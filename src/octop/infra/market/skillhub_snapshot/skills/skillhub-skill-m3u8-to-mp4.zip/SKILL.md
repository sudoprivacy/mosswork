---
name: skillhub-skill-m3u8-to-mp4
description: "将 m3u8 (HLS) 播放列表转换为 mp4 视频文件。支持本地 m3u8+ts 片段目录（如迅雷下载格式，目录名以 .m3u8 结尾内含 index.m3u8 与 index/ 子目录）、单个本地 m3u8 文件、远程 m3u8 URL，自动处理 AES-128 加密流。当用户想把 m3u8 转成 mp4、合并 ts 片段、HLS 转 mp4、视频片段合并、把下载的 m3u8 文件夹变成视频时使用。"
---

# M3U8 转 MP4

将 m3u8 (HTTP Live Streaming) 播放列表转换为 mp4 视频文件。使用 ffmpeg 进行无损流拷贝（`-c copy`），速度快、画质无损，自动处理 AES-128 加密。

## When to Use (触发场景)

- 用户说"把 m3u8 转成 mp4"、"合并 ts 片段"、"HLS 转 mp4"、"m3u8 合并成视频"
- 用户提供了一个以 `.m3u8` 结尾的**目录**（典型为迅雷/浏览器下载产物，内含 `index.m3u8` + `index/` 子目录 + ts 片段 + 可能的 `.key` 文件）
- 用户提供单个 `.m3u8` 文件
- 用户提供远程 m3u8 URL（`http(s)://....m3u8`）
- 用户说"下载的视频是很多小片段/_ts 文件，怎么合并"

## Prerequisites (前置：ffmpeg)

转换依赖 **ffmpeg**。按以下顺序定位或安装：

### 1. 定位已有 ffmpeg

```bash
# 优先用 PATH 中的 ffmpeg
if command -v ffmpeg &>/dev/null; then
  FFMPEG="ffmpeg"
  FFPROBE="ffprobe"
else
  # winget 安装的 ffmpeg 路径（版本号会变，用通配符）
  WIN_USER="${USER:-Administrator}"
  FFMPEG=$(find "/c/${WIN_USER}/AppData/Local/Microsoft/WinGet/Packages/Gyan.FFmpeg_"*/ffmpeg-*/bin/ffmpeg.exe 2>/dev/null | head -1)
  FFPROBE=$(find "/c/${WIN_USER}/AppData/Local/Microsoft/WinGet/Packages/Gyan.FFmpeg_"*/ffmpeg-*/bin/ffprobe.exe 2>/dev/null | head -1)
fi
[ -z "$FFMPEG" ] && echo "FFMPEG NOT FOUND"
```

### 2. 未安装则安装（Windows）

```bash
winget install --id Gyan.FFmpeg -e --accept-package-agreements --accept-source-agreements
```

安装后 PATH 未即时生效，需用上面的 `find` 定位实际路径（通常在 `Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe/ffmpeg-<版本>-full_build/bin/` 下）。

> macOS: `brew install ffmpeg` ｜ Linux: `sudo apt install ffmpeg`

## Workflow

### Step 1: 识别 m3u8 输入类型

用户输入可能是以下三种之一，处理方式不同：

| 类型 | 特征 | m3u8 实际路径 |
|------|------|---------------|
| **A. 目录型（迅雷下载）** | 路径以 `.m3u8` 结尾且是**目录**，内含 `index.m3u8` | `<目录>/index.m3u8` |
| **B. 单文件型** | 路径是 `.m3u8` **文件** | 该文件本身 |
| **C. 远程 URL** | 以 `http://` 或 `https://` 开头 | 该 URL |

判断方法（Bash）：
```bash
INPUT="<用户给的路径>"
if [[ "$INPUT" =~ ^https?:// ]]; then
  M3U8="$INPUT"; TYPE="remote"
elif [ -d "$INPUT" ]; then
  M3U8="$INPUT/index.m3u8"; TYPE="dir"
elif [ -f "$INPUT" ]; then
  M3U8="$INPUT"; TYPE="file"
fi
```

### Step 2:（可选）分析 m3u8 内容

读取 m3u8 前几行，确认是否加密、ts 引用方式：

```bash
head -10 "$M3U8"
```

关键信息：
- `#EXT-X-KEY:METHOD=AES-128,URI="..."` → 加密流，ffmpeg 会自动用 key 解密（key 路径通常相对 m3u8，无需手动处理）
- `#EXTINF:<秒>,` → 每个片段时长
- `index/N.ts` → ts 片段相对路径

### Step 3: 确定输出路径与文件名

- **默认输出到当前工作目录**（用户项目目录），文件名取自输入名 + `.mp4`
- 若用户指定了输出路径/文件名，用用户的
- 目录型：用目录名（去掉 `.m3u8` 后缀）作为输出文件名
- 远程型：用 URL 最后一段或让用户指定

```bash
# 目录型示例：D:\迅雷下载\1.2任务创建与结果管理.m3u8\  →  1.2任务创建与结果管理.mp4
BASENAME=$(basename "$INPUT")
OUT_NAME="${BASENAME%.m3u8}"
OUTPUT="$(pwd)/${OUT_NAME}.mp4"
```

### Step 4: 执行转换（核心命令）

**无损流拷贝**，不重新编码，速度快、画质无损：

```bash
# 本地 m3u8（A/B 型）
"$FFMPEG" -allowed_extensions ALL -i "$M3U8" -c copy -bsf:a aac_adtstoasc "$OUTPUT"

# 远程 m3u8（C 型）—— 加 -headers 防 403、-timeout 防卡死
"$FFMPEG" -headers "Referer: https://example.com/\r\nUser-Agent: Mozilla/5.0" \
  -i "$M3U8" -c copy -bsf:a aac_adtstoasc "$OUTPUT"
```

参数说明：
- `-allowed_extensions ALL`：允许读取本地无标准扩展名的片段（如加密的 ts）
- `-c copy`：直接拷贝音视频流，不重新编码（秒级完成几百 MB）
- `-bsf:a aac_adtstoasc`：修正 AAC 音频的 ADTS→MP4 容器封装，HLS→MP4 必需
- 远程场景必要时加 `-timeout 30`、`-reconnect 1 -reconnect_streamed 1`

### Step 5: 验证输出

```bash
ls -lh "$OUTPUT"
"$FFPROBE" -v error -show_entries format=duration,size,bit_rate \
  -show_entries stream=codec_type,codec_name,width,height,r_frame_rate \
  -of default=noprint_wrappers=1 "$OUTPUT"
```

确认：文件大小合理、duration 接近所有 `#EXTINF` 之和、有 video+audio 流。

### Step 6: 交付

用 `present_files` 把 mp4 展示给用户，并在回复中说明：时长、分辨率、编码、文件大小、输出路径。

## Common Issues (常见问题)

| 问题 | 原因 | 解决 |
|------|------|------|
| `Invalid data found` / ts 打不开 | m3u8 里 ts 路径相对，但当前目录不对 | 用 m3u8 的**绝对路径**作为 `-i`，ffmpeg 会以其所在目录解析相对路径 |
| 加密流报错 `decrypt` | key 路径找不到 | 确认 key 文件在 m3u8 声明的相对位置；必要时编辑 m3u8 里 `URI=` 为 key 的绝对路径 |
| 音频不同步/无声 | 缺 `-bsf:a aac_adtstoasc` | 必须加该比特流滤镜 |
| 转换极慢 | 误用重新编码（去掉了 `-c copy`） | 保持 `-c copy`；仅当格式不兼容时才用 `-c:v libx264 -c:a aac` |
| 中文路径乱码 | Windows 终端编码 | 用 Git Bash，路径用正斜杠 `/`，ffmpeg 对中文路径兼容良好 |
| 输出文件无法播放 | 容器/编码问题 | 改为重新编码：`-c:v libx264 -crf 20 -c:a aac` |
| 远程 403 | 缺 Referer/UA | 加 `-headers`（见 Step 4） |

## Tips

- **迅雷下载目录**典型结构：`<名称>.m3u8/index.m3u8` + `<名称>.m3u8/index/*.ts` + `index/0.key`，是 AES-128 加密的本地 VOD，本技能可直接处理。
- `.m3u8.bak` 是备份，忽略即可。
- 大文件（>1GB）转换仍是秒级（流拷贝不编码），但磁盘 IO 可能成瓶颈，输出到 SSD 更快。
- 若只需截取片段：`-ss 00:01:00 -t 00:00:30`（放在 `-i` 之后为快速 seek）。
