# 行业模型发布 · API 字段规格（对齐生产代码）

> 本文件是《行业模型发布助手》的字段真源。所有字段名均以生产 `employee_profiles` 表与真实创建页为准。
> 校准时间：2026-10-02

---

## 一、Web 端创建页 5 大模块 → 后端字段映射

| UI 模块 | 字段 | 后端字段 | 类型 | 必填 |
|---|---|---|---|---|
| ① 基础信息 | 模型名称 | `name` | varchar(100) | 🔴 |
| | 模型分类 | `modelCategory` | enum(`ip`/`enterprise`/`vertical`) | 默认 `vertical` |
| | 所属行业 | `industry` | varchar(50) | — |
| | 头像 | `avatarUrl` | varchar(500) | — |
| ② 模型大脑组成 | 接入 LLM | `llmProvider` / `llmModel` / `llmBaseUrl` | varchar | — |
| | 接入知识库 | `knowledgeIds` | json/array | — |
| | 公众号内容源 | `wechatSourceIds` | json/array | — |
| ③ 模型简介 | 简介 | `description` | text | 🔴 |
| ④ 接入凭证 | （平台自动交付） | — | — | 系统生成 |
| ⑤ 定价与激励 | 公开售卖 | `visibility`=`PUBLIC`/`PRIVATE` | varchar | 默认 PUBLIC |
| | 免费/付费 | `isFree` | tinyint | — |
| | 月卡 | `monthlyPrice` | decimal(10,2) | 付费时至少一档 |
| | 季卡 | `quarterlyPrice` | decimal(10,2) | — |
| | 年卡 | `yearlyPrice` | decimal(10,2) | — |
| | 永久 | `permanentPrice` | decimal(10,2) | — |
| | 按次计费开关 | `per_call_enabled` | tinyint | 默认 1 |
| | 单次价格 | `per_call_price` | decimal(10,2) | 留空按订阅档折算 |
| | 免费次数 | `freeQuota` | int | 0=不送 |
| | 免费时长(小时) | `freeTrialHours` | int | 0=不送 |
| | 一级分佣 | `directPromoterRate` | decimal(5,2) | 三者合计≤88 |
| | 二级分佣 | `secondPromoterRate` | decimal(5,2) | — |
| | 生态激励金拨比 | `ecosystemIncentiveRate` | decimal(5,2) | 默认 20 |
| | 激励金名额 | `ecosystemIncentiveQuota` | int | 默认 100，上限 500 |
| | 分佣总开关 | `commissionEnabled` | tinyint | — |
| | 团队激励金 | `teamIncentiveRate` | decimal(5,2) | — |
| | 预留 | `reserveRate` | decimal(5,2) | — |

> 📌 **注意列名不一致**（生产库历史遗留，务必用对）：
> - 定价四列是 **驼峰** `monthlyPrice/quarterlyPrice/yearlyPrice/permanentPrice`
> - 但按次计费是 **下划线** `per_call_enabled/per_call_price`
> - 免费额度有**两套**：`free_quota`（旧）和 `freeQuota`（新），**写新的**
> - 另有 `original_price`/`originalPrice`（划线价）、`monthly_price` 等下划线副本列（勿用）

---

## 二、MCP 工具规格

### 2.1 `publish_industry_model`（发布）

**入参**（实查自 `backend/src/modules/mcp/mcp.service.ts:1516`）：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `name` | string | 🔴 | 行业模型名称 |
| `description` | string | 🔴 | 行业模型简介 |
| `persona` | string | — | 人设/系统提示词 |
| `industry` | string | — | 所属行业 |
| `category` | string | — | 分类，默认 `vertical` |
| `price` | number | 付费时 | **单位：元** |
| `isFree` | boolean | — | 默认 false |
| `greeting` | string | — | 开场白 |
| `knowledgeIds` | string[] | — | 绑定的平台知识库 ID |

**固定行为**：
```js
productType: 'industry_model'   // 写死
status: 'published'            // 写死 → 创建即上架模型广场
```

**🔴 能力缺口（MCP 版没有的字段）**：
`avatarUrl` / `modelCategory` / `wechatSourceIds` / 四档定价 / `perCall*` / `freeQuota` / `freeTrialHours` / 分佣与激励金

> 🎯 **军师建议**：涉及定价/分佣/头像 → **回网页端**。两者最终写进同一张表。

### 2.2 其他相关工具

| 工具 | 用途 |
|---|---|
| `list_industry_models` | 查公开行业模型（**查重用，注意它会忽略关键词**） |
| `get_my_industry_models` | 查自己的行业模型（**查重更可靠**） |
| `chat_industry_model` | 与行业模型对话（测试用） |
| `list_knowledge_bases` | 列出可用知识库 |
| `get_knowledge_base` / `list_knowledge_documents` | 知识库自检（数文档数） |
| `search_knowledge` | 知识库检索测试 |
| `get_knowledge_evolution_stats` | 反哺与知识库成长数据 |
| `submit_corpus` | 提交反哺语料 |
| `get_my_points` | 贡献分/任务分/生态激励金进度 |
| `ecosystem_incentive_status` | 激励金资格与达标状态 |

---

## 三、🔴 查重规范（平台铁律，不可跳过）

**根因**：虾友 `search` 相关接口**忽略 keyword 参数、返回全量列表**（历史遗留）。所以：

```
❌ 错误做法：调 search(keyword="高尔夫")  → 以为搜不到就是没有
✅ 正确做法：
   1. list_industry_models / get_my_industry_models 拿全量
   2. 本地逐条比对 name（和 slug）
   3. 命中同名 → 问用户「你是不是要更新它？」
      ├─ 是 → 走 PATCH（保留原有订阅用户）
      └─ 否（确实是不同模型）→ 才新建
```

**其他命名场景同规则**：SKILL.md / 数字员工发布助手也适用。

---

## 四、行业分类（22 项，创建页动态读取）

前端走 `GET /api/categories` → 取 `按行业划分`(`4978bd55-2cb0-451b-b939-53228f3c39ee`) 的子项。

| sort | 名称 | sort | 名称 |
|---|---|---|---|
| 1 | 科技互联网 | 12 | 宠物 |
| 2 | 电商零售 | 13 | 汽车 |
| 3 | 教育培训 | 14 | 法律咨询 |
| 4 | 金融投资 | 15 | 人力资源 |
| 5 | 医疗健康 | 16 | 设计创意 |
| 6 | 房地产 | 17 | 游戏动漫 |
| 7 | 文化传媒 | 18 | 其他 |
| 8 | 餐饮美食 | 19 | 美业服务 |
| 9 | 旅游出行 | 20 | 家政养老 |
| 10 | 健身运动 | 21 | 零售便利 |
| 11 | 母婴亲子 | 22 | 健康养生 |

> ✅ 2026-10-02 已补齐美业服务/家政养老/零售便利/健康养生（原 18 → 22 项）。
> 找不到对应行业 → 选「其他」并在简介写清细分场景 + 建议反馈新增。

---

## 五、交付凭证（三件套）

| 交付物 | 值 | 说明 |
|---|---|---|
| 接口地址 | `https://aiskillhub.vip/api/v1` | 固定 |
| API Key | `api_keys` 表 `source='industry_model'` 的行 | 支付成功回调自动签发；**创作者本人可免订阅自取** |
| 模型名 | 系统生成的专属 ID | `employee_profiles.id` |

**约束**：
- 🔴 **一 Key 只绑一模型**：调别的模型 → 403
- 🔴 幂等键 `(userId, boundModelId)`，重复签发不会重复发
- 🔴 **有效期 = 订阅到期时间**
- 🔴 认接口路径：`POST /api/v1/chat/completions`（无鉴权豁免时先过实名）

---

## 六、分佣池口径（创建页原文）

> 平台抽成 12%，剩余 88% 进入你的收益池；
> 一级/二级推广分佣与生态激励金均从该池中拨出（**合计 ≤88%**）

**推荐模板**：一级 15% + 二级 8% + 生态激励金 20% = 43%，剩 45% 自留。

**积分口径**（`model-incentive.service.ts` 顶部 `TASK_POINTS`）：
- 投喂 1 条语料 = **5 任务分**
- 语料被采纳 = **10 贡献分**
- 语料被进化 = **50 贡献分**
- 贡献分达标线 **500**（2026-09-25 上调）
- 生态激励金按月分给有贡献的用户（按贡献分比例）
