---
name: skillhub-skill-n8n-workflow-builder
description: "把日常重复任务落成可运行的 n8n 工作流：节点选型、JSON 工作流草稿、HTTP/代码/触发器节点配置、错误处理与发布清单，覆盖自托管与云端 n8n 的真实搭建场景。"
---

# n8n 自动化工作流搭建师

## 适用场景

你有一堆**重复、跨多个 App、规则固定**的任务想自动化，但卡在：n8n 节点太多不知道怎么连、HTTP Request 节点的认证头怎么填、Webhook 触发器收不到数据、代码节点怎么用、一报错整条流就断。本技能把"每天把 Gmail 附件存到网盘并发群通知"这类需求，直接落成**可导入 n8n 的工作流 JSON + 逐步配置说明**，而不是泛泛讲什么是自动化。

典型用户：运营要把多平台表单汇总到表格、开发者要定时调内部 API 落库、客服要把工单自动分流、个体户要把电商订单同步到财务表、所有人想把"复制粘贴"类脏活交给机器。

> 区别于「扣子智能体搭建师」（聚焦国内零代码 SaaS 的人设/工作流）。本技能聚焦 **n8n 的节点化自动化范式**（自托管/云端通用、代码友好、API 优先），给出可直接粘贴的节点 JSON 与认证配置。

## 工作流

1. **拆任务为节点图**：把需求拆成「触发器 → 取数 → 处理 → 输出」四段，标出每段用什么节点。
   - 触发器：Schedule（定时）、Webhook（外部回调）、Manual（手动）、App 事件节点（Gmail/Notion 等）。
2. **选节点并填参数**：给出每类任务的推荐节点
   - 取数：HTTP Request（任意 REST API）、Gmail/Google Sheets/Notion/飞书节点、Database 节点。
   - 处理：Code（JS/Python，做清洗/转换）、Set（改字段）、IF/Switch（分支）、Merge（合并多路）。
   - 输出：HTTP Request（写回）、邮件/IM 节点、Google Sheets、数据库。
3. **HTTP Request 节点范式**：贴出标准骨架
   - Method/URL、Authentication（Generic Credential/OAuth2/Header Auth）、Headers（`Content-Type: application/json` + 鉴权头）、Body（JSON/表单）、Query 参数。
   - 配「务必勾 Retry On Fail + Max Tries 3」避免瞬时抖动断流。
4. **错误处理**：用 Error Trigger 节点接「失败告警」（发邮件/钉钉）；用 Continue On Fail + IF 判断状态码，避免单条坏数据卡死整批。
5. **给可导入 JSON**：输出最小可运行工作流 JSON（`nodes` + `connections`），用户粘贴到 n8n「Import from File」即可。
6. **发布清单**：自托管（Docker `n8n` 镜像 + `WEBHOOK_URL` 公网回调）与 n8n Cloud（托管 Webhook）的差异、环境变量、凭证加密存储要点。

## 示例

**需求**：「每天 9 点抓取我们官网的公开文章列表 API，把新增的 3 条写入 Google Sheets，并在飞书群发一条汇总。」

**落地方案**：
- 节点图：Schedule(09:00) → HTTP Request(GET /api/articles?since=yesterday) → Code(过滤出新增项、映射标题/链接/时间) → Google Sheets(append) → 飞书节点(发卡片)。
- HTTP Request 配置：Header Auth，头 `Authorization: Bearer <token>`，Retry On Fail 开。
- Code 节点示例（JS）：`return items.filter(i => !seen.has(i.json.id)).map(...)`。
- 输出 JSON：给出这四节点的 `nodes`/`connections` 草稿，用户导入后只填凭证即可跑。

## 边界

- 针对 **n8n（自托管与 Cloud 通用）** 的节点范式；Zapier/Make/扣子界面不同，仅思路可借鉴。
- 不替代 n8n 官方文档，节点字段以当前版本为准；不保证某个第三方 API 当下可用/未被限流。
- 不出私有化深度定制（自写后端服务、内网穿透）的完整方案，点到 n8n 能接的程度为止。
- 涉及密钥会提示放 n8n Credentials 而非硬编码进工作流，避免泄露。

## 技术底座

- 节点化数据流：每个节点消费 `items`（数组），输出 `items`，通过 `connections` 连边。
- 表达式系统：n8n 用 `{{ $json.xxx }}` / `$node["xxx"].json` 在任意字段引用上游数据。
- 认证模式：None / Basic / Header Auth / OAuth2 / Query Auth，凭证统一存 Credentials 库。
- 容错：Retry On Fail、Continue On Fail、Error Trigger 三类机制保活。
- 可扩展：输出标准工作流 JSON，支持版本管理与一键导入。
