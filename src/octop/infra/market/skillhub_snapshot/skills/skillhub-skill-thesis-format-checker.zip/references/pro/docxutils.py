# -*- coding: utf-8 -*-
"""
docxutils.py — thesis-format-doctor 格式工具的共享底层库（零第三方依赖）。

只依赖 Python 标准库：zipfile / re / json / xml.etree.ElementTree。
.docx 本质是 ZIP 包，正文与样式分别在 word/document.xml、word/styles.xml。

本库提供给下列脚本复用：
  - format-profile.py   学校模板 -> 格式画像 profile.json
  - format-check.py     客户论文 vs 画像 -> 诊断报告
  - headings-fix.py     自动套标题样式 -> 新 docx（Word 可一键出目录）
  - ref-reformat.py     参考文献按范式重排 -> 新 docx
"""
import zipfile
import re
import xml.etree.ElementTree as ET

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
WR = "{%s}" % W  # w: 前缀包裹器

# 图片相关命名空间（DrawingML / WordprocessingDrawing）
WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
WPR = "{%s}" % WP  # wp: 前缀
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
AR = "{%s}" % A    # a: 前缀
PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"
PICR = "{%s}" % PIC  # pic: 前缀

# EMU 换算常量
EMU_PER_TWIP = 635       # 1 inch = 1440 twips = 914400 EMU
EMU_PER_CM = 360000      # 1 cm = 360000 EMU
# A4 默认文本区宽度（EMU），作为 sectPr 缺失时的兜底
# A4: 21cm 宽, 左右各 3.17cm 边距 -> 文本区 ≈14.66cm
_DEFAULT_TEXT_WIDTH_EMU = 5277600


def reg_ns():
    """注册全部命名空间，避免写回 XML 时出现 ns0/ns1 前缀破坏 docx。"""
    ET.register_namespace("w", W)
    ET.register_namespace("wp", WP)
    ET.register_namespace("a", A)
    ET.register_namespace("pic", PIC)


# ---------------------------------------------------------------------------
# 读取
# ---------------------------------------------------------------------------
def load(path):
    """返回 (ZipFile, document.xml 的 ElementTree root)。"""
    z = zipfile.ZipFile(path)
    doc = z.read("word/document.xml").decode("utf-8")
    root = ET.fromstring(doc)
    return z, root


def load_styles(path):
    """读取 word/styles.xml，返回 {styleId: {name, basedOn, rPr, pPr}}。"""
    z = zipfile.ZipFile(path)
    try:
        sxml = z.read("word/styles.xml").decode("utf-8")
    except KeyError:
        return {}
    sroot = ET.fromstring(sxml)
    out = {}
    for st in sroot.findall(WR + "style"):
        sid = st.get(WR + "styleId")
        name_el = st.find(WR + "name")
        name = name_el.get(WR + "val") if name_el is not None else (sid or "")
        based = st.find(WR + "basedOn")
        basedOn = based.get(WR + "val") if based is not None else None
        rpr = _rpr_to_dict(st.find(WR + "rPr"))
        pinfo = _ppr_to_dict(st.find(WR + "pPr"))
        out[sid] = {"name": name, "basedOn": basedOn, "rPr": rpr, "pPr": pinfo}
    return out


def _rpr_to_dict(rpr):
    if rpr is None:
        return {}
    d = {}
    rfonts = rpr.find(WR + "rFonts")
    if rfonts is not None:
        d["ascii"] = rfonts.get(WR + "ascii")
        d["eastAsia"] = rfonts.get(WR + "eastAsia")
        d["hAnsi"] = rfonts.get(WR + "hAnsi")
    sz = rpr.find(WR + "sz")
    if sz is not None:
        d["sz"] = sz.get(WR + "val")  # 半磅，如 24 = 小二号
    b = rpr.find(WR + "b")
    if b is not None:
        d["bold"] = b.get(WR + "val") != "false"
    return d


def _ppr_to_dict(ppr):
    if ppr is None:
        return {}
    pinfo = {}
    ind = ppr.find(WR + "ind")
    if ind is not None:
        pinfo["firstLineChars"] = ind.get(WR + "firstLineChars")
        pinfo["firstLine"] = ind.get(WR + "firstLine")
    spacing = ppr.find(WR + "spacing")
    if spacing is not None:
        pinfo["line"] = spacing.get(WR + "line")
        pinfo["before"] = spacing.get(WR + "before")
        pinfo["after"] = spacing.get(WR + "after")
        pinfo["lineRule"] = spacing.get(WR + "lineRule")  # 行距规则：auto/exact/atLeast
    jc = ppr.find(WR + "jc")
    if jc is not None:
        pinfo["jc"] = jc.get(WR + "val")
    return pinfo


def paragraphs(root):
    """遍历正文段落，返回 [{text, style, rpr, pPr, in_table}]。style 为 w:pStyle 的 val。"""
    # 预先收集所有表格内段落元素 id（表格单元格里的 <w:p> 也要算段落）
    table_para_ids = set()
    for tbl in root.iter(WR + "tbl"):
        for cp in tbl.iter(WR + "p"):
            table_para_ids.add(id(cp))
    res = []
    for p in root.iter(WR + "p"):
        texts = "".join(t.text or "" for t in p.iter(WR + "t"))
        ppr = p.find(WR + "pPr")
        style = None
        pinfo = {}
        if ppr is not None:
            ps = ppr.find(WR + "pStyle")
            if ps is not None:
                style = ps.get(WR + "val")
            pinfo = _ppr_to_dict(ppr)
        # 取第一个非图片 run 的 rPr 作为段落字体/字号代表。
        # 含图 run（w:drawing / w:pict）的 rPr 是旧的图片属性，不代表文本格式；
        # 若取到它会导致 checker 误报"标题字号不符"（实为图片 run 的 sz）。
        first_run = None
        for r in p.iter(WR + "r"):
            _has_img = False
            for tag in (WR + "drawing", WR + "pict"):
                if len(list(r.iter(tag))) > 0:
                    _has_img = True
                    break
            if not _has_img:
                first_run = r
                break
        rpr = _rpr_to_dict(first_run.find(WR + "rPr") if first_run is not None else None)
        res.append({"text": texts, "style": style, "rpr": rpr, "pPr": pinfo,
                    "in_table": id(p) in table_para_ids})
    return res


def margins(root):
    sp = root.find(".//" + WR + "sectPr")
    if sp is None:
        return {}
    pg = sp.find(WR + "pgMar")
    if pg is None:
        return {}
    return {k: pg.get(WR + k) for k in
            ["top", "bottom", "left", "right", "header", "footer", "gutter"]
            if pg.get(WR + k) is not None}


def tables(root):
    """返回每个表格的边框字典 {edge: val}。"""
    out = []
    for tbl in root.iter(WR + "tbl"):
        borders = {}
        tblpr = tbl.find(WR + "tblPr")
        if tblpr is not None:
            bt = tblpr.find(WR + "tblBorders")
            if bt is not None:
                for edge in ["top", "left", "bottom", "right", "insideH", "insideV"]:
                    e = bt.find(WR + edge)
                    if e is not None:
                        val = e.get(WR + "val")
                        # 过滤 val="none"（无边框），否则会被误判为"有该边线"
                        if val and val != "none":
                            borders[edge] = val
        out.append(borders)
    return out


# ---------------------------------------------------------------------------
# 标题层级启发式识别（处理中文"第X章"、数字"1.1.1"、中文序号等）
# ---------------------------------------------------------------------------
def is_toc_residue(text):
    """判断段落文本是否为目录域/书签残留（.doc 转 .docx 时带入的脏数据）。

    这些段落会被 detect_heading 误判为标题（如 '1 绪论TC  "Chapter 1 Intro"'），
    若套样式会污染目录，必须跳过。判定依据：含 'TC ' 标记、英文目录项 'Chapter '、
    或目录域开关 '\\l '。
    """
    t = text or ""
    if re.search(r"TC\s", t):
        return True
    if '"Chapter' in t or "Chapter " in t:
        return True
    if re.search(r"\\l[\s\"]", t):
        return True
    return False


def style_xml(path, sid):
    """提取模板中某个 styleId 的 <w:style> 定义（字符串），供注入目标文档。"""
    reg_ns()
    z = zipfile.ZipFile(path)
    try:
        sxml = z.read("word/styles.xml").decode("utf-8")
    except KeyError:
        return ""
    sroot = ET.fromstring(sxml)
    for st in sroot.findall(WR + "style"):
        if st.get(WR + "styleId") == sid:
            return ET.tostring(st, encoding="unicode")
    return ""


def detect_heading(text):
    """
    返回 (level, confidence)。
    level: 1/2/3 或 None；confidence: 0~1。
    依据：编号格式 + 中文序数。仅做"像不像标题"的启发式判断，
    实际套样式时还需结合字号/加粗/段长等上下文（见 headings-fix.py）。
    """
    t = (text or "").strip()
    if not t:
        return (None, 0.0)
    # 第X章 / 第1篇（一级）
    if re.match(r"^第[一二三四五六七八九十百千\d]+[章篇编]", t):
        # 防御"列举性正文"被误判为章标题（用户实测踩坑）：正文里用"第一章、第二章"
        # 列举章节安排时，段落以"第X章"开头但本质是正文的枚举项，套章样式会污染目录。
        # 判定为非标题的两种情形：
        #  (a) 章/篇后紧跟顿号/逗号/分号（如"第一章、第二章……"）；
        #  (b) 一段内出现 ≥2 个章/节标记（如"第一章 绪论 第二章 文献综述"式目录残片）。
        # 去括号后再统计，避免"（含第三章内容）"这类正文叙述干扰真实标题判定。
        if re.match(r"^第[一二三四五六七八九十百千\d]+[章篇编][、，；,]", t):
            return (None, 0.0)
        _core = re.sub(r"[（(][^（）()]*[）)]", "", t)
        if len(re.findall(r"第[一二三四五六七八九十百千\d]+[章篇编]", _core)) >= 2:
            return (None, 0.0)
        return (1, 0.95)
    # 第X节（二级）
    if re.match(r"^第[一二三四五六七八九十百千\d]+节", t):
        if re.match(r"^第[一二三四五六七八九十百千\d]+节[、，；,]", t):
            return (None, 0.0)
        _core = re.sub(r"[（(][^（）()]*[）)]", "", t)
        if len(re.findall(r"第[一二三四五六七八九十百千\d]+节", _core)) >= 2:
            return (None, 0.0)
        return (2, 0.90)
    # 1 / 1.1 / 1.1.1 / 1.1.1.1（带分隔符或顿号；支持到 4 级标题）
    m = re.match(r"^(\d{1,3})(?:\.(\d{1,3}))?(?:\.(\d{1,3}))?(?:\.(\d{1,3}))?(?=[\s\u4e00-\u9fff、：:（(])", t)
    if m:
        dots = sum(1 for x in [m.group(2), m.group(3), m.group(4)] if x)
        return (1 + dots, 0.95)
    # 中文序号「一、/二、」与「（一）/（二）」：学校模板（如清华）采用纯数字四级
    # （1 / 1.1 / 1.1.1 / 1.1.1.1），并不规定 一、/（一） 对应哪一级。按"格式严格按学校
    # 模板、skill 不自创级别"原则，此类序号不硬赋标题级别，判为正文（None）——避免把
    # 客户自创/列举性的中文序号误套成某级标题格式。若某学校模板确实以中文序号分级，
    # 应由该校模板/批注明确驱动，而非在此硬编码。
    # 阿拉伯数字/圈号括号序号（（1）(1) ① ② 等）→ 正文列举项，非标题。
    return (None, 0.0)


# ---------------------------------------------------------------------------
# 写回（修改 document.xml 后生成新 docx）
# ---------------------------------------------------------------------------
def write_docx(src_zip_path, dst_path, new_document_xml):
    """以 src_zip_path 为蓝本，把 document.xml 替换为 new_document_xml，写出 dst_path。"""
    write_docx_files(src_zip_path, dst_path, {"word/document.xml": new_document_xml})


def write_docx_files(src_zip_path, dst_path, replacements):
    """以 src_zip_path 为蓝本，按 replacements={内部路径: 新xml} 替换若干部件后写出 dst_path。

    用于「按模板应用样式」：同时替换 document.xml（套样式）与 styles.xml（注入模板样式定义）。
    """
    reg_ns()
    with zipfile.ZipFile(src_zip_path) as zin:
        with zipfile.ZipFile(dst_path, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                if item.filename in replacements:
                    zout.writestr(item, replacements[item.filename])
                else:
                    zout.writestr(item, zin.read(item.filename))


def to_doc_xml(root):
    """把修改后的 root 序列化为带声明头的 document.xml 字符串。"""
    reg_ns()
    body = ET.tostring(root, encoding="unicode")
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' + body


# ---------------------------------------------------------------------------
# 批注（comments.xml）解析 —— 模板里"批注"往往写明最权威的格式要求
# （字号/字体/大纲级别/对齐/缩进/段间距/行距），应优先于样式定义采纳。
# ---------------------------------------------------------------------------
def cn2int(s):
    if s is None:
        return 0
    if str(s).isdigit():
        return int(s)
    d = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6,
         '七': 7, '八': 8, '九': 9, '十': 10}
    if s == '十':
        return 10
    if '十' in s:
        parts = s.split('十')
        left = d.get(parts[0], 1) if parts[0] else 1
        right = d.get(parts[1], 0) if parts[1] else 0
        return left * 10 + right
    return d.get(s, 0)


# 中文字号名 -> (半磅 sz 值, 磅 pt)。批注里写"小三号"等，需映射到 Word 的 sz 半磅。
SIZE_MAP = {
    '初号': (84, 42), '小初': (72, 36), '一号': (52, 26), '小一': (48, 24),
    '二号': (44, 22), '小二': (36, 18), '三号': (32, 16), '小三': (30, 15),
    '四号': (28, 14), '小四': (24, 12), '五号': (21, 10.5), '小五': (18, 9),
    '六号': (15, 7.5), '小六': (13, 6.5), '七号': (11, 5.5), '八号': (10, 5),
}
# 注意：每个字号的"小X"变体必须排在对应"X"之前，否则"小三号"会被"三号"抢先匹配。
_SIZE_ORDER = ['小初', '初号', '小一', '一号', '小二', '二号', '小三', '三号',
               '小四', '四号', '小五', '五号', '小六', '六号', '小七', '七号',
               '小八', '八号']


def comments(path):
    """读取 word/comments.xml，返回 [{id, author, text}]。无批注返回 []。"""
    z = zipfile.ZipFile(path)
    try:
        cxml = z.read("word/comments.xml").decode("utf-8")
    except KeyError:
        return []
    root = ET.fromstring(cxml)
    out = []
    for c in root.findall(WR + "comment"):
        cid = c.get(WR + "id")
        author = c.get(WR + "author") or ""
        txt = "".join(t.text or "" for t in c.iter(WR + "t"))
        out.append({"id": cid, "author": author, "text": txt.strip()})
    return out


def parse_comment_spec(text):
    """把一条批注正文解析为结构化格式要求 dict（只含命中的键）。

    可识别：中文字体、西文字体、字号(中文字号名)、加粗、大纲级别(N级/正文文本)、
    对齐(居中/两端/左/右)、首行缩进N字符、无缩进、悬挂缩进N厘米、
    段前/段后N磅、行距(单倍/固定值N磅/最小值N磅)。
    """
    t = text or ""
    spec = {}
    # 中文字体
    mz = re.search(r'中文字体(?:为|是|[:：])\s*([\u4e00-\u9fff]{1,4})', t)
    if mz:
        spec["zh_font"] = mz.group(1)
    # 西文字体
    me = re.search(r'西文字体(?:为|是|[:：])\s*([A-Za-z ]+?)(?:[，,。；;]|$)', t)
    if me:
        spec["en_font"] = me.group(1).strip()
    # 字号（中文字号名）
    for name in _SIZE_ORDER:
        if name in t:
            spec["size"] = name
            spec["sz"] = SIZE_MAP[name][0]
            break
    # 字号（原始磅值，如 13pt / 11pt）——不少学校直接写 pt，必须支持
    if "size" not in spec:
        mpt = re.search(r'(\d+(?:\.\d+)?)\s*[pP][tT]', t)
        if mpt:
            pt = float(mpt.group(1))
            spec["size"] = "%gpt" % pt
            spec["sz"] = int(round(pt * 2))
    # 加粗
    if '加粗' in t:
        spec["bold"] = True
    # 大纲级别
    mo = re.search(r'大纲级别\s*([0-9一二三四五])\s*级', t)
    if mo:
        spec["outline_level"] = cn2int(mo.group(1))
    elif '大纲级别正文文本' in t or '大纲级别正文' in t:
        spec["outline_level"] = 0  # 0 表示"正文文本"（无大纲级别）
    # 对齐
    if '居中' in t:
        spec["align"] = "center"
    elif '两端对齐' in t:
        spec["align"] = "both"
    elif '左对齐' in t:
        spec["align"] = "left"
    elif '右对齐' in t:
        spec["align"] = "right"
    # 缩进
    if '首行缩进' in t:
        mi = re.search(r'首行缩进\s*(\d+)\s*字符', t)
        spec["indent_chars"] = int(mi.group(1)) if mi else None
        spec["indent_type"] = "first"
    elif '无缩进' in t:
        spec["indent_chars"] = 0
        spec["indent_type"] = "none"
    mh = re.search(r'悬挂缩进\s*([\d.]+)\s*厘米', t)
    if mh:
        spec["hanging_cm"] = float(mh.group(1))
    mhc = re.search(r'悬挂缩进\s*([\d.]+)\s*字符', t)
    if mhc:
        spec["hanging_chars"] = float(mhc.group(1))
    # 段前/段后（兼容"段前6磅""段前空6磅""段前段后均空0磅"等多种措辞）
    mb = re.search(r'段前\s*空?\s*(\d+)\s*磅', t)
    if mb:
        spec["before_pt"] = int(mb.group(1))
    mae = re.search(r'段后\s*空?\s*(\d+)\s*磅', t)
    if mae:
        spec["after_pt"] = int(mae.group(1))
    mboth = re.search(r'段前段后均\s*空?\s*(\d+)\s*磅', t)
    if mboth:
        spec["before_pt"] = int(mboth.group(1))
        spec["after_pt"] = int(mboth.group(1))
    # 行距
    if '单倍行距' in t:
        spec["line_rule"] = "single"
    elif '固定值' in t:
        ml = re.search(r'固定值\s*(\d+)\s*磅', t)
        spec["line_rule"] = "exact"
        spec["line_val"] = int(ml.group(1)) if ml else None
    elif '最小值' in t:
        ml = re.search(r'最小值\s*(\d+)\s*磅', t)
        spec["line_rule"] = "atLeast"
        spec["line_val"] = int(ml.group(1)) if ml else None
    # 分页：另起一页 / 另起页 / 新起一页
    if re.search(r'另起.?一页|另起页|新起.?一页', t):
        spec["page_break_before"] = True
    return spec


def parse_page_spec(text):
    """解析"页边距：上—2.8 cm，下—2.5 cm…"类批注，返回 {top_cm,...}（缺省键不出现）。"""
    t = text or ""
    out = {}
    for key, pat in (("top_cm", r'上[—\-~]?\s*([\d.]+)\s*cm'),
                     ("bottom_cm", r'下[—\-~]?\s*([\d.]+)\s*cm'),
                     ("left_cm", r'左[—\-~]?\s*([\d.]+)\s*cm'),
                     ("right_cm", r'右[—\-~]?\s*([\d.]+)\s*cm'),
                     ("header_cm", r'页眉[边距]?\s*([\d.]+)\s*cm'),
                     ("footer_cm", r'页脚[边距]?\s*([\d.]+)\s*cm')):
        m = re.search(pat, t)
        if m:
            out[key] = float(m.group(1))
    return out


# 批注 -> 类别（用于把分散的批注归并到 一级标题/正文/页边距… 等规范维度）。
# 顺序即优先级（更具体的标签放前面）。
# 注意：这是「解析模板」环节的归并映射，必须从模板自身措辞识别类别——不同学校
# 模板用词不同（表题/表头/图表标题/图名…），这里集中维护同义别名，套用层不依赖
# 任何具体措辞。新增学校模板时，通常只需在此补别名即可，无需改套用逻辑。
_COMMENT_CATS = [
    ('h1', '一级标题'), ('h1', '章节标题'), ('h1', '章标题'),
    ('h3', '二级节标题'), ('h3', '二级节'),
    ('h2', '一级节标题'), ('h2', '一级节'),
    ('h2', '二级标题'), ('h2', '节标题'),
    ('h3', '三级标题'), ('h3', '小节标题'),
    ('conclusion', '结论标题'), ('ack', '致谢标题'), ('appendix', '附录标题'),
    ('toc', '目录'),
    ('figure_note', '图注'), ('figure_note', '图片来源'), ('figure_note', '图源'), ('figure_note', '图下说明'),
    ('figure', '图题'), ('figure', '图名'), ('figure', '图标题'), ('figure', '图表标题'), ('figure', '插图标题'),
    ('table_note', '表注'), ('table_note', '数据来源'), ('table_note', '资料来源'), ('table_note', '来源说明'), ('table_note', '注记'),
    ('table', '表题'), ('table', '表头'), ('table', '表标题'), ('table', '图表标题'),
    ('footnote', '脚注'),
    ('reference', '参考文献'), ('reference', '参考资料'), ('reference', '引用文献'),
    ('reference', 'References'), ('reference', 'Bibliography'),
    ('en_keywords', 'Key words'), ('keywords', '关键词'),
    ('en_abstract', '英文摘要'),
    ('abstract_title', '摘要标题'), ('abstract', '摘要'),
    ('title', '题目'), ('title', '论文题目'),
    ('page', '页边距'),
    ('body', '正文'),
]

# ---------------------------------------------------------------------------
# 跨校通用识别：结构页标题 / 参考文献区标题 / 正文样式名
# 不同学校/中英文模板用词不同（参考文献 / References / Bibliography / 参考资料…），
# 此处集中维护「关键词集合 + 大小写不敏感 + startswith 兜底」，所有调用方统一复用，
# 不再在各处散落写死中文关键词（这是跨校通用性的关键）。
# ---------------------------------------------------------------------------
REFERENCE_KEYWORDS = (
    "参考文献", "参考资料", "引用文献",
    "references", "reference", "bibliography", "bibliographies",
)
STRUCTURAL_KEYWORDS = (
    "结论", "致谢", "附录", "参考文献", "目录", "摘要",
    "abstract", "references", "reference", "bibliography",
    "conclusion", "acknowledgement", "acknowledgments",
    "acknowledgment", "appendix", "appendices", "contents", "summary",
)
BODY_STYLE_NAMES = (
    "正文", "正文文本", "normal", "body text", "bodytext", "body",
    "standard", "default paragraph font", "text body",
)


def _kw_hit(text, keywords):
    t = (text or "").strip().lower()
    if not t:
        return False
    for kw in keywords:
        k = kw.lower()
        if t == k or t.startswith(k):
            return True
    return False


def is_reference_heading(text):
    """段落是否为参考文献区标题（中英文主流 + 异校异措辞）。跨校安全。"""
    return _kw_hit(text, REFERENCE_KEYWORDS)


def is_structural_title(text):
    """段落是否为结构页标题（结论/致谢/附录/参考文献/目录/摘要/ABSTRACT…）。跨校安全。"""
    return _kw_hit(text, STRUCTURAL_KEYWORDS)


def is_body_style_name(name):
    """样式名是否为正文样式（中英文 + 异校异名）。跨校安全。"""
    return _kw_hit(name, BODY_STYLE_NAMES)


def categorize_comment(text):
    """返回批注所属类别 key；无法归类返回 'misc'。"""
    t = text or ""
    for key, token in _COMMENT_CATS:
        if token in t:
            return key
    return 'misc'


def extract_comment_specs(comments_list):
    """把批注列表归并为 类别->结构化规范。page 类别单独走 parse_page_spec。

    返回 {"cats": {类别: spec}, "page": {cm...} 或 None, "count": N}
    """
    cats = {}
    page = None
    for c in comments_list:
        cat = categorize_comment(c["text"])
        if cat == 'page':
            page = parse_page_spec(c["text"])
            continue
        if cat == 'misc':
            # 无明确标签：尝试用正文文本/首行缩进等弱信号归到 body，否则丢弃
            if '正文文本' in c["text"] and '首行缩进' in c["text"]:
                cat = 'body'
            else:
                continue
        spec = parse_comment_spec(c["text"])
        if not spec:
            continue
        # 同类批注合并：后写覆盖同键（山大模板每类仅一条，天然幂等）
        base = cats.get(cat, {})
        base.update(spec)
        cats[cat] = base
    return {"cats": cats, "page": page, "count": len(comments_list)}
