---
name: skillhub-skill-01-9-02
description: "自动根据文件扩展名/类型，将当前目录的文件归档到D盘FileArchive预设分类文件夹（图片、文档、视频、代码、压缩包等），支持预览、自定义分类、空文件夹清理，一键整理杂乱目录，全程不占用C盘空间。"
---

# File Auto Archiver - D盘文件自动归档工具

## 🎯 技能目标
自动识别当前目录下的文件类型，按扩展名归类到 **D盘`FileArchive`目录**下的预设文件夹，一键整理杂乱目录，所有文件均移动到D盘，不占用C盘空间。

## 📋 支持的文件类型与目标文件夹（D盘专属）
| 文件类型 | 扩展名 | D盘目标路径 |
|----------|--------|------------|
| 图片文件 | .jpg, .jpeg, .png, .gif, .bmp, .tiff, .webp | `D:\FileArchive\Images\` |
| 文档文件 | .txt, .pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .md | `D:\FileArchive\Documents\` |
| 视频文件 | .mp4, .avi, .mov, .mkv, .flv, .wmv | `D:\FileArchive\Videos\` |
| 音频文件 | .mp3, .wav, .flac, .aac, .ogg | `D:\FileArchive\Audios\` |
| 代码文件 | .py, .java, .js, .html, .css, .cpp, .c, .go, .json | `D:\FileArchive\Code\` |
| 压缩包 | .zip, .rar, .7z, .tar, .gz | `D:\FileArchive\Archives\` |
| 安装包 | .exe, .msi, .apk, .dmg | `D:\FileArchive\Installers\` |
| 其他文件 | 未匹配以上扩展名的文件 | `D:\FileArchive\Others\` |

## 🛠️ 执行流程（全程D盘操作）
1.  **安全校验**：
    - 首先获取当前目录路径，列出所有文件（排除子文件夹和 `.` 开头的隐藏文件）
    - 统计文件总数，生成归档预览清单，显示每个文件将移动到的D盘路径，让用户确认是否执行（防止误操作）
2.  **创建D盘目录**：
    - 自动检查并创建D盘根目录下的`FileArchive`总文件夹，以及所有子分类文件夹（如`Images/`、`Documents/`等），已存在则跳过，不会重复创建
3.  **文件分类与移动**：
    - 遍历每个文件，根据扩展名匹配对应的D盘目标文件夹
    - 若目标文件夹已存在同名文件，自动重命名（如`pic.jpg` → `pic(1).jpg`）避免覆盖原文件
    - 移动过程中实时显示进度，防止文件丢失
4.  **收尾处理**：
    - 归档完成后，统计成功移动/失败的文件数量，生成D盘归档报告
    - 可选：询问用户是否删除原目录中已归档的空文件夹

## ⚠️ 安全与错误处理
- 不处理 `.` 开头的系统隐藏文件，不移动当前 `.md` 技能文件本身
- 全程文件移动目标均为D盘，不占用C盘空间
- 遇到同名文件自动重命名，不会覆盖D盘已有的文件
- 所有操作前必须显示完整的D盘路径预览清单，用户确认后才执行
- 移动失败的文件会单独列出，保留在原目录，不会丢失
- 若D盘无权限/空间不足，会提前提示用户，避免执行失败

## 💡 使用示例
用户：`帮我把当前文件夹的文件整理到D盘`
Claude：
> 我将为你把当前目录 `D:\claudeStudy` 下的文件归档到D盘`FileArchive`目录。
> 预览：
> - `photo1.png` → `D:\FileArchive\Images\photo1.png`
> - `report.pdf` → `D:\FileArchive\Documents\report.pdf`
> - `movie.mp4` → `D:\FileArchive\Videos\movie.mp4`
> 共12个文件，确认执行归档到D盘吗？（回复「确认」开始）
用户：`确认`
Claude：
> ✅ D盘归档完成！
> - 成功移动：11个文件
> - 移动失败：0个文件
> 所有文件已按类型整理到D盘`FileArchive`目录，原目录空文件夹已清理。
