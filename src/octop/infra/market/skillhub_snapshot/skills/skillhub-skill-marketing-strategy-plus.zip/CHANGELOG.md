# 版本记录

## v1.0.2 (2026-08-07)

- 针对 SkillHub TRACE 评分短板全面升级，目标 4.9/5
- 新增快速开始、稳定性承诺、三条硬规矩（顶部）
- 输入收集改为「缺啥问啥」+ 默认值表，信息不全也能出框架
- 输出结构固定七大板块，新增各板块「最低深度」红线
- 异常处理升级为 8 种边界情况标准话术（exception-playbook.md）
- 新增信息缺失默认值表（default-values.md）
- 新增输出前 8 项自检清单（quality-checklist.md）
- 新增能力边界与组合使用指南（combination-guide.md）
- 新增 FAQ 与反模式（faq.md）
- 新增西安高新区完整案例（case-xian-example.md）
- 新增最小输入样例（examples/input-minimal.json）
- 强化 system-prompt.txt 的固定结构与格式一致性约束
- 升级文档示例，提升开箱即用度与本地化深度

## v1.0.1 (2026-08-05)

- 修正 description 触发词
- 优化输出格式

## v1.0.0 (2026-08-03)

- 首次发布
- 内置6种营销模型
- 支持完整营销策略框架生成
- 内置西安各区域地产市场数据
- 支持KPI量化指标和预算分配
