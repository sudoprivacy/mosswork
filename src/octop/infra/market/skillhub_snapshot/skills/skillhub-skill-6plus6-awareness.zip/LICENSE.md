Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International Public License

By exercising the Licensed Rights, You accept and agree to be bound by the terms
and conditions of this Creative Commons Attribution-NonCommercial-NoDerivatives
4.0 International Public License ("Public License").

The complete legal code of this license is available at:
  https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode

Human-readable summary:
  https://creativecommons.org/licenses/by-nc-nd/4.0/

Key terms (for reference only; the legal code at the URL above is authoritative):

  * Attribution (BY) — You must give appropriate credit, provide a link to the
    license, and indicate if changes were made.

  * NonCommercial (NC) — You may not use the material for commercial purposes.

  * NoDerivatives (ND) — If you remix, transform, or build upon the material,
    you may not distribute the modified material.

  * No additional restrictions — You may not apply legal terms or technological
    measures that legally restrict others from doing anything the license permits.

Copyright © 2026 意乐人生 · 归位校准体系 (《元我之学：觉察6+6》)
