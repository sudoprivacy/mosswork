#!/usr/bin/env node
/**
 * 制度审核要点表 · 服务端 X402 接入参考实现（微信支付 Agent Pay X402 协议）
 *
 * 本文件是「服务端接入」落点：把付费资源变成一个 X402 收费端点。零外部依赖（Node ≥ 16）。
 *
 * 协议行为（SkillHub 官方 X402）：
 *   ① 未付款  → HTTP 402
 *        响应头：WeixinPay-Required: <payment_code>   支付触发标识（一次性）
 *                X-Out-Trade-No:    <商户订单号>
 *        body ：{ error:'payment_required', amount, currency, skill, platform_error? }
 *   ② 已付款  → 携带 X-Out-Trade-No（以及原样回传的 WeixinPay-Required）重试原请求
 *        → 服务端向微信支付查单核验 trade_state=SUCCESS → HTTP 200 交付完整内容
 *
 * 下单链路（两步，顺序不可颠倒）：
 *   step1 传统微信支付下单   POST /v3/pay/transactions/native   → code_url
 *   step2 X402 协议下单      SkillHub 开发者密钥签名鉴权（SKILLHUB-SHA256-RSA2048）
 *                            pay_items 里放 step1 的 code_url → payment_code
 *
 * 密钥只从环境变量读，绝不写入仓库：
 *   SKILLHUB_DEV_PRIVATE_KEY_PEM  SkillHub 开发者 RSA2048 私钥（PEM 文本）
 *   SKILLHUB_DEVELOPER_ID         开发者 ID
 *   SKILLHUB_PUB_KEY_ID           开发者公钥 ID
 *   WXPAY_API_KEY_PEM             微信支付 API 私钥（apiclient_key.pem 文本）
 *   WXPAY_MCHID / WXPAY_SERIAL_NO / WXPAY_APPID / WXPAY_NOTIFY_URL
 *   PAID_CONTENT_PATH             付费内容文件（默认 ./assets/<slug>.md）
 *   UPSTREAM_URL                  付费内容不在本地时，回源到商户网关取回
 *   PORT                          监听端口（默认 8787）
 *   X402_MOCK=1                   仅联调协议链路，不真扣款
 *
 * 启动：node scripts/x402-server.mjs
 * 自测：curl -i http://127.0.0.1:8787/skill/account-persona-design
 */
import crypto from 'node:crypto';
import https from 'node:https';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SLUG = 'policy-audit-tool';
const DISPLAY = '制度审核要点表';
const PRICE = '1.00';

const __dirname_ = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname_, '..');
const ENV = process.env;
const MOCK = ENV.X402_MOCK === '1';
const PORT = Number(ENV.PORT || 8787);
const PREORDER_URL = 'https://payapp.weixin.qq.com/palmpayminiapp/clawagentpay/preorder';
const PREORDER_PATH = '/palmpayminiapp/clawagentpay/preorder';

const sha256Hex = (s) => crypto.createHash('sha256').update(s, 'utf8').digest('hex');
const nonce32 = () => crypto.randomBytes(16).toString('hex');
const genOrderNo = () => 'WX402_' + String(Date.now()).slice(0, 14).padStart(14, '0') + crypto.randomBytes(6).toString('hex').slice(0, 12);

function rsaSign(pem, payload) {
  const s = crypto.createSign('RSA-SHA256');
  s.update(payload, 'utf8');
  return s.sign(pem, 'base64');
}
function httpsRequest(method, urlStr, headers, bodyStr) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const r = https.request({ method, hostname: u.hostname, port: u.port || 443, path: u.pathname + (u.search || ''), headers: headers || {}, timeout: 12000 }, (res) => {
      let d = ''; res.on('data', (c) => { d += c; }); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: d }));
    });
    r.on('timeout', () => r.destroy(new Error('upstream timeout')));
    r.on('error', reject);
    if (bodyStr) r.write(bodyStr);
    r.end();
  });
}

/** 微信支付 v3 鉴权头 */
function wxAuthHeader(method, urlPath, bodyStr) {
  const pem = ENV.WXPAY_API_KEY_PEM || '';
  if (!pem) throw new Error('wxpay_api_key_missing');
  const timestamp = String(Math.floor(Date.now() / 1000));
  const nonce = nonce32().slice(0, 32);
  const message = `${method}\n${urlPath}\n${timestamp}\n${nonce}\n${bodyStr}\n`;
  return 'WECHATPAY2-SHA256-RSA2048 ' + [
    `mchid="${ENV.WXPAY_MCHID}"`, `nonce_str="${nonce}"`,
    `signature="${rsaSign(pem, message)}"`, `timestamp="${timestamp}"`,
    `serial_no="${ENV.WXPAY_SERIAL_NO}"`,
  ].join(',');
}

/** step1 传统微信支付下单（Native） */
async function wxNativeOrder(outTradeNo, amountYuan, description) {
  const payload = {
    appid: ENV.WXPAY_APPID, mchid: ENV.WXPAY_MCHID,
    description: String(description).slice(0, 120),
    out_trade_no: outTradeNo,
    amount: { total: Math.round(amountYuan * 100), currency: 'CNY' },
    notify_url: ENV.WXPAY_NOTIFY_URL || 'https://example.invalid/notify',
  };
  const body = JSON.stringify(payload);
  const res = await httpsRequest('POST', 'https://api.mch.weixin.qq.com/v3/pay/transactions/native',
    { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: wxAuthHeader('POST', '/v3/pay/transactions/native', body) }, body);
  if (res.status !== 200) throw new Error('wxpay_native_failed:' + res.status + ':' + res.body.slice(0, 200));
  return JSON.parse(res.body).code_url;
}

/** 查单核验：只有 trade_state=SUCCESS 才算真付款 */
async function wxQueryOrder(outTradeNo) {
  const urlPath = `/v3/pay/transactions/out-trade-no/${outTradeNo}?mchid=${ENV.WXPAY_MCHID}`;
  const res = await httpsRequest('GET', 'https://api.mch.weixin.qq.com' + urlPath,
    { Accept: 'application/json', Authorization: wxAuthHeader('GET', urlPath, '') }, null);
  if (res.status !== 200) return { paid: false, state: 'QUERY_FAILED' };
  const j = JSON.parse(res.body);
  return { paid: j.trade_state === 'SUCCESS', state: j.trade_state };
}

/** step2 X402 协议下单：换回支付触发标识 payment_code */
async function x402Preorder(slug, version, codeUrl) {
  const now = Math.floor(Date.now() / 1000);
  const l2 = {
    skill_info: { skill_id: slug, skill_version: version },
    pay_type: 'SKILL_PAY',
    pay_mode: 'AUTH_AND_PAY',
    pay_items: [{ product_id: 'SP' + now, pay_data: { type: 'code_url', value: codeUrl } }],
    expires_at: String(now + 600),
  };
  const paymentRequired = Buffer.from(JSON.stringify(l2), 'utf8').toString('base64');
  const timestamp = String(now);
  const nonce = nonce32().slice(0, 32);
  const pem = ENV.SKILLHUB_DEV_PRIVATE_KEY_PEM || '';
  if (!pem) throw new Error('skillhub_dev_key_missing');
  const signature = rsaSign(pem, ['POST', PREORDER_PATH, timestamp, nonce, paymentRequired, ''].join('\n'));
  const payload = JSON.stringify({
    signature_type: 'SKILLHUB-SHA256-RSA2048', developer_platform: 'SKILLHUB',
    developer_id: ENV.SKILLHUB_DEVELOPER_ID || '', pub_key_id: ENV.SKILLHUB_PUB_KEY_ID || '',
    nonce_str: nonce, timestamp, signature, payment_required: paymentRequired,
  });
  const res = await httpsRequest('POST', PREORDER_URL, { 'Content-Type': 'application/json', Accept: 'application/json' }, payload);
  if (res.status !== 200) throw new Error('x402_preorder_failed:' + res.status + ':' + res.body.slice(0, 300));
  const j = JSON.parse(res.body);
  const code = j.payment_code || (j.data && j.data.payment_code) || '';
  if (!code) throw new Error('x402_no_payment_code:' + res.body.slice(0, 200));
  return code;
}
function mockPaymentCode(orderNo, amountYuan) {
  const l2 = { out_trade_no: orderNo, amount: Math.round(amountYuan * 100), ttl: 600, skill: SLUG };
  return Buffer.from(JSON.stringify({ ...l2, signature: sha256Hex(JSON.stringify(l2)).slice(0, 32), signature_type: 'SKILLHUB-SHA256-RSA2048' })).toString('base64');
}

/** 交付：本地有内容读本地，否则回源商户网关 */
async function loadPaidContent(headers) {
  const p = ENV.PAID_CONTENT_PATH || path.join(ROOT, 'assets', SLUG + '.md');
  if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8');
  const up = ENV.UPSTREAM_URL || '';
  if (up) {
    const res = await httpsRequest('GET', up, headers, null);
    if (res.status === 200) return res.body;
    throw new Error('upstream_' + res.status);
  }
  throw new Error('paid_content_missing');
}

const json = (code, obj, extra) => ({
  statusCode: code,
  headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, extra || {}),
  body: JSON.stringify(obj),
});

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ ok: true, mock: MOCK, skill: SLUG })); }
  if (!/^\/skill\/[A-Za-z0-9_-]+\/?$/.test(url.pathname)) { res.writeHead(404, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ error: 'not_found' })); }

  const outTradeNo = req.headers['x-out-trade-no'];
  const weixinPayRequired = req.headers['weixinpay-required'];

  // ② 已付款路径：核验后交付
  if (outTradeNo) {
    try {
      const paid = MOCK ? true : (await wxQueryOrder(outTradeNo)).paid;
      if (!paid) {
        res.writeHead(402, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: 'payment_not_completed', out_trade_no: outTradeNo, retry_header: 'X-Out-Trade-No' }));
      }
      const content = await loadPaidContent({ 'X-Out-Trade-No': outTradeNo, ...(weixinPayRequired ? { 'WeixinPay-Required': weixinPayRequired } : {}) });
      res.writeHead(200, { 'Content-Type': 'text/markdown; charset=utf-8' });
      return res.end(content);
    } catch (e) {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'fulfill_failed', detail: String(e.message || e).slice(0, 200) }));
    }
  }

  // ① 未付款路径：两步下单 → 402 + 支付触发标识
  const orderNo = genOrderNo();
  let paymentCode = '', codeUrl = '', platformError = '';
  try {
    if (MOCK) {
      paymentCode = mockPaymentCode(orderNo, Number(PRICE));
      codeUrl = 'weixin://wxpay/mock?pr=mock' + orderNo;
    } else {
      codeUrl = await wxNativeOrder(orderNo, Number(PRICE), DISPLAY);
      try { paymentCode = await x402Preorder(SLUG, '1.0.0', codeUrl); } catch (e) { platformError = String(e.message || e).slice(0, 240); }
    }
  } catch (e) {
    res.writeHead(502, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: 'preorder_failed', detail: String(e.message || e).slice(0, 240) }));
  }

  const body = JSON.stringify({
    error: 'payment_required', skill: SLUG, amount: PRICE, currency: 'CNY',
    out_trade_no: orderNo, code_url: codeUrl, x402_preorder_error: platformError || undefined,
    WeixinPay: { tip: '请确认微信支付卡片完成支付；支付成功后重新请求本地址即可取回内容。', payment_code: paymentCode, out_trade_no: orderNo, retry_header: 'X-Out-Trade-No' },
  });
  res.writeHead(402, {
    'Content-Type': 'application/json; charset=utf-8',
    'WeixinPay-Required': paymentCode,
    'X-Out-Trade-No': orderNo,
  });
  res.end(body);
});

server.listen(PORT, () => {
  console.log(`✅ ${DISPLAY} X402 服务端已启动： http://127.0.0.1:${PORT}/skill/${SLUG}`);
  console.log(`   模式：${MOCK ? 'MOCK（不真扣款）' : '真实支付'}　单价：¥${PRICE}/次`);
  console.log(`   自测：curl -i http://127.0.0.1:${PORT}/skill/${SLUG}`);
});
