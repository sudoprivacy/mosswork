---
name: skillhub-skill-bili-main-kichiku
description: "当用户想按 B 站「鬼畜」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：鬼畜、B站分区、rid 119。"
---

# B 站分区 · 鬼畜

- 一级分区 rid：`119`；网页路由：`/v/kichiku/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 93 条榜单条目，覆盖 4 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 人力VOCALOID | 25 | 10 | 126 |
| 音MAD | 5 | 4 | 26 |
| 鬼畜剧场 | 38 | 8 | 216 |
| 鬼畜调教 | 25 | 10 | 22 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 人力VOCALOID

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 🐧准 备 咕 嘎🐧 | 贱歪 | [BV1yWZZYREsk](https://www.bilibili.com/video/BV1yWZZYREsk) | 140.1 万 |
| 【章鱼哥】“吹了百遍的竖笛，不解天赋的秘密” | 一个没有理想的理科生 | [BV1AxZdY2EeM](https://www.bilibili.com/video/BV1AxZdY2EeM) | 73.3 万 |
| ♿我学着 一个人 一辈子 一把米诺♿ | 大水母绚烂 | [BV1zhRqYUEq2](https://www.bilibili.com/video/BV1zhRqYUEq2) | 90.1 万 |
| ⚡阳 光 彩 虹 小 粑 粑⚡ | 夜雨星繁y | [BV1nHRkYcEvY](https://www.bilibili.com/video/BV1nHRkYcEvY) | 262.4 万 |
| High得我都想高歌一曲了！ | 暂离二度 | [BV17XZnY3E3q](https://www.bilibili.com/video/BV17XZnY3E3q) | 37.5 万 |

### 音MAD

数据来源：二级分区 7 日榜，可用 4 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “你说你不想再饿啊，我也不想再饿啊” | DJ_Kui | [BV192ZdYwEE9](https://www.bilibili.com/video/BV192ZdYwEE9) | 58.9 万 |
| 原声家庭🧊 | 枪弹轨迹 | [BV1BhZ9YeEYe](https://www.bilibili.com/video/BV1BhZ9YeEYe) | 94.6 万 |
| 用MC音效演奏《See You Again》，最难听懂的一次。 | 大不6仙 | [BV1LXRRYtEAe](https://www.bilibili.com/video/BV1LXRRYtEAe) | 39.8 万 |
| 你的天赋很强，背书过目不忘，两页的课文只需扫上几眼就能烂熟于心。脑子灵光，做题时的思路无比清晰不同寻常。 | Just渡亿特 | [BV1ZrZUYHERx](https://www.bilibili.com/video/BV1ZrZUYHERx) | 16.2 万 |

### 鬼畜剧场

数据来源：二级分区 7 日榜，可用 8 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 为什么西天取经唐僧不走直线？回答我！ | 修2 | [BV18fRXY1E1D](https://www.bilibili.com/video/BV18fRXY1E1D) | 257.5 万 |
| 甲亢哥 “突袭” 大张伟，英语词汇检测现场失控 | 白熊ONEヽ | [BV1mJZZYtEtE](https://www.bilibili.com/video/BV1mJZZYtEtE) | 147.4 万 |
| “小杰你会带我撤离的，对吧？” | RISEN瑞神 | [BV19tRSYuEyh](https://www.bilibili.com/video/BV19tRSYuEyh) | 296.9 万 |
| 恶搞之家风格《他们朝我扔白菜》 | 王与也行 | [BV1R3RCYdELg](https://www.bilibili.com/video/BV1R3RCYdELg) | 170.5 万 |
| 非诚勿扰：最没座的一集！ | 快乐阿依 | [BV1t3dnYHEy1](https://www.bilibili.com/video/BV1t3dnYHEy1) | 152.8 万 |

### 鬼畜调教

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| ⚡️ 建 议 发 到 外 网 宣 传 ⚡️ | 哦呼w | [BV1L2RXY9ERN](https://www.bilibili.com/video/BV1L2RXY9ERN) | 703.6 万 |
| 我自己剪的时候都没绷住 | 碧天蓝钻 | [BV1ERZoY1EV3](https://www.bilibili.com/video/BV1ERZoY1EV3) | 329.2 万 |
| 迅速找到你躲藏的地点 | Toaster_ok | [BV1riRXYhEHt](https://www.bilibili.com/video/BV1riRXYhEHt) | 132.0 万 |
| ☝🤓遛&狗⚡⚡⚡ | 去码头整点薯条vv | [BV1UYZ1YcE2N](https://www.bilibili.com/video/BV1UYZ1YcE2N) | 180.1 万 |
| 初 音 财 来 | 自动鬼畜中的WZ | [BV1ZXZnYgErz](https://www.bilibili.com/video/BV1ZXZnYgErz) | 123.4 万 |

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：教程演示（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=119." https://api.bilibili.com/x/web-interface/ranking/v2?rid=119&type=all. Accessed 6 Nov. 2026.
