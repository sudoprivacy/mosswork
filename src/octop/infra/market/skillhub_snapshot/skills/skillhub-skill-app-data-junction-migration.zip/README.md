# App Data Junction Migration

将 Windows 应用数据目录从系统盘（C盘）迁移到其他盘，软件无需重装、无感运行。

## 快速开始

1. 将 `scripts/migrate.bat` 中的 `SRC`、`DST`、`PROC` 三个参数改成你的实际路径
2. 完全退出目标软件（关窗口 + 系统托盘右键退出）
3. 双击 `migrate.bat`，按回车开始
4. 看到 `MIGRATION SUCCESS!` 即完成
5. 重开软件确认正常

或直接命令行调用：

```powershell
powershell -ExecutionPolicy Bypass -File scripts/migrate.ps1 `
  -SrcPath "C:\Users\name\AppData\Local\YourApp" `
  -DstPath "D:\AppData\YourApp" `
  -ProcessName "yourapp"
```

## 核心功能

- **robocopy /PURGE 增量同步**：只复制变化的文件，自动清理目标残留
- **robocopy /L 校验**：原生支持长路径，确保源目标完全一致
- **改名保留备份**：原目录改名为 `.migrated.bak`，不删除，可随时恢复
- **mklink /J 目录联接**：软件无感，所有读写经联接自动走目标盘
- **失败自动回滚**：任一步失败自动恢复，不丢失数据

## 触发方式

以下表述会触发本 Skill：
- "把 XX 软件的数据目录从 C 盘迁到 D 盘"
- "C 盘满了，迁移软件用户数据"
- "AppData 下的目录移到其他盘"
- "目录联接迁移 / junction migration"
- "软件装在 C 盘太占空间"

## 适合谁

- C 盘空间紧张，想把大型软件（微信、豆包、WorkBuddy、VS Code 等）的用户数据移到其他盘的用户
- 软件不自带数据目录迁移功能的场景
- 需要保留原路径兼容性（软件不改配置）的迁移需求

## 边界与注意事项

- **不适用于系统目录**（`C:\Windows`、`C:\Program Files`），需要管理员权限且可能影响系统稳定性
- **必须在软件完全退出后执行**，运行中文件被占用会导致改名失败
- **AI 不能直接执行最后一步**（杀进程会杀掉 AI 自身），必须由用户手动双击运行
- 目标盘可用空间需 > 源目录大小 × 1.2
- 迁移成功后，确认软件长期正常，再手动删除 `.migrated.bak` 备份释放空间

## 文件结构

```
app-data-junction-migration/
├── SKILL.md              # Skill 主文档（流程 + 10个踩坑记录）
├── README.md             # 本文件
├── CHANGELOG.md          # 版本更新记录
└── scripts/
    ├── migrate.ps1       # 参数化迁移脚本（PowerShell）
    └── migrate.bat       # 启动器模板（修改参数后双击运行）
```

## 回滚方法

如果迁移后软件异常：

1. 退出软件
2. 删除联接点 `C:\path\to\data`（只是联接，不删数据）
3. 将 `data.migrated.bak` 改回 `data`
4. 重开软件即可恢复
