# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-08-26

### Added
- 初始版本发布
- robocopy /PURGE 增量同步 + 清理目标残留
- robocopy /L 校验模式（原生支持长路径）
- 原目录改名保留为 `.migrated.bak` 可恢复备份
- mklink /J 目录联接，软件无感迁移
- 失败自动回滚机制
- 参数化 PowerShell 脚本（-SrcPath, -DstPath, -ProcessName, -BackupSuffix, -LogPath）
- bat 启动器模板
- 10 个实战踩坑记录：
  1. bat 文件必须用 CRLF 换行符
  2. bat 里嵌复杂 PowerShell 是转义地狱
  3. PowerShell 5.1 的 Junction 用 -Value 不是 -Target
  4. $ErrorActionPreference=Stop 与 robocopy stderr 冲突
  5. robocopy 退出码是位掩码，0-7 都是成功
  6. 校验用 robocopy /L 比 Get-ChildItem 可靠
  7. 多次未完成同步后目标有残留文件，必须 /PURGE
  8. 进程要循环等待完全退出，不能固定 sleep
  9. 脚本窗口必须显示进度，不能全重定向到日志
  10. 迁移必须在软件完全退出后由用户手动执行
- 完整的执行流程、验证方法、回滚方法文档
