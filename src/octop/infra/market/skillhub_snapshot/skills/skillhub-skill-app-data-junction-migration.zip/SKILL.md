---
name: skillhub-skill-app-data-junction-migration
description: "将 Windows 应用数据目录从 C 盘迁移到其他盘，采用 robocopy /PURGE 同步 + 改名保留备份 + mklink /J 目录联接方案，软件无感、数据可恢复。适用于软件C盘占空间、迁移 AppData 子目录、C盘满了迁移用户数据等场景。含 10 个实战踩坑记录，脚本经端到端测试。"
---

# App Data Junction Migration

将任意应用的数据目录从 C 盘迁移到其他盘，软件无需重装、无感运行。

## 核心方案

```
robocopy /E /COPY:DAT /PURGE  →  增量同步+清理目标残留
robocopy /E /L 校验            →  确认源目标完全一致
ren 源目录 源目录.migrated.bak →  原地改名保留可恢复备份
mklink /J 源目录 目标目录       →  建目录联接，软件无感
```

## 何时使用

- 用户说"XX软件C盘太占空间""把数据目录移到D盘""C盘满了"
- 需要迁移 `%LOCALAPPDATA%`、`%APPDATA%`、用户目录下的任意子目录
- 目标软件不自带数据目录迁移功能

## 执行流程

### 1. 前置检查（只读）

```powershell
# 确认源目录存在且不是联接
$item = Get-Item $SrcPath -Force
$item.LinkType  # 应为空，若是 Junction 则已迁移过

# 确认目标盘空间充足
# 确认要关闭的进程名（Get-Process 查看）
```

### 2. 生成迁移脚本

将 `scripts/migrate.ps1` 和 `scripts/migrate.bat` 复制到目标盘（如 `D:\migration\`），修改 bat 中的三个参数：

```bat
set "SRC=C:\Users\%USERNAME%\AppData\Local\DoubaoWork"
set "DST=D:\AppData\DoubaoWork"
set "PROC=doubao"
```

或直接命令行调用 ps1：

```powershell
powershell -ExecutionPolicy Bypass -File migrate.ps1 `
  -SrcPath "C:\path\to\data" `
  -DstPath "D:\path\to\data" `
  -ProcessName "appname"
```

### 3. 用户手动执行（关键！）

**AI 不能直接执行最后一步**，因为杀进程会杀掉 AI 自身运行环境。必须告知用户：

1. 完全退出目标软件（关窗口 + 系统托盘右键退出）
2. 双击 bat 启动器
3. 按回车开始，等待 5 步完成
4. 看到 `MIGRATION SUCCESS!` 才算完成
5. 重开软件确认正常

### 4. 迁移后验证

```powershell
# 验证联接
$item = Get-Item $SrcPath -Force
$item.LinkType          # 应为 "Junction"
$item.Target            # 应指向目标盘路径

# fsutil 验证
fsutil reparsepoint query $SrcPath
# 应看到 Reparse Tag Value: 0xa0000003 和 Print Name 指向目标

# 通过联接读取文件
Test-Path "$SrcPath\已知子目录"  # 应为 True

# 备份存在
Test-Path "$SrcPath.migrated.bak"  # 应为 True
```

### 5. 回滚方法（出问题时）

```powershell
# 1. 退出软件
# 2. 删除联接点（只是联接，不删数据）
Remove-Item $SrcPath -Force
# 3. 恢复备份
Rename-Item "$SrcPath.migrated.bak" (Split-Path $SrcPath -Leaf)
# 4. 重开软件
```

## 踩坑记录（必读）

以下是实际迁移过程中踩过的坑，每个都导致过失败或闪退。

### 坑1：bat 文件必须用 CRLF 换行符

**现象**：双击 bat 闪退，命令被截断（如 `robocopy` 变成 `bocopy`，`if exist` 变成 `xist`）。

**原因**：用 `Write` 工具或某些编辑器保存的文件默认是 LF（Unix 换行），Windows cmd 要求 CRLF。LF 导致 cmd 把相邻行连在一起解析。

**解决**：用 PowerShell 写入时显式用 `` "`r`n" `` 拼接，或用 `[System.IO.File]::WriteAllLines()`。写入后验证前几个字节应为 `0D 0A`。

```powershell
$lines = @('@echo off', '...', 'pause')
$content = $lines -join "`r`n"
[System.IO.File]::WriteAllText($batPath, $content, [System.Text.Encoding]::GetEncoding("GBK"))
```

### 坑2：bat 里嵌复杂 PowerShell 命令是转义地狱

**现象**：bat 中用 `powershell -Command "..."` 执行多行 PowerShell 脚本，管道符 `|`、引号、变量 `%VAR%` 互相冲突，解析失败。

**原因**：bat 的转义符是 `^`，但在双引号内 `^` 不生效；PowerShell 的管道符 `|` 在 bat 中会被当作命令管道。`^|` 在双引号外有效，双引号内被原样传给 PowerShell 导致语法错误。

**解决**：**永远不要在 bat 里嵌复杂 PowerShell**。分成两个文件：
- `migrate.bat`：5 行简单启动器，只做 `chcp` + `cd` + 调用 ps1
- `migrate.ps1`：所有逻辑写在独立的 PowerShell 脚本里

```bat
@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0migrate.ps1" -SrcPath "%SRC%" -DstPath "%DST%"
pause
```

### 坑3：PowerShell 5.1 的 New-Item Junction 用 -Value 不是 -Target

**现象**：`New-Item -ItemType Junction -Path $src -Target $dst` 在某些系统上报参数绑定错误。

**原因**：`-Target` 是 PowerShell 6+ (Core) 才引入的参数别名。Windows 自带的 PowerShell 5.1 用 `-Value`。

**解决**：**直接用 `cmd /c mklink /J`**，不依赖 PowerShell 版本，最可靠：

```powershell
$mklinkOutput = & cmd /c mklink /J "`"$SrcPath`"" "`"$DstPath`"" 2>&1
# 注意 PowerShell 中转义双引号用 `"
```

### 坑4：$ErrorActionPreference = "Stop" 与 robocopy stderr 冲突

**现象**：设置了 `$ErrorActionPreference = "Stop"` 后，robocopy 执行时脚本意外终止。

**原因**：robocopy 会把一些正常信息（文件正在使用的警告、额外文件提示）输出到 stderr。`2>&1` 把 stderr 重定向到 PowerShell 错误流后，在 `Stop` 模式下会触发终止错误。

**解决**：调用 robocopy 前后临时切换：

```powershell
$oldEAP = $ErrorActionPreference
$ErrorActionPreference = "Continue"
$output = & robocopy ... 2>&1
$rc = $LASTEXITCODE
$ErrorActionPreference = $oldEAP
```

### 坑5：robocopy 退出码是位掩码，0-7 都是成功

**现象**：robocopy 返回退出码 1 或 3，被误判为失败。

**原因**：robocopy 退出码是位掩码：
- `0x01` (1): 有文件被复制成功
- `0x02` (2): 目标有额外文件
- `0x04` (4): 有不匹配文件
- `0x08` (8): 有文件复制失败

**0-7 都是成功**，只有 `>= 8` 才是真正失败。

**解决**：`if ($rc -ge 8) { 失败 }`

### 坑6：校验用 robocopy /L 比 Get-ChildItem 更可靠

**现象**：用 `Get-ChildItem -Recurse` 遍历源和目标做文件比对，某些文件漏检。

**原因**：`Get-ChildItem` 默认不支持超过 260 字符的长路径（MAX_PATH），会静默跳过。应用缓存目录经常有超长路径。

**解决**：用 `robocopy /E /L`（list only 模式）做校验，robocopy 原生支持长路径：

```powershell
$verifyOutput = & robocopy $Src $Dst /E /L /NJH /NJS /NP /NS /NC /NDL /BYTES 2>&1
$vrc = $LASTEXITCODE
if ($vrc -ne 0) { 校验失败，有差异 }
```

注意：校验判断用 `$vrc -ne 0`，不要用 `$vrc -band 1`，因为"额外文件"是位1（值2），`-band 1` 检测不到。

### 坑7：多次未完成同步后目标有残留文件，必须 /PURGE

**现象**：前几次迁移尝试失败后，重新运行校验失败，报告源目标不一致。

**原因**：robocopy 默认不删除目标中源没有的文件。多次部分同步后，目标积累了源中已不存在的旧文件（软件运行产生又删除的临时文件）。

**解决**：robocopy 加上 `/PURGE` 参数，同步时删除目标中源没有的文件：

```powershell
robocopy $Src $Dst /E /COPY:DAT /PURGE /R:2 /W:1
```

`/PURGE` 是安全的，因为源是权威，目标只是副本。

### 坑8：进程要循环等待完全退出，不能固定 sleep

**现象**：固定 `Start-Sleep -Seconds 3` 后改名源目录失败，提示文件被占用。

**原因**：多进程架构的软件（如基于 Electron 的应用有十几个进程），3 秒不够所有进程完全退出并释放文件句柄。

**解决**：循环检测直到进程全部退出，有上限防止死循环：

```powershell
$killCount = 0
do {
    $procs = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $ProcessName }
    if ($procs) {
        $procs | ForEach-Object { Stop-Process -Force -Id $_.Id -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        $killCount++
    }
} while ($procs -and $killCount -lt 50)
Start-Sleep -Seconds 2  # 最后等句柄释放
```

### 坑9：脚本运行时窗口必须显示进度，不能全重定向到日志

**现象**：用户双击脚本后窗口"什么都没有"，以为卡住就关了。

**原因**：所有输出用 `>> log.txt 2>&1` 重定向到日志文件，窗口里只有最后一行 `pause`，用户看不到进度。

**解决**：关键步骤同时输出到窗口和日志。用 `Write-Host` 显示进度，`Write-Log` 函数同时写日志：

```powershell
function Write-Log($msg) {
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
    Add-Content -Path $LogPath -Value $line -Encoding Default
    Write-Host $msg
}
```

robocopy 不要加 `/NFL`（不显示文件列表），让用户看到正在复制哪些文件。

### 坑10：迁移必须在软件完全退出后由用户手动执行

**现象**：AI 直接执行迁移脚本，杀进程时把 AI 自身也杀掉了，或者软件运行中文件被占用导致改名失败。

**原因**：AI 运行在目标软件的环境中（如豆包的 Agent 模式），杀进程会连带杀掉 AI。软件运行时会持续写入数据目录，文件句柄被占用。

**解决**：AI 只负责生成脚本和前置检查，最后一步必须告知用户完全退出软件后手动双击执行。脚本内置进程复检，若同步期间用户重开软件则自动中止。

## 脚本参数说明

`scripts/migrate.ps1` 支持以下参数：

| 参数 | 必填 | 说明 |
|------|------|------|
| `-SrcPath` | 是 | 要迁移的源目录（通常在C盘） |
| `-DstPath` | 是 | 目标目录（通常在D盘） |
| `-ProcessName` | 否 | 要关闭的进程名模式（正则匹配），如 `doubao`、`workbuddy` |
| `-BackupSuffix` | 否 | 备份后缀，默认 `.migrated.bak` |
| `-LogPath` | 否 | 日志路径，默认在目标目录同级 |

## 不适用场景

- 迁移系统目录（`C:\Windows`、`C:\Program Files`）——需要管理员权限且可能影响系统稳定性
- 软件正在运行且无法退出——必须先退出
- 目标盘空间不足——确保目标盘可用空间 > 源目录大小 × 1.2
