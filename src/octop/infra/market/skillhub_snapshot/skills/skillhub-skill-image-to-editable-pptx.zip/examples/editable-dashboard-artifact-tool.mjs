import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { Presentation, PresentationFile } from "@oai/artifact-tool";

const {
  SKILL_DIR,
  TMP_DIR,
  FINAL_PPTX,
  RUNTIME_NODE,
  RUNTIME_NODE_MODULES,
  RUNTIME_BIN_DIR,
  RUNTIME_PYTHON,
  ICON_PATH,
  RECONSTRUCTION_SKILL_DIR,
} = process.env;
const workspaceDir = process.cwd();
for (const [name, value] of Object.entries({
  SKILL_DIR,
  TMP_DIR,
  FINAL_PPTX,
  RUNTIME_NODE,
  RUNTIME_NODE_MODULES,
  RUNTIME_BIN_DIR,
  RUNTIME_PYTHON,
  RECONSTRUCTION_SKILL_DIR,
})) {
  if (!path.isAbsolute(value ?? "")) throw new Error(`Set absolute ${name}`);
}

const { resolvePresentationFont, finalizePresentation } = await import(
  pathToFileURL(path.join(SKILL_DIR, "container_tools/artifact_tool_utils.mjs")).href,
);
const { assertTextBoxBudget } = await import(
  pathToFileURL(path.join(RECONSTRUCTION_SKILL_DIR, "scripts/text_box_budget.mjs")).href,
);
await fs.mkdir(TMP_DIR, { recursive: true });
const family = resolvePresentationFont();

const presentation = Presentation.create({ slideSize: { width: 1600, height: 900 } });
const slide = presentation.slides.add();
slide.background.fill = "#EAF8FC";

function addShape(geometry, position, fill, line = { fill: "none", width: 0 }) {
  return slide.shapes.add({ geometry, position, fill, line });
}

function addText(value, position, fontSize, color, bold = false) {
  assertTextBoxBudget(value, position, fontSize, { bold });
  const box = addShape("textbox", position, "none");
  box.text = value;
  box.text.style = {
    typeface: family,
    fontSize,
    bold,
    color,
    autoFit: "none",
  };
  return box;
}

function addProgress(x, y, width, ratio, color) {
  addShape("roundRect", { left: x, top: y, width, height: 12 }, "#DCECF3");
  addShape("roundRect", { left: x, top: y, width: width * ratio, height: 12 }, color);
}

async function addIndependentPng(filePath, unusedPosition, alt) {
  const metadata = JSON.parse(await fs.readFile(filePath + ".json", "utf8"));
  const { sourcePlacement } = await import(pathToFileURL(path.join(RECONSTRUCTION_SKILL_DIR, "scripts/source_placement.mjs")).href);
  const position = sourcePlacement(metadata.source_box, metadata.source_size, [1600, 900]);
  const bytes = await fs.readFile(filePath);
  const picture = slide.images.add({
    blob: new Uint8Array(bytes),
    contentType: "image/png",
    alt,
    fit: "contain",
    position,
  });
  picture.lockAspectRatio = true;
  return picture;
}

function addPanel(x, title, accent, rows) {
  addShape("roundRect", { left: x, top: 148, width: 760, height: 700 }, "#F7FDFF", {
    fill: accent,
    width: 3,
  });
  addShape("roundRect", { left: x + 10, top: 158, width: 740, height: 74 }, accent);
  addText(title, { left: x + 42, top: 176, width: 400, height: 48 }, 34, "#FFFFFF", true);
  for (const row of rows) {
    addShape("roundRect", { left: x + 26, top: row.y, width: 708, height: 112 }, "#FFFFFF", {
      fill: "#CDEAF4",
      width: 2,
    });
    addText(row.label, { left: x + 54, top: row.y + 18, width: 180, height: 36 }, 25, "#0A3656", true);
    addText(row.current, { left: x + 245, top: row.y + 40, width: 140, height: 34 }, 26, accent, true);
    addProgress(x + 245, row.y + 82, 140, row.ratio, accent);
    addText(row.previous, { left: x + 405, top: row.y + 42, width: 125, height: 32 }, 22, "#4A7190");
    addText(row.change, { left: x + 545, top: row.y + 44, width: 135, height: 34 }, 25, row.change.startsWith("+") ? "#F46D24" : "#159447", true);
  }
}

addText("Monthly Energy Use", { left: 120, top: 38, width: 720, height: 72 }, 50, "#0A4F91", true);
addText("Editable dashboard reconstruction example", { left: 124, top: 104, width: 620, height: 30 }, 20, "#2A7197");

const leftRows = [
  { y: 260, label: "Water", current: "1,513", previous: "2,110", ratio: 0.72, change: "-28.29%" },
  { y: 392, label: "Electricity", current: "219,345", previous: "276,509", ratio: 0.79, change: "-20.67%" },
  { y: 524, label: "Gas", current: "49,676", previous: "60,675", ratio: 0.82, change: "-18.13%" },
  { y: 656, label: "Steam", current: "59", previous: "72", ratio: 0.82, change: "-18.06%" },
];
const rightRows = [
  { y: 260, label: "Water", current: "2,219", previous: "2,312", ratio: 0.96, change: "-4.02%" },
  { y: 392, label: "Electricity", current: "389,884", previous: "365,440", ratio: 1, change: "+6.69%" },
  { y: 524, label: "Gas", current: "50,045", previous: "46,706", ratio: 1, change: "+7.15%" },
  { y: 656, label: "Steam", current: "98", previous: "98", ratio: 1, change: "0.00%" },
];

addPanel(18, "Production Line A", "#1689D8", leftRows);
addPanel(822, "Production Line B", "#31B66A", rightRows);
if (ICON_PATH) {
  if (!path.isAbsolute(ICON_PATH)) throw new Error("ICON_PATH must be absolute when provided");
  await addIndependentPng(
    ICON_PATH,
    null, // use measured source metadata, never a fixed square
    "independently cropped source icon",
  );
}
slide.speakerNotes.textFrame.setText("Illustrative values for the bundled Artifact Tool example only.");

const candidatePath = path.join(TMP_DIR, "editable-dashboard-candidate.pptx");
await (await PresentationFile.exportPptx(presentation)).save(candidatePath);
await fs.mkdir(path.dirname(FINAL_PPTX), { recursive: true });

await finalizePresentation({
  explicitTotalSlideCount: 1,
  requiredNativeTableOwnerSlides: [],
  requiredNativeChartOwnerSlides: [],
  workspaceDir,
  candidatePath,
  finalPath: FINAL_PPTX,
  pythonExecutable: RUNTIME_PYTHON,
  integrityValidatorPath: path.join(SKILL_DIR, "container_tools/inspect_presentation_package_integrity.py"),
  layoutValidatorPath: path.join(SKILL_DIR, "container_tools/inspect_presentation_layout_geometry.py"),
  layoutArgs: ["--expected-slide-size-emu", "15240000,8572500", "--validate-heading-fit"],
  fontPolicy: { basis: "design", families: [family] },
  verifyArtifactToolImport: true,
  receiptPath: path.join(TMP_DIR, `${path.basename(FINAL_PPTX)}.validation.json`),
});
