# 冷链设备巡检看板示例

左侧是 960 × 540 的原图，右侧是生成的 PPTX 经过 LibreOffice 真实渲染后的效果。

![左为原图，右为可编辑 PPTX 的真实渲染](measured-demo/side_by_side.png)

| 文件 | 可以检查什么 |
| --- | --- |
| [source.png](measured-demo/source.png) | 示例原图，由独立制作的演示页导出为截图，数字为演示数据 |
| [editable-demo.pptx](measured-demo/editable-demo.pptx) | 可编辑结果。可以改标题或数字，也可以单独拖动绿色进度条并修改阴影 |
| [rendered.png](measured-demo/rendered.png) | 从生成的 PPTX 导出的真实渲染图 |
| [layout.json](measured-demo/layout.json) | 源图的测量坐标、字体、图形和对象清单 |
| [verification.json](measured-demo/verification.json) | 实测单页和合并版的验收结果 |

样例从截图和测量布局生成，包含 10 个独立文本框与 7 个独立原生图形。结构、17 个对象的坐标和单页及合并版视觉检查均通过。截图和复核使用同一 LibreOffice 环境，这个结果用于演示验收流程。处理实际截图时，字体替换、原图压缩和复杂图形会影响视觉差异。

## 复现

从技能包目录执行。

```bash
python scripts/preflight.py --plain
python scripts/batch_convert.py --manifest examples/measured-demo/jobs.json -o demo-output --ocr none --json
```

可用 `demo-output/combined.pptx` 打开编辑。样例指定 Droid Sans Fallback 和 DejaVu Sans。未安装相同字体或缺少真实渲染时，仍可导出 PPTX，报告可能显示 `needs_review`。换字体后请复核中文换行、字宽和基线，已附的真实渲染图可作为对照。

需要处理照片底、表格和发光框时，参照 [复杂页原位校准](../references/complex-page-calibration.md)。包内 [Artifact Tool 示例](editable-dashboard-artifact-tool.mjs) 对应另一路径，使用条件见 [兼容流程](../references/artifact-tool-workflow.md)。
