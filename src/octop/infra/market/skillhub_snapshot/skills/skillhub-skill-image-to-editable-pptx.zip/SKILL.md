---
name: skillhub-skill-image-to-editable-pptx
description: "将截图、海报、组织架构、信息图、仪表盘或多张图片逐页还原成可编辑 PowerPoint。用户提到图片转PPT、截图还原、批量还原或要编辑原图中的文字、图标和箭头时使用。 Supports image-to-editable PowerPoint reconstruction, batch conversion, dense Chinese text, complex photo backdrops, and rendered visual QA."
---

# 图片转可编辑 PPT · 1.0.10

把图片作为坐标与内容依据。保留原布局、文字、数据、比例和层级；不擅自重新设计。代理负责修正直到成品可用，不把 layout 编写、错字核对、字体替换或 PPT 调整转交用户。
支持多图片、多页合并、逐图单独导出，以及复杂图文页面的分层重建。

## 触发与入口

- 用户上传图片后可说「把这张截图还原成可编辑 PPT，保留原图布局和中文」。
- 多图可说「按上传顺序逐图还原，分别导出并合成一份 PPT；照片可单独移动，箭头能编辑」。
- [安装、三步试跑和能力边界](README.md) · [原图、真实渲染与可编辑样例](examples/README.md) · [命令和参数](references/cli.md) · [常见报错与修复](references/faq.md)。

## 必须拆分图片和图标

先读 [非文字对象拆分与验收](references/visual-decomposition.md)。默认要求文字、图片、图标、箭头、边框分别可选中与修改。照片提取为独立图片；简单图标重建为原生路径，保留颜色、比例和轮廓；复杂插画/商标作为独立透明图片时明确说明路径不可编辑。禁止只移除文字后把全部视觉内容留在整页底图。

逐区建立源图 `visual_inventory`，每个可移动对象记录 kind、source_box、treatment、objects、reviewed。填写清单后逐项映射至最终 PPT 的实际对象。背景必须同时移除文字和独立前景照片、图标、边框、箭头，并设置 visual_objects_removed:true。检查单独底图，再在验证副本移动/隐藏前景确认原位置无重复残影。

缺少非文字清单、清单未复核、前景仍留在底图或对象映射不完整时禁止交付为完成品。不能以文字对象数量、整体外观相似或 review.inventory_complete:true 替代非文字检查。单张图片同样执行完整分层流程。

## 首先分清输出与验收

- 默认逐图生成 `editable.pptx`；所有输入均导出后才生成合并 `combined.pptx`，按上传顺序。缺页时先补齐；只有用户明确要部分草稿时使用 `--allow-partial-merge`。目录输入按数字自然排序（2 在 10 前）。
- 一份 PPT 的所有页只能共享一个页面尺寸。合并时采用首张成功导出的图片比例，其他比例等比留边；需要每张原尺寸时使用单页文件。不得拉伸或裁掉内容。
- `needs_layout` 表示还需分层，`needs_review` 表示已导出但未验证，`verified` 才表示单页结构、人工文字清单、OCR 疑点清零和真实 Office 渲染均通过。失败图片写入清单，保留原输入编号，不悄悄漏页。
- 自带 Pillow 渲染只检查几何位置，不能验证 Office 的字形、渐变字、发光、阴影、自由形状。绝不能因此声称“视觉还原通过”。
- 脚本返回 2 是“需要继续处理”，不是任务结束。作为代理，必须继续补齐清单、修正文字/素材与布局，重跑导出。无法完成真实渲染时如实说明成品尚待 Office 复核。
- `verified` 仍需代理亲自打开逐页并排图，检查文字、细线、照片边缘与溢出。报告为 `needs_review` 时先依据 `comparison.tile_alerts.worst` 与 `comparison.regions` 修正，再重新生成；不能让用户完成这些步骤。

## 批量入口

两张及以上图片在默认 `auto` 模式下，先为每张未测量图片准备原尺寸源图、放大阅读块和独立清单。由代理逐页完成单图级重建，再续跑导出。图片数量增加时保持每页同样的阅读、测量和修复步骤。单张图片也先准备清单和测量。可用 `--mode layered` 显式选择分层，`--mode editable` 仅用于用户明确需要自动粗稿的情况。

包内构建器用 python-pptx 读写对象。宿主提供 Presentations 渲染能力时，也可用于真实渲染与交付；直接使用包内脚本时按预检结果选择本地或外部 Office 渲染。

```bash
python scripts/batch_convert.py image1.png image2.png image3.jpg -o build --json
python scripts/batch_convert.py images/ --recursive -o build --json
python scripts/batch_convert.py --manifest jobs.json -o build --resume --json
```

运行 `python scripts/preflight.py --plain` 检查基础转换、可选 OCR 和真实渲染。缺少 OCR 时加 `--ocr none`，代理从逐页阅读块转录；单张也可加 `--prepare-only` 进入测量流程。准备阶段返回 `needs_layout` 和退出码 2 后，立即读取 `work-queue.json` 继续处理，不把它当作用户需要自行补完的交付物。

`orchestrate.py` 默认转发给批量入口，`--legacy-single` 用于旧单页调试。清单格式、续跑和合并参数见 [命令和参数](references/cli.md)。真实渲染失败时保留已导出的单页文件，报告待核对与修复动作。检测到 Office 渲染器时会再次渲染合并文件，输出 `combined-review` 逐页对比。

## 多张复杂图的执行顺序（必须完成的代理工作）

1. 先校验全部附件的可读性、EXIF、尺寸和上传顺序；原图文件必须完整解码。不可读时通过当前附件 ID 重新获取，不复用过期路径，不吞掉坏文件。
2. 批量入口为每页建立独立目录。读取 `work-queue.json`，一次只把当前页作为重建对象，完成“打开原图和全部阅读块 → 记录各区文字及对象 → 测量 → 分层构建 → 实际渲染 → 局部修复”。进入下一页时重新打开该页原图；内容、坐标与验收结论均来自该页。联系表只用于核对顺序。
3. 复杂页的 `needs_layout` 只是 OCR 与检查素材准备完毕，**没有生成可用 PPT**。由代理继续填写该页 `layout.json`，素材置于该页 `crops/`。不得告诉用户自己写 JSON、调整 PPT，或把 `needs_layout` 当成交付。
4. 改好一页后，优先用 `--manifest build/continue.json --resume`。若原 manifest 显式指定 `layout`，该路径始终是权威输入；必须编辑队列指向的原布局，不能只改导出副本后又读取旧布局。无显式布局时也可用原始完整输入列表加 `--resume`。`continue.json` 保持原输入编号及失败页；不能只取成功页重新编号。复用的仅是每页输入、资产和环境都未变的成果。
5. 读取每页 `repair-tasks.json`：先核对错字/数字/表格，再修位置、字体、连接线及发光。任务中的坐标都属于该页原始像素。完成下一次导出后重新查看局部对比，不借别页的低误差放行本页。
6. 共享字体和视觉样式可以复用，文字内容、框坐标、对象清单、检查结论必须逐页独立。参考 [密集多页工作流](references/dense-batch-workflow.md) 建表格、图表与辐射关系图的清单。
7. 每轮核对 `input_count`、`exported_count`、`pending_count` 和 `pending_indices`。全部页导出后，重新渲染合并文件并检查顺序、漏页、缩放及字体。任一页仍有问题就继续修复该页。明确资源阻塞时说明具体页码与未完成步骤，不能声称“保证无需人工调整”或“100%还原”。

## 每张图都先看，不根据文件名猜

1. 打开每张图片，读实际尺寸，尊重 EXIF 方向。对小字区域放大检查；多图先做缩略联系表，但仍逐图复核。
2. 区分纯色图表页与复杂图文页。脚本 `auto` 的颜色/边缘分析只是分流提示。复杂度不确定时走分层流程。
3. 简单图的自动识别只能用于显式粗稿；正式转换仍须逐项核对视觉清单。图1一类“工厂照片底 + 大量中文 + 人像 + 发光切角框”的图必须分层，不走平坦区域全图分割。
4. 所有图片均先准备源文件，检查存在性。上传路径失效时用附件 ID 重新下载，不在缺文件时编造转换结果。
5. 对目标字体先检查运行环境是否安装，优先用源字体；中文回退字体必须以最终实际渲染后的字宽、行距和换行复核。把文字框对齐到原图容器，别只按 OCR 墨迹框估位置。

## 复杂图片：先清单、再按层重建

遇到照片底、霓虹边框、密集表格、混合字号或大量图标时，先读 [复杂图原位校准](references/complex-page-calibration.md)。采用 `precision_mode: measured`，对象全部命名，文字使用测量容器。图标/照片裁剪 metadata 中的 `source_box` 必须传入 layout；构建器按原位置和原尺寸插入并验证素材画布。结构报告新增 `geometry`：逐对象核对坐标与尺寸，最大允许误差 0.5 个源图像素；检查未覆盖项列在 `unchecked`。这个检查只证明对象框与测量稿一致，字形、基线和测量稿本身仍须对照源图与真实渲染。

读 [复杂页面与背景保留](references/complex-pages.md) 及 [布局字段](references/layout-schema-v110.md)。遇到五张指标卡、五步流程、底部图表并存的工业霓虹页，另读 [高密度霓虹数据页](references/dense-neon-dashboard.md)。

### A. 测量与文字

- 使用 `scripts/tiled_ocr.py source.png -o texts.json`：整图识别 + 720px 重叠分块两倍放大识别，坐标映射回原图；右侧/底部使用完整尾块，较小页面也做放大识别。相同文字只在同一空间位置去重，相邻表格中相同内容仍独立保留。
- 批量入口在 `needs_layout` 时自动生成 `review-tiles/`；即使缺中文 OCR，也打开 `index.png` 和各 `tile-*.png` 逐区读取。单独运行可用 `python scripts/inspect_dense.py source.png -o review-tiles`，`tiles.json` 提供每块源图坐标。放大块只用于检查，绝不插入 PPT。
- 人工核对人名、数字、百分号、单位、脚注、换行。OCR 替代候选、低置信文字必须回到原图确认。不得自动挑一个人名当作正确答案。
- 为标题、负责人、成员区、分工区、会议区、指标区等建立 `regions`；每区都要有对应对象清单。
- 分块 OCR 只是辅助，合并/拆分文本块仍需要视觉复核。文字保持原内容，普通文字/姓名标签不得保留在图片里。
- 对每条 OCR 的 `alternatives` 与 `needs_review` 逐条处理，核对后修正 `text`，再删除 `needs_review` 标记；仅设置页级 `review.text_verified` 不会使未解决疑点通过。
- 先按 100% 源图像素测量盒子，再估字号。相似字体替换时以中文实际字宽和换行比对，必要时逐段设置 `font_name` 与 `size_pt`，不要靠放大文本框掩盖字体不匹配。细则见 [精度测量与局部复核](references/precision-qa.md)。

### B. 背景与视觉资产

- **不再强制整图去背景，不自动删除浅色背景装饰。** 旧版从像素色差推透明度的下界不足以判断元素可以删除；仅用户明确要求简化时才启用旧过滤。
- 纯色/线性渐变背景、卡片、边框、分隔线、连线均为原生对象。
- 工厂环境、照片、复杂插画可保留为独立栅格素材，但可辨识的主标题/姓名/数字/表格内容必须移出成为原生文字。
- 需要全幅照片底时，使用无前景文字/图框的干净背景资产，记录 `role: clean-background, contains_text: false, reviewed: true`。若没有干净底图，先用图像编辑能力移除前景并逐区复核。图片工具不可用时标记缺背景，不能改成纯色后声称还原。
- 程序逐个检查文字区域与干净底图的像素变化；底图仍含原文字时会报错。报错后修复底图，不通过换文件名或涂盖图层绕过。
- 被文字/卡片遮住的背景像素无法从单张图片精确恢复。重建区域要说明是修复，不保证原始隐藏像素一致。
- 不允许把原图直接作为底图，再覆盖可编辑文字；不能用页面切片规避。干净背景的声明不是自动证明，必须放大检查是否残留旧字/旧框。
- 图片面积限制按语义：真实大幅照片/干净背景可以超过旧版 15%/30% 限制；图表、表格、文字卡片、整页截图仍禁止栅格化。
- 独立人像/照片保留原像素与比例；抠图只在视觉需要时进行。纯色图标优先原生路径重建；仅明确例外才保留独立透明素材，复杂背景不要用全图阈值强行抠除。

### C. 原生对象

- 使用 `polygon` 重建切角框，`line` 重建组织架构分叉；连接端点、线宽、箭头方向均按源图。
- 支持形状 `glow`/`shadow`；文本 `text_grad`、`outline`、`glow`、`shadow`、`italic`、逐对象 `font_name`。不要把霓虹边框简化成单层普通矩形。
- 混合字号/颜色使用原生 `spans` 与固定 `line_spacing_pt`；保留小数坐标，直到写入 EMU 才取整。测量与写入使用同一实际字体，参照 [混排、字体和坐标精度](references/precision-v140.md)。
- 量准字体时用 `box_mode: frame` 和 `size_pt`：框表示实际文本容器，禁止再按 OCR 墨迹框重新拟合。自动 OCR 初稿可用原来的 ink-fit。
- 字体不可用时使用合适的中文字体并记明替换，检查最终换行。不要用英文字体测量后声称中文完全一致。
- 对象独立、命名且按 z 排序；旋转/透明度要保留。裁图时参照 `references/crop-placement.md` 保持真实 source_box。

### D. 填完 layout 再运行

```bash
python scripts/batch_convert.py --manifest jobs.json -o build --resume --json
```

填写 `review.inventory_complete`、`review.text_verified` 和 `review.visual_inventory_verified` 只能发生在实际检查之后。
结构检查会检查 layout 中每条文字与 PPT 对象；它无法证明 layout 没有漏抄源图，必须由人工/代理核对源图补全。

## 验收闭环

1. 检查每张输入都有报告条目；合并页码与源文件一一对应，失败图片明确列出。
2. 校验素材存在、尺寸匹配、每段文字可编辑、对象名称与数量吻合、对象不越界。素材缺失时直接报错，不偷偷截取源图占位。
3. 使用真实 PowerPoint/LibreOffice/WPS 或 Presentations 技能可用的最终 PPT 渲染器渲染。脚本可自动探测 LibreOffice/soffice 与 pdftoppm。
4. 比较整页、手工 region 和每个文字/图形/图片的局部差异，生成并排图和差异图。局部项目未通过时不能用较低的整页 RMS 放行；小字、人名、连线、照片裁切仍需逐项目视确认。
   重叠的 48px 网格用于定位漏列的小标签与细线，文字对象还检查像素不匹配比例和边缘召回。查看 `comparison.tile_alerts.worst` 的坐标，按误差从高到低修复。
5. 原生发光/文字特效缺少真实渲染验证时报告 `needs_review`。不放宽阈值来制造通过，不用代码预览替代最终文件。
6. 对合并后 PPT 再次实际渲染并逐页查看；尤其检查跨尺寸页的字、线宽与素材比例。
7. 交付 PPT 并简短说明：原生可编辑部分、保留为图片的部分、字体/背景修复的差异、尚未完成的验证。

本机没有 LibreOffice 时，用 Presentations 技能或实际 PowerPoint/WPS 将**最终 PPTX**逐页渲染为图片。对每张原图和对应渲染图运行：

```bash
python scripts/qa_external_render.py source.png rendered.png layout.json editable.pptx -o qa/page-01
```

它复用局部精度与结构门槛，并输出 `qa-report.json`、并排图、差异图。修复后重新导出并再检查独立版与合并版。若没有任何真实 Office 渲染器，不以几何预览放行“可直接使用”。

## 维护与旧工具

- `build_pptx_from_layout.py` 继续支持旧 schema。`--strict-assets` 禁止缺失素材时临裁；批量入口强制启用。
- `remove_background.py` / `audit_transparency.py` 仅用于需要透明背景的独立对象，不是每个页面的必经步骤。
- 旧 `verify_reconstruction.py` 专用于旧“透明前景重建”验收，不能用它的背景删除/面积上限验证新照片底图模式。
- `render_offscreen.py` 仍是几何诊断工具，未覆盖所有新的 DrawingML 效果。
- 用 `python -m pytest -q` 运行完整回归（需要 pytest）；`unittest discover` 不覆盖本包全部测试。测试通过只说明程序行为通过，不等于某批原图已完成视觉还原。

辅助测量：`measure.py` 与 `pick_color.py` 量坐标/取色，`audit_icons.py` 检查素材比例与裁切，`complexity.py` 为手工元素清单打分；自动识别由 `describe_image.py` 完成。这些工具不替代视觉验收。
