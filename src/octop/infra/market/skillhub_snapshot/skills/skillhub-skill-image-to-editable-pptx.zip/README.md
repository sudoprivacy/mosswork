# 图片转可编辑 PPT

上传截图、海报、组织架构图或数据看板，逐页按原图重建。可交付单页 PPTX 和按原顺序合并的 PPTX。

## 在技能平台使用

在平台的技能导入入口选择本 ZIP。若入口要求选择目录，解压后选择含有 `SKILL.md` 的目录，并保留 `scripts/`、`references/` 和其他随附文件。运行环境需要能读取上传的图片并执行 Python 脚本。

上传图片后可以这样说。

> 按上传顺序把这些截图还原成可编辑 PPT。保留原图布局、中文和数据，每张单独导出，再合成一份。请核对真实渲染效果。

技能负责读图、逐项测量、重建和复核。看到 `needs_layout` 时，由技能继续整理文字、坐标和素材。已有成品的效果可直接看 [原图、渲染对照与可编辑示例](examples/README.md)。

## 本地三步试跑

在解压后的技能目录运行。使用 Python 3.10 或以上版本，三步应使用同一个 Python 环境。

```bash
python -m pip install -r requirements-core.txt
python scripts/preflight.py --plain
python scripts/batch_convert.py --manifest examples/measured-demo/jobs.json -o demo-output --ocr none --json
```

打开 `demo-output/combined.pptx` 和 `demo-output/batch-report.json`。示例含已测量布局，可直接导出。如果只有基础依赖，仍会生成 PPTX 和几何预览，并标记 `needs_review`。要走自动真实渲染，把 LibreOffice/soffice 和 Poppler 的 `pdftoppm` 加入 PATH。样例使用的字体见 [示例说明](examples/README.md)。

| 需要的能力 | 安装或准备 |
| --- | --- |
| 读图、生成放大阅读块、按布局导出 PPTX | `requirements-core.txt` 中的 Pillow、NumPy、python-pptx |
| 本地中文 OCR 与自动粗稿 | `python -m pip install -r requirements.txt`，安装基础依赖和 RapidOCR。`--require-ocr` 可单独检查 |
| 真实渲染与逐页差异 | PATH 中的 LibreOffice/soffice 和 `pdftoppm`。可用 `--require-render` 检查。也可用 PowerPoint/WPS 导出图片，再运行外部渲染复核 |

转换、OCR 与比较在运行环境本地完成。首次安装依赖需要可访问的软件源或预先准备好的离线安装包。版本以 `_meta.json` 为准，运行 `python scripts/batch_convert.py --version` 可核对当前包。

## 能力边界

| 对象或场景 | 交付方式 | 需要核对 |
| --- | --- | --- |
| 标题、中文段落、数字与单位 | 原生文本框，支持分段样式和原位校准 | OCR 候选、小字、换行和缺失字体由逐区复核解决。识别不清的内容需标注 |
| 表格、图表、卡片、边框、箭头和简单图标 | 用可编辑文字、形状、路径和连线重建 | 图片无法提供图表的源数据表、原字体文件或原始矢量路径，按可见内容重建 |
| 照片、复杂插画和商标 | 独立图片对象，可移动、替换和等比缩放 | 图片内部像素保留为栅格。使用栅格图标例外时，记录理由与编辑边界 |
| 复杂照片底图 | 使用已清除前景的底图，再叠加独立对象 | 被遮住的背景像素需要修补。逐区检查文字、图标和边框残影 |
| 多页与混合尺寸 | 单页保留原图比例，合并文件共用一个画布，其他比例等比留边 | 依照原顺序复核。缺页时补齐后再合并，部分草稿由显式参数生成 |
| 源文件格式 | 目录/通配符筛选 PNG、JPEG、WebP、BMP、TIFF，单张显式路径由 Pillow 解码 | 单张源图对应一页。多帧图需拆开，按 EXIF 方向归一化后再测量 |
| 还原验证 | 结构、文字清单、对象几何、局部差异和真实渲染 | Pillow 只做几何预览。字体、发光、渐变和小字以实际渲染及逐项对照为准 |

日常转换见 [主流程](SKILL.md)。需要指定顺序、画布、字体或续跑时看 [命令和参数](references/cli.md)。遇到报错或结果异常时看 [常见问题](references/faq.md)。复杂页按 [原位校准](references/complex-page-calibration.md) 和 [对象清单验收](references/visual-decomposition.md) 逐项处理。
