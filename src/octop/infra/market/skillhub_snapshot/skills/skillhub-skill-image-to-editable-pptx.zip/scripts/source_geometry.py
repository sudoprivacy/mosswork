"""Source-pixel placement and exported-object geometry checks (not glyph QA)."""
import math

EMU = 9525


def box_values(value):
    box = [value[k] for k in ('x', 'y', 'w', 'h')] if isinstance(value, dict) else list(value)
    if len(box) != 4 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in box):
        raise ValueError('Invalid source_box/box coordinates')
    return box


def image_box(element, asset_size, source_size):
    mode = element.get('placement', 'source' if element.get('source_box') is not None else 'contain')
    if mode not in ('source', 'contain'):
        raise ValueError('Image placement must be source or contain')
    if mode == 'source':
        if element.get('source_box') is None:
            raise ValueError('Source placement requires source_box from crop metadata')
        x, y, w, h = box_values(element['source_box'])
        if w <= 0 or h <= 0 or x < 0 or y < 0 or x + w > source_size[0] or y + h > source_size[1]:
            raise ValueError('source_box outside source image')
        if element.get('source_size') is not None and list(element['source_size']) != list(source_size):
            raise ValueError('source_box provenance belongs to another source size')
        if tuple(asset_size) != (w, h):
            raise ValueError('Asset dimensions differ from source_box; restore crop canvas or update measured provenance')
        if float(element.get('rotation', 0)) != 0:
            raise ValueError('Source pixels already contain their rotation; source_box placement cannot rotate again')
        return [x, y, w, h]
    x, y, w, h = box_values(element['box'])
    iw, ih = asset_size
    scale = min(w / iw, h / ih)
    dw, dh = iw * scale, ih * scale
    return [x + (w - dw) / 2, y + (h - dh) / 2, dw, dh]


def audit_geometry(slide, layout, canvas_width, canvas_height, tolerance=.5):
    """Compare final native object containers to measured layout, in source pixels.

    Unnamed objects and ink-fit text have no stable measured container. List them
    as unchecked; measured precision mode makes that a blocking finding.
    """
    source_size = layout.get('source_size')
    if not isinstance(source_size, (list, tuple)) or len(source_size) != 2 or any(
            not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0 for v in source_size):
        return {'status': 'fail', 'checked_objects': 0, 'tolerance_source_px': tolerance,
                'findings': [{'name': 'layout', 'reason': 'Missing or invalid source_size'}], 'unchecked': []}
    width, height = source_size
    scale = min(canvas_width / (width * EMU), canvas_height / (height * EMU))
    dx = (canvas_width - width * EMU * scale) / 2
    dy = (canvas_height - height * EMU * scale) / 2
    by_name = {}
    for shape in slide.shapes:
        by_name.setdefault(shape.name, []).append(shape)
    findings, unchecked = [], []
    checked = 0
    for kind in ('texts', 'shapes', 'images', 'icons'):
        for index, element in enumerate(layout.get(kind, [])):
            name = element.get('name')
            reason = None
            if not name:
                reason = 'Needs a unique object name'
            elif kind == 'texts' and (element.get('box_mode') != 'frame' or not element.get('size_pt')):
                reason = 'Needs measured text frame and explicit size_pt'
            elif kind in ('images', 'icons') and (element.get('source_box') is None or element.get('placement', 'source') != 'source'):
                reason = 'Needs source_box provenance and source placement'
            if reason and (layout.get('precision_mode') == 'measured' or kind == 'texts' or not name):
                unchecked.append({'name': name or f'{kind}[{index}]', 'reason': reason})
                continue
            candidates = by_name.get(name, [])
            if len(candidates) != 1:
                findings.append({'name': name, 'reason': 'Missing or ambiguous object name'})
                continue
            shape = candidates[0]
            try:
                expected = box_values(element['box'])
                if kind in ('images', 'icons'):
                    expected = image_box(element, shape.image.size, (width, height))
                    if any((shape.crop_left, shape.crop_right, shape.crop_top, shape.crop_bottom)):
                        findings.append({'name': name, 'reason': 'Unexpected internal image crop'})
                elif element.get('type') == 'line':
                    x, y, w, h = expected
                    ex, ey = element.get('end', [x + w, y + h])
                    expected = [min(x, ex), min(y, ey), abs(ex - x), abs(ey - y)]
                elif element.get('type') == 'polygon':
                    points = element['points']
                    xs, ys = [p[0] for p in points], [p[1] for p in points]
                    expected = [expected[0] + min(xs), expected[1] + min(ys), max(xs) - min(xs), max(ys) - min(ys)]
            except (AttributeError, ValueError, KeyError) as exc:
                findings.append({'name': name, 'reason': str(exc)})
                continue
            actual = [(shape.left - dx) / (EMU * scale), (shape.top - dy) / (EMU * scale),
                      shape.width / (EMU * scale), shape.height / (EMU * scale)]
            error = max(abs(a - b) for a, b in zip(actual, expected))
            checked += 1
            rotation_error = abs((shape.rotation - float(element.get('rotation', 0)) + 180) % 360 - 180)
            if error > tolerance or rotation_error > .01:
                findings.append({'name': name, 'expected_box': expected, 'actual_box': actual,
                                 'max_error_px': error, 'rotation_error': rotation_error})
    if layout.get('precision_mode') == 'measured':
        findings.extend({'name': item['name'], 'reason': item['reason']} for item in unchecked)
    return {'status': 'fail' if findings else 'pass', 'checked_objects': checked,
            'tolerance_source_px': tolerance, 'findings': findings, 'unchecked': unchecked}
