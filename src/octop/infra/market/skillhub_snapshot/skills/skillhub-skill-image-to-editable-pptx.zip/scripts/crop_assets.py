#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""裁剪图片的局部区域，并保留上游透明前景图的 alpha。

用于「确实无法用原生形状重建」的复杂插画 / 照片 / 渐变图标。
注意：单张图片默认必须小于版面的 15%，最终由 validate_structure.py 检查。

用法：
  python crop_assets.py IMG --x 100 --y 50 --w 64 --h 64 --out icon1.png
  python crop_assets.py IMG --x 100 --y 50 --w 64 --h 64 --out icon1.png \
      --transparent --bg auto --tolerance 30 --pad 2
  # 批量（推荐：一次进程裁完所有图标，避免每个图标重启解释器）
  python crop_assets.py IMG --batch manifest.json --batch-report report.json

参数：
  --transparent        对尚未去背景的纯色/近纯色裁图执行边缘连通去背景
  --bg auto|RRGGBB     背景色；auto = 自动从裁剪框四角取样
  --tolerance N        背景判定的颜色距离阈值（默认 30，边缘有彩色光晕就调大）
  --pad N              向外扩 N 像素（默认 0；图标被切边时加 2~4）
  --bbox               只打印不落盘，用来确认裁剪框选对了
  --batch FILE         批量清单：{"pad":2,"jobs":[{"name","x","y","w","h","out",
                       "transparent","bg","tolerance",...}, ...]}；每张的
                       transparent/bg 可独立指定。含安全阀：去背景后不透明比例
                       低于 --alpha-threshold（默认 0.12）自动退回不去背景版本。
  --batch-report FILE  批量结果 JSON（每张的 source_box / fallback / ok）
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, check_file, hint, ok, run, warn  # noqa: E402

from PIL import Image

from remove_background import parse_hex_color, remove_edge_background


def _crop_one(img, W, H, job, default_pad=0, alpha_threshold=0.12):
    """裁剪一个区域（可去背景）。返回结果 dict。

    job 字段：name, x, y, w, h, out, metadata, transparent, bg, tolerance,
             feather, expand, pad
    与单张 CLI 语义完全一致，只是复用同一个已打开的 PIL 图像对象，
    避免每个图标都重启解释器（3.4.0 性能修复）。
    """
    name = job.get("name") or os.path.basename(job.get("out", "crop"))
    x_in, y_in = int(job["x"]), int(job["y"])
    w_in, h_in = int(job["w"]), int(job["h"])
    pad = int(job.get("pad", default_pad))
    out_path = job["out"]
    meta_path = job.get("metadata") or (out_path + ".json")

    if w_in <= 0 or h_in <= 0 or pad < 0:
        return {"name": name, "ok": False,
                "error": "w/h must be positive; pad must be non-negative"}

    x = max(0, x_in - pad)
    y = max(0, y_in - pad)
    x2 = min(W, x_in + w_in + pad)
    y2 = min(H, y_in + h_in + pad)
    if x2 <= x or y2 <= y:
        return {"name": name, "ok": False,
                "error": f"裁剪框落在图片外：({x_in},{y_in}) {w_in}×{h_in}，"
                         f"图片 {W}×{H}"}
    box = (x, y, x2, y2)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)

    def _write(transparent):
        if transparent:
            bg = job.get("bg", "auto")
            background_colors = None if bg in (None, "auto") else [parse_hex_color(bg)]
            out = remove_edge_background(
                img.crop(box),
                tolerance=int(job.get("tolerance", 30)),
                background_colors=background_colors,
                expand=int(job.get("expand", 0)),
                feather=float(job.get("feather", 0.0)),
            )
        else:
            out = img.crop(box)
        out.save(out_path)
        return out

    transparent = bool(job.get("transparent", False))
    fallback = False
    out = _write(transparent)
    # 安全阀：整块同色的芯片（如满铺色块）会被边缘连通去背景整张抹掉。
    # 不透明像素 < 阈值视为误删，退回不去背景的版本。
    if transparent:
        alpha = out.getchannel("A")
        hist = alpha.histogram()
        total = alpha.size[0] * alpha.size[1]
        # 与 orchestrate._alpha_coverage 完全一致：alpha != 0 即视为不透明
        opaque = total - hist[0]
        if total and opaque / total < alpha_threshold:
            out = _write(False)
            transparent = False
            fallback = True

    metadata = {"name": os.path.basename(out_path), "source_size": [W, H],
                "source_box": [x, y, x2 - x, y2 - y],
                "visible_box_in_crop": out.getchannel("A").getbbox()}
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    return {"name": name, "ok": True, "out": out_path,
            "source_box": [x, y, x2 - x, y2 - y],
            "transparent": transparent, "fallback": fallback,
            "alpha_threshold_hit": fallback}


def _run_batch(img, W, H, manifest_path, report_path, alpha_threshold):
    with open(manifest_path, encoding="utf-8") as f:
        manifest = json.load(f)
    jobs = manifest.get("jobs", [])
    default_pad = int(manifest.get("pad", 0))
    results = []
    for job in jobs:
        try:
            results.append(_crop_one(img, W, H, job,
                                     default_pad=default_pad,
                                     alpha_threshold=alpha_threshold))
        except Exception as exc:  # noqa: BLE001 — 单张失败不拖垮整批
            results.append({"name": job.get("name", "?"), "ok": False,
                            "error": f"{type(exc).__name__}: {exc}"})
    report = {"image": manifest.get("image"), "source_size": [W, H],
              "total": len(jobs),
              "ok_count": sum(1 for r in results if r["ok"]),
              "fallback_count": sum(1 for r in results if r.get("fallback")),
              "results": results}
    if report_path:
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    return report


def main():
    ap = argparse.ArgumentParser(description="裁剪区域 / 去背景成透明 PNG")
    ap.add_argument("image")
    ap.add_argument("--x", type=int)
    ap.add_argument("--y", type=int)
    ap.add_argument("--w", type=int)
    ap.add_argument("--h", type=int)
    ap.add_argument("--batch", help="批量清单 JSON（一次进程裁完所有图标，"
                                    "避免每个图标重启解释器）")
    ap.add_argument("--batch-report", help="批量结果 JSON 输出路径")
    ap.add_argument("--alpha-threshold", type=float, default=0.12,
                    help="去背景后不透明比例低于此值视为误删并退回（默认 0.12）")
    ap.add_argument("--out", help="输出 PNG 路径（--bbox 时可不填）")
    ap.add_argument("--transparent", action="store_true",
                    help="对裁剪区域执行边缘连通去背景；已有透明 alpha 时通常无需添加")
    ap.add_argument("--bg", default="auto",
                    help="'auto'（取四角）或十六进制色值如 FFFFFF")
    ap.add_argument("--tolerance", type=int, default=30,
                    help="背景色距离阈值，默认 30")
    ap.add_argument("--feather", type=float, default=0.0,
                    help="透明边缘羽化半径，默认 0px")
    ap.add_argument("--expand", type=int, default=0,
                    help="背景蒙版向主体边缘扩展像素，默认 0px，用于清除浅色边缘")
    ap.add_argument("--pad", type=int, default=0,
                    help="向外扩 N 像素，默认 0")
    ap.add_argument("--metadata", help="输出实际裁区及原图坐标 JSON")
    ap.add_argument("--bbox", action="store_true",
                    help="只打印裁剪框信息，不写文件")
    args = ap.parse_args()

    check_file(args.image, "图片", doc="references/reconstruction-and-qa.md")
    # Preserve an existing alpha channel from the mandatory background-removal step.
    img = Image.open(args.image).convert("RGBA")
    W, H = img.size

    if args.batch:
        # 批量模式：一次进程裁完全部图标（3.4.0 性能修复）。
        report = _run_batch(img, W, H, args.batch, args.batch_report,
                            args.alpha_threshold)
        ok(f"批量裁剪完成：{report['ok_count']}/{report['total']} 张"
           + (f"，{report['fallback_count']} 张因整块同色保留不透明"
              if report["fallback_count"] else ""))
        for r in report["results"]:
            if not r["ok"]:
                warn(f"  {r['name']} 裁剪失败：{r.get('error', '?')}")
        return 0

    if args.x is None or args.y is None or args.w is None or args.h is None:
        raise SkillError("缺少裁剪框参数 --x/--y/--w/--h",
                         reason="单张模式必须给出裁剪框；或用 --batch 批量裁剪。",
                         next_steps=["补上 --x/--y/--w/--h 重试。",
                                     "或改用 --batch manifest.json --batch-report r.json。"],
                         doc="references/reconstruction-and-qa.md")

    if args.w <= 0 or args.h <= 0 or args.pad < 0:
        raise ValueError("w/h must be positive; pad must be non-negative")

    x = max(0, args.x - args.pad)
    y = max(0, args.y - args.pad)
    x2 = min(W, args.x + args.w + args.pad)
    y2 = min(H, args.y + args.h + args.pad)
    if x2 <= x or y2 <= y:
        raise SkillError(
            f"裁剪框落在图片外：({args.x},{args.y}) {args.w}×{args.h}，图片 {W}×{H}",
            reason="坐标是按原图像素算的；换图后需要重新测量。",
            next_steps=[
                "用 `measure.py grid IMG -o grid.png` 出网格图，重新确认裁剪框。",
                "用 `measure.py ink IMG --x .. --y .. --x2 .. --y2 ..` 量出图标外框。",
            ],
            doc="references/reconstruction-and-qa.md")
    box = (x, y, x2, y2)

    if args.pad and (args.x - args.pad < 0 or args.y - args.pad < 0
                     or x2 < args.x + args.w + args.pad
                     or y2 < args.y + args.h + args.pad):
        warn("裁剪框触及图片边缘，已自动收缩到边界内。")

    if args.bbox:
        cropped = img.crop(box)
        # 统计裁剪框四边是否切到内容（非背景色像素贴边）
        px = cropped.load()
        cw, ch = cropped.size
        corner = px[0, 0]
        edge_hit = sum(
            1 for i in range(cw)
            if abs(px[i, 0][0] - corner[0]) + abs(px[i, 0][1] - corner[1])
            + abs(px[i, 0][2] - corner[2]) > 60)
        ok(f"裁剪框：({x},{y}) → ({x2},{y2})   尺寸 {cw}×{ch}")
        if edge_hit:
            warn(f"上边缘有 {edge_hit} 个非背景像素贴边 —— 图标可能被切到，"
                 f"试试把 --y 上移或加 --pad 2。")
        hint("确认无误后加 --out 文件名即可真正落盘。")
        return 0

    if not args.out:
        raise SkillError("缺少 --out 输出路径",
                         reason="未指定把裁剪结果写到哪里。",
                         next_steps=["加上 --out output/icon_01.png 重试。",
                                     "或者用 --bbox 先预览裁剪框是否正确。"],
                         doc="references/reconstruction-and-qa.md")

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    if args.transparent:
        background_colors = None if args.bg == "auto" else [parse_hex_color(args.bg)]
        out = remove_edge_background(
            img.crop(box),
            tolerance=args.tolerance,
            background_colors=background_colors,
            expand=args.expand,
            feather=args.feather,
        )
    else:
        out = img.crop(box)
    out.save(args.out)
    metadata = {"name": os.path.basename(args.out), "source_size": [W,H],
                "source_box": [x,y,x2-x,y2-y],
                "visible_box_in_crop": out.getchannel("A").getbbox()}
    with open(args.metadata or args.out + ".json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    ok(f"已保存 {args.out}   裁剪框=({x},{y},{x2 - x},{y2 - y})"
       + ("  背景已透明" if args.transparent else ""))
    if args.transparent:
        hint("边缘还有彩色光晕？把 --tolerance 从 30 调到 45~60。")
    return 0


if __name__ == "__main__":
    sys.exit(run(main))
