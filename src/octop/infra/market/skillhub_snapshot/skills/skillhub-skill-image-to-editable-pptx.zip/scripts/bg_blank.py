#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""背景隐形图形 → 按空白背景处理（流水线 3.5.0）。

源图里常有一类「背景装饰」：整页水印、大面积淡色底纹、与页面底色几乎同色的
低对比色块。它们在源图里几乎看不出来，但逐像素重建时会被还原成一个**实色原生
形状**，结果比源图更显眼，还白白多出一个对象（卡片/面板因此被误判成"内容块"、
图标残差兜底还会把这些淡色区域再裁成一批无意义的 PNG）。

本模块给出统一判定：形状**同时**满足下列 6 条时，完全按空白背景处理 —— 不生成
原生形状、不裁成图标，让页面背景原样透出：

  1. 等效不透明度 < 阈值（默认 60%）；
  2. 位于背景层（`z <= 4`；自动链路的形状默认 `z=0`）；
  3. 无描边（有描边 = 被界定的容器/面板，不是背景装饰）；
  4. 类型是 rect / roundrect / ellipse / chamfer（线、箭头、徽章不是背景装饰）；
  5. 面积 >= 页面 0.5%（小面积淡色块多为徽章底、进度条、细分隔线，一律保留）；
  6. 不是内容底板：框内没有"被它托着"的文字/图标 —— 内容面积 / 形状面积 >= 4%
     即视为底板，保留。

卡片底色、面板、进度条、带描边的容器因此天然被排除；真正会被处理的只有"底层、
无描边、大面积、几乎看不见"的那类装饰。

## 等效不透明度为什么可以这样估

位图上的叠加结果 `O = α·C + (1-α)·B`，于是 `|O - B| = α·|C - B| <= α·255`，
即 `α >= max|O-B| / 255`。`estimate_alpha()` 返回的正是这个**下界**：
它只会低估不透明度，绝不会把一个实色块误判成半透明。反过来，一个"和页面底色
几乎同色"的实色块，其下界同样很低 —— 而它在视觉上本来就是隐形的（"隐形图形"），
按空白处理不会改变观感。

命令行（自检/人工复核用）::

    python scripts/bg_blank.py layout.json --source source.png
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── 默认阈值（与 SKILL.md「背景隐形图形按空白处理」一节一致）──────────────
DEFAULT_BLANK_ALPHA = 60.0        # 等效不透明度低于 60% → 隐形
DEFAULT_MAX_Z = 4                 # z <= 4 才算背景层（面板容器 8-12 起）
DEFAULT_MIN_AREA_RATIO = 0.005    # 面积 >= 页面 0.5% 才可能是背景装饰
DEFAULT_CONTENT_RATIO = 0.04      # 内容/形状 >= 4% → 它是内容底板，保留
BLANKABLE_TYPES = ("rect", "roundrect", "rounded_rect", "ellipse", "circle",
                   "chamfer", "snip")


# ──────────────────────────── 颜色工具 ────────────────────────────
def _hex2rgb(h):
    h = str(h or "").lstrip("#")
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except Exception:
        return None


def _rgb2hex(c):
    return "#%02X%02X%02X" % tuple(int(max(0, min(255, v))) for v in c)


def bg_rgb_at(background, x, y, W, H):
    """背景模型在 (x, y) 处的颜色。

    纯色直接返回；线性渐变按 `dir` 在整页范围内插值（与
    `build_pptx_from_layout._grad_xml` / `describe_image._grad_field` 同一模型）。
    """
    bg = background or {}
    grad = bg.get("grad")
    if bg.get("kind") == "gradient" and grad and len(grad) >= 2:
        c0, c1 = _hex2rgb(grad[0]), _hex2rgb(grad[1])
        if c0 and c1:
            ty = y / float(max(1, H - 1))
            tx = x / float(max(1, W - 1))
            d = bg.get("dir") or "v"
            if d == "h":
                t = tx
            elif d == "diag":
                t = (tx + ty) / 2.0
            else:
                t = ty
            return tuple(c0[i] + (c1[i] - c0[i]) * t for i in range(3))
    return _hex2rgb(bg.get("fill") or "#FFFFFF") or (255, 255, 255)


def page_bg_rgb(background, arr=None):
    """页面背景代表色（渐变取页面中点）。`arr` 用于无 background 时兜底。"""
    bg = background or {}
    if bg.get("fill") or bg.get("grad"):
        # 渐变取中点评代表色；逐形状判定时会按位置再插值（见 blank_shapes）。
        return _mid_bg(bg)
    if arr is not None:
        try:
            import numpy as np
            a = np.asarray(arr)
            b = max(2, min(a.shape[0], a.shape[1]) // 40)
            frame = np.concatenate([a[:b].reshape(-1, 3), a[-b:].reshape(-1, 3),
                                    a[:, :b].reshape(-1, 3), a[:, -b:].reshape(-1, 3)])
            return tuple(int(v) for v in np.median(frame, axis=0))
        except Exception:
            pass
    return (255, 255, 255)


def _mid_bg(bg):
    grad = bg.get("grad")
    if bg.get("kind") == "gradient" and grad and len(grad) >= 2:
        c0, c1 = _hex2rgb(grad[0]), _hex2rgb(grad[1])
        if c0 and c1:
            return tuple((c0[i] + c1[i]) / 2.0 for i in range(3))
    return _hex2rgb(bg.get("fill") or "#FFFFFF") or (255, 255, 255)


# ──────────────────────────── 不透明度估计 ────────────────────────────
def estimate_alpha(observed, bg):
    """由"实际呈现色 vs 页面背景色"反推等效不透明度（百分数，0-100）。

    见模块 docstring：这是真实不透明度的**下界**，只会低估。
    两个输入都是 (r, g, b)。
    """
    try:
        d = max(abs(float(observed[i]) - float(bg[i])) for i in range(3))
    except Exception:
        return 100.0
    return round(min(100.0, max(0.0, d / 255.0 * 100.0)), 2)


def observed_fill(arr, box, tol=40):
    """从源图取形状框内**实际呈现**的颜色（中位数 + 一轮收敛，抗文字污染）。

    手工 layout 里 `fill` 是作者声明的"本色"，未必等于源图里看到的叠加结果；
    判定必须回到源图像素，否则一个 `#EEEEEE` 的实色面板会被当成隐形。
    """
    try:
        import numpy as np
        x0, y0, w, h = [int(round(v)) for v in box]
    except Exception:
        return None
    if arr is None or w <= 0 or h <= 0:
        return None
    H, W = arr.shape[:2]
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(W, x0 + w), min(H, y0 + h)
    if x1 <= x0 or y1 <= y0:
        return None
    sub = arr[y0:y1, x0:x1].reshape(-1, 3).astype(np.float64)
    if sub.size == 0:
        return None
    med = np.median(sub, axis=0)
    near = sub[np.abs(sub - med).max(axis=1) <= tol]
    if near.shape[0] >= max(4, sub.shape[0] // 10):
        med = np.median(near, axis=0)
    return tuple(float(v) for v in med)


def shape_alpha(el, bg_rgb, arr=None):
    """形状的不透明度（百分数）。

    1. `el["alpha"]` 显式声明（与 `build_pptx_from_layout._apply_alpha` 同口径，
       0-100，越大越实）→ 直接采用；
    2. 否则用源图框内实际呈现色反推（下界估计）；
    3. 都没有 → 100（当作实色，**绝不**误判成隐形）。
    """
    declared = el.get("alpha", None)
    if declared is not None:
        try:
            return round(max(0.0, min(100.0, float(declared))), 2)
        except Exception:
            pass
    obs = observed_fill(arr, el.get("box")) if arr is not None else None
    if obs is not None:
        return estimate_alpha(obs, bg_rgb)
    fill = _hex2rgb(el.get("fill"))
    if fill is not None and not el.get("grad"):
        # 没有源图可采样时（纯 layout 审查），退化为"本色 vs 背景"的对比度，
        # 同样是下界口径。
        return estimate_alpha(fill, bg_rgb)
    return 100.0


# ──────────────────────────── 背景层装饰判定 ────────────────────────────
def is_content_plate(box, texts=(), icons=(), min_ratio=DEFAULT_CONTENT_RATIO):
    """该形状是不是"托着内容的底板"（卡片 / 面板 / 行带）。

    判据：存在文字或图标**基本完整落在框内**（重叠 ≥ 自身面积 60%），且它的
    面积相对形状不算微不足道（≥ `min_ratio`）。

    这条把"全页水印"和"卡片底板"分开：水印面积是页面的量级，任何一条文字
    相对它都是万分之几；卡片底板则和里面的文字同一量级。
    """
    try:
        bx0, by0, bw, bh = [float(v) for v in box]
    except Exception:
        return False
    if bw <= 0 or bh <= 0:
        return False
    s_area = bw * bh
    for item in list(texts or []) + list(icons or []):
        ib = item.get("box")
        if not ib or len(ib) < 4:
            continue
        ix0, iy0, iw, ih = [float(v) for v in ib[:4]]
        if iw <= 0 or ih <= 0:
            continue
        cx, cy = ix0 + iw / 2.0, iy0 + ih / 2.0
        if not (bx0 <= cx <= bx0 + bw and by0 <= cy <= by0 + bh):
            continue
        ox0, oy0 = max(bx0, ix0), max(by0, iy0)
        ox1, oy1 = min(bx0 + bw, ix0 + iw), min(by0 + bh, iy0 + ih)
        inter = max(0.0, ox1 - ox0) * max(0.0, oy1 - oy0)
        if inter / (iw * ih) < 0.6:
            continue
        if (iw * ih) / s_area >= min_ratio:
            return True
    return False


def has_border(el):
    if el.get("border"):
        return True
    try:
        return float(el.get("border_width") or 0) > 0
    except Exception:
        return False


def classify_blankable(el, alpha, page_area, texts=(), icons=(),
                        threshold=DEFAULT_BLANK_ALPHA, max_z=DEFAULT_MAX_Z,
                        min_area_ratio=DEFAULT_MIN_AREA_RATIO,
                        content_ratio=DEFAULT_CONTENT_RATIO):
    """判断是否该按空白背景处理。返回 `(blankable: bool, reason: str)`。

    `reason` 始终给出结论依据，便于人工复核 layout 时看懂"为什么没了"。
    """
    try:
        x, y, w, h = [float(v) for v in el.get("box", [0, 0, 0, 0])]
    except Exception:
        return False, "box 无法解析"
    if alpha >= threshold:
        return False, f"不透明度 {alpha:.1f}% ≥ {threshold:.0f}%（可见，保留）"
    if float(el.get("z", 0) or 0) > max_z:
        return False, f"z={el.get('z', 0)} > {max_z}（非背景层，保留）"
    if has_border(el):
        return False, "有描边（容器/面板，保留）"
    if str(el.get("type", "rect")) not in BLANKABLE_TYPES:
        return False, f"type={el.get('type')}（线/箭头/徽章，保留）"
    area = w * h
    if page_area and area / float(page_area) < min_area_ratio:
        return False, f"面积占页面 {area / float(page_area) * 100:.2f}% < " \
                      f"{min_area_ratio * 100:.1f}%（小块，保留）"
    if is_content_plate(el.get("box"), texts, icons, content_ratio):
        return False, "托着文字/图标（内容底板，保留）"
    return True, f"不透明度 {alpha:.1f}% < {threshold:.0f}% 且为背景层装饰 → 空白"


def blank_shapes(shapes, background, page_size, texts=(), icons=(), arr=None,
                 threshold=DEFAULT_BLANK_ALPHA, enabled=True,
                 max_z=DEFAULT_MAX_Z, min_area_ratio=DEFAULT_MIN_AREA_RATIO,
                 content_ratio=DEFAULT_CONTENT_RATIO):
    """过滤形状列表。返回 `(kept, blanked)`。

    `blanked` 每项含 `name / box / fill / alpha / reason`，用于回填 layout 的
    `blanked_shapes` 字段（可追溯：被当空白处理了什么、为什么）。
    """
    kept, blanked = [], []
    if not enabled or threshold <= 0:
        return list(shapes or []), blanked
    W, H = page_size[:2] if page_size else (0, 0)
    page_area = float(W * H) if W and H else 0.0
    bg = page_bg_rgb(background, arr)
    for el in (shapes or []):
        box = el.get("box")
        if not box or len(box) < 4:
            kept.append(el)
            continue
        local_bg = bg_rgb_at(background, box[0] + box[2] / 2.0,
                             box[1] + box[3] / 2.0, W, H) \
            if (background or {}).get("kind") == "gradient" else bg
        alpha = shape_alpha(el, local_bg, arr)
        yes, reason = classify_blankable(
            el, alpha, page_area, texts, icons, threshold, max_z,
            min_area_ratio, content_ratio)
        if yes:
            blanked.append({"name": el.get("name") or "",
                            "box": [int(round(v)) for v in box[:4]],
                            "fill": el.get("fill"),
                            "alpha": alpha, "reason": reason})
        else:
            kept.append(el)
    return kept, blanked


# ──────────────────────────── 自检入口 ────────────────────────────
def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("layout", help="layout.json")
    ap.add_argument("--source", help="源图（给出时按源图像素反推不透明度）")
    ap.add_argument("--bg-blank-alpha", type=float, default=DEFAULT_BLANK_ALPHA,
                    help=f"隐形阈值（默认 {DEFAULT_BLANK_ALPHA}）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    layout = json.loads(open(a.layout, encoding="utf-8").read())
    arr = None
    if a.source and os.path.isfile(a.source):
        from PIL import Image
        import numpy as np
        arr = np.asarray(Image.open(a.source).convert("RGB"))
    kept, blanked = blank_shapes(
        layout.get("shapes", []), layout.get("background"),
        layout.get("source_size"), layout.get("texts", []),
        layout.get("icons", []), arr, a.bg_blank_alpha)
    if a.json:
        print(json.dumps({"kept": len(kept), "blanked": blanked},
                         ensure_ascii=False, indent=2))
    else:
        print(f"保留 {len(kept)} 个形状，按空白背景处理 {len(blanked)} 个：")
        for b in blanked:
            print(f"  - {b['name'] or '(未命名)'} box={b['box']} "
                  f"fill={b['fill']} alpha={b['alpha']}%  {b['reason']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
