"""Local visual fidelity diagnostics for an already rendered PowerPoint page.

These metrics flag omissions hidden by a large, unchanged background. They do
not replace visual inspection or prove that the source was transcribed correctly.
"""

import numpy as np


def _edges(rgb, threshold=42):
    pixels = rgb.astype(np.int16)
    edges = np.zeros(pixels.shape[:2], dtype=bool)
    dx = np.max(np.abs(pixels[:, 1:] - pixels[:, :-1]), axis=2) >= threshold
    dy = np.max(np.abs(pixels[1:] - pixels[:-1]), axis=2) >= threshold
    edges[:, 1:] |= dx
    edges[:, :-1] |= dx
    edges[1:] |= dy
    edges[:-1] |= dy
    return edges


def _dilate(mask, radius=2):
    height, width = mask.shape
    padded = np.pad(mask, radius)
    result = np.zeros_like(mask)
    for y in range(2 * radius + 1):
        for x in range(2 * radius + 1):
            result |= padded[y:y + height, x:x + width]
    return result


def measure_patch(source, rendered, *, pixel_threshold=64):
    """Return bounded, interpretable error metrics for equal-sized RGB arrays."""
    delta = np.max(np.abs(source.astype(np.int16) - rendered.astype(np.int16)), axis=2)
    src_edges = _edges(source)
    dst_edges = _edges(rendered)
    src_count, dst_count = int(src_edges.sum()), int(dst_edges.sum())
    return {
        'bad_pixel_fraction': round(float(np.mean(delta >= pixel_threshold)), 6),
        'edge_recall': (round(float((src_edges & _dilate(dst_edges)).sum() / src_count), 6)
                        if src_count >= 12 else None),
        'edge_precision': (round(float((dst_edges & _dilate(src_edges)).sum() / dst_count), 6)
                           if dst_count >= 12 else None),
        'source_edge_pixels': src_count,
    }


def alert_tiles(source, rendered, *, tile=48, step=24, max_bad_fraction=.045,
                max_returned=40):
    """Scan overlapping tiles, including image edges, to catch unlisted content."""
    height, width = source.shape[:2]
    x_positions = sorted(set(range(0, max(1, width - tile + 1), step)) | {max(0, width - tile)})
    y_positions = sorted(set(range(0, max(1, height - tile + 1), step)) | {max(0, height - tile)})
    bad = np.max(np.abs(source.astype(np.int16) - rendered.astype(np.int16)), axis=2) >= 64
    alerts = []
    for y in y_positions:
        for x in x_positions:
            x2, y2 = min(width, x + tile), min(height, y + tile)
            pixels = bad[y:y2, x:x2]
            count = int(pixels.sum())
            fraction = count / pixels.size
            if count >= 12 and fraction > max_bad_fraction:
                alerts.append({'box': [x, y, x2 - x, y2 - y],
                               'bad_pixel_fraction': round(fraction, 6)})
    alerts.sort(key=lambda item: item['bad_pixel_fraction'], reverse=True)
    return {'count': len(alerts), 'worst': alerts[:max_returned],
            'tile_size': tile, 'step': step, 'threshold': max_bad_fraction}


def assess(comparison, max_rms, *, max_region_bad=.09, min_text_edge_recall=.72):
    """Return blocking issues; callers may add a separate human visual review."""
    issues = []
    if comparison['rms'] > max_rms:
        issues.append(f"Whole-page RMS {comparison['rms']:.4f} > {max_rms:.4f}")
    for region in comparison['regions']:
        name = region['name']
        if region['rms'] > max_rms:
            issues.append(f"{name}: local RMS {region['rms']:.4f} > {max_rms:.4f}")
        if region['kind'] in ('texts', 'shapes'):
            if region['bad_pixel_fraction'] > max_region_bad:
                issues.append(f"{name}: large pixel mismatch {region['bad_pixel_fraction']:.1%}")
            if (region['kind'] == 'texts' and region['edge_recall'] is not None and
                    region['edge_recall'] < min_text_edge_recall):
                issues.append(f"{name}: missing/misaligned text edges (recall {region['edge_recall']:.1%})")
    if comparison['tile_alerts']['count']:
        issues.append(f"{comparison['tile_alerts']['count']} high-difference local tiles; "
                      "check tile_alerts.worst coordinates")
    return issues
