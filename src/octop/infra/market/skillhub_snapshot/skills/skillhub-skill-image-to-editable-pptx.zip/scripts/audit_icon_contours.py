#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""图标轮廓审计：检查裁出的图标/插画素材是否符合 3.3.2 的透明轮廓要求。

逐项输出（全部为源图像素语义，不做任何缩放）：

  * rgba            —— 是否 RGBA（无 alpha 通道直接判失败）
  * corner_transparent —— 四角是否真实透明（圆形/异形图标必须四角全透明）
  * border_opaque_ratio —— 外圈 2px 环带的不透明比例；接近 1 表示裁图带原背景，
                            即"矩形背景污染"
  * opaque_ratio    —— 整体不透明比例；> max-opaque-ratio 视为矩形底风险
  * rect_bg_risk    —— 综合上面三项给出的"矩形底"布尔结论
  * alpha_hole      —— alpha 图内是否存在被不透明像素包围的镂空区
  * interior_colored—— 镂空区内部是否保留了细节像素（3.3.2 要求保留圆形图标
                        内部的白色细节）
  * halo_ratio      —— 半透明（1..254）像素占比，过高说明边缘是渐变杂边

状态：`pass` / `review`。任一素材 `review` 时进程返回 1。

用法：
  python scripts/audit_icon_contours.py crops/ --json
  python scripts/audit_icon_contours.py crops/*.png --max-opaque-ratio 0.75 \\
      --require-hollow-detail
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, hint, ok, run, warn  # noqa: E402

DEFAULTS = {
    "max_opaque_ratio": 0.92,          # 超过视为整块矩形底
    "max_border_opaque_ratio": 0.55,   # 外圈环带不透明比例上限
    "max_halo_ratio": 0.35,            # 半透明像素占比上限
    "min_transparent_corners": 4,      # 圆形/异形图标要求四角全透明
}


def inspect(path, **kw):
    """审计单张素材。返回字典；不抛异常（读不了就返回 error 状态）。"""
    cfg = {**DEFAULTS, **{k: v for k, v in kw.items() if v is not None}}
    try:
        im = Image.open(path)
    except Exception as exc:  # noqa: BLE001
        return {"file": path, "status": "review", "error": f"无法打开：{exc}"}

    src_mode = im.mode
    im = im.convert("RGBA")
    w, h = im.size
    if w <= 0 or h <= 0:
        return {"file": path, "status": "review", "error": "尺寸为 0"}

    px = im.load()
    corners = [px[0, 0], px[w - 1, 0], px[0, h - 1], px[w - 1, h - 1]]
    transparent_corners = sum(1 for p in corners if p[3] <= 10)

    arr = np.asarray(im)
    total = w * h
    alpha_arr = arr[:, :, 3].astype(np.int16)
    opaque = int((alpha_arr > 10).sum())
    translucent = int(((alpha_arr > 10) & (alpha_arr < 245)).sum())

    # 外圈 2px 环带
    ring = 0
    ring_opaque = 0
    for yy in range(h):
        for xx in range(w):
            if xx < 2 or yy < 2 or xx >= w - 2 or yy >= h - 2:
                ring += 1
                if px[xx, yy][3] > 10:
                    ring_opaque += 1

    opaque_ratio = opaque / total
    border_ratio = (ring_opaque / ring) if ring else 0.0
    halo_ratio = translucent / total

    rect_bg_risk = (
        border_ratio > cfg["max_border_opaque_ratio"]
        and opaque_ratio > cfg["max_opaque_ratio"]
    )

    has_alpha = src_mode in ("RGBA", "LA", "PA") or "transparency" in im.info

    # 镂空检测：某行/列中间出现透明但不触边
    alpha = im.getchannel("A")
    ap = alpha.load()
    # 镂空检测：同一行里「不透明 → 透明 → 不透明」，即被前景包围的空洞
    hole_rows = 0
    inner_detail = 0
    for yy in range(h):
        row = [ap[xx, yy] > 10 for xx in range(w)]
        first = next((i for i, v in enumerate(row) if v), None)
        if first is None:
            continue
        last = next((i for i in range(w - 1, -1, -1) if row[i]), None)
        if first is not None and last is not None and last > first:
            if any(not row[i] for i in range(first, last + 1)):
                hole_rows += 1
                break
    for yy in range(2, h - 2):
        for xx in range(2, w - 2):
            if ap[xx, yy] > 10:
                r, g, b, a = px[xx, yy]
                if r > 200 and g > 200 and b > 200:
                    inner_detail += 1

    alpha_hole = hole_rows > 0
    interior_colored_ratio = round(inner_detail / total, 4)

    reasons = []
    if not has_alpha:
        reasons.append("无 alpha 通道")
    if transparent_corners < cfg["min_transparent_corners"]:
        reasons.append(f"四角仅 {transparent_corners}/4 透明")
    if rect_bg_risk:
        reasons.append(f"疑似矩形底（外圈不透明 {border_ratio:.2f}，整体不透明 {opaque_ratio:.2f}）")
    elif border_ratio > cfg["max_border_opaque_ratio"]:
        reasons.append(f"外圈环带不透明比例偏高 {border_ratio:.2f}")
    # 半透明杂边只对「图标」有意义；整块羽化的插画/照片（不透明比例高）
    # halo 天然很大，不参与判定。
    is_full_bleed = opaque_ratio >= 0.80
    if not is_full_bleed and halo_ratio > cfg["max_halo_ratio"]:
        reasons.append(f"半透明杂边过多 {halo_ratio:.2f}")
    # 镂空细节只在「实心色块型图标」上判定：线描图标内部本来就是透明的，
    # 不应要求它有白色细节。
    is_solid_icon = 0.55 <= opaque_ratio < 0.80
    if alpha_hole and is_solid_icon and interior_colored_ratio < 1e-4:
        reasons.append("实心图标的镂空区未保留内部细节像素")

    return {
        "file": path,
        "size": [w, h],
        "src_mode": src_mode,
        "rgba": has_alpha,
        "corner_transparent": transparent_corners == 4,
        "transparent_corners": transparent_corners,
        "opaque_ratio": round(opaque_ratio, 4),
        "border_opaque_ratio": round(border_ratio, 4),
        "halo_ratio": round(halo_ratio, 4),
        "rect_bg_risk": rect_bg_risk,
        "alpha_hole": alpha_hole,
        "interior_colored_ratio": interior_colored_ratio,
        "status": "pass" if not reasons else "review",
        "reasons": reasons,
    }


def _expand(patterns):
    out = []
    for p in patterns:
        if os.path.isdir(p):
            out += sorted(glob.glob(os.path.join(p, "*.png")))
            out += sorted(glob.glob(os.path.join(p, "*.webp")))
        else:
            out += sorted(glob.glob(p)) or [p]
    return [p for p in out if os.path.isfile(p)]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="素材文件或目录（目录会展开 *.png）")
    ap.add_argument("--max-opaque-ratio", type=float, default=None)
    ap.add_argument("--max-border-opaque-ratio", type=float, default=None)
    ap.add_argument("--max-halo-ratio", type=float, default=None)
    ap.add_argument("--min-transparent-corners", type=int, default=None)
    ap.add_argument("--contact-sheet", default=None, help="可选：输出拼版联系图")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    files = _expand(args.files)
    if not files:
        raise SkillError("没有找到可审计的素材",
                         reason="路径不存在，或目录里没有 *.png。",
                         next_steps=["确认裁剪目录：`ls crops/`",
                                     "先用 crop_assets.py 生成素材。"],
                         doc="references/precision-positioning.md")

    cfg = {k: getattr(args, k) for k in DEFAULTS}
    results = [inspect(f, **cfg) for f in files]

    if not args.json:
        for r in results:
            tag = "OK  " if r["status"] == "pass" else "注意"
            print(f"  [{tag}] {r['file']}  {r.get('size')}  "
                  f"角={r.get('transparent_corners')}/4  不透明={r.get('opaque_ratio')}  "
                  f"外圈={r.get('border_opaque_ratio')}")
            for why in r.get("reasons", []):
                print(f"          · {why}")

    if args.contact_sheet:
        try:
            from PIL import Image
            thumbs = []
            for f in files:
                im = Image.open(f).convert("RGBA")
                im.thumbnail((160, 160))
                bg = Image.new("RGBA", (168, 168), (255, 0, 255, 255))
                bg.paste(im, ((168 - im.width) // 2, (168 - im.height) // 2), im)
                thumbs.append(bg)
            cols = max(1, min(8, len(thumbs)))
            rows = (len(thumbs) + cols - 1) // cols
            sheet = Image.new("RGBA", (cols * 168, rows * 168), (30, 30, 30, 255))
            for i, t in enumerate(thumbs):
                sheet.paste(t, ((i % cols) * 168, (i // cols) * 168), t)
            sheet.convert("RGB").save(args.contact_sheet)
            ok(f"联系图 → {args.contact_sheet}（洋红=透明）")
        except Exception as exc:  # noqa: BLE001
            warn(f"联系图生成失败：{exc}")

    n_bad = sum(1 for r in results if r["status"] != "pass")
    effective = {k: getattr(args, k) for k in DEFAULTS}
    effective = {k: (DEFAULTS[k] if v is None else v) for k, v in effective.items()}
    if args.json:
        print(json.dumps({"total": len(results), "review": n_bad,
                          "thresholds": effective,
                          "items": results}, ensure_ascii=False, indent=2))
    else:
        ok(f"共 {len(results)} 张，{len(results) - n_bad} 张通过，{n_bad} 张待复核")
        if n_bad:
            hint("圆形/异形图标必须四角透明；外圈不透明比例高说明裁图带了原背景，"
                 "请回上一步用 remove_background.py 或反向 alpha 重做。")
    return 1 if n_bad else 0


if __name__ == "__main__":
    sys.exit(run(main))
