#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从透明前景参考图批量精确裁剪图标（纯 PIL，无 opencv / numpy 依赖）。

按 source_box 批量裁剪多个图标，完整保留已有 RGBA；cx/cy/r 仅兼容旧输入。
与 crop_assets.py 的分工：
  crop_assets.py   —— 单个区域，用左上角 + 宽高定位，适合任意矩形裁剪
  extract_icons.py —— 一批图标，用中心 + 半径定位，适合等尺寸图标阵列

用法：
  python extract_icons.py IMG OUT_DIR icons.json

icons.json 格式：
  [
    {"name": "icon_water.png", "cx": 84, "cy": 250, "r": 28},
    {"name": "icon_gas.png",   "cx": 900, "cy": 460, "r": 32}
  ]

  也可以用 --from-layout element-inventory.json 从元素清单提取 image 元素，
  再按 name 前缀批量重裁（省去手写坐标）。

关键经验：图标中心务必用 `measure.py ink` 或 `measure.py cols/rows` 精确
确定，不要肉眼估测；r 取 max(图标宽, 图标高)/2 + 4px 左右。
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import (SkillError, check_file, hint, ok, run,  # noqa: E402
                 warn)

from PIL import Image

from remove_background import remove_edge_background

SAMPLE_ICONS = [
    # 仅为格式示例，实际使用请写自己的 icons.json
    {"name": "icon_sample_a.png", "cx": 84, "cy": 250, "r": 28},
    {"name": "icon_sample_b.png", "cx": 896, "cy": 268, "r": 24},
]


def crop_transparent(src, cx, cy, r, out_path, tol=50):
    """裁剪 (cx±r, cy±r) 窗口，原样保留 alpha。返回输出尺寸。"""
    x0, y0 = max(0, cx - r), max(0, cy - r)
    x1, y1 = min(src.size[0], cx + r), min(src.size[1], cy + r)
    if x1 - x0 < 4 or y1 - y0 < 4:
        return None
    crop = src.crop((x0, y0, x1, y1))
    alpha = crop.getchannel("A")
    pixels = alpha.load()
    w, h = crop.size
    hit_edge = sum(
        pixels[x, y] > 8
        for x, y in (
            [(x, 0) for x in range(w)]
            + [(x, h - 1) for x in range(w)]
            + [(0, y) for y in range(1, h - 1)]
            + [(w - 1, y) for y in range(1, h - 1)]
        )
    )
    crop.save(out_path)
    return crop.size, hit_edge


def icons_from_layout(layout_path):
    """从元素清单 JSON 的 image 元素推导 (name, cx, cy, r)。"""
    try:
        data = json.load(open(layout_path, encoding="utf-8"))
    except Exception as e:
        raise SkillError(f"读不了布局文件：{layout_path}",
                         reason=str(e),
                         next_steps=["确认这是包含 elements 数组的元素清单 JSON。",
                                     "用 `python -m json.tool 文件` 检查 JSON 是否合法。"],
                         doc="references/artifact-tool-workflow.md")
    out = []
    for el in data.get("elements", []):
        if el.get("type") != "image" or not el.get("src"):
            continue
        name = os.path.basename(str(el["src"]))
        box = el.get("source_box")
        if box is None:
            if data.get("coordinate_space") != "source_pixels":
                raise ValueError("from-layout requires source_box or coordinate_space=source_pixels")
            box = [el[k] for k in ("x", "y", "w", "h")]
        if isinstance(box, dict):
            box = [box[k] for k in ("x", "y", "w", "h")]
        out.append({"name": name, "source_box": box})
    return out


def main():
    ap = argparse.ArgumentParser(description="按中心+半径批量裁剪图标")
    ap.add_argument("image")
    ap.add_argument("out_dir")
    ap.add_argument("icons_json", nargs="?", default=None,
                    help="图标清单 JSON；不填则需配合 --from-layout 或 --demo")
    ap.add_argument("--from-layout", help="从元素清单 JSON 的 image 元素推导坐标")
    ap.add_argument("--demo", action="store_true",
                    help="用内置示例坐标跑一遍（仅用于验证环境/试跑格式）")
    ap.add_argument("--tolerance", type=int, default=50)
    ap.add_argument("--report", action="store_true",
                    help="输出每个图标的边缘触边统计，便于判断是否被切边")
    args = ap.parse_args()

    check_file(args.image, "图片", doc="references/reconstruction-and-qa.md")

    if args.icons_json:
        check_file(args.icons_json, "图标清单 JSON")
        try:
            data = json.load(open(args.icons_json, encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise SkillError(
                f"icons.json 不是合法 JSON（第 {e.lineno} 行）",
                reason=f"{e.msg}。",
                next_steps=[
                    '格式应为：[{"name": "a.png", "cx": 84, "cy": 250, "r": 28}]',
                    "注意 JSON 用英文双引号，末尾不能有逗号。",
                ],
                doc="references/artifact-tool-workflow.md")
        icons = data
    elif args.from_layout:
        icons = icons_from_layout(args.from_layout)
    elif args.demo:
        icons = SAMPLE_ICONS
        warn("正在使用内置示例坐标（--demo），输出只是格式演示，不是你的图标。")
    else:
        raise SkillError(
            "没有给出要裁剪哪些图标",
            reason="本工具按图标清单工作，缺少清单就无从下手。"
                   "（内置坐标属示例数据，静默使用会产出一堆无关文件，因此不默认启用。）",
            next_steps=[
                "推荐：测量中心坐标后写一个 icons.json 并作为第 3 个参数传入。",
                "  格式：[{\"name\":\"icon_a.png\",\"cx\":84,\"cy\":250,\"r\":28}]",
                "已有元素清单？直接：--from-layout element-inventory.json 自动推导。",
                "想先试跑看看：加 --demo。",
            ],
            doc="references/artifact-tool-workflow.md")

    os.makedirs(args.out_dir, exist_ok=True)
    # Preserve an existing alpha channel from the mandatory background-removal step.
    src = Image.open(args.image).convert("RGBA")
    W, H = src.size
    made, skipped, edgewarn = 0, 0, []
    metadata = []
    from crop_geometry import extract
    for item in icons:
        name = item["name"]
        if os.path.basename(name) != name or name in [m["name"] for m in metadata]:
            raise ValueError("asset names must be unique basenames")
        box = item.get("source_box")
        if box is None:
            cx, cy, radius = item["cx"], item["cy"], item["r"]
            box = [cx-radius, cy-radius, 2*radius, 2*radius]
        crop, meta = extract(src, box, item.get("pad", 0))
        crop.save(os.path.join(args.out_dir, name))
        metadata.append({"name": name, **meta})
        made += 1
        if meta["edge_touch"]:
            edgewarn.append(name)
        print(f"  {name}: {crop.width}x{crop.height}")
    with open(os.path.join(args.out_dir, "crop-metadata.json"), "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    ok(f"完成：{made} 个图标 → {args.out_dir}" + (f"，跳过 {skipped} 个" if skipped else ""))
    if edgewarn:
        warn(f"{len(edgewarn)} 个图标疑似被切边：{edgewarn[:3]}"
             + (" …" if len(edgewarn) > 3 else ""))
        hint("把这些的 r 调大 2~4px 后重跑，或改用 crop_assets.py 精确指定矩形。")
    return 1 if edgewarn or skipped else 0


if __name__ == "__main__":
    sys.exit(run(main))
