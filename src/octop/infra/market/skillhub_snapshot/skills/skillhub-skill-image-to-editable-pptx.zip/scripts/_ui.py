#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一的人类可读提示 / 友好报错工具（image-to-ppt 全脚本共用）。

设计目标：任何脚本出错时，用户看到的是
    出了什么问题 · 为什么 · 下一步怎么做 · 去哪查
而不是一段 Python traceback。
"""
from __future__ import annotations

import sys
import traceback

BAR = "─" * 66

_QUIET = False


def set_quiet(on=True):
    """静默模式：只保留 [问题] / [注意] 与错误块，屏蔽 [OK] 与提示行。"""
    global _QUIET
    _QUIET = bool(on)


class SkillError(Exception):
    """可读错误。reason = 发生了什么；next_steps = 该怎么办；doc = 文档位置。

    code: 进程退出码。1 = 输入/布局有问题（可修）；2 = 用法或文件错误（默认）。
    """

    def __init__(self, title, reason="", next_steps=None, doc=None, code=2):
        super().__init__(title)
        self.title = title
        self.reason = reason
        self.next_steps = list(next_steps or [])
        self.doc = doc
        self.code = code


def banner(title):
    print(f"\n{BAR}\n{title}\n{BAR}")


def ok(msg):
    if not _QUIET:
        print(f"  [OK]   {msg}")


def warn(msg):
    print(f"  [注意] {msg}")


def bad(msg):
    print(f"  [问题] {msg}")


def hint(msg):
    if not _QUIET:
        print(f"          → {msg}")


def info(msg):
    """普通信息行，静默模式下隐藏。"""
    if not _QUIET:
        print(msg)


def report_error(err: SkillError):
    banner(f"出错了：{err.title}")
    if err.reason:
        print(f"原因：{err.reason}")
    if err.next_steps:
        print("\n下一步可以这样做：")
        for i, s in enumerate(err.next_steps, 1):
            print(f"  {i}. {s}")
    if err.doc:
        print(f"\n文档：{err.doc}")
    print(f"{BAR}\n")


def run(main_fn):
    """脚本入口包装器：把 SkillError 渲染成友好提示，其他异常附上最小栈信息。"""
    try:
        return main_fn() or 0
    except SkillError as e:
        report_error(e)
        return getattr(e, "code", 2)
    except KeyboardInterrupt:
        print("\n已取消。")
        return 130
    except Exception as e:  # noqa: BLE001 - 兜底，避免裸 traceback 吓到用户
        tb = traceback.extract_tb(sys.exc_info()[2])
        where = f"{tb[-1].filename.split('/')[-1]}:{tb[-1].lineno}" if tb else "未知位置"
        report_error(SkillError(
            f"{type(e).__name__}: {e}",
            reason=f"脚本在 {where} 处遇到未预期的错误。",
            next_steps=[
                "运行 python scripts/preflight.py --plain 检查基础依赖和可选组件。",
                "若刚改过元素清单，用 `python -m json.tool element-inventory.json` 检查 JSON 语法。",
                "把上面这行错误信息连同命令一起反馈，便于定位。",
            ],
            doc="references/faq.md",
        ))
        return 3


def check_file(path, what="文件", doc=None):
    import os
    if not os.path.exists(path):
        raise SkillError(
            f"找不到{what}：{path}",
            reason="路径不存在，或当前工作目录与预期不一致。",
            next_steps=[
                f"确认路径拼写，或用绝对路径重试：{path}",
                "`ls` 一下所在目录，看看文件名是否含中文/空格需要加引号。",
            ],
            doc=doc,
        )
    return path


def require(module, pip_name=None, why="", doc=None):
    """导入必需依赖，缺失时给出可直接照抄的安装命令。"""
    import importlib
    try:
        return importlib.import_module(module)
    except (ImportError, OSError) as exc:
        pkg = pip_name or module
        raise SkillError(
            f"缺少依赖：{pkg}",
            reason=why or f"当前 Python 无法导入 {pkg}（{exc}）。",
            next_steps=[
                f"在执行脚本的 Python 环境运行 python -m pip install {pkg}。",
                "没有安装权限时，使用可写的虚拟环境或当前组织提供的离线安装源。",
            ],
            doc=doc,
        )
