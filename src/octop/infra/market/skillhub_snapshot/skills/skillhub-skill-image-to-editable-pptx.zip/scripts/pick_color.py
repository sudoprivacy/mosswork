#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从图片取样颜色：单点 / 区域均值 / 区域主色。

颜色必须来自像素采样，不能凭感觉写十六进制值 —— 这是 1:1 还原的前提。

用法：
  python pick_color.py IMG --mode point    --x 120 --y 40
  python pick_color.py IMG --mode avg      --x 10 --y 10 --w 200 --h 100
  python pick_color.py IMG --mode dominant --x 10 --y 10 --w 200 --h 100

输出：十六进制色值（point/avg 一行；dominant 前 5 名，附像素数与占比）。

取不到想要的颜色时，用 `measure.py grid` 出网格图标定坐标，或换更大的采样区域。
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, check_file, hint, run  # noqa: E402

from PIL import Image


def main():
    ap = argparse.ArgumentParser(description="图片取色（单点 / 均值 / 主色）")
    ap.add_argument("image")
    ap.add_argument("--mode", choices=["point", "avg", "dominant"], default="point")
    ap.add_argument("--x", type=int, required=True)
    ap.add_argument("--y", type=int, required=True)
    ap.add_argument("--w", type=int, default=0)
    ap.add_argument("--h", type=int, default=0)
    args = ap.parse_args()

    check_file(args.image, "图片", doc="references/reconstruction-and-qa.md")
    try:
        img = Image.open(args.image).convert("RGB")
    except Exception:
        raise SkillError(
            f"读不了这张图：{args.image}",
            reason="文件可能损坏，或后缀与实际格式不符（如 .png 实为 webp）。",
            next_steps=["用系统看图软件打开确认能正常显示；必要时先另存为 PNG 再试。"],
            doc="references/reconstruction-and-qa.md")

    W, H = img.size
    if not (0 <= args.x < W and 0 <= args.y < H):
        raise SkillError(
            f"坐标超出图片范围：({args.x}, {args.y})，图片只有 {W}×{H}",
            reason="测量坐标是按原图像素算的，换图后要重新量。",
            next_steps=[
                f"把 --x 限制在 0..{W - 1}，--y 限制在 0..{H - 1}。",
                "不确定位置？先跑 `measure.py grid IMG -o grid.png` 出网格图。",
            ],
            doc="references/reconstruction-and-qa.md")

    x, y = args.x, args.y
    w = args.w if args.w > 0 else 1
    h = args.h if args.h > 0 else 1
    box = (x, y, min(x + w, W), min(y + h, H))

    if args.mode == "point":
        r, g, b = img.getpixel((x, y))
        print(f"{r:02X}{g:02X}{b:02X}")
        return 0

    region = img.crop(box)
    if args.mode == "avg":
        r, g, b = region.resize((1, 1), Image.LANCZOS).getpixel((0, 0))
        print(f"{r:02X}{g:02X}{b:02X}")
        return 0

    q = region.quantize(colors=16)
    palette = q.getpalette()
    colors = sorted(q.getcolors(), reverse=True)
    total = region.size[0] * region.size[1]
    for count, idx in colors[:5]:
        r, g, b = palette[idx * 3: idx * 3 + 3]
        print(f"{r:02X}{g:02X}{b:02X}  {count:6d}  {count / total:5.1%}")
    if colors and colors[0][0] / total > 0.9:
        hint("主色占比过高（>90%），采样区可能整个落在同一块底色上。")
    return 0


if __name__ == "__main__":
    sys.exit(run(main))
