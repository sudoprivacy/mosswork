"""Lossless crop geometry. All boxes are source pixels; no inferred scaling."""
import math


def extract(source, box, pad=0):
    if isinstance(box, dict):
        box = [box[k] for k in ("x", "y", "w", "h")]
    x, y, w, h = box
    if not all(math.isfinite(v) for v in [x,y,w,h,pad]) or min(w,h) <= 0 or pad < 0:
        raise ValueError("invalid crop geometry")
    left, top = max(0, math.floor(x-pad)), max(0, math.floor(y-pad))
    right = min(source.width, math.ceil(x+w+pad))
    bottom = min(source.height, math.ceil(y+h+pad))
    if right <= left or bottom <= top:
        raise ValueError("crop outside source")
    crop = source.convert("RGBA").crop((left,top,right,bottom))
    alpha = crop.getchannel("A")
    bbox = alpha.getbbox()
    if bbox is None:
        raise ValueError("empty crop")
    # Only source-canvas edges may legitimately clip a visible object.
    touch = ((bbox[0]==0 and left>0) or (bbox[1]==0 and top>0)
             or (bbox[2]==crop.width and right<source.width)
             or (bbox[3]==crop.height and bottom<source.height))
    return crop, {"source_size": list(source.size),
                  "source_box": [left,top,right-left,bottom-top],
                  "visible_box_in_crop": list(bbox), "edge_touch": touch}
