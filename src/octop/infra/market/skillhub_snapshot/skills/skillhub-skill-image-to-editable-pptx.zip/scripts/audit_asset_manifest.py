#!/usr/bin/env python3
"""Reject fake screenshot splitting and audit independent transparent assets."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROLE_LIMITS = {
    "icon": {"max_source_area": 0.035, "min_transparency": 0.10},
    "logo": {"max_source_area": 0.06, "min_transparency": 0.05},
    "illustration": {"max_source_area": 0.15, "min_transparency": 0.05},
    "photo": {"max_source_area": 0.30, "min_transparency": 0.0},
}
FORBIDDEN_ROLES = {
    "card", "panel", "section", "chart", "table", "text", "number",
    "label", "screenshot", "slice", "tile", "background-fragment",
}


def normalized_box(value):
    if isinstance(value, dict):
        return tuple(int(value[key]) for key in ("x", "y", "w", "h"))
    if isinstance(value, list) and len(value) == 4:
        return tuple(int(item) for item in value)
    raise ValueError("source_box must be {x,y,w,h} or [x,y,w,h]")


def alpha_stats(path):
    with Image.open(path) as image:
        has_alpha = image.mode in {"RGBA", "LA"} or "transparency" in image.info
        rgba = image.convert("RGBA")
    alpha = rgba.getchannel("A")
    histogram = alpha.histogram()
    total = rgba.width * rgba.height
    transparent = histogram[0]
    partial = total - histogram[0] - histogram[255]
    bbox = alpha.getbbox()
    if bbox:
        x0, y0, x1, y1 = bbox
        margins = [x0, y0, rgba.width - x1, rgba.height - y1]
        bbox_area = max(1, (x1 - x0) * (y1 - y0))
        bbox_aspect = (x1 - x0) / max(1, y1 - y0)
    else:
        margins = [0, 0, 0, 0]
        bbox_area = 1
        bbox_aspect = 0.0
    return {
        "has_alpha": has_alpha,
        "transparent_ratio": transparent / total if total else 0.0,
        "partial_alpha_pixels": partial,
        "visible_coverage_in_bbox": (total - transparent) / bbox_area if total else 0.0,
        "visible_bbox_aspect": bbox_aspect,
        "bbox": list(bbox) if bbox else None,
        "margins": margins,
        "size": [rgba.width, rgba.height],
    }


def source_match_stats(asset, source_crop):
    """Verify a cutout only removes alpha and never redraws source pixels."""
    asset_rgba = asset.convert("RGBA")
    source_rgba = source_crop.convert("RGBA")
    asset_pixels = asset_rgba.load()
    source_pixels = source_rgba.load()
    rgb_mismatched = 0
    created_alpha = 0
    visible_pixels = 0
    for y in range(asset_rgba.height):
        for x in range(asset_rgba.width):
            candidate = asset_pixels[x, y]
            original = source_pixels[x, y]
            if candidate[3] > original[3]:
                created_alpha += 1
            if candidate[3] > 0:
                visible_pixels += 1
                if candidate[:3] != original[:3]:
                    rgb_mismatched += 1
    return {
        "visible_pixels": visible_pixels,
        "visible_rgb_mismatched_pixels": rgb_mismatched,
        "created_alpha_pixels": created_alpha,
    }


def load_manifest(path):
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise ValueError("asset manifest must be a JSON array")
    return payload


def audit(args):
    findings = []
    reports = []
    source_boxes = []
    items = load_manifest(args.manifest)
    with Image.open(args.source) as image:
        source_rgba = image.convert("RGBA")
    source_width, source_height = source_rgba.size
    source_area = source_width * source_height
    names = set()
    files_on_disk = {
        path.name for path in args.assets_dir.iterdir()
        if path.is_file() and path.suffix.lower() in {".png", ".webp"}
    }

    for index, item in enumerate(items):
        name = item.get("name")
        role = str(item.get("role", "")).strip().lower()
        prefix = {"item": index + 1, "name": name, "role": role}
        if not name or Path(name).name != name:
            findings.append({"kind": "invalid_asset_name", **prefix})
            continue
        if name in names:
            findings.append({"kind": "duplicate_asset_name", **prefix})
            continue
        names.add(name)
        if role in FORBIDDEN_ROLES or role not in ROLE_LIMITS:
            findings.append({"kind": "forbidden_or_unknown_asset_role", **prefix})
            continue
        if role == "photo" and not args.allow_photo:
            findings.append({"kind": "photo_role_requires_explicit_approval", **prefix})
        if item.get("subject_count") != 1:
            findings.append({"kind": "asset_must_contain_one_subject", **prefix})
        if item.get("contains_text") is not False and role != "logo":
            findings.append({"kind": "raster_asset_contains_or_may_contain_text", **prefix})
        if role in {"icon", "logo", "illustration"} and item.get("background_removed") is not True:
            findings.append({"kind": "background_removal_not_declared", **prefix})
        try:
            x, y, width, height = normalized_box(item.get("source_box"))
        except Exception as exc:
            findings.append({"kind": "invalid_source_box", "message": str(exc), **prefix})
            continue
        if width <= 0 or height <= 0 or x < 0 or y < 0 or x + width > source_width or y + height > source_height:
            findings.append({
                "kind": "source_box_out_of_bounds",
                "source_box": [x, y, width, height],
                "source_size": [source_width, source_height],
                **prefix,
            })
        area_ratio = width * height / source_area if source_area else 1.0
        source_boxes.append({"name": name, "box": (x, y, width, height)})
        if area_ratio > ROLE_LIMITS[role]["max_source_area"]:
            findings.append({
                "kind": "asset_source_region_too_large",
                "area_ratio": round(area_ratio, 8),
                "maximum": ROLE_LIMITS[role]["max_source_area"],
                **prefix,
            })
        path = args.assets_dir / name
        if not path.is_file():
            findings.append({"kind": "asset_file_missing", **prefix})
            continue
        stats = alpha_stats(path)
        with Image.open(path) as image:
            asset_rgba = image.convert("RGBA")
        source_match = {
            "visible_pixels": None,
            "visible_rgb_mismatched_pixels": None,
            "created_alpha_pixels": None,
        }
        if asset_rgba.size != (width, height):
            findings.append({
                "kind": "asset_size_does_not_match_source_box",
                "asset_size": list(asset_rgba.size),
                "source_box_size": [width, height],
                **prefix,
            })
        elif x >= 0 and y >= 0 and x + width <= source_width and y + height <= source_height:
            source_crop = source_rgba.crop((x, y, x + width, y + height))
            source_match = source_match_stats(asset_rgba, source_crop)
            if source_match["visible_rgb_mismatched_pixels"]:
                findings.append({
                    "kind": "asset_redrawn_or_recolored",
                    "mismatched_pixels": source_match["visible_rgb_mismatched_pixels"],
                    **prefix,
                })
            if source_match["created_alpha_pixels"]:
                findings.append({
                    "kind": "asset_contains_pixels_absent_from_source",
                    "created_alpha_pixels": source_match["created_alpha_pixels"],
                    **prefix,
                })
        report = {
            **prefix,
            "source_box": [x, y, width, height],
            "source_area_ratio": area_ratio,
            **stats,
            **source_match,
        }
        reports.append(report)
        if role in {"icon", "logo", "illustration"}:
            if not stats["has_alpha"]:
                findings.append({"kind": "asset_missing_alpha", **prefix})
            if stats["transparent_ratio"] < ROLE_LIMITS[role]["min_transparency"]:
                findings.append({
                    "kind": "opaque_rectangular_crop",
                    "transparent_ratio": stats["transparent_ratio"],
                    "minimum": ROLE_LIMITS[role]["min_transparency"],
                    **prefix,
                })
            if stats["partial_alpha_pixels"] < args.min_partial_alpha_pixels:
                findings.append({"kind": "asset_edge_not_smoothed", **prefix})
            if stats["bbox"] and min(stats["margins"]) < args.min_margin:
                findings.append({
                    "kind": "asset_touches_crop_edge",
                    "margins": stats["margins"],
                    "minimum": args.min_margin,
                    **prefix,
                })
            if (
                stats["visible_coverage_in_bbox"] > args.max_rectangular_coverage
                and (
                    stats["visible_bbox_aspect"] > args.rectangular_aspect_threshold
                    or stats["visible_bbox_aspect"] < 1 / args.rectangular_aspect_threshold
                )
            ):
                findings.append({
                    "kind": "rectangular_composite_or_slice",
                    "coverage": stats["visible_coverage_in_bbox"],
                    "aspect": stats["visible_bbox_aspect"],
                    **prefix,
                })

    for unlisted in sorted(files_on_disk - names):
        findings.append({"kind": "unlisted_asset_file", "name": unlisted})
    for missing in sorted(names - files_on_disk):
        if not any(item.get("kind") == "asset_file_missing" and item.get("name") == missing for item in findings):
            findings.append({"kind": "asset_file_missing", "name": missing})

    if source_boxes:
        coverage = Image.new("1", (source_width, source_height), 0)
        coverage_draw = ImageDraw.Draw(coverage)
        for item in source_boxes:
            x, y, width, height = item["box"]
            coverage_draw.rectangle((x, y, x + width - 1, y + height - 1), fill=1)
        covered_pixels = sum(coverage.histogram()[1:])
        source_coverage = covered_pixels / source_area if source_area else 1.0
        if source_coverage > args.max_source_coverage:
            findings.append({
                "kind": "asset_source_boxes_cover_too_much_of_page",
                "coverage": source_coverage,
                "maximum": args.max_source_coverage,
            })
        for left_index, left in enumerate(source_boxes):
            lx, ly, lw, lh = left["box"]
            for right in source_boxes[left_index + 1:]:
                rx, ry, rw, rh = right["box"]
                vertical_overlap = max(0, min(ly + lh, ry + rh) - max(ly, ry))
                horizontal_overlap = max(0, min(lx + lw, rx + rw) - max(lx, rx))
                intersection = vertical_overlap * horizontal_overlap
                if intersection >= args.max_pair_overlap_ratio * min(lw * lh, rw * rh):
                    findings.append({
                        "kind": "overlapping_source_boxes",
                        "assets": [left["name"], right["name"]],
                        "intersection_pixels": intersection,
                    })
                vertical_edge_gap = min(abs((lx + lw) - rx), abs((rx + rw) - lx))
                horizontal_edge_gap = min(abs((ly + lh) - ry), abs((ry + rh) - ly))
                side_tiles = (
                    vertical_edge_gap <= args.tile_gap
                    and vertical_overlap >= args.tile_overlap_ratio * min(lh, rh)
                )
                stacked_tiles = (
                    horizontal_edge_gap <= args.tile_gap
                    and horizontal_overlap >= args.tile_overlap_ratio * min(lw, rw)
                )
                if side_tiles or stacked_tiles:
                    findings.append({
                        "kind": "adjacent_source_tiles",
                        "assets": [left["name"], right["name"]],
                        "gap": min(vertical_edge_gap, horizontal_edge_gap),
                    })

    if args.contact_sheet:
        make_contact_sheet(args.assets_dir, reports, args.contact_sheet)

    return {
        "status": "pass" if not findings else "fail",
        "asset_count": len(reports),
        "assets": reports,
        "findings": findings,
    }


def checker_tile(width, height, step=12):
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    for y in range(0, height, step):
        for x in range(0, width, step):
            if (x // step + y // step) % 2:
                draw.rectangle((x, y, x + step - 1, y + step - 1), fill="#D8DEE8")
    return image


def make_contact_sheet(assets_dir, reports, output):
    cell_width, cell_height = 260, 220
    columns = 4
    rows = max(1, math.ceil(len(reports) / columns))
    sheet = Image.new("RGB", (columns * cell_width, rows * cell_height), "#F4F6F8")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    for index, report in enumerate(reports):
        col, row = index % columns, index // columns
        left, top = col * cell_width, row * cell_height
        preview = checker_tile(220, 165)
        with Image.open(assets_dir / report["name"]) as image:
            rgba = image.convert("RGBA")
        rgba.thumbnail((200, 145), Image.Resampling.LANCZOS)
        x = (preview.width - rgba.width) // 2
        y = (preview.height - rgba.height) // 2
        preview.paste(rgba, (x, y), rgba)
        sheet.paste(preview, (left + 20, top + 12))
        draw.text((left + 20, top + 182), f"{report['name']} [{report['role']}]", fill="#18212B", font=font)
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output)


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("assets_dir", type=Path)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--contact-sheet", type=Path)
    parser.add_argument("--min-margin", type=int, default=2)
    parser.add_argument("--min-partial-alpha-pixels", type=int, default=1)
    parser.add_argument("--allow-photo", action="store_true")
    parser.add_argument("--max-source-coverage", type=float, default=0.30)
    parser.add_argument("--tile-gap", type=int, default=1)
    parser.add_argument("--tile-overlap-ratio", type=float, default=0.80)
    parser.add_argument("--max-pair-overlap-ratio", type=float, default=0.20)
    parser.add_argument("--max-rectangular-coverage", type=float, default=0.90)
    parser.add_argument("--rectangular-aspect-threshold", type=float, default=1.5)
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        result = audit(args)
    except Exception as exc:
        result = {"status": "error", "findings": [{"kind": "audit_error", "message": str(exc)}]}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"status={result['status']}")
        for finding in result.get("findings", []):
            print(f"- {finding['kind']}: {finding}")
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
