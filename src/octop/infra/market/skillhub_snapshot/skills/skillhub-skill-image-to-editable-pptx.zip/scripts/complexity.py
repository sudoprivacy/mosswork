#!/usr/bin/env python3
"""Score a reconstruction inventory and recommend an Artifact Tool workflow."""
import argparse
import json
import sys


def score_layout(data):
    els = data.get("elements", [])
    n = len(els)
    counts = {}
    for el in els:
        t = str(el.get("type", "unknown"))
        counts[t] = counts.get(t, 0) + 1

    score = min(42.0, n * 0.65)
    score += counts.get("freeform", 0) * 2.6
    score += counts.get("table", 0) * 4.0
    score += counts.get("image", 0) * 1.4
    score += counts.get("line", 0) * 0.45
    score += sum(1.2 for e in els if e.get("type") == "text" and "\n" in str(e.get("text", "")))
    score += sum(0.8 for e in els if isinstance(e.get("fill"), dict))
    score += 10 if n >= 80 else 0
    score += 8 if counts.get("freeform", 0) >= 10 else 0
    score += 8 if counts.get("image", 0) >= 8 else 0
    return min(100, round(score, 1)), counts


def recommend(score):
    if score <= 40:
        return "direct-rebuild", "@oai/artifact-tool"
    if score <= 70:
        return "measured-rebuild", "@oai/artifact-tool"
    return "pixel-mapped-rebuild", "@oai/artifact-tool"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("layout")
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    args = ap.parse_args()
    try:
        with open(args.layout, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as exc:
        print(f"ERROR: cannot read layout: {exc}")
        return 2
    score, counts = score_layout(data)
    mode, engine = recommend(score)
    result = {"complexity_score": score, "recommended_mode": mode,
              "recommended_engine": engine, "element_counts": counts}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"complexity_score: {score}/100")
        print(f"recommended_mode: {mode}")
        print(f"recommended_engine: {engine}")
        print("element_counts: " + json.dumps(counts, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
