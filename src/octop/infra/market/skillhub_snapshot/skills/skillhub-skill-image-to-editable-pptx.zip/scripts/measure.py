#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""像素测量工具 —— 把「目测截图猜坐标」换成可复现的数值测量。

这是图片重建工作流的重要测量工具：先量准，再写元素清单和 Artifact Tool 构建器，
能省掉大半来回返工。

子命令
------
  info     IMG                                    图片尺寸 / 模式
  grid     IMG -o out.png [--step 50]             叠加坐标网格（协助目视定位）
  point    IMG --x 120 --y 40                     单像素取色
  avg      IMG --x 10 --y 10 --w 200 --h 100      区域均值取色
  dominant IMG --x 10 --y 10 --w 200 --h 100      区域主色 Top5（含占比）
  ink      IMG --x X1 --y Y1 --x2 X2 --y2 Y2      墨迹包围盒（文字/图形的真实外框）
  rows     IMG --x X1 --y Y1 --x2 X2 --y2 Y2      按行分段 + 每行的横向分段
  cols     IMG --x X1 --y Y1 --x2 X2 --y2 Y2      按列分段（找卡片/列的左右边界）
  bands    IMG --x X1 --y Y1 --x2 X2 --y2 Y2      纵向色带变化点（找分层背景）
  compare  A.png B.png --x X1 --y Y1 --x2 X2 --y2 Y2
                                                  两图同区域墨迹包围盒对比（校验迭代用）

选色默认只统计「深色/彩色」像素，可用 --pred 切换：
  ink | dark | blue | green | red | gray | any

示例
----
  python scripts/measure.py ink   orig.jpg --x 44 --y 415 --x2 425 --y2 515
  python scripts/measure.py rows  orig.jpg --x 44 --y 415 --x2 425 --y2 845
  python scripts/measure.py cols  orig.jpg -y 600 --x 0 --x2 1672
  python scripts/measure.py compare orig.jpg output/preview.png \
      --x 570 --y 292 --x2 748 --y2 346
"""
from __future__ import annotations

import argparse
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, bad, hint, ok, run  # noqa: E402

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:  # pragma: no cover
    Image = None


# ────────────────────────────── 谓词 ──────────────────────────────
def pred_of(name):
    n = (name or "ink").lower()
    if n == "any":
        return lambda c: True
    if n == "ink":
        return lambda c: sum(c[:3]) < 600
    if n == "dark":
        return lambda c: sum(c[:3]) < 400
    if n == "blue":
        return lambda c: c[2] > 100 and c[2] - c[0] > 55 and c[0] < 140
    if n == "green":
        return lambda c: c[1] > 85 and c[1] - c[0] > 30 and c[1] - c[2] > 8
    if n == "red":
        return lambda c: c[0] > 130 and c[0] - c[1] > 55 and c[0] - c[2] > 45
    if n == "gray":
        return lambda c: sum(c[:3]) < 430 and max(c[:3]) - min(c[:3]) < 40
    raise SkillError(f"未知的 --pred 取值：{name}",
                     reason="支持的取值为 ink / dark / blue / green / red / gray / any。",
                     next_steps=["改用 --pred ink（默认，最通用）。"],
                     doc="references/reconstruction-and-qa.md")


def hx(c):
    return "%02X%02X%02X" % (c[0], c[1], c[2])


class Img:
    def __init__(self, path):
        if Image is None:
            raise SkillError("缺少依赖：pillow",
                             reason="测量工具需要 Pillow 读图。",
                             next_steps=["pip install pillow"],
                             doc="references/reconstruction-and-qa.md")
        if not os.path.exists(path):
            raise SkillError(f"找不到图片：{path}",
                             reason="路径不存在或未加引号（中文/空格路径需加引号）。",
                             next_steps=["确认路径后重试，例如：\n     python scripts/measure.py info \"my dir/a b.jpg\""],
                             doc="references/reconstruction-and-qa.md")
        self.im = Image.open(path).convert("RGB")
        self.px = self.im.load()
        self.w, self.h = self.im.size


# ────────────────────────────── 分段算法 ──────────────────────────────
def seg_cols(img, x1, y1, x2, y2, pred, gap=8, minw=3, minpx=1):
    on = []
    for x in range(x1, x2):
        n = sum(1 for y in range(y1, y2) if pred(img.px[x, y]))
        on.append(n >= minpx)
    return _merge([(x1 + i, x1 + i) for i, v in enumerate(on) if v], gap, minw)


def seg_rows(img, x1, y1, x2, y2, pred, gap=4, minh=3, minpx=2):
    on = []
    for y in range(y1, y2):
        n = sum(1 for x in range(x1, x2) if pred(img.px[x, y]))
        on.append(n >= minpx)
    return _merge([(y1 + i, y1 + i) for i, v in enumerate(on) if v], gap, minh)


def _merge(pts, gap, minw):
    out = []
    for a, _ in pts:
        if out and a - out[-1][1] <= gap:
            out[-1][1] = a
        else:
            out.append([a, a])
    return [(a, b) for a, b in out if b - a + 1 >= minw]


def bbox(img, x1, y1, x2, y2, pred, minrow=2):
    ys = [y for y in range(y1, y2)
          if sum(1 for x in range(x1, x2) if pred(img.px[x, y])) >= minrow]
    xs = [x for x in range(x1, x2)
          if any(pred(img.px[x, y]) for y in range(y1, y2))]
    return (xs[0], ys[0], xs[-1], ys[-1]) if xs and ys else None


# ────────────────────────────── 子命令 ──────────────────────────────
def cmd_info(a):
    im = Img(a.image)
    print(f"尺寸: {im.w} x {im.h} px   比例: {im.w / im.h:.4f}")
    print(f"建议 slide.width_px = {im.w}, height_px = {im.h}, width_in = 13.333")
    return 0


def cmd_grid(a):
    im = Img(a.image)
    g = im.im.copy()
    d = ImageDraw.Draw(g)
    try:
        f = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Bold.ttf", 16)
    except Exception:
        f = ImageFont.load_default()
    for x in range(0, im.w, a.step):
        major = x % (a.step * 2) == 0
        d.line([(x, 0), (x, im.h)], fill=(255, 0, 0) if major else (255, 190, 190),
               width=2 if major else 1)
        if major:
            d.text((x + 2, 2), str(x), fill=(200, 0, 0), font=f)
    for y in range(0, im.h, a.step):
        major = y % (a.step * 2) == 0
        d.line([(0, y), (im.w, y)], fill=(255, 0, 0) if major else (255, 190, 190),
               width=2 if major else 1)
        if major:
            d.text((2, y + 2), str(y), fill=(200, 0, 0), font=f)
    g.save(a.out)
    ok(f"网格图已保存：{a.out}（红线为 {a.step * 2}px 整数倍，便于目视定位）")
    return 0


def cmd_point(a):
    im = Img(a.image)
    x, y = max(0, min(a.x, im.w - 1)), max(0, min(a.y, im.h - 1))
    print(hx(im.px[x, y]))
    return 0


def cmd_avg(a):
    im = Img(a.image)
    box = (a.x, a.y, min(a.x + max(1, a.w), im.w), min(a.y + max(1, a.h), im.h))
    r, g, b = im.im.crop(box).resize((1, 1), Image.LANCZOS).getpixel((0, 0))
    print(f"{r:02X}{g:02X}{b:02X}")
    return 0


def cmd_dominant(a):
    im = Img(a.image)
    box = (a.x, a.y, min(a.x + max(1, a.w), im.w), min(a.y + max(1, a.h), im.h))
    region = im.im.crop(box)
    q = region.quantize(colors=16)
    pal = q.getpalette()
    total = region.size[0] * region.size[1]
    for cnt, idx in sorted(q.getcolors(), reverse=True)[:5]:
        r, g, b = pal[idx * 3: idx * 3 + 3]
        print(f"{r:02X}{g:02X}{b:02X}  {cnt:6d}  {cnt / total:5.1%}")
    return 0


def _need_box(a):
    if a.x2 is None or a.y2 is None:
        raise SkillError("缺少测量范围",
                         reason="该子命令需要 --x --y --x2 --y2 指定矩形区域。",
                         next_steps=["例如：--x 44 --y 415 --x2 425 --y2 845"],
                         doc="references/reconstruction-and-qa.md")


def cmd_ink(a):
    im = Img(a.image)
    _need_box(a)
    p = pred_of(a.pred)
    b = bbox(im, a.x, a.y, a.x2, a.y2, p)
    if not b:
        bad("该区域内没有匹配的像素 —— 换个 --pred 或核对坐标。")
        hint("先用 `measure.py grid` 出网格图确认区域选对了。")
        return 1
    print(f"墨迹包围盒: x {b[0]}–{b[2]}  y {b[1]}–{b[3]}")
    print(f"宽 {b[2] - b[0] + 1} px   高 {b[3] - b[1] + 1} px")
    print(f"可直接用于元素清单: \"x\": {b[0]}, \"y\": {b[1]}, "
          f"\"w\": {b[2] - b[0] + 1}, \"h\": {b[3] - b[1] + 1}")
    return 0


def cmd_rows(a):
    im = Img(a.image)
    _need_box(a)
    p = pred_of(a.pred)
    for r1, r2 in seg_rows(im, a.x, a.y, a.x2, a.y2, p, gap=a.gap):
        cols = seg_cols(im, a.x, r1, a.x2, r2 + 1, p, gap=max(a.gap, 8))
        print(f"y {r1:4d}–{r2:4d} (h={r2 - r1 + 1:3d})  横向分段: "
              f"{[(s, e) for s, e in cols]}")
    return 0


def cmd_cols(a):
    im = Img(a.image)
    _need_box(a)
    p = pred_of(a.pred)
    for c1, c2 in seg_cols(im, a.x, a.y, a.x2, a.y2, p, gap=max(a.gap, 10)):
        print(f"x {c1:4d}–{c2:4d} (w={c2 - c1 + 1:4d})")
    return 0


def cmd_bands(a):
    im = Img(a.image)
    _need_box(a)
    step = max(1, a.step)
    x = a.x + (a.x2 - a.x) // 2
    prev = None
    for y in range(a.y, a.y2):
        c = im.px[x, y]
        key = (c[0] // step * step, c[1] // step * step, c[2] // step * step)
        if key != prev:
            print(f"  y={y:4d}  {hx(c)}")
            prev = key
    hint(f"（采样列 x={x}，整数化步长 {step}；调小 --step 看更细的分层）")
    return 0


def cmd_compare(a):
    A, B = Img(a.image), Img(a.other)
    _need_box(a)
    p = pred_of(a.pred)
    ba = bbox(A, a.x, a.y, a.x2, a.y2, p)
    bb = bbox(B, a.x, a.y, a.x2, a.y2, p)
    if not ba or not bb:
        bad(f"有一侧找不到墨迹：A={ba} B={bb}")
        hint("把 --x/--y/--x2/--y2 收紧到该文字块附近重试。")
        return 1
    wa, ha = ba[2] - ba[0] + 1, ba[3] - ba[1] + 1
    wb, hb = bb[2] - bb[0] + 1, bb[3] - bb[1] + 1
    print(f"基准图 : x {ba[0]}–{ba[2]}  y {ba[1]}–{ba[3]}   宽 {wa}  高 {ha}")
    print(f"重建图 : x {bb[0]}–{bb[2]}  y {bb[1]}–{bb[3]}   宽 {wb}  高 {hb}")
    print(f"偏差   : Δx {bb[0] - ba[0]:+d}  Δy {bb[1] - ba[1]:+d}  "
          f"Δ宽 {wb - wa:+d}  Δ高 {hb - ha:+d}")
    if abs(wb - wa) > 5 and wa > 0:
        scale = wa / wb
        print(f"建议   : 宽度偏差>5px → size_pt × {scale:.3f}"
              f"（对照 references/artifact-tool-workflow.md 的字体策略）")
    else:
        ok("宽度偏差在 ±5px 内，视为匹配。")
    return 0


def build_parser():
    ap = argparse.ArgumentParser(
        prog="measure.py",
        description="像素测量工具：量准坐标、颜色和边界，再写元素清单与构建器。")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def box(sp):
        sp.add_argument("--x", type=int, required=True)
        sp.add_argument("--y", type=int, required=True)
        sp.add_argument("--x2", type=int, required=True)
        sp.add_argument("--y2", type=int, required=True)
        sp.add_argument("--pred", default="ink",
                        help="ink|dark|blue|green|red|gray|any（默认 ink）")
        sp.add_argument("--gap", type=int, default=8, help="合并间隔（px）")

    sp = sub.add_parser("info", help="图片尺寸")
    sp.add_argument("image")
    sp.set_defaults(fn=cmd_info)

    sp = sub.add_parser("grid", help="叠加坐标网格图")
    sp.add_argument("image")
    sp.add_argument("-o", "--out", default="grid.png")
    sp.add_argument("--step", type=int, default=50)
    sp.set_defaults(fn=cmd_grid)

    sp = sub.add_parser("point", help="单像素取色")
    sp.add_argument("image")
    sp.add_argument("--x", type=int, required=True)
    sp.add_argument("--y", type=int, required=True)
    sp.set_defaults(fn=cmd_point)

    for name, fn in (("avg", cmd_avg), ("dominant", cmd_dominant)):
        sp = sub.add_parser(name, help="区域取色")
        sp.add_argument("image")
        sp.add_argument("--x", type=int, required=True)
        sp.add_argument("--y", type=int, required=True)
        sp.add_argument("--w", type=int, default=100)
        sp.add_argument("--h", type=int, default=100)
        sp.set_defaults(fn=fn)

    sp = sub.add_parser("ink", help="墨迹包围盒")
    sp.add_argument("image")
    box(sp)
    sp.set_defaults(fn=cmd_ink)

    sp = sub.add_parser("rows", help="按行分段")
    sp.add_argument("image")
    box(sp)
    sp.set_defaults(fn=cmd_rows)

    sp = sub.add_parser("cols", help="按列分段")
    sp.add_argument("image")
    box(sp)
    sp.set_defaults(fn=cmd_cols)

    sp = sub.add_parser("bands", help="纵向色带变化点")
    sp.add_argument("image")
    sp.add_argument("--x", type=int, required=True)
    sp.add_argument("--y", type=int, required=True)
    sp.add_argument("--x2", type=int, required=True)
    sp.add_argument("--y2", type=int, required=True)
    sp.add_argument("--step", type=int, default=12)
    sp.set_defaults(fn=cmd_bands)

    sp = sub.add_parser("compare", help="两图同区域包围盒对比")
    sp.add_argument("image")
    sp.add_argument("other")
    box(sp)
    sp.set_defaults(fn=cmd_compare)
    return ap


def main():
    a = build_parser().parse_args()
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(run(main))
