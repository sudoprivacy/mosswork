#!/usr/bin/env python3
"""Run the same fidelity gate on a PowerPoint/WPS/Presentations rendered page.

This is useful when the batch runner cannot find LibreOffice locally. A passing
report still requires a person or agent to inspect the side-by-side image.
"""
import argparse
import json
from pathlib import Path

from _runtime import read_json
from batch_convert import compare_render, structure_check, write_json, bind_assets, check_clean_background
from visual_inventory import audit_backdrop_removal
from fidelity_gate import assess


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source', type=Path)
    ap.add_argument('rendered', type=Path)
    ap.add_argument('layout', type=Path)
    ap.add_argument('pptx', type=Path)
    ap.add_argument('-o', '--out-dir', type=Path, required=True)
    ap.add_argument('--max-rms', type=float, default=.15)
    args = ap.parse_args(argv)
    if not 0 <= args.max_rms <= 1:
        ap.error('--max-rms must be between 0 and 1')
    args.out_dir.mkdir(parents=True, exist_ok=True)
    try:
        layout = read_json(args.layout)
        bind_assets(layout, args.layout, args.layout.parent)
        check_clean_background(layout, args.source)
        comparison = compare_render(args.source, args.rendered, args.out_dir, layout)
        structure = structure_check(args.pptx, layout)
        issues = assess(comparison, args.max_rms)
        if structure['visual_inventory']['status'] == 'pass':
            audit_backdrop_removal(layout, args.source, args.layout.parent)
        if structure['status'] != 'pass':
            issues.append('PPTX object and editable-text structure mismatch')
        review = layout.get('review', {})
        if review.get('inventory_complete') is not True or review.get('text_verified') is not True:
            issues.append('Source inventory or text transcription has not been checked')
        if any(t.get('needs_review') is True for t in layout.get('texts', [])):
            issues.append('Unresolved OCR text')
        result = {'status': 'pass' if not issues else 'needs_review', 'issues': issues,
                  'comparison': comparison, 'structure': structure,
                  'visual_inspection_required': True}
    except Exception as exc:
        result = {'status': 'failed', 'issues': [str(exc)]}
    write_json(args.out_dir / 'qa-report.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'pass' else (1 if result['status'] == 'failed' else 2)


if __name__ == '__main__':
    raise SystemExit(main())
