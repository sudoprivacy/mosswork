#!/usr/bin/env python3
"""Validate a transparent cutout and write alpha/dark/light QA previews."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from PIL import Image


def composite(rgba, color):
    base = Image.new("RGBA", rgba.size, (*color, 255))
    return Image.alpha_composite(base, rgba).convert("RGB")


def opaque_rgb_rms(source, output, threshold):
    source_rgb = source.convert("RGB")
    output_rgb = output.convert("RGB")
    alpha = output.getchannel("A")
    source_pixels = source_rgb.load()
    output_pixels = output_rgb.load()
    alpha_pixels = alpha.load()
    square_sum = 0
    samples = 0
    mismatched_pixels = 0
    for y in range(output.height):
        for x in range(output.width):
            if alpha_pixels[x, y] < threshold:
                continue
            first = source_pixels[x, y]
            second = output_pixels[x, y]
            if first != second:
                mismatched_pixels += 1
            for a, b in zip(first, second):
                square_sum += (int(a) - int(b)) ** 2
                samples += 1
    rms = math.sqrt(square_sum / samples) / 255 if samples else 0.0
    return rms, mismatched_pixels, samples // 3


def audit(args):
    findings = []
    with Image.open(args.image) as image:
        has_alpha = image.mode in {"RGBA", "LA"} or "transparency" in image.info
        output = image.convert("RGBA")
    if not has_alpha:
        findings.append({"kind": "missing_alpha_channel"})
    alpha = output.getchannel("A")
    histogram = alpha.histogram()
    total = output.width * output.height
    transparent = histogram[0]
    opaque = histogram[255]
    partial = total - transparent - opaque
    transparent_ratio = transparent / total if total else 0.0
    foreground_ratio = (total - transparent) / total if total else 0.0
    if transparent_ratio < args.min_transparent_ratio:
        findings.append({
            "kind": "insufficient_transparency",
            "actual": transparent_ratio,
            "minimum": args.min_transparent_ratio,
        })
    if foreground_ratio < args.min_foreground_ratio:
        findings.append({
            "kind": "foreground_missing",
            "actual": foreground_ratio,
            "minimum": args.min_foreground_ratio,
        })
    if args.require_smooth_edges and partial < args.min_partial_alpha_pixels:
        findings.append({
            "kind": "hard_or_missing_alpha_edge",
            "partial_alpha_pixels": partial,
            "minimum": args.min_partial_alpha_pixels,
        })

    rgb_rms = None
    mismatched = None
    compared = None
    if args.source:
        with Image.open(args.source) as image:
            source = image.convert("RGBA")
        if source.size != output.size:
            findings.append({
                "kind": "source_size_mismatch",
                "source": list(source.size),
                "output": list(output.size),
            })
        else:
            rgb_rms, mismatched, compared = opaque_rgb_rms(
                source, output, args.opaque_alpha_threshold
            )
            if rgb_rms > args.max_opaque_rgb_rms:
                findings.append({
                    "kind": "opaque_foreground_rgb_changed",
                    "rms": rgb_rms,
                    "maximum": args.max_opaque_rgb_rms,
                    "mismatched_pixels": mismatched,
                    "compared_pixels": compared,
                })

    if args.preview_dir:
        args.preview_dir.mkdir(parents=True, exist_ok=True)
        alpha.save(args.preview_dir / "alpha.png")
        composite(output, (20, 24, 32)).save(args.preview_dir / "preview-dark.png")
        composite(output, (255, 255, 255)).save(args.preview_dir / "preview-light.png")
        composite(output, (255, 0, 255)).save(args.preview_dir / "preview-magenta.png")

    return {
        "status": "pass" if not findings else "fail",
        "size": [output.width, output.height],
        "transparent_ratio": round(transparent_ratio, 8),
        "foreground_ratio": round(foreground_ratio, 8),
        "partial_alpha_pixels": partial,
        "opaque_rgb_rms": None if rgb_rms is None else round(rgb_rms, 8),
        "opaque_rgb_mismatched_pixels": mismatched,
        "opaque_rgb_compared_pixels": compared,
        "findings": findings,
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--preview-dir", type=Path)
    parser.add_argument("--min-transparent-ratio", type=float, default=0.01)
    parser.add_argument("--min-foreground-ratio", type=float, default=0.01)
    parser.add_argument("--require-smooth-edges", action="store_true")
    parser.add_argument("--min-partial-alpha-pixels", type=int, default=1)
    parser.add_argument("--opaque-alpha-threshold", type=int, default=250)
    parser.add_argument("--max-opaque-rgb-rms", type=float, default=0.0)
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        result = audit(args)
    except Exception as exc:
        result = {"status": "error", "findings": [{"kind": "audit_error", "message": str(exc)}]}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"status={result['status']}")
        for finding in result.get("findings", []):
            print(f"- {finding['kind']}: {finding}")
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
