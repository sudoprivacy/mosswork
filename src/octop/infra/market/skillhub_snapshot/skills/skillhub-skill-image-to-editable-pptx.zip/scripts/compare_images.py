#!/usr/bin/env python3
"""Compare a final PPTX render with its source image and write diagnostics.

The Presentations renderer uses isotropic scaling and deliberately treats the
requested width/height as approximate maxima.  A strict pixel-size equality
check therefore rejects valid renders before any visual comparison happens.
By default this tool now normalizes a near-identical aspect-ratio render to the
reference canvas and records that normalization in its JSON output.  Material
aspect-ratio differences remain hard errors.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageEnhance, ImageOps


def parse_color(value: str):
    raw = value.strip().lstrip("#")
    if len(raw) != 6:
        raise ValueError("background color must be a six-digit RGB hex value")
    return tuple(int(raw[index:index + 2], 16) for index in (0, 2, 4))


def flatten(image: Image.Image, background):
    rgba = image.convert("RGBA")
    base = Image.new("RGBA", rgba.size, (*background, 255))
    return Image.alpha_composite(base, rgba).convert("RGB")


def normalized_rms(first: Image.Image, second: Image.Image):
    diff = ImageChops.difference(first, second)
    histogram = diff.histogram()
    square_sum = sum((index % 256) ** 2 * count for index, count in enumerate(histogram))
    channels = len(first.getbands())
    samples = first.width * first.height * channels
    return math.sqrt(square_sum / samples) / 255 if samples else 0.0


def aspect_ratio(size):
    width, height = size
    return width / height if height else 0.0


def normalize_render_size(reference, rendered, max_aspect_drift):
    if reference.size == rendered.size:
        return rendered, False, 0.0
    reference_ratio = aspect_ratio(reference.size)
    rendered_ratio = aspect_ratio(rendered.size)
    if not reference_ratio or not rendered_ratio:
        raise ValueError("reference and rendered images must have non-zero dimensions")
    drift = abs(rendered_ratio / reference_ratio - 1.0)
    if drift > max_aspect_drift:
        raise ValueError(
            f"image aspect ratios differ: reference={reference.size}, rendered={rendered.size}, "
            f"drift={drift:.4%} > {max_aspect_drift:.4%}"
        )
    return rendered.resize(reference.size, Image.Resampling.LANCZOS), True, drift


def compare(args):
    background = parse_color(args.reference_bg)
    with Image.open(args.reference) as image:
        reference = flatten(image, background)
    with Image.open(args.rendered) as image:
        rendered = flatten(image, background)

    original_render_size = rendered.size
    normalized = False
    aspect_drift = 0.0
    if reference.size != rendered.size:
        if args.size_mode == "strict":
            raise ValueError(
                f"image sizes differ: reference={reference.size}, rendered={rendered.size}; "
                "use --size-mode normalize for the renderer's expected rounding difference"
            )
        rendered, normalized, aspect_drift = normalize_render_size(
            reference, rendered, args.max_aspect_drift
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    rms = normalized_rms(reference, rendered)
    raw_difference = ImageChops.difference(reference, rendered)
    enhanced = ImageEnhance.Contrast(ImageOps.autocontrast(raw_difference)).enhance(2)
    enhanced.save(args.output_dir / "difference.png")

    side_by_side = Image.new("RGB", (reference.width * 2, reference.height), "white")
    side_by_side.paste(reference, (0, 0))
    side_by_side.paste(rendered, (reference.width, 0))
    side_by_side.save(args.output_dir / "side_by_side.png")

    return {
        "status": "pass" if rms <= args.max_rms else "fail",
        "rms_diff": round(rms, 8),
        "max_rms": args.max_rms,
        "size": list(reference.size),
        "original_render_size": list(original_render_size),
        "render_resampled": normalized,
        "aspect_drift": round(aspect_drift, 8),
        "side_by_side": str(args.output_dir / "side_by_side.png"),
        "difference": str(args.output_dir / "difference.png"),
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path)
    parser.add_argument("rendered", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-rms", type=float, default=0.12)
    parser.add_argument("--reference-bg", default="FFFFFF")
    parser.add_argument(
        "--size-mode",
        choices=("normalize", "strict"),
        default="normalize",
        help="normalize near-identical render sizes (default) or require exact dimensions",
    )
    parser.add_argument(
        "--max-aspect-drift",
        type=float,
        default=0.005,
        help="maximum relative aspect-ratio drift allowed before normalization",
    )
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        result = compare(args)
        code = 0 if result["status"] == "pass" else 1
    except Exception as exc:
        result = {"status": "error", "message": str(exc)}
        code = 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"status={result['status']}")
        if "rms_diff" in result:
            print(f"rms_diff={result['rms_diff']:.8f} max={result['max_rms']:.8f}")
        elif "message" in result:
            print(result["message"])
    return code


if __name__ == "__main__":
    sys.exit(main())
