"""Per-page continuation and actionable repair evidence for batch reconstruction."""
import hashlib
import importlib.metadata
from pathlib import Path
import shutil
import subprocess

from _runtime import office_commands, read_json


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def runtime_signature(font):
    packages = {}
    for name in ('Pillow', 'numpy', 'python-pptx', 'rapidocr-onnxruntime', 'onnxruntime'):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    fonts = ''
    if shutil.which('fc-match'):
        try:
            fonts = subprocess.run(['fc-match', '-f', '%{family}\n%{file}', font],
                                   capture_output=True, text=True, timeout=10).stdout
        except (OSError, subprocess.TimeoutExpired):
            pass
    office, pdftoppm = office_commands()
    return {'packages': packages, 'font_match': fonts, 'office': office, 'pdftoppm': pdftoppm}


def read_input_binding(path):
    """An unreadable cache entry cannot authorize reuse of measured coordinates."""
    try:
        data = read_json(path)
    except (OSError, ValueError):
        return None
    if isinstance(data, dict) and isinstance(data.get('source_sha256'), str):
        return data
    return None


def continuation_job(job, page_dir, resume):
    """Read measured edits only for the same input bytes and normalized background."""
    if not resume or job.get('layout'):
        return job
    meta = Path(page_dir) / 'input.json'
    measured = Path(page_dir) / 'layout.json'
    if not meta.is_file() or not measured.is_file():
        return job
    previous = read_input_binding(meta)
    if not previous or previous['source_sha256'] != sha256(job['source']):
        return job
    # Generated layout.draft.json is never consumed as an approved reconstruction.
    return {**job, 'layout': str(measured), 'crops': str(Path(page_dir) / 'crops')}


def repair_tasks(result):
    """Return page-local tasks, never a shared deck-wide error allowance."""
    tasks = []
    if result['status'] == 'needs_layout':
        tasks.append({'kind': 'reconstruct', 'priority': 0,
                      'draft': result.get('layout'), 'review_tiles': result.get('review_tiles'),
                      'instruction': '逐块核对源图，列齐视觉对象并创建测量后的 layout.json 和独立素材。'})
        if result.get('ocr_diagnostic'):
            tasks[0]['diagnostic'] = result['ocr_diagnostic']
    elif result['status'] == 'failed':
        tasks.append({'kind': 'execution', 'priority': 0, 'message': result.get('error')})
        if result.get('diagnostic'):
            tasks[0]['diagnostic'] = result['diagnostic']
    else:
        if result.get('render_diagnostic'):
            tasks.append({'kind': 'render', 'priority': 0, 'diagnostic': result['render_diagnostic']})
        for issue in result.get('issues', []):
            tasks.append({'kind': 'blocker', 'priority': 0, 'message': issue})
        for finding in result.get('structure', {}).get('geometry', {}).get('findings', []):
            tasks.append({'kind': 'placement', 'priority': 0, **finding})
        comparison = result.get('comparison', {})
        regions = sorted(comparison.get('regions', []),
                         key=lambda r: (r.get('kind') == 'texts', r.get('rms', 0)), reverse=True)
        for region in regions:
            if (region.get('rms', 0) > .15 or region.get('bad_pixel_fraction', 0) > .09 or
                (region.get('kind') == 'texts' and region.get('edge_recall') is not None and
                 region['edge_recall'] < .72)):
                tasks.append({'kind': 'region', 'priority': 1, **region})
        for tile in comparison.get('tile_alerts', {}).get('worst', []):
            tasks.append({'kind': 'unlisted-detail', 'priority': 2, **tile})
    return tasks


def write_continuation(out, jobs, results, write_json):
    """Preserve the full input order, including failed and not-yet-exported pages."""
    queue = []
    continuation = []
    for job, result in zip(jobs, results):
        page = Path(result['page_dir'])
        next_job = dict(job)
        measured = Path(job['layout']) if job.get('layout') else page / 'layout.json'
        if not job.get('layout') and measured.is_file() and result.get('pptx') and result.get('status') != 'failed':
            next_job.update(layout=str(measured), crops=str(page / 'crops'))
        binding = read_input_binding(page / 'input.json') if next_job.get('layout') else None
        if binding:
            # Preserve an existing binding, including one that has just failed.
            next_job.setdefault('layout_source_sha256', binding['source_sha256'])
            if 'reference_bg' in binding:
                next_job.setdefault('layout_reference_bg', binding['reference_bg'])
        continuation.append(job.get('_invalid_manifest_item', next_job))
        tasks = repair_tasks(result)
        write_json(page / 'repair-tasks.json', {'input_index': result['index'], 'tasks': tasks})
        queue.append({'input_index': result['index'], 'source': result['source'],
                      'status': result['status'], 'page_dir': str(page),
                      'measured_layout': str(measured), 'tasks': str(page / 'repair-tasks.json')})
    write_json(Path(out) / 'continue.json', {'jobs': continuation})
    write_json(Path(out) / 'work-queue.json', {'pages': queue,
               'instruction': '按每页任务修复 measured_layout 指向的文件。清单行格式错误时先改原清单。'
                              '用 --resume 保留页序，文字与坐标应逐页核对。'})
