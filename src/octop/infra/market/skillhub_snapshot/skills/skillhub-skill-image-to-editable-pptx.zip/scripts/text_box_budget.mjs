/** Conservative build-time checks for fixed-size Artifact Tool text boxes. */

function glyphWidthFactor(character) {
  if (/\s/u.test(character)) return 0.33;
  if (/\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Script=Hangul}/u.test(character)) {
    return 1.0;
  }
  if (/[A-Z]/u.test(character)) return 0.7;
  if (/[0-9]/u.test(character)) return 0.62;
  if (/[a-z]/u.test(character)) return 0.55;
  return 0.5;
}

export function estimateTextWidth(text, fontSizePx, { bold = false } = {}) {
  const weightFactor = bold ? 1.06 : 1.0;
  return [...String(text)].reduce(
    (total, character) => total + glyphWidthFactor(character) * fontSizePx * weightFactor,
    0,
  );
}

export function assertTextBoxBudget(
  text,
  position,
  fontSizePx,
  {
    bold = false,
    wrap = false,
    lineHeight = 1.28,
    insets = { left: 0, right: 0, top: 0, bottom: 0 },
    slack = 1.08,
    label = String(text).slice(0, 24),
  } = {},
) {
  if (!(fontSizePx > 0) || !(position?.width > 0) || !(position?.height > 0)) {
    throw new Error(`Invalid text geometry for ${label}`);
  }
  const usableWidth = position.width - (insets.left ?? 0) - (insets.right ?? 0);
  const usableHeight = position.height - (insets.top ?? 0) - (insets.bottom ?? 0);
  const authoredLines = String(text).split("\n");
  let requiredLines = 0;
  let widestLine = 0;
  for (const line of authoredLines) {
    const width = estimateTextWidth(line, fontSizePx, { bold }) * slack;
    widestLine = Math.max(widestLine, width);
    requiredLines += wrap ? Math.max(1, Math.ceil(width / usableWidth)) : 1;
  }
  const requiredHeight = requiredLines * fontSizePx * lineHeight;
  if ((!wrap && widestLine > usableWidth) || requiredHeight > usableHeight) {
    throw new Error(
      `Text box budget failed for ${label}: ` +
      `needs about ${Math.ceil(widestLine)}x${Math.ceil(requiredHeight)}px, ` +
      `has ${Math.floor(usableWidth)}x${Math.floor(usableHeight)}px`,
    );
  }
  return { widestLine, requiredHeight, requiredLines };
}
