#!/usr/bin/env python3
"""Audit a reconstructed PPTX for editable structure, safe raster use, and bounds."""

from __future__ import annotations

import argparse
import hashlib
import json
import posixpath
import re
import sys
import zipfile
from io import BytesIO
from pathlib import Path
from xml.etree import ElementTree as ET

from PIL import Image


P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PR_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"p": P_NS, "a": A_NS, "r": R_NS, "pr": PR_NS}
DRAWABLE_TAGS = {
    f"{{{P_NS}}}sp",
    f"{{{P_NS}}}pic",
    f"{{{P_NS}}}graphicFrame",
    f"{{{P_NS}}}cxnSp",
    f"{{{P_NS}}}grpSp",
}
IMAGE_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff",
    ".svg", ".emf", ".wmf",
}


def natural_key(name: str):
    return [int(part) if part.isdigit() else part for part in re.split(r"(\d+)", name)]


def image_fingerprint(blob: bytes):
    """Hash decoded pixels so lossless re-encoding cannot hide a source screenshot."""
    try:
        with Image.open(BytesIO(blob)) as image:
            rgba = image.convert("RGBA")
            return (rgba.size, hashlib.sha256(rgba.tobytes()).hexdigest())
    except Exception:
        return (None, hashlib.sha256(blob).hexdigest())


def path_fingerprint(path: Path):
    return image_fingerprint(path.read_bytes())


def normalized_text(value: str):
    return re.sub(r"\s+", " ", value).strip()


def load_required_texts(path: str | None):
    if not path:
        return []
    source = Path(path)
    content = source.read_text(encoding="utf-8")
    if source.suffix.lower() == ".json":
        payload = json.loads(content)
        if not isinstance(payload, list):
            raise ValueError("required text JSON must be an array")
        requirements = []
        for item in payload:
            if isinstance(item, str):
                item = {"text": item}
            if not isinstance(item, dict) or not isinstance(item.get("text"), str):
                raise ValueError("each required text item must be a string or an object with text")
            value = normalized_text(item["text"])
            if not value:
                continue
            count = int(item.get("count", 1))
            if count < 1:
                raise ValueError("required text count must be at least 1")
            slide = item.get("slide")
            if slide is not None:
                slide = int(slide)
                if slide < 1:
                    raise ValueError("required text slide numbers start at 1")
            for instance in range(1, count + 1):
                requirements.append({"text": value, "slide": slide, "instance": instance})
        return requirements
    return [
        {"text": normalized_text(line), "slide": None, "instance": 1}
        for line in content.splitlines()
        if normalized_text(line)
    ]


def unmatched_text_requirements(requirements, text_objects):
    """Match each required entry to a distinct editable text object."""
    candidates = []
    for requirement in requirements:
        options = []
        for index, text_object in enumerate(text_objects):
            if requirement["slide"] is not None and text_object["slide"] != requirement["slide"]:
                continue
            if requirement["text"] in text_object["text"]:
                options.append(index)
        candidates.append(options)

    owner = {}

    def assign(requirement_index, seen):
        for object_index in candidates[requirement_index]:
            if object_index in seen:
                continue
            seen.add(object_index)
            if object_index not in owner or assign(owner[object_index], seen):
                owner[object_index] = requirement_index
                return True
        return False

    matched = set()
    for requirement_index in sorted(range(len(requirements)), key=lambda index: len(candidates[index])):
        if assign(requirement_index, set()):
            matched.add(requirement_index)
    return [item for index, item in enumerate(requirements) if index not in matched]


def relationship_map(deck: zipfile.ZipFile, slide_name: str):
    slide_dir = posixpath.dirname(slide_name)
    rel_name = posixpath.join(slide_dir, "_rels", posixpath.basename(slide_name) + ".rels")
    if rel_name not in deck.namelist():
        return {}
    root = ET.fromstring(deck.read(rel_name))
    result = {}
    for rel in root.findall(f"{{{PR_NS}}}Relationship"):
        rel_id = rel.attrib.get("Id")
        target = rel.attrib.get("Target")
        if rel_id and target and not target.startswith(("http:", "https:")):
            if target.startswith("/"):
                result[rel_id] = posixpath.normpath(target.lstrip("/"))
            else:
                result[rel_id] = posixpath.normpath(posixpath.join(slide_dir, target))
    return result


def object_name(element: ET.Element):
    node = element.find(".//p:cNvPr", NS)
    if node is None:
        return "unnamed"
    return node.attrib.get("name") or node.attrib.get("id") or "unnamed"


def object_description(element: ET.Element):
    node = element.find(".//p:cNvPr", NS)
    return (node.attrib.get("descr") or "").strip() if node is not None else ""


def object_box(element: ET.Element):
    xfrm = element.find("./p:spPr/a:xfrm", NS)
    if xfrm is None:
        xfrm = element.find("./p:blipFill/../p:spPr/a:xfrm", NS)
    if xfrm is None:
        xfrm = element.find("./p:xfrm", NS)
    if xfrm is None:
        xfrm = element.find(".//a:xfrm", NS)
    if xfrm is None:
        return None
    off = xfrm.find("a:off", NS)
    ext = xfrm.find("a:ext", NS)
    if off is None or ext is None:
        return None
    try:
        return tuple(int(value) for value in (
            off.attrib.get("x", "0"), off.attrib.get("y", "0"),
            ext.attrib.get("cx", "0"), ext.attrib.get("cy", "0"),
        ))
    except ValueError:
        return None


def picture_media_name(element: ET.Element, rels: dict[str, str]):
    blip = element.find(".//a:blip", NS)
    if blip is None:
        return None
    rel_id = blip.attrib.get(f"{{{R_NS}}}embed")
    return rels.get(rel_id)


def effective_image_ratio(element: ET.Element, media_blob: bytes):
    with Image.open(BytesIO(media_blob)) as image:
        width, height = image.size
    src_rect = element.find(".//a:srcRect", NS)
    if src_rect is not None:
        left = int(src_rect.attrib.get("l", "0")) / 100000
        right = int(src_rect.attrib.get("r", "0")) / 100000
        top = int(src_rect.attrib.get("t", "0")) / 100000
        bottom = int(src_rect.attrib.get("b", "0")) / 100000
        width *= max(0.0, 1 - left - right)
        height *= max(0.0, 1 - top - bottom)
    return width / height if height else None


def validate(args):
    findings = []
    slide_reports = []
    required_texts = load_required_texts(args.required_text_file)

    if args.strict_reconstruction:
        missing_options = []
        if not args.forbid_source_image:
            missing_options.append("--forbid-source-image")
        if not args.required_text_file:
            missing_options.append("--required-text-file")
        if args.expected_picture_count is None:
            missing_options.append("--expected-picture-count")
        for option in missing_options:
            findings.append({
                "kind": "validator_configuration",
                "message": f"strict reconstruction requires {option}",
            })
        if not args.require_aspect_lock:
            findings.append({
                "kind": "validator_configuration",
                "message": "strict reconstruction requires --require-aspect-lock",
            })
        if not args.forbid_groups:
            findings.append({
                "kind": "validator_configuration",
                "message": "strict reconstruction requires --forbid-groups",
            })
        if args.expected_picture_count and not args.approved_image_dir:
            findings.append({
                "kind": "validator_configuration",
                "message": "strict reconstruction with pictures requires --approved-image-dir",
            })
        if args.expected_picture_count and not args.require_all_approved_images:
            findings.append({
                "kind": "validator_configuration",
                "message": "strict reconstruction with pictures requires --require-all-approved-images",
            })
    forbidden_paths = {}
    for path_value in args.forbid_source_image:
        fingerprint = path_fingerprint(Path(path_value))
        forbidden_paths.setdefault(fingerprint, []).append(path_value)
    forbidden = set(forbidden_paths)
    approved = None
    approved_paths = {}
    if args.approved_image_dir:
        approved = set()
        for path in Path(args.approved_image_dir).rglob("*"):
            if not path.is_file() or path.suffix.lower() not in IMAGE_SUFFIXES:
                continue
            fingerprint = path_fingerprint(path)
            approved.add(fingerprint)
            approved_paths.setdefault(fingerprint, []).append(str(path))

    with zipfile.ZipFile(args.pptx) as deck:
        names = set(deck.namelist())
        presentation = ET.fromstring(deck.read("ppt/presentation.xml"))
        size = presentation.find("p:sldSz", NS)
        if size is None:
            raise ValueError("ppt/presentation.xml does not define p:sldSz")
        slide_cx = int(size.attrib["cx"])
        slide_cy = int(size.attrib["cy"])
        slide_area = slide_cx * slide_cy
        slide_names = sorted(
            (name for name in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)),
            key=natural_key,
        )

        total_text_objects = 0
        total_pictures = 0
        total_shapes = 0
        referenced_media = set()
        used_fingerprints = set()
        editable_texts = []

        for media_name in sorted(name for name in names if name.startswith("ppt/media/")):
            fingerprint = image_fingerprint(deck.read(media_name))
            if fingerprint in forbidden:
                findings.append({
                    "kind": "forbidden_source_media_payload",
                    "media": media_name,
                    "source_paths": forbidden_paths.get(fingerprint, []),
                })
            if approved is not None and fingerprint not in approved:
                findings.append({
                    "kind": "unapproved_media_payload",
                    "media": media_name,
                })

        for slide_number, slide_name in enumerate(slide_names, 1):
            root = ET.fromstring(deck.read(slide_name))
            rels = relationship_map(deck, slide_name)
            report = {
                "slide": slide_number,
                "text_objects": 0,
                "pictures": 0,
                "shapes": 0,
                "picture_area_ratio_sum": 0.0,
                "ordinary_picture_area_ratio_sum": 0.0,
            }
            picture_blips = set()
            for element in root.iter():
                if element.tag not in DRAWABLE_TAGS:
                    continue
                name = object_name(element)
                description = object_description(element)
                if element.tag == f"{{{P_NS}}}grpSp" and args.forbid_groups:
                    findings.append({
                        "kind": "grouped_objects_not_supported",
                        "slide": slide_number,
                        "name": name,
                    })
                box = object_box(element)
                if element.tag == f"{{{P_NS}}}sp":
                    total_shapes += 1
                    report["shapes"] += 1
                    if element.find(".//a:t", NS) is not None:
                        total_text_objects += 1
                        report["text_objects"] += 1
                        text_value = normalized_text("".join(
                            node.text or "" for node in element.findall(".//a:t", NS)
                        ))
                        if text_value:
                            editable_texts.append({
                                "text": text_value,
                                "slide": slide_number,
                                "box": list(box) if box else None,
                            })
                if box:
                    x, y, width, height = box
                    tol = args.bounds_tolerance_emu
                    if width <= 0 or height <= 0 or x < -tol or y < -tol or x + width > slide_cx + tol or y + height > slide_cy + tol:
                        findings.append({
                            "kind": "object_outside_slide", "slide": slide_number,
                            "name": name, "box": [x, y, width, height],
                        })
                if element.tag != f"{{{P_NS}}}pic":
                    continue
                total_pictures += 1
                report["pictures"] += 1
                blip = element.find(".//a:blip", NS)
                if blip is not None:
                    picture_blips.add(id(blip))
                    if blip.attrib.get(f"{{{R_NS}}}link"):
                        findings.append({
                            "kind": "external_image_link", "slide": slide_number,
                            "name": name,
                        })
                if args.require_aspect_lock:
                    lock = element.find(".//a:picLocks", NS)
                    locked = lock is not None and lock.attrib.get("noChangeAspect") in {"1", "true"}
                    if not locked:
                        findings.append({
                            "kind": "picture_aspect_not_locked", "slide": slide_number,
                            "name": name,
                        })
                if box:
                    _, _, width, height = box
                    area_ratio = (width * height / slide_area) if slide_area else 1.0
                    report["picture_area_ratio_sum"] += area_ratio
                    report["ordinary_picture_area_ratio_sum"] += area_ratio
                    if area_ratio >= args.max_picture_area_ratio:
                        findings.append({
                            "kind": "large_picture", "slide": slide_number,
                            "name": name, "description": description,
                            "area_ratio": round(area_ratio, 6),
                        })
                media_name = picture_media_name(element, rels)
                if media_name and media_name in names:
                    referenced_media.add(media_name)
                    blob = deck.read(media_name)
                    fingerprint = image_fingerprint(blob)
                    used_fingerprints.add(fingerprint)
                    if fingerprint in forbidden:
                        findings.append({
                            "kind": "forbidden_source_image", "slide": slide_number,
                            "name": name, "media": media_name,
                            "source_paths": forbidden_paths.get(fingerprint, []),
                        })
                    if approved is not None and fingerprint not in approved:
                        findings.append({
                            "kind": "unapproved_media", "slide": slide_number,
                            "name": name, "media": media_name,
                        })
                    if box:
                        try:
                            source_ratio = effective_image_ratio(element, blob)
                        except Exception:
                            source_ratio = None
                        geometry_ratio = box[2] / box[3] if box[3] else None
                        if source_ratio and geometry_ratio:
                            drift = abs(geometry_ratio / source_ratio - 1)
                            if drift > args.max_aspect_drift:
                                findings.append({
                                    "kind": "picture_aspect_drift", "slide": slide_number,
                                    "name": name, "media": media_name,
                                    "drift": round(drift, 9),
                                })
                else:
                    findings.append({
                        "kind": "picture_missing_media", "slide": slide_number,
                        "name": name,
                    })

            for blip in root.findall(".//a:blip", NS):
                if id(blip) in picture_blips:
                    continue
                findings.append({
                    "kind": "non_picture_image_fill",
                    "slide": slide_number,
                    "relationship": blip.attrib.get(f"{{{R_NS}}}embed")
                    or blip.attrib.get(f"{{{R_NS}}}link"),
                })
            if report["ordinary_picture_area_ratio_sum"] > args.max_total_picture_area_ratio:
                findings.append({
                    "kind": "excessive_total_picture_area",
                    "slide": slide_number,
                    "area_ratio_sum": round(report["ordinary_picture_area_ratio_sum"], 6),
                    "maximum": args.max_total_picture_area_ratio,
                })
            report["picture_area_ratio_sum"] = round(report["picture_area_ratio_sum"], 6)
            report["ordinary_picture_area_ratio_sum"] = round(
                report["ordinary_picture_area_ratio_sum"], 6
            )
            slide_reports.append(report)

    if total_text_objects < args.min_text_objects:
        findings.append({
            "kind": "insufficient_text_objects",
            "actual": total_text_objects,
            "minimum": args.min_text_objects,
        })
    if total_pictures < args.min_picture_count:
        findings.append({
            "kind": "insufficient_picture_count",
            "actual": total_pictures,
            "minimum": args.min_picture_count,
        })
    if args.expected_picture_count is not None and total_pictures != args.expected_picture_count:
        findings.append({
            "kind": "picture_count_mismatch",
            "actual": total_pictures,
            "expected": args.expected_picture_count,
        })
    for required in unmatched_text_requirements(required_texts, editable_texts):
        findings.append({
            "kind": "missing_required_text",
            **required,
        })
    if args.require_all_approved_images:
        if approved is None:
            findings.append({
                "kind": "validator_configuration",
                "message": "--require-all-approved-images needs --approved-image-dir",
            })
        else:
            for fingerprint in sorted(approved - used_fingerprints, key=str):
                findings.append({
                    "kind": "approved_media_not_used",
                    "paths": approved_paths.get(fingerprint, []),
                })

    return {
        "status": "pass" if not findings else "fail",
        "slide_count": len(slide_reports),
        "slide_size_emu": [slide_cx, slide_cy],
        "editable_shape_count": total_shapes,
        "editable_text_object_count": total_text_objects,
        "picture_count": total_pictures,
        "referenced_media_count": len(referenced_media),
        "slides": slide_reports,
        "findings": findings,
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--min-text-objects", type=int, default=1)
    parser.add_argument("--min-picture-count", type=int, default=0)
    parser.add_argument("--expected-picture-count", type=int)
    parser.add_argument("--max-picture-area-ratio", type=float, default=0.15)
    parser.add_argument("--max-total-picture-area-ratio", type=float, default=0.30)
    parser.add_argument("--max-aspect-drift", type=float, default=0.001)
    parser.add_argument("--require-aspect-lock", action="store_true")
    parser.add_argument("--bounds-tolerance-emu", type=int, default=0)
    parser.add_argument("--forbid-groups", action="store_true")
    parser.add_argument("--forbid-source-image", action="append", default=[])
    parser.add_argument("--approved-image-dir")
    parser.add_argument("--require-all-approved-images", action="store_true")
    parser.add_argument("--required-text-file")
    parser.add_argument(
        "--strict-reconstruction",
        action="store_true",
        help="require the complete source/text/media/editability audit configuration",
    )
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        result = validate(args)
    except Exception as exc:
        result = {"status": "error", "findings": [{"kind": "validator_error", "message": str(exc)}]}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"status={result['status']}")
        for finding in result.get("findings", []):
            print(f"- {finding['kind']}: {finding}")
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
