#!/usr/bin/env python3
"""Create a transparent PNG while preserving the source foreground RGB.

Use mask mode for complex images.  The mask may come from a semantic image
editor; only its alpha/luminance is used, so the output keeps the original
pixels and geometry.  Edge mode is a deterministic fallback for flat or
near-flat crop backgrounds.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, deque
from pathlib import Path

from PIL import Image, ImageChops, ImageFilter, ImageOps


def parse_hex_color(value):
    raw = value.strip().lstrip("#")
    if len(raw) != 6:
        raise ValueError("background colors must be six-digit RGB hex values")
    return tuple(int(raw[index:index + 2], 16) for index in (0, 2, 4))


def color_distance(first, second):
    return sum(abs(int(a) - int(b)) for a, b in zip(first, second))


def palette_colors(quantized):
    # P 模式每像素 1 字节，正好是 palette 索引；用 tobytes() 而不是 getdata()，
    # 后者在 Pillow 14 起被弃用（且慢）。
    palette = quantized.getpalette() or []
    colors = {}
    for label in set(quantized.tobytes()):
        start = label * 3
        colors[label] = tuple(palette[start:start + 3])
    return colors


def corner_seed_colors(rgb, radius=3):
    width, height = rgb.size
    pixels = rgb.load()
    samples = []
    corners = ((0, 0), (width - 1, 0), (0, height - 1), (width - 1, height - 1))
    for corner_x, corner_y in corners:
        for y in range(max(0, corner_y - radius), min(height, corner_y + radius + 1)):
            for x in range(max(0, corner_x - radius), min(width, corner_x + radius + 1)):
                color = pixels[x, y]
                samples.append(tuple((channel // 8) * 8 for channel in color))
    return [item[0] for item in Counter(samples).most_common(12)]


def connected_background_mask(rgb, *, tolerance=45, palette_size=64, background_colors=None):
    """Return an L mask with 255 only for border-connected background pixels."""
    width, height = rgb.size
    quantized = rgb.quantize(colors=max(8, min(256, palette_size)), method=Image.Quantize.MEDIANCUT)
    label_colors = palette_colors(quantized)
    seeds = list(background_colors or corner_seed_colors(rgb))
    candidate_labels = {
        label
        for label, color in label_colors.items()
        if any(color_distance(color, seed) <= tolerance for seed in seeds)
    }
    labels = list(quantized.tobytes())   # 每字节 = palette 索引，索引即 y*width+x
    visited = bytearray(width * height)
    queue = deque()

    def enqueue(x, y):
        index = y * width + x
        if not visited[index] and labels[index] in candidate_labels:
            visited[index] = 1
            queue.append((x, y))

    for x in range(width):
        enqueue(x, 0)
        enqueue(x, height - 1)
    for y in range(height):
        enqueue(0, y)
        enqueue(width - 1, y)

    while queue:
        x, y = queue.popleft()
        if x:
            enqueue(x - 1, y)
        if x + 1 < width:
            enqueue(x + 1, y)
        if y:
            enqueue(x, y - 1)
        if y + 1 < height:
            enqueue(x, y + 1)

    return Image.frombytes("L", (width, height), bytes(255 if value else 0 for value in visited))


def remove_edge_background(
    image,
    *,
    tolerance=45,
    palette_size=64,
    background_colors=None,
    expand=1,
    feather=1.0,
):
    source = image.convert("RGBA")
    rgb = source.convert("RGB")
    background = connected_background_mask(
        rgb,
        tolerance=tolerance,
        palette_size=palette_size,
        background_colors=background_colors,
    )
    if expand > 0:
        background = background.filter(ImageFilter.MaxFilter(expand * 2 + 1))
    if feather > 0:
        background = background.filter(ImageFilter.GaussianBlur(feather))
    alpha = ImageOps.invert(background)
    alpha = ImageChops.multiply(alpha, source.getchannel("A"))
    output = source.copy()
    output.putalpha(alpha)
    return output


def mask_alpha(mask, mode):
    rgba = mask.convert("RGBA")
    alpha = rgba.getchannel("A")
    if mode == "alpha":
        return alpha
    if mode == "luma":
        return ImageOps.grayscale(rgba.convert("RGB"))
    lo, hi = alpha.getextrema()
    return alpha if lo < 255 else ImageOps.grayscale(rgba.convert("RGB"))


def apply_alpha_mask(
    source,
    mask,
    *,
    mask_mode="auto",
    invert=False,
    resize_mask=False,
    max_aspect_drift=0.005,
    feather=0.0,
):
    rgba = source.convert("RGBA")
    alpha = mask_alpha(mask, mask_mode)
    if alpha.size != rgba.size:
        source_ratio = rgba.width / rgba.height
        mask_ratio = alpha.width / alpha.height
        drift = abs(mask_ratio / source_ratio - 1.0)
        if not resize_mask:
            raise ValueError(
                f"mask size {alpha.size} does not match source {rgba.size}; use --resize-mask"
            )
        if drift > max_aspect_drift:
            raise ValueError(
                f"mask aspect drift {drift:.4%} exceeds {max_aspect_drift:.4%}"
            )
        alpha = alpha.resize(rgba.size, Image.Resampling.LANCZOS)
    if invert:
        alpha = ImageOps.invert(alpha)
    if feather > 0:
        alpha = alpha.filter(ImageFilter.GaussianBlur(feather))
    alpha = ImageChops.multiply(alpha, rgba.getchannel("A"))
    output = rgba.copy()
    output.putalpha(alpha)
    return output


def alpha_report(image):
    alpha = image.getchannel("A")
    histogram = alpha.histogram()
    total = image.width * image.height
    transparent = histogram[0]
    opaque = histogram[255]
    partial = total - transparent - opaque
    return {
        "size": [image.width, image.height],
        "transparent_ratio": transparent / total if total else 0,
        "opaque_ratio": opaque / total if total else 0,
        "partial_alpha_ratio": partial / total if total else 0,
        "partial_alpha_pixels": partial,
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--mask", type=Path, help="semantic foreground mask or transparent draft")
    parser.add_argument("--mask-mode", choices=("auto", "alpha", "luma"), default="auto")
    parser.add_argument("--invert-mask", action="store_true")
    parser.add_argument("--resize-mask", action="store_true")
    parser.add_argument("--max-mask-aspect-drift", type=float, default=0.005)
    parser.add_argument("--background-color", action="append", default=[])
    parser.add_argument("--tolerance", type=int, default=45)
    parser.add_argument("--palette-size", type=int, default=64)
    parser.add_argument("--expand", type=int, default=1)
    parser.add_argument("--feather", type=float, default=1.0)
    parser.add_argument("--json", action="store_true")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    try:
        with Image.open(args.image) as image:
            source = image.convert("RGBA")
        if args.mask:
            with Image.open(args.mask) as image:
                mask = image.copy()
            output = apply_alpha_mask(
                source,
                mask,
                mask_mode=args.mask_mode,
                invert=args.invert_mask,
                resize_mask=args.resize_mask,
                max_aspect_drift=args.max_mask_aspect_drift,
                feather=args.feather,
            )
            method = "mask"
        else:
            colors = [parse_hex_color(value) for value in args.background_color]
            output = remove_edge_background(
                source,
                tolerance=args.tolerance,
                palette_size=args.palette_size,
                background_colors=colors or None,
                expand=args.expand,
                feather=args.feather,
            )
            method = "edge"
        args.out.parent.mkdir(parents=True, exist_ok=True)
        output.save(args.out, format="PNG")
        result = {"status": "pass", "method": method, "output": str(args.out), **alpha_report(output)}
    except Exception as exc:
        result = {"status": "error", "message": str(exc)}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"status={result['status']}")
        if result.get("message"):
            print(result["message"])
        elif result.get("output"):
            print(result["output"])
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
