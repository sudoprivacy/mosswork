#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""对源图做"描述 + 定位"，输出统一的 layout.json。

本脚本解决"把图片转 PPT 之前先知道图里有什么、各自在哪里"的问题。
它做五件事：

1. 文本定位：调用 rapidocr（ONNX OCR，无需 tesseract），得到每段文字的
   4 角坐标 + 文本内容。
2. 背景推断：估计页面底色是纯色还是线性渐变，输出 `background` 字段。
   这是"高还原"的第一要素——背景丢了，整页色调就错了。
3. 形状定位：在"平坦色块"图上做连通域，按有效覆盖率与四角内缩率把每个
   色块分类成 `rect` / `roundrect`（含圆角半径）/ `ellipse` / `line`，
   并反推描边颜色与线宽；色块内部若有线性渐变则输出 `grad`。
4. 图标定位：挑出真正"小而紧凑的彩色主体"当独立素材候选（实心圆点、徽章、
   复杂图形碎片簇），供后续裁成透明 PNG。
5. 区域定位：把文字块和图标块合并排版成 row/column 区域，便于人工复核。

输出 layout.json 形如：
  {
    "source_size": [W, H],
    "background": {"kind": "gradient", "grad": ["#101B33", "#090E1E"],
                   "dir": "v", "fill": "#0F1B33", "confidence": 0.93,
                   "box": [0, 80, 1600, 820]},
    "texts":    [{"text": "...", "box": [x,y,w,h], "score": 0.98}, ...],
    "icons":    [{"name": "icon_01", "box": [x,y,w,h], "role": "icon", "area": 1024}, ...],
    "shapes":   [{"type": "roundrect", "box": [...], "fill": "RRGGBB",
                  "border": "RRGGBB", "border_width": 2, "radius": 16}, ...],
    "blanked_shapes": [{"box": [...], "fill": "RRGGBB", "alpha": 23.5,
                        "reason": "不透明度 23.5% < 60% 且为背景层装饰 → 空白"}, ...],
    "regions":  [{"type": "row", "box": [...], "contains": ["text:0", "icon:0"]}, ...],
    "summary":  {"text_count": N, "icon_count": M, "shape_count": K,
                 "detector": "rapidocr+flat-region"}
  }

可作为 build_pptx_from_layout.py 的输入，也可作为人工复核的可视化依据。

性能说明（3.4.0）：
  * 连通域改用「行程编码 + 并查集」，复杂度从 O(W·H) 降到 O(行程数)。
    实测 1600×900 单次全图连通域 2.35 s → 0.033 s（71×），饱和度掩膜
    2.55 s → 0.016 s（160×）。旧实现是纯 Python 逐像素 BFS。
  * 旧版对每个调色板颜色各扫一遍全图（最多 13 次全图连通域）；现在整条
    describe 只做一次「平坦区域分割」，所有形状/背景都由它派生。
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, hint, ok, run  # noqa: E402
import bg_blank  # noqa: E402   （3.5.0）背景隐形图形 → 空白背景判定

from PIL import Image
import numpy as np


# ──────────────────────────── 文本：rapidocr ────────────────────────────
def detect_texts(image_path: str, engine=None):
    """返回 [(text, box=(x,y,w,h), score)]；box 是源图像素坐标。"""
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError as exc:  # pragma: no cover
        raise SkillError(
            "缺少依赖：rapidocr-onnxruntime",
            reason="describe_image.py 用 ONNX OCR 提取文字块，运行时找不到这个包。",
            next_steps=[
                "pip install rapidocr-onnxruntime",
                "（沙盒里无 tesseract / brew，这是当前唯一可行的 OCR 方案）",
            ],
            doc="references/reconstruction-and-qa.md",
        ) from exc

    engine = engine if engine is not None else RapidOCR()
    raw = engine(image_path)
    # rapidocr_onnxruntime 返回 (detections, elapsed)；每个 detection = [box, text, score]
    detections = raw[0] if isinstance(raw, tuple) else raw
    if not detections:
        return []
    out = []
    for item in detections:
        # 兼容 [[box_pts], text, score] 与 (box_pts, (text, score))
        try:
            box_pts = item[0]
            text = item[1]
            score = item[2]
        except (TypeError, IndexError):
            try:
                box_pts, (text, score) = item
            except Exception:
                continue
        if not text or not text.strip():
            continue
        xs = [int(p[0]) for p in box_pts]
        ys = [int(p[1]) for p in box_pts]
        x0, y0 = max(0, min(xs)), max(0, min(ys))
        x1, y1 = max(xs), max(ys)
        w = max(1, x1 - x0)
        h = max(1, y1 - y0)
        out.append({"text": text.strip(), "box": [x0, y0, w, h], "score": float(score)})
    out.sort(key=lambda r: (r["box"][1], r["box"][0]))
    return out


# ─────────────────────── 连通域：行程编码 + 并查集 ───────────────────────
def _cc_core(mask: np.ndarray):
    """把掩膜压成「行程」并做并查集合并。

    返回 (rows, xs0, xs1, roots)：每条行程的行号、x 起点、x 终点（闭区间）
    以及它所属连通分量的根行程下标。根 = 该分量中最小的行程下标，因此按
    roots 排序即等价于逐行扫描顺序。
    """
    m = np.asarray(mask, dtype=bool)
    H, W = m.shape
    if not m.any():
        empty = np.zeros(0, dtype=np.int64)
        return empty, empty, empty, empty

    # 左右各补一列 0，用一阶差分一次性找出每行的行程起止
    pad = np.zeros((H, W + 2), dtype=np.int8)
    pad[:, 1:W + 1] = m
    diff = np.diff(pad, axis=1)
    starts = np.argwhere(diff == 1)     # (row, col)，col 即原图 x 起点
    ends = np.argwhere(diff == -1)      # (row, col)，col-1 即原图 x 终点
    n = int(starts.shape[0])
    if n == 0:
        empty = np.zeros(0, dtype=np.int64)
        return empty, empty, empty, empty
    rows = starts[:, 0].astype(np.int64)
    xs0 = starts[:, 1].astype(np.int64)
    xs1 = ends[:, 1].astype(np.int64) - 1

    order = np.lexsort((xs0, rows))
    rows, xs0, xs1 = rows[order], xs0[order], xs1[order]

    parent = np.arange(n, dtype=np.int64)

    def find(a: int) -> int:
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = int(parent[a])
        return a

    # 相邻两行之间的行程按 x 区间双指针扫描（行程已按 x 排序且互不相交）
    row_start = np.searchsorted(rows, np.arange(H + 1), side="left")
    for r in range(1, H):
        i, i_end = int(row_start[r - 1]), int(row_start[r])
        j, j_end = int(row_start[r]), int(row_start[r + 1])
        while i < i_end and j < j_end:
            if xs1[i] + 1 < xs0[j]:          # 8 邻域：允许对角相接
                i += 1
            elif xs1[j] + 1 < xs0[i]:
                j += 1
            else:
                ri, rj = find(i), find(j)
                if ri != rj:
                    if ri < rj:
                        parent[rj] = ri
                    else:
                        parent[ri] = rj
                if xs1[i] < xs1[j]:
                    i += 1
                else:
                    j += 1

    roots = np.fromiter((find(i) for i in range(n)), dtype=np.int64, count=n)
    return rows, xs0, xs1, roots


def _components_from(rows, xs0, xs1, roots, shape):
    """按根聚合出每个分量的 bbox / 面积，返回按扫描顺序排列的列表。"""
    H, W = shape
    n = roots.shape[0]
    if n == 0:
        return []
    minx = np.full(n, W, dtype=np.int64)
    np.minimum.at(minx, roots, xs0)
    maxx = np.full(n, -1, dtype=np.int64)
    np.maximum.at(maxx, roots, xs1)
    miny = np.full(n, H, dtype=np.int64)
    np.minimum.at(miny, roots, rows)
    maxy = np.full(n, -1, dtype=np.int64)
    np.maximum.at(maxy, roots, rows)
    areas = np.zeros(n, dtype=np.int64)
    np.add.at(areas, roots, xs1 - xs0 + 1)
    return [((int(minx[u]), int(miny[u]), int(maxx[u]), int(maxy[u])), int(areas[u]))
            for u in np.unique(roots)]


def _connected_components(mask: np.ndarray):
    """8 邻域连通域，返回 [(bbox, area)]，bbox=(x0,y0,x1,y1) 闭区间。

    复杂度 O(行程数 · α(n))，与图像总像素数基本无关。与旧的逐像素 BFS
    实现结果逐项一致（见 tests/test_fast_ccl.py），但快 70~160 倍。
    """
    m = np.asarray(mask, dtype=bool)
    if m.ndim != 2 or m.size == 0:
        return []
    rows, xs0, xs1, roots = _cc_core(m)
    return _components_from(rows, xs0, xs1, roots, m.shape)


def _label_map(mask: np.ndarray):
    """返回 (labels, components)。

    labels 为 int32，非前景处 -1，前景处为该连通分量的编号（= 根行程下标）；
    components 为 [{"id", "box", "area"}]，按扫描顺序排列。
    """
    m = np.asarray(mask, dtype=bool)
    labels = np.full(m.shape, -1, dtype=np.int32)
    rows, xs0, xs1, roots = _cc_core(m)
    if roots.shape[0] == 0:
        return labels, []
    for i in range(roots.shape[0]):
        labels[rows[i], xs0[i]:xs1[i] + 1] = roots[i]
    comps = [{"id": int(u), "box": b, "area": a}
             for (b, a), u in zip(_components_from(rows, xs0, xs1, roots, m.shape),
                                  np.unique(roots))]
    return labels, comps


# ──────────────────────────── 平坦区域分割 ────────────────────────────
def _edge_map(arr: np.ndarray, tol: int = 14) -> np.ndarray:
    """"非平坦"像素掩膜：与上下左右邻居的任一通道差 > tol 即算边缘。

    抗锯齿、文字笔画、图标细节都会落进边缘；卡片、色块、背景等大面积纯色
    区域则整体平坦——这正是我们要重建的原生形状。
    """
    a = arr.astype(np.int16)
    edge = np.zeros(arr.shape[:2], dtype=bool)
    dv = np.abs(np.diff(a, axis=0)).max(axis=2)
    edge[1:, :] |= dv > tol
    edge[:-1, :] |= dv > tol
    dh = np.abs(np.diff(a, axis=1)).max(axis=2)
    edge[:, 1:] |= dh > tol
    edge[:, :-1] |= dh > tol
    return edge


def _bridge_thin_edges(flat: np.ndarray, arr: np.ndarray, tol: int) -> np.ndarray:
    """把"两侧同色的 1 px 细缝"补回平坦掩膜。

    表格里的 1 px 分隔线、面板里的 1 px 描边会把整块面板切成若干横条，
    导致面板被识别成一堆细长矩形。判据：某边缘像素的上下（或左右）邻居
    都是平坦像素、且颜色相同 —— 说明它其实落在同一块同色区域内部。
    """
    H, W = flat.shape
    out = flat.copy()
    a = arr.astype(np.int16)
    if H > 4:
        d = np.abs(a[2:, :, :] - a[:-2, :, :]).max(axis=2)
        cand = np.zeros_like(flat)
        cand[1:-1, :] = (d <= tol) & flat[2:, :] & flat[:-2, :]
        out |= cand
    if W > 4:
        d = np.abs(a[:, 2:, :] - a[:, :-2, :]).max(axis=2)
        cand = np.zeros_like(flat)
        cand[:, 1:-1] = (d <= tol) & flat[:, 2:] & flat[:, :-2]
        out |= cand
    return out


def _flat_regions(arr: np.ndarray, tol: int = 14, min_area: int = 12):
    """返回 (flat, labels, regions)。

    flat     : 平坦像素布尔掩膜（已补回 1 px 细缝）
    labels   : 分量编号图（-1 表示非平坦），供按分量取像素用
    regions  : [{"id", "box", "area"}]，按扫描顺序
    """
    flat = _bridge_thin_edges(~_edge_map(arr, tol), arr, tol)
    labels, comps = _label_map(flat)
    return flat, labels, [c for c in comps if c["area"] >= min_area]


def _profile(labels: np.ndarray, arr: np.ndarray, rid: int, box):
    """**单个分量**在 bbox 内的逐行 / 逐列平均色（无像素处为 NaN）。

    必须按分量取像素：同一 bbox 里往往还嵌着别的色块（卡片里的进度条、
    面板里的分隔线），把它们的颜色混进来会把线性渐变判成"不是渐变"。
    """
    x0, y0, x1, y1 = box
    sub = labels[y0:y1 + 1, x0:x1 + 1] == rid
    ys, xs = np.nonzero(sub)
    h, w = sub.shape
    if ys.size == 0:
        return None, None
    px = arr[y0:y1 + 1, x0:x1 + 1][ys, xs].astype(np.float64)
    row_cnt = np.bincount(ys, minlength=h).astype(np.float64)
    col_cnt = np.bincount(xs, minlength=w).astype(np.float64)
    row_sum = np.zeros((h, 3))
    col_sum = np.zeros((w, 3))
    for c in range(3):
        row_sum[:, c] = np.bincount(ys, weights=px[:, c], minlength=h)
        col_sum[:, c] = np.bincount(xs, weights=px[:, c], minlength=w)
    with np.errstate(invalid="ignore", divide="ignore"):
        row_mean = row_sum / np.where(row_cnt[:, None] == 0, np.nan, row_cnt[:, None])
        col_mean = col_sum / np.where(col_cnt[:, None] == 0, np.nan, col_cnt[:, None])
    return row_mean, col_mean


def _fit_linear(profile: np.ndarray, min_delta: float = 15.0, max_resid: float = 9.0,
                eval_range=None):
    """把一维颜色剖面拟合成线性渐变。

    返回 (起点色, 终点色, 最大残差) 或 None。要求首尾变化够大、且中间点
    基本落在直线上——否则是"内容变化"而不是"渐变"。

    `eval_range=(i0, i1)` 可让端点在剖面范围之外求值（用于把页面背景区域
    拟合出的渐变外推回整页尺寸）。
    """
    if profile is None:
        return None
    idx = np.arange(profile.shape[0], dtype=np.float64)
    valid = ~np.isnan(profile[:, 0])
    if valid.sum() < 8:
        return None
    idx_v = idx[valid]
    span = idx_v[-1] - idx_v[0]
    if span < 8:
        return None
    best = None
    fits = []
    for c in range(3):
        y = profile[valid, c]
        k, b = np.polyfit(idx_v, y, 1)
        resid = float(np.abs(y - (k * idx_v + b)).max())
        delta = abs(k) * span
        fits.append((k, b))
        if delta >= min_delta and resid <= max_resid:
            if best is None or delta > best[0]:
                best = (delta, c)
    if best is None:
        return None
    lo, hi = eval_range if eval_range else (idx_v[0], idx_v[-1])
    pred = [np.zeros(3), np.zeros(3)]
    for c, (k, b) in enumerate(fits):
        pred[0][c] = k * lo + b
        pred[1][c] = k * hi + b
    return (tuple(int(np.clip(v, 0, 255)) for v in pred[0]),
            tuple(int(np.clip(v, 0, 255)) for v in pred[1]),
            best[0])


def _hex(rgb) -> str:
    return "#%02X%02X%02X" % tuple(int(np.clip(v, 0, 255)) for v in rgb)


def _corner_radius(sub: np.ndarray, max_scan: int = 80) -> int:
    """从四角的边界曲线估计圆角半径（像素）。

    原理：圆角矩形的左上角，每行第一个属于形状的 x 会随 y 递减，直到 y 越过
    圆心后稳定为 0；从顶行数到该行就是半径。四个角各估一次取**最大值**——
    角被别的元素（色条、图标）压住时只会把估计值压低，不会抬高。
    """
    h, w = sub.shape
    ests = []
    for top, left in ((True, True), (True, False), (False, True), (False, False)):
        rng = range(0, min(h, max_scan)) if top else range(h - 1, max(h - max_scan, 0) - 1, -1)
        for k, y in enumerate(rng):
            nz = np.nonzero(sub[y])[0]
            if nz.size == 0:
                continue
            off = int(nz[0]) if left else int(w - 1 - nz[-1])
            if off == 0:
                ests.append(k)
                break
    return max(ests) if ests else 0


def _shape_metrics(labels: np.ndarray, rid: int, box):
    """量出分量的形状特征。

    返回 (eff_cov, inset_norm, insets, radius_px)：

    * eff_cov 有效覆盖率：把形状内部被文字/图标挖出的**孔洞**补回去，只统计
      真正落在形状外的缺口。卡片里写了字，原始覆盖率会掉到 0.85 左右，孔洞
      回填后能恢复到 0.99 —— 这是区分"圆角矩形"和"不规则色块"的关键。
    * inset_norm 归一化四角内缩率：从 bbox 四角沿对角线向里走到第一个属于该
      分量的像素的距离 / 短边。椭圆的这个值恒为 ≈0.147，与尺寸无关；圆角矩形
      则随尺寸增大趋近 0，因此能用来把两者分开。
    * insets 四个角的原始内缩像素数（0 表示该角是直角）。
    * radius_px 估计的圆角半径。
    """
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    sub = labels[y0:y1 + 1, x0:x1 + 1] == rid
    notch = 0
    inv = ~sub
    if inv.any():
        for (cx0, cy0, cx1, cy1), a in _connected_components(inv):
            if cx0 == 0 or cy0 == 0 or cx1 == bw - 1 or cy1 == bh - 1:
                notch += a          # 与 bbox 边界相连 → 落在形状外
    eff_cov = 1.0 - notch / float(bw * bh)

    insets = []
    for cx, cy, sx, sy in ((0, 0, 1, 1), (bw - 1, 0, -1, 1),
                           (0, bh - 1, 1, -1), (bw - 1, bh - 1, -1, -1)):
        d, px, py = 0, cx, cy
        while 0 <= px < bw and 0 <= py < bh:
            if sub[py, px]:
                break
            px += sx
            py += sy
            d += 1
        insets.append(d)
    return eff_cov, min(insets) / float(max(1, min(bw, bh))), insets, \
        _corner_radius(sub)


def _classify(labels: np.ndarray, rid: int, box):
    """按形状特征把平坦分量分类。

    返回 (type, radius)。type ∈ rect | roundrect | ellipse | line；None 表示
    形状不规则、不适合用原生形状重建。
    """
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0 + 1, y1 - y0 + 1

    # 细长条 → 分隔线 / 色条
    if min(bw, bh) <= 6 and max(bw, bh) / max(1, min(bw, bh)) >= 5:
        return "line", 0

    eff_cov, inset_norm, insets, radius = _shape_metrics(labels, rid, box)

    # 圆 / 椭圆：四角明显内缩，且有效覆盖率接近 π/4
    if inset_norm >= 0.05 and 0.68 <= eff_cov <= 0.90:
        return "ellipse", 0

    if eff_cov >= 0.93:
        if min(insets) >= 2:
            return "roundrect", int(max(2, min(radius + 4, min(bw, bh) // 4)))
        return "rect", 0
    return None, 0


def _border_of(labels: np.ndarray, arr: np.ndarray, box, fill, bg_colors, max_t: int = 6):
    """反推分量外侧一圈的描边颜色与线宽。

    从四条边逐层向外扫描（1..max_t px），取第一段**连续且颜色一致、且明显
    不同于填充色**的色带作为描边。只认线宽 ≥ 2 px 的描边——1 px 的差异多半
    只是抗锯齿或"邻块底色"，画出来反而多一圈错色。描边色若与页面底色接近
    也判定为没有描边。
    """
    H, W, _ = arr.shape
    x0, y0, x1, y1 = box
    fill_v = np.asarray(fill, dtype=np.float64)

    def scan(bands):
        run = []
        base = None
        for med in bands:
            if np.abs(med - fill_v).max() <= 24:
                if run:
                    break
                continue
            if base is None:
                base = med
            elif np.abs(med - base).max() > 34:
                break
            run.append(med)
        if len(run) < 2:
            return None
        return np.median(np.vstack(run), axis=0), len(run)

    sides = []
    if y0 - 1 >= 0:
        ks = range(1, min(max_t, y0) + 1)
        sides.append(scan([np.median(arr[y0 - k, x0:x1 + 1].astype(np.float64), axis=0)
                           for k in ks]))
    if y1 + 1 < H:
        ks = range(1, min(max_t, H - 1 - y1) + 1)
        sides.append(scan([np.median(arr[y1 + k, x0:x1 + 1].astype(np.float64), axis=0)
                           for k in ks]))
    if x0 - 1 >= 0:
        ks = range(1, min(max_t, x0) + 1)
        sides.append(scan([np.median(arr[y0:y1 + 1, x0 - k].astype(np.float64), axis=0)
                           for k in ks]))
    if x1 + 1 < W:
        ks = range(1, min(max_t, W - 1 - x1) + 1)
        sides.append(scan([np.median(arr[y0:y1 + 1, x1 + k].astype(np.float64), axis=0)
                           for k in ks]))
    sides = [s for s in sides if s]
    if not sides:
        return None, 0
    cand = np.median(np.vstack([s[0] for s in sides]), axis=0)
    if np.abs(cand - fill_v).max() < 24:
        return None, 0
    for bg in bg_colors or []:
        if np.abs(cand - np.asarray(bg, dtype=np.float64)).max() < 40:
            return None, 0
    thickness = int(round(float(np.median([s[1] for s in sides]))))
    return _hex(cand), int(max(2, min(thickness, max_t)))


def detect_background(img: Image.Image, tol: int = 14, _pre=None):
    """推断页面底色：纯色或线性渐变。

    思路：页面底色天然是"外框最接近整页"的那块平坦区域（注意不能按像素数
    取最大——页面中间那张大卡片的面板面积往往比背景还大）。找到它之后，
    沿 x / y 拟合线性渐变，并把端点外推回整页尺寸；拟合不上就退回代表色。

    返回 {"kind", "fill", "grad", "dir", "confidence", "box"}。
    """
    arr = np.asarray(img.convert("RGB"))
    H, W, _ = arr.shape
    page = float(H * W)
    if _pre is not None:
        flat, labels, regions = _pre
    else:
        flat, labels, regions = _flat_regions(
            arr, tol=tol, min_area=max(64, int(page * 0.0005)))

    best = None
    for r in regions:
        x0, y0, x1, y1 = r["box"]
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        ratio = bw * bh / page
        if ratio < 0.80:
            continue
        if best is None or ratio > best[1]:
            best = (r, ratio)

    if best is None:
        # 找不到大块平坦区域（照片底、复杂纹理）→ 用外圈边框的中位色兜底
        bw = max(2, min(H, W) // 40)
        frame = np.concatenate([
            arr[:bw].reshape(-1, 3), arr[-bw:].reshape(-1, 3),
            arr[:, :bw].reshape(-1, 3), arr[:, -bw:].reshape(-1, 3)])
        med = tuple(int(v) for v in np.median(frame, axis=0))
        return {"kind": "solid", "fill": _hex(med), "grad": None,
                "dir": None, "confidence": 0.35, "box": [0, 0, W, H]}

    region, ratio = best
    rid = region["id"]
    box = region["box"]
    x0, y0, x1, y1 = box
    sel = labels[y0:y1 + 1, x0:x1 + 1] == rid
    fill = tuple(int(v) for v in np.median(arr[y0:y1 + 1, x0:x1 + 1][sel], axis=0)) \
        if sel.any() else (255, 255, 255)
    row_mean, col_mean = _profile(labels, arr, rid, box)

    # 端点外推回整页：剖面下标 = 行号 - y0（或列号 - x0）
    vfit = _fit_linear(row_mean, eval_range=(0 - y0, (H - 1) - y0))
    hfit = _fit_linear(col_mean, eval_range=(0 - x0, (W - 1) - x0))
    pick = None
    if vfit and hfit:
        pick = ("v", vfit) if vfit[2] <= hfit[2] else ("h", hfit)
    elif vfit:
        pick = ("v", vfit)
    elif hfit:
        pick = ("h", hfit)

    base = {"fill": _hex(fill),
            "box": [int(x0), int(y0), int(x1 - x0 + 1), int(y1 - y0 + 1)],
            "confidence": round(min(0.98, 0.45 + ratio * 0.55), 3)}
    if pick is None:
        return {"kind": "solid", "grad": None, "dir": None, **base}
    direction, (c0, c1, _res) = pick
    return {"kind": "gradient", "grad": [_hex(c0), _hex(c1)], "dir": direction, **base}


def _holes_are_text(box, texts, threshold: float = 0.5) -> bool:
    """该色块是否基本落在某个 OCR 文字框里（→ 它是字形的一部分，不是图标）。

    注意比的是"色块有多大比例被文字框盖住"，不是反过来——标题、横幅的 OCR
    框往往横跨整行，用文字框占比会永远判否。
    """
    if not texts:
        return False
    x0, y0, x1, y1 = box
    ba = float(max(1, (x1 - x0 + 1) * (y1 - y0 + 1)))
    for t in texts:
        tx0, ty0, tw, th = t["box"]
        ox0, oy0 = max(x0, tx0), max(y0, ty0)
        ox1, oy1 = min(x1, tx0 + tw), min(y1, ty0 + th)
        inter = max(0, ox1 - ox0) * max(0, oy1 - oy0)
        if inter / ba >= threshold:
            return True
    return False


def _icon_bearing(labels, rid, box, area, texts, page,
                  max_side: int = 200, max_bbox_ratio: float = 0.015) -> bool:
    """判断一个色块是不是"图标底盘"——内部有图形细节，不该被压成纯色形状。

    判据：块足够小 + 内部有**非文字**的空洞。例如"蓝圆底 + 白色闪电"、
    "圆角方底 + 白色清单图标"、"浅色圆盘 + 时钟线稿"都是图标底盘；把这类
    色块当普通椭圆重建会把内部细节整块抹掉。

    尺寸上限是安全阀：整条横幅、整张面板即使内部有图形，也绝不当图标裁走，
    否则会把大段可编辑内容变成一张图。
    """
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    if max(bw, bh) > max_side or bw * bh / float(page) > max_bbox_ratio:
        return False
    eff_cov, _inset, _insets, _deficit = _shape_metrics(labels, rid, box)
    hole_ratio = eff_cov - area / float(bw * bh)
    if hole_ratio < 0.04:
        return False
    return not _holes_are_text(box, texts)


def _inside_any(box, boxes, tol: int = 2) -> bool:
    """box（[x,y,w,h]）是否被 boxes 里的某个框包住（允许 tol 像素误差）。"""
    x0, y0, w, h = box
    x1, y1 = x0 + w - 1, y0 + h - 1
    for bx in boxes:
        sx0, sy0, sw, sh = bx
        if x0 >= sx0 - tol and y0 >= sy0 - tol \
                and x1 <= sx0 + sw - 1 + tol and y1 <= sy0 + sh - 1 + tol:
            return True
    return False


def _covered_by_shapes(box, shapes, threshold: float = 0.6,
                       size_ratio: float = 2.5) -> bool:
    """图标框是否已被某个**尺寸相当**的原生形状覆盖。

    必须比尺寸：图标常常整块落在某张卡片的框里，但卡片面积远大于图标，
    它并没有"画"出这个图标，不能因此把图标丢掉。
    """
    x0, y0, w, h = box
    x1, y1 = x0 + w, y0 + h
    ia = float(max(1, w * h))
    for s in shapes:
        sb = s["box"]
        sa = float(max(1, sb[2] * sb[3]))
        if sa > ia * size_ratio:
            continue
        sx0, sy0, sw, sh = sb
        ix0, iy0 = max(x0, sx0), max(y0, sy0)
        ix1, iy1 = min(x1, sx0 + sw), min(y1, sy0 + sh)
        inter = max(0, ix1 - ix0) * max(0, iy1 - iy0)
        if inter / ia >= threshold:
            return True
    return False


# ──────────────────────────── 形状：平坦区域 → 原生形状 ────────────────────────────
def _grow_flat_box(labels, arr, rid, box, max_grow: int = 2, tol: int = 40):
    """把平坦区域的框向外扩到"颜色仍是主体色"的边界。

    边缘掩膜会把每个色块的最外一圈像素标成边缘，于是连通域框天然比真实色块
    小 1px（左右上下各 1px）。对 460px 宽的卡片无所谓，对 5px 宽的强调条就是
    20% 的宽度误差 —— 导出后会看到色条偏细、面板描边内缩。这里向外逐行/逐列
    试探补回来：只要新增那一行/一列的**平均色**仍与主体色一致，就算进框。
    """
    x0, y0, x1, y1 = box
    sel = labels[y0:y1 + 1, x0:x1 + 1] == rid
    if not sel.any():
        return box
    ref = np.median(arr[y0:y1 + 1, x0:x1 + 1][sel].astype(np.float64), axis=0)
    H, W = labels.shape[:2]

    def _ok(line):
        return np.abs(line.astype(np.float64)
                      - ref.reshape(1, 3)).sum(axis=1).mean() <= tol

    for _ in range(max_grow):
        if x0 - 1 >= 0 and _ok(arr[y0:y1 + 1, x0 - 1]):
            x0 -= 1
        else:
            break
    for _ in range(max_grow):
        if x1 + 1 < W and _ok(arr[y0:y1 + 1, x1 + 1]):
            x1 += 1
        else:
            break
    for _ in range(max_grow):
        if y0 - 1 >= 0 and _ok(arr[y0 - 1, x0:x1 + 1]):
            y0 -= 1
        else:
            break
    for _ in range(max_grow):
        if y1 + 1 < H and _ok(arr[y1 + 1, x0:x1 + 1]):
            y1 += 1
        else:
            break
    return (x0, y0, x1, y1)


def detect_shapes(img: Image.Image, min_area_ratio: float = 0.0002,
                  max_area_ratio: float = 0.92, palette_k: int = 6,
                  color_tolerance: int = 28, _pre=None, background=None, texts=None,
                  exclude_boxes=None,
                  bg_blank_alpha: float = 0.0,
                  blanked=None):
    """把"大面积平坦色块"还原成原生形状。

    算法（3.4.0 重写）：
      1. 求边缘图并补回 1 px 细缝，取反得到平坦掩膜；连通域 → 候选色块。
      2. 剔除与 OCR 文字框高度重合的分量（字形内部/笔画核心，不是形状）。
      3. 按有效覆盖率与四角内缩率分类成 rect / roundrect / ellipse / line。
    4. 沿 x / y 拟合线性渐变，能拟合上的输出 `grad` 而不是单色 `fill`。
    5. 反推外侧描边色与线宽（只认 ≥ 2 px），输出 `border` / `border_width`。
    6. 页面背景区域由 `background` 字段单独承载，不重复出形状。
    7. （3.5.0）背景层里"几乎看不见"的装饰（等效不透明度 < `bg_blank_alpha`，
       默认 60%）**不出形状**，按空白背景处理，进 `blanked` 便于人工复核。

    返回 [{type, box, fill, border, border_width, radius, grad, dir}]。
    `palette_k` / `color_tolerance` 为旧版调色板算法的参数，保留仅为兼容调用。
    """
    arr = np.asarray(img.convert("RGB"))
    H, W, _ = arr.shape
    page = float(H * W)
    if _pre is not None:
        flat, labels, regions = _pre
    else:
        flat, labels, regions = _flat_regions(arr)

    bg = background if background is not None else \
        detect_background(img, _pre=(flat, labels, regions))
    bg_colors = []
    if bg.get("fill"):
        bg_colors.append(tuple(int(bg["fill"][i:i + 2], 16) for i in (1, 3, 5)))
    for g in (bg.get("grad") or []):
        bg_colors.append(tuple(int(g[i:i + 2], 16) for i in (1, 3, 5)))
    bg_box = bg.get("box")
    bg_rect = None
    if bg_box:
        bg_rect = (bg_box[0], bg_box[1], bg_box[0] + bg_box[2] - 1, bg_box[1] + bg_box[3] - 1)

    shapes = []
    for r in regions:
        rid = r["id"]
        box = r["box"]
        area = r["area"]
        x0, y0, x1, y1 = box
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        ratio = area / page
        if ratio < min_area_ratio or ratio > max_area_ratio:
            continue
        if bw < 4 or bh < 4:
            continue
        # 页面背景区域已由 background 字段承载，不再重复出一个大矩形
        if bg_rect is not None and tuple(box) == bg_rect:
            continue
        if bw * bh / page >= 0.92:
            continue
        if max(bw, bh) / max(1, min(bw, bh)) > 200:
            continue
        # 字形内部 / 笔画核心不是形状
        if texts and _text_hit([x0, y0, bw, bh], texts, contain=0.5, iou=0.3):
            continue
        # 图标底盘（以及它内部的细节块）交给裁图链路，不用原生形状抹平
        if exclude_boxes and _inside_any([x0, y0, bw, bh], exclude_boxes):
            continue

        kind, radius = _classify(labels, rid, box)
        if kind is None:
            continue

        # 边缘掩膜吃掉了最外一圈像素，先把框补回真实边界再取样、拟合、反推描边
        box = _grow_flat_box(labels, arr, rid, box)
        x0, y0, x1, y1 = box
        bw, bh = x1 - x0 + 1, y1 - y0 + 1

        sel = labels[y0:y1 + 1, x0:x1 + 1] == rid
        px = arr[y0:y1 + 1, x0:x1 + 1][sel]
        if px.size == 0:
            continue
        fill = tuple(int(v) for v in np.median(px, axis=0))

        entry = {
            "type": kind,
            "box": [int(x0), int(y0), int(bw), int(bh)],
            "fill": _hex(fill),
            "border": None,
            "border_width": 0,
        }
        if kind == "roundrect":
            entry["radius"] = int(radius)

        # 渐变（只对成片的矩形/圆角矩形做，细线不做）
        if kind in ("rect", "roundrect") and ratio >= 0.0008:
            row_mean, col_mean = _profile(labels, arr, rid, box)
            vfit = _fit_linear(row_mean) if bh >= 8 else None
            hfit = _fit_linear(col_mean) if bw >= 8 else None
            pick = None
            if vfit and hfit:
                pick = ("v", vfit) if vfit[2] <= hfit[2] else ("h", hfit)
            elif vfit:
                pick = ("v", vfit)
            elif hfit:
                pick = ("h", hfit)
            if pick:
                d, (c0, c1, _res) = pick
                entry["grad"] = [_hex(c0), _hex(c1)]
                entry["dir"] = d

        if kind != "line":
            bc, bwid = _border_of(labels, arr, box, fill, bg_colors)
            if bc:
                entry["border"] = bc
                # 描边宽度不能超过短边的 1/5，否则细图标的"描边"会糊满整个形状
                bwid = int(min(bwid, max(2, min(bw, bh) // 5)))
                entry["border_width"] = bwid
                # DrawingML 的描边是**骑在几何轮廓上**的（一半在内、一半在外），
                # 而源图的描边整个位于填充之外。所以几何框要外扩 border_width/2，
                # 否则描边整体内缩、外圈留下 1~2px 的缝（残差兜底会把这道缝切成
                # 好几张 2px 小图，既难看又浪费图片对象）。
                g = bwid // 2
                if g > 0:
                    nx0, ny0 = max(0, x0 - g), max(0, y0 - g)
                    nx1, ny1 = min(W - 1, x1 + g), min(H - 1, y1 + g)
                    if (nx0, ny0, nx1, ny1) != (x0, y0, x1, y1):
                        x0, y0, x1, y1 = nx0, ny0, nx1, ny1
                        bw, bh = x1 - x0 + 1, y1 - y0 + 1
                        entry["box"] = [int(x0), int(y0), int(bw), int(bh)]

        # （3.5.0）背景层里几乎看不见的装饰：不出形状，按空白背景处理。
        # fill 是这块平坦区域的实测中位色，等价于"源图里实际看到的叠加结果"，
        # 拿它和页面背景比，得到的就是等效不透明度的下界（见 bg_blank 模块）。
        if blanked is not None and bg_blank_alpha > 0:
            local_bg = bg_blank.bg_rgb_at(
                bg, (x0 + x1) / 2.0, (y0 + y1) / 2.0, W, H)
            alpha = bg_blank.estimate_alpha(fill, local_bg)
            yes, reason = bg_blank.classify_blankable(
                entry, alpha, page, texts=texts, threshold=bg_blank_alpha)
            if yes:
                blanked.append({"name": entry.get("name") or "",
                                "box": list(entry["box"]),
                                "fill": entry.get("fill"),
                                "alpha": alpha, "reason": reason})
                continue
        shapes.append(entry)

    shapes.sort(key=lambda r: (r["box"][1], r["box"][0]))
    for i, s in enumerate(shapes):
        s["name"] = f"shape_{i:02d}"
    return shapes


# ──────────────────────────── 图标：调色板 + 饱和度 ────────────────────────────
def _dominant_palette(arr: np.ndarray, k: int = 8, ignore_white: bool = True,
                      refine: bool = True):
    """前 k 个主导色 + 像素数。refine=True 时用该簇像素的中位色回代，
    避免量化中心落在两个区域之间、导致 mask 抓不到任何一个。"""
    im = Image.fromarray(arr)
    q = im.quantize(colors=k + 6, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette() or []
    counts = sorted(q.getcolors() or [], reverse=True)
    idx = np.asarray(q)
    out = []
    for cnt, i in counts:
        rgb = tuple(int(v) for v in pal[i * 3: i * 3 + 3])
        if ignore_white and min(rgb) >= 240:
            continue
        if refine:
            m = idx == i
            if m.sum() >= 16:
                rgb = tuple(int(v) for v in np.median(arr[m], axis=0))
        out.append((rgb, cnt))
        if len(out) >= k:
            break
    return out


def _color_mask(arr: np.ndarray, color, tol: int) -> np.ndarray:
    d = np.abs(arr.astype(np.int16) - np.asarray(color, dtype=np.int16)).max(axis=2)
    return d <= tol


def _text_hit(box, texts, contain: float = 0.5, iou: float = 0.3) -> bool:
    """候选框是否落在某个文字块里（字形/笔画，不是图标）。"""
    if not texts:
        return False
    ix0, iy0, iw, ih = box
    ix1, iy1 = ix0 + iw, iy0 + ih
    ia = float(max(1, iw * ih))
    for t in texts:
        tx0, ty0, tw, th = t["box"]
        tx1, ty1 = tx0 + tw, ty0 + th
        ox0, oy0 = max(ix0, tx0), max(iy0, ty0)
        ox1, oy1 = min(ix1, tx1), min(iy1, ty1)
        inter = max(0, ox1 - ox0) * max(0, oy1 - oy0)
        if not inter:
            continue
        if inter / ia >= contain:
            return True
        union = ia + tw * th - inter
        if union > 0 and inter / union >= iou:
            return True
    return False


def _dedupe_icons(cands):
    """去重：IoU 重叠 > 0.5 视为同一个；被更大候选整块包住的直接丢掉
    （外层裁图已经包含内层内容，再裁一次只会多一个重叠图片对象）。"""
    cands = sorted(cands, key=lambda c: -c["area"])
    out = []
    for c in cands:
        x0, y0, w, h = c["box"]
        x1, y1 = x0 + w, y0 + h
        ia = float(max(1, w * h))
        dup = False
        for o in out:
            ox0, oy0, ow, oh = o["box"]
            ox1, oy1 = ox0 + ow, oy0 + oh
            ix0, iy0 = max(x0, ox0), max(y0, oy0)
            ix1, iy1 = min(x1, ox1), min(y1, oy1)
            inter = max(0, ix1 - ix0) * max(0, iy1 - iy0)
            union = w * h + ow * oh - inter
            if union > 0 and inter / union > 0.5:
                dup = True
                break
            if inter / ia >= 0.9:
                dup = True
                break
        if not dup:
            out.append(c)
    out.sort(key=lambda r: (r["box"][1], r["box"][0]))
    for i, c in enumerate(out):
        c["name"] = f"icon_{i:02d}"
    return out


def detect_icons(img: Image.Image, min_area: int = 256, max_area: int = 20000,
                 min_saturation: float = 0.15, texts=None, palette_k: int = 8,
                 color_tolerance: int = 28):
    """挑出"小而紧凑的彩色主体"作为独立素材候选。

    两条互补的线索：
      A. 调色板色块：主导色掩膜上的连通域，要求够紧凑（覆盖率 ≥ 0.40、
         长宽比 ≤ 3）——实心圆点、徽章、色块图标走这条。
      B. 饱和度掩膜：低饱和背景上的高饱和色块——彩色线条图标走这条。

    两条都会剔除与文字框高度重合的候选（红字/蓝字常被误当成图标）。
    """
    arr = np.asarray(img.convert("RGB"))
    H, W, _ = arr.shape
    page = float(H * W)
    cands = []

    # A. 调色板色块
    for color, count in _dominant_palette(arr, k=palette_k):
        if count < page * 0.0002:
            continue
        for (x0, y0, x1, y1), area in _connected_components(
                _color_mask(arr, color, color_tolerance)):
            bw, bh = x1 - x0 + 1, y1 - y0 + 1
            if area < min_area or area > max_area:
                continue
            if bw < 6 or bh < 6:
                continue
            if max(bw, bh) / min(bw, bh) > 3.0:
                continue
            if area / float(bw * bh) < 0.40:
                continue
            cands.append({"name": "", "box": [int(x0), int(y0), int(bw), int(bh)],
                          "role": "icon", "area": int(area), "source": "palette"})

    # B. 饱和度掩膜
    mx = np.max(arr, axis=-1).astype(np.float32)
    mn = np.min(arr, axis=-1).astype(np.float32)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1.0), 0.0)
    for (x0, y0, x1, y1), area in _connected_components(sat >= min_saturation):
        if area < min_area or area > max_area:
            continue
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        if bw < 6 or bh < 6:
            continue
        if max(bw, bh) / min(bw, bh) > 6:
            continue
        cands.append({"name": "", "box": [int(x0), int(y0), int(bw), int(bh)],
                      "role": "icon", "area": int(area), "source": "saturation"})

    cands = [c for c in cands if not _text_hit(c["box"], texts)]
    return _dedupe_icons(cands)


def _leftover_icon_clusters(labels, regions, shapes, texts,
                            min_area: int = 90, max_span: int = 220,
                            max_aspect: float = 6.0, tiny_rect: int = 400,
                            blank_boxes=None):
    """把"不规整的小色块"按邻近关系聚成簇，当作复杂图标的候选。

    复杂图标（多色插画/带描边的 Logo）在平坦区域图上会碎成很多小块，
    单块过不了矩形/椭圆判定；把彼此靠近的碎块并起来就能框住整个图标。

    3.4.0 起也收"被判成 rect 但太小"的碎片：虚线箭头、刻度线、小圆点这类
    元素两头不靠 —— detect_shapes 嫌它小于 4px/288px，这里又因为"像矩形"
    被跳过 —— 结果是整条虚线箭头在成品里凭空消失。只要够小（<=tiny_rect），
    就让它们进簇，交给邻近聚簇去还原。
    """
    leftovers = []
    for r in regions:
        x0, y0, x1, y1 = r["box"]
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        if r["area"] < 12 or bw > max_span or bh > max_span:
            continue
        kind = _classify(labels, r["id"], r["box"])[0]
        if kind is not None:
            # 只有"小矩形碎片"才放行；大矩形是原生形状的活，不该裁成图
            if not (kind == "rect" and r["area"] <= tiny_rect
                    and bw <= 40 and bh <= 40):
                continue
        if _text_hit([x0, y0, bw, bh], texts, contain=0.5, iou=0.3):
            continue
        leftovers.append([x0, y0, x1, y1, r["area"]])
    if not leftovers:
        return []

    n = len(leftovers)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    gap = 6
    for i in range(n):
        for j in range(i + 1, n):
            a, b = leftovers[i], leftovers[j]
            if (a[0] - gap <= b[2] and b[0] - gap <= a[2]
                    and a[1] - gap <= b[3] and b[1] - gap <= a[3]):
                ra, rb = find(i), find(j)
                if ra != rb:
                    parent[max(ra, rb)] = min(ra, rb)

    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(leftovers[i])

    out = []
    for members in groups.values():
        x0 = min(m[0] for m in members)
        y0 = min(m[1] for m in members)
        x1 = max(m[2] for m in members)
        y1 = max(m[3] for m in members)
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        total = sum(m[4] for m in members)
        if total < min_area or bw * bh > 40000:
            continue
        if bw < 6 or bh < 4 or bw > max_span or bh > max_span:
            continue
        if max(bw, bh) / min(bw, bh) > max_aspect:
            continue
        if _text_hit([x0, y0, bw, bh], texts, contain=0.5, iou=0.3):
            continue
        # 已被某个尺寸相当的原生形状覆盖 → 不需要再裁图
        if _covered_by_shapes([x0, y0, bw, bh], shapes, 0.6):
            continue
        # 已被判定为"背景隐形装饰 → 空白"的区域：既不出形状也不裁成图标，
        # 否则刚省下的形状会在这一步变成一张毫无意义的淡色 PNG。
        if blank_boxes and _inside_any([x0, y0, bw, bh], blank_boxes):
            continue
        out.append({"name": "", "box": [int(x0), int(y0), int(bw), int(bh)],
                    "role": "icon", "area": int(total), "source": "cluster"})
    return out


def _drop_icons_inside_shapes(icons, shapes):
    """图标框若已被某个尺寸相当的原生形状覆盖，就删掉——原生形状更可编辑。"""
    out = [ic for ic in icons
           if not _covered_by_shapes(ic["box"], shapes, threshold=0.6)]
    out.sort(key=lambda r: (r["box"][1], r["box"][0]))
    for i, c in enumerate(out):
        c["name"] = f"icon_{i:02d}"
    return out


# ─────────────── 兜底：把"没被任何元素解释"的像素捞回来 ───────────────
def _hex2rgb(h):
    h = str(h or "").lstrip("#")
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except Exception:
        return (255, 255, 255)


def _grad_field(h: int, w: int, c0, c1, direction: str):
    """线性渐变场，形状 (h, w, 3)。"""
    if direction == "h":
        t = np.linspace(0.0, 1.0, w)[None, :].repeat(h, axis=0)
    elif direction == "diag":
        t = (np.linspace(0.0, 1.0, h)[:, None]
             + np.linspace(0.0, 1.0, w)[None, :]) / 2.0
    else:
        t = np.linspace(0.0, 1.0, h)[:, None].repeat(w, axis=1)
    return np.stack([c0[i] + (c1[i] - c0[i]) * t for i in range(3)], axis=2)


def _background_mask(arr, background, tol: int = 45) -> np.ndarray:
    """与背景模型（纯色 / 线性渐变）一致的像素。"""
    H, W = arr.shape[:2]
    a = arr.astype(np.int32)
    bg = background or {}
    if bg.get("kind") == "gradient" and bg.get("grad") and len(bg["grad"]) >= 2:
        model = _grad_field(H, W, _hex2rgb(bg["grad"][0]),
                            _hex2rgb(bg["grad"][1]), bg.get("dir") or "v")
    else:
        f = np.array(_hex2rgb(bg.get("fill") or "#FFFFFF"), dtype=np.float64)
        model = np.broadcast_to(f, (H, W, 3))
    return np.abs(a - model).sum(axis=2) <= tol


def _shape_paint_mask(arr, s, tol: int = 45):
    """形状**实际画出来**的像素（填充色 + 描边色），而不是整个外接框。

    必须按颜色而不是按框：结论面板的框罩住了整条虚线箭头，若按框标记覆盖，
    箭头就永远被当成"已解释"而丢掉。

    取样窗口要比形状框**外扩 2px**：DrawingML 的描边骑在几何轮廓上，源图里
    那圈 1~2px 的描边落在框外，不外扩就会把它当成"没解释的残留"。
    """
    try:
        x0, y0, w, h = [int(round(v)) for v in s["box"]]
    except Exception:
        return None
    if w <= 0 or h <= 0:
        return None
    H, W = arr.shape[:2]
    try:
        pad = max(2, int(s.get("border_width") or 0))
    except Exception:
        pad = 2
    sx0, sy0 = max(0, x0 - pad), max(0, y0 - pad)
    sx1, sy1 = min(W, x0 + w + pad), min(H, y0 + h + pad)
    if sx1 <= sx0 or sy1 <= sy0:
        return None
    sub = arr[sy0:sy1, sx0:sx1].astype(np.int32)
    hh, ww = sub.shape[:2]
    m = np.zeros((hh, ww), dtype=bool)
    if s.get("grad") and len(s["grad"]) >= 2:
        model = _grad_field(hh, ww, _hex2rgb(s["grad"][0]),
                            _hex2rgb(s["grad"][1]), s.get("dir") or "h")
        m |= np.abs(sub - model).sum(axis=2) <= tol
    elif s.get("fill"):
        f = np.array(_hex2rgb(s["fill"]), dtype=np.float64)
        m |= np.abs(sub - f).sum(axis=2) <= tol
    if s.get("border"):
        b = np.array(_hex2rgb(s["border"]), dtype=np.float64)
        m |= np.abs(sub - b).sum(axis=2) <= tol
    if s.get("type") in ("ellipse", "circle"):
        # 椭圆：只保留椭圆环带内的像素（外扩 pad 后半径同步放大）
        yy, xx = np.mgrid[0:hh, 0:ww]
        cy, cx = (hh - 1) / 2.0, (ww - 1) / 2.0
        ry, rx = max(1e-6, hh / 2.0), max(1e-6, ww / 2.0)
        m &= (((yy - cy) / ry) ** 2 + ((xx - cx) / rx) ** 2) <= 1.2
    out = np.zeros((H, W), dtype=bool)
    out[sy0:sy1, sx0:sx1] = m
    return out


def _dilate(m: np.ndarray, r: int = 2) -> np.ndarray:
    """方形结构元膨胀 r 像素（纯切片实现，不引入 scipy）。"""
    if r <= 0:
        return m
    H, W = m.shape
    p = np.pad(m, r, constant_values=False)
    out = m.copy()
    for dy in range(2 * r + 1):
        for dx in range(2 * r + 1):
            out |= p[dy:dy + H, dx:dx + W]
    return out


def _residual_icons(arr, background, shapes, icons, texts,
                    min_area: int = 48, max_side: int = 300, gap: int = 8,
                    tol: int = 45, max_sparse: float = 0.62,
                    hair_min: int = 60, hair_max_side: int = 1400,
                    hair_thick: int = 4, hair_dense: float = 0.45,
                    max_regions: int = 32, max_comp: int = 900,
                    blank_boxes=None):
    """兜底：把"既不像背景、也不属于任何形状/图标/文字"的像素聚成簇，裁成图标。

    这是"1:1 不丢东西"的最后一道保险。典型受益者：虚线箭头、刻度线、细装饰线、
    面板里的 1~2px 分隔线。它们太细 —— 3 px 高的短划线会被边缘掩膜整个吃掉，
    在平坦区域图上连一个像素都剩不下 —— 于是 detect_shapes / detect_icons /
    _leftover_icon_clusters 三条路全部漏掉，成品里凭空少一块。

    收两类簇：
      * 常规细碎元素：面积/外接框 <= max_sparse（细笔画天然稀疏，而背景模型
        失配造成的整片残留是稠密的 —— 用稠密度就能把两者分开）；
      * 发丝线（min 边 <= hair_thick）：长而极细的分隔线/下划线，它在自己细长的
        外接框里是**稠密**的，所以反过来要求 density >= hair_dense，靠"够连续"
        把噪声串排除掉。
    """
    H, W = arr.shape[:2]
    cov = _background_mask(arr, background, tol)
    for s in shapes:
        m = _shape_paint_mask(arr, s, tol)
        if m is not None:
            cov |= m
    for ic in icons:
        try:
            x, y, w, h = [int(round(v)) for v in ic["box"]]
        except Exception:
            continue
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(W, x + w), min(H, y + h)
        if x1 > x0 and y1 > y0:
            cov[y0:y1, x0:x1] = True
    for t in texts:
        try:
            x, y, w, h = [int(round(v)) for v in t["box"]]
        except Exception:
            continue
        x0, y0 = max(0, x - 2), max(0, y - 2)
        x1, y1 = min(W, x + w + 2), min(H, y + h + 2)
        if x1 > x0 and y1 > y0:
            cov[y0:y1, x0:x1] = True
    # 「背景隐形装饰 → 空白」的区域也标记为已解释：它们按设计就是页面背景，
    # 残差兜底不该把它们当成"没画出来的东西"再裁一批小图。
    for b in (blank_boxes or []):
        try:
            x, y, w, h = [int(round(v)) for v in b]
        except Exception:
            continue
        x0, y0 = max(0, x - 2), max(0, y - 2)
        x1, y1 = min(W, x + w + 2), min(H, y + h + 2)
        if x1 > x0 and y1 > y0:
            cov[y0:y1, x0:x1] = True

    resid = ~cov
    if not resid.any():
        return []

    def _size(c):
        return c[0][2] - c[0][0] + 1, c[0][3] - c[0][1] + 1

    comps = [c for c in _connected_components(resid) if c[1] >= 6]
    # 先剔掉"自己就超宽"的分量：背景模型在面板上留下的弥散残差会横跨整页，
    # 它的**外接框**罩住了整条虚线箭头；若拿外接框做邻近聚簇，箭头会被它吞掉
    # （并成一个 1600px 宽的大块，然后被 max_side 丢掉）。真正的细笔画碎片
    # 自己都很小，先按尺寸过滤不会误伤。发丝线另算。
    comps = [c for c in comps
             if (_size(c)[0] <= max_side and _size(c)[1] <= max_side)
             or min(_size(c)) <= hair_thick]
    if not comps:
        return []
    if len(comps) > max_comp:
        comps.sort(key=lambda c: -c[1])
        comps = comps[:max_comp]

    n = len(comps)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for i in range(n):
        ax0, ay0, ax1, ay1 = comps[i][0]
        for j in range(i + 1, n):
            bx0, by0, bx1, by1 = comps[j][0]
            if (ax0 - gap <= bx1 and bx0 - gap <= ax1
                    and ay0 - gap <= by1 and by0 - gap <= ay1):
                ra, rb = find(i), find(j)
                if ra != rb:
                    parent[max(ra, rb)] = min(ra, rb)
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)

    out = []
    for idxs in groups.values():
        x0 = min(comps[i][0][0] for i in idxs)
        y0 = min(comps[i][0][1] for i in idxs)
        x1 = max(comps[i][0][2] for i in idxs)
        y1 = max(comps[i][0][3] for i in idxs)
        area = sum(comps[i][1] for i in idxs)
        bw, bh = x1 - x0 + 1, y1 - y0 + 1
        dens = area / float(bw * bh)
        normal = (area >= min_area and bw >= 6 and bh >= 4
                  and bw <= max_side and bh <= max_side
                  and max(bw, bh) / max(1, min(bw, bh)) <= 14
                  and dens <= max_sparse)
        hair = (min(bw, bh) <= hair_thick and max(bw, bh) <= hair_max_side
                and area >= hair_min and dens >= hair_dense)
        if not (normal or hair):
            continue
        if _text_hit([x0, y0, bw, bh], texts, contain=0.5, iou=0.3):
            continue
        out.append({"name": "", "box": [int(x0), int(y0), int(bw), int(bh)],
                    "role": "icon", "area": int(area), "source": "residual"})
    out.sort(key=lambda r: -r["area"])
    return out[:max_regions]


# ──────────────────────────── 区域：粗分行 ────────────────────────────
def merge_regions(texts, icons, shapes, img_h: int):
    """把同一行的元素归并为一个 region，便于排版与人工复核。"""
    items = []
    for i, t in enumerate(texts):
        items.append({"id": f"text:{i}", "box": t["box"]})
    for i, ic in enumerate(icons):
        items.append({"id": f"icon:{i}", "box": ic["box"]})
    for i, s in enumerate(shapes):
        items.append({"id": f"shape:{i}", "box": s["box"]})
    if not items:
        return []
    items.sort(key=lambda r: (r["box"][1] + r["box"][3] / 2))
    rows = []
    cur = [items[0]]
    for it in items[1:]:
        prev = cur[-1]
        prev_cy = prev["box"][1] + prev["box"][3] / 2
        prev_h = prev["box"][3]
        cy = it["box"][1] + it["box"][3] / 2
        if abs(cy - prev_cy) < 0.5 * (prev_h + it["box"][3]):
            cur.append(it)
        else:
            rows.append(cur)
            cur = [it]
    rows.append(cur)
    regions = []
    for ri, row in enumerate(rows):
        xs = [it["box"][0] for it in row]
        ys = [it["box"][1] for it in row]
        xe = [it["box"][0] + it["box"][2] for it in row]
        ye = [it["box"][1] + it["box"][3] for it in row]
        regions.append({
            "type": "row",
            "index": ri,
            "box": [min(xs), min(ys), max(xe) - min(xs), max(ye) - min(ys)],
            "contains": [it["id"] for it in row],
        })
    return regions


# ──────────────────────────── 入口 ────────────────────────────
def describe(image_path: str, residual: bool = True,
             bg_blank_alpha: float = 0.0):
    if not os.path.isfile(image_path):
        raise SkillError(f"找不到图片：{image_path}",
                         reason="路径不存在或拼写错误。",
                         next_steps=["用绝对路径重试。"],
                         doc="references/reconstruction-and-qa.md")
    img = Image.open(image_path)
    W, H = img.size
    arr = np.asarray(img.convert("RGB"))

    texts = detect_texts(image_path)
    pre = _flat_regions(arr)
    flat, labels, flat_regions = pre
    background = detect_background(img, _pre=pre)

    # 图标底盘：内部有非文字图形细节的小色块。先认出来，再让形状检测避开它们，
    # 否则"蓝圆底 + 白色闪电"会被压成一个纯色圆，内部细节整块丢失。
    page = float(W * H)
    icon_boxes = []
    for r in flat_regions:
        bx0, by0, bx1, by1 = r["box"]
        if _icon_bearing(labels, r["id"], r["box"], r["area"], texts, page):
            icon_boxes.append([int(bx0), int(by0), int(bx1 - bx0 + 1), int(by1 - by0 + 1)])

    blanked = []
    shapes = detect_shapes(img, _pre=pre, background=background, texts=texts,
                           exclude_boxes=icon_boxes,
                           bg_blank_alpha=bg_blank_alpha, blanked=blanked)
    blank_boxes = [b["box"] for b in blanked]
    icons = detect_icons(img, texts=texts)
    icons += _leftover_icon_clusters(labels, flat_regions, shapes, texts,
                                     blank_boxes=blank_boxes)
    icons += [{"name": "", "box": b, "role": "icon",
               "area": int(b[2] * b[3]), "source": "plate"} for b in icon_boxes]
    icons = _dedupe_icons(icons)
    icons = _drop_icons_inside_shapes(icons, shapes)
    # 最后一道保险：把"既不像背景、也不属于任何形状/图标/文字"的像素捞回来。
    # 虚线箭头、刻度线这类细笔画在上面三条检测路径上都会被漏掉。
    if residual:
        extra = _residual_icons(arr, background, shapes, icons, texts,
                                blank_boxes=blank_boxes)
        if extra:
            icons = _dedupe_icons(icons + extra)
            icons = _drop_icons_inside_shapes(icons, shapes)
    regions = merge_regions(texts, icons, shapes, H)

    return {
        "source": os.path.abspath(image_path),
        "source_size": [W, H],
        "background": background,
        "texts": texts,
        "icons": icons,
        "shapes": shapes,
        "blanked_shapes": blanked,
        "regions": regions,
        "summary": {
            "text_count": len(texts),
            "icon_count": len(icons),
            "shape_count": len(shapes),
            "blanked_shape_count": len(blanked),
            "region_count": len(regions),
            "background_kind": background["kind"],
            "bg_blank_alpha": bg_blank_alpha,
            "detector": "rapidocr-onnxruntime + flat-region",
        },
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("image", help="源图（PNG/JPG）")
    ap.add_argument("-o", "--out", default="layout.json", help="layout 输出 JSON")
    ap.add_argument("--preview", help="可选：把检测结果画到 PNG 便于人眼复核")
    ap.add_argument("--bg-blank-alpha", type=float,
                    default=0.0,
                    help="背景隐形图形的等效不透明度阈值（0-100）：低于它就按空白"
                         "背景处理（默认 0，关闭）")
    ap.add_argument("--no-bg-blank", action="store_true",
                    help="关闭「背景隐形图形按空白处理」")
    args = ap.parse_args()

    layout = describe(args.image,
                      bg_blank_alpha=0.0 if args.no_bg_blank
                      else args.bg_blank_alpha)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    import json
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False, indent=2)

    bg = layout["background"]
    ok(f"layout.json 已写出 → {args.out}")
    ok(f"  背景  : {bg['kind']}"
       + (f" {bg['grad'][0]}→{bg['grad'][1]} ({bg['dir']})"
          if bg["kind"] == "gradient" else f" {bg['fill']}")
       + f"  置信度 {bg['confidence']}")
    ok(f"  文字块: {layout['summary']['text_count']}")
    ok(f"  图标  : {layout['summary']['icon_count']}")
    ok(f"  形状  : {layout['summary']['shape_count']}")
    ok(f"  区域  : {layout['summary']['region_count']}")
    if layout["summary"]["blanked_shape_count"]:
        ok(f"  隐形背景装饰（按空白处理）: "
           f"{layout['summary']['blanked_shape_count']}"
           f"（阈值 不透明度 < {layout['summary']['bg_blank_alpha']}%）"
           f"  → 见 layout 的 blanked_shapes")
    hint("OCR 中文数字/单位偶有误识（如 王业→工业），复核 layout.json 后再传 build_pptx。")

    if args.preview:
        from PIL import ImageDraw
        im = Image.open(args.image).convert("RGB").copy()
        d = ImageDraw.Draw(im, "RGBA")
        for s in layout.get("shapes", []):
            x, y, w, h = s["box"]
            fill_rgb = tuple(int(s["fill"][i:i + 2], 16) for i in (1, 3, 5)) + (96,)
            d.rectangle([x, y, x + w, y + h], fill=fill_rgb)
        for t in layout["texts"]:
            x, y, w, h = t["box"]
            d.rectangle([x, y, x + w, y + h], outline=(0, 128, 255), width=2)
        for ic in layout["icons"]:
            x, y, w, h = ic["box"]
            d.rectangle([x, y, x + w, y + h], outline=(255, 64, 64), width=2)
        im.save(args.preview)
        ok(f"叠加预览图已保存 → {args.preview}（半透明=形状，蓝=文字，红=图标）")
    return 0


if __name__ == "__main__":
    sys.exit(run(main))
