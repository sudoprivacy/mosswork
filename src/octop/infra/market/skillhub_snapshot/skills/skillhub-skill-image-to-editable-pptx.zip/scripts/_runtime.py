"""Shared release metadata and local-runtime diagnostics."""
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
VERSION = json.loads((ROOT / '_meta.json').read_text(encoding='utf-8'))['version']
CORE_PACKAGES = {'PIL': 'Pillow', 'numpy': 'numpy', 'pptx': 'python-pptx'}
OCR_PACKAGE = 'rapidocr-onnxruntime'


def read_json(path):
    """Accept UTF-8 with or without the BOM used by some Windows editors."""
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def office_commands():
    return shutil.which('libreoffice') or shutil.which('soffice'), shutil.which('pdftoppm')


def diagnostic(code, message, next_action):
    return {'code': code, 'message': message, 'next_action': next_action,
            'doc': 'references/faq.md'}


def core_dependency_issue():
    return diagnostic('CORE_DEPENDENCY', '当前 Python 无法载入基础转换依赖。',
                      '用同一个 Python 运行 python -m pip install -r requirements-core.txt，'
                      '然后运行 python scripts/preflight.py --plain。')


def ocr_dependency_issue():
    return diagnostic('OCR_UNAVAILABLE', '当前 Python 无法载入可选的 RapidOCR。',
                      '安装 requirements.txt 后重试，或用 --ocr none 继续分块检查和测量。')


def office_dependency_issue():
    return diagnostic('RENDER_UNAVAILABLE', 'LibreOffice/soffice 和 pdftoppm 未同时就绪。',
                      '把两个工具加入 PATH，运行 python scripts/preflight.py --require-render。'
                      '也可用 PowerPoint/WPS 导出页面图片后运行 qa_external_render.py。')


class ActionError(ValueError):
    """Keep the technical error and an actionable user-facing diagnostic together."""

    def __init__(self, detail, code, message, next_action):
        super().__init__(detail)
        self.diagnostic = diagnostic(code, message, next_action)
