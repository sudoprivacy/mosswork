#!/usr/bin/env python3
"""检查基础依赖、可选 OCR 和真实渲染环境。默认输出 JSON。"""
import argparse
import importlib
import importlib.metadata
import json
import subprocess
import sys

from _runtime import (
    CORE_PACKAGES, OCR_PACKAGE, VERSION, core_dependency_issue,
    office_commands, office_dependency_issue, ocr_dependency_issue,
)


def check_package(module, distribution):
    try:
        version = importlib.metadata.version(distribution)
    except importlib.metadata.PackageNotFoundError:
        version = None
    try:
        loaded = importlib.import_module(module)
        if module == 'rapidocr_onnxruntime' and not callable(getattr(loaded, 'RapidOCR', None)):
            raise ImportError('RapidOCR entry point is unavailable')
        return {'ok': True, 'version': version}
    except Exception as exc:
        return {'ok': False, 'version': version, 'error': f'{type(exc).__name__}: {exc}'}


def check_executable(path, flag):
    if not path:
        return {'ok': False, 'error': 'Executable not found on PATH'}
    try:
        run = subprocess.run([path, flag], capture_output=True, text=True,
                             errors='replace', timeout=10)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {'ok': False, 'error': f'{type(exc).__name__}: {exc}'}
    output = (run.stdout or run.stderr).strip()
    if run.returncode:
        return {'ok': False, 'error': output[-500:] or f'Exit code {run.returncode}'}
    return {'ok': True, 'version': output.splitlines()[0] if output else None}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', action='version', version=VERSION)
    parser.add_argument('--plain', action='store_true', help='输出中文环境检查摘要')
    parser.add_argument('--require-ocr', action='store_true', help='OCR 不可用时退出 1')
    parser.add_argument('--require-render', action='store_true', help='真实渲染工具不可用时退出 1')
    args = parser.parse_args(argv)

    package_details = {module: check_package(module, distribution) for module, distribution
                       in {**CORE_PACKAGES, 'rapidocr_onnxruntime': OCR_PACKAGE}.items()}
    packages = {module: item['ok'] for module, item in package_details.items()}
    office, pdftoppm = office_commands()
    render_details = {'office': check_executable(office, '--version'),
                      'pdftoppm': check_executable(pdftoppm, '-v')}
    can_build = all(packages[module] for module in CORE_PACKAGES)
    can_ocr = packages['rapidocr_onnxruntime']
    can_render = all(item['ok'] for item in render_details.values())
    issues = []
    if not can_build:
        issues.append(core_dependency_issue())
    if not can_ocr:
        issues.append(ocr_dependency_issue())
    if not can_render:
        issues.append(office_dependency_issue())

    result = {'version': VERSION, 'python': sys.executable,
              'packages': packages, 'package_details': package_details,
              'office': office, 'pdftoppm': pdftoppm, 'render_details': render_details,
              'can_build_measured_layout': can_build, 'can_ocr': can_ocr,
              'can_actual_render': can_render, 'issues': issues}
    if args.plain:
        print(f'图片转可编辑 PPT {VERSION} · {sys.executable}')
        for label, ready in [('基础转换', can_build), ('可选 OCR', can_ocr), ('真实渲染工具', can_render)]:
            print(f'  {label}  {"就绪" if ready else "未就绪"}')
        for issue in issues:
            print(f'  [{issue["code"]}] {issue["next_action"]}')
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(not can_build or (args.require_ocr and not can_ocr)
               or (args.require_render and not can_render))


if __name__ == '__main__':
    raise SystemExit(main())
