"""Dense page OCR: full-page context plus overlapping enlarged tiles.
No recognition results are silently promoted to verified text.
"""
import argparse
import json
from pathlib import Path
import tempfile
from PIL import Image, ImageOps
from _runtime import ocr_dependency_issue
from _ui import SkillError, run


def iou(a, b):
    x,y,w,h = a; X,Y,W,H = b
    inter = max(0,min(x+w,X+W)-max(x,X))*max(0,min(y+h,Y+H)-max(y,Y))
    return inter/max(1,w*h+W*H-inter)


def positions(length, tile, overlap):
    """Cover trailing strips with a full, overlapping tile instead of skipping them."""
    if length <= tile:
        return [0]
    return sorted(set(range(0, length-tile+1, tile-overlap)) | {length-tile})


def merge_candidates(results):
    def text(r):
        return ''.join(r['text'].split())

    def containment(a, b):
        x,y,w,h=a; X,Y,W,H=b
        inter=max(0,min(x+w,X+W)-max(x,X))*max(0,min(y+h,Y+H)-max(y,Y))
        return inter/max(1,min(w*h,W*H))

    kept=[]
    for candidate in sorted(results, key=lambda r:r.get('score',0), reverse=True):
        r=dict(candidate)
        r['needs_review']=bool(r.get('needs_review') or r.get('score',0)<.90)
        duplicate=next((q for q in kept if iou(r['box'],q['box']) > .60 or
                        (text(r)==text(q) and containment(r['box'],q['box'])>.85)),None)
        if duplicate:
            alternatives=set(duplicate.get('alternatives',[])) | set(r.get('alternatives',[]))
            if text(duplicate)!=text(r):
                alternatives.add(r['text'])
            if alternatives:
                duplicate['alternatives']=sorted(alternatives)
            duplicate['needs_review']=bool(duplicate.get('needs_review') or r.get('needs_review'))
            continue
        kept.append(r)
    # A partial recognition is evidence for a whole line, not a second text object.
    # Keep contradictory/subdivided alternatives flagged; never decide names by score.
    retained=[]
    for a in kept:
        parent=next((b for b in kept if a is not b and text(a)!=text(b) and
                     text(a) in text(b) and containment(a['box'],b['box'])>.85 and
                     a['box'][2]*a['box'][3] < b['box'][2]*b['box'][3]),None)
        if parent:
            if a.get('alternatives') or a.get('needs_review'):
                parent.setdefault('alternatives',[]).extend(a.get('alternatives',[]))
                parent['needs_review']=True
            continue
        retained.append(a)
    retained.sort(key=lambda r:(r['box'][1],r['box'][0]))
    for i,r in enumerate(retained):
        r['name']=f'text_{i:03d}'
        r['alternatives']=sorted(set(r.get('alternatives',[])))
        r['needs_review']=bool(r.get('needs_review') or r.get('score',0)<.90 or r['alternatives'])
    return retained


def recognize(source, tile_size=720, overlap=160, scale=2, engine=None, detector=None):
    if tile_size < 1 or not 0 <= overlap < tile_size or scale <= 0:
        raise ValueError('Require 0 <= overlap < tile_size and scale > 0')
    if detector is None:
        from describe_image import detect_texts
        detector=detect_texts
    if engine is None:
        try:
            from rapidocr_onnxruntime import RapidOCR
        except (ImportError, OSError) as exc:
            issue = ocr_dependency_issue()
            raise SkillError(issue['message'], reason=str(exc),
                             next_steps=[issue['next_action']], doc=issue['doc'], code=1) from exc
        # Use a bounded maximum-side policy: retain enlarged tile detail without
        # forcing the short side of every page to 1920px. Bound CPU threads per page.
        engine=RapidOCR(det_limit_side_len=max(1920, round(tile_size*scale)), det_limit_type="max",
                        intra_op_num_threads=2, inter_op_num_threads=1)
    with Image.open(source) as opened, tempfile.TemporaryDirectory(prefix='ocr-tiles-') as td:
        im=ImageOps.exif_transpose(opened).convert('RGB')
        full=Path(td)/'full.png';im.save(full)
        results=detector(str(full),engine=engine)
        for r in results:
            r['ocr_pass']='full'
        w,h=im.size
        # Always include enlarged evidence, also for small but densely lettered pages.
        for y in positions(h,tile_size,overlap):
            for x in positions(w,tile_size,overlap):
                right,bottom=min(w,x+tile_size),min(h,y+tile_size)
                patch=im.crop((x,y,right,bottom))
                new=(max(1,round(patch.width*scale)),max(1,round(patch.height*scale)))
                patch=patch.resize(new,Image.Resampling.LANCZOS)
                path=Path(td)/'tile.png';patch.save(path)
                sx,sy=new[0]/(right-x),new[1]/(bottom-y)
                for r in detector(str(path),engine=engine):
                    bx,by,bw,bh=r['box']
                    if ((x>0 and bx<3) or (right<w and bx+bw>new[0]-3) or
                        (y>0 and by<3) or (bottom<h and by+bh>new[1]-3)):
                        continue
                    left,top=max(0,x+bx/sx),max(0,y+by/sy)
                    rx,by2=min(w,x+(bx+bw)/sx),min(h,y+(by+bh)/sy)
                    if rx<=left or by2<=top:
                        continue
                    r['box']=[round(left,2),round(top,2),round(rx-left,2),round(by2-top,2)]
                    r['ocr_pass']='tile'
                    results.append(r)
    return merge_candidates(results)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source');ap.add_argument('-o','--out',default='texts.json')
    ap.add_argument('--tile-size',type=int,default=720)
    ap.add_argument('--overlap',type=int,default=160)
    ap.add_argument('--scale',type=float,default=2)
    a=ap.parse_args()
    texts=recognize(a.source,tile_size=a.tile_size,overlap=a.overlap,scale=a.scale)
    Path(a.out).write_text(json.dumps(texts,ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':
    raise SystemExit(run(main))
