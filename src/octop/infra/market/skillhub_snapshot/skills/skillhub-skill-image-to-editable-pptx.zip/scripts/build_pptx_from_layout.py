#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""根据 layout.json 构建可编辑 PPTX。

接受自动识别草稿和测量后的布局。box 使用源图像素坐标，1 px = 9525 EMU。
测量模式按明确的文字框、字号、图形坐标和 source_box 放置；兼容旧版 ink-fit、
裁图字段和描边别名。图片等比放置，按 z 顺序写入独立对象。

批量主入口始终保留背景装饰。独立构建入口仅在显式设置 --bg-blank-alpha
时启用旧版背景过滤，0 为默认关闭。使用 --strict-assets 禁止缺素材时临裁。

调用：
  python scripts/build_pptx_from_layout.py source.png layout.json crops/ -o final.pptx
"""
import argparse
import json
import os
import sys
import subprocess
import shutil

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, hint, ok, run, warn  # noqa: E402
import bg_blank  # noqa: E402   （3.5.0）背景隐形图形 → 空白背景判定

# 1 inch = 96 px ≈ 914400 EMU → 1 px = 9525 EMU
EMU_PER_PX = 9525
PX_PER_PT = 96.0 / 72.0          # 1 pt = 1.3333 px
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"

# CJK 字形 ink 高度 / em 高度的经验值，仅在没有可用字体文件时兜底。
INK_RATIO = 0.86

TYPE_MAP = {
    "rect": "RECTANGLE",
    "roundrect": "ROUNDED_RECTANGLE",
    "rounded_rect": "ROUNDED_RECTANGLE",
    "ellipse": "OVAL",
    "circle": "OVAL",
    "chamfer": "SNIP_1_RECTANGLE",     # 切角矩形，近似左上斜切
    "snip": "SNIP_1_RECTANGLE",
    "arrow_left": "LEFT_ARROW",
    "arrow_right": "RIGHT_ARROW",
    "arrow_up": "UP_ARROW",
    "arrow_down": "DOWN_ARROW",
    "triangle": "ISOSCELES_TRIANGLE",
    "chevron": "CHEVRON",
}
ARROW_MAP = {"left": "LEFT_ARROW", "right": "RIGHT_ARROW",
             "up": "UP_ARROW", "down": "DOWN_ARROW"}

# 无 fontconfig 时按平台探测字体；实际度量与导出使用同一个已解析字体族。
_FONT_ALIASES = {
    "微软雅黑": ["C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/msyhbd.ttc",
                 "/System/Library/Fonts/PingFang.ttc",
                 "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"],
    "microsoft yahei": ["C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/msyhbd.ttc"],
    "等线": ["C:/Windows/Fonts/Deng.ttf", "C:/Windows/Fonts/Dengb.ttf"],
    "黑体": ["C:/Windows/Fonts/simhei.ttf"],
    "宋体": ["C:/Windows/Fonts/simsun.ttc"],
    "苹方": ["/System/Library/Fonts/PingFang.ttc"],
    "pingfang sc": ["/System/Library/Fonts/PingFang.ttc"],
    "思源黑体": ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"],
}
# 通用兜底：任何能渲染 CJK 的字体都比默认位图字体强。
_FONT_FALLBACK = [
    "C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/simhei.ttf",
    "C:/Windows/Fonts/Deng.ttf", "C:/Windows/Fonts/simsun.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]

_FONT_PATH_CACHE = {}
_FONT_OBJ_CACHE = {}


def _xml(xml_str: str):
    """把 XML 片段解析成 **lxml** 元素。

    python-pptx 的文档树是 lxml，用 xml.etree 造出来的元素插不进去
    （TypeError: expected lxml.etree._Element）。必须走 pptx.oxml.parse_xml。
    """
    from pptx.oxml import parse_xml
    return parse_xml(xml_str)


# ──────────────────────────── 基础工具 ────────────────────────────
def _emu(px: float) -> int:
    return int(round(float(px) * EMU_PER_PX))


def _rgb(hexstr):
    from pptx.dml.color import RGBColor
    h = str(hexstr).lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _hex(triple) -> str:
    return "#%02X%02X%02X" % tuple(int(max(0, min(255, v))) for v in triple)


def resolve_font(font_name, bold=False):
    """Resolve both measured face and exported family from the same installed font."""
    key = (str(font_name or "").strip(), bool(bold))
    if key in _FONT_PATH_CACHE:
        return dict(_FONT_PATH_CACHE[key])
    info = {'requested': key[0], 'resolved': key[0], 'file': None, 'index': 0,
            'bold': bool(bold), 'substituted': False}
    if shutil.which('fc-match'):
        try:
            pattern = key[0] + (':weight=bold' if bold else ':weight=regular')
            fields = subprocess.check_output(
                ['fc-match', '-f', '%{family}\n%{file}\n%{index}', pattern],
                text=True, timeout=10).splitlines()
            if len(fields) >= 2 and os.path.isfile(fields[1]):
                info.update(resolved=fields[0].split(',')[0], file=fields[1],
                            index=int(fields[2]) if len(fields) > 2 and fields[2] else 0)
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    if not info['file']:
        candidates = list(_FONT_ALIASES.get(key[0].lower(), []))
        if bold:
            candidates.sort(key=lambda p: 'bd' not in os.path.basename(p).lower())
        path = next((p for p in candidates + _FONT_FALLBACK if os.path.isfile(p)), None)
        if path:
            from PIL import ImageFont
            font = ImageFont.truetype(path, 20)
            info.update(file=path, resolved=font.getname()[0])
    info['substituted'] = info['resolved'].casefold() != key[0].casefold() or not info['file']
    _FONT_PATH_CACHE[key] = dict(info)
    return info


def _resolve_font_file(font_name: str, bold: bool = False):
    return resolve_font(font_name, bold)['file']


def _font_at(px: float, bold: bool, font_name: str):
    info = resolve_font(font_name, bold)
    if not info['file']:
        return None
    size = max(6, int(round(px)))
    ck = (info['file'], info['index'], size)
    if ck not in _FONT_OBJ_CACHE:
        from PIL import ImageFont
        try:
            _FONT_OBJ_CACHE[ck] = ImageFont.truetype(info['file'], size, index=info['index'])
        except (OSError, ValueError):
            _FONT_OBJ_CACHE[ck] = None
    return _FONT_OBJ_CACHE[ck]


def _font_size_from_box(box_h_px: float, lines: int = 1) -> float:
    """兜底字号模型：由 ink 高度反推 pt（无可用字体文件时使用）。"""
    px = max(8.0, float(box_h_px) / max(1, int(lines)))
    return max(6.0, min(200.0, (px / INK_RATIO) * 72.0 / 96.0))


# ──────────────────────────── 颜色 / ink 度量 ────────────────────────────
def _box_inner(sub_hw, box, pad):
    """box 在（已外扩 pad 的）子图中的内部掩码；box 为子图坐标。"""
    h, w = sub_hw
    x, y, bw, bh = box
    m = np.zeros((h, w), dtype=bool)
    x0, y0 = max(0, int(x)), max(0, int(y))
    x1, y1 = min(w, int(x) + int(bw)), min(h, int(y) + int(bh))
    if x1 > x0 and y1 > y0:
        m[y0:y1, x0:x1] = True
    return m


def _ring_pixels(sub):
    """取子图外圈两行两列像素，作为"局部背景"的兜底估计。"""
    top, bot = sub[0:2].reshape(-1, 3), sub[-2:].reshape(-1, 3)
    left, right = sub[:, 0:2].reshape(-1, 3), sub[:, -2:].reshape(-1, 3)
    return np.concatenate([top, bot, left, right], axis=0)


def _bg_estimate(sub, inner, quant=16, min_share=0.30):
    """兜底背景估计：框内出现最多的量化颜色，不够集中就退回外圈中位数。"""
    pix = sub[inner] if inner is not None else sub.reshape(-1, 3)
    if pix.size == 0:
        pix = sub.reshape(-1, 3)
    q = (pix.astype(np.int32) // quant) * quant
    keys, inv, counts = np.unique(q, axis=0, return_inverse=True, return_counts=True)
    k = int(np.argmax(counts))
    if counts[k] / max(1, counts.sum()) >= min_share:
        return np.median(pix[inv == k].astype(np.float64), axis=0)
    return np.median(_ring_pixels(sub).astype(np.float64), axis=0)


def _erode1(m):
    """4 邻域腐蚀 1px（用 pad 而不是 np.roll，避免画布边缘环绕）。"""
    p = np.pad(m, 1, constant_values=False)
    return (p[1:-1, 1:-1] & p[:-2, 1:-1] & p[2:, 1:-1]
            & p[1:-1, :-2] & p[1:-1, 2:])


def _rect_border(inner):
    """矩形掩码的 1px 边框。"""
    return inner & ~_erode1(inner)


def _otsu(vals):
    """一维 Otsu 阈值。"""
    hist, _ = np.histogram(vals, bins=256, range=(0.0, 256.0))
    total = int(hist.sum())
    if total <= 0:
        return 128
    idx = np.arange(256, dtype=np.float64)
    w0 = np.cumsum(hist).astype(np.float64)
    w1 = total - w0
    s0 = np.cumsum(hist * idx)
    s1 = s0[-1] - s0
    valid = (w0 > 0) & (w1 > 0)
    if not valid.any():
        return 128
    mu0 = np.zeros(256)
    mu1 = np.zeros(256)
    mu0[valid] = s0[valid] / w0[valid]
    mu1[valid] = s1[valid] / w1[valid]
    var = w0 * w1 * (mu0 - mu1) ** 2
    var[~valid] = -1.0
    return int(np.argmax(var))


def _split_ink_bg(sub, inner):
    """把框内像素分成 ink / 背景两类 → (ink_mask, bg_rgb, ink_rgb)。

    判据不是"谁像素多"——JPEG 噪声会把白字拆成 (240,240,240)/(224,240,240)
    好几个桶，众数在 20% 和 16% 之间抖动，一抖字色就翻。真正稳的判据是
    **连通性**：文字是框内不接触边框的"孤岛"，背景是环绕文字、接触边框的那层。
    对白字蓝底、黑字白底、任意渐变底都成立。
    """
    if inner.sum() < 8:
        return None, None, None
    lum = (sub[:, :, 0] * 0.299 + sub[:, :, 1] * 0.587 + sub[:, :, 2] * 0.114)
    t = _otsu(lum[inner])
    dark = inner & (lum < t)
    light = inner & (lum >= t)
    n = int(inner.sum())
    if dark.sum() < 0.03 * n or light.sum() < 0.03 * n:
        return None, None, None
    border = _rect_border(inner)
    dt, lt = int((dark & border).sum()), int((light & border).sum())
    if dt > lt:
        bgm, inkm = dark, light
    elif lt > dt:
        bgm, inkm = light, dark
    else:
        return None, None, None
    bg = np.median(sub[bgm].astype(np.float64), axis=0)
    ink_px = sub[inkm].astype(np.float64)
    d = np.abs(ink_px - bg).sum(axis=1)
    if d.size:
        keep = d >= max(60.0, 0.5 * float(d.max()))
        if keep.sum() >= 3:
            inkm = inkm & (np.abs(sub - bg.reshape(1, 1, 3)).sum(axis=2)
                           >= max(60.0, 0.5 * float(d.max())))
            ink_px = ink_px[keep]
    return inkm, bg, np.median(ink_px, axis=0)


def _ink_analysis(img, box, pad=None):
    """一次算完源图 ink 框与字色 → ((x, y, w, h), '#RRGGBB')，失败给 (None, None)。

    OCR 给的框是"行框"，含 1~6px 冗余；直接拿它当文本框会让文字位置、字号、
    颜色三者都带上系统偏差。这里回到像素本身量一次，三者都以它为准。
    """
    try:
        x, y, w, h = [int(round(v)) for v in box]
    except Exception:
        return None, None
    if w <= 0 or h <= 0:
        return None, None
    if pad is None:
        pad = max(3, int(round(h * 0.3)))
    x0, y0 = max(0, x - pad), max(0, y - pad)
    x1, y1 = min(img.width, x + w + pad), min(img.height, y + h + pad)
    if x1 - x0 < 2 or y1 - y0 < 2:
        return None, None
    sub = np.asarray(img.crop((x0, y0, x1, y1)).convert("RGB")).astype(np.int32)
    # 只在原始 box 范围内找 ink，避免把相邻元素吃进来
    inner = _box_inner(sub.shape[:2], (x - x0, y - y0, w, h), pad)
    if not inner.any():
        return None, None

    ink_m, bg, ink_col = _split_ink_bg(sub, inner)
    if ink_m is None:
        # 退化路径：框内没有清晰的双峰（极短文本 / 纯色块），用众数 + 最远像素
        bg = _bg_estimate(sub, inner)
        dist = np.abs(sub - bg.reshape(1, 1, 3)).sum(axis=2)
        vals = dist[inner]
        dmax = float(vals.max()) if vals.size else 0.0
        if dmax < 40:
            return None, None
        ink_m = inner & (dist >= max(60.0, 0.55 * dmax))
        if ink_m.sum() < 4:
            return None, None
        ink_col = np.median(sub[ink_m].astype(np.float64), axis=0)

    ys, xs = np.where(ink_m)
    if len(xs) < 4:
        return None, None
    return ((x0 + int(xs.min()), y0 + int(ys.min()),
             int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)),
            _hex(ink_col))


def _measure_ink(img, box, pad=None, tol=60):
    """源图实测 ink 框（兼容旧调用）。"""
    return _ink_analysis(img, box, pad)[0]


def _ink_color(img, box, fallback="#282828", pad=None):
    """取文字字色（兼容旧调用）。"""
    return _ink_analysis(img, box, pad)[1] or fallback


# ──────────────────────────── 字号拟合 ────────────────────────────
def _fit_font_size(text: str, target_w: float, target_h: float,
                   font_name: str, bold: bool) -> tuple:
    """二分拟合字号，使渲染 ink 尽量等于目标 ink。

    返回 (size_pt, bbox)，bbox 为该字号下的 PIL ink 框（相对行盒左上角）。
    拟合以**宽度**为主（OCR 文本偶有误识，但字符数决定宽度，鲁棒），
    高度只作为 30% 权重的次要项。
    """
    lines = str(text).split("\n")
    line = max(lines, key=len) if lines else str(text)
    if not line.strip():
        line = " "
    n = max(1, len(lines))
    tw = max(4.0, float(target_w))
    th = max(4.0, float(target_h) / n)

    if _font_at(20, bold, font_name) is None:
        return _font_size_from_box(target_h, n), None

    lo, hi = 4.0, 400.0
    best = None
    for _ in range(26):
        mid = (lo + hi) / 2.0
        f = _font_at(mid, bold, font_name)
        if f is None:
            break
        try:
            bb = f.getbbox(line)
        except Exception:
            break
        rw, rh = bb[2] - bb[0], bb[3] - bb[1]
        err = abs(rw - tw) / tw + 0.3 * abs(rh - th) / th
        if best is None or err < best[0]:
            best = (err, mid, bb)
        if rw < tw:
            lo = mid
        else:
            hi = mid
        if hi - lo < 0.2:
            break
    if best is None:
        return _font_size_from_box(target_h, n), None
    px = max(6, round(best[1]))
    return max(5.0, min(400.0, px / PX_PER_PT)), best[2]


# ──────────────────────────── 填充 / 边框 / 透明度 ────────────────────────────
def _set_fill_xml(sp, xml_str: str):
    """按 CT_ShapeProperties 的元素顺序替换填充（必须紧跟几何元素之后）。"""
    from pptx.oxml.ns import qn
    spPr = sp._element.spPr
    for tag in ("a:noFill", "a:solidFill", "a:gradFill", "a:blipFill",
                "a:pattFill", "a:grpFill"):
        for el in spPr.findall(qn(tag)):
            spPr.remove(el)
    new = _xml(xml_str)
    geom = None
    for tag in ("a:prstGeom", "a:custGeom"):
        geom = spPr.find(qn(tag))
        if geom is not None:
            break
    if geom is not None:
        geom.addnext(new)
    else:
        spPr.insert(0, new)


def _grad_xml(colors, direction):
    cols = [str(c).lstrip("#") for c in colors if c]
    if len(cols) < 2:
        cols = (cols or ["FFFFFF"]) * 2
    ang = {"h": 0, "v": 5400000, "diag": 2700000}.get(direction or "h", 0)
    step = 100000 / (len(cols) - 1)
    gs = "".join(f'<a:gs pos="{int(round(i * step))}">'
                 f'<a:srgbClr val="{c}"/></a:gs>' for i, c in enumerate(cols))
    return (f'<a:gradFill xmlns:a="{A_NS}" rotWithShape="1"><a:gsLst>{gs}</a:gsLst>'
            f'<a:lin ang="{ang}" scaled="0"/></a:gradFill>')


def _solid_xml(color):
    return (f'<a:solidFill xmlns:a="{A_NS}">'
            f'<a:srgbClr val="{str(color).lstrip("#")}"/></a:solidFill>')


def _apply_fill(sp, el):
    grad = el.get("grad")
    fill_hex = el.get("fill")
    if grad:
        cols = grad[1] if (isinstance(grad, (list, tuple)) and len(grad) == 2
                           and isinstance(grad[1], (list, tuple))) else grad
        direction = el.get("dir") or (grad[0] if isinstance(grad, (list, tuple))
                                      and isinstance(grad[1], (list, tuple)) else "h")
        _set_fill_xml(sp, _grad_xml(cols, direction))
    elif fill_hex:
        _set_fill_xml(sp, _solid_xml(fill_hex))
    else:
        from pptx.oxml.ns import qn
        spPr = sp._element.spPr
        for tag in ("a:solidFill", "a:gradFill", "a:blipFill", "a:pattFill", "a:grpFill"):
            for e in spPr.findall(qn(tag)):
                spPr.remove(e)
        sp.fill.background()


def _apply_line(sp, el):
    """边框：兼容 `border_width`（describe_image 输出）与 `bw`（手工 layout）。"""
    from pptx.util import Pt
    border = el.get("border")
    bw = el.get("border_width")
    if bw in (None, ""):
        bw = el.get("bw")
    try:
        bw = float(bw or 0)
    except Exception:
        bw = 0.0
    if border and bw > 0:
        sp.line.color.rgb = _rgb(border)
        sp.line.width = Pt(max(0.25, bw * 72.0 / 96.0))   # px → pt
    else:
        sp.line.fill.background()


def _apply_radius(sp, el):
    """圆角半径：像素 → 相对短边比例（adj 值 0..50000）。"""
    box = el["box"]
    short = max(1, min(box[2], box[3]))
    r = el.get("radius") or 8
    try:
        sp.adjustments[0] = max(0.0, min(0.5, float(r) / short))
    except Exception:
        pass


def _apply_alpha(sp, pct):
    from pptx.oxml.ns import qn
    try:
        alpha = max(0, min(100000, int(float(pct) * 1000)))
    except Exception:
        return
    spPr = sp._element.spPr
    for fill_tag in ("a:solidFill", "a:gradFill"):
        fl = spPr.find(qn(fill_tag))
        if fl is None:
            continue
        for clr in fl.iter(qn("a:srgbClr")):
            if clr.find(qn("a:alpha")) is None:
                clr.append(clr.makeelement(qn("a:alpha"), {"val": str(alpha)}))
        return


def _set_page_background(slide, bg) -> str:
    """把 layout.background 写进 `p:cSld/p:bg`。

    3.3.2 完全没做这一步，深色版式导出后是灰白底 → 整页颜色全错。
    """
    from pptx.oxml.ns import qn
    if not bg:
        return "none"
    cSld = slide._element.find(qn("p:cSld"))
    if cSld is None:
        return "none"
    for old in cSld.findall(qn("p:bg")):
        cSld.remove(old)

    kind = bg.get("kind")
    grad = bg.get("grad")
    if kind == "gradient" and grad and len(grad) >= 2:
        body = _grad_xml(grad, bg.get("dir") or "v")
        what = f"gradient {grad[0]}→{grad[1]} ({bg.get('dir') or 'v'})"
    else:
        fill = bg.get("fill") or "#FFFFFF"
        body = _solid_xml(fill)
        what = f"solid {fill}"
    xml = (f'<p:bg xmlns:p="{P_NS}" xmlns:a="{A_NS}"><p:bgPr>{body}'
           f'<a:effectLst/></p:bgPr></p:bg>')
    cSld.insert(0, _xml(xml))
    return what


# ──────────────────────────── 主流程 ────────────────────────────
def build(args, presentation=None, save=True):
    from pptx import Presentation
    from pptx.util import Emu, Pt
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN, MSO_AUTO_SIZE
    from pptx.enum.shapes import MSO_SHAPE
    from PIL import Image

    if not os.path.isfile(args.source):
        raise SkillError(f"找不到源图：{args.source}",
                         reason="路径不存在。", next_steps=["用绝对路径重试。"])
    if not os.path.isfile(args.layout):
        raise SkillError(f"找不到 layout.json：{args.layout}",
                         reason="请先运行 describe_image.py 或提供手工 layout。")

    with open(args.layout, encoding="utf-8-sig") as f:
        layout = json.loads(f.read())
    W, H = layout["source_size"]
    src_img = Image.open(args.source).convert("RGB")
    if src_img.size != (W, H):
        raise ValueError(f"layout 尺寸 {W}x{H} 与源图 {src_img.size} 不一致；请重新测量，不能静默缩放坐标。")

    crops_dir = args.crops
    os.makedirs(crops_dir, exist_ok=True)
    layout_dir = os.path.dirname(os.path.abspath(args.layout))
    if 'visual_inventory' in layout:
        from visual_inventory import audit_visual_inventory, audit_backdrop_removal
        audit = audit_visual_inventory(layout)
        if audit['status'] != 'pass':
            raise ValueError('; '.join(audit['issues']))
        audit_backdrop_removal(layout, args.source, layout_dir)

    prs = presentation if presentation is not None else Presentation()
    if presentation is None:
        prs.slide_width = Emu(_emu(W))
        prs.slide_height = Emu(_emu(H))
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    from layered_support import place_background
    bg_desc = place_background(slide, layout.get("background"), layout_dir, args.source, W, H,
                               _set_page_background, _apply_fill)
    ok(f"  页面背景: {bg_desc}")

    # ── （3.5.0）背景隐形装饰 → 按空白背景处理 ──────────────────────────
    # 源图里"和底色几乎分不开"的装饰（整页水印、淡色底纹、低对比同色块）若被
    # 还原成实色原生形状，反而比源图更显眼。这里在落盘前把它们摘掉，页面背景
    # 原样透出。判定口径见 scripts/bg_blank.py；--no-bg-blank 可整体关闭。
    src_arr = np.asarray(src_img)
    shapes_in = layout.get("shapes", [])
    kept_shapes, blanked = bg_blank.blank_shapes(
        shapes_in, layout.get("background"), (W, H),
        texts=layout.get("texts", []),
        icons=layout.get("icons", []) + layout.get("images", []),
        arr=src_arr,
        threshold=getattr(args, "bg_blank_alpha", bg_blank.DEFAULT_BLANK_ALPHA),
        enabled=bool(getattr(args, "bg_blank_alpha", 0)) and not getattr(args, "no_bg_blank", False))
    _blank_alpha = getattr(args, "bg_blank_alpha", bg_blank.DEFAULT_BLANK_ALPHA)
    if blanked:
        ok(f"  隐形背景装饰（按空白处理）: {len(blanked)} 个"
           f"（不透明度 < {_blank_alpha:g}%）")
        for b in blanked[:8]:
            hint(f"    - {b['name'] or '(未命名)'} box={b['box']} "
                 f"fill={b['fill']} alpha={b['alpha']}%  {b['reason']}")
        if len(blanked) > 8:
            hint(f"    … 其余 {len(blanked) - 8} 个见 bg_blank.py 自检输出")
    layout["shapes"] = kept_shapes
    layout["blanked_shapes"] = blanked

    # ── 统一 z 排序（3.3.2 回填层级：底层矩形不得覆盖文字）────────────────
    queue = []
    for i, s in enumerate(layout.get("shapes", [])):
        queue.append((s.get("z", 0), 0, i, "shape", s))
    for i, im in enumerate(layout.get("images", [])):
        queue.append((im.get("z", 5), 1, i, "image", im))
    for i, ic in enumerate(layout.get("icons", [])):
        # describe_image.py 的旧字段：name 即 crops/<name>.png
        f = ic.get("file") or (str(ic.get("name", "")) + ".png")
        queue.append((ic.get("z", 5), 1, i, "image", {**ic, "file": f}))
    for i, t in enumerate(layout.get("texts", [])):
        queue.append((t.get("z", 100), 2, i, "text", t))
    queue.sort(key=lambda r: (r[0], r[1], r[2]))

    n_shape = n_img = n_txt = 0
    for _z, _k, _i, kind, el in queue:
        box = [float(v) for v in el["box"]]
        x, y, w, h = box
        if (w <= 0 or h <= 0) and el.get("type") != "line":
            raise ValueError(f"Invalid element size: {el.get('name', kind)} {box}")

        if kind == "shape":
            t = el.get("type", "rect")
            if el.get("arrow"):
                t = ARROW_MAP.get(el["arrow"], t)
            from layered_support import special_shape, apply_effects, clear_theme_effects
            special = special_shape(slide, el)
            shape_type = getattr(MSO_SHAPE, TYPE_MAP.get(t, t if t in ARROW_MAP.values() else "RECTANGLE"))
            try:
                sp = special if special is not None else slide.shapes.add_shape(
                    shape_type, Emu(_emu(x)), Emu(_emu(y)), Emu(_emu(w)), Emu(_emu(h)))
            except Exception as exc:
                raise ValueError(f"插入形状 {el.get('name')} 失败：{exc}") from exc
            clear_theme_effects(sp)
            if t != "line":
                _apply_fill(sp, el)
            _apply_line(sp, el)
            if t in ("roundrect", "rounded_rect", "chamfer", "snip"):
                _apply_radius(sp, el)
            if el.get("alpha") is not None:
                _apply_alpha(sp, el["alpha"])
            apply_effects(sp._element.spPr, el)
            sp.name = el.get("name", f"shape_{n_shape:03d}")
            sp.rotation = float(el.get("rotation", 0))
            n_shape += 1

        elif kind == "image":
            if _place_image(slide, el, crops_dir, layout_dir, src_img, W, H, strict=getattr(args, "strict_assets", False)):
                n_img += 1

        else:
            n_txt += _place_text(slide, el, src_img, args, MSO_ANCHOR,
                                 PP_ALIGN, MSO_AUTO_SIZE, Emu, Pt)

    from layered_support import fit_slide_to_canvas
    fit_slide_to_canvas(slide, W, H, prs.slide_width, prs.slide_height)
    if not save:
        return prs
    out = args.out
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    prs.save(out)
    ok(f"已生成 {out}  页面 {_emu(W)} x {_emu(H)} EMU ({W}x{H}px)  "
       f"形状 {n_shape}  图片 {n_img}  文本 {n_txt}")
    hint("box = 源图像素坐标；文字按实测 ink 框拟合字号与基线，比例锁定不拉伸。")
    return 0


def _place_image(slide, el, crops_dir, layout_dir, src_img, W, H, strict=False) -> bool:
    """插入图片：按 contain 等比缩放居中，绝不拉伸。"""
    from pptx.util import Emu
    from PIL import Image

    box = [float(v) for v in el["box"]]
    x, y, w, h = box
    path = el.get("file") or ""
    if not os.path.isabs(path):
        p1 = os.path.join(crops_dir, path)
        p2 = os.path.join(layout_dir, path)
        p3 = os.path.join(crops_dir, os.path.basename(path))
        path = next((p for p in (p1, p2, p3) if os.path.isfile(p)), p1)
    if not os.path.isfile(path):
        if strict:
            raise FileNotFoundError(f"Missing asset: {path}")
        # 兜底：素材缺失时按 crop（缺省 box）从源图临裁一份，保证 build 不挂。
        # 临裁图未去背景，只用于占位，必须在上游补正式透明素材。
        cb = el.get("crop") or el["box"]
        cx, cy = int(round(cb[0])), int(round(cb[1]))
        cw, ch = int(round(cb[2])), int(round(cb[3]))
        cx, cy = max(0, cx - 2), max(0, cy - 2)
        cw, ch = min(W - cx, cw + 4), min(H - cy, ch + 4)
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            src_img.crop((cx, cy, cx + cw, cy + ch)).save(path)
            warn(f"缺少素材 {el.get('name')}，已按源图临裁 {path}（未去背景）")
        except Exception as exc:
            warn(f"缺少素材 {el.get('name')}（{path}）且临裁失败：{exc}，跳过。")
            return False
    try:
        with Image.open(path) as asset_image:
            iw, ih = asset_image.size
    except Exception as exc:
        raise ValueError(f"读取素材 {path} 失败：{exc}") from exc
    from source_geometry import image_box
    dx, dy, dw, dh = image_box(el, (iw, ih), (W, H))
    try:
        pic = slide.shapes.add_picture(path, Emu(_emu(dx)), Emu(_emu(dy)),
                                 width=Emu(_emu(dw)), height=Emu(_emu(dh)))
        pic.name = el.get("name", os.path.basename(path))
        pic.rotation = float(el.get("rotation", 0))
        return True
    except Exception as exc:
        raise ValueError(f"插入图片 {el.get('name')} 失败：{exc}") from exc


def _place_text(slide, el, src_img, args, MSO_ANCHOR, PP_ALIGN,
                MSO_AUTO_SIZE, Emu, Pt) -> int:
    """插入文本框：按实测 ink 框拟合字号，并反推文本框位置。"""
    box = [float(v) for v in el["box"]]
    x, y, w, h = box
    text = str(el.get("text", ""))
    if not text.strip():
        return 0

    # 1) 实测 ink 框（拿不到就退回 OCR 框）
    ink = _measure_ink(src_img, box) if (getattr(args, "ink_fit", True) and
           el.get("box_mode") != "frame" and el.get("ink_fit", True)) else None
    ix, iy, iw, ih = ink if ink else (x, y, w, h)

    # 2) 字号：显式 size_pt 优先，其次字体度量拟合，最后经验模型
    font_name = el.get("font_name", args.font_name)
    bold = bool(el.get("bold", False))
    font_name = resolve_font(font_name, bold)["resolved"]
    size = el.get("size_pt")
    bb = None
    if not size:
        size, bb = _fit_font_size(text, iw, ih, font_name, bold)
    size = float(size)

    # 3) 文本框定位：PIL ink 相对行盒左上角有 (bb[0], bb[1]) 偏移，
    #    把它减掉，渲染出来的墨迹才会正好落在源图 ink 的位置。
    pad = int(getattr(args, "text_pad", 2) or 0)
    if bb is not None:
        bx0, by0, bx1, by1 = bb
        tx = ix - bx0 - pad
        ty = iy - by0 - pad
        tw = max(1, (bx1 - bx0)) + 2 * pad
        th = max(1, (by1 - by0)) + 2 * pad
    else:
        tx, ty, tw, th = ix - pad, iy - pad, iw + 2 * pad, ih + 2 * pad

    if el.get("box_mode") == "frame":
        tx, ty, tw, th = x, y, w, h
    tb = slide.shapes.add_textbox(Emu(_emu(tx)), Emu(_emu(ty)),
                                  Emu(_emu(tw)), Emu(_emu(th)))
    tb.name = el.get("name", text[:40])
    tb.rotation = float(el.get("rotation", 0))
    tf = tb.text_frame
    # 文字按 ink 框逐字定位，绝不允许渲染器自行换行（换行点与 PowerPoint 不一致）
    tf.word_wrap = bool(el.get("wrap", getattr(args, "wrap", False)))
    try:
        tf.auto_size = MSO_AUTO_SIZE.NONE
    except Exception:
        pass
    tf.margin_left = Emu(0)
    tf.margin_right = Emu(0)
    tf.margin_top = Emu(0)
    tf.margin_bottom = Emu(0)
    tf.vertical_anchor = {
        "t": MSO_ANCHOR.TOP, "m": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM,
    }.get(el.get("anchor", "t"), MSO_ANCHOR.TOP)

    color = el.get("color") or None
    if color is None:
        color = _ink_color(src_img, ink or box)
    runs = el.get("runs")
    lines = text.split("\n")
    align = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER,
             "r": PP_ALIGN.RIGHT}.get(el.get("align", "l"), PP_ALIGN.LEFT)

    from layered_support import style_text
    spans = el.get('spans')
    paragraphs = [[]]
    if spans is not None:
        if not isinstance(spans, list) or not all(isinstance(v, dict) and isinstance(v.get('text'), str) for v in spans):
            raise ValueError('spans must be a list of text/style objects')
        if ''.join(v['text'] for v in spans) != text:
            raise ValueError('spans concatenation must equal text exactly')
        if el.get('box_mode') != 'frame' or not el.get('size_pt'):
            raise ValueError('spans require measured box_mode=frame and explicit size_pt')
        for span in spans:
            for index, part in enumerate(span['text'].split('\n')):
                if index:
                    paragraphs.append([])
                if part:
                    paragraphs[-1].append({**span, 'text': part})
    else:
        paragraphs = []
        for line in lines:
            if runs and len(lines) == 1:
                paragraphs.append([{'text': ch, 'color': runs[min(i, len(runs)-1)]}
                                   for i, ch in enumerate(line)])
            else:
                paragraphs.append([{'text': line}])
    for li, segments in enumerate(paragraphs):
        p = tf.paragraphs[0] if li == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        if el.get('line_spacing_pt') is not None:
            if float(el['line_spacing_pt']) <= 0:
                raise ValueError('line_spacing_pt must be positive')
            p.line_spacing = Pt(float(el['line_spacing_pt']))
        elif el.get('spacing'):
            p.line_spacing = float(el['spacing'])
        for segment in segments:
            style = {**el, **segment}
            r = p.add_run()
            r.text = segment['text']
            r.font.size = Pt(float(style.get('size_pt') or size))
            r.font.bold = bool(style.get('bold', bold))
            face = resolve_font(style.get('font_name', font_name), r.font.bold)
            _set_cjk_font(r, face['resolved'])
            r.font.color.rgb = _rgb(style.get('color') or color)
            style_text(r, style, _grad_xml)
    return 1


def _set_cjk_font(run, name: str):
    """python-pptx 的 font.name 只写 latin typeface；中文需要再补 a:ea / a:cs。"""
    from pptx.oxml.ns import qn
    run.font.name = name
    rPr = run._r.get_or_add_rPr()
    for tag in ("a:ea", "a:cs"):
        el = rPr.find(qn(tag))
        if el is None:
            el = rPr.makeelement(qn(tag), {})
            rPr.append(el)
        el.set("typeface", name)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", help="源图")
    ap.add_argument("layout", help="layout.json（describe_image.py 或手工编制）")
    ap.add_argument("crops", help="素材目录（图标/插画 PNG）")
    ap.add_argument("-o", "--out", default="final.pptx", help="输出 PPTX 路径")
    ap.add_argument("--font-name", default="微软雅黑",
                    help="中文字体（默认微软雅黑，Windows/WPS 通用）")
    ap.add_argument("--text-pad", type=int, default=2,
                    help="文本框相对 ink 框的外扩像素（默认 2）")
    ap.add_argument("--no-ink-fit", dest="ink_fit", action="store_false",
                    help="关闭源图 ink 实测，直接用 OCR 框（调试用）")
    ap.add_argument("--strict-assets", action="store_true", help="素材缺失时终止，不从源图偷偷临裁")
    ap.add_argument("--wrap", action="store_true",
                    help="允许自动换行（默认关闭，按 ink 框逐字定位）")
    ap.add_argument("--bg-blank-alpha", type=float,
                    default=0.0,
                    help="背景隐形图形的等效不透明度阈值（0-100）：底层无描边大色块"
                         "低于它就按空白背景处理（默认 0，关闭）")
    ap.add_argument("--no-bg-blank", action="store_true",
                    help="关闭「背景隐形图形按空白处理」")
    args = ap.parse_args()
    return build(args)


if __name__ == "__main__":
    sys.exit(run(main))
