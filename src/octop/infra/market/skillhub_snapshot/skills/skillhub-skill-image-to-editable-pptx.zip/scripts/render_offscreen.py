#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""离屏几何自校验渲染器（读最终 PPTX，不依赖 Office）。

没有真实渲染工具时可使用本脚本排查几何。本脚本直接从
**最终导出的 PPTX** 里读取 slide XML，按 EMU 坐标在 Pillow 画布上重绘每个
形状 / 图片 / 文本，用来验证：

  * 每个对象是否落在源图像素坐标对应的位置上（坐标检查）
  * 文本框是否被裁断、图片是否被拉伸
  * 层级顺序是否正确（底层矩形是否盖住文字）

**视觉检查需要在 LibreOffice、PowerPoint 或 WPS 渲染最终文件后确认**。

支持 describe_image.py 自动 layout 与手工富 schema layout 两种产物：
    rect / roundrect / ellipse / snip(切角) / left|right|up|down arrow
    solidFill / gradFill / ln(边框宽) / alpha / 旋转

用法：
  python scripts/render_offscreen.py final.pptx -o rendered.png \\
      --size 1672x941 [--reference source.png] [--json]
"""
import argparse
import io
import json
import os
import posixpath
import sys
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageOps

EMU_PER_PX = 9525
NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}

# 跨平台字体候选。3.4.0 之前只有 macOS 路径 → Windows 上所有 CJK 都渲染成
# 豆腐块，RMS 自校验因此完全失去意义（差异被"两边都是豆腐"稀释）。
# 顺序：Windows → macOS → Linux。
FONT_BOLD = [("C:/Windows/Fonts/msyhbd.ttc", 0),
             ("C:/Windows/Fonts/msyh.ttc", 0),
             ("C:/Windows/Fonts/simhei.ttf", 0),
             ("C:/Windows/Fonts/Dengb.ttf", 0),
             ("C:/Windows/Fonts/simsun.ttc", 0),
             ("/System/Library/Fonts/PingFang.ttc", 8),
             ("/System/Library/Fonts/PingFang.ttc", 4),
             ("/System/Library/Fonts/Supplemental/Songti.ttc", 0),
             ("/Library/Fonts/Arial Unicode.ttf", 0),
             ("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc", 0),
             ("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc", 0)]
FONT_REG = [("C:/Windows/Fonts/msyh.ttc", 0),
            ("C:/Windows/Fonts/Deng.ttf", 0),
            ("C:/Windows/Fonts/simhei.ttf", 0),
            ("C:/Windows/Fonts/simsun.ttc", 0),
            ("/System/Library/Fonts/PingFang.ttc", 7),
            ("/System/Library/Fonts/PingFang.ttc", 3),
            ("/System/Library/Fonts/Supplemental/Songti.ttc", 0),
            ("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", 0),
            ("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc", 0)]

_FONT_CACHE = {}


def _font(px, bold):
    key = (int(px), bool(bold))
    if key in _FONT_CACHE:
        return _FONT_CACHE[key]
    f = ImageFont.load_default()
    for path, idx in (FONT_BOLD if bold else FONT_REG):
        if os.path.exists(path):
            try:
                f = ImageFont.truetype(path, max(6, int(px)), index=idx)
                break
            except Exception:
                continue
    _FONT_CACHE[key] = f
    return f


def _emu(v):
    try:
        return int(v) / EMU_PER_PX
    except Exception:
        return 0.0


def _hex2rgb(s):
    try:
        return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
    except Exception:
        return None


def _lerp(c1, c2, t):
    return tuple(int(round(c1[i] + (c2[i] - c1[i]) * t)) for i in range(3))


def _grad_lut(stops):
    """stops=[(pos, (r,g,b))...] → 长度 256 的 LUT。"""
    stops = sorted(stops)
    lut = []
    for i in range(256):
        t = i / 255.0
        if t <= stops[0][0]:
            lut.append(stops[0][1])
            continue
        if t >= stops[-1][0]:
            lut.append(stops[-1][1])
            continue
        for j in range(len(stops) - 1):
            p0, c0 = stops[j]
            p1, c1 = stops[j + 1]
            if p0 <= t <= p1:
                k = 0.0 if p1 == p0 else (t - p0) / (p1 - p0)
                lut.append(_lerp(c0, c1, k))
                break
    return np.array(lut, dtype=np.uint8)


def _fill_lut(sp):
    """返回 (方向 deg, LUT) 或 None。"""
    solid = sp.find(".//a:solidFill/a:srgbClr", NS)
    grad = sp.find(".//a:gradFill", NS)
    if grad is not None:
        stops = []
        for gs in grad.findall(".//a:gs", NS):
            pos = int(gs.get("pos", "0")) / 100000.0
            c = gs.find("a:srgbClr", NS)
            if c is not None:
                rgb = _hex2rgb(c.get("val", "FFFFFF"))
            else:
                sc = gs.find("a:schemeClr", NS)
                rgb = (200, 200, 200) if sc is None else _SCHEME.get(sc.get("val"), (200, 200, 200))
            if rgb:
                stops.append((pos, rgb))
        ang = grad.find(".//a:lin", NS)
        deg = float(ang.get("ang", "0")) / 60000.0 if ang is not None else 0.0
        if stops:
            return deg, _grad_lut(stops)
        return None
    if solid is not None:
        rgb = _hex2rgb(solid.get("val", "FFFFFF"))
        if rgb is None:
            sc = sp.find(".//a:solidFill/a:schemeClr", NS)
            rgb = _SCHEME.get(sc.get("val"), (200, 200, 200)) if sc is not None else None
        if rgb:
            return None, np.tile(np.array(rgb, dtype=np.uint8), (256, 1))
    return None


_SCHEME = {"bg1": (255, 255, 255), "tx1": (0, 0, 0), "bg2": (238, 238, 238),
           "tx2": (68, 68, 68), "accent1": (68, 114, 196), "accent2": (237, 125, 49)}


def _paint(canvas, box, deg_lut, shape, radius=0.0):
    x, y, w, h = [int(round(v)) for v in box]
    if w <= 0 or h <= 0:
        return
    deg, lut = deg_lut
    if deg is None:
        col = tuple(int(v) for v in lut[0])
        tile = Image.new("RGB", (w, h), col).convert("RGBA")
    else:
        # 只处理 0/90/180/270，其余按最近轴处理
        vert = 45 <= (deg % 180) <= 135
        if vert:
            t = np.linspace(0, 1, h)[:, None].repeat(w, axis=1)
        else:
            t = np.linspace(0, 1, w)[None, :].repeat(h, axis=0)
        if 90 < (deg % 360) < 270:
            t = 1.0 - t
        arr = lut[(t * 255).astype(np.uint8)]
        tile = Image.fromarray(arr, "RGB").convert("RGBA")
    mask = Image.new("L", (w, h), 255)
    dm = ImageDraw.Draw(mask)
    if shape in ("roundrect", "snip"):
        r = max(2, min(int(radius), w // 2, h // 2))
        dm.rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=255)
    elif shape == "ellipse":
        dm.ellipse([0, 0, w - 1, h - 1], fill=255)
    elif shape.startswith("arrow"):
        dm.rectangle([0, 0, w - 1, h - 1], fill=0)
        dm.polygon(_arrow_poly(shape, w, h), fill=255)
    tile.putalpha(mask)
    canvas.paste(tile, (x, y), tile)


def _arrow_poly(shape, w, h):
    d = shape.split("_")[-1]
    if d in ("right", "left"):
        s = h * 0.42
        head = min(h * 0.55, w * 0.5)
        if d == "right":
            return [(0, h / 2 - s / 2), (w - head, h / 2 - s / 2), (w - head, 0),
                    (w, h / 2), (w - head, h), (w - head, h / 2 + s / 2), (0, h / 2 + s / 2)]
        return [(w, h / 2 - s / 2), (head, h / 2 - s / 2), (head, 0),
                (0, h / 2), (head, h), (head, h / 2 + s / 2), (w, h / 2 + s / 2)]
    s = w * 0.42
    head = min(w * 0.55, h * 0.5)
    if d == "down":
        return [(w / 2 - s / 2, 0), (w / 2 - s / 2, h - head), (0, h - head),
                (w / 2, h), (w, h - head), (w / 2 + s / 2, h - head), (w / 2 + s / 2, 0)]
    return [(w / 2 - s / 2, h), (w / 2 - s / 2, head), (0, head),
            (w / 2, 0), (w, head), (w / 2 + s / 2, head), (w / 2 + s / 2, h)]


def _prst_to_shape(prst, has_text):
    if prst in ("roundRect",):
        return "roundrect"
    if prst in ("ellipse", "oval"):
        return "ellipse"
    if prst == "snip1Rect":
        return "snip"
    if prst == "leftArrow":
        return "arrow_left"
    if prst == "rightArrow":
        return "arrow_right"
    if prst == "upArrow":
        return "arrow_up"
    if prst == "downArrow":
        return "arrow_down"
    return "rect"


def _radius_px(sp, w, h):
    gd = sp.find(".//a:prstGeom/a:avLst/a:gd", NS)
    if gd is None:
        return 0.0
    try:
        val = int(gd.get("fmla", "val 16667").split()[-1]) / 100000.0
    except Exception:
        val = 0.16667
    return val * min(w, h)


def render(pptx_path, size=None, blank="#FFFFFF"):
    with zipfile.ZipFile(pptx_path) as z:
        pres = ET.fromstring(z.read("ppt/presentation.xml"))
        sldSz = pres.find("p:sldSz", NS)
        W = int(round(int(sldSz.get("cx")) / EMU_PER_PX))
        H = int(round(int(sldSz.get("cy")) / EMU_PER_PX))
        if size:
            W, H = size
        canvas = Image.new("RGB", (W, H), blank)
        draw = ImageDraw.Draw(canvas)

        slide = "ppt/slides/slide1.xml"
        if slide not in z.namelist():
            names = sorted(n for n in z.namelist()
                           if n.startswith("ppt/slides/slide") and n.endswith(".xml"))
            if not names:
                return canvas
            slide = names[0]
        rels_name = "ppt/slides/_rels/" + os.path.basename(slide) + ".rels"
        rels = {}
        if rels_name in z.namelist():
            rr = ET.fromstring(z.read(rels_name))
            rels = {e.get("Id"): e.get("Target") for e in rr}
        root = ET.fromstring(z.read(slide))

        # 页面背景（p:cSld/p:bg）。3.4.0 之前完全没渲染 → 深色版式在自校验图里
        # 永远是白底，RMS 把"背景全错"误判成"轻微色差"。
        bgPr = root.find(".//p:cSld/p:bg/p:bgPr", NS)
        if bgPr is not None:
            fl = _fill_lut(bgPr)
            if fl is not None:
                _paint(canvas, (0, 0, W, H), fl, "rect")
                draw = ImageDraw.Draw(canvas)

        spTree = root.find(".//p:cSld/p:spTree", NS)
        for node in list(spTree):
            tag = node.tag.split("}")[-1]
            if tag == "sp":
                _draw_sp(z, canvas, draw, node, rels)
            elif tag == "pic":
                _draw_pic(z, canvas, node, rels)
    return canvas


def _draw_sp(z, canvas, draw, sp, rels):
    xfrm = sp.find(".//p:spPr/a:xfrm", NS)
    if xfrm is None:
        return
    off, ext = xfrm.find("a:off", NS), xfrm.find("a:ext", NS)
    if off is None or ext is None:
        return
    x, y = _emu(off.get("x")), _emu(off.get("y"))
    w, h = _emu(ext.get("cx")), _emu(ext.get("cy"))
    if w <= 0 or h <= 0:
        return
    has_text = sp.find(".//a:t", NS) is not None
    prst_el = sp.find(".//a:prstGeom", NS)
    prst = prst_el.get("prst", "rect") if prst_el is not None else "rect"
    shape = _prst_to_shape(prst, has_text)

    if not has_text:
        fl = _fill_lut(sp)
        if fl is not None:
            if shape == "snip":
                shape = "roundrect"
            _paint(canvas, (x, y, w, h), fl, shape, _radius_px(sp, w, h))
        ln = sp.find(".//a:ln", NS)
        if ln is not None:
            lc = ln.find(".//a:solidFill/a:srgbClr", NS)
            if lc is not None:
                rgb = _hex2rgb(lc.get("val"))
                try:
                    lw = max(1, int(round(int(ln.get("w") or 9525) / EMU_PER_PX)))
                except Exception:
                    lw = 1
                if rgb:
                    r = max(0.0, _radius_px(sp, w, h))
                    # DrawingML 的描边**骑在几何轮廓上**（一半内、一半外），而
                    # Pillow 的 outline 是全部向内画。要让两者重合，就把矩形
                    # 外扩 lw/2 再用同样的线宽画 —— 否则渲染图里的描边会整体
                    # 内缩 1px，自校验会一直报一道不存在的缝。
                    g = lw / 2.0
                    bb = [x - g, y - g, x + w + g, y + h + g]
                    if shape == "roundrect":
                        draw.rounded_rectangle(bb, radius=r + g, outline=rgb, width=lw)
                    elif shape == "ellipse":
                        draw.ellipse(bb, outline=rgb, width=lw)
                    else:
                        draw.rectangle(bb, outline=rgb, width=lw)
        return

    # 文本：按 DrawingML 语义还原 —— 形状框左上角 = 首行行盒左上角，
    # 对齐 / 锚点在**行盒**内部平移。3.4.0 之前把 ink 框直接贴到形状框上
    # （`draw.text((tx - bb[0], ty - bb[1]))`），与 PowerPoint 差一个 ascent，
    # 于是"文字整体下沉半行"在自校验里永远看不出来。
    bodyPr = sp.find(".//a:bodyPr", NS)
    anchor = bodyPr.get("anchor", "t") if bodyPr is not None else "t"
    lines = []
    for para in sp.findall(".//a:p", NS):
        txt = "".join(t.text or "" for t in para.findall(".//a:t", NS))
        if not txt:
            continue
        rPr = para.find(".//a:rPr", NS)
        sz = float(rPr.get("sz", "1800")) / 100.0 if rPr is not None else 18.0
        bold = rPr is not None and rPr.get("b") == "1"
        col = (40, 40, 40)
        cf = para.find(".//a:rPr/a:solidFill/a:srgbClr", NS)
        if cf is not None:
            col = _hex2rgb(cf.get("val")) or col
        fnt = _font(sz / 0.75, bold)
        try:
            line_h = sum(fnt.getmetrics())
        except Exception:
            line_h = sz / 0.75 * 1.2
        try:
            adv = draw.textlength(txt, font=fnt)
        except Exception:
            adv = len(txt) * sz / 0.75
        pPr = para.find("a:pPr", NS)
        lines.append((txt, fnt, col, adv, line_h,
                      pPr.get("algn", "l") if pPr is not None else "l"))
    if not lines:
        return
    total_h = sum(ln[4] for ln in lines)
    if anchor == "ctr":
        cy = y + (h - total_h) / 2.0
    elif anchor == "b":
        cy = y + h - total_h
    else:
        cy = y
    for txt, fnt, col, adv, line_h, algn in lines:
        if algn == "ctr":
            px = x + (w - adv) / 2.0
        elif algn == "r":
            px = x + w - adv
        else:
            px = x
        draw.text((px, cy), txt, font=fnt, fill=col)
        cy += line_h


def _draw_pic(z, canvas, pic, rels):
    xfrm = pic.find(".//p:spPr/a:xfrm", NS)
    if xfrm is None:
        return
    off, ext = xfrm.find("a:off", NS), xfrm.find("a:ext", NS)
    x, y = _emu(off.get("x")), _emu(off.get("y"))
    w, h = _emu(ext.get("cx")), _emu(ext.get("cy"))
    blip = pic.find(".//a:blip", NS)
    if blip is None:
        return
    rid = blip.get("{" + NS["r"] + "}embed")
    tgt = rels.get(rid)
    if not tgt:
        return
    # rels 里的 Target 形如 ../media/image1.png，必须相对 slide 所在目录归一化，
    # 否则 "ppt/slides/../media/x.png" 不在 namelist 中，图片会静默丢失。
    if tgt.startswith("/"):
        cands = [tgt.lstrip("/")]
    else:
        cands = [posixpath.normpath(posixpath.join("ppt/slides", tgt)),
                 posixpath.normpath(posixpath.join("ppt", tgt)),
                 posixpath.normpath(tgt)]
    names = set(z.namelist())
    for c in cands:
        if c in names:
            try:
                im = Image.open(io.BytesIO(z.read(c))).convert("RGBA")
                im = im.resize((max(1, int(w)), max(1, int(h))), Image.LANCZOS)
                canvas.paste(im, (int(x), int(y)), im)
            except Exception:
                pass
            return


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("pptx")
    ap.add_argument("-o", "--out", default="rendered.png")
    ap.add_argument("--size", default=None, help="源图像素尺寸 WxH（默认取 PPT 页面）")
    ap.add_argument("--reference", default=None, help="源图，用于计算 RMS 与产出对比图")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    size = None
    if a.size:
        w, h = a.size.lower().split("x")
        size = (int(w), int(h))
    img = render(a.pptx, size)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
    img.save(a.out)
    res = {"pptx": os.path.abspath(a.pptx), "rendered": os.path.abspath(a.out),
           "size": list(img.size), "status": "pass"}
    if a.reference and os.path.isfile(a.reference):
        ref = Image.open(a.reference).convert("RGB")
        if ref.size != img.size:
            ref = ref.resize(img.size, Image.LANCZOS)
        d = np.abs(np.asarray(ref).astype(np.float64) - np.asarray(img).astype(np.float64))
        res["rms_diff"] = float(np.sqrt((d ** 2).mean()) / 255.0)
        dd = os.path.dirname(os.path.abspath(a.out))
        side = Image.new("RGB", (img.width * 2, img.height), "white")
        side.paste(ref, (0, 0)); side.paste(img, (img.width, 0))
        side.save(os.path.join(dd, "side_by_side.png"))
        diff_img = Image.fromarray(np.clip(d.sum(axis=2) / 2.2, 0, 255).astype(np.uint8))
        ImageEnhance.Contrast(ImageOps.autocontrast(diff_img.convert("L"))).enhance(2).save(
            os.path.join(dd, "difference.png"))
        res["side_by_side"] = os.path.join(dd, "side_by_side.png")
    print(json.dumps(res, ensure_ascii=False, indent=2) if a.json
          else f"rendered → {a.out}  {res.get('rms_diff', '')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
