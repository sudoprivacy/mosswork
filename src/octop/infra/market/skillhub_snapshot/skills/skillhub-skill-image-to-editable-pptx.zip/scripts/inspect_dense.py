#!/usr/bin/env python3
"""Make lossless, enlarged review tiles for dense text and layered dashboards.

The files are inspection evidence only. Never insert them as PPT slide assets.
"""
import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageOps


def make_tiles(source, out_dir, *, tile_width=520, tile_height=340, overlap=60, scale=3):
    if min(tile_width, tile_height, scale) <= 0 or overlap < 0 or overlap >= min(tile_width, tile_height):
        raise ValueError('Require positive tile dimensions/scale and smaller nonnegative overlap')
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as opened:
        image = ImageOps.exif_transpose(opened).convert('RGB')
    width, height = image.size

    def positions(length, tile):
        if length <= tile:
            return [0]
        stride = tile - overlap
        return sorted(set(range(0, length - tile + 1, stride)) | {length - tile})

    xs, ys = positions(width, tile_width), positions(height, tile_height)
    preview = image.copy()
    draw = ImageDraw.Draw(preview)
    entries = []
    for y in ys:
        for x in xs:
            x2, y2 = min(width, x + tile_width), min(height, y + tile_height)
            index = len(entries) + 1
            filename = f'tile-{index:03d}.png'
            patch = image.crop((x, y, x2, y2))
            patch.resize((patch.width * scale, patch.height * scale), Image.Resampling.NEAREST).save(out_dir / filename)
            draw.rectangle((x, y, x2 - 1, y2 - 1), outline='#FF8C00', width=2)
            draw.rectangle((x, y, x + 30, y + 17), fill='#FF8C00')
            draw.text((x + 3, y + 1), str(index), fill='black')
            entries.append({'index': index, 'file': filename, 'box': [x, y, x2 - x, y2 - y]})
    preview.save(out_dir / 'index.png')
    manifest = {'source': str(Path(source).resolve()), 'source_size': [width, height],
                'scale': scale, 'overlap': overlap, 'tiles': entries,
                'warning': 'Use source pixel coordinates; tiles are review aids, not PPT assets.'}
    (out_dir / 'tiles.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return manifest


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source')
    ap.add_argument('-o', '--out-dir', required=True)
    ap.add_argument('--tile-width', type=int, default=520)
    ap.add_argument('--tile-height', type=int, default=340)
    ap.add_argument('--overlap', type=int, default=60)
    ap.add_argument('--scale', type=int, default=3)
    args = ap.parse_args(argv)
    print(json.dumps(make_tiles(args.source, args.out_dir, tile_width=args.tile_width,
                                tile_height=args.tile_height, overlap=args.overlap,
                                scale=args.scale), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
