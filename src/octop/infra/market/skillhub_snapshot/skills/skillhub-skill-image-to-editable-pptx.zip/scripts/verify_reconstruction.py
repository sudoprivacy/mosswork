#!/usr/bin/env python3
"""Run the non-optional final gate for an image-to-editable-PPTX rebuild.

This command first validates the mandatory transparent foreground reference,
then rejects fake raster splitting, validates editable structure, checks slide
overflow, renders the final PPTX through the Presentations skill, and compares
that real render with the background-removed reference.  It exits non-zero
when any stage fails.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]


def run(command, *, env=None):
    return subprocess.run(
        [str(item) for item in command],
        text=True,
        capture_output=True,
        check=False,
        env=env,
    )


def json_from_stdout(result, stage):
    try:
        return json.loads(result.stdout)
    except Exception:
        return {
            "status": "error",
            "stage": stage,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }


def require_presentations_skill(path):
    root = Path(path).resolve()
    required = [
        root / "container_tools" / "render_slides.py",
        root / "container_tools" / "slides_test.py",
    ]
    missing = [str(item) for item in required if not item.is_file()]
    if missing:
        raise ValueError("Presentations skill is missing required tools: " + ", ".join(missing))
    return root


def presentation_overflow_failed(returncode, stdout, stderr):
    output = "\n".join(item for item in (stdout.strip(), stderr.strip()) if item)
    return (
        returncode != 0
        or "ERROR:" in output
        or "overflowing original canvas" in output
    )


def validate_runtime_env():
    required = ("RUNTIME_NODE", "RUNTIME_NODE_MODULES", "RUNTIME_BIN_DIR", "RUNTIME_PYTHON")
    missing = [name for name in required if not os.environ.get(name)]
    if missing:
        raise ValueError("missing required runtime environment: " + ", ".join(missing))


def verify(args):
    validate_runtime_env()
    presentations = require_presentations_skill(args.presentation_skill_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    background_result = run([
        sys.executable,
        ROOT / "scripts" / "audit_transparency.py",
        args.foreground_source,
        "--source",
        args.source,
        "--preview-dir",
        args.output_dir / "background-removal",
        "--require-smooth-edges",
        "--max-opaque-rgb-rms",
        "0",
        "--json",
    ])
    background_removal = json_from_stdout(background_result, "background_removal")

    if args.expected_picture_count > 0:
        asset_command = [
            sys.executable,
            ROOT / "scripts" / "audit_asset_manifest.py",
            args.approved_image_dir,
            "--manifest",
            args.asset_manifest,
            "--source",
            args.foreground_source,
            "--contact-sheet",
            args.output_dir / "assets-contact-sheet.png",
            "--json",
        ]
        if args.allow_photo_assets:
            asset_command.append("--allow-photo")
        asset_result = run(asset_command)
        asset_integrity = json_from_stdout(asset_result, "asset_integrity")
    else:
        asset_integrity = {"status": "pass", "asset_count": 0, "findings": []}

    structure_command = [
        sys.executable,
        ROOT / "scripts" / "validate_structure.py",
        args.pptx,
        "--json",
        "--strict-reconstruction",
        "--min-text-objects",
        args.min_text_objects,
        "--expected-picture-count",
        args.expected_picture_count,
        "--max-picture-area-ratio",
        args.max_picture_area_ratio,
        "--max-total-picture-area-ratio",
        args.max_total_picture_area_ratio,
        "--max-aspect-drift",
        args.max_picture_aspect_drift,
        "--require-aspect-lock",
        "--forbid-groups",
        "--forbid-source-image",
        args.source,
        "--forbid-source-image",
        args.foreground_source,
        "--required-text-file",
        args.required_text_file,
    ]
    if args.expected_picture_count > 0:
        if args.approved_image_dir:
            structure_command.extend([
                "--approved-image-dir",
                args.approved_image_dir,
                "--require-all-approved-images",
            ])
    structure_result = run(structure_command)
    structure = json_from_stdout(structure_result, "structure")

    overflow_result = run([
        sys.executable,
        presentations / "container_tools" / "slides_test.py",
        args.pptx,
    ], env=os.environ.copy())
    overflow_failed = presentation_overflow_failed(
        overflow_result.returncode, overflow_result.stdout, overflow_result.stderr
    )
    overflow = {
        "status": "fail" if overflow_failed else "pass",
        "stdout": overflow_result.stdout.strip(),
        "stderr": overflow_result.stderr.strip(),
    }

    with Image.open(args.foreground_source) as source_image:
        width, height = source_image.size
    render_dir = args.output_dir / "rendered"
    render_result = run([
        sys.executable,
        presentations / "container_tools" / "render_slides.py",
        args.pptx,
        "--output_dir",
        render_dir,
        "--width",
        width,
        "--height",
        height,
    ], env=os.environ.copy())
    renders = sorted(render_dir.glob("slide-*.png")) if render_dir.exists() else []
    render = {
        "status": "pass" if render_result.returncode == 0 and len(renders) == 1 else "fail",
        "slide_count": len(renders),
        "stdout": render_result.stdout.strip(),
        "stderr": render_result.stderr.strip(),
    }

    if render["status"] == "pass":
        compare_result = run([
            sys.executable,
            ROOT / "scripts" / "compare_images.py",
            args.foreground_source,
            renders[0],
            "--output-dir",
            args.output_dir / "visual-diff",
            "--max-rms",
            args.max_rms,
            "--max-aspect-drift",
            args.max_render_aspect_drift,
            "--size-mode",
            "normalize",
            "--json",
        ])
        visual = json_from_stdout(compare_result, "visual")
    else:
        visual = {"status": "error", "message": "render stage did not produce exactly one slide"}

    placement = {"status": "pass", "findings": []}
    if args.expected_picture_count > 0:
        placement_result = run([sys.executable, ROOT / "scripts" / "audit_placement.py",
            args.pptx, "--source", args.source, "--assets", args.approved_image_dir,
            "--manifest", args.asset_manifest])
        placement = json_from_stdout(placement_result, "placement")

    stages = {
        "placement": placement,
        "background_removal": background_removal,
        "asset_integrity": asset_integrity,
        "structure": structure,
        "overflow": overflow,
        "render": render,
        "visual": visual,
    }
    passed = all(item.get("status") == "pass" for item in stages.values())
    return {
        "status": "pass" if passed else "fail",
        "source": str(args.source),
        "foreground_source": str(args.foreground_source),
        "pptx": str(args.pptx),
        "stages": stages,
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("pptx", type=Path)
    parser.add_argument("--foreground-source", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--presentation-skill-dir", default=os.environ.get("PRESENTATIONS_SKILL_DIR"))
    parser.add_argument("--required-text-file", type=Path, required=True)
    parser.add_argument("--approved-image-dir", type=Path)
    parser.add_argument("--asset-manifest", type=Path)
    parser.add_argument("--allow-photo-assets", action="store_true")
    parser.add_argument("--expected-picture-count", type=int, required=True)
    parser.add_argument("--min-text-objects", type=int, required=True)
    parser.add_argument("--max-rms", type=float, default=0.12)
    parser.add_argument("--max-render-aspect-drift", type=float, default=0.005)
    parser.add_argument("--max-picture-aspect-drift", type=float, default=0.001)
    parser.add_argument("--max-picture-area-ratio", type=float, default=0.15)
    parser.add_argument("--max-total-picture-area-ratio", type=float, default=0.30)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if not args.presentation_skill_dir:
        parser.error("--presentation-skill-dir or PRESENTATIONS_SKILL_DIR is required")
    if args.expected_picture_count < 0 or args.min_text_objects < 0:
        parser.error("counts must be non-negative")
    if args.expected_picture_count > 0 and not args.approved_image_dir:
        parser.error("--approved-image-dir is required when pictures are expected")
    if args.expected_picture_count > 0 and not args.asset_manifest:
        parser.error("--asset-manifest is required when pictures are expected")
    return args


def main(argv=None):
    try:
        result = verify(parse_args(argv))
    except Exception as exc:
        result = {"status": "error", "message": str(exc)}
    if "--json" in (argv if argv is not None else sys.argv[1:]):
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"status={result['status']}")
        if result.get("message"):
            print(result["message"])
        for name, stage in result.get("stages", {}).items():
            print(f"- {name}: {stage.get('status')}")
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(main())
