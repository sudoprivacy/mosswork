#!/usr/bin/env python3
"""Audit extracted icon assets for clipping and aspect-ratio integrity.

The audit rejects icons whose visible pixels touch the edge and, when a
manifest is available, checks that transparent-background extraction did not
change the visible aspect ratio.
"""
import argparse
import json
import os
import sys
from PIL import Image


def audit(path, margin, expected_aspect=None, max_aspect_drift=0.001):
    with Image.open(path) as img:
        rgba = img.convert("RGBA")
        alpha = rgba.getchannel("A")
        bbox = alpha.getbbox()
        if not bbox:
            return {"file": path, "ok": False, "reason": "no visible pixels"}
        x0, y0, x1, y1 = bbox
        left, top = x0, y0
        right, bottom = img.width - x1, img.height - y1
        visible_w, visible_h = max(1, x1 - x0), max(1, y1 - y0)
        actual_aspect = visible_w / visible_h
        reasons = []
        if min(left, top, right, bottom) < margin:
            reasons.append(f"edge margin below {margin}px")
        drift = None
        if expected_aspect:
            drift = abs(actual_aspect / float(expected_aspect) - 1.0)
            if drift > max_aspect_drift:
                reasons.append(f"visible aspect drift {drift:.2%} > {max_aspect_drift:.2%}")
        return {
            "file": path,
            "ok": not reasons,
            "bbox": [x0, y0, x1, y1],
            "margins": [left, top, right, bottom],
            "actual_aspect": actual_aspect,
            "aspect_drift": drift,
            "reason": "; ".join(reasons) if reasons else None,
        }


def manifest_items(path):
    if not path or not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, list) else [data]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("assets_dir")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--margin", type=int, default=2)
    ap.add_argument("--max-aspect-drift", type=float, default=0.001)
    ap.add_argument("--require-manifest-coverage", action="store_true",
                    help="fail when any asset lacks an expected visible aspect in the manifest")
    args = ap.parse_args()

    items = manifest_items(args.manifest)
    specs = {}
    for item in items:
        name = item.get("name")
        if not name:
            # Single-asset crop_assets manifest: infer file by scanning when possible.
            continue
        aspect = item.get("visible_aspect_ratio")
        if aspect is None:
            vb = item.get("visible_box") or item.get("visible_box_in_crop")
            if vb and vb.get("h"):
                aspect = vb.get("w", 0) / vb["h"]
        specs[name] = aspect

    files = [os.path.join(args.assets_dir, n) for n in os.listdir(args.assets_dir)
             if n.lower().endswith((".png", ".webp"))]
    results = []
    for p in sorted(files):
        aspect = specs.get(os.path.basename(p))
        if args.require_manifest_coverage and aspect is None:
            results.append({
                "file": p,
                "ok": False,
                "reason": "missing manifest aspect",
            })
        else:
            results.append(audit(p, args.margin, aspect, args.max_aspect_drift))
    bad = [r for r in results if not r["ok"]]
    for r in results:
        extra = r.get("reason") or ("margins=" + str(r["margins"]))
        print(("FAIL" if not r["ok"] else "OK  ") + " " + r["file"] + "  " + extra)
    print(f"audit: {len(results)} assets, {len(bad)} failures")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
