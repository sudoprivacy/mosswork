#!/usr/bin/env python3
"""Batch image reconstruction. A successful export is never a visual-QA pass.

python batch_convert.py a.png b.png -o build
python batch_convert.py images/ --recursive -o build
python batch_convert.py --manifest jobs.json -o build --resume
Exit: 0=all actually verified; 2=exported/prepared, review needed; 1=one or more failed.
"""
import argparse
import contextlib
import copy
import glob
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from types import SimpleNamespace

from _runtime import (
    VERSION, ActionError, core_dependency_issue, diagnostic, office_commands,
    office_dependency_issue, ocr_dependency_issue, read_json,
)
from batch_state import continuation_job, read_input_binding, runtime_signature, sha256, write_continuation

CORE_IMPORT_ERROR = None
try:
    from PIL import Image, ImageOps
    import numpy as np
    from pptx import Presentation
except Exception as exc:
    CORE_IMPORT_ERROR = exc

SCRIPTS = Path(__file__).resolve().parent
EXT = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tif', '.tiff'}


def write_json(path, data):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def natural_key(path):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r'(\d+)', str(path))]


def collect_jobs(inputs, manifest=None, recursive=False):
    jobs = []
    if manifest:
        mp = Path(manifest).resolve()
        try:
            data = read_json(mp)
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            if isinstance(exc, (UnicodeError, json.JSONDecodeError)):
                raise ActionError(f'{mp}: {exc}', 'MANIFEST_JSON', '清单不是有效的 UTF-8 JSON。',
                                  f'运行 python -m json.tool "{mp}" 查看错误行，并将清单保存为 UTF-8。') from exc
            raise ActionError(str(exc), 'MANIFEST_UNREADABLE', '无法读取批量清单。',
                              '确认 --manifest 路径存在、具有读取权限，路径含空格时加引号。') from exc
        items = data.get('jobs') if isinstance(data, dict) else data
        if not isinstance(items, list):
            raise ActionError(f'{mp}: expected a jobs array', 'MANIFEST_FORMAT', '清单缺少 jobs 数组。',
                              '参考 examples/measured-demo/jobs.json，每项填写图片路径或带 source 的对象。')
        for index, item in enumerate(items, 1):
            job = {'source': item} if isinstance(item, str) else dict(item) if isinstance(item, dict) else {}
            try:
                for key in ('source', 'layout', 'crops'):
                    value = job.get(key)
                    if key != 'source' and value in (None, ''):
                        job.pop(key, None)
                        continue
                    if not isinstance(value, str) or not value.strip() or '\x00' in value:
                        raise ValueError(f'{key} must be a non-empty path string')
                    job[key] = str((mp.parent / value).resolve())
            except (ValueError, OSError, RuntimeError) as exc:
                job = {'source': '', 'input_error': f'{mp}: jobs[{index - 1}]: {exc}',
                       '_invalid_manifest_item': item}
            jobs.append(job)
    for arg in inputs:
        p = Path(arg)
        if p.is_dir():
            paths = sorted((x for x in (p.rglob('*') if recursive else p.iterdir())
                            if x.is_file() and x.suffix.lower() in EXT), key=natural_key)
        elif glob.has_magic(arg):
            paths = sorted((Path(x) for x in glob.glob(arg, recursive=recursive)
                            if Path(x).is_file() and Path(x).suffix.lower() in EXT), key=natural_key)
        else:
            paths = [p]
        if not paths:
            jobs.append({'source': str(p.absolute()), 'input_error': 'No matching images'})
        jobs.extend({'source': str(x.resolve())} for x in paths)
    if not jobs:
        raise ActionError('No images supplied', 'NO_INPUTS', '没有可处理的图片。',
                          '传入图片、目录或包含 jobs 的 JSON 清单。运行 --help 查看示例。')
    # Explicit lists preserve repeats/order. Output index guarantees unique basenames.
    return jobs


def load_layout(path):
    try:
        layout = read_json(path)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ActionError(f'{path}: {exc}', 'LAYOUT_UNREADABLE', '无法读取布局文件。',
                          '核对清单中的 layout 路径和文件权限。检查 JSON 语法并保存为 UTF-8。') from exc
    if not isinstance(layout, dict):
        raise ValueError(f'{path}: layout must be a JSON object')
    for key in ('texts', 'shapes', 'images', 'icons', 'regions'):
        items = layout.get(key, [])
        if not isinstance(items, list) or not all(isinstance(item, dict) for item in items):
            raise ValueError(f'{path}: layout.{key} must be an array of objects')
    if not isinstance(layout.get('background', {}), dict):
        raise ValueError(f'{path}: layout.background must be an object')
    return layout


def image_profile(path):
    with Image.open(path) as im:
        im = ImageOps.exif_transpose(im).convert('RGB')
        im.thumbnail((640, 640))
        arr = np.asarray(im).astype(np.int16)
    edges = np.zeros(arr.shape[:2], dtype=bool)
    edges[:, 1:] |= np.max(np.abs(arr[:, 1:] - arr[:, :-1]), axis=2) > 24
    edges[1:] |= np.max(np.abs(arr[1:] - arr[:-1]), axis=2) > 24
    q = (arr // 32).reshape(-1, 3)
    _, counts = np.unique(q, axis=0, return_counts=True)
    top = sum(sorted(counts, reverse=True)[:4]) / len(q)
    edge = float(edges.mean())
    return {'edge_density': round(edge, 4), 'top_four_color_fraction': round(float(top), 4),
            'complex': bool(top < .48 or (top < .72 and edge > .22)),
            'note': 'Heuristic routing only; visual inspection is still required'}


def fingerprint(job, args):
    digest = hashlib.sha256()
    digest.update(json.dumps({'version': VERSION, 'job': job, 'font': args.font_name,
                             'mode': args.mode, 'max_rms': args.max_rms,
                             'renderer': args.renderer, 'reference_bg': args.reference_bg,
                             'prepare_only': args.prepare_only, 'ocr': args.ocr,
                             'runtime': runtime_signature(args.font_name)}, sort_keys=True).encode())
    paths = [Path(job['source'])]
    if job.get('layout'):
        lp = Path(job['layout'])
        paths.append(lp)
        if lp.exists():
            data = load_layout(lp)
            for el in data.get('images', []) + data.get('icons', []) + [data.get('background', {})]:
                filename=el.get('file')
                if not filename and el in data.get('icons', []):
                    filename=str(el.get('name',''))+'.png'
                if filename:
                    p = Path(filename)
                    if not p.is_absolute():
                        candidates = [Path(job.get('crops', lp.parent)) / p, lp.parent / p]
                        p = next((x for x in candidates if x.is_file()), candidates[0])
                    paths.append(p)
    # Script content prevents reuse after a code change without a version bump.
    paths += sorted(SCRIPTS.glob('*.py'))
    for path in paths:
        digest.update(str(path).encode())
        if path.is_file():
            digest.update(path.read_bytes())
        else:
            digest.update(b'MISSING')
    return digest.hexdigest()


def normalize_source(path, out, background='FFFFFF'):
    try:
        with Image.open(path) as im:
            if getattr(im, 'n_frames', 1) != 1:
                raise ActionError('Multi-frame image: split frames into separate input files first',
                                  'SOURCE_MULTIFRAME', '一份输入包含多帧。',
                                  '将每帧分别另存为 PNG，再按页序传入。')
            im = ImageOps.exif_transpose(im).convert('RGBA')
    except (OSError, Image.DecompressionBombError) as exc:
        raise ActionError(str(exc), 'SOURCE_UNREADABLE', '无法完整解码源图。',
                          '重新下载原附件并确认能完整打开。若超出解码尺寸上限，先等比缩小再重新测量。') from exc
    rgb = Image.new('RGBA', im.size, '#'+background.lstrip('#'))
    rgb.alpha_composite(im)
    buffer = io.BytesIO()
    rgb.convert('RGB').save(buffer, format='PNG')
    target = Path(out)
    temp = target.with_suffix('.normalizing.tmp')
    temp.write_bytes(buffer.getvalue())
    with Image.open(temp) as check:
        check.load()
    temp.replace(target)


def validate_layout(layout, source):
    with Image.open(source) as im:
        size = list(im.size)
    if layout.get('source_size') != size:
        raise ActionError('layout.source_size must equal normalized source dimensions',
                          'LAYOUT_SIZE', f'布局尺寸与归一化源图 {size[0]} × {size[1]} 不一致。',
                          '以页面目录的 source.png 为准重新测量 source_size 和各对象坐标。')
    names = set()
    for key in ('texts', 'shapes', 'icons', 'images'):
        for i, el in enumerate(layout.get(key, [])):
            box = el.get('box', [])
            label = el.get('name') or f'{key}[{i}]'
            if (not isinstance(box, (list, tuple)) or len(box) != 4
                    or any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in box)):
                raise ActionError(f'Invalid {key}[{i}].box', 'LAYOUT_COORDINATES',
                                  f'对象 {label} 的 box 坐标无效。',
                                  '按源图像素填写四个数字 [x, y, w, h]。')
            x, y, w, h = box
            if el.get('type') == 'line':
                points = [(x, y), el.get('end', [x+w, y+h])]
                outside = any(px < 0 or py < 0 or px > size[0] or py > size[1] for px, py in points)
            else:
                outside = w <= 0 or h <= 0 or x < 0 or y < 0 or x+w > size[0]+.01 or y+h > size[1]+.01
            if outside:
                raise ActionError(f'Out of bounds {key}[{i}]: {box}', 'LAYOUT_COORDINATES',
                                  f'对象 {label} 的坐标超出 {size[0]} × {size[1]} 的源图范围。',
                                  '核对 box 的宽高和位置。连线需同时检查 end 端点。')
            name = el.get('name')
            if name and name in names:
                raise ValueError(f'Duplicate object name: {name}')
            if name:
                names.add(name)
    if not any(layout.get(key) for key in ('texts', 'shapes', 'icons', 'images')):
        raise ValueError('Layout has no reconstructed objects')


def bind_assets(layout, original_layout, crops):
    base = Path(original_layout).parent
    for el in layout.get('images', []) + layout.get('icons', []) + [layout.get('background', {})]:
        name = el.get('file')
        if not name and el in layout.get('icons', []):
            name = str(el.get('name', '')) + '.png'
        if not name:
            continue
        p = Path(name)
        if not p.is_absolute():
            options = [Path(crops) / p, base / p]
            p = next((p for p in options if p.is_file()), options[0])
        if not p.is_file():
            raise ActionError(f'Missing asset: {p}', 'ASSET_MISSING', f'缺少独立素材 {p}。',
                              '补齐对应图片，或修正 layout 的 file 和清单的 crops 路径后续跑。')
        el['file'] = str(p.resolve())


def check_clean_background(layout, source):
    """Reject a nominally clean background that still has source text pixels."""
    bg = layout.get('background', {})
    if bg.get('kind') != 'image' or not layout.get('texts'):
        return
    with Image.open(source) as source_image, Image.open(bg['file']) as background_image:
        src = np.asarray(source_image.convert('RGB')).astype(np.int16)
        clean = np.asarray(background_image.convert('RGB')).astype(np.int16)
    if src.shape != clean.shape:
        raise ValueError('Clean background size must match source')
    unchanged = []
    for i, element in enumerate(layout['texts']):
        x, y, w, h = [int(round(v)) for v in element['box']]
        if w <= 0 or h <= 0:
            continue
        diff = np.max(np.abs(src[y:y+h, x:x+w] - clean[y:y+h, x:x+w]), axis=2)
        if diff.size and float(np.mean(diff > 16)) < .005:
            unchanged.append(element.get('name') or f'texts[{i}]')
    if unchanged:
        raise ValueError('Clean background retains source text in: ' + ', '.join(unchanged[:10]))


def structure_check(pptx, layout):
    prs = Presentation(pptx)
    slide = prs.slides[0]
    actual = [s.text for s in slide.shapes if s.has_text_frame and s.text.strip()]
    expected = [str(t.get('text', '')).strip() for t in layout.get('texts', []) if str(t.get('text', '')).strip()]
    remaining = list(actual)
    missing = []
    for value in expected:
        if value in remaining:
            remaining.remove(value)
        else:
            missing.append(value)
    outside = [s.name for s in slide.shapes if s.left < 0 or s.top < 0 or
               s.left+s.width > prs.slide_width+2 or s.top+s.height > prs.slide_height+2]
    pictures = sum(s.shape_type == 13 for s in slide.shapes)
    expected_pictures = len(layout.get('images', [])) + len(layout.get('icons', [])) + int(layout.get('background', {}).get('kind') == 'image')
    expected_shapes = len(layout.get('shapes', [])) + int(layout.get('background', {}).get('kind', 'solid') != 'image')
    actual_shapes = len(slide.shapes) - len(actual) - pictures
    expected_names = [str(el['name']) for key in ('texts', 'shapes', 'images', 'icons')
                      for el in layout.get(key, []) if el.get('name')]
    actual_names = [s.name for s in slide.shapes]
    missing_names = [name for name in expected_names if name not in actual_names]
    counts_match = (pictures == expected_pictures and actual_shapes == expected_shapes and
                    len(actual) == len(expected))
    from source_geometry import audit_geometry
    geometry = audit_geometry(slide, layout, prs.slide_width, prs.slide_height)
    from visual_inventory import audit_visual_inventory
    visual_inventory = audit_visual_inventory(layout, slide)
    return {'status': 'pass' if not missing and not outside and not missing_names and counts_match and geometry['status'] == 'pass' and visual_inventory['status'] == 'pass' else 'fail',
            'visual_inventory': visual_inventory,
            'geometry': geometry,
            'missing_text': missing, 'outside': outside, 'editable_text_objects': len(actual),
            'missing_names': missing_names, 'picture_objects': pictures,
            'expected_picture_objects': expected_pictures, 'native_shape_objects': actual_shapes,
            'expected_native_shape_objects': expected_shapes, 'total_objects': len(slide.shapes)}


def render_actual(pptx, outdir, all_pages=False):
    office, pdftoppm = office_commands()
    if not office or not pdftoppm:
        return None, 'LibreOffice/soffice and pdftoppm are required for actual rendering'
    folder = Path(outdir) / 'office'
    pdf = folder / (Path(pptx).stem + '.pdf')
    try:
        folder.mkdir(exist_ok=True)
        pdf.unlink(missing_ok=True)
        for stale in folder.glob('page*.png'):
            stale.unlink()
        # Unique profile prevents joining another Office process.
        with tempfile.TemporaryDirectory(prefix='pptx-office-') as profile:
            run = subprocess.run([office, '-env:UserInstallation='+Path(profile).as_uri(), '--headless',
                                  '--convert-to', 'pdf', '--outdir', str(folder), str(pptx)],
                                 capture_output=True, text=True, errors='replace', timeout=120)
        if run.returncode or not pdf.is_file():
            detail = (run.stderr or run.stdout).strip()[-1000:]
            return None, f'Actual Office render failed: {detail or "no PDF produced"}'
        command = [pdftoppm, '-scale-to', '1800']
        if not all_pages:
            command.append('-singlefile')
        command += ['-png', str(pdf), str(folder / 'page')]
        run = subprocess.run(command, capture_output=True, text=True, errors='replace', timeout=120)
        if run.returncode:
            return None, f'pdftoppm failed (exit {run.returncode}): {run.stderr.strip()[-1000:]}'
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, f'Actual render failed: {exc}'
    images = sorted(folder.glob('page-*.png'), key=natural_key) if all_pages else folder/'page.png'
    if (all_pages and not images) or (not all_pages and not images.is_file()):
        return None, 'pdftoppm did not produce page images'
    return images, None


def render_diagnostic(renderer):
    if renderer == 'offscreen':
        return diagnostic('RENDER_OFFSCREEN', '本次仅生成几何预览。',
                          '移除 --renderer offscreen 或使用 qa_external_render.py 做真实渲染复核。')
    if not all(office_commands()):
        return office_dependency_issue()
    return diagnostic('RENDER_FAILED', '真实渲染未完成，已保留导出的 PPTX。',
                      '运行 python scripts/preflight.py --require-render 检查工具，修复后用 --resume 重试。'
                      '也可用 PowerPoint/WPS 导出页面图片，再运行 qa_external_render.py。')


def inspection_regions(layout, size, pad=4):
    """Measure every information-bearing object, even when regions were omitted."""
    width, height = size
    regions = list(layout.get('regions', []))
    for key in ('texts', 'shapes', 'icons', 'images'):
        for index, el in enumerate(layout.get(key, [])):
            if key == 'shapes' and el.get('type') == 'line':
                x, y, w, h = el['box']
                ex, ey = el.get('end', [x+w, y+h])
                box = [min(x, ex), min(y, ey), abs(ex-x), abs(ey-y)]
            else:
                box = el['box']
                if key in ('images', 'icons') and el.get('source_box') is not None and el.get('placement', 'source') == 'source':
                    from source_geometry import box_values
                    box = box_values(el['source_box'])
            x, y, w, h = box
            left = max(0, int(math.floor(x-pad)))
            top = max(0, int(math.floor(y-pad)))
            right = min(width, int(math.ceil(x+w+pad)))
            bottom = min(height, int(math.ceil(y+h+pad)))
            if right > left and bottom > top:
                regions.append({'name':el.get('name') or f'{key}[{index}]',
                                'kind':key, 'box':[left, top, right-left, bottom-top]})
    return regions


def compare_render(source, rendered, out, layout):
    from fidelity_gate import measure_patch, alert_tiles
    src = Image.open(source).convert('RGB')
    got = Image.open(rendered).convert('RGB')
    if abs((got.width/got.height)/(src.width/src.height)-1) > .005:
        raise ValueError('Rendered page aspect ratio differs from source')
    got = got.resize(src.size, Image.Resampling.LANCZOS)
    a, b = np.asarray(src, dtype=float), np.asarray(got, dtype=float)
    diff = a-b
    src_pixels, dst_pixels = np.asarray(src), np.asarray(got)
    rms = float(np.sqrt(np.mean(diff**2))/255)
    regions = []
    for r in inspection_regions(layout, src.size):
        x,y,w,h = map(round, r['box'])
        chunk = diff[y:y+h,x:x+w]
        if chunk.size:
            regions.append({'name':r.get('name', r.get('type', 'region')),
                            'kind':r.get('kind', 'region'), 'box':[x,y,w,h],
                            'rms':float(np.sqrt(np.mean(chunk**2))/255),
                            **measure_patch(src_pixels[y:y+h,x:x+w],
                                            dst_pixels[y:y+h,x:x+w])})
    side = Image.new('RGB', (src.width*2, src.height))
    side.paste(src);side.paste(got,(src.width,0));side.save(Path(out)/'side_by_side.png')
    Image.fromarray(np.uint8(np.clip(np.abs(diff)*3,0,255))).save(Path(out)/'difference.png')
    return {'rms':rms,'regions':regions,
            'tile_alerts':alert_tiles(src_pixels, dst_pixels)}


def process_job(job, page_dir, args):
    if job.get('layout') and job.get('layout_source_sha256'):
        if (job['layout_source_sha256'] != sha256(job['source']) or
            job.get('layout_reference_bg', args.reference_bg) != args.reference_bg):
            raise ActionError('Stale layout: source pixels or reference background changed',
                              'LAYOUT_STALE', '源图或透明合成底色已变化，旧布局需要复测。',
                              '用新源图重测此页并提交更新后的布局与素材。')
    source = page_dir/'source.png'
    normalize_source(job['source'], source, args.reference_bg)
    profile = image_profile(source)
    mode = job.get('mode', args.mode)
    if mode == 'auto':
        mode = 'layered' if profile['complex'] else 'editable'
    issues = []
    previous_input = page_dir/'input.json'
    measured_layout = page_dir/'layout.json'
    source_hash = sha256(job['source'])
    if measured_layout.exists() and not job.get('layout'):
        old = read_input_binding(previous_input)
        if not old or old['source_sha256'] != source_hash or old.get('reference_bg') != args.reference_bg:
            archived = page_dir/('layout.previous-'+sha256(measured_layout)[:12]+'.json')
            measured_layout.replace(archived)
    write_json(previous_input, {'source_sha256': source_hash, 'reference_bg': args.reference_bg})
    if job.get('layout'):
        layout = load_layout(job['layout'])
        crops = job.get('crops', str(Path(job['layout']).parent))
        bind_assets(layout, job['layout'], crops)
    elif mode == 'layered' or args.prepare_only or args.ocr == 'none':
        # Preserve evidence for the agent to perform semantic decomposition. Never turn
        # a textured industrial background into thousands of unrelated rectangles.
        from tiled_ocr import recognize
        from inspect_dense import make_tiles
        try:
            texts = recognize(str(source)) if args.ocr != 'none' else []
        except Exception as exc:
            texts = []
            issues.append('OCR unavailable: '+str(exc))
        with Image.open(source) as im:
            size = list(im.size)
        layout = {'source_size':size, 'background':{'kind':'solid','fill':'#FFFFFF'},
                  'texts':texts,'shapes':[],'images':[], 'regions':[],
                  'review':{'inventory_complete':False,'text_verified':False},
                  'source_profile':profile}
        write_json(page_dir/'layout.draft.json', layout)
        tiles = make_tiles(source, page_dir/'review-tiles')
        pending = {'status':'needs_layout','mode':mode,'profile':profile,
                'issues':issues+['Inspect source, inventory all regions and provide measured layered layout'],
                'layout':str(page_dir/'layout.draft.json'),
                'review_tiles':str(page_dir/'review-tiles/tiles.json'),
                'review_tile_count':len(tiles['tiles']),
                'source_normalized':str(source),
                'next_action':'Create this page\'s measured layout.json and assets; rerun the same inputs with --resume'}
        if issues:
            pending['ocr_diagnostic'] = ocr_dependency_issue()
        return pending
    else:
        from describe_image import describe
        from orchestrate import stage_crop
        try:
            layout = describe(str(source), bg_blank_alpha=0)
        except Exception as exc:
            from _ui import SkillError
            if not isinstance(exc, (ImportError, SkillError)):
                raise
            pending_args = copy.copy(args)
            pending_args.ocr = 'none'
            pending = process_job(job, page_dir, pending_args)
            pending['issues'].insert(0, 'Automatic extraction unavailable: ' + str(exc))
            pending['ocr_diagnostic'] = ocr_dependency_issue()
            return pending
        crops, meta = stage_crop(str(source), layout, str(page_dir))
        if len(meta) != len(layout.get('icons', [])):
            raise ValueError('One or more crops failed; refusing incomplete build')
        bind_assets(layout, page_dir/'layout.json', crops)
        issues.append('Automatic OCR/shape detection requires visual and text review')
    validate_layout(layout, source)
    check_clean_background(layout, source)
    if 'visual_inventory' in layout:
        from visual_inventory import audit_visual_inventory, audit_backdrop_removal
        semantic = audit_visual_inventory(layout)
        if semantic['status'] != 'pass':
            raise ValueError('; '.join(semantic['issues']))
        audit_backdrop_removal(layout, source, Path(crops))
    lp = page_dir/'layout.json'
    write_json(lp, layout)
    build_args = SimpleNamespace(source=str(source), layout=str(lp), crops=str(page_dir/'crops'),
                                out=str(page_dir/'editable.pptx'), font_name=args.font_name,
                                strict_assets=True, bg_blank_alpha=0, no_bg_blank=True,
                                ink_fit=True, text_pad=2, wrap=False)
    from build_pptx_from_layout import build
    build(build_args)
    structure = structure_check(build_args.out, layout)
    if structure['status'] != 'pass':
        issues.append('Structure requires correction')
    actual, render_error = (None, 'Actual rendering disabled') if args.renderer == 'offscreen' else render_actual(build_args.out, page_dir)
    if actual:
        renderer = 'libreoffice'
        rendered = actual
    else:
        from render_offscreen import render
        rendered = page_dir/'geometry-preview.png'
        render(build_args.out, tuple(layout['source_size'])).save(rendered)
        renderer = 'geometry-only'
        issues.append(render_error)
    comparison = compare_render(source, rendered, page_dir, layout)
    review = layout.get('review', {})
    unresolved_ocr = [t.get('name', t.get('text', '')[:20]) for t in layout.get('texts', [])
                      if t.get('needs_review') is True]
    complete = (review.get('inventory_complete') is True and review.get('text_verified') is True
                and not unresolved_ocr)
    if not complete:
        issues.append('Text transcription and complete inventory have not been verified')
    if unresolved_ocr:
        issues.append('Unresolved OCR alternatives or low confidence: '+', '.join(unresolved_ocr[:10]))
    from fidelity_gate import assess
    fidelity_issues = assess(comparison, args.max_rms)
    if fidelity_issues:
        issues += fidelity_issues[:25]
    visual_pass = bool(actual) and not fidelity_issues
    status = 'verified' if complete and visual_pass and structure['status']=='pass' else 'needs_review'
    result = {'status':status,'mode':mode,'profile':profile,'issues':issues,
            'layout':str(lp),'pptx':build_args.out,'source_normalized':str(source),
            'renderer':renderer,'visual_pass':visual_pass,'comparison':comparison,'structure':structure}
    if not actual:
        result['render_diagnostic'] = render_diagnostic(args.renderer)
    return result


def verify_combined(pptx, built, out, args):
    if args.renderer == 'offscreen':
        return {'status': 'not_run', 'reason': 'Actual rendering disabled',
                'diagnostic': render_diagnostic(args.renderer)}
    qa = out / 'combined-review'
    qa.mkdir(exist_ok=True)
    pages, error = render_actual(pptx, qa, all_pages=True)
    if pages is None:
        return {'status':'not_run','reason':error,'diagnostic':render_diagnostic(args.renderer)}
    if len(pages) != len(built):
        return {'status':'fail','reason':'Rendered page count differs from exported input count'}
    prs = Presentation(pptx)
    cw,ch = round(prs.slide_width/9525),round(prs.slide_height/9525)
    results = []
    for n,(page,result) in enumerate(zip(pages,built),1):
        layout=read_json(result['layout'])
        src=Image.open(result['source_normalized']).convert('RGB')
        factor=min(cw/src.width,ch/src.height)
        dw,dh=round(src.width*factor),round(src.height*factor)
        dx,dy=(cw-dw)//2,(ch-dh)//2
        reference=Image.new('RGB',(cw,ch),(24,24,24))
        reference.paste(src.resize((dw,dh),Image.Resampling.LANCZOS),(dx,dy))
        pd=qa/f'page-{n:04d}';pd.mkdir(exist_ok=True)
        ref=pd/'reference.png';reference.save(ref)
        transformed={}
        for key in ('regions','texts','shapes','images','icons'):
            transformed[key]=[]
            for element in layout.get(key, []):
                x,y,w,h=element['box']
                transformed[key].append({**element,'box':[dx+x*factor,dy+y*factor,w*factor,h*factor]})
                if element.get('source_box') is not None:
                    from source_geometry import box_values
                    bx,by,bw,bh = box_values(element['source_box'])
                    transformed[key][-1]['source_box'] = [dx+bx*factor,dy+by*factor,bw*factor,bh*factor]
                if element.get('type') == 'line' and element.get('end'):
                    ex,ey=element['end']
                    transformed[key][-1]['end']=[dx+ex*factor,dy+ey*factor]
        comparison=compare_render(ref,page,pd,transformed)
        from fidelity_gate import assess
        fidelity_issues = assess(comparison, args.max_rms)
        from source_geometry import audit_geometry
        geometry = audit_geometry(prs.slides[n-1], layout, prs.slide_width, prs.slide_height)
        if geometry['status'] != 'pass':
            fidelity_issues.append('Merged object coordinates differ from measured source positions')
        passed = not fidelity_issues
        results.append({'slide':n,'input_index':result['index'],'status':'pass' if passed else 'fail',
                        'comparison':comparison,'geometry':geometry,'issues':fidelity_issues[:25], 'rendered':str(page)})
    return {'status':'pass' if all(r['status']=='pass' for r in results) else 'fail',
            'renderer':'libreoffice','pages':results}


def failure_details(exc, job=None):
    if isinstance(exc, ActionError):
        issue = exc.diagnostic
    elif isinstance(exc, PermissionError):
        issue = diagnostic('ACCESS_DENIED', '无法读写文件。',
                           '确认输入可读、输出目录可写，并关闭正在占用输出文件的程序后重试。')
    elif job and job.get('layout'):
        issue = diagnostic('LAYOUT_OR_BUILD', '布局检查或构建失败。',
                           '按 error 中的对象名、坐标或文件名修改原布局，检查修复清单后用 --resume 续跑。')
    else:
        issue = diagnostic('EXECUTION_FAILED', '转换未完成。',
                           '查看 error 和对应页的 conversion.log，核对源图、输出权限及 preflight 结果。')
    return {'error': str(exc), 'error_type': type(exc).__name__, 'diagnostic': issue}


def run_batch(args):
    jobs = collect_jobs(args.sources, args.manifest, args.recursive)
    # A contact sheet or a low-resolution classification is not enough evidence
    # to export several independent layouts. Explicitly supplied layouts still run.
    args.prepare_only = getattr(args, 'prepare_only', False) or args.mode == 'auto'
    args.ocr = getattr(args, 'ocr', 'auto')
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    results = []
    for index, job in enumerate(jobs, 1):
        source_path = Path(job['source']) if job['source'] else None
        slug = (re.sub(r'[^\w.-]+', '_', source_path.stem)[:60] if source_path else '') or 'image'
        page_dir = out/'pages'/f'{index:04d}_{slug}'
        page_dir.mkdir(parents=True, exist_ok=True)
        fp = None
        try:
            if job.get('input_error'):
                if '_invalid_manifest_item' in job:
                    raise ActionError(job['input_error'], 'MANIFEST_ROW', '这条清单记录的路径字段无效。',
                                      '在原清单的对应行填写图片路径，或包含 source 字符串的对象，然后用原命令加 --resume。')
                raise ActionError(job['input_error'], 'NO_MATCHING_IMAGES', '目录或通配符没有匹配到图片。',
                                  '核对目录和扩展名。子目录需要 --recursive。修复后重新运行原命令。')
            if not source_path.is_file():
                raise ActionError(f'Source image not found: {source_path}', 'SOURCE_MISSING',
                                  f'找不到源图 {source_path}。',
                                  '重新下载附件或修正清单中的 source。相对路径从清单目录计算。')
            meta_path = page_dir/'input.json'
            binding = read_input_binding(meta_path)
            compatible_bg = bool(binding and binding.get('reference_bg') == args.reference_bg)
            job = continuation_job(job, page_dir, args.resume and compatible_bg)
            fp = fingerprint(job, args)
            report_path = page_dir/'report.json'
            try:
                cached = read_json(report_path) if args.resume and report_path.exists() else {}
            except (ValueError, OSError):
                cached = {}
            if not isinstance(cached, dict) or cached.get('render_diagnostic', {}).get('code') == 'RENDER_FAILED':
                cached = {}
            artifact_valid = bool(cached.get('artifact_hashes')) and all(
                Path(p).is_file() and sha256(p)==h for p,h in cached.get('artifact_hashes',{}).items())
            prepared_valid = cached.get('status') == 'needs_layout' and artifact_valid
            exported_valid = (cached.get('pptx') and Path(cached['pptx']).is_file() and
                cached.get('output_sha256') == sha256(cached['pptx']) and artifact_valid)
            if cached.get('fingerprint') == fp and (prepared_valid or exported_valid):
                result = cached
                result['cached'] = True
            else:
                with (page_dir/'conversion.log').open('w', encoding='utf-8') as log, contextlib.redirect_stdout(log):
                    result = process_job(job, page_dir, args)
                if result.get('status') == 'needs_layout':
                    prepared_files = [Path(result['layout']), page_dir/'source.png',
                                      Path(result['review_tiles'])]
                    prepared_files += sorted((page_dir/'review-tiles').glob('*.png'))
                    result['artifact_hashes'] = {str(p):sha256(p) for p in prepared_files}
                if result.get('pptx'):
                    result['output_sha256'] = hashlib.sha256(Path(result['pptx']).read_bytes()).hexdigest()
                    lp = Path(result['layout'])
                    ld = read_json(lp)
                    artifacts = [Path(result[k]) for k in ('pptx','layout','source_normalized')]
                    artifacts += [Path(el['file']) for el in ld.get('images',[])+ld.get('icons',[])+[ld.get('background',{})] if el.get('file')]
                    result['artifact_hashes'] = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts}
            result.update(index=index, source=job['source'], fingerprint=fp)
        except Exception as exc:
            result = {'index':index,'source':job['source'],'status':'failed',
                      **failure_details(exc, job),'fingerprint':fp}
        result['page_dir'] = str(page_dir)
        write_json(page_dir/'report.json', result)
        results.append(result)
        write_json(out/'batch-report.json', {'version':VERSION,'status':'running','results':results})
        name = source_path.name if source_path else '清单记录'
        print(f'[{index}/{len(jobs)}] {name}: {result["status"]}', file=sys.stderr)
        issue = result.get('diagnostic') or result.get('render_diagnostic') or result.get('ocr_diagnostic')
        if issue:
            print(f'  [{issue["code"]}] {issue["message"]} {issue["next_action"]}', file=sys.stderr)
    built = [r for r in results if r.get('pptx') and r['status'] != 'failed']
    write_continuation(out, jobs, results, write_json)
    combined = None
    merge_error = None
    complete_export = len(built) == len(jobs)
    allow_partial = getattr(args, 'allow_partial_merge', False)
    if built and not args.separate_only and (complete_export or allow_partial):
        try:
            prs = Presentation()
            if args.canvas:
                w,h = [int(x) for x in args.canvas.lower().split('x')]
            else:
                w,h = read_json(built[0]['layout'])['source_size']
            if min(w,h) < 1:
                raise ValueError('Canvas must be positive')
            prs.slide_width, prs.slide_height = w*9525, h*9525
            from build_pptx_from_layout import build
            with (out/'merge.log').open('w', encoding='utf-8') as log, contextlib.redirect_stdout(log):
                for page, result in enumerate(built, 1):
                    a = SimpleNamespace(source=result['source_normalized'], layout=result['layout'],
                        crops=str(Path(result['layout']).parent/'crops'), font_name=args.font_name,
                        strict_assets=True, no_bg_blank=True, bg_blank_alpha=0, ink_fit=True, text_pad=2)
                    build(a, presentation=prs, save=False)
                    prs.slides[-1].notes_slide.notes_text_frame.text = (
                        f'Input {result["index"]}: {Path(result["source"]).name}\n'
                        f'Status: {result["status"]}; renderer: {result["renderer"]}\n'
                        'Raster photos/backgrounds are not editable vectors.')
                    result['combined_slide'] = page
            combined = out/'combined.pptx'
            temp = out/'combined.tmp.pptx'
            prs.save(temp);temp.replace(combined)
        except Exception as exc:
            merge_error = str(exc)
            combined = None
            for result in built:
                result.pop('combined_slide',None)
    if combined is None and (out/'combined.pptx').is_file():
        (out/'combined.pptx').unlink()
    failed = any(r['status']=='failed' for r in results) or bool(merge_error)
    verified = all(r['status']=='verified' for r in results)
    merged_qa = {'status':'not_applicable'}
    if combined:
        try:
            merged_qa=verify_combined(combined,built,out,args)
        except Exception as exc:
            merged_qa={'status':'fail','reason':str(exc)}
    pending_layout = sum(r['status'] == 'needs_layout' for r in results)
    summary = {'version':VERSION,'status':'partial_failure' if failed else
               ('needs_layout' if pending_layout else ('verified' if verified else 'needs_review')),
               'input_count':len(jobs),'exported_count':len(built),
               'pending_count':pending_layout,
               'complete_export':complete_export,
               'pending_indices':[r['index'] for r in results if r['status'] != 'verified'],
               'work_queue':str(out/'work-queue.json'), 'continuation_manifest':str(out/'continue.json'),
               'merge_blocked_reason':('Incomplete batch; resolve pending pages before merging'
                   if built and not complete_export and not allow_partial and not args.separate_only else None),
               'combined':str(combined) if combined else None, 'merge_error':merge_error,
               'merged_visual_qa':merged_qa, 'results':results}
    # Merged files are not claimed visually verified on the basis of individual pages.
    if combined and merged_qa['status'] != 'pass' and summary['status']=='verified':
        summary['status']='needs_review'
    if merge_error:
        summary['merge_diagnostic'] = diagnostic(
            'MERGE_FAILED', '合并未完成，已保留单页 PPTX。',
            '查看 merge_error 和 merge.log，核对合并画布及输出文件权限后用 --resume 重试。')
        print(f'[MERGE_FAILED] {summary["merge_diagnostic"]["next_action"]}', file=sys.stderr)
    write_json(out/'batch-report.json', summary)
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 1 if failed else (0 if summary['status']=='verified' else 2)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--version', action='version', version=VERSION)
    ap.add_argument('sources', nargs='*')
    ap.add_argument('--manifest', help='JSON ordered jobs; paths relative to manifest')
    ap.add_argument('-o','--out-dir', default='build')
    ap.add_argument('--recursive', action='store_true')
    ap.add_argument('--resume', action='store_true')
    ap.add_argument('--prepare-only', action='store_true',
                    help='Prepare each unmeasured page for reconstruction; automatic for every image in auto mode')
    ap.add_argument('--ocr', choices=['auto', 'none'], default='auto',
                    help='Use none for agent transcription without the optional OCR dependency')
    ap.add_argument('--separate-only', action='store_true')
    ap.add_argument('--allow-partial-merge', action='store_true',
                    help='Explicitly allow a draft combined deck with missing input pages')
    ap.add_argument('--canvas', help='Merged canvas WIDTHxHEIGHT; default first exported page')
    ap.add_argument('--mode', choices=['auto','editable','layered'], default='auto')
    ap.add_argument('--renderer', choices=['auto','offscreen'], default='auto')
    ap.add_argument('--font-name', default='Microsoft YaHei')
    ap.add_argument('--reference-bg', default='FFFFFF', help='RGB hex used to composite transparent input pixels')
    ap.add_argument('--max-rms', type=float, default=.15)
    ap.add_argument('--json', action='store_true')
    args = ap.parse_args(argv)
    if not re.fullmatch(r'#?[0-9a-fA-F]{6}', args.reference_bg):
        ap.error('--reference-bg must be six hexadecimal RGB digits')
    if not 0 <= args.max_rms <= 1:
        ap.error('--max-rms must be between 0 and 1')
    try:
        if CORE_IMPORT_ERROR is not None:
            issue = core_dependency_issue()
            raise ActionError(str(CORE_IMPORT_ERROR), issue['code'], issue['message'], issue['next_action'])
        if args.canvas:
            try:
                w, h = [int(x) for x in args.canvas.lower().split('x')]
                if min(w, h) < 1:
                    raise ValueError('Canvas must be positive')
            except ValueError as exc:
                raise ActionError(str(exc), 'CANVAS_FORMAT', '合并画布尺寸无效。',
                                  '用 --canvas 1920x1080 这样的格式指定正整数宽高。') from exc
        return run_batch(args)
    except Exception as exc:
        report = failure_details(exc)
        issue = report['diagnostic']
        print(f'[{issue["code"]}] {issue["message"]} {report["error"]}', file=sys.stderr)
        print(issue['next_action'], file=sys.stderr)
        if args.json:
            print(json.dumps({'version': VERSION, 'status': 'failed', **report}, ensure_ascii=False, indent=2))
        return 1


if __name__ == '__main__':
    sys.exit(main())
