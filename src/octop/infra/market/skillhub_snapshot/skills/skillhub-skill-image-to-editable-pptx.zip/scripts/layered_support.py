"""Native DrawingML effects and aspect-preserving batch canvas placement (v1.1.0)."""
from pathlib import Path
from PIL import Image, ImageChops
from pptx.oxml import parse_xml
from pptx.oxml.ns import qn
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE

EMU = 9525
A = 'http://schemas.openxmlformats.org/drawingml/2006/main'


def color(value):
    value = str(value).lstrip('#')
    if len(value) != 6 or any(c not in '0123456789abcdefABCDEF' for c in value):
        raise ValueError(f'Invalid RGB color: {value}')
    return value.upper()


def clear_theme_effects(shape):
    shape.shadow.inherit = False
    for node in shape._element.iter(qn('a:effectRef')):
        node.set('idx', '0')


def apply_effects(node, el):
    """Apply editable native glow/shadow, in DrawingML schema order."""
    glow, shadow = el.get('glow'), el.get('shadow')
    if not glow and not shadow:
        return
    old = node.find(qn('a:effectLst'))
    if old is not None:
        node.remove(old)
    effects = []
    if glow:
        effects.append(f'<a:glow rad="{int(float(glow.get("radius", 5))*EMU)}">'
                       f'<a:srgbClr val="{color(glow.get("color", "2288FF"))}">'
                       f'<a:alpha val="{int(float(glow.get("opacity", 65))*1000)}"/>'
                       '</a:srgbClr></a:glow>')
    if shadow:
        effects.append(f'<a:outerShdw blurRad="{int(float(shadow.get("blur", 2))*EMU)}" '
                       f'dist="{int(float(shadow.get("distance", 2))*EMU)}" '
                       f'dir="{int(float(shadow.get("angle", 45))*60000)}" rotWithShape="0">'
                       f'<a:srgbClr val="{color(shadow.get("color", "000000"))}">'
                       f'<a:alpha val="{int(float(shadow.get("opacity", 60))*1000)}"/>'
                       '</a:srgbClr></a:outerShdw>')
    effect = parse_xml(f'<a:effectLst xmlns:a="{A}">{"".join(effects)}</a:effectLst>')
    # rPr: effects precede font definitions; spPr: effects follow line.
    following = {'highlight', 'uLnTx', 'uLn', 'uFillTx', 'uFill', 'latin', 'ea', 'cs',
                 'sym', 'hlinkClick', 'hlinkMouseOver', 'rtl', 'scene3d', 'sp3d', 'extLst'}
    for i, child in enumerate(node):
        if child.tag.split('}')[-1] in following:
            node.insert(i, effect)
            break
    else:
        node.append(effect)


def style_text(run, el, grad_xml):
    rpr = run._r.get_or_add_rPr()
    if el.get('text_grad'):
        for tag in ('solidFill', 'gradFill', 'noFill'):
            for child in rpr.findall(qn('a:' + tag)):
                rpr.remove(child)
        # ln then fill then effects then fonts.
        at = 1 if rpr.find(qn('a:ln')) is not None else 0
        rpr.insert(at, parse_xml(grad_xml(el['text_grad'], el.get('text_grad_dir', 'v'))))
    if el.get('outline'):
        outline = el['outline']
        ln = parse_xml(f'<a:ln xmlns:a="{A}" w="{int(float(outline.get("width", 1))*EMU)}">'
                       f'<a:solidFill><a:srgbClr val="{color(outline["color"])}"/>'
                       '</a:solidFill><a:prstDash val="solid"/></a:ln>')
        old = rpr.find(qn('a:ln'))
        if old is not None:
            rpr.remove(old)
        rpr.insert(0, ln)
    apply_effects(rpr, el)
    if el.get('italic'):
        run.font.italic = True
    if 'char_spacing' in el:
        rpr.set('spc', str(round(float(el['char_spacing']) * 75)))


def special_shape(slide, el):
    x, y, w, h = el['box']
    kind = el.get('type')
    if kind == 'line':
        # Signed endpoints preserve line direction, including vertical/horizontal lines.
        end = el.get('end', [x+w, y+h])
        sp = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
             round(x*EMU), round(y*EMU), round(end[0]*EMU), round(end[1]*EMU))
        ln = sp._element.spPr.get_or_add_ln()
        if el.get('dash'):
            ln.append(parse_xml(f'<a:prstDash xmlns:a="{A}" val="{el["dash"]}"/>'))
        if el.get('arrow_end'):
            ln.append(parse_xml(f'<a:tailEnd xmlns:a="{A}" type="triangle" w="sm" len="sm"/>'))
        return sp
    if kind == 'polygon':
        pts = el.get('points', [])
        if len(pts) < 3:
            raise ValueError('polygon requires at least 3 local pixel points')
        builder = slide.shapes.build_freeform(round(pts[0][0]), round(pts[0][1]), scale=EMU)
        builder.add_line_segments([(round(px), round(py)) for px, py in pts[1:]], close=True)
        return builder.convert_to_shape(round(x*EMU), round(y*EMU))
    return None


def place_background(slide, bg, base, source, w, h, set_page, apply_fill):
    bg = bg or {'kind': 'solid', 'fill': '#FFFFFF'}
    if bg.get('kind') == 'image':
        if bg.get('role') != 'clean-background' or bg.get('contains_text') is not False or bg.get('reviewed') is not True:
            raise ValueError('Image background requires reviewed clean-background with contains_text=false')
        path = Path(bg['file'])
        if not path.is_absolute():
            path = Path(base) / path
        with Image.open(path) as im, Image.open(source) as original:
            if im.size != (w, h):
                raise ValueError('Clean background size must match source')
            if ImageChops.difference(im.convert('RGB'), original.convert('RGB')).getbbox() is None:
                raise ValueError('Original screenshot cannot be used as clean background')
        sp = slide.shapes.add_picture(str(path), 0, 0, width=w*EMU, height=h*EMU)
        sp.name = 'background_clean_raster'
        return 'reviewed clean background (raster)'
    set_page(slide, bg)
    # Native page-sized backdrop is necessary for letterboxing mixed aspect pages.
    sp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, w*EMU, h*EMU)
    sp.name = 'background_native'
    sp.line.fill.background()
    clear_theme_effects(sp)
    spec = {'fill': bg.get('fill', '#FFFFFF')}
    if bg.get('kind') == 'gradient':
        spec = {'grad': bg['grad'], 'dir': bg.get('dir', 'v')}
    apply_fill(sp, spec)
    return bg.get('kind', 'solid')


def fit_slide_to_canvas(slide, w, h, canvas_w, canvas_h):
    scale = min(canvas_w / (w*EMU), canvas_h / (h*EMU))
    dx = (canvas_w-w*EMU*scale)/2
    dy = (canvas_h-h*EMU*scale)/2
    if abs(scale-1) < 1e-10 and abs(dx)+abs(dy) < 1:
        return
    # All objects remain independent. EMU geometry, line widths, fonts and effects
    # scale together; freeform local coordinates continue to map through extents.
    for shape in slide.shapes:
        shape.left = round(shape.left*scale+dx)
        shape.top = round(shape.top*scale+dy)
        shape.width = round(shape.width*scale)
        shape.height = round(shape.height*scale)
        for node in shape._element.iter():
            local = node.tag.split('}')[-1]
            keys = ('w',) if local == 'ln' else ()
            if local in ('rPr', 'defRPr', 'endParaRPr'):
                keys = ('sz', 'spc')
            elif local in ('glow', 'outerShdw'):
                keys = ('rad', 'dist', 'blurRad')
            elif local in ('spcPts',):
                keys = ('val',)
            for key in keys:
                if node.get(key) is not None:
                    node.set(key, str(round(float(node.get(key))*scale)))
    slide.background.fill.solid()
    from pptx.dml.color import RGBColor
    slide.background.fill.fore_color.rgb = RGBColor(24, 24, 24)
