#!/usr/bin/env python3
"""Check final PPTX picture positions against source crop provenance."""
import argparse
import hashlib
import io
import json
import posixpath
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from PIL import Image

NS={'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
    'p':'http://schemas.openxmlformats.org/presentationml/2006/main',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}

def fingerprint(data):
    im=Image.open(io.BytesIO(data)).convert('RGBA')
    return (im.size, hashlib.sha256(im.tobytes()).hexdigest())

def audit(pptx, source, assets, manifest):
    findings=[]
    source_size=Image.open(source).size
    specs=json.loads(Path(manifest).read_text())
    expected={}
    for item in specs:
        key=fingerprint((Path(assets)/item['name']).read_bytes())
        expected.setdefault(key, []).append(item)
        im=Image.open(Path(assets)/item['name']).convert('RGBA')
        alpha=im.getchannel('A'); bbox=alpha.getbbox()
        box=item['source_box']
        if isinstance(box,dict): box=[box[k] for k in ('x','y','w','h')]
        if bbox is None: findings.append('empty asset')
        elif alpha.getextrema()[0]<255 and ((bbox[0]==0 and box[0]>0) or
                (bbox[1]==0 and box[1]>0) or
                (bbox[2]==im.width and box[0]+box[2]<source_size[0]) or
                (bbox[3]==im.height and box[1]+box[3]<source_size[1])):
            findings.append('asset touches a non-canvas crop edge; inspect clipping')
    with zipfile.ZipFile(pptx) as z:
        size=ET.fromstring(z.read('ppt/presentation.xml')).find('p:sldSz', NS)
        sx,sy=int(size.get('cx'))/source_size[0],int(size.get('cy'))/source_size[1]
        if abs(sx/sy-1)>0.001:
            findings.append('page aspect differs from source')
        slides=[n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
        for name in slides:
            relname=posixpath.join(posixpath.dirname(name),'_rels',posixpath.basename(name)+'.rels')
            rels={e.get('Id'):e.get('Target') for e in ET.fromstring(z.read(relname))}
            root=ET.fromstring(z.read(name))
            if root.findall('.//p:grpSp',NS): findings.append('group transforms require flattening before audit')
            for pic in root.findall('.//p:pic',NS):
                blip=pic.find('.//a:blip',NS)
                target=rels.get(blip.get('{'+NS['r']+'}embed'))
                if not target:
                    findings.append('unresolved picture'); continue
                path=target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('ppt/slides',target))
                candidates=expected.get(fingerprint(z.read(path)),[])
                transform=pic.find('p:spPr/a:xfrm',NS)
                if transform is None:
                    findings.append('missing picture transform'); continue
                off,ext=transform.find('a:off',NS),transform.find('a:ext',NS)
                actual=[int(off.get('x'))/sx,int(off.get('y'))/sy,int(ext.get('cx'))/sx,int(ext.get('cy'))/sy]
                matched=None
                for item in candidates:
                    box=item['source_box']
                    if isinstance(box,dict): box=[box[k] for k in ('x','y','w','h')]
                    if max(abs(a-b) for a,b in zip(actual,box))<=0.5:
                        matched=item; break
                if matched is None: findings.append('picture position/size differs from source or unapproved picture')
                else: candidates.remove(matched)
                if any(int(transform.get(k,'0')) for k in ('rot','flipH','flipV')):
                    findings.append('unexpected rotation or flip')
                rect=pic.find('.//a:srcRect',NS)
                if rect is not None and any(int(v) for v in rect.attrib.values()):
                    findings.append('unexpected internal picture crop')
    if any(expected.values()): findings.append('source assets missing or misplaced')
    return {'status':'fail' if findings else 'pass','findings':findings}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('pptx');p.add_argument('--source',required=True)
    p.add_argument('--assets',required=True);p.add_argument('--manifest',required=True)
    a=p.parse_args()
    try: result=audit(a.pptx,a.source,a.assets,a.manifest)
    except Exception as exc: result={'status':'error','message':str(exc)}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='pass' else 1
if __name__=='__main__': raise SystemExit(main())
