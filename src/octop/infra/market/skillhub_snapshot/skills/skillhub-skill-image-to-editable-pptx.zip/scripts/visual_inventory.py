"""Semantic decomposition gate: audit source inventory, exported objects and backdrop.

Inventory is source evidence prepared by visual inspection, never inferred from
exported counts. Pixel changes are a diagnostic, not proof of semantic removal.
"""
from collections import Counter
from pathlib import Path
import math
import numpy as np
from PIL import Image

KINDS = {'photo', 'icon', 'frame', 'connector', 'chart', 'table', 'illustration', 'background'}
NATIVE = {'frame', 'connector', 'chart', 'table'}


def audit_visual_inventory(layout, slide=None):
    issues = []
    inventory = layout.get('visual_inventory')
    review = layout.get('review', {})
    if not isinstance(inventory, list):
        return {'status': 'fail', 'issues': ['Missing source visual_inventory; text-only reconstruction cannot be verified']}
    if review.get('visual_inventory_verified') is not True:
        issues.append('Source visual inventory has not been visually checked')
    if not inventory and review.get('no_visual_objects') is not True:
        issues.append('Empty inventory requires explicit source review: no_visual_objects=true')
    pools = {key: layout.get(key, []) for key in ('texts', 'shapes', 'images', 'icons')}
    records = [(key, el) for key, values in pools.items() for el in values]
    names = Counter(el.get('name') for _, el in records if el.get('name'))
    actual = Counter(s.name for s in slide.shapes) if slide is not None else None
    seen_ids, claimed = set(), set()
    size = layout.get('source_size', [0, 0])
    for item in inventory:
        if not isinstance(item, dict):
            issues.append('Inventory entries must be objects'); continue
        ident, kind = item.get('id'), item.get('kind')
        if not isinstance(ident, str) or not ident or ident in seen_ids:
            issues.append('Inventory IDs must be nonempty and unique')
        seen_ids.add(str(ident))
        if kind not in KINDS:
            issues.append(f'{ident}: unknown visual kind')
        box = item.get('source_box')
        valid = (isinstance(box, list) and len(box) == 4 and
                 all(isinstance(v, (int, float)) and math.isfinite(v) for v in box))
        if not valid or box[0] < 0 or box[1] < 0 or box[2] <= 0 or box[3] <= 0 or box[0]+box[2] > size[0] or box[1]+box[3] > size[1]:
            issues.append(f'{ident}: invalid source_box')
        if item.get('reviewed') is not True:
            issues.append(f'{ident}: source object not reviewed')
        if kind == 'background':
            if item.get('treatment') != 'background':
                issues.append(f'{ident}: invalid background treatment')
            continue
        treatment, targets = item.get('treatment'), item.get('objects')
        if treatment not in {'native', 'raster'} or not isinstance(targets, list) or not targets:
            issues.append(f'{ident}: must map to independent slide objects'); continue
        targets = [t for t in targets if isinstance(t, str)]
        if not targets:
            issues.append(f'{ident}: invalid target object names'); continue
        if kind in NATIVE and treatment != 'native':
            issues.append(f'{ident}: {kind} must use native objects')
        if kind == 'icon' and item.get('editable_paths', True) and treatment != 'native':
            issues.append(f'{ident}: editable icon must use native paths; raster exception requires editable_paths=false and reason')
        if kind == 'icon' and treatment == 'raster' and not item.get('reason'):
            issues.append(f'{ident}: raster icon exception needs a reason')
        for target in targets:
            if target in claimed:
                issues.append(f'{ident}: object {target} shared between source objects')
            claimed.add(target)
            if names[target] != 1:
                issues.append(f'{ident}: missing or duplicate layout object {target}'); continue
            key, el = next((k, e) for k, e in records if e.get('name') == target)
            if treatment == 'native' and key != 'shapes':
                issues.append(f'{ident}: {target} is not a native shape')
            if treatment == 'raster' and key not in {'images', 'icons'}:
                issues.append(f'{ident}: {target} is not an independent picture')
            if actual is not None:
                if actual[target] != 1:
                    issues.append(f'{ident}: missing or duplicate exported object {target}')
                else:
                    sp = next(s for s in slide.shapes if s.name == target)
                    if treatment == 'native' and (sp.shape_type == 13 or sp._element.xpath('.//a:blip')):
                        issues.append(f'{ident}: exported native object contains raster')
                    if treatment == 'raster' and sp.shape_type != 13:
                        issues.append(f'{ident}: exported asset is not a picture')
    for key, el in records:
        if key != 'texts' and el.get('name') not in claimed:
            issues.append(f'Unmapped visual object: {el.get("name")}')
    bg = layout.get('background', {})
    if bg.get('kind') == 'image' and bg.get('visual_objects_removed') is not True:
        issues.append('Backdrop must remove foreground photos, icons, frames and connectors, not only text')
    return {'status': 'pass' if not issues else 'fail', 'issues': issues,
            'source_visual_count': len(inventory), 'mapped_object_count': len(claimed)}


def audit_backdrop_removal(layout, source, base):
    """Reject unchanged foreground regions in an alleged clean backdrop."""
    if layout.get('background', {}).get('kind') != 'image':
        return
    path = Path(layout['background']['file'])
    if not path.is_absolute(): path = Path(base) / path
    with Image.open(source) as original, Image.open(path) as cleaned:
        if original.size != cleaned.size:
            raise ValueError('Backdrop size mismatch')
        a = np.asarray(original.convert('RGB'), dtype=np.int16)
        b = np.asarray(cleaned.convert('RGB'), dtype=np.int16)
    for item in layout.get('visual_inventory', []):
        if item.get('kind') == 'background': continue
        x, y, w, h = item['source_box']
        x0, y0 = int(math.floor(x)), int(math.floor(y))
        x1, y1 = int(math.ceil(x+w)), int(math.ceil(y+h))
        diff = np.max(np.abs(a[y0:y1, x0:x1]-b[y0:y1, x0:x1]), axis=2)
        if not diff.size or float(np.mean(diff > 16)) < .005:
            raise ValueError(f'Backdrop retains source visual object: {item["id"]}')


def main(argv=None):
    import argparse
    import json
    from pptx import Presentation
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('pptx', type=Path)
    ap.add_argument('layout', type=Path)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--slide', type=int, default=1)
    args = ap.parse_args(argv)
    try:
        layout = json.loads(args.layout.read_text(encoding='utf-8'))
        prs = Presentation(args.pptx)
        if not 1 <= args.slide <= len(prs.slides):
            raise ValueError('Slide number outside deck')
        result = audit_visual_inventory(layout, prs.slides[args.slide-1])
        if result['status'] == 'pass':
            audit_backdrop_removal(layout, args.source, args.layout.parent)
    except Exception as exc:
        result = {'status': 'fail', 'issues': [str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result['status'] == 'pass' else 2


if __name__ == '__main__':
    raise SystemExit(main())
