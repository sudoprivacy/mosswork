#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""端到端编排器：describe → crop → build_pptx → 离屏渲染 → 对比。

一站式把 source.png 转成 final.pptx 并产出 verify/ 报告：

  verify/
    layout.json           describe_image.py 输出的元素清单
    crops/                图标裁切（独立 PNG）
    final.pptx            重建后的 PPTX
    rendered.png          离屏渲染回 PNG（与源图同尺寸）
    side_by_side.png      原图 vs 重建并排
    difference.png        原图 vs 重建差异（增强对比）
    report.json           整链路状态 + rms_diff + 阶段摘要

此旧单页调试路线使用 Pillow 几何预览，不作为最终视觉验收。
默认批量路线和真实 Office 渲染见 batch_convert.py；复杂页面缺 OCR 时
生成带坐标的放大检查区，代理需继续逐区重建。

用法：
  python scripts/orchestrate.py source.png -o build/ \\
      --max-rms 0.15 --reference-bg FFFFFF --json
"""
from __future__ import annotations

import argparse
import io
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _ui import SkillError, bad, hint, ok, run, warn, banner  # noqa: E402
from _runtime import VERSION, core_dependency_issue

PIL_IMPORT_ERROR = None
try:
    from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageOps, ImageFont
except Exception as exc:
    PIL_IMPORT_ERROR = exc

EMU_PER_PX = 9525
NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}

THIS_DIR = os.path.dirname(os.path.abspath(__file__))


# ──────────────────────────── 阶段 1：describe ────────────────────────────
def stage_describe(source: str, out_dir: str, bg_blank_alpha: float = 0.0):
    banner("[1/5] 描述 + 定位")
    layout_path = os.path.join(out_dir, "layout.json")
    preview_path = os.path.join(out_dir, "describe_preview.png")
    cmd = [sys.executable, os.path.join(THIS_DIR, "describe_image.py"),
           source, "-o", layout_path, "--preview", preview_path,
           "--bg-blank-alpha", str(bg_blank_alpha)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        bad("describe_image.py 失败")
        print(r.stdout); print(r.stderr)
        raise SystemExit(r.returncode)
    layout = json.loads(open(layout_path, encoding="utf-8").read())
    ok(f"  文字 {layout['summary']['text_count']}  图标 {layout['summary']['icon_count']}  区域 {layout['summary']['region_count']}")
    n_blank = layout["summary"].get("blanked_shape_count", 0)
    if n_blank:
        ok(f"  隐形背景装饰 {n_blank} 个（不透明度 < {bg_blank_alpha:g}%"
           f" → 按空白背景处理）")
    return layout


# ──────────────────────────── 阶段 2：crop ────────────────────────────
def _alpha_coverage(path: str) -> float:
    """PNG 里不透明像素占比（0..1）；读不出来返回 1.0。

    3.4.0 起裁剪改为批量模式，安全阀（不透明比例 < 0.12 则退回不去背景版本）
    已在 `crop_assets.py --batch` 内部实现，故此处不再被主链路调用；保留作为
    语义参考与外部脚本的便捷工具，判定口径与批量模式**完全一致**
    （alpha != 0 即视为不透明）。
    """
    try:
        from PIL import Image
        im = Image.open(path)
        if im.mode != "RGBA":
            return 1.0
        hist = im.getchannel("A").histogram()
        total = im.width * im.height
        return (total - hist[0]) / total if total else 1.0
    except Exception:
        return 1.0


def _ring_bg_hex(source: str, x: int, y: int, w: int, h: int, pad: int = 2):
    """从裁剪框外侧的环带估计"真正的包围背景色"，返回 '#RRGGBB' 或 None。

    比 crop_assets 的 `--bg auto` 稳得多：auto 会在四角各取 7×7、最多 12 个
    种子色，一旦图标自身触到裁剪边，图标色也被当成背景 → 整块被抹成线框
    （真实测试图里的"工厂"图标就是这样被啃掉的）。这里只取一条环带的中位数，
    并且环带本身不够纯（MAD 偏大）时就放弃，交给 auto。
    """
    try:
        import numpy as np
        from PIL import Image
        im = Image.open(source).convert("RGB")
        X0, Y0 = max(0, x - pad), max(0, y - pad)
        X1, Y1 = min(im.width, x + w + pad), min(im.height, y + h + pad)
        if X1 - X0 < 3 or Y1 - Y0 < 3:
            return None
        a = np.asarray(im.crop((X0, Y0, X1, Y1))).astype(np.int32)
        ring = np.concatenate([a[0:pad].reshape(-1, 3), a[-pad:].reshape(-1, 3),
                               a[:, 0:pad].reshape(-1, 3), a[:, -pad:].reshape(-1, 3)],
                              axis=0)
        med = np.median(ring, axis=0)
        mad = float(np.median(np.abs(ring - med).sum(axis=1)))
        if mad > 36:
            return None
        return "#%02X%02X%02X" % tuple(int(v) for v in med)
    except Exception:
        return None


def stage_crop(source: str, layout: dict, out_dir: str):
    banner("[2/5] 裁剪图标")
    crops_dir = os.path.join(out_dir, "crops")
    os.makedirs(crops_dir, exist_ok=True)
    crops_meta = []
    n_fallback = 0
    icons = layout.get("icons", [])
    if not icons:
        ok(f"  共裁 0 张图标 → {crops_dir}")
        ok(f"  形状 {len(layout.get('shapes', []))} 个（由 build_pptx 直接画，无需裁图）")
        return crops_dir, crops_meta

    # 3.4.0：改为**批量模式**——一次进程裁完全部图标。此前每张图标都
    # `subprocess.run(crop_assets.py)`，每次重启解释器都要重新导入
    # numpy/PIL/onnxruntime（约 0.7~0.9 s）。57 张图标 ⇒ 整链路多花约 45 s，
    # 是"耗时过长"的最后一块大头。现在无论多少图标都只付一次导入成本。
    jobs = []
    for ic in icons:
        x, y, w, h = [int(round(v)) for v in ic["box"]]
        out_png = os.path.join(crops_dir, ic["name"] + ".png")
        # 3.4.0：默认带去背景。以前不带 --transparent，图标永远是不透明方片，
        # 贴在深色版式上就是一块块"补丁"——这是"不像原图"的主要来源之一。
        bg_hex = _ring_bg_hex(source, x, y, w, h, 2)
        jobs.append({
            "name": ic["name"], "x": x, "y": y, "w": w, "h": h,
            "out": out_png, "metadata": out_png + ".json",
            "transparent": True, "bg": bg_hex or "auto", "tolerance": 30,
        })
    manifest_path = os.path.join(out_dir, "crops_manifest.json")
    report_path = os.path.join(out_dir, "crops_report.json")
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump({"image": source, "pad": 2, "jobs": jobs}, f,
                  ensure_ascii=False, indent=2)

    r = subprocess.run([sys.executable, os.path.join(THIS_DIR, "crop_assets.py"),
                        source, "--batch", manifest_path,
                        "--batch-report", report_path],
                       capture_output=True, text=True)
    if r.returncode != 0:
        warn(f"  批量裁剪失败：{r.stderr.strip() or r.stdout.strip()}")
        return crops_dir, crops_meta
    with open(report_path, encoding="utf-8") as f:
        report = json.load(f)
    by_name = {res["name"]: res for res in report.get("results", [])}

    for ic in icons:
        res = by_name.get(ic["name"])
        if not res or not res.get("ok"):
            warn(f"  {ic['name']} 裁剪失败：{(res or {}).get('error', '未产出')}")
            continue
        if res.get("fallback"):
            warn(f"  {ic['name']} 去背景后几乎全透明（整块同色），退回不透明裁图。")
            n_fallback += 1
        # 裁图带了 2px 外扩，显示框就必须跟着外扩：否则"素材比例 ≠ 显示比例"，
        # 既会被 validate_structure.py 判成 picture_aspect_drift，也会让图标
        # 相对源图偏移 2px（透明边距被当成内容缩掉了）。
        sb = res.get("source_box")
        if sb:
            ic["box"] = [int(v) for v in sb]
        crops_meta.append({"name": ic["name"] + ".png",
                           "source_box": list(ic["box"])})
    ok(f"  共裁 {len(crops_meta)} 张图标 → {crops_dir}"
       + (f"（{n_fallback} 张因整块同色保留不透明）" if n_fallback else ""))
    ok(f"  形状 {len(layout.get('shapes', []))} 个（由 build_pptx 直接画，无需裁图）")
    return crops_dir, crops_meta


# ──────────────────────────── 阶段 3：build_pptx ────────────────────────────
def stage_build(source: str, layout_path: str, crops_dir: str, out_dir: str,
                bg_blank_alpha: float = 0.0):
    banner("[3/5] 构建 PPTX")
    pptx_path = os.path.join(out_dir, "final.pptx")
    cmd = [sys.executable, os.path.join(THIS_DIR, "build_pptx_from_layout.py"),
           source, layout_path, crops_dir, "-o", pptx_path,
           "--bg-blank-alpha", str(bg_blank_alpha)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        bad("build_pptx_from_layout.py 失败")
        print(r.stdout); print(r.stderr)
        raise SystemExit(r.returncode)
    ok(f"  已生成 {pptx_path}")
    return pptx_path


# ──────────────────────────── 阶段 4：离屏渲染 ────────────────────────────
def _emu_to_px(emu: str) -> float:
    try:
        return int(emu) / EMU_PER_PX
    except Exception:
        return 0.0


def _font_for(slide_w_px: int, height_px: float):
    """挑一个能用的字体（Windows / macOS / Linux）。"""
    candidates = [
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/Deng.ttf",
        "C:/Windows/Fonts/simsun.ttc",
        "/System/Library/Fonts/Supplemental/PingFang.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/Library/Fonts/PingFang.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for c in candidates:
        if os.path.exists(c):
            try:
                return ImageFont.truetype(c, max(8, int(height_px * 0.85)))
            except Exception:
                continue
    return ImageFont.load_default()


def render_offscreen(pptx_path: str, source_size):
    """读最终 PPTX，按 EMU 坐标在 Pillow 画布上重绘。

    3.3.2 起统一委托给 scripts/render_offscreen.py —— 它同时支持
    describe_image.py 的自动 layout 与手工富 schema（roundrect / ellipse /
    arrow / gradFill / 旋转 / 层级），并修掉了 `../media/...` 关系路径未归一化
    导致**所有图片静默丢失**的渲染 bug。

    与 describe_image.py / build_pptx_from_layout.py 共用同一坐标系 →
    几何位置天然一致，本函数只验证「放对位置 + 层级正确 + 文本未被裁断」。
    """
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from render_offscreen import render as _render
    return _render(pptx_path, tuple(source_size))


def _wrap_text(text: str, width: int):
    """极简按字符宽度换行（CJK 友好）。"""
    if width <= 0:
        width = 1
    out, buf = [], []
    for ch in text:
        buf.append(ch)
        if len(buf) >= width:
            out.append("".join(buf))
            buf = []
    if buf:
        out.append("".join(buf))
    return out


# ──────────────────────────── 阶段 5：对比 ────────────────────────────
def stage_compare(rendered: Image.Image, source: str, out_dir: str, args):
    banner("[5/5] 对比原图 vs 渲染")
    src = Image.open(source).convert("RGB")
    if rendered.size != src.size:
        warn(f"渲染尺寸 {rendered.size} ≠ 源图 {src.size}，按源图等比缩放再比。")
        rendered = rendered.resize(src.size, Image.LANCZOS)
    diff_dir = os.path.join(out_dir, "compare")
    os.makedirs(diff_dir, exist_ok=True)
    diff = ImageChops.difference(src, rendered)
    raw_rms = _rms(diff)
    enhanced = ImageEnhance.Contrast(ImageOps.autocontrast(diff)).enhance(2)
    enhanced.save(os.path.join(diff_dir, "difference.png"))
    side = Image.new("RGB", (src.width * 2, src.height), "white")
    side.paste(src, (0, 0))
    side.paste(rendered, (src.width, 0))
    side.save(os.path.join(diff_dir, "side_by_side.png"))
    status = "pass" if raw_rms <= args.max_rms else "fail"
    ok(f"  rms_diff={raw_rms:.6f} (max {args.max_rms:.4f}) → {status}")
    return {"status": status, "rms_diff": raw_rms, "max_rms": args.max_rms,
            "side_by_side": os.path.join(diff_dir, "side_by_side.png"),
            "difference": os.path.join(diff_dir, "difference.png")}


def _rms(diff: Image.Image) -> float:
    hist = diff.histogram()
    sq = sum(((i % 256) ** 2) * c for i, c in enumerate(hist))
    samples = diff.width * diff.height * 3
    return (sq / samples) ** 0.5 / 255.0


# ──────────────────────────── 主流程 ────────────────────────────
def main():
    if "--legacy-single" not in sys.argv:
        from batch_convert import main as batch_main
        return batch_main()
    sys.argv.remove("--legacy-single")
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--version', action='version', version=VERSION)
    ap.add_argument("source", help="源图")
    ap.add_argument("-o", "--out-dir", default="build/", help="所有产物目录")
    ap.add_argument("--max-rms", type=float, default=0.15,
                    help="原图 vs 重建的 RMS 上限（默认 0.15；高密度页可放宽）")
    ap.add_argument("--reference-bg", default="FFFFFF",
                    help="白底归一化背景（默认 FFFFFF）")
    ap.add_argument("--json", action="store_true", help="末尾打 report.json")
    ap.add_argument("--bg-blank-alpha", type=float, default=0.0,
                    help="背景隐形图形的等效不透明度阈值（0-100）：底层无描边大色块"
                         "低于它就按空白背景处理（默认 0，关闭）")
    a = ap.parse_args()

    if PIL_IMPORT_ERROR is not None:
        issue = core_dependency_issue()
        raise SkillError(issue['message'], reason=str(PIL_IMPORT_ERROR),
                         next_steps=[issue['next_action']], doc=issue['doc'])

    if not os.path.isfile(a.source):
        raise SkillError(f"找不到源图：{a.source}",
                         reason="路径不存在。", next_steps=["用绝对路径重试。"])

    out_dir = os.path.abspath(a.out_dir)
    os.makedirs(out_dir, exist_ok=True)
    banner(f"开始端到端编排 → {out_dir}")
    ok(f"  源图   : {a.source}")
    ok(f"  产物目录: {out_dir}")

    layout = stage_describe(a.source, out_dir, a.bg_blank_alpha)
    crops_dir, _ = stage_crop(a.source, layout, out_dir)
    # stage_crop 会把每个图标的 box 校正成"实际裁剪框"（含 2px 外扩），
    # 必须回写 layout.json —— build 阶段是重新读盘的，不回写就白改了。
    layout_path = os.path.join(out_dir, "layout.json")
    with open(layout_path, "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False, indent=2)
    pptx = stage_build(a.source, layout_path, crops_dir, out_dir, a.bg_blank_alpha)

    # 阶段 4：离屏渲染
    banner("[4/5] 离屏渲染（几何预览）")
    rendered = render_offscreen(pptx, layout["source_size"])
    render_path = os.path.join(out_dir, "rendered.png")
    rendered.save(render_path)
    ok(f"  渲染图已保存 → {render_path}")

    cmp_res = stage_compare(rendered, a.source, out_dir, a)

    report = {
        "status": "needs_review",
        "visual_pass": False,
        "renderer": "geometry-only",
        "source": os.path.abspath(a.source),
        "source_size": layout["source_size"],
        "layout_json": os.path.join(out_dir, "layout.json"),
        "crops_dir": crops_dir,
        "pptx": pptx,
        "rendered": render_path,
        "compare": cmp_res,
        "summary": layout["summary"],
    }
    if a.json:
        report_path = os.path.join(out_dir, "report.json")
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        ok(f"  report.json → {report_path}")
    banner(f"完成 · {cmp_res['status'].upper()}")
    return 0 if cmp_res["status"] == "pass" else 1


if __name__ == "__main__":
    sys.exit(run(main))
