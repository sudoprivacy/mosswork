// Map the actual physical crop, including padding, through ONE page scale.
export function sourcePlacement(sourceBox, sourceSize, slideSize) {
  const b = Array.isArray(sourceBox) ? sourceBox : [sourceBox.x, sourceBox.y, sourceBox.w, sourceBox.h];
  const [sw, sh] = sourceSize;
  const [pw, ph] = slideSize;
  if (![...b, sw, sh, pw, ph].every(Number.isFinite) || Math.min(b[2], b[3], sw, sh, pw, ph) <= 0)
    throw new Error("Invalid geometry");
  const scale = pw / sw;
  if (Math.abs((ph / sh) / scale - 1) > 1e-6) throw new Error("Page aspect differs from source");
  return {left:b[0]*scale, top:b[1]*scale, width:b[2]*scale, height:b[3]*scale};
}
