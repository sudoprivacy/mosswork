# 非文字对象拆分与验收

## 从原图建清单

先逐区打开源图，再填写 `visual_inventory`。不要从 layout 或已导出 PPT 倒推清单。每张独立照片、每个图标、每个可移动边框、每条有语义的箭头分别建项。重复图标在不同位置也分别建项。背景花纹可以合为 background；设备卡片、照片网格、页脚图标条、流程模块不属于背景。

照片保留为独立图片，允许移动、缩放、替换，不承诺把照片内部像素变为矢量。若照片上叠有图标、箭头或标签，应分离这些叠加元素，修复照片相应区域。简单图标与箭头用原生自由形状/线条重建，复杂多色商标或插画可独立透明图片保留并说明路径不可编辑。不能用通用符号替换原图标。

## 最小示例

```json
{
  "source_size": [1600, 900],
  "review": {
    "inventory_complete": true,
    "text_verified": true,
    "visual_inventory_verified": true
  },
  "visual_inventory": [
    {"id":"photo-01","kind":"photo","source_box":[40,200,240,150],
     "treatment":"raster","objects":["photo-01"],"reviewed":true},
    {"id":"flame-01","kind":"icon","source_box":[250,315,32,32],
     "treatment":"native","objects":["flame-path-01"],"reviewed":true},
    {"id":"arrow-01","kind":"connector","source_box":[350,120,220,80],
     "treatment":"native","objects":["arrow-segment-01","arrow-head-01"],"reviewed":true},
    {"id":"ambient","kind":"background","source_box":[0,0,1600,900],
     "treatment":"background","reviewed":true}
  ]
}
```

`source_box` 使用 [x,y,w,h] 原图像素。`objects` 对应 shapes/images/icons 中唯一命名，背景不得作为前景项的目标。一个复杂图标可对应多个原生 shape，但不得与另一个图标共享目标对象。图表、表格的标题与数据文字仍置 texts；图形部分映射 shapes，照片映射 images。零宽连线的清单框使用其实际可见笔画范围，shape 自身仍可零宽。

栅格图标例外需同时写 `editable_paths:false`、`treatment:raster` 与具体 `reason`。不得对整页所有图标批量写例外以节省工作。输出说明区分：原生可改颜色/路径、独立图片可移动/替换、修复背景。

纯文字输入可以写空清单，但须真实检查并设置 `review.no_visual_objects:true`。不含非文字元素的源图才允许此标志。

## 去除底图残留

背景图片必须是只含环境/纹理的干净底图。除 contains_text:false、reviewed:true 外，添加 `visual_objects_removed:true`。把独立照片、图标、箭头、框都从底图移除；否则移动前景对象后仍会露出重复元素。用图像编辑能力修复背景，保留环境构图和色调。读取图像编辑技能并使用图像编辑工具，不用大矩形盖住旧图标来蒙混。

程序比较每个源对象框与背景，未变化的区域会拒绝；像素变化不能证明语义消失，仍须查看底图并在验证副本中逐个隐藏/平移前景对象，确认原位置没有残留和重复。不要为通过检查给底图加噪声、色偏或挪动框。

## 验证

批量 `structure_check` 和外部渲染验收都调用 `visual_inventory.py`。缺少清单、只核对文字、漏对象、未映射、名称重复、原生对象含图片都会失败。历史 layout 可用于初稿诊断，但不能获得 verified。声明完整不等于完整，必须逐区人工/代理复核。

1. 对比原图与最终渲染，核对每张照片、每个图标、箭头与边框的位置和外观。
2. 检查最终 PPT 对象，不仅检查 layout：照片数量逐项对应、图标路径可编辑、箭头独立。
3. 在验证副本隐藏/移动照片和图标，检查底图残留。不要把验证副本交付。
4. 各项通过后才写 review 标志。缺少原图或完整原图不可读时不能声明还原完成。

附件同类工业页面至少核对照片网格中的每张设备照片、每个照片角标、右侧指标图标、底部收益图标、主标题标志和流程箭头。照片上的发光箭头要按语义判断是否属于可移动标注，不默认焊在照片中。
