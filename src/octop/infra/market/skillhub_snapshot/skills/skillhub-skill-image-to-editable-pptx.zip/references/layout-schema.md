# 手工 layout schema（旧版基础字段）

`describe_image.py` 适合「元素能被自动识别」的页面；信息图密度高、文字多、
装饰形状复杂时，自动结果不够用。这时按本规范手工编制 `layout.json`，
共享同一条坐标链路（源图像素 → ×9525 EMU → PPT 显示框），可做到
文字与图标的落点误差 ≤1px。

## 顶层

```json
{
  "source_size": [1672, 941],
  "shapes": [...], "images": [...], "texts": [...], "icons": [...]
}
```

`icons` 是旧版字段（等价于 `images`，`name` 即 `crops/<name>.png`），
保留向后兼容；新写的一律用 `images`。

## shapes

| 字段 | 说明 |
|---|---|
| `name` | 唯一名，报错时用于定位 |
| `type` | `rect` / `roundrect` / `ellipse` / `chamfer`(切角) / `triangle` / `chevron` |
| `arrow` | `left` / `right` / `up` / `down`，设置后覆盖 `type` |
| `box` | `[x, y, w, h]` 源图像素 |
| `fill` | `"#RRGGBB"`；`null` 表示无填充 |
| `grad` | `["h"|"v"|"diag", ["#A", "#B", ...]]`，与 `fill` 互斥，`grad` 优先 |
| `border` | 描边色，缺省不描边 |
| `bw` | 描边宽度（源图像素），内部折算 `pt = bw × 0.75` |
| `radius` | 圆角半径（源图像素），内部折算成 `adj = radius / min(w,h)` |
| `alpha` | 不透明度（0–100，越大越实）。显式启用旧过滤时，用于判断背景层装饰是否保留 |
| `z` | 层级，见下 |

## 背景隐形图形 → 空白（旧版显式选项）

底层（`z <= 4`）、无描边、面积 ≥ 页面 0.5%、框内没有"被它托着"的文字/图标，
且等效不透明度低于显式设置的阈值时，rect / roundrect / ellipse / chamfer
可按空白背景处理，让页面背景透出。判据见 `scripts/bg_blank.py`。
批量主入口保留这些装饰；独立构建入口的 `--bg-blank-alpha` 默认 `0`（关闭），
旧流程明确需要过滤时才手工指定阈值，例如 `--bg-blank-alpha 60`。

`describe_image.py` 会把这类形状写进顶层的 `blanked_shapes`
（`box / fill / alpha / reason`），手工复核时先看它。
卡片底板、面板、进度条、带描边容器**不受影响**。

## images

| 字段 | 说明 |
|---|---|
| `box` | PPT 显示框，源图像素 |
| `crop` | 源图裁切框，**必须与 `box` 等尺寸**（contain + aspect lock，禁止二次裁切） |
| `file` | 相对 `layout.json` 的路径 |
| `ramp` | `true` 时按亮度做 alpha 渐变 |
| `ramp_lo` / `ramp_hi` | 亮度 < lo 全透明、> hi 全不透明 |
| `invert` | 反向 ramp：**亮底变透明、深色笔画保留**（浅底上的深色线条图标必须开） |
| `feather` | 四边羽化像素数，用于「整块保留原样、只柔化边界」的机械插画 |

## texts

| 字段 | 说明 |
|---|---|
| `box` | 源图像素 |
| `size_pt` | 字号；缺省时由框高反推（`h × 0.85 / 1.333`） |
| `color` | 缺省时取框内最暗像素 |
| `bold` / `align`(`l`\|`c`\|`r`) / `anchor`(`t`\|`m`\|`b`) / `spacing` | 段落属性 |
| `runs` | 字符串数组，按字逐字上色（用于「白→绿」这类渐变标题，仍保持可编辑） |
| `z` | 文本默认建议 40+，确保不被底层容器覆盖 |

含换行时直接写 `"\n"`，**不要在框内依赖自动换行**——那样渲染器和
PowerPoint 的断行位置可能不一致。

## z 层级约定

排序键 = `(z, 类型序, 声明序)`，类型序 `shape=0 < image=1 < text=2`。
同 z 时形状先于图片、图片先于文本。经验值：

```
0–4    背景 / 装饰大块
8–12   面板容器、卡片底板
12–16  局部形状、素材图
17–22  箭头、徽章、连线
25–30  标题装饰线
40     正文文字
100    默认（未指定 z 的文本）
```

## 字号标定（重要）

源图是位图，OCR 框高不等于字号。用 **墨迹宽度 ÷ 该串的全宽字符数** 反推更准：

```
em_px ≈ ink_width / em_count      # CJK 每字 1 em，数字/斜杠约 0.5 em
size_pt ≈ em_px × 0.75
```

`em_count` 计算：汉字与全角标点算 1，半角数字/字母/斜杠算 0.5，空格算 0.25。

标定后必须用 `render_offscreen.py` 复测：把渲染图与源图**同一窗口**的墨迹宽度
相比，比值落在 0.97–1.03 即合格（>1.05 会有换行/裁断风险，<0.9 视觉偏小）。

## 自校验闭环

```bash
python scripts/build_pptx_from_layout.py source.png layout.json crops/ -o final.pptx
python scripts/render_offscreen.py final.pptx -o rendered.png \
       --size 1672x941 --reference source.png --json
python scripts/validate_structure.py final.pptx --min-text-objects N \
       --expected-picture-count M --forbid-groups --json
```

- 坐标检查 = `render_offscreen.py` 的 RMS + `validate_structure.py` 全绿
- 视觉检查 = 必须在 PowerPoint / WPS 里打开 `final.pptx` 人工确认
- 没有真实渲染结果时，**只能标记「坐标检查通过」**，不得宣称最终验收通过
