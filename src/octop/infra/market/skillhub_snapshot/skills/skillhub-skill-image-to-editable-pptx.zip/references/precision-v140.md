# 混排、字体和坐标精度

## 原生富文本

原有 `runs: ["#RRGGBB", ...]` 逐字颜色保持兼容。需要不同字号、字重或字体时使用 `spans`。每段 `text` 拼接后必须逐字等于父级 `text`，包括空格和换行；不一致时导出报错，防止静默漏字。

```json
{
  "name": "result-line",
  "text": "5 项协同事项\n平均 3 天缩短至 1 天以内",
  "box": [418.25, 790.5, 880.5, 78.25],
  "box_mode": "frame",
  "font_name": "Noto Sans CJK SC",
  "size_pt": 17,
  "color": "#FFFFFF",
  "line_spacing_pt": 28,
  "spans": [
    {"text": "5 项", "size_pt": 24, "bold": true, "color": "#FFD966"},
    {"text": "协同事项\n平均 "},
    {"text": "3 天", "size_pt": 24, "bold": true, "color": "#FFD966"},
    {"text": "缩短至 "},
    {"text": "1 天以内", "size_pt": 24, "bold": true, "color": "#FFD966"}
  ]
}
```

坐标仅演示字段，按实际源图重新测量。`spans` 必须配合 `box_mode: frame` 和显式 `size_pt`，不让单一字号拟合算法猜测混排字号。段内可覆盖 `font_name`、`size_pt`、`bold`、`color`、`italic`、`char_spacing`、`outline`、`glow`、`shadow`、`text_grad`。同一段落共享对齐和固定行距；需要不同基线或复杂斜排时拆成独立文本框。

`line_spacing_pt` 是固定磅值，优先于原有倍数 `spacing`。行距必须容纳最大字号，实际渲染检查大数字与上下行是否碰撞。换行用明确的 `\n`；不要为了容纳错误字体而扩大文字框。

## 字体一致性

字体测量与 PPT 内写入的字体必须一致。Linux 使用 fontconfig 解析字体族、字重、字体集合索引；其他环境按实际可用字体回退。`build_pptx_from_layout.resolve_font` 返回 requested/resolved/file/index/bold/substituted，可用于核对实际字体。fontconfig 字体匹配不证明所有字符都具备字形：中文缺字、替代字体字宽、合成粗体和 Office 再次回退都要通过真实渲染检查。

缺失原字体时优先选择覆盖中文的安装字体，按相同文字实际测量字宽和基线，明确说明替换；不把换一种字体称为原字形精确复原。

## 小数坐标与图片

框坐标和尺寸支持小数像素。直到写入 PPT 的 EMU 单位时才取整，避免多对象对齐时累积半像素/一像素偏差。图片等比居中不再对宽高分别取整。原始栅格素材仍有自身像素分辨率限制；这项修正只消除额外的几何误差。

## 逐区修正顺序

先修文字内容和缺对象，再修几何、字体/字号/行距、图片边缘，最后修描边/发光/颜色。每轮重新渲染最终 PPT，查看高误差网格与对应区域。记录尚未恢复的字体、隐藏背景或图标轮廓，不凭一次整页分数宣布复杂页面精确还原。
