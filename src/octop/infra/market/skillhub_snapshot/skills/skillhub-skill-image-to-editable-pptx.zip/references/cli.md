# 命令与参数

以下命令从含 `SKILL.md` 的目录执行。首次安装与版本核对见 [快速开始](../README.md)。

## 准备、构建、续跑

```bash
python scripts/batch_convert.py "images/01.png" "images/02.jpg" -o build --ocr none --json
python scripts/batch_convert.py images/ --recursive -o build --ocr none
python scripts/batch_convert.py --manifest build/continue.json -o build --resume --ocr none --json
```

前两条是同类入口的两个例子。开始时选一种输入方式。默认先生成源图、放大阅读块和 `work-queue.json`。查看对应页的 `measured_layout`，完成 [布局测量](layout-schema-v110.md) 和素材后，使用第三条继续。无显式布局时，也可在原命令加 `--resume`。清单中显式指定的 `layout` 是权威路径，修订应写在该文件上。

清单可用 `{"jobs":[...]}` 或直接使用 JSON 数组。相对路径按清单所在目录解析，带空格的命令行路径加引号。任务按数组顺序执行，重复输入保留原顺序与编号。

```json
{
  "jobs": [
    "images/01.png",
    {"source":"images/02.png","mode":"layered","layout":"layouts/02.json","crops":"assets/02"}
  ]
}
```

## 常用选择

| 目标 | 参数 | 生效条件和行为 |
| --- | --- | --- |
| 显式先准备阅读块 | `--prepare-only`、`--mode layered` | 未提供布局时准备测量材料。显式布局照常构建 |
| 生成自动 OCR 粗稿 | `--mode editable` | 需要 RapidOCR。自动稿仍需逐项核对 |
| 让代理转录原图 | `--ocr none` | 跳过 OCR，使用放大块，已测量的布局可直接构建 |
| 只导出原比例单页 | `--separate-only` | 每个可导出页面单独生成 `editable.pptx` |
| 指定合并画布 | `--canvas 1920x1080` | 按正整数宽高设置，页面等比留边。省略时使用首张成功导出的源图比例 |
| 在缺页时导出合并草稿 | `--allow-partial-merge` | 成功页按输入顺序合并，报告记录原页号及缺页 |
| 配置透明图的合成底色 | `--reference-bg F6F7F8` | 使用六位 RGB 十六进制。更换底色后重新校准测量布局 |
| 指定默认字体 | `--font-name "Microsoft YaHei"` | 可以被布局内的逐对象字体覆盖。实际字体以环境和 Office 渲染为准 |
| 只生成几何预览 | `--renderer offscreen` | 适合排查位置，PPTX 仍待真实渲染 |
| 重用可用页面产物 | `--resume` | 比对输入、布局、素材、代码与运行环境，保留原输入顺序 |
| 输出结构化状态 | `--json` | stdout 为 JSON，进度和修复提示发到 stderr |
| 查看当前版本 | `--version` | 批量入口、兼容入口和预检输出相同版本 |

用包内样例练习指定合并画布或只导出单页。

```bash
python scripts/batch_convert.py --manifest examples/measured-demo/jobs.json -o demo-wide --canvas 1280x800 --ocr none --json
python scripts/batch_convert.py --manifest examples/measured-demo/jobs.json -o demo-single --separate-only --ocr none --renderer offscreen --json
```

## 文件与状态

| 位置 | 用途 |
| --- | --- |
| `batch-report.json` | 批量状态、输入及导出数量、合并页号与合并视觉验收。pending_count 仅统计待测量页，pending_indices 列出所有待测量、待核对或失败页 |
| `work-queue.json` / `continue.json` | 每页的权威布局、修复任务和可续跑输入顺序 |
| `pages/0001_文件名/` | 归一化源图、放大块、布局草稿、测量布局、独立 PPTX、日志与 `repair-tasks.json` |
| 页目录的 `side_by_side.png` / `difference.png` | 左原图右渲染图，以及增强的像素差异 |
| `combined.pptx` / `combined-review/` | 合并成品及重新渲染后的逐页对照 |

批量退出码 `0` 表示通过可用的真实渲染与结构验收，`2` 表示仍待测量或复核，`1` 表示本次存在失败项。检查报告中的状态可区分参数解析错误和待复核状态。不同页的对比图与修复任务独立保存。

使用外部 Office 导出的渲染图时，按 [FAQ 的外部复核步骤](faq.md#真实渲染和字体) 校验最终文件。`orchestrate.py` 默认转发到批量入口。`--legacy-single` 供旧单页几何调试，详见 [旧流程](reconstruction-and-qa.md)。
