> 此页用于旧版透明前景与 Artifact Tool 路线。常规批量与照片底图走 [主流程](../SKILL.md) 和 [复杂页面](complex-pages.md)。

# 背景移除流程

背景移除必须发生在任何元素裁剪和 PPT 构建之前。输出是与原图同尺寸、同坐标的透明前景参考图，不是最终 PPT 素材，也不得整张嵌入 PPT。

## 复杂背景：语义蒙版 + 原像素合成

1. 用 `view_image` 检查原图。
2. 使用内置 ImageGen 的 `background-extraction` 编辑模式，请求真实透明背景。提示词必须包括：

```text
只移除背景。保持所有前景主体完整无损，不移动、不缩放、不重绘、不改字、不改数字、不改颜色。
保留细线、阴影、发光、半透明边缘和所有小装饰。边缘干净平滑，无白边、彩边、锯齿、孔洞或切边。
输出真实透明 PNG，不要白底、棋盘格、水印或新增内容。
```

3. ImageGen 输出只作为语义 alpha 蒙版，不直接作为前景 RGB。把它的 alpha 套回原图：

```bash
python scripts/remove_background.py source.png \
  --mask imagegen-transparent-draft.png \
  --mask-mode alpha --resize-mask --max-mask-aspect-drift 0.005 \
  --feather 0 --out source-foreground.png --json
```

这样所有可见颜色、中文和数字仍来自原图，ImageGen 只决定透明区域。若蒙版没有 alpha，可改用黑底白主体蒙版并指定 `--mask-mode luma`；黑白含义相反时加 `--invert-mask`。

## 纯色或近纯色背景：确定性边缘连通法

仅用于单个图标、Logo 或产品裁图，不能用于复杂整页信息图：

```bash
python scripts/remove_background.py crop.png --out crop-transparent.png \
  --tolerance 45 --expand 1 --feather 1 --json
```

算法只移除与画布边缘连通、且接近角点背景色的像素，避免误删主体内部相近颜色。主体碰到画布边缘或背景复杂时改用语义蒙版。

## 强制验收

```bash
python scripts/audit_transparency.py source-foreground.png \
  --source source.png --require-smooth-edges \
  --max-opaque-rgb-rms 0 \
  --preview-dir verify/background-removal --json
```

必须同时检查：

- PNG 有真实 alpha，且既有透明区域也有前景。
- 输出与原图尺寸完全一致。
- alpha ≥ 250 的前景 RGB 与原图逐像素一致，RMS 为 0。
- 存在半透明边缘像素，避免硬锯齿。
- 在深色、白色和洋红底预览上均无白边、彩边、孔洞、切边。

任何一项失败都重新修蒙版，不得进入 PPT 构建。

## 禁止事项

- 不得直接使用 ImageGen 重绘后的 RGB。
- 不得自动裁紧整张透明前景图，坐标必须与原图一致。
- 不得把整张透明前景图嵌入 PPT。
- 不得把透明前景图切成卡片、横条或网格块后拼回页面。
- 不得把含文字、数字、图表、面板或多个主体的裁片登记为独立素材。
