# 批量分层布局字段

旧基础字段见 [布局兼容参考](layout-schema.md)。所有 box 为源图像素 `[x,y,w,h]`。source_size 必须等于 EXIF 归一化后的源图尺寸。`images[].file` 相对于素材目录或布局文件目录；背景文件相对于布局文件。

```json
{
  "source_size": [1600,900],
  "background": {"kind":"solid","fill":"#061634"},
  "regions": [{"name":"组织架构","box":[450,110,700,320]}],
  "shapes": [
    {"name":"切角框","type":"polygon","box":[450,110,700,100],
     "points":[[12,0],[688,0],[700,12],[700,88],[688,100],[12,100],[0,88],[0,12]],
     "fill":"#061634","border":"#69EFFF","border_width":2,
     "glow":{"color":"#2255FF","radius":6,"opacity":75},"z":10},
    {"name":"下行连线","type":"line","box":[800,210,0,30],"end":[800,240],
     "border":"#BAFFFF","border_width":2,"arrow_end":true,"z":20}
  ],
  "texts": [
    {"name":"标题","text":"组织架构与成员职责","box":[300,12,740,60],
     "box_mode":"frame","size_pt":32,"font_name":"Microsoft YaHei","bold":true,
     "text_grad":["#FFFFEA","#FFD83B"],"text_grad_dir":"v",
     "outline":{"color":"#493700","width":0.5},
     "shadow":{"color":"#000000","blur":2,"distance":3,"angle":45,"opacity":60},"z":100}
  ],
  "images": [{"name":"成员01照片","file":"member01.png","box":[340,500,85,70],"z":30}],
  "review":{"inventory_complete":false,"text_verified":false}
}
```

`polygon.points` 为相对于 box 左上角的像素顶点；其点的外接矩形应与 box 尺寸一致。
`line.end` 为绝对像素终点，允许水平/垂直线，arrow_end 为终点箭头。
`glow.radius`、`shadow.blur/distance`、`outline.width`、`border_width` 为像素；opacity 为 0–100。
`size_pt` 是点，`rotation` 是度。文字/图片独立支持 rotation。
`box_mode: frame` 使用明确的容器框；默认 ink-fit 会按源图墨迹拟合，不能与 frame 混淆。
若保留 OCR 的 `needs_review: true`，即使页级 review 两项为 true，也不能标记 `verified`。核实原图、修正文案及坐标后再去掉该标记。

照片底图可替换 background 为：

```json
{"kind":"image","file":"clean-background.png","role":"clean-background","contains_text":false,"reviewed":true}
```

文件必须与源图同尺寸，不能与源截图像素一致。reviewed 只记录人工复核事实，不是自动内容审计。此底图是栅格；前景文字/数据/规则框线仍必须原生重建。

## 报告与退出码

- 0：所有单页经真实渲染及结构/清单校验通过，如有合并版则合并后逐页真实渲染也通过。
- 2：至少一个页面需要 measured layout 或视觉复核，继续检查报告。已有 PPT 可打开编辑。
- 1：输入、依赖、裁切、布局、构建或合并失败。其余单页继续运行。

`combined_slide` 给出每张成功输入在合并版中的页号。仅成功生成的单页进入合并；失败与待分层页面保留在报告中。脚本不插入假还原占位页。
