# 常见问题与修复

先看 `batch-report.json` 的 `status` 和每页 `diagnostic`。页级报告的 `error` 保留底层细节，`repair-tasks.json` 给出修复动作。带 `--json` 运行时，整份清单无法读取的错误也会输出到 stdout。

## 环境

| 现象或代码 | 怎么处理 |
| --- | --- |
| `CORE_DEPENDENCY` 或基础转换未就绪 | 用实际执行脚本的同一个 Python 运行 `python -m pip install -r requirements-core.txt`，再运行 `python scripts/preflight.py --plain`。JSON 结果的 `python` 和 `package_details` 会显示解释器、版本和导入错误 |
| `OCR_UNAVAILABLE` | 只需要分块测量和按布局导出时加 `--ocr none`。需要 OCR 时安装 `requirements.txt`，再运行 `python scripts/preflight.py --require-ocr`。若包已安装，查看 JSON 中的导入错误，确认 Python 与本机库的架构匹配 |
| `RENDER_UNAVAILABLE` | 将 LibreOffice/soffice 与 Poppler 的 `pdftoppm` 加入 PATH。重新打开终端后运行 `python scripts/preflight.py --plain --require-render`。也可使用下面的外部复核流程 |
| `RENDER_FAILED` | 已导出的 PPTX 保留为 `needs_review`。查看页报告中的渲染错误，检查预检、输出目录权限和 Office 能否打开文件。修复后用原命令加 `--resume`，或使用外部渲染复核 |
| `ACCESS_DENIED` | 关闭占用目标文件的 PowerPoint/WPS，确认输入可读和输出目录可写。输出路径可换成有权限的独立目录 |

## 清单、坐标和素材

| 现象或代码 | 怎么处理 |
| --- | --- |
| `NO_INPUTS` / `NO_MATCHING_IMAGES` | 核对目录、通配符、扩展名与 `--recursive`。通配符可加引号交给脚本匹配 |
| `MANIFEST_UNREADABLE` | 检查 `--manifest` 文件是否存在及读取权限，命令行中含空格的路径加引号 |
| `MANIFEST_JSON` / `MANIFEST_FORMAT` | 保存为 UTF-8。运行 `python -m json.tool jobs.json` 定位语法错误。顶层使用数组或含 `jobs` 数组的对象。带 BOM 的 UTF-8 可直接读取。参考 [清单示例](../examples/measured-demo/jobs.json) |
| `MANIFEST_ROW` | 报告的 `index` 从 1 开始，底层 `jobs[n]` 从 0 开始。修正原清单该条的 `source`、`layout` 或 `crops`，再用原命令加 `--resume`。其他正常记录会继续处理 |
| `SOURCE_MISSING` / `SOURCE_UNREADABLE` | 查看报告中的完整路径。相对路径以清单所在目录为准。重新获取原附件并确认可以完整打开。损坏文件建议从原始文件重新导出 |
| `SOURCE_MULTIFRAME` | 把 TIFF、动画 WebP 等多帧源图分别导出为单帧图片，按原顺序填入清单 |
| `LAYOUT_UNREADABLE` / `LAYOUT_SIZE` / `LAYOUT_STALE` | 修改 `work-queue.json` 指定的权威布局文件。对照归一化后的 `source.png` 重测尺寸和坐标。源图或透明合成底色改变时重新测量。显式布局修复后可用更新后的原清单重跑 |
| `ASSET_MISSING` 或裁图大小不符 | 补齐 `file` 指向的独立素材，核对 `crops` 与布局文件目录。按原图重裁后使用匹配的 `source_box`。有透明边缘也要保留原裁剪画布，见 [裁图回填](crop-placement.md) |
| `LAYOUT_COORDINATES` | 按提示中的对象名对照源图修改 `box`，连线需核对起点与 `end`。坐标使用源图像素 |
| `LAYOUT_OR_BUILD` | 先定位 `error` 中的对象、字段或素材。提示 1–56 inches 时，当前导出采用 96 px/in，宽高各需在 96–5376 px 内。等比调整源图并重新测量布局 |
| `CANVAS_FORMAT` | 指定合并尺寸时使用 `--canvas 1920x1080` 这类正整数宽高，或省略参数让脚本使用首个成功导出页的尺寸 |
| `MERGE_FAILED` | 从单页文件核对已导出的页，查看 `merge_error` 和 `merge.log`。校正画布或输出权限后用 `--resume` 重试 |

## 已生成什么

| 状态 | 当前产物和下一步 |
| --- | --- |
| `needs_layout` | 只有源图、放大检查块与布局草稿。技能按 `work-queue.json` 完成测量，再运行 `--resume` |
| `needs_review` | 已有可编辑 PPTX。核对结构、字体、局部差异和真实渲染。几何预览可辅助定位 |
| `partial_failure` | 按原编号检查失败页并修复。默认需所有页导出后才生成合并版，单页成品可在各自目录打开 |
| `verified` | 结构与真实渲染门槛已通过。交付前打开并排图目视核对文字、细线、素材边缘及页序 |

修复一页后保持同一输出目录和完整输入顺序。修改显式布局时编辑原 `layout` 路径。临时草稿 `layout.draft.json` 只供参考。详细参数见 [命令与续跑](cli.md)。

## 真实渲染和字体

**换了电脑后中文偏移或变成方框。** 在运行环境和查看成品的电脑安装同一款支持相应中文字符的字体。缺少原字体时，选择覆盖原字符的字体并重测行宽、字号、基线和行距。字体解析与混排字段见 [字体校准](precision-v140.md)。

**没有 LibreOffice，但能在 PowerPoint 或 WPS 打开。** 用 Office 导出最终 PPTX 对应页为 PNG。将源图、渲染图、布局、PPTX 一起传给复核脚本，再打开并排图确认。

```bash
python scripts/qa_external_render.py examples/measured-demo/source.png examples/measured-demo/rendered.png examples/measured-demo/layout.json examples/measured-demo/editable-demo.pptx -o external-check
```

以上可用随包的原图和实测渲染验证命令。处理自己的资料时，把四个路径换成同一页的文件，并对合并版逐页复核。只有 Pillow 时可继续导出与排查几何，成品标记待真实渲染。

## 容易返工的做法

| 做法 | 处理方式 |
| --- | --- |
| 整页截图作底图，上面只放文字或用多个切片铺满 | 分离照片，重建边框、文字、图标、表格和箭头。放大检查干净底图及前景移开后的原位置 |
| 按 OCR 的最高置信候选直接确认人名和数字 | 逐块回看原图，核对文字、单位、换行，处理 `alternatives` 和 `needs_review` |
| 全页 RMS 较低就放过局部错误 | 检查 `comparison.regions` 和 `tile_alerts.worst`，定位漏字、短线、偏位和图片边缘后再渲染 |
| 混尺寸批量靠拉伸填满画布或先删失败页 | 保持等比留边和完整输入顺序。要求单页原比例时查看独立 PPTX |
| 用旧版透明前景验收套复杂照片页 | 复杂页使用 [对象清单和照片底图校验](visual-decomposition.md)。透明前景专用脚本见 [旧版路线](reconstruction-and-qa.md) |
