> 此页用于旧版透明前景与 Artifact Tool 路线。常规批量与照片底图走 [主流程](../SKILL.md) 和 [复杂页面](complex-pages.md)。

# Artifact Tool 工作流

## 运行时准备

遵循 Presentations 技能的 `references/implementation.md`：使用随运行时提供的 Node、模块目录和 Python；在可写的临时构建目录创建 `node_modules` 软链接。将构建器复制到该临时目录后再执行，否则 ES modules 可能无法从脚本位置解析 `@oai/artifact-tool`。开始首次创建前，只运行一次 `mark_artifact_operation_started.mjs`。

构建器使用 JavaScript ES modules，并从 `@oai/artifact-tool` 导入：

```js
import { Presentation, PresentationFile } from "@oai/artifact-tool";
```

构建链路只使用 Presentations 技能指定的官方运行时和 Artifact Tool。

## 像素映射

若源图为 `1600 × 900`，可直接创建相同数值的画布：

```js
const presentation = Presentation.create({
  slideSize: { width: 1600, height: 900 },
});
```

这样源图坐标可以直接用于 `left/top/width/height`。如果使用其他页面尺寸，必须只使用一个统一比例映射器，不能分别缩放横纵坐标。

## 图层顺序

按下列顺序添加对象，避免层级混乱：

1. 页面背景和大面积装饰
2. 面板、卡片、分区底色
3. 分隔线、进度条、箭头和简单符号
4. 已物理裁剪的复杂图标、Logo 或照片
5. 标题、标签、数值、单位和脚注

源图中的规则信息图元素可用原生对象重建，以满足用户明确要求的可编辑性。不要为普通新演示文稿复制数据看板风格。

## 原生文本

把文本框封装成统一函数，明确设置字体、字号、颜色、字重和自动适配策略。函数在创建对象前必须调用 `scripts/text_box_budget.mjs`，阻止明显过窄或过矮的固定文本框：

```js
import { pathToFileURL } from "node:url";

const { assertTextBoxBudget } = await import(pathToFileURL(
  path.join(RECONSTRUCTION_SKILL_DIR, "scripts/text_box_budget.mjs"),
).href);

function addText(slide, value, position, style = {}) {
  const insets = style.insets ?? { top: 0, right: 0, bottom: 0, left: 0 };
  assertTextBoxBudget(value, position, style.fontSize ?? 24, {
    bold: style.bold ?? false,
    wrap: style.wrap ?? false,
    insets,
  });
  const box = slide.shapes.add({
    geometry: "textbox",
    position,
    fill: "none",
    line: { fill: "none", width: 0 },
  });
  box.text = value;
  box.text.style = {
    typeface: style.typeface,
    fontSize: style.fontSize ?? 24,
    bold: style.bold ?? false,
    color: style.color ?? "#123456",
    autoFit: "none",
    wrap: style.wrap ? "square" : "none",
    insets,
  };
  return box;
}
```

对每个文本框留出比源图墨迹框更大的渲染安全区。不要依赖默认字体、默认行距或导出后的自动缩小文字。数值与单位、标题与副标题分别建框，避免混合字号导致基线与截断问题。

源图中的标题若有渐变、描边或发光效果，读取 Presentations 的 `artifact_tool_docs/api/references/rich-text.spec.md` 与 `fill.spec.md`，使用 `shape.text.fill`、`shape.text.outline` 和原生文本叠层重建，不能直接降级成单色普通文字。

## 原生形状

使用 `rect`、`roundRect`、`line` 等几何体重建规则容器、分隔线和进度条。每个数据条至少拆成背景轨道与前景数值条两个对象。只有用户明确要求保留编辑能力的视觉编码，才用原生对象重建。

## 独立图片

复杂图标必须先生成独立文件：

```bash
python scripts/crop_assets.py source.png --x 48 --y 366 --w 55 --h 72 --pad 2 --transparent --bg auto --tolerance 30 --out crops/icon-01.png
```

然后使用 Artifact Tool 的图片 API 以 `contain` 方式放置：

```js
// 从 scripts/source_placement.mjs 导入 sourcePlacement。
const cropMetadata = JSON.parse(await fs.readFile("crops/icon-01.png.json", "utf8"));
const bytes = await fs.readFile("crops/icon-01.png");
const icon = slide.images.add({
  blob: new Uint8Array(bytes),
  contentType: "image/png",
  alt: "water icon",
  fit: "contain",
  position: sourcePlacement(cropMetadata.source_box, cropMetadata.source_size, [1600, 900]),
});
icon.lockAspectRatio = true;
```

图片对象的宽高应保持素材纵横比，并设置纵横比锁定。禁止仅通过源图内部裁剪坐标模拟独立素材，因为那仍会把整张源图嵌入文件。

开始构建前必须按 [背景移除流程](background-removal.md) 生成透明前景参考图。复杂背景不重新作为大图嵌入；页面底层使用透明或简单原生底色。原图和整张透明前景图都加入结构检查的禁止图片指纹。

## 禁止假拆分

图片对象只允许承载一个真正独立的 `icon`、`logo`、`illustration` 或 `photo`。以下内容无论是否去掉外部背景，都必须原生重建，不能作为图片：

- 卡片、面板、横条、整行、整列和页面分区
- 标题、标签、数字、单位和正文
- 图表、进度条、表格和流程节点
- 同时包含多个图标或“图标 + 文字”的组合裁片

每个批准素材都必须进入 `assets-manifest.json` 并通过 `audit_asset_manifest.py`。素材像素尺寸必须等于清单中的 `source_box` 尺寸；可见 RGB 必须逐像素来自该源区域，alpha 只能减少、不能凭空新增。联系表中出现矩形底色、相邻文字、多个主体、卡片边框或图表时，删除素材并改为原生对象。

## 字体策略

先用 Presentations 技能提供的字体解析工具确认可用字体。若源图字体无法获得，按以下顺序选择：

1. 同字形类别、同语言覆盖范围的已安装字体
2. 通过字重、字号、字距和文本框宽度补偿
3. 重新渲染并逐项修正换行和基线

finalizer 的 `fontPolicy` 必须反映字体来源：源文档用 `reference`，用户指定用 `user_request`，自行选择用 `design`。

## 最终导出

构建器输出候选 PPTX。随后使用 Presentations finalizer 写入新的最终文件，并要求：

- 页数和页面尺寸正确
- Artifact Tool 可重新导入
- 字体策略通过
- 页面几何检查通过
- 验收报告位于私有暂存目录

之后只对最终文件运行 `scripts/verify_reconstruction.py`。该命令任一阶段失败时，回到构建器修正并重新 finalizer 到新的文件名；不能只运行宽松的 `validate_structure.py` 后交付。

## 共同验收要求

本路线同样必须遵循 [非文字对象拆分与验收](visual-decomposition.md)。保留源图视觉清单并在最终 PPTX 上运行 `visual_inventory.py`，历史结构检查不能替代它。纯背景修复与独立照片的合理像素修复以当前主技能为准，不受历史透明前景逐像素约束。

```bash
python scripts/visual_inventory.py final.pptx layout.json --source source.png
```

该命令检查清单映射和背景残留诊断。仍须执行实际渲染及逐区目视检查。
