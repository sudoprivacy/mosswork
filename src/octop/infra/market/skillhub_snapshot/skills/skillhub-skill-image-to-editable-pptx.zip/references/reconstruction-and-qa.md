> 此页用于旧版透明前景与 Artifact Tool 路线。常规批量与照片底图走 [主流程](../SKILL.md) 和 [复杂页面](complex-pages.md)。

# 重建与验收规范

## 元素映射

| 源图内容 | PPT 元素 | 关键验证 |
|---|---|---|
| 标题、标签、数字、单位、脚注 | 原生文本框 | 可编辑、内容准确、字体和换行匹配 |
| 面板、卡片、底色、边框 | 原生形状 | 位置、尺寸、圆角、透明度和层级 |
| 分隔线、进度条、简单箭头 | 原生形状 | 长度、粗细、颜色和端点 |
| 复杂图标、Logo | 独立裁图文件 | 单对象、等比、无切边、无旁边文字 |
| 照片或复杂插画 | 独立图片 | 经批准、等比、裁切符合源图 |

## 截图块防护

禁止以下做法：

- 源图作为背景或大图覆盖页面
- 把带有文字的数据卡裁成图片
- 把页面切成多张小图，以规避单图面积限制
- 将整张源图嵌入 PPTX，再用内部裁剪框显示其中一小块

所有批准图片应位于单独的素材目录。结构检查同时比较图片解码后的像素指纹，不能只依赖文件名或压缩字节。

## 严格结构检查

示例：

```bash
python scripts/validate_structure.py output.pptx \
  --strict-reconstruction \
  --min-text-objects 40 \
  --required-text-file expected-text.json \
  --expected-picture-count 8 \
  --max-picture-area-ratio 0.15 \
  --max-total-picture-area-ratio 0.30 \
  --max-aspect-drift 0.001 \
  --require-aspect-lock \
  --forbid-groups \
  --forbid-source-image source.png \
  --forbid-source-image source-foreground.png \
  --approved-image-dir crops \
  --require-all-approved-images \
  --json
```

参数应根据源图元素清单设置。`expected-text.json` 每一项对应一个独立文本对象；同一个文本框不能同时满足两项。重复文本可声明次数和页码：

```json
[
  {"text": "2026财年", "count": 2, "slide": 1},
  {"text": "357.52", "slide": 1},
  "能源管理月度用量数据展示"
]
```

`--expected-picture-count` 应等于清单中确实需要保留的独立复杂视觉对象数量。

结构检查必须确认：

- 具备足够的可编辑文本对象
- 必需文字清单没有缺项
- 图片对象数与元素清单精确一致
- 每个图片关系都指向批准的独立素材
- 每个批准素材都至少使用一次
- 没有大面积截图块
- 没有源图像素指纹
- 没有图片填充、外链图片或未批准媒体载荷
- 图片显示比例未漂移
- 图片对象设置了纵横比锁定
- 单图和图片累计显示面积均未超过门槛
- 所有可见对象位于页面边界内
- 没有分组对象；保持元素独立，避免组坐标变换绕过边界检查

批准素材目录不是自动受信任。必须先运行 `audit_asset_manifest.py`，检查角色、源图区域面积、透明像素、平滑边缘、裁剪边距、单主体声明以及是否包含文字。再人工检查输出的透明底联系表：只含一个视觉对象、没有文字、卡片背景、图表或相邻主体。不要把页面切片放入批准目录。

不要把不带参数运行 `validate_structure.py` 的 `pass` 当作最终验收。只有 `--strict-reconstruction` 会要求源图指纹、必需文字、精确图片数量、比例锁定、禁止分组和批准素材全部到位。最终交付应调用总验收命令，而不是手工拼接部分检查。

## 最终渲染流程

1. 用 Presentations finalizer 生成新的最终文件。
2. 运行总验收命令：

```bash
python scripts/verify_reconstruction.py source.png final.pptx \
  --foreground-source source-foreground.png \
  --output-dir verify \
  --presentation-skill-dir "$PRESENTATIONS_SKILL_DIR" \
  --required-text-file expected-text.json \
  --approved-image-dir crops \
  --asset-manifest assets-manifest.json \
  --expected-picture-count 8 \
  --min-text-objects 40 \
  --max-rms 0.12 \
  --json
```

3. 检查 `background-removal/preview-dark.png`、`preview-light.png`、`preview-magenta.png` 与 `assets-contact-sheet.png`，确保背景透明、边缘干净且没有假拆分。
4. 检查 `visual-diff/side_by_side.png` 和 `visual-diff/difference.png`。RMS 是硬门槛，但不能替代逐项视觉判断。优先修正页面比例、整体坐标和字体，再修正局部颜色、描边和装饰。
5. 背景/素材审计、`slides_test.py`、视觉 RMS、渲染尺寸宽高比或结构配置任一失败，均视为失败。
6. 如有修复，重新导出候选文件，finalizer 到新的最终文件，再完整重复检查。
7. 最后抽查对象选择和编辑行为。

## 完成条件

只有同时满足以下条件才可交付：

- 文字和数据已逐项核对
- 原生对象与独立素材的划分符合元素清单
- finalizer 成功
- 结构检查成功
- 所有页面完成真实渲染和视觉复核
- 总验收 JSON 的 `background_removal`、`asset_integrity`、`structure`、`overflow`、`render`、`visual` 六个阶段均为 `pass`
- PowerPoint 中的对象可按预期单独选择和编辑

自动检查用于发现结构风险，不能代替人工视觉判断。
