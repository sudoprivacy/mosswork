import copy
import sys
from pathlib import Path
import pytest
from PIL import Image
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
from visual_inventory import audit_visual_inventory, audit_backdrop_removal
from batch_convert import structure_check


def layout():
    return {'source_size':[200,100], 'review':{'visual_inventory_verified':True},
        'shapes':[{'name':'icon-a'}], 'images':[{'name':'photo-a'}],
        'visual_inventory':[
            {'id':'i','kind':'icon','source_box':[10,10,20,20],'treatment':'native','objects':['icon-a'],'reviewed':True},
            {'id':'p','kind':'photo','source_box':[50,10,40,30],'treatment':'raster','objects':['photo-a'],'reviewed':True}]}


def test_text_only_bg_not_accepted():
    old={'source_size':[200,100], 'texts':[{'name':'title','text':'x'}],
         'background':{'kind':'image','contains_text':False,'reviewed':True},
         'review':{'inventory_complete':True,'text_verified':True}}
    assert audit_visual_inventory(old)['status']=='fail'


def test_independent_photo_and_native_icon():
    assert audit_visual_inventory(layout())['status']=='pass'


@pytest.mark.parametrize('mutation', ['omit','shared','raster','background','duplicate','unmapped'])
def test_invalid_decomposition(mutation):
    data=layout()
    if mutation=='omit':data['images']=[]
    if mutation=='shared':data['visual_inventory'][1]['objects']=['icon-a']
    if mutation=='raster':data['visual_inventory'][0]['treatment']='raster'
    if mutation=='background':data['background']={'kind':'image'}
    if mutation=='duplicate':data['shapes'].append({'name':'icon-a'})
    if mutation=='unmapped':data['shapes'].append({'name':'stray'})
    assert audit_visual_inventory(data)['status']=='fail'


def test_unchanged_icon_in_text_removed_backdrop_rejected(tmp_path):
    source=Image.new('RGB',(200,100),'navy');source.paste('red',(10,10,30,30));source.paste('green',(50,10,90,40));source.save(tmp_path/'src.png')
    bg=source.copy();bg.paste('white',(100,50,180,80));bg.save(tmp_path/'bg.png')
    data=layout();data['background']={'kind':'image','file':'bg.png','visual_objects_removed':True}
    with pytest.raises(ValueError,match='retains source visual object: i'):
        audit_backdrop_removal(data,tmp_path/'src.png',tmp_path)
    Image.new('RGB',(200,100),'navy').save(tmp_path/'bg.png')
    audit_backdrop_removal(data,tmp_path/'src.png',tmp_path)


def test_exported_raster_disguised_as_native_rejected(tmp_path):
    Image.new('RGB',(20,20),'red').save(tmp_path/'icon.png')
    prs=Presentation();page=prs.slides.add_slide(prs.slide_layouts[6])
    sp=page.shapes.add_picture(str(tmp_path/'icon.png'),0,0);sp.name='icon-a'
    photo=page.shapes.add_picture(str(tmp_path/'icon.png'),0,0);photo.name='photo-a'
    assert audit_visual_inventory(layout(),page)['status']=='fail'


def test_text_only_can_be_verified_after_explicit_source_review():
    assert audit_visual_inventory({'source_size':[200,100], 'review':{'visual_inventory_verified':True,'no_visual_objects':True},'visual_inventory':[]})['status']=='pass'


def test_exported_decomposition_and_missing_picture(tmp_path):
    import json
    from types import SimpleNamespace
    from build_pptx_from_layout import build
    Image.new('RGB', (200,100), 'navy').save(tmp_path/'src.png')
    Image.new('RGB', (40,30), 'green').save(tmp_path/'photo.png')
    data=layout()
    data['background']={'kind':'solid','fill':'#000080'}
    data['shapes']=[{'name':'icon-a','type':'polygon','box':[10,10,20,20],
        'points':[[0,20],[10,0],[20,20]],'fill':'#FFFFFF'}]
    data['images']=[{'name':'photo-a','file':'photo.png','box':[50,10,40,30],
                    'source_box':[50,10,40,30]}]
    (tmp_path/'layout.json').write_text(json.dumps(data))
    build(SimpleNamespace(source=str(tmp_path/'src.png'),layout=str(tmp_path/'layout.json'),
        crops=str(tmp_path),out=str(tmp_path/'out.pptx'),font_name='Arial',strict_assets=True,
        no_bg_blank=True,bg_blank_alpha=0))
    assert structure_check(tmp_path/'out.pptx',data)['status']=='pass'
    prs=Presentation(tmp_path/'out.pptx')
    page=prs.slides[0]
    assert sum(s.shape_type==13 for s in page.shapes)==1
    photo=next(s for s in page.shapes if s.name=='photo-a')
    photo._element.getparent().remove(photo._element)
    prs.save(tmp_path/'broken.pptx')
    assert structure_check(tmp_path/'broken.pptx',data)['status']=='fail'
