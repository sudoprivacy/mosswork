#!/usr/bin/env python3
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "compare_images.py"


def run(reference, rendered, output_dir, *args):
    result = subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            str(reference),
            str(rendered),
            "--output-dir",
            str(output_dir),
            "--json",
            *args,
        ],
        text=True,
        capture_output=True,
        check=False,
    )
    return result.returncode, json.loads(result.stdout)


def test_identical_images_pass_and_write_diagnostics():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        reference = root / "reference.png"
        rendered = root / "rendered.png"
        Image.new("RGB", (8, 6), "#2679B9").save(reference)
        Image.new("RGB", (8, 6), "#2679B9").save(rendered)
        out = root / "compare"
        code, payload = run(reference, rendered, out, "--max-rms", "0")
        assert code == 0, payload
        assert payload["rms_diff"] == 0
        assert (out / "side_by_side.png").exists()
        assert (out / "difference.png").exists()


def test_visible_difference_fails_threshold():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        reference = root / "reference.png"
        rendered = root / "rendered.png"
        Image.new("RGB", (8, 6), "#000000").save(reference)
        Image.new("RGB", (8, 6), "#FFFFFF").save(rendered)
        code, payload = run(reference, rendered, root / "compare", "--max-rms", "0.12")
        assert code == 1
        assert payload["status"] == "fail"
        assert payload["rms_diff"] == 1


def test_near_aspect_size_mismatch_is_normalized():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        reference = root / "reference.png"
        rendered = root / "rendered.png"
        Image.new("RGB", (1600, 900), "#000000").save(reference)
        Image.new("RGB", (1667, 938), "#000000").save(rendered)
        code, payload = run(reference, rendered, root / "compare")
        assert code == 0, payload
        assert payload["status"] == "pass"
        assert payload["render_resampled"] is True


def test_material_aspect_mismatch_is_an_error():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        reference = root / "reference.png"
        rendered = root / "rendered.png"
        Image.new("RGB", (16, 9), "#000000").save(reference)
        Image.new("RGB", (4, 3), "#000000").save(rendered)
        code, payload = run(reference, rendered, root / "compare")
        assert code == 2
        assert payload["status"] == "error"


def test_strict_size_mode_preserves_exact_size_gate():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        reference = root / "reference.png"
        rendered = root / "rendered.png"
        Image.new("RGB", (16, 9), "#000000").save(reference)
        Image.new("RGB", (32, 18), "#000000").save(rendered)
        code, payload = run(reference, rendered, root / "compare", "--size-mode", "strict")
        assert code == 2
        assert payload["status"] == "error"


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} image comparison tests")
