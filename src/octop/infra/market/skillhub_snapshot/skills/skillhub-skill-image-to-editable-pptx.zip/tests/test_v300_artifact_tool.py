"""Skill package contract tests updated for the v1.1.0 batch/layered contract."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _skill():
    return (ROOT / "SKILL.md").read_text(encoding="utf-8")


def test_runtime_version_matches_documented_release():
    import sys
    sys.path.insert(0, str(ROOT / "scripts"))
    from batch_convert import VERSION
    assert VERSION in _skill()


def test_skill_routes_batch_and_complex_pages():
    skill = _skill()
    for required in ("batch_convert.py", "layered", "python-pptx", "needs_layout", "needs_review", "verified"):
        assert required in skill
    assert "不再强制整图去背景" in skill
    assert "不能验证 Office" in skill


def test_legacy_chain_remains_documented():
    skill = _skill()
    for tool in ("describe_image.py", "build_pptx_from_layout.py", "orchestrate.py", "render_offscreen.py"):
        assert tool in skill
    assert (ROOT / "references" / "layout-schema.md").is_file()
    assert (ROOT / "references" / "layout-schema-v110.md").is_file()


def test_skill_has_ui_metadata_and_artifact_tool_reference():
    for rel in ("agents/openai.yaml",
                "references/artifact-tool-workflow.md",
                "examples/editable-dashboard-artifact-tool.mjs"):
        assert (ROOT / rel).is_file(), f"缺少 {rel}"


def test_all_referenced_local_scripts_exist():
    """SKILL.md 提到的 `scripts/xxx.py|mjs` 必须真的在包内。"""
    import re
    skill = _skill()
    refs = set(re.findall(r"scripts/([A-Za-z0-9_\-]+\.(?:py|mjs))", skill))
    missing = [r for r in sorted(refs) if not (ROOT / "scripts" / r).is_file()]
    assert not missing, f"SKILL.md 引用了不存在的脚本：{missing}"


def test_every_shipped_script_is_reachable():
    """scripts/ 下的脚本必须至少被 SKILL.md / references / examples / 其它脚本
    提到一次，否则就是死代码（`_` 前缀的私有模块除外）。"""
    def read(p):
        return p.read_text(encoding="utf-8")

    doc_blob = "\n".join(
        [read(ROOT / "SKILL.md")]
        + [read(p) for p in sorted((ROOT / "references").glob("*.md"))]
        + [read(p) for p in sorted((ROOT / "examples").glob("*.mjs"))]
    )
    script_texts = {p.name: read(p) for p in sorted((ROOT / "scripts").iterdir())
                    if p.suffix in (".py", ".mjs")}

    orphans = []
    for name, text in script_texts.items():
        stem = Path(name).stem
        # 其它脚本里的引用（排除自身文件）
        others = "\n".join(t for n, t in script_texts.items() if n != name)
        if stem in doc_blob or stem in others:
            continue
        orphans.append(name)
    assert not orphans, f"孤立脚本（未被任何文档/代码引用）：{orphans}"


def test_obsolete_build_engines_are_not_shipped():
    obsolete = [
        ROOT / "scripts" / "build_ppt.py",
        ROOT / "scripts" / "create_hf_project.py",
        ROOT / "engines" / "pptxgenjs",
        ROOT / "references" / "high-fidelity-pptxgenjs.md",
    ]
    assert not [str(path.relative_to(ROOT)) for path in obsolete if path.exists()]


def test_no_vendored_dependencies_are_shipped():
    """不允许把 node_modules / 打包缓存塞进技能包。
    （`__pycache__` 由测试运行自身产生，不在此断言范围内——打包脚本负责清理。）"""
    junk = [p for p in ROOT.rglob("node_modules")]
    junk += [p for p in ROOT.rglob("*.egg-info")]
    junk += [p for p in ROOT.rglob(".DS_Store")]
    assert not junk, f"包内混入构建产物：{[str(p.relative_to(ROOT)) for p in junk]}"


if __name__ == "__main__":
    tests = [n for n in sorted(globals()) if n.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} skill contract checks")
