"""describe_image.py 的单元测试（无外部依赖，纯函数 + 合成图）。"""
import os
import sys
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import numpy as np
from PIL import Image

import describe_image as DI


def _toy_image(tmp):
    """造一张 600x400 测试图：白底 + 红色方块 + 蓝色横条。"""
    arr = np.full((400, 600, 3), 255, dtype=np.uint8)
    arr[40:120, 40:120] = [220, 30, 30]      # 红方块（图标候选）
    arr[200:230, 40:560] = [30, 60, 220]     # 蓝色横条（应被过滤：太扁）
    Image.fromarray(arr).save(tmp)


class TestDescribe(unittest.TestCase):

    def test_detect_icons_picks_red_square(self):
        path = os.path.join(self._tmp, "toy.png")
        _toy_image(path)
        img = Image.open(path)
        icons = DI.detect_icons(img, min_area=100, max_area=20000)
        # 至少应该挑到红色方块
        self.assertTrue(any(ic["role"] == "icon" for ic in icons),
                        f"未检出图标：{icons}")
        # 蓝色横条太扁，应被排除
        widths = [ic["box"][2] for ic in icons]
        heights = [ic["box"][3] for ic in icons]
        for w, h in zip(widths, heights):
            self.assertLess(max(w, h) / min(w, h), 6,
                            f"过扁的色块不应入选：{w}x{h}")

    def test_merge_regions_groups_same_row(self):
        texts = [{"text": "A", "box": [10, 10, 20, 20]},
                 {"text": "B", "box": [40, 12, 20, 20]},
                 {"text": "C", "box": [10, 100, 20, 20]}]
        regions = DI.merge_regions(texts, [], [], 200)
        # A 和 B 在同一行 → region 0；C 单独一行 → region 1
        self.assertEqual(len(regions), 2)
        self.assertIn("text:0", regions[0]["contains"])
        self.assertIn("text:1", regions[0]["contains"])
        self.assertIn("text:2", regions[1]["contains"])

    def test_detect_shapes_picks_rect_and_hollow(self):
        path = os.path.join(self._tmp, "toy_shapes.png")
        arr = np.full((400, 600, 3), 255, dtype=np.uint8)
        arr[40:200, 40:200] = [40, 80, 200]      # 蓝色实心矩形
        # 橙色描边框：(x=300..550, y=300..380)
        arr[300:304, 300:550] = [200, 100, 0]
        arr[376:380, 300:550] = [200, 100, 0]
        arr[300:380, 300:304] = [200, 100, 0]
        arr[300:380, 546:550] = [200, 100, 0]
        Image.fromarray(arr).save(path)
        img = Image.open(path)
        shapes = DI.detect_shapes(img, palette_k=4)
        # 至少应该有一个实心矩形 + 一个空心矩形
        self.assertTrue(len(shapes) >= 1, f"未检出形状：{shapes}")
        # 看是否有空心矩形（fill=#FFFFFF, border 非空）
        hollow = [s for s in shapes if s.get("border") and s.get("fill") == "#FFFFFF"]
        self.assertTrue(len(hollow) >= 1,
                        f"未识别出空心矩形：{shapes}")

    def setUp(self):
        self._tmp = os.path.join(os.path.dirname(__file__), "_tmp_describe")
        os.makedirs(self._tmp, exist_ok=True)


if __name__ == "__main__":
    unittest.main()