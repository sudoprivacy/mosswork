#!/usr/bin/env python3
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "audit_icons.py"


def make_icon(path):
    image = Image.new("RGBA", (20, 20), (0, 0, 0, 0))
    ImageDraw.Draw(image).rectangle((4, 6, 15, 13), fill=(20, 120, 220, 255))
    image.save(path)


def run(asset_dir, *args):
    return subprocess.run(
        [sys.executable, str(SCRIPT), str(asset_dir), *args],
        text=True,
        capture_output=True,
        check=False,
    )


def test_manifest_coverage_can_be_required():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        make_icon(root / "icon.png")
        result = run(root, "--require-manifest-coverage")
        assert result.returncode == 1
        assert "missing manifest aspect" in result.stdout


def test_complete_aspect_manifest_passes():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        make_icon(root / "icon.png")
        manifest = root / "icons-manifest.json"
        manifest.write_text(
            json.dumps([{"name": "icon.png", "visible_aspect_ratio": 1.5}]),
            encoding="utf-8",
        )
        result = run(
            root,
            "--manifest",
            str(manifest),
            "--require-manifest-coverage",
            "--max-aspect-drift",
            "0",
        )
        assert result.returncode == 0, result.stdout + result.stderr


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} icon audit tests")
