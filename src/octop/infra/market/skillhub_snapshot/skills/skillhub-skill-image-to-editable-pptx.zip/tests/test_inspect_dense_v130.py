"""Review tiles preserve coordinates and cover edges with no OCR dependency."""
import tempfile
import unittest
from pathlib import Path
import sys

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from inspect_dense import make_tiles


class DenseReviewTests(unittest.TestCase):
    def test_complete_coverage_and_pixel_mapping(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            image = Image.new('RGB', (1452, 821), '#102050')
            image.putpixel((1451, 820), (255, 250, 0))
            image.save(folder / 'source.png')
            data = make_tiles(folder / 'source.png', folder / 'tiles')
            self.assertEqual(data['source_size'], [1452, 821])
            self.assertTrue((folder / 'tiles/index.png').is_file())
            last = data['tiles'][-1]
            self.assertEqual(last['box'][0] + last['box'][2], 1452)
            self.assertEqual(last['box'][1] + last['box'][3], 821)
            with Image.open(folder / 'tiles' / last['file']) as tile:
                self.assertEqual(tile.getpixel((tile.width - 1, tile.height - 1)), (255, 250, 0))


if __name__ == '__main__':
    unittest.main()
