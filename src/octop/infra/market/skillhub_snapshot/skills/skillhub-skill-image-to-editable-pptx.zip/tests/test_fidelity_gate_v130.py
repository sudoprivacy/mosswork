"""Regression checks for errors hidden by an unchanged slide background."""
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from batch_convert import check_clean_background, compare_render
from fidelity_gate import assess


class FidelityGateTests(unittest.TestCase):
    def test_missing_small_label_fails_with_loose_global_rms(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            src = Image.new('RGB', (800, 450), 'white')
            ImageDraw.Draw(src).rectangle((31, 30, 70, 42), fill='black')
            src.save(folder / 'source.png')
            Image.new('RGB', src.size, 'white').save(folder / 'rendered.png')
            layout = {'texts': [{'name': 'small label', 'box': [25, 25, 50, 24]}]}
            result = compare_render(folder / 'source.png', folder / 'rendered.png', folder, layout)
            self.assertLess(result['rms'], .15)
            self.assertGreater(result['tile_alerts']['count'], 0)
            self.assertTrue(any('small label' in issue for issue in assess(result, .15)))

    def test_omitted_unlisted_label_is_caught_by_tiles(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            src = Image.new('RGB', (800, 450), 'white')
            ImageDraw.Draw(src).rectangle((330, 180, 380, 198), fill='black')
            src.save(folder / 'source.png')
            Image.new('RGB', src.size, 'white').save(folder / 'rendered.png')
            result = compare_render(folder / 'source.png', folder / 'rendered.png', folder, {})
            self.assertLess(result['rms'], .15)
            self.assertTrue(any('local tiles' in issue for issue in assess(result, .15)))

    def test_clean_background_cannot_keep_original_text_pixels(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            src = Image.new('RGB', (160, 90), '#eeeeee')
            ImageDraw.Draw(src).rectangle((12, 15, 90, 30), fill='black')
            src.save(folder / 'source.png')
            clone = src.copy()
            ImageDraw.Draw(clone).rectangle((110, 60, 130, 75), fill='blue')
            clone.save(folder / 'background.png')
            layout = {'background': {'kind': 'image', 'file': str(folder / 'background.png')},
                      'texts': [{'name': 'title', 'box': [10, 10, 90, 30]}]}
            with self.assertRaisesRegex(ValueError, 'title'):
                check_clean_background(layout, folder / 'source.png')
            ImageDraw.Draw(clone).rectangle((12, 15, 90, 30), fill='#eeeeee')
            clone.save(folder / 'background.png')
            check_clean_background(layout, folder / 'source.png')


if __name__ == '__main__':
    unittest.main()
