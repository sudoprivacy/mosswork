#!/usr/bin/env python3
import json
import subprocess
import sys
import tempfile
import zipfile
from io import BytesIO
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = ROOT / "scripts" / "validate_structure.py"
NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
PNS = "http://schemas.openxmlformats.org/presentationml/2006/main"


def png_bytes(size=(1, 1), color=(12, 120, 200, 255)):
    buffer = BytesIO()
    Image.new("RGBA", size, color).save(buffer, format="PNG")
    return buffer.getvalue()


def make_deck(
    path: Path,
    *,
    picture_box=None,
    text="可编辑文字",
    media=None,
    as_shape_fill=False,
    lock_aspect=False,
    extra_media=None,
    absolute_target=False,
    include_group=False,
    picture_descr="",
):
    cx, cy = 9_144_000, 5_143_500
    text_xml = ""
    if text is not None:
        text_xml = f"""
        <p:sp><p:nvSpPr><p:cNvPr id="2" name="editable_text"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
        <p:spPr><a:xfrm><a:off x="100000" y="100000"/><a:ext cx="2000000" cy="400000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>
        <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:t>{text}</a:t></a:r></a:p></p:txBody></p:sp>"""
    picture_xml = ""
    if picture_box and as_shape_fill:
        x, y, w, h = picture_box
        picture_xml = f"""
        <p:sp><p:nvSpPr><p:cNvPr id="3" name="image_fill"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>
        <p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>
        <a:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></a:blipFill>
        <a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:sp>"""
    elif picture_box:
        x, y, w, h = picture_box
        locks = '<a:picLocks noChangeAspect="1"/>' if lock_aspect else ""
        picture_xml = f"""
        <p:pic><p:nvPicPr><p:cNvPr id="3" name="picture" descr="{picture_descr}"/><p:cNvPicPr>{locks}</p:cNvPicPr><p:nvPr/></p:nvPicPr>
        <p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>
        <p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>"""
    group_xml = ""
    if include_group:
        group_xml = """<p:grpSp><p:nvGrpSpPr><p:cNvPr id="9" name="group"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:grpSp>"""
    slide_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <p:sld xmlns:a="{NS}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="{PNS}">
      <p:cSld><p:spTree><p:nvGrpSpPr/><p:grpSpPr/>{text_xml}{picture_xml}{group_xml}</p:spTree></p:cSld>
    </p:sld>"""
    presentation_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <p:presentation xmlns:a="{NS}" xmlns:p="{PNS}"><p:sldSz cx="{cx}" cy="{cy}"/></p:presentation>"""
    with zipfile.ZipFile(path, "w") as deck:
        deck.writestr("ppt/presentation.xml", presentation_xml)
        deck.writestr("ppt/slides/slide1.xml", slide_xml)
        if picture_box:
            target = "/ppt/media/image1.png" if absolute_target else "../media/image1.png"
            relationships = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
              <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="{target}"/>
            </Relationships>"""
            deck.writestr("ppt/slides/_rels/slide1.xml.rels", relationships)
            deck.writestr("ppt/media/image1.png", media or png_bytes())
        if extra_media:
            deck.writestr("ppt/media/unused-source.png", extra_media)


def run_validator(deck: Path, *args):
    result = subprocess.run(
        [sys.executable, str(VALIDATOR), str(deck), "--json", *args],
        text=True,
        capture_output=True,
        check=False,
    )
    payload = json.loads(result.stdout)
    return result.returncode, payload


def test_passes_editable_text_and_small_in_bounds_picture():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "pass.pptx"
        make_deck(deck, picture_box=(100000, 700000, 600000, 600000))
        code, payload = run_validator(deck, "--min-text-objects", "1", "--min-picture-count", "1")
        assert code == 0, payload
        assert payload["status"] == "pass"


def test_rejects_large_source_slab_and_out_of_bounds_object():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "fail.pptx"
        make_deck(deck, picture_box=(-1000, 0, 9_144_000, 5_143_500))
        code, payload = run_validator(deck, "--max-picture-area-ratio", "0.15")
        kinds = {finding["kind"] for finding in payload["findings"]}
        assert code == 1
        assert "large_picture" in kinds
        assert "object_outside_slide" in kinds


def test_rejects_missing_editable_text_objects():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "missing-text.pptx"
        make_deck(deck, text=None)
        code, payload = run_validator(deck, "--min-text-objects", "1")
        assert code == 1
        assert any(item["kind"] == "insufficient_text_objects" for item in payload["findings"])


def test_rejects_picture_aspect_distortion():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "distorted.pptx"
        make_deck(
            deck,
            picture_box=(100000, 700000, 600000, 600000),
            media=png_bytes((2, 1)),
        )
        code, payload = run_validator(deck, "--max-aspect-drift", "0")
        assert code == 1
        assert any(item["kind"] == "picture_aspect_drift" for item in payload["findings"])


def test_rejects_embedded_source_screenshot_by_pixel_hash():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        source = root / "source.png"
        source.write_bytes(png_bytes((3, 2), (30, 80, 120, 255)))
        deck = root / "source-embedded.pptx"
        make_deck(
            deck,
            picture_box=(100000, 700000, 600000, 400000),
            media=source.read_bytes(),
        )
        code, payload = run_validator(deck, "--forbid-source-image", str(source))
        assert code == 1
        assert any(item["kind"] == "forbidden_source_image" for item in payload["findings"])


def test_requires_exact_picture_inventory_when_declared():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "one-picture.pptx"
        make_deck(deck, picture_box=(100000, 700000, 600000, 600000))
        code, payload = run_validator(deck, "--expected-picture-count", "2")
        assert code == 1
        assert any(item["kind"] == "picture_count_mismatch" for item in payload["findings"])


def test_rejects_missing_required_editable_text():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        deck = root / "missing-required-text.pptx"
        make_deck(deck, text="只有这一项")
        expected = root / "expected-text.json"
        expected.write_text(json.dumps(["只有这一项", "缺失的数据"]), encoding="utf-8")
        code, payload = run_validator(deck, "--required-text-file", str(expected))
        assert code == 1
        assert any(item["kind"] == "missing_required_text" for item in payload["findings"])


def test_required_text_entries_need_distinct_text_objects():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        deck = root / "one-combined-text-box.pptx"
        make_deck(deck, text="标签 数值")
        expected = root / "expected-text.json"
        expected.write_text(json.dumps(["标签", "数值"]), encoding="utf-8")
        code, payload = run_validator(deck, "--required-text-file", str(expected))
        assert code == 1
        assert any(item["kind"] == "missing_required_text" for item in payload["findings"])


def test_required_text_object_can_declare_repeated_count():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        deck = root / "one-repeated-label.pptx"
        make_deck(deck, text="2026财年")
        expected = root / "expected-text.json"
        expected.write_text(
            json.dumps([{"text": "2026财年", "count": 2, "slide": 1}]),
            encoding="utf-8",
        )
        code, payload = run_validator(deck, "--required-text-file", str(expected))
        assert code == 1
        assert any(item["kind"] == "missing_required_text" for item in payload["findings"])


def test_requires_every_approved_asset_when_requested():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        approved = root / "crops"
        approved.mkdir()
        used = approved / "used.png"
        unused = approved / "unused.png"
        used.write_bytes(png_bytes((1, 1), (12, 120, 200, 255)))
        unused.write_bytes(png_bytes((2, 1), (220, 80, 40, 255)))
        deck = root / "missing-approved-asset.pptx"
        make_deck(
            deck,
            picture_box=(100000, 700000, 600000, 600000),
            media=used.read_bytes(),
        )
        code, payload = run_validator(
            deck,
            "--approved-image-dir",
            str(approved),
            "--require-all-approved-images",
        )
        assert code == 1
        assert any(item["kind"] == "approved_media_not_used" for item in payload["findings"])


def test_rejects_image_fill_instead_of_independent_picture():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "image-fill.pptx"
        make_deck(
            deck,
            picture_box=(100000, 700000, 600000, 600000),
            as_shape_fill=True,
        )
        code, payload = run_validator(deck)
        assert code == 1
        assert any(item["kind"] == "non_picture_image_fill" for item in payload["findings"])


def test_rejects_picture_without_aspect_lock_when_required():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "unlocked.pptx"
        make_deck(deck, picture_box=(100000, 700000, 600000, 600000))
        code, payload = run_validator(deck, "--require-aspect-lock")
        assert code == 1
        assert any(item["kind"] == "picture_aspect_not_locked" for item in payload["findings"])


def test_rejects_forbidden_source_even_when_unreferenced():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        source = root / "source.png"
        source.write_bytes(png_bytes((4, 3), (90, 30, 210, 255)))
        deck = root / "unused-source-media.pptx"
        make_deck(deck, extra_media=source.read_bytes())
        code, payload = run_validator(deck, "--forbid-source-image", str(source))
        assert code == 1
        assert any(item["kind"] == "forbidden_source_media_payload" for item in payload["findings"])


def test_accepts_absolute_package_relationship_targets():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "absolute-target.pptx"
        make_deck(
            deck,
            picture_box=(100000, 700000, 600000, 600000),
            absolute_target=True,
        )
        code, payload = run_validator(deck, "--expected-picture-count", "1")
        assert code == 0, payload


def test_can_forbid_groups_to_keep_bounds_auditable():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "grouped.pptx"
        make_deck(deck, include_group=True)
        code, payload = run_validator(deck, "--forbid-groups")
        assert code == 1
        assert any(item["kind"] == "grouped_objects_not_supported" for item in payload["findings"])


def test_strict_reconstruction_rejects_incomplete_audit_configuration():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "incomplete.pptx"
        make_deck(deck)
        code, payload = run_validator(deck, "--strict-reconstruction")
        assert code == 1
        messages = [
            item.get("message", "")
            for item in payload["findings"]
            if item["kind"] == "validator_configuration"
        ]
        assert any("--forbid-source-image" in message for message in messages)
        assert any("--required-text-file" in message for message in messages)
        assert any("--expected-picture-count" in message for message in messages)


def test_large_background_plate_is_rejected_even_when_named():
    with tempfile.TemporaryDirectory() as tmp:
        deck = Path(tmp) / "background.pptx"
        make_deck(
            deck,
            picture_box=(0, 0, 9_144_000, 5_143_500),
            media=png_bytes((16, 9)),
            lock_aspect=True,
            picture_descr="approved-background-plate",
        )
        code, payload = run_validator(
            deck,
            "--max-picture-area-ratio",
            "0.15",
            "--max-total-picture-area-ratio",
            "0.30",
        )
        assert code == 1
        assert any(item["kind"] == "large_picture" for item in payload["findings"])


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} structure validator tests")
