"""build_pptx_from_layout.py 端到端：合成图 → 描述 → 裁剪 → 构建 PPTX → 校验。"""
import io
import json
import sys
import os
import unittest
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import numpy as np
from PIL import Image, ImageDraw, ImageFont


def _toy(tmp):
    arr = np.full((400, 600, 3), 255, dtype=np.uint8)
    d = ImageDraw.Draw(Image.fromarray(arr))
    try:
        font = ImageFont.truetype(
            "/System/Library/Fonts/Supplemental/PingFang.ttc", 28)
    except Exception:
        font = ImageFont.load_default()
    d.text((40, 50), "Hello", fill=(20, 20, 20), font=font)
    d.rectangle([300, 60, 380, 140], fill=(200, 40, 40))
    path = os.path.join(tmp, "src.png")
    Image.fromarray(arr).save(path)
    layout = {
        "source": path,
        "source_size": [600, 400],
        "texts": [{"text": "Hello", "box": [40, 50, 120, 40], "score": 0.99}],
        "icons": [{"name": "icon_00", "box": [300, 60, 80, 80],
                   "role": "icon", "area": 6400}],
        "regions": [{"type": "row", "index": 0, "box": [40, 50, 340, 90],
                     "contains": ["text:0", "icon:0"]}],
        "summary": {"text_count": 1, "icon_count": 1, "region_count": 1,
                    "detector": "toy"},
    }
    layout_path = os.path.join(tmp, "layout.json")
    with open(layout_path, "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False)
    crops = os.path.join(tmp, "crops")
    os.makedirs(crops, exist_ok=True)
    # 不放预裁 PNG，让 build_pptx 自己临裁
    return path, layout_path, crops


class TestBuild(unittest.TestCase):

    def test_build_pptx_and_zip(self):
        tmp = os.path.join(os.path.dirname(__file__), "_tmp_build")
        os.makedirs(tmp, exist_ok=True)
        src, layout, crops = _toy(tmp)
        out = os.path.join(tmp, "final.pptx")
        from build_pptx_from_layout import build
        class A: pass
        args = A()
        args.source, args.layout, args.crops, args.out = src, layout, crops, out
        args.font_name = "Microsoft YaHei"
        self.assertEqual(build(args), 0)
        self.assertTrue(os.path.isfile(out))
        # 校验 PPTX 结构：包含至少一个 slide、一个 textbox、一个 picture
        with zipfile.ZipFile(out) as z:
            slide = [n for n in z.namelist()
                     if n.startswith("ppt/slides/slide") and n.endswith(".xml")][0]
            xml = z.read(slide).decode("utf-8")
        self.assertIn("p:sp", xml)               # 至少一个文本框
        self.assertIn("Hello", xml)              # 文字写入了
        self.assertIn("p:pic", xml)              # 至少一张图


if __name__ == "__main__":
    unittest.main()