#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""残差兜底检测回归（`_residual_icons`）。

背景：虚线箭头、刻度线、1~2px 分隔线这类细笔画，在"平坦区域"图上连一个像素
都剩不下（3px 高的短划线会被边缘掩膜整个吃掉），于是 detect_shapes /
detect_icons / _leftover_icon_clusters 三条路全部漏掉，成品里凭空少一块。
3.4.0 加了"像素级残差"兜底：凡是不像背景、也不属于任何形状/图标/文字的像素，
聚成簇后裁成独立图标。

这里守护两件事：
  * 该捞的要捞到（细虚线、发丝分隔线）；
  * 不该捞的别乱捞（纯色页面、正常背景不能凭空多出几十个图标）。
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from describe_image import _residual_icons  # noqa: E402


def _bg(kind="solid", fill="#FEFEFE", grad=None, direction=None):
    return {"kind": kind, "fill": fill, "grad": grad, "dir": direction,
            "box": [0, 0, 400, 300], "confidence": 0.95}


def _run(arr, background, shapes=(), icons=(), texts=()):
    return _residual_icons(arr, background, list(shapes), list(icons), list(texts))


def test_dashed_arrow_is_recovered():
    """细虚线箭头：平坦区域图上一个像素都留不下，只能靠残差兜底。"""
    arr = np.full((300, 400, 3), 254, dtype=np.uint8)
    img = Image.fromarray(arr)
    d = ImageDraw.Draw(img)
    # 一条 4 段虚线 + 箭头，线宽 2px
    for x in range(120, 220, 16):
        d.rectangle([x, 148, x + 9, 149], fill=(0, 66, 172))
    d.polygon([(220, 143), (232, 149), (220, 156)], fill=(0, 66, 172))
    arr = np.asarray(img.convert("RGB"))

    out = _run(arr, _bg())
    assert out, "细虚线箭头完全没被兜底捞到"
    assert any(r["source"] == "residual" for r in out)
    best = max(out, key=lambda r: r["area"])
    x, y, w, h = best["box"]
    assert 100 <= x <= 130 and 140 <= y <= 156, f"兜底框位置不对：{best['box']}"
    assert w >= 100, f"兜底框没把整条虚线并起来：{best['box']}"
    assert h <= 24, f"兜底框过高，把无关内容吃进来了：{best['box']}"


def test_hairline_rule_is_recovered():
    """1px 长横线（标题下划线 / 行分隔线）：太细，同样只能靠残差兜底。"""
    arr = np.full((300, 400, 3), 254, dtype=np.uint8)
    img = Image.fromarray(arr)
    ImageDraw.Draw(img).rectangle([60, 90, 339, 90], fill=(70, 110, 190))
    arr = np.asarray(img.convert("RGB"))

    out = _run(arr, _bg())
    hairlines = [r for r in out if min(r["box"][2], r["box"][3]) <= 4]
    assert hairlines, f"发丝横线没被兜底捞到：{[r['box'] for r in out]}"
    box = max(hairlines, key=lambda r: r["area"])["box"]
    assert box[2] >= 240, f"横线没被完整框住：{box}"


def test_plain_page_yields_nothing():
    """纯色页面不能凭空多出图标（背景模型的容差必须收敛）。"""
    arr = np.full((300, 400, 3), 254, dtype=np.uint8)
    assert _run(arr, _bg()) == []


def test_gradient_page_yields_nothing():
    """渐变背景：拟合残差不能被误当成内容。"""
    h, w = 300, 400
    t = np.linspace(0, 1, h)[:, None]
    arr = np.zeros((h, w, 3), dtype=np.uint8)
    for i, (a, b) in enumerate([(0x10, 0x02), (0x1A, 0x08), (0x32, 0x1C)]):
        arr[:, :, i] = (a + (b - a) * t).astype(np.uint8)
    bg = _bg("gradient", grad=["#101A32", "#02081C"], direction="v")
    assert _run(arr, bg) == []


def test_covered_content_is_not_re_emitted():
    """已被形状/图标/文字覆盖的区域不得重复产出图标。"""
    arr = np.full((300, 400, 3), 254, dtype=np.uint8)
    img = Image.fromarray(arr)
    ImageDraw.Draw(img).rectangle([40, 40, 200, 120], fill=(0x1D, 0x45, 0x9F))
    arr = np.asarray(img.convert("RGB"))
    shapes = [{"type": "rect", "box": [40, 40, 161, 81],
               "fill": "#1D459F", "border": None, "border_width": 0}]
    out = _run(arr, _bg(), shapes=shapes)
    assert out == [], f"已被原生形状画出的区域仍被当成残差：{[r['box'] for r in out]}"


def test_dense_residual_is_rejected():
    """稠密的整片残留（背景模型失配）必须拒绝，不能塞进 PPT 当大截图。"""
    arr = np.full((300, 400, 3), 254, dtype=np.uint8)
    # 200x120 的实心块，与背景色明显不同，且没有任何元素声明覆盖它
    arr[60:180, 100:300] = (140, 150, 165)
    out = _run(arr, _bg())
    assert out == [], f"稠密残留被误收成图标：{[r['box'] for r in out]}"


def test_small_noise_specks_are_ignored():
    """零散小噪点不该被收成图标。"""
    rng = np.random.default_rng(7)
    arr = np.full((300, 400, 3), 254, dtype=np.uint8)
    for _ in range(40):
        y, x = rng.integers(5, 295), rng.integers(5, 395)
        arr[y, x] = (0, 0, 0)
    assert _run(arr, _bg()) == []
