#!/usr/bin/env python3
import importlib.util
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "remove_background",
    ROOT / "scripts" / "remove_background.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_edge_removal_preserves_enclosed_foreground_colored_detail_and_rgb():
    source = Image.new("RGB", (60, 40), "#EAF8FC")
    draw = ImageDraw.Draw(source)
    draw.rectangle((14, 9, 45, 30), fill="#D92D20")
    draw.rectangle((25, 15, 34, 24), fill="#EAF8FC")
    output = MODULE.remove_edge_background(source, tolerance=35, expand=0, feather=1.0)
    alpha = output.getchannel("A")
    assert alpha.getpixel((0, 0)) == 0
    assert alpha.getpixel((29, 19)) == 255
    assert alpha.getpixel((20, 19)) == 255
    assert 0 < alpha.getpixel((13, 19)) < 255
    assert output.convert("RGB").getpixel((20, 19)) == source.getpixel((20, 19))


def test_mask_mode_uses_only_alpha_and_keeps_source_rgb():
    source = Image.new("RGB", (20, 10), "#2679B9")
    mask = Image.new("RGBA", source.size, (255, 255, 255, 0))
    for x in range(20):
        value = round(255 * x / 19)
        for y in range(10):
            mask.putpixel((x, y), (255, 255, 255, value))
    output = MODULE.apply_alpha_mask(source, mask, mask_mode="alpha")
    assert output.getchannel("A").getpixel((0, 5)) == 0
    assert output.getchannel("A").getpixel((19, 5)) == 255
    assert output.convert("RGB").getpixel((19, 5)) == source.getpixel((19, 5))


def test_transparency_audit_accepts_exact_rgb_cutout_with_smooth_edges():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        source_path = root / "source.png"
        output_path = root / "output.png"
        source = Image.new("RGB", (60, 40), "#EAF8FC")
        ImageDraw.Draw(source).ellipse((14, 6, 45, 35), fill="#146FD1")
        source.save(source_path)
        MODULE.remove_edge_background(source, tolerance=35, expand=0, feather=1.0).save(output_path)
        result = subprocess.run(
            [
                sys.executable,
                str(ROOT / "scripts" / "audit_transparency.py"),
                str(output_path),
                "--source",
                str(source_path),
                "--require-smooth-edges",
                "--json",
            ],
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, result.stdout + result.stderr


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} background removal tests")
