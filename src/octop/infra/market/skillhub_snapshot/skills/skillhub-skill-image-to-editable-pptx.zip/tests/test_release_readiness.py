"""Regression tests for the installable release and recoverable failures."""
import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import batch_convert
import preflight


class ReleaseReadinessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.out = self.root / 'build'
        self.manifest = self.root / 'jobs.json'
        self.source = self.root / '中文.png'
        Image.new('RGB', (192, 108), 'white').save(self.source)

    def run_batch(self, *flags):
        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
            code = batch_convert.main(['--manifest', str(self.manifest), '-o', str(self.out),
                                       '--ocr', 'none', '--json', *flags])
        return code, json.loads(stdout.getvalue())

    def test_version_from_metadata_at_all_entry_points(self):
        expected = json.loads((ROOT / '_meta.json').read_text(encoding='utf-8'))['version']
        for script in ('batch_convert.py', 'orchestrate.py', 'preflight.py'):
            run = subprocess.run([sys.executable, '-S', str(ROOT / 'scripts' / script), '--version'],
                                 capture_output=True, text=True, timeout=20, check=True)
            self.assertEqual(run.stdout.strip(), expected)

    def test_compatibility_entry_reports_missing_dependencies_without_traceback(self):
        script = ROOT / 'scripts' / 'orchestrate.py'
        run = subprocess.run([sys.executable, '-S', str(script), str(self.source), '--json'],
                             capture_output=True, encoding='utf-8', timeout=20)
        self.assertEqual(run.returncode, 1)
        self.assertEqual(json.loads(run.stdout)['diagnostic']['code'], 'CORE_DEPENDENCY')
        self.assertNotIn('Traceback', run.stderr)

    def test_bad_manifest_json_returns_structured_error_without_touching_outputs(self):
        self.manifest.write_text('{\n  "jobs": [ }', encoding='utf-8')
        code, report = self.run_batch()
        self.assertEqual(code, 1)
        self.assertEqual(report['diagnostic']['code'], 'MANIFEST_JSON')
        self.assertIn('json.tool', report['diagnostic']['next_action'])
        self.assertFalse(self.out.exists())

    def test_bad_rows_do_not_hide_valid_pages_and_bom_manifest_is_readable(self):
        invalid = [{'layout': 'layout.json'}, None, {'source': 42}]
        self.manifest.write_text(json.dumps({'jobs': [*invalid, self.source.name]},
                                            ensure_ascii=False), encoding='utf-8-sig')
        code, report = self.run_batch()
        self.assertEqual(code, 1)
        self.assertEqual([r['status'] for r in report['results']],
                         ['failed', 'failed', 'failed', 'needs_layout'])
        self.assertEqual([r['index'] for r in report['results']], [1, 2, 3, 4])
        self.assertEqual(report['results'][0]['diagnostic']['code'], 'MANIFEST_ROW')
        next_jobs = json.loads((self.out / 'continue.json').read_text(encoding='utf-8'))['jobs']
        self.assertEqual(next_jobs[:3], invalid)

    def test_missing_image_action_points_to_source_repair(self):
        self.manifest.write_text(json.dumps(['missing.png', self.source.name]), encoding='utf-8')
        code, report = self.run_batch()
        self.assertEqual(code, 1)
        first = report['results'][0]
        self.assertEqual(first['diagnostic']['code'], 'SOURCE_MISSING')
        task = Path(first['page_dir']) / 'repair-tasks.json'
        self.assertEqual(json.loads(task.read_text(encoding='utf-8'))['tasks'][0]['diagnostic'],
                         first['diagnostic'])
        self.assertEqual(report['results'][1]['status'], 'needs_layout')

    def test_office_timeout_keeps_pptx_and_retries_with_resume(self):
        layout = {'source_size': [192, 108], 'background': {'kind': 'solid', 'fill': '#FFFFFF'},
                  'shapes': [{'type': 'rect', 'name': 'Card', 'box': [10, 10, 60, 30],
                              'fill': '#DDEEFF'}]}
        (self.root / 'layout.json').write_text(json.dumps(layout), encoding='utf-8-sig')
        self.manifest.write_text(json.dumps([{'source': self.source.name, 'layout': 'layout.json'}]),
                                 encoding='utf-8')
        real_run = subprocess.run

        def run(command, **kwargs):
            if command[0] == 'office':
                raise subprocess.TimeoutExpired('office', 120)
            return real_run(command, **kwargs)

        with patch('batch_convert.office_commands', return_value=('office', 'pdftoppm')), \
             patch('batch_convert.subprocess.run', side_effect=run):
            code, first = self.run_batch('--separate-only')
            _, second = self.run_batch('--separate-only', '--resume')
        self.assertEqual(code, 2, first)
        page = first['results'][0]
        self.assertEqual(page['status'], 'needs_review')
        self.assertTrue(Path(page['pptx']).is_file())
        self.assertFalse(page['visual_pass'])
        self.assertEqual(page['render_diagnostic']['code'], 'RENDER_FAILED')
        self.assertFalse(second['results'][0].get('cached', False))

    def test_preflight_import_failure_and_optional_components(self):
        import importlib
        original = importlib.import_module

        def import_module(name):
            if name == 'rapidocr_onnxruntime':
                raise OSError('native library not available')
            return original(name)

        for flags, expected in (([], 0), (['--require-ocr'], 1)):
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout), \
                 patch('preflight.importlib.import_module', side_effect=import_module), \
                 patch('preflight.office_commands', return_value=(None, None)):
                self.assertEqual(preflight.main(flags), expected)
            report = json.loads(stdout.getvalue())
            self.assertTrue(report['can_build_measured_layout'])
            self.assertFalse(report['can_ocr'])
            self.assertFalse(report['can_actual_render'])
            self.assertIn('native library', report['package_details']['rapidocr_onnxruntime']['error'])


if __name__ == '__main__':
    unittest.main()
