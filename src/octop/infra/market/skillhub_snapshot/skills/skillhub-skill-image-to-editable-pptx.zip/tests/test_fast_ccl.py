#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""快速连通域（行程编码 + 并查集）与旧逐像素 BFS 的等价性回归。

背景：3.3.x 的 `_connected_components` 是纯 Python 逐像素 BFS，在 1600×900
上单次就要 2.3~2.5 s；而 describe_image 一轮要跑十几次全图连通域，整条链路
13 s 以上全耗在这里。3.4.0 换成「行程编码 + 并查集」后快了 70~160 倍。

性能优化最怕"悄悄改了结果"——所以这里不看耗时，只看**结果是否逐项一致**：
对随机掩膜与若干退化掩膜，断言新实现与参考 BFS 输出的 (bbox, area) 集合
完全相同。参考实现留在本文件里，不依赖被优化过的代码。
"""
import os
import sys
from collections import deque

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from describe_image import _connected_components  # noqa: E402


def slow_cc(mask):
    """参考实现：8 邻域逐像素 BFS（3.3.x 的原版行为）。"""
    m = np.asarray(mask, dtype=bool)
    H, W = m.shape
    seen = np.zeros((H, W), dtype=bool)
    out = []
    for sy in range(H):
        for sx in range(W):
            if not m[sy, sx] or seen[sy, sx]:
                continue
            q = deque([(sx, sy)])
            seen[sy, sx] = True
            x0 = x1 = sx
            y0 = y1 = sy
            area = 0
            while q:
                x, y = q.popleft()
                area += 1
                x0, x1 = min(x0, x), max(x1, x)
                y0, y1 = min(y0, y), max(y1, y)
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < W and 0 <= ny < H and m[ny, nx] and not seen[ny, nx]:
                            seen[ny, nx] = True
                            q.append((nx, ny))
            out.append(((x0, y0, x1, y1), area))
    return sorted(out)


def _norm(comps):
    return sorted((tuple(c[0]), int(c[1])) for c in comps)


def test_matches_reference_on_random_masks():
    rng = np.random.default_rng(20240925)
    for i in range(12):
        h = int(rng.integers(8, 40))
        w = int(rng.integers(8, 40))
        density = float(rng.uniform(0.15, 0.65))
        m = rng.random((h, w)) < density
        assert _norm(_connected_components(m)) == _norm(slow_cc(m)), \
            f"随机掩膜 #{i}（{h}x{w}, density={density:.2f}）结果不一致"


def test_matches_reference_on_structured_masks():
    """细横条 / 细竖条 / 棋盘 / 单像素对角线 —— 行程合并最容易出错的形状。"""
    cases = []
    a = np.zeros((20, 30), dtype=bool)
    a[3, 2:28] = True                      # 单像素横条
    a[10:12, 5:9] = True                   # 2px 高小块
    cases.append(a)

    b = np.zeros((20, 30), dtype=bool)
    b[2:18, 7] = True                      # 单像素竖条
    cases.append(b)

    c = np.zeros((21, 21), dtype=bool)
    c[::2, ::2] = True                     # 4 邻域不连、8 邻域连
    cases.append(c)

    d = np.eye(24, dtype=bool)             # 单像素对角线（8 邻域一条链）
    cases.append(d)

    e = np.zeros((16, 16), dtype=bool)
    e[0, 0] = True                         # 只有一个像素
    cases.append(e)

    for i, m in enumerate(cases):
        assert _norm(_connected_components(m)) == _norm(slow_cc(m)), \
            f"结构化掩膜 #{i} 结果不一致"


def test_degenerate_inputs():
    assert _connected_components(np.zeros((10, 10), dtype=bool)) == []
    full = _connected_components(np.ones((7, 9), dtype=bool))
    assert len(full) == 1
    assert tuple(full[0][0]) == (0, 0, 8, 6)
    assert full[0][1] == 63


def test_single_row_and_single_column():
    row = np.ones((1, 12), dtype=bool)
    row[0, 5] = False                      # 断开成两段
    assert _norm(_connected_components(row)) == _norm(slow_cc(row))

    col = np.ones((12, 1), dtype=bool)
    col[6, 0] = False
    assert _norm(_connected_components(col)) == _norm(slow_cc(col))
