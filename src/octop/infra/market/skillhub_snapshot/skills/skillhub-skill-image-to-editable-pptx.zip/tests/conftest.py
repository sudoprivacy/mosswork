#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pytest 全局夹具：测试结束后清掉临时产物，保证技能包目录始终干净。

各测试用 `tests/_tmp_*` 作为工作目录（`_tmp_build` / `_tmp_describe` /
`_tmp_orchestrate` / `_tmp_render` ...）。如果不清，跑完一次 pytest 就会往包里
留下几十个 PNG/PPTX 和 `.pytest_cache`，打包时容易被误带出去。
"""
import glob
import os
import shutil

import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(TESTS_DIR)


def _sweep():
    for path in glob.glob(os.path.join(TESTS_DIR, "_tmp_*")):
        shutil.rmtree(path, ignore_errors=True)
    for path in glob.glob(os.path.join(TESTS_DIR, "__pycache__")):
        shutil.rmtree(path, ignore_errors=True)
    for path in glob.glob(os.path.join(ROOT, "scripts", "__pycache__")):
        shutil.rmtree(path, ignore_errors=True)
    shutil.rmtree(os.path.join(ROOT, ".pytest_cache"), ignore_errors=True)


@pytest.fixture(scope="session", autouse=True)
def _clean_tmp_artifacts():
    _sweep()
    yield
    _sweep()


def pytest_sessionfinish(session, exitstatus):   # noqa: ARG001
    """双保险：即使夹具因异常未走到 finalizer，这里也再扫一次。"""
    _sweep()
