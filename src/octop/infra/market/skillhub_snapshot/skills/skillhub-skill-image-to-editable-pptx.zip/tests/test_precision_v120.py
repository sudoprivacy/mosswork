"""Catch small local misses that a whole-slide average can conceal."""
import tempfile
import unittest
from pathlib import Path
import sys

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from batch_convert import compare_render, inspection_regions, structure_check
from pptx import Presentation
from pptx.util import Inches


class PrecisionTests(unittest.TestCase):
    def test_small_missing_label_is_detected_without_manual_regions(self):
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            source = Image.new('RGB', (600, 400), 'white')
            ImageDraw.Draw(source).rectangle((20, 20, 49, 34), fill='black')
            source.save(folder / 'source.png')
            Image.new('RGB', (600, 400), 'white').save(folder / 'rendered.png')
            layout = {'texts': [{'name': 'small label', 'box': [20, 20, 30, 15]}]}
            result = compare_render(folder / 'source.png', folder / 'rendered.png', folder, layout)
            self.assertLess(result['rms'], .15)
            self.assertGreater(result['regions'][0]['rms'], .15)
            self.assertEqual(result['regions'][0]['name'], 'small label')

    def test_line_region_uses_endpoint_and_is_clipped_to_canvas(self):
        layout = {'shapes': [{'name': 'line', 'type': 'line', 'box': [8, 8, 0, 0],
                              'end': [32, 36]}]}
        self.assertEqual(inspection_regions(layout, (40, 40))[0]['box'], [4, 4, 32, 36])

    def test_structure_rejects_missing_native_shape(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'one.pptx'
            prs = Presentation()
            prs.slide_width = Inches(6)
            prs.slide_height = Inches(4)
            slide = prs.slides.add_slide(prs.slide_layouts[6])
            textbox = slide.shapes.add_textbox(0, 0, Inches(2), Inches(.5))
            textbox.text = 'Title'
            prs.save(path)
            layout = {'texts': [{'text': 'Title'}], 'shapes': [{'name': 'card'}],
                      'background': {'kind': 'solid'}}
            report = structure_check(path, layout)
            self.assertEqual(report['status'], 'fail')
            self.assertIn('card', report['missing_names'])


if __name__ == '__main__':
    unittest.main()
