"""背景隐形图形 → 按空白背景处理（3.5.0）。

守护 6 条判定：底层 + 无描边 + 大面积 + 低不透明度 + 非内容底板 + 非线/箭头，
六条全中才按空白处理。反向用例（卡片底板、面板描边、进度条、前景层、实色块）
必须**一个都不丢** —— 这条比"丢得掉"更重要。
"""
import json
import os
import sys
import unittest
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import numpy as np
from PIL import Image, ImageDraw

import bg_blank


PAGE = (600, 400)          # W, H
PAGE_AREA = 600 * 400


def _shape(name, box, fill, **kw):
    d = {"name": name, "type": "rect", "box": list(box), "fill": fill}
    d.update(kw)
    return d


class TestEstimateAlpha(unittest.TestCase):
    """不透明度是**下界**估计：O = α·C + (1-α)·B ⇒ α ≥ max|O-B| / 255。"""

    def test_alpha_is_lower_bound_of_true_opacity(self):
        white = (255, 255, 255)
        # 30% 黑叠在白底上 → 观测 (178.5, 178.5, 178.5)
        self.assertAlmostEqual(
            bg_blank.estimate_alpha((178, 178, 178), white), 30.2, places=1)
        # 30% 品牌蓝 (0,102,255) 叠白底 → (178.5, 209.1, 255)，最大通道差仍在 R
        self.assertAlmostEqual(
            bg_blank.estimate_alpha((179, 209, 255), white), 29.8, places=1)

    def test_identical_to_background_is_fully_invisible(self):
        self.assertEqual(bg_blank.estimate_alpha((255, 255, 255),
                                                 (255, 255, 255)), 0.0)

    def test_full_contrast_is_opaque(self):
        self.assertEqual(bg_blank.estimate_alpha((0, 0, 0),
                                                 (255, 255, 255)), 100.0)

    def test_mid_tone_is_underestimated_never_overestimated(self):
        """中灰色实色块：下界 50%，真实可能 100% → 只会少判，不会误判。"""
        a = bg_blank.estimate_alpha((128, 128, 128), (255, 255, 255))
        self.assertAlmostEqual(a, 49.8, places=1)
        self.assertLessEqual(a, 100.0)


class TestClassifyBlankable(unittest.TestCase):

    def test_watermark_is_blanked(self):
        """全页水印：底层、无描边、大面积、几乎看不见 → 空白。"""
        el = _shape("watermark", [0, 0, 600, 400], "#F2F2F2")
        yes, reason = bg_blank.classify_blankable(el, 5.0, PAGE_AREA)
        self.assertTrue(yes, reason)
        self.assertIn("空白", reason)

    def test_card_plate_is_kept(self):
        """卡片底板：里面托着文字 → 保留（哪怕它本身很淡）。"""
        el = _shape("card", [40, 40, 300, 200], "#F8F8F8")
        texts = [{"text": "标题", "box": [60, 60, 200, 30]}]
        yes, reason = bg_blank.classify_blankable(el, 3.0, PAGE_AREA,
                                                  texts=texts)
        self.assertFalse(yes)
        self.assertIn("内容底板", reason)

    def test_bordered_panel_is_kept(self):
        el = _shape("panel", [40, 40, 300, 200], "#FAFAFA",
                    border="#333333", border_width=2)
        yes, reason = bg_blank.classify_blankable(el, 2.0, PAGE_AREA)
        self.assertFalse(yes)
        self.assertIn("描边", reason)

    def test_foreground_layer_is_kept(self):
        """z=10 = 面板容器层，不是背景装饰。"""
        el = _shape("panel", [40, 40, 300, 200], "#F5F5F5", z=10)
        yes, reason = bg_blank.classify_blankable(el, 4.0, PAGE_AREA)
        self.assertFalse(yes)
        self.assertIn("非背景层", reason)

    def test_line_is_never_blanked(self):
        el = _shape("sep", [0, 200, 600, 2], "#EEEEEE")
        el["type"] = "line"
        yes, reason = bg_blank.classify_blankable(el, 5.0, PAGE_AREA)
        self.assertFalse(yes)
        self.assertIn("type", reason)

    def test_tiny_bar_is_kept(self):
        """进度条/细分隔线这类小块一律保留（面积安全阀）。"""
        el = _shape("bar", [10, 300, 120, 8], "#EEEEEE")
        yes, reason = bg_blank.classify_blankable(el, 5.0, PAGE_AREA)
        self.assertFalse(yes)
        self.assertIn("面积占页面", reason)

    def test_visible_shape_is_kept(self):
        el = _shape("card", [40, 40, 300, 200], "#C82828")
        yes, reason = bg_blank.classify_blankable(el, 84.0, PAGE_AREA)
        self.assertFalse(yes)
        self.assertIn("不透明度", reason)


class TestBlankShapes(unittest.TestCase):

    def _layout(self):
        return {
            "source_size": [600, 400],
            "background": {"kind": "solid", "fill": "#FFFFFF",
                           "grad": None, "dir": None, "confidence": 0.9,
                           "box": [0, 0, 600, 400]},
            "texts": [{"text": "指标", "box": [60, 60, 200, 30]}],
            "icons": [], "images": [],
            "shapes": [
                _shape("watermark", [0, 0, 600, 400], "#F2F2F2"),
                _shape("band", [40, 40, 300, 60], "#F5F5F5"),
                _shape("panel", [40, 200, 200, 80], "#FAFAFA",
                       border="#333333", border_width=2),
                _shape("bar", [10, 300, 120, 8], "#EEEEEE"),
                _shape("card", [300, 60, 200, 120], "#C82828"),
            ],
        }

    def _source(self, path):
        """按 layout 画一张对应的源图：不透明度一律回到源图像素上去判。

        注意 `Image.fromarray()` 会拷一份数据，`ImageDraw` 必须画在**同一个**
        Image 对象上，否则画完再 `fromarray(arr)` 保存出来还是全白。
        """
        os.makedirs(os.path.dirname(path), exist_ok=True)
        im = Image.fromarray(np.full((400, 600, 3), 255, dtype=np.uint8))
        d = ImageDraw.Draw(im)
        d.rectangle([40, 40, 339, 99], fill=(245, 245, 245))      # band
        d.rectangle([40, 200, 239, 279], fill=(250, 250, 250),
                    outline=(51, 51, 51), width=2)                # panel
        d.rectangle([10, 300, 129, 307], fill=(238, 238, 238))    # bar
        d.rectangle([300, 60, 499, 179], fill=(200, 40, 40))      # card
        im.save(path)
        return np.asarray(im.convert("RGB"))

    def test_only_the_invisible_background_decoration_is_dropped(self):
        layout = self._layout()
        tmp = os.path.join(os.path.dirname(__file__), "_tmp_bgblank")
        os.makedirs(tmp, exist_ok=True)
        arr = self._source(os.path.join(tmp, "src.png"))

        kept, blanked = bg_blank.blank_shapes(
            layout["shapes"], layout["background"], PAGE,
            texts=layout["texts"], icons=[], arr=arr)

        self.assertEqual([b["name"] for b in blanked], ["watermark"])
        self.assertEqual(sorted(s["name"] for s in kept),
                         ["band", "bar", "card", "panel"])
        self.assertLess(blanked[0]["alpha"], 60.0)
        self.assertIn("空白", blanked[0]["reason"])

    def test_disabled_keeps_everything(self):
        layout = self._layout()
        tmp = os.path.join(os.path.dirname(__file__), "_tmp_bgblank")
        arr = self._source(os.path.join(tmp, "src.png"))
        kept, blanked = bg_blank.blank_shapes(
            layout["shapes"], layout["background"], PAGE,
            texts=layout["texts"], arr=arr, enabled=False)
        self.assertEqual(len(kept), 5)
        self.assertEqual(blanked, [])

    def test_threshold_zero_disables_it(self):
        layout = self._layout()
        kept, blanked = bg_blank.blank_shapes(
            layout["shapes"], layout["background"], PAGE,
            texts=layout["texts"], threshold=0)
        self.assertEqual(len(kept), 5)
        self.assertEqual(blanked, [])


class TestDescribeIntegration(unittest.TestCase):
    """自动链路：一块淡到几乎看不见的大色块不该变成原生形状。"""

    def test_faint_flat_block_is_not_emitted_as_shape(self):
        from describe_image import detect_shapes
        arr = np.full((200, 200, 3), 255, dtype=np.uint8)
        arr[20:180, 20:180] = 240                    # 与白底只差 15 → α≈5.9%
        img = Image.fromarray(arr)
        blanked = []
        shapes = detect_shapes(
            img, background={"kind": "solid", "fill": "#FFFFFF", "grad": None,
                             "dir": None, "confidence": 0.9,
                             "box": [0, 0, 200, 200]},
            bg_blank_alpha=60.0, blanked=blanked)
        self.assertEqual(len(blanked), 1)
        self.assertEqual(shapes, [])
        self.assertLess(blanked[0]["alpha"], 60.0)

    def test_same_block_is_kept_when_threshold_is_off(self):
        from describe_image import detect_shapes
        arr = np.full((200, 200, 3), 255, dtype=np.uint8)
        arr[20:180, 20:180] = 240
        img = Image.fromarray(arr)
        blanked = []
        shapes = detect_shapes(
            img, background={"kind": "solid", "fill": "#FFFFFF", "grad": None,
                             "dir": None, "confidence": 0.9,
                             "box": [0, 0, 200, 200]},
            bg_blank_alpha=0.0, blanked=blanked)
        self.assertEqual(blanked, [])
        self.assertEqual(len(shapes), 1)


class TestBuildIntegration(unittest.TestCase):
    """构建端：被判为隐形的形状不落盘，其余照常。"""

    def test_blanked_shape_is_absent_from_pptx(self):
        from build_pptx_from_layout import build
        tmp = os.path.join(os.path.dirname(__file__), "_tmp_bgblank")
        os.makedirs(tmp, exist_ok=True)
        src = os.path.join(tmp, "src.png")

        layout = TestBlankShapes()._layout()
        im = Image.fromarray(np.full((400, 600, 3), 255, dtype=np.uint8))
        d = ImageDraw.Draw(im)
        d.rectangle([40, 40, 339, 99], fill=(245, 245, 245))
        d.rectangle([40, 200, 239, 279], fill=(250, 250, 250),
                    outline=(51, 51, 51), width=2)
        d.rectangle([10, 300, 129, 307], fill=(238, 238, 238))
        d.rectangle([300, 60, 499, 179], fill=(200, 40, 40))
        im.save(src)
        layout["source"] = src
        layout_path = os.path.join(tmp, "layout.json")
        with open(layout_path, "w", encoding="utf-8") as f:
            json.dump(layout, f, ensure_ascii=False)

        out = os.path.join(tmp, "final.pptx")

        class A:
            pass
        args = A()
        args.source, args.layout, args.crops = src, layout_path, tmp
        args.out = out
        args.font_name = "Microsoft YaHei"
        args.bg_blank_alpha = 60.0
        args.no_bg_blank = False
        self.assertEqual(build(args), 0)

        with zipfile.ZipFile(out) as z:
            slide = [n for n in z.namelist()
                     if n.startswith("ppt/slides/slide")
                     and n.endswith(".xml")][0]
            xml = z.read(slide).decode("utf-8")
        self.assertIn("C82828", xml)        # 实色卡片照常落盘
        self.assertIn("FAFAFA", xml)        # 带描边面板照常落盘
        self.assertNotIn("F2F2F2", xml)     # 隐形水印 → 空白


if __name__ == "__main__":
    unittest.main()
