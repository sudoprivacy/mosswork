import assert from "node:assert/strict";
import { assertTextBoxBudget, estimateTextWidth } from "../scripts/text_box_budget.mjs";

assert(estimateTextWidth("中文123", 24, { bold: true }) > 90);
assert.doesNotThrow(() =>
  assertTextBoxBudget("非生产总能耗", { width: 220, height: 42 }, 24, { bold: true }),
);
assert.throws(() =>
  assertTextBoxBudget("非生产总能耗", { width: 90, height: 20 }, 24, { bold: true }),
  /Text box budget failed/,
);

console.log("PASS: text box budget checks unsafe fixed text frames");
