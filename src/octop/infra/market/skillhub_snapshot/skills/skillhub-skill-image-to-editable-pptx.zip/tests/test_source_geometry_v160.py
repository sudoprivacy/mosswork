import json
from pathlib import Path
import sys
from types import SimpleNamespace

from PIL import Image
from pptx import Presentation

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from build_pptx_from_layout import build
from batch_convert import structure_check


def export(root, layout, asset_size=(24, 64)):
    Image.new('RGB', (400, 240), '#082030').save(root / 'source.png')
    Image.new('RGBA', asset_size, '#23BEFF').save(root / 'icon.png')
    (root / 'layout.json').write_text(json.dumps(layout))
    output = root / 'out.pptx'
    build(SimpleNamespace(source=str(root / 'source.png'), layout=str(root / 'layout.json'),
                          crops=str(root), out=str(output), font_name='DejaVu Sans', strict_assets=True))
    return output


def test_padded_crop_uses_source_box_instead_of_recentering_in_inner_box(tmp_path):
    layout = {'source_size': [400, 240], 'images': [{'name': 'icon', 'file': 'icon.png',
              'box': [100, 20, 20, 60], 'source_box': [98, 18, 24, 64], 'source_size': [400, 240]}]}
    output = export(tmp_path, layout)
    picture = next(s for s in Presentation(output).slides[0].shapes if s.name == 'icon')
    actual = [v / 9525 for v in (picture.left, picture.top, picture.width, picture.height)]
    assert actual == [98, 18, 24, 64]


def test_trimmed_source_asset_requires_fresh_crop_provenance(tmp_path):
    import pytest
    layout = {'source_size': [400, 240], 'images': [{'name': 'icon', 'file': 'icon.png',
              'box': [98, 18, 24, 64], 'source_box': [98, 18, 24, 64]}]}
    with pytest.raises(ValueError, match='source_box'):
        export(tmp_path, layout, asset_size=(20, 60))


def test_structure_check_rejects_in_bounds_text_and_icon_displacement(tmp_path):
    layout = {'source_size': [400, 240],
              'images': [{'name': 'icon', 'file': 'icon.png', 'box': [98, 18, 24, 64],
                          'source_box': [98, 18, 24, 64]}],
              'texts': [{'name': 'cell', 'text': '829 h', 'box': [180, 25, 150, 40],
                         'box_mode': 'frame', 'size_pt': 18}]}
    output = export(tmp_path, layout)
    layout['review'] = {'visual_inventory_verified': True}
    layout['visual_inventory'] = [{'id': 'icon', 'kind': 'icon',
        'source_box': [98, 18, 24, 64], 'treatment': 'raster',
        'editable_paths': False, 'reason': 'Raster geometry fixture',
        'objects': ['icon'], 'reviewed': True}]
    assert structure_check(output, layout)['status'] == 'pass'
    deck = Presentation(output)
    for shape in deck.slides[0].shapes:
        if shape.name in ('icon', 'cell'):
            shape.left += 3 * 9525
    deck.save(output)
    result = structure_check(output, layout)
    assert result['status'] == 'fail', result
    assert {x['name'] for x in result['geometry']['findings']} == {'icon', 'cell'}


def test_measured_mode_requires_asset_provenance(tmp_path):
    layout = {'source_size': [400, 240], 'precision_mode': 'measured',
              'images': [{'name': 'icon', 'file': 'icon.png', 'box': [98, 18, 24, 64]}]}
    output = export(tmp_path, layout)
    result = structure_check(output, layout)
    assert result['status'] == 'fail'
    assert result['geometry']['unchecked'][0]['name'] == 'icon'
