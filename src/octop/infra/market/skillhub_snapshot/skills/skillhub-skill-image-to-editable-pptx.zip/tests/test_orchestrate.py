"""orchestrate.py 端到端：合成一张最简单的图，跑全流程并校验报告。"""
import io
import importlib.util
import json
import os
import subprocess
import sys
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
PY = sys.executable


def _toy(tmp):
    import numpy as np
    from PIL import Image, ImageDraw, ImageFont
    arr = np.full((300, 500, 3), 255, dtype=np.uint8)
    im = Image.fromarray(arr)
    d = ImageDraw.Draw(im)
    try:
        font = ImageFont.truetype(
            "/System/Library/Fonts/Supplemental/PingFang.ttc", 24)
    except Exception:
        font = ImageFont.load_default()
    d.text((40, 40), "Title", fill=(20, 20, 20), font=font)
    d.rectangle([40, 120, 120, 200], fill=(50, 80, 200))
    path = os.path.join(tmp, "src.png")
    im.save(path)
    return path


class TestOrchestrate(unittest.TestCase):

    @unittest.skipUnless(importlib.util.find_spec('rapidocr_onnxruntime'),
                         'Legacy OCR smoke requires optional rapidocr-onnxruntime')
    def test_end_to_end_smoke(self):
        tmp = os.path.join(os.path.dirname(__file__), "_tmp_orchestrate")
        os.makedirs(tmp, exist_ok=True)
        src = _toy(tmp)
        out_dir = os.path.join(tmp, "build")
        cmd = [PY, os.path.join(SCRIPTS, "orchestrate.py"),
               src, "--legacy-single", "-o", out_dir, "--max-rms", "0.6",
               "--reference-bg", "FFFFFF", "--json"]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        # 沙盒内允许 RMS 偏高（OCR+字体替换是粗略重建）；保证流水线不挂
        self.assertEqual(r.returncode, 0,
                         msg=f"stdout={r.stdout}\nstderr={r.stderr}")
        for fname in ("layout.json", "final.pptx", "rendered.png",
                      "compare/side_by_side.png", "compare/difference.png",
                      "report.json"):
            self.assertTrue(os.path.exists(os.path.join(out_dir, fname)),
                            f"缺产物：{fname}")
        rep = json.loads(open(os.path.join(out_dir, "report.json"),
                              encoding="utf-8").read())
        self.assertEqual(rep["status"], "needs_review")
        self.assertFalse(rep["visual_pass"])
        self.assertIn("rms_diff", rep["compare"])


if __name__ == "__main__":
    unittest.main()
