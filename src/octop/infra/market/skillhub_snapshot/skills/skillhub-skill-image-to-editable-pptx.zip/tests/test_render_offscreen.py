#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""render_offscreen.py 回归测试。

重点守护一个曾经静默失效的 bug：PPTX 的 rels `Target` 形如
`../media/imageN.png`，若不相对 `ppt/slides/` 做 normpath，就会拿不到 zip 成员，
**所有图片被静默丢弃，而 RMS 仍然"看似正常"**。所以这里不看 RMS，直接数像素。
"""
import os
import sys
import unittest

import numpy as np
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import render_offscreen as R  # noqa: E402


def _build_pptx(tmp):
    """造一张含 背景矩形 / 图片 / 文字的 PPTX。"""
    from pptx import Presentation
    from pptx.util import Emu, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE

    os.makedirs(tmp, exist_ok=True)
    pink = os.path.join(tmp, "pic.png")
    Image.new("RGB", (60, 40), (255, 0, 255)).save(pink)   # 洋红，便于断言

    prs = Presentation()
    prs.slide_width = Emu(9525 * 400)
    prs.slide_height = Emu(9525 * 200)
    s = prs.slides.add_slide(prs.slide_layouts[6])

    bg = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, Emu(9525 * 0), Emu(9525 * 0),
                            Emu(9525 * 400), Emu(9525 * 200))
    bg.fill.solid(); bg.fill.fore_color.rgb = RGBColor(0x00, 0x10, 0x30)
    bg.line.fill.background()

    s.shapes.add_picture(pink, Emu(9525 * 40), Emu(9525 * 40),
                         width=Emu(9525 * 60), height=Emu(9525 * 40))

    tb = s.shapes.add_textbox(Emu(9525 * 150), Emu(9525 * 60),
                              Emu(9525 * 200), Emu(9525 * 40))
    tb.text_frame.text = "TEST"
    tb.text_frame.paragraphs[0].runs[0].font.size = Pt(20)
    tb.text_frame.paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0x00)

    out = os.path.join(tmp, "t.pptx")
    prs.save(out)
    return out, pink


class TestRenderOffscreen(unittest.TestCase):

    def setUp(self):
        self.tmp = os.path.join(os.path.dirname(__file__), "_tmp_render")
        self.pptx, self.pink = _build_pptx(self.tmp)

    def test_size_defaults_to_slide_emu(self):
        img = R.render(self.pptx)
        self.assertEqual(img.size, (400, 200))

    def test_pictures_are_actually_drawn(self):
        """回归：rels Target 未 normpath 时图片会整体消失。"""
        img = np.asarray(R.render(self.pptx).convert("RGB")).astype(int)
        region = img[40:80, 40:100]
        # 洋红 (255,0,255)：R 与 B 高、G 低
        magenta = ((region[:, :, 0] > 180) & (region[:, :, 1] < 90)
                   & (region[:, :, 2] > 180)).sum()
        self.assertGreater(magenta, 1500,
                           f"图片未被渲染（洋红像素仅 {magenta}）——检查 rels 路径归一化")

    def test_solid_fill_and_text_are_drawn(self):
        img = np.asarray(R.render(self.pptx).convert("RGB")).astype(int)
        self.assertLess(img[10, 10].mean(), 80, "背景矩形未填充")
        band = img[60:100, 150:350]
        yellow = ((band[:, :, 0] > 170) & (band[:, :, 1] > 170)
                  & (band[:, :, 2] < 110)).sum()
        self.assertGreater(yellow, 20, "文字未被渲染")

    def test_gradient_roundrect_and_arrows_do_not_crash(self):
        from pptx import Presentation
        from pptx.util import Emu, Pt
        from pptx.dml.color import RGBColor
        from pptx.enum.shapes import MSO_SHAPE

        prs = Presentation()
        prs.slide_width = Emu(9525 * 200)
        prs.slide_height = Emu(9525 * 200)
        s = prs.slides.add_slide(prs.slide_layouts[6])
        for shape, box in [(MSO_SHAPE.ROUNDED_RECTANGLE, (10, 10, 80, 50)),
                           (MSO_SHAPE.OVAL, (100, 10, 60, 60)),
                           (MSO_SHAPE.RIGHT_ARROW, (10, 90, 80, 30)),
                           (MSO_SHAPE.LEFT_ARROW, (100, 90, 80, 30))]:
            sp = s.shapes.add_shape(shape, Emu(9525 * box[0]), Emu(9525 * box[1]),
                                    Emu(9525 * box[2]), Emu(9525 * box[3]))
            sp.fill.gradient()
            stops = sp.fill.gradient_stops
            stops[0].color.rgb = RGBColor(0x10, 0x60, 0xC0)
            if len(stops) > 1:
                stops[1].color.rgb = RGBColor(0x80, 0xE0, 0xFF)
            sp.line.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            sp.line.width = Pt(1)
        p = os.path.join(self.tmp, "grad.pptx")
        prs.save(p)
        img = np.asarray(R.render(p).convert("RGB")).astype(int)
        self.assertGreater(img[20:60, 10:90].sum(), 0, "圆角矩形未渲染")
        self.assertGreater(img[20:70, 100:160].sum(), 0, "椭圆未渲染")
        self.assertGreater(img[95:120, 10:90].sum(), 0, "箭头未渲染")

    def test_cli_writes_rendered_and_diff(self):
        out = os.path.join(self.tmp, "r.png")
        ref = os.path.join(self.tmp, "ref.png")
        Image.new("RGB", (400, 200), (0, 0, 0)).save(ref)
        import subprocess
        r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "render_offscreen.py"),
                            self.pptx, "-o", out, "--reference", ref, "--json"],
                           capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(os.path.isfile(out))
        self.assertTrue(os.path.isfile(os.path.join(self.tmp, "difference.png")))
        self.assertTrue(os.path.isfile(os.path.join(self.tmp, "side_by_side.png")))
        self.assertIn("rms_diff", r.stdout)


if __name__ == "__main__":
    unittest.main()
