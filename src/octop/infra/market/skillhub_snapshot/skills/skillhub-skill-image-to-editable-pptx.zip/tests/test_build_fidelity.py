#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_pptx_from_layout.py 的还原度回归。

这里锁定的都是"看起来对、其实错"的静默缺陷 —— 它们不会抛异常，只会让导出
的 PPT 和源图不一样：

1. 页面背景：3.3.2 完全不写 `p:bg`，深色版式导出后整页变成默认灰白。
2. 文字颜色：旧实现取框内**最暗**像素，深色底上的白字被判成近黑色 → 隐形。
3. 边框：旧实现读 `el["bw"]`，而 describe_image 输出的是 `border_width`
   → 所有描边被静默丢弃。
4. 图片：旧实现同时指定 width 与 height，素材比例与框不一致时被拉伸
   （SKILL.md 明令禁止）。
5. 字号：旧实现用 `h × 0.85 / 1.333` 固定系数，对 CJK 偏小、对数字偏大。
"""
import json
import os
import re
import sys
import zipfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from build_pptx_from_layout import (  # noqa: E402
    _fit_font_size, _ink_analysis, build)

TMP = os.path.join(os.path.dirname(__file__), "_tmp_build_fidelity")


def _args(source, layout, crops, out, font="微软雅黑"):
    class A:
        pass
    a = A()
    a.source, a.layout, a.crops, a.out = source, layout, crops, out
    a.font_name = font
    a.text_pad = 2
    a.ink_fit = True
    a.wrap = False
    return a


def _slide_xml(pptx):
    with zipfile.ZipFile(pptx) as z:
        name = next(n for n in z.namelist()
                    if n.startswith("ppt/slides/slide") and n.endswith(".xml"))
        return z.read(name).decode("utf-8")


def _font(size):
    for p in ("C:/Windows/Fonts/msyh.ttc",
              "/System/Library/Fonts/PingFang.ttc",
              "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"):
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size, index=0)
            except Exception:
                continue
    import pytest
    pytest.skip("A real CJK font is required for pixel/ink regression; bitmap fallback is not equivalent")


def _setup(tmp):
    """造一张 600x400 的图：深色渐变底 + 白字 + 带描边的圆角块。"""
    os.makedirs(tmp, exist_ok=True)
    arr = np.zeros((400, 600, 3), dtype=np.uint8)
    t = np.linspace(0, 1, 400)[:, None]
    arr[:, :, 0] = (0x10 + (0x02 - 0x10) * t).astype(np.uint8)
    arr[:, :, 1] = (0x1A + (0x08 - 0x1A) * t).astype(np.uint8)
    arr[:, :, 2] = (0x32 + (0x1C - 0x32) * t).astype(np.uint8)
    img = Image.fromarray(arr)
    d = ImageDraw.Draw(img)
    d.text((40, 40), "指标 12.5", fill=(255, 255, 255), font=_font(30))
    d.rectangle([300, 200, 460, 260], fill=(0x1D, 0x45, 0x9F),
                outline=(0x50, 0x78, 0xC8), width=2)
    src = os.path.join(tmp, "src.png")
    img.save(src)

    layout = {
        "source": src,
        "source_size": [600, 400],
        "background": {"kind": "gradient", "grad": ["#101A32", "#02081C"],
                       "dir": "v", "fill": "#0A1226",
                       "box": [0, 0, 600, 400], "confidence": 0.95},
        "texts": [{"text": "指标 12.5", "box": [40, 40, 160, 34], "score": 0.99}],
        "icons": [],
        "shapes": [{"type": "rect", "box": [300, 200, 161, 61],
                    "fill": "#1D459F", "border": "#5078C8",
                    "border_width": 2, "name": "shape_00"}],
        "regions": [],
        "summary": {"text_count": 1, "icon_count": 0, "shape_count": 1,
                    "region_count": 0, "background_kind": "gradient",
                    "detector": "toy"},
    }
    lp = os.path.join(tmp, "layout.json")
    with open(lp, "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False)
    crops = os.path.join(tmp, "crops")
    os.makedirs(crops, exist_ok=True)
    return src, lp, crops, layout


class TestBackgroundAndColour:

    def setup_method(self):
        self.tmp = TMP
        self.src, self.lp, self.crops, self.layout = _setup(self.tmp)
        self.out = os.path.join(self.tmp, "final.pptx")
        assert build(_args(self.src, self.lp, self.crops, self.out)) == 0
        self.xml = _slide_xml(self.out)

    def test_gradient_page_background_is_written(self):
        """回归：3.3.2 不写 p:bg，深色版式导出后是默认灰白底。"""
        assert "<p:bg>" in self.xml, "没有写入页面背景 p:bg"
        assert "gradFill" in self.xml, "背景不是渐变填充"
        assert "101A32" in self.xml and "02081C" in self.xml, "渐变色标丢失"
        # 垂直方向：a:lin ang=5400000（90°）
        assert 'ang="5400000"' in self.xml, "渐变方向不是竖直"

    def test_text_colour_follows_local_background_not_darkest(self):
        """回归：旧实现取最暗像素，白字会被判成近黑 → 隐形。"""
        m = re.search(r'<a:rPr[^>]*sz="(\d+)"[^>]*>.*?<a:srgbClr val="([0-9A-Fa-f]{6})"',
                      self.xml, re.S)
        assert m, "没找到文字颜色"
        r, g, b = (int(m.group(2)[i:i + 2], 16) for i in (0, 2, 4))
        assert min(r, g, b) > 180, \
            f"深色底上的白字被写成了 #{m.group(2)}（应当接近白色）"

    def test_font_size_is_ink_fitted_not_fixed_ratio(self):
        """回归：旧实现 h×0.85/1.333 会明显偏小。"""
        sz = int(re.search(r'<a:rPr[^>]*sz="(\d+)"', self.xml).group(1))
        assert 14 <= sz / 100.0 <= 34, f"字号 {sz/100.0}pt 超出合理区间"


class TestBorderAndPicture:

    def test_border_width_key_is_honoured(self):
        """回归：旧实现只读 `bw`，describe_image 输出的是 `border_width`。"""
        tmp = os.path.join(TMP, "border")
        src, lp, crops, layout = _setup(tmp)
        out = os.path.join(tmp, "b.pptx")
        assert build(_args(src, lp, crops, out)) == 0
        xml = _slide_xml(out)
        assert "<a:ln" in xml, "描边元素整体缺失（border_width 未被识别）"
        w = re.search(r'<a:ln[^>]*w="(\d+)"', xml)
        assert w, "描边宽度缺失"
        # 2px @96dpi = 1.5pt = 19050 EMU
        assert abs(int(w.group(1)) - 19050) <= 2000, \
            f"描边宽度 {int(w.group(1))} EMU 与 2px(19050) 不符"

    def test_picture_is_contained_not_stretched(self):
        """素材比例与框不一致时必须等比 contain，不能拉伸。"""
        tmp = os.path.join(TMP, "pic")
        src, lp, crops, layout = _setup(tmp)
        # 200x100 的素材塞进 100x100 的框 → 只能缩成 100x50
        Image.new("RGB", (200, 100), (255, 0, 255)).save(
            os.path.join(crops, "wide.png"))
        layout["icons"] = [{"name": "wide", "box": [100, 300, 100, 100],
                            "role": "icon", "area": 10000}]
        lp = os.path.join(tmp, "layout2.json")
        with open(lp, "w", encoding="utf-8") as f:
            json.dump(layout, f, ensure_ascii=False)
        out = os.path.join(tmp, "p.pptx")
        assert build(_args(src, lp, crops, out)) == 0
        with zipfile.ZipFile(out) as z:
            slide = next(n for n in z.namelist()
                         if n.startswith("ppt/slides/slide") and n.endswith(".xml"))
            xml = z.read(slide).decode("utf-8")
        m = re.search(r'<p:pic>.*?<a:ext cx="(\d+)" cy="(\d+)"', xml, re.S)
        assert m, "没找到图片"
        cx, cy = int(m.group(1)) / 9525.0, int(m.group(2)) / 9525.0
        assert abs(cx / cy - 2.0) < 0.08, \
            f"图片显示尺寸 {cx:.0f}x{cy:.0f} 比例不是 2:1（被拉伸了）"


class TestInkAnalysis:

    def test_white_text_on_dark_band(self):
        """白字深底：字色必须接近白，ink 框要贴合墨迹。"""
        arr = np.zeros((60, 200, 3), dtype=np.uint8)
        arr[:, :] = (0x00, 0x42, 0xAC)
        img = Image.fromarray(arr)
        ImageDraw.Draw(img).text((20, 14), "启停优化", fill=(255, 255, 255),
                                 font=_font(28))
        img = img.convert("RGB")
        box, col = _ink_analysis(img, [20, 14, 120, 32])
        assert col is not None, "没取到字色"
        r, g, b = (int(col[i:i + 2], 16) for i in (1, 3, 5))
        assert min(r, g, b) > 190, f"白字被判成 {col}"
        assert box is not None
        assert box[2] <= 130 and box[3] <= 40, f"ink 框 {box} 明显超出墨迹"

    def test_dark_text_on_light_page(self):
        arr = np.full((60, 200, 3), 254, dtype=np.uint8)
        img = Image.fromarray(arr)
        ImageDraw.Draw(img).text((20, 14), "启停优化", fill=(10, 20, 30),
                                 font=_font(28))
        img = img.convert("RGB")
        box, col = _ink_analysis(img, [20, 14, 120, 32])
        assert col is not None
        r, g, b = (int(col[i:i + 2], 16) for i in (1, 3, 5))
        assert max(r, g, b) < 90, f"深字被判成 {col}"

    def test_uniform_box_returns_nothing(self):
        img = Image.new("RGB", (100, 100), (200, 200, 200))
        assert _ink_analysis(img, [10, 10, 50, 20]) == (None, None)


class TestFontFit:

    def test_fit_tracks_target_width(self):
        """字号拟合必须跟着目标宽度走：宽框给大字，窄框给小字。"""
        big, _ = _fit_font_size("启停优化", 240, 40, "微软雅黑", False)
        small, _ = _fit_font_size("启停优化", 60, 40, "微软雅黑", False)
        assert big > small * 2.5, f"宽度 240 → {big:.1f}pt，宽度 60 → {small:.1f}pt，不成比例"

    def test_fit_never_hits_the_ceiling(self):
        """回归：单位换算写错时所有字号都会顶到上限 400pt。"""
        pt, _ = _fit_font_size("12.480", 175, 54, "微软雅黑", False)
        assert pt < 100, f"字号 {pt:.1f}pt 顶到了上限，疑似单位换算错误"
