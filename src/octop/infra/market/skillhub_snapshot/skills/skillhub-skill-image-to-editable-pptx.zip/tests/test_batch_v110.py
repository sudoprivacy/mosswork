"""Regression cases for lost pages, page geometry, stale resumes and partial failures."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from PIL import Image, ImageDraw
from pptx import Presentation

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from batch_convert import collect_jobs

class BatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()
    def fixture(self, folder, size, text):
        p=self.d/folder;p.mkdir(parents=True)
        image=Image.new('RGB',size,'#103050')
        ImageDraw.Draw(image).text((20,20),text,fill='white')
        image.save(p/'same.png')
        layout={'source_size':list(size),'background':{'kind':'solid','fill':'#103050'},
                'texts':[{'text':text,'box':[20,20,100,40],'size_pt':18,
                          'box_mode':'frame','color':'#FFFFFF'}],
                'shapes':[{'type':'rect','name':'card','box':[20,80,100,50],
                           'fill':'#3377AA','z':1}],
                'review':{'text_verified':True,'inventory_complete':True}}
        (p/'layout.json').write_text(json.dumps(layout))
        return {'source':str(p/'same.png'),'layout':str(p/'layout.json')}
    def run_batch(self,jobs,*extra):
        manifest=self.d/'jobs.json';manifest.write_text(json.dumps({'jobs':jobs}))
        cmd=[sys.executable,str(ROOT/'scripts/batch_convert.py'),'--manifest',str(manifest),
             '-o',str(self.d/'out'),'--renderer','offscreen','--json',*extra]
        result=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        report=json.loads((self.d/'out/batch-report.json').read_text())
        return result,report
    def test_mixed_sizes_same_names_and_editability(self):
        jobs=[self.fixture('a',(640,360),'Alpha'),self.fixture('b',(360,640),'Beta')]
        run,r=self.run_batch(jobs)
        self.assertEqual(run.returncode,2,run.stderr)
        self.assertEqual(r['exported_count'],2)
        self.assertNotEqual(r['results'][0]['pptx'],r['results'][1]['pptx'])
        prs=Presentation(r['combined']);self.assertEqual(len(prs.slides),2)
        for page,label in zip(prs.slides,['Alpha','Beta']):
            self.assertIn(label,[s.text for s in page.shapes if s.has_text_frame])
            self.assertTrue(all(s.left>=0 and s.top>=0 and s.left+s.width<=prs.slide_width+2
                                and s.top+s.height<=prs.slide_height+2 for s in page.shapes))
        first=next(s for s in prs.slides[0].shapes if s.name=='card')
        second=next(s for s in prs.slides[1].shapes if s.name=='card')
        self.assertAlmostEqual(first.width/first.height,second.width/second.height,places=4)
        self.assertEqual(r['results'][1]['combined_slide'],2)
        self.assertEqual(r['merged_visual_qa']['status'],'not_run')
    def test_failure_isolated_order_reported(self):
        a=self.fixture('a',(640,360),'Alpha');b=self.fixture('b',(640,360),'Beta')
        run,r=self.run_batch([a,{'source':str(self.d/'absent.png')},b], '--allow-partial-merge')
        self.assertEqual(run.returncode,1)
        self.assertEqual([x['index'] for x in r['results']],[1,2,3])
        self.assertEqual(r['results'][1]['status'],'failed')
        self.assertEqual(r['exported_count'],2)
        self.assertEqual(len(Presentation(r['combined']).slides),2)
        self.assertEqual(r['results'][2]['combined_slide'],2)
    def test_incomplete_batch_does_not_silently_merge(self):
        a=self.fixture('a',(640,360),'Alpha')
        run,r=self.run_batch([a,{'source':str(self.d/'absent.png')}])
        self.assertEqual(run.returncode,1)
        self.assertEqual(r['exported_count'],1)
        self.assertIsNone(r['combined'])
        self.assertFalse(r['complete_export'])
        self.assertIn('Incomplete',r['merge_blocked_reason'])

    def test_resume_missing_output_rebuild_and_changed_layout(self):
        a=self.fixture('a',(640,360),'Before')
        _,r=self.run_batch([a]);old=r['results'][0]
        _,r=self.run_batch([a],'--resume');self.assertTrue(r['results'][0]['cached'])
        Path(old['pptx']).unlink()
        _,r=self.run_batch([a],'--resume');self.assertNotEqual(r['results'][0]['status'],'failed')
        lp=Path(a['layout']);layout=json.loads(lp.read_text());layout['texts'][0]['text']='After';lp.write_text(json.dumps(layout))
        _,r=self.run_batch([a],'--resume')
        self.assertNotEqual(old['fingerprint'],r['results'][0]['fingerprint'])
        self.assertIn('After',[s.text for s in Presentation(r['combined']).slides[0].shapes if s.has_text_frame])
    def test_input_sort_and_manifest_relative(self):
        folder=self.d/'images';folder.mkdir()
        for n in ['10.png','2.png','1.png']:Image.new('RGB',(10,10)).save(folder/n)
        self.assertEqual([Path(j['source']).name for j in collect_jobs([str(folder)])],['1.png','2.png','10.png'])
        manifest=self.d/'m.json';manifest.write_text(json.dumps({'jobs':[{'source':'images/10.png'},{'source':'images/2.png'}]}))
        jobs=collect_jobs([],manifest)
        self.assertEqual(Path(jobs[0]['source']),folder/'10.png')
    def test_missing_asset_does_not_fabricate_crop(self):
        a=self.fixture('a',(640,360),'Alpha');p=Path(a['layout']);layout=json.loads(p.read_text())
        layout['images']=[{'name':'photo','file':'missing.png','box':[150,80,50,50]}];p.write_text(json.dumps(layout))
        run,r=self.run_batch([a])
        self.assertEqual(run.returncode,1);self.assertIn('Missing asset',r['results'][0]['error'])
        self.assertIsNone(r['combined'])

if __name__=='__main__':unittest.main()
