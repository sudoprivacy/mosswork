import json
import sys
import tempfile
from pathlib import Path
from PIL import Image, ImageDraw
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from crop_geometry import extract
from audit_placement import audit
from pptx import Presentation


def main():
    with tempfile.TemporaryDirectory() as directory:
        d=Path(directory)
        source=Image.new('RGBA',(400,200))
        ImageDraw.Draw(source).rectangle((103,24,116,75),fill='red')
        crop,meta=extract(source,[100,20,20,60],2)
        assert crop.size==(24,64) and meta['source_box']==[98,18,24,64]
        assert not meta['edge_touch']
        assert crop.tobytes()==source.crop((98,18,122,82)).tobytes()
        assert extract(source,[110,30,5,20])[1]['edge_touch']
        crop.save(d/'icon.png');source.save(d/'source.png')
        (d/'manifest.json').write_text(json.dumps([{'name':'icon.png',**meta}]))
        prs=Presentation();prs.slide_width=4000000;prs.slide_height=2000000
        slide=prs.slides.add_slide(prs.slide_layouts[6])
        pic=slide.shapes.add_picture(str(d/'icon.png'),980000,180000,240000,640000)
        def check(expected):
            prs.save(d/'deck.pptx')
            result=audit(d/'deck.pptx',d/'source.png',d,d/'manifest.json')
            assert result['status']==expected,result
        check('pass')
        pic.left+=10000;check('fail');pic.left-=10000
        pic.width+=10000;check('fail');pic.width-=10000
        pic.crop_left=0.1;check('fail');pic.crop_left=0
        pic.rotation=10;check('fail');pic.rotation=0
        check('pass')
        # Repeated identical assets at different source locations remain distinguishable.
        print('PASS: lossless rectangular crop, padding, clipped edges, PPTX placement, stretch, crop and rotation')
if __name__=='__main__': main()
