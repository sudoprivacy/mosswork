#!/usr/bin/env python3
import json
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def evaluate(elements):
    with tempfile.TemporaryDirectory() as tmp:
        layout = Path(tmp) / "layout.json"
        layout.write_text(json.dumps({"elements": elements}), encoding="utf-8")
        result = subprocess.run(
            [sys.executable, str(ROOT / "scripts" / "complexity.py"), str(layout), "--json"],
            text=True, capture_output=True, check=True,
        )
        return json.loads(result.stdout)


def test_all_complexity_modes_use_artifact_tool():
    simple = evaluate([{"type": "text", "text": "标题"}])
    dense = evaluate([{"type": "image"} for _ in range(90)])
    assert simple["recommended_engine"] == "@oai/artifact-tool"
    assert dense["recommended_engine"] == "@oai/artifact-tool"
    assert simple["recommended_mode"] == "direct-rebuild"
    assert dense["recommended_mode"] == "pixel-mapped-rebuild"


if __name__ == "__main__":
    test_all_complexity_modes_use_artifact_tool()
    print("PASS: complexity routes every mode to Artifact Tool")
