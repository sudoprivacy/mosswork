#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""crop_assets.py 批量模式的回归。

3.4.0 的性能修复把「每张图标一次 subprocess」改成「一次进程裁完整批」。
这类优化最容易悄悄改变结果，所以这里逐条锁死：

1. 批量结果必须与单张模式**逐字节一致**（不能因为复用同一 PIL 对象而串味）。
2. 安全阀（去背景后不透明比例 < alpha-threshold）必须在批量里同样生效，
   且退回的是「不去背景」的版本。
3. 批量报告里的 source_box 必须反映 pad 后的真实裁剪框（下游据此对齐显示框，
   错 1px 就会被 validate_structure.py 判成 picture_aspect_drift）。
4. 单张越界不能拖垮整批：失败的 job 记为 ok=False，其余照常产出。
"""
import json
import os
import subprocess
import sys

from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
sys.path.insert(0, SCRIPTS)

from crop_assets import _crop_one  # noqa: E402

TMP = os.path.join(os.path.dirname(__file__), "_tmp_crop_batch")


def _source(path):
    """一张 200×120 的浅灰底，放三个各不相同的色块。"""
    im = Image.new("RGBA", (200, 120), (245, 245, 245, 255))
    d = ImageDraw.Draw(im)
    d.rectangle((20, 20, 49, 49), fill=(200, 60, 60, 255))    # 红块 30×30
    d.ellipse((80, 20, 119, 59), fill=(40, 120, 220, 255))    # 蓝圆 40×40
    d.rectangle((150, 30, 159, 89), fill=(30, 30, 30, 255))   # 深色细条 10×60
    im.save(path)
    return path


def test_batch_matches_single_mode_byte_for_byte():
    os.makedirs(TMP, exist_ok=True)
    src = _source(os.path.join(TMP, "src.png"))
    img = Image.open(src).convert("RGBA")
    W, H = img.size

    jobs = [
        {"name": "red", "x": 20, "y": 20, "w": 30, "h": 30},
        {"name": "blue", "x": 80, "y": 20, "w": 40, "h": 40},
        {"name": "bar", "x": 150, "y": 30, "w": 10, "h": 60},
    ]
    for job in jobs:
        # 批量：复用同一个 img，pad=2
        b_out = os.path.join(TMP, f"batch_{job['name']}.png")
        b_job = dict(job, out=b_out, metadata=b_out + ".json", pad=2)
        b = _crop_one(img, W, H, b_job)
        assert b["ok"], b
        # 单张：重新打开图片、独立调用，pad=2
        with Image.open(src) as fresh:
            s_out = os.path.join(TMP, f"single_{job['name']}.png")
            s_job = dict(job, out=s_out, metadata=s_out + ".json", pad=2)
            s = _crop_one(fresh.convert("RGBA"), W, H, s_job)
        assert s["ok"], s
        assert b["source_box"] == s["source_box"] == \
            [job["x"] - 2, job["y"] - 2, job["w"] + 4, job["h"] + 4]
        with open(b_out, "rb") as fb, open(s_out, "rb") as fs:
            assert fb.read() == fs.read(), f"{job['name']} 批量与单张不一致"


def test_safety_valve_falls_back_for_full_bleed_chip():
    """整块同色的芯片（例如满铺色块）去背景会被整张抹掉 → 必须退回不透明版本。"""
    os.makedirs(TMP, exist_ok=True)
    src = os.path.join(TMP, "solid.png")
    Image.new("RGBA", (60, 60), (90, 170, 255, 255)).save(src)
    img = Image.open(src).convert("RGBA")
    out = os.path.join(TMP, "solid_crop.png")
    res = _crop_one(img, 60, 60, {
        "name": "chip", "x": 10, "y": 10, "w": 40, "h": 40, "pad": 0,
        "out": out, "metadata": out + ".json",
        "transparent": True, "bg": "auto", "tolerance": 30,
    })
    assert res["ok"], res
    assert res["fallback"] is True
    assert res["transparent"] is False
    # 退回版本必须是完全不透明的实心色块
    with Image.open(out) as im:
        assert im.mode == "RGBA"
        assert im.getchannel("A").getextrema() == (255, 255)


def test_safety_valve_not_triggered_for_normal_icon():
    """正常图标（有大量前景）不应被误判为误删。"""
    os.makedirs(TMP, exist_ok=True)
    src = _source(os.path.join(TMP, "src2.png"))
    img = Image.open(src).convert("RGBA")
    out = os.path.join(TMP, "red_crop.png")
    res = _crop_one(img, 200, 120, {
        "name": "red", "x": 20, "y": 20, "w": 30, "h": 30, "pad": 2,
        "out": out, "metadata": out + ".json",
        "transparent": True, "bg": "F5F5F5", "tolerance": 30,
    })
    assert res["ok"], res
    assert res["fallback"] is False
    assert res["transparent"] is True


def test_out_of_bounds_job_does_not_abort_batch():
    os.makedirs(TMP, exist_ok=True)
    src = _source(os.path.join(TMP, "src3.png"))
    manifest = os.path.join(TMP, "manifest.json")
    report_path = os.path.join(TMP, "report.json")
    jobs = [
        {"name": "good", "x": 20, "y": 20, "w": 30, "h": 30,
         "out": os.path.join(TMP, "b_good.png"), "transparent": False},
        {"name": "bad", "x": 500, "y": 500, "w": 10, "h": 10,
         "out": os.path.join(TMP, "b_bad.png"), "transparent": False},
    ]
    with open(manifest, "w", encoding="utf-8") as f:
        json.dump({"image": src, "pad": 2, "jobs": jobs}, f)

    r = subprocess.run([sys.executable, os.path.join(SCRIPTS, "crop_assets.py"),
                        src, "--batch", manifest,
                        "--batch-report", report_path],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    with open(report_path, encoding="utf-8") as f:
        report = json.load(f)
    assert report["total"] == 2
    assert report["ok_count"] == 1
    by = {x["name"]: x for x in report["results"]}
    assert by["good"]["ok"] is True
    assert by["bad"]["ok"] is False and by["bad"].get("error")
    assert os.path.exists(jobs[0]["out"])
    assert not os.path.exists(jobs[1]["out"])
