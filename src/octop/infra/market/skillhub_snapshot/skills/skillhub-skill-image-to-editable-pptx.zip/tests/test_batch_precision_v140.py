"""Prevent dense OCR omissions and loss of measured page edits during continuation."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from tiled_ocr import positions, merge_candidates, recognize
from batch_state import continuation_job, sha256, write_continuation
from batch_convert import write_json, run_batch, process_job


class DenseOCRTests(unittest.TestCase):
    def test_right_and_bottom_strips_always_covered(self):
        for length in (719, 720, 721, 850, 941, 1672, 2010):
            starts = positions(length, 720, 160)
            self.assertEqual(starts[0], 0)
            self.assertEqual(min(length, starts[-1]+720), length)
            self.assertTrue(all(b <= a+720 for a,b in zip(starts,starts[1:])))

    def test_same_label_containment_deduplicated(self):
        rows = [{'text':'96%', 'box':[20,20,40,10], 'score':.98},
                {'text':'96%', 'box':[18,18,60,18], 'score':.96}]
        self.assertEqual(len(merge_candidates(rows)), 1)

    def test_different_cells_with_same_text_kept(self):
        rows = [{'text':'已归档','box':[20,y,40,10], 'score':.98} for y in (20,40,60)]
        self.assertEqual(len(merge_candidates(rows)),3)

    def test_names_disagree_require_review(self):
        rows = [{'text':'张杰','box':[20,20,40,10], 'score':.99},
                {'text':'张末','box':[20,20,40,10], 'score':.98}]
        merged=merge_candidates(rows)
        self.assertEqual(len(merged),1)
        self.assertTrue(merged[0]['needs_review'])
        self.assertIn('张末',merged[0]['alternatives'])

    def test_small_pages_also_get_zoom_pass(self):
        calls=[]
        def detect(path,engine):
            with Image.open(path) as im:
                calls.append(im.size)
            return []
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'source.png';Image.new('RGB',(400,300)).save(p)
            recognize(p,engine=object(),detector=detect)
        self.assertEqual(calls,[(400,300),(800,600)])

    def test_no_coordinates_outside_source(self):
        def detect(path,engine):
            return [{'text':'边缘','box':[190,110,15,15],'score':.99}]
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'source.png';Image.new('RGB',(100,60)).save(p)
            rows=recognize(p,engine=object(),detector=lambda path,engine:
                           [] if Path(path).name=='full.png' else detect(path,engine))
        for r in rows:
            x,y,w,h=r['box']
            self.assertLessEqual(x+w,100)
            self.assertLessEqual(y+h,60)


class ContinuationTests(unittest.TestCase):
    def test_continuation_binding_rejects_changed_source_same_dimensions(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);source=p/'source.png';Image.new('RGB',(80,60),'navy').save(source)
            job={'source':str(source),'layout':str(p/'layout.json'),
                 'layout_source_sha256':sha256(source),'layout_reference_bg':'FFFFFF'}
            Image.new('RGB',(80,60),'red').save(source)
            with self.assertRaisesRegex(ValueError,'Stale layout'):
                process_job(job,p,SimpleNamespace(reference_bg='FFFFFF'))

    def test_unchanged_prepared_pages_resume_without_repeating_ocr(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);source=p/'source.png';Image.new('RGB',(80,60),'navy').save(source)
            args=SimpleNamespace(sources=[str(source)],manifest=None,recursive=False,
                out_dir=str(p/'out'),resume=False,mode='layered',font_name='DejaVu Sans',
                renderer='offscreen',reference_bg='FFFFFF',max_rms=.15,
                separate_only=False,canvas=None,json=False,allow_partial_merge=False)
            with patch('tiled_ocr.recognize',return_value=[]) as ocr:
                self.assertEqual(run_batch(args),2)
                args.resume=True
                self.assertEqual(run_batch(args),2)
                self.assertEqual(ocr.call_count,1)
            report=json.loads((p/'out/batch-report.json').read_text())
            self.assertTrue(report['results'][0]['cached'])

    def test_resume_uses_measured_edits_not_draft(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);source=p/'src.png';Image.new('RGB',(40,30)).save(source)
            job={'source':str(source)}
            write_json(p/'input.json',{'source_sha256':sha256(source)})
            write_json(p/'layout.draft.json',{})
            self.assertNotIn('layout',continuation_job(job,p,True))
            write_json(p/'layout.json',{'texts':[{'text':'修复文字'}]})
            self.assertEqual(continuation_job(job,p,True)['layout'],str(p/'layout.json'))
            Image.new('RGB',(40,30),'red').save(source)
            self.assertNotIn('layout',continuation_job(job,p,True))

    def test_failed_pages_keep_order_in_queue(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);jobs=[];results=[]
            for i,status in enumerate(('needs_layout','failed','needs_review'),1):
                d=p/str(i);d.mkdir()
                jobs.append({'source':str(d/'source.png')})
                results.append({'index':i,'source':jobs[-1]['source'],
                                'status':status,'page_dir':str(d)})
            write_continuation(p,jobs,results,write_json)
            queue=json.loads((p/'work-queue.json').read_text())
            self.assertEqual([r['input_index'] for r in queue['pages']],[1,2,3])
            manifest=json.loads((p/'continue.json').read_text())
            self.assertEqual(manifest['jobs'],jobs)

    def test_explicit_manifest_repairs_point_to_authoritative_layout(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);page=p/'page';page.mkdir()
            external=p/'external.json';write_json(external,{'texts':[]})
            write_json(page/'layout.json',{'texts':[]})
            job={'source':str(p/'source.png'),'layout':str(external)}
            result={'index':1,'source':job['source'],'status':'needs_review',
                    'page_dir':str(page),'pptx':str(page/'editable.pptx')}
            write_continuation(p,[job],[result],write_json)
            q=json.loads((p/'work-queue.json').read_text())
            self.assertEqual(q['pages'][0]['measured_layout'],str(external))
            continuation=json.loads((p/'continue.json').read_text())
            self.assertEqual(continuation['jobs'][0]['layout'],str(external))


if __name__=='__main__':
    unittest.main()
