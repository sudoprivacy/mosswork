"""Check native effects, independent text and geometry in the actual exported XML."""
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
import zipfile
from PIL import Image
from lxml import etree
from pptx import Presentation
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from build_pptx_from_layout import build
from batch_convert import image_profile

class LayerTests(unittest.TestCase):
    def test_neon_polygon_connectors_gradient_text(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);Image.new('RGB',(640,360),'#07142E').save(p/'src.png')
            layout={'source_size':[640,360],'background':{'kind':'solid','fill':'#07142E'},
             'shapes':[
               {'name':'panel','type':'polygon','box':[40,80,400,120],
                'points':[[12,0],[388,0],[400,12],[400,108],[388,120],[12,120],[0,108],[0,12]],
                'fill':'#07142E','border':'#66DDFF','border_width':2,
                'glow':{'color':'#3344FF','radius':6}},
               {'name':'connector','type':'line','box':[240,200,0,60],
                'border':'#AAFFFF','border_width':2,'arrow_end':True}],
             'texts':[{'name':'header','text':'组织架构 15人','box':[60,95,300,60],
                       'box_mode':'frame','size_pt':26,'bold':True,'text_grad':['#FFFFCC','#FFDD33'],
                       'outline':{'color':'#332200','width':.5},'glow':{'radius':2,'color':'#2266FF'}}]}
            (p/'layout.json').write_text(json.dumps(layout))
            a=SimpleNamespace(source=str(p/'src.png'),layout=str(p/'layout.json'),crops=str(p/'crops'),
              out=str(p/'out.pptx'),font_name='DejaVu Sans',no_bg_blank=True,bg_blank_alpha=0)
            build(a)
            with zipfile.ZipFile(p/'out.pptx') as z:
                xml=z.read('ppt/slides/slide1.xml');etree.fromstring(xml)
            for token in [b'custGeom',b'glow',b'gradFill',b'tailEnd',b'cxnSp']:
                self.assertIn(token,xml)
            root=etree.fromstring(xml)
            ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
            self.assertTrue(all(n.get('idx')=='0' for n in root.findall('.//a:effectRef',ns)))
            prs=Presentation(p/'out.pptx');page=prs.slides[0]
            text=next(s for s in page.shapes if s.name=='header')
            self.assertEqual(text.text,'组织架构 15人')
            self.assertEqual(text.left,60*9525)
            self.assertEqual(text.top,95*9525)
            self.assertEqual(sum(s.shape_type==13 for s in page.shapes),0)
    def test_original_image_rejected_as_clean_background(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);Image.new('RGB',(200,100),'red').save(p/'src.png')
            layout={'source_size':[200,100],'background':{'kind':'image','file':'src.png',
                'role':'clean-background','contains_text':False,'reviewed':True},'texts':[]}
            (p/'layout.json').write_text(json.dumps(layout))
            a=SimpleNamespace(source=str(p/'src.png'),layout=str(p/'layout.json'),crops=str(p/'crops'),out=str(p/'out.pptx'),font_name='Arial')
            with self.assertRaisesRegex(ValueError,'Original screenshot'):build(a)
    def test_dimension_mismatch_fails(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);Image.new('RGB',(200,100),'red').save(p/'src.png')
            (p/'layout.json').write_text(json.dumps({'source_size':[400,200]}))
            a=SimpleNamespace(source=str(p/'src.png'),layout=str(p/'layout.json'),crops=str(p/'crops'),out=str(p/'out.pptx'),font_name='Arial')
            with self.assertRaisesRegex(ValueError,'尺寸'):build(a)

if __name__=='__main__':unittest.main()
