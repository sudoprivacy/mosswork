#!/usr/bin/env python3
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_reconstruction",
    ROOT / "scripts" / "verify_reconstruction.py",
)
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_overflow_error_text_fails_even_when_helper_returns_zero():
    assert MODULE.presentation_overflow_failed(
        0,
        "ERROR: Slides with content overflowing original canvas (1-based indexing): 1",
        "",
    )


def test_clean_overflow_check_passes():
    assert not MODULE.presentation_overflow_failed(0, "All slides fit inside the canvas", "")


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} reconstruction verifier tests")
