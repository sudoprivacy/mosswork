#!/usr/bin/env python3
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "audit_asset_manifest.py"


def run(assets, manifest, source):
    return subprocess.run(
        [
            sys.executable,
            str(SCRIPT),
            str(assets),
            "--manifest",
            str(manifest),
            "--source",
            str(source),
            "--json",
        ],
        text=True,
        capture_output=True,
        check=False,
    )


def smooth_icon(size):
    width, height = size
    icon = Image.new("RGBA", size, (20, 120, 220, 255))
    alpha = Image.new("L", size, 0)
    ImageDraw.Draw(alpha).ellipse((4, 4, width - 5, height - 5), fill=255)
    alpha = alpha.filter(ImageFilter.GaussianBlur(0.6))
    icon.putalpha(alpha)
    return icon


def source_with_icon(path, box=(10, 10, 18, 18)):
    source = Image.new("RGBA", (100, 100), (255, 255, 255, 0))
    icon = smooth_icon((box[2], box[3]))
    source.alpha_composite(icon, (box[0], box[1]))
    source.save(path)
    return icon


def test_single_transparent_subject_manifest_passes():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        assets = root / "assets"
        assets.mkdir()
        source = root / "source.png"
        source_icon = source_with_icon(source)
        source_icon.save(assets / "icon.png")
        manifest = root / "manifest.json"
        manifest.write_text(json.dumps([{
            "name": "icon.png",
            "role": "icon",
            "source_box": {"x": 10, "y": 10, "w": 18, "h": 18},
            "subject_count": 1,
            "contains_text": False,
            "background_removed": True,
        }]), encoding="utf-8")
        result = run(assets, manifest, source)
        assert result.returncode == 0, result.stdout + result.stderr


def test_card_slice_role_is_rejected_as_fake_split():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        assets = root / "assets"
        assets.mkdir()
        source = root / "source.png"
        Image.new("RGB", (100, 100), "white").save(source)
        Image.new("RGBA", (80, 20), (255, 255, 255, 255)).save(assets / "card.png")
        manifest = root / "manifest.json"
        manifest.write_text(json.dumps([{
            "name": "card.png",
            "role": "card",
            "source_box": [5, 5, 80, 20],
            "subject_count": 4,
            "contains_text": True,
            "background_removed": False,
        }]), encoding="utf-8")
        result = run(assets, manifest, source)
        assert result.returncode == 1
        payload = json.loads(result.stdout)
        assert any(item["kind"] == "forbidden_or_unknown_asset_role" for item in payload["findings"])


def test_abutting_source_boxes_are_rejected_as_tiled_screenshot_fragments():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        assets = root / "assets"
        assets.mkdir()
        source = root / "source.png"
        source_image = Image.new("RGBA", (100, 100), (255, 255, 255, 0))
        left_icon = smooth_icon((15, 15))
        right_icon = left_icon.copy()
        source_image.alpha_composite(left_icon, (10, 10))
        source_image.alpha_composite(right_icon, (25, 10))
        source_image.save(source)
        left_icon.save(assets / "left.png")
        right_icon.save(assets / "right.png")
        manifest = root / "manifest.json"
        manifest.write_text(json.dumps([
            {
                "name": "left.png", "role": "icon", "source_box": [10, 10, 15, 15],
                "subject_count": 1, "contains_text": False, "background_removed": True,
            },
            {
                "name": "right.png", "role": "icon", "source_box": [25, 10, 15, 15],
                "subject_count": 1, "contains_text": False, "background_removed": True,
            },
        ]), encoding="utf-8")
        result = run(assets, manifest, source)
        assert result.returncode == 1
        payload = json.loads(result.stdout)
        assert any(item["kind"] == "adjacent_source_tiles" for item in payload["findings"])


def test_redrawn_asset_cannot_hide_behind_a_valid_manifest():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        assets = root / "assets"
        assets.mkdir()
        source = root / "source.png"
        source_icon = source_with_icon(source)
        recolored = source_icon.copy()
        pixels = recolored.load()
        pixels[9, 9] = (255, 0, 0, pixels[9, 9][3])
        recolored.save(assets / "icon.png")
        manifest = root / "manifest.json"
        manifest.write_text(json.dumps([{
            "name": "icon.png", "role": "icon", "source_box": [10, 10, 18, 18],
            "subject_count": 1, "contains_text": False, "background_removed": True,
        }]), encoding="utf-8")
        result = run(assets, manifest, source)
        assert result.returncode == 1
        payload = json.loads(result.stdout)
        assert any(item["kind"] == "asset_redrawn_or_recolored" for item in payload["findings"])


if __name__ == "__main__":
    tests = [name for name in globals() if name.startswith("test_")]
    for name in tests:
        globals()[name]()
    print(f"PASS: {len(tests)} asset manifest tests")
