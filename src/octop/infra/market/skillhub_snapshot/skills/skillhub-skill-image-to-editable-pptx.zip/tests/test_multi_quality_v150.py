"""Batch precision must retain a separate, full-resolution review for each image."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from batch_convert import main


class MultiImageQualityTests(unittest.TestCase):
    def test_four_measured_pages_match_single_exports_and_resume_in_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            sources = []
            sizes = [(320, 180), (180, 320), (400, 240), (320, 180)]
            for index, size in enumerate(sizes, 1):
                folder = root / str(index)
                folder.mkdir()
                source = folder / 'same.png'
                Image.new('RGB', size, 'white').save(source)
                sources.append(str(source))
            out = root / 'batch'
            self.assertEqual(main([*sources, '-o', str(out), '--ocr', 'none', '--renderer', 'offscreen']), 2)
            queue = json.loads((out / 'work-queue.json').read_text())
            single_jobs = []
            for index, (page, size) in enumerate(zip(queue['pages'], sizes), 1):
                layout = {'source_size': list(size), 'background': {'kind': 'solid', 'fill': '#FFFFFF'},
                          'texts': [{'name': 'label', 'text': f'Page {index}: {index * 17}.5%',
                                     'box': [10.25, 20.5, 150.5, 40.25], 'box_mode': 'frame', 'size_pt': 12}],
                          'shapes': [{'name': 'card', 'type': 'rect', 'box': [10.25, 80.5, 140.5, 45.25],
                                      'fill': '#336699'}],
                          'review': {'inventory_complete': True, 'text_verified': True}}
                Path(page['measured_layout']).write_text(json.dumps(layout))
                single_jobs.append({'source': page['source'], 'layout': page['measured_layout']})
            self.assertEqual(main(['--manifest', str(out / 'continue.json'), '-o', str(out),
                                   '--resume', '--renderer', 'offscreen']), 2)
            report = json.loads((out / 'batch-report.json').read_text())
            self.assertEqual(report['exported_count'], 4)
            self.assertEqual(report['pending_count'], 0)
            self.assertEqual([p['combined_slide'] for p in report['results']], [1, 2, 3, 4])
            for index, (job, result) in enumerate(zip(single_jobs, report['results']), 1):
                manifest = root / f'single-{index}.json'
                manifest.write_text(json.dumps({'jobs': [job]}))
                single_out = root / f'one-{index}'
                self.assertEqual(main(['--manifest', str(manifest), '-o', str(single_out),
                                       '--renderer', 'offscreen', '--separate-only']), 2)
                single = json.loads((single_out / 'batch-report.json').read_text())['results'][0]
                with ZipFile(result['pptx']) as batch_zip, ZipFile(single['pptx']) as single_zip:
                    self.assertEqual(batch_zip.read('ppt/slides/slide1.xml'),
                                     single_zip.read('ppt/slides/slide1.xml'))

    def test_multiple_unmeasured_images_prepare_each_page_before_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            sources = []
            for index, size in enumerate(((320, 180), (180, 320)), 1):
                source = root / f'{index}.png'
                Image.new('RGB', size, 'white').save(source)
                sources.append(str(source))

            def automatic_layout(source, **_kwargs):
                with Image.open(source) as image:
                    width, height = image.size
                return {'source_size': [width, height], 'background': {'kind': 'solid', 'fill': '#FFFFFF'},
                        'texts': [{'name': 'title', 'text': 'Unreviewed', 'box': [10, 10, 100, 30],
                                   'box_mode': 'frame', 'size_pt': 12}]}

            with patch('describe_image.describe', side_effect=automatic_layout), \
                 patch('orchestrate.stage_crop', side_effect=lambda source, layout, page: (str(Path(page) / 'crops'), [])):
                exit_code = main([*sources, '-o', str(root / 'build'), '--renderer', 'offscreen'])

            report = json.loads((root / 'build' / 'batch-report.json').read_text())
            self.assertEqual(exit_code, 2)
            self.assertEqual(report['input_count'], 2)
            self.assertEqual(report['exported_count'], 0, 'Auto drafts for multiple images bypass individual measurement')
            self.assertEqual([page['status'] for page in report['results']], ['needs_layout'] * 2)
            self.assertIsNone(report['combined'])
            queue = json.loads((root / 'build' / 'work-queue.json').read_text())
            self.assertEqual([page['input_index'] for page in queue['pages']], [1, 2])
            self.assertTrue(all(Path(page['tasks']).is_file() for page in queue['pages']))


if __name__ == '__main__':
    unittest.main()
