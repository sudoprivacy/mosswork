import sys, json, csv

def to_csv(rows, path):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if rows:
            w.writerow(list(rows[0].keys()))
            for r in rows:
                w.writerow(list(r.values()))

def to_md(rows, path):
    if not rows:
        open(path, "w", encoding="utf-8").write("无数据")
        return
    keys = list(rows[0].keys())
    lines = []
    lines.append("| " + " | ".join(keys) + " |")
    lines.append("| " + " | ".join(["---"] * len(keys)) + " |")
    for r in rows:
        cells = [str(r.get(k, "")) for k in keys]
        lines.append("| " + " | ".join(cells) + " |")
    open(path, "w", encoding="utf-8").write("\n".join(lines))

def main():
    if len(sys.argv) < 4:
        print("用法: python export.py <input.json> <csv|md> <output>")
        return
    inp = sys.argv[1]
    fmt = sys.argv[2]
    out = sys.argv[3]
    rows = json.load(open(inp, encoding="utf-8"))
    if fmt == "csv":
        to_csv(rows, out)
    else:
        to_md(rows, out)
    print("已导出: " + out)

if __name__ == "__main__":
    main()
