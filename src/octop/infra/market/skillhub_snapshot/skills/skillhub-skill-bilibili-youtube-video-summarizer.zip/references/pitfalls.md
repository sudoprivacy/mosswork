# 踩坑经验与平台策略

> 本文件记录 bilibili-youtube-video-summarizer skill 在实战中积累的踩坑经验，供 AI 和用户参考。
> 作者: pomisun | 持续更新中

---

## B站 (bilibili)

### 反爬 412 错误
- **yt-dlp 直连 B站不可用**：即使加 UA、Referer 也会被 412 拦截
- **b23.tv 短链不可直接 curl/urllib**：同样被 412
- **解决方案**：必须用 `bilibili-api-python` 走官方 API 获取音频流 URL，再用 urllib 下载（需带 Referer 头）
- **b23.tv 短链解析**：必须用 AI 的 `web_fetch` 工具解析短链获取真实 BV 号 URL，脚本不处理短链

### bilibili-api 注意事项
- `get_download_url(page_index)` 的参数是分P索引（从0开始），不是清晰度
- `vresp['dash']['audio']` 返回音频流列表，按 bandwidth 排序取最高码率
- 下载音频流时**必须设置** `Referer: https://www.bilibili.com`，否则 403
- 多P视频用 `info['pages']` 获取分P列表，再传对应索引给 `get_download_url()`

### ffmpeg 格式兼容
- Whisper **不支持 `.m4s` 格式**输入，必须先转 `.mp3` 或 `.wav`
- 转换命令：`ffmpeg -i input.m4s -c:a libmp3lame -q:a 2 output.mp3 -y`（`-y` 覆盖已有文件）
- download.py 已自动集成此步骤

### ffmpeg 路径问题
- download.py 使用 `_find_ffmpeg()` 两级查找：系统 PATH -> imageio-ffmpeg 内置
- **新用户常见问题**：系统 PATH 中没有 ffmpeg，但 `pip install imageio-ffmpeg` 后即可自动识别
- `imageio-ffmpeg` 内置独立的 ffmpeg 二进制，无需配置环境变量，推荐作为默认安装方式
- `check_env.py --fix` 会自动安装 imageio-ffmpeg 解决此问题

---

## YouTube

### 反爬（2026 更新）
- **yt-dlp 需要 deno**：2026 版 yt-dlp 需要 deno JS 运行时，不装会 warning 但仍可部分工作
- **yt-dlp 需要 cookie**：YouTube 强制 "Sign in to confirm you're not a bot"，无 cookie 无法下载
- **`--cookies-from-browser chrome`**：Chrome DPAPI 解密在远程/部分环境失败（issue #7271）
- **`--cookies-from-browser edge`**：Edge 也可能 DPAPI 失败（issue #10927）
- **`player_client=tv/mweb`**：所有客户端模式均被 block，无法绕过 cookie 要求

### YouTube 字幕 API（推荐方案）
- **youtube-transcript-api 更好**：字幕 API 不需要 cookie，且不受下载限制
- **IP 限流**：请求过频会被临时 block（约 300 次/小时），等待 1 小时后恢复
- 字幕获取和音频下载共享限流计数
- **YouTube 翻译只有繁体**：`translate()` 方法只支持 `zh-Hant`，不支持 `zh-Hans`
- **推荐用 AI 翻译**：由 LLM 读取原文字幕并翻译为流畅简体中文，质量远高于机器翻译

---

## Whisper 使用
- **v3.1 双引擎**：默认 faster-whisper（CTranslate2），可选 openai-whisper（`--engine openai`）
- **faster-whisper**：比 openai-whisper 快 3-4 倍，默认安装
- **openai-whisper**：不默认安装，需要时 `pip install openai-whisper`；在极少数情况下转写质量更好
- 首次运行会自动下载模型文件（medium 约 1.5GB），需要网络
- 长音频（>30分钟）转写较慢，可提前告知用户预估时间
- 中文视频建议指定 `--language zh` 提高准确率
- **VAD 默认开启**（仅 faster 引擎）：自动跳过静音段，额外提速 20-40%，遇到截断问题可 `--no-vad` 关闭
- 时间预估（medium 模型 + VAD）：10 分钟音频 ≈ 1-2 分钟（GPU）/ 4-7 分钟（CPU）
- **turbo 模型**：faster-whisper 专属，速度最快但中文准确率略低于 medium
- **自动设备选择**（仅 faster 引擎）：检测到 CUDA 时用 GPU + float16，否则 CPU + int8
- **何时切 openai 引擎**：faster-whisper 出现漏词、断句异常、时间戳漂移时，加 `--engine openai` 试试

---

## 平台策略总结

| 平台 | 获取方式 | 速度 | 限制 | 推荐方案 |
|------|---------|------|------|---------|
| **B站** | bilibili-api-python 下载音频 | 慢 | 412 反爬（用 API 绕过） | API 下载 → 自动转 mp3 → Whisper |
| **YouTube（有字幕）** | youtube-transcript-api 拉字幕 | 快 | IP 限流（300/h） | fetch_subtitle.py → AI 翻译 |
| **YouTube（无字幕）** | yt-dlp 下载音频 | 慢 | 需 cookie + deno | download.py → Whisper → AI 翻译 |
