---
name: skillhub-skill-bilibili-youtube-video-summarizer
description: "# bilibili-youtube-video-summarizer"
---

# bilibili-youtube-video-summarizer

> 视频 → 音频/字幕 → 转文字 → 翻译(如非中文) → 结构化总结

**作者**: pomisun | **版本**: 3.2.1 | **协议**: MIT | **Python**: >= 3.10

## 文件清单

| 文件 | 说明 |
|------|------|
| `scripts/check_env.py` | 环境自检（一键检查所有依赖） |
| `scripts/download.py` | 音频下载（B站自动转mp3 / YouTube yt-dlp） |
| `scripts/fetch_subtitle.py` | YouTube字幕获取（youtube-transcript-api） |
| `scripts/transcribe.py` | faster-whisper转文字（支持txt/md/srt/vtt，内置VAD） |
| `references/pitfalls.md` | 踩坑经验与平台策略（遇到问题时查阅） |

---

## Step 0：环境检查

首次使用或遇到依赖问题时，运行环境自检：

```bash
python <skill-path>/scripts/check_env.py
# 自动安装缺失的Python包：
python <skill-path>/scripts/check_env.py --fix
```

核心依赖：Python >= 3.10、ffmpeg（系统安装或 `pip install imageio-ffmpeg` 均可）、faster-whisper。有 NVIDIA GPU 时自动检测并启用 CUDA 加速（首次会自动安装 CUDA 版 PyTorch）。可选 openai-whisper（高质量回退）。B站还需 bilibili-api-python，YouTube 还需 yt-dlp + deno + youtube-transcript-api。

---

## Step 1：识别平台 & 解析 URL

根据 URL 判断平台：

| 平台 | URL 特征 | 示例 |
|------|---------|------|
| B站 | `bilibili.com`, `b23.tv` | `https://www.bilibili.com/video/BV1xxx` |
| YouTube | `youtube.com`, `youtu.be` | `https://www.youtube.com/watch?v=xxx` |

**B站短链 (b23.tv)** 会被 412 反爬拦截。必须先用 `web_fetch` 工具解析短链获取真实 BV 号 URL：

```
web_fetch(url="https://b23.tv/xxxxx", fetchInfo="提取重定向后的真实B站视频URL")
```

---

## Step 2：获取内容

### 路线A：B站 → download.py 下载音频

> ⚡ **默认下载最低清晰度音频**（`--quality low`），转文字完全够用且省时省空间。仅当用户明确要求高音质时才传 `--quality high`。

```bash
# 基本下载（默认低清晰度，自动转mp3）
python <skill-path>/scripts/download.py --url "https://www.bilibili.com/video/BVxxx" --output "./output/video1"

# 多P视频指定第3P
python <skill-path>/scripts/download.py --url "https://www.bilibili.com/video/BVxxx" --output "./output/ep3" --page 3

# 用户要求高音质时
python <skill-path>/scripts/download.py --url "..." --output "..." --quality high

# 登录态下载（会员/高清）
python <skill-path>/scripts/download.py --url "..." --output "..." --sessdata "YOUR_SESSDATA"
```

输出：`{output}.mp3`（已自动从 m4s 转换，临时文件已清理）

### 路线B：YouTube 有字幕 → fetch_subtitle.py（推荐，快速）

```bash
# 列出可用字幕语言
python <skill-path>/scripts/fetch_subtitle.py --url "https://www.youtube.com/watch?v=xxx" --list

# 获取英文字幕
python <skill-path>/scripts/fetch_subtitle.py --url "..." --output "sub.txt" --lang en

# Markdown格式输出
python <skill-path>/scripts/fetch_subtitle.py --url "..." --output "sub.md" --lang en --format md
```

获取后由 AI 翻译为中文（质量远优于机器翻译）。

### 路线C：YouTube 无字幕 → download.py 下载音频

> ⚡ 同样默认低清晰度。用户要求时传 `--quality high`。

```bash
python <skill-path>/scripts/download.py --url "https://www.youtube.com/watch?v=xxx" --output "./output/yt1" --browser edge

# 用户要求高音质时
python <skill-path>/scripts/download.py --url "..." --output "..." --quality high --browser edge
```

需要浏览器已登录 YouTube（cookie 认证）。

**YouTube 优先级**：先试路线B（字幕API），无字幕再走路线C。

---

## Step 3：转文字（双引擎，仅音频需要）

> v3.2 双引擎 + GPU 自动检测：默认 faster-whisper（快 3-4 倍 + VAD），自动检测 NVIDIA GPU 并启用 CUDA 加速（首次自动安装 CUDA 版 PyTorch）。遇到质量问题可切 openai-whisper。
> openai-whisper 不默认安装，需要时 `pip install openai-whisper`。

```bash
# 默认 faster-whisper（快速）
python <skill-path>/scripts/transcribe.py --input "audio.mp3" --output "text.md" --format md --language zh

# 高质量模式（openai-whisper，需先安装）
python <skill-path>/scripts/transcribe.py --input "audio.mp3" --output "text.md" --format md --language zh --engine openai

# SRT字幕输出
python <skill-path>/scripts/transcribe.py --input "audio.mp3" --output "sub.srt" --format srt

# 批量转写目录
python <skill-path>/scripts/transcribe.py --input "./audios" --output "./texts" --format md

# 关闭VAD（仅faster引擎）
python <skill-path>/scripts/transcribe.py --input "audio.mp3" --output "text.txt" --no-vad
```

| 参数 | 说明 |
|------|------|
| `--engine` | `faster`(默认,快速) / `openai`(高质量,需另装) |
| `--format` | `txt`(默认) / `md`(Markdown) / `srt`(字幕) / `vtt`(WebVTT) |
| `--model` | `tiny`/`base`/`small`/`medium`(默认)/`large-v3`; faster还支持`turbo` |
| `--language` | `zh`/`en`/`ja`等，不指定则自动检测 |
| `--title` | Markdown 输出的标题 |
| `--no-vad` | 关闭 VAD 静音过滤（仅 faster 引擎，默认开启） |

faster 引擎自动检测 GPU（CUDA），有则 GPU + float16，否则 CPU + int8。

**中文视频建议指定 `--language zh`**，可提高识别准确率。

**模型推荐**：日常用 `medium`（平衡速度和质量），追求速度用 `turbo`（仅faster），高精度用 `large-v3`。

**何时切 openai 引擎**：faster-whisper 在极少数情况下可能出现漏词/断句异常，此时加 `--engine openai` 可能改善。

---

## Step 4：翻译（非中文内容）

若检测到非中文内容（脚本会提示），由 AI 直接翻译为流畅简体中文：

1. 读取转写/字幕文本
2. AI 翻译为简体中文（保留时间戳）
3. 输出中英对照关键术语表

> 不推荐 YouTube 内置翻译（仅支持繁体 `zh-Hant`），AI 翻译质量远高于机器翻译。

---

## Step 5：生成总结

读取转写/翻译文本，生成结构化总结：

1. **基本信息**：视频标题、UP主/频道、时长
2. **核心观点**：按主题分章节，每章列要点
3. **关键数据**：视频中提到的具体数字、比例
4. **可执行建议**（如适用）
5. **中英对照**（非中文视频，关键术语对照表）

---

## 快速参考

**决策树**：
```
URL → B站？ → download.py → mp3 → transcribe.py → 总结
     YouTube？ → 有字幕？ → fetch_subtitle.py → AI翻译 → 总结
                  无字幕？ → download.py → mp3 → transcribe.py → AI翻译 → 总结
```

**遇到问题**：查阅 `references/pitfalls.md`
