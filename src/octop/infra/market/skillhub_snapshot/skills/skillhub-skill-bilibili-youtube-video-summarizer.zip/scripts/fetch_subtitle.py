#!/usr/bin/env python3
"""
YouTube 字幕获取脚本 - 使用 youtube-transcript-api

作者: pomisun
协议: MIT

优先走字幕API（快速、不受cookie限制），用于YouTube有字幕的视频。
无字幕时自动提示改用 yt-dlp + Whisper 方案。

用法:
  # 获取英文字幕
  python fetch_subtitle.py --video-id "dQw4w9WgXcQ" --output "subtitle.txt"

  # 获取中文字幕
  python fetch_subtitle.py --video-id "dQw4w9WgXcQ" --output "subtitle.txt" --lang zh

  # 获取英文字幕并输出为 SRT 格式
  python fetch_subtitle.py --video-id "dQw4w9WgXcQ" --output "subtitle.srt" --format srt

  # 列出所有可用字幕语言
  python fetch_subtitle.py --video-id "dQw4w9WgXcQ" --list

  # 从完整 YouTube URL 提取
  python fetch_subtitle.py --url "https://www.youtube.com/watch?v=dQw4w9WgXcQ" --output "sub.txt"
"""

import argparse
import os
import re
import sys


def extract_video_id(url: str) -> str:
    """从 YouTube URL 提取 video_id"""
    patterns = [
        r'(?:v=|/v/|youtu\.be/|/embed/)([a-zA-Z0-9_-]{11})',
        r'(?:shorts/)([a-zA-Z0-9_-]{11})',
    ]
    for pat in patterns:
        match = re.search(pat, url)
        if match:
            return match.group(1)
    raise ValueError(f"无法从URL提取video_id: {url}")


def format_timestamp_short(seconds: float) -> str:
    """短格式时间戳 mm:ss 或 hh:mm:ss"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def format_timestamp_srt(seconds: float) -> str:
    """SRT格式时间戳 hh:mm:ss,mmm"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def format_timestamp_vtt(seconds: float) -> str:
    """VTT格式时间戳 hh:mm:ss.mmm"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


def list_available_transcripts(video_id: str):
    """列出视频的所有可用字幕"""
    from youtube_transcript_api import YouTubeTranscriptApi

    api = YouTubeTranscriptApi()
    transcript_list = api.list(video_id)

    print(f"[YouTube] video_id: {video_id}")
    print(f"[YouTube] 可用字幕：\n")

    for t in transcript_list:
        kind = "手动" if not t.is_generated else "自动生成"
        translatable = "可翻译" if t.is_translatable else ""
        print(f"  {t.language_code:<6} {t.language:<20} [{kind}] {translatable}")

    return transcript_list


def fetch_transcript(video_id: str, lang: str = "en") -> list:
    """获取指定语言的字幕"""
    from youtube_transcript_api import YouTubeTranscriptApi

    api = YouTubeTranscriptApi()

    # 尝试多种语言回退
    lang_fallbacks = [lang]
    if lang == "zh":
        lang_fallbacks = ["zh-Hans", "zh-CN", "zh", "zh-Hant", "zh-TW"]
    elif lang == "en":
        lang_fallbacks = ["en", "en-US", "en-GB"]

    # 先尝试手动字幕，再试自动生成
    try:
        transcript = api.fetch(video_id, languages=lang_fallbacks)
        entries = []
        for snippet in transcript:
            entries.append({
                "start": snippet.start,
                "duration": snippet.duration,
                "text": snippet.text
            })
        return entries
    except Exception as e:
        raise RuntimeError(
            f"无法获取 {lang} 字幕: {e}\n"
            f"请用 --list 查看可用字幕语言，或改用 yt-dlp + Whisper 方案"
        )


def save_txt(entries: list, output_path: str, with_timestamps: bool = True):
    """保存为纯文本"""
    with open(output_path, "w", encoding="utf-8") as f:
        for e in entries:
            if with_timestamps:
                ts = format_timestamp_short(e["start"])
                f.write(f"[{ts}] {e['text']}\n")
            else:
                f.write(f"{e['text']}\n")


def save_srt(entries: list, output_path: str):
    """保存为 SRT 字幕"""
    with open(output_path, "w", encoding="utf-8") as f:
        for i, e in enumerate(entries, 1):
            start = format_timestamp_srt(e["start"])
            end = format_timestamp_srt(e["start"] + e["duration"])
            f.write(f"{i}\n{start} --> {end}\n{e['text']}\n\n")


def save_vtt(entries: list, output_path: str):
    """保存为 WebVTT 字幕"""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("WEBVTT\n\n")
        for i, e in enumerate(entries, 1):
            start = format_timestamp_vtt(e["start"])
            end = format_timestamp_vtt(e["start"] + e["duration"])
            f.write(f"{i}\n{start} --> {end}\n{e['text']}\n\n")


def save_md(entries: list, output_path: str, video_id: str = None, lang: str = None):
    """保存为 Markdown"""
    total_duration = entries[-1]["start"] + entries[-1]["duration"] if entries else 0
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(f"# YouTube 字幕\n\n")
        if video_id:
            f.write(f"- **视频**: https://www.youtube.com/watch?v={video_id}\n")
        if lang:
            f.write(f"- **语言**: {lang}\n")
        f.write(f"- **时长**: {format_timestamp_short(total_duration)}\n")
        f.write(f"- **条目数**: {len(entries)}\n\n---\n\n")

        chapter_interval = 300
        current_chapter = -1
        for e in entries:
            chapter = int(e["start"] // chapter_interval)
            if chapter > current_chapter:
                current_chapter = chapter
                cs = format_timestamp_short(chapter * chapter_interval)
                f.write(f"\n## [{cs}]\n\n")
            ts = format_timestamp_short(e["start"])
            f.write(f"**[{ts}]** {e['text']}\n\n")


def main():
    parser = argparse.ArgumentParser(
        description="YouTube 字幕获取工具 — youtube-transcript-api",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--video-id", help="YouTube video ID")
    group.add_argument("--url", help="YouTube URL (自动提取video_id)")

    parser.add_argument("--output", help="输出文件路径")
    parser.add_argument("--lang", default="en", help="字幕语言代码 (默认en)")
    parser.add_argument("--format", default="txt", choices=["txt", "md", "srt", "vtt"],
                        help="输出格式 (默认txt)")
    parser.add_argument("--list", action="store_true", help="仅列出可用字幕语言")
    parser.add_argument("--no-timestamps", action="store_true", help="纯文本不含时间戳")
    args = parser.parse_args()

    # 获取 video_id
    if args.url:
        video_id = extract_video_id(args.url)
        print(f"[YouTube] 提取 video_id: {video_id}")
    else:
        video_id = args.video_id

    # 列出字幕
    if args.list:
        list_available_transcripts(video_id)
        return

    # 获取字幕
    if not args.output:
        print("[错误] 请指定 --output 输出文件路径")
        sys.exit(1)

    print(f"[YouTube] 获取 {args.lang} 字幕...")
    entries = fetch_transcript(video_id, args.lang)

    if not entries:
        print(f"[YouTube] [WARN] 获取到空字幕（0条），可能字幕文件存在但无内容")
        print(f"[YouTube] 建议改用 yt-dlp + Whisper 方案")
        sys.exit(1)

    total_duration = entries[-1]["start"] + entries[-1]["duration"]
    print(f"[YouTube] 获取到 {len(entries)} 条字幕，总时长 {format_timestamp_short(total_duration)}")

    # 保存
    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)

    if args.format == "srt":
        save_srt(entries, args.output)
    elif args.format == "vtt":
        save_vtt(entries, args.output)
    elif args.format == "md":
        save_md(entries, args.output, video_id=video_id, lang=args.lang)
    else:
        save_txt(entries, args.output, with_timestamps=not args.no_timestamps)

    print(f"[YouTube] 已保存: {args.output}")

    # 非中文提示
    if args.lang not in ["zh", "zh-Hans", "zh-CN", "zh-Hant", "zh-TW"]:
        print(f"\n[TIP] 字幕为非中文({args.lang})，建议用 AI 翻译为中文")


if __name__ == "__main__":
    main()
