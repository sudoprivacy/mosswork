#!/usr/bin/env python3
"""
音频转文字脚本 v3.2.1 - GPU 自动检测与安装 (faster-whisper / openai-whisper)

作者: pomisun
协议: MIT

变更日志（v3.2）:
  - [新增] 自动检测 NVIDIA GPU，若 PyTorch 为 CPU 版则自动安装 CUDA 版
  - [新增] 安装完成后提示重新运行，下次启动直接走 GPU
  - [改进] GPU/CPU 设备选择统一由 _ensure_gpu_pytorch() 管理

变更日志（v3.1）:
  - [新增] 双引擎：默认 faster-whisper（快），可选 openai-whisper（高质量回退）
  - [新增] --engine faster/openai 参数切换引擎
  - openai-whisper 不默认安装，需要时再 pip install openai-whisper

变更日志（v3.0）:
  - [重大] 底层引擎从 openai-whisper 切换到 faster-whisper (3-4x 加速)
  - [重大] 内置 VAD 静音过滤 (默认开启，额外 20-40% 提速)
  - 自动检测 CUDA GPU，有则用 GPU + float16，否则 CPU + int8
  - --no-vad 参数可关闭 VAD（调试用）
  - 支持 turbo 模型 (faster-whisper 专属，速度最快)

变更日志（v2.1）:
  - 自动输出检测到的语言
  - 支持多种输出格式：txt / md / srt / vtt
  - 转写进度实时显示（按 segment 打印）
  - Markdown 格式输出带标题和时间戳章节
  - SRT/VTT 格式输出可直接作为字幕文件

用法:
  # 基本使用（默认 faster-whisper）
  python transcribe.py --input "audio.mp3" --output "transcript.txt"

  # 高质量模式（openai-whisper，需先 pip install openai-whisper）
  python transcribe.py --input "audio.mp3" --output "transcript.txt" --engine openai

  # 指定语言 + Markdown 输出
  python transcribe.py --input "audio.mp3" --output "transcript.md" --format md --language zh

  # SRT 字幕格式
  python transcribe.py --input "audio.mp3" --output "subtitle.srt" --format srt

  # 批量转写目录
  python transcribe.py --input "./audios" --output "./texts" --format md

  # 关闭 VAD（调试用，仅 faster 引擎）
  python transcribe.py --input "audio.mp3" --output "text.txt" --no-vad
"""

import argparse
import os
import subprocess
import sys
import time


# ──────────────────────────────────────────────
# GPU PyTorch 自动检测与安装
# ──────────────────────────────────────────────

def _ensure_gpu_pytorch():
    """
    检测是否有 NVIDIA GPU，如果有但当前 PyTorch 是 CPU 版，
    自动安装 CUDA 版 PyTorch 并提示用户重新运行。
    返回 True 表示 GPU 可用，False 表示只能用 CPU。
    """
    # 1. 检查是否有 NVIDIA GPU
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0:
            return False  # 没有 NVIDIA GPU 或驱动未装
        gpu_name = r.stdout.strip().split("\n")[0]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False  # nvidia-smi 不存在

    # 2. 检查 PyTorch 是否支持 CUDA
    try:
        import torch
        if torch.cuda.is_available():
            print(f"[Whisper] GPU 就绪: {gpu_name}")
            return True
        # torch 已装但是 CPU 版
        cpu_version = "+cpu" in torch.__version__
    except ImportError:
        cpu_version = True  # torch 都没装

    if not cpu_version:
        # 有 torch，没有 +cpu 标记，但 CUDA 不可用（可能 CUDA 版本不匹配）
        print(f"[WARN] 检测到 GPU ({gpu_name}) 但 PyTorch CUDA 不可用，将使用 CPU")
        return False

    # 3. 自动安装 CUDA 版 PyTorch
    print(f"[Whisper] 检测到 GPU: {gpu_name}")
    print(f"[Whisper] 当前 PyTorch 为 CPU 版，正在自动安装 CUDA 版...")
    print(f"[Whisper] (首次安装约需 2-5 分钟，之后不再重复)")
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install",
             "--force-reinstall", "torch", "torchaudio",
             "--index-url", "https://download.pytorch.org/whl/cu126",
             "--quiet", "--no-warn-script-location"],
            timeout=600,
        )
        print(f"[OK] CUDA 版 PyTorch 安装完成")
        print(f"[Whisper] 请重新运行本命令以启用 GPU 加速")
        sys.exit(0)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        print(f"[WARN] CUDA 版 PyTorch 自动安装失败: {e}")
        print(f"[TIP] 可手动运行: pip install --force-reinstall torch torchaudio --index-url https://download.pytorch.org/whl/cu126")
        print(f"[Whisper] 将继续使用 CPU 模式")
        return False


# ──────────────────────────────────────────────
# 时间戳格式化
# ──────────────────────────────────────────────

def format_timestamp(seconds: float, style: str = "short") -> str:
    """
    格式化时间戳。
    style='short': 00:00 或 00:00:00
    style='srt':   00:00:00,000
    style='vtt':   00:00:00.000
    """
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds - int(seconds)) * 1000)

    if style == "srt":
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
    elif style == "vtt":
        return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"
    else:
        if h > 0:
            return f"{h:02d}:{m:02d}:{s:02d}"
        return f"{m:02d}:{s:02d}"


# ──────────────────────────────────────────────
# 语言名称映射
# ──────────────────────────────────────────────

LANG_NAMES = {
    "zh": "中文", "en": "英语", "ja": "日语", "ko": "韩语",
    "fr": "法语", "de": "德语", "es": "西班牙语", "ru": "俄语",
    "pt": "葡萄牙语", "it": "意大利语", "ar": "阿拉伯语",
    "hi": "印地语", "th": "泰语", "vi": "越南语",
}


def get_lang_display(code: str) -> str:
    """获取语言的中文显示名"""
    return LANG_NAMES.get(code, code)


# ──────────────────────────────────────────────
# 转写
# ──────────────────────────────────────────────

def _print_result_stats(engine_name: str, segments: list, detected_lang: str,
                        lang_prob: float, elapsed: float):
    """打印转写结果统计（双引擎共用）"""
    lang_display = get_lang_display(detected_lang)
    total_duration = segments[-1]["end"] if segments else 0

    prob_str = f" (置信度: {lang_prob:.0%})" if lang_prob > 0 else ""
    print(f"[Whisper] 检测语言: {lang_display} ({detected_lang}){prob_str}")
    if not segments:
        print(f"[Whisper] [WARN] 未识别到任何语音片段（可能是纯静音/纯音乐文件）")
    else:
        print(f"[Whisper] 音频时长: {format_timestamp(total_duration)}")
        if elapsed > 0:
            print(f"[Whisper] 转写耗时: {elapsed:.1f}秒 (速比: {total_duration/elapsed:.1f}x)")
        print(f"[Whisper] 共 {len(segments)} 个片段")


def transcribe_file_faster(model, input_path: str, language: str = None,
                           use_vad: bool = True) -> dict:
    """
    使用 faster-whisper 引擎转写（默认引擎，快速）。

    返回统一 dict：
      {"language": str, "text": str, "segments": [{"start", "end", "text"}, ...]}
    """
    filename = os.path.basename(input_path)
    file_size_mb = os.path.getsize(input_path) / (1024 * 1024)
    print(f"[Whisper] 转写中: {filename} ({file_size_mb:.1f} MB)")
    vad_label = "ON" if use_vad else "OFF"
    print(f"[Whisper] 引擎: faster-whisper | VAD: {vad_label}")

    start_time = time.time()

    # faster-whisper transcribe → (generator, info)
    segments_gen, info = model.transcribe(
        input_path,
        language=language,
        beam_size=5,
        vad_filter=use_vad,
        vad_parameters=dict(min_silence_duration_ms=500) if use_vad else None,
    )

    # 收集 segments（generator 在迭代时才实际转写）
    segments = []
    full_text_parts = []
    for seg in segments_gen:
        segments.append({
            "start": seg.start,
            "end": seg.end,
            "text": seg.text,
        })
        full_text_parts.append(seg.text.strip())

    elapsed = time.time() - start_time
    detected_lang = info.language if info.language else "unknown"
    lang_prob = info.language_probability if hasattr(info, "language_probability") else 0
    _print_result_stats("faster-whisper", segments, detected_lang, lang_prob, elapsed)

    return {
        "language": detected_lang,
        "text": " ".join(full_text_parts),
        "segments": segments,
    }


def transcribe_file_openai(model, input_path: str, language: str = None) -> dict:
    """
    使用 openai-whisper 引擎转写（高质量回退）。

    返回统一 dict：
      {"language": str, "text": str, "segments": [{"start", "end", "text"}, ...]}
    """
    filename = os.path.basename(input_path)
    file_size_mb = os.path.getsize(input_path) / (1024 * 1024)
    print(f"[Whisper] 转写中: {filename} ({file_size_mb:.1f} MB)")
    print(f"[Whisper] 引擎: openai-whisper (高质量模式)")

    start_time = time.time()
    result = model.transcribe(input_path, language=language, verbose=False)
    elapsed = time.time() - start_time

    detected_lang = result.get("language", "unknown")
    raw_segments = result.get("segments", [])

    # 统一为标准 dict 列表
    segments = [{"start": s["start"], "end": s["end"], "text": s["text"]} for s in raw_segments]
    _print_result_stats("openai-whisper", segments, detected_lang, 0, elapsed)

    return {
        "language": detected_lang,
        "text": result.get("text", "").strip(),
        "segments": segments,
    }


def transcribe_file(model, input_path: str, language: str = None,
                    use_vad: bool = True, engine: str = "faster") -> dict:
    """统一转写入口，按 engine 分发到对应引擎。"""
    if engine == "openai":
        return transcribe_file_openai(model, input_path, language)
    else:
        return transcribe_file_faster(model, input_path, language, use_vad)


# ──────────────────────────────────────────────
# 输出格式
# ──────────────────────────────────────────────

def save_txt(result: dict, output_path: str, with_timestamps: bool = True):
    """保存为纯文本"""
    with open(output_path, "w", encoding="utf-8") as f:
        if with_timestamps:
            for seg in result["segments"]:
                ts = format_timestamp(seg["start"])
                text = seg["text"].strip()
                f.write(f"[{ts}] {text}\n")
        else:
            f.write(result["text"].strip())


def save_markdown(result: dict, output_path: str, title: str = None):
    """保存为 Markdown 格式（带章节标记）"""
    segments = result.get("segments", [])
    detected_lang = result.get("language", "unknown")
    lang_display = get_lang_display(detected_lang)
    total_duration = segments[-1]["end"] if segments else 0

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(f"# {title or '转录文稿'}\n\n")
        f.write(f"- **语言**: {lang_display} ({detected_lang})\n")
        f.write(f"- **时长**: {format_timestamp(total_duration)}\n")
        f.write(f"- **片段数**: {len(segments)}\n\n")
        f.write(f"---\n\n")

        if not segments:
            f.write("> 未识别到任何语音片段（可能是纯静音/纯音乐文件）\n")
            return

        # 每5分钟一个章节
        chapter_interval = 300  # 5分钟
        current_chapter = -1

        for seg in segments:
            chapter = int(seg["start"] // chapter_interval)
            if chapter > current_chapter:
                current_chapter = chapter
                chapter_start = format_timestamp(chapter * chapter_interval)
                f.write(f"\n## [{chapter_start}]\n\n")

            ts = format_timestamp(seg["start"])
            text = seg["text"].strip()
            f.write(f"**[{ts}]** {text}\n\n")


def save_srt(result: dict, output_path: str):
    """保存为 SRT 字幕格式"""
    with open(output_path, "w", encoding="utf-8") as f:
        for i, seg in enumerate(result["segments"], 1):
            start = format_timestamp(seg["start"], style="srt")
            end = format_timestamp(seg["end"], style="srt")
            text = seg["text"].strip()
            f.write(f"{i}\n{start} --> {end}\n{text}\n\n")


def save_vtt(result: dict, output_path: str):
    """保存为 WebVTT 字幕格式"""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("WEBVTT\n\n")
        for i, seg in enumerate(result["segments"], 1):
            start = format_timestamp(seg["start"], style="vtt")
            end = format_timestamp(seg["end"], style="vtt")
            text = seg["text"].strip()
            f.write(f"{i}\n{start} --> {end}\n{text}\n\n")


# 格式分发表
FORMAT_SAVERS = {
    "txt": lambda r, p, **kw: save_txt(r, p, with_timestamps=kw.get("timestamps", True)),
    "md": lambda r, p, **kw: save_markdown(r, p, title=kw.get("title")),
    "srt": lambda r, p, **kw: save_srt(r, p),
    "vtt": lambda r, p, **kw: save_vtt(r, p),
}

FORMAT_EXTENSIONS = {
    "txt": ".txt",
    "md": ".md",
    "srt": ".srt",
    "vtt": ".vtt",
}


# ──────────────────────────────────────────────
# 主入口
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="音频转文字工具 v3.2.1 -- GPU 自动检测 + 双引擎 (faster-whisper / openai-whisper)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python transcribe.py --input "audio.mp3" --output "text.txt"
  python transcribe.py --input "audio.mp3" --output "text.txt" --engine openai
  python transcribe.py --input "audio.mp3" --output "text.md" --format md --language zh
  python transcribe.py --input "audio.mp3" --output "sub.srt" --format srt
  python transcribe.py --input "./audios/" --output "./texts/" --format md
  python transcribe.py --input "audio.mp3" --output "text.txt" --no-vad
        """
    )
    parser.add_argument("--input", required=True, help="输入音频文件或目录")
    parser.add_argument("--output", required=True, help="输出文件或目录")
    parser.add_argument("--engine", default="faster", choices=["faster", "openai"],
                        help="转写引擎: faster(默认,快速) / openai(高质量,需另装)")
    parser.add_argument("--model", default="medium",
                        help="Whisper模型 (默认medium; faster引擎支持turbo)")
    parser.add_argument("--language", default=None,
                        help="语言代码 (zh/en/ja等)，不指定则自动检测")
    parser.add_argument("--format", default="txt", choices=["txt", "md", "srt", "vtt"],
                        help="输出格式 (默认txt)")
    parser.add_argument("--no-timestamps", action="store_true",
                        help="纯文本模式不包含时间戳 (仅txt格式有效)")
    parser.add_argument("--title", default=None,
                        help="Markdown输出的标题 (仅md格式有效)")
    parser.add_argument("--no-vad", action="store_true",
                        help="关闭VAD静音过滤（仅faster引擎，默认开启）")
    args = parser.parse_args()

    engine = args.engine
    use_vad = not args.no_vad

    # ── 自动检测 GPU 并确保 CUDA 版 PyTorch ──
    gpu_ready = _ensure_gpu_pytorch()

    # ── 按引擎加载模型 ──
    if engine == "faster":
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            print("[FAIL] faster-whisper 未安装，请运行: pip install faster-whisper")
            sys.exit(1)

        # 验证模型名
        faster_models = {"tiny", "base", "small", "medium", "large-v2", "large-v3", "turbo"}
        if args.model not in faster_models:
            print(f"[FAIL] faster-whisper 不支持模型 '{args.model}'")
            print(f"[TIP] 可选: {', '.join(sorted(faster_models))}")
            sys.exit(1)

        # 根据 GPU 检测结果选择设备
        if gpu_ready:
            device = "cuda"
            compute_type = "float16"
        else:
            device = "cpu"
            compute_type = "int8"

        print(f"[Whisper] 加载模型: {args.model} (引擎: faster-whisper, "
              f"设备: {device}, 精度: {compute_type})")
        load_start = time.time()
        model = WhisperModel(args.model, device=device, compute_type=compute_type)
        load_time = time.time() - load_start
        print(f"[Whisper] 模型加载完成 ({load_time:.1f}秒)")

    else:  # openai
        try:
            import whisper
        except ImportError:
            print("[FAIL] openai-whisper 未安装，请运行: pip install openai-whisper")
            print("[TIP] openai-whisper 不默认安装。通常 faster 引擎已足够，")
            print("      仅在遇到转写质量问题时才需要安装 openai 引擎。")
            sys.exit(1)

        # openai-whisper 模型列表不含 turbo
        openai_models = {"tiny", "base", "small", "medium", "large", "large-v2", "large-v3"}
        if args.model not in openai_models:
            print(f"[FAIL] openai-whisper 不支持模型 '{args.model}'")
            print(f"[TIP] 可选: {', '.join(sorted(openai_models))}")
            if args.model == "turbo":
                print("[TIP] turbo 仅 faster 引擎支持，openai 引擎请用 medium 或 large-v3")
            sys.exit(1)

        # openai-whisper 通过 .to(device) 自动处理 GPU
        device_str = "GPU" if gpu_ready else "CPU"
        print(f"[Whisper] 加载模型: {args.model} (引擎: openai-whisper, 设备: {device_str})")
        load_start = time.time()
        model = whisper.load_model(args.model)
        load_time = time.time() - load_start
        print(f"[Whisper] 模型加载完成 ({load_time:.1f}秒)")

        if not args.no_vad:
            print("[Whisper] [INFO] openai 引擎不支持 VAD，已自动忽略")

    fmt = args.format
    ext = FORMAT_EXTENSIONS[fmt]
    saver = FORMAT_SAVERS[fmt]

    input_path = args.input
    output_path = args.output

    if os.path.isfile(input_path):
        # -- 单文件模式 --
        result = transcribe_file(model, input_path, args.language,
                                 use_vad=use_vad, engine=engine)

        if os.path.isdir(output_path):
            base = os.path.splitext(os.path.basename(input_path))[0]
            out_file = os.path.join(output_path, f"{base}{ext}")
        else:
            out_file = output_path

        os.makedirs(os.path.dirname(out_file) or ".", exist_ok=True)
        saver(result, out_file,
              timestamps=not args.no_timestamps,
              title=args.title or os.path.splitext(os.path.basename(input_path))[0])
        print(f"[Whisper] 已保存: {out_file}")

        # 非中文提示
        detected = result.get("language", "")
        if detected and detected != "zh":
            print(f"\n[TIP] 检测到非中文内容({get_lang_display(detected)})，建议用 AI 翻译为中文")

    elif os.path.isdir(input_path):
        # -- 批量模式 --
        supported_ext = {".mp3", ".wav", ".m4a", ".m4s", ".flac", ".ogg", ".opus", ".wma", ".aac"}
        files = sorted([
            f for f in os.listdir(input_path)
            if os.path.splitext(f)[1].lower() in supported_ext
        ])

        if not files:
            print(f"[Whisper] 未找到支持的音频文件: {input_path}")
            sys.exit(1)

        print(f"[Whisper] 找到 {len(files)} 个音频文件")
        print(f"{'---' * 17}")

        if os.path.isfile(output_path):
            print(f"[错误] 输入为目录时，输出也必须为目录")
            sys.exit(1)

        os.makedirs(output_path, exist_ok=True)
        total_start = time.time()

        for idx, fname in enumerate(files, 1):
            print(f"\n[{idx}/{len(files)}] {fname}")
            input_file = os.path.join(input_path, fname)
            base = os.path.splitext(fname)[0]
            out_file = os.path.join(output_path, f"{base}{ext}")
            result = transcribe_file(model, input_file, args.language,
                                     use_vad=use_vad, engine=engine)
            saver(result, out_file,
                  timestamps=not args.no_timestamps,
                  title=args.title or base)
            print(f"[Whisper] 已保存: {out_file}")

        total_elapsed = time.time() - total_start
        print(f"\n{'=' * 50}")
        print(f"[OK] 全部完成，共处理 {len(files)} 个文件，总耗时 {total_elapsed:.1f}秒")
    else:
        print(f"[错误] 输入不存在: {input_path}")
        sys.exit(1)


if __name__ == "__main__":
    main()
