#!/usr/bin/env python3
"""
视频音频下载脚本 v3.2.1 - 支持B站(bilibili)和YouTube

作者: pomisun
协议: MIT

变更日志（v3.0）:
  - YouTube cookies 智能获取（三级优先级）:
    1. 首选用户指定的 cookies.txt 文件 (--cookies 参数)
    2. 次选自动从 Firefox 提取 (明文 SQLite, 复制+导出 Netscape cookies.txt)
    3. 回退 yt-dlp --cookies-from-browser (可能因 Chrome v20 加密失败)
  - Chrome 127+ 的 v20 应用绑定加密已无法通过外部程序解密
  - 新增 --cookies 参数: 直接传入 Netscape 格式 cookies.txt 路径

变更日志（v2.1）:
  - 默认下载最低清晰度音频（--quality low），转文字完全够用且省时省空间
  - 用户可通过 --quality high/medium 手动指定高音质

变更日志（v2.0）:
  - B站下载后自动 ffmpeg 转 mp3（不再输出 m4s）
  - 支持多P视频（--page 参数）
  - 支持登录态（--sessdata 参数）下载高清/会员内容
  - 移除无效的 b23.tv 短链解析（改由 AI 用 web_fetch 预处理）
  - 下载进度百分比实时显示
  - 自动清理中间 m4s 临时文件

用法:
  # B站视频
  python download.py --url "https://www.bilibili.com/video/BVxxxxx" --output "./output/video1"

  # B站多P视频第3P
  python download.py --url "https://www.bilibili.com/video/BVxxxxx" --output "./output/ep3" --page 3

  # B站登录态（下载会员/高清内容）
  python download.py --url "https://www.bilibili.com/video/BVxxxxx" --output "./output/vip" --sessdata "YOUR_SESSDATA"

  # YouTube视频（自动检测 Firefox cookies）
  python download.py --url "https://www.youtube.com/watch?v=xxxxx" --output "./output/yt1"

  # YouTube指定 cookies.txt 文件
  python download.py --url "https://www.youtube.com/watch?v=xxxxx" --output "./output/yt1" --cookies "./cookies.txt"

  # YouTube指定cookie浏览器（回退方案）
  python download.py --url "https://www.youtube.com/watch?v=xxxxx" --output "./output/yt1" --browser chrome
"""

import argparse
import asyncio
import glob
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.request


# ──────────────────────────────────────────────
# 平台检测
# ──────────────────────────────────────────────

def detect_platform(url: str) -> str:
    """检测URL所属平台"""
    url_lower = url.lower()
    if any(k in url_lower for k in ["bilibili.com", "b23.tv", "bilibili.cn"]):
        return "bilibili"
    elif any(k in url_lower for k in ["youtube.com", "youtu.be"]):
        return "youtube"
    else:
        raise ValueError(f"不支持的平台: {url}")


def extract_bilibili_bvid(url: str) -> str:
    """从B站URL中提取BV号"""
    match = re.search(r'(BV[\w]+)', url)
    if match:
        return match.group(1)
    raise ValueError(f"无法从URL中提取BV号: {url}")


# ──────────────────────────────────────────────
# ffmpeg 查找
# ──────────────────────────────────────────────

def _find_ffmpeg() -> str | None:
    """
    查找 ffmpeg 可执行文件路径。

    优先级:
      1. 系统 PATH 中的 ffmpeg
      2. imageio-ffmpeg 包提供的 ffmpeg（pip install imageio-ffmpeg）

    Returns:
        ffmpeg 可执行文件的完整路径，未找到返回 None。
    """
    # 优先级 1: 系统 PATH
    ffmpeg_path = shutil.which("ffmpeg")
    if ffmpeg_path:
        return ffmpeg_path

    # 优先级 2: imageio-ffmpeg
    try:
        import imageio_ffmpeg
        ffmpeg_path = imageio_ffmpeg.get_ffmpeg_exe()
        if ffmpeg_path and os.path.isfile(ffmpeg_path):
            print(f"[ffmpeg] 使用 imageio-ffmpeg: {ffmpeg_path}")
            return ffmpeg_path
    except ImportError:
        pass

    return None


# ──────────────────────────────────────────────
# B站下载
# ──────────────────────────────────────────────

async def download_bilibili(bvid: str, output_path: str, quality: str = "low",
                            page: int = 0, sessdata: str = None):
    """
    使用 bilibili-api-python 下载B站视频音频。

    Args:
        bvid: BV号
        output_path: 输出文件路径（不含扩展名）
        quality: 音质 low/medium/high（默认 low，仅提取音频转文字时低音质足够）
        page: 分P索引（从0开始，对应第1P）
        sessdata: 登录cookie中的SESSDATA值（可选，用于会员/高清内容）
    """
    from bilibili_api import video, Credential

    # 构建credential（如果有sessdata）
    credential = None
    if sessdata:
        credential = Credential(sessdata=sessdata)
        print(f"[B站] 使用登录态下载")

    v = video.Video(bvid=bvid, credential=credential)
    info = await v.get_info()

    title = info.get("title", "unknown")
    duration = info.get("duration", 0)
    pages = info.get("pages", [])

    # 显示多P信息
    if len(pages) > 1:
        print(f"[B站] 多P视频，共 {len(pages)} P")
        for i, p in enumerate(pages):
            marker = " ←" if i == page else ""
            print(f"  P{i+1}: {p.get('part', '')} ({p.get('duration', 0)//60}分{p.get('duration', 0)%60}秒){marker}")
        if page >= len(pages):
            raise ValueError(f"P{page+1} 不存在，该视频只有 {len(pages)} P")
        page_title = pages[page].get("part", "")
        print(f"[B站] 下载: P{page+1} - {page_title}")
    else:
        print(f"[B站] {title} | 时长: {duration//60}分{duration%60}秒")

    # 获取下载URL
    vresp = await v.get_download_url(page)
    dash = vresp.get("dash", {})
    audio_streams = dash.get("audio") or []

    if not audio_streams:
        raise RuntimeError("未找到音频流，可能是互动视频或付费内容")

    # 按码率排序
    audio_streams.sort(key=lambda x: x.get("bandwidth", 0), reverse=True)

    if quality == "low" and len(audio_streams) > 1:
        audio_streams = [audio_streams[-1]]
    elif quality == "medium" and len(audio_streams) > 2:
        audio_streams = [audio_streams[len(audio_streams) // 2]]

    best_audio = audio_streams[0]
    audio_url = best_audio["baseUrl"]
    bandwidth = best_audio.get("bandwidth", 0)
    print(f"[B站] 音频码率: {bandwidth // 1000}kbps")

    # 下载音频（m4s格式）
    m4s_path = f"{output_path}.m4s"
    req = urllib.request.Request(audio_url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Referer": "https://www.bilibili.com"
    })

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with urllib.request.urlopen(req, timeout=300) as resp, open(m4s_path, "wb") as f:
        total = int(resp.headers.get("Content-Length", 0))
        downloaded = 0
        while True:
            chunk = resp.read(1024 * 1024)  # 1MB chunks
            if not chunk:
                break
            f.write(chunk)
            downloaded += len(chunk)
            if total > 0:
                pct = downloaded / total * 100
                size_mb = downloaded / (1024 * 1024)
                total_mb = total / (1024 * 1024)
                print(f"\r  下载进度: {pct:.1f}% ({size_mb:.1f}/{total_mb:.1f} MB)", end="", flush=True)
        print()  # 换行

    # ── 自动转换 m4s → mp3 ──
    mp3_path = f"{output_path}.mp3"
    # ffmpeg -q:a 值越小音质越高: 2=~190kbps, 4=~130kbps, 7=~100kbps
    qa_map = {"high": "2", "medium": "4", "low": "7"}
    qa_value = qa_map.get(quality, "7")

    ffmpeg_bin = _find_ffmpeg()
    if not ffmpeg_bin:
        print(f"[WARN] ffmpeg 未找到，跳过转换。请安装 ffmpeg 或 pip install imageio-ffmpeg")
        print(f"  手动运行: ffmpeg -i \"{m4s_path}\" -c:a libmp3lame -q:a {qa_value} \"{mp3_path}\" -y")
        mp3_path = m4s_path  # 回退使用 m4s
    else:
        print(f"[ffmpeg] 转换 m4s -> mp3 (quality={quality}, -q:a {qa_value}) ...")
        ffmpeg_cmd = [
            ffmpeg_bin, "-i", m4s_path,
            "-c:a", "libmp3lame", "-q:a", qa_value,
            mp3_path, "-y",
            "-loglevel", "warning"
        ]
        try:
            subprocess.run(ffmpeg_cmd, check=True, capture_output=True, text=True, timeout=300)
            print(f"[ffmpeg] 转换完成: {mp3_path}")
            # 清理临时 m4s 文件
            os.remove(m4s_path)
            print(f"[清理] 已删除临时文件: {m4s_path}")
        except subprocess.CalledProcessError as e:
            print(f"[WARN] ffmpeg 转换失败: {e.stderr}")
            print(f"[WARN] 保留原始 m4s 文件: {m4s_path}")
            mp3_path = m4s_path

    return {
        "title": title,
        "duration": duration,
        "page": page + 1,
        "total_pages": len(pages),
        "format": "mp3" if mp3_path.endswith(".mp3") else "m4s",
        "file": mp3_path
    }


# ──────────────────────────────────────────────
# YouTube Cookies 智能获取
# ──────────────────────────────────────────────

def _find_firefox_cookies_db() -> str | None:
    """查找 Firefox 的 cookies.sqlite 文件路径。返回最大的那个（通常是主 profile）。"""
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if not appdata:
            return None
        profiles_dir = os.path.join(appdata, "Mozilla", "Firefox", "Profiles")
    elif sys.platform == "darwin":
        profiles_dir = os.path.expanduser("~/Library/Application Support/Firefox/Profiles")
    else:
        profiles_dir = os.path.expanduser("~/.mozilla/firefox")

    if not os.path.isdir(profiles_dir):
        return None

    dbs = glob.glob(os.path.join(profiles_dir, "*/cookies.sqlite"))
    if not dbs:
        return None

    # 返回文件最大的那个（通常是活跃的主 profile）
    return max(dbs, key=os.path.getsize)


def _export_firefox_cookies(domains: list[str] | None = None) -> str | None:
    """
    从 Firefox cookies.sqlite 导出 Netscape 格式 cookies.txt。

    Firefox cookies 是明文 SQLite，即使浏览器正在运行也可以复制文件后读取。
    这是 2026 年 Chrome v20 应用绑定加密后，唯一可靠的浏览器 cookie 提取方式。

    Args:
        domains: 要提取的域名列表，如 [".youtube.com", ".google.com"]。
                 None 表示提取所有 cookies。

    Returns:
        导出的 cookies.txt 临时文件路径，失败返回 None。
    """
    db_path = _find_firefox_cookies_db()
    if not db_path:
        return None

    print("[Cookies] 检测到 Firefox, 正在提取 cookies ...")

    # 复制到临时文件（绕过可能的 Firefox 文件锁）
    tmp_db = os.path.join(tempfile.gettempdir(), "firefox_cookies_tmp.sqlite")
    try:
        shutil.copy2(db_path, tmp_db)
    except (PermissionError, OSError) as e:
        print(f"[Cookies] 复制 Firefox cookies 失败: {e}")
        return None

    try:
        conn = sqlite3.connect(tmp_db)
        try:
            cur = conn.cursor()

            # 构建查询
            if domains:
                placeholders = " OR ".join(["host LIKE ?" for _ in domains])
                query = f"SELECT host, name, value, path, expiry, isSecure FROM moz_cookies WHERE {placeholders}"
                params = [f"%{d.lstrip('.')}%" for d in domains]
                cur.execute(query, params)
            else:
                cur.execute("SELECT host, name, value, path, expiry, isSecure FROM moz_cookies")

            rows = cur.fetchall()
        finally:
            conn.close()

        if not rows:
            print("[Cookies] Firefox 中未找到相关 cookies（可能未登录 YouTube）")
            return None

        print(f"[Cookies] 提取到 {len(rows)} 条 cookies")

        # 写入 Netscape 格式 cookies.txt（限制文件权限）
        cookies_path = os.path.join(tempfile.gettempdir(), "yt_cookies.txt")
        fd = os.open(cookies_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("# Netscape HTTP Cookie File\n")
            f.write("# Exported by bilibili-youtube-video-summarizer from Firefox\n")
            for host, name, value, path, expiry, secure in rows:
                # 跳过含控制字符的异常 cookie（防止 Netscape 格式破坏）
                _fields = (host, name, value, path)
                if any(ch in fld for fld in _fields for ch in ("\t", "\n", "\r")):
                    continue
                # Netscape 格式: domain \t flag \t path \t secure \t expiry \t name \t value
                domain_flag = "TRUE" if host.startswith(".") else "FALSE"
                secure_flag = "TRUE" if secure else "FALSE"
                f.write(f"{host}\t{domain_flag}\t{path}\t{secure_flag}\t{expiry}\t{name}\t{value}\n")

        print(f"[Cookies] 已导出到: {cookies_path}")
        return cookies_path

    except Exception as e:
        print(f"[Cookies] 解析 Firefox cookies 失败: {e}")
        return None
    finally:
        # 清理临时 DB
        try:
            os.remove(tmp_db)
        except OSError:
            pass


def _resolve_youtube_cookies(cookies_file: str | None, browser: str) -> dict:
    """
    智能决定 YouTube 下载使用哪种 cookies 方式。

    优先级:
      1. 用户指定的 cookies.txt (--cookies)
      2. 自动从 Firefox 提取
      3. 回退到 yt-dlp --cookies-from-browser

    Returns:
        dict with either {"cookies_file": path} or {"browser": name} or {}
    """
    # 优先级 1: 用户显式提供
    if cookies_file:
        if os.path.isfile(cookies_file):
            print(f"[Cookies] 使用指定的 cookies 文件: {cookies_file}")
            return {"cookies_file": cookies_file}
        else:
            print(f"[WARN] 指定的 cookies 文件不存在: {cookies_file}")

    # 优先级 2: Firefox 自动提取
    youtube_domains = [".youtube.com", ".google.com", ".googleapis.com"]
    firefox_cookies = _export_firefox_cookies(youtube_domains)
    if firefox_cookies:
        return {"cookies_file": firefox_cookies}

    # 优先级 3: 回退 --cookies-from-browser
    print(f"[Cookies] Firefox 不可用, 回退到 --cookies-from-browser {browser}")
    print(f"[TIP] Chrome 127+ 的 v20 加密可能导致失败。")
    print(f"[TIP] 推荐安装 Firefox 并登录 YouTube, 即可自动提取 cookies。")
    return {"browser": browser}


# ──────────────────────────────────────────────
# YouTube下载
# ──────────────────────────────────────────────

def download_youtube(url: str, output_path: str, quality: str = "low",
                     fmt: str = "mp3", browser: str = "edge",
                     cookies_file: str | None = None):
    """
    使用 yt-dlp 下载 YouTube 视频音频。

    Cookies 获取优先级:
      1. --cookies 指定的 Netscape cookies.txt
      2. 自动从 Firefox 提取（明文 SQLite，最可靠）
      3. 回退 --cookies-from-browser（Chrome v20 加密可能失败）

    Args:
        url: YouTube URL
        output_path: 输出文件路径（不含扩展名）
        quality: 音质 low/medium/high（默认 low，仅提取音频转文字时低音质足够）
        fmt: 输出格式 mp3/wav
        browser: cookie来源浏览器 edge/chrome/firefox（仅回退时使用）
        cookies_file: Netscape 格式 cookies.txt 路径（可选，最高优先级）
    """
    quality_map = {"high": "0", "medium": "5", "low": "9"}
    audio_quality = quality_map.get(quality, "9")

    output_file = f"{output_path}.{fmt}"
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    # 智能获取 cookies
    cookie_config = _resolve_youtube_cookies(cookies_file, browser)

    cmd = [
        sys.executable, "-m", "yt_dlp",
        "--no-playlist",
        "-x",
        "--audio-format", fmt,
        "--audio-quality", audio_quality,
        "-o", output_file,
        "--no-progress",
        "--print", "title",
        "--print", "duration_string",
    ]

    # 根据 cookie 策略添加参数
    cookie_source_desc = "无 cookies"
    if "cookies_file" in cookie_config:
        cmd.extend(["--cookies", cookie_config["cookies_file"]])
        cookie_source_desc = f"cookies.txt ({cookie_config['cookies_file']})"
    elif "browser" in cookie_config:
        cmd.extend(["--cookies-from-browser", cookie_config["browser"]])
        cookie_source_desc = f"浏览器 ({cookie_config['browser']})"

    cmd.append(url)

    print(f"[YouTube] 开始下载 (cookie来源: {cookie_source_desc}) ...")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except subprocess.TimeoutExpired:
        raise RuntimeError("yt-dlp 下载超时 (>10 分钟), 可能网络问题或视频过大")

    if result.returncode != 0:
        stderr = result.stderr
        # JavaScript runtime 缺失（仅作为额外提示，不阻断后续错误检测）
        if "JavaScript runtime" in stderr or ("deno" in stderr.lower() and "not found" in stderr.lower()):
            print("[WARN] yt-dlp 需要 JavaScript 运行时 (deno) 来解析 YouTube。")
            if sys.platform == "win32":
                print("[TIP] 安装 deno: irm https://deno.land/install.ps1 | iex")
            else:
                print("[TIP] 安装 deno: curl -fsSL https://deno.land/install.sh | sh")
        # DPAPI 解密失败（Chrome/Edge v20 加密）
        if "DPAPI" in stderr or "decrypt" in stderr.lower():
            error_msg = (
                "浏览器 cookies 解密失败 (Chrome 127+ 的 v20 应用绑定加密)。\n"
                "解决方案（按推荐顺序）:\n"
                "  1. [推荐] 安装 Firefox 并登录 YouTube, 重新运行即可自动提取 cookies\n"
                "  2. 手动导出 Netscape 格式 cookies.txt 后使用 --cookies 参数\n"
                "  3. 换用 --browser firefox (如已安装 Firefox)\n"
            )
            raise RuntimeError(error_msg + f"\n原始错误: {stderr[:300]}")
        if "Sign in to confirm" in stderr or "confirm you" in stderr.lower() or "are not a bot" in stderr.lower():
            error_msg = (
                "YouTube 要求登录验证或检测到机器人。\n"
                "解决方案（按推荐顺序）:\n"
                "  1. [推荐] 安装 Firefox, 登录 YouTube, 然后重新运行（自动提取 cookies）\n"
                "  2. 手动导出 cookies.txt 后使用 --cookies 参数\n"
                "  3. 确保浏览器已登录 YouTube, 使用 --browser firefox/edge/chrome\n"
            )
            if "cookies_file" in cookie_config:
                error_msg += f"\n当前 cookies.txt 可能已过期, 请重新导出。"
            raise RuntimeError(error_msg + f"\n原始错误: {stderr[:500]}")
        raise RuntimeError(f"yt-dlp 下载失败: {stderr[:500]}")

    lines = result.stdout.strip().split("\n")
    title = lines[0] if len(lines) > 0 else "unknown"
    duration_str = lines[1] if len(lines) > 1 else "unknown"

    # 清理临时 cookies 文件（仅 Firefox 自动导出的）
    if "cookies_file" in cookie_config:
        tmp_cookies = cookie_config["cookies_file"]
        if os.path.normcase(tmp_cookies).startswith(os.path.normcase(tempfile.gettempdir())):
            try:
                os.remove(tmp_cookies)
            except OSError:
                pass

    print(f"[YouTube] {title} | {duration_str}")
    print(f"  下载完成: {output_file}")

    return {
        "title": title,
        "duration": duration_str,
        "format": fmt,
        "file": output_file
    }


# ──────────────────────────────────────────────
# 主入口
# ──────────────────────────────────────────────

async def main():
    parser = argparse.ArgumentParser(
        description="视频音频下载工具 v3.2.1 -- 支持B站/YouTube (Firefox cookies 自动提取)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python download.py --url "https://www.bilibili.com/video/BV1xx" --output "./audio"
  python download.py --url "https://www.bilibili.com/video/BV1xx" --output "./ep3" --page 3
  python download.py --url "https://www.youtube.com/watch?v=xxx" --output "./yt"
  python download.py --url "https://www.youtube.com/watch?v=xxx" --output "./yt" --cookies "./cookies.txt"
  python download.py --url "https://www.youtube.com/watch?v=xxx" --output "./yt" --browser firefox
        """
    )
    parser.add_argument("--url", required=True, help="视频URL (B站/YouTube)")
    parser.add_argument("--output", required=True, help="输出文件路径 (不含扩展名)")
    parser.add_argument("--quality", default="low", choices=["low", "medium", "high"],
                        help="音频质量 (默认low，仅转文字用低音质即可；用户要求高清时传high)")
    parser.add_argument("--page", type=int, default=1,
                        help="B站多P视频的分P编号，从1开始 (默认1)")
    parser.add_argument("--sessdata", default=None,
                        help="B站登录cookie中的SESSDATA (可选，用于会员/高清)")
    parser.add_argument("--browser", default="edge", choices=["edge", "chrome", "firefox"],
                        help="YouTube cookie来源浏览器, 仅回退时使用 (默认edge)")
    parser.add_argument("--cookies", default=None,
                        help="Netscape 格式 cookies.txt 路径 (可选，YouTube 最高优先级)")
    parser.add_argument("--format", default="mp3", choices=["mp3", "wav"],
                        help="YouTube输出格式 (默认mp3)")
    args = parser.parse_args()

    platform = detect_platform(args.url)
    print(f"平台: {platform}")
    print(f"{'---' * 17}")

    if platform == "bilibili":
        # 注意：b23.tv 短链必须由 AI 用 web_fetch 预解析后传入真实URL
        if "b23.tv" in args.url:
            print("[错误] b23.tv 短链无法直接使用 (会被412反爬拦截)。")
            print("       请先用 web_fetch 工具解析短链获取真实BV号URL，再传入本脚本。")
            sys.exit(1)

        bvid = extract_bilibili_bvid(args.url)
        page_index = max(0, args.page - 1)  # 用户传1开始，内部用0开始
        info = await download_bilibili(bvid, args.output, args.quality, page_index, args.sessdata)

        print(f"\n{'===' * 17}")
        print(f"[OK] 下载完成")
        print(f"  标题: {info['title']}")
        print(f"  分P: {info['page']}/{info['total_pages']}")
        print(f"  时长: {info['duration']//60}分{info['duration']%60}秒")
        print(f"  格式: {info['format']}")
        print(f"  文件: {info['file']}")

    elif platform == "youtube":
        info = download_youtube(
            args.url, args.output, args.quality, args.format,
            args.browser, args.cookies
        )

        print(f"\n{'===' * 17}")
        print(f"[OK] 下载完成")
        print(f"  标题: {info['title']}")
        print(f"  时长: {info['duration']}")
        print(f"  格式: {info['format']}")
        print(f"  文件: {info['file']}")


if __name__ == "__main__":
    asyncio.run(main())
