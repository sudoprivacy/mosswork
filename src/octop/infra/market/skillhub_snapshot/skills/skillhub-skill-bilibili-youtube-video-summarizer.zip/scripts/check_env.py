#!/usr/bin/env python3
"""
环境自检脚本 - 检查 video-transcriber skill 所需的全部依赖

作者: pomisun
协议: MIT

用法:
  python check_env.py           # 检查全部
  python check_env.py --fix     # 检查并尝试自动安装缺失的 Python 包
"""

import argparse
import importlib
import os
import shutil
import subprocess
import sys


# ──────────────────────────────────────────────
# 检查项定义
# ──────────────────────────────────────────────

CHECKS = [
    # (名称, 类型, 检测方式, 安装方式, 必需程度, 说明)
    ("Python >= 3.10", "runtime", None, None, "必需", "运行脚本"),
    ("ffmpeg", "ffmpeg", None, None, "必需", "音频格式转换 (m4s->mp3)"),
    ("yt-dlp", "python", "yt_dlp", "pip install yt-dlp", "YouTube下载", "YouTube音频下载"),
    ("deno", "cli", "deno", None, "YouTube下载", "yt-dlp 2026版JS运行时"),
    ("bilibili-api-python", "python", "bilibili_api", "pip install bilibili-api-python", "B站下载", "B站API下载"),
    ("faster-whisper", "python", "faster_whisper", "pip install faster-whisper", "Whisper转录", "默认引擎(CTranslate2加速)"),
    ("openai-whisper", "python", "whisper", "pip install openai-whisper", "[可选]高质量", "备用引擎(--engine openai)"),
    ("youtube-transcript-api", "python", "youtube_transcript_api", "pip install youtube-transcript-api", "YouTube字幕", "YouTube字幕获取"),
    ("torch (PyTorch)", "python", "torch", "pip install torch", "Whisper转录", "Whisper底层依赖"),
    ("imageio-ffmpeg", "python", "imageio_ffmpeg", "pip install imageio-ffmpeg", "[可选]ffmpeg替代", "内置ffmpeg二进制(无需系统安装)"),
]


def check_python_version() -> tuple:
    """检查 Python 版本"""
    v = sys.version_info
    ok = v.major >= 3 and v.minor >= 10
    version_str = f"{v.major}.{v.minor}.{v.micro}"
    return ok, version_str


def check_cli_tool(name: str) -> tuple:
    """检查命令行工具是否可用"""
    path = shutil.which(name)
    if path:
        try:
            result = subprocess.run([name, "--version"], capture_output=True, text=True, timeout=10)
            version = result.stdout.strip().split("\n")[0][:60] if result.stdout else "已安装"
            return True, version
        except Exception:
            return True, f"已安装 ({path})"
    return False, "未安装"


def check_ffmpeg() -> tuple:
    """
    检查 ffmpeg 是否可用。

    优先级:
      1. 系统 PATH 中的 ffmpeg
      2. imageio-ffmpeg 包内置的 ffmpeg
    """
    # 优先级 1: 系统 PATH
    path = shutil.which("ffmpeg")
    if path:
        try:
            result = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, timeout=10)
            version = result.stdout.strip().split("\n")[0][:60] if result.stdout else "已安装"
            return True, f"系统 PATH: {version}"
        except Exception:
            return True, f"系统 PATH: {path}"

    # 优先级 2: imageio-ffmpeg
    try:
        import imageio_ffmpeg
        ffmpeg_path = imageio_ffmpeg.get_ffmpeg_exe()
        if ffmpeg_path and os.path.isfile(ffmpeg_path):
            return True, f"imageio-ffmpeg 内置"
    except ImportError:
        pass

    return False, "未安装 (系统PATH和imageio-ffmpeg均未找到)"


def check_python_package(import_name: str) -> tuple:
    """检查 Python 包是否可导入"""
    try:
        mod = importlib.import_module(import_name)
        version = getattr(mod, "__version__", "已安装")
        return True, str(version)
    except ImportError:
        return False, "未安装"


def pip_install(package_cmd: str) -> bool:
    """尝试 pip 安装"""
    cmd = package_cmd.replace("pip install ", "")
    print(f"    正在安装 {cmd} ...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", cmd],
            capture_output=True, text=True, timeout=300
        )
        return result.returncode == 0
    except Exception as e:
        print(f"    安装失败: {e}")
        return False


# ──────────────────────────────────────────────
# 安装建议（跨平台）
# ──────────────────────────────────────────────

def _get_install_hint(name: str) -> str:
    """根据依赖名称和当前平台返回安装建议"""
    if name == "ffmpeg":
        hints = ["pip install imageio-ffmpeg (推荐, 免配置)"]
        if sys.platform == "win32":
            hints.append("winget install ffmpeg")
        elif sys.platform == "darwin":
            hints.append("brew install ffmpeg")
        else:
            hints.append("sudo apt install ffmpeg")
        return " 或 ".join(hints)
    elif name == "deno":
        if sys.platform == "win32":
            return "irm https://deno.land/install.ps1 | iex"
        else:
            return "curl -fsSL https://deno.land/install.sh | sh"
    return ""


# ──────────────────────────────────────────────
# 主检查流程
# ──────────────────────────────────────────────

def run_checks(auto_fix: bool = False):
    print("=" * 60)
    print("  bilibili-youtube-video-summarizer 环境自检")
    print("=" * 60)
    print()

    results = []
    missing = []

    for name, check_type, target, install_cmd, required, desc in CHECKS:
        if check_type == "runtime":
            ok, info = check_python_version()
        elif check_type == "ffmpeg":
            ok, info = check_ffmpeg()
        elif check_type == "cli":
            ok, info = check_cli_tool(target)
        elif check_type == "python":
            ok, info = check_python_package(target)
        else:
            ok, info = False, "未知检查类型"

        status = "[OK]" if ok else "[FAIL]"
        results.append((status, name, info, required, desc))

        if not ok:
            missing.append((name, check_type, target, install_cmd, required))

    # 打印结果表
    print(f"{'状态':^4} {'依赖':^25} {'版本/状态':^30} {'必需程度':^12} {'说明'}")
    print(f"{'--' * 2} {'--' * 12} {'--' * 15} {'--' * 6} {'--' * 15}")
    for status, name, info, required, desc in results:
        print(f" {status}  {name:<25} {info:<30} {required:<12} {desc}")

    print()

    # ffmpeg 特殊处理：如果 ffmpeg 和 imageio-ffmpeg 都OK，跳过 imageio-ffmpeg 的缺失
    ffmpeg_ok = any(s == "[OK]" and n == "ffmpeg" for s, n, *_ in results)
    if ffmpeg_ok:
        # ffmpeg 已可用，imageio-ffmpeg 缺失不算问题
        missing = [(n, ct, t, ic, r) for n, ct, t, ic, r in missing if n != "imageio-ffmpeg"]

    if not missing:
        print("[OK] 所有依赖已就绪，可以正常使用!")
        return True

    # 有缺失项
    print(f"[WARN] 共 {len(missing)} 项缺失:")
    pip_fixable = []
    manual_fixable = []

    for name, check_type, target, install_cmd, required in missing:
        if check_type == "python" and install_cmd:
            pip_fixable.append((name, install_cmd))
        elif check_type == "ffmpeg":
            # ffmpeg 缺失时推荐安装 imageio-ffmpeg
            pip_fixable.append(("imageio-ffmpeg (ffmpeg替代)", "pip install imageio-ffmpeg"))
        elif check_type == "cli":
            hint = _get_install_hint(name)
            manual_fixable.append((name, hint or "请手动安装"))
        else:
            manual_fixable.append((name, "需手动安装"))

    if pip_fixable:
        print("\n  可自动安装 (pip):")
        for name, cmd in pip_fixable:
            print(f"    {name}: {cmd}")

        if auto_fix:
            print("\n  正在自动安装...")
            for name, cmd in pip_fixable:
                ok = pip_install(cmd)
                print(f"    {name}: {'[OK] 成功' if ok else '[FAIL] 失败'}")
        else:
            print("\n  [TIP] 加 --fix 参数可自动安装 Python 包")

    if manual_fixable:
        print("\n  需手动安装:")
        for name, cmd in manual_fixable:
            print(f"    {name}: {cmd}")

    return False


def main():
    parser = argparse.ArgumentParser(description="bilibili-youtube-video-summarizer 环境自检")
    parser.add_argument("--fix", action="store_true", help="自动安装缺失的 Python 包")
    args = parser.parse_args()

    ok = run_checks(auto_fix=args.fix)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
