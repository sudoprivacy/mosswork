#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第一步：聚焦缺口证据抽取(高信号)。仅抽取真正指示'研究缺口/方法缺陷/未来研究'的句子，
剔除版权声明、but/however 过渡等噪声。
用法: python step1_focus.py <txt目录> [输出目录(默认=txt目录)]
输出: gap_evidence.txt(按篇、按信号强度排序)

与 step1_analyze.py 的区别：本脚本是"精选"版——强缺口标记 + 噪声黑名单 + 特异方法词加权，
用于直接可引用的原句证据；analyze 是"全景"版(泛/特异频次 + 批评语境全量句)。
"""
import os, sys, glob, re

# 强缺口标记(中英)：明确指向缺陷/空白/未来研究/方法软肋
STRONG = [
    "future research", "future work", "limitation", "limitations", "this study is limited",
    "this study has", "we did not", "remain unclear", "remains unclear", "remains to be",
    "little is known", "few studies", "scant", "under-explored", "understudied",
    "under-researched", "lack of empirical", "lack empirical", "anecdotal evidence",
    "speculat", "need further", "call for more", "calls for more", "longitudinal",
    "cross-sectional", "causal", "operationaliz", "construct valid", "validity",
    "sample size", "theoretical framework", "without a unified", "no consensus",
    "inconsistent findings", "mixed findings", "contradictory", "limited evidence",
    "lack of", "lacks", "few studies have", "remains limited", "previously unexplored",
    "gap in", "research gap", "literature gap",
    "局限", "不足", "空白", "缺失", "未解决", "有待", "缺乏实证", "实证支持", "操作性",
    "可重复", "效度", "因果", "样本量", "横截面", "构念", "还原论", "循环", "争议",
    "模糊", "边界条件", "尚未", "机制不清", "理论框架", "不一致", "分歧", "缺口",
    "鲜有", "尚无", "亟需", "尚未见", "有待验证", "缺乏统一", "缺乏可靠", "测量工具",
]
# 噪声过滤
NOISE = ["creative commons", "license", "attribution", "open access", "distributed under",
         "singapore management university", "author contributions", "no use",
         "this is an open", "cc by", "copyright", "all rights reserved"]

# 特异方法词(加权计分，优先保留)
SPEC = ["operationaliz", "construct valid", "validity", "causal", "longitudinal",
        "cross-sectional", "sample size", "anecdotal", "speculat", "theoretical framework",
        "操作性", "效度", "因果", "样本量", "横截面", "构念", "还原论", "循环",
        "实证支持", "缺乏实证", "测量工具", "缺乏统一", "缺乏可靠", "机制不清"]

SPLIT = re.compile(r'(?<=[。！？!?.])\s+|\n+')

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    txt_dir = sys.argv[1]
    out_dir = sys.argv[2] if len(sys.argv) > 2 else txt_dir
    os.makedirs(out_dir, exist_ok=True)

    out = []
    for fp in sorted(glob.glob(os.path.join(txt_dir, "*.txt"))):
        name = os.path.splitext(os.path.basename(fp))[0]
        text = open(fp, encoding="utf-8", errors="replace").read()
        sents = SPLIT.split(text)
        kept = []
        for s in sents:
            s = s.strip()
            if len(s) < 22 or len(s) > 520:
                continue
            sl = s.lower()
            if any(n in sl for n in NOISE):
                continue
            hits = [m for m in STRONG if m in sl]
            if not hits:
                continue
            score = len(hits) + sum(3 for m in SPEC if m in sl)
            kept.append((score, s, hits))
        kept.sort(key=lambda x: -x[0])
        for score, s, hits in kept[:18]:
            out.append("%s\t[%s]\t%s" % (name, "/".join(hits[:5]), s))

    with open(os.path.join(out_dir, "gap_evidence.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print("聚焦缺口证据句:", len(out))

if __name__ == "__main__":
    main()
