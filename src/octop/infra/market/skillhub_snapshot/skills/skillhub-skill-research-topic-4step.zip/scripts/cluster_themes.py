#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""主题词共现矩阵 + 文献聚类。用法: python cluster_themes.py <txt目录> [输出.tsv]

输出主题聚类矩阵（每篇文献 × 各主题词频 + 主导主题）到 stdout 与可选 tsv 文件。
重要：THEMES 主题词是领域相关的，必须按当前文献领域替换（下例为认知科学示例，勿直接沿用）。
中英混合语料时关键词须双语；勿用 "AI/learning/teaching" 等泛词（几乎每篇都出现、会淹没主导主题信号），改用特指词（生成式/大模型/ChatGPT/competenc/literacy/validity/ethics 等）。
"""
import os, sys, glob, json

# 主题词表：优先从同目录 themes.json 读入（换领域时建议创建 themes.json，避免改脚本）；
# 无 themes.json 时用下方内置示例（认知科学，须按领域重写）。
_THEMES_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "themes.json")
if os.path.exists(_THEMES_PATH):
    THEMES = json.load(open(_THEMES_PATH, encoding="utf-8"))
else:
    THEMES = {
        "表征/符号": ["表征", "符号", "命题符号", "模拟原则", "知觉符号"],
        "隐喻": ["隐喻", "映射", "源域", "目标域"],
        "神经证据": ["镜像神经元", "脑区", "皮层", "fMRI", "ERP", "脑成像", "神经机制", "神经科学"],
        "社会认知": ["社会认知", "他人", "共情", "情绪", "道德", "权力", "人际"],
        "教学应用": ["教学", "学习", "课堂", "学生", "教育", "课程"],
        "理论思潮": ["二元论", "还原论", "范式", "思潮", "离身", "身心"],
        "可塑性/发展": ["可塑性", "发展", "经验", "抑制", "突触"],
        "具身机制": ["具身", "身体", "动作", "体验", "知觉", "模拟"],
    }

def cluster(txt_dir, out_tsv=None):
    keys = list(THEMES.keys())
    rows = []
    for fp in sorted(glob.glob(os.path.join(txt_dir, "*.txt"))):
        name = os.path.splitext(os.path.basename(fp))[0]
        with open(fp, encoding="utf-8", errors="replace") as f:
            text = f.read()
        counts = [sum(text.count(w) for w in THEMES[k]) for k in keys]
        lead = keys[counts.index(max(counts))]
        rows.append((name, counts, lead))
    header = "文献\t" + "\t".join(keys) + "\t主导主题"
    print(header)
    for name, counts, lead in rows:
        print(name + "\t" + "\t".join(str(c) for c in counts) + "\t" + lead)
    if out_tsv:
        with open(out_tsv, "w", encoding="utf-8") as f:
            f.write(header + "\n")
            for name, counts, lead in rows:
                f.write(name + "\t" + "\t".join(str(c) for c in counts) + "\t" + lead + "\n")
        print("已输出", out_tsv)
    return rows

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    cluster(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
