#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""四维创新性评估：加权打分 + 排序 + 敏感性分析（第四步 4-1）。

用法: python score_candidates.py <candidates.json>
候选数据从外部 JSON 读入（消除硬编码，换候选集无需改脚本）。

candidates.json 格式:
{
  "weights": {"orig": 0.30, "cross": 0.20, "appl": 0.25, "theory": 0.25},   // 可选，覆盖默认
  "candidates": [
    {"id": "P1", "name": "AI素养可观测维度结构与测量工具",
     "orig": 7, "cross": 5, "appl": 9, "theory": 8},
    ...
  ]
}

四维: orig=原创性, cross=学科交叉性, appl=应用潜力, theory=理论深度 (各 1-10)
权重默认: 原创.30 / 交叉.20 / 应用.25 / 理论.25
敏感性: 固定另跑 理论导向 / 应用导向 两种极端配置
"""
import json, sys

CONFIGS = {
    "默认(原创.30/交叉.20/应用.25/理论.25)": dict(orig=.30, cross=.20, appl=.25, theory=.25),
    "理论导向(理论.35/原创.30/交叉.20/应用.15)": dict(orig=.30, cross=.20, appl=.15, theory=.35),
    "应用导向(应用.35/原创.25/交叉.20/理论.20)": dict(orig=.25, cross=.20, appl=.35, theory=.20),
}

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    cands = data["candidates"]
    if "weights" in data:
        CONFIGS[list(CONFIGS.keys())[0]] = data["weights"]

    rank_across = {c["id"]: [] for c in cands}
    for cname, w in CONFIGS.items():
        print("\n=== " + cname + " ===")
        rows = []
        for c in cands:
            score = c["orig"]*w["orig"] + c["cross"]*w["cross"] + c["appl"]*w["appl"] + c["theory"]*w["theory"]
            rows.append((score, c["id"], c["name"], c))
        rows.sort(key=lambda x: -x[0])
        for i, (s, cid, nm, c) in enumerate(rows, 1):
            rank_across[cid].append(i)
            print("{}. {} {}: {:.2f}  [原{} 交{} 用{} 理{}]".format(
                i, cid, nm, s, c["orig"], c["cross"], c["appl"], c["theory"]))

    print("\n=== 稳健性: 各题在三种配置下的名次 ===")
    for c in cands:
        cid, ranks = c["id"], rank_across[c["id"]]
        print("{} {} : 名次{} 跨度{}".format(cid, c["name"], ranks, max(ranks)-min(ranks)))

if __name__ == "__main__":
    main()
