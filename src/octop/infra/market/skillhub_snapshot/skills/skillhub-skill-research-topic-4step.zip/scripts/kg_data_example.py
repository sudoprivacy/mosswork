# -*- coding: utf-8 -*-
"""领域本体数据模板。复制本文件为 kg_data.py 并填入你的领域数据。

供 build_kg_and_infer.py（推理引擎）与 generate_kg_html.py（生成图谱）使用。

## 格式约定

【硬性约束】本文件中的所有实体（尤其 theory / mechanism 等理论类）必须来自所分析的文献，
可在原文中溯源；严禁填入文献之外的外部理论（如研究者自带的理论先验）。
外部理论只属于 3-3「跨学科强化」的"导入透镜"，绝不可作为领域既有构念写入本图谱。
填完请逐一对理论类实体回原文核查，无法溯源的实体一律移出。

ENTITIES: (id, label, type, sub) 四元组列表
  - id: 唯一标识（英文/拼音，用于边引用）
  - label: 显示名（中文）
  - type: 实体类型，默认 5 类：theory / mechanism / discipline / gap / application
    （如需自定义类型名，请在 kg_template.html 的 DATA.gapType 或 generate 时对应配置）
  - sub: 子类标注。type=gap 时 sub 必填，取值为「知识 / 关系 / 理论 / 方法」，
    决定推理引擎 R3/R4 生成的问题类型。

EDGES: (from_id, rel, to_id) 三元组列表
  - rel 关系类型，默认 4 种：supports / challenges / relatesTo / gaps

REL_LABEL / TYPE_LABEL: 关系/类型的中文显示名。
"""
ENTITIES = [
    ("t1", "核心理论", "theory", "理论"),
    ("m1", "核心机制", "mechanism", "机制"),
    ("g1", "某研究空白", "gap", "知识"),   # sub 取 知识/关系/理论/方法
]

EDGES = [
    ("m1", "supports", "t1"),
    ("g1", "gaps", "t1"),
]

REL_LABEL = {
    "supports": "支持",
    "challenges": "挑战",
    "relatesTo": "关联",
    "gaps": "缺失",
}

TYPE_LABEL = {
    "theory": "理论",
    "mechanism": "机制",
    "discipline": "学科",
    "gap": "空白",
    "application": "应用",
}

# 推理引擎语义配置（可选；自定义实体类型名时须相应修改，否则 R3/R4 推理会失效）
# build_kg_and_infer.py 优先读此处 CONFIG，无则用默认值（theory/mechanism/gap）。
CONFIG = {
    "positive_rels": {"supports"},                 # 正向可传递关系（R1 传递）
    "conflict_rels": {"challenges", "conflicts"},  # 冲突类关系（R2）
    "concept_types": {"theory", "mechanism"},      # 构念类实体类型（R4d 关系型空白）
    "theory_type": "theory",                       # 理论类实体类型名（R4a/R4c）
    "gap_type": "gap",                             # 空白类实体类型名（R3/R4）
}
