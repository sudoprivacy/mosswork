#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第一步：局限关键词频次统计(泛批评词 vs 特异问题词，中英双语) + 批评语境句子抽取。
用法: python step1_analyze.py <txt目录> [输出目录(默认=txt目录)]
输出: keyword_freq.tsv、critical_sentences.txt

注意：泛词(BROAD)与特异词(SPECIFIC)分列统计——泛词覆盖面广但信号弱，特异词才是定位缺陷的锚点。
"""
import os, sys, glob, re

# 泛批评词(覆盖面广、信息量低)
BROAD = ["问题", "难以", "局限", "质疑", "缺乏", "挑战", "缺陷", "困难", "困境",
         "不足", "模糊", "有待", "尚未", "缺失", "空白", "薄弱",
         "problem", "problems", "issue", "issues", "challenge", "challenges",
         "difficulty", "difficult", "limitation", "limitations", "lack", "lacks",
         "weakness", "weaknesses", "shortcoming", "shortcomings", "gap", "gaps",
         "unclear", "ambiguous", "remain", "remains", "remained"]

# 特异问题词(定位缺陷的锚点)
SPECIFIC = ["还原论", "操作性", "可重复", "循环", "未解决", "解释力", "实证支持",
            "方法论", "争议", "构念", "效度", "因果", "样本量", "横截面",
            "reductionism", "operational", "operationalization", "replicab",
            "circular", "unresolved", "explanatory power", "empirical support",
            "methodolog", "controvers", "controversy", "construct valid",
            "validity", "causal", "longitudinal", "cross-sectional", "sample size",
            "anecdotal", "theoretical", "framework", "speculat", "self-report"]

# 批评语境抽取标记
MARKERS = ["局限", "不足", "困境", "质疑", "争议", "有待", "难以", "未解决", "缺失", "空白",
           "薄弱", "缺陷", "模糊", "不确定", "尚未", "缺乏", "gap", "gaps", "limitation",
           "limitations", "remain", "remains", "unresolved", "unclear", "ambiguous",
           "future research", "future work", "need to", "needs to", "call for",
           "lack of", "lacks", "without", "however,", "but", "yet", "nevertheless",
           "challenge", "challenges", "weakness", "weaknesses", "insufficient",
           "uncertain", "speculat", "little is known", "poorly", "under-explored",
           "understudied", "under-researched", "rarely", "few studies", "scant"]

SENT_SPLIT = re.compile(r'(?<=[。！？!?.])\s+|\n+')

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    txt_dir = sys.argv[1]
    out_dir = sys.argv[2] if len(sys.argv) > 2 else txt_dir
    os.makedirs(out_dir, exist_ok=True)

    papers = sorted(glob.glob(os.path.join(txt_dir, "*.txt")))
    broad_total = {k: [0, 0] for k in BROAD}
    spec_total = {k: [0, 0] for k in SPECIFIC}
    per_paper = []
    crit_lines = []

    for fp in papers:
        name = os.path.splitext(os.path.basename(fp))[0]
        with open(fp, encoding="utf-8", errors="replace") as f:
            text = f.read()
        low = text.lower()
        b_hit = {k: text.count(k) for k in BROAD}
        s_hit = {k: low.count(k.lower()) for k in SPECIFIC}
        nb = sum(b_hit.values()); ns = sum(s_hit.values())
        for k, c in b_hit.items():
            if c: broad_total[k][0] += c; broad_total[k][1] += 1
        for k, c in s_hit.items():
            if c: spec_total[k][0] += c; spec_total[k][1] += 1
        per_paper.append((name, nb, ns))

        sents = SENT_SPLIT.split(text)
        kept = []
        for s in sents:
            s = s.strip()
            if len(s) < 12 or len(s) > 600:
                continue
            sl = s.lower()
            hits = [m for m in MARKERS if m in sl]
            if len(hits) >= 1:
                score = len(hits) + sum(2 for m in SPECIFIC if m in sl)
                kept.append((score, s, hits))
        kept.sort(key=lambda x: -x[0])
        for score, s, hits in kept[:45]:
            crit_lines.append("%s\t[%s]\t%s" % (name, "/".join(hits[:5]), s))

    with open(os.path.join(out_dir, "keyword_freq.tsv"), "w", encoding="utf-8") as f:
        f.write("类型\t关键词\t总频次\t命中篇数\n")
        for k, (c, p) in sorted(broad_total.items(), key=lambda x: -x[1][0]):
            if c: f.write("泛\t%s\t%d\t%d\n" % (k, c, p))
        f.write("\n")
        for k, (c, p) in sorted(spec_total.items(), key=lambda x: -x[1][0]):
            if c: f.write("特异\t%s\t%d\t%d\n" % (k, c, p))
        f.write("\n类型\t文献\t泛词合计\t特异词合计\n")
        for name, nb, ns in sorted(per_paper, key=lambda x: -(x[1] + x[2])):
            f.write("篇\t%s\t%d\t%d\n" % (name, nb, ns))

    with open(os.path.join(out_dir, "critical_sentences.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(crit_lines))

    print("论文数:", len(papers), "| 批评语境句子:", len(crit_lines))

if __name__ == "__main__":
    main()
