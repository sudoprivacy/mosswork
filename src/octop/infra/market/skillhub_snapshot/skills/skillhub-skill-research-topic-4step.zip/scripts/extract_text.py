#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""批量提取 PDF 全文为 UTF-8 txt。用法: python extract_text.py <文献目录> <输出目录>"""
import os, sys, glob

def extract(src_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    pdfs = sorted(glob.glob(os.path.join(src_dir, "*.pdf")))
    if not pdfs:
        print("目录下无 PDF 文件:", src_dir); return
    import fitz  # pymupdf
    for p in pdfs:
        name = os.path.splitext(os.path.basename(p))[0]
        try:
            doc = fitz.open(p)
            text = "\n".join(page.get_text() for page in doc)
            doc.close()
            # 清理控制字符与 CJK 间空格
            text = text.replace("\x03", "").replace("\ufeff", "")
            out = os.path.join(out_dir, name + ".txt")
            with open(out, "w", encoding="utf-8") as f:
                f.write(text)
            print("OK  %s (%d chars)" % (name, len(text)))
        except Exception as e:
            print("FAIL", name, "->", e)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    extract(sys.argv[1], sys.argv[2])
