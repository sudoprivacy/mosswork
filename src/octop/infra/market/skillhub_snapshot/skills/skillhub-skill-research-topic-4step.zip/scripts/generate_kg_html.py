#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成交互式知识图谱 HTML。

用法: python generate_kg_html.py [graph.json] [输出.html]
默认读取同目录 graph.json，输出同目录 knowledge_graph.html。
若 graph.json 缺少配色，自动补默认配色（实体色按类型动态分配，关系色用语义默认色 + 未知关系名轮换兜底，见 kg_visual_spec.md）。
"""
import json, os, sys, io

# 通用色板（按实体类型出现顺序轮换分配；若 graph.json 已提供 typeColor/relColor 则优先使用）
PALETTE_TYPE = [
    ["#1A6FC4", "#D6E8FA"],   # 蓝
    ["#1C8D73", "#CFEAE2"],   # 青绿
    ["#6B6B6B", "#E6E6E6"],   # 灰
    ["#B22222", "#FCE3E3"],   # 红
    ["#9B2E5A", "#F2D8E3"],   # 粉
]
PALETTE_REL = {
    "supports": "#3C9E3F",
    "challenges": "#C53030",
    "relatesTo": "#B2AFA3",
    "gaps": "#B71C1C",
}
# 未知关系名的备用色（按出现顺序轮换，用于领域自定义关系词时兜底）
PALETTE_REL_FALLBACK = ["#7C54B0", "#1C8D73", "#C47A1A", "#D24B7A", "#3B82D1"]

def auto_type_color(data):
    """为 data 中缺失的实体类型动态分配配色。"""
    tc = data.get("typeColor") or {}
    node_types = []
    for n in data.get("nodes", []):
        if n["type"] not in node_types:
            node_types.append(n["type"])
    for i, t in enumerate(node_types):
        if t not in tc:
            tc[t] = PALETTE_TYPE[i % len(PALETTE_TYPE)]
    data["typeColor"] = tc

def auto_rel_color(data):
    """为 data 中缺失的关系类型动态分配配色（已知语义关系用默认色，未知关系轮换兜底）。"""
    rc = data.get("relColor") or {}
    rels = []
    for e in data.get("edges", []):
        if e["rel"] not in rels:
            rels.append(e["rel"])
    fi = 0
    for r in rels:
        if r not in rc:
            rc[r] = PALETTE_REL.get(r) or PALETTE_REL_FALLBACK[fi % len(PALETTE_REL_FALLBACK)]
            fi += 1
    data["relColor"] = rc

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    gpath = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "graph.json")
    opath = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, "knowledge_graph.html")
    tpath = os.path.join(here, "..", "assets", "kg_template.html")

    with open(gpath, encoding="utf-8") as f:
        data = json.load(f)
    with open(tpath, encoding="utf-8") as f:
        template = f.read()

    # 动态补配色（仅补缺失项，不覆盖用户已提供者）
    auto_type_color(data)
    auto_rel_color(data)

    html = template.replace("__GRAPH_DATA__", json.dumps(data, ensure_ascii=False))
    with io.open(opath, "w", encoding="utf-8") as f:
        f.write(html)
    print("OK %s (%d bytes; FFFD=%d)" % (opath, len(html), html.count("\ufffd")))

if __name__ == "__main__":
    main()
