#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""领域本体构建 + 逻辑推理引擎。

用法：在与 kg_data.py 同目录下运行，或先创建 kg_data.py（定义 ENTITIES / EDGES / REL_LABEL / TYPE_LABEL）。
输出：①连通性检查结果 ②推理衍生问题列表 ③graph.json（供 generate_kg_html.py 使用）。

ENTITIES 格式: [(id, label, type, sub), ...]
EDGES 格式:    [(from_id, rel, to_id), ...]
"""
import json, sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from kg_data import ENTITIES, EDGES, REL_LABEL, TYPE_LABEL
except ImportError:
    print("缺少 kg_data.py。请复制同目录 kg_data_example.py 为 kg_data.py 并填入数据。")
    sys.exit(1)

try:
    from kg_data import CONFIG as _CFG
except ImportError:
    _CFG = {}

ID2N = {e[0]: {"label": e[1], "type": e[2], "sub": e[3]} for e in ENTITIES}
# 语义常量：优先用 kg_data.CONFIG（自定义实体类型名时须在其中相应修改），无则用默认方案。
# gap 实体的 sub 字段取值约定：知识 / 关系 / 理论 / 方法（决定 R3/R4 生成的问题类型）
POSITIVE_RELS = _CFG.get("positive_rels", {"supports"})
CONFLICT_RELS = _CFG.get("conflict_rels", {"challenges", "conflicts"})
CONCEPT_TYPES = _CFG.get("concept_types", {"theory", "mechanism"})
THEORY_TYPE = _CFG.get("theory_type", "theory")
GAP_TYPE = _CFG.get("gap_type", "gap")

def check_connectivity():
    """BFS 找连通分量，返回孤立分支列表。"""
    adj = {i: set() for i in ID2N}
    for f, r, t in EDGES:
        adj[f].add(t); adj[t].add(f)
    visited, comps = set(), []
    for s in adj:
        if s in visited: continue
        c, stack = set(), [s]
        while stack:
            v = stack.pop()
            if v in c: continue
            c.add(v)
            for nb in adj[v]:
                if nb not in c: stack.append(nb)
        visited |= c; comps.append(c)
    comps.sort(key=lambda x: -len(x))
    isolated = [c for c in comps if len(c) < len(comps[0])]
    return comps, isolated

def infer(adj, edge_dir):
    """四类推理，返回衍生问题列表 (kind, qid, text, evidence)。"""
    def has_edge(a, b): return (a, b) in edge_dir or (b, a) in edge_dir
    def edge_rels(a, b):
        if (a, b) in edge_dir: return edge_dir[(a, b)]
        if (b, a) in edge_dir: return edge_dir[(b, a)]
        return []
    derived = []
    def add(kind, text, ev):
        n = sum(1 for d in derived if d[0] == kind) + 1
        derived.append((kind, "DQ-%s%d" % (kind, n), text, ev))

    # R1 传递路径：正向关系两跳传递（A 支持 B、B 支持 C → A 隐含支持 C）
    TRANS = {(x, y) for x in POSITIVE_RELS for y in POSITIVE_RELS}
    for (a,b), rs in edge_dir.items():
        for r1 in rs:
            if r1 not in POSITIVE_RELS: continue
            for c in adj[b]:
                if c == a or has_edge(a, c): continue
                for r2 in edge_rels(b, c):
                    if (r1, r2) in TRANS:
                        add("M", "%s对%s的隐含%s作用是否成立？" % (ID2N[a]["label"], ID2N[c]["label"], REL_LABEL.get(r2,r2)),
                            "%s -%s-> %s -%s-> %s" % (ID2N[a]["label"], REL_LABEL[r1], ID2N[b]["label"], REL_LABEL[r2], ID2N[c]["label"]))
    # R2 冲突/反驳检测（CONFLICT_RELS 为冲突类关系名）
    for f, r, t in EDGES:
        if r not in CONFLICT_RELS: continue
        # 双向冲突 = 实质冲突
        if r in edge_rels(t, f) and f < t:
            add("T", "「%s」与「%s」互相%s，是否构成实质冲突？" % (ID2N[f]["label"], ID2N[t]["label"], REL_LABEL.get(r, r)),
                "%s ↔ %s（双向%s）" % (ID2N[f]["label"], ID2N[t]["label"], REL_LABEL.get(r, r)))
        # 证据角力：f 反驳 t，且存在 z 支持 t
        for z in adj[t]:
            if z != f and any(p in POSITIVE_RELS for p in edge_rels(z, t)):
                add("T", "%s与%s的证据角力中，%s是否被证伪或需限定适用域？" % (ID2N[f]["label"], ID2N[z]["label"], ID2N[t]["label"]),
                    "%s %s %s；%s 支持 %s" % (ID2N[f]["label"], REL_LABEL.get(r, r), ID2N[t]["label"], ID2N[z]["label"], ID2N[t]["label"]))
    # R3 缺口邻域缺失连接
    for g in ID2N:
        if ID2N[g]["type"] != GAP_TYPE: continue
        nbrs = [x for x in adj[g] if ID2N[x]["type"] != GAP_TYPE]
        for x, y in itertools.combinations(sorted(nbrs), 2):
            if has_edge(x, y): continue
            gsub = ID2N[g]["sub"]
            ev = "%s 经空白[%s] 关联 %s；无直接连接" % (ID2N[x]["label"], ID2N[g]["label"], ID2N[y]["label"])
            if gsub == "知识":   add("K", "%s与%s在%s中各自角色与关系？" % (ID2N[x]["label"], ID2N[y]["label"], ID2N[g]["label"]), ev)
            elif gsub == "关系": add("R", "%s与%s的因果方向与边界条件？（空白:%s）" % (ID2N[x]["label"], ID2N[y]["label"], ID2N[g]["label"]), ev)
            elif gsub == "理论": add("T", "%s与%s能否在%s上被整合或裁定？" % (ID2N[x]["label"], ID2N[y]["label"], ID2N[g]["label"]), ev)
            elif gsub == "方法": add("M", "针对[%s]，%s与%s可组合为怎样的一体化方法？" % (ID2N[g]["label"], ID2N[x]["label"], ID2N[y]["label"]), ev)
    # R4 规则模板
    for g in ID2N:
        if ID2N[g]["type"] != GAP_TYPE: continue
        gsub = ID2N[g]["sub"]; nbrs = list(adj[g])
        types = [ID2N[x]["type"] for x in nbrs]
        if gsub == "理论" and types.count(THEORY_TYPE) >= 2:
            ths = [ID2N[x]["label"] for x in nbrs if ID2N[x]["type"] == THEORY_TYPE]
            add("T", "是否应建立涵盖%s的统一理论框架？判别性预测是什么？" % "、".join(ths[:3]), "R4a 理论型空白多理论")
        if gsub == "方法":
            add("M", "现有方法在[%s]上失效的根因是什么？如何组合/改造出新方法？" % ID2N[g]["label"], "R4b 方法型空白")
        if gsub == "知识" and THEORY_TYPE in types:
            ths = [ID2N[x]["label"] for x in nbrs if ID2N[x]["type"] == THEORY_TYPE]
            add("K", "%s在空白[%s]上的解释边界？是否需新构念？" % ("、".join(ths[:2]), ID2N[g]["label"]), "R4c 知识型空白含理论")
        if gsub == "关系" and sum(types.count(t) for t in CONCEPT_TYPES) >= 2:
            cs = [ID2N[x]["label"] for x in nbrs if ID2N[x]["type"] in CONCEPT_TYPES]
            add("R", "%s的关系是否受第三变量调节？" % "与".join(cs[:2]), "R4d 关系型空白含多构念")
    return derived

def build_graph_json():
    """生成供 generate_kg_html.py 使用的 graph.json。"""
    nodes = [{"id": i, "label": e[1], "type": e[2], "sub": e[3]} for i, e in enumerate(ENTITIES)]
    idx = {e[0]: i for i, e in enumerate(ENTITIES)}
    edges = [{"s": idx[f], "t": idx[t], "rel": r} for f, r, t in EDGES]
    return {"nodes": nodes, "edges": edges, "typeLabel": TYPE_LABEL, "relLabel": REL_LABEL}

def main():
    # 连通性
    comps, isolated = check_connectivity()
    print("连通分量数: %d，最大分量 %d 节点" % (len(comps), len(comps[0])))
    for c in isolated:
        names = [ID2N[v]["label"] for v in sorted(c)]
        print("  [孤立分支] %d 节点: %s" % (len(c), "、".join(names)))

    # 推理
    adj = {i: set() for i in ID2N}
    edge_dir = {}
    for f, r, t in EDGES:
        adj[f].add(t); adj[t].add(f)
        edge_dir.setdefault((f, t), []).append(r)
    derived = infer(adj, edge_dir)
    order = {"K":0,"R":1,"T":2,"M":3}
    derived.sort(key=lambda d: (order[d[0]], d[1]))
    print("\n衍生问题总数: %d" % len(derived))
    for kind, qid, text, ev in derived:
        print("[%s] %s | %s | 证据: %s" % (kind, qid, text, ev))

    # 输出文件
    out_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(out_dir, "graph.json"), "w", encoding="utf-8") as f:
        json.dump(build_graph_json(), f, ensure_ascii=False, indent=1)
    with open(os.path.join(out_dir, "derived_questions.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join("[%s] %s | %s" % (k, q, t) for k, q, t, _ in derived))
    print("\n已输出 graph.json 与 derived_questions.txt")

if __name__ == "__main__":
    main()
