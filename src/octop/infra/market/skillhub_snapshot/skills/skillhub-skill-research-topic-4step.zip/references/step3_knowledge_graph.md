# 知识图谱制作（3-2 演绎路径产出）

知识图谱是 3-2 演绎路径的核心产出，包含「领域本体 → 逻辑推理 → 交互式可视化」三个环节。本文档讲制作与验证，推理引擎用法见 `references/step3_question_generation.md` 的 3-2。

## 步骤

### 1. 准备图谱数据
- 复制 `scripts/kg_data_example.py` 为 `scripts/kg_data.py`，按注释格式填入实体（id/label/type/sub）与关系（from/rel/to）三元组。
- gap 类型实体的 sub 字段取「知识/关系/理论/方法」，决定推理引擎的问题类型。
- 运行 `scripts/build_kg_and_infer.py` 会自动生成 `graph.json`（含 nodes/edges/typeLabel/relLabel），无需手工拼 JSON。

### 2. 连通性检查（必做）
- `build_kg_and_infer.py` 会自动 BFS 找连通分量并打印孤立分支。
- 若出现孤立分支（某几个节点自成一团、与主图无连接），补一条语义合理的桥接边连入主图（如某子主题分支桥接到其上位主题）。

### 3. 生成 HTML
- 运行 `scripts/generate_kg_html.py`，读取图谱 JSON + `assets/kg_template.html`，替换 `__GRAPH_DATA__` 占位符生成单文件 HTML（零外部依赖）。

### 4. 验证与迭代
- 用浏览器实际渲染截图验证；交互验证须注意 pitfalls.md 第 19-22 条（file 协议、rAF 停摆、eval IIFE、缓存）。
- 交付用户审阅，按反馈迭代样式与互动（参考 `references/kg_visual_spec.md`）。

## 产出
- 交互式知识图谱 HTML（`03_知识图谱_3-2.html`：力导向、缩放平移、高亮不隐藏、同心环分层、节点拖拽）

## 关键规范
- 样式与互动要求严格遵循 `references/kg_visual_spec.md`，逐条核对，不得省略。
