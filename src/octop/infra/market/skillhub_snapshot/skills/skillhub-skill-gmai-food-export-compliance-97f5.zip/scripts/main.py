# -*- coding: utf-8 -*-
"""食品出口合规核查器（gmai-food-export-compliance-97f5）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：出口合规核查表（法规符合性、限量要求、证书与注册逐项）；差距项清单与整改建议；通关与检验检疫流程要点
建议输入（专业字段）：业务场景；适用规则；数据类型；主体角色
"""
import json, os, re, sys, time

SLUG = "gmai-food-export-compliance-97f5"
TITLE = "食品出口合规核查器"
PRICE_FEN = 1990
CATEGORY = "食品与农业合规"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['业务场景', True, ['场景', '业务描述', '处理活动'], '描述谁在做什么处理活动，是判断适用的起点'], ['适用规则', True, ['适用法规', '监管要求', '合规依据'], '指明拟对照的规则，未指明时按领域通用规则核对'], ['数据类型', True, ['处理对象', '信息类型', '数据类别'], '对象类别与敏感级别决定保护强度'], ['主体角色', True, ['角色', '主体定位', '处理者角色'], '决定申报、评估与留痕义务的边界'], ['跨境情形', False, ['出境', '跨境传输', '境外接收方'], '涉及跨境须单独评估并提供依据'], ['现有控制措施', False, ['现有措施', '控制现状', '已采取措施'], '用于计算与要求的差距'], ['留存期限', False, ['保存期限', '留档年限'], '留痕要求的期限依据']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'items': [['许可与资质', '生产经营许可与许可范围是否覆盖实际产品', '高', '核对许可证明与产品清单', '超范围品类停止生产或补办许可'], ['配料与添加剂使用', '配料表与添加剂使用是否符合标准限量', '高', '逐项核对配料表与使用记录', '调整配方或用量并复核'], ['标签标识', '标签要素与宣称是否合规、无功效暗示', '高', '逐项核对标签要素与宣传用语', '修订标签与宣传用语'], ['保质期与储存条件', '保质期设定是否有依据且标注准确', '中', '核对稳定性试验与实际储存条件', '补充依据并修正标注'], ['进货查验与追溯', '原料是否查验并形成可追溯链条', '中', '抽查进货台账与批次追溯', '建立批次追溯台账'], ['出厂检验', '是否按标准完成出厂检验并留档', '中', '抽查检验报告与批次对应关系', '按批次完成检验并归档'], ['从业人员健康管理', '接触直接入口食品人员是否持有效健康证明', '低', '核对健康证明有效期', '安排体检并更新台账']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['《中华人民共和国个人信息保护法》相关规定（告知同意、最小必要、跨境传输、个人权利）', '《中华人民共和国数据安全法》数据分类分级与安全保护义务', '《中华人民共和国网络安全法》网络运营者安全保护义务', '个人信息处理者与受托处理者的义务划分（委托处理需订立协议并监督）', '数据出境安全评估、标准合同与认证等合规路径', '事件通知与记录留存要求（按适用规定执行）']
# 自检项（输入完备度）
CHECKS = [['食品出口合规核查·产品与用途确认', ['食品出口合规核查', '核对目标国法规与证书要求'], '先确认产品类别、加工方式与目标市场'], ['食品出口合规核查·限量与标准核对', ['核对目标国法规与证书要求', '食品出口合规核查器'], '逐项核对添加剂、污染物或农残限量要求'], ['食品出口合规核查·标签与宣称核查', ['食品出口合规核查器', '食品出口合规核查'], '核对标识要素与声称的合规条件'], ['食品出口合规核查·红线识别', ['食品出口合规核查'], '识别功效夸大与虚假检测情形，命中即终止'], ['食品出口合规核查·整改与记录清单', ['食品出口合规核查', '核对目标国法规与证书要求'], '输出整改项与追溯记录要求']]
# 交付物构成
DELIVERABLES = ['出口合规核查表（法规符合性、限量要求、证书与注册逐项）', '差距项清单与整改建议', '通关与检验检疫流程要点']
FOOTER = "本报告不构成检验检测结论；上市销售以监管许可与检验报告为准。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """合规核对交付物：适用范围 → 法规判定 → 逐条款核对 → 风险分级 → 整改路径 → 留痕"""
    P = ctx["spec"]["params"]; L = []
    scene = ctx["fv"]("业务场景")
    reg = ctx["fv"]("适用法规")
    dtype = ctx["fv"]("数据类型") or ctx["fv"]("处理对象")
    cross = ctx["fv"]("跨境情形")
    role = ctx["fv"]("主体角色")
    keep = ctx["fv"]("留存期限")
    ctrl = ctx["fv"]("现有控制措施")
    item = ctx["spec"]["title"]
    items = P.get("items") or []
    highs = sum(1 for x in items if x[2] == "高")
    mids = sum(1 for x in items if x[2] == "中")
    lows = sum(1 for x in items if x[2] == "低")

    L.append(("一、适用范围与结论摘要", [
        "- 核对对象：%s" % (brief(scene, 60) or "（未提供业务场景，需补充后方可定位适用规则）"),
        "- 适用规则来源：%s" % (brief(reg, 60) or "（未指定，按%s领域通用规则核对，需法务确认属地适用版本）" % item),
        "- 主体角色：%s" % (brief(role, 40) or "（未提供，角色决定义务边界，必须补充）"),
        "- 客体/数据类型：%s" % (brief(dtype, 40) or "（未提供，需明确对象类别与敏感级别）"),
        "- 跨境情形：%s" % (brief(cross, 40) or "未涉及/未说明（如涉及跨境传输须单独评估）"),
        "",
        "**结论摘要**：本次核对共 %d 项要点，其中高风险 %d 项、中风险 %d 项、低风险 %d 项。高风险项在整改完成前不建议上线或推进；中风险项应在 30 天内闭环；低风险项纳入例行巡检。" % (
            len(items), highs, mids, lows),
    ]))

    L.append(("二、适用规则判定", [
        "| 判定维度 | 本次情形 | 判定结论 |", "|---|---|---|",
        "| 管辖与适用法域 | %s | 由主体注册地、业务发生地与数据/物项流向共同决定 |" % (brief(cross, 30) or "境内"),
        "| 适用规则清单 | %s | 需逐条核对现行有效版本并标注生效时间 |" % (brief(reg, 40) or "按领域通用规则"),
        "| 主体义务类型 | %s | 决定申报、备案、评估或留痕义务 |" % (brief(role, 30) or "待确认"),
        "| 客体敏感级别 | %s | 决定保护强度与审批层级 |" % (brief(dtype, 30) or "待确认"),
        "",
        "> 规则以官方公布的现行有效版本为准；本表不替代属地法务对适用版本的确认。",
    ]))

    rows = ["| 序号 | 核对要点 | 判定问题 | 风险等级 | 核实方式 | 整改动作 |", "|---|---|---|---|---|---|"]
    for i, x in enumerate(items, 1):
        rows.append("| %d | %s | %s | %s | %s | %s |" % (i, x[0], x[1], x[2], x[3], x[4]))
    if not items:
        rows.append("| 1 | 待补充核对要点 | 依适用规则清单逐条展开 | 高 | 逐项核对现行文本 | 形成核对台账 |")
    L.append(("三、逐项核对表", rows))

    pri = ["| 优先级 | 整改事项 | 责任角色 | 建议期限 | 关闭证据 |", "|---|---|---|---|---|"]
    for x in [x for x in items if x[2] == "高"][:6]:
        pri.append("| P0 | %s | 合规负责人 | 立即（上线前） | %s |" % (x[4], x[3]))
    for x in [x for x in items if x[2] == "中"][:6]:
        pri.append("| P1 | %s | 业务负责人 + 合规 | 30 天内 | %s |" % (x[4], x[3]))
    for x in [x for x in items if x[2] == "低"][:6]:
        pri.append("| P2 | %s | 业务负责人 | 纳入例行巡检 | %s |" % (x[4], x[3]))
    if len(pri) == 2:
        pri.append("| P0 | 补齐核对要点后重新定级 | 合规负责人 | 立即 | 更新后的核对台账 |")
    L.append(("四、整改路径与优先级", pri))

    L.append(("五、留痕与报告要件", [
        "| 留痕对象 | 内容要求 | 保存期限 |", "|---|---|---|",
        "| 核对记录 | 本次核对依据的规则版本、逐项结论、核实人 | %s |" % (brief(keep, 24) or "按适用规则要求（一般不少于 3 年）"),
        "| 证据材料 | 合同/授权/评估报告/审批单据等原始件 | 同记录期限 |",
        "| 整改证据 | 关闭证据、复核记录与责任人签署 | 同记录期限 |",
        "| 变更记录 | 业务或规则变化后的再核对记录 | 同记录期限 |",
        "",
        "现有控制措施（%s）与上述要求的差距，应在整改表中逐项对应并指定关闭证据。" % (brief(ctrl, 40) or "未提供，需补充现状描述"),
    ]))

    L.append(("六、持续监控建议", [
        "- 规则变更监控：指定责任人按季度复核适用规则的现行有效版本与生效时间。",
        "- 触发式复核：业务模式、数据类型、流向或主体角色发生变更时立即重新核对。",
        "- 抽样复核：按季度抽取执行记录，核对与本次核对表的一致性并留痕。",
        "",
        "> 本核对表为合规作业参考，**不构成法律意见**；规则适用与定性判断应由具备相应资质的法务人员确认后使用。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
