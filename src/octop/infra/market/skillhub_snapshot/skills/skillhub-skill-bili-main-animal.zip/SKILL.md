---
name: skillhub-skill-bili-main-animal
description: "当用户想按 B 站「动物圈」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：动物圈、B站分区、rid 217。"
---

# B 站分区 · 动物圈

- 一级分区 rid：`217`；网页路由：`/v/animal/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 96 条榜单条目，覆盖 6 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 动物二创 | 6 | 7 | 220 |
| 动物综合 | 6 | 7 | 75 |
| 喵星人 | 42 | 9 | 218 |
| 小宠异宠 | 7 | 9 | 222 |
| 汪星人 | 29 | 10 | 219 |
| 野生动物 | 6 | 8 | 221 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 动物二创

数据来源：二级分区 7 日榜，可用 7 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 棘龙重新竞争最大兽脚类（上集）复原思路篇 | 龙爪洪荒 | [BV1gNRdYJExx](https://www.bilibili.com/video/BV1gNRdYJExx) | 96.9 万 |
| 我的引体向上现状 | 迷途0001 | [BV1YtZmYGEnW](https://www.bilibili.com/video/BV1YtZmYGEnW) | 98.4 万 |
| 为 母 则 不 锈 钢 Ⅲ | 知了解压萌物 | [BV1ReRdYbEvJ](https://www.bilibili.com/video/BV1ReRdYbEvJ) | 129.4 万 |
| 那些略微超标的动物们！ | 蒙哥马利愛学习 | [BV15EZRYaEoT](https://www.bilibili.com/video/BV15EZRYaEoT) | 77.5 万 |
| 《不白来哈，都不白来》 | 龙馍馍 | [BV1gadHYoECT](https://www.bilibili.com/video/BV1gadHYoECT) | 36.6 万 |

### 动物综合

数据来源：二级分区 7 日榜，可用 7 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 听劝式动物园！ | 长沙ZOOLUNG室内动物园 | [BV1j9ZRYBERQ](https://www.bilibili.com/video/BV1j9ZRYBERQ) | 375.6 万 |
| 水族馆竟这么离谱？触摸池里的深水炸弹！重庆海昌海洋馆 | 爱养鱼的卓林 | [BV1y7Z9YVEzy](https://www.bilibili.com/video/BV1y7Z9YVEzy) | 125.1 万 |
| 把我同桌她吓哭了，乌鸦竟把蚂蚁榨干了 | 账号已注销 | [BV1mMZJYHEFB](https://www.bilibili.com/video/BV1mMZJYHEFB) | 103.6 万 |
| 当小鸟学会用身体骗人开门 | 鹦鹉优品 | [BV1awR2Y8E4C](https://www.bilibili.com/video/BV1awR2Y8E4C) | 35.9 万 |
| 你们养的德牧也这个样子吗？逮谁干谁！ | 阿东乐园 | [BV1UCR9YyEsf](https://www.bilibili.com/video/BV1UCR9YyEsf) | 502.6 万 |

### 喵星人

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 小猫：叽里咕噜在说啥呢 | 短腿小拖宝 | [BV13iRkYDESk](https://www.bilibili.com/video/BV13iRkYDESk) | 278.4 万 |
| 美男子布偶猫洗护 | 喵小睇d | [BV17BRUYCEvG](https://www.bilibili.com/video/BV17BRUYCEvG) | 347.4 万 |
| 大叔训练小动物 | 大叔爱玩猫 | [BV1zvRDYWERh](https://www.bilibili.com/video/BV1zvRDYWERh) | 100.2 万 |
| 小猫的坚持换来了同伴的一线生机 | 小饼遇见猫 | [BV1jFZUYnEZg](https://www.bilibili.com/video/BV1jFZUYnEZg) | 95.3 万 |
| 方便袋成功上岸，以后请尊称方主任 | 本喵叫兔兔 | [BV1C6RoY5EjA](https://www.bilibili.com/video/BV1C6RoY5EjA) | 131.5 万 |

### 小宠异宠

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 要了我半条命，终于找到这只狐狸了！！！ | 提提斯 | [BV1vbZSYJE2m](https://www.bilibili.com/video/BV1vbZSYJE2m) | 503.0 万 |
| 这家伙有点嚣张啊，关起来 | 天下一场梦 | [BV1nyRoYrEDU](https://www.bilibili.com/video/BV1nyRoYrEDU) | 57.0 万 |
| 整一只小脊蛊（蚰蜒）玩玩 | 一枚甲虫迷 | [BV1HgdWYSEhd](https://www.bilibili.com/video/BV1HgdWYSEhd) | 133.5 万 |
| 四大顶尖战力参与大灭绝，复仇之战？！新李火旺加入慈鲷阵营。 | 蔡武年 | [BV1UqZmYKEfy](https://www.bilibili.com/video/BV1UqZmYKEfy) | 128.2 万 |
| 【仓鼠】鼠：我铺垫料吗，有点意思 | 你就跟你那老鼠过去吧 | [BV1AmZoYnEe4](https://www.bilibili.com/video/BV1AmZoYnEe4) | 52.3 万 |

### 汪星人

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 高智商犯罪之打劫全世界 | 哈哈皮没有耳朵 | [BV1UoZdYsEEE](https://www.bilibili.com/video/BV1UoZdYsEEE) | 191.9 万 |
| 见到主人新买只伯恩山回家，家里的三只狗会作何反应？ | 哈仔十一 | [BV1ueRBYiEPP](https://www.bilibili.com/video/BV1ueRBYiEPP) | 185.6 万 |
| “没有哪只小狗能抵抗得了嘬嘬嘬的诱惑” | 动物治愈馆 | [BV1CNRBYxEue](https://www.bilibili.com/video/BV1CNRBYxEue) | 311.2 万 |
| 潺潺流水终于穿过了一座座山，爱的终点也一定是熊熊燃烧的希望之火 | 小阳爱猫狗公益账号 | [BV1UoZ2YYEcA](https://www.bilibili.com/video/BV1UoZ2YYEcA) | 66.3 万 |
| 西卡：花生啊喂我花生 | 西卡观察员 | [BV1pJRyYgEvX](https://www.bilibili.com/video/BV1pJRyYgEvX) | 269.2 万 |

### 野生动物

数据来源：二级分区 7 日榜，可用 8 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 心有鱼而力不足 | 涛哥玩配音 | [BV1kfR9YeEB7](https://www.bilibili.com/video/BV1kfR9YeEB7) | 200.1 万 |
| 谁家新燕啄春泥啄春泥啄春泥啄春泥起飞；啄春泥啄春泥啄春泥啄春泥起飞；啄春泥啄春泥啄春泥啄春泥起飞；啄春泥啄春泥啄春泥啄春泥起飞；啄春泥啄春泥啄春泥啄春泥起飞 | Reahven | [BV1DGRzYzEaa](https://www.bilibili.com/video/BV1DGRzYzEaa) | 76.3 万 |
| 海兔，一种连呼吸都散发着可爱的生物 | 动物007 | [BV1trZmYYEj1](https://www.bilibili.com/video/BV1trZmYYEj1) | 107.8 万 |
| 没想到白眼狼还有后续，在野外生活快半个月了，瘦了不少！ | MK的鹦鹉 | [BV1andbY7ES6](https://www.bilibili.com/video/BV1andbY7ES6) | 36.3 万 |
| 【雪豹】凌小蛰不正经科普 | 圆掌 | [BV1AbZZYpEH4](https://www.bilibili.com/video/BV1AbZZYpEH4) | 31.1 万 |

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=217." https://api.bilibili.com/x/web-interface/ranking/v2?rid=217&type=all. Accessed 6 Nov. 2026.
