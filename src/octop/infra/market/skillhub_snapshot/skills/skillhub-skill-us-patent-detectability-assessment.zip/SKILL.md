---
name: skillhub-skill-us-patent-detectability-assessment
description: "Assess whether infringement of proposed patent claims can be detected in products. Use when the user wants to evaluate claim enforceability or detectability. 评估他人实施该发明时侵权行为能否被发现，用于决定是否申请以及如何布局权利要求以提升可执行性。"
---

# Detectability Assessment

Evaluate how easily an invention's implementation can be detected in potentially infringing products, helping decide whether to patent it and how to structure claims for maximum enforceability.

## Instructions

1. Read the instruction file at `${CLAUDE_SKILL_DIR}/references/prompt.md`
2. Ask the user for the required inputs if not already provided via `$ARGUMENTS`:
   - **Patent claims** or **invention disclosure** to assess
3. Fill in the `{{PLACEHOLDER}}` values with the user's content
4. Execute the prompt to perform the assessment
5. Present the output to the user If the user provides a file path or pasted content as `$ARGUMENTS`, use that as input.

## Inputs

| Placeholder | What to put here |
|---|---|
| `{{PATENT_CLAIMS}}` | The subject matter to analyze. Use **one** of the following formats: |

## Attribution

Adapted from **arcprime-ip/patent-prompts** (MIT License) by ArcPrime — <https://github.com/arcprime-ip/patent-prompts>.
Original prompt text is reproduced with the license notice retained. Modifications: repackaged into a
standalone skill with `references/prompt.md`, bilingual description, and SkillHub metadata.

> This skill produces an analytical aid, not legal advice. Always have a qualified patent
> professional review any output before relying on it.

## Scope

Written for **US patent practice** — USPTO filing and prosecution, 35 U.S.C. §§ 101/102/103/112,
Alice/Mayo eligibility, Graham/KSR obviousness. For CNIPA or EPO practice, the statutory
frameworks differ and the analysis must be adapted.
