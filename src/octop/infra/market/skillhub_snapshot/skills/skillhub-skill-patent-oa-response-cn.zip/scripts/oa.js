#!/usr/bin/env node
/**
 * OA 答复制作与修订 —— 技能脚本（零依赖，Node 12+）。
 *
 *   node oa.js create <申请号> [--new]                    建任务并等待第 1 轮
 *   node oa.js wait   <taskId>                             接着等（断线、超时后都用它）
 *   node oa.js revise <taskId> --opinion-file <文件>       提交修改观点并等待
 *   node oa.js retry  <taskId>                             重试失败的那一轮
 *   node oa.js status <taskId>                             只查一次状态
 *   node oa.js save   <taskId> [轮次]                      重新下载某一轮的 OA 文件存到本地（比如文件被删了；不给轮次存最新一版）
 *
 * 退出码：0 这一步有结果了 / 10 还在生成，再运行一次 wait / 2 输入或本地文件有误
 *        / 3 已有进行中的任务或轮次（这次什么都没提交）/ 1 出错
 *
 * 进度打印成「[进度 X%] …」，节点固定（0 / 10 / 20 / 30 / 50 / 70 / 100），SKILL.md 里有对应的话术表。
 * 取材料、排队、分析、撰写这几段每 30 秒重报一次：内容没变也报，它就是心跳。
 *
 * <b>每条命令最多等 OA_WAIT_SECONDS 秒（默认 30，和心跳同步）就返回</b>，还在生成时退出码 10，AI 把进度告诉用户再运行 wait；
 * create / revise / retry 刚开始一轮时只等 15 秒就先返回一次，让「启动、准备材料」早点报出去。
 * WorkBuddy 前台跑命令时要等命令结束才显示输出、AI 也插不了话（2026-09-28 实测），命令越短用户越早看到进度；
 * 一出结果马上返回，不用等满——命令里照旧按 pollAfterSeconds（默认 10 秒）查一次。
 * 生成在服务端跑，命令结束或被杀都不影响，再运行 wait 接着看。
 *
 * 每轮做完自动把正文存成文件、报出路径（和第一版一样），AI 读这个文件把正文展示给用户，不在输出里再打一遍正文。
 *
 * --stream：在终端里直接跑、想边写边看正文时用（技能不用）。正文夹在「[正文开始]」和「[正文结束]」之间一段段打出来，
 * 中途重新生成过就打「[正文中断] …」、之后从头再输出；每条命令最多等 540 秒。
 *
 * 状态存在 OA_STATE_DIR（默认 ~/.oa-reply/），建任务前先把 requestKey 落盘：断线后重跑同一条 create 会拿回同一个任务。
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');

const BASE = (process.env.OA_SKILL_BASE_URL || 'https://sage-ai.net/api/v3/oa/skill').replace(/\/+$/, '');
const STATE_DIR = process.env.OA_STATE_DIR || path.join(os.homedir(), '.oa-reply');
/** 带了 --stream：边写边打正文（见文件开头）。 */
let streamMode = false;

function waitSeconds() {
  const fallback = streamMode ? 540 : 30;
  return Math.max(30, parseInt(process.env.OA_WAIT_SECONDS || String(fallback), 10) || fallback);
}

/**
 * 建任务、提交修订、重试这三条命令只等这么久就先返回：刚开始那一分钟状态变得最快（启动、准备材料、材料完成、开始分析），
 * 等满的话这几条会攒成一批才让用户看到。先返回一次，「启动、准备材料」十几秒内就能报出去，之后的 wait 再按 30 秒一批。
 */
const FIRST_WAIT_SECONDS = 15;

function firstWaitSeconds() {
  return streamMode ? waitSeconds() : Math.min(FIRST_WAIT_SECONDS, waitSeconds());
}
/** 取材料、排队、分析、撰写这几段隔多久重报一次进度（心跳）。 */
const TICK_MS = 30000;
const PENDING_TTL_MS = 24 * 3600 * 1000;
const REQUEST_TIMEOUT_MS = 60000;

const EXIT_OK = 0;
const EXIT_ERROR = 1;
const EXIT_INPUT = 2;
const EXIT_EXISTING = 3;
const EXIT_RUNNING = 10;

const TASK_ID_RE = /^oa_[0-9a-f]{32}$/;
const STANDARD_NO_RE = /^\d{12}[0-9X]$/;
/** 本地文件读写出的错：报成「网络问题」的话 AI 会原样重跑，而不是去改路径。 */
const LOCAL_ERRORS = ['ENOENT', 'EACCES', 'EPERM', 'EROFS', 'EISDIR', 'ENOTDIR', 'ENOSPC', 'EBUSY'];

// ------------------------------------------------------------------ 申请号（与服务端同一套规则）

/**
 * 可选前缀只认 CN / cn / ZL；12 位数字 + 可选的点 + 1 位校验位（0-9 或大写 X）；
 * 标准化后第 5 位必须是 1 或 8。不合格返回 null。
 */
function normalizePatentNo(raw) {
  if (typeof raw !== 'string') return null;
  const v = raw.trim();
  if (!/^(CN|cn|ZL)?\d{12}\.?[0-9X]$/.test(v)) return null;
  const body = v.replace(/^(CN|cn|ZL)/, '').replace('.', '');
  if (body.length !== 13 || !STANDARD_NO_RE.test(body)) return null;
  if (body[4] !== '1' && body[4] !== '8') return null;
  return body;
}

// ------------------------------------------------------------------ 本地文件

function ensureStateDir() {
  fs.mkdirSync(STATE_DIR, { recursive: true });
}

function taskFile(taskId) {
  return path.join(STATE_DIR, taskId + '.json');
}

function pendingFile(patentNo) {
  return path.join(STATE_DIR, 'pending-' + patentNo + '.json');
}

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return null;
  }
}

/** 先写临时文件再改名：写到一半被杀也不会留下一个坏文件。临时文件名带进程号，两个命令同时写也不会互相踩。 */
function writeJson(file, data) {
  ensureStateDir();
  const tmp = file + '.' + process.pid + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}

/** 记一下这个任务最近的状态，给 create 判断「这件专利是不是已经有没结束的任务」用。写不进去不影响主流程。 */
function saveTaskState(view, extra) {
  try {
    const file = taskFile(view.taskId);
    const old = readJson(file) || {};
    writeJson(file, Object.assign({}, old, extra || {}, {
      taskId: view.taskId,
      patentNo: view.patentNo,
      lastStatus: view.status,
      lastNextAction: view.nextAction,
      currentRound: view.currentRound,
      updatedAt: new Date().toISOString(),
    }));
  } catch (e) {
    say('（提示：本地状态没写进去：' + e.message + '，不影响这次操作）');
  }
}

/** 本地记着的、这件专利还没结束的任务（只看本机）。 */
function findOpenLocalTask(patentNo) {
  let names = [];
  try {
    names = fs.readdirSync(STATE_DIR);
  } catch (e) {
    return null;
  }
  for (const name of names) {
    if (!/^oa_[0-9a-f]{32}\.json$/.test(name)) continue;
    const s = readJson(path.join(STATE_DIR, name));
    if (s && s.patentNo === patentNo && ['WAIT', 'REVISE', 'RETRY_ROUND'].indexOf(s.lastNextAction) >= 0) {
      return s;
    }
  }
  return null;
}

/**
 * 读修改观点文件。只收 UTF-8（可带 BOM）和带 BOM 的 UTF-16；解出来有乱码（GBK 按 UTF-8 读）
 * 或空字符（没 BOM 的 UTF-16）就返回 null——乱码照样能提交上去，还会用掉一次修订。
 */
function readTextFile(file) {
  const buf = fs.readFileSync(file);
  let text;
  if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
    text = buf.slice(2).toString('utf16le');
  } else if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) {
    const body = Buffer.from(buf.slice(2));
    if (body.length % 2 !== 0) return null;
    text = body.swap16().toString('utf16le');
  } else {
    text = buf.toString('utf8').replace(/^\uFEFF/, '');
  }
  if (text.indexOf('\uFFFD') >= 0 || text.indexOf('\u0000') >= 0) return null;
  return text;
}

// ------------------------------------------------------------------ HTTP

function checkBase() {
  const u = new URL(BASE);
  // 只许 https；http 只给本机调试用
  if (u.protocol !== 'https:' && !(u.protocol === 'http:' && /^(localhost|127\.0\.0\.1|\[::1\])$/.test(u.hostname))) {
    const e = new Error('OA_SKILL_BASE_URL 必须是 https 地址：' + BASE);
    e.inputError = true;
    throw e;
  }
}

function request(method, url, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body), 'utf8');
    const headers = { Accept: 'application/json' };
    if (payload) {
      headers['Content-Type'] = 'application/json; charset=utf-8';
      headers['Content-Length'] = payload.length;
    }
    const lib = u.protocol === 'http:' ? http : https;
    let settled = false;
    const done = (fn, v) => {
      if (!settled) {
        settled = true;
        fn(v);
      }
    };
    const req = lib.request(u, { method, headers, timeout: timeoutMs }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('error', (e) => done(reject, e));
      // 响应体中途断开：有的 Node 版本不会触发 end，不接住的话 Promise 永远不结束
      res.on('close', () => {
        if (!res.complete) done(reject, new Error('连接中断'));
      });
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let json = null;
        try {
          json = JSON.parse(text);
        } catch (e) {
          // 网关错误页之类，不是我们的 JSON
        }
        done(resolve, { status: res.statusCode, json, text });
      });
    });
    req.on('timeout', () => req.destroy(new Error('请求超时')));
    req.on('error', (e) => done(reject, e));
    if (payload) req.write(payload);
    req.end();
  });
}

class ApiError extends Error {
  constructor(status, errorCode, message) {
    super(message);
    this.status = status;
    this.errorCode = errorCode;
  }
}

/**
 * 调接口。网络问题、服务端 5xx、网关限速（RATE_LIMITED，几秒后就放行）自动重试几次；重试不会重复生成。
 * 服务端明确回了业务错误（带 errorCode 的 4xx，包括 429 的排队满、今天的额度用完）直接抛：等几秒再问结果一样。
 * 给了 deadline 就不越过它：每次请求的超时和重试都在剩余时间内。
 */
async function api(method, pathname, body, deadline) {
  const tries = 4;
  let lastErr;
  for (let i = 0; i < tries; i++) {
    const left = deadline ? deadline - Date.now() : REQUEST_TIMEOUT_MS;
    if (left <= 1000) break;
    try {
      const r = await request(method, BASE + pathname, body, Math.min(REQUEST_TIMEOUT_MS, left));
      if (r.json && r.json.code === '200') return r.json.data;
      if (r.json && r.json.errorCode) {
        if (r.status >= 500 || r.json.errorCode === 'RATE_LIMITED') {
          lastErr = new ApiError(r.status, r.json.errorCode, r.json.msg);
        } else {
          throw new ApiError(r.status, r.json.errorCode, r.json.msg);
        }
      } else if (r.status >= 500 || r.status === 429 || r.status === 408) {
        lastErr = new Error('服务暂时不可用（HTTP ' + r.status + '）');
      } else {
        throw new ApiError(r.status, 'HTTP_' + r.status, '服务返回了无法识别的内容（HTTP ' + r.status + '）');
      }
    } catch (e) {
      if (e instanceof ApiError) throw e;
      lastErr = e;
    }
    const pause = 3000 * (i + 1);
    if (i === tries - 1 || (deadline && Date.now() + pause >= deadline)) break;
    await sleep(pause);
  }
  throw lastErr || new Error('请求超时');
}

/** 服务端给的任务视图要拿来拼本地文件路径，先确认它长得对。 */
function checkView(v) {
  if (!v || !TASK_ID_RE.test(v.taskId || '') || !STANDARD_NO_RE.test(v.patentNo || '')
      || !(Number.isInteger(v.currentRound) && v.currentRound >= 0)) {
    throw new Error('服务返回的任务信息不完整');
  }
  return v;
}

/** textFrom：已经打出来的正文字数。给了，服务端就顺带返回生成中新写出来的那一段（流式）。 */
async function getTask(taskId, deadline, textFrom) {
  const query = textFrom === undefined ? '' : '?textFrom=' + textFrom;
  return checkView(await api('GET', '/tasks/' + taskId + query, undefined, deadline));
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// ------------------------------------------------------------------ 输出

function say(line) {
  process.stdout.write(line + '\n');
}

/** 最后一行给 AI 读的机器可读摘要。 */
function summary(view, extra) {
  const s = {
    taskId: view.taskId,
    patentNo: view.patentNo,
    oaType: view.oaTypeLabel || null,
    status: view.status,
    nextAction: view.nextAction,
    currentRound: view.currentRound,
    maxRounds: view.maxRounds,
    remainingRevisions: view.remainingRevisions,
    latestDocumentRound: view.latestDocumentRound,
  };
  say('@@OA ' + JSON.stringify(Object.assign(s, extra || {})));
}

/**
 * 文件名带任务号后 6 位：同一件专利可能先后有好几个任务，只按申请号和轮次命名的话，
 * 第二个任务的结果会和第一个撞名。
 */
function outputPath(patentNo, taskId, roundNo) {
  const dir = process.env.OA_OUTPUT_DIR || process.cwd();
  return path.join(dir, 'OA答复_' + patentNo + '_' + taskId.slice(-6) + '_第' + roundNo + '轮.md');
}

// ------------------------------------------------------------------ 等待与取结果

/**
 * 进度行。<b>百分比只用固定的几个值</b>（SKILL.md 的话术表按百分比查行，报一个表里没有的数字，
 * 转述的那一头就没法办了）；会变的信息（已用时）放在后半句。
 */
function progress(percent, text) {
  say('[进度 ' + percent + '%] ' + text);
}

/** 秒数 → 「42 秒」「1分钟」「4分33秒」。 */
function duration(seconds) {
  const s = Math.max(0, Math.round(seconds));
  if (s < 60) return s + ' 秒';
  return Math.floor(s / 60) + (s % 60 === 0 ? '分钟' : '分' + (s % 60) + '秒');
}

/**
 * 当前处在哪一段，报哪一行。字数只用来区分「分析」和「撰写」两段，不报给用户。
 */
function stageOf(v) {
  const since = (label) => (v.elapsedSeconds == null ? '' : '，' + label + ' ' + duration(v.elapsedSeconds));
  if (v.status === 'PREPARING') {
    return { key: 'fetch', percent: 10, text: '全周期材料准备中' + since('已用时') };
  }
  const revise = v.currentRound >= 2;
  const r = v.round || {};
  if (r.status === 'PENDING') {
    return { key: 'queue', percent: 30, text: '排队中' + since('已等待') };
  }
  if (!(r.outputChars > 0)) {
    return { key: 'analyze', percent: 50, text: (revise ? '分析修改观点中' : '分析全周期材料中') + since('已用时') };
  }
  return { key: 'write', percent: 70, text: (revise ? '修订答复中' : '撰写答复中') + since('已用时') };
}

// ------------------------------------------------------------------ 正文（流式）

/** 控制字符（保留换行和制表符）：正文打到终端之前去掉，免得清屏、改标题这类终端控制序列生效。 */
const CONTROL_CHARS = /[\u0000-\u0008\u000B-\u001F\u007F-\u009F]/g;

function clean(text) {
  return text.replace(CONTROL_CHARS, '');
}

/**
 * 正文的输出状态：打到了哪一次生成（streamId）、收到的服务端原文（按它算 textFrom、比对前缀）、
 * 最后打出去的一个字（补换行用）。同一次生成的正文只会往后长，新的一段接在后面打；换了一次生成就作废重来。
 */
function newBody() {
  return { open: false, streamId: null, received: '', last: '' };
}

function writeText(body, text) {
  if (!text) return;
  body.received += text;
  const out = clean(text);
  if (out) {
    process.stdout.write(out);
    body.last = out[out.length - 1];
  }
}

function openBody(body, streamId) {
  say('[正文开始]');
  Object.assign(body, newBody(), { open: true, streamId });
}

/** 标记行必须单独一行：正文末尾没换行就先补一个。 */
function endLine(body) {
  if (body.last && body.last !== '\n') {
    process.stdout.write('\n');
  }
}

/** 已经打出去的半截作废，message 是给用户的一句话。 */
function interruptBody(body, message) {
  if (!body.open) return;
  endLine(body);
  say('[正文中断] ' + message);
  Object.assign(body, newBody());
}

/** 这一轮的完整正文：流式打过的是它的开头就补齐后面，否则整篇重新打。 */
function finishBody(body, output) {
  if (body.open && output.indexOf(body.received) === 0) {
    writeText(body, output.slice(body.received.length));
  } else {
    interruptBody(body, '中途重新生成过，下面是完整的最终内容。');
    openBody(body, null);
    writeText(body, output);
  }
  endLine(body);
  say('[正文结束]');
  body.open = false;
}

/** 等这一轮出结论。中途出错（网络断了、本地写文件失败）时，已经打出去的半截先收个尾，不能让「[错误]」接在正文后面。 */
async function waitFor(taskId, seconds = waitSeconds()) {
  const body = newBody();
  try {
    return await pollRound(taskId, body, seconds);
  } catch (e) {
    interruptBody(body, '连接中断，正文没有收完；接着等的时候会从头重新输出完整正文。');
    throw e;
  }
}

/**
 * 查进度直到这一轮有结论，或者本条命令的时间用完。
 *
 * <p>取材料、排队、分析、撰写这几段：换段时马上报，同一段里每 30 秒重报一次，内容没变也报——
 * 这就是心跳。第 1 轮从取材料进到生成时，补报一行「全周期材料已完成，开始制作」。
 */
async function pollRound(taskId, body, seconds) {
  const deadline = Date.now() + seconds * 1000;
  let lastKey = '';
  let lastTick = 0;
  // 上一条命令最后看到的还是「取材料」，这一条一进来就过了这段：「材料已完成」那一行要补上，
  // 不然建任务先返回的那 15 秒正好停在取材料时，这一行永远报不出来。本地状态是上一次查进度时存的
  const prev = readJson(taskFile(taskId));
  let sawFetching = !!(prev && prev.lastStatus === 'PREPARING');
  let v = null;
  for (;;) {
    if (deadline - Date.now() < 5000) break;
    // 不是 --stream 就不要半截正文：不带 textFrom，服务端就不给
    v = await getTask(taskId, deadline, streamMode ? body.received.length : undefined);
    saveTaskState(v);
    if (v.nextAction !== 'WAIT') {
      return finishStep(v, body);
    }
    const r = v.round || {};
    // 退回排队（自动重试）或换了一次生成：之前打出去的半截作废，进度从头报。
    // 读到 SUCCESS / FAILED 不算：任务和轮次是分两次读的，可能正好撞上这一轮刚结束，下一次查进度就会收尾
    if (body.open && (r.status === 'PENDING' || (r.streamId && r.streamId !== body.streamId))) {
      interruptBody(body, '生成中断，已自动重新开始，正文会从头重新输出。');
      lastKey = '';
    }
    if (streamMode && r.status === 'RUNNING' && r.streamId && typeof r.text === 'string') {
      if (!body.open) {
        if (lastKey !== 'write') {
          const w = stageOf(v);
          progress(w.percent, w.text);
        }
        openBody(body, r.streamId);
      }
      // 服务端从 textFrom 起给；请求时带的是上一次生成的字数（刚换了一次生成）就先不打，下一次从 0 取
      const from = typeof r.textFrom === 'number' ? r.textFrom : 0;
      if (from <= body.received.length) {
        writeText(body, r.text.slice(body.received.length - from));
      }
    } else if (!body.open) {
      // 正文开始往外打以后不再报进度：正文本身就是心跳，进度行插进去会把正文打断
      const stage = stageOf(v);
      if (stage.key === 'fetch') {
        sawFetching = true;
      } else if (sawFetching) {
        progress(20, '全周期材料已完成，开始制作');
        sawFetching = false;
      }
      const now = Date.now();
      if (stage.key !== lastKey || now - lastTick >= TICK_MS) {
        progress(stage.percent, stage.text);
        lastKey = stage.key;
        lastTick = now;
      }
    }
    const pause = Math.max(3, v.pollAfterSeconds || 10) * 1000;
    if (Date.now() + pause > deadline) break;
    await sleep(pause);
  }
  interruptBody(body, '正文还没写完，接着等的时候会从头重新输出完整正文。');
  say('');
  say('还在生成中（服务端在继续跑，不会因为这条命令结束而中断）。');
  say('请再运行一次：node oa.js wait ' + taskId);
  if (v) summary(v);
  return EXIT_RUNNING;
}

const TRUNCATED = '⚠ 这一轮的输出达到了长度上限，末尾可能不完整。';

/**
 * 这一轮有结论了，三种收尾：
 * <ul>
 *   <li>生成了新的 OA 文件：报 100% 和实际耗时，把正文存成文件、报路径，然后给出服务端的提示
 *       （--stream 时先把正文补齐：流式没打完的部分，或者整篇）；</li>
 *   <li>只回了一两句话（无可采纳观点、无效输入、拒答）：<b>不报 100%、不报耗时</b>——没有新文件，
 *       报「完成」会让用户以为文件改好了。直接打「[回复] 第 N 轮回复：……」和服务端的提示；</li>
 *   <li>没成功（取材料失败、这一轮生成失败、过期）：打「[错误] 服务端的提示原话」。流式打过半截的，先说明那半截作废。</li>
 * </ul>
 */
async function finishStep(v, body = newBody()) {
  const extra = {};
  // 过期的任务正文已经取不到了（服务端回 410），不报完成、不去下载，直接给提示
  const succeeded = v.round && v.round.status === 'SUCCESS' && !v.expired;
  if (succeeded) {
    const roundNo = v.round.roundNo;
    const r = await downloadRound(v.taskId, roundNo);
    if (r.outputKind === 'DOCUMENT') {
      if (streamMode) {
        finishBody(body, r.output);
      }
      progress(100, roundNo === 1 ? '制作完成' : '第 ' + roundNo + ' 轮完成');
      if (v.elapsedSeconds != null) {
        say('[耗时] 本轮实际耗时 ' + duration(v.elapsedSeconds));
        extra.elapsedSeconds = v.elapsedSeconds;
      }
      Object.assign(extra, saveDocument(v.patentNo, v.taskId, roundNo, r));
    } else if (r.reply !== undefined) {
      interruptBody(body, '这一轮最后没有生成新的 OA 文件，上面的内容作废。');
      sayReply(roundNo, r.reply);
      Object.assign(extra, { outputKind: r.outputKind, reply: r.reply });
    }
  } else {
    interruptBody(body, '这一轮没有生成完，上面的内容不完整，请不要使用。');
  }
  say('');
  const isError = !succeeded && v.nextAction !== 'DONE' && v.nextAction !== 'REVISE';
  if (v.hint) say((isError ? '[错误] ' : '') + v.hint);
  if (v.nextAction === 'REVISE') {
    say('（修订请用：node oa.js revise ' + v.taskId + ' --opinion-file <观点文件>）');
  } else if (v.nextAction === 'RETRY_ROUND') {
    say('（重试请用：node oa.js retry ' + v.taskId + '）');
  }
  summary(v, extra);
  return EXIT_OK;
}

function sayReply(roundNo, reply) {
  say('[回复] 第 ' + roundNo + ' 轮回复：' + clean(reply));
}

/**
 * 取某一轮的结果，只取不打印（怎么打由调用方定）。正式文件给 output；
 * 不是 OA 文件的回复（无可采纳观点、无效输入或其它一两句话）给 reply。
 */
async function downloadRound(taskId, roundNo) {
  if (!(Number.isInteger(roundNo) && roundNo >= 1)) {
    throw new Error('服务返回的轮次不对');
  }
  const r = await api('GET', '/tasks/' + taskId + '/rounds/' + roundNo);
  if (r.status !== 'SUCCESS' || typeof r.output !== 'string') {
    return { roundStatus: r.status };
  }
  if (r.outputKind && r.outputKind !== 'DOCUMENT') {
    return { outputKind: r.outputKind, reply: r.output.trim() };
  }
  return { outputKind: 'DOCUMENT', output: r.output, truncated: !!r.truncated };
}

/**
 * 正文存成文件并报路径。每次都按服务端的内容写：成功轮次的正文不会再变，重写是安全的，
 * 而「已存在就跳过」会把本地的旧文件当成新结果。
 */
function saveDocument(patentNo, taskId, roundNo, r) {
  const file = outputPath(patentNo, taskId, roundNo);
  fs.writeFileSync(file, r.output, 'utf8');
  say('第 ' + roundNo + ' 轮 OA 文件已保存：' + file + '（' + r.output.length + ' 字）');
  if (r.truncated) {
    say(TRUNCATED);
  }
  return { outputKind: 'DOCUMENT', roundNo, file, chars: r.output.length, truncated: r.truncated };
}

// ------------------------------------------------------------------ 命令

async function cmdCreate(args) {
  const raw = args[0];
  const standard = normalizePatentNo(raw);
  if (!standard) {
    say('[错误] 专利申请号格式不正确：' + (raw || '（空）'));
    say('支持的写法：2023106384150、CN202310638415.0、ZL202311841441.X（第 5 位必须是 1 或 8）');
    return EXIT_INPUT;
  }
  ensureStateDir();
  if (args.indexOf('--new') < 0) {
    const open = findOpenLocalTask(standard);
    if (open) {
      say('这件专利（' + standard + '）已经有一个没结束的任务：' + open.taskId);
      say('接着看它请运行：node oa.js wait ' + open.taskId);
      say('确实要重新制作一份（会从头重新生成），在 create 命令后加 --new。');
      say('@@OA ' + JSON.stringify({ taskId: open.taskId, patentNo: standard, nextAction: 'EXISTING' }));
      return EXIT_EXISTING;
    }
  }
  // 先落盘再提交：提交到一半断了，下次重跑同一条 create 带的还是这个键，服务端返回同一个任务
  const pf = pendingFile(standard);
  let pending = readJson(pf);
  if (!pending || !pending.requestKey || Date.now() - Date.parse(pending.createdAt) > PENDING_TTL_MS) {
    pending = { requestKey: 'rk_' + crypto.randomBytes(16).toString('hex'), createdAt: new Date().toISOString() };
    writeJson(pf, pending);
  }
  const v = checkView(await api('POST', '/tasks', { patentNo: raw.trim(), requestKey: pending.requestKey }));
  saveTaskState(v, { rawPatentNo: raw.trim(), createdAt: new Date().toISOString() });
  try {
    fs.unlinkSync(pf);
  } catch (e) {
    // 已经删过
  }
  progress(0, '启动任务');
  say('任务号：' + v.taskId + '（申请号 ' + v.patentNo + '）');
  say('（断线或中断后用 node oa.js wait ' + v.taskId + ' 接着看，不要重新创建）');
  return waitFor(v.taskId, firstWaitSeconds());
}

async function cmdWait(args) {
  return waitFor(requireTaskId(args[0]));
}

async function cmdStatus(args) {
  const v = await getTask(requireTaskId(args[0]));
  saveTaskState(v);
  say(v.statusText || v.status);
  if (v.hint) say(v.hint);
  summary(v);
  return v.nextAction === 'WAIT' ? EXIT_RUNNING : EXIT_OK;
}

/**
 * 提交修改观点。<b>以服务端为准判断这段观点是不是已经提交过</b>：当前这一轮的观点和文件里的一字不差，
 * 就是上次提交后断线了（或者命令被重跑了），接着等，绝不再提交一次。不靠本地记录——本地文件可能没写进去、被别的命令覆盖。
 */
async function cmdRevise(args) {
  const taskId = requireTaskId(args[0]);
  const i = args.indexOf('--opinion-file');
  if (i < 0 || !args[i + 1]) {
    say('[错误] 请把用户的修改观点写进一个 UTF-8 文本文件，用 --opinion-file 传进来（不要直接放在命令行里，中文会乱码）。');
    return EXIT_INPUT;
  }
  const text = readTextFile(args[i + 1]);
  if (text === null) {
    say('[错误] 观点文件不是 UTF-8 编码（读出来是乱码），这次没有提交。');
    say('请用你自己的写文件工具按 UTF-8 重新写这个文件；不要用 PowerShell 的 Set-Content、Out-File 或 > 重定向。');
    return EXIT_INPUT;
  }
  const opinion = text.trim();
  if (!opinion) {
    say('[错误] 修改观点是空的，这次没有提交。');
    return EXIT_INPUT;
  }
  const v = await getTask(taskId);
  saveTaskState(v);
  if (v.currentRound >= 2) {
    const cur = await api('GET', '/tasks/' + taskId + '/rounds/' + v.currentRound);
    if ((cur.opinion || '').trim() === opinion) {
      if (v.nextAction === 'WAIT') {
        say('这段修改观点已经作为第 ' + v.currentRound + ' 轮提交过，正在生成，接着等结果（不会重复提交）。');
        return waitFor(taskId);
      }
      say('这段修改观点和第 ' + v.currentRound + ' 轮提交的一字不差，第 ' + v.currentRound + ' 轮已经有结论，下面是它的结果（没有再提交）。');
      say('如果要按新的观点继续修订，请把新观点写进新文件再 revise。');
      return finishStep(v);
    }
  }
  if (v.nextAction !== 'REVISE') {
    if (v.nextAction === 'WAIT') {
      say('第 ' + v.currentRound + ' 轮还没完成，这次的修改观点【没有提交】。');
      say('请先运行 node oa.js wait ' + taskId + ' 等这一轮出结果、展示给用户，再问用户是否还按这段观点修订。');
      summary(v, { opinionSubmitted: false });
      return EXIT_EXISTING;
    }
    if (v.nextAction === 'DONE') {
      // 轮数用完后再提观点：明确说「已结束、要新建」，不能只重复一遍结束语
      say('本任务的 ' + v.maxRounds + ' 轮已经全部用完，不能再修订，这次的修改观点没有提交。需要按新观点重新制作，请新建任务：');
      say('node oa.js create ' + v.patentNo + ' --new（会从头重新生成）');
    } else {
      say(v.hint || v.statusText || '这个任务现在不能提交修改观点。');
      say('这次的修改观点没有提交。');
    }
    summary(v, { opinionSubmitted: false });
    return EXIT_ERROR;
  }
  const roundNo = v.currentRound + 1;
  const after = checkView(await api('POST', '/tasks/' + taskId + '/rounds', { roundNo, opinion }));
  saveTaskState(after);
  progress(0, '已提交第 ' + roundNo + ' 轮修改观点');
  return waitFor(taskId, firstWaitSeconds());
}

async function cmdRetry(args) {
  const taskId = requireTaskId(args[0]);
  const v = await getTask(taskId);
  if (v.nextAction !== 'RETRY_ROUND') {
    say(v.hint || v.statusText || '这个任务现在不需要重试。');
    summary(v);
    return v.nextAction === 'WAIT' ? EXIT_RUNNING : EXIT_OK;
  }
  const roundNo = v.currentRound;
  // 原样再提交这一轮：观点必须和第一次一模一样，从服务端取回，不依赖本地记录
  const r = await api('GET', '/tasks/' + taskId + '/rounds/' + roundNo);
  await api('POST', '/tasks/' + taskId + '/rounds', { roundNo, opinion: r.opinion || '' });
  progress(0, '重新开始第 ' + roundNo + ' 轮');
  return waitFor(taskId, firstWaitSeconds());
}

/**
 * 重新下载某一轮的 OA 文件存到本地（比如文件被删了、要取之前某一轮），只报路径、不打印正文。
 * 不给轮次就存最新的一版。
 */
async function cmdSave(args) {
  const taskId = requireTaskId(args[0]);
  const v = await getTask(taskId);
  const roundNo = args[1] === undefined ? v.latestDocumentRound : parseInt(args[1], 10);
  if (!(roundNo >= 1)) {
    say(args[1] === undefined ? '这个任务还没有可以保存的 OA 文件。' : '轮次不对，比如：node oa.js save ' + taskId + ' 1');
    summary(v);
    return EXIT_INPUT;
  }
  const r = await downloadRound(taskId, roundNo);
  if (r.outputKind !== 'DOCUMENT') {
    say(r.reply !== undefined
      ? '第 ' + roundNo + ' 轮没有生成 OA 文件（这一轮的回复是：' + clean(r.reply) + '），没有可以保存的内容。'
      : '第 ' + roundNo + ' 轮还没有可以保存的 OA 文件。');
    summary(v, { roundNo });
    return EXIT_INPUT;
  }
  summary(v, saveDocument(v.patentNo, taskId, roundNo, r));
  return EXIT_OK;
}

function requireTaskId(id) {
  if (!TASK_ID_RE.test(id || '')) {
    const e = new Error('任务号格式不对：' + (id || '（空）') + '。任务号形如 oa_ 加 32 位字母数字。');
    e.inputError = true;
    throw e;
  }
  return id;
}

// ------------------------------------------------------------------ 入口

const COMMANDS = { create: cmdCreate, wait: cmdWait, status: cmdStatus, revise: cmdRevise, retry: cmdRetry, save: cmdSave };

async function main() {
  const argv = process.argv.slice(2);
  streamMode = argv.indexOf('--stream') >= 0;
  const [cmd, ...args] = argv.filter((a) => a !== '--stream');
  if (cmd === 'normalize') {
    // 只做本地校验，给测试和排查用
    const s = normalizePatentNo(args[0]);
    say(s || 'INVALID');
    return s ? EXIT_OK : EXIT_INPUT;
  }
  const fn = COMMANDS[cmd];
  if (!fn) {
    say('用法：node oa.js create|wait|revise|retry|status|save ...（见文件开头的说明）');
    return EXIT_INPUT;
  }
  try {
    checkBase();
    return await fn(args);
  } catch (e) {
    if (e.inputError) {
      say('[错误] ' + e.message);
      return EXIT_INPUT;
    }
    if (e && LOCAL_ERRORS.indexOf(e.code) >= 0) {
      say('[错误] 本地文件读写失败：' + e.message);
      say('请检查文件路径是否正确、目录是否可写；状态目录可以用环境变量 OA_STATE_DIR 换到可写的位置。');
      return EXIT_INPUT;
    }
    if (e instanceof ApiError) {
      say('[错误] ' + e.message);
      say('@@OA ' + JSON.stringify({ error: e.errorCode, status: e.status }));
      return e.errorCode === 'PATENT_NO_INVALID' || e.errorCode === 'PARAM_ERROR' ? EXIT_INPUT : EXIT_ERROR;
    }
    say('[错误] 网络或服务暂时不可用：' + (e.message || e.code || String(e)));
    say('稍后重新运行同一条命令即可（已提交的任务不会丢，也不会重复生成）。');
    return EXIT_ERROR;
  }
}

if (require.main === module) {
  // 兜底：万一有哪条路径没走到 process.exit（比如 Promise 悬空导致事件循环自己空了），不能以 0 退出冒充「有结果了」
  process.exitCode = EXIT_ERROR;
  main().then((code) => {
    // 等 stdout 写完再退：macOS 上管道是异步写的，直接 exit 可能截掉最后一段（收尾标记、提示、@@OA）
    process.exitCode = code;
    process.stdout.write('', () => process.exit(code));
  });
}

module.exports = { normalizePatentNo, readTextFile, stageOf, duration };
