param(
    [Parameter(Mandatory=$true)][ValidateSet('inspect','apply')][string]$Action,
    [Parameter(Mandatory=$true)][string]$InputPath,
    [Parameter(Mandatory=$true)][string]$OutputPath,
    [string]$PlanPath
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$wordNs = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
$utf8 = New-Object Text.UTF8Encoding($false)

function Get-SourceHash([string]$FilePath) {
    $stream=[IO.File]::OpenRead($FilePath)
    $algorithm=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}

function Read-WordXml([string]$FilePath) {
    $zip = [IO.Compression.ZipFile]::OpenRead($FilePath)
    try {
        $entry = $zip.GetEntry('word/document.xml')
        if (-not $entry) { throw 'The DOCX has no word/document.xml.' }
        $stream = $entry.Open()
        try {
            $settings = New-Object Xml.XmlReaderSettings
            $settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit
            $settings.XmlResolver = $null
            $reader = [Xml.XmlReader]::Create($stream,$settings)
            try {
                $xml = New-Object Xml.XmlDocument
                $xml.PreserveWhitespace = $true
                $xml.XmlResolver = $null
                $xml.Load($reader)
                return ,$xml
            } finally { $reader.Dispose() }
        } finally { $stream.Dispose() }
    } finally { $zip.Dispose() }
}
function Get-ParagraphText($Paragraph,$Namespaces) {
    return (($Paragraph.SelectNodes('.//w:t',$Namespaces) | ForEach-Object { $_.InnerText }) -join '')
}
function New-TextRun($Xml,$StyleRun,[string]$Text,[bool]$Highlight) {
    $run = $Xml.CreateElement('w','r',$wordNs)
    if ($StyleRun) {
        $style = $StyleRun.SelectSingleNode('./w:rPr',$script:ns)
        if ($style) { [void]$run.AppendChild($style.CloneNode($true)) }
    }
    if ($Highlight) {
        $properties = $run.SelectSingleNode('./w:rPr',$script:ns)
        if (-not $properties) { $properties=$Xml.CreateElement('w','rPr',$wordNs); [void]$run.PrependChild($properties) }
        @($properties.SelectNodes('./w:highlight',$script:ns)) | ForEach-Object { [void]$properties.RemoveChild($_) }
        $mark=$Xml.CreateElement('w','highlight',$wordNs)
        [void]$mark.SetAttribute('val',$wordNs,'yellow')
        [void]$properties.AppendChild($mark)
    }
    $node=$Xml.CreateElement('w','t',$wordNs)
    $space=$Xml.CreateAttribute('xml','space','http://www.w3.org/XML/1998/namespace')
    $space.Value='preserve'
    [void]$node.Attributes.Append($space)
    $node.InnerText=$Text
    [void]$run.AppendChild($node)
    return ,$run
}
function Replace-Text($Xml,$Paragraph,[string]$OldText,[string]$NewText) {
    foreach($child in $Paragraph.ChildNodes) {
        if($child.NodeType -eq [Xml.XmlNodeType]::Element -and ($child.NamespaceURI -ne $wordNs -or $child.LocalName -notin @('pPr','r'))) { throw 'Complex paragraph: use a native Word revision tool instead.' }
    }
    $runs=@($Paragraph.SelectNodes('./w:r',$script:ns))
    foreach($run in $runs) {
        foreach($child in $run.ChildNodes) {
            if($child.NodeType -eq [Xml.XmlNodeType]::Element -and ($child.NamespaceURI -ne $wordNs -or $child.LocalName -notin @('rPr','t'))) { throw 'Complex run: fields, tabs, drawings and breaks require a native Word tool.' }
        }
    }
    $text=Get-ParagraphText $Paragraph $script:ns
    $start=$text.IndexOf($OldText,[StringComparison]::Ordinal)
    if($start -lt 0 -or $text.IndexOf($OldText,$start+$OldText.Length,[StringComparison]::Ordinal) -ge 0) { throw 'oldText must occur exactly once in the specified paragraph.' }
    $end=$start+$OldText.Length
    $position=0; $inserted=$false
    $replacement=New-Object 'Collections.Generic.List[Xml.XmlNode]'
    foreach($run in $runs) {
        $part=($run.SelectNodes('./w:t',$script:ns) | ForEach-Object { $_.InnerText }) -join ''
        $next=$position+$part.Length
        if($next -le $start -or $position -ge $end) {
            $replacement.Add($run.CloneNode($true))
        } else {
            if($position -lt $start) { $replacement.Add((New-TextRun $Xml $run $part.Substring(0,$start-$position) $false)) }
            if(-not $inserted) { $replacement.Add((New-TextRun $Xml $run $NewText $true)); $inserted=$true }
            if($next -gt $end) { $replacement.Add((New-TextRun $Xml $run $part.Substring($end-$position) $false)) }
        }
        $position=$next
    }
    if(-not $inserted) { throw 'Could not anchor replacement.' }
    foreach($run in $runs) { [void]$Paragraph.RemoveChild($run) }
    foreach($run in $replacement) { [void]$Paragraph.AppendChild($run) }
}

$inputFile=(Resolve-Path -LiteralPath $InputPath).Path
$outputFile=[IO.Path]::GetFullPath($OutputPath)
if([string]::Equals($inputFile,$outputFile,[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $outputFile)) { throw 'Choose a new output filename; overwriting is disabled.' }
if(-not (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($outputFile)))) { throw 'Output parent directory does not exist.' }
$sourceHash=Get-SourceHash $inputFile
$doc=Read-WordXml $inputFile
$script:ns=New-Object Xml.XmlNamespaceManager($doc.NameTable)
$script:ns.AddNamespace('w',$wordNs)
$paragraphs=@($doc.SelectNodes('/w:document/w:body//w:p',$script:ns))
if($Action -eq 'inspect') {
    $items=@(for($index=0;$index -lt $paragraphs.Count;$index++) {
        [pscustomobject]@{id=('p{0:D4}' -f ($index+1));text=(Get-ParagraphText $paragraphs[$index] $script:ns)}
    })
    [IO.File]::WriteAllText($outputFile,([pscustomobject]@{sourceSha256=$sourceHash;paragraphs=$items} | ConvertTo-Json -Depth 8),$utf8)
    Write-Output ('Inspected {0} paragraphs.' -f $items.Count)
    exit 0
}
if(-not $PlanPath) { throw 'PlanPath is required for apply.' }
$plan=Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
if($plan.sourceSha256 -ne $sourceHash) { throw 'Source changed; inspect the original again before applying.' }
$operations=@($plan.operations)
if($operations.Count -eq 0) { throw 'The plan has no operations.' }
$insertAnchors=@{}
foreach($operation in $operations) {
    if($operation.decision -ne 'confirmed' -or [string]::IsNullOrWhiteSpace([string]$operation.evidence)) { throw 'Every operation needs a confirmed decision and meeting evidence.' }
    if([string]$operation.paragraphId -notmatch '^p([0-9]{4,})$') { throw 'Invalid paragraphId.' }
    $paragraphIndex=[int]$Matches[1]-1
    if($paragraphIndex -lt 0 -or $paragraphIndex -ge $paragraphs.Count) { throw 'Paragraph is outside the source document.' }
    $paragraph=$paragraphs[$paragraphIndex]
    if([string]::IsNullOrEmpty([string]$operation.newText)) { throw 'newText cannot be empty; pure deletion needs a tracked-change tool.' }
    if($operation.type -eq 'replace-text') {
        if([string]::IsNullOrEmpty([string]$operation.oldText)) { throw 'oldText cannot be empty.' }
        Replace-Text $doc $paragraph ([string]$operation.oldText) ([string]$operation.newText)
    } elseif($operation.type -eq 'insert-after') {
        $newParagraph=$doc.CreateElement('w','p',$wordNs)
        $pStyle=$paragraph.SelectSingleNode('./w:pPr',$script:ns)
        if($pStyle) {
            $newStyle=$pStyle.CloneNode($true)
            @($newStyle.SelectNodes('./w:sectPr',$script:ns)) | ForEach-Object { [void]$newStyle.RemoveChild($_) }
            [void]$newParagraph.AppendChild($newStyle)
        }
        [void]$newParagraph.AppendChild((New-TextRun $doc ($paragraph.SelectSingleNode('./w:r',$script:ns)) ([string]$operation.newText) $true))
        $anchor=$paragraph
        if($insertAnchors.ContainsKey($operation.paragraphId)) { $anchor=$insertAnchors[$operation.paragraphId] }
        [void]$anchor.ParentNode.InsertAfter($newParagraph,$anchor)
        $insertAnchors[$operation.paragraphId]=$newParagraph
    } else { throw 'Unsupported operation type.' }
}
if((Get-SourceHash $inputFile) -ne $sourceHash) { throw 'Source changed while preparing the revision.' }
$temporaryFile=$outputFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
try {
    [IO.File]::Copy($inputFile,$temporaryFile,$false)
    $zip=[IO.Compression.ZipFile]::Open($temporaryFile,[IO.Compression.ZipArchiveMode]::Update)
    try {
        $zip.GetEntry('word/document.xml').Delete()
        $entry=$zip.CreateEntry('word/document.xml',[IO.Compression.CompressionLevel]::Optimal)
        $stream=$entry.Open()
        try { $doc.Save($stream) } finally { $stream.Dispose() }
    } finally { $zip.Dispose() }
    $verified=Read-WordXml $temporaryFile
    if($verified.DocumentElement.LocalName -ne 'document') { throw 'Revised DOCX XML failed verification.' }
    [IO.File]::Move($temporaryFile,$outputFile)
    Write-Output ('Applied {0} confirmed changes to a new DOCX.' -f $operations.Count)
} finally {
    if(Test-Path -LiteralPath $temporaryFile) { Remove-Item -LiteralPath $temporaryFile -Force }
}
