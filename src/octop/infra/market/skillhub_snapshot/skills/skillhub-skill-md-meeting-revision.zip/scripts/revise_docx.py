#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Cross-platform DOCX revision tool (Python standard library only).

Same contract as scripts/revise-docx.ps1, for macOS / Linux / any host without
Windows PowerShell. No third-party packages, no Office installation required.

Usage:
    python revise_docx.py inspect --input "<原方案.docx>" --output "<段落索引.json>"
    python revise_docx.py apply   --input "<原方案.docx>" --plan "<修改计划.json>" --output "<副本.docx>"

Plan format (UTF-8 JSON), identical to the PowerShell version:
    {
      "sourceSha256": "<index 中的 sha256>",
      "operations": [
        {"type": "replace-text", "paragraphId": "p0003",
         "oldText": "原文中连续且唯一的文本", "newText": "新文本",
         "decision": "confirmed", "evidence": "发言人、时间、原话"},
        {"type": "insert-after", "paragraphId": "p0003",
         "newText": "新增段落", "decision": "confirmed", "evidence": "会议依据"}
      ]
    }

Guarantees: never overwrites the original or an existing output; refuses complex
paragraphs (fields / drawings / breaks) instead of flattening them; new text is
highlighted yellow; only word/document.xml is modified.
"""

import argparse
import copy
import hashlib
import json
import os
import re
import sys
import uuid
import zipfile
import xml.etree.ElementTree as ET

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_NS = "http://www.w3.org/XML/1998/namespace"
W = "{%s}" % W_NS
DOCUMENT_PART = "word/document.xml"
ALLOWED_PARAGRAPH_CHILDREN = {W + "pPr", W + "r"}
ALLOWED_RUN_CHILDREN = {W + "rPr", W + "t"}


class RevisionError(Exception):
    pass


# --------------------------------------------------------------------------- #
# basics
# --------------------------------------------------------------------------- #

def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def register_namespaces(raw):
    """Keep original namespace prefixes so mc:Ignorable etc. stay valid."""
    for match in re.finditer(rb'xmlns:([^\s=/>]+)="([^"]+)"', raw):
        prefix = match.group(1).decode("utf-8", "ignore")
        uri = match.group(2).decode("utf-8", "ignore")
        if prefix in ("xml", "xmlns"):
            continue
        try:
            ET.register_namespace(prefix, uri)
        except ValueError:
            pass
    default = re.search(rb'\sxmlns="([^"]+)"', raw)
    if default:
        try:
            ET.register_namespace("", default.group(1).decode("utf-8", "ignore"))
        except ValueError:
            pass


def read_document(path):
    with zipfile.ZipFile(path) as archive:
        try:
            raw = archive.read(DOCUMENT_PART)
        except KeyError:
            raise RevisionError("The DOCX has no word/document.xml.")
    register_namespaces(raw)
    parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    parser.feed(raw)
    root = parser.close()
    if root.tag != W + "document":
        raise RevisionError("Unexpected root element in word/document.xml.")
    return root


def serialize_document(root):
    body = ET.tostring(root, encoding="unicode")
    if body.startswith("<?xml"):
        body = body[body.index("?>") + 2:]
    header = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'
    return (header + body).encode("utf-8")


def element_children(node):
    return [child for child in node if isinstance(child.tag, str)]


def paragraph_text(paragraph):
    return "".join(node.text or "" for node in paragraph.iter(W + "t"))


def local_name(tag):
    return tag.rsplit("}", 1)[-1]


def make_run(style_run, text, highlight):
    run = ET.Element(W + "r")
    if style_run is not None:
        properties = style_run.find(W + "rPr")
        if properties is not None:
            run.append(copy.deepcopy(properties))
    if highlight:
        properties = run.find(W + "rPr")
        if properties is None:
            properties = ET.Element(W + "rPr")
            run.insert(0, properties)
        for existing in properties.findall(W + "highlight"):
            properties.remove(existing)
        mark = ET.SubElement(properties, W + "highlight")
        mark.set(W + "val", "yellow")
    node = ET.SubElement(run, W + "t")
    node.set("{%s}space" % XML_NS, "preserve")
    node.text = text
    return run


# --------------------------------------------------------------------------- #
# operations
# --------------------------------------------------------------------------- #

def replace_text(paragraph, old_text, new_text):
    for child in element_children(paragraph):
        if child.tag not in ALLOWED_PARAGRAPH_CHILDREN:
            raise RevisionError(
                "Complex paragraph: use a native Word revision tool instead.")
    runs = paragraph.findall(W + "r")
    for run in runs:
        for child in element_children(run):
            if child.tag not in ALLOWED_RUN_CHILDREN:
                raise RevisionError(
                    "Complex run: fields, tabs, drawings and breaks require a "
                    "native Word tool.")

    text = paragraph_text(paragraph)
    start = text.find(old_text)
    if start < 0 or text.find(old_text, start + len(old_text)) >= 0:
        raise RevisionError(
            "oldText must occur exactly once in the specified paragraph.")

    end = start + len(old_text)
    position = 0
    inserted = False
    replacement = []
    for run in runs:
        part = "".join(node.text or "" for node in run.findall(W + "t"))
        nxt = position + len(part)
        if nxt <= start or position >= end:
            replacement.append(copy.deepcopy(run))
        else:
            if position < start:
                replacement.append(make_run(run, part[:start - position], False))
            if not inserted:
                replacement.append(make_run(run, new_text, True))
                inserted = True
            if nxt > end:
                replacement.append(make_run(run, part[end - position:], False))
        position = nxt

    if not inserted:
        raise RevisionError("Could not anchor replacement.")

    for run in runs:
        paragraph.remove(run)
    for run in replacement:
        paragraph.append(run)


def insert_after(parents, anchor, new_text, style_source):
    paragraph = ET.Element(W + "p")
    style = anchor.find(W + "pPr")
    if style is not None:
        cloned = copy.deepcopy(style)
        for sect in cloned.findall(W + "sectPr"):
            cloned.remove(sect)
        paragraph.append(cloned)
    paragraph.append(make_run(style_source, new_text, True))
    parent = parents.get(anchor)
    if parent is None:
        raise RevisionError("Cannot locate the anchor paragraph's parent.")
    parent.insert(list(parent).index(anchor) + 1, paragraph)
    parents[paragraph] = parent
    return paragraph


def build_parent_map(root):
    return {child: parent for parent in root.iter() for child in parent}


# --------------------------------------------------------------------------- #
# actions
# --------------------------------------------------------------------------- #

def action_inspect(input_path, output_path):
    ensure_new_output(input_path, output_path)
    root = read_document(input_path)
    paragraphs = [
        {"id": "p%04d" % (index + 1), "text": paragraph_text(node)}
        for index, node in enumerate(root.iter(W + "p"))
    ]
    payload = {"sourceSha256": sha256_of(input_path), "paragraphs": paragraphs}
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    print("Inspected %d paragraphs." % len(paragraphs))
    return 0


def ensure_new_output(input_path, output_path):
    source = os.path.realpath(input_path)
    target = os.path.realpath(output_path)
    if source.lower() == target.lower():
        raise RevisionError("Choose a new output filename; overwriting is disabled.")
    if os.path.exists(output_path):
        raise RevisionError("Choose a new output filename; overwriting is disabled.")
    parent = os.path.dirname(target)
    if parent and not os.path.isdir(parent):
        raise RevisionError("Output parent directory does not exist.")


def action_apply(input_path, plan_path, output_path):
    ensure_new_output(input_path, output_path)
    source_hash = sha256_of(input_path)
    with open(plan_path, "r", encoding="utf-8") as handle:
        plan = json.load(handle)
    if plan.get("sourceSha256") != source_hash:
        raise RevisionError(
            "Source changed; inspect the original again before applying.")
    operations = plan.get("operations") or []
    if not operations:
        raise RevisionError("The plan has no operations.")

    root = read_document(input_path)
    paragraphs = list(root.iter(W + "p"))
    parents = build_parent_map(root)
    ordered = []
    for operation in operations:
        decision = operation.get("decision")
        evidence = (operation.get("evidence") or "").strip()
        if decision != "confirmed" or not evidence:
            raise RevisionError(
                "Every operation needs a confirmed decision and meeting evidence.")
        paragraph_id = str(operation.get("paragraphId") or "")
        if not re.match(r"^p\d{4,}$", paragraph_id):
            raise RevisionError("Invalid paragraphId: %s" % paragraph_id)
        index = int(paragraph_id[1:]) - 1
        if index < 0 or index >= len(paragraphs):
            raise RevisionError("Paragraph is outside the source document.")
        new_text = operation.get("newText")
        if not new_text:
            raise RevisionError(
                "newText cannot be empty; pure deletion needs a tracked-change tool.")
        kind = operation.get("type")
        if kind == "replace-text":
            old_text = operation.get("oldText")
            if not old_text:
                raise RevisionError("oldText cannot be empty.")
            replace_text(paragraphs[index], old_text, new_text)
        elif kind == "insert-after":
            anchor = None
            for candidate_id, candidate in ordered:
                if candidate_id == paragraph_id:
                    anchor = candidate
            if anchor is None:
                anchor = paragraphs[index]
            style_source = paragraphs[index].find(W + "r")
            new_paragraph = insert_after(parents, anchor, new_text, style_source)
            ordered.append((paragraph_id, new_paragraph))
        else:
            raise RevisionError("Unsupported operation type: %r" % kind)

    if sha256_of(input_path) != source_hash:
        raise RevisionError("Source changed while preparing the revision.")

    xml_bytes = serialize_document(root)
    temporary = output_path + "." + uuid.uuid4().hex + ".tmp"
    try:
        with zipfile.ZipFile(input_path, "r") as zin, \
                zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                data = xml_bytes if item.filename == DOCUMENT_PART else zin.read(item.filename)
                zout.writestr(item, data)
        verify(temporary)
        os.replace(temporary, output_path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)
    print("Applied %d confirmed changes to a new DOCX." % len(operations))
    return 0


def verify(path):
    root = read_document(path)
    if root.tag != W + "document":
        raise RevisionError("Revised DOCX XML failed verification.")


# --------------------------------------------------------------------------- #

def main(argv=None):
    parser = argparse.ArgumentParser(description="DOCX revision tool (cross-platform).")
    parser.add_argument("action", choices=["inspect", "apply"])
    parser.add_argument("--input", required=True, help="original .docx")
    parser.add_argument("--output", required=True, help="new .docx or index .json")
    parser.add_argument("--plan", help="revision plan JSON (apply only)")
    args = parser.parse_args(argv)
    try:
        if args.action == "inspect":
            return action_inspect(args.input, args.output)
        if not args.plan:
            raise RevisionError("--plan is required for apply.")
        return action_apply(args.input, args.plan, args.output)
    except RevisionError as error:
        print("Error: %s" % error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
