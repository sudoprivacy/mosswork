# 腾讯会议录屏自动获取（改稿前置）

用户说「把最新录屏的变动点更新到文档」「按会议录制改稿」，或只给会议主题／会议号、没给纪要时，直接去腾讯会议取录屏内容，不要回头索要材料。

## 0 前置能力

- 依赖随 WorkBuddy 提供的腾讯会议 CLI `tmeet`（连接器 tmeet）。先加载 `tmeet-skill`，按其要求**静默**执行一次 `agent_init`（失败即忽略），再执行任何 tmeet 命令。
- `tmeet auth status` 看登录态。未登录时按 `tmeet-skill` 引导用户执行 `tmeet auth login`（阻塞命令，必须前台运行）。
- 安全：不输出 AccessToken／RefreshToken；面向用户一律用会议号 `meeting_code`，**不暴露 `meeting_id`**。
- 录制权限申请、取消录制等写操作按 `tmeet-skill` 的二次确认要求执行，不得自问自答代确认。

## 1 定位「最新录屏」

按用户给的线索分层，不要一上来就问用户要文件。

| 用户线索 | 入口 | 说明 |
|---|---|---|
| 只说「最新录屏」、没给会议 | `tmeet record list --start <近14天> --end <now> --page-size 30` | 返回自己名下有权限的云录制，按 `media_start_time` 倒序，取第一条即最新 |
| 给了会议主题／会议号 | `tmeet meeting list-ended --start … --end …` 找 `meeting_code`，再 `tmeet meeting get --meeting-code <code>` | `records[]` 里有 `meeting_record_id`／`record_file_id`／`state`／`permission_status`／`duration` |
| 记得会上说过某句话 | `tmeet record search --query "<关键词>" --query-field transcript_content` | 跨会议按转写内容检索 |

- 时间窗默认取最近 14 天；用户说「最新」时直接取列表首条，**不要硬编码日期**。
- 用户自己名下的 `record list` 只含有权限的录制；指向别人主持的会议时用会议级入口，才能拿到 `permission_status`。

## 2 状态与权限门禁

| `state` / `permission_status` | 处理 |
|---|---|
| 录制中／转码中 | 不取内容、不申请权限，告知用户等「转码完成」 |
| 转码完成 + `can_view` | 直接取内容 |
| `can_apply` | `record permission-apply-prepare` 拉预览 → **展示给用户并等待明确确认** → `record permission-apply-commit` |
| `closed` / `deleted` | 告知不可申请，停止 |
| `password_required` | 走 `--pwd` 密码路径，不是权限申请 |

## 3 取内容（按权威度递降）

1. `tmeet record transcript-get --record-file-id <id>` —— **逐字稿**（pid／时间戳／发言人／逐词），作为改稿主依据；段落多时用 `--pid` + `--limit` 分批取。
2. `tmeet record transcript-paragraphs --record-file-id <id>` —— 段落索引（pid／start／end），用于定位与分页。
3. `tmeet record transcript-search --record-file-id <id> --text "<关键词>"` —— 单文件内定位某句原话。
4. `tmeet record smart-minutes --record-file-id <id>` —— 智能纪要（摘要＋待办）。用于交叉验证「结论／待办」，**不能替代原话**；引用时须标注是 AI 加工版。

## 4 关于下载原始视频

- `tmeet record address --meeting-record-id <id>` 返回的是**播放地址**（`view_address`，形如 `https://meeting.tencent.com/crw/xxxx`），腾讯会议 CLI **不提供 MP4 直链下载**。
- 因此默认以**官方转写原文**为内容依据（与录屏同源），并在交付说明中如实写明「未落盘原始视频」及原因，不宣称已下载。
- 用户明确要求落盘视频时，把播放地址交给用户手动下载，或使用宿主已有的浏览器能力在已登录会话中操作；**不得伪造下载结果**。

## 5 落地与引用格式

- 在工作目录落盘：`transcript.txt`（`[start-end] 发言人: 文本`）、`tg.json`、`minutes.json`、`inspect.json`、`revision-plan.json`，便于复核与回溯。
- 会议依据统一写成：`YYYY-MM-DD 录屏 HH:MM-HH:MM 发言人：原话`。
- ASR 存在口语化误差（同音误识），涉及规则的关键结论必须结合上下文与方案原文交叉判断，**不得凭单句措辞改写业务规则**。

## 6 降级路径

- 无 tmeet／无权限／只有本地 mp4、m4a：改用宿主已有转写能力（本地音视频转写）。转写不可用时，交付「仍需转写」状态与具体缺项，不把文件名或画面当成声音证据。
- tmeet 报 `500284`／「该功能暂不可使用」：属权限／灰度问题，**不重试**，如实告知用户。
