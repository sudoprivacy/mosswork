# Word 修订接口（跨平台）

对 `.docx` 做黄底修订时，按宿主平台选择脚本。两个脚本**契约完全一致**（同样的 `inspect` / `apply`、同样的计划 JSON、同样的拒绝策略与黄底规则），可互换使用；不安装 Python 包、Node 或 Office。

| 宿主 | 脚本 | 依赖 |
|---|---|---|
| Windows | `scripts/revise-docx.ps1` | 系统自带 `powershell.exe` + .NET |
| macOS / Linux / 无 PowerShell | `scripts/revise_docx.py` | Python 3.8+ 标准库 |
| 两者都没有 | 宿主已有的 Word 编辑能力；仍不行则交付标黄的 HTML 修订建议与未完成项 | — |

路径写成 `<skill>` 占位，实际使用本 Skill 所在目录，不要照抄他人机器路径。

## 1 读取段落与原件哈希

```bash
# Windows
powershell.exe -NoProfile -File "<skill>/scripts/revise-docx.ps1" -Action inspect -InputPath "<原方案.docx>" -OutputPath "<段落索引.json>"

# macOS / Linux
python3 "<skill>/scripts/revise_docx.py" inspect --input "<原方案.docx>" --output "<段落索引.json>"
```

输出 `{sourceSha256, paragraphs:[{id:"p0001", text:"…"}]}`。段落编号按文档顺序，含表格内的段落。

## 2 写修改计划（UTF-8 JSON）

```json
{
  "sourceSha256": "<索引中原件的sha256>",
  "operations": [
    {
      "type": "replace-text",
      "paragraphId": "p0003",
      "oldText": "原文中连续且唯一的文本",
      "newText": "会议明确决定的新文本",
      "decision": "confirmed",
      "evidence": "发言人、时间和原话（材料中有才填写）"
    },
    {
      "type": "insert-after",
      "paragraphId": "p0003",
      "newText": "会议明确决定的新增规则",
      "decision": "confirmed",
      "evidence": "对应会议依据"
    }
  ]
}
```

- `replace-text` 只替换指定段落内**唯一出现**的 `oldText`，保留其余文字及普通文本的 run 样式，**只把新文字标黄**。
- `insert-after` 在指定段落后新增黄底段落，沿用其段落样式（不复制分节符），也不复制该段落原有的黄色标记。
- 同一 `paragraphId` 上可以有多条 `insert-after`，按数组顺序依次插入。
- `decision` 必须是 `confirmed` 且 `evidence` 非空，否则整批拒绝。

## 3 应用并另存副本

```bash
# Windows
powershell.exe -NoProfile -File "<skill>/scripts/revise-docx.ps1" -Action apply -InputPath "<原方案.docx>" -PlanPath "<修改计划.json>" -OutputPath "<原方案_会议修订.docx>"

# macOS / Linux
python3 "<skill>/scripts/revise_docx.py" apply --input "<原方案.docx>" --plan "<修改计划.json>" --output "<原方案_会议修订.docx>"
```

## 4 脚本保证与拒绝策略

两个脚本都会：校验源哈希（计划生成后原件被改动则拒绝）、校验段落编号在范围内、校验 `oldText` 在段内唯一、**遇到任意无效操作整批失败且不产出半成品**、**禁止覆盖原件或已存在的输出文件**、只改写 `word/document.xml`（压缩包内其余部件按原字节写入）、写完后重新解析副本做校验。

遇到以下结构采取**拒绝**策略，不把复杂段落压平，也不静默删除：

- 段落含域、书签、图片、超链接、制表符、软换行等（出现除 `w:pPr` / `w:r` 之外的子节点）；
- run 内含除 `w:rPr` / `w:t` 之外的元素。

纯删除不静默处理：删除意见应通过可用的 Word 修订工具落实，或单独列为待处理项目。

跨平台差异：PowerShell 版用 `XmlDocument` 保留原始 XML 前缀与注释；Python 版通过注册原 `xmlns:*` 前缀保留 `mc:Ignorable` 等依赖前缀的属性，并以 `insert_comments=True` 保留注释。两者产出结果一致（已用同一份文档与计划比对：段落数、黄底数量、非目标部件差异均为零）。

系统不允许执行本地脚本时，**不要更改执行策略**，改用宿主已有 Word 能力，或明确交付 HTML 修订建议与未完成项。
