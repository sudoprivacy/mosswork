---
name: skillhub-skill-s-k-003
description: "知识图谱可视化构建。当用户说\"制作知识图谱\"、\"知识图谱可视化\"、\"构建知识关联图\"、\"生成知识网络图\"、或希望以图谱形式展示知识库资料之间的关联时触发。适用于将任意知识库收藏资料（JSON格式）转化为交互式HTML图谱，支持点击查看详情、主题/等级筛选、关键词搜索。不适用于修改已有图谱或数据分析图表。"
---

# 知识图谱构建器

## 概述

将知识库的收藏资料转化为交互式可视化知识图谱。输入一份 JSON 格式的资料清单，即可生成一个可独立打开的 HTML 文件，以节点-边网络图展示资料之间的关联。

## 输入要求

需要一份 JSON 数组，每条资料至少包含以下字段：

| 字段 | 必填 | 说明 |
|------|------|------|
| `title` | ✅ | 资料标题 |
| `theme` | 推荐 | 主题分类（用于颜色区分） |
| `output_status` | 可选 | 产出状态（未处理/已提炼/已转化），图谱中已转化节点显示绿色边框、已提炼显示蓝色边框 |
| `kb_name` | 推荐 | 所属知识库名称 |
| `media_id` | 可选 | 资料ID（点击节点展示） |
| `media_type` | 可选 | 资料类型 |

数据来源：
- 优先使用 `kb-inventory-update` 技能生成的 `processed_kb_items_latest.json`
- 也可以从知识库扫描结果 `scan_result.json` 直接构建
- 或任何符合上述字段的 JSON 文件

## 工作流程

```
输入 JSON 数据 → 构建图谱节点和边 → 注入 HTML 模板 → 输出可交互文件
```

### Phase 1：构建图谱数据

```bash
python3 scripts/build_graph.py \
    --input processed_kb_items_latest.json \
    --output graph_data.json \
    --max-edges 3000
```

**参数说明：**
- `--input`：必填，包含资料清单的 JSON 文件路径
- `--output`：必填，输出的图谱数据 JSON 路径
- `--max-edges`：可选，最大边数量。默认 3000。节点越多需要越多边来展示关联

**图谱构建逻辑：**

1. **节点**：每条资料一个节点，颜色=主题，大小=等级（A最大、C最小）
2. **边（关键词共现）**：从标题提取关键词（去停用词），同一关键词被2-10篇资料共享则创建边
3. **边（工具/模型共享）**：按 Seedance、Codex、GPT-Image 等工具关键词聚合，权重更高

### Phase 2：生成 HTML 图谱

```bash
python3 scripts/generate_graph_html.py \
    --graph graph_data.json \
    --output 知识图谱.html \
    --title "我的知识库知识图谱"
```

**参数说明：**
- `--graph`：必填，Phase 1 输出的图谱数据 JSON
- `--output`：必填，输出的 HTML 文件路径
- `--title`：可选，图谱标题，默认"知识库收藏知识图谱"

**HTML 特性：**

- ✅ 三重 CDN 容灾（bootcdn → jsdelivr → unpkg），自动切换
- ✅ 异步加载，等待 vis.js 就绪后才初始化（避免白屏）
- ✅ 加载状态反馈（连接中 → 渲染中 → 就绪/失败）
- ✅ 350+ 节点流畅渲染，力导向物理布局

### Phase 3：提供下载

生成后使用 `provide_file` 工具提供下载链接。

如果用户使用了 `kb-inventory-update` 技能且有最新数据，可以直接跳过 Phase 1，复用现有数据：

```bash
# 一步完成
python3 scripts/build_graph.py \
    --input processed_kb_items_latest.json \
    --output graph_data.json && \
python3 scripts/generate_graph_html.py \
    --graph graph_data.json \
    --output 知识图谱.html
```

## 交互功能

打开 HTML 文件后可用以下操作：

| 功能 | 操作 | 说明 |
|------|------|------|
| 🔍 搜索 | 左侧搜索框键入 | 实时筛选匹配标题/主题/知识库的节点 |
| 📂 主题筛选 | 点击主题按钮 | 只看某个主题域的资料 |
| ⭐ 等级筛选 | 点击 A/B/C 按钮 | 聚焦高价值或待清理资料 |
| 🟢 产出状态 | 节点边框 | 绿色=已转化，蓝色=已提炼，红色=⚠️过时，橙色=待复核 |
| 👆 查看详情 | 单击节点 | 右侧显示标题、知识库、等级、产出状态、media_id |
| 🔍 聚焦邻域 | 双击节点 | 放大并高亮该节点及其关联 |
| 🖱️ 拖拽/缩放 | 鼠标滚轮+拖拽 | 自由浏览图谱 |
| 🔄 重置 | 左下按钮 | 恢复全图 |

## 输出摘要

完成后向用户报告：

1. 节点数、边数、HTML 文件大小
2. 各主题域的节点分布
3. 交互操作指南（搜索/筛选/点击/双击）

## 适用场景

- 梳理知识库整体结构和资料分布
- 发现被遗忘但有价值的资料（通过关联边意外发现）
- 评估各主题域的覆盖密度
- 与 kb-inventory-update 配合，每次整理后同步更新图谱

## 资源目录

### scripts/
- `build_graph.py` — 从 JSON 数据构建图谱节点和边
- `generate_graph_html.py` — 将图谱数据注入模板生成 HTML

### assets/
- `template.html` — 交互式图谱 HTML 模板（vis.js + 三重 CDN 容灾）

---
## 部署依赖

本技能脚本依赖 `shared/logger.py`（统一日志模块）。部署时需将 `shared/` 目录与技能目录放在**同级**位置：

```
skills/
├── shared/          ← 必须存在（来自 shared.zip）
│   └── logger.py
└── kb-inventory-update/  （或 kb-graph-builder / kb-auto-digester）
```

脚本通过 `sys.path.insert(0, .../../..)` 自动定位，无需额外配置。若缺少该模块，脚本会报 `ModuleNotFoundError: shared.logger`。
