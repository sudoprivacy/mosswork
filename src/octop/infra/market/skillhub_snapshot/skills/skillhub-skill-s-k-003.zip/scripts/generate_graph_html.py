#!/usr/bin/env python3
"""将图谱数据 JSON 注入 HTML 模板，生成可独立打开的交互式知识图谱。

用法：
    python3 generate_graph_html.py --graph GRAPH_JSON --output OUTPUT_HTML [--title "自定义标题"]
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log

import json
import sys
import os

TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "assets", "template.html")


def main():
    args = sys.argv[1:]
    graph_path = args[args.index("--graph") + 1]
    output_path = args[args.index("--output") + 1]
    title = args[args.index("--title") + 1] if "--title" in args else "知识库收藏知识图谱"

    with open(graph_path, "r", encoding="utf-8") as f:
        graph = json.load(f)

    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        html = f.read()

    nodes_str = json.dumps(graph["nodes"], ensure_ascii=False)
    edges_str = json.dumps(graph["edges"], ensure_ascii=False)

    html = html.replace("__NODES_PLACEHOLDER__", nodes_str)
    html = html.replace("__EDGES_PLACEHOLDER__", edges_str)
    html = html.replace("__TITLE__", title)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    log.info(f"图谱 HTML 生成完成: {os.path.getsize(output_path)/1024:.1f} KB → {output_path}")


if __name__ == "__main__":
    main()
