#!/usr/bin/env python3
"""从知识库整理数据构建图谱节点和边。

输入：processed_kb_items JSON（来自 kb-inventory-update 的输出，或任何包含 title/theme/grade/kb_name/media_id 字段的 JSON 数组）
输出：包含 nodes 和 edges 的 JSON 文件


用法：
    python3 build_graph.py --input ITEMS_JSON --output GRAPH_JSON [--max-edges 3000]
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log

import json
import re
import sys
import os
from collections import defaultdict



THEME_COLORS = {
    "AI提示词工程": "#e74c3c", "AI视频与自媒体运营": "#3498db",
    "AI视觉与图像创作": "#9b59b6", "AI工具与自动化": "#2ecc71",
    "市场拓展与变现": "#e67e22", "个人学习方法": "#95a5a6",
    "写作表达与公文材料": "#1abc9c",
}

STOP_WORDS = {
    "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一",
    "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着",
    "没有", "看", "自己", "这", "他", "她", "它", "们", "那", "些",
    "什么", "怎么", "如何", "为什么", "还是", "可以", "这个", "那个",
    "已经", "比较", "非常", "就是", "使用", "通过", "进行", "对于",
    "所以", "还有", "或", "但", "与", "从", "被", "让", "把", "用", "对",
}

# 二级标签关键词（用于生成工具级关联）
TOOL_KEYWORDS = [
    "Seedance", "GPT-Image", "Image2", "Nano Banana", "Codex",
    "Claude", "Gemini", "DeepSeek", "NotebookLM", "YouTube",
    "PPT", "Skill", "Agent", "OpenClaw", "MCP", "Sora",
    "Midjourney", "ComfyUI", "Stable Diffusion", "SD",
    "豆包", "即梦", "剪映", "可灵",
]


def extract_keywords(title):
    """从标题中提取有意义的关键词（去停用词）。"""
    clean = re.sub(r'[#＃【】\[\]「」\(\)（）\@\*]', ' ', title)
    clean = re.sub(r'[，。！？、：；～…·,\.!\?:\-]', ' ', clean)
    words = [w for w in clean.split() if len(w) >= 2 and w not in STOP_WORDS]
    return words[:10]


def determine_color(theme):
    """根据主题返回节点颜色，未匹配返回默认灰色。"""
    for key, color in THEME_COLORS.items():
        if key in (theme or ""):
            return color
    return "#7f8c8d"


def build_graph(items, max_edges=3000):
    """
    构建图谱数据。

    节点：每条资料一个节点，含 id/label/title/group/color/value 等字段。
    边：基于两种方式生成——
      1. 标题关键词共现（同一关键词被2-8篇资料共享则连边）
      2. 工具/模型共享（同一工具词出现在多篇资料中则连边，权重更高）
    """
    title_to_id = {}
    nodes = []

    for idx, item in enumerate(items):
        title = (item.get("title") or item.get("label") or "")[:80]
        node_id = str(idx)
        title_to_id[title] = node_id

        theme = item.get("theme", "")
        grade = item.get("grade", "B")
        output_status = item.get("output_status", item.get("status", ""))
        timeliness = item.get("timeliness", "current")
        color = determine_color(theme)
        size = {"A": 22, "B": 14, "C": 10}.get(grade, 14)

        # 产出状态着色：已转化为绿色边框，已提炼为蓝色边框
        border_color = None
        if output_status == "已转化":
            border_color = "#27ae60"
        elif output_status == "已提炼":
            border_color = "#2980b9"

        # 时效性着色：过时=红色虚线边框，待复核=橙色虚线边框
        if timeliness == "outdated":
            border_color = "#e74c3c"
        elif timeliness == "review" and not border_color:
            border_color = "#f39c12"

        nodes.append({
            "id": node_id,
            "label": title[:30],
            "full_title": title,
            "kb_name": item.get("kb_name", ""),
            "theme": theme,
            "grade": grade,
            "output_status": output_status,
            "timeliness": timeliness,
            "media_id": item.get("media_id", ""),
            "media_type": item.get("media_type", ""),
            "value": size,
            "color": color,
            "group": theme,
            "borderColor": border_color or color,
        })

    # ── 边：关键词共现 ──
    edge_set = set()
    edges = []
    keyword_index = defaultdict(list)

    for item in items:
        title = (item.get("title") or item.get("label") or "")[:80]
        keywords = extract_keywords(title)
        for kw in set(keywords):
            keyword_index[kw].append(title_to_id[title])

    for kw, node_ids in keyword_index.items():
        if 1 < len(node_ids) <= 10:
            for i in range(len(node_ids)):
                for j in range(i + 1, len(node_ids)):
                    ek = (node_ids[i], node_ids[j])
                    if ek not in edge_set and len(edges) < max_edges:
                        edge_set.add(ek)
                        edges.append({"from": node_ids[i], "to": node_ids[j], "label": kw[:8], "value": 0.5})

    # ── 边：工具/模型共享 ──
    tool_index = defaultdict(list)
    for item in items:
        title = (item.get("title") or item.get("label") or "")[:80]
        for tk in TOOL_KEYWORDS:
            if tk in title:
                tool_index[tk].append(title_to_id[title])
                break

    for tk, node_ids in tool_index.items():
        if len(node_ids) > 1 and len(edges) < max_edges:
            for i in range(len(node_ids)):
                for j in range(i + 1, len(node_ids)):
                    ek = (node_ids[i], node_ids[j])
                    if ek not in edge_set:
                        edge_set.add(ek)
                        edges.append({"from": node_ids[i], "to": node_ids[j], "label": tk[:8], "value": 1})

    return {"nodes": nodes, "edges": edges[:max_edges]}


def main():
    args = sys.argv[1:]
    input_path = args[args.index("--input") + 1]
    output_path = args[args.index("--output") + 1]
    max_edges = int(args[args.index("--max-edges") + 1]) if "--max-edges" in args else 3000

    with open(input_path, "r", encoding="utf-8") as f:
        items = json.load(f)

    graph = build_graph(items, max_edges)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(graph, f, ensure_ascii=False)

    log.info(f"图谱构建完成: {len(graph['nodes'])} 节点, {len(graph['edges'])} 边 → {output_path}")


if __name__ == "__main__":
    main()
