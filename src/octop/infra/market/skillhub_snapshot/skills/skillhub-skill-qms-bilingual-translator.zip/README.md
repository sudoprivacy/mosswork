# QMS 中英双语翻译

把制药企业的中文 QMS/GMP 文件译成**一段中文、一段英文**的双语 Word 文档，英文术语与句式对齐 ICH Q7。

## 能处理什么

管理规程、标准操作规程（SOP）、质量标准、验证方案与报告、批生产记录、偏差/OOS 调查报告、质量协议、供应商审计报告等。

题目和正文全部译；表格保留原结构，单元格内中文一行、英文一行。

## 怎么用

装好后直接在对话里说：

> 把这份《偏差处理管理规程.docx》译成中英双语 Word

> 按 Q7 标准把这份 SOP 译成中英对照，存到 D:\质量文件

技能会自动完成：解析源文件 → 按 Q7 术语表落词 → 生成 docx → 质检 → 交付。

## 英译标准

以 ICH Q7《Good Manufacturing Practice Guide for Active Pharmaceutical Ingredients》（Step 4, 2000）为范本，规则落在三份参考文件里：

| 文件 | 内容 |
|---|---|
| `references/q7-glossary.md` | 约 250 条中英术语对照，标出易错点（quality unit(s)、确认=qualification、返工≠重新加工） |
| `references/q7-style-guide.md` | 情态动词、句式模板、拼写、中文公文套话处理 |
| `references/q7-full-text.txt` | Q7 全文，用于核实原句用词 |

几条硬规则：中文"应"→ `should`；`must` 只用于法定强制义务；**不用 `shall`**（Q7 全文零使用）；质量部门一律 `quality unit(s)`。

## 输出

- 格式：A4，标题小二黑体居中，正文五号宋体、首行缩进 2 字符，英文 Times New Roman 紧随其后，页眉带标题、页脚居中页码。
- 位置：默认 `E:\QMS管理文件\QMS_中英双语`；没有 E 盘时退到 `~/Documents/QMS_中英双语`；也可用环境变量 `QMS_BILINGUAL_OUTDIR` 指定。
- 同名文件默认不覆盖，防止冲掉受控文件。

## 依赖

Python 3.9+，`python-docx`（生成 Word）、`pypdf`（读 PDF）。首次运行时技能会自动检测并安装。

Windows 自带宋体、黑体、Times New Roman；macOS/Linux 若缺字体，改 `scripts/build_bilingual_docx.py` 顶部的 `ZH_FONT` / `ZH_HEI` 常量。

## 不适合的场景

- 扫描版 PDF（无文字层）——需先 OCR。
- 无中文原文、需要从零撰写英文文件的情形。
- 需要按 EU GMP、US FDA 特定表述改写的场景（本技能以 ICH Q7 为准）。
