---
name: skillhub-skill-qms-bilingual-translator
description: "把制药企业中文 QMS/GMP 文件（管理规程、SOP、质量标准、验证方案与报告、批生产记录、偏差/OOS 调查报告、质量协议等）译成\"一段中文、一段英文\"的双语 Word 文档，英文以 ICH Q7《Good Manufacturing Practice Guide for Active Pharmaceutical Ingredients》的术语与句式为标准范本。当用户提出\"中英双语\"\"中英对照\"\"翻译 GMP/QMS 文件\"\"按 Q7 标准翻译\"\"出双语 Word\"等需求时使用。"
---

# QMS 中英双语文件生成

把中文 QMS 文件转成一份可直接归档的双语 .docx：**题目和正文均译**，版式为**一段中文紧跟一段对应英文**，英文用词与句式对齐 ICH Q7。

## 交付物

单个 .docx，结构如下：

```
标题（中文，小二黑体居中）
Title (English, Times New Roman 加粗居中)
────────────────────────────────
1 目的
1 Purpose
    为规范……（中文段落，首行缩进 2 字符）
    To standardize ...（英文段落，紧随其后）
```

表格保持原表格结构，每个单元格内**中文一行、英文一行**。

**输出位置固定**：所有生成的 .docx 一律存到 `E:\QMS管理文件\QMS_中英双语\`。脚本会把输出路径的目录部分统一替换为该目录，只取文件名；不要在其他地方另存副本，也不要在工作区留交付物。

## 前置环境

脚本依赖 `python-docx`（生成 docx）与 `pypdf`（读 PDF）。先探测可用的解释器，缺库再装：

```bash
# 1) 找一个能用的 python：优先 PATH，其次 WorkBuddy 托管解释器（版本号按实际目录取）
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && PY=$(ls -d "$HOME"/.workbuddy/binaries/python/versions/*/python.exe 2>/dev/null | tail -1)
"$PY" -c "import docx, pypdf" 2>/dev/null || "$PY" -m pip install -q python-docx pypdf
```

下文用 `$SKILL` 指代本 skill 目录（`~/.workbuddy/skills/qms-bilingual-translator`）。

## 工作流

### 第 1 步：解析源文件

```bash
"$PY" "$SKILL/scripts/extract_source.py" "输入文件.docx" -o work/source.blocks.jsonl --txt work/source.txt
```

- 支持 .docx / .pdf / .md / .txt。PDF 若是扫描件（提取结果为空或成段乱码），先告知用户需要 OCR 版本，不要硬译。
- **通读 `work/source.txt`**，弄清章节层级、条款编号、列表与表格位置。不要一次性把整份 jsonl 读进上下文，长文档按章节分段处理。
- 检查输出的结构统计：`title/h1/h2/h3/para/li/table` 数量是否与原文观感一致。若标题全被识别成 `para`，说明源文件没用样式，按编号规则（`1`、`1.1`、`1.1.1`）手工在 jsonl 里改 type。

### 第 2 步：确定术语

1. 打开 `references/q7-glossary.md`，把源文中出现的术语逐条落下。
2. 表中没有的，先检索 Q7 原文确认官方用词：

```bash
grep -n -i "关键词" "$SKILL/references/q7-full-text.txt" | head -20
```

3. Q7 未覆盖的现代概念（CAPA、数据完整性、审计追踪、质量协议等），沿用 EU/US GMP 通行译法，并在交付说明中列出。

术语一旦定下，全文不得更换同义词——检查官按词核对，同义词会被视为体系不一致。

### 第 3 步：翻译并产出双语 JSONL

一行一块，UTF-8，中文原文**照抄不改**（只填 `en`）：

```json
{"type":"title","zh":"偏差处理管理规程","en":"Procedure for Deviation Management"}
{"type":"h1","zh":"1 目的","en":"1 Purpose"}
{"type":"para","zh":"建立偏差处理规程，规范偏差的报告、调查、评估与关闭。","en":"To establish a procedure for deviation handling and to standardize the reporting, investigation, evaluation and closure of deviations."}
{"type":"li","zh":"偏差发现人应在发现后立即报告。","en":"The person detecting the deviation should report it immediately upon detection.","level":1}
{"type":"table","rows":[[{"zh":"序号","en":"No."},{"zh":"步骤","en":"Step"}],[{"zh":"1","en":"1"},{"zh":"偏差报告","en":"Deviation reporting"}]]}
```

规则：

- **块序与块类型必须与源文一致**，不合并、不拆分、不增删段落。原文一句拆成两句英文时，仍写在同一块里。
- 长文档分批写：每 30–50 块一个 `work/part01.jsonl`、`work/part02.jsonl`……，最后按顺序拼给生成脚本。这样单次输出可控，也便于中途校对。
- 表格单元格可用简写 `"中文||English"` 代替对象，两者等价。
- 编号、批号、日期、单位、文件代号、专有名词原样保留；中文数字编号（一、二、三）转阿拉伯数字，除非原文是章节标题。
- 只译标题与正文；封面审批栏、页眉页脚、签名字样按原文结构保留并翻译其文字。

翻译时**必须**先读 `references/q7-style-guide.md`（句法、情态动词、拼写、套话处理），并按 `references/q7-glossary.md` 落词。两条最硬的红线：

- 中文"应"→ `should`；`must` 只留给法定强制义务；**永不使用 `shall`**。
- 质量部门一律 `quality unit(s)`，不得写 quality department。

### 第 4 步：生成 Word

```bash
"$PY" "$SKILL/scripts/build_bilingual_docx.py" "偏差处理管理规程_中英双语_20261019.docx" work/part*.jsonl
```

- **只传文件名**，不要拼目录。脚本固定写入 `E:\QMS管理文件\QMS_中英双语\`（`--outdir` 可改，非必要不用）。
- 文件名格式：`<原文件名去扩展名>_中英双语_<YYYYMMDD>.docx`。目标文件已存在时脚本会直接停止，**必须先问用户**是覆盖（加 `--force`）还是换版本号。
- 中间文件（`work/*.jsonl`、`source.txt`）留在工作区，不进交付目录。

脚本自动完成：A4 页面、标题分层、中文首行缩进 2 字符、英文紧随其后并留 8pt 段后距、表格中英同格、页眉放标题、页脚居中页码。

改版式时改脚本顶部常量（字体、字号、`--line-spacing`），不要逐段手工调格式。

### 第 5 步：质检（不可跳过）

```bash
"$PY" "$SKILL/scripts/qa_check.py" work/part*.jsonl
```

- **[错误]** 必须清零：缺译文、英文混入汉字、出现 `shall`、JSON 解析失败。
- **[警告]** 逐条判断：`must` 滥用、禁用语（quality department / labeling / acceptable criteria 等）、单句超 40 词、英文段全角标点。
- **[提示]** 术语复核：脚本按术语表反查，列出"中文出现该术语但英文未用规定译法"的位置，逐条核对后决定改或不改。

修完重跑第 4、5 步，直到无错误。再抽查 3–5 段对照原文，确认无漏译、无错位。

### 第 6 步：交付

用 `present_files` 打开 `E:\QMS管理文件\QMS_中英双语\<文件名>.docx`，并说明：**完整输出路径**、块数/字数、术语新增项、质检结果、以及需要用户确认的取舍（如"质量受权人"译为 quality authorized person 还是 Qualified Person）。

## 硬性规则

1. **范围**：题目 + 正文全覆盖，不得只译正文不译标题，也不得保留未译段落。
2. **配对**：一段中文后必须紧跟其英文；不得先整篇中文再整篇英文。
3. **顺序不可乱**：中英错位是本类交付最严重的错误，交付前必须按块抽查。
4. **术语唯一**：同一中文术语全文一种译法。
5. **不润色不增删**：原文没有的要求不得添加，原文有的要求不得删除——译文是受控文件，不是改写。
6. **数字与标识原样**：批号、编号、日期、规格、限度、单位一律照抄。
7. **中文原文零改动**：`zh` 字段与源文逐字一致（仅允许去除多余空格与换行）。
8. **不臆造法规引用**：原文引用某法规/药典章节时，保留原引用，不补充原文没有的条款号。
9. **输出统一存放**：最终 .docx 只放在 `E:\QMS管理文件\QMS_中英双语\`，不放工作区、不放桌面、不发散到其他目录。

## 常见坑

| 现象 | 处理 |
|---|---|
| 中文长句含 4–5 个分句 | 拆成 2–3 个英文句，每句一个要求；块不变 |
| "对……进行检验" | 直接 `test ...`，去掉"进行" |
| "确保……得到有效执行" | `ensure that ... is effectively implemented`，不译 obtain execution |
| 中文"必须"但属管理要求 | 译 `should`，不是 `must` |
| "确认"（DQ/IQ/OQ/PQ、设备确认） | `qualification`，不是 confirmation |
| "检验"与"检查"混淆 | 检验→testing，检查/视察→inspection |
| 表格列数不一致 | 生成脚本按最多列补齐，缺格留空；源表本身错列需回问用户 |
| 源文有合并单元格 | 读出的重复单元格文本会重复出现，翻译时只保留一份，其余留空 |
| 文件很长（>300 块） | 按章节分批翻译与分段质检，最后一次性生成，避免中途上下文丢失 |
| 目标目录不存在 | 脚本会自动创建 `E:\QMS管理文件\QMS_中英双语\`；若 E 盘不可写（只读/未挂载），停下问用户，不要改存到工作区 |
| 同名文件已存在 | 脚本默认拒绝写入并报错；问用户是否 `--force` 覆盖，或换带版本号的文件名 |

## 移植到其他电脑（分享给同事时先确认这几条）

| 项 | 说明 |
|---|---|
| 输出目录 | 默认 `E:\QMS管理文件\QMS_中英双语`；没有 E 盘时自动退到 `~/Documents/QMS_中英双语`；也可用环境变量 `QMS_BILINGUAL_OUTDIR` 指定。**首次在新机器运行前，先跟用户确认目录** |
| Python 依赖 | `python-docx`、`pypdf`，按"前置环境"一节安装 |
| 字体 | 宋体、黑体、Times New Roman 需系统存在。macOS/Linux 缺宋体时改脚本顶部 `ZH_FONT` / `ZH_HEI` / `EN_FONT` |
| 参考文件 | Q7 全文、术语表、风格规范均已随 skill 打包，**不依赖**原 `E:\法规指南` 目录，也不依赖本机任何路径 |
| 打包 | 用 skill-creator 的 `package_skill.py <skill目录>` 生成 zip；zip 内顶层目录必须是 `qms-bilingual-translator/`，否则对方导入后结构不对 |

## 参考文件

| 文件 | 用途 | 何时读 |
|---|---|---|
| `references/q7-glossary.md` | 中英术语对照（约 250 条，含易错备注） | 第 2 步，每次必读 |
| `references/q7-style-guide.md` | 句法、情态动词、拼写、中文套话处理、自检清单 | 第 3 步，每次必读 |
| `references/q7-full-text.txt` | Q7 全文（49 页），用 grep 查原句与上下文 | 核实术语或句式时按需检索，不要整份读入 |
