#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把源文件解析成结构化 JSONL，供后续翻译与生成双语 Word 使用。

用法:
    python extract_source.py <源文件> [-o out/source.blocks.jsonl] [--txt out/source.txt]

支持 .docx / .pdf / .md / .txt。
每条 JSONL 一行，字段:
    文本块: {"id": 1, "type": "title|h1|h2|h3|para|li", "zh": "原文", "level": 0}
    表格块: {"id": 12, "type": "table", "rows": [["单元格", ...], ...]}
"""
import argparse
import json
import os
import re
import sys

CJK = re.compile(r"[\u4e00-\u9fff]")
NUM_HEADING = re.compile(r"^\s*(\d+(?:\.\d+)*)\s*[、.．]?\s+\S")
CHAPTER_HEADING = re.compile(r"^\s*第[一二三四五六七八九十百]+[章节条]\s*")
LIST_MARK = re.compile(r"^\s*(?:[•·▪◦\-–—*]|\(?\d+[)）]|\(?[一二三四五六七八九十]+[)）]|[①-⑳]|[a-zA-Z][)）])\s+")
BULLET_CHARS = "•·▪◦-–—*"


# ---------- docx ----------
def iter_docx_blocks(path):
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    from docx.oxml.table import CT_Tbl
    from docx.oxml.text.paragraph import CT_P

    doc = Document(path)
    parent = doc.element.body
    for child in parent.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, doc)
        elif isinstance(child, CT_Tbl):
            yield Table(child, doc)


def outline_level(par):
    """读 paragraph 的 outlineLvl，用于识别无样式标题。"""
    try:
        pPr = par._p.pPr
        if pPr is None:
            return None
        node = pPr.find("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}outlineLvl")
        if node is None:
            return None
        return int(node.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val")) + 1
    except Exception:
        return None


def heading_level_of(par, text):
    """返回 1/2/3 表示标题层级，None 表示正文。"""
    style = (par.style.name or "") if par.style is not None else ""
    s = style.lower()
    m = re.search(r"(?:heading|标题)\s*(\d)", s)
    if m:
        return min(int(m.group(1)), 3)
    if s in ("title", "标题"):
        return 0
    lvl = outline_level(par)
    if lvl:
        return min(lvl, 3)
    m = NUM_HEADING.match(text)
    if m:
        # 形如 "6.3 Records of ..." 或 "7.3 取样" 且不长，视为标题
        if len(text) <= 60 and not text.rstrip().endswith(("。", "；", ".", ";")):
            return min(m.group(1).count(".") + 1, 3)
    if CHAPTER_HEADING.match(text) and len(text) <= 40:
        return 1
    return None


def is_list_item(par, text):
    style = (par.style.name or "").lower() if par.style is not None else ""
    if "list" in style or "列表" in style:
        return True
    if text[:1] in BULLET_CHARS:
        return True
    return bool(re.match(r"^\s*(\(?\d+[)）]|[①-⑳]|[一二三四五六七八九十]+、)", text))


def clean(text):
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


# ---------- pdf ----------
def iter_pdf_blocks(path):
    from pypdf import PdfReader

    reader = PdfReader(path)
    lines = []
    for page in reader.pages:
        raw = page.extract_text() or ""
        for ln in raw.split("\n"):
            ln = clean(ln)
            if ln:
                lines.append(ln)

    merged = []
    for ln in lines:
        if not merged:
            merged.append(ln)
            continue
        prev = merged[-1]
        prev_end = prev[-1]
        starts_lower = ln[0].islower()
        if (prev_end not in "。；：:.;!?！？" and (starts_lower or CJK.match(prev[-1] or ""))
                and not NUM_HEADING.match(ln) and len(prev) > 12):
            merged[-1] = prev + (" " if (prev[-1].isascii() and ln[0].isascii()) else "") + ln
        else:
            merged.append(ln)

    for ln in merged:
        # 去掉页眉页脚式噪声（纯数字、页码）
        if re.fullmatch(r"[-—\s]*\d{1,3}[-—\s]*", ln):
            continue
        yield {"kind": "text", "text": ln}


# ---------- md/txt ----------
def iter_text_blocks(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            ln = clean(raw)
            if not ln:
                continue
            m = re.match(r"^(#{1,4})\s+(.*)$", ln)
            if m:
                yield {"kind": "md_heading", "level": len(m.group(1)), "text": m.group(2).strip()}
            elif re.match(r"^\s*\|.*\|\s*$", ln):
                yield {"kind": "md_table_row", "text": ln}
            else:
                yield {"kind": "text", "text": ln}


def parse_md_tables(rows):
    """把连续的 markdown 表格行合并成一个表格块。"""
    cells = []
    for row in rows:
        if re.fullmatch(r"\|[\s:\-|]+\|", row.strip()):
            continue
        parts = [c.strip() for c in row.strip().strip("|").split("|")]
        cells.append(parts)
    return cells


def build_blocks(path):
    ext = os.path.splitext(path)[1].lower()
    blocks = []
    seq = 0

    def add_text(text, level=None, force_list=False):
        nonlocal seq
        text = clean(text)
        if not text:
            return
        seq += 1
        if level == 0:
            btype = "title"
        elif level in (1, 2, 3):
            btype = f"h{level}"
        elif force_list:
            btype = "li"
        else:
            btype = "para"
        blocks.append({"id": seq, "type": btype, "zh": text})

    if ext == ".docx":
        first_text_seen = False
        for item in iter_docx_blocks(path):
            if item.__class__.__name__ == "Table":
                rows = []
                for row in item.rows:
                    cells = []
                    for cell in row.cells:
                        cells.append(clean(cell.text.replace("\n", " ")))
                    if any(cells):
                        rows.append(cells)
                if rows:
                    seq += 1
                    blocks.append({"id": seq, "type": "table", "rows": rows})
                continue

            text = clean(item.text)
            if not text:
                continue
            lvl = heading_level_of(item, text)
            if (lvl is None and not first_text_seen and len(text) <= 60
                    and not NUM_HEADING.match(text) and not CHAPTER_HEADING.match(text)):
                lvl = 0  # 首个短段落当作文件标题（但编号开头的视为章节）
            first_text_seen = True
            add_text(text, lvl, force_list=is_list_item(item, text))

    elif ext == ".pdf":
        first = True
        for b in iter_pdf_blocks(path):
            text = b["text"]
            lvl = heading_level_of_simple(text)
            if (first and len(text) <= 80 and lvl is None
                    and not NUM_HEADING.match(text) and not CHAPTER_HEADING.match(text)):
                lvl = 0
            first = False
            add_text(text, lvl, force_list=bool(LIST_MARK.match(text)))

    elif ext in (".md", ".markdown", ".txt"):
        pending_table = []

        def flush_table():
            nonlocal seq
            if pending_table:
                rows = parse_md_tables(pending_table)
                if rows:
                    seq += 1
                    blocks.append({"id": seq, "type": "table", "rows": rows})
                pending_table.clear()

        for b in iter_text_blocks(path):
            if b["kind"] == "md_table_row":
                pending_table.append(b["text"])
                continue
            flush_table()
            if b["kind"] == "md_heading":
                add_text(b["text"], b["level"])
            else:
                add_text(b["text"], heading_level_of_simple(b["text"]),
                         force_list=bool(LIST_MARK.match(b["text"])))
        flush_table()
    else:
        raise SystemExit(f"不支持的格式: {ext}")

    return blocks


def heading_level_of_simple(text):
    if len(text) <= 60 and not text.rstrip().endswith(("。", "；", ".", ";")):
        m = NUM_HEADING.match(text)
        if m:
            return min(m.group(1).count(".") + 1, 3)
        if CHAPTER_HEADING.match(text):
            return 1
    return None


def to_txt(blocks):
    out = []
    for b in blocks:
        if b["type"] == "table":
            out.append("[TABLE]")
            for row in b["rows"]:
                out.append(" | ".join(row))
            out.append("[/TABLE]")
        else:
            prefix = {"title": "# ", "h1": "## ", "h2": "### ", "h3": "#### ", "li": "- "}.get(b["type"], "")
            out.append(prefix + b["zh"])
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    ap.add_argument("-o", "--out", default=None, help="输出 JSONL 路径")
    ap.add_argument("--txt", default=None, help="同时输出可读的纯文本，便于通读校对")
    args = ap.parse_args()

    if not os.path.exists(args.source):
        raise SystemExit(f"文件不存在: {args.source}")

    blocks = build_blocks(args.source)
    if not blocks:
        raise SystemExit("未解析到任何内容，请检查源文件是否为可提取文本的版本（扫描件需先 OCR）")

    stem = os.path.splitext(os.path.basename(args.source))[0]
    out = args.out or os.path.join(os.getcwd(), "source.blocks.jsonl")
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        for b in blocks:
            f.write(json.dumps(b, ensure_ascii=False) + "\n")

    n_text = sum(1 for b in blocks if b["type"] != "table")
    n_table = sum(1 for b in blocks if b["type"] == "table")
    print(f"[OK] {stem}: {len(blocks)} 块（段落 {n_text}，表格 {n_table}）-> {out}")

    if args.txt:
        with open(args.txt, "w", encoding="utf-8") as f:
            f.write(to_txt(blocks))
        print(f"[OK] 可读文本 -> {args.txt}")

    types = {}
    for b in blocks:
        types[b["type"]] = types.get(b["type"], 0) + 1
    print("[结构]", ", ".join(f"{k}:{v}" for k, v in sorted(types.items())))


if __name__ == "__main__":
    sys.exit(main())
