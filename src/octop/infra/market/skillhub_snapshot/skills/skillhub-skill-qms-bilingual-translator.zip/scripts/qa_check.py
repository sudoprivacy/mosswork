#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""双语 JSONL 质检：结构完整性、Q7 风格合规、术语一致性。

用法:
    python qa_check.py 文件1.jsonl [文件2.jsonl ...] [--glossary references/q7-glossary.md]

输出分级：
    [错误] 交付前必须修复（缺译文、英文混入汉字、出现 shall 等）
    [警告] 合规风险（must 滥用、禁用语、超长句、全角标点）
    [提示] 术语可能与 Q7 用词不一致，需人工复核
"""
import argparse
import json
import os
import re
import sys

CJK = re.compile(r"[\u4e00-\u9fff]")
FULLWIDTH = re.compile(r"[，。；：！？（）【】“”‘’、]")

FORBIDDEN = [
    (r"\bshall\b", "使用 shall（Q7 零使用，属合同语域）", "error"),
    (r"\bquality department\b|\bQA department\b", "应作 quality unit(s)", "error"),
    (r"\bmid-?product\b|\bintermediate product\b", "应作 intermediate", "warn"),
    (r"\bbulk drug\b|\braw medicine\b", "应作 API", "warn"),
    (r"\blabeling\b|\blabeled\b", "Q7 用 labelling / labelled（双写 l）", "warn"),
    (r"\bacceptable criteria\b", "应作 acceptance criteria", "warn"),
    (r"\bquality standard\b", "指质量标准时应作 specification", "warn"),
    (r"\bvalidity date\b", "应作 expiry date", "warn"),
    (r"\bmaster batch record\b", "Q7 用 master production instructions", "warn"),
    (r"\bsuch as[^.]{0,120}\betc\.", "such as 与 etc. 不得叠用", "warn"),
    (r"\bmust\b", "must 仅用于法定强制义务；管理要求应为 should", "warn"),
]

# 过于宽泛、必然误报的词，不做术语反查
PRIORITY_SKIP = {
    "生产", "记录", "文件", "内容", "程序", "批", "范围", "职责", "取样", "检验",
    "包装", "标签", "设备", "物料", "验证", "确认", "质量", "放行", "变更", "偏差",
}


def load_glossary(path):
    """解析术语表 -> [{"zh":..,"ens":[..],"skip":bool}]"""
    items = []
    if not path or not os.path.exists(path):
        return items
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip().startswith("|"):
                continue
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) < 2:
                continue
            zh_cell = re.sub(r"[*`⚠]", "", cells[0]).strip()
            en_cell = re.sub(r"[*`]", "", cells[1]).strip()
            note = cells[2] if len(cells) > 2 else ""
            if not zh_cell or set(zh_cell) <= set("-: ") or zh_cell == "中文":
                continue
            skip = ("章节名" in note) or ("仅用于章节标题" in note)

            ens = set()
            for part in re.split(r"[；;]", en_cell):
                part = part.strip()
                if not part:
                    continue
                ens.add(part)
                # "Reserve/Retention Samples" 这类并列写法，逐项也算命中
                for sub in re.split(r"\s*/\s*", part):
                    if len(sub) >= 3:
                        ens.add(sub.strip())
                bare = re.sub(r"\s*\([^)]*\)", "", part).strip()
                if len(bare) >= 3:
                    ens.add(bare)
                for abbr in re.findall(r"\(([A-Za-z][A-Za-z/&\-]{1,12})\)", part):
                    ens.add(abbr)
            ens = {e for e in ens if e and len(e) >= 3}

            for zk in re.split(r"\s*/\s*", zh_cell):
                zk = zk.strip()
                if len(zk) >= 2 and zk not in PRIORITY_SKIP:
                    items.append({"zh": zk, "ens": sorted(ens), "skip": skip})
    return items


def norm(s):
    return re.sub(r"\s+", " ", s.lower()).strip()


def check_terms(zh, en, glossary):
    """长词优先匹配，避免「原料」被「原料药」里的片段误触发。"""
    spans = []
    for item in glossary:
        if item["skip"] or not item["ens"]:
            continue
        pos = zh.find(item["zh"])
        while pos != -1:
            spans.append((pos, pos + len(item["zh"]), item))
            pos = zh.find(item["zh"], pos + 1)
    spans.sort(key=lambda s: s[1] - s[0], reverse=True)

    chosen, taken, seen = [], [], set()
    for s, e, item in spans:
        if item["zh"] in seen:
            continue
        if any(not (e <= cs or s >= ce) for cs, ce in taken):
            continue
        chosen.append((s, e, item))
        taken.append((s, e))
        seen.add(item["zh"])

    en_l = norm(en)
    hits = []
    for _, _, item in chosen:
        if any(norm(x) in en_l for x in item["ens"]):
            continue
        hits.append(f"「{item['zh']}」→ 期望 {item['ens'][0]}")
    return hits[:3]


def iter_entries(path):
    """产出 (loc, zh, en, is_table)"""
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("//"):
                continue
            loc = f"{os.path.basename(path)}:{lineno}"
            try:
                b = json.loads(line)
            except json.JSONDecodeError as e:
                yield loc, None, None, False, f"JSON 解析失败：{e}"
                continue
            if b.get("type") == "table":
                zh_cells, en_cells = [], []
                for row in b.get("rows") or []:
                    for c in row:
                        if isinstance(c, dict):
                            zh_cells.append(str(c.get("zh") or ""))
                            en_cells.append(str(c.get("en") or ""))
                        else:
                            z, _, e = str(c).partition("||")
                            zh_cells.append(z)
                            en_cells.append(e)
                yield loc, zh_cells, en_cells, True, None
            else:
                yield (loc, [(b.get("zh") or "").strip()], [(b.get("en") or "").strip()],
                       False, None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--glossary", default=None)
    ap.add_argument("--max-term-hints", type=int, default=40)
    args = ap.parse_args()

    if args.glossary is None:
        args.glossary = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                     "references", "q7-glossary.md")
    glossary = load_glossary(args.glossary)

    errors, warnings, hints = [], [], []
    n_blocks = n_missing = 0
    should = must = shall = 0
    words_total = sents_total = 0

    for path in args.inputs:
        for loc, zh_list, en_list, is_table, parse_err in iter_entries(path):
            if parse_err:
                errors.append(f"{loc} {parse_err}")
                continue
            n_blocks += 1
            zh = " ".join(z for z in zh_list if z).strip()
            en_parts = [e for e in en_list if e]

            if not en_parts:
                n_missing += 1
                errors.append(f"{loc} 缺少英文译文：{zh[:40]}")
                continue

            en = " " + " ".join(en_parts) + " "

            for z, e in zip(zh_list, en_list):
                if e and CJK.search(e):
                    errors.append(f"{loc} 英文中混入汉字：{e[:50]}")
                if e and FULLWIDTH.search(e):
                    warnings.append(f"{loc} 英文出现全角标点：{e[:50]}")

            should += len(re.findall(r"\bshould\b", en, re.I))
            must += len(re.findall(r"\bmust\b", en, re.I))
            shall += len(re.findall(r"\bshall\b", en, re.I))

            for pat, msg, level in FORBIDDEN:
                m = re.search(pat, en, re.I)
                if m:
                    snippet = en[max(0, m.start() - 25):m.end() + 25].strip()
                    (errors if level == "error" else warnings).append(f"{loc} {msg}：…{snippet}…")

            if not is_table:
                words_total += len(en.split())
                sentences = [s for s in re.split(r"(?<=[.!?])\s+", en.strip()) if s]
                sents_total += len(sentences)
                for sent in sentences:
                    n = len(sent.split())
                    if n > 40:
                        warnings.append(f"{loc} 单句 {n} 词，建议拆分：{sent[:70]}…")

            if zh and glossary:
                for h in check_terms(zh, en, glossary):
                    hints.append(f"{loc} {h}｜{en.strip()[:50]}")

    total_modal = should + must + shall
    if total_modal and must / total_modal > 0.15:
        warnings.append(f"must 占情态动词 {must / total_modal:.0%}（Q7 为 0.4%），"
                        f"请复核是否把管理要求写成了法定强制")

    print("=" * 66)
    print(f"块数 {n_blocks}｜缺译文 {n_missing}｜should {should}｜must {must}｜shall {shall}")
    if words_total:
        print(f"英文正文 {words_total} 词 / 约 {sents_total} 句，平均句长 {words_total / max(sents_total, 1):.1f} 词")
    print("=" * 66)

    def dump(title, items, limit=None):
        if not items:
            return
        print(f"\n{title}（{len(items)}）")
        for i, it in enumerate(items[:limit] if limit else items, 1):
            print(f"  {i}. {it}")
        if limit and len(items) > limit:
            print(f"  … 另有 {len(items) - limit} 条")

    dump("[错误]", errors)
    dump("[警告]", warnings)
    dump("[提示] 术语复核", hints, args.max_term_hints)

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
