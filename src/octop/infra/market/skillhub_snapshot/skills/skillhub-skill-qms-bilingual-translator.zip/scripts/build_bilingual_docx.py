#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把双语 JSONL 渲染成排版规范的 Word 文档（一段中文 + 一段英文）。

用法:
    python build_bilingual_docx.py 输出文件名.docx part1.jsonl [part2.jsonl ...]

输出位置固定为 E:\\QMS管理文件\\QMS_中英双语（可用 --outdir 改），
只传文件名即可，传入的目录部分会被忽略，以保证所有交付文件集中存放。

JSONL 每行一个块（缺 en 视为未翻译，会告警并在文中留空）:
    {"type":"title","zh":"质量风险管理规程","en":"Quality Risk Management Procedure"}
    {"type":"h1","zh":"1 目的","en":"1 Purpose"}
    {"type":"para","zh":"……","en":"……"}
    {"type":"li","zh":"……","en":"……","level":1}
    {"type":"table","rows":[[{"zh":"序号","en":"No."},{"zh":"步骤","en":"Step"}], ...]}
表格也接受简写: rows 中每格为 "中文||English" 字符串。

排版: A4；标题小二黑体居中；一级标题四号黑体；正文五号宋体、首行缩进 2 字符；
英文用 Times New Roman 同字号紧随其后；表格单元格内中英上下两行。
"""
import argparse
import json
import os
import sys

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ZH_FONT = "宋体"
ZH_HEI = "黑体"
EN_FONT = "Times New Roman"

def _default_outdir():
    """优先级：环境变量 > E:\\QMS管理文件\\QMS_中英双语（存在 E 盘时）> ~/Documents/QMS_中英双语。

    这样本机固定落在 E 盘，换到没有 E 盘的用户机器也不会报错。
    """
    env = os.environ.get("QMS_BILINGUAL_OUTDIR")
    if env:
        return env
    preferred = r"E:\QMS管理文件\QMS_中英双语"
    if os.path.isdir("E:\\"):
        return preferred
    return os.path.join(os.path.expanduser("~"), "Documents", "QMS_中英双语")


# 所有交付文件统一存放目录
DEFAULT_OUTDIR = _default_outdir()

SIZE_TITLE_ZH = 18
SIZE_TITLE_EN = 13
SIZE_H1_ZH = 14
SIZE_H1_EN = 12
SIZE_H2_ZH = 12
SIZE_H2_EN = 11
SIZE_H3_ZH = 10.5
SIZE_H3_EN = 10.5
SIZE_BODY = 10.5
SIZE_TABLE = 9


def set_run(run, zh_font, en_font, size, bold=False, color=None, italic=False):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = en_font
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:ascii"), en_font)
    rFonts.set(qn("w:hAnsi"), en_font)
    rFonts.set(qn("w:eastAsia"), zh_font)
    rFonts.set(qn("w:cs"), en_font)
    if color:
        run.font.color.rgb = RGBColor(*color)


def first_line_chars(p, chars=2, size=SIZE_BODY):
    """设置首行缩进 N 个字符（同时写 firstLineChars 与 twips 回退值）。"""
    p.paragraph_format.first_line_indent = Pt(size * chars)
    pPr = p._p.get_or_add_pPr()
    ind = pPr.find(qn("w:ind"))
    if ind is None:
        ind = OxmlElement("w:ind")
        pPr.append(ind)
    ind.set(qn("w:firstLineChars"), str(chars * 100))
    ind.set(qn("w:firstLine"), str(int(size * chars * 20)))


def add_bottom_border(p, sz=8, color="808080"):
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(sz))
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color)
    pbdr.append(bottom)
    pPr.append(pbdr)


def keep_with_next(p):
    p.paragraph_format.keep_with_next = True


def add_page_number(paragraph):
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_end)
    set_run(run, ZH_FONT, EN_FONT, 9)


def shade(cell, fill="F2F2F2"):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell_margins(table, left=80, right=80, top=40, bottom=40):
    tblPr = table._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for tag, val in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        el = OxmlElement(f"w:{tag}")
        el.set(qn("w:w"), str(val))
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)


def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def cell_parts(cell_data):
    if isinstance(cell_data, dict):
        return str(cell_data.get("zh", "") or ""), str(cell_data.get("en", "") or "")
    text = str(cell_data or "")
    if "||" in text:
        z, e = text.split("||", 1)
        return z.strip(), e.strip()
    return text, ""


class Builder:
    def __init__(self, doc, line_spacing=1.25):
        self.doc = doc
        self.line_spacing = line_spacing
        self.missing_en = 0
        self.counts = {}
        self.title_zh = ""
        self.title_en = ""
        self._setup()

    def _setup(self):
        doc = self.doc
        sec = doc.sections[0]
        sec.page_width = Cm(21.0)
        sec.page_height = Cm(29.7)
        sec.top_margin = Cm(2.54)
        sec.bottom_margin = Cm(2.54)
        sec.left_margin = Cm(2.6)
        sec.right_margin = Cm(2.6)

        normal = doc.styles["Normal"]
        normal.font.name = EN_FONT
        normal.font.size = Pt(SIZE_BODY)
        normal.element.rPr.rFonts.set(qn("w:eastAsia"), ZH_FONT)
        pf = normal.paragraph_format
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
        pf.line_spacing = self.line_spacing
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)

        self.content_width_cm = sec.page_width.cm - sec.left_margin.cm - sec.right_margin.cm

    # ---------- 文本块 ----------
    def _para(self, text, zh_font, en_font, size, bold=False,
              align=WD_ALIGN_PARAGRAPH.LEFT, before=0, after=0,
              indent_chars=0, left_indent=None, hanging=None):
        p = self.doc.add_paragraph()
        p.alignment = align
        p.paragraph_format.space_before = Pt(before)
        p.paragraph_format.space_after = Pt(after)
        p.paragraph_format.line_spacing = self.line_spacing
        if left_indent is not None:
            p.paragraph_format.left_indent = Cm(left_indent)
        if hanging is not None:
            p.paragraph_format.first_line_indent = Cm(-hanging)
        if indent_chars:
            first_line_chars(p, indent_chars, size)
        if text:
            run = p.add_run(text)
            set_run(run, zh_font, en_font, size, bold=bold)
        return p

    def block(self, b):
        btype = b.get("type", "para")
        self.counts[btype] = self.counts.get(btype, 0) + 1
        zh = (b.get("zh") or "").strip()
        en = (b.get("en") or "").strip()

        if btype == "table":
            self.table(b)
            return

        if not zh and not en:
            return
        if zh and not en:
            self.missing_en += 1

        if btype == "title":
            self.title_zh = self.title_zh or zh
            self.title_en = self.title_en or en
            p = self._para(zh, ZH_HEI, EN_FONT, SIZE_TITLE_ZH, bold=True,
                           align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=6)
            keep_with_next(p)
            p2 = self._para(en, ZH_HEI, EN_FONT, SIZE_TITLE_EN, bold=True,
                            align=WD_ALIGN_PARAGRAPH.CENTER, before=0, after=16)
            add_bottom_border(p2)
            return

        if btype in ("h1", "h2", "h3"):
            conf = {
                "h1": (SIZE_H1_ZH, SIZE_H1_EN, 14, 4, 10),
                "h2": (SIZE_H2_ZH, SIZE_H2_EN, 11, 3, 8),
                "h3": (SIZE_H3_ZH, SIZE_H3_EN, 9, 2, 6),
            }[btype]
            zs, es, before, after_in, after_out = conf
            p = self._para(zh, ZH_HEI, EN_FONT, zs, bold=True, before=before, after=after_in)
            keep_with_next(p)
            p2 = self._para(en, ZH_HEI, EN_FONT, es, bold=True, before=0, after=after_out)
            keep_with_next(p2)
            return

        if btype == "li":
            level = int(b.get("level", 1) or 1)
            indent = 0.74 * (level - 1) + 0.74
            self._para(f"－\t{zh}" if zh else "", ZH_FONT, EN_FONT, SIZE_BODY,
                       align=WD_ALIGN_PARAGRAPH.JUSTIFY, after=0,
                       left_indent=indent, hanging=0.74)
            if en:
                self._para(f"－\t{en}" if en else "", ZH_FONT, EN_FONT, SIZE_BODY,
                           align=WD_ALIGN_PARAGRAPH.JUSTIFY, after=8,
                           left_indent=indent, hanging=0.74)
            return

        # 普通正文：中英各一段
        self._para(zh, ZH_FONT, EN_FONT, SIZE_BODY, align=WD_ALIGN_PARAGRAPH.JUSTIFY,
                   after=0, indent_chars=2)
        if en:
            self._para(en, ZH_FONT, EN_FONT, SIZE_BODY, align=WD_ALIGN_PARAGRAPH.JUSTIFY,
                       after=8)

    # ---------- 表格 ----------
    def table(self, b):
        rows = b.get("rows") or []
        rows = [r for r in rows if any(str(c) for c in r)]
        if not rows:
            return
        ncols = max(len(r) for r in rows)
        table = self.doc.add_table(rows=0, cols=ncols)
        table.style = "Table Grid"
        table.autofit = False
        set_cell_margins(table)

        # 列宽：按各列最长文本估算，最小 1.5cm
        weights = []
        for c in range(ncols):
            lens = []
            for r in rows:
                if c < len(r):
                    z, e = cell_parts(r[c])
                    lens.append(max(len(z) * 2, len(e)))
            weights.append(max(min(max(lens or [4]), 40), 3))
        total = sum(weights)
        avail = self.content_width_cm - 0.2 * ncols
        widths = [max(avail * w / total, 1.5) for w in weights]
        scale = avail / sum(widths)
        widths = [w * scale for w in widths]
        for ci in range(ncols):
            table.columns[ci].width = Cm(widths[ci])

        for ri, row in enumerate(rows):
            cells = table.add_row().cells
            for ci in range(ncols):
                data = row[ci] if ci < len(row) else ""
                zh, en = cell_parts(data)
                cell = cells[ci]
                cell.width = Cm(widths[ci])
                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                p = cell.paragraphs[0]
                p.paragraph_format.line_spacing = 1.05
                p.paragraph_format.space_after = Pt(0)
                if zh:
                    set_run(p.add_run(zh), ZH_FONT, EN_FONT, SIZE_TABLE, bold=(ri == 0))
                if en:
                    p2 = cell.add_paragraph()
                    p2.paragraph_format.line_spacing = 1.05
                    p2.paragraph_format.space_before = Pt(0)
                    p2.paragraph_format.space_after = Pt(0)
                    set_run(p2.add_run(en), ZH_FONT, EN_FONT, SIZE_TABLE,
                            bold=(ri == 0), color=(0x44, 0x44, 0x44))
                if ri == 0:
                    shade(cell, "E8E8E8")
            if ri == 0:
                repeat_header(table.rows[0])
        # 表后留白
        self.doc.add_paragraph().paragraph_format.space_after = Pt(6)

    # ---------- 页眉页脚 ----------
    def finish(self):
        sec = self.doc.sections[0]
        header = sec.header
        hp = header.paragraphs[0]
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        txt = " / ".join(x for x in (self.title_zh, self.title_en) if x)
        if txt:
            set_run(hp.add_run(txt), ZH_FONT, EN_FONT, 8, color=(0x66, 0x66, 0x66))
            add_bottom_border(hp, sz=4, color="BFBFBF")

        footer = sec.footer
        fp = footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        add_page_number(fp)


def load_blocks(paths):
    blocks = []
    for path in paths:
        with open(path, "r", encoding="utf-8") as f:
            for lineno, line in enumerate(f, 1):
                line = line.strip()
                if not line or line.startswith("//"):
                    continue
                try:
                    blocks.append(json.loads(line))
                except json.JSONDecodeError as e:
                    raise SystemExit(f"[JSON 错误] {path}:{lineno} {e}\n  {line[:120]}")
    return blocks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("output", help="输出文件名（只写文件名即可，统一存入 --outdir；也可给完整路径）")
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("--outdir", default=DEFAULT_OUTDIR,
                    help=f"统一输出目录，默认 {DEFAULT_OUTDIR}")
    ap.add_argument("--line-spacing", type=float, default=1.25)
    ap.add_argument("--core-title", default=None)
    ap.add_argument("--force", action="store_true", help="目标文件已存在时允许覆盖（默认拒绝）")
    args = ap.parse_args()

    blocks = load_blocks(args.inputs)
    if not blocks:
        raise SystemExit("没有可渲染的内容")

    doc = Document()
    b = Builder(doc, line_spacing=args.line_spacing)
    for blk in blocks:
        b.block(blk)
    b.finish()

    doc.core_properties.title = args.core_title or b.title_zh or "QMS Bilingual Document"
    doc.core_properties.comments = "Bilingual (Chinese-English) rendering based on ICH Q7 terminology."

    # 统一存放：只取文件名，落到固定输出目录
    name = os.path.basename(args.output.strip())
    if not name.lower().endswith(".docx"):
        name += ".docx"
    os.makedirs(args.outdir, exist_ok=True)
    out_path = os.path.join(args.outdir, name)
    if os.path.abspath(out_path) != os.path.abspath(args.output):
        print(f"[目录] 统一输出到 {args.outdir}")
    if os.path.exists(out_path) and not args.force:
        raise SystemExit(f"[停止] 目标文件已存在：{out_path}\n"
                         f"       确认覆盖请加 --force；保留旧版请改用带日期/版本号的文件名。")
    doc.save(out_path)

    print(f"[OK] 已生成 {out_path}")
    print("[统计] " + ", ".join(f"{k}:{v}" for k, v in sorted(b.counts.items())))
    if b.missing_en:
        print(f"[警告] 有 {b.missing_en} 个块缺少英文译文（输出中仅保留中文）")


if __name__ == "__main__":
    sys.exit(main())
