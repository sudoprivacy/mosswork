# ICH Q7 术语对照表（中文 → 英文）

本表是制药企业 QMS 文件中译英的**强制用词依据**。翻译时必须逐条对照，不得自行更换同义词。

- 来源：ICH Q7《Good Manufacturing Practice Guide for Active Pharmaceutical Ingredients》（Step 4, 10 November 2000）第 20 章 Glossary 及各章节正文用词。
- 标 ⚠ 的词条存在易错点，见"备注"列。
- 表中未收录的词，先在全文中检索（`references/q7-full-text.txt`），仍无对应再按 Q7 构词习惯新造，并在交付说明中列出新增术语。

---

## 1. 质量体系与组织

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 质量管理 | quality management | |
| 质量管理体系 | quality management system | |
| 质量保证 | Quality Assurance (QA) | 首次出现给全称，后文用 QA |
| 质量控制 | Quality Control (QC) | |
| 质量单位 / 质量部门 | **quality unit(s)** | ⚠ Q7 固定用 quality unit(s)，不得写 quality department / QA department。单复数随原文，常保留括号形式 |
| 独立的质量单位 | independent quality unit(s) | |
| 药品生产质量管理规范 | Good Manufacturing Practice (GMP) | |
| 现行药品生产质量管理规范 | current Good Manufacturing Practice (cGMP) | Q7：cGMP 与 GMP 等效 |
| 质量方针 | quality policy | |
| 质量手册 | quality manual | |
| 质量风险管理 | quality risk management | |
| 产品质量回顾 | Product Quality Review (PQR) | ⚠ Q7 §2.5 章节名；正文亦作 regular quality reviews of APIs |
| 年度质量回顾 | annual product quality review | |
| 内部审计（自检） | internal audit (self inspection) | ⚠ Q7 标题写法：Internal Audits (Self Inspection) |
| 纠正措施 | corrective action | |
| 预防措施 | preventive action | |
| 纠正和预防措施 | corrective and preventive action (CAPA) | Q7 无 CAPA 缩写，现代 QMS 文件可用；Q7 语境优先展开写 |
| 持续改进 | continual improvement | |
| 管理评审 | management review | |
| 组织架构 | organisational structure | Q7 §2.12 原文拼写为 organisational |
| 职责 | responsibility | |
| 权限 / 授权 | authorization | 动词 authorised / authorized 见拼写规则 |
| 偏差 | deviation | |
| 关键偏差 | critical deviation | |
| 变更 | change | |
| 变更控制 | change control | |
| 不符合 | non-conformance | |
| 超标结果 | out-of-specification (OOS) result | ⚠ Q7 连字符写法：out-of-specification |
| 投诉 | complaint | |
| 召回 | recall | |
| 退货 | returns | |
| 法规检查 / 监督检查 | regulatory inspection | |
| 注册 / 申报 | registration / filing | |
| 药典 | pharmacopoeia | 形容词 compendial |
| 药典方法 | compendial method | |

---

## 2. 物料与产品

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 物料 | material | Q7 定义为总称：raw materials、process aids、intermediates、APIs、packaging and labelling materials |
| 原料 / 原材料 | raw material | Q7：starting materials、reagents、solvents 的总称 |
| 起始物料 | starting material | |
| 原料药起始物料 | API starting material | ⚠ 专有名词，首字母大写 A/P/I/S/M；不得译成 API starting raw material |
| 原料药 / 活性药物成分 | Active Pharmaceutical Ingredient (API) | 同义：drug substance；Q7 主用 API |
| 药用物质 | drug substance | 见上 |
| 中间体 | intermediate | ⚠ 不得译 mid-product / intermediate product |
| 成品 / 制剂 | drug (medicinal) product | ⚠ Q7 固定写法带括号：drug (medicinal) product |
| 辅料 | excipient | Q7 未定义，制剂语境使用 |
| 包装材料 | packaging material | |
| 标签 / 标签材料 | labelling materials；单张标签为 label | ⚠ 材料用 labelling materials，实物用 label |
| 印刷包装材料 | printed packaging materials | |
| 工艺助剂 | process aids | ⚠ 不译 processing auxiliary |
| 溶剂 | solvent | |
| 试剂 | reagent | |
| 母液 | mother liquor | |
| 回收溶剂 | recovered solvents | |
| 纯化水 | purified water | |
| 注射用水 | Water for Injection (WFI) | |
| 饮用水 | potable water | |
| 工艺用水 | process water | |
| 杂质 | impurity | |
| 杂质谱 | impurity profile | |
| 降解产物 | degradation product | |
| 残留物 | residue | |
| 生物负载 | bioburden | ⚠ 一个词，不写 bio-burden |
| 污染 | contamination | |
| 交叉污染 | cross-contamination | |
| 混淆 / 混药 | mix-up | ⚠ 不译 confusion |
| 异物 | foreign matter | |
| 洁净度 | cleanliness | |

---

## 3. 批与标识

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 批 | batch (or lot) | Q7 定义条目写作 Batch (or Lot)，正文统一用 batch |
| 批号 | batch number (or lot number) | |
| 批量 | batch size | |
| 批记录 | batch production record | Q7 全称 batch production and control records |
| 批生产记录 | Batch Production Record | |
| 批生产与控制记录 | batch production and control records | |
| 主生产指令 | master production instructions | ⚠ Q7 用 master production instructions，括注 master production and control records；不写 master batch record |
| 主记录 | master record | 非 Q7 用词，仅当原文即"主记录"时用 |
| 有效日期 / 有效期 | expiry date (or expiration date) | ⚠ 不写 validity date |
| 复验期 | retest date | |
| 贮存期 / 货架期 | shelf life | |
| 生产日期 | date of manufacture | |
| 状态标识 | status labelling | |
| 待检 | quarantine | 见下 |
| 隔离 / 待检状态 | quarantine | ⚠ 既指物理隔离也指状态；动词 quarantined |
| 放行 | release | |
| 拒收 | reject / rejection | |
| 合格 | approved；符合标准 conform to specifications | |
| 不合格 | rejected；不符合标准 not conform to specifications | |

---

## 4. 厂房、设施与设备

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 厂房 | premises；buildings and facilities | ⚠ Q7 §4.1 标题 Design and Construction，正文用 buildings and facilities |
| 设施 | facility / facilities | |
| 公用工程 | utilities | |
| 专用生产区 | dedicated production area | |
| 密闭系统 | closed system | |
| 密闭或受控设备 | closed or contained equipment | |
| 气流 | air flow | |
| 空气过滤 | air filtration | |
| 送风 / 回风 | supply air / return air | |
| 排风 | exhaust | |
| 压差 | differential pressure | |
| 气锁 | air lock | |
| 管道 | pipework | ⚠ Q7 用 pipework 指管路系统，单根管子 pipe |
| 排水口 | drain | |
| 空气阻断 | air break | ⚠ 非 air gap（air gap 为 EU 用法） |
| 照明 | lighting | |
| 污水与废弃物 | sewage and refuse | |
| 卫生与维护 | sanitation and maintenance | |
| 清洁 | cleaning | |
| 消毒 | sanitization；disinfection | Q7 多用 sanitization |
| 灭菌 | sterilization | |
| 设备 | equipment | |
| 主要设备 | major equipment | |
| 非专用设备 | non-dedicated equipment | |
| 器具 | utensils | |
| 校准 | calibration | |
| 可追溯标准 | traceable standard | |
| 计算机化系统 | computerized system | ⚠ 区别于 computer system（硬件+软件组合）；Q7 两者都定义，指"与计算机系统集成的工艺或操作"时用 computerized system |
| 计算机系统 | computer system | |
| 审计追踪 | audit trail | Q7 无此条，数据完整性文件用 |
| 数据完整性 | data integrity | 现代概念，Q7 无 |

---

## 5. 生产与控制

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 生产 | production；制造 manufacture / manufacturing | ⚠ manufacturing 涵盖收货到发运全过程（Q7 §1.1 定义），指车间制造操作时用 production |
| 生产工艺 | manufacturing process | |
| 工序 / 工艺步骤 | process step | |
| 关键工艺步骤 | critical process step | |
| 关键工艺参数 | critical process parameters | |
| 关键质量属性 | critical quality attributes | |
| 中间控制 / 过程控制 | in-process control (or process control) | ⚠ 不写 in-process testing |
| 中间控制点 | in-process control point | |
| 收率 | yield | |
| 实际收率 | actual yield | |
| 预期收率 | expected yield | |
| 称量 | weighing | |
| 分装 / 分料 | subdividing | Q7 §8.11：material is subdivided |
| 混合（批间） | blending | ⚠ §8.4 定义为 combining batches；与 mixing（工艺混合）区分 |
| 返工 | reworking | ⚠ 用非既定工艺处理不合格品 |
| 重新加工 / 再加工 | reprocessing | ⚠ 用既定工艺重复处理 |
| 回收 | recovery | |
| 时限 | time limits | |
| 连续生产 | continuous production | |
| 周期生产 / 阶段生产 | campaign production | |
| 包装 | packaging | |
| 重新包装 | repackaging | |
| 贴签 | labelling | |
| 重新贴签 | relabelling | |
| 标签发放与平衡 | label issuance and reconciliation | |
| 标签平衡 | label reconciliation | |
| 贮存 | storage | |
| 仓储 | warehousing | |
| 发运 / 分销 | distribution | |
| 运输 | transport | |
| 物流 | shipment | |

---

## 6. 实验室控制

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 实验室控制 | laboratory controls | |
| 检验 | testing | ⚠ 不写 inspection（inspection 指检查/视察） |
| 取样 | sampling | |
| 留样 | reserve sample；retention sample | ⚠ Q7 §11.7 标题 Reserve/Retention Samples，正文用 reserve samples |
| 对照品 | reference standard | |
| 一级对照品 | primary reference standard | |
| 二级对照品 | secondary reference standard | |
| 标准品 | reference standard | 与对照品同译，靠修饰语区分 |
| 标准溶液 | standard solution | |
| 检验方法 | test method；analytical method | Q7 analytical method 指分析方法 |
| 分析方法验证 | validation of analytical procedures | Q7 §11.3 原文用 procedures |
| 质量标准 | specification | ⚠ 不写 quality standard |
| 接受标准 / 可接受标准 | acceptance criteria | ⚠ 不写 acceptable criteria |
| 检验报告 / 检验报告书 | Certificate of Analysis (CoA) | Q7 §11.4 标题 Certificates of Analysis |
| 稳定性考察 | stability monitoring | Q7 §11.5 Stability Monitoring of APIs |
| 稳定性试验 | stability testing | |
| 持续稳定性考察 | on-going stability program | Q7：on-going testing program |
| 长期试验 | long-term testing | |
| 加速试验 | accelerated testing | |
| 影响因素试验 | stress testing | |
| 含量 | assay | |
| 有关物质 | related substances | |
| 干燥失重 | loss on drying | |
| 炽灼残渣 | residue on ignition | |
| 重金属 | heavy metals | |
| 微生物限度 | microbial limits | |
| 无菌 | sterility / sterile | |
| 细菌内毒素 | bacterial endotoxins | |
| 热原 | pyrogens | |

---

## 7. 验证与确认

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 验证 | validation | |
| 确认 | qualification | ⚠ 不得把"确认"译成 confirmation；DQ/IQ/OQ/PQ 用 qualification |
| 设计确认 | Design Qualification (DQ) | |
| 安装确认 | Installation Qualification (IQ) | |
| 运行确认 | Operational Qualification (OQ) | |
| 性能确认 | Performance Qualification (PQ) | |
| 工艺验证 | process validation | |
| 清洁验证 | cleaning validation | |
| 再验证 | revalidation | |
| 同步验证 | concurrent validation | |
| 前瞻性验证 | prospective validation | |
| 回顾性验证 | retrospective validation | |
| 验证方案 | validation protocol | ⚠ 不写 validation plan |
| 验证报告 | validation report | |
| 已验证系统 | validated system | |
| 定期回顾 | periodic review | |
| 最差条件 | worst case | |
| 擦拭取样 | swabbing | |
| 淋洗取样 | rinsing | |

---

## 8. 机构与人员

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 人员 | personnel | ⚠ 不写 staff / employee（出现在要求句时） |
| 资质 | qualification | 人员资质用 qualifications |
| 培训 | training | |
| 岗位职责 | job responsibilities | |
| 健康检查 | health examination | |
| 卫生习惯 | sanitation and health habits | Q7 §3.20 原文 |
| 工作服 | clothing；gowning | 更衣 gowning / gown |
| 传染病 | infectious disease | |
| 开放性创口 | open lesions | Q7 §3.24 原文 |
| 顾问 | consultant | |
| 质量受权人 | quality authorized person | ⚠ 中国 GMP 概念。出口欧盟语境可用 Qualified Person (QP)；同一文件内统一，首次出现加括注 |

---

## 9. 委托与供应链

| 中文 | 英文（Q7 用词） | 备注 |
|---|---|---|
| 委托生产 / 合同生产 | contract manufacturing | |
| 委托方 | contract giver | ⚠ Q7 §16 固定用词 |
| 受托方 / 合同生产商 | contract acceptor (contractor) | ⚠ Q7 写作 contract acceptor (contractor) |
| 质量协议 | quality agreement | Q7 用 contract or formal agreement；现代文件用 quality agreement |
| 供应商 | supplier | |
| 供应商审计 | supplier audit | |
| 供应商确认 | supplier approval | Q7 §7.31 Supplier approval |
| 供应商变更 | change of supplier | |
| 来源变更 | change of source of supply | Q7 §7.14 |
| 中间商 / 代理商 | agent | Q7 §17 |
| 经纪人 | broker | |
| 贸易商 | trader | |
| 经销商 / 分销商 | distributor | |
| 分包装商 | repacker | |
| 换签商 | relabeller | |
| 可追溯性 | traceability | |
| 承运人 | shipper / carrier | |

---

## 10. QMS 文件标准章节名（固定译法）

| 中文 | 英文 | 备注 |
|---|---|---|
| 目的 | Purpose | 章节名，仅用于标题 |
| 范围 | Scope | 章节名，仅用于标题 |
| 职责 | Responsibilities | 章节名，仅用于标题 |
| 定义 / 术语和定义 | Definitions | 章节名，仅用于标题 |
| 程序 / 内容 | Procedure | 章节名，仅用于标题 |
| 相关文件 | Related Documents | 章节名，仅用于标题 |
| 参考文件 | References | 章节名，仅用于标题 |
| 附件 / 附录 | Appendix / Attachment | 章节名，仅用于标题 |
| 变更历史 / 修订记录 | Document History / Revision History | 章节名，仅用于标题 |
| 起草 | Prepared by | 章节名，仅用于标题 |
| 审核 | Reviewed by | 章节名，仅用于标题 |
| 批准 | Approved by | 章节名，仅用于标题 |
| 生效日期 | Effective Date | 章节名，仅用于标题 |
| 复审日期 | Review Date | 章节名，仅用于标题 |
| 文件编号 | Document Number | 章节名，仅用于标题 |
| 版本号 | Version / Revision Number | 章节名，仅用于标题 |
| 页码 | Page | 章节名，仅用于标题 |
| 分发 | Distribution | 章节名，仅用于标题 |
| 受控文件 | controlled document | |
| 受控副本 | controlled copy | |
| 非受控副本 | uncontrolled copy | |
| 作废 | obsolete；withdrawn | |
| 替代 | superseded | |
| 发放 | issuance | |
| 归档 | archiving | 动词 archive |
| 保存期限 | retention period | 章节名，仅用于标题 |
| 真实副本 | true copy | |
| 原始记录 | original record | |
| 签名 | signature；signed | 动词 should be signed |
| 电子签名 | electronic signature | |
| 手写签名 | handwritten signature | |
| 缩写 / 首字母 | initials | |
