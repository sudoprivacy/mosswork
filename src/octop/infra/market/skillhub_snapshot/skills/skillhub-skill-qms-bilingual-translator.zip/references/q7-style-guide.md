# Q7 英译风格规范

本文件规定把中文 QMS 文件译成英文时的句法、语气、拼写与格式规则。所有规则的依据是 ICH Q7 原文的实测用词分布，不做个人风格发挥。

配合 `q7-glossary.md`（用词）与 `q7-full-text.txt`（原文检索）使用。

---

## 1. 语域与主语

Q7 是给生产商看的规范性指南，通篇陈述"谁应当做什么"，不使用第一人称、不使用口语、不使用 shall。

| 中文 | 英文 |
|---|---|
| 本公司 / 公司 / 工厂 | the manufacturer；谈组织内部单位时用 the company |
| 本规程 / 本文件 | this procedure / this document |
| 各部门 | 各具体单位：the production unit、the quality unit(s) |
| 相关人员 | 具名到角色：appropriate personnel、responsible management |

规则：

- 表述要求时**优先用被动 + should**：`Written procedures should be established for ...`。这既贴合 Q7，也避免"谁来执行"的歧义。
- 只有明确指向主体时才写主语：`The manufacturer should ensure that ...`、`The quality unit(s) should review and approve ...`。
- 不用 we / our / you / the company must。

---

## 2. 情态动词（最关键的合规差异）

Q7 全文 `should` 出现 494 次，`must` 仅 2 次，`shall` 0 次，`can` 61 次、`may` 34 次。据此定映射：

| 中文 | 英文 | 说明 |
|---|---|---|
| 应 / 应当 / 应该 | **should** | 默认。GMP 要求一律用 should |
| 必须 / 须 | **must** | ⚠ 仅用于法定强制义务或引用法规原文（例：注册文件中的承诺必须履行 → All commitments in registration/filing documents must be met.）。中文写"必须"但实为管理要求时，仍译 should |
| 不得 / 禁止 | should not；法规禁止用 must not | |
| 可 / 可以 / 允许 | can（许可、能力）；may（授权、可能性） | Q7 中 can 更常用 |
| 宜 / 建议 / 最好 | should | 不译 it is recommended to |
| 需要 / 需 | 视语境：要求 → should；客观需要 → is required / necessary | 不滥用 need to |

⚠ 绝不使用 **shall**（Q7 零使用，且属合同语域，检查官视为语域错误）。
⚠ 不把 should 升级成 must，也不把 should 降级成 can——这是中译英最常见的两个合规性错误。

---

## 3. 句式模板（中文 → Q7 标准译法）

### 3.1 建立文件类

| 中文 | 英文 |
|---|---|
| 应建立……的书面程序 | Written procedures should be established for ... |
| 应制定……规程并遵照执行 | Procedures should be established and followed for ... |
| 应建立并维护…… | A system should be established and maintained for ... |
| 应有书面程序规定…… | There should be written procedures describing ... |
| ……应有文件规定 | ... should be documented |
| 应编制……清单 | A list of ... should be prepared |

### 3.2 确保与符合类

| 中文 | 英文 |
|---|---|
| 应确保…… | It should be ensured that ...；主语明确时 The manufacturer should ensure that ... |
| 确保……得以…… | ensure that ... is/are ...（去掉"得以"） |
| 应符合……要求 | should meet the requirements of ...；符合标准 conform to specifications |
| 应与……一致 | should be consistent with ... |
| 应按……执行 | should be performed in accordance with ... |
| 参照……执行 | in accordance with ...（Q7 中 in accordance with 与 according to 各 10 次，均可，同一文件内保持一致） |

### 3.3 记录与签署类

| 中文 | 英文 |
|---|---|
| 应记录 / 应有记录 | Records should be maintained / should be kept |
| 应及时记录 | should be recorded at the time they are performed（Q7 §2.15 原句） |
| 记录应保存……年 | Records should be retained for ... years |
| 应签名并注明日期 | should be signed and dated |
| 更正应注明日期、签名，并使原记录清晰可辨 | Corrections should be dated and signed and leave the original entry still readable. |
| 应可追溯 | ... should be traceable |

### 3.4 审批与职责类

| 中文 | 英文 |
|---|---|
| 由……起草 | prepared by ... |
| 经……审核、批准 | reviewed and approved by ... |
| ……负责…… | ... is responsible for ... |
| 职责包括但不限于 | responsibilities include but are not necessarily limited to ... |
| 不得委托他人 | should not be delegated |

### 3.5 条件与限定类

| 中文 | 英文 |
|---|---|
| 必要时 | where necessary |
| 适当时 | where appropriate |
| 如适用 | if applicable |
| 除非另有规定 / 说明 | unless otherwise specified |
| 除非有正当理由 | unless otherwise justified |
| 至少 | at least |
| 不超过 / 不少于 | not more than / not less than |
| 定期 | at regular intervals；periodically |
| 及时 | in a timely manner |
| 立即 | immediately |
| 逐批 | batch by batch；对每批 for each batch |
| 经批准后 | after approval；仅经批准的 approved |

### 3.6 举例与列举

- 举例一律用 **e.g.,**（Q7 用 43 次，for example 仅 4 次），后接逗号。
- 列举用 **such as**（17 次）；结尾不用 etc. 除非原文明确"等"且不穷尽，此时用 etc.（3 次）。
- 项目符号用短横或编号，与 Q7 一致；英文列表项首字母大写、句末视是否完整句决定是否加句号（完整句加句号，短语不加）。

---

## 4. 术语一致性红线

同一文件内以下词只能有一种译法，禁止为了"读起来顺"换词：

| 必须用 | 禁止使用 |
|---|---|
| quality unit(s) | quality department, QA department, quality division |
| intermediate | mid-product, intermediate product |
| API / Active Pharmaceutical Ingredient | bulk drug, raw medicine, active ingredient（首次定义后） |
| raw material | raw and auxiliary material |
| specification | quality standard, standard（指质量标准时） |
| acceptance criteria | acceptable criteria, acceptance standard |
| validation / qualification | verification / confirmation（"确认"必译 qualification） |
| should | shall, need to, is required to, ought to |
| testing（检验） | inspection（视察/检查） |
| deviation | variance, discrepancy |
| reprocessing / reworking | 二者不得互换，见术语表 |
| labelling | labeling（见拼写规则） |

术语首次出现时补英文全称与缩写：`Active Pharmaceutical Ingredient (API)`，后文统一用 API。

---

## 5. 拼写与标点

Q7 为协调文本，拼写混用；按下列实测多数形式统一：

| 采用 | 不用 | 依据 |
|---|---|---|
| organization, authorized, minimize, crystallization, recognize | organisation, authorised, minimise, crystallisation, recognise | Q7 中 -ize/-ization 占多数（organization 6:2，authorized 8:5，minimize 8:1） |
| labelling, labelled, relabelling, relabeller, unlabelled | labeling, labeled | Q7 中 labelling 30 次，labeling 0 次 |
| labeling 仅当原文为美式受控模板时 | — | 特殊情况下全文统一即可，不得逐句摇摆 |
| program | programme | Q7 中 program 9 次 |
| fiber, liter | fibre, litre | 依 Q7 |

标点与数字：

- 英文段落使用英文标点（半角逗号、句号、括号、冒号），数字与单位间加空格：`25 °C`、`5 kg`、`70 %`（Q7 原文多为 `70%`，同一文件统一即可，推荐 `70%` 无空格）。
- 中文段落使用全角标点。中英混排时不出现全角标点被带到英文段的情况。
- 范围号：英文用 `to` 或短横，`2–8 °C` 用短横线（en dash）。
- 编号沿用原文层级：`1`、`1.1`、`1.1.1`；英文标题后不加标点。

---

## 6. 中文公文套话的处理

中文 QMS 文件大量出现虚动词与四字套话，直译会产出不地道的英文。处理规则：

| 中文 | 处理 |
|---|---|
| 进行 / 予以 / 加以 + 动词 | 直接删除虚动词，用实义动词：进行检验 → test；予以销毁 → destroy |
| 对……进行…… | 改为直接动宾：对设备进行清洁 → clean the equipment |
| 严格 / 切实 / 认真 / 有效地 | 删除，或落为具体标准（thoroughly 仅在确有必要时） |
| ……性（可行性、完整性、准确性） | 视语境改为形容词 + 名词：完整性 → integrity；可行性 → feasibility；准确性 → accuracy |
| 有关 / 相关 / 相应的 | related to / relevant / applicable，能删则删 |
| 确保……得到…… | ensure that ... is ... |
| 严禁 / 一律不得 | should not（法规禁止才用 must not） |
| 原则上 | in principle；如无实质约束可省略 |
| 等 | such as 或 etc.，不得两者同时用（such as ... etc. 为错误搭配） |

⚠ 中文一个句子里连挂 4–5 个分句时，拆成 2–3 个英文句。Q7 单句平均 20 词左右，超过 40 词应拆分。

---

## 7. 长句拆分示例

中文原文：
> 生产过程中产生的偏差应由操作人员立即报告班组长，班组长填写偏差记录并报质量部门审核，质量部门应在 3 个工作日内完成评估，必要时启动纠正和预防措施。

不合格译法（照搬中文语序、混用 quality department）：
> Deviations generated in the production process should be reported by operators to the shift leader immediately, the shift leader fills in the deviation record and reports to the quality department for review, and the quality department should complete the assessment within 3 working days and start CAPA when necessary.

Q7 风格译法（拆句、补主语、用 quality unit(s)、去虚动词）：
> Any deviation occurring during production should be reported immediately by the operator to the shift leader. The shift leader should complete the deviation record and forward it to the quality unit(s) for review. The quality unit(s) should complete the assessment within 3 working days and, where necessary, initiate corrective and preventive actions.

---

## 8. 标题

- 英文标题用 **Title Case**（实词首字母大写，冠词、介词、连词小写，首词与末词大写）：`Reserve/Retention Samples`、`Validation of Analytical Procedures`。
- 章节编号与原中文一一对应，编号在标题前：`7.3 Sampling and Testing of Incoming Production Materials`。
- 不使用中文式冒号收尾，不在标题末尾加句号。
- 标题中的专有名词保持原样：`API Starting Material`、`GMP`、`QA/QC`。

---

## 9. 译文自检清单

逐条过一遍，任何一条不通过都需回改：

1. 每段中文都有对应英文，段序与原文一致，无遗漏、无合并。
2. `should` 占情态动词绝大多数；无 `shall`；`must` 仅出现在法定强制处。
3. 术语与 `q7-glossary.md` 逐条一致；quality unit(s)、intermediate、specification、acceptance criteria 无变体。
4. 拼写统一（-ize/-ization；labelling 双写 l）。
5. 无对……进行……、无虚动词、无"等"与 such as 叠用。
6. 英文段落无中文全角标点、无残留汉字。
7. 单句不超过 40 词；一句只讲一个要求。
8. 首字母缩写首次出现已给全称。
