# -*- coding: utf-8 -*-
"""家政服务合同条款核查（gmai-train-04-796f）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：《家政服务合同条款核查》照护服务方案（含能力评估、逐项核对、人力与工时测算）；服务清单与资质核验表；归档与复用说明（版本留痕 + 更新口径）
建议输入（专业字段）：服务对象情况（年龄/自理能力）；服务内容与频次；规模/量级；预算；现有条件；验收要求
"""
# === HUBFIX 友好错误处理（自动注入，勿删） ===
import sys as _hubfix_sys, os as _hubfix_os


def _hubfix_hook(_t, _v, _tb):
    """把底层异常翻译成用户能看懂的中文提示，并给出下一步动作。"""
    _m = str(_v) or _v.__class__.__name__
    _low = _m.lower()
    if isinstance(_v, FileNotFoundError) or "no such file" in _low:
        print("\n❌ 输入文件不存在：%s" % _m)
        print("   → 请检查文件路径是否正确、文件是否已被移动或删除，然后重新运行。")
    elif isinstance(_v, PermissionError):
        print("\n❌ 文件无访问权限：%s" % _m)
        print("   → 请关闭正在占用该文件的程序（如播放器/编辑器），或换一个有写入权限的输出目录。")
    elif isinstance(_v, ModuleNotFoundError) or "no module named" in _low:
        print("\n❌ 缺少依赖模块：%s" % _m)
        print("   → 请先在技能目录执行：pip install -r requirements.txt")
    elif "ffmpeg" in _low:
        print("\n❌ 未找到 ffmpeg（音视频处理依赖）：%s" % _m)
        print("   → 请先安装 ffmpeg 并把 ffmpeg.exe 所在目录加入系统 PATH，然后重新运行。")
    elif isinstance(_v, (ValueError, KeyError, TypeError)):
        print("\n❌ 输入内容或参数格式不受支持：%s" % _m)
        print("   → 请核对输入文件格式与字段是否符合「输入要求」；不确定时可先用 demo 示例文件试跑。")
    elif isinstance(_v, KeyboardInterrupt):
        print("\n⚠️ 已手动中断，未产生结果文件。")
    else:
        print("\n❌ 运行失败：%s" % _m)
        print("   → 常见原因是输入格式不受支持、依赖缺失或磁盘写入受限；"
              "可加 --help 查看用法，仍失败请附本段提示反馈。")
    _hubfix_sys.exit(2)


_hubfix_sys.excepthook = _hubfix_hook


def _hubfix_argerr(_self, _msg):
    """把 argparse 的英文用法报错也翻译成中文提示。"""
    print("\n❌ 参数有误：%s" % _msg)
    print("   → 请按上方用法（usage）补齐参数；不确定时执行 --help 查看全部参数说明。")
    _hubfix_sys.exit(2)


try:
    import argparse as _hubfix_argparse
    _hubfix_argparse.ArgumentParser.error = _hubfix_argerr
except Exception:
    pass
# === HUBFIX 友好错误处理结束 ===

import json, os, re, sys, time

SLUG = "gmai-train-04-796f"
TITLE = "家政服务合同条款核查"
PRICE_FEN = 1490
CATEGORY = "家政与养老服务"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['服务对象情况（年龄/自理能力）', True, ['服务对象', '老人情况', '被照护人'], '对象能力等级决定照护方案与人力配置'], ['服务内容与频次', True, ['服务项目', '照护内容', '频次'], '内容与频次决定工时与报价'], ['规模/量级', False, ['人数', '户数', '服务量'], '规模影响排班与成本'], ['预算', False, ['费用上限', '预算'], '用于性价比评估'], ['现有条件', False, ['现有环境', '家庭条件'], '居住环境决定可执行性'], ['验收要求', False, ['验收标准', '服务标准'], '决定验收口径']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'dims': ['需求匹配', '落地成本', '安全可控', '可持续', '风险'], 'options': [['方案 A：钟点/白班制', '按小时或白班派单，成本最低，适合半自理与家务型需求', {'需求匹配': 4, '落地成本': 5, '安全可控': 3, '可持续': 4, '风险': 3}], ['方案 B：住家全天照护', '住家护理员全天在岗，适合失能或需夜间照护', {'需求匹配': 5, '落地成本': 3, '安全可控': 4, '可持续': 4, '风险': 4}], ['方案 C：机构/社区托养', '日间照料中心或机构托养，专业度高、家庭负担低', {'需求匹配': 5, '落地成本': 2, '安全可控': 5, '可持续': 5, '风险': 3}]]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['GB/T 35796-2018《居家养老服务规范》：规定服务内容、流程与质量要求', '《家政服务员国家职业技能标准》：五级/初级工至一级/高级技师技能要求', 'GB/T 37276-2018《养老机构等级划分与评定》：一至五级评定指标与分值', 'GB/T 42195-2022《老年人能力评估规范》：自理能力/基础运动/精神状态/感知觉与社会参与四维', '家政服务合同应载明服务内容、期限、报酬、损害赔偿与争议解决方式', '《民法典》第 1191 条：工作人员执行工作任务造成他人损害，由用人单位承担侵权责任', '长期护理保险失能等级评估与支付标准，以当地试点办法为准', '母婴护理、餐饮等岗位从业人员须持有效健康证明（《食品安全法》第 45 条口径）']
# 自检项（输入完备度）
CHECKS = [['家政服务合同条款核查·服务需求与能力等级核对', ['家政服务合同条款核查', '家政与养老服务'], '先按老年人能力评估四维核定照护等级，需求错配是最常见事故源'], ['家政服务合同条款核查·人员资质与健康证明核对', ['家政服务合同条款核查', '家政与养老服务'], '核查职业技能等级证书与健康证明有效性'], ['家政服务合同条款核查·安全与风险核查', ['家政服务合同条款核查', '家政与养老服务'], '跌倒/压疮/误吸/用药四类高发风险须有防范措施与应急流程'], ['家政服务合同条款核查·服务可执行性', ['家政服务合同条款核查', '家政与养老服务'], '排班、替班与交接机制可落地，家属沟通链路清晰'], ['家政服务合同条款核查·诚信红线', ['家政服务合同条款核查', '家政与养老服务'], '不得伪造资质、虚报服务时长或诱导购买无关服务，命中即终止']]
# 交付物构成
DELIVERABLES = ['《家政服务合同条款核查》照护服务方案（含能力评估、逐项核对、人力与工时测算）', '服务清单与资质核验表', '归档与复用说明（版本留痕 + 更新口径）']
FOOTER = '本报告为家政与养老服务领域的专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。'


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """方案设计交付物：需求约束 → 方案对比 → 选型依据 → 实施步骤 → 验收标准 → 风险回滚"""
    P = ctx["spec"]["params"]; L = []
    goal = ctx["fv"]("目标")
    cons = ctx["fv"]("约束条件")
    scale = ctx["fv"]("规模/量级")
    budget = ctx["nm"]("预算")
    env = ctx["fv"]("现有环境")
    accept = ctx["fv"]("验收要求")
    opts = P.get("options") or []        # [[方案名, 说明, {维度:分}], ...]
    dims = P.get("dims") or ["适配度", "实施成本", "运维复杂度", "扩展性", "风险"]

    L.append(("一、需求与约束确认", [
        "- 设计目标：%s" % (brief(goal, 60) or "（未提供，需求不清将导致方案无法收敛）"),
        "- 约束条件：%s" % (brief(cons, 60) or "（未提供，约束决定可行域，建议补充时间/合规/人力约束）"),
        "- 规模量级：%s" % (brief(scale, 40) or "（未提供，规模影响选型与成本模型）"),
        "- 预算：%s" % (fmt(budget) + " 元" if budget is not None else "（未提供，按性价比排序而非绝对成本）"),
        "- 现有环境：%s" % (brief(env, 60) or "（未提供，存量系统决定改造成本）"),
        "- 验收要求：%s" % (brief(accept, 50) or "（未提供，默认按功能、性能、可用性三维验收）"),
    ]))

    if opts:
        head = "| 方案 | " + " | ".join(dims) + " | 加权得分 |"
        sep = "|---" * (len(dims) + 2) + "|"
        rows = [head, sep]
        best, bestv = None, -1
        for o in opts:
            sc = o[2]
            vals = [sc.get(d, 3) for d in dims]
            tot = sum(vals)
            if tot > bestv:
                bestv, best = tot, o[0]
            rows.append("| %s | %s | %d |" % (o[0], " | ".join(str(v) for v in vals), tot))
        rows.append("")
        rows.append("评分口径：1~5 分（5 最优）。加权得分用于初筛，最终选型须结合下节依据确认。")
        L.append(("二、候选方案对比", rows))
        L.append(("三、选型依据与推荐", [
            "- 推荐方案：**%s**（对比表加权得分最高）" % best,
            "- 说明：%s" % (opts[[o[0] for o in opts].index(best)][1] if best else ""),
            "",
            "| 决策依据 | 说明 |", "|---|---|",
            "| 与目标匹配度 | 是否直接解决 一、中的设计目标 |",
            "| 约束满足性 | 是否满足全部硬性约束（合规/时间/人力） |",
            "| 总拥有成本 | 建设成本 + 3 年运维成本，而非仅采购价 |",
            "| 可逆性 | 方案变更或回退的代价 |",
            "| 组织适配 | 团队现有技能能否承接运维 |",
        ]))
    else:
        L.append(("二、候选方案对比", ["| 方案 | 说明 | 结论 |", "|---|---|---|",
                                  "| 方案 A（补充后生成） | 需提供候选方案与评分维度 | 待评估 |"]))
        L.append(("三、选型依据与推荐", ["请补充候选方案后重新生成；推荐结论依赖对比数据，不做无依据推荐。"]))

    L.append(("四、实施步骤与里程碑", [
        "| 阶段 | 主要任务 | 交付物 | 里程碑判定 |", "|---|---|---|---|",
        "| 阶段一 设计 | 完成方案细化与接口定义 | 设计说明、接口清单 | 评审通过 |",
        "| 阶段二 搭建 | 按设计实施，先打通最小可用链路 | 可运行环境 | 端到端跑通 |",
        "| 阶段三 验证 | 功能、性能、异常场景验证 | 验证报告 | 全部验收项达标 |",
        "| 阶段四 上线 | 灰度→全量，配套监控与预案 | 上线记录、预案 | 观察期无阻断问题 |",
        "| 阶段五 移交 | 文档与运维移交、培训 | 运维手册 | 接收方确认 |",
    ]))

    L.append(("五、验收标准", [
        "| 维度 | 验收项 | 判定标准 |", "|---|---|---|",
        "| 功能 | 需求逐条对应 | 100% 需求项可演示通过 |",
        "| 性能 | 关键路径响应/吞吐 | 达到需求约定值（未约定时按同行业基线） |",
        "| 可用性 | 故障恢复 | 演练一次可恢复，RTO/RPO 达标 |",
        "| 可维护 | 文档与可观测 | 指标、日志、告警齐备 |",
        "| 合规 | 数据与许可 | 审计无高危项 |",
    ]))

    L.append(("六、风险与回滚", [
        "| 风险 | 触发信号 | 应对 |", "|---|---|---|",
        "| 需求变更 | 关键指标反复调整 | 冻结需求基线，变更走评审 |",
        "| 集成失败 | 接口联调不通 | 预留适配层，先桩后真 |",
        "| 性能不达标 | 压测低于目标 | 预留水平扩展方案 |",
        "| 上线事故 | 观察期异常率上升 | 一键回滚至上一版本并保留数据 |",
        "| 人力不足 | 关键角色缺位 | 提前指定备份责任人 |",
        "",
        "> 本方案为技术作业参考，实施前须由具备相应资质的责任工程师复核；涉及结构安全、消防、特种设备等法定审批事项的，以主管部门审批结论为准。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L
def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    # HUBFIX 主流程包裹
    try:
        main()
    except SystemExit:
        raise
    except Exception as _hubfix_err:
        _hubfix_hook(type(_hubfix_err), _hubfix_err, None)
