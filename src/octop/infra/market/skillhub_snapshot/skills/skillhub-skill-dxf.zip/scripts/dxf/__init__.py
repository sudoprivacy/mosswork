"""DXF generation CLI."""
