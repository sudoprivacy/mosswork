## Description: <br>
Generate, regenerate, and validate 2D DXF drawings from Python ezdxf gen_dxf() sources. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[liubuq-sys](https://clawhub.ai/user/liubuq-sys) <br>

### License/Terms of Use: <br>
MIT License <br>


## Use Case: <br>
Developers and engineers use this skill to create or update DXF files for 2D profiles, templates, cut layouts, and CAD-derived drawings, then validate generated artifacts with ezdxf checks. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: DXF generation runs Python generator files supplied as targets. <br>
Mitigation: Run only generator sources created by you or a trusted collaborator, and review unexpected gen_dxf() or gen_step() files before execution. <br>
Risk: Unpinned runtime dependencies can reduce reproducibility for CAD/DXF outputs. <br>
Mitigation: Pin dependency versions when using the skill in reproducible or higher-assurance workflows. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/liubuq-sys/skills/dxf) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, files] <br>
**Output Format:** [Markdown guidance with Python and shell command snippets plus generated DXF file paths.] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Generated artifacts are DXF files from explicit Python targets; validation findings should be reported.] <br>

## Skill Version(s): <br>
1.0.0 (source: ClawHub release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
