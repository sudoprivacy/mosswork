#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
check_script.py — 电影解说台词的机械自检（适配「3分钟看完一部电影」段式）

用法：
  python check_script.py --script <分段json> [--min 640 --max 820]

段式（5 类，缺一不可）：
  hook     钩子        —— 反常识 / 痛点共鸣 / 悬念前置，第一句就让人停
  premise  设定        —— 不剧透的一句话剧情 / 它讲什么（谁、在哪、卷入什么）
  core     核心看点    —— 1–2 个主题 + 一句可转述金句 +（可选）名场面；可拆多段
  maker    导演/背景   —— 导演凭什么拍它 + 一点幕后语境，不念简历
  ending   观看理由    —— 落到具体的人/场景/动作，谁该看、看完得到什么

校验项：
  1) 总字数 640–820（汉字 + 英文单词 + 数字串，不含标点与空白）
  2) 分段数 6–11
  3) 段式覆盖 hook / premise / core / maker / ending
  4) 首段无禁用开场白
  5) 存在 punchline 金句（置于 core 段），≤30 字，且真实出现在口播文本中
  6) 每段 headline 5–14 字
  7) maker 段 80–140 字（容差 70–160）
  8) core 段合计 300–420 字（容差 270–460，可拆多段合并计）
  9) premise 段 100–180 字（容差 90–210）
  10) 结尾段无空泛词、无剧透结局

退出码：全部通过 0，存在 ❌ 为 1。
"""
import argparse
import json
import re
import sys
import unicodedata

CJK_RE = re.compile(r"[㐀-䶿一-鿿]")
WORD_RE = re.compile(r"[A-Za-z]+")
NUM_RE = re.compile(r"\d+(?:\.\d+)?")

BANNED_OPENINGS = [
    "今天给大家推荐", "今天给大家带来", "今天推荐一部", "今天来给大家",
    "大家好，我是", "大家好,我是", "这部电影的导演是", "今天我们要聊",
    "今天我们来聊", "接下来给大家介绍",
]
VAGUE_ENDINGS = [
    "值得一看", "值得一看的电影", "强烈推荐", "不要错过", "快去看", "赶紧去看",
    "推荐给大家", "一定要看", "大家可以去看看", "非常推荐",
]
# 剧透红线：结尾段不得直接说出结局/凶手/反转结果
SPOILER_HINTS = [
    "最后他死了", "最后她死了", "其实凶手是", "结局是", "最后反转", "真相是男主",
    "真相是女主", "最后活下来的是", "其实男主", "其实女主", "大结局",
]

REQUIRED_SECTIONS = ["hook", "premise", "core", "maker", "ending"]


def count_chars(text):
    """口播字数：汉字逐字 + 英文单词 + 数字串，不含标点与空白。"""
    return len(CJK_RE.findall(text)) + len(WORD_RE.findall(text)) + len(NUM_RE.findall(text))


def raw_chars(text):
    """含标点的非空白字符数，供参考。"""
    return len([c for c in text if not unicodedata.category(c).startswith("Z")])


def split_sentences(text):
    return [s for s in re.split(r"[。！？!?]", text) if s.strip()]


def main():
    ap = argparse.ArgumentParser(description="电影解说台词自检")
    ap.add_argument("--script", required=True, help="分段 JSON（数组）")
    ap.add_argument("--min", type=int, default=640, help="总字数下限")
    ap.add_argument("--max", type=int, default=820, help="总字数上限")
    args = ap.parse_args()

    with open(args.script, encoding="utf-8") as f:
        segs = json.load(f)
    if isinstance(segs, dict):
        segs = segs.get("segments", [])

    results = []

    def add(ok, msg):
        results.append((bool(ok), msg))

    # 1) 总字数
    total = sum(count_chars(s.get("text", "")) for s in segs)
    total_raw = sum(raw_chars(s.get("text", "")) for s in segs)
    add(args.min <= total <= args.max,
        f"总字数 {total} 字（要求 {args.min}–{args.max}；含标点 {total_raw} 字符）")

    # 2) 分段数
    add(6 <= len(segs) <= 11, f"分段数 {len(segs)} 段（要求 6–11）")

    # 3) 段式覆盖
    sections = [s.get("section", "") for s in segs]
    missing = [r for r in REQUIRED_SECTIONS if r not in sections]
    add(not missing,
        "段式覆盖：" + ("hook / premise / core / maker / ending 齐全" if not missing
                      else f"缺少 {missing}"))

    # 4) 禁用开场白
    first_text = segs[0].get("text", "") if segs else ""
    hit = [w for w in BANNED_OPENINGS if w in first_text]
    add(not hit, f"无禁用开场白" + ("" if not hit else f"（命中：{hit}）"))

    # 5) 金句（须在 core 段）
    pl_seg = None
    pl_text = None
    for s in segs:
        p = s.get("punchline")
        if p:
            pl_seg = s
            if isinstance(p, str):
                pl_text = p
            else:
                pl_text = s.get("punchline_text") or (
                    split_sentences(s.get("text", ""))[-1] if split_sentences(s.get("text", "")) else ""
                )
            break
    if not pl_seg:
        add(False, "金句缺失：没有标记 punchline 的段落")
    elif pl_seg.get("section") != "core":
        add(False, f"金句须置于 core 段（当前在 {pl_seg.get('section')} 段）")
    else:
        n = count_chars(pl_text)
        in_text = pl_text in (pl_seg.get("text") or "")
        add(n <= 30 and in_text,
            f"金句「{pl_text}」{n} 字"
            + ("，已在口播文本中" if in_text else "，❗未出现在 text 中（必须被念出来）"))

    # 6) headline 字数
    bad_h = [s.get("headline", "") for s in segs if not (5 <= raw_chars(s.get("headline", "")) <= 14)]
    add(not bad_h, f"大字标题字数均在 5–14 字" + ("" if not bad_h else f"（越界：{bad_h}）"))

    # 7) premise 段
    p_segs = [s for s in segs if s.get("section") == "premise"]
    p_n = sum(count_chars(s.get("text", "")) for s in p_segs)
    add(p_segs and 90 <= p_n <= 210,
        f"premise 设定段合计 {p_n} 字（要求 100–180，容差 90–210）" if p_segs else "premise 段缺失")

    # 8) core 段（可拆多段，合并计）
    c_segs = [s for s in segs if s.get("section") == "core"]
    c_n = sum(count_chars(s.get("text", "")) for s in c_segs)
    add(c_segs and 270 <= c_n <= 460,
        f"core 核心看点段合计 {c_n} 字（要求 300–420，容差 270–460）" if c_segs else "core 段缺失")

    # 9) maker 段
    m_segs = [s for s in segs if s.get("section") == "maker"]
    m_n = sum(count_chars(s.get("text", "")) for s in m_segs)
    add(m_segs and 70 <= m_n <= 160,
        f"maker 导演段 {m_n} 字（要求 80–140，容差 70–160）" if m_segs else "maker 段缺失")

    # 10) 结尾空泛 + 剧透红线（合并为一条检查，保留精确失败原因）
    last_text = segs[-1].get("text", "") if segs else ""
    vhit = [w for w in VAGUE_ENDINGS if w in last_text]
    shit = [w for w in SPOILER_HINTS if w in last_text]
    if vhit:
        ending_msg = f"结尾命中空泛词：{vhit}（请改具体观看理由，勿用『值得一看』类空话）"
    elif shit:
        ending_msg = f"结尾命中剧透词：{shit}（请改为不剧透的观看理由）"
    else:
        ending_msg = "结尾无空泛词、未剧透结局"
    add(not (vhit or shit), ending_msg)

    # B 混合画面策略建议（非阻塞）：hook / ending 建议配置真实片段，core 用海报/名场面截图
    hook_s = next((s for s in segs if s.get("section") == "hook"), None)
    end_s = segs[-1] if segs else None
    suggest_clip = []
    if hook_s and not hook_s.get("clip"):
        suggest_clip.append("hook")
    if end_s and end_s.get("section") == "ending" and not end_s.get("clip"):
        suggest_clip.append("ending")
    if suggest_clip:
        print(f"⚠️ B混合画面建议：{'、'.join(suggest_clip)} 段建议配置 clip 真实片段"
              f"（预告片优先，详见 references/clip_sourcing.md）；core 段用海报/名场面截图。"
              f"该建议不影响本次自检通过判定。")

    # 输出
    print("\n=== 台词自检报告 ===")
    for i, s in enumerate(segs, 1):
        n = count_chars(s.get("text", ""))
        mark = " ★金句" if s.get("punchline") else ""
        sec = s.get("section", "-")
        print(f"  [{i}] {sec:8s} {n:3d}字  {s.get('headline', '')}{mark}")
    print()
    for ok, msg in results:
        print(f"[{'✅' if ok else '❌'}] {msg}")
    passed = sum(1 for ok, _ in results if ok)
    print(f"\n自检通过 {passed}/{len(results)}")
    if passed == len(results):
        print("→ 可进入配音环节。")
        return 0
    print("→ 存在 ❌，必须改稿后重跑，不得进入配音环节。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
