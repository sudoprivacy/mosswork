#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
tts.py — 电影解说分段配音 + 时间轴生成（edge-tts，免费，需联网）

输入：--script 分段 JSON（数组，每项含 headline / text，text 为口播文本）
输出：
  <out>/seg_000.mp3 ... seg_NNN.mp3   各段配音
  <out>/voice.mp3                     拼接后的完整口播
  <out>/timeline.json                 时间轴 [{index, text, headline, start, end, duration}]

用法：
  python tts.py --script seg.json --out ./voice --voice zh-CN-YunjianNeural --rate +5%
"""
import argparse
import asyncio
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

try:
    import edge_tts
except ImportError:
    sys.exit("缺少 edge-tts，请先: pip install edge-tts")


def find_ffmpeg():
    """定位 ffmpeg 可执行文件。"""
    env = os.environ.get("FFMPEG_PATH")
    if env and os.path.isfile(env):
        return env
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    for p in ("ffmpeg", "ffmpeg.exe"):
        if shutil.which(p):
            return p
    sys.exit("未找到 ffmpeg：请设置 FFMPEG_PATH 或安装 imageio-ffmpeg")


FFMPEG = find_ffmpeg()


def probe_duration(path):
    """用 ffmpeg 读取媒体时长（秒），不依赖 ffprobe。"""
    cmd = [FFMPEG, "-hide_banner", "-i", path]
    p = subprocess.run(cmd, capture_output=True, text=True)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", p.stderr or "")
    if not m:
        raise RuntimeError(f"无法解析时长: {path}\n{p.stderr}")
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


async def synth_segment(text, voice, rate, out_path, retries=3):
    """合成单段配音，网络抖动时自动重试（默认 3 次）。"""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            communicate = edge_tts.Communicate(text, voice, rate=rate)
            await communicate.save(out_path)
            return True
        except Exception as e:  # 网络/服务抖动，重试
            last_err = e
            print(f"  [warn] 第 {attempt} 次配音失败：{e}")
    raise last_err


def concat_mp3(paths, out_path):
    """用 ffmpeg concat demuxer 拼接 mp3。"""
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        for p in paths:
            f.write(f"file '{os.path.abspath(p).replace(os.sep, '/')}'\n")
        list_file = f.name
    try:
        subprocess.run(
            [FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", list_file,
             "-c", "copy", out_path],
            check=True, capture_output=True,
        )
    finally:
        os.unlink(list_file)


def main():
    ap = argparse.ArgumentParser(description="edge-tts 分段配音 + 时间轴")
    ap.add_argument("--script", required=True, help="分段 JSON 文件路径")
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--voice", default="zh-CN-YunjianNeural", help="音色 ID")
    ap.add_argument("--rate", default="+5%", help="语速，如 +5%% / +0%%")
    ap.add_argument("--retries", type=int, default=3, help="单段配音失败重试次数")
    args = ap.parse_args()

    with open(args.script, encoding="utf-8") as f:
        segments = json.load(f)

    os.makedirs(args.out, exist_ok=True)

    seg_paths = []
    timeline = []
    cursor = 0.0
    for i, seg in enumerate(segments):
        text = (seg.get("text") or "").strip()
        headline = (seg.get("headline") or "").strip()
        if not text:
            continue
        seg_path = os.path.join(args.out, f"seg_{i:03d}.mp3")
        try:
            asyncio.run(synth_segment(text, args.voice, args.rate, seg_path, retries=args.retries))
        except Exception as e:
            print(f"  [ERROR] 段落 {i}「{headline or text[:14]}」配音失败，跳过该段：{e}")
            continue
        dur = probe_duration(seg_path)
        timeline.append({
            "index": i,
            "headline": headline,
            "text": text,
            "start": round(cursor, 3),
            "end": round(cursor + dur, 3),
            "duration": round(dur, 3),
        })
        cursor += dur
        seg_paths.append(seg_path)
        print(f"  [{i}] {dur:.2f}s  {headline or text[:14]}")

    if not seg_paths:
        sys.exit("全部段落配音失败，未产出任何音频，请检查网络与 edge-tts 可用性。")

    voice_mp3 = os.path.join(args.out, "voice.mp3")
    if len(seg_paths) == 1:
        shutil.copyfile(seg_paths[0], voice_mp3)
    else:
        concat_mp3(seg_paths, voice_mp3)

    timeline_path = os.path.join(args.out, "timeline.json")
    with open(timeline_path, "w", encoding="utf-8") as f:
        json.dump({"total": round(cursor, 3), "segments": timeline}, f, ensure_ascii=False, indent=2)

    print(f"\n配音完成：总时长 {cursor:.2f}s（共 {len(seg_paths)} 段成功）")
    print(f"  时间轴 -> {timeline_path}")
    print(f"  完整配音 -> {voice_mp3}")


if __name__ == "__main__":
    main()
