#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
search_footage.py — 为【3分钟看完一部电影】查找真实电影静帧 / 预告片素材（S1/S2/S3）。

封装「素材主导」画面策略的"查找"环节：给定片名 + 导演 + 年份，
自动产出可用的真实素材候选清单（footage_manifest.json），并附可直接打开的来源链接。

来源分级（详见 references/clip_sourcing.md）：
  S1 官方预告片   —— 片方/发行方 YouTube 官方频道发布的 Trailer/Teaser（默认首选，版权最干净）
  S2 片方物料     —— TMDB 官方剧照/海报、官方幕后特辑截图（带署名，免费可用）
  S3 公有领域/CC  —— Wikimedia Commons、Internet Archive 等明确可复用来源
  S4 第三方搬运   —— 非官方影视切片号、网盘资源（一律拒绝，脚本不产出 S4 候选）

两种模式：
  1) 有 TMDB_API_KEY（环境变量或 --tmdb-key）：直接调 TMDB API，
     拿到剧照直链（backdrop/still）+ 官方预告片 YouTube 链接，写入 manifest。
  2) 无 key：输出各来源"可直接打开的查找链接 + 候选描述"，
     由模型/用户用浏览器取素材，或交给 fetch_footage.py 下载。

零额外依赖：只用 Python 标准库（urllib / json / argparse），不引入 requests。

用法：
  # 有 TMDB key：自动拿到真实剧照直链 + 官方预告片
  python search_footage.py --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014 \
      --tmdb-key $TMDB_API_KEY --out assets/footage_manifest.json

  # 无 key：只输出各来源查找链接（模型/用户据此取素材）
  python search_footage.py --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014
"""
import argparse
import json
import os
import sys
import time
import urllib.parse
import urllib.request

TMDB_API = "https://api.themoviedb.org/3"
IMG_BASE = "https://image.tmdb.org/t/p"
UA = "three-minute-movie-skill/1.2.0 (+footage search; respects TMDB attribution)"


def _get(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _q(s):
    return urllib.parse.quote(s)


# ---------- TMDB 模式（有 key） ----------
def tmdb_search(title, year, key, lang="zh-CN"):
    url = f"{TMDB_API}/search/movie?api_key={key}&query={_q(title)}&language={lang}" \
          + (f"&year={int(year)}" if year else "")
    data = _get(url)
    results = data.get("results") or []
    return results[0] if results else None


def tmdb_backdrops(movie_id, key):
    """官方剧照/背景图（backdrop 多为宽幅名场面感画面，可作 still）。"""
    try:
        data = _get(f"{TMDB_API}/movie/{movie_id}/images?api_key={key}"
                    f"&include_image_language=null,en,zh&language=null")
        return data.get("backdrops") or []
    except Exception:
        return []


def tmdb_videos(movie_id, key):
    try:
        data = _get(f"{TMDB_API}/movie/{movie_id}/videos?api_key={key}&language=en-US")
        return data.get("results") or []
    except Exception:
        return []


def tmdb_mode(title, director, year, key):
    m = tmdb_search(title, year, key)
    if not m:
        print(f"⚠️ TMDB 未匹配到《{title}》（year={year}），回退到无 key 查找链接模式。")
        return None
    mid = m["id"]
    poster = (IMG_BASE + "/w780" + m["poster_path"]) if m.get("poster_path") else None
    cand = []
    if poster:
        cand.append({"role": "poster", "tier": "S2", "source": "TMDB 官方海报",
                     "url": poster, "note": "TMDB 公开海报接口（须署名，商用请确认授权）",
                     "whitelisted": True})
    for i, b in enumerate(tmdb_backdrops(mid, key)[:6]):
        fp = b.get("file_path")
        if not fp:
            continue
        w = b.get("width") or 1280
        size = "w1280" if w >= 1280 else "w780"
        cand.append({"role": "still", "tier": "S2", "source": "TMDB 官方剧照",
                     "url": IMG_BASE + f"/{size}" + fp,
                     "note": f"TMDB backdrop（宽幅名场面感，可作 still；须署名）",
                     "whitelisted": True})
    trailers = [v for v in tmdb_videos(mid, key)
                if v.get("site") == "YouTube" and v.get("type") in ("Trailer", "Teaser")]
    yt = None
    if trailers:
        yt = "https://www.youtube.com/watch?v=" + trailers[0]["key"]
        cand.append({"role": "trailer", "tier": "S1", "source": "片方 YouTube 官方预告片",
                     "url": yt, "note": f"官方{v['type']}：{v.get('name','')}",
                     "whitelisted": True})
    return {
        "movie": {"title": title, "director": director, "year": year, "tmdb_id": mid,
                  "tmdb_title": m.get("title")},
        "poster_url": poster,
        "trailer_url": yt,
        "candidates": cand,
        "search_urls": _search_urls(title, director),
        "recommendation": "已用 TMDB key 取得真实剧照直链与官方预告片链接；"
                          "still 取 S2（TMDB 剧照，须署名），trailer 取 S1（官方预告片，最稳）。"
                          "下载见 fetch_footage.py。",
        "mode": "tmdb",
    }


# ---------- 无 key 模式：只产出查找链接 ----------
def _search_urls(title, director):
    q = f"{title} {director or ''}".strip()
    return {
        "S1_youtube_official_trailer": f"https://www.youtube.com/results?search_query={_q(q + ' official trailer')}",
        "S2_tmdb": f"https://www.themoviedb.org/search?query={_q(title)}",
        "S3_wikimedia_stills": f"https://commons.wikimedia.org/w/index.php?search={_q(title + ' film stills')}&title=Special:MediaSearch",
        "S3_internet_archive": f"https://archive.org/search?query={_q(title + ' trailer')}",
    }


def nostream_mode(title, director, year):
    return {
        "movie": {"title": title, "director": director, "year": year},
        "poster_url": None,
        "trailer_url": None,
        "candidates": [],
        "search_urls": _search_urls(title, director),
        "recommendation": "未提供 TMDB_API_KEY，已输出各来源可直接打开的查找链接。"
                          "优先 S1（片方 YouTube 官方预告片）→ S2（TMDB 剧照，须署名）→ "
                          "S3（Wikimedia/Internet Archive 公有领域/CC）。禁止 S4（第三方搬运/盗版）。"
                          "拿到链接后可交给 fetch_footage.py 下载（仅放行 S1/S2/S3 白名单 host）。",
        "mode": "nostream",
    }


def main():
    ap = argparse.ArgumentParser(description="查找真实电影静帧/预告片素材（S1/S2/S3）")
    ap.add_argument("--title", required=True, help="片名")
    ap.add_argument("--director", default="", help="导演（命中同名片用）")
    ap.add_argument("--year", default="", help="年份")
    ap.add_argument("--tmdb-key", default=os.environ.get("TMDB_API_KEY", ""),
                    help="TMDB API key（也可用环境变量 TMDB_API_KEY）")
    ap.add_argument("--out", default="", help="manifest 输出路径（默认打印到 stdout）")
    args = ap.parse_args()

    if args.tmdb_key:
        try:
            manifest = tmdb_mode(args.title, args.director, args.year, args.tmdb_key)
        except Exception as e:
            print(f"⚠️ TMDB 查询失败（{e}），回退无 key 链接模式。", file=sys.stderr)
            manifest = None
        if manifest is None:
            manifest = nostream_mode(args.title, args.director, args.year)
    else:
        manifest = nostream_mode(args.title, args.director, args.year)

    text = json.dumps(manifest, ensure_ascii=False, indent=2)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"✅ 已写入 manifest：{args.out}（模式={manifest['mode']}）")
    else:
        print(text)

    # 终端可读摘要
    print("\n=== 查找摘要 ===")
    print(f"片名：{args.title} 导演：{args.director or '—'} 年份：{args.year or '—'}")
    if manifest.get("candidates"):
        print(f"真实候选 {len(manifest['candidates'])} 条：")
        for c in manifest["candidates"]:
            print(f"  [{c['tier']}] {c['role']:7} {c['source']} -> {c['url']}")
    else:
        print("无真实直链（未提供 TMDB key）：请用以下链接人工/浏览器取素材——")
        for k, v in manifest["search_urls"].items():
            print(f"  {k}: {v}")
    print(f"\n建议：{manifest['recommendation']}")


if __name__ == "__main__":
    main()
