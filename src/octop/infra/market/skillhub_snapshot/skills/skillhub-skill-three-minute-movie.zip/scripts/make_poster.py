#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
make_poster.py — 用「影片名场面」静帧合成竖版电影海报（默认路径）

默认（推荐）：传入 --source <名场面静帧图片>，把该图 cover 裁切铺满整张海报，
做电影感调色（轻微降饱和 + 提对比 + 暖调），再叠顶部 / 底部压暗 scrim 保证文字可读，
最后压上片名 / 导演 / 年份 / 类型 / 标语的大字排版。
这样海报就是「这部电影的一个名场面 + 片名」，而不是一张单调的纯文字卡。

无 --source 时回退为自绘渐变海报卡（L3 兜底，零额度、零风险、必定可用）。

产出 850×1212（接近 2:3 海报比例）PNG，可直接用作 render.py 的 cover / intro_cover。

用法：
  # 推荐：用名场面静帧合成
  python make_poster.py --source 名场面.jpg --title 星际穿越 --year 2014 \
      --director "克里斯托弗·诺兰" --genre "科幻,冒险,剧情" \
      --tagline "爱是唯一可以穿越时空的东西" --theme cinema --out poster.png

  # 兜底：无静帧时自绘卡
  python make_poster.py --title 星际穿越 --year 2014 --director "克里斯托弗·诺兰" \
      --genre "科幻,冒险,剧情" --tagline "爱是唯一可以穿越时空的东西" \
      --theme cinema --out poster.png

约定：
  - 只写公开可确认的信息（片名 / 年份 / 导演 / 类型 / 一句话标语）；
    不准在海报上编造「评分 9.x」「票房破亿」「获奖 N 项」等无法核实的内容。
  - 名场面静帧须来自合规来源（官方预告片帧 / 授权物料 / 用户自有截图），见 clip_sourcing.md。
  - AI 生成或自绘图作 --source 时必须标注 ai_generated，不得冒充片方官方海报。
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
from PIL import Image, ImageDraw, ImageFont

import render  # 复用跨平台字体探测与主题配色

W, H = 850, 1212
GOLD = (232, 190, 106)
CREAM = (240, 236, 226)
MUTE = (150, 158, 172)


def _fit_cover(im, tw, th):
    """cover 裁剪铺满 (tw, th)：等比放大到至少覆盖，再居中裁切。"""
    src_w, src_h = im.size
    scale = max(tw / src_w, th / src_h)
    nw, nh = int(round(src_w * scale)), int(round(src_h * scale))
    im = im.resize((nw, nh), Image.LANCZOS)
    left = (nw - tw) // 2
    top = (nh - th) // 2
    return im.crop((left, top, left + tw, top + th))


def _cinematic_still(im):
    """电影感处理：轻微降饱和 + 提对比 + 暖调，叠顶部/底部压暗 scrim 保证文字可读。"""
    arr = np.asarray(im.convert("RGB"), dtype=np.float32)
    lum = arr.mean(axis=2, keepdims=True)
    arr = arr * 0.80 + lum * 0.20          # 轻微降饱和
    arr = (arr - 128) * 1.10 + 128         # 轻微提对比
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    out = Image.fromarray(arr).convert("RGBA")
    d = ImageDraw.Draw(out, "RGBA")
    # 顶部压暗（导演 / 类型区）
    top_h = int(H * 0.40)
    for y in range(top_h):
        a = int(165 * (1 - y / top_h))
        d.line([(0, y), (W, y)], fill=(0, 0, 0, a))
    # 底部压暗（片名 / 标语区）
    bot0 = int(H * 0.58)
    for y in range(bot0, H):
        a = int(185 * ((y - bot0) / (H - bot0)))
        d.line([(0, y), (W, y)], fill=(0, 0, 0, a))
    return out


def _overlay_text(img, args):
    d = ImageDraw.Draw(img, "RGBA")
    f_title = ImageFont.truetype(render.FONT_BOLD, args.title_size)
    f_year = ImageFont.truetype(render.FONT_BOLD, 52)
    f_dir = ImageFont.truetype(render.FONT_REG, 32)
    f_genre = ImageFont.truetype(render.FONT_REG, 28)
    f_tag = ImageFont.truetype(render.FONT_REG, 27)

    # 导演（顶部 scrim 区）
    if args.director:
        dt = f"导演 · {args.director}"
        dw = d.textlength(dt, font=f_dir)
        d.text(((W - dw) / 2, int(H * 0.12)), dt, font=f_dir, fill=CREAM,
               stroke_width=2, stroke_fill=(0, 0, 0, 170))
    # 类型（顶部）
    genres = [w.strip() for w in (args.genre or "").split(",") if w.strip()]
    if genres:
        gap = 34
        total_w = sum(d.textlength(w, font=f_genre) for w in genres) + gap * (len(genres) - 1)
        gx = (W - total_w) / 2
        for w in genres:
            d.text((gx, int(H * 0.17)), w, font=f_genre, fill=(212, 216, 224, 240),
                   stroke_width=1, stroke_fill=(0, 0, 0, 130))
            gx += d.textlength(w, font=f_genre) + gap

    # 片名（底部 scrim 区，偏下三分之一）
    title = f"《{args.title}》" if args.bracket else args.title
    tw = d.textlength(title, font=f_title)
    tx = (W - tw) / 2
    ty = int(H * 0.66)
    d.text((tx, ty), title, font=f_title, fill=CREAM,
           stroke_width=4, stroke_fill=(0, 0, 0, 210))
    if args.year:
        d.text((tx, ty + args.title_size + 14), args.year, font=f_year, fill=GOLD,
               stroke_width=2, stroke_fill=(0, 0, 0, 180))
    # 标语（最底）
    if args.tagline:
        d.text((W / 2 - d.textlength(args.tagline, font=f_tag) / 2, H - 96),
               args.tagline, font=f_tag, fill=MUTE,
               stroke_width=1, stroke_fill=(0, 0, 0, 130))


def build_from_still(args):
    src = Image.open(args.source).convert("RGB")
    base = _fit_cover(src, W, H)
    img = _cinematic_still(base)
    d = ImageDraw.Draw(img, "RGBA")
    d.rectangle([22, 22, W - 23, H - 23], outline=(255, 255, 255, 55), width=2)
    _overlay_text(img, args)
    img.convert("RGB").save(args.out)
    print(f"名场面海报已生成: {args.out}  {img.size}（静帧来源: {args.source}）")


def build_fallback_card(args):
    """无 --source 时的自绘渐变海报卡（L3 兜底）。"""
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    theme = render.THEMES.get(args.theme, render.THEMES["cinema"])
    top = np.array(theme["top"], dtype=np.float32)
    bottom = np.array(theme["bottom"], dtype=np.float32)

    t = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    arr = top[None, None, :] * (1 - t) + bottom[None, None, :] * t
    arr = np.repeat(arr, W, axis=1)
    rng = np.random.default_rng(7)
    arr = arr + rng.integers(-1, 2, size=arr.shape).astype(np.float32)
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).convert("RGBA")
    d = ImageDraw.Draw(img)

    f_title = ImageFont.truetype(render.FONT_BOLD, args.title_size)
    f_year = ImageFont.truetype(render.FONT_BOLD, 54)
    f_dir = ImageFont.truetype(render.FONT_REG, 36)
    f_genre = ImageFont.truetype(render.FONT_REG, 32)
    f_tag = ImageFont.truetype(render.FONT_REG, 30)

    def center(text, font, y, fill, maxw=None):
        x = (W - d.textlength(text, font=font)) / 2
        if maxw and d.textlength(text, font=font) > maxw:
            x = (W - maxw) / 2
        d.text((x, y), text, font=font, fill=fill)

    title = f"《{args.title}》" if args.bracket else args.title
    center(title, f_title, 250, CREAM)
    if args.year:
        center(args.year, f_year, 250 + args.title_size + 30, GOLD)
    y_line = 560
    d.rectangle([300, y_line, 550, y_line + 2], fill=(70, 80, 98))
    if args.director:
        center(f"导演 · {args.director}", f_dir, 620, CREAM)
    genres = [w for w in (args.genre or "").split(",") if w.strip()]
    if genres:
        total_w = sum(d.textlength(w, font=f_genre) for w in genres) + 40 * (len(genres) - 1)
        x = (W - total_w) / 2
        for w in genres:
            d.text((x, 720), w, font=f_genre, fill=(196, 204, 218))
            x += d.textlength(w, font=f_genre) + 40
    if args.tagline:
        center(args.tagline, f_tag, 1020, MUTE, maxw=W - 120)
    d.rectangle([24, 24, W - 25, H - 25], outline=(60, 68, 84), width=2)
    img.convert("RGB").save(args.out)
    print(f"自绘海报卡已生成（无静帧兜底）: {args.out}  {img.size}")


def main():
    ap = argparse.ArgumentParser(description="用名场面静帧合成竖版电影海报（无静帧回退自绘卡）")
    ap.add_argument("--source", default="", help="名场面静帧图片路径（推荐；来自合规来源）")
    ap.add_argument("--title", required=True, help="片名（不含书名号）")
    ap.add_argument("--year", default="", help="上映年份")
    ap.add_argument("--director", default="", help="导演")
    ap.add_argument("--genre", default="", help="类型，逗号分隔（可空）")
    ap.add_argument("--tagline", default="", help="一句话标语 / 主题句（可空）")
    ap.add_argument("--theme", default="cinema", help="配色主题，见 render.THEMES（电影默认 cinema 红金）")
    ap.add_argument("--title-size", type=int, default=92)
    ap.add_argument("--bracket", action="store_true", help="给片名加《》")
    ap.add_argument("--out", required=True, help="输出 PNG 路径")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    if args.source and os.path.isfile(args.source):
        build_from_still(args)
    else:
        if args.source:
            print(f"⚠️ --source 文件不存在，回退自绘卡: {args.source}")
        build_fallback_card(args)


if __name__ == "__main__":
    main()
