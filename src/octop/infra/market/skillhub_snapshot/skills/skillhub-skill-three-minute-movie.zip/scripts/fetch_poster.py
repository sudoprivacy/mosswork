#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
fetch_poster.py — 电影海报获取「第一级：真实搜索」的执行器（下载 → 校验 → 规范化 → 缓存）

职责边界（重要）：
  - 本脚本**只做下载 / 校验 / 规范化 / 缓存**，**不负责搜索**。
  - 搜索由宿主模型用 WebSearch 完成，把候选 URL 通过 `--url`（可重复）或 `--candidates`（JSON 数组）传入。
  - 三级降级（real_search → user_upload → ai_generated）的决策与提示文案见
    `references/poster_sourcing.md`，本脚本只执行并产出可机读的 meta JSON。

用法：
  # A. 真实搜索：按序尝试候选 URL，第一个通过质量校验的胜出
  python fetch_poster.py --url https://a.jpg --url https://b.jpg \
      --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014 --out <工作目录>/assets/poster.png

  # B. 用户上传 / AI 生成图入库：校验本地文件并规范化
  python fetch_poster.py --local ~/Downloads/poster.jpg --title 星际穿越 --out assets/poster.png
  python fetch_poster.py --local ai_poster.png --source ai_generated --title 星际穿越 --out assets/poster.png

  # C. 只查缓存（命中则直接复用，不发起任何网络请求）
  python fetch_poster.py --from-cache --title 星际穿越 --year 2014

退出码：
  0 成功（含缓存命中）
  2 ERR_NETWORK   网络 / HTTP 失败（可重试，或换下一个源）
  3 ERR_QUALITY   质量校验不通过（分辨率、比例不合格；换源，不要重试同一 URL）
  4 ERR_FILE      文件损坏 / 非图片 / 格式不支持 / 协议非法
  5 ERR_NOTFOUND  无候选 URL 或全部源失败（进入下一级降级）
  6 ERR_ARGS      参数错误
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prep_poster import prep_image, white_bbox, white_ratio  # noqa: E402

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def default_cache_dir():
    """缓存默认落在系统缓存目录（而非 skill 内部），避免用户级安装只读导致写缓存失败。"""
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "three-minute-movie", "cache")
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Caches/three-minute-movie")
    return os.path.expanduser("~/.cache/three-minute-movie")


CACHE_DIR = default_cache_dir()
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0 Safari/537.36")

MIN_SIDE_DEFAULT = 800      # 硬性：长边下限（海报竖版常见 1000×1500 起）
RECOMMEND_SIDE = 1000       # 软性：低于此值给 warning
# 电影海报多为竖版 2:3（w/h≈0.667）；也兼容 1:1 与 0.66–0.75 区间
RATIO_MIN, RATIO_MAX = 0.45, 1.30

EXIT_OK, EXIT_NETWORK, EXIT_QUALITY, EXIT_FILE, EXIT_NOTFOUND, EXIT_ARGS = 0, 2, 3, 4, 5, 6

COPYRIGHT = {
    "real_search": "来源：{host}（公开电影海报接口，如 TMDB / IMDb / 豆瓣）。海报受版权保护，"
                   "仅用于电影介绍与二次创作；商用前请自行确认授权（商用须取得片方 / 发行方书面授权）。",
    "user_upload": "来源：用户上传。请确认你对该图片拥有使用授权。",
    "ai_generated": "来源：自绘 / AI 生成（非官方海报）。画面不含第三方受版权保护素材，仅作示意，"
                    "不得冒充片方官方海报；商用请替换为授权海报。",
}

MAGIC = [
    (b"\xff\xd8", "JPEG"),
    (b"\x89PNG\r\n\x1a\n", "PNG"),
    (b"RIFF", "WEBP"),
]


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def cache_key(title, director, year):
    """缓存键：优先 片名|年份，其次 片名|导演（去噪后加 md5 短戳）。"""
    raw = f"{title}|{year}" if year else f"{title}|{director}"
    digest = hashlib.md5(raw.encode("utf-8")).hexdigest()[:10]
    safe = re.sub(r"[^\w一-鿿]+", "_", (year or title or "poster")).strip("_")[:48]
    return f"{safe}-{digest}" if safe else digest


def cache_paths(key, cache_dir):
    d = os.path.join(cache_dir, key)
    return d, os.path.join(d, "poster.png"), os.path.join(d, "meta.json")


def load_cache(key, cache_dir):
    d, img, meta_p = cache_paths(key, cache_dir)
    if not (os.path.isfile(img) and os.path.isfile(meta_p)):
        return None
    try:
        with open(meta_p, encoding="utf-8") as f:
            meta = json.load(f)
    except Exception:
        return None
    meta["poster_path"] = img
    meta["cache_hit"] = True
    return meta


def save_cache(key, cache_dir, img_path, meta):
    d, img, meta_p = cache_paths(key, cache_dir)
    os.makedirs(d, exist_ok=True)
    shutil.copyfile(img_path, img)
    with open(meta_p, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    return img


def host_of(url):
    m = re.match(r"https?://([^/]+)", url or "")
    return m.group(1) if m else ""


def download(url, dest, timeout=20):
    """下载图片。返回 (True, None, None) 或 (False, exit_code, reason)。"""
    scheme = urllib.parse.urlparse(url).scheme.lower()
    if scheme not in ("http", "https"):
        return False, EXIT_FILE, f"不支持的协议：{scheme}（仅允许 http/https，已拒绝本地路径读取）"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "image/*"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ctype = r.headers.get("Content-Type", "")
            data = r.read(20 * 1024 * 1024)
    except urllib.error.HTTPError as e:
        code = EXIT_NOTFOUND if e.code in (400, 401, 403, 404, 410) else EXIT_NETWORK
        return False, code, f"HTTP {e.code} {e.reason}"
    except urllib.error.URLError as e:
        return False, EXIT_NETWORK, f"网络不可达或被代理拒绝（{e.reason}）"
    except TimeoutError:
        return False, EXIT_NETWORK, f"下载超时（>{timeout}s）"
    except OSError as e:
        return False, EXIT_NETWORK, f"网络错误（{e}）"

    if ctype and not ctype.lower().startswith("image/") and "html" in ctype.lower():
        return False, EXIT_FILE, f"响应不是图片（Content-Type={ctype}）"
    if not any(data.startswith(m) for m, _ in MAGIC):
        return False, EXIT_FILE, f"响应不是图片（前 8 字节={data[:8].hex()}）"
    if len(data) < 5 * 1024:
        return False, EXIT_QUALITY, f"图片过小（{len(data)} 字节），疑似占位图"

    os.makedirs(os.path.dirname(os.path.abspath(dest)) or ".", exist_ok=True)
    with open(dest, "wb") as f:
        f.write(data)
    return True, None, None


def validate(path, min_side=MIN_SIDE_DEFAULT):
    """质量校验。返回 (ok, quality_dict, exit_code, reason)。"""
    try:
        im = Image.open(path)
        im.load()
    except Exception as e:
        return False, {}, EXIT_FILE, f"文件损坏或不是图片（{e}）"

    if im.format not in ("JPEG", "PNG", "WEBP"):
        return False, {}, EXIT_FILE, f"格式不支持：{im.format}（仅 JPG / PNG / WEBP）"

    w, h = im.size
    ratio = round(w / h, 3)
    q = {
        "width": w, "height": h, "ratio": ratio,
        "format": im.format, "bytes": os.path.getsize(path),
    }

    if max(w, h) < min_side:
        return False, q, EXIT_QUALITY, f"分辨率不足：{w}×{h}，要求长边 ≥ {min_side}px"
    if not (RATIO_MIN <= ratio <= RATIO_MAX):
        return False, q, EXIT_QUALITY, f"宽高比 {ratio} 不在 {RATIO_MIN}–{RATIO_MAX}，与海报不符"

    arr = np.array(im.convert("RGB")).astype(int)
    wr = round(white_ratio(arr, 248), 3)
    q["white_ratio"] = wr
    q["white_bg"] = wr > 0.5

    warns = []
    if max(w, h) < RECOMMEND_SIDE:
        warns.append(f"分辨率偏低（长边 {max(w, h)}px，建议 ≥ {RECOMMEND_SIDE}px）")
    if q["white_bg"]:
        warns.append(f"疑似白底图（纯白占 {wr:.0%}），已自动裁边")
    if im.format == "JPEG" and q["bytes"] < 30 * 1024:
        warns.append("文件极小，可能是缩略图")
    q["warnings"] = warns
    return True, q, None, None


def normalize(src, out, pad=8, radius=20, max_side=1600, trim_white_bg=False):
    """规范化输出：裁白边 +（可选）收紧白框 + 限尺寸 + 圆角 → RGBA PNG。"""
    im = Image.open(src)
    res = prep_image(im, pad=pad, radius=radius, max_side=max_side, verbose=False,
                     trim_white_bg=trim_white_bg)
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    res.save(out)
    return res.size


def main():
    ap = argparse.ArgumentParser(description="电影海报获取/校验/缓存（三级降级之第一级）")
    ap.add_argument("--title", default="", help="片名（用于缓存键与 meta）")
    ap.add_argument("--director", default="", help="导演（用于缓存键与 meta）")
    ap.add_argument("--year", default="", help="上映年份（优先作为缓存键的一部分）")
    ap.add_argument("--url", action="append", default=[], help="候选海报 URL，可重复（按序尝试）")
    ap.add_argument("--candidates", default="", help="候选 URL 的 JSON 数组文件路径")
    ap.add_argument("--local", default="", help="本地图片路径（用户上传 / AI 生成图入库）")
    ap.add_argument("--source", choices=["real_search", "user_upload", "ai_generated"],
                    default="", help="覆盖来源类型（默认由 --local / --url 推断）")
    ap.add_argument("--out", default="", help="规范化后的海报输出路径（PNG）")
    ap.add_argument("--meta-out", default="", help="meta JSON 输出路径（默认 <out>.poster.json）")
    ap.add_argument("--cache-dir", default=CACHE_DIR, help=f"缓存目录（默认 {CACHE_DIR}）")
    ap.add_argument("--min-side", type=int, default=MIN_SIDE_DEFAULT, help="长边下限")
    ap.add_argument("--timeout", type=int, default=20, help="单次下载超时秒数")
    ap.add_argument("--from-cache", action="store_true", help="只查缓存，不发起网络请求")
    ap.add_argument("--force", action="store_true", help="忽略缓存，强制重新获取")
    ap.add_argument("--trim-white-bg", action="store_true",
                    help="规范化时二次收紧：砍掉海报体之外的白色外框（默认关闭）")
    args = ap.parse_args()

    if not (args.title or args.year):
        print(json.dumps({"error": {"code": "ERR_ARGS", "reason": "至少需要提供 --title 或 --year"}},
                         ensure_ascii=False))
        return EXIT_ARGS

    key = cache_key(args.title, args.director, args.year)
    if not args.force:
        hit = load_cache(key, args.cache_dir)
        if hit:
            if args.out:
                shutil.copyfile(hit["poster_path"], args.out)
                hit["poster_path"] = args.out
            print(json.dumps(hit, ensure_ascii=False, indent=2))
            return EXIT_OK
        if args.from_cache:
            print(json.dumps({"error": {"code": "ERR_NOTFOUND",
                                        "reason": f"缓存未命中（key={key}）"}},
                             ensure_ascii=False))
            return EXIT_NOTFOUND

    urls = list(args.url)
    if args.candidates and os.path.isfile(args.candidates):
        try:
            with open(args.candidates, encoding="utf-8") as f:
                data = json.load(f)
            urls += [x["url"] if isinstance(x, dict) else x for x in data]
        except Exception as e:
            print(json.dumps({"error": {"code": "ERR_ARGS", "reason": f"候选文件解析失败：{e}"}},
                             ensure_ascii=False))
            return EXIT_ARGS

    tmp_dir = os.path.join(args.cache_dir, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)
    failures = []

    # 本地源优先处理（--local 属于用户上传 / AI 生成入库，不走网络）
    if args.local:
        if not os.path.isfile(args.local):
            print(json.dumps({"error": {"code": "ERR_FILE", "reason": f"文件不存在：{args.local}"}},
                             ensure_ascii=False))
            return EXIT_FILE
        ok, q, code, reason = validate(args.local, args.min_side)
        if not ok:
            print(json.dumps({"error": {"code": {EXIT_QUALITY: "ERR_QUALITY",
                                                 EXIT_FILE: "ERR_FILE"}.get(code, "ERR_FILE"),
                                        "reason": reason, "quality": q}}, ensure_ascii=False))
            return code
        src_type = args.source or "user_upload"
        raw_path = args.local
        src_url = ""
        ok_flag = True
    else:
        if not urls:
            print(json.dumps({"error": {"code": "ERR_NOTFOUND",
                                        "reason": "没有候选海报 URL（需先用 WebSearch 检索，再传入 --url）"}},
                             ensure_ascii=False))
            return EXIT_NOTFOUND
        ok_flag = False
        src_type, raw_path, src_url, q = "real_search", "", "", {}
        for i, u in enumerate(urls):
            tmp = os.path.join(tmp_dir, f"cand_{i}.bin")
            ok_dl, code, reason = download(u, tmp, args.timeout)
            if not ok_dl:
                failures.append({"url": u, "code": code, "reason": reason})
                continue
            ok_v, q2, code_v, reason_v = validate(tmp, args.min_side)
            if not ok_v:
                failures.append({"url": u, "code": code_v, "reason": reason_v})
                continue
            ok_flag, raw_path, src_url, q = True, tmp, u, q2
            break

    if not ok_flag:
        codes = [f["code"] for f in failures] or [EXIT_NOTFOUND]
        code = EXIT_NETWORK if any(c == EXIT_NETWORK for c in codes) else \
            (EXIT_QUALITY if any(c == EXIT_QUALITY for c in codes) else EXIT_NOTFOUND)
        print(json.dumps({"error": {
            "code": {EXIT_NETWORK: "ERR_NETWORK", EXIT_QUALITY: "ERR_QUALITY",
                     EXIT_FILE: "ERR_FILE", EXIT_NOTFOUND: "ERR_NOTFOUND"}[code],
            "reason": "所有候选海报均未通过（详见 details）；建议换源重试或进入下一级降级",
            "details": failures}}, ensure_ascii=False, indent=2))
        return code

    out = args.out or os.path.join(tmp_dir, "normalized.png")
    final_size = normalize(raw_path, out, trim_white_bg=args.trim_white_bg)
    q["normalized_size"] = list(final_size)

    host = host_of(src_url)
    meta = {
        "poster_path": os.path.abspath(out),
        "poster_url": src_url,
        "source_type": src_type,
        "source_host": host,
        "copyright": COPYRIGHT[src_type].format(host=host or "本地文件"),
        "quality": q,
        "movie": {"title": args.title, "director": args.director, "year": args.year},
        "cache_key": key,
        "cache_hit": False,
        "needs_visual_check": src_type == "real_search",
        "fetched_at": now_iso(),
    }
    cached_img = save_cache(key, args.cache_dir, out, dict(meta, poster_path=out))
    meta["cached_at"] = cached_img

    meta_out = args.meta_out or (out + ".poster.json")
    with open(meta_out, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    meta["meta_path"] = meta_out

    # 清理临时候选文件
    for f in os.listdir(tmp_dir):
        if f.startswith("cand_"):
            try:
                os.remove(os.path.join(tmp_dir, f))
            except OSError:
                pass

    print(json.dumps(meta, ensure_ascii=False, indent=2))
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
