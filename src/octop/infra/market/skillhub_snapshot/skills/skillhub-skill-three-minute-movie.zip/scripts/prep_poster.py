#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
prep_poster.py — 预处理用户提供的海报图，产出可直接给 render.py 用的 cover / intro_cover

用户给的海报图十有八九是**白底 JPG**（官方海报 / 电商图 / 3D 海报渲染图），直接贴到深色视频背景上
会出现一块生硬白矩形。本脚本做三件事：

  1) 裁掉外围纯白边（自适应 bbox，可留安全边距）
  2) 加圆角（4x 超采样抗锯齿）
  3) 若 --trim-white-bg，对"海报体之外"的白框再做一次收紧（可选，谨慎使用）
     实测提示：`white_bbox` 已能裁掉绝大部分白边，本开关只在"bbox 内仍存在整行/整列几乎
     全白的外框"时才生效（如海报四周留了一圈白），对白底 3D 海报 mockup 通常只削 2–6px
     ——那种残留白属于海报体本身，不应裁掉。

用法：
  python prep_poster.py --in 海报.jpg --out poster.png --pad 8 --radius 20

输出：RGBA PNG（透明四角），可直接作为 config.json 的 cover / intro_cover。
"""
import argparse
import os

import numpy as np
from PIL import Image, ImageDraw


def white_bbox(arr, thr):
    """返回非白内容的 bounding box (x0, y0, x1, y1)，以"任一通道 < thr"判定为内容。"""
    mask = arr.min(axis=2) < thr
    rows = np.where(mask.any(axis=1))[0]
    cols = np.where(mask.any(axis=0))[0]
    if len(rows) == 0 or len(cols) == 0:
        return 0, 0, arr.shape[1], arr.shape[0]
    return int(cols.min()), int(rows.min()), int(cols.max()) + 1, int(rows.max()) + 1


def trim_white_edges(arr, thr=244, ratio=0.97, max_frac=0.25):
    """二次收紧：从四边向内收缩，砍掉"几乎整行 / 整列都是近白"的外框。

    用于 bbox 裁边后**海报主体之外仍有白底残留**的情况（例如 3D 海报渲染图投在白背景上，
    柔和阴影把 bbox 撑大）。判定不依赖单像素：只有**整行/整列 ≥ ratio 比例的像素都接近白**
    才认为是白框，因此不会误伤海报主体内部的大片白（主体两侧总有非白背景或阴影）。

    安全阀：单边内收不超过原边长的 max_frac（默认 25%），超出即放弃该边的收紧。
    返回 (x0, y0, x1, y1)；无法判定时返回 None。
    """
    h, w = arr.shape[:2]
    near_white = arr.min(axis=2) >= thr
    row_frac = near_white.mean(axis=1)
    col_frac = near_white.mean(axis=0)

    def shrink(fracs, limit):
        lo = 0
        while lo < limit and fracs[lo] >= ratio:
            lo += 1
        hi = len(fracs) - 1
        while hi > lo and fracs[hi] >= ratio:
            hi -= 1
        return lo, hi + 1

    rel_limit = max(1, int(h * max_frac))
    top, bottom = shrink(row_frac, rel_limit)
    rel_limit_w = max(1, int(w * max_frac))
    left, right = shrink(col_frac, rel_limit_w)

    if bottom - top < h * 0.5 or right - left < w * 0.5:
        return None  # 收紧过头，判定不可信，放弃
    if (top, left, bottom, right) == (0, 0, h, w):
        return None  # 无可收紧
    return left, top, right, bottom


def rounded_alpha(size, radius, ss=4):
    """生成圆角 alpha 遮罩（4x 超采样抗锯齿）。"""
    w, h = size
    m = Image.new("L", (w * ss, h * ss), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, w * ss - 1, h * ss - 1],
                                        radius=radius * ss, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def white_ratio(arr, thr):
    """纯白像素占比（用于判断是否需要裁白边）。"""
    return float((arr.min(axis=2) >= thr).mean())


def prep_image(im, pad=8, radius=20, max_side=1600, threshold=248, verbose=False,
               trim_white_bg=False):
    """对 RGB 图执行规范化：裁外围白边 →（可选）收紧白底外框 → 限最长边 → 切圆角，返回 RGBA 图。

    被 prep_poster.py（命令行）与 fetch_poster.py（海报流水线）共用。
    """
    im = im.convert("RGB")
    arr = np.array(im).astype(int)
    x0, y0, x1, y1 = white_bbox(arr, threshold)
    if verbose:
        print(f"原图 {im.size} → 内容 bbox ({x0}, {y0}, {x1}, {y1})")

    if trim_white_bg:
        sub = arr[y0:y1, x0:x1]
        tb = trim_white_edges(sub)
        if tb is None:
            if verbose:
                print("白框收紧：无可收紧的白框（或收紧过头已放弃）")
        else:
            lx, ty, rx, by = tb
            x0, y0, x1, y1 = x0 + lx, y0 + ty, x0 + rx, y0 + by
            if verbose:
                print(f"白框收紧后 bbox ({x0}, {y0}, {x1}, {y1})")

    pad = max(0, pad)
    x0 = max(0, x0 - pad); y0 = max(0, y0 - pad)
    x1 = min(im.width, x1 + pad); y1 = min(im.height, y1 + pad)
    cropped = im.crop((x0, y0, x1, y1))
    if verbose:
        print(f"裁剪后 {cropped.size}")

    if max_side and max(cropped.size) > max_side:
        scale = max_side / max(cropped.size)
        new_size = (round(cropped.width * scale), round(cropped.height * scale))
        cropped = cropped.resize(new_size, Image.LANCZOS)
        if verbose:
            print(f"缩放后 {cropped.size}")

    out = cropped.convert("RGBA")
    if radius > 0:
        out.putalpha(rounded_alpha(out.size, radius))
    return out


def main():
    ap = argparse.ArgumentParser(description="封面图预处理（裁白边 + 圆角 → RGBA PNG）")
    ap.add_argument("--in", dest="src", required=True, help="输入封面图（jpg/png/webp）")
    ap.add_argument("--out", dest="dst", required=True, help="输出 PNG")
    ap.add_argument("--pad", type=int, default=8, help="裁剪后保留的边距像素（默认 8）")
    ap.add_argument("--radius", type=int, default=20, help="圆角半径像素，0 为不切圆角（默认 20）")
    ap.add_argument("--threshold", type=int, default=248,
                    help="白边判定阈值：某像素任一通道低于该值即视为内容（默认 248）")
    ap.add_argument("--max-side", type=int, default=1600,
                    help="输出最长边上限，超出则等比缩小（默认 1600，控制渲染耗时）")
    ap.add_argument("--trim-white-bg", action="store_true",
                    help="二次收紧：砍掉海报主体之外「整行/整列几乎全白」的白框（默认关闭，谨慎使用）")
    args = ap.parse_args()

    im = Image.open(args.src).convert("RGB")
    out = prep_image(im, pad=args.pad, radius=args.radius,
                     max_side=args.max_side, threshold=args.threshold, verbose=True,
                     trim_white_bg=args.trim_white_bg)
    os.makedirs(os.path.dirname(os.path.abspath(args.dst)) or ".", exist_ok=True)
    out.save(args.dst)
    print(f"已输出 {args.dst}  {out.size}")


if __name__ == "__main__":
    main()
