#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
render.py — 竖屏「大字报」电影解说视频合成（ffmpeg）

输入：--config 合成配置 JSON + --out 输出 mp4
  配置 JSON 字段：
    title       片名（用于片名大字卡兜底；无海报时展示）
    author      导演（选填，无海报时在大字卡底部署名）
    theme       配色主题: night-gold / warm-book / pure-dark / forest / cinema
    width       输出宽度（默认 1080）
    height      输出高度（默认 1920；小红书 3:4 用 1440）
    cover       海报图路径（选填，无则用片名大字卡）
    intro_cover 片头海报图路径（选填）
    intro_seconds 片头海报展示秒数（默认 0）
    voice       完整配音 mp3 路径
    timeline    tts.py 产出的 timeline.json 路径
    bgm         背景音乐 mp3 路径（选填，缺省则静音出片）
    segments    分段数组 [{headline, text, show_cover,
                          clip?{src,in?,dur?,fit?}, still?}]
                画面优先级：clip(电影切片视频) > still(名场面静帧图) > cover 海报 > 大字卡。
                - clip：真实片段（预告片 / 名场面切片）。存在且可读时该段用「静音实拍画面 + 解说字幕」铺底。
                - still：名场面静帧图（来自合规来源）。存在且可读时该段用「静帧 + Ken Burns 推近 + 解说字幕」铺底。
                两者皆缺时，show_cover 段回退共用 cover 海报，否则仅大字+字幕铺在背景上。
                文件缺失或字段省略则自动回退并打印 ⚠️，不中断整条渲染。

输出：width×height@30fps 竖屏 mp4（H.264 + AAC）。版面按尺寸等比自适应。

用法：
  python render.py --config cfg.json --out final.mp4
"""
import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw, ImageFont

FPS = 30
TAIL = 1.0  # 结尾留白（秒）


def _pick_font(candidates):
    """从候选绝对路径列表中返回第一个真实存在的字体文件。"""
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None


# 跨平台中文字体探测：Windows(微软雅黑) → macOS(华文黑体/苹方/冬青黑体) → Linux(Noto CJK)
_CAND_BOLD = [
    r"C:\Windows\Fonts\msyhbd.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
]
_CAND_REG = [
    r"C:\Windows\Fonts\msyh.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/STHeiti Light.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
]
FONT_BOLD = _pick_font(_CAND_BOLD)
FONT_REG = _pick_font(_CAND_REG)
if FONT_BOLD is None or FONT_REG is None:
    sys.exit("未找到中文字体：请在本文件 _CAND_BOLD / _CAND_REG 中补充本机中文黑体类字体的绝对路径")
FONT_FALLBACK = FONT_REG

THEMES = {
    "night-gold": {"top": (11, 16, 38), "bottom": (26, 31, 58),
                   "headline": (236, 203, 120), "subtitle": (238, 238, 238), "accent": (212, 175, 55)},
    "warm-book":  {"top": (43, 27, 18), "bottom": (74, 44, 26),
                   "headline": (245, 230, 200), "subtitle": (240, 230, 215), "accent": (212, 175, 55)},
    "pure-dark":  {"top": (17, 19, 24), "bottom": (30, 32, 38),
                   "headline": (255, 255, 255), "subtitle": (222, 222, 222), "accent": (255, 255, 255)},
    "forest":     {"top": (13, 31, 26), "bottom": (22, 53, 42),
                   "headline": (232, 240, 232), "subtitle": (216, 230, 216), "accent": (150, 200, 160)},
    "cinema":     {"top": (30, 11, 15), "bottom": (62, 16, 22),
                   "headline": (241, 202, 122), "subtitle": (240, 228, 222), "accent": (201, 38, 48)},
}


def find_ffmpeg():
    env = os.environ.get("FFMPEG_PATH")
    if env and os.path.isfile(env):
        return env
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    for p in ("ffmpeg", "ffmpeg.exe"):
        if shutil.which(p):
            return p
    sys.exit("未找到 ffmpeg：请设置 FFMPEG_PATH 或安装 imageio-ffmpeg")


FFMPEG = None  # 懒加载：仅在 main() 内首次解析，避免被 make_poster.py 等导入时被迫探测 ffmpeg


def probe_duration(path):
    """用 ffmpeg 读取媒体时长（秒），不依赖 ffprobe；读不到返回 None。"""
    if FFMPEG is None:
        return None
    cmd = [FFMPEG, "-hide_banner", "-i", path]
    p = subprocess.run(cmd, capture_output=True, text=True)
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", p.stderr or "")
    if not m:
        return None
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


def layout(W, H):
    """把所有版面坐标表达为 1080×1920 基准的等比缩放因子，使 9:16 / 3:4 等比例自适应。"""
    sx = W / 1080.0
    sy = H / 1920.0
    fs = min(sx, sy)
    return {
        "sx": sx, "sy": sy, "fs": fs,
        "hf_size_show": max(20, int(74 * fs)),
        "hf_size_no": max(24, int(96 * fs)),
        "h_top_show": int(230 * sy),
        "h_top_no": int(440 * sy),
        "h_line_h_f": 1.28,
        "sf_size": max(14, int(44 * fs)),
        "s_top": int(1490 * sy),
        "s_line_h": max(18, int(64 * sy)),
        "max_text_w": int(900 * sx),
        "cover_max_w": int(720 * sx),
        "cover_max_h": int(900 * sy),
        "cover_cy": int(940 * sy),
        "intro_max_w": int(940 * sx),
        "intro_max_h": int(1580 * sy),
        "intro_cy": int(980 * sy),
        "box_w": int(720 * sx),
        "box_h": int(900 * sy),
        "box_y0": int(440 * sy),
        "title_fs": max(18, int(84 * fs)),
        "title_top": int(670 * sy),
        "title_line_h": max(20, int(120 * sy)),
        "author_fs": max(16, int(52 * fs)),
    }


# ---------- 文字换行 ----------

NO_LEAD_PUNCT = set("，。！？、；：）〕］｝》」』】…—～·!?,.;:)]}%")


def _greedy_wrap(text, font, max_width):
    lines, cur = [], ""
    for ch in text:
        if ch == "\n":
            if cur:
                lines.append(cur)
            cur = ""
            continue
        if font.getlength(cur + ch) <= max_width:
            cur += ch
        elif ch in NO_LEAD_PUNCT and cur:
            cur += ch  # 避头：标点不另起一行（允许轻微溢出）
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    return lines


def _balance_lines(lines, font, max_width):
    """把过长的上一行末字逐个挪到下一行，直到各行长度均衡（且不产生行首标点）。"""
    guard = 0
    changed = True
    while changed and guard < 300:
        changed = False
        guard += 1
        for i in range(len(lines) - 1):
            a, b = lines[i], lines[i + 1]
            if len(a) - len(b) >= 2 and len(a) >= 2 and a[-1] not in NO_LEAD_PUNCT:
                cand = a[-1] + b
                if font.getlength(cand) <= max_width:
                    lines[i], lines[i + 1] = a[:-1], cand
                    changed = True
    return lines


def wrap_text(text, font, max_width):
    """按宽度自动换行：避头标点 + 逐字平衡，避免行首标点与过短的末行。"""
    return _balance_lines(_greedy_wrap(text, font, max_width), font, max_width)


def render_text_block(draw, lines, font, fill, anchor_x, top_y, line_h,
                      stroke_width, stroke_fill, align="center"):
    y = top_y
    for line in lines:
        w = font.getlength(line)
        x = anchor_x - w / 2 if align == "center" else anchor_x
        draw.text((x, y), line, font=font, fill=fill,
                  stroke_width=stroke_width, stroke_fill=stroke_fill)
        y += line_h


# ---------- 背景 ----------

def make_background(theme, out_path, W, H, dither=True):
    top = np.array(THEMES[theme]["top"], dtype=np.float32)
    bottom = np.array(THEMES[theme]["bottom"], dtype=np.float32)
    t = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
    img = (top[None, None, :] * (1 - t) + bottom[None, None, :] * t)
    img = np.repeat(img, W, axis=1)
    # 暗色渐变跨度小，直接量化会出现明显色带（马赫带）；加入不可见的 ±1 抖动打散
    if dither:
        rng = np.random.default_rng(20240930)
        img = img + rng.uniform(-1.2, 1.2, img.shape).astype(np.float32)
    img = np.clip(img, 0, 255).astype(np.uint8)
    Image.fromarray(img).save(out_path)


# ---------- 段落大字 + 字幕 ----------

def make_segment_png(theme, headline, subtitle, show_cover, out_path, W, H, L):
    th = THEMES[theme]
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)

    hf_size = L["hf_size_no"] if show_cover else L["hf_size_show"]
    hf = ImageFont.truetype(FONT_BOLD, hf_size)
    h_lines = wrap_text(headline, hf, L["max_text_w"])[:3]
    h_line_h = int(hf_size * L["h_line_h_f"])
    h_top = L["h_top_show"] if show_cover else L["h_top_no"]
    render_text_block(draw, h_lines, hf, th["headline"], W / 2, h_top, h_line_h,
                      stroke_width=max(3, hf_size // 18), stroke_fill=(0, 0, 0, 170))

    sf = ImageFont.truetype(FONT_REG, L["sf_size"])
    s_lines = wrap_text(subtitle, sf, L["max_text_w"])
    render_text_block(draw, s_lines, sf, th["subtitle"], W / 2, L["s_top"], L["s_line_h"],
                      stroke_width=2, stroke_fill=(0, 0, 0, 190))

    canvas.save(out_path)


# ---------- 海报 ----------

def make_cover_png(cover_path, out_path, W, H, L):
    """把海报缩放到竖屏居中并贴到透明画布上，便于 zoompan。"""
    cover = Image.open(cover_path).convert("RGBA")
    cover.thumbnail((L["cover_max_w"], L["cover_max_h"]), Image.LANCZOS)
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cx, cy = W // 2, L["cover_cy"]
    canvas.paste(cover, (cx - cover.width // 2, cy - cover.height // 2), cover)
    canvas.save(out_path)


def make_still_png(still_path, out_path, W, H, L):
    """把名场面静帧 cover 铺满整屏，加顶部/底部压暗 scrim（保证大字与字幕可读），便于 zoompan。"""
    still = Image.open(still_path).convert("RGBA")
    sw, sh = still.size
    scale = max(W / sw, H / sh)
    nw, nh = int(round(sw * scale)), int(round(sh * scale))
    still = still.resize((nw, nh), Image.LANCZOS)
    left = (nw - W) // 2
    top = (nh - H) // 2
    canvas = still.crop((left, top, left + W, top + H)).convert("RGBA")
    d = ImageDraw.Draw(canvas, "RGBA")
    bot0 = int(H * 0.62)
    for y in range(bot0, H):
        a = int(150 * ((y - bot0) / (H - bot0)))
        d.line([(0, y), (W, y)], fill=(0, 0, 0, a))
    top_h = int(H * 0.30)
    for y in range(top_h):
        a = int(90 * (1 - y / top_h))
        d.line([(0, y), (W, y)], fill=(0, 0, 0, a))
    canvas.save(out_path)


def make_intro_cover_png(cover_path, out_path, W, H, L, max_w=None, max_h=None, cy=None):
    """片头海报卡：把海报放大居中，占满画面主要区域，便于 zoompan 做片头。"""
    max_w = max_w or L["intro_max_w"]
    max_h = max_h or L["intro_max_h"]
    cy = cy or L["intro_cy"]
    cover = Image.open(cover_path).convert("RGBA")
    cover.thumbnail((max_w, max_h), Image.LANCZOS)
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cx = W // 2
    sh = Image.new("RGBA", (cover.width + 40, cover.height + 40), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([20, 20, cover.width + 20, cover.height + 20],
                                         radius=18, fill=(0, 0, 0, 120))
    canvas.alpha_composite(sh, (cx - sh.width // 2 + 8, cy - sh.height // 2 + 14))
    canvas.paste(cover, (cx - cover.width // 2, cy - cover.height // 2), cover)
    canvas.save(out_path)


def make_title_card(theme, title, author, out_path, W, H, L):
    """无海报时的片名大字卡兜底。"""
    th = THEMES[theme]
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    box_w, box_h = L["box_w"], L["box_h"]
    x0, y0 = (W - box_w) // 2, L["box_y0"]
    draw.rounded_rectangle([x0, y0, x0 + box_w, y0 + box_h], radius=24,
                           fill=(255, 255, 255, 18), outline=th["accent"] + (200,), width=4)
    tf = ImageFont.truetype(FONT_BOLD, L["title_fs"])
    t_lines = wrap_text(title, tf, box_w - 120)
    render_text_block(draw, t_lines, tf, th["headline"], W / 2, L["title_top"], L["title_line_h"],
                      stroke_width=3, stroke_fill=(0, 0, 0, 170))
    if author:
        af = ImageFont.truetype(FONT_REG, L["author_fs"])
        author_y = y0 + box_h - int(190 * L["sy"])
        draw.text((W / 2 - af.getlength(author) / 2, author_y), author,
                  font=af, fill=th["subtitle"], stroke_width=2, stroke_fill=(0, 0, 0, 170))
    canvas.save(out_path)


# ---------- 主流程 ----------

def main():
    ap = argparse.ArgumentParser(description="竖屏电影解说视频合成（支持真实片段 B 混合画面）")
    ap.add_argument("--config", required=True, help="合成配置 JSON")
    ap.add_argument("--out", required=True, help="输出 mp4 路径")
    ap.add_argument("--width", type=int, default=0, help="输出宽度（覆盖 config 中的 width）")
    ap.add_argument("--height", type=int, default=0, help="输出高度（覆盖 config 中的 height）")
    args = ap.parse_args()

    global FFMPEG
    FFMPEG = find_ffmpeg()

    with open(args.config, encoding="utf-8") as f:
        cfg = json.load(f)

    theme = cfg.get("theme", "cinema")
    if theme not in THEMES:
        theme = "night-gold"
    segments = cfg.get("segments", [])

    W = int(cfg.get("width", 1080))
    H = int(cfg.get("height", 1920))
    if args.width:
        W = args.width
    if args.height:
        H = args.height
    L = layout(W, H)

    # 片头封面卡：intro_cover 存在时，视频最前面显示 intro_seconds 秒大封面
    intro_cover = cfg.get("intro_cover")
    if not (intro_cover and os.path.isfile(intro_cover)):
        intro_cover = None
    intro_secs = max(0.0, float(cfg.get("intro_seconds", 0) or 0)) if intro_cover else 0.0

    workdir = tempfile.mkdtemp(prefix="bookvideo_")
    print(f"临时目录: {workdir}")

    # 时间轴
    with open(cfg["timeline"], encoding="utf-8") as f:
        tl = json.load(f)
    tl_segs = tl["segments"]
    # 用 timeline 自带的 index 字段建索引表：配音某段失败时 tts.py 会跳过该段，
    # 此时按位置取段会与 segments 错位，必须按 index 精确匹配。
    tl_by_index = {e.get("index", k): e for k, e in enumerate(tl_segs)}
    total_voice = tl["total"]
    total_dur = intro_secs + total_voice + TAIL
    total_frames = int(round(total_dur * FPS))

    # 1. 背景
    bg_path = os.path.join(workdir, "bg.png")
    make_background(theme, bg_path, W, H)

    inputs = ["-i", bg_path]
    idx = 1

    # 2a. 片头大封面
    intro_idx = None
    if intro_cover:
        intro_canvas = os.path.join(workdir, "intro_cover.png")
        make_intro_cover_png(intro_cover, intro_canvas, W, H, L)
        inputs += ["-i", intro_canvas]
        intro_idx = idx
        idx += 1

    cfg_dir = os.path.dirname(os.path.abspath(args.config))

    # 2b. 真实片段（电影切片）：任意段可携带 clip，静音实拍画面铺底 + 解说字幕
    clip_idx = {}      # 段序号 -> ffmpeg 输入序号
    clip_src = {}      # 段序号 -> 解析后的片段绝对路径（供 probe/clamp 使用）
    for i, s in enumerate(segments):
        c = s.get("clip")
        if not c or not c.get("src"):
            continue
        csrc = c["src"]
        if not os.path.isabs(csrc):
            csrc = os.path.join(cfg_dir, csrc)
        if os.path.isfile(csrc):
            inputs += ["-i", csrc]
            clip_idx[i] = idx
            clip_src[i] = csrc
            idx += 1
        else:
            print(f"⚠️ 片段缺失，跳过：{csrc}（该段回退名场面/海报/大字卡）")

    # 2c. 名场面静帧（素材主导画面）：任意段可携带 still，优先于共用海报
    still_idx = {}     # 段序号 -> ffmpeg 输入序号
    still_src = {}     # 段序号 -> 解析后的静帧绝对路径
    for i, s in enumerate(segments):
        st = s.get("still")
        if not st:
            continue
        ssrc = st if os.path.isabs(st) else os.path.join(cfg_dir, st)
        if os.path.isfile(ssrc):
            p = os.path.join(workdir, f"still_{i:03d}.png")
            make_still_png(ssrc, p, W, H, L)
            inputs += ["-i", p]
            still_idx[i] = idx
            still_src[i] = ssrc
            idx += 1
        else:
            print(f"⚠️ 名场面静帧缺失，跳过：{ssrc}（该段回退海报/大字卡）")

    # 2d. 段落海报 / 片名卡（仅用于没有 clip / still 的 show_cover 段，作兜底）
    cover_indices = [i for i, s in enumerate(segments)
                     if s.get("show_cover") and i not in clip_idx and i not in still_idx]
    cover_canvas = None
    if cfg.get("cover") and os.path.isfile(cfg["cover"]):
        cover_canvas = os.path.join(workdir, "cover.png")
        make_cover_png(cfg["cover"], cover_canvas, W, H, L)
    elif segments:
        cover_canvas = os.path.join(workdir, "cover.png")
        make_title_card(theme, cfg.get("title", ""), cfg.get("author", ""), cover_canvas, W, H, L)
        if not cover_indices:
            cover_indices = [0, len(segments) - 1]
    if cover_canvas:
        inputs += ["-i", cover_canvas]
        cover_idx = idx
        idx += 1
    else:
        cover_idx = None
        cover_indices = []

    # 3. 每段大字 + 字幕叠加图
    seg_pngs = []
    for i, s in enumerate(segments):
        p = os.path.join(workdir, f"seg_{i:03d}.png")
        make_segment_png(theme, s.get("headline", ""), s.get("text", ""),
                         s.get("show_cover", False), p, W, H, L)
        seg_pngs.append(p)

    # 4. 组装 ffmpeg 命令
    seg_start_idx = idx
    for p in seg_pngs:
        inputs += ["-loop", "1", "-t", f"{total_dur:.3f}", "-i", p]
        idx += 1
    voice_idx = idx
    inputs += ["-i", cfg["voice"]]
    idx += 1
    bgm_idx = None
    if cfg.get("bgm") and os.path.isfile(cfg["bgm"]):
        bgm_idx = idx
        inputs += ["-i", cfg["bgm"]]
        idx += 1
    else:
        print("未提供 BGM，将静音出片（配音不受影响）。")

    fc = []
    # 背景：缓慢推近
    fc.append(
        f"[0:v]zoompan=z='min(1+0.00025*on,1.06)':x='iw/2-(iw/zoom/2)':"
        f"y='ih/2-(ih/zoom/2)':d={total_frames}:s={W}x{H}:fps={FPS}[bgv]"
    )
    cur = "[bgv]"
    # 片头大封面：0 ~ intro_secs 显示，慢推近 + 淡入淡出
    if intro_idx is not None and intro_secs > 0:
        fi = min(0.4, intro_secs / 3)
        fo = min(0.4, intro_secs / 3)
        fc.append(
            f"[{intro_idx}:v]format=rgba,zoompan=z='min(1+0.0006*on,1.10)':"
            f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={total_frames}:s={W}x{H}:fps={FPS},"
            f"fade=t=in:st=0:d={fi:.3f}:alpha=1,"
            f"fade=t=out:st={max(0.0, intro_secs - fo):.3f}:d={fo:.3f}:alpha=1[iv]"
        )
        fc.append(f"{cur}[iv]overlay=0:0:shortest=1:enable='between(t,0,{intro_secs:.3f})'[v0]")
        cur = "[v0]"
    # 段落海报：Ken Burns + 首现淡入/末现淡出 + 按展示段 enable 控窗（时间轴整体后移 intro_secs）
    if cover_idx is not None and cover_indices:
        ci_list = [ci for ci in cover_indices if ci in tl_by_index]
        if ci_list:
            cs = tl_by_index[ci_list[0]]["start"] + intro_secs
            ce = min(tl_by_index[ci_list[-1]]["end"] + intro_secs + 0.2, total_dur)
            fc.append(
                f"[{cover_idx}:v]format=rgba,zoompan=z='min(1+0.0004*on,1.12)':"
                f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={total_frames}:s={W}x{H}:fps={FPS},"
                f"fade=t=in:st={cs:.3f}:d=0.35:alpha=1,"
                f"fade=t=out:st={max(cs, ce - 0.35):.3f}:d=0.35:alpha=1[cv]"
            )
            enable_expr = "+".join(
                f"between(t,{tl_by_index[ci]['start'] + intro_secs:.3f},{tl_by_index[ci]['end'] + intro_secs:.3f})"
                for ci in ci_list
            )
            fc.append(f"{cur}[cv]overlay=0:0:shortest=1:enable='{enable_expr}'[vc]")
            cur = "[vc]"
    # 每段文字叠加（含淡入淡出）
    for i, s in enumerate(segments):
        tl = tl_by_index.get(i)
        if tl is None:
            continue  # 该段配音失败被跳过，不叠加字幕/画面，避免错位
        st = tl["start"] + intro_secs
        en = tl["end"] + intro_secs
        if en - st <= 0.7:
            en = st + 0.7
        en = min(en, total_dur)
        out_dur = en - st
        # 2d. 真实片段叠加（B 混合）：静音实拍画面铺底，解说字幕压在上面
        if i in clip_idx:
            ci = clip_idx[i]
            cin = float(s.get("clip", {}).get("in", 0) or 0)
            cdur = min(float(s.get("clip", {}).get("dur", out_dur) or out_dur), out_dur)
            fit = s.get("clip", {}).get("fit", "cover")
            src_dur = probe_duration(clip_src.get(i))
            if src_dur is None or src_dur <= 0.2:
                print(f"⚠️ 片段无法读取时长或为空，跳过：{clip_src.get(i)}（该段回退海报/大字卡）")
            elif cin >= src_dur - 0.05:
                print(f"⚠️ 片段起始 {cin:.1f}s 超出可用长度 {src_dur:.1f}s，跳过：{clip_src.get(i)}"
                      f"（该段回退海报/大字卡）")
            else:
                cdur = min(cdur, src_dur - cin)  # 钳制到源可用长度，避免 ffmpeg trim 越界报错
                if fit == "contain":
                    sc = f"scale={W}:{H}:force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2"
                else:
                    sc = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}"
                fc.append(
                    f"[{ci}:v]trim=start={cin:.3f}:duration={cdur:.3f},setpts=PTS-STARTPTS,"
                    f"{sc},format=rgba,"
                    f"fade=t=in:st=0:d=0.3:alpha=1,"
                    f"fade=t=out:st={max(0.0, cdur - 0.3):.3f}:d=0.3:alpha=1[cl{i}]"
                )
                fc.append(f"{cur}[cl{i}]overlay=0:0:enable='between(t,{st:.3f},{en:.3f})'[vc{i}]")
                cur = f"[vc{i}]"
        # 2e. 名场面静帧叠加（素材主导）：静帧铺底 + Ken Burns 缓慢推近 + 淡入淡出
        elif i in still_idx:
            si = still_idx[i]
            fc.append(
                f"[{si}:v]format=rgba,zoompan=z='min(1+0.0004*on,1.14)':"
                f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={total_frames}:s={W}x{H}:fps={FPS},"
                f"fade=t=in:st={st:.3f}:d=0.4:alpha=1,"
                f"fade=t=out:st={max(st, en - 0.4):.3f}:d=0.4:alpha=1[st{i}]"
            )
            fc.append(f"{cur}[st{i}]overlay=0:0:enable='between(t,{st:.3f},{en:.3f})'[vst{i}]")
            cur = f"[vst{i}]"
        fade_in = min(0.3, out_dur / 3)
        fade_out = min(0.35, out_dur / 3)
        in_idx = seg_start_idx + i
        fc.append(
            f"[{in_idx}:v]format=rgba,"
            f"fade=t=in:st={st:.3f}:d={fade_in:.3f}:alpha=1,"
            f"fade=t=out:st={en - fade_out:.3f}:d={fade_out:.3f}:alpha=1[s{i}]"
        )
        fc.append(f"{cur}[s{i}]overlay=0:0[v{i + 2}]")
        cur = f"[v{i + 2}]"

    # 音频（配音整体后移 intro_secs，BGM 从 0 开始）
    vchain = "aresample=44100,pan=stereo|c0=c0|c1=c0"
    if intro_secs > 0:
        ms = int(round(intro_secs * 1000))
        vchain += f",adelay={ms}|{ms}"
    if bgm_idx is not None:
        fc.append(
            f"[{voice_idx}:a]{vchain}[av];"
            f"[{bgm_idx}:a]aresample=44100,pan=stereo|c0=c0|c1=c0,"
            f"volume=0.12,afade=t=in:st=0:d=2.5,"
            f"afade=t=out:st={max(0.0, total_dur - 3.5):.3f}:d=3.5[ab];"
            f"[av][ab]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0,"
            f"atrim=0:{total_dur:.3f},alimiter=limit=0.9[aout]"
        )
    else:
        fc.append(
            f"[{voice_idx}:a]{vchain},apad,atrim=0:{total_dur:.3f},alimiter=limit=0.9[aout]"
        )

    cmd = [FFMPEG, "-y", *inputs,
           "-filter_complex", ";".join(fc),
           "-map", cur, "-map", "[aout]",
           "-c:v", "libx264", "-preset", "medium", "-crf", "21",
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
           "-movflags", "+faststart",
           args.out]

    print("合成中 ...")
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        print("ffmpeg 失败，stderr 末尾：")
        print((p.stderr or "")[-3000:])
        print(f"临时文件保留在：{workdir}（排查后可手动删除）")
        sys.exit(1)

    shutil.rmtree(workdir, ignore_errors=True)
    print(f"完成 -> {args.out}（{W}x{H}@{FPS}fps，时长约 {total_dur:.1f}s）")


if __name__ == "__main__":
    main()
