#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_footage.py — 从 search_footage.py 产出的 manifest（或单条 URL）下载真实素材，
强制 S1/S2/S3 白名单，记录来源与版权，拒绝 S4。

设计原则（见 references/clip_sourcing.md 红线）：
  - 只放行白名单 host：image.tmdb.org(S2) / upload.wikimedia.org(S3) / archive.org(S3)。
  - 非白名单 host 一律拒绝下载（S4 第三方搬运/盗版），并给出明确错误，不静默失败。
  - trailer(S1, YouTube) 不内置下载（避免绕过平台条款）；改为输出 yt-dlp 指令，
    仅当 --yt-dlp 显式开启且本机有 yt-dlp 时才尝试。
  - 每个下载项写入带 provenance 的 manifest，交付时如实说明来源与版权。

零额外依赖：标准库 + Pillow（已在 requirements.txt）。

用法：
  # 按 manifest 批量下载（只下 poster/still；trailer 给指令）
  python fetch_footage.py --manifest assets/footage_manifest.json --assets-dir assets

  # 单条下载（明确来源分级）
  python fetch_footage.py --url https://image.tmdb.org/t/p/w1280/xxxx.jpg \
      --role still --tier S2 --source "TMDB 官方剧照" --assets-dir assets

  # 顺带尝试用 yt-dlp 下官方预告片
  python fetch_footage.py --manifest assets/footage_manifest.json --assets-dir assets --yt-dlp
"""
import argparse
import json
import os
import shutil
import sys
import urllib.parse
import urllib.request

try:
    from PIL import Image
except Exception as e:  # pragma: no cover
    print(f"⚠️ 缺少 Pillow：{e}（pip install Pillow）", file=sys.stderr)
    Image = None

UA = "three-minute-movie-skill/1.2.0 (+footage fetch; respects source attribution)"

# 白名单：host -> 允许的来源分级（命中即 S1/S2/S3；未命中即 S4，拒绝）
ALLOWED_HOSTS = {
    "image.tmdb.org": "S2",
    "upload.wikimedia.org": "S3",
    "archive.org": "S3",
}
TRAILER_HOSTS = ("youtube.com", "youtu.be", "www.youtube.com", "m.youtube.com")


def _host_of(url):
    h = urllib.parse.urlparse(url).netloc.lower()
    return h[4:] if h.startswith("www.") else h


def _classify(url):
    host = _host_of(url)
    if any(host == t or host.endswith("." + t) for t in TRAILER_HOSTS):
        return "trailer", "S1"
    if host in ALLOWED_HOSTS:
        return "media", ALLOWED_HOSTS[host]
    return "blocked", "S4"


def _download(url, dest, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
    with open(dest, "wb") as f:
        f.write(data)
    return len(data)


def _safe_name(title, role, n, ext):
    base = "".join(ch for ch in title if ch.isalnum() or ch in " _-") or "movie"
    return f"{base}_{role}_{n}{ext}"


def _validate_image(path):
    if Image is None:
        return True, "skip"
    try:
        im = Image.open(path)
        im.verify()
        return True, f"{im.format}"
    except Exception as e:
        return False, str(e)


def fetch_one(url, role, tier, source, assets_dir, title, n, yt_dlp=False):
    kind, klass = _classify(url)
    if kind == "blocked":
        print(f"⛔ 拒绝下载（S4 非白名单来源）：{url}\n   本技能只用 S1/S2/S3，第三方搬运/盗版一律不用。")
        return None
    if kind == "trailer":
        cmd = f'yt-dlp -f "bv*+ba/b" "{url}" -o "{os.path.join(assets_dir, "clips", "{title}_official_trailer.%(ext)s")}"'
        print(f"🎬 trailer(S1 官方预告片) 不自动下载，请用 yt-dlp 获取：\n   {cmd}")
        if yt_dlp and shutil.which("yt-dlp"):
            clips_dir = os.path.join(assets_dir, "clips")
            os.makedirs(clips_dir, exist_ok=True)
            os.system(cmd)
            print("   （已尝试 yt-dlp 下载）")
        return {"role": "trailer", "tier": "S1", "source": source or "片方 YouTube 官方预告片",
                "url": url, "whitelisted": True, "downloaded": False,
                "note": "官方预告片须用 yt-dlp 下载；叠加解说后作 clip 使用"}
    # media (poster/still)
    ext = os.path.splitext(urllib.parse.urlparse(url).path)[1] or ".jpg"
    if ext.lower() not in (".jpg", ".jpeg", ".png", ".webp"):
        ext = ".jpg"
    out_dir = os.path.join(assets_dir, role + "s" if role != "poster" else "")
    os.makedirs(out_dir, exist_ok=True)
    dest = os.path.join(out_dir, _safe_name(title, role, n, ext))
    try:
        size = _download(url, dest)
    except Exception as e:
        print(f"⚠️ 下载失败：{url} -> {e}")
        return None
    ok, info = _validate_image(dest)
    if not ok:
        print(f"⛔ 下载文件非有效图片，已删除：{dest}（{info}）")
        try:
            os.remove(dest)
        except Exception:
            pass
        return None
    print(f"✅ 已下载 [{klass}] {role}: {dest} ({size} bytes, {info})")
    return {"role": role, "tier": klass, "source": source or klass,
            "url": url, "local": dest, "bytes": size, "format": info,
            "whitelisted": True, "downloaded": True}


def main():
    ap = argparse.ArgumentParser(description="白名单下载真实素材（S1/S2/S3，拒绝 S4）")
    ap.add_argument("--manifest", default="", help="search_footage.py 产出的 manifest.json")
    ap.add_argument("--url", default="", help="单条素材 URL（与 --manifest 二选一）")
    ap.add_argument("--role", default="still", help="单条角色：poster/still/trailer")
    ap.add_argument("--tier", default="", help="单条分级：S1/S2/S3（单条模式必填）")
    ap.add_argument("--source", default="", help="单条来源描述")
    ap.add_argument("--assets-dir", default="assets", help="素材输出目录")
    ap.add_argument("--title", default="", help="片名（用于命名，默认取 manifest）")
    ap.add_argument("--yt-dlp", action="store_true", help="trailer 尝试用 yt-dlp 下载")
    args = ap.parse_args()

    os.makedirs(args.assets_dir, exist_ok=True)
    fetched = []

    if args.manifest:
        with open(args.manifest, encoding="utf-8") as f:
            man = json.load(f)
        title = args.title or (man.get("movie") or {}).get("title") or "movie"
        for i, c in enumerate(man.get("candidates") or []):
            r = fetch_one(c["url"], c.get("role", "still"), c.get("tier", ""),
                          c.get("source", ""), args.assets_dir, title, i, args.yt_dlp)
            if r:
                fetched.append(r)
    elif args.url:
        if not args.tier:
            print("⚠️ 单条模式需 --tier S1/S2/S3", file=sys.stderr)
            sys.exit(6)
        r = fetch_one(args.url, args.role, args.tier, args.source,
                      args.assets_dir, args.title or "movie", 0, args.yt_dlp)
        if r:
            fetched.append(r)
    else:
        print("⚠️ 需提供 --manifest 或 --url", file=sys.stderr)
        sys.exit(6)

    if fetched:
        out_path = os.path.join(args.assets_dir, "footage_manifest.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump({"fetched": fetched, "fetched_at": _now()}, f,
                      ensure_ascii=False, indent=2)
        print(f"\n✅ 下载完成 {len(fetched)} 项，provenance 写入：{out_path}")
    else:
        print("⚠️ 没有成功下载任何素材。")


def _now():
    try:
        import datetime
        return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    except Exception:
        return ""


if __name__ == "__main__":
    main()
