# 真实素材查找封装（Footage Search · 内置脚本）

> 目标：把「真实电影静帧 / 预告片素材怎么找」这件事**做成技能里能直接跑的能力**，
> 而不是只在文档里写"去网上找"。两个脚本分工：查找 → 下载，全程只放行 S1/S2/S3，拒绝 S4。
> 配合 `clip_sourcing.md`（来源分级与版权护栏）与 `poster_sourcing.md`（海报）使用。

---

## 一、两个脚本

| 脚本 | 职责 | 依赖 |
|---|---|---|
| `scripts/search_footage.py` | 给定片名+导演+年份，**产出真实素材候选清单（manifest）** + 各来源查找链接 | 仅标准库（零额外依赖） |
| `scripts/fetch_footage.py` | 读 manifest（或单条 URL），**按 S1/S2/S3 白名单下载**静帧/海报，记录来源与版权，拒绝 S4 | 标准库 + Pillow（已在 requirements） |

> 两者都不引入新依赖；`TMDB_API_KEY` 是**可选增强**（有则直接拿剧照直链+官方预告片，无则输出查找链接）。

---

## 二、来源分级（与 clip_sourcing.md 一致）

| 级别 | 含义 | 白名单 host（fetch 放行） |
|---|---|---|
| **S1 官方预告片** | 片方/发行方 YouTube 官方 Trailer/Teaser | `youtube.com` / `youtu.be` |
| **S2 片方物料** | TMDB 官方剧照/海报（带署名，免费可用） | `image.tmdb.org` |
| **S3 公有领域/CC** | Wikimedia Commons / Internet Archive | `upload.wikimedia.org` / `archive.org` |
| **S4 第三方搬运** | 非官方切片号、网盘资源 | **一律拒绝下载** |

**硬规则**：`fetch_footage.py` 只下载白名单 host；命中 S4（非白名单）直接报错退出，**绝不静默绕过**。

---

## 三、用法

### 3.1 查找（search_footage.py）

```bash
# 有 TMDB key：自动拿到真实剧照直链 + 官方预告片链接
python scripts/search_footage.py --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014 \
    --tmdb-key $TMDB_API_KEY --out assets/footage_manifest.json

# 无 key：只输出各来源"可直接打开的查找链接"（模型/用户据此取素材）
python scripts/search_footage.py --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014
```

输出（manifest.json）字段：`movie` / `poster_url` / `trailer_url` / `candidates[]`（role/tier/source/url/whitelisted）/ `search_urls` / `recommendation` / `mode`。

### 3.2 下载（fetch_footage.py）

```bash
# 按 manifest 批量下载（只下 poster/still；trailer 给 yt-dlp 指令）
python scripts/fetch_footage.py --manifest assets/footage_manifest.json --assets-dir assets

# 单条下载（明确分级）
python scripts/fetch_footage.py --url https://image.tmdb.org/t/p/w1280/xxxx.jpg \
    --role still --tier S2 --source "TMDB 官方剧照" --assets-dir assets

# 顺带尝试用 yt-dlp 下官方预告片（需本机有 yt-dlp）
python scripts/fetch_footage.py --manifest assets/footage_manifest.json --assets-dir assets --yt-dlp
```

下载结果写入 `assets/footage_manifest.json`（含 provenance：`url` / `source` / `tier` / `local` / `bytes` / `format`），交付时如实说明来源与版权。

> trailer（S1）不内置下载，改输出 `yt-dlp` 指令——避免绕过平台下载条款；仅 `--yt-dlp` 显式开启且本机有 yt-dlp 时才尝试。

---

## 四、agent 调用方式（工作流里的落点）

- **Step 5（海报）**：先用 `search_footage.py` 找名场面静帧（S2 TMDB 剧照 / S3 Wikimedia）→ `fetch_footage.py` 下载 → 交给 `make_poster.py --source <静帧>` 合成名场面海报。
- **Step 5b（切片+名场面）**：`search_footage.py` 找 hook/ending 的官方预告片（S1）、core 段的名场面静帧（S2/S3）→ `fetch_footage.py` 下载 → 写入分段 JSON 的 `clip` / `still` 字段 → `render.py` 合成。
- 拿不到合规素材时回退海报/大字卡（不整条纯文字卡），交付如实说明哪些段用了真实画面、来自哪一级来源。

---

## 五、红线

1. 不用 S4（第三方搬运/盗版）；`fetch_footage.py` 会硬拒绝非白名单 host。
2. 真实片段/静帧必须叠加解说/字幕/观点，不得原片静默连放。
3. 商用前自行确认授权；TMDB/Wikimedia 来源须保留署名。
4. 查找失败不静默假装"有素材"——交付时如实说明来源与缺失。
