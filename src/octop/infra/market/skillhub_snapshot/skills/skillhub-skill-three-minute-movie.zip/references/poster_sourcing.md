# 海报获取三级降级策略（Poster Sourcing）

> 目标：让海报这件事**有一套确定性流程**，而不是每次临场发挥。
> 三条来源**互斥**、**优先级严格**，一次任务只产出**一个** `source_type`，写进海报 meta 并交付给用户。

---

## 一、三条来源：互斥 + 严格优先级

| 级别 | `source_type` | 触发条件 | 互斥规则 |
|---|---|---|---|
| **L1 真实搜索** | `real_search` | 用户**未**提供海报图时，先检索公开海报接口 | 命中即终止，不再走 L2 / L3 |
| **L2 用户上传** | `user_upload` | L1 失败（网络 / 质量 / 无结果）→ 引导上传；或用户一开始就给了图 | 用户已给图时**直接采用**，跳过 L1 搜索 |
| **L3 自绘 / AI 生成** | `ai_generated` | L2 未上传，或用户主动选择「跳过」 | 兜底，必须标注「AI 生成 / 自绘」，不得冒充官方海报 |

**决策顺序（严格按此执行，不得跳级）**：

```text
用户已提供海报图？
├─ 是 → L2 user_upload（校验 → 规范化 → 入库），结束
└─ 否 → L1 real_search（WebSearch 找候选 URL → fetch_poster.py 下载校验）
        ├─ 通过 → L1 real_search，结束
        └─ 失败 → 引导用户上传（给出格式/比例/分辨率要求 + 明确的「跳过」选项）
                 ├─ 用户上传且校验通过 → L2 user_upload，结束
                 └─ 未上传 / 主动跳过 → L3 ai_generated（make_poster.py 自绘 / ImageGen），结束
```

**L3 默认兜底说明**：`make_poster.py` 自绘竖版海报卡**零额度、零风险、必定可用**，作为 L3 的默认兜底；若当前环境已接入 ImageGen，也可调用其生成（须同样标注 `ai_generated`）。无论哪种，都**不得**冒充片方官方海报。

**互斥的硬约束**：
- 一次任务只写**一个** `source_type` 到海报 meta，不得同时存在两个来源。
- 禁止把 AI 生成图或未核实来源的图标成 `real_search`。
- 缓存命中的来源类型沿用首次获取时的类型，不因复用而改变归属。

---

## 二、L1 · 真实搜索

### 2.1 分工（模型 vs 脚本）

| 环节 | 谁做 | 具体动作 |
|---|---|---|
| 检索候选 | **模型** | 用 `WebSearch` 按「片名 + 导演 + 年份」检索，收集 **2–5 个候选图片 URL**，记录来源域名 |
| 下载校验 | **脚本** | `scripts/fetch_poster.py --url ... --url ... --year ... --title ... --out ...` |
| 视觉复核 | **模型** | `needs_visual_check=true` 时必须看图确认：是这部电影的海报、无水印、无第三方品牌 |

> 安全：脚本仅接受 `http` / `https` 协议的 URL（`file://` 等本地协议会被拒绝），候选 URL 来自模型检索结果，不支持任意本地路径读取。

### 2.2 公开源清单（按推荐顺序尝试）

| # | 源 | 用法 | 备注 |
|---|---|---|---|
| 1 | TMDB 海报 | `https://image.tmdb.org/t/p/w780/{poster_path}`（需先查 `themoviedb.org` 拿 poster_path） | 无水印、免费；竖版 2:3，质量高 |
| 2 | 豆瓣电影条目页 | WebSearch 找条目 → 海报图床 URL | 中文片覆盖好；常反爬，失败即换源 |
| 3 | IMDb 海报 | WebSearch 找 `title.images` → 海报直链 | 外语片覆盖好 |
| 4 | 片方 / 票务详情页 | WebSearch 找条目页，取 `og:image` / 主图 | 猫眼、淘票票、院线官网等 |
| 5 | 通用图片搜索 | Bing / DuckDuckGo 图片 | **必须视觉复核**：容易命中同人图、二创海报、盗版资源图 |

> 实践提示：部分环境**外网受限**（代理对某些域名返回 502）。此时不要死等，按异常处理矩阵直接降级到 L2。

### 2.3 执行命令

```bash
python scripts/fetch_poster.py \
    --url <候选1> --url <候选2> \
    --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014 \
    --out <工作目录>/assets/poster.png
```

脚本按序尝试候选，**第一个通过质量校验的胜出**；全部失败则输出错误明细（每个 URL 的失败原因）并返回对应退出码。

---

## 三、质量校验阈值

| 校验项 | 类型 | 阈值 | 失败码 |
|---|---|---|---|
| 文件格式 | 硬 | JPG / PNG / WEBP | `ERR_FILE` |
| 协议 | 硬 | 仅 `http` / `https` | `ERR_FILE` |
| 长边分辨率 | 硬 | ≥ **800 px**（推荐 ≥ 1000 px，低于则 warning） | `ERR_QUALITY` |
| 宽高比（w/h） | 硬 | **0.45 – 1.30**（海报多为 0.66 竖版，兼容 1:1） | `ERR_QUALITY` |
| 文件完整性 | 硬 | 可被 PIL 解码 | `ERR_FILE` |
| 最小体积 | 硬 | ≥ 5 KB（排除占位图） | `ERR_QUALITY` |
| 白底占比 | 软 | > 50% 判定为白底图 → **自动裁边 + 圆角** | warning |
| 水印 / 内容匹配 | 软 | 由模型视觉复核 | 换源 |

白底图不必拒绝——`fetch_poster.py` 会自动裁掉外围白边并切圆角，输出规范化的 RGBA PNG。

---

## 四、L2 · 引导用户上传（提示文案模板）

L1 失败时用 `AskUserQuestion` 给出**两个选项**（不要只发一句"请上传"）：

- 选项 A：**我现在上传海报**
- 选项 B：**跳过，用自绘 / AI 海报**

配套说明文案（可直接引用）：

```text
没找到《{片名}》的合格真实海报（原因：{网络不可达 / 分辨率不足 / 图不对}）。
你可以直接发一张海报图给我：
  · 格式：JPG / PNG / WEBP
  · 建议比例：竖版 2:3（如 1000×1500）
  · 最低要求：长边 ≥ 800px（低于此值会被判为不达标）
也可以选「跳过」——我用自绘卡 / AI 生成一张示意海报，会明确标注「自绘 / AI 生成」，不会冒充片方官方海报。
```

上传后入库：

```bash
python scripts/fetch_poster.py --local <用户图片> --title 星际穿越 --director "..." --year 2014 \
    --out <工作目录>/assets/poster.png
```

若用户图不合规（损坏 / 分辨率不足 / 比例异常），脚本会给出**具体原因**（例如"分辨率不足：400×600，要求长边 ≥ 800px"），模型据此提示用户**重新上传**或改走 L3。

---

## 五、L3 · 自绘 / AI 生成（兜底）

**名场面合成（本技能推荐，`make_poster.py --source`）**：
1. 用一张**名场面静帧**（`--source`）合成竖版 850×1212 海报：静帧 cover 铺满 + 电影感调色 + 顶/底压暗 scrim + 片名/导演/年份/类型/标语大字排版。这样海报是「这部电影的一个名场面 + 片名」，而不是单调的纯文字卡。
2. 名场面静帧须来自合规来源（官方预告片帧 / 授权剧照 / 用户自有截图，分级同 `clip_sourcing.md` 的 S1/S2/S3）；用 `scripts/search_footage.py` + `scripts/fetch_footage.py` 查找下载（只放行 S1/S2/S3 白名单，拒绝 S4），详见 `references/footage_search.md`。
3. 无 `--source` 时回退为自绘渐变卡（零额度、零风险兜底）：只画公开可确认信息（片名/年份/导演/类型/标语），**不得**编造评分/票房/奖项。
4. 生成后入库标注来源（`source_type` 按静帧实际来源填 `real_search` / `user_upload` / `ai_generated`）：

```bash
# 推荐：名场面静帧合成
python scripts/make_poster.py --source <名场面静帧.jpg> --title 星际穿越 --year 2014 \
    --director "克里斯托弗·诺兰" --genre "科幻,冒险,剧情" \
    --tagline "爱是唯一可以穿越时空的东西" --theme cinema --out <工作目录>/assets/poster.png

# 兜底：无静帧时自绘卡
python scripts/make_poster.py --title 星际穿越 --year 2014 --director "克里斯托弗·诺兰" \
    --genre "科幻,冒险,剧情" --tagline "爱是唯一可以穿越时空的东西" \
    --theme cinema --out <工作目录>/assets/poster.png

python scripts/fetch_poster.py --local <海报图> --source <来源类型> \
    --title 星际穿越 --director "..." --year 2014 --out <工作目录>/assets/poster.png
```

**AI 生成（环境已接入 ImageGen 时可选）**：
1. 竖版优先（如 `1024x1536`），与视频主题色协调。
2. **必须包含片名文字**（中文片名 + 可选英文原名），不得只有抽象插画。
3. **不得**包含：可识别的第三方 IP、真实人物肖像、片方 LOGO、其他电影海报元素、二维码/水印文字。
4. 生成后**必须入库标注来源**（同上 `--source ai_generated`）。
5. 交付时**必须**说明：这是 AI 生成的示意海报，非片方官方海报；商用请替换为授权海报。

> 额度提示（仅 AI 生成路径）：图像生成会产生额外额度消耗，**调用前必须先告知用户**并获得确认。

---

## 六、异常处理矩阵

| 场景 | 错误码 | 退出码 | 给用户的提示 | 重试入口 |
|---|---|---|---|---|
| 网络不可达 / 超时 / 代理拒绝 / HTTP 5xx | `ERR_NETWORK` | 2 | 「海报源连不上（代理/网络限制），可以换源重试或直接上传海报」 | 换源重跑 / `--force` / 直接上传 |
| HTTP 404 / 403（该源没有这部片） | `ERR_NOTFOUND` | 5 | 「这个源没有《片名》的海报」 | 换源 / 上传 |
| 分辨率不足 / 比例不符 | `ERR_QUALITY` | 3 | 「找到的图只有 400×600，达不到 800px 长边，画面会糊」 | 换源 / 上传更高清图 |
| 文件损坏 / 格式不支持 / 协议非法 | `ERR_FILE` | 4 | 「这张图打不开或格式支持（仅 JPG/PNG/WEBP，且须为 http/https 链接）」 | 重新上传 / 换源 |
| 缓存未命中（`--from-cache`） | `ERR_NOTFOUND` | 5 | — | 正常走 L1 |
| 参数缺失 | `ERR_ARGS` | 6 | — | 补齐 `--title` 或 `--year` |

**错误处理原则**：错误必须**可理解**（说清是哪个源、什么原因、下一步怎么办），并且**必须给出重试入口**，不允许静默失败或静默回退成片名大字卡。

---

## 七、缓存策略

- **目录**：默认系统缓存目录（Windows `%LOCALAPPDATA%/three-minute-movie`、macOS `~/Library/Caches/three-minute-movie`、Linux `~/.cache/three-minute-movie`），可用 `--cache-dir` 覆盖。
- **缓存键**：优先 `片名|年份`（去噪后 + md5 短戳）；无年份时用 `片名|导演`。
- **命中行为**：直接复用本地文件，**不发任何网络请求**；meta 中 `cache_hit: true`。
- **失效方式**：`--force` 强制重新获取；或删除对应缓存目录。
- **收益**：同一部片反复出片（改文案重渲）不会重复请求外部源。

```bash
python scripts/fetch_poster.py --from-cache --title 星际穿越 --year 2014
```

---

## 八、海报 meta 输出字段（写入 `<out>.poster.json`）

```json
{
  "poster_path": "/abs/path/assets/poster.png",
  "poster_url": "https://image.tmdb.org/t/p/w780/abc.jpg",
  "source_type": "real_search",
  "source_host": "image.tmdb.org",
  "copyright": "来源：image.tmdb.org（公开电影海报接口）。海报受版权保护，仅用于电影介绍与二次创作；商用前请自行确认授权。",
  "quality": {
    "width": 780, "height": 1170, "ratio": 0.667, "format": "JPEG",
    "bytes": 142033, "white_ratio": 0.1, "white_bg": false,
    "warnings": [], "normalized_size": [780, 1170]
  },
  "movie": { "title": "星际穿越", "director": "克里斯托弗·诺兰", "year": "2014" },
  "cache_key": "星际穿越-2014-xxxx",
  "cache_hit": false,
  "needs_visual_check": true,
  "fetched_at": "2026-10-10T14:50:00+08:00"
}
```

### 三档版权说明模板（由脚本按 `source_type` 自动填充）

| source_type | copyright 模板 |
|---|---|
| `real_search` | 来源：{host}（公开电影海报接口，如 TMDB / IMDb / 豆瓣）。海报受版权保护，仅用于电影介绍与二次创作；**商用前请自行确认授权**（商用须取得片方 / 发行方书面授权）。 |
| `user_upload` | 来源：用户上传。**请确认你对该图片拥有使用授权**。 |
| `ai_generated` | 来源：**自绘 / AI 生成（非官方海报）**。画面不含第三方受版权保护素材，仅作示意，**不得冒充片方官方海报**；商用请替换为授权海报。 |

交付汇报时必须带上 `source_type` 与 `copyright`，让用户知道海报从哪来、能不能商用。

---

## 九、红线

1. 不得把 AI 生成图或未核实来源的图标成真实海报。
2. 不得使用盗版资源图、带第三方水印的图、或明显来自他人设计的素材。
3. 商用场景必须提示用户自行确认授权。
4. 网络失败时**不得静默回退**——要么换源重试，要么明确告知用户并进入下一级降级。
