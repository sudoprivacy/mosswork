---
name: skillhub-skill-three-minute-movie
description: "输入片名+导演（或年份），锁定唯一影片并生成 3 分钟五段式电影解说台词，一键产出竖屏 9:16 电影解说短视频（MP4）。把一部电影拆成一条 3 分钟竖屏解说：先由大模型按「片名+导演/年份」精准锁定影片，再按五段式（钩子/设定/核心看点/导演背景/观看理由）产出 640-820 字不剧透口语台词，自检后一键渲染素材主导成片（名场面海报 + 电影切片）。触发：电影解说、3分钟看完、讲电影、电影推荐、这部电影讲什么。"
---

# 3分钟看完一部电影

## 一、定位与归属

- **技能类型**：内容生产类 / 短视频自动化生成 Skill。
- **标签组**：视频生成 / 电影解说 / 短视频。
- **目标**：**片名进、解说台词出**的端到端电影解说流水线——用户只给片名与导演（或年份），产出一条可直接发布的 3 分钟竖屏 9:16 电影解说短视频。
- **核心能力链**：`片名 → 锁定影片 → 五段式台词 → 海报 → 配音 → 合成 → 成片交付`。
- **成本约束**：配音（edge-tts）与 BGM（Mixkit 免费曲库）均免费，**不依赖任何付费 API、无需 key**。但需注意：edge-tts 是调用微软云端 TTS（联网）、BGM 需从 Mixkit 下载、海报 L1 真实搜索需联网——**断网环境无法完成配音与联网取海报**。
- **成片形态**：竖屏 9:16 **素材主导画面**——海报用**影片名场面静帧**合成（不再是单调的自绘文字卡），整片画面**默认由电影素材驱动**：钩子 / 结尾用**真实预告片切片（视频）**铺底 + 解说字幕，**每个核心看点段都用对应的「名场面静帧」+ 大字金句 + 字幕**，导演 / 设定段也尽量配名场面；低沉 BGM 垫底。一句话：**海报是名场面、画面是切片/名场面，几乎不出现纯文字卡**。来源与版权护栏见 `references/clip_sourcing.md`（动 + 静帧）、`references/poster_sourcing.md`（海报）。
- **基因**：**电影解说 / 安利（spoiler-light）**，不剧透结局。让观众"看懂这部电影好在哪、该不该看"，而不是"替他把电影看完"。

## 二、适用与触发场景

**适用**：单部电影的 3 分钟解说 / 安利口播；影视号、电影推荐号的日常更新；看完一部电影做成一条短视频。

**触发词**（命中任一即启用）：电影解说、3分钟看完、讲电影、把《XX》讲成视频、这部电影讲什么、做个电影解说的短视频、电影推荐、安利一部电影。

**不适用（NOT for）**：

- 需要真人出镜口播；
- 非电影类内容（剧集 / 综艺单集 / 纪录片系列）；
- 多部电影横向盘点（本技能只讲单部）；
- 需要复杂分镜 / 动画的解说视频；
- **剧透向逐幕速览**（本技能只讲看点、不替观众把电影看完；结局、凶手、终极反转一律不剧透）。

## 三、输入参数

| 参数      | 必填       | 默认值                            | 说明                                                                            |
| ------- | -------- | ------------------------------ | ----------------------------------------------------------------------------- |
| 片名      | ✅        | —                              | 单部影片名                                                                         |
| 导演 / 年份 | 选填（用于锁定） | 模型推断                           | 同名片多时用于唯一锁定，交代背景                                                              |
| 海报图片    | 选填       | 三级降级自动获取                       | **L1 真实搜索 → L2 引导上传（可跳过）→ L3 AI 生成**，三源互斥；规则见 `references/poster_sourcing.md` |
| 时长      | 选填       | 3 分钟（约 180s）                   | 五段式固定节奏，由台词字数自然决定                                                             |
| 音色      | 选填       | `zh-CN-YunjianNeural`（云健，沉稳男声） | 备选见 `references/platforms.md`                                                 |
| BGM     | 选填       | Silent Descent（默认曲）            | 免费曲库见 `references/platforms.md`                                               |
| 片头海报卡   | 选填       | 2.0s                           | 配置 `intro_cover` + `intro_seconds`，视频最前面展示放大海报                                |

**原则**：只有片名是必须的；其余一律走默认值，不打断用户。缺失信息由模型做合理假设并**在交付时明确告知**，不因追问而停滞。

## 四、分步工作流（严格遵守）

### Step 1 · 锁定唯一影片（本技能第一道闸口，不可跳过）

大模型依据「片名 + 导演/年份」精准锁定唯一影片，输出一张**影片确认卡**：

```text
片名：《星际穿越》
导演：克里斯托弗·诺兰
年份 / 类型：（能确认则填，不能确认写"未确认"）
一句话定位：把"爱"拍成物理定律的硬核科幻
可讲的核心看点（1 个）：用一段父女对讲机通话，让引力有了温度
```

- 若片名存在**同名 / 近似片**（如《无间道》有港版与美版翻拍），或导演与片名匹配存疑，**必须先向用户确认**再继续，禁止凭猜测开写。
- 若该导演确实拍过此片但模型无法确认其内容细节，**不得编造具体情节、金句原文、评分与票房**；应改用公开可确认的常识性定位，或在确认卡中标注"内容细节待确认"。

### Step 2 · 收集参数

片名已给即用；导演/年份、海报、音色、BGM 未指定则走默认值。一次问清，不重复追问。

### Step 3 · 撰写五段式台词（本技能的核心价值）

按 `references/copywriting.md` 的规范写。结构**固定为五段**，总字数**硬控 640–820 字**：

| 段落            | 时间       | 字数        | 任务                                            |
| ------------- | -------- | --------- | --------------------------------------------- |
| ① 钩子 hook     | 0–10s    | 35–70 字   | 反常识 / 痛点共鸣 / 悬念前置                             |
| ② 设定 premise  | 10–45s   | 100–180 字 | **不剧透**地说清"它讲什么"（谁、在哪、卷入什么）                   |
| ③ 核心看点 core   | 45–140s  | 300–420 字 | **只讲 1–2 个**看点，用名场面讲道理，给出 1 句≤30字金句（可拆 2–3 段） |
| ④ 导演背景 maker  | 140–165s | 80–140 字  | 交代"他凭什么拍它" + 一点幕后语境，**不念简历**                  |
| ⑤ 观看理由 ending | 165–180s | 35–70 字   | 给**具体**的观看理由，**不剧透**                          |

产出两份内容：

1. **口播全文**（五段，纯口语）；
2. **分段表**（分镜 6–11 段：核心看点段可拆 2–3 段以保持视觉节奏），每段给 `section` / `headline`（5–14 字大字）/ `text`（该段口播）/ `show_cover`。

> **语速校准（实测，务必照此估算）**：edge-tts 云健男声 `--rate +5%` ≈ **245–255 字/分钟**，`+0%` ≈ **240 字/分钟**（字数按"汉字+英文词+数字串，不含标点"计）。  
> 因此 640–820 字 → `+5%` 约 **155–200s**，`+0%` 约 **160–205s**。**操作结论：写满 ~720 字用 `--rate +5%` 即可贴 180 秒（加 2s 片头海报 + 1s 留白 → 成片约 176s）；只有短稿才降到 `--rate=-5%`（注意用 `--rate=-5%` 等号写法，避免被 argparse 当成选项）。**  
> **字数硬指标（640–820 字）优先于时长**——不得为凑时长注水，也不得为压字数砍掉名场面与金句。  
> **非中文片**：默认音色为 `zh-CN-*`，解外语片时请改用对应语种 voice（如英文 `en-US-GuyNeural`），否则会串味。  
> **不剧透红线**：premise / core / ending 都不得泄露结局、凶手、终极反转。

### Step 4 · 完稿自检（写完立即执行，不通过必须改）

逐条对照 `references/selfcheck.md` 的 10 项清单，并**必须运行脚本做机械校验**：

```bash
python scripts/check_script.py --script <分段json>
```

脚本会校验字数、段数、段式覆盖、禁用开场、金句存在性与位置、各段字数容差、标题字数、空泛结尾与剧透红线（详见 References）。**任一 ❌ 项必须修改后重跑**，不得带着 ❌ 进入配音环节。自检通过后，把台词与分段表展示给用户确认。

### Step 5 · 海报获取（三级降级）+ 配音

海报**必须**走三级降级；完整规则、源清单、校验阈值、提示文案模板与异常处理矩阵见 `references/poster_sourcing.md`。  
三条来源**互斥**、优先级**严格**，一次任务只产出**一个** `source_type`：

| 级别                | `source_type`  | 触发条件             | 执行方式                                                                                                                                          |
| ----------------- | -------------- | ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| **L1 真实搜索**       | `real_search`  | 用户**未**提供海报图     | 模型用 `WebSearch` 找 2–5 个候选 URL → `fetch_poster.py` 下载并校验（长边 ≥800px、宽高比 0.45–1.30、可解码）；命中即终止                                                    |
| **L2 用户上传**       | `user_upload`  | L1 失败；或用户一开始就给了图 | 用户已给图则**直接采用**（跳过 L1）。L1 失败时用 `AskUserQuestion` 引导上传，给足「JPG/PNG/WEBP · 建议竖版 2:3 · 长边 ≥800px」，并**必须提供「跳过」选项**                                  |
| **L3 自绘 / AI 生成** | `ai_generated` | 未上传 / 主动跳过       | 优先用 `make_poster.py` 自绘竖版海报卡（零额度、零风险兜底）；若环境已接入 ImageGen 也可用其生成（`make_poster.py` 自绘始终可用，作为 L3 默认兜底，避免静默失败）。两者**都必须标注 `ai_generated`**，不得冒充官方海报 |

```bash
# L1 真实搜索（模型先用 WebSearch 找候选，再交给脚本）
python scripts/fetch_poster.py --url <候选1> --url <候选2> \
    --title "星际穿越" --director "克里斯托弗·诺兰" --year 2014 \
    --out <工作目录>/assets/poster.png

# L2 用户上传入库（自动裁白边 + 圆角）
python scripts/fetch_poster.py --local <用户图> --title "星际穿越" --director "..." --year 2014 \
    --out <工作目录>/assets/poster.png

# L3 自绘海报卡 / AI 生成图入库（须显式标注来源）
python scripts/make_poster.py --title 星际穿越 --year 2014 --director "克里斯托弗·诺兰" \
    --genre "科幻,冒险,剧情" --tagline "爱是唯一可以穿越时空的东西" \
    --theme cinema --out <工作目录>/assets/poster.png

python scripts/fetch_poster.py --local <生成图> --source ai_generated --title "星际穿越" \
    --out <工作目录>/assets/poster.png
```

**硬性要求（违反即为流程事故）**：

1. **互斥**：一次任务只写一个 `source_type`，写入 `<out>.poster.json`（含 `poster_path` / `poster_url` / `source_type` / `copyright` / `quality`）。禁止混用，禁止事后改归属。
2. **不许静默回退**：网络失败、质量不达标、上传损坏，都要按 `poster_sourcing.md` 的异常处理矩阵给出**可理解的原因 + 重试入口**（换源 / 重新上传 / 跳到 L3），**不得**一声不响换成片名大字卡。
3. **必须缓存**：`fetch_poster.py` 按 `片名|年份`（无则 `片名|导演`）缓存到系统缓存目录（默认 `~/.cache/three-minute-movie` 或 `%LOCALAPPDATA%/three-minute-movie`），命中即复用（`cache_hit: true`），不重复请求外部源。可用 `--cache-dir` 覆盖。
4. **必须告知来源**：交付汇报带上 `source_type` 与 `copyright`，让用户知道海报从哪来、能否商用。
5. **视觉复核**：`needs_visual_check: true`（L1）时，模型必须真的看图确认是这部电影、无水印，再进渲染。
6. 用户海报多为白底 JPG，`fetch_poster.py` 会自动裁白边 + 切圆角；单独用 `prep_poster.py --pad 8 --radius 20` 亦可。自绘卡只写可公开确认的信息（片名/年份/导演/类型/标语），**不得**编造评分、票房、奖项。

- **配音**：`scripts/tts.py` 逐段生成 mp3 并产出精确时间轴（含网络失败自动重试）：

```bash
python scripts/tts.py --script <分段json> --out <工作目录>/voice --voice zh-CN-YunjianNeural --rate +5%
```

### Step 5b · 电影切片 + 名场面（素材主导画面，默认必须）

**真实素材怎么找（已封装进技能，默认必须走这步）**：用 `scripts/search_footage.py` 按片名+导演+年份查找真实静帧/预告片候选——有 `TMDB_API_KEY`（可选，免费）时直接拿剧照直链+官方预告片链接，无 key 时输出 S1/S2/S3 各来源可直接打开的查找链接；再用 `scripts/fetch_footage.py` 按白名单下载（只放行 S1/S2/S3，拒绝 S4），把结果写进分段 JSON 的 `clip` / `still`。完整用法、来源分级、白名单与红线见 `references/footage_search.md`。

```bash
# 1) 查找：输出 manifest（候选直链 / 各来源链接）
python scripts/search_footage.py --title 星际穿越 --director "克里斯托弗·诺兰" --year 2014 \
    --tmdb-key $TMDB_API_KEY --out assets/footage_manifest.json
# 2) 下载：白名单内 fetch（poster/still 落地，trailer 给 yt-dlp 指令）
python scripts/fetch_footage.py --manifest assets/footage_manifest.json --assets-dir assets
```

**策略**：整片画面默认由电影素材驱动。每段可带 `clip`（电影切片视频）或 `still`（名场面静帧图）——画面优先级 `clip > still > 海报 > 大字卡`。`hook` / `ending` **强烈建议用 `clip`**（视频切片，最有真实感、最影响完播）；`core` / `premise` / `maker` **用 `still`**（名场面静帧），让每个看点都落在具体画面上。完整来源分级、版权护栏、字段规格、异常处理见 `references/clip_sourcing.md`。

**来源优先级（只取其一来源类型，禁用第三方搬运 / 盗版）**：

| 级别            | 来源                             | 版权     | 默认用法              |
| ------------- | ------------------------------ | ------ | ----------------- |
| **S1 官方预告片**  | 片方/发行方官方账号发布的 Trailer / Teaser | **最高** | **默认首选**，最稳       |
| **S2 片方物料**   | 官方幕后特辑 / 授权正片片段                | 高      | 确认官方发布即可用         |
| **S3 自购片源切片** | 自己购买/租赁片源后截的片段                 | 中      | 单段 ≤5s、叠加解说、标片名导演 |

**在分段表里加 `clip`**（仅 hook / ending 等片段段；`show_cover` 设为 false，避免片段上再叠海报）：

```json
{"section":"hook", "headline":"没有外星人",
 "text":"都说科幻片靠怪物吓人。诺兰拍了十年烧钱科幻，公认最吓人的那部，连一个外星人都没有。",
 "show_cover":false,
 "clip":{"src":"assets/clips/星际穿越_预告片.mp4","in":8.0,"dur":4.5,"fit":"cover"}}

{"section":"ending", "headline":"一个人看完",
 "text":"如果你也曾在异地，对着屏幕说过我很快就回来，这部片子，值得你一个人，安静地看完。",
 "show_cover":false,
 "clip":{"src":"assets/clips/星际穿越_名场面_对讲机.mp4","in":0,"dur":4.0,"fit":"cover"}}
```

- `src` 写绝对路径，或相对 `config.json` 所在目录的相对路径（`render.py` 自动解析）；`in`=从源第几秒截；`dur`=截多少秒（建议 = 该段口播时长，最长不超该段）；`fit`=`cover`（满屏裁切，推荐）/ `contain`（留黑边）。
- **片段音频会被静音**，配音（edge-tts）压在画面上，不会两层声音打架。
- **缺失自动回退**：`clip.src` 文件不存在或省略 → 该段回退海报 / 大字卡，并打印 `⚠️ 片段缺失，跳过`，不中断整条渲染。
- 交付时必须如实说明哪些段用了真实画面、片段来自哪种来源（S1/S2/S3）。

**在分段表中加 `still`**（名场面静帧；`core` / `premise` / `maker` 等段；`show_cover` 可设 true 也可省略，render 会优先用 still 铺底）：

```json
{"section":"core", "headline":"对讲机那头",
 "text":"看那段对讲机。女儿从十岁长到二十岁，父亲在飞船上只老了几年。",
 "show_cover":true,
 "still":"assets/stills/星际穿越_对讲机.png"}

{"section":"premise", "headline":"农夫与星空",
 "text":"库珀是个种玉米的农夫，也是个工程师。地球在枯萎，沙尘暴一年比一年狠。",
 "show_cover":false,
 "still":"assets/stills/星际穿越_玉米地沙尘暴.png"}
```

- `still` 写绝对路径或相对 `config.json` 目录的路径；建议来自官方预告片帧 / 授权物料 / 用户自有截图（来源分级同 `clip`，见 `clip_sourcing.md` 的「名场面静帧」一节）。
- 画面优先级：`clip`（视频切片）> `still`（名场面静帧）> 共用 `cover` 海报 > 大字卡。一段同时有 `clip` 和 `still` 时取 `clip`。
- `still` 段会做 Ken Burns 缓慢推近 + 淡入淡出，叠大字金句与字幕，视觉上就是「名场面 + 解说」，不再是单调文字卡。
- `still` 缺失 → 该段回退海报 / 大字卡，并打印 `⚠️ 名场面静帧缺失，跳过`。

> **素材主导是默认要求**：钩子 / 结尾必须用 `clip` 切片；核心看点段务必给 `still` 名场面（没有合规静帧时再回退海报，但不可整条都是纯文字卡）。版权面控制靠「只用 S1/S2/S3 来源 + 单段切片 ≤5s + 全片真实画面占比 ≤30% + 叠加解说」，详见 `clip_sourcing.md`。

### Step 6 · 合成 + 质检 + 交付

```bash
python scripts/render.py --config <合成配置json> --out <输出mp4>
```

1. 用 ffmpeg 校验：分辨率（默认 1080×1920，可在 config 用 `width`/`height` 改，如小红书 1080×1440、B站横屏 1920×1080）、30fps、H.264 + AAC、时长≈目标值。
2. 抽 3 帧（开头 / 中段 / 结尾）确认大字无越界、海报无变形、字幕无错字与行首标点。
3. 调用 `present_files` 交付成片，并汇报：时长 / 分辨率 / 音色 / BGM / 可调整项（换音色、改文案重渲、换主题色）。

## 五、台词撰写规则（摘要，完整版见 `references/copywriting.md`）

1. **钩子禁用开场**：禁止「今天给大家推荐一部电影」「今天给大家带来一部」等。用反常识、痛点共鸣或悬念前置切入，第一句就要让人停下。
2. **只讲 1–2 个看点**：核心看点段**只能有 1–2 个**主张。出现第 3 个即不合格——解说不是剧情复述。
3. **用名场面讲道理**，不做概念堆砌。先给一个观众能代入的具体场景/镜头，再从场景里长出观点。
4. **必须产出一句"社交货币"金句**：≤30 字、脱离上下文也能被转述、听完想截图或转述给别人。在分段表中把该段标记为 `"punchline": true`（且须置于 `core` 段）。
5. **导演交代只说两件事**：凭什么拍它 + 一点幕后语境（他怎么做到的），**不念简历**（不列履历表、不罗列获奖年表）。
6. **结尾给具体理由**，不说「值得一看」「强烈推荐」这类空话。要落到具体的人、具体的场景、具体的动作，**且不剧透结局**。
7. **口语化**：像与朋友聊天，短句为主（单句 ≤18 字），能用数字就用数字；避免书面语过重，避免脱离上下文的孤立摘句。
8. **不剧透**：premise / core 不泄露结局、凶手、终极反转；名场面可讲"发生什么"，不可讲"导致的结果"。
9. **不做虚假夸大**：评分、票房、获奖须真实可核查，禁用「必看」「封神」「神作」等极限词。

## 六、完稿自检清单（10 项，完稿即执行）

| #  | 检查项              | 判定标准                                                  | 校验方式         |
| -- | ---------------- | ----------------------------------------------------- | ------------ |
| 1  | 钩子是否有效           | 首句为反常识 / 痛点共鸣 / 悬念；无禁用开场白                             | 脚本 + 人工      |
| 2  | 段式是否齐全           | `hook` / `premise` / `core` / `maker` / `ending` 五类齐全 | 脚本           |
| 3  | 设定是否不剧透且具体       | 有具体人/处境/冲突，无结局泄露                                      | 人工（+ 结尾剧透扫描） |
| 4  | 核心看点是否 1–2 个且场景化 | 只有 1–2 个主张；有具体名场面支撑                                   | 人工           |
| 5  | 用户能否一句话复述        | 存在 `punchline`（在 core 段）金句且 ≤30 字、脱离上下文仍成立            | 脚本 + 人工      |
| 6  | 导演交代是否精简         | 导演段 80–140 字，只讲凭什么拍 + 幕后，无简历罗列                        | 脚本           |
| 7  | 结尾理由是否具体且不剧透     | 落到具体人/场景/动作，非空话，无结局泄露                                 | 脚本 + 人工      |
| 8  | 总字数是否达标          | 口播全文 640–820 字（汉字+英文词+数字串，不含标点）                       | 脚本           |
| 9  | 标题字数与分段数         | 每段 headline 5–14 字；分段 6–11 段                          | 脚本           |
| 10 | 不剧透红线            | premise/core/ending 不泄露结局、凶手、终极反转                     | 人工 + 结尾脚本扫描  |

完整判定细则、不合格示例与修改示范见 `references/selfcheck.md`。脚本共 10 项机械校验（含按段字数预算与剧透扫描），语义类判定（看点数、场景化、口语度、不剧透程度）由模型与人工完成。

## 七、输出格式示例

### 7.1 台词与分段表（`segments.json`）

```json
[
  {"section":"hook",    "headline":"没有外星人",
   "text":"都说科幻片靠怪物吓人。诺兰拍了十年烧钱科幻，公认最吓人的那部，连一个外星人都没有。",
   "show_cover":false,"clip":{"src":"assets/clips/星际穿越_预告片.mp4","in":8.0,"dur":4.5,"fit":"cover"}},
  {"section":"premise","headline":"农夫与星空",
   "text":"库珀是个种玉米的农夫，也是个工程师。地球在枯萎，沙尘暴一年比一年狠。他得在陪孩子长大，和替人类找一条活路之间，选一个。","show_cover":false,"still":"assets/stills/星际穿越_玉米地沙尘暴.png"},
  {"section":"core",    "headline":"对讲机那头",
   "text":"看那段对讲机。女儿从十岁长到二十岁，父亲在飞船上只老了几年。他每句我很快就回来，越来越像一句安慰自己的谎。","show_cover":true,"still":"assets/stills/星际穿越_对讲机.png"},
  {"section":"core",    "headline":"书架也是星图",
   "text":"还有那座书架。它其实是一张星图，把整个宇宙的坐标，藏进了一面墙。诺兰最狠的，是把浪漫拍成了线索。","show_cover":true,"still":"assets/stills/星际穿越_书架星图.png"},
  {"section":"core",    "headline":"爱是另一种引力","punchline":true,
   "text":"诺兰没把爱拍成软糖，他拍成了另一种引力。让这对父女跨过光年的，不是飞船，是那句始终没挂断的对讲机。","show_cover":true,"still":"assets/stills/星际穿越_对讲机.png"},
  {"section":"maker",   "headline":"较真的诺兰",
   "text":"诺兰拍了十年烧钱科幻，从不买现成特效套餐。引力那场戏，他真把摄影机架进零重力舱，让演员真飘起来。他最肯花的不是钱，是为一颗镜头反复较真的轴劲。","show_cover":false,"still":"assets/stills/星际穿越_零重力舱.png"},
  {"section":"ending",  "headline":"一个人看完",
   "text":"如果你也曾在异地，对着屏幕说过我很快就回来，这部片子，值得你一个人，安静地看完。",
   "show_cover":false,"clip":{"src":"assets/clips/星际穿越_名场面_对讲机.mp4","in":0,"dur":4.0}}
]
```

> 注：以上为结构示意，正式可复现示例见 `examples/` 下两个经 `check_script.py` 自检 10/10 通过的文件。

### 7.2 成片规格与交付汇报

```text
成片：星际穿越_诺兰_电影解说.mp4
规格：1080×1920 @30fps · H.264 + AAC · 5.3MB
实测：720 字台词 @ +5% → 配音约 173s，加 2s 片头海报 + 1s 留白 → 成片约 176s
音色：云健男声（zh-CN-YunjianNeural，+5%）  BGM：Silent Descent
结构：2s 片头海报卡 → 钩子 → 设定 → 核心看点（名场面+金句）→ 导演 → 观看理由
可调整项：换音色 / 改文案重渲 / 换主题色（cinema 红金）/ 延长片头海报
```

### 7.3 海报 meta（`assets/poster.png.poster.json`）

```json
{
  "poster_path": "/abs/.../assets/poster.png",
  "poster_url": "https://image.tmdb.org/t/p/w780/abc.jpg",
  "source_type": "real_search",
  "source_host": "image.tmdb.org",
  "copyright": "来源：image.tmdb.org（公开电影海报接口）。海报受版权保护，仅用于电影介绍与二次创作；商用前请自行确认授权。",
  "quality": { "width": 780, "height": 1170, "ratio": 0.667, "format": "JPEG", "bytes": 142033, "white_ratio": 0.1, "white_bg": false, "warnings": [], "normalized_size": [780, 1170] },
  "movie": { "title": "星际穿越", "director": "克里斯托弗·诺兰", "year": "2014" },
  "cache_key": "星际穿越-2014-xxxx",
  "cache_hit": false,
  "needs_visual_check": true,
  "fetched_at": "2026-10-10T14:50:00+08:00"
}
```


`source_type` 三选一且**互斥**：`real_search`（真实搜索）/ `user_upload`（用户上传）/ `ai_generated`（AI 生成 / 自绘）。  
交付汇报必须带上 `source_type` 与 `copyright`，让用户知道海报从哪来、能否商用。

## 八、合成配置 `config.json` 字段

```json
{
  "title": "星际穿越",
  "author": "克里斯托弗·诺兰",
  "theme": "cinema",
  "cover": "/abs/path/assets/poster.png",
  "intro_cover": "/abs/path/assets/poster.png",
  "intro_seconds": 2.0,
  "voice": "/abs/path/voice/voice.mp3",
  "timeline": "/abs/path/voice/timeline.json",
  "bgm": "/abs/path/bgm/SilentDescent.mp3",
  "width": 1080,
  "height": 1920,
  "segments": [
    { "section":"hook", "headline":"没有外星人", "text":"...", "show_cover": false,
      "clip": { "src": "assets/clips/星际穿越_预告片.mp4", "in": 8.0, "dur": 4.5, "fit": "cover" } },
    { "section":"premise", "headline":"农夫与星空", "text":"...", "show_cover": false,
      "still": "assets/stills/星际穿越_玉米地沙尘暴.png" },
    { "section":"core", "headline":"对讲机那头", "text":"...", "show_cover": true,
      "still": "assets/stills/星际穿越_对讲机.png" },
    { "section":"maker", "headline":"较真的诺兰", "text":"...", "show_cover": false,
      "still": "assets/stills/星际穿越_零重力舱.png" },
    { "section":"ending", "headline":"一个人看完", "text":"...", "show_cover": false,
      "clip": { "src": "assets/clips/星际穿越_名场面_对讲机.mp4", "in": 0, "dur": 4.0 } }
  ]
}
```

- `cover` / `intro_cover` 现在是「名场面静帧合成的海报」（make_poster.py --source 产出），不再是自绘文字卡。
- 画面优先级：clip(视频切片) > still(名场面) > cover 海报 > 大字卡；hook/ending 用 clip，其余段用 still。

- `width` / `height`：输出分辨率，默认 1080×1920。小红书 3:4 用 `1080` / `1440`；B站横屏用 `1920` / `1080`；版面按尺寸等比自适应。
- `cover` / `intro_cover` / `voice` / `timeline` / `bgm` **必须写绝对路径**（相对路径在 skill 目录下调用会找不到而静默回退）。
- 缺 `bgm` 时自动静音出片（不报错）。

## 九、目录结构

```text
three-minute-movie/
├── SKILL.md                        # 本文件（定义 + 工作流）
├── README.md                       # 用户文档
├── requirements.txt                # Python 依赖（已锁定版本）
├── references/
│   ├── copywriting.md              # 五段式台词规范、钩子/金句/不剧透规则、写作原则
│   ├── selfcheck.md                # 10 项自检清单：判定细则 + 不合格示例 + 修改示范
│   ├── poster_sourcing.md          # 海报三级降级（静态图）：源清单/校验阈值/引导文案/异常矩阵/缓存/字段
│   ├── clip_sourcing.md            # 真实片段来源与版权护栏（素材主导动态画面）：S1/S2/S3 来源、clip/still 字段、版权三档、回退规则
│   ├── footage_search.md           # 真实素材查找封装：search_footage + fetch_footage 用法、来源分级、白名单、agent 调用
│   └── platforms.md                # 平台规格、音色表、免费 BGM 曲库、片段时长建议、发布建议
├── examples/
│   ├── 星际穿越_诺兰_segments.json  # 科幻类示例台词（自检 10/10）
│   └── 肖申克的救赎_德拉邦特_segments.json # 剧情类示例台词（自检 10/10）
└── scripts/
    ├── check_script.py             # 台词机械自检（字数/段数/段式/禁用开场/金句/剧透，共 10 项）
    ├── fetch_poster.py             # L1 真实搜索执行器（下载→质量校验→规范化→缓存，输出 poster meta）
    ├── prep_poster.py              # 用户海报预处理（裁白边 + 圆角 → RGBA PNG）
    ├── make_poster.py              # 无实拍海报时自绘竖版海报卡（cover / intro_cover 通用）；--source 名场面静帧合成海报
    ├── search_footage.py           # 真实素材查找封装（按片名+导演+年份找 S1/S2/S3 静帧/预告片候选；零额外依赖）
    ├── fetch_footage.py            # 白名单下载封装（只放行 S1/S2/S3，拒绝 S4，记录 provenance）
    ├── tts.py                      # edge-tts 分段配音 + 时间轴（含失败重试）
    └── render.py                   # ffmpeg 合成（背景+片头海报+海报+大字+字幕+BGM；支持 segment.clip/still 电影素材叠加，尺寸可配）
```

## 十、环境依赖

- **Python**：3.9+，需 `edge-tts`、`imageio-ffmpeg`（自带 ffmpeg 7.x）、`Pillow`、`numpy`。
- **安装依赖**：`pip install -r requirements.txt`（建议先建虚拟环境，不要装全局）。
- **中文字体（跨平台自动探测）**：`render.py` 内置候选列表，按 Windows（微软雅黑）→ macOS（华文黑体 / 冬青黑体 / 苹方）→ Linux（Noto CJK）顺序取第一个存在的字体；缺失时往 `_CAND_BOLD` / `_CAND_REG` 补充绝对路径。
- **ffmpeg**：脚本优先用 `imageio-ffmpeg` 自带 ffmpeg，其次环境变量 `FFMPEG_PATH`，再次 `which ffmpeg`；无需系统 ffmpeg。
- **联网说明**：edge-tts 配音、L1 海报搜索、Mixkit BGM 下载均需联网；其余步骤（文案、自检、渲染）纯本地。

## 十一、踩坑备忘（务必遵守）

1. **ffmpeg 路径**：不在 PATH 里，脚本已内置自动发现（`imageio_ffmpeg` → 环境变量 `FFMPEG_PATH` → `which ffmpeg`），不要假设 `ffmpeg` 命令可直接调用。
2. **中文字体**：跨平台已自动探测；自加字体必须用**绝对路径**，否则中文变方块。
3. **配音与字幕必须对齐**：字幕时间来自 `tts.py` 产出的 `timeline.json`，**改文案后必须重跑 `tts.py` 再合成**，不要手写估算。
4. **BGM 音量要低**：默认 0.12（约 -18dB），高于 0.2 会盖过人声。
5. **不要编造**：片名锁定存疑时先确认；影片内容细节、金句原文、评分票房不得凭空生成。
6. **不要用 `rm` 清理工作目录**：后台脚本里 `rm` 会触发安全机制 fail-closed，用 Python `shutil` 或直接覆盖写入。
7. **自检不过不许进配音**：`check_script.py` 有 ❌ 时必须改稿重跑，这是质量闸口不是形式。
8. **用户海报先裁白边**：官方海报 / 票务图 / 3D 海报渲染图几乎都是白底 JPG，直接渲染会在深色背景上留一块生硬白矩形；一律先过 `prep_poster.py --pad 8 --radius 20`。
9. **海报 / 音频路径要在 config 里写绝对路径**：`render.py` 以当前工作目录解析相对路径，从 skill 目录调用时相对路径会找不到而静默回退成片名大字卡。
10. **海报必须走三级降级并留痕**：不要绕过 `fetch_poster.py` 直接把图丢进 config——否则没有 `source_type` / `copyright` / 缓存，复用与版权说明都会失控。网络失败要**明确告知用户并给重试入口**，禁止静默降级。
11. **不剧透是红线**：premise / core / ending 都不得泄露结局、凶手、终极反转；名场面可讲"发生什么"，不可讲"导致的结果"。
12. **真实片段只走 S1/S2/S3 来源**：官方预告片（默认）→ 片方物料 → 自购片源切片；**禁止第三方搬运 / 盗版资源**（clip_sourcing.md 红线）。片段须叠加解说、单段 ≤5s、标注片名导演；`clip.src` 缺失会自动回退海报，不中断渲染，但交付须如实说明哪些段用了真实画面。
13. **片段时长要够**：`clip.dur` 不得超过源片段可用长度，否则 ffmpeg trim 报错；建议省略 `dur` 让其自动取该段口播时长，并确保源片段本身至少这么长。
