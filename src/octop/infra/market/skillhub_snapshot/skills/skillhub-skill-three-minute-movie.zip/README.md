# 3分钟看完一部电影（three-minute-movie）

> 输入「片名 + 导演/年份」，**锁定唯一影片 → 生成 3 分钟五段式电影解说台词 → 一键产出竖屏 9:16 电影解说短视频（MP4）**。
> 全程免费、无需任何付费 API / key；配音用 edge-tts，配乐用 Mixkit 免费曲库。**不剧透结局**。

这是一个 [WorkBuddy](https://www.workbuddy.cn) 技能（Skill），由 AI 在对话中调用，把一部电影自动拆成一条可直接发布到抖音 / 快手 / 视频号 / 小红书 / B站 的「大字报」电影解说短视频。

---

## 功能特性

- **精准锁片**：以「片名 + 导演/年份」唯一锁定一部电影，禁止编造情节 / 金句 / 评分；同名片或匹配存疑会先跟你确认。
- **五段式台词**：钩子 → 设定（不剧透）→ 核心看点（1–2 个 + 1 句≤30字金句）→ 导演背景 → 观看理由。硬控 640–820 字（约 3 分钟）。
- **不剧透红线**：premise / core / ending 都不泄露结局、凶手、终极反转；名场面可讲"发生什么"，不可讲"导致的结果"。
- **完稿自检**：脚本机械校验 10 项（字数 / 段数 / 段式 / 禁用开场 / 金句位置 / 各段字数容差 / 空泛结尾 / 剧透扫描），任一不过不让进配音。
- **海报三级降级**：L1 真实搜索 → L2 用户上传（可跳过）→ L3 自绘海报卡兜底，**三源互斥 + 版权留痕**。
- **真实片段 B 混合（推荐）**：`hook` / `ending` 段可叠加官方预告片片段铺底（`clip` 字段，静音 + 解说字幕），`core` 段用海报 + 大字金句；片段缺失自动回退海报，来源与版权护栏见 `references/clip_sourcing.md`。
- **本地渲染**：`render.py` 用 ffmpeg 合成背景 + 海报 Ken Burns + 大字标题 + 底部字幕 + 低沉 BGM；`hook` / `ending` 段可叠加真实预告片片段（B 混合）。
- **多平台尺寸**：默认 1080×1920（9:16）；通过 config 的 `width/height` 真配置即可出小红书 3:4（1080×1440）、B站横屏（1920×1080），**无需改源码**。

## 安装

### 方式一：作为 WorkBuddy 技能（推荐）
把本目录复制到用户级技能目录即可跨项目复用：

```
# Windows（xcopy 递归复制目录）
xcopy /E /I /Q three-minute-movie %USERPROFILE%\.workbuddy\skills\three-minute-movie

# macOS / Linux
cp -r three-minute-movie ~/.workbuddy/skills/three-minute-movie
```

### 方式二：从源码使用
需要 Python 3.9+，安装依赖：

```bash
pip install -r requirements.txt
```

## 依赖

| 包 | 作用 |
|---|---|
| `edge-tts` | 免费云端中文配音（联网，无需 key） |
| `imageio-ffmpeg` | 提供 ffmpeg 可执行文件用于合成 |
| `Pillow` | 海报处理 / 自绘海报卡 / 文字排版 |
| `numpy` | 背景渐变与图像处理计算 |

> 注意：edge-tts 配音、海报 L1 真实搜索、BGM 下载均**需要联网**；断网环境无法完成配音与联网取海报。

## 使用流程（在 WorkBuddy 对话中）

1. 触发：说「把《星际穿越》讲成一条 3 分钟视频」「安利一下《肖申克的救赎》」「3分钟看完《XXX》」。
2. 锁片：AI 用「片名 + 导演/年份」确认唯一影片，必要时反问你。
3. 写稿：产出五段式 640–820 字台词（含 1 句金句，不剧透）。
4. 自检：跑 `scripts/check_script.py`，10/10 通过才进下一步。
5. 海报：三级降级取海报（真实搜索 / 你上传 / AI 自绘卡）。
6. 真实片段（可选但推荐）：把官方预告片放到 `assets/clips/`，在分段表的 `hook` / `ending` 段加 `clip` 字段（见 `references/clip_sourcing.md`）；缺失会自动回退海报。
7. 配音：`scripts/tts.py` 用 edge-tts 逐段配音，产出时间轴。
8. 合成 + 交付：`scripts/render.py` 用 ffmpeg 合成 MP4 并汇报海报来源 / 版权。

## 目录结构

```
three-minute-movie/
├── SKILL.md              # 技能主文档（含 frontmatter 元数据）
├── requirements.txt      # Python 依赖（锁定最低兼容版本）
├── LICENSE
├── scripts/
│   ├── check_script.py   # 五段式台词机械自检（10 项）
│   ├── prep_poster.py    # 用户海报预处理（裁白边 + 圆角）
│   ├── make_poster.py    # 无海报时自绘竖版海报卡
│   ├── fetch_poster.py   # 海报获取 / 校验 / 缓存（三级降级执行器）
│   ├── tts.py            # edge-tts 分段配音 + 时间轴生成
│   └── render.py         # ffmpeg 竖屏大字报合成
├── references/           # copywriting / selfcheck / poster_sourcing / clip_sourcing / platforms
└── examples/             # 星际穿越_诺兰 / 肖申克的救赎_德拉邦特 示例台词
```

## 示例

`examples/` 下提供两个已通过自检 10/10 的示例台词 JSON（含 B 混合 `clip` 字段），可直接用来复现出片：

- `examples/星际穿越_诺兰_segments.json`（科幻类）
- `examples/肖申克的救赎_德拉邦特_segments.json`（剧情类）

## 版权与合规

- 海报 L1 真实搜索来自公开海报接口（TMDB / IMDb / 豆瓣等），**商用前请确认授权**，建议取得片方 / 发行方书面许可。
- L3 自绘海报卡仅作示意，**不得冒充片方官方海报**。
- 真实片段仅用官方预告片（S1）/ 片方物料（S2）/ 自购片源切片（S3），**禁止第三方搬运 / 盗版**；片段须叠加解说、标注片名导演、单段克制（详见 `references/clip_sourcing.md`）。
- edge-tts 与 Mixkit 曲库均遵循各自服务条款，使用前请知悉。
- **不剧透**：成片与封面都不要泄露电影结局，尊重未观影观众。

## License

[MIT](LICENSE) © 2026 Blues
