---
name: skillhub-skill-z-doc-to-public-html
description: "一站式把本地 .docx/.md 文档变成「可公网访问的互动网页」。先调用「文档转互动HTML阅读器」(z-doc-to-interactive-html) 生成自包含 HTML，再调用「本地HTML公网发布器」(z-html-public-deploy) 部署为公网链接，返回 URL 并预览。当用户说\"把文档直接发成公网网页 / 文档变公网链接 / 一步把文档发网上 / 文档转在线页\"时使用。"
---

# 文档转公网互动页

把「文档转网页」和「网页发公网」串成一条龙：丢个文档进来，出去就是一个能分享的网址。

## 何时用
- 用户想**一步到位**：给个 .docx/.md，直接要一个可公网访问、带目录+搜索的网页链接。
- 触发词：「文档直接发成公网网页 / 文档变公网链接 / 一步把文档发网上 / 文档转在线页 / 把这份报告发成能开的网址」。

## 核心原则（不重复造逻辑）
本 skill 是**编排层**，自身不实现解析/部署细节，而是按顺序复用两个已建 skill：
1. `z-doc-to-interactive-html` —— 产出自包含互动 HTML。
2. `z-html-public-deploy` —— 把该 HTML 部署为公网 URL。

## 执行流程
1. 拿到本地文档路径（.docx / .md）。
2. 调用「文档转互动HTML阅读器」流程，生成自包含 HTML（CSS/JS 全内联、图片 base64）。
   - 校验自包含（G3）：若含外链资源，先回退让上游 skill 处理内联，不要带病部署。
3. 调用「本地HTML公网发布器」流程，将该 HTML 部署为静态站点，取得公网 URL。
   - WorkBuddy 环境：`workbuddy_cloudstudio_deploy` 传入含该 HTML 的目录（入口指向该文件或重命名为 index.html）。
   - 其他客户端：走等价静态托管（GitHub Pages / Netlify / Vercel / 对象存储），见 R-CROSS。
4. 验证 URL 可达（HTTP 200）。
5. `present_files` 呈现公网链接 + 预览面板（F3）。

## 输出示例
- 用户：「把《新员工手册.docx》发成能开的网址」
- 助手：转 HTML → 部署 → 返回 `https://xxxx.cloudstudio.app/新员工手册` → 对话内直接预览。

## 注意 / 红线
- **顺序不可逆**：必须先保证自包含 HTML 再部署，否则公网打开变空白。
- 发布前确认用户意图，不擅自公开敏感文档。
- 公网链接可能有时效，长期托管提醒走正式静态服务。
- 不修改原文语义，仅做样式/部署层的编排。

## 配套联动
- 上游：`z-doc-to-interactive-html`（提供 HTML）。
- 下游：`z-html-public-deploy`（提供公网 URL）。
- 如仅需本地阅读不要公网，直接用上游 skill 即可。
