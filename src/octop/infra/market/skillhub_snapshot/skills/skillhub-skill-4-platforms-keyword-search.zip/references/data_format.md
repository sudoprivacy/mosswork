# 红狐(RedFox) 四大平台数据格式说明

## 抖音（广域库 /searchWork）

接口：`POST https://redfox.hk/story/api/dy/data/searchWork`

| 字段 | 说明 |
|------|------|
| videoId | 作品唯一 ID |
| content | 作品文案/标题 |
| authorName | 账号名称 |
| publishTime | 发布时间 |
| likeCount | 点赞数 |
| collectCount | 收藏数 |
| commentCount | 评论数 |
| shareCount | 分享数 |
| videoType | 作品类型（0=视频, 68=图集, 63=直播录屏）|
| duration | 时长（毫秒）|
| opusUrl | 作品链接 |
| tagList | 话题标签列表 |

热度分计算（本地）：点赞×1.0 + 收藏×1.2 + 评论×1.5 + 分享×0.8，归一化到 0-100

## 小红书（优质库）

接口：`POST https://redfox.hk/story/api/xhsUser/searchArticle`

**优质库特点**：
- 返回小红书优质作品，数据质量高
- 支持 `sortType` 排序：`_0`(默认相关性) / `_2`(最新) / `_4`(最热)
- 分页使用 `offset`（从 0 开始，每页 20 条）

| 字段 | 说明 |
|------|------|
| workId | 作品 ID |
| workTitle | 作品标题 |
| workDesc | 作品内容 |
| workUrl | 作品链接 |
| workPublishTime | 发布时间 |
| accountNickname | 作者昵称 |
| accountUserid | 作者小红书 ID |
| workLikedCount | 点赞数 |
| workCommentsCount | 评论数 |
| workCollectedCount | 收藏数 |
| workSharedCount | 分享数 |
| workReadedCount | 阅读数 |
| workType | 作品类型（normal=图文, video=视频）|
| coverUrl | 封面图链接 |

**注意**：优质库无 relevanceScore/popularityScore/recencyScore/totalScore 字段，排序按互动数（点赞+收藏+评论+分享）代替。

## 公众号（爆款文章）

接口：`POST https://redfox.hk/story/api/gzh/search/hotArticleNew`

| 字段 | 说明 |
|------|------|
| id | 文章 ID |
| title | 标题 |
| author | 作者/公众号 |
| publicTime | 发布时间 |
| clicksCount | 阅读数 |
| watchCount | 在看数 |
| likeCount | 点赞数 |
| commentsCount | 评论数 |
| relevanceScore | 相关性得分 |
| popularityScore | 热度得分 |
| recencyScore | 时效得分 |
| totalScore | 总分（15分制）|
| summary | 摘要 |
| url | 原文链接 |

爆款标准：阅读数 5000+，总分 ≥13 视为强爆款信号

## 视频号（广域库 /searchWork）

接口：`POST https://redfox.hk/story/api/sphAllData/searchWork`

| 字段 | 说明 |
|------|------|
| description | 作品描述 |
| nickname | 作者昵称 |
| publishTime | 发布时间 |
| likeCount | 点赞数 |
| commentCount | 评论数 |
| forwardCount | 转发数 |
| favCount | 收藏数 |
| videoUrl | 视频链接 |

注意：视频号接口无时间范围参数，需客户端按发布时间过滤
