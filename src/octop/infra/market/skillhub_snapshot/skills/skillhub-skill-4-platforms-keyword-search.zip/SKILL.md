---
name: skillhub-skill-4-platforms-keyword-search
description: "【宝哥】四大平台选题关键词搜索。给定关键词，同时调用红狐(RedFox)接口查询抖音、小红书、公众号、视频号四大平台的爆款内容，合并导出为 Excel（多 sheet）和 HTML 汇总表格，用于「宝哥聊 AI」全平台内容选题调研。已合并原 baoge-xhs-keyword-search-top20 的小红书最热N条能力：小红书走优质库 searchArticle（不限 1000+ 门槛），支持 --xhs-sort-type(_4最热/_2最新/_0相关性) 与 --days 时间窗。当用户需要一键搜索四大平台爆款、按关键词找全平台可二创选题、生成四平台选题 Excel/HTML 汇总，或要\"某关键词下小红书最热N条（不限门槛）\"时使用。"
---

# 【宝哥】四大平台选题关键词搜索
> 作者：宝哥聊AI

## 功能概述

给定一个或多个关键词，**同时调用红狐(RedFox)四大平台接口**：

1. **抖音**（广域库 `/searchWork`）→ 拉取相关作品
2. **小红书**（优质库 `/xhsUser/searchArticle`）→ 拉取关键词匹配的优质笔记（**不限 1000+ 互动门槛，全量匹配**）
3. **公众号**（爆款文章 `/hotArticleNew`）→ 拉取阅读 5000+ 文章
4. **视频号**（广域库 `/searchWork`）→ 拉取相关作品

合并导出为：

- **Excel**（`.xlsx`）：单文件多 sheet（抖音/小红书/公众号/视频号各一个 sheet），每个 sheet 独立排序、冻结首行、自动筛选、高热度标红、链接可点击。
- **HTML**（表格视图）：四平台汇总的可筛选网页，每个平台一个独立区块，带搜索框，方便预览与分享。

> **能力合并说明**：原 `baoge-xhs-keyword-search-top20`（小红书最热 N 条）的优质库能力已内建到本 skill 的小红书分支中。现在无需单独调用 top20，直接在四平台一键搜索里用 `--xhs-sort-type _4 --days 0` 即可拿到「某关键词下小红书最热 N 条整体」；要限定时间窗则用 `--days`。详见下方「小红书专属参数」。

适用场景：宝哥做全平台内容选题情报、从四平台爆款里挑可二创选题、批量产出选题汇总表格。

## 前置依赖

1. **`REDFOX_API_KEY`（红狐接口密钥）**：必填。两种配置方式二选一，详见下方「配置 API Key」一节。
2. **openpyxl**：仅导出 Excel 时需要。已装在受管虚拟环境：
   `C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe`
   该环境未装时，HTML 导出仍可用（纯标准库）。

## 配置 API Key（二选一）

脚本运行必须拿到 `REDFOX_API_KEY`（红狐接口密钥）。两种方式任选其一：

**方式 A：配置文件（推荐新手 / 不想改系统环境变量）**

技能目录已附带 `config.example.env` 模板：

```bash
# 1. 复制模板并重命名
cp "C:/Users/Administrator/.workbuddy/skills/4-platforms-keyword-search/config.example.env" \
   "C:/Users/Administrator/.workbuddy/skills/4-platforms-keyword-search/config.env"

# 2. 用编辑器打开 config.env，把 your_redfox_api_key_here 换成真实 Key，保存
# 3. 运行脚本时自动读取该文件，无需另设环境变量
```

> **安全**：含真实 Key 的 `config.env` 不要提交到公开仓库或分享；`config.example.env` 只是模板，不含密钥，可安全提交与分发。打包/分发本 skill 前务必删除 `config.env`。

**方式 B：系统 / 用户环境变量**

- Windows 用户级：新建 `REDFOX_API_KEY=<你的key>`，设好后**重启 WorkBuddy** 生效。
- Bash 临时：`export REDFOX_API_KEY=<你的key>`（Bash 工具因源生 `.bashrc` 当下即可用）。

两种方式同时存在时，**`config.env` 配置文件优先于环境变量**（设计如此：可覆盖 WorkBuddy 启动时继承的、陈旧的/失效的环境变量值）。此外还可用命令行 `--api-key <key>` 显式传入，其优先级最高。完整优先级：

`--api-key 命令行参数` > `config.env / .env 文件` > `环境变量 REDFOX_API_KEY`

> 典型坑：改完 Windows 用户级 `REDFOX_API_KEY` 后若**没重启 WorkBuddy**，运行中的进程仍持有旧值。此时把新 Key 写进 `config.env` 即可立即生效，无需重启。

还没有红狐 Key？前往 https://redfox.hk/dashboard/keys 注册并获取 API Key。

## 运行方式

脚本：`scripts/fetch_and_export_4platforms.py`

```bash
# 用受管 venv 的 python（已含 openpyxl，可同时出 Excel + HTML）
VENV="C:/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe"
SCRIPT="C:/Users/Administrator/.workbuddy/skills/4-platforms-keyword-search/scripts/fetch_and_export_4platforms.py"

# 同时导出 Excel 和 HTML（默认）
"$VENV" "$SCRIPT" --keyword "企业AI" --output both --outdir "F:/zimeiti"

# 只出 Excel
"$VENV" "$SCRIPT" --keyword "制造业降本" --output excel

# 多关键词（逗号分隔，自动合并去重）
"$VENV" "$SCRIPT" --keyword "AI培训,老板获客" --output both

# 按评论数排序（评论最多的 20 条）
"$VENV" "$SCRIPT" --keyword "企业AI" --max-items 20 --sort-by comment
```

> 💡 **多关键词用法提示**（用户常问）：一次搜多个词时，用**半角逗号 `,`** 分隔，例如
> `--keyword "企业AI,workbuddy"`。脚本会对每个词分别查询四个平台接口，再按各平台 ID 自动合并去重、
> 统一排序。注意**不要**用空格（会被当成一整个长词）或中文逗号（脚本已自动纠正为半角，但建议直接打半角）。
> 多关键词的输出文件名用下划线连接，并带生成时间戳（月日_时分），如 `四平台_企业AI_workbuddy_爆款数据_0823_1347.xlsx`。

### 小红书专属参数（合并自 top20）

小红书接口（`searchArticle` 优质库）**没有服务端时间参数**，时间窗只能在客户端按发布时间过滤。本 skill 为此提供两个专属开关：

| 参数 | 说明 | 典型用法 |
|------|------|----------|
| `--xhs-sort-type` | 小红书**服务端**排序，仅当**无时间窗**时生效：`_4` 最热(互动数) / `_2` 最新发布(默认) / `_0` 相关性 | `--xhs-sort-type _4` |
| `--days` | 相对时间窗天数（见下方全局说明），小红书据此客户端过滤最近 N 天 | `--days 7` |

常见组合：

```bash
# ① 小红书「最热 N 条整体」（不限时间窗、不限 1000+ 门槛）—— 原 top20 的核心诉求
"$VENV" "$SCRIPT" --keyword "企业AI" --xhs-sort-type _4 --days 0 --max-items 20

# ② 最近 7 天 · 小红书最热 20 条（--days 对四平台统一生效，小红书内部强制按最新拉取后客户端取最热）
"$VENV" "$SCRIPT" --keyword "企业AI" --days 7 --max-items 20

# ③ 不限定时间窗，小红书按最新发布取前 20
"$VENV" "$SCRIPT" --keyword "老板获客" --xhs-sort-type _2 --days 0 --max-items 20
```

> 时间窗与排序协作规则：只要带时间窗（`--start-date` 或 `--days>0`），小红书内部会**强制按 `_2`(最新) 拉取**以保证发布时间单调递减、遇到窗口外作品即停翻（无遗漏），再按 `--sort-by`（默认互动总数）降序取前 N；此时 `--xhs-sort-type` 被忽略。`--xhs-sort-type` 仅在**无时间窗**（`--days 0` 或未指定任何时间参数）时直接决定服务端排序结果。

参数总表：

| 参数 | 必填 | 说明 | 默认 |
|------|------|------|------|
| `--keyword` | 是 | 搜索关键词，多个用逗号分隔 | - |
| `--output` | 否 | `excel` / `html` / `both` | `both` |
| `--outdir` | 否 | 输出目录 | 当前目录 |
| `--max-items` | 否 | 每平台最大条数（自动分页拉取） | 50 |
| `--start-date` | 否 | 开始日期 YYYY-MM-DD（绝对时间窗，四平台通用） | 不填 |
| `--days` | 否 | 相对时间窗天数：`>0` 四平台仅保留最近 N 天；`0` 四平台均不限制时间窗；不填=各平台默认 | 不填 |
| `--sort-by` | 否 | 排序字段：`comment`(评论) / `like`(点赞) / `collect`(收藏) / `share`(分享) / `total`(总分/互动总数，默认) | 各平台默认 |
| `--xhs-sort-type` | 否 | 小红书服务端排序（仅无时间窗时生效）：`_4` 最热 / `_2` 最新 / `_0` 相关性 | `_2` |
| `--api-key` | 否 | 红狐 API Key（优先级最高） | 取 config.env / 环境变量 |
| `--debug` | 否 | 打印接口请求与响应状态 | 关 |

**排序字段映射**：

| 平台 | comment | like | collect | share | total |
|------|---------|------|---------|-------|-------|
| 抖音 | commentCount | likeCount | collectCount | shareCount | hot（热度分）|
| 小红书 | commentsCount | likedCount | collectedCount | sharedCount | interactiveCount（互动总数）|
| 公众号 | commentsCount | likeCount | watchCount | clicksCount | totalScore |
| 视频号 | comment | like | fav | forward | like |

> 💡 小红书优质库策略：默认按 `_2`(最新) 拉取，客户端按时间窗过滤；窗口内作品再按 `--sort-by` 指定字段（点赞/评论/收藏/分享/互动总数）降序取前 N 条。注意：B 端词（如"企业AI"）在小红书内容量天然较少，窗口内可能凑不齐 20 条，返回实际数量属正常。

## ⚠️ 本机必坑点：Windows 路径翻译

本机是 **Git Bash + 原生 Windows Python**，原生 Python 会把 `/c/Users/...` 这种 POSIX 路径误当成相对当前盘符、拼成 `C:\c\Users\...` 报错 "No such file"。

**规则**：凡是把脚本路径传给 `python.exe`，必须先用 `cygpath -w` 转成 Windows 原生路径：

```bash
SCRIPT_WIN="$(cygpath -w "$HOME/.workbuddy/skills/4-platforms-keyword-search/scripts/fetch_and_export_4platforms.py")"
"$VENV" "$SCRIPT_WIN" --keyword "企业AI" --output both --outdir "F:/zimeiti"
```

（脚本**内部**读写 `--outdir` 用普通路径即可，只有「脚本自身路径」需要转 Windows 原生。）

## 输出文件命名

文件名统一带 **`四平台_`** 前缀（与单平台技能产出区分），并追加**生成时间戳 `月日_时分`**：

- `F:/zimeiti/四平台_企业AI_爆款数据_0823_1347.xlsx`
- `F:/zimeiti/四平台_企业AI_爆款数据_0823_1347.html`

时间戳格式为 `MMDD_HHMM`（24 小时制），由脚本在运行时生成，Excel 与 HTML 共用同一戳，便于成对区分不同批次。
多关键词时文件名用 `_` 连接，如 `四平台_AI培训_老板获客_爆款数据_0823_1347.xlsx`。

> ⚠️ **交付要求（重要经验）**：脚本只是把文件写到 `--outdir`，**不会自动把文件交给用户**。
> 跑完生成后，必须调用 `present_files` 把成品（xlsx / html）交付给用户，或明确给出绝对路径；
> 不要只做「验证性运行」然后把临时产物删掉就结束——用户要看到的是真实输出文件。

## 数据说明

- 数据来源：红狐(RedFox)四大平台接口，互动数为入库时快照，非实时。
- 各平台接口：
  - 抖音：广域库 `/searchWork`，返回所有匹配作品
  - 小红书：**优质库** `/xhsUser/searchArticle`，关键词全量匹配、**不限 1000+ 互动门槛**（与爆款库相反），支持 `sortType` 排序（`_0` 相关性 / `_2` 最新 / `_4` 最热）
  - 公众号：广域库 `/hotArticleNew`，返回阅读 5000+ 的文章
  - 视频号：广域库 `/searchWork`，返回所有匹配作品
- 各平台爆款标准：
  - 抖音：热度分 ≥ 60 视为强爆款信号（本地加权：点赞×1.0+收藏×1.2+评论×1.5+分享×0.8）
  - 小红书：优质库按互动总数（点赞+收藏+评论+分享）排序，互动总数 ≥10000 标红；因不限门槛，结果里可能出现低互动笔记，属预期
  - 公众号：阅读数 5000+ 的文章，总分 ≥13 视为强爆款信号
  - 视频号：按点赞数降序，无爆款阈值
- 字段来源见 `references/data_format.md`（红狐各平台对象字段映射）。

## 选题跟进建议

导出后可进一步：
1. 从各平台高热度/高总分条目里挑 3–5 条最贴合「宝哥聊 AI」定位（老板获客、制造业降本、AI 培训）的内容做二创选题
2. 对比四平台同一关键词的内容差异，找出平台特性（如抖音重视频、小红书重干货收藏、公众号重深度、视频号重社交裂变）
3. 加一列「二创适配度」人工标注，沉淀到内容资产库

## 与其他技能的关系

本技能是以下单平台技能的**组合封装**；其中小红书最热 N 条（原 top20）能力已内建，无需单独调用：

- `baoge-douyin-keyword-search`（抖音）
- `baoge-xhs-keyword-search-top20`（小红书最热 N 条，已合并进本 skill）
- `baoge-xhs-keyword-search-hit`（小红书**仅 1000+ 真爆款**，如需严格 1000+ 门槛用此）
- `wechat-article-keyword-search`（公众号）
- `wechat-keyword-search`（视频号）

如需单平台精细控制（如只搜抖音、改排序字段、拉更多条数），请直接使用对应单平台技能。
