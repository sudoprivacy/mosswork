#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音平台数据获取模块
"""

import json
import urllib.request
import urllib.error
from datetime import datetime, timedelta


def _num(v):
    """把可能带逗号/空值的数字统一成 int"""
    if v is None:
        return 0
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).replace(",", "").strip()
    if s == "":
        return 0
    try:
        return int(float(s))
    except ValueError:
        return 0


def _vtype(v):
    """广域库 videoType 是数字枚举，转成可读中文"""
    m = {"0": "视频", "68": "图集", "63": "直播录屏"}
    return m.get(str(v), str(v) if v not in (None, "") else "视频")


def _tags(raw):
    """从 tagList 取话题名称，逗号连接"""
    lst = raw.get("tagList") or []
    names = [t.get("tagName", "") for t in lst if t.get("tagName")]
    return ",".join(names)


def _heat(raw):
    """本地热度分（未归一化）"""
    like = _num(raw.get("likeCount"))
    collect = _num(raw.get("collectCount"))
    comment = _num(raw.get("commentCount"))
    share = _num(raw.get("shareCount"))
    return like * 1.0 + collect * 1.2 + comment * 1.5 + share * 0.8


def _normalize(raw):
    """将红狐广域库抖音原始作品对象规整为本脚本使用的字段字典"""
    title = (raw.get("content") or "").strip().replace("\n", " ")
    title = title[:50] if title else (raw.get("authorName", "") or "")
    return {
        "title": title,
        "content": (raw.get("content") or "").strip(),
        "account": raw.get("authorName", ""),
        "publish_time": raw.get("publishTime", ""),
        "like_count": raw.get("likeCount", 0),
        "collect_count": raw.get("collectCount", 0),
        "comment_count": raw.get("commentCount", 0),
        "share_count": raw.get("shareCount", 0),
        "work_type": _vtype(raw.get("videoType", "")),
        "duration": raw.get("duration", 0),
        "url": raw.get("opusUrl", ""),
        "tags": _tags(raw),
    }


def http_post(url, body, headers):
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"__http_error__": e.code}
    except Exception as e:
        return {"__error__": str(e)}


def fetch_douyin_works(keywords, api_key, max_items=50, start_date=None, debug=False, sort_mode="hot"):
    """调用红狐广域库接口，返回作品列表（已去重、按指定方式排序）
    
    参数:
        sort_mode: 排序方式，默认 hot（热度分），可选 likeCount/collectCount/commentCount/shareCount
    """
    API_URL = "https://redfox.hk/story/api/dy/data/searchWork"
    PAGE_SIZE_CAP = 50

    headers = {"Content-Type": "application/json", "REDFOX_API_KEY": api_key}
    today = datetime.now()
    end = today.strftime("%Y-%m-%d")

    def _query(date_start):
        collected = {}
        page = 1
        while True:
            for kw in keywords:
                body = {
                    "keyword": kw,
                    "startDate": date_start,
                    "endDate": end,
                    "pageNum": page,
                    "pageSize": min(PAGE_SIZE_CAP, max(10, max_items)),
                }
                if debug:
                    print(f"[debug] 抖音查询关键词={kw!r} page={page} 范围 {date_start} ~ {end}")
                res = http_post(API_URL, body, headers)
                if "__http_error__" in res:
                    raise Exception(f"HTTP 错误: {res['__http_error__']}")
                if "__error__" in res:
                    raise Exception(f"请求异常: {res['__error__']}")
                if res.get("code") != 2000:
                    raise Exception(f"接口返回错误: code={res.get('code')} msg={res.get('msg')}")
                data = res.get("data", {})
                arts = data.get("list", [])
                for a in arts:
                    aid = a.get("videoId")
                    if aid and aid not in collected:
                        collected[aid] = a
            if len(arts) < min(PAGE_SIZE_CAP, max(10, max_items)) or not arts:
                break
            if len(collected) >= max_items:
                break
            page += 1
            if page > 50:
                break
        return list(collected.values())

    s7 = (today - timedelta(days=7)).strftime("%Y-%m-%d")
    s30 = (today - timedelta(days=30)).strftime("%Y-%m-%d")

    if start_date:
        raw_list = _query(start_date)
    else:
        raw_list = _query(s7)
        if len(raw_list) < 10:
            if debug:
                print("[debug] 抖音近7天数据不足，拓展至近30天")
            raw_list = _query(s30)

    works = [_normalize(a) for a in raw_list]

    # 计算本地热度分并归一化到 0-100
    for w in works:
        w["_raw_heat"] = _heat(w)
    max_raw = max((w["_raw_heat"] for w in works), default=0)
    for w in works:
        if max_raw > 0:
            w["hot_score"] = round(w["_raw_heat"] / max_raw * 100, 1)
        else:
            w["hot_score"] = 0.0

    # 按指定方式排序
    if sort_mode == "hot":
        works.sort(key=lambda x: x.get("hot_score", 0), reverse=True)
    else:
        works.sort(key=lambda x: _num(x.get(sort_mode)), reverse=True)

    return works[:max_items]
