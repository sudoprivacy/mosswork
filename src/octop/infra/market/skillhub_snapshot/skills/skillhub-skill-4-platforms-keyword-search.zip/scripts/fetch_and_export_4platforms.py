#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四大平台选题关键词搜索 - 合并导出脚本
同时调用红狐(RedFox)抖音、小红书、公众号、视频号接口，合并导出 Excel + HTML
"""

import argparse
import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# 添加脚本目录到路径，以便导入各平台模块
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))

# 尝试导入 openpyxl（Excel 导出）
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False
    print("⚠️  openpyxl 未安装，仅支持 HTML 导出", file=sys.stderr)


def load_config() -> Dict[str, str]:
    """加载配置文件，优先级：--api-key > config.env > 环境变量"""
    config = {}
    
    # 1. 尝试读取技能目录下的 config.env
    skill_dir = SCRIPT_DIR.parent
    config_env = skill_dir / "config.env"
    if config_env.exists():
        with open(config_env, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    config[key.strip()] = value.strip()
    
    # 2. 环境变量兜底
    if "REDFOX_API_KEY" not in config:
        env_key = os.environ.get("REDFOX_API_KEY", "")
        if env_key:
            config["REDFOX_API_KEY"] = env_key
    
    return config


def get_api_key(args) -> Optional[str]:
    """获取 API Key，优先级：命令行 > config.env > 环境变量"""
    if args.api_key:
        return args.api_key
    
    config = load_config()
    key = config.get("REDFOX_API_KEY", "")
    
    # 检查是否是占位符
    if key and key != "your_redfox_api_key_here" and not key.startswith("ak_xxxx"):
        return key
    
    return None


def parse_keywords(keyword_str: str) -> List[str]:
    """解析关键词，支持逗号分隔"""
    # 自动纠正中文逗号为半角
    keyword_str = keyword_str.replace("，", ",")
    keywords = [k.strip() for k in keyword_str.split(",") if k.strip()]
    return keywords


def generate_filename(keywords: List[str], output_dir: str, timestamp: str) -> Tuple[str, str]:
    """生成输出文件名"""
    kw_part = "_".join(keywords)
    base_name = f"四平台_{kw_part}_爆款数据_{timestamp}"
    excel_path = os.path.join(output_dir, f"{base_name}.xlsx")
    html_path = os.path.join(output_dir, f"{base_name}.html")
    return excel_path, html_path


def fetch_douyin(keywords: List[str], api_key: str, max_items: int, start_date: Optional[str], debug: bool, sort_by: Optional[str] = None) -> List[Dict]:
    """调用抖音接口（广域库 /searchWork）"""
    try:
        from fetch_douyin import fetch_douyin_works
        # 抖音排序字段映射
        sort_map = {
            "comment": "commentCount",
            "like": "likeCount",
            "collect": "collectCount",
            "share": "shareCount",
            "total": "hot"  # 热度分
        }
        sort_mode = sort_map.get(sort_by, "hot") if sort_by else "hot"
        return fetch_douyin_works(keywords, api_key, max_items, start_date, debug, sort_mode)
    except ImportError as e:
        print(f"⚠️  抖音模块导入失败: {e}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"⚠️  抖音数据获取失败: {e}", file=sys.stderr)
        return []


def fetch_xiaohongshu(keywords: List[str], api_key: str, max_items: int, start_date: Optional[str], debug: bool, sort_by: Optional[str] = None, xhs_sort_type: str = "_2", xhs_days: Optional[int] = None) -> List[Dict]:
    """调用小红书接口（优质库 searchArticle）"""
    try:
        from fetch_xiaohongshu import fetch_xiaohongshu_notes
        # 小红书排序字段映射
        sort_map = {
            "comment": "commentsCount",
            "like": "likedCount",
            "collect": "collectedCount",
            "share": "sharedCount",
            "total": "totalScore"
        }
        sort_field = sort_map.get(sort_by, "totalScore") if sort_by else "totalScore"
        return fetch_xiaohongshu_notes(
            keywords, api_key, max_items, start_date, debug, sort_field,
            sort_type=xhs_sort_type, days=xhs_days
        )
    except ImportError as e:
        print(f"⚠️  小红书模块导入失败: {e}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"⚠️  小红书数据获取失败: {e}", file=sys.stderr)
        return []


def fetch_gzh(keywords: List[str], api_key: str, max_items: int, start_date: Optional[str], debug: bool, sort_by: Optional[str] = None) -> List[Dict]:
    """调用公众号接口"""
    try:
        from fetch_gzh import fetch_gzh_articles
        # 公众号排序字段映射
        sort_map = {
            "comment": "commentsCount",
            "like": "likeCount",
            "collect": "watchCount",  # 在看
            "share": "clicksCount",   # 阅读
            "total": "totalScore"
        }
        sort_field = sort_map.get(sort_by, "totalScore") if sort_by else "totalScore"
        return fetch_gzh_articles(keywords, api_key, max_items, start_date, debug, sort_field)
    except ImportError as e:
        print(f"⚠️  公众号模块导入失败: {e}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"⚠️  公众号数据获取失败: {e}", file=sys.stderr)
        return []


def fetch_shipinhao(keywords: List[str], api_key: str, max_items: int, start_date: Optional[str], debug: bool, sort_by: Optional[str] = None) -> List[Dict]:
    """调用视频号接口"""
    try:
        from fetch_shipinhao import fetch_shipinhao_works
        # 视频号排序字段映射
        sort_map = {
            "comment": "comment",
            "like": "like",
            "collect": "fav",
            "share": "forward",
            "total": "like"  # 默认按点赞
        }
        rank_by = sort_map.get(sort_by, "like") if sort_by else "like"
        return fetch_shipinhao_works(keywords, api_key, max_items, start_date, debug, rank_by)
    except ImportError as e:
        print(f"⚠️  视频号模块导入失败: {e}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"⚠️  视频号数据获取失败: {e}", file=sys.stderr)
        return []


def export_excel(
    data: Dict[str, List[Dict]],
    output_path: str,
    keywords: List[str],
    timestamp: str
) -> bool:
    """导出 Excel（多 sheet）"""
    if not OPENPYXL_AVAILABLE:
        print("❌ openpyxl 未安装，无法导出 Excel", file=sys.stderr)
        return False

    def _sv(v):
        """None 转空串，其他原样返回（防 openpyxl 写入 None 异常）"""
        return "" if v is None else v

    import re as _re
    _ILLEGAL_RE = _re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

    wb = Workbook()
    wb.remove(wb.active)  # 删除默认 sheet
    
    # 定义样式
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)
    highlight_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")  # 浅红
    border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin")
    )
    
    platforms = [
        ("抖音", data.get("douyin", [])),
        ("小红书", data.get("xiaohongshu", [])),
        ("公众号", data.get("gzh", [])),
        ("视频号", data.get("shipinhao", []))
    ]
    
    for platform_name, items in platforms:
        if not items:
            continue
        
        ws = wb.create_sheet(title=platform_name)
        
        # 根据平台定义列
        if platform_name == "抖音":
            headers = ["排名", "标题", "账号", "发布时间", "点赞", "收藏", "评论", "分享", "作品类型", "时长", "热度分", "话题标签", "作品链接"]
            rows = []
            for idx, item in enumerate(items, 1):
                rows.append([
                    idx,
                    _sv(item.get("title")),
                    _sv(item.get("account")),
                    _sv(item.get("publish_time")),
                    item.get("like_count", 0),
                    item.get("collect_count", 0),
                    item.get("comment_count", 0),
                    item.get("share_count", 0),
                    _sv(item.get("work_type")),
                    _sv(item.get("duration")),
                    item.get("hot_score", 0),
                    _sv(item.get("tags")),
                    _sv(item.get("url"))
                ])
            highlight_col = 11  # 热度分列
            highlight_threshold = 60
            
        elif platform_name == "小红书":
            headers = ["排名", "标题", "博主", "发布时间", "点赞", "收藏", "评论", "分享", "互动总数", "相关性", "热度", "时效", "总分", "笔记链接"]
            rows = []
            for idx, item in enumerate(items, 1):
                rows.append([
                    idx,
                    _sv(item.get("title")),
                    _sv(item.get("blogger")),
                    _sv(item.get("publish_time")),
                    item.get("liked_count", 0),
                    item.get("collected_count", 0),
                    item.get("comments_count", 0),
                    item.get("shared_count", 0),
                    item.get("interactive_count", 0),
                    item.get("relevance_score", 0),
                    item.get("hot_score", 0),
                    item.get("timeliness_score", 0),
                    item.get("total_score", 0),
                    _sv(item.get("url"))
                ])
            highlight_col = 13  # 总分列
            highlight_threshold = 13

        elif platform_name == "公众号":
            headers = ["排名", "标题", "作者", "发布时间", "阅读", "在看", "点赞", "评论", "相关性", "热度", "时效", "总分", "摘要", "原文链接"]
            rows = []
            for idx, item in enumerate(items, 1):
                rows.append([
                    idx,
                    _sv(item.get("title")),
                    _sv(item.get("author")),
                    _sv(item.get("publish_time")),
                    item.get("read_count", 0),
                    item.get("looking_count", 0),
                    item.get("like_count", 0),
                    item.get("comment_count", 0),
                    item.get("relevance_score", 0),
                    item.get("hot_score", 0),
                    item.get("timeliness_score", 0),
                    item.get("total_score", 0),
                    _sv(item.get("summary")),
                    _sv(item.get("url"))
                ])
            highlight_col = 12  # 总分列
            highlight_threshold = 13

        elif platform_name == "视频号":
            headers = ["排名", "描述", "作者", "点赞", "评论", "转发", "收藏", "发布时间", "视频链接"]
            rows = []
            for idx, item in enumerate(items, 1):
                rows.append([
                    idx,
                    _sv(item.get("description")),
                    _sv(item.get("author")),
                    item.get("like_count", 0),
                    item.get("comment_count", 0),
                    item.get("forward_count", 0),
                    item.get("fav_count", 0),
                    _sv(item.get("publish_time")),
                    _sv(item.get("url"))
                ])
            highlight_col = 4  # 点赞列
            highlight_threshold = 10000  # 视频号点赞阈值
        
        # 写入表头
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = border
        
        # 写入数据
        for row_idx, row_data in enumerate(rows, 2):
            for col_idx, value in enumerate(row_data, 1):
                # 剔除 openpyxl 不允许的控制字符（如 \x0b 垂直制表符），否则整表导出失败
                if isinstance(value, str):
                    value = _ILLEGAL_RE.sub(" ", value)
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = border
                
                # 数值格式
                if isinstance(value, (int, float)) and col_idx > 1:
                    cell.number_format = "#,##0"
                
                # 链接列
                if col_idx == len(headers) and value:  # 最后一列是链接
                    cell.hyperlink = value
                    cell.font = Font(color="0563C1", underline="single")
                
                # 高亮
                if col_idx == highlight_col and isinstance(value, (int, float)) and value >= highlight_threshold:
                    cell.fill = highlight_fill
        
        # 冻结首行
        ws.freeze_panes = "A2"
        
        # 自动筛选
        ws.auto_filter.ref = ws.dimensions
        
        # 调整列宽
        for col_idx in range(1, len(headers) + 1):
            col_letter = get_column_letter(col_idx)
            if col_idx == 1:  # 排名
                ws.column_dimensions[col_letter].width = 8
            elif col_idx == len(headers):  # 链接
                ws.column_dimensions[col_letter].width = 30
            else:
                ws.column_dimensions[col_letter].width = 15
    
    try:
        wb.save(output_path)
        print(f"✅ Excel 已导出: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Excel 导出失败: {e}", file=sys.stderr)
        return False


def export_html(
    data: Dict[str, List[Dict]],
    output_path: str,
    keywords: List[str],
    timestamp: str
) -> bool:
    """导出 HTML（四平台汇总）"""

    def _s(v, maxlen=None):
        """安全字符串处理：None→空串，按需截断"""
        s = str(v) if v is not None else ""
        if maxlen and len(s) > maxlen:
            s = s[:maxlen]
        return s
    
    html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>四平台爆款数据 - {"_".join(keywords)} - {timestamp}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: #f5f5f5; padding: 20px; }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        h1 {{ color: #333; margin-bottom: 10px; font-size: 24px; }}
        .meta {{ color: #666; margin-bottom: 20px; font-size: 14px; }}
        .platform-section {{ background: white; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .platform-title {{ font-size: 18px; font-weight: bold; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #eee; }}
        .platform-title.douyin {{ color: #000; border-color: #FE2C55; }}
        .platform-title.xiaohongshu {{ color: #FF2442; border-color: #FF2442; }}
        .platform-title.gzh {{ color: #07C160; border-color: #07C160; }}
        .platform-title.shipinhao {{ color: #FA9D3B; border-color: #FA9D3B; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
        th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #eee; }}
        th {{ background: #f8f9fa; font-weight: 600; position: sticky; top: 0; }}
        tr:hover {{ background: #f5f5f5; }}
        .highlight {{ background: #FFE4E1 !important; }}
        .link {{ color: #0563C1; text-decoration: none; }}
        .link:hover {{ text-decoration: underline; }}
        .number {{ text-align: right; font-family: monospace; }}
        .empty {{ text-align: center; color: #999; padding: 40px; }}
        .search-box {{ margin-bottom: 15px; }}
        .search-box input {{ width: 300px; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; }}
        .stats {{ display: flex; gap: 20px; margin-bottom: 15px; font-size: 14px; color: #666; }}
        .stat-item {{ background: #f0f0f0; padding: 5px 10px; border-radius: 4px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 四平台爆款数据汇总</h1>
        <div class="meta">
            关键词: <strong>{"、".join(keywords)}</strong> | 
            生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} | 
            数据来源: 红狐(RedFox)接口
        </div>
"""
    
    platforms = [
        ("douyin", "抖音", data.get("douyin", []), "douyin"),
        ("xiaohongshu", "小红书", data.get("xiaohongshu", []), "xiaohongshu"),
        ("gzh", "公众号", data.get("gzh", []), "gzh"),
        ("shipinhao", "视频号", data.get("shipinhao", []), "shipinhao")
    ]
    
    for platform_key, platform_name, items, css_class in platforms:
        if not items:
            continue
        
        # 计算统计
        total = len(items)
        if platform_key == "douyin":
            highlight_count = sum(1 for i in items if i.get("hot_score", 0) >= 60)
            highlight_label = "热度分≥60"
        elif platform_key in ["xiaohongshu", "gzh"]:
            highlight_count = sum(1 for i in items if i.get("total_score", 0) >= 13)
            highlight_label = "总分≥13"
        else:  # shipinhao
            highlight_count = sum(1 for i in items if i.get("like_count", 0) >= 10000)
            highlight_label = "点赞≥1万"
        
        html_content += f"""
        <div class="platform-section">
            <div class="platform-title {css_class}">📱 {platform_name} ({total} 条)</div>
            <div class="stats">
                <span class="stat-item">总计: {total}</span>
                <span class="stat-item">{highlight_label}: {highlight_count}</span>
            </div>
            <div class="search-box">
                <input type="text" placeholder="搜索 {platform_name} 内容..." onkeyup="filterTable('{platform_key}', this.value)">
            </div>
            <table id="table-{platform_key}">
"""
        
        # 表头和数据行
        if platform_key == "douyin":
            html_content += """<thead><tr><th>排名</th><th>标题</th><th>账号</th><th>发布时间</th><th class="number">点赞</th><th class="number">收藏</th><th class="number">评论</th><th class="number">分享</th><th>类型</th><th class="number">热度分</th><th>话题标签</th><th>链接</th></tr></thead><tbody>"""
            for idx, item in enumerate(items, 1):
                highlight = "highlight" if item.get("hot_score", 0) >= 60 else ""
                html_content += f"""<tr class="{highlight}"><td>{idx}</td><td>{_s(item.get("title"), 50)}</td><td>{_s(item.get("account"))}</td><td>{_s(item.get("publish_time"))}</td><td class="number">{item.get("like_count", 0):,}</td><td class="number">{item.get("collect_count", 0):,}</td><td class="number">{item.get("comment_count", 0):,}</td><td class="number">{item.get("share_count", 0):,}</td><td>{_s(item.get("work_type"))}</td><td class="number">{item.get("hot_score", 0)}</td><td>{_s(item.get("tags"))}</td><td><a href="{_s(item.get("url"))}" class="link" target="_blank">查看</a></td></tr>"""

        elif platform_key == "xiaohongshu":
            html_content += """<thead><tr><th>排名</th><th>标题</th><th>博主</th><th>发布时间</th><th class="number">点赞</th><th class="number">收藏</th><th class="number">评论</th><th class="number">分享</th><th class="number">互动总数</th><th class="number">总分</th><th>链接</th></tr></thead><tbody>"""
            for idx, item in enumerate(items, 1):
                highlight = "highlight" if item.get("total_score", 0) >= 13 else ""
                html_content += f"""<tr class="{highlight}"><td>{idx}</td><td>{_s(item.get("title"), 50)}</td><td>{_s(item.get("blogger"))}</td><td>{_s(item.get("publish_time"))}</td><td class="number">{item.get("liked_count", 0):,}</td><td class="number">{item.get("collected_count", 0):,}</td><td class="number">{item.get("comments_count", 0):,}</td><td class="number">{item.get("shared_count", 0):,}</td><td class="number">{item.get("interactive_count", 0):,}</td><td class="number">{item.get("total_score", 0)}</td><td><a href="{_s(item.get("url"))}" class="link" target="_blank">查看</a></td></tr>"""

        elif platform_key == "gzh":
            html_content += """<thead><tr><th>排名</th><th>标题</th><th>作者</th><th>发布时间</th><th class="number">阅读</th><th class="number">在看</th><th class="number">点赞</th><th class="number">评论</th><th class="number">总分</th><th>摘要</th><th>链接</th></tr></thead><tbody>"""
            for idx, item in enumerate(items, 1):
                highlight = "highlight" if item.get("total_score", 0) >= 13 else ""
                html_content += f"""<tr class="{highlight}"><td>{idx}</td><td>{_s(item.get("title"), 50)}</td><td>{_s(item.get("author"))}</td><td>{_s(item.get("publish_time"))}</td><td class="number">{item.get("read_count", 0):,}</td><td class="number">{item.get("looking_count", 0):,}</td><td class="number">{item.get("like_count", 0):,}</td><td class="number">{item.get("comment_count", 0):,}</td><td class="number">{item.get("total_score", 0)}</td><td>{_s(item.get("summary"), 50)}</td><td><a href="{_s(item.get("url"))}" class="link" target="_blank">查看</a></td></tr>"""

        elif platform_key == "shipinhao":
            html_content += """<thead><tr><th>排名</th><th>描述</th><th>作者</th><th class="number">点赞</th><th class="number">评论</th><th class="number">转发</th><th class="number">收藏</th><th>发布时间</th><th>链接</th></tr></thead><tbody>"""
            for idx, item in enumerate(items, 1):
                highlight = "highlight" if item.get("like_count", 0) >= 10000 else ""
                html_content += f"""<tr class="{highlight}"><td>{idx}</td><td>{_s(item.get("description"), 50)}</td><td>{_s(item.get("author"))}</td><td class="number">{item.get("like_count", 0):,}</td><td class="number">{item.get("comment_count", 0):,}</td><td class="number">{item.get("forward_count", 0):,}</td><td class="number">{item.get("fav_count", 0):,}</td><td>{_s(item.get("publish_time"))}</td><td><a href="{_s(item.get("url"))}" class="link" target="_blank">查看</a></td></tr>"""
        
        html_content += "</tbody></table></div>"
    
    html_content += """
    </div>
    <script>
        function filterTable(platform, keyword) {
            const table = document.getElementById('table-' + platform);
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
            keyword = keyword.toLowerCase();
            for (let row of rows) {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(keyword) ? '' : 'none';
            }
        }
    </script>
</body>
</html>"""
    
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"✅ HTML 已导出: {output_path}")
        return True
    except Exception as e:
        print(f"❌ HTML 导出失败: {e}", file=sys.stderr)
        return False


def main():
    parser = argparse.ArgumentParser(description="四大平台选题关键词搜索")
    parser.add_argument("--keyword", required=True, help="搜索关键词，多个用逗号分隔")
    parser.add_argument("--output", choices=["excel", "html", "both"], default="both", help="输出格式")
    parser.add_argument("--outdir", default=".", help="输出目录")
    parser.add_argument("--max-items", type=int, default=50, help="每平台最大条数")
    parser.add_argument("--start-date", help="开始日期 YYYY-MM-DD")
    parser.add_argument("--api-key", help="RedFox API Key")
    parser.add_argument("--debug", action="store_true", help="调试模式")
    parser.add_argument("--sort-by", default=None, help="排序字段：comment=评论 / like=点赞 / collect=收藏 / share=分享 / total=总分（默认各平台默认排序）")
    parser.add_argument("--xhs-sort-type", choices=["_0", "_2", "_4"], default="_2",
                        help="小红书服务端排序（仅无时间窗时生效）：_4 最热(互动数) / _2 最新发布(默认) / _0 相关性")
    parser.add_argument("--days", type=int, default=None,
                        help="相对时间窗天数；>0=四平台仅保留最近 N 天，0=四平台均不限制时间窗（小红书配合 --xhs-sort-type _4 即最热N条整体）；不填=各平台默认")
    
    args = parser.parse_args()
    
    # 解析关键词
    keywords = parse_keywords(args.keyword)
    if not keywords:
        print("❌ 错误：未提供有效关键词", file=sys.stderr)
        sys.exit(1)
    
    print(f"🔍 搜索关键词: {', '.join(keywords)}")
    
    # 获取 API Key
    api_key = get_api_key(args)
    if not api_key:
        print("❌ 错误：未找到 REDFOX_API_KEY", file=sys.stderr)
        print("请配置 config.env 或设置环境变量 REDFOX_API_KEY", file=sys.stderr)
        sys.exit(1)
    
    # 生成时间戳
    timestamp = datetime.now().strftime("%m%d_%H%M")
    
    # 确保输出目录存在
    os.makedirs(args.outdir, exist_ok=True)
    
    # 拉取四平台数据
    print("\n📡 开始拉取四平台数据...")
    
    # 显示排序方式
    if args.sort_by:
        sort_names = {
            "comment": "评论数",
            "like": "点赞数",
            "collect": "收藏数",
            "share": "分享数",
            "total": "总分/热度"
        }
        print(f"  排序方式: 按{sort_names.get(args.sort_by, args.sort_by)}降序")
    
    # 处理 --days：>0 折算为四平台统一的 start_date；0 显式关闭各平台时间窗；不填=各平台默认
    eff_start_date = args.start_date
    xhs_days = None
    if args.days is not None:
        if args.days > 0:
            eff_start_date = (datetime.now() - timedelta(days=args.days)).strftime("%Y-%m-%d")
            print(f"  时间窗: 最近 {args.days} 天 (>= {eff_start_date})")
        else:  # 0 => 不限制时间窗
            eff_start_date = None
            xhs_days = 0
            print("  时间窗: 不限制（各平台取最热/最新整体）")

    data = {}
    
    print("  → 抖音...")
    data["douyin"] = fetch_douyin(keywords, api_key, args.max_items, eff_start_date, args.debug, args.sort_by)
    print(f"    ✓ 获取 {len(data['douyin'])} 条")
    
    print("  → 小红书...")
    data["xiaohongshu"] = fetch_xiaohongshu(keywords, api_key, args.max_items, eff_start_date, args.debug, args.sort_by, args.xhs_sort_type, xhs_days)
    print(f"    ✓ 获取 {len(data['xiaohongshu'])} 条")
    
    print("  → 公众号...")
    data["gzh"] = fetch_gzh(keywords, api_key, args.max_items, eff_start_date, args.debug, args.sort_by)
    print(f"    ✓ 获取 {len(data['gzh'])} 条")
    
    print("  → 视频号...")
    data["shipinhao"] = fetch_shipinhao(keywords, api_key, args.max_items, eff_start_date, args.debug, args.sort_by)
    print(f"    ✓ 获取 {len(data['shipinhao'])} 条")
    
    # 生成输出路径
    excel_path, html_path = generate_filename(keywords, args.outdir, timestamp)
    
    # 导出
    success = True
    
    if args.output in ["excel", "both"]:
        print("\n📊 导出 Excel...")
        if not export_excel(data, excel_path, keywords, timestamp):
            success = False
    
    if args.output in ["html", "both"]:
        print("\n🌐 导出 HTML...")
        if not export_html(data, html_path, keywords, timestamp):
            success = False
    
    if success:
        print(f"\n✅ 完成！输出文件:")
        if args.output in ["excel", "both"]:
            print(f"   Excel: {excel_path}")
        if args.output in ["html", "both"]:
            print(f"   HTML:  {html_path}")
    else:
        print("\n⚠️  部分导出失败", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
