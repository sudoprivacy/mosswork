#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
公众号平台数据获取模块
"""

import json
import urllib.request
import urllib.error
from datetime import datetime, timedelta


def _num(v):
    """把可能带逗号/空值的数字统一成 int/float"""
    if v is None:
        return 0
    if isinstance(v, (int, float)):
        return v
    s = str(v).replace(",", "").strip()
    if s == "":
        return 0
    try:
        return int(s)
    except ValueError:
        try:
            return float(s)
        except ValueError:
            return 0


def http_post(url, body, headers):
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"__http_error__": e.code}
    except Exception as e:
        return {"__error__": str(e)}


def fetch_gzh_articles(keywords, api_key, max_items=50, start_date=None, debug=False, sort_field="totalScore"):
    """调用红狐公众号接口，返回文章列表（已去重、按指定字段降序）
    
    参数:
        sort_field: 排序字段，默认 totalScore（总分），可选 likeCount/clicksCount/watchCount/commentsCount
    """
    API_URL = "https://redfox.hk/story/api/gzh/search/hotArticleNew"

    headers = {"Content-Type": "application/json", "X-API-Key": api_key}
    end_date = datetime.now().strftime("%Y-%m-%d")

    def _query(date_start):
        collected = []
        for kw in keywords:
            body = {
                "keyword": kw,
                "startDate": date_start,
                "endDate": end_date,
                "source": "公众号选题关键词搜索-SkillHub",
            }
            if debug:
                print(f"[debug] 公众号查询关键词={kw!r} 范围 {date_start} ~ {end_date}")
            res = http_post(API_URL, body, headers)
            if "__http_error__" in res:
                raise Exception(f"HTTP 错误: {res['__http_error__']}")
            if "__error__" in res:
                raise Exception(f"请求异常: {res['__error__']}")
            if res.get("code") != 2000:
                raise Exception(f"接口返回错误: {res.get('msg')}")
            collected.extend(res.get("data", {}).get("articles", []))
        return collected

    def _dedupe(items):
        seen, out = set(), []
        for a in items:
            aid = a.get("id")
            if aid and aid not in seen:
                seen.add(aid)
                out.append(a)
        return out

    s7 = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    s30 = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")

    if start_date:
        articles = _dedupe(_query(start_date))
    else:
        articles = _dedupe(_query(s7))
        if len(articles) < 10:
            if debug:
                print("[debug] 公众号近7天数据不足，拓展至近30天")
            articles = _dedupe(_query(s30))

    # 规整字段
    normalized = []
    for a in articles:
        normalized.append({
            "title": a.get("title", ""),
            "author": a.get("author", ""),
            "publish_time": a.get("publicTime", "")[:10] if a.get("publicTime") else "",
            "read_count": _num(a.get("clicksCount")),
            "looking_count": _num(a.get("watchCount")),
            "like_count": _num(a.get("likeCount")),
            "comment_count": _num(a.get("commentsCount")),
            "relevance_score": a.get("relevanceScore", 0),
            "hot_score": a.get("popularityScore", 0),
            "timeliness_score": a.get("recencyScore", 0),
            "total_score": a.get("totalScore", 0),
            "summary": a.get("summary", ""),
            "url": a.get("url", ""),
        })

    # 按指定字段排序
    sort_key_map = {
        "totalScore": "total_score",
        "likeCount": "like_count",
        "clicksCount": "read_count",
        "watchCount": "looking_count",
        "commentsCount": "comment_count",
    }
    sort_key = sort_key_map.get(sort_field, "total_score")
    normalized.sort(key=lambda x: _num(x.get(sort_key)), reverse=True)
    return normalized[:max_items]
