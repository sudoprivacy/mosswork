#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书平台数据获取模块（优质库 / searchArticle）
接口：POST https://redfox.hk/story/api/xhsUser/searchArticle

特性（已与 baoge-xhs-keyword-search-top20 合并）：
- 使用红狐「优质库」接口，关键词全量匹配，**不限 1000+ 互动门槛**（与爆款库相反）。
- 网络请求带 **3 次重试 + 退避**（与视频号模块一致）：可扛红狐上游瞬时挂起；
  对 5xx 网关错误（502/503/504）也重试，4xx 鉴权/参数错误立即失败。
- 支持服务端排序 sortType：_0 相关性 / _2 最新(发布时间) / _4 最热(互动数)。
- 支持时间窗：全局 --start-date（绝对日期）或 --days（相对天数，XHS 专属）；
  --days=0 表示不限制时间窗（配合 --xhs-sort-type _4 即"该关键词下最热 N 条整体"）。
- 时间窗内按指定字段（互动总数/点赞/评论/收藏/分享）降序取前 N 条。

时间窗与排序的协作规则：
1. 有窗口（start_date 或 days>0）：必须按 _2(最新) 拉取，发布时间单调递减，
   遇到早于窗口起点的作品即停止翻页（窗口内全量收集，无遗漏），再按 --sort-by 降序取前 N。
2. 无窗口（days=0 或未指定任何时间参数）：按 --xhs-sort-type 指定的服务端排序拉取，
   _4 直接得到最热 N 条，_2 得到最新 N 条，_0 保持相关性顺序；再按 --sort-by 兜底重排。
"""

import json
import time
import urllib.request
import urllib.error
from datetime import datetime, timedelta


def _num(v):
    """把可能带逗号/空值的数字统一成 int（互动数用于排序与展示）。"""
    if v is None:
        return 0
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).replace(",", "").strip()
    if s == "":
        return 0
    # 处理 "5w+" 这类格式
    if s.endswith("w+"):
        try:
            return int(float(s[:-2]) * 10000)
        except ValueError:
            return 0
    try:
        return int(float(s))
    except ValueError:
        return 0


def _parse_time(s):
    """解析发布时间，兼容 '2025-07-21 17:09:42' / '2025-07-21' / 毫秒或秒级时间戳。
    解析失败返回 None（时间窗模式下无法判定时间的笔记将被跳过）。"""
    if not s:
        return None
    if isinstance(s, (int, float)):
        try:
            ts = float(s)
            if ts > 1e12:  # 毫秒时间戳
                ts = ts / 1000.0
            return datetime.fromtimestamp(ts)
        except (ValueError, OverflowError, OSError):
            return None
    s = str(s).strip()
    if not s:
        return None
    if " " in s:
        candidates = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
                      "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M"]
    else:
        candidates = ["%Y-%m-%d", "%Y/%m/%d"]
    for fmt in candidates:
        try:
            return datetime.strptime(s[:19] if " " in s else s[:10], fmt)
        except ValueError:
            continue
    return None


def _normalize(raw):
    """将红狐 XHS 优质库原始作品对象规整为本脚本使用的字段字典。"""
    liked = _num(raw.get("workLikedCount"))
    collected = _num(raw.get("workCollectedCount"))
    comments = _num(raw.get("workCommentsCount"))
    shared = _num(raw.get("workSharedCount"))
    return {
        "title": raw.get("workTitle", "") or (raw.get("workDesc", "") or "")[:50],
        "blogger": raw.get("accountNickname", ""),
        "publish_time": raw.get("workPublishTime", ""),
        "liked_count": liked,
        "collected_count": collected,
        "comments_count": comments,
        "shared_count": shared,
        "interactive_count": liked + collected + comments + shared,
        "relevance_score": 0,
        "hot_score": 0,
        "timeliness_score": 0,
        "total_score": 0,  # 优质库无总分字段
        "url": raw.get("workUrl", ""),
        "work_id": raw.get("workId", ""),
        "work_type": raw.get("workType", ""),
        "cover_url": raw.get("coverUrl", ""),
    }


def http_post(url, body, headers, retries=3):
    """POST JSON，带重试与退避。

    重试范围：
      - 网络瞬时错误（urllib.error.URLError / ConnectionError / TimeoutError / OSError）
        例如红狐上游挂起导致的 read timeout，按 1s/2s 退避重试。
      - 5xx 网关错误（502/503/504）这类上游瞬时故障，同样重试。
    不重试：4xx（鉴权/参数等确定性错误）直接抛出，避免无效重试。
    失败时抛出 RuntimeError（含已重试次数），由调用方统一捕获。
    """
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                method="POST",
                headers=headers,
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if 500 <= e.code < 600:
                # 网关/上游瞬时故障，重试
                last_err = e
                if attempt < retries:
                    time.sleep(attempt)
                    continue
                raise RuntimeError(f"小红书接口持续返回 {e.code}（已重试 {retries} 次）")
            raise  # 4xx 等非重试错误，直接抛出
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            last_err = e
            if attempt < retries:
                time.sleep(attempt)
                continue
    if last_err is not None:
        raise RuntimeError(f"网络请求失败（已重试 {retries} 次）：{last_err}")
    raise RuntimeError(f"网络请求失败（已重试 {retries} 次）")


def fetch_xiaohongshu_notes(
    keywords,
    api_key,
    max_items=50,
    start_date=None,
    debug=False,
    sort_by="totalScore",
    sort_type="_2",
    days=None,
):
    """调用红狐 XHS 优质库接口，返回笔记列表。

    参数:
        keywords:   关键词列表（每个关键词分别查询，按 workId 去重合并）。
        api_key:    红狐接口密钥。
        max_items:  每平台最大条数（自动分页拉取）。
        start_date: 绝对时间窗起点 YYYY-MM-DD（全局 --start-date 透传）。优先级高于 days。
        sort_by:    客户端最终排序字段，可选：
                     totalScore(互动总数,默认) / likedCount / collectedCount /
                     commentsCount / sharedCount / interactiveCount。
        sort_type:  无时间窗时的服务端排序：_0 相关性 / _2 最新 / _4 最热（默认 _2）。
        days:       XHS 专属相对天数窗；None=沿用 start_date 或默认 7 天；
                    >0=最近 N 天；0=不限制时间窗（最热 N 条整体）。

    返回: 按规则排序后的笔记字典列表（最多 max_items 条）。
    """
    API_URL = "https://redfox.hk/story/api/xhsUser/searchArticle"
    PAGE_SIZE = 20  # 优质库每页固定 20 条
    MAX_PAGES = 50  # 安全上限，最多拉 1000 条

    headers = {"Content-Type": "application/json", "REDFOX_API_KEY": api_key}
    now = datetime.now()

    # 1) 确定时间窗 cutoff（优先级：start_date > days>0 > days==0(无窗) > 默认 7 天）
    cutoff = None
    if start_date:
        try:
            cutoff = datetime.strptime(start_date, "%Y-%m-%d")
        except ValueError:
            cutoff = now - timedelta(days=7)
    elif days is not None:
        if days > 0:
            cutoff = now - timedelta(days=days)
        # days == 0 → cutoff 保持 None（不限制时间窗）
    else:
        cutoff = now - timedelta(days=7)  # 历史默认：近 7 天

    # 2) 确定服务端拉取排序：有窗口必须按 _2（时间单调递减，便于提前停止翻页）
    fetch_sort = "_2" if cutoff is not None else sort_type

    if debug:
        win_label = cutoff.strftime("%Y-%m-%d") if cutoff else "不限制"
        print(f"[debug] 小红书时间窗: >= {win_label} | 服务端排序: {fetch_sort}")

    # 3) 分页拉取
    collected = {}
    for kw in keywords:
        offset = 0
        for page in range(1, MAX_PAGES + 1):
            body = {
                "keyword": kw,
                "offset": offset,
                "sortType": fetch_sort,
            }
            if debug:
                print(f"[debug] 小红书查询关键词={kw!r} offset={offset} sortType={fetch_sort}")
            res = http_post(API_URL, body, headers)
            if "__http_error__" in res:
                raise Exception(f"HTTP 错误: {res['__http_error__']}")
            if "__error__" in res:
                raise Exception(f"请求异常: {res['__error__']}")
            if res.get("code") != 2000:
                raise Exception(f"接口返回错误: {res.get('msg')}")

            data = res.get("data", {})
            arts = data.get("list", []) or []
            has_more = bool(data.get("hasMore", False))

            if not arts:
                break

            stop = False
            for a in arts:
                # 仅当按 _2 拉取且有窗口时，时间才单调递减，可安全提前停止
                if cutoff is not None and fetch_sort == "_2":
                    pub_dt = _parse_time(a.get("workPublishTime"))
                    if pub_dt is not None and pub_dt < cutoff:
                        stop = True
                        break
                aid = a.get("workId")
                if aid and aid not in collected:
                    collected[aid] = a

            if debug:
                print(f"[debug] 本页获取 {len(arts)} 条，窗口内累计 {len(collected)} 条，hasMore={has_more}")

            if stop:
                if debug:
                    print("[debug] 已遇到窗口外作品，停止翻页")
                break
            if not has_more or len(arts) < PAGE_SIZE:
                break

            offset += PAGE_SIZE

    notes = [_normalize(a) for a in collected.values()]

    # 4) 防御性时间过滤（仅当非 _2 拉取却带窗口时，理论上不会发生，保留兜底）
    if cutoff is not None and fetch_sort != "_2":
        notes = [
            n for n in notes
            if (_parse_time(n.get("publish_time")) or datetime.min) >= cutoff
        ]

    # 5) 最终排序
    sort_key_map = {
        "totalScore": "interactive_count",       # 互动总数
        "interactiveCount": "interactive_count",
        "likedCount": "liked_count",
        "collectedCount": "collected_count",
        "commentsCount": "comments_count",
        "sharedCount": "shared_count",
    }
    if sort_by and sort_by in sort_key_map:
        field = sort_key_map[sort_by]
        notes.sort(key=lambda x: _num(x.get(field)), reverse=True)
    elif cutoff is not None or sort_type == "_4":
        # 有窗口或要求最热：按互动总数降序
        notes.sort(key=lambda x: _num(x.get("interactive_count")), reverse=True)
    elif fetch_sort == "_2":
        # 无窗口且要求最新：按发布时间降序
        notes.sort(
            key=lambda x: _parse_time(x.get("publish_time")) or datetime.min,
            reverse=True,
        )
    # sort_type == "_0"（相关性）且不在上述分支：保持服务端返回顺序，不重排

    if debug:
        mode = "窗口内" if cutoff else f"无窗口({sort_type})"
        print(f"[debug] 小红书{mode}共 {len(notes)} 条，取前 {max_items} 条")

    return notes[:max_items]
