#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
视频号平台数据获取模块
"""

import json
import urllib.request
import urllib.error
from datetime import datetime, timedelta


def _num(v):
    """把可能带逗号/空值的数字统一成 int"""
    if v is None:
        return 0
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v).replace(",", "").strip()
    if s == "":
        return 0
    try:
        return int(float(s))
    except ValueError:
        return 0


def parse_pubtime(s):
    """把接口返回的 'YYYY-MM-DD HH:MM:SS' 解析为 datetime"""
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(s), fmt)
        except ValueError:
            continue
    return None


def http_post(url, body, headers, retries=3):
    import time as _time
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                method="POST",
                headers=headers,
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode("utf-8")
            payload = json.loads(raw)
            if payload.get("code") != 2000:
                raise RuntimeError(f"接口返回错误 code={payload.get('code')} msg={payload.get('msg')}")
            return payload.get("data") or {}
        except urllib.error.HTTPError:
            raise
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            last_err = e
            if attempt < retries:
                _time.sleep(attempt)
            continue
    if isinstance(last_err, urllib.error.HTTPError):
        raise last_err
    raise RuntimeError(f"网络请求失败（已重试 {retries} 次）：{last_err}")


def fetch_shipinhao_works(keywords, api_key, max_items=50, start_date=None, debug=False, rank_by="like"):
    """调用红狐视频号接口，返回作品列表（按指定指标降序）
    
    参数:
        rank_by: 排序指标，默认 like（点赞），可选 comment/forward/fav
    """
    API_URL = "https://redfox.hk/story/api/sphAllData/searchWork"

    headers = {
        "Content-Type": "application/json;charset=UTF-8",
        "X-API-Key": api_key,
    }

    # 计算时间窗口
    if start_date:
        try:
            start_dt = datetime.strptime(start_date, "%Y-%m-%d")
            days = (datetime.now() - start_dt).days
        except ValueError:
            days = 7
    else:
        days = 7

    cutoff = datetime.now() - timedelta(days=days)

    # 视频号接口只支持单关键词，多关键词时循环查询并合并
    all_collected = []
    seen = set()
    
    for kw in keywords:
        collected = []
        # 视频号接口没有时间参数，用"最新"排序拉取，客户端过滤
        for page in range(1, 21):  # 最多20页
            body = {
                "keyword": kw,
                "sort": "最新",
                "page": page,
                "size": 50,
                "source": "redfox_web",
            }
            if debug:
                print(f"[debug] 视频号查询关键词={kw!r} 第{page}页")

            data = http_post(API_URL, body, headers)
            items = data.get("list") or []
            if not items:
                break

            times = [parse_pubtime(it.get("publishTime")) for it in items]
            times = [t for t in times if t]

            for it in items:
                pt = parse_pubtime(it.get("publishTime"))
                if pt is None:
                    collected.append(it)
                    continue
                if pt >= cutoff:
                    collected.append(it)

            # 本页最老时间若已早于 cutoff，后续页只会更老，可停止
            if times and min(times) < cutoff:
                break

            if len(collected) >= max_items * 2:  # 多收集一些，后面过滤
                break
        
        # 合并到总列表
        all_collected.extend(collected)
        if debug:
            print(f"[debug] 视频号关键词={kw!r} 收集到 {len(collected)} 条")

    # 跨关键词去重
    unique = []
    for it in all_collected:
        key = it.get("videoUrl") or it.get("description")
        if key and key not in seen:
            seen.add(key)
            unique.append(it)

    # 规整字段
    normalized = []
    for it in unique:
        normalized.append({
            "description": (it.get("description") or "")[:100],
            "author": it.get("nickname", ""),
            "like_count": _num(it.get("likeCount")),
            "comment_count": _num(it.get("commentCount")),
            "forward_count": _num(it.get("forwardCount")),
            "fav_count": _num(it.get("favCount")),
            "publish_time": it.get("publishTime", ""),
            "url": it.get("videoUrl", ""),
        })

    # 按指定指标降序
    rank_field_map = {
        "like": "like_count",
        "comment": "comment_count",
        "forward": "forward_count",
        "fav": "fav_count",
    }
    sort_field = rank_field_map.get(rank_by, "like_count")
    normalized.sort(key=lambda x: x.get(sort_field, 0), reverse=True)

    return normalized[:max_items]
