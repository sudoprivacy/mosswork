"""Rhino7 protocol/PowerShell regression tests. Uses mocks, NOT a native kernel."""
import base64
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / 'scripts/rhino7'
SHELLS = list(dict.fromkeys(filter(None, [shutil.which('powershell'), shutil.which('pwsh')])))


def module():
    stubs = {name: types.ModuleType(name) for name in ['Rhino','System','scriptcontext','rhinoscriptsyntax']}
    spec = importlib.util.spec_from_file_location('bridge7_test', BRIDGE / 'bridge.py')
    result = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, stubs):
        spec.loader.exec_module(result)
    result.basestring, result.long = str, int
    return result


class BridgeLogic(unittest.TestCase):
    def setUp(self):
        self.m = module()
        self.bridge = object.__new__(self.m.Bridge)
        self.bridge.token = 'a' * 64
        self.bridge.records = {}
        self.bridge.lock = threading.Lock()
        self.count = 0
        def schedule(ident, method, params, record):
            self.count += 1
            record['response'] = {'id':ident,'status':'ok','result':params}
            record['event'].set()
        self.bridge.schedule = schedule

    def request(self, ident='abc', params=None, **changes):
        request = dict(protocol=self.m.PROTOCOL, token=self.bridge.token, id=ident,
                       method='run_python', params=params or {})
        request.update(changes)
        left, right = socket.socketpair()
        thread = threading.Thread(target=self.bridge.handle, args=(left,))
        thread.start()
        right.sendall(json.dumps(request).encode() + b'\n')
        stream = right.makefile('rb')
        response = json.loads(stream.readline())
        stream.close(); right.close(); thread.join(3)
        return response

    def test_repeated_request_executes_once(self):
        self.assertEqual(self.request(params={'text':'中文'}), self.request(params={'text':'中文'}))
        self.assertEqual(self.count, 1)

    def test_changed_arguments_same_id_rejected(self):
        self.request(params={'x':1})
        self.assertEqual(self.request(params={'x':2})['status'], 'error')
        self.assertEqual(self.count, 1)

    def test_token_rejected_before_dispatch(self):
        self.assertEqual(self.request(token='wrong')['execution_state'], 'not_dispatched')
        self.assertEqual(self.count, 0)

    def test_status_returns_previous_result(self):
        original = self.request(params={'x':3})
        reply = self.request(ident='query',method='get_request_status',params={'request_id':'abc'})
        self.assertEqual(reply['result'], original)
        self.assertEqual(self.count, 1)

    def test_nonfinite_rejected(self):
        for source in ['{"x":NaN}', '{"x":Infinity}', '{"x":1e400}']:
            with self.assertRaises(ValueError): self.m.strict_json(source)

    def test_document_guard(self):
        self.m.Rhino.RhinoDoc = types.SimpleNamespace(ActiveDoc=types.SimpleNamespace(RuntimeSerialNumber=12,Path=''))
        for value in [True, 0, 1, '12']:
            with self.assertRaises(ValueError): self.m.checked_doc({'expected_document_serial':value})
        self.assertEqual(self.m.checked_doc({'expected_document_serial':12}).RuntimeSerialNumber, 12)

    def test_failed_execution_restores_document_and_ends_undo(self):
        ended=[]
        doc=types.SimpleNamespace(RuntimeSerialNumber=12,Path='',BeginUndoRecord=lambda name:7,EndUndoRecord=lambda value:ended.append(value))
        self.m.Rhino.RhinoDoc=types.SimpleNamespace(ActiveDoc=doc)
        self.m.sc.doc='previous'
        self.m.live_objects=lambda document:[]
        self.bridge.folder=str(BRIDGE)
        with self.assertRaises(RuntimeError):
            self.bridge.execute('run_python',dict(expected_document_serial=12,run_id='test',code='raise RuntimeError("fixture")'))
        self.assertEqual(ended,[7]); self.assertEqual(self.m.sc.doc,'previous')

    def test_mismatched_document_never_begins_undo(self):
        begun=[]
        doc=types.SimpleNamespace(RuntimeSerialNumber=12,Path='',BeginUndoRecord=lambda name:begun.append(name))
        self.m.Rhino.RhinoDoc=types.SimpleNamespace(ActiveDoc=doc)
        with self.assertRaises(ValueError):
            self.bridge.execute('run_python',dict(expected_document_serial=13,run_id='test',code='result={}'))
        self.assertEqual(begun,[])

    def test_idle_callbacks_do_not_reenter_mutations(self):
        class Idle:
            def __init__(self): self.handlers=[]
            def __iadd__(self,handler): self.handlers.append(handler);return self
            def __isub__(self,handler): self.handlers.remove(handler);return self
            def tick(self):
                for handler in list(self.handlers):
                    if handler in self.handlers: handler(None,None)
        idle=Idle(); self.m.Rhino.RhinoApp=types.SimpleNamespace(Idle=idle)
        self.bridge.executing=False
        active=[0];peak=[0];order=[]
        def execute(method,params):
            active[0]+=1;peak[0]=max(peak[0],active[0]);order.append(params['n'])
            idle.tick()
            active[0]-=1
            return {}
        self.bridge.execute=execute
        records=[{'event':threading.Event()} for _ in range(2)]
        for n,record in enumerate(records): self.m.Bridge.schedule(self.bridge,str(n),'run_python',{'n':n},record)
        idle.tick()
        self.assertEqual(order,[0,1]);self.assertEqual(peak[0],1)
        self.assertTrue(all(r['event'].is_set() for r in records))

    def test_ledger_limit_preserves_previous_results(self):
        self.bridge.records={str(n):{} for n in range(4096)}
        reply=self.request(ident='new-request')
        self.assertEqual(reply['status'],'error');self.assertEqual(self.count,0)
        self.assertEqual(len(self.bridge.records),4096)


@unittest.skipUnless(os.name == 'nt' and SHELLS, 'Windows PowerShell required')
class PowerShellProtocol(unittest.TestCase):
    def run_stdio(self, shell, lines, extra=()):
        result = subprocess.run([shell,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(BRIDGE/'stdio.ps1'),*extra],
                                input=('\n'.join(json.dumps(x) if not isinstance(x,str) else x for x in lines)+'\n').encode(),
                                capture_output=True,timeout=25)
        self.assertEqual(result.returncode,0,result.stderr)
        return [json.loads(line) for line in result.stdout.decode('utf-8-sig').splitlines() if line.strip()]

    def test_mcp_initialize_list_ping_parse_errors(self):
        lines=[dict(jsonrpc='2.0',id=1,method='initialize',params={'protocolVersion':'2025-06-18'}),
               dict(jsonrpc='2.0',method='notifications/initialized'),dict(jsonrpc='2.0',id=2,method='tools/list'),
               dict(jsonrpc='2.0',id=3,method='ping'),'{broken',dict(jsonrpc='2.0',id=5,method='nope')]
        for shell in SHELLS:
            result=self.run_stdio(shell,lines)
            self.assertEqual(len(result),5)
            self.assertEqual(result[0]['result']['protocolVersion'],'2025-06-18')
            self.assertEqual(len(result[1]['result']['tools']),5)
            self.assertEqual(result[3]['error']['code'],-32700)
            self.assertEqual(result[4]['error']['code'],-32601)

    def fake_call(self,shell,kind):
        with tempfile.TemporaryDirectory(prefix='rhino7-protocol-') as temporary:
            server=socket.socket(); server.bind(('127.0.0.1',0)); server.listen(1); server.settimeout(15)
            session=Path(temporary)/'session.json'
            session.write_text(json.dumps(dict(protocol='rhino-shenbi-7/1',host='127.0.0.1',port=server.getsockname()[1],
                                               token='a'*64,pid=12345,rhino_major=7)),encoding='utf-8')
            received=[]
            def serve():
                try:
                    client,_=server.accept()
                    with client,client.makefile('rb') as stream:
                        request=json.loads(stream.readline()); received.append(request)
                        if kind=='disconnect': return
                        value={'image_base64':base64.b64encode(b'png-fixture').decode(),'document_serial':12}
                        response=dict(status='ok',id=request['id'] if kind!='wrong-id' else 'wrong',result=value)
                        encoded=json.dumps(response).encode()+b'\n'
                        client.sendall(encoded[:7]); client.sendall(encoded[7:])
                finally: server.close()
            thread=threading.Thread(target=serve,daemon=True);thread.start()
            result=self.run_stdio(shell,[dict(jsonrpc='2.0',id=9,method='tools/call',params={'name':'get_viewport_image','arguments':{'expected_document_serial':12}})],
                                  ('-SessionFile',str(session)))[0]['result']
            thread.join(3)
            self.assertEqual(len(received),1)
            return result

    def test_chunked_reply_and_mcp_image(self):
        for shell in SHELLS:
            result=self.fake_call(shell,'success')
            self.assertFalse(result['isError'])
            self.assertEqual(result['content'][0]['type'],'image')

    def test_disconnect_is_unknown_and_not_replayed(self):
        for shell in SHELLS:
            result=self.fake_call(shell,'disconnect')
            self.assertTrue(result['isError'])
            self.assertEqual(json.loads(result['content'][0]['text'])['execution_state'],'unknown')

    def test_wrong_reply_id_is_unknown(self):
        for shell in SHELLS:
            result=self.fake_call(shell,'wrong-id')
            self.assertTrue(result['isError'])
            self.assertEqual(json.loads(result['content'][0]['text'])['execution_state'],'unknown')

    def test_rhino7_config_no_external_python_and_no_overwrite(self):
        for shell in SHELLS:
            with tempfile.TemporaryDirectory(prefix='rhino7-config-') as folder:
                out=Path(folder)/'mcp.json'
                command=[shell,'-NoProfile','-File',str(ROOT/'scripts/configure-mcp.ps1'),'-RhinoVersion','7','-RhinoPid','12345','-OutFile',str(out)]
                result=subprocess.run(command,capture_output=True,timeout=15)
                self.assertEqual(result.returncode,0,result.stderr)
                before=out.read_bytes(); entry=json.loads(before)['mcpServers']['rhino-cn']
                self.assertTrue(entry['command'].endswith('powershell.exe'))
                self.assertEqual(entry['args'][-2:],['-RhinoPid','12345'])
                self.assertNotEqual(subprocess.run(command,capture_output=True,timeout=15).returncode,0)
                self.assertEqual(before,out.read_bytes())

    def test_all_powershell_files_parse_on_both_engines(self):
        for shell in SHELLS:
            command='$ErrorActionPreference="Stop"; $bad=@(); Get-ChildItem -LiteralPath '+"'"+str(ROOT/'scripts').replace("'","''")+"'"+' -Recurse -Filter *.ps1 | ForEach-Object { $tokens=$null; $errors=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tokens,[ref]$errors); $bad+=@($errors) }; if($bad.Count){$bad | Out-String | Write-Output; exit 1}'
            result=subprocess.run([shell,'-NoProfile','-Command',command],capture_output=True,timeout=20)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)

    def test_setup7_prepare_and_failed_start_with_mock_executable(self):
        csc=Path(os.environ.get('SystemRoot',r'C:\Windows'))/'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
        if not csc.is_file(): self.skipTest('.NET framework compiler required')
        with tempfile.TemporaryDirectory(prefix='rhino7-setup-') as temporary:
            folder=Path(temporary)/'中文 paths $literal'; folder.mkdir()
            source=folder/'fixture.cs'
            source.write_text('[assembly:System.Reflection.AssemblyFileVersion("7.32.0.0")] class Fixture { static void Main() {} }',encoding='utf-8')
            build=subprocess.run([str(csc),'/nologo','/target:exe','/out:'+str(folder/'Rhino.exe'),str(source)],capture_output=True)
            self.assertEqual(build.returncode,0,build.stdout+build.stderr)
            for shell in SHELLS:
                for flag in ['-PrepareOnly','-WhatIf']:
                    command=[shell,'-NoProfile','-File',str(ROOT/'scripts/setup-rhino.ps1'),'-RhinoVersion','7','-RhinoSystem',str(folder),flag]
                    result=subprocess.run(command,capture_output=True,timeout=15)
                    self.assertEqual(result.returncode,0,result.stderr)
                    value=json.loads(result.stdout)
                    self.assertEqual(value['status'],'prepared');self.assertFalse(value['downloads_required']);self.assertFalse(value['launches_process'])
                # Mock exits immediately, so the helper must never report ready.
                result=subprocess.run([shell,'-NoProfile','-File',str(ROOT/'scripts/setup-rhino7.ps1'),'-RhinoSystem',str(folder),'-WaitSeconds','3'],capture_output=True,timeout=20)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertIn(json.loads(result.stdout)['status'],['startup_failed','attach_required'])


if __name__=='__main__': unittest.main()
