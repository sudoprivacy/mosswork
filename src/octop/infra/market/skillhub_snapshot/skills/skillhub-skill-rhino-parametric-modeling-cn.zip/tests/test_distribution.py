"""Distribution checks: no live Rhino or model is changed. Python 3.10+ stdlib."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SHELL = shutil.which('pwsh') or shutil.which('powershell')


class DistributionTests(unittest.TestCase):
    def test_vendor_hashes_and_contents(self):
        vendor = ROOT / 'vendor' / 'official'
        manifest = json.loads((vendor / 'assets.json').read_text(encoding='utf-8'))
        self.assertEqual(len(manifest['assets']), 2)
        supplied = os.environ.get('RHINO_SKILL_TEST_ASSET_DIR')
        if supplied:
            vendor = Path(supplied)
        elif not all((vendor / item['file']).is_file() for item in manifest['assets']):
            self.skipTest('Official installers download on first use; set RHINO_SKILL_TEST_ASSET_DIR to a verified cache containing both versions')
        for item in manifest['assets']:
            asset = vendor / item['file']
            self.assertEqual(asset.stat().st_size, item['bytes'])
            self.assertEqual(hashlib.sha256(asset.read_bytes()).hexdigest(), item['sha256'])
            with zipfile.ZipFile(asset) as archive:
                self.assertIsNone(archive.testzip())
                self.assertIn('router/win-x64/rhino-mcp-router.exe', archive.namelist())
                self.assertIn('manifest.yml', archive.namelist())
                self.assertIn('version: 0.1.5', archive.read('manifest.yml').decode())

    def test_main_skill_and_local_links(self):
        skill = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(skill.startswith('---\nname: rhino-parametric-modeling-cn\n'))
        for path in ROOT.rglob('*.md'):
            text = path.read_text(encoding='utf-8')
            for link in re.findall(r'\]\(([^)]+)\)', text):
                target = link.split('#')[0]
                if not target or '://' in target or target.startswith('mailto:'):
                    continue
                self.assertTrue((path.parent / target).is_file(), '%s -> %s' % (path.relative_to(ROOT), target))

    @unittest.skipUnless(SHELL and os.name == 'nt', 'Windows PowerShell configuration helper')
    def test_configuration_argv_unicode_and_no_overwrite(self):
        with tempfile.TemporaryDirectory(prefix='rhino-cn-') as temporary:
            folder = Path(temporary) / '中文 paths $literal'
            router = folder / 'packages' / '8.0' / 'Rhino-MCP-Platform' / '0.1.5' / 'router' / 'win-x64' / 'rhino-mcp-router.exe'
            router.parent.mkdir(parents=True)
            router.write_bytes(b'not executed: only path discovery')
            config = folder / 'mcp.json'
            command = [SHELL, '-NoProfile', '-File', str(ROOT / 'scripts' / 'configure-mcp.ps1'),
                       '-PackagesRoot', str(folder / 'packages'), '-OutFile', str(config)]
            result = subprocess.run(command, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads(config.read_text(encoding='utf-8'))
            entry = data['mcpServers']['rhino-cn']
            self.assertEqual(entry['command'], str(router))
            self.assertEqual(entry['args'], ['--default-version', '8'])
            before = config.read_bytes()
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)
            self.assertEqual(config.read_bytes(), before)

    @unittest.skipUnless(SHELL and os.name == 'nt', 'Windows PowerShell configuration helper')
    def test_multiple_routers_require_explicit_path(self):
        with tempfile.TemporaryDirectory(prefix='rhino-cn-') as temporary:
            folder = Path(temporary)
            for version in ('0.1.5', '0.2.1-wip'):
                router = folder / '8.0' / 'Rhino-MCP-Platform' / version / 'router' / 'win-x64' / 'rhino-mcp-router.exe'
                router.parent.mkdir(parents=True)
                router.write_bytes(b'not executed')
            command = [SHELL, '-NoProfile', '-File', str(ROOT / 'scripts' / 'configure-mcp.ps1'), '-PackagesRoot', str(folder)]
            self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)

    @unittest.skipUnless(SHELL and os.name == 'nt', 'Windows PowerShell configuration helper')
    def test_adapter_config_uses_python_and_separate_arguments(self):
        import sys
        with tempfile.TemporaryDirectory(prefix='rhino-cn-') as temporary:
            config = Path(temporary) / 'adapter.json'
            command = [SHELL, '-NoProfile', '-File', str(ROOT / 'scripts' / 'configure-mcp.ps1'),
                       '-Mode', 'adapter', '-PythonPath', sys.executable, '-RhinoPid', '12345', '-OutFile', str(config)]
            result = subprocess.run(command, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            entry = json.loads(config.read_text(encoding='utf-8'))['mcpServers']['rhino-cn']
            self.assertEqual(entry['command'], sys.executable)
            self.assertEqual(entry['args'][1:], ['stdio', '--pid', '12345'])
            self.assertTrue(Path(entry['args'][0]).is_file())

    @unittest.skipUnless(SHELL and os.name == 'nt', 'Windows PowerShell helper')
    def test_missing_rhino_does_not_install(self):
        with tempfile.TemporaryDirectory(prefix='rhino-cn-') as temporary:
            command = [SHELL, '-NoProfile', '-File', str(ROOT / 'scripts' / 'install-offline.ps1'),
                       '-RhinoSystem', temporary, '-WhatIf']
            result = subprocess.run(command, capture_output=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(list(Path(temporary).iterdir()), [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
