"""Adversarial workflow regressions. Capture uses API stubs, not live Rhino."""
import json
import math
import os
from pathlib import Path
import random
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts/rhino/tests'))
sys.path.insert(0, str(ROOT / 'scripts/parametric'))
import test_runtime_templates as rt
from test_runtime_templates import Record
import _common
import capture_views
import inspect_document
import parametric_contract as pc


class CaptureQualityTests(unittest.TestCase):
    def setUp(self):
        self.fixture = rt.RuntimeTests()
        self.fixture.setUp()
        self.folder = Path(self.fixture.tmp)
        self.calls = []
        def save(path, fmt):
            self.calls.append(path)
            Path(path).write_bytes(b'API STUB OUTPUT: NOT A REAL PNG')
        self.fixture.doc.Views.ActiveView.CaptureToBitmap = lambda size: Record(Save=save, Dispose=lambda: None)
        self.config = {'expected_document_path':self.fixture.doc.Path, 'output_root':str(self.folder),
                       'isolate_ids':['normal'],
                       'views':[{'name':'front', 'camera':[0,-5,2], 'target':[0,0,2]}]}

    def tearDown(self):
        self.fixture.tearDown()

    def rejected_before_change(self):
        with self.assertRaises((ValueError, KeyError)):
            capture_views.main(self.config, self.fixture.doc)
        self.assertEqual(self.calls, [])
        self.assertEqual(self.fixture.objects.operations, [])
        self.assertEqual(self.fixture.vp.projection, 'original-projection')

    def test_report_cannot_overwrite_model_named_fixture(self):
        path = self.folder / 'source.3dm'
        path.write_bytes(b'NOT A MODEL: protected bytes')
        self.config['report_path'] = str(path)
        self.rejected_before_change()
        self.assertEqual(path.read_bytes(), b'NOT A MODEL: protected bytes')

    def test_report_cannot_overwrite_existing_json(self):
        path = self.folder / 'previous.json'
        path.write_bytes(b'previous evidence')
        self.config['report_path'] = str(path)
        self.rejected_before_change()
        self.assertEqual(path.read_bytes(), b'previous evidence')

    @unittest.skipUnless(os.name == 'nt', 'Windows case-insensitive file aliases')
    def test_case_variant_capture_names_are_the_same_output(self):
        self.config['views'].append(dict(self.config['views'][0], name='FRONT'))
        self.rejected_before_change()

    def test_invalid_later_spec_leaves_no_partial_captures(self):
        self.config['views'].append(dict(self.config['views'][0], name='invalid', projection='orthogonal-typo'))
        self.rejected_before_change()

    def test_degenerate_camera_axes_rejected(self):
        for values in [dict(camera=[0,0,2]), dict(camera=[0,0,5]), dict(up=[0,0,0])]:
            with self.subTest(values=values):
                self.config['views'] = [dict(name='front', camera=[0,-5,2], target=[0,0,2])]
                self.config['views'][0].update(values)
                self.rejected_before_change()

    def test_nonfinite_or_reversed_inputs_rejected(self):
        for values in [dict(camera=[0,float('nan'),2]), dict(up=[0,0,float('inf')]),
                       dict(projection='perspective',lens_mm=float('nan')),
                       dict(bounds=[[1,0,0],[0,1,1]])]:
            with self.subTest(values=values):
                self.config['views']=[dict(name='front',camera=[0,-5,2],target=[0,0,2])]
                self.config['views'][0].update(values)
                self.rejected_before_change()

    def test_projection_failure_is_not_success(self):
        self.fixture.vp.ChangeToParallelProjection = lambda symmetric: False
        with self.assertRaises(RuntimeError):
            capture_views.main(self.config,self.fixture.doc)
        self.assertEqual(self.calls,[])
        self.assertEqual(self.fixture.vp.projection,'original-projection')
        self.assertEqual([(o.Id,o.IsHidden) for o in self.fixture.objects.items],
                         [('normal',False),('hidden',True),('locked',False),('deleted',False)])

    def test_valid_capture_preserves_spec_and_writes_new_report(self):
        path = self.folder / 'capture.json'
        self.config['report_path'] = str(path)
        result = capture_views.main(self.config,self.fixture.doc)
        self.assertEqual(result['status'],'captured_and_restored')
        self.assertEqual(len(self.calls),1)
        self.assertEqual(json.loads(path.read_text())['requested_views'], self.config['views'])
        self.assertEqual(self.fixture.vp.projection,'original-projection')

    def test_inspection_refuses_existing_evidence_file(self):
        path=self.folder/'inspect.json'
        path.write_bytes(b'previous inspection')
        with self.assertRaises(ValueError):
            inspect_document.main({'report_path':str(path)}, self.fixture.doc)
        self.assertEqual(path.read_bytes(),b'previous inspection')

    def test_exclusive_report_creation_rejects_late_collision(self):
        path=self.folder/'race.json'
        path.write_bytes(b'other writer')
        with self.assertRaises(OSError):
            _common.write_json(str(path),{'new':'evidence'},overwrite=False)
        self.assertEqual(path.read_bytes(),b'other writer')

    def test_example_generation_tag_is_visible_to_default_inspection(self):
        key=pc.example_parameters()['provenance']['generation_tag_key']
        self.fixture.objects.items[0].Attributes.tags[key]='test-r01'
        report=inspect_document.main({'target_ids':['normal']},self.fixture.doc)
        self.assertEqual(report['objects'][0]['generation_tag'],'test-r01')


class ParameterQualityTests(unittest.TestCase):
    def test_one_hundred_varied_panels_meet_measured_clearances(self):
        rng=random.Random(541)
        for index in range(100):
            nx,ny=rng.randint(1,12),rng.randint(1,10)
            pitch_x,pitch_y=rng.randint(18,40),rng.randint(18,40)
            diameter=rng.randint(2,7)
            jitter=rng.choice([0,.05,.1])
            edge=8
            width=2*(edge+diameter/2+jitter*pitch_x)+(nx-1)*pitch_x+.2*pitch_x
            height=2*(edge+diameter/2+jitter*pitch_y)+(ny-1)*pitch_y+.2*pitch_y
            cfg=pc.example_parameters()
            cfg['seed']=index
            cfg['parameters'].update(panel_width=width,panel_height=height,plate_thickness=1,
                edge_margin=edge,hole_diameter=diameter,pitch_x=pitch_x,pitch_y=pitch_y,
                minimum_web=3,jitter_fraction=jitter)
            report=pc.build_recipe(cfg)
            holes=report['recipe']['features']
            self.assertEqual(len(holes),nx*ny)
            for i,a in enumerate(holes):
                x,y=a['center_xy_m']; radius=a['radius_m']
                self.assertGreaterEqual(min(x-radius,y-radius,width/1000-x-radius,height/1000-y-radius),.008-1e-12)
                for b in holes[i+1:]:
                    bx,by=b['center_xy_m']
                    gap=math.hypot(x-bx,y-by)-radius-b['radius_m']
                    self.assertGreaterEqual(gap,.003-1e-12)

    def test_one_hundred_rib_variants_fit_real_extent_and_gap(self):
        rng=random.Random(774)
        for index in range(100):
            count,thickness,gap=rng.randint(1,40),rng.randint(2,15),rng.randint(0,40)
            edge=20
            span=2*edge+count*thickness+max(0,count-1)*gap
            cfg=pc.example_parameters('rib_array')
            cfg['seed']=index
            cfg['parameters'].update(span=span,count=count,rib_thickness=thickness,
                minimum_clear_gap=gap,edge_margin=edge,height_variation_fraction=.7)
            ribs=pc.build_recipe(cfg)['recipe']['features']
            self.assertEqual(len(ribs),count)
            self.assertGreaterEqual(ribs[0]['min_m'][0],edge/1000-1e-12)
            self.assertLessEqual(ribs[-1]['max_m'][0],(span-edge)/1000+1e-12)
            for a,b in zip(ribs,ribs[1:]):
                self.assertGreaterEqual(b['min_m'][0]-a['max_m'][0],gap/1000-1e-12)
            self.assertTrue(all(a['max_m'][2]>a['min_m'][2] for a in ribs))


if __name__ == '__main__':
    unittest.main(verbosity=2)
