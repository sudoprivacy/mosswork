"""Run the bundled offline checks in isolated Python processes, not Rhino.

python tests/run_checks.py --out NEW_REPORT.json
Requires Python 3.10+. Windows-specific checks may be skipped elsewhere.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SUITES = [
    ('rhino7_compatibility', ['-m','unittest','discover','-s','tests','-p','test_rhino7.py','-q']),
    ('adapter', ['-m','unittest','discover','-s','adapter','-p','test_adapter.py','-q']),
    ('first_run_setup', ['-m','unittest','discover','-s','tests','-p','test_first_run_setup.py','-q']),
    ('first_run_regressions', ['-m','unittest','discover','-s','adapter','-p','test_first_run_regressions.py','-q']),
    ('runtime_stubs', ['scripts/rhino/tests/test_runtime_templates.py','-q']),
    ('parameter_contract', ['scripts/parametric/test_parametric_contract.py','-q']),
    ('quality_regressions', ['tests/test_quality_regressions.py','-q']),
    ('transport_faults', ['-m','unittest','discover','-s','tests','-p','test_transport_faults.py','-q']),
    ('distribution', ['-m','unittest','discover','-s','tests','-p','test_distribution.py','-q']),
    ('setup', ['-m','unittest','discover','-s','tests','-p','test_setup_rhino.py','-q']),
]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',help='Optional new UTF-8 JSON report; never overwrite an existing file')
    args=parser.parse_args()
    path=Path(args.out).resolve() if args.out else None
    if path and (path.exists() or not path.parent.is_dir()):
        parser.error('Report must be a new file in an existing directory')
    results=[]
    for name,arguments in SUITES:
        try:
            run=subprocess.run([sys.executable,'-B','-X','utf8']+arguments,cwd=ROOT,
                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf-8',errors='replace',timeout=180)
            log=run.stdout
            count=re.search(r'Ran (\d+) tests? in ',log)
            skips=re.search(r'skipped=(\d+)',log)
            results.append({'suite':name,'exit_code':run.returncode,
                'tests':int(count.group(1)) if count else None,
                'skips':int(skips.group(1)) if skips else 0,'log':log})
        except subprocess.TimeoutExpired:
            results.append({'suite':name,'exit_code':None,'tests':None,'skips':None,
                            'log':'Suite exceeded 180 seconds; not counted as passed'})
        print(name+': '+('passed with skips' if results[-1]['exit_code']==0 and results[-1]['skips'] else 'passed' if results[-1]['exit_code']==0 else 'FAILED'),flush=True)
    success=all(r['exit_code']==0 and r['tests'] is not None for r in results)
    fully_validated=success and all(r['skips']==0 for r in results)
    report={'scope':'offline script tests and local API mocks; no real Rhino/model/agent-host integration',
        'python':sys.version.split()[0],'platform':sys.platform,
        'all_suites_passed':fully_validated, 'no_test_failures':success, 'fully_validated':fully_validated,
        'passed':sum((r['tests'] or 0)-(r['skips'] or 0) for r in results) if success else None,
        'tests':sum(r['tests'] or 0 for r in results),
        'skips':sum(r['skips'] or 0 for r in results),'suites':results,
        'live_rhino_tested':False,'domestic_model_invoked':False}
    encoded=json.dumps(report,ensure_ascii=True,indent=2)
    if path:
        fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_BINARY',0),0o666)
        with os.fdopen(fd,'wb') as stream:
            stream.write(encoded.encode('utf-8'))
    print(encoded)
    return 0 if success else 1


if __name__=='__main__':
    sys.exit(main())
