import json,os,subprocess,tempfile,unittest
from pathlib import Path
import test_setup_rhino as fixtures
import contextlib,io,sys
from unittest.mock import patch
import run_checks

ROOT=Path(__file__).resolve().parents[1]

class TestSummary(unittest.TestCase):
    def test_skips_are_not_reported_as_full_pass(self):
        completed=subprocess.CompletedProcess([],0,stdout='Ran 3 tests in 0.1s\nOK (skipped=3)\n')
        out=io.StringIO()
        with patch.object(run_checks,'SUITES',[('skip-fixture',[])]),patch.object(run_checks.subprocess,'run',return_value=completed),patch.object(sys,'argv',['run_checks.py']),contextlib.redirect_stdout(out):
            self.assertEqual(run_checks.main(),0)
        report=json.loads(out.getvalue().split('\n',1)[1])
        self.assertFalse(report['all_suites_passed'])
        self.assertFalse(report['fully_validated'])
        self.assertEqual(report['passed'],0)
        self.assertEqual(report['skips'],3)

@unittest.skipUnless(os.name=='nt' and fixtures.SHELLS and fixtures.CSC.is_file(),'Windows fixtures required')
class FirstRunSetup(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixtures.SetupRhinoTests.setUpClass()
        cls.base=fixtures.SetupRhinoTests.fixture_root
        cls.rhino7=cls.base/'mock7';cls.rhino7.mkdir()
        source=cls.rhino7/'Rhino.cs'
        source.write_text('[assembly:System.Reflection.AssemblyFileVersion("7.0.0.0")] class R {static void Main(){}}')
        fixtures.SetupRhinoTests.compile(source,cls.rhino7/'Rhino.exe')
    @classmethod
    def tearDownClass(cls):fixtures.SetupRhinoTests.tearDownClass()
    def test_unified_whatif_writes_no_configuration(self):
        for shell in fixtures.SHELLS:
            with tempfile.TemporaryDirectory() as folder:
                output=Path(folder)/'must-not-exist.json'
                proc=subprocess.run([shell,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'scripts/initialize-rhino.ps1'),'-RhinoVersion','7','-RhinoSystem',str(self.rhino7),'-WhatIf','-ConfigOutFile',str(output)],capture_output=True,encoding='utf-8',errors='replace',timeout=15)
                self.assertEqual(proc.returncode,0,proc.stderr)
                report=json.loads(proc.stdout)
                self.assertFalse(report['connection_verified'])
                self.assertFalse(report['modeling_verified'])
                self.assertFalse(output.exists())
    def test_router_pid_rejected_before_path_lookup(self):
        for shell in fixtures.SHELLS:
            proc=subprocess.run([shell,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'scripts/configure-mcp.ps1'),'-RhinoVersion','9','-RhinoPid','12345'],capture_output=True,encoding='utf-8',errors='replace',timeout=15)
            self.assertNotEqual(proc.returncode,0)
            self.assertIn('not supported in router mode',proc.stderr)
    def test_registry_install_path_resolved(self):
        for shell in fixtures.SHELLS:
            quote=fixtures.quote
            script='. '+quote(ROOT/'scripts/setup-common.ps1')+'; function Get-ItemProperty { param($LiteralPath,$ErrorAction) [pscustomobject]@{Path='+quote(self.rhino7)+'} }; Resolve-RhinoSystem -RhinoVersion 7'
            proc=subprocess.run([shell,'-NoProfile','-ExecutionPolicy','Bypass','-Command',script],capture_output=True,encoding='utf-8',errors='replace',timeout=15)
            self.assertEqual(proc.returncode,0,proc.stderr)
            self.assertEqual(Path(proc.stdout.strip()),self.rhino7)

if __name__=='__main__':unittest.main()
