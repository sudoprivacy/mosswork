"""Isolated Windows setup checks; no real Rhino, network, or user config is used.

Creates versioned mock executables and a fixture-pinned package under TEMP.
Real official downloads are a separate release check, never a test dependency.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SHELLS = list(dict.fromkeys(filter(None, (shutil.which('powershell'), shutil.which('pwsh')))))
CSC = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'


def quote(value):
    return "'" + str(value).replace("'", "''") + "'"


@unittest.skipUnless(os.name == 'nt' and SHELLS and CSC.is_file(), 'Windows PowerShell and .NET compiler required')
class SetupRhinoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='rhino-setup-tests-')
        cls.fixture_root = Path(cls.temp.name)
        cls.rhino_versions = {}
        for label, version in [('8', '8.29.0.0'), ('9', '9.0.0.0'), ('old8', '8.28.0.0')]:
            folder = cls.fixture_root / ('mock Rhino ' + label)
            folder.mkdir()
            source = folder / 'Rhino.cs'
            source.write_text('[assembly:System.Reflection.AssemblyFileVersion("' + version + '")]\n'
                              'class RhinoMock { static void Main() {} }', encoding='utf-8')
            cls.compile(source, folder / 'Rhino.exe')
            cls.rhino_versions[label] = folder
        source = cls.fixture_root / 'Yak.cs'
        source.write_text('''using System;
using System.IO;
class YakMock {
  static int Main(string[] args) {
    File.AppendAllText(Environment.GetEnvironmentVariable("MOCK_YAK_LOG"), String.Join("|", args) + "\\n");
    return Int32.Parse(Environment.GetEnvironmentVariable("MOCK_YAK_EXIT") ?? "0");
  }
}''', encoding='utf-8')
        cls.compile(source, cls.fixture_root / 'Yak.exe')
        for folder in cls.rhino_versions.values():
            shutil.copy2(cls.fixture_root / 'Yak.exe', folder / 'Yak.exe')

    @classmethod
    def compile(cls, source, destination):
        result = subprocess.run([str(CSC), '/nologo', '/target:exe', '/out:' + str(destination), str(source)], capture_output=True)
        if result.returncode:
            raise RuntimeError(result.stdout.decode(errors='replace') + result.stderr.decode(errors='replace'))

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.case = tempfile.TemporaryDirectory(prefix='case-', dir=self.fixture_root)
        self.addCleanup(self.case.cleanup)
        self.folder = Path(self.case.name) / '中文 paths $literal'
        self.bundle = self.folder / 'bundle'
        (self.bundle / 'scripts').mkdir(parents=True)
        (self.bundle / 'vendor/official').mkdir(parents=True)
        for name in ('setup-rhino.ps1', 'install-offline.ps1', 'setup-common.ps1'):
            shutil.copy2(ROOT / 'scripts' / name, self.bundle / 'scripts' / name)
        self.manifest = json.loads((ROOT / 'vendor/official/assets.json').read_text(encoding='utf-8-sig'))
        self.payload = b'isolated package fixture; never downloaded or executed\n'
        for entry in self.manifest['assets']:
            entry['bytes'] = len(self.payload)
            entry['sha256'] = hashlib.sha256(self.payload).hexdigest()
        self.write_manifest()
        self.cache = self.folder / 'package cache'
        self.yak_log = self.folder / 'yak called.txt'
        self.environment = dict(os.environ, APPDATA=str(self.folder / 'appdata'),
                                LOCALAPPDATA=str(self.folder / 'localappdata'),
                                MOCK_YAK_LOG=str(self.yak_log), MOCK_YAK_EXIT='0')

    def write_manifest(self):
        (self.bundle / 'vendor/official/assets.json').write_text(json.dumps(self.manifest), encoding='utf-8')

    def cached_asset(self, version='8'):
        self.cache.mkdir(parents=True, exist_ok=True)
        entry = next(e for e in self.manifest['assets'] if '-rh' + version + '_' in e['file'])
        destination = self.cache / entry['file']
        destination.write_bytes(self.payload)
        return destination

    def run_setup(self, shell, version='8', rhino=None, flags=(), success=True):
        command = '[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false); $ErrorActionPreference = "Stop"; '
        command += '$result = & ' + quote(self.bundle / 'scripts/setup-rhino.ps1')
        command += ' -RhinoVersion ' + quote(version)
        command += ' -RhinoSystem ' + quote(self.rhino_versions[rhino or version])
        command += ' -CacheDirectory ' + quote(self.cache)
        command += ' ' + ' '.join(flags) + '; $result | ConvertTo-Json -Depth 6 -Compress'
        encoded = base64.b64encode(command.encode('utf-16-le')).decode('ascii')
        result = subprocess.run([shell, '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                                capture_output=True, env=self.environment, timeout=30)
        output = result.stdout.decode('utf-8-sig', errors='replace')
        error = result.stderr.decode('utf-8', errors='replace')
        if success:
            self.assertEqual(result.returncode, 0, output + error)
            lines = [line for line in output.splitlines() if line.startswith('{')]
            self.assertEqual(len(lines), 1, output + error)
            return json.loads(lines[0])
        self.assertNotEqual(result.returncode, 0, output + error)
        return output + error

    def test_whatif_both_versions_writes_nothing(self):
        for shell in SHELLS:
            for version in ('8', '9'):
                with self.subTest(shell=shell, version=version):
                    result = self.run_setup(shell, version, flags=('-WhatIf',))
                    self.assertEqual(result['Status'], 'WhatIf')
                    self.assertIn('https://files.mcneel.com/yak/packages/', result['DownloadUrl'])
                    self.assertFalse(self.cache.exists())
                    self.assertFalse(self.yak_log.exists())

    def test_prepareonly_reuses_verified_cache_both_versions(self):
        for version in ('8', '9'):
            path = self.cached_asset(version)
            before = path.stat().st_mtime_ns
            for shell in SHELLS:
                with self.subTest(shell=shell, version=version):
                    result = self.run_setup(shell, version, flags=('-PrepareOnly',))
                    self.assertEqual(result['Status'], 'Prepared')
                    self.assertTrue(result['CacheReused'])
                    self.assertEqual(result['Sha256'], hashlib.sha256(self.payload).hexdigest())
                    self.assertEqual(path.stat().st_mtime_ns, before)
                    self.assertFalse(self.yak_log.exists())
            self.assertEqual(path.read_bytes(), self.payload)
        self.assertFalse(list(self.cache.glob('*.part')))

    def test_corrupt_cache_refused_even_with_whatif(self):
        path = self.cached_asset()
        damaged = b'X' + self.payload[1:]
        path.write_bytes(damaged)
        for shell in SHELLS:
            for flags in (('-PrepareOnly',), ('-WhatIf',)):
                with self.subTest(shell=shell, flags=flags):
                    error = self.run_setup(shell, flags=flags, success=False)
                    self.assertIn('SHA256 mismatch', error)
                    self.assertEqual(path.read_bytes(), damaged)
                    self.assertFalse(self.yak_log.exists())

    def test_version_mismatch_and_old_rhino_refused(self):
        for shell in SHELLS:
            for version, rhino in (('9', '8'), ('8', '9'), ('8', 'old8')):
                with self.subTest(shell=shell, version=version, rhino=rhino):
                    self.run_setup(shell, version, rhino, flags=('-WhatIf',), success=False)
                    self.assertFalse(self.cache.exists())
                    self.assertFalse(self.yak_log.exists())

    def test_existing_installation_returns_without_cache_or_download(self):
        for version in ('8', '9'):
            installed = Path(self.environment['APPDATA']) / ('McNeel/Rhinoceros/packages/' + version + '.0/Rhino-MCP-Platform/0.9.0')
            installed.mkdir(parents=True)
            (installed / 'net8.0').mkdir()
            (installed / 'router/win-x64').mkdir(parents=True)
            (installed / 'router/win-arm64').mkdir(parents=True)
            for required in ('net8.0/RhinoMcpPlatform.rhp','router/win-x64/rhino-mcp-router.exe','router/win-arm64/rhino-mcp-router.exe','manifest.yml'):
                (installed / required).write_text('mock complete installation', encoding='utf-8')
            marker = installed / 'preserve.txt'
            marker.write_text('existing installation', encoding='utf-8')
            for shell in SHELLS:
                with self.subTest(shell=shell, version=version):
                    result = self.run_setup(shell, version)
                    self.assertEqual(result['Status'], 'ExistingInstallation')
                    self.assertIn('MCPConnect', result['Notes'])
                    self.assertFalse(self.cache.exists())
                    self.assertFalse(self.yak_log.exists())
                    self.assertEqual(marker.read_text(), 'existing installation')

    def test_incomplete_installation_reports_error_without_download(self):
        installed = Path(self.environment['APPDATA']) / 'McNeel/Rhinoceros/packages/8.0/Rhino-MCP-Platform/0.9.0'
        installed.mkdir(parents=True)
        for shell in SHELLS:
            error = self.run_setup(shell, success=False)
            self.assertIn('Incomplete Rhino-MCP-Platform', error)
            self.assertFalse(self.cache.exists())
            self.assertFalse(self.yak_log.exists())
            self.assertTrue(installed.exists())

    def test_root_only_residue_is_not_treated_as_missing(self):
        root = Path(self.environment['APPDATA']) / 'McNeel/Rhinoceros/packages/8.0/Rhino-MCP-Platform'
        root.mkdir(parents=True)
        marker = root / 'partial-install.tmp'
        marker.write_text('preserve residue', encoding='utf-8')
        for shell in SHELLS:
            error = self.run_setup(shell, success=False)
            self.assertIn('Incomplete Rhino-MCP-Platform', error)
            self.assertFalse(self.cache.exists())
            self.assertFalse(self.yak_log.exists())
            self.assertEqual(marker.read_text(), 'preserve residue')

    def test_unapproved_download_url_rejected_without_network(self):
        self.manifest['assets'][0]['download_url'] = 'https://example.com/arbitrary.yak'
        self.write_manifest()
        for shell in SHELLS:
            with self.subTest(shell=shell):
                self.run_setup(shell, flags=('-WhatIf',), success=False)
                self.assertFalse(self.cache.exists())

    def test_install_uses_local_yak_once_with_literal_path(self):
        asset = self.cached_asset()
        for shell in SHELLS:
            with self.subTest(shell=shell):
                if self.yak_log.exists():
                    self.yak_log.unlink()
                result = self.run_setup(shell)
                self.assertEqual(result['Status'], 'Installed')
                self.assertTrue(result['RequiresRhinoRestart'])
                self.assertEqual(self.yak_log.read_text(encoding='utf-8').splitlines(), ['install|' + str(asset)])

    def test_unknown_yak_failure_is_not_retried(self):
        self.cached_asset()
        self.environment['MOCK_YAK_EXIT'] = '7'
        for shell in SHELLS:
            with self.subTest(shell=shell):
                if self.yak_log.exists():
                    self.yak_log.unlink()
                self.run_setup(shell, success=False)
                self.assertEqual(len(self.yak_log.read_text(encoding='utf-8').splitlines()), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
