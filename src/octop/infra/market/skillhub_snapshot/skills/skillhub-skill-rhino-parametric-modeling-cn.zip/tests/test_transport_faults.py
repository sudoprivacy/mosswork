"""Regressions from an isolated Windows MCP host fault-injection run.

No real Rhino, model endpoint, installed configuration, or external network.
The server records a simulated write before intentionally damaging its response.
"""
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

BUNDLE = Path(__file__).resolve().parents[1]
ADAPTER = BUNDLE / "adapter" / "rhino_stdio_adapter.py"
TOOLS = [{"name": name, "description": name,
          "inputSchema": {"type": "object", "properties": {}}}
         for name in ("run_python", "get_context", "get_viewport_image")]


def child_environment():
    env = os.environ.copy()
    for key in list(env):
        if "proxy" in key.lower() or key.lower() == "psmodulepath":
            env.pop(key)
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    return env


class FaultServer:
    def __init__(self, fault):
        self.fault, self.requests, self.writes = fault, [], []
        owner = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args):
                pass

            def do_POST(self):
                request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                owner.requests.append(request)
                method = request["method"]
                if method == "initialize":
                    result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}},
                              "serverInfo": {"name": "rhino-mcp", "version": "0.1.5"}}
                elif method == "tools/list":
                    if owner.fault == "bad-list":
                        result = None
                        owner.fault = "normal"
                    elif owner.fault == "pagination":
                        result = {"tools": TOOLS[2:]} if request.get("params", {}).get("cursor") else {"tools": TOOLS[:2], "nextCursor": "second"}
                    else:
                        result = {"tools": TOOLS}
                elif method == "tools/call":
                    owner.writes.append(request)
                    result = {"content": [{"type": "text", "text": "mock tool executed"}]}
                    if owner.fault == "truncated":
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json")
                        self.send_header("Transfer-Encoding", "chunked")
                        self.end_headers()
                        self.wfile.write(b'100\r\n{"jsonrpc":"2.0","id":')
                        self.wfile.flush()
                        self.close_connection = True
                        self.connection.shutdown(socket.SHUT_RDWR)
                        self.connection.close()
                        return
                else:
                    result = {}
                response = {"jsonrpc": "2.0", "id": request["id"], "result": result}
                if method == "tools/call" and owner.fault == "wrong-id":
                    response["id"] = "unmatched"
                raw = b"{bad}" if method == "tools/call" and owner.fault == "bad-json" else json.dumps(response).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = "http://127.0.0.1:%d/" % self.server.server_port

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()


def request(request_id, method, params=None):
    result = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        result["params"] = params
    return result


class TransportFaultTests(unittest.TestCase):
    def host(self, server, messages):
        with tempfile.TemporaryDirectory(prefix="国产 宿主 ", dir=os.environ.get("RHINO_TEST_ROOT")) as cwd:
            stream = "\n".join(m if isinstance(m, str) else json.dumps(m, ensure_ascii=False) for m in messages) + "\n"
            process = subprocess.run([sys.executable, "-B", str(ADAPTER), "stdio", "--url", server.url],
                                     input=stream, text=True, encoding="utf-8", capture_output=True,
                                     cwd=cwd, env=child_environment(), timeout=10)
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertNotIn("Traceback", process.stderr)
        return [json.loads(line) for line in process.stdout.splitlines()]

    def fault_recovery(self, fault):
        with FaultServer(fault) as server:
            responses = self.host(server, [request(1, "initialize"), request(2, "tools/list"),
                request(3, "tools/call", {"name": "run_python", "arguments": {"script": "print('中文 🦏')"}}),
                request(4, "ping")])
            self.assertEqual([r["id"] for r in responses], [1, 2, 3, 4])
            self.assertEqual(responses[2]["error"]["data"], {"executionState": "unknown", "automaticRetry": False})
            self.assertIn("result", responses[3])
            self.assertEqual(len(server.writes), 1, "Never replay an uncertain write")

    def test_truncated_chunked_response_keeps_unknown_and_recovers(self):
        self.fault_recovery("truncated")

    def test_invalid_json_response_keeps_unknown_and_recovers(self):
        self.fault_recovery("bad-json")

    def test_mismatched_response_id_keeps_unknown_and_recovers(self):
        self.fault_recovery("wrong-id")

    def test_nonfinite_input_rejected_without_http_write_and_recovers(self):
        for number in ("1e400", "NaN", "Infinity", "-Infinity"):
            with self.subTest(number=number), FaultServer("normal") as server:
                bad = '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"get_context","arguments":{"scale":%s}}}' % number
                responses = self.host(server, [request(1, "initialize"), bad, request(3, "ping")])
                self.assertEqual(responses[1]["error"]["code"], -32700)
                self.assertIn("result", responses[2])
                self.assertEqual(server.writes, [])

    def test_null_tool_listing_isolated_and_next_listing_recovers(self):
        with FaultServer("bad-list") as server:
            responses = self.host(server, [request(1, "initialize"), request(2, "tools/list"), request(3, "tools/list")])
            self.assertIn("error", responses[1])
            self.assertEqual([t["name"] for t in responses[2]["result"]["tools"]], [t["name"] for t in TOOLS])

    def test_pagination_keeps_earlier_tools_callable(self):
        with FaultServer("pagination") as server:
            responses = self.host(server, [request(1, "initialize"), request(2, "tools/list"),
                request(3, "tools/list", {"cursor": "second"}),
                request(4, "tools/call", {"name": "get_context", "arguments": {}})])
            self.assertEqual(responses[1]["result"]["nextCursor"], "second")
            self.assertIn("result", responses[3])
            self.assertEqual(len(server.writes), 1)

    def test_call_discovers_pending_page_before_rejecting_name(self):
        with FaultServer("pagination") as server:
            responses = self.host(server, [request(1, "initialize"), request(2, "tools/list"),
                request(3, "tools/call", {"name": "get_viewport_image", "arguments": {}})])
            self.assertIn("result", responses[2])
            self.assertEqual(len(server.writes), 1)
            self.assertEqual([r.get("params", {}).get("cursor") for r in server.requests if r["method"] == "tools/list"], [None, "second"])


@unittest.skipUnless(os.name == "nt", "PowerShell path semantics are Windows-specific")
class PowerShellLocationTests(unittest.TestCase):
    def run_shell(self, shell_name, action, versioned_rhino=False, direct_whatif=False):
        shell = shutil.which(shell_name)
        if not shell:
            self.skipTest(shell_name + " is unavailable")
        with tempfile.TemporaryDirectory(prefix="接入 中文 ", dir=os.environ.get("RHINO_TEST_ROOT")) as folder:
            root = Path(folder)
            launch, project = root / "启动 目录", root / "宿主 项目"
            launch.mkdir(); project.mkdir()
            if versioned_rhino:
                compiler_shell = shutil.which("powershell.exe")
                if not compiler_shell:
                    self.skipTest("Windows PowerShell compiler unavailable")
                system = project / "模拟 Rhino" / "System"
                system.mkdir(parents=True)
                compiler = root / "compile-fake.ps1"
                compiler.write_text("param([string]$Output)\n$ErrorActionPreference='Stop'\n$code = @'\n"
                    "using System;\nusing System.Reflection;\n"
                    "[assembly: AssemblyVersion(\"8.29.0.0\")]\n[assembly: AssemblyFileVersion(\"8.29.0.0\")]\n"
                    "public static class FakeRhino { public static int Main(string[] args) { return 0; } }\n"
                    "'@\nAdd-Type -TypeDefinition $code -OutputAssembly $Output -OutputType ConsoleApplication\n", encoding="utf-8-sig")
                compiled = subprocess.run([compiler_shell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(compiler), "-Output", str(system / "Rhino.exe")],
                    env=child_environment(), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20)
                self.assertEqual(compiled.returncode, 0, compiled.stderr)
                (system / "Yak.exe").write_bytes(b"not executable: WhatIf must never invoke this")
            (project / "python 中文.exe").write_bytes(b"inert path test")
            (project / "router 中文.exe").write_bytes(b"inert path test")
            wrapper = root / "location.ps1"
            wrapper.write_text("param([string]$Project,[string]$Bundle)\n$ErrorActionPreference='Stop'\nSet-Location -LiteralPath $Project\n" + action, encoding="utf-8-sig")
            env = child_environment()
            env["APPDATA"] = str(root / "isolated appdata")
            argv = [shell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"]
            if direct_whatif:
                argv += [str(BUNDLE / "scripts" / "install-offline.ps1"), "-RhinoSystem", str(system), "-WhatIf"]
                if os.environ.get('RHINO_SKILL_TEST_ASSET_DIR'):
                    argv += ['-AssetDirectory', os.environ['RHINO_SKILL_TEST_ASSET_DIR']]
            else:
                argv += [str(wrapper), "-Project", str(project), "-Bundle", str(BUNDLE)]
            proc = subprocess.run(argv, cwd=launch, env=env,
                                  capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20)
            self.assertEqual(proc.returncode, 0, proc.stderr)
            if direct_whatif:
                self.assertRegex(proc.stdout, r"Verified SHA256: [0-9a-f]{64}")
                return {}, project, launch
            return json.loads((project / "generated.json").read_text("utf-8")), project, launch

    def config_output(self, shell):
        config, project, launch = self.run_shell(shell,
            "& (Join-Path $Bundle 'scripts/configure-mcp.ps1') -Mode adapter -PythonPath '" + sys.executable.replace("'", "''") + "' -OutFile '.\\generated.json'\n")
        self.assertEqual(Path(config["mcpServers"]["rhino-cn"]["command"]), Path(sys.executable))

    def config_relative_commands(self, shell):
        config, project, launch = self.run_shell(shell,
            "& (Join-Path $Bundle 'scripts/configure-mcp.ps1') -Mode adapter -PythonPath '.\\python 中文.exe' -OutFile '.\\adapter.json'\n"
            "& (Join-Path $Bundle 'scripts/configure-mcp.ps1') -Mode router -RouterPath '.\\router 中文.exe' -OutFile '.\\generated.json'\n"
            "$a = Get-Content -LiteralPath '.\\adapter.json' -Raw -Encoding UTF8 | ConvertFrom-Json\n"
            "if ($a.mcpServers.'rhino-cn'.command -ne (Join-Path $Project 'python 中文.exe')) { throw 'Python path resolved outside project' }\n")
        self.assertEqual(Path(config["mcpServers"]["rhino-cn"]["command"]), project / "router 中文.exe")

    def installer_relative(self, shell):
        # The executable is inert and has no Rhino version resource. Correct path
        # resolution reaches the version guard; wrong resolution fails at Yak path.
        self.run_shell(shell,
            "New-Item -ItemType Directory -Path '.\\模拟 Rhino\\System' | Out-Null\n"
            "[IO.File]::WriteAllBytes((Join-Path $Project '模拟 Rhino\\System\\Rhino.exe'), [byte[]](1,2,3))\n"
            "[IO.File]::WriteAllBytes((Join-Path $Project '模拟 Rhino\\System\\Yak.exe'), [byte[]](1,2,3))\n"
            "try { & (Join-Path $Bundle 'scripts/install-offline.ps1') -RhinoSystem '.\\模拟 Rhino\\System' -WhatIf; throw 'Expected version guard' }\n"
            "catch { if ($_.Exception.Message -notlike '*major version does not match*') { throw } }\n"
            "[IO.File]::WriteAllText((Join-Path $Project 'generated.json'), '{}')\n")

    def installer_whatif(self, shell):
        if not os.environ.get('RHINO_SKILL_TEST_ASSET_DIR') and not (BUNDLE / 'vendor/official/rhino-mcp-platform-0.1.5-rh8_29-win.yak').is_file():
            self.skipTest('Set RHINO_SKILL_TEST_ASSET_DIR to a verified official package cache for the offline installer test')
        self.run_shell(shell, "", versioned_rhino=True, direct_whatif=True)

    def test_ps51_outfile_follows_set_location(self):
        self.config_output("powershell.exe")

    def test_ps7_outfile_follows_set_location(self):
        self.config_output("pwsh.exe")

    def test_ps51_relative_python_and_router_follow_set_location(self):
        self.config_relative_commands("powershell.exe")

    def test_ps7_relative_python_and_router_follow_set_location(self):
        self.config_relative_commands("pwsh.exe")

    def test_ps51_relative_rhino_system_reaches_version_guard(self):
        self.installer_relative("powershell.exe")

    def test_ps7_relative_rhino_system_reaches_version_guard(self):
        self.installer_relative("pwsh.exe")

    def test_ps51_whatif_checks_hash_without_launching_yak(self):
        self.installer_whatif("powershell.exe")

    def test_ps7_whatif_checks_hash_without_launching_yak(self):
        self.installer_whatif("pwsh.exe")


if __name__ == "__main__":
    unittest.main(verbosity=2)
