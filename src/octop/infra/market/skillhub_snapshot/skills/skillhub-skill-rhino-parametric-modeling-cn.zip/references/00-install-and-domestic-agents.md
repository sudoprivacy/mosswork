# 00｜把技能装到同事电脑，并接入国产 agent

当前1.0.3首次安装/状态验收优先使用[统一操作卡](14-first-run-quickstart.md)。

交付包版本：**1.0.3（修复版）**；资料核对日期：2026-09-08。安装与使用不要求 指定模型品牌或外部模型服务 或本包作者电脑上的任何路径。

本版对Windows PowerShell5.1/7的相对路径、安装预演及可选adapter的断流恢复做了隔离故障测试；adapter内部版本为1.2.0，官方Yak仍为0.1.5；组件版本独立于技能包的对外版本1.0.3。配置片段按PowerShell当前位置解析并写入明确的新文件，不修改已有宿主配置。完整边界见 [模拟测试报告](../tests/simulation-report.md)。命令读取中文文档时明确使用UTF-8，例如 `Get-Content -LiteralPath .\SKILL.md -Encoding UTF8`。

本 SkillHub 版包含完整技能与初始化脚本；不嵌入平台禁止的二进制文件。首次使用按 [初始化说明](12-first-run-and-skillhub.md) 自动从 McNeel 官方直连服务获取需要的插件并校验。其他使用者不需要再领取附件。

## 1. 先分清需要哪几层

| 层 | 作用 | 本包是否提供 |
|---|---|---|
| Rhino | 实际存放和计算几何 | 不提供商业软件和许可证 |
| 官方 Rhino-MCP-Platform | 把 Rhino 操作提供给 agent | 首次使用自动获取 Windows 官方0.1.5原始Yak；固定来源、版本、大小与SHA256 |
| agent 宿主 | 本机运行工具、文件和多轮任务 | 使用同事已有的支持本地 MCP/命令的宿主 |
| 模型 | 识别图片、制定和修正建模方案 | 自选国产云模型或本地模型，不包含账号/密钥 |
| 本技能 | 中文流程、经验、验证、脚本 | 全部包含 |
| 可选中文适配器 | 官方 HTTP 单实例转 stdio、CLI 调用 | 标准库 Python 脚本，无 pip/npm 依赖 |

“国产模型”不等于“国产 agent 宿主”。同一个模型可以由不同宿主调用，MCP 能力取决于宿主；图像能力取决于模型及宿主是否传入图片。工具路径在运行 MCP 的那台电脑上解析，不在模型云服务上解析。

## 2. Windows 最短安装路径

1. 把 **整个 ZIP 解压**到固定目录，如 `D:\Rhino技能\rhino-parametric-modeling-cn`。不要在 ZIP 预览窗口直接运行，不要只复制 SKILL.md 后丢掉其引用文件。
2. 检查 Rhino：本包 `rh8_29` 资产要求 Rhino **8.29 或更高的 8.x**；`rh9_0` 资产供 Rhino9系列，具体兼容性以加载结果为准。**Rhino7使用[随包独立兼容桥](13-rhino7-ready-workflow.md)**，不用这两份官方插件；直接执行`setup-rhino.ps1 -RhinoVersion 7`和`configure-mcp.ps1 -RhinoVersion 7`，不走下面的官方安装流程。
3. 若已安装官方插件，保留现有版本，直接去第 5 步；不要为了用此技能降级。
4. 在解压目录打开 PowerShell，按自己 Rhino 版本运行一次初始化；由 agent 完成环境准备时也执行相同命令：

```powershell
# Rhino 8.29+
& .\scripts\setup-rhino.ps1 -RhinoVersion 8

# Rhino 9；只有使用 9 时才运行
& .\scripts\setup-rhino.ps1 -RhinoVersion 9

# 非默认安装目录示例
& .\scripts\setup-rhino.ps1 -RhinoVersion 8 -RhinoSystem 'D:\应用\Rhino 8\System'
```

初始化脚本先核对Rhino版本和已有插件；缺插件时从固定的 `` 官方源下载，核对清单中的大小和SHA256，再调用 **对应Rhino自带的Yak.exe安装本地文件**。可用缓存会复用，已安装的插件不会擅自降级/替换；不改agent配置，不关闭或保存正在工作的Rhino。`-PrepareOnly` 只准备并校验缓存，`-WhatIf` 不下载或安装。完整配置后的使用不需要反复下载。

如公司的 PowerShell 策略不允许运行脚本，不要更改整机策略；可直接用对应 Rhino 自带的 Yak 执行官方本地安装：

```powershell
& 'C:\Program Files\Rhino 8\System\Yak.exe' install 'D:\已核验缓存\rhino-mcp-platform-0.1.5-rh8_29-win.yak'
```

以上缓存路径是示例。只有无法运行PS1时，才从 `vendor/official/assets.json` 的官方 `download_url` 手工获取原件并核验SHA256，再按实际缓存路径修改。正常首次流程由本技能的初始化脚本完成。Yak 官方支持安装本地 `.yak`，新增包在下次 Rhino 启动时加载。Yak CLI 官方说明，安装与加载说明。

5. 保存自己的工作后重新启动 Rhino，运行 `MCPConnect`。看见真实插件配置再继续。以该命令给出的 router 路径和配置为优先依据。
6. 生成一份 **待导入的配置片段**：

```powershell
# 必须与安装的版本一致；Rhino9使用9
$rhinoVersion = '8' # 使用Rhino9时改为'9'
& .\scripts\configure-mcp.ps1 -RhinoVersion $rhinoVersion -OutFile '.\rhino-mcp.generated.json'
```

脚本查找已安装插件的官方 `rhino-mcp-router.exe`，生成 `mcpServers` JSON；主路径不需要 Node.js 或外部 Python。多个候选时不猜最新，用 `MCPConnect` 当前配置里的绝对路径显式指定：

```powershell
& .\scripts\configure-mcp.ps1 -RhinoVersion $rhinoVersion `
  -RouterPath 'C:\Users\同事\AppData\Roaming\McNeel\Rhinoceros\packages\8.0\Rhino-MCP-Platform\0.1.5\router\win-x64\rhino-mcp-router.exe' `
  -OutFile '.\rhino-mcp.generated.json'
```

不会覆盖已有文件。把 JSON 内的 `rhino-cn` 条目**合并**进宿主现有 MCP 配置，不要用整份示例替换已有账号/工具设置；宿主可能还要求 `type: "stdio"` 等字段，以其实际 schema 为准。目录改名或移动后重新生成路径。**如果公司不允许运行 PS1，直接复制 `MCPConnect` 对话框的 `mcp.json` 标签内容并合并即可，配置生成脚本是便利工具，不是必需组件。**

7. 让宿主读取 SKILL.md；若支持技能目录，放入其规定的 skills 目录。若不支持自动 skill，给项目规则增加一句：`开始 Rhino 参考建模前，读取 D:\Rhino技能\rhino-parametric-modeling-cn\SKILL.md，并按当前阶段加载其 references。`
8. 用 [分阶段提示词](07-agent-prompts.md) 的只读检查验证目标文档，然后在测试副本上做小范围创建、检查、截图和重读保存，再开始复杂项目。

## 3. 本地智能助手的通用接入方式

宿主需支持本地stdio MCP进程或命令执行。把生成配置中的 `mcpServers.rhino-cn` 条目导入实际宿主设置，保留已有模型配置和其他工具；以该宿主实际配置结构为准，不绑定品牌或指定模型服务。

模型服务和本机建模工具是两层独立能力。模型账号由使用者已有环境提供，本技能不推荐服务商、收费计划或购买渠道。模型与宿主的图像输入、工具图片和多轮调用能力需实测。

只有云端网页聊天而没有本机执行能力时，不能直接访问这台电脑的建模软件。回环地址在云服务器中指云服务器自身；不得将未保护的本机端口开放到公网来绕过这一限制。

接入后先核对真实工具列表与目标文档，再在测试副本完成小样、截图和保存重读；配置导入成功不等于所有建模任务均已验证。

## 4. 可选：中文工具适配器

需要本机 Python 3.10+，只使用标准库。适配器连接**已启动监听的官方 Rhino 实例**，把官方 HTTP JSON-RPC 转为通用 stdio MCP，叠加中文说明，保留真实工具名和 schema。它不代替官方 router 的槽位管理、自动启动及跨版本功能，也不把 Rhino 7 旧 socket 端口当作官方服务。

先在目标 Rhino 执行 `MCPStart` 并确认监听地址。`MCPConnect` 打开连接配置对话框，不等于已经启动 HTTP 监听。在解压目录运行（路径按本机修改）：

```powershell
& 'C:\Python311\python.exe' .\adapter\rhino_stdio_adapter.py probe
& 'C:\Python311\python.exe' .\adapter\rhino_stdio_adapter.py tools --out 'D:\建模任务\连接记录'
```

自动发现只接受唯一有效官方公告；存在多个实例必须明确 `--pid` 或经核对的 `--url`。`10500` 仅是官方端口起点示例，不保证当前实例就是该端口；重新启动后端口/PID 也可能变化。

```powershell
& 'C:\Python311\python.exe' .\adapter\rhino_stdio_adapter.py probe --pid 12345
& .\scripts\configure-mcp.ps1 -Mode adapter `
  -PythonPath 'C:\Python311\python.exe' -RhinoPid 12345 `
  -OutFile '.\rhino-cn-adapter.generated.json'
```

生成配置使用绝对路径和独立 argv 参数，因此可放中文及空格目录。不要同时启用官方 router 和适配器对同一文档进行并行写入。详细接口和测试边界见 [适配器说明](../adapter/README.md)。

### 不能接 MCP，但能执行本地命令

可使用同一个适配器 CLI：

```powershell
# 参数放在 UTF-8 JSON 文件中；name 必须先由 tools 返回
& 'C:\Python311\python.exe' .\adapter\rhino_stdio_adapter.py call `
  --pid 12345 --name '实际工具名' --arguments-file 'D:\建模任务\args.json' `
  --out 'D:\建模任务\工具结果'

# Rhino Python 3 脚本由真实 run_python 工具执行
& 'C:\Python311\python.exe' .\adapter\rhino_stdio_adapter.py run-python `
  --pid 12345 --script-file 'D:\建模任务\stage.py' --out 'D:\建模任务\工具结果'
```

`--out` 保存原始 JSON；图片内容会原样解码到唯一子目录，agent 还需实际读取/显示这些图片才能做视觉核对。`run-python` 是便利入口，会先核对工具清单，并非假设任何第三方 Rhino MCP 都提供 `run_python`。

完整的 CLI 截图例子：先在 `tools` 中确认 `get_viewport_image` 及其当前参数 schema。官方稳定 0.1.5 的该工具参数均有默认值，可用空对象；先创建已存在的工作目录，再执行：

```powershell
[IO.File]::WriteAllText('D:\建模任务\image-args.json', '{}', (New-Object Text.UTF8Encoding $false))
& 'C:\Python311\python.exe' .\adapter\rhino_stdio_adapter.py call `
  --pid 12345 --name get_viewport_image --arguments-file 'D:\建模任务\image-args.json' `
  --out 'D:\建模任务\截图结果'
```

读取命令 stdout JSON 的 `files` 数组，然后用宿主图片读取工具真正查看 JPG/PNG。若改用 `capture_views.py`，PNG 由 Rhino 脚本直接写出，路径在脚本报告的 `files` 中；此时适配器的顶层 `files` 可能为空，因为 `run_python` 只返回了文本。同一 PID 对应多个文档监听时要改用已核对的 `--url`，不能随便选一个。

## 5. 无代理、离线和首次依赖

| 场景 | 还需要什么 |
|---|---|
| 同事有 Rhino 8.29+/9 和本地 MCP 宿主，接国产云模型 | 本技能自动初始化取得插件，技能内容完整包含；模型服务网络/账号由宿主管理 |
| 官方 router 主路径 | 初始化取得的官方 Yak + 已安装 Rhino 及其 .NET 8 运行时；无需运行 npm/pip/npx |
| 可选中文适配器 | 同事电脑预装 Python 3.10+；无需额外 Python 包 |
| 完全断网 | 官方插件须已安装或有已校验缓存；Rhino许可、本地宿主、本地模型、视觉输入能力与ScriptEditor依赖都需预先就绪 |
| Rhino 内部 run_python | 在目标电脑先完成 ScriptEditor 的 Python 3 初始化并运行只读脚本验证；首次初始化可能需要 PyPI 网络 |
| 外部复杂网格/图像计算 | 按项目选择 rhino3dm、NumPy、SciPy、Shapely 等；它们不是接入的必要依赖，本包未携带所有平台的 wheels |

不要在 agent 启动 MCP 时偷偷 `pip install` 或 `npx -y`。如果具体项目确需外部库，在一台能联网的同系统/同 Python 版本电脑准备对应 wheelhouse，使用 `pip download` 收集 wheel，离线电脑用 `pip install --no-index --find-links <wheelhouse> <包名>`。包版本、Python ABI、操作系统和 CPU 架构都要匹配；无适配 wheel 时不应声称已完成离线依赖准备。RhinoCommon 可完成的建模无需为了套用某案例强加这些库。

**以下Python3初始化针对Rhino8/9官方通道；Rhino7随包桥无需此步骤。外部Python与Rhino内部Python是两份不同运行环境。** 即使同事电脑已经安装 Python，也不能推定 Rhino 的脚本语言已初始化。断网前在同一台电脑运行 `ScriptEditor`，等待 Python 3 初始化完成并执行一个标准库只读脚本。尚未准备好时，先用官方 `get_context`、`get_viewport_image` 检查连接；不要把首次语言初始化超时归为模型失败。McNeel 官方语言初始化说明。本包没有携带或自动复制用户的 `.rhinocode` 运行目录。

本包不安装代理，不修改系统代理，不需要把国内模型请求转发海外服务。可选适配器连接回环地址时主动绕过环境代理，防止本地 MCP 被误送代理。

## 6. 常见问题

| 症状 | 先检查和处理 |
|---|---|
| 找不到 MCPConnect | 插件是否匹配 Rhino 版本、安装后是否重启、插件加载日志 |
| 只有安装占位工具 | 还没有实际建模服务；安装提示不是可用工具清单 |
| MCP 启动失败 | command 绝对路径、args 数组、文件是否移动、宿主是否支持 stdio；看 stderr |
| 连到空文档 | router 自动启动或实例选错；重新绑定并确认实际路径，先不写入 |
| 适配器找不到公告 | 已在目标 Rhino 运行 MCPStart 并启动监听吗；是否多个实例；查看 README 的公告路径和 --listener-dir |
| 连不上10500 | 不是固定端口；读本次公告。不要扫描猜测第三方旧端口 |
| 模型只说计划不调用 | 工具未启用、模型不支持可靠调用、schema 超出上下文；先做小任务测试 |
| 无法看截图 | 检查宿主图片 tool result 支持，CLI 可用 --out 落盘并实际读取 |
| 返回200但没有结果 | 查看 MCP isError、content.text 内脚本 error、生成对象和保存报告 |
| 超时 | 检查是否已完成该 run_id；不自动重放写入。大批工作分批、输出摘要 |
| 图层隐藏保存后失效 | 检查保存重读；File3dm 图层属性在 Add 前设置，不依赖脱离表的副本 |
| 对象过多或浏览器卡顿 | 曲面与显示网格分层，批次/实例，先低细节预览；大 GLB 通过本地 HTTP 查看 |

接入后用测试副本运行小样与检查流程，实际测试记录见 `VALIDATION.md`。
