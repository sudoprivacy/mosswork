#!/usr/bin/env python3
"""Optional local-only adapter for McNeel RhinoAI's external HTTP endpoint.

Python >= 3.10, standard library only. Prefer the official rhino-mcp-router
stdio executable when available. This adapter never launches Rhino or installs
packages; it attaches to one already running official Rhino 8/9 listener.
"""
import argparse
import base64
import copy
import http.client
import ipaddress
import json
import os
from pathlib import Path
import sys
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

VERSION = "1.2.0"
PROTOCOL = "2024-11-05"
SUPPORTED_PROTOCOLS = (PROTOCOL, "2025-03-26", "2025-06-18")
SOURCE_COMMIT = "4109116e3ea2cfd62859fd150b5f4331b93f45b5"
STABLE_COMMIT = "7f079d27199f1690143b9229db80b25ba38915be"
MAX_RESPONSE = 256 * 1024 * 1024
ZH = {
    "get_context": "读取当前文档上下文快照；先核对文档与单位。",
    "list_objects": "列出文档对象；按实际参数筛选和分页。",
    "get_selection": "读取当前选择。",
    "set_selection": "设置对象选择。",
    "get_commands": "读取 Rhino 可调用命令。",
    "get_viewport_image": "捕获 Rhino 视口图像，用于检查真实模型。",
    "set_camera": "设置视口相机。",
    "zoom_to_object": "将视图缩放至指定对象。",
    "zoom_to_layer": "将视图缩放至指定图层。",
    "run_python": "执行 Python 3 脚本；文档句柄必须使用注入的 __rhino_doc__，不要依赖 scriptcontext.doc 或 rhinoscriptsyntax。",
    "run_csharp": "执行 C# 脚本；使用官方工具注入的文档上下文。",
    "run_command": "执行 Rhino 命令；按原参数说明传入命令。",
    "open_doc": "打开或导入文档；调用前核对完整路径。",
    "save_doc": "保存文档；按建模任务约定另存交付文件。",
    "close_doc": "关闭文档；调用前处理未保存工作。",
    "set_layer_material": "设置图层材质。",
    "manage_plugin_commands": "管理插件命令。",
}


class AdapterError(Exception):
    def __init__(self, message, code=-32001, data=None):
        super().__init__(message)
        self.code, self.data = code, data

    def rpc(self, request_id):
        error = {"code": self.code, "message": str(self)}
        if self.data is not None:
            error["data"] = self.data
        return {"jsonrpc": "2.0", "id": request_id, "error": error}


def dump(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def strict_json(value):
    """Reject non-finite numbers and invalid UTF-8 before an HTTP write."""
    result = json.loads(value)
    dump(result).encode("utf-8")
    return result


def normalized_url(value):
    """Only the audited external loopback root endpoint is accepted."""
    try:
        parsed = urllib.parse.urlsplit(value)
        port = parsed.port
        host = parsed.hostname
        local = host == "localhost" or (host and ipaddress.ip_address(host).is_loopback)
    except ValueError:
        local = False
        parsed, port = None, None
    if not parsed or not local or parsed.scheme != "http" or not port:
        raise AdapterError("仅接受官方本机地址 http://127.0.0.1:<端口>/ 或 http://localhost:<端口>/。")
    if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ("", "/"):
        raise AdapterError("官方外部端点路径必须为 /；不要使用 /agent、/mcp、凭据或查询参数。")
    return urllib.parse.urlunsplit(("http", parsed.netloc, "/", "", ""))


def default_listener_dir():
    override = os.environ.get("RHINO_MCP_HOME")
    if override:
        return Path(override) / "rhino-mcp" / "listeners"
    if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "McNeel" / "rhino-mcp" / "listeners"
    # .NET LocalApplicationData on Unix commonly resolves to XDG_DATA_HOME.
    # Explicit --listener-dir avoids depending on a platform's .NET mapping.
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))) / "McNeel" / "rhino-mcp" / "listeners"


def announcements(directory, pid=None):
    found = []
    for file in sorted(Path(directory).glob("*.json")):
        try:
            item = json.loads(file.read_text(encoding="utf-8-sig"))
            if item.get("v") != 1 or str(item.get("version")) not in ("8", "9"):
                continue
            if type(item.get("pid")) is not int or type(item.get("port")) is not int:
                continue
            if item["pid"] <= 0 or not 0 < item["port"] < 65536:
                continue
            if pid is not None and item["pid"] != pid:
                continue
            found.append({"pid": item["pid"], "version": str(item["version"]),
                          "url": "http://127.0.0.1:%d/" % item["port"], "announcement": str(file)})
        except (OSError, ValueError, TypeError, AttributeError):
            continue
    return found


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise AdapterError("本机官方端点不应重定向；已停止，未转发到其他地址。")


class DeadlineHTTPConnection(http.client.HTTPConnection):
    """Socket watchdog includes send and header parsing, not just the body."""
    def connect(self):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0: raise TimeoutError("Request total deadline exceeded")
        self.timeout = min(self.timeout, remaining)
        # Only literal loopback addresses are used; avoid DNS for localhost.
        if self.host == "localhost": self.host = "127.0.0.1"
        super().connect()
        sock = self.sock
        def abort():
            try: sock.shutdown(socket.SHUT_RDWR)
            except OSError: pass
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            self.close()
            raise TimeoutError("Request total deadline exceeded")
        self.watchdog = threading.Timer(remaining, abort)
        self.watchdog.daemon = True
        self.watchdog.start()


class DeadlineHTTPHandler(urllib.request.HTTPHandler):
    def __init__(self):
        super().__init__()
        self.deadline = 0
        self.connections = []

    def http_open(self, request):
        def create(host, **kwargs):
            connection = DeadlineHTTPConnection(host, **kwargs)
            connection.deadline = self.deadline
            connection.watchdog = None
            self.connections.append(connection)
            return connection
        return self.do_open(create, request)

    def finish(self):
        for connection in self.connections:
            if connection.watchdog is not None: connection.watchdog.cancel()
        self.connections.clear()


class OfficialHTTP:
    def __init__(self, url, timeout=180):
        self.url = normalized_url(url)
        self.timeout = timeout
        self.deadline_handler = DeadlineHTTPHandler()
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(), self.deadline_handler)
        self.initialized = False
        self.tools = None
        self.next_cursor = None
        self.info = None
        self.protocol = PROTOCOL

    def post(self, message):
        try:
            payload = dump(message).encode("utf-8")
        except (ValueError, UnicodeError) as exc:
            raise AdapterError("请求不能编码为严格 UTF-8 JSON；请检查非有限数值或无效字符。", -32602) from exc
        request = urllib.request.Request(self.url, data=payload, method="POST", headers={
            "Content-Type": "application/json", "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": message.get("params", {}).get("protocolVersion", self.protocol) if message.get("method") == "initialize" else self.protocol,
        })
        deadline = time.monotonic() + self.timeout
        self.deadline_handler.deadline = deadline
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                # Reject indefinite SSE before reading any body bytes.
                if "text/event-stream" in response.headers.get("Content-Type", "").lower():
                    raise AdapterError("此上游返回 SSE；本适配器只支持官方 JSON POST 端点。请用官方 stdio router。")
                sock = getattr(getattr(getattr(response, "fp", None), "raw", None), "_sock", None)
                def abort_read():
                    if sock is not None:
                        try: sock.shutdown(socket.SHUT_RDWR)
                        except OSError: pass
                remaining = deadline - time.monotonic()
                if remaining <= 0: raise TimeoutError("Request total deadline exceeded")
                watchdog = threading.Timer(remaining, abort_read)
                watchdog.daemon = True
                watchdog.start()
                try:
                    chunks, received = [], 0
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0: raise TimeoutError("Request total deadline exceeded")
                        if sock is not None: sock.settimeout(remaining)
                        read = getattr(response, "read1", response.read)
                        chunk = read(min(65536, MAX_RESPONSE + 1 - received))
                        if time.monotonic() >= deadline: raise TimeoutError("Request total deadline exceeded")
                        if not chunk: break
                        received += len(chunk)
                        if received > MAX_RESPONSE: raise AdapterError("响应超过 256 MiB；请减少视口尺寸或拆分结果。")
                        chunks.append(chunk)
                    data = b"".join(chunks)
                finally:
                    watchdog.cancel()
                if response.status in (202, 204) and not data and message.get("id") is None:
                    return None
        except AdapterError as exc:
            raise self.response_error(str(exc), message) from exc
        except (OSError, urllib.error.URLError, http.client.HTTPException) as exc:
            # No retries: a timed-out script may still have modified the document.
            uncertain = message.get("method") == "tools/call"
            raise AdapterError("官方 HTTP 连接失败：%s。%s" % (exc, "该工具执行结果未知；请先检查 Rhino，不要自动重试。" if uncertain else "请确认 Rhino 8/9 中官方 MCPStart 已运行和端口正确。"),
                               data={"executionState": "unknown" if uncertain else "unavailable", "automaticRetry": False}) from exc
        finally:
            self.deadline_handler.finish()
        if message.get("id") is None:
            return None
        try:
            result = strict_json(data.decode("utf-8-sig"))
        except (ValueError, UnicodeError) as exc:
            raise self.response_error("官方端点未返回有效 JSON；请核对地址和插件版本。", message) from exc
        if not isinstance(result, dict) or result.get("jsonrpc") != "2.0" or result.get("id") != message["id"]:
            raise self.response_error("上游 JSON-RPC 响应格式或请求 id 不匹配。", message)
        if ("result" in result) == ("error" in result):
            raise self.response_error("上游响应必须且只能包含 result 或 error。", message)
        return result

    @staticmethod
    def response_error(message_text, request):
        # A malformed response cannot establish that a submitted tool did not run.
        if request.get("method") == "tools/call":
            return AdapterError(message_text + " 该工具执行结果未知；请先检查 Rhino，不要自动重试。",
                                data={"executionState": "unknown", "automaticRetry": False})
        return AdapterError(message_text)

    def rpc(self, method, params=None, request_id="adapter"):
        message = {"jsonrpc": "2.0", "method": method}
        if request_id is not None:
            message["id"] = request_id
        if params is not None:
            message["params"] = params
        return self.post(message)

    def initialize(self, params=None, request_id="adapter-init"):
        params = params or {"protocolVersion": PROTOCOL, "capabilities": {},
                            "clientInfo": {"name": "rhino-parametric-modeling-cn-adapter", "version": VERSION}}
        params = copy.deepcopy(params)
        requested = params.get("protocolVersion", PROTOCOL)
        params["protocolVersion"] = requested if requested in SUPPORTED_PROTOCOLS else PROTOCOL
        response = self.rpc("initialize", params, request_id)
        if "error" in response:
            return response
        info = response["result"]
        if not isinstance(info, dict) or not isinstance(info.get("serverInfo"), dict):
            raise AdapterError("上游 initialize 缺少 serverInfo。")
        if info.get("serverInfo", {}).get("name") != "rhino-mcp":
            raise AdapterError("服务标识不是已审计官方 rhino-mcp；拒绝将其他 Rhino 桥当作官方平台。")
        if info.get("protocolVersion") not in SUPPORTED_PROTOCOLS:
            raise AdapterError("上游协议与本适配器审计版本不符；请使用官方 router 或更新适配器。")
        self.protocol = info["protocolVersion"]
        self.info, self.initialized = info, True
        return response

    def ready(self):
        response = self.initialize()
        if "error" in response:
            err = response["error"]
            raise AdapterError(err.get("message", "上游初始化失败"), err.get("code", -32001), err.get("data"))
        self.rpc("notifications/initialized", request_id=None)

    def list_tools(self, request_id="adapter-tools", params=None, chinese=True):
        response = self.rpc("tools/list", params, request_id)
        if "result" not in response:
            return response
        response = copy.deepcopy(response)
        if not isinstance(response["result"], dict):
            raise AdapterError("上游 tools/list 不含有效工具清单。")
        entries = response["result"].get("tools", [])
        next_cursor = response["result"].get("nextCursor")
        if next_cursor is not None and not isinstance(next_cursor, str):
            raise AdapterError("上游 tools/list 的 nextCursor 必须为字符串。")
        if not isinstance(entries, list) or any(not isinstance(t, dict) or not isinstance(t.get("name"), str) or not isinstance(t.get("inputSchema"), dict) for t in entries):
            raise AdapterError("上游 tools/list 不含有效工具清单。")
        page_tools = {t["name"]: copy.deepcopy(t) for t in entries}
        if len(page_tools) != len(entries):
            raise AdapterError("上游工具名称重复，无法确定调用目标。")
        continuing = isinstance(params, dict) and "cursor" in params
        if continuing and self.tools is not None:
            if self.tools.keys() & page_tools.keys():
                raise AdapterError("上游工具名称跨分页重复，请从头重新发现能力。")
            self.tools.update(page_tools)
        else:
            self.tools = page_tools
        self.next_cursor = next_cursor
        # Do not change names, argument schemas, annotations, or capabilities.
        for tool in entries:
            if chinese and tool["name"] in ZH:
                tool["description"] = ZH[tool["name"]] + "\n\n官方原说明：\n" + tool.get("description", "")
        return response

    def call(self, name, arguments, request_id="adapter-call"):
        if not isinstance(name, str):
            raise AdapterError("工具 name 必须为字符串。", -32602)
        if self.tools is None:
            listing = self.list_tools()
            if "error" in listing:
                listing["id"] = request_id
                return listing
        seen_cursors = set()
        while name not in self.tools and self.next_cursor is not None:
            cursor = self.next_cursor
            if cursor in seen_cursors:
                raise AdapterError("上游工具分页游标重复，请重新发现能力。")
            seen_cursors.add(cursor)
            listing = self.list_tools(params={"cursor": cursor})
            if "error" in listing:
                listing["id"] = request_id
                return listing
        if name not in self.tools:
            raise AdapterError("当前官方 tools/list 未提供工具 %r；请重新发现能力，不要猜测名称。" % name, -32602)
        if not isinstance(arguments, dict):
            raise AdapterError("arguments 必须为 JSON 对象。", -32602)
        return self.rpc("tools/call", {"name": name, "arguments": arguments}, request_id)


def connect(args):
    if args.url:
        return OfficialHTTP(args.url, args.timeout), {"selection": "explicit-url", "url": normalized_url(args.url)}
    candidates = announcements(args.listener_dir, args.pid)
    if not candidates:
        raise AdapterError("未发现官方 Rhino 8/9 公告。请运行官方 MCPStart，再传 --url 或 --listener-dir；本工具不会启动 Rhino。")
    alive, errors = [], []
    deadline = time.monotonic() + min(args.timeout, 10)
    for item in candidates[:32]:
        remaining = deadline - time.monotonic()
        if remaining <= 0: break
        probe = OfficialHTTP(item["url"], min(remaining, 3))
        try:
            response = probe.initialize()  # Identity check only; no tool write.
            if "error" in response: raise AdapterError(str(response["error"]))
            alive.append(item)
        except AdapterError as exc:
            errors.append({"url": item["url"], "pid": item.get("pid"), "error": str(exc)})
    incomplete = len(alive) + len(errors) < len(candidates)
    if incomplete:
        raise AdapterError("监听器发现达到时间或数量上限；请用 --url 或 --pid 精确选择。",
                           data={"listeners": alive, "probeErrors": errors, "discoveryIncomplete": True, "announcementFilesUntouched": True})
    if len(alive) != 1:
        raise AdapterError("可用官方监听器数量为 %d；请用 --url 或 --pid 精确选择实例。" % len(alive),
                           data={"listeners": alive, "probeErrors": errors, "announcementFilesUntouched": True})
    chosen = alive[0]
    return OfficialHTTP(chosen["url"], args.timeout), {"selection": "announcement", **chosen}


def handle(client, message, chinese=True):
    if not isinstance(message, dict) or message.get("jsonrpc") != "2.0" or not isinstance(message.get("method"), str):
        raise AdapterError("需要单条 JSON-RPC 2.0 请求对象。", -32600)
    request_id = message.get("id")
    if isinstance(request_id, (dict, list, bool)):
        raise AdapterError("请求 id 必须为字符串或数值。", -32600)
    method, params = message["method"], message.get("params", {})
    if not isinstance(params, dict):
        raise AdapterError("params 必须为对象。", -32602)
    if method == "initialize":
        if request_id is None:
            raise AdapterError("initialize 需要请求 id。", -32600)
        return client.initialize(params, request_id)
    if not client.initialized:
        raise AdapterError("请先完成 initialize 握手。", -32002)
    if request_id is None:
        if method in ("notifications/initialized", "notifications/cancelled"):
            client.rpc(method, params, request_id=None)
        return None
    if method == "tools/list":
        return client.list_tools(request_id, params, chinese)
    if method == "tools/call":
        return client.call(params.get("name"), params.get("arguments", {}), request_id)
    if method in ("ping", "resources/list", "resources/templates/list", "resources/read"):
        return client.rpc(method, params, request_id)
    raise AdapterError("该官方端点不支持方法 %s。" % method, -32601)


def stdio(args):
    client = None
    for line in sys.stdin:
        if not line.strip():
            continue
        message = None
        try:
            try:
                message = strict_json(line)
            except (ValueError, UnicodeError) as exc:
                raise AdapterError("无效 JSON。", -32700) from exc
            # Do not connect to Rhino for malformed input.
            if not isinstance(message, dict) or not isinstance(message.get("method"), str) or message.get("jsonrpc") != "2.0":
                raise AdapterError("需要单条 JSON-RPC 2.0 请求对象。", -32600)
            if client is None:
                client, _ = connect(args)
            response = handle(client, message, not args.original_descriptions)
        except AdapterError as exc:
            response = exc.rpc(message.get("id") if isinstance(message, dict) else None)
            if isinstance(message, dict) and message.get("id") is None and isinstance(message.get("method"), str):
                response = None
                print(str(exc), file=sys.stderr)
        if response is not None:
            print(dump(response), flush=True)
    return 0


def write_artifacts(response, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    # A unique run directory prevents replacing an earlier report/capture.
    import tempfile
    run = Path(tempfile.mkdtemp(prefix="rhino-", dir=str(directory)))
    (run / "response.json").write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
    files = []
    for index, block in enumerate(response.get("result", {}).get("content", [])):
        if block.get("type") not in ("image", "audio") or not isinstance(block.get("data"), str):
            continue
        suffix = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "audio/wav": ".wav", "audio/mpeg": ".mp3"}.get(block.get("mimeType"), ".bin")
        try:
            payload = base64.b64decode(block["data"], validate=True)
        except ValueError:
            continue
        target = run / ("content-%03d" % index + suffix)
        target.write_bytes(payload)
        files.append(str(target.resolve()))
    return {"report": str((run / "response.json").resolve()), "files": files}


def response_failed(response, tool_name=None):
    if "error" in response or response.get("result", {}).get("isError") is True:
        return True
    # stable 0.1.5 run_python encodes script errors as JSON inside text content.
    # Preserve that content, but do not tell a CLI caller that failed Python ran OK.
    if tool_name in ("run_python", "run_csharp"):
        for block in response.get("result", {}).get("content", []):
            if block.get("type") == "text":
                try:
                    payload = json.loads(block.get("text", ""))
                    if isinstance(payload, dict) and payload.get("error"):
                        return True
                except ValueError:
                    pass
    return False


def parser():
    result = argparse.ArgumentParser(description="官方 Rhino 8/9 HTTP 单实例便携适配器；优先使用官方 stdio router。")
    commands = result.add_subparsers(dest="command", required=True)
    for name in ("stdio", "probe", "tools", "call", "run-python"):
        sub = commands.add_parser(name)
        sub.add_argument("--url", help="官方外部地址，例如 http://127.0.0.1:10500/")
        sub.add_argument("--listener-dir", default=str(default_listener_dir()))
        sub.add_argument("--pid", type=int, help="按官方 listener 公告的 Rhino 进程号筛选")
        sub.add_argument("--timeout", type=float, default=180)
        sub.add_argument("--original-descriptions", action="store_true")
        if name != "stdio":
            sub.add_argument("--out", help="保存 JSON 报告和图像到此目录下的新运行子目录")
        if name == "call":
            sub.add_argument("--name", required=True)
            sub.add_argument("--arguments-file", required=True, help="UTF-8 JSON 参数对象文件")
        if name == "run-python":
            sub.add_argument("--script-file", required=True, help="UTF-8 Python 3 脚本文件")
    return result


def main(argv=None):
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    args = parser().parse_args(argv)
    if not 0 < args.timeout <= 86400:
        parser().error("--timeout 必须大于 0 且不超过 86400 秒")
    if args.url and args.pid is not None:
        parser().error("--url 与 --pid 不能同时使用")
    if args.command == "stdio":
        return stdio(args)
    try:
        client, selected = connect(args)
        client.ready()
        if args.command == "probe":
            ping = client.rpc("ping")
            listing = client.list_tools(chinese=not args.original_descriptions)
            if "error" in ping or "error" in listing:
                response = ping if "error" in ping else listing
            else:
                response = {"jsonrpc": "2.0", "id": "probe", "result": {
                    "adapterVersion": VERSION, "sourceCommit": SOURCE_COMMIT, "stableCommit": STABLE_COMMIT, "connection": selected,
                    "server": client.info, "ping": ping["result"], "toolCount": len(client.tools),
                    "toolNames": sorted(client.tools), "scope": "single-running-official-listener", "liveRhino7Validated": False}}
        elif args.command == "tools":
            response = client.list_tools(chinese=not args.original_descriptions)
        elif args.command == "call":
            arguments = strict_json(Path(args.arguments_file).read_text(encoding="utf-8-sig"))
            response = client.call(args.name, arguments)
        else:
            script = Path(args.script_file).read_text(encoding="utf-8-sig")
            response = client.call("run_python", {"script": script})
        tool_name = "run_python" if args.command == "run-python" else getattr(args, "name", None)
        failed = response_failed(response, tool_name)
        if args.out:
            print(dump({"ok": not failed, **write_artifacts(response, args.out)}))
        else:
            print(json.dumps(response, ensure_ascii=False, indent=2))
        return 1 if failed else 0
    except (AdapterError, OSError, ValueError) as exc:
        error = exc if isinstance(exc, AdapterError) else AdapterError(str(exc))
        print(dump(error.rpc(None)), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
