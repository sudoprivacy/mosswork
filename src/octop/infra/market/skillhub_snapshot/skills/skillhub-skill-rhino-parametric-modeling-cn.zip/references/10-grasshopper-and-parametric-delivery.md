# 10 · Grasshopper 与通用参数化交付

本章适用于产品外壳、开孔板、格栅、肋阵列、栏杆、楼梯、展陈、幕墙等由规则驱动的模型。先建立可计算关系，再选择 Grasshopper、Rhino 脚本或两者结合；不把某一建筑案例的坐标、体量比例或图层名当成通用模板。

## 1. 参数化的实际交付合同

真正的参数化交付需要同时保存：**可编辑输入、依赖关系、生成器、源几何引用、重算方法与验证记录**。可用 `.gh/.ghx` 承载图形定义，也可用 `parameters.json + builder.py` 承载脚本定义。两者都应支持在约定范围内改参数后重新得到模型。

| 交付内容 | 能证明什么 | 还需要什么 |
|---|---|---|
| 烘焙后的 3dm / mesh / Brep | 当前几何状态可查看或编辑 | 不会自动保留生成规则；需另交定义与参数 |
| 有命名参数的脚本 | 输入能够驱动计算 | 提供实际调用、范围/约束、源引用和重算测试 |
| 有滑块的 GH 定义 | 存在输入控件 | 检查滑块是否真正连接并影响目标输出 |
| `.gh` + 参数快照 + 依赖清单 + 重算记录 | 能追溯并复算约定模型 | 仍需检查同事电脑上的组件版本和外部资源 |
| 几何 recipe / 参数校验器 | 可以检查计算关系和重现构造输入 | 本身还不是 Rhino 实体，也不是已经测试的 `.gh` 文件 |

**不能只交一堆烘焙网格就称“完全参数化”。** 如果某些部位仅作显示网格，明确它们由哪个上游曲面/规则生成、哪些参数可改、哪些关系尚未建立。不要承诺任意数值都能重算；合同范围内通过测试即可，超界要有可读错误。

## 2. GH 与脚本之间只有一份参数事实来源

推荐把参数 JSON 或 GH 输入面板选为唯一事实来源，另一边作显式映射。不要同时维护不同值的 JSON、滑块默认值和脚本常数。

例如孔板采用“固定孔距，派生行列数”；肋阵列采用“固定数量，派生中心距”。如果宽度、数量、间距全部暴露给用户，必须说明谁是主输入、谁是派生值，不能让三者互相覆盖。

```mermaid
flowchart LR
  A[命名输入与源几何] --> B[类型/单位/范围校验]
  B --> C[跨字段约束]
  C --> D[派生尺寸与数据树]
  D --> E[原生几何生成]
  E --> F[有效性/尺寸/数量验证]
  F --> G[预览与内部校核]
  G --> H[按已授权范围 Bake]
  H --> I[GUID/批次标签/文件重读验证]
```

几何构建与 Bake 分开。滑动参数可以更新预览，但不能每次求解都在 Rhino 文档里添加一批重复对象。脚本组件的输入访问方式、类型提示和输出设置会影响数据如何进入和离开组件，应逐一记录。McNeel 脚本组件输入/输出说明、发布组件的输入与输出设置。

## 3. 先发现工具与组件，不能猜 GUID

连接实际 Rhino/GH 环境后先读取 `tools/list`、工具参数 schema 和可访问的 GH 文档/组件清单。只使用当前返回的工具名；平台版本、已加载插件、GH 1/GH 2 或文档槽位可能影响可用工具。

为每个用到的组件记录：真实名称、组件类型标识、文档内实例标识、插件/程序集版本，以及输入输出端口的名称、索引、数据类型、Item/List/Tree 访问方式、是否可选、数据匹配模式。组件类型 GUID 与画布中某一个实例的 GUID 不是同一件事，不能混用。复制他人定义后，实例标识也可能变化。

没有组件发现工具时，可通过该环境支持的 GH SDK 只读枚举，或让用户在 GH 中打开定义并检查端口；仍然使用枚举得到的标识。不要凭组件图标、昵称、网上案例或语言模型记忆写入“看起来像”组件 GUID。工具可以执行 Rhino 脚本，也不等于它已经提供了 GH 图操作接口。

实际输入/输出映射表至少像这样：

| 逻辑名 | GH 名称/端口（以实际清单填入） | 类型与访问 | 脚本键 | 输出影响 |
|---|---|---|---|---|
| 板宽 | 实际发现的板宽输入 | Number / Item | `panel_width` | 外轮廓、列数、孔中心 |
| 孔距 X | 实际发现的孔距输入 | Number / Item | `pitch_x` | 列数、孔中心、最小腹板检查 |
| 肋数量 | 实际发现的整数输入 | Integer / Item | `count` | 分支数、中心距 |
| 源曲线 | 实际引用参数 | Curve / List 或 Tree | 已核对 GUID 集 | 路径或边界；不可由文件备注指令替代 |

每次改一个输入，用输出数量、包围盒或几何摘要证明这条连接确实生效。没有影响的控件，要么解释其适用条件，要么移除，不保留虚假的调节功能。

## 4. 数据树是模型结构，不是显示格式

GH 的 DataTree 由路径和每条路径下的有序项组成；路径可稀疏，项里可以有 null。普通 `list[list]` 只在约定层级一致时才能无歧义地代表它，混合路径深度时必须保存实际 `GH_Path`。McNeel：Grasshopper 数据树与 Python。

为每个阶段先写树形状合同。例如多块孔板：

```text
输入面板       {panel}[0]             每板一个闭合外边界
孔中心         {panel;row}[column]    每板、每排、每孔都有稳定位置
孔半径         {panel;row}[column]    与中心完全相同的路径/项数
单板开孔输入   {panel}[hole]          只在每块板内部归并孔环
板实体输出     {panel}[0]             每板一个结果（或明确声明多实体）
```

肋阵列可以使用 `{rib}[0]` 存每根肋的实体与属性。路径必须同时贯穿几何、名称、材料和 feature ID；不要在几何分支改变后仍按旧列表下标分配材料。

| 操作 | 实际改变 | 常见错误 | 正确检查 |
|---|---|---|---|
| Graft | 把已有分支中的项进一步分成分支 | 把配对输入变成大量组合，生成数量暴涨 | 改前后打印路径、项数与预期配对 |
| Flatten | 把树归并为列表，丢掉原分支分组 | 多块板的孔混到一起，Loft 跨越无关零件 | 只在需要的语义层级归并，并保留对应映射 |
| Simplify / Path Mapper | 调整路径共同前缀或路径结构 | 把索引当成不变零件身份，或误合并分支 | 验证转换前后的 feature ID 对应 |
| Item/List/Tree access | 改变一次脚本求解接收到的范围 | 以为接到全树，实际按项反复执行；结果被重复 bake | 输出输入类型、分支统计、求解次数 |
| Null/空分支处理 | 改变有效项或占位结构 | 自动 Cull 后材料/属性错位 | 明确“保留占位”或“整体重建索引”的规则 |

Graft 和 Flatten 的含义有官方 SDK/教程依据；它们并不是遇到报错时轮流试的按钮。DataTree.Graft API、高级数据结构教程。

每一条关键连线应能回答：预期几条分支？各分支多少项？输入按一一配对、广播还是组合？空输入是否允许？输出数量有什么上限？大阵列先用 `2×3` 或三根肋验清结构，再放大规模。

## 5. Range、Domain 与重新参数化

参数域与几何长度分开记录。把曲线域设为 `[0,1]` 不会把曲线缩放成一米，也不保证 `t=0.5` 是弧长中点；曲面 U/V 参数更不等于世界 X/Y 距离。需要等距构件时，用弧长/实际曲面度量求解，不能把均匀参数值直接当等距。

当 n 表示“分段数”并包含两端时，样本数是 n+1；当 n 表示“对象数”时，应直接构造 n 个位置。读取实际组件的端口说明，不仅看昵称 `N`。闭合曲线的起终参数可对应同一点，重复端点要有明确去重规则。

重新参数化前复制输入或明确修改所有权，记录旧域和新域。重新参数化只改变求值映射；它不修复修剪边界、退化面、曲面接缝、翻转方向或不均匀度量。对修剪曲面，落在基础 U/V 矩形内的采样点仍可能位于修剪区域外，需要执行面域/裁剪判断。McNeel 重新参数化曲线示例。

对于孔板和直肋这种公制规则，配套模板直接使用物理尺寸计算位置，避免引入无必要的 UV 假设。拓展到自由曲面时，新增“参数域→实体位置”的独立节点，并测试边界和接缝。

## 6. 配套可执行参数合同

文件位于 `scripts/parametric/`：

- `parametric_contract.py`：纯标准库校验器、稳定依赖排序、内容哈希、解析构建配方及测试用例生成器。
- `parameters.example.json`：可调圆孔板，固定孔距后派生行列数。
- `parameters.ribs.example.json`：独立盒形肋阵列，固定数量后派生中心距。
- `test_parametric_contract.py`：离线行为测试。

在包根目录执行：

```powershell
python .\scripts\parametric\parametric_contract.py schema
python .\scripts\parametric\parametric_contract.py validate .\scripts\parametric\parameters.example.json
python .\scripts\parametric\parametric_contract.py recipe .\scripts\parametric\parameters.example.json --out D:\RhinoWork\panel-r01.recipe.json
python .\scripts\parametric\parametric_contract.py recipe .\scripts\parametric\parameters.ribs.example.json --out D:\RhinoWork\ribs-r01.recipe.json
python .\scripts\parametric\parametric_contract.py cases --kind perforated_panel --out D:\RhinoWork\panel-cases.json
python .\scripts\parametric\parametric_contract.py cases --kind rib_array --out D:\RhinoWork\rib-cases.json
python .\scripts\parametric\test_parametric_contract.py
```

先创建输出目录，使用自己的路径。已有 `--out` 文件不被覆盖。成功退出码为 0；参数/文件错误为 2，并输出 `valid=false` 和可读错误。外部运行无需 Rhino、Grasshopper、pip 包或网络。

合同关键字段：

| 字段 | 规则 |
|---|---|
| `contract_version` | 精确识别 schema 版本；不自动把未知版本当旧格式 |
| `builder.id/version` | 明确选择构造类型和规则版本 |
| `units` | 只接受 `mm/cm/m`；所有长度一起换算，不能夹杂未知单位 |
| `seed` | 必填整数；不依赖全局随机状态或系统时钟 |
| `parameters` | 键集合与类型严格匹配；不接受多余的“无效旋钮” |
| `source` | 可选相对 3dm 路径、SHA-256、GUID 清单；路径和摘要成对提供 |
| `provenance` | bake 批次名和生成标签键；不混入几何输入哈希 |

每个数值先检查类型、有限性和单字段范围，再按精确十进制单位换算。`true` 不会被当成整数 1，`20.0` 不会自动舍入为整数数量，NaN/Infinity 被拒绝。公开 schema 的长度上下界使用米，输入 JSON 仍使用声明的单位。

孔板校验包括：孔距减去两侧最坏随机偏移后仍保留最小腹板、孔边缘与板边界保持最小材料宽度、板中至少能放入一个孔、厚度与板幅合理匹配，以及明确的最多 10,000 个孔配方预算。数量用十进制计算后向下取整，避免尺寸边界因二进制误差突然多出一排。开孔率是按圆面积计算的派生结果；实际实体仍要验证贯通孔和孔数。

肋阵列校验包括：跨度能容纳两端退距和一根肋、数量与厚度之间留足最小净距、随机高度范围保持正值。`count=1` 有明确居中规则，净距标为“不适用”，不会除以零。这里的范围是演示构造的合同，不是结构或加工认证标准。

## 7. Recipe 到原生几何：必须补完最后一段

`recipe` 输出圆孔中心/半径、板轮廓/厚度，或每根肋的盒体 min/max；其中 `path` 和 `item_index` 是显式树结构。它保留解析构造信息，不输出伪装成实体的截图，也没有调用 Rhino。`delivery_state` 会明确标为 `analytic_recipe_only`。

一个可执行的 GH Python 3 肋阵列桥接例子如下。先在实际脚本组件中建立输入 `cfg_json`（String、Item）和 `script_folder`（String、Item），输出 `G`、`feature_ids`、`report`；核对端口的真实配置后再接线。`script_folder` 是解压包内 `scripts/parametric` 的实际目录。

```python
import json
import sys
import Rhino
import System
from Grasshopper import DataTree
from Grasshopper.Kernel.Data import GH_Path

if script_folder not in sys.path:
    sys.path.insert(0, script_folder)
from parametric_contract import build_recipe, UNIT_TO_METERS

cfg = json.loads(cfg_json)
report = build_recipe(cfg)
if report['builder']['id'] != 'rib_array':
    raise ValueError('This native example builds rib_array only')

# 前置检查必须已证明 cfg.units 与目标 Rhino 文档单位一致。
# 配方内部为米，此处转换回已声明、已核对的文档单位。
scale = 1.0 / float(UNIT_TO_METERS[cfg['units']])
G = DataTree[System.Object]()
feature_ids = DataTree[System.Object]()
for feature in report['recipe']['features']:
    lo = Rhino.Geometry.Point3d(*[v * scale for v in feature['min_m']])
    hi = Rhino.Geometry.Point3d(*[v * scale for v in feature['max_m']])
    brep = Rhino.Geometry.Box(Rhino.Geometry.BoundingBox(lo, hi)).ToBrep()
    if brep is None or not brep.IsValid or not brep.IsSolid:
        raise RuntimeError('Invalid rib: ' + feature['id'])
    path = GH_Path(int(feature['path'][0]))
    G.Add(brep, path)
    feature_ids.Add(feature['id'], path)
```

这个示例创建内存中的原生 Brep 供 GH 预览，没有 Bake，也没有改变 Rhino 文档。配套离线测试没有执行这段 Rhino/GH API，必须在目标版本中试跑并记录。修改外部模块后，GH/Python 可能保留 import 缓存；发布正式 builder 版本或重新加载组件/会话，并核对实现文件哈希，不能只改磁盘源码却继续使用旧缓存。

孔板原生 builder 应把外轮廓和圆形内环构成有效平面区域后挤出封闭，或者对完整板实体执行经验证的贯穿布尔切孔。无论哪条路径，都检查孔数、贯通性、闭合性、最小边距和输出实体数量。不要把孔的圆柱体当作已经完成的切孔结果。

## 8. DAG、seed、哈希与重算

合同中显式列出依赖 DAG，并用拓扑排序拒绝未知依赖和循环。参数范围检查成功后才计算派生值。几何 builder 再消费配方，几何通过检查后才能提交 Bake。几何计算失败不能沿用上一轮输出并标为本轮成功。

seed 使用“seed + 稳定 feature ID + 随机通道”的 SHA-256 派生规则。顺序改变不影响同一个 feature 的随机值；增加肋数量时，已有 `rib/0` 等 ID 的高度扰动保持。相同输入和实现得到相同配方；参数变动导致数量或分支变化时，也有稳定身份可比较。随机算法自身的改变需要升级 builder 版本。

输出中区分：

- `parameter_hash`：规范化到米的十进制输入、contract/builder 版本、seed 和源摘要/GUID。等价毫米/米输入得到同一哈希；仅更改 bake 批次名不会改变它。
- `recipe_hash`：实际解析构造数据；用于检查重算输出是否变化。
- `implementation_sha256`：本参数配方模块的源码摘要。
- `native_builder_sha256`：模板设为 null，因为没有替用户生成真实 Rhino/GH builder；完成实际 builder 后，交付 manifest 必须补入真实文件摘要。

源文件字段只是合同声明。需要验证字节时加 `--source-root 交付根目录`；脚本会核对实际文件 SHA-256，但仍明确 `object_guids_checked=false` 和 `geometry_parsed=false`。源对象 GUID 的存在、类型和变化须通过 Rhino 只读检查确认。两个演示 builder 是独立程序式几何，不会自动根据源 3dm 定位或变形；这种依赖要在真实 builder 中明确实现。

不要靠删除缓存“试试看”来解释重算。记录改变了哪个输入、哪些节点应失效、实际重算的 builder 版本、输出数量与哈希，必要时保留前一版与本版差异报告。

## 9. Bake 与交付目录

Bake 使用显式按钮或操作命令，一次成功计算对应一个生成批次。每个 Rhino 对象写入至少：模型实例 ID、run_id、feature_id、parameter_hash、builder_version 和 component_role。另存 `feature_id → Rhino GUID` 映射；相同批次的不确定返回先查询实际对象，再决定是否重试。重算预览与 Bake 超时的处理不可混为一谈。

更新已烘焙方案时，先生成并检查候选对象，确认目标批次范围后才替换/归档该模型实例的旧输出；不按公共图层名删除所有对象。源曲线、手工细部和其他用户对象不因“重新 bake”被误删。Undo 分组、文件副本和重读规则见 [05 运行与交付](05-rhino-runtime-and-delivery.md)。官方 GH Bake 示例说明了几何从 GH 写入 Rhino 文档的过程，但示例不能替代当前平台的目标文档/槽位约定。McNeel 自定义 GhPython Bake 示例。

推荐交付目录：

```text
model-delivery/
  parameters/selected.json       选定方案，不是默认示例
  definition/model.gh            实际可运行定义（若采用 GH）
  builder/build_model.py         实际原生生成器（若采用脚本或 GH 外部模块）
  source/input.3dm               被引用的源几何；纯程序式模型可没有
  manifest.json                 版本、依赖、哈希、单位/原点、参数范围、源 GUID
  outputs/model_r03.3dm          已重读核验的烘焙副本
  outputs/object-map.json        feature ID 与 Rhino GUID 映射
  tests/cases.json               有效、边界、无效参数案例
  tests/recompute-report.json    实际环境下的重算结果
  review/                       多视图与必要截面
  README.md                     同事实际操作步骤与未完成范围
```

没有实际 `.gh` 就不在 manifest 中声称已交付；脚本路线也可以完整参数化，但必须保留可运行的 builder。文件依赖使用相对路径，锁定插件/组件版本，避免只在作者电脑的绝对路径下可运行。原始源文件摘要变了，重新核对引用，不悄悄替换为“相似”几何。

## 10. 验收：至少证明一次真正的参数更新

| 案例 | 预期 |
|---|---|
| 默认参数 | 所有约束通过，实体/孔/肋数量与配方一致 |
| 有效边界 | 单孔、单肋、恰好最小净距等边界明确成立 |
| 无效组合 | 碰孔、超薄边缘、数量过多等在建模前失败并解释字段关系 |
| 单参数变化 | 对应尺寸、数量或形态发生预期变化；无无关对象变化 |
| 相同 seed 重算 | 配方哈希一致；几何在约定容差内一致 |
| 不同 seed | 仅声明的随机通道变化，最小净距仍满足 |
| 保存/重启/重开 | 依赖可找到、输入值保存、仍能重算；烘焙对象可追溯 |

配套 `cases` 命令生成已知有效边界与无效组合，并尝试单字段端点。某个字段的独立最小值可能被跨字段约束禁止，不把它强行标成“有效边界”。这些用例先通过参数校验，再由真实 builder 执行，比较尺寸、数量、几何有效性与实体闭合性。

本次离线测试覆盖两个示例、真实孔中心间距/边距、肋间距、单位等价哈希、seed 重现、数据依赖、来源字节摘要、参数不变性和生成案例。它们不证明 Rhino 布尔操作、GH 数据匹配或 `.gh` 文件已经运行；这部分必须由当前实际工具环境完成并写入 `recompute-report.json`。
