# Rhino 7：可执行兼容通道与建模操作卡

当前1.0.3首次安装/状态验收优先使用[统一操作卡](14-first-run-quickstart.md)。

版本1.0.3。Windows Rhino7 使用本包独立桥接；Rhino8.29+/9继续使用官方 Rhino-MCP-Platform。两条通道共享建模方法和检查/截图/保存模板。本桥不是 McNeel 官方插件，也没有将 Rhino8 内核移植到7。

## 1. 首次接入：不要让模型临时发明桥接

前提：本机已安装并能正常打开、保存模型的正版 Rhino7；Agent 允许本地命令或 stdio MCP。只需本包源码、Windows自带 PowerShell5.1 和 Rhino7内置 IronPython，不需额外 Python、Node、pip、代理或下载插件。Rhino授权和Agent账号仍由已有环境提供。

解压到固定目录后，从包根目录执行：

```powershell
& .\scripts\setup-rhino.ps1 -RhinoVersion 7
& .\scripts\configure-mcp.ps1 -RhinoVersion 7 -OutFile '.\rhino7-mcp.local.json'
```

读取真实回执：`ready`才代表桥接和文档查询成功；`prepared`只代表检查完成。`attach_required`时，把回执中的`command`完整复制到指定 Rhino7 窗口命令栏执行一次，再运行初始化检查。脚本不会关闭正在工作的文档来强制接入。没有Rhino7实例时会尝试启动新空文档；启动时出现授权、模板或插件错误需要先解决，不能把进程ID当成功。已有多个Rhino7时运行专用脚本 `setup-rhino7.ps1 -RhinoPid 实际PID`；配置同样传入该PID。

配置生成的是新片段，合并其中`mcpServers.rhino-cn`到实际宿主的MCP设置；保留其他服务器。宿主若用其他配置结构，应按其界面导入相同command/args，不能整文件覆盖。移动Skill目录后须重新生成路径；不将本机路径、会话token或local配置重新打包上传。

每次重启Rhino7需重新运行初始化；它不修改Rhino永久启动项。重复加载桥接复用已有会话。桥绑定127.0.0.1随机端口，使用每进程令牌，发现文件在`%LOCALAPPDATA%\RhinoShenbi\bridge7`；不得分享到聊天或远程开放端口。配置绑定PID只在该进程存活期间有效，重启后改为新PID或单实例自动发现。

## 2. 固定工具合同

以真实`tools/list`为准。本兼容桥固定提供五项，中文schema随包在`scripts/rhino7/tools.json`。

| 工具 | 用途 | 必需条件 |
|---|---|---|
| `get_context` | Rhino/Python版本、当前文档序号/路径、单位、公差、对象计数、图层 | 首先调用；不要猜文档序号 |
| `run_python` | 在真实Rhino7主线程串行执行RhinoCommon建模 | `expected_document_serial`、`run_id`；`code`与绝对`script_path`二选一；最后设置JSON可序列化的`result` |
| `run_template` | 复用 `inspect`、`capture`、`save` | 文档序号、template、config；config格式见05与模板源码 |
| `get_viewport_image` | 当前视口直接返回MCP PNG图像 | 文档序号，可选width/height（64至2000） |
| `get_request_status` | 查询超时请求的排队/运行/完成状态 | 将上次回执的`id`作为`request_id`参数；截图MCP文本块直接给出request_id |

所有建模脚本都有注入的`__rhino_doc__`及`CONFIG`。使用该句柄，不要自己打开另一份文档后继续旧请求。检查文档序号可防止切错文档，但不代替对象ID/CRC的基线校验。Python异常可能发生在部分对象已经创建之后，具名Undo与`AGENT_RUN_ID`用于核对恢复，不承诺自动事务回滚。

没有MCP但有本地命令的宿主可用：

```powershell
& .\scripts\rhino7\client.ps1 -Method get_context
& .\scripts\rhino7\client.ps1 -Method run_python -ParamsFile 'D:\工作\request.json'
```

JSON请求写UTF-8文件，勿将代码拼进Shell字符串。原生MCP截图能直接交给视觉模型；CLI回执包含base64时，应由宿主解码成PNG并调用其图像查看工具。只有文字推理能力的模型不能把文件存在等同于已看图。

## 3. 通用小样：真实布尔、改参、核验

随包 `scripts/rhino7/parametric_vessel.py` 是可改半径/高度/壁厚的容器示例，创建原生闭合Brep，校验有效性、体积、尺寸；重复同一个instance只替换自己生成的对象。它是技术验收小样，不是所有设计的默认形状。

先从get_context取得实际序号，然后run_python传入：

```json
{
  "expected_document_serial": 1,
  "run_id": "sample-v1",
  "script_path": "D:\\Skills\\rhino-parametric-modeling-cn\\scripts\\rhino7\\parametric_vessel.py",
  "config": {"instance":"sample-body","radius":20,"height":45,"wall":2}
}
```

上面序号和路径是占位示例，必须替换为真实值。第一次在工作副本执行，检查返回`valid/solid/volume/bounds/created_ids`。再改radius=24、height=52，保持instance、使用新run_id，核验原对象被替换且其他对象未变。试wall>=radius时应报错且对象数/CRC不变。不要因为工具成功就省略图像检查。

在其他电脑一键验收：先在Rhino7新建**空白文档并另存为新的3dm**，连接桥接后执行下面命令；输出目录必须尚不存在。脚本自动检查基线、原生布尔、参数重建、非法输入保护、三个角度截图、保存重读和原文件SHA256，生成`smoke-report.json`及新的3dm/PNG。

```powershell
& .\scripts\rhino7\smoke-test.ps1 -OutputDirectory 'D:\Rhino测试\test-001'
```

检查报告结果，并实际打开三张PNG核对是否完整显示容器、开口和底部。有多实例时加`-RhinoPid 实际PID`；失败时保留回执和当前测试场景，从失败项定位，不直接重复整批。

## 4. IronPython2.7写法卡

- 用`.format()`，禁止f-string、类型注解、dataclass、async/await、pathlib；禁用默认假定numpy/scipy可导入的方案。外部Python3可以算参数/拓扑并写JSON，真实Brep/布尔/曲面编辑在Rhino7执行。
- 源码第一行`# -*- coding: utf-8 -*-`；中文路径作为Unicode传递；用浮点分子或`from __future__ import division`避免整数除法误差。
- 显式`Rhino.Geometry.Point3d/Vector3d/Plane/Interval`，必要时`System.Collections.Generic.List[Rhino.Geometry.Curve]`匹配.NET重载；不要把Python点列表直接冒充曲线。
- 建几何先在内存进行，检查返回None/空数组、`IsValid`、目标尺寸与闭合意图，再Add进文档。布尔或Join返回多个部分时逐一判断，不盲取[0]。
- GUID用`System.Guid`解析；JSON只返回str/int/float/bool/list/dict。不能直接返回Brep、Bitmap或.NET对象。有限值与跨参数条件必须在写入前验证。
- 带面有三角/梯形/折板截面时建立真实截面与稳定局部标架后Sweep/Loft，不能只画彩色曲线。先让主形、共享边、合流逻辑成立，再铺细节。
- NURBS、解析实体、Rhino7支持的SubD和网格按意图选择。ShrinkWrap等仅新版本提供的命令不能硬调用；如果网格重建替代不能满足公差/可编辑性，应说明缺口或使用合适Rhino版本，不能悄悄降质。
- Grasshopper7使用该机实际可用组件与GhPython引擎；本桥没有移植官方GH工具，也不自动把Python3 GH定义变成7可用定义。检查依赖后按10章建立/验证可重算定义。

## 5. 质量流程在Rhino7同样执行

1. 读基线：锁定文档、单位/公差、目标对象与保留集合。新增模型先把空工作文档另存到新的工作路径；保存模板需要真实文档路径和独立干净基线。
2. 定参数、局部坐标和依赖：把已知、推断、参考图冲突分开记录。多个角度定主轮廓/开口/比例，不能照单张透视扭曲三维几何。
3. 先骨架和主形；只做最难截面/接缝的小样。用顶/正/侧/两侧透视和关键剖面验证；曲线平滑靠连续性、控制点和曲率，不靠密网格掩盖。
4. 主形成立后生成次级带面、分格、玻璃、结构/内衬；避开孔洞、边缘和真实接口，按feature_id管理依赖重建。
5. 用固定camera/target/up/bounds重复截图比对；`capture`模板恢复原视图及可见性。顶视up通常[0,1,0]。反向侧和底面也要检查，不能仅保留好看的角度。
6. 核验典型参数、边界、非法输入、数量改变；另存副本并重读3dm，核对保留集合和新对象。保存模板只适合“干净基线+新增批次”；原位编辑/复杂块/布局需要05章对应策略。

## 6. 故障恢复表

| 回执/现象 | 下一步 |
|---|---|
| 无session/connection refused | 确认Rhino7已启动，在正确窗口执行初始化回执command，再get_context；不要把9876旧桥当本桥 |
| 多实例 | 选择实际目标PID并核对文档路径；不默认第一项 |
| 文档序号/路径不匹配 | 重新get_context与目标对象检查；不自动把守卫改成新值后直接写入 |
| SyntaxError | 在Rhino7实际引擎编译失败，先改Python2写法；桥接在执行前编译，正常情况下该次未添加几何 |
| failed_partial_possible | inspect对象ID/标签/CRC，决定局部补齐或具名Undo；异常不等于没执行 |
| unknown/超时 | 查询同一request_id；pending继续等待，completed读取原结果。不要换ID重放。桥重启丢失内存账本，需检查文档/文件状态 |
| 截图空白/遮挡 | 检查真实视口、可见性、相机和模型范围；连接成功与图像有效是两个验收点 |
| 保存后对象缺失 | 确认run_id及保存范围，核对重读报告；不能覆盖原文件掩盖问题 |

客户端不自动重发写入；同一连接会话内，同一request_id和相同参数最多执行一次，改变参数重用ID将报错。4096条请求后保留账本并拒绝新任务，需核对状态后重新启动Rhino/桥接，不删除账本后盲目续写。

实际版本依据：Rhino.Python官方说明、Windows启动参数。实际验证结果和未覆盖范围见`VALIDATION.md`，不能用本操作卡代替实测。
