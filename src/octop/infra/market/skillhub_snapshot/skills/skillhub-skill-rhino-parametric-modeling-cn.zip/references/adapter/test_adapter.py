"""Offline transport tests. Only localhost mock servers; never touches Rhino."""
import base64
import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

import rhino_stdio_adapter as adapter

TOOLS = [
    {"name": "run_python", "description": "Execute official Python", "inputSchema": {
        "type": "object", "properties": {"script": {"type": "string"}}, "required": ["script"]},
     "annotations": {"readOnlyHint": False, "destructiveHint": True}},
    {"name": "get_context", "description": "Snapshot", "inputSchema": {"type": "object", "properties": {}}},
]


class MockOfficial:
    def __enter__(self):
        self.requests, self.behavior = [], None
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                message = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                owner.requests.append(message)
                if owner.behavior:
                    result = owner.behavior(message)
                else:
                    result = None
                method = message["method"]
                if result is None:
                    if method == "initialize":
                        result = {"protocolVersion": adapter.PROTOCOL, "serverInfo": {"name": "rhino-mcp", "version": "0.1.5"}, "capabilities": {"tools": {}, "resources": {}}}
                    elif method == "tools/list":
                        result = {"tools": TOOLS}
                    elif method == "tools/call":
                        result = {"content": [{"type": "text", "text": json.dumps({"stdout": message["params"]["arguments"]["script"], "error": None})}]}
                    else:
                        result = {}
                if message.get("id") is None:
                    self.send_response(204)
                    self.end_headers()
                    return
                if isinstance(result, tuple):
                    key, result = result
                else:
                    key = "result"
                payload = json.dumps({"jsonrpc": "2.0", "id": message["id"], key: result}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                try:
                    self.wfile.write(payload)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.url = "http://127.0.0.1:%d/" % self.server.server_port
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()


class AdapterTests(unittest.TestCase):
    def test_root_loopback_only(self):
        for bad in ("http://example.com:10500/", "http://127.0.0.1:10500/agent", "http://127.0.0.1:10500/mcp", "http://u:p@localhost:10500/", "https://localhost:10500/", "http://0.0.0.0:10500/", "http://localhost:10500/?x=1"):
            with self.subTest(url=bad), self.assertRaises(adapter.AdapterError):
                adapter.normalized_url(bad)
        self.assertEqual(adapter.normalized_url("http://localhost:10500"), "http://localhost:10500/")
        self.assertEqual(adapter.normalized_url("http://[::1]:10500/"), "http://[::1]:10500/")

    def test_initialize_ping_and_exact_schema(self):
        with MockOfficial() as server:
            client = adapter.OfficialHTTP(server.url)
            client.ready()
            self.assertEqual(client.rpc("ping")["result"], {})
            tools = client.list_tools()["result"]["tools"]
            self.assertEqual(tools[0]["inputSchema"], TOOLS[0]["inputSchema"])
            self.assertEqual(tools[0]["annotations"], TOOLS[0]["annotations"])
            self.assertIn("__rhino_doc__", tools[0]["description"])
            self.assertEqual(client.list_tools(chinese=False)["result"]["tools"], TOOLS)

    def test_wrong_server_rejected(self):
        with MockOfficial() as server:
            server.behavior = lambda m: {"serverInfo": {"name": "rhino7-bridge"}, "protocolVersion": adapter.PROTOCOL} if m["method"] == "initialize" else None
            with self.assertRaisesRegex(adapter.AdapterError, "不是已审计官方"):
                adapter.OfficialHTTP(server.url).ready()

    def test_wrong_protocol_rejected(self):
        with MockOfficial() as server:
            server.behavior = lambda m: {"serverInfo": {"name": "rhino-mcp"}, "protocolVersion": "2099-01-01"} if m["method"] == "initialize" else None
            with self.assertRaisesRegex(adapter.AdapterError, "协议"):
                adapter.OfficialHTTP(server.url).ready()

    def test_unknown_tool_never_forwarded(self):
        with MockOfficial() as server:
            client = adapter.OfficialHTTP(server.url)
            client.ready()
            with self.assertRaises(adapter.AdapterError):
                client.call("create_magic_stadium", {})
            self.assertNotIn("tools/call", [r["method"] for r in server.requests])

    def test_tool_name_must_be_string(self):
        with self.assertRaises(adapter.AdapterError):
            adapter.OfficialHTTP("http://localhost:10500/").call({}, {})

    def test_image_content_preserved_and_artifact_written(self):
        raw = b"fake-image-bytes"
        content = {"content": [{"type": "image", "mimeType": "image/png", "data": base64.b64encode(raw).decode()}, {"type": "text", "text": "保留说明"}]}
        with MockOfficial() as server, tempfile.TemporaryDirectory() as folder:
            server.behavior = lambda m: content if m["method"] == "tools/call" else None
            client = adapter.OfficialHTTP(server.url)
            client.ready()
            response = client.call("run_python", {"script": "pass"})
            self.assertEqual(response["result"], content)
            report = adapter.write_artifacts(response, folder)
            self.assertEqual(Path(report["files"][0]).read_bytes(), raw)
            self.assertEqual(json.loads(Path(report["report"]).read_text("utf-8")), response)
            second = adapter.write_artifacts(response, folder)
            self.assertNotEqual(report["report"], second["report"])

    def test_upstream_errors_preserved(self):
        with MockOfficial() as server:
            server.behavior = lambda m: ("error", {"code": -32602, "message": "official error", "data": {"x": 1}}) if m["method"] == "tools/call" else None
            client = adapter.OfficialHTTP(server.url)
            client.ready()
            result = client.call("run_python", {"script": "pass"}, "abc")
            self.assertEqual(result["id"], "abc")
            self.assertEqual(result["error"]["data"], {"x": 1})

    def test_timeout_never_retries_tool(self):
        with MockOfficial() as server:
            def behavior(message):
                if message["method"] == "tools/call":
                    time.sleep(.12)
                return None
            server.behavior = behavior
            client = adapter.OfficialHTTP(server.url, .03)
            client.ready()
            with self.assertRaises(adapter.AdapterError) as caught:
                client.call("run_python", {"script": "pass"})
            self.assertEqual(caught.exception.data["executionState"], "unknown")
            self.assertFalse(caught.exception.data["automaticRetry"])
            self.assertEqual(sum(r["method"] == "tools/call" for r in server.requests), 1)

    def test_announcements_filter_and_read_only(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for version, pid in (("8", 801), ("9", 901), ("7", 701)):
                (root / (version + ".json")).write_text(json.dumps({"v": 1, "pid": pid, "port": 10500 + pid, "version": version}))
            (root / "invalid.json").write_text("no json")
            before = {p.name: p.read_bytes() for p in root.iterdir()}
            self.assertEqual(len(adapter.announcements(root)), 2)
            self.assertEqual(adapter.announcements(root, 901)[0]["version"], "9")
            self.assertEqual(before, {p.name: p.read_bytes() for p in root.iterdir()})

    def test_ambiguous_listener_refuses_selection(self):
        with MockOfficial() as a, MockOfficial() as b, tempfile.TemporaryDirectory() as folder:
            for index, server in enumerate((a, b)):
                Path(folder, "%d.json" % index).write_text(json.dumps({"v": 1, "pid": index + 1, "port": server.server.server_port, "version": "8"}))
            args = adapter.parser().parse_args(["probe", "--listener-dir", folder])
            with self.assertRaisesRegex(adapter.AdapterError, "数量为 2"):
                adapter.connect(args)
            self.assertEqual(len(list(Path(folder).glob("*.json"))), 2)

    def test_stdio_lifecycle_serial_and_clean_stdout(self):
        with MockOfficial() as server:
            messages = [
                {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": adapter.PROTOCOL}},
                {"jsonrpc": "2.0", "method": "notifications/initialized"},
                {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
                {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "run_python", "arguments": {"script": "print('中文')"}}},
                {"jsonrpc": "2.0", "id": 4, "method": "ping"},
            ]
            process = subprocess.run([sys.executable, str(Path(adapter.__file__)), "stdio", "--url", server.url], input="\n".join(json.dumps(m) for m in messages) + "\n", text=True, encoding="utf-8", capture_output=True, timeout=10)
            self.assertEqual(process.returncode, 0, process.stderr)
            responses = [json.loads(line) for line in process.stdout.splitlines()]
            self.assertEqual([r["id"] for r in responses], [1, 2, 3, 4])
            self.assertEqual([m["method"] for m in server.requests], ["initialize", "notifications/initialized", "tools/list", "tools/call", "ping"])

    def test_stdio_invalid_input_stays_usable(self):
        args = adapter.parser().parse_args(["stdio", "--url", "http://localhost:10500/"])
        output = io.StringIO()
        with patch("sys.stdin", io.StringIO("bad-json\n[]\n")), contextlib.redirect_stdout(output):
            adapter.stdio(args)
        self.assertEqual([json.loads(x)["error"]["code"] for x in output.getvalue().splitlines()], [-32700, -32600])

    def test_tools_call_requires_initialize(self):
        client = adapter.OfficialHTTP("http://localhost:10500/")
        with self.assertRaisesRegex(adapter.AdapterError, "initialize"):
            adapter.handle(client, {"jsonrpc": "2.0", "id": 1, "method": "tools/list"})

    def test_cli_script_unicode_and_nested_script_failure(self):
        with MockOfficial() as server, tempfile.TemporaryDirectory() as folder:
            source = Path(folder, "测试.py")
            source.write_text("print('测试')\n", encoding="utf-8")
            server.behavior = lambda m: {"content": [{"type": "text", "text": '{"stdout":"","error":"Traceback failed"}'}]} if m["method"] == "tools/call" else None
            proc = subprocess.run([sys.executable, str(Path(adapter.__file__)), "run-python", "--url", server.url, "--script-file", str(source), "--out", folder], capture_output=True, text=True, encoding="utf-8", timeout=10)
            self.assertEqual(proc.returncode, 1, proc.stderr)
            self.assertFalse(json.loads(proc.stdout)["ok"])
            call = [r for r in server.requests if r["method"] == "tools/call"][0]
            self.assertEqual(call["params"]["arguments"]["script"], source.read_text("utf-8"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
