# 首次使用：一个 Skill 完成环境准备

当前1.0.3首次安装/状态验收优先使用[统一操作卡](14-first-run-quickstart.md)。

版本 **1.0.3（修复版）**。这是可独立分发的 SkillHub 自动初始化版：只下载这一个 Skill，不需要向发布者索取附件。建模经验、全部参考章、参数合同、模型执行脚本、模板与中文适配器完整保留。

## Agent 第一次使用时执行

1. 检查用户已有的 Rhino 与宿主：支持Windows **Rhino7、Rhino8.29+或Rhino9**，以及支持本地MCP/命令的agent。**如果是Rhino7，直接转[13操作卡](13-rhino7-ready-workflow.md)，不要继续本节的官方插件步骤**。Rhino商业软件、许可证和模型账号由已有环境提供；云端聊天页面无法直接访问本机Rhino。
2. 若用户已经要求启用Rhino建模且所需初始化在已授权范围内，按实际Rhino版本执行下列初始化命令。已安装的官方插件会复用；缺少时脚本自动获取固定版本的官方安装包、核验，再调用Rhino自带Yak安装。
3. 读取命令真实回执。`Prepared` 只说明插件缓存已经准备，`Installed` 只说明Yak返回成功；都不能代替Rhino加载和MCP握手验收。首次安装后提示用户在保存工作后重启Rhino，不能擅自关闭未保存的工程。
4. 在Rhino运行 `MCPConnect`，按 [00 接入](00-install-and-domestic-agents.md) 生成/合并MCP配置；用真实 `tools/list` 与只读文档查询验证。已有宿主账号和其他工具配置必须保留。需要的Rhino内部ScriptEditor Python3首次初始化仍按实际提示完成。
5. 在测试副本完成小样生成→查询→截图→保存重读，再开始目标建模。准备好后继续本技能的形体、结构、细节与多视图迭代流程。

在解压后的技能目录执行：

```powershell
# Rhino7：本包兼容桥，不下载Yak或外部Python
& .\scripts\setup-rhino.ps1 -RhinoVersion 7

# Rhino 8.29+
& .\scripts\setup-rhino.ps1 -RhinoVersion 8

# Rhino 9：只有使用9时运行
& .\scripts\setup-rhino.ps1 -RhinoVersion 9

# Rhino不在默认安装路径时
& .\scripts\setup-rhino.ps1 -RhinoVersion 8 -RhinoSystem 'D:\应用\Rhino 8\System'
```

默认缓存在用户 `LOCALAPPDATA` 下的 `RhinoParametricSkill/plugin-v0.1.5`，无需写入安装好的技能目录。以后命中正确缓存会复用；已有插件不会自动降级或替换。损坏缓存会明确报错并保留现场，不静默覆盖。

```powershell
# 只检查拟执行动作，不联网、不创建缓存、不安装
& .\scripts\setup-rhino.ps1 -RhinoVersion 8 -WhatIf

# 自动下载并校验，但暂不调用Yak安装
& .\scripts\setup-rhino.ps1 -RhinoVersion 8 -PrepareOnly
```

只需要正常初始化时，不必先运行两个可选命令。脚本不修改整机执行策略；若宿主不允许运行PS1，需要按公司的脚本策略配置能力，不能把策略拦截报成已安装。

## 分发范围

本上传包仅含可读文本、脚本和许可，不嵌入二进制依赖。完整保留建模流程，必要插件由初始化脚本从目标软件官方文件服务下载并校验；不采用改后缀、分卷或隐蔽编码。

缺少插件和缓存时首次需要联网；运行环境准备后不需反复下载。平台实际文件限制和审核结果以提交时要求为准。

## 下载来源与完整性

固定准备官方插件 **0.1.5**，不会追随 `latest` 造成能力漂移。依赖通过目标软件官方文件服务直接获取，具体机器下载地址见资产清单。具体URL、大小、SHA256和固定依赖信息均见 [资产清单](../vendor/official/assets.json)。

本次在关闭HTTP代理的下载客户端中，两份Windows版本均首试HTTP200获取，大小和完整SHA256与此前官方原件一致；另核对Rhino8的119个内部文件及Rhino9的118个内部文件，全部相同。证据见 [下载验证记录](../tests/official-download-verification.json)。另外，正式 `setup-rhino.ps1` 的 `-PrepareOnly` 在PowerShell5.1和7下分别实际下载了Rhino8/9原件，均返回Prepared、哈希一致且无临时残留；这里的Rhino身份是隔离模拟对象，没有调用真实Yak安装。见 [脚本下载验证](../tests/setup-download-verification.json)。这证明本机本次无HTTP代理下载成功，不保证所有用户网络都能访问。

初始化使用Windows PowerShell与.NET，不要求另装Python、Node、pip或npm；只从固定HTTPS官方地址获取安装包，保持证书验证、大小上限与SHA256校验。部分下载先写入临时文件，校验通过才发布到缓存。不会执行远程脚本文本，不会关闭证书校验或转向未知代理镜像。

若网络失败，应报告实际错误；没有已校验的完整文件就不能继续安装。若Yak返回未知或失败状态，应先读取本机插件状态，不能反复重放安装。Rhino本体、ScriptEditor首次依赖初始化、宿主或模型服务可能有各自网络要求，与插件下载分开说明。

## 维护与测试

`scripts/install-offline.ps1` 仍保留，可由初始化脚本传入 `-AssetDirectory` 指向已经校验的缓存，执行同一官方Yak安装流程。它不自行下载。`scripts/configure-mcp.ps1` 和建模执行脚本继续使用原工作流。

`tests/verification.json` 记录实际脚本测试。`tests/test_setup_rhino.py` 使用隔离的模拟Rhino/Yak测试初始化；真实官方文件下载另有上面的独立记录。

要核对两份已下载原件并跑完整测试，可设置环境变量后执行：

```powershell
$env:RHINO_SKILL_TEST_ASSET_DIR = 'D:\已校验的官方插件缓存'
python tests/run_checks.py --out NEW_REPORT.json
```

没有两份缓存时相关原件检查会显示跳过，不得把跳过算成通过。重新打包时只上传本配置的文本/脚本文件；不要把运行后缓存或测试下载的Yak装回Skill ZIP。上传时填写版本 **1.0.3**。
