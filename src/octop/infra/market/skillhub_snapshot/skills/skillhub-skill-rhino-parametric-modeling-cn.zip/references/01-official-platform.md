# 官方 Rhino-MCP-Platform 接入核对

核对日期：2026-09-08。官方来源是 目标软件开发者提供的接口源码，项目 README 标题为 Rhino MCP Platform，Rhino 包名为 `Rhino-MCP-Platform`。这不是第三方同名 Rhino MCP 仓库。

## 版本与验证边界

| 项目 | 本包采用的依据 | 能确认的范围 |
|---|---|---|
| 主分支源码 | 固定 commit `4109116e3ea2cfd62859fd150b5f4331b93f45b5` | 当前 router、插件外部端点与工具注册合同 |
| 首次初始化获取的稳定插件 | 官方 release `plugin-v0.1.5`，commit `7f079d27199f1690143b9229db80b25ba38915be`，Windows Rhino 8/9 Yak | 已核对 tag 源码的端口、公告、握手、run_python 参数兼容；二进制安装与资产哈希见包内清单 |
| 可选 Python 适配器 | 本包 adapter/rhino_stdio_adapter.py | 15 项 localhost mock 测试通过；不是 McNeel 官方发布组件 |
| 真实 Rhino 8/9 | 官方支持范围 | 使用官方router与实际工具schema |
| 本包 Rhino7 通道 | 随包独立IronPython桥+PowerShell stdio | 见[13操作卡](13-rhino7-ready-workflow.md)；与官方8/9协议分开，不能冒充官方插件验证 |

Rhino 8 与 Rhino 9（WIP/BETA 包依实际安装版本）是官方安装指南提供的版本。固定 Rhino 8 包名带 `rh8_29`，安装时应满足该包的版本要求。不要把“Rhino 8”解释成任何早期 8.x 均已验证。官方安装指南源码

## 优先走官方自带 stdio router

官方平台已经提供 `rhino-mcp-router`。路由器通过 stdin/stdout 与代理通信，通过本机 HTTP 与 Rhino 文档监听器通信；负责实例选择、启动、状态数据库和恢复。国产代理能配置 MCP stdio 进程时，直接指向这个可执行文件即可，无需另搭 HTTP 桥。官方 router README、stdio 注册代码

Windows router 使用 .NET 8 framework-dependent 单文件发布，依赖 Rhino 在 Windows 上安装的 .NET 运行时，并设置 RollForward=Major；不能将它描述为无运行时依赖。macOS 源码采用 NativeAOT 发布，但本包初始化脚本准备的是 Windows Yak，不包含 macOS 资产。可选 Python 适配器需要 Python 3.10+ 标准库。官方 Router.csproj

在 Rhino 中安装官方包后运行 `MCPConnect`，复制其实际 router 路径。示意配置：

```json
{
  "mcpServers": {
    "rhino": {
      "command": "C:/实际路径/rhino-mcp-router.exe",
      "args": ["--default-version", "8"]
    }
  }
}
```

`--default-version` 可选 8 或 9。可执行文件跟随插件放在相对目录 `../router/<rid>/rhino-mcp-router.exe`；Windows 常见 `<rid>` 为 `win-x64`。不要硬编码开发者电脑路径，也不要假设 PATH 已有该命令。官方配置生成器

官方 router 工具还包含实例管理/路由上下文，其工具参数未必和单实例插件 HTTP 端点完全相同。本技能任何调用都必须先读取**当前连接的** `tools/list`，不能将一个接口的 schema 套用到另一个接口。

`MCPConnect` 用于查看/配置连接，不等同于启动目标文档 HTTP 监听器。使用本包可选适配器时，在目标文档运行 `MCPStart`，核对其实际地址后再 `probe`；官方 router 则有自己的实例管理路径。MCPConnectCommand.cs、MCPStartCommand.cs

## 可选单实例 HTTP 接入的精确合同

| 要素 | 已审计实现 |
|---|---|
| 监听地址 | Kestrel `ListenLocalhost(port)` |
| 外部端点 | `http://localhost:<port>/`，JSON POST |
| 起始端口 | 默认 10500；多文档/实例递增或显式指定，因此不是恒定端口 |
| 主分支 `/agent` | Rhino AI 内部面板过滤端点，外部代理不应接入 |
| 握手 serverInfo.name | `rhino-mcp` |
| 插件握手 protocolVersion | `2024-11-05` |
| 消息模型 | JSON-RPC 2.0，请求/响应；通知通常 HTTP 204 |
| SSE | 该插件源代码明确不实现 Streamable-HTTP SSE 通道，不能把它宣传为全功能 SSE 服务 |
| 方法 | initialize、notifications/initialized、notifications/cancelled、ping、tools/list、tools/call、resources/list、resources/templates/list、resources/read |

依据：McpServer.cs、McpEndpoint.cs、Protocol.cs。

插件写入 `<pid>-<port>.json` 公告，字段为 `{"v":1,"pid":整数,"port":整数,"version":"8或9"}`。Windows 默认目录 `%LOCALAPPDATA%/McNeel/rhino-mcp/listeners`；设定 `RHINO_MCP_HOME` 后则使用 `<该变量>/rhino-mcp/listeners`。目录依据实际函数，不能照抄旧注释中的 temp 路径。RouterPaths.cs、RhinoAIHost.cs

可选适配器只读取公告，通过 initialize/ping 判定响应；不会管理 router 的 SQLite 数据库，不会删除公告，也不提供多实例恢复。一个监听器超时后不会自动转接另一份模型。

## 稳定 0.1.5 与主分支差异

已直接读取 `plugin-v0.1.5` 标签的 `McpServer.cs`、`Server/McpEndpoint.cs`、`Server/Protocol.cs`、`RhMcpHost.cs`、`router/RouterPaths.cs` 和 `Tools/RunPythonTool.cs`。上述外部根地址、10500 起点、公告字段/目录、服务名、2024-11-05 协议、run_python 的 script 参数均保持兼容。稳定版主机源文件名是 `RhMcpHost.cs`，主分支已改为 `RhinoAIHost.cs`，这是文件组织差异。稳定标签、稳定主机实现

稳定版 `run_python` 将脚本输出序列化为 JSON 文本 `{stdout,error}` 放入 MCP content；脚本失败可能不以 `result.isError` 标记。适配器 CLI 会同时识别该内层 error，但 stdio 继续原样传递官方结果。主分支已改用脚本执行结果对象，因此业务验收不能只看 HTTP 200。稳定 RunPythonTool.cs、主分支 RunPythonTool.cs

## 工具能力必须实时发现

插件工具由源码注册器生成。适配器保留 `name`、`inputSchema`、`annotations`，只给已知工具加入固定中文摘要，未发现的名称拒绝调用。常见名称包括 `get_context`、`list_objects`、`get_selection`、`get_viewport_image`、`set_camera`、`run_python`、`run_csharp`、`run_command`、`open_doc`、`save_doc`，是否存在以及参数都应以当前 tools/list 为准。Grasshopper 1/2 的可用能力还取决于安装的 Rhino/插件版本，不应预先承诺所有 `g1_*`/`g2_*` 工具可用。

官方 `run_python` 运行 Python 3，提供文档句柄 `__rhino_doc__`。直接操作这个文档对象；不能照搬第三方 Rhino 7 桥的 `scriptcontext.doc`、`rhinoscriptsyntax` 或 `execute_code` 合同。官方脚本工具

`get_viewport_image` 返回真实视口内容，用于逐步比对参考图；它不是图片生成接口。精准造型、闭合/法线/尺寸/拓扑验收和隐藏面的合理补完仍属于建模流程，不由 MCP 连接本身保证。

## 协议、许可证与测试依据

标准 stdio 采用每行 JSON-RPC 消息，stdout 不可混入日志；日志可写 stderr。本包实现遵循该传输要求，并显式保留插件实际返回的协议版本。MCP 2024-11-05 传输规范

McNeel 仓库采用 MIT，版权声明为 `Copyright (c) 2026 Robert McNeel & Associates`。随官方资产分发时应保留对应许可文件和来源，不能将本中文技能包标为 McNeel 官方认证。官方 LICENSE

本次自动测试仅向 localhost 临时 mock 服务发送请求，未启动/配置 Rhino，未编辑任何模型。测试命令：`python -m unittest discover -s adapter -p test_adapter.py -v`，15 项通过。模型验收和具体代理可用性需要在目标电脑完成，不能由源码审计推导成已实测。
