import io,json,time,threading,unittest
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from unittest.mock import patch
import rhino_stdio_adapter as a

class FirstRun(unittest.TestCase):
    def test_drip_headers_have_total_deadline(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']))
                try:
                    self.connection.sendall(b'HTTP/1.1 200 OK\r\nX-Slow: ')
                    for _ in range(40):self.connection.sendall(b'x');time.sleep(.03)
                    self.connection.sendall(b'\r\nContent-Length: 0\r\n\r\n')
                except OSError:pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            c=a.OfficialHTTP('http://127.0.0.1:%d'%server.server_port,timeout=.15)
            started=time.monotonic()
            with self.assertRaises(a.AdapterError) as caught:c.rpc('tools/call',{'name':'example'})
            self.assertLess(time.monotonic()-started,.65)
            self.assertEqual(caught.exception.data['executionState'],'unknown')
        finally:server.shutdown();server.server_close()
    def test_sse_rejected_before_read(self):
        class Response:
            status=200
            headers={'Content-Type':'text/event-stream'}
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,*args):raise AssertionError('SSE body must not be read')
        c=a.OfficialHTTP('http://127.0.0.1:10000')
        with patch.object(c.opener,'open',return_value=Response()):
            with self.assertRaisesRegex(a.AdapterError,'SSE'):c.rpc('ping')

    def test_supported_protocol_negotiated(self):
        for version in ('2024-11-05','2025-03-26','2025-06-18'):
            c=a.OfficialHTTP('http://127.0.0.1:10000')
            def reply(method,params=None,request_id=None):
                return {'jsonrpc':'2.0','id':request_id,'result':{'protocolVersion':version,'serverInfo':{'name':'rhino-mcp','version':'test'},'capabilities':{}}}
            with patch.object(c,'rpc',side_effect=reply):
                self.assertEqual(c.initialize({'protocolVersion':version})['result']['protocolVersion'],version)

    def test_drip_response_has_total_deadline_and_unknown_write(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                self.rfile.read(int(self.headers['Content-Length']))
                self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length','1000');self.end_headers()
                try:
                    for _ in range(40):self.wfile.write(b' ');self.wfile.flush();time.sleep(.03)
                except OSError:pass
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        try:
            c=a.OfficialHTTP('http://127.0.0.1:%d'%server.server_port,timeout=.15)
            started=time.monotonic()
            with self.assertRaises(a.AdapterError) as caught:c.rpc('tools/call',{'name':'example'})
            self.assertLess(time.monotonic()-started,.65)
            self.assertEqual(caught.exception.data['executionState'],'unknown')
        finally:server.shutdown();server.server_close()

    def test_discovery_retains_failure_diagnostics_and_budget(self):
        args=type('Args',(),dict(url=None,timeout=.05,listener_dir='unused',pid=None))()
        candidates=[{'url':'http://127.0.0.1:10000','pid':1}]*3
        def fail(client):time.sleep(.03);raise a.AdapterError('wrong protocol')
        with patch.object(a,'announcements',return_value=candidates),patch.object(a.OfficialHTTP,'initialize',fail):
            with self.assertRaises(a.AdapterError) as caught:a.connect(args)
        self.assertIn('probeErrors',caught.exception.data)
        self.assertLess(len(caught.exception.data['probeErrors']),3)

if __name__=='__main__':unittest.main()
