# 官方 Rhino HTTP 的可选便携适配器

当前1.0.2首次安装/状态验收优先使用[统一操作卡](../references/14-first-run-quickstart.md)。

优先使用官方 `rhino-mcp-router.exe` 的 stdio 接口。官方 router 已提供多实例路由、实例启动及恢复；国产代理只要能配置标准 MCP stdio 服务，就可以直接使用它，并不需要先支持 HTTP。本目录提供 Python 单实例适配器，供需要中文工具摘要、命令行结果落盘，或暂时不能使用官方 router 的宿主选择。

本适配器 1.2.0 由本技能包提供，不是 McNeel 官方程序。它只连接正在运行的**官方 Rhino 8 / Rhino 9** 外部 HTTP 监听器，不安装插件、不启动或关闭 Rhino、不修改代理配置。本机的 Rhino 7 兼容链属于另一套第三方桥，不能视为官方平台验证。

## 运行条件

- 已安装并运行 Rhino 8 或 Rhino 9 和官方 Rhino-MCP-Platform。首次初始化固定获取的官方资产为 0.1.5；Rhino 8 文件名包含 `rh8_29`，应按该包的 Rhino 版本要求安装。
- 已在目标文档中运行官方 `MCPStart`，确认打印的本机地址。
- Python 3.10 或更高版本。本目录只使用 Python 标准库，不需要 pip、Node、联网安装或 API Key。
- 官方 router 主路径不需要 Python。Windows router 是 framework-dependent 程序，依赖 Rhino 安装的 .NET 8（允许向更高主版本滚动）；“无需 Python/npm/pip”不代表没有运行时要求。插件安装、离线分发和通用代理配置见包根目录说明。

## 五个命令

以下从技能包根目录运行。Windows 可将 `python` 换为已安装 Python 的完整路径，所有示例目录需要换为自己的目录。端口 10500 是起始默认值，必须以本机实际端口为准。

```powershell
python adapter/rhino_stdio_adapter.py probe --url http://127.0.0.1:10500/
python adapter/rhino_stdio_adapter.py tools --url http://127.0.0.1:10500/ --out C:/RhinoWork/capabilities
python adapter/rhino_stdio_adapter.py stdio --url http://127.0.0.1:10500/
python adapter/rhino_stdio_adapter.py call --url http://127.0.0.1:10500/ --name get_context --arguments-file C:/RhinoWork/context-args.json --out C:/RhinoWork/results
python adapter/rhino_stdio_adapter.py run-python --url http://127.0.0.1:10500/ --script-file C:/RhinoWork/inspect.py --out C:/RhinoWork/results
```

`context-args.json` 可以先写 `{}`，实际可用参数以 `tools` 输出中的 `get_context.inputSchema` 为准。`run-python` 读取 UTF-8 脚本，先确认 `run_python` 存在，再传递 `{"script":"完整脚本文本"}`；不会把本机文件路径错误地当作脚本内容。插件中的 Python 3 必须使用注入的 `__rhino_doc__` 作为文档句柄。

最小只读脚本 `inspect.py`：

```python
import json
doc = __rhino_doc__
print(json.dumps({"name": doc.Name, "units": str(doc.ModelUnitSystem),
                  "objects": doc.Objects.Count}, ensure_ascii=False))
```

适配器不会隐式注入建模 CONFIG。需要包内建模检查脚本时，使用该脚本约定的 CONFIG 包装入口，参见 [Rhino 运行与交付](../references/05-rhino-runtime-and-delivery.md)。

## 国产代理中的 stdio 配置

优先使用官方 `MCPConnect` 给出的 router 完整路径：

```json
{"mcpServers":{"rhino":{"command":"C:/实际安装路径/rhino-mcp-router.exe","args":["--default-version","8"]}}}
```

需要此适配器时，配置形状如下。不同宿主外层键可能不同，`command` 和 `args` 应作为独立字段，不要拼成含引号的 shell 字符串。

```json
{
  "mcpServers": {
    "rhino": {
      "command": "C:/Python311/python.exe",
      "args": [
        "C:/RhinoSkills/rhino-parametric-modeling-cn/adapter/rhino_stdio_adapter.py",
        "stdio", "--url", "http://127.0.0.1:10500/"
      ]
    }
  }
}
```

工具名不添加适配器别名。宿主界面可能自动显示类似 `mcp__rhino__run_python` 的前缀，那是宿主命名空间；向上游提交的真实名称仍为 `run_python`。

## 自动发现与精确选择

省略 `--url` 时只读扫描官方公告目录：

- Windows 默认 `%LOCALAPPDATA%/McNeel/rhino-mcp/listeners/*.json`。
- 如果设置了 `RHINO_MCP_HOME`，目录为 `<RHINO_MCP_HOME>/rhino-mcp/listeners`。
- 非 Windows 的 .NET 路径可能随系统不同；优先显式传 `--listener-dir` 或 `--url`。
- 公告字段为 `v=1`、`pid`、`port`、`version=8或9`。适配器不会删除失效公告或修改 `state.db`。

```powershell
python adapter/rhino_stdio_adapter.py probe
python adapter/rhino_stdio_adapter.py probe --pid 12345
python adapter/rhino_stdio_adapter.py probe --listener-dir C:/实际目录/rhino-mcp/listeners
```

发现模式只以握手检查候选监听器，不调用建模工具。只有一个可用监听器时才自动选中；多个时返回候选列表，要求明确指定。一个 Rhino 进程可以有多个文档端口，因此即使指定 `--pid`，仍可能需要 `--url`。连接建立后固定在该地址；不会因断线自动切换到另一份文档。

`--url` 必须是 HTTP loopback 根地址 `/`；拒绝公网地址、重定向、代理、`/agent` 和 `/mcp`。服务 `initialize.serverInfo.name` 必须是 `rhino-mcp`。名称检查是兼容性检查，不是软件签名认证；应通过本技能初始化脚本从McNeel官方来源获取并安装插件。

## 协议与结果合同

- 对外 stdio 为 UTF-8，每行一条 JSON-RPC 2.0 消息。stdout 仅输出协议消息；错误说明写 stderr。
- 保留官方 `initialize` 返回协议 `2024-11-05` 和能力声明。宿主需要接受该版本协商；要求更新版本的宿主应使用官方 router。
- 支持 `initialize`、`notifications/initialized`、`notifications/cancelled`、`ping`、`tools/list`、`tools/call`、`resources/list`、`resources/templates/list`、`resources/read`，不凭空声明其他能力。
- 官方插件当前外部根端点是 JSON POST 请求/响应，不是完整的 SSE 流实现；本适配器不实现 SSE、OAuth、服务端反向请求、订阅、采样或多实例生命周期管理。
- 一次适配器进程逐条串行请求。多个代理进程之间不提供全局互斥，不能让它们同时修改同一文档。取消通知会转发，但串行同步调用期间无法立即中断已经运行的 Rhino 脚本。
- `tools/list` 每次读取上游。保留原工具名称、inputSchema、annotations 和分页游标；同轮分页合并已发现名称，无 cursor 的新清单重置缓存。调用尚未缓存的名称时，先读取已有 nextCursor 指向的剩余页，再判断是否存在；这只补读能力清单，不重放工具执行。已知常用工具叠加固定中文摘要并保留原说明。`--original-descriptions` 关闭中文叠加。未来新增工具保持上游原说明，不猜测翻译或参数。
- `tools/call` 只调用已发现名称，参数校验以官方 schema 和官方执行器为准。工具结果、图片 base64、JSON-RPC 错误原样保留。
- 默认超时 180 秒，长脚本可传 `--timeout 600`。工具超时、HTTP 响应中断、坏 JSON 或请求 id 不匹配时可能已经执行：返回 `executionState=unknown` 且 `automaticRetry=false`，先检查 Rhino 对象/生成标记/日志，禁止自动重复建模。适配器保持 stdio 进程可用，以便下一步做只读核对。
- 非有限数值（如 `NaN`、`Infinity`、溢出的 `1e400`）在本地拒绝，不发送到 Rhino。损坏的工具清单返回结构化错误，宿主可重新发现能力。

CLI 成功返回 0；连接、协议、工具 `isError` 或稳定版脚本文本 JSON 的 `error` 非空返回 1。脚本自己的业务检查结果仍要读取报告判断，退出码不会替代几何验收。

没有 `--out` 时，CLI stdout 输出完整响应 JSON。有 `--out` 时，每次创建新的 `rhino-*` 子目录，写 `response.json` 并将 MCP image/audio 内容解码为独立文件，stdout 返回 `{ok,report,files}`。不解析脚本 stdout 中的业务 JSON，也不改变官方响应。所有内容保留在本机，不上传、发布或部署。

## 本地测试与验证范围

```powershell
python -m unittest discover -s adapter -p test_adapter.py -v
python -m unittest discover -s tests -p test_transport_faults.py -v
```

原 15 项自动测试使用本机临时 mock HTTP 服务，覆盖 stdio 握手和串行请求、通知、清单 schema 保留、工具名拒绝猜测、上游错误、图像落盘、中文脚本、嵌套脚本错误、超时不重试、监听公告筛选、多实例歧义和错误服务拒绝。新增 15 项来自实际故障注入：7 项检查断流后的执行未知状态与恢复、坏 JSON、错误 id、非有限数值、损坏清单和分页；另 8 项在 Windows PowerShell 5.1 与 PowerShell 7 分别验证 Set-Location 后的相对输出、Python/router 路径、RhinoSystem 路径和 `-WhatIf` 哈希校验。当前 Windows 环境共 30 项通过；非 Windows 或未安装对应 PowerShell 的环境跳过相应路径测试。测试不会读取或修改 Rhino 模型。

路径修复使用 PowerShell 的 GetUnresolvedProviderPathFromPSPath 解析当前位置下的路径；配置片段仍输出绝对路径和独立 argv。分页测试依据 MCP 2024-11-05 tools/list 合同，是协议 mock 兼容测试，未证明真实官方 0.1.5 曾出现分页场景。

使用时先 `probe`、保存 `tools` 快照，然后运行只读文档检查，再在副本中做一次可撤销的小构件验证。此适配器用于Rhino8/9官方HTTP通道；Rhino7请使用随包 `scripts/rhino7/stdio.ps1`。

源码审计依据为主分支 commit `4109116e3ea2cfd62859fd150b5f4331b93f45b5` 和稳定 `plugin-v0.1.5` commit `7f079d27199f1690143b9229db80b25ba38915be`。具体依据与差异见 `../references/01-official-platform.md`。Python 适配器代码可随本技能包携带；已有 Python 时无需下载额外依赖。


1.2.0修复：SSE在读body前拒绝；HTTP单请求总截止时间；自动发现总预算和逐项错误；支持2024-11-05/2025-03-26/2025-06-18握手，未知协议仍拒绝。stdio串行，运行中的取消通知会排队，不宣称即时取消。品牌宿主联测仍需实际验收。
