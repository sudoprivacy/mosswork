# 1.0.3 首次使用：Windows最短路线

前提：本机能正常打开正版Rhino7、Rhino8.29+或Rhino9；Agent可以运行本地命令或stdio MCP。云端网页聊天不能直接使用本机Rhino。模型账号和图像能力由宿主提供。

## 1. 下载技能

Windows没有Bash或SkillHub CLI时，直接从技能页面下载ZIP，**完整解压到固定目录**，把整个技能目录放入宿主认可的skills位置。不要只复制SKILL.md。SkillHub公开CLI安装入口使用Bash、tar、python3；这是平台安装依赖，与Rhino7桥无需外部Python/Node是两回事。

已有SkillHub CLI时可使用：

```text
skillhub install @user_79052190/rhino-parametric-modeling-cn --dir <实际宿主skills目录>
```

以宿主实际加载结果为准；下载成功不等于技能已加载。不要改系统代理、关闭证书验证或执行未知镜像脚本。

## 2. 统一初始化

在解压的包根目录运行，**版本参数必须匹配已有Rhino**：

```powershell
# Rhino7：本机桥，无插件下载；可自动读取注册表中的D盘等安装位置
& .\scripts\initialize-rhino.ps1 -RhinoVersion 7 -ConfigOutFile '.\rhino7-mcp.generated.json'

# Rhino8.29+：官方插件和router
& .\scripts\initialize-rhino.ps1 -RhinoVersion 8 -ConfigOutFile '.\rhino8-mcp.generated.json'

# Rhino9：配置也使用9，不再误指8
& .\scripts\initialize-rhino.ps1 -RhinoVersion 9 -ConfigOutFile '.\rhino9-mcp.generated.json'

# 只读预演；不会创建配置或安装
& .\scripts\initialize-rhino.ps1 -RhinoVersion 7 -WhatIf
```

仅执行自己版本的一条。非标准安装可显式传 `-RhinoSystem`。多Rhino7实例传 `-RhinoPid 实际PID`；官方router路径不接受PID参数，以官方工具选择真实文档。

输出包含分阶段耗时、状态和下一步。`prepared`只是准备；官方路径的`connection_pending`只是尚未验收连接。Rhino7 `attach_required`会给出command、last_error和可能的启动阻塞项：在正确窗口处理许可/模板/插件提示，执行该command一次，再检查。脚本不会绕过许可或关闭已有工程。

已有官方安装会检查manifest、插件和当前架构router文件；残留或不完整目录明确报错并保留，不自动覆盖、降级或删除。文件存在仍不证明插件加载成功。

## 3. 宿主连接和原生模型验收

把生成JSON中的 `mcpServers.rhino-cn` 导入宿主MCP设置，保留其他服务器。移动目录后重新生成配置。真实 `tools/list` 和 `get_context` 成功、文档/单位正确才算接入通过。

Rhino7：先新建空白文档，另存为新的3dm。然后运行：

```powershell
& .\scripts\initialize-rhino.ps1 -RhinoVersion 7 -SmokeOutputDirectory 'D:\Rhino测试\新测试目录'
```

输出目录必须不存在；冒烟测试会创建容器、改参、检查非法输入、截图和保存重读。实际查看三张PNG。只有这些通过才有 `modeling_verified=true`。它是技术小样，不能证明所有参考图造型都能还原。

Rhino8/9：在Rhino运行MCPConnect，完成官方插件加载和宿主导入；首次在ScriptEditor完成Python3初始化，该步骤有独立的运行时/PyPI网络依赖。用真实内核完成小样、截图和另存重读后再开始正式工程。

## 4. 可选适配器边界

优先官方router。HTTP适配器只连接回环JSON端点，不支持SSE；检测到SSE立即拒绝，不读取无限响应。支持2024-11-05、2025-03-26、2025-06-18握手及回退协商；未知上游协议仍拒绝。支持列表由协议模拟测试覆盖，不能替代品牌宿主实机测试。

`--timeout`是单个HTTP请求的总截止时间；自动发现最多32个候选，整体预算不超过10秒并保留失败诊断。发现不完整时不能选择可能错误的唯一实例，应传实际--url或--pid。stdio仍串行处理，请求运行期间取消通知会排队；大任务应分批，超时后先核对状态，不盲目重发写入。

## 5. 版本和验收范围

技能1.0.3；可选适配器1.2.0；固定官方插件0.1.5；桥协议rhino-shenbi-7/1。历史测试记录保留原日期和版本，当前结果见VALIDATION.md。

无代理与完全离线不同：Rhino8/9没有插件及缓存时首次需要联网；Rhino内部运行时、许可和宿主模型也需分别准备。本机下载测速不保证所有用户网络都相同。
