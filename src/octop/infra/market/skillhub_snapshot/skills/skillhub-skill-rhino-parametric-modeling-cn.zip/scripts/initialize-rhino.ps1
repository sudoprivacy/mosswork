#requires -Version 5.1
<# Unified first-run helper. Does not change host settings, license settings,
restart Rhino or overwrite files. Connection and modeling are distinct stages. #>
[CmdletBinding(SupportsShouldProcess=$true)]
param(
    [Parameter(Mandatory=$true)][ValidateSet('7','8','9')][string]$RhinoVersion,
    [string]$RhinoSystem,
    [string]$CacheDirectory,
    [int]$RhinoPid=0,
    [ValidateRange(0,60)][int]$WaitSeconds=45,
    [switch]$PrepareOnly,
    [string]$ConfigOutFile,
    [string]$SmokeOutputDirectory
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'setup-common.ps1')
if ($RhinoVersion -ne '7' -and $RhinoPid -gt 0) { throw 'The official router does not bind a PID through this helper. Omit RhinoPid and select the intended document using official tools.' }
if ($SmokeOutputDirectory -and ($RhinoVersion -ne '7' -or $PrepareOnly -or $WhatIfPreference)) { throw 'SmokeOutputDirectory requires the live Rhino7 path; it writes only into a new empty saved test document.' }
$report=[ordered]@{skill_version='1.0.3';rhino_version=$RhinoVersion;stages=@();connection_verified=$false;modeling_verified=$false;status='pending'}
$watch=[Diagnostics.Stopwatch]::StartNew()
$resolved=Resolve-RhinoSystem -RhinoVersion $RhinoVersion -RhinoSystem $RhinoSystem
$report.stages+=@{name='environment';seconds=$watch.Elapsed.TotalSeconds;rhino_system=$resolved;status='executable_found'}
$watch.Restart()
$prepared=& (Join-Path $PSScriptRoot 'setup-rhino.ps1') -RhinoVersion $RhinoVersion -RhinoSystem $resolved -CacheDirectory $CacheDirectory -RhinoPid $RhinoPid -WaitSeconds $WaitSeconds -PrepareOnly:$PrepareOnly -WhatIf:$WhatIfPreference
if ($RhinoVersion -eq '7') { $prepared=$prepared | ConvertFrom-Json }
$report.stages+=@{name='setup';seconds=$watch.Elapsed.TotalSeconds;result=$prepared}
if ($RhinoVersion -eq '7') {
    $report.status=$prepared.status
    $report.connection_verified=($prepared.status -eq 'ready')
} else { $report.status='connection_pending'; if ($PrepareOnly) { $report.status='prepared' }; if ($WhatIfPreference) { $report.status='whatif' } }
if ($ConfigOutFile -and -not $PrepareOnly -and -not $WhatIfPreference -and
    ($RhinoVersion -ne '7' -or $report.connection_verified)) {
    $watch.Restart()
    $configArgs=@{RhinoVersion=$RhinoVersion;OutFile=$ConfigOutFile}
    if ($RhinoVersion -eq '7' -and $RhinoPid -gt 0) { $configArgs.RhinoPid=$RhinoPid }
    & (Join-Path $PSScriptRoot 'configure-mcp.ps1') @configArgs | Out-Null
    $report.stages+=@{name='configuration';status='fragment_created';seconds=$watch.Elapsed.TotalSeconds;path=[IO.Path]::GetFullPath($ConfigOutFile)}
}
if ($SmokeOutputDirectory -and $report.connection_verified) {
    $watch.Restart()
    $smoke=& (Join-Path $PSScriptRoot 'rhino7\smoke-test.ps1') -RhinoPid $prepared.rhino_pid -OutputDirectory $SmokeOutputDirectory | ConvertFrom-Json
    $report.modeling_verified=($smoke.status -eq 'passed')
    $report.stages+=@{name='native_smoke';seconds=$watch.Elapsed.TotalSeconds;result=$smoke}
}
$report.next_steps=if ($RhinoVersion -eq '7') {
    if ($report.connection_verified) { 'Import the generated MCP fragment into your local host, preserving other servers. Confirm tools/list and the target document. Run smoke-test only in a NEW EMPTY SAVED test document.' }
    else { 'Read setup result.command and last_error. Resolve Rhino startup/license dialogs, run the bridge command in the intended Rhino window once, then rerun. No connection success has been recorded.' }
} else { 'Save existing work before restarting Rhino when needed. Run MCPConnect, import the fragment, verify tools/list and get_context, initialize ScriptEditor Python3, then validate native modeling and save/reopen in a test copy.' }
$report | ConvertTo-Json -Depth 60
