#requires -Version 5.1
# Shared local transport. No network except IPv4 loopback; no auto replay.
function Get-Rhino7Session {
    param([int]$RhinoPid = 0, [string]$SessionFile)
    if ($SessionFile) {
        $paths = @($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($SessionFile))
    } else {
        $root = Join-Path $env:LOCALAPPDATA 'RhinoShenbi\bridge7'
        $paths = @()
        if (Test-Path -LiteralPath $root -PathType Container) {
            foreach ($file in @(Get-ChildItem -LiteralPath $root -Filter '*.json' -File)) {
                $number = 0
                if (-not [int]::TryParse($file.BaseName, [ref]$number)) { continue }
                if ($RhinoPid -gt 0 -and $number -ne $RhinoPid) { continue }
                $process = Get-Process -Id $number -ErrorAction SilentlyContinue
                if ($process -and $process.ProcessName -eq 'Rhino') { $paths += $file.FullName }
            }
        }
    }
    if ($paths.Count -eq 0) { throw 'No running Rhino7 bridge. Run setup-rhino.ps1 -RhinoVersion 7 and execute its RhinoCommand in the target Rhino if requested.' }
    if ($paths.Count -ne 1) { throw ('Multiple Rhino7 sessions; specify -RhinoPid. Session files: ' + ($paths -join ', ')) }
    $data = [IO.File]::ReadAllText($paths[0], [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($data.protocol -ne 'rhino-shenbi-7/1' -or $data.host -ne '127.0.0.1' -or
        $data.rhino_major -ne 7 -or $data.port -lt 1 -or $data.port -gt 65535 -or
        $data.token -notmatch '^[a-f0-9]{64}$' -or $data.pid -lt 1 -or
        ($RhinoPid -gt 0 -and $data.pid -ne $RhinoPid)) { throw 'Invalid Rhino7 session record.' }
    return $data
}

function Invoke-Rhino7Request {
    param([string]$Method, [object]$Parameters = @{}, [int]$RhinoPid = 0,
          [string]$SessionFile, [string]$RequestId)
    if (-not $RequestId) { $RequestId = [guid]::NewGuid().ToString('N') }
    $session = Get-Rhino7Session -RhinoPid $RhinoPid -SessionFile $SessionFile
    $request = @{ protocol='rhino-shenbi-7/1'; token=$session.token; id=$RequestId; method=$Method; params=$Parameters }
    $encoded = [Text.Encoding]::UTF8.GetBytes(($request | ConvertTo-Json -Depth 90 -Compress) + "`n")
    if ($encoded.Length -gt 4194304) { throw 'Request exceeds 4MiB. Pass script_path and a small config instead.' }
    $client = New-Object Net.Sockets.TcpClient
    $stream = $null
    $memory = New-Object IO.MemoryStream
    $sent = $false
    $deadline = [DateTime]::UtcNow.AddSeconds(120)
    try {
        $connect = $client.ConnectAsync('127.0.0.1', [int]$session.port)
        if (-not $connect.Wait(5000)) { throw 'Bridge connection timed out.' }
        [void]$connect.GetAwaiter().GetResult()
        $stream = $client.GetStream()
        $stream.ReadTimeout = 120000
        $stream.WriteTimeout = 10000
        $sent = $true
        $stream.Write($encoded, 0, $encoded.Length)
        $buffer = New-Object byte[] 65536
        $complete = $false
        while (-not $complete) {
            $remaining = [int][Math]::Ceiling(($deadline - [DateTime]::UtcNow).TotalMilliseconds)
            if ($remaining -le 0) { throw 'Bridge request total deadline exceeded.' }
            $stream.ReadTimeout = $remaining
            $n = $stream.Read($buffer, 0, $buffer.Length)
            if ([DateTime]::UtcNow -ge $deadline) { throw 'Bridge request total deadline exceeded.' }
            if ($n -eq 0) { throw 'Bridge closed without a complete reply.' }
            $end = [Array]::IndexOf($buffer, [byte]10, 0, $n)
            $count = if ($end -ge 0) { $end } else { $n }
            $memory.Write($buffer, 0, $count)
            if ($memory.Length -gt 25165824) { throw 'Bridge reply exceeds limit.' }
            $complete = $end -ge 0
        }
        $utf8 = New-Object Text.UTF8Encoding($false, $true)
        $response = $utf8.GetString($memory.ToArray()) | ConvertFrom-Json
        if ($response.id -cne $RequestId) { throw 'Bridge reply id mismatch.' }
        if ($response.status -notin @('ok','error')) { throw 'Invalid bridge reply status.' }
        return $response
    } catch {
        $state = if ($sent) { 'unknown' } else { 'not_dispatched' }
        return [pscustomobject]@{ id=$RequestId; status='error'; execution_state=$state;
            error=$_.Exception.Message; recovery='Query get_request_status with this id in the same session. Never blindly replay a modifying request.' }
    } finally {
        if ($stream) { $stream.Dispose() }
        $client.Close()
        $memory.Dispose()
    }
}
