#requires -Version 5.1
[CmdletBinding()]
param([int]$RhinoPid = 0, [string]$SessionFile)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::InputEncoding = New-Object Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
. (Join-Path $PSScriptRoot 'transport.ps1')
$tools = @((Get-Content -LiteralPath (Join-Path $PSScriptRoot 'tools.json') -Raw -Encoding UTF8 | ConvertFrom-Json).tools)
while ($null -ne ($line = [Console]::ReadLine())) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $id = $null
    $response = $null
    $errorCode = -32700
    try {
        if ([Text.Encoding]::UTF8.GetByteCount($line) -gt 4194304) { throw 'MCP line exceeds 4MiB.' }
        $request = $line | ConvertFrom-Json
        $errorCode = -32600
        if ($request.jsonrpc -ne '2.0') { throw 'Expected JSON-RPC 2.0.' }
        if (-not ($request.PSObject.Properties.Name -contains 'id')) { continue }
        $id = $request.id
        $errorCode = -32602
        $result = $null
        switch ($request.method) {
            'initialize' {
                $version = $request.params.protocolVersion
                if ($version -notin @('2024-11-05','2025-03-26','2025-06-18')) { $version = '2024-11-05' }
                $result = @{ protocolVersion=$version; capabilities=@{tools=@{listChanged=$false}};
                    serverInfo=@{name='rhino-shenbi-7';version='1.0.3'};
                    instructions='Rhino7 uses IronPython2.7. Read get_context first. run_python requires document serial and run_id. Set JSON-serializable result. No f-strings/Python3. Use run_template for inspect/capture/save. An unknown execution state must be reconciled, never blindly retried.' }
            }
            'ping' { $result = @{} }
            'tools/list' { $result = @{tools=$tools} }
            'tools/call' {
                $name = $request.params.name
                if (@($tools | Where-Object { $_.name -ceq $name }).Count -ne 1) { throw 'Unknown Rhino7 tool.' }
                $arguments = $request.params.arguments
                if ($null -eq $arguments) { $arguments = @{} }
                $answer = Invoke-Rhino7Request -Method $name -Parameters $arguments -RhinoPid $RhinoPid -SessionFile $SessionFile
                $blocks = @()
                if ($answer.status -eq 'ok' -and $name -eq 'get_viewport_image') {
                    $blocks += @{type='image';mimeType='image/png';data=$answer.result.image_base64}
                    $blocks += @{type='text';text=(@{status='ok';request_id=$answer.id;document_serial=$answer.result.document_serial} | ConvertTo-Json -Compress)}
                } else {
                    $blocks += @{type='text';text=($answer | ConvertTo-Json -Depth 90 -Compress)}
                }
                $result = @{content=$blocks;isError=($answer.status -ne 'ok')}
            }
            default { $response = @{jsonrpc='2.0';id=$id;error=@{code=-32601;message='Method not found'}} }
        }
        if (-not $response) { $response = @{jsonrpc='2.0';id=$id;result=$result} }
    } catch {
        $response = @{jsonrpc='2.0';id=$id;error=@{code=$errorCode;message=$_.Exception.Message}}
    }
    [Console]::WriteLine(($response | ConvertTo-Json -Depth 100 -Compress))
}
