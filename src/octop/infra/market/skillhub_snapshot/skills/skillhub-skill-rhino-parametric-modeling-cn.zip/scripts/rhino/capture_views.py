# -*- coding: utf-8 -*-
"""Capture explicit world-coordinate cameras; restore projection/visibility."""
from __future__ import print_function
import os
import json
import math
from _common import (check_document, enumerate_objects, absolute_path, checked_child,
                     safe_name, write_json, resolve_document, ensure_new_report_path)


def _vector(value, label):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError(label + ' must contain three finite coordinates')
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in value):
        raise ValueError(label + ' coordinates must be numbers')
    result = [float(v) for v in value]
    if any(math.isnan(v) or math.isinf(v) for v in result):
        raise ValueError(label + ' coordinates must be finite')
    return result


def _unit(value, label):
    scale = max(abs(v) for v in value)
    if scale == 0 or math.isinf(scale) or math.isnan(scale):
        raise ValueError(label + ' must be a finite nonzero vector')
    scaled = [v / scale for v in value]
    length = math.sqrt(sum(v * v for v in scaled))
    return [v / length for v in scaled]


def _validate_spec(spec):
    if not isinstance(spec, dict):
        raise ValueError('Each view must be a JSON object')
    safe_name(spec['name'])
    camera = _vector(spec['camera'], 'camera')
    target = _vector(spec['target'], 'target')
    up = _unit(_vector(spec.get('up', [0, 0, 1]), 'up'), 'up')
    direction = _unit([b - a for a, b in zip(camera, target)], 'camera direction')
    cross = [direction[1] * up[2] - direction[2] * up[1],
             direction[2] * up[0] - direction[0] * up[2],
             direction[0] * up[1] - direction[1] * up[0]]
    if sum(v * v for v in cross) <= 1e-16:
        raise ValueError('up must not be parallel to camera direction; top views usually need up=[0,1,0]')
    projection = spec.get('projection', 'parallel')
    if projection not in ('parallel', 'perspective'):
        raise ValueError('projection must be parallel or perspective')
    if projection == 'perspective':
        lens = spec.get('lens_mm', 50)
        if isinstance(lens, bool) or not isinstance(lens, (int, float)) or not 0 < lens < float('inf'):
            raise ValueError('lens_mm must be a finite positive number')
    if spec.get('bounds') is not None:
        bounds = spec['bounds']
        if not isinstance(bounds, (list, tuple)) or len(bounds) != 2:
            raise ValueError('bounds must contain min and max coordinates')
        lo, hi = _vector(bounds[0], 'bounds min'), _vector(bounds[1], 'bounds max')
        if any(a > b for a, b in zip(lo, hi)) or lo == hi:
            raise ValueError('bounds must enclose a nonzero, ordered extent')


def main(config, doc=None):
    import Rhino
    import System
    doc = resolve_document(config, doc, globals().get('__rhino_doc__'))
    check_document(doc, config, required=True)
    root = absolute_path(config['output_root'])
    if not os.path.isdir(root):
        raise ValueError('Create output_root before capture')
    specs = config.get('views', [])
    if not specs:
        raise ValueError('At least one explicit camera specification is required')
    for spec in specs:
        _validate_spec(spec)
    width, height = int(config.get('width', 1600)), int(config.get('height', 1000))
    if not (64 <= width <= 8192 and 64 <= height <= 8192):
        raise ValueError('Capture dimensions must be 64..8192 pixels')
    targets = set(str(System.Guid(value)) for value in config.get('isolate_ids', []))
    objects = enumerate_objects(Rhino, doc, references=True, definitions=False)
    object_map = dict((str(obj.Id), obj) for obj in objects)
    if targets - set(object_map):
        raise ValueError('Missing isolate_ids; inspect again before capture')
    # Isolation never shows hidden targets or changes layer visibility.
    if any(object_map[key].IsHidden or not doc.Layers[object_map[key].Attributes.LayerIndex].IsVisible for key in targets):
        raise ValueError('An isolation target is hidden; prepare the view explicitly first')
    paths = [checked_child(root, os.path.join(root, safe_name(spec['name']) + '.png')) for spec in specs]
    if len(set(os.path.normcase(path) for path in paths)) != len(paths) or any(os.path.exists(path) for path in paths):
        raise ValueError('Capture paths must be distinct new files')
    report_path = ensure_new_report_path(config, [doc.Path])
    if report_path:
        report_path = checked_child(root, report_path)
    view = doc.Views.ActiveView
    if view is None:
        raise RuntimeError('No active Rhino view')
    vp = view.ActiveViewport
    mode = None
    if config.get('display_mode'):
        mode = Rhino.Display.DisplayModeDescription.FindByName(config['display_mode'])
        if mode is None:
            raise ValueError('Display mode not found: ' + config['display_mode'])
    saved_projection = Rhino.DocObjects.ViewportInfo(vp)
    saved_target = vp.CameraTarget
    saved_size = vp.Size
    saved_display = vp.DisplayMode
    changed_hidden = []
    restoration_errors = []
    written = []
    try:
        if targets:
            for obj in objects:
                if str(obj.Id) not in targets and not obj.IsHidden:
                    if not doc.Objects.Hide(obj.Id, True):
                        raise RuntimeError('Could not isolate object: ' + str(obj.Id))
                    changed_hidden.append(obj.Id)
        vp.Size = System.Drawing.Size(width, height)
        if mode is not None:
            vp.DisplayMode = mode
        for spec, path in zip(specs, paths):
            if spec.get('projection', 'parallel') == 'parallel':
                if vp.ChangeToParallelProjection(True) is False:
                    raise RuntimeError('Could not apply parallel projection')
            elif spec.get('projection') == 'perspective':
                if vp.ChangeToPerspectiveProjection(True, float(spec.get('lens_mm', 50))) is False:
                    raise RuntimeError('Could not apply perspective projection')
            else:
                raise ValueError('projection must be parallel or perspective')
            vp.SetCameraLocations(Rhino.Geometry.Point3d(*spec['target']),
                                  Rhino.Geometry.Point3d(*spec['camera']))
            vp.CameraUp = Rhino.Geometry.Vector3d(*spec.get('up', [0, 0, 1]))
            if spec.get('bounds'):
                bb = Rhino.Geometry.BoundingBox(Rhino.Geometry.Point3d(*spec['bounds'][0]),
                                                Rhino.Geometry.Point3d(*spec['bounds'][1]))
                if not bb.IsValid:
                    raise ValueError('Invalid camera bounds')
                if vp.ZoomBoundingBox(bb) is False:
                    raise RuntimeError('Could not frame camera bounds')
            doc.Views.Redraw()
            bitmap = view.CaptureToBitmap(System.Drawing.Size(width, height))
            if bitmap is None:
                raise RuntimeError('CaptureToBitmap returned no bitmap')
            try:
                bitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png)
            finally:
                bitmap.Dispose()
            written.append(path)
    finally:
        for ident in changed_hidden:
            try:
                if not doc.Objects.Show(ident, True):
                    restoration_errors.append('Could not restore object ' + str(ident))
            except Exception as exc:
                restoration_errors.append(str(exc))
        try:
            vp.Size = saved_size
            if not vp.SetViewProjection(saved_projection, False):
                restoration_errors.append('Could not restore camera projection')
            vp.SetCameraTarget(saved_target, False)
            vp.DisplayMode = saved_display
        except Exception as exc:
            restoration_errors.append(str(exc))
        saved_projection.Dispose()
        doc.Views.Redraw()
        if restoration_errors:
            raise RuntimeError('View restoration incomplete: ' + '; '.join(restoration_errors))
    report = {'status': 'captured_and_restored', 'files': written,
              'visibility_camera_display_restored': True, 'geometry_mutated': False,
              'selection_not_modified': True, 'coordinates': 'document world coordinates and units'}
    report['requested_views'] = specs
    report['framing_note'] = 'bounds refits framing; a parallel view without bounds inherits its frustum and is not a fixed-scale comparison'
    if report_path:
        write_json(report_path, report, overwrite=False)
    return report


if __name__ == '__main__':
    if 'CONFIG' not in globals():
        raise ValueError('Inject CONFIG using the wrapper described in reference 05')
    result = main(CONFIG)
    if CONFIG.get('print_json', True):
        print(json.dumps(result, ensure_ascii=True))
