# -*- coding: utf-8 -*-
"""Native Rhino7/8/9 parametric open vessel, with validated replacement.

Invoke through run_python with CONFIG. Dimensions are in document units.
No global deletion, implicit save, units change, or external dependencies.
"""
from __future__ import print_function
import math
import Rhino
import System


def main(config, doc):
    values = {}
    for key, default in [('radius', 20.0), ('height', 45.0), ('wall', 2.0)]:
        value = config.get(key, default)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(key + ' must be numeric')
        value = float(value)
        if math.isnan(value) or math.isinf(value) or value <= 0:
            raise ValueError(key + ' must be finite and positive')
        values[key] = value
    r, h, wall = values['radius'], values['height'], values['wall']
    tolerance = doc.ModelAbsoluteTolerance
    if wall >= min(r * 0.4, h * 0.4) or wall <= tolerance * 10:
        raise ValueError('wall must exceed 10*tolerance and be below 40% of radius/height')
    name = config.get('instance', 'vessel-demo')
    if not isinstance(name, type(u'')):
        name = str(name)
    if not name or len(name) > 80:
        raise ValueError('instance must be 1..80 characters')
    old = []
    settings = Rhino.DocObjects.ObjectEnumeratorSettings()
    settings.HiddenObjects = True
    settings.LockedObjects = True
    settings.DeletedObjects = False
    for obj in doc.Objects.GetObjectList(settings):
        if obj.Attributes.GetUserString('SHENBI_EXAMPLE_INSTANCE') == name:
            if obj.IsLocked or obj.IsHidden or obj.IsReference:
                raise ValueError('Previous example is hidden/locked/reference; inspect before replacing')
            old.append(obj.Id)
    g = Rhino.Geometry
    outer = g.Cylinder(g.Circle(g.Plane.WorldXY, r), h).ToBrep(True, True)
    inner_plane = g.Plane(g.Point3d(0, 0, wall), g.Vector3d.ZAxis)
    inner = g.Cylinder(g.Circle(inner_plane, r - wall), h).ToBrep(True, True)
    parts = g.Brep.CreateBooleanDifference(outer, inner, tolerance)
    if not parts or len(parts) != 1 or not parts[0].IsValid or not parts[0].IsSolid:
        raise RuntimeError('Boolean failed; no document geometry changed')
    volume = g.VolumeMassProperties.Compute(parts[0])
    expected = math.pi * (r*r*h - (r-wall)**2*(h-wall))
    if volume is None or abs(volume.Volume - expected) > max(expected*1e-6, tolerance**3):
        raise RuntimeError('Unexpected volume; no document geometry changed')
    attrs = Rhino.DocObjects.ObjectAttributes()
    attrs.Name = name
    attrs.SetUserString('SHENBI_EXAMPLE_INSTANCE', name)
    attrs.SetUserString('FEATURE_ID', 'hollow_body')
    ident = doc.Objects.AddBrep(parts[0], attrs)
    if ident == System.Guid.Empty:
        raise RuntimeError('Adding geometry failed; previous example preserved')
    for old_id in old:
        if not doc.Objects.Delete(old_id, True):
            raise RuntimeError('Partial replacement: inspect IDs; use named Undo before retrying')
    doc.Views.Redraw()
    return {'id': str(ident), 'replaced_ids': [str(x) for x in old], 'parameters': values,
            'valid': True, 'solid': True, 'volume': volume.Volume, 'expected_volume': expected,
            'bounds': [[-r, -r, 0], [r, r, h]], 'representation': 'native closed Brep'}


if __name__ == '__main__':
    result = main(CONFIG, __rhino_doc__)
