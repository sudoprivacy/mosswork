# -*- coding: utf-8 -*-
"""Read-only inventory. Inject CONFIG via run_config.py; Rhino 7/8 compatible."""
from __future__ import print_function
import sys
import json
from _common import check_document, enumerate_objects, geometry_signature, write_json, ensure_new_report_path, resolve_document


def main(config, doc=None):
    import Rhino
    import System
    doc = resolve_document(config, doc, globals().get('__rhino_doc__'))
    check_document(doc, config)
    report_path = ensure_new_report_path(config, [doc.Path])
    objects = enumerate_objects(Rhino, doc, config.get('include_references', True),
                                config.get('include_definitions', True))
    requested = set(str(System.Guid(value)) for value in config.get('target_ids', []))
    found = set(str(obj.Id) for obj in objects)
    missing = sorted(requested - found)
    selected = [obj for obj in objects if not requested or str(obj.Id) in requested]
    counts = {}
    records = []
    limit = int(config.get('max_records', 10000))
    if limit < 0:
        raise ValueError('max_records must be nonnegative')
    for obj in selected:
        kind = str(obj.Geometry.GetType().FullName)
        counts[kind] = counts.get(kind, 0) + 1
        if len(records) < limit:
            record = geometry_signature(System, obj.Geometry)
            record.update({'id': str(obj.Id), 'name': obj.Attributes.Name or '',
                'layer_index': int(obj.Attributes.LayerIndex), 'hidden': bool(obj.IsHidden),
                'locked': bool(obj.IsLocked), 'reference': bool(obj.IsReference),
                'instance_definition_geometry': bool(obj.IsInstanceDefinitionGeometry),
                'generation_tag': obj.Attributes.GetUserString(config.get('generation_tag_key', 'AGENT_RUN_ID'))})
            records.append(record)
    layers = [{'id': str(layer.Id), 'index': int(layer.Index), 'full_path': layer.FullPath,
               'parent_id': str(layer.ParentLayerId), 'visible': bool(layer.IsVisible),
               'locked': bool(layer.IsLocked)} for layer in doc.Layers if not layer.IsDeleted]
    report = {'status': 'inspected_read_only', 'document_mutated': False,
        'document_path': doc.Path, 'rhino_version': str(Rhino.RhinoApp.Version),
        'python_version': sys.version, 'units': str(doc.ModelUnitSystem),
        'absolute_tolerance': float(doc.ModelAbsoluteTolerance),
        'angle_tolerance_radians': float(doc.ModelAngleToleranceRadians),
        'enumerated_count': len(objects), 'target_count': len(selected),
        'missing_target_ids': missing, 'type_counts': counts, 'layers': layers,
        'objects': records, 'records_truncated': len(selected) > len(records),
        'count_note': 'Explicit live enumeration excludes deleted undo entries; definition and reference inclusion is recorded in config.',
        'config': config}
    if report_path:
        write_json(report_path, report, overwrite=False)
    return report


if __name__ == '__main__':
    if 'CONFIG' not in globals():
        raise ValueError('Inject CONFIG using the wrapper described in reference 05')
    result = main(CONFIG)
    if CONFIG.get('print_json', True):
        print(json.dumps(result, ensure_ascii=True))
