[CmdletBinding(SupportsShouldProcess=$true)]
param(
    [ValidateSet('8','9')][string]$RhinoVersion = '8',
    [string]$RhinoSystem,
    [string]$AssetDirectory
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'setup-common.ps1')
$bundleRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$RhinoSystem = Resolve-RhinoSystem -RhinoVersion $RhinoVersion -RhinoSystem $RhinoSystem
$RhinoSystem = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RhinoSystem)
$yakPath = Join-Path $RhinoSystem 'Yak.exe'
$rhinoPath = Join-Path $RhinoSystem 'Rhino.exe'
if (-not (Test-Path -LiteralPath $yakPath -PathType Leaf)) { throw "Yak.exe missing: $yakPath. Install a licensed supported Rhino first, or specify -RhinoSystem." }
if (-not (Test-Path -LiteralPath $rhinoPath -PathType Leaf)) { throw "Rhino.exe missing: $rhinoPath" }
$fileVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($rhinoPath)
if ($fileVersion.FileMajorPart -ne [int]$RhinoVersion) { throw 'Rhino executable major version does not match -RhinoVersion.' }
if ($RhinoVersion -eq '8' -and $fileVersion.FileMinorPart -lt 29) { throw 'The bundled Rhino 8 package requires Rhino 8.29 or later.' }
$distTag = if ($RhinoVersion -eq '8') { 'rh8_29' } else { 'rh9_0' }
$assetName = "rhino-mcp-platform-0.1.5-$distTag-win.yak"
if (-not $AssetDirectory) { $AssetDirectory = Join-Path $bundleRoot 'vendor\official' }
$AssetDirectory = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($AssetDirectory)
$assetPath = Join-Path $AssetDirectory $assetName
$manifestPath = Join-Path $bundleRoot 'vendor\official\assets.json'
$assetManifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$entry = @($assetManifest.assets | Where-Object { $_.file -eq $assetName })
if ($entry.Count -ne 1) { throw 'Bundled asset is not listed exactly once in assets.json.' }
# Windows PowerShell 5.1 Get-FileHash uses a pipeline that inherits -WhatIf.
# This is read-only validation and must run before the installation decision.
$sha256 = [Security.Cryptography.SHA256]::Create()
$assetStream = $null
try {
    $assetStream = [IO.File]::OpenRead($assetPath)
    $actualHash = ([BitConverter]::ToString($sha256.ComputeHash($assetStream))).Replace('-', '').ToLowerInvariant()
} finally {
    if ($null -ne $assetStream) { $assetStream.Dispose() }
    $sha256.Dispose()
}
if ($actualHash -ne $entry[0].sha256) { throw 'Bundled asset checksum mismatch. Obtain a clean copy of the package.' }
$installedRoot = Join-Path $env:APPDATA ("McNeel\Rhinoceros\packages\$RhinoVersion.0\Rhino-MCP-Platform")
if (Test-Path -LiteralPath $installedRoot) {
    $existing = @(Get-ChildItem -LiteralPath $installedRoot -Directory -ErrorAction SilentlyContinue)
    if ($existing.Count -gt 0) { throw "Rhino-MCP-Platform already has an installation at $installedRoot. Keep the existing installation; use MCPConnect/configure-mcp.ps1. This helper will not downgrade or replace it." }
}
Write-Output "Verified SHA256: $actualHash"
Write-Output "Local package: $assetPath"
if ($PSCmdlet.ShouldProcess($RhinoSystem, "Install local official Rhino-MCP-Platform 0.1.5 with Yak")) {
    & $yakPath install $assetPath
    if ($LASTEXITCODE -ne 0) { throw "Yak exited with code $LASTEXITCODE. Read the output before retrying." }
    Write-Output 'Restart Rhino after saving your work. Run MCPConnect, then create the agent configuration. A successful install is not an end-to-end modeling test.'
}
