# -*- coding: utf-8 -*-
"""Portable parameter contracts and analytic recipes; standard library only.

This module does not import Rhino/Grasshopper, bake geometry, or claim to be
a .gh definition. Native builders consume its validated analytic recipe.
Commands: schema, validate, recipe, cases. No network or third-party packages.
"""
from __future__ import print_function
import argparse
import copy
import hashlib
import json
import math
import os
import re
import sys
import uuid
from decimal import Decimal, InvalidOperation, ROUND_FLOOR

CONTRACT_VERSION = '1.0.0'
BUILDER_VERSION = '1.0.0'
UNIT_TO_METERS = {'mm': Decimal('0.001'), 'cm': Decimal('0.01'), 'm': Decimal('1')}
MAX_FEATURES = 10000
try:
    INTEGER_TYPES = (int, long)
    STRING_TYPES = (basestring,)
except NameError:
    INTEGER_TYPES = (int,)
    STRING_TYPES = (str,)


def _field(kind, minimum, maximum, meaning):
    return {'type': kind, 'minimum_si': minimum, 'maximum_si': maximum, 'meaning': meaning}


SCHEMAS = {
    'perforated_panel': {
        'parameters': {
            'panel_width': _field('length', .005, 100, 'X extent'),
            'panel_height': _field('length', .005, 100, 'Y extent'),
            'plate_thickness': _field('length', .0001, 1, 'Z thickness'),
            'edge_margin': _field('length', 0, 10, 'Minimum material from hole edge to panel boundary'),
            'hole_diameter': _field('length', .0001, 5, 'Circular through-hole diameter'),
            'pitch_x': _field('length', .0001, 10, 'Unjittered column pitch'),
            'pitch_y': _field('length', .0001, 10, 'Unjittered row pitch'),
            'minimum_web': _field('length', .0001, 1, 'Minimum material between holes'),
            'jitter_fraction': _field('number', 0, .2, 'Per-axis center jitter / corresponding pitch')},
        'dependencies': {
            'derived.jitter': ['parameters.pitch_x', 'parameters.pitch_y', 'parameters.jitter_fraction'],
            'derived.hole_counts': ['parameters.panel_width', 'parameters.panel_height', 'parameters.edge_margin',
                                    'parameters.hole_diameter', 'parameters.pitch_x', 'parameters.pitch_y', 'derived.jitter'],
            'derived.hole_centers': ['derived.hole_counts', 'derived.jitter', 'seed'],
            'derived.open_area_ratio': ['derived.hole_counts', 'parameters.hole_diameter',
                                        'parameters.panel_width', 'parameters.panel_height']}},
    'rib_array': {
        'parameters': {
            'span': _field('length', .005, 100, 'Array extent along X'),
            'rib_length': _field('length', .005, 100, 'Each rib extent along Y'),
            'rib_height': _field('length', .001, 10, 'Nominal Z height'),
            'rib_thickness': _field('length', .0001, 1, 'Each rib extent along X'),
            'edge_margin': _field('length', 0, 10, 'Material-space setback at both X ends'),
            'minimum_clear_gap': _field('length', 0, 10, 'Required space between adjacent ribs'),
            'count': _field('integer', 1, 1000, 'Number of independently identified ribs'),
            'height_variation_fraction': _field('number', 0, .8, 'Seeded symmetric variation / nominal height')},
        'dependencies': {
            'derived.rib_spacing': ['parameters.span', 'parameters.rib_thickness', 'parameters.edge_margin', 'parameters.count'],
            'derived.rib_centers': ['derived.rib_spacing', 'parameters.count', 'parameters.span'],
            'derived.rib_heights': ['parameters.rib_height', 'parameters.height_variation_fraction', 'parameters.count', 'seed'],
            'derived.total_volume': ['derived.rib_heights', 'parameters.rib_thickness', 'parameters.rib_length']}}
}


class ParameterError(ValueError):
    def __init__(self, errors):
        self.errors = errors if isinstance(errors, list) else [errors]
        ValueError.__init__(self, '; '.join(self.errors))


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, INTEGER_TYPES + (float, Decimal)):
        raise ParameterError(label + ': expected a finite number, not bool/string')
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ParameterError(label + ': invalid numeric value')
    if not result.is_finite():
        raise ParameterError(label + ': NaN/Infinity are not accepted')
    return result


def _decimal_text(value):
    text = format(value.normalize(), 'f')
    return '0' if value == 0 else text


def canonical_hash(value):
    encoded = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)
    return hashlib.sha256(encoded.encode('ascii')).hexdigest()


def topological_order(graph):
    """Stable order; unknown dependencies/cycles are contract errors."""
    pending = dict((key, set(values)) for key, values in graph.items())
    missing = sorted(set(dep for values in pending.values() for dep in values) - set(pending))
    if missing:
        raise ParameterError('Unknown DAG dependencies: ' + ', '.join(missing))
    order = []
    while pending:
        ready = sorted(key for key, dependencies in pending.items() if not dependencies)
        if not ready:
            raise ParameterError('Dependency cycle: ' + ', '.join(sorted(pending)))
        for key in ready:
            order.append(key)
            del pending[key]
        for dependencies in pending.values():
            dependencies.difference_update(ready)
    return order


def _source(config):
    source = config.get('source', {})
    if not isinstance(source, dict) or set(source) - set(['3dm_relative_path', 'sha256', 'object_ids']):
        raise ParameterError('source must contain only 3dm_relative_path, sha256, object_ids')
    path = source.get('3dm_relative_path')
    digest = source.get('sha256')
    ids = source.get('object_ids', [])
    if not isinstance(ids, list):
        raise ParameterError('source.object_ids must be a list')
    try:
        ids = [str(uuid.UUID(value)) for value in ids]
    except (ValueError, TypeError, AttributeError):
        raise ParameterError('source.object_ids must contain valid GUID strings')
    if len(ids) != len(set(ids)):
        raise ParameterError('source.object_ids contains duplicates')
    if path is not None:
        if not isinstance(path, STRING_TYPES) or not path or os.path.isabs(path) or ':' in path:
            raise ParameterError('source.3dm_relative_path must be a portable relative path')
        if '..' in path.replace('\\', '/').split('/') or not path.lower().endswith('.3dm'):
            raise ParameterError('source path must stay in the delivery folder and end in .3dm')
    if digest is not None and (not isinstance(digest, STRING_TYPES) or not re.match(r'^[a-fA-F0-9]{64}$', digest)):
        raise ParameterError('source.sha256 must be 64 hexadecimal characters')
    if bool(path) != bool(digest) or (ids and not path):
        raise ParameterError('Referenced source requires its relative .3dm path and SHA-256 together')
    return {'3dm_relative_path': path, 'sha256': digest.lower() if digest else None, 'object_ids': ids}


def _random01(seed, feature, channel):
    # Index-addressed SHA-256 noise does not depend on iteration order or the
    # global random generator. Changing feature count leaves existing IDs stable.
    key = '%d|%s|%s' % (seed, feature, channel)
    return int(hashlib.sha256(key.encode('ascii')).hexdigest()[:13], 16) / float(16 ** 13)


def _cross_constraints(kind, p):
    errors = []
    if kind == 'perforated_panel':
        diameter = p['hole_diameter']
        jitter_x = p['jitter_fraction'] * p['pitch_x']
        jitter_y = p['jitter_fraction'] * p['pitch_y']
        if p['edge_margin'] < p['minimum_web']:
            errors.append('edge_margin must be >= minimum_web')
        if p['plate_thickness'] > min(p['panel_width'], p['panel_height']) / 4:
            errors.append('plate_thickness must be <= one quarter of the smaller panel dimension')
        for axis, extent, jitter in [('x', p['panel_width'], jitter_x), ('y', p['panel_height'], jitter_y)]:
            pitch = p['pitch_' + axis]
            if pitch - 2 * jitter - diameter < p['minimum_web']:
                errors.append('pitch_%s must preserve minimum_web after worst-case opposing jitter' % axis)
            if extent < 2 * (p['edge_margin'] + diameter / 2 + jitter):
                errors.append('panel extent %s cannot contain even one safe hole' % axis)
        if errors:
            raise ParameterError(errors)
        usable_x = p['panel_width'] - 2 * (p['edge_margin'] + diameter / 2 + jitter_x)
        usable_y = p['panel_height'] - 2 * (p['edge_margin'] + diameter / 2 + jitter_y)
        nx = int((usable_x / p['pitch_x']).to_integral_value(rounding=ROUND_FLOOR)) + 1
        ny = int((usable_y / p['pitch_y']).to_integral_value(rounding=ROUND_FLOOR)) + 1
        if nx * ny > MAX_FEATURES:
            raise ParameterError('Hole count exceeds the explicit %d-feature recipe budget' % MAX_FEATURES)
        return {'columns': nx, 'rows': ny, 'feature_count': nx * ny,
                'jitter_x_m': float(jitter_x), 'jitter_y_m': float(jitter_y),
                'guaranteed_web_x_m': float(p['pitch_x'] - 2 * jitter_x - diameter),
                'guaranteed_web_y_m': float(p['pitch_y'] - 2 * jitter_y - diameter),
                'open_area_ratio': nx * ny * math.pi * float(diameter) ** 2 / 4 /
                                   float(p['panel_width'] * p['panel_height'])}
    count = int(p['count'])
    usable = p['span'] - 2 * p['edge_margin'] - p['rib_thickness']
    if usable < 0:
        errors.append('span must contain rib_thickness + two edge margins')
    spacing = usable / (count - 1) if count > 1 else Decimal(0)
    gap = spacing - p['rib_thickness'] if count > 1 else None
    if count > 1 and gap < p['minimum_clear_gap']:
        errors.append('count/thickness/span leave less than minimum_clear_gap')
    if errors:
        raise ParameterError(errors)
    return {'feature_count': count, 'rib_spacing_m': float(spacing),
            'clear_gap_m': float(gap) if gap is not None else None,
            'minimum_height_m': float(p['rib_height'] * (1 - p['height_variation_fraction'])),
            'maximum_height_m': float(p['rib_height'] * (1 + p['height_variation_fraction']))}


def validate_parameters(config):
    if not isinstance(config, dict):
        raise ParameterError('Top-level input must be a JSON object')
    allowed = set(['contract_version', 'builder', 'units', 'seed', 'parameters', 'source', 'provenance'])
    unknown = sorted(set(config) - allowed)
    if unknown:
        raise ParameterError('Unknown top-level fields: ' + ', '.join(unknown))
    if config.get('contract_version') != CONTRACT_VERSION:
        raise ParameterError('Unsupported contract_version; migrate explicitly to ' + CONTRACT_VERSION)
    builder = config.get('builder')
    if not isinstance(builder, dict) or set(builder) != set(['id', 'version']):
        raise ParameterError('builder requires exactly id and version')
    kind = builder['id']
    if not isinstance(kind, STRING_TYPES) or kind not in SCHEMAS or builder['version'] != BUILDER_VERSION:
        raise ParameterError('Unsupported builder id/version')
    units = config.get('units')
    if not isinstance(units, STRING_TYPES) or units not in UNIT_TO_METERS:
        raise ParameterError('units must be exactly mm, cm or m')
    seed = config.get('seed')
    if isinstance(seed, bool) or not isinstance(seed, INTEGER_TYPES) or not 0 <= seed <= 2147483647:
        raise ParameterError('seed must be an explicit integer in [0, 2147483647]')
    raw = config.get('parameters')
    schema = SCHEMAS[kind]['parameters']
    if not isinstance(raw, dict):
        raise ParameterError('parameters must be an object')
    if set(raw) != set(schema):
        raise ParameterError('Parameter keys differ; missing=%s unknown=%s' %
                             (sorted(set(schema) - set(raw)), sorted(set(raw) - set(schema))))
    normalized = {}
    for name, spec in schema.items():
        value = raw[name]
        if spec['type'] == 'integer' and (isinstance(value, bool) or not isinstance(value, INTEGER_TYPES)):
            raise ParameterError(name + ': expected an integer, no implicit rounding')
        number = _number(value, name)
        if spec['type'] == 'length':
            number *= UNIT_TO_METERS[units]
        if number < Decimal(str(spec['minimum_si'])) or number > Decimal(str(spec['maximum_si'])):
            raise ParameterError('%s: outside [%s, %s] %s' % (name, spec['minimum_si'], spec['maximum_si'],
                                 'meters' if spec['type'] == 'length' else 'dimensionless'))
        normalized[name] = number
    source = _source(config)
    provenance = config.get('provenance', {})
    if not isinstance(provenance, dict) or set(provenance) - set(['run_id', 'generation_tag_key']):
        raise ParameterError('provenance allows only run_id and generation_tag_key')
    for key, value in provenance.items():
        if not isinstance(value, STRING_TYPES) or not re.match(r'^[A-Za-z0-9_-]{1,80}$', value):
            raise ParameterError('provenance.%s must be a portable 1-80 character identifier' % key)
    derived = _cross_constraints(kind, normalized)
    graph = dict(('parameters.' + key, []) for key in schema)
    graph['seed'] = []
    graph.update(SCHEMAS[kind]['dependencies'])
    canonical = {'contract_version': CONTRACT_VERSION, 'builder': builder,
                 'units': 'm', 'seed': seed,
                 'parameters_si_decimal': dict((key, _decimal_text(value)) for key, value in normalized.items()),
                 'source_sha256': source['sha256'], 'source_object_ids': source['object_ids']}
    values = dict((key, int(value) if schema[key]['type'] == 'integer' else float(value))
                  for key, value in normalized.items())
    return {'valid': True, 'builder': copy.deepcopy(builder), 'input_units': units,
            'normalized_units': 'm', 'parameters_si': values, 'derived': derived,
            'seed': seed, 'noise_algorithm': 'sha256-feature-channel-v1', 'source': source,
            'provenance': copy.deepcopy(provenance), 'canonical_inputs': canonical,
            'parameter_hash': canonical_hash(canonical), 'dependency_graph': graph,
            'dependency_order': topological_order(graph)}


def build_recipe(config):
    """Revalidate before deriving an ordered, deterministic analytic recipe."""
    report = validate_parameters(config)
    p, d, seed = report['parameters_si'], report['derived'], report['seed']
    features = []
    if report['builder']['id'] == 'perforated_panel':
        start_x = (p['panel_width'] - (d['columns'] - 1) * p['pitch_x']) / 2
        start_y = (p['panel_height'] - (d['rows'] - 1) * p['pitch_y']) / 2
        for row in range(d['rows']):
            for column in range(d['columns']):
                ident = 'panel/hole/%d/%d' % (row, column)
                x = start_x + column * p['pitch_x'] + (2 * _random01(seed, ident, 'x') - 1) * d['jitter_x_m']
                y = start_y + row * p['pitch_y'] + (2 * _random01(seed, ident, 'y') - 1) * d['jitter_y_m']
                features.append({'id': ident, 'kind': 'circular_through_cut', 'path': [row], 'item_index': column,
                                 'center_xy_m': [x, y], 'radius_m': p['hole_diameter'] / 2})
        construction = {'kind': 'extruded_perforated_rectangle', 'plane': 'WorldXY local coordinates',
            'outline_xy_m': [[0, 0], [p['panel_width'], 0], [p['panel_width'], p['panel_height']],
                             [0, p['panel_height']], [0, 0]],
            'z_interval_m': [0, p['plate_thickness']],
            'operation': 'Build planar region with circular inner loops, validate holes, extrude and cap; or subtract validated oversized cutters from the panel solid.'}
    else:
        for index in range(d['feature_count']):
            ident = 'rib/%d' % index
            center = p['span'] / 2 if d['feature_count'] == 1 else p['edge_margin'] + p['rib_thickness'] / 2 + index * d['rib_spacing_m']
            h = p['rib_height'] * (1 + p['height_variation_fraction'] * (2 * _random01(seed, ident, 'height') - 1))
            features.append({'id': ident, 'kind': 'box', 'path': [index], 'item_index': 0,
                'min_m': [center - p['rib_thickness'] / 2, 0, 0],
                'max_m': [center + p['rib_thickness'] / 2, p['rib_length'], h]})
        construction = {'kind': 'independent_rib_solids', 'operation': 'Create one closed box per branch; preserve stable feature IDs and avoid unintended union.'}
        d['actual_total_volume_m3'] = sum((f['max_m'][0] - f['min_m'][0]) * p['rib_length'] * f['max_m'][2] for f in features)
    recipe = {'units': 'm', 'construction': construction, 'features': features,
              'data_tree_contract': 'path is an explicit GH_Path index tuple; item_index is local within the branch'}
    report['recipe'] = recipe
    report['recipe_hash'] = canonical_hash(recipe)
    implementation_hash = None
    if globals().get('__file__') and os.path.isfile(__file__):
        with open(__file__, 'rb') as stream:
            implementation_hash = hashlib.sha256(stream.read()).hexdigest()
    report['implementation_sha256'] = implementation_hash
    report['native_builder_sha256'] = None
    report['delivery_state'] = 'analytic_recipe_only; no Rhino geometry or .gh file has been generated or baked'
    return report


def verify_source_file(config, root):
    """Verify source bytes only. GUID/geometry verification requires Rhino."""
    source = _source(config)
    if not source['3dm_relative_path']:
        return {'required': False, 'sha256_checked': False, 'object_guids_checked': False}
    root = os.path.realpath(os.path.abspath(root))
    path = os.path.realpath(os.path.join(root, source['3dm_relative_path']))
    if not os.path.normcase(path).startswith(os.path.normcase(root) + os.sep):
        raise ParameterError('Source file resolves outside source_root')
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        while True:
            data = stream.read(1024 * 1024)
            if not data:
                break
            digest.update(data)
    if digest.hexdigest() != source['sha256']:
        raise ParameterError('Referenced source SHA-256 differs; re-inspect and version the inputs')
    return {'required': True, 'sha256_checked': True, 'sha256': digest.hexdigest(),
            'object_guids_checked': False, 'geometry_parsed': False}


def example_parameters(kind='perforated_panel'):
    parameters = ({'panel_width': 1200, 'panel_height': 600, 'plate_thickness': 12, 'edge_margin': 30,
                   'hole_diameter': 20, 'pitch_x': 60, 'pitch_y': 60, 'minimum_web': 8, 'jitter_fraction': .08}
                  if kind == 'perforated_panel' else
                  {'span': 3000, 'rib_length': 2000, 'rib_height': 300, 'rib_thickness': 20,
                   'edge_margin': 50, 'minimum_clear_gap': 40, 'count': 20, 'height_variation_fraction': .15})
    if kind not in SCHEMAS:
        raise ParameterError('Unknown example type')
    return {'contract_version': CONTRACT_VERSION, 'builder': {'id': kind, 'version': BUILDER_VERSION},
            'units': 'mm', 'seed': 2026, 'parameters': parameters,
            'source': {'3dm_relative_path': None, 'sha256': None, 'object_ids': []},
            'provenance': {'run_id': kind + '_r01', 'generation_tag_key': 'AGENT_RUN_ID'}}


def generate_cases(kind='perforated_panel'):
    baseline = example_parameters(kind)
    cases = []
    def add(name, valid, mutate):
        candidate = copy.deepcopy(baseline)
        mutate(candidate)
        cases.append({'case_id': name, 'expect_valid': valid, 'config': candidate})
    add('default_valid', True, lambda c: None)
    if kind == 'perforated_panel':
        add('one_hole_exact_edge_clearance', True, lambda c: c['parameters'].update(
            panel_width=30, panel_height=30, plate_thickness=1, edge_margin=10, hole_diameter=10,
            pitch_x=20, pitch_y=20, minimum_web=5, jitter_fraction=0))
        add('web_exactly_at_minimum', True, lambda c: c['parameters'].update(
            hole_diameter=20, pitch_x=28, pitch_y=28, jitter_fraction=0, minimum_web=8))
        add('holes_collide_after_jitter', False, lambda c: c['parameters'].update(pitch_x=25, jitter_fraction=.1))
        add('no_hole_fits', False, lambda c: c['parameters'].update(panel_width=30))
        add('geometry_budget_exceeded', False, lambda c: c['parameters'].update(panel_width=100000, panel_height=100000))
    else:
        add('single_rib_no_division_by_zero', True, lambda c: c['parameters'].update(count=1))
        add('single_rib_exact_edge_clearance', True, lambda c: c['parameters'].update(count=1, span=120))
        add('gap_exactly_at_minimum', True, lambda c: c['parameters'].update(span=1260, count=20))
        add('too_many_ribs_for_gap', False, lambda c: c['parameters'].update(count=100))
        add('fractional_count', False, lambda c: c['parameters'].update(count=5.5))
    add('unknown_units', False, lambda c: c.update(units='inch'))
    add('boolean_seed', False, lambda c: c.update(seed=True))
    add('unknown_parameter', False, lambda c: c['parameters'].update(unused_knob=1))
    add('unsupported_builder_version', False, lambda c: c['builder'].update(version='99.0.0'))
    add('unhashed_source_reference', False, lambda c: c.update(source={'3dm_relative_path': 'source.3dm', 'sha256': None, 'object_ids': []}))
    for name, spec in sorted(SCHEMAS[kind]['parameters'].items()):
        scale = float(UNIT_TO_METERS[baseline['units']]) if spec['type'] == 'length' else 1.0
        for side, bound in [('minimum', spec['minimum_si']), ('maximum', spec['maximum_si'])]:
            value = bound / scale
            if spec['type'] == 'integer':
                value = int(value)
            candidate = copy.deepcopy(baseline)
            candidate['parameters'][name] = value
            try:
                validate_parameters(candidate)
            except ParameterError:
                pass  # A scalar bound can be infeasible under cross-field constraints.
            else:
                cases.append({'case_id': name + '_' + side + '_valid_boundary', 'expect_valid': True, 'config': candidate})
        delta = max(abs(spec['minimum_si']) * .1, .00001) / scale
        invalid = (spec['minimum_si'] / scale - delta)
        if spec['type'] == 'integer':
            invalid = int(spec['minimum_si']) - 1
        add(name + '_below_type_bound', False, lambda c, key=name, value=invalid: c['parameters'].update({key: value}))
    return cases


def load_parameters(path):
    with open(path, 'rb') as stream:
        return json.loads(stream.read().decode('utf-8-sig'), parse_float=Decimal)


def _json_default(value):
    if isinstance(value, Decimal):
        return float(value)
    raise TypeError('Cannot serialize ' + type(value).__name__)


def write_new_json(path, output):
    """Atomically refuse an existing output; common Python 2.7/3 syntax."""
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0)
    descriptor = os.open(path, flags, 0o666)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(output.encode('utf-8'))


def cli(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['schema', 'validate', 'recipe', 'cases'])
    parser.add_argument('parameters_file', nargs='?')
    parser.add_argument('--kind', choices=sorted(SCHEMAS), default='perforated_panel')
    parser.add_argument('--out', help='New JSON output path; an existing file is not overwritten')
    parser.add_argument('--source-root', help='Optional delivery directory: verify referenced source .3dm SHA-256')
    args = parser.parse_args(argv)
    try:
        if args.command == 'schema':
            result = {'contract_version': CONTRACT_VERSION, 'builder_version': BUILDER_VERSION,
                      'normalized_length_unit': 'm', 'schemas': SCHEMAS}
        elif args.command == 'cases':
            result = {'builder': args.kind, 'cases': generate_cases(args.kind)}
        else:
            if not args.parameters_file:
                raise ParameterError('parameters_file is required')
            config = load_parameters(args.parameters_file)
            result = validate_parameters(config) if args.command == 'validate' else build_recipe(config)
            result['source_verification'] = (verify_source_file(config, args.source_root) if args.source_root
                                             else {'sha256_checked': False, 'object_guids_checked': False})
        output = json.dumps(result, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False, default=_json_default)
        if args.out:
            write_new_json(args.out, output)
        print(output)
        return 0
    except (ParameterError, ValueError, IOError) as exc:
        errors = exc.errors if isinstance(exc, ParameterError) else [str(exc)]
        print(json.dumps({'valid': False, 'errors': errors}, ensure_ascii=True))
        return 2


if __name__ == '__main__':
    sys.exit(cli())
