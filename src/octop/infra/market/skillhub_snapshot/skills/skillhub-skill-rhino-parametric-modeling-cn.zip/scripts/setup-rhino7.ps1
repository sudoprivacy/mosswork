#requires -Version 5.1
[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Low')]
param([string]$RhinoSystem, [int]$RhinoPid=0, [switch]$PrepareOnly, [int]$WaitSeconds=45)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'setup-common.ps1')
$RhinoSystem = Resolve-RhinoSystem -RhinoVersion '7' -RhinoSystem $RhinoSystem
$exe=Join-Path $RhinoSystem 'Rhino.exe'
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Licensed Rhino 7 must be installed first.' }
if ((Get-Item -LiteralPath $exe).VersionInfo.FileMajorPart -ne 7) { throw 'The executable is not Rhino 7.' }
$bridge=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'rhino7\bridge.py'))
$command='_-RunPythonScript "' + $bridge + '"'
. (Join-Path $PSScriptRoot 'rhino7\transport.ps1')
$running=@(Get-Process Rhino -ErrorAction SilentlyContinue | Where-Object { $_.MainModule.FileVersionInfo.FileMajorPart -eq 7 })
if ($RhinoPid -gt 0) {
    $running=@($running | Where-Object Id -eq $RhinoPid)
    if ($running.Count -eq 0) { throw 'Requested Rhino 7 PID is not running.' }
}
if ($PrepareOnly -or $WhatIfPreference) {
    [ordered]@{status='prepared'; runtime='Rhino7 IronPython2.7'; bridge=$bridge; command=$command; downloads_required=$false; launches_process=$false} | ConvertTo-Json
    return
}
if ($running.Count -gt 1) { throw 'Multiple Rhino 7 processes exist. Pass -RhinoPid for the intended document.' }
if ($running.Count -eq 0) {
    if (-not $PSCmdlet.ShouldProcess($exe,'Start Rhino 7 and load the local bridge in a new document')) { return }
    # Windows argv escaping: embedded quotes must survive Start-Process into Rhino's /runscript value.
    $args='/nosplash /notemplate /runscript="' + $command.Replace('"','\"') + '"'
    $process=Start-Process -FilePath $exe -ArgumentList $args -WindowStyle Hidden -PassThru
    $RhinoPid=$process.Id
    $started=$true
} else { $RhinoPid=$running[0].Id; $started=$false }
$lastError = 'No bridge discovery record yet.'
$deadline=[DateTime]::UtcNow.AddSeconds([Math]::Max(0,[Math]::Min(60,$WaitSeconds)))
do {
    if ($started) {
        $process.Refresh()
        if ($process.HasExited) {
            [ordered]@{status='startup_failed'; rhino_pid=$RhinoPid; exit_code=$process.ExitCode; command=$command; instruction='Rhino exited before the bridge became ready. Open Rhino normally and resolve license/startup messages yourself; then run the bridge command. No license settings were changed.'} | ConvertTo-Json
            return
        }
    }
    try {
        $session=Get-Rhino7Session -RhinoPid $RhinoPid
        $reply=Invoke-Rhino7Request -Method get_context -Parameters @{} -RhinoPid $RhinoPid
        if ($reply.status -eq 'ok') {
            [ordered]@{status='ready'; rhino_pid=$RhinoPid; context=$reply.result; downloads_required=$false} | ConvertTo-Json -Depth 15
            return
        }
    } catch { $lastError = $_.Exception.Message }
    if (-not $started) { break }
    Start-Sleep -Milliseconds 500
} while ([DateTime]::UtcNow -lt $deadline)
if (-not (Get-Process -Id $RhinoPid -ErrorAction SilentlyContinue)) {
    [ordered]@{status='startup_failed';rhino_pid=$RhinoPid;last_error=$lastError;instruction='Rhino process is no longer running. Open Rhino normally and inspect license/startup errors before retrying.'} | ConvertTo-Json
    return
}
[ordered]@{status='attach_required';last_error=$lastError;possible_blockers=@('license/startup dialog','template or plugin dialog','bridge command not loaded'); rhino_pid=$RhinoPid; command=$command; instruction='In this Rhino 7 window, run command once, then rerun setup with -RhinoPid. Existing documents are never closed or restarted.'} | ConvertTo-Json
