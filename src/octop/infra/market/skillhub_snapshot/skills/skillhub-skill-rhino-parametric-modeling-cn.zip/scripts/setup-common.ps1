# Shared read-only environment inspection, Windows PowerShell 5.1+.
function Resolve-RhinoSystem {
    param([string]$RhinoVersion, [string]$RhinoSystem)
    if ($RhinoSystem) { return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RhinoSystem) }
    $candidates = @()
    foreach ($key in @("HKLM:\SOFTWARE\McNeel\Rhinoceros\$RhinoVersion.0\Install", "HKLM:\SOFTWARE\WOW6432Node\McNeel\Rhinoceros\$RhinoVersion.0\Install")) {
        $record = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($record) {
            if ($record.PSObject.Properties.Name -contains 'Path' -and $record.Path) { $candidates += [string]$record.Path }
            if ($record.PSObject.Properties.Name -contains 'InstallPath' -and $record.InstallPath) { $candidates += Join-Path $record.InstallPath 'System' }
        }
    }
    $candidates += Join-Path $env:ProgramFiles "Rhino $RhinoVersion\System"
    foreach ($candidate in @($candidates | Select-Object -Unique)) {
        $exe = Join-Path $candidate 'Rhino.exe'
        if ((Test-Path -LiteralPath $exe -PathType Leaf) -and (Get-Item -LiteralPath $exe).VersionInfo.FileMajorPart -eq [int]$RhinoVersion) {
            return [IO.Path]::GetFullPath($candidate)
        }
    }
    throw "Rhino $RhinoVersion was not found in registry/default paths. Install and open a licensed supported Rhino, or pass -RhinoSystem explicitly."
}

function Get-RhinoInstallationState {
    param([string]$InstalledRoot)
    if (Test-Path -LiteralPath $InstalledRoot -PathType Leaf) { return 'Incomplete' }
    $directories = @(Get-ChildItem -LiteralPath $InstalledRoot -Directory -ErrorAction SilentlyContinue)
    if ($directories.Count -eq 0) {
        if (@(Get-ChildItem -LiteralPath $InstalledRoot -Force -ErrorAction SilentlyContinue).Count -gt 0) { return 'Incomplete' }
        return 'Missing'
    }
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'win-arm64' } else { 'win-x64' }
    foreach ($directory in $directories) {
        $plugin = Join-Path $directory.FullName 'net8.0\RhinoMcpPlatform.rhp'
        $router = Join-Path $directory.FullName "router\$arch\rhino-mcp-router.exe"
        $manifest = Join-Path $directory.FullName 'manifest.yml'
        if ((Test-Path -LiteralPath $plugin -PathType Leaf) -and (Test-Path -LiteralPath $router -PathType Leaf) -and
            (Test-Path -LiteralPath $manifest -PathType Leaf) -and (Get-Item -LiteralPath $plugin).Length -gt 0 -and
            (Get-Item -LiteralPath $router).Length -gt 0 -and (Get-Item -LiteralPath $manifest).Length -gt 0) { return 'FilesPresent' }
    }
    return 'Incomplete'
}
