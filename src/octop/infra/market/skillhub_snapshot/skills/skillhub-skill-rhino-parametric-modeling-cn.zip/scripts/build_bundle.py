"""Build a portable ZIP + full single-file handbook using only Python stdlib.

Run from any working directory: python scripts/build_bundle.py --out-dir PATH
No source models, caches, user settings or dependency folders are packaged.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.0.3'
PREFIX = 'Rhino神笔_AI建模与参考图还原_Rhino7-8-9兼容版'
DISPLAY_NAME = 'Rhino 神笔｜AI 建模与参考图还原'
ALLOWED = {'.md', '.py', '.ps1', '.json', '.txt'}


def files():
    result = []
    for path in ROOT.rglob('*'):
        relative = path.relative_to(ROOT)
        if not path.is_file() or path.is_symlink():
            continue
        if any(part.startswith('.') or part == '__pycache__' for part in relative.parts):
            continue
        if path.name == 'FILE_MANIFEST.json':
            continue
        if path.suffix.lower() in ALLOWED:
            result.append(path)
    return sorted(result, key=lambda item: item.relative_to(ROOT).as_posix())


def anchor(path):
    return 'file-' + re.sub(r'[^a-z0-9-]', '-', path.relative_to(ROOT).as_posix().lower())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir', required=True)
    args = parser.parse_args()
    output = Path(args.out_dir).resolve()
    if output == ROOT or ROOT in output.parents:
        raise ValueError('Place release artifacts outside the skill folder')
    output.mkdir(parents=True, exist_ok=True)
    paths = files()
    forbidden = ['GM' + '04', '20260907_' + 'tailand', 'stadium-' + 'iteration']
    for path in paths:
        if path.suffix == '.yak':
            continue
        source = path.read_text(encoding='utf-8')
        if any(value in source for value in forbidden):
            raise ValueError('Project-specific identifier in ' + path.relative_to(ROOT).as_posix())
    manifest = {'name': 'rhino-parametric-modeling-cn', 'display_name': DISPLAY_NAME, 'version': VERSION, 'profile': 'skillhub-rhino7-8-9',
                'files': [{'file': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size,
                           'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
    manifest_path = ROOT / 'FILE_MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if len(paths) + 1 > 200 or sum(p.stat().st_size for p in paths + [manifest_path]) > 10485760:
        raise ValueError('SkillHub expanded file count or total size limit exceeded')
    archive_path = output / (PREFIX + '_v' + VERSION + '.zip')
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in paths + [manifest_path]:
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2026, 9, 8, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError('Corrupt archive member: ' + bad)
        for item in manifest['files']:
            data = archive.read(item['file'])
            if hashlib.sha256(data).hexdigest() != item['sha256']:
                raise ValueError('Archive hash mismatch: ' + item['file'])

    chapter_order = ['14-first-run-quickstart.md', '13-rhino7-ready-workflow.md', '00-install-and-domestic-agents.md', '01-official-platform.md',
                     '11-modeling-judgment-and-iteration.md',
                     '08-parametric-modeling-core.md', '09-model-types-and-patterns.md', '12-first-run-and-skillhub.md',
                     '10-grasshopper-and-parametric-delivery.md', '05-rhino-runtime-and-delivery.md',
                     '02-reference-and-massing.md', '03-topology-and-sections.md',
                     '04-detail-and-validation.md', '07-agent-prompts.md', '06-case-study.md']
    markdown = [ROOT / 'SKILL.md'] + [ROOT / 'references' / name for name in chapter_order]
    markdown += [ROOT / 'adapter' / 'README.md'] + sorted((ROOT / 'templates').glob('*.md'))
    markdown += [ROOT / 'scripts' / 'parametric' / 'README.md']
    markdown += [ROOT / 'tests' / 'modeling-behavior-cases.md',
                 ROOT / 'tests' / 'simulation-report.md',
                 ROOT / 'VALIDATION.md', ROOT / 'THIRD_PARTY_NOTICES.md']
    code = [ROOT / 'adapter' / 'rhino_stdio_adapter.py']
    code += sorted((ROOT / 'scripts' / 'rhino').glob('*.py'))
    code += sorted(p for p in (ROOT / 'scripts' / 'rhino7').iterdir() if p.is_file() and p.suffix in ALLOWED)
    code += sorted((ROOT / 'scripts').glob('*.ps1'))
    code += sorted(p for p in (ROOT / 'scripts' / 'parametric').glob('*.py') if not p.name.startswith('test_'))
    code += sorted((ROOT / 'scripts' / 'parametric').glob('*.json'))
    included = set(markdown + code)
    sections = ['# ' + DISPLAY_NAME + '：完整使用手册\n\n版本 ' + VERSION + '。覆盖空间判断与反馈迭代、通用参数/约束、曲线曲面、NURBS/SubD/Mesh、Grasshopper、跨类型建模、重建验证及可编辑交付；历史模型保留为可选复盘案例。此文件合并技能、手册、模板及可执行脚本源码，方便查阅或导入知识库。**实际使用只需同名ZIP，由首次初始化脚本获取所需官方插件并校验**；本上传包不嵌入二进制插件，不要求另领附件。小上下文 agent 先读 SKILL 入口，再按阶段查阅，不需一次加载全篇。\n\n']
    sections += ['- [%s](#%s)\n' % (p.relative_to(ROOT).as_posix(), anchor(p)) for p in markdown + code]
    def rewrite(path, text):
        def one(match):
            label, link = match.group(1), match.group(2)
            if '://' in link or link.startswith(('#', 'mailto:')):
                return match.group(0)
            target = (path.parent / link.split('#')[0]).resolve()
            if target in included:
                return '[%s](#%s)' % (label, anchor(target))
            if target.is_file() and ROOT in target.parents:
                return '%s（ZIP 内 `%s`）' % (label, target.relative_to(ROOT).as_posix())
            return match.group(0)
        return re.sub(r'\[([^\]]+)\]\(([^)]+)\)', one, text)
    for path in markdown:
        content = path.read_text(encoding='utf-8')
        if path.name == 'SKILL.md':
            content = re.sub(r'^---\n.*?\n---\n', '', content, count=1, flags=re.S)
        sections.append('\n\n---\n\n<a id="%s"></a>\n\n%s\n' % (anchor(path), rewrite(path, content)))
    for path in code:
        language = {'.ps1': 'powershell', '.json': 'json'}.get(path.suffix, 'python')
        sections.append('\n\n---\n\n<a id="%s"></a>\n\n# 源码：%s\n\n保存为 ZIP 中同名路径；依赖其他随包文件。\n\n````%s\n%s\n````\n' %
                        (anchor(path), path.relative_to(ROOT).as_posix(), language, path.read_text(encoding='utf-8')))
    handbook = output / (PREFIX + '_完整单文件版.md')
    handbook.write_text(''.join(sections), encoding='utf-8')
    digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
    (output / (archive_path.name + '.sha256.txt')).write_text(digest + '  ' + archive_path.name + '\n', encoding='utf-8')
    print(json.dumps({'zip': str(archive_path), 'zip_bytes': archive_path.stat().st_size,
                      'zip_sha256': digest, 'files_in_zip': len(paths) + 1,
                      'handbook': str(handbook), 'handbook_bytes': handbook.stat().st_size,
                      'handbook_characters': len(''.join(sections)),
                      'archive_verified': True}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
