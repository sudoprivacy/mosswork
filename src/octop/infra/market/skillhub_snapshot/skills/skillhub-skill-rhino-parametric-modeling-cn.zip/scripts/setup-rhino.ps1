#requires -Version 5.1
<#
.SYNOPSIS
Prepares and installs the pinned official Rhino-MCP-Platform package.
.DESCRIPTION
Requires a local licensed Rhino 8.29+ or Rhino 9 installation. Downloads only
the selected official YAK from files.mcneel.com, with certificate validation,
no redirects, no proxy, a 100 second deadline, and pinned SHA256/byte limits.
PrepareOnly verifies/downloads the package without calling Yak. WhatIf makes
no network request and writes no files. Existing installations are preserved.
This helper never restarts Rhino, changes models, or configures an agent.
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Low')]
param(
    [ValidateSet('7', '8', '9')][string]$RhinoVersion = '8',
    [string]$RhinoSystem,
    [string]$CacheDirectory,
    [switch]$PrepareOnly,
    [int]$RhinoPid = 0,
    [ValidateRange(0,60)][int]$WaitSeconds = 45
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'setup-common.ps1')

if ($RhinoVersion -eq '7') {
    & (Join-Path $PSScriptRoot 'setup-rhino7.ps1') -RhinoSystem $RhinoSystem -PrepareOnly:$PrepareOnly -WhatIf:$WhatIfPreference -RhinoPid $RhinoPid -WaitSeconds $WaitSeconds
    return
}

function Assert-LocalPath {
    param([string]$Path)
    $full = [IO.Path]::GetFullPath($Path)
    if ($full -notmatch '^[A-Za-z]:\\') { throw "Expected a local Windows path: $Path" }
    $current = $full
    while ($current) {
        try {
            if (([IO.File]::GetAttributes($current) -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Reparse points are not supported: $current"
            }
        } catch [IO.FileNotFoundException] {
        } catch [IO.DirectoryNotFoundException] {
        }
        $parent = [IO.Directory]::GetParent($current)
        if ($null -eq $parent) { break }
        $current = $parent.FullName
    }
}

function Get-VerifiedAssetHash {
    param([string]$Path, [object]$Entry)
    Assert-LocalPath $Path
    if (-not [IO.File]::Exists($Path)) { throw "Missing package file: $Path" }
    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try {
        if ($stream.Length -ne $Entry.bytes) { throw "Package size mismatch; existing files will not be overwritten: $Path" }
        $digest = [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace('-', '').ToLowerInvariant()
        if ($digest -cne $Entry.sha256) { throw "Package SHA256 mismatch; existing files will not be overwritten: $Path" }
        return $digest
    } finally {
        $hasher.Dispose()
        $stream.Dispose()
    }
}

function Save-OfficialAsset {
    param([string]$Destination, [object]$Entry)
    Add-Type -AssemblyName System.Net.Http
    $cacheRoot = [IO.Path]::GetDirectoryName($Destination)
    Assert-LocalPath $cacheRoot
    [void][IO.Directory]::CreateDirectory($cacheRoot)
    Assert-LocalPath $cacheRoot
    $partial = [IO.Path]::Combine($cacheRoot, '.rhino-download-' + [guid]::NewGuid().ToString('N') + '.part')
    $handler = $null
    $client = $null
    $response = $null
    $inputStream = $null
    $outputStream = $null
    $deadline = $null
    try {
        $handler = New-Object Net.Http.HttpClientHandler
        $handler.UseProxy = $false
        $handler.AllowAutoRedirect = $false
        $client = New-Object Net.Http.HttpClient($handler)
        $client.Timeout = [TimeSpan]::FromSeconds(100)
        $client.MaxResponseContentBufferSize = [long]$Entry.bytes
        $deadline = New-Object Threading.CancellationTokenSource
        $deadline.CancelAfter(100000)
        $response = $client.GetAsync([uri]$Entry.download_url,
            [Net.Http.HttpCompletionOption]::ResponseHeadersRead, $deadline.Token).GetAwaiter().GetResult()
        if ([int]$response.StatusCode -ne 200) { throw "Official download returned HTTP $([int]$response.StatusCode); redirects are not followed." }
        $contentLength = $response.Content.Headers.ContentLength
        if ($null -ne $contentLength -and $contentLength -ne $Entry.bytes) { throw 'Official download Content-Length differs from the pinned package size.' }
        $inputStream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
        $outputStream = [IO.File]::Open($partial, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $buffer = New-Object byte[] 65536
        $received = [long]0
        while ($true) {
            $read = $inputStream.ReadAsync($buffer, 0, $buffer.Length, $deadline.Token).GetAwaiter().GetResult()
            if ($read -eq 0) { break }
            $received += $read
            if ($received -gt $Entry.bytes) { throw 'Official download exceeded the pinned package size.' }
            $outputStream.Write($buffer, 0, $read)
        }
        $outputStream.Dispose()
        $outputStream = $null
        if ($received -ne $Entry.bytes) { throw 'Official download ended before the pinned package size.' }
        $digest = Get-VerifiedAssetHash $partial $Entry
        Assert-LocalPath $Destination
        # Same-directory File.Move publishes atomically and never overwrites.
        [IO.File]::Move($partial, $Destination)
        return $digest
    } finally {
        if ($null -ne $outputStream) { $outputStream.Dispose() }
        if ($null -ne $inputStream) { $inputStream.Dispose() }
        if ($null -ne $response) { $response.Dispose() }
        if ($null -ne $client) { $client.Dispose() }
        elseif ($null -ne $handler) { $handler.Dispose() }
        if ($null -ne $deadline) { $deadline.Dispose() }
        if ([IO.File]::Exists($partial)) {
            # Delete only this invocation's exact temporary file; no recursion.
            Assert-LocalPath $partial
            if ([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($partial)) -cne $cacheRoot -or
                [IO.Path]::GetFileName($partial) -cnotmatch '^\.rhino-download-[a-f0-9]{32}\.part$') {
                throw 'Refusing temporary-file cleanup outside the cache directory.'
            }
            [IO.File]::Delete($partial)
        }
    }
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'This setup helper requires Windows.' }
$RhinoSystem = Resolve-RhinoSystem -RhinoVersion $RhinoVersion -RhinoSystem $RhinoSystem
$RhinoSystem = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RhinoSystem)
Assert-LocalPath $RhinoSystem
$rhinoPath = [IO.Path]::Combine($RhinoSystem, 'Rhino.exe')
$yakPath = [IO.Path]::Combine($RhinoSystem, 'Yak.exe')
foreach ($path in @($rhinoPath, $yakPath)) {
    Assert-LocalPath $path
    if (-not [IO.File]::Exists($path)) { throw "Required executable missing: $path. Install a licensed supported Rhino first, or specify -RhinoSystem." }
}
$version = [Diagnostics.FileVersionInfo]::GetVersionInfo($rhinoPath)
if ($version.FileMajorPart -ne [int]$RhinoVersion) { throw 'Rhino executable major version does not match -RhinoVersion.' }
if ($RhinoVersion -eq '8' -and $version.FileMinorPart -lt 29) { throw 'The official Rhino 8 package requires Rhino 8.29 or later.' }
if (-not $env:APPDATA) { throw 'APPDATA is required to inspect existing Rhino packages.' }
$installedRoot = [IO.Path]::Combine($env:APPDATA, "McNeel\Rhinoceros\packages\$RhinoVersion.0\Rhino-MCP-Platform")
Assert-LocalPath $installedRoot
$installationState = Get-RhinoInstallationState $installedRoot
if ($installationState -eq 'Incomplete') { throw "Incomplete Rhino-MCP-Platform installation at $installedRoot. Existing files preserved. Repair using Rhino PackageManager after inspecting the directory; no automatic overwrite or reinstall." }
if ($installationState -eq 'FilesPresent') {
    [pscustomobject]@{
        Status = 'ExistingInstallation'; AssetPath = $null; Sha256 = $null
        RequiresRhinoRestart = $false; InstalledRoot = $installedRoot
        FilesVerified = $true; ConnectionVerified = $false
        Notes = 'Existing Rhino-MCP-Platform required files found; loading and connection are not yet verified. Installation preserved. In Rhino, run MCPConnect, then use configure-mcp.ps1 for your agent.'
    }
    return
}
if (-not $CacheDirectory) {
    if (-not $env:LOCALAPPDATA) { throw 'LOCALAPPDATA is required unless -CacheDirectory is specified.' }
    $CacheDirectory = [IO.Path]::Combine($env:LOCALAPPDATA, 'RhinoParametricSkill\plugin-v0.1.5')
}
$cacheRoot = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($CacheDirectory)
Assert-LocalPath $cacheRoot
if ([IO.File]::Exists($cacheRoot)) { throw 'CacheDirectory is an existing file.' }
$distTag = if ($RhinoVersion -eq '8') { 'rh8_29' } else { 'rh9_0' }
$assetName = "rhino-mcp-platform-0.1.5-$distTag-win.yak"
$expectedUrl = "https://files.mcneel.com/yak/packages/Rhino-MCP-Platform-0.1.5-$distTag-win.yak"
$manifestPath = [IO.Path]::GetFullPath([IO.Path]::Combine($PSScriptRoot, '..\vendor\official\assets.json'))
Assert-LocalPath $manifestPath
$manifest = [IO.File]::ReadAllText($manifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
$entries = @($manifest.assets | Where-Object { $_.file -ceq $assetName })
if ($entries.Count -ne 1) { throw 'Official package must be listed exactly once in assets.json.' }
$entry = $entries[0]
if ($entry.sha256 -isnot [string] -or $entry.sha256 -cnotmatch '^[0-9a-f]{64}$' -or
    $entry.bytes -is [string] -or $entry.bytes -is [bool] -or $null -eq $entry.bytes -or
    $entry.bytes -lt 1 -or $entry.bytes -gt 100000000 -or [math]::Floor([double]$entry.bytes) -ne $entry.bytes -or
    $entry.download_url -cne $expectedUrl) {
    throw 'Invalid pinned asset metadata or unapproved download URL.'
}
$assetPath = [IO.Path]::Combine($cacheRoot, $assetName)
Assert-LocalPath $assetPath
if ([IO.Directory]::Exists($assetPath)) { throw 'The cached package path is an existing directory.' }
$cacheReused = [IO.File]::Exists($assetPath)
$digest = $null
if ($cacheReused) { $digest = Get-VerifiedAssetHash $assetPath $entry }
$result = [ordered]@{
    Status = $null; AssetPath = $assetPath; Sha256 = $entry.sha256
    DownloadUrl = $entry.download_url; CacheReused = $cacheReused
    RequiresRhinoRestart = $false; Notes = $null
}
$operation = if ($PrepareOnly) { 'Prepare and verify the official Rhino plugin package' } else { 'Prepare and install the official Rhino plugin package with local Yak.exe' }
if (-not $PSCmdlet.ShouldProcess("$assetPath (source: $($entry.download_url))", $operation)) {
    $result.Status = 'WhatIf'
    $result.Notes = 'No download, file write, or installation was performed.'
    [pscustomobject]$result
    return
}
if (-not $cacheReused) { $digest = Save-OfficialAsset $assetPath $entry }
$result.Sha256 = $digest
if ($PrepareOnly) {
    $result.Status = 'Prepared'
    $result.Notes = 'Official package bytes and SHA256 verified. Run setup-rhino.ps1 without -PrepareOnly to install.'
} else {
    $installer = [IO.Path]::Combine($PSScriptRoot, 'install-offline.ps1')
    # The installer revalidates the package and existing installation. Do not
    # retry Yak automatically: a failed command can have an unknown outcome.
    $installerOutput = @(& $installer -RhinoVersion $RhinoVersion -RhinoSystem $RhinoSystem -AssetDirectory $cacheRoot -Confirm:$false)
    $result.Status = 'Installed'
    $result.RequiresRhinoRestart = $true
    $result.Notes = @('Save your work, restart Rhino when ready, run MCPConnect, then use configure-mcp.ps1 for your agent.') + @($installerOutput | ForEach-Object { [string]$_ })
}
[pscustomobject]$result
