# -*- coding: utf-8 -*-
"""Local Rhino helpers. Python 2.7/3 compatible; imports do not contact Rhino."""
from __future__ import print_function
import hashlib
import json
import os
import re


def absolute_path(value):
    if not value or not os.path.isabs(value):
        raise ValueError('An absolute path is required: %r' % value)
    return os.path.realpath(os.path.abspath(value))


def same_path(a, b):
    return os.path.normcase(absolute_path(a)) == os.path.normcase(absolute_path(b))


def checked_child(root, path):
    root = absolute_path(root)
    path = absolute_path(path)
    if not os.path.normcase(path).startswith(os.path.normcase(root) + os.sep):
        raise ValueError('Output must be inside output_root')
    return path


def safe_name(value):
    if not isinstance(value, type(u'')):
        value = str(value)
    if not re.match(r'^[A-Za-z0-9_-]{1,80}$', value):
        raise ValueError('Use 1-80 ASCII letters, digits, underscore or hyphen for run_id/name')
    return value


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def write_json(path, data, overwrite=True):
    path = absolute_path(path)
    if not os.path.isdir(os.path.dirname(path)):
        raise ValueError('Create the report directory before execution')
    encoded = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    if overwrite:
        with open(path, 'wb') as stream:
            stream.write(encoded)
    else:
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0)
        descriptor = os.open(path, flags, 0o666)
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(encoded)


def check_document(doc, config, required=False):
    expected = config.get('expected_document_path')
    if required and not expected:
        raise ValueError('expected_document_path is required for this operation')
    if expected and (not doc.Path or not same_path(doc.Path, expected)):
        raise ValueError('Active document differs from expected_document_path')


def resolve_document(config, explicit_doc=None, injected_doc=None):
    if explicit_doc is not None:
        return explicit_doc
    if injected_doc is not None:
        return injected_doc
    if config.get('allow_legacy_scriptcontext', False):
        import scriptcontext
        return scriptcontext.doc
    raise ValueError('Missing official __rhino_doc__ handle. For an explicit legacy Rhino 7 session only, set allow_legacy_scriptcontext=true.')


def enumerate_objects(Rhino, doc, references=False, definitions=True):
    settings = Rhino.DocObjects.ObjectEnumeratorSettings()
    settings.NormalObjects = True
    settings.HiddenObjects = True
    settings.LockedObjects = True
    settings.DeletedObjects = False
    settings.ActiveObjects = True
    settings.ReferenceObjects = bool(references)
    settings.IdefObjects = bool(definitions)
    settings.IncludeLights = True
    settings.IncludeGrips = False
    return list(doc.Objects.GetObjectList(settings))


def geometry_signature(System, geometry, strict_crc=False):
    error = None
    try:
        crc = int(geometry.DataCRC(System.UInt32(0)))
    except Exception as exc:
        crc = None
        error = str(exc)
        if strict_crc:
            raise RuntimeError('Geometry CRC unavailable: ' + error)
    box = geometry.GetBoundingBox(True)
    bounds = None
    if box.IsValid:
        bounds = [[float(box.Min.X), float(box.Min.Y), float(box.Min.Z)],
                  [float(box.Max.X), float(box.Max.Y), float(box.Max.Z)]]
    return {'type': str(geometry.GetType().FullName), 'valid': bool(geometry.IsValid),
            'geometry_crc32': crc, 'crc_error': error, 'bounds_document_units': bounds}


def file_signature(System, obj, strict_crc=False):
    result = geometry_signature(System, obj.Geometry, strict_crc)
    attrs = obj.Attributes
    result.update({'id': str(attrs.ObjectId), 'name': attrs.Name or '',
                   'layer_index': int(attrs.LayerIndex), 'material_index': int(attrs.MaterialIndex),
                   'linetype_index': int(attrs.LinetypeIndex), 'mode': str(attrs.Mode)})
    return result


def ensure_new_report_path(config, model_paths):
    path = config.get('report_path')
    if path:
        path = absolute_path(path)
        if not path.lower().endswith('.json'):
            raise ValueError('report_path must end in .json')
        if any(same_path(path, p) for p in model_paths if p):
            raise ValueError('Report path cannot equal a model path')
        if os.path.exists(path):
            raise ValueError('Report path must be a new JSON file')
    return path
