# -*- coding: utf-8 -*-
"""Rhino Shenbi local compatibility bridge; run INSIDE Rhino 7 IronPython.

Independent MIT implementation, not the official Rhino 8/9 plugin. One
authenticated, newline-framed request per TCP connection, on loopback only.
All Rhino work runs on Idle, sequentially. No process killing or dependencies.
"""
from __future__ import print_function
import os
import sys
import json
import socket
import threading
import hashlib
import traceback
import time
import Rhino
import System
import scriptcontext as sc
import rhinoscriptsyntax as rs

PROTOCOL = 'rhino-shenbi-7/1'
STICKY_KEY = 'rhino_shenbi_bridge7_v1'
MAX_REQUEST = 4 * 1024 * 1024
MAX_RESPONSE = 24 * 1024 * 1024


def strict_json(value):
    def invalid(number):
        raise ValueError('Nonfinite JSON is not allowed: ' + number)
    result = json.loads(value, parse_constant=invalid)
    # Also catches overflows such as 1e400.
    json.dumps(result, allow_nan=False)
    return result


def live_objects(doc):
    settings = Rhino.DocObjects.ObjectEnumeratorSettings()
    settings.NormalObjects = True
    settings.HiddenObjects = True
    settings.LockedObjects = True
    settings.DeletedObjects = False
    settings.IdefObjects = True
    settings.ReferenceObjects = True
    settings.IncludeLights = True
    return list(doc.Objects.GetObjectList(settings))


def context():
    doc = Rhino.RhinoDoc.ActiveDoc
    if doc is None:
        raise ValueError('Open a Rhino document first')
    return {'rhino_version': str(Rhino.RhinoApp.Version), 'python_version': sys.version,
            'process_id': int(System.Diagnostics.Process.GetCurrentProcess().Id),
            'document_serial': int(doc.RuntimeSerialNumber), 'document_path': doc.Path or '',
            'units': str(doc.ModelUnitSystem), 'tolerance': float(doc.ModelAbsoluteTolerance),
            'object_count': len(live_objects(doc)),
            'layers': [x.FullPath for x in doc.Layers if not x.IsDeleted],
            'runtime': 'IronPython 2.7', 'bridge': PROTOCOL,
            'supported_pipeline': ['inspect', 'RhinoCommon modeling', 'capture', 'save_and_reopen'],
            'notes': 'Independent Rhino7 bridge. No Python3/CPython or Rhino8-only kernel features.'}


def checked_doc(params):
    doc = Rhino.RhinoDoc.ActiveDoc
    serial = params.get('expected_document_serial')
    if isinstance(serial, bool) or not isinstance(serial, (int, long)) or serial <= 0:
        raise ValueError('expected_document_serial from get_context is required')
    if doc is None or int(doc.RuntimeSerialNumber) != serial:
        raise ValueError('Target document changed; read get_context again before executing')
    expected_path = params.get('expected_document_path')
    if expected_path and os.path.normcase(os.path.abspath(expected_path)) != os.path.normcase(os.path.abspath(doc.Path or '')):
        raise ValueError('Target document path differs')
    return doc


class Bridge(object):
    def __init__(self, folder):
        self.folder = folder
        self.running = False
        self.records = {}
        self.executing = False
        self.lock = threading.Lock()
        self.token = System.Guid.NewGuid().ToString('N') + System.Guid.NewGuid().ToString('N')
        self.pid = int(System.Diagnostics.Process.GetCurrentProcess().Id)
        self.session_id = System.Guid.NewGuid().ToString('N')
        self.session_dir = os.path.join(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), 'RhinoShenbi', 'bridge7')
        self.session_path = os.path.join(self.session_dir, str(self.pid) + '.json')

    def start(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind(('127.0.0.1', 0))
        self.sock.listen(8)
        self.sock.settimeout(1)
        self.running = True
        if not os.path.isdir(self.session_dir):
            os.makedirs(self.session_dir)
        data = {'protocol': PROTOCOL, 'host': '127.0.0.1', 'port': self.sock.getsockname()[1],
                'pid': self.pid, 'token': self.token, 'session_id': self.session_id,
                'rhino_major': 7, 'bridge_path': os.path.join(self.folder, 'bridge.py')}
        # Only this process' own discovery record is replaced; no document/user config.
        System.IO.File.WriteAllText(self.session_path, json.dumps(data), System.Text.UTF8Encoding(False))
        self.thread = threading.Thread(target=self.listen)
        self.thread.daemon = True
        self.thread.start()
        Rhino.RhinoApp.WriteLine('Rhino Shenbi 7 ready. PID {0}; local port {1}.'.format(self.pid, data['port']))

    def stop(self):
        self.running = False
        self.sock.close()
        if os.path.isfile(self.session_path):
            with open(self.session_path, 'rb') as stream:
                current = json.loads(stream.read())
            if current.get('session_id') == self.session_id:
                os.remove(self.session_path)

    def listen(self):
        while self.running:
            try:
                client, peer = self.sock.accept()
            except socket.timeout:
                continue
            except Exception:
                break
            thread = threading.Thread(target=self.handle, args=(client,))
            thread.daemon = True
            thread.start()

    def handle(self, client):
        ident = None
        dispatched = False
        try:
            client.settimeout(15)
            chunks = b''
            while b'\n' not in chunks:
                block = client.recv(65536)
                if not block:
                    raise ValueError('Incomplete request frame')
                chunks += block
                if len(chunks) > MAX_REQUEST:
                    raise ValueError('Request exceeds 4MiB')
            raw, remainder = chunks.split(b'\n', 1)
            if remainder.strip():
                raise ValueError('One request per connection only')
            request = strict_json(raw.decode('utf-8'))
            if not isinstance(request, dict) or request.get('protocol') != PROTOCOL or request.get('token') != self.token:
                raise ValueError('Bridge identity or token mismatch')
            ident = request.get('id')
            if not isinstance(ident, basestring) or not 1 <= len(ident) <= 80:
                raise ValueError('A request id of 1-80 characters is required')
            method = request.get('method')
            params = request.get('params', {})
            if not isinstance(params, dict):
                raise ValueError('params must be an object')
            if method == 'get_request_status':
                with self.lock:
                    found = self.records.get(params.get('request_id'))
                    response = {'status': 'ok', 'id': ident, 'result': found['response'] if found else {'status': 'not_found', 'execution_state': 'unknown_do_not_replay'}}
            else:
                if method not in ('get_context', 'run_python', 'run_template', 'get_viewport_image'):
                    raise ValueError('Unknown bridge method')
                key = hashlib.sha256(json.dumps({'method': method, 'params': params}, sort_keys=True, allow_nan=False).encode('utf-8')).hexdigest()
                with self.lock:
                    record = self.records.get(ident)
                    if record:
                        if record['hash'] != key:
                            raise ValueError('Request id reused with different arguments')
                    else:
                        if len(self.records) >= 4096:
                            raise ValueError('Session request ledger full; complete/reconcile work before restarting this bridge')
                        record = {'hash': key, 'event': threading.Event(), 'response': {'id': ident, 'status': 'pending', 'execution_state': 'queued'}}
                        self.records[ident] = record
                        dispatched = True
                        self.schedule(ident, method, params, record)
                dispatched = True
                if not record['event'].wait(110):
                    response = {'id': ident, 'status': 'error', 'execution_state': 'unknown', 'error': 'Rhino busy or operation still running; query get_request_status. Do not replay.'}
                else:
                    response = record['response']
            encoded = json.dumps(response, ensure_ascii=True, allow_nan=False).encode('utf-8')
            if len(encoded) > MAX_RESPONSE:
                encoded = json.dumps({'id': ident, 'status': 'error', 'execution_state': 'completed_result_too_large', 'error': 'Result exceeds transport limit; query a smaller result or write a local report'}).encode('utf-8')
            client.sendall(encoded + b'\n')
        except Exception as exc:
            try:
                client.sendall(json.dumps({'id': ident, 'status': 'error', 'execution_state': 'unknown' if dispatched else 'not_dispatched', 'error': str(exc)}, ensure_ascii=True).encode('utf-8') + b'\n')
            except Exception:
                pass
        finally:
            client.close()

    def schedule(self, ident, method, params, record):
        def idle(sender, event):
            if self.executing:
                return
            Rhino.RhinoApp.Idle -= idle
            self.executing = True
            record['response'] = {'id': ident, 'status': 'pending', 'execution_state': 'running'}
            try:
                value = self.execute(method, params)
                # Validate before claiming success, rather than silently stringifying geometry.
                json.dumps(value, allow_nan=False)
                record['response'] = {'id': ident, 'status': 'ok', 'execution_state': 'completed', 'result': value}
            except Exception as exc:
                record['response'] = {'id': ident, 'status': 'error', 'execution_state': 'failed_partial_possible', 'error': str(exc), 'traceback': traceback.format_exc()[-5000:]}
            finally:
                self.executing = False
                record['event'].set()
        Rhino.RhinoApp.Idle += idle

    def execute(self, method, params):
        if method == 'get_context':
            return context()
        doc = checked_doc(params)
        if method == 'get_viewport_image':
            width = int(params.get('width', 1000))
            height = int(params.get('height', 750))
            if not 64 <= width <= 2000 or not 64 <= height <= 2000:
                raise ValueError('Image dimensions must be between 64 and 2000')
            view = doc.Views.ActiveView
            if view is None:
                raise ValueError('No active view')
            bitmap = view.CaptureToBitmap(System.Drawing.Size(width, height))
            memory = System.IO.MemoryStream()
            try:
                bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Png)
                return {'mime_type': 'image/png', 'image_base64': System.Convert.ToBase64String(memory.ToArray()), 'width': width, 'height': height, 'document_serial': int(doc.RuntimeSerialNumber)}
            finally:
                memory.Dispose()
                bitmap.Dispose()
        config = params.get('config', {})
        if not isinstance(config, dict):
            raise ValueError('config must be a JSON object')
        runtime = os.path.abspath(os.path.join(self.folder, '..', 'rhino'))
        if method == 'run_template':
            templates = {'inspect': 'inspect_document.py', 'capture': 'capture_views.py', 'save': 'save_verified_copy.py'}
            if params.get('template') not in templates:
                raise ValueError('template must be inspect, capture, or save')
            path = os.path.join(runtime, templates[params['template']])
            with open(path, 'rb') as stream:
                code = stream.read().decode('utf-8-sig')
            if 'expected_document_path' not in config and doc.Path:
                config['expected_document_path'] = doc.Path
            config['print_json'] = False
        else:
            source = params.get('code')
            path = params.get('script_path')
            if bool(source) == bool(path):
                raise ValueError('Provide exactly one of code or absolute script_path')
            if path:
                if not os.path.isabs(path) or not path.lower().endswith('.py'):
                    raise ValueError('script_path must be an absolute .py path')
                with open(path, 'rb') as stream:
                    code = stream.read().decode('utf-8-sig')
            else:
                path = '<rhino7-user-script>'
                code = source
        if runtime not in sys.path:
            sys.path.insert(0, runtime)
        scope = {'__name__': '__main__', '__file__': path, '__rhino_doc__': doc, 'CONFIG': config,
                 'Rhino': Rhino, 'System': System, 'sc': sc, 'rs': rs}
        previous = sc.doc
        undo = 0
        before = set(str(o.Id) for o in live_objects(doc))
        run_id = params.get('run_id', 'template' if method == 'run_template' else None)
        if not isinstance(run_id, basestring) or not 1 <= len(run_id) <= 80:
            raise ValueError('run_id must be a short string')
        try:
            # Compilation happens in the target IronPython engine BEFORE any edit.
            compiled = compile(code.encode('utf-8'), path, 'exec')
            sc.doc = doc
            undo = doc.BeginUndoRecord('Rhino Shenbi: ' + run_id)
            eval(compiled, scope)
            if method == 'run_python' and 'result' not in scope:
                raise ValueError('Script completed but did not set result; do not replay blindly')
            value = scope.get('result')
            return {'value': value, 'run_id': run_id, 'document_serial': int(doc.RuntimeSerialNumber),
                    'created_ids': [str(o.Id) for o in live_objects(doc) if str(o.Id) not in before]}
        finally:
            try:
                for obj in live_objects(doc):
                    if str(obj.Id) not in before and not obj.IsReference:
                        attr = obj.Attributes.Duplicate()
                        try:
                            attr.SetUserString('AGENT_RUN_ID', run_id)
                            doc.Objects.ModifyAttributes(obj.Id, attr, True)
                        finally:
                            attr.Dispose()
            finally:
                try:
                    if undo:
                        doc.EndUndoRecord(undo)
                finally:
                    sc.doc = previous


def main():
    if Rhino.RhinoApp.Version.Major != 7:
        raise RuntimeError('This bridge is only for Rhino7; use the official router for Rhino8/9')
    existing = sc.sticky.get(STICKY_KEY)
    if existing and existing.running:
        Rhino.RhinoApp.WriteLine('Rhino Shenbi bridge already running; existing session preserved.')
        return existing
    bridge = Bridge(os.path.dirname(os.path.abspath(__file__)))
    bridge.start()
    sc.sticky[STICKY_KEY] = bridge
    return bridge


if __name__ == '__main__':
    main()
