#requires -Version 5.1
<# Run against a NEW EMPTY SAVED Rhino7 document only. Adds a test vessel.
Creates a fresh output directory, verifies regeneration and failed-input
preservation, captures three views, saves a new 3dm and reopens for checks.
Never closes Rhino, overwrites the baseline, or deletes unrelated objects. #>
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$OutputDirectory, [int]$RhinoPid=0)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'transport.ps1')
function Invoke-Checked {
    param([string]$Method,[object]$Parameters)
    $answer=Invoke-Rhino7Request -Method $Method -Parameters $Parameters -RhinoPid $RhinoPid
    if ($answer.status -ne 'ok') { throw ($answer | ConvertTo-Json -Depth 20 -Compress) }
    return $answer.result
}
$context=Invoke-Checked get_context @{}
if ($context.object_count -ne 0 -or -not $context.document_path) {
    throw 'Create a NEW EMPTY Rhino7 document, save it to a NEW .3dm path, then run this test. Current document was not changed.'
}
$source=[IO.Path]::GetFullPath($context.document_path)
if (-not [IO.File]::Exists($source)) { throw 'Saved baseline does not exist.' }
$output=[IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $output) { throw 'OutputDirectory must be a NEW directory; existing outputs are preserved.' }
[void][IO.Directory]::CreateDirectory($output)
$beforeHash=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
$serial=$context.document_serial
$run='smoke-'+[guid]::NewGuid().ToString('N').Substring(0,12)
$report=[ordered]@{scope='native Rhino7 smoke test';runtime=$context.rhino_version;run_id=$run;checks=@();status='running'}
try {
    $baselineCheck=Invoke-Checked run_python @{expected_document_serial=$serial;run_id=$run;config=@{path=$source};code='model=Rhino.FileIO.File3dm.Read(CONFIG["path"])
if model is None: raise ValueError("Cannot read saved baseline")
try:
    count=sum(1 for obj in model.Objects)
    if count != 0: raise ValueError("Saved baseline must also be empty")
    result={"baseline_objects":count}
finally:
    model.Dispose()'}
    $report.checks+=@{name='empty_saved_baseline';result=$baselineCheck.value}
    $params=@{expected_document_serial=$serial;run_id=$run;script_path=(Join-Path $PSScriptRoot 'parametric_vessel.py');config=@{instance=$run;radius=20.0;height=45.0;wall=2.0}}
    $first=Invoke-Checked run_python $params
    $report.checks+=@{name='create_native_boolean_brep';result=$first.value}
    $params.config.radius=24.0; $params.config.height=52.0
    $second=Invoke-Checked run_python $params
    if ($second.value.replaced_ids -notcontains $first.value.id) { throw 'Regeneration did not report replacement.' }
    $report.checks+=@{name='parameter_regeneration';result=$second.value}
    $inspection=@{expected_document_serial=$serial;template='inspect';config=@{expected_document_path=$source;max_records=20}}
    $snapshot=Invoke-Checked run_template $inspection
    if ($snapshot.value.enumerated_count -ne 1) { throw 'Expected exactly one generated vessel.' }
    $params.config.wall=100.0
    $illegal=Invoke-Rhino7Request -Method run_python -Parameters $params -RhinoPid $RhinoPid
    if ($illegal.status -ne 'error') { throw 'Invalid wall unexpectedly accepted.' }
    $after=Invoke-Checked run_template $inspection
    if (($snapshot.value.objects | ConvertTo-Json -Depth 20 -Compress) -cne ($after.value.objects | ConvertTo-Json -Depth 20 -Compress)) {
        throw 'Invalid parameters changed existing geometry.'
    }
    $report.checks+=@{name='invalid_input_preserves_ids_and_geometry';passed=$true}
    $views=@(
        @{name='top';camera=@(0,0,160);target=@(0,0,26);up=@(0,1,0);bounds=@(@(-26,-26,0),@(26,26,54))},
        @{name='front';camera=@(0,-160,26);target=@(0,0,26);up=@(0,0,1);bounds=@(@(-26,-26,0),@(26,26,54))},
        @{name='perspective';camera=@(110,-140,120);target=@(0,0,26);up=@(0,0,1);projection='perspective';bounds=@(@(-26,-26,0),@(26,26,54))}
    )
    $capture=Invoke-Checked run_template @{expected_document_serial=$serial;template='capture';config=@{expected_document_path=$source;output_root=$output;width=1000;height=800;views=$views;isolate_ids=@($second.value.id)}}
    $report.checks+=@{name='three_view_capture';result=$capture.value}
    $saved=Invoke-Checked run_template @{expected_document_serial=$serial;template='save';config=@{expected_document_path=$source;source_baseline=$source;output_root=$output;run_id=$run;output_stem='rhino7-smoke';expected_baseline_count=0;expected_generated_count=1;file_version=7}}
    $report.checks+=@{name='save_reopen_and_geometry_verification';result=$saved.value}
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -cne $beforeHash) { throw 'Baseline hash changed.' }
    $report.checks+=@{name='baseline_sha256_preserved';passed=$true}
    $report.status='passed'
} catch {
    $report.status='failed'
    $report.error=$_.Exception.Message
} finally {
    [IO.File]::WriteAllText((Join-Path $output 'smoke-report.json'),($report | ConvertTo-Json -Depth 60),(New-Object Text.UTF8Encoding $false))
}
$report | ConvertTo-Json -Depth 60
if ($report.status -ne 'passed') { exit 1 }
