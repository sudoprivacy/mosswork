# -*- coding: utf-8 -*-
"""Clean baseline + tagged generation -> new, reopened and verified 3dm.

No active-document geometry/layers/path are changed. This intentionally does
not use SaveAs: old study objects in the live document are not auto-exported.
Model-space generated geometry only; see reference 05 for scope limitations.
"""
from __future__ import print_function
import os
import json
from _common import (absolute_path, same_path, checked_child, safe_name,
                     sha256_file, write_json, check_document, enumerate_objects,
                     file_signature, geometry_signature, resolve_document)


def _add_geometry(Rhino, model, geometry, attrs):
    g = Rhino.Geometry
    names = [('Mesh', 'AddMesh'), ('SubD', 'AddSubD'), ('Extrusion', 'AddExtrusion'),
             ('Brep', 'AddBrep'), ('Curve', 'AddCurve'), ('Surface', 'AddSurface'),
             ('PointCloud', 'AddPointCloud'), ('TextDot', 'AddTextDot')]
    for type_name, method in names:
        cls = getattr(g, type_name, None)
        if cls is not None and isinstance(geometry, cls):
            return getattr(model.Objects, method)(geometry, attrs)
    if isinstance(geometry, g.Point):
        return model.Objects.AddPoint(geometry.Location, attrs)
    raise TypeError('Generated geometry needs a dedicated component copier: ' + str(geometry.GetType().FullName))


class _Remapper(object):
    """Append independent components; never reuse a live numeric table index."""
    def __init__(self, Rhino, System, model, doc, run_id):
        self.Rhino, self.System, self.model, self.doc = Rhino, System, model, doc
        self.run_id = run_id
        self.layers, self.materials, self.linetypes, self.groups = {}, {}, {}, {}
        self.doc_layers = dict((str(layer.Id), layer) for layer in doc.Layers if not layer.IsDeleted)
        root = Rhino.DocObjects.Layer()
        root.Name = 'Generated_' + run_id
        root.IsVisible = True
        root.IsLocked = False
        self.root_index = self.add(model.AllLayers, root)

    def add(self, table, component):
        component.Id = self.System.Guid.NewGuid()
        component.Index = -1
        ident = component.Id
        try:
            table.Add(component)
            stored = table.FindId(ident)
            if stored is None:
                raise RuntimeError('File component could not be appended')
            return int(stored.Index)
        finally:
            component.Dispose()

    def material(self, index):
        index = int(index)
        if index < 0:
            return index
        if index not in self.materials:
            material = self.Rhino.DocObjects.Material()
            material.CopyFrom(self.doc.Materials[index])
            material.Name = 'Material_' + self.run_id + '_' + str(index)
            self.materials[index] = self.add(self.model.AllMaterials, material)
        return self.materials[index]

    def linetype(self, index):
        index = int(index)
        if index < 0:
            return index
        if index not in self.linetypes:
            source = self.doc.Linetypes[index]
            target = self.Rhino.DocObjects.Linetype()
            target.Name = 'Linetype_' + self.run_id + '_' + str(index)
            for i in range(source.SegmentCount):
                values = source.GetSegment(i)
                length, solid = values[-2], values[-1]
                target.AppendSegment(length, solid)
            self.linetypes[index] = self.add(self.model.AllLinetypes, target)
        return self.linetypes[index]

    def group(self, index):
        index = int(index)
        if index not in self.groups:
            source = self.doc.Groups.FindIndex(index)
            if source is None:
                raise ValueError('Missing live group')
            # Group has no public empty constructor in the supported API.
            # File3dm copies the source component; do not mutate/dispose the
            # live document-owned Group wrapper.
            stored = self.model.AllGroups.FindId(source.Id)
            if stored is None:
                self.model.AllGroups.Add(source)
                stored = self.model.AllGroups.FindId(source.Id)
            if stored is None:
                raise RuntimeError('Could not copy generated group reference')
            self.groups[index] = int(stored.Index)
        return self.groups[index]

    def layer(self, index):
        index = int(index)
        if index in self.layers:
            return self.layers[index]
        source = self.doc.Layers[index]
        parent_index = self.root_index
        if source.ParentLayerId != self.System.Guid.Empty:
            parent = self.doc_layers.get(str(source.ParentLayerId))
            if parent is None:
                raise ValueError('Missing live layer parent')
            parent_index = self.layer(parent.Index)
        target = self.Rhino.DocObjects.Layer()
        target.Name = source.Name
        target.ParentLayerId = self.model.AllLayers.FindIndex(parent_index).Id
        for prop in ['Color', 'PlotColor', 'PlotWeight', 'IsVisible', 'IsLocked', 'IsExpanded']:
            setattr(target, prop, getattr(source, prop))
        target.SetPersistentVisibility(source.GetPersistentVisibility())
        target.SetPersistentLocking(source.GetPersistentLocking())
        target.RenderMaterialIndex = self.material(source.RenderMaterialIndex)
        target.LinetypeIndex = self.linetype(source.LinetypeIndex)
        self.layers[index] = self.add(self.model.AllLayers, target)
        return self.layers[index]

    def archive_layer(self):
        layer = self.Rhino.DocObjects.Layer()
        layer.Name = 'Original_Targets_Archive'
        layer.ParentLayerId = self.model.AllLayers.FindIndex(self.root_index).Id
        # Set both values BEFORE table.Add; later wrapper mutation can be detached.
        layer.IsVisible = False
        layer.SetPersistentVisibility(False)
        layer.IsLocked = True
        return self.add(self.model.AllLayers, layer)


def _validate(Rhino, System, path, expected, units, tolerances, tag_key, run_id, generated_ids):
    model = Rhino.FileIO.File3dm.Read(path)
    if model is None:
        raise RuntimeError('Saved file could not be reopened')
    try:
        actual = dict((str(obj.Attributes.ObjectId), obj) for obj in model.Objects)
        if set(actual) != set(expected):
            raise RuntimeError('Reopened object GUID set differs: missing %d, extra %d' %
                               (len(set(expected) - set(actual)), len(set(actual) - set(expected))))
        for ident, wanted in expected.items():
            got = file_signature(System, actual[ident], strict_crc=True)
            for key in ['type', 'geometry_crc32', 'name', 'layer_index', 'material_index', 'linetype_index', 'mode']:
                if got[key] != wanted[key]:
                    raise RuntimeError('Reopened %s differs on object %s' % (key, ident))
            layer = model.AllLayers.FindIndex(got['layer_index'])
            if layer is None or bool(layer.IsVisible) != wanted['layer_visible']:
                raise RuntimeError('Reopened layer visibility differs: ' + ident)
            if ident in generated_ids and actual[ident].Attributes.GetUserString(tag_key) != run_id:
                raise RuntimeError('Generation tag missing: ' + ident)
        if str(model.Settings.ModelUnitSystem) != units:
            raise RuntimeError('Saved unit system differs')
        for key, value in tolerances.items():
            if abs(float(getattr(model.Settings, key)) - value) > max(1e-12, abs(value) * 1e-12):
                raise RuntimeError('Saved model tolerance differs: ' + key)
        return {'verified': True, 'object_count': len(actual), 'geometry_crc_checked': len(actual),
                'units': units, 'sha256': sha256_file(path), 'bytes': os.path.getsize(path)}
    finally:
        model.Dispose()


def main(config, doc=None):
    import Rhino
    import System
    doc = resolve_document(config, doc, globals().get('__rhino_doc__'))
    check_document(doc, config, required=True)
    source = absolute_path(config['source_baseline'])
    root = absolute_path(config['output_root'])
    run_id = safe_name(config['run_id'])
    stem = safe_name(config.get('output_stem', 'model'))
    tag_key = config.get('generation_tag_key', 'AGENT_RUN_ID')
    destination = checked_child(root, os.path.join(root, stem + '_' + run_id + '.3dm'))
    pending = checked_child(root, os.path.join(root, stem + '_' + run_id + '.pending.3dm'))
    report_path = checked_child(root, os.path.join(root, stem + '_' + run_id + '.verification.json'))
    if not os.path.isfile(source) or not os.path.isdir(root):
        raise ValueError('source_baseline file and output_root directory must already exist')
    if same_path(source, destination) or same_path(doc.Path, destination):
        raise ValueError('Versioned output must differ from source and active document')
    archive_ids = set(str(System.Guid(value)) for value in config.get('archive_target_ids', []))
    all_live = enumerate_objects(Rhino, doc, references=False, definitions=False)
    generated = sorted([obj for obj in all_live if obj.Attributes.GetUserString(tag_key) == run_id],
                       key=lambda obj: str(obj.Id))
    if not generated:
        raise ValueError('No objects with the exact generation tag/run_id were found')
    if config.get('expected_generated_count') is not None and len(generated) != int(config['expected_generated_count']):
        raise ValueError('Generated object count differs; inspect an uncertain earlier call before retrying')
    for obj in generated:
        if not obj.Geometry.IsValid or obj.IsReference or obj.IsInstanceDefinitionGeometry:
            raise ValueError('Invalid or unsupported generated object: ' + str(obj.Id))
        if str(obj.Attributes.Space) != 'ModelSpace':
            raise ValueError('Generated page-space geometry requires a dedicated layout copier')
    source_hash = sha256_file(source)
    model = Rhino.FileIO.File3dm.Read(source)
    if model is None:
        raise ValueError('Could not read source_baseline')
    expected = {}
    try:
        baseline = dict((str(obj.Attributes.ObjectId), obj) for obj in model.Objects)
        if archive_ids - set(baseline):
            raise ValueError('archive_target_ids are not all in source_baseline')
        if config.get('expected_baseline_count') is not None and len(baseline) != int(config['expected_baseline_count']):
            raise ValueError('Baseline object count differs')
        if any(obj.Attributes.GetUserString(tag_key) for obj in baseline.values()):
            raise ValueError('Use a clean source baseline without prior objects carrying generation_tag_key')
        generated_ids = set(str(obj.Id) for obj in generated)
        if generated_ids & set(baseline):
            raise ValueError('Generated GUID collides with a baseline GUID')
        if model.Settings.ModelUnitSystem != doc.ModelUnitSystem:
            raise ValueError('Live document units differ from baseline; do not silently rescale')
        units = str(model.Settings.ModelUnitSystem)
        tolerances = dict((key, float(getattr(model.Settings, key))) for key in
                         ['ModelAbsoluteTolerance', 'ModelAngleToleranceRadians', 'ModelRelativeTolerance'])
        baseline_before = dict((ident, file_signature(System, obj, strict_crc=True))
                               for ident, obj in baseline.items())
        generated_before = dict((str(obj.Id), geometry_signature(System, obj.Geometry, strict_crc=True))
                                for obj in generated)
        remapper = _Remapper(Rhino, System, model, doc, run_id)
        for obj in generated:
            attrs = obj.Attributes.Duplicate()
            try:
                attrs.ObjectId = obj.Id
                attrs.LayerIndex = remapper.layer(attrs.LayerIndex)
                attrs.MaterialIndex = remapper.material(attrs.MaterialIndex)
                attrs.LinetypeIndex = remapper.linetype(attrs.LinetypeIndex)
                groups = list(attrs.GetGroupList() or [])
                attrs.RemoveFromAllGroups()
                for index in groups:
                    attrs.AddToGroup(remapper.group(index))
                ident = _add_geometry(Rhino, model, obj.Geometry, attrs)
                if ident != obj.Id:
                    raise RuntimeError('Generated object GUID was not preserved')
            finally:
                attrs.Dispose()
        if archive_ids:
            archive = remapper.archive_layer()
            for ident in archive_ids:
                baseline[ident].Attributes.LayerIndex = archive
        for obj in model.Objects:
            signature = file_signature(System, obj, strict_crc=True)
            signature['layer_visible'] = bool(model.AllLayers.FindIndex(signature['layer_index']).IsVisible)
            expected[signature['id']] = signature
        for ident, before in list(baseline_before.items()) + list(generated_before.items()):
            for key in ['type', 'geometry_crc32']:
                if before[key] != expected[ident][key]:
                    raise RuntimeError('File assembly changed source geometry ' + ident)
            if ident in baseline_before and ident not in archive_ids:
                for key in ['name', 'layer_index', 'material_index', 'linetype_index', 'mode']:
                    if before[key] != expected[ident][key]:
                        raise RuntimeError('File assembly changed an unrelated original attribute ' + ident)
        model.Strings.SetString('REFERENCE_MODELING', 'run_id', run_id)
        model.Strings.SetString('REFERENCE_MODELING', 'source_sha256', source_hash)
        # An uncertain previous save is REOPENED and compared, never overwritten.
        if os.path.exists(destination):
            verification = _validate(Rhino, System, destination, expected, units, tolerances,
                                     tag_key, run_id, generated_ids)
            status = 'already_present_reopened_verified'
        else:
            if not os.path.exists(pending):
                options = Rhino.FileIO.File3dmWriteOptions()
                options.Version = int(config.get('file_version', Rhino.RhinoApp.Version.Major))
                options.SaveRenderMeshes = False
                options.SaveAnalysisMeshes = False
                options.SaveUserData = True
                if not model.Write(pending, options):
                    raise RuntimeError('File3dm.Write returned false')
            verification = _validate(Rhino, System, pending, expected, units, tolerances,
                                     tag_key, run_id, generated_ids)
            # Move refuses to replace an existing destination; keep source/pending on failure.
            System.IO.File.Move(pending, destination)
            status = 'saved_reopened_verified'
    finally:
        model.Dispose()
    if sha256_file(source) != source_hash:
        raise RuntimeError('Source baseline changed during verification')
    report = {'status': status, 'output': destination, 'source_baseline': source,
        'source_sha256_unchanged': source_hash, 'run_id': run_id, 'generation_tag_key': tag_key,
        'original_objects_preserved': len(baseline), 'generated_objects': len(generated),
        'archived_target_ids': sorted(archive_ids), 'verification': verification,
        'active_document_mutated': False, 'untouched_geometry_guids_preserved': True,
        'scope': 'Baseline tables retained; tagged model-space geometry appended with remapped layers/materials/linetypes/groups. External texture assets and third-party render/plugin behavior are not certified.'}
    write_json(report_path, report)
    return report


if __name__ == '__main__':
    if 'CONFIG' not in globals():
        raise ValueError('Inject CONFIG using the wrapper described in reference 05')
    result = main(CONFIG)
    if CONFIG.get('print_json', True):
        print(json.dumps(result, ensure_ascii=True))
