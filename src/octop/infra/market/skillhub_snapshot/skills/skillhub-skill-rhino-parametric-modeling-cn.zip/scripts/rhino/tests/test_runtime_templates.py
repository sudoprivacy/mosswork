# -*- coding: utf-8 -*-
"""Offline unit tests using small API stubs, NOT a Rhino integration test."""
from __future__ import print_function
import os
import shutil
import sys
import tempfile
import types
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.dirname(HERE)
sys.path.insert(0, SCRIPTS)
import _common
import inspect_document
import capture_views
import save_verified_copy
import run_config


class Record(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class Geometry(object):
    IsValid = True
    def __init__(self, crc=123):
        self.crc = crc
    def DataCRC(self, seed):
        return self.crc
    def GetType(self):
        return Record(FullName='Rhino.Geometry.Mesh')
    def GetBoundingBox(self, accurate):
        return Record(IsValid=True, Min=Record(X=0, Y=0, Z=0), Max=Record(X=1, Y=2, Z=3))


class Attributes(object):
    def __init__(self, ident):
        self.ObjectId = ident
        self.Name = ident
        self.LayerIndex = 0
        self.MaterialIndex = -1
        self.LinetypeIndex = -1
        self.Mode = 'Normal'
        self.tags = {}
    def GetUserString(self, key):
        return self.tags.get(key)


class Object(object):
    def __init__(self, ident, hidden=False, locked=False, deleted=False):
        self.Id = ident
        self.Attributes = Attributes(ident)
        self.Geometry = Geometry()
        self.IsHidden = hidden
        self.IsLocked = locked
        self.IsDeleted = deleted
        self.IsReference = False
        self.IsInstanceDefinitionGeometry = False


class Objects(object):
    def __init__(self, objects):
        self.items = objects
        self.operations = []
    @property
    def Count(self):
        raise AssertionError('Runtime Count must not be used for preservation counts')
    def GetObjectList(self, settings):
        self.last_settings = settings
        return [obj for obj in self.items
                if (not obj.IsDeleted or settings.DeletedObjects)
                and (not obj.IsHidden or settings.HiddenObjects)
                and (not obj.IsLocked or settings.LockedObjects)]
    def Hide(self, ident, quiet):
        self.operations.append(('hide', ident))
        next(obj for obj in self.items if obj.Id == ident).IsHidden = True
        return True
    def Show(self, ident, quiet):
        self.operations.append(('show', ident))
        next(obj for obj in self.items if obj.Id == ident).IsHidden = False
        return True


class Viewport(object):
    def __init__(self):
        self.Size = (640, 480)
        self.CameraTarget = (1, 2, 3)
        self.DisplayMode = 'old-display'
        self.CameraUp = (0, 0, 1)
        self.projection = 'original-projection'
    def ChangeToParallelProjection(self, symmetric):
        self.projection = 'parallel'
    def ChangeToPerspectiveProjection(self, symmetric, lens):
        self.projection = 'perspective'
    def SetCameraLocations(self, target, camera):
        self.CameraTarget = target
    def SetViewProjection(self, info, update):
        self.projection = info.projection
        self.CameraUp = info.up
        return True
    def SetCameraTarget(self, target, update):
        self.CameraTarget = target


class ViewportInfo(object):
    def __init__(self, vp):
        self.projection = vp.projection
        self.up = vp.CameraUp
        self.disposed = False
    def Dispose(self):
        self.disposed = True


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp_parent = os.path.realpath(tempfile.gettempdir())
        self.tmp = tempfile.mkdtemp(prefix='rhino-template-test-')
        self.old_modules = dict((key, sys.modules.get(key)) for key in ['Rhino', 'System'])
        self.Rhino = types.ModuleType('Rhino')
        self.System = types.ModuleType('System')
        self.System.Guid = lambda value: str(value)
        self.System.UInt32 = int
        self.System.Drawing = Record(Size=lambda x, y: (x, y), Imaging=Record(ImageFormat=Record(Png='png')))
        self.Rhino.DocObjects = Record(ObjectEnumeratorSettings=Record, ViewportInfo=ViewportInfo)
        self.Rhino.RhinoApp = Record(Version=Record(Major=7))
        self.Rhino.Geometry = Record(Point3d=lambda *p: tuple(p), Vector3d=lambda *p: tuple(p))
        self.Rhino.Display = Record(DisplayModeDescription=Record(FindByName=lambda name: None))
        sys.modules['Rhino'] = self.Rhino
        sys.modules['System'] = self.System
        layer = Record(Id='layer-0', Index=0, FullPath='Layer', ParentLayerId='', IsVisible=True,
                       IsLocked=False, IsDeleted=False)
        self.objects = Objects([Object('normal'), Object('hidden', hidden=True), Object('locked', locked=True),
                                Object('deleted', deleted=True)])
        self.vp = Viewport()
        view = Record(ActiveViewport=self.vp, CaptureToBitmap=lambda size: None)
        self.doc = Record(Path=os.path.join(self.tmp, 'working.3dm'), ModelUnitSystem='Meters',
            ModelAbsoluteTolerance=.001, ModelAngleToleranceRadians=.01, Objects=self.objects,
            Layers=[layer], Views=Record(ActiveView=view, Redraw=lambda: None))

    def tearDown(self):
        for key, value in self.old_modules.items():
            if value is None:
                sys.modules.pop(key, None)
            else:
                sys.modules[key] = value
        resolved = os.path.realpath(self.tmp)
        if not resolved.startswith(self.tmp_parent + os.sep) or not os.path.basename(resolved).startswith('rhino-template-test-'):
            raise AssertionError('Refusing unexpected recursive test cleanup target')
        shutil.rmtree(resolved)

    def test_child_path_does_not_accept_sibling_prefix(self):
        self.assertEqual(_common.checked_child(self.tmp, os.path.join(self.tmp, 'report.json')),
                         os.path.join(self.tmp, 'report.json'))
        with self.assertRaises(ValueError):
            _common.checked_child(self.tmp, self.tmp + '-sibling/report.json')

    def test_missing_official_document_does_not_fall_back(self):
        with self.assertRaises(ValueError):
            _common.resolve_document({})
        self.assertIs(_common.resolve_document({}, injected_doc=self.doc), self.doc)

    def test_inspect_includes_hidden_locked_excludes_deleted(self):
        report = inspect_document.main({'max_records': 2}, self.doc)
        self.assertEqual(report['enumerated_count'], 3)
        self.assertTrue(report['records_truncated'])
        self.assertEqual(report['target_count'], 3)
        self.assertTrue(self.objects.last_settings.HiddenObjects)
        self.assertTrue(self.objects.last_settings.LockedObjects)
        self.assertFalse(self.objects.last_settings.DeletedObjects)
        self.assertEqual(self.objects.operations, [])

    def test_missing_guid_and_path_mismatch_are_explicit(self):
        report = inspect_document.main({'target_ids': ['absent']}, self.doc)
        self.assertEqual(report['missing_target_ids'], ['absent'])
        with self.assertRaises(ValueError):
            inspect_document.main({'expected_document_path': os.path.join(self.tmp, 'other.3dm')}, self.doc)

    def test_capture_failure_restores_only_temporary_visibility(self):
        config = {'expected_document_path': self.doc.Path, 'output_root': self.tmp,
                  'isolate_ids': ['normal'], 'views': [{'name': 'front', 'camera': [0, -5, 2], 'target': [0, 0, 2]}]}
        with self.assertRaises(RuntimeError):
            capture_views.main(config, self.doc)
        self.assertEqual([(o.Id, o.IsHidden) for o in self.objects.items],
                         [('normal', False), ('hidden', True), ('locked', False), ('deleted', False)])
        self.assertEqual(self.vp.projection, 'original-projection')
        self.assertEqual(self.vp.CameraTarget, (1, 2, 3))
        self.assertEqual(self.vp.Size, (640, 480))
        self.assertEqual(self.vp.DisplayMode, 'old-display')
        self.assertNotIn(('show', 'hidden'), self.objects.operations)

    def test_existing_capture_is_not_overwritten(self):
        path = os.path.join(self.tmp, 'front.png')
        with open(path, 'wb') as stream:
            stream.write(b'existing')
        config = {'expected_document_path': self.doc.Path, 'output_root': self.tmp,
                  'views': [{'name': 'front', 'camera': [0, -5, 2], 'target': [0, 0, 2]}]}
        with self.assertRaises(ValueError):
            capture_views.main(config, self.doc)
        self.assertEqual(self.objects.operations, [])
        with open(path, 'rb') as stream:
            self.assertEqual(stream.read(), b'existing')

    def _verification_fixture(self):
        obj = Object('original')
        model = Record(Objects=[obj], AllLayers=Record(FindIndex=lambda index: Record(IsVisible=True)),
            Settings=Record(ModelUnitSystem='Meters', ModelAbsoluteTolerance=.001), disposed=False)
        model.Dispose = lambda: setattr(model, 'disposed', True)
        self.Rhino.FileIO = Record(File3dm=Record(Read=lambda path: model))
        path = os.path.join(self.tmp, 'fake.3dm')
        with open(path, 'wb') as stream:
            stream.write(b'NOT A REAL 3DM: stub read verification fixture')
        expected = _common.file_signature(self.System, obj, True)
        expected['layer_visible'] = True
        return path, obj, model, {'original': expected}

    def test_reopen_verifier_accepts_matching_crc_and_ids(self):
        path, obj, model, expected = self._verification_fixture()
        report = save_verified_copy._validate(self.Rhino, self.System, path, expected, 'Meters',
                    {'ModelAbsoluteTolerance': .001}, 'AGENT_RUN_ID', 'r03', set())
        self.assertTrue(report['verified'])
        self.assertTrue(model.disposed)

    def test_reopen_verifier_rejects_changed_crc(self):
        path, obj, model, expected = self._verification_fixture()
        obj.Geometry.crc = 456
        with self.assertRaises(RuntimeError):
            save_verified_copy._validate(self.Rhino, self.System, path, expected, 'Meters',
                    {'ModelAbsoluteTolerance': .001}, 'AGENT_RUN_ID', 'r03', set())
        self.assertTrue(model.disposed)

    def test_reopen_verifier_rejects_missing_original_id(self):
        path, obj, model, expected = self._verification_fixture()
        obj.Attributes.ObjectId = 'changed-id'
        with self.assertRaises(RuntimeError):
            save_verified_copy._validate(self.Rhino, self.System, path, expected, 'Meters',
                    {'ModelAbsoluteTolerance': .001}, 'AGENT_RUN_ID', 'r03', set())
        self.assertTrue(model.disposed)

    def test_wrapper_rejects_arbitrary_script_name(self):
        with self.assertRaises(ValueError):
            run_config.run({'script_name': '../other.py', 'config_path': '/not-used'})


if __name__ == '__main__':
    unittest.main(verbosity=2)
