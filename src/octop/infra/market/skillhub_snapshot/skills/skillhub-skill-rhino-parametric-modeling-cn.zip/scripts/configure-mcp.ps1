[CmdletBinding()]
param(
    [ValidateSet('router','adapter','rhino7')][string]$Mode = 'router',
    [ValidateSet('7','8','9','WIP')][string]$RhinoVersion = '8',
    [string]$RouterPath,
    [string]$PackagesRoot,
    [string]$PythonPath,
    [string]$Url,
    [int]$RhinoPid = 0,
    [string]$OutFile
)
$ErrorActionPreference = 'Stop'
$bundleRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$entry = [ordered]@{}
if ($Mode -eq 'router' -and $RhinoVersion -ne '7' -and $RhinoPid -gt 0) { throw '-RhinoPid is not supported in router mode. Select the document using the official router; use adapter/rhino7 mode for PID selection.' }
if ($Mode -eq 'router' -and $RhinoVersion -eq 'WIP') { throw 'Specify RhinoVersion 9 for Rhino9 packages; WIP is not a package-directory version.' }
if ($RhinoVersion -eq '7' -or $Mode -eq 'rhino7') {
    $entry.command = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $entry.args = @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $bundleRoot 'scripts\rhino7\stdio.ps1'))
    if ($RhinoPid -gt 0) { $entry.args += @('-RhinoPid',[string]$RhinoPid) }
} elseif ($Mode -eq 'router') {
    if (-not $RouterPath) {
        if (-not $PackagesRoot) { $PackagesRoot = Join-Path $env:APPDATA 'McNeel\Rhinoceros\packages' }
        $verDir = if ($RhinoVersion -eq '8') { '8.0' } else { '9.0' }
        $baseDir = Join-Path $PackagesRoot "$verDir\Rhino-MCP-Platform"
        $archName = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'win-arm64' } else { 'win-x64' }
        $candidates = @()
        if (Test-Path -LiteralPath $baseDir) {
            foreach ($pkgDir in @(Get-ChildItem -LiteralPath $baseDir -Directory)) {
                $candidate = Join-Path $pkgDir.FullName "router\$archName\rhino-mcp-router.exe"
                if (Test-Path -LiteralPath $candidate -PathType Leaf) { $candidates += $candidate }
            }
        }
        if ($candidates.Count -eq 0) { throw "No installed official router found under $baseDir. Install the matching package first or use -RouterPath from MCPConnect." }
        if ($candidates.Count -gt 1) { throw ("Multiple routers found. Pass -RouterPath for the package active in MCPConnect:`n" + ($candidates -join "`n")) }
        $RouterPath = $candidates[0]
    }
    $RouterPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($RouterPath)
    if (-not (Test-Path -LiteralPath $RouterPath -PathType Leaf)) { throw "Router executable missing: $RouterPath" }
    $entry.command = $RouterPath
    $entry.args = @('--default-version', $RhinoVersion)
} else {
    if (-not $PythonPath) { throw 'Adapter mode requires -PythonPath pointing to a Python 3.10+ executable.' }
    $PythonPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($PythonPath)
    if (-not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) { throw "Python executable missing: $PythonPath" }
    if ($Url -and $RhinoPid -gt 0) { throw 'Choose either -Url or -RhinoPid, not both.' }
    $adapterArgs = @((Join-Path $bundleRoot 'adapter\rhino_stdio_adapter.py'), 'stdio')
    if ($Url) { $adapterArgs += @('--url', $Url) }
    elseif ($RhinoPid -gt 0) { $adapterArgs += @('--pid', [string]$RhinoPid) }
    $entry.command = $PythonPath
    $entry.args = $adapterArgs
    $entry.env = @{ PYTHONIOENCODING = 'utf-8'; PYTHONUTF8 = '1' }
}
$json = @{ mcpServers = @{ 'rhino-cn' = $entry } } | ConvertTo-Json -Depth 12
if ($OutFile) {
    $OutFile = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutFile)
    if (Test-Path -LiteralPath $OutFile) { throw 'Output exists. Choose a new filename. Existing agent settings are never overwritten by this helper.' }
    $outParent = Split-Path -Parent $OutFile
    if (-not (Test-Path -LiteralPath $outParent -PathType Container)) { throw 'Output parent directory does not exist.' }
    [IO.File]::WriteAllText($OutFile, $json, (New-Object Text.UTF8Encoding $false))
    Write-Output "Created configuration fragment: $OutFile"
} else {
    Write-Output $json
}
