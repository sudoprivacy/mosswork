#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('get_context','run_python','run_template','get_viewport_image','get_request_status')][string]$Method = 'get_context',
    [string]$ParamsFile,
    [int]$RhinoPid = 0,
    [string]$SessionFile,
    [string]$RequestId
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
. (Join-Path $PSScriptRoot 'transport.ps1')
$parameters = @{}
if ($ParamsFile) {
    $parameters = Get-Content -LiteralPath $ParamsFile -Raw -Encoding UTF8 | ConvertFrom-Json
}
$answer = Invoke-Rhino7Request -Method $Method -Parameters $parameters -RhinoPid $RhinoPid -SessionFile $SessionFile -RequestId $RequestId
$answer | ConvertTo-Json -Depth 90 -Compress
if ($answer.status -ne 'ok') { exit 1 }
