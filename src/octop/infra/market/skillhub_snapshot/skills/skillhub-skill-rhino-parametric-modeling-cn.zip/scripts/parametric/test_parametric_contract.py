# -*- coding: utf-8 -*-
"""Offline behavioral tests; no Rhino or Grasshopper calls."""
from __future__ import print_function
import copy
import hashlib
import math
import os
import sys
import tempfile
import unittest
from decimal import Decimal

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import parametric_contract as contract


class ParametricTests(unittest.TestCase):
    def test_output_creation_is_exclusive_and_preserves_existing_bytes(self):
        descriptor, path = tempfile.mkstemp(suffix='.json')
        try:
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(b'original-output')
            with self.assertRaises(IOError):
                contract.write_new_json(path, 'replacement')
            with open(path, 'rb') as stream:
                self.assertEqual(stream.read(), b'original-output')
            os.remove(path)
            contract.write_new_json(path, '{"new": true}')
            with open(path, 'rb') as stream:
                self.assertEqual(stream.read(), b'{"new": true}')
        finally:
            if os.path.exists(path):
                os.remove(path)

    def test_default_panel_count_and_analytic_holes(self):
        result = contract.build_recipe(contract.example_parameters())
        self.assertEqual(result['derived']['feature_count'], 171)
        self.assertEqual(len(result['recipe']['features']), 171)
        self.assertTrue(all(f['kind'] == 'circular_through_cut' for f in result['recipe']['features']))
        self.assertIsNone(result['native_builder_sha256'])

    def test_all_generated_holes_obey_real_clearances(self):
        result = contract.build_recipe(contract.example_parameters())
        p = result['parameters_si']
        holes = result['recipe']['features']
        for i, hole in enumerate(holes):
            x, y = hole['center_xy_m']
            r = hole['radius_m']
            self.assertGreaterEqual(min(x-r, y-r, p['panel_width']-x-r, p['panel_height']-y-r), p['edge_margin']-1e-12)
            for other in holes[i+1:]:
                a, b = other['center_xy_m']
                distance = math.hypot(x-a, y-b)-r-other['radius_m']
                self.assertGreaterEqual(distance, p['minimum_web']-1e-12)

    def test_equivalent_mm_and_m_have_identical_parameter_hash(self):
        mm = contract.example_parameters()
        meters = copy.deepcopy(mm)
        meters['units'] = 'm'
        for key, spec in contract.SCHEMAS['perforated_panel']['parameters'].items():
            if spec['type'] == 'length':
                meters['parameters'][key] = Decimal(str(mm['parameters'][key])) / 1000
        self.assertEqual(contract.validate_parameters(mm)['parameter_hash'],
                         contract.validate_parameters(meters)['parameter_hash'])

    def test_provenance_does_not_change_geometry_inputs_hash(self):
        first = contract.example_parameters()
        second = copy.deepcopy(first)
        second['provenance']['run_id'] = 'new_bake_batch'
        self.assertEqual(contract.validate_parameters(first)['parameter_hash'],
                         contract.validate_parameters(second)['parameter_hash'])

    def test_seeded_recipe_is_deterministic_and_seed_sensitive(self):
        first = contract.example_parameters()
        self.assertEqual(contract.build_recipe(first)['recipe_hash'], contract.build_recipe(first)['recipe_hash'])
        second = copy.deepcopy(first)
        second['seed'] += 1
        self.assertNotEqual(contract.build_recipe(first)['recipe_hash'], contract.build_recipe(second)['recipe_hash'])

    def test_rib_identity_noise_does_not_shift_when_count_changes(self):
        first = contract.example_parameters('rib_array')
        second = copy.deepcopy(first)
        second['parameters']['count'] = 21
        a = contract.build_recipe(first)['recipe']['features']
        b = contract.build_recipe(second)['recipe']['features']
        self.assertEqual([(f['id'], f['max_m'][2]) for f in a], [(f['id'], f['max_m'][2]) for f in b[:len(a)]])

    def test_ribs_have_requested_gap_and_single_rib_is_defined(self):
        config = contract.example_parameters('rib_array')
        result = contract.build_recipe(config)
        ribs = result['recipe']['features']
        for left, right in zip(ribs, ribs[1:]):
            self.assertGreaterEqual(right['min_m'][0]-left['max_m'][0], .040-1e-12)
        config['parameters']['count'] = 1
        one = contract.build_recipe(config)
        self.assertIsNone(one['derived']['clear_gap_m'])
        self.assertAlmostEqual(sum([one['recipe']['features'][0]['min_m'][0], one['recipe']['features'][0]['max_m'][0]])/2, 1.5)

    def test_invalid_scalar_and_cross_field_inputs_fail(self):
        for key, value in [('hole_diameter', float('nan')), ('hole_diameter', float('inf')),
                           ('hole_diameter', True), ('pitch_x', 10)]:
            config = contract.example_parameters()
            config['parameters'][key] = value
            with self.assertRaises(contract.ParameterError):
                contract.validate_parameters(config)
        for field, value in [('units', []), ('seed', True)]:
            config = contract.example_parameters()
            config[field] = value
            with self.assertRaises(contract.ParameterError):
                contract.validate_parameters(config)

    def test_unused_knob_and_fractional_count_do_not_silently_pass(self):
        config = contract.example_parameters()
        config['parameters']['unused_knob'] = 3
        with self.assertRaises(contract.ParameterError):
            contract.validate_parameters(config)
        config = contract.example_parameters('rib_array')
        config['parameters']['count'] = 20.0
        with self.assertRaises(contract.ParameterError):
            contract.validate_parameters(config)

    def test_dependency_order_cycles_and_unknown_inputs(self):
        order = contract.topological_order({'a': [], 'b': ['a'], 'c': ['b']})
        self.assertEqual(order, ['a', 'b', 'c'])
        for bad in [{'a': ['b'], 'b': ['a']}, {'a': ['missing']}]:
            with self.assertRaises(contract.ParameterError):
                contract.topological_order(bad)

    def test_all_generated_cases_match_stated_validity(self):
        count = 0
        for kind in sorted(contract.SCHEMAS):
            for case in contract.generate_cases(kind):
                try:
                    contract.validate_parameters(case['config'])
                    valid = True
                except contract.ParameterError:
                    valid = False
                self.assertEqual(valid, case['expect_valid'], case['case_id'])
                count += 1
        self.assertGreater(count, 40)

    def test_source_reference_is_explicit_and_verified_as_bytes_only(self):
        config = contract.example_parameters()
        for path in ['../source.3dm', '/outside/source.3dm', 'C:/outside/source.3dm']:
            config['source'] = {'3dm_relative_path': path, 'sha256': '0'*64, 'object_ids': []}
            with self.assertRaises(contract.ParameterError):
                contract.validate_parameters(config)
        handle, path = tempfile.mkstemp(suffix='.3dm')
        try:
            content = b'NOT A REAL 3DM: source hash fixture'
            with os.fdopen(handle, 'wb') as stream:
                stream.write(content)
            config['source'] = {'3dm_relative_path': os.path.basename(path),
                                'sha256': hashlib.sha256(content).hexdigest(), 'object_ids': []}
            result = contract.verify_source_file(config, os.path.dirname(path))
            self.assertTrue(result['sha256_checked'])
            self.assertFalse(result['geometry_parsed'])
            config['source']['sha256'] = '0'*64
            with self.assertRaises(contract.ParameterError):
                contract.verify_source_file(config, os.path.dirname(path))
        finally:
            os.remove(path)  # Exact mkstemp-created file; no recursive cleanup.

    def test_validation_does_not_mutate_the_input(self):
        config = contract.example_parameters()
        before = copy.deepcopy(config)
        contract.build_recipe(config)
        self.assertEqual(config, before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
