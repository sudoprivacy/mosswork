# 通用参数合同与解析配方

本目录只依赖 Python 标准库，可离线执行。完整工作流见 `../../references/10-grasshopper-and-parametric-delivery.md`。

```powershell
python parametric_contract.py validate parameters.example.json
python parametric_contract.py recipe parameters.ribs.example.json
python parametric_contract.py cases --kind perforated_panel
python test_parametric_contract.py
```

使用 `--out 新文件.json` 保存结果；已有文件不被覆盖。成功退出码 0，参数/文件错误退出码 2。`--source-root 交付目录` 可验证引用的源文件字节摘要；GUID/几何检查仍需 Rhino。

| 示例 | 输入事实来源 | 派生数据 |
|---|---|---|
| 可调圆孔板 | 尺寸、孔距、孔径、边距、腹板、偏移幅度与 seed | 行列数、孔中心、保证间距、开孔率 |
| 独立肋阵列 | 跨度、数量、截面、退距、净距与 seed | 中心距、稳定肋 ID、高度、盒体边界、体积 |

输出为规范化参数和解析构建配方，**不是已经生成的 Rhino 实体或 GH 定义**。`native_builder_sha256=null` 明确保留待完成项。真实交付应补入 builder/.gh、选定参数、源几何（如有）、版本和重算记录。

本包演示参数使用与Rhino检查/保存模板一致的默认标签键 `AGENT_RUN_ID`。原生生成器、inspect与保存配置必须使用同一个 `generation_tag_key` 和同一个run_id。旧任务若已用 `PARAMETRIC_RUN_ID` 或自定义键，继续显式传入该键，不自行改现有对象标签。此调整只统一示例来源标记，不改变几何算法、参数合同或builder版本。

测试日期 2026-09-08：外部 CPython 3.11.7，14 项离线测试通过；无 Rhino/GH 调用。测试还遍历生成器给出的有效/无效案例，并独立测量所有默认孔的边距/互距和默认肋间距，检查原子拒绝覆盖已有输出。没有将这些测试表述为 Rhino/GH 原生集成验证。
