#requires -Version 5.1
# Compile only with installed Rhino7's actual IronPython engine. Never starts Rhino.
[CmdletBinding()]
param([string]$RhinoRoot=(Join-Path $env:ProgramFiles 'Rhino 7'))
$ErrorActionPreference='Stop'
$folder=Join-Path $RhinoRoot 'Plug-ins\IronPython'
foreach ($name in @('Microsoft.Scripting.dll','Microsoft.Dynamic.dll','IronPython.dll')) {
    [void][Reflection.Assembly]::LoadFrom((Join-Path $folder $name))
}
$engine=[IronPython.Hosting.Python]::CreateEngine()
$compiled=@()
$paths=@(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.py' -File)
$paths+=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot '..\rhino') -Filter '*.py' -File)
foreach ($file in $paths) {
    $source=[IO.File]::ReadAllText($file.FullName,[Text.Encoding]::UTF8)
    [void]$engine.CreateScriptSourceFromString($source,[Microsoft.Scripting.SourceCodeKind]::File).Compile()
    $compiled+=$file.Name
}
[ordered]@{status='syntax_passed'; engine_version=$engine.LanguageVersion.ToString(); files=$compiled; geometry_executed=$false; rhino_launched=$false} | ConvertTo-Json -Depth 8
