# -*- coding: utf-8 -*-
"""Wrapper entry point, run inside Rhino, not in an external Python process.

Inject CONFIG={"script_name":"inspect_document.py","config_path":absolute_json}.
Only the three bundled operation names are accepted; no code comes from JSON.
"""
from __future__ import print_function
import json
import os
import sys


def run(wrapper_config):
    allowed = ('inspect_document.py', 'capture_views.py', 'save_verified_copy.py')
    name = wrapper_config['script_name']
    if name not in allowed:
        raise ValueError('Choose one of the bundled Rhino script names')
    folder = os.path.dirname(os.path.abspath(__file__))
    config_path = wrapper_config['config_path']
    if not os.path.isabs(config_path):
        raise ValueError('config_path must be absolute')
    with open(config_path, 'rb') as stream:
        config = json.loads(stream.read().decode('utf-8-sig'))
    if not isinstance(config, dict):
        raise ValueError('Configuration must be a JSON object')
    path = os.path.join(folder, name)
    if folder not in sys.path:
        sys.path.insert(0, folder)
    scope = {'__name__': '__main__', '__file__': path, 'CONFIG': config}
    if '__rhino_doc__' in globals():
        scope['__rhino_doc__'] = globals()['__rhino_doc__']
    with open(path, 'rb') as stream:
        code = compile(stream.read(), path, 'exec')
    eval(code, scope)
    return scope['result']


if __name__ == '__main__':
    if 'CONFIG' not in globals():
        raise ValueError('Inject wrapper CONFIG with script_name and config_path')
    result = run(CONFIG)
