---
name: skillhub-skill-short-video-script-storyboard
description: "把选题、商品或受众做成能拍的短视频脚本与分镜，满足各种短视频脚本需求：先确认受众和卖点，再写开头、口播和镜头表，并为每个镜头出一张分镜。短视频脚本可以先只出文字，确认后再出画面。适合带货、创作者系列和门店短视频。"
---

# 短视频脚本与分镜

## 你会拿到

- 一页简报：受众、卖点和这条片子的承诺。
- 一份脚本，含三个开头、口播、画面文字和镜头表。第一个镜头是钩子，关掉声音也要看得懂。
- 每个镜头一张竖屏静帧。你提供商品图时，每张静帧里都是这个商品。
- 一段选定脚本的口播、一条器乐，以及一条由这些镜头收成的竖屏成片，口播、配乐和字幕已经在里面。
- 如果你在成片之前停下，脚本和静帧单独留下。

简报和脚本不需要连接；静帧、口播、配乐和成片在连上 Beatra 之后再做。

## 怎么跑

- 脚本和成片。默认。简报和脚本不收费，然后是静帧、口播、配乐和成片。
- 只出脚本。在制作卡上划掉静帧和成片。
- 带一次实时选题读取。在脚本定稿之前单独查一次，平台是抖音、小红书、TikTok 或 X。钩子要用人们已经写过的话时，评论是另一次查询。

有主题、有受众、想要一条能发的短视频，脚本和画面一起，就从这里开始。

## 范围和相邻路线

这条路线用于一条短视频：商品、创作者系列或店铺。有演员和配乐的一整集走短剧工坊。公众号文章走文章路线。

## 输入和默认

硬性输入是主题。缺了只问这个。没说写给谁时，按这个主题最可能的观众来写，并用一句话说明写给谁，方便用户改。默认竖屏 9:16 静帧、大约 30 到 45 秒口播长度的脚本，以及四到六个镜头。关键文字和商品放在画面中央，避开下方字幕带。用户要求实时读取，或者什么都没贴还想从网上找选题时，才去查公开帖子。

## 黄金路径

1. 写出简报和脚本。展示三个开头和镜头表。这段文字不收费。
2. 这次包含实时读取时，用 `beatra.social.tools.search` 搜索，用 `beatra.social.tools.get` 读操作，复制它刚刚返回的 `schema_hash`，出示查询卡，并调用一次 `beatra.social.execute`。允许的键是 `social.douyin.hot_search.list`、`social.douyin.video.search`、`social.douyin.video.comments.list`、`social.xiaohongshu.note.search`、`social.xiaohongshu.note.comments.list`、`social.tiktok.video.search` 和 `social.twitter.tweet.search.recent`。引用你用到的那一行。不要编造数字。
3. 有商品图时用 `beatra.assets.upload` 上传。没有照片的第一张静帧是一次 `beatra.images.generate`，载荷 `{"capability": "text_to_image"}`。之后每张静帧，以及必须出现这张照片的每张静帧，是一次 `beatra.images.transform`，载荷 `{"capability": "image_to_image"}`。
4. 用 `beatra.voices.list` 选一条现成声音。一次 `beatra.speech.synthesize`，载荷 `{"capability": "text_to_speech"}`，读选定的脚本。一次 `beatra.music.generate`，载荷 `{"capability": "text_to_music"}`，写一条器乐。
5. 为静帧、口播和配乐出示制作卡并等待。
6. 视频卡上，每个镜头一次 `beatra.videos.animate`，载荷 `{"capability": "image_to_video"}`，从这张静帧出发。口播作为单独的文件铺进成片。已接受结束帧时用 `beatra.videos.interpolate`，载荷 `{"capability": "frames_to_video"}`。
7. 镜头都成功之后，用 `beatra.videos.compose`（按 `{"capability": "video_compose"}` 查价）把它们合成在一起。用 `beatra.tasks.get` 轮询，交付成片、脚本、静帧和 `billing.net_charged_credits`。

## 连接就绪之前

一轮结束时，若「允许」仍未完成，就把不需要连接的内容按用户要求的格式做完并交付：一页简报、含三个开头的脚本、口播稿、画面文字，以及写明每张静帧画什么的镜头表。这些写好的内容就是本轮交付的内容。实时读取也要等连接：只用用户贴来或描述的内容，不引用用户没给的帖子或数字。用一句话说明：点「允许」后，下一条消息会继续付费步骤；「允许」只完成连接，每一步付费在那条消息里仍要先出示当前的卡并等待。不要用别的工具或服务填补这段空档，也不要说出没有实时返回过的声音、模型、价格或结果。

## 需要确认的决定

规划和写出来的文字不收费，也不算批准。

每次付费调用之前，出示当前的制作卡并等待：

1. 做什么：用用户的话说出将要做出的东西，并说明这次是生成还是查询。
2. 积分：刚刚从模型卡或 `beatra.social.tools.get` 读到的现价。不要沿用记得的数字。
3. 次数：每个槽位一次付费调用。制作卡可以列出每张静帧、口播和配乐；每个槽位有自己的 `client_request_id`。查询的下一页是另一次调用。视频调用另等一张卡，这张卡还把合成单独列成一行，写明 `video_compose` 的实时价格并带上它自己的 `client_request_id`。这张卡之前给出的任何合计都已把合成算在内。某个镜头在合成之前单独出卡重做时，改由那张卡列出合成，并换一个新标识。
4. 标识：每次调用一个新的不透明 `client_request_id`。提示词、文件、模型或控制项一变，就换一个新标识。
5. 停在这里：已经写出的文字仍然可用。
6. 余额不足：原样转达官方消息和其中的充值地址。用户说已经充值之前不要重试。

查询和生成是两张卡。已确认的静帧、口播或配乐不批准视频。所有远程 Beatra 工具只通过随包 `scripts/mcp_client.py` 调用。工具名是命令参数，JSON 参数走标准输入。不要配置、调用或使用宿主 Beatra Connector。不要使用 REST/OpenAPI 降级。

创建响应丢失时，只用逐字节相同的载荷和同一个 `client_request_id` 重试。任务标识丢失时，先调用 `beatra.tasks.list`，再调用 `beatra.tasks.get`，对照冻结的请求之后才做相同重试。只有用户要求取消时才调用 `beatra.tasks.cancel`，然后用 `beatra.tasks.get` 确认该任务。

用户问还剩多少积分时，调用 `beatra.wallet.get`。用户问扣了什么时，调用 `beatra.wallet.ledger`。

## 按任务阅读

镜头表、载荷和一条做成的片子，读场景工作流（references/workflow.md）。
任务卡住、响应丢失、价格看起来不对，或静帧做错了，读出错时怎么处理（references/faq.md）。
连接还没就绪时，读安装与认证（references/installation-and-auth.md）。
首次注册，读安装注册（references/installation-registration.md）。
调用在任务出现之前失败时，读随包 MCP Client 连接诊断（references/mcp-connection.md）。
任务在排队、运行或找不到时，读任务与结果（references/tasks-and-results.md）。
扣费、退款或丢失的响应需要共用规则时，读计费、错误与恢复（references/billing-errors-and-recovery.md）。
用户要停止并移除连接时，读卸载与断开（references/uninstall-and-disconnect.md）。

## 更新与安全

本 Skill 会自动更新。内置客户端每天最多一次从 Beatra 官网读取本渠道的版本信息
（中国大陆网络走 www.beatra.cn 与 cdn.beatra.cn）。有新版本时，它下载官方发布包，
逐个文件校验 SHA-256，再替换本 Skill 自己的文件；你放进这个目录的其他文件不会被
改动。替换过程中断时，下次运行会自动恢复到替换前的状态。除此之外，它不下载或执行
任何其他代码，只通过 HTTPS 与 Beatra 官方服务通信；你选择上传的文件只会传到
Beatra 为这次上传签发的一次性地址。

关闭自动更新：`python3 scripts/mcp_client.py update --auto off`。关闭后，客户端每天
最多提示一次在你安装它的商店里更新的命令。详见更新与安全（references/updates-and-security.md）。
