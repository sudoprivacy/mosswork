# -*- coding: utf-8 -*-
"""社团活动策划书模板固化包（st-uni-39）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：《社团活动策划书》学术工具成品（框架/模板，引用格式锚定GB/T 7714-2015）；完成标准与自检清单；查重与学术诚信自查说明
建议输入（专业字段）：考试/科目；备考周期；当前基础
"""
import json, os, re, sys, time

SLUG = "st-uni-39"
TITLE = "社团活动策划书模板固化包"
PRICE_FEN = 2990
CATEGORY = "学生学习成长"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['考试/科目', True, ['考试', '科目', '考试名称'], '以官方大纲为唯一依据'], ['备考周期', True, ['周期', '备考时间', '剩余时间'], '决定节奏与周数'], ['当前基础', True, ['基础', '现有水平', '起点'], '基础决定起点与时间分配'], ['目标', False, ['目标分数', '目标', '期望'], '目标应可衡量'], ['每日可用时间', False, ['每天时间', '可用时间', '学习时长'], '决定每周任务量']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'mods': [['基础巩固模块', '30%', '概念梳理+课后题', '课本概念、公式与基本题型过关'], ['专项突破模块', '25%', '专题训练', '薄弱章节专题集中训练（错因分类定位）'], ['综合训练模块', '20%', '套卷限时', '按考试节奏限时训练与答题顺序优化'], ['错题复盘模块', '15%', '错题重做', '错题本三栏法：原题+错因+正确解法与同类题'], ['节奏与心态模块', '10%', '作息与复盘', '作息表、运动与心态调适，考试周弹性安排']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['艾宾浩斯遗忘曲线复习节点：当天/次日/3天/7天/15天各滚动复习一次', '康奈尔笔记法：笔记栏/线索栏/总结栏，课后24小时内补线索栏', '错题本三栏法：原题+错因（概念/计算/审题/表达/时间五类）+正确解法与同类变式', '番茄工作法：25分钟专注+5分钟休息，中学生单日学习块≤4个连续番茄', '《GB/T 7714-2015》文后参考文献著录规则（论文与报告引用格式）', '四六级：全国统考每年6月/12月，425分为常见报道门槛线', '考研时间线：9月预报名、10月正式报名、12月下旬初试、次年3~4月复试调剂', '中考体育与招生政策各地逐年调整，执行前以当地当年中招方案为准']
# 自检项（输入完备度）
CHECKS = [['社团活动策划书模板固化·学情与目标核查', ['社团活动策划书模板固化', '面向大学生课程与学术场景'], '先核对当前学情、可用时间与可衡量目标，缺基线不排计划'], ['社团活动策划书模板固化·方法与依据', ['面向大学生课程与学术场景', '引用格式锚定/'], '方法落到真实学习科学锚点（记忆曲线/错因分类/限时训练），不空谈'], ['社团活动策划书模板固化·计划可执行性', ['引用格式锚定/', '7714-2015'], '任务到天到时段，负荷与学生作息匹配并留弹性'], ['社团活动策划书模板固化·家校与诚信边界', ['社团活动策划书模板固化', '附自检清单'], '明确家长角色与诚信边界，拒绝代写、作弊与真题泄露'], ['社团活动策划书模板固化·诚信红线', ['代写作业', '作弊'], '不得代写作业或组织作弊，命中即终止']]
# 交付物构成
DELIVERABLES = ['《社团活动策划书》学术工具成品（框架/模板，引用格式锚定GB/T 7714-2015）', '完成标准与自检清单', '查重与学术诚信自查说明']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """教学考试交付物：考纲结构 → 掌握度诊断 → 学习路径 → 专项训练 → 自测复盘 → 合规声明"""
    P = ctx["spec"]["params"]; L = []
    exam = ctx["fv"]("考试/科目") or ctx["spec"]["title"]
    period = ctx["fv"]("备考周期")
    base = ctx["fv"]("当前基础")
    target = ctx["fv"]("目标")
    hours = ctx["nm"]("每日可用时间")
    mods = P.get("mods") or []       # [[模块, 权重, 题型, 核心考点], ...]

    L.append(("一、考纲与题型结构", [
        "- 考试/科目：%s" % brief(exam, 50),
        "- 备考周期：%s" % (brief(period, 30) or "（未提供，建议至少留出 8 周）"),
        "- 当前基础：%s" % (brief(base, 50) or "（未提供，基础决定起点与节奏）"),
        "- 目标：%s" % (brief(target, 40) or "（未提供，目标应可衡量）"),
        "- 每日可用时间：%s" % (("%s 小时" % fmt(hours)) if hours is not None else "（未提供，按 1.5 小时估算）"),
        "",
        "以官方考试大纲为唯一依据编制计划；大纲版次与生效年份须记录，避免用过期大纲。",
    ]))

    rows = ["| 模块 | 分值权重 | 常见题型 | 核心考点 | 当前掌握度 |", "|---|---|---|---|---|"]
    for m in mods:
        rows.append("| %s | %s | %s | %s | 待自评（掌握/模糊/不会） |" % (m[0], m[1], m[2], m[3]))
    if not mods:
        rows.append("| 待补充模块 | — | — | — | — |")
    L.append(("二、模块与掌握度诊断", rows))

    weeks = 8
    try:
        if period and period[0].isdigit():
            weeks = int(re.match(r"(\d+)", period).group(1))
    except Exception:
        weeks = 8
    if weeks > 24:
        weeks = 24
    per = max(1, weeks // 3)
    L.append(("三、学习路径（%d 周）" % weeks, [
        "| 阶段 | 周次 | 任务 | 产出 |", "|---|---|---|---|",
        "| 打基础 | 第 1~%d 周 | 按模块过一遍考纲要点，只求理解与建立框架 | 自建知识框架图 |" % per,
        "| 做真题 | 第 %d~%d 周 | 近 3~5 年真题按模块拆解，统计错因 | 错因统计表 |" % (per + 1, per * 2),
        "| 补短板 | 第 %d~%d 周 | 只攻错因排名前列的薄弱点 | 专项训练记录 |" % (per * 2 + 1, weeks - 1),
        "| 模拟复盘 | 第 %d 周 | 限时整卷模拟，稳定答题节奏 | 模考成绩曲线 |" % weeks,
        "",
        "时间分配按「模块权重 × 当前薄弱程度」排序，把最多时间给「权重高且薄弱」的模块。",
    ]))

    L.append(("四、薄弱点专项训练", [
        "| 错因类型 | 典型表现 | 训练方式 | 检验标准 |", "|---|---|---|---|",
        "| 概念不清 | 同类题反复错 | 回归教材原文 + 自述概念 | 能合上书讲清楚 |",
        "| 计算失误 | 思路对但结果错 | 限时计算专项 + 步骤留痕 | 连续 10 题无计算错误 |",
        "| 审题偏差 | 答非所问 | 拆解题干要素训练 | 能标出题干全部限制条件 |",
        "| 表达不规范 | 会做但丢分 | 对照评分标准改自己的答案 | 按评分点自查得分 |",
        "| 时间不够 | 会做但没做完 | 分模块限时训练 | 整卷留出 10% 检查时间 |",
    ]))

    L.append(("五、自测与复盘", [
        "| 时点 | 动作 | 记录 |", "|---|---|---|",
        "| 每周 | 一次模块小测 | 正确率、耗时、错因 |",
        "| 每两周 | 一次混合测试 | 跨模块迁移能力 |",
        "| 考前两周 | 两次整卷模考 | 分数曲线与节奏问题 |",
        "",
        "复盘三问：错在哪（知识点）？为什么错（错因类型）？下次怎么避免（具体动作）？只写第一问等于没复盘。",
    ]))

    L.append(("六、合规与声明", [
        "- 学习计划基于公开考试大纲与通用备考方法编制，不涉及任何真题泄露、押题售卖或考试作弊内容。",
        "- 不承诺考试分数或录取结果；实际成绩取决于个人基础、投入时间与当年考试情况。",
        "- 所有训练材料应使用正规出版或官方公布的资料，不得使用未经授权的内部资料。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
