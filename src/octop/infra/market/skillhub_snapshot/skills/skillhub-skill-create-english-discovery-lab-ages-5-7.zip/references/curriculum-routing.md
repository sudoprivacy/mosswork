# 课程与语言等级路由

只在用户要求课程对齐时读取并核对当前版本：

- 新西兰课程官方入口：https://newzealandcurriculum.tahurangi.education.govt.nz/
- 新西兰家长年级指南：https://www.education.govt.nz/parents-and-caregivers/schools-year-0-13/understand-your-childs-learning/new-zealand-curriculum-year-by-year-learning-guide
- 英格兰国家课程：https://www.gov.uk/government/collections/national-curriculum
- 澳大利亚课程 Version 9：https://v9.australiancurriculum.edu.au/
- CEFR Companion Volume：https://www.coe.int/en/web/common-european-framework-reference-languages/cefr-companion-volume-and-its-language-versions

路由规则：

1. 先按实际年龄和英语水平定语言负担，再参考课程主题顺序。
2. CEFR只用于描述语言能力，不代表数学、科学或其他学科水平。
3. 新西兰课程处于分阶段更新期；每次声称对齐前核对实施年份和学习领域状态。
4. “参考官方课程”不等于“获得官方认证”。
5. 不复制受版权保护的练习册、题库、插图或大段课程文本；只提炼目标并原创活动。

