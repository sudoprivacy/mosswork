# 课程数据合同（5–7岁）

生成 UTF-8 JSON 对象，至少包含：

```json
{
  "title": "How Plants Drink",
  "age": 6,
  "english_level": "Pre-A1",
  "subject": "science",
  "duration_minutes": 12,
  "knowledge_points": ["Roots take in water"],
  "objectives": ["Drag water to the roots and say: Roots drink water."],
  "vocabulary": [
    {"term": "root", "definition_en": "The part under the soil.", "hint_zh": "根"}
  ],
  "visual_model": {
    "type": "layered-2.5d",
    "rotation_control": true,
    "layers": ["flower", "stem", "roots", "soil"]
  },
  "interactions": [
    {"type": "drag_drop", "goal": "Move water to the roots.", "keyboard_alternative": true}
  ],
  "checks": [{"prompt": "Where do roots grow?", "answer": "under the soil"}],
  "bilingual_support": {"hint_mode": "tap-to-reveal"},
  "privacy_mode": "no-personal-data"
}
```

约束：

- `age` 必须为5–7。
- `knowledge_points` 保持1–2个；`duration_minutes` 保持8–18分钟。
- 至少一个 `drag_drop` 互动；每个互动提供键盘替代操作。
- `visual_model.layers` 至少2层，并提供旋转控制。
- 英文儿童定义尽量不超过12个空格分隔词。
- HTML 使用原生 HTML/CSS/JavaScript；内联全部资源；不要联网。
- 提供明显的英文朗读按钮，但浏览器不支持语音时仍能完成课程。
- 中文只作提示，不遮盖主要英文内容。

