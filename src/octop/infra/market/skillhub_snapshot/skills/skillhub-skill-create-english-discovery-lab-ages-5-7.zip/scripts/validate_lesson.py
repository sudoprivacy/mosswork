#!/usr/bin/env python3
"""Validate an interactive English-subject lesson for ages 5–7."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

MIN_AGE, MAX_AGE = 5, 7
MIN_MINUTES, MAX_MINUTES = 8, 18
MIN_POINTS, MAX_POINTS = 1, 2
MIN_LAYERS = 2
MAX_DEFINITION_WORDS = 12
FORBIDDEN_KEYS = {
    "full_name", "phone", "email", "address", "school_name", "exact_location",
    "wechat", "photo", "recording", "student_id",
}


def _all_keys(value: Any) -> set[str]:
    if isinstance(value, dict):
        keys = {str(key).lower() for key in value}
        for item in value.values():
            keys.update(_all_keys(item))
        return keys
    if isinstance(value, list):
        keys: set[str] = set()
        for item in value:
            keys.update(_all_keys(item))
        return keys
    return set()


def _list_field(data: dict[str, Any], name: str, errors: list[str]) -> list[Any]:
    value = data.get(name)
    if not isinstance(value, list) or not value:
        errors.append(f"{name} must be a non-empty list")
        return []
    return value


def validate_lesson(data: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    for field in ("title", "english_level", "subject"):
        if not isinstance(data.get(field), str) or not data[field].strip():
            errors.append(f"{field} must be a non-empty string")

    age = data.get("age")
    if not isinstance(age, int) or not MIN_AGE <= age <= MAX_AGE:
        errors.append(f"age must be between {MIN_AGE} and {MAX_AGE}")

    minutes = data.get("duration_minutes")
    if not isinstance(minutes, int) or not MIN_MINUTES <= minutes <= MAX_MINUTES:
        errors.append(f"duration_minutes must be between {MIN_MINUTES} and {MAX_MINUTES}")

    points = _list_field(data, "knowledge_points", errors)
    if points and not MIN_POINTS <= len(points) <= MAX_POINTS:
        errors.append(f"knowledge_points must contain {MIN_POINTS}–{MAX_POINTS} items")
    _list_field(data, "objectives", errors)
    vocabulary = _list_field(data, "vocabulary", errors)
    _list_field(data, "checks", errors)

    for index, item in enumerate(vocabulary):
        if not isinstance(item, dict) or not all(item.get(key) for key in ("term", "definition_en")):
            errors.append(f"vocabulary[{index}] needs term and definition_en")
            continue
        if len(str(item["definition_en"]).split()) > MAX_DEFINITION_WORDS:
            errors.append(f"vocabulary[{index}].definition_en is too long for this age")

    visual = data.get("visual_model")
    if not isinstance(visual, dict):
        errors.append("visual_model must be an object")
    else:
        layers = visual.get("layers")
        if not isinstance(layers, list) or len(layers) < MIN_LAYERS:
            errors.append(f"visual_model.layers must contain at least {MIN_LAYERS} items")
        if visual.get("rotation_control") is not True:
            errors.append("visual_model.rotation_control must be true")

    interactions = _list_field(data, "interactions", errors)
    if interactions:
        if not any(isinstance(item, dict) and item.get("type") == "drag_drop" for item in interactions):
            errors.append("at least one drag_drop interaction is required")
        for index, item in enumerate(interactions):
            if not isinstance(item, dict) or not item.get("goal"):
                errors.append(f"interactions[{index}] needs a goal")
            elif item.get("keyboard_alternative") is not True:
                errors.append(f"interactions[{index}] needs keyboard_alternative=true")

    bilingual = data.get("bilingual_support")
    if not isinstance(bilingual, dict) or bilingual.get("hint_mode") not in {
        "tap-to-reveal", "always", "off"
    }:
        errors.append("bilingual_support.hint_mode is invalid")
    if data.get("privacy_mode") != "no-personal-data":
        errors.append("privacy_mode must be no-personal-data")

    raw = json.dumps(data, ensure_ascii=False).lower()
    if "http://" in raw or "https://" in raw:
        errors.append("lesson data must not contain external URLs")
    forbidden = sorted(_all_keys(data) & FORBIDDEN_KEYS)
    if forbidden:
        errors.append("personal-data fields are forbidden: " + ", ".join(forbidden))

    if errors:
        raise ValueError("\n".join(errors))
    return {
        "valid": True,
        "age_band": f"{MIN_AGE}-{MAX_AGE}",
        "knowledge_points": len(points),
        "interactions": len(interactions),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("lesson_json", type=Path)
    args = parser.parse_args()
    data = json.loads(args.lesson_json.read_text(encoding="utf-8"))
    print(json.dumps(validate_lesson(data), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

