import unittest

from validate_lesson import validate_lesson


def valid_lesson():
    return {
        "title": "How Plants Drink",
        "age": 6,
        "english_level": "Pre-A1",
        "subject": "science",
        "duration_minutes": 12,
        "knowledge_points": ["Roots take in water"],
        "objectives": ["Move water to the roots."],
        "vocabulary": [
            {"term": "root", "definition_en": "The part under the soil.", "hint_zh": "根"}
        ],
        "visual_model": {
            "type": "layered-2.5d",
            "rotation_control": True,
            "layers": ["plant", "roots", "soil"],
        },
        "interactions": [
            {"type": "drag_drop", "goal": "Move water.", "keyboard_alternative": True}
        ],
        "checks": [{"prompt": "Where are roots?", "answer": "Under the soil."}],
        "bilingual_support": {"hint_mode": "tap-to-reveal"},
        "privacy_mode": "no-personal-data",
    }


class LessonValidationTest(unittest.TestCase):
    def test_accepts_valid_lesson(self):
        self.assertTrue(validate_lesson(valid_lesson())["valid"])

    def test_requires_drag_drop(self):
        lesson = valid_lesson()
        lesson["interactions"][0]["type"] = "quiz"
        with self.assertRaisesRegex(ValueError, "drag_drop"):
            validate_lesson(lesson)

    def test_rejects_personal_data(self):
        lesson = valid_lesson()
        lesson["email"] = "child@example.com"
        with self.assertRaisesRegex(ValueError, "personal-data"):
            validate_lesson(lesson)


if __name__ == "__main__":
    unittest.main()

