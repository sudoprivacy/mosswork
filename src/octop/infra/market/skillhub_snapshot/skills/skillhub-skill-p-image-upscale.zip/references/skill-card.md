## Description: <br>
Use when someone wants to upscale or sharpen an existing image for print, large crops, or higher-quality delivery. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative operators use this skill to upscale or sharpen existing images through Pruna's p-image-upscale API for print, large crops, product or mood-board enlargement, and higher-quality delivery. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Source images are sent to Pruna's cloud API for processing. <br>
Mitigation: Use the skill only for images that policy allows Pruna to process, especially for confidential, regulated, or third-party material. <br>
Risk: The skill requires a PRUNA_API_KEY for paid API calls. <br>
Mitigation: Keep the key in environment variables, do not print or commit it, and stop if the key is missing instead of using placeholders. <br>
Risk: Downloaded outputs can overwrite local files if the path is reused. <br>
Mitigation: Confirm output paths before downloads and review saved files before relying on them. <br>
Risk: Upscaling or realism enhancement can introduce artifacts or unwanted changes from the source image. <br>
Mitigation: Use the p-image-upscale quality checklist to inspect detail, fidelity, format, and artifact issues before delivery. <br>


## Reference(s): <br>
- [p-image-upscale model docs](https://docs.api.pruna.ai/guides/models/p-image-upscale) <br>
- [Pruna API quickstart](https://docs.api.pruna.ai/guides/quickstart) <br>
- [Pruna API reference](references/pruna-api.md) <br>
- [API credentials](references/api-credentials.md) <br>
- [p-image-upscale quality checklist](references/p-image-upscale-quality-checklist.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration] <br>
**Output Format:** [Markdown guidance with curl command examples and API parameters] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May result in uploaded source images and downloaded upscaled image files through Pruna's API.] <br>

## Skill Version(s): <br>
1.0.6 (source: server evidence release metadata and skill frontmatter metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
