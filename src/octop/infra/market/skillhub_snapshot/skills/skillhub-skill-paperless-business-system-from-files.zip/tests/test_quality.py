"""隔离临时项目的真实服务端回归，不接触用户数据库；python -m unittest discover -s tests -v。"""
from __future__ import annotations
import hashlib, importlib.util, io, json, os, re, sqlite3, subprocess, sys, tempfile, time, unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from generate_business_system import compile_schema


def spec_example():
    required={'required_confirmed':True}
    return {
        'schema_version':'3.0','system':{'name':'回归测试','deployment_mode':'portable_full','network_mode':'offline_core'},
        'business_objects':[
            {'key':'suppliers','label':'供应商','confirmed_unique_keys':[['code']], 'fields':[{'key':'code','label':'供应商编号','type':'text',**required},{'key':'name','label':'供应商名称','type':'text'},{'key':'date','label':'开户日期','type':'date'}]},
            {'key':'orders','label':'订单','confirmed_unique_keys':[['number']], 'fields':[{'key':'supplier','label':'供应商编号','type':'text',**required},{'key':'number','label':'订单号','type':'text',**required},{'key':'amount','label':'金额','type':'number',**required}]}
        ],
        'roles':[{'key':'production','name':'生产主管'},{'key':'finance','name':'财务主管'},{'key':'manager','name':'总经理'},{'name':'普通用户'}],
        'relationships':[{'label':'订单关联供应商','confirmed':True,'from_object':'orders','from_field':'supplier','to_object':'suppliers','to_field':'code'}],
        'workflows':[{'key':'order_review','label':'订单审核','object':'orders','confirmed':True,'steps':[{'label':'部门会签','roles':['production','finance'],'mode':'all','distinct_from_submitter':True},{'label':'经理审批','roles':['manager'],'mode':'any','distinct_from_submitter':True}]}],
        'ui':{'theme':'classic-red'}
    }


class CompilerTests(unittest.TestCase):
    def test_identifier_and_phone_preserve_leading_zero(self):
        from extract_business_model import infer_field_type
        for label in ('电话号码','手机号','客户编号','邮编','订单号'):
            self.assertEqual(infer_field_type(label,['00123','00456']),'text')
        self.assertEqual(infer_field_type('数量',[1,2]),'number')
    def test_candidate_reference_points_child_to_parent(self):
        from extract_business_model import detect_relationships
        parent={'key':'p','fields':[{'key':'id','label':'供应商编号','type':'text','candidate_unique':True,'relation_samples':['S1','S2']}]}
        child={'key':'c','fields':[{'key':'sid','label':'供应商编号','type':'text','candidate_unique':False,'relation_samples':['S1','S1','S2']}]}
        r=detect_relationships([parent,child])[0]
        self.assertEqual((r['from_object'],r['to_object']),('c','p'));self.assertFalse(r['confirmed'])
    def test_confirmed_complex_spec_compiles(self):
        s=compile_schema(spec_example());self.assertEqual(len(s['relationships_compiled']),1);self.assertEqual(len(s['workflows_compiled']),1);self.assertFalse(s['feature_blockers'])
    def test_unconfirmed_relationship_not_enforced(self):
        s=spec_example();s['relationships'][0]['confirmed']=False
        self.assertFalse(compile_schema(s)['relationships_compiled'])
    def test_nonunique_parent_is_blocked(self):
        s=spec_example();s['business_objects'][0]['confirmed_unique_keys']=[]
        self.assertTrue(compile_schema(s)['feature_blockers'])
    def test_undefined_reviewer_is_blocked(self):
        s=spec_example();s['workflows'][0]['steps'][0]['roles']=['不存在']
        self.assertTrue(compile_schema(s)['feature_blockers'])
    def test_branches_not_silently_ignored(self):
        s=spec_example();s['workflows'][0]['branch']={'amount':100}
        self.assertFalse(compile_schema(s)['workflows_compiled']);self.assertTrue(compile_schema(s)['feature_blockers'])
    def test_custom_report_needs_implementation(self):
        s=spec_example();s['reports']=[{'name':'月度跨表汇总'}]
        self.assertTrue(compile_schema(s)['feature_blockers'])
    def test_special_system_name_generation(self):
        with tempfile.TemporaryDirectory() as td:
            spec=spec_example();spec['system']['name']="旺旺'系统<演示>"
            p=Path(td)/'spec.json';p.write_text(json.dumps(spec,ensure_ascii=False),encoding='utf-8')
            r=subprocess.run([sys.executable,str(ROOT/'scripts/generate_business_system.py'),'--spec',str(p),'--output',str(Path(td)/'out')],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stdout+r.stderr)
            html=(Path(td)/'out/01_服务端_完整程序/templates/base.html').read_text()
            self.assertIn('&lt;演示&gt;',html)
    def test_strict_rejects_missing_coverage(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);p=path/'spec.json';p.write_text(json.dumps(spec_example(),ensure_ascii=False),encoding='utf-8')
            subprocess.run([sys.executable,str(ROOT/'scripts/generate_business_system.py'),'--spec',str(p),'--output',str(path/'project')],check=True,capture_output=True)
            for f in (path/'project').rglob('FEATURE_COVERAGE.json'):f.unlink()
            r=subprocess.run([sys.executable,str(ROOT/'scripts/validate_local_bundle.py'),str(path/'project'),'--strict'],capture_output=True,text=True)
            self.assertNotEqual(r.returncode,0);self.assertIn('缺少业务覆盖清单',r.stdout)
    def test_theme_validation(self):
        for t in ('classic-red','business-blue','readable-slate'):
            s=spec_example();s['ui']['theme']=t;self.assertEqual(compile_schema(s)['ui']['theme'],t)
        s['ui']['theme']='unknown'
        with self.assertRaises(ValueError):compile_schema(s)


class RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='paperless-quality-');cls.base=Path(cls.tmp.name)
        path=cls.base/'spec.json';path.write_text(json.dumps(spec_example(),ensure_ascii=False),encoding='utf-8')
        cls.project=cls.base/'project'
        r=subprocess.run([sys.executable,str(ROOT/'scripts/generate_business_system.py'),'--spec',str(path),'--output',str(cls.project)],text=True,capture_output=True)
        if r.returncode:raise RuntimeError(r.stdout+r.stderr)
        cls.service=cls.project/'01_服务端_完整程序'
        cls.old_data=os.environ.get('DATA_DIR');os.environ['DATA_DIR']=str(cls.base/'test-data')
        sys.path.insert(0,str(cls.service))
        mod_spec=importlib.util.spec_from_file_location('quality_app',cls.service/'app.py');cls.mod=importlib.util.module_from_spec(mod_spec);mod_spec.loader.exec_module(cls.mod)
        cls.app=cls.mod.app
        from core.db import connect
        from core.security import hash_password
        from business.runtime_generated import load_schema,STAGING_DIR
        cls.connect=staticmethod(connect);cls.schema=load_schema();cls.staging=STAGING_DIR
        with connect() as c:
            cls.admin=c.execute("SELECT id FROM users WHERE username='管理员'").fetchone()[0]
            cls.users={}
            for role in ('生产主管','财务主管','总经理','普通用户'):
                rid=c.execute('SELECT id FROM roles WHERE name=?',(role,)).fetchone()[0]
                uid=c.execute('INSERT INTO users(username,password_hash,role_id,must_change_password) VALUES(?,?,?,0)',(role,hash_password('Test-Password-123'),rid)).lastrowid
                cls.users[role]=uid
    @classmethod
    def tearDownClass(cls):
        if cls.old_data is None:os.environ.pop('DATA_DIR',None)
        else:os.environ['DATA_DIR']=cls.old_data
        cls.tmp.cleanup()
    def setUp(self):
        with self.connect() as c:
            for table in ('workflow_votes','workflow_events','workflow_instances','import_receipts','biz_obj_002','biz_obj_001'):
                c.execute(f'DELETE FROM {table}')
            c.execute("INSERT INTO biz_obj_001(c01,c02,created_by) VALUES('S1','供应商一',?)",(self.admin,))
        self.client=self.client_for(self.admin)
    def client_for(self,uid):
        c=self.app.test_client()
        with c.session_transaction() as s:s['uid']=uid;s['_csrf']='quality-token'
        return c
    def post(self,path,data=None,client=None,ajax=False):
        return (client or self.client).post(path,data={'_csrf':'quality-token',**(data or {})},headers={'X-Requested-With':'XMLHttpRequest'} if ajax else {})
    def new_order(self,number='O1',amount='100'):
        return self.post('/business/obj_002/new',{'c01':'S1','c02':number,'c03':amount},ajax=True)
    def order_id(self):
        with self.connect() as c:return c.execute('SELECT MAX(id) FROM biz_obj_002').fetchone()[0]
    def count(self):
        with self.connect() as c:return c.execute('SELECT COUNT(*) FROM biz_obj_002').fetchone()[0]
    def preview(self,content,encoding='utf-8-sig',filename='订单.csv'):
        b=content.encode(encoding) if isinstance(content,str) else content
        r=self.post('/business/obj_002/import',{'action':'preview','file':(io.BytesIO(b),filename)})
        html=r.get_data(as_text=True);m=re.search(r'name="token" value="([^"]+)"',html)
        return r,m.group(1) if m else None
    def commit(self,token,client=None):return self.post('/business/obj_002/import',{'action':'commit','token':token},client=client)
    def instance(self):
        with self.connect() as c:return dict(c.execute('SELECT * FROM workflow_instances').fetchone())
    def flow(self,action,client=None,comment='',version=None):
        rid=self.order_id()
        if version is None:
            with self.connect() as c:
                row=c.execute('SELECT version FROM workflow_instances WHERE object_key=? AND record_id=?',('obj_002',rid)).fetchone()
                version=row[0] if row else 0
        return self.post(f'/business/obj_002/{rid}/workflow',{'action':action,'version':str(version),'comment':comment},client=client)
    def test_chinese_error_no_sql_leak(self):
        self.assertEqual(self.new_order().status_code,200)
        r=self.new_order();self.assertEqual(r.status_code,409)
        body=r.get_data(as_text=True);self.assertIn('PB1201',body);self.assertNotIn('UNIQUE constraint',body);self.assertNotIn(str(self.base),body)
    def test_references_validate_and_query(self):
        r=self.post('/business/obj_002/new',{'c01':'MISSING','c02':'O1','c03':'1'},ajax=True)
        self.assertEqual(r.status_code,400);self.assertEqual(self.count(),0)
        self.new_order();r=self.client.get(f'/business/obj_002/{self.order_id()}/related');self.assertEqual(r.status_code,200);self.assertIn('供应商一',r.get_data(as_text=True))
    def test_reference_delete_and_rekey_are_blocked(self):
        self.new_order()
        with self.connect() as c:pid=c.execute('SELECT id FROM biz_obj_001').fetchone()[0]
        self.assertEqual(self.post(f'/business/obj_001/{pid}/delete').status_code,409)
        self.assertEqual(self.post(f'/business/obj_001/{pid}/edit',{'c01':'S2','c02':'新名称'},ajax=True).status_code,409)
    def test_db_reference_constraint_cannot_be_bypassed(self):
        with self.assertRaises(sqlite3.IntegrityError):
            with self.connect() as c:c.execute("INSERT INTO biz_obj_002(c01,c02,c03) VALUES('missing','O2',10)")
        self.assertEqual(self.count(),0)
    def test_nonfinite_and_large_integers_rejected(self):
        from business.runtime_generated import coerce
        for value in ('nan','inf','-inf','1e999'):
            r=self.new_order(amount=value);self.assertEqual(r.status_code,400)
        with self.assertRaises(ValueError):coerce({'type':'integer'},str(2**64))
        self.assertEqual(self.count(),0)
    def test_division_by_zero_and_excessive_power_rejected(self):
        from business.runtime_generated import SafeCalc
        for expr in ('1/0','2**100000','2**-10000'):
            with self.assertRaises(ValueError):SafeCalc({}).eval(expr)
    def test_invalid_page_does_not_crash(self):
        self.assertEqual(self.client.get('/business/obj_002?page=abc').status_code,200)
    def test_login_uses_reference_card_without_workspace_navigation(self):
        html=self.app.test_client().get('/login').get_data(as_text=True)
        for token in ('class="login-body"','class="login-card"','class="brand-mark"','autocomplete="username"','autocomplete="current-password"','data-password-toggle','登录系统'):
            self.assertIn(token,html)
        self.assertNotIn('class="sidebar"',html);self.assertNotIn('游客密码',html)
    def test_login_failure_preserves_account_not_password(self):
        client=self.app.test_client();client.get('/login')
        with client.session_transaction() as session:token=session['_csrf']
        html=client.post('/login',data={'_csrf':token,'username':'测试账号<测试>','password':'wrong-secret-xyz'}).get_data(as_text=True)
        self.assertIn('测试账号&lt;测试&gt;',html);self.assertNotIn('wrong-secret-xyz',html)
    def test_dashboard_hides_unauthorized_modules(self):
        html=self.client_for(self.users['普通用户']).get('/').get_data(as_text=True)
        self.assertIn('暂无可访问',html);self.assertNotIn('供应商',html)
        self.new_order();html=self.client.get('/').get_data(as_text=True)
        self.assertIn('可查看的业务记录',html);self.assertIn('1 条记录',html)
    def test_all_themes_and_no_premature_modal_message(self):
        body=self.client.get('/business/obj_002').get_data(as_text=True)
        for name in ('经典红','商务蓝','清晰大字'):self.assertIn(name,body)
        js=(self.service/'static/app.js').read_text();self.assertNotIn("postMessage('business:saved'",js)
        for t in ('classic-red','business-blue','readable-slate'):self.assertIn(t,js)
    def test_csv_chinese_encoding(self):
        r,token=self.preview('供应商编号,订单号,金额\nS1,订单一,25.5\n',encoding='gb18030')
        self.assertIsNotNone(token);self.assertEqual(self.commit(token).status_code,302);self.assertEqual(self.count(),1)
    def test_migration_failure_rolls_back_data(self):
        from core.migrations import execute_statements
        with self.assertRaises(sqlite3.OperationalError):
            with self.connect() as c:
                c.execute('BEGIN IMMEDIATE')
                execute_statements(c,"CREATE TABLE rollback_probe(value TEXT); INSERT INTO rollback_probe VALUES('x'); THIS IS INVALID;")
        with self.connect() as c:self.assertIsNone(c.execute("SELECT 1 FROM sqlite_master WHERE name='rollback_probe'").fetchone())
    def test_native_excel_date_import(self):
        import openpyxl
        from datetime import datetime
        wb=openpyxl.Workbook();wb.active.append(['供应商编号','供应商名称','开户日期']);wb.active.append(['S2','新供应商',datetime(2026,11,10)])
        bio=io.BytesIO();wb.save(bio)
        r=self.post('/business/obj_001/import',{'action':'preview','file':(io.BytesIO(bio.getvalue()),'供应商.xlsx')})
        html=r.get_data(as_text=True);token=re.search(r'name="token" value="([^"]+)"',html)
        self.assertIsNotNone(token,html)
        self.post('/business/obj_001/import',{'action':'commit','token':token.group(1)})
        with self.connect() as c:self.assertEqual(c.execute("SELECT c03 FROM biz_obj_001 WHERE c01='S2'").fetchone()[0],'2026-11-10')
    def test_admin_pages_and_permission_denial(self):
        for path in ('/admin/users','/admin/audit'):
            self.assertEqual(self.client.get(path).status_code,200)
            self.assertEqual(self.client_for(self.users['普通用户']).get(path).status_code,403)
        uid=self.users['普通用户'];self.assertEqual(self.client.get(f'/admin/users/{uid}/permissions').status_code,200)
    def test_admin_can_create_user_and_set_persistent_permissions(self):
        with self.connect() as c:role_id=c.execute("SELECT id FROM roles WHERE name='普通用户'").fetchone()[0]
        self.assertEqual(self.post('/admin/users',{'username':'新账号'+str(time.time_ns()),'password':'Test-Password-2026','role_id':str(role_id)}).status_code,302)
        uid=self.users['普通用户']
        self.assertEqual(self.post(f'/admin/users/{uid}/permissions',{'mode':'custom','codes':['biz.obj_002.view']}).status_code,302)
        self.assertEqual(self.client_for(uid).get('/business/obj_002').status_code,200)
        self.assertEqual(self.client_for(uid).get('/admin/users').status_code,403)
        self.post(f'/admin/users/{uid}/permissions',{'mode':'role'})
    def test_last_admin_cannot_be_disabled(self):
        with self.connect() as c:rid=c.execute("SELECT id FROM roles WHERE name='管理员'").fetchone()[0]
        self.assertEqual(self.post(f'/admin/users/{self.admin}',{'role_id':str(rid),'active':'0'}).status_code,409)
    def test_xlsx_preview(self):
        import openpyxl
        wb=openpyxl.Workbook();wb.active.append(['供应商编号','订单号','金额']);wb.active.append(['S1','X1',10]);bio=io.BytesIO();wb.save(bio)
        r,token=self.preview(bio.getvalue(),filename='订单.xlsx');self.assertIsNotNone(token);self.assertEqual(self.commit(token).status_code,302)
    def test_repeated_import_exactly_once(self):
        _,token=self.preview('供应商编号,订单号,金额\nS1,I1,3\n')
        self.assertEqual(self.commit(token).status_code,302);self.assertEqual(self.commit(token).status_code,302);self.assertEqual(self.count(),1)
    def test_concurrent_import_exactly_once(self):
        _,token=self.preview('供应商编号,订单号,金额\nS1,I1,3\n')
        clients=[self.client_for(self.admin),self.client_for(self.admin)]
        with ThreadPoolExecutor(max_workers=2) as pool:statuses=list(pool.map(lambda c:self.commit(token,client=c).status_code,clients))
        self.assertEqual(statuses,[302,302]);self.assertEqual(self.count(),1)
    def test_invalid_import_atomic(self):
        _,token=self.preview('供应商编号,订单号,金额\nS1,I1,3\nS1,I2,错误\n')
        r=self.commit(token);self.assertIn('没有导入任何数据',r.get_data(as_text=True));self.assertEqual(self.count(),0)
    def test_import_collision_after_preview_rolls_back_all(self):
        _,token=self.preview('供应商编号,订单号,金额\nS1,I1,3\nS1,I2,4\n')
        self.new_order('I2');r=self.commit(token);self.assertIn('PB1201',r.get_data(as_text=True));self.assertEqual(self.count(),1)
    def test_duplicate_headers_and_rows_reported(self):
        r,token=self.preview('供应商编号,订单号,金额,金额\nS1,I1,3,3\n');self.assertIsNone(token);self.assertIn('重复字段名',r.get_data(as_text=True))
        r,token=self.preview('供应商编号,订单号,金额\nS1,I1,3\nS1,I1,4\n');self.assertIn('唯一编号重复',r.get_data(as_text=True));self.commit(token);self.assertEqual(self.count(),0)
    def test_stale_preview(self):
        _,token=self.preview('供应商编号,订单号,金额\nS1,I1,3\n')
        p=self.staging/(token+'.json');obj=json.loads(p.read_text());obj['created_at']=0;p.write_text(json.dumps(obj))
        self.assertIn('PB1204',self.commit(token).get_data(as_text=True));self.assertEqual(self.count(),0)
    def test_path_traversal_token_blocked(self):
        self.assertEqual(self.commit('../../secret').status_code,400)
    def test_no_silent_row_truncation(self):
        r,token=self.preview('供应商编号,订单号,金额\n'+''.join(f'S1,I{i},1\n' for i in range(20001)))
        self.assertIsNone(token);self.assertIn('20,000',r.get_data(as_text=True));self.assertEqual(self.count(),0)
    def test_export_has_professional_readable_layout(self):
        import openpyxl
        self.new_order();data=self.client.get('/business/obj_002/export.xlsx').data
        wb=openpyxl.load_workbook(io.BytesIO(data));ws=wb.active
        self.assertEqual(ws.freeze_panes,'A2');self.assertEqual(ws.auto_filter.ref,'A1:C2');self.assertTrue(ws.cell(1,1).font.bold)
        self.assertEqual(ws.cell(1,1).fill.fgColor.rgb[-6:],'D71920');self.assertEqual(ws.cell(2,3).value,100)
        wb.close()
    def test_export_formula_is_literal(self):
        self.new_order(number='=1+1');data=self.client.get('/business/obj_002/export.xlsx').data
        import openpyxl
        wb=openpyxl.load_workbook(io.BytesIO(data));self.assertEqual(wb.active.cell(2,2).data_type,'s');wb.close()
    def test_serial_parallel_workflow(self):
        self.new_order();self.assertEqual(self.flow('submit').status_code,302)
        self.assertEqual(self.flow('approve',client=self.client_for(self.users['总经理'])).status_code,403)
        self.assertEqual(self.flow('approve',client=self.client_for(self.users['生产主管'])).status_code,302);self.assertEqual(self.instance()['step'],0)
        self.assertEqual(self.flow('approve',client=self.client_for(self.users['财务主管'])).status_code,302);self.assertEqual(self.instance()['step'],1)
        self.assertEqual(self.flow('approve',client=self.client_for(self.users['总经理'])).status_code,302);self.assertEqual(self.instance()['state'],'approved')
        self.assertEqual(self.client.get(f'/business/obj_002/{self.order_id()}/workflow').status_code,200)
    def test_approval_replay_and_self_review_blocked(self):
        self.new_order();self.flow('submit');client=self.client_for(self.users['生产主管']);v=self.instance()['version']
        self.flow('approve',client=client,version=v);self.assertEqual(self.flow('approve',client=client,version=v).status_code,409)
        self.assertEqual(self.flow('approve').status_code,403)
    def test_pending_data_cannot_change_or_delete(self):
        self.new_order();self.flow('submit');rid=self.order_id()
        self.assertEqual(self.post(f'/business/obj_002/{rid}/edit',{'c01':'S1','c02':'changed','c03':'1'},ajax=True).status_code,409)
        self.assertEqual(self.post(f'/business/obj_002/{rid}/delete').status_code,409)
    def test_rejection_requires_reason_then_resubmit(self):
        self.new_order();self.flow('submit');client=self.client_for(self.users['财务主管'])
        self.assertIn('请填写驳回原因',self.flow('reject',client=client).get_data(as_text=True));self.assertEqual(self.instance()['state'],'pending')
        self.flow('reject',client=client,comment='资料不全');self.assertEqual(self.instance()['state'],'rejected')
        self.flow('submit');self.assertEqual(self.instance()['cycle'],2)
    def test_unauthorized_workflow_denied(self):
        self.new_order();self.flow('submit');c=self.client_for(self.users['普通用户'])
        self.assertEqual(self.flow('approve',client=c).status_code,403)
    def test_csrf_and_missing_page_friendly(self):
        r=self.client.post('/business/obj_002/new',data={'c01':'S1'});self.assertEqual(r.status_code,400);self.assertIn('PB1208',r.get_data(as_text=True))
        r=self.client.get('/missing');self.assertEqual(r.status_code,404);self.assertIn('PB1210',r.get_data(as_text=True))
    def test_backups_collision_free_and_corrupt_restore_safe(self):
        from core.backup import create_backup,integrity_ok
        from core.config import DB_PATH
        a=create_backup();b=create_backup();self.assertNotEqual(a,b);self.assertTrue(integrity_ok(a));self.assertFalse(integrity_ok(self.base/'missing.db'))
        source=sqlite3.connect(DB_PATH);source.execute('PRAGMA wal_checkpoint(TRUNCATE)');source.close()
        corrupt=self.base/'bad.db';corrupt.write_bytes(b'bad')
        before=hashlib.sha256(DB_PATH.read_bytes()).hexdigest()
        r=subprocess.run([sys.executable,str(self.service/'backup_restore.py'),'restore',str(corrupt)],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0);self.assertEqual(before,hashlib.sha256(DB_PATH.read_bytes()).hexdigest())

if __name__=='__main__':unittest.main(verbosity=2)
