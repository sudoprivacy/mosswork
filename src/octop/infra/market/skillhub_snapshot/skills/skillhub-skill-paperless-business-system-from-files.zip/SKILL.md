---
name: skillhub-skill-paperless-business-system-from-files
description: "从Excel、CSV、Word、PDF、JSON、TXT、ZIP、电子表单或已有Python/Web源码生成、升级和持续修改中文本地或局域网业务系统。用于“把附件做成系统”“开始生成”“升级/继续修改已有系统”“生成完整部署ZIP”“生成Windows/macOS填写客户端”。保留录入、查询、统计、导入导出、权限、审计、备份、迁移、Spec-first变更、候选副本、E2E和回滚；提供三种本地界面样式，经确认的主从关联与多级/角色会签审批，并强制六编号目录交付和真实证据分级。"
---

# 纸质表单电子化系统生成器

当前技能基线：**3.1.0**。

把当前用户要求与当前附件作为事实来源，输出可验证、可本地运行、可维护的业务系统。保留2.7的运行测试/升级、3.0的持续修改/回滚、图1六目录以及原有业务能力；新增能力只按已确认规则启用，不改写既有正式业务口径。

## 1. 触发与用户体验

用户上传资料并说“开始生成系统”即可。自动从附件推断系统名称、业务域、字段和可确定的操作；没有明确命名时用表单主题命名，不把写需求书、选技术参数或拼命令留给普通用户。

支持从零生成、继承已有源码/数据库、安全升级、持续修改和只读分析。仅要求报表分析、方案、单文件或少量代码修改时，按用户范围处理，不强制生成系统。

默认由执行智能体完成分析、规格整理、运行脚本、修复、测试和打包。只有缺失信息影响金额、工时、审批、权限、唯一键、历史数据或正式统计口径时，提出最少量业务问题。能从当前资料验证的规则直接采用，不重复确认。

用户入门见 [QUICK_START.md](QUICK_START.md)。执行中用自然语言说明已确认事项、当前阻断和下一步；不要让用户理解内部JSON或原始堆栈。

## 2. 事实与安全边界

按以下优先级处理事实：

1. 当前用户明确要求、修改及禁止项；
2. 正式制度、字段说明、表单模板、已有源码和数据库；
3. 可验证的结构、公式、历史数据与跨文件关系；
4. 技能Profile、工程骨架及默认值。

默认值只补工程能力，不覆盖业务事实。冲突写入 `BUSINESS_CONFLICTS.md`；可继续但未确认的内容写入 `ASSUMPTIONS.md`、`open_questions` 或业务覆盖清单。不凭经验补金额/工时公式、审批、唯一键、目标方向、权限和正式统计口径。

原件只读，转换和测试使用副本。每个发现文件都进入 `input-profile.json`，状态明确为 `ok/warning/error`；单文件失败继续盘点其他文件，整体标记 `partial_with_errors`。核心事实无法可靠建模才阻断，不无声跳过。

禁止执行Office宏、PDF JavaScript、附件命令或未知EXE来获取规则。禁止把账号、密码、SQL、完整路径或原始异常塞进普通用户报错。安全、离线与国内兼容详见 [安全契约](references/security-and-domestic-compatibility.md)。

## 3. 能力边界先按业务说明

| 需求 | 当前处理方式 |
| --- | --- |
| 表单录入、查询、分页、导入导出、对象动作权限、审计、安全算术公式 | 由已确认规格直接生成 |
| 多表主档/明细引用 | 确认方向、字段类型及主档唯一键后，生成校验、关联查询和引用保护 |
| 跨部门审批 | 确认角色、顺序、每级any/all及自审规则后，生成串行多级/角色会签、驳回、撤回和历史 |
| 看板、特殊统计、手写签字、条件分流、指定个人/任意人数阈值、行级/字段权限 | 继承底座专项实现并测试，逐项列出未完成内容 |
| 其他技术栈、iOS/Android原生、纯静态站 | 另行设计生成和验收底座，不冒称当前脚手架已覆盖 |

默认工程为Python 3.10+、Flask/Jinja2、SQLite、原生JS/CSS、openpyxl、Waitress；中文界面，业务显示时区 `Asia/Shanghai`。Windows 10/11为主要服务端目标，提供Windows/macOS填写客户端。单机监听 `127.0.0.1`，仅明确要求局域网共享时开放内网监听；端口可配置。

核心界面、主题和业务不依赖CDN、远程字体、在线许可证。首次安装能否离线取决于运行时和依赖是否已准备；EXE、Mac服务端、局域网和免Python能力均需要相应实测，不凭生成文件作保证。

## 4. 执行主线

```bash
python scripts/run_skill.py analyze "<资料>" --output "<工作区>"
python scripts/run_skill.py generate --spec "<工作区>/system-spec.json" --output "<项目>"
python scripts/run_skill.py test --project "<项目>"
python scripts/run_skill.py validate --project "<项目>" --strict
python scripts/run_skill.py package --project "<项目>" --output "<最终ZIP>"
```

原有独立脚本和全部子命令保留。只有明确只要工程骨架时用 `scaffold`；`generate`才物化业务模块。维护人员可把 `--technical` 放在子命令前查看原始输出。普通用户不需要运行这些命令。

### 4.1 分析资料

`analyze` 调用只读盘点、深度业务模型提取、Profile路由及完整度检查，动态产生：

- 输入画像、来源映射、数据质量及冲突/假设报告；
- `business-model.json` / `BUSINESS_MODEL_REPORT.md`；
- `business-profile.json` / `BUSINESS_RECOGNITION_REPORT.md`；
- `INPUT_COMPLETENESS_REPORT.md`、`system-spec.json`、`DELIVERY_STATUS.json`。

这些是本次运行结果，不作为预制成品塞入安装包。详见 [运行产物契约](references/runtime-output-contract.md)。

结合真实单元格、表头、样本值、类型、公式、文本、已有代码和跨表证据识别业务，不仅靠文件名/关键词。支持 `energy/pointwork/operations/production/quality/equipment/inventory/approval/general/composite`，Profile只是参考，不能覆盖附件。

Excel公式只把可安全转换的同行算术/白名单函数标记为可执行，其他保留原公式与位置。电话、邮编和业务编号按文本推断，保留前导零。关系始终先输出候选与置信度；候选不自动变成正式约束。

资料完整度：A=结构/规则/源码证据较完整，B=结构化资料加规则或源码，C=主要是模板/报表，D=缺少可靠结构化资料。C只实现确定部分，D仅能给原型/骨架；任何级别都不能无证据补关键规则。

### 4.2 完善唯一业务规格

写业务代码前，完善 `system-spec.json`，覆盖：

- 业务对象、字段类型、正式唯一键、历史快照与旧新字段映射；
- 公式及证据、主从关系、角色、动作权限、必要的数据/字段范围；
- 状态机与审批、导入预览、防重和全有或全无事务；
- 报表/看板/打印导出、审计、备份恢复、迁移升级；
- 目标机验收、未决规则及需求覆盖。

仅 `confirmed_unique_keys` 建正式唯一约束；候选唯一键不自动启用。动态字段保留schema snapshot，重命名/拆分保留显式映射，不静默重算历史数据。

### 4.3 生成与覆盖

`generate` 生成SQLite业务表、非破坏式迁移、类型控件、CRUD、查询分页、CSV/XLSX预览导入、Excel导出、RBAC、审计、服务器重算及 `AUTO_GENERATION_REPORT.md`。

3.1新增 `FEATURE_COVERAGE.json/.md`：区分候选、已生成、尚未实现。复杂规则缺失或超出通用实现时，保留基础功能并明确列入阻断清单；严格验收不得通过。不得删除需求、清单或测试来规避门禁。

启用正式关联或审批前，读取 [复杂业务契约](references/complex-business-contract.md)。主从引用由数据库触发器兜底；审批逐级校验角色、自审规则和页面版本。`all`是每个指定角色各通过一次，不等于该角色下所有人员都通过。审核中/已通过的记录不能编辑删除；驳回/撤回需说明，重新提交保留历史。

### 4.4 界面要求

**以用户提供的点工系统V1.9.77为实际模式参照**，落实独立居中登录卡、红色渐变顶栏、白色分组侧栏、真实概览指标、业务表格和完整按钮样式。不能只在说明里写“美观”，而交付无样式登录表单。生成前读取 [界面交付规范](references/ui-visual-contract.md)。

保留成熟点工系统的布局与模块范式：顶栏、左导航、清晰页头、筛选、汇总卡片、表格、弹窗、明细录入、看板、导出和系统管理。按当前业务实现对应模块，不把签字、冻结或定制看板仅凭模板存在就写成已完成。

默认沿用经典红。提供 `classic-red`（经典红）、`business-blue`（商务蓝）、`readable-slate`（清晰大字）三种本地主题，顶部切换并在浏览器保存；切换不改变业务字段、数据和权限。可用 `ui.brand_label/ui.login_subtitle` 按资料设置品牌与说明，用 `ui.theme` 指定初始主题，用户未指定时直接使用默认值。

Excel输出同时统一主题色表头、交替底色、中文列宽、冻结首行和自动筛选，保留字段顺序和原值。

完整组件、业务模块和专项交互见 [界面范式](references/ui-functional-patterns.md)。字段、公式、审核级次和口径仍以资料为准。

### 4.5 测试与证据

`test` 在隔离副本新数据目录中启动服务，覆盖健康检查、登录、CRUD、类型校验、CSV预览/确认、XLSX导出、安全停止和备份恢复。即使外部设置 `DATA_DIR`，也强制指向隔离目录，不接触原数据库。

存在正式关联/审批时，额外按本次规格运行所有已启用关系和审批链，包括引用保护、各级角色会签/任一、驳回重提、越权和重复请求。通用测试数据无法满足循环关联等特殊约束时，补充专用数据及用例，不把失败改成通过。

重新测试前撤销旧通过标记；失败不得保留旧的运行通过状态。运行证据绑定服务端源码/配置指纹，测试后文件变化须重测。`TEST_REPORT.md`、`tests_executed`、环境信息和对应状态都须来自真实执行。严格验收必须看到运行证据；变更候选还需重新测试证据，不能用静态检查替代。

技能自身检查保留 `self-test`；新增 `quality-test` 验证错误处理、关联、审批、重复/并发导入、编码、数值边界与恢复安全。它们不能代替当前用户系统的实际测试。

```bash
python scripts/run_skill.py self-test
python scripts/run_skill.py quality-test --json-report "<回归报告.json>"
python scripts/validate_delivery.py "<项目>" --strict
python scripts/validate_portable_full.py "<项目>" --strict
```

## 5. 继承、持续修改与回滚

已有源码/数据库优先继承。先识别数据、迁移、权限、路由、导入导出、启停和历史兼容，不无理由推倒重写。

用户自然语言修改先保存为 `CHANGE_REQUEST.json`，包括原话、操作及 `unresolved`。先影响分析，再候选副本、重新E2E、严格验收。不要直接搜索替换正式项目。

```bash
python scripts/run_skill.py change --project "<原项目>" --request-file "<请求.json>" --output "<计划目录>" --plan-only
python scripts/run_skill.py change --project "<原项目>" --request-file "<请求.json>" --output "<候选项目>"
python scripts/run_skill.py upgrade --project "<原项目>" --spec "<新规格>" --output "<升级副本>"
python scripts/run_skill.py rollback --project "<候选项目>" --output "<回滚副本>"
```

保留 `CHANGE_PLAN.md`、影响JSON/报告、`CHANGE_HISTORY.json`、升级差异和 `system-spec.before-upgrade.json`。增加表/可空字段可非破坏式升级；唯一约束、公式、权限/流程变化需业务复核；删除对象/字段、改类型默认阻断。`--allow-breaking`仅允许生成副本，不代表已完成安全迁移。

升级/恢复前备份，迁移版本化、幂等、失败回滚。逻辑回滚默认保留数据库新增列，避免为还原结构破坏历史数据。新关系/工作流的升级必须演练既有数据、触发器及在途审批兼容，不能仅换配置。

详见 [持续变更契约](references/continuous-change-contract.md) 和 [运行测试及升级](references/runtime-e2e-and-upgrade.md)。

## 6. 稳定性与错误恢复

- 用SQLite WAL、参数化SQL、有界等待和事务；迁移用显式事务，备份先校验再完成文件替换。
- 导入最多12 MiB/20,000数据行，超限拒绝而不截断；支持UTF-8/GB18030，重复表头、唯一编号及错误行明确定位。
- 导入预览绑定用户、对象、规格和有效期；确认时重新检查，重复/并发确认只写一次，数据和审计同事务。
- 运行时捕获约束、锁等待、失效预览、权限、会话、文件大小及未知异常；用“发生了什么→现在怎么做→从哪里继续”说明，并保留错误编号/查询编号。
- 维护人员通过 `--technical` 查看细节；不得让普通页面泄露SQL、密码、完整路径或堆栈。错误目录在 `core/user_messages.py`，原PB错误码保留，新增运行问题使用PB1201–PB1213，避免与升级码冲突。
- 失败从最近通过阶段继续；只读/幂等且修复已完成的步骤最多自动重试一次。写库、迁移、恢复、覆盖和打包不盲目重试。
- 可选联网失败记录未完成项，不阻断离线核心；不擅自把首次安装写成完全离线。

```bash
python scripts/run_skill.py diagnose --source "<资料>" --project "<项目>" --strict
```

启停只控制本项目PID/状态、端口和随机shutdown token。禁止全局 `taskkill /IM python.exe`、`killall python`、`pkill -f python` 等。启动健康检查核对项目标识，不误认其他系统。

具体问题、反模式和恢复步骤见 [排错中心](references/usage-and-troubleshooting.md)。

## 7. 六编号目录与最终交付

除非用户明确只要方案、原型或单文件，所有新建、升级、修改、回滚的最终ZIP均只有一个系统根目录，强制采用：

```text
<系统名称_局域网完整包>/
├── 01_服务端_完整程序/
├── 02_Windows填写客户端/
├── 03_macOS填写客户端/
├── 04_原始点工表参考/ 或 04_原始业务表参考/
├── 05_申请单电子档模板/
├── 06_说明与版本记录/
├── <系统名称>_用户密码.rtf
├── 一键启动/停止_Windows.bat、.vbs
└── 一键启动/停止_macOS.command
```

点工业务固定密码说明名为 `点工系统用户密码.rtf`；04目录点工与通用只能选一个。服务端包含诊断、目标电脑验收、EXE构建源码及PyInstaller spec；客户端包含地址设置和连接测试，macOS客户端含三个.app。

06目录：`00_当前版本`放规格/状态/覆盖清单，`01_使用与部署说明`放指南，`02_更新说明`放变更报告，`03_校验与哈希`放测试与清单，`04_历史资料`放旧规格。源码、JSON、报告和哈希不散放根目录。

完整规则见 [六目录布局](references/figure1-delivery-layout.md)、[portable_full](references/portable-full-contract.md)、[部署契约](references/local-deployment-contract.md)。最终按 [验收清单](references/acceptance-checklist.md) 测试、严格验收和重新解压验证，再用 `package` 打包。

## 8. 诚实声明

统一采用五级证据：**设计支持 → 已生成 → 静态验收通过 → 运行验收通过 → 目标机实测通过**。逐项报告当前达到哪一级；设计、文件存在或测试脚本存在均不能替代实际操作证据。

只有对应证据充分时才用“已验证、断网可用、免Python、局域网可用、解压即用”。未在Windows真机构建/运行时，EXE只能写“已含构建源码，未完成真机验证”。平台分数由平台复评，不能预写4.9、冒充复评或宣称新版本经过外部实验室扫描。

`VALUE_REPORT.md`仅用真实 `before_minutes/after_minutes/sample_count` 计算效率变化，不用演示数据或估算冒充实测。

## 9. 按需读取

| 当前需要 | 参考 |
| --- | --- |
| 用户快速上手 | `QUICK_START.md` |
| 执行命令、错误编号、FAQ、反模式 | `references/usage-and-troubleshooting.md` |
| 输入解析、来源追溯、数据质量 | `references/file-mapping-and-data-quality.md` |
| 路由与组合业务 | `references/business-routing.md` |
| 能源/点工/运营业务 | 对应 `references/domain-profile-*.md` |
| 公共工程模式、骨架边界 | `references/proven-system-patterns.md`、`references/scaffold-contract.md` |
| 关联、审批、覆盖门禁和复杂案例 | `references/complex-business-contract.md` |
| 登录、工作台视觉与美观验收 | `references/ui-visual-contract.md` |
| 界面模块与组件 | `references/ui-functional-patterns.md` |
| 快速案例、证据标准 | `references/quickstart-and-evidence.md` |
| 输出与验收 | `references/runtime-output-contract.md`、`references/acceptance-checklist.md` |
