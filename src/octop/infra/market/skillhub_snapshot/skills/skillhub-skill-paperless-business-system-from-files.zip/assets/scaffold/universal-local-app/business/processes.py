"""经确认的跨表引用与串行/角色并行审批；不执行用户提供的代码。"""
from __future__ import annotations
import json
from flask import abort
from core.db import connect
from core.rbac import current_user, current_permissions

WORKFLOW_SQL='''
CREATE TABLE IF NOT EXISTS workflow_instances(
 id INTEGER PRIMARY KEY,object_key TEXT NOT NULL,record_id INTEGER NOT NULL,workflow_key TEXT NOT NULL,
 state TEXT NOT NULL,step INTEGER NOT NULL DEFAULT 0,cycle INTEGER NOT NULL DEFAULT 1,
 submitted_by INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,
 UNIQUE(object_key,record_id));
CREATE TABLE IF NOT EXISTS workflow_votes(
 instance_id INTEGER NOT NULL,cycle INTEGER NOT NULL,step INTEGER NOT NULL,role TEXT NOT NULL,
 user_id INTEGER NOT NULL,PRIMARY KEY(instance_id,cycle,step,role));
CREATE TABLE IF NOT EXISTS workflow_events(
 id INTEGER PRIMARY KEY,instance_id INTEGER NOT NULL,user_id INTEGER NOT NULL,
 action TEXT NOT NULL,comment TEXT NOT NULL DEFAULT '',step INTEGER NOT NULL,cycle INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS import_receipts(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL,object_key TEXT NOT NULL,row_count INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
'''


def workflow_for(schema,key):
    return next((w for w in schema.get('workflows_compiled',[]) if w['object']==key),None)


def assert_editable(conn,key,rid):
    row=conn.execute('SELECT state FROM workflow_instances WHERE object_key=? AND record_id=?',(key,rid)).fetchone()
    if row and row['state'] in {'pending','approved'}:abort(409)


def reference_errors(conn,schema,obj,values):
    errors=[]; objects={o['key']:o for o in schema.get('objects',[])}
    for rel in schema.get('relationships_compiled',[]):
        if rel['from_object']!=obj['key']:continue
        value=values.get(rel['from_field'])
        if value in (None,''):continue
        parent=objects[rel['to_object']]
        found=conn.execute(f"SELECT 1 FROM {parent['table']} WHERE {rel['to_field']}=? LIMIT 1",(value,)).fetchone()
        if not found:
            label=next(f['label'] for f in obj['fields'] if f['key']==rel['from_field'])
            errors.append(f'{label}：请先在“{parent["label"]}”中维护对应编号，再填写或导入。')
    return errors


def related_groups(conn,schema,obj,record):
    groups=[]; objects={o['key']:o for o in schema.get('objects',[])}
    for rel in schema.get('relationships_compiled',[]):
        if rel['to_object']==obj['key']:
            other=objects[rel['from_object']]; field=rel['from_field']; value=record[rel['to_field']]
        elif rel['from_object']==obj['key']:
            other=objects[rel['to_object']]; field=rel['to_field']; value=record[rel['from_field']]
        else:continue
        if f"biz.{other['key']}.view" not in current_permissions():continue
        if value in (None,''):continue
        total=conn.execute(f"SELECT COUNT(*) FROM {other['table']} WHERE {field}=?",(value,)).fetchone()[0]
        rows=conn.execute(f"SELECT * FROM {other['table']} WHERE {field}=? ORDER BY id LIMIT 100",(value,)).fetchall()
        groups.append({'label':rel['label'],'obj':other,'rows':rows,'total':total})
    return groups


def workflow_data(conn,wf,obj,rid):
    record=conn.execute(f"SELECT * FROM {obj['table']} WHERE id=?",(rid,)).fetchone()
    if not record:abort(404)
    instance=conn.execute('SELECT * FROM workflow_instances WHERE object_key=? AND record_id=?',(obj['key'],rid)).fetchone()
    events=conn.execute('SELECT e.*,u.username FROM workflow_events e LEFT JOIN users u ON u.id=e.user_id WHERE instance_id=? ORDER BY e.id',(instance['id'],)).fetchall() if instance else []
    return record,instance,events


def act(conn,wf,obj,rid,action,version,comment):
    user=current_user(); uid=user['id']; perms=current_permissions(); role=user['role_name']
    conn.execute('BEGIN IMMEDIATE')
    record,inst,_=workflow_data(conn,wf,obj,rid)
    latest=inst['version'] if inst else 0
    if version!=latest:abort(409)
    comment=comment.strip()
    if len(comment)>2000:raise ValueError('处理说明请控制在 2,000 字以内。')
    if action=='submit':
        if f"biz.{obj['key']}.submit" not in perms:abort(403)
        if record['created_by']!=uid and role!='管理员':abort(403)
        if inst and inst['state'] not in {'rejected','withdrawn'}:abort(409)
        if inst:
            conn.execute("UPDATE workflow_instances SET state='pending',step=0,cycle=cycle+1,version=version+1,submitted_by=? WHERE id=?",(uid,inst['id']))
        else:
            conn.execute("INSERT INTO workflow_instances(object_key,record_id,workflow_key,state,submitted_by) VALUES(?,?,?,'pending',?)",(obj['key'],rid,wf['key'],uid))
    elif action=='withdraw':
        if not inst or inst['state']!='pending':abort(409)
        if inst['submitted_by']!=uid or f"biz.{obj['key']}.submit" not in perms:abort(403)
        if not comment:raise ValueError('请填写撤回原因，方便后续追溯。')
        conn.execute("UPDATE workflow_instances SET state='withdrawn',version=version+1 WHERE id=?",(inst['id'],))
    elif action in {'approve','reject'}:
        if not inst or inst['state']!='pending':abort(409)
        if inst['workflow_key']!=wf['key']:abort(409)
        if f"biz.{obj['key']}.review" not in perms:abort(403)
        step=wf['steps'][inst['step']]
        if role not in step['roles']:abort(403)
        if step['distinct_from_submitter'] and uid==inst['submitted_by']:abort(403)
        if action=='reject':
            if not comment:raise ValueError('请填写驳回原因，让提交人知道如何修改。')
            conn.execute("UPDATE workflow_instances SET state='rejected',version=version+1 WHERE id=?",(inst['id'],))
        else:
            exists=conn.execute('SELECT 1 FROM workflow_votes WHERE instance_id=? AND cycle=? AND step=? AND role=?',(inst['id'],inst['cycle'],inst['step'],role)).fetchone()
            if exists:abort(409)
            conn.execute('INSERT INTO workflow_votes VALUES(?,?,?,?,?)',(inst['id'],inst['cycle'],inst['step'],role,uid))
            count=conn.execute('SELECT COUNT(*) FROM workflow_votes WHERE instance_id=? AND cycle=? AND step=?',(inst['id'],inst['cycle'],inst['step'])).fetchone()[0]
            finished=step['mode']=='any' or count==len(step['roles'])
            last=inst['step']==len(wf['steps'])-1
            state='approved' if finished and last else 'pending'
            next_step=inst['step']+1 if finished and not last else inst['step']
            conn.execute('UPDATE workflow_instances SET state=?,step=?,version=version+1 WHERE id=?',(state,next_step,inst['id']))
    else:raise ValueError('请选择提交、通过、驳回或撤回。')
    fresh=conn.execute('SELECT * FROM workflow_instances WHERE object_key=? AND record_id=?',(obj['key'],rid)).fetchone()
    conn.execute('INSERT INTO workflow_events(instance_id,user_id,action,comment,step,cycle) VALUES(?,?,?,?,?,?)',(fresh['id'],uid,action,comment,inst['step'] if inst else 0,fresh['cycle']))
    conn.execute('INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)',(uid,'审批:'+action,json.dumps({'object':obj['key'],'record':rid,'state':fresh['state'],'version':fresh['version']},ensure_ascii=False)))
