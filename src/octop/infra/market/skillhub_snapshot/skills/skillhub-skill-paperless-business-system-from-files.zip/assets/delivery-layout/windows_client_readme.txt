{{SYSTEM_NAME}} Windows填写客户端

1. 先由服务器电脑启动系统。
2. 第一次使用可双击“设置服务器地址_Windows.vbs”。
3. 双击“测试服务器连接_Windows.vbs”确认连接。
4. 双击“{{SAFE_SYSTEM_NAME}}_Windows.vbs”打开填写页面。
5. server_url.txt 默认由服务端写入局域网地址；使用“设置服务器地址”后会转为人工模式，后续启动不会覆盖。
