from __future__ import annotations
import sqlite3, datetime as dt, os, uuid
from pathlib import Path
from .config import DB_PATH, BACKUP_DIR


def create_backup(prefix='manual')->Path:
    BACKUP_DIR.mkdir(parents=True,exist_ok=True)
    target=BACKUP_DIR/f'{prefix}_{dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")}_{uuid.uuid4().hex[:6]}.db'
    pending=target.with_suffix('.partial')
    src=dst=None
    try:
        if not DB_PATH.is_file():raise FileNotFoundError('数据库尚未创建。')
        src=sqlite3.connect(DB_PATH.as_uri()+'?mode=ro',uri=True,timeout=8)
        dst=sqlite3.connect(str(pending),timeout=8)
        src.backup(dst)
        if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('备份完整性检查未通过。')
        dst.close(); dst=None
        os.replace(pending,target)
    finally:
        if dst:dst.close()
        if src:src.close()
        pending.unlink(missing_ok=True)
    return target


def integrity_ok(path:Path)->bool:
    if not path.is_file():return False
    try:
        c=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True,timeout=8)
        try:return c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        finally:c.close()
    except sqlite3.Error:return False
