"""本地管理员入口：账号、用户权限覆盖与只读审计。"""
from __future__ import annotations
from flask import Blueprint, abort, redirect, render_template, request, url_for
from .db import connect, query, one
from .rbac import permission_required, current_user
from .security import hash_password

bp=Blueprint('admin',__name__,url_prefix='/admin')


def audit_in(conn,action,detail):
    conn.execute('INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)',(current_user()['id'],action,detail))


@bp.route('/users',methods=['GET','POST'])
@permission_required('user_manage')
def users():
    error=None
    if request.method=='POST':
        username=request.form.get('username','').strip();password=request.form.get('password','')
        if not username or len(username)>100:error='账号名需为1–100个字符。'
        elif len(password)<8:error='请设置至少8位的初始密码。'
        else:
            try:role_id=int(request.form.get('role_id','0'))
            except ValueError:role_id=0
            if not one('SELECT 1 FROM roles WHERE id=?',(role_id,)):error='请选择已有角色。'
            else:
                with connect() as c:
                    uid=c.execute('INSERT INTO users(username,password_hash,role_id,must_change_password) VALUES(?,?,?,1)',(username,hash_password(password),role_id)).lastrowid
                    audit_in(c,'新建账号',f'user_id={uid}')
                return redirect(url_for('admin.users'))
    people=query('SELECT u.id,u.username,u.active,u.must_change_password,u.permissions_customized,r.name role_name FROM users u LEFT JOIN roles r ON r.id=u.role_id ORDER BY u.id')
    return render_template('admin_users.html',people=people,roles=query('SELECT id,name FROM roles ORDER BY id'),error=error)


@bp.post('/users/<int:uid>')
@permission_required('user_manage')
def update_user(uid):
    user=one('SELECT * FROM users WHERE id=?',(uid,))
    if not user:abort(404)
    try:role_id=int(request.form.get('role_id','0'))
    except ValueError:abort(400)
    if not one('SELECT 1 FROM roles WHERE id=?',(role_id,)):abort(400)
    active=1 if request.form.get('active')=='1' else 0
    password=request.form.get('password','')
    if password and len(password)<8:abort(400)
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        current=c.execute('SELECT u.*,r.name role_name FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?',(uid,)).fetchone()
        new_role=c.execute('SELECT name FROM roles WHERE id=?',(role_id,)).fetchone()[0]
        if current and current['role_name']=='管理员' and (not active or new_role!='管理员'):
            count=c.execute("SELECT COUNT(*) FROM users u JOIN roles r ON r.id=u.role_id WHERE r.name='管理员' AND u.active=1 AND u.id<>?",(uid,)).fetchone()[0]
            if count==0:abort(409,'PB1213')
        if uid==current_user()['id'] and not active:abort(409,'PB1213')
        c.execute('UPDATE users SET role_id=?,active=? WHERE id=?',(role_id,active,uid))
        if password:c.execute('UPDATE users SET password_hash=?,must_change_password=1 WHERE id=?',(hash_password(password),uid))
        audit_in(c,'修改账号',f'user_id={uid};role_id={role_id};active={active};password_reset={bool(password)}')
    return redirect(url_for('admin.users'))


@bp.route('/users/<int:uid>/permissions',methods=['GET','POST'])
@permission_required('permission_manage')
def user_permissions(uid):
    user=one('SELECT id,username,role_id,permissions_customized FROM users WHERE id=?',(uid,))
    if not user:abort(404)
    if request.method=='POST':
        # 防止误把当前管理账号锁在系统外，自己的覆盖权限在另一管理账号中修改。
        if uid==current_user()['id']:abort(409,'PB1213')
        codes=set(request.form.getlist('codes'));known={r['code'] for r in query('SELECT code FROM permissions')}
        if not codes<=known:abort(400)
        custom=request.form.get('mode')=='custom'
        with connect() as c:
            c.execute('UPDATE users SET permissions_customized=? WHERE id=?',(int(custom),uid))
            c.execute('DELETE FROM user_permissions WHERE user_id=?',(uid,))
            if custom:c.executemany('INSERT INTO user_permissions(user_id,permission_code) VALUES(?,?)',[(uid,code) for code in sorted(codes)])
            audit_in(c,'修改用户权限',f'user_id={uid};custom={custom};permission_count={len(codes) if custom else 0}')
        return redirect(url_for('admin.user_permissions',uid=uid))
    checked={r['permission_code'] for r in query('SELECT permission_code FROM user_permissions WHERE user_id=?',(uid,))} if user['permissions_customized'] else {r['permission_code'] for r in query('SELECT permission_code FROM role_permissions WHERE role_id=?',(user['role_id'],))}
    return render_template('admin_permissions.html',account=user,permissions=query('SELECT code,name FROM permissions ORDER BY code'),checked=checked,is_self=uid==current_user()['id'])


@bp.get('/audit')
@permission_required('audit_view')
def audit_log():
    rows=query('SELECT a.id,a.action,a.detail,a.created_at,u.username FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200')
    return render_template('admin_audit.html',rows=rows)
