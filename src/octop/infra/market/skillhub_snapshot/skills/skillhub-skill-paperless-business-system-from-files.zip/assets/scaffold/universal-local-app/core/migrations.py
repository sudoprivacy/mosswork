from __future__ import annotations
from .db import connect
from business.processes import WORKFLOW_SQL
from .backup import create_backup
from .config import DB_PATH
import sqlite3

MIGRATIONS=[
('0001_core', r"""
CREATE TABLE IF NOT EXISTS schema_migrations(id TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS roles(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,description TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS permissions(code TEXT PRIMARY KEY,name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS role_permissions(role_id INTEGER NOT NULL,permission_code TEXT NOT NULL,PRIMARY KEY(role_id,permission_code),FOREIGN KEY(role_id) REFERENCES roles(id) ON DELETE CASCADE,FOREIGN KEY(permission_code) REFERENCES permissions(code) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role_id INTEGER,active INTEGER NOT NULL DEFAULT 1,must_change_password INTEGER NOT NULL DEFAULT 1,permissions_customized INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(role_id) REFERENCES roles(id));
CREATE TABLE IF NOT EXISTS user_permissions(user_id INTEGER NOT NULL,permission_code TEXT NOT NULL,PRIMARY KEY(user_id,permission_code),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(permission_code) REFERENCES permissions(code) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,action TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS system_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
""")]

try:
    from business.generated_migrations import MIGRATIONS as BUSINESS_MIGRATIONS, ensure_business_schema
except ModuleNotFoundError as exc:
    if exc.name!='business.generated_migrations':raise
    BUSINESS_MIGRATIONS=[]
    def ensure_business_schema(conn): return None
MIGRATIONS.extend(BUSINESS_MIGRATIONS)
MIGRATIONS.append(('1200_workflows_and_import_receipts',WORKFLOW_SQL))

def execute_statements(conn,sql):
    statement=''
    for line in sql.splitlines(keepends=True):
        # sqlite3.complete_statement 正确处理触发器内部的分号。
        for char in line:
            statement+=char
            if char==';' and sqlite3.complete_statement(statement):
                conn.execute(statement); statement=''
    if statement.strip():conn.execute(statement)


def migrate():
    existed=DB_PATH.is_file() and DB_PATH.stat().st_size>0
    if existed:
        with connect() as c:
            has_table=c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'").fetchone()
            applied={r[0] for r in c.execute('SELECT id FROM schema_migrations')} if has_table else set()
        if any(mid not in applied for mid,_ in MIGRATIONS):create_backup('before_migration')
    with connect() as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute('CREATE TABLE IF NOT EXISTS schema_migrations(id TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
        for mid,sql in MIGRATIONS:
            if c.execute('SELECT 1 FROM schema_migrations WHERE id=?',(mid,)).fetchone():continue
            execute_statements(c,sql)
            c.execute('INSERT INTO schema_migrations(id) VALUES(?)',(mid,))
        ensure_business_schema(c)
