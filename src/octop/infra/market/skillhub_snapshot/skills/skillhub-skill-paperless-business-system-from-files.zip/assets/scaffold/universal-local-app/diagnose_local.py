from __future__ import annotations
import argparse, importlib.util, json, platform, sqlite3
from core.config import DATA_DIR, DB_PATH, ROOT
from core.lifecycle import load_state
from core.backup import integrity_ok


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--technical',action='store_true');args=parser.parse_args()
    checks=[]
    for mod,name in [('flask','网页运行组件'),('waitress','本地服务组件'),('openpyxl','Excel处理组件')]:
        ok=importlib.util.find_spec(mod) is not None
        checks.append((name,ok,'已就绪' if ok else '请让维护人员安装交付包requirements.txt中的依赖。'))
    try:
        import tempfile
        with tempfile.NamedTemporaryFile(dir=DATA_DIR,prefix='diagnose-',delete=True):pass
        checks.append(('保存位置',True,'可以保存文件。'))
    except OSError:checks.append(('保存位置',False,'请检查磁盘空间及文件夹写入权限。'))
    if DB_PATH.exists():
        ok=integrity_ok(DB_PATH);checks.append(('数据文件',ok,'完整性检查通过。' if ok else '请保留当前数据库并联系维护人员检查有效备份，不要删除数据文件。'))
    else:checks.append(('数据文件',True,'首次成功启动后创建。'))
    ok=(ROOT/'templates/base.html').is_file() and (ROOT/'static/app.css').is_file()
    checks.append(('界面文件',ok,'文件完整。' if ok else '请重新解压完整系统包。'))
    report='\n'.join(f'[{"通过" if passed else "待处理"}] {name}：{action}' for name,passed,action in checks)
    if args.technical:report+='\nPython/OS：'+platform.python_version()+' / '+platform.platform()+'\n运行状态：'+json.dumps({k:load_state().get(k) for k in ('app_id','pid','port','url')},ensure_ascii=False)
    (DATA_DIR/'诊断报告.txt').write_text(report,encoding='utf-8');print(report)
    print('从哪里继续：先处理首个“待处理”项目，再重新启动；不需要重新生成业务系统。')
    return 0 if all(c[1] for c in checks) else 1
if __name__=='__main__':raise SystemExit(main())
