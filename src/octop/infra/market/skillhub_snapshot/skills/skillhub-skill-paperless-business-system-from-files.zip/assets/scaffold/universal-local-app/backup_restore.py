from __future__ import annotations
import argparse, os, sqlite3, tempfile
from pathlib import Path
from contextlib import closing
from core.backup import create_backup, integrity_ok
from core.config import DB_PATH
from core.lifecycle import load_state
from core.user_messages import classify, plain


def main():
    ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest='cmd',required=True)
    sp.add_parser('backup'); r=sp.add_parser('restore'); r.add_argument('file')
    a=ap.parse_args()
    try:
        if a.cmd=='backup':print(create_backup());return 0
        if load_state().get('pid'):
            print('恢复前请先使用本项目的“一键停止”，待服务退出后再恢复。');return 1
        src=Path(a.file).resolve()
        if not integrity_ok(src):print('备份文件无法通过完整性检查。请换用另一份有效备份；现有数据库没有被替换。');return 1
        rollback=create_backup('before_restore')
        fd,temp_name=tempfile.mkstemp(prefix='restore-',suffix='.db',dir=DB_PATH.parent);os.close(fd)
        pending=Path(temp_name)
        try:
            with closing(sqlite3.connect(src.as_uri()+'?mode=ro',uri=True)) as origin:
                with closing(sqlite3.connect(pending)) as dest:origin.backup(dest);dest.execute('PRAGMA journal_mode=DELETE')
            if not integrity_ok(pending):raise ValueError('恢复副本完整性检查未通过。')
            with closing(sqlite3.connect(DB_PATH,timeout=8)) as current:current.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            os.replace(pending,DB_PATH)
            # 服务停止后才清理旧辅助文件，避免旧WAL重放到恢复库。
            for suffix in ('-wal','-shm'):Path(str(DB_PATH)+suffix).unlink(missing_ok=True)
        finally:pending.unlink(missing_ok=True)
        print('恢复完成；恢复前的数据已备份：',rollback);return 0
    except Exception as exc:
        print(plain(classify(exc)));return 1
if __name__=='__main__':raise SystemExit(main())
