校验与哈希资料目录

正式交付前至少放入：TEST_REPORT.md、PY_SOURCE_MANIFEST.json、FILES_SHA256.txt、delivery-manifest.json，以及独立解压复验结果。
