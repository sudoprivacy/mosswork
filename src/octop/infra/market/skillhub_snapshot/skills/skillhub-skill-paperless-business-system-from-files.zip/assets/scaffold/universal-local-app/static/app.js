/* 通用交互：侧栏高亮、弹窗、轻提示、确认框。供所有视图使用。 */
(function () {
  window.toast = function (msg, ok) {
    var el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast'; el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = msg;
    el.style.background = ok === false ? '#B42318' : '#1f2328';
    el.classList.add('show');
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2200);
  };

  // 弹窗（iframe 加载目标页面）
  window.openModal = function (url, title) {
    var root = document.getElementById('modal-root');
    if (!root) { root = document.createElement('div'); root.id = 'modal-root'; document.body.appendChild(root); }
    root.innerHTML = '<div class="modal" id="app-modal" role="dialog" aria-modal="true"><div class="modal-panel"><div class="modal-head"><h2></h2><button class="icon-btn" type="button" aria-label="关闭">&times;</button></div><iframe id="modal-frame" style="width:100%;height:70vh;border:0;"></iframe></div></div>';
    root.querySelector('h2').textContent = title || '编辑';
    root.querySelector('button').onclick = window.closeModal;
    var target = new URL(url,location.href);
    if (target.origin !== location.origin) { window.closeModal(); return; }
    root.querySelector('iframe').src = target.href;
  };
  window.closeModal = function () {
    ['app-modal','confirm-modal'].forEach(function (id) { var m=document.getElementById(id); if(m)m.remove(); });
  };
  window.confirmAction = function (text, onOk) {
    var root=document.getElementById('modal-root');
    if(!root)return;
    root.innerHTML='<div class="modal" id="confirm-modal" role="dialog" aria-modal="true"><div class="modal-panel small"><div class="modal-head"><h2>确认操作</h2></div><p></p><div class="modal-actions"><button class="btn" id="confirm-cancel" type="button">取消</button><button class="btn danger" id="confirm-ok" type="button">确定</button></div></div></div>';
    root.querySelector('p').textContent=text;
    document.getElementById('confirm-cancel').onclick=window.closeModal;
    document.getElementById('confirm-ok').onclick=function(){window.closeModal();if(onOk)onOk();};
  };

  // 按最长匹配定位当前业务模块，避免同时高亮“全部模块”和当前模块。
  (function highlight() {
    var path=location.pathname,links=Array.from(document.querySelectorAll('.side-link'));
    var matched=links.filter(function(a){var href=a.getAttribute('href');return href && (href==='/'?path==='/':path===href || path.indexOf(href.replace(/\/$/,'')+'/')===0);});
    matched.sort(function(a,b){return b.getAttribute('href').length-a.getAttribute('href').length;});
    if(matched.length)matched[0].classList.add('active');
  })();
  if(window.self!==window.top)document.body.classList.add('embedded');
  document.querySelectorAll('[data-password-toggle]').forEach(function(button){
    button.addEventListener('click',function(){
      var input=document.getElementById(button.getAttribute('data-password-toggle'));if(!input)return;
      var show=input.type==='password';input.type=show?'text':'password';
      button.setAttribute('aria-pressed',show?'true':'false');button.setAttribute('aria-label',show?'隐藏密码':'显示密码');
    });
  });
  var login=document.getElementById('login-form');
  if(login)login.addEventListener('submit',function(){var submit=login.querySelector('button[type=submit]');if(submit){submit.disabled=true;submit.textContent='正在登录…';}});
  document.addEventListener('keydown',function(event){
    if(event.key!=='Escape')return;
    if(window.self!==window.top){try{window.parent.closeModal();}catch(e){}}else{window.closeModal();}
  });
  var allowed = ['classic-red','business-blue','readable-slate'];
  var picker = document.getElementById('theme-picker');
  var theme = document.body.getAttribute('data-theme') || 'classic-red';
  try { theme = localStorage.getItem('paperless:theme') || theme; } catch (e) {}
  if (allowed.indexOf(theme) === -1) theme = 'classic-red';
  document.body.setAttribute('data-theme',theme);
  if (picker) {
    picker.value = theme;
    picker.addEventListener('change',function () {
      if (allowed.indexOf(picker.value) === -1) return;
      document.body.setAttribute('data-theme',picker.value);
      try { localStorage.setItem('paperless:theme',picker.value); } catch (e) {}
    });
  }
})();
