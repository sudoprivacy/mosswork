from __future__ import annotations
import uuid
from flask import jsonify, render_template, request
from werkzeug.exceptions import HTTPException
from .user_messages import classify, message, CATALOG


def install_error_handlers(app):
    @app.errorhandler(Exception)
    def handle_error(exc):
        ref=uuid.uuid4().hex[:10]
        if isinstance(exc, HTTPException):
            status=exc.code or 500
            code={400:'PB1208',401:'PB1208',403:'PB1207',404:'PB1210',413:'PB1209',409:'PB1211'}.get(status,'PB999')
            if exc.description in CATALOG:code=exc.description
        else:
            code=classify(exc)
            status=409 if code in {'PB1201','PB1212'} else 503 if code=='PB1202' else 500
            # 日志只保存异常类别和请求路径，不记录密码、表单、SQL和异常原文。
            app.logger.error('request=%s error=%s kind=%s path=%s',ref,code,type(exc).__name__,request.path)
        data=message(code,reference=ref)
        if request.headers.get('X-Requested-With')=='XMLHttpRequest' or request.accept_mimetypes.best=='application/json':
            return jsonify(ok=False,errors=[data['title'],data['action']],error=data),status
        return render_template('error.html',problem=data),status
