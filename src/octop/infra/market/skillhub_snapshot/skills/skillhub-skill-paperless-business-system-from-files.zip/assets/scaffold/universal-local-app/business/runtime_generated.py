from __future__ import annotations

import ast
import hashlib
import math
import time
import sqlite3
import itertools
import csv
import io
import json
import re
import secrets
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable
from flask import Blueprint, abort, jsonify, redirect, render_template, request, send_file, url_for

from core.audit import audit
from core.config import DATA_DIR
from core.user_messages import classify, plain
from business.processes import workflow_for, reference_errors, related_groups, assert_editable, workflow_data, act
from core.db import connect, one, query
from core.excel_io import require_openpyxl
from core.rbac import current_permissions, current_user, login_required

ROOT=Path(__file__).resolve().parents[1]
SCHEMA_PATH=Path(__file__).with_name('generated_schema.json')
STAGING_DIR=DATA_DIR/'import_staging'
bp=Blueprint('business',__name__,url_prefix='/business')


def load_schema()->dict:
    if not SCHEMA_PATH.is_file(): return {'objects':[]}
    return json.loads(SCHEMA_PATH.read_text(encoding='utf-8'))


def get_object(key:str)->dict:
    for o in load_schema().get('objects',[]):
        if o.get('key')==key:return o
    abort(404)


def permission(code:str):
    u=current_user()
    if not u:return False
    return code in current_permissions()


def require_permission(code:str):
    if not current_user(): abort(401)
    if code not in current_permissions(): abort(403)


def _role_name(role:dict)->str:
    return str(role.get('name') or role.get('label') or role.get('key') or '').strip()


def _resolve_schema_object(schema:dict, ref:str):
    ref=str(ref or '').strip()
    for o in schema.get('objects',[]):
        if ref in {str(o.get('key') or ''),str(o.get('label') or '')}:return o
    return None


def ensure_business_permissions():
    schema=load_schema(); objects=schema.get('objects',[])
    if not objects:return
    with connect() as c:
        admin=c.execute("SELECT id FROM roles WHERE name='管理员'").fetchone()
        # 先创建每个业务对象的标准权限；管理员始终拥有全部。
        all_codes=[]
        for o in objects:
            for action,label in [('view','查看'),('create','新增'),('edit','修改'),('delete','删除'),('import','导入'),('export','导出'),('submit','提交审批'),('review','审核')]:
                code=f"biz.{o['key']}.{action}"; name=f"{label}{o.get('label',o['key'])}"; all_codes.append(code)
                c.execute('INSERT OR IGNORE INTO permissions(code,name) VALUES(?,?)',(code,name))
                if admin:c.execute('INSERT OR IGNORE INTO role_permissions(role_id,permission_code) VALUES(?,?)',(admin['id'],code))
        # 3.0：将 system-spec 中明确给出的角色/对象权限物化为 RBAC 种子。
        role_ids={}
        for role in schema.get('roles',[]):
            name=_role_name(role)
            if not name:continue
            c.execute('INSERT OR IGNORE INTO roles(name,description) VALUES(?,?)',(name,str(role.get('description') or '')))
            row=c.execute('SELECT id FROM roles WHERE name=?',(name,)).fetchone()
            if row:
                rid=row['id']; role_ids[name]=rid; role_ids[str(role.get('key') or '')]=rid
                for code in role.get('permissions') or role.get('permission_codes') or []:
                    code=str(code)
                    if code in all_codes:c.execute('INSERT OR IGNORE INTO role_permissions(role_id,permission_code) VALUES(?,?)',(rid,code))
        for rule in schema.get('permissions',[]):
            role_ref=str(rule.get('role') or rule.get('role_key') or rule.get('role_name') or '').strip()
            rid=role_ids.get(role_ref)
            if not rid:continue
            codes=[str(x) for x in (rule.get('permission_codes') or [])]
            obj=_resolve_schema_object(schema,rule.get('object') or rule.get('object_key'))
            actions=rule.get('actions') or ([rule.get('action')] if rule.get('action') else [])
            if obj:
                for action in actions:
                    code=f"biz.{obj['key']}.{action}"
                    if code in all_codes:codes.append(code)
            for code in dict.fromkeys(codes):
                if code not in all_codes:continue
                if rule.get('allow',True):c.execute('INSERT OR IGNORE INTO role_permissions(role_id,permission_code) VALUES(?,?)',(rid,code))
                else:c.execute('DELETE FROM role_permissions WHERE role_id=? AND permission_code=?',(rid,code))
        for workflow in schema.get('workflows_compiled',[]):
            for step in workflow['steps']:
                for name in step['roles']:
                    role=c.execute('SELECT id FROM roles WHERE name=?',(name,)).fetchone()
                    if not role:continue
                    for action in ('view','review'):
                        c.execute('INSERT OR IGNORE INTO role_permissions(role_id,permission_code) VALUES(?,?)',(role['id'],f"biz.{workflow['object']}.{action}"))


class SafeCalc:
    FUNCS={'sum':lambda *x:sum(x),'round':round,'min':min,'max':max,'abs':abs}
    def __init__(self,values:dict[str,Any]):self.values=values
    def eval(self,expr:str):
        if len(expr)>2000:raise ValueError('计算公式过长，请让维护人员检查。')
        tree=ast.parse(expr,mode='eval')
        if sum(1 for _ in ast.walk(tree))>200:raise ValueError('计算公式过于复杂，请分步计算。')
        result=self.visit(tree.body)
        if not isinstance(result,(int,float)) or not math.isfinite(result):raise ValueError('计算结果超出有效范围。')
        return result
    def visit(self,n):
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return n.value
        if isinstance(n,ast.Name):return self._num(self.values.get(n.id))
        if isinstance(n,ast.BinOp):
            a,b=self.visit(n.left),self.visit(n.right)
            if isinstance(n.op,(ast.Div,ast.Mod)) and b==0:raise ValueError('除数不能为0，请核对输入数值。')
            if isinstance(n.op,ast.Pow) and (abs(b)>12 or abs(a)>1e12):raise ValueError('幂运算超出有效范围，请核对公式。')
            ops={ast.Add:lambda:a+b,ast.Sub:lambda:a-b,ast.Mult:lambda:a*b,ast.Div:lambda:a/b if b!=0 else None,ast.Pow:lambda:a**b,ast.Mod:lambda:a%b if b!=0 else None}
            fn=ops.get(type(n.op))
            if not fn:raise ValueError('公式包含暂不支持的运算，请联系维护人员。')
            return fn()
        if isinstance(n,ast.UnaryOp):
            v=self.visit(n.operand)
            if isinstance(n.op,ast.USub):return -v
            if isinstance(n.op,ast.UAdd):return v
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in self.FUNCS:
            return self.FUNCS[n.func.id](*[self.visit(x) for x in n.args])
        raise ValueError('公式格式无法识别，请联系维护人员。')
    @staticmethod
    def _num(v):
        if v in (None,''):return 0
        try:return int(v) if re.fullmatch(r'[-+]?\d+',str(v).strip()) else float(v)
        except Exception:raise ValueError('参与计算的字段必须填写数字。')


def apply_calculations(obj:dict,payload:dict)->tuple[dict,list[str]]:
    out=dict(payload); errors=[]
    for r in obj.get('calculations',[]):
        expr=r.get('expression')
        if not expr:continue
        try:
            val=SafeCalc(out).eval(expr)
            out[r['target_field']]='' if val is None else val
        except Exception as e:
            label=next((f['label'] for f in obj['fields'] if f['key']==r.get('target_field')),'自动计算字段')
            detail=str(e) if isinstance(e,ValueError) else '请核对参与计算的数字，或联系维护人员检查公式。'
            errors.append(f'{label}：{detail}')
    return out,errors


def _parse_date(s:str)->str:
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%Y.%m.%d'):
        try:return datetime.strptime(s,fmt).date().isoformat()
        except ValueError:pass
    try:return date.fromisoformat(s).isoformat()
    except Exception:raise ValueError('必须为有效日期，例如 2026-08-18')


def _parse_datetime(s:str)->str:
    text=s.replace('T',' ')
    for fmt in ('%Y-%m-%d %H:%M','%Y-%m-%d %H:%M:%S','%Y/%m/%d %H:%M'):
        try:return datetime.strptime(text,fmt).isoformat(sep=' ',timespec='seconds')
        except ValueError:pass
    try:return datetime.fromisoformat(text).isoformat(sep=' ',timespec='seconds')
    except Exception:raise ValueError('必须为有效日期时间，例如 2026-08-18 09:30')


def _enum_key(field:dict,value:Any):
    """按字段类型归一化枚举值，避免 0/0.0 等合法等价值被误判。"""
    s=str(value).strip(); t=str(field.get('type','text')).lower()
    if t in {'integer','number'}:
        try:return ('number',Decimal(s).normalize())
        except InvalidOperation:return ('raw',s)
    if t=='boolean':
        low=s.lower()
        if low in {'1','true','是','yes','y','on'}:return ('boolean',1)
        if low in {'0','false','否','no','n','off'}:return ('boolean',0)
        return ('raw',s)
    if t=='date':
        try:return ('date',_parse_date(s))
        except ValueError:return ('raw',s)
    if t=='datetime':
        try:return ('datetime',_parse_datetime(s))
        except ValueError:return ('raw',s)
    return ('text',s)


def _enum_contains(field:dict,value:Any)->bool:
    key=_enum_key(field,value)
    return any(key==_enum_key(field,candidate) for candidate in (field.get('enum_candidates') or []))


def coerce(field:dict,value:Any):
    if value is None:return None
    s=str(value).strip()
    if s=='':return None
    t=str(field.get('type','text')).lower()
    if t=='date' and isinstance(value,(date,datetime)):s=value.date().isoformat() if isinstance(value,datetime) else value.isoformat()
    if t=='datetime' and isinstance(value,date) and not isinstance(value,datetime):s=value.isoformat()+' 00:00:00'
    enums=[str(x) for x in (field.get('enum_candidates') or [])]
    if enums and not _enum_contains(field,s):raise ValueError('必须选择允许的值：'+' / '.join(enums[:12]))
    if t=='integer':
        if not re.fullmatch(r'[-+]?\d+',s):raise ValueError('必须为整数')
        if len(s.lstrip('+-'))>19:raise ValueError('数字过大，请控制在18位以内。')
        value=int(s)
        if not -(2**63)<=value<2**63:raise ValueError('数字过大，请控制在18位以内。')
        return value
    if t=='number':
        try:value=float(s)
        except ValueError:raise ValueError('必须为数字，例如 12.5')
        if not math.isfinite(value):raise ValueError('必须为有效数字，不能填写无穷大或空数值。')
        return value
    if t=='boolean':
        low=s.lower()
        if low in {'1','true','是','yes','y','on'}:return 1
        if low in {'0','false','否','no','n','off'}:return 0
        raise ValueError('必须为“是/否”或 true/false')
    if t=='date':return _parse_date(s)
    if t=='datetime':return _parse_datetime(s)
    if len(s)>20000:raise ValueError('内容过长，请控制在20,000字以内。')
    return s


def build_payload(obj:dict,getter:Callable[[dict],Any])->tuple[dict,list[str]]:
    values={}; errors=[]
    for f in obj.get('fields',[]):
        if f.get('computed'):continue
        raw=getter(f)
        try:values[f['key']]=coerce(f,raw)
        except ValueError as e:
            values[f['key']]=raw
            errors.append(f"{f['label']}：{e}")
    if errors:return values,errors
    values,calc_errors=apply_calculations(obj,values); errors.extend(calc_errors)
    errors.extend(validate_payload(obj,values))
    return values,errors


def validate_payload(obj:dict,payload:dict)->list[str]:
    errors=[]
    for f in obj.get('fields',[]):
        value=payload.get(f['key'])
        if f.get('required') and value in (None,''):errors.append(f"{f['label']} 不能为空")
        enums=[str(x) for x in (f.get('enum_candidates') or [])]
        if value not in (None,'') and enums and not _enum_contains(f,value):errors.append(f"{f['label']} 不在允许值范围")
    return errors


def row_to_dict(row,obj):
    return {'id':row['id'],**{f['key']:row[f['column']] for f in obj.get('fields',[])},'created_at':row['created_at'],'updated_at':row['updated_at']}


@bp.get('/')
@login_required
def index():
    objects=[]
    for o in load_schema().get('objects',[]):
        if permission(f"biz.{o['key']}.view"):objects.append(o)
    return render_template('business_index.html',objects=objects)


@bp.get('/<key>')
@login_required
def list_records(key):
    obj=get_object(key); require_permission(f'biz.{key}.view')
    q=request.args.get('q','').strip()[:500]
    try:page=max(1,min(100000,int(request.args.get('page','1') or 1)))
    except ValueError:page=1
    page_size=30
    fields=obj.get('fields',[]); where=''; params=[]
    if q and fields:
        clauses=[f"CAST({f['column']} AS TEXT) LIKE ?" for f in fields]; where=' WHERE '+' OR '.join(clauses); params=['%'+q+'%']*len(fields)
    total=one(f"SELECT COUNT(*) n FROM {obj['table']}"+where,tuple(params))['n']
    rows=query(f"SELECT * FROM {obj['table']}"+where+' ORDER BY id DESC LIMIT ? OFFSET ?',tuple(params+[page_size,(page-1)*page_size]))
    return render_template('business_list.html',obj=obj,rows=[row_to_dict(r,obj) for r in rows],q=q,page=page,total=total,page_size=page_size,can_create=permission(f'biz.{key}.create'),can_edit=permission(f'biz.{key}.edit'),can_delete=permission(f'biz.{key}.delete'),can_import=permission(f'biz.{key}.import'),can_export=permission(f'biz.{key}.export'),workflow=workflow_for(load_schema(),key),has_relations=any(key in (r['from_object'],r['to_object']) for r in load_schema().get('relationships_compiled',[])))


@bp.route('/<key>/new',methods=['GET','POST'])
@login_required
def new_record(key):
    obj=get_object(key); require_permission(f'biz.{key}.create'); errors=[]; values={}
    if request.method=='POST':
        values,errors=build_payload(obj,lambda f:request.form.get(f['key']))
        if not errors:
            fields=obj.get('fields',[]); cols=[f['column'] for f in fields]; vals=[values.get(f['key']) for f in fields]
            with connect() as c:
                c.execute('BEGIN IMMEDIATE')
                errors.extend(reference_errors(c,load_schema(),obj,values))
                if not errors:
                    c.execute(f"INSERT INTO {obj['table']} ({','.join(cols)},created_by,updated_by) VALUES ({','.join('?' for _ in cols)},?,?)",tuple(vals+[current_user()['id'],current_user()['id']]))
                    c.execute('INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)',(current_user()['id'],f'新增{obj["label"]}',json.dumps(values,ensure_ascii=False)[:3500]))
            if errors:
                if request.headers.get('X-Requested-With')=='XMLHttpRequest':return jsonify(ok=False,errors=errors),400
                return render_template('business_form.html',obj=obj,values=values,errors=errors,mode='new')
            if request.headers.get('X-Requested-With')=='XMLHttpRequest':return jsonify({'ok':True})
            return redirect(url_for('business.list_records',key=key))
        if request.headers.get('X-Requested-With')=='XMLHttpRequest':return jsonify({'ok':False,'errors':errors}),400
    return render_template('business_form.html',obj=obj,values=values,errors=errors,mode='new')


@bp.route('/<key>/<int:rid>/edit',methods=['GET','POST'])
@login_required
def edit_record(key,rid):
    obj=get_object(key); require_permission(f'biz.{key}.edit'); row=one(f"SELECT * FROM {obj['table']} WHERE id=?",(rid,))
    if not row:abort(404)
    values=row_to_dict(row,obj); errors=[]
    if request.method=='POST':
        values,errors=build_payload(obj,lambda f:request.form.get(f['key']))
        if not errors:
            fields=obj.get('fields',[]); sets=','.join(f"{f['column']}=?" for f in fields); vals=[values.get(f['key']) for f in fields]
            with connect() as c:
                c.execute('BEGIN IMMEDIATE'); assert_editable(c,key,rid)
                errors.extend(reference_errors(c,load_schema(),obj,values))
                if not errors:
                    c.execute(f"UPDATE {obj['table']} SET {sets},updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",tuple(vals+[current_user()['id'],rid]))
                    c.execute('INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)',(current_user()['id'],f'修改{obj["label"]}',f'id={rid}'))
            if errors:
                if request.headers.get('X-Requested-With')=='XMLHttpRequest':return jsonify(ok=False,errors=errors),400
                return render_template('business_form.html',obj=obj,values=values,errors=errors,mode='edit')
            if request.headers.get('X-Requested-With')=='XMLHttpRequest':return jsonify({'ok':True})
            return redirect(url_for('business.list_records',key=key))
        if request.headers.get('X-Requested-With')=='XMLHttpRequest':return jsonify({'ok':False,'errors':errors}),400
    return render_template('business_form.html',obj=obj,values=values,errors=errors,mode='edit')


@bp.post('/<key>/<int:rid>/delete')
@login_required
def delete_record(key,rid):
    obj=get_object(key); require_permission(f'biz.{key}.delete')
    with connect() as c:
        c.execute('BEGIN IMMEDIATE'); assert_editable(c,key,rid)
        c.execute(f"DELETE FROM {obj['table']} WHERE id=?",(rid,))
        c.execute('INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)',(current_user()['id'],f'删除{obj["label"]}',f'id={rid}'))
    return redirect(url_for('business.list_records',key=key))


def parse_upload(file_storage,obj):
    name=(file_storage.filename or '').lower(); raw=file_storage.read(12*1024*1024+1)
    if len(raw)>12*1024*1024:raise ValueError('文件超过12 MiB，请拆分后再预览。')
    labels=[f['label'] for f in obj.get('fields',[]) if not f.get('computed')]; rows=[]; invalid=[]; wb=None
    try:
        if name.endswith('.xlsx'):
            op=require_openpyxl(); wb=op.load_workbook(io.BytesIO(raw),read_only=True,data_only=False)
            data=list(itertools.islice(wb.active.iter_rows(values_only=True),20002))
        elif name.endswith('.csv'):
            try:text=raw.decode('utf-8-sig')
            except UnicodeDecodeError:text=raw.decode('gb18030')
            data=list(itertools.islice(csv.reader(io.StringIO(text)),20002))
        else:raise ValueError('请选择 XLSX 或 CSV 格式文件。')
    finally:
        if wb:wb.close()
    if not data:raise ValueError('文件里没有数据，请检查是否选错文件。')
    if len(data)>20001:raise ValueError('文件超过20,000行，请拆分后导入，避免遗漏。')
    headers=[str(x or '').strip() for x in data[0]]
    if len([h for h in headers if h])!=len(set(h for h in headers if h)):raise ValueError('第一行有重复字段名，请改为不同名称后重新预览。')
    index={h:i for i,h in enumerate(headers)}; missing=[x for x in labels if x not in index]
    if missing:raise ValueError('第一行缺少这些字段：'+'、'.join(missing[:10])+'。请按原表单补齐字段名。')
    seen={}; schema=load_schema()
    with connect() as c:
        for row_no,row in enumerate(data[1:],start=2):
            if not any(x not in (None,'') for x in row):continue
            values,errors=build_payload(obj,lambda f,row=row:row[index[f['label']]] if index[f['label']]<len(row) else None)
            if not errors:errors.extend(reference_errors(c,schema,obj,values))
            for keys in obj.get('confirmed_unique_keys',[]):
                key_values=tuple(values.get(k) for k in keys)
                if any(v is None for v in key_values):continue
                sig=(tuple(keys),key_values)
                if sig in seen:errors.append(f'与文件第{seen[sig]}行的唯一编号重复，请核对。')
                elif c.execute(f"SELECT 1 FROM {obj['table']} WHERE "+' AND '.join(k+'=?' for k in keys),key_values).fetchone():errors.append('唯一编号在系统中已经存在，请核对后再导入。')
                else:seen[sig]=row_no
            if errors:invalid.append({'row':row_no,'errors':errors,'values':values})
            else:rows.append({'row':row_no,'values':values})
    return rows,invalid


@bp.route('/<key>/import',methods=['GET','POST'])
@login_required
def import_records(key):
    obj=get_object(key); require_permission(f'biz.{key}.import'); error=None; preview=None; token=None; invalid_preview=None; summary=None
    STAGING_DIR.mkdir(parents=True,exist_ok=True)
    schema_hash=hashlib.sha256(SCHEMA_PATH.read_bytes()).hexdigest()
    if request.method=='POST' and request.form.get('action')=='preview':
        try:
            file=request.files.get('file')
            if not file:raise ValueError('请先选择要导入的文件。')
            valid,invalid=parse_upload(file,obj); token=secrets.token_urlsafe(24)
            stage={'uid':current_user()['id'],'object':key,'created_at':time.time(),'schema_hash':schema_hash,'valid_rows':valid,'invalid_rows':invalid}
            (STAGING_DIR/(token+'.json')).write_text(json.dumps(stage,ensure_ascii=False,default=str),encoding='utf-8')
            preview=[x['values'] for x in valid[:20]]; invalid_preview=invalid[:20]; summary={'valid':len(valid),'invalid':len(invalid),'total':len(valid)+len(invalid)}
        except UnicodeError:error=plain('PB1205')
        except ValueError as exc:error=str(exc)
        except Exception as exc:error=plain(classify(exc))
    elif request.method=='POST' and request.form.get('action')=='commit':
        token=request.form.get('token','')
        if not re.fullmatch(r'[A-Za-z0-9_-]{24,64}',token):abort(400)
        p=STAGING_DIR/(token+'.json')
        try:
            with connect() as c:
                c.execute('BEGIN IMMEDIATE')
                receipt=c.execute('SELECT * FROM import_receipts WHERE token=?',(token,)).fetchone()
                if receipt:
                    if receipt['user_id']!=current_user()['id'] or receipt['object_key']!=key:abort(403)
                    return redirect(url_for('business.list_records',key=key))
                stage=json.loads(p.read_text(encoding='utf-8'))
                if stage.get('uid')!=current_user()['id'] or stage.get('object')!=key:abort(403)
                if time.time()-stage.get('created_at',0)>7200 or stage.get('schema_hash')!=schema_hash:raise FileNotFoundError()
                invalid=stage.get('invalid_rows',[])
                if invalid:raise ValueError(f'仍有 {len(invalid)} 行填写错误，本次没有导入任何数据；请修正后重新预览。')
                rows=[x.get('values',{}) for x in stage.get('valid_rows',[])]; fields=obj.get('fields',[]); cols=[f['column'] for f in fields]
                if not rows:raise ValueError('没有可导入的数据，请检查文件后重新预览。')
                for values in rows:
                    errors=reference_errors(c,load_schema(),obj,values)
                    if errors:raise ValueError('关联主档已变化，本次没有导入任何数据。请重新预览。')
                    vals=[values.get(f['key']) for f in fields]
                    c.execute(f"INSERT INTO {obj['table']} ({','.join(cols)},created_by,updated_by) VALUES ({','.join('?' for _ in cols)},?,?)",tuple(vals+[current_user()['id'],current_user()['id']]))
                c.execute('INSERT INTO import_receipts(token,user_id,object_key,row_count) VALUES(?,?,?,?)',(token,current_user()['id'],key,len(rows)))
                c.execute('INSERT INTO audit_log(user_id,action,detail) VALUES(?,?,?)',(current_user()['id'],f'导入{obj["label"]}',f'{len(rows)} 条'))
            try:p.unlink(missing_ok=True)
            except OSError:pass
            return redirect(url_for('business.list_records',key=key))
        except UnicodeError:error=plain('PB1205')
        except ValueError as exc:error=str(exc)
        except (OSError,sqlite3.Error) as exc:error=plain(classify(exc))
    return render_template('business_import.html',obj=obj,error=error,preview=preview,invalid_preview=invalid_preview,summary=summary,token=token)


@bp.get('/<key>/<int:rid>/related')
@login_required
def related_records(key,rid):
    obj=get_object(key); require_permission(f'biz.{key}.view')
    with connect() as c:
        row=c.execute(f"SELECT * FROM {obj['table']} WHERE id=?",(rid,)).fetchone()
        if not row:abort(404)
        groups=related_groups(c,load_schema(),obj,row)
    return render_template('business_related.html',obj=obj,rid=rid,groups=groups)


@bp.route('/<key>/<int:rid>/workflow',methods=['GET','POST'])
@login_required
def workflow_record(key,rid):
    obj=get_object(key); require_permission(f'biz.{key}.view'); wf=workflow_for(load_schema(),key)
    if not wf:abort(404)
    error=None
    if request.method=='POST':
        try:
            version=int(request.form.get('version','-1'))
            with connect() as c:act(c,wf,obj,rid,request.form.get('action',''),version,request.form.get('comment',''))
            return redirect(url_for('business.workflow_record',key=key,rid=rid))
        except ValueError as exc:error=str(exc)
    with connect() as c:record,instance,events=workflow_data(c,wf,obj,rid)
    step=wf['steps'][instance['step']] if instance and instance['state']=='pending' else None
    user=current_user(); can_submit=permission(f'biz.{key}.submit') and (record['created_by']==user['id'] or user['role_name']=='管理员')
    can_review=bool(step and user['role_name'] in step['roles'] and permission(f'biz.{key}.review') and (not step['distinct_from_submitter'] or user['id']!=instance['submitted_by']))
    return render_template('business_workflow.html',obj=obj,rid=rid,wf=wf,instance=instance,events=events,step=step,error=error,can_submit=can_submit,can_review=can_review,can_withdraw=bool(instance and instance['submitted_by']==user['id'] and permission(f'biz.{key}.submit')))


@bp.get('/<key>/export.xlsx')
@login_required
def export_records(key):
    obj=get_object(key); require_permission(f'biz.{key}.export'); op=require_openpyxl(); wb=op.Workbook(); ws=wb.active; ws.title=obj.get('label','数据')[:31]
    fields=obj.get('fields',[]); ws.append([f['label'] for f in fields])
    for r in query(f"SELECT * FROM {obj['table']} ORDER BY id"):
        ws.append([r[f['column']] for f in fields])
        for cell in ws[ws.max_row]:
            if isinstance(cell.value,str) and cell.value.startswith(('=','+','-','@')):cell.data_type='s'
    # 保留字段顺序和原值，只统一Excel输出的视觉与阅读体验。
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
    import unicodedata
    accent={'classic-red':'D71920','business-blue':'2563A6','readable-slate':'475569'}.get((load_schema().get('ui') or {}).get('theme','classic-red'),'D71920')
    for cell in ws[1]:
        cell.fill=PatternFill('solid',fgColor=accent);cell.font=Font(name='微软雅黑',bold=True,color='FFFFFF',size=11)
        cell.alignment=Alignment(vertical='center',wrap_text=True)
    ws.row_dimensions[1].height=28
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font=Font(name='微软雅黑',size=10,color='344054')
            cell.alignment=Alignment(vertical='center')
            cell.fill=PatternFill('solid',fgColor='F7F9FC' if cell.row%2==0 else 'FFFFFF')
            cell.border=Border(bottom=Side(style='hair',color='E7EBF1'))
        ws.row_dimensions[row[0].row].height=23
    for index,field in enumerate(fields,1):
        samples=[str(ws.cell(row,index).value or '')[:80] for row in range(1,min(ws.max_row,80)+1)]
        width=max(sum(2 if unicodedata.east_asian_width(ch) in 'WF' else 1 for ch in value) for value in samples)
        ws.column_dimensions[get_column_letter(index)].width=max(14,min(38,width+4))
    ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions;ws.sheet_view.zoomScale=95
    ws.print_title_rows='1:1';ws.page_setup.orientation='landscape';ws.page_setup.fitToWidth=1
    bio=io.BytesIO(); wb.save(bio); bio.seek(0); audit(current_user()['id'],f'导出{obj["label"]}')
    return send_file(bio,as_attachment=True,download_name=f"{obj['label']}.xlsx",mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
