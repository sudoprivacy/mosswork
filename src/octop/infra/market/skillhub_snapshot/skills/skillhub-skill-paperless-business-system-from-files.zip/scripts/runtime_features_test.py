#!/usr/bin/env python3
"""仅在E2E创建的隔离项目中，按本次规格运行所有正式关联和审批链。"""
from __future__ import annotations
import io, json, os, sqlite3, sys, uuid
from pathlib import Path


def main():
    service=Path(sys.argv[1]).resolve()
    if not (service/'.paperless-test-isolated').is_file() or Path(os.environ.get('DATA_DIR','')).resolve()!=service/'data':
        print('拒绝执行：扩展测试只允许在E2E隔离副本中运行。');return 2
    sys.path.insert(0,str(service))
    import app
    from core.db import connect
    from core.security import hash_password
    from business.runtime_generated import load_schema
    schema=load_schema();relations=schema.get('relationships_compiled',[]);workflows=schema.get('workflows_compiled',[])
    checks=[];fixtures={};objects={o['key']:o for o in schema['objects']}
    with connect() as c:admin=c.execute("SELECT id FROM users WHERE username='管理员'").fetchone()[0]
    def client(uid):
        out=app.app.test_client()
        with out.session_transaction() as session:session['uid']=uid;session['_csrf']='isolated-feature-test'
        return out
    admin_client=client(admin)
    def post(c,path,data):return c.post(path,data={'_csrf':'isolated-feature-test',**data},headers={'X-Requested-With':'XMLHttpRequest'})
    def request(c,path,data,status):
        r=post(c,path,data)
        if r.status_code!=status:raise RuntimeError(f'路径 {path} 预期{status}，实际{r.status_code}；'+r.get_data(as_text=True)[:400])
        return r
    pending=list(objects.values())
    while pending:
        progressed=False
        for obj in list(pending):
            refs=[r for r in relations if r['from_object']==obj['key']]
            if any(r['to_object'] not in fixtures for r in refs):continue
            seed=uuid.uuid4().hex[:10];values={}
            for f in obj['fields']:
                if f.get('computed'):continue
                enums=f.get('enum_candidates') or []
                if enums:val=str(enums[0])
                else:val={'integer':str(int(seed[:6],16)),'number':str(int(seed[:6],16)+.5),'boolean':'1','date':'2026-11-10','datetime':'2026-11-10T10:00'}.get(f['type'],'验证_'+seed)
                values[f['key']]=val
            for r in refs:values[r['from_field']]=fixtures[r['to_object']]['values'][r['to_field']]
            request(admin_client,f"/business/{obj['key']}/new",values,200)
            with connect() as c:record=dict(c.execute(f"SELECT * FROM {obj['table']} ORDER BY id DESC LIMIT 1").fetchone())
            fixtures[obj['key']]={'rid':record['id'],'values':{f['key']:record[f['column']] for f in obj['fields']},'input':values}
            pending.remove(obj);progressed=True
        if not progressed:raise RuntimeError('关联存在循环，需要专用测试数据；不能假定通用测试已通过。')
    for rel in relations:
        target=objects[rel['to_object']];source=objects[rel['from_object']];parent=fixtures[target['key']];child=fixtures[source['key']]
        request(admin_client,f"/business/{target['key']}/{parent['rid']}/delete",{},409)
        page=admin_client.get(f"/business/{source['key']}/{child['rid']}/related")
        if page.status_code!=200 or target['label'] not in page.get_data(as_text=True):raise RuntimeError('关联查询未显示主档。')
        checks.append(f"关联 {rel['label']}：按主档录入、关联查询、引用删除保护")
    users={}
    for wf in workflows:
        obj=objects[wf['object']];record=fixtures[obj['key']];path=f"/business/{obj['key']}/{record['rid']}/workflow"
        def state():
            with connect() as c:return dict(c.execute('SELECT * FROM workflow_instances WHERE object_key=? AND record_id=?',(obj['key'],record['rid'])).fetchone())
        request(admin_client,path,{'action':'submit','version':'0'},302)
        request(admin_client,f"/business/{obj['key']}/{record['rid']}/edit",record['input'],409)
        # 无当前对象权限的用户无法查看或审核。
        unknown='隔离无权限'+uuid.uuid4().hex[:5]
        with connect() as c:
            role=c.execute('INSERT INTO roles(name) VALUES(?)',(unknown,)).lastrowid
            uid=c.execute('INSERT INTO users(username,password_hash,role_id) VALUES(?,?,?)',(unknown,hash_password(uuid.uuid4().hex),role)).lastrowid
        request(client(uid),path,{'action':'approve','version':str(state()['version'])},403)
        for index,step in enumerate(wf['steps']):
            for role_name in step['roles'][:1] if step['mode']=='any' else step['roles']:
                if role_name not in users:
                    name='隔离审核'+uuid.uuid4().hex[:8]
                    with connect() as c:
                        role_id=c.execute('SELECT id FROM roles WHERE name=?',(role_name,)).fetchone()[0]
                        uid=c.execute('INSERT INTO users(username,password_hash,role_id) VALUES(?,?,?)',(name,hash_password(uuid.uuid4().hex),role_id)).lastrowid
                    users[role_name]=client(uid)
                reviewer=users[role_name];v=str(state()['version'])
                if index==0 and role_name==step['roles'][0]:
                    # 驳回必须有原因，并验证重新提交会保留前轮记录。
                    response=post(reviewer,path,{'action':'reject','version':v})
                    if '驳回原因' not in response.get_data(as_text=True):raise RuntimeError('驳回原因门禁失效。')
                    request(reviewer,path,{'action':'reject','version':v,'comment':'隔离验证：补齐资料'},302)
                    if state()['state']!='rejected':raise RuntimeError('驳回状态未保存。')
                    request(admin_client,path,{'action':'submit','version':str(state()['version'])},302)
                    v=str(state()['version'])
                request(reviewer,path,{'action':'approve','version':v},302)
                request(reviewer,path,{'action':'approve','version':v},409)
        if state()['state']!='approved':raise RuntimeError('审批链未到达通过状态。')
        request(admin_client,f"/business/{obj['key']}/{record['rid']}/delete",{},409)
        checks.append(f"审批 {wf['label']}：全部级次、角色权限、会签/任一、驳回重提、重放保护和审核锁定")
    print(json.dumps({'passed':True,'checks':checks,'relationships':len(relations),'workflows':len(workflows)},ensure_ascii=False))
    return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({'passed':False,'error':str(exc)},ensure_ascii=False));raise SystemExit(1)
