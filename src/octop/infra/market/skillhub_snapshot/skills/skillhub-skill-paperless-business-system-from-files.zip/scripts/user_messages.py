"""命令入口和诊断共用运行时中文消息目录。"""
import importlib.util
from pathlib import Path
_path=Path(__file__).resolve().parents[1]/'assets/scaffold/universal-local-app/core/user_messages.py'
_spec=importlib.util.spec_from_file_location('paperless_messages',_path)
_mod=importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_mod)
message=_mod.message
plain=_mod.plain
classify=_mod.classify
