#!/usr/bin/env python3
"""静态验证完整本地部署系统契约；不执行用户项目代码。"""
from __future__ import annotations
import argparse,json,re,sys
from pathlib import Path
from project_layout import (
    DOCUMENTATION_DIR, FORM_TEMPLATE_DIR, GENERAL_SOURCE_DIR, MACOS_CLIENT_DIR,
    POINTWORK_SOURCE_DIR, SERVICE_DIR, WINDOWS_CLIENT_DIR, find_project_file,
)

ROOT_RUNTIME_FILES={'一键启动_Windows.bat','一键启动_Windows.vbs','一键停止_Windows.bat','一键停止_Windows.vbs','一键启动_macOS.command','一键停止_macOS.command'}

def exists_any(root,names): return any(p.is_file() and p.name in names for p in root.rglob('*'))
def read_any(root,names):
    for p in root.rglob('*'):
        if p.is_file() and p.name in names:
            try: return p,p.read_text(encoding='utf-8',errors='replace')
            except OSError: pass
    return None,''
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('--strict',action='store_true'); ap.add_argument('--json-report'); a=ap.parse_args(); root=Path(a.project); errors=[]; warnings=[]; notes=[]
    if not root.is_dir(): print('[PB001] 项目目录不存在'); return 1
    spec_path=find_project_file(root,'system-spec.json')
    try: spec=json.loads(spec_path.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'system-spec.json 无法读取：{e}'); spec={}
    domains=[str(x).lower() for x in ((spec.get('system') or {}).get('business_domains') or [])]
    source_dir=POINTWORK_SOURCE_DIR if 'pointwork' in domains else GENERAL_SOURCE_DIR
    required_dirs={SERVICE_DIR,WINDOWS_CLIENT_DIR,MACOS_CLIENT_DIR,source_dir,FORM_TEMPLATE_DIR,DOCUMENTATION_DIR}
    for name in sorted(required_dirs):
        if not (root/name).is_dir(): errors.append(f'缺少图1目录：{name}')
    for name in sorted(ROOT_RUNTIME_FILES):
        if not (root/name).is_file(): errors.append(f'缺少图1根目录入口：{name}')
    password_files=[p for p in root.iterdir() if p.is_file() and (p.name=='点工系统用户密码.rtf' or p.name.endswith('_用户密码.rtf'))]
    if 'pointwork' in domains and not (root/'点工系统用户密码.rtf').is_file(): errors.append('点工业务缺少 点工系统用户密码.rtf')
    elif not password_files: errors.append('根目录缺少用户密码说明RTF')
    if a.strict:
        allowed=required_dirs|ROOT_RUNTIME_FILES|{p.name for p in password_files}
        unexpected=sorted(p.name for p in root.iterdir() if not p.name.startswith('.') and p.name not in allowed)
        if unexpected: errors.append('图1根目录存在未归类项目：'+'、'.join(unexpected))
    py=[p for p in root.rglob('*.py') if '.venv' not in p.parts and 'vendor' not in p.parts]
    if not py: errors.append('缺少第一方 Python 源码')
    else: notes.append(f'第一方 Python 源码：{len(py)} 个')
    req={'主入口':['app.py','server.py','main.py'],'EXE入口':['exe_entry.py'],'EXE构建脚本':['build_exe_windows.py'],'备份恢复':['backup_restore.py'],'Windows启动':['start_windows.bat','start-windows.bat'],'Windows停止':['stop_windows.bat','stop-windows.bat'],'一键诊断':['诊断_一键诊断.bat','diagnose_windows.bat'],'目标电脑验收':['验收_目标电脑.bat','target_pc_acceptance.py'],'运行说明':['README_运行说明.md','使用说明.md'],'依赖清单':['requirements.txt']}
    for label,names in req.items():
        if not exists_any(root,names): (errors if a.strict or label not in {'一键诊断','目标电脑验收','依赖清单'} else warnings).append(f'缺少{label}：{names}')
    starts=[p for p in root.rglob('*') if p.is_file() and p.name in {'start_windows.bat','start-windows.bat'}]; stops=[p for p in root.rglob('*') if p.is_file() and p.name in {'stop_windows.bat','stop-windows.bat'}]
    if starts and stops and not any(s.parent==t.parent for s in starts for t in stops): errors.append('Windows 启动与停止脚本未成对放在同一目录')
    for p in stops:
        txt=p.read_text(encoding='utf-8',errors='replace').lower()
        bad=[r'taskkill\s+[^\r\n]*/im\s+python(?:w)?\.exe',r'killall\s+python',r'pkill\s+[^\r\n]*python']
        if any(re.search(x,txt) for x in bad): errors.append(f'{p.relative_to(root)} 使用全局结束 Python 进程的危险停止方式')
        if a.strict and not any(k in txt for k in ('pid','process_id','server.pid','app.pid')): warnings.append(f'{p.relative_to(root)} 未发现 PID/唯一实例标识字样，请人工确认只停止本项目')
    if not list(root.rglob('*.spec')): errors.append('缺少 PyInstaller .spec')
    for f in ['DELIVERY_STATUS.json','PY_SOURCE_MANIFEST.json','FILES_SHA256.txt','TEST_REPORT.md']:
        if not find_project_file(root,f).is_file(): errors.append(f'缺少 {f}')
    status=find_project_file(root,'DELIVERY_STATUS.json')
    if status.is_file():
        try:
            obj=json.loads(status.read_text(encoding='utf-8'))
            if obj.get('windows_exe_runtime_verified') is True and not obj.get('exe_binary_included'): errors.append('windows_exe_runtime_verified=true 但 exe_binary_included 不是 true')
            for k in ('exe_build_source_included','python_source_included'):
                if obj.get(k) is not True: errors.append(f'DELIVERY_STATUS 未确认 {k}')
            for k in ('diagnostic_bundle_included','target_pc_acceptance_included','target_pc_smoke_verified','input_files_silently_skipped','runtime_e2e_verified'):
                if k not in obj: (errors if a.strict else warnings).append(f'DELIVERY_STATUS 缺少 {k}')
            if obj.get('input_files_silently_skipped',0)!=0: errors.append('input_files_silently_skipped 必须为 0')
            if obj.get('target_pc_smoke_verified') is True and not obj.get('target_pc_test_environment'): errors.append('目标电脑标记已验证但未记录测试环境')
            if obj.get('continuous_change_candidate') is True:
                for f in ('CHANGE_REQUEST.json','CHANGE_PLAN.md','CHANGE_IMPACT.json','CHANGE_IMPACT_REPORT.md','CHANGE_HISTORY.json'):
                    if not find_project_file(root,f).is_file(): errors.append(f'3.0 变更候选缺少 {f}')
                if obj.get('change_source_project_immutable') is not True: errors.append('3.0 变更候选未声明源项目保持不可变')
            if a.strict:
                if not obj.get('tests_executed'): errors.append('严格验收要求 tests_executed 非空；请先执行 run_skill.py test')
                if obj.get('runtime_source_fingerprint'):
                    from runtime_fingerprint import fingerprint
                    if obj['runtime_source_fingerprint']!=fingerprint(root):errors.append('测试后源码或业务配置已变化，请重新运行测试')
                if obj.get('runtime_e2e_verified') is not True: errors.append('严格验收要求 runtime_e2e_verified=true；静态检查不能替代真实运行测试')
                if obj.get('runtime_e2e_verified') is True and not obj.get('runtime_e2e_test_environment'): errors.append('runtime_e2e_verified=true 但未记录运行测试环境')
                if obj.get('continuous_change_candidate') is True and obj.get('change_runtime_verified') is not True: errors.append('3.0 变更候选严格验收要求 change_runtime_verified=true；变更后必须重新运行 E2E')
        except Exception as e: errors.append(f'DELIVERY_STATUS.json 无法解析：{e}')
    service=root/SERVICE_DIR
    generated=service/'business/generated_schema.json';model={}
    if generated.is_file():
        try:
            model=json.loads(generated.read_text(encoding='utf-8'))
            if a.strict and (model.get('relationships_compiled') or model.get('workflows_compiled')):
                evidence=json.loads(status.read_text(encoding='utf-8')) if status.is_file() else {}
                if evidence.get('complex_features_runtime_verified') is not True:errors.append('正式关联/审批尚未完成本次规格的运行测试')
        except (OSError,ValueError):errors.append('业务模型或运行证据无法读取')
    coverage=find_project_file(root,'FEATURE_COVERAGE.json')
    if generated.is_file() and 'feature_coverage_gate' in model.get('generated_capabilities',[]):
        if not coverage.is_file():errors.append('缺少业务覆盖清单，不能确认需求是否完整实现')
        try:
            from generate_business_system import compile_schema
            expected=compile_schema(spec)
            if expected.get('feature_blockers'):
                (errors if a.strict else warnings).append('原始规格中仍有未实现业务需求，不能通过删除覆盖项规避验收')
            for key in ('relationships_compiled','workflows_compiled'):
                if model.get(key)!=expected.get(key):errors.append('业务配置与原始规格不一致：'+key)
        except (ValueError,TypeError,KeyError):errors.append('原始业务规格无法编译，请先修正规格')
    if coverage.is_file():
        try:
            covered=json.loads(coverage.read_text(encoding='utf-8'))
            for item in covered.get('blockers',[]):
                (errors if a.strict else warnings).append('业务尚未完整实现：'+item['label']+'；'+item['detail'])
        except (ValueError,OSError):errors.append('业务覆盖清单无法读取')
    test_report=find_project_file(root,'TEST_REPORT.md')
    if test_report.is_file():
        tt=test_report.read_text(encoding='utf-8',errors='replace').lower()
        if a.strict and ('状态：未执行' in tt or 'status: not run' in tt or 'not_tested' in tt): errors.append('TEST_REPORT 仍标记为未执行；严格验收不通过')
    readme_p,readme=read_any(root,['README_运行说明.md','使用说明.md'])
    if readme:
        for word in ('启动','停止','诊断','验收'):
            if word not in readme: (errors if a.strict else warnings).append(f'{readme_p.relative_to(root)} 未说明“{word}”')
    report={'schema_version':'1.0','project':str(root.resolve()),'strict':bool(a.strict),'passed':not errors,'notes':notes,'warnings':warnings,'errors':errors}
    if a.json_report:
        out=Path(a.json_report).expanduser(); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    for n in notes: print('[通过]',n)
    for w in warnings: print('[警告]',w)
    if errors:
        print(f'[PB401] 本地部署契约验收失败，共 {len(errors)} 项'); [print('-',e) for e in errors]; return 1
    print('[通过] 完整本地部署契约静态检查通过。' + (' 严格模式。' if a.strict else '')); return 0
if __name__=='__main__': sys.exit(main())
