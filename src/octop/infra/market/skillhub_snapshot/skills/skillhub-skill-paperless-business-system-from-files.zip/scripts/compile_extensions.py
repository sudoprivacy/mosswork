"""编译经确认的关联和审批；保留未覆盖项，避免把配置存在当作功能已实现。"""
from __future__ import annotations

THEMES={'classic-red','business-blue','readable-slate'}


def compile_extensions(spec, objects):
    issues=[]; relations=[]; workflows=[]; coverage=[]
    def issue(area,label,detail):
        issues.append({'area':area,'label':label,'detail':detail})
    def obj(ref):
        matches=[o for o in objects if str(ref) in {o['key'],o['label'],o.get('source_key')}]
        return matches[0] if len(matches)==1 else None
    def field(o,ref):
        if o is None:return None
        matches=[f for f in o['fields'] if str(ref) in {f['key'],f['label'],f.get('source_key')}]
        return matches[0] if len(matches)==1 else None
    def confirmed(item):
        return item.get('confirmed') is True or item.get('evidence_level') in {'formal','user_confirmed'}
    for i,r in enumerate(spec.get('relationships') or [],1):
        label=str(r.get('label') or r.get('key') or f'关联{i}')
        if not confirmed(r):
            coverage.append({'area':'relationship','label':label,'status':'candidate','detail':'仅候选；未建立约束，需确认后启用。'});continue
        source=obj(r.get('from_object')); target=obj(r.get('to_object'))
        sf=field(source,r.get('from_field')); tf=field(target,r.get('to_field'))
        if not all((source,target,sf,tf)):
            issue('relationship',label,'关联表或字段无法唯一匹配，请使用业务对象 key 和字段 key。');continue
        if sf['type']!=tf['type']:
            issue('relationship',label,'两端字段类型不同，请核对后再启用关联。');continue
        if [tf['key']] not in target.get('confirmed_unique_keys',[]):
            issue('relationship',label,'主表关联字段必须有已确认的单字段唯一键，避免一条明细对应多个主档。');continue
        if r.get('on_delete','restrict')!='restrict':
            issue('relationship',label,'当前只支持保留明细的 restrict 删除策略；级联删除须专门实现和测试。');continue
        relations.append({'key':f'rel_{i:03d}','label':label,'from_object':source['key'],'from_field':sf['key'],'to_object':target['key'],'to_field':tf['key'],'on_delete':'restrict'})
        coverage.append({'area':'relationship','label':label,'status':'generated','detail':'写入时校验主档存在，主档有明细时禁止改号/删除；关联查询遵守查看权限。'})
    roles={}
    for r in spec.get('roles') or []:
        name=str(r.get('name') or r.get('label') or r.get('key') or '').strip()
        for ref in [r.get('key'),r.get('name'),r.get('label')]:
            if ref:roles[str(ref)]=name
    roles['管理员']='管理员'
    used=set()
    for i,w in enumerate(spec.get('workflows') or [],1):
        label=str(w.get('label') or w.get('name') or w.get('key') or f'审批{i}')
        start=len(issues)
        if not confirmed(w):
            issue('workflow',label,'审批顺序、角色和通过方式需有正式或用户确认依据。');continue
        target=obj(w.get('object') or w.get('object_key'))
        if not target:
            issue('workflow',label,'未能找到审批对应的业务对象。');continue
        if target['key'] in used:
            issue('workflow',label,'同一业务对象当前只能启用一条审批链；条件分流需单独实现。');continue
        steps=[]
        for j,step in enumerate(w.get('steps') or [],1):
            names=[roles.get(str(x)) for x in (step.get('roles') or [])]
            mode=step.get('mode','any')
            if not names or any(not x for x in names) or mode not in {'any','all'}:
                issue('workflow',label,f'第{j}级需要已定义的审核角色和 any/all 通过方式。');continue
            if 'distinct_from_submitter' not in step or not isinstance(step['distinct_from_submitter'],bool):
                issue('workflow',label,f'第{j}级需明确能否由提交人审核。');continue
            if any(k in step for k in ('condition','script','assignees','min_approvals')):
                issue('workflow',label,'条件表达式、指定人员及任意人数阈值需要扩展实现，不能降级成角色审批。');continue
            steps.append({'key':f'step_{j:03d}','label':str(step.get('label') or f'第{j}级审核'),'roles':list(dict.fromkeys(names)),'mode':mode,'distinct_from_submitter':step['distinct_from_submitter']})
        if not steps:issue('workflow',label,'请至少定义一级审核。')
        if any(k in w for k in ('conditions','branch','script','auto_approve','field_level_permissions','signatures')):
            issue('workflow',label,'条件分支、自动通过、字段权限或手写签字需要专项实现和测试。')
        if len(issues)!=start:continue
        used.add(target['key'])
        workflows.append({'key':f'wf_{i:03d}','label':label,'object':target['key'],'steps':steps,'reject_requires_comment':True})
        coverage.append({'area':'workflow','label':label,'status':'generated','detail':'串行多级，每级可角色并行会签/任一通过；驳回必填原因、拒绝越权和重复提交、审核记录可追溯。'})
    for i,r in enumerate(spec.get('reports') or [],1):
        issue('report',str(r.get('label') or r.get('name') or f'报表{i}'),'自定义统计口径和跨表汇总需单独物化和验收；基础列表及Excel导出已保留。')
    wf_engine=spec.get('workflow_engine') or {}
    if wf_engine.get('field_level_permissions'):
        issue('permission','字段级权限','当前通用底座仅实现对象动作权限；字段权限必须补充服务端实现和越权测试。')
    for i,p in enumerate(spec.get('permissions') or [],1):
        if any(p.get(k) for k in ('data_scope','row_filter','field_permissions')):
            issue('permission',f'权限{i}','行级/字段级范围不能用对象权限替代，需专项实现。')
    for x in issues:coverage.append({**x,'status':'blocked'})
    theme=(spec.get('ui') or {}).get('theme','classic-red')
    if theme not in THEMES:raise ValueError('界面样式请选择 classic-red、business-blue 或 readable-slate。')
    return {'relationships_compiled':relations,'workflows_compiled':workflows,'ui':{'theme':theme,'available_themes':sorted(THEMES),'brand_label':str((spec.get('ui') or {}).get('brand_label') or '业务管理平台')[:24],'login_subtitle':str((spec.get('ui') or {}).get('login_subtitle') or '让日常业务，更清晰有序。')[:100]},'feature_coverage':coverage,'feature_blockers':issues}
