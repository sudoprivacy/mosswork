#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html
import json
import re
import shutil
import sys
from pathlib import Path

from project_layout import (
    DOCUMENTATION_DIR,
    FORM_TEMPLATE_DIR,
    GENERAL_SOURCE_DIR,
    GUIDE_DIR,
    MACOS_CLIENT_DIR,
    POINTWORK_SOURCE_DIR,
    SERVICE_DIR,
    WINDOWS_CLIENT_DIR,
    ensure_documentation_tree,
    project_output,
)


ROOT = Path(__file__).resolve().parents[1]
SCAFFOLD = ROOT / "assets" / "scaffold" / "universal-local-app"
DELIVERY_TEMPLATES = ROOT / "assets" / "delivery-layout"
TEMPLATE_DIR_NAME = "_platform_templates"
SKILL_VERSION = "3.1.0"
GENERATOR_SKILL = "纸质表单电子化系统生成器"
GENERATOR_SKILL_ID = "paperless-business-system-from-files"

REFERENCE_SUFFIXES = {
    ".xlsx", ".xlsm", ".xls", ".csv", ".tsv", ".docx", ".pdf",
    ".json", ".txt", ".md", ".png", ".jpg", ".jpeg", ".webp",
}
FORM_KEYWORDS = ("申请", "请假", "加班", "审批", "表单", "单据", "模板", "template")
TEXT_TEMPLATE_SUFFIXES = {
    ".py", ".html", ".css", ".js", ".json", ".md", ".txt", ".bat",
    ".vbs", ".command", ".spec", ".yaml", ".yml", ".toml", ".ini",
    ".cfg", ".ps1", ".sh", ".plist", ".xml",
}
DELIVERY_DOC_MAP = {
    "README_RUN.md": "README_运行说明.md",
    "README_EXE_BUILD.md": "README_EXE打包说明.md",
    "README_SCAFFOLD.md": "README_工程骨架说明.md",
}


def safe_filename(raw: str, fallback: str = "本地业务系统") -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(raw or "").strip())
    value = value.rstrip(" .")[:80]
    return value or fallback


def rtf_escape(text: str) -> str:
    out: list[str] = []
    for char in text:
        code = ord(char)
        if char in "\\{}":
            out.append("\\" + char)
        elif code < 128:
            out.append(char)
        else:
            signed = code if code <= 32767 else code - 65536
            out.append(f"\\u{signed}?")
    return "".join(out)


def replace_tokens(value: str, replacements: dict[str, str]) -> str:
    result = value
    for key, replacement in replacements.items():
        result = result.replace(key, replacement)
    return result


def materialize_template_map(template_dir: Path, target_root: Path, replacements: dict[str, str]) -> list[str]:
    mapping_path = template_dir / "template-map.json"
    if not mapping_path.is_file():
        raise RuntimeError(f"缺少模板映射：{mapping_path}")
    obj = json.loads(mapping_path.read_text(encoding="utf-8"))
    created: list[str] = []
    for item in obj.get("templates", []):
        source = str(item.get("source") or "").strip()
        output = replace_tokens(str(item.get("output") or "").strip(), replacements)
        if not source or not output:
            raise RuntimeError("模板映射存在空 source/output")
        src = (template_dir / source).resolve()
        dst = (target_root / output).resolve()
        if template_dir.resolve() not in src.parents:
            raise RuntimeError(f"非法模板路径：{source}")
        try:
            dst.relative_to(target_root.resolve())
        except ValueError as exc:
            raise RuntimeError(f"非法输出路径：{output}") from exc
        if not src.is_file():
            raise RuntimeError(f"模板文件不存在：{source}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(replace_tokens(src.read_text(encoding="utf-8"), replacements), encoding="utf-8", newline="\n")
        if item.get("executable") is True:
            dst.chmod(dst.stat().st_mode | 0o111)
        created.append(dst.relative_to(target_root).as_posix())
    return created


def materialize_service_templates(service_dir: Path, replacements: dict[str, str]) -> list[str]:
    template_dir = service_dir / TEMPLATE_DIR_NAME
    created = materialize_template_map(template_dir, service_dir, replacements)
    shutil.rmtree(template_dir)
    for source, target in DELIVERY_DOC_MAP.items():
        src = service_dir / source
        if src.is_file():
            src.rename(service_dir / target)
    return created


def replace_tree_tokens(root: Path, replacements: dict[str, str]) -> list[str]:
    changed: list[str] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_TEMPLATE_SUFFIXES:
            continue
        try:
            original = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        local_replacements=dict(replacements)
        if path.suffix.lower()=='.html':local_replacements['{{SYSTEM_NAME}}']=html.escape(replacements['{{SYSTEM_NAME}}'],quote=True)
        resolved = replace_tokens(original, local_replacements)
        if resolved != original:
            path.write_text(resolved, encoding="utf-8", newline="\n")
            changed.append(path.relative_to(root).as_posix())
    return changed


def unique_destination(folder: Path, filename: str) -> Path:
    candidate = folder / filename
    if not candidate.exists():
        return candidate
    for index in range(2, 1000):
        alternate = folder / f"{candidate.stem}({index}){candidate.suffix}"
        if not alternate.exists():
            return alternate
    raise RuntimeError(f"同名参考资料过多：{filename}")


def copy_reference_materials(paths: list[str], source_dir: Path, form_dir: Path) -> dict[str, list[str]]:
    copied = {"source_references": [], "form_templates": [], "skipped": []}
    for raw in paths:
        base = Path(raw).expanduser()
        candidates = [base] if base.is_file() else sorted(base.rglob("*")) if base.is_dir() else []
        if not candidates:
            copied["skipped"].append(str(base))
            continue
        for path in candidates:
            if not path.is_file() or path.is_symlink() or any(part.startswith(".") for part in path.parts):
                continue
            if path.suffix.lower() not in REFERENCE_SUFFIXES:
                copied["skipped"].append(str(path))
                continue
            is_form = any(key in path.name.lower() for key in FORM_KEYWORDS)
            destination_folder = form_dir if is_form else source_dir
            destination = unique_destination(destination_folder, safe_filename(path.name, "参考资料" + path.suffix))
            shutil.copy2(path, destination)
            copied["form_templates" if is_form else "source_references"].append(destination.name)
    return copied


def normalized_spec(spec: dict) -> dict:
    result = json.loads(json.dumps(spec, ensure_ascii=False))
    system = result.setdefault("system", {})
    system["deployment_mode"] = "portable_full"
    system["delivery_layout"] = "figure1-numbered-six-folders-v1"
    portable = result.setdefault("portable_full", {})
    portable.update({
        "enabled": True,
        "layout_standard": "figure1-numbered-six-folders-v1",
        "windows_client": True,
        "macos_client": True,
        "root_one_click_wrappers": True,
        "version_archive": True,
        "reference_materials_area": True,
        "electronic_templates_area": True,
    })
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=f"根据 system-spec.json 生成 {SKILL_VERSION} 图1式六目录系统骨架。")
    parser.add_argument("--spec", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--source-materials", action="append", default=[])
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    spec_path = Path(args.spec).expanduser()
    target = Path(args.output).expanduser()
    if not spec_path.is_file():
        print("[PB601] system-spec.json 不存在")
        return 1
    try:
        spec = normalized_spec(json.loads(spec_path.read_text(encoding="utf-8")))
    except Exception as exc:
        print(f"[PB602] system-spec.json 无法读取：{exc}")
        return 1
    system = spec.get("system") or {}
    name = str(system.get("name") or "本地业务系统").strip()
    safe_name = safe_filename(name)
    domains = [str(item).strip().lower() for item in (system.get("business_domains") or [])]
    is_pointwork = "pointwork" in domains
    source_dir_name = POINTWORK_SOURCE_DIR if is_pointwork else GENERAL_SOURCE_DIR
    password_name = "点工系统用户密码.rtf" if is_pointwork else f"{safe_name}_用户密码.rtf"
    if target.exists():
        if not args.force:
            print("[PB603] 输出目录已存在；如确认覆盖请加 --force")
            return 1
        shutil.rmtree(target)

    network = str(system.get("network_mode") or "offline_core")
    replacements = {
        "{{SYSTEM_NAME_PY}}": repr(name),
        "{{SAFE_SYSTEM_NAME_PY}}": repr(safe_name),
        "{{SYSTEM_NAME}}": name,
        "{{SAFE_SYSTEM_NAME}}": safe_name,
        "{{SYSTEM_NAME_XML}}": html.escape(name, quote=True),
        "{{SAFE_SYSTEM_NAME_RTF}}": rtf_escape(safe_name),
        "{{PASSWORD_NOTE_RTF}}": rtf_escape("首次启动时生成随机管理员密码。请查看01_服务端_完整程序/data/首次管理员凭据.txt；首次登录后立即修改密码。"),
        "{{SKILL_VERSION}}": SKILL_VERSION,
        "{{BUSINESS_DOMAINS}}": ",".join(domains),
        "{{SOURCE_REFERENCE_DIR}}": source_dir_name,
        "{{PASSWORD_FILE_NAME}}": password_name,
        "{{DEFAULT_BIND_HOST}}": "0.0.0.0" if network == "lan" else "127.0.0.1",
    }
    service = target / SERVICE_DIR
    source_dir = target / source_dir_name
    form_dir = target / FORM_TEMPLATE_DIR
    try:
        target.mkdir(parents=True)
        shutil.copytree(SCAFFOLD, service)
        service_files = materialize_service_templates(service, replacements)
        resolved_files = replace_tree_tokens(service, replacements)
        delivery_files = materialize_template_map(DELIVERY_TEMPLATES, target, replacements)
        ensure_documentation_tree(target)
        for folder in (target / WINDOWS_CLIENT_DIR, target / MACOS_CLIENT_DIR, source_dir, form_dir, service / "logs"):
            folder.mkdir(parents=True, exist_ok=True)
        (service / "logs" / "README.txt").write_text("运行日志目录；新建交付包不预置真实敏感日志。\n", encoding="utf-8")
        copied = copy_reference_materials(args.source_materials, source_dir, form_dir)
    except Exception as exc:
        shutil.rmtree(target, ignore_errors=True)
        print(f"[PB604] 图1式交付骨架生成失败：{exc}")
        return 1

    project_output(target, "system-spec.json").write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    for name_out in (
        "input-profile.json", "business-model.json", "BUSINESS_MODEL_REPORT.md", "business-profile.json",
        "BUSINESS_RECOGNITION_REPORT.md", "INPUT_COMPLETENESS_REPORT.md", "source-file-mapping.json",
        "data-quality-report.md", "BUSINESS_CONFLICTS.md", "ASSUMPTIONS.md",
    ):
        source = spec_path.parent / name_out
        if source.is_file():
            shutil.copy2(source, project_output(target, name_out))

    status_source = spec_path.parent / "DELIVERY_STATUS.json"
    if status_source.is_file():
        status = json.loads(status_source.read_text(encoding="utf-8"))
    else:
        status = json.loads((ROOT / "assets" / "templates" / "delivery-status.template.json").read_text(encoding="utf-8"))
    status.update({
        "business_domains": domains,
        "scaffold_used": True,
        "deployment_mode": "portable_full",
        "delivery_layout": "figure1-numbered-six-folders-v1",
        "figure1_layout_verified": False,
        "portable_full_requested": True,
        "portable_full_layout_included": True,
        "windows_client_included": True,
        "macos_client_included": True,
        "continuous_change_supported": True,
        "change_history_included": True,
        "change_source_project_immutable": True,
        "project_version": str(system.get("version") or "1.0.0"),
    })
    project_output(target, "DELIVERY_STATUS.json").write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    project_output(target, "TEST_REPORT.md").write_text("# TEST_REPORT\n\n状态：未执行。完成业务代码后必须执行真实运行E2E。\n", encoding="utf-8")
    project_output(target, "RUNTIME_ACCEPTANCE.md").write_text("# RUNTIME_ACCEPTANCE\n\n状态：未在目标电脑执行。\n", encoding="utf-8")
    project_output(target, "VALUE_REPORT.md").write_text("# VALUE_REPORT\n\n尚未录入真实业务前后耗时，不声明未经实测的效率提升。\n", encoding="utf-8")
    project_output(target, "CHANGE_HISTORY.json").write_text(json.dumps({"schema_version": "3.0", "project_version": str(system.get("version") or "1.0.0"), "entries": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    baseline = {
        "schema_version": "3.0.2",
        "generator_skill": GENERATOR_SKILL,
        "generator_skill_id": GENERATOR_SKILL_ID,
        "skill_version": SKILL_VERSION,
        "system_name": name,
        "business_domains": domains,
        "deployment_mode": "portable_full",
        "delivery_layout": "figure1-numbered-six-folders-v1",
        "figure1_layout_materialized": True,
        "service_directory": SERVICE_DIR,
        "windows_client_directory": WINDOWS_CLIENT_DIR,
        "macos_client_directory": MACOS_CLIENT_DIR,
        "source_reference_directory": source_dir_name,
        "form_template_directory": FORM_TEMPLATE_DIR,
        "documentation_directory": DOCUMENTATION_DIR,
        "continuous_change_supported": True,
        "materialized_service_runtime_files": service_files,
        "resolved_service_template_files": resolved_files,
        "materialized_delivery_runtime_files": delivery_files,
        "copied_reference_materials": copied,
    }
    project_output(target, "GENERATION_BASELINE.json").write_text(json.dumps(baseline, ensure_ascii=False, indent=2), encoding="utf-8")
    nav = target / DOCUMENTATION_DIR / GUIDE_DIR / "00_请先看_交付导航.md"
    nav.write_text(
        "# 交付导航\n\n"
        "1. 服务端位于 `01_服务端_完整程序/`。\n"
        "2. Windows与macOS填写客户端分别位于02、03目录。\n"
        "3. 当前规格、交付状态与变更历史位于 `06_说明与版本记录/00_当前版本/`。\n"
        "4. 测试、哈希和最终验收证据位于 `06_说明与版本记录/03_校验与哈希/`。\n"
        "5. 3.0持续变更采用CHANGE_REQUEST、影响分析、候选副本、重新E2E和严格验收。\n",
        encoding="utf-8",
    )
    print(f"[完成] 纸质表单电子化系统生成器 {SKILL_VERSION} 已生成图1式六目录工程骨架：{target.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
