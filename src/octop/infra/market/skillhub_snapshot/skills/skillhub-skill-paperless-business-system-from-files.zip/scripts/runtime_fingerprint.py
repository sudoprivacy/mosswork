"""把运行证据绑定到实际服务端源码和业务配置；忽略数据库、日志和缓存。"""
import hashlib
from pathlib import Path

SKIP={'data','logs','__pycache__','.git','.venv','.venv_windows','venv','vendor','node_modules','dist','build','portable_runtime'}
SUFFIXES={'.py','.html','.css','.js','.json','.txt','.spec','.bat','.command'}

def fingerprint(project:Path):
    root=project/'01_服务端_完整程序' if (project/'01_服务端_完整程序').is_dir() else project
    digest=hashlib.sha256()
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if not p.is_file() or set(rel.parts)&SKIP or p.suffix not in SUFFIXES:continue
        digest.update(rel.as_posix().encode());digest.update(b'\0');digest.update(p.read_bytes());digest.update(b'\0')
    return digest.hexdigest()
