#!/usr/bin/env python3
"""3.0 非破坏式逻辑回滚：用候选中的升级前规格生成一个回滚副本；不删除数据库新增列。"""
from __future__ import annotations
import argparse, json, shutil, subprocess, sys, tempfile
from datetime import datetime, timezone
from pathlib import Path
from project_layout import find_project_file, project_output

ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'

def main()->int:
    ap=argparse.ArgumentParser(description='根据 system-spec.before-upgrade.json 创建非破坏式回滚副本。')
    ap.add_argument('--project',required=True); ap.add_argument('--output',required=True); ap.add_argument('--force',action='store_true')
    a=ap.parse_args(); project=Path(a.project).expanduser().resolve(); out=Path(a.output).expanduser().resolve()
    before=find_project_file(project,'system-spec.before-upgrade.json')
    if not project.is_dir() or not before.is_file(): print('[PB1101] 项目缺少 system-spec.before-upgrade.json，无法自动回滚'); return 1
    if out.exists():
        if not a.force: print('[PB1102] 输出目录已存在；确认覆盖请加 --force'); return 1
        shutil.rmtree(out)
    cmd=[sys.executable,str(S/'upgrade_system.py'),'--project',str(project),'--spec',str(before),'--output',str(out),'--allow-breaking']
    rc=subprocess.run(cmd).returncode
    if rc:
        shutil.rmtree(out,ignore_errors=True); print('[PB1103] 回滚副本生成失败；原项目未修改'); return rc
    report=['# ROLLBACK_REPORT','',f'- 来源候选：`{project}`',f'- 生成时间（UTC）：{datetime.now(timezone.utc).isoformat()}','- 回滚方式：恢复升级前业务规格并重新生成运行代码。','- 数据策略：不执行 DROP COLUMN / 改类型等破坏性 SQL；升级期间新增的 SQLite 列可能保留，但旧规格/旧代码不会使用这些列。','- 验收：回滚副本必须重新执行 test + validate --strict。','']
    project_output(out,'ROLLBACK_REPORT.md').write_text('\n'.join(report),encoding='utf-8')
    st=find_project_file(out,'DELIVERY_STATUS.json')
    if st.is_file():
        obj=json.loads(st.read_text(encoding='utf-8')); obj.update({'rollback_candidate':True,'runtime_e2e_verified':False,'change_runtime_verified':False,'tests_executed':[]}); st.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'[完成] 已生成非破坏式回滚副本：{out}')
    print('[说明] 数据库新增列默认保留，以避免回滚过程再次破坏历史数据。')
    return 0
if __name__=='__main__': raise SystemExit(main())
