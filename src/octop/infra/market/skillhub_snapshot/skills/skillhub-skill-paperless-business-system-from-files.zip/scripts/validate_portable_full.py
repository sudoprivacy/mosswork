#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from project_layout import (
    CURRENT_DIR,
    DOCUMENTATION_DIR,
    FORM_TEMPLATE_DIR,
    GENERAL_SOURCE_DIR,
    HISTORY_DIR,
    MACOS_CLIENT_DIR,
    POINTWORK_SOURCE_DIR,
    SERVICE_DIR,
    UPDATE_DIR,
    VERIFY_DIR,
    WINDOWS_CLIENT_DIR,
    find_project_file,
)

ROOT_FILES = {
    "一键启动_Windows.bat", "一键启动_Windows.vbs",
    "一键停止_Windows.bat", "一键停止_Windows.vbs",
    "一键启动_macOS.command", "一键停止_macOS.command",
}


def any_name(root: Path, names: tuple[str, ...]) -> bool:
    return any(path.is_file() and path.name in names for path in root.rglob("*"))


def main() -> int:
    parser = argparse.ArgumentParser(description="验证图1式六目录完整部署包装。")
    parser.add_argument("project")
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    root = Path(args.project)
    errors: list[str] = []
    if not root.is_dir():
        print("[PB001] 项目目录不存在")
        return 1
    spec_path = find_project_file(root, "system-spec.json")
    status_path = find_project_file(root, "DELIVERY_STATUS.json")
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[PB451] system-spec.json 无法读取：{exc}")
        return 1
    domains = [str(item).lower() for item in ((spec.get("system") or {}).get("business_domains") or [])]
    source_dir = POINTWORK_SOURCE_DIR if "pointwork" in domains else GENERAL_SOURCE_DIR
    for directory in (SERVICE_DIR, WINDOWS_CLIENT_DIR, MACOS_CLIENT_DIR, source_dir, FORM_TEMPLATE_DIR, DOCUMENTATION_DIR):
        if not (root / directory).is_dir():
            errors.append(f"缺少图1目录：{directory}")
    for name in ROOT_FILES:
        if not (root / name).is_file():
            errors.append(f"根目录缺少：{name}")
    password = root / "点工系统用户密码.rtf" if "pointwork" in domains else None
    if password is not None and not password.is_file():
        errors.append("点工业务缺少：点工系统用户密码.rtf")
    if not any(path.is_file() and (path.name == "点工系统用户密码.rtf" or path.name.endswith("_用户密码.rtf")) for path in root.iterdir()):
        errors.append("根目录缺少用户密码说明RTF")

    service = root / SERVICE_DIR
    checks = {
        "服务端主入口": ("app.py", "server.py", "main.py"),
        "服务端启动": ("start_windows.bat",),
        "服务端停止": ("stop_windows.bat",),
        "运行说明": ("README_运行说明.md",),
        "备份恢复": ("backup_restore.py",),
        "EXE构建": ("build_exe_windows.py",),
        "诊断": ("diagnose_local.py",),
        "目标机验收": ("target_pc_acceptance.py",),
    }
    for label, names in checks.items():
        if not any_name(service, names):
            errors.append(f"缺少{label}：{names}")
    for directory in ("templates", "static", "data", "logs"):
        if not (service / directory).exists():
            errors.append(f"服务端缺少 {directory}/")

    windows = root / WINDOWS_CLIENT_DIR
    for name in ("server_url.txt", "Windows客户端使用说明.txt", "设置服务器地址_Windows.vbs", "测试服务器连接_Windows.vbs"):
        if not (windows / name).is_file():
            errors.append(f"Windows客户端缺少：{name}")
    launchers = [path for path in windows.glob("*_Windows.vbs") if path.name not in {"设置服务器地址_Windows.vbs", "测试服务器连接_Windows.vbs"}]
    if not launchers:
        errors.append("Windows客户端缺少系统打开入口")

    macos = root / MACOS_CLIENT_DIR
    for name in ("server_url.txt", "macOS客户端使用说明.txt"):
        if not (macos / name).is_file():
            errors.append(f"macOS客户端缺少：{name}")
    apps = [path for path in macos.glob("*.app") if path.is_dir()]
    if len(apps) < 3:
        errors.append("macOS客户端至少需要系统、设置地址、测试连接三个.app")
    for app in apps:
        if not (app / "Contents" / "Info.plist").is_file():
            errors.append(f"{app.name} 缺少Info.plist")
        macos_bin = app / "Contents" / "MacOS"
        if not macos_bin.is_dir() or not any(path.is_file() for path in macos_bin.iterdir()):
            errors.append(f"{app.name} 缺少MacOS入口")

    docs = root / DOCUMENTATION_DIR
    for section in (CURRENT_DIR, "01_使用与部署说明", UPDATE_DIR, VERIFY_DIR, HISTORY_DIR):
        if not (docs / section).is_dir():
            errors.append(f"06目录缺少：{section}")
    try:
        status = json.loads(status_path.read_text(encoding="utf-8"))
        for key in ("portable_full_requested", "portable_full_layout_included", "windows_client_included", "macos_client_included"):
            if status.get(key) is not True:
                errors.append(f"DELIVERY_STATUS未确认：{key}")
    except Exception as exc:
        errors.append(f"DELIVERY_STATUS无法读取：{exc}")
    if errors:
        print(f"[PB451] 图1六目录验收失败，共 {len(errors)} 项")
        for item in errors:
            print("-", item)
        return 1
    print("[通过] 图1式六目录完整部署包装检查通过。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
