#!/usr/bin/env python3
"""图1六目录项目中的统一文件定位规则。"""
from __future__ import annotations

import json
from pathlib import Path


SERVICE_DIR = "01_服务端_完整程序"
WINDOWS_CLIENT_DIR = "02_Windows填写客户端"
MACOS_CLIENT_DIR = "03_macOS填写客户端"
POINTWORK_SOURCE_DIR = "04_原始点工表参考"
GENERAL_SOURCE_DIR = "04_原始业务表参考"
FORM_TEMPLATE_DIR = "05_申请单电子档模板"
DOCUMENTATION_DIR = "06_说明与版本记录"

CURRENT_DIR = "00_当前版本"
GUIDE_DIR = "01_使用与部署说明"
UPDATE_DIR = "02_更新说明"
VERIFY_DIR = "03_校验与哈希"
HISTORY_DIR = "04_历史资料"

CURRENT_FILES = {
    "system-spec.json", "DELIVERY_STATUS.json", "GENERATION_BASELINE.json",
    "VALUE_REPORT.md", "CHANGE_HISTORY.json", "input-profile.json",
    "business-model.json", "BUSINESS_MODEL_REPORT.md", "business-profile.json",
    "BUSINESS_RECOGNITION_REPORT.md", "INPUT_COMPLETENESS_REPORT.md",
    "source-file-mapping.json", "data-quality-report.md",
    "BUSINESS_CONFLICTS.md", "ASSUMPTIONS.md",
}
VERIFY_FILES = {
    "TEST_REPORT.md", "RUNTIME_ACCEPTANCE.md", "PY_SOURCE_MANIFEST.json",
    "FILES_SHA256.txt", "delivery-manifest.json",
}
UPDATE_FILES = {
    "AUTO_GENERATION_REPORT.md", "UPGRADE_DIFF_REPORT.md", "upgrade-diff.json",
    "CHANGE_REQUEST.json", "CHANGE_PLAN.md", "CHANGE_IMPACT.json",
    "CHANGE_IMPACT_REPORT.md", "ROLLBACK_REPORT.md",
}
HISTORY_FILES = {"system-spec.before-upgrade.json"}


def is_figure1(root: Path) -> bool:
    return (root / SERVICE_DIR).is_dir() or (root / DOCUMENTATION_DIR).is_dir()


def docs_dir(root: Path, section: str) -> Path:
    path = root / DOCUMENTATION_DIR / section
    path.mkdir(parents=True, exist_ok=True)
    return path


def mapped_path(root: Path, name: str) -> Path:
    if name in VERIFY_FILES:
        return root / DOCUMENTATION_DIR / VERIFY_DIR / name
    if name in UPDATE_FILES:
        return root / DOCUMENTATION_DIR / UPDATE_DIR / name
    if name in HISTORY_FILES:
        return root / DOCUMENTATION_DIR / HISTORY_DIR / name
    return root / DOCUMENTATION_DIR / CURRENT_DIR / name


def find_project_file(root: Path, name: str) -> Path:
    root_path = root / name
    mapped = mapped_path(root, name)
    if root_path.is_file():
        return root_path
    if mapped.is_file():
        return mapped
    return mapped if is_figure1(root) else root_path


def project_output(root: Path, name: str) -> Path:
    path = mapped_path(root, name) if is_figure1(root) else root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_project_json(root: Path, name: str) -> dict:
    path = find_project_file(root, name)
    return json.loads(path.read_text(encoding="utf-8"))


def service_root(root: Path) -> Path:
    service = root / SERVICE_DIR
    return service if service.is_dir() else root


def ensure_documentation_tree(root: Path) -> None:
    for section in (CURRENT_DIR, GUIDE_DIR, UPDATE_DIR, VERIFY_DIR, HISTORY_DIR):
        docs_dir(root, section)
