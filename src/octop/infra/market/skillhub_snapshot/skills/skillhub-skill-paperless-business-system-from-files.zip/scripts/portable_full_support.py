"""3.0.2 图1式交付的兼容常量与已物化结构检查。

实际目录、客户端和启停器由 create_project_scaffold.py 从
assets/delivery-layout 统一生成，避免出现两套不一致的交付逻辑。
"""
from __future__ import annotations

from pathlib import Path

from project_layout import (
    DOCUMENTATION_DIR,
    FORM_TEMPLATE_DIR,
    GENERAL_SOURCE_DIR,
    MACOS_CLIENT_DIR,
    POINTWORK_SOURCE_DIR,
    SERVICE_DIR,
    WINDOWS_CLIENT_DIR,
)


WIN_CLIENT_DIR = WINDOWS_CLIENT_DIR
MAC_CLIENT_DIR = MACOS_CLIENT_DIR
POINTWORK_REF_DIR = POINTWORK_SOURCE_DIR
GENERAL_REF_DIR = GENERAL_SOURCE_DIR
REF_DIR = GENERAL_REF_DIR
TEMPLATE_DIR = FORM_TEMPLATE_DIR
DOC_DIR = DOCUMENTATION_DIR


def portable_enabled(spec: dict) -> bool:
    """3.0.2 把 portable_full/图1六目录作为强制最终交付。"""
    return True


def materialize_portable_layout(root: Path, service: Path, spec: dict, skill_version: str) -> dict:
    """兼容旧调用点：确认新脚手架已物化完整图1结构并返回元数据。"""
    root = Path(root)
    system = spec.get("system") or {}
    domains = {str(item).strip().lower() for item in (system.get("business_domains") or [])}
    source_dir = POINTWORK_SOURCE_DIR if "pointwork" in domains else GENERAL_SOURCE_DIR
    required = (
        SERVICE_DIR,
        WINDOWS_CLIENT_DIR,
        MACOS_CLIENT_DIR,
        source_dir,
        FORM_TEMPLATE_DIR,
        DOCUMENTATION_DIR,
    )
    missing = [name for name in required if not (root / name).is_dir()]
    if Path(service) != root / SERVICE_DIR or missing:
        detail = "、".join(missing) if missing else SERVICE_DIR
        raise RuntimeError(
            "图1式目录尚未由 create_project_scaffold.py 完整物化：" + detail
        )
    return {
        "service_dir": SERVICE_DIR,
        "windows_client_dir": WINDOWS_CLIENT_DIR,
        "macos_client_dir": MACOS_CLIENT_DIR,
        "source_reference_dir": source_dir,
        "form_template_dir": FORM_TEMPLATE_DIR,
        "documentation_dir": DOCUMENTATION_DIR,
        "runtime_strategy": (spec.get("portable_full") or {}).get(
            "runtime_strategy", "self_bootstrap_venv"
        ),
        "skill_version": skill_version,
    }
