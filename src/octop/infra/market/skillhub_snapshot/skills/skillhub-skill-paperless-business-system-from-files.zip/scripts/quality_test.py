#!/usr/bin/env python3
"""在临时目录中运行质量回归；结果与退出码可供CI和验收使用。"""
from __future__ import annotations
import argparse, io, json, sys, unittest
from datetime import datetime, timezone
from pathlib import Path


def main():
    p=argparse.ArgumentParser(description='运行隔离业务质量回归，不修改用户项目。');p.add_argument('--json-report');a=p.parse_args()
    try:import flask,openpyxl
    except ImportError:
        from user_messages import plain
        print(plain('PB802'));return 2
    stream=io.StringIO();suite=unittest.defaultTestLoader.discover(str(Path(__file__).resolve().parents[1]/'tests'))
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    report={'generated_at':datetime.now(timezone.utc).isoformat(),'platform':sys.platform,'python':sys.version.split()[0],'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'network_used':False,'isolated_temporary_projects':True,'details':stream.getvalue()}
    if a.json_report:
        out=Path(a.json_report);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(stream.getvalue())
    return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
