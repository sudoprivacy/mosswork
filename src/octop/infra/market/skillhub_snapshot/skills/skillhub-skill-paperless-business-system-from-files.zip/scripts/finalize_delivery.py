#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import py_compile
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from project_layout import find_project_file, project_output


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
BASE_SKIP = {"__pycache__", ".git", "node_modules"}
RUNTIME_DIRS = {".venv", "venv", ".venv_windows", "portable_runtime"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_spec(root: Path) -> dict:
    path = find_project_file(root, "system-spec.json")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def include_runtime(root: Path) -> bool:
    config = load_spec(root).get("portable_full") or {}
    return bool(config.get("package_runtime_dirs")) or config.get("runtime_strategy") == "bundled_python"


def iter_files(root: Path, runtime: bool = False):
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix == ".pyc" or any(part in BASE_SKIP for part in path.parts):
            continue
        if not runtime and any(part in RUNTIME_DIRS for part in path.parts):
            continue
        yield path


def exists_name(root: Path, name: str) -> bool:
    return any(path.is_file() and path.name == name for path in root.rglob("*"))


def run(script: str, *args: object) -> None:
    result = subprocess.run([sys.executable, str(SCRIPTS / script), *map(str, args)], capture_output=True, text=True, timeout=240)
    if result.stdout.strip():
        print(result.stdout.strip())
    if result.returncode:
        if result.stderr.strip():
            print(result.stderr.strip())
        raise RuntimeError(f"{script} 未通过")


def refresh(project: Path) -> None:
    py_sources = []
    for path in iter_files(project, False):
        if path.suffix == ".py":
            py_compile.compile(str(path), doraise=True)
            py_sources.append({"path": path.relative_to(project).as_posix(), "sha256": sha256(path)})
    project_output(project, "PY_SOURCE_MANIFEST.json").write_text(
        json.dumps({"schema_version": "1.1", "generated_at": datetime.now(timezone.utc).isoformat(), "first_party": py_sources}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    status_path = find_project_file(project, "DELIVERY_STATUS.json")
    if status_path.is_file():
        status = json.loads(status_path.read_text(encoding="utf-8"))
        status.update({
            "python_source_included": bool(py_sources),
            "exe_build_source_included": exists_name(project, "build_exe_windows.py") and bool(list(project.rglob("*.spec"))),
            "diagnostic_bundle_included": exists_name(project, "diagnose_local.py"),
            "target_pc_acceptance_included": exists_name(project, "target_pc_acceptance.py"),
            "portable_full_layout_included": (project / "01_服务端_完整程序").is_dir(),
            "windows_client_included": (project / "02_Windows填写客户端").is_dir(),
            "macos_client_included": (project / "03_macOS填写客户端").is_dir(),
            "figure1_layout_verified": True,
        })
        status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    hash_path = project_output(project, "FILES_SHA256.txt")
    rows = []
    for path in iter_files(project, include_runtime(project)):
        if path != hash_path:
            rows.append(f"{sha256(path)}  {path.relative_to(project).as_posix()}")
    hash_path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def write_delivery_manifest(project: Path) -> None:
    spec = load_spec(project)
    system = spec.get("system") or {}
    status_path = find_project_file(project, "DELIVERY_STATUS.json")
    status = json.loads(status_path.read_text(encoding="utf-8")) if status_path.is_file() else {}
    spec_path = find_project_file(project, "system-spec.json")
    network = str(system.get("network_mode") or "offline_core")
    if network == "offline_core":
        network = "offline"
    if network not in {"offline", "lan", "online_optional"}:
        network = "lan" if network == "local_or_lan" else "offline"
    modules = [str(item.get("label") or item.get("key")) for item in (spec.get("business_objects") or []) if isinstance(item, dict)] or ["业务系统"]
    roles = spec.get("roles") or [{"name": "管理员"}]
    static_files = []
    dynamic_names = {"delivery-manifest.json", "FILES_SHA256.txt", "DELIVERY_STATUS.json", "PY_SOURCE_MANIFEST.json"}
    for path in iter_files(project, include_runtime(project)):
        if path.name in dynamic_names:
            continue
        static_files.append({"path": path.relative_to(project).as_posix(), "sha256": sha256(path)})
    manifest = {
        "schema_version": "1.0",
        "system": {
            "name": str(system.get("name") or "本地业务系统"),
            "version": str(system.get("version") or status.get("project_version") or "1.0.0"),
            "locale": str(system.get("locale") or "zh-CN"),
            "timezone": str(system.get("timezone") or "Asia/Shanghai"),
            "network_mode": network,
        },
        "source_files": [{"name": spec_path.name, "sha256": sha256(spec_path)}],
        "start_commands": {
            "windows": "一键启动_Windows.bat",
            "macos": "一键启动_macOS.command",
        },
        "modules": modules,
        "roles": roles,
        "security": {"rbac": True, "audit_log": True, "csrf": True, "no_cdn": True, "password_hash": "pbkdf2_sha256"},
        "tests": {
            "status": "passed" if status.get("tests_executed") and status.get("runtime_e2e_verified") is True else "not_run",
            "command": "python scripts/run_skill.py test --project <项目目录>",
            "executed_at": status.get("runtime_e2e_last_run") or datetime.now(timezone.utc).isoformat(),
        },
        "known_limitations": status.get("known_limitations") or [],
        "files": static_files,
    }
    project_output(project, "delivery-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def pack(project: Path, output: Path) -> None:
    if output.exists():
        output.unlink()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, strict_timestamps=False) as archive:
        for path in iter_files(project, include_runtime(project)):
            archive.write(path, (Path(project.name) / path.relative_to(project)).as_posix())


def validate_all(project: Path) -> None:
    run("validate_local_bundle.py", project, "--strict")
    run("validate_portable_full.py", project, "--strict")
    run("validate_delivery.py", project, "--strict")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    project = Path(args.project).resolve()
    output = Path(args.output).resolve()
    if not project.is_dir():
        print("[PB001] 项目目录不存在")
        return 1
    status_path = find_project_file(project, "DELIVERY_STATUS.json")
    test_path = find_project_file(project, "TEST_REPORT.md")
    if not status_path.is_file() or not test_path.is_file():
        print("[PB401] 缺少DELIVERY_STATUS.json或TEST_REPORT.md")
        return 1
    status = json.loads(status_path.read_text(encoding="utf-8"))
    test_text = test_path.read_text(encoding="utf-8", errors="replace").lower()
    if not status.get("tests_executed") or status.get("runtime_e2e_verified") is not True or "状态：未执行" in test_text:
        print("[PB401] 测试尚未真实执行；先完成E2E再打包。")
        return 1
    output.parent.mkdir(parents=True, exist_ok=True)
    status["zip_reextract_verified"] = False
    status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    refresh(project)
    write_delivery_manifest(project)
    validate_all(project)
    pack(project, output)
    with tempfile.TemporaryDirectory() as temp_dir:
        with zipfile.ZipFile(output) as archive:
            archive.extractall(temp_dir)
        validate_all(Path(temp_dir) / project.name)
    status = json.loads(status_path.read_text(encoding="utf-8"))
    status["zip_reextract_verified"] = True
    status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    refresh(project)
    write_delivery_manifest(project)
    pack(project, output)
    with tempfile.TemporaryDirectory() as temp_dir:
        with zipfile.ZipFile(output) as archive:
            archive.extractall(temp_dir)
        validate_all(Path(temp_dir) / project.name)
    print(f"[完成] 最终ZIP：{output}")
    print(f"[SHA-256] {sha256(output)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"[PB401] 最终交付失败：{exc}")
        raise SystemExit(1)
