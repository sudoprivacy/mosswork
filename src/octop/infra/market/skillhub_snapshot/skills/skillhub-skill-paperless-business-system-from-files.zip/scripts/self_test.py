#!/usr/bin/env python3
"""技能包自身冒烟测试：覆盖 2.7 闭环，并验证 3.0 持续变更、影响分析、版本历史与回滚。"""
from __future__ import annotations
import hashlib, importlib.util, json, sqlite3, subprocess, sys, tempfile
from pathlib import Path
from project_layout import find_project_file

ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'scripts'

def run(cmd):
    if Path(cmd[0]).name=='run_skill.py':cmd=[cmd[0],'--technical',*cmd[1:]]
    p=subprocess.run([sys.executable,*cmd],cwd=ROOT,text=True,capture_output=True)
    return p.returncode,p.stdout,p.stderr

def write_csvs(src:Path):
    (src/'员工.csv').write_text('工号,姓名,部门\nE001,张三,生产\nE002,李四,质量\nE003,王五,生产\n',encoding='utf-8-sig')
    (src/'能耗记录.csv').write_text('员工编号,日期,用电量,产量\nE001,2026-08-16,100,50\nE001,2026-08-17,120,60\nE002,2026-08-18,90,45\n',encoding='utf-8-sig')

def import_module(path:Path,name:str):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def sha(path:Path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    checks=[]
    rc,out,err=run([str(S/'check_version.py')]); checks.append(('版本一致性 3.1.0',rc==0 and '3.1.0' in out,out or err))
    old_names=('万能'+'本地业务系统生成器','图1式'+'业务系统生成器','万能'+'本地部署')
    visible=[]
    for path in ROOT.rglob('*'):
        if path.is_file() and (path.suffix.lower() in {'.md','.txt','.yaml','.yml','.json','.py'} or path.name in {'VERSION'}):
            try:visible.append(path.read_text(encoding='utf-8'))
            except (OSError,UnicodeDecodeError):pass
    visible_text='\n'.join(visible)
    agent_text=(ROOT/'agents'/'openai.yaml').read_text(encoding='utf-8')
    checks.append(('内部可见名称统一',all(x not in visible_text for x in old_names) and 'display_name: "纸质表单电子化系统生成器"' in agent_text,''))
    rc,out,err=run([str(S/'run_skill.py'),'--help']); checks.append(('统一入口包含 change/rollback',rc==0 and all(x in out for x in ('test','upgrade','change','rollback','generate')),out or err))
    with tempfile.TemporaryDirectory(prefix='paperless-skill-smoke-') as td:
        t=Path(td); src=t/'input'; work=t/'work'; project=t/'project'; upgraded=t/'upgraded'; changed=t/'changed'; rollback=t/'rollback'; plan=t/'plan'; blocked=t/'blocked'; src.mkdir(); write_csvs(src)
        rc,out,err=run([str(S/'run_skill.py'),'analyze',str(src),'--output',str(work),'--system-name','技能自测系统'])
        model=json.loads((work/'business-model.json').read_text(encoding='utf-8')) if (work/'business-model.json').is_file() else {}
        rels=model.get('relationships') or []
        relation_ok=any(r.get('sample_overlap_count',0)>=2 and r.get('confidence_score',0)>=80 for r in rels)
        generated_spec=json.loads((work/'system-spec.json').read_text(encoding='utf-8')) if (work/'system-spec.json').is_file() else {}
        checks.append(('业务关系增强与 3.0 spec',rc==0 and model.get('summary',{}).get('structured_objects',0)>=2 and relation_ok and generated_spec.get('schema_version')=='3.0' and (generated_spec.get('change_management') or {}).get('mode')=='continuous_spec_first',out or err))

        rc,out,err=run([str(S/'run_skill.py'),'generate','--spec',str(work/'system-spec.json'),'--output',str(project)])
        service=project/'01_服务端_完整程序' if (project/'01_服务端_完整程序').is_dir() else project
        schema=json.loads((service/'business'/'generated_schema.json').read_text(encoding='utf-8')) if (service/'business'/'generated_schema.json').is_file() else {}
        fields=[f for o in schema.get('objects',[]) for f in o.get('fields',[])]
        gm=(service/'business'/'generated_migrations.py').read_text(encoding='utf-8') if (service/'business'/'generated_migrations.py').is_file() else ''
        runtime=(service/'business'/'runtime_generated.py').read_text(encoding='utf-8') if (service/'business'/'runtime_generated.py').is_file() else ''
        checks.append(('智能表单/严格校验/迁移/RBAC种子生成',rc==0 and fields and all('ui_control' in f and 'validation' in f for f in fields) and 'ensure_business_schema' in gm and 'spec_defined_role_permission_seeding' in schema.get('generated_capabilities',[]) and 'schema.get(\'roles\'' in runtime,out or err))
        root_names={p.name for p in project.iterdir()}
        figure1_ok={'01_服务端_完整程序','02_Windows填写客户端','03_macOS填写客户端','04_原始业务表参考','05_申请单电子档模板','06_说明与版本记录','一键启动_Windows.bat','一键停止_Windows.bat','一键启动_Windows.vbs','一键停止_Windows.vbs','一键启动_macOS.command','一键停止_macOS.command','技能自测系统_用户密码.rtf'}==root_names
        checks.append(('图1六目录强制生成',figure1_ok,''))
        history_path=find_project_file(project,'CHANGE_HISTORY.json')
        checks.append(('初始变更历史', history_path.is_file() and json.loads(history_path.read_text(encoding='utf-8')).get('project_version')=='1.0.0',''))
        baseline_path=find_project_file(project,'GENERATION_BASELINE.json'); baseline=json.loads(baseline_path.read_text(encoding='utf-8')) if baseline_path.is_file() else {}
        checks.append(('生成结果署名统一',baseline.get('generator_skill')=='纸质表单电子化系统生成器' and baseline.get('generator_skill_id')=='paperless-business-system-from-files',''))

        # 未运行 E2E 时，strict 必须拒绝。
        rc,out,err=run([str(S/'run_skill.py'),'validate','--project',str(project),'--strict'])
        checks.append(('严格验收阻止未测试项目',rc!=0 and ('runtime_e2e_verified' in out or 'tests_executed' in out or 'TEST_REPORT' in out),out or err))

        # 保留 2.7 的直接 spec upgrade 兼容性。
        old_schema=schema; first=old_schema['objects'][0]; db=service/'data'/'app.db'; db.parent.mkdir(parents=True,exist_ok=True)
        c=sqlite3.connect(db); cols=','.join(f'"{f["column"]}" TEXT' for f in first['fields']); c.execute(f'CREATE TABLE "{first["table"]}"(id INTEGER PRIMARY KEY AUTOINCREMENT,{cols},created_by INTEGER,updated_by INTEGER,created_at TEXT,updated_at TEXT)'); c.execute('CREATE TABLE preserve_probe(k TEXT PRIMARY KEY,v TEXT)'); c.execute("INSERT INTO preserve_probe VALUES('keep','yes')"); c.commit(); c.close()
        new_spec=json.loads((work/'system-spec.json').read_text(encoding='utf-8')); new_spec['business_objects'][0]['fields'].append({'key':'c99','label':'升级新增字段','type':'text','nullable':True,'candidate_unique':False,'examples':['A']})
        new_spec_path=t/'new-system-spec.json'; new_spec_path.write_text(json.dumps(new_spec,ensure_ascii=False,indent=2),encoding='utf-8')
        rc,out,err=run([str(S/'run_skill.py'),'upgrade','--project',str(project),'--spec',str(new_spec_path),'--output',str(upgraded)])
        up_service=upgraded/'01_服务端_完整程序' if (upgraded/'01_服务端_完整程序').is_dir() else upgraded
        up_db=up_service/'data'/'app.db'; additive_ok=False
        if rc==0 and up_db.is_file():
            gm_mod=import_module(up_service/'business'/'generated_migrations.py','generated_migrations_smoke')
            c=sqlite3.connect(up_db); gm_mod.ensure_business_schema(c); c.commit(); cols2={r[1] for r in c.execute(f'PRAGMA table_info("{first["table"]}")').fetchall()}; probe=c.execute("SELECT v FROM preserve_probe WHERE k='keep'").fetchone(); c.close(); additive_ok=('c99' in cols2 and probe and probe[0]=='yes')
        diff_path=find_project_file(upgraded,'upgrade-diff.json'); diff=json.loads(diff_path.read_text(encoding='utf-8')) if diff_path.is_file() else {}
        checks.append(('2.7 直接升级兼容与数据保留',rc==0 and additive_ok and diff.get('summary',{}).get('safe_additive',0)>=1,out or err))

        # 3.0：自然语言由执行智能体结构化；引擎先 plan，再创建候选，源项目不可变。
        base_spec_path=find_project_file(project,'system-spec.json'); base_spec=json.loads(base_spec_path.read_text(encoding='utf-8')); base_hash=sha(base_spec_path)
        obj_ref=base_spec['business_objects'][0].get('label') or base_spec['business_objects'][0].get('key')
        req={'schema_version':'3.0','request_id':'chg-smoke-001','title':'新增备注字段','natural_language':f'给{obj_ref}增加一个备注字段','assumptions':[],'unresolved':[],'operations':[{'op':'add_field','object':obj_ref,'field':{'key':'continuous_note','label':'持续变更备注','type':'text','required':False}}]}
        req_path=t/'CHANGE_REQUEST.json'; req_path.write_text(json.dumps(req,ensure_ascii=False,indent=2),encoding='utf-8')
        rc,out,err=run([str(S/'run_skill.py'),'change','--project',str(project),'--request-file',str(req_path),'--output',str(plan),'--plan-only'])
        impact=json.loads((plan/'CHANGE_IMPACT.json').read_text(encoding='utf-8')) if (plan/'CHANGE_IMPACT.json').is_file() else {}
        checks.append(('3.0 变更影响分析',rc==0 and impact.get('risk_level')=='low' and impact.get('safe_to_create_candidate') is True and (plan/'CHANGE_PLAN.md').is_file(),out or err))
        rc,out,err=run([str(S/'run_skill.py'),'change','--project',str(project),'--request-file',str(req_path),'--output',str(changed)])
        changed_spec_path=find_project_file(changed,'system-spec.json'); changed_spec=json.loads(changed_spec_path.read_text(encoding='utf-8')) if changed_spec_path.is_file() else {}
        changed_history_path=find_project_file(changed,'CHANGE_HISTORY.json'); history=json.loads(changed_history_path.read_text(encoding='utf-8')) if changed_history_path.is_file() else {}
        changed_status_path=find_project_file(changed,'DELIVERY_STATUS.json'); changed_status=json.loads(changed_status_path.read_text(encoding='utf-8')) if changed_status_path.is_file() else {}
        new_field_ok=any(f.get('key')=='continuous_note' for f in changed_spec.get('business_objects',[{}])[0].get('fields',[]))
        source_immutable=sha(base_spec_path)==base_hash
        checks.append(('3.0 候选副本/版本历史/源项目不可变',rc==0 and new_field_ok and source_immutable and history.get('project_version')=='1.1.0' and changed_status.get('continuous_change_candidate') is True and changed_status.get('runtime_e2e_verified') is False,out or err))

        # 3.0 strict 对未重测候选必须额外阻断。
        rc,out,err=run([str(S/'run_skill.py'),'validate','--project',str(changed),'--strict'])
        checks.append(('3.0 候选必须重新 E2E',rc!=0 and ('change_runtime_verified' in out or 'runtime_e2e_verified' in out),out or err))

        # 删除字段必须被高风险门禁挡住，不能静默生成候选。
        field_ref=base_spec['business_objects'][0]['fields'][0].get('label') or base_spec['business_objects'][0]['fields'][0].get('key')
        req2={'schema_version':'3.0','request_id':'chg-smoke-break','natural_language':f'删除{field_ref}','unresolved':[],'operations':[{'op':'remove_field','object':obj_ref,'field':field_ref}]}
        req2p=t/'BREAKING_REQUEST.json'; req2p.write_text(json.dumps(req2,ensure_ascii=False,indent=2),encoding='utf-8')
        rc,out,err=run([str(S/'run_skill.py'),'change','--project',str(project),'--request-file',str(req2p),'--output',str(blocked)])
        checks.append(('3.0 破坏性变更默认阻断',rc!=0 and (blocked/'CHANGE_IMPACT.json').is_file() and json.loads((blocked/'CHANGE_IMPACT.json').read_text(encoding='utf-8')).get('risk_level')=='high' and sha(base_spec_path)==base_hash,out or err))

        # 逻辑回滚可以恢复升级前 spec，不执行破坏性删列。
        rc,out,err=run([str(S/'run_skill.py'),'rollback','--project',str(changed),'--output',str(rollback)])
        rb_spec_path=find_project_file(rollback,'system-spec.json'); rb_spec=json.loads(rb_spec_path.read_text(encoding='utf-8')) if rb_spec_path.is_file() else {}
        rb_field=any(f.get('key')=='continuous_note' for f in rb_spec.get('business_objects',[{}])[0].get('fields',[])) if rb_spec.get('business_objects') else True
        checks.append(('3.0 非破坏式逻辑回滚',rc==0 and not rb_field and find_project_file(rollback,'ROLLBACK_REPORT.md').is_file(),out or err))

        rc,out,err=run([str(S/'runtime_e2e_test.py'),'--help']); checks.append(('真实运行 E2E 测试器可调用',rc==0 and '隔离副本' in out,out or err))

    failed=[x for x in checks if not x[1]]
    for name,ok,msg in checks: print(f"[{'通过' if ok else '失败'}] {name}")
    if failed:
        for name,_,msg in failed: print(f'--- {name} ---\n{msg}')
        return 1
    print(f'[通过] 技能冒烟测试完成：{len(checks)}/{len(checks)}')
    print('[说明] runtime E2E 的真实启动测试需项目运行环境已安装 Flask/openpyxl；self-test 验证 3.0 变更/回滚架构和验收门禁，不伪造运行通过。')
    return 0

if __name__=='__main__': raise SystemExit(main())
