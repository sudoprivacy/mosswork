#!/usr/bin/env python3
"""3.0 连续变更引擎：把结构化自然语言意图安全应用到已有 system-spec，并生成升级候选副本。"""
from __future__ import annotations

import argparse
import copy
import json
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from project_layout import find_project_file, project_output

ROOT = Path(__file__).resolve().parents[1]
S = ROOT / 'scripts'


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def slug(value: str, fallback: str = 'item') -> str:
    s = re.sub(r'[^a-zA-Z0-9_]+', '_', str(value or '')).strip('_').lower()
    if not s:
        s = fallback
    if s[0].isdigit():
        s = f'{fallback}_{s}'
    return s[:64]


def resolve_object(spec: dict, ref: str) -> tuple[dict | None, str | None]:
    ref = str(ref or '').strip()
    exact = []
    for obj in spec.get('business_objects') or []:
        if ref and ref in {str(obj.get('key') or ''), str(obj.get('label') or '')}:
            exact.append(obj)
    if len(exact) == 1:
        return exact[0], None
    if len(exact) > 1:
        return None, f'业务对象引用不唯一：{ref}'
    folded = ref.lower()
    fuzzy = [o for o in spec.get('business_objects') or [] if folded and (folded in str(o.get('key') or '').lower() or folded in str(o.get('label') or '').lower())]
    if len(fuzzy) == 1:
        return fuzzy[0], None
    if len(fuzzy) > 1:
        return None, f'业务对象模糊匹配到多个候选：{ref}'
    return None, f'找不到业务对象：{ref}'


def resolve_field(obj: dict, ref: str) -> tuple[dict | None, str | None]:
    ref = str(ref or '').strip()
    exact = [f for f in obj.get('fields') or [] if ref and ref in {str(f.get('key') or ''), str(f.get('label') or '')}]
    if len(exact) == 1:
        return exact[0], None
    if len(exact) > 1:
        return None, f'字段引用不唯一：{ref}'
    folded = ref.lower()
    fuzzy = [f for f in obj.get('fields') or [] if folded and (folded in str(f.get('key') or '').lower() or folded in str(f.get('label') or '').lower())]
    if len(fuzzy) == 1:
        return fuzzy[0], None
    if len(fuzzy) > 1:
        return None, f'字段模糊匹配到多个候选：{ref}'
    return None, f'找不到字段：{ref}'


def normalize_field(raw: dict, index: int) -> dict:
    label = str(raw.get('label') or raw.get('name') or f'新增字段{index}').strip()
    key = str(raw.get('key') or '').strip() or slug(label, f'field_{index}')
    ftype = str(raw.get('type') or 'text').lower()
    if ftype not in {'text', 'integer', 'number', 'boolean', 'date', 'datetime'}:
        raise ValueError(f'不支持字段类型：{ftype}')
    out = {
        'key': key,
        'label': label,
        'type': ftype,
        'nullable': bool(raw.get('nullable', not bool(raw.get('required', False)))),
        'required': bool(raw.get('required', False)),
        'candidate_unique': bool(raw.get('candidate_unique', False)),
        'examples': list(raw.get('examples') or [])[:10],
        'enum_candidates': [str(x) for x in (raw.get('enum_candidates') or []) if str(x).strip()][:50],
        'evidence_level': str(raw.get('evidence_level') or 'user_confirmed'),
        'evidence': raw.get('evidence') or 'continuous_change_request'
    }
    if out['required']:
        out['required_confirmed'] = True
    return out


def add_unique(items: list, item: Any) -> bool:
    sig = json.dumps(item, ensure_ascii=False, sort_keys=True)
    if any(json.dumps(x, ensure_ascii=False, sort_keys=True) == sig for x in items):
        return False
    items.append(item)
    return True


def dependency_hits(spec: dict, object_key: str, field_key: str | None = None) -> list[dict]:
    hits = []
    needles = {str(object_key)}
    if field_key:
        needles.add(str(field_key))
    sections = ['field_mappings', 'calculation_rules', 'relationships', 'permissions', 'workflows', 'reports']
    for section in sections:
        for idx, item in enumerate(spec.get(section) or []):
            text = json.dumps(item, ensure_ascii=False)
            if all(n in text for n in needles):
                hits.append({'section': section, 'index': idx, 'evidence': item})
    obj, _ = resolve_object(spec, object_key)
    if obj and field_key:
        for idx, item in enumerate(obj.get('calculation_rules') or []):
            text = json.dumps(item, ensure_ascii=False)
            if field_key in text:
                hits.append({'section': f'business_objects.{object_key}.calculation_rules', 'index': idx, 'evidence': item})
    return hits


def apply_operations(old: dict, request: dict) -> tuple[dict, list[dict], list[str]]:
    spec = copy.deepcopy(old)
    applied: list[dict] = []
    errors: list[str] = []
    operations = request.get('operations') or []
    for i, op in enumerate(operations, 1):
        kind = str(op.get('op') or '').strip()
        try:
            if kind == 'add_field':
                obj, err = resolve_object(spec, op.get('object'))
                if err: raise ValueError(err)
                field = normalize_field(op.get('field') or {}, i)
                if any(field['key'] == str(f.get('key')) or field['label'] == str(f.get('label')) for f in obj.get('fields') or []):
                    raise ValueError(f'字段已存在：{field["label"]}/{field["key"]}')
                obj.setdefault('fields', []).append(field)
                applied.append({'op': kind, 'object': obj.get('key'), 'field': field})
            elif kind == 'rename_field':
                obj, err = resolve_object(spec, op.get('object'))
                if err: raise ValueError(err)
                field, err = resolve_field(obj, op.get('field'))
                if err: raise ValueError(err)
                before = field.get('label')
                field['label'] = str(op.get('new_label') or '').strip()
                if not field['label']: raise ValueError('new_label 不能为空')
                applied.append({'op': kind, 'object': obj.get('key'), 'field': field.get('key'), 'from': before, 'to': field['label']})
            elif kind == 'set_required':
                obj, err = resolve_object(spec, op.get('object'))
                if err: raise ValueError(err)
                field, err = resolve_field(obj, op.get('field'))
                if err: raise ValueError(err)
                value = bool(op.get('required'))
                field['required'] = value
                field['required_confirmed'] = value
                field['nullable'] = not value
                field['evidence_level'] = 'user_confirmed'
                applied.append({'op': kind, 'object': obj.get('key'), 'field': field.get('key'), 'required': value})
            elif kind == 'change_field_type':
                obj, err = resolve_object(spec, op.get('object'))
                if err: raise ValueError(err)
                field, err = resolve_field(obj, op.get('field'))
                if err: raise ValueError(err)
                new_type = str(op.get('new_type') or '').lower()
                if new_type not in {'text','integer','number','boolean','date','datetime'}: raise ValueError(f'不支持字段类型：{new_type}')
                before = field.get('type')
                field['type'] = new_type
                field['evidence_level'] = 'user_confirmed'
                applied.append({'op': kind, 'object': obj.get('key'), 'field': field.get('key'), 'from': before, 'to': new_type})
            elif kind == 'remove_field':
                obj, err = resolve_object(spec, op.get('object'))
                if err: raise ValueError(err)
                field, err = resolve_field(obj, op.get('field'))
                if err: raise ValueError(err)
                obj['fields'] = [f for f in obj.get('fields') or [] if f is not field]
                applied.append({'op': kind, 'object': obj.get('key'), 'field': field.get('key'), 'label': field.get('label')})
            elif kind == 'add_object':
                raw = copy.deepcopy(op.get('object_spec') or {})
                label = str(raw.get('label') or op.get('label') or '').strip()
                if not label: raise ValueError('新增业务对象缺少 label')
                key = str(raw.get('key') or op.get('key') or '').strip() or slug(label, f'object_{i}')
                if any(key == str(x.get('key')) or label == str(x.get('label')) for x in spec.get('business_objects') or []):
                    raise ValueError(f'业务对象已存在：{label}/{key}')
                fields = [normalize_field(x, n) for n, x in enumerate(raw.get('fields') or [], 1)]
                if not fields: raise ValueError('新增业务对象至少需要 1 个字段')
                obj = {'key': key, 'label': label, 'fields': fields, 'confirmed_unique_keys': raw.get('confirmed_unique_keys') or [], 'calculation_rules': raw.get('calculation_rules') or [], 'evidence': 'continuous_change_request', 'confidence_score': 100}
                spec.setdefault('business_objects', []).append(obj)
                applied.append({'op': kind, 'object': key, 'label': label, 'fields': len(fields)})
            elif kind == 'remove_object':
                obj, err = resolve_object(spec, op.get('object'))
                if err: raise ValueError(err)
                spec['business_objects'] = [x for x in spec.get('business_objects') or [] if x is not obj]
                applied.append({'op': kind, 'object': obj.get('key'), 'label': obj.get('label')})
            elif kind == 'add_role':
                role = copy.deepcopy(op.get('role') or {})
                name = str(role.get('name') or role.get('label') or '').strip()
                if not name: raise ValueError('角色名称不能为空')
                role.setdefault('key', slug(role.get('key') or name, 'role'))
                role['name'] = name
                role.setdefault('description', '')
                add_unique(spec.setdefault('roles', []), role)
                applied.append({'op': kind, 'role': role})
            elif kind == 'add_permission':
                perm = copy.deepcopy(op.get('permission') or {})
                if not perm: raise ValueError('permission 不能为空')
                perm.setdefault('evidence_level', 'user_confirmed')
                perm.setdefault('evidence', 'continuous_change_request')
                add_unique(spec.setdefault('permissions', []), perm)
                applied.append({'op': kind, 'permission': perm})
            elif kind == 'add_workflow':
                wf = copy.deepcopy(op.get('workflow') or {})
                if not wf: raise ValueError('workflow 不能为空')
                wf.setdefault('key', slug(wf.get('key') or wf.get('name') or f'workflow_{i}', 'workflow'))
                wf.setdefault('evidence_level', 'user_confirmed')
                add_unique(spec.setdefault('workflows', []), wf)
                applied.append({'op': kind, 'workflow': wf})
            elif kind == 'add_report':
                rpt = copy.deepcopy(op.get('report') or {})
                if not rpt: raise ValueError('report 不能为空')
                rpt.setdefault('key', slug(rpt.get('key') or rpt.get('name') or f'report_{i}', 'report'))
                rpt.setdefault('evidence_level', 'user_confirmed')
                add_unique(spec.setdefault('reports', []), rpt)
                applied.append({'op': kind, 'report': rpt})
            elif kind == 'set_system_name':
                name = str(op.get('name') or '').strip()
                if not name: raise ValueError('系统名称不能为空')
                before = (spec.get('system') or {}).get('name')
                spec.setdefault('system', {})['name'] = name
                applied.append({'op': kind, 'from': before, 'to': name})
            else:
                raise ValueError(f'不支持的变更操作：{kind or "<empty>"}')
        except Exception as exc:
            errors.append(f'第 {i} 项 {kind or "<empty>"}：{exc}')
    return spec, applied, errors


def impact_analysis(old: dict, new: dict, applied: list[dict], unresolved: list) -> dict:
    # 复用 2.7 成熟 diff 语义，3.0 在其上增加依赖影响和风险等级。
    import upgrade_system
    diff = upgrade_system.compare(old, new)
    dependencies = []
    for item in applied:
        if item.get('op') in {'remove_field', 'change_field_type'}:
            dependencies.extend(dependency_hits(old, str(item.get('object')), str(item.get('field'))))
        elif item.get('op') == 'remove_object':
            dependencies.extend(dependency_hits(old, str(item.get('object'))))
    materialization = []
    for item in applied:
        op = item.get('op')
        if op in {'add_field','rename_field','set_required','change_field_type','remove_field','add_object','remove_object','set_system_name'}:
            materialization.append({'operation': op, 'level': 'generated_runtime', 'note': '会进入 system-spec 并重新生成业务运行代码；数据库仍只自动执行非破坏式迁移。'})
        elif op in {'add_role','add_permission'}:
            materialization.append({'operation': op, 'level': 'spec_and_rbac_seed', 'note': '写入 system-spec；纸质表单电子化系统生成器 3.0 会保留角色/权限声明并生成权限种子。数据范围权限仍需明确字段规则。'})
        elif op in {'add_workflow','add_report'}:
            materialization.append({'operation': op, 'level': 'spec_only_review_required', 'note': '写入 system-spec 并纳入影响/审计；通用骨架不会在无明确状态字段、指标公式时猜测完整流程页面或统计口径。'})
    risk = 'low'
    reasons = []
    if diff['breaking'] or dependencies:
        risk = 'high'; reasons.append('存在破坏性结构变化或已发现依赖引用')
    elif diff['review_required'] or unresolved:
        risk = 'medium'; reasons.append('存在需业务复核的规则变化或未解决项')
    else:
        reasons.append('仅检测到可安全新增变化')
    return {
        'schema_version': '3.0',
        'generated_at': now(),
        'risk_level': risk,
        'risk_reasons': reasons,
        'upgrade_diff': diff,
        'dependency_impacts': dependencies,
        'materialization': materialization,
        'unresolved': unresolved,
        'safe_to_create_candidate': not bool(unresolved) and (not diff['breaking']) and not bool(dependencies),
        'source_project_is_immutable': True
    }


def semver_next(current: str, impact: dict) -> str:
    m = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)', str(current or ''))
    major, minor, patch = map(int, m.groups()) if m else (1, 0, 0)
    if impact.get('risk_level') == 'high':
        return f'{major+1}.0.0'
    if impact.get('upgrade_diff', {}).get('summary', {}).get('safe_additive', 0):
        return f'{major}.{minor+1}.0'
    return f'{major}.{minor}.{patch+1}'


def history_for(project: Path) -> dict:
    path = find_project_file(project, 'CHANGE_HISTORY.json')
    if path.is_file():
        try:return load_json(path)
        except Exception: pass
    return {'schema_version': '3.0', 'project_version': '1.0.0', 'entries': []}


def render_plan(request: dict, applied: list[dict], impact: dict, next_version: str) -> str:
    diff = impact['upgrade_diff']['summary']
    lines = [
        '# CHANGE_PLAN', '',
        f'- 请求：{request.get("natural_language") or request.get("title") or request.get("request_id") or "结构化变更"}',
        f'- 风险：**{impact["risk_level"]}**',
        f'- 目标项目版本：**{next_version}**',
        f'- 安全新增：{diff.get("safe_additive",0)}',
        f'- 需复核：{diff.get("review_required",0)}',
        f'- 破坏性：{diff.get("breaking",0)}',
        f'- 依赖命中：{len(impact.get("dependency_impacts") or [])}',
        '', '## 执行顺序', '',
        '1. 固化原 system-spec 与变更请求。',
        '2. 生成 proposed-system-spec.json。',
        '3. 执行影响分析与风险分级。',
        '4. 只在原项目不变的前提下创建升级候选副本。',
        '5. 重新生成业务模块并保留原数据库。',
        '6. 清空旧运行验收状态，要求重新执行真实 E2E。',
        '7. E2E + validate --strict 通过后，候选版本才可作为正式版本使用。',
        '', '## 本次结构化操作', ''
    ]
    lines += [f'- `{x.get("op")}`：{json.dumps(x, ensure_ascii=False)}' for x in applied] or ['- 无']
    if impact.get('dependency_impacts'):
        lines += ['', '## 依赖影响', ''] + [f'- {json.dumps(x, ensure_ascii=False)}' for x in impact['dependency_impacts']]
    if impact.get('unresolved'):
        lines += ['', '## 未解决项', ''] + [f'- {x}' for x in impact['unresolved']]
    lines += ['', '> 3.0 默认不原地修改源项目。候选项目未重新通过真实运行测试前，不得宣称变更已验证。', '']
    return '\n'.join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description='3.0 连续变更：将结构化自然语言意图安全应用到已有项目。')
    ap.add_argument('--project', required=True, help='已有生成项目')
    ap.add_argument('--request-file', required=True, help='由执行智能体根据用户自然语言生成的 CHANGE_REQUEST.json')
    ap.add_argument('--output', required=True, help='计划目录或升级候选目录')
    ap.add_argument('--plan-only', action='store_true')
    ap.add_argument('--allow-breaking', action='store_true')
    ap.add_argument('--allow-unresolved', action='store_true')
    ap.add_argument('--force', action='store_true')
    a = ap.parse_args()

    project = Path(a.project).expanduser().resolve()
    request_path = Path(a.request_file).expanduser().resolve()
    out = Path(a.output).expanduser().resolve()
    old_spec_path = find_project_file(project, 'system-spec.json')
    if not project.is_dir() or not old_spec_path.is_file():
        print('[PB1001] 已有项目不存在或缺少 system-spec.json'); return 1
    if not request_path.is_file():
        print('[PB1002] CHANGE_REQUEST.json 不存在'); return 1
    try:
        old = load_json(old_spec_path); request = load_json(request_path)
    except Exception as e:
        print(f'[PB1003] 输入 JSON 无法读取：{e}'); return 1
    if str(request.get('schema_version') or '') not in {'3.0','3.0.0'}:
        print('[PB1004] CHANGE_REQUEST.schema_version 必须为 3.0'); return 1
    unresolved = list(request.get('unresolved') or [])
    new, applied, errors = apply_operations(old, request)
    if errors:
        print('[PB1005] 结构化变更请求包含无法安全执行的操作：')
        for e in errors: print('-', e)
        return 1
    if not applied:
        print('[PB1006] 没有可执行 operations'); return 1
    impact = impact_analysis(old, new, applied, unresolved)
    history = history_for(project)
    next_version = semver_next(history.get('project_version','1.0.0'), impact)

    if out.exists():
        if not a.force:
            print('[PB1007] 输出目录已存在；确认覆盖请加 --force'); return 1
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    write_json(out/'CHANGE_REQUEST.json', request)
    write_json(out/'proposed-system-spec.json', new)
    write_json(out/'CHANGE_IMPACT.json', impact)
    (out/'CHANGE_PLAN.md').write_text(render_plan(request, applied, impact, next_version), encoding='utf-8')
    (out/'CHANGE_IMPACT_REPORT.md').write_text(
        '# CHANGE_IMPACT_REPORT\n\n'
        f'- 风险等级：**{impact["risk_level"]}**\n'
        f'- 安全创建候选：**{"是" if impact["safe_to_create_candidate"] else "否"}**\n'
        f'- 依赖命中：**{len(impact["dependency_impacts"])}**\n'
        f'- 未解决项：**{len(unresolved)}**\n\n'
        '详细机器可读结果见 `CHANGE_IMPACT.json`。\n', encoding='utf-8')

    if a.plan_only:
        print(f'[完成] 3.0 变更计划：{out}')
        print(f'[风险] {impact["risk_level"]}；源项目未修改。')
        return 0
    if unresolved and not a.allow_unresolved:
        print(f'[PB1008] 仍有 {len(unresolved)} 个未解决业务问题，默认停止创建候选。计划已输出：{out}'); return 1
    breaking = impact['upgrade_diff'].get('breaking') or []
    if (breaking or impact['dependency_impacts']) and not a.allow_breaking:
        print(f'[PB1009] 检测到高风险/破坏性影响，默认停止自动应用。计划已输出：{out}'); return 1

    # 将计划先保存在内存，再让成熟的 2.7 upgrade 引擎创建完整候选副本。
    payloads = {p.name:p.read_bytes() for p in out.iterdir() if p.is_file()}
    shutil.rmtree(out)
    with tempfile.TemporaryDirectory(prefix='paperless-change-') as td:
        proposed = Path(td)/'proposed-system-spec.json'
        write_json(proposed, new)
        cmd = [sys.executable, str(S/'upgrade_system.py'), '--project', str(project), '--spec', str(proposed), '--output', str(out)]
        if a.allow_breaking: cmd.append('--allow-breaking')
        rc = subprocess.run(cmd).returncode
        if rc:
            shutil.rmtree(out, ignore_errors=True)
            print('[PB1010] 候选版本生成失败；源项目保持不变。')
            return rc
    for name, data in payloads.items():
        project_output(out, name).write_bytes(data)
    # 最终候选的正式 spec 必须等于 proposed spec。
    write_json(project_output(out,'system-spec.json'), new)
    hist = history_for(project)
    entry = {
        'timestamp': now(),
        'from_version': hist.get('project_version','1.0.0'),
        'to_version': next_version,
        'request_id': request.get('request_id'),
        'natural_language': request.get('natural_language'),
        'risk_level': impact['risk_level'],
        'operations': applied,
        'source_project': str(project),
        'candidate_project': str(out),
        'runtime_verified': False
    }
    hist['schema_version'] = '3.0'; hist['project_version'] = next_version
    hist.setdefault('entries', []).append(entry)
    write_json(project_output(out,'CHANGE_HISTORY.json'), hist)
    status = find_project_file(out,'DELIVERY_STATUS.json')
    if status.is_file():
        st = load_json(status)
        st.update({
            'continuous_change_supported': True,
            'continuous_change_candidate': True,
            'change_request_included': True,
            'change_impact_report_included': True,
            'change_plan_included': True,
            'change_history_included': True,
            'change_runtime_verified': False,
            'change_source_project_immutable': True,
            'project_version': next_version,
            'runtime_e2e_verified': False,
            'complex_features_runtime_verified': False,
            'runtime_e2e_last_run': None,
            'runtime_e2e_test_environment': None,
            'tests_executed': []
        })
        write_json(status, st)
    project_output(out,'TEST_REPORT.md').write_text('# TEST_REPORT\n\n状态：未执行。3.0 变更候选必须重新执行真实运行 E2E，再执行 `validate --strict`。\n', encoding='utf-8')
    print(f'[完成] 已创建 3.0 连续变更候选：{out}')
    print(f'[版本] {entry["from_version"]} -> {entry["to_version"]}；风险 {impact["risk_level"]}。')
    print('[安全] 源项目未修改；候选必须重新 test + validate --strict 后才能作为正式版本。')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
