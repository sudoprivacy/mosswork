# CHANGELOG 3.0.3

## 界面与功能参照点工系统范式

- 新增 `references/ui-functional-patterns.md`：把点工系统的界面布局范式（顶栏 + 左侧多视图导航 + 卡片 + 筛选 + 汇总卡片 + 表格 + 弹窗 + 签字）与功能模块范式（主数据录入 / 明细录入 / 看板驾驶舱 / 汇总导出 / 单据电子档 / 档案管理 / 系统管理）系统化，作为生成系统时的「界面与功能参照基准」。
- 更新 `SKILL.md`：新增 11.1 节「界面与功能参照点工系统范式（强制）」，并在 frontmatter description 与参考文件路由表中纳入该范式，生成系统时不再退回「顶部导航 + 单列表」的简陋骨架。
- 升级前端骨架 `assets/scaffold/universal-local-app`：`templates/base.html` 改为「顶栏 + 左侧 sidebar 多视图导航 + 主区」，`static/app.css` 重写为点工式样式（红色主色 #D9232E、卡片、筛选、汇总卡片、表格、弹窗、状态标签、按钮分级），`templates/dashboard.html` 增强为带 page-head + summary-cards + 业务模块网格的首页。
- 业务模块 CRUD 从「多页跳转」升级为「列表内弹窗录入」：新增 `static/app.js`（openModal/closeModal/confirmAction/toast 通用交互），`business_list.html` 改为 page-head + 筛选 + 汇总卡片 + 表格 + 弹窗新增/编辑 + 确认删除，`business_form.html` 改为弹窗内 AJAX 提交（保存后通知父窗口刷新），`business_index.html`/`business_import.html` 统一 page-head 版式；`business/runtime_generated.py` 的 new/edit 支持 `X-Requested-With` 返回 JSON（弹窗 AJAX 用），普通表单仍走 redirect 保持兼容。

> 业务字段、公式、口径仍以用户上传的表单与提示词为准；本版本只规定界面长相与能力集合。
>
> 已端到端验证：生成的系统登录后，列表页含 page-head/summary-cards/弹窗入口，弹窗 AJAX 新增返回 `{"ok":true}` 且数据正确写入回显。
