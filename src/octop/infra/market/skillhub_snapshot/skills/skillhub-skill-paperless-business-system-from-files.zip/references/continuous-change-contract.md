# 3.0 持续变更契约（Spec-first Continuous Change）

## 1. 核心目标

3.0 不再要求用户为了一个小改动重新上传全部材料、重新生成整个系统。已有系统后续修改默认采用：

`用户自然语言需求 → CHANGE_REQUEST → 影响分析 → proposed-system-spec → 候选副本 → E2E → strict 验收 → 新版本`

执行智能体负责把用户原话结构化为 `CHANGE_REQUEST.json`；确定性脚本负责应用变更和判断风险。脚本本身不伪装成大语言模型，也不会在缺少证据时猜测业务规则。

## 2. CHANGE_REQUEST

模板：`assets/templates/change-request.template.json`。

必须保留 `natural_language` 原文，并将已确认动作写入 `operations`。支持：

- `add_field`
- `rename_field`
- `set_required`
- `change_field_type`
- `remove_field`
- `add_object`
- `remove_object`
- `add_role`
- `add_permission`
- `add_workflow`
- `add_report`
- `set_system_name`

无法确认且会影响正式业务结果的内容必须写入 `unresolved`，不得靠默认值伪造。

## 3. 影响分析门禁

统一入口：

```bash
python scripts/run_skill.py change \
  --project <当前项目> \
  --request-file <CHANGE_REQUEST.json> \
  --output <计划或候选目录> \
  --plan-only
```

输出：

- `CHANGE_REQUEST.json`
- `proposed-system-spec.json`
- `CHANGE_PLAN.md`
- `CHANGE_IMPACT.json`
- `CHANGE_IMPACT_REPORT.md`

风险级别：

- `low`：仅安全新增；
- `medium`：存在规则、权限、流程等需复核变化；
- `high`：删除、字段改类型，或检测到依赖引用。

`high` 默认阻断；只有执行者明确确认迁移方案后才可使用 `--allow-breaking`。

## 4. 候选版本，不原地覆盖

默认应用：

```bash
python scripts/run_skill.py change \
  --project <当前项目> \
  --request-file <CHANGE_REQUEST.json> \
  --output <新候选项目>
```

源项目必须保持不变。候选项目会继承数据库与历史文件，重新生成运行代码，并新增：

- `CHANGE_HISTORY.json`
- `system-spec.before-upgrade.json`
- `UPGRADE_DIFF_REPORT.md`
- `upgrade-diff.json`

项目版本按风险自动递增：安全新增通常提升 minor；高风险变更提升 major；其他变化提升 patch。

## 5. 变更后重新测试是硬门禁

候选项目创建后，旧版本的 E2E 证据全部失效：

```bash
python scripts/run_skill.py test --project <候选项目>
python scripts/run_skill.py validate --project <候选项目> --strict
```

`DELIVERY_STATUS.json.continuous_change_candidate=true` 时，strict 额外要求：

- `CHANGE_REQUEST.json` 存在；
- `CHANGE_PLAN.md` 存在；
- `CHANGE_IMPACT.json` / `CHANGE_IMPACT_REPORT.md` 存在；
- `CHANGE_HISTORY.json` 存在；
- `change_source_project_immutable=true`；
- 重新 E2E 后 `change_runtime_verified=true`。

因此“修改完成”与“修改已验证”必须分开表述。

## 6. 角色与权限

3.0 生成运行架构会保留 `system-spec.roles` 与 `system-spec.permissions`，并把明确的对象级 RBAC 规则种入生成系统。

支持的通用对象权限动作：

`view / create / edit / delete / import / export`

数据范围权限（例如“只能看自己”“主管看本部门”）必须有明确用户字段、部门字段或归属关系；缺少这些证据时只能写入待确认，禁止用对象级 RBAC 冒充数据范围权限。

## 7. 工作流和报表的边界

`add_workflow` / `add_report` 可以进入 system-spec、变更历史和影响分析，但通用骨架不会在以下信息缺失时自行猜测完整实现：

- 工作流缺少状态字段、状态迁移、审批角色或驳回规则；
- 报表缺少指标口径、时间粒度、过滤维度或计算公式。

此时能力状态只能是“规格已记录/待物化”，不能声称运行功能已经完成。

## 8. 回滚

```bash
python scripts/run_skill.py rollback --project <变更候选> --output <回滚副本>
```

回滚恢复 `system-spec.before-upgrade.json` 并重新生成旧运行逻辑。为保护历史数据，默认不执行 DROP COLUMN 或改类型等破坏性 SQL；新增数据库列可能保留，但旧规格不会使用它们。回滚副本仍必须重新 test + strict validate。

## 9. 禁止行为

- 禁止直接根据自然语言搜索替换源码而跳过 system-spec；
- 禁止在没有 `CHANGE_REQUEST` 的情况下声称“持续修改已纳入版本管理”；
- 禁止把旧版本 E2E 结果继承成新候选的测试通过；
- 禁止为了“回滚干净”而自动删除历史数据库列；
- 禁止在高风险依赖命中时静默加 `--allow-breaking`；
- 禁止把尚未物化的 workflow/report 规格描述为已经可运行。
