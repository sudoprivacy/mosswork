# 3.0.0 大版本升级说明

3.0.0 的目标不是继续增加零散页面，而是把技能从“一次性从资料生成系统”升级为“已有系统可持续、安全迭代”。

## 核心新增

1. **Spec-first 连续变更**：新增 `change` 命令。执行智能体把用户自然语言原文结构化成 `CHANGE_REQUEST.json`，确定性变更引擎再修改 system-spec，不直接让自然语言搜索替换源码。
2. **变更影响分析**：自动输出 `CHANGE_PLAN.md`、`CHANGE_IMPACT.json`、`CHANGE_IMPACT_REPORT.md`，复用 2.7 upgrade diff 并增加依赖扫描、风险分级和能力物化等级。
3. **源项目默认不可变**：所有变更先生成候选副本；生成失败不留下半成品，也不改原项目。
4. **项目版本历史**：新增 `CHANGE_HISTORY.json`，记录用户原话、结构化操作、风险、来源版本与目标版本。
5. **变更后测试重新归零**：候选版本不能继承旧 E2E 证据；strict 对连续变更候选增加专门门禁。
6. **角色/对象权限种子**：生成 schema 保留 roles/permissions，并把明确的对象级 `view/create/edit/delete/import/export` 权限种入 RBAC。
7. **非破坏式逻辑回滚**：新增 `rollback` 命令，用升级前规格创建回滚副本，不以删除数据库列换取表面上的“完全还原”。
8. **3.0 规格模板**：`system-spec` 新增 `change_management`，交付状态新增连续变更和回滚证据字段。

## 兼容性

- 保留 2.7.0 的 `analyze / scaffold / generate / test / validate / upgrade / diagnose / package` 全部入口。
- `upgrade` 仍可供技术人员直接用“新 system-spec”升级；业务用户的常规后续修改优先走 `change`。
- 最终交付格式没有被推翻，而是在项目中新增变更计划、影响报告和历史链路。

## 重要边界

3.0 的自然语言理解由执行本技能的 AI 完成，脚本只执行结构化、可审计的变更请求。工作流、数据范围权限和报表如果缺少关键业务事实，必须进入 `unresolved` 或待物化状态，不能因为“大版本”而降低证据标准。
