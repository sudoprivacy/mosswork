# 图1式六编号目录交付规范

## 1. 强制根目录

最终 ZIP 解压后必须只有一个系统根目录。点工业务使用以下名称，不得把服务端源码或报告散放根目录：

```text
<系统名称_局域网完整包>/
├── 01_服务端_完整程序/
├── 02_Windows填写客户端/
├── 03_macOS填写客户端/
├── 04_原始点工表参考/
├── 05_申请单电子档模板/
├── 06_说明与版本记录/
├── 点工系统用户密码.rtf
├── 一键启动_macOS.command
├── 一键启动_Windows.bat
├── 一键启动_Windows.vbs
├── 一键停止_macOS.command
├── 一键停止_Windows.bat
└── 一键停止_Windows.vbs
```

非点工业务仍使用相同六段结构，但第04目录改为 `04_原始业务表参考`，密码说明改为 `<系统名称>_用户密码.rtf`。

## 2. 目录职责

### 01_服务端_完整程序

放置完整第一方 Python 源码、`templates/`、`static/`、`data/`、数据库迁移、导入导出、备份恢复、服务端成对启停、诊断、目标电脑验收、EXE 构建源码和依赖。根目录启停文件只能调用这里的项目专属入口。

### 02_Windows填写客户端

至少包含：

- `server_url.txt`；
- `<系统名称>_Windows.vbs`；
- `设置服务器地址_Windows.vbs`；
- `测试服务器连接_Windows.vbs`；
- `Windows客户端使用说明.txt`。

客户端负责打开局域网填写页面，不复制数据库，不在客户机存放管理员凭据。

### 03_macOS填写客户端

至少包含系统客户端、设置服务器地址、测试服务器连接三个 `.app` 目录，配套 `server_url.txt` 和使用说明。每个 `.app` 必须有 `Contents/Info.plist` 和 `Contents/MacOS/` 入口。未在 macOS 真机验证时必须标记 `macos_client_runtime_verified=false`，不能宣称已验证。

### 04_原始点工表参考 / 04_原始业务表参考

放置用于识别字段、公式、工作表结构、打印版式和历史兼容的经授权原始表或脱敏参考件。不得放入密码、令牌、私钥或无授权敏感个人信息。不能打包原件时，保留说明并在交付状态中记录原因和影响。

### 05_申请单电子档模板

放置请假、加班、审批、申请等电子模板。没有对应业务时保留说明文件，并在 `DELIVERY_STATUS.json` 标记“不适用”，不得留空目录。

### 06_说明与版本记录

固定包含：

```text
06_说明与版本记录/
├── 00_当前版本/
├── 01_使用与部署说明/
├── 02_更新说明/
├── 03_校验与哈希/
└── 04_历史资料/
```

- `00_当前版本/`：`system-spec.json`、`input-profile.json`、`business-profile.json`、映射、冲突、假设、数据质量、`DELIVERY_STATUS.json`；
- `01_使用与部署说明/`：交付导航、运行说明、EXE说明、备份恢复、目标电脑验收；
- `02_更新说明/`：本次功能、修复和迁移说明；
- `03_校验与哈希/`：`TEST_REPORT.md`、`PY_SOURCE_MANIFEST.json`、`FILES_SHA256.txt`、`delivery-manifest.json`、独立解压验证证据；
- `04_历史资料/`：旧版本说明、数据库迁移映射和历史快照。

## 3. 密码说明

密码 RTF 不能包含通用固定密码。首次启动时由服务端生成随机管理员密码，凭据写入 `01_服务端_完整程序/data/首次管理员凭据.txt`，首次登录后强制修改并删除临时凭据。根目录 RTF 只说明查找位置和安全要求。

## 4. 生成和验收

从零生成时运行：

```bash
python scripts/create_project_scaffold.py \
  --spec system-spec.json \
  --output <系统完整包目录> \
  --source-materials <当前材料目录>
```

业务实现完成后运行：

```bash
python scripts/validate_local_bundle.py <系统完整包目录> --strict
python scripts/validate_delivery.py <系统完整包目录> --strict
```

最终 ZIP 必须重新解压到全新目录再重复严格检查。任一必需目录、客户端、根目录入口、服务端源码或正式报告缺失时，交付结论必须为“不通过”，不得只用说明文件掩盖缺失的实际功能。
