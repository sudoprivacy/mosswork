#!/usr/bin/env python3
"""Append reusable production memory for future video-text-production runs."""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path


DEFAULT_MEMORY = Path.home() / ".codex" / "automations" / "video-text-production" / "memory.jsonl"


def split_csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def main() -> int:
    parser = argparse.ArgumentParser(description="Record video production memory.")
    parser.add_argument("--memory-path", type=Path, default=DEFAULT_MEMORY)
    parser.add_argument("--project", required=True)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--input-profile", required=True)
    parser.add_argument("--content-type", default="")
    parser.add_argument("--outputs", default="")
    parser.add_argument("--style", default="")
    parser.add_argument("--lessons", default="")
    parser.add_argument("--blockers", default="")
    args = parser.parse_args()

    entry = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "cwd": os.getcwd(),
        "project": args.project,
        "summary": args.summary,
        "input_profile": args.input_profile,
        "content_type": args.content_type,
        "outputs": split_csv(args.outputs),
        "style": args.style,
        "lessons": split_csv(args.lessons),
        "blockers": split_csv(args.blockers),
    }

    args.memory_path.parent.mkdir(parents=True, exist_ok=True)
    with args.memory_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False) + "\n")

    print(f"制作记忆已生成：{args.memory_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
