#!/usr/bin/env python3
"""Choose a conservative subtitle style from slide/frame images."""

from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path

try:
    from PIL import Image, ImageFilter, ImageStat
except ImportError as exc:  # pragma: no cover - environment dependent
    raise SystemExit("Pillow is required: python3 -m pip install pillow") from exc


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"}


def image_files(slides_dir: Path) -> list[Path]:
    return sorted(p for p in slides_dir.rglob("*") if p.suffix.lower() in IMAGE_SUFFIXES)


def band_stats(image: Image.Image, band: str) -> dict[str, float]:
    width, height = image.size
    if band == "top":
        box = (0, 0, width, height // 3)
    elif band == "middle":
        box = (0, height // 3, width, (height * 2) // 3)
    else:
        box = (0, (height * 2) // 3, width, height)

    crop = image.crop(box).convert("L").resize((320, 180))
    brightness = ImageStat.Stat(crop).mean[0]
    edge = crop.filter(ImageFilter.FIND_EDGES)
    edge_density = ImageStat.Stat(edge).mean[0]
    return {"brightness": float(brightness), "edge_density": float(edge_density)}


def choose_position(samples: list[dict[str, dict[str, float]]]) -> str:
    scores: dict[str, float] = {}
    for band in ["bottom", "top", "middle"]:
        edges = [sample[band]["edge_density"] for sample in samples]
        scores[band] = statistics.mean(edges)
    return min(scores, key=scores.get)


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze slides and emit subtitle style JSON.")
    parser.add_argument("--slides", required=True, type=Path, help="Directory of slide/frame images")
    parser.add_argument("--out", required=True, type=Path, help="Output JSON path")
    parser.add_argument("--width", type=int, default=1920, help="Target video width")
    parser.add_argument("--height", type=int, default=1080, help="Target video height")
    args = parser.parse_args()

    files = image_files(args.slides)
    if not files:
        raise SystemExit(f"No image files found in {args.slides}")

    sample_indices = sorted(set([0, len(files) // 2, len(files) - 1]))
    samples: list[dict[str, dict[str, float]]] = []
    for index in sample_indices:
        with Image.open(files[index]) as image:
            image = image.convert("RGB")
            samples.append({band: band_stats(image, band) for band in ["top", "middle", "bottom"]})

    position = choose_position(samples)
    all_brightness = [sample[position]["brightness"] for sample in samples]
    brightness = statistics.mean(all_brightness)

    light_background = brightness > 168
    font_size = 58 if args.width >= args.height else 64
    margin_v = 72 if position == "bottom" else 64

    style = {
        "target": {"width": args.width, "height": args.height, "fps": 30},
        "position": position,
        "ass_alignment": {"bottom": 2, "top": 8, "middle": 5}[position],
        "font_name": "PingFang SC",
        "font_size": font_size,
        "primary_colour": "&H00222222" if light_background else "&H00FFFFFF",
        "outline_colour": "&H00FFFFFF" if light_background else "&H00000000",
        "back_colour": "&H66000000" if not light_background else "&H44FFFFFF",
        "outline": 2 if light_background else 3,
        "shadow": 0 if light_background else 1,
        "margin_l": 96,
        "margin_r": 96,
        "margin_v": margin_v,
        "basis": {
            "sampled_files": [str(files[i]) for i in sample_indices],
            "band_stats": samples,
            "rationale": "Chose the lowest edge-density safe band and high-contrast subtitle colors.",
        },
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(style, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(str(args.out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
