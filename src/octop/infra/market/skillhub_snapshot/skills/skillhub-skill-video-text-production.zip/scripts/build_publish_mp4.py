#!/usr/bin/env python3
"""Render a publishable MP4 from slide images, audio, SRT, and subtitle style."""

from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import NamedTuple

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:  # pragma: no cover - checked only when fallback is needed
    Image = None
    ImageDraw = None
    ImageFont = None


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"}
FONT_CANDIDATES = [
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/STHeiti Light.ttc",
    "/Library/Fonts/Arial Unicode.ttf",
    "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
]


class SubtitleEvent(NamedTuple):
    start: float
    end: float
    text: str


def run_json(command: list[str]) -> dict:
    output = subprocess.check_output(command, text=True)
    return json.loads(output)


def ffprobe_duration(path: Path) -> float | None:
    try:
        data = run_json(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "json",
                str(path),
            ]
        )
        return float(data["format"]["duration"])
    except Exception:
        return None


def slide_files(slides_dir: Path) -> list[Path]:
    return sorted(p for p in slides_dir.rglob("*") if p.suffix.lower() in IMAGE_SUFFIXES)


def ffmpeg_filter_available(name: str) -> bool:
    try:
        output = subprocess.check_output(["ffmpeg", "-hide_banner", "-filters"], text=True, stderr=subprocess.STDOUT)
    except Exception:
        return False
    return any(line.split() and line.split()[-1] == name for line in output.splitlines())


def ass_force_style(style: dict) -> str:
    keys = {
        "font_name": "FontName",
        "font_size": "FontSize",
        "primary_colour": "PrimaryColour",
        "outline_colour": "OutlineColour",
        "back_colour": "BackColour",
        "outline": "Outline",
        "shadow": "Shadow",
        "ass_alignment": "Alignment",
        "margin_l": "MarginL",
        "margin_r": "MarginR",
        "margin_v": "MarginV",
    }
    return ",".join(f"{ass_key}={style[key]}" for key, ass_key in keys.items() if key in style)


def filter_escape(path: Path) -> str:
    return str(path.resolve()).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")


def option_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'").replace(",", "\\,").replace(":", "\\:")


def parse_srt_time(value: str) -> float:
    hours, minutes, rest = value.strip().replace(",", ".").split(":")
    seconds = float(rest)
    return int(hours) * 3600 + int(minutes) * 60 + seconds


def parse_srt(path: Path) -> list[SubtitleEvent]:
    text = path.read_text(encoding="utf-8-sig")
    blocks = [block.strip() for block in text.replace("\r\n", "\n").replace("\r", "\n").split("\n\n") if block.strip()]
    events: list[SubtitleEvent] = []
    for block in blocks:
        lines = block.splitlines()
        timing_index = next((i for i, line in enumerate(lines) if "-->" in line), None)
        if timing_index is None:
            continue
        start_text, end_text = [part.strip().split()[0] for part in lines[timing_index].split("-->", 1)]
        caption = "\n".join(line.strip() for line in lines[timing_index + 1 :] if line.strip())
        if caption:
            events.append(SubtitleEvent(parse_srt_time(start_text), parse_srt_time(end_text), caption))
    return events


def ass_color(value: str | None, default: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    if not value or not value.startswith("&H"):
        return default
    raw = value[2:].rjust(8, "0")[-8:]
    alpha = 255 - int(raw[0:2], 16)
    blue = int(raw[2:4], 16)
    green = int(raw[4:6], 16)
    red = int(raw[6:8], 16)
    return red, green, blue, alpha


def find_font(size: int):
    if ImageFont is None:
        return None
    for candidate in FONT_CANDIDATES:
        if Path(candidate).exists():
            try:
                return ImageFont.truetype(candidate, size)
            except Exception:
                pass
    return ImageFont.load_default()


def text_size(draw, text: str, font) -> tuple[int, int]:
    box = draw.multiline_textbbox((0, 0), text, font=font, spacing=8, stroke_width=0)
    return box[2] - box[0], box[3] - box[1]


def wrap_caption(draw, text: str, font, max_width: int) -> str:
    wrapped: list[str] = []
    for source_line in text.splitlines():
        line = ""
        for char in source_line:
            trial = line + char
            if line and text_size(draw, trial, font)[0] > max_width:
                wrapped.append(line)
                line = char
            else:
                line = trial
        if line:
            wrapped.append(line)
    return "\n".join(wrapped[:2])


def scaled_canvas(slide: Path, width: int, height: int):
    if Image is None:
        raise SystemExit("Pillow is required for subtitle burn-in fallback: python3 -m pip install pillow")
    with Image.open(slide) as src:
        src = src.convert("RGB")
        src.thumbnail((width, height), Image.Resampling.LANCZOS)
        canvas = Image.new("RGB", (width, height), (0, 0, 0))
        canvas.paste(src, ((width - src.width) // 2, (height - src.height) // 2))
        return canvas


def render_baked_frame(slide: Path, caption: str, style: dict, out: Path, width: int, height: int) -> None:
    image = scaled_canvas(slide, width, height).convert("RGBA")
    draw = ImageDraw.Draw(image)
    font_size = int(style.get("font_size", 58))
    font = find_font(font_size)
    max_width = width - int(style.get("margin_l", 96)) - int(style.get("margin_r", 96))
    caption = wrap_caption(draw, caption, font, max_width) if caption else ""

    if caption:
        text_w, text_h = text_size(draw, caption, font)
        margin_v = int(style.get("margin_v", 72))
        alignment = int(style.get("ass_alignment", 2))
        x = (width - text_w) // 2
        if alignment == 8:
            y = margin_v
        elif alignment == 5:
            y = (height - text_h) // 2
        else:
            y = height - margin_v - text_h

        padding_x = 28
        padding_y = 18
        background = ass_color(style.get("back_colour"), (0, 0, 0, 110))
        rect = (x - padding_x, y - padding_y, x + text_w + padding_x, y + text_h + padding_y)
        draw.rounded_rectangle(rect, radius=14, fill=background)
        draw.multiline_text(
            (x, y),
            caption,
            font=font,
            fill=ass_color(style.get("primary_colour"), (255, 255, 255, 255)),
            spacing=8,
            align="center",
            stroke_width=int(style.get("outline", 2)),
            stroke_fill=ass_color(style.get("outline_colour"), (0, 0, 0, 255)),
        )

    image.convert("RGB").save(out)


def active_caption(events: list[SubtitleEvent], timestamp: float) -> str:
    for event in events:
        if event.start <= timestamp < event.end:
            return event.text
    return ""


def bake_subtitle_segments(
    slides: list[Path],
    duration: float,
    events: list[SubtitleEvent],
    style: dict,
    tmp_dir: Path,
    width: int,
    height: int,
    audio_duration: float | None,
) -> list[tuple[Path, float]]:
    total = max(len(slides) * duration, max((event.end for event in events), default=0.0), audio_duration or 0.0)
    boundaries = {0.0, total}
    boundaries.update(min(total, i * duration) for i in range(1, len(slides) + 1))
    for event in events:
        if 0 <= event.start <= total:
            boundaries.add(event.start)
        if 0 <= event.end <= total:
            boundaries.add(event.end)
    ordered = sorted(boundaries)

    segments: list[tuple[Path, float]] = []
    for index, (start, end) in enumerate(zip(ordered, ordered[1:]), start=1):
        segment_duration = end - start
        if segment_duration <= 0.001:
            continue
        midpoint = start + min(segment_duration / 2, 0.01)
        slide_index = min(int(midpoint // duration), len(slides) - 1)
        caption = active_caption(events, midpoint)
        frame_path = tmp_dir / f"frame-{index:04d}.png"
        render_baked_frame(slides[slide_index], caption, style, frame_path, width, height)
        segments.append((frame_path, segment_duration))
    return segments


def main() -> int:
    parser = argparse.ArgumentParser(description="Build publish.mp4 for courseware video packages.")
    parser.add_argument("--slides-dir", required=True, type=Path)
    parser.add_argument("--audio", type=Path)
    parser.add_argument("--srt", type=Path)
    parser.add_argument("--style-json", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--duration-per-slide", type=float, default=None)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--width", type=int, default=1920)
    parser.add_argument("--height", type=int, default=1080)
    args = parser.parse_args()

    slides = slide_files(args.slides_dir)
    if not slides:
        raise SystemExit(f"No slide images found in {args.slides_dir}")

    audio_duration = ffprobe_duration(args.audio) if args.audio and args.audio.exists() else None
    duration = args.duration_per_slide
    if duration is None:
        duration = max(2.0, (audio_duration / len(slides)) if audio_duration else 4.0)

    args.out.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)
        style = {}
        if args.style_json and args.style_json.exists():
            style = json.loads(args.style_json.read_text(encoding="utf-8"))

        use_subtitles_filter = bool(args.srt and args.srt.exists() and ffmpeg_filter_available("subtitles"))
        segments: list[tuple[Path, float]]
        if args.srt and args.srt.exists() and not use_subtitles_filter:
            events = parse_srt(args.srt)
            segments = bake_subtitle_segments(
                slides,
                duration,
                events,
                style,
                tmp_dir,
                args.width,
                args.height,
                audio_duration,
            )
            vf_parts = ["format=yuv420p"]
        else:
            segments = [(slide, duration) for slide in slides]
            vf_parts = [
                f"scale={args.width}:{args.height}:force_original_aspect_ratio=decrease",
                f"pad={args.width}:{args.height}:(ow-iw)/2:(oh-ih)/2",
                "format=yuv420p",
            ]

        concat_path = Path(tmp) / "slides.txt"
        lines: list[str] = []
        for slide, segment_duration in segments:
            lines.append(f"file {shlex.quote(str(slide.resolve()))}")
            lines.append(f"duration {segment_duration:.3f}")
        lines.append(f"file {shlex.quote(str(segments[-1][0].resolve()))}")
        concat_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

        if args.srt and args.srt.exists() and use_subtitles_filter:
            force_style = ass_force_style(style)
            subtitle_filter = f"subtitles=filename='{filter_escape(args.srt)}'"
            if force_style:
                subtitle_filter += f":force_style='{option_escape(force_style)}'"
            vf_parts.append(subtitle_filter)

        command = [
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat_path),
        ]

        if args.audio and args.audio.exists():
            command.extend(["-i", str(args.audio)])

        command.extend(
            [
                "-vf",
                ",".join(vf_parts),
                "-r",
                str(args.fps),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
            ]
        )

        if args.audio and args.audio.exists():
            command.extend(["-c:a", "aac", "-b:a", "192k", "-shortest"])

        command.append(str(args.out))
        subprocess.run(command, check=True)

    print(str(args.out))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
