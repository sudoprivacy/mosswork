#!/usr/bin/env python3
"""Classify local files for the video-text-production skill."""

from __future__ import annotations

import argparse
import json
import mimetypes
from pathlib import Path


CATEGORIES = {
    "deck": {".ppt", ".pptx", ".key"},
    "pdf": {".pdf"},
    "audio": {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"},
    "script": {".txt", ".md", ".docx", ".srt", ".vtt"},
    "video": {".mp4", ".mov", ".m4v", ".mkv", ".webm"},
    "image": {".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"},
}


def classify(path: Path) -> str:
    suffix = path.suffix.lower()
    for category, suffixes in CATEGORIES.items():
        if suffix in suffixes:
            return category
    return "source"


def iter_files(paths: list[Path]) -> list[Path]:
    files: list[Path] = []
    for path in paths:
        if path.is_dir():
            files.extend(p for p in path.rglob("*") if p.is_file())
        elif path.is_file():
            files.append(path)
    return sorted(files, key=lambda p: str(p).lower())


def main() -> int:
    parser = argparse.ArgumentParser(description="Classify video production input files.")
    parser.add_argument("paths", nargs="+", type=Path, help="Input files or folders")
    parser.add_argument("--json", dest="json_out", action="store_true", help="Emit JSON only")
    args = parser.parse_args()

    buckets: dict[str, list[dict[str, object]]] = {
        key: [] for key in ["deck", "pdf", "audio", "script", "video", "image", "source"]
    }

    for file_path in iter_files(args.paths):
        category = classify(file_path)
        mime, _ = mimetypes.guess_type(str(file_path))
        buckets[category].append(
            {
                "path": str(file_path.resolve()),
                "name": file_path.name,
                "suffix": file_path.suffix.lower(),
                "size_bytes": file_path.stat().st_size,
                "mime": mime,
            }
        )

    recommendations: list[str] = []
    if buckets["deck"] and buckets["pdf"]:
        recommendations.append("Use an adjacent PDF for stable slide rendering when it matches the deck.")
    if buckets["deck"] and not buckets["pdf"]:
        recommendations.append("Convert the deck to PDF before rendering slide images.")
    if buckets["video"] and not (buckets["deck"] or buckets["pdf"]):
        recommendations.append("Ask the user to confirm clip order unless filenames clearly encode order.")
    if buckets["audio"] and not buckets["script"]:
        recommendations.append("Transcribe or request a spoken script before final subtitle generation.")
    if (buckets["deck"] or buckets["pdf"]) and buckets["audio"] and buckets["script"]:
        recommendations.append("Proceed with courseware package generation: FCPXML, SRT, plan, report, and MP4.")

    result = {"inputs": buckets, "recommendations": recommendations}

    if args.json_out:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
