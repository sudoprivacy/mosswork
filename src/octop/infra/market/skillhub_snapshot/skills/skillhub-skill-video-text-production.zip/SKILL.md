---
name: skillhub-skill-video-text-production
description: "Generate Chinese short-video text assets and assemble courseware/video production packages. Use when Codex needs to audit a user draft before rewriting, split a script into audience-facing issues and idea directions, produce or refine narration, titles, semantic shot splitting, image prompts, deterministic subtitle splitting, PPT/PDF/audio/script-to-video packaging, Final Cut Pro/FCPXML project pa"
---

# Video Text Production

Use this skill to turn a topic, source material, PPT/PDF courseware, voiceover, or draft script into a stable video-production pipeline.

Keep the workflow deterministic where possible. Use prompts for creative steps such as narration, titles, semantic split, image prompts, and style rationale. Use fixed rules and scripts for file inventory, subtitle slicing, memory writing, and MP4 rendering.

## Source And Dependency Transparency

This skill package contains instructions, references, and local helper scripts only. It does not bundle the user's raw PPT/PDF/audio/video/image files, API keys, model credentials, Remotion/Hyperframes projects, node modules, or external platform accounts.

When producing a video package or handoff plan, distinguish:

- **User-provided raw inputs**: files, pasted text, scripts, audio, decks, images, videos, and existing project folders supplied in the current task.
- **Bundled skill resources**: `SKILL.md`, `references/`, `scripts/`, and `agents/openai.yaml`.
- **Local tool dependencies**: Python, Pillow, ffmpeg/ffprobe, office/PDF conversion tools, Final Cut Pro, or other tools available in the target environment.
- **External runtimes/APIs**: OpenAI or other model APIs, TTS APIs, transcription APIs, Remotion/Pujer/P5J/Hyperframes platforms, and any user-connected services. Use them only when available in the user's environment and never imply credentials are bundled.

Read [references/source-and-dependency-transparency.md](./references/source-and-dependency-transparency.md) when a task needs provenance notes, API/dependency disclosure, generation-report wording, or upload/package safety checks.

## Animation Runtime And Component Notice

This skill does not bundle a complete Remotion project, Hyperframes project, Pujer/P5J/p5.js component library, motion component pack, or hosted rendering platform. When a user asks to make animations or identify where animation is needed, first check whether the target workspace or platform already has the required runtime, components, and render command.

If those dependencies are missing, be explicit: deliver an animation plan, component manifest, install/setup checklist, and integration notes, but do not claim the animation can be rendered or used directly. If the user provides an existing animation project, inspect it and work with its components instead of inventing unavailable ones.

Read [references/animation-runtime-requirements.md](./references/animation-runtime-requirements.md) for dependency checks, user-facing notices, and fallback output shapes.

## Select Mode

Choose the smallest mode that satisfies the user:

- **Draft audit and idea divergence**: When the user provides a draft, article rewrite, script, transcript, SRT, or rough idea and wants feedback, first split and audit the source, give audience-facing suggestions, then proceed to rewriting or production planning only after the direction is clear.
- **Text assets only**: Produce narration, titles, `cut_text`, image prompts, or subtitle-ready text.
- **Courseware package**: Convert PPT/PDF + voiceover + script into a reusable production package with FCPXML, SRT, plan, report, source archive, and publishable MP4.
- **Animation planning**: When the user asks where to add animation or wants animated output, check whether Remotion/Hyperframes/Pujer/P5J/p5.js/motion components are available. If not, produce the animation blueprint and dependency checklist rather than promising a render.
- **Existing video assembly**: Combine user-provided MP4/video files. Ask for order when filenames, timestamps, or user instructions do not make the sequence obvious.

## Draft Audit And Idea Divergence Workflow

When the user uploads or pastes a draft and asks for rewriting, polishing, content ideas, script adaptation, or "what should we do next", do not rewrite immediately unless the user explicitly says to skip review.

Use this order:

1. Read the source first. For local files, inspect the actual contents before judging.
2. Split the source into logical blocks: hook/opening, setup, core claim, evidence/example, payoff, CTA, and redundant or empty lines.
3. Judge content quality, hook strength, and audience benefit from the target viewer's point of view.
4. Give concise suggestions before the next production step: keep/delete/move earlier/add one line.
5. Offer 2-4 divergence directions only when useful, such as stronger hook angle, sharper audience pain, more commercial implication, more concrete example, or different video structure.
6. Ask for direction when the next step depends on creative choice. If the user already gave a clear goal, continue into narration, `cut_text`, image prompts, subtitles, or package planning.

Read [references/script-audience-divergence.md](./references/script-audience-divergence.md) for the full audit format, scoring dimensions, hook rules, audience-perspective questions, and replacement-line guidance.

## Courseware Package Workflow

When the user provides a PPT/PDF, audio file, spoken script, or asks for Final Cut Pro/MP4 output, follow this order:

1. Inventory inputs before editing or rendering. Run `scripts/inspect_inputs.py <task-folder-or-files...>` when files are local.
2. Classify each input as deck, rendered PDF, audio, script/transcript, video clip, image, or supporting source.
3. If the user provides PPT/PPTX/Keynote, prefer an adjacent exported PDF when present; otherwise convert the deck to PDF before slide rendering. If conversion fails, preserve the deck and report the blocker.
4. If the user provides MP4/video clips without a deck, ask how to order clips unless the user gives an explicit order or filenames clearly encode order.
5. Render deck/PDF pages to slide images, then create `timeline_plan.json` from slide count, audio duration, and script/subtitle segments.
6. Generate `subtitles_short.srt` with the deterministic subtitle rules below.
7. Analyze slide/frame visuals for subtitle placement and styling. Run `scripts/analyze_subtitle_style.py --slides <slides-dir> --out subtitle_style.json` when slide images are available.
8. Build the editable package first: `timeline.fcpxml`, `subtitles_short.srt`, `timeline_plan.json`, `generation_report.md`, `README.txt`, `media/slides`, `media/voice`, and `source`.
9. Build the publishable MP4 with ffmpeg. Prefer `scripts/build_publish_mp4.py` when slide images, audio, SRT, and style JSON are available.
10. Append a reusable production memory with `scripts/record_production_memory.py` after a successful or meaningfully partial run, and tell the user the memory was generated.

Read [references/courseware-video-packaging.md](./references/courseware-video-packaging.md) for the full package contract, MP4 rendering rules, subtitle style heuristics, and memory schema.

## Text Asset Workflow

For text-only requests, follow this order unless the user explicitly asks for only one step:

1. Generate the narration script.
2. Extract the large title and small title from the final narration.
3. Split the narration into semantic `cut_text` units for shots.
4. Generate one image prompt per `cut_text`.
5. Split narration or `cut_text` into subtitle-sized caption units with deterministic rules.

If the user already provides a final narration, skip narration generation and start from titles or splitting.

## Inputs

Collect only the minimum needed:

- Topic or business question
- Optional source material, transcript, notes, or article
- Optional rough draft, SRT, article-to-script rewrite, voice-over script, or video script for audit before rewriting
- Optional PPT/PPTX/Keynote/PDF courseware
- Optional audio voiceover
- Optional MP4/video clips
- Optional animation runtime, Remotion/Hyperframes project, Pujer/P5J/p5.js component library, motion components, or platform-specific animation package
- Intended audience
- Tone or creator persona
- Optional target duration

If inputs are weak, still produce a strong first draft instead of blocking.

## Prompt Resources

Read [references/prompt-templates.md](./references/prompt-templates.md) when you need the exact reusable prompt bodies for:

- Draft audit and idea divergence follow-up rewrites
- Narration generation
- Large and small title generation
- Semantic shot splitting into `cut_text`
- Image prompt generation from `cut_text`

Reuse those prompts with light adaptation. Preserve the user’s original creator voice if one is already established.

## Subtitle Rules

Do not treat subtitle slicing as a creative prompt unless the user explicitly asks for stylistic rewriting.

Use deterministic rules:

- Keep original wording and order.
- Split by semantic pauses first, then punctuation, then length.
- Keep each subtitle short enough for mobile reading.
- Avoid breaking a phrase in the middle when a natural pause exists.
- Keep each subtitle unit readable in one glance.
- Ensure subtitle order matches narration exactly.

When timing is not provided, output plain ordered subtitle units. When timing is provided or estimated, preserve alignment with the source narration segment.

## Subtitle Style Matching

For MP4 exports, choose subtitle styling from the actual slides or sampled frames:

- Inspect the first, middle, and last pages, plus any dense pages.
- Prefer bottom-center subtitles when the lower third is visually quiet.
- Move subtitles to top-center when the bottom third contains key charts, UI, or logos.
- Use white text with dark stroke/shadow on dark or mixed slides; use near-black text with translucent light backing on light slides.
- Keep subtitles inside title/action safe areas and avoid covering faces, charts, tables, logos, and primary callouts.
- For 16:9 output, start near 48-64 px text at 1920x1080; for 9:16 output, start near 54-72 px text at 1080x1920. Adjust down for long Chinese lines.
- Save decisions in `subtitle_style.json` and cite the visual basis in `generation_report.md`.

## Output Shape

Prefer explicit structured output when handling multiple steps:

```json
{
  "narration": "full narration",
  "title_large": "large title",
  "title_small": "small title",
  "cut_text": ["shot text 1", "shot text 2"],
  "cut_text_image": ["image prompt 1", "image prompt 2"],
  "captions": ["caption 1", "caption 2"]
}
```

For courseware packaging, prefer this directory shape:

```text
output/
├── publish.mp4
├── timeline.fcpxml
├── subtitles_short.srt
├── subtitle_style.json
├── timeline_plan.json
├── generation_report.md
├── README.txt
├── media/
│   ├── slides/
│   └── voice/
└── source/
```

If the user asks for only one artifact, output only that artifact.

## Quality Bar

Check before returning:

- Draft audit comes before rewriting when the user gave source text and did not explicitly ask to skip critique.
- Audience benefit is concrete: decision shortcut, practical action, warning, talking point, emotional validation, or a clearer reason to watch.
- The narration sounds like a creator with judgment, not an assistant.
- Titles are derived from the narration rather than inventing unrelated concepts.
- `cut_text` count follows the requested range if one is specified.
- `cut_text` and `cut_text_image` counts match exactly.
- Subtitle splitting is readable and does not distort meaning.
- Animation output is labeled correctly: renderable only when the required runtime, components, assets, and render command are present and verified.
- Source/dependency notes are explicit when external files, APIs, model services, TTS/transcription tools, Remotion/Hyperframes runtimes, or user-provided assets influence the output.
- `timeline.fcpxml` remains editable in Final Cut Pro and does not replace the human review step.
- `publish.mp4` plays locally, has audible audio when audio was provided, and has readable subtitles.
- `generation_report.md` records file inventory, conversion/rendering steps, subtitle count, MP4 path, memory status, and any blockers.
- Production memory summarizes the reusable lesson without storing raw user files or long transcripts.

## Boundaries

Do not:

- Add meta commentary like “下面是” or “让我分析”.
- Output Markdown headings inside the actual generated copy unless the user asks.
- Invent concepts that are absent from the narration when generating titles.
- Rewrite a user's draft immediately when the request calls for review, divergence, or audience judgment first.
- Turn subtitle splitting into freeform rewriting.
- Claim an animation, Remotion/Hyperframes render, Pujer/P5J component output, or motion package is usable unless the target components and runtime are present or bundled.
- Embed Remotion/Hyperframes-only metadata directly into FCPXML or MP4 in a way that could break opening/import. Keep animation specs in sidecar manifests or separate project folders unless the target format explicitly supports them.
- Claim an MP4, FCPXML, or memory was created unless the file write actually succeeded.
- Auto-concatenate unrelated MP4 clips when the intended order is ambiguous.
