# Source And Dependency Transparency

Use this reference when producing a generation report, upload summary, package handoff, or SkillHub-facing explanation of where inputs, APIs, tools, and files came from.

## What Is Bundled In This Skill

The skill package contains:

- `SKILL.md`: workflow, mode selection, quality bar, and boundaries.
- `agents/openai.yaml`: UI-facing skill metadata and default prompt.
- `references/`: reusable instructions for prompt templates, courseware packaging, draft/audience audit, animation runtime checks, and source/dependency transparency.
- `scripts/`: local helper scripts for input inspection, subtitle style analysis, MP4 rendering with ffmpeg, and production-memory recording.

The skill package does not contain:

- The user's raw PPT/PDF/audio/video/image files.
- User drafts, transcripts, source documents, or private project folders.
- API keys, tokens, account credentials, cookies, or model provider secrets.
- Remotion/Hyperframes/Pujer/P5J node projects, node modules, hosted render services, or motion component packs.
- Final Cut Pro, ffmpeg, Python, Pillow, office converters, TTS/transcription services, or model runtimes.

## Source Categories To Report

When writing `generation_report.md` or a handoff note, separate sources like this:

```text
来源与依赖说明
- 用户原始输入：列出本次任务实际提供的文件/文本/素材，不复制长原文。
- Skill 内置资源：列出使用的 reference 和 helper script。
- 本地工具依赖：列出 ffmpeg/ffprobe、Python/Pillow、PDF/Office 转换工具、Final Cut Pro 等实际用到或缺失的工具。
- 外部 API/服务：列出实际调用的模型、TTS、转写、图像、云渲染或平台 API；如果没有调用，写“本次未调用外部 API”。
- 动画运行时：列出 Remotion/Hyperframes/Pujer/P5J/motion components 是否由用户提供、是否安装、是否验证渲染命令。
- 阻塞与假设：列出未验证、缺失、需要用户平台继续安装或确认的部分。
```

## API And Credential Rules

- Never claim an API is available unless it is actually configured in the current environment or provided by the user.
- Never store API keys, bearer tokens, cookies, or credential files inside the output package.
- If an external API is used, record provider name, purpose, and output artifact, not the secret value.
- If no API is used, state that clearly.
- If a task relies on a user-connected platform that is not accessible from the current machine, label it as an assumption.

## User Raw Data Rules

- Treat user-provided raw files as task inputs, not reusable skill assets.
- Archive raw sources in an output package only when the workflow explicitly asks for `source/` preservation.
- Do not add raw user files to the SkillHub skill zip.
- Do not write long transcripts, sensitive source text, or private materials into production memory. Summarize reusable lessons only.

## File Handoff Rules

- Keep core outputs format-native and openable: FCPXML as XML, SRT as plain text, JSON as parseable JSON, MP4 as decodable media, zip as valid archive.
- Keep optional animation/runtime metadata in sidecar files or separate project folders.
- Do not make Final Cut Pro project opening depend on Remotion, Hyperframes, Node.js, or platform-specific plugins.
- Validate generated packages before claiming success: zip integrity, XML parse, JSON parse, SRT readability, MP4 decode/playback, and dependency notes.

## Minimal Report Snippet

Use this compact wording when the user needs transparency:

```text
来源与依赖说明：
- 本次用户原始输入：<files/text summary>
- Skill 内置资源：video-text-production/SKILL.md, references/<used>, scripts/<used>
- 本地工具：<ffmpeg/Python/Pillow/etc. used or missing>
- 外部 API：<used provider/purpose>；如无则写“未调用外部 API”
- 动画运行时：<Remotion/Hyperframes/Pujer/P5J present/missing/assumed>
- 重要限制：<what cannot be rendered/opened until user installs/provides dependencies>
```
