# Courseware Video Packaging

Use this reference when a task includes PPT/PDF courseware, voiceover audio, spoken script, FCPXML, MP4 export, subtitle visual matching, file-type detection, or production memory.

## Input Detection

Run:

```bash
python3 scripts/inspect_inputs.py <task-folder-or-files...>
```

Classify files into:

- `deck`: `.ppt`, `.pptx`, `.key`
- `pdf`: `.pdf`
- `audio`: `.mp3`, `.wav`, `.m4a`, `.aac`, `.flac`, `.ogg`
- `script`: `.txt`, `.md`, `.docx`, `.srt`, `.vtt`
- `video`: `.mp4`, `.mov`, `.m4v`, `.mkv`, `.webm`
- `image`: `.png`, `.jpg`, `.jpeg`, `.webp`, `.tif`, `.tiff`
- `source`: anything else that should be preserved

Rules:

- If both a PPT/PPTX and same-name PDF exist, use the PDF for stable rendering and archive the PPT/PPTX in `source/`.
- If only PPT/PPTX exists, convert it to PDF before slide rendering. Use local office tooling when available and report the exact blocker when conversion fails.
- If only MP4/video files exist, ask for clip order unless the user already gave it or filenames clearly encode order (`01-`, `02-`, timestamps, or slide numbers).
- If the user provides the expected demo triplet, PPT/PDF + voiceover + script, proceed without asking extra questions.

## Package Contract

Create a single output folder with:

```text
publish.mp4
timeline.fcpxml
subtitles_short.srt
subtitle_style.json
timeline_plan.json
generation_report.md
README.txt
media/slides/
media/voice/
source/
```

Keep the old promise: the editable Final Cut Pro project remains a primary deliverable. The new MP4 is an added publish/export artifact, not a replacement for the FCPXML package.

## Slide And Timing Plan

Use audio duration when available. If no per-slide timing exists, distribute duration across slides with a minimum readable duration:

- Default slide duration: `audio_duration / slide_count`
- Minimum slide duration: `2.0s`
- Training/explainer content: allow longer static slides when script density is high
- If the script has explicit slide/page markers, align segments to those markers before equal distribution

Write `timeline_plan.json` with:

```json
{
  "output_format": "16:9",
  "fps": 30,
  "slides": [
    {
      "index": 1,
      "file": "media/slides/slide-001.png",
      "start": 0.0,
      "end": 4.2,
      "scene_tags": ["training", "title", "low_detail_bottom"],
      "subtitle_zone": "bottom"
    }
  ],
  "audio": "media/voice/voiceover.wav",
  "subtitles": "subtitles_short.srt"
}
```

## Subtitle Visual Matching

Analyze slide images or sampled video frames before burning subtitles.

Heuristics:

- Prefer `bottom` when the bottom third has low edge density and no important text.
- Use `top` when bottom contains logos, charts, callouts, or UI controls.
- Use `middle` only for title cards or when both top and bottom are occupied.
- On dark/mixed backgrounds, use white text, dark outline, and subtle shadow.
- On bright backgrounds, use near-black text with translucent light backing or strong dark outline.
- Keep Chinese subtitle lines short; use two lines only when a single line would exceed safe width.
- Never cover faces, primary charts, product screenshots, brand marks, or the main slide title.

Run:

```bash
python3 scripts/analyze_subtitle_style.py --slides media/slides --out subtitle_style.json
```

The script returns a conservative style. Override it manually when a visual inspection clearly shows a better placement.

## MP4 Export

Prefer ffmpeg. Render a publishable MP4 from slide images, voiceover audio, SRT, and `subtitle_style.json`:

```bash
python3 scripts/build_publish_mp4.py \
  --slides-dir media/slides \
  --audio media/voice/voiceover.wav \
  --srt subtitles_short.srt \
  --style-json subtitle_style.json \
  --out publish.mp4
```

Validation:

- Run `ffprobe publish.mp4` or `ffmpeg -v error -i publish.mp4 -f null -` to check decode health.
- Confirm duration roughly matches audio when audio is present.
- Confirm subtitles are readable and placed away from important slide content.

If ffmpeg is missing, still deliver the editable package and report that `publish.mp4` is blocked by a missing ffmpeg dependency.

## FCPXML

Generate `timeline.fcpxml` as an editable first cut:

- One timeline/storyline matching the slide order.
- Slide images as separate clips, not flattened into a single video.
- Voiceover as a separate audio asset.
- Subtitles as separate caption/title items where possible, or an external SRT sidecar when full title generation is not supported.
- Use stable relative paths so the whole package folder can move together.

Do not claim Final Cut Pro import success unless it was actually imported or validated.

## Production Memory

After a successful or meaningfully partial run, append a JSONL memory:

```bash
python3 scripts/record_production_memory.py \
  --project "courseware-demo" \
  --summary "Training PPT + voiceover -> FCPXML package and publish.mp4" \
  --input-profile "PPT/PDF + voiceover + spoken script" \
  --content-type "training courseware" \
  --outputs "timeline.fcpxml,publish.mp4,subtitles_short.srt" \
  --style "bottom subtitles, white text, dark stroke" \
  --lessons "Use adjacent PDF when PPTX conversion is fragile"
```

Default memory path:

```text
~/.codex/automations/video-text-production/memory.jsonl
```

Memory rules:

- Store reusable production decisions, not raw files or long transcripts.
- Mention input profile, content type, subtitle style, output paths, blockers, and lessons.
- On the next similar task, inspect recent memory first and reuse matching decisions when appropriate.
- Tell the user: `制作记忆已生成：<path>` after the append succeeds.
