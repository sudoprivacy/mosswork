# Animation Runtime Requirements

Use this reference when the user asks to make animations, decide where animation is needed, generate Remotion/Hyperframes/Pujer/P5J/p5.js plans, use motion components, or prepare high-performance rendering.

## Core Rule

Separate animation planning from animation execution.

This skill can define animation intent, timing, storyboard, component needs, visual prompts, subtitle behavior, and render checks. It can only execute or claim renderable animation when the target environment already contains the required runtime, component library, assets, and render command, or when those resources are explicitly bundled in the task.

## Dependency Check

Before promising animated output, check for:

- Runtime: Node.js project, Remotion setup, Hyperframes project, p5.js/P5J project, Pujer package, or the user's platform-specific animation runtime.
- Components: existing motion components, shared animation templates, scene components, chart components, subtitle components, lower-thirds, CTA components, transitions, and brand assets.
- Install state: `package.json`, lockfile, dependency install instructions, node modules availability, or platform plugin install status.
- Render command: documented commands such as `npm run dev`, `npm run render`, `npx remotion render`, or platform export flow.
- Asset contract: fonts, images, audio, alpha video, transparent overlays, data files, and expected resolution/fps.
- Output target: preview, transparent overlay, social video, courseware scene, final MP4, FCPXML handoff, or component spec only.

If local files are available, inspect them before advising. If the project is on another platform and not accessible, state the dependency assumption.

## User-Facing Notice

When dependencies are missing or unknown, include a short notice near the top:

```text
动画能力提示：当前 skill 包没有内置 Remotion/Hyperframes/Pujer/P5J 组件和渲染环境。下面可以先交付动画方案、组件清单和接入步骤；如果要直接生成可运行动画，需要在目标平台安装/提供对应组件库和渲染命令。
```

Use a softer version when the user only asks for planning:

```text
我先按“可交给动画工程实现”的方式输出：镜头、动效、组件需求、时长和交互/渲染注意点。是否能直接渲染，取决于你那边是否已有 Remotion/Hyperframes/Pujer/P5J 组件。
```

## Output When Components Are Missing

Do not stop. Produce a useful handoff package:

```json
{
  "animation_notice": "runtime/components not bundled",
  "scene_plan": [
    {
      "scene": "opening hook",
      "duration": "0.0-3.5s",
      "animation_intent": "fast reveal of core claim",
      "needed_components": ["TextReveal", "SubtitleTrack", "BackgroundMotion"],
      "fallback_static": "title card with highlighted keyword",
      "assets": ["voiceover", "brand font", "background image"],
      "render_notes": "1080x1920, 30fps, safe title area"
    }
  ],
  "install_or_attach_needed": [
    "Remotion project or equivalent animation runtime",
    "Hyperframes project or export pipeline if required",
    "motion component pack",
    "Pujer/P5J/p5.js generative visual components"
  ],
  "next_step": "install/attach components, then map scene_plan into project files"
}
```

## Output When Components Are Present

If the project and components are present, inspect the codebase and align with it:

- Reuse existing component names and props.
- Avoid inventing components unless the project pattern supports creating them.
- Add or update only the required scenes, data files, captions, and render configuration.
- Run the available dev/render command when feasible.
- Verify output file existence and playback before claiming success.

## Export Safety With Remotion Or Hyperframes

Keep animation integration from breaking the rest of the package:

- Do not inject Remotion/Hyperframes-only fields into `timeline.fcpxml`, SRT, ASS, MP4 metadata, or package files unless the target format explicitly supports them.
- Put animation handoff data in sidecar files such as `animation_manifest.json`, `remotion_scene_plan.json`, `hyperframes_export_notes.md`, or a separate `animation/` project folder.
- Preserve the core package contract: `timeline.fcpxml`, `subtitles_short.srt`, `timeline_plan.json`, `subtitle_style.json`, `publish.mp4`, `media/`, and `source/` should remain openable without animation runtimes.
- If a Remotion/Hyperframes project is included, keep it as an optional folder with its own `package.json`, lockfile, README/export command, and assets. Do not make opening the FCPXML or playing the MP4 depend on Node modules.
- Before reporting success, validate the base package independently from the animation project: zip integrity, XML parse for FCPXML, SRT readability, MP4 decode/playback, and sidecar JSON parse.
- If animation export fails but the base package opens, report a partial success instead of marking the whole package failed.

## Where Animation Is Needed

When the user asks "哪里需要动画", mark animation only where it improves comprehension or attention:

- Hook: fast reveal, contrast, or visual punch in the first 3-8 seconds.
- Transition: move between ideas, steps, before/after, or problem/solution.
- Mechanism: show a process, data flow, automation, comparison, or cause-effect chain.
- Evidence: animate chart, number, screenshot focus, or before/after delta.
- CTA/end: keep brand memory, next action, or reusable tail animation.

Do not animate every line. Use static cards for dense explanation and animation for attention, mechanism, and memory.

## Fallbacks

If animation execution is blocked:

- Provide static storyboard frames or slide directions.
- Provide Remotion/Pujer/P5J component specs.
- Provide Hyperframes scene/export specs.
- Provide p5.js visual prompts or pseudocode.
- Provide transparent overlay requirements for a later editor.
- Provide a checklist for the user's platform: install components, import assets, run preview, render final, inspect subtitles.

Record the blocker in `generation_report.md` when producing a courseware/video package.
