# Script Audience Divergence

Use this reference when the user provides a Chinese or mixed-language draft, article-to-script rewrite, SRT, transcript, voice-over script, video script, or rough idea and wants feedback, polishing, rewriting, or next-step video production.

## Core Rule

Read the source first, then audit it. Do not start by rewriting unless the user explicitly asks for a direct rewrite or says to skip critique.

Use this order:

1. Judge the content quality.
2. Judge whether the hook works.
3. Stand in the target viewer's position and judge what the viewer will feel before, during, and after watching.
4. Split the source into usable blocks and weak blocks.
5. Give the smallest useful fix.
6. Then offer rewrite directions, replacement lines, or the next production step.

## Input Handling

- For pasted text, read the full text before commenting.
- For `.srt`, parse subtitles in order. Ignore timestamps for semantic judgment, but use them to notice slow setup, repeated points, late payoff, or pacing problems.
- For documents, PDFs, Markdown, Word exports, transcripts, and scripts, extract readable text with the best available local tool before auditing.
- For long sources, sample beginning, middle, and end only after reading enough to understand the structure. State the sampling assumption.
- If the target audience is not stated, infer it from topic, wording, and channel. Label the inference. Ask only when audience cannot be reasonably inferred.

## Source Split

Split the draft into these blocks when possible:

- `hook`: the first 3-8 seconds or first 1-3 lines.
- `setup`: background needed before the main claim.
- `core_claim`: the one sentence the viewer should remember.
- `evidence`: concrete fact, example, mechanism, contrast, number, or lived detail.
- `payoff`: why the viewer should care now.
- `cta`: requested action or final turn.
- `weak_lines`: empty transitions, repeated setup, generic summary, self-explanation, and lines that sound like internal notes.

If the draft lacks a block, say so directly instead of inventing one.

## Quality Audit

Score and diagnose these dimensions:

- Core point: can the viewer repeat the main idea in one sentence?
- User relevance: does it connect to a pain, desire, fear, status gain, money, time, efficiency, career, decision, or emotional need the audience already cares about?
- Information density: does each sentence add a new judgment, fact, example, contrast, or consequence?
- Structure: does it move from hook to explanation to payoff without wandering?
- Specificity: does it use concrete people, scenarios, numbers, mechanisms, or before/after contrast instead of abstract claims?
- Credibility: does it give enough evidence, logic, or lived detail for the audience to believe it?
- Rhythm: does the opening arrive fast, and does the payoff come before attention drops?
- Redundancy: which lines are repeated, soft, explanatory, or replaceable?

For short voice-over work, prefer `短、狠、密`: one dominant selling point, strong judgment early, commercial or practical implication, and minimal background.

## Hook Audit

Judge the first 3-8 seconds. A usable hook usually contains at least one of:

- A pain or desire the audience recognizes.
- A counterintuitive judgment.
- A concrete promise: what the viewer will know, avoid, gain, or decide after watching.
- A timely or high-stakes reason to care now.
- A sharp contrast: old way vs new way, common belief vs reality, surface event vs deeper meaning.

Do not call a hook good just because the wording is dramatic. A hook is good only if the right viewer immediately thinks: `这跟我有关`.

## Audience Perspective

Switch from creator perspective to viewer perspective. Answer:

- Who is the likely viewer?
- What does this viewer already care about before watching?
- What will they feel in the first 5 seconds: curious, confused, sold, pressured, bored, skeptical?
- What will they feel after watching: smarter, helped, anxious, inspired, unconvinced, advertised to, or unchanged?
- What exact benefit do they get: decision shortcut, new frame, practical action, warning, talking point, emotional validation, or nothing concrete?
- Where would they swipe away, and why?
- What sentence would they remember or repeat?

Use plain viewer-internal-monologue lines when useful:

```text
观众心里会想：这跟我有什么关系？
观众会觉得：这个点能帮我判断接下来要不要做。
```

## Divergence Directions

After the audit, offer 2-4 next directions only when they are meaningfully different. Examples:

- **痛点前置版**: move the viewer's concrete pain into the first sentence.
- **判断更狠版**: lead with a sharper conclusion or counterintuitive claim.
- **案例驱动版**: open with a scene, user story, or before/after contrast.
- **商业价值版**: tie the topic to cost, revenue, efficiency, conversion, risk, or decision speed.
- **知识密度版**: compress background and add mechanisms, examples, or consequences.
- **情绪共鸣版**: keep the information but make the viewer feel recognized.
- **课程/培训版**: turn the draft into teachable steps, checkpoints, and recap subtitles.
- **程序化视频版**: turn the draft into Remotion/P5J shot plans, timing, visual prompts, and render notes.

Avoid giving too many directions. The goal is to help the user choose the next move, not scatter the task.

## Output Format

Return concise Chinese by default. Start with a blunt verdict:

```text
结论：能发 / 需要小修 / 需要大改 / 先别发
原因：一句话说明最大问题或最大优势。
```

Then use this structure:

```text
1. 文稿拆分
- 钩子：
- 铺垫：
- 核心观点：
- 证据/例子：
- 结果/收益：
- 空句/重复句：

2. 内容质量
- 评分：x/10
- 最大优点：
- 最大问题：
- 哪些句子是空的：

3. 钩子判断
- 开头是否成立：
- 观众为什么会/不会停下：
- 更好的钩子方向：

4. 用户视角
- 目标用户：
- 用户看完会觉得：
- 用户得到的好处：
- 用户可能不买账的地方：

5. 最小改法
- 保留：
- 删除：
- 提前：
- 补一句：

6. 下一步发散方向
- 方向 A：
- 方向 B：
- 方向 C：
```

If the draft is weak, add a short `可直接替换的开头` with 1-3 compact options. If the user already asked for the next artifact and the direction is clear, continue after the audit into narration, `cut_text`, image prompts, subtitles, timeline planning, Remotion/P5J planning, or courseware packaging.

## Style Rules

- Be direct, specific, and useful. Do not comfort the draft.
- Avoid generic comments like `增强吸引力`, `提升感染力`, or `建议更有故事性` unless followed by exact lines and exact fixes.
- Prefer line-level diagnosis over abstract advice.
- Do not summarize the source as the main output. The user needs judgment.
- Do not optimize only for creator intent. Optimize for viewer self-interest.
- If the draft has no clear audience benefit, say so clearly.
- If the topic is valuable but the draft buries it, identify the buried value and move it earlier.
