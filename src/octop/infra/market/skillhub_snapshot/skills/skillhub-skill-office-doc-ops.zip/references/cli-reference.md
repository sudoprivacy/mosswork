# OfficeCLI 完整命令参考

> 本文件是 `officecli` 技能的详细参考。核心流程见 SKILL.md；此处提供全部命令的细节、值格式与边界情况。
> 信息截至 2026-10，来源于官方仓库 README 与官方 agent 技能文档（https://officecli.ai/SKILL.md）。版本差异以 `officecli help` 实时输出为准。

## 1. 安装

| 方式 | 命令 | 平台 |
|------|------|------|
| 一键脚本 | `curl -fsSL https://d.officecli.ai/install.sh \| bash` | macOS / Linux |
| 一键脚本 | `irm https://d.officecli.ai/install.ps1 \| iex` | Windows PowerShell |
| Homebrew | `brew install officecli` | macOS / Linux |
| Scoop | `scoop install officecli` | Windows |
| npm | `npm install -g @officecli/officecli` | 全平台（自动拉取平台原生二进制） |
| 手动下载 | GitHub Releases：`officecli-mac-arm64` / `officecli-mac-x64` / `officecli-linux-x64` / `officecli-linux-arm64` / `officecli-win-x64.exe` / `officecli-win-arm64.exe` | 全平台 |
| 显式安装 | `officecli install`（裸执行 `officecli` 也会触发） | 已下载二进制时 |

- 自包含单二进制，.NET 运行时内嵌；**不需要 Microsoft Office**；headless（CI/Docker/无显示服务器）可运行。
- 源码构建仅编译阶段需要 .NET 10 SDK（`./build.sh`）。
- 配置：`~/.officecli/config.json`；`officecli config autoUpdate false` 关闭自动更新；`OFFICECLI_SKIP_UPDATE=1` 单次跳过。
- 验证安装：`officecli --version`（安装后需新终端刷新 PATH）。

## 2. 命令总览

| 命令 | 用途 |
|------|------|
| `create` | 按扩展名创建空白 .docx/.xlsx/.pptx |
| `view` | 渲染/查看：outline、text、annotated、stats、issues、html、svg、screenshot、pdf、forms |
| `get` | 按路径读取节点（`--depth N` 展开子级，`--json` 结构化） |
| `query` | CSS 风格选择器查询 |
| `set` | 设属性/格式；`--find`/`--replace` 文本查找替换 |
| `add` | 添加元素（`--type`、`--prop`、`--after`/`--before`/`--index`、`--from` 克隆） |
| `remove` | 删除元素 |
| `move` / `swap` | 移动 / 交换元素 |
| `validate` | OpenXML schema 校验 |
| `batch` | 批量执行多命令（默认原子回滚） |
| `dump` / `refresh` | 导出可回放的 JSON 蓝图 / 重算 TOC、页码、交叉引用 |
| `merge` | 模板合并（`{{key}}` 占位符） |
| `import` | CSV 导入 Excel（`--header`） |
| `watch` | 本地 HTTP 实时预览（默认 http://localhost:26315） |
| `open` / `save` / `close` | 常驻模式：载入 / flush 保留 / flush 并释放 |
| `mark` / `unmark` / `get-marks` | watch 内的修改提案（待人工确认后由 set 管线应用） |
| `raw` / `raw-set` / `add-part` | L3 原始 XML 读写 / 新建文档部件 |
| `mcp` | 注册 MCP server（claude/cursor/vscode/lmstudio/opencode/list） |
| `load_skill` | 加载场景化规则技能 |
| `plugins` | 插件管理（扩展 .doc/.hwpx/.pdf 导出） |
| `config` | 配置（如 autoUpdate） |
| `help` | 帮助（≡ `--help`；`officecli help <fmt> <element>` 查 schema） |

## 3. L1 读取与检查

### view 模式

| 模式 | 说明 | 常用参数 |
|------|------|---------|
| `outline` | 文档结构大纲 | — |
| `text` | 纯文本提取 | `--start N --end N`、`--max-lines N`；xlsx 加 `--cols A,B,C` |
| `annotated` | 带格式注释文本 | — |
| `stats` | 统计（页数、字数、形状数） | — |
| `issues` | 格式/内容/结构问题 | `--type format\|content\|structure`、`--limit N` |
| `html` | 静态 HTML 快照（与 watch 同渲染器，无需服务器） | `-o 文件`、`--browser`、`--page N`（docx）、`--start N --end N`（pptx） |
| `screenshot` | 每页 PNG（无头浏览器） | `-o 文件`、`--page N`、`--screenshot-width/-height`；pptx `--grid N` |
| `svg` | SVG（pptx 幻灯片） | `-o 文件` |
| `pdf` / `forms` | PDF 导出 / 表单字段 JSON（需 format-handler 插件） | `-o 文件` |

用法：`officecli view <file> <mode> [-o 输出文件]`。CI 产物、归档、对比用一次性 `html`；需要实时刷新或浏览器点选时用 `watch`。

### get / query

```bash
officecli get report.docx '/body/p[3]' --depth 2 --json
officecli get slides.pptx '/slide[1]' --depth 1          # 列出第 1 页全部形状
officecli get data.xlsx '/Sheet1/B2' --json
officecli get deck.pptx selected --json                  # 读取 watch 中用户点选的元素
officecli query report.docx "paragraph[style=Heading1]" --json
officecli query report.docx "run:contains(TODO)"
```

- 路径为 1 起（XPath 惯例）：`/body/p[3]` = 第 3 段。`--index` 参数 0 起（Excel 的 `add --type row/col` 例外，1 起）。
- 默认文本输出便于 grep：`path (type) "text" key=val ...`。
- 选择器支持属性匹配、`:contains`、`:has()` 等；详见 `officecli help <fmt> query`。

## 4. L2 DOM 操作

### set — 属性与格式

```bash
officecli set <file> <path> --prop key=value [--prop ...]
```

- 任意 XML 属性均可设（含当前不存在的属性）；不带 `find=` 时作用于整个元素。
- **点号别名**：`--prop font.color=red --prop font.bold=true --prop font.size=14pt`（shape/run/paragraph/table/row/cell/section/styles 可用）。

**值格式：**

| 类型 | 格式 | 示例 |
|------|------|------|
| 颜色 | 十六进制（可带 `#`）、命名、RGB、主题色 | `FF0000`、`#FF0000`、`red`、`rgb(255,0,0)`、`accent1`~`accent6` |
| 间距 | 带单位 | `12pt`、`0.5cm`、`1.5x`、`150%` |
| 尺寸 | EMU 或带后缀 | `914400`、`2.54cm`、`1in`、`72pt`、`96px` |

### find / replace — 文本级查找替换

```bash
# 格式化匹配文本（自动拆分 run）
officecli set doc.docx '/body/p[1]' --find weather --prop bold=true --prop color=red
# 正则
officecli set doc.docx '/body/p[1]' --find '\d+%' --prop regex=true --prop color=red
# 全文替换（/ 为全文范围）
officecli set doc.docx / --find draft --replace final
# docx 修订模式替换（留痕）
officecli set doc.docx / --find draft --replace final --prop revision.author=Alice
```

- 路径控制搜索范围：`/` 全文；`/body/p[1]`、`/slide[N]/shape[M]` 指定元素；`/header[1]`、`/footer[1]` 页眉页脚。
- 默认大小写敏感；忽略大小写：`--prop 'find=(?i)error' --prop regex=true`。
- 匹配跨 run 边界；无匹配时静默成功，`--json` 输出含 `"matched": N`。
- **Excel 仅支持 find+replace**（不支持 find+格式属性）。

### add — 添加与克隆

```bash
officecli add <file> <parent> --type <type> [--prop ...]
officecli add <file> <parent> --type <type> --after <path> [--prop ...]
officecli add <file> <parent> --type <type> --before <path> [--prop ...]
officecli add <file> <parent> --type <type> --index N [--prop ...]     # 0 起（Excel row/col 例外 1 起）
officecli add <file> <parent> --from <path>                            # 克隆（保留跨部件关系）
```

- `--after` / `--before` / `--index` 互斥；不带位置参数则追加到末尾。
- `--after` / `--before` 可省略 `--to`（从锚点推断容器）。
- Word 示例：`--type paragraph --prop style=Heading1`、`--type run`、`--type table --prop rows=2 --prop cols=2`、`--after "find:First sentence."`。
- 元素类型与别名以 `officecli help <fmt> add` 为准。

### move / swap / remove

```bash
officecli move <file> <path> [--to <parent>] [--index N] [--after <path>] [--before <path>]
officecli swap <file> <path1> <path2>
officecli remove <file> '/body/p[4]'
```

### batch — 批量操作

```bash
# stdin 方式
echo '[{"command":"set","path":"/slide[1]/shape[1]","props":{"text":"Hello"}},
      {"command":"set","path":"/slide[1]/shape[2]","props":{"fill":"FF0000"}}]' | officecli batch deck.pptx --json
# 内联方式
officecli batch deck.pptx --commands '[{"op":"set","path":"/slide[1]/shape[1]","props":{"text":"Hi"}}]' --json
# 保留成功项（旧行为）
officecli batch deck.pptx --input updates.json --best-effort --json
# 遇错即停
officecli batch deck.pptx --input updates.json --stop-on-error --json
```

- 默认**原子性**：任一项失败整批回滚，磁盘文件与执行前逐字节一致；JSON 摘要含 `"atomicRolledBack": true`，失败项带机器可读 `code` 字段。
- `--best-effort`：保留成功项（适用于有损 `dump→batch` 回放）。
- `--stop-on-error`：剩余项标记 skipped；与 `--best-effort` 组合 = 遇错即停但保留已成功项。
- 支持的命令：`add`、`set`、`get`、`query`、`remove`、`move`、`swap`、`view`、`raw`、`raw-set`、`validate`。
- JSON 字段：`command`（或 `op`）、`path`、`parent`、`type`、`from`、`to`、`index`、`after`、`before`、`props`、`selector`、`mode`、`depth`、`part`、`xpath`、`action`、`xml`。

## 5. 常驻模式（Resident Mode）

- 每个命令首次访问文件时自动启动常驻实例（60s 空闲超时），文件锁冲突自动规避；`OFFICECLI_NO_AUTO_RESIDENT=1` 关闭自动启动。
- 长会话显式管理（12 分钟空闲超时）：`open` → 连续 `set` → `close`。
- **flush 时机**：仅当非 officecli 程序要读文件时（python-docx/openpyxl、Word/WPS、渲染交付、上传）。`save` = flush 并保留常驻；`close` = flush 并释放。officecli 自身读取始终可见最新修改。`OFFICECLI_RESIDENT_FLUSH=each` 可改为每次变更都落盘。

## 6. L3 原始 XML

```bash
officecli raw <file> <part>                                    # 查看原始 XML
officecli raw-set <file> <part> --xpath "..." --action replace --xml '<w:p>...</w:p>'
officecli add-part <file> <parent>                            # 新建文档部件（返回 rId）
```

- `raw-set` 动作：`append`、`prepend`、`insertbefore`、`insertafter`、`replace`、`remove`、`setattr`。
- 无需手写 xmlns 声明，前缀自动注册。可用部件以 `officecli help <fmt> raw` 为准。

## 7. 往返蓝图（dump / refresh）

```bash
officecli dump existing.docx -o blueprint.json               # 整文档
officecli dump existing.docx /body/tbl[1] -o table.json      # 任意子树
officecli dump existing.xlsx /Sheet1 -o sheet.json           # 单个工作表
officecli batch new.docx --input blueprint.json              # 回放
officecli refresh report.docx                                # 重算 TOC/页码/交叉引用
```

- dump 路径默认 `/`；docx 子树：`/body`、`/body/p[N]`、`/body/tbl[N]`、`/theme`、`/settings`、`/numbering`、`/styles`；xlsx：`/SheetName`、`/sheet[N]`。
- 覆盖度：docx 全覆盖；pptx 文本/表格/图片/图表/备注/主题 + OLE/3D/音视频/SmartArt/morph 过渡（raw-set 直通）；xlsx 单元格/公式/样式 + 表格、条件格式、数据验证、批注、图表、迷你图、图片、形状、透视表（slicer/chartEx/OLE 原样载体）。

## 8. watch 实时预览与交互

- `officecli watch <file>` → http://localhost:26315，编辑即时刷新。
- 浏览器内点选元素（shift/cmd/ctrl+click 多选，空白处拖拽框选），`officecli get <file> selected --json` 读取点选路径（稳定 `@id=` 形式）。
- `mark` / `unmark` / `get-marks`：在 watch 进程内登记修改提案（`find`、`color`、`note`、`tofix`），确认后由 set 管线应用；一次性修改直接用 `set`。
- 约束：同一文件同时只能一个 watch；组形状整体选中（v1 不支持钻进子元素）；docx 仅顶层段落/表格可寻址；xlsx 不发 `data-path`（mark/selection 恒为 stale）。
- 智能体自动化优先 `view html` / `view screenshot` 一次性模式，watch 面向人工交互。

## 9. 其他能力

- **模板合并**：`officecli merge template.docx out.docx --data '{"k":"v"}'` 或 `--data data.json`（`{{key}}` 占位符）。
- **CSV 导入**：`officecli import budget.xlsx "/Q1 Data" sales.csv --header`。
- **公式引擎**：350+ Excel 公式自动求值。
- **MCP**：`officecli mcp claude|cursor|vscode|lmstudio|opencode`，`officecli mcp list` 查状态；MCP 工具只有一个 `command` 字符串参数，原样透传 CLI。
- **插件**：`officecli plugins list`，扩展 `.doc`、`.hwpx`、`.pdf` 导出支持。

## 10. 场景化技能（load_skill）

| 名称 | 适用场景 |
|------|---------|
| `word` | 报告、信函、备忘录、方案等通用文档 |
| `academic-paper` | 期刊/会议/论文：APA/Chicago/IEEE/MLA 引文、公式、SEQ+PAGEREF 交叉引用、多栏排版、参考文献（不用于商务报告） |
| `pptx` | 通用演示：评审、销售、全员会、发布 |
| `pitch-deck` | **仅融资路演**（seed~C 轮、SAFE、可转债）（不用于销售/产品/评审） |
| `morph-ppt` | Morph 动画演示（不用于静态 Deck） |
| `morph-ppt-3d` | 3D Morph：GLB 模型、相机运动、景深 |
| `excel` | 通用工作簿、公式、透视表、跟踪表 |
| `financial-model` | 财务模型、情景、预测 |
| `data-dashboard` | CSV/表格数据 → KPI/分析/看板（图表+迷你图） |

加载规则：选最匹配的一个；场景技能已含格式默认规则，**不要叠加**；规则跨轮次持久，不要每轮重复加载；两个不同产物 = 两次独立加载。

## 11. 已知陷阱速查

| 陷阱 | 正确做法 |
|------|---------|
| `--name "foo"` | `--prop name="foo"` |
| 路径含 `[N]` 不加引号 | 一律引号：`'/slide[1]'` |
| PPT `shape[1]` 当正文 | `shape[1]` 是标题占位符，正文从 `shape[2]` 起 |
| `/shape[myname]` 名称索引 | 不支持；用数字索引或 `@name=`（仅 PPT） |
| 猜属性名 | `officecli help <fmt> <element>` |
| 改打开中的文件 | 先在 PowerPoint/WPS 关闭 |
| `$` 被 shell 吞 | 单引号：`--prop text='$15M'` |
| 换行符 | `--prop text="a\\nb"` |
| 索引基数 | 路径 1 起；`--index` 0 起；Excel row/col 的 `--index` 1 起 |
| batch 部分失败 | 默认整批回滚；要保留成功项加 `--best-effort` |
