#!/usr/bin/env bash
# OfficeCLI 安装自检脚本
# 用途：探测 officecli 是否可用（PATH 或常见安装位置），输出版本号；
#       未安装时按当前平台给出安装命令。
# 用法：bash check-install.sh
# 兼容：Git Bash (Windows) / macOS / Linux 的 bash

set -u

FOUND=""
VERSION=""

report_found() {
  local bin="$1"
  echo "[OK] 找到 officecli: $bin"
  VERSION="$("$bin" --version 2>&1 | head -n 1)"
  if [ -n "$VERSION" ]; then
    echo "[OK] 版本: $VERSION"
  else
    echo "[WARN] 已找到二进制但 --version 无输出，请手动运行: $bin --version"
  fi
}

# 1) PATH 探测
if command -v officecli >/dev/null 2>&1; then
  report_found "$(command -v officecli)"
  FOUND="yes"
fi

# 2) 常见安装位置探测（PATH 未刷新时很有用）
if [ -z "$FOUND" ]; then
  CANDIDATES=""
  # 脚本安装 / 手动释放常见目录
  [ -n "${HOME:-}" ] && CANDIDATES="$CANDIDATES $HOME/.officecli/bin/officecli $HOME/.local/bin/officecli"
  [ -n "${LOCALAPPDATA:-}" ] && CANDIDATES="$CANDIDATES $LOCALAPPDATA/Programs/officecli/officecli.exe $LOCALAPPDATA/Microsoft/WinGet/Links/officecli.exe"
  [ -n "${USERPROFILE:-}" ] && CANDIDATES="$CANDIDATES $USERPROFILE/scoop/shims/officecli.exe"
  [ -n "${HOME:-}" ] && CANDIDATES="$CANDIDATES $HOME/scoop/shims/officecli.exe"
  # npm 全局
  if command -v npm >/dev/null 2>&1; then
    NPM_PREFIX="$(npm prefix -g 2>/dev/null)"
    [ -n "$NPM_PREFIX" ] && CANDIDATES="$CANDIDATES $NPM_PREFIX/officecli $NPM_PREFIX/officecli.exe"
  fi
  # Homebrew
  [ -x /opt/homebrew/bin/officecli ] && CANDIDATES="$CANDIDATES /opt/homebrew/bin/officecli"
  [ -x /usr/local/bin/officecli ] && CANDIDATES="$CANDIDATES /usr/local/bin/officecli"

  for c in $CANDIDATES; do
    if [ -x "$c" ]; then
      report_found "$c"
      FOUND="yes"
      break
    fi
  done
fi

# 3) 未安装：给出指引
if [ -z "$FOUND" ]; then
  echo "[MISS] 未检测到 officecli。请按平台安装（任选其一）："
  echo ""
  echo "  Windows (PowerShell):"
  echo "    irm https://d.officecli.ai/install.ps1 | iex"
  echo "    或: scoop install officecli"
  echo "    或: npm install -g @officecli/officecli"
  echo ""
  echo "  macOS / Linux:"
  echo "    curl -fsSL https://d.officecli.ai/install.sh | bash"
  echo "    或: brew install officecli"
  echo ""
  echo "安装完成后必须新开一个终端（刷新 PATH），然后运行: officecli --version"
  echo "备用安装地址（raw.githubusercontent.com）："
  echo "    irm https://raw.githubusercontent.com/iOfficeAI/OfficeCLI/main/install.ps1 | iex   (Windows)"
  echo "    curl -fsSL https://raw.githubusercontent.com/iOfficeAI/OfficeCLI/main/install.sh | bash   (macOS/Linux)"
  exit 1
fi

exit 0
