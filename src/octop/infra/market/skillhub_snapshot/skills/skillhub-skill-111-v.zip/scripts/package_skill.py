#!/usr/bin/env python3
"""打包技能脚本 - 将技能文件夹打包成 .skill 文件"""

import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

def get_skill_name(path: str) -> str:
    """从 SKILL.md 提取技能名称"""
    skill_path = Path(path)
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        content = skill_md.read_text(encoding="utf-8")
        import re
        match = re.search(r'^---\n.*?name:\s*(.+?)\n', content, re.DOTALL)
        if match:
            return match.group(1).strip()
    return skill_path.name

def get_skill_version(path: str) -> str:
    """从 _meta.json 获取版本号"""
    skill_path = Path(path)
    meta_json = skill_path / "_meta.json"
    if meta_json.exists():
        meta = json.loads(meta_json.read_text(encoding="utf-8"))
        return meta.get("version", "1.0.0")
    return "1.0.0"

def get_skill_id(path: str) -> str:
    """从 _meta.json 获取技能ID"""
    skill_path = Path(path)
    meta_json = skill_path / "_meta.json"
    if meta_json.exists():
        meta = json.loads(meta_json.read_text(encoding="utf-8"))
        return meta.get("id", skill_path.name)
    return skill_path.name

def package_skill(path: str, output_dir: str = ".") -> str:
    """打包技能并返回输出文件路径"""
    skill_path = Path(path).resolve()
    output_path = Path(output_dir).resolve()

    if not skill_path.exists():
        raise FileNotFoundError(f"技能目录不存在: {path}")

    skill_name = get_skill_name(path)
    skill_id = get_skill_id(path)
    skill_version = get_skill_version(path)

    # 生成输出文件名: skill-name_version.skill
    output_file = output_path / f"{skill_name}_{skill_version}.skill"

    # 创建 zip 文件
    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for file_path in skill_path.rglob('*'):
            if file_path.is_file():
                # 跳过隐藏文件和 __pycache__
                if any(part.startswith('.') or part == '__pycache__' for part in file_path.parts):
                    continue
                arcname = file_path.relative_to(skill_path)
                zf.write(file_path, arcname)

    return str(output_file)

if __name__ == "__main__":
    skill_path = sys.argv[1] if len(sys.argv) > 1 else "."
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "."

    try:
        output_file = package_skill(skill_path, output_dir)
        print(f"✓ 技能打包成功: {output_file}")
        sys.exit(0)
    except Exception as e:
        print(f"✗ 打包失败: {e}")
        sys.exit(1)
