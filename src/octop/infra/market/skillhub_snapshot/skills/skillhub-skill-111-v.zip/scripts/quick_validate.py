#!/usr/bin/env python3
"""快速验证脚本 - 检查技能结构完整性"""

import json
import os
import re
from pathlib import Path

def validate_skill(path: str) -> tuple[bool, list[str]]:
    """验证技能文件夹结构"""
    errors = []
    skill_path = Path(path)

    # 检查目录存在
    if not skill_path.exists():
        return False, [f"技能目录不存在: {path}"]

    # 检查 SKILL.md
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        errors.append("缺少 SKILL.md 文件")
    else:
        content = skill_md.read_text(encoding="utf-8")

        # 检查 frontmatter 格式
        if not content.startswith("---"):
            errors.append("SKILL.md 必须以 YAML frontmatter 开头 (---)")
        else:
            frontmatter_match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
            if not frontmatter_match:
                errors.append("SKILL.md frontmatter 格式不正确")
            else:
                frontmatter = frontmatter_match.group(1)

                # 检查必需字段
                if 'name:' not in frontmatter:
                    errors.append("frontmatter 缺少 name 字段")
                if 'description:' not in frontmatter:
                    errors.append("frontmatter 缺少 description 字段")

                # 检查 description 是否包含触发短语
                if 'description:' in frontmatter:
                    desc_match = re.search(r'description:\s*(.+)', frontmatter)
                    if desc_match:
                        desc = desc_match.group(1).strip()
                        if len(desc) < 20:
                            errors.append("description 内容过短，应至少包含20字符")
                        if '使用' not in desc and '当用户' not in desc:
                            errors.append("description 应包含触发条件（如'使用'、'当用户'等）")

    # 检查 _meta.json
    meta_json = skill_path / "_meta.json"
    if not meta_json.exists():
        errors.append("缺少 _meta.json 文件")
    else:
        try:
            meta = json.loads(meta_json.read_text(encoding="utf-8"))
            if "id" not in meta:
                errors.append("_meta.json 缺少 id 字段")
            if "version" not in meta:
                errors.append("_meta.json 缺少 version 字段")
        except json.JSONDecodeError as e:
            errors.append(f"_meta.json 格式错误: {e}")

    # 检查目录名称与 name 一致
    if skill_md.exists():
        content = skill_md.read_text(encoding="utf-8")
        frontmatter_match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
        if frontmatter_match:
            frontmatter = frontmatter_match.group(1)
            name_match = re.search(r'name:\s*(.+)', frontmatter)
            if name_match:
                expected_name = name_match.group(1).strip()
                folder_name = skill_path.name
                if expected_name != folder_name:
                    errors.append(f"技能名称不匹配: 文件夹名 '{folder_name}' 与 name '{expected_name}' 不同")

    return len(errors) == 0, errors

if __name__ == "__main__":
    import sys
    skill_path = sys.argv[1] if len(sys.argv) > 1 else "."
    valid, errors = validate_skill(skill_path)

    if valid:
        print("✓ 验证通过")
        sys.exit(0)
    else:
        print("✗ 验证失败:")
        for err in errors:
            print(f"  - {err}")
        sys.exit(1)
