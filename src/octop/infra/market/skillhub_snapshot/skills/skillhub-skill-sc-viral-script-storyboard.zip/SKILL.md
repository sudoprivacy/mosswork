---
name: skillhub-skill-sc-viral-script-storyboard
description: "爆款脚本工厂：快速拆解 + 分镜 + 口播全搞定。用于 OpenClaw 课程第 9 节：短视频结构拆解、分镜表、口播稿与时长估算。 触发词：短视频、爆款脚本、分镜、口播、抖音、视频脚本。"
---

# viral-script-storyboard

## 课程定位

- 节次：第 9 节
- 模块：模块二
- 标题：爆款脚本工厂：快速拆解 + 分镜 + 口播全搞定
- 核心目的：短视频结构拆解、分镜表、口播稿与时长估算。
- 上游参考：ai-video-script、videocut、short-video-script、video-script-gen、douyin-script-duration-calculator

## 使用流程

1. 先确认平台、时长、受众、商品/主题和版权来源。
2. 拆解用户提供的链接或文本时只总结结构，不洗稿复刻表达。
3. 生成分镜表必须包含镜头、画面、台词、字幕、时长与素材说明。
4. 配音只接 MiniMax、豆包语音、讯飞等境内服务或本地方案；不得仿冒真人声音。

## 标准输出

- `结构拆解.md`
- `分镜表.csv`
- `口播稿.md`
- `时长估算.csv`

## MCP/API 边界

- 默认允许：MiniMax TTS、豆包语音、讯飞语音、filesystem
- 可选能力：videocut、openai-whisper 仅本地/自托管替代经审计后
- 禁用能力：ElevenLabs、明示境外语音云的 MCP
- 备注：搬运/洗稿风险需在输出中提醒。

## 合规检查

执行前先回答三件事：

1. 数据或素材是否由用户提供、平台导出、公开授权或课程 demo 提供。
2. 是否涉及账号登录、批量操作、隐私、金融、医疗、未成年人或版权。
3. 是否需要人工确认后再调用外部 API 或工具。

若任一项不确定，先给出手动 SOP 或待确认清单，不直接调用外部服务。
