# Troubleshooting

## Error routing

- `PYTHON_REQUIRED`: Install Python 3.10+ from `https://www.python.org/downloads/windows/`, enable “Add python.exe to PATH,” reopen Codex, then retry the original link.
- `PYTHON_VENV_FAILED`: Confirm Python includes `venv`, then rerun `scripts/setup.ps1`.
- `PLAYWRIGHT_INSTALL_FAILED` or `PLAYWRIGHT_SETUP_FAILED`: Check PyPI/network access, run `scripts/setup.ps1`, then repeat `scripts/run.ps1 doctor`.
- `BROWSER_SELECTION_REQUIRED`: Ask the user to choose Edge or Chrome, then run `doctor --browser <choice>` to persist it.
- `BROWSER_MISSING`: Show `available_browsers`. Use `https://www.microsoft.com/edge/download` for Edge or `https://www.google.com/chrome/` for Chrome, wait for installation, then rerun `doctor --browser <choice>`.
- `LOGIN_REQUIRED` or `LOGIN_TIMEOUT`: Run headed `login` and let the user authenticate in the dedicated window.
- `NO_CAPTURED_HEADERS`: Keep Yuanbao open for ten seconds, interact with the page once, then retry. Never copy cookies from another profile.
- `YUANBAO_AUTH_FAILED`: Headed downloads automatically clear only the dedicated Yuanbao session, wait for login, and retry once. If that retry fails, run `login --force`, then retry the link.
- `YUANBAO_PARSE_FAILED`: Confirm the link remains accessible in WeChat and retry later. Yuanbao may be rate-limiting or may have changed its internal API.
- `WEIXIN_PARSE_FAILED` or `MEDIA_URL_MISSING`: The share item may be private, deleted, expired, or unsupported.
- `INVALID_MP4`: The media token expired or the response was an error document. Retry resolution; do not rename partial content as MP4.

## Browser choice and profiles

The saved browser preference is `%LOCALAPPDATA%\wx-channels-download\settings.json`. Browser sessions are isolated in `profiles\edge` and `profiles\chrome`; an older Edge session may remain in `profile`. Every path belongs only to this Skill. Never inspect or print cookie databases and never read the user's normal Edge or Chrome profile.

Use `login --force` to clear cookies and web storage only in the currently selected dedicated profile. Do not delete an entire profile unless the user explicitly requests a full reset.

## What launches the browser

`run.ps1` selects a Python runtime with the Playwright package. `yuanbao_channels.py` then calls Playwright's persistent Chromium launcher with the executable path of installed Edge or Chrome. It opens the browser only while `login`, `resolve`, or `download` is running and closes it afterward. The Skill creates no Windows startup entry, scheduled task, service, or always-running background process.

Playwright is installed into `%LOCALAPPDATA%\wx-channels-download\runtime` when needed. Do not run `playwright install`: this Skill deliberately reuses installed Edge or Chrome rather than downloading Playwright's browser binaries.

## Security

- Never persist captured request headers outside the dedicated browser profile.
- Never include cookies, media URLs, `generalToken`, or `exportId` in logs or final responses.
- Do not upload a profile or commit it to a repository.
- Prefer a visible browser. Headless mode can trigger device validation and cannot perform interactive recovery.
