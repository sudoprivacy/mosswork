---
name: skillhub-skill-wx-video-download
description: "Download a WeChat Channels (视频号) MP4 from an official weixin.qq.com/sph share link by reusing a dedicated local Tencent Yuanbao session in the user's chosen Edge or Chrome browser. Use when the user asks to download, resolve, inspect, or troubleshoot a 视频号 share link without copying cookies, installing a root certificate, or opening the WeChat desktop client."
---

# WeChat Channels Download

Keep Yuanbao authentication in a Skill-only Edge or Chrome profile. Never ask the user to paste cookies, tokens, request headers, credentials, or normal browser profile files into chat.

## Dependency model

- Explain only when setup is needed: Playwright is the local automation library that starts and controls the selected browser when a command runs. Windows does not auto-start the browser, and the Skill does not register any startup task or background service.
- Require Python 3.10+ and an installed Edge or Chrome. Use the user's installed browser executable but never its normal profile.
- Let `scripts/run.ps1` bootstrap missing Playwright into `%LOCALAPPDATA%\wx-channels-download\runtime`. This installs the Python package only; do not run `playwright install` or download another Chromium build.
- If setup reports `PYTHON_REQUIRED`, tell the user to install Python from `https://www.python.org/downloads/windows/`, enable “Add python.exe to PATH,” reopen Codex, and retry the original link. Do not continue until Python is available.
- If the chosen browser is missing, direct the user to the official Edge (`https://www.microsoft.com/edge/download`) or Chrome (`https://www.google.com/chrome/`) installer. Wait for installation, then rerun `doctor --browser <choice>`.

## Workflow

1. Check the environment and saved browser choice:

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/run.ps1 doctor
   ```

2. Let `run.ps1` install Playwright automatically when missing. Tell the user before the first setup that it creates a local Skill runtime. If automatic setup fails, read [references/troubleshooting.md](references/troubleshooting.md); run `scripts/setup.ps1` directly only for diagnosis.

3. If `selected_browser` is null, ask the user once: “视频下载使用 Edge 还是 Chrome？” Show `available_browsers` and do not ask when the user already stated a choice. Save the answer by running:

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/run.ps1 doctor --browser chrome
   ```

   Replace `chrome` with `edge` when chosen. The script persists this preference locally; do not ask again on later downloads. Passing `--browser edge|chrome` on any command changes the saved choice.

4. If `logged_in` is false, start interactive login with the selected browser:

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/run.ps1 login --timeout 300
   ```

   Tell the user to finish login in the visible dedicated browser window. Wait for the command to return. Closing this window does not log out; the local profile is reused later.

5. Download the supplied link:

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts/run.ps1 download "https://weixin.qq.com/sph/..." --output-dir "<absolute-directory>"
   ```

6. Report `file_path`, byte size, title, author, browser, and SHA-256. Do not report media URLs, cookies, `generalToken`, `exportId`, or captured request headers.

## Session recovery

- Let a visible `resolve` or `download` command handle HTTP 401 automatically. It clears only the selected Skill profile's stale Yuanbao cookies and web storage, opens Yuanbao login, waits for the user's login, then retries the original link once.
- Tell the user to scan/login when `SESSION_EXPIRED` appears. Do not start a separate download command while the original command is waiting.
- Use `login --force` only when manual session reset is required. It performs the same Skill-only cleanup and never touches the user's normal browser profile.
- A headless command cannot recover interactively; rerun it without `--headless`.

## Operating rules

- Accept only `https://weixin.qq.com/sph/` links unless the script later adds another official share-link form.
- Default the output directory to the user's Downloads folder when none is requested.
- Keep the browser visible by default. Use `--headless` only after a successful headed download on that browser and machine.
- Reuse `%LOCALAPPDATA%\wx-channels-download\profiles\edge` or `profiles\chrome`. The legacy Edge-only `profile` directory remains supported. Never read Edge or Chrome's normal user profile.
- Read [references/troubleshooting.md](references/troubleshooting.md) after any nonzero exit or error JSON.
- Download only content the user is authorized to access. Do not bypass private, deleted, paywalled, or access-controlled content.

## Commands

- `doctor [--browser edge|chrome]`: List installed choices, save/read the selection, and check the selected dedicated profile without printing secrets.
- `login [--browser edge|chrome] [--force]`: Open the dedicated profile and wait for login.
- `resolve <url> [--browser edge|chrome]`: Resolve metadata and verify media availability without saving it.
- `download <url> [--browser edge|chrome]`: Resolve and stream MP4. H.264 is the default; pass `--codec h265` when requested.
