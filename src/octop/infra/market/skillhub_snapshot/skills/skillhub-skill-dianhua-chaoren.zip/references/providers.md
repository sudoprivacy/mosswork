# 通话服务接入规范（可插拔，不绑定厂商）

本技能**不提供电话线路、号码、通话分钟数或任何通信资质**。真正把电话拨出去，只能由用户自己的手机、自己的通话服务，或已安装的其它电话技能完成。本技能负责的是前后两端：本人档案、话术、确认护栏、纪要、台账。

这一点必须对用户讲清楚，不得暗示"装了本技能就能自动打电话"。

## 三种模式对比

| 模式 | 是否需要账号/费用 | 是否自动拨出 | 适合谁 |
| --- | --- | --- | --- |
| `manual`（默认） | 不需要 | 否，产出拨号卡片由本人按下拨号键 | 所有人，开箱即用 |
| `webhook` | 需要自备 HTTP 通话服务 | 是，提交到自有端点 | 已有 AI 电话网关、企业内网的进阶用户 |
| `external` | 取决于外部技能 | 由外部技能决定 | 已装呼波特、ClawCall 之类电话技能的人 |

三种模式共用同一套 `plan → confirm → call → status → result` 流程，换模式只改 `~/.mycall/provider.json` 的 `mode`，话术、台账、合规护栏完全不变。

## 一、manual：零配置，人人可用

不需要任何配置文件。默认就是 manual。`call` 返回 `state=ready_to_dial`，输出 `dial_url`（`tel:` 链接）和话术卡，由本人点击拨号、照着说。

这是"每个人适用"的关键：**哪怕完全没有 API、没有账号、没有网络，本技能依然把最费神的部分（怎么开口、问什么、怎么收尾、打完记什么）做完了。**

## 二、webhook：万能适配器

把任意 AI 电话服务、企业语音网关或自建中转包装成 3 个 HTTP 端点即可。本技能不内置、不猜测任何厂商的接口地址与参数，一切以该服务的官方文档为准。

### 配置文件 `~/.mycall/provider.json`

```json
{
  "mode": "webhook",
  "webhook": {
    "submit_url": "https://你的服务/submit",
    "status_url": "https://你的服务/status",
    "result_url": "https://你的服务/result",
    "api_key_env": "MYCALL_API_KEY",
    "timeout": 30
  },
  "allow_hours": [9, 20],
  "cooldown_hours": 24
}
```

密钥的值放在系统环境变量 `MYCALL_API_KEY` 里，本技能只在请求头加 `Authorization: Bearer <值>`。**绝不把密钥写进配置文件、任务文件或日志。**

### 三个动作

**1) submit（提交通话）** — `POST` 到 `submit_url`，请求体：

```json
{
  "task_id": "C20261111-204500-A1B2",
  "to": "完整号码",
  "purpose": "这通电话要办的事",
  "scene": "confirm",
  "script": {"open": "…", "main": "…", "followup": "…", "close": "…", "branches": ["…"], "tone": "…", "taboo": "…"},
  "self_profile": {"name": "…", "org": "…", "title": "…", "style": "…", "taboo": "…"},
  "scheduled_at": "",
  "callback_hint": "结果请回传 status_url / result_url"
}
```

**2) status（查状态）** — `POST` 到 `status_url`，请求体 `{"task_id": "…", "provider_call_id": "…"}`。

**3) result（取结果）** — `POST` 到 `result_url`，请求体同上。

### 响应约定

返回单个 JSON 对象。本技能识别以下字段，其余字段原样保留在 `data` 里：

| 字段 | 说明 |
| --- | --- |
| `call_id` / `id` / `task_id` / `provider_call_id` | 服务商侧通话编号，任一即可 |
| `state` / `status` | 状态；常见值 `queued` `ringing` `connected` `completed` `failed` `no_answer` `busy` 会映射到统一状态 |
| `message` / `userMessage` | 面向用户的说明 |
| `transcript` / `summary` / `answered` / `outcome` | 通话结果，随 `data` 保留 |

未知状态一律映射为"结果不确定，不重复操作"，不猜测、不重拨。返回非 JSON 或空体时只说"服务已受理"，不编造进度。连接失败或 HTTP 错误直接报错停止，同一动作失败两次不再重试。

### 自建中转的最小责任

- 校验调用方密钥
- 遵守通话时段、频次、对方拒绝等合规要求（见 compliance.md）
- 按《人工智能生成合成内容标识办法》对合成语音添加显式与隐式标识
- 只回传完成本次事由所必需的信息

## 三、external：与其它电话技能协作

当用户已经装了能真正拨号的技能（例如呼波特 WhoBot、ClawCall 等），把本技能当作它的"前置大脑 + 后置秘书"：

1. 本技能建本人档案、写话术、出确认卡、做合规检查。
2. `mode=external` 时 `call` 返回 `state=handoff`，把话术卡交给外部技能执行拨出。
3. 外部技能回传结果后，用 `result` 把答复、办成情况、下一步归档进台账。

配置：

```json
{
  "mode": "external",
  "external": {
    "name": "已有电话技能的名称",
    "note": "按其官方文档执行，本技能不代替它拨号"
  }
}
```

本技能不调用、不复制、不绕过任何外部技能的登录态、账号或计费体系；它们的能力、费用与可用操作以其自身产品资料和系统返回为准。

## 四、密钥与隐私纪律

- 环境变量名写在配置里，值只存在系统环境变量中。
- `MYCALL_HOME` 可把全部运行期数据（档案、通讯录、任务、令牌、台账）改到任意目录，默认 `~/.mycall`。
- `doctor` 不联网、不拨号、不打印密钥值。
- 令牌一次性、30 分钟有效；`call` 缺令牌、令牌用过/过期/任务不匹配，一律拒绝拨出。

## 五、明确的边界

不提供：电话线路、SIM 卡、号码资源、呼出资质、语音克隆、实时语音识别、定时自动执行、批量任务调度、任何厂商的官方接口实现。

`plan --when` 只记录用户期望的时间，不负责定时；到点仍须重新确认后再拨出。
