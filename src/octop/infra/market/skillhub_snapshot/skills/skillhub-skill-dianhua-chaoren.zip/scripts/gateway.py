#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
电话超人 通话网关 —— 把「发起通话 / 查询状态 / 取回结果」三个动作统一起来。

设计原则：
1. 不内置任何厂商的私有接口细节，不猜测、不编造 API 地址。
2. 三种模式：
   - manual   零配置，不联网不拨号，产出拨号卡片由本人拨出（人人可用）。
   - webhook  用户填自己的 HTTP 端点，任意 AI 电话服务 / 企业网关都能接。
   - external 交给用户已有的其它电话技能或控制台执行，本技能负责前后两端。
3. 密钥只从环境变量读取，绝不写进配置文件、任务文件或日志。

所有函数返回统一结构：
    {"ok": bool, "state": str, "message": str, "provider_call_id": str|None, "data": dict}
state 取值：ready_to_dial | submitted | ringing | in_call | completed | failed | handoff | unknown
"""

import json
import os
import urllib.request
import urllib.error
from pathlib import Path

DEFAULT_CONFIG = {
    "mode": "manual",
    "webhook": {
        "submit_url": "",
        "status_url": "",
        "result_url": "",
        "api_key_env": "MYCALL_API_KEY",
        "timeout": 30,
    },
    "external": {
        "name": "",
        "note": "",
    },
    "allow_hours": [9, 20],
    "cooldown_hours": 24,
}

_STATE_ALIAS = {
    "queued": "submitted", "pending": "submitted", "dialing": "ringing",
    "ring": "ringing", "ringing": "ringing", "connected": "in_call",
    "in_call": "in_call", "speaking": "in_call", "finished": "completed",
    "completed": "completed", "done": "completed", "success": "completed",
    "failed": "failed", "error": "failed", "no_answer": "completed",
    "busy": "completed", "rejected": "completed",
}


def _ok(state, message, call_id=None, data=None):
    return {"ok": True, "state": state, "message": message,
            "provider_call_id": call_id, "data": data or {}}


def _err(message, data=None):
    return {"ok": False, "state": "failed", "message": message,
            "provider_call_id": None, "data": data or {}}


def load_config(home):
    """读取 provider.json；不存在时返回纯 manual 默认配置。"""
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    path = Path(home) / "provider.json"
    if path.exists():
        try:
            user_cfg = json.loads(path.read_text(encoding="utf-8"))
            for key, value in user_cfg.items():
                if isinstance(value, dict) and isinstance(cfg.get(key), dict):
                    cfg[key].update(value)
                else:
                    cfg[key] = value
        except (OSError, ValueError) as exc:
            cfg["_config_error"] = str(exc)
    env_mode = os.environ.get("MYCALL_MODE", "").strip()
    if env_mode in ("manual", "webhook", "external"):
        cfg["mode"] = env_mode
    return cfg


def describe(cfg):
    """给 doctor 用的能力摘要，不含任何密钥值。"""
    mode = cfg.get("mode", "manual")
    info = {"mode": mode, "ready": True, "can_dial": False, "note": ""}
    if mode == "manual":
        info["note"] = "零配置模式：生成话术与拨号卡片，由本人按下拨号键。"
    elif mode == "external":
        info["can_dial"] = False
        info["note"] = "外部执行模式：由 " + (cfg.get("external", {}).get("name") or "其它电话技能") + " 拨出，本技能做档案、话术、确认与纪要。"
    elif mode == "webhook":
        wh = cfg.get("webhook", {})
        info["can_dial"] = bool(wh.get("submit_url"))
        key_env = wh.get("api_key_env") or "MYCALL_API_KEY"
        info["api_key_present"] = bool(os.environ.get(key_env))
        info["note"] = "Webhook 模式：提交通话到自有 HTTP 端点。" if info["can_dial"] else "Webhook 模式已选但未填写 submit_url。"
        if not info["can_dial"]:
            info["ready"] = False
    return info


def _http_json(url, payload, cfg, method="POST"):
    """向用户自有端点发一个 JSON 请求。密钥只从环境变量取。"""
    wh = cfg.get("webhook", {})
    key_env = wh.get("api_key_env") or "MYCALL_API_KEY"
    headers = {"Content-Type": "application/json", "User-Agent": "dianhua-chaoren/1.0"}
    key = os.environ.get(key_env, "")
    if key:
        headers["Authorization"] = "Bearer " + key
    timeout = int(wh.get("timeout") or 30)
    req = urllib.request.Request(
        url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers, method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        return _err("通话服务返回 HTTP %s" % exc.code, {"url": url})
    except (urllib.error.URLError, OSError, ValueError) as exc:
        return _err("通话服务连接失败：%s" % exc, {"url": url})
    if not raw.strip():
        return _ok("submitted", "通话服务已受理（无返回明细）", data={"raw": ""})
    try:
        return _normalize(json.loads(raw))
    except ValueError:
        return _ok("submitted", "通话服务已受理（返回非 JSON）", data={"raw": raw[:500]})


def _normalize(obj):
    """把服务商返回映射成本技能的统一状态结构，缺失字段不臆造。"""
    if not isinstance(obj, dict):
        return _ok("unknown", "服务返回结构无法识别，不推测结果", data={"raw": str(obj)[:500]})
    call_id = obj.get("call_id") or obj.get("id") or obj.get("task_id") or obj.get("provider_call_id")
    raw_state = str(obj.get("state") or obj.get("status") or "submitted").lower()
    state = _STATE_ALIAS.get(raw_state, "submitted" if call_id else "unknown")
    message = obj.get("message") or obj.get("userMessage") or "通话服务已受理"
    return _ok(state, message, str(call_id) if call_id else None, data=obj)


def submit(task, cfg):
    """提交通话任务。manual / external 模式绝不联网、绝不拨号。"""
    mode = cfg.get("mode", "manual")
    if mode == "manual":
        return _ok("ready_to_dial", "话术卡已备好，请由本人按下拨号键；本技能不会自动拨出。")
    if mode == "external":
        name = cfg.get("external", {}).get("name") or "已接入的电话技能"
        return _ok("handoff", "请把这张话术卡交给「%s」执行拨出，结果回来后交本技能归档。" % name)
    if mode == "webhook":
        url = cfg.get("webhook", {}).get("submit_url", "")
        if not url:
            return _err("未配置 webhook.submit_url，已阻止拨号。参见 references/providers.md")
        payload = {
            "task_id": task.get("task_id"),
            "to": task.get("to"),
            "purpose": task.get("purpose"),
            "scene": task.get("scene"),
            "script": task.get("script"),
            "self_profile": task.get("self_profile", {}),
            "scheduled_at": task.get("when") or "",
            "callback_hint": "结果请回传 status_url / result_url",
        }
        return _http_json(url, payload, cfg)
    return _err("未知的通话模式：%s" % mode)


def status(task, cfg):
    mode = cfg.get("mode", "manual")
    if mode != "webhook":
        return _ok(task.get("state", "unknown"), "当前模式由本地记录状态，未向任何服务查询。",
                   task.get("provider_call_id"))
    url = cfg.get("webhook", {}).get("status_url", "")
    if not url:
        return _ok(task.get("state", "unknown"), "未配置 status_url，沿用上次本地状态。",
                   task.get("provider_call_id"))
    return _http_json(url, {"task_id": task.get("task_id"),
                            "provider_call_id": task.get("provider_call_id")}, cfg)


def fetch_result(task, cfg):
    mode = cfg.get("mode", "manual")
    if mode != "webhook":
        return _ok("completed", "当前模式不自动取回通话内容，请由本人或宿主转述结果后归档。")
    url = cfg.get("webhook", {}).get("result_url", "")
    if not url:
        return _ok("completed", "未配置 result_url，请转述对方答复后归档。")
    return _http_json(url, {"task_id": task.get("task_id"),
                            "provider_call_id": task.get("provider_call_id")}, cfg)
