#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
电话超人 唯一命令入口。纯 Python 标准库，零第三方依赖。

宿主 AI 只需记住 10 个子命令：
    doctor                          自检（绝不拨号、绝不联网）
    profile  show|set|init          本人档案
    contact  add|list|find|remove  常用联系人
    plan     ...                   一句话任务 -> 通话计划 + 话术骨架 + 拨号卡
    confirm  --task --approve      用户明确同意后，生成一次性拨号令牌
    call     --task --token --yes  真正发起（manual 模式只出拨号卡，不拨号）
    status   --task                查询状态
    result   --task ...            结构化纪要归档
    log      [--limit] [--export]  通话台账
    export   --task [--out]        导出 Markdown 话术卡

所有 stdout 输出均为单个 JSON 对象（ensure_ascii=False）。
所有运行期数据存放在 MYCALL_HOME（默认 ~/.mycall），不写进技能目录，
因此同一份技能包可分发给任何人、各自保留自己的档案与台账。
"""

import argparse
import csv
import json
import os
import re
import secrets
import sys
from datetime import datetime, timedelta
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gateway  # noqa: E402

SKILL_DIR = Path(__file__).resolve().parent.parent
HOME = Path(os.environ.get("MYCALL_HOME", str(Path.home() / ".mycall"))).expanduser()

PROFILE_FILE = HOME / "self_profile.json"
CONTACTS_FILE = HOME / "contacts.json"
TASKS_FILE = HOME / "tasks.json"
TOKENS_FILE = HOME / "tokens.json"
LOG_FILE = HOME / "call_log.csv"

PROFILE_DEFAULT = {
    "name": "", "org": "", "title": "", "how_to_address_me": "",
    "style": "客气、简洁、不绕弯", "taboo": "",
    "intro": "", "allow_hours": [9, 20], "allow_recording": False,
    "note": "",
}

SCENES = {
    "confirm": "确认预约、会议或时间是否照旧",
    "remind": "把一件已定的事通知到对方",
    "visit": "回访，问问近况或事情办得怎么样",
    "invite": "邀约对方参加活动、到店或来访",
    "ask": "询问进度、结果、报价或某件事的具体情况",
    "book": "订位、订场地、预约服务",
    "thanks": "致谢、致意",
    "other": "其它事项",
}

FOLLOWUP = {
    "confirm": "那我按这个记下了，时间或地点有变化的话，麻烦您提前跟我说一声，可以吗？",
    "remind": "我跟您核对一下，需要您这边做什么、什么时间之前，对吗？",
    "visit": "您看这件事接下来还需要我这边配合什么吗？",
    "invite": "您方便来吗？如果时间不合适，我这边可以另约。",
    "ask": "我记一下，您看我理解得对不对：……；另外大概什么时候能有结果？",
    "book": "帮我确认一下人数、时间和有没有特别要求，另外留个称呼方便到店核对。",
    "thanks": "不打扰您了，后续有事随时联系。",
    "other": "我把要点复述一遍，您看有没有理解错的地方？",
}

LOG_FIELDS = ["时间", "任务号", "对方", "称呼", "事由", "场景", "方式", "状态", "结果摘要", "下一步"]

MARKETING_BLOCK = ["群呼", "批量外呼", "骚扰", "电销名单", "轰炸", "刷单", "引流加微", "名单群发"]


# --------------------------------------------------------------------------- #
# 基础工具
# --------------------------------------------------------------------------- #

def out(obj, exit_code=0):
    print(json.dumps(obj, ensure_ascii=False, default=str))
    sys.exit(exit_code)


def fail(msg, **extra):
    payload = {"ok": False, "error": msg}
    payload.update(extra)
    out(payload, 1)


def load_json(path, default):
    if not path.exists():
        return json.loads(json.dumps(default))
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        fail("读取 %s 失败：%s" % (path.name, exc))


def save_json(path, obj):
    HOME.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    tmp.replace(path)


def now():
    return datetime.now()


def stamp():
    return now().strftime("%Y-%m-%d %H:%M:%S")


def new_task_id():
    return "C" + now().strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(2).upper()


def norm_phone(raw):
    s = re.sub(r"[\s\-()（）]", "", str(raw or ""))
    if s.startswith("+86"):
        s = s[3:]
    if s.startswith("86") and len(s) == 13:
        s = s[2:]
    return s


def valid_phone(s):
    if re.fullmatch(r"1[3-9]\d{9}", s):
        return True
    if re.fullmatch(r"0\d{2,3}\d{7,8}", s):
        return True
    if re.fullmatch(r"\d{7,8}", s):
        return True
    return False


def mask(phone):
    s = norm_phone(phone)
    return "尾号 " + s[-4:] if len(s) >= 4 else "号码不完整"


def profile():
    p = load_json(PROFILE_FILE, PROFILE_DEFAULT)
    for k, v in PROFILE_DEFAULT.items():
        p.setdefault(k, v)
    return p


def contacts():
    return load_json(CONTACTS_FILE, [])


def tasks():
    return load_json(TASKS_FILE, {})


def tokens():
    return load_json(TOKENS_FILE, {})


def resolve_contact(query):
    """名字或号码 -> 联系人 dict；多义时返回候选，不擅自选一个。"""
    q = str(query or "").strip()
    if not q:
        return None, [], "没有填写要打给谁"
    cs = contacts()
    if valid_phone(norm_phone(q)):
        hit = next((c for c in cs if norm_phone(c.get("phone")) == norm_phone(q)), None)
        if hit:
            return dict(hit), [], ""
        return {"name": "", "phone": norm_phone(q), "call": "", "relation": ""}, [], ""
    hits = [dict(c) for c in cs if q in str(c.get("name", "")) or q in str(c.get("call", ""))]
    exact = [c for c in hits if c.get("name") == q or c.get("call") == q]
    if len(exact) == 1:
        return exact[0], [], ""
    if len(hits) == 1:
        return hits[0], [], ""
    if len(hits) > 1:
        return None, hits, "通讯录里有多位匹配，请先让用户确认是哪一位"
    return None, [], "通讯录里没有「%s」，也没有给出可直接识别的电话号码" % q


# --------------------------------------------------------------------------- #
# 话术骨架
# --------------------------------------------------------------------------- #

def make_script(p, c, purpose, scene, tone):
    name = p.get("name") or "我"
    address = c.get("call") or c.get("name") or "您"
    org = p.get("org") or ""
    intro = p.get("intro") or ("我是%s%s的%s" % (org, "、" if org and p.get("title") else "", p.get("title") or name)).strip()
    if not p.get("name"):
        intro = "您好，我这边是" + (org or "之前联系过您的这位")
    opener = "您好，请问是%s吗？%s。现在方便说两句吗？" % (address, intro)
    main = purpose.strip()
    followup = FOLLOWUP.get(scene, FOLLOWUP["other"])
    close = "好的，我记下了，不耽误您时间，谢谢，再见。"
    if p.get("style"):
        tone = tone or p.get("style")
    return {
        "identity": "以「%s」本人身份通话，不冒充他人、不谎称机构" % (p.get("name") or "本人"),
        "open": opener,
        "main": main,
        "followup": followup,
        "close": close,
        "branches": [
            "对方说不方便：不追问、不纠缠，问一句「那我什么时候再打给您合适」，记下时间即结束。",
            "不是本人接听：不透露具体事由，只说「方便时请他回个电话」，不留敏感信息。",
            "对方明确表示不愿继续或要求不要再联系：立即致谢结束，并标记该号码不再外呼。",
            "对方答非所问或信息不确定：只复述确认，不替对方下结论。",
        ],
        "tone": tone or "客气、简洁、不绕弯",
        "taboo": p.get("taboo") or "不承诺未经本人同意的事项，不打听与本次事由无关的个人信息",
        "recording_notice": "如需录音，须在开场时先说明并取得对方同意。" if p.get("allow_recording") else "本技能默认不录音；如通话服务会录音，须按当地规定事先告知。",
    }


# --------------------------------------------------------------------------- #
# 合规检查
# --------------------------------------------------------------------------- #

def compliance(task, cfg, p):
    warnings, blockers = [], []
    purpose = task.get("purpose", "")
    if not purpose or len(purpose.strip()) < 4:
        blockers.append("没说清楚这通电话要办什么事")
    for word in MARKETING_BLOCK:
        if word in purpose:
            blockers.append("事由含「%s」，属于被禁止的营销骚扰类外呼" % word)
    if not p.get("name"):
        warnings.append("还没建本人档案，开场白只能用通用说法；建议先跑 profile init")
    allow = cfg.get("allow_hours") or p.get("allow_hours") or [9, 20]
    try:
        start, end = int(allow[0]), int(allow[1])
    except (ValueError, IndexError, TypeError):
        start, end = 9, 20
    hour = now().hour
    if not (start <= hour < end):
        blockers.append("当前 %02d:00 不在允许的通话时段 %02d:00–%02d:00 内" % (hour, start, end))
    phone = norm_phone(task.get("to", ""))
    if not valid_phone(phone):
        blockers.append("电话号码格式不对：%s" % mask(phone))
    if cfg.get("mode") != "manual":
        cd = float(cfg.get("cooldown_hours") or 24)
        cutoff = now() - timedelta(hours=cd)
        for row in read_log():
            if row.get("对方") == mask(phone):
                try:
                    if datetime.strptime(row.get("时间", ""), "%Y-%m-%d %H:%M:%S") > cutoff:
                        warnings.append("同一号码在 %.0f 小时内已联系过一次，请确认是否确有必要" % cd)
                except ValueError:
                    pass
                break
    if task.get("mode") == "webhook":
        warnings.append("自动拨号可能产生服务商费用，金额以服务商实际计费为准")
    if task.get("when"):
        warnings.append("已指定时间「%s」，本技能不负责定时执行，请到点再确认拨出" % task["when"])
    return warnings, blockers


def read_log():
    if not LOG_FILE.exists():
        return []
    try:
        with LOG_FILE.open("r", encoding="utf-8-sig", newline="") as fh:
            return list(csv.DictReader(fh))
    except (OSError, ValueError):
        return []


def append_log(row):
    HOME.mkdir(parents=True, exist_ok=True)
    exists = LOG_FILE.exists()
    with LOG_FILE.open("a", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=LOG_FIELDS)
        if not exists:
            writer.writeheader()
        writer.writerow({k: row.get(k, "") for k in LOG_FIELDS})


# --------------------------------------------------------------------------- #
# 子命令
# --------------------------------------------------------------------------- #

def cmd_doctor(args):
    cfg = gateway.load_config(HOME)
    p = profile()
    desc = gateway.describe(cfg)
    warnings = []
    try:
        HOME.mkdir(parents=True, exist_ok=True)
        writable = os.access(str(HOME), os.W_OK)
    except OSError:
        writable = False
    if not writable:
        warnings.append("数据目录不可写：%s（可用 MYCALL_HOME 改到别处）" % HOME)
    if not p.get("name"):
        warnings.append("本人档案未建立，先用 profile init 填姓名等信息")
    if cfg.get("_config_error"):
        warnings.append("provider.json 解析失败：%s" % cfg["_config_error"])
    if cfg.get("mode") == "webhook" and not desc.get("api_key_present"):
        warnings.append("未检测到环境变量 %s 的值" % (cfg.get("webhook", {}).get("api_key_env") or "MYCALL_API_KEY"))
    out({
        "ok": True, "checked_at": stamp(), "home": str(HOME),
        "python": sys.version.split()[0],
        "profile_ready": bool(p.get("name")),
        "profile_name": p.get("name", ""),
        "contacts_count": len(contacts()),
        "tasks_count": len(tasks()),
        "log_count": len(read_log()),
        "provider": desc,
        "allow_hours": cfg.get("allow_hours"),
        "warnings": warnings,
        "note": "自检未联网、未拨号、未读取任何密钥的值。",
        "next": "档案未建则先建档案；否则直接用 plan 下达一句话任务。",
    })


def cmd_profile(args):
    p = profile()
    action = args.action
    if action == "show":
        out({"ok": True, "profile": p, "file": str(PROFILE_FILE)})
    if action == "init":
        for key in ("name", "org", "title", "how_to_address_me", "intro", "style", "taboo"):
            val = getattr(args, key, None)
            if val is not None:
                p[key] = val
        save_json(PROFILE_FILE, p)
        out({"ok": True, "profile": p, "message": "本人档案已保存", "file": str(PROFILE_FILE)})
    if action == "set":
        if args.key not in PROFILE_DEFAULT:
            fail("不支持的字段：%s" % args.key, allowed=list(PROFILE_DEFAULT.keys()))
        p[args.key] = args.value
        save_json(PROFILE_FILE, p)
        out({"ok": True, "key": args.key, "value": args.value, "message": "已更新"})
    fail("未知的 profile 操作：%s" % action)


def cmd_contact(args):
    cs = contacts()
    action = args.action
    if action == "add":
        phone = norm_phone(args.phone)
        if not valid_phone(phone):
            fail("电话号码格式不对：%s" % args.phone)
        if any(norm_phone(c.get("phone")) == phone for c in cs):
            fail("这个号码已经在通讯录里了", existing=mask(phone))
        item = {"name": args.name, "phone": phone, "call": args.call or args.name,
                "relation": args.relation or "", "note": args.note or "", "added_at": stamp()}
        cs.append(item)
        save_json(CONTACTS_FILE, cs)
        out({"ok": True, "contact": {**item, "phone": mask(phone)}, "message": "已存入通讯录"})
    if action == "list":
        shown = [{**c, "phone": mask(c.get("phone"))} for c in cs]
        out({"ok": True, "count": len(shown), "contacts": shown})
    if action == "find":
        q = args.query or ""
        hits = [c for c in cs if q in c.get("name", "") or q in c.get("call", "") or q in c.get("relation", "")]
        shown = [{**c, "phone": mask(c.get("phone"))} for c in hits]
        out({"ok": True, "count": len(shown), "contacts": shown})
    if action == "remove":
        before = len(cs)
        cs = [c for c in cs if c.get("name") != args.name and c.get("call") != args.name]
        if len(cs) == before:
            fail("通讯录里没有「%s」" % args.name)
        save_json(CONTACTS_FILE, cs)
        out({"ok": True, "message": "已移除 %d 位" % (before - len(cs))})
    fail("未知的 contact 操作：%s" % action)


def cmd_plan(args):
    cfg = gateway.load_config(HOME)
    p = profile()
    c, candidates, err = resolve_contact(args.to)
    if err:
        payload = {"ok": False, "error": err, "need_user_choice": bool(candidates)}
        if candidates:
            payload["candidates"] = [{"name": x.get("name"), "call": x.get("call"),
                                      "relation": x.get("relation"), "phone": mask(x.get("phone"))}
                                     for x in candidates]
        out(payload, 1)
    custom = ""
    if args.script_file:
        try:
            custom = Path(args.script_file).read_text(encoding="utf-8")
        except OSError as exc:
            fail("读话术文件失败：%s" % exc)
    if args.script:
        custom = args.script
    script = make_script(p, c, args.purpose, args.scene, args.tone)
    task = {
        "task_id": new_task_id(), "created_at": stamp(),
        "to": c.get("phone", ""), "to_name": c.get("name", ""),
        "to_call": c.get("call") or c.get("name") or "",
        "purpose": args.purpose.strip(), "scene": args.scene,
        "when": args.when or "", "tone": args.tone or p.get("style"),
        "mode": args.provider or cfg.get("mode", "manual"),
        "script": script, "custom_script": custom,
        "self_profile": {k: p.get(k) for k in ("name", "org", "title", "style", "taboo")},
        "state": "planned", "provider_call_id": "",
        "result": {}, "confirmed_token": "",
    }
    warnings, blockers = compliance(task, cfg, p)
    all_tasks = tasks()
    all_tasks[task["task_id"]] = task
    save_json(TASKS_FILE, all_tasks)
    checklist = [
        "打给谁：%s（%s）" % (c.get("call") or c.get("name") or "未存名", mask(task["to"])),
        "办什么事：%s" % task["purpose"],
        "什么时候：%s" % (task["when"] or "现在"),
        "怎么打：%s" % {"manual": "本人按拨号键，照着话术卡说",
                        "webhook": "由已接入的通话服务自动拨出",
                        "external": "交给已接入的电话技能拨出"}.get(task["mode"], task["mode"]),
        "开场身份：%s" % (p.get("name") or "（未建档，用通用自称）"),
    ]
    if task["mode"] == "webhook":
        checklist.append("费用：可能产生服务商通话费，以服务商实际计费为准")
    out({
        "ok": not blockers, "blocked": bool(blockers), "blockers": blockers,
        "warnings": warnings, "task_id": task["task_id"],
        "to_masked": mask(task["to"]), "to_name": task["to_name"],
        "purpose": task["purpose"], "scene": task["scene"],
        "scene_note": SCENES.get(task["scene"], ""),
        "mode": task["mode"], "script": script, "custom_script": custom,
        "dial_url": "tel:" + task["to"], "checklist": checklist,
        "need_confirm": True,
        "next": "把 checklist 逐项给用户看并请其明确同意；同意后运行 confirm --task %s --approve。若 blocked=true 先解决 blockers，不得确认。" % task["task_id"],
        "privacy": "dial_url 仅供生成拨号链接，不要在回复里原文展示完整号码。",
    })


def cmd_confirm(args):
    all_tasks = tasks()
    task = all_tasks.get(args.task)
    if not task:
        fail("找不到任务 %s，请先 plan" % args.task)
    cfg = gateway.load_config(HOME)
    warnings, blockers = compliance(task, cfg, profile())
    if blockers:
        fail("合规检查未通过，已拒绝生成拨号令牌", blockers=blockers)
    if not args.approve:
        fail("未带 --approve。只有在用户明确说出同意之后才能带此参数。")
    token = secrets.token_urlsafe(18)
    all_tokens = tokens()
    all_tokens[token] = {
        "task_id": args.task, "created_at": stamp(),
        "expires_at": (now() + timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S"),
        "used": False,
    }
    save_json(TOKENS_FILE, all_tokens)
    task["state"] = "confirmed"
    task["confirmed_token"] = token
    all_tasks[args.task] = task
    save_json(TASKS_FILE, all_tasks)
    out({"ok": True, "token": token, "task_id": args.task,
         "expires_at": all_tokens[token]["expires_at"],
         "summary": {"to": task["to_call"], "masked": mask(task["to"]),
                     "purpose": task["purpose"], "mode": task["mode"]},
         "warnings": warnings,
         "next": "运行 call --task %s --token <token> --yes" % args.task,
         "note": "令牌一次性、30 分钟有效；manual 模式不会拨号。"})


def _check_token(args):
    """只校验不消耗：合规复查不通过时令牌仍然有效，避免白白作废。"""
    rec = tokens().get(args.token)
    if not rec:
        fail("拨号令牌无效，已阻止拨出")
    if rec.get("used"):
        fail("令牌已用过，已阻止重复拨出")
    if rec.get("task_id") != args.task:
        fail("令牌与任务不匹配，已阻止拨出")
    try:
        if datetime.strptime(rec["expires_at"], "%Y-%m-%d %H:%M:%S") < now():
            fail("令牌已过期，请重新向用户确认后再生成")
    except (ValueError, KeyError):
        fail("令牌时间格式异常，已阻止拨出")


def _mark_token_used(token_value):
    all_tokens = tokens()
    all_tokens[token_value]["used"] = True
    save_json(TOKENS_FILE, all_tokens)


def cmd_call(args):
    all_tasks = tasks()
    task = all_tasks.get(args.task)
    if not task:
        fail("找不到任务 %s" % args.task)
    if not args.yes:
        fail("缺少 --yes，已阻止拨出")
    _check_token(args)
    cfg = gateway.load_config(HOME)
    warnings, blockers = compliance(task, cfg, profile())
    if blockers:
        fail("拨出前复查未通过，已阻止拨出", blockers=blockers)
    _mark_token_used(args.token)
    task["mode"] = cfg.get("mode", task.get("mode", "manual"))
    res = gateway.submit(task, cfg)
    task["state"] = res["state"]
    task["provider_call_id"] = res.get("provider_call_id") or ""
    task["submitted_at"] = stamp()
    task["last_message"] = res["message"]
    all_tasks[args.task] = task
    save_json(TASKS_FILE, all_tasks)
    append_log({
        "时间": stamp(), "任务号": args.task, "对方": mask(task["to"]),
        "称呼": task["to_call"], "事由": task["purpose"], "场景": task["scene"],
        "方式": task["mode"], "状态": res["state"],
        "结果摘要": res["message"], "下一步": "status / result",
    })
    out({"ok": res["ok"], "state": res["state"], "message": res["message"],
         "task_id": args.task, "provider_call_id": task["provider_call_id"],
         "dial_url": "tel:" + task["to"], "to_masked": mask(task["to"]),
         "warnings": warnings,
         "next": "manual：请本人按下拨号键，打完后用 result 归档；webhook：用 status 查询；external：等执行方回传结果。",
         "truthfulness": "state=ready_to_dial 或 handoff 时，绝不能说成「电话已打通」。",
         "exit_code": 0 if res["ok"] else 1})


def cmd_status(args):
    all_tasks = tasks()
    task = all_tasks.get(args.task)
    if not task:
        fail("找不到任务 %s" % args.task)
    cfg = gateway.load_config(HOME)
    res = gateway.status(task, cfg)
    if res["ok"] and res["state"] != "unknown":
        task["state"] = res["state"]
        all_tasks[args.task] = task
        save_json(TASKS_FILE, all_tasks)
    out({"ok": res["ok"], "task_id": args.task, "state": res["state"],
         "message": res["message"], "provider_call_id": task.get("provider_call_id", ""),
         "to_masked": mask(task["to"]), "purpose": task["purpose"],
         "note": "只转述查询到的状态，不推测、不补进度。"})


def cmd_result(args):
    all_tasks = tasks()
    task = all_tasks.get(args.task)
    if not task:
        fail("找不到任务 %s" % args.task)
    cfg = gateway.load_config(HOME)
    remote = gateway.fetch_result(task, cfg)
    transcript = ""
    if args.transcript_file:
        try:
            transcript = Path(args.transcript_file).read_text(encoding="utf-8")
        except OSError as exc:
            fail("读通话记录文件失败：%s" % exc)
    result = {
        "answered": args.answered, "outcome": args.outcome or "",
        "followup": args.followup or "", "remote_message": remote["message"],
        "remote_data": remote.get("data", {}), "recorded_at": stamp(),
        "transcript_saved_locally": bool(transcript),
    }
    task["result"] = {k: v for k, v in result.items() if k != "remote_data"}
    task["transcript"] = transcript
    task["state"] = "completed"
    all_tasks[args.task] = task
    save_json(TASKS_FILE, all_tasks)
    append_log({
        "时间": stamp(), "任务号": args.task, "对方": mask(task["to"]),
        "称呼": task["to_call"], "事由": task["purpose"], "场景": task["scene"],
        "方式": task["mode"], "状态": "completed",
        "结果摘要": args.outcome or "（未填写对方答复）", "下一步": args.followup or "",
    })
    out({"ok": True, "task_id": args.task, "to_masked": mask(task["to"]),
         "summary": {"是否接通": args.answered, "对方答复与办成情况": args.outcome or "（未填写）",
                     "下一步": args.followup or "（无）"},
         "remote_message": remote["message"],
         "privacy": "通话原文只保存在本机任务文件，不写入台账、不外发。",
         "next": "把 summary 用大白话回报给用户；未办成的事项明确说明需要本人跟进。"})


def cmd_log(args):
    rows = read_log()
    limit = args.limit or 20
    if args.export:
        dest = Path(args.export).expanduser()
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open("w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=LOG_FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        out({"ok": True, "exported": str(dest), "count": len(rows)})
    out({"ok": True, "total": len(rows), "file": str(LOG_FILE),
         "rows": rows[-limit:], "note": "台账只存脱敏号码与结构化摘要，不存通话原文。"})


def render_card(task):
    s = task.get("script", {})
    lines = [
        "# 通话卡 · %s" % task.get("to_call") or "# 通话卡",
        "",
        "- 打给：%s（%s）" % (task.get("to_call") or "未存名", mask(task.get("to", ""))),
        "- 要办的事：%s" % task.get("purpose", ""),
        "- 场景：%s" % SCENES.get(task.get("scene"), "其它"),
        "- 时间：%s" % (task.get("when") or "现在"),
        "- 方式：%s" % {"manual": "本人拨号", "webhook": "通话服务自动拨出",
                        "external": "交由外部电话技能拨出"}.get(task.get("mode"), task.get("mode")),
        "- 任务号：%s" % task.get("task_id", ""),
        "",
        "**一键拨号：** [拨给 %s](tel:%s)" % (task.get("to_call") or "对方", task.get("to", "")),
        "",
        "## 照着说",
        "",
    ]
    if task.get("custom_script"):
        lines += [task["custom_script"].strip(), ""]
    else:
        for label, key in (("开场", "open"), ("说正事", "main"),
                           ("追问一句", "followup"), ("收尾", "close")):
            lines += ["**%s**：%s" % (label, s.get(key, "")), ""]
    lines += ["## 遇到这些情况", ""]
    for b in s.get("branches", []):
        lines += ["- " + b]
    lines += ["", "## 说话分寸", "",
              "- 语气：%s" % s.get("tone", ""),
              "- 绝不说：%s" % s.get("taboo", ""),
              "- %s" % s.get("recording_notice", ""),
              "- %s" % s.get("identity", ""),
              "", "## 打完记一笔", "",
              "- 对方怎么答的：", "- 事情办成了吗：", "- 还要做什么：", ""]
    return "\n".join(lines)


def cmd_export(args):
    all_tasks = tasks()
    task = all_tasks.get(args.task)
    if not task:
        fail("找不到任务 %s" % args.task)
    template = SKILL_DIR / "assets" / "script_card.md"
    text = render_card(task)
    if template.exists():
        text += "\n\n---\n\n" + template.read_text(encoding="utf-8")
    if args.out:
        dest = Path(args.out).expanduser()
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(text, encoding="utf-8")
        out({"ok": True, "path": str(dest), "task_id": args.task,
             "message": "话术卡已导出", "to_masked": mask(task["to"])})
    out({"ok": True, "task_id": args.task, "markdown": text,
         "to_masked": mask(task["to"])})


# --------------------------------------------------------------------------- #
# 参数解析
# --------------------------------------------------------------------------- #

def build_parser():
    ap = argparse.ArgumentParser(prog="mycall.py", description="电话超人 命令入口")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor", help="自检，不拨号不联网")

    p = sub.add_parser("profile", help="本人档案")
    p.add_argument("action", choices=["show", "set", "init"])
    p.add_argument("--key")
    p.add_argument("--value")
    for k in ("name", "org", "title", "how_to_address_me", "intro", "style", "taboo"):
        p.add_argument("--" + k.replace("_", "-"), dest=k)

    c = sub.add_parser("contact", help="常用联系人")
    c.add_argument("action", choices=["add", "list", "find", "remove"])
    c.add_argument("--name")
    c.add_argument("--phone")
    c.add_argument("--call", dest="call")
    c.add_argument("--relation")
    c.add_argument("--note")
    c.add_argument("--query")

    pl = sub.add_parser("plan", help="一句话任务生成通话计划")
    pl.add_argument("--to", required=True, help="通讯录里的名字，或直接给号码")
    pl.add_argument("--purpose", required=True, help="这通电话要办的事，一句大白话")
    pl.add_argument("--scene", default="other", choices=list(SCENES.keys()))
    pl.add_argument("--when", default="")
    pl.add_argument("--tone", default="")
    pl.add_argument("--script", default="")
    pl.add_argument("--script-file", default="")
    pl.add_argument("--provider", default="", choices=["", "manual", "webhook", "external"])

    cf = sub.add_parser("confirm", help="用户明确同意后生成一次性令牌")
    cf.add_argument("--task", required=True)
    cf.add_argument("--approve", action="store_true")

    ca = sub.add_parser("call", help="发起通话（manual 只出拨号卡）")
    ca.add_argument("--task", required=True)
    ca.add_argument("--token", required=True)
    ca.add_argument("--yes", action="store_true")

    st = sub.add_parser("status", help="查询状态")
    st.add_argument("--task", required=True)

    rs = sub.add_parser("result", help="归档通话纪要")
    rs.add_argument("--task", required=True)
    rs.add_argument("--answered", default="unknown", choices=["yes", "no", "unknown"])
    rs.add_argument("--outcome", default="")
    rs.add_argument("--followup", default="")
    rs.add_argument("--transcript-file", default="")

    lg = sub.add_parser("log", help="查看或导出台账")
    lg.add_argument("--limit", type=int, default=20)
    lg.add_argument("--export", default="")

    ex = sub.add_parser("export", help="导出 Markdown 话术卡")
    ex.add_argument("--task", required=True)
    ex.add_argument("--out", default="")

    return ap


DISPATCH = {
    "doctor": cmd_doctor, "profile": cmd_profile, "contact": cmd_contact,
    "plan": cmd_plan, "confirm": cmd_confirm, "call": cmd_call,
    "status": cmd_status, "result": cmd_result, "log": cmd_log,
    "export": cmd_export,
}


def main():
    args = build_parser().parse_args()
    try:
        DISPATCH[args.cmd](args)
    except SystemExit:
        raise
    except Exception as exc:  # 任何异常都以 JSON 返回，方便宿主判断
        fail("%s: %s" % (type(exc).__name__, exc))


if __name__ == "__main__":
    main()
