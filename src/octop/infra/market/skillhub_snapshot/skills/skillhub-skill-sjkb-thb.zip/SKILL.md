---
name: skillhub-skill-sjkb-thb
description: "把上传的 Excel（.xlsx/.csv）或 Word（.docx）表格数据做成可交互的单文件 HTML 动态数据看板：左侧导航栏、上方核心指标卡、右侧数据看板主区，采用柱状图、折线图、饼图等合适图型，并内置「导入数据」按钮，支持手动即时更新与条件允许时的定时自动刷新。当用户上传或指向 Excel/Word 数据文件并说「做数据看板」「生成数据看板」「做成 dashboard」「数据大屏」，或要求给看板加导入数据按钮时使用。产出固定为 HTML 文件。与偏静态出图的 data-viz-analysis 不同，本技能交付带数据导入与按列映射重算能力的交互式看板。"
---

# 动态数据看板生成

把源数据变成**一个可双击打开、可导入新数据重算的 HTML 看板**。布局固定：左侧导航、上方核心指标卡、右侧图表主区。

## 硬规则

1. 交付物只有 HTML。**不改源数据**，不覆盖用户原件；中间产物（profile/data JSON）放工作区临时目录。
2. 先看数据画像再设计图表。指标 3—6 个、图表 3—6 张；没有有信号的维度时如实说明，不硬凑图。
3. 所有数值必须能由 `mapping` + `source` 重算出来。构建脚本数值核查不通过时**默认拒绝交付**，不得用 `--force` 蒙混。
4. 页面零 CDN、零后端、离线可用。不向用户承诺「实时自动同步」：手动导入即时更新是确定能力，定时自动刷新依赖浏览器文件句柄或数据 URL，须按 `references/dashboard-spec.md` 第六节如实说明。
5. 用户只上传了文件、没有说做看板时，不生成本技能产物。
6. 涉及源数据数字自相矛盾时，保留原样并点明疑点，由用户裁定，不自行修正。

## 工作流

**第 1 步 · 定位文件**
确认源数据文件绝对路径与输出位置。输出文件名建议 `数据看板_<源文件名>.html`，保存在当前工作区；用户指定了路径就用指定路径。
若文件是 `.xls` / `.doc` 旧格式，请用户另存为 `.xlsx` / `.docx` 后再继续，不要猜测二进制内容。

**第 2 步 · 抽取与画像**
```
python <SKILL_DIR>/scripts/extract_data.py "<源文件>" --out "<工作区>/_dashboard/profile.json"
```
读取输出的 JSON：`ok` 必须为 true；逐个工作表看 `columns[].kind`（number / date / time / category / text / id / empty）、`unique`、`top`、`min/max/sum` 与 `warnings`。
- 表头探测不准时用 `--header-row N` 重跑，或多表时用 `--sheet "名称"` 分别看。
- 画像只取前 2000 行（报告里有 `truncated` 提示）；聚合口径要以实际行数复核。
- Word 文档若只有段落没有表格，只能做摘要卡，如实告诉用户该素材支撑不了图表。

**第 3 步 · 读规范并写数据契约**
**必读** `references/dashboard-spec.md`（数据契约、mapping、图表选型、布局、边界、自检清单）。
按画像挑维度：时间序列走折线/面积，离散类目走柱状/横条，构成占比走饼/环，多系列分解走堆叠柱；`id`、零方差列不做维度。
在工作区写 `_dashboard/data.json`，必须同时包含：
- `meta`（标题、口径说明、结论性 summary 与带数字的 highlights）
- `kpis`（3—6 个）、`charts`（3—6 张，labels 与 datasets 等长）、`table`（前 100 行明细）
- `mapping`（与 kpis/charts **顺序一一对应**，决定导入后能否重算）
- `source`（完整 `columns` + `rows`，供构建期数值核查；默认不进入交付 HTML）

**第 4 步 · 构建并核查**
```
python <SKILL_DIR>/scripts/build_dashboard.py "<工作区>/_dashboard/data.json" --out "<输出>.html"
```
脚本会校验契约、按 mapping 对 source 逐项重算比对 KPI 与每张图，并打印机器可读报告。
- 退出码 0：确认 `ok:true`、`numberCheck.performed:true` 且 `diffs` 为空、`injected.offline:true`。
- 退出码 2：契约错误 → 按 `errors` 修 data.json 后重跑。
- 退出码 3：数值不一致 → 回到源数据核对口径，或向用户说明疑点；**不要**改用 `--force`。
- 退出码 4：输出校验失败 → 检查模板占位符与标签。

**第 5 步 · 实机检查（环境允许时）**
用本机 Edge/Chrome 无头模式打开生成的 HTML 并 dump DOM，确认页面已执行脚本、KPI 与 SVG 图表节点存在：
```
"<edge路径>" --headless --disable-gpu --no-sandbox --dump-dom "<输出HTML绝对路径>"
```
检查 DOM 中是否出现 `chart-svg`、`kpi`、KPI 数值文字。若无可用浏览器，如实标注「未做浏览器实机验证」，不要用「生成成功」代替结果正确。

**第 6 步 · 交付**
用 `present_files` 打开 HTML，并在回复中写明：
- 文件名与保存位置；
- 已检查项（数值一致性核查项数、契约、离线自包含、实机渲染如有）与未检查项；
- 看板包含哪些指标/图表及数据来源口径；
- 「导入数据」与「自动刷新」怎么用，以及自动刷新的适用条件与限制（见规范第六节）。

## 资源

| 文件 | 用途 |
|---|---|
| `scripts/extract_data.py` | 零第三方依赖读取 xlsx/csv/docx/json → 数据画像 JSON；`--demo` 可自检 |
| `scripts/build_dashboard.py` | 校验契约 + 数值一致性核查 + 注入模板 → 单文件 HTML；`--check` 只核查 |
| `assets/dashboard-template.html` | 完整看板模板：布局、纯 SVG 图表、导入/映射/刷新/导出逻辑。**不要直接交付这个模板**，必须经 build 脚本注入 |
| `references/dashboard-spec.md` | 数据契约、mapping 规则、图表选型、布局、更新机制边界、自检清单 |

## 页面能力速览

- 左侧导航：总览 / 趋势分析 / 对比分析 / 结构分析 / 明细数据 / 数据管理；总览展示全部图表。
- 上方 KPI 卡：数值、环比/较上次导入变化、迷你趋势线。
- 右侧主区：图表网格（悬停提示、图例开关系列、时间范围筛选）+ 左栏核心结论与数据口径。
- 导入数据：支持 xlsx / xlsm / docx / csv / tsv / json 及拖拽；自动探测表头、可选工作表、逐字段列映射；应用后即时重算全部 KPI 与图表。
- 数据管理：绑定本地文件、数据 URL、自动刷新间隔、更新日志、导出看板 JSON / 明细 CSV。

## 不要做

- 不输出 PDF、PPT、图片或 README；不把源数据外发到任何在线服务。
- 不引入 Chart.js / ECharts 等 CDN；不改动模板的三段式布局骨架。
- 不编造指标、图例口径或来源标注；不把推断说成事实。
