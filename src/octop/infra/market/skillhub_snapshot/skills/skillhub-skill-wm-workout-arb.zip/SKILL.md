---
name: skillhub-skill-wm-workout-arb
description: "查询 A 股已公告、对价可计算的现金选择权/收购请求权/要约/换股条款（主池可年化；监视池只跟踪）。数据来自巨潮 PDF 规则抽取，不是东财并购重组。"
---

# 公告套利

已公告公司行动的条款与占用窗口。主池必须有对价才能年化；重组预案/分拆进监视池，**不算年化**。

## 何时使用

- 「现在有哪些现金选择权 / 要约 / 换股还能算占用」
- 「信达/东兴现金选择权价格是多少」
- 「某公司有没有进行中的公告套利条款」

## 不要用本技能

| 用户说法 | 改用 |
|----------|------|
| 东财并购重组进度/金额（无行权价） | 公司页「并购重组」/`wm-script（action=run）`，**不要**把 `bgcz` 当对价 |
| 传闻、媒体重组消息 | **不做**；只认巨潮公告 |
| 回测买卖点 | `wm-backtest` |
| 年报 PDF 原文 | `wm-filings` / `wm-report-extract` |

## 库主人

- 域库：`sys/workout` → `workout.board()` / `workout.query(sym)`
- 速查：[references/lib.md](references/lib.md)
- 数据：`cn.workout.LIST.global`（BSSAA）

## 调用

```bash
bash .cursor/skills/wm-skillhub/scripts/wm.sh run wm-workout-arb \
  '{"mode":"board"}' --result

bash .cursor/skills/wm-skillhub/scripts/wm.sh run wm-workout-arb \
  '{"mode":"symbol"}' --symbol 601059 --result
```

现价年化在读侧现算，不入库。缺申报截止日的主池事件不要编占用天数。条款数字以巨潮 PDF 为准；回答时带上 `sourceUrl` / `pageUrl` 让用户自行核对。

**不构成投资建议。**
