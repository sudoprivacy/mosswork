# 公告套利库速查（workout）

域库：`sys/workout/*` → 对外 **`workout.*`**（**不进** `sys/init`；`xs.require("sys/workout/init.xs")`）。

数据：`store.query("alt.bssaa", "cn.workout.LIST.global", 400, {"unwrap": "list"})`

## 技能已封装

| mode | 底层 |
|------|------|
| `board`（默认） | `workout.board()` |
| `symbol` | `workout.query(sym)` |

## 口径

- 主池：现金选择权 / 收购请求权 / 要约 / 换股，且对价可算，才年化
- 监视池：重组预案 / 分拆，只跟踪
- **禁止**用东财 `bgcz` 当行权价
- 年化：`g=(对价-现价)/现价`，简单年化 `g×365/占用天数`；缺截止日不算年化
- 现价：`$CLOSE_LAST`（与公司卡一致）。禁止用当前财报 SAS 下的 `$CLOSE_DAY`
- 每条条款带 `source` / `sourceUrl`（巨潮 PDF）/ `pageUrl`（巨潮公告页）。回答里给出下载或打开地址，让用户自行核对原文。旧行可能只有 PDF、没有公告页。
