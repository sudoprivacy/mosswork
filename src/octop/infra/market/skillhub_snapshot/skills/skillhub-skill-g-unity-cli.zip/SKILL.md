---
name: skillhub-skill-g-unity-cli
description: "在 Windows 上从仅安装 Unity Hub 与 Unity 6 的状态自助安装、配置和使用官方 Unity CLI，并自动安装项目 Pipeline、操作场景/对象/脚本、运行验证、保存与故障恢复。"
---

# Unity CLI 项目自动化（Unity 6 / Windows）

## 适用范围

当用户要修改 Unity 项目中的场景、GameObject、组件、C# 脚本、UI、材质、动画或执行 Play Mode 验证时使用本技能。

本技能不要求 npm、Node.js、Python、Git、PowerShell 模块或第三方自动化包。命令仅使用：

1. 已安装且已授权的 **Unity 6 Editor**；
2. 官方 **Unity CLI** 可执行文件（命令名为 `unity`）；
3. 智能体环境自带的 Shell/文件工具。

> 重要：Unity CLI 并不包含在 Unity Editor 6 本体中。技能的职责包括在 CLI 缺失时自行从**官方 Unity 渠道**安装它、配置用户级 PATH 并验证可用性。不要把 npm/Node、Python、Git 或任何第三方包管理器作为安装前提，也不能假装仅靠 Editor 即可调用 `unity command`。

联网只在以下操作需要：首次安装 Unity CLI、`unity pipeline install` 下载 Pipeline 包、或项目解析其 `manifest.json` 中缺失的 UPM 包。已有缓存时不需要网络。

## 首次自助安装 Unity CLI（只有 Unity Hub + Unity 6 时）

当 `unity --version` 返回“命令不存在”时，先执行以下流程；这不是需要用户另行提供下载链接的阻塞项。

1. 检查 Unity Hub 和 Editor 已安装：

```bash
unityhub --version
unity editors --json
unity license
```

`unityhub` 的实际命令名或可执行路径因 Hub 版本而异；若不存在，使用 OS 路径查询确认 Hub 是否已安装。若 Unity 6 Editor 不存在或许可证无效，向用户报告这个唯一阻塞项——CLI 不能替代 Editor 或许可证。

2. 通过浏览器自动化或 Shell 从 Unity **官方域名**检索当前 Unity CLI 的 Windows 安装页面/发布页。优先使用：

```text
https://docs.unity.com/
https://unity.com/
https://download.unity.com/
https://hub.unity3d.com/
```

只接受由 Unity 控制的 HTTPS 下载地址和明确标记为 Windows x64 的 Unity CLI 安装包。可通过官方文档页、官方发布页或官方重定向链接获取最终下载地址。**不要因为某个文档 URL 404、页面为动态渲染、或搜索引擎无结果就要求用户提供安装链接**；应改用上述官方域名继续发现，并验证重定向后的主机仍属于 Unity 官方域名。

3. 下载到 Session scratchpad，用系统内置安装能力静默安装到用户范围；不要要求管理员权限，也不要安装 npm、Node.js、Python 或 Git。安装程序类型和无交互参数必须以当前官方发布页的说明或安装程序自身的帮助为准。安装完成后，在当前会话中显式追加 CLI 的安装目录到 `PATH`，并持久化到用户级 PATH（不能覆盖原有 PATH）。

4. 验证安装与基本健康状态：

```bash
unity --version
unity --help
unity auth status
unity license
```

5. 如果官方站点不可访问、下载损坏、签名/发行者不是 Unity，或安装器失败：记录实际错误、保留下载文件在 scratchpad 供诊断，并停止。此时才请用户处理网络、代理、企业安全策略或授权；不要要求其猜测下载链接，不要使用非官方镜像，不要绕过签名/安全警告，也不要伪造 CLI。

成功后继续本技能的认证、项目打开、Pipeline 安装与自动化流程。

## 认证与许可证

登录不是每次编辑都必需，但**有效的 Unity Editor 许可证**始终是运行/构建/自动化的前提。先进行只读检查：

```bash
unity auth status
unity license
```

判断方式：

- 已登录、许可证有效、Editor 已连接、所需包已缓存：可直接工作，无需再次登录。
- 未登录但许可证有效且只做本地编辑：通常仍可工作；不要为了“例行检查”而强制登录。
- 没有有效许可证：停止需要启动、运行或构建 Editor 的操作，请用户在本机完成 Unity 激活。企业浮动许可证、离线许可证和个人许可证必须遵循用户组织既有流程。
- 要下载 CLI/Editor/Pipeline/UPM 包、访问 Unity Cloud、模板或在线版本信息：网络是必要条件；若 CLI 明确要求认证，则需登录。

只有用户确认可以登录、且 CLI 提示认证为阻塞项时，才执行：

```bash
unity auth login
```

该命令可能打开浏览器或进入交互式设备授权流程。绝不要求用户在聊天中发送账号、密码、访问令牌、序列号、许可证文件或 Cookie；不读取/打印智能体 vault 或机器上的私密认证配置。完成后重新运行：

```bash
unity auth status
unity license
```

认证或许可证出现 401/403、账号权限不足、激活失败时，最多复查一次状态，然后停止并请用户在本机 Unity Hub/浏览器/许可证管理流程中修复；不要反复登录或尝试绕过授权。

## 安全与行为准则

- 先检查项目与编辑器状态，再写入。
- 修改范围严格限制在用户请求的项目、场景、资源或脚本。
- 不删除 GameObject、资源、包或用户文件，除非用户明确要求；删除类命令需要用户确认。
- 不重置用户已经调整的 Camera、模型 Transform、Lighting 或项目设置。
- 不用可破坏引用的手工 YAML 编辑来移动场景对象。优先使用 `set_parent`、`set_transform`、`rename_gameobject` 等 Pipeline 命令。
- 每次写入后都要：等待编译完成 → 检查 Console → 保存场景（编辑模式）→ 需要时 Play Mode 验证。
- 不占用或终止已有 Unity/Pipeline 进程。若 Editor 已连接，复用它。

## 输入与前提检查

确定：

- 项目绝对路径，例如 `D:\UnityProjects\MyProject`；
- 要编辑的场景；
- 用户意图是否包括运行时行为、构建，还是只改编辑器数据。

在项目目录运行：

```bash
unity --version
unity status --json
unity pipeline list
```

解释：

- `unity status --json` 有 `state: ready`：可直接向该 Editor 发命令。
- 没有连接实例：先用正确版本打开项目：

```bash
unity open "D:\UnityProjects\MyProject"
unity status --json
```

等待 Editor 导入完毕后再继续；不要启动重复实例。

- Pipeline 未安装或状态异常：

```bash
unity pipeline install --project-path "D:\UnityProjects\MyProject"
```

这会将官方 Pipeline 包写入该项目的 Package Manager 配置，并由 Unity 自动获取它所需的 UPM 依赖。该步骤可能触发包解析与脚本重编译。

安装后重新检查：

```bash
unity pipeline list
unity status --json
```

如果项目使用自定义/离线 Package Registry 且 Pipeline 安装失败，报告确切报错，请用户提供网络、registry 或缓存；不要擅自改 `Packages/manifest.json`。

## 基础命令模式

所有操作指定项目目录，尤其当 Shell 当前目录不在项目根目录时：

```bash
unity command <command_name> --json [parameters]
```

常用诊断：

```bash
unity command --json
unity command get_scene_hierarchy --json
unity command get_console_logs --json
unity command recompile_status --json
```

`unity command --json` 会列出**当前安装的 Pipeline 版本实际提供的命令和参数 schema**。不要假定任意版本都有相同命令；首次使用较少见的命令时，先从此输出确认其参数。

## 标准编辑流程

### 1. 选择并检查场景

```bash
unity command list_open_scenes --json
unity command get_scene_hierarchy --json
```

如需切换场景，先查询 `open_scene` 的 schema，再打开对应 `Assets/.../*.unity`。

用精确对象查找：

```bash
unity command find_gameobjects --json --name "Main Camera"
unity command find_gameobjects --json --name "目标对象"
```

把返回的 `globalId` 保存下来并作为后续修改目标。对包含斜杠、中文、重名路径或模型深层对象，**不要依赖 hierarchy path**；优先使用 `globalId`。

### 2. 创建、重命名、层级整理

先用 `unity command --json` 查参数，再调用下列常见命令：

```bash
unity command create_gameobject --json --name "新分组" --parent "<parent-globalId>"
unity command set_parent --json --target "<target-globalId>" --parent "<parent-globalId>" --world_position_stays true
unity command rename_gameobject --json --target "<target-globalId>" --name "新名称"
unity command set_transform --json --target "<target-globalId>" ...
```

`world_position_stays true` 用于纯层级整理，以保持模型显示位置不变。

### 3. 编写和挂载脚本

脚本放在项目内，例如 `Assets/AgentWork/Scripts/`。写入新脚本时，建议先让 Pipeline 登记 `.meta`，再替换其内容：

```bash
unity command create_script --json --name "MyComponent" --path "Assets/AgentWork/Scripts"
```

然后用智能体的文件写入工具编辑：

```
Assets/AgentWork/Scripts/MyComponent.cs
```

随后严格执行：

```bash
unity command recompile --json
unity command recompile_status --json
```

只有 `recompile_status` 返回 `completed` 且 `failed:false` 后，才挂载：

```bash
unity command attach_script --json \
  --target "<target-globalId>" \
  --script "Assets/AgentWork/Scripts/MyComponent.cs"
```

若直接通过文件工具新建 `.cs` 后 `attach_script` 报 `No MonoScript`，不要重复同一调用：使用 `create_script --overwrite true` 让 Pipeline 建立资产记录，再写回真实代码，重新编译后挂载。

### 4. C# 运行时输入兼容性

先检查项目 Input System 配置和现有代码。若项目已使用 Input System，可以使用：

```csharp
using UnityEngine.InputSystem;
```

如果项目尚未启用或没有 `com.unity.inputsystem`，不要随意新增依赖。可在现有输入框架中实现，或先请用户确认是否允许添加包。

运行时创建 UI 时：

- Canvas、EventSystem、字体/资源均需在代码中做空值检查；
- 避免重复创建（先查已有 EventSystem/Canvas）；
- UI 点击应屏蔽模型拖拽等场景输入，例如用 `EventSystem.current.IsPointerOverGameObject()`；
- 动态 UI 不会自动写进场景，这是正常现象；其 Bootstrap 组件必须挂在已保存的场景对象上。

### 5. 编译、错误检查与保存

```bash
unity command recompile_status --json
unity command get_console_logs --json
unity command save_scene --json
```

只在编辑模式保存。如果 `save_scene` 报告正处于 Play Mode，先停止：

```bash
unity command editor_stop --json
unity command save_scene --json
```

不要将旧的正常 `Debug.Log` 误报为新错误；要区分 `Error`、`Warning` 与 `Log`。

## Play Mode 验证

当改动涉及 Awake/Start、动态 UI、输入或游戏逻辑时：

```bash
unity command editor_play --json
```

进入后可验证运行时对象：

```bash
unity command find_gameobjects --json --name "运行时对象名"
unity command get_console_logs --json
```

检查完毕：

```bash
unity command editor_stop --json
```

注意：Play Mode 对 Transform、运行时创建对象、材质 PropertyBlock 的改动通常在退出时回滚；保存必须在编辑模式完成。

若该版本未提供鼠标/UI 点击注入命令，不要声称已自动点击验证。应准确报告已验证到的事实，例如“按钮已在运行时创建、无脚本错误”，并说明实际交互需用户在 Game View 试用。

## 重编译或连接重置恢复

脚本重编译、包解析、保存场景后，第一次命令偶尔会出现连接重置或暂时状态异常。遵循此恢复流程：

```bash
unity status --json
unity command recompile_status --json
```

再重试**之前失败的安全查询/操作一次**。不要无限重试；如果 Editor 不再 ready，报告连接状态。避免依赖 `sleep`、`seq`、`which` 等并非所有智能体 Shell 都提供的工具。

## 常见失败对照

| 表现 | 正确处理 |
|---|---|
| `unity: command not found` | 执行本技能“首次自助安装 Unity CLI”流程：从官方 Unity 域名发现、下载并安装，配置用户 PATH 后验证。仅当官方访问/签名/安装真实失败时才请求用户处理阻塞。 |
| 认证 401/403、权限不足或许可证无效 | 最多复查一次 `unity auth status` / `unity license`；请用户在本机完成登录、激活或企业授权，绝不索取凭据。 |
| `No connected instances` | 用 `unity open <project>` 打开项目，等待并复查 `unity status --json`。 |
| `No MonoScript at ...` | 用 `create_script` 登记资产，重新编译，之后才 `attach_script`。 |
| `save_scene cannot run while ... play mode` | `editor_stop`，再 `save_scene`。 |
| `recompile_status` 一开始仍显示旧错误 | 先 `unity status --json`，再查一次状态；仅在已刷新后判断。 |
| 层级路径含中文/`/` 后被错误解析 | 使用 `find_gameobjects` 返回的 `globalId`。 |
| `pipeline install` 或包解析失败 | 保存错误信息；检查网络、Unity 登录/许可证、公司 registry/代理及可用缓存。不要手动删包。 |

## 最终交付检查清单

在回复用户前必须亲自观察到：

- [ ] 项目脚本编译完成，`failed:false`；
- [ ] Console 中没有由本次改动引起的 Error；
- [ ] 编辑模式已保存相关场景/资产；
- [ ] 若有运行时功能，已启动过 Play Mode 并验证可查询的运行时对象/状态；
- [ ] 已退出 Play Mode，除非用户要求保持运行；
- [ ] 回复中列出实际修改过的项目相对路径（例如 `Assets/Scenes/SampleScene.unity`）；
- [ ] 不宣称没有实际观察到的视觉效果或点击行为。

## 面向用户的简洁汇报模板

```
已完成：<功能>。
修改：`Assets/...`。
验证：脚本编译成功；Console 无新增错误；场景已保存；<运行时验证的事实>。
```
