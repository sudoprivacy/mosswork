---
name: skillhub-skill-bili-main-game
description: "当用户想按 B 站「游戏」分区定位子分区、查找该领域的上榜视频或核对 BV 号与播放数据时使用。本包只提供分区结构与榜单结构化元数据，不提供视频口播内容，也不转载第三方标题与昵称。触发词：游戏、B站分区、rid 4。"
---

# B 站分区 · 游戏

- 一级分区 rid：`4`；网页路由：`/v/game/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 96 条榜单条目，覆盖 7 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| GMV | 3 | 3 | 121 |
| 单机游戏 | 24 | 9 | 17 |
| 手机游戏 | 38 | 9 | 172 |
| 桌游棋牌 | 2 | 5 | 173 |
| 电子竞技 | 13 | 9 | 171 |
| 网络游戏 | 15 | 10 | 65 |
| 音游 | 1 | 1 | 136 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### GMV

数据来源：二级分区 7 日榜，可用 3 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV1SVfTYWE3V](https://www.bilibili.com/video/BV1SVfTYWE3V) | 76.9 万 | 二级分区 7 日榜 |
| [BV1jcZUYSEbW](https://www.bilibili.com/video/BV1jcZUYSEbW) | 60.7 万 | 二级分区 7 日榜 |
| [BV1p3R6YFEXF](https://www.bilibili.com/video/BV1p3R6YFEXF) | 78.0 万 | 二级分区 7 日榜 |

### 单机游戏

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV1gNRdYJEXZ](https://www.bilibili.com/video/BV1gNRdYJEXZ) | 796.0 万 | 二级分区 7 日榜 |
| [BV1EgRiY5Eek](https://www.bilibili.com/video/BV1EgRiY5Eek) | 445.3 万 | 二级分区 7 日榜 |
| [BV18wZbY7Eyt](https://www.bilibili.com/video/BV18wZbY7Eyt) | 454.0 万 | 二级分区 7 日榜 |
| [BV1gZRXYjEku](https://www.bilibili.com/video/BV1gZRXYjEku) | 178.0 万 | 二级分区 7 日榜 |
| [BV19LRRYXEfo](https://www.bilibili.com/video/BV19LRRYXEfo) | 355.1 万 | 二级分区 7 日榜 |

### 手机游戏

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV18hZ1YaEuM](https://www.bilibili.com/video/BV18hZ1YaEuM) | 509.3 万 | 二级分区 7 日榜 |
| [BV1VsRmYeEmy](https://www.bilibili.com/video/BV1VsRmYeEmy) | 213.9 万 | 二级分区 7 日榜 |
| [BV1rXdcYQEFE](https://www.bilibili.com/video/BV1rXdcYQEFE) | 246.7 万 | 二级分区 7 日榜 |
| [BV1wsR2Y1Eis](https://www.bilibili.com/video/BV1wsR2Y1Eis) | 618.4 万 | 二级分区 7 日榜 |
| [BV1ZURCYhEU2](https://www.bilibili.com/video/BV1ZURCYhEU2) | 320.8 万 | 二级分区 7 日榜 |

### 桌游棋牌

数据来源：二级分区 7 日榜，可用 5 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV1HddAYtEyo](https://www.bilibili.com/video/BV1HddAYtEyo) | 481.3 万 | 二级分区 7 日榜 |
| [BV1BJZmYmE2T](https://www.bilibili.com/video/BV1BJZmYmE2T) | 133.0 万 | 二级分区 7 日榜 |
| [BV1kMZ1Y7EHP](https://www.bilibili.com/video/BV1kMZ1Y7EHP) | 185.0 万 | 二级分区 7 日榜 |
| [BV1RyZZY3Ecp](https://www.bilibili.com/video/BV1RyZZY3Ecp) | 288.0 万 | 二级分区 7 日榜 |
| [BV1UdZ2YPEHF](https://www.bilibili.com/video/BV1UdZ2YPEHF) | 141.8 万 | 二级分区 7 日榜 |

### 电子竞技

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV1qNRRY8EZC](https://www.bilibili.com/video/BV1qNRRY8EZC) | 175.3 万 | 二级分区 7 日榜 |
| [BV1rhRUYEEUn](https://www.bilibili.com/video/BV1rhRUYEEUn) | 242.0 万 | 二级分区 7 日榜 |
| [BV146ZmYPEQS](https://www.bilibili.com/video/BV146ZmYPEQS) | 155.4 万 | 二级分区 7 日榜 |
| [BV1yVZQYMEVC](https://www.bilibili.com/video/BV1yVZQYMEVC) | 160.9 万 | 二级分区 7 日榜 |
| [BV1iFRDY7ER3](https://www.bilibili.com/video/BV1iFRDY7ER3) | 142.8 万 | 二级分区 7 日榜 |

### 网络游戏

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV1QoZUY3EeJ](https://www.bilibili.com/video/BV1QoZUY3EeJ) | 395.1 万 | 二级分区 7 日榜 |
| [BV1nXdcYQEtx](https://www.bilibili.com/video/BV1nXdcYQEtx) | 404.0 万 | 二级分区 7 日榜 |
| [BV1CURSYREaa](https://www.bilibili.com/video/BV1CURSYREaa) | 247.6 万 | 二级分区 7 日榜 |
| [BV1EGZoY5EqP](https://www.bilibili.com/video/BV1EGZoY5EqP) | 198.6 万 | 二级分区 7 日榜 |
| [BV1ZVfKYeEQD](https://www.bilibili.com/video/BV1ZVfKYeEQD) | 324.4 万 | 二级分区 7 日榜 |

### 音游

数据来源：二级分区 7 日榜，可用 1 条，下表展示前 5 条。

| BV 号 | 播放 | 来源 |
| --- | --- | --- |
| [BV1AQZ4YKEXu](https://www.bilibili.com/video/BV1AQZ4YKEXu) | 128.6 万 | 二级分区 7 日榜 |

## 合规说明

本包 v1.0.0 在 2026-11-06 收到平台审核结论「未通过内容合规审查」，版本记录中的标签为「内容含涉政内容」。平台未指明具体命中位置，本包不对此作推断。

从 v1.2.0 起，本包不再转载第三方视频标题、UP 主昵称与视频简介。`data/` 下只保留本包实际收录的结构化字段：BV 号、播放量、时长、发布时间，以及主榜数据中的 UP 主 mid 与子分区名。用户可以按表格中的 BV 号链接打开原站核对标题与创作者。

本次调整只移除文本字段，没有新增视频条目、没有改写数值、没有补写任何推断内容。分区名称一律沿用接口返回的 `tname`。

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：Mugen（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=4." https://api.bilibili.com/x/web-interface/ranking/v2?rid=4&type=all. Accessed 6 Nov. 2026.
