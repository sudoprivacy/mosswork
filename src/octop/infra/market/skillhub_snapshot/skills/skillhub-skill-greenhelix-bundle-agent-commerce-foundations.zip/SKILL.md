---
name: skillhub-skill-greenhelix-bundle-agent-commerce-foundations
description: "The complete foundation for agent-to-agent commerce. Covers B2B transactions, API migration, security hardening, payment rails, pricing strategy, and multi-agent orchestration. 6 guides, $184 value."
---

# Agent Commerce Foundations: 6-Guide Bundle for Building Autonomous Transaction Systems

## Included Guides
| Guide | Individual Price |
|-------|-----------------|
| Agent-to-Agent Commerce: Build Autonomous B2B Transactions | $29.00 |
| Agent Commerce Migration Guide: Retrofit Your REST APIs for Autonomous Agent Buyers | $39.00 |
| Locking Down Agent Commerce: The OWASP-Aligned Security Guide for Autonomous AI Agents on GreenHelix | $29.00 |
| The Agent Payment Rails Playbook | $29.00 |
| The Agent Pricing & Monetization Playbook | $29.00 |
| The Multi-Agent Commerce Cookbook: Orchestrating Agent Teams That Discover, Negotiate, Pay, and Verify Each Other | $29.00 |

## Total Value: $184.00 | Bundle Price: $149.00
