#!/usr/bin/env node
/**
 * paid.mjs —— 通用 A2M 付费闸门客户端（600 个 Skill 共用这一份，只改 payment_service.json）
 *
 * 铁律（违反则不交付）：
 *  1. PAY_API_BASE 必填，且拒绝 localhost/127.0.0.1/0.0.0.0/.local/内网段
 *  2. complete 只接受平台下发的真实 Payment-Proof，绝不自拼、绝不降级免费
 *  3. 未验付通过前，不向调用方输出任何业务内容
 *  4. 断网 ≠ 欠费：网络失败一律报错退出，不当作已付费
 *  5. 402 ≠ 数据缺失：402 只表示待支付，退出码 2
 *
 * 退出码：0 已付费放行 / 2 待支付(402) / 1 失败未交付
 *
 * 用法：
 *   node paid.mjs session  --payload payload.json     # 免费，换 session_id
 *   node paid.mjs probe                                # 探测，未付返回 402 账单（退出码 2）
 *   node paid.mjs complete --proof "$PAYMENT_PROOF"    # 带真实凭证重试（退出码 0）
 *   node paid.mjs status                               # 查单
 *   node paid.mjs --help
 *
 * 环境变量：
 *   PAY_API_BASE     必填，如 https://pay.example.com
 *   PAYMENT_PROOF    支付宝下发的 Payment-Proof（Base64）
 *   PAY_CACHE_DIR    默认同目录 .pay_cache
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CACHE_DIR = process.env.PAY_CACHE_DIR || path.join(__dirname, '..', '.pay_cache');
const STATE_FILE = path.join(CACHE_DIR, 'state.json');
const CONFIG_FILE = process.env.PAY_CONFIG || path.join(__dirname, '..', 'payment_service.json');

const EXIT_OK = 0;
const EXIT_FAIL = 1;
const EXIT_PAY = 2;

function die(code, message, extra = {}) {
  // fail-closed：任何异常都不输出业务内容
  console.log(JSON.stringify({ ok: false, error: { code, message, ...extra } }, null, 2));
  process.exit(EXIT_FAIL);
}

function help() {
  console.log(`用法：
  node paid.mjs session  --payload payload.json    免费提交本次输入，换 session_id
  node paid.mjs probe                               探测付费状态（未付返回账单，退出码 2）
  node paid.mjs complete --proof <Payment-Proof>    携带真实支付凭证重试，验付通过后退出码 0
  node paid.mjs status                              查询当前订单状态
  node paid.mjs --help

环境变量：PAY_API_BASE（必填）、PAYMENT_PROOF、PAY_CACHE_DIR
退出码：0 已付费放行 / 2 待支付 / 1 失败`);
}

function readJson(p, fallback = null) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; }
}
function writeState(patch) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
  const cur = readJson(STATE_FILE, {}) || {};
  fs.writeFileSync(STATE_FILE, JSON.stringify({ ...cur, ...patch, updated_at: new Date().toISOString() }, null, 2));
}

function loadConfig() {
  const cfg = readJson(CONFIG_FILE, null);
  if (!cfg || !cfg.resource_id) {
    die('Config-Missing', `未找到有效配置：${CONFIG_FILE}（需含 resource_id）`);
  }
  return cfg;
}

function apiBase() {
  // 端点优先级：环境变量 PAY_API_BASE（私有部署/联调）优先，未设置时回落到包内 payment_service.json.endpoint，
  // 保证买家零配置也能直接跑（不需要买家 export 任何变量）。
  let raw = (process.env.PAY_API_BASE || '').trim();
  if (!raw) {
    const cfg = readJson(CONFIG_FILE, null) || {};
    raw = (cfg.endpoint || cfg.api_base || cfg.pay_api_base || '').trim();
  }
  if (!raw) die('EndpointUnconfigured', '未配置 402 服务端：包内 payment_service.json 缺 endpoint，且未设置 PAY_API_BASE。未配置时本技能拒绝交付。');
  let url;
  try { url = new URL(raw); } catch { die('EndpointInvalid', `PAY_API_BASE 不是合法 URL：${raw}`); }
  if (url.protocol !== 'https:' && url.hostname !== 'localhost') {
    // 允许 http 仅当显式 SELFTEST=1（本机联调用），否则必须有 TLS
    if (process.env.PAY_SELFTEST !== '1') die('EndpointInsecure', 'PAY_API_BASE 必须是 HTTPS（正式收款不允许明文 HTTP）');
  }
  const h = url.hostname;
  const isLocal = h === 'localhost' || h === '127.0.0.1' || h === '::1' || h === '0.0.0.0' || h.endsWith('.local')
    || /^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(h);
  if (isLocal) die('EndpointLocalhost', `PAY_API_BASE 指向本机/内网（${h}），买家无法访问，等于没有服务端。请改成公网 HTTPS 地址。`);
  return raw.replace(/\/$/, '');
}

async function call(method, url, { proof = '', body = null } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (proof) headers['Payment-Proof'] = proof;
  let res;
  try {
    res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch (err) {
    die('Network-Failed', `请求 ${url} 失败：${err && err.message}。断网不等于欠费，未交付任何内容。`);
  }
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* 保留原文 */ }
  return {
    status: res.status,
    headers: {
      amtPaymentLink: res.headers.get('amtPaymentLink') || '',
      paymentNeeded: res.headers.get('Payment-Needed') || '',
    },
    json,
    text,
  };
}

function requireSession() {
  const st = readJson(STATE_FILE, {}) || {};
  const sid = (process.env.A2M_SESSION_ID || st.session_id || '').trim();
  if (!sid) die('Session-Required', '请先执行 `paid.mjs session --payload payload.json` 提交本次输入（免费），再探测支付。');
  return sid;
}

async function main() {
  const args = process.argv.slice(2);
  const cmd = args[0];
  if (!cmd || cmd === '--help' || cmd === '-h') { help(); process.exit(cmd ? EXIT_OK : EXIT_FAIL); }

  const cfg = loadConfig();
  const base = apiBase();
  const resourceId = process.env.PAY_RESOURCE_ID || cfg.resource_id;
  const tier = process.env.PAY_TIER || cfg.tier_fen || '';
  const tierPath = tier ? `${base}/t/${tier}/resource` : `${base}/resource`;

  const flag = (name, dflt = '') => {
    const i = args.indexOf('--' + name);
    return i >= 0 && args[i + 1] ? args[i + 1] : dflt;
  };

  if (cmd === 'session') {
    const payloadPath = flag('payload');
    if (!payloadPath) die('Payload-Missing', '请用 --payload 指定本次输入文件（JSON）。未提交输入不产生账单。');
    const payload = readJson(path.resolve(payloadPath), null);
    if (!payload || typeof payload !== 'object' || Array.isArray(payload) || !Object.keys(payload).length) {
      die('Payload-Empty', 'payload 必须是包含本次输入内容的非空 JSON 对象。');
    }
    // 数据最小化：只上传资源标识、输入长度与 SHA-256 摘要，不上传 diff 正文。
    const rawText = JSON.stringify(payload);
    const payload_len = rawText.length;
    const digest = crypto.createHash('sha256').update(rawText, 'utf8').digest('hex');
    // 收款服务仅用于计费与授权，无法还原用户代码内容。
    const body = { resource_id: resourceId, payload_len, payload_sha256: digest };
    const r = await call('POST', `${base}/session`, { body });
    if (r.status !== 200 || !r.json || !r.json.session_id) {
      die('Session-Failed', `提交输入失败（HTTP ${r.status}）：${r.json ? r.json.message || r.json.code : r.text.slice(0, 200)}`);
    }
    writeState({ resource_id: resourceId, session_id: r.json.session_id, out_trade_no: null, paid: false, api_base: base, payload_sha256: digest });
    console.log(JSON.stringify({ ok: true, session_id: r.json.session_id, resource_id: resourceId, price: r.json.price, payload_sha256: digest, payload_len }, null, 2));
    process.exit(EXIT_OK);
  }

  if (cmd === 'probe') {
    const sid = requireSession();
    const r = await call('GET', `${tierPath}?resource_id=${encodeURIComponent(resourceId)}&session_id=${encodeURIComponent(sid)}`);
    if (r.status === 402) {
      writeState({ out_trade_no: r.json && r.json.out_trade_no, paid: false, amt_payment_link: r.headers.amtPaymentLink });
      console.log(JSON.stringify({
        ok: true,
        status: 402,
        payment_needed: true,
        resource_id: resourceId,
        out_trade_no: r.json && r.json.out_trade_no,
        amount: r.json && r.json.amount,
        currency: (r.json && r.json.currency) || 'CNY',
        goods_name: r.json && r.json.goods_name,
        pay_before: r.json && r.json.pay_before,
        pay_link: r.headers.amtPaymentLink,
        next: '完成支付宝支付后，用平台下发的 Payment-Proof 执行 complete',
      }, null, 2));
      process.exit(EXIT_PAY);
    }
    if (r.status === 200 && r.json && r.json.authorized) {
      writeState({ paid: true, out_trade_no: r.json.out_trade_no });
      console.log(JSON.stringify({ ok: true, authorized: true, idempotent: true, ...r.json }, null, 2));
      process.exit(EXIT_OK);
    }
    die('Probe-Failed', `探测失败（HTTP ${r.status}）：${r.json ? r.json.message || r.json.code : r.text.slice(0, 200)}`);
  }

  if (cmd === 'complete') {
    const proof = (flag('proof') || process.env.PAYMENT_PROOF || process.env.X_PAYMENT_PROOF || '').trim();
    if (!proof) {
      die('Proof-Missing', '缺少真实 Payment-Proof。本技能不允许自拼凭证：请在支付宝完成支付后，把平台下发的 Payment-Proof 通过 --proof 或 PAYMENT_PROOF 传入。');
    }
    // 只做结构自检，防止误传文件路径之类的脏值；不做任何“本地判定已付费”
    if (!/^[A-Za-z0-9+/=]+$/.test(proof) || proof.length < 24) {
      die('Proof-Invalid', 'Payment-Proof 格式非法（应为 Base64）。伪造或自拼的凭证一律拒绝。');
    }
    const sid = requireSession();
    const r = await call('GET', `${tierPath}?resource_id=${encodeURIComponent(resourceId)}&session_id=${encodeURIComponent(sid)}`, { proof });
    if (r.status === 200 && r.json && r.json.authorized) {
      writeState({ paid: true, out_trade_no: r.json.out_trade_no, trade_no: r.json.trade_no });
      console.log(JSON.stringify({
        ok: true,
        authorized: true,
        resource_id: resourceId,
        out_trade_no: r.json.out_trade_no,
        trade_no: r.json.trade_no,
        amount: r.json.amount,
        session_id: r.json.session_id,
        unlock: r.json.unlock,
        fulfillment: r.json.fulfillment,
      }, null, 2));
      process.exit(EXIT_OK);
    }
    die('Verify-Failed', `验付未通过（HTTP ${r.status}）：${r.json ? r.json.message || r.json.code : r.text.slice(0, 200)}。未交付任何内容。`);
  }

  if (cmd === 'status') {
    const st = readJson(STATE_FILE, {}) || {};
    const no = flag('order') || st.out_trade_no;
    if (!no) die('Order-Unknown', '当前没有已知订单，请先 probe。');
    const r = await call('GET', `${base}/orders/${encodeURIComponent(no)}`);
    console.log(JSON.stringify({ ok: r.status === 200, ...(r.json || { raw: r.text.slice(0, 200) }) }, null, 2));
    process.exit(r.status === 200 ? EXIT_OK : EXIT_FAIL);
  }

  die('Unknown-Command', `未知命令：${cmd}`);
}

main().catch((err) => die('Unhandled', String(err && err.message ? err.message : err)));
