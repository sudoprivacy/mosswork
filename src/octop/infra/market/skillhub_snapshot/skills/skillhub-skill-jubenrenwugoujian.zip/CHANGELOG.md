# 更新日志

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2026-05-23

### Added

- 初始版本发布
- 九大维度角色分析体系
- 五阶段工作流程
- 完整的角色原型档案模板
- 提示词模板库
- 角色一致性检查清单
- 多种AI工具集成支持
- 中英文双语支持

### Features

- **剧本解析**：支持剧本文本自动拆解和角色提取
- **原型构建**：基于九大维度进行全面分析
- **档案生成**：输出完整的角色原型档案
- **提示词生成**：支持中文和英文AI绘图提示词
- **一致性检查**：完整的多维度检查清单

### Dimensions

1. 人物特点 - 年龄、性别、体型、身份特征
2. 面部特征 - 脸型、五官、肤色、表情
3. 服饰装扮 - 服装款式、颜色、材质、配件
4. 道具设定 - 武器、工具、装饰物
5. 动作规范 - 身体姿态、手势、动态
6. 性格描述 - 性格关键词、行为模式
7. 背景设定 - 成长经历、动机、冲突
8. 色彩方案 - 主色调、配色方案
9. 风格标签 - 艺术流派、参考作品

### Workflow Stages

1. 剧本解析
2. 原型构建
3. 角色设计
4. 分镜规划
5. 视频合成

### File Structure

```
剧本人物原型构建/
├── SKILL.md                    # 主技能文件
├── config.json                 # 配置文件
├── metadata.json               # 元数据
├── _meta.json                 # 发布元数据
├── CHANGELOG.md               # 更新日志
└── references/
    ├── character-profile-template.md   # 角色原型档案模板
    ├── prompt-templates.md             # 提示词模板库
    └── checklist.md                   # 一致性检查清单
```

---

## [Unreleased]

### Planned Features

- [ ] 支持更多AI绘图工具
- [ ] 增加角色关系图谱生成
- [ ] 支持批量角色分析
- [ ] 增加剧本格式自动识别
- [ ] 支持团队协作功能
