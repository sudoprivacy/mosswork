# 多态分析详解

> 本文档详细说明剧本人物原型构建技能中的多态分析功能

---

## 1. 什么是多态分析

### 1.1 定义

**多态分析**是指识别和分析同一角色在不同条件下的表现差异。在剧本中，一个角色不可能从头到尾保持完全相同的状态，他们会在不同场景、不同时间点、不同情绪状态下表现出不同的特征。

### 1.2 为什么需要多态分析

传统角色分析往往只关注角色的"标准形象"，但实际上：

1. **场景变化**：角色在家和工作场所的打扮可能完全不同
2. **时间变化**：角色从青年到中年，外貌和气质都会发生变化
3. **情绪变化**：同一角色在愤怒和喜悦时的表情、姿态完全不同
4. **身份变化**：角色在职场和家庭中可能表现不同

### 1.3 多态分析的价值

- **真实性**：让角色更立体、更真实
- **一致性**：明确哪些特征必须保持不变
- **可控性**：在变化中保持角色核心认同
- **效率性**：快速生成不同场景下的角色变体

---

## 2. 四种多态类型

### 2.1 场景态（Scene State）

**定义**：同一角色在不同场景中的表现差异

**常见场景分类**：

| 场景类型 | 服饰变化 | 表情变化 | 动作变化 |
|----------|----------|----------|----------|
| 日常 | 居家服、休闲装 | 放松、自然 | 随意、放松 |
| 工作 | 职业装、制服 | 专注、严肃 | 规范、得体 |
| 正式 | 正装、礼服 | 端庄、礼貌 | 正式、得体 |
| 社交 | 时尚、个性 | 友好、热情 | 活跃、互动 |
| 私密 | 睡衣、浴袍 | 真实、脆弱 | 放松、私密 |

**分析要点**：

```
【场景态分析】
1. 识别剧本中的所有场景
2. 标记角色在各场景中的首次出场
3. 提取每个场景中角色的：
   - 服饰描述
   - 表情描述
   - 动作描述
   - 语气描述
4. 识别场景间的差异点
5. 定义核心不变特征
```

### 2.2 时间态（Timeline State）

**定义**：同一角色在不同时间点的变化

**时间维度**：

| 时间类型 | 跨度 | 变化内容 |
|----------|------|----------|
| 人生阶段 | 童年/少年/青年/中年/老年 | 外貌、体型、气质 |
| 时间线 | 过去/现在/未来 | 服饰风格、妆容、道具 |
| 特定时间 | 白天/夜晚、工作日/周末 | 精神状态、装扮 |
| 时间跨度 | 短（一天内）/中（一段时间）/长（数年） | 渐进变化 |

**分析要点**：

```
【时间态分析】
1. 识别剧本中的时间线
2. 标记关键时间节点
3. 提取每个时间点的角色特征：
   - 外貌变化（年龄感）
   - 发型变化
   - 体型变化
   - 服饰风格变化
   - 气质变化
4. 识别变化规律
5. 定义核心身份特征
```

### 2.3 情绪态（Emotion State）

**定义**：同一角色在不同情绪下的表现差异

**情绪类型**：

| 情绪 | 表情特征 | 眼神特征 | 身体语言 | 语言特点 |
|------|----------|----------|----------|----------|
| 喜悦 | 笑容、眼角上扬 | 明亮、弯弯 | 舒展、开放 | 轻快、上扬 |
| 愤怒 | 眉头紧锁、咬牙 | 凌厉、充血 | 僵硬、握拳 | 严厉、尖锐 |
| 悲伤 | 嘴角下垂、眼眶泛红 | 暗淡、无神 | 萎靡、蜷缩 | 低沉、断续 |
| 恐惧 | 瞪眼、张嘴 | 睁大、惊恐 | 僵硬、退缩 | 颤抖、结巴 |
| 惊讶 | 眉毛上挑、嘴微张 | 睁大、聚焦 | 僵住、后退 | 高升、停顿 |
| 冷漠 | 面无表情、眼神空洞 | 空洞、遥远 | 静止、封闭 | 平淡、机械 |
| 紧张 | 吞咽、抿嘴 | 闪躲、游移 | 小动作多 | 支吾、重复 |

**分析要点**：

```
【情绪态分析】
1. 识别剧本中的情绪场景
2. 提取角色在各情绪状态下的表现：
   - 面部表情
   - 眼神变化
   - 身体姿态
   - 手部动作
   - 语言语气
3. 建立情绪-表现映射表
4. 定义核心表情特征（情绪中立时）
```

### 2.4 身份态（Identity State）

**定义**：同一角色在不同身份角色下的表现差异

**身份维度**：

| 身份类型 | 服饰差异 | 言行差异 | 道具差异 |
|----------|----------|----------|----------|
| 职业身份 | 制服vs便装 | 专业术语vs日常用语 | 职业工具 |
| 家庭身份 | 父母/子女/配偶 | 亲情表达vs指责 | 家庭物品 |
| 社交身份 | 公众形象vs私下 | 得体vs真实 | 社交道具 |
| 秘密身份 | 伪装vs真实 | 掩饰vs暴露 | 特殊道具 |

**分析要点**：

```
【身份态分析】
1. 识别角色的多重身份
2. 分析每个身份的表现特征：
   - 服饰选择
   - 言谈举止
   - 道具使用
   - 态度立场
3. 识别身份间的冲突
4. 定义核心身份认同
```

---

## 3. 多态分析矩阵

### 3.1 完整多态分析模板

```markdown
## 【角色名】多态分析矩阵

### 核心不变特征（Immutable Features）

| 维度 | 特征 | 跨状态一致性保证 |
|------|------|------------------|
| 脸型 | | 必须一致 |
| 眼形 | | 必须一致 |
| 眼色 | | 必须一致 |
| 肤色 | | 必须一致 |
| 体型比例 | | 必须一致 |
| 核心性格 | | 必须一致 |
```

### 3.2 场景态矩阵

| 场景 | 发型 | 服装 | 妆容 | 表情 | 动作 | 道具 |
|------|------|------|------|------|------|------|
| 日常 | | | | | | |
| 工作 | | | | | | |
| 正式 | | | | | | |
| 社交 | | | | | | |
| 私密 | | | | | | |

### 3.3 时间态矩阵

| 时间 | 发型 | 面容 | 体型 | 气质 | 服装风格 |
|------|------|------|------|------|----------|
| 过去 | | | | | |
| 现在 | | | | | |
| 未来 | | | | | |

### 3.4 情绪态矩阵

| 情绪 | 表情 | 眼神 | 眉毛 | 嘴角 | 动作 |
|------|------|------|------|------|------|
| 中性 | | | | | |
| 喜悦 | | | | | |
| 愤怒 | | | | | |
| 悲伤 | | | | | |
| 恐惧 | | | | | |
| 惊讶 | | | | | |
| 冷漠 | | | | | |

---

## 4. 多态分析实操流程

### 4.1 步骤一：角色提取

1. 阅读剧本，标记所有角色名首次出现的位置
2. 汇总每个角色的所有描述片段
3. 识别角色的戏份权重（主演/配角/客串）

### 4.2 步骤二：场景识别

1. 识别剧本中的所有场景
2. 标记场景转换点
3. 提取每个场景的时间/地点信息
4. 汇总角色在各场景的出现

### 4.3 步骤三：逐维度提取

对每个角色，逐维度提取信息：

```
维度1：人物特点
- 从剧本中提取年龄相关信息
- 提取性别、种族描述
- 提取职业信息
- 提取体型描述

维度2：面部特征
- 提取所有面部描述
- 识别核心面部特征
- 标记描述差异

维度3：服饰装扮
- 按场景提取服饰描述
- 识别服饰变化点
- 定义基准服饰

...（其他维度类似）
```

### 4.4 步骤四：多态识别

1. 对比同一角色在不同场景的描述
2. 识别描述差异
3. 判断是否为同一角色的不同表现
4. 还是不同角色（同名）

### 4.5 步骤五：一致性规范定义

```
【角色名】一致性规范

核心特征（绝对不变）：
- 脸型：[描述]
- 眼睛：[描述]
- 肤色：[描述]
- 体型：[描述]
- 核心性格：[描述]

可变特征（可随状态变化）：
- 发型：场景态A/场景态B
- 服装：场景态A/场景态B
- 表情：情绪态A/情绪态B
```

---

## 5. 多态提示词生成

### 5.1 核心态提示词（不变特征）

```json
{
  "character": "[角色名]",
  "core_prompt": {
    "zh": "[年龄]岁[性别], [核心面部描述], [核心发型], [核心服装风格], [核心性格]",
    "en": "[age] year old [gender], [core facial features], [core hairstyle], [core clothing style], [core personality]"
  },
  "negative_prompt": "different face, different eyes, different hair color, anime, cartoon"
}
```

### 5.2 场景态提示词（可变特征）

```json
{
  "character": "[角色名]",
  "scene_states": {
    "daily": {
      "prompt": "[核心特征] + [日常服装] + [日常表情] + [日常动作]"
    },
    "work": {
      "prompt": "[核心特征] + [工作服装] + [工作表情] + [工作动作]"
    },
    "formal": {
      "prompt": "[核心特征] + [正式服装] + [正式表情] + [正式动作]"
    }
  }
}
```

### 5.3 情绪态提示词

```json
{
  "character": "[角色名]",
  "emotion_states": {
    "neutral": {
      "prompt": "[核心特征] + [中性表情]"
    },
    "happy": {
      "prompt": "[核心特征] + [开心表情] + [开放动作]"
    },
    "angry": {
      "prompt": "[核心特征] + [愤怒表情] + [紧张动作]"
    }
  }
}
```

---

## 6. 多态分析案例

### 案例：职场女性的多态表现

**角色**：李华，32岁女性，广告公司创意总监

**核心不变特征**：
- 脸型：椭圆形
- 眼型：丹凤眼，眼色为深棕色
- 肤色：白皙
- 体型：标准身材，165cm

**场景态变化**：

| 场景 | 发型 | 妆容 | 服装 | 配饰 |
|------|------|------|------|------|
| 日常 | 马尾辫 | 淡妆 | 休闲装 | 少 |
| 工作 | 利落盘发 | 专业妆 | 西装套裙 | 简约手表 |
| 正式 | 精致卷发 | 精致妆 | 高定礼服 | 珠宝 |

**情绪态变化**：

| 情绪 | 表情 | 眼神 | 动作 |
|------|------|------|------|
| 中性 | 职业微笑 | 平和 | 双手交叠 |
| 喜悦 | 真诚笑容 | 弯弯 | 拍手 |
| 愤怒 | 抿嘴 | 冷峻 | 单手叉腰 |
| 悲伤 | 眼眶泛红 | 低垂 | 低头 |

---

## 7. 常见问题

### Q1：如何判断是同一角色的多态还是不同角色？

**判断标准**：
1. 姓名是否相同
2. 描述是否有连续性
3. 性格是否有延续性
4. 是否有明确的身份转换说明

### Q2：描述冲突时如何处理？

**处理原则**：
1. 以首次出现的描述为准
2. 考虑场景合理性
3. 标记冲突点
4. 选择更详细的描述

### Q3：如何处理没有明确描述的维度？

**处理原则**：
1. 标记为"未明确"
2. 根据角色背景推测
3. 参考类似角色
4. 使用默认值

---

## 8. 多态分析检查清单

### 场景态检查
- [ ] 是否识别了所有场景
- [ ] 是否提取了每个场景的服饰描述
- [ ] 是否识别了场景间的差异
- [ ] 是否定义了核心服饰

### 时间态检查
- [ ] 是否梳理了时间线
- [ ] 是否识别了外貌变化
- [ ] 是否定义了基准形象

### 情绪态检查
- [ ] 是否覆盖了主要情绪
- [ ] 是否提取了表情关键词
- [ ] 是否建立了情绪-表现映射

### 身份态检查
- [ ] 是否识别了多重身份
- [ ] 是否分析了身份间差异
- [ ] 是否定义了核心身份

---

## 9. 情绪态完整提示词模板（白底标准）

### 情绪态提示词生成规则

**结构**：
```
front-facing portrait of [character],
close-up on face,
[face shape],
[眉部描述],
[眼形] [眼色] eyes,
[nose],
[唇色] lips,
[肤质] skin,
**[情绪名称] expression**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 中性表情

```
front-facing portrait of [character],
close-up on face,
[face shape],
neutral expressionless face,
relaxed brows,
[eye color] eyes with [gaze type],
[nose],
[lip color] lips,
[skin type] skin,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 喜悦/微笑

```
front-facing portrait of [character],
close-up on face,
[face shape],
**happy smile expression**,
relaxed eyebrows,
[eye color] eyes with warmth and joy,
[nose],
[lip color] lips slightly curved up,
[skin type] skin,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 愤怒

```
front-facing portrait of [character],
close-up on face,
[face shape],
**angry expression**,
furrowed angry brows,
[eye color] intense eyes with anger,
[nose],
tight pressed lips,
[skin type] skin showing tension,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 悲伤

```
front-facing portrait of [character],
close-up on face,
[face shape],
**sad melancholic expression**,
slightly furrowed sad brows,
[eye color] dim eyes with sorrow,
[nose],
downturned lips,
[skin type] skin showing weariness,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 恐惧/惊恐

```
front-facing portrait of [character],
close-up on face,
[face shape],
**fearful shocked expression**,
raised startled brows,
[eye color] wide terrified eyes,
[nose],
slightly open trembling lips,
[skin type] skin showing fear,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 惊讶

```
front-facing portrait of [character],
close-up on face,
[face shape],
**surprised expression**,
eyebrows raised in surprise,
[eye color] wide startled eyes,
[nose],
mouth slightly open,
[skin type] skin,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 冷漠/木然

```
front-facing portrait of [character],
close-up on face,
[face shape],
**emotionless blank expression**,
flat neutral brows,
[eye color] empty distant eyes,
[nose],
straight neutral lips,
[skin type] skin,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

**文档版本**：2.0
**最后更新**：2026-05-23
**更新内容**：添加情绪态完整提示词模板（白底标准）
