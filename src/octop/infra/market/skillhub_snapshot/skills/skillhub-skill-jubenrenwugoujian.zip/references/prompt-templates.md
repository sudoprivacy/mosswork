# 提示词模板库 v5.0（面部重点版·白底标准）

> 用于快速生成角色AI绘图提示词
> **核心更新 v5.0**：面部重点——3张正侧脸 + 情绪态完整模板

---

## 1. 面部特征描述模板

### 正面脸部描述

```
[年龄]岁[性别]，
[脸型]，
[眉形][眉色]眉，
[眼形][眼色]眼，
[鼻形]，
[唇形][唇色]唇，
[肤色]肌肤，
[表情]
```

**示例**：
```
35岁男性，
棱角分明脸，
剑眉浓黑，
深邃[眼形]眼，
高鼻梁，
薄唇，
健康肤色肌肤，
冷漠表情
```

### 侧面脸部描述

```
[年龄]岁[性别]，
[脸型]，
左侧/右侧轮廓，
[侧面眉形]，
[侧面眼形]，
[鼻梁侧影]，
[肤名]肌肤
```

---

## 2. 九宫格提示词模板（面部重点·白底标准）

### 格子1：正面脸部（柔和表情）

```
front-facing portrait of [character],
close-up on face,
[face shape], [eyebrows], [eyes], [nose], [lips],
[skin tone],
**gentle relaxed expression**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子2：正面脸部（情绪表情）

```
front-facing portrait of [character],
close-up on face,
[face shape], [eyebrows], [eyes], [nose], [lips],
[skin tone],
**[emotion] expression**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子3：左侧脸特写

```
left side profile close-up of [character]'s face,
[face shape], left cheekbone visible,
[side eyebrow], [side eye], [nose profile],
[skin tone],
**[expression]**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子4：右侧脸特写

```
right side profile close-up of [character]'s face,
[face shape], right cheekbone visible,
[side eyebrow], [side eye], [nose profile],
[skin tone],
**[expression]**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子5：正面半身照

```
front view half-body portrait of [character],
waist-up shot,
[hairstyle], [upper outfit],
**[expression]**,
[accessories],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子6：眼部特写

```
extreme close-up of [character]'s eyes,
[eye shape], [eye color],
**[gaze description]**,
[eyelashes], [eyebrows],
catch lights visible,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子7：正面全身照

```
front view full body shot of [character],
standing pose, full body in frame,
[hairstyle], [full outfit],
[shoes], [pose],
[accessories],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子8：背面全身照

```
back view full body shot of [character],
back facing camera, full body in frame,
[hair back], [outfit back],
[overall silhouette],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 格子9：配饰/手部特写

```
detail shot of [character]'s [accessory],
[accessory description],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

## 3. 情绪态提示词模板（白底标准）

### 中性表情

```
[character],
close-up on face,
[face shape],
**neutral expressionless face**,
relaxed brows, [eye color] eyes,
[nose], [lip color] lips,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 喜悦/微笑

```
[character],
close-up on face,
[face shape],
**happy smile expression**,
relaxed eyebrows,
[eye color] eyes with warmth,
soft smile showing [teeth/no teeth],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 愤怒

```
[character],
close-up on face,
[face shape],
**angry expression**,
furrowed brows,
[eye color] intense eyes,
tight lips, clenched jaw,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 悲伤

```
[character],
close-up on face,
[face shape],
**sad melancholic expression**,
slightly furrowed brows,
[eye color] dim eyes,
downturned lips,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 恐惧/惊恐

```
[character],
close-up on face,
[face shape],
**fearful shocked expression**,
raised eyebrows,
[eye color] wide eyes,
slightly open mouth,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 惊讶

```
[character],
close-up on face,
[face shape],
**surprised expression**,
eyebrows raised,
[eye color] wide open eyes,
mouth slightly open,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 冷漠/木然

```
[character],
close-up on face,
[face shape],
**emotionless blank expression**,
flat eyebrows,
[eye color] empty distant gaze,
straight neutral lips,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

## 4. 负面提示词模板

### 通用负面

```
ugly, disfigured, bad anatomy, bad proportions,
extra limbs, missing limbs, floating limbs,
disconnected limbs, poorly drawn face,
mutation, mutated, ugly, disgusting,
bad hands, extra fingers, fewer fingers,
cross-eyed, wall-eyed, asymmetric eyes,
bad teeth, missing teeth, extra teeth,
bad skin, bad texture, bad complexion,
overly smooth skin, plastic skin,
blur, blurry, out of focus,
low resolution, pixelated,
watermark, text, logo, signature,
cropped, worst quality, low quality,
normal quality, jpeg artifacts,
anime, cartoon, 3d render, cgi
```

### 白底图额外负面

```
**background with patterns, background with scenery,
outdoor background, dark background,
gradient background, colored background,
text on background, logo on background,
shadow on background, reflection on background**
```

---

## 5. 快速参考表

### 脸型词汇

| 中文 | 英文 |
|------|------|
| 圆形 | round |
| 方形 | square |
| 椭圆形 | oval |
| 长方形 | oblong |
| 菱形 | diamond |
| 心形 | heart-shaped |

### 眼形词汇

| 中文 | 英文 |
|------|------|
| 杏眼 | almond eyes |
| 圆眼 | round eyes |
| 丹凤眼 | phoenix eyes |
| 桃花眼 | peach blossom eyes |
| 细长眼 | narrow eyes |

### 眉形词汇

| 中文 | 英文 |
|------|------|
| 剑眉 | sword eyebrows |
| 柳叶眉 | willow eyebrows |
| 平眉 | flat eyebrows |
| 浓眉 | thick eyebrows |
| 弯眉 | curved eyebrows |

### 鼻形词汇

| 中文 | 英文 |
|------|------|
| 高鼻梁 | high nose bridge |
| 鹰钩鼻 | aquiline nose |
| 蒜头鼻 | bulbous nose |
| 直鼻 | straight nose |
| 塌鼻 | flat nose |

### 唇形词汇

| 中文 | 英文 |
|------|------|
| 薄唇 | thin lips |
| 厚唇 | thick lips |
| 樱桃唇 | cherry lips |
| 嘟嘟唇 | pouty lips |

### 表情词汇

| 中文 | 英文 |
|------|------|
| 微笑 | smile |
| 大笑 | laugh |
| 皱眉 | frown |
| 严肃 | serious |
| 愤怒 | angry |
| 惊讶 | surprised |
| 悲伤 | sad |
| 冷漠 | indifferent |
| 柔和 | gentle |
| 空洞 | empty |

### 光线词汇（白底标准）

| 中文 | 英文 |
|------|------|
| 纯白背景 | pure white seamless background |
| 影棚柔光 | studio soft lighting |
| 中性背景 | neutral studio backdrop |

---

**模板版本**：5.0
**最后更新**：2026-05-23
**核心更新**：面部重点九宫格（3正侧脸+眼部特写）+ 情绪态完整模板
