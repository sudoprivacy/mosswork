# 九宫格角色展示图模板 v5.0（面部重点版）

> 本文档定义角色九宫格展示图的标准格式和提示词模板
> **核心更新 v5.0**：面部重点——3张正侧脸（正面x2 + 左侧 + 右侧）+ 眼部特写

---

## 1. 九宫格布局（面部重点版）

```
┌─────────────────┬─────────────────┬─────────────────┐
│                 │                 │                 │
│   1 正面脸部    │   2 正面脸部    │   3 左侧脸部    │
│   （柔和表情）  │   （情绪表情）  │   特写          │
│                 │                 │                 │
├─────────────────┼─────────────────┼─────────────────┤
│                 │                 │                 │
│   4 右侧脸部    │   5 正面半身    │   6 眼部特写    │
│   特写          │   照            │                 │
│                 │                 │                 │
├─────────────────┼─────────────────┼─────────────────┤
│                 │                 │                 │
│   7 正面全身    │   8 背面全身    │   9 配饰/手部   │
│   照            │   照            │   特写          │
│                 │                 │                 │
└─────────────────┴─────────────────┴─────────────────┘
```

---

## 2. 白底摄影棚标准

### 背景标准（必须）
- **纯白无缝背景**：#FFFFFF
- 无阴影、无渐变、无图案
- 背景亮度均匀

### 灯光标准（必须）
- **影棚柔光**：使用散射光源
- **三灯布光**：
  - 主光：正面或侧正面
  - 补光：对侧约45度
  - 轮廓光：背面分离主体

### 面部拍摄标准
- 面部占画面60%以上（特写）
- 眼睛位于画面中央或三分线
- 保持眼神清晰

---

## 3. 各格子定义与白底提示词

### 格子1：正面脸部特写（柔和表情）

| 属性 | 说明 |
|------|------|
| 名称 | 正面脸部（柔和表情） |
| 景别 | 面部特写 |
| 视角 | 完全正面 |
| 重点 | 五官细节、柔和表情 |

**提示词模板（白底标准）**：
```
front-facing portrait of [character name],
close-up shot on face,
[face shape], [eyebrows], [eyes], [nose], [lips],
[skin tone],
**gentle relaxed expression**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子2：正面脸部特写（情绪表情）

| 属性 | 说明 |
|------|------|
| 名称 | 正面脸部（情绪表情） |
| 景别 | 面部特写 |
| 视角 | 完全正面 |
| 重点 | 五官细节、具体情绪 |

**提示词模板（白底标准）**：
```
front-facing portrait of [character name],
close-up shot on face,
[face shape], [eyebrows], [eyes], [nose], [lips],
[skin tone],
**[emotion] expression**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子3：左侧脸特写

| 属性 | 说明 |
|------|------|
| 名称 | 左侧脸特写 |
| 景别 | 面部侧面特写 |
| 视角 | 完全左侧 |
| 重点 | 侧脸轮廓、颧骨、侧眉眼 |

**提示词模板（白底标准）**：
```
left side profile close-up of [character name]'s face,
[face shape], left cheekbone visible,
[side eyebrow], [side eye], [nose profile],
[skin tone],
**[expression]**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子4：右侧脸特写

| 属性 | 说明 |
|------|------|
| 名称 | 右侧脸特写 |
| 景别 | 面部侧面特写 |
| 视角 | 完全右侧 |
| 重点 | 侧脸轮廓、颧骨、侧眉眼 |

**提示词模板（白底标准）**：
```
right side profile close-up of [character name]'s face,
[face shape], right cheekbone visible,
[side eyebrow], [side eye], [nose profile],
[skin tone],
**[expression]**,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子5：正面半身照

| 属性 | 说明 |
|------|------|
| 名称 | 正面半身照 |
| 景别 | 半身（腰部以上） |
| 视角 | 正面 |
| 重点 | 发型、上装、表情、配饰 |

**提示词模板（白底标准）**：
```
front view half-body portrait of [character name],
waist-up shot,
[hairstyle], [upper outfit],
**[expression]**,
[accessories],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子6：眼部特写

| 属性 | 说明 |
|------|------|
| 名称 | 眼部特写 |
| 景别 | 眼部特写 |
| 视角 | 正面 |
| 重点 | 眼睛、眼神、睫毛、眉毛 |

**提示词模板（白底标准）**：
```
extreme close-up portrait of [character name]'s eyes,
[eye shape], [eye color],
**[intense/gentle/deep] gaze**,
[eyelashes], [eyebrows],
catch lights visible,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子7：正面全身照

| 属性 | 说明 |
|------|------|
| 名称 | 正面全身照 |
| 景别 | 全身 |
| 视角 | 正面 |
| 重点 | 发型、全套服装、鞋子、站姿 |

**提示词模板（白底标准）**：
```
front view full body shot of [character name],
standing pose, full body in frame,
[hairstyle], [full outfit],
[shoes], [pose],
[accessories],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子8：背面全身照

| 属性 | 说明 |
|------|------|
| 名称 | 背面全身照 |
| 景别 | 全身 |
| 视角 | 背面 |
| 重点 | 发型背面、服装背面、整体轮廓 |

**提示词模板（白底标准）**：
```
back view full body shot of [character name],
back facing camera, full body in frame,
[hair back], [outfit back],
[overall silhouette],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

### 格子9：配饰/手部特写

| 属性 | 说明 |
|------|------|
| 名称 | 配饰/手部特写 |
| 景别 | 细节特写 |
| 视角 | 手部或配饰 |
| 重点 | 配饰细节或手部 |

**提示词模板（白底标准）**：
```
detail shot of [character name]'s [accessory],
[accessory description],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic

OR

close-up shot of [character name]'s hands,
[hand description],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

## 4. 情绪表情提示词模板

### 中性表情

```
front-facing portrait of [character],
close-up on face, [face shape],
neutral expressionless face,
relaxed brows, [eye color] eyes,
[nose], [lip color] lips,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 喜悦/微笑

```
front-facing portrait of [character],
close-up on face, [face shape],
**happy smile expression**,
relaxed eyebrows, [eye color] eyes with warmth,
soft smile showing [teeth/no teeth],
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 愤怒

```
front-facing portrait of [character],
close-up on face, [face shape],
**angry expression**,
furrowed brows, [eye color] intense eyes,
tight lips, clenched jaw,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 悲伤

```
front-facing portrait of [character],
close-up on face, [face shape],
**sad melancholic expression**,
slightly furrowed brows, [eye color] dim eyes,
downturned lips,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 恐惧/惊恐

```
front-facing portrait of [character],
close-up on face, [face shape],
**fearful shocked expression**,
raised eyebrows, [eye color] wide eyes,
slightly open mouth,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

### 冷漠/木然

```
front-facing portrait of [character],
close-up on face, [face shape],
**emotionless blank expression**,
flat eyebrows, [eye color] empty distant gaze,
straight neutral lips,
**pure white seamless background**,
**studio soft lighting**,
**neutral studio backdrop**,
ultra detailed, photorealistic
```

---

## 5. 拍摄技术参数（白底标准）

### 相机设置

| 参数 | 值 | 说明 |
|------|-----|------|
| 相机 | 全画幅单反/微单 | Sony A7系列、Canon R系列 |
| 镜头 | 85mm定焦 | 标准人像镜头 |
| 光圈 | f/4 - f/5.6 | 中等光圈保证景深 |
| 快门 | 1/125s - 1/200s | 安全快门速度 |
| ISO | 100 | 低ISO保证画质 |

### 灯光设置（白底专用）

| 灯光 | 位置 | 作用 |
|------|------|------|
| 主光 (Key Light) | 正面/侧正面 | 主要照明，柔和散射 |
| 补光 (Fill Light) | 对侧，约45度 | 减少阴影，柔和 |
| 轮廓光 (Rim Light) | 背面/侧背面 | 分离主体与白背景 |
| 背景光 (Background Light) | 打亮背景 | 均匀打白背景 |

---

## 6. 完整九宫格提示词示例（白底标准·面部重点）

### 角色示例：李华，32岁女性，广告公司创意总监

```markdown
## 九宫格展示图提示词（面部重点·白底标准）

### 【1】正面脸部特写（柔和表情）
中文：32岁女性，椭圆脸，柳叶眉，棕色杏眼，高鼻梁，薄唇，白皙肌肤，表情温和放松
英文：`front-facing portrait of Li Hua, close-up on face, oval face, willow eyebrows, brown almond eyes, high nose bridge, thin lips, fair skin, **gentle relaxed expression**, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【2】正面脸部特写（情绪表情）
中文：32岁女性，椭圆脸，柳叶眉，棕色杏眼，高鼻梁，薄唇，白皙肌肤，表情自信专业
英文：`front-facing portrait of Li Hua, close-up on face, oval face, willow eyebrows, brown almond eyes, high nose bridge, thin lips, fair skin, **confident professional expression**, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【3】左侧脸特写
中文：32岁女性，椭圆脸，左侧脸轮廓，侧面柳叶眉，侧面杏眼，高鼻梁侧影，白皙肌肤
英文：`left side profile close-up of Li Hua's face, oval face, left cheekbone visible, side willow eyebrow, side almond eye, nose profile, fair skin, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【4】右侧脸特写
中文：32岁女性，椭圆脸，右侧脸轮廓，侧面柳叶眉，侧面杏眼，高鼻梁侧影，白皙肌肤
英文：`right side profile close-up of Li Hua's face, oval face, right cheekbone visible, side willow eyebrow, side almond eye, nose profile, fair skin, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【5】正面半身照
中文：正面半身，棕色中长发，灰色职业西装，白色衬衫，简约银色手表，专业自信表情
英文：`front view half-body portrait of Li Hua, waist-up shot, brown medium wavy hair, grey blazer, white blouse, **confident professional expression**, silver wristwatch, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【6】眼部特写
中文：眼部特写，棕色杏眼，眼神坚定专注，卷翘睫毛，自然眉形，目光温和有力
英文：`extreme close-up of Li Hua's eyes, brown almond eyes, **determined focused gaze**, curled lashes, natural eyebrows, catch lights visible, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【7】正面全身照
中文：正面全身，站立姿势，棕色短发利落，灰色职业套装，黑色高跟鞋，双手自然下垂
英文：`front view full body shot of Li Hua, standing pose, full body in frame, neat brown short hair, grey professional suit, black heels, hands at sides, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【8】背面全身照
中文：背面全身，棕色短发利落，灰色西装外套背面，白色衬衫后背，职业女性轮廓
英文：`back view full body shot of Li Hua, back facing camera, full body in frame, neat brown short hair, grey blazer back, white blouse back, professional silhouette, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`

### 【9】配饰/手部特写
中文：手部特写，修长手指，淡粉色指甲油，简约银色戒指，手背静脉隐约可见
英文：`close-up of Li Hua's hands, slender fingers, natural pink nail polish, thin silver ring, visible veins on hand back, **pure white seamless background**, **studio soft lighting**, **neutral studio backdrop**, ultra detailed, photorealistic`
```

---

## 7. 九宫格生成检查清单（面部重点版）

### 拍摄前检查
- [x] 纯白无缝背景已准备
- [x] 影棚柔光已设置
- [x] 背景打光均匀
- [x] 角色核心面部特征已定义
- [x] 各角度描述已准备（正面x2 + 左侧 + 右侧）
- [x] 情绪表情已确定

### 生成后检查（面部一致性）
- [x] 九宫格比例正确（3x3）
- [x] 脸部占画面60%以上
- [x] 正面脸部（格子1、2）脸型一致
- [x] 左侧脸（格子3）与正面脸型一致
- [x] 右侧脸（格子4）与正面脸型一致
- [x] 眼形、眼色一致
- [x] 鼻形一致
- [x] 唇形一致
- [x] 肤色基调一致
- [x] **背景为纯白无缝**
- [x] **灯光为影棚柔光**

---

**模板版本**：5.0
**最后更新**：2026-05-23
**核心更新**：面部重点九宫格（3正侧脸+眼部特写）+ 情绪态完整模板
