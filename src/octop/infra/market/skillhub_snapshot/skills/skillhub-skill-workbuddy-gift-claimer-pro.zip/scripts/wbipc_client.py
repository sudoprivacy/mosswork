"""WBIPC official-channel client (v3.3.3, host-injected login state).

  * WorkBuddy desktop writes ``wbipc/endpoint.json`` itself. We only read the
    pipe name and the handshake ticket from that host-owned file.
  * A mutual HMAC-SHA256 handshake proves BOTH sides; the client verifies the
    server proof first and fails closed if it does not match.
  * All business calls go through the host's official ``wb.request`` forwarder,
    with authentication headers injected by the host.
  * The ticket stays in memory for the handshake only and is scrubbed on exit.

Author: Joyxj2devs Team
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import struct
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

PROTOCOL = 1
HANDSHAKE_TIMEOUT_MS = 5000
RPC_TIMEOUT_S = 20
MAX_RESPONSE_BYTES = 640 * 1024  # host caps forwarded responses; enforce locally too

# Only these headers may ever be supplied by us. The host injects the rest.
_ALLOWED_HEADERS = ("content-type", "accept")


def _endpoint_path() -> Path:
    override = os.environ.get("WBIPC_ENDPOINT_PATH")
    if override:
        return Path(override)
    base = os.environ.get("WORKBUDDY_CONFIG_DIR") or (
        Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".workbuddy"
    )
    return Path(base) / "wbipc" / "endpoint.json"


def ticket_id(ticket: str) -> str:
    """Non-reversible ticket identifier for the handshake (never the ticket itself)."""
    return hashlib.sha256(ticket.encode("utf-8")).hexdigest()[:16]


def _encode(role: str, t: Dict[str, Any]) -> bytes:
    parts = [
        "wbipc-s" if role == "server" else "wbipc-c",
        str(t["protocol"]),
        t["endpoint"],
        t["clientNonce"],
        t["serverNonce"],
    ]
    chunks = []
    for p in parts:
        b = p.encode("utf-8")
        chunks.append(struct.pack(">I", len(b)))
        chunks.append(b)
    return b"".join(chunks)


def _proof(ticket: str, role: str, t: Dict[str, Any]) -> str:
    return base64.urlsafe_b64encode(
        hmac.new(ticket.encode("utf-8"), _encode(role, t), hashlib.sha256).digest()
    ).decode("ascii").rstrip("=")


class WbipcError(Exception):
    """Transport-level error carrying a stable, user-facing code."""
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


class WbipcClient:
    """Client for the official WorkBuddy WBIPC named pipe."""

    def __init__(self) -> None:
        # Lazy import so --diagnose and non-Windows probing stay friendly.
        try:
            import win32file  # noqa: F401
            import pywintypes  # noqa: F401
        except ImportError as e:  # pragma: no cover - platform dependent
            raise WbipcError(
                "E_NO_PYWIN32",
                "缺少 pywin32 依赖（仅 Windows 需要）。",
            ) from e
        self._win32file = None
        self._pywintypes = None
        ep_file = _endpoint_path()
        try:
            ep = json.loads(ep_file.read_text(encoding="utf-8"))
        except FileNotFoundError as e:
            raise WbipcError(
                "E_NO_ENDPOINT",
                "找不到 WorkBuddy 的通信端点文件，请先启动并登录 WorkBuddy 桌面端。",
            ) from e
        except (json.JSONDecodeError, OSError) as e:
            raise WbipcError("E_BAD_ENDPOINT", "通信端点文件不可读或已损坏。") from e
        self.endpoint = ep.get("endpoint")
        self._ticket = ep.get("ticket")  # in-memory only, never persisted/logged
        if not self.endpoint or not self._ticket:
            raise WbipcError("E_BAD_ENDPOINT", "通信端点文件内容不完整。")
        self._handle = None
        self._chan: Optional[str] = None
        self._methods: Any = None

    def __enter__(self) -> "WbipcClient":
        import win32file
        import pywintypes
        self._win32file = win32file
        self._pywintypes = pywintypes
        GENERIC_READ_WRITE = 0xC0000000
        OPEN_EXISTING = 3
        try:
            self._handle = win32file.CreateFile(
                self.endpoint, GENERIC_READ_WRITE, 0, None, OPEN_EXISTING, 0, None
            )
        except pywintypes.error as e:
            raise WbipcError(
                "E_PIPE_GONE",
                "连不上 WorkBuddy 的内部通道，请确认桌面端已启动并登录。",
            ) from e
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._handle:
            try:
                self._win32file.CloseHandle(self._handle)
            except Exception:
                pass
            self._handle = None
        # Scrub the handshake secret from memory on the way out.
        self._ticket = None

    def _read_chunk(self, deadline: float) -> bytes:
        win32file, pywintypes = self._win32file, self._pywintypes
        box: Dict[str, Any] = {"err": None, "data": None}

        def worker() -> None:
            try:
                err, data = win32file.ReadFile(self._handle, 65536, None)
                box["err"], box["data"] = err, data
            except pywintypes.error as e:
                box["err"] = e.winerror

        t = threading.Thread(target=worker, daemon=True)
        t.start()
        t.join(max(0.0, deadline - time.time()))
        if t.is_alive():
            raise WbipcError("E_TIMEOUT", "WorkBuddy 响应超时，请稍后重试。")
        err = box["err"]
        if err == 109:  # ERROR_BROKEN_PIPE
            return b""
        if isinstance(err, int) and err not in (0, 109):
            raise WbipcError("E_DISCONNECTED", "与 WorkBuddy 的连接已断开。")
        return bytes(box["data"]) if box["data"] else b""

    def _read_frame(self, deadline: float) -> Optional[Dict[str, Any]]:
        buf = b""
        while True:
            if time.time() > deadline:
                raise WbipcError("E_TIMEOUT", "WorkBuddy 响应超时，请稍后重试。")
            i = buf.find(b"\n")
            if i >= 0:
                line = buf[:i]
                if line.strip():
                    if len(buf) > MAX_RESPONSE_BYTES:
                        raise WbipcError("E_PAYLOAD_TOO_LARGE", "响应体超过安全上限。")
                    return json.loads(line.decode("utf-8"))
                buf = buf[i + 1:]
                continue
            chunk = self._read_chunk(deadline)
            if not chunk:
                return None
            buf += chunk

    def _write_frame(self, obj: Dict[str, Any]) -> None:
        data = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
        self._win32file.WriteFile(self._handle, data, None)

    def handshake(self) -> Dict[str, Any]:
        """Mutual HMAC handshake. Verifies the server proof before sending ours."""
        ticket = self._ticket
        cnonce = base64.urlsafe_b64encode(secrets.token_bytes(16)).decode().rstrip("=")
        dl = time.time() + HANDSHAKE_TIMEOUT_MS / 1000.0
        self._write_frame({
            "type": "session_hello",
            "protocol_min": PROTOCOL,
            "protocol_max": PROTOCOL,
            "client_nonce": cnonce,
            "ticket_id": ticket_id(ticket),
            "client": {"kind": "python-skill", "id": "workbuddy-gift-claimer", "version": "3.3.3"},
        })
        msg = self._read_frame(dl)
        if not msg or msg.get("type") != "session_challenge":
            raise WbipcError("E_HANDSHAKE", "WBIPC 握手响应不符合预期。")
        transcript = {
            "protocol": PROTOCOL,
            "endpoint": self.endpoint,
            "clientNonce": cnonce,
            "serverNonce": msg.get("server_nonce", ""),
        }
        expected = _proof(ticket, "server", transcript)
        # Fail closed: never talk to a pipe that cannot prove it owns the ticket.
        if not hmac.compare_digest(expected, str(msg.get("server_proof", ""))):
            raise WbipcError(
                "E_SPOOFED_ENDPOINT",
                "通信端点校验失败（可能被其他实例占用或端点已过期）。",
            )
        self._write_frame({
            "type": "session_prove",
            "client_proof": _proof(ticket, "client", transcript),
        })
        ack = self._read_frame(dl)
        if not ack or ack.get("type") != "session_hello_ack":
            raise WbipcError("E_HANDSHAKE", "WBIPC 握手确认失败。")
        return ack

    def invoke(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        cid = secrets.randbelow(2 ** 31)
        self._write_frame({
            "jsonrpc": "2.0", "id": cid, "method": method,
            "params": params, "mode": "call",
        })
        dl = time.time() + RPC_TIMEOUT_S
        while True:
            msg = self._read_frame(dl)
            if msg is None:
                raise WbipcError("E_DISCONNECTED", "与 WorkBuddy 的连接已断开。")
            if "jsonrpc" not in msg:
                continue
            if msg.get("id") == cid:
                if "error" in msg:
                    raise WbipcError("E_RPC", "宿主转发器返回错误。")
                return msg.get("result") or {}

    def _bind_forwarder(self) -> None:
        if self._chan is not None:
            return
        r = self.invoke("broker/GetPipe", {"pipe": "wb.request"})
        self._chan = r.get("channel")
        self._methods = r.get("methods")
        if not self._chan:
            raise WbipcError("E_NO_FORWARDER", "宿主未提供官方请求转发通道。")

    def http(self, method: str, path: str,
             json_body: Optional[Dict[str, Any]] = None,
             query: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Ask the host to forward one request; the host injects the login state.

        We never set authentication headers, and never hold a credential.
        Only the whitelisted content headers are allowed.
        """
        if not path.startswith("/"):
            raise WbipcError("E_BAD_PATH", "请求路径不合法。")
        self._bind_forwarder()
        params: Dict[str, Any] = {"method": method, "path": path}
        if query:
            params["query"] = query
        if json_body is not None:
            raw = json.dumps(json_body, ensure_ascii=False).encode("utf-8")
            params["body_b64"] = base64.b64encode(raw).decode("ascii")
        r = self.invoke(f"{self._chan}/http.fetch", params)
        b64 = r.get("body_b64") or ""
        if len(b64) > MAX_RESPONSE_BYTES:
            raise WbipcError("E_PAYLOAD_TOO_LARGE", "响应体超过安全上限。")
        raw = base64.b64decode(b64) if b64 else b""
        text = raw.decode("utf-8", errors="replace")
        try:
            data: Any = json.loads(text) if text else None
        except (ValueError, TypeError):
            data = text
        return {
            "status": r.get("status", 0),
            "headers": r.get("headers", {}),
            "body": data,
        }

    def list_pipes(self) -> Dict[str, Any]:
        return self.invoke("broker/ListPipes", {})
