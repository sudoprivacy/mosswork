"""WorkBuddy daily check-in + buddy travel, through the official WBIPC channel.

Commands:
    status    read-only: check-in state, buddy info, travel state
    checkin   claim today's check-in credits (idempotent)
    travel    state-aware handling: idle -> depart / traveling -> report / arrived -> claim
    all       checkin + state-aware handling, within this one run
    selftest  handshake + list host pipes, no business request

All requests are forwarded by the WorkBuddy host via wb.request; the host injects
the login state and applies its own checks. This module contains no HTTP client.

Author: Joyxj2devs Team
"""
from __future__ import annotations

import json
import random
import sys
import time
from typing import Any, Dict, Optional

from wbipc_client import WbipcClient, WbipcError

CHECKIN_STATUS = "/v2/billing/meter/checkin-activity-status"
CHECKIN_DO = "/v2/billing/meter/daily-checkin"
BUDDY_INFO = "/activity/growth/buddy/info"
TRAVEL_STATUS = "/activity/growth/buddy/travel/status"
TRAVEL_CONFIG = "/activity/growth/buddy/travel/config"
TRAVEL_DEPART = "/activity/growth/buddy/travel/depart"
TRAVEL_CLAIM = "/activity/growth/buddy/travel/claim"

LOCATIONS = {1: "咖啡馆", 2: "商场店铺", 3: "健身房", 4: "古镇客栈"}


def _friendly_error(e: Exception) -> Dict[str, Any]:
    """Translate low-level failures into code + message + action (user-facing)."""
    if isinstance(e, WbipcError):
        code, msg = e.code, e.message
    else:
        code, msg = "E_UNEXPECTED", "发生未知错误。"
    actions = {
        "E_NO_PYWIN32": "安装 pywin32 依赖后重试（仅 Windows 需要）。",
        "E_NO_ENDPOINT": "请先启动 WorkBuddy 桌面端并完成登录，再运行。",
        "E_BAD_ENDPOINT": "重启 WorkBuddy 桌面端以刷新通信端点。",
        "E_PIPE_GONE": "启动 WorkBuddy 桌面端并登录后重试。",
        "E_SPOOFED_ENDPOINT": "关闭多余的 WorkBuddy 窗口；仍失败则重启桌面端。",
        "E_TIMEOUT": "等 10 秒后重试；连续失败请重启 WorkBuddy 桌面端。",
        "E_DISCONNECTED": "重跑一次即可；签到与领取都是幂等的，不会重复发奖。",
        "E_RPC": "重跑一次；若持续出现请检查 WorkBuddy 版本。",
        "E_NO_FORWARDER": "确认 WorkBuddy 桌面端为较新版本后重试。",
        "E_PAYLOAD_TOO_LARGE": "重跑一次；若持续出现请反馈给作者。",
        "E_HANDSHAKE": "重启 WorkBuddy 桌面端后重试。",
        "E_BAD_LOCATION": "把地点改成 1-4 之间的整数，或不填（随机选择）。",
        "E_BAD_PATH": "这是内部参数错误，请反馈给作者。",
    }
    return {
        "code": code,
        "message": msg,
        "action": actions.get(code, "先运行 selftest 自检；仍失败请带着 detail 反馈。"),
        "detail": str(e)[:300],
    }


def _data(resp: Dict[str, Any]) -> Dict[str, Any]:
    body = resp.get("body")
    if isinstance(body, dict):
        d = body.get("data")
        return d if isinstance(d, dict) else {}
    return {}


def cmd_selftest(c: WbipcClient, ack: Dict[str, Any]) -> Dict[str, Any]:
    pipes = c.list_pipes()
    return {
        "ok": True,
        "endpoint": c.endpoint,
        "pipes": pipes.get("pipes", []),
        "ack": {k: v for k, v in ack.items()
                if k in ("type", "protocol", "max_inflight")},
    }


def cmd_status(c: WbipcClient) -> Dict[str, Any]:
    chk = c.http("POST", CHECKIN_STATUS)
    buddy = c.http("GET", BUDDY_INFO)
    travel = c.http("GET", TRAVEL_STATUS)
    return {"checkin": chk, "buddy": buddy, "travel": travel}


def cmd_checkin(c: WbipcClient) -> Dict[str, Any]:
    """Idempotent: 'already checked in today' is a success, not a failure.

    The service answers an already-completed check-in with HTTP 400 and
    code=10001 ("今天已签到"). That is a normal idempotent result, so the
    business code (not the HTTP status) decides success here.
    """
    r = c.http("POST", CHECKIN_DO)
    body = r.get("body") if isinstance(r.get("body"), dict) else {}
    code = body.get("code")
    msg = str(body.get("msg", ""))
    already = (
        code == 10001
        or "已签到" in msg
        or bool(_data(r).get("today_checked_in"))
    )
    ok = (code == 0) or already
    return {
        "ok": ok,
        "http_status": r.get("status"),
        "already_checked_in": already,
        "business_code": code,
        "message": msg,
        "response": r,
    }


def cmd_travel(c: WbipcClient, location_id: Optional[int] = None) -> Dict[str, Any]:
    """State-aware handling of one user request. Never blindly claims."""
    if location_id is not None and location_id not in LOCATIONS:
        raise WbipcError(
            "E_BAD_LOCATION",
            f"地点只接受 1-4（{' / '.join(f'{k} {v}' for k, v in LOCATIONS.items())}），收到 {location_id}。",
        )
    st = c.http("GET", TRAVEL_STATUS)
    d = _data(st)
    state = d.get("state", "unknown")

    if state == "arrived":
        claim = c.http("POST", TRAVEL_CLAIM, {})
        return {"action": "claim", "state": state, "status": st, "claim": claim,
                "reward_credit": d.get("reward_credit")}
    if state == "idle":
        if d.get("daily_limit_reached"):
            return {"action": "noop", "state": state,
                    "reason": "daily_limit_reached", "status": st}
        lid = location_id if location_id in LOCATIONS else random.randint(1, 4)
        depart = c.http("POST", TRAVEL_DEPART, {"location_id": lid})
        return {"action": "depart", "state": state, "status": st,
                "location": LOCATIONS[lid], "location_id": lid, "depart": depart}
    if state == "traveling":
        return {"action": "noop", "state": state,
                "arrive_at": d.get("arrive_at"),
                "reward_credit": d.get("reward_credit"),
                "location": (d.get("location") or {}).get("name"),
                "status": st}
    return {"action": "unknown_state", "state": state, "status": st}


def cmd_all(c: WbipcClient, location_id: Optional[int] = None) -> Dict[str, Any]:
    return {"checkin": cmd_checkin(c), "travel": cmd_travel(c, location_id)}


def run(cmd: str, location_id: Optional[int] = None) -> Dict[str, Any]:
    """Run one user request; retry once in-process on a transient failure."""
    transient = {"E_DISCONNECTED", "E_TIMEOUT", "E_PIPE_GONE"}
    attempts = 0
    while True:
        try:
            with WbipcClient() as c:
                ack = c.handshake()
                if cmd == "selftest":
                    out = cmd_selftest(c, ack)
                elif cmd == "status":
                    out = cmd_status(c)
                elif cmd == "checkin":
                    out = cmd_checkin(c)
                elif cmd == "travel":
                    out = cmd_travel(c, location_id)
                elif cmd == "all":
                    out = cmd_all(c, location_id)
                else:
                    raise WbipcError("E_BAD_COMMAND", "未知子命令。")
            return {"ok": True, "channel": "wbipc_official", "cmd": cmd, "data": out}
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception as e:  # noqa: BLE001
            attempts += 1
            fe = _friendly_error(e)
            if fe["code"] in transient and attempts < 2:
                time.sleep(2)
                continue
            return {
                "ok": False,
                "channel": "wbipc_official",
                "error": fe,
                "hint": "可重复运行，签到与领取都是幂等的，不会重复发奖"
                        + ("；本次请求内已重试 1 次仍失败。" if fe["code"] in transient else "。"),
                "retried": attempts > 1,
            }


def main() -> int:
    import argparse
    ap = argparse.ArgumentParser(description="WorkBuddy 签到 + 猫猫旅行（官方 WBIPC 通道）")
    ap.add_argument("cmd", nargs="?", default="all",
                    choices=["status", "checkin", "travel", "all", "selftest"])
    ap.add_argument("--location", type=int, default=None,
                    help="派出地点 1-4，不填随机选择")
    args = ap.parse_args()
    out = run(args.cmd, args.location)
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
