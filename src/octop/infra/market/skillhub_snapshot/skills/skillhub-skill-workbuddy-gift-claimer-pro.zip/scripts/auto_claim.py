"""WorkBuddy daily check-in and travel reward assistant (v3.3.3).

Requests are handled through the WorkBuddy desktop app's official local
channel: the host forwards each request and adds the login state itself.
Each invocation handles one request, prints its result and exits.

Usage:
  python auto_claim.py                    # one on-demand run: check-in + buddy travel
  python auto_claim.py --cmd status     # read-only state
  python auto_claim.py --cmd checkin    # check-in only
  python auto_claim.py --cmd travel     # buddy travel handling only
  python auto_claim.py --cmd selftest   # handshake health check, no business request
  python auto_claim.py --location 2     # travel location 1-4
  python auto_claim.py --json           # structured JSON output
  python auto_claim.py --diagnose      # environment self-check
  python auto_claim.py --version / --help

Author: Joyxj2devs Team
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

__author__ = "Joyxj2devs Team"
__version__ = "3.3.3"
__mode__ = "wbipc_official"

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


def _delegate(cmd: str = "all", location: Optional[int] = None) -> Dict[str, Any]:
    """Run one command through the host's official forwarder."""
    try:
        from wb_auto import run
        out = run(cmd, location)
    except Exception as e:  # noqa: BLE001
        return {
            "success": False,
            "channel": "wbipc",
            "status": "error",
            "msg": f"Official channel unavailable: {type(e).__name__}: {e}",
            "mode": __mode__,
        }

    if out.get("ok"):
        data = out.get("data") or {}
        # Business-level success: an already-checked-in today is a success,
        # and every travel state (idle / traveling / arrived) is a valid result.
        business_ok = True
        if cmd in ("checkin", "all"):
            business_ok = bool(data.get("checkin", {}).get("ok", True))
        return {
            "success": business_ok,
            "channel": "wbipc",
            "status": "success" if business_ok else "error",
            "msg": json.dumps(data, ensure_ascii=False)[:1500],
            "mode": __mode__,
            "detail": out,
        }

    err = out.get("error") or {}
    return {
        "success": False,
        "channel": "wbipc",
        "status": "error",
        "msg": err.get("message", "Official channel request failed"),
        "mode": __mode__,
        "error_code": err.get("code"),
        "detail": out,
    }


def _diagnose() -> Dict[str, Any]:
    """Local environment self-check. No network access, no credential access."""
    deps: Dict[str, str] = {}
    for mod in ("win32file", "pywintypes"):
        try:
            __import__(mod)
            deps[mod] = "ok"
        except Exception as e:  # noqa: BLE001
            deps[mod] = f"missing: {type(e).__name__}"

    base = os.environ.get("WORKBUDDY_CONFIG_DIR") or (
        Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".workbuddy"
    )
    ep = Path(os.environ.get("WBIPC_ENDPOINT_PATH") or (Path(base) / "wbipc" / "endpoint.json"))
    # Only existence is reported; the endpoint contents are never printed here.
    return {
        "version": __version__,
        "platform": sys.platform,
        "python_version": sys.version.split()[0],
        "mode": __mode__,
        "endpoint_file": str(ep),
        "endpoint_exists": ep.exists(),
        "dependencies": deps,
        "compliance": "no credential access; login state injected by the desktop app",
    }


def _arg_value(argv: List[str], flag: str) -> Optional[str]:
    if flag in argv:
        i = argv.index(flag)
        if i + 1 < len(argv):
            return argv[i + 1]
    return None


def main(argv=None) -> int:
    """CLI entry point."""
    argv = list(argv if argv is not None else sys.argv[1:])

    if "--version" in argv:
        print(json.dumps({"version": __version__, "mode": __mode__}))
        return 0
    if "--help" in argv or "-h" in argv:
        print(__doc__)
        return 0
    if "--diagnose" in argv:
        report = _diagnose()
        print(json.dumps(report, ensure_ascii=False, indent=2))
        wb_ok = report["endpoint_exists"] and report["dependencies"].get("win32file") == "ok"
        return 0 if wb_ok else 1

    as_json = "--json" in argv
    channel = _arg_value(argv, "--channel") or "auto"
    cmd = _arg_value(argv, "--cmd") or "all"
    loc_raw = _arg_value(argv, "--location")
    try:
        location = int(loc_raw) if loc_raw is not None else None
    except ValueError:
        location = None

    if channel == "ui":
        result = {
            "success": False,
            "channel": "ui",
            "status": "unavailable",
            "msg": "This build ships the official channel only. "
                   "Please start and sign in to the WorkBuddy desktop app.",
            "mode": __mode__,
        }
    else:
        result = _delegate(cmd=cmd, location=location)

    final: Dict[str, Any] = {
        "success": result.get("success", False),
        "version": __version__,
        "mode": __mode__,
        "result": result,
    }

    if as_json:
        print(json.dumps(final, ensure_ascii=False, indent=2))
    elif result.get("success"):
        print("Check-in and travel rewards completed through the official channel.")
    else:
        print(f"Failed: {result.get('msg', result.get('status', 'error'))}")

    return 0 if final.get("success") else 1


if __name__ == "__main__":
    sys.exit(main())
