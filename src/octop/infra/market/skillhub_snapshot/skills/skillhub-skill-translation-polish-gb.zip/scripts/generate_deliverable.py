#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_deliverable.py - 由一份翻译结果 JSON 渲染**唯一的交付文档：推荐译文本身**。

不生成任何"原文/译文对照"版本：交付物就是译文，按原文结构（标题层级、列表、
表格、图注表注、编号）排版，格式与 JSON 契约见 references/output_spec.md。

输入 JSON：
  {
    "meta": {"project", "date", "source_language", "target_language", "doc_title", ...},
    "blocks": [                      # 渲染主体，结构须与原文骨架一致
      {"no":1,"type":"heading","level":1,"text":"工作范围"},
      {"no":2,"type":"paragraph","text":"..."},
      {"no":3,"type":"list_item","list":"bullet|number|keep","level":0,"text":"..."},
      {"no":4,"type":"table","header":true,"rows":[["项目","说明"],["1","..."]]},
      {"no":5,"type":"caption"|"quote"|"code"|"page_break"|"boilerplate","text":"..."}
    ],
    "alignment": [...],              # 过程记录：质检用的逐段配对，不渲染
    "defects": [...],                # 过程记录：缺陷与修订，不渲染
    "meta.iteration": {...}          # 过程记录：迭代轨迹，不渲染
  }

用法:
    python generate_deliverable.py --input result.json --out-dir . --prefix 项目名
    python generate_deliverable.py --input result.json --format md   # 输出 Markdown

骨架可由 scripts/extract_source.py 从原文（.docx/.md/.txt）抽取。
"""

import argparse
import datetime
import json
import os
import sys

DOCX_REQUIRED = False
try:
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor
    DOCX_REQUIRED = True
except ImportError:
    pass


HEADER_FILL = "1F4E79"   # 表头深蓝底 + 白字
ZEBRA_FILL = "F2F6FA"    # 表格斑马纹
CODE_FILL = "F5F5F5"     # 等宽代码块底纹
DARK = RGBColor(0x1F, 0x1F, 0x1F)
GREY = RGBColor(0x59, 0x59, 0x59)
LIGHT_GREY = RGBColor(0x89, 0x89, 0x89)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

CN_FONT = "宋体"
EN_FONT = "Times New Roman"
MONO_FONT = "Consolas"
HEAD_FONT = "黑体"

INDENT_UNIT = Cm(0.74)   # 列表每一级的缩进


# ---------------- 基础排版工具 ----------------

def _set_run_font(run, size=11, bold=False, cn_font=CN_FONT, en_font=EN_FONT,
                  color=None, italic=False):
    run.font.name = en_font
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), cn_font)


def _shade_cell(cell, hex_fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tc_pr.append(shd)


def _shade_para(p, hex_fill):
    pPr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    pPr.append(shd)


def _set_cell(cell, text, bold=False, size=10, color=None, align=None):
    """写单元格文本；含换行符时拆为多行（同单元格多段落），垂直居中。"""
    p = cell.paragraphs[0]
    for r in list(p.runs):
        r._r.getparent().remove(r._r)
    for extra in cell.paragraphs[1:]:
        extra._p.getparent().remove(extra._p)
    lines = [""] if text is None else str(text).split("\n")
    for i, line in enumerate(lines):
        para = p if i == 0 else cell.add_paragraph()
        if align is not None:
            para.alignment = align
        para.paragraph_format.space_after = Pt(0)
        para.paragraph_format.space_before = Pt(0)
        para.paragraph_format.line_spacing = 1.2
        run = para.add_run(line)
        _set_run_font(run, size=size, bold=bold, color=color)
    tc_pr = cell._tc.get_or_add_tcPr()
    if tc_pr.find(qn("w:vAlign")) is None:
        va = OxmlElement("w:vAlign")
        va.set(qn("w:val"), "center")
        tc_pr.append(va)
    return cell


def _style_header_row(row, size=10):
    for cell in row.cells:
        _set_cell(cell, cell.text, bold=True, size=size, color=WHITE,
                  align=WD_ALIGN_PARAGRAPH.CENTER)
        _shade_cell(cell, HEADER_FILL)


def _set_table_fixed(table, widths):
    tbl_pr = table._tbl.tblPr
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tbl_pr.append(layout)
    grid = table._tbl.find(qn("w:tblGrid"))
    if grid is not None:
        for gc in grid.findall(qn("w:gridCol")):
            grid.remove(gc)
        for wd in widths:
            gc = OxmlElement("w:gridCol")
            gc.set(qn("w:w"), str(int(wd.twips)))
            grid.append(gc)
    for i, wd in enumerate(widths):
        for row in table.rows:
            if i < len(row.cells):
                row.cells[i].width = wd


def _add_para(doc, text="", bold=False, size=11, indent_cm=None, align=None,
              color=None, space_after=6, italic=False, mono=False):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_after = Pt(space_after)
    pf.line_spacing = 1.25
    if indent_cm is not None:
        pf.left_indent = Cm(indent_cm)
    if align is not None:
        p.alignment = align
    run = p.add_run(text)
    if mono:
        _set_run_font(run, size=size, bold=bold, cn_font=MONO_FONT, en_font=MONO_FONT,
                      color=color, italic=italic)
        _shade_para(p, CODE_FILL)
    else:
        _set_run_font(run, size=size, bold=bold, color=color, italic=italic)
    return p


def _add_heading(doc, text, level=1):
    level = max(1, min(int(level or 1), 4))
    h = doc.add_heading(level=level)
    run = h.add_run(text)
    _set_run_font(run, size={1: 16, 2: 14, 3: 12.5, 4: 11.5}[level],
                  bold=True, cn_font=HEAD_FONT, color=DARK)
    return h


def _add_page_number_footer(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    _set_run_font(run, size=9)
    fld1 = OxmlElement("w:fldChar"); fld1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = "PAGE"
    fld2 = OxmlElement("w:fldChar"); fld2.set(qn("w:fldCharType"), "end")
    run._r.append(fld1); run._r.append(instr); run._r.append(fld2)


def _set_cell_margins(cell, top=60, bottom=60, left=80, right=80):
    tc_pr = cell._tc.get_or_add_tcPr()
    margins = OxmlElement("w:tcMar")
    for tag, val in [("top", top), ("bottom", bottom), ("start", left), ("end", right),
                     ("left", left), ("right", right)]:
        elem = OxmlElement(f"w:{tag}")
        elem.set(qn("w:w"), str(val))
        elem.set(qn("w:type"), "dxa")
        margins.append(elem)
    tc_pr.append(margins)


def _table_col_widths(rows, total_cm=16.0):
    """按各列内容长度分配列宽（总宽固定为 16cm，A4 页边距 2.5cm 可用宽），避免长列被压扁。"""
    if not rows:
        return [Cm(total_cm)]
    ncol = max(len(r) for r in rows)
    weights = []
    for c in range(ncol):
        longest = max((len(str(r[c])) if c < len(r) else 0) for r in rows)
        weights.append(max(longest, 4))
    s = sum(weights) or 1
    return [Cm(total_cm * w / s) for w in weights]


# ---------------- 渲染：docx ----------------

def _render(doc, blocks):
    skipped_boilerplate = 0
    for b in blocks:
        btype = b.get("type", "paragraph")
        text = (b.get("text") or "").strip()

        if btype == "heading":
            if text:
                _add_heading(doc, text, b.get("level", 1))

        elif btype == "paragraph":
            _add_para(doc, text, bold=bool(b.get("bold")), size=11)

        elif btype == "list_item":
            kind = b.get("list", "bullet")
            level = int(b.get("level", 0) or 0)
            if kind in ("bullet", "number"):
                style = "List Bullet" if kind == "bullet" else "List Number"
                if level > 0:
                    style = f"{style} {min(level + 1, 5)}"
                try:
                    p = doc.add_paragraph(style=style)
                except KeyError:
                    p = doc.add_paragraph()
                    p.paragraph_format.left_indent = INDENT_UNIT * (level + 1)
                p.paragraph_format.space_after = Pt(3)
                p.paragraph_format.line_spacing = 1.2
                run = p.add_run(text)
                _set_run_font(run, size=11)
            else:  # keep：保留原文编号/符号，仅缩进对齐
                _add_para(doc, text, size=11,
                          indent_cm=0.74 * (level + 1), space_after=3)

        elif btype == "table":
            rows = b.get("rows") or []
            if not rows:
                continue
            ncol = max(len(r) for r in rows)
            tbl = doc.add_table(rows=0, cols=ncol)
            tbl.style = "Table Grid"
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            tbl.autofit = False
            for ri, row in enumerate(rows):
                cells = tbl.add_row().cells
                for ci in range(ncol):
                    val = row[ci] if ci < len(row) else ""
                    is_head = bool(b.get("header")) and ri == 0
                    _set_cell(cells[ci], val, size=9.5, bold=is_head,
                              color=WHITE if is_head else None,
                              align=WD_ALIGN_PARAGRAPH.CENTER if (is_head or ci == 0 and len(val) < 6)
                              else WD_ALIGN_PARAGRAPH.LEFT)
                    _set_cell_margins(cells[ci], top=60, bottom=60)
                    if is_head:
                        _shade_cell(cells[ci], HEADER_FILL)
                    elif ri % 2 == 0:
                        _shade_cell(cells[ci], ZEBRA_FILL)
            _set_table_fixed(tbl, _table_col_widths(rows))
            _add_para(doc, "", size=4, space_after=4)

        elif btype == "caption":
            _add_para(doc, text, size=9.5, align=WD_ALIGN_PARAGRAPH.CENTER,
                      color=GREY, space_after=8)

        elif btype == "quote":
            _add_para(doc, text, size=10.5, indent_cm=1.0, color=GREY, italic=True)

        elif btype == "code":
            for line in text.split("\n"):
                _add_para(doc, line, size=9.5, indent_cm=0.4, space_after=0, mono=True)
            _add_para(doc, "", size=4, space_after=6)

        elif btype == "page_break":
            doc.add_page_break()

        elif btype == "boilerplate":
            skipped_boilerplate += 1  # 页眉页脚残留，默认不译出

    return skipped_boilerplate


def build_docx(data, out_path):
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = EN_FONT
    normal.font.size = Pt(11)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), CN_FONT)

    section = doc.sections[0]
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)
    _add_page_number_footer(section)

    meta = data.get("meta") or {}
    title = meta.get("doc_title")
    if title:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(title)
        _set_run_font(run, size=18, bold=True, cn_font=HEAD_FONT, color=DARK)
        sub = meta.get("doc_subtitle")
        if sub:
            _add_para(doc, sub, size=10, align=WD_ALIGN_PARAGRAPH.CENTER,
                      color=LIGHT_GREY, space_after=10)

    skipped = _render(doc, data.get("blocks") or [])
    doc.save(out_path)
    return skipped


# ---------------- 渲染：markdown ----------------

def build_md(data, out_path):
    meta = data.get("meta") or {}
    lines = []
    if meta.get("doc_title"):
        lines.append(f"# {meta['doc_title']}\n")
    for b in data.get("blocks") or []:
        btype = b.get("type", "paragraph")
        text = (b.get("text") or "").strip()
        if btype == "heading":
            lines.append(f"{'#' * max(1, min(int(b.get('level', 1)), 6))} {text}\n")
        elif btype == "paragraph":
            lines.append(f"{text}\n")
        elif btype == "list_item":
            level = int(b.get("level", 0) or 0)
            pad = "  " * level
            if b.get("list") == "bullet":
                lines.append(f"{pad}- {text}")
            elif b.get("list") == "keep":
                lines.append(f"{pad}{text}")
            else:
                lines.append(f"{pad}1. {text}")
        elif btype == "table":
            rows = b.get("rows") or []
            for ri, row in enumerate(rows):
                lines.append("| " + " | ".join(row) + " |")
                if ri == 0:
                    lines.append("| " + " | ".join(["---"] * len(row)) + " |")
            lines.append("")
        elif btype == "caption":
            lines.append(f"> {text}\n")
        elif btype == "quote":
            lines.append("> " + text.replace("\n", "\n> ") + "\n")
        elif btype == "code":
            lines.append("```\n" + text + "\n```\n")
        elif btype == "page_break":
            lines.append("---\n")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# ---------------- 入口 ----------------

def main():
    ap = argparse.ArgumentParser(
        description="生成唯一交付文档《推荐译文》——只输出译文本身，不生成对照版本")
    ap.add_argument("--input", "-i", required=True, help="翻译结果 JSON 文件")
    ap.add_argument("--out-dir", "-d", default=".", help="输出目录；缺省当前目录")
    ap.add_argument("--prefix", "-p", default="", help="文件名前缀（如项目名）；缺省用时间戳")
    ap.add_argument("--format", "-f", default="docx", choices=["docx", "md"],
                    help="输出格式：docx（默认，保留排版）或 md")
    ap.add_argument("--mode", "-m", default=None,
                    choices=["quality_inspection", "self_iterative"],
                    help="【已废弃】2.0 起不再区分模式；此参数被忽略。")
    args = ap.parse_args()

    if args.format == "docx" and not DOCX_REQUIRED:
        sys.stderr.write(
            "[ERROR] 缺少 python-docx 依赖。请先安装：\n  pip install python-docx\n")
        sys.exit(2)
    if args.mode is not None:
        print("[WARN] --mode 已废弃：2.0 起为单一流水线，该参数已忽略。")

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    os.makedirs(args.out_dir, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base = f"{args.prefix.rstrip('_')}_推荐译文" if args.prefix else f"推荐译文_{stamp}"
    out_path = os.path.join(args.out_dir, f"{base}.{args.format}")

    if args.format == "docx":
        skipped = build_docx(data, out_path)
        if skipped:
            print(f"[INFO] 已跳过 {skipped} 处页眉页脚残留（boilerplate）。")
    else:
        build_md(data, out_path)

    blocks = data.get("blocks") or []
    print(f"[OK] 推荐译文已生成: {out_path}")
    print(f"[STATS] 结构块 {len(blocks)} 个："
          f"标题 {sum(1 for b in blocks if b.get('type') == 'heading')} / "
          f"段落 {sum(1 for b in blocks if b.get('type') == 'paragraph')} / "
          f"列表 {sum(1 for b in blocks if b.get('type') == 'list_item')} / "
          f"表格 {sum(1 for b in blocks if b.get('type') == 'table')}")


if __name__ == "__main__":
    main()
