#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_source.py - 抽取原文文件的**结构骨架**，用于"按原文格式排版"地输出推荐译文。

用途：本技能只交付译文本身（不做对照表），因此必须先拿到原文的结构（标题层级、
列表、表格、图注表注、加粗、编号），再逐块翻译，最后按同一结构渲染，避免排版漂移。

支持输入：
  .docx  识别标题样式、List Bullet/Number、表格（含表头判定）、加粗、空段
  .md/.txt 识别 # 标题、-/* 列表、1. 编号、| 表格、> 引用、``` 代码块

输出 JSON：
  {
    "source_file": "...",
    "stats": {"blocks": n, "headings": n, "paragraphs": n, "list_items": n,
              "tables": n, "char_count_estimate": n},
    "blocks": [
      {"no": 1, "type": "heading", "level": 1, "text": "Scope of Works"},
      {"no": 2, "type": "paragraph", "text": "...", "bold": false},
      {"no": 3, "type": "list_item", "list": "bullet", "level": 0, "text": "..."},
      {"no": 4, "type": "table", "header": true, "rows": [["Item", "Desc"], ["1", "..."]]}
    ]
  }

用法:
    python extract_source.py --input 原文.docx --out skeleton.json
    python extract_source.py --input 原文.md   （不传 --out 则打印到标准输出）
"""

import argparse
import json
import os
import re
import sys

MD_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")
BULLET_RE = re.compile(r"^[\s]*[-*+·•]\s+(.*)$")
ORDERED_RE = re.compile(r"^[\s]*(\(?\d+[\.、\)]|\[?\d+\]|[a-zA-Z][\.\)])\s+(.*)$")
TABLE_SEP_RE = re.compile(r"^\s*\|?[\s:\-\|]+\|[\s:\-\|]*$")
CODE_FENCE_RE = re.compile(r"^\s*(```|~~~)")
CAPTION_RE = re.compile(r"^\s*(图|表|Figure|Table|Fig\.?)\s*[\d\.\-—]+", re.I)
# PDF/文本抽取残留的分页标记（如 "--- PAGE 3 ---"、"第 3 页"）：不计入译文内容
PAGE_MARKER_RE = re.compile(
    r"^\s*([-=*_~\s]*(page|第)\s*\d+\s*(页)?[-=*_~\s]*)$", re.I)
# 页眉页脚/水印残留（PDF 抽取常见）：不作为标题候选，默认不译出
BOILERPLATE_RE = re.compile(
    r"^\s*((strictly\s+)?confidential(\s+\d+)?| proprietary|draft(\s+\d+)?|"
    r"page\s+\d+(\s+of\s+\d+)?|第\s*\d+\s*页(\s*/\s*共\s*\d+\s*页)?|-?\s*\d+\s*-?)\s*$", re.I)
# 罗马数字编号条目（vii)、XVIII.）→ 归入列表而非标题
ROMAN_RE = re.compile(r"^\s*[\(\[]?[ivxlcdm]{1,7}[\.\)\]]\s+", re.I)

# docx 样式名（中英文 Word 均可能出现）
HEADING_STYLE_RE = re.compile(r"^(heading|标题)\s*(\d)", re.I)
LIST_STYLE_RE = re.compile(r"^(list\s*(bullet|number|paragraph)|列表)", re.I)


# ---------------- docx ----------------

def _iter_block_items(doc):
    """按文档流顺序产出段落与表格（python-docx 原生只分别给出 paragraphs / tables）。"""
    from docx.oxml.table import CT_Tbl
    from docx.oxml.text.paragraph import CT_P
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    body = doc.element.body
    for child in body.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, doc)
        elif isinstance(child, CT_Tbl):
            yield Table(child, doc)


def _para_is_bold(p):
    runs = [r for r in p.runs if r.text.strip()]
    if not runs:
        return False
    return all(r.bold for r in runs)


def _table_rows(table):
    rows = []
    for row in table.rows:
        cells = []
        for cell in row.cells:
            cells.append("\n".join(x.text.strip() for x in cell.paragraphs).strip())
        rows.append(cells)
    return rows


def _first_row_is_header(table):
    if not table.rows:
        return False
    for cell in table.rows[0].cells:
        for p in cell.paragraphs:
            if p.text.strip() and _para_is_bold(p):
                return True
    return False


def _detect_list(text, style_name=""):
    """判定列表类型：(list_kind, level, clean_text)。带原文编号的一律 keep，避免双重编号。"""
    level = 0
    m = LIST_STYLE_RE.match(style_name or "")
    if m:
        tail = re.search(r"(\d+)\s*$", style_name or "")
        level = max(0, int(tail.group(1)) - 1) if tail else 0
    if BULLET_RE.match(text):
        return "bullet", level, BULLET_RE.match(text).group(1)
    m = ORDERED_RE.match(text)
    if m:
        # 原文已带编号 → 保留原文编号，仅缩进
        return "keep", level, text.strip()
    if m or LIST_STYLE_RE.match(style_name or ""):
        return "number", level, text.strip()
    return None, level, text.strip()


def extract_docx(path):
    try:
        from docx import Document
    except ImportError:
        sys.stderr.write("[ERROR] 读取 .docx 需要 python-docx：pip install python-docx\n")
        sys.exit(2)

    doc = Document(path)
    blocks = []
    no = 0
    for item in _iter_block_items(doc):
        # 表格
        if item.__class__.__name__ == "Table":
            rows = _table_rows(item)
            if not rows:
                continue
            no += 1
            blocks.append({
                "no": no,
                "type": "table",
                "header": _first_row_is_header(item),
                "rows": rows,
            })
            continue

        text = item.text.strip()
        style_name = (item.style.name or "") if item.style is not None else ""

        if not text:
            if "page break" in (item._p.xml or "").lower():
                no += 1
                blocks.append({"no": no, "type": "page_break"})
            continue

        no += 1
        hm = HEADING_STYLE_RE.match(style_name)
        if hm:
            level = int(hm.group(2))
            blocks.append({"no": no, "type": "heading", "level": min(level, 4), "text": text})
            continue

        if CAPTION_RE.match(text) and len(text) < 120:
            blocks.append({"no": no, "type": "caption", "text": text})
            continue

        kind, level, clean = _detect_list(text, style_name)
        if kind:
            blocks.append({"no": no, "type": "list_item", "list": kind,
                           "level": level, "text": clean})
            continue

        blocks.append({"no": no, "type": "paragraph", "text": text,
                       "bold": _para_is_bold(item)})
    return blocks


# ---------------- md / txt ----------------

TERMINAL_RE = re.compile(r"[.!?:。！？：]\s*$")


def _heading_candidate(text, next_text, prev_block=None):
    """纯文本无 # 标记时的标题候选启发式，只做**候选标记**供模型确认，不改写结构。

    判定条件（同时满足）：
      1. 长度 ≤ 60 且不以句末标点结尾；
      2. 上一行是完整句（以句末标点结束）、或是标题/列表/表格/文首——即本行不是上一句的换行续行；
      3. 带章节编号（1. / 1.1. / Appendix A），或后接明显更长的正文行。
    """
    if len(text) > 60 or not text:
        return False
    if text[-1] in ".;,:;。；：，、":
        return False

    numbered = bool(re.match(r"^\s*(\d+(\.\d+)*[\.、]?|appendix\s+[a-z0-9]+|annex\s+[a-z0-9]+|"
                             r"attachment\s+[a-z0-9]+|第[一二三四五六七八九十\d]+[章节部分])\b",
                             text, re.I))
    if numbered:
        return True  # 章节编号是强信号，直接判为候选

    # 非编号行：要求上一行已收尾（否则本行多半是换行的续行片段），且后接更长的正文
    prev_text = ((prev_block or {}).get("text") or "").strip()
    if prev_block is not None and prev_text and not TERMINAL_RE.search(prev_text):
        return False
    if next_text and len(next_text) > len(text) + 20:
        return True
    return False


def extract_text(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.read().splitlines()

    blocks = []
    no = 0
    skipped_markers = 0
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        # 分页标记：跳过，不计入译文
        if PAGE_MARKER_RE.match(stripped):
            skipped_markers += 1
            i += 1
            continue

        # 页眉页脚/水印残留：标为 boilerplate，渲染时默认跳过
        if BOILERPLATE_RE.match(stripped) and len(stripped) <= 40:
            no += 1
            blocks.append({"no": no, "type": "boilerplate", "text": stripped})
            i += 1
            continue

        # 代码块
        if CODE_FENCE_RE.match(line):
            i += 1
            buf = []
            while i < len(lines) and not CODE_FENCE_RE.match(lines[i]):
                buf.append(lines[i])
                i += 1
            i += 1
            no += 1
            blocks.append({"no": no, "type": "code", "text": "\n".join(buf)})
            continue

        # 表格（当前行以 | 开头且下一行为分隔行）
        if stripped.startswith("|") and i + 1 < len(lines) and TABLE_SEP_RE.match(lines[i + 1]):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not TABLE_SEP_RE.match(lines[i]):
                    rows.append(cells)
                i += 1
            if rows:
                no += 1
                blocks.append({"no": no, "type": "table", "header": True, "rows": rows})
            continue

        hm = MD_HEADING_RE.match(line)
        if hm:
            no += 1
            blocks.append({"no": no, "type": "heading", "level": len(hm.group(1)),
                           "text": hm.group(2).strip()})
            i += 1
            continue

        if stripped.startswith(">"):
            no += 1
            blocks.append({"no": no, "type": "quote", "text": stripped.lstrip("> ").strip()})
            i += 1
            continue

        bm = BULLET_RE.match(line)
        if bm:
            no += 1
            blocks.append({"no": no, "type": "list_item", "list": "bullet",
                           "level": (len(line) - len(line.lstrip())) // 2,
                           "text": bm.group(1)})
            i += 1
            continue

        om = ORDERED_RE.match(line)
        if om or ROMAN_RE.match(line):
            no += 1
            blocks.append({"no": no, "type": "list_item", "list": "keep",
                           "level": 0, "text": stripped})
            i += 1
            continue

        nxt = next((l.strip() for l in lines[i + 1:] if l.strip()), "")
        no += 1
        para = {"no": no, "type": "paragraph", "text": stripped}
        if _heading_candidate(stripped, nxt, blocks[-1] if blocks else None):
            para["heading_candidate"] = True
        blocks.append(para)
        i += 1
    return blocks, skipped_markers


# ---------------- 统计与出口 ----------------

def _char_count(blocks):
    total = 0
    for b in blocks:
        if b["type"] == "table":
            for row in b.get("rows", []):
                for cell in row:
                    total += len(re.sub(r"\s+", "", cell or ""))
        else:
            total += len(re.sub(r"\s+", "", b.get("text", "") or ""))
    return total


def main():
    ap = argparse.ArgumentParser(description="抽取原文结构骨架，供按原格式排版输出译文")
    ap.add_argument("--input", "-i", required=True, help="原文文件（.docx / .md / .txt）")
    ap.add_argument("--out", "-o", default="", help="骨架 JSON 输出路径；缺省打印到标准输出")
    args = ap.parse_args()

    path = args.input
    if not os.path.exists(path):
        sys.stderr.write(f"[ERROR] 文件不存在: {path}\n")
        sys.exit(1)

    ext = os.path.splitext(path)[1].lower()
    skipped_markers = 0
    if ext == ".docx":
        blocks = extract_docx(path)
    elif ext in (".md", ".markdown", ".txt"):
        blocks, skipped_markers = extract_text(path)
    else:
        sys.stderr.write(f"[ERROR] 暂不支持的格式: {ext}（支持 .docx / .md / .txt）\n")
        sys.exit(1)

    stats = {
        "blocks": len(blocks),
        "headings": sum(1 for b in blocks if b["type"] == "heading"),
        "heading_candidates": sum(1 for b in blocks if b.get("heading_candidate")),
        "paragraphs": sum(1 for b in blocks if b["type"] == "paragraph"),
        "list_items": sum(1 for b in blocks if b["type"] == "list_item"),
        "tables": sum(1 for b in blocks if b["type"] == "table"),
        "char_count_estimate": _char_count(blocks),
        "skipped_page_markers": skipped_markers,
    }
    data = {"source_file": os.path.abspath(path), "stats": stats, "blocks": blocks}

    text = json.dumps(data, ensure_ascii=False, indent=2)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"[OK] 骨架已导出: {args.out}")
        print(f"[STATS] {json.dumps(stats, ensure_ascii=False)}")
    else:
        print(text)


if __name__ == "__main__":
    main()
