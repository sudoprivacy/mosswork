# 输出规格：JSON 契约 · 排版规则 · 自检（references/output_spec.md）

本 skill 只交付**一份文件：译文本身**（`*_推荐译文.docx`，可选 `.md`）。**不生成任何"原文/译文对照"版本，不出质检报告**；差错率与缺陷清单只用于驱动改进与留痕，不进交付文档。

本文件是**交付物的 JSON 契约与排版规则的唯一权威来源**（质检判定基准见 `standards.md`）。排版质量 = 交付质量的一半：客户先看结构，再看字句。

---

## 一、流程

```
原文文件 ──extract_source.py──▶ skeleton.json（blocks 骨架 + stats）
                                     │ 逐块翻译：no 与 type 不变，只换 text
                                     ▼
                              result.json
                                     │ generate_deliverable.py
                                     ▼
                              《推荐译文》.docx / .md
```

骨架的 `stats`（标题/段落/列表/表格数、字数）是**结构守恒基准**，渲染后必须逐项对上。`heading_candidate` 是纯文本的标题候选，由模型确认后升为 `heading`；`boilerplate`（页眉页脚/水印残留）渲染时自动跳过，不译出。

---

## 二、JSON 结构（最小可运行示例）

```json
{
  "meta": {
    "project": "设备技术规范", "date": "2026-08-28",
    "source_language": "en", "target_language": "zh",
    "doc_title": "技术规范（TS-001）", "doc_subtitle": "通用设备　|　第二版",
    "purpose_class": "II", "purpose_CA": 0.75, "difficulty_K": 1.0,
    "char_count_W": 4200, "glossary": "MFS=最低功能规范；BESS=储能系统",
    "pe_depth": "深度译后编辑（full PE）",
    "iteration": {"rounds": 2, "history": [{"round": 0, "rate": 0.70}, {"round": 1, "rate": 0.0}],
                  "converged": true, "residual_defects": 0}
  },
  "standard": "GB/T 19682-2005 + GB/T 40036-2021",
  "blocks": [
    {"no": 1, "type": "heading", "level": 1, "text": "1. 总则"},
    {"no": 2, "type": "paragraph", "text": "本规范规定了设备的设计、供货、安装与调试要求。"},
    {"no": 3, "type": "list_item", "list": "bullet", "level": 0, "text": "符合最低功能规范（MFS）；"},
    {"no": 4, "type": "list_item", "list": "keep", "level": 0, "text": "a) 提交经批准的图纸；"},
    {"no": 5, "type": "caption", "text": "表 1 - 主要设备清单"},
    {"no": 6, "type": "table", "header": true,
     "rows": [["序号", "设备", "数量"], ["1", "储能系统（BESS）", "30 MW / 60 MWh"]]},
    {"no": 7, "type": "quote", "text": "注：组件须通过 IEC TS 62804-2 的抗 PID 测试。"},
    {"no": 8, "type": "code", "text": "PPA_TERM = 21 年\nCOD_DATE = 2028-06-30"},
    {"no": 9, "type": "page_break"},
    {"no": 10, "type": "boilerplate", "text": "Strictly Confidential 3"}
  ],
  "alignment": [
    {"no": 1, "source": "1. General", "translation": "1. 总则", "recommended": "1. 总则"}
  ],
  "defects": [
    {"no": 1, "location": "块3", "category": "Ⅲ", "source": "Minimum Functional Specification",
     "original_translation": "最低功能说明", "suggested_translation": "符合最低功能规范（MFS）",
     "reason": "术语不统一：MFS 前文已定名「最低功能规范」（GB/T 19682-2005 第Ⅲ类）。"}
  ],
  "defect_counts": {"Ⅰ": 0, "Ⅱ": 0, "Ⅲ": 1, "Ⅳ": 0},
  "checklist_40036": [{"item": "术语/用语一致", "ok": false, "note": "MFS 译名已统一"}],
  "error_rate_permil": 0.70, "pass_threshold_permil": 1.5, "converged": true
}
```

### 2.1 脚本消费字段（决定交付文档）

| 字段 | 必填 | 说明 |
| :--- | :--- | :--- |
| `blocks[]` | **是** | 渲染主体，`no`/`type` 必须与骨架一致 |
| `blocks[].type` | 是 | `heading` / `paragraph` / `list_item` / `table` / `caption` / `quote` / `code` / `page_break` / `boilerplate` |
| `blocks[].text` | 文本块必填 | 该块**译文**（非原文）；支持 `\n` 换行 |
| `blocks[].level` | heading 必填 | 标题层级 1~4（>4 按 4 渲染）；list_item 为缩进层级，默认 0 |
| `blocks[].list` | list_item 必填 | `bullet` / `number` / `keep`（**原文带编号一律 keep**） |
| `blocks[].rows` / `header` | table 必填 | 二维数组；`header: true` 时首行渲染为深蓝表头 |
| `blocks[].bold` | 否 | 整段加粗 |
| `meta.doc_title` / `doc_subtitle` | 否 | 封面式抬头，**不占 Heading 层级**；缺省则直接从正文开始 |

容错：`boilerplate` 自动跳过并计数；`text` 为空的块不渲染；未知块类型忽略。

### 2.2 过程记录字段（驱动迭代与追溯，不渲染）

| 字段 | 说明 |
| :--- | :--- |
| `alignment[]` | 逐段配对（`source`/`translation`/`recommended`），用于质检与防漏段 |
| `defects[]` | 缺陷与修订（`category`、`suggested_translation`、可选 `reason`）；**修正须同步进 `blocks`** |
| `meta.iteration` | `{"rounds", "history":[{"round","rate"}], "converged", "residual_defects"}` |
| `defect_counts` / `error_rate_permil` / `converged` | 各轮质检留痕 |
| `checklist_40036` | GB/T 40036-2021 定性清单执行记录 |
| `meta.glossary` / `pe_depth` / `purpose_CA` / `difficulty_K` / `char_count_W` | 本次打磨口径与质检参数 |

---

## 三、块类型与渲染规则

| 块类型 | 渲染结果 | 注意 |
| :--- | :--- | :--- |
| `heading` | Word Heading 1~4（黑体，16 / 14 / 12.5 / 11.5pt） | 层级取原文；超过 4 级按 4 级 |
| `paragraph` | 正文：宋体 / Times New Roman 11pt，行距 1.25，段后 6pt | 不额外首行缩进（与原文一致）；整段加粗用 `bold: true` |
| `list_item` + `bullet` | Word `List Bullet` | 原文已带 `•` 等符号先剥掉，避免双符号 |
| `list_item` + `number` | Word `List Number` | 仅原文**无**编号时使用，否则双重编号 |
| `list_item` + `keep` | 缩进段落，保留原文编号/字母/罗马数字 | **默认走这条**：原文带编号的条目一律 keep |
| `table` | Table Grid，深蓝表头（1F4E79 白字），偶数行斑马纹（F2F6FA），列宽按内容自适应（总宽 16cm） | 行列数与表头照搬，只换文字 |
| `caption` | 居中 9.5pt 灰色 | 位置随原文（表注多在表上，图注多在图下） |
| `quote` | 缩进斜体 | 注释、引述块 |
| `code` | Consolas 9.5pt + 浅灰底纹（F5F5F5） | 代码/公式/参数表原样不译 |
| `page_break` | 分页符 | 保持原文分页 |
| `boilerplate` | 自动跳过 | 页眉页脚/水印残留不译出 |

**版面**：A4，页边距上 2.2 / 下 2.0 / 左右 2.5 cm；页脚页码居中 9pt。文档不含原文列、差错率、缺陷计数、判定结论或任何说明性文字。

---

## 四、格式保真五原则

1. **结构守恒优先于语句流畅**：先复制骨架再填译文，绝不因目标语言更顺就重排结构——客户要逐条核对原文，结构一变就失效。
2. **编号照搬不重排**：`1.` / `1.1` / `(a)` / `vii)` / `Appendix A` 原样保留；不改中文数字序号，不"修正"原文跳号（疑有误则在译文注明，不静默修改）。
3. **表格只换文字**：行列数、表头、单元格边界、数字与单位的列位全部不动。
4. **格式层全文一致**：术语、单位符号、日期格式、千分位、缩略语大小写全文统一（第Ⅲ/Ⅳ类差错的直接来源）。
5. **不译元素原样保留**：标准号、型号、合同号、URL、邮箱、路径、代码变量名、货币数值——不翻译、不改大小写、不加空格。

**长文档分块**：按骨架 `no` 区间切块，块间重叠 1~2 段，每块带上级标题路径（如 `2 > 2.1`）；合并按 `no` 升序，**不重新编号**。

---

## 五、输出前自检清单（渲染前逐条过）

**结构层**

- [ ] 标题 / 段落 / 列表项 / 表格数与骨架 `stats` 完全一致
- [ ] 每个 `no` 都已翻译，无跳块、无漏段
- [ ] 编号无跳号、无重复、**无双重编号**（如 `1. 1. xxx`）
- [ ] 表格行列数一致，表头未丢失，数字与单位未被移动

**内容层**

- [ ] 无占位符残留（`TODO` / `待译` / `xxx` / `[...]`）
- [ ] 无原文整句残留（有意保留的术语、编号、代码除外）
- [ ] 数据校准轮每一处疑点已核销（数字、单位、日期、专有编号）
- [ ] 术语表已应用且全文一致

**标记层**

- [ ] 无 Markdown 残留符号（`**`、`#`、`|`、`---`）
- [ ] 无分页标记（`--- PAGE n ---`、`第 n 页`）与页眉页脚残留
- [ ] 中英标点、空格、引号、破折号用法统一
- [ ] 单位符号与数字间空格规则统一（如 `50 mg` / `30 MW`）

---

## 六、最常见的 8 类格式缺陷

| # | 缺陷 | 症状 | 预防 |
| :--- | :--- | :--- | :--- |
| 1 | 标题降级 | 章节渲染成正文，文档失去骨架 | 以骨架 `heading_candidate` + 编号模式判定，别靠"看起来像不像" |
| 2 | 手工重排编号 | 译文序号与原文对不上 | 一律照搬，不改号 |
| 3 | 双重编号 | `List Number` + 原文 `1.` → `1. 1.` | 原文带编号的条目用 `keep` |
| 4 | 表格错位 | 行列数变了、表头丢了、单位挪列 | 整体翻译，逐格核对，不重排 |
| 5 | 单位不统一 | 前文「毫克」后文「mg」 | 先定术语表写法，再全文统一 |
| 6 | 标点混用 | 中英标点、多余空格 | 自检标记层逐条过 |
| 7 | 分块拼接错误 | 标题重复、编号断号、段落错位 | 按 `no` 升序拼接，块间留重叠，不重新编号 |
| 8 | 页眉页脚混入正文 | `Strictly Confidential`、`Page 3` 被译出 | 骨架标为 `boilerplate`，渲染自动跳过 |

---

## 七、命令

```bash
# 1) 抽取原文骨架（原文是文件时必做）
python scripts/extract_source.py --input 原文.docx --out skeleton.json

# 2) 渲染唯一交付物
python scripts/generate_deliverable.py --input result.json --out-dir . --prefix 项目名
# → 项目名_推荐译文.docx   （--format md 输出 Markdown）

# 缺省 --prefix 用时间戳命名；缺省 --out-dir 输出到当前目录
# 【已废弃】--mode：2.0 起单一流水线，该参数被忽略
```

`extract_source.py` 与 `generate_deliverable.py` 需 `python-docx`（缺失时 `pip install python-docx`）；`--format md` 不需要额外依赖。
