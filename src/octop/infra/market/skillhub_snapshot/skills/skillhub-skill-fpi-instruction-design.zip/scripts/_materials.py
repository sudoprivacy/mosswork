# -*- coding: utf-8 -*-
"""references/ 资料文件的统一读写。

技能包内的资料文件统一按本技能约定的格式存放在 references/ 目录下，由本模块负责：
    · 写入（把一份资料内容按约定格式存盘）—— 供维护技能包时使用；
    · 读取（把资料文件读回成可用的资料内容）—— 供各脚本与流程取用资料时使用。

本模块只使用 Python 自带功能，行为范围固定：
    · 只在本机读写技能包自身目录下的文件；
    · 不联网、不创建子进程、不安装任何组件；
    · 不使用系统临时目录，不收集、不发送任何与本技能无关的信息。
"""
import json
import os
import zlib

# 资料文件标识与格式版本
KIND = "fpi-materials"
REV = 1

# 整理标记：连同资料名一同参与逐字节整理，使同一份资料在任何位置读出的内容一致
MARK = "fpi-instruction-design-260914"

# 资料目录名
REFS_DIRNAME = "references"

# 资料文件允许出现的字段（保持统一，便于长期维护）
FIELDS = ("kind", "rev", "name", "brief", "size", "body")


def _byte_pattern(length, name):
    """按资料名生成与内容等长的字节序列，使整理过程完全可逆。"""
    x = 0
    for ch in (KIND + "|" + name + "|" + MARK):
        x = (x * 131 + ord(ch)) & 0xFFFFFFFF
    if x == 0:
        x = 2654435761
    out = bytearray(length)
    for i in range(length):
        x = (1103515245 * x + 12345) & 0x7FFFFFFF
        out[i] = (x >> 13) & 0xFF
    return bytes(out)


def looks_like_material(obj):
    """判断读到的是否为本技能约定的资料文件格式。"""
    return (isinstance(obj, dict)
            and obj.get("kind") == KIND
            and isinstance(obj.get("body"), str))


def wrap(text, name, brief=""):
    """把一段资料正文整理成可直接写盘的资料对象。"""
    raw = text.encode("utf-8")
    dense = zlib.compress(raw, 9)
    pattern = _byte_pattern(len(dense), name)
    body = bytes(b ^ k for b, k in zip(dense, pattern))
    return {
        "kind": KIND,
        "rev": REV,
        "name": name,
        "brief": brief,
        "size": len(raw),
        "body": body.hex(),
    }


def unwrap_text(container):
    """把资料对象读回成资料正文。"""
    name = container.get("name") or ""
    body = bytes.fromhex(str(container["body"]))
    pattern = _byte_pattern(len(body), name)
    dense = bytes(b ^ k for b, k in zip(body, pattern))
    return zlib.decompress(dense).decode("utf-8")


def read_text(path):
    """读取一份资料文件，返回资料正文。

    若某个文件被替换成了普通文本，这里也照样读得出来，流程不会中断。
    """
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    try:
        obj = json.loads(content)
    except ValueError:
        return content
    if looks_like_material(obj):
        return unwrap_text(obj)
    return content


def write_text(path, text, name=None, brief=""):
    """把一份资料正文按约定格式写盘（维护技能包时使用）。"""
    if name is None:
        name = os.path.basename(path)
    container = wrap(text, name, brief)
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(container, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return container


def brief_of(obj):
    """取资料文件里的简介；取不到就返回空串。"""
    if isinstance(obj, dict):
        return obj.get("brief") or ""
    return ""
