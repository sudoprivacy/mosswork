#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_docx.py —— 将结构化方案 JSON 渲染为 Word（.docx）教案文档

【用途】
当当前 AI 工具没有原生文档生成能力时，由 AI 运行本脚本产出 .docx。
（优先推荐使用 WorkBuddy 等工具自带的文档生成能力，质量更佳。）

【用法】
    python render_docx.py --plan plan.json --out 教案.docx
    python render_docx.py --plan plan.json --out 教案.docx --dir <输出基准目录>
    python render_docx.py --plan plan.json --out 教案.docx --footer <自备页脚文本路径>

【依赖】需本机具备生成 Word 的基础组件；若本机缺少该组件，脚本只输出一句通俗提示，
由 AI 工具改用它自带的文档生成能力直接产出文件。脚本自身不联网、不创建额外进程、
不安装任何组件。异常均给出通俗中文提示，不向用户抛代码。

【输出规范（已落实，开箱即用）】
  · 标题用微软雅黑，正文用宋体；不使用任何 Markdown 标记；不写入强制换行符（硬回车）。
  · 「三、学生学习效果评价」为加权评分量规矩阵表：行＝评价指标＋权重，列＝优秀/良好/中等/合格/待改进，
    每格给出详细且可量化的评分说明；表格自动置于横向页面以保证可读性。
  · 文末空五行后原样追加页脚（自动跳过空行，不产生多余空段）；页脚默认取自
    技能包 references 下的 footer-note 资料，无需另传参数。
  · 结构见 references 的 reply-spec 资料与 data/reply-spec.json。

【evaluation_rubric 结构（推荐）】
{
  "levels": [{"name": "优秀", "score": "90-100"}, ... 共五级],
  "rows": [
    {"indicator": "评价指标名称", "weight": 20,
     "descs": ["优秀档的量化说明", "良好档…", "中等档…", "合格档…", "待改进档…"]}
  ]
}
  旧式 list（元素含 dimension/levels）仍兼容，自动降级为两列表。
"""
import argparse
import importlib.util
import json
import os
import re
import sys


def _docx_ready():
    """本机是否具备生成 .docx 的基础组件（只做存在性检查，不做任何其它动作）。"""
    try:
        return importlib.util.find_spec("docx") is not None
    except Exception:
        return False


if not _docx_ready():
    print(json.dumps({
        "ok": False,
        "hint": ("本机缺少生成 Word 所需的基础组件，脚本方式本次用不了。"
                 "请让 AI 工具改用其自带的文档生成能力直接产出 .docx（推荐），"
                 "本次输出照样可以完成，用户无需做任何事。"),
    }, ensure_ascii=False))
    raise SystemExit(0)

from docx import Document
from docx.shared import Pt, RGBColor


def resolve_out(out_path, base_dir=""):
    """把输出路径解析为绝对路径：相对路径按基准目录（默认当前目录）展开。"""
    if not os.path.isabs(out_path):
        base = os.path.abspath(base_dir) if base_dir else os.getcwd()
        out_path = os.path.join(base, os.path.basename(out_path))
    out_path = os.path.abspath(out_path)
    d = os.path.dirname(out_path)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    return out_path


TITLE_FONT = "微软雅黑"
BODY_FONT = "宋体"

_MD_RE = re.compile(r"(\*\*|__|\*|_|`|#+\s*|>\s*|-{3,}|·\s*)")


def clean(s):
    """清洗文本：去掉 Markdown 标记，把内部换行/多余空格归并为正常空格。"""
    if not isinstance(s, str):
        s = "" if s is None else str(s)
    s = _MD_RE.sub("", s)
    s = s.replace("\r", " ").replace("\n", " ")
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip()


def load_footer_text(footer_path=""):
    """取页脚原文。

    默认读取技能包 references 下的 footer-note 资料；若显式传入文件路径，
    则按该路径读取。任一环节取不到时返回空串，不阻断正文渲染。
    """
    if footer_path:
        try:
            if os.path.exists(footer_path):
                with open(footer_path, "r", encoding="utf-8") as f:
                    return f.read()
        except Exception:
            return ""
        return ""
    here = os.path.dirname(os.path.abspath(__file__))
    refs = os.path.join(os.path.dirname(here), "references")
    path = os.path.join(refs, "footer-note.json")
    if not os.path.exists(path):
        return ""
    try:
        if here not in sys.path:
            sys.path.insert(0, here)
        import _materials
        return _materials.read_text(path)
    except Exception:
        return ""


def _set_cjk(run, font):
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    run.font.name = font
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts')
        rpr.append(rfonts)
    rfonts.set(qn('w:eastAsia'), font)


def _style_fonts(doc):
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    normal = doc.styles['Normal']
    normal.font.name = BODY_FONT
    normal.font.size = Pt(12)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts')
        rpr.append(rfonts)
    rfonts.set(qn('w:eastAsia'), BODY_FONT)
    for hname in ('Heading 1', 'Heading 2', 'Heading 3', 'Title'):
        try:
            st = doc.styles[hname]
            st.font.name = TITLE_FONT
            rpr = st.element.get_or_add_rPr()
            rfonts = rpr.find(qn('w:rFonts'))
            if rfonts is None:
                rfonts = OxmlElement('w:rFonts')
                rpr.append(rfonts)
            rfonts.set(qn('w:eastAsia'), TITLE_FONT)
        except KeyError:
            pass


def _title(doc, text):
    p = doc.add_paragraph()
    p.alignment = 1
    r = p.add_run(clean(text))
    _set_cjk(r, TITLE_FONT)
    r.bold = True
    r.font.size = Pt(16)


def _h(doc, text, level=1):
    p = doc.add_heading(level=level)
    r = p.add_run(clean(text))
    _set_cjk(r, TITLE_FONT)


def _para(doc, label, text):
    p = doc.add_paragraph()
    if label:
        r = p.add_run(clean(label))
        _set_cjk(r, BODY_FONT)
        r.bold = True
    if text:
        r2 = p.add_run(clean(text))
        _set_cjk(r2, BODY_FONT)


def _bullets(doc, items):
    for it in items:
        p = doc.add_paragraph(style='List Bullet')
        r = p.add_run(clean(it))
        _set_cjk(r, BODY_FONT)


def _cell_multiline(cell, text):
    """单元格多行：用多个段落表示，绝不写入强制换行符（硬回车）。"""
    lines = [clean(x) for x in str(text).split("\n") if clean(x)]
    if not lines:
        lines = [""]
    cell.paragraphs[0].text = ""
    for i, ln in enumerate(lines):
        p = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
        r = p.add_run(ln)
        _set_cjk(r, BODY_FONT)


# ---------------------------------------------------------------------------
# 学生学习效果评价：评分量规矩阵表（行=评价指标+权重，列=五级评分）
# ---------------------------------------------------------------------------
def _shade(cell, hexcolor):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), hexcolor)
    tcPr.append(shd)


def _cell_fill(cell, text, size=9, bold=False, color=None, align=None, fill=None):
    """写入单元格：单段多 run，绝不产生硬回车。"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    cell.paragraphs[0].text = ""
    p = cell.paragraphs[0]
    if align == "center":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(clean(text))
    _set_cjk(r, BODY_FONT)
    r.bold = bold
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor(int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16))
    if fill:
        _shade(cell, fill)


def _set_col_widths(table, widths):
    from docx.shared import Inches
    table.autofit = False
    for row in table.rows:
        for i, w in enumerate(widths):
            if i < len(row.cells):
                row.cells[i].width = Inches(w)


def _apply_page(sec, landscape=False):
    from docx.enum.section import WD_ORIENT
    from docx.shared import Inches
    if landscape:
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width = Inches(11.69)
        sec.page_height = Inches(8.27)
        sec.left_margin = Inches(0.6)
        sec.right_margin = Inches(0.6)
        sec.top_margin = Inches(0.6)
        sec.bottom_margin = Inches(0.6)
    else:
        sec.orientation = WD_ORIENT.PORTRAIT
        sec.page_width = Inches(8.27)
        sec.page_height = Inches(11.69)
        sec.left_margin = Inches(0.9)
        sec.right_margin = Inches(0.9)
        sec.top_margin = Inches(0.8)
        sec.bottom_margin = Inches(0.8)
    return sec


def _landscape_section(doc):
    """新增横向页面（A4 横向），返回该 section。"""
    from docx.enum.section import WD_SECTION
    return _apply_page(doc.add_section(WD_SECTION.NEW_PAGE), landscape=True)


def _portrait_section(doc):
    """恢复纵向页面（A4 纵向）。"""
    from docx.enum.section import WD_SECTION
    return _apply_page(doc.add_section(WD_SECTION.NEW_PAGE), landscape=False)


DEFAULT_LEVELS = [
    {"name": "优秀", "score": "90-100"},
    {"name": "良好", "score": "80-89"},
    {"name": "中等", "score": "70-79"},
    {"name": "合格", "score": "60-69"},
    {"name": "待改进", "score": "＜60"},
]


def _normalize_rubric(rubric):
    """兼容两种写法：dict（新，含权重矩阵）与 list（旧，维度+等级）。"""
    if isinstance(rubric, dict):
        levels = rubric.get("levels") or DEFAULT_LEVELS
        rows = rubric.get("rows") or []
        rows = [r for r in rows if isinstance(r, dict)]
        if rows:
            return levels, rows
        return levels, []
    if isinstance(rubric, list):
        return DEFAULT_LEVELS, rubric
    return DEFAULT_LEVELS, []


def _render_rubric(doc, rubric):
    """渲染加权评分量规矩阵表；旧式 list 结构自动降级为两列表。"""
    levels, rows = _normalize_rubric(rubric)
    if not rows:
        _para(doc, "", "（请在 plan.json 的 evaluation_rubric 中补充量规）")
        return False
    # 旧结构（元素含 dimension/levels）走降级渲染
    if rows and ("indicator" not in rows[0]):
        table = doc.add_table(rows=1, cols=2)
        table.style = 'Table Grid'
        for idx, txt in enumerate(("评价维度", "等级描述 / 分值")):
            _cell_fill(table.rows[0].cells[idx], txt, size=10, bold=True,
                       color="#FFFFFF", align="center", fill="#4A5568")
        for row in rows:
            cells = table.add_row().cells
            _cell_multiline(cells[0], row.get("dimension", ""))
            lvs = row.get("levels", [])
            _cell_multiline(cells[1], "；".join(
                "{}（{}分）".format(lv.get('desc', ''), lv.get('score', '')) for lv in lvs))
        return False

    # 新结构：横向页面承载 7 列矩阵
    _landscape_section(doc)
    _h(doc, "三、学生学习效果评价", 1)
    _para(doc, "", "本量规按评价指标加权计分：总分 = Σ（各指标得分 × 权重）。"
                   "各指标得分对照右侧五级评分说明评定。")

    ncols = 2 + len(levels)
    table = doc.add_table(rows=2, cols=ncols)
    table.style = 'Table Grid'
    table.alignment = 1

    # 第一行：合并的标题单元格（评价指标 / 权重 / 五级）
    hdr = table.rows[0].cells
    _cell_fill(hdr[0], "评价指标", size=10, bold=True, color="#FFFFFF", align="center", fill="#2C3E50")
    _cell_fill(hdr[1], "权重", size=10, bold=True, color="#FFFFFF", align="center", fill="#2C3E50")
    merged = hdr[2].merge(hdr[ncols - 1])
    _cell_fill(merged, "评分等级与评分说明", size=10, bold=True, color="#FFFFFF",
               align="center", fill="#2C3E50")

    # 第二行：五级表头
    hdr2 = table.rows[1].cells
    _cell_fill(hdr2[0], "（按任务分析确定）", size=8, bold=False, align="center", fill="#EDF2F7")
    _cell_fill(hdr2[1], "（%）", size=8, bold=False, align="center", fill="#EDF2F7")
    for i, lv in enumerate(levels):
        _cell_fill(hdr2[2 + i], "{}（{}分）".format(clean(lv.get("name", "")), clean(lv.get("score", ""))),
                   size=9, bold=True, color="#FFFFFF", align="center", fill="#5A6C7D")

    # 数据行
    shade = ["#FFFFFF", "#F7FAFC"]
    for ri, row in enumerate(rows):
        cells = table.add_row().cells
        ind = clean(row.get("indicator", ""))
        if row.get("note"):
            ind = ind + "（" + clean(row.get("note", "")) + "）"
        _cell_fill(cells[0], ind, size=9, bold=True, fill=shade[ri % 2])
        w = row.get("weight", "")
        _cell_fill(cells[1], "{}%".format(w) if w != "" else "", size=9, bold=True,
                   align="center", fill=shade[ri % 2])
        descs = row.get("descs") or row.get("levels") or []
        for i in range(len(levels)):
            d = descs[i] if i < len(descs) else ""
            _cell_fill(cells[2 + i], d, size=8.5, fill=shade[ri % 2])

    total_w = sum(float(r.get("weight", 0) or 0) for r in rows)
    tail = table.add_row().cells
    m = tail[0].merge(tail[1])
    _cell_fill(m, "合计权重", size=9, bold=True, align="center", fill="#EDF2F7")
    m2 = tail[2].merge(tail[ncols - 1])
    _cell_fill(m2, "{}%　（总分 = Σ 各指标得分 × 权重 ÷ 100）".format(
        int(total_w) if float(total_w).is_integer() else total_w), size=9, bold=True, fill="#EDF2F7")

    usable = 11.69 - 1.2
    rest = (usable - 2.15 - 0.6) / max(len(levels), 1)
    _set_col_widths(table, [2.15, 0.6] + [rest] * len(levels))
    return True


def render(plan, out_path, footer_text):
    doc = Document()
    _style_fonts(doc)
    _apply_page(doc.sections[0], landscape=False)   # 全文统一 A4 纵向

    _title(doc, "五星教学模式（首要教学原理）教案")
    info = [
        ("课程名称", plan.get("course", "")),
        ("专业名称", plan.get("major", "")) if plan.get("audience") == "大学" else None,
        ("授课对象", plan.get("audience", "")),
        ("授课内容", plan.get("content", "")),
        ("课时", plan.get("period", "")),
        ("设计者", plan.get("designer", "")),
    ]
    _h(doc, "基本信息", 2)
    for row in info:
        if row and row[1]:
            _para(doc, row[0] + "：", row[1])

    # 一、教学内容
    _h(doc, "一、教学内容", 1)
    for k in plan.get("knowledge", []):
        _para(doc, "【" + clean(k.get('type', '')) + "】" + clean(k.get('name', '')) + "：", k.get("detail", ""))
    tree = plan.get("knowledge_tree", "")
    if tree:
        _para(doc, "知识树图：", tree)

    # 二、五星教学设计
    _h(doc, "二、五星教学设计", 1)

    _h(doc, "2.1 聚焦问题", 2)
    _h(doc, "2.1.1 教学目标", 3)
    for o in plan.get("objectives", []):
        _para(doc, "", o)
    _h(doc, "2.1.2 聚焦问题", 3)
    _bullets(doc, plan.get("focus_problems", []))

    _h(doc, "2.2 激活旧知", 2)
    _bullets(doc, plan.get("activate", []))

    _h(doc, "2.3 示证新知", 2)
    _h(doc, "一般信息（事实/概念）", 3)
    for g in plan.get("demonstrate_general", []):
        _para(doc, clean(g.get("point", "")), "")
        for ex in g.get("examples", []):
            _para(doc, "例子：", ex)
        for qz in g.get("quiz", []):
            _para(doc, "提问/测试：", f"{qz.get('q','')}（参考答案：{qz.get('a','')}）")
    _h(doc, "具体描述（程序/原理/过程）", 3)
    for s in plan.get("demonstrate_specific", []):
        _para(doc, "", s)

    _h(doc, "2.4 应用新知", 2)
    ap = plan.get("apply", {})
    _para(doc, "学生回答安排：", ap.get("answer_arrangement", ""))
    ps = ap.get("practice_steps", {})
    for step in ["识别实例", "执行实例", "预测结果", "指出缺失缺陷"]:
        _para(doc, step + "：", ps.get(step, ""))
    _para(doc, "教学支架：", ap.get("scaffold", ""))

    _h(doc, "2.5 融会贯通", 2)
    _bullets(doc, plan.get("integrate", []))

    # 三、学生学习效果评价（加权评分量规矩阵表）
    rubric = plan.get("evaluation_rubric", [])
    switched = _render_rubric(doc, rubric)
    if switched:
        _portrait_section(doc)

    # 四、教学设计改进建议
    _h(doc, "四、教学设计改进建议", 1)
    _para(doc, "", plan.get("improvement", ""))

    # footer：空五行 + 原样追加（footer 本身不清洗，保持用户原文；跳过空行避免多余空段）
    for _ in range(5):
        doc.add_paragraph("")
    if footer_text:
        for ln in footer_text.split("\n"):
            if not ln.strip():
                continue
            p = doc.add_paragraph()
            r = p.add_run(ln.rstrip("\r"))
            _set_cjk(r, BODY_FONT)

    doc.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser(description="渲染 Word 教案")
    ap.add_argument("--plan", required=True, help="build_plan.py 输出的方案 JSON")
    ap.add_argument("--out", default="教案.docx", help="输出 .docx 路径")
    ap.add_argument("--dir", default="", help="--out 为相对路径时的基准目录；不传则用当前目录")
    ap.add_argument("--footer", default="",
                    help="自备页脚文本路径；不传则自动取 references 下的 footer-note 资料")
    args = ap.parse_args()

    try:
        with open(args.plan, "r", encoding="utf-8") as f:
            plan = json.load(f)
        footer_text = load_footer_text(args.footer)
        out_path = resolve_out(args.out, args.dir)
        path = render(plan, out_path, footer_text)
        print(json.dumps({"ok": True, "docx": path}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"ok": False, "hint": f"生成 Word 出错：{e}。请改用 AI 工具原生文档生成能力，或检查 plan.json 内容是否完整。"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
