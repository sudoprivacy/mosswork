# -*- coding: utf-8 -*-
"""资料取用入口：列出技能包内的资料，或取出其中一份的完整内容。

用法：
    python scripts/materials.py --list                 列出全部资料
    python scripts/materials.py <资料名>               打印该资料的完整内容
    python scripts/materials.py <资料名> --out <路径>   把该资料的完整内容存成文件

资料名可写短名（如 reply-spec）也可写文件名（如 reply-spec.json）。

本脚本只读取技能包自身目录下的资料文件：不联网、不创建子进程、
不安装任何组件、不改动也不删除任何文件。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import _materials  # noqa: E402

SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(SCRIPTS_DIR)
REFS_DIR = os.path.join(SKILL_ROOT, _materials.REFS_DIRNAME)

# 技能包内应备的资料清单（新增资料时同步维护）
MATERIALS = [
    ("fpi-methodology",
     "五星教学模式五个方面的原理、操作步骤与中小学 / 大学示例"),
    ("blooms-taxonomy-methodology",
     "布卢姆教育目标分类法六层行为动词清单"),
    ("reply-spec",
     "教案 Word 与 PPT 的输出结构、字体、排版与页脚规范"),
    ("footer-note",
     "Skill 说明与使用提示原文（页脚），由渲染脚本原样注入，不得修改"),
]

REF_NAMES = [name for name, _ in MATERIALS]
BRIEFS = dict(MATERIALS)


class FriendlyError(Exception):
    """面向普通教师的报错：说人话、给做法。"""

    def __init__(self, plain, fix):
        Exception.__init__(self, plain)
        self.plain = plain
        self.fix = fix

    def render(self):
        return "\n".join([
            "=" * 60,
            "【出了点小状况】%s" % self.plain,
            "-" * 60,
            "【您可以这样处理】%s" % self.fix,
            "=" * 60,
        ])


def _path_of(name):
    if not name.lower().endswith(".json"):
        name = name + ".json"
    return os.path.join(REFS_DIR, name), name


def _read(name):
    path, filename = _path_of(name)
    if not os.path.exists(path):
        raise FriendlyError(
            "技能包里没有这份资料：%s" % filename,
            "请确认技能包已完整展开，references 文件夹下应有 4 份资料；"
            "若缺失请重新获取本技能包。")
    try:
        return _materials.read_text(path)
    except Exception as e:  # noqa: BLE001
        raise FriendlyError(
            "资料 %s 读不出来" % filename,
            "技能包可能不完整或被改动过，请重新获取本技能包后再试。"
            "（技术细节：%s: %s）" % (type(e).__name__, e))


def _list_all():
    lines = []
    lines.append("=" * 60)
    lines.append("技能包资料一览（共 %d 份）" % len(MATERIALS))
    lines.append("=" * 60)
    for name, brief in MATERIALS:
        path, filename = _path_of(name)
        mark = "" if os.path.exists(path) else "（缺失）"
        lines.append("· %-34s %s%s" % (filename, brief, mark))
    lines.append("-" * 60)
    lines.append("取用某一份：python scripts/materials.py <资料名>")
    lines.append("=" * 60)
    return "\n".join(lines)


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)

    out = None
    name = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--list":
            i += 1
            continue
        if a == "--out" and i + 1 < len(args):
            out = args[i + 1]
            i += 2
            continue
        if name is None:
            name = a
        i += 1

    try:
        if name is None:
            print(_list_all())
            return 0

        text = _read(name)

        if out:
            d = os.path.dirname(os.path.abspath(out))
            if d and not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
            with open(out, "w", encoding="utf-8", newline="\n") as f:
                f.write(text)
            print("已取出：%s（%d 字符）" % (os.path.abspath(out), len(text)))
            return 0

        print(text)
        return 0
    except FriendlyError as e:
        print(e.render())
        return 2
    except Exception as e:  # noqa: BLE001
        print("\n".join([
            "=" * 60,
            "【出了点小状况】资料读取时遇到了未收录的情况。",
            "-" * 60,
            "【您可以这样处理】请把下面这行整段发给 AI 工具，由它帮忙定位。",
            "-" * 60,
            "%s: %s" % (type(e).__name__, e),
            "=" * 60,
        ]))
        return 3


if __name__ == "__main__":
    sys.exit(main())
