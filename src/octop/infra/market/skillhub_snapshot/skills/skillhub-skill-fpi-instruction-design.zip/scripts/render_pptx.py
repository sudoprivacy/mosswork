#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_pptx.py —— 将结构化方案 JSON 渲染为视觉化 PPT（.pptx）说课 + 讲课课件

【用途】
当当前 AI 工具没有原生 PPT 生成能力时，由 AI 运行本脚本产出 .pptx。
（优先推荐使用 WorkBuddy 等工具自带的 PPT 生成能力，质量更佳。）

【设计目标：开箱即用、视觉化、内容翔实】
  · 全程使用色块卡片、箭头流程、图标徽章、对比列、柱状图等图示化表达，杜绝满篇文字。
  · 讲课部分依据 plan["classes"] 逐课渲染，每课 ≥20 页（封面 + 目标路线图 + 五方面各含分隔页与多张内容页）。
  · 说课部分五段论，每页一种可视化版式。
  · 配色、页脚、字体（微软雅黑）统一，符合 data/ppt-templates.json。

【plan.json 关键字段】
  course / audience / content / designer / template(配色id) / lessons
  lecture: {intro, sections:[{title,icon,points:[...]}]}     # 说课五段（可选，缺省由其他字段生成）
  classes: [                                                # 讲课逐课
    { title, goals:[...], roadmap:[...](可选),
      phases:[ {name, number, slides:[ {kind, title, ...}, ... ] }, ... ] }
  ]
  说明：slides 的 kind 支持 bullets / cards / flow / steps / compare / example /
        activity / principle / chart / map / qa / star5，详见本文件 draw_slide()。
        其中 star5 = 五星教学模式环形图示（中心聚焦问题 + 四相位顺时针循环），
        说课首段与每次课目标页会自动插入该图示，无需在 classes 中重复声明。

【用法】
    python render_pptx.py --plan plan.json --out 课件.pptx \
        --templates data/ppt-templates.json --template warm_orange \
        [--dir <输出基准目录>] [--footer <自备页脚文本路径>] [--mode all|lecture|teach]

    不传 --footer 时，页脚自动取自技能包 references 下的 footer-note 资料。
    不传 --dir 时，--out 为相对路径则按当前目录展开。

【依赖】需本机具备生成 PPT 的基础组件；若本机缺少该组件，脚本只输出一句通俗提示，
由 AI 工具改用它自带的 PPT 生成能力直接产出文件。脚本自身不联网、不创建额外进程、
不安装任何组件。所有异常均给出通俗中文提示，不向用户抛代码。
"""
import argparse
import importlib.util
import json
import os
import sys


def _pptx_ready():
    """本机是否具备生成 .pptx 的基础组件（只做存在性检查，不做任何其它动作）。"""
    try:
        return importlib.util.find_spec("pptx") is not None
    except Exception:
        return False


if not _pptx_ready():
    print(json.dumps({
        "ok": False,
        "hint": ("本机缺少生成 PPT 所需的基础组件，脚本方式本次用不了。"
                 "请让 AI 工具改用其自带的 PPT 生成能力直接产出 .pptx（推荐），"
                 "本次输出照样可以完成，用户无需做任何事。"),
    }, ensure_ascii=False))
    raise SystemExit(0)

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.shapes import MSO_CONNECTOR
from pptx.oxml.ns import qn
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION


def resolve_out(out_path, base_dir=""):
    """把输出路径解析为绝对路径：相对路径按基准目录（默认当前目录）展开。"""
    if not os.path.isabs(out_path):
        base = os.path.abspath(base_dir) if base_dir else os.getcwd()
        out_path = os.path.join(base, os.path.basename(out_path))
    out_path = os.path.abspath(out_path)
    d = os.path.dirname(out_path)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    return out_path


W = 13.333   # 幻灯片宽（英寸）
H = 7.5      # 幻灯片高
FONT = "微软雅黑"


# ----------------------------------------------------------------------------
# 基础工具
# ----------------------------------------------------------------------------
def _rgb(hexcolor):
    h = hexcolor.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _set_cjk(run, font=FONT):
    rPr = run._r.get_or_add_rPr()
    ea = rPr.find(qn('a:ea'))
    if ea is None:
        from lxml import etree
        ea = etree.SubElement(rPr, qn('a:ea'))
    ea.set('typeface', font)
    run.font.name = font


def _blank(prs):
    return prs.slides.add_slide(prs.slide_layouts[6])


def _safe(v, default=""):
    return v if isinstance(v, str) else ("" if v is None else str(v))


def load_footer_text(footer_path=""):
    """取页脚原文。

    默认读取技能包 references 下的 footer-note 资料；若显式传入文件路径，
    则按该路径读取。任一环节取不到时返回空串，不阻断正文渲染。
    """
    if footer_path:
        try:
            if os.path.exists(footer_path):
                with open(footer_path, "r", encoding="utf-8") as f:
                    return f.read()
        except Exception:
            return ""
        return ""
    here = os.path.dirname(os.path.abspath(__file__))
    refs = os.path.join(os.path.dirname(here), "references")
    path = os.path.join(refs, "footer-note.json")
    if not os.path.exists(path):
        return ""
    try:
        if here not in sys.path:
            sys.path.insert(0, here)
        import _materials
        return _materials.read_text(path)
    except Exception:
        return ""


# ----------------------------------------------------------------------------
# 形状与文本
# ----------------------------------------------------------------------------
def _rect(slide, l, t, w, h, fill=None, line=None, line_w=0.75, round=True, shadow=False):
    shp = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if round else MSO_SHAPE.RECTANGLE,
        Inches(l), Inches(t), Inches(w), Inches(h))
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = _rgb(fill)
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = _rgb(line)
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def _text(slide, l, t, w, h, lines, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.MIDDLE,
          wrap=True, margin=0.12):
    """lines: list of dict {text,size,bold,color,align,bullet,space_before}
    若 text 为 None 跳过该段落。"""
    tb = slide.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    try:
        tf.margin_left = Inches(margin)
        tf.margin_right = Inches(margin)
        tf.margin_top = Inches(margin * 0.6)
        tf.margin_bottom = Inches(margin * 0.6)
    except Exception:
        pass
    first = True
    for ln in lines:
        if ln is None:
            continue
        text = _safe(ln.get("text", ""))
        if text == "" and not first:
            continue
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = ln.get("align", align)
        if ln.get("space_before") is not None:
            p.space_before = Pt(ln["space_before"])
        if ln.get("space_after") is not None:
            p.space_after = Pt(ln["space_after"])
        # 支持一行内多段 run（用于主题色+正文）
        runs = ln.get("runs", None)
        if runs:
            for rdef in runs:
                r = p.add_run()
                r.text = _safe(rdef.get("text", ""))
                r.font.size = Pt(rdef.get("size", 16))
                r.font.bold = rdef.get("bold", False)
                col = rdef.get("color")
                if col:
                    r.font.color.rgb = _rgb(col)
                r.font.name = FONT
                _set_cjk(r, FONT)
            continue
        r = p.add_run()
        r.text = text
        r.font.size = Pt(ln.get("size", 16))
        r.font.bold = ln.get("bold", False)
        col = ln.get("color")
        if col:
            r.font.color.rgb = _rgb(col)
        r.font.name = FONT
        _set_cjk(r, FONT)
    return tb


def _badge(slide, cx, cy, d, fill, symbol, sym_color="#FFFFFF", sym_size=18):
    """圆形图标徽章：圆心(cx,cy)，直径 d。"""
    ov = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(cx - d / 2), Inches(cy - d / 2),
                                Inches(d), Inches(d))
    ov.fill.solid()
    ov.fill.fore_color.rgb = _rgb(fill)
    ov.line.fill.background()
    ov.shadow.inherit = False
    tf = ov.text_frame
    tf.word_wrap = False
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    r = p.add_run()
    r.text = symbol
    r.font.size = Pt(sym_size)
    r.font.bold = True
    r.font.color.rgb = _rgb(sym_color)
    r.font.name = FONT
    _set_cjk(r, FONT)
    return ov


def _arrow(slide, x, y, w, h, color, kind="right"):
    geom = {
        "right": MSO_SHAPE.RIGHT_ARROW,
        "down": MSO_SHAPE.DOWN_ARROW,
        "left": MSO_SHAPE.LEFT_ARROW,
        "up": MSO_SHAPE.UP_ARROW,
    }.get(kind, MSO_SHAPE.RIGHT_ARROW)
    shp = slide.shapes.add_shape(geom, Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = _rgb(color)
    shp.line.fill.background()
    shp.shadow.inherit = False
    return shp


def _mix(c1, c2, t):
    """把 c1 按 t 比例向 c2 混合（t=0 返回 c1，t=1 返回 c2）。用于生成浅色底。"""
    a = c1.lstrip("#")
    b = c2.lstrip("#")
    out = []
    for i in (0, 2, 4):
        va = int(a[i:i + 2], 16)
        vb = int(b[i:i + 2], 16)
        out.append(int(round(va + (vb - va) * t)))
    return "#%02X%02X%02X" % tuple(out)


def _header(slide, title, sub=None, tpl=None, dark=None):
    tpl = tpl or DEFAULT_TPL
    dark = dark or tpl["primary"]
    _rect(slide, 0, 0, W, 1.05, fill=dark, round=False)
    _rect(slide, 0, 1.05, W, 0.06, fill=tpl["accent"], round=False)
    lines = [{"text": title, "size": 24, "bold": True, "color": "#FFFFFF"}]
    _text(slide, 0.5, 0.12, W - 1.0, 0.8, lines, anchor=MSO_ANCHOR.MIDDLE)
    if sub:
        _text(slide, 0.5, 1.18, W - 1.0, 0.5,
              [{"text": sub, "size": 13, "bold": False, "color": tpl["muted"]}])


def _footer(slide, course, page, total, tpl=None):
    """页脚：仅保留右侧页码，不显示课程名等文字（用户要求）。"""
    tpl = tpl or DEFAULT_TPL
    _rect(slide, 0, H - 0.42, W, 0.42, fill=tpl["surface"], round=False)
    _text(slide, W - 2.0, H - 0.42, 1.6, 0.42,
          [{"text": f"{page} / {total}", "size": 10, "color": tpl["muted"], "align": PP_ALIGN.RIGHT}],
          anchor=MSO_ANCHOR.MIDDLE)


def _card(slide, l, t, w, h, title, body_lines, tpl, color, icon=None, icon_sym=None):
    """一张内容卡片（带标题色条/图标）。"""
    _rect(slide, l, t, w, h, fill="#FFFFFF", line=tpl["line"], line_w=1.0)
    # 左侧色条
    _rect(slide, l, t, 0.12, h, fill=color, round=False)
    top = t + 0.12
    if icon:
        _badge(slide, l + 0.55, top + 0.3, 0.6, color, icon_sym or "●", sym_size=16)
        tx = l + 1.0
        tw = w - 1.15
    else:
        tx = l + 0.32
        tw = w - 0.55
    if title:
        _text(slide, tx, top, tw, 0.5,
              [{"text": title, "size": 15, "bold": True, "color": color}])
        body_top = top + 0.55
    else:
        body_top = top + 0.05
    _text(slide, l + 0.32, body_top, w - 0.6, h - (body_top - t) - 0.15,
          body_lines, anchor=MSO_ANCHOR.TOP)


# ----------------------------------------------------------------------------
# 单页绘制（按 kind 分发）
# ----------------------------------------------------------------------------
def draw_slide(slide, spec, tpl, course, page, total):
    kind = spec.get("kind", "bullets")
    # 五星环形图示整页自成版式，自行绘制标题栏与页脚
    if kind in ("star5", "fpi_cycle", "five_star"):
        draw_star5(slide, spec, tpl, course, page, total)
        return
    title = spec.get("title", "")
    _header(slide, title, spec.get("sub"), tpl)
    color = spec.get("color") or tpl["primary"]

    if kind == "bullets":
        items = spec.get("items", [])
        cols = 1 if len(items) <= 6 else 2
        _bullet_grid(slide, items, tpl, color, cols)
    elif kind == "cards":
        _cards_grid(slide, spec.get("cards", []), tpl, color)
    elif kind == "flow":
        _flow(slide, spec.get("steps", []), tpl, color)
    elif kind == "steps":
        _steps(slide, spec.get("steps", []), tpl, color)
    elif kind == "compare":
        _compare(slide, spec.get("columns", []), tpl, color)
    elif kind == "example":
        _example(slide, spec, tpl, color)
    elif kind == "activity":
        _activity(slide, spec, tpl, color)
    elif kind == "principle":
        _principle(slide, spec, tpl, color)
    elif kind == "chart":
        _chart_slide(slide, spec, tpl, color)
    elif kind == "map":
        _map(slide, spec, tpl, color)
    elif kind == "qa":
        _qa(slide, spec, tpl, color)
    else:
        _bullet_grid(slide, spec.get("items", [spec.get("body", "")]), tpl, color, 1)
    _footer(slide, course, page, total, tpl)


def _bullet_grid(slide, items, tpl, color, cols=1, top=None, bottom=None):
    """条目列表。top/bottom 可指定绘制区纵向范围（英寸），避免与页面上方元素重叠。"""
    items = [_safe(x) for x in items if str(x).strip()]
    if not items:
        return
    area_t = top if top is not None else 1.7
    area_h = (bottom if bottom is not None else 6.8) - area_t
    gap = 0.25
    if cols == 1:
        n = len(items)
        ch = min(0.78, (area_h - gap * (n - 1)) / max(n, 1))
        for i, it in enumerate(items):
            t = area_t + i * (ch + gap)
            _rect(slide, 0.7, t, W - 1.4, ch, fill=tpl["surface"], line=tpl["line"], line_w=0.75)
            _badge(slide, 1.05, t + ch / 2, 0.42, color, "●", sym_size=12)
            _text(slide, 1.45, t, W - 2.2, ch,
                  [{"text": it, "size": 15, "color": tpl["ink"]}], anchor=MSO_ANCHOR.MIDDLE)
    else:
        rows = (len(items) + 1) // 2
        cw = (W - 1.4 - gap) / 2
        ch = min(1.5, (area_h - gap * (rows - 1)) / max(rows, 1))
        for i, it in enumerate(items):
            r, c = divmod(i, 2)
            l = 0.7 + c * (cw + gap)
            t = area_t + r * (ch + gap)
            _rect(slide, l, t, cw, ch, fill=tpl["surface"], line=tpl["line"], line_w=0.75)
            _badge(slide, l + 0.4, t + ch / 2, 0.42, color, "●", sym_size=12)
            _text(slide, l + 0.8, t, cw - 1.0, ch,
                  [{"text": it, "size": 14, "color": tpl["ink"]}], anchor=MSO_ANCHOR.MIDDLE)


def _cards_grid(slide, cards, tpl, color):
    if not cards:
        return
    area_t, area_h = 1.7, 5.1
    n = len(cards)
    cols = 2 if n <= 4 else 3
    rows = (n + cols - 1) // cols
    gap = 0.3
    cw = (W - 1.0 - gap * (cols - 1)) / cols
    ch = (area_h - gap * (rows - 1)) / rows
    for i, c in enumerate(cards):
        r, col = divmod(i, cols)
        l = 0.5 + col * (cw + gap)
        t = area_t + r * (ch + gap)
        ccol = c.get("color") or color
        body = []
        for b in c.get("points", [c.get("body", "")]):
            body.append({"text": "· " + _safe(b), "size": 13, "color": tpl["ink"], "space_after": 4})
        _card(slide, l, t, cw, ch, c.get("title", ""), body, tpl, ccol,
              icon=c.get("icon"), icon_sym=c.get("sym"))


def _flow(slide, steps, tpl, color):
    if not steps:
        return
    area_t = 2.2
    bh = 2.4
    n = len(steps)
    gap = 0.5
    bw = (W - 1.4 - gap * (n - 1)) / n
    for i, s in enumerate(steps):
        l = 0.7 + i * (bw + gap)
        _rect(slide, l, area_t, bw, bh, fill=tpl["surface"], line=color, line_w=1.25)
        _badge(slide, l + bw / 2, area_t + 0.45, 0.7, color, str(i + 1), sym_size=20)
        _text(slide, l + 0.15, area_t + 0.9, bw - 0.3, 0.5,
              [{"text": _safe(s.get("t", "")), "size": 15, "bold": True, "color": color, "align": PP_ALIGN.CENTER}])
        _text(slide, l + 0.15, area_t + 1.45, bw - 0.3, bh - 1.55,
              [{"text": _safe(s.get("d", "")), "size": 12, "color": tpl["ink"], "align": PP_ALIGN.CENTER}],
              anchor=MSO_ANCHOR.TOP)
        if i < n - 1:
            _arrow(slide, l + bw + 0.02, area_t + bh / 2 - 0.18, gap - 0.04, 0.36, color, "right")
    # 底部一句话
    note = _safe(slide_note(steps))
    if note:
        _text(slide, 0.7, area_t + bh + 0.3, W - 1.4, 0.6,
              [{"text": note, "size": 13, "italic": True, "color": tpl["muted"]}])


def slide_note(steps):
    return ""


def _steps(slide, steps, tpl, color):
    if not steps:
        return
    area_t, area_h = 1.8, 4.9
    n = len(steps)
    gap = 0.22
    rh = min(0.85, (area_h - gap * (n - 1)) / max(n, 1))
    for i, s in enumerate(steps):
        t = area_t + i * (rh + gap)
        _rect(slide, 0.7, t, W - 1.4, rh, fill="#FFFFFF", line=tpl["line"], line_w=0.75)
        _badge(slide, 1.05, t + rh / 2, 0.5, color, str(i + 1), sym_size=16)
        _text(slide, 1.5, t, (W - 1.4) * 0.32, rh,
              [{"text": _safe(s.get("t", "")), "size": 15, "bold": True, "color": color}], anchor=MSO_ANCHOR.MIDDLE)
        _text(slide, 1.5 + (W - 1.4) * 0.33, t, (W - 1.4) * 0.62, rh,
              [{"text": _safe(s.get("d", "")), "size": 13, "color": tpl["ink"]}], anchor=MSO_ANCHOR.MIDDLE)


def _compare(slide, columns, tpl, color):
    if not columns:
        return
    area_t, area_h = 1.8, 4.8
    n = len(columns)
    gap = 0.3
    cw = (W - 1.0 - gap * (n - 1)) / n
    for i, col in enumerate(columns):
        l = 0.5 + i * (cw + gap)
        ccol = col.get("color") or (tpl["palette"][i % len(tpl["palette"])] if tpl.get("palette") else color)
        _rect(slide, l, area_t, cw, area_h, fill="#FFFFFF", line=tpl["line"], line_w=1.0)
        _rect(slide, l, area_t, cw, 0.7, fill=ccol, round=False)
        _text(slide, l, area_t, cw, 0.7,
              [{"text": _safe(col.get("h", "")), "size": 16, "bold": True, "color": "#FFFFFF", "align": PP_ALIGN.CENTER}],
              anchor=MSO_ANCHOR.MIDDLE)
        body = []
        for it in col.get("items", []):
            body.append({"text": "▸ " + _safe(it), "size": 13, "color": tpl["ink"], "space_after": 6})
        _text(slide, l + 0.2, area_t + 0.85, cw - 0.4, area_h - 1.0, body, anchor=MSO_ANCHOR.TOP)


def _example(slide, spec, tpl, color):
    area_t = 1.8
    box_h = 1.5
    # 情境框
    _rect(slide, 0.7, area_t, W - 1.4, box_h, fill=tpl["surface"], line=color, line_w=1.25)
    _badge(slide, 1.15, area_t + 0.75, 0.7, color, "❓", sym_size=22)
    _text(slide, 1.7, area_t + 0.1, W - 2.6, 1.3,
          [{"text": "情境 / 案例", "size": 13, "bold": True, "color": color},
           {"text": _safe(spec.get("scenario", "")), "size": 14, "color": tpl["ink"]}],
          anchor=MSO_ANCHOR.MIDDLE)
    # 分析要点（从情境框下方开始，避免覆盖）
    items = spec.get("points", [])
    if items:
        label_t = area_t + box_h + 0.18
        _text(slide, 0.7, label_t, W - 1.4, 0.4,
              [{"text": "分析要点", "size": 15, "bold": True, "color": color}])
        _bullet_grid(slide, items, tpl, color, cols=1 if len(items) <= 6 else 2,
                     top=label_t + 0.45, bottom=7.0)


def _activity(slide, spec, tpl, color):
    area_t = 1.8
    box_h = 1.25
    _rect(slide, 0.7, area_t, W - 1.4, box_h, fill=color, round=True)
    _badge(slide, 1.2, area_t + 0.62, 0.7, "#FFFFFF", "✎", sym_color=color, sym_size=22)
    _text(slide, 1.75, area_t + 0.1, W - 2.6, 1.05,
          [{"text": "课堂活动", "size": 13, "bold": True, "color": "#FFFFFF"},
           {"text": _safe(spec.get("task", "")), "size": 15, "bold": True, "color": "#FFFFFF"}],
          anchor=MSO_ANCHOR.MIDDLE)
    items = spec.get("steps", spec.get("items", []))
    if items:
        # 从任务框下方开始绘制，避免覆盖（页脚带上沿 7.08）
        _bullet_grid(slide, items, tpl, color, cols=1 if len(items) <= 6 else 2,
                     top=area_t + box_h + 0.25, bottom=7.0)


def _principle(slide, spec, tpl, color):
    area_t = 2.2
    _rect(slide, 0.9, area_t, W - 1.8, 2.8, fill=tpl["surface"], line=color, line_w=1.5)
    _badge(slide, W / 2, area_t + 0.55, 0.85, color, "★", sym_size=26)
    _text(slide, 1.4, area_t + 1.0, W - 2.8, 1.6,
          [{"text": _safe(spec.get("text", "")), "size": 18, "bold": True, "color": tpl["ink"], "align": PP_ALIGN.CENTER}],
          anchor=MSO_ANCHOR.MIDDLE)
    note = _safe(spec.get("note", ""))
    if note:
        _text(slide, 1.4, area_t + 2.0, W - 2.8, 0.7,
              [{"text": note, "size": 13, "color": tpl["muted"], "align": PP_ALIGN.CENTER}])


def _chart_slide(slide, spec, tpl, color):
    cats = spec.get("categories", [])
    vals = spec.get("values", [])
    if not cats or not vals:
        _text(slide, 0.7, 3.0, W - 1.4, 1.0,
              [{"text": "（本页缺少图表数据）", "size": 14, "color": tpl["muted"]}])
        return
    try:
        cd = CategoryChartData()
        cd.categories = cats
        cd.add_series("数值", vals)
        gf = slide.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED,
                                    Inches(0.9), Inches(1.9), Inches(W - 1.8), Inches(4.4), cd)
        chart = gf.chart
        chart.has_legend = False
        chart.has_title = False
        plot = chart.plots[0]
        plot.has_data_labels = True
        plot.data_labels.font.size = Pt(11)
        plot.data_labels.font.bold = True
        ser = plot.series[0]
        ser.format.fill.solid()
        ser.format.fill.fore_color.rgb = _rgb(color)
        cat_ax = chart.category_axis
        cat_ax.tick_labels.font.size = Pt(11)
        val_ax = chart.value_axis
        val_ax.tick_labels.font.size = Pt(9)
        val_ax.has_major_gridlines = False
    except Exception:
        _text(slide, 0.7, 3.0, W - 1.4, 1.0,
              [{"text": "（图表渲染失败，已跳过）", "size": 14, "color": tpl["muted"]}])
    cap = _safe(spec.get("caption", ""))
    if cap:
        _text(slide, 0.9, 6.35, W - 1.8, 0.5,
              [{"text": cap, "size": 12, "color": tpl["muted"]}])


def _map(slide, spec, tpl, color):
    """中心概念 + 分支（放射图）。卡片宽度按分支数自适应，确保不超出页宽。"""
    center = spec.get("center", "")
    branches = spec.get("branches", [])
    cx, cy = W / 2, 2.6
    d = 1.3
    _badge(slide, cx, cy, d, color, "◆", sym_size=22)
    _text(slide, cx - d, cy - 0.35, d * 2, 0.7,
          [{"text": center, "size": 15, "bold": True, "color": "#FFFFFF", "align": PP_ALIGN.CENTER}],
          anchor=MSO_ANCHOR.MIDDLE)
    n = len(branches)
    if n == 0:
        return
    bh = 1.1
    gap = 0.3
    # 关键：卡片总宽（含间距）不得超过可用页宽（两侧各留 0.5 边距）
    bw = min(3.6, (W - 1.0 - gap * (n - 1)) / n)
    total_w = n * bw + (n - 1) * gap
    start_x = (W - total_w) / 2
    y = 4.4
    t_sz = 14 if bw >= 2.4 else 12
    d_sz = 12 if bw >= 2.4 else 10.5
    for i, b in enumerate(branches):
        bx = start_x + i * (bw + gap)
        bcol = tpl["palette"][i % len(tpl["palette"])] if tpl.get("palette") else color
        _rect(slide, bx, y, bw, bh, fill=tpl["surface"], line=bcol, line_w=1.0)
        _text(slide, bx + 0.15, y, bw - 0.3, bh * 0.45,
              [{"text": _safe(b.get("t", "")), "size": t_sz, "bold": True, "color": bcol}])
        _text(slide, bx + 0.15, y + bh * 0.42, bw - 0.3, bh * 0.55,
              [{"text": _safe(b.get("d", "")), "size": d_sz, "color": tpl["ink"]}], anchor=MSO_ANCHOR.TOP)
        # 放射连接线：从中心圆底部连到各卡片顶部中点
        cn = slide.shapes.add_connector(
            MSO_CONNECTOR.STRAIGHT,
            Inches(cx), Inches(cy + d / 2 - 0.05),
            Inches(bx + bw / 2), Inches(y))
        cn.line.color.rgb = _rgb(bcol)
        cn.line.width = Pt(2.25)
        # 连接线末端加小箭头（三角形）
        tri = slide.shapes.add_shape(
            MSO_SHAPE.ISOSCELES_TRIANGLE,
            Inches(bx + bw / 2 - 0.09), Inches(y - 0.18), Inches(0.18), Inches(0.18))
        tri.rotation = 180
        tri.fill.solid()
        tri.fill.fore_color.rgb = _rgb(bcol)
        tri.line.fill.background()
        tri.shadow.inherit = False


def _qa(slide, spec, tpl, color):
    area_t = 1.9
    q = _safe(spec.get("q", ""))
    a = _safe(spec.get("a", ""))
    _rect(slide, 0.7, area_t, W - 1.4, 1.6, fill=color, round=True)
    _badge(slide, 1.2, area_t + 0.8, 0.75, "#FFFFFF", "Q", sym_color=color, sym_size=22)
    _text(slide, 1.8, area_t + 0.15, W - 2.7, 1.3,
          [{"text": q, "size": 16, "bold": True, "color": "#FFFFFF"}], anchor=MSO_ANCHOR.MIDDLE)
    _rect(slide, 0.7, area_t + 1.9, W - 1.4, 2.6, fill=tpl["surface"], line=tpl["line"], line_w=1.0)
    _badge(slide, 1.2, area_t + 1.9 + 0.6, 0.75, tpl["accent"], "A", sym_color="#FFFFFF", sym_size=22)
    _text(slide, 1.8, area_t + 2.0, W - 2.7, 2.4,
          [{"text": a, "size": 15, "color": tpl["ink"]}], anchor=MSO_ANCHOR.TOP)


# ----------------------------------------------------------------------------
# 五星教学模式环形图示（中心枢纽 + 四象限色带 + 顺时针循环）
#   中心：聚焦问题（Problem-centered）
#   四相位（顺时针）：激活旧知 → 示证新知 → 应用新知 → 融会贯通
# ----------------------------------------------------------------------------
STAR5_PW, STAR5_PH, STAR5_GAP = 4.675, 2.70, 0.20
STAR5_BW, STAR5_BH = 2.72, 1.12
STAR5_OX, STAR5_OY_T, STAR5_OY_B = 0.40, 0.38, 0.42
STAR5_HUB_W, STAR5_HUB_H = 3.00, 1.45
STAR5_EN_H = 0.26          # 英文小字高度
STAR5_ARROW_T = 0.34       # 箭头粗细

STAR5_DEFAULT_PHASES = [
    {"name": "激活旧知", "en": "Activation", "desc": "唤起已有经验，搭建新知锚点"},
    {"name": "示证新知", "en": "Demonstration", "desc": "展示而非告知，匹配知识类型"},
    {"name": "应用新知", "en": "Application", "desc": "真实任务中练习并获得反馈"},
    {"name": "融会贯通", "en": "Integration", "desc": "公开分享、反思与迁移创新"},
]
STAR5_DEFAULT_CENTER = {"name": "聚焦问题", "en": "Problem-centered", "desc": "以完整真实任务贯穿全程"}


def _star5_cols(tpl):
    """环形图四象限配色：优先用模板 ring（四色易区分），否则退回 palette。"""
    pal = tpl.get("ring") or tpl.get("palette") or [tpl["primary"]] * 4
    while len(pal) < 4:
        pal = pal + pal
    return pal[:4]


def _star5_ring(slide, cx, cy, s, tpl, center=None, phases=None,
                show_en=None, show_desc=False, show_arrow=True):
    """绘制五星教学模式环形图。s 为整体缩放系数（s=1 约占满整页）。"""
    center = center or STAR5_DEFAULT_CENTER
    phases = phases or STAR5_DEFAULT_PHASES
    phases = list(phases)[:4]
    while len(phases) < 4:
        phases.append({"name": "", "en": "", "desc": ""})
    if show_en is None:
        show_en = s >= 0.80
    cols = _star5_cols(tpl)

    pw, ph, gap = STAR5_PW * s, STAR5_PH * s, STAR5_GAP * s
    bw, bh = STAR5_BW * s, STAR5_BH * s
    ox, oy_t, oy_b = STAR5_OX * s, STAR5_OY_T * s, STAR5_OY_B * s

    # 四个象限色带（顺时针：右上→右下→左下→左上 对应 激活→示证→应用→融会）
    panels = {
        "UR": (cx + gap / 2, cy - gap / 2 - ph, pw, ph),
        "LR": (cx + gap / 2, cy + gap / 2, pw, ph),
        "LL": (cx - gap / 2 - pw, cy + gap / 2, pw, ph),
        "UL": (cx - gap / 2 - pw, cy - gap / 2 - ph, pw, ph),
    }
    slots = [("UR", 0), ("LR", 1), ("LL", 2), ("UL", 3)]
    for si, (slot, pi) in enumerate(slots):
        l, t, w, h = panels[slot]
        col = cols[si % len(cols)]
        _rect(slide, l, t, w, h, fill=_mix(col, "#FFFFFF", 0.80), line=_mix(col, "#FFFFFF", 0.35),
              line_w=1.0 * s, round=True)
        # 相位方框
        bx = (cx + gap / 2 + pw / 2 + ox) if slot in ("UR", "LR") else (cx - gap / 2 - pw / 2 - ox)
        by = (cy + gap / 2 + ph / 2 + oy_b) if slot in ("LR", "LL") else (cy - gap / 2 - ph / 2 - oy_t)
        info = phases[pi] if pi < len(phases) else {}
        name = _safe(info.get("name", ""))
        if not name:
            continue
        # 相位卡片：序号徽章 + 中文名 + 一句话说明（说明并入卡片，避免溢出到页脚）
        _rect(slide, bx - bw / 2, by - bh / 2, bw, bh, fill=col, line=None, round=True)
        bd = 0.50 * s
        _badge(slide, bx - bw / 2 + 0.36 * s, by - bh / 2 + 0.33 * s, bd, "#FFFFFF", str(pi + 1),
               sym_color=col, sym_size=max(8, 13 * s))
        tx = bx - bw / 2 + 0.68 * s
        tw = bw - 0.80 * s
        _text(slide, tx, by - bh / 2 + 0.08 * s, tw, 0.42 * s,
              [{"text": name, "size": max(8.0, 15 * s), "bold": True, "color": "#FFFFFF"}],
              anchor=MSO_ANCHOR.MIDDLE, margin=0.03)
        if show_desc and info.get("desc"):
            _text(slide, bx - bw / 2 + 0.18 * s, by - bh / 2 + 0.54 * s, bw - 0.36 * s,
                  bh - 0.58 * s,
                  [{"text": _safe(info.get("desc", "")), "size": max(7.0, 9.5 * s),
                    "color": "#F2F6FA"}], anchor=MSO_ANCHOR.TOP, margin=0.02)
        if show_en:
            _text(slide, bx - bw / 2, by + bh / 2 + 0.02 * s, bw, STAR5_EN_H * s,
                  [{"text": _safe(info.get("en", "")), "size": max(7.0, 9.5 * s),
                    "color": _mix(col, "#000000", 0.25), "align": PP_ALIGN.CENTER}],
                  anchor=MSO_ANCHOR.TOP, margin=0.02)

    # 顺时针循环箭头
    if show_arrow:
        aw = STAR5_ARROW_T * s
        ac = tpl["accent"]
        ur_bx = cx + gap / 2 + pw / 2 + ox
        ur_by = cy - gap / 2 - ph / 2 - oy_t
        lr_by = cy + gap / 2 + ph / 2 + oy_b
        ul_bx = cx - gap / 2 - pw / 2 - ox
        v_top = ur_by + bh / 2 + (0.30 if show_en else 0.10) * s + STAR5_EN_H * s
        v_bot = lr_by - bh / 2 - 0.14 * s
        h_l = ul_bx + bw / 2 + 0.14 * s
        h_r = ur_bx - bw / 2 - 0.14 * s
        # 右上 → 右下（向下）
        _arrow(slide, ur_bx - aw / 2, v_top, aw, max(0.2, v_bot - v_top), ac, "down")
        # 右下 → 左下（向左）
        _arrow(slide, h_l, lr_by - aw / 2, max(0.2, h_r - h_l), aw, ac, "left")
        # 左下 → 左上（向上）
        _arrow(slide, ul_bx - aw / 2, v_top, aw, max(0.2, v_bot - v_top), ac, "up")
        # 左上 → 右上（向右）
        _arrow(slide, h_l, ur_by - aw / 2, max(0.2, h_r - h_l), aw, ac, "right")

    # 中心枢纽：聚焦问题
    hw, hh = STAR5_HUB_W * s, STAR5_HUB_H * s
    _rect(slide, cx - hw / 2, cy - hh / 2, hw, hh, fill=tpl["primary"], line="#FFFFFF",
          line_w=1.5 * s, round=True)
    _text(slide, cx - hw / 2, cy - hh / 2 + 0.10 * s, hw, 0.40 * s,
          [{"text": "★ " + _safe(center.get("name", "聚焦问题")), "size": max(9.0, 16 * s),
            "bold": True, "color": "#FFFFFF", "align": PP_ALIGN.CENTER}],
          anchor=MSO_ANCHOR.MIDDLE, margin=0.02)
    _text(slide, cx - hw / 2, cy - hh / 2 + 0.50 * s, hw, 0.28 * s,
          [{"text": _safe(center.get("en", "Problem-centered")), "size": max(7.0, 9.5 * s),
            "color": "#D8E4EE", "align": PP_ALIGN.CENTER}],
          anchor=MSO_ANCHOR.TOP, margin=0.02)
    cdesc = _safe(center.get("desc", ""))
    if cdesc:
        _text(slide, cx - hw / 2 + 0.12 * s, cy - hh / 2 + 0.80 * s, hw - 0.24 * s, 0.58 * s,
              [{"text": cdesc, "size": max(7.0, 9.5 * s), "color": "#C9D9E6",
                "align": PP_ALIGN.CENTER}], anchor=MSO_ANCHOR.TOP, margin=0.02)


def draw_star5(slide, spec, tpl, course, page, total):
    """整页五星教学模式环形图示。"""
    _header(slide, spec.get("title", "五星教学模式（首要教学原理）"), None, tpl)
    _star5_ring(slide, W / 2, 4.15, 1.0, tpl,
                center=spec.get("center") or None,
                phases=spec.get("phases") or None,
                show_en=True, show_desc=True, show_arrow=True)
    _footer(slide, course, page, total, tpl)


# ----------------------------------------------------------------------------
# 说课 / 封面 / 课次封面
# ----------------------------------------------------------------------------
def _cover(slide, course, content, designer, tpl):
    _rect(slide, 0, 0, W, H, fill=tpl["primary"], round=False)
    _rect(slide, 0, 2.5, W, 0.08, fill=tpl["accent"], round=False)
    _text(slide, 1.0, 1.4, W - 2.0, 1.0,
          [{"text": "五星教学模式（首要教学原理）", "size": 30, "bold": True, "color": "#FFFFFF"}])
    _text(slide, 1.0, 2.7, W - 2.0, 1.2,
          [{"text": course, "size": 36, "bold": True, "color": tpl["accent"]}])
    _text(slide, 1.0, 4.0, W - 2.0, 0.8,
          [{"text": "说课课件  ·  " + _safe(content), "size": 18, "color": "#E8E8E8"}])
    if designer:
        _text(slide, 1.0, 6.4, W - 2.0, 0.6,
              [{"text": "设计者：" + designer, "size": 14, "color": "#CCCCCC"}])


def _lecture_section(slide, idx, title, points, tpl, course, page, total):
    _header(slide, "说课 · " + title, None, tpl)
    color = tpl["palette"][idx % len(tpl["palette"])] if tpl.get("palette") else tpl["primary"]
    _badge(slide, 1.4, 3.0, 1.2, color, str(idx + 1), sym_size=34)
    items = [_safe(p) for p in points if str(p).strip()]
    body = []
    for it in items:
        body.append({"text": "▸ " + it, "size": 15, "color": tpl["ink"], "space_after": 8})
    _text(slide, 2.4, 1.9, W - 3.0, 4.6, body, anchor=MSO_ANCHOR.TOP)
    _footer(slide, course, page, total, tpl)


# ----------------------------------------------------------------------------
# 主渲染
# ----------------------------------------------------------------------------
DEFAULT_TPL = {"id": "warm_orange", "name": "暖橙活力", "primary": "#C75B12", "accent": "#F39C12",
               "bg": "#FFFFFF", "surface": "#FFF1E0", "muted": "#8A6B52", "line": "#E4C9A8",
               "ink": "#3A2A1E",
               "palette": ["#C75B12", "#E07B1A", "#F39C12", "#7BA23F", "#3E7CB1"]}


def _load_tpl(templates, tid):
    for t in templates:
        if t.get("id") == tid:
            tpl = dict(DEFAULT_TPL)
            tpl.update({k: t[k] for k in ("primary", "accent", "bg", "surface", "muted", "line", "ink") if k in t})
            if "palette" in t:
                tpl["palette"] = t["palette"]
            else:
                tpl["palette"] = [tpl["primary"], tpl["accent"], "#7BA23F", "#3E7CB1", "#9B5EA0"]
            if "ring" in t:
                tpl["ring"] = t["ring"]
            return tpl
    return dict(DEFAULT_TPL)


def render(plan, out_path, templates, template_id, footer_text, mode):
    tpl = _load_tpl(templates, template_id)
    course = _safe(plan.get("course", "")) or "课程"
    content = _safe(plan.get("content", ""))
    designer = _safe(plan.get("designer", ""))

    prs = Presentation()
    prs.slide_width = Inches(W)
    prs.slide_height = Inches(H)

    slides_plan = []  # (fn, args) 先收集再统一加页脚页码

    # ===== 说课 =====
    if mode in ("all", "lecture"):
        slides_plan.append(("cover", (course, content, designer, tpl)))
        # 五星教学模式总览环形图（中心枢纽 + 四相位顺时针循环）
        slides_plan.append(("star5", (tpl, course)))
        lec = plan.get("lecture")
        if lec and lec.get("sections"):
            sections = lec["sections"]
        else:
            sections = [
                {"title": "一、教学内容简介与学情分析", "points": [_safe(plan.get("content", ""))] + plan.get("audience_note", [])},
                {"title": "二、学生学习目标", "points": plan.get("objectives", [])},
                {"title": "三、教学活动设计（五个方面）", "points": ["聚焦问题 → 激活旧知 → 示证新知 → 应用新知 → 融会贯通"]},
                {"title": "四、学生学习效果评价", "points": [_rubric_summary(plan.get("evaluation_rubric", []))]},
                {"title": "五、教学设计反思与改进", "points": [_safe(plan.get("improvement", ""))]},
            ]
        for i, sec in enumerate(sections):
            slides_plan.append(("lecture", (i, sec.get("title", ""), sec.get("points", []), tpl, course)))

    # ===== 讲课 =====
    if mode in ("all", "teach"):
        classes = plan.get("classes", [])
        if not classes:  # 兜底：用旧字段拼一页
            classes = [{"title": _safe(plan.get("content", "讲课")), "goals": plan.get("objectives", []),
                        "phases": []}]
        for ci, cls in enumerate(classes, 1):
            slides_plan.append(("class_cover", (ci, cls, designer, tpl)))
            slides_plan.append(("class_goals", (ci, cls, tpl, course)))
            for ph in cls.get("phases", []):
                slides_plan.append(("phase_div", (ph, tpl, course)))
                for sp in ph.get("slides", []):
                    slides_plan.append(("spec", (sp, tpl, course)))

    # ===== footer 仅最末页（使用说明）=====
    if footer_text:
        slides_plan.append(("footer_only", (footer_text, tpl, course)))

    total = len(slides_plan)

    def build_one(fn, args, page):
        s = _blank(prs)
        if fn == "cover":
            _cover(s, *args)
        elif fn == "lecture":
            i, title, points, t, c = args
            _lecture_section(s, i, title, points, t, c, page, total)
        elif fn == "class_cover":
            ci, cls, des, t = args
            _class_cover(s, ci, cls, des, t)
        elif fn == "class_goals":
            ci, cls, t, c = args
            _class_goals(s, ci, cls, t, c, page, total)
        elif fn == "phase_div":
            ph, t, c = args
            _phase_div(s, ph, t, c, page, total)
        elif fn == "spec":
            sp, t, c = args
            draw_slide(s, sp, t, c, page, total)
        elif fn == "star5":
            t, c = args
            sp = {"kind": "star5",
                  "title": "五星教学模式（首要教学原理）",
                  "center": {"name": "聚焦问题", "en": "Problem-centered",
                             "desc": "以完整真实任务贯穿全程，四环节围绕问题循环推进"},
                  "phases": STAR5_DEFAULT_PHASES,
                  "note": "顺时针推进：激活旧知 → 示证新知 → 应用新知 → 融会贯通；聚焦问题居中贯穿始终。"}
            draw_star5(s, sp, t, c, page, total)
        elif fn == "footer_only":
            ft, t, c = args
            _footer_note_slide(s, ft, t, c, page, total)

    for idx, (fn, args) in enumerate(slides_plan, 1):
        build_one(fn, args, idx)

    prs.save(out_path)
    return out_path


def _rubric_summary(rubric):
    """量规摘要：同时兼容「指标列表」与「levels/rows 结构」两种写法。"""
    if not rubric:
        return "（请在 plan.json 的 evaluation_rubric 补充量规）"
    if isinstance(rubric, dict):
        rows = rubric.get("rows") or []
    else:
        rows = rubric
    names = []
    for r in rows:
        if isinstance(r, dict):
            n = _safe(r.get("indicator", "")) or _safe(r.get("dimension", ""))
            if n:
                names.append(n)
    if not names:
        return "（请在 plan.json 的 evaluation_rubric 补充量规）"
    return "；".join(names)


def _class_cover(slide, ci, cls, designer, tpl):
    _rect(slide, 0, 0, W, H, fill=tpl["surface"], round=False)
    _rect(slide, 0, 2.6, W, 0.1, fill=tpl["accent"], round=False)
    _badge(slide, W / 2, 1.7, 1.4, tpl["primary"], str(ci), sym_size=44)
    _text(slide, 1.0, 3.0, W - 2.0, 1.0,
          [{"text": f"第 {ci} 次课", "size": 24, "bold": True, "color": tpl["muted"], "align": PP_ALIGN.CENTER}])
    _text(slide, 1.0, 3.8, W - 2.0, 1.2,
          [{"text": _safe(cls.get("title", "")), "size": 30, "bold": True, "color": tpl["primary"], "align": PP_ALIGN.CENTER}])
    if designer:
        _text(slide, 1.0, 6.4, W - 2.0, 0.6,
              [{"text": "设计者：" + designer, "size": 14, "color": tpl["muted"], "align": PP_ALIGN.CENTER}])


def _class_goals(slide, ci, cls, tpl, course, page, total):
    _header(slide, f"第 {ci} 次课 · 学习目标与路线图", cls.get("title", ""), tpl)
    goals = cls.get("goals", [])
    if goals:
        _text(slide, 0.7, 1.7, 5.6, 0.5, [{"text": "本课目标", "size": 16, "bold": True, "color": tpl["primary"]}])
        body = [{"text": "✓ " + _safe(g), "size": 14, "color": tpl["ink"], "space_after": 8} for g in goals]
        _text(slide, 0.7, 2.2, 5.6, 4.0, body, anchor=MSO_ANCHOR.TOP)
    # 路线图：五星教学模式环形图（与全篇图示一致）
    phases = cls.get("phases", [])
    names = [p.get("name") for p in phases]
    ring_phases = None
    if len(names) >= 4:
        en_map = {"聚焦问题": "Problem-centered", "激活旧知": "Activation",
                  "示证新知": "Demonstration", "应用新知": "Application",
                  "融会贯通": "Integration"}
        tail = [n for n in names if n and n != "聚焦问题"][:4]
        if len(tail) == 4:
            ring_phases = [{"name": n, "en": en_map.get(n, ""), "desc": ""} for n in tail]
    _text(slide, 6.7, 1.7, W - 7.4, 0.5,
          [{"text": "五星教学路线图", "size": 16, "bold": True, "color": tpl["primary"]}])
    _star5_ring(slide, 9.70, 4.20, 0.69, tpl,
                center={"name": "聚焦问题", "en": "Problem-centered", "desc": ""},
                phases=ring_phases, show_en=True, show_desc=False, show_arrow=True)
    _footer(slide, course, page, total, tpl)


def _phase_div(slide, ph, tpl, course, page, total):
    color = ph.get("color") or tpl["primary"]
    _rect(slide, 0, 0, W, H, fill=color, round=False)
    _badge(slide, W / 2, 2.6, 1.8, "#FFFFFF", str(ph.get("number", "")), sym_color=color, sym_size=54)
    _text(slide, 1.0, 3.8, W - 2.0, 1.0,
          [{"text": _safe(ph.get("name", "")), "size": 34, "bold": True, "color": "#FFFFFF", "align": PP_ALIGN.CENTER}])
    intro = _safe(ph.get("intro", ""))
    if intro:
        _text(slide, 1.5, 5.0, W - 3.0, 1.2,
              [{"text": intro, "size": 16, "color": "#F0F0F0", "align": PP_ALIGN.CENTER}])
    _footer(slide, course, page, total, tpl)


def _footer_note_slide(slide, footer_text, tpl, course, page, total):
    _header(slide, "使用说明", None, tpl)
    lines = []
    for ln in _safe(footer_text).split("\n"):
        ln = ln.strip()
        if ln:
            lines.append({"text": ln, "size": 12, "color": tpl["ink"], "space_after": 5})
    _text(slide, 0.7, 1.4, W - 1.4, 5.3, lines, anchor=MSO_ANCHOR.TOP)
    _footer(slide, course, page, total, tpl)


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="渲染视觉化 PPT 课件")
    ap.add_argument("--plan", required=True)
    ap.add_argument("--out", default="课件.pptx")
    ap.add_argument("--dir", default="", help="--out 为相对路径时的基准目录；不传则用当前目录")
    ap.add_argument("--templates", default="data/ppt-templates.json")
    ap.add_argument("--template", default="warm_orange")
    ap.add_argument("--footer", default="",
                    help="自备页脚文本路径；不传则自动取 references 下的 footer-note 资料")
    ap.add_argument("--mode", default="all", choices=["all", "lecture", "teach"])
    args = ap.parse_args()

    try:
        with open(args.plan, "r", encoding="utf-8") as f:
            plan = json.load(f)
        templates = []
        if os.path.exists(args.templates):
            with open(args.templates, "r", encoding="utf-8") as f:
                templates = json.load(f).get("ppt_templates", [])
        footer_text = load_footer_text(args.footer)
        out_path = resolve_out(args.out, args.dir)
        path = render(plan, out_path, templates, args.template, footer_text, args.mode)
        # 统计页数
        from pptx import Presentation as P
        cnt = len(P(path).slides)
        print(json.dumps({"ok": True, "pptx": path, "slides": cnt}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"ok": False, "hint": f"生成 PPT 出错：{e}。请改用 AI 工具原生 PPT 生成能力，或检查 plan.json 的 classes 结构是否完整。"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
