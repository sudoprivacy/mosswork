#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_plan.py —— 将收集到的信息装配为结构化方案 JSON（深度思考草稿）

【用途】
流程六中，AI 把用户提供的信息、联网检索到的资料、布卢姆目标、五个方面设计装配成一份
结构化草稿 JSON，供渲染脚本（render_docx.py / render_pptx.py）或续跑使用。

【用法】
    python build_plan.py --inputs inputs.json [--web searched.json] --out plan.json
    python build_plan.py --out plan.json --dir <输出基准目录>
    python build_plan.py --out plan.json        # 仅输出一份空模板，便于 AI 逐项填写

【--web 传入的文件结构】由 AI 把自带联网检索能力查到的资料整理成下述 JSON 后传入（可选）：
    { "sources": [ {"title": "标题", "text": "正文"} ] }

脚本自身不联网、不创建进程、不安装任何组件；只读你传入的文件、只写你指定的输出路径。

【inputs.json 字段（均为可选，缺失则由 AI 在后续填写）】
{
  "course": "课程名称",
  "audience": "中小学/大学/培训机构/企业培训",
  "content": "授课内容",
  "designer": "设计者姓名",
  "lessons": 2,
  "deliverable": "only_doc / doc_lecture / doc_lecture_teach",
  "template": "warm_orange",
  "objectives": [ "学生能够……（记忆）" ],
  "knowledge": [ {"name":"知识点","type":"事实|概念|程序|原理|过程","detail":"..."} ],
  "focus_problems": [ "聚焦问题例子1", "..." ],
  "activate": [ "激活旧知方案1", "..." ],
  "demonstrate_general": [ {"point":"一般信息点","examples":[...],"quiz":[{"q":"","a":""}]} ],
  "demonstrate_specific": [ "具体描述（示范过程）1", "..." ],
  "apply": {"answer_arrangement":"...", "practice_steps": {"识别实例":"","执行实例":"","预测结果":"","指出缺失缺陷":""}, "scaffold":"..."},
  "integrate": [ "融会贯通活动1", "..." ],
  "evaluation_rubric": {
    "levels": [ {"name":"优秀","score":"90-100"}, {"name":"良好","score":"80-89"},
                {"name":"中等","score":"70-79"}, {"name":"合格","score":"60-69"},
                {"name":"待改进","score":"60 以下"} ],
    "rows": [ {"indicator":"评价指标（由任务分析确定，须具体明确）","weight":20,
               "descs":["优秀档：详细且可量化的评分说明","良好档：…","中等档：…","合格档：…","待改进档：…"]} ]
  },
  "improvement": "改进建议",
  "lecture": {"intro":"...", "sections":[{"title":"一、教学内容简介与学情分析","points":["..."]}]},
  "classes": [
    {"title":"第1次课 标题","goals":["目标1","目标2"],
     "phases":[
       {"name":"聚焦问题","number":1,"intro":"一句话引入",
        "slides":[
          {"kind":"problem","title":"情境问题","sub":"副标题","problems":["问题1","问题2"]},
          {"kind":"cards","title":"核心概念","cards":[{"title":"","points":["",""]}]},
          {"kind":"flow","title":"流程","steps":[{"t":"步骤","d":"说明"}]},
          {"kind":"example","title":"案例","scenario":"","points":["",""]},
          {"kind":"activity","title":"课堂活动","task":"","steps":["",""]},
          {"kind":"bullets","title":"要点","items":["",""]},
          {"kind":"compare","title":"对比","columns":[{"h":"列名","items":["",""]}]},
          {"kind":"chart","title":"图表","categories":["A","B"],"values":[3,5],"caption":"说明"},
          {"kind":"principle","title":"原则","text":"","note":""},
          {"kind":"map","title":"结构图","center":"中心","branches":[{"t":"","d":""}]},
          {"kind":"qa","title":"问答","q":"","a":""}
        ]},
       {"name":"激活旧知","number":2,"slides":[...]},
       {"name":"示证新知","number":3,"slides":[...]},
       {"name":"应用新知","number":4,"slides":[...]},
       {"name":"融会贯通","number":5,"slides":[...]}
     ]}
  ],
  "footer_note": "（由 references 的 footer-note 资料自动拼接，无需填写）"
}

【幻灯片 kind 一览（渲染脚本据此绘制视觉化页面）】
  problem  情境/问题导入（高亮框 + 分析要点）
  bullets  要点卡片网格（1列或2列）
  cards    概念卡片网格（标题+要点）
  flow     横向箭头流程（3-5步）
  steps    纵向编号步骤
  compare  多列对比（2-3列）
  example  案例框 + 分析要点
  activity 课堂活动任务 + 清单
  principle 原则/金句高亮框
  chart    柱状图（categories + values）
  map      中心放射结构图
  qa       问答两框
  star5    五星教学模式环形图示（中心聚焦问题 + 四相位顺时针循环，脚本已自动插入，无需手写）

【evaluation_rubric 编写要求（强制）】
  评分量规必须是「评价指标 + 权重」× 五级评分的矩阵，且：
  · 行（rows）：先对本次学习任务做任务分析，再提炼 4-6 个具体、明确、可观测的评价指标，
    每个指标赋予权重，全部权重之和为 100。
  · 列（levels）：固定为 优秀(90-100) / 良好(80-89) / 中等(70-79) / 合格(60-69) / 待改进(60以下)。
  · 单元格（descs）：每一格都要给出详细且可量化的评分说明——含频次、比例、数量、正确率、
    字数、等级等可核对标准，避免「较好」「不错」这类模糊表述。
  · 计分方式：总分 = Σ（各指标得分 × 权重）÷ 100。

【classes 编写要求（强制）】
  每次课的 slides 数量不少于 20 页，覆盖五个方面的完整闭环；
  页面以图示为主（flow/cards/compare/chart/map 等），不要整页纯文字。
"""
import argparse
import json
import os


def resolve_out(out_path, base_dir=""):
    """把输出路径解析为绝对路径：相对路径按基准目录（默认当前目录）展开。"""
    if not os.path.isabs(out_path):
        base = os.path.abspath(base_dir) if base_dir else os.getcwd()
        out_path = os.path.join(base, os.path.basename(out_path))
    out_path = os.path.abspath(out_path)
    d = os.path.dirname(out_path)
    if d and not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    return out_path


def empty_template():
    return {
        "course": "",
        "audience": "",
        "content": "",
        "designer": "",
        "lessons": 1,
        "deliverable": "doc_lecture_teach",
        "template": "warm_orange",
        "knowledge_categories": ["事实", "概念", "程序", "原理", "过程"],
        "objectives": [],
        "knowledge": [],
        "focus_problems": [],
        "activate": [],
        "demonstrate_general": [],
        "demonstrate_specific": [],
        "apply": {"answer_arrangement": "", "practice_steps": {}, "scaffold": ""},
        "integrate": [],
        "evaluation_rubric": [],
        "improvement": "",
        "lecture": {"intro": "", "sections": []},
        "classes": [],
    }


def main():
    ap = argparse.ArgumentParser(description="装配结构化方案 JSON")
    ap.add_argument("--inputs", dest="inputs", default="", help="用户输入 JSON 路径")
    ap.add_argument("--web", default="", help="AI 联网检索结果整理成的 JSON 路径（可选）")
    ap.add_argument("--out", default="plan.json", help="输出 JSON 路径")
    ap.add_argument("--dir", default="", help="--out 为相对路径时的基准目录；不传则用当前目录")
    args = ap.parse_args()

    plan = empty_template()
    if args.inputs:
        try:
            with open(args.inputs, "r", encoding="utf-8") as f:
                user = json.load(f)
            plan.update({k: v for k, v in user.items() if v not in (None, "", [], {})})
        except Exception as e:
            print(json.dumps({"ok": False, "hint": f"读取输入失败：{e}。请检查 JSON 格式。"}, ensure_ascii=False))
            return

    if args.web:
        try:
            with open(args.web, "r", encoding="utf-8") as f:
                web = json.load(f)
            snippets = []
            for s in web.get("sources", []):
                if s.get("text"):
                    snippets.append(f"【{s.get('title','')}】\n{s['text'][:1500]}")
            if snippets:
                plan["_web_context"] = "\n\n".join(snippets)
        except Exception:
            pass  # 检索结果缺失不阻断主流程

    out_path = resolve_out(args.out, args.dir)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)
    print(json.dumps({"ok": True, "plan_path": out_path, "filled_fields": [k for k, v in plan.items() if v not in (None, "", [], {})]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
