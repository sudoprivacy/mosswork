# Training Course Designer · 付费版

- 按次 ¥9.90 / 买断 ¥150（单设备）
- 微信扫码：`node scripts/pay_client.mjs --probe`
- 服务端生成 14 份课程包：`node scripts/generate.mjs --input brief.json --out training-course-package.zip`
- 本包不含本地生成器/模板；无授权无法获取文件。
