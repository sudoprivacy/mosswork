#!/usr/bin/env node
/** 兼容入口：当前 training-pay 只开通微信 Native；A2M 未配置时明确提示。 */
import { requireGrant } from './guard.mjs';
if (process.argv.includes('--check')) {
  const g = requireGrant();
  console.log(`LICENSE_OK=1 kind=${g.kind}`);
  process.exit(0);
}
console.error('当前 training-pay 生产通道为微信 Native，尚未配置支付宝 A2M。');
console.error('请使用：node scripts/pay_client.mjs --probe');
process.exit(1);
