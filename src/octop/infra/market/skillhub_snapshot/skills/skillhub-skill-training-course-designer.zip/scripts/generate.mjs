#!/usr/bin/env node
/** 上传 brief，服务端生成交付包，返回 zip。 */
import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { requireGrant, SERVICE_ID } from './guard.mjs';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const PRICING = JSON.parse(readFileSync(join(ROOT, 'config', 'pricing.json'), 'utf8'));
const BASE = PRICING.backend.base_url.replace(/\/$/, '');
const argv = process.argv.slice(2);
const val = (f) => { const i = argv.indexOf(f); return i >= 0 ? argv[i + 1] : undefined; };
const input = val('--input') || 'brief.json';
const out = val('--out') || 'training-package.zip';
const g = requireGrant();
const body = { service_id: SERVICE_ID, token: g.token, device: g.device, inputs: JSON.parse(readFileSync(resolve(input), 'utf8')) };
const r = await fetch(BASE + '/api/generate', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
if (r.status !== 200) { console.error('✗ 生成失败', r.status, await r.text()); process.exit(1); }
const buf = Buffer.from(await r.arrayBuffer());
writeFileSync(out, buf);
console.log(`✓ 已生成 ${out}`);
console.log(`  delivery: ${r.headers.get('x-delivery-id')}`);
console.log(`  sha256: ${r.headers.get('x-sha256')}`);
