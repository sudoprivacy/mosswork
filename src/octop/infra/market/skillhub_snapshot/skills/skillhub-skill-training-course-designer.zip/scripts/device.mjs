#!/usr/bin/env node
/**
 * device.mjs — 稳定设备指纹（只本机计算，不上传原始指纹）
 *
 * 用途：把买断许可证 / 按次授权绑定到具体机器，防止把凭证复制给朋友直接用。
 * 只把 sha256 摘要发给服务端（见 guard.mjs / pay_client.mjs），服务器不接触原始硬件信息。
 *
 * 残余风险：设备指纹在客户端计算，改代码可以伪造；它挡的是「复制一份 license.json」。
 */

import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, existsSync } from 'node:fs';
import { hostname, userInfo, platform } from 'node:os';

function macPlatformUUID() {
  try {
    const out = execFileSync('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'], {
      encoding: 'utf8',
      timeout: 3000,
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    const m = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/);
    return m ? m[1] : '';
  } catch {
    return '';
  }
}

function linuxMachineId() {
  try {
    return readFileSync('/etc/machine-id', 'utf8').trim();
  } catch {
    try {
      return readFileSync('/var/lib/dbus/machine-id', 'utf8').trim();
    } catch {
      return '';
    }
  }
}

function windowsMachineGuid() {
  try {
    const out = execFileSync(
      'reg',
      ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
      { encoding: 'utf8', timeout: 3000, stdio: ['ignore', 'pipe', 'ignore'] }
    );
    const m = out.match(/MachineGuid\s+REG_SZ\s+([\w-]+)/i);
    return m ? m[1] : '';
  } catch {
    return '';
  }
}

/** 计算稳定的设备标识；优先硬件 UUID，退化到 hostname+user+platform */
export function deviceId() {
  let hw = '';
  const p = platform();
  if (p === 'darwin') hw = macPlatformUUID();
  else if (p === 'linux') hw = linuxMachineId();
  else if (p === 'win32') hw = windowsMachineGuid();

  const basis = hw ? `${p}|${hw}` : `${p}|${hostname()}|${userInfo().username}`;
  return 'dev_' + createHash('sha256').update(basis).digest('hex').slice(0, 32);
}

export function deviceInfo() {
  const p = platform();
  return { id: deviceId(), platform: p, hostname: hostname() };
}
