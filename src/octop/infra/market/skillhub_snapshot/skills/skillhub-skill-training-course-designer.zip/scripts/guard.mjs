#!/usr/bin/env node
/** 价值动作前置授权检查：没有有效 TSLIC1/TSENT1 就退出。 */
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { verifyToken, loadToken, tokenPath } from '../server/license.mjs';
import { deviceId } from './device.mjs';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const PRICING = JSON.parse(readFileSync(join(ROOT, 'config', 'pricing.json'), 'utf8'));
export const SERVICE_ID = PRICING.service_id;
export const RESOURCE_ID = PRICING.resource_id;

export function requireGrant() {
  const device = deviceId();
  const saved = loadToken(SERVICE_ID);
  const token = saved?.token;
  if (!token) {
    console.error('✗ 未找到有效付费授权');
    console.error('  先运行：node scripts/pay_client.mjs --probe');
    console.error('  扫码付款后：node scripts/pay_client.mjs --poll --order <订单号>');
    process.exit(1);
  }
  const v = verifyToken(token, { serviceId: SERVICE_ID, resourceId: RESOURCE_ID, device });
  if (!v.valid) {
    console.error(`✗ 授权无效：${v.reason}`);
    console.error('  请重新付款/换绑设备，或联系客服。');
    process.exit(1);
  }
  return { token, device, payload: v.payload, kind: v.kind, path: tokenPath(SERVICE_ID) };
}

if (process.argv[1] && process.argv[1].endsWith('guard.mjs')) {
  const g = requireGrant();
  console.log(`✓ 授权有效 (${g.kind})  ${g.payload.pd || SERVICE_ID}`);
  console.log(`TOKEN_FILE=${g.path}`);
}
