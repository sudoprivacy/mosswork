#!/usr/bin/env node
/**
 * training pay client — 微信 Native 扫码 + 轮询到账 + 领取签名授权
 * 用法：
 *   node scripts/pay_client.mjs --probe [--tier buyout]
 *   node scripts/pay_client.mjs --poll --order TT_...
 *   node scripts/pay_client.mjs --status --order TT_...
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';
import { deviceId } from './device.mjs';
import { saveToken, tokenPath } from '../server/license.mjs';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const PRICING = JSON.parse(readFileSync(join(ROOT, 'config', 'pricing.json'), 'utf8'));
const BASE = PRICING.backend.base_url.replace(/\/$/, '');
const SERVICE = PRICING.service_id;
const DEVICE = deviceId();
const CACHE = join(homedir(), '.talent-training');
const ORDER_FILE = join(CACHE, `${SERVICE}-order.json`);
const C = { b: '\x1b[1m', d: '\x1b[2m', g: '\x1b[32m', y: '\x1b[33m', r: '\x1b[31m', x: '\x1b[0m' };
const argv = process.argv.slice(2);
const has = (f) => argv.includes(f);
const val = (f) => { const i = argv.indexOf(f); return i >= 0 ? argv[i + 1] : undefined; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function post(path, body) {
  const r = await fetch(BASE + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}) });
  return { status: r.status, data: await r.json().catch(() => ({})) };
}
async function get(path) {
  const r = await fetch(BASE + path); return { status: r.status, data: await r.json().catch(() => ({})) };
}
function saveOrder(o) { mkdirSync(CACHE, { recursive: true }); writeFileSync(ORDER_FILE, JSON.stringify(o, null, 2)); }

async function main() {
  if (has('--probe')) {
    const tier = val('--tier') === 'buyout' ? 'buyout' : 'per_use';
    const r = await post('/api/precreate', { service_id: SERVICE, tier, device: DEVICE });
    if (r.status !== 402) { console.error('✗ 建单失败', r.status, r.data); process.exit(1); }
    const b = r.data;
    saveOrder({ order: b.out_trade_no, tier, device: DEVICE });
    console.log(`\n${C.b}培训付费服务${C.x}`);
    console.log(`  商品    ${b.product}`);
    console.log(`  金额    ${C.b}¥${b.amount}${C.x} / ${tier === 'buyout' ? '买断' : '次'}`);
    console.log(`  订单号  ${b.out_trade_no}`);
    console.log(`  支付通道  wechat（微信扫码）`);
    console.log(`\n  ${C.b}扫码支付${C.x}  ${BASE}${b.qr_url}`);
    console.log(`  ${C.d}code_url: ${b.code_url}${C.x}`);
    console.log(`\n  付款后：node scripts/pay_client.mjs --poll --order ${b.out_trade_no}`);
    console.log(`ORDER=${b.out_trade_no}`);
    console.log(`PAY_QR_URL=${BASE}${b.qr_url}`);
    process.exit(2);
  }

  if (has('--poll')) {
    const order = val('--order') || (existsSync(ORDER_FILE) ? JSON.parse(readFileSync(ORDER_FILE, 'utf8')).order : '');
    if (!order) { console.error('缺少 --order'); process.exit(1); }
    console.log(`等待支付 ${order} ...`);
    for (let i = 0; i < 300; i++) {
      const r = await get(`/api/poll/${order}`);
      if (r.status === 200 && r.data.status === 'paid') {
        const e = await post('/api/entitlement', { out_trade_no: order, device: DEVICE });
        if (e.status !== 200) { console.error('✗ 领取授权失败', e.status, e.data); process.exit(1); }
        const p = saveToken(SERVICE, { token: e.data.token, order, device: DEVICE, tier: e.data.tier, saved_at: new Date().toISOString() });
        console.log(`${C.g}✓ 支付到账，授权已保存${C.x}`);
        console.log(`  token: ${p}`);
        console.log(`  tier: ${e.data.tier}`);
        process.exit(0);
      }
      await sleep(3000);
      if (i % 10 === 9) console.log('  仍在等待支付…');
    }
    console.error('✗ 等待超时；稍后可用 --poll 重试'); process.exit(2);
  }

  if (has('--status')) {
    const order = val('--order'); if (!order) { console.error('缺少 --order'); process.exit(1); }
    const r = await get(`/api/orders/${order}`); console.log(JSON.stringify(r.data, null, 2)); process.exit(r.data.status === 'pending' ? 2 : 0);
  }

  console.error('用法: --probe [--tier buyout] | --poll --order <id> | --status --order <id>');
  process.exit(1);
}
main().catch((e) => { console.error(e); process.exit(1); });
