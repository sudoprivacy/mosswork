#!/usr/bin/env node
/** 客户端：只做验签，不做授权决策。公钥只认随包 config/license_pub.json。 */
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { createPublicKey, verify as edVerify } from 'node:crypto';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const PUB = join(ROOT, 'config', 'license_pub.json');
export const TOKEN_DIR = process.env.TALENT_TRAINING_HOME || join(homedir(), '.talent-training');

export function publicKey() {
  if (!existsSync(PUB)) return null;
  const j = JSON.parse(readFileSync(PUB, 'utf8'));
  if (!j.key) return null;
  return createPublicKey({ key: Buffer.from(j.key, 'base64'), format: 'der', type: 'spki' });
}

export function verifyToken(token, { serviceId, resourceId, device } = {}) {
  const parts = String(token || '').trim().split('.');
  if (parts.length !== 3) return { valid: false, reason: 'malformed_token' };
  const [prefix, body, sig] = parts;
  if (!['TSLIC1', 'TSENT1'].includes(prefix)) return { valid: false, reason: 'bad_prefix' };
  const key = publicKey();
  if (!key) return { valid: false, reason: 'license_public_key_missing' };
  let ok = false;
  try { ok = edVerify(null, Buffer.from(body, 'base64url'), key, Buffer.from(sig, 'base64url')); } catch { return { valid: false, reason: 'malformed_token' }; }
  if (!ok) return { valid: false, reason: 'bad_signature' };
  let p; try { p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); } catch { return { valid: false, reason: 'malformed_payload' }; }
  if (p.v !== 1) return { valid: false, reason: 'unsupported_version' };
  if (serviceId && p.pd && p.pd !== serviceId) return { valid: false, reason: 'service_mismatch' };
  if (resourceId && p.rs && p.rs !== resourceId) return { valid: false, reason: 'resource_mismatch' };
  if (device && p.dv && p.dv !== device) return { valid: false, reason: 'device_mismatch' };
  if (prefix === 'TSENT1') {
    if (p.t !== 'entitlement') return { valid: false, reason: 'not_entitlement' };
    if (!p.exp || Number(p.exp) < Date.now()) return { valid: false, reason: 'entitlement_expired' };
  } else {
    if (p.t !== 'buyout') return { valid: false, reason: 'not_license' };
    if (!p.dv) return { valid: false, reason: 'license_not_device_bound' };
  }
  return { valid: true, kind: prefix === 'TSLIC1' ? 'license' : 'entitlement', payload: p };
}

export function tokenPath(serviceId) { return join(TOKEN_DIR, `${serviceId}.json`); }
export function loadToken(serviceId) {
  const p = tokenPath(serviceId);
  if (!existsSync(p)) return null;
  try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; }
}
export function saveToken(serviceId, data) {
  mkdirSync(TOKEN_DIR, { recursive: true });
  const p = tokenPath(serviceId);
  writeFileSync(p, JSON.stringify(data, null, 2), { mode: 0o600 });
  return p;
}
