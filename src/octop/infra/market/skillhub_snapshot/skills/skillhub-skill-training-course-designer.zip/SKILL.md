---
name: skillhub-skill-training-course-designer
description: "Professional training course design for corporate L&D with ONE-CLICK generation of complete training packages including course materials, marketing copy, and assessments. Use when designing training courses, workshops, or learning programs. 本技能为付费技能：按次 ¥9.90，服务端生成 14 份课程包文件；买断 ¥150。"
---

# Training Course Designer · 付费版（P3 服务端生成）

> **付费技能 · 执行前必读**
> - 创作者：张号东 · 深圳市班客人力资源服务有限公司
> - 按次 **¥9.90 / 次**（一套 14 份课程包）；买断 **¥150**（不限次，单设备）
> - 收款：微信 Native 扫码，付完自动到账
> - 退款：未交付全额退；已交付不退（内容错误 7 日内补正一次）
> - **服务端生成**：本包不包含本地生成器和模板，14 份交付物由 `training-pay` 服务端生成；没有授权无法获取文件。

## 强制流程（不得跳过）

### 0. 付款并领取授权
```bash
node scripts/pay_client.mjs --probe
# 把打印出的 PAY_QR_URL 二维码给用户扫；付款后：
node scripts/pay_client.mjs --poll --order <订单号>
```
买断：
```bash
node scripts/pay_client.mjs --probe --tier buyout
node scripts/pay_client.mjs --poll --order <订单号>
```
授权保存在 `~/.talent-training/training_course_v1.json`，绑定当前设备。

### 1. 收集 brief（5 类输入）
至少收集；缺省值可自动补，但越具体交付越准：
- 课程主题 / 标题
- 目标受众（岗位、层级、人数）
- 时长（如 1 天/6 小时）
- 3-5 个学习目标
- 业务目标、核心主题、成功指标（可选）

写成 `brief.json`：
```json
{
  "title": "新任管理者领导力",
  "audience": "新晋经理，0-2 年管理经验",
  "duration": "2 天 / 12 小时",
  "participants": "24 人",
  "objectives": ["能完成团队目标拆解", "能进行绩效反馈对话", "能制定 90 天管理计划"],
  "business_goal": "提升新任经理的团队带教与目标达成能力",
  "topics": ["角色转型", "目标管理", "绩效反馈", "团队激励"],
  "success_metrics": "满意度≥4.5；90 天目标达成率提升 15%",
  "dates": "2026-03-12 至 03-13",
  "location": "深圳"
}
```

### 2. 服务端生成课程包
```bash
node scripts/generate.mjs --input brief.json --out training-course-package.zip
# 输出交付编号与 SHA256
unzip -o training-course-package.zip -d training-course-package
```

### 3. 审核与交付
- 检查 14 份文件与页脚授权信息；
- 可按客户品牌微调措辞，但**不得移除授权页脚**；
- 把 zip 或解压后的文件交付给用户。

## 14 份交付物
1. 01-课程大纲.docx
2. 02-讲师手册.docx
3. 03-学员手册.docx
4. 04-课程设计说明.docx
5. 05-招生文案.docx
6. 06-开课通知.docx
7. 07-课前提醒.docx
8. 08-课后跟进.docx
9. 09-课前测评.docx
10. 10-课后测验.docx
11. 11-反应层评估.docx
12. 12-30天应用评估.docx
13. 13-互动活动清单.docx
14. 14-交付清单.md

## 参考（仅方法，不参与生成）
- `references/course-design-brief-template.md`
- `references/course-design-methodology.md`
- `references/interactive-activities-library.md`

## 规则
- 未取得有效 `TSENT1` / `TSLIC1` 授权，**不得**输出课程包、不得伪造授权页脚；
- 按次授权 24 小时有效、一单一次交付；买断授权绑定设备、不得转售；
- 退款由管理端处理，客户端不直接退款；
- 服务端不保存 brief 原文，只记录输入哈希、交付编号与 SHA256。
