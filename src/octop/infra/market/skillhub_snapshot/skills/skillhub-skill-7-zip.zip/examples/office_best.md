```python
# -*- coding: utf-8 -*-
"""办公助手：生成 7-Zip 批量脚本 / Notepad++ 编码规范 / PDF24 命令。"""
import argparse, sys

SEVEN = """@echo off
:: 批量压缩当前目录每个子文件夹为独立 7z
for /d %%d in (*) do (
  7z a "%%d.7z" "%%d\" -mx=9 -pSECRET
)
echo done
"""

NPP = ["默认编码 UTF-8 无 BOM", "显示行尾符与空格", "开启 自动缩进/列编辑(Ctrl+Alt)",
       "大文件(>50MB)用 大文件模式", "正则替换: 搜索 ^(.*)$ 替换为 需求"]

PDF = ["合并: PDF24 -> 合并文件", "拆分: 按页范围导出", "转 Word: 导出为 DOCX(版式可能偏移)"]

def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument("action", nargs="?", default="demo")
    ap.add_argument("--product", default="7zip")
    a = ap.parse_args(argv[1:])
    if a.action == "demo":
        print("===== 7-Zip 批量脚本 =====\n" + SEVEN)
        print("\n===== Notepad++ 规范 =====")
        for n in NPP:
            print("  - " + n)
        print("\n===== PDF24 =====")
        for p in PDF:
            print("  - " + p)
        return
    if a.action == "7z":
        print(SEVEN)
    if a.action == "npp":
        for n in NPP:
            print(n)

if __name__ == "__main__":
    main(sys.argv)
```
