# 运行示例输出（执行 `office_best.py demo`）

```text
===== 7-Zip 批量脚本 =====
@echo off
:: 批量压缩当前目录每个子文件夹为独立 7z
for /d %%d in (*) do (
  7z a "%%d.7z" "%%d" -mx=9 -pSECRET
)
echo done


===== Notepad++ 规范 =====
  - 默认编码 UTF-8 无 BOM
  - 显示行尾符与空格
  - 开启 自动缩进/列编辑(Ctrl+Alt)
  - 大文件(>50MB)用 大文件模式
  - 正则替换: 搜索 ^(.*)$ 替换为 需求

===== PDF24 =====
  - 合并: PDF24 -> 合并文件
  - 拆分: 按页范围导出
  - 转 Word: 导出为 DOCX(版式可能偏移)
```
