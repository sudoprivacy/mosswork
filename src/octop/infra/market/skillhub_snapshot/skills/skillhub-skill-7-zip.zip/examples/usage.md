# 使用说明

```bash
# 保存 examples/office_best.md 中的代码为 office_best.py 后运行
set PYTHONIOENCODING=utf-8
python office_best.py demo        # 查看全部示例
python office_best.py config     # 按子命令生成具体配置
```

所有命令均为纯标准库实现，无需 pip install。
