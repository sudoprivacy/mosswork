## Description: <br>
Use when someone wants virtual try-on - dress a person in clothes from reference photos for fashion or ecommerce. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External developers and fashion or ecommerce teams use this skill to generate virtual try-on outputs by applying one or more garment reference images to a person photo while preserving the person and scene. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill sends selected person photos, garment images, prompts, and optional related content to Pruna's remote API. <br>
Mitigation: Use only user-approved media, disclose the remote API transfer before generation, and avoid third-party likeness or voice content without permission. <br>
Risk: The workflow can trigger paid Pruna generation calls. <br>
Mitigation: Confirm that PRUNA_API_KEY is intentionally configured and get user agreement on inputs before any POST /v1/predictions request. <br>
Risk: Try-on results can lose garments, misclassify unsupported references, or reduce quality in turbo mode. <br>
Mitigation: Run the provided quality checklist, keep final multi-garment jobs within the documented reliable range, and use normal mode for complex or final delivery assets. <br>


## Reference(s): <br>
- [ClawHub skill release](https://clawhub.ai/pruna-ai/skills/p-image-try-on) <br>
- [Pruna p-image-try-on model docs](https://docs.api.pruna.ai/guides/models/p-image-try-on) <br>
- [Runware virtual try-on guide](https://runware.ai/docs/models/prunaai-p-image-try-on/guides/virtual-try-on) <br>
- [Pruna API shared reference](references/pruna-api.md) <br>
- [p-image-try-on quality checklist](references/p-image-try-on-quality-checklist.md) <br>
- [Generation diversity](references/generation-diversity.md) <br>
- [Random seed ritual](references/random-seed-ritual.md) <br>
- [Realistic persona showcase](references/realistic-persona-showcase.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, shell commands, configuration] <br>
**Output Format:** [Markdown guidance with inline shell commands and JSON API request examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May lead the agent to upload user-approved images to Pruna's API and save generated image outputs when credentials are configured.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
