"""
多进程版 MD&A 提取 - ProcessPoolExecutor 突破 GIL
"""
import os, re, csv, json, time, requests, sys, io
from concurrent.futures import ProcessPoolExecutor, as_completed
from pypdf import PdfReader

WORK_DIR = "."  # 当前目录，按需修改
SEARCH_RESULT = os.path.join(WORK_DIR, "年报搜索结果.csv")
OUTPUT_CSV = os.path.join(WORK_DIR, "年报MD&A提取结果.csv")
PROGRESS = os.path.join(WORK_DIR, "mda_progress_mp.json")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://www.cninfo.com.cn/",
}


def extract_text(pdf_data):
    """pypdf 提取文本"""
    parts = []
    reader = PdfReader(io.BytesIO(pdf_data))
    for page in reader.pages:
        try:
            t = page.extract_text()
            if t:
                parts.append(t)
        except:
            pass
    result = "\n".join(parts)
    return result if len(result) > 5000 else None


def find_mda(text):
    """定位 MD&A 章节"""
    if not text or len(text) < 3000:
        return None
    skip = min(3000, len(text) // 10)
    for m in re.finditer(r'第[三四五六]节\s*管理层讨论[与和]分析', text[skip:], re.IGNORECASE):
        start = skip + m.start()
        return text[start:start + 100000]
    for m in re.finditer(r'管理层讨论[与和]分析', text[skip:], re.IGNORECASE):
        start = skip + m.start()
        return text[start:start + 100000]
    return None


def extract_subsections(mda_text):
    """提取核心竞争力和未来发展展望"""
    core, outlook = "", ""
    if not mda_text:
        return core, outlook

    m = re.search(r'核心竞争力分析', mda_text)
    if m:
        start = m.end()
        next_sec = re.search(r'\n\s*[（(][一二三四五六七八九十]+[)）]\s*\S', mda_text[start:start + 15000])
        end = start + next_sec.start() if next_sec else start + 12000
        core = mda_text[start:end].strip()

    m = re.search(r'公司未来发展[的之]展望', mda_text)
    if m:
        start = m.end()
        next_major = re.search(r'\n\s*第[一二三四五六七八九十]+\s*[节章]', mda_text[start:start + 20000])
        end = start + next_major.start() if next_major else start + 15000
        outlook = mda_text[start:end].strip()

    return core, outlook


def clean_text(text):
    if not text:
        return ""
    return re.sub(r'\s+', ' ', text).strip()


def process_one(company):
    """处理一家公司 (多进程worker)"""
    code = company.get("code", "")
    name = company.get("name", "")
    pdf_url = company.get("pdf_url", "")

    if not pdf_url:
        return {"code": code, "status": "error", "error": "no url"}

    # 下载
    try:
        resp = requests.get(pdf_url, headers=HEADERS, timeout=60)
        if resp.status_code != 200 or len(resp.content) < 10000:
            return {"code": code, "status": "error", "error": f"download {resp.status_code}"}
    except Exception as e:
        return {"code": code, "status": "error", "error": f"download: {str(e)[:80]}"}

    # 提取文本
    text = extract_text(resp.content)
    if not text:
        return {"code": code, "status": "error", "error": "text extraction failed"}

    # 定位 MD&A
    mda_text = find_mda(text)
    if not mda_text:
        return {"code": code, "status": "error", "error": "mda not found"}

    # 提取子章节
    core, outlook = extract_subsections(mda_text)

    return {
        "code": code,
        "status": "ok",
        "core_competitiveness": clean_text(core),
        "future_outlook": clean_text(outlook),
        "cc_len": len(core),
        "fo_len": len(outlook),
    }


def main():
    if not os.path.exists(SEARCH_RESULT):
        print(f"年报搜索结果不存在")
        return

    companies = []
    with open(SEARCH_RESULT, "r", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            companies.append(row)
    total = len(companies)
    print(f"加载 {total} 家公司", flush=True)

    # 加载进度
    progress = {}
    if os.path.exists(PROGRESS):
        with open(PROGRESS, "r", encoding="utf-8") as f:
            progress = json.load(f)
        done = sum(1 for v in progress.values() if v.get("status") == "ok")
        print(f"从进度恢复: {done} 家已完成", flush=True)

    # 过滤未完成的
    remaining = [c for c in companies if c.get("code") not in progress or progress[c["code"]].get("status") != "ok"]

    if not remaining:
        print("全部已完成!", flush=True)
        return

    workers = 8
    print(f"待处理: {len(remaining)}/{total}, 进程数: {workers}", flush=True)
    t0 = time.time()

    with ProcessPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(process_one, c): c for c in remaining}

        for future in as_completed(futures):
            try:
                result = future.result()
            except Exception as e:
                code = futures[future].get("code", "?")
                result = {"code": code, "status": "error", "error": str(e)[:100]}

            code = result["code"]
            progress[code] = result

            done = sum(1 for v in progress.values() if v.get("status") == "ok")
            err = sum(1 for v in progress.values() if v.get("status") == "error")
            elapsed = time.time() - t0
            rate = done / elapsed * 60 if elapsed > 0 else 0
            eta = (total - done - err) / rate if rate > 0 else 0

            if result["status"] == "ok":
                print(f"[{done}/{total}] {code} OK ({result['cc_len']}字/{result['fo_len']}字) "
                      f"速度:{rate:.0f}/分 ETA:{eta:.0f}分", flush=True)
            else:
                print(f"[{done}/{total}] {code} ERR: {result.get('error','')}", flush=True)

            if (done + err) % 10 == 0:
                with open(PROGRESS, "w", encoding="utf-8") as f:
                    json.dump(progress, f, ensure_ascii=False)

    # 最终保存
    with open(PROGRESS, "w", encoding="utf-8") as f:
        json.dump(progress, f, ensure_ascii=False)

    # 输出 CSV
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "股票代码", "股票名称", "年报标题", "年报日期",
            "核心竞争力分析", "公司未来发展的展望", "cc字数", "fo字数", "状态"
        ])
        writer.writeheader()
        for company in companies:
            code = company.get("code", "")
            r = progress.get(code, {})
            writer.writerow({
                "股票代码": code,
                "股票名称": company.get("name", ""),
                "年报标题": company.get("title", ""),
                "年报日期": company.get("date", ""),
                "核心竞争力分析": r.get("core_competitiveness", ""),
                "公司未来发展的展望": r.get("future_outlook", ""),
                "cc字数": r.get("cc_len", 0),
                "fo字数": r.get("fo_len", 0),
                "状态": r.get("status", "pending"),
            })

    elapsed = time.time() - t0
    done = sum(1 for v in progress.values() if v.get("status") == "ok")
    err = sum(1 for v in progress.values() if v.get("status") == "error")
    print(f"\n完成! 耗时:{elapsed/60:.1f}分 成功:{done} 失败:{err}")
    print(f"结果: {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
