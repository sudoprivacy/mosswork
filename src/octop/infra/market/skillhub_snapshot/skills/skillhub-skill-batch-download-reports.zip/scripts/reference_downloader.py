"""
下载A股白酒上市公司 2021-2025 年报、中报、季报 PDF
"""
import requests
import os
import time
import json
import re

OUTPUT_DIR = r"./reports"  # 输出目录，按需修改
CACHE_FILE = os.path.join(OUTPUT_DIR, "download_cache.json")

LIQUOR_COMPANIES = [
    ("600519", "贵州茅台"), ("000858", "五粮液"), ("000568", "泸州老窖"),
    ("600702", "舍得酒业"), ("000799", "酒鬼酒"), ("600809", "山西汾酒"),
    ("000596", "古井贡酒"), ("603369", "今世缘"), ("600559", "老白干酒"),
    ("600199", "金种子酒"), ("603198", "迎驾贡酒"), ("600779", "水井坊"),
    ("000860", "顺鑫农业"), ("603919", "金徽酒"), ("002304", "洋河股份"),
    ("600197", "伊力特"), ("000995", "皇台酒业"), ("603589", "口子窖"),
    ("600381", "青海春天"),
]

API_HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Content-Type": "application/x-www-form-urlencoded",
    "Origin": "https://www.cninfo.com.cn",
    "Referer": "https://www.cninfo.com.cn/new/commonUrl?url=disclosure/list/notice",
}

DL_HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Referer": "https://www.cninfo.com.cn/",
}


def search(code, name, year, report_type):
    """搜索指定公司的报告"""
    # 确定交易所
    if code.startswith("6"):
        column, plate = "sse", "sh"
    else:
        column, plate = "szse", "sz"

    # 搜索关键词（不用年份，CNINFO分词问题会导致搜不到）
    searchkey = f"{name} {report_type}"
    # 年报季通常在次年1-4月
    if report_type == "年度报告":
        se_date = f"{year+1}-01-01~{year+1}-04-30"
    else:
        se_date = f"{year}-01-01~{year+1}-06-30"

    url = "https://www.cninfo.com.cn/new/hisAnnouncement/query"
    data = {
        "pageNum": 1, "pageSize": 10,
        "column": column, "plate": plate,
        "tabName": "fulltext",
        "searchkey": searchkey,
        "seDate": se_date,
    }

    try:
        resp = requests.post(url, data=data, headers=API_HEADERS, timeout=15)
        result = resp.json()
        for ann in (result.get("announcements") or []):
            title = ann.get("announcementTitle", "")
            sec_code = ann.get("secCode", "")

            # 匹配条件
            if sec_code != code:
                continue
            if report_type not in title:
                continue
            # 排除非正文
            bad = ["摘要", "英文", "提示性", "说明会", "更正公告", "补充公告",
                   "问询", "审核问", "修订", "业绩预告", "业绩快报", "English"]
            if any(kw in title for kw in bad):
                continue
            # 年份二次确认
            if str(year) not in title:
                continue

            return ann.get("adjunctUrl", "")

    except Exception as e:
        print(f"      API异常: {e}", flush=True)

    return None


def download_pdf(pdf_path, filename):
    """下载PDF"""
    filepath = os.path.join(OUTPUT_DIR, filename)
    if os.path.exists(filepath) and os.path.getsize(filepath) > 10000:
        return True  # 已存在

    pdf_url = "https://static.cninfo.com.cn/" + pdf_path
    try:
        resp = requests.get(pdf_url, headers=DL_HEADERS, timeout=60)
        if resp.status_code == 200 and len(resp.content) > 10000:
            with open(filepath, "wb") as f:
                f.write(resp.content)
            return True
    except:
        pass
    return False


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    cache = {}
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            cache = json.load(f)

    reports = [
        ("年度报告", "年报"),
        ("半年度报告", "中报"),
        ("第一季度报告", "一季报"),
        ("第三季度报告", "三季报"),
    ]
    years = [2021, 2022, 2023, 2024, 2025]
    total = len(LIQUOR_COMPANIES) * len(years) * len(reports)

    downloaded = 0
    skipped = 0
    not_found = 0

    for ci, (code, name) in enumerate(LIQUOR_COMPANIES):
        for yi, year in enumerate(years):
            for rt_kw, rt_label in reports:
                cache_key = f"{code}_{year}_{rt_label}"
                filename = f"{code}_{name}_{year}_{rt_label}.pdf"

                if cache.get(cache_key) == "ok":
                    skipped += 1
                    continue

                pdf_path = search(code, name, year, rt_kw)
                if pdf_path:
                    ok = download_pdf(pdf_path, filename)
                    if ok:
                        downloaded += 1
                        cache[cache_key] = "ok"
                        print(f"[{downloaded+skipped+not_found}/{total}] {code} {name} {year} {rt_label} OK", flush=True)
                    else:
                        not_found += 1
                        print(f"[{downloaded+skipped+not_found}/{total}] {code} {name} {year} {rt_label} FAIL", flush=True)
                else:
                    not_found += 1
                    # 不打印未找到的，减少噪音

                time.sleep(0.25)

            # 每年结束保存缓存
            if yi == len(years) - 1:
                with open(CACHE_FILE, "w", encoding="utf-8") as f:
                    json.dump(cache, f)
                print(f"  [{name}] 完成 {year}", flush=True)

    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache, f)

    # 统计
    pdfs = [f for f in os.listdir(OUTPUT_DIR) if f.endswith(".pdf")]
    print(f"\n=== 完成 ===", flush=True)
    print(f"下载: {downloaded}, 跳过: {skipped}, 未找到: {not_found}", flush=True)
    print(f"PDF总数: {len(pdfs)}", flush=True)
    for code, name in LIQUOR_COMPANIES:
        cnt = len([f for f in pdfs if f.startswith(code)])
        print(f"  {name}: {cnt} 份", flush=True)


if __name__ == "__main__":
    main()
