# z-pyramid（金字塔原理）

一句话：自上而下表达——先给答案，再给支撑答案的分组理由，每组下面才是证据。本 skill 是 z-系列的方法论底座。

## 何时使用

说"拆解问题、issue tree、逻辑树、结构化表达、结论先行、So What、报告重构"，或意图是"把问题拆清楚 / 把表达变结论先行"时触发。典型场景：拆模糊大问题（SCQA + MECE issue tree）、重构结论后置的文稿、点评汇报结构。

## 用法速览

- 问法：「帮我把 X 拆成问题树」「这份汇报结论后置了，按金字塔重构」
- 用法卡：聊天说 `z-pyramid help`，ZCode 下 `/z-pyramid-help` 直达
- 单轮任务不占轮次：一句话复述后直接开工

## 核心机制

- **三条铁律**：用户没让改文档就不改（点评+问题收尾）；时间顺序即内容的东西不套金字塔；不虚构源材料外的事实与结论。
- **Gate**：材料需要读者接受判断或做决定才适用；时间线/教程/操作手册一句话说明并停。
- **核心结构**：结论先行 + 纵向三规则（结论→理由→证据）+ MECE 分组 + So What 提炼。
- **被全系引用**：z-clarify 用它拆大需求、验报告；z-assess 用结论先行组织评估报告——作为方法论层被调用时跳过"先问"，直接供方法。

## 与 z-系列的关系

```
z-flow-kickoff（编排：开场协议→契约→横幅→交接→续跑）
   └─ z-pyramid(本 skill：拆解) → z-clarify(澄清→登记册) ⇄ z-chain(生态/干系人事实)
                              ↓
                       z-assess(四维+风险+假设 → Go/No-Go)
                              ↓ Go
                       z-init(工程文档基线化) → 下游 spec/开发（松耦合，AGENTS.md 契约）
```

分工：本 skill 管"怎么想、怎么表达"；评估维度与结论归 z-assess，生态事实归 z-chain，澄清流程归 z-clarify。整链编排见 z-flow-kickoff；六技能相互独立、按需组合，联动方未安装时按各自文内退化规则执行。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`）；更新只需 `git -C ~/z-skill-series pull`，无需重装。GitHub HTTPS 不稳时可改用 SSH。

### 单独安装（任一 agent）

把 `skills/z-pyramid` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装已实测可用：`npx skills add zimy0033/z-skill-series/skills/z-pyramid`。

## License

MIT
