# 期权

[全部业务域](../README.md)

期权品种、合约与行情；按完整合约代码定位。


## 资料与标识

查询目录、搜索、合约或基本资料，取得后续请求所需标识。

| 需求 / 文档 | 接口或工具 | 使用范围 |
| --- | --- | --- |
| [期权品种资料](varieties-list.md) | `GET /api/options/varieties/list` | 公开 |
| [期权合约详情](options-reference.md#contracts-detail) | `GET /api/options/contracts/detail` | 公开 |
| [期权合约基础信息列表](options-reference.md#contracts-list) | `GET /api/options/contracts/list` | 公开 |

## 行情

查询分时走势选择期权分时行情，查询日线选择期权日 K。

| 需求 / 文档 | 接口或工具 | 使用范围 |
| --- | --- | --- |
| [期权分时](options-prices.md#prices-intraday) | `GET /api/options/prices/intraday` | 公开 |
| [期权K线](options-prices.md#prices-daily) | `GET /api/options/prices/daily` | 公开 |
