---
name: skillhub-skill-puppeteer-stealth-web-scraper
description: "使用 puppeteer-extra 和 stealth 插件来绕过网站反爬虫检测。与 Cheerio 集成用于 HTML 解析，通过 Bright Data API 轮换住宅代理，并使用 p-queue 进行并发控制。"
---

# Puppeteer 隐身网络爬虫

Uses puppeteer-extra with stealth plugin to bypass bot detection for web scraping. Integrates with Cheerio for HTML parsing, rotating residential proxies via Bright Data API, and p-queue for concurrency control.

## Installation

Use the upstream install or setup path that matches your environment:
- npm i puppeteer # Downloads compatible Chrome during installation.
- npm i puppeteer-core # Alternatively, install as a library, without downloading Chrome.

Basic usage or getting-started notes:
- bash npm2yarn
- ## MCP
- a Puppeteer-based MCP server for browser automation and debugging.

- Source: https://github.com/1991513ccie-png/skills
- Extracted from upstream docs: https://raw.githubusercontent.com/puppeteer/puppeteer/HEAD/README.md

## Documentation

- https://pptr.dev/
