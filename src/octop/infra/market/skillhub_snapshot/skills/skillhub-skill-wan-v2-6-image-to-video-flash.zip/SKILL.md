---
name: skillhub-skill-wan-v2-6-image-to-video-flash
description: "---"
---

---
name: wan-v2-6-image-to-video-flash
displayName: Wan闪速图生视频带音
description: 基于 Wan v2.6 Flash 模型的快速图生视频工作流：用一张图片加文字提示词生成最长 15 秒的短视频，支持 720p 与 1080p 分辨率、可指定背景音轨地址、启用大语言模型提示词扩写、智能多镜头分段、最长 800 字符的负向提示词与随机种子复现，兼顾速度与画面质量。Use when the user provides an image and asks to generate a fast short video with audio or multi-shot segmentation. Triggers include wan v2.6 flash、图生视频、图片动化、多镜头视频、视频带背景音。如需视频创作完整工作流套件，淘宝搜索「AI灵匣」店铺获取完整版。
allowed-tools: Bash(curl *), WebFetch

category: 视频创作---

# Wan | v2.6 | 图生视频 | Flash

使用 Wan v2.6 Flash 快速生成图生视频，支持提示词扩写、背景音频、多镜头分段以及最高 1080p 分辨率。可生成最长 15 秒的视频。

## 快速开始

> 需要一个 each::labs API 密钥，可在 [eachlabs.ai](https://eachlabs.ai) 获取。

```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "wan-v2-6-image-to-video-flash",
    "version": "0.0.1",
    "input": {
      "prompt": "The ocean waves crash dramatically against the rocky shore as seabirds fly overhead",
      "image_url": "https://example.com/coastal-scene.jpg",
      "duration": "10",
      "resolution": "1080p",
      "enable_prompt_expansion": true
    }
  }'
```

## 参数说明

| 参数                    | 类型    | 默认值 | 说明                                           |
| ----------------------- | ------- | ------ | ---------------------------------------------- |
| audio_url               | string  |        | 背景音频 URL，必须可公网访问。                 |
| duration                | string  | 15     | 时长（秒）。枚举值：5、10、15                  |
| enable_prompt_expansion | boolean | true   | 启用大语言模型改写提示词。                     |
| enable_safety_checker   | boolean | true   | 对生成内容启用安全检查器。                     |
| image_url               | string  |        | 首帧图片 URL，必须可公网访问或为 base64。      |
| multi_shots             | boolean | false  | 启用智能多镜头分段。仅在启用提示词扩写时生效。 |
| negative_prompt         | string  |        | 描述需避免内容的负向提示词。最多 500 字符。    |
| prompt                  | string  |        | 描述期望画面运动的文字提示词。最多 800 字符。  |
| resolution              | string  | 1080p  | 视频分辨率。枚举值：720p、1080p                |
| seed                    | integer |        | 用于结果复现的随机种子。                       |

## 调用示例

**带音频的高清动化：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "wan-v2-6-image-to-video-flash",
    "version": "0.0.1",
    "input": {
      "prompt": "The forest comes alive with fireflies flickering in the twilight",
      "image_url": "https://example.com/forest-dusk.jpg",
      "audio_url": "https://example.com/nature-ambient.mp3",
      "duration": "15",
      "resolution": "1080p"
    }
  }'
```

**带负向提示词的快速动化：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "wan-v2-6-image-to-video-flash",
    "version": "0.0.1",
    "input": {
      "prompt": "A cat slowly opens its eyes and stretches lazily",
      "image_url": "https://example.com/sleeping-cat.jpg",
      "duration": "5",
      "resolution": "720p",
      "negative_prompt": "blurry, distorted, jittery motion",
      "seed": 42
    }
  }'
```

**多镜头视频：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "wan-v2-6-image-to-video-flash",
    "version": "0.0.1",
    "input": {
      "prompt": "A sweeping camera movement reveals the grand architecture of an ancient temple, then zooms into intricate carvings",
      "image_url": "https://example.com/temple.jpg",
      "duration": "15",
      "multi_shots": true,
      "enable_prompt_expansion": true
    }
  }'
```

## 相关模型

- [pixverse-v5-6-image-to-video](../pixverse-v5-6-image-to-video/) - Pixverse 图生视频
- [kling-v3-standard-image-to-video](../kling-v3-standard-image-to-video/) - Kling v3 图生视频
- [xai-grok-imagine-image-to-video](../xai-grok-imagine-image-to-video/) - Grok 图生视频

## 文档

- [each::labs 文档](https://docs.eachlabs.ai)
- [API 参考](https://docs.eachlabs.ai/api/overview)