---
name: skillhub-skill-bili-transcribe
description: "B站视频语音听译/转写技能 - 将 B 站视频音频下载并转写为中文文本。触发场景：用户给出 B 站视频链接（含 BV 号）要求听译、转写、提取字幕、语音识别全文、或'截听译全文再分析'。处理长视频时自动切分并逐块转写。复用系统 Python 与共享模型缓存，不创建虚拟环境、不重复下载权重。"
---

# B站视频听译 (bili-transcribe)

> **Goal**: 把 B 站视频音频下载下来，用 Whisper 转写成中文全文，供后续分析使用。
> 设计原则：零虚拟环境、共享模型缓存、用完即清；官方字幕直取优先；交付前 AI 校对。
> 版本主题与完整变更史见 [CHANGELOG.md](./CHANGELOG.md)。v1.9.0 起 SKILL.md 按 thin-hub
> 规范瘦身：长内容拆到 `references/`，本文件只做入口与路由。
> Windows/Linux 双平台安装构建验证见 [CROSS_PLATFORM.md](./CROSS_PLATFORM.md)（同一份代码直接运行）。

## 最快路径：一条命令

```bash
python3 scripts/run.py "https://www.bilibili.com/video/BVxxxxxxxxx"
```

`run.py` 自动串起全流程：环境检查 → 模型准备 → **检查官方字幕（有则跳过转写）** → 下载音频 → 切分 → 逐块转写 → 合并 → 清理。
**中断后重跑同一条命令即可续跑**，已完成的块不重来。首次使用者请先看 [QUICKSTART.md](./QUICKSTART.md)。

常用选项：

| 选项 | 用途 |
|---|---|
| `--dry-run` | 只检查和预估耗时（含官方字幕提示 + 建议传的 `-p` 领域术语），不下载不转写 |
| `--model small` | 指定模型（默认按本机 CPU/磁盘自动选） |
| `-p "领域术语"` | 提高专有名词识别准确率（dry-run 会建议该传什么） |
| `--language en` | 视频是英文/日文时指定语言，显著提升转写质量（默认 zh） |
| `--beam-size 1` | Whisper 束搜索宽度，默认 5；资源极紧时降 1（更快但更不准） |
| `--srt` | 额外输出 SRT/VTT 字幕（可直接挂播放器） |
| `--fix-dict SPEC` | 可选后处理纠错词典：`oss`（内置开源通用词典，词边界护栏）、`path.json`（自有词库），逗号组合 |
| `--budget 480` | 单次最多跑 480 秒，到点保存进度退出（退出码 **75**），重跑续跑 |
| 其他 | `--page 2` 多 P 选集 · `--cookie "SESSDATA=xxx"` 显式登录态（优先级最高）· `--keep` 保留中间文件 |

**登录态自动分层**（v2.0.0，不传 `--cookie` 时）：环境变量 `BILI_SESSDATA` > `~/.bili-transcribe/config.json` > 本机浏览器 CDP(:9222) > 游客模式。云端沙箱无浏览器时自动静默降级，零副作用。首次使用有引导文案；自检用 `python3 scripts/bili_config.py status`。给网友的三场景说明见 [references/multi-user.md](./references/multi-user.md)。

> **给 Agent 的提示**：有工具超时限制的环境里，用 `--budget 480` 反复调用直到退出码为 0，
> 比手工循环调 `scripts/transcribe_chunk.py` 更省事且不丢进度；中断后忘了原命令，
> 看工作目录 `.bili_<BV号>/task.json` 即知参数。

## When to Use / NOT to Use

- ✅ 用户给出 `bilibili.com/video/BVxxxx` 链接，要求"听译/转写/提取字幕/语音识别全文"
- ❌ 用户只给了网页文章/非 B 站视频 → 用 WebFetch 直接抓文本
- ❌ 视频已有 CC 字幕 → 先查 `x/player/v2` 的 subtitle 字段直接拉字幕，不必转写
- ⚠️ 纯本地音频转写 → 可复用 `scripts/transcribe_chunk.py`，跳过 get_audio 步骤

## 环境与磁盘公约（务必遵守；细节与理由见 references/workflow.md 开头）

1. **绝不为本技能创建虚拟环境**——复用当前解释器，`python3 scripts/ensure_env.py` 幂等装依赖。
2. **pip 一律 `--no-cache-dir`**——漏加时 `~/.cache/pip` 会膨胀到 5 GB+，比模型还大。
3. **模型权重放共享缓存**（默认 `~/.local/whisper-models/<模型名>`），已有则复用不重下。
4. **用完即清**——收尾必跑 `python3 scripts/cleanup.py` 回收中间 wav/切块/临时 json。
5. **首次使用者优先**——失败给「人话原因 + 一行修复命令」，耗时步骤先说清下多少、等多久。

## 标准工作流路由表

工作目录建议用 `/root/.codebuddy/artifact/<task>/` 作临时区，**最终交付文件写 `/workspace`**。
每步的完整命令、参数说明与实测注意事项见 **[references/workflow.md](./references/workflow.md)**。

| 步骤 | 做什么 | 一句话命令 |
|---|---|---|
| 0 备齐环境 | 幂等装依赖（不建 venv） | `python3 scripts/ensure_env.py` |
| 1 下载音频 | dash 流直取（勿用 yt-dlp，必被风控） | `python3 scripts/get_audio.py "<URL或BVid>" audio.wav` |
| 2 模型就绪 | 共享缓存自动选型，已有则秒过 | `python3 scripts/setup_model.py --auto` |
| 3 切分长音频 | 自适应静音点 + 硬上限兜底 | `python3 scripts/split.py audio.wav chunks --rm-source` |
| 4 逐块转写 | **前台串行勿并行**；先想领域传 `-p` | `timeout 400 python3 scripts/transcribe_chunk.py <i> -p "<术语>" --rm-chunk` |
| 5 合并 | 自动过滤 Whisper 幻觉段 | `python3 scripts/merge.py <块数量> /workspace` |
| 6 收尾清理 | 必做；保留模型与最终产物 | `python3 scripts/cleanup.py` |

> **长视频（>10min）改用单进程后台**：
> `nohup python3 scripts/run.py "<url>" --keep > run.log 2>&1 &`
> run.py 内部串行调度、断点续跑；进度看 `tail run.log` 或 `.bili_<BV号>/task.json`。

## 转写之后（可选增值步骤）

- **AI 校对（正式步骤 7，强烈建议）**：ASR 直出对中文专名误识率高（实测 NAS→納斯、AI→AA），
  且校对必须由独立子代理执行、主对话只发起+接收（隔离原则）。强制流程与子代理 briefing 全文见
  **[references/proofread.md](./references/proofread.md)**。
- **技术类总结（正式步骤 8）**：用户要"进一步分析/梳理/总结"时按现成骨架产出
  `梳理总结_<BV号>.md`（结论先行 + 对比表 + 术语口径 + 关键数据 + 个人研判），
  模板与约定见 **[references/summary-template.md](./references/summary-template.md)**。

## ⚠️ 踩坑铁律（实战沉淀；全文 14 条见 [references/pitfalls.md](./references/pitfalls.md)）

最容易翻车的几条：

1. pip 不加 `--no-cache-dir` 是最大的隐形空间黑洞（实测 5 GB+）。
2. 不要并发多个 transcribe 子进程；长任务改单进程后台跑 `run.py`（内部串行，父进程存活即续跑）。
3. `pkill` 绝不用会出现在自己命令行里的 pattern；停止进程按已知 PID kill。
4. 先查官方字幕（`x/player/v2` 的 subtitle），有就直接拉，省去整轮转写。**AI 字幕必须登录态**（实测无登录 code 0 但字幕轨 = 0），游客模式只能拿 UP 主手传的 CC 字幕。
5. 静音检测必须相对 mean_volume 自适应（写死 −30dB 在响度压缩视频上一个切点都判不出）。
6. 交付前必须 AI 校对专名；先 WebSearch 核实再改，严禁臆造。

## 输出约定

| 文件 | 内容 |
|---|---|
| `transcript_full.txt` | 带时间戳 `[mm:ss-mm:ss]` 的完整逐段文本 |
| `transcript_plain.txt` | 纯文本（无时间戳），便于阅读/二次分析 |

如需进一步"分析"，把转录稿作为素材，结合 WebSearch/WebFetch 核实事实后产出结构化报告。

## 文件地图

| 路径 | 内容 |
|---|---|
| [QUICKSTART.md](./QUICKSTART.md) / [README.md](./README.md) | 新手五分钟入门 / 人类入口页 |
| [CROSS_PLATFORM.md](./CROSS_PLATFORM.md) / [CHANGELOG.md](./CHANGELOG.md) | 双平台说明 / 完整变更史 |
| [references/multi-user.md](./references/multi-user.md) | 给网友的三场景说明与隐私声明 |
| `references/workflow.md` | 步骤 0–6 完整 SOP 与注意事项 |
| `references/proofread.md` | AI 校对流程与子代理 briefing |
| `references/summary-template.md` | 技术类总结模板 |
| `references/pitfalls.md` | 踩坑铁律全文 |
| `examples/case-index.md` | 示例产物与真实案例索引 |
| `scripts/*.py` | ensure_env / envkit / get_audio / setup_model / split / transcribe_chunk / merge / cleanup / run / bili_config / bili_cdp_cookie |
| `scripts/bili_config.py` | 登录态分层管理（status / set-cookie / clear），配置在 `~/.bili-transcribe/config.json` 永不入仓 |
| `scripts/bili_cdp_cookie.py` | 本机浏览器 CDP 读登录态（纯标准库 WS 客户端，失败静默降级） |
| `config.example.json` | 配置示例（全占位符） |
| `dicts/oss_zh.json` | 内置开源通用纠错词典 |