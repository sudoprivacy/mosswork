# 快速开始（第一次用，看这一页就够）

> **Windows 与 Linux 虚拟机用法完全一致**（v1.5.0 起），下面命令两边通用。
> Windows 上若提示缺 ffmpeg，脚本会自动尝试 `winget install --id Gyan.FFmpeg`；
> 若装了 ffmpeg.exe 但没有 ffprobe，脚本会自动降级用 `ffmpeg -i` 解析时长，不影响使用。

## 三步跑通

```bash
# 1. 体检 + 自动补齐依赖（不会创建虚拟环境，用你现有的 Python）
python3 scripts/ensure_env.py

# 2. 下载语音模型（整个流程唯一的大件，只需一次，之后所有任务共用）
python3 scripts/setup_model.py --auto

# 3. 跑一个视频
python3 scripts/run.py "https://www.bilibili.com/video/BV1apuc6UEir"
```

第 3 步会自动完成：查官方字幕（有则直接拿字幕）→ 下载音频 → 切分 → 逐块转写 → 合并全文 → 清理中间文件。
产物是 `transcript_full.txt`（带时间戳）、`transcript_plain.txt`（纯文本）；
加 `--srt` 会额外输出可直接挂播放器的 SRT/VTT 字幕。

> 嫌麻烦？直接执行第 3 步也行 —— `run.py` 会自己检查环境、按需装依赖和下模型。

---

## 先搞清楚要花多少时间和空间

跑之前先问一句，不打无准备之仗：

```bash
python3 scripts/run.py "<视频链接>" --dry-run
```

它只查不做，会告诉你：本机几核、磁盘剩多少、用哪个模型、**这个视频大概要转多久**。

**空间开销**（一次性，之后不再增长）：

| 项目 | 大小 | 说明 |
|---|---|---|
| 语音模型 | 0.2 – 3.1 GB | 看你选哪个，**所有任务共用一份** |
| Python 依赖 | 约 60 MB | 装进你现有环境，不建虚拟环境 |
| 单个视频中间文件 | 20 – 60 MB | 跑完自动清理 |

**时间开销**：转写是纯 CPU 计算，大致按下表估：

| 机器 | 推荐模型 | 10 分钟视频约需 |
|---|---|---|
| 8 核以上 | large-v3 | 10 分钟 |
| 4 核 | medium | 10 分钟 |
| 2 核 | small | 11 分钟 |

> 进度条走得慢是正常的，不是卡死。`run.py` 每转完一块都会报剩余时间。

---

## 常见问题

**Q：会不会在我电脑上建虚拟环境、占一堆空间？**

不会，这是本技能的硬性设计原则。依赖装进你**当前的** Python 环境（已经在 venv/conda 里就装进去，否则装系统环境），pip 全程 `--no-cache-dir` 不留缓存。模型放共享目录 `~/.local/whisper-models/`，多个任务、多个技能复用同一份。

**Q：我磁盘不多 / 机器不快，怎么办？**

用 `--auto`，脚本会按你的 CPU 和磁盘自动挑模型。也可以手动指定：

```bash
python3 scripts/setup_model.py --list     # 看各模型占多大、本机跑多快
python3 scripts/setup_model.py small      # 0.6 GB，快很多
```

**Q：跑到一半断了 / 关了终端 / 断网了？**

重跑**同一条命令**就行，已完成的块不会重来，模型下载也会断点续传。

**Q：转写太慢，能不能限制单次运行时间？**

```bash
python3 scripts/run.py "<链接>" --budget 480   # 最多跑 8 分钟
```

到点会保存进度并退出（退出码 75），重跑继续。适合自动化脚本或有超时限制的环境。

**Q：专业术语识别不准？**

把这期视频的关键词告诉它：

```bash
python3 scripts/run.py "<链接>" -p "本视频涉及 Cherry Studio、MCP、RAG 等术语"
```

**Q：视频是英文/日文的？**

默认按中文转写，英文/日文视频请显式指定语言（质量显著提升）：

```bash
python3 scripts/run.py "<链接>" --language en    # 或 ja
```

**Q：转写结果里有明显错字？**

v1.4.0 起默认束搜索宽度 5，同音字误识已大幅减少。仍有个别错字时，可以用词典一键修正：

```bash
echo '{"避缓":"闭环","所死":"锁死"}' > fix.json
python3 scripts/run.py "<链接>" --fix-dict fix.json
```

**Q：视频有官方字幕，还要转写吗？**

不用。`run.py` 会自动检测官方字幕，有就直接下载字幕产出全文和 SRT，跳过整轮转写。想看有没有字幕：`python3 scripts/run.py "<链接>" --dry-run`。

**Q：连不上、装不上？**

```bash
python3 scripts/ensure_env.py --doctor
```

会逐项检查硬件、网络连通性、依赖、模型，并给出具体的修复命令。
在公司/校园网内通常是要配代理：`export https_proxy=http://<代理>:<端口>`

**Q：想把空间要回来？**

```bash
python3 scripts/cleanup.py --dry-run    # 先看会删什么
python3 scripts/cleanup.py --caches     # 清中间文件 + pip 等缓存
python3 scripts/cleanup.py --deep       # 连模型一起删（下次要重新下）
```

---

## 全部命令速查

```bash
# 环境
python3 scripts/ensure_env.py              # 体检 + 装依赖
python3 scripts/ensure_env.py --doctor     # 完整诊断（含网络、耗时预估）

# 模型
python3 scripts/setup_model.py --list      # 看有哪些模型、本机多快
python3 scripts/setup_model.py --auto      # 自动选一个下

# 跑
python3 scripts/run.py "<链接>"                      # 一键全流程
python3 scripts/run.py "<链接>" --dry-run            # 只预估不执行
python3 scripts/run.py "<链接>" --model small        # 指定模型
python3 scripts/run.py "<链接>" -p "领域术语"         # 提高专名准确率
python3 scripts/run.py "<链接>" --language en        # 英文/日文视频指定语言
python3 scripts/run.py "<链接>" --srt                # 额外输出 SRT/VTT 字幕
python3 scripts/run.py "<链接>" --fix-dict fix.json  # 按词典修正错字
python3 scripts/run.py "<链接>" --page 2             # 多 P 视频选第 2 P
python3 scripts/run.py "<链接>" --budget 480         # 限时运行，可续跑
python3 scripts/run.py "<链接>" --keep               # 保留中间文件

# 单独看视频信息（不下载）
python3 scripts/get_audio.py "<链接>" --info

# 清理
python3 scripts/cleanup.py --caches
```

分步执行（需要精细控制时）见 `SKILL.md` 的标准工作流。
