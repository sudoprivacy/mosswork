# dicts/ — 纠错词典目录

## oss_zh.json（开源通用层 · v1.8.0 新增）

- **定位**：通用中文「常见错别字」纠错底层，**仅显式调用**（`--fix-dict oss`），不默认启用。
- **收录原则**：只收「左形在规范中文里几乎从不正确的常见错别字」，
  不收语境依赖词（如 反应/反映、启事/启示），避免误伤。
- **技术专名不在此列**：DeepSeek→DeepSick 类 AI/技术专名无可靠开源资源，
  降误识杠杆始终是 `-p` 提示词 + 步骤 7 LLM 校对（见 SKILL.md）。
- **护栏**：`oss` 词典在 `merge.py` 中走词边界模式——单字误识仅当不被其它
  CJK 字夹住时才替换（防止嵌在长词里误伤，如「深」不会误改「深圳」）；
  多字条目按子串替换。

### 维护（有进有出）

- 想要更全的通用纠错，可把 [pycorrector](https://github.com/shibing624/pycorrector)
  的同源数据（如 `same_pinyin.txt`）经人工筛选后并入本文件；**只取数据、不引代码**。
- 自己的领域词库请放 `dicts/tech.json` 等独立小表，用 `--fix-dict tech.json` 调用，
  与通用层分立、各自治理。

## 用法

```bash
# 仅用开源通用层
python3 scripts/merge.py 9 /workspace --fix-dict oss

# 通用层在前 + 自己的词库在后（逗号组合，可重复 --fix-dict）
python3 scripts/merge.py 9 /workspace --fix-dict oss,my.json
# 或 run.py 一条命令：
python3 scripts/run.py "<url>" --fix-dict oss,my.json
```
