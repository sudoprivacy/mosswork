# 给网友：bili-transcribe 多用户使用说明

> 本技能**不收集、不上传任何数据**：你的 B 站登录态只保存在你自己的机器/沙箱里，
> 只用于向 B 站官方 API 请求你自己的数据。作者侧无任何服务器、无任何遥测。

## 我该用哪种模式？

| 你的环境 | 模式 | 你需要做 | 能拿到什么 |
|---|---|---|---|
| 本机有浏览器且已登录 B 站 | **本机自动** | 保持浏览器调试实例运行（默认 127.0.0.1:9222），什么都不用配 | 官方 CC 字幕 + **AI 字幕直取**（长视频秒出全文），无字幕再本地 Whisper |
| 云端沙箱 / 无浏览器 | **自配登录态**（可选） | `python3 scripts/bili_config.py set-cookie "SESSDATA=xxx"` | 同上 |
| 什么都不想配 | **游客模式** | 什么都不做 | CC 字幕（UP 主上传过的）直取；没有则本地 Whisper 转写 |

三种模式**都能跑通**，配置只是加速，不是门槛。

## 怎么拿自己的 SESSDATA？

1. 电脑浏览器登录 `bilibili.com`
2. 按 `F12` → Application/应用（或 存储）→ Cookies → `https://bilibili.com`
3. 找到名为 `SESSDATA` 的行，复制它的**值**（不要带等号、不要复制整条 Cookie）
4. 写入配置：`python3 scripts/bili_config.py set-cookie "粘贴这里"`（也接受完整 `SESSDATA=xxx` 格式）

⚠️ **安全提醒**：SESSDATA 等同你的 B 站账号身份，泄露 = 账号可能被盗用。
- 不要发给任何人（包括技能作者）、不要截图、不要提交进任何 git 仓库
- 配置文件存在 `~/.bili-transcribe/config.json`（POSIX 下已自动收紧为 600 权限）
- 怀疑泄露就去 B 站「账号安全」里退出全部设备，登录态立即作废

## 云端沙箱注意事项

- 无 GUI 浏览器属正常现象：CDP 自动探测会静默跳过，不会报错
- 机房出口 IP 可能被 B 站风控：音频直取失败时，配置 SESSDATA 后重试通常可解
- 无 GPU 时转写较慢：用 `--budget 480` 分次跑（到点存进度，重跑即续），或 `--dry-run` 先看预估耗时

## 常用自检

```bash
python3 scripts/bili_config.py status        # 当前登录态来源（值打码，永不回显完整值）
python3 scripts/bili_cdp_cookie.py [端口]    # 单测本机浏览器 CDP 链路
python3 scripts/ensure_env.py --doctor       # 完整体检（硬件/依赖/模型/耗时预估）
```
