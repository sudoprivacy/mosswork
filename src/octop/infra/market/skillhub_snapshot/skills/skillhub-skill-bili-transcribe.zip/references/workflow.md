# 标准工作流详解（步骤 0–6）

> 本文是 `SKILL.md` 路由表指向的完整 SOP，命令均可直接复制执行。
> 工作目录建议用 `/root/.codebuddy/artifact/<task>/` 作为临时区，**最终交付文件写 `/workspace`**。
> Windows/Linux 双平台安装、构建与验证见根目录 CROSS_PLATFORM.md（同一份代码直接运行）。

## 环境与磁盘公约（v1.1.0 核心，务必遵守）

**1. 绝不为本技能创建虚拟环境。** 不 `python -m venv`、不 `virtualenv`、不 `conda create`。
一律复用当前解释器：已在某个 venv/conda 中就装进去，否则装进系统环境。
> 理由：`faster-whisper` + `ctranslate2` 依赖链 1–3 GB，每个技能各建一份纯属浪费，
> 且与宿主已装好的包完全重复。`scripts/ensure_env.py` 已按此实现，直接调用即可。

**2. pip 一律 `--no-cache-dir`（或用 `uv --no-cache`）。**
> 实测教训：漏加时 `~/.cache/pip` 会膨胀到 **5 GB+**，比模型本身还大。

**3. 模型权重放共享缓存，不放技能私有目录。**
默认 `~/.local/whisper-models/<模型名>`，可用 `$WHISPER_MODEL_DIR` 覆盖。
脚本会自动探测已存在的权重（含 v1.0.0 的 `/root/whisper-large-v3`）并复用，**不重复下载 3 GB**。

**4. 用完即清。** 收尾必须跑 `scripts/cleanup.py`，回收中间 wav / 切块 / 临时 json。
> 一次 35 分钟视频的中间产物约 160 MB（原始 wav + 切块各一份），攒几次就是 GB 级。

**5. 首次使用者优先（v1.3.0）。** 任何失败都要给「人话原因 + 一行修复命令」，
绝不把 traceback 甩给用户；任何耗时步骤都要先说清楚要下多少、要等多久。
> 理由：第一次用的人没有上下文，一段 traceback 足以劝退；
> 而"进度条不动"若没提前说明，会被当成程序卡死直接 Ctrl+C。

| 依赖 | 检查/安装 |
|---|---|
| 全部依赖 | `python3 scripts/ensure_env.py`（幂等，缺什么装什么，不建 venv） |
| 只想检查不安装 | `python3 scripts/ensure_env.py --check`（退出码 0 = 齐备） |
| 排查问题 | `python3 scripts/ensure_env.py --doctor`（硬件/网络/依赖/模型/耗时预估） |

## 步骤 0 · 备齐环境（幂等，可跳过如已确认）

```bash
python3 scripts/ensure_env.py
```

## 步骤 1 · 下载音频（直取 dash 流，绕过 yt-dlp 风控）

```bash
python3 scripts/get_audio.py "<B站视频URL或BVid>" audio.wav
```

> 该脚本直接调 `playurl` API 取 dash 音频流，curl 下载后 ffmpeg 转 16k 单声道 wav。
> **不要用 yt-dlp 走网页**——必被 B 站风控拦截。

## 步骤 2 · 确保模型就绪（共享缓存，已有则秒过）

```bash
python3 scripts/setup_model.py --auto     # 按本机 CPU/磁盘自动选型（推荐）
python3 scripts/setup_model.py            # 默认 large-v3；已存在则直接复用
python3 scripts/setup_model.py --list     # 查看可选模型、占用与本机预计速度
python3 scripts/setup_model.py small      # 磁盘紧张时改用小模型
```

> 选型建议（`--auto` 已内置）：**8 核以上**才推荐 large-v3，4 核用 medium，2 核用 small。
> 核数不够硬上 large-v3，30 分钟视频要跑 1 小时，第一次用的人会以为程序死了。
> 下载失败会自动重试 3 次（指数退避），中断后重跑自动续传。

> 模型下载经验：**官方 HuggingFace 被墙；hf-mirror 重定向境外 CDN 大文件必断；ModelScope 直连最稳**。
> 默认 large-v3（3.1 GB，术语准确度最高）；空间不足时脚本会预检并提示降级到 medium/small/base。

## 步骤 3 · 切分长音频（自适应静音点 + 硬上限）

```bash
python3 scripts/split.py audio.wav chunks --rm-source
# 产出 chunks/cNNN.wav + chunks.json（每块含 start/end/dur/cut）
# --rm-source: 切完删掉原始整段 wav，省一半空间（切块已完整覆盖内容）
# 可调: --target 180 --max 300 --min 45
```

> **v1.2.0 起静音阈值是自适应的**：先测整段 `mean_volume`，再以「均值 −12dB」起步逐级放宽。
> 旧版写死 −30dB，遇到响度压得很满的视频（实测某视频 mean −19.2 dB）会**一个静音点都判不出**，
> 772 秒音频退化成 1 块，转写慢且无容错。切点取静音区间**中点**而非起点，不在语句余音处下刀。
> 无论如何都强制 `--max` 上限，找不到静音点就按时长硬切（`chunks.json` 里标记 `cut: hard`）。
>
> 时长 ≤ `--max` 时自动不切分，直接单块处理。

## 步骤 4 · 逐块转写（⚠️ 关键：前台串行，勿并行）

**先想一下这个视频是什么领域**，把关键术语通过 `-p` 传进去能显著降低误识别率
（例如把 "Claude Opus" 听成 "Cloud Fable"）。不传则用通用中文提示词。
（不确定传什么？先跑 `run.py --dry-run`，会按标题/简介建议该传的 `-p` 术语。）

> **线程数（v1.8.0 放宽）**：默认自动取 `min(核数-1, 16)`，多核机器不再锁死 8 核。
> 想降速/限资源可显式 `CPU_THREADS=4`。

**对每一个块索引 `i`，单独发起一次【前台】Bash 调用**（不要合并、不要并发多子进程）：

```bash
timeout 400 python3 scripts/transcribe_chunk.py i \
  -p "本视频涉及 大模型、注意力机制、MoE 等术语" --rm-chunk
```

用循环逐块执行（每块一次独立调用，跑完再跑下一块）：

```bash
for i in 0 1 2 3 4 5 6 7 8 9 10; do
  [ -f out_${i}.json ] && continue
  timeout 400 python3 scripts/transcribe_chunk.py $i --rm-chunk
done
```

> **长视频（>10min）优先单进程后台**：逐块前台在工具 600s 上限下会被迫转后台、管理易丢。
> 改用一条命令单进程后台（run.py 内部串行调度，进度自动续跑）：
>
> ```bash
> nohup python3 scripts/run.py "<url>" --keep > run.log 2>&1 &
> # 看进度：tail run.log  /  ps aux|grep run.py  /  查 .bili_<BV>/task.json
> ```

> 产出 `out_NNN.json`（时间已对齐原音频）。`--rm-chunk` 转完即删该块，边转边释放空间。
> 模型目录无需指定，脚本自动解析共享缓存。

## 步骤 5 · 合并（自动过滤幻觉）

```bash
python3 scripts/merge.py <块数量> /workspace
# 产出 /workspace/transcript_full.txt（带时间戳）与 transcript_plain.txt
python3 scripts/merge.py --keep-all        # 关闭过滤，保留原始全部段落
```

> **v1.2.0 起自动过滤 Whisper 幻觉**。块尾静音/纯 BGM 处，模型极易凭空生成
> "中文字幕提供 / 请点赞订阅 / 字幕由XX提供"等训练集字幕水印残留，且时间戳常越出块边界
> （实测某块只到 147.3s，幻觉段却标到 176.7s）。过滤三条规则：越界段、块首尾的黑名单短语、
> 相邻完全重复段。合并时会打印被过滤的内容供复核。

## 步骤 6 · 收尾清理（必做）

```bash
python3 scripts/cleanup.py                # 清中间产物，保留模型与最终产物
python3 scripts/cleanup.py --caches       # 顺带清 pip/下载缓存（可回收数 GB）
python3 scripts/cleanup.py --dry-run      # 不确定时先看会删什么
```

> 默认**不会**动 `/workspace` 的 `transcript_*.txt`，也**不会**删共享模型（留着下次复用）。
> 只有显式 `--deep` 才会删模型权重。

## 下一步

- 转写完成后建议做 **AI 校对（步骤 7）**：见 [proofread.md](./proofread.md)。
- 用户要求"进一步分析/总结"时按模板产出总结：见 [summary-template.md](./summary-template.md)。
- 全部踩坑铁律：见 [pitfalls.md](./pitfalls.md)。