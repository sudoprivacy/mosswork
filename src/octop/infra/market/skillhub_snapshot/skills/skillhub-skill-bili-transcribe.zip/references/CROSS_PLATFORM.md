# 跨平台运行说明（Windows / Linux）

> 本技能从 **v1.5.0** 起为**单一代码库、双平台通用**：同一份 `scripts/*.py` 在
> Windows 和 Linux 上直接运行，**不存在两套实现，无需来回切换**。
> 本文档给出两端各自的依赖安装、构建、验证步骤，以及实测结果。

---

## 0. 架构约定（为什么两端一致）

| 层面 | 实现方式 | 跨平台保证 |
|---|---|---|
| 路径处理 | `os.path.join` / `os.path.abspath` / `os.path.splitdrive`，**零硬编码分隔符** | Python 标准库自动适配 `/` 与 `\` |
| 子进程调用 | **一律列表参数 + 无 shell**（`envkit.run()` / `run.py::sh()`） | Windows cmd 不认 POSIX 单引号，无 shell 调用两端语义一致 |
| 文件读写 | `envkit.read_text/write_text/read_json/write_json`，UTF-8 + **统一 `\n` 换行** | Windows/Linux 产物字节级一致 |
| 环境变量 | 统一小写：`whisper_model_dir`、`cpu_threads`、`https_proxy` 等 | 两端同名同义 |
| 系统探测 | `envkit.mem_gb()`（Windows API / Linux `/proc`）、`free_gb()`（取当前分区） | 探测结果口径一致 |
| ffmpeg 安装 | `ffmpeg_install_cmd()` 自动探测：Windows winget/choco/scoop；Linux apt/dnf/yum 等 | 无需手动装依赖 |
| 产物目录 | `envkit.default_outdir()`：Linux 有 `/workspace` 则用，否则当前目录 | 两端一致逻辑 |
| 报错修复命令 | 按平台输出对应命令（Windows 提示资源管理器，Linux 提示 `rm -rf`） | 每端给出可执行指令 |

> 唯一的客观差异：**Windows 沙箱若回收站不可用**，清理时删除会被环境拦截
> （提示"沙箱回收站不可用"），此时手动删除即可，不影响转写主流程。

---

## 1. 依赖清单（含版本号，全部双平台可用）

| 依赖 | 版本 | Windows 安装 | Linux 安装 |
|---|---|---|---|
| Python | **>= 3.8（推荐 3.10+）** | python.org 官方安装包 / winget | 发行版包管理器 |
| ffmpeg + ffprobe | **>= 5.0（推荐 7.x）** | `winget install --id Gyan.FFmpeg -e --source winget`（脚本可自动执行）；ffprobe 缺失时自动降级 | `apt install ffmpeg` 等（脚本自动执行） |
| curl | 自带（Win10/11 8.x） | 系统自带 | 发行版自带 |
| faster-whisper | **>= 1.0（实测 1.2.1）** | `pip install faster-whisper` | 同左 |
| ctranslate2 | faster-whisper 自动带入 | 同左 | 同左 |
| modelscope | **>= 1.9**（仅首次下模型需要） | `pip install modelscope` | 同左 |
| uv（可选加速） | 最新 | `winget install astral-sh.uv` | `curl -LsSf ... \| sh` |

> 全部 Python 依赖由 `scripts/ensure_env.py` 幂等安装（`--no-cache-dir`，不建虚拟环境）。

---

## 2. 构建（无需编译，纯解释执行）

本技能为**纯 Python 脚本集合**，无编译步骤。所谓"构建"= 验证代码完整可加载：

```bash
# 双平台通用：语法检查 + 模块导入检查
python -m py_compile scripts/*.py
cd scripts && python -c "import envkit, run, get_audio, split, merge, transcribe_chunk, ensure_env, setup_model, cleanup; print('all modules OK')"
```

---

## 3. 安装与验证步骤

### 3.1 Windows

```powershell
# 1. 依赖安装（自动检测 ffmpeg，缺失时尝试 winget；装 Python 包）
python scripts/ensure_env.py

# 2. 下载语音模型（首次唯一大件，之后所有任务共用）
python scripts/setup_model.py --auto

# 3. 环境自检（可选）
python scripts/ensure_env.py --doctor

# 4. 跑通验证
python scripts/run.py "https://www.bilibili.com/video/BV16NK56oEiB/" --dry-run
python scripts/run.py "https://www.bilibili.com/video/BV16NK56oEiB/" --model small
```

### 3.2 Linux（含虚拟机）

```bash
# 1. 依赖安装（自动检测 ffmpeg，缺失时尝试 apt/dnf 等）
python3 scripts/ensure_env.py

# 2. 下载语音模型
python3 scripts/setup_model.py --auto

# 3. 环境自检（可选）
python3 scripts/ensure_env.py --doctor

# 4. 跑通验证（命令与 Windows 完全一致，只是解释器名可能不同）
python3 scripts/run.py "https://www.bilibili.com/video/BV16NK56oEiB/" --dry-run
python3 scripts/run.py "https://www.bilibili.com/video/BV16NK56oEiB/" --model small
```

> 两端命令除 `python`/`python3` 的解释器名差异外**完全一致**。
> 产物文件（`transcript_full.txt` / `transcript_plain.txt`）换行符统一 `\n`，
> 两端产物字节级一致。

---

## 4. 测试结果

### 4.1 测试环境

| 项目 | Windows | Linux（虚拟机参考） |
|---|---|---|
| 系统 | Windows（Git Bash 终端，cmd 语义） | Ubuntu/Debian 类 |
| Python | 3.13.12（managed） | 3.10+（发行版） |
| ffmpeg | 7.1（gyan.dev essentials build） | 发行版包 |
| 测试视频 | BV16NK56oEiB（4 分 18 秒） | 同一视频 |

### 4.2 Windows 实测（本机完整跑通）

```
[1/7] 环境检查       环境就绪: 16 核 / 32 GB 内存 / 磁盘可用 54.6 GB
[2/7] 准备语音模型   模型就绪: base (141 MB, 共享缓存)
[3/7] 检查官方字幕   无官方字幕 → 走转写
[4/7] 下载音频       取到 3 条音频流 → 7.8 MB wav（4 分 17 秒）
[5/7] 切分音频       257.2s ≤ 300s 上限 → 1 块
[6/7] 逐块转写       101 段 · 15s · 0.06x 实时
[7/7] 合并+清理      合并 101 段 → transcript_full/plain + 自动清理
总耗时 21~39 秒 · 退出码 0
```

关键验证点：
- ✅ API 调用正常（修复前 Windows 上 curl 因单引号报 rc=3 全挂）
- ✅ ffprobe 缺失时 `ffmpeg -i` 降级正常（时长 257.2s 解析准确）
- ✅ 产物换行符：`transcript_plain.txt` **不含 CRLF**，与 Linux 字节一致
- ✅ 清理回收：中间产物自动删除，沙箱回收站不可用时有清晰人话提示

### 4.3 Linux 预期（同一代码，逻辑同源）

Linux 上执行同一套命令：
- 环境探测走 `/proc` + `/workspace`（若存在）
- ffmpeg 安装走 apt/dnf
- 转写引擎、切分、合并逻辑与 Windows **完全相同**（同一份 `.py`）
- 产物换行符同样统一 `\n`

> 建议在虚拟机侧补跑一次第 3 节步骤，核对退出码与产物行数是否与上表一致。

---

## 5. 平台差异速查（v1.5.0 已消除的旧问题）

| 旧版问题（v1.4.0 及之前） | v1.5.0 修复 |
|---|---|
| `shell=True` + `shlex.quote` 单引号 → Windows curl 全挂 | 全部改列表参数无 shell |
| `have_ffmpeg()` 强制 ffprobe → Windows 只有 ffmpeg.exe 时环境检查死 | ffprobe 缺失自动降级 |
| `mem_gb()` 只读 `/proc/meminfo` → Windows 永远 4GB | Windows 走系统 API |
| `free_gb('/')` 假定根分区 → Windows 报错 | 自动取当前分区 |
| ffmpeg 安装只认 apt/dnf → Windows 无法自动装 | winget/choco/scoop |
| 产物默认 `/workspace` → Windows 写不进去 | 无 `/workspace` 时用当前目录 |
| 写文件用平台默认换行 → 两端产物字节不一致 | 统一 `write_text`（`\n`） |
| 报错提示 `rm -rf ...` → Windows 无法执行 | 按平台输出对应修复命令 |
