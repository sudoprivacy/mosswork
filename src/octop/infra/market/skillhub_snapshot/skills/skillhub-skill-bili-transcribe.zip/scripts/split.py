#!/usr/bin/env python3
"""
split.py — 把长音频切成若干块（默认每块约 3 分钟），优先在静音处下刀，绝不切出超长块。

经验: 单进程转写整段长音频极慢。切分后【逐块前台串行】转写最稳。
      （本沙箱并发转写反而更慢，且后台/进程池子进程会被回收）

用法:
    python3 split.py <输入wav> [块目录] [--rm-source]
                     [--target 180] [--max 300] [--min 45]

产出:
    chunks/cNNN.wav  +  chunks.json (含每块 start/end/dur/file/cut 切点类型)

v1.1.0: 新增 --rm-source，切分成功后删掉原始整段 wav，避免同一份音频存两份。
v1.2.0: 修复"高响度视频退化为单块"——
        1) 静音阈值改为【相对 mean_volume 自适应】并多级放宽，不再写死 -30dB；
        2) 切点取静音区间【中点】，不在语句余音处下刀；
        3) 强制块长上限：找不到合适静音点就按时长硬切，杜绝超长块拖垮转写。
v1.4.0: 文件路径统一 shlex.quote（shell 安全加固）；chunks.json 用 with+encoding 写出。
v1.5.0: 子进程调用全部改无 shell 列表参数（Windows cmd 不认 POSIX 单引号）。
        时长探测优先 ffprobe，缺失时降级 ffmpeg -i 解析（Windows 常见只有 ffmpeg.exe）。
"""
import sys, os, re, json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

TARGET = 180.0   # 理想块长 s
MAX_CHUNK = 300.0  # 块长硬上限 s
MIN_CHUNK = 45.0   # 块长下限 s（避免碎块）


def sh(cmd):
    """列表参数 → 无 shell；字符串 → shell（兼容旧调用）。"""
    return envkit.run(cmd, quiet=True)[1]


def probe_duration(wav):
    """ffprobe 优先，缺失时用 ffmpeg -i 解析 Duration。"""
    d = envkit.audio_duration(wav)
    if d <= 0:
        raise ValueError(f"无法解析音频时长: {wav}")
    return d


def mean_volume(wav):
    """整段平均响度，用于推算自适应静音阈值。"""
    rc, out = envkit.run(
        ["ffmpeg", "-i", wav, "-af", "volumedetect", "-f", "null", "-"],
        quiet=True)
    m = re.search(r"mean_volume:\s*(-?[0-9.]+) dB", out)
    return float(m.group(1)) if m else -25.0


def detect_silences(wav, thresh_db, min_sil):
    """返回静音区间中点列表。取中点比取 start 更安全，不会切到语句余音。"""
    rc, out = envkit.run(
        ["ffmpeg", "-i", wav,
         "-af", f"silencedetect=noise={thresh_db}dB:d={min_sil}",
         "-f", "null", "-"], quiet=True)
    starts, mids = [], []
    for line in out.splitlines():
        ms = re.search(r"silence_start:\s*(-?[0-9.]+)", line)
        if ms:
            starts.append(float(ms.group(1)))
            continue
        me = re.search(r"silence_end:\s*([0-9.]+)", line)
        if me and starts:
            st = starts[-1]
            en = float(me.group(1))
            mids.append((st + en) / 2.0)
    # 末尾静音未闭合时忽略即可
    return sorted(set(round(x, 3) for x in mids if x > 0))


def collect_candidates(wav, dur):
    """自适应多级放宽，直到候选切点足够覆盖全片。"""
    mv = mean_volume(wav)
    need = max(1, int(dur // TARGET))  # 至少需要这么多切点才可能均匀分块
    print(f"平均响度 {mv:.1f} dB，需要约 {need} 个切点")

    # 相对阈值：安静视频阈值自然低，高响度视频阈值自然高
    ladder = [
        (round(mv - 12, 1), 0.35),
        (round(mv - 8, 1), 0.30),
        (round(mv - 5, 1), 0.25),
        (round(mv - 3, 1), 0.20),
    ]
    best = []
    for th, d in ladder:
        th = max(-50.0, min(-8.0, th))
        c = detect_silences(wav, th, d)
        print(f"  阈值 {th} dB / {d}s -> 候选切点 {len(c)} 个")
        if len(c) > len(best):
            best = c
        if len(c) >= need * 2:  # 候选足够富余就不再放宽，避免切在轻微停顿上
            break
    return best


def pick_cuts(cands, dur):
    """贪心选点：优先离理想位置最近的静音点；范围内无静音点则硬切。"""
    cuts = [0.0]
    hard = set()
    last = 0.0
    while dur - last > MAX_CHUNK:
        lo, hi = last + MIN_CHUNK, last + MAX_CHUNK
        ideal = last + TARGET
        inrange = [c for c in cands if lo <= c <= hi]
        if inrange:
            pick = min(inrange, key=lambda c: abs(c - ideal))
        else:
            pick = min(ideal, hi)   # 兜底硬切，保证块长不失控
            hard.add(round(pick, 3))
        cuts.append(pick)
        last = pick
    # 收尾：剩余不足上限，直接并入最后一块；太短则并回上一块
    if dur - last < MIN_CHUNK and len(cuts) > 1:
        cuts.pop()
    cuts.append(dur)
    return cuts, hard


def main():
    argv = sys.argv[1:]
    if not argv:
        print(__doc__)
        sys.exit(1)
    rm_source = "--rm-source" in argv

    def opt(name, default):
        if name in argv:
            return float(argv[argv.index(name) + 1])
        return default

    global TARGET, MAX_CHUNK, MIN_CHUNK
    TARGET = opt("--target", TARGET)
    MAX_CHUNK = opt("--max", MAX_CHUNK)
    MIN_CHUNK = opt("--min", MIN_CHUNK)

    skip = set()
    for name in ("--target", "--max", "--min"):
        if name in argv:
            i = argv.index(name)
            skip.update({i, i + 1})
    pos = [a for i, a in enumerate(argv) if not a.startswith("--") and i not in skip]
    if not pos:
        print(__doc__)
        sys.exit(1)

    wav = pos[0]
    chunk_dir = pos[1] if len(pos) > 1 else "chunks"
    os.makedirs(chunk_dir, exist_ok=True)

    dur = probe_duration(wav)
    print(f"音频时长 {dur:.1f}s，目标块长 {TARGET:.0f}s / 上限 {MAX_CHUNK:.0f}s")

    if dur <= MAX_CHUNK:
        cuts, hard = [0.0, dur], set()
        print("时长在单块上限内，不切分")
    else:
        cands = collect_candidates(wav, dur)
        cuts, hard = pick_cuts(cands, dur)
        n_hard = len(hard)
        print(f"切成 {len(cuts)-1} 块（静音点 {len(cuts)-1-n_hard} 处，硬切兜底 {n_hard} 处）")

    meta = []
    for i in range(len(cuts) - 1):
        st, en = cuts[i], cuts[i + 1]
        cf = os.path.join(chunk_dir, f"c{i:03d}.wav")
        rc = envkit.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", wav,
             "-ss", f"{st:.3f}", "-to", f"{en:.3f}",
             "-ar", "16000", "-ac", "1", cf], quiet=True)[0]
        if rc == 0:
            meta.append({"idx": i, "file": cf, "start": st, "end": en,
                         "dur": en - st,
                         "cut": "hard" if round(en, 3) in hard else "silence"})
        else:
            print(f"[警告] 第 {i} 块切分失败，已跳过")

    envkit.write_json("chunks.json", meta)
    longest = max((m["dur"] for m in meta), default=0)
    print(f"完成: {len(meta)} 块 -> chunks.json（最长块 {longest:.1f}s）")

    if rm_source and len(meta) == len(cuts) - 1:
        try:
            mb = os.path.getsize(wav) / (1024 ** 2)
            os.remove(wav)
            print(f"已删除原始整段音频 {wav}（省 {mb:.0f} MB，内容已由切块完整覆盖）")
        except OSError as e:
            print(f"原始音频删除失败: {e}")


if __name__ == "__main__":
    main()
