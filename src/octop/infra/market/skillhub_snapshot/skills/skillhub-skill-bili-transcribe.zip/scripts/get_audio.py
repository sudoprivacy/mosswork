#!/usr/bin/env python3
"""
get_audio.py — 从 B 站视频直取音频并转 16k 单声道 wav

绕过 yt-dlp 网页风控：直接调 playurl API 取 dash 音频流，curl 下载后 ffmpeg 转码。
（不要用 yt-dlp 走网页，必被 B 站风控拦截。）

用法:
    python3 get_audio.py "<B站视频URL或BVid>" [输出wav路径]
    python3 get_audio.py "<URL>" audio.wav --page 2     # 多 P 视频选第 2 P
    python3 get_audio.py "<URL>" --info                 # 只看视频信息，不下载
    python3 get_audio.py "<URL>" --cookie "SESSDATA=xxx"  # 登录态（充电/会员专属视频）

支持 b23.tv 短链，会自动展开。
v1.4.0: 新增 --cookie（登录态）；下载后校验音频时长与接口声明是否一致（截断即报错）。
v1.5.0: 子进程调用全部改无 shell 列表参数（Windows cmd 不认 POSIX 单引号，
        shlex.quote 产物在 Windows 上必炸，实测 curl rc=3）。ffprobe 缺失时
        时长校验自动降级用 ffmpeg -i 解析。
"""
import io
import json
import os
import re
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")


def run(cmd):
    """统一执行入口: 列表参数 → 无 shell；字符串 → shell（不传单引号！）。

    Windows 关键: cmd.exe 不认 POSIX 单引号。凡是 curl/ffmpeg 调用，
    一律用列表参数 + 无 shell，绝对安全。
    """
    return envkit.run(cmd, quiet=True)


def curl(args, timeout=None):
    """带默认头的 curl 封装（列表参数，无 shell，跨平台安全）。"""
    cmd = ["curl", "-s", "-L", "--max-time", str(timeout or 20),
           "-H", f"User-Agent: {UA}"] + list(args)
    return run(cmd)


def preflight():
    """先检查工具链，别等下载完才发现没有 ffmpeg。"""
    if not shutil.which("curl"):
        envkit.die("缺少 curl（下载音频流需要）",
                   "安装后重试（Windows 可用 winget install curl）")
    if not envkit.have_ffmpeg():
        mgr, cmd = envkit.ffmpeg_install_cmd()
        envkit.die("缺少 ffmpeg（音频转码需要）",
                   cmd or "手动安装 ffmpeg: https://ffmpeg.org/download.html")


def expand_short_url(url):
    """b23.tv 短链 → 真实视频地址。"""
    if "b23.tv" not in url:
        return url
    rc, out = curl(["-I", "-A", UA, url])
    for line in out.splitlines():
        if line.lower().startswith("location:") and "BV" in line:
            return line.split(":", 1)[1].strip()
    return url


def parse_bvid(url):
    m = re.search(r"(BV[0-9A-Za-z]{10})", url)
    return m.group(1) if m else None


def api_json(api, referer=None, cookie=None):
    """调 B 站 API 并返回 data 字段。所有失败都翻译成人话。"""
    args = []
    if referer:
        args += ["-H", f"Referer: {referer}"]
    if cookie:
        args += ["-H", f"Cookie: {cookie}"]
    args += [api]
    rc, out = curl(args)
    if rc != 0 or not out.strip():
        envkit.die("连不上 B 站 API（网络不通或被拦截）",
                   "检查网络；若在公司网内可能需要代理: "
                   "export https_proxy=http://<代理>:<端口>")
    try:
        d = json.load(io.StringIO(out))
    except json.JSONDecodeError:
        envkit.die("B 站 API 返回的不是合法数据（可能被网络中间层劫持）",
                   "换个网络环境重试；或确认能正常访问 bilibili.com")
    if d.get("code") != 0:
        msg = d.get("message", "未知错误")
        code = d.get("code")
        hint = {
            -404: "视频不存在或已被删除",
            -403: "无访问权限（可能是充电专属/地区限制）",
            62002: "稿件不可见（可能已被 UP 主设为私密）",
            62004: "稿件审核中",
        }.get(code, msg)
        envkit.die(f"B 站接口拒绝了请求: {hint}（code={code}）",
                   "换一个可公开访问的视频链接试试")
    return d["data"]


def get_video_info(bvid, cookie=None):
    d = api_json(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}",
                 cookie=cookie)
    pages = d.get("pages") or [{"cid": d["cid"], "part": d.get("title", ""),
                                "duration": d.get("duration", 0)}]
    return {
        "title": d.get("title", ""),
        "owner": (d.get("owner") or {}).get("name", ""),
        "desc": d.get("desc", "") or "",
        "duration": d.get("duration", 0),
        "pages": pages,
    }


def get_audio_url(bvid, cid, cookie=None):
    api = (f"https://api.bilibili.com/x/player/playurl?bvid={bvid}&cid={cid}"
           f"&fnval=16&fnver=0&fourk=1")
    d = api_json(api, referer="https://www.bilibili.com/", cookie=cookie)
    dash = d.get("dash")
    if not dash or not dash.get("audio"):
        envkit.die("这个视频没有可用的 dash 音频流（可能是互动视频或付费内容）",
                   "换一个普通视频试试")
    audios = sorted(dash["audio"], key=lambda x: -x["bandwidth"])
    return audios[0]["baseUrl"], len(audios)


def get_cc_subtitle(bvid, cid, cookie=None):
    """查官方 CC 字幕（x/player/v2 的 subtitle 字段）。

    返回 (subtitle_url, lan) 或 (None, None)。无需 WBI 签名（实测可用）。
    有字幕的视频可以跳过整轮转写，直接拿官方字幕。
    """
    api = f"https://api.bilibili.com/x/player/v2?bvid={bvid}&cid={cid}"
    d = api_json(api, referer="https://www.bilibili.com/", cookie=cookie)
    subs = ((d.get("subtitle") or {}).get("subtitles")) or []
    if not subs:
        return None, None
    # 优先中文字幕；ai-zh 是 B 站自动生成，通常比人工的更完整
    ordered = sorted(subs, key=lambda s: (s.get("lan") != "zh-CN",
                                          s.get("lan") != "zh-Hans",
                                          s.get("lan") != "ai-zh"))
    best = ordered[0]
    return best.get("subtitle_url"), best.get("lan_doc") or best.get("lan")


def download_cc_subtitle(subtitle_url, out_dir, out_base="transcript"):
    """下载 CC 字幕 json 并转成 transcript_full/plain + srt。

    返回 (行数, 是否成功)；失败返回 (0, False)（调用方应回退到转写）。
    """
    if not subtitle_url:
        return 0, False
    if subtitle_url.startswith("//"):
        subtitle_url = "https:" + subtitle_url
    rc, out = curl([subtitle_url], timeout=30)
    if rc != 0 or not out.strip():
        return 0, False
    try:
        d = json.load(io.StringIO(out))
        body = d.get("body") or []
    except (json.JSONDecodeError, AttributeError):
        return 0, False
    if not body:
        return 0, False

    segs = [{"start": float(s.get("from", 0)), "end": float(s.get("to", 0)),
             "text": (s.get("content") or "").replace("\n", " ").strip()}
            for s in body if s.get("content")]
    segs = [s for s in segs if s["text"]]

    full = [f"[{int(s['start'])//60:02d}:{int(s['start'])%60:02d}-"
            f"{int(s['end'])//60:02d}:{int(s['end'])%60:02d}] {s['text']}"
            for s in segs]
    plain = [s["text"] for s in segs]
    envkit.write_text(os.path.join(out_dir, out_base + "_full.txt"),
                      "\n".join(full))
    envkit.write_text(os.path.join(out_dir, out_base + "_plain.txt"),
                      "\n".join(plain))

    # SRT 一并产出（官方字幕直接挂播放器最常用）
    from merge import write_srt
    write_srt(segs, os.path.join(out_dir, out_base + ".srt"))
    return len(plain), True


def main():
    argv = sys.argv[1:]
    if not argv:
        print(__doc__)
        return 1

    flags = {a for a in argv if a.startswith("--")}
    page = 1
    if "--page" in argv:
        i = argv.index("--page")
        if i + 1 < len(argv):
            page = int(argv[i + 1])
            argv = argv[:i] + argv[i + 2:]
    pos = [a for a in argv if not a.startswith("--")]

    url = pos[0]
    out_wav = pos[1] if len(pos) > 1 else "audio.wav"

    url = expand_short_url(url)
    bvid = parse_bvid(url)
    if not bvid:
        envkit.die(f"没能从链接里解析出 BV 号: {url}",
                   '传入含 BVxxxx 的完整链接，例如 '
                   '"https://www.bilibili.com/video/BV1xx411c7mD"')

    cookie = None
    if "--cookie" in argv:
        i = argv.index("--cookie")
        if i + 1 < len(argv):
            cookie = argv[i + 1]

    info = get_video_info(bvid, cookie=cookie)
    npages = len(info["pages"])
    print(f"标题: {info['title']}")
    print(f"UP主: {info['owner']}  ·  时长: "
          f"{envkit.fmt_duration(info['duration'])}"
          + (f"  ·  共 {npages} P" if npages > 1 else ""))

    if "--info" in flags:
        if npages > 1:
            for i, p in enumerate(info["pages"], 1):
                print(f"  P{i}: {p.get('part', '')} "
                      f"({envkit.fmt_duration(p.get('duration', 0))})")
        return 0

    preflight()

    if page < 1 or page > npages:
        envkit.die(f"分 P 序号 {page} 超出范围（该视频共 {npages} P）",
                   f"用 --page 1..{npages} 指定，或加 --info 查看分 P 列表")
    sel = info["pages"][page - 1]
    cid = sel["cid"]
    if npages > 1:
        print(f"选择 P{page}: {sel.get('part', '')}")

    os.makedirs(os.path.dirname(os.path.abspath(out_wav)) or ".", exist_ok=True)

    base_url, naud = get_audio_url(bvid, cid, cookie=cookie)
    print(f"取到 {naud} 条音频流，下载最高码率...")

    m4s = out_wav + ".m4s"
    dargs = ["-H", f"Referer: https://www.bilibili.com/video/{bvid}/",
             "-H", "Origin: https://www.bilibili.com"]
    if cookie:
        dargs += ["-H", f"Cookie: {cookie}"]
    dargs += ["-o", m4s, base_url]
    rc, _ = curl(dargs, timeout=600)
    if rc != 0 or not os.path.exists(m4s) or os.path.getsize(m4s) < 1000:
        envkit.die("音频流下载失败（可能是网络中断或防盗链变更）",
                   "重跑一次；持续失败请检查网络", code=3)

    print(f"转码 16k 单声道 -> {out_wav}")
    rc, log = run(["ffmpeg", "-y", "-loglevel", "error",
                   "-i", m4s, "-ar", "16000", "-ac", "1", out_wav])
    if rc != 0:
        envkit.die(f"ffmpeg 转码失败: {log[-300:]}",
                   "确认 ffmpeg 可用: ffmpeg -version", code=4)

    # v1.4.0: 音频完整性校验 —— 转码后时长应与接口声明一致（截断=网络问题）
    expect = sel.get("duration") or info["duration"]
    actual = envkit.audio_duration(out_wav) or 0
    if expect and actual:
        dev = abs(actual - expect) / expect
        if dev > 0.10:
            print(f"⚠ 音频时长 {actual:.0f}s 与接口声明 {expect:.0f}s "
                  f"偏差 {dev*100:.0f}%，可能下载被截断")
            print("  建议重跑一次；若反复出现请检查网络稳定性。")

    sz = os.path.getsize(out_wav) / (1024 ** 2)
    print(f"完成: {out_wav} ({sz:.1f} MB)")

    try:
        os.remove(m4s)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
