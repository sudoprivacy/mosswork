#!/usr/bin/env python3
"""
envkit.py — 共用环境 / 共享缓存 / 硬件感知 的公共工具模块

设计原则（重要，其他脚本请一并遵守）:
  1. **绝不创建虚拟环境**。不 venv、不 virtualenv、不 conda create。
     技能一律复用宿主机/沙箱已有的 Python 解释器。理由: 一个 venv 里
     faster-whisper + ctranslate2 + torch 依赖动辄 1-3 GB，每个技能各建
     一份是纯粹的空间浪费，且与宿主已装好的包重复。
  2. **模型权重放共享缓存目录**，不放技能私有目录。多个技能/多次任务复用同一份。
  3. **pip 一律 --no-cache-dir**。实测未加时 ~/.cache/pip 能涨到 5 GB+。
  4. (v1.3.0) **首次使用者优先**: 任何失败都要给"人话原因 + 一行修复命令"，
     绝不把 traceback 直接甩给用户；任何耗时步骤都要先给出时间/空间预期。
  5. (v1.5.0) **跨平台（Windows / Linux）**: 子进程调用一律走**无 shell 的
     列表参数**（subprocess.run(list)），绝不拼 shell 字符串 —— Windows 的
     cmd.exe 不认 POSIX 单引号，shlex.quote 的产物在 Windows 上必炸
     （实测 curl 直接 rc=3）。所有"路径/时长/内存/磁盘"探测都有 Windows 分支。
"""
import os
import re
import shlex
import shutil
import subprocess
import sys

IS_WINDOWS = os.name == "nt"

# ---------------------------------------------------------------- 依赖版本表（跨平台）
# 所有依赖均有 Windows/Linux 双平台版本；版本号在本表集中登记，便于审计。
#   python      : >= 3.8（推荐 3.10+）                —— 双平台官方安装包
#   faster-whisper: >= 1.0, 实测 1.2.1                —— PyPI 双平台 wheel
#   ctranslate2  : faster-whisper 自带依赖            —— PyPI 双平台 wheel
#   modelscope   : >= 1.9（仅首次下模型需要）          —— PyPI 双平台 wheel
#   ffmpeg       : >= 5.0（推荐 7.x）                 —— Windows: winget Gyan.FFmpeg
#                                                     / 手动下载 gyan.dev builds；
#                                                     Linux: 发行版包管理器
#   curl         : Windows 10/11 自带 8.x；Linux 各发行版自带
#   python -m pip: 随 python 自带（Windows 用 py -m pip）

# ---------------------------------------------------------------- 模型规格表
# size_gb : 磁盘占用估算(GB)，用于下载前预检
# rtf8    : 在 8 线程 CPU 上的实时率(耗时/音频时长)，用于预估转写时间
# note    : 给首次使用者看的一句话取舍说明
#
# v1.4.0 校准: rtf8 依据真实转写实测回调（此前偏保守 2-5 倍，用户按预估
# 会以为要等很久而放弃）。实测值来自 small/base 在 8 线程 CPU 的 RTF；
# run.py 会在首块转写后用实测 RTF 覆盖静态预估，更准。
MODELS = {
    "large-v3": {"repo": "pengzhendong/faster-whisper-large-v3", "size_gb": 3.1,
                 "rtf8": 0.8, "note": "准确度最高，术语/英文缩写识别最好"},
    "medium":   {"repo": "pengzhendong/faster-whisper-medium",   "size_gb": 1.6,
                 "rtf8": 0.35, "note": "准确度与速度平衡，日常够用"},
    "small":    {"repo": "pengzhendong/faster-whisper-small",    "size_gb": 0.6,
                 "rtf8": 0.15, "note": "快且省，专有名词误识略多"},
    "base":     {"repo": "pengzhendong/faster-whisper-base",     "size_gb": 0.2,
                 "rtf8": 0.08, "note": "最轻量，仅适合试跑/听大意"},
}

MODEL_ORDER = ["large-v3", "medium", "small", "base"]

# v1.0.0 使用过的私有路径，保留探测以便老用户复用、不重复下载。
# 必须按模型名归属: 曾有 bug —— 用户明确要下 small，却因为这里存在
# large-v3 的旧目录而被告知"已存在"，结果加载了 3 GB 的大模型，
# 在小机器上直接卡死。旧路径只能顶替**同名**模型。
LEGACY_DIRS_BY_MODEL = {
    "large-v3": ["/root/whisper-large-v3",
                 os.path.join(os.path.expanduser("~"), ".cache",
                              "whisper-models", "large-v3")],
}
# 兼容旧引用: 扁平列表（仅用于"本机有没有任何可用权重"这类模糊查询）
LEGACY_DIRS = [d for ds in LEGACY_DIRS_BY_MODEL.values() for d in ds]

# 各发行版包管理器的 ffmpeg 安装命令（首个可用者生效）
PKG_MANAGERS = [
    ("apt-get", "{sudo}apt-get update -qq && {sudo}apt-get install -y ffmpeg"),
    ("dnf",     "{sudo}dnf install -y ffmpeg"),
    ("yum",     "{sudo}yum install -y ffmpeg"),
    ("zypper",  "{sudo}zypper install -y ffmpeg"),
    ("pacman",  "{sudo}pacman -S --noconfirm ffmpeg"),
    ("apk",     "{sudo}apk add ffmpeg"),
    ("brew",    "brew install ffmpeg"),          # brew 不用 sudo
]

# Windows 包管理器（winget 优先，Win10/11 自带）
WIN_PKG_MANAGERS = [
    ("winget", "winget install --id Gyan.FFmpeg -e --source winget"),
    ("choco",  "choco install ffmpeg -y"),
    ("scoop",  "scoop install ffmpeg"),
]

MIN_PY = (3, 8)


# ---------------------------------------------------------------- 跨平台执行
def q(s) -> str:
    """跨平台 shell 引用: POSIX 用单引号，Windows cmd 用双引号。

    仅当确实需要 shell=True 时才用。优先用 run()/run_list() 的无 shell 列表。
    """
    s = str(s)
    if not IS_WINDOWS:
        return shlex.quote(s)
    # cmd.exe 里双引号内的双引号用 \" 转义
    return '"' + s.replace('"', '\\"') + '"'


def run(cmd, quiet: bool = False, timeout: int = None):
    """执行命令。

    - cmd 为**列表** → 无 shell，跨平台最安全（推荐，v1.5.0 起全部调用方应改列表）
    - cmd 为**字符串** → 本机默认 shell（POSIX sh / Windows cmd），仅在确实需要
      shell 特性（管道/重定向）时使用，且**不要混入 shlex.quote 的单引号**

    输出统一按 UTF-8 解码（容错），避免 Windows GBK 控制台导致乱码/解码崩溃。
    """
    if isinstance(cmd, (list, tuple)):
        r = subprocess.run(list(cmd), capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
    else:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout)
    out = (r.stdout or "") + (r.stderr or "")
    if not quiet and r.returncode != 0:
        print(f"[cmd failed] {cmd}\n{out[-800:]}")
    return r.returncode, out


# ---------------------------------------------------------------- 路径与模型
def shared_cache_root() -> str:
    """共享缓存根目录。默认 ~/.local/whisper-models；
    可用 $BILI_MODEL_CACHE 覆盖根目录，$WHISPER_MODEL_DIR/$MODEL_DIR 覆盖单个模型目录。"""
    base = os.environ.get("BILI_MODEL_CACHE") or os.path.join(
        os.path.expanduser("~"), ".local")
    return os.path.join(base, "whisper-models")


def resolve_model_dir(name: str = "large-v3", for_download: bool = False) -> str:
    """解析模型目录，优先级:
       1) $WHISPER_MODEL_DIR / $MODEL_DIR 显式指定
       2) 共享缓存 ~/.local/whisper-models/<name>（已存在）
       3) 旧版私有路径（已存在则直接复用，避免重复下载 3 GB）
       4) for_download=True 时返回共享缓存路径作为落地点
    """
    explicit = os.environ.get("WHISPER_MODEL_DIR") or os.environ.get("MODEL_DIR")
    if explicit:
        return explicit

    shared = os.path.join(shared_cache_root(), name)
    if is_model_ready(shared):
        return shared

    # v2.0.1: 旧版缓存位置 ~/.cache/whisper-models 迁移兼容（任意模型名，
    # 只复用同名模型，绝不用 large-v3 顶替用户要的 small）
    legacy = os.path.join(os.path.expanduser("~"), ".cache",
                          "whisper-models", name)
    if is_model_ready(legacy):
        return legacy

    # 只复用**同名**模型的旧路径，绝不用 large-v3 顶替用户要的 small
    for d in LEGACY_DIRS_BY_MODEL.get(name, []):
        if is_model_ready(d):
            return d

    if for_download:
        return shared
    # 都不存在时也返回共享路径，让调用方给出明确的"请先下载"提示
    return shared


def list_ready_models():
    """列出本机所有可用模型 [(name, dir), ...]，按质量从高到低排序。"""
    found = {}
    for name in MODEL_ORDER:
        d = os.path.join(shared_cache_root(), name)
        if is_model_ready(d):
            found.setdefault(name, d)
    for name, dirs in LEGACY_DIRS_BY_MODEL.items():
        for d in dirs:
            if is_model_ready(d):
                found.setdefault(name, d)
    return [(n, found[n]) for n in MODEL_ORDER if n in found]


def any_model_ready():
    """返回本机**质量最好**的已就绪模型 (name, dir)，没有则 (None, None)。

    必须按质量排序，不能按目录扫描顺序: 曾有 bug —— 机器上同时存在
    large-v3(旧路径) 和 base(共享缓存)，结果自动选了 base，
    首次使用者拿到的转写质量莫名其妙地差。
    """
    explicit = os.environ.get("WHISPER_MODEL_DIR") or os.environ.get("MODEL_DIR")
    if explicit and is_model_ready(explicit):
        return "custom", explicit
    ready = list_ready_models()
    return ready[0] if ready else (None, None)


def is_model_ready(d: str) -> bool:
    """faster-whisper 需要 model.bin 才算可用。"""
    return bool(d) and os.path.isfile(os.path.join(d, "model.bin"))


# ---------------------------------------------------------------- 硬件与预估
def cpu_count() -> int:
    try:
        return len(os.sched_getaffinity(0))     # 尊重 cgroup/taskset 限制
    except AttributeError:
        return os.cpu_count() or 2


def mem_gb() -> float:
    """物理内存(GB)。Linux 读 /proc/meminfo；Windows 用 GlobalMemoryStatusEx。

    注意: 不读 cgroup memory.max —— 实测它可能是某子 cgroup 的局部限制
    （曾误显示 8GB，实际 126GB），据此降配置纯属自找麻烦。
    """
    if IS_WINDOWS:
        try:
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            m = MEMORYSTATUSEX()
            m.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                return m.ullTotalPhys / (1024 ** 3)
        except Exception:                       # noqa: BLE001
            pass
        return 4.0
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) / (1024 ** 2)
    except OSError:
        pass
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / (1024 ** 3)
    except (ValueError, OSError, AttributeError):
        return 4.0


def suggest_threads() -> int:
    """转写线程数（v1.8.0 放宽上限）。

    int8 CPU 转写：8 线程后边际递减，16 为甜点；封顶 16 防内存抖动与
    多核机器上的调度开销。旧版硬锁 8 核，32 核机器白浪费一半多核。
    留一核给系统/IO，单核机器退化为 1。
    """
    n = cpu_count()
    if n <= 1:
        return 1
    return min(n - 1, 16)


def estimate_rtf(model: str = "large-v3", threads: int = None) -> float:
    """预估实时率(耗时 ÷ 音频时长)。线程越少越慢，按 8 线程基准线性缩放。"""
    threads = threads or suggest_threads()
    base = MODELS.get(model, MODELS["large-v3"])["rtf8"]
    return base * (8.0 / max(1, threads)) ** 0.7


def fmt_duration(sec: float) -> str:
    sec = max(0, int(sec))
    if sec < 60:
        return f"{sec} 秒"
    if sec < 3600:
        return f"{sec // 60} 分 {sec % 60} 秒"
    return f"{sec // 3600} 小时 {(sec % 3600) // 60} 分"


# 推荐某模型所需的最低 CPU 核数。
# 依据: large-v3 在 8 线程下约 1.0 倍实时，核数减半耗时接近翻倍。
# 首次使用者宁可"快点看到结果"，也不要盯着 1 小时不动的进度条，
# 所以核数不足时主动降档，而不是硬推最强模型。
MIN_CORES = {"large-v3": 8, "medium": 4, "small": 2, "base": 1}


def recommend_model(audio_sec: float = None) -> tuple:
    """按可用磁盘 + CPU 推荐模型，返回 (模型名, 理由)。

    首次使用者最容易犯的错: 4 核笔记本上直接上 large-v3，
    12 分钟视频跑 40 分钟，以为程序卡死了。
    """
    avail = free_gb(shared_cache_root())
    cores = cpu_count()

    # 已经下过的优先用，别让人再等一次下载
    ready_name, _ = any_model_ready()
    if ready_name and ready_name != "custom":
        return ready_name, f"本地已有 {ready_name} 权重，直接复用（省去重新下载）"

    for name in MODEL_ORDER:
        need = MODELS[name]["size_gb"] * 1.25
        disk_ok = avail >= need
        cpu_ok = cores >= MIN_CORES[name]
        if not (disk_ok and cpu_ok):
            continue

        reason = f"磁盘可用 {avail:.1f} GB、{cores} 核 CPU"
        if name != MODEL_ORDER[0]:
            # 说明为什么没给最强的那个
            blocked_by_disk = avail < MODELS[MODEL_ORDER[0]]["size_gb"] * 1.25
            if blocked_by_disk:
                reason += "；磁盘装不下 large-v3，选它更稳"
            else:
                reason += f"；核数少于 {MIN_CORES[MODEL_ORDER[0]]}，用 large-v3 会慢到让人以为卡死"
        est = estimate_rtf(name, min(8, max(1, cores - 1)))
        reason += f"（预计 {est:.1f} 倍实时）"
        return name, reason

    return "base", (f"磁盘仅剩 {avail:.1f} GB / {cores} 核，只能用最小模型；"
                    "建议先清理空间: python3 scripts/cleanup.py --caches")


# ---------------------------------------------------------------- 磁盘
def free_gb(path: str = None) -> float:
    """目标路径所在分区的可用空间(GB)。Windows/Linux 通用。

    Windows 上不能直接把 '/' 交给 disk_usage（会解析成当前盘根，若传的是
    不存在的路径要逐级向上找；盘符根在 Windows 会死循环 dirname）。
    盘符根统一用 os.path.splitdrive + os.sep 拼，不硬编码 '\\'。
    """
    target = os.path.abspath(path) if path else os.getcwd()
    seen = set()
    while target not in seen and not os.path.exists(target):
        seen.add(target)
        parent = os.path.dirname(target)
        if parent == target:
            break
        target = parent
    if not os.path.exists(target):
        drive, _ = os.path.splitdrive(target)
        target = (drive + os.sep) if IS_WINDOWS and drive else os.sep
    try:
        usage = shutil.disk_usage(target)
        return usage.free / (1024 ** 3)
    except OSError:
        return 0.0


def dir_size_mb(path: str) -> float:
    if not os.path.exists(path):
        return 0.0
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            fp = os.path.join(root, f)
            try:
                total += os.path.getsize(fp)
            except OSError:
                pass
    return total / (1024 ** 2)


# ---------------------------------------------------------------- 统一 IO（跨平台换行符）
def read_text(path: str) -> str:
    """读文本，UTF-8，换行符归一化为 \\n（Windows 写的 CRLF 也能读）。"""
    with open(path, "r", encoding="utf-8", newline=None) as f:
        return f.read()


def write_text(path: str, text: str, newline: str = "\n") -> None:
    """写文本，UTF-8，统一用 \\n 换行 —— Windows/Linux 产物完全一致。

    不传 newline=None（即不依赖平台默认），保证两端 transcript 文件字节级一致。
    """
    with open(path, "w", encoding="utf-8", newline=newline) as f:
        f.write(text)


def read_json(path: str):
    import json
    return json.loads(read_text(path))


def write_json(path: str, obj, indent: int = 1) -> None:
    import json
    write_text(path, json.dumps(obj, ensure_ascii=False, indent=indent))


# ---------------------------------------------------------------- 默认产物目录
def default_outdir() -> str:
    """默认产物目录，跨平台统一：
    - Linux 沙箱若有 /workspace 用 /workspace（历史约定）
    - 否则（含 Windows）用当前工作目录
    """
    if not IS_WINDOWS and os.path.isdir("/workspace"):
        return "/workspace"
    return os.getcwd()


# ---------------------------------------------------------------- 音频时长
def audio_duration(wav: str) -> float:
    """取音频时长（秒）。优先 ffprobe；没有 ffprobe（Windows 常见只有
    ffmpeg.exe）时降级用 `ffmpeg -i` 解析 stderr 里的 Duration 行。
    失败返回 0。
    """
    if not wav or not os.path.isfile(wav):
        return 0.0
    ffprobe = shutil.which("ffprobe")
    if ffprobe:
        try:
            r = subprocess.run(
                [ffprobe, "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", wav],
                capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=60)
            v = float(r.stdout.strip())
            if v > 0:
                return v
        except (ValueError, OSError, subprocess.SubprocessError):
            pass
    # 降级: ffmpeg -i 解析 Duration: HH:MM:SS.xx
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return 0.0
    try:
        r = subprocess.run([ffmpeg, "-i", wav, "-f", "null", "-"],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=60)
        m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)",
                      (r.stderr or "") + (r.stdout or ""))
        if m:
            h, mi, s = m.groups()
            return int(h) * 3600 + int(mi) * 60 + float(s)
    except (ValueError, OSError, subprocess.SubprocessError):
        pass
    return 0.0


# 兼容旧引用（部分脚本直接 import 过 audio_duration_ffprobe）
def audio_duration_ffprobe(wav: str) -> float:
    return audio_duration(wav)


# ---------------------------------------------------------------- 环境探测
def in_virtualenv() -> bool:
    """当前解释器是否已处在某个 venv/conda 中。

    注意: 返回 True 时我们**复用**它，而不是再建一个。
    """
    return (hasattr(sys, "real_prefix")
            or sys.prefix != getattr(sys, "base_prefix", sys.prefix)
            or bool(os.environ.get("CONDA_PREFIX")))


def python_ok() -> bool:
    return sys.version_info >= MIN_PY


def have_module(mod: str) -> bool:
    import importlib.util
    try:
        return importlib.util.find_spec(mod) is not None
    except (ImportError, ValueError):
        return False


def have_ffmpeg() -> bool:
    """ffmpeg 是否可用。

    v1.5.0 放宽: 不再强制要求 ffprobe 同存 —— Windows 上常见只装了
    ffmpeg.exe（如 pip 装的 static build），ffprobe 缺失时
    audio_duration() 会自动降级用 ffmpeg -i 解析时长。
    """
    return bool(shutil.which("ffmpeg"))


def sudo_prefix() -> str:
    """非 root 且有 sudo 时返回 'sudo '，否则空串。"""
    try:
        is_root = os.geteuid() == 0
    except AttributeError:      # 非 POSIX
        is_root = False
    if is_root:
        return ""
    return "sudo " if shutil.which("sudo") else ""


def ffmpeg_install_cmd():
    """返回 (包管理器名, 安装命令)；没有已知包管理器时返回 (None, 说明)。

    Windows: winget/choco/scoop 依次探测；都没有时给手动安装指引。
    """
    if IS_WINDOWS:
        for mgr, tpl in WIN_PKG_MANAGERS:
            if shutil.which(mgr):
                return mgr, tpl
        return None, ("Windows 上可在 PowerShell 执行: "
                      "winget install --id Gyan.FFmpeg -e --source winget"
                      "（或从 https://www.gyan.dev/ffmpeg/builds/ 下载后把 "
                      "bin 目录加入 PATH）")
    sudo = sudo_prefix()
    for mgr, tpl in PKG_MANAGERS:
        if shutil.which(mgr):
            return mgr, tpl.format(sudo=sudo)
    return None, None


def check_url(url: str, timeout: int = 6) -> bool:
    """轻量连通性探测。只判断"能不能连上"，不下载内容。"""
    import urllib.error
    import urllib.request
    req = urllib.request.Request(
        url, method="HEAD",
        headers={"User-Agent": "Mozilla/5.0 (compatible; bili-transcribe)"})
    try:
        urllib.request.urlopen(req, timeout=timeout)
        return True
    except (urllib.error.URLError, OSError):
        # 有些站点拒绝 HEAD，退化成 GET 只读一小段
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "Mozilla/5.0 (compatible; bili-transcribe)"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                r.read(1)
            return True
        except (urllib.error.URLError, OSError):
            return False


# ---------------------------------------------------------------- 执行与安装
def pip_install(pkgs, quiet: bool = True):
    """安装到**当前解释器所在环境**，永不新建 venv，且永不留 pip 缓存。

    优先 uv（快且默认不膨胀缓存），回退到 pip。
    返回 (成功?, 失败时的原始输出) —— 首次使用者需要看到真实报错，不能吞。
    """
    if isinstance(pkgs, str):
        pkgs = [pkgs]
    last = ""

    if shutil.which("uv"):
        rc, out = run(["uv", "pip", "install", "--system", "--no-cache",
                       *(("-q",) if quiet else ())] + list(pkgs), quiet=True)
        if rc == 0:
            return True, ""
        last = out

    py = sys.executable or "python3"
    # --no-cache-dir 是硬性要求: 实测缺失时 pip 缓存可膨胀到 5 GB
    rc, out = run([py, "-m", "pip", "install", "--no-cache-dir",
                   *(("-q",) if quiet else ())] + list(pkgs), quiet=True)
    if rc == 0:
        return True, ""
    last = out

    if "externally-managed-environment" in out:
        rc, out = run([py, "-m", "pip", "install", "--no-cache-dir",
                       "--break-system-packages",
                       *(("-q",) if quiet else ())] + list(pkgs), quiet=True)
        if rc == 0:
            return True, ""
        last = out
    return False, last


# ---------------------------------------------------------------- 人话输出
def human(mb: float) -> str:
    return f"{mb/1024:.2f} GB" if mb >= 1024 else f"{mb:.0f} MB"


def die(reason: str, fix: str = "", code: int = 1):
    """统一的失败出口: 一句人话原因 + 一行可直接复制的修复命令。

    严禁把 traceback 甩给用户 —— 第一次用的人根本不知道从哪看起。
    """
    print(f"\n✗ {reason}", file=sys.stderr)
    if fix:
        print(f"  → 修复方法: {fix}", file=sys.stderr)
    sys.exit(code)


def tip(msg: str):
    print(f"  · {msg}")


def banner(title: str):
    print("=" * 60)
    print(f" {title}")
    print("=" * 60)
