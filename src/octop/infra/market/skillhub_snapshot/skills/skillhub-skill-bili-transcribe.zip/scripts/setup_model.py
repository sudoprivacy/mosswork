#!/usr/bin/env python3
"""
setup_model.py — 下载 faster-whisper 模型权重到【共享缓存】

这是首次使用唯一的大件下载，全流程只需做一次，之后所有任务/技能共用。

要点:
  * 模型统一落到共享缓存 ~/.local/whisper-models/<name>，跨任务、跨技能复用
  * 已存在（含 v1.0.0 的 /root/whisper-large-v3）则直接复用，不重复下载
  * 下载前磁盘预检，空间不足时提示降级而不是把盘写满
  * 下载后清掉 ModelScope 的重复缓存副本（否则同一模型占两份）
  * (v1.3.0) 断网/超时自动重试；中断后重跑自动续传；失败给人话原因而非 traceback

经验: 官方 HuggingFace 被墙；hf-mirror 重定向境外 CDN 大文件必断；ModelScope 直连最稳。

用法:
    python3 setup_model.py                 # 默认 large-v3
    python3 setup_model.py --auto          # 按本机 CPU/磁盘自动选（首次推荐用这个）
    python3 setup_model.py small           # 指定模型
    python3 setup_model.py --list          # 查看可选模型与占用
    python3 setup_model.py --where         # 只打印当前会用哪个模型目录
"""
import os
import shutil
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

DEFAULT_NAME = "large-v3"
SAFETY_RATIO = 1.25      # 需要 模型大小 * 该系数 的可用空间
MAX_RETRY = 3            # 大文件下载偶发断流，自动重试


def cmd_list():
    threads = envkit.suggest_threads()
    print(f"{'模型':<10} {'占用':<8} {'本机预计速度':<14} 说明")
    print("-" * 74)
    for name, info in envkit.MODELS.items():
        d = os.path.join(envkit.shared_cache_root(), name)
        mark = " [已下载]" if envkit.is_model_ready(d) else ""
        rtf = envkit.estimate_rtf(name, threads)
        speed = f"{rtf:.2f}x 实时"
        print(f"{name:<10} {info['size_gb']:<8.1f} {speed:<14} {info['note']}{mark}")
    print("-" * 74)
    print(f"（速度按本机 {envkit.cpu_count()} 核 / {threads} 线程估算，"
          f"0.5x 实时 = 10 分钟视频转 5 分钟）")
    for d in envkit.LEGACY_DIRS:
        if envkit.is_model_ready(d):
            print(f"\n发现旧版私有目录（会被自动复用）: {d} "
                  f"({envkit.human(envkit.dir_size_mb(d))})")


def cleanup_modelscope_cache():
    """ModelScope 部分版本会在 hub 缓存里再留一份完整副本，删掉省一倍空间。"""
    candidates = [
        os.path.join(os.path.expanduser("~"), ".cache", "modelscope", "hub"),
        os.environ.get("MODELSCOPE_CACHE", ""),
    ]
    freed = 0.0
    for c in candidates:
        if c and os.path.isdir(c):
            mb = envkit.dir_size_mb(c)
            if mb > 50:      # 只清明显是权重副本的
                shutil.rmtree(c, ignore_errors=True)
                freed += mb
    if freed:
        print(f"已清理 ModelScope 重复缓存，回收 {envkit.human(freed)}")
    return freed


def download_with_retry(repo, out, size_gb):
    """带重试的下载。ModelScope 自带断点续传，重跑不会从头再来。"""
    from modelscope import snapshot_download

    for attempt in range(1, MAX_RETRY + 1):
        if attempt > 1:
            wait = 5 * (2 ** (attempt - 2))      # 5s, 10s
            print(f"\n第 {attempt}/{MAX_RETRY} 次尝试（{wait}s 后开始，"
                  f"已下载部分会续传，不会从头再来）...")
            time.sleep(wait)
        t0 = time.time()
        try:
            snapshot_download(repo, local_dir=out)
            if envkit.is_model_ready(out):
                got = envkit.dir_size_mb(out)
                cost = time.time() - t0
                speed = got / cost if cost > 0 else 0
                print(f"\n下载完成: {envkit.human(got)}，"
                      f"耗时 {envkit.fmt_duration(cost)}"
                      + (f"（平均 {speed:.1f} MB/s）" if speed else ""))
                return True, ""
            # 下完了但没有 model.bin，属于仓库结构异常
            return False, "下载完成但未找到 model.bin，可能是模型仓库结构变化"
        except KeyboardInterrupt:
            print("\n已中断。已下载的部分保留着，重跑本命令会自动续传。")
            sys.exit(130)
        except Exception as ex:                  # noqa: BLE001
            msg = f"{type(ex).__name__}: {ex}"
            print(f"  第 {attempt} 次失败: {msg[:200]}")
            last = msg
    return False, last


def explain_failure(err):
    """把异常翻译成首次使用者能看懂的原因 + 对策。"""
    low = err.lower()
    if any(k in low for k in ("timeout", "timed out", "connection", "ssl",
                              "network", "resolve", "unreachable")):
        return ("网络连不上 ModelScope（大文件下载对网络比较敏感）",
                "换个网络或配代理后重跑同一命令（会自动续传）: "
                "export https_proxy=http://<代理>:<端口>")
    if "no space" in low or "disk" in low:
        return ("磁盘空间不足",
                "清理后重试: python3 scripts/cleanup.py --caches")
    if "permission" in low:
        return ("没有写入权限",
                f"换个可写目录: export WHISPER_MODEL_DIR=$HOME/whisper-models")
    if "not found" in low or "404" in low:
        return ("模型仓库地址不可用（可能已变更）",
                "先看看可选列表: python3 scripts/setup_model.py --list")
    return ("模型下载失败", "重跑同一命令会自动续传；若持续失败可改用小模型: "
                          "python3 scripts/setup_model.py small")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = {a for a in sys.argv[1:] if a.startswith("--")}

    if "--list" in flags:
        cmd_list()
        return 0

    # --- 选模型 ---
    if "--auto" in flags and not args:
        name, reason = envkit.recommend_model()
        print(f"自动选型: {name}  （{reason}）")
    else:
        name = args[0] if args else DEFAULT_NAME

    if name not in envkit.MODELS:
        envkit.die(f"未知模型 {name}",
                   f"可选: {', '.join(envkit.MODELS)}；"
                   "或用 --auto 让脚本按本机配置自动选")

    out = args[1] if len(args) > 1 else envkit.resolve_model_dir(
        name, for_download=True)

    if "--where" in flags:
        print(out)
        return 0

    # --- 复用检查: 已有就不重复下载 ---
    existing = envkit.resolve_model_dir(name)
    if envkit.is_model_ready(existing):
        print(f"模型已存在，直接复用（未重复下载）: {existing}")
        print(f"占用 {envkit.human(envkit.dir_size_mb(existing))}")
        print("\n可以直接开始转写了:")
        print('  python3 scripts/run.py "<B站视频链接>"')
        return 0

    ready_other, other_dir = envkit.any_model_ready()
    if ready_other:
        print(f"提示: 本机已有 {ready_other} 模型（{other_dir}）。")
        print(f"      若只是想先跑起来，可以直接用它，无需再下 {name}。\n")

    # --- 下载前把预期讲清楚 ---
    info = envkit.MODELS[name]
    need = info["size_gb"] * SAFETY_RATIO
    avail = envkit.free_gb(os.path.dirname(out) or "/")
    threads = envkit.suggest_threads()

    envkit.banner(f"首次准备: 下载 {name} 语音模型（只需一次）")
    print(f"目标目录  : {out}")
    print(f"下载大小  : 约 {info['size_gb']} GB")
    print(f"磁盘预检  : 需要 ~{need:.1f} GB，可用 {avail:.1f} GB")
    print(f"模型特点  : {info['note']}")
    print(f"转写速度  : 本机约 {envkit.estimate_rtf(name, threads):.2f} 倍实时"
          f"（{threads} 线程）")
    print("耗时说明  : 取决于网速，百兆宽带约几分钟；中途断了重跑会自动续传")
    print("-" * 60)

    if avail < need:
        smaller = [n for n, i in envkit.MODELS.items()
                   if i["size_gb"] * SAFETY_RATIO < avail]
        envkit.die(
            f"磁盘空间不足（需要 {need:.1f} GB，只剩 {avail:.1f} GB）",
            (f"改用更小的模型: python3 scripts/setup_model.py {smaller[-1]}"
             if smaller else
             "先清理磁盘: python3 scripts/cleanup.py --caches"),
            code=2)

    # --- 依赖 ---
    if not envkit.have_module("modelscope"):
        print("安装 modelscope（--no-cache-dir，不留缓存）...")
        ok, err = envkit.pip_install("modelscope")
        if not ok:
            print(err[-600:])
            envkit.die("modelscope 安装失败（没有它就没法下载模型）",
                       f"手动执行: {sys.executable} -m pip install "
                       "--no-cache-dir modelscope", code=3)

    # --- 下载前先探一下网，别让人白等 ---
    if not envkit.check_url("https://www.modelscope.cn"):
        envkit.die(
            "连不上 ModelScope（下载模型的源站）",
            "检查网络或设置代理后重试: export https_proxy=http://<代理>:<端口>",
            code=5)

    repo = info["repo"]
    print(f"开始下载 {name}（{repo}）")
    print("（进度由 ModelScope 输出；大文件阶段可能长时间无新行，属正常）\n")
    os.makedirs(out, exist_ok=True)

    ok, err = download_with_retry(repo, out, info["size_gb"])
    if not ok:
        reason, fix = explain_failure(err)
        envkit.die(reason, fix, code=4)

    cleanup_modelscope_cache()
    print(f"\n模型就绪: {out} ({envkit.human(envkit.dir_size_mb(out))})")
    print("该目录为共享缓存，后续任务/其他技能会自动复用，无需重复下载。")
    print("\n下一步，直接跑一个视频:")
    print('  python3 scripts/run.py "<B站视频链接>"')
    return 0


if __name__ == "__main__":
    sys.exit(main())
