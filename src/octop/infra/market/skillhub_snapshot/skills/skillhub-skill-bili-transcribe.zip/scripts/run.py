#!/usr/bin/env python3
"""
run.py — 一条命令跑完整个流程（首次使用请从这里开始）

    python3 scripts/run.py "https://www.bilibili.com/video/BVxxxxxxxxx"

它会自动依次完成: 环境检查 → 模型准备 → 下载音频 → 切分 → 逐块转写 → 合并 → 清理。
中途任何时候中断（Ctrl+C / 超时 / 断网），**重跑同一条命令即可续跑**，
已完成的块不会重来。

常用选项:
    --model NAME     指定模型 large-v3/medium/small/base（默认按本机配置自动选）
    --prompt TEXT    本视频的领域术语，能显著降低专名误识别率
    --outdir DIR     最终产物目录（默认 /workspace，不存在则用当前目录）
    --workdir DIR    中间文件目录（默认 ./.bili_<BV号>）
    --page N         多 P 视频选第 N P
    --budget SEC     本次最多运行多少秒，到点优雅退出并保存进度（给自动化用）
    --keep           保留中间文件，不自动清理
    --dry-run        只做检查和预估，不真正开跑
    --language LANG  转写语言: zh/en/ja/...（默认 zh；英文视频请传 en）
    --beam-size N    Whisper 束搜索宽度（默认 5；调高更准更慢，调低更快）
    --srt            额外输出 SRT/VTT 字幕（可直接挂播放器）
    --fix-dict SPEC  可选后处理词典，修正误识别。可重复或逗号组合：
                     oss        → 内置开源通用错别字词典（dicts/oss_zh.json，走词边界护栏）
                     path.json  → 你的自有词库
                     例: --fix-dict oss,my.json（通用层在前，自有词库在后）
    --cookie SESSDATA  显式传 B 站登录态（优先级最高）。不传时自动解析：
                       环境变量 BILI_SESSDATA > ~/.bili-transcribe/config.json
                       > 本机浏览器 CDP(:9222)；全落空则游客模式继续

给自动化/Agent 的提示:
    加 --budget 480 可以避免单次调用超过工具超时上限；
    退出码 75 表示"预算用尽但进度已保存"，重复执行同一命令直到返回 0 即可。
"""
import glob
import json
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

SCRIPTS = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable or "python3"
EXIT_BUDGET = 75          # 预算用尽（进度已保存，重跑即续）

# 行缓冲: 否则本进程的 print 会被缓冲，而子进程输出直接落终端，
# 用户看到的步骤顺序会前后错乱，非常困惑。
try:
    sys.stdout.reconfigure(line_buffering=True)
except AttributeError:
    pass


# ------------------------------------------------------------------ 工具
def sh(cmd, cwd=None):
    """前台执行并实时透传输出（仅接受列表参数，无 shell）。

    v1.5.0: 跨平台铁律 —— Windows cmd 不认 POSIX 单引号，所有子进程
    调用一律列表参数 + 无 shell，两端行为完全一致。
    """
    if not isinstance(cmd, (list, tuple)):
        raise TypeError("sh() 只接受列表参数（无 shell），禁止传 shell 字符串")
    return subprocess.run(list(cmd), cwd=cwd).returncode


def step(n, total, title):
    print()
    print("─" * 60)
    print(f"[{n}/{total}] {title}")
    print("─" * 60)


def parse_args(argv):
    opts = {"model": None, "prompt": None, "outdir": None, "workdir": None,
            "page": 1, "budget": 0, "keep": False, "dry": False,
            "language": "zh", "beam": 5, "srt": False, "fix_dict": [],
            "cookie": None}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--model" and i + 1 < len(argv):
            opts["model"] = argv[i + 1]; i += 2
        elif a in ("--prompt", "-p") and i + 1 < len(argv):
            opts["prompt"] = argv[i + 1]; i += 2
        elif a == "--outdir" and i + 1 < len(argv):
            opts["outdir"] = argv[i + 1]; i += 2
        elif a == "--workdir" and i + 1 < len(argv):
            opts["workdir"] = argv[i + 1]; i += 2
        elif a == "--page" and i + 1 < len(argv):
            opts["page"] = int(argv[i + 1]); i += 2
        elif a == "--budget" and i + 1 < len(argv):
            opts["budget"] = float(argv[i + 1]); i += 2
        elif a == "--language" and i + 1 < len(argv):
            opts["language"] = argv[i + 1]; i += 2
        elif a == "--beam-size" and i + 1 < len(argv):
            opts["beam"] = int(argv[i + 1]); i += 2
        elif a == "--fix-dict" and i + 1 < len(argv):
            # 支持 --fix-dict oss,my.json 与重复 --fix-dict，统一收集为列表
            opts["fix_dict"].append(argv[i + 1]); i += 2
        elif a == "--cookie" and i + 1 < len(argv):
            opts["cookie"] = argv[i + 1]; i += 2
        elif a == "--keep":
            opts["keep"] = True; i += 1
        elif a == "--dry-run":
            opts["dry"] = True; i += 1
        elif a == "--srt":
            opts["srt"] = True; i += 1
        elif a.startswith("-"):
            envkit.die(f"未知选项: {a}", "查看用法: python3 scripts/run.py")
        else:
            pos.append(a); i += 1
    return opts, pos


def audio_duration(wav):
    return envkit.audio_duration(wav)


# v1.8.0: dry-run 轻量领域识别 → 建议该传的 -p 术语，降低后续校对成本。
# 仅做关键词命中，不引入模型；命中即打印建议，未命中不打扰。
_DOMAIN_HINTS = [
    ("AI / 大模型", ["大模型", "人工智能", "机器学习", "深度学习", "agent", "llm",
                     "gpt", "deepseek", "推理", "微调", "训练", "神经网络", "transformer"],
     "DeepSeek、ChatGPT、大模型、Agent、MoE、Transformer、微调、推理、token"),
    ("编程 / 开发", ["python", "代码", "编程", "开发", "函数", "接口", "源码",
                    "docker", "git", "前端", "后端", "算法"],
     "Python、函数、API、Git、Docker、变量、类、异步、编译"),
    ("金融 / 财报", ["财报", "营收", "利润", "毛利率", "股票", "基金", "估值",
                    "现金流", "持仓", "财报电话会"],
     "营收、毛利率、现金流、EPS、估值、持仓、环比、同比"),
    ("医学 / 健康", ["医学", "临床", "诊断", "症状", "药物", "剂量", "受体",
                    "疾病", "治疗"],
     "症状、诊断、临床、剂量、受体、靶点"),
    ("汽车 / 硬件", ["汽车", "续航", "电池", "电机", "底盘", "扭矩", "芯片",
                    "硬件", "手机"],
     "扭矩、续航、电池、底盘、电机、芯片、制程"),
]


def suggest_prompt_terms(text):
    """返回建议的 -p 术语串（命中领域时）；无命中返回空串。"""
    low = (text or "").lower()
    for _name, keys, terms in _DOMAIN_HINTS:
        if any(k.lower() in low for k in keys):
            return terms
    return ""


# ------------------------------------------------------------------ 各阶段
def stage_env():
    """快速体检。只在真缺东西时才啰嗦。"""
    problems = []
    if not envkit.python_ok():
        envkit.die(f"Python 版本过低（需要 >= {'.'.join(map(str, envkit.MIN_PY))}）",
                   "换更高版本解释器执行")
    if not envkit.have_ffmpeg():
        problems.append("ffmpeg")
    if not envkit.have_module("faster_whisper"):
        problems.append("faster-whisper")
    if problems:
        print(f"缺少依赖: {', '.join(problems)} —— 自动安装中"
              f"（复用当前环境，不建虚拟环境）...")
        rc = sh([PY, os.path.join(SCRIPTS, "ensure_env.py")])
        if rc != 0 or not envkit.have_ffmpeg() or \
                not envkit.have_module("faster_whisper"):
            envkit.die("依赖没能自动装齐",
                       "按上面的提示手动处理，然后重跑本命令")
    else:
        print(f"环境就绪: {envkit.cpu_count()} 核 / "
              f"{envkit.mem_gb():.0f} GB 内存 / "
              f"磁盘可用 {envkit.free_gb():.1f} GB")


def stage_model(want):
    """确保有可用模型；没有就自动下载（首次使用的大件，只做一次）。"""
    if want:
        if want not in envkit.MODELS:
            envkit.die(f"未知模型 {want}",
                       f"可选: {', '.join(envkit.MODELS)}")
        mdir = envkit.resolve_model_dir(want)
        if envkit.is_model_ready(mdir):
            print(f"模型就绪: {want}  {mdir}"
                  f"  ({envkit.human(envkit.dir_size_mb(mdir))})")
            return want, mdir
        print(f"指定的 {want} 尚未下载，开始下载（只需一次）...")
        if sh([PY, os.path.join(SCRIPTS, "setup_model.py"), want]) != 0:
            envkit.die(f"{want} 模型准备失败", "看上面的提示处理后重跑")
        mdir = envkit.resolve_model_dir(want)
        if not envkit.is_model_ready(mdir):
            # 绝不静默回退到别的模型: 用户指定了什么就必须用什么
            envkit.die(f"{want} 下载后仍不可用: {mdir}",
                       f"重试: python3 scripts/setup_model.py {want}")
        return want, mdir

    name, mdir = envkit.any_model_ready()
    if name:
        print(f"模型就绪: {name}  {mdir}"
              f"  ({envkit.human(envkit.dir_size_mb(mdir))})")
        return name, mdir

    rec, reason = envkit.recommend_model()
    print(f"首次使用，需要下载语音模型（之后所有任务共用，不会重复下载）")
    print(f"  自动选择: {rec}  —— {reason}")
    if sh([PY, os.path.join(SCRIPTS, "setup_model.py"), rec]) != 0:
        envkit.die("模型下载失败", "看上面的提示处理后重跑本命令（会续传）")
    return rec, envkit.resolve_model_dir(rec)


def stage_audio(url, workdir, page, cookie=None):
    wav = os.path.join(workdir, "audio.wav")
    if os.path.isfile(wav) and os.path.getsize(wav) > 10000:
        dur = audio_duration(wav)
        print(f"音频已存在，跳过下载（{envkit.fmt_duration(dur)}）")
        return wav, dur
    cmd = [PY, os.path.join(SCRIPTS, "get_audio.py"), url, wav]
    if page != 1:
        cmd += ["--page", str(page)]
    if cookie:
        cmd += ["--cookie", cookie]
    if sh(cmd) != 0:
        envkit.die("音频下载失败", "看上面的提示处理后重跑")
    return wav, audio_duration(wav)


def stage_split(wav, workdir):
    meta_path = os.path.join(workdir, "chunks.json")
    if os.path.isfile(meta_path):
        meta = envkit.read_json(meta_path)
        print(f"切分清单已存在，跳过（{len(meta)} 块）")
        return meta
    if sh([PY, os.path.join(SCRIPTS, "split.py"), "audio.wav", "chunks"],
          cwd=workdir) != 0:
        envkit.die("音频切分失败", "确认 ffmpeg 可用: ffmpeg -version")
    return envkit.read_json(meta_path)


def stage_transcribe(meta, workdir, model_name, model_dir, prompt, budget,
                     t_start, language="zh", beam=5):
    """逐块串行转写。模型只加载一次（比每块起一个进程快得多）。

    model_dir 必须显式传入并透传给 load_model —— 曾有 bug: 这里只传了
    model_name，load_model 自己去解析默认模型，结果用户 --model base
    却实际加载了 large-v3，小机器上直接 OOM 或慢到无法忍受。
    """
    import transcribe_chunk as tc

    todo = [i for i in range(len(meta))
            if not os.path.isfile(os.path.join(workdir, f"out_{i:03d}.json"))]
    done_cnt = len(meta) - len(todo)
    if not todo:
        print(f"全部 {len(meta)} 块此前已转写完成，跳过")
        return True

    todo_sec = sum(meta[i]["dur"] for i in todo)
    rtf = envkit.estimate_rtf(model_name)
    est_total = todo_sec * rtf
    print(f"待转写 {len(todo)}/{len(meta)} 块 · "
          f"音频 {envkit.fmt_duration(todo_sec)} · "
          f"预计耗时 {envkit.fmt_duration(est_total)}"
          f"（beam={beam} · {language}）")
    if done_cnt:
        print(f"（已完成 {done_cnt} 块，本次接着跑）")

    # 预算合理性预警: 最小执行单位是"一块"，预算小于单块耗时也至少会跑完一块。
    if budget:
        biggest = max(meta[i]["dur"] for i in todo) * rtf
        if budget < biggest:
            print(f"⚠ 预算 {envkit.fmt_duration(budget)} 小于单块预计耗时 "
                  f"{envkit.fmt_duration(biggest)}；"
                  f"本次至少会跑完一块才能保存进度。")
            print(f"  建议预算 ≥ {envkit.fmt_duration(biggest * 1.3)}，"
                  f"或改用更小的模型 / 更小的 --max 块长。")
    print()

    cwd0 = os.getcwd()
    os.chdir(workdir)
    try:
        model = tc.load_model(model_dir=model_dir, quiet=False)
        measured = None          # 实测实时率，比预估准
        last_tail = None         # 上一块末尾文本，作为下一块的上下文
        for n, i in enumerate(todo, 1):
            # 预算检查: 预计跑完这块会不会超时。
            # 首块也要判断——只是无论如何都得跑完一块，否则永远没有进度。
            if budget:
                used = time.time() - t_start
                pred = meta[i]["dur"] * (measured or rtf)
                if used + pred > budget and (n > 1 or used >= budget):
                    left = [j for j in todo[todo.index(i):]]
                    print(f"\n⏸ 时间预算用尽（已用 {envkit.fmt_duration(used)}）。"
                          f"还剩 {len(left)} 块未转写。")
                    print("  进度已保存，重跑同一条命令即可继续。")
                    return False

            pct = (n + done_cnt - 1) / len(meta) * 100
            print(f"▸ 块 {i}  ({n}/{len(todo)} 本次 · 总进度 {pct:.0f}%)")
            prev_tail = last_tail if n > 1 else None
            _n, cost, dur = tc.transcribe_one(
                model, meta, i, prompt=prompt, rm_chunk=True,
                language=language, beam_size=beam, prev_tail=prev_tail)
            if _n > 0:
                # 记录本块末尾文本，作为下一块的上下文（块边界保持术语一致）
                p = os.path.join(workdir, f"out_{i:03d}.json")
                if os.path.isfile(p):
                    rows = envkit.read_json(p)
                    last_tail = " ".join(r["text"] for r in rows[-2:])[-160:]
            if cost > 0 and dur > 0:
                measured = cost / dur
                rest = [j for j in todo[todo.index(i) + 1:]]
                if rest:
                    eta = sum(meta[j]["dur"] for j in rest) * measured
                    print(f"  剩余 {len(rest)} 块，预计还要 "
                          f"{envkit.fmt_duration(eta)}"
                          f"（实测 {measured:.2f}x 实时，已按实测修正预估）")
    except KeyboardInterrupt:
        print("\n已中断。进度已保存，重跑同一条命令可继续。")
        sys.exit(130)
    finally:
        os.chdir(cwd0)
    return True


def stage_merge(workdir, outdir, srt=False, fix_dicts=None):
    n = len(glob.glob(os.path.join(workdir, "out_*.json")))
    args = ["--srt"] if srt else []
    for spec in (fix_dicts or []):
        args += ["--fix-dict", spec]
    cmd = [PY, os.path.join(SCRIPTS, "merge.py"), str(n),
           os.path.abspath(outdir)] + args
    if sh(cmd, cwd=workdir) != 0:
        envkit.die("合并失败", "检查工作目录下的 out_*.json 是否完整")


def stage_cleanup(workdir, keep):
    if keep:
        print(f"已保留中间文件: {workdir}")
        return
    sh([PY, os.path.join(SCRIPTS, "cleanup.py"), "--dir", workdir])
    try:
        os.rmdir(workdir)
    except OSError:
        pass


# ------------------------------------------------------------------ 主流程
def main():
    opts, pos = parse_args(sys.argv[1:])
    if not pos:
        print(__doc__)
        return 1
    url = pos[0]
    t_start = time.time()

    # 短链要先展开再取 BV 号，否则工作目录会退化成通用名，
    # 跑第二个视频时可能复用上一个视频的音频，转写出完全错的内容。
    import get_audio as ga
    url = ga.expand_short_url(url)
    bv = ga.parse_bvid(url) or ""
    if not bv:
        envkit.die(f"没能从链接解析出 BV 号: {url}",
                   '传入含 BVxxxx 的完整链接，例如 '
                   '"https://www.bilibili.com/video/BV1xx411c7mD"')
    # v1.8.0: BV 号格式校验（手滑/复制截断会被提前拦下，给出人话）
    if not re.fullmatch(r"BV[0-9A-Za-z]{10}", bv):
        envkit.die(f"解析出的 BV 号格式异常: {bv}（应为 BV + 10 位字母/数字）",
                   '传入标准 BV 号链接，例如 '
                   '"https://www.bilibili.com/video/BV1xx411c7mD"')

    # 分 P 视频每个 P 独立目录，避免互相覆盖
    tag = bv if opts["page"] == 1 else f"{bv}_p{opts['page']}"
    workdir = opts["workdir"] or os.path.abspath(f".bili_{tag}")
    # 默认产物目录统一走 envkit.default_outdir()（Linux 有 /workspace 则用，否则当前目录）
    outdir = opts["outdir"] or envkit.default_outdir()
    os.makedirs(workdir, exist_ok=True)
    os.makedirs(outdir, exist_ok=True)

    envkit.banner("B站视频听译 · 一键流程")
    print(f"视频     : {url}")
    print(f"中间目录 : {workdir}")
    print(f"产物目录 : {outdir}")

    # v2.0.0: 登录态自动解析（CLI --cookie > 环境变量 > 配置文件 > 本机浏览器 CDP），
    # 全部落空则游客模式继续 —— 云端沙箱与首次使用零门槛。三层细节见 bili_config.py。
    if not opts["cookie"]:
        import bili_config as bcfg
        cookie, src = bcfg.resolve_auto_cookie()
        if cookie:
            opts["cookie"] = cookie
            print(f"🔑 登录态已自动获取（{src}），AI 字幕/会员视频可用")
        elif not bcfg.config_exists():
            print("\n[首次使用] 当前为游客模式：官方 CC 字幕可用时直取，其余走本地 Whisper 转写。")
            print("  想让 AI 字幕也自动直取（长视频可跳过整轮转写）？两种方式二选一：")
            print("    1) 本机浏览器已登录 B 站 → 保持调试实例运行即可自动读取（默认 127.0.0.1:9222）")
            print('    2) python3 scripts/bili_config.py set-cookie "SESSDATA=xxxxxxxx"')
            print("  不配置也完全可以，本任务继续以游客模式执行...\n")

    if opts["budget"]:
        print(f"时间预算 : {envkit.fmt_duration(opts['budget'])}"
              f"（到点会保存进度并退出，重跑即续）")

    # v1.4.0: 任务元数据落盘 —— 中断后即使忘了原始命令，
    # 看 .bili_<BV>/task.json 就知道怎么续跑。
    task = {"url": url, "bvid": bv, "page": opts["page"],
            "model": opts["model"], "prompt": opts["prompt"],
            "language": opts["language"], "beam": opts["beam"],
            "outdir": outdir, "command": " ".join(sys.argv),
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S")}
    try:
        envkit.write_json(os.path.join(workdir, "task.json"), task)
    except OSError:
        pass

    TOTAL = 7
    step(1, TOTAL, "环境检查")
    stage_env()

    step(2, TOTAL, "准备语音模型")
    model_name, model_dir = stage_model(opts["model"])

    if opts["dry"]:
        # dry-run 不下载，只用 API 拿时长做预估
        info = ga.get_video_info(bv)
        sel = info["pages"][min(opts["page"], len(info["pages"])) - 1]
        dur = sel.get("duration") or info["duration"]
        rtf = envkit.estimate_rtf(model_name)
        print(f"标题: {info['title']}")
        print(f"音频时长 {envkit.fmt_duration(dur)}，"
              f"预计转写耗时 {envkit.fmt_duration(dur * rtf)}"
              f"（{model_name} · {envkit.suggest_threads()} 线程）")
        # v1.8.0: 轻量领域识别 → 建议该传的 -p 术语，降低后续校对成本
        hint = suggest_prompt_terms(info.get("title", "") + " " + info.get("desc", ""))
        if hint:
            print(f"💡 建议传 -p 提升专名识别: -p \"{hint}\"")
        # dry-run 顺带提示是否可用官方字幕（省去整轮转写）
        cid2 = sel["cid"]
        sub_url, lan = ga.get_cc_subtitle(bv, cid2, cookie=opts["cookie"])
        if sub_url:
            print(f"🎬 该视频有官方字幕（{lan}），实际运行时将直接使用字幕，"
                  f"无需转写！")
        print("\n--dry-run: 检查与预估完成，未下载、未转写。")
        return 0

    step(3, TOTAL, "检查官方字幕（有则省去整轮转写）")
    info = ga.get_video_info(bv)
    sel = info["pages"][min(opts["page"], len(info["pages"])) - 1]
    cid = sel["cid"]
    sub_url, lan = ga.get_cc_subtitle(bv, cid, cookie=opts["cookie"])
    if sub_url:
        print(f"发现官方字幕（{lan}），直接下载使用，跳过转写")
        n_lines, ok = ga.download_cc_subtitle(sub_url, outdir)
        if ok:
            print(f"字幕已保存: {n_lines} 行 "
                  f"-> {outdir}/transcript_full.txt / transcript_plain.txt / .srt")
            cost = time.time() - t_start
            print(f"\n总耗时: {envkit.fmt_duration(cost)}（无需转写）")
            return 0
        print("字幕下载失败，回退到音频转写")

    step(4, TOTAL, "下载音频")
    wav, dur = stage_audio(url, workdir, opts["page"], cookie=opts["cookie"])
    rtf = envkit.estimate_rtf(model_name)
    print(f"音频时长 {envkit.fmt_duration(dur)}，"
          f"预计转写耗时 {envkit.fmt_duration(dur * rtf)}"
          f"（{model_name} · {envkit.suggest_threads()} 线程）")

    step(5, TOTAL, "切分音频")
    meta = stage_split(wav, workdir)

    step(6, TOTAL, "逐块转写（CPU 密集，请耐心）")
    finished = stage_transcribe(meta, workdir, model_name, model_dir,
                                opts["prompt"], opts["budget"], t_start,
                                language=opts["language"], beam=opts["beam"])
    if not finished:
        print(f"\n继续执行:\n  {' '.join(sys.argv)}")
        return EXIT_BUDGET

    step(7, TOTAL, "合并全文并清理")
    stage_merge(workdir, outdir, srt=opts["srt"], fix_dicts=opts["fix_dict"])
    stage_cleanup(workdir, opts["keep"])

    cost = time.time() - t_start
    print()
    envkit.banner("完成")
    print(f"总耗时: {envkit.fmt_duration(cost)}")
    for f in ("transcript_full.txt", "transcript_plain.txt"):
        p = os.path.join(outdir, f)
        if os.path.isfile(p):
            print(f"  {p}  ({os.path.getsize(p)//1024} KB)")
    print()
    print("💡 下一步（可选）：以上是机器直出稿，ASR 对专有名词误识率较高。")
    print("   如需 AI 校对（专名还原/同音字/标点/术语统一），直接对 WorkBuddy 说：")
    print("   「校对这份转录稿」，即可产出 transcript_proofread_plain.txt 与校对说明。")
    print(f"\n磁盘可用: {envkit.free_gb():.1f} GB"
          f"（模型已缓存复用，下次跑不用再下）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
