#!/usr/bin/env python3
"""
merge.py — 合并所有 out_NNN.json 为完整转录稿，并过滤 Whisper 常见幻觉段。

用法:
    python3 merge.py [块数量或自动探测] [输出目录] [--keep-all]
    python3 merge.py . --srt            # 额外输出 SRT/VTT 字幕（可直接挂播放器）
    python3 merge.py . --fix-dict d.json          # 可选后处理: 按词典替换误识别词
    python3 merge.py . --fix-dict oss             # 仅用内置开源通用错别字词典
    python3 merge.py . --fix-dict oss,my.json     # 通用层 + 自有词库（可重复 --fix-dict）

产出:
    transcript_full.txt   带时间戳 [mm:ss-mm:ss] 每段一行
    transcript_plain.txt  纯文本（无时间戳）
    transcript.srt        可选: SRT 字幕
    transcript.vtt        可选: VTT 字幕

v1.2.0: 新增幻觉过滤（--keep-all 可关闭）。Whisper 在块尾静音/纯 BGM 处极易
        凭空生成"字幕by/请点赞订阅/中文字幕提供"等训练集残留文本，且时间戳
        常越出块边界。过滤规则:
        1) 时间戳超出该块 chunks.json 声明的 end（+1s 容差）→ 丢弃；
        2) 命中幻觉短语黑名单且该段处于块首尾 → 丢弃；
        3) 与前一段完全重复的文本 → 丢弃。
v1.4.0: 统一 with/encoding 处理文件；新增 --srt / --fix-dict（可选后处理词典）。
"""
import sys, os, re, json, glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

# 开源通用纠错词典（v1.8.0）：仅 --fix-dict oss 显式调用，不默认启用。
# 收录常见错别字，技术专名仍归 -p/LLM（见 SKILL.md 两层分立原则）。
OSS_DICT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "..", "dicts", "oss_zh.json")

# CJK 统一表意文字区（用于词边界判定，避免单字误识嵌在长词里误伤）
_CJK = "一-鿿"


def is_cjk(ch):
    return bool(ch) and "一" <= ch <= "鿿"


def resolve_fix_dicts(specs):
    """把 --fix-dict 的多个取值（可逗号组合）解析为 [(label, path), ...]。

    - 关键字 `oss` → 内置通用纠错词典 dicts/oss_zh.json
    - 其它 → 视为文件路径
    顺序保留：oss 在前、用户词库在后（通用层高置信先跑，专名交给 -p/LLM）。
    """
    out = []
    if not specs:
        return out
    for spec in specs:
        for tok in str(spec).split(","):
            tok = tok.strip()
            if not tok:
                continue
            if tok == "oss":
                out.append(("oss", OSS_DICT))
            else:
                out.append((tok, tok))
    return out

# 训练集残留高频幻觉（字幕组水印、平台口播），仅在块首尾位置生效，避免误杀正文
HALLUCINATION = [
    "字幕", "中文字幕", "字幕由", "字幕提供", "翻译由", "小编", "打赏",
    "请不吝点赞", "点赞", "订阅", "转发", "打赏支持明镜", "明镜与点点栏目",
    "谢谢观看", "感谢观看", "感谢收看", "下次再见", "本视频由",
    "MING PAO CANADA", "MING PAO TORONTO", "Amara.org", "字幕志愿者",
]


def load_json(path):
    """统一读 JSON（UTF-8，跨平台换行符归一化）。"""
    return envkit.read_json(path)


def fmt_srt_ts(sec):
    """秒 → SRT 时间戳 HH:MM:SS,mmm。"""
    ms = int(round(sec * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def fmt_vtt_ts(sec):
    return fmt_srt_ts(sec).replace(",", ".")


def write_srt(segs, path):
    envkit.write_text(path, "".join(
        f"{i}\n{fmt_srt_ts(s['start'])} --> "
        f"{fmt_srt_ts(s['end'])}\n{s['text']}\n\n"
        for i, s in enumerate(segs, 1)))


def write_vtt(segs, path):
    envkit.write_text(path, "WEBVTT\n\n" + "".join(
        f"{fmt_vtt_ts(s['start'])} --> "
        f"{fmt_vtt_ts(s['end'])}\n{s['text']}\n\n" for s in segs))


def apply_fix_dict(segs, fix_path, boundary=False):
    """可选后处理: 按词典 {误词: 正确词} 做子串替换。

    - boundary=True（开源通用层用）：单字误识仅当**不被其它 CJK 字夹住**时
      才替换（词边界护栏），防止嵌在长词里误伤（如「深」不会误改「深圳」）；
      多字条目按普通子串替换。
    - boundary=False（用户自建词库用）：直接子串替换，尊重使用者意图。
    只处理明确指出的词，不做全局硬编码——避免把"正确词"误改成别的。
    词典 JSON 示例: {"避缓": "闭环", "所死": "锁死"}
    """
    if not fix_path:
        return segs, 0
    if not os.path.exists(fix_path):
        print(f"  ⚠ 词典文件不存在: {fix_path}（跳过替换）")
        return segs, 0
    try:
        fix = json.loads(envkit.read_text(fix_path))
    except (json.JSONDecodeError, OSError):
        print(f"  ⚠ 词典 {fix_path} 不是合法 JSON（跳过替换）")
        return segs, 0
    if not isinstance(fix, dict) or not fix:
        print(f"  ⚠ 词典 {fix_path} 为空或格式不对（应为 {{误词: 正确词}}）")
        return segs, 0
    n = 0
    for s in segs:
        t = s["text"]
        for bad, good in fix.items():
            if not bad or bad not in t:
                continue
            if boundary and len(bad) <= 1 and is_cjk(bad):
                t, k = re.subn(rf"(?<![{_CJK}]){re.escape(bad)}(?![{_CJK}])",
                               good, t)
            else:
                k = t.count(bad)
                t = t.replace(bad, good)
            n += k
        s["text"] = t
    return segs, n


def is_hallucination(text):
    t = text.strip()
    if not t:
        return True
    if len(t) > 24:          # 长句基本是正文，不误杀
        return False
    return any(k in t for k in HALLUCINATION)


def load_chunk_bounds():
    """从 chunks.json 读每块的真实边界，用于裁掉越界段。

    容错: 文件缺失/损坏/结构不对时返回空边界（仅放弃越界裁剪，
    不阻断合并主流程）。v1.4.0 收窄异常捕获，避免吞掉编程错误。
    """
    if not os.path.exists("chunks.json"):
        return {}
    try:
        meta = load_json("chunks.json")
        return {m["idx"]: (m["start"], m["end"]) for m in meta}
    except (json.JSONDecodeError, TypeError, KeyError, ValueError):
        return {}


def main():
    argv = sys.argv[1:]
    keep_all = "--keep-all" in argv
    want_srt = "--srt" in argv
    fix_specs = []
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--fix-dict" and i + 1 < len(argv):
            fix_specs.append(argv[i + 1])
            i += 2
            continue
        rest.append(a)
        i += 1
    fix_list = resolve_fix_dicts(fix_specs)
    pos = [a for a in rest if not a.startswith("--") and a != "--srt"
           and a != "--keep-all"]
    n = int(pos[0]) if pos and pos[0].isdigit() else None
    out_dir = pos[1] if len(pos) > 1 else "."
    os.makedirs(out_dir, exist_ok=True)

    bounds = load_chunk_bounds()
    files = [f"out_{i:03d}.json" for i in range(n)] if n else sorted(glob.glob("out_*.json"))

    segs, dropped = [], []
    for f in files:
        if not os.path.exists(f):
            continue
        m = re.search(r"out_(\d+)\.json", f)
        idx = int(m.group(1)) if m else None
        cur = load_json(f)
        lo, hi = bounds.get(idx, (None, None))
        for i, s in enumerate(cur):
            if not keep_all:
                # 规则1: 时间戳越出块边界
                if hi is not None and s["start"] > hi + 1.0:
                    dropped.append((f, "越界", s))
                    continue
                # 规则2: 块首尾的幻觉短语
                if (i == 0 or i == len(cur) - 1) and is_hallucination(s["text"]):
                    dropped.append((f, "幻觉", s))
                    continue
            segs.append(s)

    segs.sort(key=lambda x: x["start"])

    # 规则3: 相邻完全重复
    if not keep_all:
        dedup = []
        for s in segs:
            if dedup and s["text"].strip() == dedup[-1]["text"].strip():
                dropped.append(("-", "重复", s))
                continue
            dedup.append(s)
        segs = dedup

    if not segs:
        print("没有可合并的段落")
        sys.exit(1)

    # 可选后处理: 按词典替换误识别词（oss 通用层在前，用户词库在后）
    for label, path in fix_list:
        segs, n_fix = apply_fix_dict(segs, path, boundary=(label == "oss"))
        if n_fix:
            print(f"已按词典替换 {n_fix} 处（{label}）")

    print(f"合并 {len(segs)} 段, 时间跨度 {segs[0]['start']:.1f}->{segs[-1]['end']:.1f}s")
    if dropped:
        print(f"已过滤 {len(dropped)} 段可疑内容（--keep-all 可保留）:")
        for f, why, s in dropped[:10]:
            print(f"  [{why}] {s['start']:.1f}-{s['end']:.1f} {s['text'][:40]}")

    full, plain = [], []
    for s in segs:
        a, b = s["start"], s["end"]
        full.append(f"[{int(a)//60:02d}:{int(a)%60:02d}-{int(b)//60:02d}:{int(b)%60:02d}] {s['text']}")
        plain.append(s["text"])

    envkit.write_text(os.path.join(out_dir, "transcript_full.txt"),
                      "\n".join(full))
    envkit.write_text(os.path.join(out_dir, "transcript_plain.txt"),
                      "\n".join(plain))
    print(f"写出 {os.path.join(out_dir,'transcript_full.txt')} 与 transcript_plain.txt")
    if want_srt:
        write_srt(segs, os.path.join(out_dir, "transcript.srt"))
        write_vtt(segs, os.path.join(out_dir, "transcript.vtt"))
        print("写出 transcript.srt / transcript.vtt（可直接挂播放器）")


if __name__ == "__main__":
    main()
