#!/usr/bin/env python3
"""
cleanup.py — 收尾清理，把这次任务产生的磁盘占用还回去（v1.1.0 新增）

一次 35 分钟视频的中间产物: 原始 wav ~65 MB + 切块 wav 再一份 ~65 MB
+ 各块 json。跑完不清，几次任务就是几个 GB。

用法:
    python3 scripts/cleanup.py                # 清本次任务中间产物（默认，安全）
    python3 scripts/cleanup.py --caches       # 额外清 pip / modelscope 缓存
    python3 scripts/cleanup.py --deep         # 额外删共享模型权重（下次需重下 3 GB，慎用）
    python3 scripts/cleanup.py --dry-run      # 只报告不删
    python3 scripts/cleanup.py --dir <工作目录>

默认**不会**碰: /workspace 下的最终产物 transcript_*.txt、共享模型权重。
"""
import glob
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

# 中间产物模式（相对工作目录）
# 注意 *.wav.m4s 会同时被 *.wav.m4s 和 *.m4s 命中，去重处理
INTERMEDIATE_FILES = ["*.wav", "*.wav.m4s", "*.m4s", "out_*.json", "chunks.json"]
INTERMEDIATE_DIRS = ["chunks", "__pycache__"]
# 脚本自身目录下的 __pycache__（Python 运行本技能脚本时自动生成，非任务产物）
# 旧版曾写 "scripts/__pycache__"，那是相对工作目录的相对路径，永远命中不了。
SCRIPT_PYCACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "__pycache__")
PROTECTED = {"transcript_full.txt", "transcript_plain.txt"}


def size_of(path):
    if os.path.isdir(path):
        return envkit.dir_size_mb(path)
    try:
        return os.path.getsize(path) / (1024 ** 2)
    except OSError:
        return 0.0


def collect(workdir):
    targets = []
    seen = set()
    for pat in INTERMEDIATE_FILES:
        for p in glob.glob(os.path.join(workdir, pat)):
            key = os.path.normcase(os.path.abspath(p))
            if key in seen:
                continue
            seen.add(key)
            if os.path.basename(p) not in PROTECTED:
                targets.append(p)
    for d in INTERMEDIATE_DIRS:
        p = os.path.join(workdir, d)
        if os.path.isdir(p):
            key = os.path.normcase(os.path.abspath(p))
            if key not in seen:
                seen.add(key)
                targets.append(p)
    return targets


def collect_caches():
    home = os.path.expanduser("~")
    cands = [
        os.path.join(home, ".cache", "pip"),
        os.path.join(home, ".cache", "modelscope", "hub"),
        os.path.join(home, ".cache", "huggingface", "hub"),
    ]
    return [c for c in cands if os.path.isdir(c) and size_of(c) > 1]


def remove(path, dry):
    mb = size_of(path)
    if dry:
        print(f"  [dry] {path}  ({envkit.human(mb)})")
        return mb
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        else:
            os.remove(path)
        print(f"  已删 {path}  ({envkit.human(mb)})")
        return mb
    except OSError as e:
        # Windows 沙箱可能拦截删除（回收站不可用），给人话提示而不是干巴巴报错
        msg = str(e)
        if "SAFE_DELETE" in msg or "recycle" in msg.lower():
            print(f"  跳过 {path}  （沙箱回收站不可用，删除被环境拦截；"
                  f"可手动删除或换普通终端执行）")
        else:
            print(f"  跳过 {path}: {e}")
        return 0.0


def main():
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    dry = "--dry-run" in flags
    workdir = "."
    if "--dir" in sys.argv:
        i = sys.argv.index("--dir")
        if i + 1 < len(sys.argv):
            workdir = sys.argv[i + 1]

    print(f"工作目录: {os.path.abspath(workdir)}{'  [dry-run]' if dry else ''}")
    freed = 0.0

    print("\n[1] 本次任务中间产物")
    targets = collect(workdir)
    if not targets:
        print("  （无）")
    for t in targets:
        freed += remove(t, dry)

    # 顺带清脚本目录的 __pycache__（Python 字节码缓存，可随时重新生成）
    if os.path.isdir(SCRIPT_PYCACHE):
        freed += remove(SCRIPT_PYCACHE, dry)

    if "--caches" in flags or "--deep" in flags:
        print("\n[2] 包管理器 / 下载缓存")
        caches = collect_caches()
        if not caches:
            print("  （无）")
        for c in caches:
            freed += remove(c, dry)

    if "--deep" in flags:
        print("\n[3] 共享模型权重（下次使用需重新下载）")
        roots = [envkit.shared_cache_root()] + envkit.LEGACY_DIRS
        hit = False
        for r in roots:
            if os.path.isdir(r):
                hit = True
                freed += remove(r, dry)
        if not hit:
            print("  （无）")

    print("\n" + "-" * 48)
    print(f"{'预计可回收' if dry else '共回收'}: {envkit.human(freed)}")
    print(f"当前可用磁盘: {envkit.free_gb():.1f} GB")
    if "--deep" not in flags:
        mdir = envkit.resolve_model_dir()
        if envkit.is_model_ready(mdir):
            print(f"已保留共享模型: {mdir}（供下次复用，不必重下）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
