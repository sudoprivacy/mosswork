"""bili_cdp_cookie.py — 从本机浏览器的 CDP 调试实例读取 B 站登录态（v2.0.0）

原理: 连 http://127.0.0.1:<port>/json/version 拿浏览器级 WebSocket 端点，
发 CDP `Storage.getCookies`，过滤 bilibili.com 域里的 SESSDATA。

设计约束:
  * 纯标准库（自带最小 WebSocket 客户端），不新增任何 pip 依赖
  * 只读 bilibili.com 域、只取 SESSDATA；其他 cookie 一律丢弃，不落盘、不打印
  * 任何失败都返回 None + 人话原因，绝不抛异常打断主流程（云端沙箱零副作用）

命令行自检:
    python3 scripts/bili_cdp_cookie.py            # 打印可达性与打码结果
"""

import base64
import json
import os
import socket
import struct
import sys
import urllib.request


def _http_json(port, path, timeout):
    url = f"http://127.0.0.1:{port}{path}"
    # 直连回环地址必须绕过系统代理（走代理会 502）
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(url, timeout=timeout) as r:
        return json.load(r)


class _WS:
    """一次性阻塞式 WebSocket 客户端（文本帧 + ping/pong + 分片），够用即收。"""

    def __init__(self, host, port, path, timeout):
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\n"
               "Upgrade: websocket\r\nConnection: Upgrade\r\n"
               f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.sock.sendall(req.encode())
        resp = b""
        while b"\r\n\r\n" not in resp:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("握手响应不完整")
            resp += chunk
        if b" 101 " not in resp.split(b"\r\n", 1)[0]:
            raise ConnectionError("握手被拒绝（端口不是 CDP 调试实例）")

    def _recv_exact(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                return None
            buf += chunk
        return buf

    def send_text(self, text):
        payload = text.encode()
        mask = os.urandom(4)
        hdr = bytearray([0x81])
        n = len(payload)
        if n < 126:
            hdr.append(0x80 | n)
        elif n < 65536:
            hdr.append(0x80 | 126)
            hdr += struct.pack(">H", n)
        else:
            hdr.append(0x80 | 127)
            hdr += struct.pack(">Q", n)
        hdr += mask
        self.sock.sendall(bytes(hdr) + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    def recv_message(self):
        """读完整消息（自动拼分片、回 pong）。连接关闭返回 None。"""
        parts, opcode = [], None
        while True:
            hdr = self._recv_exact(2)
            if hdr is None:
                return None
            op = hdr[0] & 0x0F
            ln = hdr[1] & 0x7F
            if ln == 126:
                ext = self._recv_exact(2)
                if ext is None:
                    return None
                ln = struct.unpack(">H", ext)[0]
            elif ln == 127:
                ext = self._recv_exact(8)
                if ext is None:
                    return None
                ln = struct.unpack(">Q", ext)[0]
            payload = self._recv_exact(ln) if ln else b""
            if payload is None:
                return None
            if op == 0x8:            # close
                return None
            if op == 0x9:            # ping -> pong
                self.sock.sendall(bytes([0x8A, 0x80]) + os.urandom(4))
                continue
            if op == 0x1:
                opcode, parts = 0x1, [payload]
            elif op == 0x0 and parts:
                parts.append(payload)
            if opcode == 0x1 and (hdr[0] & 0x80):  # FIN
                return b"".join(parts).decode("utf-8", "replace")

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


def fetch_sessdata(port=9222, timeout=3):
    """返回 (cookie, err) 二元组：成功为 ("SESSDATA=...", None)，不可用时为
    (None, 人话原因)。永不抛异常。所有调用点均按二元组解包。"""
    try:
        info = _http_json(port, "/json/version", timeout)
        ws_url = info.get("webSocketDebuggerUrl") or ""
        if not ws_url.startswith("ws://"):
            return None, f"调试端点异常（{ws_url[:40]}）"
        rest = ws_url.split("://", 1)[1]
        host, _, path = rest.partition("/")
        ws = _WS(host, port, "/" + path, timeout)
    except (OSError, ValueError, ConnectionError) as e:
        return None, f"调试实例未运行或端口不通（: {port}, {type(e).__name__}）"
    try:
        ws.send_text(json.dumps({"id": 1, "method": "Storage.getCookies", "params": {}}))
        while True:
            msg = ws.recv_message()
            if msg is None:
                return None, "连接中断，未收到 cookie 响应"
            d = json.loads(msg)
            if d.get("id") != 1:
                continue
            if "error" in d:
                return None, f"CDP 错误: {d['error'].get('message', '?')}"
            cookies = (d.get("result") or {}).get("cookies") or []
            sess = [c for c in cookies
                    if c.get("name") == "SESSDATA"
                    and str(c.get("domain", "")).lstrip(".").endswith("bilibili.com")]
            if not sess:
                return None, "调试实例在线，但没有 B 站登录态（先在该浏览器里登录 bilibili.com）"
            # 优先取有效期更长的那条
            sess.sort(key=lambda c: c.get("expires") or 0, reverse=True)
            return "SESSDATA=" + sess[0]["value"], None
    except (OSError, ValueError) as e:
        return None, f"读取 cookie 失败（{type(e).__name__}）"
    finally:
        ws.close()


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9222
    print(f"探测 127.0.0.1:{port} ...")
    cookie, err = fetch_sessdata(port=port)
    if cookie:
        body = cookie.partition("=")[2]
        print(f"✅ 登录态可读: SESSDATA={body[:6]}…（共{len(body)}字符，值已打码不回显）")
        return 0
    print(f"❌ 不可用: {err}")
    print("提示: 需要浏览器以调试模式运行且已登录 bilibili.com；"
          "云端沙箱无浏览器属正常现象，请用配置文件/环境变量方式。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
