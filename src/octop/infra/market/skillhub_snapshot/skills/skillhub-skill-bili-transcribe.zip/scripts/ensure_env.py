#!/usr/bin/env python3
"""
ensure_env.py — 首次上手向导 / 环境体检（幂等，可反复执行）

⚠️ 本脚本**不会创建虚拟环境**。它复用你当前的 Python 解释器：
   - 如果你已经在某个 venv/conda 里，就装进那个环境；
   - 如果是系统解释器，就装进系统环境。
   绝不会为这个技能单独 venv —— 那会白白多占 1-3 GB 且与宿主重复。

用法:
    python3 scripts/ensure_env.py            # 体检并按需安装（首次运行就跑这个）
    python3 scripts/ensure_env.py --check    # 只体检不安装（退出码 0=齐备）
    python3 scripts/ensure_env.py --doctor   # 完整诊断: 硬件/网络/依赖/模型/耗时预估
    python3 scripts/ensure_env.py --yes      # 显式确认自动安装（兼容历史用法）

注: 本脚本默认就直接安装缺失项，不做交互确认（幂等、安全）。
    --yes 只是显式声明，与默认行为一致，留着为兼容旧命令。

首次使用者请直接看输出末尾的「下一步」，照抄那一行命令即可。
"""
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

PY_DEPS = [("faster_whisper", "faster-whisper")]          # 运行必需
OPTIONAL_DEPS = [("modelscope", "modelscope")]            # 仅首次下模型需要

NET_TARGETS = [
    ("B站 API（下载音频用）", "https://api.bilibili.com"),
    ("ModelScope（下载模型用）", "https://www.modelscope.cn"),
]


def mark(ok):
    return "✓" if ok else "✗"


# ------------------------------------------------------------------ 安装 ffmpeg
def install_ffmpeg():
    """尝试用系统包管理器安装 ffmpeg（Windows 走 winget/choco/scoop）。

    与旧版的关键区别: **不再吞掉错误输出**。第一次装的人如果失败，
    必须看到真实原因（没有 sudo？没网？源不可用？），否则无从下手。

    v1.5.0: Windows 安装命令拆成列表参数走无 shell（winget 可执行文件
    路径可能含空格，shell 拼接会碎）；Linux 的包管理器命令本身含
    管道/`&&`，仍走本机 shell，但内部不做任何引号假设。
    """
    mgr, cmd = envkit.ffmpeg_install_cmd()
    if not cmd:
        print("  未识别到可用的包管理器（apt/dnf/yum/zypper/pacman/apk/brew"
              + ("/winget/choco/scoop" if envkit.IS_WINDOWS else "") + "）。")
        print("  请手动安装 ffmpeg 后重试: https://ffmpeg.org/download.html")
        return False

    print(f"  使用 {mgr} 安装 ffmpeg ...")
    print(f"  $ {cmd}")
    r = None
    if envkit.IS_WINDOWS:
        # winget/choco/scoop 安装后 PATH 不即时生效，且需要无交互。
        # 用 shlex.split 把命令串拆成列表走无 shell，路径带空格也安全。
        import shlex
        argv = shlex.split(cmd)
        if mgr == "winget":
            argv += ["--accept-source-agreements", "--accept-package-agreements"]
        r = subprocess.run(argv, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
    else:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
    if envkit.have_ffmpeg():
        return True

    err = (r.stdout + r.stderr).strip()
    print("  安装未成功。原始输出（末尾 600 字）:")
    print("  " + "\n  ".join(err[-600:].splitlines()[-12:] or ["(无输出)"]))
    if "permission denied" in err.lower() or "are you root" in err.lower():
        print("\n  看起来是权限问题。请用管理员身份执行:")
        print(f"    sudo {cmd.replace('sudo ', '')}")
    elif "could not resolve" in err.lower() or "temporary failure" in err.lower():
        print("\n  看起来是网络/软件源问题。请检查网络或更换镜像源后重试。")
    return False


# ------------------------------------------------------------------ 各分区体检
def section_hardware():
    py = sys.executable or "python3"
    cores, threads = envkit.cpu_count(), envkit.suggest_threads()
    print(f"解释器      : {py}")
    print(f"Python 版本 : {sys.version.split()[0]}"
          + ("" if envkit.python_ok() else
             f"  ✗ 过低，需要 >= {'.'.join(map(str, envkit.MIN_PY))}"))
    if envkit.in_virtualenv():
        print("环境策略    : 检测到已有虚拟环境 → 直接复用，不新建")
    else:
        print("环境策略    : 系统解释器 → 直接使用，不新建")
    print(f"CPU / 内存  : {cores} 核 / {envkit.mem_gb():.0f} GB"
          f"（转写将用 {threads} 线程）")
    print(f"磁盘可用    : {envkit.free_gb():.1f} GB")
    print(f"模型缓存目录: {envkit.shared_cache_root()}")
    return envkit.python_ok()


def section_network(enabled=True):
    if not enabled:
        return True
    print("-" * 60)
    print("网络连通性（不通的话后面一定失败，先在这里发现）")
    all_ok = True
    for label, url in NET_TARGETS:
        ok = envkit.check_url(url)
        print(f"  [{mark(ok)}] {label}")
        all_ok = all_ok and ok
    if not all_ok:
        print("  提示: 若在公司/校园网内，可能需要配置代理:")
        print("    export https_proxy=http://<代理地址>:<端口>")
    return all_ok


def section_deps():
    print("-" * 60)
    print("依赖检查")
    missing = []

    ok = envkit.have_ffmpeg()
    print(f"  [{mark(ok)}] ffmpeg / ffprobe   （音频下载与切分必需）")
    if not ok:
        missing.append("ffmpeg")

    for mod, pkg in PY_DEPS:
        ok = envkit.have_module(mod)
        print(f"  [{mark(ok)}] {pkg:<18}（语音识别引擎，约 60 MB）")
        if not ok:
            missing.append(pkg)

    for mod, pkg in OPTIONAL_DEPS:
        ok = envkit.have_module(mod)
        print(f"  [{mark(ok)}] {pkg:<18}（仅首次下载模型时需要）")
    return missing


def section_model():
    print("-" * 60)
    print("语音模型")
    name, mdir = envkit.any_model_ready()
    if name:
        print(f"  [✓] 已就绪: {name}  {mdir}"
              f"  ({envkit.human(envkit.dir_size_mb(mdir))})")
        return True, name

    rec, reason = envkit.recommend_model()
    info = envkit.MODELS[rec]
    print("  [✗] 尚未下载任何模型 —— 这是首次使用唯一的大件下载")
    print(f"      推荐: {rec}（{info['size_gb']} GB，{info['note']}）")
    print(f"      理由: {reason}")
    print(f"      下载: python3 scripts/setup_model.py --auto")
    return False, rec


def section_estimate(model_name):
    """把"要等多久"提前说清楚，避免首次使用者以为程序卡死。"""
    print("-" * 60)
    threads = envkit.suggest_threads()
    rtf = envkit.estimate_rtf(model_name, threads)
    print(f"耗时预估（{model_name} · {threads} 线程 · 纯 CPU）")
    for label, sec in (("10 分钟视频", 600), ("30 分钟视频", 1800),
                       ("60 分钟视频", 3600)):
        print(f"  {label:<12} 约 {envkit.fmt_duration(sec * rtf)}")
    print("  说明: 转写是 CPU 密集任务，进度条走得慢属正常，不是卡死。")
    if rtf > 1.5:
        print(f"  ⚠ 你的机器跑 {model_name} 偏慢，想快可以换小模型:")
        print("      python3 scripts/setup_model.py small")


def section_next_step(missing, model_ready, rec):
    print("=" * 60)
    if missing:
        print("下一步: 先补齐依赖")
        print("  python3 scripts/ensure_env.py")
    elif not model_ready:
        print("下一步: 下载语音模型（只需一次，之后所有任务共用）")
        print("  python3 scripts/setup_model.py --auto")
    else:
        print("环境齐备。下一步: 直接跑一个视频试试")
        print('  python3 scripts/run.py "https://www.bilibili.com/video/BV1xx411c7mD"')
    print("=" * 60)


# ------------------------------------------------------------------ 主流程
def main():
    flags = {a for a in sys.argv[1:] if a.startswith("--")}
    check_only = "--check" in flags
    doctor = "--doctor" in flags
    # --yes 与默认行为一致（默认就直接装），仅作为显式确认的兼容标志，无需分支处理

    envkit.banner("bili-transcribe 环境体检（共用环境模式，不建 venv）")

    py_ok = section_hardware()
    if not py_ok:
        envkit.die(
            f"Python 版本过低（需要 >= {'.'.join(map(str, envkit.MIN_PY))}）",
            "换用更高版本解释器执行，例如: python3.11 scripts/ensure_env.py")

    section_network(enabled=doctor)
    missing = section_deps()
    model_ready, rec_model = section_model()
    if doctor:
        section_estimate(rec_model)

    # ---- 只检查 ----
    if check_only:
        print("-" * 60)
        if missing:
            print(f"缺少: {', '.join(missing)}（--check 模式不安装）")
            section_next_step(missing, model_ready, rec_model)
            return 1
        print("依赖齐备。")
        section_next_step(missing, model_ready, rec_model)
        return 0

    if not missing:
        print("-" * 60)
        print("依赖齐备，无需安装。")
        section_next_step(missing, model_ready, rec_model)
        return 0

    # ---- 执行安装 ----
    print("-" * 60)
    print(f"缺少 {len(missing)} 项: {', '.join(missing)}")
    print("开始安装（pip 全程 --no-cache-dir，不留缓存、不建虚拟环境）")
    failed = []

    if "ffmpeg" in missing:
        if install_ffmpeg():
            print("  [✓] ffmpeg")
        else:
            failed.append("ffmpeg")
        missing.remove("ffmpeg")

    if missing:
        print(f"  安装 Python 包: {' '.join(missing)} ...")
        ok, err = envkit.pip_install(missing)
        if ok:
            print(f"  [✓] {' '.join(missing)}")
        else:
            failed += missing
            print("  安装失败，原始输出（末尾 600 字）:")
            print("  " + "\n  ".join(err[-600:].splitlines()[-12:] or ["(无输出)"]))
            py = sys.executable or "python3"
            print("\n  可手动重试:")
            print(f"    {py} -m pip install --no-cache-dir {' '.join(missing)}")

    print("-" * 60)
    if failed:
        print(f"仍有 {len(failed)} 项未装上: {', '.join(failed)}")
        print("按上面的提示手动处理后，重新执行本脚本即可（幂等，不会重复装）。")
        return 1

    print("环境准备完成。")
    model_ready, rec_model = envkit.any_model_ready()[0] is not None, rec_model
    section_next_step([], model_ready, rec_model)
    return 0


if __name__ == "__main__":
    sys.exit(main())
