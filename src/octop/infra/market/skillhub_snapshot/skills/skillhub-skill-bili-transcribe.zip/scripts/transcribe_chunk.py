#!/usr/bin/env python3
"""
transcribe_chunk.py — 转写【单个】音频块（前台串行单元）

也可作为模块被 run.py import: load_model() 只加载一次模型，
逐块复用，省下每块几十秒的重复加载时间。

要点:
  * 模型目录由共享缓存自动解析（envkit），不硬编码私有路径
  * initial_prompt 默认通用，不注入任何领域专名（旧版写死过某期视频的术语，
    转写其他领域视频时会把这些词"喂"给模型造成误识别污染）
  * --rm-chunk: 转写成功后立即删掉该块 wav，边转边释放空间
  * 缺依赖/缺模型/缺文件时给"人话 + 一行修复命令"，不甩 traceback

经验(关键):
  * 本沙箱并发转写反而更慢，且后台/进程池子进程会被回收。
  * 每块单独前台运行（timeout 400s，< 工具 600s 上限）最稳。
  * 绝不用会出现在自己命令行里的 pkill pattern（会自杀）。

用法:
    python3 transcribe_chunk.py <块索引> [模型目录] [chunks.json]
    python3 transcribe_chunk.py 0 -p "本视频涉及 XXX、YYY 等术语"
    python3 transcribe_chunk.py 0 --rm-chunk
    python3 transcribe_chunk.py 0 --beam-size 5 --language zh
    CPU_THREADS=4 python3 transcribe_chunk.py 0   # 显式限制线程（默认自动取 min(核数-1,16)）

产出: out_NNN.json  (list of {start,end,text}，时间已对齐原音频)

v1.4.0:
  * beam_size 默认从 1 提升到 5（准确率明显更好），可 --beam-size 调整
  * 新增 --language（默认 zh；英文视频传 en 可显著提升质量）
  * 文件读写统一 with + encoding="utf-8"
"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envkit  # noqa: E402

# 通用提示词: 只声明语言与书写规范，不注入任何领域专名，避免污染
DEFAULT_PROMPT = "以下是一段中文讲解内容，请使用简体中文输出，保留专业术语与英文缩写的原貌，并添加合适的标点。"


def load_model(model_dir=None, threads=None, quiet=False):
    """加载 Whisper 模型。失败时给人话提示而不是 traceback。

    run.py 会调用一次后重复使用，避免每块重复加载（large-v3 每次约 10-30 秒）。
    """
    model_dir = model_dir or envkit.resolve_model_dir()
    threads = int(threads or os.environ.get("CPU_THREADS")
                  or envkit.suggest_threads())

    if not envkit.is_model_ready(model_dir):
        name, other = envkit.any_model_ready()
        if other:
            envkit.die(
                f"指定的模型目录不可用: {model_dir}",
                f"本机已有 {name} 模型，用它即可: "
                f"export WHISPER_MODEL_DIR={other}")
        envkit.die(
            "还没有下载语音模型（首次使用需要下载一次）",
            "python3 scripts/setup_model.py --auto")

    if not envkit.have_module("faster_whisper"):
        envkit.die(
            "缺少语音识别引擎 faster-whisper",
            "python3 scripts/ensure_env.py")

    try:
        from faster_whisper import WhisperModel
    except Exception as ex:                       # noqa: BLE001
        envkit.die(f"faster-whisper 导入失败: {type(ex).__name__}: {ex}",
                   "重装试试: python3 -m pip install --no-cache-dir "
                   "--force-reinstall faster-whisper")

    if not quiet:
        print(f"加载模型: {model_dir}（{threads} 线程，int8 量化）")
    t0 = time.time()
    try:
        model = WhisperModel(model_dir, device="cpu", compute_type="int8",
                             cpu_threads=threads)
    except Exception as ex:                       # noqa: BLE001
        msg = str(ex).lower()
        if "memory" in msg or "alloc" in msg:
            envkit.die("内存不足，加载不了这个模型",
                       "换用更小的模型: python3 scripts/setup_model.py small")
        envkit.die(f"模型加载失败: {type(ex).__name__}: {ex}",
                   "模型文件可能损坏，删掉重下: "
                   + ("rm -rf " + model_dir if not envkit.IS_WINDOWS
                      else "删除目录 " + model_dir + "（资源管理器）")
                   + " && python3 scripts/setup_model.py --auto")
    if not quiet:
        print(f"模型就绪，耗时 {time.time() - t0:.1f}s")
    return model


def transcribe_one(model, meta_all, idx, prompt=None, rm_chunk=False,
                   quiet=False, language="zh", beam_size=5, prev_tail=None):
    """转写第 idx 块，写出 out_NNN.json，返回 (段数, 耗时秒, 音频秒)。

    prev_tail: 上一块末尾 1-2 句真实文本。拼进 initial_prompt 作为上下文，
    让模型在块边界处保持术语/句式一致（比 condition_on_previous_text=True
    更安全，不会触发长音频的重复循环幻觉）。
    """
    if idx >= len(meta_all):
        envkit.die(f"块索引 {idx} 超出范围（共 {len(meta_all)} 块）",
                   "检查 chunks.json，或重新执行 split.py")
    m = meta_all[idx]
    wav = m["file"]
    if not os.path.isfile(wav):
        out = f"out_{idx:03d}.json"
        if os.path.isfile(out):
            # 之前已转写并用 --rm-chunk 删掉了块文件，属正常续跑场景
            rows = envkit.read_json(out)
            if not quiet:
                print(f"[chunk {idx}] 已有结果，跳过（{len(rows)} 段）")
            return len(rows), 0.0, m["dur"]
        envkit.die(f"块文件不存在: {wav}",
                   "先切分音频: python3 scripts/split.py audio.wav chunks")

    base_prompt = prompt or os.environ.get("WHISPER_PROMPT") or DEFAULT_PROMPT
    if prev_tail:
        base_prompt = f"{base_prompt}\n（承接上文）{prev_tail}"
    t0 = time.time()
    segments, _info = model.transcribe(
        wav, language=language, beam_size=beam_size, vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500),
        condition_on_previous_text=False, initial_prompt=base_prompt)

    rows = [{"start": m["start"] + s.start, "end": m["start"] + s.end,
             "text": s.text.strip()} for s in segments]
    cost = time.time() - t0

    out = f"out_{idx:03d}.json"
    envkit.write_json(out, rows)

    if not quiet:
        rtf = cost / m["dur"] if m["dur"] else 0
        print(f"[chunk {idx}] {len(rows)} 段 · 音频 {m['dur']:.0f}s · "
              f"耗时 {cost:.0f}s · {rtf:.2f}x 实时 -> {out}")

    if rm_chunk:
        try:
            mb = os.path.getsize(wav) / (1024 ** 2)
            os.remove(wav)
            if not quiet:
                print(f"[chunk {idx}] 已释放块文件 ({mb:.0f} MB)")
        except OSError:
            pass
    return len(rows), cost, m["dur"]


def parse_args(argv):
    opts = {"prompt": None, "rm_chunk": False, "language": "zh", "beam": 5}
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-p", "--prompt") and i + 1 < len(argv):
            opts["prompt"] = argv[i + 1]
            i += 2
        elif a == "--rm-chunk":
            opts["rm_chunk"] = True
            i += 1
        elif a == "--language" and i + 1 < len(argv):
            opts["language"] = argv[i + 1]
            i += 2
        elif a == "--beam-size" and i + 1 < len(argv):
            opts["beam"] = int(argv[i + 1])
            i += 2
        else:
            pos.append(a)
            i += 1
    return opts, pos


def main():
    opts, pos = parse_args(sys.argv[1:])
    if not pos:
        print(__doc__)
        return 1

    try:
        idx = int(pos[0])
    except ValueError:
        envkit.die(f"块索引必须是数字，收到: {pos[0]}",
                   "例如转写第 0 块: python3 scripts/transcribe_chunk.py 0")

    model_dir = pos[1] if len(pos) > 1 else None
    meta_path = pos[2] if len(pos) > 2 else "chunks.json"

    if not os.path.isfile(meta_path):
        envkit.die(f"找不到切分清单 {meta_path}",
                   "先切分音频: python3 scripts/split.py audio.wav chunks")
    meta_all = envkit.read_json(meta_path)

    model = load_model(model_dir)
    n, cost, dur = transcribe_one(model, meta_all, idx,
                                  prompt=opts["prompt"],
                                  rm_chunk=opts["rm_chunk"],
                                  language=opts["language"],
                                  beam_size=opts["beam"])

    # 给出整片预估，避免用户不知道还要等多久
    remaining = [m for i, m in enumerate(meta_all)
                 if i > idx and not os.path.isfile(f"out_{i:03d}.json")]
    if remaining and cost > 0 and dur > 0:
        rtf = cost / dur
        left = sum(m["dur"] for m in remaining) * rtf
        print(f"还剩 {len(remaining)} 块（约 {envkit.fmt_duration(left)}）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
