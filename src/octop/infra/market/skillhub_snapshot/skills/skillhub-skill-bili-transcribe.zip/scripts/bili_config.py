"""bili_config.py — 登录态与配置的分层管理（v2.0.0）

优先级（高→低）：CLI --cookie > 环境变量 BILI_SESSDATA > 配置文件 sessdata > 游客(无)。
配置文件固定在 ~/.bili-transcribe/config.json，绝不随技能分发、不入仓。

CLI:
    python3 scripts/bili_config.py status                 # 显示当前模式（不回显完整值）
    python3 scripts/bili_config.py set-cookie "SESSDATA=xxx"   # 写入配置（也接受裸值）
    python3 scripts/bili_config.py clear                  # 清除配置文件
"""

import argparse
import json
import os
import sys

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".bili-transcribe")
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_CDP_PORT = 9222


def config_exists():
    return os.path.isfile(CONFIG_PATH)


def _load():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _normalize(value):
    """容忍两种输入：裸 SESSDATA 值 或 完整的 'SESSDATA=...' 键值对。"""
    v = (value or "").strip().strip('"').strip("'")
    if not v:
        return None
    if "=" in v:
        name, _, val = v.partition("=")
        if name.strip().upper() == "SESSDATA" and val.strip():
            return "SESSDATA=" + val.strip()
        return None
    return "SESSDATA=" + v


def _env_port():
    try:
        return int(os.environ.get("BILI_CDP_PORT", "").strip() or DEFAULT_CDP_PORT)
    except ValueError:
        return DEFAULT_CDP_PORT


def get_cdp_port():
    """CDP 调试端口：环境变量 BILI_CDP_PORT > 配置文件 cdp_port > 默认 9222。"""
    d = _load()
    try:
        return int(d.get("cdp_port") or _env_port())
    except (TypeError, ValueError):
        return _env_port()


def get_config_cookie():
    """配置文件里的登录态；无则 None。"""
    return _normalize(_load().get("sessdata"))


def get_env_cookie():
    return _normalize(os.environ.get("BILI_SESSDATA"))


def resolve_auto_cookie():
    """CLI 之外的三层自动解析。返回 (cookie, 来源说明) 或 (None, None)。

    来源依次：环境变量 > 配置文件 > 本机浏览器 CDP（失败静默跳过——
    云端沙箱没有调试端口，天然落到游客模式，零副作用）。
    """
    v = get_env_cookie()
    if v:
        return v, "环境变量 BILI_SESSDATA"
    v = get_config_cookie()
    if v:
        return v, "配置文件 ~/.bili-transcribe/config.json"
    try:
        import bili_cdp_cookie
        v, _err = bili_cdp_cookie.fetch_sessdata(port=get_cdp_port())
        if v:
            return v, f"本机浏览器 CDP(:{get_cdp_port()})"
    except Exception:
        pass
    return None, None


# ---------------------------------------------------------------- CLI
def _mask(v):
    if not v:
        return "(无)"
    body = v.partition("=")[2] or v
    return (body[:6] + "…" + f"（共{len(body)}字符）") if len(body) > 10 else "…（过短）"


def _mode_report():
    env = get_env_cookie()
    cfg = get_config_cookie()
    print(f"配置文件 : {CONFIG_PATH}{'（不存在）' if not config_exists() else ''}")
    print(f"环境变量 : {'BILI_SESSDATA=' + _mask(env) if env else '(未设置)'}")
    if cfg:
        print(f"配置文件 : sessdata={_mask(cfg)}")
    port = get_cdp_port()
    try:
        import bili_cdp_cookie
        v, _err = bili_cdp_cookie.fetch_sessdata(port=port)
        if v:
            print(f"本机浏览器 : CDP(:{port}) 可读，SESSDATA={_mask(v)}")
            print("生效模式 : 本机浏览器 CDP 自动（优先级低于显式配置）")
            return
        print(f"本机浏览器 : CDP(:{port}) 不可用（未运行调试实例或未登录 B 站）")
    except Exception as e:
        print(f"本机浏览器 : CDP(:{port}) 探测失败（{type(e).__name__}）")
    eff = "环境变量" if env else ("配置文件" if cfg else "游客（无登录态，CC 字幕 + Whisper 兜底）")
    print(f"生效模式 : {eff}")


def main():
    ap = argparse.ArgumentParser(description="bili-transcribe 登录态配置管理")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("status", help="显示当前登录态来源（值打码）")
    p_set = sub.add_parser("set-cookie", help='写入登录态，如 "SESSDATA=xxx" 或裸值')
    p_set.add_argument("value")
    sub.add_parser("clear", help="删除配置文件")
    a = ap.parse_args()
    if a.cmd == "status":
        _mode_report()
        return 0
    if a.cmd == "set-cookie":
        v = _normalize(a.value)
        if not v:
            print("值无效：应传 SESSDATA 值本身，或完整 \"SESSDATA=xxx\"")
            return 1
        os.makedirs(CONFIG_DIR, exist_ok=True)
        d = _load()
        d["sessdata"] = v.partition("=")[2]
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
        try:
            os.chmod(CONFIG_PATH, 0o600)  # POSIX 收紧权限；Windows 忽略失败
        except OSError:
            pass
        print(f"已写入 {CONFIG_PATH}（值打码: {_mask(v)}）")
        print("提醒: 该文件含你的账号登录态，请勿截图/分享/提交到任何仓库。")
        return 0
    if a.cmd == "clear":
        if config_exists():
            os.remove(CONFIG_PATH)
            print("已删除配置文件")
        else:
            print("配置文件不存在，无需清除")
        return 0
    ap.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
