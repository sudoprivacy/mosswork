# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.0.1] - 2026-09-05

**主题：修复游客 / 云端模式启动崩溃** —— 登录态自动解析在 CDP 调试实例不可达时，
会把错误二元组当成 cookie 透传进子进程命令，导致 `run.py` 一启动就 `subprocess`
报 `expected str, bytes or os.PathLike object, not tuple` 崩溃。该场景正是技能声明的
「云端沙箱 / 首次使用（无浏览器）」默认路径，故 2.0.0 在此类环境必然起不来。

### Fixed

- `scripts/bili_config.py::resolve_auto_cookie`：CDP 探测失败时
  `bili_cdp_cookie.fetch_sessdata()` 返回 `(None, 错误原因)` 二元组，原代码按标量接收
  `v = fetch_sessdata(...)` 后 `if v:` 误判非空元组为真，把整个元组当 cookie 透传入
  `run.py` 的子进程命令参数。改为 `v, _err = fetch_sessdata(...)` 正确解包，与同文件
  `_mode_report`（2.0.0 已正确解包）契约一致。游客模式 / 无调试实例的云端沙箱现在可
  正常进入 Whisper 转写，不再启动即崩
- `scripts/bili_cdp_cookie.py::fetch_sessdata` 文档字符串修正：声明实际返回
  `(cookie_or_None, errmsg_or_None)` 二元组，与实现及全部调用点一致（消除原
  「返回字符串 / None」的歧义文档）

### Changed

- `SKILL.md`：版本 2.0.0 → 2.0.1

## [2.0.0] - 2026-09-05

**主题：多用户与云端沙箱适配** —— 支持其他网友开箱即用，登录态自动分层，
零隐私收集（凭据只存使用者自己的机器，永不入仓）。

### Added

- `scripts/bili_config.py`：登录态分层管理。优先级 CLI `--cookie` > 环境变量
  `BILI_SESSDATA` > `~/.bili-transcribe/config.json` > 本机浏览器 CDP > 游客模式。
  CLI 子命令 `status`（值打码）/ `set-cookie` / `clear`；配置文件 POSIX 下自动 600 权限
- `scripts/bili_cdp_cookie.py`：本机浏览器 CDP 读登录态（纯标准库最小 WS 客户端，
  `Storage.getCookies` 过滤 bilibili.com 域）。任何失败返回 None + 人话原因，
  云端沙箱无调试端口时静默降级、零副作用
- `run.py`：启动时自动解析登录态并提示来源；首次使用（无配置）打印游客模式引导文案
- `config.example.json`：配置示例（全占位符）
- `references/multi-user.md`：给网友的三场景说明（本机自动 / 云端自配 / 游客）、
  SESSDATA 获取与安全提醒、云端风控与 `--budget` 建议、隐私声明

### Changed

- `SKILL.md`：版本 2.0.0；选项表与文件地图更新；踩坑铁律第 4 条补充
  「AI 字幕必须登录态（实测无登录 code 0 字幕轨 = 0）」
- **模型缓存根迁移** `~/.cache/whisper-models` → `~/.local/whisper-models`
  （可用 `$BILI_MODEL_CACHE` 覆盖根、`$WHISPER_MODEL_DIR` 覆盖单模型目录）；
  旧位置任意同名模型仍被自动识别复用，老用户升级无需重新下载

### Security

- 隐私审计通过：技能目录零凭据残留；新增代码不落盘任何 cookie 值、
  `status` 永不回显完整登录态；CDP 只读 bilibili.com 域并过滤丢弃其余 cookie

## [1.9.0] - 2026-08-23

**主题：thin-hub 结构整改** —— 纯文档重组，`scripts/` 与 `dicts/` 零改动，行为不变。

### Changed

- `SKILL.md` 按 thin-hub 规范重构：367 行 → 120 行，只保留入口（一条命令、选项表、
  When to Use、公约摘要）+ 标准工作流路由表 + 文件地图；长内容拆分至：
  - `references/workflow.md`：步骤 0–6 完整 SOP 与注意事项
  - `references/proofread.md`：AI 校对流程与子代理 briefing 全文（原步骤 7）
  - `references/summary-template.md`：技术类总结模板（原步骤 8）
  - `references/pitfalls.md`：踩坑铁律全文 14 条
- 示例转录稿 `transcript_full.txt` / `transcript_plain.txt` 从技能根目录移入 `examples/`，
  并新增 `examples/case-index.md` 案例索引（补齐第三层 examples）

### Fixed

- frontmatter `name` 与目录名不一致：`bili-transcribe` → `bili-transcribe__skillhub`
  （slug 字段保留 hub 来源标记 `bili-transcribe` 不变）

## [1.8.0] - 2026-08-19

**主题：性能与可用性整改** —— 线程上限放宽、后台姿势修正、对接开源通用纠错词典。

### Added

- `envkit.py`：`suggest_threads()` 线程上限 8 → `min(核数-1, 16)`，多核机器转写提速（实测 8→16 在 int8 CPU 转写上收益明显）
- `dicts/oss_zh.json` + `dicts/README.md`：内置开源通用错别字纠错词典（精选常见错别字，**仅显式调用**）
- `merge.py` / `run.py`：`--fix-dict` 支持 `oss` 关键字与逗号组合多词典（`--fix-dict oss,my.json`），通用层在前、自有词库在后；词边界护栏（单字误识不被其它 CJK 字夹住时才替换，防止嵌在长词里误伤）
- `run.py --dry-run`：按标题/简介做轻量领域识别，建议该传的 `-p` 领域术语（AI/编程/金融/医学/汽车），降低后续校对成本
- `SKILL.md`：新增可选**步骤 8 · 技术类总结模板**（结论先行 + 差异对比表 + 术语口径 + 个人研判骨架）
- `SKILL.md`：铁律 3 修订——区分「并发多子进程（危险）」与「单进程 `nohup run.py &` 后台（长任务推荐）」，消除文档与实测的矛盾

### Changed

- `SKILL.md` 步骤 4 SOP：去掉 `CPU_THREADS=8` 硬编码（默认自动取 `min(核数-1,16)`），补充 >10min 长视频单进程后台姿势
- 技能自带示例转录稿 `transcript_full.txt/plain.txt` 文件头加 `# 示例产物（测试用，非你的目标视频）` 注释，防误认是本次产物
- `get_audio.py`：`get_video_info()` 返回 `desc` 字段（支撑 dry-run 领域建议）

### Fixed

- `run.py` 入口新增 BV 号格式校验（`^BV[0-9A-Za-z]{10}$`），手滑/复制截断提前拦下并给出一行修复命令
- `merge.py`：修正词边界模式下替换计数（只统计实际替换次数，不含被护栏拦下的命中）

### 备注（暂缓项）

- `av` 库解码 fallback（ffmpeg 缺失时回退 `av`）：改动面较大、影响 Windows 本机行为，待确认后单独合入
- `estimate_rtf` 校准：需更多实测样本标定，未盲改公式

## [1.7.0] - 2026-08-11

**主题：补上缺失的 AI 校对环节（子代理强制隔离）** —— 转写直出稿质量差的根本解决手段。

### Added

- `SKILL.md`：新增**步骤 7 · AI 校对（子代理强制模式）** 正式 SOP —— 校对项（专名还原 /
  同音字 / 断句标点 / 术语一致性 / 口语杂质）、**隔离原则（校对必须由独立子代理执行，
  主进程只发起+接收，绝不参与校对逻辑）**、完整子代理 briefing 模板（原样传入勿精简）、
  交付动作（产出 `transcript_proofread*` 稿 + 校对说明 + 拿不准先核实）、命名约定
  （`proofread` 后缀与机器直出区分）
- `run.py`：完成提示新增"💡 下一步（可选）：AI 校对"引导，用户知道转写后可发起校对

### Changed

- 踩坑铁律 11：「交付前必须人工校订专名」升级为「交付前必须 AI 校对专名（正式步骤 7）」

### Fixed

- 无

## [1.6.0] - 2026-08-11

**主题：跨平台通用化重构** —— 单一代码库双平台直接运行，统一抽象消除平台分支。

### Added

- `CROSS_PLATFORM.md`：双平台运行说明 —— Windows/Linux 各自的依赖安装、构建、验证步骤
  + 双平台测试结果对照表 + 依赖版本登记表（全部标注跨平台版本号）
- `envkit.py`：统一 IO 抽象 `read_text/write_text/read_json/write_json` ——
  **UTF-8 + 换行符统一 `\n`**（Windows/Linux 产物字节级一致，实测无 CRLF）
- `envkit.py`：`default_outdir()` —— 默认产物目录抽象（Linux 有 `/workspace` 则用，否则当前目录）
- `envkit.py`：依赖版本表集中登记（python/faster-whisper/ctranslate2/modelscope/ffmpeg/curl，均双平台可用）

### Changed

- `run.py::sh()`：收敛为**仅接受列表参数**（无 shell），字符串 shell 分支删除，
  统一单执行路径 —— 双端行为完全一致
- 全部 JSON/文本写出收敛到 `envkit.write_text/write_json`；JSON 读入收敛到 `envkit.read_json`
- `merge.py`/`get_audio.py`/`split.py`/`transcribe_chunk.py`/`run.py`：移除散落的
  `open(...)` / `json.load/dump`，统一走抽象层
- `free_gb()`：盘符根用 `os.path.splitdrive + os.sep` 拼接，不再硬编码 `'\\'`
- `ensure_env.py`：Windows ffmpeg 安装改为列表参数 + 无 shell（`shlex.split` 拆解，
  可执行文件路径含空格也安全）

### Fixed

- 无（v1.5.0 已修复功能性问题；本版本为架构收敛）

## [1.5.0] - 2026-08-11

**主题：跨平台** —— Windows 与 Linux 虚拟机行为对齐，用法不再有差异。

### Added

- `envkit.py`：`IS_WINDOWS` 平台标记；`run()` 统一执行入口（列表参数→无 shell、字符串→shell），
  所有子进程输出按 UTF-8 容错解码（Windows GBK 控制台不再乱码/崩溃）
- `envkit.py`：`mem_gb()` 增加 Windows 分支（GlobalMemoryStatusEx）；`free_gb()` 不再假定 `/`，
  自动取当前盘/目录所在分区；`ffmpeg_install_cmd()` 支持 winget/choco/scoop
- `envkit.py`：`audio_duration()` 新增 ffprobe 缺失时的 `ffmpeg -i` 解析降级
  （Windows 常见只装 ffmpeg.exe）
- `cleanup.py`：Windows 沙箱回收站不可用导致删除被拦截时，给人话提示而非干巴巴报错

### Changed

- **全部脚本**：子进程调用从 `shell=True` + `shlex.quote` 改为**无 shell 列表参数**
  —— Windows cmd.exe 不认 POSIX 单引号，旧版 curl 直接 rc=3 全挂（实测复现）
- `envkit.have_ffmpeg()`：不再强制 ffprobe 同存（ffprobe 缺失时自动降级）
- `run.py`：产物默认目录 `/workspace` 仅 Linux 有则用，Windows 用当前目录；
  `free_gb('/')` 全部改 `free_gb()`（Windows 无 `/` 根概念）
- `transcribe_chunk.py` / 各脚本报错修复命令：`rm -rf` 仅 Linux 提示，Windows 提示用资源管理器删除
- `get_audio.py` / `run.py` / `split.py`：清理无用 import（shlex/subprocess）

### Fixed

- `cleanup.py`：`*.wav.m4s` 被 `*.wav.m4s` 与 `*.m4s` 双模式重复匹配（dry-run 列两次），按
  `normcase(abspath)` 去重
- `get_audio.py --info`：Windows 上因单引号 curl 报"连不上 B 站 API"（实为 URL malformed）——
  改列表参数后实测通过

## [1.4.0] - 2026-08-11

**主题：代码审查整改** —— 依据对全部 9 个脚本的逐项审查修复 P0-P4 级问题，重点提升转写质量。

### Added

- `run.py`：官方 CC 字幕预检查（`x/player/v2`），有字幕的视频直接下载字幕并产出全文 + SRT，**跳过整轮转写**；`--dry-run` 会提示该视频是否有字幕
- `run.py`：`--language` 指定转写语言（默认 zh；英文/日文视频传 en/ja 显著提升质量）
- `run.py`：`--beam-size` 束搜索宽度（默认 5，替代原先写死的 `beam_size=1`，同音字误识大幅减少）
- `run.py`：`--srt` 额外输出 SRT/VTT 字幕；`--fix-dict` 可选后处理词典（`{"误词":"正确词"}`）
- `run.py`：`--cookie "SESSDATA=xxx"` 支持充电/会员专属视频
- `run.py`：任务元数据写入 `task.json`（视频 / 模型 / 参数 / 原命令），中断后忘了命令也能续跑
- `run.py`：跨块上下文传递——上一块末尾文本拼入下一块 `initial_prompt`，块边界术语保持一致
- `get_audio.py`：音频完整性校验——转码后时长与接口声明比对，偏差 >10% 提示可能被截断
- `merge.py`：`--srt` 输出 SRT/VTT；`--fix-dict` 可选替换词典

### Changed

- `transcribe_chunk.py`：`beam_size` 默认 1 → 5（转写准确率显著提升），语言不再硬编码 `zh`
- `envkit.py`：`MODELS` 的 `rtf8` 依据实测回调（原先偏保守 2-5 倍，预估时间虚高）
- `get_audio.py` / `split.py`：shell 命令中的用户可控输入统一 `shlex.quote()` 防注入
- 全部脚本：文件读写统一 `with open(..., encoding="utf-8")`（原 merge.py 在非 UTF-8 系统上会乱码）
- `envkit.check_url`：异常捕获收窄为 `URLError/OSError`

### Fixed

- `merge.py`：`json.load(open(...))` 未指定 `encoding="utf-8"` 且未关闭句柄
- `ensure_env.py`：docstring 声称支持 `--yes` 但代码从未实现（现明确为兼容标志）
- `README.md`：Python 版本要求 `3.11+` 与代码 `MIN_PY=(3,8)` 不一致
- `run.py` `stage_merge`：文件计数 `startswith("out_")` 会误匹配非 json 文件，改 `glob("out_*.json")`
- `cleanup.py`：`scripts/__pycache__` 相对路径永远命中不了，改为清理脚本目录自身缓存

## [1.3.0] - 2026-08-11

**主题：第一次用就能跑通** —— 一键入口、断点续跑、人话报错、耗时预估。

### Added

- `run.py`：一条命令全流程入口（环境检查 → 模型准备 → 下载音频 → 切分 → 逐块转写 → 合并 → 清理）
- `run.py`：`--dry-run` 只查不跑，提前给出本机核数 / 磁盘 / 视频时长 / 预估耗时
- `run.py`：`--budget N` 限时运行，到点保存进度并以退出码 `75` 退出，重跑同命令即可续跑
- `run.py`：断点续跑，重跑同一条命令时已完成块不重来，模型下载断点续传
- `ensure_env.py`：`--doctor` 完整诊断（硬件 / 网络连通性 / 依赖 / 模型 / 耗时预估 / 下一步命令），`--check` 只检查不安装
- `setup_model.py`：`--auto` 按本机 CPU 核数 / 磁盘自动推荐模型，`--list` 列出各模型占用与本机实测速度
- `setup_model.py`：模型下载失败自动重试（指数退避 5s / 10s），中断保留部分、重试覆盖
- `envkit.py`：硬件感知（CPU 核数 / 内存 / 磁盘探测、模型推荐、线程自适应、网络连通预判），人话报错 `die(reason, fix)`
- `get_audio.py`：`b23.tv` 短链自动展开、BV 号严格解析、`--info` 仅查不下载、`--page N` 多 P 支持
- `QUICKSTART.md`：面向首次使用者的三步上手 + 时间 / 空间预估 + FAQ

### Changed

- `stage_model` 拒绝未知模型名、绝不静默回退到默认模型
- 模型目录按**同名**复用（`LEGACY_DIRS_BY_MODEL`），不再跨模型串用旧路径
- `run.py` 在创建工作目录前先展开短链并解析 BV 号，避免不同视频音频互相覆盖
- 所有失败统一给出「人话原因 + 一行修复命令」，不再把 traceback 甩给用户

### Fixed

- 修复 `--model base` 实际误加载 `large-v3`（`model_dir` 未透传、`stage_model` 静默回退）
- 修复 `setup_model.py base` 误报「模型已存在（large-v3）」（旧版任意请求都复用 large-v3 私有路径）
- 修复弱机被推荐 `large-v3`（`recommend_model` 新增 `MIN_CORES` 核数门控：4 核 → medium、2 核 → small、1 核 → base；磁盘不足时同样降级）
- 修复 `any_model_ready` 在目录扫描时把 base 排在 large-v3 之前导致误判
- 修复 `--budget` 小于单块估时仍跑满整块（新增预算不足告警，条件放宽为「块数 > 1 或已用 ≥ 预算」）

### Removed

- 无

## [1.2.0] - 2026-08-11

**主题：转写不失真** —— 自适应切分、幻觉过滤。

### Added

- `split.py`：静音阈值改为相对 `mean_volume` 自适应四级放宽，切点取静音区间中点，强制块长上限，无静音点时按时长硬切兜底（标记 `cut: hard`）；新增 `--target/--max/--min`
- `merge.py`：幻觉过滤（越界 / 块首尾黑名单短语 / 相邻重复 三规则），新增 `--keep-all`

### Changed

- `split.py`：重写切分算法，不再写死 −30dB 绝对阈值

### Fixed

- 修复高响度视频（`mean_volume` ≈ −19dB）被切成单块、转写无容错的问题
- 修复 Whisper 在块尾静音 / BGM 处凭空生成「中文字幕提供」等水印文本及时间戳越界的问题

## [1.1.0] - 2026-08-11

**主题：不占额外空间** —— 零虚拟环境、共享模型缓存、用完即清。

### Added

- `ensure_env.py`：幂等环境准备，明确复用现有解释器，绝不创建虚拟环境
- `envkit.py`：共享路径解析、磁盘预检、安装封装
- `cleanup.py`：中间产物 / 缓存 / 模型的分级清理
- `setup_model.py`：改用共享缓存目录，自动复用已有权重（含 v1.0.0 私有路径），下载后清理 ModelScope 重复副本
- `transcribe_chunk.py`：提示词改为可配置（修复旧版硬编码专名污染其他领域），新增 `--rm-chunk` 转完即释放
- `split.py`：新增 `--rm-source`，修复短音频（≤30s）切出 0 块导致内容全丢的边界 bug
- 所有 pip 安装统一 `--no-cache-dir`

### Changed

- 模型权重统一放共享缓存 `~/.cache/whisper-models/<模型名>`，跨任务 / 跨技能复用

## [1.0.0] - 2026-08-09

### Added

- 首次发布：B 站 dash 流音频下载 + Whisper 长视频按静音点切分、逐块前台转写 SOP
