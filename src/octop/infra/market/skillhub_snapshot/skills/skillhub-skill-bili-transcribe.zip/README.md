# bili-transcribe · B站视频语音听译技能

> 把 B 站视频音频下载下来，用 Whisper 转写成中文全文，供后续分析使用。
> **v1.1.0 主题：不占额外空间** —— 零虚拟环境、共享模型缓存、用完即清。
> **v1.2.0 主题：转写不失真** —— 自适应切分、幻觉过滤。
> **v1.3.0 主题：第一次用就能跑通** —— 一键入口、断点续跑、人话报错、耗时预估。
> **v1.4.0 主题：质量整改** —— beam_size 5 大幅减少误识、官方字幕直取、SRT 输出、语言可选。
> **v1.5.0 主题：跨平台** —— Windows 与 Linux 虚拟机用法完全一致，一处代码两端跑。
> **v1.6.0 主题：跨平台通用化重构** —— 统一 IO/路径抽象、换行符归一、依赖版本登记、双平台运行说明。
> **v1.7.0 主题：AI 校对环节** —— 转写直出稿质量差的根本解决手段：**独立子代理隔离校对**（主进程只发起+接收，零污染），固化为正式步骤 7。
> **v1.8.0 主题：性能与可用性整改** —— 线程上限放宽至 16、修正「长任务后台」铁律、对接开源通用纠错词典（`--fix-dict oss`，词边界护栏）、dry-run 建议 `-p` 领域术语、BV 号格式校验。

> **跨平台说明**：本技能为**单一代码库双平台通用**，Windows 与 Linux 直接运行同一份
> 代码。双平台依赖安装、构建、验证步骤与测试结果见 **[CROSS_PLATFORM.md](./CROSS_PLATFORM.md)**。

## 特性

- **跨平台通用（v1.5.0/v1.6.0）**：Windows / Linux 同一份代码直接运行。子进程调用全部
  无 shell 列表参数（Windows cmd 不认 POSIX 单引号）；路径全走 `os.path.join` 零硬编码
  分隔符；文件读写统一 UTF-8 + `\n` 换行（两端产物字节级一致）；ffprobe 缺失自动降级
  `ffmpeg -i`；内存/磁盘/ffmpeg 安装全部双平台分支（winget/choco/scoop / apt/dnf）
- **不建虚拟环境**：复用你当前的 Python 解释器（系统或已有 venv 都行），
  不为这个技能单独 venv —— 那会多占 1–3 GB 且与宿主已装的包完全重复
- **模型走共享缓存**：权重统一放 `~/.local/whisper-models/<模型名>`，跨任务、跨技能复用；
  已存在则直接复用，**不重复下载 3 GB**
- **pip 全程 `--no-cache-dir`**：实测漏加时 `~/.cache/pip` 能涨到 5 GB+，比模型还大
- **用完即清**：`cleanup.py` 一键回收中间产物与缓存，默认保留最终转录稿和模型
- **绕过 B站风控**：直接走 `playurl` 接口取 dash 音频流，不依赖 `yt-dlp` 网页抓取
- **模型下载走 ModelScope**：避开 HuggingFace 官方/镜像被墙的坑
- **稳定串行转写**：长视频自动按静音点切分，逐块前台转写（已固化"并行会被沙箱回收 + 并发反而更慢"的经验）
- **自适应切分**：静音阈值随音频实际响度浮动，不写死 −30dB。高响度视频（现代视频普遍响度压满）
  不会再退化成单块；找不到静音点时按时长硬切兜底，块长永不失控
- **幻觉过滤**：自动剔除 Whisper 在块尾静音处凭空生成的"中文字幕提供"类水印文本及越界时间戳段
- **提示词可配置**：按视频主题传领域术语提升准确率，默认通用不污染其他领域
- **一条命令跑全流程（v1.3.0）**：`run.py` 自动串起 环境→模型→下载→切分→转写→合并→清理，
  断点续跑、限时预算、dry-run 预估全部内置
- **首次使用者优先（v1.3.0）**：任何失败都给「人话原因 + 一行修复命令」，绝不甩 traceback；
  任何耗时步骤都先说清楚要下多少、要等多久；下载失败自动重试（指数退避）
- **硬件感知（v1.3.0）**：自动探测 CPU 核数/内存/磁盘，按本机能力 `--auto` 推荐模型、自适应线程数
- **转写质量升级（v1.4.0）**：束搜索宽度默认 5（同音字误识大幅减少）、跨块上下文衔接、
  语言可选（英文/日文视频 `--language en`）、可选后处理词典 `--fix-dict`
- **官方字幕直取（v1.4.0）**：视频若有 CC 字幕则直接下载字幕产出全文，跳过整轮转写
- **SRT/VTT 输出（v1.4.0）**：`--srt` 生成可挂播放器的字幕文件
- **音频完整性校验（v1.4.0）**：下载转码后比对接口声明的时长，截断即提示

## 快速开始

> 第一次用，直接看 **`QUICKSTART.md`** 这一页就够了。

### 最简路径：一条命令

```bash
# 直接跑，run.py 会自己检查环境、按需装依赖和下模型
python3 scripts/run.py "https://www.bilibili.com/video/BVxxxxxxxxx"
```

产物是 `transcript_full.txt`（带时间戳）、`transcript_plain.txt`（纯文本），
`--srt` 会额外生成可直接挂播放器的 SRT/VTT 字幕。
**跑到一半断了？重跑同一条命令即可续跑**，已完成的块不重来，模型下载也会断点续传。
忘了原命令？看工作目录 `.bili_<BV号>/task.json`。

### 稳妥路径：分步跑（看得更清楚）

```bash
# 1. 体检 + 自动补齐依赖（不会创建虚拟环境，用你现有的 Python）
python3 scripts/ensure_env.py

# 2. 下载语音模型（整个流程唯一的大件，只需一次，之后所有任务共用）
python3 scripts/setup_model.py --auto

# 3. 跑一个视频（全自动：查字幕 → 下载音频 → 切分 → 逐块转写 → 合并 → 清理）
python3 scripts/run.py "https://www.bilibili.com/video/BV1apuc6UEir"
```

### 常用选项（run.py）

| 选项 | 用途 |
|---|---|
| `--dry-run` | 只检查和预估耗时（含有无官方字幕提示），不下载不转写 |
| `--model small` | 指定模型（默认按本机 CPU/磁盘自动选） |
| `-p "领域术语"` | 提高专有名词识别准确率 |
| `--language en` | 视频是英文/日文时指定，转写质量显著提升（默认 zh） |
| `--beam-size 1` | 束搜索宽度，默认 5；资源极紧时降 1 |
| `--srt` | 额外输出 SRT/VTT 字幕 |
| `--fix-dict fix.json` | 按词典 `{"误词":"正确词"}` 修正误识别 |
| `--budget 480` | 单次最多跑 480 秒，到点保存进度退出（退出码 **75**），重跑续跑 |
| `--page 2` | 多 P 视频选第 2 P |
| `--cookie "SESSDATA=xxx"` | 充电/会员专属视频登录态（选填） |
| `--keep` | 保留中间文件 |

## 先搞清楚要花多少时间和空间

跑之前先问一句，不打无准备之仗：

```bash
python3 scripts/run.py "<视频链接>" --dry-run
```

它只查不做，会告诉你：本机几核、磁盘剩多少、用哪个模型、**这个视频大概要转多久**。

**空间开销**（一次性，之后不再增长）：

| 项目 | 大小 | 说明 |
|---|---|---|
| 语音模型 | 0.2 – 3.1 GB | 看你选哪个，**所有任务共用一份** |
| Python 依赖 | 约 60 MB | 装进你现有环境，不建虚拟环境 |
| 单个视频中间文件 | 20 – 60 MB | 跑完自动清理 |

**时间开销**：转写是纯 CPU 计算，大致按下表估：

| 机器 | 推荐模型 | 10 分钟视频约需 |
|---|---|---|
| 8 核以上 | large-v3 | 10 分钟 |
| 4 核 | medium | 10 分钟 |
| 2 核 | small | 11 分钟 |

> 进度条走得慢是正常的，不是卡死。`run.py` 每转完一块都会报剩余时间。

## 空间管理速查

| 命令 | 作用 |
|---|---|
| `python3 scripts/ensure_env.py --check` | 只检查环境，不安装（退出码 0 = 齐备） |
| `python3 scripts/ensure_env.py --doctor` | 完整诊断：硬件/网络/依赖/模型/耗时预估 |
| `python3 scripts/setup_model.py --list` | 列出可选模型、磁盘占用、本机实测速度 |
| `python3 scripts/setup_model.py --auto` | 按本机 CPU/磁盘自动挑一个下载 |
| `python3 scripts/setup_model.py --where` | 打印当前会使用的模型目录 |
| `python3 scripts/setup_model.py small` | 磁盘紧张时改用 0.6 GB 小模型 |
| `python3 scripts/run.py "<链接>" --budget 480` | 限时运行（到点退出码 75，可续跑） |
| `python3 scripts/cleanup.py --dry-run` | 预览会清理什么、能回收多少 |
| `python3 scripts/cleanup.py --caches` | 顺带清 pip / 下载缓存（常可回收数 GB） |
| `python3 scripts/cleanup.py --deep` | 连共享模型一起删（下次需重下，慎用） |

环境变量：

- `WHISPER_MODEL_DIR` — 指定模型目录（覆盖自动解析）
- `WHISPER_PROMPT` — 指定转写提示词（等价于 `-p`）
- `CPU_THREADS` — 转写线程数，默认按 CPU 核数自适应（上限 8）

## 依赖

- `ffmpeg`、`python3.8+`（推荐 3.10+）
- Python 包：`faster-whisper`（下载模型时还需 `modelscope`）
- 全部由 `scripts/ensure_env.py` 幂等处理

## 更新日志

> 完整历史（含 Added / Changed / Fixed 分类）见 [CHANGELOG.md](./CHANGELOG.md)，遵循 [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) 与语义化版本规范。

### [1.8.0] - 2026-08-19

**主题：性能与可用性整改** —— 线程上限放宽、后台姿势修正、对接开源通用纠错词典。

- **Added**：线程上限放宽至 `min(核数-1,16)`（多核提速）；内置通用错别字词典 `dicts/oss_zh.json` + `--fix-dict oss`（词边界护栏，防嵌长词误伤）；`--fix-dict oss,my.json` 逗号组合多词典；`--dry-run` 建议 `-p` 领域术语；可选步骤 8 技术类总结模板
- **Changed**：铁律 3 区分「并发多子进程（危险）」与「单进程 `nohup run.py &` 后台（长任务推荐）」；步骤 4 SOP 去掉 `CPU_THREADS=8` 硬编码（默认自动取线程）；自带示例转录稿加头注释防误认
- **Fixed**：BV 号格式校验（非法即给一行修复命令）；词边界替换计数修正
- **备注（暂缓）**：`av` 库解码 fallback、`estimate_rtf` 校准——待确认/更多样本后合入

### [1.7.0] - 2026-08-11

**主题：AI 校对环节（子代理强制隔离）** —— 转写直出稿质量差的根本解决手段。

- **Added**：`SKILL.md` 步骤 7 · AI 校对 —— **独立子代理强制执行**（主进程只发起+接收，不参与校对逻辑，防上下文污染），附完整子代理 briefing 模板；专名还原/同音字/断句标点/术语统一/口语杂质五项校对，产出 `transcript_proofread*` 稿 + 校对说明，拿不准先核实；`run.py` 完成提示引导发起校对
- **Changed**：踩坑铁律 11「人工校订」升级为「AI 校对（正式步骤 7）」

### [1.6.0] - 2026-08-11

**主题：跨平台通用化重构** —— 单一代码库双平台直接运行，统一抽象消除平台分支。

- **Added**：`CROSS_PLATFORM.md` 双平台运行说明（依赖安装/构建/验证 + 测试结果）；`envkit` 统一 IO 抽象（UTF-8 + `\n` 换行，产物双端字节一致）；`default_outdir()` 默认产物目录抽象；依赖版本登记表
- **Changed**：`run.py::sh()` 仅接受列表参数（删字符串 shell 分支，统一单执行路径）；全部 JSON/文本 IO 收敛到 `envkit` 抽象层；`free_gb()` 盘符根用 `os.path.splitdrive + os.sep`；Windows ffmpeg 安装改列表参数无 shell
- **Fixed**：无（v1.5.0 已修功能性问题，本版本为架构收敛）

### [1.5.0] - 2026-08-11

**主题：跨平台** —— Windows 与 Linux 虚拟机行为对齐，用法不再有差异。

- **Added**：Windows 支持（ffmpeg 安装走 winget/choco/scoop；内存走系统 API；磁盘取当前分区；ffprobe 缺失自动降级 `ffmpeg -i` 解析时长）；cleanup 沙箱删除拦截的人话提示
- **Changed**：全部子进程调用从 `shell=True`+`shlex.quote` 改为**无 shell 列表参数**（Windows cmd 不认 POSIX 单引号，实测 curl rc=3）；`have_ffmpeg` 不再强制 ffprobe 同存；产物默认目录 `/workspace` 仅 Linux 使用，Windows 用当前目录；`rm -rf` 修复命令按平台区分
- **Fixed**：cleanup 中间产物 `*.wav.m4s` 被 `*.wav.m4s`/`*.m4s` 双模式重复匹配（去重）；get_audio/split 残留无用 import

### [1.4.0] - 2026-08-11

**主题：质量整改** —— 依据代码审查修复 P0-P4 级问题，重点提升转写质量。

- **Added**：官方字幕直取（有 CC 字幕的视频跳过转写）；`--language` 语言可选；`--beam-size`（默认 5）；`--srt` SRT/VTT 输出；`--fix-dict` 可选纠错词典；`--cookie` 登录态；`task.json` 任务记录；跨块上下文衔接；音频时长完整性校验
- **Changed**：`beam_size` 默认 1→5；RTF 预估按实测回调；shell 命令 `shlex.quote` 加固；文件读写统一 `with + encoding`
- **Fixed**：merge.py 无编码/句柄泄漏；`--yes` 文档与实现不符；README 版本要求不一致；`stage_merge` 误计数；cleanup 无效路径

### [1.3.0] - 2026-08-11

**主题：第一次用就能跑通** —— 一键入口、断点续跑、人话报错、耗时预估。

- **Added**：`run.py` 一条命令全流程 + `--dry-run` 预估 + `--budget`（退出码 75）限时续跑；`ensure_env.py --doctor` 人话体检；`setup_model.py --auto/--list` 自动推荐与重试；`get_audio.py` 短链展开 / 多 P；`QUICKSTART.md`
- **Changed**：`stage_model` 拒绝未知模型、绝不静默回退；模型目录按同名复用；短链在工作目录创建前展开
- **Fixed**：`--model base` 误加载 large-v3；`setup_model base` 误报已存在；弱机被推 large-v3；`any_model_ready` 误判；`--budget` 跑满整块

### [1.2.0] - 2026-08-11

**主题：转写不失真** —— 自适应切分、幻觉过滤。

- **Added**：`split.py` 自适应四级阈值 + 硬切兜底；`merge.py` 幻觉过滤（越界 / 黑名单 / 重复）
- **Fixed**：高响度视频退化为单块；块尾凭空生成"中文字幕提供"水印及时间戳越界

### [1.1.0] - 2026-08-11

**主题：不占额外空间** —— 零虚拟环境、共享模型缓存、用完即清。

- **Added**：`ensure_env.py` / `envkit.py` / `cleanup.py`；共享缓存；`--no-cache-dir`；`transcribe_chunk` 提示词可配置；`split --rm-source`
- **Changed**：模型权重统一放 `~/.local/whisper-models/<模型名>`

### [1.0.0] - 2026-08-09

- **Added**：B 站 dash 流音频下载 + Whisper 长视频按静音点切分、逐块前台转写 SOP

## 许可证

MIT
