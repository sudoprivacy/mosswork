# -*- coding: utf-8 -*-
"""
消防规范在线路由（gf.cabr-fire.com）—— 离线检索 + 按需定向抓取

子命令：
  code <编号>           按标准编号查（仅本地目录，不联网）
  kw  <关键词> [<关键词>] 按关键词查（名称包含，任一命中）
  fetch <list-ID> [...]  按需定向抓取单本规范全文（联网，落本地 cache）
                        多个 list-ID 空格分隔
                        --force 覆盖已有缓存
                        --list-page-debug 输出 list 页解析结果到 stdout
  help                   显示本帮助

数据源：references/_fire_codes_online.json（抓取自消防规范网，2026-09-04）

缓存位置：<skill>/cache/fire_online_fetched/<list-ID>_<name>.md
按需缓存，不入 skill 包分发。

设计意图（万工红线）：
  - 不囤全量正文（违背"不背条文、按需取证"原则）
  - 用户设计需要某本规范的具体条文时，立即 fetch 即得，取完即用
  - 目录保持全量（零成本，1992 条路由表）
"""
import json, os, sys, re, ssl, time, urllib.request, html as ihtml, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
REFS = os.path.join(HERE, "..", "references")
DB = os.path.join(REFS, "_fire_codes_online.json")
TOC_PRIORITY = os.path.normpath(os.path.join(HERE, "..", "..", "..", "books", "cabr-fire", "corpus", "toc_priority.json"))
CACHE = os.path.join(HERE, "..", "cache", "fire_online_fetched")
BASE = "https://gf.cabr-fire.com"


def _ctx():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try: ctx.set_ciphers('DEFAULT@SECLEVEL=1')
    except Exception: pass
    return ctx


def _get(url, retry=3):
    ua = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) fire_online.py'}
    for i in range(retry):
        try:
            r = urllib.request.Request(url, headers=ua)
            return urllib.request.urlopen(r, timeout=45, context=_ctx()).read()
        except Exception:
            if i == retry - 1: return None
            time.sleep(1.5 * (i + 1))


def _dec(b):
    for e in ('utf-8', 'gbk', 'gb18030'):
        try: return b.decode(e)
        except Exception: pass
    return b.decode('utf-8', 'ignore')


# ---------- 检索（离线） ----------

def cmd_code(entries, args):
    q = args[0].upper().replace(" ", "")
    hits = [e for e in entries if e["code"].upper().replace(" ", "").startswith(q)]
    _print_hits(hits, entries)


def cmd_kw(entries, args):
    hits = [e for e in entries if any(k in e["name"] for k in args)]
    _print_hits(hits, entries)


def _print_hits(hits, entries, label="命中"):
    print(f"{label} {len(hits)} 条 / 全库 {len(entries)} 条\n")
    for e in hits[:60]:
        print("%-12s %s" % (e["code"] or "—", e["name"]))
        print("             %s" % e["url"])
    if len(hits) > 60:
        print(f"\n... 另有 {len(hits) - 60} 条，请细化关键词")


# ---------- 按需定向抓取（联网） ----------

def _load_toc_priority():
    """从多个候选位置加载 toc_priority.json（优先清单及其 articles URL 表）。

    不阻塞——若无文件返回 {}；fetch 会全部走 list-page 解析（多一次 HTTP，但功能完整）。
    env var WANGOING_CABRFIRE_TOC 可显式覆盖。
    """
    candidates = []
    env = os.environ.get("WANGOING_CABRFIRE_TOC", "").strip()
    if env: candidates.append(env)
    candidates += [
        # skill 内部
        os.path.join(REFS, "_toc_priority.json"),
        # 项目级 books/ 上溯 4 层（支持 .workbuddy/skills/<skill>/scripts 在 WorkBuddy 项目根 books/ 之下）
        os.path.normpath(os.path.join(HERE, "..", "..", "..", "..", "books", "cabr-fire", "corpus", "toc_priority.json")),
        os.path.normpath(os.path.join(HERE, "..", "..", "..", "books", "cabr-fire", "corpus", "toc_priority.json")),
    ]
    for c in candidates:
        if c and os.path.exists(c):
            try: return json.load(open(c, encoding="utf-8"))
            except Exception: continue
    return {}


def _find_articles_from_list_page(list_id):
    """查 toc_priority 没有的 list-ID → 抓 gf.cabr-fire.com/list-<id>.htm 解析其文章列表。

    返回 (label, articles, error)。
    label 从列表页 h1 / title / crumbs 提取规范真实名称；解析失败则用 "list-<id>" 兜底。
    """
    url = f"{BASE}/list-{list_id}.htm"
    body = _get(url)
    if not body:
        return None, None, f"无法访问列表页: {url}"
    html = _dec(body)
    # 1) 标题：优先级 h1.title > h1 > <title>
    label = None
    for pat, group in [
        (r'<h1[^>]*class=["\'][^"\']*\btitle\b[^"\']*["\'][^>]*>(.*?)</h1>', 1),
        (r'<h1[^>]*>(.*?)</h1>', 1),
        (r'<title[^>]*>(.*?)</title>', 1),
    ]:
        m = re.search(pat, html, flags=re.S | re.I)
        if not m: continue
        t = re.sub(r'<[^>]+>', '', m.group(group)).strip()
        t = re.sub(r'\s+', ' ', t)
        # 站点 title 常含"住房城乡建设部关于印发《...》的通知（建科规〔2020〕5号） - 站点名"
        # 优先抓《》内文作为规范名
        book = re.search(r'《([^》]+)》', t)
        if book and 3 < len(book.group(1)) < 80:
            label = book.group(1).strip()
            break
        # 去掉站点后缀
        t2 = re.sub(r'\s*[-_]\s*(中国建筑科学研究院|消防规范网|消防规范).*$', '', t).strip()
        t2 = re.sub(r'（\s*\d{4,4}\s*号.*$', '', t2).strip()  # 去掉文号
        t2 = re.sub(r'(关于.*通知)$', '', t2).strip()
        if 4 < len(t2) < 60:
            label = t2
            break
    if not label:
        label = f"list-{list_id}"
    # 2) 章节列表
    arts = []
    for m in re.finditer(r'<a[^>]+href=[\'"](?:https?://gf\.cabr-fire\.com/)?article-(\d+)\.htm[\'"][^>]*>(.*?)</a>', html, flags=re.S | re.I):
        aid = m.group(1)
        title = re.sub(r'<[^>]+>', '', m.group(2)).strip()
        title = re.sub(r'\s+', ' ', title)
        if not title or len(title) < 2:
            continue
        arts.append({"aid": aid, "title": title[:80], "url": f"{BASE}/article-{aid}.htm"})
    # 去重保序
    seen = set(); uniq = []
    for a in arts:
        if a["aid"] in seen: continue
        seen.add(a["aid"]); uniq.append(a)
    return label, uniq, None


def _extract_bcon(html):
    m = re.search(r'<div[^>]*class=["\'][^"\']*\bb_con\b[^"\']*["\'][^>]*>', html)
    if not m: return None
    start = m.end(); depth = 1; i = start; n = len(html)
    while i < n and depth > 0:
        nd = html.find('<div', i); cd = html.find('</div', i)
        if cd == -1: break
        if nd != -1 and nd < cd:
            depth += 1; i = nd + 4
        else:
            depth -= 1; i = cd + 5
    seg = html[start:i - 5] if depth == 0 else html[start:start + 20000]
    return seg


def _seg_to_text(seg):
    s = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', seg, flags=re.S | re.I)
    s = re.sub(r'<br\s*/?>', '\n', s, flags=re.I)
    s = re.sub(r'</(p|div|li|tr|h\d)>', '\n', s, flags=re.I)
    s = re.sub(r'<[^>]+>', '', s)
    s = ihtml.unescape(s)
    s = s.replace('\u3000', ' ')
    s = re.sub(r'[ \t]+', ' ', s)
    lines = [l.strip() for l in s.split('\n')]
    return '\n'.join([l for l in lines if l])


def _safe_name(s):
    return re.sub(r'[\\/:*?"<>|]', '_', s)[:80]


def cmd_fetch(entries, args):
    if not args:
        print("用法：fetch <list-ID> [list-ID...] [--force] [--list-page-debug]"); return
    force = '--force' in args
    if force: args = [a for a in args if a != '--force']
    debug = '--list-page-debug' in args
    if debug: args = [a for a in args if a != '--list-page-debug']
    if not args:
        print("fetch 需要至少一个 list-ID"); return

    os.makedirs(CACHE, exist_ok=True)
    toc = _load_toc_priority()
    grand = {"ok": 0, "empty": 0, "fail": 0, "skipped": 0}

    for list_id in args:
        print(f"\n=== list-{list_id} ===")
        # 优先从 toc_priority 取 articles；否则按需解析列表页
        if list_id in toc:
            label = toc[list_id].get("label", f"list-{list_id}")
            arts = toc[list_id].get("articles", [])
            source = "toc_priority (优先清单)"
        else:
            label, arts, err = _find_articles_from_list_page(list_id)
            if err:
                print(f"  🔴 {err}"); grand["fail"] += 1; continue
            source = "list-page 按需解析"
        if not arts:
            print(f"  ⚠️ 解析到 0 个 article"); grand["empty"] += 1; continue
        print(f"  label: {label}")
        print(f"  articles: {len(arts)} ({source})")

        fn = os.path.join(CACHE, f"{list_id}_{_safe_name(label)}.md")
        if os.path.exists(fn) and not force:
            print(f"  ⚠️ 已缓存 → {fn}（用 --force 覆盖）")
            grand["skipped"] += 1
            continue

        buf = [f"# {label}\n",
               f"> 来源：消防规范网 {BASE}/list-{list_id}.htm",
               f"> 抓取日期：{datetime.date.today()}　方式：按需定向抓取（fire_online.py fetch）",
               f"> 置信度：中——网站条文为第三方整理，引用前须回国家标准正版原文核验\n",
               f"## 章节列表（{len(arts)}）\n"]
        for a in arts:
            buf.append(f"- [{a['title']}]({a['url']})")
        buf.append("\n## 条文正文\n")
        ok = empty = fail = 0
        for i, a in enumerate(arts, 1):
            d = _get(a["url"])
            if not d:
                fail += 1
                buf.append(f"\n### {a['title']}\n\n（抓取失败）\n")
                continue
            html = _dec(d)
            seg = _extract_bcon(html)
            if not seg:
                fail += 1
                buf.append(f"\n### {a['title']}\n\n（无 b_con 容器）\n")
                continue
            txt = _seg_to_text(seg)
            if len(txt) < 2:
                empty += 1
                continue
            ok += 1
            buf.append(f"\n### {a['title']}\n\n`{a['url']}`\n\n{txt}\n")
            if i % 5 == 0 or i == len(arts):
                print(f"  进度 {i}/{len(arts)} (ok={ok} empty={empty} fail={fail})")
                sys.stdout.flush()
            time.sleep(0.2)
        with open(fn, "w", encoding="utf-8") as f:
            f.write('\n'.join(buf))
        print(f"  💾 → {fn}")
        grand["ok"] += ok; grand["empty"] += empty; grand["fail"] += fail
        if debug:
            print(f"  --debug: 第 1 条 = {arts[0]}")

    print(f"\n=== 汇总 ===")
    print(f"  ok article={grand['ok']}  empty={grand['empty']}  fail={grand['fail']}  skipped(已缓存)={grand['skipped']}")
    print(f"  cache 目录: {CACHE}")


def cmd_help():
    print(__doc__)


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("help", "-h", "--help"):
        cmd_help(); return
    mode = sys.argv[1]
    args = sys.argv[2:]
    # fetch / fetch-status 不需要本地 entries
    if mode not in ("fetch", "fetch-status"):
        if not os.path.exists(DB):
            print(f"❌ 找不到本地目录: {DB}"); sys.exit(1)
        entries = json.load(open(DB, encoding="utf-8"))["entries"]
    else:
        entries = []

    if mode == "code":
        if not args: print("code 需要一个编号"); return
        cmd_code(entries, args)
    elif mode == "kw":
        if not args: print("kw 需要至少一个关键词"); return
        cmd_kw(entries, args)
    elif mode == "fetch":
        cmd_fetch(entries, args)
    elif mode == "fetch-status":
        if not os.path.isdir(CACHE):
            print(f"无缓存目录: {CACHE}"); return
        files = sorted(os.listdir(CACHE))
        if args and args[0] == "--prune":
            # 删"旧命名"的孤立缓存（形如 <id>_list-<id>.md 已被新命名取代）
            keep = []
            removed = []
            # 同 list-ID 下：保留规范名更长的（即含真实名称的）
            by_id = {}
            for f in files:
                m = re.match(r'^(\d+)_(.+)\.md$', f)
                if not m: continue
                by_id.setdefault(m.group(1), []).append((f, len(m.group(2))))
            for fid, versions in by_id.items():
                versions.sort(key=lambda x: -x[1])
                for f, _ in versions[1:]:
                    p = os.path.join(CACHE, f)
                    sz = os.path.getsize(p)
                    os.remove(p)
                    removed.append(f"  🗑️ {f} ({sz} B)")
                if versions:
                    keep.append(versions[0][0])
            print(f"保留 {len(keep)} 个有效缓存：")
            for f in keep:
                sz = os.path.getsize(os.path.join(CACHE, f))
                print(f"  ✅ {f}  ({sz} B)")
            print(f"\n清理 {len(removed)} 个冗余：")
            for r in removed:
                print(r)
            return
        total_bytes = 0
        for f in files:
            p = os.path.join(CACHE, f); sz = os.path.getsize(p); total_bytes += sz
            print(f"  {f}  ({sz} B)")
        print(f"\n  共 {len(files)} 个文件，{total_bytes} B = {total_bytes/1024:.1f} KB")
        print(f"\n  tip: fetch-status --prune  可清理旧命名的冗余缓存")
    else:
        cmd_help()


if __name__ == "__main__":
    main()
