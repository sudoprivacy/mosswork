#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 版本：4.0.0 ｜ 更新：2026-08-31 ｜ 同源：books/_wpsbridge/wps_bridge.py（四 skill 共用同一份，勿单改）
"""
wps_bridge.py v2 — 万工-* skill 的 WPS/Office 增强模块（产出引擎）
====================================================================
在 v1（四引擎识别/自动重试/硬件自适应/docx-pptx生成/PDF导出）基础上，
v2 重构吸收了 7 类创作 skill 的方法论：

  [公文排版] 党政机关公文标准排版 Pro（GB/T 9704-2012）→ docx --style gongwen
  [标书排版] 同上 + 投标文件惯例                          → docx --style bid
  [PPT设计]  PPT Generator / Slide maker 的配色与页面规范   → ppt --theme + --closing
  [文字提取] PDF和图片文字提取（含扫描页 OCR）             → extract
  [视觉自检] Slide maker 的渲染检查 + PPT Generator 禁止项  → check
  [内容规划] 一页一主题 / 3秒法则 / 视觉层次                → SKILL.md 规范

引擎顺序：WPS COM → MS Office COM → LibreOffice → 纯 Python（自动探测）。

用法（在 skill 目录下执行）：
    python scripts/wps_bridge.py engine-info                      # 引擎 + 硬件
    python scripts/wps_bridge.py outline --sample                 # outline JSON 模板
    python scripts/wps_bridge.py docx --input o.json --output 设计说明.docx [--style gongwen|bid|default]
    python scripts/wps_bridge.py ppt  --input o.json --output 方案.pptx --size a3 --theme tech [--closing]
    python scripts/wps_bridge.py export --file 设计说明.docx --format pdf
    python scripts/wps_bridge.py extract --file 扫描版.pdf --out 提取.md [--pages 1-20]
    python scripts/wps_bridge.py check  --file 方案.pptx          # 视觉自检（溢出/字号/默认蓝）

outline JSON 结构（路由取证后由 AI 组装）：
{
  "title": "xxx项目 设计说明", "subtitle": "项目全称",
  "meta": {"单位": "xxx", "专业": "建筑", "日期": "2026-08-31"},
  "sections": [
    {"heading": "1 设计依据", "level": 1,
     "paragraphs": ["……"], "bullets": ["……"],
     "table": {"headers": ["条款", "内容"], "rows": [["……", "……"]]},
     "citations": [{"source": "GB 55037-2022", "clause": "第3.2.1条", "page": "p12"}]}
  ]
}
citations 以「依据：source clause（page）」灰字小注落进文档，保证引用可溯源。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time

# 延迟依赖：无 python-pptx 的环境（如仅跑 engine-info）仍可导入本模块；
# 真正的排版函数只在 build_pptx 内部且 python-pptx 可用时被调用。
try:
    from pptx.dml.color import RGBColor
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import PP_ALIGN
    from pptx.util import Cm, Emu, Inches, Mm, Pt
except Exception:  # noqa: BLE001
    Cm = Inches = Mm = Pt = Emu = RGBColor = MSO_SHAPE = PP_ALIGN = None

# ---------- 常量 ----------
GRAY = "808080"
DARK = "333333"
ACCENT = "1F4E79"

HARDWARE_GRADE = {"high": (30, 8), "medium": (60, 4), "low": (120, 1)}

# ---------- docx 排版预设（吸收 GB/T 9704-2012 与投标文件惯例） ----------
DOCX_STYLES = {
    "default": {  # 设计说明默认：黑体标题 + 宋体正文
        "label": "设计说明（默认）",
        "title": ("黑体", 18), "subtitle": ("楷体", 14),
        "h1": ("黑体", 15), "h2": ("黑体", 13), "h3": ("黑体", 12),
        "body": ("宋体", 12), "bullet": ("宋体", 12), "table": ("宋体", 10.5),
        "line_spacing": 1.5, "first_indent_cm": 0.74,
    },
    "gongwen": {  # 党政机关公文（简化 GB/T 9704-2012）
        "label": "公文（GB/T 9704-2012 简化）",
        "title": ("方正小标宋简体", 22),  # 二号
        "h1": ("黑体", 16),               # 一级标题 黑体三号
        "h2": ("楷体_GB2312", 16),        # 二级标题 楷体三号
        "h3": ("仿宋_GB2312", 16),        # 三级标题 仿宋三号（加粗）
        "body": ("仿宋_GB2312", 16),      # 正文 仿宋三号
        "bullet": ("仿宋_GB2312", 16),
        "table": ("仿宋_GB2312", 12),
        "line_spacing": 28.0,             # 行距 28 磅
        "first_indent_cm": 1.13,          # 三号字 2 字符 ≈ 1.13cm
        "title_spacing": (18, 18),        # 标题段前/段后
    },
    "bid": {  # 投标文件/技术标书
        "label": "标书（技术标惯例）",
        "title": ("黑体", 22),            # 二号
        "h1": ("黑体", 16),               # 三号
        "h2": ("黑体", 14),               # 四号
        "h3": ("黑体", 12),               # 小四
        "body": ("宋体", 12),             # 小四宋体
        "bullet": ("宋体", 12),
        "table": ("宋体", 10.5),
        "line_spacing": 1.5,
        "first_indent_cm": 0.85,          # 小四 2 字符
    },
}

# ---------- PPT 主题配色（吸收 PPT Generator 配色方案） ----------
THEMES = {
    "midnight": {"label": "午夜商务", "bg": "FFFFFF", "primary": "1E2761", "accent": "CADCFC", "text": "2F3542", "dark": False},
    "coral":    {"label": "珊瑚活力", "bg": "FFFFFF", "primary": "F96167", "accent": "F9E795", "text": "2F3C7E", "dark": False},
    "ocean":    {"label": "海洋渐变", "bg": "FFFFFF", "primary": "065A82", "accent": "1C7293", "text": "21295C", "dark": False},
    "green":    {"label": "青绿信任", "bg": "FFFFFF", "primary": "028090", "accent": "02C39A", "text": "03343B", "dark": False},
    "sage":     {"label": "鼠尾草静", "bg": "FFFFFF", "primary": "50808E", "accent": "84B59F", "text": "3A4A50", "dark": False},
    "charcoal": {"label": "炭灰极简", "bg": "FFFFFF", "primary": "36454F", "accent": "A7BEAE", "text": "212121", "dark": False},
    "tech":     {"label": "科技深空", "bg": "0D1117", "primary": "58A6FF", "accent": "1F6FEB", "text": "E6EDF3", "dark": True},
    "premium":  {"label": "高端黑金", "bg": "111111", "primary": "D4AF37", "accent": "8B6F2E", "text": "F2F2F2", "dark": True},
}
DEFAULT_THEME = "midnight"

# ---------- 公文要素（吸收《公文写作》skill：文种/关系/格式/收束语） ----------
# 文种 → 收束语 + 行文关系 + 纪律提示
DOC_KINDS = {
    "通知": {"close": "请结合实际认真抓好落实，并于〔日期〕前将有关情况报〔单位〕。",
            "rel": "下行/平行", "rule": "明确对象、事项、责任、时限；平行通知避免命令口吻"},
    "通报": {"close": "请各单位举一反三，切实整改。", "rel": "下行", "rule": "事实准确，评价克制，避免情绪化"},
    "报告": {"close": "特此报告。", "rel": "上行", "rule": "不夹带请示事项"},
    "请示": {"close": "妥否，请批示。", "rel": "上行", "rule": "一文一事，一般只送一个主送机关"},
    "批复": {"close": "此复。", "rel": "下行", "rule": "明确同意/不同意及依据，不含糊"},
    "函":   {"close": "专此函达，盼复。", "rel": "平行", "rule": "语气平等礼貌，不命令"},
    "纪要": {"close": "请各参会单位按议定事项抓好落实。", "rel": "内部", "rule": "写会议认为/指出/要求，不写流水账"},
    "决定": {"close": "本决定自印发之日起施行。", "rel": "下行", "rule": "权威明确，适合较重大事项"},
    "通告": {"close": "本通告自发布之日起施行。", "rel": "面向社会", "rule": "条款清楚，面向特定范围"},
    "公告": {"close": "特此公告。", "rel": "面向国内外", "rule": "事项级别高，慎用"},
    "意见": {"close": "请结合实际贯彻落实。", "rel": "上行/下行/平行", "rule": "政策性较强，背景意义+总体要求+具体意见"},
    "方案": {"close": "各责任单位要按职责分工抓好落实，重要情况及时报告。",
            "rel": "下行", "rule": "目标+重点任务+实施步骤+责任分工+保障措施"},
    "总结": {"close": None, "rel": "上行/内部", "rule": "总体情况+主要做法+成效经验+问题不足+下步安排"},
}

# ---------- 去AI味词库（吸收《公文写作》humanizer pass +《完美复刻》禁用清单） ----------
AI_TELLS = {
    "抽象词堆叠": ["赋能", "生态", "动能", "闭环", "抓手", "体系", "格局", "协同",
                   "提质增效", "走深走实", "落地见效", "凝心聚力", "久久为功",
                   "高质量发展", "新局面", "新篇章", "新台阶"],
    "意义膨胀": ["具有重要意义", "标志着", "彰显了", "充分体现了", "充分展现了",
                 "极大地", "深刻地", "全面开创", "历史性成就", "重大突破"],
    "宣传腔": ["亮点纷呈", "成效斐然", "精彩纷呈", "焕发活力", "蓬勃发展", "蒸蒸日上"],
    "模糊主体": ["相关部门", "有关单位", "有关方面", "重点领域", "关键环节",
                 "群众普遍认为", "社会反响良好", "大家一致认为"],
    "元话语": ["下面从", "本文将从", "接下来从", "让我们", "本文将", "以下是"],
    "万能结尾": ["谱写新篇章", "开创新局面", "再上新台阶", "未来可期", "砥砺前行", "奋力谱写"],
    "虚动词": ["扎实推进", "全面加强", "深入开展", "持续强化", "不断优化", "大力推动"],
    # 复用副词：公文/正式文本高频复用，属正常表达，仅作 🟡 提示（避免同一词高频堆叠），绝不判 🔴
    "复用副词": ["进一步", "持续", "不断", "全面", "切实", "有效", "逐步", "着力",
                "深入", "扎实", "更加", "愈发", "相继", "日益"],
}
# 判断强度分级（证据不足时降级）
JUDGMENT_LEVELS = [
    (5, ["重大突破", "历史性成就", "开创性"]),
    (4, ["取得明显成效", "形成机制", "显著成效"]),
    (3, ["取得进展", "初见成效", "阶段性成果"]),
    (2, ["有序推进", "稳步推进"]),
    (1, ["已启动", "正在开展"]),
]


# ---------- 工具 ----------
def eprint(*a):
    print(*a, file=sys.stderr)


def retry(fn, tries=3, base=1.0, label=""):
    """自动重试：1s → 2s → 4s 指数退避"""
    last = None
    for i in range(tries):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001
            last = e
            if i < tries - 1:
                eprint(f"[wps_bridge] {label}失败({type(e).__name__})，{base * (2 ** i):.0f}s 后重试 {i + 1}/{tries - 1}…")
                time.sleep(base * (2 ** i))
    raise last


def hardware():
    """硬件自适应：返回 (等级, 超时秒, 线程数)"""
    cpus = os.cpu_count() or 4
    mem_gb = None
    try:
        import ctypes

        class _MS(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        m = _MS()
        m.dwLength = ctypes.sizeof(_MS)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            mem_gb = m.ullTotalPhys / 1024 ** 3
    except Exception:  # noqa: BLE001
        pass
    if cpus >= 8 and (mem_gb is None or mem_gb >= 16):
        grade = "high"
    elif cpus >= 4 and (mem_gb is None or mem_gb >= 8):
        grade = "medium"
    else:
        grade = "low"
    timeout, threads = HARDWARE_GRADE[grade]
    return grade, timeout, threads, cpus, mem_gb


def detect_engines():
    """四引擎探测：{wps, ms, libre, pure}"""
    res = {"wps": False, "ms": False, "libre": False, "pure": False}
    try:
        import win32com.client  # noqa: F401
    except Exception:  # noqa: BLE001
        win32com_client = None
    else:
        win32com_client = win32com.client

        def _probe(progids):
            for p in progids:
                try:
                    app = win32com_client.Dispatch(p)
                    try:
                        app.Quit()
                    except Exception:  # noqa: BLE001
                        pass
                    return True
                except Exception:  # noqa: BLE001
                    continue
            return False

        res["wps"] = _probe(["kwps.Application", "ket.Application", "kwpp.Application"])
        res["ms"] = _probe(["Word.Application", "Excel.Application", "PowerPoint.Application"])
    for exe in ("soffice", "libreoffice"):
        if shutil.which(exe):
            res["libre"] = True
    try:
        import docx  # noqa: F401
        import pptx  # noqa: F401

        res["pure"] = True
    except Exception:  # noqa: BLE001
        pass
    return res


# ---------- 中文字体辅助 ----------
def _set_font(run, name="宋体", size=12, bold=False, italic=False, color=None):
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor

    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _add_footer_page_number(doc, size=9):
    """页脚右下角页码（PAGE 域，WPS/Word 打开即显示）"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    footer = doc.sections[0].footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run()
    f1 = OxmlElement("w:fldChar"); f1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    f2 = OxmlElement("w:fldChar"); f2.set(qn("w:fldCharType"), "end")
    run._r.append(f1); run._r.append(it); run._r.append(f2)
    _set_font(run, name="宋体", size=size, color=GRAY)


# ---------- docx 生成 ----------
def build_docx(outline, out_path, style="default", footer_page=True, doctype=""):
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt

    if style == "gongwen":
        # v3：--style gongwen 走完整公文要素排版（红头/字号/主送/收束语/落款/抄送）
        # doctype 手动指定文种时覆盖 outline.doc_kind，决定收束语与文种纪律
        return build_gongwen_docx(outline, out_path, doctype=doctype)
    st = DOCX_STYLES.get(style, DOCX_STYLES["default"])
    doc = Document()
    for s in doc.sections:
        s.top_margin = Cm(2.54)
        s.bottom_margin = Cm(2.54)
        s.left_margin = Cm(3.0)
        s.right_margin = Cm(2.6)

    t_font, t_size = st["title"]
    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t.paragraph_format.space_before = Pt(24)
    t.paragraph_format.space_after = Pt(18)
    _set_font(t.add_run(outline.get("title", "设计说明")), name=t_font, size=t_size, bold=True, color=DARK)
    if outline.get("subtitle"):
        st_font, st_size = st.get("subtitle", ("楷体", 14))
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_font(p.add_run(outline["subtitle"]), name=st_font, size=st_size, color="595959")
    meta = outline.get("meta") or {}
    if meta:
        mt = doc.add_paragraph()
        mt.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_font(mt.add_run("　".join(f"{k}：{v}" for k, v in meta.items())), name="宋体", size=10.5, color=GRAY)

    for sec in outline.get("sections", []):
        lv = int(sec.get("level", 1))
        key = f"h{min(lv, 3)}"
        h_font, h_size = st[key]
        h = doc.add_paragraph()
        h.paragraph_format.space_before = Pt(12)
        h.paragraph_format.space_after = Pt(6)
        _set_font(h.add_run(sec.get("heading", "")), name=h_font, size=h_size,
                  bold=(lv <= 2 or key == "h3"), color=ACCENT if (lv == 1 and style == "default") else DARK)
        for para in sec.get("paragraphs", []):
            p = doc.add_paragraph()
            p.paragraph_format.first_line_indent = Cm(st["first_indent_cm"])
            p.paragraph_format.line_spacing = st["line_spacing"]
            b_font, b_size = st["body"]
            _set_font(p.add_run(para), name=b_font, size=b_size, color=DARK)
        for b in sec.get("bullets", []):
            bp = doc.add_paragraph(style="List Bullet")
            bt_font, bt_size = st["bullet"]
            _set_font(bp.add_run(b), name=bt_font, size=bt_size, color=DARK)
        tb = sec.get("table")
        if tb and tb.get("headers"):
            tbl = doc.add_table(rows=1, cols=len(tb["headers"]))
            tbl.style = "Table Grid"
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            hdr = tbl.rows[0].cells
            for i, htxt in enumerate(tb["headers"]):
                hp = hdr[i].paragraphs[0]
                hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
                _set_font(hp.add_run(str(htxt)), name="黑体", size=10.5, bold=True, color="FFFFFF")
                shd = hdr[i]._tc.get_or_add_tcPr().makeelement(
                    "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}shd", {})
                shd.set("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val", "clear")
                shd.set("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}fill", ACCENT)
                hdr[i]._tc.get_or_add_tcPr().append(shd)
            for row in tb.get("rows", []):
                cells = tbl.add_row().cells
                for j, val in enumerate(row):
                    if j >= len(cells):
                        break
                    tb_font, tb_size = st["table"]
                    _set_font(cells[j].paragraphs[0].add_run(str(val)), name=tb_font, size=tb_size, color=DARK)
        for cit in sec.get("citations", []):
            cp = doc.add_paragraph()
            cp.paragraph_format.left_indent = Cm(0.5)
            txt = "◆ 依据：" + " ".join(str(cit.get(k, "")).strip() for k in ("source", "clause", "page") if cit.get(k))
            _set_font(cp.add_run(txt), name="宋体", size=9, italic=True, color=GRAY)

    if footer_page:
        _add_footer_page_number(doc)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    doc.save(out_path)
    return out_path


# ---------- 公文完整排版（吸收 GB/T 9704-2012 +《公文写作》文种规范） ----------
def _add_red_line(par, color="FF0000", size="12"):
    """红旗分隔线（段落下边框，红色单线）"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    pPr = par._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), size)
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color)
    pbdr.append(bottom)
    pPr.append(pbdr)


def build_gongwen_docx(outline, out_path, doctype=""):
    """完整公文排版：红头→发文字号→红旗线→标题→主送机关→正文→收束语→附件→落款→日期→附注→抄送"""
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt

    FS, FS_B = "仿宋_GB2312", "黑体"          # 正文仿宋、一级标题黑体
    KT = "楷体_GB2312"                        # 二级标题楷体
    XBS = "方正小标宋简体"                     # 标题小标宋
    BODY_PT, TITLE_PT, H_PT = 16, 22, 16      # 三号=16pt 二号=22pt

    doc = Document()
    for s in doc.sections:
        s.top_margin, s.bottom_margin = Cm(3.7), Cm(3.5)
        s.left_margin, s.right_margin = Cm(2.8), Cm(2.6)

    def P(align=WD_ALIGN_PARAGRAPH.LEFT, before=0, after=0, indent=None, spacing=None):
        p = doc.add_paragraph()
        p.alignment = align
        p.paragraph_format.space_before = Pt(before)
        p.paragraph_format.space_after = Pt(after)
        if indent:
            p.paragraph_format.first_line_indent = Cm(indent)
        if spacing:
            p.paragraph_format.line_spacing = spacing
        return p

    # 1 红头（发文机关标志）
    if outline.get("redhead"):
        p = P(WD_ALIGN_PARAGRAPH.CENTER, after=6)
        _set_font(p.add_run(outline["redhead"]), name=XBS, size=TITLE_PT + 4, bold=True, color="FF0000")
    # 2 发文字号
    if outline.get("doc_number"):
        p = P(WD_ALIGN_PARAGRAPH.CENTER, after=4)
        _set_font(p.add_run(outline["doc_number"]), name=FS, size=BODY_PT, color=DARK)
    # 3 红旗线
    if outline.get("redhead") or outline.get("doc_number"):
        _add_red_line(P(after=10))
    # 4 标题（发文机关+关于+事由+的+文种）
    p = P(WD_ALIGN_PARAGRAPH.CENTER, before=6, after=14)
    _set_font(p.add_run(outline.get("title", "")), name=XBS, size=TITLE_PT, bold=True, color=DARK)
    # 5 主送机关（顶格+冒号）
    if outline.get("recipient"):
        p = P(after=6)
        _set_font(p.add_run(outline["recipient"]), name=FS, size=BODY_PT, color=DARK)
    # 6 正文
    for sec in outline.get("sections", []):
        lv = min(int(sec.get("level", 1)), 3)
        hname = FS_B if lv == 1 else (KT if lv == 2 else FS)
        p = P(before=8, after=4, indent=1.13, spacing=Pt(28))
        _set_font(p.add_run(sec.get("heading", "")), name=hname, size=H_PT,
                  bold=(lv == 3), color=DARK)
        for para in sec.get("paragraphs", []):
            p = P(indent=1.13, spacing=Pt(28))
            _set_font(p.add_run(para), name=FS, size=BODY_PT, color=DARK)
        for b in sec.get("bullets", []):
            p = P(indent=1.13, spacing=Pt(28))
            _set_font(p.add_run("　　" + b), name=FS, size=BODY_PT, color=DARK)
        tb = sec.get("table")
        if tb and tb.get("headers"):
            tbl = doc.add_table(rows=1, cols=len(tb["headers"]))
            tbl.style = "Table Grid"
            tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
            for i, htxt in enumerate(tb["headers"]):
                c = tbl.rows[0].cells[i]
                c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                _set_font(c.paragraphs[0].add_run(str(htxt)), name=FS_B, size=12, bold=True, color=DARK)
            for row in tb.get("rows", []):
                cells = tbl.add_row().cells
                for j, val in enumerate(row):
                    if j < len(cells):
                        _set_font(cells[j].paragraphs[0].add_run(str(val)), name=FS, size=12, color=DARK)
    # 7 收束语（按文种自动，或用户指定；--doctype 可手动覆盖文种）
    kind = doctype or outline.get("doc_kind", "")
    closing = outline.get("closing") or DOC_KINDS.get(kind, {}).get("close")
    if closing:
        p = P(before=8, indent=1.13, spacing=Pt(28))
        _set_font(p.add_run(closing), name=FS, size=BODY_PT, color=DARK)
    # 8 附件
    for i, att in enumerate(outline.get("attachments", [])):
        p = P(before=6, indent=1.13)
        _set_font(p.add_run(("附件：" if i == 0 else "　　　") + str(att)), name=FS, size=BODY_PT, color=DARK)
    # 9 落款 + 日期（右侧右空2字）
    if outline.get("signer") or outline.get("date"):
        P(before=18)
        if outline.get("signer"):
            p = P(WD_ALIGN_PARAGRAPH.RIGHT, after=2)
            _set_font(p.add_run(outline["signer"] + "　　"), name=FS, size=BODY_PT, color=DARK)
        if outline.get("date"):
            p = P(WD_ALIGN_PARAGRAPH.RIGHT)
            _set_font(p.add_run(outline["date"] + "　　"), name=FS, size=BODY_PT, color=DARK)
    # 10 附注
    for nt in outline.get("notes", []):
        p = P(before=6, indent=1.13)
        _set_font(p.add_run("（" + str(nt) + "）"), name=FS, size=14, color=DARK)
    # 11 抄送（版记）
    if outline.get("cc"):
        P(before=14)
        _add_red_line(P(), color="000000", size="6")
        p = P(before=4)
        _set_font(p.add_run("抄送：" + str(outline["cc"]) + "。"), name=FS, size=14, color=DARK)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    doc.save(out_path)
    return out_path


# ---------- 去AI味自检（吸收《公文写作》humanizer pass +《完美复刻》禁用清单） ----------
def analyze_anti_ai(text, kind=""):
    """返回 [(级别, 类别, 问题, 建议)]，级别：🔴高 / 🟡中 / ⚪低"""
    import re
    from collections import Counter

    findings = []
    sentences = [s for s in re.split(r"[。！？；\n]", text) if s.strip()]

    # 1 各类 AI 词命中
    for cat, words in AI_TELLS.items():
        hits = []
        for w in words:
            n = text.count(w)
            if n:
                hits.append((w, n))
        if not hits:
            continue
        total = sum(n for _, n in hits)
        top = "、".join(f"{w}×{n}" for w, n in sorted(hits, key=lambda x: -x[1])[:4])
        if cat in ("意义膨胀", "宣传腔", "万能结尾"):
            findings.append(("🔴", cat, f"命中 {total} 处（{top}）",
                             "改为陈述具体任务/结果/时限，删除评价性拔高"))
        elif cat == "模糊主体":
            findings.append(("🔴", cat, f"命中 {total} 处（{top}）",
                             "点名责任单位或改用明确占位符〔单位〕"))
        elif cat == "元话语":
            findings.append(("🔴", cat, f"命中 {total} 处（{top}）", "直接写内容，删除过渡宣告"))
        elif cat == "复用副词":
            # 公文常用副词，仅在单词高频复用（≥3 次）时作 🟡 提示，不阻断判定
            hot = [(w, n) for w, n in hits if n >= 3]
            if not hot:
                continue
            top = "、".join(f"{w}×{n}" for w, n in sorted(hot, key=lambda x: -x[1])[:4])
            findings.append(("🟡", cat, f"高频复用副词 {len(hot)} 个（{top}）",
                             "公文/正式文本常用副词，提示避免同一词高频堆叠；非阻断项，合理表达可保留"))
        elif cat == "抽象词堆叠":
            findings.append(("🟡", cat, f"命中 {total} 处（{top}）",
                             "每个抽象词后必须跟具体指标/项目/变化，否则删除"))
        else:
            findings.append(("🟡", cat, f"命中 {total} 处（{top}）",
                             "替换为具体动作与宾语（是/有/完成/整改/报送）"))

    # 2 单句抽象词堆叠（≥3 个不同抽象词）
    for s in sentences:
        c = sum(1 for w in AI_TELLS["抽象词堆叠"] if w in s)
        if c >= 3:
            findings.append(("🔴", "同句抽象词堆叠",
                             f"「{s.strip()[:34]}…」含 {c} 个抽象词", "拆句并补具体事实"))
            break

    # 3 机械排比：连续 3 个以上「要…」短句 / 虚动词密度
    yao = len(re.findall(r"要[^。；]{0,12}[，、]", text))
    if yao >= 3:
        findings.append(("🟡", "机械排比", f"连续「要…」结构 {yao} 处",
                         "改为任务清单，每项写明主体+动作+对象+时限"))
    xu = sum(text.count(w) for w in AI_TELLS["虚动词"])
    if xu >= 4:
        findings.append(("🟡", "动词无宾语", f"虚动词 {xu} 处（扎实推进/全面加强…）",
                         "补齐宾语：推进什么、加强什么"))

    # 4 判断强度与证据匹配
    max_lv, max_word = 0, ""
    for lv, words in JUDGMENT_LEVELS:
        for w in words:
            if w in text and lv > max_lv:
                max_lv, max_word = lv, w
    if max_lv >= 4:
        findings.append(("🟡", "判断过强", f"使用「{max_word}」（强度等级 {max_lv}）",
                         "确认有数据/制度/流程支撑，否则降级为「取得进展/初见成效」"))

    # 5 句长过于整齐（制造有力感的短句堆砌）
    lens = [len(s) for s in sentences if len(s) > 2]
    if len(lens) >= 6:
        avg = sum(lens) / len(lens)
        var = (sum((x - avg) ** 2 for x in lens) / len(lens)) ** 0.5
        if var < 4 and avg < 30:
            findings.append(("⚪", "节奏过齐", f"句长标准差 {var:.1f}（平均 {avg:.0f} 字）",
                             "按内容调整长短：事实/依据用长句，决定/提醒用短句"))

    # 6 文种与收束语匹配
    if kind and kind in DOC_KINDS:
        want = DOC_KINDS[kind].get("close")
        if want and want not in text:
            findings.append(("🟡", "文种收束语缺失",
                             f"「{kind}」建议收束：{want}",
                             DOC_KINDS[kind]["rule"]))
        if kind == "报告" and ("请批示" in text or "请予批准" in text):
            findings.append(("🔴", "文种错位", "报告中夹带请示事项", "报告不得夹带请批事项，改走请示"))
        if kind == "请示" and text.count("：") > 1 and "主送" not in text:
            findings.append(("⚪", "请示纪律", "请示应一文一事、单一主送机关", "核对是否多事项/多主送"))
    return findings


# ---------- pptx 生成 ----------
def _set_pp_font(run, size=18, bold=False, color=DARK, name="微软雅黑"):
    from pptx.dml.color import RGBColor
    from pptx.oxml.ns import qn
    from pptx.util import Pt

    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)
    run.font.name = name
    rPr = run._r.get_or_add_rPr()
    ea = rPr.makeelement(qn("a:ea"), {})
    ea.set("typeface", name)
    rPr.append(ea)


def _set_slide_bg(slide, color):
    bg = slide.background
    bg.fill.solid()
    from pptx.dml.color import RGBColor

    bg.fill.fore_color.rgb = RGBColor.from_string(color)


# ---------- PPT 导演化（v4.0.0 · 吸收 PPT生成助手：设计令牌 + 故事线 + 28 版式精选 12 种） ----------
DESIGN_TOKENS = {
    "margin": 0.03,      # 边距占画布宽比例
    "gap": 0.02,         # 元素间距占画布宽比例
    "font": {"title": 40, "section": 30, "card": 18, "body": 16, "note": 11},
    "grid": 12,
}
LAYOUTS = ["cover", "divider", "content", "left-text-right-img", "right-text-left-img",
           "image-text-mix", "kpi", "compare", "timeline", "quote", "full-image",
           "two-col", "card-grid", "flow"]
LAYOUT_LABELS = {
    "cover": "封面", "divider": "章节过渡", "content": "内容页", "left-text-right-img": "左文右图",
    "right-text-left-img": "右文左图", "image-text-mix": "图文混排", "kpi": "大数据KPI",
    "compare": "对比列", "timeline": "时间轴", "quote": "引用金句", "full-image": "大图全屏",
    "two-col": "双栏论点", "card-grid": "卡片网格", "flow": "流程/阶梯",
}


def _fs(base, size):
    return int(base * (1.25 if size == "a3" else 1.0))


def _ly_img_slot(slide, x, y, w, h, img_path, note, th):
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RGBColor
    from pptx.util import Pt
    if img_path and os.path.exists(img_path):
        try:
            slide.shapes.add_picture(img_path, x, y, width=w, height=h)
            return
        except Exception:  # noqa: BLE001
            pass
    box = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    box.fill.solid()
    box.fill.fore_color.rgb = RGBColor.from_string(th["accent"])
    box.line.color.rgb = RGBColor.from_string(th["primary"])
    box.line.width = Pt(1)
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    _set_pp_font(p.add_run(), size=12, color=th["text"])
    p.runs[0].text = note or "〔配图位：在此插入图片〕"


def _heading_bar(s, prs, sec, th, size, mm_, TXT):
    bar = s.shapes.add_textbox(mm_(15), mm_(12), prs.slide_width - mm_(30), mm_(18))
    tf = bar.text_frame
    tf.word_wrap = True
    tp = tf.paragraphs[0]
    _set_pp_font(tp.add_run(), size=_fs(30, size), bold=True, color=th["primary"])
    tp.runs[0].text = sec.get("heading", "")
    return bar


def _fill_body(tf, sec, size, th, TXT, psize, bsize):
    first = True
    for para in sec.get("paragraphs", []):
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        _set_pp_font(p.add_run(), size=psize, color=th["text"])
        p.runs[0].text = para
        p.space_after = Pt(8)
    for b in sec.get("bullets", []):
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        _set_pp_font(p.add_run(), size=bsize, color=th["text"])
        p.runs[0].text = "▪ " + b
        p.space_after = Pt(6)
    for cit in sec.get("citations", []):
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        _set_pp_font(p.add_run(), size=_fs(11, size), color=TXT)
        p.runs[0].text = "依据：" + " ".join(str(cit.get(k, "")).strip() for k in ("source", "clause", "page") if cit.get(k))


def _add_table(s, prs, sec, size, th, mm_):
    from pptx.util import Mm, Inches
    tb = sec.get("table")
    if not (tb and tb.get("headers") and tb.get("rows")):
        return
    rows = [tb["headers"]] + tb["rows"]
    nrows, ncols = len(rows), len(tb["headers"])
    tbox = s.shapes.add_table(nrows, ncols, mm_(20),
                               prs.slide_height - (Mm(150) if size == "a3" else (Mm(100) if size == "a4" else Inches(4.2))),
                               prs.slide_width - mm_(40),
                               Mm(120) if size == "a3" else (Mm(80) if size == "a4" else Inches(2.4))).table
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = tbox.cell(i, j)
            cell.text = str(val)
            for pr in cell.text_frame.paragraphs:
                pr.alignment = PP_ALIGN.CENTER
                for r in pr.runs:
                    _set_pp_font(r, size=_fs(12, size), bold=(i == 0), color=th["text"])
                    if i == 0:
                        r.font.color.rgb = __import__("pptx").dml.color.RGBColor.from_string("FFFFFF")
                        r.font.bold = True


def _ly_content(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    body = s.shapes.add_textbox(mm_(20), mm_(40), prs.slide_width - mm_(40), prs.slide_height - mm_(60))
    body.text_frame.word_wrap = True
    _fill_body(body.text_frame, sec, size, th, TXT, _fs(18, size), _fs(16, size))
    _add_table(s, prs, sec, size, th, mm_)


def _ly_divider(prs, label, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    box = s.shapes.add_textbox(mm_(20), prs.slide_height * 0.4, prs.slide_width * 0.8, prs.slide_height * 0.2)
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    _set_pp_font(p.add_run(), size=_fs(36, size), bold=True, color=th["primary"])
    p.runs[0].text = label


def _ly_lr_img(prs, sec, th, size, mm_, TXT, right=False):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    W, H = prs.slide_width, prs.slide_height
    m = int(W * DESIGN_TOKENS["margin"])
    if right:  # 右文左图
        img_box = (m, int(H * 0.22), int(W * 0.44), int(H * 0.66))
        txt_box = (int(W * 0.52), int(H * 0.22), int(W * 0.45), int(H * 0.66))
    else:      # 左文右图
        txt_box = (m, int(H * 0.22), int(W * 0.45), int(H * 0.66))
        img_box = (int(W * 0.52), int(H * 0.22), int(W * 0.44), int(H * 0.66))
    _ly_img_slot(s, *img_box, sec.get("image"), "〔配图位：在此插入图片〕", th)
    tb = s.shapes.add_textbox(*txt_box)
    tb.text_frame.word_wrap = True
    _fill_body(tb.text_frame, sec, size, th, TXT, _fs(16, size), _fs(14, size))
    _add_table(s, prs, sec, size, th, mm_)


def _ly_img_mix(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    W, H = prs.slide_width, prs.slide_height
    _ly_img_slot(s, int(W * 0.04), int(H * 0.24), int(W * 0.32), int(H * 0.6),
                 sec.get("image"), "〔配图：案例/效果图〕", th)
    tb = s.shapes.add_textbox(int(W * 0.40), int(H * 0.24), int(W * 0.56), int(H * 0.6))
    tb.text_frame.word_wrap = True
    _fill_body(tb.text_frame, sec, size, th, TXT, _fs(16, size), _fs(14, size))


def _ly_kpi(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    W, H = prs.slide_width, prs.slide_height
    cards = sec.get("cards") or [{"n": "", "label": ""}]
    n = len(cards)
    gap = int(W * 0.02)
    cw = (W - 2 * int(W * 0.04) - gap * (n - 1)) // n
    y = int(H * 0.34)
    ch = int(H * 0.4)
    for i, c in enumerate(cards):
        x = int(W * 0.04) + i * (cw + gap)
        box = s.shapes.add_textbox(x, y, cw, ch)
        tf = box.text_frame
        tf.word_wrap = True
        p0 = tf.paragraphs[0]
        p0.alignment = PP_ALIGN.CENTER
        _set_pp_font(p0.add_run(), size=_fs(48, size), bold=True, color=th["primary"])
        p0.runs[0].text = str(c.get("n", ""))
        p1 = tf.add_paragraph()
        p1.alignment = PP_ALIGN.CENTER
        _set_pp_font(p1.add_run(), size=_fs(14, size), color=TXT)
        p1.runs[0].text = str(c.get("label", ""))


def _ly_compare(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    W, H = prs.slide_width, prs.slide_height
    cols = sec.get("columns") or [{"title": "旧", "items": []}, {"title": "新", "items": []}]
    gap = int(W * 0.03)
    cw = (W - 2 * int(W * 0.04) - gap) // 2
    y = int(H * 0.28)
    ch = int(H * 0.5)
    for i, col in enumerate(cols):
        x = int(W * 0.04) + i * (cw + gap)
        box = s.shapes.add_textbox(x, y, cw, ch)
        tf = box.text_frame
        tf.word_wrap = True
        pt = tf.paragraphs[0]
        _set_pp_font(pt.add_run(), size=_fs(20, size), bold=True, color=th["primary"])
        pt.runs[0].text = col.get("title", "")
        for it in col.get("items", []):
            p = tf.add_paragraph()
            _set_pp_font(p.add_run(), size=_fs(15, size), color=th["text"])
            p.runs[0].text = "• " + str(it)


def _ly_timeline(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    W, H = prs.slide_width, prs.slide_height
    nodes = sec.get("nodes") or [{"t": "", "d": ""}]
    n = len(nodes)
    gap = int(W * 0.02)
    cw = (W - 2 * int(W * 0.04) - gap * (n - 1)) // n
    y = int(H * 0.4)
    ch = int(H * 0.3)
    for i, nd in enumerate(nodes):
        x = int(W * 0.04) + i * (cw + gap)
        box = s.shapes.add_textbox(x, y, cw, ch)
        tf = box.text_frame
        tf.word_wrap = True
        p0 = tf.paragraphs[0]
        p0.alignment = PP_ALIGN.CENTER
        _set_pp_font(p0.add_run(), size=_fs(18, size), bold=True, color=th["primary"])
        p0.runs[0].text = str(nd.get("t", ""))
        if nd.get("d"):
            p1 = tf.add_paragraph()
            p1.alignment = PP_ALIGN.CENTER
            _set_pp_font(p1.add_run(), size=_fs(12, size), color=TXT)
            p1.runs[0].text = str(nd.get("d", ""))


def _ly_quote(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    W, H = prs.slide_width, prs.slide_height
    box = s.shapes.add_textbox(int(W * 0.12), int(H * 0.3), int(W * 0.76), int(H * 0.4))
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    _set_pp_font(p.add_run(), size=_fs(28, size), bold=True, color=th["primary"])
    p.runs[0].text = "“" + sec.get("quote", sec.get("heading", "")) + "”"
    if sec.get("source"):
        p2 = tf.add_paragraph()
        p2.alignment = PP_ALIGN.CENTER
        _set_pp_font(p2.add_run(), size=_fs(14, size), color=TXT)
        p2.runs[0].text = "——" + sec.get("source", "")


def _ly_fullimg(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    W, H = prs.slide_width, prs.slide_height
    _ly_img_slot(s, 0, 0, W, H, sec.get("image"), "〔大图：在此插入主视觉/效果图〕", th)
    if sec.get("caption"):
        box = s.shapes.add_textbox(int(W * 0.1), int(H * 0.82), int(W * 0.8), int(H * 0.14))
        tf = box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        _set_pp_font(p.add_run(), size=_fs(16, size), color="FFFFFF" if th["dark"] else th["text"])
        p.runs[0].text = sec.get("caption", "")


def _ly_twocol(prs, sec, th, size, mm_, TXT):
    _ly_compare(prs, sec, th, size, mm_, TXT)  # 双栏论点复用对比列布局


def _ly_cardgrid(prs, sec, th, size, mm_, TXT):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _set_slide_bg(s, th["bg"])
    _heading_bar(s, prs, sec, th, size, mm_, TXT)
    W, H = prs.slide_width, prs.slide_height
    cards = sec.get("cards") or [{"title": "", "desc": ""}]
    n = len(cards)
    cols = 2 if n > 2 else n
    rows = (n + cols - 1) // cols
    gap = int(W * 0.02)
    cw = (W - 2 * int(W * 0.04) - gap * (cols - 1)) // cols
    ch = (int(H * 0.62) - gap * (rows - 1)) // rows
    y0 = int(H * 0.28)
    for i, c in enumerate(cards):
        r, cc = divmod(i, cols)
        x = int(W * 0.04) + cc * (cw + gap)
        y = y0 + r * (ch + gap)
        box = s.shapes.add_textbox(x, y, cw, ch)
        tf = box.text_frame
        tf.word_wrap = True
        pt = tf.paragraphs[0]
        _set_pp_font(pt.add_run(), size=_fs(18, size), bold=True, color=th["primary"])
        pt.runs[0].text = str(c.get("title", ""))
        if c.get("desc"):
            pd = tf.add_paragraph()
            _set_pp_font(pd.add_run(), size=_fs(13, size), color=th["text"])
            pd.runs[0].text = str(c.get("desc", ""))


def _ly_flow(prs, sec, th, size, mm_, TXT):
    _ly_timeline(prs, sec, th, size, mm_, TXT)  # 流程/阶梯复用时间轴布局


_LY_DISPATCH = {
    "content": _ly_content, "left-text-right-img": lambda *a: _ly_lr_img(*a, right=False),
    "right-text-left-img": lambda *a: _ly_lr_img(*a, right=True), "image-text-mix": _ly_img_mix,
    "kpi": _ly_kpi, "compare": _ly_compare, "timeline": _ly_timeline, "quote": _ly_quote,
    "full-image": _ly_fullimg, "two-col": _ly_twocol, "card-grid": _ly_cardgrid, "flow": _ly_flow,
}


def build_pptx(outline, out_path, size="169", theme=DEFAULT_THEME, closing=False, narrative=False, default_layout="content"):
    from pptx import Presentation
    from pptx.util import Cm, Inches, Mm, Pt

    th = THEMES.get(theme, THEMES[DEFAULT_THEME])
    prs = Presentation()
    if size == "a3":  # A3 横版 420×297mm（投标/汇报惯用）
        prs.slide_width = Mm(420)
        prs.slide_height = Mm(297)
    elif size == "a4":
        prs.slide_width = Mm(297)
        prs.slide_height = Mm(210)
    else:
        w, h = {"169": (13.333, 7.5), "43": (10.0, 7.5)}.get(size, (13.333, 7.5))
        prs.slide_width = Inches(w)
        prs.slide_height = Inches(h)
    blank = prs.slide_layouts[6]
    mm_ = lambda v: Mm(v) if size in ("a3", "a4") else Inches(v / 25.4)
    TXT = th["text"] if th["dark"] else "595959"  # 副标题灰

    def _cover():
        s = prs.slides.add_slide(blank)
        _set_slide_bg(s, th["bg"])
        box = s.shapes.add_textbox(mm_(20), prs.slide_height * 0.36, prs.slide_width * 0.8, prs.slide_height * 0.3)
        tf = box.text_frame; tf.word_wrap = True
        p0 = tf.paragraphs[0]; p0.alignment = PP_ALIGN.CENTER
        _set_pp_font(p0.add_run(), size=40 if size == "a3" else 32, bold=True, color=th["primary"])
        p0.runs[0].text = outline.get("title", "")
        if outline.get("subtitle"):
            p1 = tf.add_paragraph(); p1.alignment = PP_ALIGN.CENTER
            _set_pp_font(p1.add_run(), size=20 if size == "a3" else 16, color=TXT)
            p1.runs[0].text = outline["subtitle"]
        meta = outline.get("meta") or {}
        if meta:
            p2 = tf.add_paragraph(); p2.alignment = PP_ALIGN.CENTER
            _set_pp_font(p2.add_run(), size=14, color=TXT)
            p2.runs[0].text = "　".join(f"{k}：{v}" for k, v in meta.items())

    def _closing():
        s = prs.slides.add_slide(blank)
        _set_slide_bg(s, th["bg"])
        box = s.shapes.add_textbox(mm_(20), prs.slide_height * 0.4, prs.slide_width * 0.8, prs.slide_height * 0.2)
        tf = box.text_frame; tf.word_wrap = True
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        _set_pp_font(p.add_run(), size=36 if size == "a3" else 28, bold=True, color=th["primary"])
        p.runs[0].text = "谢谢！"

    _cover()
    _acts_seen = set()
    for sec in outline.get("sections", []):
        ly = (sec.get("layout") or default_layout).strip()
        if (narrative or sec.get("act")) and sec.get("act") and sec["act"] not in _acts_seen:
            _acts_seen.add(sec["act"])
            _ly_divider(prs, sec["act"], th, size, mm_, TXT)
        if ly == "cover":
            _ly_content(prs, sec, th, size, mm_, TXT)
        elif ly == "divider":
            _ly_divider(prs, sec.get("heading", sec.get("act", "章节")), th, size, mm_, TXT)
        elif ly in _LY_DISPATCH:
            _LY_DISPATCH[ly](prs, sec, th, size, mm_, TXT)
        else:
            _ly_content(prs, sec, th, size, mm_, TXT)
    if closing:
        _closing()
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    prs.save(out_path)
    return out_path


# ---------- 图表生成（吸收《diagram-builder》SVG 规范：680 宽 / marker 箭头 / 防压字） ----------
SVG_W = 680


def _svg_esc(t):
    return (str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def build_diagram_svg(spec, out_path):
    """生成符合规范的静态 SVG（流程图/时序/分层架构）。

    spec = {
      "type": "flow" | "arch",          # flow=横向流程；arch=分层架构
      "title": "消防审查流程",
      "nodes": [{"id":"a","label":"受理","layer":0}],   # arch 用 layer；flow 按顺序
      "edges": [{"from":"a","to":"b","label":""}]
    }
    规范：viewBox 0 0 680 H；箭头 marker 朝右；文字与连线共区先铺白底；中文 sans-serif。
    """
    import html as _html

    ntype = spec.get("type", "flow")
    nodes = spec.get("nodes", [])
    edges = spec.get("edges", [])
    if not nodes:
        raise RuntimeError("E003 diagram 需要 nodes")

    W = SVG_W
    PAD = 24
    NODE_H = 54
    GAP_X, GAP_Y = 46, 62
    TITLE_H = 46

    # 布局（flow：≤4 节点单行自适应宽度；arch：分层）
    positions = {}
    if ntype == "arch":
        node_w = 150.0
        layers = {}
        for n in nodes:
            layers.setdefault(int(n.get("layer", 0)), []).append(n["id"])
        y = TITLE_H + PAD
        h = TITLE_H + PAD * 2 + len(layers) * (NODE_H + GAP_Y)
        for li in sorted(layers):
            ids = layers[li]
            total_w = len(ids) * node_w + (len(ids) - 1) * GAP_X
            x = (W - total_w) / 2 if total_w < W - PAD * 2 else PAD
            for nid in ids:
                positions[nid] = (x, y)
                x += node_w + GAP_X
            y += NODE_H + GAP_Y
    else:
        n = len(nodes)
        cols = n if n <= 4 else 3
        node_w = min(150.0, (W - PAD * 2 - (cols - 1) * GAP_X) / cols)
        rows = (n + cols - 1) // cols
        h = TITLE_H + PAD * 2 + rows * (NODE_H + GAP_Y)
        for i, nd in enumerate(nodes):
            r, c = divmod(i, cols)
            cnt = min(cols, n - r * cols)
            total_w = cnt * node_w + (cnt - 1) * GAP_X
            x = (W - total_w) / 2 + c * (node_w + GAP_X)
            positions[nd["id"]] = (x, TITLE_H + PAD + r * (NODE_H + GAP_Y))

    parts = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {h}" width="{W}" '
        f'font-family="sans-serif">')
    parts.append('<defs>'
                 '<marker id="ar" viewBox="0 0 10 10" refX="10" refY="5" '
                 'markerWidth="10" markerHeight="10" orient="auto">'
                 '<path d="M0,0 L10,5 L0,10 z" fill="#5B8FF9"/></marker>'
                 '<style>'
                 '.t{font-size:15px;fill:#1F2329}'
                 '.n{fill:#EEF3FE;stroke:#5B8FF9;stroke-width:1.5;rx:8}'
                 '.l{font-size:13px;fill:#333}'
                 '.bg{fill:#ffffff}'
                 '.ttl{font-size:18px;font-weight:bold;fill:#1F2329}'
                 '</style></defs>')
    if spec.get("title"):
        parts.append(f'<text x="{W/2}" y="30" text-anchor="middle" class="ttl">'
                     f'{_svg_esc(spec["title"])}</text>')

    # 连线（先画线，节点后画，保证节点压在线上方）
    for e in edges:
        a, b = positions.get(e.get("from")), positions.get(e.get("to"))
        if not a or not b:
            continue
        ax, ay = a[0] + node_w / 2, a[1] + NODE_H / 2
        bx, by = b[0] + node_w / 2, b[1] + NODE_H / 2
        if abs(by - ay) < 4:
            # 同行水平连线（左→右 或 右→左，marker 自动定向）
            if bx >= ax:
                x1, x2 = a[0] + node_w + 6, b[0] - 8
            else:
                x1, x2 = a[0] - 6, b[0] + node_w + 8
            parts.append(f'<line x1="{x1}" y1="{ay}" x2="{x2}" y2="{ay}" '
                         f'stroke="#5B8FF9" stroke-width="1.5" marker-end="url(#ar)"/>')
            mx, my = (x1 + x2) / 2, ay
        else:
            # 跨行/跨层：折线（源底 → 中线 → 目标顶），避免斜穿节点
            mid_y = ay + (by - ay) / 2
            parts.append(f'<path d="M{ax},{a[1]+NODE_H} L{ax},{mid_y} L{bx},{mid_y} '
                         f'L{bx},{b[1]-8}" fill="none" stroke="#5B8FF9" stroke-width="1.5" '
                         f'marker-end="url(#ar)"/>')
            mx, my = (ax + bx) / 2, mid_y
        if e.get("label"):
            tw = len(str(e["label"])) * 13 + 10
            parts.append(f'<rect x="{mx-tw/2}" y="{my-11}" width="{tw}" height="22" class="bg"/>')
            parts.append(f'<text x="{mx}" y="{my+4}" text-anchor="middle" class="l">'
                         f'{_svg_esc(e["label"])}</text>')

    # 节点（后画，压在连线上方）
    for n in nodes:
        x, y = positions[n["id"]]
        parts.append(f'<rect x="{x}" y="{y}" width="{node_w}" height="{NODE_H}" rx="8" class="n"/>')
        label = str(n.get("label", n["id"]))
        parts.append(f'<text x="{x+node_w/2}" y="{y+NODE_H/2+5}" text-anchor="middle" class="t">'
                     f'{_svg_esc(label)}</text>')
    parts.append("</svg>")

    svg = "".join(parts)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(svg)
    return out_path


# ---------- 导出 PDF ----------
def _export_wps(path, out):
    import win32com.client

    ext = os.path.splitext(path)[1].lower()

    def _docx():
        app = win32com.client.Dispatch("kwps.Application")
        app.Visible = False
        doc = app.Documents.Open(path, ReadOnly=True)
        doc.ExportAsFixedFormat(out, 17)
        doc.Close(False)
        app.Quit()

    def _pptx():
        app = win32com.client.Dispatch("kwpp.Application")
        app.Visible = False
        pres = app.Presentations.Open(path, ReadOnly=True, WithWindow=False)
        pres.SaveAs(out, 32)
        pres.Close()
        app.Quit()

    return retry(_docx if ext == ".docx" else _pptx, label="WPS导出PDF")


def _export_ms(path, out):
    import win32com.client

    ext = os.path.splitext(path)[1].lower()

    def _docx():
        app = win32com.client.Dispatch("Word.Application")
        app.Visible = False
        doc = app.Documents.Open(path, ReadOnly=True)
        doc.ExportAsFixedFormat(out, 17)
        doc.Close(False)
        app.Quit()

    def _pptx():
        app = win32com.client.Dispatch("PowerPoint.Application")
        pres = app.Presentations.Open(path, ReadOnly=True, WithWindow=False)
        pres.ExportAsFixedFormat(out, 2)
        pres.Close()
        app.Quit()

    return retry(_docx if ext == ".docx" else _pptx, label="MS导出PDF")


def _export_libre(path, out):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        raise RuntimeError("E011 LibreOffice 未安装，无法转换")
    d = os.path.dirname(os.path.abspath(out))
    r = subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", d, path],
                       capture_output=True, text=True, timeout=180)
    if r.returncode != 0:
        raise RuntimeError(f"E012 LibreOffice 转换失败：{r.stderr[:200]}")
    stem = os.path.splitext(os.path.basename(path))[0]
    cand = os.path.join(d, stem + ".pdf")
    if os.path.exists(cand) and cand != out:
        shutil.move(cand, out)
    return out


def export_pdf(path, engine="auto"):
    path = os.path.abspath(path)  # COM 进程按自身 CWD 解析相对路径
    if not os.path.exists(path):
        raise RuntimeError(f"E013 文件不存在：{path}")
    out = os.path.splitext(path)[0] + ".pdf"
    eng = detect_engines()
    order = {"wps": ["wps", "ms", "libre"], "ms": ["ms", "wps", "libre"],
             "libre": ["libre"], "auto": ["wps", "ms", "libre"]}[engine]
    last = None
    for e in order:
        if e == "wps" and eng["wps"]:
            try:
                _export_wps(path, out)
                return out
            except Exception as ex:  # noqa: BLE001
                last = ex
        elif e == "ms" and eng["ms"]:
            try:
                _export_ms(path, out)
                return out
            except Exception as ex:  # noqa: BLE001
                last = ex
        elif e == "libre" and eng["libre"]:
            try:
                return _export_libre(path, out)
            except Exception as ex:  # noqa: BLE001
                last = ex
    raise RuntimeError(f"E010 无可用的 PDF 导出引擎（最后错误：{last}）。请安装 WPS 或 LibreOffice。")


# ---------- 文字提取（吸收 PDF和图片文字提取 skill） ----------
def _ocr_img(arr_bgr):
    """RapidOCR：入参必须为 np.ndarray(BGR)"""
    from rapidocr_onnxruntime import RapidOCR

    res, _ = RapidOCR()(arr_bgr)
    if not res:
        return ""
    return "\n".join(t for _, t, _ in res)


def _img_to_bgr(pil_img):
    import numpy as np

    arr = np.array(pil_img)
    if arr.ndim == 3 and arr.shape[2] == 3:
        arr = arr[:, :, ::-1]  # RGB -> BGR
    return arr


def _diagnose_page(page):
    """页面诊断：native-text / scanned / mixed / suspicious / empty"""
    t = page.get_text().strip()
    nchars = len(t)
    try:
        nimgs = len(page.get_images(full=False))
    except Exception:  # noqa: BLE001
        nimgs = 0
    if nchars == 0 and nimgs == 0:
        return "EMPTY_PAGE"
    if nchars >= 100:
        return "mixed" if nimgs > 0 else "native-text"
    if nchars < 20 and nimgs > 0:
        return "scanned"
    return "suspicious"


def _detect_columns(page):
    """多栏检测：按 block 左边界 X 坐标聚类，返回栏数（1/2/3…）"""
    try:
        xs = sorted(b[0] for b in page.get_text("blocks") if len(b) >= 5 and str(b[4]).strip())
    except Exception:  # noqa: BLE001
        return 1
    if len(xs) < 6:
        return 1
    thr = max(40.0, page.rect.width * 0.15)
    clusters = [[xs[0]]]
    for x in xs[1:]:
        if x - clusters[-1][-1] > thr:
            clusters.append([x])
        else:
            clusters[-1].append(x)
    big = [c for c in clusters if len(c) >= 2]
    return len(big) if len(big) >= 2 else 1


def _mark_risk_numbers(t):
    """高风险数字串标记（金额/编号/长数字/日期），提示二次复核"""
    import re

    pat = re.compile(
        r"(?<!\d)(?:"
        r"\d{6,}"                                        # 长数字串（编号/证件/账号）
        r"|\d+\.\d{2}"                                   # 金额两位小数
        r"|[¥￥]\s?\d[\d,]*(?:\.\d+)?"                    # 货币金额
        r"|\d{4}[-/.年]\d{1,2}[-/.月]\d{1,2}日?"          # 日期（含 2026-08-31 / 2026年8月31日）
        r"|\d{3,4}-\d{7,8}"                              # 电话
        r"|[〔\[【（(]\s*\d{4}\s*[〕\]】）)]\s*第?\d+\s*号"   # 发文字号
        r")(?!\d)")
    return pat.sub(lambda m: f"{m.group(0)}〔复核〕", t)


def extract_text(src, out_path=None, pages=None, mark_risk=True):
    """PDF/图片 → Markdown。PDF：文字层直取，扫描页自动 OCR（含页面状态/多栏/数字复核）"""
    import pymupdf

    ext = os.path.splitext(src)[1].lower()
    src = os.path.abspath(src)
    if not os.path.exists(src):
        raise RuntimeError(f"E013 文件不存在：{src}")
    lines = [f"# 提取结果：{os.path.basename(src)}", ""]
    stat = []

    def _page_range(n):
        if not pages:
            return list(range(n))
        rng = []
        for part in str(pages).split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-", 1)
                rng.extend(range(int(a) - 1, min(int(b), n)))
            elif part:
                rng.append(int(part) - 1)
        return sorted(set(x for x in rng if 0 <= x < n))

    if ext in (".pdf",):
        doc = pymupdf.open(src)
        n = doc.page_count
        stat.append(f"共 {n} 页")
        text_pages = 0
        scan_pages = 0
        st_count = {"native-text": 0, "scanned": 0, "mixed": 0, "suspicious": 0, "EMPTY_PAGE": 0}
        multi_col = []
        for i in _page_range(n):
            page = doc[i]
            state = _diagnose_page(page)
            st_count[state] = st_count.get(state, 0) + 1
            cols = _detect_columns(page)
            if cols >= 2:
                multi_col.append(i + 1)
            t = page.get_text().strip()
            tag = {"native-text": "文字层", "scanned": "扫描页·OCR", "mixed": "混合·文字层+图像",
                   "suspicious": "存疑·低文字量", "EMPTY_PAGE": "空白页"}.get(state, state)
            if state in ("native-text", "mixed") and t:
                text_pages += 1
                body = _mark_risk_numbers(t) if mark_risk else t
                extra = f" ｜ 多栏（{cols}栏）" if cols >= 2 else ""
                lines.append(f"## 第 {i + 1} 页（{tag}{extra}）")
                lines.append(body)
                if cols >= 2:
                    lines.append(f"<!-- 第 {i + 1} 页为双栏版面，已按左栏→右栏顺序恢复 -->")
                lines.append("")
            elif state == "EMPTY_PAGE":
                lines.append(f"## 第 {i + 1} 页（{tag}）")
                lines.append("（无文字内容）")
                lines.append("")
            else:
                scan_pages += 1
                try:
                    pix = page.get_pixmap(dpi=180)
                    import numpy as np

                    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
                    if pix.n == 3:
                        arr = arr[:, :, ::-1]
                    ocr = _ocr_img(arr)
                    if mark_risk and ocr.strip():
                        ocr = _mark_risk_numbers(ocr)
                except Exception as e:  # noqa: BLE001
                    ocr = f"（OCR 失败：{e}）"
                extra = f" ｜ 多栏（{cols}栏）" if cols >= 2 else ""
                lines.append(f"## 第 {i + 1} 页（{tag}{extra}）")
                lines.append(ocr if ocr.strip() else "（该页未识别到文字）")
                if cols >= 2:
                    lines.append(f"<!-- 第 {i + 1} 页为双栏版面，已按左栏→右栏顺序恢复 -->")
                lines.append("")
        doc.close()
        stat.append(f"文字层 {text_pages} 页 / 扫描OCR {scan_pages} 页")
        detail = "、".join(f"{k} {v}" for k, v in st_count.items() if v)
        if detail:
            stat.append("页面状态：" + detail)
        if multi_col:
            stat.append(f"多栏页 {len(multi_col)} 页（第 {','.join(map(str, multi_col[:8]))}"
                        f"{'…' if len(multi_col) > 8 else ''} 页）")
    elif ext in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
        from PIL import Image

        img = Image.open(src)
        arr = _img_to_bgr(img)
        ocr = _ocr_img(arr)
        lines.append("## 图片 OCR")
        lines.append(ocr if ocr.strip() else "（未识别到文字）")
        lines.append("")
        stat.append("图片 1 张")
    else:
        raise RuntimeError(f"E015 不支持的文件格式：{ext}（支持 pdf/png/jpg/jpeg/gif/webp/bmp）")

    body = "\n".join(lines)
    md = f"> 来源：{src} ｜ {'｜'.join(stat)} ｜ 提取时间 {time.strftime('%Y-%m-%d %H:%M')}\n\n{body}"
    if out_path:
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(md)
        return out_path, md, stat
    return None, md, stat


# ---------- 视觉自检（吸收 Slide maker 渲染检查 + PPT Generator 禁止项） ----------
DEFAULT_BLUES = ("0000FF", "4472C4", "0563C1")  # 默认主题蓝（商务场景除外）


def check_docx(path):
    from docx import Document

    doc = Document(path)
    paras = [p for p in doc.paragraphs if p.text.strip()]
    findings = []
    if not paras:
        findings.append(("🔴", "文档无正文段落"))
    heads = [p for p in paras if p.runs and p.runs[0].font.size and p.runs[0].font.size.pt >= 14 and p.runs[0].font.bold]
    if not heads and paras:
        findings.append(("🟡", "未检测到粗体大字号标题（层级可能缺失）"))
    findings.append(("✅", f"正文段落 {len(paras)} 个，粗体标题 {len(heads)} 个"))
    return findings


def check_pptx(path):
    from pptx import Presentation
    from pptx.util import Pt

    prs = Presentation(path)
    findings = []
    n = 0
    for idx, slide in enumerate(prs.slides, 1):
        n += 1
        total_chars = 0
        min_pt = 999
        blues = []
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if not run.text:
                        continue
                    total_chars += len(run.text)
                    try:
                        pt = run.font.size.pt if run.font.size else 999
                    except Exception:  # noqa: BLE001
                        pt = 999
                    min_pt = min(min_pt, pt)
                    try:
                        rgb = str(run.font.color.rgb) if run.font.color and run.font.color.type else ""
                    except Exception:  # noqa: BLE001
                        rgb = ""
                    if rgb and rgb.upper() in DEFAULT_BLUES:
                        blues.append(rgb)
        if total_chars > 400:
            findings.append(("🟡", f"第{idx}页 文字约{total_chars}字，可能信息过载（3秒法则）"))
        if min_pt < 10 and min_pt != 999:
            findings.append(("🟡", f"第{idx}页 最小字号 {min_pt}pt < 10pt（正文≥14pt，注释≥10pt）"))
        if blues:
            findings.append(("🟡", f"第{idx}页 出现默认主题蓝 {set(blues)}（非商务场景建议换色）"))
    if not n:
        findings.append(("🔴", "PPT 无页面"))
    findings.append(("✅", f"共 {n} 页，检查完成"))
    return findings


# ---------- 文生图提示词引擎（v4.0.0 · 蒸馏 10 个文生图 skill 为一套可执行引擎） ----------
# 设计原则（来自各 skill 的共识，原子化吸收而非堆砌原文）：
#  - 双语强制：英文版优先（模型理解更准），中文版与英文版同细节密度（Nanobanana / Prompt Master）
#  - 结构：主体 + 场景 + 风格 + 光影 + 构图 + 色彩（+ 文字 + 排除），SOCAWT 六维 / 六层词序（胖达 / ImagePrompt-SOCAWT）
#  - 即梦禁否定：主 prompt 不写"不要X"，排除项进 negative；中文色名不写 hex（即梦 prompt skill）
#  - 图生图保留项：开头写明"严格保留参考图中…"，再写修改项（Nano Banana / 智绘图片香蕉）
#  - 比例驱动构图：先定 ratio 再写构图（即梦 / PPT 生成助手）
IMAGE_PLATFORMS = {
    "jimeng":     {"label": "即梦 / Dreamina", "model": "5.0 / Seedream",
                   "note": "中文 prompt 最佳；禁否定词；色名用中文不写 hex；ratio 驱动构图"},
    "nanobanana": {"label": "Nano Banana / Gemini", "model": "Nano Banana 2",
                   "note": "画面内文字用引号标原文+字体位置；多参考图先说保留项"},
    "agnes":      {"label": "Agnes Image (agnes-image-2.1-flash)", "model": "agnes-image-2.1-flash",
                   "note": "size 档位 1K-4K + ratio；文生图三必填 model+prompt+size"},
    "bigmodel":   {"label": "智谱 BigModel (CogView)", "model": "cogview-4 / cogview-4-250304",
                   "note": "--size WxH；cogview-4 质量最高"},
}


def build_image_prompt(brief):
    """把结构化 brief 蒸馏成 双语提示词 + 负向 + 多平台参数提示。

    brief 字段：subject/scene/style/light/composition/color/text/
                ratio(默认 16:9)/mode(t2i|img2img)/preserve/img2img 保留项/
                exclude/quality
    """
    subject = (brief.get("subject") or "").strip()
    scene = (brief.get("scene") or "").strip()
    style = (brief.get("style") or "").strip()
    light = (brief.get("light") or "").strip()
    composition = (brief.get("composition") or "").strip()
    color = (brief.get("color") or "").strip()
    text = (brief.get("text") or "").strip()          # 需精确呈现的画面文字
    ratio = (brief.get("ratio") or "16:9").strip()
    mode = (brief.get("mode") or "t2i").strip().lower()
    preserve = (brief.get("preserve") or "").strip()   # img2img 必须保留项
    exclude = (brief.get("exclude") or "").strip()
    quality = (brief.get("quality") or "高细节，清晰，专业级").strip()

    # —— 英文版（主，自然语言句子）——
    en = []
    if mode == "img2img" and preserve:
        en.append(f"Strictly preserve: {preserve}.")
    if subject:
        en.append(subject)
    if scene:
        en.append(scene if scene.lower().startswith(("in ", "on ", "at ")) else f"in {scene}")
    if style:
        en.append(f"{style} style")
    if light:
        en.append(f"{light} lighting")
    if composition:
        en.append(composition)
    if color:
        en.append(f"color palette: {color}")
    if text:
        en.append(f'title text "{text}" rendered clearly and legibly')
    en.append(quality)
    en_prompt = ", ".join(en).strip()

    # —— 中文版（同细节密度，正向；色名用中文不写 hex）——
    zh = []
    if mode == "img2img" and preserve:
        zh.append(f"严格保留参考图中的{preserve}。")
    if subject:
        zh.append(subject)
    if scene:
        zh.append(f"场景为{scene}")
    if style:
        zh.append(f"采用{style}风格")
    if light:
        zh.append(f"{light}光线")
    if composition:
        zh.append(composition)
    if color:
        zh.append(f"配色以{color}为主（使用中文色名，不写十六进制）")
    if text:
        zh.append(f'画面文字严格写作"{text}"，字体清晰可读')
    zh.append(quality)
    zh_prompt = "，".join(zh).rstrip("，") + "。"

    negative_en = exclude or "cluttered background, extra text, watermark, low resolution, distorted"
    negative_zh = exclude or "杂乱背景，多余文字，水印，低清晰度，变形"

    platforms = {pid: {"label": m["label"], "model": m["model"], "ratio": ratio, "note": m["note"]}
                 for pid, m in IMAGE_PLATFORMS.items()}
    return {
        "mode": mode, "ratio": ratio,
        "en_prompt": en_prompt, "zh_prompt": zh_prompt,
        "negative_en": negative_en, "negative_zh": negative_zh,
        "platforms": platforms,
    }


def build_node_prompt(brief):
    """节点大样写实化预置（吸收 Evai 黄金范式）：把二维构造节点蒸馏为 双语写实化提示词。

    六语法固化：竖向半剖透视 + 半剖透视手法 + 实景渲染对标真照片 + 8K +
    材料逐层质感 + 绿色尺寸引线 + 白色中文标注 + 杜绝卡通/手绘。
    仅出提示词，不调生图 API；拿到后去即梦 / Nano Banana / Evai / Agnes 粘贴即可。

    brief 字段：node_name / materials(list 外→内) / view / annotation /
                background / ratio(默认 3:4) / platform / avoid / mode / preserve
    """
    node = (brief.get("node_name") or "").strip()
    materials = brief.get("materials") or []
    if isinstance(materials, str):
        materials = [m.strip() for m in materials.replace("、", ",").split(",") if m.strip()]
    mat_chain = " → ".join(materials) if materials else "（按实际构造层次外→内逐层列出）"
    view = (brief.get("view") or "竖向半剖透视").strip()
    annotation = (brief.get("annotation")
                  or "尺寸引线统一采用绿色；名称标注均以白色中文说明；绿色尺寸数值排布清楚有序").strip()
    node_type = (brief.get("node_type") or "").strip().lower()
    # 节点类型自动背景：用户显式 --background 优先；否则按类型补环境短语
    _NT_BG = {
        "roof": "屋顶蓝天背景，远处有城市或山地建筑轮廓，天光自然照明",
        "facade": "建筑外立面实景环境，周边有相邻建筑与天空，自然日光",
        "basement": "地下空间暗环境，人工照明补光，混凝土结构氛围",
        "stair": "建筑室内公共空间环境，侧高窗引入自然采光",
    }
    if node_type and node_type not in _NT_BG:
        print(f"⚠️ 未识别的 --node-type '{node_type}'（取值 roof/facade/basement/stair），已忽略；如需自定义背景请用 --background")
    background = (brief.get("background") or "").strip() or _NT_BG.get(node_type, "")
    ratio = (brief.get("ratio") or "3:4").strip()
    platform = (brief.get("platform") or "").strip()
    mode = (brief.get("mode") or "t2i").strip().lower()
    preserve = (brief.get("preserve") or "").strip()
    avoid = (brief.get("avoid") or "").strip()

    # —— 英文版（主，自然语言句子，对标真实照片）——
    en = []
    if mode == "img2img" and preserve:
        en.append(f"Strictly preserve: {preserve}.")
    en.append(
        f"Professional-grade engineering construction cutaway render depicting the vertical section of {node}, "
        f"using a half-cut perspective technique that reveals the full layered construction detail"
    )
    en.append(
        f"photorealistic rendering on par with real photographs, 8K ultra-high resolution, "
        f"believable material textures that strictly follow the actual materials: {mat_chain}"
    )
    en.append(f"{view} composition")
    en.append("annotation convention: dimension leader lines in green; component labels in white Chinese text; "
              "green dimension values arranged clean and orderly")
    en.append("technical cutaway diagram of a complex structural node, photorealistic, real-scene rendering "
              "— absolutely no cartoon, hand-drawn, or flat illustration style")
    if background:
        en.append(background)
    if ratio:
        en.append(f"composition tuned for {ratio} aspect ratio")
    en_prompt = ", ".join(en).strip()

    # —— 中文版（同细节密度，正向；色名用中文不写 hex；杜绝否定词）——
    zh = []
    if mode == "img2img" and preserve:
        zh.append(f"严格保留参考图中的{preserve}。")
    zh.append(f"一张专业水准的工程构造剖切效果图，刻画{node}的竖向剖面，运用半剖透视手法，将复杂节点构造悉数呈现")
    zh.append(f"渲染品质对标真实照片，分辨率达 8K 超清级别，材料质感逼真可信，严格遵照其原本材质：{mat_chain}")
    zh.append(f"采用{view}构图")
    zh.append(f"标注规范：{annotation}")
    zh.append("风格限定：画面须具备复杂结构工程节点的图解气质，务求真实，采用实景化渲染与竖向剖面构图，杜绝一切卡通、手绘画风")
    if background:
        zh.append(background)
    if ratio:
        zh.append(f"构图按{ratio}比例调校")
    zh_prompt = "，".join(zh).rstrip("，") + "。"

    negative_en = avoid or "cartoon, hand-drawn, flat illustration, sketch, low resolution, distorted, extra text"
    negative_zh = avoid or "卡通，手绘，扁平插画，草图，低清晰度，变形，多余文字"

    platforms = {pid: {"label": m["label"], "model": m["model"], "ratio": ratio, "note": m["note"]}
                 for pid, m in IMAGE_PLATFORMS.items()}
    if platform:
        platforms["_target"] = {"label": f"目标平台：{platform}", "model": "", "ratio": ratio,
                                "note": "本提示词按节点大样写实化范式蒸馏，可直接粘贴至该平台生图"}
    return {
        "preset": "node", "mode": mode, "ratio": ratio, "node_name": node,
        "en_prompt": en_prompt, "zh_prompt": zh_prompt,
        "negative_en": negative_en, "negative_zh": negative_zh,
        "platforms": platforms,
    }


def cmd_imgprompt(args):
    if getattr(args, "preset", "") == "node":
        brief = {
            "node_name": (args.node or "").strip(),
            "materials": [m.strip() for m in (args.materials or "").replace("、", ",").split(",") if m.strip()],
            "node_type": (args.node_type or "").strip(),
            "view": (args.view or "").strip(),
            "annotation": (args.annotation or "").strip(),
            "background": (args.background or "").strip(),
            "ratio": (args.ratio or "3:4").strip(),
            "platform": (args.platform or "").strip(),
            "avoid": (args.avoid or "").strip(),
            "mode": (args.mode or "t2i").strip().lower(),
            "preserve": (args.preserve or "").strip(),
        }
        if not brief["node_name"]:
            print("❌ --preset node 需要 --node 节点名称（如 --node \"屋面女儿墙泛水节点\"）")
            return
        res = build_node_prompt(brief)
        print("ℹ️ 本工具仅生成提示词，不直接调用生图 API；请复制 zh_prompt 到即梦 / Nano Banana / Evai 等平台生成图像。")
    else:
        if not args.input:
            print("❌ 通用文生图模式需要 --input brief.json（或改用 --preset node）")
            return
        with open(args.input, encoding="utf-8") as f:
            brief = json.load(f)
        if isinstance(brief, list):
            brief = brief[0]
        res = build_image_prompt(brief)
    out = args.output
    if out:
        with open(out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)
        print(f"✅ 已生成文生图提示词：{out}（{res['mode']} / ratio {res['ratio']}）")
    else:
        print(f"===== 文生图提示词（{res['mode']} · ratio {res['ratio']}）=====")
        print(f"【EN】{res['en_prompt']}")
        print(f"【ZH】{res['zh_prompt']}")
        print(f"【负向 EN】{res['negative_en']}")
        print(f"【负向 ZH】{res['negative_zh']}")
        for pid, m in res["platforms"].items():
            print(f"  · {m['label']}｜model={m['model']}｜ratio={m['ratio']}｜{m['note']}")


# ---------- CLI ----------
OUTLINE_SAMPLE = {
    "title": "示例：消防设计说明",
    "subtitle": "xx 项目（改造工程）",
    "meta": {"单位": "xx设计院", "专业": "建筑/给排水", "日期": "2026-08-31"},
    "sections": [
        {
            "heading": "1 设计依据",
            "level": 1,
            "paragraphs": ["本设计依据现行国家工程建设消防技术标准编制。"],
            "bullets": ["《建筑设计防火规范》GB 50016-2014（2018年版）",
                        "《建筑防火通用规范》GB 55037-2022"],
            "citations": [{"source": "GB 55037-2022", "clause": "第3.2.1条", "page": "p12"}],
        },
        {
            "heading": "1.1 防火分区",
            "level": 2,
            "paragraphs": ["按规范要求划分防火分区并设置防火墙、防火门。"],
            "table": {"headers": ["部位", "措施"], "rows": [["楼梯间", "乙级防火门"], ["管井", "丙级防火门"]]},
            "citations": [{"source": "GB 50016-2014（2018年版）", "clause": "第5.3.1条", "page": "p66"}],
        },
    ],
}


def cmd_engine_info(_):
    eng = detect_engines()
    grade, timeout, threads, cpus, mem = hardware()
    mems = f"{mem:.1f}G" if mem else "未知"
    print("===== 万工 WPS/Office 增强模块 · v4.0.0 能力探测 =====")
    print(f"WPS COM        : {'✅' if eng['wps'] else '❌'}")
    print(f"MS Office COM  : {'✅' if eng['ms'] else '❌'}")
    print(f"LibreOffice    : {'✅' if eng['libre'] else '❌'}")
    print(f"纯 Python      : {'✅' if eng['pure'] else '❌'}（需 python-docx / python-pptx）")
    print("----- 硬件自适应 -----")
    print(f"CPU {cpus} 核 / 内存 {mems} → 等级 {grade}（超时 {timeout}s / 线程 {threads}）")
    print("----- 能力矩阵 -----")
    print(f"docx 生成 : 纯Python ✅（style: {', '.join(DOCX_STYLES)}）")
    print(f"pptx 生成 : 纯Python ✅（theme: {', '.join(THEMES)}；layout: {', '.join(LAYOUTS)}；--narrative 叙事弧）")
    print(f"文生图提示词 : 纯Python ✅（build_image_prompt 通用 + build_node_prompt 节点大样写实化(Evai范式) → EN/ZH 双语 + 即梦/纳米香蕉/智绘/Agnes 多平台参数）")
    print(f"导出 PDF  : {'WPS→MS' if eng['wps'] or eng['ms'] else 'LibreOffice'}  |  文字提取: PDF/图片→MD  |  视觉自检: check")
    if not eng["wps"] and not eng["ms"] and not eng["libre"]:
        print("⚠ 未检测到可导出 PDF 的办公软件，导出需安装 WPS 或 LibreOffice。")


GONGWEN_SAMPLE = {
    "doc_kind": "通知",
    "redhead": "〔发文机关标志〕",
    "doc_number": "〔发文字号〕",
    "title": "〔发文机关〕关于〔事由〕的通知",
    "recipient": "〔主送机关〕：",
    "sections": [
        {"heading": "一、工作事项", "level": 1,
         "paragraphs": ["根据〔文件/会议〕要求，为〔目的〕，现就〔事项〕通知如下。"],
         "bullets": ["〔事项一：主体+动作+对象+时限〕", "〔事项二〕"]},
        {"heading": "二、具体要求", "level": 1,
         "paragraphs": ["〔要求内容，写明责任单位、反馈方式、检查节点〕"]},
    ],
    "attachments": [],
    "signer": "〔发文机关〕",
    "date": "〔2026年8月31日〕",
    "notes": [],
    "cc": "",
}

DIAGRAM_SAMPLE = {
    "type": "flow",
    "title": "消防设计审查流程",
    "nodes": [{"id": "a", "label": "受理"}, {"id": "b", "label": "资料审查"},
              {"id": "c", "label": "现场核查"}, {"id": "d", "label": "出具意见"}],
    "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "c", "label": "需整改"},
              {"from": "c", "to": "d"}],
}


def cmd_outline(args):
    which = (args.sample or "default").strip().lower()
    if which in ("gongwen", "公文", "gw"):
        print(json.dumps(GONGWEN_SAMPLE, ensure_ascii=False, indent=2))
    elif which in ("diagram", "图表", "svg"):
        print(json.dumps(DIAGRAM_SAMPLE, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(OUTLINE_SAMPLE, ensure_ascii=False, indent=2))


def cmd_diagram(args):
    with open(args.input, encoding="utf-8") as f:
        spec = json.load(f)
    out = args.output or (os.path.splitext(args.input)[0] + ".svg")
    out = build_diagram_svg(spec, out)
    print(f"✅ 已生成 SVG：{out}（type={spec.get('type','flow')}，宽度 680，符合内联可视化规范）")


def cmd_docx(args):
    with open(args.input, encoding="utf-8") as f:
        outline = json.load(f)
    out = args.output or (os.path.splitext(args.input)[0] + ".docx")
    out = build_docx(outline, out, style=args.style, footer_page=not args.no_footer_page,
                     doctype=args.doctype)
    label = "完整公文要素（红头/字号/主送/收束语/落款/抄送）" if args.style == "gongwen" \
        else DOCX_STYLES.get(args.style, DOCX_STYLES["default"])["label"]
    print(f"✅ 已生成 Word：{out}（样式：{label}）")
    if args.open:
        os.startfile(out)  # noqa: S606


def cmd_ppt(args):
    with open(args.input, encoding="utf-8") as f:
        outline = json.load(f)
    out = args.output or (os.path.splitext(args.input)[0] + ".pptx")
    th = THEMES.get(args.theme, THEMES[DEFAULT_THEME])
    out = build_pptx(outline, out, size=args.size, theme=args.theme, closing=args.closing, narrative=args.narrative, default_layout=args.layout or "content")
    narr = " / 叙事弧" if args.narrative else ""
    print(f"✅ 已生成 PPT：{out}（尺寸 {args.size} / 主题 {th['label']}{narr}）")
    if args.open:
        os.startfile(out)  # noqa: S606


def cmd_export(args):
    out = export_pdf(args.file, engine=args.engine)
    print(f"✅ 已导出 PDF：{out}")


def cmd_extract(args):
    out, md, stat = extract_text(args.file, out_path=args.out, pages=args.pages)
    print("提取统计：", "｜".join(stat))
    if out:
        print(f"✅ 已保存 Markdown：{out}（共 {len(md)} 字符）")
    else:
        print(md)


def _text_of(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".docx":
        from docx import Document

        return "\n".join(p.text for p in Document(path).paragraphs)
    if ext == ".pptx":
        from pptx import Presentation

        buf = []
        for s in Presentation(path).slides:
            for sh in s.shapes:
                if sh.has_text_frame:
                    buf.append(sh.text_frame.text)
        return "\n".join(buf)
    with open(path, encoding="utf-8") as f:
        return f.read()


def cmd_check(args):
    ext = os.path.splitext(args.file)[1].lower()
    findings = []
    if ext == ".pptx":
        findings += check_pptx(args.file)
    elif ext == ".docx":
        findings += check_docx(args.file)
    elif ext in (".md", ".txt"):
        findings.append(("✅", f"纯文本 {ext}，仅执行去AI味自检"))
    else:
        print(f"E015 仅支持 .pptx/.docx/.md/.txt 自检（当前：{ext}）")
        return

    if args.anti_ai:
        txt = _text_of(args.file)
        ai = analyze_anti_ai(txt, kind=args.doc_kind or "")
        if ai:
            findings.append(("—", f"去AI味自检：{len(ai)} 项风险"))
            findings += ai
        else:
            findings.append(("✅", "去AI味自检：未发现明显 AI 味特征"))

    print(f"===== 自检报告：{args.file} =====")
    n_warn = 0
    for f in findings:
        if len(f) >= 4:
            level, cat, prob, sug = f[0], f[1], f[2], f[3]
            if level in ("🔴", "🟡"):
                n_warn += 1
            print(f" {level} 【{cat}】{prob}")
            if sug:
                print(f"      → {sug}")
        else:
            level, msg = f[0], f[1]
            if level in ("🔴", "🟡"):
                n_warn += 1
            print(f" {level} {msg}")
    print("---- 结论：" + (f"{n_warn} 条提醒，建议按提示修订后重新生成" if n_warn else "通过") + " ----")


def main():
    ap = argparse.ArgumentParser(description="万工-* skill 的 WPS/Office 增强模块 v4.0.0（产出引擎：PPT 导演化 + 文生图提示词引擎）",
                                 formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog=__doc__.split("用法（在 skill 目录下执行）")[1])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("engine-info", help="引擎 + 硬件探测").set_defaults(fn=cmd_engine_info)
    p = sub.add_parser("outline", help="打印 JSON 模板")
    p.add_argument("--sample", nargs="?", const="default",
                   help="模板类型：default(设计说明) / gongwen(公文) / diagram(图表)")
    p.set_defaults(fn=cmd_outline)
    p = sub.add_parser("docx", help="outline JSON → Word")
    p.add_argument("--input", required=True)
    p.add_argument("--output")
    p.add_argument("--style", choices=list(DOCX_STYLES), default="default",
                   help="default=设计说明 / gongwen=完整公文(红头·字号·主送·收束语·落款·抄送) / bid=标书")
    p.add_argument("--doctype", default="",
                   help="公文文种手动指定（通知/报告/请示/函/纪要/通报/批复/决定/意见/方案…，见 outline.doc_kind）；"
                        "覆盖 outline 中的 doc_kind，决定收束语与文种纪律，仅 --style gongwen 生效")
    p.add_argument("--open", action="store_true")
    p.add_argument("--no-footer-page", action="store_true")
    p.set_defaults(fn=cmd_docx)
    p = sub.add_parser("ppt", help="outline JSON → PPT")
    p.add_argument("--input", required=True)
    p.add_argument("--output")
    p.add_argument("--size", choices=["a3", "a4", "169", "43"], default="169")
    p.add_argument("--theme", choices=list(THEMES), default=DEFAULT_THEME, help="配色主题")
    p.add_argument("--closing", action="store_true", help="末尾自动加致谢页")
    p.add_argument("--narrative", action="store_true", help="启用叙事弧：按 outline 各 section 的 act 字段插入章节分隔页（钩子→张力→释放）")
    p.add_argument("--layout", help=f"默认版面（缺省 content；可在 outline 各 section 用 layout 字段覆盖）：{', '.join(LAYOUTS)}")
    p.add_argument("--open", action="store_true")
    p.set_defaults(fn=cmd_ppt)
    p = sub.add_parser("export", help="docx/pptx → PDF")
    p.add_argument("--file", required=True)
    p.add_argument("--engine", choices=["auto", "wps", "ms", "libre"], default="auto")
    p.set_defaults(fn=cmd_export)
    p = sub.add_parser("extract", help="PDF/图片 → Markdown 文字提取（扫描页自动 OCR）")
    p.add_argument("--file", required=True)
    p.add_argument("--out", help="输出 .md 路径（缺省仅打印）")
    p.add_argument("--pages", help="页码范围，如 '1-5,8'（缺省全部）")
    p.add_argument("--no-mark-risk", action="store_true", help="不标记高风险数字串")
    p.set_defaults(fn=cmd_extract)
    p = sub.add_parser("imgprompt", help="文生图提示词引擎：brief JSON / --preset node 节点大样 → 双语(EN/ZH)提示词 + 多平台参数")
    p.add_argument("--preset", choices=["", "node"], default="", help="预置模板：留空=通用文生图；node=节点大样写实化（Evai 范式）")
    p.add_argument("--input", required=False, help="通用模式 brief JSON（subject/scene/style/ratio/mode/preserve/exclude…）")
    p.add_argument("--node", help="节点名称（preset=node，必填，如 屋面女儿墙泛水节点）")
    p.add_argument("--node-type", help="节点类型自动背景（preset=node，可选；roof/facade/basement/stair，用户 --background 优先）")
    p.add_argument("--materials", help="材料层次 外→内 逗号分隔（preset=node，如 SBS防水卷材,XPS保温板,钢筋混凝土）")
    p.add_argument("--view", help="视角（preset=node，默认 竖向半剖透视）")
    p.add_argument("--annotation", help="标注要求（preset=node，默认 绿色引线+白色中文）")
    p.add_argument("--background", help="背景环境（preset=node，可选）")
    p.add_argument("--platform", help="目标平台提示（preset=node，可选；evai/jimeng/nano-banana…）")
    p.add_argument("--avoid", help="负向覆盖（preset=node，可选）")
    p.add_argument("--mode", default="t2i", help="t2i | img2img（img2img 需配 --preserve）")
    p.add_argument("--preserve", help="img2img 必须保留项（preset=node 也适用）")
    p.add_argument("--ratio", default="", help="比例 3:4 / 16:9（node 预设默认 3:4）")
    p.add_argument("--output", help="输出 JSON 路径（缺省打印到终端）")
    p.set_defaults(fn=cmd_imgprompt)
    p = sub.add_parser("diagram", help="流程图/架构图 → SVG（680px 规范，可内联展示）")
    p.add_argument("--input", required=True, help="图表 JSON（nodes/edges）")
    p.add_argument("--output", help="输出 .svg 路径")
    p.set_defaults(fn=cmd_diagram)
    p = sub.add_parser("check", help="自检 .pptx/.docx/.md（版式 + 去AI味）")
    p.add_argument("--file", required=True)
    p.add_argument("--anti-ai", action="store_true", help="执行去AI味自检（意义膨胀/排比/抽象词/文种）")
    p.add_argument("--doc-kind", default="", help=f"文种：{'/'.join(DOC_KINDS)}")
    p.set_defaults(fn=cmd_check)
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
