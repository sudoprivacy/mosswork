#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
万工-消防设计 · 取证脚本
把 55 本消防规范 PDF 变成可路由、可取证的本地知识源。

子命令
  list                     列出全部规范：编号 | 名称 | 页数 | 域 | 取证方式
  route  <关键词>          按主题路由：该查哪本规范的哪一页
  get    <规范> <起> [止]  抽取原文页（文字层直抽；扫描件自动 OCR 并缓存）
                            --ocr-engine hunyuan 切换 HunyuanOCR 在线通道（讯飞 MaaS）
  search <关键词>          在 33 本有文字层的规范全文中检索
  toc    <规范>            列出该规范的章节目录（含 PDF 页码）
  offset <规范>            显示 印刷页码→PDF页码 的偏移量推定

说明
  - 所有页码均为 PDF 页码（与 PDF 阅读器显示一致）。
  - 扫描件 OCR 默认 rapidocr-onnxruntime（约 4 秒/页），结果缓存到 ocr_cache.json；
    `--ocr-engine hunyuan` 走讯飞 MaaS HunyuanOCR 在线通道（约 6 秒/页，需 XFYUN_API_KEY，
    表格输出 Markdown、合并单元格结构有损需人工校对；2026-09-05 GB50084 p21 实测 6/6 关键项命中），
    结果同样缓存（键 hunyuan:页号）。
"""
import os
import re
import sys
import json
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
DATA = os.path.join(SKILL, "references", "_codes.json")

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# 语料根目录：默认指向作者本机路径。
# 换机 / 换人使用时，设置环境变量覆盖即可（无需改代码）：
#   Windows:  set WANGOING_FIRE_SRC=<你的语料根路径>
#   Linux/mac: export WANGOING_FIRE_SRC=/your/path/A005消防规范
SRC = os.environ.get("WANGOING_FIRE_SRC", r"corpus")
CACHE_DIR = os.path.join(SKILL, "scripts", ".cache")
OCR_CACHE = os.path.join(CACHE_DIR, "ocr_cache.json")
TEXT_CACHE = os.path.join(CACHE_DIR, "text")
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(TEXT_CACHE, exist_ok=True)


def load_codes():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def norm(s):
    return re.sub(r"[\s\u3000]+", "", s or "")


def find_code(token):
    """按规范号或文件名关键字定位条目"""
    codes = load_codes()
    t = norm(token).upper()
    # 精确规范号优先
    for c in codes:
        for sid in c.get("ids", []):
            if norm(sid).upper() == t:
                return c
    # 规范号包含
    for c in codes:
        for sid in c.get("ids", []):
            s = norm(sid).upper()
            if s and (s in t or t in s):
                return c
    # 名称关键字
    for c in codes:
        if t in norm(c.get("name", "")):
            return c
    # 文件名
    for c in codes:
        if t in norm(c.get("file", "")):
            return c
    return None


# ---------------- 分卷解析 ----------------
def part_of(code, pno):
    """全局页码 → (该分卷相对路径, 卷内页码)"""
    parts = code.get("parts")
    if parts:
        for p in parts:
            if p["offset"] < pno <= p["offset"] + p["pages"]:
                return p["rel"], pno - p["offset"]
        last = parts[-1]
        return last["rel"], last["pages"]
    return code.get("rel") or code["file"], pno


def path_of(rel):
    p = os.path.join(SRC, rel)
    if not os.path.exists(p):
        sys.stderr.write(
            "[verify] 语料文件不存在：%s\n"
            "        请设置环境变量 WANGOING_FIRE_SRC 指向语料根目录\n"
            "        （该目录应包含 _codes.json 中记录的各规范 PDF / 文档）。\n" % p
        )
        sys.exit(2)
    return p


def open_part(code, pno):
    """打开全局页码所在的分卷，返回 (doc, 卷内页码)"""
    import pymupdf
    rel, local = part_of(code, pno)
    return pymupdf.open(path_of(rel)), local


# ---------------- 文字层抽取 ----------------
def open_doc(code):
    import pymupdf
    return pymupdf.open(path_of(code.get("rel") or code["file"]))


def text_page(code, pno):
    """抽取单页文字；无文字层返回空串"""
    if pno < 1 or pno > code["pages"]:
        return ""
    doc, local = open_part(code, pno)
    try:
        t = doc.load_page(local - 1).get_text("text") or ""
    finally:
        doc.close()
    return t


_OCR = None


def get_ocr():
    global _OCR
    if _OCR is None:
        from rapidocr_onnxruntime import RapidOCR
        _OCR = RapidOCR()
    return _OCR


def load_ocr_cache():
    if os.path.exists(OCR_CACHE):
        with open(OCR_CACHE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_ocr_cache(c):
    tmp = OCR_CACHE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(c, f, ensure_ascii=False)
    os.replace(tmp, OCR_CACHE)


def ocr_page(code, pno, dpi=170):
    import math
    from PIL import Image
    Image.MAX_IMAGE_PIXELS = None
    cache = load_ocr_cache()
    key = code["file"]
    slot = cache.setdefault(key, {})
    hit = slot.get(str(pno))
    if hit:
        return hit, True
    doc, local = open_part(code, pno)
    try:
        page = doc.load_page(local - 1)
        r = page.rect
        area = max((r.width / 72.0) * (r.height / 72.0), 0.01)
        dpi = max(72, min(dpi, int(math.sqrt(30_000_000 / area))))
        img = page.get_pixmap(dpi=dpi).tobytes("png")
    finally:
        doc.close()
    res, _ = get_ocr()(img)
    lines = [x[1].strip() for x in (res or []) if x[1] and x[1].strip()]
    text = "\n".join(lines)
    slot[str(pno)] = text
    save_ocr_cache(cache)
    return text, False


def hunyuan_ocr_page(code, pno, dpi=200):
    """HunyuanOCR 在线兜底通道（讯飞星辰 MaaS，OpenAI 兼容；urllib 直连零新依赖）。
    需环境变量 XFYUN_API_KEY。结果缓存键 hunyuan:<页号>。"""
    import base64 as _b64
    import urllib.request
    key = os.environ.get("XFYUN_API_KEY", "")
    if not key:
        raise RuntimeError("XFYUN_API_KEY 未设置——HunyuanOCR 在线通道不可用，请 export 后重试或用默认 rapid 引擎")
    cache = load_ocr_cache()
    slot = cache.setdefault(code["file"], {})
    ck = f"hunyuan:{pno}"
    hit = slot.get(ck)
    if hit:
        return hit, True
    doc, local = open_part(code, pno)
    try:
        page = doc.load_page(local - 1)
        png = page.get_pixmap(dpi=dpi).tobytes("png")
    finally:
        doc.close()
    body = json.dumps({
        "model": "xophunyuanocr",
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": "请逐字识别图片中的全部文字内容，这是消防规范页面。"
                                     "保持条文号、数字、表格结构原样输出，表格用 Markdown 格式。不要添加任何解释。"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64," + _b64.b64encode(png).decode()}},
        ]}],
        "temperature": 0.1, "max_tokens": 8192,
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://maas-api.cn-huabei-1.xf-yun.com/v2/chat/completions",
        data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
    with urllib.request.urlopen(req, timeout=120) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    text = (data.get("choices") or [{}])[0].get("message", {}).get("content", "")
    if not text.strip():
        raise RuntimeError(f"HunyuanOCR 返回空结果（{code['file']} p{pno}）")
    slot[ck] = text
    save_ocr_cache(cache)
    return text, False


# ---------------- 子命令 ----------------
def cmd_list(args):
    codes = load_codes()
    print(f"{'规范号':<22}{'名称':<34}{'页':>5}  {'取证':<6}{'域'}")
    print("-" * 96)
    for c in codes:
        ids = "/".join(c.get("ids", [])[:2])[:20]
        nm = c.get("name", "")[:32]
        mode = "文字层" if c.get("has_text") else "OCR"
        print(f"{ids:<22}{nm:<34}{c.get('pages', 0):>5}  {mode:<6}{c.get('domain', '')}")
    print(f"\n共 {len(codes)} 本 | 文字层 {sum(1 for c in codes if c.get('has_text'))} 本 | 扫描件 {sum(1 for c in codes if not c.get('has_text'))} 本")


def cmd_toc(args):
    code = find_code(args.code)
    if not code:
        print("未找到规范：", args.code)
        return
    print(f"# {code['name']}  共 {code['pages']} 页　域：{code.get('domain','')}")
    print(f"# 路径：{code.get('rel') or code['file']}")
    if code.get("parts"):
        segs = []
        for p in code["parts"]:
            segs.append("%s (p%d-%d)" % (os.path.basename(p["rel"]), p["offset"] + 1, p["offset"] + p["pages"]))
        print("# 分卷：" + " | ".join(segs))
    print(f"# 目录来源：{code.get('toc_method', '-')}   印刷页码→PDF页码偏移：{code.get('offset', '未知')}\n")
    for t, p in code.get("toc", []):
        print(f"  p{p:>4}  {t}")


def cmd_get(args):
    code = find_code(args.code)
    if not code:
        print("未找到规范：", args.code)
        print("可用 verify.py list 查看全部")
        return
    p1 = max(1, args.start)
    p2 = min(code["pages"], args.stop or args.start)
    if p1 > p2:
        p1, p2 = p2, p1
    print(f"# {code['name']}  PDF 第 {p1}-{p2} 页  （共 {code['pages']} 页）\n")
    for p in range(p1, p2 + 1):
        txt = text_page(code, p) if code.get("has_text") else ""
        src = "文字层"
        if not txt.strip():
            if args.no_ocr:
                print(f"===== PAGE {p} =====  [扫描件，无文字层；加 --ocr 或去掉 --no-ocr 触发 OCR]")
                continue
            if getattr(args, "ocr_engine", "rapid") == "hunyuan":
                txt, cached = hunyuan_ocr_page(code, p)
                src = "OCR(Hunyuan,缓存)" if cached else "OCR(Hunyuan)"
            else:
                txt, cached = ocr_page(code, p)
                src = "OCR(缓存)" if cached else "OCR"
        clean = re.sub(r"\n{3,}", "\n\n", txt).strip()
        print(f"===== PAGE {p}  [{src}] =====")
        print(clean)
        print()
    print(f"--- 引用格式 ---")
    rel_a, local_a = part_of(code, p1)
    print(f"源：{rel_a} 第 {p1}-{p2} 页（卷内 p{local_a}）"
          + (f"　[分卷：{' + '.join(str(p['pages']) for p in code['parts'])} 页]" if code.get("parts") else ""))


def cmd_search(args):
    kw = args.keyword
    codes = [c for c in load_codes() if c.get("has_text")]
    hits = []
    for c in codes:
        fp = os.path.join(TEXT_CACHE, re.sub(r'[\\/:*?"<>|]', "_", c["file"])[:60] + ".txt")
        if not os.path.exists(fp):
            continue
        with open(fp, encoding="utf-8") as f:
            txt = f.read()
        for m in re.finditer(re.escape(kw), txt):
            s = max(0, m.start() - 120)
            e = min(len(txt), m.end() + 160)
            # 找到所属 PAGE 标记
            head = txt.rfind("===== [", 0, m.start())
            pg = ""
            if head >= 0:
                mm = re.search(r"PAGE (\d+)", txt[head:head + 200])
                if mm:
                    pg = mm.group(1)
            seg = re.sub(r"\s+", "", txt[s:e])
            hits.append((c, pg, seg))
            if len(hits) >= args.limit * 6:
                break
    if not hits:
        print(f"文字层规范中未检索到「{kw}」。")
        print("提示：22 本扫描件不参与全文检索，可用 verify.py route <关键词> 定位后，再 verify.py get <规范> <页> --ocr 取证。")
        return
    print(f"检索「{kw}」命中 {len(hits)} 处（显示前 {args.limit} 处）\n")
    for c, pg, seg in hits[:args.limit]:
        print(f"[{c['ids'][0] if c.get('ids') else c['name']}] p{pg} · {c['name']}")
        print(f"   …{seg}…")
        print()


def cmd_route(args):
    kw = args.keyword
    kws = [norm(k) for k in re.split(r"[\s,，、]+", kw) if norm(k)]
    if not kws:
        kws = [norm(kw)]
    codes = load_codes()
    scored = []
    for c in codes:
        score = 0
        why = []
        name_blob = norm(c.get("name", "")) + norm(c.get("domain", "")) + "".join(norm(i) for i in c.get("ids", []))
        topic_tokens = [norm(t) for t in (c.get("topics") or "").split()]
        topic_tokens = [t for t in topic_tokens if len(t) >= 2]
        toc_blob = [(norm(t), p) for t, p in c.get("toc", [])]
        qblob = norm(kw)
        hit_any = False
        hit_page = None
        for k in kws:
            # 章节标题命中权重最高
            for t, p in toc_blob:
                if k in t:
                    score += 8
                    why.append(f"章节「{t}」p{p}")
                    hit_any = True
                    if hit_page is None:
                        hit_page = p
                    break
            if k in name_blob:
                score += 4
                why.append("规范名")
                hit_any = True
            # 主题词命中（支持「钢结构防火涂料」这类复合查询：统计命中主题词数量）
            tm = [t for t in topic_tokens if t in k]
            if not tm:
                tm = [t for t in topic_tokens if t in qblob]
            if tm:
                score += 5 * len(tm)
                why.append("主题 " + "/".join(tm[:3]))
                hit_any = True
        if not hit_any:
            continue
        c = dict(c)
        # 用户明确要"图示/图集/做法/详图"时，图集(norm rank 6)优先于通用规范
        if re.search(r"图示|图集|做法|详图|构造详图|安装图|选用与安装", kw) and c.get("rank") == 6:
            score += 16
            why.append("图示优先")
        # 精确提示页码（hints）> 章节命中页 > 正文起始
        hp = None
        for k in kws:
            for hk, hpg in (c.get("hints") or {}).items():
                if hk in k or hk in qblob:
                    if hp is None or hpg < hp:
                        hp = hpg
        if hp is not None:
            c["anchor_page"] = [hp, min(hp + 2, c["pages"])]
            why.append(f"锚点 p{hp}")
        elif hit_page is not None:
            c["anchor_page"] = [hit_page, min(hit_page + 3, c["pages"])]
        # 效力层级高的加权（仅在已命中时生效）
        # 通用规范优先：合规判据先看 GB 55037 / GB 55036，再看专业标准
        rk = c.get("rank", 9)
        if rk <= 2:
            score += 12
        elif rk == 3:
            score += 2
        scored.append((score, c, sorted(set(why))[:4]))
    if not scored:
        print(f"未路由到规范：「{kw}」")
        print("建议：换更具体的术语（如「防火分区」「疏散净宽度」「消防电梯前室」），或先 verify.py list 浏览。")
        return
    scored.sort(key=lambda x: -x[0])
    print(f"路由「{kw}」→ 命中 {len(scored)} 本，按效力层级与相关度排序：\n")
    for score, c, why in scored[:args.top]:
        mode = "文字层" if c.get("has_text") else "扫描件(需OCR)"
        print(f"● {c['ids'][0] if c.get('ids') else ''} {c['name']}   [{mode}]")
        print(f"  文件：{c['file']}")
        print(f"  命中：{', '.join(why)}")
        pg = c.get("anchor_page")
        if pg:
            print(f"  建议取证：python scripts/verify.py get \"{c['ids'][0] if c.get('ids') else c['name']}\" {pg[0]} {pg[1]}")
        else:
            toc6 = " · ".join(f"p{p} {t}" for t, p in c.get("toc", [])[:6])
            if toc6:
                print(f"  章节：{toc6}")
        print()


def cmd_offset(args):
    code = find_code(args.code)
    if not code:
        print("未找到规范：", args.code)
        return
    print(f"{code['name']}: 印刷页码 → PDF页码 偏移 = {code.get('offset', '未知')}（PDF页 = 印刷页 + 偏移）")


def main():
    ap = argparse.ArgumentParser(description="万工-消防设计 取证脚本")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="列出全部规范").set_defaults(func=cmd_list)

    p = sub.add_parser("route", help="按主题路由")
    p.add_argument("keyword")
    p.add_argument("--top", type=int, default=6)
    p.set_defaults(func=cmd_route)

    p = sub.add_parser("get", help="抽取原文页（PDF页码）")
    p.add_argument("code")
    p.add_argument("start", type=int)
    p.add_argument("stop", type=int, nargs="?")
    p.add_argument("--ocr", action="store_true", help="扫描件强制 OCR（默认行为）")
    p.add_argument("--no-ocr", action="store_true", help="跳过 OCR，只输出文字层")
    p.add_argument("--ocr-engine", choices=["rapid", "hunyuan"], default="rapid", dest="ocr_engine",
                   help="扫描件 OCR 引擎：rapid=本地 RapidOCR（默认）；hunyuan=讯飞 MaaS 在线（需 XFYUN_API_KEY，表格保真更好）")
    p.set_defaults(func=cmd_get)

    p = sub.add_parser("search", help="文字层规范全文检索")
    p.add_argument("keyword")
    p.add_argument("--limit", type=int, default=12)
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("toc", help="章节目录")
    p.add_argument("code")
    p.set_defaults(func=cmd_toc)

    p = sub.add_parser("offset", help="页码偏移")
    p.add_argument("code")
    p.set_defaults(func=cmd_offset)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
