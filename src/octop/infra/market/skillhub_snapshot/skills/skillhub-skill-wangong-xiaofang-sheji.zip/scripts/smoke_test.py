#!/usr/env python3
# -*- coding: utf-8 -*-
"""
smoke_test.py — wps_bridge.py 发布前冒烟自检（4 个万工-* skill 同源组件）
============================================================================
覆盖 v1 四引擎 / v3 产出引擎 / v3.1 公文·图表·去AI味·文种覆盖 / v4.0.0 文生图提示词引擎（通用 + 节点大样写实化预置）+ 叙事弧 PPT 导演化。

用法：
    python scripts/smoke_test.py                 # 全量
    python scripts/smoke_test.py --only core     # 核心产出链路
    python scripts/smoke_test.py --only extract  # 文字提取（需 pymupdf/rapidocr）
退出码：0 = 全部通过；1 = 存在失败（发布前必须为 0）。
所有产物写入系统临时目录，不污染 skill 目录。
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

BRIDGE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wps_bridge.py")
PY = sys.executable

SAMPLE = {
    "title": "冒烟测试：消防设计说明",
    "subtitle": "xx 项目（冒烟样例）",
    "meta": {"单位": "测试", "专业": "建筑", "日期": "2026-08-31"},
    "sections": [
        {"heading": "1 设计依据", "level": 1,
         "paragraphs": ["本设计依据现行国家工程建设消防技术标准编制。"],
         "bullets": ["《建筑防火通用规范》GB 55037-2022"],
         "citations": [{"source": "GB 55037-2022", "clause": "第3.2.1条", "page": "p12"}]},
        {"heading": "1.1 防火分区", "level": 2,
         "paragraphs": ["按规范要求划分防火分区。"],
         "table": {"headers": ["部位", "措施"], "rows": [["楼梯间", "乙级防火门"]]}},
    ],
}

GONGWEN = {
    "doc_kind": "通知",
    "redhead": "〔发文机关〕",
    "doc_number": "〔发文字号〕",
    "title": "〔发文机关〕关于〔事由〕的通知",
    "recipient": "〔主送机关〕：",
    "sections": [{"heading": "一、工作事项", "level": 1,
                  "paragraphs": ["根据〔文件〕要求，现就有关事项通知如下。"]}],
    "signer": "〔发文机关〕",
    "date": "2026年8月31日",
    "cc": "〔抄送单位〕",
}

DIAGRAM = {
    "type": "flow",
    "title": "冒烟流程",
    "nodes": [{"id": "a", "label": "受理"}, {"id": "b", "label": "审查"},
              {"id": "c", "label": "出具意见"}],
    "edges": [{"from": "a", "to": "b"}, {"from": "b", "to": "c"}],
}

# v4.0.0 文生图提示词引擎样例
IMGPROMPT_T2I = {
    "subject": "a modern elderly-care clubhouse, low-rise white concrete with warm wood louvers",
    "scene": "a lakeside garden in Chongli, winter, soft snow, pine trees",
    "style": "architectural photography, realistic, daylight, wide-angle",
    "light": "golden-hour",
    "composition": "centered front elevation, foreground reflecting pool, ratio-driven 16:9",
    "color": "warm white and timber beige with a touch of pine green",
    "ratio": "16:9",
    "mode": "t2i",
    "exclude": "people, vehicles, watermark",
    "quality": "high detail, crisp, professional architectural rendering",
}

IMGPROMPT_IMG2IMG = {
    "subject": "the same clubhouse massing",
    "scene": "same site, change season to midsummer with lush green lawn",
    "style": "keep the architectural photography look",
    "light": "noon",
    "composition": "same centered front elevation and reflecting pool composition",
    "color": "keep warm white and timber beige, add seasonal greens",
    "ratio": "16:9",
    "mode": "img2img",
    "preserve": "the building silhouette, window grid, and roof profile",
    "exclude": "people, vehicles, watermark",
    "quality": "high detail, crisp",
}

# v4.0.0 叙事弧 PPT 导演化样例
NARRATIVE = {
    "title": "冒烟测试：康养社区汇报（叙事弧）",
    "subtitle": "v4.0.0 导演化 PPT",
    "meta": {"单位": "测试", "专业": "建筑", "日期": "2026-08-31"},
    "sections": [
        {"act": "第一幕 · 钩子", "layout": "quote", "heading": "为什么是崇礼",
         "paragraphs": ["冰雪康养与候鸟式养老叠加，提出空间新命题。"]},
        {"act": "第一幕 · 钩子", "layout": "content", "heading": "1 定位",
         "level": 1, "paragraphs": ["以‘小镇+康养’为内核。"],
         "bullets": ["低密度", "配套前置"], "citations": [{"source": "文本", "clause": "P12", "page": "p12"}]},
        {"act": "第二幕 · 张力", "layout": "kpi", "heading": "2 指标",
         "level": 1, "kpis": [{"label": "容积率", "value": "1.2"}, {"label": "绿地率", "value": "38%"}]},
        {"act": "第三幕 · 释放", "layout": "timeline", "heading": "3 节奏",
         "level": 1, "steps": [{"t": "2026 Q4", "d": "示范区"}, {"t": "2027 Q2", "d": "一期"}]},
    ],
}

# 故意含 AI 味的样本，用于验证 anti_ai 能检出
AI_TEXT = ("近年来，我局深入贯彻落实高质量发展要求，工作取得显著成效，亮点纷呈。\n"
           "下面从三个方面展开。相关部门要进一步强化统筹，全面加强领导，持续优化服务。\n"
           "未来，我们将凝心聚力、砥砺前行，奋力谱写高质量发展新篇章。")


def run(cmd, label):
    print("  ▶ %s" % label)
    try:
        r = subprocess.run([PY, BRIDGE] + cmd, capture_output=True, text=True, timeout=180)
    except Exception as e:  # noqa: BLE001
        print("    🔴 %s 异常：%s" % (label, e))
        return False
    ok = r.returncode == 0
    for line in (r.stdout or r.stderr).strip().splitlines()[-2:]:
        print("      ", line)
    print("    %s %s 退出码 %d" % ("✅" if ok else "🔴", label, r.returncode))
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["core", "extract"], default="all")
    args = ap.parse_args()

    if not os.path.exists(BRIDGE):
        print("🔴 未找到 wps_bridge.py：%s" % BRIDGE)
        return 1

    tmp = tempfile.mkdtemp(prefix="wps_smoke_")
    ojson = os.path.join(tmp, "outline.json")
    gjson = os.path.join(tmp, "gongwen.json")
    djson = os.path.join(tmp, "diagram.json")
    aifile = os.path.join(tmp, "ai_text.md")
    docx = os.path.join(tmp, "smoke.docx")
    pptx = os.path.join(tmp, "smoke.pptx")

    with open(ojson, "w", encoding="utf-8") as f:
        json.dump(SAMPLE, f, ensure_ascii=False)
    with open(gjson, "w", encoding="utf-8") as f:
        json.dump(GONGWEN, f, ensure_ascii=False)
    with open(djson, "w", encoding="utf-8") as f:
        json.dump(DIAGRAM, f, ensure_ascii=False)
    with open(aifile, "w", encoding="utf-8") as f:
        f.write(AI_TEXT)

    # v4.0.0 文生图 / 叙事弧样例落盘
    img_t2i = os.path.join(tmp, "img_t2i.json")
    img_img2img = os.path.join(tmp, "img_img2img.json")
    narr = os.path.join(tmp, "narr.json")
    with open(img_t2i, "w", encoding="utf-8") as f:
        json.dump(IMGPROMPT_T2I, f, ensure_ascii=False)
    with open(img_img2img, "w", encoding="utf-8") as f:
        json.dump(IMGPROMPT_IMG2IMG, f, ensure_ascii=False)
    with open(narr, "w", encoding="utf-8") as f:
        json.dump(NARRATIVE, f, ensure_ascii=False)

    results = []
    results.append(run(["engine-info"], "engine-info（引擎+硬件）"))
    if args.only in ("all", "core"):
        results.append(run(["docx", "--input", ojson, "--output", docx, "--style", "bid"], "docx --style bid"))
        results.append(run(["docx", "--input", gjson, "--output", os.path.join(tmp, "gw.docx"), "--style", "gongwen"],
                           "docx --style gongwen（v3 公文要素）"))
        # v3.1：--doctype 手动覆盖文种（请示→收束语「妥否，请批示」）
        gw2 = os.path.join(tmp, "gw_doctype.docx")
        ok_dt = run(["docx", "--input", gjson, "--output", gw2, "--style", "gongwen", "--doctype", "请示"],
                    "docx --style gongwen --doctype 请示（v3.1 文种覆盖）")
        if ok_dt and os.path.exists(gw2):
            try:
                from docx import Document
                _t = "\n".join(p.text for p in Document(gw2).paragraphs)
                ok_dt = "妥否，请批示。" in _t
                print("      %s 收束语按 --doctype 覆盖为请示" % ("✅" if ok_dt else "🔴"))
            except Exception as e:  # noqa: BLE001
                print("      ⏭ 收束语校验跳过（%s）" % e)
        results.append(ok_dt)
        results.append(run(["ppt", "--input", ojson, "--output", pptx, "--size", "a3", "--theme", "tech", "--closing"],
                           "ppt --size a3 --theme tech --closing"))
        results.append(run(["diagram", "--input", djson, "--output", os.path.join(tmp, "flow.svg")],
                           "diagram → SVG（v3）"))
        results.append(run(["check", "--file", docx], "check docx"))
        results.append(run(["check", "--file", pptx], "check pptx"))
        results.append(run(["check", "--file", aifile, "--anti-ai"], "check --anti-ai（v3 去AI味）"))
        results.append(run(["export", "--file", docx, "--engine", "auto"], "export docx→PDF"))
        # ===== v4.0.0 新增 T-case =====
        # 文生图提示词引擎：t2i
        imgout = os.path.join(tmp, "img_t2i_out.json")
        ok_img = run(["imgprompt", "--input", img_t2i, "--output", imgout], "imgprompt t2i（v4 文生图引擎）")
        if ok_img and os.path.exists(imgout):
            try:
                d = json.load(open(imgout, encoding="utf-8"))
                ok_img = bool(d.get("en_prompt")) and bool(d.get("zh_prompt")) and len(d.get("platforms", {})) == 4
                print("      %s 双语提示词 + 4 平台参数完整（mode=%s, ratio=%s）" %
                      ("✅" if ok_img else "🔴", d.get("mode"), d.get("ratio")))
            except Exception as e:  # noqa: BLE001
                print("      ⏭ imgprompt 校验跳过（%s）" % e)
        results.append(ok_img)
        # 文生图提示词引擎：img2img（保留项）
        imgout2 = os.path.join(tmp, "img_img2img_out.json")
        ok_img2 = run(["imgprompt", "--input", img_img2img, "--output", imgout2], "imgprompt img2img（v4 保留项）")
        if ok_img2 and os.path.exists(imgout2):
            try:
                d = json.load(open(imgout2, encoding="utf-8"))
                ok_img2 = "Strictly preserve" in d.get("en_prompt", "")
                print("      %s img2img 保留项写入 EN 提示词" % ("✅" if ok_img2 else "🔴"))
            except Exception as e:  # noqa: BLE001
                print("      ⏭ imgprompt img2img 校验跳过（%s）" % e)
        results.append(ok_img2)
        # 叙事弧 PPT 导演化
        narrppt = os.path.join(tmp, "narr.pptx")
        ok_narr = run(["ppt", "--input", narr, "--output", narrppt, "--narrative", "--size", "a3", "--theme", "coral"],
                      "ppt --narrative（v4 叙事弧导演化）")
        if ok_narr and os.path.exists(narrppt):
            try:
                from pptx import Presentation
                _n = len(Presentation(narrppt).slides)
                ok_narr = _n >= 6  # 封面 + 3 幕分隔 + 4 内容 = 8；>=6 即分隔页生效
                print("      %s 叙事弧生效（%d 页，含章节分隔页）" % ("✅" if ok_narr else "🔴", _n))
            except Exception as e:  # noqa: BLE001
                print("      ⏭ 叙事弧页校验跳过（%s）" % e)
        results.append(ok_narr)
        # --layout 默认版面覆盖
        ok_layout = run(["ppt", "--input", narr, "--output", os.path.join(tmp, "layout.pptx"), "--layout", "card-grid"],
                        "ppt --layout card-grid（v4 默认版面覆盖）")
        results.append(ok_layout)
        # 文生图提示词引擎：节点大样写实化预置（Evai 范式）
        nodeout = os.path.join(tmp, "node_out.json")
        ok_node = run(["imgprompt", "--preset", "node",
                       "--node", "屋面女儿墙泛水节点",
                       "--materials", "SBS防水卷材,XPS保温板,钢筋混凝土,水泥砂浆",
                       "--background", "屋顶蓝天背景，远处有城市建筑轮廓",
                       "--ratio", "3:4", "--platform", "evai", "--output", nodeout],
                      "imgprompt --preset node（节点大样写实化）")
        if ok_node and os.path.exists(nodeout):
            try:
                d = json.load(open(nodeout, encoding="utf-8"))
                ok_node = (d.get("preset") == "node"
                           and bool(d.get("en_prompt")) and bool(d.get("zh_prompt"))
                           and "green" in d.get("en_prompt", "").lower()
                           and "绿色" in d.get("zh_prompt", "")
                           and "杜绝" in d.get("zh_prompt", ""))
                print("      %s 节点大样范式固化（绿引线/白中文/杜绝卡通）" % ("✅" if ok_node else "🔴"))
            except Exception as e:  # noqa: BLE001
                print("      ⏭ node 校验跳过（%s）" % e)
        results.append(ok_node)
        # 节点预置变体：--platform nano-banana + --node-type 自动背景 + 中文逗号材料
        nodeout_nb = os.path.join(tmp, "node_nb.json")
        ok_node_nb = run(["imgprompt", "--preset", "node",
                          "--node", "地下室底板后浇带",
                          "--node-type", "basement",
                          "--materials", "C30补偿收缩混凝土、止水钢板、水泥基渗透结晶",
                          "--ratio", "16:9", "--platform", "nano-banana", "--output", nodeout_nb],
                         "imgprompt --preset node（nano-banana 变体 + node-type 自动背景）")
        if ok_node_nb and os.path.exists(nodeout_nb):
            try:
                d = json.load(open(nodeout_nb, encoding="utf-8"))
                nb_plat = d.get("platforms", {}).get("_target", {})
                ok_node_nb = (d.get("preset") == "node"
                              and "地下" in d.get("zh_prompt", "")
                              and "nano-banana" in nb_plat.get("label", ""))
                print("      %s 节点变体（node-type 背景+中文逗号材料+nano-banana 目标）" % ("✅" if ok_node_nb else "🔴"))
            except Exception as e:  # noqa: BLE001
                print("      ⏭ node nano-banana 校验跳过（%s）" % e)
        results.append(ok_node_nb)
        # 节点预置边界：非法 --node-type 须打印警告且不注入自动背景
        ok_nt = False
        r_nt = subprocess.run([PY, BRIDGE, "imgprompt", "--preset", "node",
                               "--node", "幕墙龙骨连接节点", "--node-type", "rof",
                               "--materials", "铝合金型材,不锈钢螺栓"],
                              capture_output=True, text=True, timeout=120)
        out_nt = (r_nt.stdout or "") + (r_nt.stderr or "")
        ok_nt = (r_nt.returncode == 0
                 and "⚠️ 未识别的 --node-type 'rof'" in out_nt
                 and "蓝天" not in out_nt and "地下" not in out_nt)
        print("      %s 非法 node-type 警告 + 无自动背景" % ("✅" if ok_nt else "🔴"))
        results.append(ok_nt)
    if args.only in ("all", "extract"):
        if os.path.exists(docx):
            r = subprocess.run([PY, BRIDGE, "export", "--file", docx, "--engine", "auto"],
                               capture_output=True, text=True, timeout=180)
            pdf = os.path.join(tmp, "smoke.pdf")
            if r.returncode == 0 and os.path.exists(pdf):
                results.append(run(["extract", "--file", pdf, "--out", os.path.join(tmp, "smoke.md"), "--pages", "1"],
                                   "extract PDF→Markdown"))
            else:
                print("  ⏭ extract 跳过（PDF 导出不可用，非 extract 本身失败）")
        else:
            print("  ⏭ extract 跳过（无前置 PDF）")

    n_ok = sum(results)
    n_all = len(results)
    print("=" * 56)
    print("冒烟结果：%d/%d 通过 ｜ 临时产物：%s" % (n_ok, n_all, tmp))
    if n_ok == n_all:
        print("✅ 全部通过，可以发布")
        return 0
    print("🔴 存在失败，发布前必须修复")
    return 1


if __name__ == "__main__":
    sys.exit(main())
