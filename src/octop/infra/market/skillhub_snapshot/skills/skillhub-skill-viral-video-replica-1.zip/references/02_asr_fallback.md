# 语音识别备用路径（仅当硬字幕缺失时启用）

如用户要求启用 ASR 或拼图无可用文字，再执行本流程。

## 依赖选择

| 实现 | 适用 | 体积/耗时 |
|------|------|----------|
| `faster-whisper` | Windows/Linux，支持中文，准确率高 | 约 200MB 依赖 + 模型 |
| `whisper-cpp` | macOS / Windows，轻量 CPU 推理 | 几百 MB（含 small 模型） |
| `openai-whisper` | 通用，需 torch | 1-2GB |

建议优先尝试 `faster-whisper`，命令示例：

```bash
# 装进隔离 venv
~/.workbuddy/binaries/python/versions/3.13.12/python.exe -m venv ~/.workbuddy/binaries/python/envs/default
~/.workbuddy/binaries/python/envs/default/Scripts/python.exe -m pip install faster-whisper -i https://pypi.tuna.tsinghua.edu.cn/simple

# 转写
~/.workbuddy/binaries/python/envs/default/Scripts/python.exe -m faster_whisper audio.wav --model small --language zh --output_format json
```

## 流程

1. 调用 `extract_material.py --audio` 导出 16k 单声道 `audio.wav`。
2. 询问用户是否安装 faster-whisper；安装完成后转写。
3. 转写结果按时间戳分段，与镜头表对齐。
