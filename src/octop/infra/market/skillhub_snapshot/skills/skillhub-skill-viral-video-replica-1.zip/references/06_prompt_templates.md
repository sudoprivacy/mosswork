# 视频生成提示词模板

针对每个确认后的分镜，输出可直接用于生成视频的提示词包。模板按工具分类：

## 通用长文本提示词（适合 Runway / Pika / Veo / Sora 类）

```text
镜号 {no} | 时长 {duration}s
景别：{shot_size}
运镜：{camera_move}
画面主体：{subject}
动作/变化：{motion}
光线/氛围：{lighting}
镜头情绪：{mood}
台词：{dialogue}    ← 该镜对应的口播/台词/字幕原文，无台词填「（无台词）」
负向：模糊，低分辨率，畸形肢体，水印，文字，字幕条，抖动过度，色块
```

## 可灵 / 即梦 图生视频提示词

- 首帧图描述（用于文生图）：
  ```
  {subject}，{shot_size}，{lighting}，{mood}，
  正在说：{dialogue}，电影级构图，8k，超清，写实摄影风格，无字幕无水印
  ```
- 运动提示词（用于图生视频）：
  ```
  {camera_move}，{motion}，口播台词：{dialogue}，保持主体稳定，动作自然流畅
  ```

## Seedance 提示词（与已装 seedance-video-creator 技能对齐）

- Seedance 对首帧和动作描述比较敏感，提示词应：
  - 先给一段「场景+主体+景别+光线」的总述；
  - 再分点列出主体动作、镜头运动、情绪；
  - 单列「台词」要点，确保画面与对白一致；
  - 控制时长不超过 5s/镜（Seedance 更适合短镜拼合）。

示例：

```text
Scene {no}: A close-up shot of {subject} under soft natural light, cinematic depth of field.
Motion: {camera_move}; the subject {motion} smoothly.
Mood: {mood}.
Dialogue: {dialogue}    ← 该镜口播/台词原文，无台词填「（无台词）」
Avoid: blur, text, watermark, distorted hands, flicker.
```

## 输出要求

- 每个分镜必须单独成块。
- 必须包含负向提示词。
- 提示词中不允许出现原视频中的具体人物肖像、品牌 logo、版权素材。
- 每个分镜必须将台词（{dialogue}，取自阶段三新分镜脚本的「台词」列）同步写入提示词；无台词的分镜标注「（无台词）」。
- 如使用可灵/即梦，还需补充「首帧生成提示词」供用户先去文生图。
