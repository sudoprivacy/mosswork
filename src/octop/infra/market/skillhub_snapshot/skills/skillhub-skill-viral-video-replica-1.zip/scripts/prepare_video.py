#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
爆款视频复刻 - 视频入口统一化：把「链接 或 本地文件」统一成一个本地视频绝对路径。

本地文件：只做存在性与可读性校验，零成本直通。
链接：用 yt-dlp 下载（B站/YouTube/小红书成功率高；抖音需分享链接且可能失败）。
     yt-dlp 未安装时，用 --install 装进隔离 venv，绝不污染用户全局环境。

用法:
  python prepare_video.py <url|path> [--out DIR] [--install] [--cookies-from-browser chrome]

stdout 输出 === REPLICA_SOURCE_START/END === 之间的 JSON。
退出码: 0 成功 / 2 本地文件不存在 / 6 缺 yt-dlp / 7 下载失败
"""

import argparse
import glob
import json
import os
import re
import shutil
import subprocess
import sys

MARK_START = "=== REPLICA_SOURCE_START ==="
MARK_END = "=== REPLICA_SOURCE_END ==="

VENV_DIR = os.path.expanduser(r"~/.workbuddy/binaries/python/envs/default")
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi", ".flv", ".ts"}
# 视频号无公开可下载地址，任何工具都拿不到，直接引导本地上传
UNSUPPORTED_HINT = {
    "channels.weixin.qq.com": "微信视频号",
    "weixin.qq.com": "微信内容页",
    "finder.video.qq.com": "微信视频号",
}


def log(msg):
    print(msg, file=sys.stderr, flush=True)


def venv_python():
    p = os.path.join(VENV_DIR, "Scripts" if os.name == "nt" else "bin",
                     "python.exe" if os.name == "nt" else "python")
    return p if os.path.exists(p) else None


def resolve_ytdlp():
    """按 独立可执行 → 隔离 venv → 当前解释器模块 顺序探测 yt-dlp 调用方式。"""
    exe = shutil.which("yt-dlp")
    if exe:
        return [exe]
    vp = venv_python()
    if vp:
        rc = subprocess.run([vp, "-m", "yt_dlp", "--version"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode
        if rc == 0:
            return [vp, "-m", "yt_dlp"]
    rc = subprocess.run([sys.executable, "-m", "yt_dlp", "--version"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode
    if rc == 0:
        return [sys.executable, "-m", "yt_dlp"]
    return None


def install_ytdlp():
    """装进隔离 venv（不存在则先建），走国内镜像避免超时。"""
    vp = venv_python()
    if not vp:
        log("创建隔离 venv: " + VENV_DIR)
        os.makedirs(os.path.dirname(VENV_DIR), exist_ok=True)
        rc = subprocess.run([sys.executable, "-m", "venv", VENV_DIR]).returncode
        if rc != 0:
            log("venv 创建失败")
            return None
        vp = venv_python()
    if not vp:
        return None
    for index in ["https://pypi.tuna.tsinghua.edu.cn/simple",
                  "https://mirrors.aliyun.com/pypi/simple",
                  None]:
        cmd = [vp, "-m", "pip", "install", "-U", "yt-dlp"]
        if index:
            cmd += ["-i", index]
        log("安装 yt-dlp: " + " ".join(cmd[-2:]))
        if subprocess.run(cmd).returncode == 0:
            return resolve_ytdlp()
    return None


def download(runner, url, outdir, cookies_browser=None):
    os.makedirs(outdir, exist_ok=True)
    tmpl = os.path.join(outdir, "source.%(ext)s")
    cmd = runner + [
        "--no-playlist", "--no-warnings", "--no-part",
        "-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b",
        "--merge-output-format", "mp4",
        "-o", tmpl,
        "--print", "after_move:%(title)s\t%(uploader)s\t%(duration)s\t%(webpage_url)s",
        url,
    ]
    if cookies_browser:
        cmd += ["--cookies-from-browser", cookies_browser]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=1800)
    out = proc.stdout.decode("utf-8", errors="replace").strip()
    err = proc.stderr.decode("utf-8", errors="replace").strip()

    files = [f for f in glob.glob(os.path.join(outdir, "source.*"))
             if os.path.splitext(f)[1].lower() in VIDEO_EXT]
    if proc.returncode != 0 or not files:
        log("yt-dlp 下载失败:\n" + (err[-1200:] or out[-600:]))
        return None, {}
    info = {}
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) >= 4:
            info = {"title": parts[0], "uploader": parts[1],
                    "duration": parts[2], "webpage_url": parts[3]}
    return os.path.abspath(max(files, key=os.path.getsize)), info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="视频链接或本地视频文件路径")
    ap.add_argument("--out", default=None, help="下载目录，默认 ~/Downloads/爆款复刻素材")
    ap.add_argument("--install", action="store_true", help="缺 yt-dlp 时自动装进隔离 venv")
    ap.add_argument("--cookies-from-browser", default=None,
                    help="需登录的站点用浏览器 cookie，如 chrome / edge")
    args = ap.parse_args()

    target = args.target.strip().strip('"').strip("'")
    is_url = bool(re.match(r"^https?://", target, re.I))

    # —— 本地文件路径 ——
    if not is_url:
        path = os.path.abspath(os.path.expanduser(target))
        if not os.path.isfile(path):
            log("本地文件不存在: " + path)
            sys.exit(2)
        if os.path.splitext(path)[1].lower() not in VIDEO_EXT:
            log("警告: 扩展名 %s 不在常见视频格式内，仍继续尝试" % os.path.splitext(path)[1])
        result = {"source_type": "local", "video_path": path,
                  "size_mb": round(os.path.getsize(path) / 1048576, 2)}
        print(MARK_START)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(MARK_END)
        return

    # —— 链接 ——
    for host, name in UNSUPPORTED_HINT.items():
        if host in target.lower():
            log("%s 链接无公开可下载地址，任何下载工具都无法获取。"
                "请在手机/电脑客户端保存视频到本地后，把文件拖进对话或提供绝对路径。" % name)
            sys.exit(7)

    runner = resolve_ytdlp()
    if not runner and args.install:
        runner = install_ytdlp()
    if not runner:
        log("未检测到 yt-dlp。加 --install 自动安装到隔离 venv，"
            "或手动下载视频后改用本地文件路径。")
        sys.exit(6)

    outdir = args.out or os.path.join(os.path.expanduser("~"), "Downloads", "爆款复刻素材")
    path, info = download(runner, target, outdir, args.cookies_from_browser)
    if not path:
        log("下载未成功。抖音/小红书等站点常有风控，最稳的办法："
            "用客户端「保存到相册/本地」后把视频文件提供为本地路径。")
        sys.exit(7)

    result = {"source_type": "url", "video_path": path, "origin_url": target,
              "size_mb": round(os.path.getsize(path) / 1048576, 2)}
    result.update(info)
    print(MARK_START)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(MARK_END)


if __name__ == "__main__":
    main()
