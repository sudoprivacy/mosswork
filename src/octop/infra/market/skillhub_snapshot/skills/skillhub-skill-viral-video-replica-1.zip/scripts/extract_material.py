#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
爆款视频复刻 - 本地素材提取器（纯本地，仅依赖 ffmpeg/ffprobe + 标准库）

产出四类素材，供 agent 反推分镜脚本与文案：
  1. metadata   —— 时长/分辨率/帧率/编码/有无音轨
  2. shots      —— 镜头切分（scene detect），每镜含 起止秒/时长/代表帧路径 → 直接对应分镜表的「镜号|时长」
  3. sub_tiles  —— 字幕条拼图（密集采样底部字幕带并纵向堆叠），一张图读几十条字幕 → 还原完整文案
  4. audio      —— 可选导出 16k 单声道 wav，供 ASR 兜底

用法:
  python extract_material.py <video> [--out DIR] [--scene-threshold 0.3]
        [--max-shots 40] [--max-frame-edge 1280] [--sub-top 0.70] [--sub-bottom 0.98]
        [--sub-interval 0.8] [--tile-rows 12] [--no-subs] [--audio]

stdout 输出 === REPLICA_MANIFEST_START/END === 之间的 JSON。
退出码: 0 成功 / 2 视频不存在 / 8 缺 ffmpeg / 11 超出体积或时长上限
"""

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time

MARK_START = "=== REPLICA_MANIFEST_START ==="
MARK_END = "=== REPLICA_MANIFEST_END ==="

# Windows 上 ffmpeg 常见安装位置（winget / choco），PATH 里找不到时兜底扫描
WIN_FFMPEG_HINTS = [
    r"C:\Users\{user}\AppData\Local\Microsoft\WinGet\Packages",
    r"C:\ProgramData\chocolatey\bin",
    r"C:\ffmpeg\bin",
]


def log(msg):
    print(msg, file=sys.stderr, flush=True)


def find_tool(name):
    """在 PATH 与常见安装目录中定位 ffmpeg/ffprobe。"""
    p = shutil.which(name)
    if p:
        return p
    exe = name + (".exe" if os.name == "nt" else "")
    for hint in WIN_FFMPEG_HINTS:
        base = hint.replace("{user}", os.environ.get("USERNAME", ""))
        if not os.path.isdir(base):
            continue
        for root, _dirs, files in os.walk(base):
            if exe in files:
                return os.path.join(root, exe)
    return None


def run(cmd, timeout=1800):
    """执行命令，返回 (returncode, stdout, stderr)。ffmpeg 的进度/showinfo 走 stderr。"""
    proc = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
    )
    dec = lambda b: b.decode("utf-8", errors="replace")
    return proc.returncode, dec(proc.stdout), dec(proc.stderr)


def probe(ffprobe, video):
    rc, out, err = run([
        ffprobe, "-v", "error", "-print_format", "json",
        "-show_format", "-show_streams", video,
    ])
    if rc != 0:
        log("ffprobe 失败: " + err.strip()[:500])
        return None
    data = json.loads(out)
    v = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in data.get("streams", []) if s.get("codec_type") == "audio"), None)
    fmt = data.get("format", {})

    def fps_of(stream):
        raw = (stream or {}).get("r_frame_rate", "0/0")
        try:
            num, den = raw.split("/")
            return round(float(num) / float(den), 3) if float(den) else 0.0
        except Exception:
            return 0.0

    duration = float(fmt.get("duration") or (v or {}).get("duration") or 0)
    return {
        "path": os.path.abspath(video),
        "filename": os.path.basename(video),
        "duration_sec": round(duration, 3),
        "width": int((v or {}).get("width") or 0),
        "height": int((v or {}).get("height") or 0),
        "fps": fps_of(v),
        "video_codec": (v or {}).get("codec_name"),
        "audio_codec": (a or {}).get("codec_name"),
        "has_audio": a is not None,
        "size_mb": round(os.path.getsize(video) / 1048576, 2),
        "bitrate_kbps": round(int(fmt.get("bit_rate", 0)) / 1000) if fmt.get("bit_rate") else None,
        "orientation": "竖屏" if int((v or {}).get("height") or 0) > int((v or {}).get("width") or 0) else "横屏",
    }


def detect_cuts(ffmpeg, video, threshold):
    """scene detect 取镜头切点秒数列表。showinfo 输出在 stderr。"""
    rc, _out, err = run([
        ffmpeg, "-hide_banner", "-nostats", "-i", video,
        "-filter:v", "select='gt(scene,%s)',showinfo" % threshold,
        "-an", "-f", "null", "-",
    ])
    cuts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", err)]
    if rc != 0 and not cuts:
        log("scene detect 异常，将回退定时切分: " + err.strip()[-400:])
    return sorted(set(cuts))


def build_shots(cuts, duration, min_shot=0.45, max_shots=40, max_shot_len=4.0):
    """
    把切点整理成镜头区间。三重保障：
      - 切点过密（<min_shot）则丢弃，避免转场闪帧被当成独立镜头；
      - 单镜过长（>max_shot_len）则内部等分插点。scene detect 对「亮度接近的切换」
        （如红→绿、同色调场景轮换）不敏感，实测会漏切点，必须补粒度否则分镜表失真；
      - 完全无切点（纯静态/单长镜）则整体定时切分。
    """
    marks = [0.0]
    for c in cuts:
        if c - marks[-1] >= min_shot and c < duration - 0.15:
            marks.append(round(c, 3))
    marks.append(round(duration, 3))
    mode = "scene" if len(marks) > 2 else "timed"

    if max_shot_len and max_shot_len > 0:
        refined = [marks[0]]
        for i in range(len(marks) - 1):
            seg = marks[i + 1] - marks[i]
            if seg > max_shot_len * 1.4:
                n = max(2, int(round(seg / max_shot_len)))
                for k in range(1, n):
                    refined.append(round(marks[i] + seg * k / n, 3))
            refined.append(marks[i + 1])
        if len(refined) > len(marks):
            mode += "+split"
        marks = refined

    # 镜头过多时按时长优先保留（丢弃最短的碎镜，与相邻合并）
    while len(marks) - 1 > max_shots:
        durs = [(marks[i + 1] - marks[i], i) for i in range(len(marks) - 1)]
        _d, idx = min(durs)
        drop = idx + 1 if idx + 1 < len(marks) - 1 else idx
        if drop <= 0 or drop >= len(marks) - 1:
            break
        marks.pop(drop)

    shots = []
    for i in range(len(marks) - 1):
        start, end = marks[i], marks[i + 1]
        shots.append({
            "no": i + 1,
            "start_sec": round(start, 3),
            "end_sec": round(end, 3),
            "duration_sec": round(end - start, 3),
            "mid_sec": round(start + (end - start) / 2, 3),
        })
    return shots, mode


def grab_frame(ffmpeg, video, ts, dst, max_edge):
    """精确抽单帧。-ss 放在 -i 前用关键帧快速定位，再用 -ss 精确校正。"""
    vf = "scale='if(gt(iw,ih),min(%d,iw),-2)':'if(gt(iw,ih),-2,min(%d,ih))'" % (max_edge, max_edge)
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
           "-ss", "%.3f" % max(ts, 0), "-i", video, "-frames:v", "1"]
    if max_edge > 0:
        cmd += ["-vf", vf]
    cmd += ["-q:v", "3", dst]
    rc, _o, err = run(cmd, timeout=180)
    if rc != 0 or not os.path.exists(dst):
        log("抽帧失败 @%.2fs: %s" % (ts, err.strip()[-200:]))
        return None
    return dst


def build_sub_tiles(ffmpeg, video, outdir, meta, top, bottom, interval, rows, tile_width=720):
    """
    密集采样字幕带并纵向堆叠成拼图。
    单条 ffmpeg: fps 采样 → crop 字幕带 → scale 统一宽 → tile 纵向堆叠。
    返回 tiles 列表，每张附带格子对应的时间戳（行优先，用于把字幕对齐到镜头）。
    """
    h = meta["height"]
    if h <= 0:
        return [], "视频高度未知，跳过字幕拼图"
    crop_h = max(int(h * (bottom - top)), 16)
    crop_y = int(h * top)
    if crop_y + crop_h > h:
        crop_h = h - crop_y

    pattern = os.path.join(outdir, "subtile_%03d.jpg")
    vf = (
        "fps=1/{iv},crop=iw:{ch}:0:{cy},scale={tw}:-2,"
        "tile=1x{rows}:padding=6:margin=6:color=white"
    ).format(iv=interval, ch=crop_h, cy=crop_y, tw=tile_width, rows=rows)

    rc, _o, err = run([
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", video,
        "-vf", vf, "-fps_mode", "passthrough", "-q:v", "3", pattern,
    ], timeout=900)

    # ffmpeg fps 滤镜的实际采样帧数：t = k/fps_out，k 从 0 起且 t < duration
    total_samples = math.ceil(meta["duration_sec"] / interval)
    tiles = []
    idx = 1
    while True:
        p = pattern % idx
        if not os.path.exists(p):
            break
        # 第 idx 张拼图自上往下第 k 格（k 从 0 起）对应采样时刻；末张不满会补白格
        base = (idx - 1) * rows
        stamps = [round((base + k) * interval, 2)
                  for k in range(rows) if base + k < total_samples]
        tiles.append({
            "idx": idx,
            "path": os.path.normpath(p),
            "grid": "1x%d" % rows,
            "valid_cells": len(stamps),
            "cell_timestamps_sec": stamps,
        })
        idx += 1

    note = None
    if rc != 0 and not tiles:
        note = "字幕拼图失败: " + err.strip()[-300:]
        log(note)
    return tiles, note


def extract_audio(ffmpeg, video, outdir):
    dst = os.path.join(outdir, "audio.wav")
    rc, _o, err = run([
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", video,
        "-vn", "-ac", "1", "-ar", "16000", dst,
    ], timeout=900)
    if rc != 0 or not os.path.exists(dst):
        log("音频导出失败: " + err.strip()[-200:])
        return None
    return dst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--out", default=None, help="素材输出目录，默认 视频同级/replica-<时间戳>")
    ap.add_argument("--scene-threshold", type=float, default=0.3)
    ap.add_argument("--max-shots", type=int, default=40)
    ap.add_argument("--max-shot-len", type=float, default=4.0,
                    help="单镜超过该秒数则内部等分补点，防止漏切点导致分镜粒度不足；0 关闭")
    ap.add_argument("--max-frame-edge", type=int, default=1280)
    ap.add_argument("--sub-top", type=float, default=0.70, help="字幕带上边界（画面高度比例）")
    ap.add_argument("--sub-bottom", type=float, default=0.98)
    ap.add_argument("--sub-interval", type=float, default=0.8, help="字幕采样间隔秒")
    ap.add_argument("--tile-rows", type=int, default=12, help="每张拼图堆叠几条字幕")
    ap.add_argument("--no-subs", action="store_true")
    ap.add_argument("--audio", action="store_true", help="额外导出 16k wav 供 ASR")
    ap.add_argument("--max-size-mb", type=float, default=800)
    ap.add_argument("--max-duration-sec", type=float, default=900)
    args = ap.parse_args()

    video = os.path.abspath(args.video)
    if not os.path.isfile(video):
        log("视频文件不存在: " + video)
        sys.exit(2)

    ffmpeg, ffprobe = find_tool("ffmpeg"), find_tool("ffprobe")
    if not ffmpeg or not ffprobe:
        log("缺少 ffmpeg/ffprobe。Windows 安装: winget install Gyan.FFmpeg / mac: brew install ffmpeg / linux: apt install ffmpeg")
        sys.exit(8)

    meta = probe(ffprobe, video)
    if not meta:
        sys.exit(2)
    if args.max_size_mb and meta["size_mb"] > args.max_size_mb:
        log("文件 %.1fMB 超过上限 %.0fMB，请压缩或裁剪关键片段" % (meta["size_mb"], args.max_size_mb))
        sys.exit(11)
    if args.max_duration_sec and meta["duration_sec"] > args.max_duration_sec:
        log("时长 %.0fs 超过上限 %.0fs，请裁剪关键片段" % (meta["duration_sec"], args.max_duration_sec))
        sys.exit(11)

    outdir = args.out or os.path.join(
        os.path.dirname(video), "replica-" + time.strftime("%Y%m%d-%H%M%S"))
    frames_dir = os.path.join(outdir, "frames")
    subs_dir = os.path.join(outdir, "subs")
    os.makedirs(frames_dir, exist_ok=True)
    if not args.no_subs:
        os.makedirs(subs_dir, exist_ok=True)

    # 1. 镜头切分
    cuts = detect_cuts(ffmpeg, video, args.scene_threshold)
    shots, shots_mode = build_shots(cuts, meta["duration_sec"],
                                    max_shots=args.max_shots,
                                    max_shot_len=args.max_shot_len)

    # 2. 每镜代表帧（取镜头中点，避开转场脏帧）
    for s in shots:
        dst = os.path.normpath(os.path.join(frames_dir, "shot_%03d.jpg" % s["no"]))
        s["frame"] = grab_frame(ffmpeg, video, s["mid_sec"], dst, args.max_frame_edge)
    # 首帧单独留一张，用于封面/开场钩子分析
    cover = grab_frame(ffmpeg, video, min(0.1, meta["duration_sec"] / 2),
                       os.path.normpath(os.path.join(outdir, "cover.jpg")), args.max_frame_edge)

    # 3. 字幕条拼图
    tiles, sub_note = ([], None)
    if not args.no_subs:
        tiles, sub_note = build_sub_tiles(
            ffmpeg, video, subs_dir, meta,
            args.sub_top, args.sub_bottom, args.sub_interval, args.tile_rows)

    # 4. 音频（可选）
    audio = extract_audio(ffmpeg, video, outdir) if args.audio else None

    manifest = {
        "metadata": meta,
        "cover": cover,
        "shots": shots,
        "shots_count": len(shots),
        "shots_mode": shots_mode,
        "scene_cuts_sec": cuts,
        "sub_tiles": tiles,
        "sub_tile_note": sub_note,
        "sub_band": {"top_ratio": args.sub_top, "bottom_ratio": args.sub_bottom,
                     "interval_sec": args.sub_interval, "rows_per_tile": args.tile_rows},
        "audio": audio,
        "out_dir": outdir,
    }
    with open(os.path.join(outdir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print("REPLICA_OUT_DIR=" + outdir)
    print(MARK_START)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(MARK_END)


if __name__ == "__main__":
    main()
