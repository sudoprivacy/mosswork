#!/usr/bin/env python3
"""三源融合买卖锚点计算模块（公共）

供 daily_order_plan.py / price_alerts.py 共用。
规则来源: SKILL a-share-reverse-t-and-automation > 三源融合做T买卖价锚定规则
   反T卖出价 = 现价上方最近压力（MA5/MA10、Fib38.2%、筹码90%上沿、前高，取最低阻力）
   反T接回价 = Fib61.8% 与 今日低点/前低 重叠区间的中间价（筹码下沿接近时纳入）
用户习惯（2026-08-27确认）: 卖出、买入取三源融合区间的中间价挂单，确保能成交。
"""
import os
import sys
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import t_signal_threesource as ts


def three_source_anchors(symbol, quote, bars, chip_cache=None):
    """计算三源融合买卖锚点。

    参数:
        symbol: 如 'sz001389'
        quote: 行情 dict（含 current/high/low）
        bars: 日K列表（fetch_kline 返回，**已剔除当日**，只用截至昨日的完整K线）
        chip_cache: 筹码缓存 dict（可选）

    返回:
        {
          'sell_mid': 卖出挂单价（反T高抛，现价上方最近压力）,
          'sell_range': (低, 高) 卖出锚点区间,
          'buy_mid': 买入挂单价（反T接回，支撑重叠区中间）,
          'buy_range': (低, 高) 买入锚点区间,
          'sell_src': 卖出锚点来源描述,
          'buy_src': 买入锚点来源描述,
          'trend': 'bullish'/'bearish'/'neutral',
          'trend_label': 中文趋势标签,
        }

    ⚠️ 稳定性保证（2026-08-27 用户质疑后修复）:
      - K线只用到昨日收盘：MA/Fib/波段锚点盘中不漂移，9:50跑和收盘后跑结果一致
      - 今日实时 high/low 仅作"当日可成交"修正（卖出不超过今日高，买入不低于今日低）
    """
    if chip_cache is None:
        chip_cache = ts.load_chip_cache()

    closes = [b["close"] for b in bars]
    ma5 = ts.calc_ma(closes, 5)
    ma10 = ts.calc_ma(closes, 10)
    ma30 = ts.calc_ma(closes, 30)

    cur = quote["current"]
    if not cur or cur <= 0:
        return None

    trend = ts.determine_trend(ma5, ma10, ma30, cur)
    trend_label = {"bullish": "多头↑", "bearish": "空头↓", "neutral": "震荡→"}.get(trend, "震荡→")

    # 波段 + 斐波那契
    sw_hi, sw_lo = ts.find_recent_swing(bars, 25)
    short_hi, short_lo = ts.find_recent_swing(bars, 12)
    fibs = ts.calc_fib_levels(sw_hi, sw_lo)
    sfibs = ts.calc_fib_levels(short_hi, short_lo)

    # 筹码
    chip = chip_cache.get(symbol, {})
    chip_low = chip.get("cost90_low")
    chip_high = chip.get("cost90_high")

    # ── 卖出锚点：现价上方的压力位，取最低（最容易触达）──
    # ⚠️ 必须严格高于现价(v > cur)，否则挂单价低于现价=立即成交=卖飞(2026-08-27修复)
    sell_cands = []
    sell_src = []
    for v, label in [
        (ma10, "MA10"),
        (ma5, "MA5"),
        (sfibs["0.382"], "Fib38.2%"),
        (fibs["0.382"], "Fib38.2%(长)"),
        (sw_hi, "前高"),
        (chip_high, "筹码上沿"),
    ]:
        if v and v > cur:
            sell_cands.append(round(v, 2))
            sell_src.append(f"{label}{v:.2f}")
    # 去重排序
    uniq = sorted(set(sell_cands))
    sell_src = sorted(set(sell_src))
    if uniq:
        sell_mid = uniq[0]
        sell_range = (uniq[0], uniq[1] if len(uniq) >= 2 else uniq[0])
    else:
        sell_mid = round(cur * 1.01, 2)
        sell_range = (sell_mid, sell_mid)
        sell_src = ["现价+1%兜底"]

    # ── 买入锚点：支撑位重叠区（Fib61.8 / 今日低点 / 前低 / 筹码下沿）──
    # 规则: 接回价 = Fib位与筹码位重叠区间，取中间价挂单；重叠不到就用 Fib61.8 与今日低点之间
    # ⚠️ 必须严格低于现价(v < cur)，否则挂单价高于现价=立即成交=追高(2026-08-27修复)
    buy_cands = []
    buy_src = []
    for v, label in [
        (sfibs["0.618"], "Fib61.8%"),
        (fibs["0.618"], "Fib61.8%(长)"),
        (short_lo, "短波段低"),
        (sw_lo, "波段低"),
        (quote.get("low"), "今日低"),
        (chip_low, "筹码下沿"),
    ]:
        if v and v < cur:
            buy_cands.append(round(v, 2))
            buy_src.append(f"{label}{v:.2f}")
    uniq_b = sorted(set(buy_cands))
    buy_src = sorted(set(buy_src))
    if uniq_b:
        if len(uniq_b) >= 2:
            # 取最贴近现价的两个支撑（排序后最后两个）的中间价（重叠区中间）
            buy_mid = round((uniq_b[-1] + uniq_b[-2]) / 2, 2)
            buy_range = (uniq_b[-2], uniq_b[-1])
        else:
            buy_mid = uniq_b[0]
            buy_range = (uniq_b[0], uniq_b[0])
    else:
        buy_mid = round(cur * 0.99, 2)
        buy_range = (buy_mid, buy_mid)
        buy_src = ["现价-1%兜底"]

    # ── 涨跌停硬边界（2026-09-09 播恩幽灵单教训后新增，优先于高低修正）──
    # 暴涨/暴跌股的均线筹码全在极值外侧时，加权锚点会外推过板（预测接13.03但跌停14.74=幽灵单）
    # 用昨收×涨跌停%算板边：接回价永不 < 跌停价，卖出价永不 > 涨停价
    prev_close = quote.get("prev_close") or quote.get("prev") or quote.get("昨收") or 0
    if prev_close > 0:
        code = str(quote.get("_code") or quote.get("code") or symbol)
        limit_pct = 0.20 if (code.startswith("30") or code.startswith("68")) else 0.10
        limit_down = round(prev_close * (1 - limit_pct), 2)
        limit_up = round(prev_close * (1 + limit_pct), 2)
        if buy_mid < limit_down:
            buy_mid = limit_down
            buy_range = (buy_mid, buy_mid)
            buy_src = [f"跌停{limit_down:.2f}硬边界(原{','.join(buy_src)})"]
        if sell_mid > limit_up:
            sell_mid = limit_up
            sell_range = (sell_mid, sell_mid)
            sell_src = [f"涨停{limit_up:.2f}硬边界(原{','.join(sell_src)})"]

    # ── 当日可成交修正（2026-08-27 用户质疑后加入）──
    # 接回价若低于今日低点 → 今天到不了，挂单作废。修正为今日低点附近（低×1.003）
    # ⚠️ clamp: 修正后仍必须 卖>现价、买<现价，否则立即成交=卖飞/追高（8/27二次修复）
    today_low = quote.get("low") or 0
    if today_low > 0 and buy_mid < today_low:
        buy_mid = round(today_low * 1.003, 2)
        buy_range = (buy_mid, buy_mid)
        buy_src = [f"今日低{today_low:.2f}修正(原{','.join(buy_src)})"]
    if buy_mid >= cur:
        buy_mid = round(cur * 0.999, 2)
        buy_range = (buy_mid, buy_mid)
        buy_src = [f"现价下方clamp(原{','.join(buy_src)})"]
    # 卖出价若高于今日高点 → 今天到不了，同样修正为今日高点附近（高×0.997）
    today_high = quote.get("high") or 0
    if today_high > 0 and sell_mid > today_high:
        sell_mid = round(today_high * 0.997, 2)
        sell_range = (sell_mid, sell_mid)
        sell_src = [f"今日高{today_high:.2f}修正(原{','.join(sell_src)})"]
    if sell_mid <= cur:
        sell_mid = round(cur * 1.001, 2)
        sell_range = (sell_mid, sell_mid)
        sell_src = [f"现价上方clamp(原{','.join(sell_src)})"]

    return {
        "sell_mid": sell_mid,
        "sell_range": sell_range,
        "buy_mid": buy_mid,
        "buy_range": buy_range,
        "sell_src": ",".join(sell_src),
        "buy_src": ",".join(buy_src),
        "trend": trend,
        "trend_label": trend_label,
        "ma5": round(ma5, 2) if ma5 else None,
        "ma10": round(ma10, 2) if ma10 else None,
        "ma30": round(ma30, 2) if ma30 else None,
    }


def get_anchor_for(symbol, quote=None):
    """便捷入口：给定 symbol（如 'sz001389'），自动拉行情+K线，返回三源融合锚点。
    行情拉取失败时返回 None。
    quote 支持两种字段命名：三源模块标准 'current'，或腾讯接口 'price'。

    K线只取到昨日（剔除今日）：保证 9:50 盘中和收盘后算出同样的稳定锚点。
    """
    if quote is not None and 'current' not in quote and 'price' in quote:
        # 腾讯字段 → 三源标准字段
        quote = dict(quote)
        quote['current'] = quote.get('price', 0)
    if quote is None or not quote.get('current'):
        quotes = ts.fetch_quotes({symbol: symbol})
        quote = quotes.get(symbol)
        if not quote:
            return None
    bars = ts.fetch_kline(symbol, 60)
    if len(bars) < 10:
        return None
    # 剔除当日K线：最后一根 day == 今天 → 丢弃，只用昨日及之前
    today = datetime.date.today().strftime("%Y-%m-%d")
    if bars and bars[-1]["day"] >= today:
        bars = bars[:-1]
    if len(bars) < 10:
        return None
    return three_source_anchors(symbol, quote, bars)


if __name__ == "__main__":
    # 测试
    for sym in ["sz001389", "sz301589", "sz000987"]:
        anchors = get_anchor_for(sym)
        if anchors:
            print(f"{sym} 趋势{anchors['trend_label']}")
            print(f"  卖出: {anchors['sell_mid']} (区间{anchors['sell_range'][0]}~{anchors['sell_range'][1]}) [{anchors['sell_src']}]")
            print(f"  买入: {anchors['buy_mid']} (区间{anchors['buy_range'][0]}~{anchors['buy_range'][1]}) [{anchors['buy_src']}]")
