## Description: <br>
Helps an agent animate a still image using the motion, timing, and camera movement from a reference video. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative operators use this skill to prepare Pruna P-API requests that animate a reference image with motion from a source video, including asset upload, prediction creation, polling, and quality review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill uploads user images and videos to Pruna for paid generation. <br>
Mitigation: Confirm the user has rights or consent for the media before upload, verify PRUNA_API_KEY is configured securely, and make the paid API call only after the user confirms inputs. <br>
Risk: The skill exposes disable_safety_checker for human media generation. <br>
Mitigation: Keep disable_safety_checker off by default and use it only with a clear, policy-compliant reason. <br>
Risk: Poorly matched source video and reference image can create motion-transfer artifacts or misleading output. <br>
Mitigation: Apply the documented input gate and quality checklist, including first-frame alignment, visible body parts, proportion fit, and post-generation visual review. <br>


## Reference(s): <br>
- [Pruna p-video-animate model docs](https://docs.api.pruna.ai/guides/models/p-video-animate) <br>
- [Replicate prunaai/p-video-animate](https://replicate.com/prunaai/p-video-animate) <br>
- [Runware animating images from video guide](https://runware.ai/docs/models/prunaai-p-video-animate/guides/animating-images-from-video) <br>
- [Pruna API guide](references/pruna-api.md) <br>
- [API credentials](references/api-credentials.md) <br>
- [p-video-animate quality checklist](references/p-video-animate-quality-checklist.md) <br>
- [Generation diversity](references/generation-diversity.md) <br>
- [Generation quality checklist hub](references/generation-quality-checklists.md) <br>
- [Random seed ritual](references/random-seed-ritual.md) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Shell commands, Configuration, API calls] <br>
**Output Format:** [Markdown guidance with bash and JSON examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires PRUNA_API_KEY and produces instructions for Pruna file upload, prediction creation, polling, download, and visual quality review.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
