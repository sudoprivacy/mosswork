# WeChat Public Account Layout Style Guide

## Goal

Define a reusable WeChat public account layout standard for a minimalist, premium visual style that can be published reliably through Wenyan and the WeChat publishing workflow.

The target is a WeChat article draft that remains clean, readable, and brand-consistent after Wenyan rendering and WeChat upload.

## Design Positioning

The visual tone is:

- Minimal
- Premium
- Calm
- Clear
- Editorial rather than decorative

The article should feel trustworthy, clean, thoughtful, easy to continue reading, and not noisy.

Avoid:

- Over-designed title cards inside the body
- Frequent colored boxes
- Heavy poster-like section headers
- Dense multi-column thinking inherited from web layouts
- Repetitive template transitions that make the article feel machine-generated
- Visual clutter created by too many dividers, stickers, icons, or badges

## Applicability

This layout standard is suitable for:

- Hot-topic analysis articles
- Commentary pieces
- Industry observation articles
- Brand-value or trend pieces
- Profile and story-driven long-form pieces

It is less suitable for:

- Strongly playful or youth-oriented meme content
- Highly commercial sales pages
- Articles that depend on complex tables or long data dashboards

## Visual System

Use a restrained neutral palette with one warm accent:

- Primary text: `#1F1F1F`
- Secondary text: `#6B6B6B`
- Soft background: `#F5F3EF`
- Accent color: `#8C6A43`
- Divider color: `#D9D3CA`

Rules:

- Most of the article should remain black, gray, and white or off-white
- Use the accent color sparingly
- Do not rotate multiple highlight colors inside one article
- Do not use bright red, purple gradients, neon blue, or highly saturated green as base style colors

Because WeChat typography control is limited, rely on hierarchy rather than custom fonts:

- Keep the main title short and direct
- Make subtitle or lead text shorter than the title block suggests
- Keep body paragraphs compact
- Make captions visually weaker than body text
- Use section headings to create rhythm, not visual noise

Image style should be documentary when the topic is news-based, clean and cinematic when the topic is commentary or feature writing, and consistent within one article.

Avoid random stock photos, collage-heavy body layouts, and low-quality screenshots unless the screenshot is necessary evidence.

## Layout Components

### Cover

Each article should have one cover image.

Cover requirements:

- High clarity
- Single visual focus
- No overloaded text
- Strong atmosphere without busy composition

Prefer letting the platform cover carry the first visual impression. Do not repeat the same large title card inside the body unless there is a strong editorial reason.

### Title Area

The article opening should include one main title and an optional one-line subtitle or lead.

Rules:

- The title should not rely on exaggerated punctuation
- Avoid long dual-clause headlines unless the content genuinely needs them
- The subtitle should frame the article, not repeat the title

### Lead Paragraph

The lead should be 2 to 3 short paragraphs at most.

It should establish the topic, clarify the stakes, and set the tone.

Rules:

- No empty scene-setting
- No inflated opening claims
- No mechanical repeated "recently" framing

### Section Headings

Use section headings every 3 to 5 paragraphs, depending on density.

Section headings should control reading rhythm, signal transitions, and give the article a visible backbone.

Rules:

- Keep headings concise
- Prefer statement-like headings over slogan-like headings
- Avoid making every heading the same length and cadence

### Body Paragraphs

Body paragraphs are the core of the style.

Rules:

- Prefer short to medium paragraph length
- Most paragraphs should stay within 2 to 4 lines in mobile reading conditions
- Split paragraphs when the logic changes
- Keep argument flow clean
- Let one paragraph carry one main move
- Do not stack multiple rhetorical turns in one paragraph

Language rules tied to layout:

- Avoid repeated opening connectors across adjacent paragraphs
- Avoid the Chinese "not this, but that" contrast template
- Avoid generic filler phrases and inflated wrap-up sentences

### Quote Or Emphasis Blocks

Use quote blocks sparingly, usually 1 to 3 times per article.

Suitable content:

- A sharp judgment
- A key fact
- A memorable line
- A transition sentence that deserves isolation

Rules:

- Keep the block short
- Do not style every important sentence as a quote block
- Use it to create breathing space, not visual overload

### Data Blocks

Use lightweight data modules only when the data is central.

Rules:

- Limit to the most useful 1 to 3 figures
- Prefer short bullet presentation over large tables
- If a table is necessary, simplify it aggressively before publication

### Dividers

Divider usage should be restrained.

Recommended forms:

- Thin horizontal line
- Small centered symbol
- Whitespace-only transition

Rules:

- One article should not rely on many divider styles
- If section headings are already clear, divider usage should decrease

### Body Images

Use images as rhythm control, not decoration.

Recommended density:

- One image every 800 to 1200 Chinese characters

Rules:

- Keep each image relevant to the immediately surrounding section
- Add short captions when attribution or context matters
- Do not insert multiple images back-to-back without a reading reason

### Ending

The ending should close quietly and clearly.

Rules:

- Summarize the core point
- Optionally leave one forward-looking observation
- Do not shout
- Do not use empty elevation language
- Do not force a grand closing if the article works better with restraint

## WeChat And Wenyan Constraints

Assume:

- WeChat does not behave like a free web page
- Font control is limited
- Complex layout control is limited
- Advanced interactive behavior does not exist
- Visual consistency comes from structure, spacing, images, and restraint

Reliable:

- Cover image
- Title hierarchy
- Section headings
- Body paragraph rhythm
- Quote blocks
- Images with captions
- Simple dividers
- Consistent Markdown structure
- Stable theme choice in Wenyan

Unreliable or not recommended:

- Multi-column layouts
- Precise overlay positioning
- Heavy custom CSS assumptions
- Dense card systems
- Complex infographic-like compositions inside the article body

## Recommended Wenyan Strategy

Use a restrained base theme such as `lapis`, and avoid frequent theme switching. Visual consistency matters more than novelty.

The publishing workflow should use:

- Wenyan-compatible Markdown
- One stable cover path
- Localized images when possible
- One consistent theme rather than per-article styling experiments

## Standard Article Structure

Recommended structure:

1. Cover
2. Title
3. Short lead
4. Main section 1
5. Main section 2
6. Main section 3
7. Optional quote or data block
8. Closing
9. Sources or references when needed

Adapt this structure to topic complexity, but do not replace it with overly fragmented layouts.

## Production Checklist

Before publication, confirm:

- The article matches the minimalist premium tone
- The accent color is restrained
- The cover is clean and high quality
- Section headings are concise and not repetitive
- Paragraphs are not too long
- Quote blocks are used selectively
- Image density is controlled
- No empty grandstanding language remains in the text
- No repeated sentence templates dominate the article
- Markdown structure is Wenyan-compatible

## Final Principle

The standard should make each article feel like it belongs to the same publication, even when the topics change.

Minimalist premium style is not created by adding design. It is created by removing noise, tightening hierarchy, and keeping every visible choice under control.
