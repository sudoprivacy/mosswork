---
name: skillhub-skill-wechat-hot-article-publisher
description: "Use when the user asks to write, assemble, publish, or push a WeChat public account article, especially when they mention WeChat article, public account, draft box, hot topics, hot search, wenyan, topic shortlist, or image matching, or want a complete workflow from topic discovery through final publication. Also use when the user wants the same article-publishing workflow reused across conversatio"
---

# WeChat Hot Article Publisher

## Overview

Use this skill when the user wants a full WeChat public account article workflow, not just a draft.

The workflow always includes:

1. Run the publishing preflight when the request includes draft-box publication
2. Search current hot topics from Baidu and Toutiao
3. Present 10 topic options first
4. Wait for the user to choose one topic
5. Research the chosen topic with current sources
6. Write a structured first draft
7. Run a separate humanizer refinement pass on the draft
8. Choose 3 to 5 highly relevant sourced news photos when available, or use clearly labeled explanatory body visuals when source pages have no usable images
9. Apply the house WeChat layout style to the finished article and selected images
10. Format the article as Wenyan-compatible Markdown
11. Publish to the WeChat draft box with `wenyan`

Do not skip the humanizer pass. Do not skip the 10-topic selection step unless the user explicitly gives a final topic and says to proceed directly.

## When To Use

Use this skill when the user says or implies any of these:

- "Write a WeChat public account article"
- "Publish this to the WeChat draft box"
- "Research hot topics first, then write"
- "Match images and publish it"
- "Use wenyan to publish"
- "Use the same WeChat workflow as before"

Do not use this skill for:

- Generic blog posts with no WeChat publishing request
- Pure copy editing with no topic research or publication step
- WeChat replies, chat messages, or customer-service copy

## Recipient Setup

Before publishing to a real WeChat draft box, the recipient environment must have:

- Web access for current hot-topic research and source verification
- A working Wenyan CLI, available either as `wenyan` on `PATH` or as a project-local executable
- WeChat draft-publication credentials configured for Wenyan
- A writable working folder for article Markdown and localized image files
- The current machine IP allowed by the WeChat Official Account platform, or a configured Wenyan server/proxy path

If any publishing prerequisite is missing, try to resolve the local tooling gap when the environment allows it, then continue the research, draft, humanizer, image, and layout phases. Report the exact missing publishing setup as a concrete blocker instead of pretending publication succeeded.

## Mandatory Publishing Preflight

Run this preflight before doing long article work whenever the user asks to publish to the WeChat draft box. Do not wait until the end to discover that publishing cannot run.

### 1. Check Wenyan

Find a usable Wenyan command in this order:

1. `wenyan` on `PATH`
2. A project-local executable such as `./node_modules/.bin/wenyan` or `.\node_modules\.bin\wenyan.cmd`
3. An ephemeral runner such as `npx -y @wenyan-md/cli`

Verify the command with:

```bash
wenyan --help
wenyan publish --help
wenyan credential --help
```

If no Wenyan command is available, install or guide setup:

- If package installation is allowed and appropriate for the current project, install `@wenyan-md/cli` locally or globally.
- If installation is not allowed, tell the user to install it, for example with `npm install -g @wenyan-md/cli`, then stop before the publication step.

Do not assume this skill author's `node_modules` exists on the recipient machine.

### 2. Check Credentials Without Exposing Secrets

Wenyan can publish with either:

- Environment variables: `WECHAT_APP_ID` and `WECHAT_APP_SECRET`
- An env file passed with `--env-file .env`
- Wenyan's credential store configured through `wenyan credential --set`

Check for credentials without printing secrets:

1. Confirm whether `WECHAT_APP_ID` and `WECHAT_APP_SECRET` are present in the environment.
2. If an env file is expected, confirm the file exists and contains both keys, but do not echo values.
3. Otherwise run `wenyan credential --location` and check whether the credential file exists and appears configured, but do not print the file contents.

If credentials are missing, tell the user exactly what is needed:

```env
WECHAT_APP_ID=your_wechat_official_account_app_id
WECHAT_APP_SECRET=your_wechat_official_account_app_secret
```

Then suggest one of these setup paths:

- Create a local `.env` file and publish with `--env-file .env`
- Run `wenyan credential --set` and enter the AppID/AppSecret interactively
- Use a configured Wenyan server with `--server` and `--api-key`

Never write credentials into the skill package. Never print `WECHAT_APP_SECRET` in the response or logs.

### 3. Check WeChat API Reachability Constraints

Before promising publication, remind the user that the machine or server calling the WeChat API must satisfy the WeChat Official Account IP whitelist requirement. If the local IP is not stable or not whitelisted, use Wenyan server mode or a proxy path instead of repeatedly retrying local publication.

### 4. Preflight Outcome

After preflight, state one of these outcomes:

- `ready_to_publish`: Wenyan, credentials, writable workspace, and likely API path are available.
- `can_prepare_only`: Writing, images, layout, and Markdown can be completed, but publication is blocked by missing Wenyan, missing credentials, or IP/API setup.

Only attempt the final `wenyan publish` command when the outcome is `ready_to_publish`.

## Fixed Workflow

### 1. Hot topic discovery

Always browse the web for up-to-date topics. Use current Baidu hot search and Toutiao hot topics or reliable hot-topic aggregators that reflect them.

Your output to the user at this stage is always 10 topic options.

For each option, include:

- Topic name
- Why it is hot
- Suitable article angle
- Whether it is steady, risky, light, or strong for WeChat publishing

Do not start writing the article before the user picks a topic, unless the user explicitly overrides this rule.

### 2. Source verification

After the user selects a topic, verify the core facts with current primary or high-credibility sources.

Prefer:

- Official releases
- Major mainstream reporting
- Original interviews, speeches, reports, or data pages

Always confirm dates and the actual event context before writing. If a quote or stat is central to the article, verify it first.

### 3. Drafting

Write a full first draft before polishing. The first draft should already have a clean WeChat structure:

- Strong title
- Hooked opening
- Clear subheads
- Main analysis
- Closing section
- Source list

The article should read like a mature public-account piece, not a report or memo.

### 4. Required humanizer pass

After the first draft is complete, run a separate humanizer refinement pass.

This is mandatory. Treat it as an explicit second phase, not a vague intention during drafting.

During the humanizer pass:

- Remove stiff AI-summary phrasing
- Cut inflated abstract nouns and empty macro language
- Break overly symmetrical sentence patterns
- Vary rhythm between short and long sentences
- Keep a clear human point of view
- Preserve clarity and credibility

The goal is not to make the text casual. The goal is to make it read like a real writer with judgment.

If helpful, keep both files:

- `*_draft.md` for the initial version
- final `*.md` for the humanized version

## Image Rules

### 5. Image sourcing

Images must be strongly related to the article, not generic filler.

Prefer images from the reporting pages or official pages used in the research phase. Good sources include:

- Official news or government pages
- Mainstream news pages covering the event
- Official company or institution pages tied to the story

Avoid random stock-style images when event photos exist.

If the researched webpages do not provide usable article images, use an appropriate draw-skill-main visual tool only for explanatory body visuals, such as a logic diagram, timeline, process chart, data graphic, or concept illustration. This fallback is for helping readers understand the issue, not for pretending to have documentary event photos.

When using generated or drawn visuals:

- Make the visual explanatory, schematic, or clearly illustrative; avoid photorealistic fake news scenes.
- Caption it honestly as an AI-generated illustration, diagram, or editorial graphic.
- Do not use any self-created, AI-generated, or draw-skill-main image as the article cover.
- Keep searching for a compliant sourced cover image from official pages, mainstream reporting, licensed material, or a user-provided image. If no compliant cover can be found, report that as a publication blocker instead of substituting a self-created cover.

### 6. Image localization for stability

Remote image hotlinks can fail during `wenyan publish`.

Preferred workflow:

1. Select relevant sourced images from reporting pages
2. Download them to a local article image folder
3. Create explanatory generated visuals only when sourced pages have no usable body images
4. Reference all approved body images with local relative paths in Markdown
5. Let `wenyan` upload them during publication

Use 3 to 5 body images when available. Add a caption for each image with source attribution, or an honest generated-visual label when the image was created as an explanatory illustration.

## Layout Rules

### 7. House layout standard

When the article Markdown already exists and the image set has been selected, run a separate layout pass before publication.

This layout pass is mandatory.

Use the local style guide at:

- `references/wechat-layout-style-guide.md`

Load that bundled file from this skill package and treat it as the house standard for WeChat article presentation. Do not depend on a user-specific absolute path for the style guide.

### 8. What the layout pass must do

During the layout pass, reshape the article so it follows the house style:

- Keep the overall tone minimal, premium, calm, and editorial
- Use one clear title and an optional short subtitle or lead
- Keep the opening tight and avoid empty scene-setting
- Insert concise section headings every 3 to 5 paragraphs when needed
- Keep body paragraphs short to medium for mobile reading
- Use quote or emphasis blocks sparingly
- Control image density and place images where they support reading rhythm
- Use short captions only when context or attribution matters
- End quietly and clearly without inflated closing language

The layout pass must also enforce the writing constraints tied to this style:

- Avoid the Chinese "not this, but that" contrast template
- Avoid generic filler, hollow emphasis, and broad hype phrasing
- Avoid repeating the same paragraph opening pattern mechanically
- Avoid repeated sentence rhythm across adjacent paragraphs

### 9. WeChat-safe layout translation

Do not treat the style guide like a web design brief.

Translate it into WeChat-safe structure:

- Stable Markdown hierarchy
- Consistent section breaks
- Limited decorative elements
- One restrained Wenyan theme
- Local image references when possible

If a design idea from the style guide depends on free-form web layout, simplify it into structure, spacing, image choice, or heading rhythm rather than forcing unsupported formatting.

## Publication Format

### 10. Wenyan Markdown

Prepare the article as a Wenyan-compatible Markdown file with frontmatter:

```yaml
---
title: Article title
cover: ./relative/path/to/cover.png
---
```

The `cover` field must point to a compliant sourced or user-provided cover image. Do not set the cover to a self-created image, AI-generated image, draw-skill-main output, schematic diagram, or editorial illustration. If a compliant cover is unavailable, do not fake one; surface the blocker and ask for a cover source or permission to publish only after a proper cover is available.

The body should include:

- Headline
- Structured sections
- Embedded images
- Captions
- References

Default visual direction for this workflow:

- Use the minimalist premium house style from the local guide
- Prefer `lapis` as the default Wenyan theme unless the user requests another theme

### 11. Publishing

Publish only after the preflight outcome is `ready_to_publish`.

For environment-variable or credential-store publication, use:

```powershell
wenyan publish -f "article.md" -t lapis -h solarized-light
```

For `.env` based publication, use:

```powershell
wenyan publish -f "article.md" -t lapis -h solarized-light --env-file ".env"
```

For Wenyan server publication, use:

```powershell
wenyan publish -f "article.md" -t lapis -h solarized-light --server "https://api.example.com" --api-key "your-api-key"
```

If `wenyan` is not on `PATH`, use the recipient project's local executable, such as `.\node_modules\.bin\wenyan.cmd`, or report that Wenyan is not installed. Do not assume the current working directory contains this skill author's `node_modules`.

If publishing requires WeChat credentials, use the configured local environment values or the local credential setup already present on the recipient's machine.

Default publication target is the WeChat draft box.

## Response Pattern

When the user asks for draft-box publication, first run the publishing preflight and report either `ready_to_publish` or `can_prepare_only`.

Unless the user already gave a final topic, the first substantial response after preflight and research should be the 10-topic shortlist.

After topic selection, the execution pattern is:

1. Confirm or carry forward the preflight outcome
2. Research
3. Draft
4. Humanizer pass
5. Image localization
6. Cover compliance check
7. Layout pass using the house WeChat style guide
8. Final Markdown assembly
9. Wenyan publish only if `ready_to_publish`
10. Return the file path and Media ID, or return the file path plus the exact publishing blocker

## Quality Bar

Before claiming completion, verify:

- The publishing preflight was run before long-form work when publication was requested
- The article topic came from current hot-topic research
- The user was given 10 topic options first
- The final article was refined in a separate humanizer pass
- Sourced images are related to the actual news event, and any generated visuals explain the topic without implying they are event photos
- Any generated or drawn visuals are used only as clearly labeled body illustrations, never as the cover
- The cover image is sourced from an official, mainstream, licensed, or user-provided source
- The final article was passed through the house WeChat layout standard
- The Markdown is publishable by Wenyan
- The article was published to the WeChat draft box, or a concrete blocker was reported

If publishing fails because of remote image instability, switch to local copies and retry.
