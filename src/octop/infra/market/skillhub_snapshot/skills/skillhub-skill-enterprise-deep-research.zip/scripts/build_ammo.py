# -*- coding: utf-8 -*-
"""一页纸谈单弹药包 · 命令行生成器。

把「大客户谈单作战手册」的最终交付物做成一条命令可产出，
并对所有常见失败路径给出 `[错误]` / `[依赖缺失]` 前缀提示 + 明确退出码，
不抛裸 traceback。

用法：
  build_ammo.py --demo [--out-dir DIR]          # 用内置样例直接出一份（零配置）
  build_ammo.py --data spec.json --out-dir DIR  # 按 spec 出一份
  build_ammo.py --template                      # 打印 spec 骨架

退出码：
  0  成功（可能有 [警告]）
  1  依赖缺失 / 写入失败 / 未预期错误
  2  参数或数据问题（文件不存在、JSON 解析失败、字段缺失、表格列数不匹配）
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PIP = ("\"C:/Users/ghszb/.workbuddy/binaries/python/envs/default/Scripts/python.exe\""
       " -m pip install python-docx")

# ---------------------------------------------------------------- 依赖守卫
try:
    sys.path.insert(0, HERE)
    from report_kit import Report
except ImportError as e:                                   # pragma: no cover
    sys.stderr.write("[依赖缺失] %s\n" % e)
    sys.stderr.write("修复命令：\n  %s\n" % PIP)
    sys.exit(1)


def die(code, msg, *hints):
    sys.stderr.write("[错误] %s\n" % msg)
    for h in hints:
        sys.stderr.write("       %s\n" % h)
    sys.exit(code)


TEMPLATE = {
    "title": "XX 公司 谈单弹药包",
    "subtitle": "会谈时间 · 对方：姓名职务 · 我方目标：一句话",
    "confidential": "内部资料",
    "footer": "博维管理咨询",
    "out": "XX公司_谈单弹药包.docx",
    "summary": [
        "一句话目标：这次要拿到的最小承诺（不是'保持联系'）。",
        "最大机会：一句话说清对方为什么现在就要解决。",
        "最大风险：谁会拦、为什么要拦。",
    ],
    "sections": [
        {
            "heading": "一、对方三张脸",
            "table": {
                "headers": ["角色", "姓名职务", "真实诉求", "雷区"],
                "rows": [
                    ["决策人", "王总 董事长", "三年内做出可复制的交付体系", "别谈理论，只谈多久见效"],
                    ["影响者", "刘经理 采购总监", "别动他现有的供应商格局", "别当着老板面质疑他的数据"],
                    ["把关人", "陈会计 财务", "付款节奏与发票合规", "不接受季付以外的账期"],
                ],
            },
        },
        {
            "heading": "二、三套预案",
            "table": {
                "headers": ["预案", "开价", "底线", "触发条件"],
                "rows": [
                    ["最优：全年陪跑", "48 万/年，季付", "36 万", "老板当场拍板"],
                    ["备选：单模块 6 周", "18 万", "12 万", "老板犹豫、要先看效果"],
                    ["兜底：1 天诊断", "2.8 万", "2.8 万不让", "预算卡死 / 有人拦"],
                ],
            },
            "callout": {"title": "让步顺序", "text": "先让周期，再让附加服务，最后才谈总价且同步减范围。"},
        },
        {
            "heading": "三、现场算账框架",
            "numbered": [
                "把对方痛点折成一个年度金额（例如人效下滑 18% ≈ 年损失 620 万）。",
                "我方报价占该金额的比例，当场写在白板上。",
                "给出回本周期：X 个月由增量覆盖投入。",
            ],
        },
        {
            "heading": "四、红线与让步顺序",
            "bullets": [
                "红线：不接受纯结果对赌；不先出方案后谈价。",
                "让步次序：周期 → 附加服务 → 总价（同步减范围）。",
                "查不到的数字一律写「待核实」，不许补全。",
            ],
        },
    ],
}


DEMO = {
    "title": "宏远精密 谈单弹药包",
    "subtitle": "2026-09-12 14:00 · 对方：董事长王总、采购刘经理 · 我方目标：签诊断单",
    "confidential": "内部资料",
    "footer": "博维管理咨询",
    "out": "宏远精密_谈单弹药包_20260909.docx",
    "summary": [
        "一句话目标：当场拿到「组织诊断」立项，收预付款，不是'保持联系'。",
        "最大机会：三年营收翻番但人效下滑 18%，王总自己说'管不动了'。",
        "最大风险：刘经理是既得利益者，会拿'以前做过没用'拦人。",
    ],
    "sections": [
        {
            "heading": "一、对方三张脸",
            "table": {
                "headers": ["角色", "姓名职务", "真实诉求", "雷区"],
                "rows": [
                    ["决策人", "王总 董事长", "三年内做出可复制的交付体系", "别谈理论，只谈多久见效"],
                    ["影响者", "刘经理 采购总监", "别动他现有的供应商格局", "别当着王总面质疑他的数据"],
                    ["把关人", "陈会计 财务", "付款节奏与发票合规", "不接受季付以外的账期"],
                ],
            },
        },
        {
            "heading": "二、三套预案",
            "table": {
                "headers": ["预案", "开价", "底线", "触发条件"],
                "rows": [
                    ["最优：全年陪跑", "48 万/年，季付", "36 万", "王总当场拍板"],
                    ["备选：单模块 6 周", "18 万", "12 万", "王总犹豫、要先看效果"],
                    ["兜底：1 天诊断", "2.8 万", "2.8 万不让", "预算卡死 / 刘经理拦"],
                ],
            },
            "callout": {"title": "让步顺序", "text": "先让周期，再让附加服务，最后才谈总价且同步减范围。"},
        },
        {
            "heading": "三、现场算账框架",
            "numbered": [
                "人效下滑 18% ≈ 年损失约 620 万（按 2025 营收与人数推算，待核实）。",
                "我方 48 万报价 ≈ 该损失的 7.7%，当场写在白板上。",
                "回本周期：交付体系见效后约 5 个月由增量覆盖投入。",
            ],
        },
        {
            "heading": "四、红线与让步顺序",
            "bullets": [
                "红线：不接受纯结果对赌；不先出方案后谈价。",
                "让步次序：周期 → 附加服务 → 总价（同步减范围）。",
                "人效 18% 为推断值，现场须与王总核对后再引用。",
            ],
        },
    ],
}


def load_spec(path):
    if not os.path.isfile(path):
        die(2, "数据文件不存在：%s" % path,
            "用绝对路径；Windows 路径建议把反斜杠改成正斜杠。",
            "或先跑 `--template > spec.json` 生成骨架。")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        die(2, "JSON 解析失败（文件 %s）：%s" % (path, e),
            "常见原因：尾逗号、中文引号（“ ”）、用了单引号、注释未删。",
            "修复：`--template > spec.json` 重新生成骨架再照填。")
    except UnicodeDecodeError as e:
        die(2, "文件编码不是 UTF-8：%s" % e, "把 spec.json 另存为 UTF-8 再试。")


def build(spec, out_dir):
    title = (spec.get("title") or "").strip()
    if not title:
        die(2, "spec 缺少必填字段 `title`",
            "一页纸必须有标题，否则打印出来分不清是哪家的。")

    out_name = spec.get("out") or ("%s_谈单弹药包.docx" % title.replace(" ", ""))
    out_path = os.path.join(out_dir, out_name)

    r = Report(title=title,
               subtitle=spec.get("subtitle"),
               confidential=spec.get("confidential"),
               footer=spec.get("footer") or "博维管理咨询",
               cover=False)                      # 一页纸不要封面

    if spec.get("summary"):
        r.summary(spec["summary"])

    sections = spec.get("sections") or []
    if not sections:
        sys.stderr.write("[警告] spec 里没有 sections，产出的将只有标题与结论\n")

    for idx, sec in enumerate(sections, 1):
        try:
            if sec.get("heading"):
                r.h1(sec["heading"])
            if sec.get("table"):
                t = sec["table"]
                r.table(t["headers"], t["rows"])
            if sec.get("bullets"):
                r.bullets(sec["bullets"])
            if sec.get("numbered"):
                r.numbered(sec["numbered"])
            if sec.get("callout"):
                c = sec["callout"]
                r.callout(c.get("title") or "提示", c.get("text") or "")
        except KeyError as e:
            die(2, "第 %d 个 section 缺少字段 %s" % (idx, e),
                "每个 section 可用：heading / table{headers,rows} / bullets / numbered / callout{title,text}")
        except (ValueError, IndexError) as e:
            die(2, "第 %d 个 section 的表格列数不匹配：%s" % (idx, e),
                "表头有几列，每一行就必须有几列。")

    try:
        saved = r.save(out_path)
    except PermissionError:
        die(1, "写入失败（权限不足或文件被占用）：%s" % out_path,
            "先关掉已打开的这个 docx，或换一个输出目录。")
    except OSError as e:
        die(1, "写入失败：%s" % e, "检查磁盘空间与路径合法性。")

    size = os.path.getsize(saved)
    print("[生成] %s（%s 字节）" % (saved, format(size, ",")))
    if size == 0:
        sys.stderr.write("[警告] 文件大小为 0，请检查内容\n")
    return saved


def main():
    ap = argparse.ArgumentParser(
        description="一页纸谈单弹药包生成器",
        epilog="退出码：0 成功 / 1 依赖或写入失败 / 2 参数与数据问题")
    ap.add_argument("--demo", action="store_true", help="用内置样例直接出一份（零配置）")
    ap.add_argument("--data", help="spec.json 路径")
    ap.add_argument("--out-dir", default=".", help="输出目录（不存在会自动创建）")
    ap.add_argument("--template", action="store_true", help="打印 spec 骨架")
    a = ap.parse_args()

    if a.template:
        print(json.dumps(TEMPLATE, ensure_ascii=False, indent=2))
        return 0

    if not a.demo and not a.data:
        ap.print_usage(sys.stderr)
        die(2, "需要 --demo 或 --data（或先用 --template 生成骨架）",
            "最快试法：`build_ammo.py --demo --out-dir ./试试`")

    spec = DEMO if a.demo else load_spec(a.data)

    try:
        build(spec, a.out_dir)
    except SystemExit:
        raise
    except Exception as e:                                  # 兜底：不抛裸 traceback
        die(1, "未预期错误：%s: %s" % (type(e).__name__, e),
            "若反复出现，请携带上面的信息反馈。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
