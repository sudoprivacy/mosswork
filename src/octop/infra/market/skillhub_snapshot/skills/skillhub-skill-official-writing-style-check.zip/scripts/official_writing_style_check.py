# -*- coding: utf-8 -*-
"""公文用语规范体检 — 离线、纯标准库、不联网的公文语言规范检查工具。

功能：
  对一段公文 / 机关文稿 / 正式事务材料的正文做确定性"用语规范体检"，逐行给出问题定位：
    - 数字用法（年份简写、届次会议用阿拉伯数字、概数顿号、定型词组用阿拉伯数字）
    - 法定计量单位（斤/尺/寸/磅等非法定单位、平米缩写）
    - 称谓用语（咱们/你们 等口语自称与不对称第二人称）
    - 标题标点（标题末尾误用句号/逗号）
    - 文风语气（绝对化浮夸、口语方言词）
    - 层次序号（阿拉伯数字后接顿号）
    - 文种禁忌（报告夹带请示、请示缺请示语）
    - 模糊推诿用语过多
  不做：不解析图片、不联网、不读工作区、不替用户下政治/法律结论；政治表述以权威发布为准，本工具不做政治表述核对。

退出码：0 无问题 / 1 检出需修正项 / 2 参数或文件错误。
依据：GB/T 15835-2011《出版物上数字用法》、GB/T 9704-2012《党政机关公文格式》、
      《党政机关公文处理工作条例》、公文用语规范通用要求。
"""
import argparse
import json
import re
import sys

VERSION = "1.0.0"

# 文种（用于标题识别与文种禁忌判定）
WENZHONG = ["通知", "通报", "报告", "请示", "批复", "函", "决定", "决议",
            "意见", "公告", "通告", "纪要", "命令", "令"]

# ---------------------------------------------------------------------------
# 规则目录（config 子命令输出；validate 子命令据此自测）
# ---------------------------------------------------------------------------
RULES = [
    dict(id="YEAR_ABBREV", name="年份简写", severity="ERROR",
         basis="GB/T 15835-2011 4.2 年份应写全称",
         desc="两位数字年份（如 '98年'）应写为四位全称（'1998年'）。"),
    dict(id="ORDINAL_FULIHUI", name="届次会议用阿拉伯数字", severity="ERROR",
         basis="公文用语规范：会议届次用汉字数字",
         desc="'5中全会'应写为'五中全会'；'19大'应写为'十九大'。"),
    dict(id="ORDINAL_DA", name="数词+大 用阿拉伯数字", severity="MEDIUM",
         basis="公文用语规范：数量结构用汉字数字",
         desc="'3大产业'应写为'三大产业'。"),
    dict(id="ORDINAL_JIE", name="届次用阿拉伯数字", severity="MEDIUM",
         basis="公文用语规范：届次用汉字数字",
         desc="'13届'应写为'十三届'。"),
    dict(id="APPROX_DUNHAO", name="概数误用顿号", severity="MEDIUM",
         basis="GB/T 15835-2011 5.1 相邻数字表概数中间不加顿号",
         desc="'二、三个'应写为'二三个'。"),
    dict(id="UNIT_ILLEGAL", name="非法定计量单位", severity="MEDIUM",
         basis="GB 3100-1993 应使用国家法定计量单位",
         desc="'5斤''3尺''2磅'应换算为公斤/米等法定单位。"),
    dict(id="UNIT_PINGMI", name="平米缩写", severity="LOW",
         basis="公文用语规范：书写应规范",
         desc="'平米'应写为'平方米'。"),
    dict(id="TITLE_PUNCT", name="标题末尾标点", severity="ERROR",
         basis="GB/T 9704-2012 7.3.1 标题一般不用标点符号",
         desc="标题行末尾误用句号/逗号，应去除（法规规章名称加书名号除外）。"),
    dict(id="ZANMEN", name="口语自称'咱们'", severity="ERROR",
         basis="公文用语规范：称谓用语",
         desc="公文机关自称用'本/我'，不用口语'咱们'。"),
    dict(id="NIMEN", name="第二人称'你们'", severity="MEDIUM",
         basis="公文用语规范：称谓用语",
         desc="对下级用'你（处/单位）'，对平级用'贵'，不用'你们'。"),
    dict(id="ABSOLUTE_CLAIM", name="绝对化浮夸用语", severity="MEDIUM",
         basis="公文用语规范：语气应客观平实",
         desc="'顶级''空前绝后''最优秀'等浮夸绝对化表述宜改为客观表述。"),
    dict(id="KOUYU", name="口语方言词", severity="MEDIUM",
         basis="公文用语规范：用语应规范书面",
         desc="'搞定''折腾''靠谱'等口语方言词应改为规范书面语。"),
    dict(id="CENGCI_DUNHAO", name="层次序号顿号", severity="MEDIUM",
         basis="GB/T 9704-2012 层次序号：'1.'用下脚点",
         desc="行首'1、'应写为'1.'（阿拉伯数字序号后用下脚点）。"),
    dict(id="BAOGAO_QINGSHI", name="报告夹带请示", severity="ERROR",
         basis="《条例》：报告不得夹带请示事项",
         desc="文种为'报告'时正文中出现'请批示/请批复'等请示用语。"),
    dict(id="QINGSHI_MISSING", name="请示缺请示语", severity="LOW",
         basis="公文用语规范：请示结尾应有商定请示语",
         desc="文种为'请示'但正文未见'妥否/当否/请批示'等请示语。"),
    dict(id="MOHU", name="模糊推诿用语过多", severity="LOW",
         basis="公文用语规范：责任主体应具体",
         desc="'有关部门/相关方面'等出现≥3次，建议具体化。"),
]

RULE_BY_ID = {r["id"]: r for r in RULES}

# ---------------------------------------------------------------------------
# 正则与词表
# ---------------------------------------------------------------------------
RE_YEAR = re.compile(r"(?<!\d)(\d{2})年(?!代)")
RE_FULIHUI = re.compile(r"(?<!\d)(\d{1,2})中全会")
RE_DA = re.compile(r"(?<!\d)(\d{1,2})大(?!会)")
RE_JIE = re.compile(r"(?<!\d)(\d{1,3})届")
RE_APPROX = re.compile(
    r"([一二三四五六七八九])、([一二三四五六七八九])"
    r"(个|米|年|次|名|项|种|条|吨|斤|户|所|件|本|张|把|台|辆|篇|份|倍)")
RE_UNIT = re.compile(r"(\d+)\s*(斤|尺|寸|磅|码|加仑|哩|英尺|英寸|英里)")
RE_TITLE_PUNCT = re.compile(r"[。，.\uff0e]\s*$")
RE_CENGCI = re.compile(r"^\s*\d+、")
RE_MOHU = re.compile(r"有关部门|相关单位|相关方面|有关方面|相关部门|有关单位")

ABSOLUTE_PHRASES = [
    "顶级", "空前绝后", "举世无双", "绝无仅有", "史无前例", "遥遥领先",
    "无与伦比", "独步天下", "登峰造极", "举世闻名", "最优秀", "最先进",
    "最强大", "最完美", "最重要", "最显著", "最突出", "最顶尖", "最权威",
    "最领先", "最震撼", "最惊艳", "最卓越", "最优异",
]
RE_ABSOLUTE = re.compile("|".join(re.escape(p) for p in ABSOLUTE_PHRASES))

KOUYU_WORDS = [
    "搞定", "折腾", "靠谱", "立马", "甭", "溜达", "忽悠", "捅娄子", "穿小鞋",
    "唠嗑", "哥们儿", "姐们儿", "费劲", "犯愁", "蛮好", "老外",
]
RE_KOUYU = re.compile("|".join(re.escape(w) for w in KOUYU_WORDS))

QINGSHI_MARK = re.compile(r"请批示|请批复|恳请批准|妥否|当否|是否妥当|以上请示|当否请")


def is_title_line(line):
    s = line.strip()
    if not s or len(s) > 40:
        return False, None
    # 去掉末尾标点后再判文种（标题行常带句号/逗号，去掉后仍以文种结尾）
    s2 = s.rstrip("。，.． ")
    for wz in WENZHONG:
        if s2.endswith(wz):
            return True, wz
    return False, None


def make_finding(line_no, col, rule_id, evidence, suggestion):
    r = RULE_BY_ID[rule_id]
    return dict(line=line_no, col=col, rule=rule_id, severity=r["severity"],
                message=r["name"], evidence=evidence,
                suggestion=suggestion, basis=r["basis"])


def check_text(text):
    """返回 (findings列表, 文档级标记 dict)。"""
    lines = text.splitlines()
    findings = []
    doc_is_report = False
    doc_is_qingshi = False

    for i, line in enumerate(lines, start=1):
        ln = line.strip()
        title_ok, wz = is_title_line(line)
        if wz == "报告":
            doc_is_report = True
        if wz == "请示":
            doc_is_qingshi = True

        # YEAR_ABBREV
        for m in RE_YEAR.finditer(line):
            findings.append(make_finding(i, m.start() + 1, "YEAR_ABBREV",
                             m.group(0), "写为四位年份，如 '%s年'→'%s年'" %
                             (m.group(1), "19" + m.group(1) if m.group(1)[0] == "9"
                              else "20" + m.group(1))))

        # ORDINAL_FULIHUI
        for m in RE_FULIHUI.finditer(line):
            han = _arabic_to_han(int(m.group(1)))
            findings.append(make_finding(i, m.start() + 1, "ORDINAL_FULIHUI",
                             m.group(0), "写为 '%s中全会'" % han))

        # ORDINAL_DA
        for m in RE_DA.finditer(line):
            han = _arabic_to_han(int(m.group(1)))
            findings.append(make_finding(i, m.start() + 1, "ORDINAL_DA",
                             m.group(0), "写为 '%s大'" % han))

        # ORDINAL_JIE
        for m in RE_JIE.finditer(line):
            han = _arabic_to_han(int(m.group(1)))
            findings.append(make_finding(i, m.start() + 1, "ORDINAL_JIE",
                             m.group(0), "写为 '%s届'" % han))

        # APPROX_DUNHAO
        for m in RE_APPROX.finditer(line):
            findings.append(make_finding(i, m.start() + 1, "APPROX_DUNHAO",
                             m.group(0), "写为 '%s%s'（去掉顿号）" %
                             (m.group(1), m.group(2))))

        # UNIT_ILLEGAL
        for m in RE_UNIT.finditer(line):
            unit = m.group(2)
            sugg = {"斤": "公斤（千克）", "尺": "米", "寸": "厘米", "磅": "千克",
                    "码": "米", "加仑": "升", "哩": "千米", "英尺": "米",
                    "英寸": "厘米", "英里": "千米"}.get(unit, "法定计量单位")
            findings.append(make_finding(i, m.start() + 1, "UNIT_ILLEGAL",
                             m.group(0), "换算为 %s" % sugg))

        # UNIT_PINGMI
        if "平米" in line:
            pos = line.index("平米")
            findings.append(make_finding(i, pos + 1, "UNIT_PINGMI", "平米",
                             "写为 '平方米'"))

        # TITLE_PUNCT
        if title_ok and RE_TITLE_PUNCT.search(ln):
            findings.append(make_finding(i, len(ln), "TITLE_PUNCT",
                             ln[-1], "去除标题末尾标点（法规规章名称加书名号除外）"))

        # ZANMEN
        if "咱们" in line:
            pos = line.index("咱们")
            findings.append(make_finding(i, pos + 1, "ZANMEN", "咱们",
                             "机关自称用 '本/我'（如 '我局''我部'）"))

        # NIMEN
        if "你们" in line:
            pos = line.index("你们")
            findings.append(make_finding(i, pos + 1, "NIMEN", "你们",
                             "对下级用 '你（处/单位）'，对平级用 '贵单位'"))

        # ABSOLUTE_CLAIM
        for m in RE_ABSOLUTE.finditer(line):
            findings.append(make_finding(i, m.start() + 1, "ABSOLUTE_CLAIM",
                             m.group(0), "改为客观平实表述，避免浮夸绝对化"))

        # KOUYU
        for m in RE_KOUYU.finditer(line):
            findings.append(make_finding(i, m.start() + 1, "KOUYU",
                             m.group(0), "改为规范书面语"))

        # CENGCI_DUNHAO
        if RE_CENGCI.match(line):
            m = RE_CENGCI.match(line)
            findings.append(make_finding(i, m.start() + 1, "CENGCI_DUNHAO",
                             m.group(0).strip(), "改为下脚点，如 '1.'"))

    # 文档级：报告夹带请示
    if doc_is_report:
        for i, line in enumerate(lines, start=1):
            if QINGSHI_MARK.search(line):
                findings.append(make_finding(i, 1, "BAOGAO_QINGSHI",
                                 line.strip()[:30],
                                 "报告不得夹带请示事项，另文请示"))

    # 文档级：请示缺请示语
    if doc_is_qingshi:
        full = "\n".join(lines)
        if not QINGSHI_MARK.search(full):
            findings.append(make_finding(0, 0, "QINGSHI_MISSING",
                             "（全文）", "请示结尾应加 '妥否，请批示' 等请示语"))

    # 文档级：模糊用语过多
    mohu_count = len(RE_MOHU.findall(text))
    if mohu_count >= 3:
        findings.append(make_finding(0, 0, "MOHU", "出现 %d 次" % mohu_count,
                         "建议具体化责任主体，减少 '有关/相关' 模糊指代"))

    return findings, dict(is_report=doc_is_report, is_qingshi=doc_is_qingshi)


_HAN = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"]


def _arabic_to_han(n):
    if 0 <= n <= 10:
        return _HAN[n]
    if 11 <= n <= 19:
        return "十" + _HAN[n - 10]
    if 20 <= n <= 99:
        t, o = divmod(n, 10)
        if o == 0:
            return _HAN[t] + "十"
        return _HAN[t] + "十" + _HAN[o]
    return str(n)


# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------
SEV_ORDER = {"ERROR": 0, "MEDIUM": 1, "LOW": 2}


def summarize(findings):
    s = {"total": len(findings), "error": 0, "medium": 0, "low": 0}
    for f in findings:
        if f["severity"] == "ERROR":
            s["error"] += 1
        elif f["severity"] == "MEDIUM":
            s["medium"] += 1
        else:
            s["low"] += 1
    return s


def human_report(text_src, lines_total, findings, sev_filter=None):
    out = []
    out.append("公文用语规范体检 v%s" % VERSION)
    out.append("输入: %s (%d 行)" % (text_src, lines_total))
    if not findings:
        out.append("----")
        out.append("未检出用语规范问题。")
        return "\n".join(out)
    shown = [f for f in findings if sev_filter is None or
              SEV_ORDER[f["severity"]] <= SEV_ORDER[sev_filter]]
    shown.sort(key=lambda f: (f["line"], SEV_ORDER[f["severity"]], f["col"]))
    out.append("---- 检出问题 (%d 项) ----" % len(shown))
    for f in shown:
        loc = "[L%d]" % f["line"] if f["line"] else "[全文]"
        out.append("%s %-8s %s" % (loc, f["severity"], f["message"]))
        out.append("   命中: %s" % f["evidence"])
        out.append("   建议: %s" % f["suggestion"])
        out.append("   依据: %s" % f["basis"])
    s = summarize(findings)
    out.append("---- 统计 ----")
    out.append("ERROR: %d  MEDIUM: %d  LOW: %d" % (s["error"], s["medium"], s["low"]))
    if s["error"] or s["medium"]:
        out.append("建议：先修复 ERROR / MEDIUM 级问题后重新体检。")
    else:
        out.append("仅 LOW 级提示，可按需优化。")
    return "\n".join(out)


def json_report(text_src, lines_total, findings, sev_filter=None):
    shown = [f for f in findings if sev_filter is None or
             SEV_ORDER[f["severity"]] <= SEV_ORDER[sev_filter]]
    return dict(tool="official-writing-style-check", version=VERSION,
                input=text_src, lines=lines_total,
                findings=shown, summary=summarize(findings),
                exit_code=1 if findings else 0)


# ---------------------------------------------------------------------------
# 子命令
# ---------------------------------------------------------------------------
def detect_text_from_bytes(raw):
    """探测编码：utf-8-sig -> utf-8 -> gbk -> latin-1(replace)。"""
    for enc in ("utf-8-sig", "utf-8", "gbk", "latin-1"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", "replace"), "latin-1"


def read_input(args):
    if args.input:
        try:
            with open(args.input, "rb") as f:
                raw = f.read()
        except OSError as e:
            sys.stderr.write("无法读取文件: %s\n" % e)
            sys.exit(2)
        text, _ = detect_text_from_bytes(raw)
        return text, args.input
    else:
        return sys.stdin.read(), "<stdin>"


def cmd_check(args):
    text, src = read_input(args)
    findings, _ = check_text(text)
    lines_total = len(text.splitlines())
    if args.json:
        rep = json_report(src, lines_total, findings, args.sev)
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        print(human_report(src, lines_total, findings, args.sev))
    sys.exit(1 if findings else 0)


def cmd_config(args):
    if args.json:
        print(json.dumps(dict(tool="official-writing-style-check",
              version=VERSION, rules=RULES), ensure_ascii=False, indent=2))
    else:
        print("公文用语规范体检 v%s — 规则目录 (%d 条)" % (VERSION, len(RULES)))
        print("----")
        for r in RULES:
            print("[%s] %-22s %-7s" % (r["id"], r["name"], r["severity"]))
            print("   %s" % r["desc"])
            print("   依据: %s" % r["basis"])
    sys.exit(0)


# 内置自测样例：{文本: 应触发的规则 id 集合}
SELF_TESTS = [
    ("根据98年的数据，我局开展了工作。", {"YEAR_ABBREV"}),
    ("会议传达了5中全会精神。", {"ORDINAL_FULIHUI"}),
    ("3大产业协同发展。", {"ORDINAL_DA"}),
    ("13届人大一次会议。", {"ORDINAL_JIE"}),
    ("涉及二、三个部门。", {"APPROX_DUNHAO"}),
    ("采购5斤大米和3尺布。", {"UNIT_ILLEGAL"}),
    ("建筑面积约120平米。", {"UNIT_PINGMI"}),
    ("关于进一步加强安全管理的通知。", {"TITLE_PUNCT"}),
    ("咱们单位要扎实推进。", {"ZANMEN"}),
    ("请你们单位按时报送。", {"NIMEN"}),
    ("这是最优秀的方案，堪称顶级。", {"ABSOLUTE_CLAIM"}),
    ("问题已经搞定，别折腾了。", {"KOUYU"}),
    ("1、提高认识；2、落实责任。", {"CENGCI_DUNHAO"}),
    ("关于XX工作情况的报告。\n妥否，请批示。", {"BAOGAO_QINGSHI"}),
    ("关于XX事项的请示。\n现将有关情况说明如下。", {"QINGSHI_MISSING"}),
    ("有关部门、相关单位、有关方面均参与，相关部门落实。", {"MOHU"}),
]


def cmd_validate(args):
    passed = 0
    failed = 0
    details = []
    for text, expect in SELF_TESTS:
        findings, _ = check_text(text)
        got = {f["rule"] for f in findings}
        missing = expect - got
        if not missing:
            passed += 1
        else:
            failed += 1
            details.append("FAIL: 期望 %s 实际漏检 %s | 样本: %s" %
                           (sorted(expect), sorted(missing), text[:30]))
    print("公文用语规范体检 v%s 自测" % VERSION)
    print("----")
    print("通过 %d / %d" % (passed, len(SELF_TESTS)))
    for d in details:
        print(d)
    sys.exit(0 if failed == 0 else 1)


def build_parser():
    p = argparse.ArgumentParser(
        description="公文用语规范体检：离线、纯标准库的公文语言规范检查工具。")
    p.add_argument("--version", action="version", version="%(prog)s " + VERSION)
    sub = p.add_subparsers(dest="cmd")

    pc = sub.add_parser("check", help="体检一段公文文本")
    pc.add_argument("input", nargs="?", help="文本文件路径(.txt/.md)；省略则读 stdin")
    pc.add_argument("--json", action="store_true", help="输出纯 JSON")
    pc.add_argument("--sev", choices=["ERROR", "MEDIUM", "LOW"],
                    help="只显示该级别及以上（默认全部）")
    pc.add_argument("--out", help="将报告写入文件（默认打印到 stdout）")
    pc.set_defaults(func=cmd_check)

    ps = sub.add_parser("config", help="输出规则目录")
    ps.add_argument("--json", action="store_true", help="输出纯 JSON")
    ps.set_defaults(func=cmd_config)

    pv = sub.add_parser("validate", help="运行内置自测断言")
    pv.set_defaults(func=cmd_validate)

    return p


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "cmd", None):
        parser.print_help()
        sys.exit(2)
    args.func(args)


if __name__ == "__main__":
    main()
