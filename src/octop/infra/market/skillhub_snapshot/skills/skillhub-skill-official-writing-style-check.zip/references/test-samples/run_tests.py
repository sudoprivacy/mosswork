# -*- coding: utf-8 -*-
"""公文用语规范体检 — 回归测试（纯标准库）。

期望全部手算：每个样本应触发哪些规则 id、退出码是多少，写死在 CASES 里。
用法：python3 run_tests.py [脚本路径] [样本目录]
默认脚本 = ../scripts/official_writing_style_check.py，样本目录 = /tmp/gw_samples
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "scripts", "official_writing_style_check.py")
SAMPLE_DIR = sys.argv[2] if len(sys.argv) > 2 else "/tmp/gw_samples"

# (文件名, 期望触发的规则 id 集合, 期望退出码, 禁止出现的规则 id 集合)
CASES = [
    ("s_clean.txt", set(), 0, None),
    ("s_year.txt", {"YEAR_ABBREV"}, 1, None),
    ("s_ordinal.txt", {"ORDINAL_FULIHUI", "ORDINAL_DA", "ORDINAL_JIE"}, 1, None),
    ("s_approx.txt", {"APPROX_DUNHAO"}, 1, None),
    ("s_unit.txt", {"UNIT_ILLEGAL", "UNIT_PINGMI"}, 1, None),
    ("s_title.txt", {"TITLE_PUNCT"}, 1, None),
    ("s_zanmen.txt", {"ZANMEN"}, 1, None),
    ("s_nimen.txt", {"NIMEN"}, 1, None),
    ("s_absolute.txt", {"ABSOLUTE_CLAIM"}, 1, None),
    ("s_kouyu.txt", {"KOUYU"}, 1, None),
    ("s_cengci.txt", {"CENGCI_DUNHAO"}, 1, None),
    ("s_baogao.txt", {"BAOGAO_QINGSHI"}, 1, None),
    ("s_qingshi.txt", {"QINGSHI_MISSING"}, 1, None),
    ("s_mohu.txt", {"MOHU"}, 1, None),
    ("s_mohu_low.txt", set(), 0, {"MOHU"}),
    ("s_equiv.txt", set(), 0, {"YEAR_ABBREV", "APPROX_DUNHAO"}),
    ("s_empty.txt", set(), 0, None),
    ("s_year_bom.txt", {"YEAR_ABBREV"}, 1, None),   # UTF-8 BOM 应被识别
    ("s_unit_gbk.txt", {"UNIT_ILLEGAL", "UNIT_PINGMI"}, 1, None),  # GBK 应被识别
]


def run_json(args):
    cmd = [sys.executable, SCRIPT, "check"]
    if "--json" not in args:
        cmd.append("--json")
    cmd += list(args)
    p = subprocess.run(cmd, capture_output=True, text=True)
    data = None
    if p.returncode in (0, 1):
        try:
            data = json.loads(p.stdout)
        except json.JSONDecodeError:
            data = None
    return p.returncode, data, p.stderr


def rule_set(data):
    return {f["rule"] for f in data["findings"]} if data else set()


def ok(cond, detail):
    if cond:
        print("  PASS  %s" % detail)
        return 1
    print("  FAIL  %s" % detail)
    return 0


def main():
    passed = 0
    total = 0
    # 1) 各样本断言
    for fname, expect, exp_rc, forbid in CASES:
        path = os.path.join(SAMPLE_DIR, fname)
        rc, data, err = run_json([path])
        print("[%s]" % fname)
        if data is None:
            print("  FAIL  无法解析 JSON (rc=%d stderr=%s)" % (rc, err.strip()))
            continue
        got = rule_set(data)
        # 退出码
        total += 1
        passed += ok(rc == exp_rc, "退出码 %d == %d" % (rc, exp_rc))
        # 期望规则全部命中
        missing = expect - got
        total += 1
        passed += ok(not missing, "期望规则全部命中 %s (漏:%s)" %
                     (sorted(expect), sorted(missing)) if expect else "无期望规则")
        # 禁止规则不出现
        if forbid:
            extra = forbid & got
            total += 1
            passed += ok(not extra, "无误报 %s (误:%s)" % (sorted(forbid), sorted(extra)))

    # 2) 空集合陷阱：用长度断言保证"无问题"是真的不空
    rc, data, _ = run_json([os.path.join(SAMPLE_DIR, "s_empty.txt")])
    total += 1
    passed += ok(data is not None and len(data["findings"]) == 0, "空文件 findings 长度为 0")

    # 3) --json 契约：必需键齐全
    rc, data, _ = run_json([os.path.join(SAMPLE_DIR, "s_year.txt")])
    keys_ok = data and all(k in data for k in ("tool", "version", "input", "lines", "findings", "summary", "exit_code"))
    total += 1
    passed += ok(keys_ok, "--json 顶层键齐全")
    fk = all(k in data["findings"][0] for k in ("line", "col", "rule", "severity", "message", "evidence", "suggestion", "basis")) if data and data["findings"] else False
    total += 1
    passed += ok(fk, "finding 字段齐全")

    # 4) 不存在文件 → 退出码 2
    rc, _, _ = run_json(["/tmp/__nonexistent_gw_2026__.txt"])
    total += 1
    passed += ok(rc == 2, "不存在文件退出码 2 (实际 %d)" % rc)

    # 5) config 规则数 == 16
    p = subprocess.run([sys.executable, SCRIPT, "config", "--json"], capture_output=True, text=True)
    cfg = json.loads(p.stdout)
    total += 1
    passed += ok(len(cfg["rules"]) == 16, "config 规则数 16 (实际 %d)" % len(cfg["rules"]))

    # 6) validate 子命令自测全过
    pv = subprocess.run([sys.executable, SCRIPT, "validate"], capture_output=True, text=True)
    total += 1
    passed += ok(pv.returncode == 0, "validate 自测通过 (rc=%d)" % pv.returncode)

    print("----")
    print("通过 %d / %d  (cases=%d)" % (passed, total, len(CASES)))
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
