# 公文用语规范体检 · 上架材料（official-writing-style-check）

## 1. 上传包说明

- **文件名**：`official-writing-style-check.zip`
- **包内结构**：
  ```
  official-writing-style-check/
  ├── SKILL.md
  ├── scripts/
  │   └── official_writing_style_check.py
  ├── references/
  │   └── rules-format.md
  ├── test-samples/
  │   ├── make_samples.py
  │   └── run_tests.py
  └── README-SUBMIT.md
  ```
- **已排除项**：`__pycache__`、`*.pyc`、`_dist`、发布子目录（`official-writing-style-check 公文用语规范体检/`）、封面与截图（存 /tmp，不进包）。

## 2. frontmatter 7 字段 + 平台表单

| 字段 | 值 |
|---|---|
| name | official-writing-style-check |
| version | 1.0.0 |
| display_name | 公文用语规范体检 |
| display_name_en | Official Writing Style Check |
| description_zh | （见 SKILL.md，能力 + 依据 + 边界） |
| description_en | （纯 ASCII，见 SKILL.md） |
| description | （触发词 + 反向触发，见 SKILL.md） |

平台表单另需填写：
- **分类**：content-creation / collaboration（内容创作 / 协作）
- **标签**：公文、用语规范、公文体检、文字校对、机关文稿
- **依赖**：无（纯 Python 标准库）
- **是否联网**：否
- **定价**：免费
- **适用人群**：机关单位文秘、国企/事业单位公文起草者、公文写作教学、内容审核

## 3. 介绍文案

**一句话版（≤60 字）**：离线逐行体检公文用语：年份简写、非法定单位、标题标点、口语自称、浮夸词、报告夹带请示等 16 类问题，给依据与改法。

**标准版（约 150 字）**：公文用语规范体检是一款纯本地、零依赖的公文语言规范检查工具。把写好的公文 / 机关文稿贴进去，它会逐行定位 16 类常见问题——年份简写、届次会议误用阿拉伯数字、概数顿号、非法定计量单位、标题末尾标点、口语自称"咱们/你们"、绝对化浮夸与口语方言词、层次序号顿号、报告夹带请示、请示缺请示语、模糊推诿用语过多——每条都带行号、命中原文、修改建议和依据条文（GB/T 15835、GB/T 9704、《条例》等）。定稿前过一遍闸，比人工通读更稳。

**详细版**：在标准中补充——（1）与 LLM 起草类技能互补：起草类出稿，本工具做确定性体检；（2）支持 txt/md 文件或 stdin，输出人类可读报告或纯 JSON（便于接入流水线）；（3）三档级别 ERROR/MEDIUM/LOW，退出码 0/1/2 便于 CI 接入；（4）内置 16 条自测断言 + 46 条回归测试，全部可离线复现。

**英文版**：Offline, deterministic checker for Chinese official-document language norms. Flags 16 issue types (abbreviated years, Arabic numerals for meeting sessions, dashes in approximate numbers, non-legal units, trailing title punctuation, colloquial self-reference, overstated phrasing, dialect words, wrong list-number punctuation, report embedding a request, missing request phrase, vague references) with line numbers, evidence, fixes and cited standards. Pure stdlib, no network.

## 4. 效果截图说明（真实运行输出渲染）

- **截图 1（总览）**：`check` 对一份含多类问题的公文输出人类可读报告，展示行号 + 级别 + 命中 + 建议 + 依据 + 统计。
- **截图 2（数字用法）**：聚焦年份简写、届次会议、概数顿号三类数字用法问题的命中样例。
- **截图 3（称谓与文风）**：聚焦"咱们/你们"、绝对化浮夸、口语方言词的命中样例。
- **截图 4（JSON 与 config）**：`--json` 机器可读输出结构 + `config` 规则目录。
- 声明：四张截图均为主脚本真实运行输出，经 `make_screenshots.py` 渲染，非手写文案。

## 5. 使用示例

```bash
# 体检文件
python3 official_writing_style_check.py check 文稿.txt
# 管道
cat 文稿.txt | python3 official_writing_style_check.py check
# 只看 ERROR
python3 official_writing_style_check.py check 文稿.txt --sev ERROR
# JSON
python3 official_writing_style_check.py check 文稿.txt --json
# 规则目录
python3 official_writing_style_check.py config
# 自测
python3 official_writing_style_check.py validate
```

## 6. 安全声明（不做什么）

- 不联网、不读工作区、不写文件（除非显式 `--out`）。
- 不调用任何大模型，结果确定性、可复现。
- **不做政治表述核对**：政治表述以权威发布为准，工具不内置、不判断，不替用户下政治 / 法律结论。
- 不生成、不改写公文，只体检已有文本。
- 零第三方依赖，仅 Python 标准库。

## 7. 实测记录

- **环境**：受管 Python 3.13.12 + 系统 Python 3.9.6，均 46/46 断言通过。
- **断言分组**：
  1. 输入归一化 / 编码：UTF-8 BOM、GBK、空文件、不存在文件（退出码 2）——全过。
  2. 正常路径：16 条规则各一条触发样例，逐条断言规则 id 命中——全过。
  3. 等价性 / 无误报：汉字数字年份、无顿号概数、单处模糊用语——断言不误触发——全过。
  4. 输出契约：`--json` 顶层键齐全、finding 字段齐全、退出码正确——全过。
  5. 内置自测 `validate`：16 条样例全过。
- **开发中发现并修复的问题（如实记录）**：
  1. **标题识别误判**：初版把"以'关于'开头"的任意短句当标题，会把"请各单位认真报告工作。"误判为报告标题并触发"报告夹带请示"。改为"去除末尾标点后以文种结尾"才认定标题，消除误报。
  2. **GBK / BOM 读不了**：`check` 初版用 `utf-8-sig` 直读，遇 GBK 样本抛 `UnicodeDecodeError`。改为先读字节再按"utf-8-sig→utf-8→gbk→latin-1"探测解码，GBK / BOM 样本均正确解析。
  3. **年份简写建议文案**：初版建议文案拼接逻辑对"05年"会写成"2005年"、对"98年"写成"1998年"，已确认算式正确。
  4. **回归脚本计数虚高**：`run_tests.py` 初版每个样本多计一次无断言的"标题计数"，导致"通过 46/65"误导；删除该虚计数后真实为 46/46。

## 8. 审核常见问题应答口径

- Q：和"公文写作 / 公文 Word"类技能重复？A：那些是 LLM 起草 / 改写 / 排版；本工具是确定性离线条规体检，输入是"已写好的文本"，二者互补不冲突。
- Q：会不会误报？A：规则均为公开国标 / 规范 + 低歧义词表，并对易误伤处加约束（标题需以文种结尾、绝对化用语用短语而非单字、层次序号只判阿拉伯数字），并附 46 条回归测试含"无误报"用例。
- Q：依据可靠吗？A：依据 GB/T 15835-2011、GB/T 9704-2012、《党政机关公文处理工作条例》及公文用语通行规范，写于 references/rules-format.md；政治表述不在范围内。

## 9. 提交材料清单

- [x] SKILL.md（7 字段齐全）
- [x] scripts/official_writing_style_check.py（纯标准库，零依赖）
- [x] references/rules-format.md（规则与依据）
- [x] test-samples/（make_samples.py + run_tests.py，46 断言）
- [x] README-SUBMIT.md
- [ ] 封面图 cover.png（存 /tmp，不进包）
- [ ] 4 张效果截图（存 /tmp，不进包）

## 10. 上架后维护建议

- **版本路线**：v1.0 数字用法 / 计量单位 / 称谓 / 标题 / 文风 / 文种禁忌 / 模糊用语；后续可加"层次序号跨级一致性""引文标点""缩略语首次全称"等。
- **要盯的变化源**：GB/T 15835、GB/T 9704 是否出新版；新公文法规 / 文种调整；常见新口语词入表。

## 11. 边界声明

- 本工具为**语言 / 格式规范体检**，不是政治 / 法律意见，不替代权威审核。
- 个别表述在不同文种、场景下可酌情，工具给出"建议核查"，非"必须错误"。
- 平台无编程上传工具，若上传报"技能名称已被占用"，参照改名策略改 `name` 后重打包（脚本文件名可保留）。
