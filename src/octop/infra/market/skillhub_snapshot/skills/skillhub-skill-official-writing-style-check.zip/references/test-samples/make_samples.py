# -*- coding: utf-8 -*-
"""生成公文用语规范体检的回归测试样本（纯标准库）。

用法：python3 make_samples.py [输出目录]
样本均按"手算期望"构造：每个文件应触发哪些规则 id 在 run_tests.py 中写死。
"""
import os
import sys

SAMPLES = {
    # 规范公文（应 0 问题）
    "s_clean.txt": (
        "关于2024年度安全生产工作的通知\n"
        "\n"
        "一、提高政治站位\n"
        "各单位要严格落实主体责任。\n"
        "\n"
        "二、强化隐患排查\n"
        "对重点领域开展全面检查。\n"
        "\n"
        "三、加强应急值守\n"
        "确保信息报送渠道畅通。\n"
    ),
    # 年份简写
    "s_year.txt": "根据98年的统计数据，我局已完成年度工作。\n",
    # 届次会议用阿拉伯数字（3 条规则）
    "s_ordinal.txt": "会议传达了5中全会精神，推动3大产业，13届人大一次会议作出部署。\n",
    # 概数顿号（2 处）
    "s_approx.txt": "涉及二、三个部门，三、四年可以完成。\n",
    # 非法定单位 + 平米缩写
    "s_unit.txt": "采购5斤大米，占地3尺，建筑面积120平米。\n",
    # 标题末尾标点
    "s_title.txt": "关于进一步加强安全管理的通知。\n",
    # 口语自称
    "s_zanmen.txt": "咱们单位要扎实推进各项工作。\n",
    # 第二人称你们
    "s_nimen.txt": "请你们单位按时报送有关材料。\n",
    # 绝对化浮夸（2 处）
    "s_absolute.txt": "这是最优秀的方案，整体水平顶级。\n",
    # 口语方言词（2 处）
    "s_kouyu.txt": "问题已经搞定，不要再折腾了。\n",
    # 层次序号顿号（3 处）
    "s_cengci.txt": "1、提高认识；2、落实责任；3、强化考核。\n",
    # 报告夹带请示
    "s_baogao.txt": ("关于2023年工作总结的报告。\n"
                     "现将工作情况报告如下。\n"
                     "妥否，请批示。\n"),
    # 请示缺请示语
    "s_qingshi.txt": ("关于申请专项经费的请示。\n"
                      "因工作需要，现申请专项经费。\n"),
    # 模糊用语过多（4 次）
    "s_mohu.txt": "有关部门负责牵头，相关单位配合，有关方面参与，相关部门落实。\n",
    # 模糊用语仅 1 次（不应触发 MOHU）
    "s_mohu_low.txt": "有关部门负责牵头落实。\n",
    # 等价写法（汉字数字/无顿号）——不应误报
    "s_equiv.txt": "一九九八年召开会议，二三个部门参与协作。\n",
    # 空文件
    "s_empty.txt": "",
}

# GBK / BOM 变体（内容取自上面两个样本）
SAMPLES_GBK = {"s_unit_gbk.txt": SAMPLES["s_unit.txt"]}
SAMPLES_BOM = {"s_year_bom.txt": SAMPLES["s_year.txt"]}


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/gw_samples"
    os.makedirs(out, exist_ok=True)
    for name, txt in SAMPLES.items():
        with open(os.path.join(out, name), "w", encoding="utf-8") as f:
            f.write(txt)
    for name, txt in SAMPLES_GBK.items():
        with open(os.path.join(out, name), "wb") as f:
            f.write(txt.encode("gbk"))
    for name, txt in SAMPLES_BOM.items():
        with open(os.path.join(out, name), "w", encoding="utf-8-sig") as f:
            f.write(txt)
    print("samples written to %s (%d files)" % (out, len(SAMPLES) + len(SAMPLES_GBK) + len(SAMPLES_BOM)))


if __name__ == "__main__":
    main()
