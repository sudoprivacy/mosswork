#!/usr/bin/env python3
"""人才九宫格可视化生成器 — 9-Box Grid Generator v1.0

输入：员工姓名+绩效+潜力评分（CSV 或命令行参数）
输出：交互式 SVG 或 HTML 九宫格人才盘点图

用法：
    python 9box_generator.py --csv talents.csv --output grid.svg
    python 9box_generator.py --csv talents.csv --output grid.html --format html
    python 9box_generator.py --names "张三 李四" --perf "4.2 2.5" --pot "3.8 4.1" --output grid.svg
"""

import argparse
import csv
import math
import os
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


# ═══════════════════════════════════════════════════════════════
# 数据模型
# ═══════════════════════════════════════════════════════════════

@dataclass
class Employee:
    name: str
    perf: float          # 绩效评分 1.0-5.0
    pot: float           # 潜力评分 1.0-5.0
    department: Optional[str] = None


@dataclass
class GridConfig:
    perf_low: float = 2.5    # ≤ 此值为低绩效
    perf_high: float = 3.5   # ≥ 此值为高绩效（中间为中绩效）
    pot_low: float = 2.5
    pot_high: float = 3.5


# ═══════════════════════════════════════════════════════════════
# 九格定义
# ═══════════════════════════════════════════════════════════════

CELL_DEFS = {
    # (pot_col, perf_row) → (标签, 颜色, 核心建议)
    (3, 3): ("明星人才", "green",  "重点保留 · 加速晋升"),
    (3, 2): ("核心人才", "green",  "加大挑战 · 关注成长"),
    (2, 3): ("业务骨干", "yellow", "稳定激励 · 拓宽视野"),
    (2, 2): ("中坚力量", "yellow", "稳步发展 · 能力提升"),
    (1, 3): ("专家型",   "yellow", "精深发展 · 保留技能"),
    (3, 1): ("潜力股",   "yellow", "诊断根因 · 岗位匹配"),
    (1, 2): ("稳定贡献", "red",    "维持现状 · 适量投资"),
    (2, 1): ("待观察",   "red",    "绩效改进 · 关注适配"),
    (1, 1): ("问题员工", "red",    "限期改进 · 考虑优化"),
}

COLORS = {
    "green":  {"bg": "#C8E6C9", "dot": "#1B5E20", "label": "#2E7D32"},
    "yellow": {"bg": "#FFF9C4", "dot": "#E65100", "label": "#F57C00"},
    "red":    {"bg": "#FFCDD2", "dot": "#C62828", "label": "#C62828"},
}

COL_LABELS = {1: "低潜力", 2: "中潜力", 3: "高潜力"}
ROW_LABELS = {1: "低绩效", 2: "中绩效", 3: "高绩效"}


# ═══════════════════════════════════════════════════════════════
# 评分 → 格位映射
# ═══════════════════════════════════════════════════════════════

def score_to_col(score: float, low: float, high: float) -> int:
    if score <= low:
        return 1
    if score < high:
        return 2
    return 3


def classify_employees(employees: List[Employee], cfg: GridConfig) -> Dict[Tuple[int, int], List[Employee]]:
    """将员工列表映射到九格。"""
    grid: Dict[Tuple[int, int], List[Employee]] = {(c, r): [] for c in (1, 2, 3) for r in (1, 2, 3)}
    for emp in employees:
        col = score_to_col(emp.pot, cfg.pot_low, cfg.pot_high)
        row = score_to_col(emp.perf, cfg.perf_low, cfg.perf_high)
        grid[(col, row)].append(emp)
    return grid


# ═══════════════════════════════════════════════════════════════
# SVG 生成
# ═══════════════════════════════════════════════════════════════

class SVGGenerator:
    W = 800
    H = 810
    ORIGIN_X = 75
    ORIGIN_Y = 110
    CELL_W = 210
    CELL_H = 210
    GAP = 7

    def __init__(self, cfg: GridConfig):
        self.cfg = cfg

    def _cell_origin(self, col: int, row: int) -> Tuple[int, int]:
        x = self.ORIGIN_X + (col - 1) * (self.CELL_W + self.GAP)
        y = self.ORIGIN_Y + (3 - row) * (self.CELL_H + self.GAP)
        return x, y

    def _cell_center(self, col: int, row: int) -> Tuple[int, int]:
        ox, oy = self._cell_origin(col, row)
        return ox + self.CELL_W // 2, oy + self.CELL_H // 2

    def _jitter_positions(self, n: int, cx: int, cy: int, radius: int = 55) -> List[Tuple[int, int]]:
        """同格内 n 个点，用圆形排列错开。"""
        if n <= 1:
            return [(cx, cy)]
        positions = []
        for i in range(n):
            angle = 2 * math.pi * i / n - math.pi / 2
            positions.append((
                int(cx + radius * math.cos(angle)),
                int(cy + radius * math.sin(angle)),
            ))
        return positions

    def generate(self, grid: Dict[Tuple[int, int], List[Employee]],
                 title: str = "人才九宫格", subtitle: str = "") -> str:
        parts = [self._svg_header(title, subtitle)]

        # 列标签
        for c in (1, 2, 3):
            cx, _ = self._cell_center(c, 1)
            parts.append(f'<text x="{cx}" y="{self.ORIGIN_Y - 30}" class="col-label">{COL_LABELS[c]}</text>')

        # 行标签
        for r in (1, 2, 3):
            _, cy = self._cell_center(1, r)
            parts.append(f'<text x="{self.ORIGIN_X - 55}" y="{cy + 5}" class="row-label" text-anchor="end">{ROW_LABELS[r]}</text>')

        # 九格背景 + 文字
        for col in (1, 2, 3):
            for row in (1, 2, 3):
                ox, oy = self._cell_origin(col, row)
                label, zone, advice = CELL_DEFS[(col, row)]
                clr = COLORS[zone]
                rx, ry = 8, 8
                parts.append(f'<rect x="{ox}" y="{oy}" width="{self.CELL_W}" height="{self.CELL_H}" fill="{clr["bg"]}" rx="{rx}" ry="{ry}" stroke="#e0e0e0" stroke-width="1"/>')
                # 格标签
                label_y = oy + 35
                parts.append(f'<text x="{ox + self.CELL_W//2}" y="{label_y}" class="zone-label" fill="{clr["label"]}">{label}</text>')
                parts.append(f'<text x="{ox + self.CELL_W//2}" y="{label_y + 22}" class="zone-sub">{advice}</text>')

        # 员工数据点
        dot_id = 0
        for col in (1, 2, 3):
            for row in (1, 2, 3):
                emps = grid.get((col, row), [])
                if not emps:
                    continue
                cx, cy = self._cell_center(col, row)
                positions = self._jitter_positions(len(emps), cx, cy, radius=int(self.CELL_W * 0.25))
                for emp, (px, py) in zip(emps, positions):
                    label, zone, _ = CELL_DEFS[(col, row)]
                    dot_color = COLORS[zone]["dot"]
                    parts.append(self._employee_dot_svg(dot_id, emp, px, py, label, dot_color))
                    dot_id += 1

        # 图例
        parts.append(self._legend_svg())

        parts.append('</svg>')
        return '\n'.join(parts)

    def _svg_header(self, title: str, subtitle: str) -> str:
        sub = subtitle or f'绩效阈值 ≤{self.cfg.perf_low} 低 / {self.cfg.perf_low + 0.1:.1f}-{self.cfg.perf_high - 0.1:.1f} 中 / ≥{self.cfg.perf_high} 高'
        return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.W} {self.H}" width="100%" height="100%">
<defs>
  <style>
    text {{ font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif; }}
    .title {{ font-size: 20px; font-weight: bold; fill: #1a1a1a; }}
    .subtitle {{ font-size: 12px; fill: #888; }}
    .col-label {{ font-size: 15px; font-weight: bold; fill: #444; text-anchor: middle; }}
    .row-label {{ font-size: 14px; font-weight: bold; fill: #444; }}
    .zone-label {{ font-size: 14px; font-weight: bold; text-anchor: middle; }}
    .zone-sub {{ font-size: 11px; fill: #666; text-anchor: middle; }}
    .employee-dot {{ cursor: pointer; }}
    .employee-dot:hover circle {{ stroke: #333; stroke-width: 3.5; filter: drop-shadow(0 2px 3px rgba(0,0,0,0.25)); }}
    .tooltip {{ visibility: hidden; }}
    .employee-dot:hover .tooltip {{ visibility: visible; }}
    @keyframes pulse {{ 0%,100% {{ opacity: 1; }} 50% {{ opacity: 0.55; }} }}
    .star-dot {{ animation: pulse 2s ease-in-out infinite; }}
  </style>
</defs>
<rect width="{self.W}" height="{self.H}" fill="#ffffff" rx="12"/>
<text x="{self.W//2}" y="36" class="title" text-anchor="middle">{title}</text>
<text x="{self.W//2}" y="56" class="subtitle" text-anchor="middle">{sub}</text>'''

    def _employee_dot_svg(self, dot_id: int, emp: Employee, px: int, py: int,
                          label: str, dot_color: str) -> str:
        is_star = (emp.perf >= 4.5 and emp.pot >= 4.5)
        r = 10 if is_star else 8
        extra_class = 'star-dot' if is_star else ''
        dep_line = f'<tspan x="{px}" dy="16" font-size="10" fill="#ccc">{emp.department}</tspan>' if emp.department else ''

        return f'''  <g class="employee-dot {extra_class}" transform="translate({px}, {py})">
    <circle cx="0" cy="0" r="{r}" fill="{dot_color}" stroke="#fff" stroke-width="2.5" class="dot"/>
    <g class="tooltip">
      <rect x="-68" y="-58" width="136" height="52" rx="6" fill="#333" opacity="0.92"/>
      <text x="0" y="-42" fill="#fff" font-size="12" text-anchor="middle">{emp.name} | 绩{emp.perf} 潜{emp.pot}</text>
      <text x="0" y="-26" fill="#FFE082" font-size="11" text-anchor="middle">{label}</text>{dep_line}
    </g>
  </g>'''

    def _legend_svg(self) -> str:
        items = [
            ("🟢 绿区 · 优先投资", COLORS["green"]["bg"]),
            ("🟡 黄区 · 关注发展", COLORS["yellow"]["bg"]),
            ("🔴 红区 · 限期改进", COLORS["red"]["bg"]),
        ]
        x_start = self.W - 240
        lines = []
        for i, (label, color) in enumerate(items):
            y = 16 + i * 24
            lines.append(f'<rect x="{x_start}" y="{y}" width="16" height="16" rx="3" fill="{color}" stroke="#ccc"/>')
            lines.append(f'<text x="{x_start + 22}" y="{y + 13}" font-size="12" fill="#666">{label}</text>')
        return '\n'.join(lines)


# ═══════════════════════════════════════════════════════════════
# HTML 生成
# ═══════════════════════════════════════════════════════════════

class HTMLGenerator:
    def __init__(self, cfg: GridConfig):
        self.cfg = cfg

    def generate(self, grid: Dict[Tuple[int, int], List[Employee]],
                 title: str = "人才九宫格", subtitle: str = "") -> str:
        total = sum(len(v) for v in grid.values())
        sub = subtitle or f'绩效阈值 ≤{self.cfg.perf_low} / {self.cfg.perf_low+0.1:.1f}-{self.cfg.perf_high-0.1:.1f} / ≥{self.cfg.perf_high} · 共{total}人'

        cells_html = []
        for row in (3, 2, 1):
            for col in (1, 2, 3):
                emps = grid.get((col, row), [])
                label, zone, advice = CELL_DEFS[(col, row)]
                clr = COLORS[zone]
                emp_tags = ''.join(
                    f'<span class="emp-tag" data-name="{e.name}" data-perf="{e.perf}" data-pot="{e.pot}" data-label="{label}" title="{e.name}: 绩{e.perf} 潜{e.pot} — {label}">{e.name}</span>'
                    for e in emps
                )
                cells_html.append(f'''<div class="cell cell-{zone}" data-col="{col}" data-row="{row}">
  <div class="cell-label">{label}</div>
  <div class="cell-advice">{advice}</div>
  <div class="cell-employees">{emp_tags}</div>
</div>''')

        return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif; background: #f5f5f5; padding: 30px; }}
  .container {{ max-width: 960px; margin: 0 auto; }}
  h1 {{ text-align: center; color: #1a1a1a; margin-bottom: 6px; font-size: 24px; }}
  .subtitle {{ text-align: center; color: #888; font-size: 13px; margin-bottom: 24px; }}
  .legend {{ display: flex; justify-content: flex-end; gap: 20px; margin-bottom: 12px; font-size: 13px; }}
  .legend-item {{ display: flex; align-items: center; gap: 6px; }}
  .legend-dot {{ width: 14px; height: 14px; border-radius: 3px; border: 1px solid #ccc; }}
  .grid {{ display: grid; grid-template-columns: 50px repeat(3, 1fr); grid-template-rows: auto repeat(3, 1fr); gap: 8px; }}
  .corner {{ }}
  .col-header {{ text-align: center; font-weight: bold; color: #555; font-size: 14px; padding: 8px 0; }}
  .row-header {{ display: flex; align-items: center; font-weight: bold; color: #555; font-size: 14px; writing-mode: vertical-rl; text-orientation: upright; letter-spacing: 4px; }}
  .cell {{ border-radius: 10px; padding: 16px; min-height: 180px; display: flex; flex-direction: column; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: transform 0.2s, box-shadow 0.2s; }}
  .cell:hover {{ transform: translateY(-2px); box-shadow: 0 4px 16px rgba(0,0,0,0.12); }}
  .cell-green {{ background: #C8E6C9; }}
  .cell-yellow {{ background: #FFF9C4; }}
  .cell-red {{ background: #FFCDD2; }}
  .cell-label {{ font-size: 15px; font-weight: bold; margin-bottom: 2px; }}
  .cell-green .cell-label {{ color: #2E7D32; }}
  .cell-yellow .cell-label {{ color: #E65100; }}
  .cell-red .cell-label {{ color: #C62828; }}
  .cell-advice {{ font-size: 11px; color: #777; margin-bottom: 10px; }}
  .cell-employees {{ display: flex; flex-wrap: wrap; gap: 5px; }}
  .emp-tag {{ display: inline-block; padding: 4px 10px; border-radius: 14px; font-size: 12px; color: #fff; cursor: pointer; transition: transform 0.15s; position: relative; }}
  .cell-green .emp-tag {{ background: #388E3C; }}
  .cell-yellow .emp-tag {{ background: #E65100; }}
  .cell-red .emp-tag {{ background: #C62828; }}
  .emp-tag:hover {{ transform: scale(1.08); z-index: 10; }}
  .emp-tag:hover::after {{ content: attr(data-label); position: absolute; bottom: 110%; left: 50%; transform: translateX(-50%); white-space: nowrap; background: #333; color: #fff; padding: 3px 8px; border-radius: 4px; font-size: 11px; }}
  .stats {{ margin-top: 30px; display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }}
  .stat-card {{ background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }}
  .stat-card h3 {{ font-size: 15px; color: #1a1a1a; margin-bottom: 12px; }}
  .stat-card ul {{ list-style: none; font-size: 13px; color: #555; }}
  .stat-card li {{ padding: 4px 0; border-bottom: 1px solid #f0f0f0; }}
  .stat-card li:last-child {{ border-bottom: none; }}
</style>
</head>
<body>
<div class="container">
  <h1>{title}</h1>
  <div class="subtitle">{sub}</div>
  <div class="legend">
    <div class="legend-item"><span class="legend-dot" style="background:#C8E6C9"></span> 绿区 · 优先投资</div>
    <div class="legend-item"><span class="legend-dot" style="background:#FFF9C4"></span> 黄区 · 关注发展</div>
    <div class="legend-item"><span class="legend-dot" style="background:#FFCDD2"></span> 红区 · 限期改进</div>
  </div>
  <div class="grid">
    <div class="corner"></div>
    <div class="col-header">低潜力</div>
    <div class="col-header">中潜力</div>
    <div class="col-header">高潜力</div>
    <div class="row-header">高绩效</div>
    {cells_html[2]}  {cells_html[5]}  {cells_html[8]}
    <div class="row-header">中绩效</div>
    {cells_html[1]}  {cells_html[4]}  {cells_html[7]}
    <div class="row-header">低绩效</div>
    {cells_html[0]}  {cells_html[3]}  {cells_html[6]}
  </div>
  <div class="stats">
    <div class="stat-card">
      <h3>绿区 · 优先投资（{self._count_zone(grid, "green")}人）</h3>
      <ul>{''.join(self._zone_list(grid, "green"))}</ul>
    </div>
    <div class="stat-card">
      <h3>红区 · 限期改进（{self._count_zone(grid, "red")}人）</h3>
      <ul>{''.join(self._zone_list(grid, "red"))}</ul>
    </div>
  </div>
</div>
</body>
</html>'''

    def _count_zone(self, grid, zone: str) -> int:
        return sum(len(emps) for (col, row), emps in grid.items() if CELL_DEFS[(col, row)][1] == zone)

    def _zone_list(self, grid, zone: str) -> List[str]:
        items = []
        for (col, row), emps in grid.items():
            if CELL_DEFS[(col, row)][1] != zone:
                continue
            for e in emps:
                label = CELL_DEFS[(col, row)][0]
                items.append(f'<li><strong>{e.name}</strong> — 绩{e.perf} 潜{e.pot} · {label}</li>')
        return items


# ═══════════════════════════════════════════════════════════════
# CSV 解析
# ═══════════════════════════════════════════════════════════════

def parse_csv(filepath: str, department_filter: Optional[str] = None) -> List[Employee]:
    employees = []
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("CSV 文件为空或格式异常")

        # 自动识别列名
        col_map = _detect_columns(reader.fieldnames)

        for row_num, row in enumerate(reader, start=2):
            try:
                name = str(row[col_map['name']]).strip()
                perf = float(row[col_map['perf']])
                pot = float(row[col_map['pot']])
                dept = str(row.get(col_map.get('dept', ''), '')).strip() or None

                if not (1.0 <= perf <= 5.0 and 1.0 <= pot <= 5.0):
                    raise ValueError(f'评分超出 1.0-5.0 范围：绩效={perf} 潜力={pot}')

                if department_filter and dept and dept != department_filter:
                    continue

                employees.append(Employee(name=name, perf=perf, pot=pot, department=dept))
            except (ValueError, KeyError) as e:
                raise ValueError(f'CSV 第 {row_num} 行解析失败：{e}') from e

    _check_duplicates(employees)
    return employees


def _detect_columns(fieldnames: List[str]) -> Dict[str, str]:
    """自动检测列名映射。"""
    field_lower = {f.lower().strip(): f for f in fieldnames}
    mapping = {}

    name_candidates = ['姓名', '名字', 'name', '员工', '人员', '姓名/名字']
    perf_candidates = ['绩效评分', '绩效', 'performance', 'perf', '绩效得分', '绩效分']
    pot_candidates = ['潜力评分', '潜力', 'potential', 'pot', '潜力得分', '潜力分']
    dept_candidates = ['部门', 'department', 'dept', '组织', '团队']

    for candidates, key in [(name_candidates, 'name'), (perf_candidates, 'perf'),
                              (pot_candidates, 'pot'), (dept_candidates, 'dept')]:
        for cand in candidates:
            if cand in field_lower:
                mapping[key] = field_lower[cand]
                break
        if key not in mapping and key != 'dept':
            raise ValueError(
                f"CSV 缺少必要列。需要包含姓名/绩效/潜力相关列，当前列名：{fieldnames}\n"
                f"正确格式示例：姓名,绩效评分,潜力评分"
            )

    return mapping


def _check_duplicates(employees: List[Employee]):
    seen = {}
    for i, emp in enumerate(employees):
        if emp.name in seen:
            del employees[seen[emp.name]]
            print(f"[警告] 姓名「{emp.name}」重复，已保留最后一条记录", file=sys.stderr)
        seen[emp.name] = i


# ═══════════════════════════════════════════════════════════════
# 命令行入口
# ═══════════════════════════════════════════════════════════════

def parse_args():
    parser = argparse.ArgumentParser(
        description='人才九宫格可视化生成器 v1.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''示例：
  python 9box_generator.py --csv talents.csv --output grid.svg
  python 9box_generator.py --csv talents.csv --output grid.html --format html
  python 9box_generator.py --names "张三 李四" --perf "4.2 2.5" --pot "3.8 4.1" --output grid.svg
  python 9box_generator.py --csv talents.csv --output grid.svg --perf-cut 2.0,3.5 --pot-cut 2.5,4.0
        ''',
    )
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('--csv', help='CSV 文件路径')
    input_group.add_argument('--names', help='空格分隔的姓名列表，如 "张三 李四 王五"')

    parser.add_argument('--perf', help='空格分隔的绩效分列表，与 --names 配合使用')
    parser.add_argument('--pot', help='空格分隔的潜力分列表，与 --names 配合使用')
    parser.add_argument('--output', default='grid.svg', help='输出文件路径（默认 grid.svg）')
    parser.add_argument('--format', choices=['svg', 'html'], default='svg', help='输出格式 svg 或 html（默认 svg）')
    parser.add_argument('--perf-cut', default='2.5,3.5', help='绩效切分点，逗号分隔，如 "2.5,3.5"')
    parser.add_argument('--pot-cut', default='2.5,3.5', help='潜力切分点，逗号分隔，如 "2.5,3.5"')
    parser.add_argument('--title', default='人才九宫格', help='图表标题')
    parser.add_argument('--filter-department', default=None, help='按部门筛选')
    parser.add_argument('--stats', default=None, help='导出统计 CSV 文件路径')

    return parser.parse_args()


def main():
    args = parse_args()

    # 解析切分点
    try:
        perf_low, perf_high = map(float, args.perf_cut.split(','))
        pot_low, pot_high = map(float, args.pot_cut.split(','))
    except ValueError:
        print('错误：切分点格式不正确，应为数字逗号分隔，如 "2.5,3.5"', file=sys.stderr)
        sys.exit(1)

    if not (1.0 <= perf_low < perf_high <= 5.0):
        print(f'警告：绩效切分点不合理 (低={perf_low} 高={perf_high})，建议低 < 高且在 1.0-5.0 之间', file=sys.stderr)

    cfg = GridConfig(perf_low=perf_low, perf_high=perf_high, pot_low=pot_low, pot_high=pot_high)

    # 数据输入
    if args.csv:
        employees = parse_csv(args.csv, department_filter=args.filter_department)
    else:
        names = args.names.split() if args.names else []
        perfs = list(map(float, args.perf.split())) if args.perf else []
        pots = list(map(float, args.pot.split())) if args.pot else []

        if not (len(names) == len(perfs) == len(pots)):
            print(f'错误：姓名({len(names)})、绩效({len(perfs)})、潜力({len(pots)})数量不一致', file=sys.stderr)
            sys.exit(1)

        employees = [Employee(name=n, perf=p, pot=t) for n, p, t in zip(names, perfs, pots)]

    if len(employees) > 50:
        print(f'提示：共 {len(employees)} 人，SVG 可能较密集，建议使用 --format html', file=sys.stderr)

    # 分类
    grid = classify_employees(employees, cfg)

    # 生成
    subtitle = f'绩效阈值 ≤{perf_low} 低 / {perf_low+0.1:.1f}-{perf_high-0.1:.1f} 中 / ≥{perf_high} 高 · 共{len(employees)}人'
    if args.format == 'svg':
        gen = SVGGenerator(cfg)
        output = gen.generate(grid, title=args.title, subtitle=subtitle)
    else:
        gen = HTMLGenerator(cfg)
        output = gen.generate(grid, title=args.title, subtitle=subtitle)

    # 写入输出文件
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(output)

    # 统计
    print(f'✅ 已生成 {args.format.upper()} 文件：{os.path.abspath(args.output)}')
    print(f'   共 {len(employees)} 人，分布于 {sum(1 for v in grid.values() if v)} 个格子')
    green_count = sum(len(v) for (c, r), v in grid.items() if CELL_DEFS[(c, r)][1] == 'green')
    yellow_count = sum(len(v) for (c, r), v in grid.items() if CELL_DEFS[(c, r)][1] == 'yellow')
    red_count = sum(len(v) for (c, r), v in grid.items() if CELL_DEFS[(c, r)][1] == 'red')
    print(f'   🟢 绿区 {green_count}人  🟡 黄区 {yellow_count}人  🔴 红区 {red_count}人')

    # 导出统计 CSV
    if args.stats:
        _export_stats(grid, args.stats)
        print(f'   📊 统计表已导出：{os.path.abspath(args.stats)}')


def _export_stats(grid: Dict[Tuple[int, int], List[Employee]], filepath: str):
    with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['格位(潜力列×绩效行)', '分区', '标签', '人数', '占总人数%', '姓名列表'])
        total = sum(len(v) for v in grid.values())
        for col in (1, 2, 3):
            for row in (1, 2, 3):
                emps = grid.get((col, row), [])
                label, zone, _ = CELL_DEFS[(col, row)]
                pct = f"{len(emps)/total*100:.1f}%" if total > 0 else "0%"
                name_list = '、'.join(e.name for e in emps)
                writer.writerow([f'({col},{row})', zone, label, len(emps), pct, name_list])


if __name__ == '__main__':
    main()
