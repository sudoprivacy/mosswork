---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: 5c0fa478708bf2c9ec3bd0adf95ae3f0_6414bb5e908111f18e22525400f8a581
    ReservedCode1: u5dwqVL5dp4fazFnFxQdMrNcb48zBE6W6j/h6ToNyM67LP2YFa9WCO/+d/yzsTJ5qNwHMQQ+UOpR23GTK9VkHpuJce2cl0kZQ1zCWhjH9pSkxjg3CtzvwaoEhvkUoTUpD9PQRmp/G8K6B7mksb7QycHFttih/3ED/0RM75WWLlTvbcdvnDWWG2yHqZQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: 5c0fa478708bf2c9ec3bd0adf95ae3f0_6414bb5e908111f18e22525400f8a581
    ReservedCode2: u5dwqVL5dp4fazFnFxQdMrNcb48zBE6W6j/h6ToNyM67LP2YFa9WCO/+d/yzsTJ5qNwHMQQ+UOpR23GTK9VkHpuJce2cl0kZQ1zCWhjH9pSkxjg3CtzvwaoEhvkUoTUpD9PQRmp/G8K6B7mksb7QycHFttih/3ED/0RM75WWLlTvbcdvnDWWG2yHqZQ=
---

# EXTEND.md — 人才九宫格可视化生成器 v1.0

## §D 完整示例

### 示例一：批量 CSV 生成

**输入 CSV（talents.csv）**：
```csv
姓名,绩效评分,潜力评分
赵一,4.5,4.2
钱二,3.8,2.5
孙三,2.2,4.0
李四,3.0,3.2
周五,1.8,1.5
吴六,4.0,3.8
郑七,2.8,4.5
王八,3.5,2.0
冯九,4.8,4.8
陈十,2.5,3.0
```

**命令**：
```bash
python 9box_generator.py --csv talents.csv --output talents_grid.svg
```

**生成的 SVG**：

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 780 780" width="100%" height="100%">
  <defs>
    <style>
      text { font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif; }
      .title { font-size: 20px; font-weight: bold; fill: #1a1a1a; }
      .col-label { font-size: 14px; font-weight: bold; fill: #555; text-anchor: middle; }
      .row-label { font-size: 14px; font-weight: bold; fill: #555; }
      .zone-label { font-size: 13px; font-weight: bold; text-anchor: middle; }
      .zone-sub { font-size: 11px; fill: #666; text-anchor: middle; }
      .dot-label { font-size: 11px; fill: #333; text-anchor: middle; }
      .border { stroke: #bbb; stroke-width: 2; fill: none; }
      .grid-line { stroke: #ddd; stroke-width: 1; }

      /* hover 效果 */
      .employee-dot { cursor: pointer; }
      .employee-dot:hover circle { stroke: #333; stroke-width: 3; }
      .employee-dot:hover text { font-weight: bold; fill: #000; }
      .tooltip { visibility: hidden; }
      .employee-dot:hover .tooltip { visibility: visible; }

      /* 动画 */
      @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
      }
      .star-dot { animation: pulse 2s ease-in-out infinite; }
    </style>
  </defs>

  <!-- 背景 -->
  <rect width="780" height="780" fill="#ffffff" rx="10"/>

  <!-- 标题 -->
  <text x="390" y="38" class="title" text-anchor="middle">人才九宫格 · 2026年Q2人才盘点</text>
  <text x="390" y="58" font-size="12" fill="#888" text-anchor="middle">绩效阈值 ≤2.5 低 / 2.6-3.5 中 / ≥3.6 高 · 共10人</text>

  <!-- ==================== 列标签 ==================== -->
  <text x="180" y="88" class="col-label">低</text>
  <text x="180" y="103" class="col-label">潜力</text>
  <text x="390" y="88" class="col-label">中</text>
  <text x="390" y="103" class="col-label">潜力</text>
  <text x="600" y="88" class="col-label">高</text>
  <text x="600" y="103" class="col-label">潜力</text>

  <!-- ==================== 行标签 ==================== -->
  <text x="38" y="260" font-size="14" font-weight="bold" fill="#555">高绩效</text>
  <text x="38" y="460" font-size="14" font-weight="bold" fill="#555">中绩效</text>
  <text x="38" y="660" font-size="14" font-weight="bold" fill="#555">低绩效</text>

  <!-- ==================== 九格背景 ==================== -->
  <!-- 高绩效行 (y: 115-315) -->
  <!-- 格(1,3) 低潜高绩 → 🟡 -->
  <rect x="70" y="115" width="200" height="200" fill="#FFF9C4" rx="4"/>
  <!-- 格(2,3) 中潜高绩 → 🟡 -->
  <rect x="280" y="115" width="200" height="200" fill="#FFF9C4" rx="4"/>
  <!-- 格(3,3) 高潜高绩 → 🟢 -->
  <rect x="490" y="115" width="200" height="200" fill="#C8E6C9" rx="4"/>

  <!-- 中绩效行 (y: 325-525) -->
  <!-- 格(1,2) 低潜中绩 → 🔴 -->
  <rect x="70" y="325" width="200" height="200" fill="#FFCDD2" rx="4"/>
  <!-- 格(2,2) 中潜中绩 → 🟡 -->
  <rect x="280" y="325" width="200" height="200" fill="#FFF9C4" rx="4"/>
  <!-- 格(3,2) 高潜中绩 → 🟢 -->
  <rect x="490" y="325" width="200" height="200" fill="#C8E6C9" rx="4"/>

  <!-- 低绩效行 (y: 535-735) -->
  <!-- 格(1,1) 低潜低绩 → 🔴 -->
  <rect x="70" y="535" width="200" height="200" fill="#FFCDD2" rx="4"/>
  <!-- 格(2,1) 低潜中绩 → 🔴 -->
  <rect x="280" y="535" width="200" height="200" fill="#FFCDD2" rx="4"/>
  <!-- 格(3,1) 高潜低绩 → 🟡 -->
  <rect x="490" y="535" width="200" height="200" fill="#FFF9C4" rx="4"/>

  <!-- ==================== 格位文字标签 ==================== -->
  <!-- 高绩效行 -->
  <text x="170" y="210" class="zone-label" fill="#F57C00">专家型</text>
  <text x="170" y="230" class="zone-sub">精深发展 · 保留技能</text>

  <text x="380" y="210" class="zone-label" fill="#F57C00">业务骨干</text>
  <text x="380" y="230" class="zone-sub">稳定激励 · 拓宽视野</text>

  <text x="590" y="210" class="zone-label" fill="#2E7D32">✦ 明星人才</text>
  <text x="590" y="230" class="zone-sub">重点保留 · 加速晋升</text>

  <!-- 中绩效行 -->
  <text x="170" y="420" class="zone-label" fill="#C62828">稳定贡献</text>
  <text x="170" y="440" class="zone-sub">维持现状 · 适量投资</text>

  <text x="380" y="420" class="zone-label" fill="#F57C00">中坚力量</text>
  <text x="380" y="440" class="zone-sub">稳步发展 · 能力提升</text>

  <text x="590" y="420" class="zone-label" fill="#2E7D32">核心人才</text>
  <text x="590" y="440" class="zone-sub">加大挑战 · 关注成长</text>

  <!-- 低绩效行 -->
  <text x="170" y="630" class="zone-label" fill="#C62828">问题员工</text>
  <text x="170" y="650" class="zone-sub">限期改进 · 考虑优化</text>

  <text x="380" y="630" class="zone-label" fill="#C62828">待观察</text>
  <text x="380" y="650" class="zone-sub">绩效改进 · 关注适配</text>

  <text x="590" y="630" class="zone-label" fill="#F57C00">潜力股</text>
  <text x="590" y="650" class="zone-sub">诊断根因 · 岗位匹配</text>

  <!-- ==================== 员工数据点 ==================== -->
  <!-- 赵一: 绩4.5 潜4.2 → 格(3,3) 高潜高绩 -->
  <g class="employee-dot" transform="translate(590, 280)">
    <circle cx="0" cy="0" r="8" fill="#1B5E20" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">赵一 | 绩4.5 潜4.2</text>
    <text class="tooltip" x="0" y="-14" fill="#A5D6A7" font-size="10" text-anchor="middle">明星人才 · 加速晋升</text>
  </g>

  <!-- 吴六: 绩4.0 潜3.8 → 格(3,3) 高潜高绩 -->
  <g class="employee-dot" transform="translate(620, 298)">
    <circle cx="0" cy="0" r="8" fill="#1B5E20" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">吴六 | 绩4.0 潜3.8</text>
    <text class="tooltip" x="0" y="-14" fill="#A5D6A7" font-size="10" text-anchor="middle">核心人才 · 加大挑战</text>
  </g>

  <!-- 冯九: 绩4.8 潜4.8 → 格(3,3) 明星中的明星 -->
  <g class="employee-dot star-dot" transform="translate(560, 265)">
    <circle cx="0" cy="0" r="10" fill="#FFD600" stroke="#1B5E20" stroke-width="2.5"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">冯九 | 绩4.8 潜4.8</text>
    <text class="tooltip" x="0" y="-14" fill="#FFD600" font-size="10" text-anchor="middle">明星人才 · 加速晋升</text>
  </g>

  <!-- 钱二: 绩3.8 潜2.5 → 格(1,3) 低潜高绩 -->
  <g class="employee-dot" transform="translate(170, 260)">
    <circle cx="0" cy="0" r="8" fill="#E65100" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">钱二 | 绩3.8 潜2.5</text>
    <text class="tooltip" x="0" y="-14" fill="#FFE0B2" font-size="10" text-anchor="middle">专家型 · 保留技能</text>
  </g>

  <!-- 孙三: 绩2.2 潜4.0 → 格(3,1) 高潜低绩 -->
  <g class="employee-dot" transform="translate(590, 650)">
    <circle cx="0" cy="0" r="8" fill="#E65100" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">孙三 | 绩2.2 潜4.0</text>
    <text class="tooltip" x="0" y="-14" fill="#FFE0B2" font-size="10" text-anchor="middle">潜力股 · 诊断根因</text>
  </g>

  <!-- 郑七: 绩2.8 潜4.5 → 格(3,1) 高潜低绩 -->
  <g class="employee-dot" transform="translate(620, 668)">
    <circle cx="0" cy="0" r="8" fill="#E65100" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">郑七 | 绩2.8 潜4.5</text>
    <text class="tooltip" x="0" y="-14" fill="#FFE0B2" font-size="10" text-anchor="middle">潜力股 · 诊断根因</text>
  </g>

  <!-- 李四: 绩3.0 潜3.2 → 格(2,2) 中潜中绩 -->
  <g class="employee-dot" transform="translate(380, 460)">
    <circle cx="0" cy="0" r="8" fill="#F57C00" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">李四 | 绩3.0 潜3.2</text>
    <text class="tooltip" x="0" y="-14" fill="#FFF9C4" font-size="10" text-anchor="middle">中坚力量 · 稳步发展</text>
  </g>

  <!-- 陈十: 绩2.5 潜3.0 → 格(2,1) 低潜中绩 -->
  <g class="employee-dot" transform="translate(380, 650)">
    <circle cx="0" cy="0" r="8" fill="#C62828" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">陈十 | 绩2.5 潜3.0</text>
    <text class="tooltip" x="0" y="-14" fill="#FFCDD2" font-size="10" text-anchor="middle">待观察 · 绩效改进</text>
  </g>

  <!-- 周五: 绩1.8 潜1.5 → 格(1,1) 低潜低绩 -->
  <g class="employee-dot" transform="translate(170, 650)">
    <circle cx="0" cy="0" r="8" fill="#C62828" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">周五 | 绩1.8 潜1.5</text>
    <text class="tooltip" x="0" y="-14" fill="#FFCDD2" font-size="10" text-anchor="middle">问题员工 · 限期改进</text>
  </g>

  <!-- 王八: 绩3.5 潜2.0 → 格(1,2) 低潜中绩 -->
  <g class="employee-dot" transform="translate(170, 460)">
    <circle cx="0" cy="0" r="8" fill="#C62828" stroke="#fff" stroke-width="2"/>
    <rect class="tooltip" x="-55" y="-42" width="110" height="38" rx="5" fill="#333" opacity="0.9"/>
    <text class="tooltip" x="0" y="-28" fill="#fff" font-size="11" text-anchor="middle">王八 | 绩3.5 潜2.0</text>
    <text class="tooltip" x="0" y="-14" fill="#FFCDD2" font-size="10" text-anchor="middle">稳定贡献 · 维持现状</text>
  </g>

  <!-- ==================== 图例 ==================== -->
  <rect x="600" y="30" width="14" height="14" rx="2" fill="#C8E6C9" stroke="#bbb"/>
  <text x="620" y="42" font-size="11" fill="#555">绿区·优先投资</text>
  <rect x="600" y="50" width="14" height="14" rx="2" fill="#FFF9C4" stroke="#bbb"/>
  <text x="620" y="62" font-size="11" fill="#555">黄区·关注发展</text>
  <rect x="600" y="70" width="14" height="14" rx="2" fill="#FFCDD2" stroke="#bbb"/>
  <text x="620" y="82" font-size="11" fill="#555">红区·限期改进</text>
</svg>
```

### 示例二：单条手输（无脚本，内联 SVG）

**用户输入**：`张三 绩效4.2 潜力3.8`

**Skill 响应**：生成简化版九宫格 SVG，只标注张三一人（高绩中潜 → 业务骨干格），其他格为空。适合快速定位单人。

### 示例三：HTML 交互版

**命令**：`python 9box_generator.py --csv talents.csv --output grid.html --format html`

**效果**：生成完整 HTML 页面，包含：
- CSS Grid 布局的九宫格
- 每个员工为定位气泡，hover 弹出更丰富的详情卡片（含雷达图缩略图）
- 右侧面板：按格统计人数、高潜人才列表、红区关注列表
- 适合校准会投屏演示

## §E 九格人才建议详解

### 🟢 绿区（优先投资）

| 格位 | 建议动作 | 具体措施 | 时间窗口 |
|------|---------|---------|---------|
| (3,3) 明星人才 | 重点保留 + 加速晋升 | ① 安排导师（Mentor）而非教练（Coach）② 给予跨部门曝光机会 ③ 薪资对标市场 75 分位以上 ④ 设计 12-18 个月的晋升路径 | 立即行动 |
| (3,2) 核心人才 | 加大挑战 + 关注成长 | ① 给独立负责项目的权限 ② 半年内安排轮岗或跨职能项目 ③ 关注绩效是否被低估（可能是潜力未充分转化为绩效） | 本季度内 |

### 🟡 黄区（关注发展）

| 格位 | 建议动作 | 具体措施 | 时间窗口 |
|------|---------|---------|---------|
| (2,3) 业务骨干 | 稳定激励 + 拓宽视野 | ① 避免倦怠：调整重复性工作比例 ② 给横向项目或 mentor 新人 ③ 短期激励（项目奖金）而非长期画饼 | 半年内 |
| (2,2) 中坚力量 | 稳步发展 + 能力提升 | ① 找 1-2 个可量化的能力提升目标 ② 配一个强项互补的 peer 结对学习 ③ 关注是否被低估（可能是评分偏保守） | 年度规划 |
| (1,3) 专家型 | 精深发展 + 保留技能 | ① 不强行推管理路线 ② 设立技术/专业序列晋升通道 ③ 保护其专注时间，减少管理类打扰 | 持续 |
| (3,1) 潜力股 | 诊断根因 + 岗位匹配 | ① 绩效低的根因：人岗错配？资源不足？管理问题？② 尝试换岗或换 leader ③ 3 个月观察期 | 本季度内 |

### 🔴 红区（限期改进）

| 格位 | 建议动作 | 具体措施 | 时间窗口 |
|------|---------|---------|---------|
| (1,2) 稳定贡献 | 维持现状 + 适量投资 | ① 不做主要资源倾斜 ② 确保其职责范围内的交付稳定 ③ 如有流失风险，评估替代成本 | 按需 |
| (2,1) 待观察 | 绩效改进 + 关注适配 | ① 正式 PIP（绩效改进计划）② 明确可量化的改进目标和时限 ③ 指定 mentor 跟进 | 3 个月 |
| (1,1) 问题员工 | 限期改进或优化 | ① 先诊断后行动 ② 如果是人岗错配优先尝试调岗 ③ 如为能力/态度问题，启动优化流程 | 1-3 个月 |

## §F 脚本扩展能力

9box_generator.py 支持的额外功能（EXTEND 中详细说明调用方式）：

| 功能 | 参数 | 说明 |
|------|------|------|
| 按部门筛选 | `--filter-department "技术部"` | CSV 需要有"部门"列 |
| 对比两次盘点 | `--compare grid_2026Q1.svg` | 输出两次盘点的并排对比图 |
| 自定义颜色 | `--green "#A5D6A7" --yellow "#FFE082" --red "#EF9A9A"` | 适配企业品牌色 |
| 导出统计表 | `--stats stats.csv` | 输出每格人数、百分比、名单的 CSV |
| 比例标注 | `--show-percent` | 在每格显示占总人数百分比 |

## §G 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-08-05 | 首次发布。CSV/命令行双输入模式、SVG/HTML 双格式输出、hover 交互（姓名+分数+建议标签）、可配置绩效/潜力切分阈值、同格错位排列、九格人才建议动作库、内联 SVG 轻量模式 |
*（内容由AI生成，仅供参考）*
