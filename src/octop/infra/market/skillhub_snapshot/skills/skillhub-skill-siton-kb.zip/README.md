# dify-kb-qa

当前版本：**v1.0.0（人力资源部门）**

基于 Dify **工作流应用**的检索问答 skill。它只做一件事：**从 Dify 知识库检索相关片段，交给运行本 skill 的助手基于片段回答，并附文档引用**。不调用 Dify 的对话/LLM 接口，不需要在 Dify 里配置大模型。

每次检索都是一次真实的工作流运行；运维可在 Dify → 该应用 → 「日志与标注」追溯输入、召回片段、耗时和提问人。

按**单知识库模式**使用：检索哪个库由工作流里的「知识库检索」节点决定，skill 不列库、不切库。

```
用户问题
   │
   ▼
[助手] 改写为独立检索问题（多轮时结合当前会话上下文）
   │
   ▼
[kb.cjs search] POST /v1/workflows/run（blocking）
   │
   ▼
[Dify 工作流] 开始 → 知识库检索 → 结束(result)
   │            └── 运行记录写入「日志与标注」
   ▼
[助手] 仅基于片段作答 + 引用列表 + 来源说明
```

## 前置条件

- Node.js >= 18（使用内置 `fetch`，零依赖）
- 一个 Dify **Workflow 应用**，结构为：`开始(query) → 知识库检索(目标库) → 结束(result)`
- 该应用的 **API Key**（`app-` 开头，在应用 → 访问 API 页创建）
- Key 只保存在各自机器的 `~/.config/dify-kb-qa/config.json`，不随 skill 包分发

### 在 Dify 里创建工作流（一次性）

1. 工作室 → 创建应用 → 创建空白应用 → 选 **工作流**。
2. 开始节点保留一个输入变量 `query`（文本）。
3. 加入「知识库检索」节点：查询变量引用 `开始/query`，选择目标知识库，设置 Top K / 检索方式。
4. 结束节点添加输出变量 `result`，值选「知识库检索/result」。
5. 发布，然后 **访问 API → API 密钥 → 创建密钥**，得到 `app-...`。

换个知识库只需改工作流里的检索节点并重新发布，skill 配置不用动。

## 配置（首次使用）

第一次提问时，skill 会先检查本机是否已有 Key。没有的话会直接请你在**对话里粘贴应用 Key**，然后在后台调用 `/info` 与 `/parameters` 校验，并保存到 `~/.config/dify-kb-qa/config.json`（权限 600）——不需要你执行任何命令。

实例地址、来源说明与工作流变量名写在 skill 的 `config.defaults.json`（非密钥），所以用户只需要提供 Key。

开发者也可以在终端手动配置：

```bash
node scripts/kb.cjs setup                      # 交互式，输入不回显
node scripts/kb.cjs setup --api-key "app-xxxxxxxx"
node scripts/kb.cjs setup --force              # 已存在凭证时覆盖
```

检查本机凭证：

```bash
node scripts/kb.cjs auth           # 只查本地文件，不联网
node scripts/kb.cjs auth --check   # 联网校验应用、类型与输入变量
```

优先级：命令行 `--api-key` / `--base-url` > 环境变量 `DIFY_API_KEY` / `DIFY_BASE_URL` > 用户配置文件 > skill 内 `config.defaults.json`。

配置文件示例：

```json
{
  "base_url": "http://your-dify-host/v1",
  "api_key": "app-xxxxxxxx",
  "default_kb": "人事部门知识库",
  "source_note": "知识库内文件来自钉盘-人力行政部共享文件，文件获取日期：2026-10-30",
  "workflow": {
    "input_var": "query",
    "output_var": "result"
  }
}
```

## 快速开始

```bash
cd /path/to/dify-kb-qa        # 换成实际安装目录

# 0. 首次使用：检查/写入本机 Key
node scripts/kb.cjs auth
node scripts/kb.cjs setup

# 1. 自检：Node 版本、凭证、应用类型、输入变量
node scripts/kb.cjs doctor

# 2. 检索（单库，无需 --kb；Top K 等参数在 Dify 节点里设置）
node scripts/kb.cjs search --query "年假有几天"
```

`search` 常用参数：

| 参数 | 说明 |
| --- | --- |
| `--query "..."` | 检索问题，≤32768 字符（与工作流输入变量一致） |
| `--json` | 调试用：输出解析后的 `records`（含 `workflow_run_id`） |
| `--timeout 60000` | 请求超时（毫秒，工作流默认 60 秒） |

返回的片段**始终完整输出，不截断**。需要在 Dify 日志里精确定位某次请求时，用 `--json` 取 `workflow_run_id`。

完整接口字段、错误码与限流规则见 [`references/api.md`](references/api.md)。

## 运维：查看检索日志

**位置：Dify → 目标工作流应用 → 日志与标注。**（仅运维排查使用，不需要告知终端用户）

每条记录包含：

- 输入 `query`（用户问题）
- 输出 `result`（召回片段、文档名与分数）
- 运行状态、耗时、时间
- `user`：提问者标识，skill 默认取本机用户名（`os.userInfo().username`）

点开单次运行还能看到每个节点的执行详情。知识库的 Service API（`/datasets/{id}/retrieve`）不会在这里显示——因此本 skill 不使用该接口。

需要区分同事时，可给每人单独创建一个应用 API Key（在「访问 API」页可建多个），或在配置文件的 `workflow.user` 里写固定标识。

## 安装

把整个 `dify-kb-qa` 目录放进所用 Agent 运行环境的技能目录，或通过其技能市场导入打包后的 zip。技能目录的具体位置由运行环境决定；本目录无需改动即可复用。

安装后新开一个会话，说“帮我查一下知识库里有没有…”，skill 会被自动发现并触发。对软链方式，修改本目录内容会立即生效。

## 在 WorkBuddy 中使用

WorkBuddy 兼容 OpenClaw 技能结构，本 skill 无需改代码：

```bash
# 方式一：本机自用，直接放进 WorkBuddy 技能目录
cp -r /path/to/dify-kb-qa ~/.workbuddy/skills/

# 方式二：打包后通过技能市场导入/上传
python3 "/Applications/WorkBuddy.app/Contents/Resources/app.asar.unpacked/resources/plugins/workbuddy-builtin/skills/skill-creator/scripts/package_skill.py" \
  ~/Desktop/dify-kb-qa ~/Desktop/dist
```

注意：

- zip 内必须是 `dify-kb-qa/SKILL.md` 顶层目录结构，不能把文件直接放在 zip 根目录。
- 配置和 API Key 不在包内；每位同事首次使用时 skill 会直接在对话里询问 Key，并在后台校验保存，无需执行命令。
- 检索是否出现在 Dify 日志，与运行 skill 的机器无关：只要请求到了你们的 Dify 实例，就会记录。

> 与 `ima-skill` 的边界：本 skill 只面向 **Dify** 知识库；IMA 知识库/笔记仍走 `ima-skill`。

## 安全说明

- API Key 只以 `Authorization` Header 发送到配置的 `base_url`。
- Key 保存在本机 `~/.config/dify-kb-qa/config.json`，权限 600；不要把该文件提交到仓库或分享给他人。
- Key 不会出现在 stdout、错误信息或 `setup`/`doctor` 的输出中（只显示掩码）。
- 如果 Key 曾粘贴到聊天/群聊，建议在 Dify 控制台重新生成并执行 `setup --force`。

## 目录结构

```
dify-kb-qa/
├── SKILL.md              # skill 定义：全局规则、决策表、RAG 工作流
├── README.md
├── meta.json             # 版本与运行时依赖
├── config.defaults.json  # 实例地址、知识库显示名、来源说明、工作流变量（非密钥）
├── scripts/
│   └── kb.cjs            # auth / setup / doctor / search
└── references/
    └── api.md            # /workflows/run 契约、错误与限流
```

## 已知限制

- 只读：不支持上传/修改/删除知识库文档。
- 单库：检索哪个库由工作流节点决定；更换知识库需要在 Dify 里改节点并重新发布。
- 检索参数（Top K、检索方式、阈值、重排序）只能在 Dify 工作流里调整，skill 不提供命令行覆盖。
- 答案由运行 skill 的助手生成，质量取决于检索片段与模型；检索不到的结论必须显式说明。
- 依赖工作流应用的 API 可用性；应用被删除或 Key 被吊销时，需要重新创建并 `setup --force`。
