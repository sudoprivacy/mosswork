---
name: skillhub-skill-siton-kb
description: "# dify-kb-qa"
---

# dify-kb-qa

通过 Dify **工作流应用**检索知识库片段，由运行本 skill 的助手基于片段生成答案。本 skill 只做检索；答案、引用和追问改写都在当前会话内完成。

本 skill 为**单知识库模式**：检索哪个库由工作流里的「知识库检索」节点决定，skill 不列库、不切库。

以下命令中 `$SKILL_DIR` 表示本 skill 的绝对路径，由安装位置决定。在每个 shell 会话里先设置一次：

```bash
export SKILL_DIR="/path/to/dify-kb-qa"
```

## ⛔ 全局规则 — 执行任何操作前阅读

1. **凭证与请求边界：** 应用 API Key 只发送到用户配置的 `base_url`；不得把完整 Key 写入回答或任何文件，也不得发往其他地址。用户在对话中提供 Key 后，立即用 `setup` 校验并保存，不要复述 Key。
2. **失败即停：** 检索失败（401/403/404/网络错误，或工作流 `status≠succeeded`）时不得继续回答，不得用模型自身知识冒充知识库内容；按错误表说明原因。
3. **答案必须基于片段：** 只使用本次检索返回的片段作答。片段不足以回答时，明确说“没有找到相关内容”，可建议换个问法。
4. **query 长度：** 上限 32768 字符（与工作流输入变量的 max_length 一致）；多轮追问必须先把上下文结合进去，改写成独立、自包含的检索问题（去掉“它/这个/那上面说的”这类指代），再调用检索。
5. **引用必须可核对：** 每次回答末尾列出实际使用的片段来源（文档名 + score + segment id）；没有用到的片段不要列。
6. **单库边界：** 不询问“用哪个知识库”，不尝试切换知识库，不把其他库内容混入回答。用户点名其他库时，说明当前只配置了一个库，如需调整请联系管理员。
7. **检索参数不在 skill 侧：** 不要向 `search` 传 `--top-k`/`--method`/`--min-score`。

## Credential Check — 每次检索前

```bash
node "$SKILL_DIR/scripts/kb.cjs" auth
```

- 退出码 0（`AUTH OK`）：本机已有 Key，直接进入工作流。
- `AUTH MISSING`：本机没有 Key → 走「首次使用：在对话中配置 Key」。
- `AUTH INVALID`：Key 失效或应用/变量不匹配，按错误表处理，不要带着失效凭证继续检索。
- 需要联网确认：`node "$SKILL_DIR/scripts/kb.cjs" auth --check`。

### 首次使用：在对话中配置 Key

每位同事的 Key 只保存在**自己的机器**：`~/.config/dify-kb-qa/config.json`（权限 600），不随 skill 包分发。实例地址、来源说明与工作流变量名已写在 `config.defaults.json` 里，用户只需提供 Key，**不需要执行任何命令**。

1. `auth` 返回 `AUTH MISSING` 时，直接对用户说：
   “首次使用需要配置知识库 Key。请把管理员提供的 Dify 应用 API Key（`app-` 开头）直接发给我，我会在后台校验并保存到你本机，不会写进回答。”
2. 收到 Key 后立即在后台运行：
   `node "$SKILL_DIR/scripts/kb.cjs" setup --api-key '<Key>'`（已有 Key 需覆盖时加 `--force`）
   不要复述、回显或让用户再次确认 Key。
3. 若用户给的是 `dataset-` 开头的 Key，说明拿错了：本 skill 只接受管理员提供的应用 Key（`app-`），请不要使用知识库 Key。
4. `setup` 会先联网校验应用类型与输入变量，成功才写入；失败时按错误表说明原因并请其提供有效 Key，不要继续检索。
5. 成功后运行 `auth` 确认 `AUTH OK`，用掩码形式告知“已保存并验证通过（Key app-…）”，然后回答用户最初的问题。
6. 绝不在回答或 skill 目录中保存完整 Key；`setup` 输出只显示掩码。

配置优先级：命令行 `--api-key`/`--base-url` > 环境变量 `DIFY_API_KEY`/`DIFY_BASE_URL` > `~/.config/dify-kb-qa/config.json` > skill 内 `config.defaults.json`（仅实例地址与变量名，非密钥）。

单库配置文件结构（由 `setup` 自动生成）：

```json
{
  "base_url": "http://<dify-instance>/v1",
  "api_key": "app-xxxxxxxx",
  "default_kb": "人事部门知识库",
  "source_note": "知识库内文件来自钉盘-人力行政部共享文件，文件获取日期：2026-10-30",
  "workflow": {
    "input_var": "query",
    "output_var": "result"
  }
}
```

- `api_key` 必须是**应用 API Key**（以 `app-` 开头），不是知识库 Key。
- `input_var` 是工作流开始节点的变量名，`output_var` 是结束节点的输出变量名；`setup` 会自动探测输入变量。

## RAG 问答工作流

### Step 0 — 检索范围

检索范围由工作流决定，skill 不列库、不切库。回答中不提知识库名称；用户点名其他知识库时，说明当前检索范围由管理员配置。

### Step 1 — 改写检索问题

结合当前会话上下文把用户这句改写成独立问题：补全指代、保留关键实体与限定词，控制在 32768 字符内（远小于此即可，关键是聚焦）。不要加入上下文中不存在的假设。

### Step 2 — 检索片段

```bash
node "$SKILL_DIR/scripts/kb.cjs" search --query "<改写后的问题>"
```

- 不要传 `--top-k` / `--method` / `--min-score` / `--kb`：这些由 Dify 检索节点决定。
- 0 条结果或明显不相关：**最多再试一次**——换更宽的关键词、减少限定后重试；仍无结果则按全局规则如实告知，不要编造。
- 片段始终完整输出，不截断。

### Step 3 — 基于片段回答

- 只使用检索到的片段；不同片段冲突时指出冲突，不做臆断。
- 回答中可以用 `[1]` `[2]` 标注依据，末尾统一列引用。
- 片段没覆盖的部分直接说“没有找到相关信息”，不要补外部知识。
- 引用列表之后附一行来源说明：`知识库内文件来自钉盘-人力行政部共享文件，文件获取日期：2026-10-30`（取自 `source_note`，原样照抄）。

引用格式：

```markdown
引用：
[1] 《补贴管理办法.pdf》 score 0.8734（segment 5bf2bbea）
[2] 《补贴管理办法.pdf》 score 0.6398（segment 57e0a2bb）

来源说明：知识库内文件来自钉盘-人力行政部共享文件，文件获取日期：2026-10-30
```

## 常用命令速查

```bash
# 检查本机 Key
node "$SKILL_DIR/scripts/kb.cjs" auth

# 检索
node "$SKILL_DIR/scripts/kb.cjs" search --query "补贴包含哪几项"
```

## 错误处理

| 症状 | 含义 | 处理 |
| --- | --- | --- |
| HTTP 401 `unauthorized` | 应用 Key 无效/被删除，或用了知识库 Key | 请用户重新提供应用 Key，`setup --force` 更新 |
| HTTP 403 `forbidden` | 应用无权限、未发布，或触发限流 | 若是限流，**等待满 1 分钟**再试；否则告知用户检索暂不可用，请联系管理员 |
| HTTP 404 `not_found` | 应用不存在，或 base_url 指向错误实例 | 告知用户检索暂不可用，请联系管理员核对实例地址与 Key |
| HTTP 400 `invalid_param` | 输入变量名/类型不匹配 | 用 `setup --workflow-input <变量名> --force` 修正 |
| `工作流执行未成功（status=failed…）` | 工作流节点报错 | 告知用户本次检索失败，建议稍后重试；不要编造答案 |
| `工作流输出中没有变量「result」` | 结束节点输出变量名不对 | 检查结束节点，或用 `setup --workflow-output <变量名> --force` 修正 |
| `AUTH MISSING` | 本机没有 Key | 按「首次使用」向用户索取 `app-` Key |
| `AUTH INVALID` | Key 失效、应用类型不对或输入变量不匹配 | 让用户重新提供 Key，`setup --force` 后重新 `auth` |
| 网络请求失败 / 超时 | Base URL 不可达 | 核对 `DIFY_BASE_URL`（自建实例含 `/v1`），可加 `--timeout 90000` |

## 用户体验约定

- 检索前用一行说明：“正在检索知识库…”；不要输出原始 JSON，除非用户要求。
- 回答末尾附上 `source_note` 的来源说明，不提及知识库名称。
- 回答里不展示完整 UUID、Key；只展示文档名、score、必要的 segment 短 ID。
- 引用按 score 从高到低排列；低分片段（如 < 0.3）即使列出也要提示“相关性较低”。
