# Dify 接口参考（dify-kb-qa）

按需加载：SKILL.md 的常规流程不要求读本文件；排查错误或确认字段语义时再读。

依据 Dify Service API（2026-10 核对）。所有路径均在 `/v1` 下。

## 1. 认证与 Base URL

| 项 | 值 |
| --- | --- |
| Cloud | `https://api.dify.ai/v1` |
| 自建 | `<实例地址>/v1` |
| Header | `Authorization: Bearer {APP_API_KEY}` |
| Content-Type | `application/json` |

- 应用 Key 在 **应用 → 访问 API → API 密钥** 创建，以 `app-` 开头。一个应用可以创建多个 Key，便于按人分发和单独吊销。
- 知识库 Key（`dataset-`）不能调用本 skill 使用的接口；误用会得到 401/403。
- 应用必须已**发布**，否则运行接口不可用。

## 2. 检索：`POST /workflows/run`

本 skill 的唯一检索入口。工作流结构：`开始(query) → 知识库检索 → 结束(result)`。

### 请求

```json
{
  "inputs": { "query": "补贴包含哪几项" },
  "response_mode": "blocking",
  "user": "jennywang"
}
```

| 字段 | 必填 | 说明 |
| --- | --- | --- |
| `inputs` | 是 | 键为开始节点变量名；skill 从 `GET /parameters` 自动探测，默认 `query` |
| `response_mode` | 是 | `blocking` 或 `streaming`；skill 用 `blocking` |
| `user` | 是 | 终端用户标识，用于日志归因；skill 默认取本机用户名，可在配置 `workflow.user` 覆盖 |

### 响应

```json
{
  "workflow_run_id": "09927c4b-a6f3-463e-a3be-b35b3a5501f6",
  "task_id": "...",
  "data": {
    "id": "09927c4b-...",
    "status": "succeeded",
    "outputs": {
      "result": [
        {
          "content": "……片段正文……",
          "metadata": {
            "score": 0.8733747842734552,
            "document_id": "5376bff2-...",
            "document_name": "补贴管理办法.pdf",
            "segment_id": "5bf2bbea-...",
            "dataset_id": "343fdd69-...",
            "child_chunks": []
          }
        }
      ]
    },
    "error": null,
    "elapsed_time": 0.42,
    "total_tokens": 0
  }
}
```

- `status`：`succeeded` / `failed` / `stopped`；非 `succeeded` 时读 `data.error`，节点详情由运维在「日志与标注」查看。
- `outputs.<变量>` 是「结束」节点的输出；skill 默认读 `result`，可用 `--workflow-output` 改。
- 片段的 **`score` 在 `metadata.score`**，不在顶层；`document_name`、`segment_id`、`child_chunks` 同样在 `metadata` 里。
- 空结果时 `outputs.result` 为 `[]`，不是错误。
- blocking 模式服务端最长约 100 秒；skill 默认超时 60 秒（`--timeout` 可调）。

### 排障：查看节点级输出

`response_mode=streaming` 会逐节点推送 SSE 事件（`workflow_started`、`node_started`、`node_finished`、`text_chunk`、`workflow_finished`）。`node_finished` 的 `data.outputs` 是节点的原始输出，可用于确认检索节点是否返回了片段：

```bash
curl -sN -X POST '<base_url>/workflows/run' \
  -H "Authorization: Bearer $DIFY_API_KEY" -H 'Content-Type: application/json' \
  -d '{"inputs":{"query":"测试"},"response_mode":"streaming","user":"diag"}' \
  | grep node_finished
```

## 3. 应用信息

### 3.1 `GET /info`

```json
{ "name": "知识库", "description": "", "mode": "workflow", "tags": [] }
```

`mode` 必须是 `workflow`；`chat`、`agent-chat`、`advanced-chat` 等类型不能用于本 skill 的检索。

### 3.2 `GET /parameters`

返回开始节点的输入表单：

```json
{
  "user_input_form": [
    { "text-input": { "variable": "query", "label": "问题", "required": true } }
  ]
}
```

skill 用 `variable` 自动探测输入变量名；`setup` 校验变量是否存在，`doctor` 复查。

## 4. 错误与限流

错误封套：

```json
{ "code": "invalid_param", "message": "user is required", "status": 400 }
```

| 状态 | 常见 code | 含义 / 处理 |
| --- | --- | --- |
| 400 | `invalid_param` | 输入变量名/类型不匹配、缺少 `user`、工作流未正确配置输出 |
| 401 | `unauthorized` | 应用 Key 无效/被删除，或误用知识库 Key；重新生成 |
| 403 | `forbidden` | 应用未发布、无权限，或触发限流 |
| 404 | `not_found` | 应用不存在，或 base_url 指向其他实例 |
| 429 | `too_many_requests` | 请求过频，退避重试 |
| 500 | `internal_server_error` | Dify 服务端问题，稍后重试 |

- 工作流运行受实例并发与工作区配额限制；超限时返回 403/429，被拒绝的请求也可能计入配额，建议等待完整 1 分钟再试。
- 工作流内部节点报错不会变成 HTTP 错误：HTTP 200 + `data.status=failed`，原因在 `data.error`。

## 5. 日志

本 skill 的每次检索都是真实的工作流运行，Dify 会把以下内容写入 **应用 → 日志与标注**：

- 输入（`query`）、输出（`result` 片段数组）
- 状态、耗时、开始/结束时间、`user`
- 单次运行内各节点的执行详情

skill 侧不写本地请求日志，日志唯一来源就是 Dify。
