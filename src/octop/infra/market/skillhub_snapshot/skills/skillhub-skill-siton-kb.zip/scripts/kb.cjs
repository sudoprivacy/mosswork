#!/usr/bin/env node
'use strict';

/**
 * dify-kb-qa CLI — 通过 Dify 工作流检索知识库片段（不生成答案，答案由调用方基于片段生成）
 *
 * 子命令：
 *   auth [--check]              检查本机是否已有可用 Key（默认不联网）
 *   setup                       首次配置：输入 Key → 校验 → 写入 ~/.config/dify-kb-qa/config.json
 *   doctor                      检查配置、凭证与工作流连通性
 *   search --query "..."        检索相关片段（POST /workflows/run）
 *
 * 凭证优先级：
 *   --api-key / --base-url  >  环境变量 DIFY_API_KEY / DIFY_BASE_URL
 *   >  ~/.config/dify-kb-qa/config.json  >  skill 内 config.defaults.json（非密钥）
 *
 * 退出码：
 *   0  成功（doctor：全部检查通过）
 *   1  程序性错误（缺凭证、参数错误、网络失败）或 doctor 存在 FAIL 项
 *   2  未预期的内部错误
 *
 * stdout 只输出数据/结果；程序性错误以 JSON 写到 stderr：{"code":-100,"msg":"..."}
 * Dify 业务错误输出到 stderr：HTTP 状态 + code + message + 中文处理提示。
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ERR_PROGRAMMATIC = -100;
const DEFAULT_BASE_URL = 'https://api.dify.ai/v1';
const CONFIG_DIR = path.join(os.homedir(), '.config', 'dify-kb-qa');
const CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');
const DEFAULTS_FILE = path.join(__dirname, '..', 'config.defaults.json');
const QUERY_MAX = 32768; // 与 Dify 工作流开始节点输入变量的 max_length 保持一致
const BOOLEAN_FLAGS = new Set(['full', 'json', 'help', 'check', 'force']);

const CONFIG_SAMPLE = `{
  "base_url": "http://<dify-instance>/v1",
  "api_key": "app-xxxxxxxx",
  "default_kb": "补贴管理办法",
  "workflow": {
    "input_var": "query",
    "output_var": "result"
  }
}`;

class AppError extends Error {
  constructor(msg) {
    super(msg);
    this.name = 'AppError';
  }
}

// ---------------------------------------------------------------------------
// 参数与凭证
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const flags = {};
  const positionals = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--') {
      positionals.push(...argv.slice(i + 1));
      break;
    }
    if (!arg.startsWith('--')) {
      positionals.push(arg);
      continue;
    }

    const eq = arg.indexOf('=');
    let name;
    let value;
    if (eq !== -1) {
      name = arg.slice(2, eq);
      value = arg.slice(eq + 1);
    } else {
      name = arg.slice(2);
      if (BOOLEAN_FLAGS.has(name)) {
        flags[name] = true;
        continue;
      }
      value = argv[i + 1];
      if (value === undefined || value.startsWith('--')) {
        throw new AppError(`参数 --${name} 缺少取值`);
      }
      i += 1;
    }
    flags[name] = value;
  }

  return { flags, positionals };
}

function readJsonSafe(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function writeJson(filePath, data) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + '\n', { mode: 0o600 });
  try {
    fs.chmodSync(filePath, 0o600);
  } catch {
    // 某些文件系统不支持 chmod，忽略即可
  }
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
}

function normalizeBaseUrl(raw) {
  let value = String(raw || DEFAULT_BASE_URL).trim().replace(/\/+$/, '');
  if (!/\/v1$/.test(value)) value += '/v1';
  return value;
}

function loadConfig(flags) {
  const configExists = fs.existsSync(CONFIG_FILE);
  const parsed = readJsonSafe(CONFIG_FILE);
  const fileConfig = parsed || {};

  let apiKey = '';
  let apiKeySource = '';
  if (flags['api-key']) {
    apiKey = flags['api-key'];
    apiKeySource = '--api-key';
  } else if (process.env.DIFY_API_KEY) {
    apiKey = process.env.DIFY_API_KEY;
    apiKeySource = '环境变量 DIFY_API_KEY';
  } else if (fileConfig.api_key) {
    apiKey = fileConfig.api_key;
    apiKeySource = CONFIG_FILE;
  }

  let baseUrlRaw = DEFAULT_BASE_URL;
  let baseUrlSource = '默认值';
  if (flags['base-url']) {
    baseUrlRaw = flags['base-url'];
    baseUrlSource = '--base-url';
  } else if (process.env.DIFY_BASE_URL) {
    baseUrlRaw = process.env.DIFY_BASE_URL;
    baseUrlSource = '环境变量 DIFY_BASE_URL';
  } else if (fileConfig.base_url) {
    baseUrlRaw = fileConfig.base_url;
    baseUrlSource = CONFIG_FILE;
  }

  const defaults = loadDefaults();
  const wfFile = fileConfig.workflow && typeof fileConfig.workflow === 'object' ? fileConfig.workflow : {};
  const wfDefaults = defaults.workflow && typeof defaults.workflow === 'object' ? defaults.workflow : {};

  return {
    apiKey: String(apiKey).trim(),
    apiKeySource,
    baseUrl: normalizeBaseUrl(baseUrlRaw),
    baseUrlSource,
    workflow: {
      inputVar: String(flags['workflow-input'] || wfFile.input_var || wfDefaults.input_var || 'query').trim(),
      outputVar: String(flags['workflow-output'] || wfFile.output_var || wfDefaults.output_var || 'result').trim(),
      user: String(wfFile.user || wfDefaults.user || '').trim(),
    },
    defaultKb: fileConfig.default_kb ? String(fileConfig.default_kb) : '',
    sourceNote: String(fileConfig.source_note || defaults.source_note || '').trim(),
    configExists,
    configInvalid: configExists && parsed === null,
  };
}

function requireApiKey(config) {
  if (!config.apiKey) {
    throw new AppError(
      `未找到 Dify 应用 API Key（app-…）。请先运行：\n` +
        `  node scripts/kb.cjs setup\n` +
        `（交互式输入并保存到 ${CONFIG_FILE}，权限 600）\n` +
        `也可设置环境变量 DIFY_API_KEY，或手动创建配置文件：\n${CONFIG_SAMPLE}`
    );
  }
}

function loadDefaults() {
  return readJsonSafe(DEFAULTS_FILE) || {};
}

function promptHidden(promptText) {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY) {
      reject(
        new AppError(
          '当前不是交互式终端，无法安全输入 Key。请在支持交互式终端的 shell 中运行 setup，或加 --api-key（会留在命令/对话记录中）。'
        )
      );
      return;
    }

    process.stderr.write(promptText);
    const stdin = process.stdin;
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding('utf8');

    let value = '';
    const cleanup = () => {
      stdin.removeListener('data', onData);
      stdin.setRawMode(false);
      stdin.pause();
    };
    const onData = (chunk) => {
      for (const char of chunk) {
        const code = char.codePointAt(0);
        if (code === 13 || code === 10 || code === 4) {
          cleanup();
          process.stderr.write('\n');
          resolve(value.trim());
          return;
        }
        if (code === 3) {
          cleanup();
          process.stderr.write('\n');
          reject(new AppError('已取消。'));
          return;
        }
        if (code === 21) {
          value = '';
          continue;
        }
        if (code === 127 || code === 8) {
          value = value.slice(0, -1);
          continue;
        }
        if (code >= 32) value += char;
      }
    };
    stdin.on('data', onData);
  });
}

async function cmdAuth(flags) {
  const config = loadConfig(flags);

  if (!config.apiKey) {
    process.stderr.write(
      'AUTH MISSING: 本地未找到 Dify 应用 API Key（app-…）。请向用户索取 Key，然后运行 ' +
        '"setup --api-key <key>"（已有 Key 需覆盖时加 --force）保存到 ' +
        CONFIG_FILE +
        '\n'
    );
    process.exitCode = 1;
    return;
  }

  if (!flags.check) {
    process.stdout.write(
      `AUTH OK: 检索工作流「${config.defaultKb || '默认'}」（本地配置，Key ${maskKey(config.apiKey)}）\n`
    );
    return;
  }

  try {
    const timeoutMs = parseTimeout(flags.timeout);
    const info = await apiRequest('GET', '/info', config, undefined, timeoutMs);
    if (!info.ok) {
      const hint = apiErrorHint(info.status, apiErrorParts(info).code);
      process.stderr.write(
        `AUTH INVALID: ${describeApiError(info)}` + (hint ? `\n提示：${hint}` : '') + '\n'
      );
      process.exitCode = 1;
      return;
    }
    const name = info.json && info.json.name ? info.json.name : '检索工作流';

    const params = await apiRequest('GET', '/parameters', config, undefined, timeoutMs);
    if (!params.ok) {
      process.stderr.write(`AUTH INVALID: 读取工作流参数失败，${describeApiError(params)}\n`);
      process.exitCode = 1;
      return;
    }
    const vars = workflowInputVars(params.json);
    if (vars.length && !vars.includes(config.workflow.inputVar)) {
      process.stderr.write(
        `AUTH INVALID: 工作流没有输入变量「${config.workflow.inputVar}」。实际变量：${vars.join('、')}。` +
          `请运行 setup --workflow-input <变量名> --force 修正。\n`
      );
      process.exitCode = 1;
      return;
    }
    process.stdout.write(
      `AUTH OK: ${name}（工作流，输入变量 ${config.workflow.inputVar}，Key ${maskKey(config.apiKey)} 验证通过）\n`
    );
  } catch (error) {
    process.stderr.write(`AUTH INVALID: ${error.message}\n`);
    process.exitCode = 1;
  }
}

async function cmdSetup(flags) {
  const defaults = loadDefaults();
  const fileConfig = readJsonSafe(CONFIG_FILE) || {};
  const existing = loadConfig(flags);

  if (fileConfig.api_key && !flags.force) {
    throw new AppError(
      `${CONFIG_FILE} 中已存在 api_key。如需更换 Key 或知识库，请加 --force 重新配置。`
    );
  }

  let apiKey = flags['api-key'] ? String(flags['api-key']).trim() : '';
  if (!apiKey && process.env.DIFY_API_KEY) {
    apiKey = String(process.env.DIFY_API_KEY).trim();
  }
  if (!apiKey && process.stdin.isTTY) {
    apiKey = await promptHidden('请输入 Dify 应用 API Key（app-…，输入不回显，回车确认）: ');
  }
  if (!apiKey) {
    throw new AppError(
      '未提供 API Key。请在交互式终端运行 setup（Key 不回显），或加 --api-key（注意会留在命令/对话记录中）。'
    );
  }

  const baseUrl = normalizeBaseUrl(
    flags['base-url'] || process.env.DIFY_BASE_URL || fileConfig.base_url || defaults.base_url || DEFAULT_BASE_URL
  );

  if (!apiKey.startsWith('app-')) {
    process.stderr.write(
      '[warn] 该 Key 不是应用 Key（app-…）。本 skill 只支持工作流模式，应用 Key 在 Dify 应用的「访问 API」页创建。\n'
    );
  }

  const probe = { apiKey, baseUrl, apiKeySource: 'setup 输入' };
  const timeoutMs = parseTimeout(flags.timeout);

  // 写入前先联网校验：应用 Key 有效、是 workflow 应用，且输入变量存在
  const info = await apiRequest('GET', '/info', probe, undefined, timeoutMs);
  if (!info.ok) {
    throwApiError('校验应用 API Key（GET /info）', info);
  }
  const appMode = info.json && info.json.mode ? String(info.json.mode) : '';
  if (appMode && appMode !== 'workflow') {
    throw new AppError(
      `该应用类型为 ${appMode}，不是 workflow。请在 Dify 中创建一个 Workflow 应用（开始 → 知识库检索 → 结束），再创建应用 API Key。`
    );
  }

  const params = await apiRequest('GET', '/parameters', probe, undefined, timeoutMs);
  if (!params.ok) {
    throwApiError('读取工作流参数（GET /parameters）', params);
  }
  const vars = workflowInputVars(params.json);
  let inputVar = String(flags['workflow-input'] || '').trim();
  if (!inputVar) {
    if (vars.includes('query')) inputVar = 'query';
    else if (vars.length === 1) inputVar = vars[0];
    else inputVar = 'query';
  }
  if (vars.length && !vars.includes(inputVar)) {
    throw new AppError(
      `工作流没有输入变量「${inputVar}」。实际变量：${vars.join('、')}。请用 --workflow-input 指定。`
    );
  }
  if (!vars.length) {
    process.stderr.write(
      '[warn] 未能从 /parameters 读到输入变量，默认按 query 调用；运行失败时用 --workflow-input 指定。\n'
    );
  }

  const defaultOutputVar = defaults.workflow && defaults.workflow.output_var ? defaults.workflow.output_var : 'result';
  const outputVar = String(flags['workflow-output'] || defaultOutputVar).trim();
  const appName = info.json && info.json.name ? info.json.name : '检索工作流';
  const kbName = String(existing.defaultKb || defaults.kb_name || defaults.dataset_name || appName).trim();

  const config = {
    base_url: baseUrl,
    api_key: apiKey,
    default_kb: kbName,
    workflow: { input_var: inputVar, output_var: outputVar },
  };
  writeJson(CONFIG_FILE, config);

  process.stdout.write(
    [
      `✅ 已保存到 ${CONFIG_FILE}（权限 600）`,
      `   实例：${baseUrl}`,
      `   应用（工作流）：${appName}`,
      `   显示名称：${kbName}`,
      `   输入变量：${inputVar} ／ 输出变量：${outputVar}`,
      `   Key：${maskKey(apiKey)}`,
    ].join('\n') + '\n'
  );
}

function maskKey(key) {
  if (!key) return '(空)';
  if (key.length <= 12) return `${key.slice(0, 4)}…`;
  return `${key.slice(0, 10)}…${key.slice(-4)}`;
}

// ---------------------------------------------------------------------------
// 检索工作流（Dify Workflow App，运行记录会出现在 Dify「日志与标注」）
// ---------------------------------------------------------------------------

function workflowInputVars(parameters) {
  const form = parameters && Array.isArray(parameters.user_input_form) ? parameters.user_input_form : [];
  const names = [];
  for (const item of form) {
    if (!item || typeof item !== 'object') continue;
    for (const key of Object.keys(item)) {
      const field = item[key];
      if (field && typeof field === 'object' && field.variable) names.push(String(field.variable));
    }
  }
  return names;
}

function workflowUser(config) {
  const raw = config.workflow.user || os.userInfo().username || 'dify-kb-qa';
  const cleaned = String(raw)
    .replace(/[^\w一-龥.-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return cleaned || 'dify-kb-qa';
}

function toWorkflowRecord(item) {
  if (typeof item === 'string') {
    return { score: null, segment: { id: '', content: item, document: { id: '', name: '' } } };
  }
  if (!item || typeof item !== 'object') {
    return { score: null, segment: { id: '', content: String(item), document: { id: '', name: '' } } };
  }

  const segment = item.segment && typeof item.segment === 'object' ? item.segment : {};
  let metadata = {};
  if (item.metadata && typeof item.metadata === 'object') metadata = item.metadata;
  else if (segment.metadata && typeof segment.metadata === 'object') metadata = segment.metadata;
  const document = segment.document && typeof segment.document === 'object' ? segment.document : {};

  return {
    score: item.score ?? segment.score ?? metadata.score ?? null,
    segment: {
      id: String(item.segment_id ?? segment.id ?? metadata.segment_id ?? ''),
      content: String(item.content ?? item.text ?? segment.content ?? ''),
      document: {
        id: String(metadata.document_id ?? document.id ?? ''),
        name: String(item.title ?? item.document_name ?? document.name ?? metadata.document_name ?? ''),
      },
    },
  };
}

function normalizeWorkflowOutput(raw, outputVar) {
  if (raw === undefined || raw === null) {
    throw new AppError(
      `工作流输出中没有变量「${outputVar}」。请在 Dify 工作流的「结束」节点把检索结果映射为输出变量 ` +
        `「${outputVar}」，或用 setup --workflow-output <变量名> --force 指定实际输出变量名。`
    );
  }

  let value = raw;
  if (typeof value === 'string') {
    const text = value.trim();
    if (!text) return [];
    try {
      value = JSON.parse(text);
    } catch {
      return [toWorkflowRecord({ content: text })];
    }
  }
  if (value && !Array.isArray(value) && typeof value === 'object') {
    if (Array.isArray(value.records)) value = value.records;
    else if (Array.isArray(value.result)) value = value.result;
    else if (Array.isArray(value.data)) value = value.data;
  }

  const list = Array.isArray(value) ? value : [value];
  return list
    .filter((item) => item !== null && item !== undefined && item !== '')
    .map(toWorkflowRecord);
}

async function workflowSearch(query, config, timeoutMs) {
  const wf = config.workflow;
  const response = await apiRequest(
    'POST',
    '/workflows/run',
    config,
    {
      inputs: { [wf.inputVar]: query },
      response_mode: 'blocking',
      user: workflowUser(config),
    },
    timeoutMs
  );

  if (!response.ok) {
    throwApiError('运行检索工作流', response);
  }

  const data = response.json && response.json.data;
  if (!data || typeof data !== 'object') {
    throw new AppError('工作流响应缺少 data 字段。请确认当前 Key 属于 Workflow 类型的应用。');
  }
  if (data.status && data.status !== 'succeeded') {
    const detail = data.error ? `：${String(data.error).replace(/\s+/g, ' ').slice(0, 300)}` : '';
    throw new AppError(
      `工作流执行未成功（status=${data.status}${detail}）。本次检索失败，请稍后重试。`
    );
  }

  const outputs = data.outputs && typeof data.outputs === 'object' ? data.outputs : {};
  const records = normalizeWorkflowOutput(outputs[wf.outputVar], wf.outputVar);
  return {
    records,
    runId: String(response.json.workflow_run_id || data.id || ''),
    elapsed: data.elapsed_time,
  };
}

function parseTimeout(raw, fallback = 30000) {
  if (raw === undefined) return fallback;
  const value = Number(raw);
  if (!Number.isFinite(value) || value < 1000) {
    throw new AppError('--timeout 需为 >= 1000 的毫秒数。');
  }
  return Math.floor(value);
}

// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------

async function apiRequest(method, apiPath, config, body, timeoutMs = 30000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(`${config.baseUrl}${apiPath}`, {
      method,
      headers: {
        Authorization: `Bearer ${config.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });

    const text = await response.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      // 非 JSON 响应（如代理错误页），保留原文
    }

    return { status: response.status, ok: response.ok, json, text };
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new AppError(`请求超时（${timeoutMs}ms）：${config.baseUrl}${apiPath}`);
    }
    throw new AppError(`网络请求失败：${error.message}（${config.baseUrl}${apiPath}）`);
  } finally {
    clearTimeout(timer);
  }
}

function apiErrorParts(response) {
  const code = response.json && response.json.code ? response.json.code : `http_${response.status}`;
  const message =
    response.json && response.json.message
      ? response.json.message
      : String(response.text || '').slice(0, 300) || '(空响应)';
  return { code, message };
}

function apiErrorHint(status, code) {
  if (status === 401) {
    return '应用 API Key 无效或已被删除，请在 Dify 应用的「访问 API」页重新生成。';
  }
  if (status === 403) {
    if (code === 'forbidden') {
      return '应用无权限访问，或工作流运行触发了限流（限流需等待满 1 分钟）。';
    }
    return '无权限：请检查应用是否已发布、Key 是否属于该应用。';
  }
  if (status === 404) {
    return '应用不存在，或 base_url 指向了错误的 Dify 实例。';
  }
  if (status === 400) {
    return '请求参数错误：请核对工作流输入变量名（setup --workflow-input）与输入类型。';
  }
  if (status === 429) {
    return '请求过于频繁，请退避后重试。';
  }
  if (status >= 500) {
    return 'Dify 服务端错误，请稍后重试。';
  }
  return '';
}

function describeApiError(response) {
  const { code, message } = apiErrorParts(response);
  return `HTTP ${response.status} ${code}：${String(message).replace(/\s+/g, ' ').slice(0, 300)}`;
}

function throwApiError(action, response) {
  const { code, message } = apiErrorParts(response);
  const hint = apiErrorHint(response.status, code);
  throw new AppError(
    `${action}失败（HTTP ${response.status}，${code}）：${message}` + (hint ? `\n提示：${hint}` : '')
  );
}

// ---------------------------------------------------------------------------
// search
// ---------------------------------------------------------------------------

function formatScore(raw) {
  const value = Number(raw);
  return Number.isFinite(value) ? value.toFixed(4) : 'n/a';
}

function indent(text, spaces = 4) {
  return String(text)
    .split('\n')
    .map((line) => ' '.repeat(spaces) + line)
    .join('\n');
}

function printRecords(sourceNote, query, records) {
  const lines = [`来源说明：${sourceNote || '内部资料'}`, `查询：${query}`, `结果：${records.length} 个片段`];

  if (!records.length) {
    lines.push('');
    lines.push('未找到相关片段。可换个问法后重试。');
    process.stdout.write(lines.join('\n') + '\n');
    return;
  }

  records.forEach((record, index) => {
    const segment = record.segment || {};
    const document = segment.document || {};
    const content = String(segment.content || '').trim();
    const childCount = Array.isArray(record.child_chunks) ? record.child_chunks.length : 0;
    const meta = [
      `score ${formatScore(record.score)}`,
      `文档：${document.name || '(未知文档)'}`,
      `segment：${segment.id || '-'}`,
    ];
    if (childCount > 0) meta.push(`子片段：${childCount}`);

    lines.push('');
    lines.push(`[${index + 1}] ${meta.join(' | ')}`);
    lines.push(indent(content || '(空片段)'));
  });

  process.stdout.write(lines.join('\n') + '\n');
}

async function cmdSearch(flags) {
  const config = loadConfig(flags);
  requireApiKey(config);

  if (flags.query === undefined) {
    throw new AppError('缺少 --query "检索问题"。');
  }
  let query = String(flags.query).trim();
  if (!query) {
    throw new AppError('--query 不能为空。');
  }
  if (query.length > QUERY_MAX) {
    process.stderr.write(
      `[warn] query 超过 ${QUERY_MAX} 字符，已截断。请先把追问改写为更短的独立问题再检索。\n`
    );
    query = query.slice(0, QUERY_MAX);
  }

  if (flags.kb) {
    process.stderr.write('[warn] 本 skill 只检索配置的单一知识库（由工作流节点决定），--kb 已不再使用。\n');
  }
  if (flags.full) {
    process.stderr.write('[warn] 检索片段现在总是完整输出，--full 已不再需要。\n');
  }
  if (flags['top-k'] !== undefined || flags['min-score'] !== undefined || flags.method) {
    process.stderr.write(
      '[warn] 检索参数由 Dify 工作流中的检索节点决定，--top-k/--min-score/--method 已不再使用（可移除）。\n'
    );
  }

  const run = await workflowSearch(query, config, parseTimeout(flags.timeout, 60000));

  if (flags.json) {
    process.stdout.write(
      JSON.stringify({ query, workflow_run_id: run.runId, records: run.records }, null, 2) + '\n'
    );
    return;
  }
  printRecords(config.sourceNote, query, run.records);
}

// ---------------------------------------------------------------------------
// doctor
// ---------------------------------------------------------------------------

async function cmdDoctor(flags) {
  const results = [];
  const add = (ok, label, detail) => results.push({ ok, label, detail });
  const timeoutMs = parseTimeout(flags.timeout);

  const major = Number(process.versions.node.split('.')[0]);
  add(major >= 18, 'Node.js 版本', `v${process.versions.node}${major < 18 ? '（需要 >= 18）' : ''}`);

  const config = loadConfig(flags);
  if (config.configInvalid) {
    add(false, '配置文件', `${CONFIG_FILE} JSON 解析失败，请检查语法`);
  } else {
    add(
      true,
      '配置文件',
      config.configExists ? CONFIG_FILE : `${CONFIG_FILE} 不存在（可选；也可使用环境变量）`
    );
  }

  add(
    Boolean(config.apiKey),
    '应用 API Key',
    config.apiKey
      ? `来源：${config.apiKeySource}，${maskKey(config.apiKey)}`
      : '未找到。请运行 setup 配置，或设置 DIFY_API_KEY'
  );
  add(true, 'Base URL', `${config.baseUrl}（来源：${config.baseUrlSource}）`);

  if (config.apiKey && !config.apiKey.startsWith('app-')) {
    add(false, 'Key 格式', '应用 API Key 应以 "app-" 开头；当前 Key 无法调用 /workflows/run');
  }

  add(true, '检索通道', 'Dify 工作流 App（POST /workflows/run，每次运行都写入「日志与标注」）');

  if (!config.apiKey) {
    add(false, '连接与鉴权', '跳过（缺少应用 API Key）');
  } else {
    try {
      const info = await apiRequest('GET', '/info', config, undefined, timeoutMs);
      if (!info.ok) {
        add(false, '连接与鉴权', describeApiError(info));
      } else {
        const name = info.json && info.json.name ? info.json.name : '(未命名)';
        const appMode = info.json && info.json.mode ? String(info.json.mode) : '';
        if (appMode && appMode !== 'workflow') {
          add(false, '应用类型', `当前为 ${appMode}，不是 workflow；/workflows/run 不可用`);
        } else {
          add(true, '连接与鉴权', `GET /info 成功：${name}（workflow）`);
        }

        const params = await apiRequest('GET', '/parameters', config, undefined, timeoutMs);
        if (!params.ok) {
          add(false, '工作流参数', describeApiError(params));
        } else {
          const vars = workflowInputVars(params.json);
          add(
            vars.length === 0 || vars.includes(config.workflow.inputVar),
            '工作流输入变量',
            vars.length
              ? `${config.workflow.inputVar}（可用：${vars.join('、')}）`
              : `未读到输入变量，将按 ${config.workflow.inputVar} 调用`
          );
          add(true, '工作流输出变量', `${config.workflow.outputVar}（静态无法校验，检索时验证）`);
        }
      }
    } catch (error) {
      add(false, '连接与鉴权', error.message);
    }
  }

  add(true, '知识库', `由工作流中的检索节点决定；当前显示名称「${config.defaultKb || '未设置'}」`);
  add(true, '运行日志', 'Dify → 该应用 → 日志与标注（每条提问都会记录，user 为本机用户名）');

  const passed = results.filter((item) => item.ok).length;
  const failed = results.length - passed;

  const lines = ['dify-kb-qa doctor'];
  results.forEach((item) => {
    lines.push(`${item.ok ? '✓' : '✗'} ${item.label}：${item.detail}`);
  });
  lines.push('');
  lines.push(`结果：${passed} 项通过，${failed} 项失败`);
  process.stdout.write(lines.join('\n') + '\n');

  if (failed > 0) process.exitCode = 1;
}

// ---------------------------------------------------------------------------
// help
// ---------------------------------------------------------------------------

function printHelp(command) {
  if (command === 'setup' || command === 'auth') {
    process.stdout.write(`用法：
  node scripts/kb.cjs setup [--api-key <key>] [--base-url <url>]
                            [--workflow-input <变量>] [--workflow-output <变量>] [--force]
  node scripts/kb.cjs auth [--check]

setup：交互式终端下提示输入应用 API Key（app-…，不回显），先调 GET /info 与
        GET /parameters 校验应用与变量，再写入 ~/.config/dify-kb-qa/config.json（权限 600）。
        已存在凭证时需加 --force。非交互终端（如 agent 后台调用）请使用 --api-key。
        输入变量默认自动探测（优先 query）；输出变量默认 result。
auth：默认只检查本机配置文件；--check 会联网验证应用、类型与输入变量。
`);
    return;
  }

  if (command === 'search') {
    process.stdout.write(`用法：node scripts/kb.cjs search --query "..." [选项]

选项：
  --query "..."           检索问题（≤32768 字符）
  --json                  输出解析后的 records JSON
  --timeout 60000         请求超时（毫秒，默认 60000）

检索调用 POST /workflows/run（blocking）；Top K、检索方式、阈值等在 Dify 工作流的
「知识库检索」节点里设置。返回的片段始终完整输出，不截断。
`);
    return;
  }

  process.stdout.write(`dify-kb-qa — 通过 Dify 工作流检索知识库，答案由调用方基于片段生成

用法：node scripts/kb.cjs <command> [options]

命令：
  auth                        检查本机是否已有应用 Key（--check 联网验证）
  setup                       首次配置：输入应用 Key → 校验 → 保存到本机
  doctor                      检查配置、凭证与工作流连通性
  search                      检索知识片段

search 选项：
  --query "..."             检索问题（≤32768 字符）
  --json                    输出解析后的 records JSON
  --timeout 60000           请求超时（毫秒）

setup 选项：
  --api-key <key>           应用 API Key（app-…）
  --base-url <url>          Dify 实例地址（默认取 config.defaults.json）
  --workflow-input <变量>   工作流输入变量名（默认自动探测）
  --workflow-output <变量>  工作流输出变量名（默认 result）
  --force                   覆盖已有配置

凭证优先级：命令行 > 环境变量 DIFY_API_KEY / DIFY_BASE_URL > ${CONFIG_FILE} > config.defaults.json
`);
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

async function main(argv) {
  const [, , command, ...rest] = argv;

  if (command === '--help' || command === '-h' || command === 'help') {
    const { positionals } = parseArgs(rest);
    printHelp(positionals[0]);
    return;
  }

  const { flags } = parseArgs(rest);

  if (!command || flags.help) {
    printHelp(command);
    return;
  }

  switch (command) {
    case 'auth':
      await cmdAuth(flags);
      break;
    case 'setup':
      await cmdSetup(flags);
      break;
    case 'doctor':
      await cmdDoctor(flags);
      break;
    case 'search':
      await cmdSearch(flags);
      break;
    default:
      throw new AppError(`未知子命令「${command}」。可用：auth / setup / doctor / search。`);
  }
}

if (require.main === module) {
  main(process.argv).catch((error) => {
    if (error instanceof AppError) {
      process.stderr.write(JSON.stringify({ code: ERR_PROGRAMMATIC, msg: error.message }) + '\n');
      process.exit(1);
    }
    process.stderr.write(
      JSON.stringify({ code: 2, msg: `内部错误：${error && error.message ? error.message : String(error)}` }) + '\n'
    );
    process.exit(2);
  });
}

module.exports = {
  AppError,
  apiRequest,
  loadConfig,
  normalizeBaseUrl,
  parseArgs,
  workflowInputVars,
  normalizeWorkflowOutput,
  ERR_PROGRAMMATIC,
};
