#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_report.py — 从数据 JSON + 源码库生成「知识点整理」讲义（md）

铁律（用户要求，2026-08-11）：
  1. 只交付 md；用户确认后才出 PDF（本脚本不生成 PDF）
  2. 纯知识点整理：不写学生情况
  3. 标题：`# 260811更新——dp、快速幂、数论…`（日期更新——知识点短名）
  4. 知识点标题：`## 快速幂`
  5. 例题代码：把老师同一题的全部提交【按思路归纳去重】——同思路只留 1 个代表代码；
     每种思路配【讲解文字（含 LaTeX 公式）+ 代码】
  6. 公式一律 LaTeX：`$a^b \bmod p$`
  7. 老师没 AC 的题按老师风格写标准程序
  8. 客观题知识点也要讲解

用法:
  python3 gen_report.py [data.json] [codes.json] [teacher_multi.json] [--out-dir /tmp/wechat-md]
输出: <date>更新-知识点.md / .html / -微信总结.txt
"""
import argparse, json, os, re, sys
from collections import defaultdict

# ---------- 代码规范化（gesp-text 规范：科学计数法、单语句省 {}、去多余空行） ----------
_CONST_FIX = [
    ("1000000007", "1e9 + 7"),
    ("100000000", "1e8"),
    ("1000005", "1e6 + 5"),
    ("100005", "1e5 + 5"),
    ("10005", "1e4 + 5"),
    ("100000", "1e5"),
    ("10000", "1e4"),
]
def _drop_brace_ctrl(m):
    """for/if/while/else 的单语句块去大括号：{ (注释行) stmt; } → 换行 + stmt;（保留注释、继承缩进）
    函数体（前是函数签名）不匹配，大括号一律保留"""
    head = m.group(1)
    raw = m.group(2)
    has_nl = "\n" in raw                     # 用原始 body 判断是否多行
    body = raw.strip("\n")
    lines = [l for l in body.split("\n") if l.strip()]
    if not lines:
        return head
    ind = (len(lines[0]) - len(lines[0].lstrip())) if has_nl else 4
    pad = " " * ind
    return head + "\n" + "\n".join(pad + l.strip() for l in lines)

_NEST_RE = re.compile(r"(\b(?:for|if|while)\s*\([^)]*\))\s*\{\s*(.*?)\s*\}", re.S)

def _drop_nested(m):
    """嵌套 for/if/while 去外层大括号：仅当块内恰好一条语句（for 头自带 2 分号不计）"""
    head, body = m.group(1), m.group(2)
    bare = re.sub(r"//[^\n]*", "", body)
    n_for = len(re.findall(r"\bfor\s*\(", bare))
    n_cond = len(re.findall(r"\b(?:if|while)\s*\(", bare))
    n_stmts = bare.count(";") - 2 * n_for   # 每条语句末尾 1 个分号
    if n_stmts != 1:
        return m.group(0)                   # 多语句块保留大括号
    lines = [l for l in body.strip("\n").split("\n") if l.strip()]
    ind2 = len(lines[1]) - len(lines[1].lstrip()) if len(lines) > 1 else 4
    ind1 = max(ind2 - 4, 0)
    out = [" " * ind1 + lines[0].strip()]
    out += [" " * ind2 + l.strip() for l in lines[1:]]
    return head + "\n" + "\n".join(out)

def norm_code_style(code):
    """把代码改造成 gesp-text 规范风格：
    1) 大数常量展开式 → 科学计数法（1000000007→1e9 + 7、10005→1e4 + 5 等）
    2) 单语句省 {}（含注释行、嵌套 for 的单语句块）
    3) 压缩多余连续空行（保留单个空行）"""
    if not code:
        return code
    # 头文件规范：#include<bits/stdc++.h> → #include <bits/stdc++.h>（< 后有空格）
    code = re.sub(r"#include<bits/stdc\+\+\.h>", "#include <bits/stdc++.h>", code)
    # 规范：禁 #define int long long + signed main（gesp-text §1）——整体迁移为 #define ll long long + int main
    if "#define int long long" in code:
        code = code.replace("#define int long long", "#define ll long long")
        code = code.replace("signed main", "int main")
        code = re.sub(r"\bint (qpow|inv|res|ans|p|a|b|x)\b", r"ll \1", code)
    # 清理死代码：函数顶层 return 之后、同函数体内不可达的语句（如迭代版后残留的递归版）
    code = re.sub(r"(return[^;]*;)\n\s*\n((?:\s*[^{}\n][^\n]*\n)*?)(\s*\})",
                  lambda m: m.group(1) + "\n" + m.group(3), code)
    # 输入输出/移位规范：二元 << 和 >> 两侧加空格（cin>>n→cin >> n、cout<<h→cout << h、a>>b→a >> b）
    # 排除 <<= / >>= 复合赋值（后跟 = 不是 \w）
    code = re.sub(r"(?<=\w)\s*<<\s*(?=\w)", " << ", code)
    code = re.sub(r"(?<=\w)\s*>>\s*(?=\w)", " >> ", code)
    code = re.sub(r"\}cout", "}\n    cout", code)
    # 乱格式修复：行首 2 空格 → 4 空格（规范缩进 4 空格）
    code = re.sub(r"^  (\S)", r"    \1", code, flags=re.M)
    # 规范：普通数组优先——高精度 DP 的 vector<string> c(n+1) 改全局裸数组 string c[105];
    code = re.sub(r"vector<string> c\(n \+ 1\);", "string c[105];", code)
    for old, new in _CONST_FIX:
        code = re.sub(r"(?<![0-9a-zA-Z_.])" + re.escape(old) + r"(?![0-9])", new, code)
    # 单语句省 {}：仅 for/if/while/else 的单语句块（函数体大括号一律保留）
    code = re.sub(
        r"(\b(?:for|if|while)\s*\([^)]*\))\s*\{((?:\n\s*)?(?://[^\n]*\n\s*)?[^{}\n]*?;)\s*\}",
        _drop_brace_ctrl, code)
    # 嵌套 for/if/while 单语句去外层大括号（仅块内恰好一条语句；多语句块保留）
    code = _NEST_RE.sub(_drop_nested, code)
    code = re.sub(r"\n{3,}", "\n\n", code)
    return code

# ---------- 知识点讲解库 ----------
# 每个知识点：points=要点(含公式) | idea_groups=[{name,desc,keywords}] 思路组 | pits=易错 | code=标准程序
# keywords: 命中任一即归入该思路组；老师代码按序归组，同组只留 1 个代表
KNOWLEDGE = {
    "快速幂": {
        "points": [
            "快速算 **$a^b \\bmod p$**，暴力连乘 $b$ 次会超时",
            "核心：把 $b$ 拆成二进制，只用 $\\log_2 b$ 次乘法",
            "类比「查表」：先算 $a^1, a^2, a^4, a^8 \\dots$，$b$ 的哪一位是 1 就把哪个乘进来",
        ],
        "idea_groups": [
            {"name": "方法一：递归写法",
             "desc": "用 `b & 1` 或 `b % 2` 判断：$b$ 是奇数 $\\to a^b = a^{b-1} \\times a$，$b$ 是偶数 $\\to a^b = (a^2)^{b/2}$；边界 $b=0$ 返回 1。\n**为什么这样拆**：目标是让指数每次减半\n  - 奇数先拆出一个 $a$ 变偶数：$a^b = a \\cdot a^{b-1}$\n  - 偶数直接平方折半：$a^b = (a^2)^{b/2}$\n  - 指数 $b \\to \\frac{b}{2}$，只需 $O(\\log b)$ 层递归，$b=10^9$ 也秒过",
             "keywords": ["return qpow", "n - 1", "b - 1"]},
            {"name": "方法二：迭代写法",
             "desc": "`res` 初始为 1，循环里 `b & 1`（或 `b % 2`）为真就把当前 `a` 乘进 `res`，然后 `a = a * a % p`、`b` 减半。\n**为什么这样写**：把 $b$ 看成二进制\n  - $a^b = \\prod a^{2^k}$，$b$ 的第 $k$ 位是 1 才乘\n  - `a = a * a` 就是在算 $a^1, a^2, a^4 \\dots$ 这一串\n  - 哪一位是 1 就把对应那个乘进 `res`，等价于递归法但不用递归栈",
             "keywords": ["while (b)", "res = res * a"]},
        ],
        "pits": ["==每一步都要 `% p`==，忘了会爆 long long", "==`b = 0` 时结果是 1==，别写成 0", "`a` 也要先 `% p` 再乘"],
        "code": """#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 105;
ll p;

ll qpow(ll a, ll b) {
    ll res = 1;
    while (b) {
        if (b % 2) res = res * a % p;
        a = a * a % p, b /= 2;
    }
    return res;
}

int main() {
    ll a, b;
    cin >> a >> b >> p;
    cout << qpow(a, b);
    return 0;
}""",
    },
    "DP（路径计数）": {
        "points": [
            "问「从起点到终点有几种走法」，核心是**递推**",
            "到 $(i,j)$ 的走法数 = 上面来的 + 左边来的：$f_{i,j} = f_{i-1,j} + f_{i,j-1}$",
        ],
        "idea_groups": [
            {"name": "方法一：DP 递推（全局数组）",
             "desc": "从 $(0,0)$ 出发，第一行/第一列都只有 1 种走法；按格子递推 $f_{i,j} = (f_{i-1,j} + f_{i,j-1}) \\bmod M$。\n**为什么这样递推**：走到 $(i,j)$ 的最后一步只能从上面或左边来\n  - 从上面来：$(i-1,j) \\to (i,j)$\n  - 从左边来：$(i,j-1) \\to (i,j)$\n  - 两种互不重叠，加法原理直接相加",
             "keywords": ["f[N][N]", "f[n + 1][m + 1]", "int f[", "ll f["]},
            {"name": "方法二：组合数公式",
             "desc": "从 $(0,0)$ 走到 $(n,m)$：向下 $n$ 步、向右 $m$ 步，共 $n+m$ 步；答案就是从这 $n+m$ 步里选 $n$ 步向下，$C_{n+m}^{n} = C_{n+m}^{m}$。\n**为什么是组合数**：\n  - 只要定下哪些步是向下，向右的步就自动确定了\n  - 一条路径对应一种选择，选法数就是 $C_{n+m}^{n}$\n  - 等价 $C_{n+m}^{m}$，$m$ 大时换小的算；代码用 `comb(m + n, min(n, m))` 实现",
             "keywords": ["comb", "perm", "min(n, m)", "min(m, n)"]},
        ],
        "pits": ["==边界行/列初始化为 1==：第一行、第一列只有一种走法", "==答案很大时要 `% mod`=="],
        "code": """#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 1005, M = 1e9 + 7;
ll dp[N][N];

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i <= n; i++) dp[i][0] = 1;
    for (int j = 0; j <= m; j++) dp[0][j] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            dp[i][j] = (dp[i - 1][j] + dp[i][j - 1]) % M;
    cout << dp[n][m];
    return 0;
}""",
    },
    "卡特兰数": {
        "points": [
            "**卡特兰数**：$C_n = \\frac{1}{n+1}C_{2n}^n$，出栈序列、括号匹配、不越过对角线的路径……方案数都是它",
            "递推：$C_n = \\sum_{i=0}^{n-1} C_i \\cdot C_{n-1-i}$；相邻项 $C_n = \\frac{2(2n-1)}{n+1} C_{n-1}$（$C_0 = 1$）",
            "表格 DP 法（**从头到尾只用加法**）：$f_{i,j} = f_{i-1,j} + f_{i,j-1}$（$j \\le i$），答案 $f_{n,n}$",
            "今天的三道卡特兰数题：`TS77020` 简单的路径计数VI、`CSPJ200303` [NOIP 2003] 栈、`LQ202506` [蓝桥杯] 魔术扑克牌排列",
        ],
        "idea_groups": [
            {"name": "方法一：表格 DP + 高精度加法（纯加法）",
             "desc": "答案超出 long long，用字符串手写高精度加法 `add`；$f_{i,j} = f_{i-1,j} + f_{i,j-1}$，$f_{0,j}=1$，答案 $f_{n,n}$。\n**为什么是卡特兰数**：出栈序列、括号匹配、不越过对角线的路径，方案数都是 $C_n = \\frac{1}{n+1}C_{2n}^n$——因为它们都满足「任意时刻后项不超前项」\n  - 出栈序列：任意时刻已出栈数 $\\le$ 已进栈数（进得不够就出=出空气）\n  - 括号匹配：左括号=进栈、右括号=出栈，任意前缀左括号数 $\\ge$ 右括号数\n  - 路径：任意时刻不越过对角线（$j \\le i$）\n**为什么只用加法**：表格递推每一步只是两个数相加，**从头到尾用不到乘法**，高精度只需要手写加法 `add`\n**为什么用高精度**：$C_n$ 增长极快，$n=30$ 时已 $\\approx 3.8 \\times 10^{16}$，爆 long long",
             "keywords": ["add", "f[i][j]", "cat", "dp[i][j]", "f[0][i]"]},
            {"name": "方法二：递推公式法",
             "desc": "用相邻项递推一路算到 $C_n$：$C_n = \\frac{2(2n-1)}{n+1} C_{n-1}$，代码就一行 `h = h * 2 * (2 * i - 1) / (i + 1);`。\n**为什么用递推公式**：\n  - 由 $C_n = \\frac{1}{n+1}C_{2n}^n$ 的相邻项比值推出\n  - $O(n)$ 一次循环算完，比表格 DP 更省\n  - $n$ 不大时用 `long long` 直接算；$C_n$ 很快超范围，$n$ 大就要换高精度",
             "keywords": ["2 * (2 * i", "2 * (2*i", "(i + 1)", "(i+1)", "i + 2"]},
        ],
        "pits": ["==出栈序列数 / 括号匹配数 / 不越对角线路径数都是卡特兰数==", "==$C_n = \\frac{1}{n+1}C_{2n}^n$，$n=30$ 就超 long long，必须高精度==", "==递推公式法注意先乘后除==：`h * 2 * (2 * i - 1) / (i + 1)`，顺序错了会丢精度=="],
        "code": "",
    },
    "数论（逆元）": {
        "points": [
            "模运算里**没有除法**！$\\frac{a}{b} \\bmod p$ 不能直接算",
            "要乘 $b$ 的逆元 $b^{-1}$（满足 $b \\cdot b^{-1} \\equiv 1 \\pmod p$）",
            "$p$ 是质数时用费马小定理：$b^{-1} = b^{p-2} \\bmod p$",
            "类比：就像「除以 3」等于「乘 $\\frac{1}{3}$」",
        ],
        "idea_groups": [
            {"name": "方法一：费马小定理 + 快速幂",
             "desc": "`inv(x)` = $x^{p-2} \\bmod p$，配合快速幂 $O(\\log p)$ 求出逆元，把除法变乘法。\n**为什么是 $x^{p-2}$**：\n  - 费马小定理：$x^{p-1} \\equiv 1 \\pmod p$（$p$ 是质数、$x$ 不被 $p$ 整除）\n  - 两边同除以 $x$：$x^{p-2} \\equiv x^{-1} \\pmod p$\n  - 所以逆元就是 $x^{p-2} \\bmod p$，正好用快速幂 $O(\\log p)$ 算",
             "keywords": ["inv", "qpow", "p - 2"]},
        ],
        "pits": ["==p 必须是质数==才可以用 $b^{p-2}$", "==b 和 p 要互质==", "先会快速幂再学逆元"],
        "code": """#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 105;
ll p = 2146516019;

ll qpow(ll a, ll b) {
    ll res = 1;
    while (b) {
        if (b % 2) res = res * a % p;
        a = a * a % p, b /= 2;
    }
    return res;
}

ll inv(ll x) {
    return qpow(x, p - 2) % p;
}

int main() {
    int n;
    cin >> n;
    cout << inv(n);
    return 0;
}""",
    },
    "组合（排列）": {
        "points": [
            "**排列 $A_n^m$** 考虑顺序（排队），**组合 $C_n^m$** 不考虑（选人）",
            "$A_n^m = \\frac{n!}{(n-m)!}$，$C_n^m = \\frac{A_n^m}{m!}$",
            "类比：排队买奶茶谁先谁后有区别=排列；抓苹果先抓后抓没区别=组合",
        ],
        "idea_groups": [
            {"name": "方法一：高精度加法 + 表格递推（纯加法 DP）",
             "desc": "答案超出 long long，用字符串手写高精度加法 `add`；按 $f_{i,j} = f_{i-1,j} + f_{i,j-1}$ 填表，$f_{0,j}=1$，答案 $f_{n,n}$（本质是卡特兰数 $C_n = \\frac{1}{n+1}C_{2n}^n$）。\n为什么只用加法：这个表格递推每一步都只是两个数相加（$f_{i,j} = f_{i-1,j} + f_{i,j-1}$），**从头到尾用不到乘法**，所以高精度只需要手写加法 `add` 就够了；为什么用高精度：$C_n$ 增长极快，$n=30$ 时已经 $\\approx 3.8 \\times 10^{16}$，$n$ 再大就爆 long long，必须用字符串逐位算。",
             "keywords": ["add(string", "string add", "cat", "f[0][i]"]},
        ],
        "pits": ["==C(n,m) = C(n,n-m)==，m 大时换小的算", "==$C_n^0 + C_n^1 + \\cdots + C_n^n = 2^n$==", "别把排列组合公式记混"],
        "code": """#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 30;

ll perm(int n, int m) {
    ll res = 1;
    for (int i = 0; i < m; i++)
        res *= n - i;
    return res;
}

ll comb(int n, int m) {
    return perm(n, m) / perm(m, m);
}

int main() {
    int n, m;
    cin >> n >> m;
    cout << comb(n, m);
    return 0;
}""",
    },
    "数位": {
        "points": [
            "**数位分离**：`n % 10` 拿个位，`n / 10` 删个位，循环到 0",
            "类比「卸磨杀驴过河拆桥」：拿一个删一个，拿完删完就结束",
            "统计位数、求和、判回文都靠它",
        ],
        "idea_groups": [
            {"name": "方法一：排列组合公式",
             "desc": "按位数累加：$d$ 位数且各位不同 $= 9 \\times P(9, d-1)$（首位不能是 0，后面从 9 个数字里选 $d-1$ 个排列），答案 $1 + \\sum_{d=1}^{n} 9 \\cdot P(9, d-1)$。\n为什么首位不能是 0：$d$ 位数的第一位是最高位，写成 0 就不是 $d$ 位数了（前导零），所以第一位只能在 1~9 里选（9 种）；剩下 $d-1$ 位从剩余 9 个数字里选 $d-1$ 个全排列，乘法原理得 $9 \\times P(9, d-1)$。",
             "keywords": ["perm", "9 *", "9*", "P(9"]},
            {"name": "方法二：数位 DP",
             "desc": "`dfs(pos, mask, used)`：`pos` 当前位，`mask` 用二进制记录已用数字，`used` 是否已开始；用过的数字跳过，递归到最后返回 1；加 `f[pos][mask][used]` 记忆化。\n为什么用 `mask`：题目要求各位数字都不同，必须知道前面用过哪些数字——`mask` 的第 $d$ 位是 1 就代表数字 $d$ 用过了，选下一个数时跳过；`used` 标记是否已经写过非零首位（没开始时可以跳过这位不填，对应更短的数），配合记忆化数组避免重复搜索。",
             "keywords": ["dfs", "mask", "1 << d", "1<<d"]},
        ],
        "pits": ["==循环里别直接动 n 本身==，要留原值就另存一份"],
        "code": """#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;
    while (n) {
        int k = n % 10;
        n /= 10;
    }
    return 0;
}""",
    },
    "栈队列": {
        "points": [
            "**栈**：先进后出，像一摞盘子（stack）",
            "**队列**：先进先出，像排队买奶茶（queue）",
            "括号匹配、表达式求值都靠栈",
            "**循环队列**：用数组模拟队列，`rear` 进 `front` 出，走到数组末尾就绕回开头（取模），省空间",
            "判空 `front == rear`；判满 `(rear + 1) % MAXSIZE == front`（留一个空位）；入队 `rear = (rear + 1) % MAXSIZE`；出队 `front = (front + 1) % MAXSIZE`；长度 `(rear - front + MAXSIZE) % MAXSIZE`",
        ],
        "idea_groups": [
            {"name": "方法一：卡特兰数（表格 DP + 高精度加法）",
             "desc": "**为什么是卡特兰数**：$n$ 个元素依次进栈，任意时刻**已出栈数不能超过已进栈数**（进得不够就出，那是出空气），这一限制等价于括号匹配（左括号=进栈、右括号=出栈）、也等价于不越过对角线的路径，所以方案数 = 卡特兰数 $C_n = \\frac{1}{n+1}C_{2n}^n$。\n表格 DP 法：`f[i][j]` = 已进 $i$ 个、已出 $j$ 个的方案数（要求 $j \\le i$），最后一步要么再进一个（$f_{i-1,j}$）、要么再出一个（$f_{i,j-1}$），加法原理相加：$f_{i,j} = f_{i-1,j} + f_{i,j-1}$；答案很大，用高精度加法 `add` 逐位算。",
             "keywords": ["add", "f[i][j]", "catalan"]},
        ],
        "pits": ["==`pop()`/`top()` 前先判 `empty()`==，否则崩", "==栈顶是 `top()`，队列头是 `front()`==", "==循环队列判满要留一个空位==：`(rear + 1) % MAXSIZE == front`", "==循环队列长度要 `+ MAXSIZE` 再取模==，防止减出负数"],
        "code": """#include <bits/stdc++.h>
using namespace std;
stack<int> st;
queue<int> q;

int main() {
    st.push(1), st.pop();
    q.push(1), q.pop();
    return 0;
}""",
    },
    "图论": {
        "points": [
            "图 = 点 + 边。有向图边有方向，无向图没有",
            "**握手定理**：无向图**度数之和 = 2 × 边数**（每条边贡献 2 个度，所以度数之和永远是偶数）",
            "**完全图**：无向 $n$ 个点两两连边，共 $\\frac{n(n-1)}{2}$ 条；有向完全图 $n(n-1)$ 条（双向各一条）",
            "**树**：$n$ 个点 $n-1$ 条边，任意两点连通且无环；再加一条边必成环",
            "**连通**：无向图任意两点可达；有向图强连通 = 任意两点互相可达",
            "有向图**入度之和 = 出度之和 = 边数**",
            "**简单路径**：不重复经过点的路径；**环**：起点终点相同的路径",
            "平面图**欧拉公式**：$V - E + F = 2$（顶点数 - 边数 + 面数 = 2）",
            "类比「朋友圈」：你是点，互相关注是边",
        ],
        "idea_groups": [],
        "pits": ["==度数之和一定是偶数==（2×边数，握手定理）", "==完全图边数别记混==：无向 $\\frac{n(n-1)}{2}$、有向 $n(n-1)$", "==树 $n$ 个点 $n-1$ 条边==，多加一条必成环", "==有向图入度总和 = 出度总和==，都等于边数", "遍历别重复走，防止死循环"],
        "code": """#include <bits/stdc++.h>
using namespace std;
const int N = 1005;
vector<int> g[N];

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    return 0;
}""",
    },
    "模拟": {
        "points": [
            "按题意一步一步模拟，**别多想**，把过程翻译成代码",
            "注意循环边界和数据范围，防 TLE / 溢出",
        ],
        "idea_groups": [],
        "pits": ["==注意用 long long==，乘积可能爆炸"],
        "std_desc": "老师未提交此题，按老师代码风格写的标准程序。\n为什么直接模拟：这题数据范围小，按题意一步一步翻译成代码就行，==别多想==——先把过程模拟出来保证对，再想优化。",
        "code": """#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 1005;
int a[N];

int main() {
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i];
    // 按题意模拟
    ll ans = 0;
    cout << ans;
    return 0;
}""",
    },
    "分支": {
        "points": [
            "if-else 按条件分类讨论",
            "注意边界：等于号、大小写",
        ],
        "idea_groups": [],
        "pits": ["==比较别漏等号==", "==输出大小写按题目来=="],
        "std_desc": "老师未提交此题，按老师代码风格写的标准程序。\n为什么这样排：三个数比大小，先两两交换把最大的放到 `a`、最小的放到 `c`，再交换一次就排好序——手写交换排序比 `sort` 更直白，考场不依赖 STL 也能过。",
        "code": """#include <bits/stdc++.h>
using namespace std;

int main() {
    int a, b, c;
    cin >> a >> b >> c;
    if (a < b) swap(a, b);
    if (a < c) swap(a, c);
    if (b < c) swap(b, c);
    cout << c << ' ' << b << ' ' << a;
    return 0;
}""",
    },
    "数制转换": {
        "points": [
            "进制转换：十进制转 k 进制 ==除 k 取余==，k 进制转十进制 ==按权展开==：$x = \\sum d_i \\cdot k^i$",
            "类比：凑零钱，从大到小一张张换",
        ],
        "idea_groups": [],
        "pits": ["==大于 9 的位用字母 A-F 表示==", "==注意 0 的转换=="],
        "code": "",
    },
    "真题套卷": {
        "points": [
            "真题刷的就是考点分布和做题节奏",
            "错题整理成错题本，反复看",
        ],
        "idea_groups": [],
        "pits": ["==计时训练==，模拟考场节奏"],
        "code": "",
    },
    "计算机基础": {
        "points": [
            "进制、编码、存储、硬件基础概念",
            "$1B = 8bit$，$1KB = 1024B$，$1MB = 1024KB$",
        ],
        "idea_groups": [],
        "pits": ["==KB 与 KiB 陷阱==：CSP 默认 $2^{10} = 1024$"],
        "code": "",
    },
    "单调栈队列": {
        "points": [
            "维护一个**单调递增/递减**的栈或队列",
            "解决「下一个更大/更小元素」类问题",
        ],
        "idea_groups": [],
        "pits": ["==弹出条件想清楚==：什么时候出队"],
        "code": "",
    },
}

# ---------- 知识点归一（琦琦 OJ 短名体系） ----------
_NORM = [
    ("简单的路径计数VI", "卡特兰数"),   # 不越过对角线的路径 = 卡特兰数
    ("路径计数", "DP（路径计数）"),
    ("快速幂", "快速幂"),
    ("逆元", "数论（逆元）"),
    ("魔术扑克牌排列", "卡特兰数"),
    ("各位数字都不同", "数位"),
    ("求三个数的大小顺序", "分支"),
    ("最多的花生", "模拟"),
    ("0与1", "模拟"),
    ("堆石子", "模拟"),
    ("栈队列", "栈队列"),
    ("栈", "卡特兰数"),
    ("图论", "图论"),
    ("数制转换", "数制转换"),
    ("计算机基础", "计算机基础"),
    ("单调栈队列", "单调栈队列"),
]
def normalize_kp(kp):
    for k, v in _NORM:
        if k in kp:
            return v
    return kp

def title_knowledge(title):
    t = re.sub(r"^【[^】]*】", "", title or "")
    t = re.sub(r"\[模板\]", "", t).strip()
    return t or "未分类"

def question_knowledge(qtitle):
    t = re.sub(r"^[A-Z]+-", "", qtitle or "")
    t = re.sub(r"-Q\d+$", "", t)
    t = re.sub(r"-\d+$", "", t)
    t = t.strip()
    if not t or re.fullmatch(r"\d{4}", t or ""):
        return "真题套卷"
    return t or "未分类"

def is_ac_status(status):
    return status == 0

def pct(a, b):
    return f"{a * 100 // b}%" if b else "-"

def build_stats(data):
    date, gname = data["date"], data.get("group", {}).get("name", "")
    members = data.get("members", [])
    subs = data.get("coding_subs", [])
    qrecs = data.get("question_records", [])

    coding_by_stu = defaultdict(dict)
    coding_by_kp = defaultdict(lambda: {"n": 0, "ac": 0})
    for s in subs:
        name = s.get("username") or "?"
        tags = s.get("tags") or [title_knowledge(s.get("title"))]
        kp = " / ".join(tags) if tags else "未分类"
        kp = normalize_kp(kp)
        ac = is_ac_status(s.get("status"))
        dp = s.get("displayPid") or s.get("title") or s.get("submitId")
        if dp not in coding_by_stu[name] or (s.get("submitTime") or "") >= (coding_by_stu[name][dp].get("submitTime") or ""):
            coding_by_stu[name][dp] = {
                "displayPid": dp, "title": s.get("title"),
                "tags": tags, "kp": kp, "ac": ac, "score": s.get("score"),
                "submitTime": s.get("submitTime"),
            }
        coding_by_kp[kp]["n"] += 1
        if ac:
            coding_by_kp[kp]["ac"] += 1

    quest_by_stu = defaultdict(list)
    quest_by_kp = defaultdict(lambda: {"n": 0, "ac": 0})
    uid2name = {m.get("uid"): m.get("username") for m in members}
    for r in qrecs:
        name = uid2name.get(r.get("uid"), "?")
        kp = normalize_kp(question_knowledge(r.get("title")))
        correct = 1 if str(r.get("correct")) == "1" else 0
        quest_by_stu[name].append({"qid": r.get("qid"), "title": r.get("title"), "kp": kp, "correct": correct})
        quest_by_kp[kp]["n"] += 1
        quest_by_kp[kp]["ac"] += correct

    return {
        "date": date, "gname": gname,
        "member_count": len(members),
        "members": [m.get("username") for m in members if m.get("username")],
        "coding_total": len(subs), "coding_ac": sum(1 for s in subs if is_ac_status(s.get("status"))),
        "quest_total": len(qrecs), "quest_ac": sum(1 for r in qrecs if str(r.get("correct")) == "1"),
        "coding_by_stu": dict(coding_by_stu), "quest_by_stu": dict(quest_by_stu),
        "coding_by_kp": dict(coding_by_kp), "quest_by_kp": dict(quest_by_kp),
    }

# ---------- 例题思路归纳：同思路只留 1 个代表代码 ----------
def group_codes(codes, teacher_multi, kp, st):
    """返回 [(思路名, 讲解, code, 例题pid, 例题名), ...]
    每个思路的代码都标注它来源的例题（题号+题名）；
    优先用老师历史多思路真实代码；组内无真实代码时该思路跳过；老师整题没 AC 用标准程序"""
    kp_pids, title_map = [], {}
    for name, cs in st["coding_by_stu"].items():
        for dp, c in cs.items():
            if c["kp"] == kp:
                kp_pids.append(dp)
                title_map[dp] = c.get("title") or ""
    cnt = defaultdict(int)
    for p in kp_pids:
        cnt[p] += 1
    if not cnt:
        return []
    pid = max(cnt, key=cnt.get)          # 主例题 = 今天提交最多的题
    ex_title = title_map.get(pid, "")

    # 老师历史多思路真实代码（按提交时间升序）
    teacher_codes = []
    if teacher_multi and teacher_multi.get(pid):
        teacher_codes = [s["code"] for s in teacher_multi[pid]]

    k = KNOWLEDGE.get(kp, {})
    groups = k.get("idea_groups", [])
    result = []
    # 规范过滤：DP/序列类知识点禁止展示 vector 写法（普通数组优先）
    no_vector = kp in ("DP（路径计数）", "数位", "模拟", "分支", "栈队列", "卡特兰数")
    # 组合/卡特兰（表格递推）老师只写纯加法 DP，跳过含乘法 mul 的代码
    no_mul = kp in ("组合（排列）", "栈队列", "卡特兰数")
    if groups and teacher_codes:
        used = set()
        for g in groups:
            hit = None
            for i, code in enumerate(teacher_codes):
                if i in used:
                    continue
                if no_vector and "vector" in code:
                    continue  # 跳过 vector 写法，展示裸数组版
                if no_mul and "mul(" in code:
                    continue  # 跳过含乘法的代码，只展示纯加法版
                if any(kw in code for kw in g.get("keywords", [])):
                    hit = code
                    used.add(i)
                    break
            if hit:
                result.append((g["name"], g["desc"], hit, pid, ex_title))
    elif teacher_codes:
        if no_vector:
            # 挑一个不含 vector 的代表
            for code in teacher_codes:
                if "vector" not in code:
                    result.append(("思路", "同一道题的 AC 写法，思路相同，写法略有差异。", code, pid, ex_title))
                    break
        if not result and teacher_codes:
            result.append(("思路", "同一道题的 AC 写法，思路相同，写法略有差异。", teacher_codes[0], pid, ex_title))
    else:
        # 老师没 AC 的题不输出"标准程序"（例题代码必须是老师真实提交，AI 写的标准程序不进讲义）
        pass
    return result

# ---------- 讲义式 MD（纯知识点整理） ----------
# 伪知识点：客观题标题里抠出来的分类，不是真正的知识点，不写进讲义
_FAKE_KP = {"真题套卷", "计算机基础", "未分类"}
# 用户 2026-08-11 手动从讲义删除的知识点（非主线/未练出），生成时过滤；
# 若后续某天又成为主线，从该集合移除即可
_SKIP_KP = {"数位", "数制转换"}

def gen_md(st, codes, teacher_multi):
    date_md = st['date'].replace("-", "")[2:]
    kp_order = [k for k, _ in sorted(st["coding_by_kp"].items(), key=lambda x: -x[1]["n"])
                if _["n"] and k not in _SKIP_KP and group_codes(codes, teacher_multi, k, st)]
    quest_order = [k for k, _ in sorted(st["quest_by_kp"].items(), key=lambda x: -x[1]["n"])
                   if _["n"] and k not in _FAKE_KP and k not in _SKIP_KP]
    short = {"DP（路径计数）": "dp", "快速幂": "快速幂", "数论（逆元）": "数论",
             "组合（排列）": "组合", "卡特兰数": "卡特兰数", "数位": "数位",
             "栈队列": "栈队列", "模拟": "模拟", "分支": "分支", "图论": "图论",
             "数制转换": "数制转换", "单调栈队列": "单调栈队列"}
    all_kp = kp_order + [k for k in quest_order if k not in kp_order]
    title_names = "、".join(short.get(k, k) for k in all_kp[:6])
    L = [f"# {date_md}更新——{title_names}", ""]

    # 编程题知识点
    for kp in kp_order:
        k = KNOWLEDGE.get(kp, {})
        groups = group_codes(codes, teacher_multi, kp, st)
        if not groups:
            continue  # 老师没 AC 的题无真实代码，整个知识点跳过
        L.append(f"## {kp}")
        L.append("")
        for p in k.get("points", []):
            L.append(f"- {p}")
        L.append("")
        # 例题名字做标题（对齐琦琦风格：`### 3442 较大的数`），方法一/二/三做子标题
        pid, ex_title = groups[0][3], groups[0][4]
        L.append(f"### `{pid}` {ex_title}")
        L.append("")
        for name, desc, code, _, _ in groups:
            code = norm_code_style(code)
            L.append(f"#### {name}")
            L.append("")
            for line in desc.split("\n"):
                if line.startswith("  - "):      # 子层级：缩进 4 空格
                    L.append(f"    - {line[4:]}")
                elif line.startswith("    - "):  # 更深层级：缩进 8 空格
                    L.append(f"        - {line[6:]}")
                else:
                    L.append(f"- {line}")
            L.append("")
            L.append("```cpp")
            L.append(code)
            L.append("```")
            L.append("")
        for p in k.get("pits", []):
            L.append(f"- {p}")
        L.append("")
        L.append("---")
        L.append("")

    # 客观题知识点
    if quest_order:
        L.append("## 客观题知识点")
        L.append("")
        for kp in quest_order:
            k = KNOWLEDGE.get(kp, {})
            L.append(f"### {kp}")
            L.append("")
            for p in k.get("points", []):
                L.append(f"- {p}")
            for p in k.get("pits", []):
                L.append(f"- {p}")
            L.append("")
        L.append("---")
        L.append("")

    return "\n".join(L)

# ---------- HTML ----------
def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def gen_html(st, codes, teacher_multi):
    kp_order = [k for k, _ in sorted(st["coding_by_kp"].items(), key=lambda x: -x[1]["n"])
                if _["n"] and k not in _SKIP_KP and group_codes(codes, teacher_multi, k, st)]
    quest_order = [k for k, _ in sorted(st["quest_by_kp"].items(), key=lambda x: -x[1]["n"])
                   if _["n"] and k not in _FAKE_KP and k not in _SKIP_KP]
    blocks = []
    for kp in kp_order:
        k = KNOWLEDGE.get(kp, {})
        pts = "".join(f"<li>{esc(p)}</li>" for p in k.get("points", []))
        pits = "".join(f"<li>{esc(p)}</li>" for p in k.get("pits", []))
        ghtml = ""
        groups = group_codes(codes, teacher_multi, kp, st)
        if not groups:
            continue
        pid, ex_title = groups[0][3], groups[0][4]
        ghtml += f"<h3>📝 <code>{esc(pid)}</code> {esc(ex_title)}</h3>"
        for name, desc, code, _, _ in groups:
            code = norm_code_style(code)
            ghtml += (f"<h4>{esc(name)}</h4>"
                      f"<p>{esc(desc)}</p><pre>{esc(code)}</pre>")
        blocks.append(f"<div class='kp-block'><h3>📖 {esc(kp)}</h3><ul>{pts}</ul>{ghtml}<ul>{pits}</ul></div>")
    if quest_order:
        qhtml = ""
        for kp in quest_order:
            k = KNOWLEDGE.get(kp, {})
            pts = "".join(f"<li>{esc(p)}</li>" for p in k.get("points", []))
            pits = "".join(f"<li>{esc(p)}</li>" for p in k.get("pits", []))
            qhtml += f"<div class='kp-block'><h3>📖 {esc(kp)}</h3><ul>{pts}{pits}</ul></div>"
        blocks.append(f"<h2>客观题知识点</h2>{qhtml}")
    date_md = st['date'].replace("-", "")[2:]
    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>{esc(date_md)}更新 知识点讲义</title>
<style>
body{{font-family:'PingFang SC','Microsoft YaHei',sans-serif;margin:0;padding:32px;background:#fff;color:#333}}
h1{{font-size:22px;border-bottom:3px solid #e53935;padding-bottom:8px}}
h2{{font-size:17px;margin-top:28px;color:#c62828}}
h3{{font-size:15px;margin:10px 0}}
.kp-block{{border:1px solid #e0e0e0;border-left:4px solid #e53935;border-radius:6px;padding:10px 16px;margin:12px 0;background:#fffdf7}}
.kp-block pre{{background:#f5f5f5;border-radius:6px;padding:10px;font-size:13px;overflow-x:auto;white-space:pre-wrap;word-break:break-all}}
code{{background:#f5f5f5;border-radius:4px;padding:1px 5px}}
</style></head><body>
<h1>📚 {esc(date_md)}更新——知识点讲解</h1>
{''.join(blocks)}
</body></html>"""

# ---------- 微信一段话（家长群口吻） ----------
def gen_wechat(st):
    kp = sorted(st["coding_by_kp"].items(), key=lambda x: -x[1]["n"])[:3]
    parts = [f"📚{st['date']}学习小结（{st['gname']}）"]
    parts.append(f"今天班里{st['member_count']}位同学共提交编程题{st['coding_total']}次、客观题{st['quest_total']}题，大家都很投入👍")
    if kp:
        names = "、".join(f"{k}" for k, v in kp if v["n"])
        parts.append(f"主要练了：{names}。知识点讲解讲义已发群里，课下记得敲一遍模板～")
    parts.append("有问题随时私信琦琦老师，明天课上统一讲！")
    return "\n".join(parts)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", nargs="?", default="/tmp/wechat-md/data.json")
    ap.add_argument("codes", nargs="?", default="/tmp/wechat-md/codes.json")
    ap.add_argument("teacher", nargs="?", default="/tmp/wechat-md/teacher_multi_codes.json")
    ap.add_argument("--out-dir", default="/tmp/wechat-md")
    args = ap.parse_args()
    with open(args.data, encoding="utf-8") as f:
        data = json.load(f)
    codes = {}
    if os.path.exists(args.codes):
        with open(args.codes, encoding="utf-8") as f:
            codes = json.load(f)
    teacher_multi = {}
    if os.path.exists(args.teacher):
        with open(args.teacher, encoding="utf-8") as f:
            teacher_multi = json.load(f)
    st = build_stats(data)
    os.makedirs(args.out_dir, exist_ok=True)
    date_md = st['date'].replace("-", "")[2:]
    base = os.path.join(args.out_dir, f"{date_md}更新-知识点")
    with open(base + ".md", "w", encoding="utf-8") as f:
        f.write(gen_md(st, codes, teacher_multi))
    with open(base + ".html", "w", encoding="utf-8") as f:
        f.write(gen_html(st, codes, teacher_multi))
    with open(base + "-微信总结.txt", "w", encoding="utf-8") as f:
        f.write(gen_wechat(st))
    print(f"[ok] 输出到 {base}.md / .html / -微信总结.txt")

if __name__ == "__main__":
    main()
