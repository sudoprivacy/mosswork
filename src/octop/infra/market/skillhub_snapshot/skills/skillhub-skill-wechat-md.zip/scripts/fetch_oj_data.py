#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_oj_data.py — 拉取 192 OJ 指定班级今日做题数据
数据源:
  1. 班级成员:  GET /api/group/get-member-list?gid=<gid>        (需登录)
  2. 编程题提交: GET /api/get-submission-list?username=<名>      (匿名, 需分页)
  3. 题目标签:   GET /api/get-problem-detail?problemId=WLX<pid> (需登录, 取 tags)
  4. 客观题记录: question_record 表 join question 表             (需 SSH + MySQL, 按班级成员 uid 过滤)

输出: JSON (成员 / 编程题提交(仅今日, 含 tags) / 客观题记录(仅今日) / 题目知识点聚合)
用法:
  python3 fetch_oj_data.py --gid 1014 [--date 2026-08-11] [--out /tmp/wechat-md/data.json] [--no-questions]
  python3 fetch_oj_data.py --group-name "CSP-J/S暑期集训2608" [--out ...]   # 自动搜 gid
依赖: python3 标准库 + curl; 客观题需要本机 ssh 免密到 192.144.128.63
"""
import argparse, json, os, ssl, subprocess, sys, time, urllib.request, urllib.parse
from datetime import datetime, timedelta, timezone
from pathlib import Path

def _load_env_local():
    env_path = Path(__file__).resolve().parent.parent / ".env.local"
    if not env_path.is_file():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip())

_load_env_local()

_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE  # 192 为自签名/IP 证书, 同 curl -k

HOST = os.environ.get("OJ_HOST", "https://192.144.128.63")
USERNAME = os.environ.get("OJ_LOGIN_USER", "")
PASSWORD = os.environ.get("OJ_LOGIN_PASSWORD", "")
SSH_HOST = os.environ.get("OJ_SSH_HOST", "root@192.144.128.63")
MYSQL_CONTAINER = os.environ.get("OJ_MYSQL_CONTAINER", "qiqioj-mysql")
MYSQL_DB = os.environ.get("OJ_MYSQL_DB", "hoj")
UTC = timezone.utc
LOCAL = timezone(timedelta(hours=8), "CST")

def http_json(url, token=None, timeout=30, retries=3):
    req = urllib.request.Request(url)
    if token:
        req.add_header("Authorization", token)
    for i in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=_CTX) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            if i == retries - 1:
                raise
            time.sleep(1.5 * (i + 1))

def login():
    if not USERNAME or not PASSWORD:
        sys.exit("Set OJ_LOGIN_USER and OJ_LOGIN_PASSWORD (see skills/wechat-md/env.example)")
    body = json.dumps({"username": USERNAME, "password": PASSWORD}).encode()
    req = urllib.request.Request(HOST + "/api/login", data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30, context=_CTX) as r:
        return r.headers.get("Oj-Token") or r.headers.get("Authorization")

def get_members(token, gid):
    out, page = [], 1
    while True:
        d = http_json(f"{HOST}/api/group/get-member-list?limit=100&currentPage={page}&gid={gid}", token)
        recs = (d.get("data") or {}).get("records") or []
        out.extend(recs)
        if len(recs) < 100:
            break
        page += 1
    return out

def find_gid_by_name(token, name):
    d = http_json(f"{HOST}/api/get-group-list?limit=50&currentPage=1&keyword={urllib.parse.quote(name)}")
    for g in (d.get("data") or {}).get("records") or []:
        if g.get("name") == name:
            return g
    return None

def find_group_by_id(token, gid):
    d = http_json(f"{HOST}/api/get-group-list?limit=100&currentPage=1")
    for g in (d.get("data") or {}).get("records") or []:
        if g.get("id") == gid:
            return g
    return None

def get_submissions(username, date_obj):
    """匿名拉某用户全部提交, 过滤出本地日期 date_obj 当天的 (submitTime 为 UTC)"""
    day_start_local = datetime(date_obj.year, date_obj.month, date_obj.day, tzinfo=LOCAL)
    day_start_utc = day_start_local.astimezone(UTC)
    day_end_utc = day_start_utc + timedelta(days=1)
    out, page = [], 1
    while True:
        d = http_json(f"{HOST}/api/get-submission-list?limit=100&currentPage={page}&username={urllib.parse.quote(username)}&completeProblemID=false")
        data = d.get("data") or {}
        recs = data.get("records") or []
        total = data.get("total") or 0
        for r in recs:
            t = r.get("submitTime")
            if not t:
                continue
            try:
                ts = datetime.fromisoformat(t.replace("Z", "+00:00"))
            except Exception:
                continue
            if day_start_utc <= ts < day_end_utc:
                out.append(r)
        if page * 100 >= total or len(recs) == 0:
            break
        page += 1
        time.sleep(0.3)
    return out

def get_problem_tags(token, display_pid):
    """取单题 tags 名称列表; 失败返回 []"""
    try:
        d = http_json(f"{HOST}/api/get-problem-detail?problemId={urllib.parse.quote(display_pid)}", token)
        p = (d.get("data") or {}).get("problem") or {}
        return [t.get("name") for t in (p.get("tags") or []) if t.get("name")]
    except Exception:
        return []

def ssh_query(sql):
    """SSH 到服务器 docker exec mysql 执行只读 SQL, 返回行字典列表"""
    remote = (
        "PW=$(tr -d '\\n\\r' < /opt/hoj-build/.credentials/mysql-root); "
        f"docker exec -e MYSQL_PWD=\"$PW\" {MYSQL_CONTAINER} mysql -uroot {MYSQL_DB} "
        f"--default-character-set=utf8mb4 -e \"{sql}\""
    )
    cmd = ["ssh", "-o", "ConnectTimeout=10", "-o", "StrictHostKeyChecking=no", SSH_HOST, remote]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            print("[warn] ssh 查询失败:", r.stderr.strip()[:200], file=sys.stderr)
            return []
        return parse_mysql_output(r.stdout)
    except Exception as e:
        print("[warn] ssh 不可用:", e, file=sys.stderr)
        return []

def parse_mysql_output(text):
    lines = [l for l in text.strip().splitlines() if l.strip()]
    if not lines:
        return []
    headers = [h.strip() for h in lines[0].split("\t")]
    rows = []
    for l in lines[1:]:
        cells = l.split("\t")
        rows.append({headers[i]: (cells[i].strip() if i < len(cells) else "") for i in range(len(headers))})
    return rows

TAGS_CACHE_FILE = "/tmp/wechat-md/tags_cache.json"

def load_tags_cache():
    try:
        with open(TAGS_CACHE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_tags_cache(cache):
    try:
        with open(TAGS_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
    except Exception:
        pass

def get_question_records(member_uids, date_obj):
    """客观题记录: question_record join question, 按班级成员 uid 过滤, 仅当日"""
    if not member_uids:
        return []
    day_start = f"{date_obj.year}-{date_obj.month:02d}-{date_obj.day:02d}"
    uid_list = ",".join("'" + u.replace("'", "''") + "'" for u in member_uids)
    sql = (f"SELECT qr.uid, qr.qid, qr.correct, qr.score, qr.create_time, q.title "
           f"FROM question_record qr LEFT JOIN question q ON qr.qid=q.id "
           f"WHERE qr.uid IN ({uid_list}) AND DATE(qr.create_time)='{day_start}' "
           f"ORDER BY qr.create_time")
    return ssh_query(sql)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gid", type=int, help="班级 gid (优先)")
    ap.add_argument("--group-name", help="班级名, 自动搜索 gid (如 CSP-J/S暑期集训2608)")
    ap.add_argument("--date", help="本地日期 YYYY-MM-DD, 默认今天")
    ap.add_argument("--out", default="/tmp/wechat-md/data.json")
    ap.add_argument("--no-questions", action="store_true", help="跳过客观题(不 SSH)")
    args = ap.parse_args()

    date_obj = datetime.strptime(args.date, "%Y-%m-%d") if args.date else datetime.now(LOCAL)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)

    token = login()
    print("[ok] 登录成功", file=sys.stderr)

    if args.gid:
        gid = args.gid
        ginfo = find_group_by_id(token, gid) or {"gid": gid}
    else:
        g = find_gid_by_name(token, args.group_name) if args.group_name else None
        if not g:
            sys.exit("[err] 未找到班级, 请用 --gid 或正确的 --group-name")
        gid, ginfo = g["id"], g
    print(f"[ok] 班级: {ginfo.get('name', gid)} (gid={gid})", file=sys.stderr)

    members = get_members(token, gid)
    if not members:
        sys.exit("[err] 班级无成员")
    print(f"[ok] 成员 {len(members)} 人", file=sys.stderr)

    # 编程题提交 (今日)
    subs, tags_cache = [], load_tags_cache()
    for m in members:
        name = m.get("username")
        ms = get_submissions(name, date_obj)
        print(f"  - {name}: {len(ms)} 条提交", file=sys.stderr)
        for s in ms:
            dp = s.get("displayPid")
            if dp and dp not in tags_cache:
                tags_cache[dp] = get_problem_tags(token, dp)
                time.sleep(0.2)
            s["tags"] = tags_cache.get(dp, [])
        subs.extend(ms)
    save_tags_cache(tags_cache)
    print(f"[ok] 编程题提交(今日): {len(subs)} 条", file=sys.stderr)

    # 客观题记录 (今日)
    qrecords = []
    if not args.no_questions:
        member_uids = [m.get("uid") for m in members if m.get("uid")]
        qrecords = get_question_records(member_uids, date_obj)
        print(f"[ok] 客观题记录(今日): {len(qrecords)} 条", file=sys.stderr)

    # 知识点聚合: 按题 (displayPid -> tags), 客观题按 title 前缀推测 (如 CSPJ-xxxx)
    result = {
        "date": date_obj.strftime("%Y-%m-%d"),
        "group": ginfo,
        "gid": gid,
        "members": [{"uid": m.get("uid"), "username": m.get("username")} for m in members],
        "coding_subs": subs,
        "question_records": qrecords,
        "tag_stats": {},
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"[ok] 数据已写入 {args.out}", file=sys.stderr)

if __name__ == "__main__":
    main()
