#!/usr/bin/env python3
"""Fetch a 编程派 (biancheng.love) project, its code, and its paimon doc.

Credentials come from env BC_USER / BC_PASS (never hard-code them).
Usage:
  BC_USER=... BC_PASS=... python3 fetch_biancheng.py --project 447068 --out-dir /tmp/bc
"""
import argparse, json, os, sys, urllib.parse, urllib.request, http.cookiejar

API = "https://api.biancheng.love"
ASSET = "https://asset.biancheng.love"


def session():
    jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    user = os.environ.get("BC_USER"); pwd = os.environ.get("BC_PASS")
    if not user or not pwd:
        sys.exit("set BC_USER / BC_PASS")
    body = json.dumps({"username": user, "password": pwd}).encode()
    req = urllib.request.Request(API + "/login", data=body,
                                 headers={"Content-Type": "application/json"})
    with opener.open(req, timeout=20) as r:
        data = json.loads(r.read().decode())
    if data.get("status") != "ok":
        sys.exit(f"login failed: {data}")
    return opener, data


def get(opener, url):
    with opener.open(url, timeout=30) as r:
        return r.read()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--out-dir", default="/tmp/bc")
    a = ap.parse_args()
    opener, me = session()
    os.makedirs(a.out_dir, exist_ok=True)
    pid = str(a.project)
    info = json.loads(get(opener, f"{API}/project/info/{pid}"))
    project = json.loads(get(opener, f"{ASSET}/sands/{pid}/project.json"))
    paimon = json.loads(get(opener, f"{API}/python/paimon/{pid}"))
    for name, obj in [("info", info), ("project", project), ("paimon", paimon)]:
        with open(os.path.join(a.out_dir, f"{pid}_{name}.json"), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=1)
    print("login:", me.get("nickName"), me.get("userId"))
    print("project:", project.get("title"), "id", project.get("projectId"), "ratio", project.get("ratio"))
    for node in project.get("codeTree", [{}])[0].get("children", []):
        code = node.get("code", "")
        print(f"code file: {node.get('title')} key={node.get('key')} lines={code.count(chr(10)) + 1}")
    pdata = (paimon.get("data") or {}).get("paimon")
    print("paimon:", "empty" if not pdata else f"{len(pdata)} bytes")
    print("saved to", a.out_dir)


if __name__ == "__main__":
    main()
