#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_teacher_multi.py — 拉取指定老师对当天各题的历史【所有不同思路】AC 代码，按思路去重存本地

铁律：例题代码必须是老师真实提交；同一题不同思路都保留，同思路只留 1 个代表（按代码去注释去空白后签名判重）。
老师 OJ 用户名必须由调用方传入（--teacher），禁止脚本内写死。

用法:
  python3 fetch_teacher_multi.py --teacher 七七 [--codes ...] [--out ...]
输出:
  teacher_multi_codes.json = { pid: [ {submitId, code, submitTime}, ... 按提交时间升序 ], ... }
"""
import argparse, json, re, sys, time, urllib.parse
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from fetch_oj_data import HOST, http_json, login

def norm_code(code):
    """代码签名：去注释、去空白，用于判断是否同一思路"""
    if not code:
        return ""
    c = re.sub(r"//[^\n]*", "", code)
    c = re.sub(r"/\*.*?\*/", "", c, flags=re.S)
    return re.sub(r"\s+", "", c)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--teacher", required=True, help="老师 OJ 用户名（如 七七），必填")
    ap.add_argument("--codes", default="/tmp/wechat-md/codes.json")
    ap.add_argument("--out", default="/tmp/wechat-md/teacher_multi_codes.json")
    args = ap.parse_args()
    teacher = (args.teacher or "").strip()
    if not teacher:
        print("[err] --teacher 不能为空", file=sys.stderr)
        sys.exit(1)

    codes = json.load(open(args.codes, encoding="utf-8"))
    pids = list(codes.get("problems", {}).keys())
    if not pids:
        print("[err] codes.json 无题目，先跑 fetch_codes.py")
        sys.exit(1)

    token = login()
    out = {}
    print(f"[ok] 例题老师账号: {teacher}", file=sys.stderr)
    for pid in pids:
        subs = []
        page = 1
        while True:
            url = (f"{HOST}/api/get-submission-list?limit=100&currentPage={page}"
                   f"&username={urllib.parse.quote(teacher)}&completeProblemID=false&problemID={pid}")
            d = http_json(url)
            data = d.get("data") or {}
            recs = data.get("records") or []
            subs.extend(recs)
            if page * 100 >= (data.get("total") or 0) or not recs:
                break
            page += 1
            time.sleep(0.15)
        acs = [s for s in subs if s.get("status") == 0]
        acs.sort(key=lambda s: s.get("submitTime") or "")
        seen, versions = {}, []
        for s in acs:
            d = http_json(f"{HOST}/api/get-submission-detail?submitId={s['submitId']}", token)
            code = ((d.get("data") or {}).get("submission") or {}).get("code") or ""
            sig = norm_code(code)
            if sig and sig not in seen:
                seen[sig] = 1
                versions.append({"submitId": s["submitId"], "code": code, "submitTime": s.get("submitTime")})
            time.sleep(0.2)
        out[pid] = versions
        print(f"[ok] {pid} {codes['problems'][pid].get('title','')}: 老师历史AC {len(acs)} 条 → {len(versions)} 种思路", file=sys.stderr)
        time.sleep(0.3)

    json.dump(out, open(args.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"[ok] saved {args.out}（{len(out)} 题）", file=sys.stderr)

if __name__ == "__main__":
    main()
