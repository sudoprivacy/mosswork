#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_codes.py — 爬取班级成员（含老师）在【今天/指定日期】做过的题的提交代码，按「思路」去重，存本地备用

铁律（用户要求）：
  每次做任务，只爬【今天】做题涉及的题目的所有提交代码（一道题可能有很多次提交）；
  按思路去重（同一题不同解法都留，重复提交合并），保存到本地备用；
  写 md 时例题代码必须用真实提交的源码，不瞎编。

用法:
  python3 fetch_codes.py --gid 1014 [--date 2026-08-11] [--out /tmp/wechat-md/codes.json] [--limit-per-pid 8]
  python3 fetch_codes.py --group-name "CSP-J/S暑期集训2608"

输出 JSON 结构:
{
  "date": "2026-08-11",
  "gid": 1014,
  "group": {...},
  "users": [...],
  "problems": {
     "WLX3496": {
        "title": "【模板】快速幂",
        "solutions": [           # 按思路去重后的解法列表
           {"username":"七七","submitId":1264933,"status":0,"score":100,"ac":true,
            "submitTime":"...","code":"...", "sig":"..."}  # sig = 思路指纹(去注释去空白)
        ]
     }
  }
}
"""
import argparse, json, os, re, sys, time, urllib.parse
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fetch_oj_data import (HOST, http_json, login, get_members,
                           find_gid_by_name, find_group_by_id, LOCAL, UTC)

def norm_code(code):
    """代码规范化：去注释、去空白/换行，得到思路指纹"""
    if not code:
        return ""
    c = re.sub(r"//[^\n]*", "", code)
    c = re.sub(r"/\*.*?\*/", "", c, flags=re.S)
    c = re.sub(r"\s+", "", c)
    return c

def get_all_subs(username):
    """拉某用户全部提交（分页）；username 需 quote"""
    out, page = [], 1
    while True:
        url = (f"{HOST}/api/get-submission-list?limit=100&currentPage={page}"
               f"&username={urllib.parse.quote(username)}&completeProblemID=false")
        d = http_json(url)
        data = d.get("data") or {}
        recs = data.get("records") or []
        total = data.get("total") or 0
        out.extend(recs)
        if page * 100 >= total or not recs:
            break
        page += 1
        time.sleep(0.12)
    return out

def get_contest_subs(token, cid):
    """读取比赛编程提交；自由练习列表不包含 cid 非 0 的提交。"""
    out, page = [], 1
    while True:
        url = (f"{HOST}/api/contest/v2/{cid}/programming-submissions"
               f"?limit=100&currentPage={page}")
        d = http_json(url, token)
        data = d.get("data") or {}
        recs = data.get("records") or data.get("list") or []
        if isinstance(data, list):
            recs = data
        out.extend(recs)
        total = data.get("total") if isinstance(data, dict) else len(recs)
        print(f"  [contest {cid}] page {page} +{len(recs)} total={total}", file=sys.stderr)
        if not recs or (isinstance(total, int) and page * 100 >= total):
            break
        page += 1
        time.sleep(0.12)
        if page > 80:
            break
    return out

def get_code(token, submit_id):
    d = http_json(f"{HOST}/api/get-submission-detail?submitId={submit_id}", token)
    sub = (d.get("data") or {}).get("submission") or {}
    return sub.get("code") or ""

def fetch_codes(gid, group_name, out_path, limit_per_pid, date_str, cid=None):
    token = login()
    print("[ok] 登录成功", file=sys.stderr)

    if gid:
        ginfo = find_group_by_id(token, gid) or {"gid": gid}
    else:
        g = find_gid_by_name(token, group_name)
        if not g:
            sys.exit("[err] 未找到班级")
        gid, ginfo = g["id"], g

    members = get_members(token, gid)
    print(f"[ok] 班级 {ginfo.get('name', gid)} 成员 {len(members)} 人", file=sys.stderr)

    # 日期边界（UTC）
    day = datetime.strptime(date_str, "%Y-%m-%d")
    day_start_local = datetime(day.year, day.month, day.day, tzinfo=LOCAL)
    day_start_utc = day_start_local.astimezone(UTC)
    day_end_utc = day_start_utc + timedelta(days=1)

    # 只收集当天的提交 → 得到当天涉及的题目集合
    today_subs, problems = [], {}
    for m in members:
        name = m.get("username")
        subs = get_all_subs(name)
        for s in subs:
            t = s.get("submitTime")
            if not t:
                continue
            try:
                ts = datetime.fromisoformat(t.replace("Z", "+00:00"))
            except Exception:
                continue
            if not (day_start_utc <= ts < day_end_utc):
                continue
            today_subs.append(s)
            dp = s.get("displayPid") or ""
            if dp:
                problems.setdefault(dp, {"title": s.get("title") or "", "subs": []})
                problems[dp]["subs"].append(s)
        print(f"  - {name}: 当天 {sum(1 for s in subs if s.get('submitTime') and day_start_utc <= datetime.fromisoformat(s['submitTime'].replace('Z','+00:00')) < day_end_utc)} 条", file=sys.stderr)

    if cid:
        csubs = get_contest_subs(token, cid)
        names = {m.get("username") for m in members}
        n_add = 0
        for s in csubs:
            if s.get("username") not in names:
                continue
            dp = s.get("displayPid") or s.get("display_pid") or ""
            if not dp:
                continue
            today_subs.append(s)
            problems.setdefault(dp, {"title": s.get("title") or "", "subs": []})
            problems[dp]["subs"].append(s)
            n_add += 1
        print(f"[ok] 比赛 cid={cid} 并入 {n_add} 条（班级成员）", file=sys.stderr)
    print(f"[ok] 当天共 {len(today_subs)} 条提交，涉及 {len(problems)} 道题，开始拉代码去重…", file=sys.stderr)

    for dp, p in problems.items():
        subs = sorted(p["subs"], key=lambda x: x.get("submitTime") or "", reverse=True)
        seen_sig = {}
        for s in subs:
            code = get_code(token, s["submitId"])
            sig = norm_code(code)
            if not sig:
                continue
            sol = {
                "username": s.get("username"), "submitId": s.get("submitId"),
                "status": s.get("status"), "score": s.get("score"),
                "submitTime": s.get("submitTime"), "code": code, "sig": sig,
                "ac": s.get("status") == 0,
            }
            if sig in seen_sig:
                old = seen_sig[sig]
                if (sol["ac"] and not old["ac"]) or (sol["ac"] == old["ac"] and (sol.get("score") or 0) > (old.get("score") or 0)):
                    seen_sig[sig] = sol
            else:
                seen_sig[sig] = sol
        sols = sorted(seen_sig.values(), key=lambda x: (not x["ac"], -(x.get("score") or 0)))
        p["solutions"] = sols[:limit_per_pid]
        print(f"  {dp} {p['title']}: {len(subs)} 提交 → {len(sols)} 思路", file=sys.stderr)

    result = {
        "date": date_str,
        "gid": gid, "group": ginfo,
        "users": [m.get("username") for m in members],
        "problems": {dp: {"title": p["title"], "solutions": p["solutions"]} for dp, p in problems.items()},
    }
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
    print(f"[ok] 已保存 {out_path}", file=sys.stderr)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--gid", type=int)
    ap.add_argument("--group-name")
    ap.add_argument("--out", default="/tmp/wechat-md/codes.json")
    ap.add_argument("--limit-per-pid", type=int, default=8)
    ap.add_argument("--date", default=datetime.now(LOCAL).strftime("%Y-%m-%d"))
    ap.add_argument("--cid", type=int, help="比赛 id；同时合并班级成员在该比赛中的提交")
    args = ap.parse_args()
    fetch_codes(args.gid, args.group_name, args.out, args.limit_per_pid, args.date, args.cid)
