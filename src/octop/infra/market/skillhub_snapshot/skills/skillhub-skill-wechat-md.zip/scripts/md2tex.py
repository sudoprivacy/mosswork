#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
md2tex.py — 琦琦风格讲义 md → 专业 LaTeX
支持：标题、列表（嵌套）、有序列表、表格、代码块、$/$/$ 公式、==高亮==、**加粗**、---
用法:
  python3 md2tex.py <input.md> <output.tex>
  python3 md2tex.py <input.md> <output.tex> --header "CSP-J · 周六09:00"
"""
import re, sys, argparse


def esc_latex(s):
    s = s.replace('\\', r'\textbackslash{}')
    for ch in ['&', '%', '$', '#', '_', '{', '}']:
        s = s.replace(ch, '\\' + ch)
    s = s.replace('~', r'\textasciitilde{}')
    s = s.replace('^', r'\textasciicircum{}')
    return s


_INLINE_RE = re.compile(
    r'(\$\$[^$]+\$\$)'     # 行内偶发的 $$...$$（少见）
    r'|(\$[^$\n]+\$)'      # 行内公式
    r'|`([^`\n]+)`'
    r'|\*\*(.+?)\*\*'
    r'|==(.+?)=='
)


def inline(s):
    parts = []

    def _cb(m):
        if m.group(1):
            body = m.group(1)[2:-2]
            parts.append(r'\[' + body + r'\]')
            return '\x01%d\x02' % (len(parts) - 1)
        if m.group(2):
            parts.append(m.group(2))
            return '\x01%d\x02' % (len(parts) - 1)
        if m.group(3):
            # 行内代码：保留原文字符，只转义 LaTeX 特殊符；箭头等用文字替代以免进 math
            t = m.group(3)
            t = (t.replace('→', '->')
                  .replace('↔', '<->')
                  .replace('…', '...'))
            t = t.replace('\\', r'\textbackslash{}')
            for ch in ['&', '%', '#', '_', '{', '}']:
                t = t.replace(ch, '\\' + ch)
            t = t.replace('^', r'\textasciicircum{}')
            t = t.replace('~', r'\textasciitilde{}')
            t = t.replace('$', r'\$')
            parts.append(r'\texttt{' + t + '}')
            return '\x01%d\x02' % (len(parts) - 1)
        if m.group(4):
            parts.append(r'\textbf{' + inline(m.group(4)) + '}')
            return '\x01%d\x02' % (len(parts) - 1)
        if m.group(5):
            inner = m.group(5).strip()
            # 「易错点」→ 讲义风标签；其余 == == → 荧光笔高亮
            if inner in ('易错点', '易错', '易错提示'):
                parts.append(r'\pitlabel')
            else:
                parts.append(r'\markhl{' + inline(inner) + '}')
            return '\x01%d\x02' % (len(parts) - 1)
        return m.group(0)

    tmp = _INLINE_RE.sub(_cb, s)
    # 仅对保护区之外的纯文本做 Unicode → LaTeX 与转义
    out = []
    i = 0
    _circled = {
        '①': '(1)', '②': '(2)', '③': '(3)', '④': '(4)', '⑤': '(5)',
        '⑥': '(6)', '⑦': '(7)', '⑧': '(8)', '⑨': '(9)', '⑩': '(10)',
    }
    while i < len(tmp):
        if tmp[i] == '\x01':
            j = tmp.find('\x02', i)
            out.append(tmp[i:j + 1])
            i = j + 1
            continue
        # 读到下一段纯文本
        j = tmp.find('\x01', i)
        if j < 0:
            j = len(tmp)
        chunk = tmp[i:j]
        for a, b in _circled.items():
            chunk = chunk.replace(a, b)
        chunk = (chunk.replace('　', ' ')
                      .replace('–', '-'))
        chunk = esc_latex(chunk)
        # esc 之后再插入命令，避免反斜杠被二次转义
        chunk = (chunk.replace('→', r'$\rightarrow$')
                      .replace('↔', r'$\leftrightarrow$')
                      .replace('…', r'\ldots{}')
                      .replace('≠', r'$\neq$'))
        out.append(chunk)
        i = j
    tmp = ''.join(out)
    for i, p in enumerate(parts):
        tmp = tmp.replace('\x01%d\x02' % i, p)
    return tmp


def fig_unit_square():
    return r"""
\begin{center}
\begin{tikzpicture}[scale=2.0, >=stealth]
  \draw[->, thick, gray!70!black] (-0.35,0) -- (1.55,0) node[right] {$x$};
  \draw[->, thick, gray!70!black] (0,-0.35) -- (0,1.55) node[above] {$y$};
  \draw[thick, brand!80!black] (0,0) rectangle (1,1);
  \fill (0,0) circle (1.3pt) node[below left, font=\scriptsize] {$(0,0)$ 偶偶};
  \fill (1,0) circle (1.3pt) node[below right, font=\scriptsize] {$(1,0)$ 奇偶};
  \fill (0,1) circle (1.3pt) node[above left, font=\scriptsize] {$(0,1)$ 偶奇};
  \fill (1,1) circle (1.3pt) node[above right, font=\scriptsize] {$(1,1)$ 奇奇};
  \node[below=12pt, font=\small\bfseries\color{brand!80!black}] at (0.5,0)
    {二维：边长 $1$ 的正方形，$4$ 种奇偶类型};
\end{tikzpicture}
\end{center}
""".strip().split('\n')


def fig_unit_cube():
    return r"""
\begin{center}
\begin{tikzpicture}[scale=1.35, >=stealth]
  \def\ax{1.0}\def\ay{0.55}\def\az{1.0}
  \newcommand{\Pxyz}[3]{({#1*\ax - #2*\ay}, {#3*\az + #2*\ay*0.35})}
  \draw[->, thick, gray!70!black] \Pxyz{-0.25}{0}{0} -- \Pxyz{1.55}{0}{0} node[right] {$x$};
  \draw[->, thick, gray!70!black] \Pxyz{0}{-0.25}{0} -- \Pxyz{0}{1.55}{0} node[above right] {$y$};
  \draw[->, thick, gray!70!black] \Pxyz{0}{0}{-0.25} -- \Pxyz{0}{0}{1.55} node[above] {$z$};
  \draw[dashed, gray!60] \Pxyz{0}{0}{0} -- \Pxyz{0}{1}{0};
  \draw[dashed, gray!60] \Pxyz{0}{1}{0} -- \Pxyz{1}{1}{0};
  \draw[dashed, gray!60] \Pxyz{0}{1}{0} -- \Pxyz{0}{1}{1};
  \draw[thick, brand!80!black] \Pxyz{0}{0}{0} -- \Pxyz{1}{0}{0} -- \Pxyz{1}{0}{1} -- \Pxyz{0}{0}{1} -- cycle;
  \draw[thick, brand!80!black] \Pxyz{1}{0}{0} -- \Pxyz{1}{1}{0} -- \Pxyz{1}{1}{1} -- \Pxyz{1}{0}{1};
  \draw[thick, brand!80!black] \Pxyz{0}{0}{1} -- \Pxyz{0}{1}{1} -- \Pxyz{1}{1}{1};
  \fill \Pxyz{0}{0}{0} circle (1.4pt) node[below left, font=\scriptsize] {$(0,0,0)$};
  \fill \Pxyz{1}{0}{0} circle (1.4pt) node[below right, font=\scriptsize] {$(1,0,0)$};
  \fill \Pxyz{0}{1}{0} circle (1.4pt) node[left, font=\scriptsize] {$(0,1,0)$};
  \fill \Pxyz{1}{1}{0} circle (1.4pt) node[right, font=\scriptsize] {$(1,1,0)$};
  \fill \Pxyz{0}{0}{1} circle (1.4pt) node[above left, font=\scriptsize] {$(0,0,1)$};
  \fill \Pxyz{1}{0}{1} circle (1.4pt) node[above right, font=\scriptsize] {$(1,0,1)$};
  \fill \Pxyz{0}{1}{1} circle (1.4pt) node[above left, font=\scriptsize] {$(0,1,1)$};
  \fill \Pxyz{1}{1}{1} circle (1.4pt) node[above right, font=\scriptsize] {$(1,1,1)$};
  \node[below=6pt, font=\small\bfseries\color{brand!80!black}] at \Pxyz{0.7}{0.3}{-0.35}
    {三维：边长 $1$ 的立方体，$8$ 种奇偶类型};
\end{tikzpicture}
\end{center}
""".strip().split('\n')


def fig_dfs_diamond():
    return r"""
\begin{center}
\begin{tikzpicture}[scale=1.15, every node/.style={circle, draw=brand!80!black, thick, inner sep=1.6pt, font=\small\bfseries}]
  \node (a) at (0,3.2) {a};
  \node (b) at (-1.5,2.1) {b};
  \node (c) at (1.5,2.1) {c};
  \node (d) at (0,1.0) {d};
  \node (e) at (-1.5,-0.1) {e};
  \node (f) at (1.5,-0.1) {f};
  \node (g) at (0,-1.2) {g};
  \draw[thick, brand!70!black] (a)--(b) (a)--(c) (b)--(d) (c)--(d)
    (d)--(e) (d)--(f) (e)--(g) (f)--(g);
\end{tikzpicture}
\end{center}
""".strip().split('\n')


def fig_huffman_tree():
    return r"""
\begin{center}
\begin{tikzpicture}[
    intern/.style={circle, draw=brand!80!black, thick, inner sep=1.4pt, font=\scriptsize\bfseries},
    leaf/.style={draw=brand!80!black, rounded corners=2pt, thick, inner sep=1.8pt, align=center, font=\scriptsize},
    el/.style={font=\scriptsize\bfseries, inner sep=0.5pt},
    level distance=14.5mm,
    level 1/.style={sibling distance=58mm},
    level 2/.style={sibling distance=36mm},
    level 3/.style={sibling distance=24mm},
    level 4/.style={sibling distance=18mm},
    edge from parent/.style={draw, thick, brand!70!black}
  ]
  \node[intern] {根}
    child {node[intern] {0.51}
      child {node[intern] {0.28}
        child {node[intern] {0.13}
          child {node[leaf] {B\\0.09\\\texttt{0000}}
            edge from parent node[el, left] {0}}
          child {node[leaf] {A\\0.04\\\texttt{0001}}
            edge from parent node[el, right] {1}}
          edge from parent node[el, left] {0}}
        child {node[leaf] {E\\0.15\\\texttt{001}}
          edge from parent node[el, right] {1}}
        edge from parent node[el, left] {0}}
      child {node[intern] {0.23}
        child {node[leaf] {C\\0.11\\\texttt{010}}
          edge from parent node[el, left] {0}}
        child {node[leaf] {D\\0.12\\\texttt{011}}
          edge from parent node[el, right] {1}}
        edge from parent node[el, right] {1}}
      edge from parent node[el, above left] {0}}
    child {node[leaf] {F\\0.49\\\texttt{1}}
      edge from parent node[el, above right] {1}};
\end{tikzpicture}\\[2pt]
{\footnotesize 圆圈是合并后的频率；左走记 0、右走记 1。叶子上是字符、频率、编码（与选项 C 一致）。}
\end{center}
""".strip().split('\n')


def fig_rebuild_btree():
    return r"""
\begin{center}
\begin{tikzpicture}[
    scale=0.95,
    every node/.style={circle, draw=brand!80!black, thick, inner sep=1.5pt, font=\small\bfseries},
    level distance=11mm,
    sibling distance=16mm
  ]
  \node {a}
    child {node {b}}
    child {node {c}
      child {node {d}
        child {node {f}}
        child {node {g}
          child {node {h}}
          child {node {i}}
        }
      }
      child {node {e}}
    };
\end{tikzpicture}
\end{center}
""".strip().split('\n')


def fig_csp_folder():
    return r"""
\begin{center}
\begin{tikzpicture}[
    root/.style={draw=brand, line width=1.1pt, rounded corners=3pt,
      fill=brand!16, minimum width=3.8cm, minimum height=0.85cm,
      font=\normalsize\bfseries, inner sep=3pt},
    box/.style={draw=brand!80!black, thick, rounded corners=2pt,
      fill=brand!6, align=center, inner sep=4pt, text width=2.45cm,
      font=\small, anchor=north},
    link/.style={brand!70!black, thick, -{Stealth[length=1.6mm]}}
  ]
  \node[root] (z) at (0,0) {准考证号};
  \node[box] (a) at (-6.55,-1.15) {\textbf{advance}\\[2pt]
    {\ttfamily\footnotesize advance.cpp}\\{\ttfamily\footnotesize advance.in}\\{\ttfamily\footnotesize advance.out}};
  \node[box] (c) at (-3.27,-1.15) {\textbf{cards}\\[2pt]
    {\ttfamily\footnotesize cards.cpp}\\{\ttfamily\footnotesize cards.in}\\{\ttfamily\footnotesize cards.out}};
  \node[box] (b) at (0,-1.15) {\textbf{beads}\\[2pt]
    {\ttfamily\footnotesize beads.cpp}\\{\ttfamily\footnotesize beads.in}\\{\ttfamily\footnotesize beads.out}};
  \node[box] (u) at (3.27,-1.15) {\textbf{burger}\\[2pt]
    {\ttfamily\footnotesize burger.cpp}\\{\ttfamily\footnotesize burger.in}\\{\ttfamily\footnotesize burger.out}};
  \node[box] (r) at (6.55,-1.15) {\textbf{report}\\[2pt]
    {\ttfamily\footnotesize report.cpp}\\{\ttfamily\footnotesize report.in}\\{\ttfamily\footnotesize report.out}};
  \draw[link] (z.south) -- (a.north);
  \draw[link] (z.south) -- (c.north);
  \draw[link] (z.south) -- (b.north);
  \draw[link] (z.south) -- (u.north);
  \draw[link] (z.south) -- (r.north);
\end{tikzpicture}\\[2pt]
{\footnotesize 最外层是准考证号。每个方块是一道题的文件夹，里面三个文件。\texttt{freopen} 只写文件名，不要把文件夹名再写一遍。}
\end{center}
""".strip().split('\n')


def fig_dfs_grid_stack():
    return r"""
\begin{center}
\begin{tikzpicture}[
    cell/.style={
      draw=brand!80!black, thick,
      minimum width=1.28cm, minimum height=1.08cm,
      inner sep=1pt, outer sep=0pt, align=center, font=\small
    },
    on/.style={cell, fill=brand!16},
    off/.style={cell, fill=white},
    arr/.style={-{Stealth[length=1.5mm]}, thick, brand!70!black}
  ]
  \node[on]  (c11) at (0.00, 2.60) {$(1,1)$};
  \node[on]  (c12) at (1.95, 2.60) {$(1,2)$};
  \node[on]  (c13) at (3.90, 2.60) {$(1,3)$};
  \node[on]  (c14) at (5.85, 2.60) {$(1,4)$};
  \node[off] (c21) at (0.00, 0.80) {$(2,1)$};
  \node[off] (c22) at (1.95, 0.80) {$(2,2)$};
  \node[off] (c23) at (3.90, 0.80) {$(2,3)$};
  \node[on]  (c24) at (5.85, 0.80) {$(2,4)$};
  \node[off] (c31) at (0.00,-1.00) {$(3,1)$};
  \node[off] (c32) at (1.95,-1.00) {$(3,2)$};
  \node[off] (c33) at (3.90,-1.00) {$(3,3)$};
  \node[on]  (c34) at (5.85,-1.00) {$(3,4)$};
  \node[font=\scriptsize\bfseries\color{brand!80!black}, above=5pt] at (c11.north) {左上};
  \node[font=\scriptsize\bfseries\color{brand!80!black}, below=5pt] at (c34.south) {右下};
  \draw[arr] (c11.east) -- (c12.west);
  \draw[arr] (c12.east) -- (c13.west);
  \draw[arr] (c13.east) -- (c14.west);
  \draw[arr] (c14.south) -- (c24.north);
  \draw[arr] (c24.south) -- (c34.north);
  \begin{scope}[shift={(8.50,-1.35)}]
    \node[font=\small\bfseries\color{brand!80!black}] at (1.10, 5.18) {栈（当前路径）};
    \draw[thick, brand!80!black, fill=brand!10] (0,0) rectangle (2.20,4.80);
    \foreach \y in {0.80,1.60,2.40,3.20,4.00} {
      \draw[thick, brand!80!black] (0,\y) -- (2.20,\y);
    }
    \node at (1.10,4.40) {$(3,4)$};
    \node at (1.10,3.60) {$(2,4)$};
    \node at (1.10,2.80) {$(1,4)$};
    \node at (1.10,2.00) {$(1,3)$};
    \node at (1.10,1.20) {$(1,2)$};
    \node at (1.10,0.40) {$(1,1)$};
    \node[font=\scriptsize, right=5pt] at (2.20,4.40) {栈顶};
    \node[font=\scriptsize, right=5pt] at (2.20,0.40) {栈底};
    \node[font=\footnotesize] at (1.10,-0.42) {$6=3+4-1$ 格};
  \end{scope}
\end{tikzpicture}\\[2pt]
{\footnotesize 涂色格子是一条最长路径：先向右走到第 $4$ 列，再向下走到第 $3$ 行。}
\end{center}
""".strip().split('\n')


# md 里不方便画的图：按小标题自动插入到 tex（不必写进 md）
_AUTO_FIGS = {
    '先二维': fig_unit_square,
    '再三维立方体（本题）': fig_unit_cube,
    '从 a 出发的无向图': fig_dfs_diamond,
    '画出哈夫曼树': fig_huffman_tree,
    '画出这棵二叉树': fig_rebuild_btree,
    '三行四列矩阵': fig_dfs_grid_stack,
    '目录长这样': fig_csp_folder,
}

_AUTO_FIG_NEEDSPACE = {
    '从 a 出发的无向图': '7.2cm',
    '画出哈夫曼树': '11.2cm',
    '画出这棵二叉树': '8.6cm',
    '三行四列矩阵': '10.2cm',
    '目录长这样': '7.6cm',
}


def parse_table_row(line):
    line = line.strip().strip('|')
    cells = [c.strip() for c in line.split('|')]
    return cells


def is_sep_row(line):
    s = line.strip().strip('|').replace(' ', '')
    return bool(s) and all(set(c) <= set('-:') and c for c in s.split('|'))


def _half_dim(dim):
    m = re.match(r'([0-9.]+)(.*)', dim.strip())
    val = float(m.group(1)) / 2
    unit = m.group(2)
    if val == int(val):
        val = int(val)
    return f'{val}{unit}'


def table_to_tex(rows, overview=False, overview_pad=None):
    if not rows:
        return []
    ncol = max(len(r) for r in rows)
    # 归一列数
    rows = [r + [''] * (ncol - len(r)) for r in rows]
    colspec = '|' + 'l|' * ncol if ncol <= 2 else '|' + 'l' * (ncol - 1) + 'X|'
    # 简单：全用 l，宽表用 p
    if ncol >= 3:
        # 最后一列弹性
        widths = {
            3: r'|p{1.6cm}|p{3.2cm}|p{9.2cm}|',
            4: r'|c|p{3.8cm}|p{3.6cm}|p{4.6cm}|',
            6: r'|c|c|c|c|c|c|',
            7: r'|c|c|c|c|c|c|c|',
        }
        colspec = widths.get(ncol, '|' + 'l|' * ncol)
    elif ncol == 2:
        if overview and overview_pad:
            colspec = (r'|>{\raggedright\arraybackslash}S{m{2.8cm}}|'
                       r'>{\raggedright\arraybackslash}S{m{12.8cm}}|')
        elif overview:
            colspec = r'|p{2.8cm}|p{12.8cm}|'
        else:
            colspec = r'|p{3.2cm}|p{12.4cm}|'
    else:
        colspec = '|' + 'c|' * ncol

    stretch = '1.22' if overview else '1.25'
    out = [
        r'\vspace{2pt}' if overview else r'\vspace{4pt}',
        r'\begin{center}',
        r'\renewcommand{\arraystretch}{' + stretch + '}',
    ]
    if overview and overview_pad:
        half = _half_dim(overview_pad)
        out.append(r'\begingroup')
        out.append(r'\setlength{\cellspacetoplimit}{' + half + '}')
        out.append(r'\setlength{\cellspacebottomlimit}{' + half + '}')
    out += [
        r'\begin{tabular}{' + colspec + '}',
        r'\hline',
    ]
    # header
    out.append(' & '.join(inline(c) for c in rows[0]) + r' \\')
    out.append(r'\hline')
    for r in rows[1:]:
        out.append(' & '.join(inline(c) for c in r) + r' \\')
        out.append(r'\hline')
    out.append(r'\end{tabular}')
    if overview and overview_pad:
        out.append(r'\endgroup')
    out += [
        r'\end{center}',
        r'\vspace{4pt}',
        '',
    ]
    return out


def preamble(header_left='CSP-J · 周六09:00', header_right='琦琦老师'):
    return r"""\documentclass[11pt,a4paper]{article}
\usepackage[UTF8,heading=true]{ctex}
\usepackage[top=2.0cm,bottom=2.0cm,left=2.0cm,right=2.0cm,headheight=18pt]{geometry}
\usepackage{amsmath,amssymb,mathtools}
\usepackage{enumitem}
\usepackage{listings}
\usepackage{xcolor}
\usepackage{fancyhdr}
\usepackage{titlesec}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{tabularx}
\usepackage{array}
\usepackage{cellspace}
\usepackage{hyperref}
\usepackage{tcolorbox}
\tcbuselibrary{skins,breakable}

\definecolor{brand}{RGB}{16,110,180}
\definecolor{highlight}{RGB}{16,140,202}
\definecolor{hlbg}{RGB}{255,236,179}
\definecolor{hlfg}{RGB}{90,55,10}
\definecolor{pit}{RGB}{180,70,40}
\definecolor{codebg}{RGB}{246,248,250}
\definecolor{codeframe}{RGB}{210,216,222}
\definecolor{ansbg}{RGB}{232,245,233}
\definecolor{tipbg}{RGB}{255,243,224}
\definecolor{rulegray}{RGB}{180,180,180}

\usepackage{tikz}
\usepackage{needspace}
\usetikzlibrary{calc,positioning,arrows.meta}

% typora 式高亮：淡黄底深字；易错用赭石加粗（对齐 C++/GESP 讲义，不要白字蓝底）
\newcommand{\markhl}[1]{%
  \colorbox{hlbg}{\hspace{0.12em}\strut\textcolor{hlfg}{#1}\hspace{0.12em}}%
}
\newcommand{\pitlabel}{\textcolor{pit}{\bfseries 易错}}

\lstset{
  basicstyle=\ttfamily\small,
  backgroundcolor=\color{codebg},
  frame=single,
  rulecolor=\color{codeframe},
  breaklines=true,
  columns=fullflexible,
  keepspaces=true,
  language=C++,
  commentstyle=\color{gray!70!black},
  keywordstyle=\color{brand},
  stringstyle=\color{red!55!black},
  showstringspaces=false,
  tabsize=4,
  xleftmargin=3pt, xrightmargin=3pt,
  aboveskip=8pt, belowskip=8pt,
}

\setlist[itemize]{nosep, leftmargin=1.5em, itemsep=2pt, topsep=3pt}
\setlist[enumerate]{nosep, leftmargin=1.7em, itemsep=2pt, topsep=3pt, label=\arabic*.}
\setlist[itemize,2]{leftmargin=1.3em, label=\textbullet}

\pagestyle{fancy}
\fancyhf{}
% 页眉文字贴近横线：自绘「文字 + 小间距 + 线」，关掉默认 headrule
\renewcommand{\headrulewidth}{0pt}
\fancyhead[C]{%
  \vbox{%
    \hbox to \headwidth{%
      \small\textcolor{brand}{\textbf{""" + header_left + r"""}}\hfil
      \small\textcolor{gray}{""" + header_right + r"""}%
    }%
    \vskip 0.2pt
    {\color{brand}\hrule height 0.4pt}%
  }%
}
\fancyfoot[C]{\small\textcolor{gray}{\thepage}}
\setlength{\headheight}{18pt}
\setlength{\headsep}{10pt}

\titleformat{\section}{\Large\bfseries\color{brand}}{}{0pt}{}[\vspace{2pt}{\color{rulegray}\titlerule[0.6pt]}]
\titleformat{\subsection}{\large\bfseries\color{brand!80!black}}{}{0pt}{}
\titleformat{\subsubsection}{\normalsize\bfseries\color{brand!70!black}}{}{0pt}{}
\titlespacing*{\section}{0pt}{14pt}{8pt}
\titlespacing*{\subsection}{0pt}{10pt}{4pt}
\titlespacing*{\subsubsection}{0pt}{12pt}{6pt}

\parindent=0pt
\parskip=3pt
\hypersetup{colorlinks=true, linkcolor=brand, urlcolor=brand}

% 方法一/二/三 等四级标题：独立成行，上下留白，避免贴代码/列表
\newcommand{\methodhead}[1]{%
  \par\nopagebreak
  \vspace{12pt}%
  {\normalsize\bfseries\color{brand!70!black}#1}\par\nopagebreak
  \vspace{6pt}%
}

% 答案高亮条
\newcommand{\ansline}[1]{%
  \par\vspace{6pt}%
  \begin{tcolorbox}[colback=ansbg, colframe=green!45!black, boxrule=0.4pt,
    left=6pt, right=6pt, top=3pt, bottom=3pt, arc=2pt, sharp corners=southwest]
    \textbf{#1}
  \end{tcolorbox}%
  \vspace{2pt}%
}

\begin{document}
"""


def convert(md_path, tex_path, header_left='CSP-J · 周六09:00', header_right='琦琦老师'):
    lines = open(md_path, encoding='utf-8').read().split('\n')
    tex = [preamble(header_left, header_right)]

    in_code = False
    code_lang = 'C++'
    code_buf = []
    in_display_math = False
    math_buf = []
    # list stack: each entry is ('itemize'|'enumerate', depth)
    list_stack = []

    def close_lists_to(depth):
        """关掉 depth 及以上的列表（保留更浅的）。"""
        while list_stack and list_stack[-1][1] >= depth:
            kind, _ = list_stack.pop()
            tex.append(r'\end{' + kind + '}')

    def close_all_lists():
        close_lists_to(0)

    def open_list(kind, depth):
        # 只关掉更深的；同层同类型则继续
        while list_stack and list_stack[-1][1] > depth:
            tex.append(r'\end{' + list_stack.pop()[0] + '}')
        if list_stack and list_stack[-1][1] == depth:
            if list_stack[-1][0] != kind:
                tex.append(r'\end{' + list_stack.pop()[0] + '}')
                tex.append(r'\begin{' + kind + '}')
                list_stack.append((kind, depth))
            return
        tex.append(r'\begin{' + kind + '}')
        list_stack.append((kind, depth))

    i = 0
    n = len(lines)
    last_h2 = ''
    # 总览独占该日首页；不同日子的 # 更新 自动另起一页
    exclusive_overview = False
    overview_pad = None
    seen_h1 = False

    def end_exclusive_overview():
        nonlocal exclusive_overview
        if exclusive_overview:
            close_all_lists()
            tex.append(r'\clearpage')
            tex.append('')
            exclusive_overview = False

    while i < n:
        raw = lines[i]
        line = raw.rstrip()
        stripped = line.strip()

        # 显式分页：首页独立、阶段一从下一页开始
        if stripped == '<!-- pagebreak -->':
            close_all_lists()
            tex.append(r'\clearpage')
            tex.append('')
            i += 1
            continue

        # display math $$ ... $$
        if stripped == '$$':
            if not in_display_math:
                close_all_lists()
                in_display_math = True
                math_buf = []
            else:
                in_display_math = False
                tex.append(r'\[')
                tex.append('\n'.join(math_buf))
                tex.append(r'\]')
                tex.append('')
            i += 1
            continue
        if in_display_math:
            math_buf.append(stripped)
            i += 1
            continue

        # code fence
        mcode = re.match(r'^[-*]?\s*```([a-zA-Z]*)\s*$', stripped)
        if mcode:
            if not in_code:
                close_all_lists()
                in_code = True
                lang = (mcode.group(1) or 'cpp').lower()
                if lang in ('latex', 'tikz', 'tex'):
                    code_lang = '__raw__'
                elif lang in ('cpp', 'c++', 'c'):
                    code_lang = 'C++'
                elif lang.startswith('py'):
                    code_lang = 'Python'
                else:
                    code_lang = ''
                code_buf = []
            else:
                in_code = False
                if code_lang == '__raw__':
                    tex.append(r'\begin{center}')
                    tex.extend(code_buf)
                    tex.append(r'\end{center}')
                    tex.append('')
                elif code_lang:
                    tex.append(r'\begin{lstlisting}[language=' + code_lang + ']')
                    tex.extend(code_buf)
                    tex.append(r'\end{lstlisting}')
                    tex.append('')
                else:
                    tex.append(r'\begin{lstlisting}')
                    tex.extend(code_buf)
                    tex.append(r'\end{lstlisting}')
                    tex.append('')
            i += 1
            continue
        if in_code:
            code_buf.append(line)
            i += 1
            continue

        # table block
        if stripped.startswith('|') and i + 1 < n and is_sep_row(lines[i + 1]):
            close_all_lists()
            rows = [parse_table_row(stripped)]
            i += 2  # skip header + sep
            while i < n and lines[i].strip().startswith('|'):
                rows.append(parse_table_row(lines[i].rstrip()))
                i += 1
            tex.extend(table_to_tex(rows, overview=exclusive_overview, overview_pad=overview_pad))
            continue

        # headings
        mh = re.match(r'^(#{1,4})\s*(.*)$', line)
        if mh:
            close_all_lists()
            level = len(mh.group(1))
            raw_title = mh.group(2).strip()
            title = inline(raw_title)
            cmd = {
                1: r'\section*',
                2: r'\subsection*',
                3: r'\subsubsection*',
                4: r'\methodhead',
            }[level]
            if level == 1:
                if seen_h1:
                    end_exclusive_overview()
                    tex.append(r'\clearpage')
                    tex.append('')
                seen_h1 = True
            if level == 2:
                last_h2 = raw_title
                if '知识点总览' in raw_title:
                    exclusive_overview = True
                    overview_pad = None
                else:
                    end_exclusive_overview()
                    tex.append(r'\Needspace{3.6cm}')
            tex.append(cmd + '{' + title + '}')
            tex.append('')
            # 自动插图（md 不写 TikZ）
            for key, maker in _AUTO_FIGS.items():
                if key in raw_title:
                    ns = _AUTO_FIG_NEEDSPACE.get(key)
                    if ns:
                        tex.append(r'\Needspace{' + ns + '}')
                    tex.extend(maker())
                    tex.append('')
                    break
            i += 1
            continue

        # images
        im = re.match(r'^!\[([^\]]*)\]\(([^)]+)\)\s*$', stripped)
        if im:
            close_all_lists()
            alt, path = im.group(1).strip(), im.group(2).strip()
            tex.append(r'\begin{center}')
            tex.append(r'\includegraphics[width=0.86\textwidth]{' + path + '}')
            if alt:
                tex.append(r'\\[3pt]{\footnotesize\color{gray}' + inline(alt) + '}')
            tex.append(r'\end{center}')
            tex.append('')
            i += 1
            continue

        # hr
        if re.match(r'^-{3,}$', stripped):
            close_all_lists()
            if exclusive_overview:
                tex.append(r'\clearpage')
                tex.append('')
                exclusive_overview = False
            else:
                tex.append(r'\vspace{10pt}{\color{rulegray}\hrule height 0.4pt}\vspace{12pt}')
                tex.append('')
            i += 1
            continue

        if not stripped:
            i += 1
            continue

        pad_m = re.match(r'^<!--\s*overview-pad:\s*([0-9.]+pt)\s*-->\s*$', stripped)
        if pad_m:
            overview_pad = pad_m.group(1)
            i += 1
            continue

        # answer line → special box
        if stripped.startswith('**答案') or stripped.startswith('**答：') or stripped.startswith('**答:'):
            close_all_lists()
            m_ans = re.match(r'^\*\*(.+)\*\*\s*$', stripped)
            body = inline(m_ans.group(1)) if m_ans else inline(stripped)
            tex.append(r'\ansline{' + body + '}')
            tex.append('')
            i += 1
            continue

        # unordered list (with indent depth)
        lm = re.match(r'^(\s*)[-*]\s+(.*)$', line)
        if lm:
            spaces = len(lm.group(1).replace('\t', '  '))
            depth = spaces // 2  # 0,1,2...
            open_list('itemize', depth)
            tex.append(r'\item ' + inline(lm.group(2).strip()))
            i += 1
            continue

        # ordered list
        om = re.match(r'^(\s*)\d+\.\s+(.*)$', line)
        if om:
            spaces = len(om.group(1).replace('\t', '  '))
            depth = spaces // 2
            open_list('enumerate', depth)
            tex.append(r'\item ' + inline(om.group(2).strip()))
            i += 1
            continue

        # normal paragraph
        close_all_lists()
        tex.append(inline(stripped))
        tex.append('')
        i += 1

    close_all_lists()
    tex.append(r'\end{document}')
    open(tex_path, 'w', encoding='utf-8').write('\n'.join(tex))
    return tex_path


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('md')
    ap.add_argument('tex')
    ap.add_argument('--header', default='CSP-J · 周六09:00')
    ap.add_argument('--author', default='琦琦老师')
    args = ap.parse_args()
    convert(args.md, args.tex, args.header, args.author)
    print('[ok]', args.tex)
