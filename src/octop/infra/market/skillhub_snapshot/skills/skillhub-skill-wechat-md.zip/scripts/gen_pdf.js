// gen_pdf.js — 知识点报告 HTML → A4 PDF 渲染
// 用法: node gen_pdf.js [html路径] [pdf输出路径]
// 依赖: playwright-core（npm install playwright-core），用本机 Edge 无头渲染
const { chromium } = require('playwright-core');
const path = require('path');

const EDGE = '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge';

const htmlPath = process.argv[2];
const pdfPath = process.argv[3] || htmlPath.replace(/\.html$/i, '.pdf');

if (!htmlPath) {
  console.error('用法: node gen_pdf.js <report.html> [report.pdf]');
  process.exit(1);
}

(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: EDGE });
  const page = await browser.newPage();
  await page.goto('file://' + path.resolve(htmlPath), { waitUntil: 'networkidle' });
  await page.pdf({
    path: pdfPath,
    format: 'A4',
    printBackground: true,
    margin: { top: '0', right: '0', bottom: '0', left: '0' },
  });
  console.log('PDF generated OK:', pdfPath);
  await browser.close();
})();
