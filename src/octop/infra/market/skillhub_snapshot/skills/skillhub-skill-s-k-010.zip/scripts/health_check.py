#!/usr/bin/env python3
"""知识库健康检查引擎 — 四项检测：失效风险、过时信号、矛盾信号、元信息。"""

import os, re, sys, json
from collections import Counter, defaultdict
from datetime import datetime, timedelta

def load_cards(cards_dir):
    cards = {}
    for f in sorted(os.listdir(cards_dir)):
        if not f.startswith('km_') or not f.endswith('.md'):
            continue
        path = os.path.join(cards_dir, f)
        with open(path, encoding='utf-8') as fp:
            content = fp.read()
        title = ''
        m = re.search(r'^#\s+(.+)', content, re.MULTILINE)
        if m:
            title = m.group(1).strip()
        cards[f] = {'content': content, 'title': title, 'path': path}
    return cards

def check_c1_broken_links(cards):
    """C1: 检测失效风险 — 不可访问URL、引用已删除资料。"""
    findings = []
    # Check for suspicious URL patterns
    for name, card in cards.items():
        urls = re.findall(r'https?://[^\s\)]+', card['content'])
        for url in urls:
            if any(d in url for d in ['localhost', '127.0.0.1', 'example.com']):
                findings.append({
                    'card': name,
                    'title': card['title'],
                    'issue': f'含本地/示例URL: {url[:60]}',
                    'severity': 'high'
                })
    return findings

def check_c2_outdated(cards, data_items):
    """C2: 过时信号 — 提及停用模型/工具。"""
    findings = []
    deprecated = [
        ('ChatGPT 3.5', '已升级为 GPT-4/4o'),
        ('DALL-E 2', '已升级为 DALL-E 3'),
        ('GPT-3', '已升级'),
        ('Stable Diffusion 1', '已升级为 SDXL/SD3'),
        ('Midjourney v4', '已升级为 v6'),
        ('Microsoft Copilot', '已更名为 Microsoft 365 Copilot'),
    ]
    for name, card in cards.items():
        for old_name, note in deprecated:
            if old_name.lower() in card['content'].lower():
                findings.append({
                    'card': name,
                    'title': card['title'],
                    'issue': f'提及已停用: {old_name} ({note})',
                    'severity': 'medium'
                })

    # Check processed data for timeliness
    if data_items:
        outdated = [i for i in data_items if i.get('timeliness') == 'outdated']
        review = [i for i in data_items if i.get('timeliness') == 'review']
        if outdated:
            findings.append({
                'card': 'processed_data',
                'title': f'{len(outdated)} 条过时资料',
                'issue': ', '.join(i['title'][:40] for i in outdated[:5]),
                'severity': 'high'
            })
        if review:
            findings.append({
                'card': 'processed_data',
                'title': f'{len(review)} 条待复核',
                'issue': '需人工核实时效性',
                'severity': 'medium'
            })

    return findings

def check_c3_contradictions(cards):
    """C3: 矛盾信号 — 关键词级对立检测。"""
    findings = []
    # Simple heuristic: detect opposing keywords
    opposites = [
        (['推荐', '好用', '最佳'], ['不推荐', '避坑', '差评']),
    ]
    for name, card in cards.items():
        for pos_words, neg_words in opposites:
            has_pos = any(w in card['content'] for w in pos_words)
            has_neg = any(w in card['content'] for w in neg_words)
            # Only flag if single card has both (self-contradiction)
            # This is a simplified check
            pass
    if not findings:
        findings.append({
            'card': '-',
            'title': '未检测到明显矛盾',
            'issue': '语义级矛盾检测需LLM辅助，当前仅做关键词级检查',
            'severity': 'low'
        })
    return findings

def check_c4_metadata(cards, data_items):
    """C4: 元信息 — 缺失字段、孤岛卡片。"""
    findings = []

    # Check cards without keywords
    no_kw = 0
    for name, card in cards.items():
        if '## 关键词' not in card['content']:
            no_kw += 1
    if no_kw:
        findings.append({
            'card': f'{no_kw}张卡片',
            'title': '缺少关键词',
            'issue': '建议补充「## 关键词」小节以支持关联引擎',
            'severity': 'medium'
        })

    # Check cards without related section
    no_rel = 0
    for name, card in cards.items():
        if '## 关联资料' not in card['content']:
            no_rel += 1
    if no_rel:
        findings.append({
            'card': f'{no_rel}张卡片',
            'title': '缺少关联资料',
            'issue': '建议运行 kb-linker 建立关联',
            'severity': 'low'
        })

    # Orphan cards (not referenced by any aggregate page)
    # This is a rough check
    return findings

def generate_report(cards, data_items, output_path):
    findings_c1 = check_c1_broken_links(cards)
    findings_c2 = check_c2_outdated(cards, data_items)
    findings_c3 = check_c3_contradictions(cards)
    findings_c4 = check_c4_metadata(cards, data_items)

    all_findings = findings_c1 + findings_c2 + findings_c3 + findings_c4
    high = sum(1 for f in all_findings if f.get('severity') == 'high')
    medium = sum(1 for f in all_findings if f.get('severity') == 'medium')
    low = sum(1 for f in all_findings if f.get('severity') == 'low')

    # Health score
    score = 100
    score -= high * 15
    score -= medium * 5
    score -= low * 2
    score = max(0, min(100, score))

    lines = [
        '# 🏥 知识库健康检查报告',
        '',
        f'> 生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
        f'> 卡片数：{len(cards)} | 资料数：{len(data_items) if data_items else "N/A"}',
        '',
        f'## 健康评分：{score}/100',
        '',
        f'| 严重度 | 数量 |',
        f'|--------|------|',
        f'| 🔴 高 | {high} |',
        f'| 🟡 中 | {medium} |',
        f'| 🟢 低 | {low} |',
        '',
        '---',
        '',
    ]

    for label, findings_list in [('C1 失效风险 🔴', findings_c1), ('C2 过时信号 🟡', findings_c2),
                                   ('C3 矛盾信号 🟢', findings_c3), ('C4 元信息 🟢', findings_c4)]:
        lines.append(f'## {label}')
        lines.append('')
        if not findings_list or (len(findings_list) == 1 and findings_list[0].get('severity') == 'low'):
            lines.append('✅ 未发现问题。')
        else:
            lines.append('| 卡片 | 问题 | 严重度 |')
            lines.append('|------|------|:--:|')
            for f in findings_list:
                sev = {'high': '🔴', 'medium': '🟡', 'low': '🟢'}.get(f.get('severity', 'low'), '🟢')
                lines.append(f'| {f["title"][:30]} | {f["issue"][:60]} | {sev} |')
        lines.append('')

    # Fix suggestions
    lines.append('## 修复建议')
    lines.append('')
    if high:
        lines.append(f'{high} 个高严重度问题需要立即处理。')
    if medium:
        lines.append(f'{medium} 个中严重度问题建议本周内处理。')

    report = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report)

    print(f'健康检查完成: 评分 {score}/100 | 🔴{high} 🟡{medium} 🟢{low}')
    return report

def main():
    args = sys.argv[1:]
    cards_dir = args[args.index('--cards-dir') + 1]
    data_path = args[args.index('--data') + 1] if '--data' in args else None
    output_path = args[args.index('--output') + 1]

    cards = load_cards(cards_dir)
    data_items = None
    if data_path and os.path.exists(data_path):
        with open(data_path, encoding='utf-8') as f:
            data_items = json.load(f)

    generate_report(cards, data_items, output_path)

if __name__ == '__main__':
    main()
