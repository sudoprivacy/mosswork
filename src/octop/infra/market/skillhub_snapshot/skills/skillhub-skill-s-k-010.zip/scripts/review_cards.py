#!/usr/bin/env python3
"""知识库复盘分析引擎 — 四项核心分析：资产盘点、关键词趋势、孤岛检测、升级建议。"""

import os, re, sys, json
from collections import Counter, defaultdict
from datetime import datetime

def load_cards(cards_dir):
    cards = {}
    for f in sorted(os.listdir(cards_dir)):
        if not f.startswith('km_') or not f.endswith('.md'):
            continue
        path = os.path.join(cards_dir, f)
        with open(path, encoding='utf-8') as fp:
            content = fp.read()
        title = ''
        m = re.search(r'^#\s+(.+)', content, re.MULTILINE)
        if m:
            title = m.group(1).strip()
        # Extract keywords
        kws = []
        kw_m = re.search(r'##\s*关键词\s*\n(.*?)(?=\n##|\n---|\Z)', content, re.DOTALL | re.IGNORECASE)
        if kw_m:
            kws = re.split(r'[、，,\n]', kw_m.group(1))
            kws = [k.strip().lower() for k in kws if k.strip() and len(k.strip()) >= 2]
        cards[f] = {'content': content, 'title': title, 'keywords': kws}
    return cards

def q1_asset_inventory(cards):
    """Q1: 核心资产盘点 — 被引用最多的卡片。"""
    ref_counter = Counter()
    for name, card in cards.items():
        refs = re.findall(r'km_\d+', card['content'])
        for ref in refs:
            ref_counter[ref] += 1

    top = ref_counter.most_common(10)
    # 前缀匹配：cards key 格式为 km_XXX_标题.md，ref 为 km_XXX
    # 不能用 cards.get(ref+'.md') 直接查，会因文件名含标题后缀而 miss
    result = []
    for ref, count in top:
        matched_title = '?'
        for fname, card_data in cards.items():
            if fname.startswith(ref + '_') or fname == ref + '.md':
                matched_title = card_data.get('title', '?')
                break
        result.append((ref, count, matched_title))
    return result

def q2_keyword_trends(cards):
    """Q2: 关键词趋势 — 出现≥2次的关键词。"""
    kw_counter = Counter()
    kw_cards = defaultdict(set)
    for name, card in cards.items():
        for kw in card['keywords']:
            kw_counter[kw] += 1
            kw_cards[kw].add(name)

    # Filter: ≥2 occurrences
    trends = [(kw, count, len(kw_cards[kw])) for kw, count in kw_counter.most_common(20) if count >= 2]
    return trends

def q3_orphan_detection(cards, cards_dir):
    """Q3: 孤岛检测 — 未被关联+未被聚合页引用的卡片。"""
    all_files = set(cards.keys())

    # Build title → filename reverse index for kb-linker title-based references
    # Use list-valued dict to handle duplicate titles (e.g. km_060+km_106 both "NotebookLM 提示词模板")
    title_to_files = {}
    for fname, card in cards.items():
        t = card.get('title', '').strip()
        if t:
            clean = re.sub(r'^[^\w]+', '', t).strip()
            title_to_files.setdefault(clean, []).append(fname)
            title_to_files.setdefault(t, []).append(fname)

    # Cards referenced by others (km_XXX format)
    referenced = set()
    for name, card in cards.items():
        refs = re.findall(r'km_\d+', card['content'])
        for ref in refs:
            ref_file = ref + '.md'
            if ref_file in all_files:
                referenced.add(ref_file)

    # Cards referenced by kb-linker title-based references (关联资料 section)
    # Format: - **{emoji} {title}**  `{keyword}`
    for name, card in cards.items():
        content = card.get('content', '')
        # Find the 关联资料 section
        link_section = re.search(r'##\s*关联资料\s*\n(.*?)(?=\n##|\Z)', content, re.DOTALL)
        if link_section:
            for line in link_section.group(1).split('\n'):
                m = re.match(r'-\s+\*\*([^*]+)\*\*', line.strip())
                if m:
                    ref_title = m.group(1).strip()
                    # Strip leading emoji
                    clean_title = re.sub(r'^[^\w]+', '', ref_title).strip()
                    # Match by title (support duplicate titles via list)
                    if clean_title in title_to_files:
                        referenced.update(title_to_files[clean_title])
                    elif ref_title in title_to_files:
                        referenced.update(title_to_files[ref_title])

    # Also check aggregate pages
    aggs = [f for f in os.listdir(cards_dir)
            if f.startswith('_aggregate_') and f.endswith('.md')]
    for agg in aggs:
        agg_path = os.path.join(cards_dir, agg)
        with open(agg_path, encoding='utf-8') as fp:
            content = fp.read()
        refs = re.findall(r'km_\d+', content)
        for ref in refs:
            ref_file = ref + '.md'
            if ref_file in all_files:
                referenced.add(ref_file)

    orphans = all_files - referenced
    return [(f, cards[f]['title']) for f in sorted(orphans)]

def q4_upgrade_suggestions(cards, data_items, top_n=10):
    """Q4: B→A 升级建议。"""
    if not data_items:
        return []

    upgrade_signals = ['模板', '指南', '工作流', 'SOP', '方法论', '全流程', '手册', '保姆级', '合集']

    b_items = [i for i in data_items if i.get('grade') == 'B']
    candidates = []
    for item in b_items:
        title = item.get('title', '')
        score = sum(1 for sig in upgrade_signals if sig in title)
        if score >= 2:
            candidates.append((score, title, item.get('theme', ''), item.get('kb_name', '')))

    candidates.sort(key=lambda x: -x[0])
    return candidates[:top_n]

def generate_report(cards, data_items, output_path, cards_dir, top_n=10):
    q1 = q1_asset_inventory(cards)
    q2 = q2_keyword_trends(cards)
    q3 = q3_orphan_detection(cards, cards_dir)
    q4 = q4_upgrade_suggestions(cards, data_items, top_n)

    # Grade distribution from data
    grades = Counter(i.get('grade', '?') for i in data_items) if data_items else {}
    output_status = Counter(i.get('output_status', '未处理') for i in data_items) if data_items else {}

    lines = [
        '# 📊 知识库复盘报告',
        '',
        f'> 生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
        f'> 卡片数：{len(cards)} | 资料数：{len(data_items) if data_items else "N/A"}',
        '',
        '## Q1 核心资产盘点',
        '',
        f'**知识卡片**：{len(cards)} 张',
        '',
    ]

    if grades:
        lines.append(f'**等级分布**：A类 {grades.get("A",0)} / B类 {grades.get("B",0)} / C类 {grades.get("C",0)}')
        lines.append('')
    if output_status:
        pending = output_status.get('未处理', 0)
        digested = output_status.get('已提炼', 0)
        converted = output_status.get('已转化', 0)
        total = pending + digested + converted
        lines.append(f'**转化漏斗**：未处理 {pending}（{pending/total*100:.1f}%）→ 已提炼 {digested}（{digested/total*100:.1f}%）→ 已转化 {converted}（{converted/total*100:.1f}%）')
        lines.append('')

    if q1:
        lines.append('### 被引用最多的卡片')
        lines.append('')
        lines.append('| 卡片 | 引用次数 | 标题 |')
        lines.append('|------|:--:|------|')
        for ref, count, title in q1[:5]:
            lines.append(f'| {ref} | {count} | {title[:50]} |')
        lines.append('')

    lines.append('## Q2 关键词趋势')
    lines.append('')
    if q2:
        lines.append('| 关键词 | 出现次数 | 涉及卡片 |')
        lines.append('|------|:--:|:--:|')
        for kw, count, card_count in q2[:10]:
            lines.append(f'| `{kw}` | {count} | {card_count} |')
    lines.append('')

    lines.append('## Q3 孤岛检测')
    lines.append('')
    if q3:
        lines.append(f'未被引用卡片：{len(q3)} 张')
        lines.append('')
        for f, title in q3[:10]:
            lines.append(f'- {f} — {title[:60]}')
        if len(q3) > 10:
            lines.append(f'- ... 及其他 {len(q3)-10} 张')
    else:
        lines.append('✅ 所有卡片均已融入知识网络。')
    lines.append('')

    lines.append('## Q4 B→A 升级建议')
    lines.append('')
    if q4:
        lines.append('| 标题 | 信号得分 | 主题 | 知识库 |')
        lines.append('|------|:--:|------|------|')
        for score, title, theme, kb in q4:
            lines.append(f'| {title[:45]} | {score} | {theme} | {kb} |')
    else:
        lines.append('未发现明确升级候选。')
    lines.append('')

    report = '\n'.join(lines)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report)

    print(f'复盘完成: Q1 资产{len(q1)}项 | Q2 趋势{len(q2)}项 | Q3 孤岛{len(q3)}张 | Q4 升级候选{len(q4)}条')
    return report

def main():
    args = sys.argv[1:]
    cards_dir = args[args.index('--cards-dir') + 1]
    data_path = args[args.index('--data') + 1] if '--data' in args else None
    output_path = args[args.index('--output') + 1]
    top_n = int(args[args.index('--top') + 1]) if '--top' in args else 10

    cards = load_cards(cards_dir)
    data_items = None
    if data_path and os.path.exists(data_path):
        with open(data_path, encoding='utf-8') as f:
            data_items = json.load(f)

    generate_report(cards, data_items, output_path, cards_dir, top_n)

if __name__ == '__main__':
    main()
