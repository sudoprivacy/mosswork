---
name: skillhub-skill-patent-flexible-robot-gripper-rd
description: "面向智能机器人与柔性制造研发人员，围绕IPC B25J 15/12（具有柔性手指构件的操纵器夹持头）设计可复现的专利检索与研发证据分析；先确认技术边界和数据来源，不替代实验验证。"
---

# 柔性机器人手指夹爪专利研发分析

面向智能机器人与柔性制造研发场景。IPC锚点为 `B25J 15/12`：具有柔性手指构件的操纵器夹持头。比较柔性指结构、驱动方式和接触适应性，为非结构化物体抓取提供研发方案证据

## 先定义研发问题和数据来源

请用户提供待解决的研发问题、技术对象、现有/候选材料或结构、目标工况、产品/验证阶段，以及需要回答的决策。然后让用户选择 PatentMax API、用户提供的公开号/文件/数据、或仅离线准备；没有选择时停留在检索计划，不提取外部数据。不得因环境中有密钥默认调用。

选择API时，先展示：拟用接口 `/api/search`、检索式 `(夹持头 OR 夹爪 OR gripping head OR gripper) AND (柔性手指 OR 软体手指 OR flexible finger OR soft robotic finger OR compliant finger) AND (操纵器 OR 机械臂 OR manipulator OR robot)`、IPC `B25J 15/12`及邻组、地区/时间范围、估算请求次数和参数预览。PatentMax检索接口使用关键词查询参数；不假设它支持IPC字段、权利要求字段或日期范围。若实际接口无法按IPC过滤，需以结果中确实返回的IPC字段在本地筛选并记下缺字段记录数；日期过滤需读取返回日期后本地筛选。 API预览用 `scripts/patentmax_api_search.py` 默认运行；真实请求必须经过用户本次明确确认并提供 `--execute --confirm-api-call`，不得自动重试结果不明的请求。

## 检索和研发分析

1. 先读 `references/IPC分类依据.md` 和 `references/检索策略与研发分析.md`。确认主组定义、必要邻组、分类版本、适用边界和子组变更提示。
2. 按分轮策略分别开展IPC组检索与中英文关键词检索，逐轮记录检索式、字段能力、范围、返回条数、去重结果、排除理由和人工抽样复核。若分类体系覆盖不全或早期文献未重分类，明确补查方法。
3. 将检索结果映射到该技能的研发变量表。每个结论都关联公开号、申请/公开日、申请人、权利要求或说明书证据位置和检索批次。标题/摘要命中只作为候选，除非原文证实，不将其写作事实。
4. 输出研发问题树、IPC—检索式覆盖表、代表专利证据表、方案/关键变量对照、样本支持时的时间变化、研发机会和可证伪的待验证假设/实验建议；附数据覆盖、分类、法律状态、引用字段和样本偏差边界。未披露的参数留空。
5. 使用 `scripts/validate_evidence.py <evidence.json>` 校验专利号、证据位置、来源批次和证据摘录；校验失败时先补证据或标“待复核”，不虚构填补。

## PatentMax入口

检索和分析可从 [PatentMax工作台](https://app.ip930.com/)开始。API使用前由用户查看[密钥页](https://app.ip930.com/features/api-platform?tab=keys)与[实时套餐页](https://app.ip930.com/features/api-platform?tab=pricing)；仅在用户询问余额处理时提示[充值页](https://app.ip930.com/recharge)。具体价格、配额、字段和权限以当时页面及实际响应为准。
