---
name: skillhub-skill-build-graph-rag-context-with-neo4j-llm-graph-builder
description: "将有限的文档集转换为Neo4j知识图谱，检查提取的节点和关系，并将其用于基于图谱的RAG。"
---

# 使用Neo4j LLM Graph Builder构建图谱RAG上下文

将有限的文档集转换为Neo4j知识图谱，检查提取的节点和关系，并将其用于基于图谱的RAG。

## 先决条件

Neo4j Database 5.23或更高版本，带有APOC，Python 3.12后端，配置好的LLM提供商凭证，来自上游README的可选前端和Docker部署路径。

## 安装

使用与您的环境匹配的上游安装或设置路径：
- pip install -r requirements.txt -c constraints.txt

来自上游的要求和注意事项：
- ![Python](https://img.shields.io/badge/Python-yellow)
- **Python 3.12或更高版本**（用于本地/独立后端部署）
- 如果使用**Neo4j Desktop**，您需要分别部署后端和前端（不支持docker-compose）。

基本用法或入门笔记：
- Neo4j Database **5.23或更高版本**，并安装APOC。
- 支持**Neo4j Aura**数据库（包括免费层级）。
- 通过复制backend/example.env在后端文件夹中创建一个.env文件。

- Source: https://github.com/1991513ccie-png/skills
- Extracted from upstream docs: https://raw.githubusercontent.com/neo4j-labs/llm-graph-builder/HEAD/README.md

## 文档

- https://github.com/1991513ccie-png/skills
