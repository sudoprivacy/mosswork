#!/usr/bin/env node
// 播客节目大纲 付费脚本：probe / pay / complete 三段
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs';
import path from 'node:path';

const exec = promisify(execFile);
const API_BASE = process.env.PAY_API_BASE || 'http://localhost:8788';
const ENDPOINT = '/podcast-outline';
const SERVICE_NAME = '播客节目大纲';
const PRICE = '9.90';

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i++) {
    if (argv[i].startsWith('--')) {
      args[argv[i].slice(2)] = argv[i + 1];
      i++;
    }
  }
  return args;
}

async function probe(args) {
  const body = {
    input: args.input || '',
  };
  const res = await fetch(API_BASE + ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (res.status === 402) {
    const stateDir = args['state-dir'] || `.state/${Date.now()}`;
    fs.mkdirSync(stateDir, { recursive: true });
    const paymentNeededRaw = res.headers.get('payment-needed');
    const paymentNeeded = JSON.parse(decodeURIComponent(paymentNeededRaw));
    fs.writeFileSync(path.join(stateDir, 'request.json'), JSON.stringify(body));
    fs.writeFileSync(path.join(stateDir, 'payment-needed.json'), JSON.stringify(paymentNeeded, null, 2));
    console.log(JSON.stringify({
      kind: 'payment_required',
      price: PRICE,
      service: SERVICE_NAME,
      out_trade_no: paymentNeeded.out_trade_no,
      state_dir: stateDir,
    }, null, 2));
  } else if (res.ok) {
    console.log(text);
  } else {
    console.error('probe failed:', res.status, text);
    process.exit(1);
  }
}

async function pay(args) {
  const stateDir = args['state-dir'];
  if (!stateDir) { console.error('need --state-dir'); process.exit(1); }
  const paymentNeeded = JSON.parse(fs.readFileSync(path.join(stateDir, 'payment-needed.json'), 'utf8'));
  const request = JSON.parse(fs.readFileSync(path.join(stateDir, 'request.json'), 'utf8'));
  try {
    const { stdout } = await exec('alipay-bot', [
      '402-buyer-pay',
      '--session-id', path.basename(stateDir),
      '--payment-needed', JSON.stringify(paymentNeeded),
      '--intent-summary', `${SERVICE_NAME}`,
    ], { timeout: 5 * 60 * 1000 });
    console.log(stdout);
  } catch (e) {
    console.log(JSON.stringify({
      kind: 'pay_manual',
      hint: 'alipay-bot 未安装。请先执行 npx -y @alipay/agent-payment@latest install。',
      out_trade_no: paymentNeeded.out_trade_no,
      amount: paymentNeeded.amount,
    }, null, 2));
  }
}

async function complete(args) {
  const stateDir = args['state-dir'];
  const paymentNeeded = JSON.parse(fs.readFileSync(path.join(stateDir, 'payment-needed.json'), 'utf8'));
  const request = JSON.parse(fs.readFileSync(path.join(stateDir, 'request.json'), 'utf8'));
  const res = await fetch(API_BASE + ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Payment-Proof': `out_trade_no=${paymentNeeded.out_trade_no}&payment_sign=after_pay`,
    },
    body: JSON.stringify(request),
  });
  console.log(await res.text());
}

const cmd = process.argv[2];
const args = parseArgs(process.argv);
if (cmd === 'probe') await probe(args);
else if (cmd === 'pay') await pay(args);
else if (cmd === 'complete') await complete(args);
else { console.error('usage: probe|pay|complete'); process.exit(1); }
