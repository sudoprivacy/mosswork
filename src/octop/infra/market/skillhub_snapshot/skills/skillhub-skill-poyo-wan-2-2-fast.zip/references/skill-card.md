## Description: <br>
Wan 2.2 Fast video generation on PoYo through poyo.ai, helping agents prepare text-to-video and image-to-video payloads, submit asynchronous tasks, and guide polling or webhook follow-up. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to create PoYo Wan 2.2 Fast video-generation requests, choose the appropriate text-to-video or image-to-video model, and submit or explain asynchronous task workflows. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill submits prompts, image URLs, callback URLs, and generated media metadata to PoYo. <br>
Mitigation: Review payloads before submission and avoid sending confidential prompts, private image URLs, callback URLs, or generated media unless the user trusts PoYo and the callback receiver. <br>
Risk: The PoYo API key is required for submission and could be exposed if used in unsafe environments. <br>
Mitigation: Keep POYO_API_KEY server-side in environment variables or a backend secret manager, and do not place it in browser code, public repositories, logs, screenshots, or chat output. <br>
Risk: The helper can make live video-generation requests when explicitly used with a trusted shell and prepared payload. <br>
Mitigation: Do not make live API calls unless the user explicitly asks and provides a safe server-side environment. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/coolhackboy/skills/poyo-wan-2-2-fast) <br>
- [PoYo Wan 2.2 Fast model page](https://poyo.ai/models/wan-2-2-fast) <br>
- [PoYo Wan 2.2 text-to-video API docs](https://docs.poyo.ai/api-manual/video-series/wan2.2-text-to-video-fast) <br>
- [PoYo Wan 2.2 image-to-video API docs](https://docs.poyo.ai/api-manual/video-series/wan2.2-image-to-video-fast) <br>
- [PoYo API key page](https://poyo.ai/dashboard/api-key) <br>
- [Artifact API reference](artifact/references/api.md) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, code, shell commands, configuration] <br>
**Output Format:** [Markdown with JSON payload examples and inline bash or curl commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include selected model id, request type, payload summary, resolution, aspect ratio, seed, source image count, returned task_id, and polling or webhook next steps.] <br>

## Skill Version(s): <br>
1.0.1 (source: release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
