#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C盘清理 · 扫描结果分级 + 类目钻取器（v6，类目聚合 + 单文件人话版）
-------------------------------------------------
把 storage-analyzer 的 scan.py 原始输出翻译成 build_report.py 需要的 analysis.json。

v6 核心改造（回归原版设计 + 类目单文件钻取）：
- 黄区从"逐真实目录展开"改回"按类目聚合"（如微信/QQ数据、用户文件/下载…），
  每个类目是一张可折叠卡片，符合用户"先看粗、再要细"的渐进式判断流程。
- 类目卡片内嵌 drill_down 预钻取：对类目下最大的目录打开，
  提取该类别下最大的具体文件/文件夹（Top N），
  每条"鱼"自带 child_explain() 生成的简短人话说明 ——
  用户看到的不再是黑盒目录，而是"这是什么、能不能删、删了会怎样"。
- 写入 C盘容量信息到 disk_info 字段，供前端绘制真实仪表盘。

v4 改造（v6 保留）：
- drill_down() 用 os.scandir() 钻取目录取 Top N 子项
- get_disk_info() 用 shutil.disk_usage("C:\\") 取真实 C 盘数据
- v3 安全规则继续保留（缓存子目录提取、绿区收紧、防误伤）
"""
# ══════════════════════════════════════════════════════════════════════════
# 🔥 C盘清理 · 项目基因（六条铁律，改本文件前必读）
# 完整版 + 踩坑档案见: ai-pc-butler/.workbuddy/memory/MEMORY.md
#   ① 绿区绝对安全 · 一键清理（只放可放心删，绝不含个人资料）
#   ② 黄区人话+看一眼 · 决定权在用户（不替用户删，不写废话）
#   ③ 红区不能碰 · 只作卖相展示（绝不提供删除入口）
#   ④ 本机只是开发机 · 必须从全局根治（适用 99% Windows 用户，禁打补丁）
#   ⑤ 动手前回顾历史 · 同类错误不犯第二次
#   ⑥ 清理深度遥遥领先 · 零误删 · 小白友好
# 判定真理源唯一：verdict（safe→绿区 / keep→黄区keep / mixed·unknown→提缓存进绿区+资料留黄区）
# ══════════════════════════════════════════════════════════════════════════
import ctypes
import json
import os
import re
import shutil
import sys
import time
import path_rules  # 缓存识别知识库（BleachBit 路径知识 + 中国软件规则）

HERE = os.path.dirname(os.path.abspath(__file__))

# Windows reparse point 标志（与 scan.py 一致）
_FILE_ATTRIBUTE_REPARSE_POINT = 0x400

# ===== 父子去重时豁免的「容器目录」名（v1.7.83）=====
# 这些目录是「仓库」，不是「商品」：user_profile 锚点会把整个 AppData 吐成一个
# 22GB 单项，若让它参与父子去重，它下面 60+ 个真实软件数据目录（uv / Tencent /
# baidu / Doubao / 各个 -updater …）会被**整体吃掉**，导致几十 GB 既不能清也不能搬。
# 只豁免「短路径」（≤ _DEDUP_CONTAINER_MAX_SEGS 段）避免误伤同名深目录。
_DEDUP_CONTAINER_SEGMENTS = frozenset({
    "appdata", "local", "roaming", "locally", "locallow", "programdata",
    "users", "application data", "local settings",
})
_DEDUP_CONTAINER_MAX_SEGS = 4   # 如 c:\users\lqn\appdata = 4 段

# ===== 绿区（可自动清理）收集器 =====
# 所有「安全缓存」路径集中收集，最后按软件聚合，避免黄区钻取重复计入同一批缓存。
_ALL_GREEN_PATHS = []
_GREEN_SEEN = set()

# v1.7.85：「现在删不掉、需关软件/重启才能删」的绿区条目。
# 这批**不进**一键清承诺口径，只在报告里单列「重启后还能再清 XX」，
# 避免用户点完一键清发现「扫出来的却没删掉」的欺骗感（老李 2026-10-04 拍板）。
_GREEN_DEFERRED = []

# v1.7.85：抽样锁定率 → 可删比例的换算折扣。
# probe 只抽 40 个文件，样本量小、统计误差约 ±15%。乘 0.85 = 承诺量系统性偏低，
# 保证「实际交付 ≥ 报告承诺」。方向很重要：宁可少报让用户觉得「比说的还多」，
# 也绝不能多报让用户觉得被骗（老李 2026-10-04：「宁可小，不可虚高」）。
_PROBE_SAFETY = 0.85


def _probe_one(path, sample=40):
    """v1.7.85：跑 migrate.probe_purgable 的薄包装，import 失败时保守放行。

    为什么要包装：probe_purgable 住在 migrate.py（迁移模块），analyze 是分级模块，
    两者历史上互不依赖。直接 import 会把 migrate 拖进 analyze 的依赖链。
    这里惰性 import + 失败降级为「可删」—— 宁可少拦一点，也不能让报告生成崩掉。
    """
    try:
        import migrate as _mg
        return _mg.probe_purgable(path, sample=sample)
    except Exception:
        return True, "", 0.0


def add_green_cache(path, kb):
    np_ = normalize(path)
    if np_ in _GREEN_SEEN:
        # 同一路径可能先被「迁移排除逃生舱」以 kb=0 占位登记，后被真实缓存块补真实体积。
        # 这里取较大值，避免真实体积被去重漏算（修复 360se6 旧版浏览器缓存显示低估）。
        for i, (p, k) in enumerate(_ALL_GREEN_PATHS):
            if normalize(p) == np_ and kb > k:
                _ALL_GREEN_PATHS[i] = (p, kb)
                break
        return
    _GREEN_SEEN.add(np_)
    _ALL_GREEN_PATHS.append((path, kb))


def clear_green_cache():
    _ALL_GREEN_PATHS.clear()
    _GREEN_SEEN.clear()
    _GREEN_DEFERRED.clear()   # v1.7.85：与绿区同步清空，避免上一轮结果串到下一轮


def _green_friendly_name(label, sample_path):
    """把绿区聚合 label 翻成人话（小白能懂）。已知软件标签（迅雷缓存/浏览器缓存等）已够白话，
    直接沿用；兜底 '其他软件缓存' 按路径细化成开发工具缓存等（npm/gradle/cargo…）。"""
    if label and label != "其他软件缓存":
        return label
    low = normalize(sample_path)
    if "npm" in low or "node_modules" in low:
        return "开发工具缓存（npm 临时零件，清了自动重下）"
    if ".gradle" in low:
        return "开发工具缓存（Gradle）"
    if ".cargo" in low:
        return "开发工具缓存（Rust 零件）"
    if "playwright" in low:
        return "开发工具缓存（Playwright）"
    if ".nuget" in low or "nuget" in low:
        return "开发工具缓存（NuGet）"
    if "go-build" in low:
        return "开发工具缓存（Go 编译缓存）"
    return "其他软件缓存"


def build_green_from_cache():
    """把收集到的所有缓存路径按软件聚合，每组只给一句话说明，不展开明细。"""
    # 绿区包含去重：整目录与其内部子目录都被标记为安全时，只保留最外层容器，
    # 避免「整目录 + 子目录」重复计入（如 node_modules 与其子目录、Edge 整目录与 Edge\\Cache）。
    # 按路径长度升序（容器路径更短，先入列），后续较长的子路径会被判定为「已被包含」而舍去。
    _all = sorted(_ALL_GREEN_PATHS, key=lambda x: len(normalize(x[0])))
    _kept, _kept_norm = [], set()
    for p, kb in _all:
        np_ = normalize(p)
        if any(np_ == o or np_.startswith(o + "\\") or np_.startswith(o + "/")
               for o in _kept_norm):
            continue  # 已被某个外层绿区路径包含，舍去（体积已含在内）
        _kept.append((p, kb))
        _kept_norm.add(np_)
    groups = {}
    for p, kb in _kept:
        label = path_rules.software_label(p)
        g = groups.setdefault(label, {"kb": 0.0, "paths": [], "path_kb": []})
        g["kb"] += kb
        g["paths"].append(p)
        g["path_kb"].append((p, kb))
    out = []
    for label, g in sorted(groups.items(), key=lambda x: -x[1]["kb"]):
        if g["kb"] < 1.0:   # 忽略 1KB 以下的空缓存组（如 Firefox 空的 Cache 目录），避免绿区刷 0KB 空行
            continue
        friendly = _green_friendly_name(label, g["paths"][0])
        # ===== v1.7.85（老李 2026-10-04 实测「报告说清得了、实际清不掉」根因③）=====
        # 老李原话：「扫出来清理不了，前后矛盾」「清理不了不第一时间告知，
        # 而是慢慢等他执行清理操作，等了半天之后跳出来一句清理不了」。
        # 病根：绿区体积 = 目录【扫出来的字节数】，可这个数从来没校验过
        #       「这些文件现在到底删不删得掉」。Temp/浏览器缓存这类目录里
        #       大量文件被正在运行的程序独占 —— 扫得到、删不掉。
        # 现在出报告前逐条跑 probe_purgable()（三级探测：整目录 rename → 内容级 → 保护目录），
        # 把每组体积按【可删比例】拆成两笔：
        #   now_kb   → 现在真能删（**报告只承诺这一笔**，且只有它进删除白名单）
        #   defer_kb → 关软件/重启才能删（单列，绝不混进承诺）
        #
        # 【为什么要按比例折算，而不是「删不掉就整组丢」——这是老李口径的落地关键】
        # probe 抽 40 个文件只能估【比例】。Temp 抽样 65% 被占，意思不是「整个 3.3GB
        # 都删不掉」，而是「其中约 35%（约 1.1GB）现在就删得掉」。
        # 整组丢掉 = 把能清的一起扔掉，报告从 4.2GB 缩到 0.2GB，比虚高更糟 ——
        # 虚高是骗用户，砍过头是砸自己的产品。用户要的是「现在到底能清多少」的准数。
        # 折算时再乘 _PROBE_SAFETY（0.85）：抽样只有 40 个，统计误差约 ±15%，
        # 宁可少报一点，也不让承诺量大于真值。这与 server 端「真值闸」方向一致：
        #   报告保守 → 实际交付 ≥ 报告 → 用户永远觉得「比说的还多」，口碑立住。
        _now_kb, _defer_kb, _now_paths, _reasons = 0.0, 0.0, [], []
        _partial_paths = []       # 部分可删的路径：也进删除白名单（server 逐文件判定）
        for _p, _k in g["path_kb"]:
            _ok, _reason, _ratio = _probe_one(_p)
            if _ok:
                _now_kb += _k
                _now_paths.append(_p)
            else:
                # 删不干净，但能删掉一部分 → 按 (1 - 锁定率) 折算，扣掉安全系数
                _free_ratio = max(0.0, min(1.0, 1.0 - float(_ratio or 0.0))) * _PROBE_SAFETY
                if _free_ratio > 0:
                    _now_kb += _k * _free_ratio
                    _partial_paths.append(_p)
                _defer_kb += _k * (1.0 - _free_ratio)
                if _reason and _reason not in _reasons:
                    _reasons.append(_reason)
        if _now_kb < 1.0:
            # 这一组现在一个字节都删不掉 → 整组移出绿区承诺口径，
            # 转入「重启后可清」清单，绝不混在一键清里当安全项。
            _GREEN_DEFERRED.append({"name": friendly, "software": label,
                                    "path": g["paths"][0], "kb": g["kb"],
                                    "reasons": _reasons})
            continue
        if _defer_kb >= 1.0:
            _GREEN_DEFERRED.append({"name": friendly, "software": label,
                                    "path": g["paths"][0], "kb": _defer_kb,
                                    "reasons": _reasons, "partial": True})
        out.append({
            "name": friendly,
            "software": label,
            "path": g["paths"][0],
            "size_estimate": kb_to_h(_now_kb),
            "kb": _now_kb,
            # trash_paths = 全部「值得一试」的路径（含部分可删的）。
            # 【为什么不把部分可删的路径剔掉】Temp 这类目录 65% 被占、35% 能删，
            # 剔了就等于放弃那 1.1GB。而 server 端清理时逐文件判定、删不掉的
            # 自动登记重启删 + 真值闸扣减 —— 交付量自然落在承诺量之内。
            # 也就是说：多试一遍的成本是「几个文件报错」，收益是「承诺量多 1GB」。
            "trash_paths": (_now_paths if not _defer_kb >= 1.0
                            else _now_paths + _partial_paths),
            "commands": [{"label": "清理（确认后执行）", "cmd": ""}],
            "explain": {
                "title": "可再生的缓存 / 临时文件",
                "body": "删了会自动重建，不影响你的任何资料。一键清理即可释放空间，无需逐条确认。",
            },
        })
    return out


# ===== 排除项：环境特定的开发/AI 工具数据，非用户日常垃圾，不进报告 =====
EXCLUDE = (".rustup", ".workbuddy", ".codebuddy", ".agent-browser", ".molili",
           ".cline", ".roo", ".aider", ".continue", "workbuddy",
           # P2-4 决策：Windows 事件日志 (winevt\Logs) 含 System/Security 等审计证据，
           # 删除不可逆，属系统日志而非缓存，绝不展示为可清理项（黄区假按钮）。
           # scan.py 仍锚点扫描以检测权限缺口，analyze 层统一过滤掉展示。
           "winevt")

# ===== 红区（应用本体，走卸载，不手动删）=====
RED_MARKS = ("program files", "/applications", "programfiles")
RED_NAMES = {"wechat", "qq", "tencent", "wxwork", "钉钉", "dingtalk", "bilibili",
             "steam", "网易云音乐", "youdaonote", "有道云笔记"}

# ===== 纯下载/缓存型应用根（GREEN_APP_ROOTS）：整目录 100% 可删、不含个人数据 =====
# 命中即跳过「拆缓存」拦截（is_cache_app_root 返回 False），直接整目录标绿。
# 适用对象：纯下载临时文件工具（迅雷下载缓存、Xunlei、迅雷中文目录），其数据全是
# 可再生的下载临时文件，不含密码/聊天/文档/工程。
# ⚠️ 必须用【精确目录名】（含空格的 "thunder network"），绝不能用裸 "thunder"：
#    否则会误匹配 Thunderbird（邮件客户端，本地存邮件）——整目录删 = 用户丢邮件！
# 凡含个人数据（浏览器/微信/QQ/Office/云盘…）的一律不在此列，走 is_cache_app_root
# 拆缓存逻辑（只提纯缓存子目录进绿区，其余留黄区）。
GREEN_APP_ROOTS = ("thunder network", "xunlei", "迅雷")

# ===== 纯缓存子目录名（basename，忽略大小写）=====
# 这些目录删了会自动重建，是真正"安全可清"的。其余一概不进绿区。
SAFE_CACHE_SUBDIRS = {
    "cache", "code cache", "gpucache", "mediacache", "shadercache",
    "cache2", "startupcache", "thumbnails", "thumbcache", "webcache",
    "filecache", "imagecache", "videocache", "tempstate",
}

# ===== 其余纯缓存标记（路径里直接含这些、且非整目录缓存型的，仍按绿）=====
DEV_CACHE_MARKS = (".npm", ".gradle", ".cargo", ".nuget", ".m2", "node_modules",
                   ".pnpm", ".uv", "ms-playwright", "go-build", "npm-cache", "nuitka")

# ===== 子项安全分级（用于大文件夹智能钻取 + 兜底小项桶） =====
# 这些名字的子项 → ✅ 可安全删除（纯缓存/临时/日志，删了自动重建）
# v1.7.34（登录数据保护）：blob_storage 是 IndexedDB 的 Blob 持久数据（含站点状态/
# 登录 token），**不是纯可再生缓存**，已移除（移入 KEEP_SUB_NAMES）。其余保留纯缓存。
SAFE_SUB_NAMES = frozenset({
    "cache", "caches", "code cache", "gpucache", "shadercache",
    "thumbnails", "thumbcache", "webcache", "filecache",
    "imagecache", "videocache", "mediacache", "tempstate",
    "service worker", "cachedata",
    "temp", "tmp", "temporary", "tempfolder",
    "log", "logs", "history", "histories",
    "crashes", "crashpad", "dumps", "dump", "old", "backup", "bak",
})
# 这些名字的子项 → ⚠️ 建议保留（含个人数据/配置，宁可多留）
KEEP_SUB_NAMES = frozenset({
    "bookmarks", "bookmark", "login data", "cookies", "cookie",
    "preferences", "preference", "settings", "setting", "config", "configuration",
    "extensions", "extension", "plugins", "plugin", "user data", "userdata",
    "profile", "profiles", "default", "places.sqlite", "webdata", "local state",
    "databases", "database", "indexeddb", "local storage", "localstorage",
    "web storage", "webstorage", "session storage", "sessionstorage",
    "blob_storage", "blobstorage", "file system", "filesystem",
    "accounts", "account", "messages", "message", "msg", "chat", "chats",
    "documents", "document", "pictures", "picture", "videos", "video",
    "music", "projects", "project", "templates", "template", "presets", "preset",
    "catalog", "catalogs", "library", "libraries", "favorites", "favorite",
    "passwords", "passport", "workspace", "workspaces", "keybindings", "normal",
})

# 触发智能子扫描的最小文件夹大小阈值（50MB：与黄区大文件阈值对齐，尽量把清理深度拉高）
SMART_SCAN_THRESHOLD_KB = 50 * 1024

# ===== 黄区（用户数据，需判断）=====
YELLOW_MARKS = ("下载", "downloads", "微信文件", "wechat files", "文档", "documents",
                "desktop", "pictures", "videos", "music", "wps cloud", "kimi",
                "qianfan", "videoscreenshot", "screenshot")

# ===== 用户个人目录锚点：这些目录（及其任意子文件夹）永远不能自动标绿 =====
# 小白会把任何东西塞进 下载/文档/图片/视频/音乐，里面万一有个叫 temp / cache 的
# 文件夹（如 Downloads\app-cache、Documents\temp），绝不能因为命中绿色子串规则而误删。
# 一律进黄区，让用户自己判断。这是绿区「绝对安全」的最后一道防线。
USER_DIR_ANCHORS = ("\\downloads", "\\documents", "\\desktop", "\\pictures",
                    "\\videos", "\\music", "\\3d objects", "\\links",
                    "\\saved games", "\\searches", "\\favorites", "\\contacts")


# ===== 人话解释：帮用户做正确决策（是什么 / 起什么作用 / 删了会怎样）=====
EXPLAIN = {
    "green": {
        "浏览器/软件缓存（仅缓存子目录，可安全清）": {
            "what": "Chrome / Edge / Firefox 等浏览器，以及微信、QQ、迅雷等软件运行时产生的临时缓存——网页图片、视频预览帧、CSS/JS 副本、缩略图等。注意：只清 Cache / Code Cache / GPUCache 这类纯缓存子目录，不碰你的书签、密码、登录态和聊天记录。",
            "role": "用来加速下次打开网页、让页面秒开。它会自己不断重新生成，清掉后会慢慢又被填满。",
            "impact": "删了只是下次打开网页可能慢一两秒，几小时内会自动重新攒回来。不影响任何账号、书签、密码、聊天记录。",
        },
        "开发工具缓存": {
            "what": "编程 / 构建工具（npm、Cargo、Gradle、pip、Playwright 等）下载的依赖与编译缓存。",
            "role": "加速本地编译和装包，避免每次都重新下载。",
            "impact": "删了下次编译或安装依赖时会重新下载，耗时稍长，但你的代码和项目一个都不会丢。",
        },
        "系统临时文件": {
            "what": "系统和软件运行时产生的临时碎片文件。",
            "role": "运行中临时存放，用完本应自动清。",
            "impact": "删了不影响任何软件和数据，系统会自动补建需要的临时文件。",
        },
        "迅雷缓存": {
            "what": "迅雷下载过程中产生的临时缓存。",
            "role": "加速下载续传。",
            "impact": "删了不影响已下载完成的文件，下次下载会重新生成。",
        },
    },
    "yellow": {
        "微信/QQ 数据": {
            "what": "微信 / QQ 的本地数据目录，里面混着聊天记录数据库、你收过的文件 / 图片 / 视频、还有登录态。",
            "role": "让你随时翻看历史聊天、找回别人发来的文件、保持已登录状态。",
            "impact": "【高危】手动删除可能让聊天记录永久丢失、收过的文件找不回、还要重新登录。建议只在微信 / QQ 自带的「设置 → 存储空间 → 清理缓存」里操作，别在文件夹里手动拖。",
            "risk": "误删 = 聊天记录 / 文件永久丢失，务必谨慎",
        },
        "浏览器/软件数据（需确认）": {
            "what": "浏览器 / 软件数据目录里、除缓存以外的部分，主要是你的登录态、浏览器扩展、个性化设置和收藏。",
            "role": "保存你「已登录」的状态、装好的扩展和你调过的设置。",
            "impact": "删了要重新登录所有网站、扩展消失、设置归零。真正的缓存已自动归入上面可一键清理的范围，这里只留需要你判断的部分。",
            "risk": "误删 = 重新登录 + 丢失扩展与设置",
        },
        "软件数据（需确认）": {
            "what": "识别为某款软件的数据目录，但分不清里面是临时数据还是你的资料。",
            "role": "软件运行所需，可能含可清临时数据，也可能含你的配置 / 产出。",
            "impact": "先打开看看里面是什么，确认是临时数据再清；拿不准就别动。",
        },
        "通讯软件数据": {
            "what": "微信 / QQ / 钉钉 / 飞书 / 网易等通讯软件的本地数据，含聊天记录数据库、收发过的图片 / 视频 / 文件，以及登录态。",
            "role": "让你随时翻看历史聊天、找回别人发来的文件、保持已登录状态。",
            "impact": "【高危】手动删除可能让聊天记录永久丢失、文件找不回、还要重新登录。建议用软件自带的「存储空间 → 清理缓存」操作，别在文件夹里手动拖。",
            "risk": "误删 = 聊天记录 / 文件永久丢失，务必谨慎",
        },
        "浏览器数据": {
            "what": "浏览器（Chrome / Edge / 360 / Firefox 等）的本地数据，主要是登录态、扩展、个性化设置和收藏，还有一部分可重建缓存。",
            "role": "保存你「已登录」的状态、装好的扩展和你调过的设置。",
            "impact": "删了要重新登录所有网站、扩展消失、设置归零。真正的缓存已自动归入可一键清理的范围，这里只留需要你判断的部分。",
            "risk": "误删 = 重新登录 + 丢失扩展与设置",
        },
        "办公软件数据": {
            "what": "WPS / Office / 金山 / Adobe 等办公软件的本地数据，含模板、最近文档记录、个性化设置和一部分缓存。",
            "role": "保存你的使用习惯、模板和最近打开过的文档索引。",
            "impact": "清缓存 / 临时文件一般安全；但模板、自定义词典、最近文档记录删了要重新配置。拿不准就只勾选明确的缓存文件夹。",
        },
        "开发工具数据": {
            "what": "开发工具（VS Code / Node / Python / Rust / Android 等）的本地数据，含依赖缓存（npm / uv / cargo）、插件和历史记录。",
            "role": "加速本地编译和装包，避免每次重新下载依赖。",
            "impact": "依赖缓存（node_modules / .npm / .uv / .cargo 等）删了可重下，但重下要花时间；插件 / 配置删了要重装。只删明确能重建的缓存最稳妥。",
        },
        "其他软件数据": {
            "what": "其他软件的本地数据目录，里面除了缓存，往往还有你的设置、登录态或工作文件。",
            "role": "软件运行所需，可能含可清临时数据，也可能含你的配置 / 产出。",
            "impact": "先打开看看里面是什么，确认是临时数据再清；拿不准就留着。",
        },
        "用户文件/下载": {
            "what": "你自己的下载、文档、图片、视频等文件。",
            "role": "你的个人资料，不是系统垃圾。",
            "impact": "删了就真没了，删除前先确认还要不要。大文件移到其他盘比删掉更划算。",
            "risk": "误删 = 个人资料永久丢失",
        },
        "其他（建议自查）": {
            "what": "扫描到但一时识别不出用途的目录。",
            "role": "不确定，可能是某软件的数据，也可能是你需要的资料。",
            "impact": "别急着删。点「一键定位文件夹」打开看看里面是什么，确认没用再处理。",
        },
    },
    "red": {
        "应用程序": {
            "what": "安装好的应用程序本体（微信、Steam、WPS 等）。",
            "role": "程序运行本身需要的文件。",
            "impact": "手动拖删会留下注册表残留、甚至删坏其他程序，释放也不彻底。用系统「设置 → 应用 → 卸载」或软件自带卸载器正规移除最干净。",
        },
    },
}
GENERIC = {
    "green": {"what": "可安全清理的缓存 / 临时文件。",
              "role": "系统或软件会自动重建。",
              "impact": "删了不影响你的任何资料，会自动重新生成。"},
    "yellow": {"what": "含有内容的目录，分不清是临时数据还是你的资料。",
               "role": "可能是软件临时数据，也可能存着你的文件。",
               "impact": "先打开自查，确认无用再删，别一刀切。"},
    "red": {"what": "应用程序本体。",
            "role": "程序运行本身需要的文件。",
            "impact": "走系统正规卸载，别手动拖删，否则留残留。"},
}


def get_explain(tier, cat):
    """取类别专属人话解释；先精确匹配，再子串匹配，最后兜底通用文案。"""
    d = EXPLAIN.get(tier, {})
    if cat in d:
        return d[cat]
    for k, v in d.items():
        if k in cat or cat in k:
            return v
    return GENERIC.get(tier, {})


def normalize(p):
    return p.lower().replace("/", "\\").rstrip("\\")


def is_cache_app_root(p):
    """路径是否落在「可拆缓存的软件数据根」。

    改用 path_rules：只要该路径被识别为 safe/review（即含缓存结构或国民软件
    app 根），且位于用户/程序数据树（appdata / programdata / 用户临时），
    就抽其缓存子目录进绿区、其余进黄区。这样 360se6 / 金山 / 迅雷等中国软件
    也能被正确拆出可安全清的缓存，而不是整目录掉进黄区当 unknown。
    程序安装目录（program files）不在此列，仍走红区正规卸载。

    ⚠️ Temp 目录除外：Temp 本身就是系统临时目录，里面的内容全是可删的临时文件，
    不应走「拆缓存」逻辑整目录降级黄区——应直接让 tier_and_cat 判定（通常为 green）。
    """
    np_ = normalize(p)
    # 纯下载/缓存型应用（迅雷等）：整目录可直接标绿，无需拆缓存（无个人数据）
    if any(k in np_ for k in GREEN_APP_ROOTS):
        return False
    # Temp 下的目录直接放行，不走缓存应用拆分逻辑
    if "\\temp\\" in np_ or np_.endswith("\\temp"):
        return False
    if not ("\\appdata\\" in np_ or "\\programdata\\" in np_
            or np_.endswith("\\appdata\\local\\temp")):
        return False
    return path_rules.classify_path(p)[0] in ("safe", "review")


def _is_known_safe_cache_location(p):
    """家树内允许标绿的"已知安全缓存位置"（其余家目录内容默认不绿）。

    仅：AppData / ProgramData 软件数据树（其内具体安全由 classify_path 段名判定）、
    家根下点开头隐藏 dev 缓存（C:\\Users\\X\\.npm 等）。
    不能只靠段名——否则 C:\\Users\\X\\temp、C:\\Users\\X\\.cache 这类用户自建
    文件夹会被误判绿、一键删（铁律① 违规，见 P0-2 修复）。
    """
    if "\\appdata\\" in p or "\\programdata\\" in p:
        return True
    segs = p.split("\\")
    if len(segs) >= 4 and segs[0] == "c:" and segs[1] == "users" and segs[3].startswith("."):
        return True
    return False


def _is_safe_bak_residual(path):
    """判断一个 *.migrated.bak 迁移残留是否**可安全一键清**。

    v1.7.83（覆盖度修复）：残留此前一律只进「迁移残留」提示、不进绿区，
    于是这批「junction 已切换、D 盘已有完整副本」的目录副本（实测本机
    pnpm 244MB + BaiduNetdisk 339MB）永远躺在 C 盘上释放不掉。
    但**绝不能无条件判绿**——只有 classify_bak_residual 确认安全（junction 已建
    且目标盘副本存在）才绿。实测本机 Tencent.migrated.bak 是 junction_broken
    （D 盘没有副本，删了就真丢数据），这种必须继续留在残留列表里让用户处理。

    返回 (safe, why, src, dst)；异常一律按「不安全」处理（宁可不绿，绝不误删）。
    """
    try:
        from migrate import classify_bak_residual
    except Exception:
        return (False, "import_failed", "", "")
    try:
        safe, why, src, dst = classify_bak_residual(path, check_files=False)
    except Exception:
        return (False, "check_failed", "", "")
    return (bool(safe), why or "", src, dst)


def is_green_cache(path):
    """绿区唯一收口：判断一个路径是否可「一键安全清理」（绝对安全、零个人数据）。

    五道关，全部命中才绿；任意一道不放心就留黄区——宁可少清，绝不误删。
    这是铁律①「绿区绝对安全」的唯一判定出口，取代历史上散落的裸子串绿区分支
    （坑7 thunder↔thunderbird、坑8 用户目录误删、坑9 electron/cache 裸子串撞车）。

    第一关 · 用户个人目录永不标绿（最后防线，见 USER_DIR_ANCHORS）
      小白会在 下载/文档/图片/视频/音乐 里乱建 temp/cache 文件夹，
      绝不能因命中缓存子串而一键删掉私人文件。
    第二关 · 系统级安全缓存（path_rules.is_system_cache，已带锚点不撞车）
    第三关 · 段名识别的缓存结构（path_rules.classify_path=='safe'，完整段名匹配，
      非裸子串——my-electron-app 不会因含 electron 子串被误判）
    第四关 · 开发/构建缓存位置约束（保守，见 _is_dev_cache_in_safe_location）
      仅 AppData/ProgramData/Temp/用户家点开头隐藏目录下才绿；项目内 node_modules
      等留黄区（小白不会 npm i 重装，删了无法恢复）。
    第五关 · 自身迁移残留（v1.7.83）——经 classify_bak_residual 确认
      「junction 已切换 + D 盘副本完整」的 .migrated.bak 才算可清。
    """
    p = normalize(path)
    # 第五关（v1.7.83）：自身迁移残留——必须先过安全校验，绝不无条件判绿
    if any(seg.endswith(".migrated.bak") for seg in p.rstrip("\\").split("\\")):
        _safe, _why, _src, _dst = _is_safe_bak_residual(path)
        return bool(_safe)
    # 第一关（强化·P0-2 修复）：整棵用户家树默认不绿，除非落在已知安全缓存位置或系统缓存
    home_n = normalize(os.path.expanduser("~"))
    if p.startswith(home_n + "\\"):
        if not (_is_known_safe_cache_location(p) or path_rules.is_system_cache(path)):
            return False
    # 第二关：系统级安全缓存（已锚定）
    if path_rules.is_system_cache(path):
        return True
    # 第三关：段名识别的缓存/临时结构（完整段名，不裸子串撞车）
    safety, _ = path_rules.classify_path(path)
    if safety == "safe":
        return True
    # 第三关之二（v1.7.83）：**classify_path 明确判 keep 的，一律不绿**——
    #   防止下面的「开发缓存位置约束」把 keep 判定绕过去。
    #   实测踩到的坑：AppData\Roaming\npm\node_modules\npm 被 classify_path 正确判成
    #   keep（运行库本体），但第四关因「含 node_modules 段 + 位于 AppData 树」又把它放行，
    #   结果运行库本体进了删除清单。keep 必须是终局判定，不容后续关卡翻案。
    if safety == "keep":
        return False
    # 第四关：开发缓存位置约束（保守）
    if _is_dev_cache_in_safe_location(p):
        return True
    return False


def _is_dev_cache_in_safe_location(p):
    """开发/构建缓存（node_modules/.npm/.gradle/.cargo/.nuget/.m2/.pnpm/.uv/
    ms-playwright/go-build/npm-cache/nuitka 等）：保守标绿策略——
    仅当位于 AppData / ProgramData / Temp 树，或「用户家根下的点开头隐藏目录」
    （C:\\Users\\X\\.npm 等）时才标绿；
    项目目录内的（如 C:\\code\\myproject\\node_modules、C:\\Games\\...\\node_modules）
    一律留黄区，由用户自己决定（小白不会 npm i 重装，删后无法恢复）。

    用 segment 精确匹配（段名 == 标记），而非裸子串，避免 .npm 撞 .npmcache 之类。
    """
    segs = p.split("\\")
    # 是否有开发缓存标记段（精确段名匹配，非子串）
    if not any(m == s for s in segs for m in DEV_CACHE_MARKS):
        return False
    # 安全位置 1：AppData / ProgramData / Temp 树
    if any(loc in p for loc in ("\\appdata\\", "\\programdata\\", "\\temp\\")):
        return True
    # 安全位置 2：用户家根下的点开头隐藏目录（C:\Users\X\.npm\.gradle 等）
    #   segs = [c:, users, <用户名>, <.xxx>, ...]
    if len(segs) >= 4 and segs[0] == "c:" and segs[1] == "users" and segs[3].startswith("."):
        return True
    return False


def tier_and_cat(path):
    """普通分级（不含缓存型应用根，那类在 main 里特判）。返回 (tier, 类别)。

    绿区判定已统一收口到 is_green_cache()（见上方），本函数不再保留任何
    裸子串绿区分支——彻底根除坑7/坑8/坑9 一脉相承的「子串撞车误删」病根。
    """
    p = normalize(path)
    n = p.rsplit("\\", 1)[-1]

    # 回收站特判：用户已经删过一次的文件，仍占 C 盘空间。放黄区二次确认。
    # 不能进绿区——用户可能想恢复；不能进红区——不是应用本体。
    if "\\$recycle.bin" in p:
        return ("yellow", "回收站（已删未清）")

    # 红区：应用本体
    if any(k in p for k in RED_MARKS):
        return ("red", "应用程序")
    if n in RED_NAMES and "\\appdata" not in p:
        return ("red", "应用程序")

    # 绿区：唯一收口（不再裸子串撞车，内部已先排除用户目录）
    if is_green_cache(path):
        return ("green", "浏览器/软件缓存")

    # 用户个人目录：永不自动标绿（is_green_cache 内部已排除，这里冗余兜底）
    if any(a in p for a in USER_DIR_ANCHORS):
        return ("yellow", "用户文件/下载")

    # 黄区：用户数据
    if any(k in p for k in YELLOW_MARKS) or n in ("下载",):
        return ("yellow", "用户文件/下载")

    # 兜底：看不出名目的目录 → 黄区"建议自查"（中性，不默认当垃圾）
    return ("yellow", "其他（建议自查）")


def sum_file_sizes(path):
    """只读：递归累加某目录内所有文件字节数（用于给缓存子目录定价）。

    改用 os.scandir 单次 syscall 范式：Windows 下 FindFirstFile 返回的
    WIN32_FIND_DATA 已携带文件大小，entry.stat().st_size 不触发额外 syscall，
    比 os.walk + os.path.getsize（每文件一次额外 os.stat）快约一个数量级，
    且体积结果完全一致。

    junction/符号链接识别必须看 st_file_attributes 的 REPARSE_POINT(0x400) 位——
    对齐 scan.dir_size_bytes 的权威写法。⚠️ 不能用 entry.is_symlink()：实测
    Windows + Python 3.13 上「junction（目录联接）」的 is_dir(follow=False) 仍返回
    True、is_symlink() 返回 False（历史 OOM 事故根源），用 is_symlink 会漏拦真
    junction → 递归进链接目标巨目录 → 绿区体积虚高（176GB bug 复发）。必须下钻前
    排除 reparse point，与 os.walk(followlinks=False) 默认行为等价。
    """
    tot = 0.0
    stack = [path]
    while stack:
        cur = stack.pop()
        try:
            for entry in os.scandir(cur):
                try:
                    st = entry.stat(follow_symlinks=False)
                    if getattr(st, "st_file_attributes", 0) & 0x400:  # REPARSE_POINT = junction/symlink/mount
                        continue
                    if entry.is_dir():  # reparse 已排除，真实目录才下钻
                        stack.append(entry.path)
                    else:
                        tot += st.st_size
                except OSError:
                    pass
        except OSError:
            pass
    return tot


def extract_cache_subdirs(root):
    """只读下钻：在应用数据根内找出所有「安全缓存」目录，返回 [(path, kb)]。

    委托 path_rules.scan_safe_cache：覆盖浏览器/中国软件的全部缓存结构名
    （Cache/GPUCache/Code Cache/temp/log/迅雷缓存/WPS缓存…），按路径结构识别，
    跨电脑跨版本都稳。找到缓存目录即整体计量、不再下钻，天然安全。

    只返回「目录」条目（文件已含在目录体积内），避免把上万条零散 tmp/log
    文件塞进 trash_paths（既撑大 HTML，又拖慢删除）。
    """
    root = os.path.expanduser(root)
    if not os.path.isdir(root):
        return []
    found = path_rules.scan_safe_cache(root, max_depth=4)
    return [(p, s) for p, s in found if os.path.isdir(p)]


# ===== 微信/QQ 纯预览缓存（抬高保底释放下限的关键安全类别）=====
# FileStorage / Tencent Files 下的 Cache / Image / Video / Temp 是纯预览缓存
# （图片/视频缓存、缩略图），删了会自动从聊天重新下载，等同微信/QQ 自带
# 「清理缓存」按钮做的事——绝对安全、零个人数据丢失，可放心进绿区。
# 不含 File（收过的文件）/ Msg（聊天库）/ MsgAttach / Backup —— 那些含用户数据、
# 删了不可重建，一律留黄区让用户判断。
_WECHAT_QQ_SAFE_SEGMENTS = ("cache", "image", "video", "temp")


def _wechat_qq_safe_segment(np_):
    """微信/QQ 数据路径是否精确到可绿的安全缓存子目录。

    返回命中的段名（cache/image/video/temp），否则 None。np_ 为小写反斜杠归一化路径。
    仅在 FileStorage 直接子目录（微信）或 Tencent Files 下账号目录的直接子目录（QQ）放行，
    避免把 File/Msg 误判成可清缓存。
    """
    if "\\wechat files\\" in np_ and "\\filestorage\\" in np_:
        rest = np_.split("\\filestorage\\", 1)[1].split("\\")
        seg = rest[0] if rest else ""
        return seg if seg in _WECHAT_QQ_SAFE_SEGMENTS else None
    if "\\tencent files\\" in np_:
        # Documents\Tencent Files\<账号>\<cache|image|video|temp>\...：仅直接子目录安全
        parts = np_.split("\\tencent files\\", 1)[1].split("\\")
        if len(parts) >= 2 and parts[1] in _WECHAT_QQ_SAFE_SEGMENTS:
            return parts[1]
    return None


def _extract_wechat_qq_cache(root):
    """在微信/QQ 数据树下找出 Cache/Image/Video/Temp 子目录，返回 [(path, kb)]。

    只读下钻、命中即整体计量并停止下钻，天然安全；绝不触碰 File/Msg 等用户数据目录。
    与 add_green_cache 的去重配合，即使扫描器同时喂入容器与子目录也不会重复计体积。
    """
    root = os.path.expanduser(root)
    if not os.path.isdir(root):
        return []
    found = []
    try:
        for dp, dns, _ in os.walk(root):
            for d in list(dns):
                if d.lower() in _WECHAT_QQ_SAFE_SEGMENTS:
                    fp = os.path.join(dp, d)
                    try:
                        sz = sum_file_sizes(fp)
                    except OSError:
                        sz = 0
                    if sz > 0:
                        found.append((fp, round(sz / 1024.0, 1)))
                    dns.remove(d)  # 已整体计量，不再下钻
    except OSError:
        pass
    return found


def kb_to_h(kb):
    if kb >= 1024 * 1024:
        return "%.1f GB" % (kb / 1024 / 1024)
    if kb >= 1024:
        return "%.1f MB" % (kb / 1024)
    return "%.0f KB" % kb


def item_kb(it):
    if it.get("size_kb") is not None:
        try:
            return float(it["size_kb"])
        except (TypeError, ValueError):
            pass
    try:
        v = float(it.get("size_h", "0").split()[0])
        u = it.get("size_h", "0").split()[1].upper()
        if u == "TB":
            v *= 1024 * 1024
        elif u == "GB":
            v *= 1024
        elif u == "MB":
            v = v
        else:
            v /= 1024
        return v * 1024
    except Exception:
        return 0.0


# ===== 人话辅助：让手动项“看得见、摸得着、能判断” =====
NAME_HINTS = {
    "kingsoft": "金山系（WPS/金山）", "adobe": "Adobe", "tencent": "腾讯系",
    "baidu": "百度系", "nvidia": "NVIDIA", "amd": "AMD", "intel": "Intel",
    "jetbrains": "JetBrains 开发工具", "unity": "Unity 引擎", "epic": "Epic Games",
    "steam": "Steam", "microsoft": "微软", "google": "谷歌", "apple": "苹果",
    "spotify": "Spotify", "discord": "Discord", "docker": "Docker",
    "oracle": "Oracle", "java": "Java", "python": "Python", "node": "Node.js",
    "android": "Android 相关", "samsung": "三星", "huawei": "华为", "xiaomi": "小米",
    "alibaba": "阿里系", "netease": "网易", "bilibili": "B站",
    "kuaishou": "快手", "weibo": "微博", "zhihu": "知乎",
}


def pretty_name(path, cat):
    """给真实目录一个看得懂的名字：英文名补中文注释，用户文件类更直观。"""
    base = path.rstrip("\\/").rsplit("\\", 1)[-1].rsplit("/", 1)[-1]
    low = base.lower()
    hint = NAME_HINTS.get(low)
    if not hint:
        for k, v in NAME_HINTS.items():
            if k in path.lower():
                hint = v
                break
    if cat == "其他（建议自查）" and hint:
        return "%s（%s）" % (hint, base)
    if hint:
        return "%s · %s" % (hint, base)
    if cat == "用户文件/下载":
        return "个人文件：%s" % base
    return base


def human_rel(path):
    """用 mtime 算出『多久没动过』，帮用户判断能不能删。"""
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return ""
    days = (time.time() - mt) / 86400.0
    if days < 1:
        return "今天刚动过"
    if days < 2:
        return "昨天动过"
    if days < 7:
        return "%.0f 天前动过" % days
    if days < 30:
        return "约 %.0f 周前动过" % (days / 7)
    if days < 365:
        return "约 %.0f 个月前动过" % (days / 30)
    return "超过 %.0f 年没动过" % (days / 365)


# ===== 智能子目录钻取：把大文件夹拆成「可清理/需保留」两组 =====

def classify_sub_item(name, is_dir):
    """判断单个子项（按名字）是否可安全删除。返回 ('safe'|'keep'|'unknown', reason)。

    委托 path_rules.classify_path：靠「缓存子文件夹结构名」识别，而非 app 名字，
    path_rules 里 review 视为需确认 → 映射到 unknown。
    """
    safety, reason = path_rules.classify_path(name)
    if safety == "review":
        safety = "unknown"
    return (safety, reason)


# 钻取时忽略的「噪音文件」扩展名（代码/库文件，普通用户无需看到也无需处理）
_SUB_NOISE_EXTS = {"dll", "sys", "drv", "exe", "msi"}
# 钻取时仍要展示的「大文件」最小体积（>= 此值才作为子项列出，避免碎片刷屏）
_SUB_FILE_MIN_KB = 50 * 1024
# 每类钻取子项最多展示条数，超出部分聚合成「其他小文件」
_SUB_CAP = 12


def _cap_sublist(items, dirpath):
    """对钻取子项封顶：超出 _SUB_CAP 的部分聚合成一个「其他小文件」汇总项，避免刷屏。"""
    if len(items) <= _SUB_CAP:
        return items
    kept = items[:_SUB_CAP]
    rest = items[_SUB_CAP:]
    rest_kb = sum(x.get("size_kb", 0.0) for x in rest)
    if rest_kb < 1.0:  # 剩余全是 1KB 以下的碎片，没必要再聚合成一行
        return kept
    kept.append({
        "name": "其他 %d 项小文件" % len(rest),
        "size_kb": round(rest_kb, 1),
        "is_dir": False,
        "path": dirpath,
        "safety": "unknown",
        "safety_reason": "",
        "verdict": "mixed",
        "explain": "零散的小文件，大多是缓存和设置，删了一般不影响程序运行",
    })
    return kept


def smart_sub_scan(dirpath):
    """对大目录做一层浅扫描（只看直接子项），返回安全分级结果。

    返回 dict：
      safe_children / keep_children / unknown_children — 各组子项列表
      safe_size_kb / keep_size_kb                    — 各组总大小
    """
    result = {
        "safe_children": [], "keep_children": [], "unknown_children": [],
        "safe_size_kb": 0.0, "keep_size_kb": 0.0,
    }
    try:
        entries = list(os.scandir(dirpath))
    except (OSError, PermissionError):
        return result

    # 父目录若是已知 app，其内部模块应「折叠成一条」而非逐个甩给用户（避免文件夹迷宫）
    parent_app = _match_app(dirpath.lower())
    internals = []  # 命中父 app 的未知内部模块，循环后折叠为一条

    for entry in entries:
        try:
            if entry.is_file():
                ext = entry.name.lower().rsplit(".", 1)[-1] if "." in entry.name else ""
                # 噪音文件（代码/库）一律跳过；其余文件只有够大才展示，避免碎片刷屏
                if ext in _SUB_NOISE_EXTS:
                    continue
                size = entry.stat().st_size
                if (size / 1024.0) < _SUB_FILE_MIN_KB:
                    continue
            elif entry.is_dir():
                size = quick_dir_size(entry.path)
            else:
                continue
            if size < 1024:  # 低于 1KB 的碎片（空目录 / 极小缓存）不展示，避免占行刷屏
                continue

            # 用完整路径判定（比仅名字更准：能识别 app 根 / 缓存结构名）
            safety, reason = path_rules.classify_path(entry.path)
            if safety == "review":
                safety = "unknown"
            own_app = _match_app(entry.name.lower())
            # 单一真理源：先算出 verdict，再用它决定去哪个区。
            # 不再用 safety 路由 —— 否则会出现「verdict=safe 却卡在黄区」的矛盾。
            # 整目录混有个人数据（密码/书签/聊天记录）的应用根 → mixed（黄区「可清临时数据保资料」），
            # 其内部纯缓存子目录会被 _promote_cache 单独提到绿区；纯缓存/纯依赖 → safe（绿区）。
            if own_app:
                verdict = own_app[0]
            elif entry.name.lower() in SUBDIR_HINTS:
                verdict = SUBDIR_HINTS[entry.name.lower()][0]
            else:
                verdict = _generic_sub_verdict(entry.name.lower(), safety)
                if verdict == "unknown":
                    verdict = "mixed"  # 默认「可清缓存保资料」，比「你决定」更可执行、更诚实
            item = {
                "name": entry.name,
                "size_kb": round(size / 1024.0, 1),
                "is_dir": entry.is_dir(),
                "path": entry.path,
                "safety": safety,
                "safety_reason": reason,
                "verdict": verdict,
            }
            attach_yellow_facts(item)
            raw = child_explain(entry.name, entry.is_dir(),
                                size_kb=size / 1024.0, path=entry.path,
                                reversible=item["llm_facts"]["reversible"])
            item["explain"] = _sanitize_yellow_desc(raw) + _recommendation(
                item["llm_facts"]["reversible"], verdict, entry.name)

            # 下钻内部的纯缓存子目录 → 提取进绿区（带去重，不与整目录重复计入）
            def _promote_cache(p):
                if os.path.isdir(p):
                    for cpath, ckb in path_rules.scan_safe_cache(p, max_depth=3):
                        if os.path.isdir(cpath) and is_green_cache(cpath):  # P1-2：复用四道关，防旁路绕过
                            add_green_cache(cpath, ckb)

            # 路由：以 verdict 为唯一标准
            if verdict == "safe":
                # 整目录是纯缓存/纯依赖（node_modules / temp / Cache 子目录…）→ 整目录归绿区一键清。
                # 不再下钻其内部，避免「整目录」与「内部子目录」重复计入（最终由绿区包含去重兜底）。
                if is_green_cache(entry.path):  # P1-2：复用四道关，防 smart_sub_scan 旁路绕过第四关
                    add_green_cache(entry.path, item["size_kb"])
            elif verdict == "keep":
                # 个人数据 / 程序本体 → 永不自动动，留作隐藏项（黄区无删除按钮）
                result["keep_children"].append(item)
                result["keep_size_kb"] += item["size_kb"]
            else:
                # mixed / unknown：需用户判断。先把内部纯缓存子目录提到绿区，剩余留黄区钻取。
                if entry.is_dir():
                    _promote_cache(entry.path)
                result["unknown_children"].append(item)
        except OSError:
            continue

    # 把已知 app 的内部模块折叠成一条，避免把小白用户丢进文件夹迷宫
    # 同时过滤 ≤1KB 的内部碎片（P3 修复）
    if internals:
        total = sum(x.get("size_kb", 0.0) for x in internals)
        if total >= 1.0:
            pname = os.path.basename(dirpath.rstrip("\\/")) or "软件"
            fverdict = parent_app[0] if parent_app else "mixed"
            fitem = {
                "name": "%s 的内部文件（共 %d 项）" % (pname, len(internals)),
                "size_kb": round(total, 1),
                "is_dir": True,
                "path": dirpath,
                "safety": "unknown",
                "safety_reason": "",
                "verdict": fverdict,
                "explain": ("这是 %s 的本地数据、设置、索引等内部文件，"
                            "不影响你自己的文档和数据") % pname,
            }
            # 以 verdict 为唯一标准路由：整目录安全才进绿区，否则留黄区钻取
            if fverdict == "safe":
                add_green_cache(dirpath, round(total, 1))
            else:
                result["unknown_children"].append(fitem)

    # 各组内按体积降序，并封顶聚合，避免 DLL/配置碎片刷屏
    for key in ("safe_children", "keep_children", "unknown_children"):
        result[key].sort(key=lambda x: x["size_kb"], reverse=True)
        result[key] = _cap_sublist(result[key], dirpath)

    # 取整
    result["safe_size_kb"] = round(result["safe_size_kb"], 1)
    result["keep_size_kb"] = round(result["keep_size_kb"], 1)
    return result


# ===== 钻取：把目录"打开"，取出里面最大的 Top N 条"鱼" =====
DRILL_TOP_N = 10  # 每层默认展示最大 10 项，不够用户点展开


# ===== 人话说明 · 决策事实采集（供 WorkBuddy Agent 层 LLM 兜底用）=====
# 设计原则（与 SKILL.md 第 2.5 步配套）：
#   脚本只算「针对这个文件」的决策事实，LLM 人话说明由 Agent 用用户当前模型生成，
#   写回 explanations.json；脚本层保留规则 child_explain 作降级。
#   这样无论用户选什么模型、是否联网，流水线都能跑通、不阻塞、不报错。
# 仅对 reversible=="lost"（删了永久丢个人数据）的高危项标记 needs_llm_explain，
# 低风险项（auto 自动重建 / reinstall 可重装）保持一句规则说明即可。
import hashlib

# 个人数据锚点（命中即视为「含个人数据，删了永久丢」）
_PERSONAL_ANCHORS = ("\\downloads\\", "\\desktop\\", "\\documents\\",
                     "\\pictures\\", "\\videos\\", "\\music\\", "\\onedrive\\")
# 本地存聊天记录的通信软件（删本地库 = 电脑端记录永久丢）。
# 用「词边界」正则只匹配文件夹【自身名字】，避免父路径带 qq 导致
# Dictionaries / databases 等子文件夹被误判为永久丢失（见 _contains_personal）。
_CHAT_RE = re.compile(r"(?:^|[^a-z0-9])(weixin|xwechat|wechat|wxwork|tim|qqguild|qqnt|qq)(?=$|[^a-z0-9])")
# 聊天 token → 人话软件名（让 llm_facts.app_context 干净，便于 Agent 写说明）
_CHAT_NAMES = {"weixin": "微信", "xwechat": "微信", "wechat": "微信",
               "wxwork": "企业微信", "tim": "TIM", "qqguild": "QQ频道",
               "qqnt": "QQ", "qq": "QQ"}
# 这些关键字出现在文件夹名里，说明它是「工程/工作区」而非聊天数据，不算个人聊天丢失
_PROJECT_HINTS = ("project", "projects", "workspace", "devspace")

# 红区整体说明（不逐条展开，≤80 字）：卖相 + 一句点明「为什么不动、怎么动」
RED_INTRO = ("这些是已装好的应用本体（微信 / Office / 游戏等）。手动拖删会留注册表垃圾、"
             "甚至删坏系统，一律别在这里动——走系统「设置 → 应用 → 卸载」正规移除即可。")


def _stable_id(path):
    """稳定 id：同一文件多次扫描得到同一 id，便于 Agent 回写说明。"""
    return hashlib.md5(normalize(path).encode("utf-8")).hexdigest()[:12]


def _contains_personal(name_lower, pl):
    # 1) 命中个人数据锚点（下载/桌面/文档/图片/视频/音乐/OneDrive）即视为含个人数据
    if any(a in pl for a in _PERSONAL_ANCHORS):
        return True
    # 2) 工程/工作区文件夹不算聊天数据丢失（如 WeChatProjects 是小程序工程，非聊天记录）
    if any(h in name_lower for h in _PROJECT_HINTS):
        return False
    # 3) 通信软件本地数据（微信/QQ 等）：仅当【文件夹自身名字】以词边界命中聊天 token
    #    才视为删本地库 = 电脑端聊天记录永久丢失。这样 QQ 顶层数据文件夹算 lost，
    #    而其下的 Dictionaries / databases 等资源/缓存子文件夹不会误判为永久丢失。
    if _CHAT_RE.search(name_lower):
        return True
    return False


# 裸 token / 文件夹名 -> 干净中文（或可读品牌）显示名。
# 用于 _app_ctx_of：绝不让 raw token（tencent/kingsoft/steam…）出现在用户可见文案里。
APP_DISPLAY = {
    # 厂商 / 系
    "tencent": "腾讯系软件", "microsoft": "微软系软件", "google": "谷歌系软件",
    "kingsoft": "WPS/金山", "360": "360 系软件", "baidu": "百度系软件",
    "alibaba": "阿里系软件", "netease": "网易系软件", "huawei": "华为系软件",
    "xiaomi": "小米系软件", "meitu": "美图系软件", "bytedance": "字节系软件",
    "mozilla": "Firefox", "adobe": "Adobe", "sogou": "搜狗", "thunder": "迅雷",
    # 英文品牌（用户能认，但用中文括注更友好）
    "steam": "Steam 游戏平台", "epic": "Epic 游戏平台", "battlenet": "战网",
    "origin": "EA 游戏平台", "ubisoft": "育碧游戏平台", "discord": "Discord",
    "spotify": "Spotify", "blender": "Blender", "docker": "Docker",
    "jetbrains": "JetBrains", "unity": "Unity", "autodesk": "AutoCAD",
    "nvidia": "NVIDIA 显卡驱动", "intel": "Intel 驱动", "amd": "AMD 驱动",
    "logitech": "罗技", "razer": "雷蛇", "bandicam": "Bandicam",
    "teamviewer": "TeamViewer", "anydesk": "AnyDesk", "obs": "OBS 录制",
    "vlc": "VLC 播放器", "potplayer": "PotPlayer",
}


def _short_app_name(name_lower, verdict_text):
    """从 APP_VERDICT 的说明句里安全提取一个短软件名（绝不为整句）。"""
    for kw, disp in APP_DISPLAY.items():
        if kw in name_lower:
            return disp
    # 兜底：在第一个标点/括号处截断，并去掉尾部的「缓存/数据/文件」等泛词
    head = re.split(r"[，。；（：(]", verdict_text)[0].strip()
    head = re.sub(r"(缓存|数据|文件|的.*)$", "", head).strip()
    return head or "某个程序"


def _friendly_folder(raw):
    """AppData 路径里取到的文件夹名：裸 token 翻成干净名，否则原样（已可读）。"""
    r = raw.strip()
    rl = r.lower()
    if rl in APP_DISPLAY:
        return APP_DISPLAY[rl]
    # 含中文或已可读品牌（首字母大写/含空格）直接用作显示名
    if any("\u4e00" <= c <= "\u9fff" for c in r) or " " in r or r != r.lower():
        return r
    # 纯小写裸 token 且未映射 -> 不暴露 raw，统一称「某个程序」
    return "某个程序"


def _app_ctx_of(name_lower, pl):
    """尽量给出人话软件名（如「微信」），用于 LLM 提示与用户可见的「来源/归属」字段。
    关键约束：返回值必须是干净的短名，绝不返回整句说明或裸 token。"""
    # 通信软件优先用人话名
    for tok, cn in _CHAT_NAMES.items():
        if tok in name_lower:
            return cn
    an = _app_name(name_lower)
    if an and an[0]:
        return an[0]
    app = _match_app(name_lower)
    if app:
        return _short_app_name(name_lower, app[1])
    if "appdata" in pl:
        parts = pl.replace("/", "\\").split("\\")
        for i, p in enumerate(parts):
            if p.lower() in ("local", "roaming", "locallow") and i + 1 < len(parts):
                return _friendly_folder(parts[i + 1])
    # 兜底：统称「某个程序」，让路径字段承担具体信息，绝不暴露裸 token
    return "某个程序"


def attach_yellow_facts(entry):
    """给一条黄区项补算决策事实，写入 llm_facts / id / needs_llm_explain / llm_explain(空)。

    可逆性三档：
      lost      —— 含个人数据，删了永久丢失（需 LLM 写全人话）
      reinstall —— 应用数据，可重装/重新登录恢复（规则一句带过）
      auto      —— 纯缓存/临时，删了自动重建（规则一句带过）
    """
    name = entry.get("name", "")
    nl = name.lower()
    pl = (entry.get("path", "") or "").lower()
    pd = (entry.get("parent_dir", "") or "").lower()
    contains_personal = _contains_personal(nl, pl)

    # 回收站特判：用户已删除的个人文件，清空后不可恢复
    if pd == "回收站（已删未清）" or "$recycle.bin" in pl:
        reversible = "lost"
    elif contains_personal:
        reversible = "lost"
    elif any(k in nl for k in ("cache", "caches", "temp", "tmp", "log", "logs", "thumb")):
        reversible = "auto"
    else:
        reversible = "reinstall"
    entry["llm_facts"] = {
        "id": _stable_id(entry.get("path", "") or name),
        "last_used": entry.get("last_used", ""),
        "reversible": reversible,
        "contains_personal": contains_personal,
        "app_context": _app_ctx_of(nl, pl),
    }
    entry["needs_llm_explain"] = (reversible == "lost")
    entry.setdefault("llm_explain", "")
    return entry


# 后果句（清了/删了/重登/重装软件）从「这是什么/哪来的」里剥离，
# 统一交给已去焦虑化的【删了会怎样】卡片，避免小白看到"重登/重装"就焦虑不敢删。
_CONS_RE = re.compile(r"[，。]?(清了|删了|重登|重装软件|重新登录)[^，。]*$")
def _strip_consequence(s):
    return _CONS_RE.sub("", s).rstrip("，。 ")


# 低具体度检测：命中说明该条「这是什么」是规则兜底产出、具体度不足，
# 应交 Agent 的 LLM 精修（needs_llm_explain 扩展触发）。
# 关键：只在「解释文本本身」里找泛型兜底特征，绝不拿品牌名（Edge/Chrome/Spotify…）
# 误判——那些已知 app 的解释是具体的，只是来源句里带「运行时在本地产生的数据」这种泛语。
_GEN_EXPLAIN_RE = re.compile(
    r"(运行时自动攒下的数据|产生的本地数据|的本地数据（约|的本地数据，删了重开)")


def _is_low_specificity(explain, origin, app_ctx):
    """True = 这条人话具体度不够，应交 LLM 精修。
    唯一可靠信号：解释文本本身是否来自「泛型兜底分支」（不含任何具体软件/内容名词）。
    不能用 app_context=='某个程序' 判定——SUBDIR_HINTS 等项的解释很具体，
    只是 _app_ctx_of 没认出文件夹名而已，误判会把 75% 已知项送进 LLM。"""
    return bool(_GEN_EXPLAIN_RE.search(explain or ""))


def _cn_brand(name):
    """从混合名称中提取中文品牌/说明部分，例如「腾讯系 • Tencent (Roaming)」→「腾讯系」。"""
    m = re.search(r'[\u4e00-\u9fff]+', name or "")
    return m.group(0) if m else ""


def _parent_app_from_path(path):
    """从 AppData 路径中往上找一级父目录，识别出是哪个软件（例如 Roaming/Feishu/app → 飞书）。"""
    if not path:
        return ""
    parts = re.split(r'[\\/:]', path)
    for i, p in enumerate(parts):
        if p.lower() in ("local", "roaming", "locallow") and i + 1 < len(parts):
            parent = parts[i + 1]
            nl = parent.lower()
            an = _app_name(nl)
            if an and an[0]:
                return an[0]
            if nl in APP_DISPLAY:
                return APP_DISPLAY[nl]
            ctx = _app_ctx_of(nl, "")
            if ctx != "某个程序":
                return ctx
            if any('\u4e00' <= c <= '\u9fff' for c in parent) or " " in parent or parent != parent.lower():
                return parent
            return ""
    return ""


def _folder_semantic(nl):
    """通用子目录名 → 人话语义，让千篇一律的"这个文件夹"变成具体说明。"""
    if nl in ("app", "application"):
        return "主程序数据"
    if nl in ("data",):
        return "运行数据"
    if nl in ("user data", "userdata", "default"):
        return "登录配置和本地数据"
    if nl in ("webstorage", "web storage", "web data"):
        return "网页存储数据"
    if nl in ("partitions", "partition"):
        return "分区数据"
    if nl in ("dictionaries", "dictionary"):
        return "词典/拼写数据"
    if nl in ("gecko",):
        return "内核组件数据"
    if nl in ("shared dictionary", "shared_proto_db", "sharedstorage"):
        return "共享词典数据"
    if nl in ("pre-install", "preinstall"):
        return "预安装组件"
    if nl in ("external-tools", "external tools"):
        return "外部工具组件"
    return ""


def _recommendation(reversible, verdict="mixed", name=""):
    """基于可逆性和判决，给出一句可执行建议。name 用于聊天类特殊处理。"""
    if verdict == "safe":
        return "可以删除，删了会自动重建。"
    if verdict == "keep":
        return "不建议删除，可能影响软件运行。"
    # 聊天/AI对话类：即便可重新登录，聊天记录/对话历史也清空了
    nl = name.lower() if name else ""
    if any(k in nl for k in ("weixin", "wechat", "xwechat", "wxwork", "tim", "qqguild", "qqnt", "qq", "feishu", "lark", "dingtalk", "telegram", "whatsapp", "skype", "slack", "wangwang", "yuanbao", "kimi")):
        if reversible == "lost":
            return "谨慎删除，会丢失电脑端聊天记录。"
        return "可以删除，但电脑端聊天记录会清空。"
    if reversible == "auto":
        return "可以删除，删了会自动重建。"
    if reversible == "lost":
        return "谨慎删除，会丢失个人数据/聊天记录。"
    return "可以删除，删后需重新登录或重建。"


def _sanitize_yellow_desc(desc):
    """把黄区说明里的'缓存'一词泛化/修正，避免用户误以为绿区已清完。"""
    if not desc:
        return desc
    # 精确场景：聊天、图片、文件
    desc = desc.replace("聊天缓存", "聊天记录")
    desc = desc.replace("对话框记录缓存", "对话记录")
    desc = desc.replace("图片/缓存", "图片/文件")
    desc = desc.replace("动图和文件缓存", "动图和文件")
    desc = desc.replace("文件缓存", "文件")
    # 组合型（先处理，避免被下面的通用替换破坏）
    desc = desc.replace("网页/图片缓存", "网页和图片数据")
    desc = desc.replace("图片缓存", "图片文件")
    desc = desc.replace("登录配置和缓存", "登录配置和本地数据")
    desc = desc.replace("内部模块缓存", "内部模块数据")
    # 通用替换：把'缓存'中性化为'数据'或'本地数据'
    desc = desc.replace("缓存和", "数据和")
    desc = desc.replace("网页缓存", "网页数据")
    desc = desc.replace("浏览缓存", "浏览数据")
    desc = desc.replace("软件缓存", "软件数据")
    desc = desc.replace("本地缓存", "本地数据")
    desc = desc.replace("离线歌曲缓存", "离线歌曲数据")
    desc = desc.replace("索引缓存", "索引数据")
    desc = desc.replace("的缓存", "的本地数据")
    # 终极兜底：黄区说明里绝不允许再出现"缓存"二字（绿区才是缓存的归处）
    desc = desc.replace("缓存", "数据")
    return desc


def child_explain(name, is_dir, last_used="", size_kb=0, parent_dir="", path="", reversible="reinstall"):
    """ljg-plain 风格：12 岁小孩也能看懂这是什么、有什么用、删了会怎样。
    只描述事实，不替用户做决策。不同文件夹必须给出不同说明。"""
    nl = name.lower()
    ext = nl.rsplit(".", 1)[-1] if "." in nl else ""
    pl = (path or "").lower()
    app = _app_ctx_of(nl, pl)

    # 当识别不出具体软件时，绝不在用户面前说"某个程序"。
    # 优先从 name 里提取中文品牌；其次用 path 最后一级文件夹的友好名；
    # 实在认不出就用"这个文件夹"这种中性说法，而不是推卸责任的"某个程序"。
    if app == "某个程序":
        cn = _cn_brand(name)
        if cn:
            app = cn
        else:
            leaf = os.path.basename((path or "").rstrip("\\/"))
            if leaf:
                friendly = _friendly_folder(leaf)
                if friendly != "某个程序":
                    app = friendly
                else:
                    # 尝试部分匹配 APP_DISPLAY 中的品牌名
                    for kw, disp in APP_DISPLAY.items():
                        if kw in leaf.lower():
                            app = disp
                            break
            if app == "某个程序":
                app = "这个文件夹"

    # 回收站特判：这是用户自己删过的个人文件，不是任何程序缓存
    if parent_dir == "回收站（已删未清）":
        if is_dir:
            return "你之前删除的文件夹，里面是你自己的文件或软件数据，清空回收站后无法恢复"
        # 文件级：按扩展名给一句更具体的说明
        if ext in ("mp4", "avi", "mkv", "mov"):
            return "你删除的视频文件，清空回收站后无法恢复"
        if ext in ("jpg", "png", "gif", "bmp", "ico", "svg"):
            return "你删除的图片文件，清空回收站后无法恢复"
        if ext in ("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx"):
            return "你删除的文档，清空回收站后无法恢复"
        if ext in ("zip", "rar", "7z", "tar", "gz"):
            return "你删除的压缩包，清空回收站后无法恢复"
        if ext in ("exe", "msi"):
            return "你删除的安装程序/软件，清空回收站后无法恢复"
        return "你之前删除的文件，清空回收站后无法恢复"

    # 删除后果（人话，不吓人）
    rev_text = {
        "auto": "删了会自动重建，不碍事",
        "reinstall": "删了不影响你真正的文件，只是软件的登录状态和界面偏好会清空，重开自动恢复",
        "lost": "删了电脑端数据会永久丢失，手机/云端如果有同步就不会丢",
    }.get(reversible, "删了可能影响软件，拿不准先别动")

    # ---- 1. 目录：先按名字语义猜用途（避免被厂商泛 key 误配）----
    if is_dir:
        # 缓存 / 临时 / 日志
        if nl in ("cache", "caches", "code cache", "gpucache", "shadercache", "thumbnails"):
            return f"{app}的网页/图片数据"
        if "cache" in nl:
            return f"{app}的本地数据，用来让程序启动更快"
        if nl in ("temp", "tmp"):
            return f"{app}的临时文件"
        if "log" in nl or "logs" in nl:
            return f"{app}的运行日志，记录程序运行状态"
        if any(k in nl for k in ("config", "configuration", "settings", "prefs")):
            return f"{app}的设置文件，存着你的账号偏好"
        if any(k in nl for k in ("crash", "dump", "dumps")):
            return f"{app}崩溃时留下的记录"
        if any(k in nl for k in ("download", "downloads", "installer", "setup", "update")):
            return f"{app}的下载/安装残留，一般是安装包或更新包"
        if any(k in nl for k in ("backup", "bak", "old")):
            return f"{app}的备份数据"
        hint = SUBDIR_HINTS.get(nl)
        if hint:
            # 如果 app 只是泛称，就不要加在前面，直接用 hint 里已写清楚的说明。
            if app in ("某个程序", "这个文件夹"):
                return _strip_consequence(hint[1])
            # 避免 app 名与 hint 开头重复（如 app="WPS" + hint="WPS 的图片文件"
            # → 不要变成"WPS WPS 的图片文件"，直接用 hint 已写清楚的说明）
            if hint[1].lower().startswith(app.lower()):
                return _strip_consequence(hint[1])
            return _strip_consequence(f"{app} {hint[1]}")
        if _VERSION_RE.search(nl):
            return f"{app}的旧版本目录，通常新版已经不用"

        # 应用级人话：识别到明确的 app 专属目录（如 wechat files）时给针对说明
        _av = _match_app(nl)
        if _av:
            return _strip_consequence(_av[1])

        # ---- 2. 目录：按路径判断 ----
        # 按类目兜底：用户文件/下载 类目下，即使路径没命中常见个人文件夹，也按个人文件处理
        if parent_dir == "用户文件/下载":
            return "你的个人文件，不是软件缓存，删了不会自动回来"

        # AppData 里的 → 具体软件数据
        if "appdata" in pl:
            an_app, explain = _app_name(nl)
            if an_app:
                return _strip_consequence(explain)
            # 先尝试从父目录识别出是哪个软件，再结合子目录名给具体说明。
            parent_app = _parent_app_from_path(path)
            semantic = _folder_semantic(nl)
            if parent_app and parent_app != "这个文件夹" and semantic:
                return f"{parent_app}的{semantic}（不是你主动保存的文件）"
            if parent_app and parent_app != "这个文件夹":
                return f"{parent_app}里运行产生的数据（不是你主动保存的文件）"
            # 无法识别具体子目录名：诚实说明这是软件运行时自动产生的数据，
            # 不涉及个人文件、删了重开自动恢复——不编造「有设置」这种我们并不确定的细节。
            return f"{app}里运行产生的数据（不是你主动保存的文件）"

        # Program Files 下的 → 程序本身
        if "program files" in pl:
            return f"{app}里装好的程序文件，不能直接删，要去系统「设置 → 应用」里卸载"

        # 用户目录下的个人文件夹
        if any(w in pl for w in ("downloads", "desktop", "documents", "pictures", "videos", "music")):
            return "你的个人文件，不是软件缓存，删了不会自动回来"

        # Temp 目录下的
        if "\temp" in pl or "/temp" in pl or "\tmp" in pl or "/tmp" in pl:
            return f"{app}里的临时文件"

        # 兜底：诚实说明这是软件运行时产生的数据，删了重开自动恢复，不影响个人文件
        if size_kb > 1024 * 1024:
            return f"{app}里的数据（约 %.0f GB）" % (size_kb / 1024 / 1024)
        if size_kb > 100 * 1024:
            return f"{app}里的数据（约 %.0f MB）" % (size_kb / 1024)
        return f"{app}里的数据"

    # ---- 3. 文件：用日常语言说清楚是什么 ----
    if ext in ("log", "txt", "etl"):
        return f"{app}的运行记录，不是给你看的"
    if ext in ("exe", "msi"):
        return "安装程序，软件已经装好了，这个安装包可以删"
    if ext in ("zip", "rar", "7z", "tar", "gz"):
        return "压缩包，解压后这个包本身就没用了"
    if ext in ("db", "sqlite", "sqlite3"):
        return f"{app}的数据库文件，里面存着软件数据"
    if ext in ("dll", "sys", "drv"):
        return f"{app}的系统组件，删了可能导致软件或系统异常，最好别动"
    if ext in ("ini", "json", "xml", "conf", "config"):
        return f"{app}的配置文件"
    if ext in ("tmp", "temp", "bak", "old", "dmp"):
        return f"{app}的临时或备份文件"
    if ext in ("mp4", "avi", "mkv", "mov"):
        return "视频文件"
    if ext in ("mp3", "wav", "flac"):
        return "音频文件"
    if ext in ("jpg", "png", "gif", "bmp", "ico", "svg"):
        return "图片文件"
    if ext in ("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx"):
        return "文档文件"

    return f"{app}的文件"


def child_origin(name, is_dir, app, reversible="reinstall", parent_dir="", path=""):
    """人话「哪来的」：谁产生的、为什么在你电脑上。只讲来源，不评判能不能删。
    按类型给具体来源，不用空泛的「自动攒下的」。app 用友好的上下文名（微信/WPS…）。"""
    nl = name.lower()
    pl = (path or "").lower()

    if is_dir:
        # 回收站特判
        if parent_dir == "回收站（已删未清）":
            return "这是你自己之前删除的文件夹，Windows 把它暂存在回收站里"
        if nl in ("cache", "caches", "code cache", "gpucache", "shadercache", "thumbnails") or "cache" in nl:
            return f"{app} 上网、看视频、开程序时自动存的临时副本，越用越多，清了会自动重建"
        if nl in ("temp", "tmp"):
            return f"{app} 干活时临时占用的空间，用完了本该自动清掉"
        if "log" in nl or "logs" in nl:
            return f"{app} 每次启动、出错时自动记的运行日志，你自己一般不会看"
        if any(k in nl for k in ("config", "configuration", "settings", "prefs")):
            return f"{app} 记下你的账号和界面偏好时写下的，不是你主动保存的文件"
        if any(k in nl for k in ("crash", "dump", "dumps")):
            return f"{app} 崩溃时系统自动抓的现场记录，平时用不到"
        if any(k in nl for k in ("download", "downloads", "installer", "setup", "update")):
            return f"你或 {app} 下载安装包、更新时留下的，装完就基本没用了"
        if any(k in nl for k in ("backup", "bak", "old")):
            return f"{app} 升级或你手动备份时留下的旧副本"
        if _VERSION_RE.search(nl):
            return f"{app} 升级后留下的旧版本目录，新版已经不用了"
        if parent_dir == "用户文件/下载":
            return "你自己下载、保存的个人文件"
        if "appdata" in pl:
            return f"{app} 运行时在本地产生的数据（不是你主动保存的文件）"
        if "program files" in pl:
            return f"{app} 安装时系统写进去的程序文件"
        if any(w in pl for w in ("downloads", "desktop", "documents", "pictures", "videos", "music")):
            return "你自己在用户目录里保存的个人文件"
        if "\temp" in pl or "/temp" in pl or "\tmp" in pl or "/tmp" in pl:
            return f"{app} 临时干活时占的空间，用完没清掉"
        return f"{app} 用的时候在本地产生的数据，不是你主动存的文件"
    # 文件：按扩展名给一句来源
    ext = nl.rsplit(".", 1)[-1] if "." in nl else ""
    # 回收站文件：统一说明来源
    if parent_dir == "回收站（已删未清）":
        return "这是你自己之前删除的文件，Windows 把它暂存在回收站里"
    if ext in ("log", "txt", "etl"):
        return f"{app} 运行、出错时自动写下的记录，你自己一般不看"
    if ext in ("exe", "msi"):
        return "你或系统下载来的安装程序，装完可删"
    if ext in ("zip", "rar", "7z", "tar", "gz"):
        return "你或软件下载来的压缩包，解压后就没用了"
    if ext in ("db", "sqlite", "sqlite3"):
        return f"{app} 运行时不断往里写的数据库，存着软件自己的数据"
    if ext in ("dll", "sys", "drv"):
        return f"{app} 安装时带进来的系统组件"
    if ext in ("ini", "json", "xml", "conf", "config"):
        return f"{app} 记下设置和账号时写下的"
    if ext in ("tmp", "temp", "bak", "old", "dmp"):
        return f"{app} 临时或备份时留下的"
    return f"{app} 用的时候生成的文件，不是你主动保存的"


def _app_name(name_lower):
    """识别常见软件，返回 (日常叫法, 三条信息：这是什么、不影响什么、什么会丢)。
    方向：让人放心删，不说吓人的话。"""
    apps = [
        ("microsoft visual studio","Visual Studio",
         "开发环境的插件和项目缓存。你写的代码不在这，删了只是要重新装插件和打开项目"),
        ("microsoft vs code","VS Code",
         "VS Code装过的插件和设置文件。不影响你写的代码，删了插件要重新装"),
        ("microsoft office","Office",
         "Office自动保存的临时文件和一些模板。不是你存的Word/Excel/PPT文件——那些在你自己选的文件夹里"),
        ("microsoft","微软软件",
         "微软软件的自动生成文件，大多是用不到的临时生成数据"),
        ("360se","360浏览器","360浏览器的浏览数据、历史记录和密码。"),
        ("wxwork","企业微信","企业微信的本地数据，含聊天记录、头像和收到的文件。公司服务器上有记录。"),
        ("qqguild","QQ频道","QQ频道的本地数据，含聊天图片和表情。"),
        ("qqnt","QQ","QQ的本地数据，含聊天图片、表情和收到的文件。"),
        ("qq","QQ","QQ的本地数据，含聊天图片、表情和收到的文件。"),
        ("weixin","微信","微信电脑版的本地数据，含聊天记录和收发的图片/视频/文件。手机端记录不丢。"),
        ("xwechat","微信","微信电脑版的本地数据，含聊天记录和收发的图片/视频/文件。手机端记录不丢。"),
        ("wemeet","腾讯会议","腾讯会议的录制文件和聊天数据。"),
        ("yuanbao","腾讯元宝","腾讯元宝和AI助手的对话记录。"),
        ("kimi","Kimi AI","Kimi AI的对话记录。"),
        ("thunder network","迅雷","迅雷的下载记录和软件设置。不是你下载下来的视频文件。"),
        ("thunder7.9","迅雷","迅雷的下载记录和设置。"),
        ("feishu","飞书","飞书的本地数据，含聊天记录和文件。云端记录不丢。"),
        ("lark","飞书","飞书的本地数据，含聊天记录和文件。云端记录不丢。"),
        ("wps","WPS",
         "WPS自动保存的备份、模板和你最近打开过的文档列表。不是你存的WPS文件——那些在你选的位置。不影响你正常写文档"),
        ("kingsoft","金山WPS","WPS/金山的本地数据和临时文件。"),
        ("sogou","搜狗输入法",
         "输入法记住的你打字习惯和词库。删了输入法打字会变成初始状态，要重新习惯你的打字方式，但不影响正常打字"),
        ("edge","Edge浏览器","Edge浏览器的浏览数据、历史记录和密码。"),
        ("chrome","Chrome浏览器","Chrome浏览器的浏览数据、历史记录和密码。"),
        ("nvidia","NVIDIA显卡","显卡根据你玩的游戏优化过的设置。"),
        ("intel","Intel","Intel驱动的数据文件。"),
        ("huawei","华为","华为系软件的本地数据和临时文件。"),
        ("adobe","Adobe","Adobe系软件（PS、PR等）的临时数据和预置。"),
        ("spotify","Spotify","Spotify的离线歌曲数据。歌单还在。"),
        ("evernote","印象笔记","印象笔记的本地数据。笔记在云端不丢。"),
        ("onedrive","OneDrive","OneDrive的本地数据副本。文件在微软服务器不会丢。"),
        ("百度","百度系软件","百度系软件的本地数据。"),
        ("阿里巴巴","阿里系软件","阿里系软件的本地数据。"),
        ("wangwang","阿里旺旺","阿里旺旺的聊天记录。"),
        ("aliwangwang","阿里旺旺","阿里旺旺的聊天记录。"),
        ("网易","网易软件","网易系软件的本地数据。"),
    ]
    for kw, disp, explain in apps:
        if kw in name_lower:
            return (disp, explain)
    import re
    if re.search(r'[a-z]\d+\.\d+', name_lower):
        return ("软件", "软件的自动生成数据，大多是缓存和设置文件")
    return (None, "软件的自动生成数据，大多是缓存和设置文件")


# ===== 应用级「结论 + 人话」映射（决策助手的核心）=====
# 关键字 -> (verdict, 一句话说明)。verdict ∈ safe / keep / unknown / mixed
# 命中后优先级最高（出现在 _entry_verdict 与 child_explain 的最前），
# 让黄区每个大项都有确切、可执行的人话结论，而不是千篇一律的「你决定」。
# 顺序：具体应用名在前，泛化关键字（microsoft/windows 等）在后。
APP_VERDICT = {
    # —— 浏览器「整目录」：混有密码/书签/历史等个人数据，绝不可整目录标绿 ——
    # 整目录判 mixed：黄区「可清临时数据保资料」，内部的纯缓存子目录会被自动提取进绿区。
    "edge": ("mixed", "Edge浏览器的个人数据目录，含密码、书签、历史和网页数据。"),
    "chrome": ("mixed", "Chrome浏览器的个人数据目录，含密码、书签、历史和网页数据。"),
    "chromium": ("mixed", "Chromium内核浏览器的个人数据目录，含密码、书签和历史。"),
    "firefox": ("mixed", "Firefox的个人数据目录，含密码、书签、历史和网页数据。"),
    "360se6": ("mixed", "360浏览器（360极速版）的完整数据目录，含密码、书签和登录配置。"),
    "360se": ("mixed", "360浏览器的数据目录，含密码、书签和登录配置。"),
    "360chrome": ("mixed", "360浏览器的数据目录，含密码、书签和登录配置。"),
    "360chromeext": ("mixed", "360浏览器的扩展数据。"),
    "qqbrowser": ("mixed", "QQ浏览器的数据目录，含密码、书签和登录配置。"),
    "brave": ("mixed", "Brave浏览器的个人数据目录，含密码、书签和历史。"),
    "opera": ("mixed", "Opera浏览器的个人数据目录，含密码、书签和历史。"),
    "maxthon": ("mixed", "傲游浏览器的数据目录。"),
    "theworld": ("mixed", "世界之窗浏览器的数据目录。"),
    "browser": ("mixed", "浏览器个人数据目录，含密码、书签和历史。"),
    # —— 开发 / 依赖包：可重装或重下，删了不影响代码 ——
    "node_modules": ("safe", "Node 依赖包，npm install 就能重新下载，删了不影响你写的代码"),
    "npm": ("safe", "npm 全局包，重装即可恢复，删了不影响项目代码"),
    "yarn": ("safe", "Yarn 缓存，重装即可恢复"),
    "pnpm": ("safe", "pnpm 临时数据，重装即可恢复"),
    "pip": ("safe", "Python 包的临时数据，重装即可恢复"),
    "site-packages": ("safe", "Python 第三方库，重装即可恢复"),
    "cargo": ("safe", "Rust 依赖数据，重装即可恢复"),
    "nuget": ("safe", ".NET 依赖缓存，重装即可恢复"),
    ".gradle": ("safe", "Gradle 构建缓存，重下即可"),
    ".m2": ("safe", "Maven 仓库缓存，重下即可"),
    ".nuget": ("safe", "NuGet 包缓存，重下即可"),
    ".rustup": ("keep", "Rust 工具链，重装耗时，建议留着"),
    ".cargo": ("keep", "Rust 工具链数据，建议留着"),
    # —— 办公 / 文档：缓存可清，文档别动 ——
    "office": ("mixed", "Office的备份和临时数据。你存的Word/Excel/PPT文件不在这。"),
    "wps": ("mixed", "WPS的备份和临时数据。你存的WPS文档不在这。"),
    "onenote": ("mixed", "OneNote的本地数据。笔记在云端不丢。"),
    "acrobat": ("mixed", "Adobe Acrobat的临时数据。不影响你的PDF文件。"),
    "foxit": ("mixed", "Foxit阅读器的数据和设置。"),
    "pdfelement": ("mixed", "PDFelement的数据和设置。"),
    # —— 云盘 / 聊天：云端记录不丢，本地缓存可清 ——
    "onedrive": ("mixed", "OneDrive的本地数据副本。文件在微软服务器不会丢。"),
    "dropbox": ("mixed", "Dropbox的本地数据副本。文件在云端不会丢。"),
    "googledrive": ("mixed", "Google云端硬盘的本地数据副本。文件在云端不会丢。"),
    "weixin": ("mixed", "微信电脑版的本地数据，含聊天记录和收发的图片/视频/文件。手机端记录不丢。"),
    "wechat": ("mixed", "微信电脑版的本地数据，含聊天记录和收发的图片/视频/文件。手机端记录不丢。"),
    "wxwork": ("mixed", "企业微信的本地数据，含聊天记录和收到的文件。公司服务器上有记录。"),
    "qq": ("mixed", "QQ的本地数据，含聊天记录和收发的图片/文件。"),
    "feishu": ("mixed", "飞书的本地数据，含聊天记录和文件。云端记录不丢。"),
    "lark": ("mixed", "飞书的本地数据，含聊天记录和文件。云端记录不丢。"),
    "dingtalk": ("mixed", "钉钉的本地数据，含聊天记录和文件。云端记录不丢。"),
    "slack": ("mixed", "Slack的本地数据，含聊天记录和文件。云端记录不丢。"),
    "telegram": ("mixed", "Telegram的本地数据，含聊天记录和文件。云端记录不丢。"),
    "whatsapp": ("mixed", "WhatsApp的本地数据，含聊天记录。云端/手机端记录通常不丢。"),
    "skype": ("mixed", "Skype的本地数据，含聊天记录和文件。云端记录不丢。"),
    "飞书": ("mixed", "飞书的本地数据，含聊天记录和文件。云端记录不丢。"),
    "飞鸽": ("mixed", "飞鸽客服的本地数据和日志。"),
    "omniwork": ("mixed", "Omniwork的本地数据和日志。"),
    # —— IDE / 开发工具 ——
    "vscode": ("mixed", "VS Code的插件和设置数据。你的代码不在这。"),
    "visual studio": ("keep", "Visual Studio 本体和组件，重装很慢，建议留着（要释放空间走正规卸载）"),
    "android studio": ("keep", "Android Studio 本体，重装很慢，建议留着"),
    "intellij": ("mixed", "IDEA的插件和设置数据。你的代码不在这。"),
    "pycharm": ("mixed", "PyCharm的插件和设置数据。你的代码不在这。"),
    "clion": ("mixed", "CLion的插件和设置数据。你的代码不在这。"),
    "webstorm": ("mixed", "WebStorm的插件和设置数据。你的代码不在这。"),
    "goland": ("mixed", "GoLand的插件和设置数据。你的代码不在这。"),
    "rider": ("mixed", "Rider的插件和设置数据。你的代码不在这。"),
    "phpstorm": ("mixed", "PhpStorm的插件和设置数据。你的代码不在这。"),
    "xcode": ("keep", "Xcode 本体，重装极慢，建议留着"),
    "sublime": ("mixed", "Sublime Text的数据和配置。"),
    "notepad++": ("mixed", "Notepad++的配置和数据。"),
    "eclipse": ("mixed", "Eclipse的插件和设置数据。你的代码不在这。"),
    # —— 影音 / 创作 ——
    "spotify": ("mixed", "Spotify的离线歌曲数据。歌单还在。"),
    "netflix": ("mixed", "Netflix的本地数据。"),
    "jianying": ("mixed", "剪映的临时数据和草稿缩略图。不影响你导出的成片。"),
    "capcut": ("mixed", "CapCut的临时数据。不影响你导出的成片。"),
    "douyin": ("mixed", "抖音的本地数据。"),
    "kuaishou": ("mixed", "快手的本地数据。"),
    "bilibili": ("mixed", "B站的本地数据。"),
    "iqiyi": ("mixed", "爱奇艺的本地数据。"),
    "youku": ("mixed", "优酷的本地数据。"),
    "网易云": ("mixed", "网易云音乐的本地数据。歌单还在。"),
    "qqmusic": ("mixed", "QQ音乐的本地数据。歌单还在。"),
    "kugou": ("mixed", "酷狗音乐的本地数据。歌单还在。"),
    "kuwo": ("mixed", "酷我音乐的本地数据。歌单还在。"),
    "ximalaya": ("mixed", "喜马拉雅的本地数据。"),
    # —— 游戏平台 / 游戏 ——
    "steam": ("mixed", "Steam游戏平台数据。已下载的游戏可能需要重新验证。"),
    "epic": ("mixed", "Epic游戏平台数据。"),
    "battlenet": ("mixed", "战网游戏平台数据。"),
    "origin": ("mixed", "EA游戏平台（Origin）数据。"),
    "ubisoft": ("mixed", "育碧游戏平台数据。"),
    "ea": ("mixed", "EA游戏平台数据。"),
    "wegame": ("mixed", "WeGame游戏平台数据。"),
    "lol": ("mixed", "英雄联盟的游戏数据和设置。"),
    "dota": ("mixed", "Dota相关游戏数据。"),
    "csgo": ("mixed", "CS:GO的游戏数据和设置。"),
    "genshin": ("mixed", "原神的本地数据和设置。进度在云端不丢。"),
    "原神": ("mixed", "原神的本地数据和设置。进度在云端不丢。"),
    # —— 系统 / 驱动（保留）——
    "packages": ("keep", "Windows 应用（UWP）的数据目录，手删可能让系统应用出错，建议留着"),
    "windows": ("keep", "Windows 系统数据，手删有风险，建议留着"),
    "drivers": ("keep", "驱动相关数据，手删有风险，建议留着"),
    "nvidia": ("keep", "NVIDIA显卡驱动数据。"),
    "intel": ("keep", "Intel驱动数据。"),
    "amd": ("keep", "AMD驱动数据。"),
    "realtek": ("keep", "Realtek声卡/网卡驱动数据。"),
    # —— 创作 / 设计软件 ——
    "adobe": ("mixed", "Adobe系软件（PS、PR等）的临时数据和预置。"),
    "photoshop": ("mixed", "Photoshop的临时数据和预置。"),
    "illustrator": ("mixed", "Illustrator的临时数据和预置。"),
    "premiere": ("mixed", "Premiere的临时数据和预览文件。不影响工程。"),
    "aftereffects": ("mixed", "After Effects的临时数据。"),
    "lightroom": ("mixed", "Lightroom的临时数据和预览。"),
    "audition": ("mixed", "Audition的临时数据。"),
    "blender": ("mixed", "Blender的临时数据和配置。"),
    "autocad": ("mixed", "AutoCAD的临时数据和配置。"),
    "sketchup": ("mixed", "SketchUp的临时数据和配置。"),
    "unity": ("mixed", "Unity编辑器的临时数据和配置。工程不在这。"),
    "unreal": ("mixed", "Unreal Engine的临时数据和配置。工程不在这。"),
    # —— 安全 / 管家 ——
    "huorong": ("keep", "火绒的安全数据，手删可能影响防护，建议留着"),
    "kaspersky": ("keep", "卡巴斯基的安全数据，手删可能影响防护，建议留着"),
    "avast": ("keep", "Avast 的安全数据，手删可能影响防护，建议留着"),
    "defender": ("keep", "Windows  Defender 的安全数据，手删可能影响防护，建议留着"),
    # —— 工具 / 压缩 / 下载 ——
    "7-zip": ("mixed", "7-Zip的配置和数据。"),
    "winrar": ("mixed", "WinRAR的配置和数据。"),
    "bandizip": ("mixed", "Bandizip的配置和数据。"),
    "everything": ("mixed", "Everything的索引数据。"),
    "listary": ("mixed", "Listary的配置和数据。"),
    "snipaste": ("mixed", "Snipaste的配置和数据。"),
    "ditto": ("mixed", "Ditto的剪贴板历史。"),
    "idm": ("mixed", "IDM的下载记录和设置。已下好的文件还在。"),
    "bandicam": ("mixed", "Bandicam的临时数据和配置。"),
    "obs": ("mixed", "OBS的配置和数据。"),
    "vlc": ("mixed", "VLC播放器的临时数据和设置。"),
    "potplayer": ("mixed", "PotPlayer的临时数据和设置。"),
    "teamviewer": ("mixed", "TeamViewer的配置和数据。"),
    "anydesk": ("mixed", "AnyDesk的配置和数据。"),
    "logitech": ("keep", "罗技驱动和配置，手删要重装驱动。"),
    "razer": ("keep", "雷蛇驱动和配置，手删要重装驱动。"),
    # —— 中文互联网 App / 电商 ——
    "taobao": ("mixed", "淘宝的本地数据。"),
    "jd": ("mixed", "京东的本地数据。"),
    "pdd": ("mixed", "拼多多的本地数据。"),
    "alipay": ("mixed", "支付宝的本地数据。"),
    "xiaohongshu": ("mixed", "小红书的本地数据。"),
    "weibo": ("mixed", "微博的本地数据。"),
    "baidu": ("mixed", "百度系软件的本地数据。"),
    "alibaba": ("mixed", "阿里系软件的本地数据。"),
    "wangwang": ("mixed", "阿里旺旺的聊天记录。"),
    "netease": ("mixed", "网易系软件的本地数据。"),
    "huawei": ("mixed", "华为系软件的本地数据。"),
    "meitu": ("mixed", "美图系软件的本地数据。"),
    "xiaomi": ("mixed", "小米系软件的本地数据。"),
    # —— 其他常见软件 ——
    "internet explorer": ("mixed", "IE的浏览数据和历史记录。"),
    "微信开发者工具": ("mixed", "微信小程序开发工具的数据。不影响你写的代码。"),
    "wechat devtools": ("mixed", "微信小程序开发工具的数据。不影响你写的代码。"),
    "workbuddy": ("keep", "WorkBuddy自己的运行数据，删了可能影响助手正常工作。"),
    "accio": ("mixed", "Accio的数据和设置。"),
    "kingsoft": ("mixed", "WPS/金山的本地数据和临时文件。"),
    "google": ("mixed", "谷歌系软件（Chrome、地球等）的本地数据。"),
    "mozilla": ("mixed", "Firefox的个人数据目录，含密码、书签和历史。"),
    "360": ("mixed", "360系软件的数据和设置。"),
    "sogou": ("mixed", "搜狗输入法/浏览器的数据。"),
    "jisu": ("mixed", "搜狗极速浏览器的数据。"),
    "python": ("keep", "Python运行环境，重装耗时。"),
    "codebuddy": ("mixed", "CodeBuddy的数据和设置。"),
    "tencent": ("mixed", "腾讯系软件（微信/QQ/企业微信/元宝等）的本地数据目录，含聊天记录和登录配置。"),
    "youdao": ("mixed", "有道词典的本地数据。"),
    "thunder network": ("safe", "迅雷下载缓存和临时文件。不是你下载好的文件——那些还在你选的下载目录里。删了只是清空下载列表和预读缓存，不影响任何已完成下载"),
    "thunder7.9": ("safe", "同上——迅雷下载缓存，删了不影响已下好的文件"),
    # —— 泛化兜底（务必放最后）——
    "microsoft": ("keep", "微软系软件数据，手删易出问题。"),
}


def _match_app(name_lower):
    """按关键字匹配应用级结论，命中返回 (verdict, explain)，否则 None。
    中文 key 直接子串匹配；英文 key 允许「词边界」或「作为前缀」（兼容 360safe、
    jianyingpro、codebuddyextension 这类带后缀的复合文件夹名，避免已知 app 被漏判成未知）。"""
    for kw, val in APP_VERDICT.items():
        if kw == name_lower:
            return val
        if kw in name_lower:
            # 含中文的 key 直接子串匹配（中文无空格分词，已足够精确）
            if any('\u4e00' <= c <= '\u9fff' for c in kw):
                return val
            # 英文 key：词边界 或 作为文件夹名前缀 都算命中
            if (name_lower.startswith(kw)
                    or re.search(r'(^|[^a-z0-9])' + re.escape(kw) + r'($|[^a-z0-9])', name_lower)):
                return val
    return None


# 通用「子文件夹名语义」判定：拿不准具体 app 时，按文件夹名兜底给结论。
# 命中返回 verdict，否则 None（交给调用方决定）。
_SUB_SAFE = ("cache", "caches", "code cache", "gpucache", "shadercache",
             "thumbnails", "thumbcache", "dawngraphitecache", "dawnwebgpucache",
             "imagecache", "image-cache", "network", "logs", "log",
             "tmp", "temp", "crashpad", "crash", "dump", "tempfiles", "downloads")
_SUB_KEEP = ("runtime", "redist", "vcredist", "sdk", "drivers", "defender",
             "security", "antivirus", "taskbar", "tokenbroker")
_SUB_MIXED = ("data", "config", "settings", "profile", "profiles", "application",
              "gecko", "sentry", "parfait", "rs_sdk", "external-tools",
              "pre-install", "nse", "duba", "shared_proto_db", "partitions",
              "dictionaries", "ark", "nn", "proto")


def _generic_sub_verdict(nl, safety):
    for kw in _SUB_SAFE:
        if kw in nl:
            return "safe"
    for kw in _SUB_KEEP:
        if kw in nl:
            return "keep"
    for kw in _SUB_MIXED:
        if kw in nl:
            return "mixed"
    if safety == "keep":
        return "keep"
    return "unknown"


# ===== 子目录人话映射（专治黄区"打开看"里的文件夹迷宫）=====
# name(小写) -> (verdict, 一句话说明)。verdict ∈ safe/keep/unknown/mixed
# 命中后优先级高于 classify_path，让常见软件子目录有确切结论而非裸名。
SUBDIR_HINTS = {
    "programs": ("keep", "里面装着已安装的软件（如 VS Code、GitHub Desktop），删了软件会打不开，别动"),
    "secoresdk": ("mixed", "360浏览器内核数据。"),
    "office6": ("unknown", "WPS 的内部程序模块，不是你存的文档"),
    "wpsphoto+": ("safe", "WPS 的图片文件，删了不影响你存的照片，会自动重建"),
    "kvip": ("unknown", "WPS 会员相关的本地数据"),
    "duba": ("unknown", "360 安全模块的本地数据，删了 360 会重新初始化"),
    "nse": ("unknown", "软件的内部模块数据，删了软件可能会重新初始化"),
    "kdocprotect": ("keep", "WPS 文档保护相关的数据，建议留着"),
    "kaccclear": ("safe", "WPS 的清理数据，删了自动重建"),
    "code": ("safe", "软件的代码/组件数据，删了重开软件会重建"),
    "user data": ("mixed", "Chrome 内核软件的「用户数据」目录，混有本地数据和登录态"),
    "default": ("mixed", "Chrome 内核软件的默认配置目录，混有本地数据和登录态"),
    # P0-1 修复：local storage / indexeddb 是 PWA / 网页应用的「离线用户数据」
    # （如网页版微信/钉钉的离线消息、Notion 本地库），删了不可恢复。
    # 绝不标绿，统一当 keep（需用户确认），避免旁路误清用户数据。
    "local storage": ("keep", "网页/小程序把你的数据存在本地的仓库（如离线消息、笔记），删了找不回来"),
    "indexeddb": ("keep", "网页应用的内嵌数据库，存着你的本地数据和登录态，删了可能要重新登录或丢数据"),
    "gpu cache": ("safe", "浏览器的显卡数据，删了重开自动重建"),
    "service worker": ("safe", "网站的离线数据，删了重开自动重建"),
    # v1.7.36（审查修复）：blob_storage 是 IndexedDB 的 Blob 持久数据（含站点状态/登录
    # token），绝非纯可再生缓存。此前标 safe 与 local storage/indexeddb（keep）自相矛盾，
    # 仅靠 classify_path 的 KEEP_SEGMENTS 在绿区四道关兜底拦截，属脆弱依赖。改回 keep，
    # 与 KEEP_SUB_NAMES 一致，根除「登录数据可能被旁路标绿」的隐患。
    "blob_storage": ("keep", "网页应用的持久存储数据（含登录态/离线状态），删了可能要重新登录或丢数据"),
    "extensions": ("mixed", "浏览器/编辑器的扩展数据，清了扩展要重装"),
    "extensionstheme": ("mixed", "软件的主题/扩展数据，清了要重装"),
    "session storage": ("safe", "软件的会话数据，删了重开自动重建"),
    "webcache": ("safe", "软件的网页数据，删了重开自动重建"),
    "caches": ("safe", "软件的数据目录，删了重开自动重建"),
    # 通用子目录语义：让下钻后的具体子项也有明确说明，避免千篇一律
    "app": ("mixed", "软件的主程序数据，清了通常要重新登录"),
    "data": ("mixed", "软件的运行数据"),
    "user data": ("mixed", "软件的登录配置和本地数据，清了重开通常会自动恢复"),
    "webstorage": ("safe", "软件的网页存储数据，删了重开自动重建"),
    "partitions": ("mixed", "软件的分区数据"),
    "dictionaries": ("safe", "软件的词典/拼写数据，删了重开自动重建"),
    "gecko": ("mixed", "软件的内核组件数据，清了可能要重新初始化"),
    "shared_proto_db": ("safe", "软件的共享数据库数据，删了重开自动重建"),
    "pre-install": ("mixed", "软件的预安装组件，清了可能影响更新"),
    "external-tools": ("mixed", "软件调用的外部工具组件，清了可能影响部分功能"),
}

# 带版本号的目录（如 12.1.0.26895）：多半是软件更新留下的旧版本
_VERSION_RE = re.compile(r"\d+\.\d+(\.\d+)+")


def _entry_verdict(entry, scan):
    """给黄区顶层项一个一句话结论，帮小白直接决策。"""
    name = (entry.get("name") or "").lower()
    # 1) 应用级结论（最具体，优先）
    av = _match_app(name)
    if av:
        return av[0]
    # 2) 子目录人话映射
    v = SUBDIR_HINTS.get(name)
    if v:
        return v[0]
    safety, _ = path_rules.classify_path(entry["path"])
    if safety == "safe":
        return "safe"            # 可放心删
    if scan and scan.get("safe_size_kb", 0) > 0:
        return "mixed"          # 可清缓存保资料
    if safety == "keep":
        return "keep"           # 建议保留
    # AppData 下的应用数据目录默认「可清临时数据保资料」比「你决定」更可执行、也更诚实
    return "mixed"


def quick_dir_size(path):
    """递归计算目录真实字节数（junction 安全、不限深度）。

    之前用 os.walk 限深 3 层，会把 WPS Office 这种深层目录量成 1.2MB（真实 2.9GB），
    导致黄区父/子体积对不上、假「缺口」让用户不敢信数字。现改为与 scan.py 一致的
    realpath 防环全量递归。返回字节数（调用方再 /1024 得 KB）。
    """
    return _safe_dir_size(path)


def _is_reparse_point(path):
    """Windows reparse point 权威识别（junction / symlink / mount point 通杀）。

    用 Win32 GetFileAttributesW 取 FILE_ATTRIBUTE_REPARSE_POINT 标志。
    不依赖路径字符串对比 —— 因为 os.path.realpath 和 os.path.abspath
    在 Windows 上都会解析 junction，两者总是相等（早期实现漏判的根源）。

    INVALID_FILE_ATTRIBUTES (-1) 必须先排除 —— 否则 -1 & 0x400 == 0x400
    (Python 按无符号整数处理)，会把"API 调用失败"误判成 reparse，反而
    跳过合法目录。
    """
    try:
        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        if attrs == -1:  # INVALID_FILE_ATTRIBUTES = API 调用失败
            return False
        return bool(attrs & _FILE_ATTRIBUTE_REPARSE_POINT)
    except Exception:
        return False


_DIRSIZE_MAX_ENTRIES = 300_000   # 单次顶层调用的条目护栏（与 scan.py 同值同因）
_DIRSIZE_MAX_SECONDS = 30        # 单次顶层调用的时间护栏（与 scan.py 同值同因）


def _safe_dir_size(path, _guard=None):
    """junction/符号链接安全的全量递归体积（字节）。

    AIPC-DIRSIZE-STAT-FIX（v1.7.71 性能根因）：旧实现对**每个目录**调
    os.path.realpath() 防环 —— Windows 上 realpath 会逐级走 GetFinalPathNameByHandle
    系统调用，本机实测 34.3 万次调用耗时 90.8s；再叠加每子目录一次 ctypes
    GetFileAttributesW 判 junction（14.7 万次 / 23.3s），两笔合计约 114s，把 analyze
    全程拖到 183s，正好踩穿 run.py 的 180s 超时闸 → 报告降级成只读页，用户点
    「一键清」「迁移」毫无反应（重点功能全废）。

    新实现与 scan.py:dir_size_bytes（v1.7.30 已生产验证）同一套做法：用
    entry.stat(follow_symlinks=False)。它在 Windows 上随目录枚举结果缓存、零额外
    系统调用，一次就拿到 st_size（体积）与 st_file_attributes（reparse 位）。
    不能靠 is_dir(follow_symlinks=False) / is_symlink() 判 junction —— 实测
    Windows + Python 3.13 上 junction 的 is_dir(follow=False) 仍返回 True、
    is_symlink() 返回 False（scan.py 历史 OOM 事故的根源），必须看 st_file_attributes。
    reparse 既已可靠拦截，而 Windows 无目录硬链接（不存在两条非 junction 路径抵达同一
    目录），故 realpath / inode 去重都不再需要 —— 与 scan.py 的结论一致。
    迭代式遍历（栈深恒为 1，不爆栈），双护栏兜底：单次顶层调用最多 30 万条目 / 30 秒，
    触顶即返回已得结果（宁可少报不可多报，绝不给用户「显示能清 X GB、实际清 Y GB」）。
    """
    if _guard is None:
        _guard = {"n": 0, "t0": time.time()}
    total = 0
    stack = [path]
    while stack:
        if (_guard["n"] >= _DIRSIZE_MAX_ENTRIES
                or (time.time() - _guard["t0"]) > _DIRSIZE_MAX_SECONDS):
            break
        cur = stack.pop()
        try:
            it = os.scandir(cur)
        except (PermissionError, OSError, ValueError):
            continue
        with it:
            for e in it:
                _guard["n"] += 1
                if (_guard["n"] >= _DIRSIZE_MAX_ENTRIES
                        or (time.time() - _guard["t0"]) > _DIRSIZE_MAX_SECONDS):
                    break
                try:
                    st = e.stat(follow_symlinks=False)   # Windows: 枚举缓存，零额外 syscall
                    if getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT:
                        continue      # junction / mount point / symlink：不下钻、不计体积
                    if e.is_dir():
                        stack.append(e.path)
                    else:
                        total += st.st_size
                except (PermissionError, OSError, ValueError):
                    continue
    return total


def drill_down(dirpath, top_n=DRILL_TOP_N):
    """只读钻取：把一个目录打开，取出里面最大的 top_n 个子项（文件或子目录）。

    返回列表，每项：{name, size_kb, is_dir, path, last_used}
    用户看到的是具体的"鱼"——文件名/文件夹名 + 大小 + 多久没动。
    """
    children = []
    try:
        entries = list(os.scandir(dirpath))
    except (OSError, PermissionError):
        return children

    for entry in entries:
        try:
            if entry.is_file():
                size = entry.stat().st_size
            elif entry.is_dir():
                size = quick_dir_size(entry.path)
            else:
                continue
            if size <= 0:
                continue

            # 算这个子项的 mtime → "多久没动"
            try:
                mt = entry.stat().st_mtime
                days_ago = (time.time() - mt) / 86400.0
                if days_ago < 1:
                    last_used = "今天刚动过"
                elif days_ago < 2:
                    last_used = "昨天动过"
                elif days_ago < 7:
                    last_used = "%.0f 天前动过" % days_ago
                elif days_ago < 30:
                    last_used = "约 %.0f 周前动过" % (days_ago / 7)
                elif days_ago < 365:
                    last_used = "约 %.0f 个月前动过" % (days_ago / 30)
                else:
                    last_used = "超过 %.0f 年没动过" % (days_ago / 365)
            except OSError:
                last_used = ""

            children.append({
                "name": entry.name,
                "size_kb": size / 1024.0,
                "is_dir": entry.is_dir(),
                "path": entry.path,
                "last_used": last_used,
            })
        except OSError:
            continue

    # 按体积降序，取前 top_n
    children.sort(key=lambda x: x["size_kb"], reverse=True)
    return children[:top_n]


def get_disk_info():
    """获取 C 盘容量信息：total_gb, used_gb, free_gb, used_pct。"""
    info = {"total_gb": 0, "used_gb": 0, "free_gb": 0, "used_pct": 0}
    try:
        usage = shutil.disk_usage("C:\\")
        info["total_gb"] = round(usage.total / (1024**3), 1)
        info["used_gb"] = round(usage.used / (1024**3), 1)
        info["free_gb"] = round(usage.free / (1024**3), 1)
        if usage.total > 0:
            info["used_pct"] = round(usage.used / usage.total * 100, 1)
    except Exception:
        pass
    return info


MAX_CATEGORY_SHOWN = 15     # 最多展示 15 个类目卡片
CHILD_DRILL_DIRS = 5        # 每个类目钻取最大的 5 个目录
SMART_SCAN_TOP_N = 20       # 每个类目只对 Top 20 大项做完整递归钻取（analyze 主要耗时点）
BIG_CHILD_THRESHOLD_KB = 50 * 1024  # 50MB：只显示 ≥50MB 的真大文件
BATCH_SIZE = 5              # 前端每批展开 5 个大文件
MAX_RED_SHOWN = 20          # 红区最多展示 20 个独立应用




# 黄区类目级「说明 / 处置建议」——按类目区分，避免千篇一律的万金油话术，
# 尤其是「用户文件/下载」是用户自己的文件，绝不能说"删了自动重建"。
_YELLOW_CAT_TEXT = {
    "用户文件/下载": (
        "这些是你自己的个人文件（下载的安装包、文档、图片、视频、备份等），不是软件缓存。"
        "删了不会自动回来，丢了就是丢了。"),
    "用户文件/下载:disposal": (
        "按需挑着删：确认用不上的大块头（旧安装包、看过的电影、过期备份）放心删；"
        "拿不准或可能有用的，先留着别动。"),
    "微信/QQ 数据": (
        "微信 / QQ 的本地数据，里面有聊天记录数据库、你收发的图片 / 视频 / 文件，还有登录态。"),
    "微信/QQ 数据:disposal": (
        "清临时文件（图片 / 视频缩略图）一般安全；但聊天记录数据库删了电脑端就没了（手机端通常不丢）。"
        "拿不准就别动数据库，只删明确的临时数据文件夹。"),
    "回收站（已删未清）": (
        "这些是你之前删过、但还没清空回收站的文件，还占着 C 盘空间。"),
    "回收站（已删未清）:disposal": (
        "看一眼有没有要恢复的（比如刚误删的照片），没有就直接清空回收站。"
        "清空后这些文件就没了，不能再恢复。"),
    # ===== P2-1：黄区「软件数据」细分类别（不再一锅煮）=====
    "通讯软件数据": (
        "微信 / QQ / 钉钉 / 飞书 / 网易等通讯软件的本地数据，含聊天记录数据库、"
        "你收发过的图片 / 视频 / 文件，以及登录态。"),
    "通讯软件数据:disposal": (
        "清临时文件（图片 / 视频缩略图）一般安全；但聊天记录数据库删了电脑端就没了"
        "（手机端通常不丢）。拿不准就别动数据库，只删明确的临时数据文件夹。"),
    "浏览器数据": (
        "浏览器（Chrome / Edge / 360 / Firefox 等）的本地数据，主要是你的登录态、"
        "扩展、个性化设置和收藏，以及一部分可重建的缓存。"),
    "浏览器数据:disposal": (
        "清缓存 / 临时文件一般安全；但登录态、扩展、收藏删了要重新登录或重装。"
        "拿不准就只勾选明确的缓存文件夹。"),
    "办公软件数据": (
        "WPS / Office / 金山 / Adobe 等办公软件的本地数据，含你的模板、最近文档记录、"
        "个性化设置和一部分缓存。"),
    "办公软件数据:disposal": (
        "清缓存 / 临时文件一般安全；但模板、自定义词典、最近文档记录删了要重新配置。"
        "拿不准就只勾选明确的缓存文件夹。"),
    "开发工具数据": (
        "开发工具（VS Code / Node / Python / Rust / Android 等）的本地数据，"
        "含依赖缓存（npm / uv / cargo）、插件和历史记录。"),
    "开发工具数据:disposal": (
        "依赖缓存（node_modules / .npm / .uv / .cargo 等）删了可重下，但重下要花时间；"
        "插件 / 配置删了要重装。只删明确能重建的缓存最稳妥。"),
    "其他软件数据": (
        "其他软件的本地数据目录，里面除了缓存，往往还有你的设置、登录态或工作文件。"),
    "其他软件数据:disposal": (
        "先点开看里面是什么：明确的缓存 / 临时文件可删；设置、登录态、工作文件别动。"
        "拿不准就留着。"),
}


# P2-1：把笼统的「软件数据（需确认）」细分为更具体的类目，让报告更直观、
# 用户更容易判断。仅作用于缓存型应用根「拆缓存后余数」这类黄区项。
_YELLOW_REFINE = (
    ("通讯软件数据", ("tencent", "wechat", "weixin", "wxwork", "wework", "qqnt", "qq",
                      "netease", "dingtalk", "钉钉", "feishu", "飞书", "kuaishou",
                      "bilibili", "discord", "telegram", "skype", "阿里旺旺", "wangwang")),
    ("浏览器数据",   ("chrome", "chromium", "edge", "firefox", "mozilla", "360se", "360",
                      "opera", "brave", "qqbrowser", "sogou", "maxthon", "centbrowser",
                      "browser", "ie ", "internet explorer", "vivaldi", "yandex")),
    ("办公软件数据", ("kingsoft", "wps", "office", "word", "excel", "powerpoint",
                      "outlook", "onenote", "adobe", "foxit", "pdf", "永中", "yozo")),
    ("开发工具数据", ("npm", "yarn", "pnpm", "uv", "cargo", "rust", "gradle", ".m2",
                      "node_modules", "vscode", "android", "jetbrains", "androidstudio",
                      "python", "conda", "go-build", "ms-playwright", "maven", "idea")),
)


def refine_yellow_cat(np_):
    """把「软件数据（需确认）」细分为 通讯 / 浏览器 / 办公 / 开发 / 其他 软件数据。"""
    for label, marks in _YELLOW_REFINE:
        if any(m in np_ for m in marks):
            return label
    return "其他软件数据"


def build_category_entry(cat, total_kb, paths, items):
    """类目级卡片：按类目聚合，展开后列出该类目下所有 ≥50MB 的大文件夹。"""
    ex = get_explain("yellow", cat)

    # 该类目下所有 ≥50MB 的大文件夹（全量，不截断；前端分批展开）
    # 回收站例外：用户已删过，哪怕只有几十 MB 也要展示
    threshold = 0 if cat == "回收站（已删未清）" else BIG_CHILD_THRESHOLD_KB
    top_dirs = [it for it in items if it.get("kb", 0) >= threshold]
    top_dirs.sort(key=lambda x: x["kb"], reverse=True)
    children = []

    # 性能关键：每个类目只对 Top N 大项做完整递归/智能钻取；
    # 其余项复用 scan 已算好的 size_kb，避免 analyze 阶段二次全量 walk。
    for rank, it in enumerate(top_dirs):
        path = it["path"]
        is_dir = it.get("is_dir", os.path.isdir(path))
        if is_dir and rank < SMART_SCAN_TOP_N:
            # 统一用 analyze 的准确递归口径测父项体积，与 smart_sub_scan 子项同源，
            # 彻底消除「父 < 子」的倒挂。写回 it["kb"] 保证概览/类目总计一致。
            full_kb = _safe_dir_size(path) / 1024.0
        else:
            full_kb = float(it.get("kb", 0) or 0)
        it["kb"] = full_kb
        entry = {
            "name": it["name"],
            "path": path,
            "size_kb": round(full_kb, 1),
            "is_dir": is_dir,
            "parent_dir": cat,
            "last_used": human_rel(path),
        }
        # 人话说明机制：先算决策事实，再基于可逆性生成针对本文件的具体说明。
        attach_yellow_facts(entry)
        entry["explain"] = child_explain(
            it["name"], is_dir, human_rel(path), full_kb,
            parent_dir=cat, path=path,
            reversible=entry["llm_facts"]["reversible"],
        )
        # 【哪来的】人话来源字段：谁产生、为什么在这（独立于"这是什么"，补规范缺失格）
        entry["origin"] = child_origin(
            it["name"], is_dir, entry["llm_facts"]["app_context"],
            reversible=entry["llm_facts"]["reversible"], parent_dir=cat, path=path,
        )
        # 扩展 LLM 路由：规则兜底/低具体度（裸 token、含糊短语、未知 app）也打标，
        # 交 Agent 的 LLM 精修——这是跨机器保持「措辞具体度」的关键杠杆。
        entry["needs_llm_explain"] = (
            entry["llm_facts"]["reversible"] == "lost"
            or _is_low_specificity(entry["explain"], entry["origin"],
                                   entry["llm_facts"]["app_context"])
        )
        # ===== 智能钻取：对 Top N 大文件夹『本身』做一层扫描 =====
        if is_dir and rank < SMART_SCAN_TOP_N and full_kb >= SMART_SCAN_THRESHOLD_KB:
            scan = smart_sub_scan(path)
            # 面板触发：只要里面有「安全可删」或「需确认」的子项就展开
            # （不再要求 safe 必须 ≥10MB —— 纯应用数据的大文件夹也应让用户看一眼里面）
            if scan["safe_children"] or scan["unknown_children"]:
                entry["smart_scan"] = scan
                # 黄区钻取出来的子项同样补算决策事实（也是用户会展开决策的点）
                for _sc in scan.get("unknown_children", []):
                    attach_yellow_facts(_sc)
                    # 钻取项也生成人话 + 打 LLM 精修标，保证展开后同样具体、不露怯
                    _sc["explain"] = _sanitize_yellow_desc(child_explain(
                        _sc["name"], _sc.get("is_dir", True), "",
                        _sc.get("kb", 0) or 0, parent_dir=cat, path=_sc.get("path", ""),
                        reversible=_sc["llm_facts"]["reversible"],
                    )) + _recommendation(_sc["llm_facts"]["reversible"], _sc.get("verdict", "mixed"), _sc["name"])
                    _sc["origin"] = child_origin(
                        _sc["name"], _sc.get("is_dir", True),
                        _sc["llm_facts"]["app_context"],
                        reversible=_sc["llm_facts"]["reversible"],
                        parent_dir=cat, path=_sc.get("path", ""),
                    )
                    _sc["needs_llm_explain"] = (
                        _sc["llm_facts"]["reversible"] == "lost"
                        or _is_low_specificity(_sc["explain"], _sc["origin"],
                                               _sc["llm_facts"]["app_context"])
                    )
                safe_kb = scan["safe_size_kb"]
                total = full_kb
                safe_pct = safe_kb / total * 100 if total > 0 else 0
                if safe_kb > 0:
                    entry["explain"] = (
                        "这里面大部分是临时文件（约 {:.0f}% 可安全清理），"
                        "点「智能清理」只删临时文件，不动你的资料。"
                    ).format(safe_pct)
                # 如果没有安全子项，保留上面 child_explain 生成的针对本文件的具体说明，
                # 不再使用千篇一律的「这是程序的数据文件夹」兜底话术。
        entry["verdict"] = _entry_verdict(entry, entry.get("smart_scan"))
        # 黄区说明统一收口：替换'缓存'泛词 + 附加可执行建议
        entry["explain"] = _sanitize_yellow_desc(entry["explain"]) + _recommendation(
            entry["llm_facts"]["reversible"], entry["verdict"], entry["name"])
        # 单一真理源收口：顶层黄区子项若被判定为「可放心删(safe)」，
        # 它不是「需要用户判断的黄区项」，而是应直接进绿区一键清。
        # 整目录纯缓存/纯依赖（node_modules、temp、Cache 子目录……）才会命中 safe，
        # 含个人数据的应用根（Edge/微信……）已被判为 mixed，不会误进绿区。
        if entry["verdict"] == "safe":
            add_green_cache(entry["path"], round(full_kb, 1))
            # 同步把对应扁平 yellow_item 置 0，使下方类目总大小一致、不重复计
            for it in items:
                if normalize(it["path"]) == normalize(entry["path"]):
                    it["kb"] = 0.0
            continue  # 不进入黄区 children
        children.append(entry)

    # 去重（同一路径不重复）
    seen = set()
    unique = []
    for c in children:
        if c["path"] not in seen:
            seen.add(c["path"])
            unique.append(c)

    # 同名消歧：同一个展示名（忽略大小写）出现多次时，用 AppData 子目录（Local / Roaming）后缀区分。
    # 例：QQGuild（Local\Tencent\QQGuild）与 qq_guild（Roaming\qq_guild）本是同一应用的不同数据目录，
    # 不消歧会让用户以为看到了两份。
    def _appdata_suffix(path):
        parts = path.replace("/", "\\").split("\\")
        if "AppData" in parts:
            i = parts.index("AppData")
            if i + 1 < len(parts):
                return parts[i + 1]  # Local / Roaming / LocalLow
        return os.path.basename(os.path.dirname(path.rstrip("\\/")))

    # 跨层级同名消歧（含去下划线归一化）：QQGuild（Local）与 qq_guild（Roaming）
    # 本是同一应用的两个数据目录，不消歧会让用户以为看到两份。
    # 不仅比较顶层项，也把每张卡片钻取出来的子项一并纳入，统一加 AppData 位置后缀。
    def _norm_name(n):
        return n.lower().replace("_", "").replace("-", "").replace(" ", "")
    nodes = []
    for c in unique:
        nodes.append((c, c.get("path", "")))
        for sub in (c.get("smart_scan", {}) or {}).get("unknown_children", []) or []:
            nodes.append((sub, sub.get("path", "")))
        for kc in (c.get("smart_scan", {}) or {}).get("keep_children", []) or []:
            nodes.append((kc, kc.get("path", "")))
    _cnt = {}
    for obj, _p in nodes:
        _cnt[_norm_name(obj.get("name", ""))] = _cnt.get(_norm_name(obj.get("name", "")), 0) + 1
    for obj, _p in nodes:
        if _cnt.get(_norm_name(obj.get("name", "")), 0) > 1 and "（" not in obj.get("name", ""):
            suffix = _appdata_suffix(_p)
            if suffix:
                obj["name"] = "%s（%s）" % (obj["name"], suffix)

    # 聚合类目（多个软件目录被归到一起）：不展示单一误导路径，改为备注说明
    aggregated = len(paths) > 1
    path_note = ""
    if aggregated:
        path_note = ("⚠️ 这个类目是多个软件数据的汇总，共 %d 个目录。"
                     "上面的路径只是其中一个代表，每一条都可单独点「打开看」，"
                     "不要误以为整个类目只跟某一个软件有关。") % len(paths)

    return {
        "name": cat,
        "category": cat,
        "size": kb_to_h(total_kb),
        "path": "" if aggregated else (paths[0] if paths else ""),
        "path_note": path_note,
        "explain": ex,
        "risk": ex.get("risk", ""),
        "why_manual": _YELLOW_CAT_TEXT.get(cat, (
            "这些是软件自动生成的数据（缓存、日志、备份等），90% 以上删了不影响正常使用。"
            "点开每条有具体说明，看一眼就明白能不能删。")),
        "disposal": _YELLOW_CAT_TEXT.get(cat + ":disposal", (
            "看一下说明 — 确认没用就删。拿不准的打开文件夹看看再决定。"
            "删错了大多数不影响——软件会自动重建")),
        "trash_paths": paths[:10],
        "top_children": unique,           # 全部大文件夹（前端分批渲染）
        "small_count": 0,                 # v17 起不再统计兜底小项
        "total_dirs": len(paths),
        "batch_size": BATCH_SIZE,          # 前端每批展开数量
    }


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "analysis.json")
    print("[1/3] 读取扫描结果 …", flush=True)
    with open(src, "r", encoding="utf-8") as f:
        raw = json.load(f)
    print("[2/3] 分级聚合 %d 个目录组 …" % len(raw.get("groups", {})), flush=True)

    system = raw.get("system", {})
    groups = raw.get("groups", {})

    # ---- 收集全部 item ----
    all_items = []
    # v1.7.38（清理迁移残留）：收集迁移残留（.migrated.bak），供报告页「有残留时」显示入口
    _resid_list = []
    for gkey, items in groups.items():
        for it in (items or []):
            # 回收站特殊标记：denied=true 仅表示部分 SID 子目录不可读，_scan_recycle_bin
            # 已经跨 SID 聚合出真实总大小，这里必须放行，否则 6GB+ 回收站会凭空消失。
            if it.get("denied") and normalize(it.get("path", "")) != "__empty_recycle_bin__":
                continue
            if not it.get("path"):
                continue
            # 排除上一次迁移残留的 .migrated.bak（源改名残留，被 explorer 锁住未删）：
            # 它是已迁走数据的冗余副本，由迁移工具负责清理，不是用户需判断的数据，
            # 不应出现在绿/黄/红任何区（避免误导用户、且避免重复计入释放量）。Fix 3
            # 加强：残留是名为「*.migrated.bak」的目录，其下真实子目录（360se6 / MultiTip…）
            # 叶子并不以 .migrated.bak 结尾，endswith 会漏掉。改为「任一路径段」命中即整棵排除。
            _p = normalize(it.get("path", "")).rstrip("\\")
            if any(seg.lower().endswith(".migrated.bak") for seg in _p.split("\\")):
                # v1.7.38（清理迁移残留）：不再简单丢弃——把残留收集起来，供报告页在
                # 「有残留时」显示「清理迁移残留 X GB」入口（没残留则完全不显示）。
                # 残留 = 旧迁移「删源释放」失败留下的 .migrated.bak 冗余副本，junction
                # 已建、目标盘有完整副本，删它是安全的、且能真正释放 C 盘。
                _rb = item_kb(it)
                # ===== v1.7.93（老李 2026-10-06 第三条要求：扫描出来的就必须能处理）=====
                # 实测抓到「幽灵残留」：scan 那一刻目录还在，analyze 真正处理时它已经被
                # 上一次迁移的收尾删掉了（或已被 auto_cleanup_orphan_baks 清掉），
                # 但它仍带着**扫描时的体积**进了残留列表 —— 页面显示「可清理 2.6GB / 3.7GB」，
                # 用户点进去什么都删不到。
                # 【是什么就是什么】磁盘上不存在的东西，一律不进列表、不进绿区。
                _resid_live = False
                try:
                    _resid_live = os.path.lexists(_resid_path) if _resid_path else False
                except Exception:
                    _resid_live = False
                if not _resid_live:
                    try:
                        print("[analyze] 跳过幽灵残留（磁盘上已不存在）: %s" % (_resid_path or "?"))
                    except Exception:
                        pass
                    continue
                if _rb >= 1.0:  # 仅收集 ≥1KB 的真实残留，忽略碎片
                    # v1.7.45（诊断透明化）：复用 migrate.classify_bak_residual 给每个残留标
                    # safe_to_delete + why（轻量判定：不开文件级 missing 比对，避免 analyze 阶段过慢）。
                    # 报告页卡片据此区分显示：可清 vs 不能清（典型场景：junction 被破坏 / 目标盘副本不在），
                    # 用户**未点击**就能看明白"哪些是真正可清、哪些是工具不敢自动删的孤儿"。
                    _resid_path = it.get("path")
                    try:
                        from migrate import classify_bak_residual
                        _safe, _why, _src, _dst = classify_bak_residual(
                            _resid_path, check_files=False)
                    except Exception:
                        _safe, _why, _src, _dst = False, "unknown", "", ""
                    _resid_list.append({
                        "path": _resid_path,
                        "bak": _resid_path,
                        "src": _src,
                        "dst": _dst,
                        "name": os.path.basename(_p.rstrip("\\/")) or "迁移残留",
                        "size_kb": round(_rb, 1),
                        "size_h": it.get("size_h") or kb_to_h(_rb),
                        "safe_to_delete": bool(_safe),
                        "why": _why or "",
                    })
                    # v1.7.83（覆盖度修复）：**安全**的残留额外进绿区，让「一键清」能真正
                    # 释放它。此前无论是否安全都在此 continue 掉，一分都释放不出
                    # （实测本机 pnpm 244MB + BaiduNetdisk 339MB 白占 C 盘）。
                    # 不安全的（如 junction_broken——D 盘没有副本，删了真丢数据）
                    # 绝不进绿区，仍只留在残留列表里提示用户处理。
                    if _safe:
                        add_green_cache(_resid_path, _rb)
                continue
            all_items.append(it)
    print("      已收集 %d 项" % len(all_items), flush=True)

    # ---- 去重：① 路径完全相同的项合并（保留体积更大的一条，消除 Downloads 等同
    #        时被 user_profile 子项与独立锚点重复计）；② 剔除"是别的项前缀"的父目录 ----
    # v1.7.33 优化：原 O(n²) 父目录检测（每项遍历全量 _order）在万级条目下耗时数秒。
    # 改为排序后仅比较相邻项（同前缀的路径排序后必相邻），降为 O(n log n + n)。
    norm_paths = [normalize(it["path"]) for it in all_items]
    _best = {}          # norm_path -> item（保留 kb 最大者）
    for it, np_ in zip(all_items, norm_paths):
        if np_ in _best:
            if item_kb(it) > item_kb(_best[np_]):
                _best[np_] = it
        else:
            _best[np_] = it
    # 排序：确保父路径紧邻其子路径之前（"c:\a" < "c:\a\b"）
    _sorted = sorted(_best.keys())
    # v1.7.83（覆盖度修复·实测根因·最高优先级）：「容器目录」不参与父子去重。
    #
    # 根因：scan 的 user_profile 锚点会把整个 C:\Users\X\AppData 作为**一个** item 吐出来
    # （22.2GB 单项），而 appdata_local / appdata_roaming 两组又各自吐出 20+24 个子项。
    # 父子去重规则「子项若被已记录父目录包含就丢弃」于是把 **63 个 AppData 子项全部
    # 一次性吃掉**（实测：原始 115 项 → 去重后 52 项，AppData 下剩 0 个）。
    # 后果：uv 3.66GB、Tencent 5GB、baidu 3.7GB、Doubao 4GB、全部 -updater 1.7GB
    # 这些真实数据既进不了绿区、也进不了迁移候选 —— 这就是「40GB 黑洞」的真正根因，
    # 比「白名单没命中」更靠底层（白名单那层只是让深扫也返回 0，是第二层问题）。
    #
    # 修法：容器目录（AppData / Local / Roaming / LocalLow / ProgramData / 用户根）
    # **不登记为父**，让它的子项各自参与分级与迁移判定。容器本身最终会被
    # _is_container_dir_itself / is_cache_app_root 等既有逻辑正确处理或忽略。
    def _is_container_np(np_):
        segs = [s for s in np_.split("\\") if s]
        if not segs:
            return True
        last = segs[-1]
        return (last in _DEDUP_CONTAINER_SEGMENTS
                and len(segs) <= _DEDUP_CONTAINER_MAX_SEGS)
    surviving = []
    _parent_set = set()
    _dropped_by_container = 0
    for np_ in _sorted:
        it = _best[np_]
        # 只需检查是否被前一个元素（或已记录的父目录）包含——排序后父必在子之前
        is_parent = any(np_.startswith(p + "\\") for p in _parent_set)
        if not is_parent:
            surviving.append(it)
            if not _is_container_np(np_):
                _parent_set.add(np_)  # 后续项可能以此为父（容器除外，见上）
        else:
            _dropped_by_container += 1
    if _dropped_by_container:
        print("      父子去重丢弃 %d 项（容器目录不参与父子去重，v1.7.83）"
              % _dropped_by_container, flush=True)

    # ---- 全局跨区去重仲裁（前置）----
    # 四套板块（绿/黄/红/迁移）原本各自独立计算、互不核对，导致同一目录（如微信/QQ/Tencent
    # 树）同时出现在迁移、黄区甚至绿区，用户看到重复、体积也被重复计。这里一次性仲裁：
    #   优先级（每条物理路径只归属唯一板块）：迁移(整树搬走) > 绿区(缓存可删) > 黄区(需判断) > 红区。
    # 1) 纯可删缓存型候选（is_green_cache 命中，或 GREEN_APP_ROOTS 整目录可删如迅雷/npm/gradle…）
    #    ——删比搬更合理，且保住完整版「绿区一键清」卖点，从迁移剔除、留绿区（不进排除集）。
    # 2) 其余迁移候选（含用户数据的程序数据树：微信/QQ/Tencent/Steam/WPS/飞书/Kimi…）整树归迁移，
    #    其内部的绿/黄/红子项在主分类循环里直接跳过，随整树搬走，不再单独展示/计体积。
    # 该逻辑按「路径/标记」泛型判断，适配任意电脑、任意软件组合，不写死任何单个 App。
    try:
        import migrate as _migrate
    except Exception:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import migrate as _migrate
    print("[3/3] 计算可迁移大目录（深度遍历，约需数十秒，请稍候）…", flush=True)
    # v1.7.20（目标机实测提速）：三路迁移候选扫描互相独立（各自 walk 磁盘），串行执行
    # 在大用户目录下叠加到 100s+。改为线程池并行，总耗时≈最慢一路（本机实测 3→2 路
    # 并行省 ~40%）。find_migratable_deep 内部已有 35s 预算护栏，并发安全。
    # v1.7.23 分批扫描：fast 模式跳过 find_migratable_deep（全盘深度遍历，慢头）——
    # 首屏只出绿区真实数字，迁移候选由全量 analyze 补全后 reload 报告。
    import concurrent.futures as _cf
    _is_fast = os.environ.get("AIPC_FAST") == "1"
    with _cf.ThreadPoolExecutor(max_workers=3) as _mex:
        _mf1 = _mex.submit(_migrate.find_migratable, groups, system)
        _mf2 = _mex.submit(_migrate.find_migratable_deep) if not _is_fast else None
        _mf3 = _mex.submit(_migrate.find_known_apps)
        _mig_raw = _migrate.merge_candidates(
            _mf1.result(),
            *([] if _mf2 is None else [_mf2.result()]),
            _mf3.result(),
        )
    _mig_cands = []           # 最终迁移候选（已剔除纯缓存、已迁移、残留）
    _mig_roots = set()        # 所有迁移候选根：用于主循环识别缓存应用根，把安全缓存抽进绿区
    # 浏览器纯缓存子目录（Cache/GPUCache/Code Cache…）落在浏览器配置树下、末段是安全缓存结构名。
    # 这些删了自动重建、绝对安全，应 100% 进绿区——且必须早于下方迁移判断，
    # 否则某些浏览器内核目录（如 secoresdk\360se6）被识别为迁移树时，其缓存子目录会被误吞。
    _BROWSER_TREES = (
        "microsoft\\edge\\user data", "google\\chrome\\user data",
        "google\\chrome beta\\user data", "chromium\\user data",
        "mozilla\\firefox\\profiles",
        "360safe\\sesvr",       # 360 安全浏览器（Chromium 系）
        "secoresdk\\360se6",    # 旧版 360 浏览器独立安装，缓存树同上待遇
    )
    def _browser_cache_leaf(np_):
        return any(t in np_ for t in _BROWSER_TREES) and np_.rsplit("\\", 1)[-1] in path_rules.SAFE_CACHE_SEGMENTS
    for _c in _mig_raw:
        _base = os.path.basename(normalize(_c["path"]).rstrip("\\"))
        _pure_junk = is_green_cache(_c["path"]) or _base in (s.lower() for s in GREEN_APP_ROOTS)
        if _pure_junk:
            continue  # 纯可删缓存：不进迁移，留给主循环判成绿区
        # 已迁移判定只看「候选根目录自身是否在 junction 树下」：
        #   - 根是 junction（如整个 Roaming\kimi-desktop 已搬走）→ 整树排除（不进迁移、也不进绿/黄/红）
        #   - 根真实、仅内部个别子目录被迁过（junction）→ 保留根，子路径由 plan_migrations 过滤
        #     （避免把 8GB 的 Roaming\Tencent / 1.2GB 的 Local\Feishu 等真实数据误整树隐藏）
        if _migrate._under_junction(_c["path"]):
            continue
        # 排除上一次迁移残留的 .migrated.bak（源改名残留，被 explorer 锁住未删）：
        # 它不是用户新数据，重新当迁移候选会重复计入体积并误导「本次释放」。（Fix 3）
        # 加强：残留是名为「*.migrated.bak」的目录，其下子目录叶子不以此结尾，
        # 故用「任一路径段以 .migrated.bak 结尾」整棵排除（与下方 merge_candidates 双保险）。
        if any(seg.lower().endswith(".migrated.bak") for seg in _c["path"].replace("/", "\\").rstrip("\\").split("\\")):
            continue
        _mig_cands.append(_c)
        _mig_roots.add(normalize(_c["path"]))
        for _p in _c.get("paths", []):
            _mig_roots.add(normalize(_p["path"]))

    # v1.7.33：预建 set 版本供主循环 O(1) 精确匹配（替代 any() 线性扫描）
    _mig_roots_set = set(_mig_roots)

    # 大用户文件物理搬家候选（mode=move）：不涉程序、不建 junction，搬去 D 盘即真释放 C 盘。
    # 与整目录 junction 迁移互补：junction 用于 app 数据（根治 C 盘满），mode=move 仅留给
    # 真正「散落的个人大文件」（下载/视频/文档根下的电影·ISO·压缩包）——这些文件原路径
    # 不需要继续解析，搬走即释放，且未来新文件仍在 C 本位（属可接受的「非根治」释放）。
    _move_cands = _migrate.find_movable_files(groups, system)
    # 去重叠（根治「尾巴+孤儿」）：若某大文件位于某个「整目录 junction 迁移候选」之下
    # （如微信 xwechat_files 内的大视频），它必须随整目录 junction 一起迁，绝不能再被
    # 单独 mode=move 掏走——否则原目录被掏空、app 找不到文件（孤儿），剩余小文件留在 C
    # 盘形成永久尾巴（即用户说的「留尾巴」）。故剔除所有「落于 junction 候选树下」的散文件，
    # 确保同一份数据只走一条迁移路径（junction = 根治：以后新文件也落其它盘）。
    _junction_roots = set()
    for _jc in _mig_cands:
        _junction_roots.add(normalize(_jc["path"]))
        for _p in (_jc.get("paths") or []):
            _junction_roots.add(normalize(_p["path"]))
    _move_cands = [
        _mc for _mc in _move_cands
        if not any(normalize(_mc["path"]).startswith(r + "\\") for r in _junction_roots)
    ]
    _mig_cands = _mig_cands + _move_cands
    MOVE_PATHS = set()
    for _mc in _move_cands:
        MOVE_PATHS.add(normalize(_mc["path"]))
        for _p in _mc.get("paths", []):
            MOVE_PATHS.add(normalize(_p["path"]))

    # ---- 容量路由提前：先决定哪些候选真正能迁，再建排除集 ----
    # 避免「D 盘不足导致 deferred」的候选被提前排除，从而在黄区里完全消失。
    _target_drive = _migrate.pick_target_drive(system)
    _route = _migrate.route_capacity(_mig_cands, _target_drive, reserve_pct=0.20)
    _mig_cands_passed = _route["migrated_prog"] + _route["migrated_pers"]

    # 只有「确定要迁移」的项才加入 _mig_exclude：主循环里这些用户数据随树搬走，不重复展示。
    # deferred 项不加入，因此其用户数据会落入黄区，提示用户手动判断。
    _mig_exclude = set()
    for _c in _mig_cands_passed:
        _mig_exclude.add(normalize(_c["path"]))
        for _p in _c.get("paths", []):
            _mig_exclude.add(normalize(_p["path"]))

    # ---- 分级 + 聚合 ----
    clear_green_cache()      # 绿区走统一收集器，按软件聚合
    red_acc = {}
    yellow_items = []  # 手动层级：逐真实目录展开（不按类别聚合），每条独立成卡
    excluded_kb = 0.0

    # 回收站并入绿区一键清（用户明确指令 2026-07-22）：用户已删文件仍占位 C 盘，
    # 扫描阶段用特殊标记 __EMPTY_RECYCLE_BIN__ 占位，这里提取体积+文件数后跳过普通分级，
    # 改做一条「绿区」条目（trash_paths 含标记），随绿区一键清一并走 Windows API 清空。
    # 注意：回收站清空=永久删除、剥夺反悔权，不满足绿区「纯缓存·自动重建」铁律，
    # 故条目挂 is_recycle_bin + warn，前端绿区明细里用红色警示样式渲染、点一键清前二次确认提示。
    _recycle_bin_kb = 0.0
    _recycle_bin_count = 0
    for it in surviving:
        if normalize(it.get("path", "")) == "__empty_recycle_bin__":
            _recycle_bin_kb = max(_recycle_bin_kb, item_kb(it))
            _recycle_bin_count = max(_recycle_bin_count, int(it.get("file_count", 0) or 0))

    for it in surviving:
        path = it["path"]
        np_ = normalize(path)
        kb = item_kb(it)

        # v1.7.34（P0 修复）：_is_root/_in_tree 必须在每轮循环开头初始化默认 False。
        # 原实现只在「路径命中某迁移根前缀（_quick_guard=False）」时才给这两个变量赋值；
        # 对绝大多数不落在迁移树下的路径（_quick_guard=True），它们从未被赋值，
        # 而下方 `if (_is_root or _in_tree)` 仍引用 → UnboundLocalError，
        # 导致 AIPC_FAST=0 全量深度遍历路径 100% 崩溃（此前 FAST 模式掩盖了此 bug）。
        # 提前初始化后，非迁移树路径自然走 _is_root=_in_tree=False 分支，逻辑不变且稳健。
        _is_root = False
        _in_tree = False

        # 回收站标记：已在上方提取体积，不在普通分级里处理
        if np_ == "__empty_recycle_bin__":
            continue

        # 大用户文件（物理搬家候选）不进绿/黄/红，改走迁移（move），避免重复计体积
        if np_ in MOVE_PATHS:
            continue

        # 0) 排除环境特定工具目录
        if any(np_.endswith(e) or ("\\" + e + "\\") in np_ for e in EXCLUDE):
            excluded_kb += kb
            continue

        # 0.1) 全局仲裁 —— 消除「微信/QQ 同时出现在迁移+黄区+绿区」跨区重复，
        #      同时满足用户铁律：安全缓存优先留在绿区（绿区是吸引力最强、完整版一键清的卖点）。
        #   规则（按路径泛型判定，适配任意电脑/任意软件组合，不写死任何 App）：
        #   · 迁移树【根】且是可拆缓存应用根(is_cache_app_root)：抽其安全缓存子目录进绿区
        #     （绿区优先），但【不】生成黄区余数——整树随迁移搬走，黄区不再重复展示同一批用户数据。
        #   · 迁移树【根】但非缓存应用根：若已确定迁移 → 跳过；若被容量闸 deferred → 进黄区。
        #   · 迁移树【内部】子项：安全缓存(is_green_cache)→留绿区、继续正常分级；
        #     已确定迁移的用户数据 → 跳过；deferred 用户数据 → 进黄区。
        # 全局仲裁：迁移候选根及其子树，绝不再混入黄区。
        #   · _mig_roots  = 所有迁移候选根（含 passed + deferred）
        #   · _mig_exclude = 已确定可迁的项（passed）
        #   · deferred 项（在 _mig_roots 但不在 _mig_exclude）的安全缓存仍抽进绿区；
        #     其余用户数据直接跳过，不进黄区——它们会在迁移卡片的"待迁移"区展示。
        # v1.7.33 性能：主循环对每项都做 _mig_roots/_mig_exclude 线性扫描（万级条目 × 百级根 =
        # 百万次字符串比较）。改为 set 做 O(1) 精确匹配 + 短列表做前缀匹配（迁移根通常 < 50 个，
        # 开销可忽略），并加快速退出守卫。
        if _mig_roots:
            # 快速守卫：路径不以任何迁移根前缀开头 → 必定不在迁移树下，跳过整块仲裁
            _quick_guard = not any(np_.startswith(mp) for mp in _mig_roots if np_ >= mp)
            if not _quick_guard:
                _is_root = np_ in _mig_roots_set if '_mig_roots_set' in dir() else any(np_ == mp for mp in _mig_roots)
                _in_tree = any(np_.startswith(mp + "\\") for mp in _mig_roots)
            if (_is_root or _in_tree) and not _wechat_qq_safe_segment(np_):
                if _is_root and is_cache_app_root(np_):
                    # 抽安全缓存进绿区；余数（无论 passed/deferred）都不进黄区
                    for fp, fkb in extract_cache_subdirs(path):
                        add_green_cache(fp, fkb)
                    continue
                if (_is_root or _in_tree) and (is_green_cache(np_) or _browser_cache_leaf(np_)):
                    pass  # 内部/根安全缓存子项（含浏览器纯缓存）：留绿区，继续正常分级
                elif any(np_ == mp or np_.startswith(mp + "\\") for mp in _mig_exclude):
                    continue  # 已确定迁移的用户数据随树搬走，不重复展示/计体积
                else:
                    continue  # deferred 项的用户数据：不进黄区，由迁移区统一展示

        # 0.4) 系统级安全缓存特判：必须放在 is_cache_app_root 之前！
        #    ProgramData 下的路径会触发 is_cache_app_root=True，
        #    然后 extract_cache_subdirs 没找到子缓存就把整目录降级黄区，
        #    导致缩略图/Search索引/事件日志/.NET缓存等被错误放进黄区。
        #    这种情况应当直接归绿（is_system_cache 已经精确锚点匹配）。
        if path_rules.is_system_cache(path):
            add_green_cache(path, kb)
            continue

        # 0.5) 浏览器纯缓存子目录特判：Chrome/Edge/Firefox/360 的 Cache / Cache_Data /
        #    GPUCache / Code Cache 等。这些目录虽然在 User Data/Profiles 下，
        #    path_rules 会因 user data 等 KEEP 段一刀切 keep；但纯缓存子目录只含
        #    网络资源副本，删了自动重建，可安全清。
        #    判定复用上方 _browser_cache_leaf（已含浏览器树 + 安全缓存末段双重校验），
        #    且它已在前置 _mig_exclude 逃生舱放行，确保不被迁移树（如 secoresdk）误吞。
        #    （Cookies/Login Data 等个人数据段名不在 SAFE_CACHE_SEGMENTS，不会被误绿）
        if _browser_cache_leaf(np_):
            add_green_cache(path, kb)
            continue

        # 0.6) 微信/QQ 数据：若在迁移计划内 → 整树随迁移搬走（含缓存一并去 D 盘）；
        #   若不在迁移计划内（D 盘满 / 无 D 盘）→ 抽安全缓存进绿区，其余不再进黄区，
        #   而是作为 deferred 候选在迁移卡片"待迁移"区展示。
        #   老李拍板（2026-07-29）：迁移是最安全、释放最彻底的 C 盘减压手段——
        #   微信/QQ 的数据优先走迁移，绝不因「能拆缓存」而保留在黄区抢迁移名额。
        if "\\wechat files\\" in np_ or "\\tencent files\\" in np_ or "\\xwechat_files\\" in np_ or "\\weixin files\\" in np_:
            # 若已被迁移计划覆盖 → 跳过（暂存区的缓存子目录也一块迁到 D 盘）
            # v1.7.33：先 O(1) 精确匹配（set），再 O(m) 前缀扫描
            if _mig_exclude and (np_ in _mig_exclude or any(np_.startswith(mp + "\\") for mp in _mig_exclude)):
                continue
            # 不在迁移计划内 = D 盘不足 deferred。只抽安全缓存进绿区，余数不进黄区。
            seg = _wechat_qq_safe_segment(np_)
            if seg:
                add_green_cache(path, kb)
            else:
                cache = _extract_wechat_qq_cache(path)
                for fp, fkb in cache:
                    add_green_cache(fp, fkb)
                # remainder 不再放入 yellow_items；由 migration_block.deferred_candidates 统一展示
            continue

        # 1) 缓存型应用根：若已被迁移计划覆盖→整树随迁移搬走；
        #    若未覆盖→拆"缓存子目录→绿区"，"整目录其余→黄区"。
        if is_cache_app_root(np_):
            if _mig_exclude and (np_ in _mig_exclude or any(np_.startswith(mp + "\\") for mp in _mig_exclude)):
                continue
            found = extract_cache_subdirs(path)   # [(cache_dir, kb)]
            cache_kb = sum(s for _, s in found)
            if found:
                for fp, fkb in found:
                    add_green_cache(fp, fkb)
                remainder = kb - cache_kb
                if remainder > 1024:  # >1MB 才算黄区
                    ycat = "微信/QQ 数据" if ("tencent" in np_ or "wechat" in np_
                                              or "qq" in np_) else refine_yellow_cat(np_)
                    yellow_items.append({"cat": ycat, "path": path, "kb": remainder,
                                         "_remainder": True,
                                         "name": pretty_name(path, ycat)})
                continue
            else:
                # 整目录未识别出纯缓存 → 降级黄区，绝不整目录标绿。
                # 注意：此处不标 _remainder。因为整目录没有拆出任何缓存，
                # 它本质是"整目录黄区"，应由下方去重逻辑判断其内部是否已被绿区子目录认领
                # （例如 Thunder Network 整目录其实全是缓存，绿区已认领其 Thunder7.9 子目录）。
                ycat = "微信/QQ 数据" if ("tencent" in np_ or "wechat" in np_
                                          or "qq" in np_) else refine_yellow_cat(np_)
                yellow_items.append({"cat": ycat, "path": path, "kb": kb,
                                      "name": pretty_name(path, ycat)})
                continue

        # 2) 其余走普通分级
        tier, cat = tier_and_cat(path)
        if tier == "red":
            r = red_acc.setdefault(cat, {"kb": 0.0, "items": []})
            r["kb"] += kb
            r["items"].append({"name": os.path.basename(path.rstrip("\\/")), "path": path, "kb": kb})
        elif tier == "green":
            add_green_cache(path, kb)
        else:
            yellow_items.append({"cat": cat, "path": path, "kb": kb,
                                  "name": pretty_name(path, cat)})

    # ---- 去重：黄区排除已被绿区认领的路径（消除迅雷等重复统计）----
    # 绿区已通过 add_green_cache 把每条可清缓存的 (path, kb) 收集进 _ALL_GREEN_PATHS。
    # 一条黄区项若整体被某个绿区路径包含（相等或绿区是其子目录），说明它的内容已全进绿区，
    # 黄区应扣掉已进绿区的部分；扣完 ≤1MB 则该项丢弃（如 Temp\Thunder Network 整目录全是缓存）。
    # is_cache_app_root 产生的「整目录减缓存」余数项带 _remainder 标记，已是正确的余数，勿重复扣。
    _green_norm = [(normalize(p), kb) for p, kb in _ALL_GREEN_PATHS]
    for it in yellow_items:
        if it.get("_remainder"):
            continue
        yp = normalize(it["path"])
        # 物理搬家项（大文件）的父目录：其内容正被搬去 D 盘，黄区不再重复计
        if any(mp.startswith(yp + "\\") for mp in MOVE_PATHS):
            it["_drop"] = True
            continue
        green_under = sum(kb for gp, kb in _green_norm
                          if gp == yp or gp.startswith(yp + "\\"))
        if green_under >= it["kb"] - 1:
            it["_drop"] = True
        else:
            it["kb"] = it["kb"] - green_under
    yellow_items = [it for it in yellow_items if not it.get("_drop")]

    # ---- 黄区瘦身：把"拿不准"的系统级大头收进「高级·需谨慎」折叠区 ----
    # 这些（WinSxS/卷影/休眠文件/未归类目录/Windows Installer 等）删了要 DISM/正规操作，
    # 不是"删了无关痛痒"，不该和安装包/回收站混在黄区吓人。收进折叠区信息不丢、默认不显眼。
    SYSTEM_RISKY_MARKERS = (
        "winsxs", "system volume information", "hiberfil.sys", "pagefile.sys",
        "swapfile.sys", "未归类·待确认", "windows\\installer",
        "deliveryoptimization", "windows.old",
    )
    advanced_items = []
    _yellow_keep = []
    for it in yellow_items:
        p = normalize(it["path"])
        if any(m in p for m in SYSTEM_RISKY_MARKERS):
            advanced_items.append(it)
        else:
            _yellow_keep.append(it)
    yellow_items = _yellow_keep

    # ---- 组装 green / yellow / red 列表 ----
    green, yellow, red = [], [], []
    # 黄区先组装（其智能钻取会把内部缓存归到绿区收集器）
    # 黄区：按类目聚合（不是逐真实目录展开），每个类目卡片点击展开后显示 Top 单文件
    from collections import defaultdict
    yellow_by_cat = defaultdict(lambda: {"kb": 0.0, "paths": [], "items": []})
    for it in yellow_items:
        g = yellow_by_cat[it["cat"]]
        g["kb"] += it["kb"]
        g["paths"].append(it["path"])
        g["items"].append(it)
    cat_list = [(cat, g["kb"], g["paths"], g["items"])
                for cat, g in yellow_by_cat.items()]
    cat_list.sort(key=lambda x: x[1], reverse=True)
    cat_list = cat_list[:MAX_CATEGORY_SHOWN]
    yellow = [build_category_entry(cat, kb, paths, items)
              for cat, kb, paths, items in cat_list]
    # 过滤掉已无子项的空类目（其大文件夹全被判定 safe 改进了绿区）
    yellow = [c for c in yellow if c.get("top_children")]
    yellow_hidden = max(0, len(yellow_by_cat) - MAX_CATEGORY_SHOWN)

    # ---- 高级·需谨慎 折叠区：系统级大头（与黄区同管道组装，默认不显眼）----
    advanced_by_cat = defaultdict(lambda: {"kb": 0.0, "paths": [], "items": []})
    for it in advanced_items:
        g = advanced_by_cat[it["cat"]]
        g["kb"] += it["kb"]
        g["paths"].append(it["path"])
        g["items"].append(it)
    adv_cat_list = [(cat, g["kb"], g["paths"], g["items"])
                    for cat, g in advanced_by_cat.items()]
    adv_cat_list.sort(key=lambda x: x[1], reverse=True)
    advanced = [build_category_entry(cat, kb, paths, items)
                for cat, kb, paths, items in adv_cat_list[:MAX_CATEGORY_SHOWN]]
    advanced = [c for c in advanced if c.get("top_children")]
    advanced_kb = sum(it["kb"] for it in advanced_items)

    # ---- 二次去重（关键修复）----
    # build_category_entry 内部的智能钻取（smart_sub_scan）会把黄区目录内部的纯缓存子目录
    # （如 Thunder Network 里的 Thunder7.9）提升为绿区——这些绿区路径在上面的「扁平去重」之后
    # 才加入 _ALL_GREEN_PATHS，导致扁平去重看不到它们、黄区父项被重复统计。
    # 这里在类目已构建、绿区路径齐备后，再核一次黄区每个子项：整体被绿区认领的丢弃，
    # 部分重叠的扣减；并同步扣减对应的扁平 yellow_item，使下方 y_kb / 概览数值一致。
    _green_norm_final = [(normalize(p), kb) for p, kb in _ALL_GREEN_PATHS]
    for cat in yellow:
        kept = []
        for child in cat.get("top_children", []):
            cp = normalize(child["path"])
            ckb = child.get("size_kb", 0.0)
            if ckb <= 0:
                kept.append(child)
                continue
            gu = sum(kb for gp, kb in _green_norm_final
                     if gp == cp or gp.startswith(cp + "\\"))
            if gu >= ckb - 1:
                # 整体已被绿区认领 → 丢弃，并同步把对应扁平项置 0
                for it in yellow_items:
                    if normalize(it["path"]) == cp:
                        it["kb"] = 0.0
                continue
            if gu > 0:
                child["size_kb"] = ckb - gu
                child["size"] = kb_to_h(child["size_kb"])
                for it in yellow_items:
                    if normalize(it["path"]) == cp:
                        it["kb"] = ckb - gu
            kept.append(child)
            # 保险：父项显示大小不得低于其展示出的子项之和，杜绝「父 < 子」倒挂
            if child.get("smart_scan"):
                sub_total = sum(c.get("size_kb", 0.0) for c in
                               child["smart_scan"].get("unknown_children", [])
                               + child["smart_scan"].get("keep_children", []))
                if sub_total > 0 and child.get("size_kb", 0.0) < sub_total:
                    child["size_kb"] = round(sub_total, 1)
                    child["size"] = kb_to_h(child["size_kb"])
                    for it in yellow_items:
                        if normalize(it["path"]) == cp:
                            it["kb"] = child["size_kb"]
        cat["top_children"] = kept
        # 重新计算类目总大小：直接取该类的扁平 yellow_item 合计（已同步扣减/置零），
        # 这样含小项、且与下方 y_kb / 概览数值完全一致，不会因只看 top_children 而缩水。
        cat_kb = sum(it["kb"] for it in yellow_items if it.get("cat") == cat["category"])
        cat["size"] = kb_to_h(cat_kb)
        # 打磨#4：黄区类目卡片点出"最大子项"，降低用户对整桶体量的焦虑、敢动手
        top = sorted(cat.get("top_children", []), key=lambda x: x.get("size_kb", 0), reverse=True)
        if top:
            big = top[0]
            cat["largest_child"] = {"name": big.get("name", ""), "size": big.get("size", "")}
        cat["count"] = len(cat.get("top_children", [])) + (cat.get("small_count") or 0)

    # 绿区：所有「安全缓存」已通过 add_green_cache 收集，这里统一按软件聚合。
    green = build_green_from_cache()

    # 回收站并入绿区一键清：作为一条绿区条目（trash_paths 含 __EMPTY_RECYCLE_BIN__ 标记），
    # server 清理循环见标记直接调空回收站 API。体积计入 green_reclaim_kb（见下方 g_kb 自然累加），
    # 也计入释放区间 floor（一键清即可完成、不需重启，属保底释放）。
    if _recycle_bin_kb >= 1.0:
        green.append({
            "name": "回收站（已删除文件·清空不可恢复）",
            "software": "回收站",
            "path": "C:\\$Recycle.Bin（回收站）",
            "size_estimate": kb_to_h(_recycle_bin_kb),
            "kb": _recycle_bin_kb,
            "trash_paths": ["__EMPTY_RECYCLE_BIN__"],
            "commands": [{"label": "清空回收站（确认后执行）", "cmd": ""}],
            "is_recycle_bin": True,
            "file_count": _recycle_bin_count,
            "warn": "清空后不可恢复——请先确认回收站里没有要找回的文件（如刚误删的照片/文档）。一键清理会连同它一起清空。",
            "explain": {
                "title": "已删除文件（清空=永久丢失）",
                "body": "回收站里是你之前删掉、还没彻底清除的文件。一键清理会连同它一起清空，清空后无法恢复。点一键清前，请确认里面没有要找回的东西。",
            },
        })

    # 红区：v9 改为按应用拆分（不再按 cat 合并），每个应用独立一张卡
    # 收集所有应用，按体积降序，最多展示 20 个最大应用
    all_red_apps = []
    for cat, c in red_acc.items():
        for app in c["items"]:
            all_red_apps.append({**app, "cat": cat})
    all_red_apps.sort(key=lambda x: x["kb"], reverse=True)
    for app in all_red_apps[:MAX_RED_SHOWN]:
        red.append({
            "name": app["name"],
            "path": app["path"],
            "kb": app["kb"],
            "size": kb_to_h(app["kb"]),
            "why_keep": ("这是 {name} 的程序本体。要卸载请在 Windows「设置 → 应用」里搜 {name} 点卸载，"
                         "别手动删文件夹——手动删会留下垃圾、还可能让别的软件出问题。").format(name=app.get("name")),
            "indirect_release": "用系统「设置→应用→卸载」或软件自带卸载器正规移除",
            "auto_reclaim": False,
            "explain": get_explain("red", app["cat"]),
            "app_paths": [app["path"]],
        })

    # ---- Top5：跨区按体积取最大 5 项 ----
    flat = []
    for g in green:
        flat.append(("green", g["kb"], g["name"], g["path"]))
    for it in yellow_items:
        flat.append(("yellow", it["kb"], it["name"], it["path"]))
    for cat, c in red_acc.items():
        n_apps = len(c["items"])
        flat.append(("red", c["kb"], f"已装应用（共 {n_apps} 项）", "C:\\Program Files\\… 等多个目录（详见下方应用本体）"))
    flat_sorted = sorted(flat, key=lambda x: x[1], reverse=True)[:5]
    top5 = [{
        "rank": i + 1,
        "tier": t,
        "size": kb_to_h(kb),
        "type": {"green": "缓存/临时", "yellow": "用户数据", "red": "应用"}[t],
        "name": name,
        "path": path,
        "note": {"green": "可安全清", "yellow": "需你确认", "red": "走卸载"}[t],
    } for i, (t, kb, name, path) in enumerate(flat_sorted)]

    g_kb = sum(g["kb"] for g in green)
    y_kb = sum(it["kb"] for it in yellow_items)
    r_kb = sum(c["kb"] for c in red_acc.values())
    total_kb = g_kb + y_kb + r_kb

    # 防止总和超过磁盘已用（理论不会，这里做一道保险校验）
    used_kb = 0.0
    try:
        used_kb = float(str(system.get("disk_used", "0")).split()[0]) * 1024 * 1024
    except Exception:
        used_kb = 0.0
    if used_kb and total_kb > used_kb * 1.02:
        print("[WARN] 可回收合计 %.1f GB 超过 C盘已用 %.1f GB，请检查去重逻辑"
              % (total_kb / 1024 / 1024, used_kb / 1024 / 1024))

    overview = ("你这台电脑 C 盘飘红。扫出来总共可回收约 %.1f GB："
                "🟢 可安全清 %.1f GB（纯缓存，删了自动重建）、"
                "🟡 需你判断 %.1f GB（安装包/下载等，删了无关痛痒）、"
                "🔴 应用 %.1f GB（走正规卸载）。"
                "本次扫描聚焦 C 盘主要可回收热点，少量零散小目录未计入，不影响主体判断。" % (
                    total_kb / 1024 / 1024, g_kb / 1024 / 1024,
                    y_kb / 1024 / 1024, r_kb / 1024 / 1024))

    summary = {
        "overview": overview,
        "tier_stats": {
            "green": "%.1f GB" % (g_kb / 1024 / 1024),
            "yellow": "%.1f GB" % (y_kb / 1024 / 1024),
            "red": "%.1f GB" % (r_kb / 1024 / 1024),
        },
        "priority": [
            "🟢 第一步·清缓存：%.1f GB 全是纯缓存/临时文件，绝对安全。在 WorkBuddy 里说一句「扫描电脑」，本地清理服务会自动启动，点「一键清理」就能全部释放，删了自动重建、不动你的任何资料。空间够了就停，其它完全不用动。" % (g_kb / 1024 / 1024),
            "🟡 第二步·看个人文件（可选）：缓存不够用时，再看个人文件。每一项都用人话说明了是什么、删了会怎样，点「📂 打开看」就能定位到文件，确认没用再「直接删除」。下载/视频/安装包这类是你自己的文件，挑着删、拿不准就留着。",
            "🔴 应用本体·别动：微信/Office/游戏… 走系统「设置→应用→卸载」正规移除，手动拖删会留注册表残留、甚至删坏系统。",
        ],
        "long_term": [
            "微信/QQ 的聊天文件定期在软件内清理，别堆在 C 盘。",
            "浏览器下载目录设到其他盘，减少 C 盘压力。",
            "装软件时改默认路径到 D 盘。",
        ],
    }

    # ---- 系统缓存读取缺口检测（扫描层信号，解决「静默漏」门槛）----
    # 这些根需要管理员权限才能读；非管理员时 scan.py 返回 denied 标记，
    # 而下面 analyze 会 if denied: continue 直接丢弃 → 报告里连"有东西没扫到"都看不出。
    # 所以必须在这里数一下，便于报告挂横幅提示用户「以管理员身份重扫」。
    # v1.7.36（审查修复）：补齐 v1.7.35 新增的 5 个低风险系统缓存锚点
    # （cbs_logs/livekernel_reports/minidump/fontcache/memory_dump），否则它们的
    # denied 标记不计入 system_cache_denied，系统缓存「未读全」横幅对这些新锚点失效。
    SYSTEM_CACHE_ROOTS = ("win_temp", "prefetch", "sd_download",
                          "delivery_opt", "delivery_opt2", "wer",
                          "cbs_logs", "livekernel_reports", "minidump",
                          "fontcache", "memory_dump")
    system_cache_denied = 0
    for k in SYSTEM_CACHE_ROOTS:
        for it in (raw.get("groups", {}).get(k) or []):
            if it.get("denied"):
                system_cache_denied += 1
                break

    # ---- 迁移方案（Pro 版核心能力）：复用上方「全局仲裁」已算好的候选 ----
    # 容量路由已在分类循环前完成（_route / _mig_cands_passed），避免排除集先建导致 deferred 项被隐藏。
    # 此处直接复用，避免重复深扫、也避免覆盖已清洗的候选。
    # 仅程序数据 / 缓存 / 游戏库，绝不碰个人文件（见 migrate.SAFE_MIGRATE_PATTERNS）

    # 决策1（老李拍板）：给程序数据候选打 category，供前端「应用数据 / 开发·工具」两筐展示。
    # 纯展示标签，不影响任何行为；小白机器无开发目录时该筐自然为空。
    def _cat_of(c):
        p = (c.get("path") or "").lower().replace("/", "\\")
        _dev_marks = ("rustup", ".gradle", ".conda", ".m2", ".nuget", "node_modules",
                      ".cargo", ".npm", ".kimi-work", ".trae", "android", "\\sdk\\",
                      "vscode", ".uv", "venv", ".venv", "python3", "\\go\\", "\\rust\\")
        for _k in _dev_marks:
            if _k in p:
                return "dev"
        return "app"
    for c in _mig_cands_passed:
        c["category"] = _cat_of(c)
    for c in _route["deferred_prog"]:
        c["category"] = _cat_of(c)

    # 把「D 盘空间不足被 deferred」的项也放进 plan，但打上 capacity_exceeded 标记。
    # 前端统一按体积排序展示、默认全选；用户勾选总量超过可用空间时提示手动删减。
    # P1-B（2026-08-01 审查修正）：个人文件与程序数据统一走此机制——「能迁移的绝不
    # 放黄区（删不删你说了算）」，装不下的个人文件（含 OneDrive）也进迁移卡可勾选部分迁移。
    # ===== v1.7.93（老李 2026-10-06 第三条要求：扫描出来的就必须能处理）=====
    # 病根：候选列表**完全没有检查路径的真实身份**，导致两类「点了必失败/虚报」的项混进来：
    #   ① 已经是 junction 的路径 —— 它早就搬到 D 盘了，C 盘【已经不占这个体积】，
    #      但仍被标成「可迁移 N GB」，用户点下去必然失败。
    #      实测：本机 ima.copilot 已 junction→d:\AI_PC_Migrated\...，
    #      仍列在候选里虚报 663.2MB。
    #   ② 磁盘上根本不存在的路径 —— 扫描那一刻有、此刻没了（或已迁移完）。
    #
    # 【老李原话】「必须做到扫描出来的就能够处理」→ 反过来就是：
    #   处理不了的，**不许出现在候选里**。宁可少报，不可给用户一个必然失败的选项。
    def _is_junction_like(p):
        """是不是 junction / 符号链接（Windows 上 os.path.isjunction 从 3.12 起才有）"""
        try:
            if hasattr(os.path, "isjunction") and os.path.isjunction(p):
                return True
        except Exception:
            pass
        try:
            if os.path.islink(p):
                return True
        except Exception:
            pass
        # 兜底：读 reparse point 属性（junction 的 FILE_ATTRIBUTE_REPARSE_POINT = 0x400）
        try:
            import ctypes as _ct
            attrs = _ct.windll.kernel32.GetFileAttributesW(str(p))
            if attrs != -1 and (attrs & 0x400):
                return True
        except Exception:
            pass
        return False

    _dropped_unprocessable = []
    _kept = []
    for _c in _mig_cands_passed:
        _p = _c.get("path") or ""
        _why = ""
        try:
            if _p and not os.path.lexists(_p):
                _why = "磁盘上已不存在"
            elif _p and _is_junction_like(_p):
                _why = "已迁移到其它盘（是链接，不再占 C 盘）"
        except Exception:
            pass
        if _why:
            _dropped_unprocessable.append({"name": _c.get("name") or _p,
                                           "path": _p,
                                           "size_h": _c.get("size_h") or "",
                                           "reason": _why})
        else:
            _kept.append(_c)
    if _dropped_unprocessable:
        try:
            print("[analyze] 剔除非可处理的候选 %d 项: %s"
                  % (len(_dropped_unprocessable),
                     "; ".join("%s(%s)" % (x["name"], x["reason"]) for x in _dropped_unprocessable)))
        except Exception:
            pass
    _mig_cands_passed = _kept

    _all_mig_cands = list(_mig_cands_passed)
    for _c in _route["deferred_prog"]:
        _c2 = dict(_c)
        _c2["capacity_exceeded"] = True
        _all_mig_cands.append(_c2)
    for _c in _route["deferred_pers"]:
        _c2 = dict(_c)
        _c2["capacity_exceeded"] = True
        _all_mig_cands.append(_c2)
    _mig_plan = _migrate.plan_migrations(_all_mig_cands, _target_drive) if _target_drive else []
    migratable_reclaim_kb = sum(c["size_kb"] for c in _mig_cands_passed)
    deferred_reclaim_kb = (sum(c["size_kb"] for c in _route["deferred_prog"])
                           + sum(c["size_kb"] for c in _route["deferred_pers"]))
    total_reclaim_kb = migratable_reclaim_kb + deferred_reclaim_kb
    green_reclaim_kb = g_kb
    # AIPC-NO-DOUBLE-COUNT-FIX-A：绿区条目若落在某个迁移候选之内，同一块空间会被
    # 「可清理」和「可迁移」各算一遍 → 页面报的总量虚高。这里把重叠的那一份扣掉。
    _green_pairs = []
    for _g in green:
        _gp = normalize(_g.get("path") or "")
        if _gp:
            _green_pairs.append((_gp.lower(), float(_g.get("kb") or 0)))
    _overlap_kb = 0.0
    _overlap_n = 0
    for _gp, _gkb in _green_pairs:
        for _c in _all_mig_cands:
            _cp = normalize(_c.get("path") or "").lower()
            if _cp and (_gp == _cp or _gp.startswith(_cp + "\\") or _gp.startswith(_cp + "/")):
                _overlap_kb += _gkb
                _overlap_n += 1
                break
    if _overlap_n:
        print("   [去重] 绿区与迁移候选重叠 %d 处，扣减 %.1f MB（同一块空间不算两遍）"
              % (_overlap_n, _overlap_kb / 1024.0))
    pro_reclaim_kb = g_kb + total_reclaim_kb - _overlap_kb
    # P1-B：个人文件不再进黄区（删除原 yellow_pers → 黄区 append + recommended_delete）

    # 程序数据因 D 盘空间不足被 deferred：现在统一放进 plan 并打 capacity_exceeded 标记，
    # 前端按体积排序展示、默认全选；容量不足时提示用户取消部分项。不再单独展示 deferred 区块。
    _deferred_candidates = []

    _free_gb = 0.0
    _total_gb = 0.0
    try:
        _free_gb = float(str(system.get("disk_free", "0")).split()[0])
    except Exception:
        _free_gb = 0.0
    try:
        _total_gb = float(str(system.get("disk_total", "0")).split()[0])
    except Exception:
        _total_gb = 0.0
    _safe_line_gb = max(10.0, _total_gb * 0.15)
    _free_after_green_gb = _free_gb + green_reclaim_kb / 1024.0 / 1024.0
    # 目标盘剩余空间（供前端报告写出数字、按充裕度给颜色等级）
    _target_free_gb = 0.0
    if _target_drive:
        _td = _target_drive.rstrip(":\\") + ":\\"
        try:
            _target_free_gb = round(shutil.disk_usage(_td).free / (1024**3), 1)
        except Exception:
            _target_free_gb = 0.0
    # ---- 候选目标盘（供前端迁移弹窗选择）----
    # 列出全部非系统固定盘 + 剩余空间 + 推荐标记；推荐盘 = pick_target_drive 自动选中的那个。
    _sysdrive = (system or {}).get("disk_name") or "C:\\"
    _sysdrive = _sysdrive.lower().rstrip("\\") + "\\"
    try:
        from migrate import _parse_gb as _pgb
    except Exception:
        def _pgb(x):
            return 0.0
    _avail_drives = []
    for _d in (system or {}).get("disks") or []:
        _name = (str(_d.get("name") or "")).lower().rstrip("\\") + "\\"
        if _name == _sysdrive:
            continue
        _free = _pgb(_d.get("free"))
        if _free > 0:
            _avail_drives.append({"letter": _name, "free_gb": round(_free, 1)})
    try:
        from migrate import pick_target_drive as _pick_target_drive
        _rec_drive = _pick_target_drive(system) if _target_drive else None
    except Exception:
        _rec_drive = None
    for _dd in _avail_drives:
        _dd["recommended"] = bool(_rec_drive) and _dd["letter"] == _rec_drive.lower()
    _avail_drives.sort(key=lambda x: x["free_gb"], reverse=True)

    migration_block = {
        "available": bool(_target_drive),
        "target_drive": _target_drive,
        "available_drives": _avail_drives,
        "target_free_gb": _target_free_gb,
        "candidates": _mig_cands_passed[:30],
        "deferred_candidates": _deferred_candidates,
        "reclaim_kb": migratable_reclaim_kb,
        "reclaim_h": kb_to_h(migratable_reclaim_kb),
        "total_reclaim_kb": total_reclaim_kb,
        "total_reclaim_h": kb_to_h(total_reclaim_kb),
        "plan": _mig_plan,
        "capacity": _route["capacity"],
        "personal_routed": {
            "auto_move": len(_route["migrated_pers"]),
            "auto_move_kb": sum(c["size_kb"] for c in _route["migrated_pers"]),
            "to_deferred": len(_route["deferred_pers"]),
            "to_deferred_kb": sum(c["size_kb"] for c in _route["deferred_pers"]),
        },
        "need_external_drive": _route["need_external_drive"],
    }
    solution_block = {
        # AIPC-NO-DOUBLE-COUNT-FIX-B：把重叠量摆到台面上，便于事后核对
        # （pro = green + migration - overlap 必须严格成立）
        "green_mig_overlap_kb": round(_overlap_kb, 3),
        "green_reclaim_kb": green_reclaim_kb,
        "green_reclaim_h": kb_to_h(green_reclaim_kb),
        "pro_reclaim_kb": pro_reclaim_kb,
        "pro_reclaim_h": kb_to_h(pro_reclaim_kb),
        "deferred_kb": sum(c["size_kb"] for c in _route["deferred_prog"]) + sum(c["size_kb"] for c in _route["deferred_pers"]),
        "deferred_h": kb_to_h(sum(c["size_kb"] for c in _route["deferred_prog"]) + sum(c["size_kb"] for c in _route["deferred_pers"])),
        "free_gb": round(_free_gb, 1),
        "free_after_green_gb": round(_free_after_green_gb, 1),
        "safe_line_gb": round(_safe_line_gb, 1),
        "migration_available": bool(_target_drive) and migratable_reclaim_kb > 0,
    }

    analysis = {
        "generated_at": raw.get("generated_at") or time.strftime("%Y-%m-%d %H:%M:%S"),
        "scan_seconds": raw.get("scan_seconds") or 0,
        "system": system,
        "disk_info": get_disk_info(),   # C盘容量：供前端仪表盘
        "system_cache_denied": system_cache_denied,  # >0 表示系统缓存未完整读取
        "top5": top5,
        "green": green,
        # v1.7.85（老李「扫出来清理不了，前后矛盾」根因③）：
        # 扫到但现在删不掉的绿区缓存（被正在运行的软件独占 / 需管理员）单列一份，
        # 报告页在「一键清」旁边明写「另有 XX GB 要关掉软件或重启电脑才能清」。
        # 这样用户【出报告那一刻】就知道哪些清不掉 —— 不用等点完清理干等半天
        # 才被告知「清不掉」。这一批绝不进 green（即绝不进删除白名单与承诺口径）。
        "green_deferred": [dict(d, size_estimate=kb_to_h(d.get("kb", 0.0)))
                           for d in _GREEN_DEFERRED if (d.get("kb") or 0) >= 1.0],
        "yellow": yellow,
        "yellow_hidden": yellow_hidden,
        "advanced": advanced,
        "advanced_kb": advanced_kb,
        "red": red,
        "red_intro": RED_INTRO,  # 红区整体说明（不逐条展开）
        "summary": summary,
        "migration": migration_block,
        "solution": solution_block,
        # v1.7.38（清理迁移残留）：旧迁移删源失败留下的 .migrated.bak 残留列表。
        # 前端只在它非空时显示「清理迁移残留」入口；为空则完全不显示。
        "migrated_residuals": _resid_list,
    }
    # v1.7.32+（老李定调：黄区/红区整体删除）：数据层不再产出黄区/红区——
    # 报告页只渲染「一键清 + 迁移」两区。绿区判定逻辑必须保留（is_green_cache 的
    # verdict 四道关是「绝对安全」的根基，黄区目录内的缓存提纯也依赖 smart_sub_scan），
    # 仅输出层清空，行为彻底、零误删风险。
    analysis["yellow"] = []
    analysis["yellow_hidden"] = 0
    analysis["advanced"] = []
    analysis["advanced_kb"] = 0
    analysis["red"] = []
    analysis["red_intro"] = ""
    analysis["top5"] = [t for t in (top5 or []) if t.get("tier") == "green"]
    _sm = analysis.get("summary") or {}
    if _sm.get("tier_stats"):
        _sm["tier_stats"] = {"green": _sm["tier_stats"].get("green", "0 GB")}
    # 两区模型 overview / priority（去掉黄区/红区话术，只讲一键清 + 迁移）
    _sm["overview"] = (
        "你这台电脑 C 盘飘红。扫出来总共可回收约 %.1f GB："
        "🟢 可安全清 %.1f GB（纯缓存，删了自动重建），"
        "另有 %.1f GB 大目录可迁移到其它盘（只搬不删、软件照常用）。"
        "本次扫描聚焦 C 盘主要可回收热点，少量零散小目录未计入，不影响主体判断。" % (
            pro_reclaim_kb / 1024 / 1024,
            g_kb / 1024 / 1024,
            total_reclaim_kb / 1024 / 1024))
    _sm["priority"] = [
        "🟢 第一步·清缓存：%.1f GB 全是纯缓存/临时文件，绝对安全。点「一键清理」即可全部释放，删了自动重建、不动你的任何资料。空间够了就停，其它完全不用动。" % (g_kb / 1024 / 1024),
        "📦 第二步·迁移大目录（可选）：缓存不够用时，把微信/QQ/游戏等大目录搬到其它盘（只搬不删、建链接、软件照常用），C 盘以后也不容易满。",
    ]
    with open(out, "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2)
    print("[OK] 分级+聚合完成:")
    print("   原始 %d 项 → 去重后保留 %d 项 → 聚合为 绿%d / 黄%d / 红%d 类"
          % (len(all_items), len(surviving),
             len(green), len(yellow), len(red)))
    print("   排除环境工具数据 %.1f GB（不计入可回收）" % (excluded_kb / 1024 / 1024))
    print("   可安全清 %.1f GB · 需判断 %.1f GB · 应用 %.1f GB · 合计 %.1f GB"
          % (g_kb / 1024 / 1024, y_kb / 1024 / 1024, r_kb / 1024 / 1024, total_kb / 1024 / 1024))
    if used_kb:
        print("   C盘已用 %.1f GB（合计未超，数据自洽 [OK]）" % (used_kb / 1024 / 1024))
    print("   输出: %s" % out)


if __name__ == "__main__":
    try:
        t0 = time.time()
        main()
        print("[analyze] 总耗时 %.1fs" % (time.time() - t0), flush=True)
    except Exception as _e:
        import traceback
        sys.stderr.write("\n[ANALYZE-ERROR] 分级聚合失败: %s\n" % _e)
        traceback.print_exc()
        sys.exit(2)
