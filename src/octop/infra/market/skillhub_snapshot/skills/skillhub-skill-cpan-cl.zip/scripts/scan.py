#!/usr/bin/env python3
"""Read-only storage scanner (macOS + Windows).

Collects disk usage, system info, and per-directory size breakdowns for the
hot spots that typically eat disk, and emits one JSON blob to stdout for Claude
to interpret and classify. Auto-detects the OS and scans the right locations.

STRICTLY READ-ONLY: only sizes/lists/reads metadata. Never creates, moves, or
deletes anything.

Output shape (same on both OSes):
{
  "generated_at", "scan_seconds",
  "system": {os, build, arch, user, home, filesystem,
             disk_total, disk_used, disk_free, purgeable,
             disks: [{name, total, used, free}]},   # all volumes/drives
  "groups": { "<group>": [{name, path, size_kb, size_h}], ... }
}
"""
import ctypes
import json
import os
import shutil
import sys
import time
import traceback
import threading

HOME = os.path.expanduser("~")

# FILE_ATTRIBUTE_REPARSE_POINT = 0x400 —— Windows 唯一权威识别
# junction / symlink / mount point 的标志（用 GetFileAttributesW 拿）。
# 注意：早期版本用 os.path.realpath vs os.path.abspath 对比 ——但二者
# 都会解析 junction，所以两者总是相等 → 永远返回 False → 漏判所有
# junction。后果：8 线程并发扫到 .workbuddy（指向 D 盘几 GB 的 venv）
# 时进 D 盘狂吃内存 → OOM → 进程被 Windows 杀掉 + 0 字节输出
# (用户看到的就是"退出码 1 但啥也没出来")。
_FILE_ATTRIBUTE_REPARSE_POINT = 0x400

# 记录被扫描护栏截断的根目录名（analyze / 报告可据此提示"部分未读完"）
_TRUNCATED_ROOTS = set()


def _record_truncated(root_name, entries_seen, elapsed):
    """扫描命中 entries/time 护栏时记录并输出进度。"""
    name = root_name or "unknown"
    _TRUNCATED_ROOTS.add(name)
    print("[scan] %s 达到扫描上限（已扫 %d 个目录项，耗时 %.1fs），部分子目录未计入"
          % (name, entries_seen, elapsed), file=sys.stderr, flush=True)


def human(kb):
    """KB number -> human string like '12.3 GB'."""
    n = float(kb) * 1024
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit not in ("B", "KB") else f"{int(n)} {unit}"
        n /= 1024


def _is_reparse_point(path):
    """Windows reparse point 权威识别（junction / symlink / mount point 通杀）。

    用 Win32 GetFileAttributesW 取 FILE_ATTRIBUTE_REPARSE_POINT 标志。
    不依赖路径字符串对比 —— 因为 os.path.realpath 和 os.path.abspath
    在 Windows 上都会解析 junction，两者总是相等（早期实现漏判的根源）。

    INVALID_FILE_ATTRIBUTES (-1) 必须先排除 —— 否则 -1 & 0x400 == 0x400
    (Python 按无符号整数处理)，会把"API 调用失败"误判成 reparse，反而
    跳过合法目录。
    """
    try:
        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
        if attrs == -1:  # INVALID_FILE_ATTRIBUTES = API 调用失败
            return False
        return bool(attrs & _FILE_ATTRIBUTE_REPARSE_POINT)
    except Exception:
        return False



# ======================================================================
# macOS
# ======================================================================
import re
import subprocess


def run(cmd, timeout=180):
    try:
        kwargs = {}
        if sys.platform.startswith("win"):
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kwargs).stdout
    except Exception:
        return ""


def du_children(path, min_kb=51200, limit=40):
    """Size every immediate child of `path` via du, sorted desc. macOS."""
    if not os.path.isdir(path):
        return []
    results = []
    try:
        entries = sorted(os.listdir(path))
    except PermissionError:
        return [{"name": "(permission denied)", "path": path,
                 "size_kb": 0, "size_h": "?", "denied": True}]
    for name in entries:
        if name in (".", ".."):
            continue
        child = os.path.join(path, name)
        if os.path.islink(child):
            continue
        out = run(["du", "-sk", child], timeout=120)
        m = re.match(r"\s*(\d+)", out)
        if not m:
            continue
        kb = int(m.group(1))
        if kb < min_kb:
            continue
        results.append({"name": name, "path": child, "size_kb": kb, "size_h": human(kb)})
    results.sort(key=lambda r: r["size_kb"], reverse=True)
    return results[:limit]


MAC_TARGETS = [
    ("home", HOME, 102400),
    ("library", os.path.join(HOME, "Library"), 51200),
    ("caches", os.path.join(HOME, "Library/Caches"), 51200),
    ("containers", os.path.join(HOME, "Library/Containers"), 51200),
    ("group_containers", os.path.join(HOME, "Library/Group Containers"), 51200),
    ("app_support", os.path.join(HOME, "Library/Application Support"), 51200),
    ("applications", "/Applications", 102400),
    ("downloads", os.path.join(HOME, "Downloads"), 51200),
    ("dev_caches", None, 51200),
]

MAC_DEV_CACHE_PATHS = [
    "~/Library/Caches/pip", "~/Library/Caches/uv", "~/.cache", "~/.cargo",
    "~/.npm", "~/.pnpm-store", "~/.gradle", "~/.m2",
    "~/Library/Developer/Xcode/DerivedData", "~/Library/Developer/CoreSimulator",
    "~/Library/Developer/Xcode/iOS DeviceSupport", "~/Library/pnpm",
    "~/go/pkg", "~/.docker",
]


def dev_caches_macos():
    results = []
    for p in MAC_DEV_CACHE_PATHS:
        path = os.path.expanduser(p)
        if not os.path.isdir(path):
            continue
        out = run(["du", "-sk", path], timeout=180)
        m = re.match(r"\s*(\d+)", out)
        if not m:
            continue
        kb = int(m.group(1))
        if kb < 51200:
            continue
        results.append({"name": os.path.basename(path.rstrip("/")) or path,
                        "path": path, "size_kb": kb, "size_h": human(kb)})
    results.sort(key=lambda r: r["size_kb"], reverse=True)
    return results


def system_info_macos():
    info = {}
    info["os"] = "macOS " + run(["sw_vers", "-productVersion"]).strip()
    info["build"] = run(["sw_vers", "-buildVersion"]).strip()
    arch = run(["uname", "-m"]).strip()
    brand = run(["sysctl", "-n", "machdep.cpu.brand_string"]).strip()
    info["arch"] = (f"Apple Silicon (arm64){' / ' + brand if brand else ''}"
                    if arch == "arm64" else f"{arch}{' / ' + brand if brand else ''}")
    info["user"] = os.environ.get("USER", "") or run(["whoami"]).strip()
    info["home"] = HOME
    total, used, free = "?", "?", "?"
    try:
        t, u, f = shutil.disk_usage("/")
        total, used, free = human(t // 1024), human(u // 1024), human(f // 1024)
    except Exception:
        pass
    info["disk_total"], info["disk_used"], info["disk_free"] = total, used, free
    dinfo = run(["diskutil", "info", "/"])
    fs = re.search(r"File System Personality:\s*(.+)", dinfo)
    info["filesystem"] = fs.group(1).strip() if fs else "APFS"
    pm = re.search(r"Purgeable Space:\s*([\d.,]+ \w+)", dinfo)
    info["purgeable"] = pm.group(1).strip() if pm else ""
    info["disk_name"] = "Macintosh HD"
    info["disks"] = [{"name": "Macintosh HD", "total": total, "used": used, "free": free}]
    return info


def scan_macos():
    system = system_info_macos()
    groups = {}
    for key, path, floor in MAC_TARGETS:
        groups[key] = dev_caches_macos() if key == "dev_caches" else du_children(path, min_kb=floor)
    return system, groups


# ======================================================================
# Windows  (UNTESTED on this build — stdlib only: os, shutil, ctypes)
# ======================================================================
def dir_size_bytes(path, _seen=None, depth=0, root_name=None):
    """迭代算子树大小（os.scandir 栈遍历，栈深度永远 = 1，绝不递归爆栈）。

    v1.7.30 性能重写（目标机扫描 148s → 提速的核心项之一）：
    旧实现用 os.walk + 每个子目录额外 3 次系统调用（os.path.islink + GetFileAttributesW
    判 reparse + os.stat），每个文件再 lstat 一次 —— 本机实测 31.6 万次 lstat 耗时 ~64s、
    17.9 万次 islink ~29s，成为扫描最大瓶颈。新实现直接遍历 os.scandir 的 DirEntry：
    Windows 上 FindFirstFile/FindNextFile 枚举时已带回 stat 信息，entry.is_dir(
    follow_symlinks=False) / entry.stat() 均为缓存读取，零额外系统调用；junction /
    symlink（reparse point）在 follow_symlinks=False 下天然返回 False，与旧实现
    「跳过 reparse 子树」语义一致。

    防环三道闸（顺序由廉价到昂贵）：
      1) entry.is_dir(follow_symlinks=False) == False（reparse point 带
         FILE_ATTRIBUTE_REPARSE_POINT，is_dir(follow_symlinks=False) 必为 False）
         —— 跳过 junction / mount point / symlink
      2) (st_dev, st_ino) inode 集合 —— 即便 (1) 漏判，撞 inode 也会拒
      3) 顶层 _seen 集合只在单次调用内传递，避免跨线程膨胀

    双重护栏：单次扫描最多 30 万 entries、最多 90 秒；任一触顶即返回。
    超过的部分计入实际 total，但不会让进程无限耗下去（避免 OOM）。

    `depth` 参数仅作兼容保留（旧调用方可能传），新实现不依赖它。
    `root_name` 用于进度日志与截断标记（如 'appdata_local'）。
    """
    if _seen is None:
        _seen = set()
    total = 0
    denied = False
    truncated = False
    try:
        st = os.stat(path)
        inode_key = st.st_ino
    except (OSError, ValueError):
        inode_key = None
    if inode_key is not None and inode_key in _seen:
        return 0, denied
    if inode_key is not None:
        _seen.add(inode_key)

    started = time.time()
    entries_seen = 0
    last_progress = started  # 用 started 作基准，避免第一秒就狂打进度
    MAX_ENTRIES = 300_000      # 30 万 entries 护栏（约数百万文件）
    MAX_SECONDS = 30           # 30 秒护栏（单根最坏耗时，从 90s 缩减 —— 全局有 150s 硬上限，不再容忍 90s/根）
    # v1.7.23（生产审计修复）：temp 等 agg 聚合根是绿区最大头（本机 39GB），全量扫描时
    # 线程池 32 路并发争抢磁盘 IO，temp 遍历常被 30s 护栏截断 → 大头丢失 → 全量数字
    # 暴跌（快扫 42GB → 全量 6.5GB），破坏「数字只增不减」承诺。关键根放宽到 60s/60 万条。
    if root_name in ("temp", "win_temp"):
        MAX_SECONDS = 60
        MAX_ENTRIES = 600_000
    # v1.7.83（迁移覆盖度修复·2026-10-04）：用户数据三大根是「迁移候选」的唯一来源，
    # 30s/30 万条护栏对本机（用户目录 51.8G / 62 万文件）会整根截断：
    # 实测 user_profile 被标 truncated，WorkBuddy 那 10.55G 根本没读完 → 报告少算十几 GB。
    # 迁移是本工具的核心卖点，这三根值得多花时间；全局仍有 150s 硬上限兜底。
    if root_name in ("user_profile", "appdata_local", "appdata_roaming"):
        MAX_SECONDS = 90
        MAX_ENTRIES = 3_000_000
    PROGRESS_INTERVAL_SEC = 5  # 每 5 秒输出一次进度，缓解用户焦虑
    PROGRESS_INTERVAL_ENT = 50000  # 每 5 万 entries 也输出一次

    def _emit_progress(force=False):
        nonlocal last_progress
        now = time.time()
        if force or now - last_progress >= PROGRESS_INTERVAL_SEC or entries_seen - getattr(_emit_progress, "last_entries", 0) >= PROGRESS_INTERVAL_ENT:
            print("[scan] %s 进度：已扫 %d 个目录项，%.2f GB，耗时 %.1fs"
                  % (root_name or path, entries_seen, total / (1024 ** 3), now - started),
                  file=sys.stderr, flush=True)
            last_progress = now
            _emit_progress.last_entries = entries_seen
    _emit_progress.last_entries = 0

    stack = [path]
    try:
        while stack:
            cur = stack.pop()
            if entries_seen >= MAX_ENTRIES or (time.time() - started) > MAX_SECONDS:
                truncated = True
                break
            try:
                it = os.scandir(cur)
            except (OSError, ValueError):
                denied = True
                continue
            with it:
                for e in it:
                    if entries_seen >= MAX_ENTRIES or (time.time() - started) > MAX_SECONDS:
                        truncated = True
                        break
                    entries_seen += 1
                    _emit_progress()
                    try:
                        st = e.stat(follow_symlinks=False)  # Windows: 枚举缓存，零额外系统调用
                        # reparse point 权威识别：junction / mount point / symlink 通杀。
                        # 注意：不能依赖 e.is_dir(follow_symlinks=False) / e.is_symlink() ——
                        # 实测 Windows + Python 3.13 上 junction 的 is_dir(follow=False) 仍返回
                        # True、is_symlink() 返回 False（历史 OOM 事故根源），必须看 st_file_attributes。
                        # 命中 reparse → 不下钻、不计体积。既然 reparse 已可靠拦截 junction，
                        # 真实目录不存在「两条非 junction 路径到达同一目录」的可能（Windows 无目录
                        # 硬链接），故无需再做目录 inode 去重（e.inode() 在本机是真实系统调用，
                        # 12 万次耗时 66s，v1.7.30 移除；无限环由 MAX_ENTRIES/MAX_SECONDS 护栏兜底）。
                        if getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT:
                            continue  # junction / symlink / mount point 全跳（不下钻、不计体积）
                        if e.is_dir():  # 真实目录：下钻
                            stack.append(e.path)
                        else:
                            total += st.st_size
                    except (OSError, ValueError):
                        denied = True
                        continue
    except (OSError, ValueError):
        denied = True

    if truncated:
        _record_truncated(root_name or path, entries_seen, time.time() - started)
    else:
        _emit_progress(force=True)  # 完成时打一次总进度
    return total, denied


def _under_any(path, roots):
    """path 是否等于 roots 中某项，或位于其下（用于扫描排除，避免重复走同一棵大树）。"""
    if not roots:
        return False
    p = os.path.normcase(os.path.abspath(path))
    for r in roots:
        rn = os.path.normcase(os.path.abspath(r))
        if p == rn or p.startswith(rn + os.sep):
            return True
    return False


def scandir_children(path, min_kb=51200, limit=40, flag_denied=False, exclude=None, root_name=None):
    """Size every immediate child of `path` via os.scandir. Windows.

    flag_denied=True（仅系统缓存根用）：若任一子项内部撞到权限拒绝，即便体积低于
    门槛被丢弃，也追加一条 {denied:True} 标记，保证 analyze 的 system_cache_denied
    能感知到"有东西没读全" → 横幅可靠触发。
    exclude：可迭代的路径集合，命中的子项（及其子树）直接跳过——既避免重复计入
    （如 Local\\Temp 已由 temp 组整目录聚合），又省掉一次完整递归的体积计算（提速）。
    """
    if not path or not os.path.isdir(path):
        return []
    results = []
    try:
        with os.scandir(path) as it:
            entries = sorted(it, key=lambda e: e.name)
    except PermissionError:
        return [{"name": "(permission denied)", "path": path,
                 "size_kb": 0, "size_h": "?", "denied": True}]
    any_inner_denied = False
    computed = 0          # 性能护栏——单根目录最多全额计算这么多个子项体积
    COMPUTE_CAP = 300     # 输出 limit=40 远小于此，几乎不影响 top-N 准确性，但锁死最坏耗时
    for entry in entries:
        child = entry.path
        name = entry.name
        if exclude and _under_any(child, exclude):
            continue
        # v1.7.30：一次缓存 stat 同时完成 reparse 判定（junction/symlink 通杀）。
        # 旧实现 entry.is_symlink() + GetFileAttributesW(_is_reparse_point) 两次独立
        # 系统调用/子项（本机 3.6 万次耗时 ~14s）；DirEntry.stat 在 Windows 上随枚举
        # 缓存、零额外 syscall，st_file_attributes 含 REPARSE_POINT 位即应跳过。
        try:
            _st = entry.stat(follow_symlinks=False)
        except (PermissionError, OSError):
            any_inner_denied = True
            continue
        # 跳过 Windows junction 重解析点（Application Data / Local Settings /
        # My Documents 等指向真实目录的虚拟重定向）。它们本身不占空间，
        # 不跳过会和真实目录重复计算（如 AppData 43GB 之外又冒出
        # Application Data 21GB 的假大项），且删除它毫无意义甚至报错。
        if getattr(_st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT:
            continue
        try:
            if entry.is_file(follow_symlinks=False):
                kb = _st.st_size // 1024
            else:
                if computed >= COMPUTE_CAP:
                    # 超量子目录跳过全额递归，避免数千次全量递归卡死（P1-4）
                    continue
                b, inner_denied = dir_size_bytes(child, root_name=root_name or name)
                kb = b // 1024
                computed += 1
                if inner_denied:
                    any_inner_denied = True
        except (PermissionError, OSError):
            any_inner_denied = True
            continue
        if kb < min_kb:
            continue
        results.append({"name": name, "path": child, "size_kb": kb, "size_h": human(kb)})
    results.sort(key=lambda r: r["size_kb"], reverse=True)
    results = results[:limit]
    if flag_denied and any_inner_denied:
        results.append({"name": "(部分内容需管理员权限，未计入)", "path": path,
                        "size_kb": 0, "size_h": "?", "denied": True})
    return results


# ---- 快速剪枝：Program Files 跳过系统子目录（Microsoft/Common Files/…）----
# 这些系统目录用户不可动，但深度 walk 极耗时（C#/.NET 下数万文件）。
# 改为只聚合根目录文件大小（不递归），保留用户自有软件的正常扫描。
_PF_SKIP_NAMES = {"microsoft", "common files", "reference assemblies",
                  "dotnet", "assembly", "windows", "windowsapps",
                  "windows defender", "windows nt"}
_PF_SKIP_STARTS = ("microsoft ", )

def _scandir_pf_fast(path, min_kb, root_name):
    """快速版 scandir_children：对 Program Files 子目录智能跳过系统组件。"""
    if not os.path.isdir(path):
        return []
    results = []
    try:
        with os.scandir(path) as it:
            for entry in sorted(it, key=lambda e: e.name):
                child = entry.path
                name_l = entry.name.lower()
                # 系统目录：只算根层文件体积（不递归），节省 90% 时间
                is_sys = (name_l in _PF_SKIP_NAMES or
                          any(name_l.startswith(s) for s in _PF_SKIP_STARTS))
                if entry.is_dir() and not entry.is_symlink():
                    if _is_reparse_point(child):
                        continue
                    if is_sys:
                        # 聚合根级文件大小（快速，>0.1s 级别）
                        kb = _size_root_files_only(child)
                    else:
                        try:
                            b, _denied = dir_size_bytes(child, root_name=root_name or name_l)
                            kb = b // 1024
                        except (PermissionError, OSError):
                            continue
                elif entry.is_file(follow_symlinks=False):
                    try:
                        kb = entry.stat(follow_symlinks=False).st_size // 1024
                    except (PermissionError, OSError):
                        continue
                else:
                    continue
                if kb < min_kb:
                    continue
                results.append({"name": entry.name, "path": child,
                               "size_kb": kb, "size_h": human(kb)})
    except PermissionError:
        return [{"name": "(permission denied)", "path": path,
                 "size_kb": 0, "size_h": "?", "denied": True}]
    results.sort(key=lambda r: r["size_kb"], reverse=True)
    return results[:40]


def _size_root_files_only(path):
    """只聚合根级文件大小（不递归子目录），用于快速估价系统目录。"""
    tot = 0
    try:
        with os.scandir(path) as it:
            for entry in it:
                if entry.is_file(follow_symlinks=False):
                    try:
                        tot += entry.stat(follow_symlinks=False).st_size
                    except OSError:
                        pass
    except Exception:
        pass
    return tot // 1024


def list_drives_windows():
    drives = []
    import string
    for letter in string.ascii_uppercase:
        root = f"{letter}:\\"
        if os.path.exists(root):
            try:
                t, u, f = shutil.disk_usage(root)
                drives.append({"name": root, "total": human(t // 1024),
                               "used": human(u // 1024), "free": human(f // 1024)})
            except Exception:
                continue
    return drives


def system_info_windows():
    import platform
    info = {}
    info["os"] = platform.system() + " " + platform.release()
    info["build"] = platform.version()
    info["arch"] = os.environ.get("PROCESSOR_ARCHITECTURE", platform.machine())
    info["user"] = os.environ.get("USERNAME", "")
    info["home"] = os.environ.get("USERPROFILE", HOME)
    sysdrive = os.environ.get("SystemDrive", "C:") + "\\"
    total, used, free = "?", "?", "?"
    try:
        t, u, f = shutil.disk_usage(sysdrive)
        total, used, free = human(t // 1024), human(u // 1024), human(f // 1024)
    except Exception:
        pass
    info["disk_total"], info["disk_used"], info["disk_free"] = total, used, free
    info["filesystem"] = "NTFS"
    info["purgeable"] = ""
    info["disk_name"] = sysdrive
    info["disks"] = list_drives_windows()
    return info


def scan_windows():
    profile = os.environ.get("USERPROFILE", HOME)
    local = os.environ.get("LOCALAPPDATA", os.path.join(profile, "AppData", "Local"))
    roaming = os.environ.get("APPDATA", os.path.join(profile, "AppData", "Roaming"))
    # 全局超时：从入口开始计时，超时即截断所有任务（配合单根 30s 护栏，双保险）
    _SCAN_DEADLINE = time.time() + 150
    # 个人文件夹已扫标记：user_profile 已经走了 Documents/Pictures/... 
    # 后面独立锚点不再重复 walk（省 30~50% 扫描时间）
    _profile_children_seen = set()  # normcase 后的子目录路径
    _profile_scanned = threading.Lock()
    targets = [
        ("user_profile", profile, 102400),
        ("appdata_local", local, 51200),
        ("appdata_roaming", roaming, 51200),
        ("temp", os.environ.get("TEMP", os.path.join(local, "Temp")), 51200),
        ("downloads", os.path.join(profile, "Downloads"), 51200),
        # ====== Phase1: 个人文件夹独立锚点（用户最大的可回收空间常在这里）======
        # user_profile 已把 Documents/Pictures/... 当作子项扫出，但这里用更低阈值(50MB)
        # 独立锚定，确保 50~100MB 区间的个人文件夹也能冒泡成黄区项；去重逻辑会合并重复路径。
        ("documents", os.path.join(profile, "Documents"), 51200),
        ("pictures", os.path.join(profile, "Pictures"), 51200),
        ("videos", os.path.join(profile, "Videos"), 51200),
        ("music", os.path.join(profile, "Music"), 51200),
        ("desktop", os.path.join(profile, "Desktop"), 51200),
        ("program_files", os.environ.get("ProgramFiles", r"C:\Program Files"), 102400),
        ("program_files_x86", os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), 102400),
        # 系统级安全缓存（体积往往巨大、且删了系统自动重建，之前完全没扫 → 漏掉的大头）
        ("win_temp", r"C:\Windows\Temp", 10240),
        ("prefetch", r"C:\Windows\Prefetch", 10240),
        ("sd_download", r"C:\Windows\SoftwareDistribution\Download", 10240),
        ("delivery_opt", r"C:\Windows\SoftwareDistribution\DeliveryOptimization", 10240),
        ("delivery_opt2", r"C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization", 10240),
        ("wer", r"C:\ProgramData\Microsoft\Windows\WER", 10240),
        # 本地版 WER（每个用户的崩溃报告）：Local\Microsoft\Windows\WER。
        # 与 ProgramData 版同属系统崩溃转储，删了安全、Windows 自动重建。
        # 段名 \microsoft\windows\wer 已在 SYSTEM_CACHE_MARKS → 自动进绿区。
        ("wer_local", os.path.join(local, "Microsoft", "Windows", "WER"), 10240),
        # ====== 三类必杀器·系统级缓存 ======
        # 缩略图缓存：thumbcache_*.db，删了下次打开文件夹自动重建
        ("thumbcache", os.path.join(local, "Microsoft", "Windows", "Explorer"), 10240),
        # Windows Search 索引：能删了重建，速度极慢，体积常达数 GB
        ("search_index", r"C:\ProgramData\Microsoft\Search\Data", 10240),
        # Windows 事件日志：winevt\Logs 下的 .evtx，体积可能数百 MB~数 GB
        ("event_logs", r"C:\Windows\System32\winevt\Logs", 10240),
        # IIS 日志：inetpub\logs\LogFiles，普通用户通常没有
        ("iis_logs", r"C:\inetpub\logs\LogFiles", 10240),
        # .NET 本地映像缓存：删了下次运行 .NET 程序自动重建
        ("dotnet_native_img", r"C:\Windows\assembly\NativeImages_v4.0.30319_64", 10240),
        # ====== 三类必杀器·浏览器 Cache 主目录 ======
        # 这些之前是被子目录匹配上 (Cache/GPUCache 等)，但 Default\Cache 主目录常常
        # 被拆成数千个小文件，scandir_children 阈值过滤后漏掉。这里直接聚合。
        ("chrome_cache", os.path.join(local, "Google", "Chrome", "User Data", "Default", "Cache"), 51200),
        ("edge_cache", os.path.join(local, "Microsoft", "Edge", "User Data", "Default", "Cache"), 51200),
        ("firefox_cache", os.path.join(local, "Mozilla", "Firefox", "Profiles"), 51200),
        # 360 浏览器主缓存
        ("360se_cache", os.path.join(roaming, "360Safe", "sesvr", "Cache"), 51200),
        # ====== Phase2: 覆盖率补全·用户级/系统级纯缓存锚点 ======
        # IE / Edge 旧版 INetCache：系统临时网络缓存，等同浏览器缓存，删了安全
        ("inetcache", os.path.join(local, "Microsoft", "Windows", "INetCache"), 10240),
        # OneDrive 日志与自动更新缓存（不动同步的用户文件）
        ("onedrive_logs", os.path.join(local, "Microsoft", "OneDrive", "logs"), 10240),
        ("onedrive_updater", os.path.join(local, "Microsoft", "OneDrive", "StandaloneUpdater"), 10240),
        # UWP/Store 应用缓存根：Packages 下各应用的 LocalCache 等临时目录
        ("uwp_cache", os.path.join(local, "Packages"), 10240),
        # ====== 系统确定性锚点（仅保留绿区安全缓存）======
        # 注：原 WinSxS / Windows Installer / VSS 卷影 / Windows.old 四条「需判断(黄区)」
        # 锚点已于 v1.7.32 移除——黄区不再展示；且经 analyze.is_green_cache 四道关判定，
        # 这四条路径 100% 只会进黄区、绝不进绿区/迁移，移除后绿区量与迁移量与原全量
        # 完全一致（守住院「绿区量/迁移量必须不变」红线）。扫描也由此不再遍历这些系统大目录。
        # 仅保留 $PatchCache$（Windows Installer 补丁缓存）：删了可由 Windows 重下、不影响系统，
        # 属安全缓存，单独锚定进绿区（已在 path_rules.SAFE_CACHE_SEGMENTS 登记 "$patchcache$"）。
        ("installer_patchcache", r"C:\Windows\Installer\$PatchCache$", 10240),
        # ====== v1.7.35（增强3·补低风险系统缓存）：崩溃转储 / 字体缓存 / 系统日志 ======
        # 全是可再生、删了系统自动重建的安全缓存，不碰系统功能/应用/个人文件。
        # CBS 日志：Windows 组件服务安装/修复日志（磁盘紧张时可达数 GB）
        ("cbs_logs", r"C:\Windows\Logs\CBS", 10240),
        # LiveKernelReports：内核实时崩溃转储（蓝屏/驱动崩溃残留）
        ("livekernel_reports", r"C:\Windows\LiveKernelReports", 10240),
        # Minidump：蓝屏小内存转储文件（*.dmp）
        ("minidump", r"C:\Windows\Minidump", 10240),
        # FontCache：字体缓存（系统自动重建；Win10/11 路径在 ServiceProfiles 下）
        ("fontcache", r"C:\Windows\ServiceProfiles\LocalService\AppData\Local\FontCache", 10240),
        # MemoryDump：内存转储残留（非 pagefile）
        ("memory_dump", r"C:\Windows\MEMORY.DMP", 10240),
    ]
    # v1.7.23 分批扫描（生产提速）：AIPC_FAST=1 时只扫「秒级大户锚点」——
    # temp / 回收站 / 浏览器缓存 / 系统级安全缓存等（占绿区体积 90%+，秒级出真实数字），
    # 用于 run.py 首屏秒出「可释放量」；完整扫描（个人目录/程序目录/系统组件）由 run.py
    # 在后台补全后 reload 报告，数字只增不减（快扫真实 → 全量更全）。
    # 慢锚点（user_profile/appdata_*/program_files/winsxs 等全盘遍历）被排除，首屏 ~15s。
    _FAST_KEYS = {"prefetch", "sd_download", "delivery_opt", "delivery_opt2",
                  "wer", "wer_local", "thumbcache", "search_index", "event_logs",
                  "iis_logs", "dotnet_native_img", "chrome_cache", "edge_cache",
                  "firefox_cache", "360se_cache", "inetcache", "onedrive_logs",
                  "onedrive_updater", "installer_patchcache",
                  # v1.7.35（增强3）：低风险系统缓存也纳入首屏快扫（崩溃转储/日志/字体缓存）
                  "cbs_logs", "livekernel_reports", "minidump", "fontcache", "memory_dump"}
    if os.environ.get("AIPC_FAST") == "1":
        targets = [t for t in targets if t[0] in _FAST_KEYS]
    # 系统级安全缓存根：开启 flag_denied，内层被拒也要打标记（供横幅感知）
    SYS_CACHE_KEYS = {"win_temp", "prefetch", "sd_download",
                      "delivery_opt", "delivery_opt2", "wer",
                      "thumbcache", "search_index", "event_logs", "iis_logs",
                      "dotnet_native_img",
                      # v1.7.35（增强3）：低风险系统缓存（崩溃转储/日志/字体缓存）
                      # v1.7.36（审查修复）：补齐 memory_dump，三集合（_FAST_KEYS /
                      # SYS_CACHE_KEYS / SYSTEM_CACHE_MARKS）对齐一致
                      "cbs_logs", "livekernel_reports", "minidump", "fontcache",
                      "memory_dump"}
    # Local\Temp 体积巨大且已由下方 temp 组整目录聚合，从 appdata_local 排除：
    # 既避免重复计入（双计），又省掉一次 5GB+ 的完整递归（提速，保扫描≤3分钟）。
    _exclude_from_local = {os.path.join(local, "Temp")}
    import concurrent.futures as _cf
    # ---- 核心优化: 全局超时 + 去重 ----
    t_start_global = time.time()
    def _scan_task(task):
        key, path, floor, mode = task
        # 全局超时：超过硬上限后直接放弃新任务（已跑完的结果保留）
        if time.time() > _SCAN_DEADLINE:
            return key, []
        # 去重：文档/图片/视频/音乐/桌面若 user_profile 已覆盖过，跳过重复扫描
        _pf_keys = {"documents", "pictures", "videos", "music", "desktop"}
        if key in _pf_keys:
            _np = os.path.normcase(os.path.abspath(path))
            with _profile_scanned:
                if _np in _profile_children_seen:
                    return key, []
        # Program Files 剪枝：跳过冗余系统目录（节省 40~60s）
        _ism = mode == "pf_skip_system"
        try:
            if mode == "agg":
                rec = _size_one_path(key, path)
                if key == "recycle_bin" and rec.get("size_kb", 0) > 0:
                    rec["path"] = "__EMPTY_RECYCLE_BIN__"
                    rec["name"] = "回收站（已删除未清）"
                return key, [rec]
            _excl = _exclude_from_local if key == "appdata_local" else None
            if _ism:
                return key, _scandir_pf_fast(path, floor, key)
            # v1.7.36（审查修复）：单文件锚点（如 C:\Windows\MEMORY.DMP 内存转储残留）
            # 是文件而非目录，scandir_children 的 os.path.isdir 门槛会让它恒返回空 → 该
            # 锚点永不产出数据（v1.7.35 新增的 memory_dump 形同虚设）。此处用
            # os.path.getsize 单独计量单文件，并按 min_kb 门槛过滤，补齐这条盲区。
            if os.path.isfile(path):
                try:
                    _fsize = os.path.getsize(path)
                except OSError:
                    _fsize = 0
                if _fsize // 1024 >= floor:
                    return key, [{"name": os.path.basename(path), "path": path,
                                  "size_kb": _fsize // 1024, "size_h": human(_fsize // 1024)}]
                return key, []
            return key, scandir_children(path, min_kb=floor, root_name=key,
                                         flag_denied=(key in SYS_CACHE_KEYS), exclude=_excl)
        except Exception:
            return key, []
    # 用户个人目录子项跟踪：user_profile 扫描后，把已覆盖的子目录登记
    _tasks_raw = [(t[0], t[1], t[2], "children") for t in targets]
    # 把 program_files 两个根改成快速剪枝模式 (pf_skip_system)
    for _i, _t in enumerate(_tasks_raw):
        if _t[0] in ("program_files", "program_files_x86"):
            _tasks_raw[_i] = (_t[0], _t[1], _t[2], "pf_skip_system")
    _tasks = _tasks_raw
    # temp / win_temp：聚合整目录（与浏览器缓存同款逻辑）。内部海量小文件，scandir_children
    # 只列≥min_kb 子项会漏掉绝大部分体积；整目录聚合补全盲区（Local\Temp 实占 5GB+）。
    # 判定 is_green_cache 为真 → 必进绿区、不掉黄区（不打地鼠）。appdata_local 已排除 Local\Temp，无双计。
    _tasks.append(("temp", os.environ.get("TEMP", os.path.join(local, "Temp")), 0, "agg"))
    _tasks.append(("win_temp", r"C:\Windows\Temp", 0, "agg"))
    # 回收站：用户已删文件仍占位 C 盘。下方 505 行独立扫描（_scan_recycle_bin 跨 SID 聚合 + file_count），
    # 输出特殊标记 __EMPTY_RECYCLE_BIN__，由服务端调用 Windows API 清空回收站，不走普通文件删除。
    # 已剥离出绿区，独立成「深度清理」项（需二次确认），见 analyze.py / report_template.html。
    groups = {}
    # 自适应线程数：多核机器吃满 CPU 加速枚举；下限 8 保底（低核机不退化），
    # 上限 32 防止线程过多反而因 GIL/磁盘争用变慢。SSD 上枚举主要受 CPU/目录元数据
    # 读取限制，更多 worker 显著缩短总耗时。纯标准库，无外部依赖。
    _scan_workers = min(32, max(8, (os.cpu_count() or 4) * 2))

    # ---- 个人文件夹去重：先单独跑 user_profile 并登记其子目录，再并发其余锚点 ----
    # 关键修复（v1.7.8）：原实现把 _profile_children_seen 的填充放在线程池 map 之后，
    # 导致并发期间该集合恒为空，documents/pictures/videos/music/desktop 五个独立锚点
    # 每次都重复全量扫描 user_profile 已覆盖的子树（注释声称省 30~50%，实际完全没生效）。
    # 改为：先同步跑 user_profile → 填充去重集合 → 再提交其余任务，去重才真正生效。
    _tasks_rest = [t for t in _tasks if t[0] != "user_profile"]
    # v1.7.23 分批扫描：fast 模式跳过 user_profile 全盘预扫描（个人目录是慢头，首屏不需要），
    # 去重集合为空即可（fast 锚点不含个人文件夹锚点，无重复扫描问题）。
    if os.environ.get("AIPC_FAST") == "1":
        groups["user_profile"] = []
    else:
        try:
            _up_key, _up_res = _scan_task(("user_profile", profile, 102400, "children"))
            groups[_up_key] = _up_res
        except Exception:
            groups["user_profile"] = []
    with _profile_scanned:
        for it in (groups.get("user_profile") or []):
            p = it.get("path")
            if p:
                _profile_children_seen.add(os.path.normcase(os.path.abspath(p)))

    with _cf.ThreadPoolExecutor(max_workers=_scan_workers) as _ex:
        for key, res in _ex.map(_scan_task, _tasks_rest):
            groups[key] = res

    # 全局超时后丢弃的 key 用 [] 补齐，防止后续建索引时 KeyError
    for _k in set(t[0] for t in _tasks):
        if _k not in groups:
            groups[_k] = []
    groups["_scan_seconds"] = [{"name": "scan_total_sec", "size_kb": max(0, time.time() - t_start_global), "path":"", "size_h":""}]

    dev_paths = [
        os.path.join(profile, ".cache"), os.path.join(profile, ".npm"),
        os.path.join(profile, ".gradle"), os.path.join(profile, ".m2"),
        os.path.join(profile, ".nuget", "packages"), os.path.join(profile, ".cargo"),
        os.path.join(local, "pip", "Cache"), os.path.join(local, "Yarn"),
        os.path.join(local, "uv"), os.path.join(local, "ms-playwright"),
        os.path.join(local, "go-build"),
    ]
    dev = []
    for p in dev_paths:
        if time.time() > _SCAN_DEADLINE:  # 超时护栏：不拖累总扫描时长
            break
        if not os.path.isdir(p):
            continue
        try:
            b, _ = dir_size_bytes(p, root_name="dev_caches:" + os.path.basename(p.rstrip("\\/")))
        except (PermissionError, OSError):
            continue
        kb = b // 1024
        if kb < 51200:
            continue
        dev.append({"name": os.path.basename(p.rstrip("\\/")) or p,
                    "path": p, "size_kb": kb, "size_h": human(kb)})
    dev.sort(key=lambda r: r["size_kb"], reverse=True)
    groups["dev_caches"] = dev

    # ====== 三类必杀器·浏览器 Cache 主目录（聚合整目录体积） ======
    # 这些路径本身就是 Cache 目录（如 Chrome Cache），不是父目录。
    # scandir_children 会列出 Cache 内的子文件，单个文件通常 < 50MB，
    # 全被 min_kb 过滤掉了。所以走专用函数：直接聚合总大小输出单条记录。
    # 浏览器深埋缓存：Cache 主目录之外的 GPUCache / Code Cache / ShaderCache /
    # GraphiteDawnCache 等子目录，体积常达数百 MB~数 GB，删了浏览器自动重建。
    # 这些子目录段名（gpucache/codecache/shadercache/graphitedawncache）已全登记进
    # SAFE_CACHE_SEGMENTS → 自动进绿区。按 profile × 子目录程序化展开，避免漏项。
    _browser_profiles = [
        ("chrome", os.path.join(local, "Google", "Chrome", "User Data", "Default")),
        ("edge", os.path.join(local, "Microsoft", "Edge", "User Data", "Default")),
        ("360se", os.path.join(roaming, "360Safe", "sesvr")),
        # 旧版 360 浏览器（360se6）：缓存树在 secoresdk\360se6\User Data\Default 下，
        # 与 360Safe\sesvr 是两套独立安装，需单独枚举才能覆盖（否则漏绿 ~96MB）。
        ("360se6", os.path.join(roaming, "secoresdk", "360se6", "User Data", "Default")),
    ]
    _browser_cache_subdirs = ["Cache", "GPUCache", "Code Cache", "ShaderCache", "GraphiteDawnCache"]
    browser_cache_paths = []
    for _bname, _bprof in _browser_profiles:
        for _sub in _browser_cache_subdirs:
            _cpath = os.path.join(_bprof, _sub)
            if os.path.isdir(_cpath):
                browser_cache_paths.append((f"{_bname}_{_sub.replace(' ', '').lower()}_cache", _cpath))
    # Firefox: Profiles 下面是 *default-release 等子目录，每个里有 cache2
    bc_results = []
    for key, path in browser_cache_paths:
        if time.time() > _SCAN_DEADLINE:  # 超时护栏
            break
        item = _size_one_path(key, path)
        if item["size_kb"] > 0:
            bc_results.append(item)
    # Firefox：找 Profiles 下的 cache2 子目录
    ff_profiles = os.path.join(local, "Mozilla", "Firefox", "Profiles")
    if os.path.isdir(ff_profiles):
        try:
            for prof in os.listdir(ff_profiles):
                prof_path = os.path.join(ff_profiles, prof)
                if not os.path.isdir(prof_path):
                    continue
                # firefox 缓存可能在 cache2（新版）或 Cache（旧版）
                for cache_name in ("cache2", "Cache"):
                    cache_path = os.path.join(prof_path, cache_name)
                    if os.path.isdir(cache_path):
                        item = _size_one_path("firefox_cache", cache_path)
                        if item["size_kb"] > 0:
                            bc_results.append(item)
                        break
        except (PermissionError, OSError):
            pass
    groups["browser_caches"] = bc_results

    # 回收站（用户已经删过一次的文件，仍占 C 盘空间）
    # 路径下是 S-1-5-XX 的 SID 文件夹，每个里面是 $I*（元信息）和 $R*（实际文件）
    # 跨 SID 聚合，输出单条记录供黄区展示
    groups["recycle_bin"] = [_scan_recycle_bin()]

    # ====== Phase3: 全盘顶层兜底（保证零隐形）======
    # 注：原 system_reserved（hiberfil/pagefile「关休眠/调虚拟内存可释放」）于 v1.7.32 移除——
    # 它属需判断(黄区)，且经 is_green_cache 判定绝不进绿区/迁移，移除不破红线。
    _covered_roots = [
        profile, local, roaming, os.path.join(profile, "Downloads"),
        os.environ.get("ProgramFiles", r"C:\Program Files"),
        os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
        r"C:\Windows", r"C:\ProgramData", r"C:\$Recycle.Bin",
        r"C:\System Volume Information",
    ]
    # v1.7.23 分批扫描：fast 模式跳过「全盘顶层兜底」与「迁移候选深度遍历」（两大慢头），
    # 首屏只出绿区真实数字；uncategorized_large / large_user_files 由全量扫描补全后 reload。
    if os.environ.get("AIPC_FAST") == "1":
        groups["uncategorized_large"] = []
        groups["large_user_files"] = []
    else:
        groups["uncategorized_large"] = sweep_top_level_uncovered(_covered_roots, deadline=_SCAN_DEADLINE)

        # ====== 大用户文件（物理搬去 D 盘迁移候选）======
        # 递归找用户个人目录下的影音/镜像/压缩包/文档等（不涉程序），搬去 D 盘即真释放 C 盘
        # （不删、不建 junction、零丢失）。
        # v1.7.35（增强2·提高迁移量）：阈值从 50MB 降到 20MB，覆盖更多中小体积大文件
        # （10-50MB 的文档/素材/工程文件是个人文件夹常见大头，50MB 以下会漏掉）。
        # 搬运项变多，但 limit=200 + deadline 护栏保证不拖累扫描。
        MOVE_MIN_KB = 20480  # 20MB，覆盖更多用户媒体/工程；50MB 会漏掉中小大文件
        _move_roots = [
            os.path.join(profile, "Downloads"),
            os.path.join(profile, "Videos"),
            os.path.join(profile, "Pictures"),
            os.path.join(profile, "Desktop"),
            os.path.join(profile, "Documents"),
            os.path.join(profile, "Music"),
        ]
        groups["large_user_files"] = find_large_user_files(_move_roots, min_kb=MOVE_MIN_KB, limit=200, max_depth=5,
                                                            deadline=_SCAN_DEADLINE)

    return system_info_windows(), groups


def _scan_recycle_bin():
    """扫描 C:\\$Recycle.Bin，跨所有用户 SID 迭代聚合大小。返回单条记录。

    用户已经删除过这些文件，但仍占着 C 盘空间。放黄区让用户二次确认是否清空。
    回收站里既有被删文件（$R*），也有元信息（$I*），文件夹里的内容也要递归统计。
    使用显式栈迭代，避免异常深层目录触发 Python 递归深度上限。
    """
    rb_root = r"C:\$Recycle.Bin"
    result = {"name": "回收站（已删未清）", "path": "__EMPTY_RECYCLE_BIN__",
              "size_kb": 0, "size_h": "?", "file_count": 0, "denied": False}
    if not os.path.isdir(rb_root):
        return result

    total_bytes = 0
    file_count = 0
    any_denied = False
    stack = []
    try:
        for sid in os.listdir(rb_root):
            sid_path = os.path.join(rb_root, sid)
            if os.path.isdir(sid_path):
                stack.append(sid_path)
    except (PermissionError, OSError):
        any_denied = True

    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for entry in it:
                    try:
                        if entry.is_symlink():
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            stack.append(entry.path)
                        elif entry.is_file(follow_symlinks=False):
                            total_bytes += entry.stat(follow_symlinks=False).st_size
                            file_count += 1
                    except (PermissionError, OSError):
                        any_denied = True
                        continue
        except (PermissionError, OSError):
            any_denied = True
            continue

    result["size_kb"] = total_bytes // 1024
    result["size_h"] = human(total_bytes // 1024) if total_bytes else "?"
    result["file_count"] = file_count
    result["denied"] = any_denied
    return result


def _norm_local(p):
    return os.path.normpath(p).lower().rstrip("\\")


def _scan_system_reserved():
    """Phase1: 报告 hiberfil.sys / pagefile.sys / swapfile.sys 体积。

    这些是系统保留文件，本身不可删，但『关休眠 / 调虚拟内存』能释放等量空间。
    放黄区让用户知道『这样做能腾出多少』——属于覆盖率必须可见的项。
    """
    items = []
    for fn in ("hiberfil.sys", "pagefile.sys", "swapfile.sys"):
        fp = os.path.join("C:\\", fn)
        if os.path.exists(fp):
            try:
                kb = os.path.getsize(fp) // 1024
            except OSError:
                kb = 0
            if kb > 0:
                items.append({"name": fn + "（系统保留·关休眠/调虚拟内存可释放）",
                              "path": fp, "size_kb": kb, "size_h": human(kb)})
    return items


def sweep_top_level_uncovered(covered_roots, floor=51200, deadline=None):
    """Phase3: 全盘顶层兜底扫描（保证零隐形）。

    枚举 C: 下所有顶层目录，凡不在已覆盖根内的，整体计量并输出，
    归入「未归类·待确认(黄区)」。这样任何装到 C 盘根的行业软件 / 驱动 /
    残留目录都可见，绝不隐形——这是「98% 覆盖率」的兜底保障。

    covered_roots: scan_windows 已覆盖的顶层根（用户态 / Program Files / Windows / ProgramData 等），
                   落在其内的顶层目录跳过（已由其它 target 处理）。
    """
    results = []
    skip = set(_norm_local(p) for p in covered_roots)
    try:
        for name in sorted(os.listdir("C:\\")):
            if deadline is not None and time.time() > deadline:  # 超时护栏：全盘顶层兜底不拖累总时长
                break
            d = os.path.join("C:\\", name)
            if not os.path.isdir(d):
                continue
            nd = _norm_local(d)
            # 跳过已被其它 target 覆盖的顶层根（含其自身 / 其子 / 其父）
            if any(nd == s or nd.startswith(s + "\\") or s.startswith(nd + "\\") for s in skip):
                continue
            if _is_reparse_point(d):
                continue
            try:
                b, _ = dir_size_bytes(d, root_name="uncategorized:" + name)
            except (PermissionError, OSError):
                continue
            kb = b // 1024
            if kb < floor:
                continue
            results.append({"name": name + "（未归类·待确认）", "path": d,
                            "size_kb": kb, "size_h": human(kb)})
    except (PermissionError, OSError):
        pass
    results.sort(key=lambda r: r["size_kb"], reverse=True)
    return results


def _size_one_path(key, path):
    """把单个路径作为整体扫描，返回单条记录（name/path/size_kb/size_h/denied）。

    用于浏览器 Cache 主目录这类「路径本身就是缓存根」的情况。
    dir_size_bytes 内部已有防环、防 junction、超深保护。
    """
    result = {"name": key, "path": path,
              "size_kb": 0, "size_h": "?", "denied": False}
    if not path or not os.path.isdir(path):
        return result
    try:
        total_bytes, inner_denied = dir_size_bytes(path, root_name=key)
        result["size_kb"] = total_bytes // 1024
        result["size_h"] = human(total_bytes // 1024) if total_bytes else "?"
        result["denied"] = inner_denied
    except (PermissionError, OSError):
        result["denied"] = True
    return result


def find_large_user_files(roots, min_kb=512000, limit=60, max_depth=4, deadline=None):
    """递归找用户目录里的大文件（>=min_kb，默认 500MB），作为「物理搬去 D 盘」迁移候选。

    只找【文件】、不找目录；跳过安装包(.exe/.msi 等→走黄区删除)、临时/半成品下载。
    限深(max_depth) + 限数(limit) 双护栏，避免全盘递归卡死。
    返回 [{name, path, size_kb, size_h}]（降序）。这些文件不涉程序、搬走即真释放 C 盘。

    v1.7.30 性能：旧实现每个条目先 is_symlink + GetFileAttributesW(_is_reparse_point) 两次
    独立系统调用；改为一次 e.stat(follow_symlinks=False)（Windows 枚举缓存、零 syscall），
    用 st_file_attributes 的 REPARSE_POINT 位统一判 junction/symlink。另新增 deadline
    （全局 150s 硬上限），超时立即返回已收集结果，绝不拖累扫描总时长。
    """
    # 可搬：想留但不占 C 盘的大块头（影音/镜像/压缩包/大文档）
    # v1.7.35（增强2·扩大类型）：补充工程文件/备份/数据库/照片素材等常见大文件类型。
    # 均为用户个人数据（非程序），物理搬去 D 盘零丢失，仍是安全迁移。
    MOVABLE_EXTS = {
        "mp4", "mkv", "avi", "mov", "flv", "wmv", "webm", "m4v", "mpg", "mpeg", "ts",
        "iso", "wim", "vhd", "vhdx", "img", "nrg", "cue", "dmg",
        "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst",
        "pdf", "psd", "ai", "dwg", "blend", "mp3", "wav", "flac", "aac",
        # ---- v1.7.35 补充：工程 / 备份 / 数据库 / 素材 ----
        "prproj", "aep", "pproj", "c4d", "ma", "mb", "blend", "skp", "3dm", "stl",
        "docx", "doc", "xlsx", "xls", "pptx", "ppt", "pub", "odt", "ods", "odp",
        "bak", "backup", "dat", "db", "sqlite", "mdf", "ldf", "ndf",
        "nef", "cr2", "cr3", "arw", "dng", "raw", "tif", "tiff", "bmp", "png", "jpg", "jpeg", "gif",
        "avi", "mkv",  # 已有，去重无妨
    }
    # 不搬：安装包走黄区删除；临时/半成品下载不可靠
    SKIP_EXTS = {"exe", "msi", "msix", "cab", "tmp", "part", "crdownload", "download"}
    results = []
    seen = set()
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        stack = [(root, 0)]
        while stack:
            if deadline is not None and time.time() > deadline:
                break
            cur, depth = stack.pop()
            try:
                with os.scandir(cur) as it:
                    for e in it:
                        if deadline is not None and time.time() > deadline:
                            break
                        try:
                            st = e.stat(follow_symlinks=False)  # 枚举缓存，零额外系统调用
                            # junction / symlink / mount point：整棵跳过（含文件型 reparse）
                            if getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT:
                                continue
                            if e.is_dir():  # 真实目录：深度达标才下钻
                                if depth < max_depth:
                                    stack.append((e.path, depth + 1))
                                continue
                            ext = e.name.rsplit(".", 1)[-1].lower() if "." in e.name else ""
                            if ext in SKIP_EXTS or ext not in MOVABLE_EXTS:
                                continue
                            kb = st.st_size // 1024
                            if kb < min_kb:
                                continue
                            np_ = os.path.normcase(os.path.realpath(e.path))
                            if np_ in seen:
                                continue
                            seen.add(np_)
                            results.append({"name": e.name, "path": e.path,
                                            "size_kb": kb, "size_h": human(kb)})
                        except (PermissionError, OSError):
                            continue
            except (PermissionError, OSError):
                continue
    results.sort(key=lambda r: r["size_kb"], reverse=True)
    return results[:limit]


# ======================================================================
def main():
    started = time.time()
    # 行缓冲：哪怕扫到一半出问题，至少能看到走到哪了（不会"完全没输出"）
    try:
        sys.stdout.reconfigure(line_buffering=True)
        sys.stderr.reconfigure(line_buffering=True)
    except Exception:
        pass
    try:
        if sys.platform == "darwin":
            system, groups = scan_macos()
        elif sys.platform.startswith("win"):
            system, groups = scan_windows()
        else:
            print(json.dumps({"error": "unsupported_platform", "platform": sys.platform,
                              "message": "scan.py supports macOS and Windows only."},
                             ensure_ascii=False))
            return
    except Exception as e:
        # 兜底：任何未捕获异常都打 JSON 到 stdout（让上层 run.py 能识别失败），
        # 不再出现"退出码 1 + 0 字节输出"这种用户看了一头雾水的情况。
        print(json.dumps({
            "error": "scan_failed",
            "platform": sys.platform,
            "type": type(e).__name__,
            "message": str(e),
            "trace_tail": traceback.format_exc().splitlines()[-8:],
        }, ensure_ascii=False))
        return
    data = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "system": system,
        "groups": groups,
        "scan_seconds": round(time.time() - started, 1),
        "truncated_roots": sorted(_TRUNCATED_ROOTS),
    }
    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
