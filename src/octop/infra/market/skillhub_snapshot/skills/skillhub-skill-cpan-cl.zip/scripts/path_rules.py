# -*- coding: utf-8 -*-
"""
path_rules.py — C盘清理的「缓存识别知识库」。

设计目标（直接回应老板的两个痛点）：
1. 不再靠「app 名字字典」分类（360se6 因不在字典被误判 unknown）——改为靠
   「缓存子文件夹的结构名」（Cache / GPUCache / Code Cache / temp / log …）识别。
   这些结构名跨 app、跨电脑、跨版本都一致，所以「形形色色的电脑」也能稳。
2. 知识来源：BleachBit 的 CleanerML（104 个清理定义里的缓存路径）+
   中国国民软件（360 / 腾讯 / 金山WPS / 迅雷 / 百度 / 搜狗）实测路径。

安全哲学（沿用 Pinkbin：宁可错放，不误删）：
- 只认「明确的缓存/临时」结构名 → 标 safe（可安全清，删了自动重建）。
- 含个人数据的结构名 → 标 keep（永不自动动）。
- 拿不准的 app 根目录 → 标 review（需用户确认），但会进一步下钻找里面的缓存。
"""

import os

# ---------------------------------------------------------------------------
# 1) 明确的「安全缓存」目录结构名（小写，作为路径的某一层 segment 匹配）
#    来源：BleachBit cleaners/*.xml 里所有 command="delete" 的缓存型子目录名
#    + 中国软件实测（360se6 / 腾讯系 / 金山WPS / 迅雷 的缓存子目录）。
# ---------------------------------------------------------------------------
SAFE_CACHE_SEGMENTS = {
    # ---- 通用浏览器/软件缓存（Chromium / Electron 系几乎通用）----
    "cache", "caches", "code cache", "codecache", "gpu cache", "gpucache",
    "shadercache", "graphitedawncache",
    "service worker", "serviceworker",
    "media cache", "mediacache",
    "crash reports", "crashreports", "crashpad", "crashpadreports", "crashes",
    "dawncache", "grshadercache", "mojo", "optimizationguide", "autofill",
    "shortcuts", "top sites", "topsites", "safebrowsing", "subresource filter",
    "site engagements", "siteengagements", "client side phishing",
    "hyphenation", "translation", "speech synthesis", "speechsynthesis",
    "variations", "module cache", "modulecache", "wasm",
    "shared dictionary", "shareddictionary", "webcache",
    # ---- 中国软件实测缓存名 ----
    "radium", "minibrowser", "ebwebview", "wpscloud", "kvipcache", "kdcache",
    "dubacache", "nsecache", "office6cache", "kzipcache", "avcache",
    "gifcache", "piccache", "videocache", "imagecache", "fontcache",
    "lightcache", "dnscache", "jietemp", "xl_data", "xar",
    "program\\webui", "webui", "update", "updates", "patch", "installcache",
    "$patchcache$",  # Windows Installer 补丁缓存（$PatchCache$），删了可重下，不影响系统
    "delivery optimization", "electron", "filecache", "browsercrashes",
    "_cache", ".cache", "cache2", "thumbnails", "thumbcache",
    # UWP/Store 应用临时缓存；IE/Edge 旧版网络临时缓存（与上方系统锚点双保险）
    "localcache", "inetcache",
    # ---- 非标准但常见的缓存文件夹名（跨 app，补全结构识别）----
    "cache_data", "cachedata", "cef_cache", "cef", "leveldb",
    "d3dcache", "glcache", "vulkancache", "vkcache", "mesacache",
    "d3dshadercache", "pip", "conda", "yarn", "npm_cache",
    "temp", "temporary", "tmp",
    "prefetch", "wer", "crashdumps", "minidump", "diagnostics",
}

# 安全缓存：文件扩展名兜底（零散的临时/日志文件）
SAFE_CACHE_EXTS = {"tmp", "temp", "log", "etl", "bak", "old", "dmp", "partial"}

# ---------------------------------------------------------------------------
# 1.5) 「自家残留 + 升级安装包」→ 直接判 safe（v1.7.83 覆盖度修复）
#
# 背景（2026-10-04 真机实测：本机 5 类共约 4.5GB 被判黄区黑洞、一分释放不出）：
#   a) AppData\Local\Temp\aipc_purge\  —— 我们自己 fast_purge 的暂存区。
#      工具已认定「这东西该删」才会 rename 进来，却因为后台 rd 线程被杀软逐文件
#      拦下而长期卡在 C 盘（实测 615MB / 1.5 万文件，最早可追溯到 2026-08-12）。
#      它是**已判定可删**的待删物，再判一次黄区等于让用户自己掏手指头删。
#   b) AppData\Local\<app>-updater\      —— Electron 自动更新下载的**安装包暂存**
#      （kimi 462MB installer.exe、GenieWorkBuddy 等 14 个共 1.72GB）。
#      装完就没人再读它，下次更新会重新下载；纯下载缓存，删了零后果。
#   c) *.migrated.bak                     —— 我们自己迁移留下的旧源副本。
#
# ⚠️ 安全边界：a/b 是「工具/更新器自己产生的可再生下载物」，不含任何用户数据。
#    c 绝不能无条件判 safe——只有在 classify_bak_residual 确认「junction 已切换且
#    目标盘副本完整」时才可清（见 analyze.is_green_cache 的第五道关），
#    否则就是删用户唯一一份数据。实测本机 Tencent.migrated.bak 就是
#    junction_broken（不能删），com.tencent.yuanbao.migrated.bak 才是 safe。
# ---------------------------------------------------------------------------

# 自家暂存区：路径任意一层 segment 精确等于此值即判 safe
SELF_STAGE_SEGMENTS = frozenset({"aipc_purge"})

# 升级安装包暂存目录：目录名以这些后缀结尾即判 safe
UPDATER_DIR_SUFFIXES = ("-updater", "_updater", "-update", "_update")


def is_self_stage_residual(path):
    """是否本工具自己的待删暂存区（fast_purge 暂存区）。"""
    return any(s in _segments(path) for s in SELF_STAGE_SEGMENTS)


def is_updater_staging(path):
    """是否 Electron 等自动更新器的**安装包下载暂存目录**（<app>-updater）。

    只认「末段目录名带 -updater/_update 后缀」这一种形态，且排除个人目录
    （用户在 D:\下载 建的 "小说-updater" 不会被误判——本函数只按末段名，
    调用方 is_green_cache 已先用家目录关卡拦过一遍）。
    """
    segs = _segments(path)
    if not segs:
        return False
    last = segs[-1]
    return any(last.endswith(sfx) and len(last) > len(sfx) + 1 for sfx in UPDATER_DIR_SUFFIXES)


# ---------------------------------------------------------------------------
# 2) 含个人数据的结构名 → keep（永不自动动）
# ---------------------------------------------------------------------------
KEEP_SEGMENTS = {
    "bookmark", "bookmarks", "login", "cookie", "cookies", "extension",
    "extensions", "plugin", "plugins", "preference", "preferences",
    "setting", "settings", "profile", "database", "databases", "account",
    "accounts", "message", "messages", "chat", "document", "documents",
    "picture", "pictures", "video", "videos", "project", "projects",
    "library", "libraries", "favorite", "favorites", "password", "passwords",
    "workspace", "filestorage", "file receiver", "filereceiver", "qqfilerecv",
    "qqfile", "wechat files", "wechatfiles", "userdata", "user_data",
    "user data", "documents", "desktop", "music", "downloads", "下载",
    # v1.7.34（登录数据保护·关键）：以下为「网站持久化存储」目录，承载登录态/会话，
    # **绝非纯可再生缓存**。清理会导致部分网站被登出 / 丢会话（用户实测反馈"清理后
    # 很多网站需重新登录"）。必须从 SAFE_CACHE_SEGMENTS 移到此处，永不清理：
    #   - local storage / web storage      ：localStorage（站点持久化，常含登录 token）
    #   - session storage                  ：sessionStorage（会话）
    #   - indexdb / indexeddb / file system：IndexedDB（站点数据库，含离线数据/状态）
    #   - blob storage / blobstore         ：IndexedDB 的 Blob 数据
    #   - quota manager                    ：存储配额/统计（关联上述持久数据）
    "local storage", "localstorage", "web storage", "webstorage",
    "session storage", "sessionstorage", "indexdb", "indexeddb",
    "file system", "filesystem", "blob storage", "blobstore",
    "quota manager", "quotamanager",
}

# ---------------------------------------------------------------------------
# 3) 已知「国民软件 app 根目录」标记 → 其整体标 review（需确认），但内部缓存可安全清
#    用路径里是否含这些子串判断（跨版本/跨安装路径都较稳）。
# ---------------------------------------------------------------------------
APP_ROOT_MARKS = (
    "360se", "360", "secoresdk", "qihoo",                      # 360 系
    "tencent", "wechat", "weixin", "wxwork", "wework", "qqnt", "qq",  # 腾讯系
    "kingsoft", "wps", "wps office", "kesetting",              # 金山 / WPS
    "thunder network", "xunlei", "迅雷",                       # 迅雷（精确目录名，避免误匹配 Thunderbird 邮件客户端）
    "baidunetdisk", "baidu", "baidun",                         # 百度
    "sogou", "kzip",                                           # 搜狗
    "netease", "douyin", "kuaishou", "bilibili", "alipay",     # 其他国民软件
)

# 国民软件里「可安全清」的知名大缓存目录（精确名，用于顶层也亮出来）
KNOWN_SAFE_APP_CACHES = (
    ("360se6", "360 浏览器缓存"),
    ("thunder7.9", "迅雷 7.9 缓存"),
    ("thunder7", "迅雷缓存"),
    ("wps office", "WPS Office 缓存"),
    ("qqnt", "QQ NT 缓存"),
    ("wxwork", "企业微信缓存"),
    ("weixin", "微信(PC)缓存"),
    ("yuanbao", "元宝缓存"),
    ("qq", "QQ 缓存"),
)


# ---------------------------------------------------------------------------
# 4) 系统级安全缓存根（Windows 通用，删了系统自动重建，且体积往往巨大）
#    这些目录 scan.py 之前根本没扫，是「漏掉的比想象多」的主力。
# ---------------------------------------------------------------------------
# ⚠️ 必须带路径锚点（前后有 \\），不能用裸子串！
# 反面教训：曾用裸 "wer" → "PowerPoint"(po-wer)、"360AlbumViewer"(vie-wer)、
# "Answers"(ans-wer)、"PowerManager"(po-wer) 全被误判成系统缓存，用户级 app
# 缓存混进「Windows 系统缓存」组，小白看到一脸懵。同理 "prefetch"/"deliveryoptimization"
# 也改为带盘符或父目录锚定的完整片段。
SYSTEM_CACHE_MARKS = (
    "\\windows\\temp",
    "\\windows\\prefetch",
    "\\softwaredistribution\\download",
    "\\softwaredistribution\\deliveryoptimization",
    "\\microsoft\\windows\\deliveryoptimization",  # ServiceProfiles 下的 DO
    "\\microsoft\\windows\\wer",                    # C:\ProgramData\Microsoft\Windows\WER
    # ====== 三类必杀器·系统级缓存 ======
    "\\windows\\explorer\\thumbcache",             # 缩略图 (AppData\Local\Microsoft\Windows\Explorer)
    "\\microsoft\\search\\data",                   # Windows Search 索引
    "\\microsoft\\windows\\inetcache",             # IE / Edge 旧版网络临时缓存
    "\\microsoft\\onedrive\\logs",                  # OneDrive 日志（不含同步文件）
    "\\microsoft\\onedrive\\standaloneupdater",    # OneDrive 自动更新缓存
    # ⚠️ P2-4 修复：Windows 事件日志 (winevt\logs) 含 System.evtx/Security.evtx，
    # 属审计/排障证据，非纯缓存，删除不可逆（对 IT/企业用户尤其重要）。
    # 故不再当系统安全缓存标绿，移除以保绿区 100% 安全（当前对其不做展示）。
    "\\inetpub\\logs",                              # IIS 日志
    "\\assembly\\nativeimages_",                   # .NET Native Image Cache
    # ====== v1.7.35（增强3）：低风险系统缓存（崩溃转储 / 字体缓存 / 系统日志）======
    # 全是可再生、删了系统自动重建的安全缓存，不碰系统功能/应用/个人文件。
    "\\windows\\logs\\cbs",                        # CBS 组件服务日志（磁盘紧张可达数 GB）
    "\\windows\\livekernelreports",                # 内核实时崩溃转储
    "\\windows\\minidump",                         # 蓝屏小内存转储 *.dmp
    "\\windows\\serviceprofiles\\localservice\\appdata\\local\\fontcache",  # 字体缓存（系统自动重建）
    "\\windows\\memory.dmp",                       # 内存转储残留（非 pagefile）
)

def is_system_cache(path):
    """路径是否落在已知的 Windows 系统安全缓存根（可放心标绿）。

    用带 \\ 锚点的完整路径片段匹配，避免把含 wer/power/viewer 等子串的
    用户级 app 缓存误判成系统缓存。首尾各补一个 \\ 以便锚点命中盘符根/末层。
    """
    np_ = "\\" + path.replace("/", "\\").lower().strip("\\") + "\\"
    for m in SYSTEM_CACHE_MARKS:
        if m in np_:  # m 已含前导 \\ 锚点，避免 power/viewer/answer 等误命中
            return True
    return False


def _segments(path):
    """把路径拆成小写 segment 列表（兼容 / 与 \\）。"""
    p = path.replace("/", "\\").lower().strip("\\")
    return [s for s in p.split("\\") if s]


def classify_path(path):
    """给定任意路径，返回 ('safe' | 'review' | 'keep', reason)。

    - safe   : 明确的缓存/临时结构 → 可安全清
    - keep   : 含个人数据 → 永不自动动
    - review : app 根目录或拿不准 → 需用户确认（但内部缓存仍可安全清）
    """
    segs = _segments(path)
    last = segs[-1] if segs else ""
    joined = "\\".join(segs)

    # 0) 自家暂存区 / 升级安装包暂存 → safe（v1.7.83）
    #    必须排在 keep 之前：`-updater` 目录常含 "desktop"/"edge" 等词会被
    #    KEEP_SEGMENTS 先一刀切 keep（实测 kimi-desktop-updater 正是如此）。
    #    这两类目录里装的是「我们已判定该删的待删物」与「更新器下载的安装包」，
    #    都不含用户数据，判 keep 是误伤。
    if is_self_stage_residual(joined):
        return ("safe", "本工具待删暂存区，删了不影响任何软件")
    if is_updater_staging(joined):
        return ("safe", "软件更新下载的安装包缓存，删了下次更新自动重下")

    # 1) 含个人数据 → keep（优先级最高）
    for k in KEEP_SEGMENTS:
        if k in joined:
            return ("keep", "含书签/聊天/文档等个人数据，建议保留")

    # 1.5) Python/Node 运行时的**本体包**不是缓存（v1.7.83 实测抓到的误删风险）
    #   ...\Lib\site-packages\pip 是完整可运行的 Python 包（有 __init__.py / _internal），
    #   删掉会直接破坏 pip 功能；但它末段名恰是 "pip"，而 "pip" 在
    #   SAFE_CACHE_SEGMENTS 里（为的是识别 %LOCALAPPDATA%\pip\Cache 这类缓存根），
    #   于是被裸段名匹配判成 safe —— **这是去重修复让更多路径进入判定后才暴露的**。
    #   修法：site-packages / node_modules 下的东西一律 keep（那是「装好的运行环境」，
    #   该清的是它们旁边的 Cache 目录，不是它们本身）。
    if "site-packages" in segs or "node_modules" in segs:
        return ("keep", "编程语言运行库本体，删了会破坏该环境（要清请清旁边的 Cache 目录）")

    # 2) 明确缓存结构名 → safe
    for s in SAFE_CACHE_SEGMENTS:
        if s == last or ("\\" + s + "\\") in ("\\" + joined + "\\") or joined.endswith("\\" + s):
            return ("safe", "缓存/临时文件，删了会自动重建")
    # 文件扩展名兜底
    if "." in last:
        ext = last.rsplit(".", 1)[-1]
        if ext in SAFE_CACHE_EXTS:
            return ("safe", "日志/临时文件，可删")

    # 2.5) 系统级安全缓存根 → safe（Windows 通用，删了自动重建）
    if is_system_cache(joined):
        return ("safe", "系统缓存/临时文件，删了系统会自动重建")

    # 3) 国民软件 app 根 → review
    for m in APP_ROOT_MARKS:
        if m in joined:
            return ("review", "应用数据目录，内含可清理缓存，建议确认后清理")

    # 4) AppData / 程序数据下的未知目录 → review（中性，不默认当垃圾）
    if "appdata" in joined or "programdata" in joined or "program files" in joined:
        return ("review", "软件数据目录，建议打开确认")

    # 5) 兜底：拿不准 → review
    return ("review", "需打开确认内容")


def scan_safe_cache(root, max_depth=3):
    """只读下钻：在 root 内找出所有「安全缓存」子目录，返回 [(path, size_kb)]。

    - 只认 SAFE_CACHE_SEGMENTS 的 segment 名（或安全扩展名文件）。
    - 找到缓存目录后**整体计量并停止下钻**（避免重复统计 + 控制遍历深度）。
    - 绝不触碰非缓存目录，天然安全。
    - 上限 MAX_DIRS 防止极端超大目录卡死。
    """
    root = os.path.expanduser(root)
    if not os.path.isdir(root):
        return []
    found = []
    MAX_DIRS = 400
    _seen = set()
    try:
        for dp, dns, fns in os.walk(root):
            # 环检测：跳过已访问的真实路径（防极端 junction 环，P2-5）
            try:
                rdp = os.path.realpath(dp)
            except OSError:
                rdp = dp
            if rdp in _seen:
                dns[:] = []
                continue
            _seen.add(rdp)
            depth = dp[len(root):].count(os.sep)
            if depth > max_depth:
                dns[:] = []
                continue
            # 安全缓存目录
            for d in list(dns):
                if d.lower() in SAFE_CACHE_SEGMENTS:
                    fp = os.path.join(dp, d)
                    try:
                        sz = sum_file_sizes(fp)
                    except OSError:
                        sz = 0
                    if sz > 0:
                        found.append((fp, round(sz / 1024.0, 1)))
                    dns.remove(d)  # 已整体计量，不再下钻
                    if len(found) >= MAX_DIRS:
                        dns[:] = []
                        break
            if len(found) >= MAX_DIRS:
                break
            # 安全缓存文件（零散 tmp/log 等）
            for fn in fns:
                fl = fn.lower()
                if "." in fl and fl.rsplit(".", 1)[-1] in SAFE_CACHE_EXTS:
                    fp = os.path.join(dp, fn)
                    try:
                        sz = os.path.getsize(fp)
                    except OSError:
                        sz = 0
                    if sz > 0:
                        found.append((fp, round(sz / 1024.0, 1)))
    except OSError:
        pass
    return found


def _is_junction(path):
    """Windows 目录联接(junction)检测。

    关键：junction 不被 os.path.islink 识别，os.walk(followlinks=False) 仍会下钻进去，
    把『目标目录的体积』重复算进绿区；但删除 junction 只删链接(≈0 释放)。
    若不跳过，会制造『显示可释放 X GB，实际删了只腾几 KB』的虚高——等同诈骗。
    返回 True 表示这是 junction（应跳过其子树）。
    """
    try:
        if hasattr(os.path, "isjunction") and os.path.isjunction(path):
            return True
        # 回退：reparse point 且非 symlink 即视为 junction
        st = os.lstat(path)
        if getattr(st, "st_file_attributes", 0) & 0x400:  # FILE_ATTRIBUTE_REPARSE_POINT
            if not os.path.islink(path):
                return True
    except OSError:
        pass
    return False


def sum_file_sizes(path):
    """递归累加目录内【真实可删】文件字节数。

    防虚高(P0)：
      1) 跳过 junction 子树——删 junction 不释放目标空间，不能算进『可释放量』；
      2) 同 (st_dev, st_ino) 只计一次——硬链接多条名字共享同一簇，删一条不释放。
    保证『报告显示可释放 X GB』 == 『真实能删的文件体积』，数字绝不含水。

    v1.7.30 性能重写（analyze 阶段 63.6s → 数秒的核心项）：旧实现 os.walk + 每个
    子目录一次 _is_junction 探测 + 每个文件一次 os.stat（独立系统调用，杀软环境下
    ~0.45ms/次）。新实现用 os.scandir 栈遍历：Windows 上 DirEntry 的 stat 信息随枚举
    缓存（entry.stat() 零额外 syscall），junction 用缓存 st_file_attributes 的
    REPARSE_POINT 位识别（不能用 is_dir(follow_symlinks=False)——实测 Windows+Py3.13
    上 junction 仍返回 True）。
    硬链接去重：DirEntry.stat 的 st_ino 在本机恒为 0、e.inode() 每次又是真实系统调用
    （~0.41ms，360 杀软钩子放大），全量去重会让 8 万文件付出 40s。折中：仅对 ≥1MB 的
    文件做 inode 去重（防大文件虚高；小文件硬链接多计误差 ≤ 数量×1MB，实测目标机
    缓存目录硬链接重复率 0%，可忽略）。避免回归时需留意此口径。
    """
    tot = 0.0
    seen = set()  # 硬链接去重：文件索引（= os.stat().st_ino，Windows 上唯一）
    DEDUP_MIN_BYTES = 1024 * 1024  # v1.7.30：仅 ≥1MB 文件做去重（见 docstring 权衡）
    try:
        if _is_junction(path):
            return 0.0  # 路径本身是 junction：删它不释放目标空间
    except OSError:
        pass
    stack = [path]
    try:
        while stack:
            cur = stack.pop()
            try:
                it = os.scandir(cur)
            except OSError:
                continue
            with it:
                for e in it:
                    try:
                        st = e.stat(follow_symlinks=False)  # Windows: 枚举缓存，零额外系统调用
                        # junction / symlink / mount point（reparse point）→ 跳过子树，
                        # 删 junction 不释放目标空间，不能算进可释放量。
                        if getattr(st, "st_file_attributes", 0) & 0x400:
                            continue
                        if e.is_dir():
                            stack.append(e.path)
                        else:
                            if st.st_size >= DEDUP_MIN_BYTES:
                                key = e.inode()
                                if key in seen:
                                    continue
                                seen.add(key)
                            tot += st.st_size
                    except OSError:
                        continue
    except OSError:
        pass
    return tot


def known_safe_app_cache(name):
    """若目录名是已知的国民软件大缓存（360se6/迅雷7.9/WPS Office/QQNT…），
    返回 (展示名, 说明)，否则 None。用于顶层也醒目亮出。"""
    nl = (name or "").lower().strip()
    for key, label in KNOWN_SAFE_APP_CACHES:
        if key in nl:
            return label
    return None


def software_label(path):
    """给定一个缓存路径，返回它「属于哪个软件」的可读标签。

    用途：把零散的缓存目录（...\\360se6\\Cache、...\\GPUCache…）按软件聚合成
    一条用户能认出的记录，如「360 浏览器缓存」「迅雷缓存」「Edge 缓存」，
    而不是笼统的「浏览器/软件缓存」。跨电脑/跨版本都稳（靠路径里的 app 根标记）。
    """
    segs = _segments(path)
    joined = "\\".join(segs)
    # 0) 系统级安全缓存
    if is_system_cache(joined):
        return "Windows 系统缓存（临时文件 / 预读取）"
    # 1) 精确已知大缓存（360se6 / Thunder7.9 / WPS Office / QQNT …）
    for key, label in KNOWN_SAFE_APP_CACHES:
        if key in joined:
            return label
    # 2) 国民软件 app 根标记 → 可读标签
    if "360se" in joined or "360" in joined or "qihoo" in joined or "secoresdk" in joined:
        return "360 浏览器缓存"
    if "kingsoft" in joined or "wps" in joined or "kesetting" in joined:
        return "金山 WPS 缓存"
    if "thunder network" in joined or "xunlei" in joined or "迅雷" in joined:
        return "迅雷缓存"
    if "tencent" in joined or "wechat" in joined or "wxwork" in joined or "wework" in joined or "qqnt" in joined or "qq" in joined:
        return "腾讯系缓存（微信 / QQ / 企业微信）"
    if "baidu" in joined:
        return "百度缓存"
    if "sogou" in joined or "kzip" in joined:
        return "搜狗缓存"
    if "netease" in joined:
        return "网易缓存"
    if "douyin" in joined or "bilibili" in joined or "kuaishou" in joined:
        return "短视频 / 视频缓存"
    # 3) 浏览器
    if "chrome" in joined or "chromium" in joined:
        return "Chrome 缓存"
    if "edge" in joined:
        return "Edge 缓存"
    if "firefox" in joined or "mozilla" in joined:
        return "Firefox 缓存"
    if "electron" in joined:
        return "Electron 应用缓存"
    # 3.5) 微软 Office / 组件（PowerPoint/Word/Excel/Outlook/OneNote/webview2）
    #      注意锚点，避免 "password"、"keyword" 等误命中
    if any(k in joined for k in ("powerpoint", "\\word\\", "excel", "outlook",
                                 "onenote", "\\office\\", "msoffice", "webview2",
                                 "officeclicktorun")):
        return "Microsoft Office 缓存"
    # 4) 兜底
    return "其他软件缓存"
