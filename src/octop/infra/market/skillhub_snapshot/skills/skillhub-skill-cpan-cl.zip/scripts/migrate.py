#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C 盘迁移引擎（融合 FolderMove / SteamMover 的开源思路：移动文件夹 + 创建 NTFS 目录联接）。

只读、零网络、零第三方依赖。核心三步（与 FolderMove 完全一致）：
  1. 把一个「自包含」的大文件夹从 C 盘移动到其它盘（如 D:\\AI_PC_Migrated\\...）
  2. 在原位置创建一个 junction（目录联接），指向新位置
  3. Windows / 程序以为文件还在原处，实际已搬到别的盘 -> C 盘立刻腾出空间

安全边界（与产品「信任」本质一致，绝不碰个人文件）：
  - 仅允许迁移明确是「程序数据 / 缓存 / 游戏库」的目录（SAFE_MIGRATE_PATTERNS）
  - 绝不迁移 Desktop / Documents / Pictures / Downloads / 用户根目录
  - 移动前检查目标盘空间；junction 创建失败则自动回滚（把文件搬回原处）
  - 需要管理员权限（mklink /J 创建联接）
"""
import os
import re
import shutil
import subprocess
import sys
import json
import hashlib
import threading
import time as _time
import tempfile as _tf
from concurrent.futures import ThreadPoolExecutor, as_completed
# v1.7.86：主循环与兜底分支都改成「带 timeout 的 as_completed」，超时时靠这个异常
# 交出已完成的部分。不 import 它就无法区分「正常全部完成」与「到点被迫收工」，
# 也就无法如实记账（只能全当成成功或全当成失败，都是骗用户）。
try:
    from concurrent.futures import TimeoutError as FuturesTimeoutError
except Exception:                                    # 极老版本兜底
    class FuturesTimeoutError(Exception):
        pass

# 创建子进程时不弹出黑色控制台窗口（Windows）。用于 cmd/robocopy/takeown/icacls/
# schtasks 等命令，避免用户看到一堆黑框而恐慌/退款。
try:
    CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW
except AttributeError:
    CREATE_NO_WINDOW = 0x08000000

# v1.7.82（过审改造·科恩实验室）：本模块已彻底移除「注册开机/登录自启任务」的一切能力
# （v1.7.81 及之前的 _schedule_reboot_commit / _schedule_reboot_complete / 登录清理任务通道全部删除）。
# 迁移收尾改为「重启电脑 → 重新打开本工具 → 启动兜底自动补齐」（见 auto_cleanup_orphan_baks）。
# consent_system 同意开关保留，现仅用于门控 Restart Manager 等敏感系统 API 的调用。
_REBOOT_TASKS_ALLOWED = False
_RM_ALLOWED = False


def set_system_tasks_allowed(allowed):
    """设置是否允许使用 Restart Manager 等敏感系统 API（v1.7.82 起不再有开机任务可门控）。

    由 server.py 在用户通过 UI 明确确认后调用。默认 False。"""
    global _REBOOT_TASKS_ALLOWED, _RM_ALLOWED
    _REBOOT_TASKS_ALLOWED = bool(allowed)
    _RM_ALLOWED = bool(allowed)


# 迁移目标盘预留空间：固定 10GB 上限（v1.7.33 从 20 降到 10）。
# 若目标盘本身很小，则按总容量的 15% 预留，避免把目标盘压爆（二者取小）。
# 10GB 对日常使用已足够缓冲（Windows 更新/临时文件峰值通常 < 8GB），
# 同时大幅减少「34GB 被锁无法迁移」的糟糕体验。
RESERVE_GB = 10.0

# ===== v1.7.94 P0：junction 整目录迁移的「峰值倍数」=====
# 迁 N GB 的目录，真实峰值可能占 2N GB：
#   ① 拷一份到目标盘 = N
#   ② 若目标盘已有源里没有的数据，旧副本会被挪成 <target>.previous（AIPC-DST-FOREIGN-FIX
#      的保护措施，绝不能删用户可能唯一的一份），此时两份并存 = 2N
#   ③ 直到 junction 建好、切换成功，`_clean_previous_asides` 才把 .previous 收掉
# 旧容量闸按 N 判 → 会把目标盘压到 RESERVE_GB 以下 → 用户新存的数据写不进去。
# 所以这里按 2 倍计预算。做成常量而非散落在业务代码里，便于将来按实测调整。
ASIDE_PEAK_FACTOR = 2.0

# 后台 purge 线程登记：fast_purge 把「改名搬移」放到后台线程后，server 需要等待这些
# 线程把暂存区真正 rd 掉、磁盘空间真正释放后，才能测得准确的「真实释放量」。
_PURGE_THREADS = []
_PURGE_LOCK = threading.Lock()
# v1.7.24：异步清空（_empty_dir_contents）的真实残留统计（线程完成后回报，
# server 校准线程读取 → 更新 clean_state → 弹窗/页面展示「未清理 X 项 + 已安排重启删」）。
_PURGE_RESIDUAL = {"count": 0, "bytes": 0}
_PURGE_RESIDUAL_LOCK = threading.Lock()
# v1.7.27：SHEmptyRecycleBinW 后台线程登记（黄金组合的物理释放阶段——大回收站
# 20GB/数万文件实测 8 分钟，若同步阻塞会让 done/弹窗 8 分钟才出现，严重伤体验）。
# server 校准线程通过 wait_bg_empty() 等待其真正释放后再磁盘实测覆盖 freed。
_EMPTY_THREADS = []
_EMPTY_LOCK = threading.Lock()

def wait_bg_empty(timeout=300):
    """等待所有在途的 SHEmptyRecycleBinW 后台清空线程完成（最多 timeout 秒）。"""
    threads = []
    with _EMPTY_LOCK:
        threads = list(_EMPTY_THREADS)
        _EMPTY_THREADS[:] = []
    for t in threads:
        try:
            t.join(timeout)
        except Exception:
            pass

def wait_purge(timeout=120):
    """等待所有在途的后台 purge 线程完成（最多 timeout 秒），随后清空登记。

    用于清理动作结束后核算『磁盘实测真实释放量』——必须等 rd 真正释放磁盘。
    """
    threads = []
    with _PURGE_LOCK:
        threads = list(_PURGE_THREADS)
        _PURGE_THREADS[:] = []
    for t in threads:
        try:
            t.join(timeout)
        except Exception:
            pass

# --------------------------------------------------------------------------
# 极速删除：整目录瞬时改名搬至暂存区 + 后台线程 rd 真正清理
# --------------------------------------------------------------------------
_GLOBAL_PURGE_STAGE = None

# v1.7.85（老李 2026-10-04 实测根因①）：暂存区**不能放在 %TEMP% 里面**。
# 原实现用 os.path.join(_tf.gettempdir(), "aipc_purge") = C:\Users\<u>\AppData\Local\Temp\aipc_purge，
# 而 `Temp` 本身【就是一键清的清理目标】。于是：
#   清理 Temp → fast_purge 试图 rename Temp → C:\...\Temp\aipc_purge\p_xxx
#                                              ↑ 目标是自己的子目录，MoveFileExW 必失败(err 5)
#   → 永远走 _empty_dir_contents 兜底分支 → 整目录删不掉（实测 41179 个文件只删掉 15 个）。
# 这就是「报告说 4.3GB、实际释放 0.06GB」的直接原因。
# 修正：暂存区放【C 盘根】下、与 %TEMP% 同卷（rename 跨卷会变成复制，删不掉就白干）。
_PURGE_STAGE_CANDIDATES = (
    r"C:\aipc_purge",             # 首选：C 盘根，与 Temp 同卷
    r"C:\ProgramData\aipc_purge",  # 备选：ProgramData（通常同卷且可写）
)

def _purge_stage():
    global _GLOBAL_PURGE_STAGE
    if _GLOBAL_PURGE_STAGE is None:
        chosen = None
        for d in _PURGE_STAGE_CANDIDATES:
            try:
                os.makedirs(d, exist_ok=True)
                # 必须能真正写入（只 makedirs 成功不代表可写）
                _probe = os.path.join(d, ".probe")
                with open(_probe, "wb") as _f:
                    _f.write(b"1")
                # v1.7.100：探针用 _win_delete 直删。若被运行环境安全删除层拦进
                #   回收站，.probe 会留在暂存区里，让「暂存区已清空」的判定永远不成立。
                _win_delete(_probe)
                chosen = d
                break
            except Exception:
                continue
        if chosen is None:
            # 兜底：退回 %TEMP% 下（此时 Temp 自身清理会走 _empty_dir_contents 分支，
            # 速度慢但不会假成功——该分支已改为同步返回真实结果）
            chosen = os.path.join(_tf.gettempdir(), "aipc_purge")
            try:
                os.makedirs(chosen, exist_ok=True)
            except Exception:
                chosen = _tf.gettempdir()
        _GLOBAL_PURGE_STAGE = chosen
    return _GLOBAL_PURGE_STAGE

def _bg_purge(staging_path):
    """background thread: really delete the staged tree (slow under AV, but non-blocking).

    重试：大目录在实时查杀/占用进程（如 360 持有自身缓存文件）逐文件扫描时，
    首轮 rd 偶发因单文件被占用而以非 0 退出、残留若干文件。给 0.5s 让占用/查杀
    释放后重试，至多 3 次，覆盖瞬时锁；持久锁（应用仍运行）则如实残留，由用户
    关闭相关软件后重试——属正常 OS 行为，非缺陷。
    """
    for attempt in range(3):
        try:
            r = subprocess.run(["cmd", "/c", "rd", "/s", "/q", staging_path],
                               capture_output=True, text=True, errors="ignore", timeout=600,
                               creationflags=CREATE_NO_WINDOW)
            if not os.path.exists(staging_path):
                return
            if r.returncode == 0 and not os.path.exists(staging_path):
                return
        except Exception:
            pass
        if attempt < 2:
            _time.sleep(0.5)
    # 末轮仍残留：尝试 del + rd 兜底（处理 rd 因个别顽固文件失败的极端情况）
    try:
        subprocess.run(["cmd", "/c", "del", "/f", "/q", "/s", staging_path],
                       capture_output=True, text=True, errors="ignore", timeout=600,
                       creationflags=CREATE_NO_WINDOW)
        subprocess.run(["cmd", "/c", "rd", "/s", "/q", staging_path],
                       capture_output=True, text=True, errors="ignore", timeout=600,
                       creationflags=CREATE_NO_WINDOW)
    except Exception:
        pass

def _kill_proc_tree(proc, timeout=8):
    """v1.7.85：杀掉子进程**及其全部后代**（robocopy /MT:N 会 spawn N 个工作线程进程）。

    【为什么必须杀进程树 —— 这就是「迁移卡 5 小时」的直接凶手】
    _copy_tree 里原来超时只写 `proc.kill()`：
        proc.kill() 在 Windows 上 = TerminateProcess(主进程)，**只杀主进程**，
        robocopy /MT:64 的 64 个工作进程是它的**子进程**，会继续活着继续往 D 盘写。
    于是超时后发生的事（老李 2026-10-04 实测 4h48m 卡死）：
        ① 主进程被杀，但 64 个子进程还在跑 → D 盘空间继续减少
        ② ticker 用「D 盘空间变化」当进度 → 页面显示 93.4% 一直不动（假数字）
        ③ 主进程 raise 掉进 shutil.copytree 兜底，单线程逐文件、**零进度上报**
        ④ copytree 与残留的 64 个 robocopy 子进程抢 D 盘 IO，越拖越慢
        ⑤ 4h48m 一个字节没搬完，server.log 一行不写
    修法：taskkill /T /F 杀整棵树。杀不掉也要如实返回 False，让调用方知道没杀干净。
    """
    if proc is None:
        return True
    try:
        if proc.poll() is not None:
            return True
    except Exception:
        pass
    killed = False
    # 首选 taskkill /T /F（唯一能杀整棵树的系统自带手段）
    try:
        _r = subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                            capture_output=True, timeout=timeout,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        killed = (_r.returncode == 0)
    except Exception:
        killed = False
    # 兜底：至少把主进程杀掉（taskkill 不可用时）
    try:
        if proc.poll() is None:
            proc.kill()
            killed = True
    except Exception:
        pass
    try:
        proc.wait(timeout=timeout)
    except Exception:
        pass
    return killed


def _robocopy_delete_popen(path):
    """启动 robocopy /MIR 空目录快速删除，返回 (Popen, empty_dir)。

    关键修复（v1.7.5 一键清卡死）：旧实现用 subprocess.run 同步阻塞（timeout=600），
    且 robocopy /MIR 删完只留下「空目录本身」导致调用方轮询死等满 600s。
    这里改为非阻塞 Popen，由 _sync_delete_with_progress 边跑边轮询进度。
    无 robocopy 时返回 (None, None)，由调用方回退 rd /s /q。
    """
    robocopy = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "robocopy.exe")
    if not os.path.exists(robocopy):
        return (None, None)
    empty = os.path.join(_purge_stage(), "_empty_%d_%d" % (os.getpid(), int(_time.time() * 1000)))
    try:
        os.makedirs(empty, exist_ok=True)
    except Exception:
        return (None, None)
    try:
        proc = subprocess.Popen([robocopy, empty, path, "/MIR", "/MT:64", "/R:0", "/W:0", "/NP", "/NFL", "/NDL"],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                creationflags=CREATE_NO_WINDOW)
        return (proc, empty)
    except Exception:
        try:
            # v1.7.100：_win_delete 代替 os.rmdir（后者被安全删除层重定向进回收站）
            _win_delete(empty)
        except Exception:
            pass
        return (None, None)


def _force_rmdir_tree(path):
    """尽力删除目录树（含空子目录）；个别锁定文件删不掉也无妨，交给残留收集。"""
    try:
        subprocess.run(["cmd", "/c", "rd", "/s", "/q", path],
                       capture_output=True, text=True, errors="ignore", timeout=90,
                       creationflags=CREATE_NO_WINDOW)
    except Exception:
        pass


def _parallel_delete_tree(path, deadline=None):
    """ctypes 并行删除整棵目录树（借鉴 FastFolderDelete MIT 思路：多线程 DeleteFileW/RemoveDirectoryW）。

    纯 Windows API，零外部 exe；被占用/已删条目忽略（幂等）；只删 path 之内，绝不越界。
    两阶段：先并行删全部文件，再按深度倒序并行删目录（深目录先删，父目录最后清）。
    deadline 到达后停止，交给上层 rd /s /q 兜底。目标为缓存/临时目录，文件量在合理范围。
    """
    import ctypes
    try:
        k32 = ctypes.windll.kernel32
    except Exception:
        return
    root = os.path.abspath(path)
    if not os.path.exists(root):
        return
    if deadline is None:
        deadline = _time.time() + 120
    files, dirs = [], []
    try:
        for dp, dn, fn in os.walk(root):
            if _time.time() > deadline:
                break
            for fl in fn:
                files.append(os.path.join(dp, fl))
            for d in dn:
                dirs.append(os.path.join(dp, d))
    except Exception:
        pass
    dirs.sort(key=len, reverse=True)  # 深目录先删，避免「非空目录」失败

    def _del_file(ap):
        try:
            if os.path.abspath(ap).startswith(root):
                k32.DeleteFileW(os.path.abspath(ap))
        except Exception:
            pass

    def _del_dir(ap):
        try:
            if os.path.abspath(ap).startswith(root):
                k32.RemoveDirectoryW(os.path.abspath(ap))
        except Exception:
            pass

    nw = min(32, max(4, (os.cpu_count() or 4) * 2))
    if files and _time.time() <= deadline:
        try:
            with ThreadPoolExecutor(max_workers=nw) as ex:
                list(ex.map(_del_file, files))
        except Exception:
            pass
    if dirs and _time.time() <= deadline:
        try:
            with ThreadPoolExecutor(max_workers=nw) as ex:
                list(ex.map(_del_dir, dirs))
        except Exception:
            pass


def _sync_delete_with_progress(path, on_progress, deadline_sec=120):
    """同步删除大目录（暂存态），删除期间持续回调真实进度，杜绝 UI 卡死。

    策略（v1.7.6 提速）：优先 ctypes 并行删除（多线程 DeleteFileW/RemoveDirectoryW，
    借鉴 FastFolderDelete MIT 思路，海量小文件快数倍）；删除在后台线程跑，主线程轮询
    真实剩余字节回传进度，保持 UI 响应。删除结束（或超时）再用 rd /s /q 兜底，
    确保空目录/被锁残留也清掉。最后收集删不掉的残留文件（被程序/系统锁定），供 Q1 重启自动删。
    """
    try:
        total_bytes = max(1, _dir_stats(path)[1])
    except Exception:
        total_bytes = 1
    last_emit = 0.0

    def _emit(rem):
        nonlocal last_emit
        now = _time.time()
        if now - last_emit < 0.35 and rem > 0:
            return
        last_emit = now
        done = max(0, total_bytes - rem)
        try:
            on_progress(done, total_bytes, 0)
        except Exception:
            pass

    _emit(total_bytes)  # 起手先给一个进度（done=0），避免 UI 看着没反应

    deadline = _time.time() + deadline_sec
    # 后台并行删除（加速核心），主线程轮询进度杜绝卡死
    del_thread = threading.Thread(target=_parallel_delete_tree, args=(path, deadline), daemon=True)
    del_thread.start()
    while del_thread.is_alive() and _time.time() < deadline:
        try:
            rem = _dir_stats(path)[1] if os.path.exists(path) else 0
        except Exception:
            rem = 0
        _emit(rem)
        _time.sleep(0.4)
    del_thread.join(timeout=5)
    # 兜底 rd /s /q：清掉并行删除可能遗漏的空目录/被锁文件（保证删得掉、不残留）
    _force_rmdir_tree(path)
    _emit(0)
    # ── Q1：收集删不掉的残留文件（被程序/系统锁定），返回给上层登记重启自动删 ──
    residual = []
    try:
        if os.path.exists(path):
            for _root, _dirs, _files in os.walk(path):
                for _f in _files:
                    residual.append(os.path.join(_root, _f))
                    if len(residual) >= 5000:
                        raise StopIteration
    except StopIteration:
        pass
    except Exception:
        pass
    return residual


def _lp(path):
    """长路径前缀：让 Win32 API 支持 >260 字符路径（深度缓存如 node_modules / 微信多层缓存）。

    否则路径过长的文件/目录 DeleteFileW / RemoveDirectoryW / MoveFileExW 直接失败，
    沦为删不掉的残留 —— 即「扫描出来却清不掉」的根因之一。
    要求：绝对路径 + 反斜杠 + 无 . / .. 成分（normpath 已处理）；UNC 不在此处理（仅本地盘）。
    """
    try:
        a = os.path.abspath(path)
        a = os.path.normpath(a).replace("/", "\\")
        if not a.startswith("\\\\?\\"):
            a = "\\\\?\\" + a
        return a
    except Exception:
        return path


def _win_delete(path):
    """用 Windows API 直接删除（不经 Python 文件接口），确保磁盘空间立即释放。
    文件或软链用 DeleteFileW；空目录用 RemoveDirectoryW；非空目录回退 cmd rd（子进程）。"""
    import ctypes
    p = _lp(path)
    if os.path.islink(p) or os.path.isfile(p):
        if not ctypes.windll.kernel32.DeleteFileW(p):
            raise OSError("DeleteFileW 失败(err %d): %s" % (ctypes.GetLastError(), p))
        return
    if os.path.isdir(p):
        if ctypes.windll.kernel32.RemoveDirectoryW(p):
            return
        # 非空目录回退 cmd rd
        subprocess.run(["cmd", "/c", "rd", "/s", "/q", p],
                       capture_output=True, text=True, errors="ignore", timeout=120,
                       creationflags=CREATE_NO_WINDOW)
        return
    # 不存在视为已删


def _win_move(src, dst):
    """v1.7.9: os.rename replacement using MoveFileExW with long path support.

    Python's os.rename does NOT recognize the NT namespace prefix, so long paths
    (>260 chars) cause rename to fail silently and fall through to slow in-place delete.
    MoveFileExW with MOVEFILE_COPY_ALLOWED handles both same-volume atomic renames
    and cross-volume moves correctly with extended-length paths.
    """
    import ctypes
    MOVEFILE_COPY_ALLOWED = 0x2
    if ctypes.windll.kernel32.MoveFileExW(_lp(src), _lp(dst), MOVEFILE_COPY_ALLOWED):
        return
    # MoveFileExW failed — try os.rename as fallback for short paths
    raise OSError("MoveFileExW failed(err %d): %s -> %s" % (
        ctypes.GetLastError(), src, dst))
    return


def _probe_file_locked(fp):
    """Quick probe: try CreateFileW with DELETE access to test if a file is locked.
    Returns True if locked (cannot open for delete), False if deletable.
    Uses 0 share mode to detect any holder. Does NOT modify the file."""
    import ctypes
    try:
        k32 = ctypes.windll.kernel32
        GENERIC_READ = 0x80000000
        DELETE = 0x00010000
        OPEN_EXISTING = 3
        FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
        INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
        h = k32.CreateFileW(
            _lp(fp),
            GENERIC_READ | DELETE,
            0,  # no sharing: detect any holder
            None,
            OPEN_EXISTING,
            FILE_FLAG_BACKUP_SEMANTICS,
            None,
        )
        if h is None or h == INVALID_HANDLE_VALUE:
            return True  # locked or doesn't exist (treat as locked)
        k32.CloseHandle(h)
        return False  # unlocked
    except Exception:
        return True  # conservative: treat as locked


def _rd_fast_delete(path, timeout=240):
    r"""v1.7.83 新增：先用 `cmd /c rd /s /q` 整目录物理删除（最快路径）。

    【为什么加回来——v1.7.12 废弃 rd 的理由已不成立】
    v1.7.12 担心「rd 在部分环境下返回 0 却没真删、且启动会卡满 timeout」，据此全量改用
    WinAPI 逐文件。但 2026-10-04 本机实测（同一台机、同一目录形态、2000 个 1KB 小文件）：

        DeleteFileW 单线程        17 文件/秒
        DeleteFileW 32 线程       64 文件/秒   ← v1.7.24 现行方案
        rd /s /q                134 文件/秒   ← 快 2.1 倍，且三轮连续测试零残留

    致命后果实测：`uv\cache` 有 57618 个文件 / 2400MB，按 64 文件/秒需 15 分钟，
    而 fast_purge 给异步删除的时限只有 180 秒 → 只能删掉约 1.1 万个，**剩下 4.6 万个
    （约 2.4GB）永远删不掉**。这就是「报告说一键清 10.6GB、实际只释放 3.3GB」的真凶。

    【安全设计——绝不把可靠性押在 rd 单独身上】
    rd 只是「快路径」，不是「唯一路径」。本函数返回 True/False 表示是否**确已删干净**
    （判定标准 = 目录已不存在），调用方在 rd 失败/超时/没删干净时，一律回退到
    WinAPI 逐文件扫尾（_fast_delete_dir 原路径）。因此即使某台机器上 rd 失败、
    返回 0 却不真删，也只是「退回慢速删除」，绝不会出现「以为删了其实没删」。

    返回 True  = 已确认删干净（调用方无需再扫尾）
    返回 False = 未删干净 / 超时 / 不可用 → 调用方必须走 WinAPI 扫尾
    """
    try:
        p = subprocess.run(
            ["cmd", "/c", "rd", "/s", "/q", _lp(path)],
            capture_output=True, timeout=timeout,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        _ = p.returncode   # rc 不可信（可能返 0 却没删），只认下面的实地判定
    except Exception:
        return False
    # 实地判定：目录还在 或 里面还有文件 = 没删干净（不信 rc）
    try:
        if not os.path.isdir(_lp(path)):
            return True
        for _dp, _dn, _fn in os.walk(_lp(path)):
            if _fn:
                return False
        # 空目录壳：再补一刀（rd 偶尔留下空壳）
        # v1.7.100：必须真删。若走 os.rmdir 被安全删除层拦进回收站，空壳会永远留在
        #   原位 → 上层「已删干净」判定失败 → 清不掉的目录反复重试。
        try:
            _win_delete(_lp(path))
        except Exception:
            pass
        return not os.path.isdir(_lp(path))
    except Exception:
        return False


def _fast_delete_dir(path, on_progress=None, max_sec=30):
    r"""Fast delete: rd 快路径 + WinAPI 并行递归删除（v1.7.83 混合，环境无关）。

    v1.7.24 纯 WinAPI 版实测只有 64 文件/秒，海量小文件目录（uv\cache 5.7 万个文件）
    在 180 秒时限内删不完 → 2.4GB 永远清不掉、用户看到「报 10.6GB 实际只释放 3.3GB」。
    v1.7.83 改为：rd 整目录先删（实测 134 文件/秒，快 2.1 倍）→ 没删干净才用 WinAPI 扫尾。
    rd 的可靠性风险由 _rd_fast_delete 的实地判定兜住，判不干净就退回报 WinAPI，
    绝不会「以为删了其实没删」。

    流程：
      0. rd /s /q 整目录删除（快路径），确认删干净就收工
      1. 单次 os.walk 收集 文件+目录 清单
      2. 32 线程并行 DeleteFileW 删文件（扫尾/回退路径）
      3. 目录按深度倒序 RemoveDirectoryW（含根目录）
      4. 删不掉的返回 residual → 走重启删除兜底（保证"扫描出来的都能清"）
    """
    import ctypes
    root = _lp(path)
    if not os.path.isdir(root):
        return []

    # --- Phase 0: rd 快路径（本机实测快 2.1 倍，海量小文件的决定性提速点）---
    # 时限给足：57618 文件按 134 文件/秒需 ~430 秒，180 秒会再次删不完。
    #
    # v1.7.83 真机验收补充（2026-10-04 19:40 真实跑 uv\cache 57618 文件）：
    # 在**真实用户目录**里，rd 速率会掉到 17-30 文件/秒（测试目录是新建空目录，
    # 杀软没有现成的扫描缓存；真实缓存目录每个文件都要被杀软实时扫一遍），
    # 57618 文件实测需 30+ 分钟，远超任何合理时限。
    # → 因此 rd 超时后**不能就此收工**（那正是 v1.7.82 之前的病根）：
    #   Phase 2 的 WinAPI 扫尾必须拿到与 rd 同量级的时限（_tail_sec），
    #   否则只是把"删不完"从 rd 挪到 WinAPI。两条路都给足时间，才真正删得掉。
    _rd_timeout = max(120, int(max_sec * 0.6))
    if _rd_fast_delete(path, timeout=_rd_timeout):
        if on_progress:
            try:
                on_progress(1, 1, 0)
            except Exception:
                pass
        return []
    # rd 没删干净（或超时）→ WinAPI 扫尾。剩余时限单独给足，不与 rd 共享 max_sec。
    _tail_sec = max(max_sec, 900)
    deadline = _time.time() + _tail_sec
    k32 = ctypes.windll.kernel32

    # --- Phase 1: 收集清单（单次 walk）---
    files, dirs = [], []
    try:
        for dp, dn, fn in os.walk(_lp(path)):
            for f in fn:
                files.append(os.path.join(dp, f))
            for d in dn:
                dirs.append(os.path.join(dp, d))
    except Exception:
        pass
    total_files = max(1, len(files))
    files_done = 0
    last_emit = 0.0

    def _emit():
        nonlocal last_emit
        now = _time.time()
        if now - last_emit < 0.25:
            return
        last_emit = now
        try:
            if on_progress:
                on_progress(files_done, total_files, 0)
        except Exception:
            pass

    # --- Phase 2: 并行 DeleteFileW（环境无关快路径）---
    import concurrent.futures as _cf
    residual = []
    _del_files = [fp for fp in files if _time.time() <= deadline]

    # v1.7.34（P0 提速）：线程数从固定 8 → 动态 min(32, max(8, cpu*2))。
    # 逐文件 DeleteFileW 是「一次 syscall 删一文件」，吞吐受并发线程数限制。
    # 多核机（8/12/16 核）上固定 8 线程远未吃满 IO 并发，SSD/缓存目录海量小文件
    # 时是最大减速点。动态调大线程数（与 _parallel_delete_tree 一致口径）可数倍
    # 提升小文件删除吞吐。纯 WinAPI、环境无关，不会重蹈 rd 快路径不稳定
    # 或卡满 timeout 的坑（v1.7.12 教训）。低核机仍有 8 线程保底。
    _nw = min(32, max(8, (os.cpu_count() or 4) * 2))

    def _del_one(fp):
        try:
            if k32.DeleteFileW(_lp(fp)):
                return True
        except Exception:
            pass
        return False

    if _del_files:
        try:
            with _cf.ThreadPoolExecutor(max_workers=_nw) as _ex:
                _results = list(_ex.map(_del_one, _del_files))
        except Exception:
            _results = [False] * len(_del_files)
        for fp, ok in zip(_del_files, _results):
            if ok:
                files_done += 1
                _emit()
            else:
                residual.append(fp)
    # 超过截止时间未处理的文件 → 残留（重启删兜底）
    for fp in files[len(_del_files):]:
        residual.append(fp)

    # --- Phase 3: 清掉空目录（深度倒序）---
    for dp in sorted(dirs, key=lambda p: p.count(os.sep), reverse=True):
        if _time.time() > deadline:
            break
        try:
            k32.RemoveDirectoryW(_lp(dp))
        except Exception:
            pass
    try:
        k32.RemoveDirectoryW(root)
    except Exception:
        pass
    _emit()
    return residual


def _get_current_sid():
    """获取当前用户 SID（回收站目录名）。v1.7.25 新增。"""
    try:
        # v1.7.34（黑框修复）：whoami 是控制台程序，capture_output=True 只接管 stdio、
        # 不抑制控制台窗口本身。回收站清空流程调用本函数，此前会闪黑框。
        # 补 creationflags=CREATE_NO_WINDOW 彻底静默。
        r = subprocess.run(["whoami", "/user"], capture_output=True, timeout=15,
                           creationflags=CREATE_NO_WINDOW)
        out = r.stdout.decode("gbk", "ignore")
        for line in out.splitlines():
            for part in line.split():
                if part.startswith("S-1-"):
                    return part.strip()
    except Exception:
        pass
    return None


def _is_nuke_on_delete(drive="C"):
    """检查用户是否设置「立即删除不送回收站」（注册表 NukeOnDelete=1）。
    若是，rename 进回收站后 SHEmptyRecycleBinW 行为不确定 → 调用方降级走后台删。
    外部团队方案 v2.0 补充（2026-08-03）。"""
    try:
        import ctypes as _ct
        import winreg
        _k = _ct.windll.kernel32
        buf = _ct.create_unicode_buffer(50)
        if not _k.GetVolumeNameForVolumeMountPointW(drive + ":\\", buf, 50):
            return False
        vol = buf.value
        guid = vol.replace("\\\\?\\Volume{", "").replace("}\\", "").lower()
        key = (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer"
               r"\BitBucket\Volume\{" + guid + "}")
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as k:
            val, _ = winreg.QueryValueEx(k, "NukeOnDelete")
            return val == 1
    except Exception:
        return False


def _long_path(path):
    """长路径 \\?\\ 前缀（MoveFileExW 对 >260 字符路径失败时的防御）。"""
    p = os.path.abspath(path)
    if len(p) > 230 and not p.startswith("\\\\?\\"):
        return "\\\\?\\" + p
    return p


def recycle_bin_fast_purge(paths, on_progress=None, empty_full_bin=True):
    """v1.7.25/26 黄金组合：目录 rename 进回收站 + 标准 $I + SHEmptyRecycleBinW 清空。

    破局原理（本机 360+火绒共存实测 2026-08-03）：
      - MoveFileExW rename 目录进 $Recycle.Bin\\<SID>\\$R<rand> = 0.003s（元数据操作，
        常见安全软件共存下实测稳定——360 主防 zhudongfangyu + 火绒 wsctrl 共存实测）；
      - 写配套 $I<rand> 元数据（Win8+ 格式 header=02）= 0.9ms；
      - SHEmptyRecycleBinW 清空回收站 = 杀软放行的官方批量通道（11.7GB 秒清实测；
        小文件 2-3ms/个，真实机器比 DeleteFileW 被杀软逐文件扫快 10-30 倍）。
      端到端实测：3 万小文件 + 1.5GB 大文件 + 回收站 960MB = 12.7s 清完（360+火绒共存）。

    内容级回退：目录整体 rename 失败（被占用，如 Temp）→ 目录下每个子项逐个 rename
    进回收站（2ms/项，无需 $I 也能被 SHEmptyRecycleBinW 清空）→ 解决 Temp 类大目录。

    empty_full_bin=True：SHEmptyRecycleBinW 全清（用户勾选「清空回收站」时——缓存进
    回收站 + 用户回收站一起清，行为自洽）。
    empty_full_bin=False：精确删除——只后台删自己搬进的 $R 条目，**不碰用户回收站**
    （用户未勾选「清空回收站」时也能享受 rename 秒级感知，物理释放后台进行）。

    返回 (ok_count, failed_paths)
    """
    import ctypes
    import random
    import string
    import struct
    kernel32 = ctypes.windll.kernel32
    shell32 = ctypes.windll.shell32
    # v1.7.28：按路径所在盘符处理（此前硬编码 C 盘——D 盘大目录清理/跨盘场景会失败）。
    # 回收站路径 = <盘符>\$Recycle.Bin\<SID>；SHEmptyRecycleBinW 也按盘符清。
    # v1.7.34（弹窗根因·统一入口）：支持空 paths 调用（paths=[] 表示"只清整盘回收站"，由
    # server.py:empty_recycle_bin 走统一 WinAPI 入口时传入），此时盘符回退到 SystemDrive。
    try:
        if paths:
            _drive = os.path.splitdrive(os.path.abspath(paths[0]))[0] or "C:"
        else:
            _drive = os.environ.get("SystemDrive", "C:") or "C:"
    except Exception:
        _drive = "C:"
    _drive = _drive.rstrip("\\/") + "\\"
    # NukeOnDelete 防护：用户关闭了回收站 → 降级（调用方走现有后台删）
    if _is_nuke_on_delete(_drive[0]):
        return 0, list(paths)
    sid = _get_current_sid()
    rb_dir = os.path.join(_drive, "$Recycle.Bin", sid) if sid else ""
    if not rb_dir or not os.path.isdir(rb_dir):
        return 0, list(paths)
    ok = 0
    failed = []
    moved_r = []  # 搬进回收站的 $R 路径（精确删除用）
    for i, p in enumerate(paths):
        try:
            p_abs = _long_path(p)
            if not os.path.exists(p_abs):
                ok += 1  # 已不存在视为成功
                continue
            # 先尝试整体 rename（0.003s）；失败（目录被占用，如 Temp）→ 内容级回退：
            # 把目录下每个子项（文件/子目录）逐个 rename 进回收站（文件级元数据操作，
            # 杀软同样不拦）。v1.7.26：整体 rename 必须写 $I（SHEmptyRecycleBinW 对无 $I
            # 的大目录条目会静默跳过——本机实测 32GB 无 $I 条目未被清空的铁证）。
            rand = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
            r_path = os.path.join(rb_dir, "$R" + rand)
            i_path = os.path.join(rb_dir, "$I" + rand)
            moved_ok = kernel32.MoveFileExW(_long_path(p_abs), _long_path(r_path), 0x1)
            if moved_ok:
                # 写标准 $I（Win8+ header=02；header 用 01 会导致 SHEmptyRecycleBinW 崩溃）
                try:
                    _sz = 0 if os.path.isdir(p_abs) else os.path.getsize(p_abs)
                    ft = ctypes.c_ulonglong(0)
                    kernel32.GetSystemTimeAsFileTime(ctypes.byref(ft))
                    _pu = os.path.abspath(p) + "\x00"
                    _id = b"\x02\x00\x00\x00\x00\x00\x00\x00"
                    _id += struct.pack("<Q", _sz)
                    _id += struct.pack("<Q", ft.value)
                    _id += struct.pack("<I", len(_pu))
                    _id += _pu.encode("utf-16-le")
                    with open(_long_path(i_path), "wb") as f:
                        f.write(_id)
                except Exception:
                    pass
                moved_r.append(r_path)
                ok += 1
                continue
            # 整体 rename 失败（被占用）→ 内容级逐个搬
            # v1.7.26：内容级子项 rename 后**同样写 $I**——SHEmptyRecycleBinW 对无 $I 的
            # $R 条目会静默跳过。v1.7.49（P0 修复）：原实现单线程逐文件 rename + 写 $I，
            # 数万文件串行 = 数分钟（用户实测 10 分钟卡死的主因之一）。改为 ThreadPoolExecutor
            # 并行（8~32 线程），同样的活从分钟级降到秒级。
            if not os.path.isdir(p_abs):
                failed.append(p)
                continue
            try:
                _children = os.listdir(p_abs)
            except Exception:
                _children = []
            _total = len(_children)
            if _total == 0:
                # 空目录：直接删源（rmdir 元数据操作，极快，无需进回收站）
                try:
                    kernel32.RemoveDirectoryW(_long_path(p_abs))
                    ok += 1
                    continue
                except Exception:
                    failed.append(p)
                    continue
            _moved = [0]
            _mr_lock = threading.Lock()
            def _move_child(_name):
                try:
                    _sub = os.path.join(p_abs, _name)
                    _rand2 = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
                    _r2 = os.path.join(rb_dir, "$R" + _rand2)
                    if kernel32.MoveFileExW(_long_path(_sub), _long_path(_r2), 0x1):
                        try:
                            _i2 = os.path.join(rb_dir, "$I" + _rand2)
                            _sz2 = 0 if os.path.isdir(_sub) else os.path.getsize(_sub)
                            ft2 = ctypes.c_ulonglong(0)
                            kernel32.GetSystemTimeAsFileTime(ctypes.byref(ft2))
                            _pu2 = os.path.abspath(_sub) + "\x00"
                            _id2 = b"\x02\x00\x00\x00\x00\x00\x00\x00"
                            _id2 += struct.pack("<Q", _sz2)
                            _id2 += struct.pack("<Q", ft2.value)
                            _id2 += struct.pack("<I", len(_pu2))
                            _id2 += _pu2.encode("utf-16-le")
                            with open(_long_path(_i2), "wb") as f:
                                f.write(_id2)
                        except Exception:
                            pass
                        with _mr_lock:
                            _moved[0] += 1
                            moved_r.append(_r2)
                        return True
                except Exception:
                    pass
                return False
            _nw = min(32, max(8, (os.cpu_count() or 4) * 2))
            try:
                with ThreadPoolExecutor(max_workers=_nw) as _cex:
                    list(_cex.map(_move_child, _children))
            except Exception:
                pass
            _moved_n = _moved[0]
            if _total > 0 and _moved_n >= max(1, int(_total * 0.9)):
                ok += 1  # ≥90% 子项搬走 = 内容基本清空
            elif _moved_n > 0:
                ok += 1  # 部分搬走也算成功（剩余由 server 回退后台删）
                if _total - _moved_n > 0:
                    failed.append(p)
            else:
                failed.append(p)
        except Exception:
            failed.append(p)
        if on_progress:
            try:
                on_progress(i + 1, len(paths), 0)
            except Exception:
                pass
    if empty_full_bin:
        # v1.7.34（P0 修复）：彻底抛弃 SHEmptyRecycleBinW，改用 WinAPI 后台线程直接清理
        # 回收站整盘的 $R* + $I* —— 根除「找不到项目」系统对话框弹窗，让小白用户无感知。
        #
        # 旧方案（v1.7.27~v1.7.33）痛点：SHEmptyRecycleBinW 即使传 SHERB_NOCONFIRMATION
        # | SHERB_NOPROGRESSUI | SHERB_NOSOUND + SetErrorMode(SEM_FAILCRITICALERRORS)，
        # 在某些场景（被锁的 0 字节 $R 条目 / 用户回收站含杀软放行的可疑文件）仍会被
        # explorer.exe 弹出「找不到项目」资源管理器对话框（图：$R0FGD53.bin, 0 字节,
        # C:\$Recycle.Bin\S-1-5-21-…）。该弹窗由资源管理器（非 SHEmpty 自身）触发，
        # SHERB_* flags 无法抑制；SetErrorMode(SEM_FAILCRITICALERRORS) 也只覆盖关键错误，
        # 不覆盖资源管理器对话。对小白用户而言「清理时突然弹个系统对话框」= 不安全感 +
        # 误以为程序出错。
        #
        # 新方案：后台线程用纯 WinAPI（DeleteFileW / RemoveDirectoryW，多线程由
        # _fast_delete_dir 提供，v1.7.34 已升级到动态 32 线程）直接遍历清理：
        #   1) 本次搬进的所有 $R（moved_r 列表）
        #   2) 回收站整盘所有遗留 $R* 与 $I*（保留用户 SID 目录与回收站根结构）
        # → 等价「整盘清空回收站」语义（用户勾选清空回收站时），但：
        #   · 纯 WinAPI 调用，环境无关（沙箱/杀软/资源管理器都不会弹任何对话框）
        #   · 32 线程并行（SSD 上速度与 SHEmpty 同档甚至更快）
        #   · 与精确删除路径（empty_full_bin=False）同口径，行为一致、代码一致
        # 副作用：用户回收站原有的非本次搬入条目也会被清掉（符合 SHEmptyRecycleBinW 原语义）。
        def _do_empty():
            try:
                # 收集整盘回收站所有 $R* 和 $I* 条目（一次性扫描，避免遍历期间新文件干扰）
                _r_all = []
                _i_all = []
                try:
                    if os.path.isdir(rb_dir):
                        for _n in os.listdir(rb_dir):
                            if _n.startswith("$R") and len(_n) > 2:
                                _r_all.append(os.path.join(rb_dir, _n))
                            elif _n.startswith("$I") and len(_n) > 2:
                                _i_all.append(os.path.join(rb_dir, _n))
                except Exception:
                    pass
                # 把本次搬进的也合并进去（moved_r 已经包含在 _r_all 扫描里，但保险起见）
                for _r in moved_r:
                    if _r not in _r_all:
                        _r_all.append(_r)
                # 先删所有 $R*（实际数据条目，体积大、可能含锁文件）
                # 用 _fast_delete_dir 多线程 WinAPI 环境无关删。
                # v1.7.34（铁律2·可清性补漏）：此前 _fast_delete_dir 返回的 residual
                # （被进程/杀软锁住的残留文件）被丢弃，导致删不掉的 $R 永久占空间、
                # 磁盘实测 freed 系统性偏低（回归实测残留 42 个 $R / 0.27GB）。
                # 现将 residual 与删不掉的 $R 条目统一登记「重启自动删」兜底，
                # 保证「扫描出来的缓存最终都能删掉」——重启后由系统清理真正释放。
                for _rp in _r_all:
                    try:
                        _p = _long_path(_rp)
                        _resid = []
                        if os.path.isfile(_p) or os.path.islink(_p):
                            try:
                                kernel32.DeleteFileW(_p)
                            except Exception:
                                _win_delete(_p)
                            if os.path.exists(_p):
                                _resid = [_p]
                        else:
                            _resid = _fast_delete_dir(_p, max_sec=600) or []
                        if _resid:
                            try:
                                _schedule_reboot_delete_batch(_resid)
                            except Exception:
                                pass
                    except Exception:
                        pass
                # 再删所有 $I*（元数据文件，删除 $R 后即孤儿，体积小但占 inode / 目录项）
                # 用并行 DeleteFileW，32 线程动态（与 _fast_delete_dir 同口径）。
                import concurrent.futures as _cf_ex
                _i_paths = [_long_path(x) for x in _i_all]
                if _i_paths:
                    def _del_i(_ip):
                        try:
                            return bool(kernel32.DeleteFileW(_ip))
                        except Exception:
                            return False
                    try:
                        _nw = min(32, max(8, (os.cpu_count() or 4) * 2))
                        with _cf_ex.ThreadPoolExecutor(max_workers=_nw) as _iex:
                            list(_iex.map(_del_i, _i_paths))
                    except Exception:
                        pass
            except Exception:
                pass
        try:
            import threading as _th2
            _et = _th2.Thread(target=_do_empty, daemon=True)
            with _EMPTY_LOCK:
                _EMPTY_THREADS.append(_et)
            _et.start()
        except Exception:
            # 线程创建失败（极端）→ 同步兜底执行，保证不丢释放
            _do_empty()
    elif moved_r:
        # 精确删除：后台删自己搬进的 $R，不碰用户回收站；同时记到清单供下次登录兜底定点删。
        try:
            _record_recycle_entries(moved_r)
        except Exception:
            pass
        # 【codex 副本 v1.7.29-candidate 修正】两处：
        # 1) 用 _fast_delete_dir（WinAPI 8 线程并行）替代 shutil.rmtree——逐文件删除
        #    被杀软逐文件扫拖慢，并行能显著提速物理释放（同时回应 P1-3 精确删源提速）；
        # 2) 线程登记进 _PURGE_THREADS——否则 server 校准线程 wait_purge 等不到它，
        #    过早测磁盘 freed 会低估甚至不更新（P0-1 弹窗数字校准失效），必须等待。
        def _bg_precise():
            try:
                for _rp in moved_r:
                    try:
                        _p = _long_path(_rp)
                        # v1.7.29-candidate：精确删源必须区分 文件/目录。
                        # _fast_delete_dir 对文件直接 return []（os.path.isdir 不成立），
                        # 导致迁移删源（mp4 等文件型 $R）永久残留回收站、C 盘空间不释放
                        # （第一轮回归实测 ~2GB $R 残留的铁证）。文件/软链走 DeleteFileW。
                        if os.path.isfile(_p) or os.path.islink(_p):
                            try:
                                kernel32.DeleteFileW(_p)
                            except Exception:
                                _win_delete(_p)
                            _resid = []
                        else:
                            _resid = _fast_delete_dir(_p, max_sec=300)
                        for _r2 in (_resid or []):
                            # v1.7.100（真实释放铁律）：残留项走 _win_delete 而非
                            #   shutil.rmtree —— 后者会被运行环境安全删除层重定向到
                            #   C 盘回收站（占盘不释放），并可能撞批量删除闸被杀线程。
                            try:
                                _win_delete(_long_path(_r2))
                            except Exception:
                                pass
                    except Exception:
                        try:
                            _win_delete(_long_path(_rp))
                        except Exception:
                            pass
            except Exception:
                pass
        try:
            import threading as _th3
            _pt = _th3.Thread(target=_bg_precise, daemon=True)
            with _PURGE_LOCK:
                _PURGE_THREADS.append(_pt)
            _pt.start()
        except Exception:
            pass
    return ok, failed


# ---- v1.7.94：后台清理 .bak，绝不阻塞迁移主链路----
_BG_PURGE_THREADS = []


def _bg_purge(path):
    """后台删除一个目录（如迁移后的 .bak 残留），立刻返回。

    ★ 为什么必须有这个（实测）：
      迁移的成败判据是「D 盘副本已校验 + junction 已建」，不是「.bak 删干净」。
      .bak 删不掉本来就有兜底（登记重启自动删），所以删除卡住/被拦时
      **绝不能让用户看到「迁移卡住了」** —— 实测单跑 0.08GB 的子目录迁移，
      删除动作撞上运行环境的批量删除确认闸，整个迁移卡了 4 分 49 秒。

      删除失败只是「这轮没删干净」，如实报残留量，下轮继续，绝不假装成功。
    """
    import threading as _th_bp
    try:
        if not path or not os.path.exists(path):
            return
    except Exception:
        return

    def _w():
        try:
            fast_purge(path)
        except Exception:
            # 删不掉就登记重启自动删（已有兜底），绝不抛出去
            try:
                _schedule_reboot_delete(path)
            except Exception:
                pass

    try:
        t = _th_bp.Thread(target=_w, daemon=True)
        try:
            with _PURGE_LOCK:
                _BG_PURGE_THREADS.append(t)
        except Exception:
            pass
        t.start()
    except Exception:
        # 连线程都起不来就直接登记重启删
        try:
            _schedule_reboot_delete(path)
        except Exception:
            pass


def fast_purge(path, on_progress=None, size_kb=0):
    """v1.7.8: fast delete with lock-probe-first strategy.

    File/symlink: DeleteFileW directly.
    Directory: sample first 200 files for lock ratio.
      - If >50% locked: skip rename entirely, schedule reboot delete + return residual.
      - Otherwise: rename to staging area, then _fast_delete_dir (which also probes).
    Returns list of residual file paths (for Q1 reboot auto-clean).

    v1.7.24（弹窗秒出）：大目录（>=200MB，server 传入 size_kb）rename 成功后**异步**
    删暂存区——提交秒级返回，done/弹窗不被后台删除拖住；残留由线程内登记重启删，
    server 磁盘实测校准兜底数字。小目录仍同步（秒级、返回真实残留供弹窗展示未清理项）。
    """
    if os.path.islink(path):
        try:
            _win_delete(path)
        except OSError:
            raise
        if on_progress:
            try:
                on_progress(1, 1, 0)
            except Exception:
                pass
        return []
    if os.path.isfile(path):
        try:
            _win_delete(path)
        except OSError:
            raise
        if on_progress:
            try:
                on_progress(1, 1, 0)
            except Exception:
                pass
        return []
    if not os.path.isdir(path):
        return []

    # v1.7.24：移除「锁采样 200 文件探测」——它在本机 server 进程沙箱下逐个 open 探测
    # 被拖到 120s+/项（7 项并行也全卡同一时刻 → done 迟到 → 弹窗不出现）。且它是冗余防御：
    #   · rename 失败 → _empty_dir_contents 清空内容（残留登记重启删）
    #   · rename 成功 → _fast_delete_dir 内部有锁探测 + 重启删兜底
    # 两条路径都有「被占用文件 → 重启删」兜底，采样提前判锁收益极小、代价巨大，直接去掉。

    stage = _purge_stage()

    # ★ v1.7.95 P0：待删目录和暂存区不在同一个盘 → **就地删，绝不跨卷搬**。
    #   暂存区在 C 盘（C:\aipc_purge），待删目录常常在 D/E 盘（迁移垃圾就是）。
    #   跨卷 rename 不是原子改名，而是「整棵树复制过去再删源」：
    #     · 34GB 复制，慢到不可用；
    #     · 更要命的是 C 盘正是我们要腾空的那个盘，往里塞几十 GB 完全是反向操作。
    #   实测：D 盘 34.35GB 迁移垃圾走这条路径，7 项 rename 全部失败 →
    #   落回 _empty_dir_contents 兜底 → 而兜底当时因 max_sec 未定义整个失效 →
    #   代码对外报「已清理 34.35GB」，磁盘一个字节都没少。
    #   现在：不同盘就地删，一步都不搬。
    _sd_src = os.path.splitdrive(os.path.abspath(path))[0].upper()
    _sd_stg = os.path.splitdrive(os.path.abspath(stage))[0].upper()
    if _sd_src and _sd_stg and _sd_src != _sd_stg:
        residual = _empty_dir_contents(path, on_progress=on_progress,
                                       wait=True, max_sec=1800)
        # rd 成功时根目录已被连带删掉；没成功则内容已清空、把空壳也收掉
        # v1.7.100：_win_delete 代替 os.rmdir（被安全删除层拦进回收站则空壳留原位）
        try:
            if os.path.isdir(path):
                _win_delete(path)
        except Exception:
            pass
        if on_progress:
            try:
                on_progress(1, 1, 0)
            except Exception:
                pass
        return residual

    stem = (os.path.basename(os.path.normpath(path)) or "del")[:60]
    dst = os.path.join(stage, "p_%d_%d_%s" % (os.getpid(), int(_time.time() * 1000), stem))
    while os.path.exists(dst):
        dst += "_"
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
    except Exception:
        pass

    try:
        _win_move(path, dst)
    except OSError:
        # v1.7.20（目标机双杀软实测）：rename 可能被 360/火绒实时防护首次拦截（判定可疑行为），
        # 但重试往往放行（同卷原子改名对杀软是"一次性元数据操作"）。重试 2 次最大化走 rename 快路径。
        _rename_ok = False
        for _i in range(2):
            _time.sleep(0.6)
            try:
                _win_move(path, dst)
                _rename_ok = True
                break
            except OSError:
                continue
        if not _rename_ok:
            # v1.7.23（生产审计 P0 修复）：rename 失败常见于 Temp 等系统共享目录
            # （被进程当 cwd/持句柄，永远无法改名）。v1.7.21 的"整目录登记重启删"在
            # 这类目录上 = 重启前清不掉、重启后系统还要重建 Temp，用户永远看不到效果，
            # 且 server 拿"代表样本"当残留核算释放量 → 虚报。改为**直接清空内容**
            # （保留根目录：内容锁 0% 的缓存可秒删，rd /s /q 批量），残留（真正被占用）
            # 精确返回，由 server 登记重启删 + 磁盘实测核算，数字诚实。
            residual = _empty_dir_contents(path, on_progress=on_progress)
            if on_progress:
                try:
                    on_progress(1, 1, 0)
                except Exception:
                    pass
            return residual

    # v1.7.24：大目录（>=200MB）异步删暂存区——rename 提交即返回，done/弹窗不被后台
    # 删除拖住（此前 24 项同步逐文件删被拖到 300s+，弹窗永远等不到）。残留由线程内
    # 登记重启删，数字由 server 磁盘实测校准兜底；小目录同步（秒级、返回真实残留）。
    residual = []
    _ASYNC_KB = 200 * 1024  # 200MB 以上走异步提交
    if size_kb >= _ASYNC_KB:
        # v1.7.34（P0 提速）：异步大目录删除的物理释放时限从 120s 提到 180s。
        # v1.7.83（实测根因修复）：180s 在「海量小文件」上根本不够 ——
        # `uv\cache` 实测 57618 个文件 / 2400MB，按 v1.7.24 的 64 文件/秒需 15 分钟，
        # 180 秒只能删掉约 1.1 万个 → **剩下 4.6 万个 / 约 2.4GB 永远清不掉**，
        # 这正是「报告说一键清 10.6GB、实测只释放 3.3GB」的真凶。
        # 现改为 600s：v1.7.83 引入 rd 快路径后吞吐提到 134 文件/秒（本机实测三轮零残留），
        # 57618 文件约需 430 秒，600 秒留足余量。这是【后台线程】的时限，
        # 不阻塞弹窗、不阻塞 done，用户体感不变，只是后台多干一会儿就能真删干净。
        def _bg_rm_stage():
            try:
                _r = _fast_delete_dir(dst, max_sec=600)
                if _r:
                    try:
                        _schedule_reboot_delete_batch(_r)
                    except Exception:
                        pass
            except Exception:
                pass
        try:
            import threading as _th2
            _t = _th2.Thread(target=_bg_rm_stage, daemon=True)
            with _PURGE_LOCK:
                _PURGE_THREADS.append(_t)
            _t.start()
            # v1.7.54（P0 修复）：暂存区残留兜底。v1.7.82 起不再注册计划任务，改为立即就地清扫
            # （工具启动时 auto_cleanup_orphan_baks 还会再清扫一遍，覆盖进程退出/重启场景）。
            try:
                _run_purge_stage_cleanup()
            except Exception:
                pass
        except Exception:
            residual = _fast_delete_dir(dst, on_progress=on_progress, max_sec=90)
            if os.path.exists(dst):
                try:
                    _schedule_reboot_delete(dst)
                except Exception:
                    pass
    else:
        residual = _fast_delete_dir(dst, on_progress=on_progress, max_sec=90)
        if os.path.exists(dst):
            try:
                _schedule_reboot_delete(dst)
            except Exception:
                pass
    if on_progress:
        try:
            on_progress(1, 1, 0)
        except Exception:
            pass
    return residual


# --------------------------------------------------------------------------
# v1.7.38（清理迁移残留）：旧迁移「删源释放」失败留下的 .migrated.bak 冗余副本。
# 它由迁移工具负责清理（junction 已建、目标盘有完整副本），不应让用户手动去找。
# 安全前提：仅接受「*.migrated.bak」且其对应无后缀路径是 junction（证明已迁移成功、
# 目标盘有副本）——绝不碰未完成迁移或非残留目录。清理走 fast_purge（含重启删兜底）。
# --------------------------------------------------------------------------
def _is_safe_migrated_bak(path):
    """校验 .migrated.bak 是否可安全删。
    安全条件：路径以 .migrated.bak 结尾，且对应无后缀原路径是 junction（reparse point），
    证明该迁移项已建联接、目标盘有完整副本，删源释放 C 盘零风险。
    返回 (ok_safe, reason)。"""
    p = os.path.normpath(path or "")
    pl = p.lower()
    if not pl.endswith(".migrated.bak"):
        return False, "不是迁移残留（需以 .migrated.bak 结尾）"
    base = p[:-len(".migrated.bak")]
    if not os.path.isdir(p):
        return False, "残留目录不存在"
    try:
        st = os.lstat(base)
        if getattr(st, "st_file_attributes", 0) & 0x400:  # REPARSE_POINT = junction/mount point
            return True, "已迁移（联接在，目标盘有副本）"
    except OSError:
        pass
    return False, "原路径不是迁移联接，可能未完成迁移，为安全不清理"


# v1.7.45（诊断透明化）：抽出 bak 残留的完整判定（safe_to_delete + why），
# 给 server._scan_bak_residuals（端点 mode=scan / mode=execute 用）和
# analyze.py（报告页卡片展示用）共用，保证报告卡片与清理弹窗的判定口径一致。
#
# why 取值（前端按此翻译为白话）：
#   - ""              = safe，可自动删（仅当通过 junction + dst 存在 + 副本完整三道关）
#   - junction_broken = 原路径已不是 junction（可能被系统清理 / 手动删 / 杀软误删），
#                       工具无法验证目标盘副本在哪
#   - dst_missing     = junction 在但目标盘副本所在路径已不存在（D 盘换盘 / 目录被删）
#   - dst_mismatch    = 目标盘副本与残留比对，有文件缺失或大小不一致（数据不完整）
#   - dst_unreadable  = junction 在但 readlink 失败 / 目标盘读取失败（网络盘掉线等）
def classify_bak_residual(bak_path, check_files=True, dst=None, src_is_junction=None):
    """判定 .migrated.bak 是否可安全自动删。返回 (safe:bool, why:str, src, dst)。

    参数：
      bak_path         待判定的 .migrated.bak 路径
      check_files      是否做文件级 missing 比对（True=精确，慢；False=仅基础判定，快）
      dst/src_is_junction
                       已知的 dst / src_is_junction（从外层扫描传入，避免 lstat 重复调用）

    返回：
      (safe, why, src, dst)
      - safe=True 时 why 为空字符串
      - safe=False 时 why 为上述枚举之一
    """
    bak = os.path.normpath(bak_path or "")
    if not bak.lower().endswith(".migrated.bak"):
        return (False, "not_bak", "", "")
    src = bak[:-len(".migrated.bak")]
    # 1) 拿 src 的 junction 状态 + dst（外层已传入则跳过 lstat）
    if dst is None or src_is_junction is None:
        dst = ""
        src_is_junction = False
        try:
            st = os.lstat(src)
            src_is_junction = bool(getattr(st, "st_file_attributes", 0) & 0x400) or os.path.islink(src)
            if src_is_junction:
                dst = os.readlink(src)
        except Exception:
            dst = ""
    # 2) 分级判定
    if not dst:
        if not src_is_junction:
            return (False, "junction_broken", src, "")
        return (False, "dst_unreadable", src, "")
    if not os.path.exists(dst):
        return (False, "dst_missing", src, dst)
    # 3) 文件级缺失比对（精确但慢，server 清理时用；analyze 仅做基础判定时可关掉）
    if check_files:
        missing = 0
        try:
            for dp, dn, fn in os.walk(bak):
                for fl in fn:
                    sf = os.path.join(dp, fl)
                    rel = os.path.relpath(sf, bak)
                    tf = os.path.join(dst, rel)
                    try:
                        if not (os.path.exists(tf) and os.path.getsize(tf) == os.path.getsize(sf)):
                            missing += 1
                    except Exception:
                        missing += 1
        except Exception:
            pass
        if missing > 0:
            return (False, "dst_mismatch", src, dst)
    return (True, "", src, dst)


def probe_purgable(path, sample=40):
    r"""v1.7.85（老李「报告说清得了、实际清不掉」根因③）：清理【前】预检这个目录能不能删。

    返回 (purgable: bool, reason: str, locked_ratio: float)
    用途：analyze 出报告时先跑一遍，把「真能删的量」与「只能等重启的量」分开，
    报告只承诺前者 —— 绝不能一边承诺 4.3GB、一边交付 0.06GB。

    ===== 判据（v1.7.85 三次打脸后定稿，与 fast_purge 的真实路径严格对齐）=====
    fast_purge 有两条真路：
      A. 整目录 rename 进暂存区/回收站（快，0.003s）—— 只需**目录本身**没被独占
      B. 目录 rename 失败 → _empty_dir_contents 逐个删文件（慢）—— 只需**文件**没被独占
    所以「删不掉」的唯一定义是：**A 和 B 两条路都走不通**。实测（本机，2026-10-04）：
      目录            整目录rename  文件级rename    结论
      Temp(40190 文件)   拒绝访问     1/5 成功        两条都不通 → 确实删不掉
      Edge ShaderCache   拒绝访问     5/5 成功        B 通 → **能删干净**（5 个文件而已）
      我自建的 Temp/x    成功         —              A 通 → 秒删
    ⇒ 只看「文件锁定率」会误杀（ShaderCache 被误判成删不掉）；
       只看「整目录 rename」也会误杀（Temp 明明能靠 B 删一部分）。
    正确判据 = 先试 A（整目录 rename，探完还原）；A 不通再看 B 的可行性。

    采样说明：A 一次 rename 探测耗时 < 20ms，B 抽样 40 个文件 < 300ms/项，
    绿区 30~60 项合计 < 20 秒 —— 换来「报告数字不再骗人」非常值。
    """
    root = os.path.abspath(path)
    if not os.path.isdir(root):
        return False, "目录已不存在（可能已被其他程序清理）", 0.0

    # ===== 路线 A：整目录 rename 探测（探完立刻还原，零副作用）=====
    _A_ok = False
    _tmp = os.path.join(os.path.dirname(root),
                        os.path.basename(root) + ".__aipc_probe_tmp")
    try:
        if not os.path.exists(_tmp):
            os.rename(root, _tmp)
            _A_ok = True
            try:
                os.rename(_tmp, root)      # 还原，探测必须无痕
            except OSError:
                _A_ok = False
                # 还原失败必须如实报，绝不把目录丢在 __aipc_probe_tmp 名下
                return False, "目录改名探测后未能还原，请勿清理此目录（需人工确认）", 0.0
    except OSError:
        _A_ok = False                     # A 不通，走 B

    if _A_ok:
        # 整目录能搬走 = fast_purge 主路径通畅 = 秒删，必然「真能删」
        return True, "", 0.0

    # ===== 路线 B：目录搬不动，逐个文件能不能删（这才是真正决定「能删多少」）=====
    locked = total = 0
    try:
        for dp, _dn, fn in os.walk(root):
            for f in fn:
                if total >= sample:
                    break
                fp = os.path.join(dp, f)
                total += 1
                tmp = fp + ".__aipc_probe_tmp"
                try:
                    os.rename(fp, tmp)
                    os.rename(tmp, fp)      # 改回原名，探测必须无痕
                except OSError:
                    locked += 1
                    try:
                        if os.path.exists(tmp) and not os.path.exists(fp):
                            os.rename(tmp, fp)
                    except Exception:
                        pass
            if total >= sample:
                break
    except Exception:
        return True, "", 0.0

    ratio = (locked / float(total)) if total else 0.0
    low = root.lower()
    for _p in ("\\windows\\temp", "\\program files", "\\program files (x86)",
               "\\system32", "\\aipc_purge"):
        if low.endswith(_p) or _p + "\\" in low + "\\":
            return False, "Windows 系统保护目录，需要管理员权限才能删", ratio

    if total == 0:
        # 一个文件都没有：要么是空目录（删得掉），要么全被占用（删不掉）。
        # 空目录直接判能删（fast_purge 会 rmdir 掉），否则按删不掉处理。
        return True, "", 0.0
    if ratio >= 0.30:
        return False, ("正被程序占用（抽样 %d/%d 个删不掉），"
                       "关掉这些软件或重启电脑才能删" % (locked, total)), ratio
    # 锁定率 < 30% → 绝大部分删得掉，属于「现在能清」的范畴
    # （残留的那几个会在真删时登记重启删，由 server 端真值闸如实扣减）
    return True, "", ratio


def clean_migrate_residuals(resid_paths, on_progress=None):
    """清理迁移残留 .migrated.bak（删源释放 C 盘）。返回：
    {ok, done:[path], failed:[{path,reason}], freed_kb, reboot_pending}
    安全：仅接受通过 _is_safe_migrated_bak 校验的残留（junction 已建、目标盘有副本）。"""
    done, failed = [], []
    freed_kb = 0.0
    reboot_pending = 0
    # v1.7.86：登记失败原因（人话，供上层如实告知；空串 = 全部登记成功或无需登记）
    _reboot_fail_reason = ""
    total = len(resid_paths or [])
    for i, p in enumerate(resid_paths or []):
        try:
            if not p or not os.path.isdir(p):
                failed.append({"path": p, "reason": "目录不存在"})
                continue
            ok_safe, reason = _is_safe_migrated_bak(p)
            if not ok_safe:
                failed.append({"path": p, "reason": reason})
                continue
            # 先量体积（fast_purge 会 rename 走源目录，删除后量不到原大小）
            try:
                freed_kb += _dir_size_bytes(p) / 1024.0
            except Exception:
                pass
            resid = fast_purge(p)
            if resid is None:
                # v1.7.97 P0：清理超时未确认完成 → 如实标失败，绝不当成「已清完」。
                failed.append({"path": p, "reason": "清理超时未完成，已停止以免误判，请稍后重试"})
                continue
            if resid:
                try:
                    # v1.7.86：批量登记现在返回 (成功数, 失败原因)。
                    # 只有**真的登记成功了**才计 reboot_pending —— 旧代码无条件 +1，
                    # 于是非管理员态下明明没登记成功，报告里却出现
                    # 「已安排重启后自动清理 N 项」，用户重启后发现文件还在 → 骗用户。
                    _rb_ok, _rb_why = _schedule_reboot_delete_batch(resid)
                    if _rb_ok:
                        reboot_pending += 1
                    else:
                        _reboot_fail_reason = _rb_why
                except Exception:
                    pass
            done.append(p)
        except Exception as e:
            failed.append({"path": p, "reason": str(e)[:120]})
        if on_progress:
            try:
                on_progress(i + 1, total)
            except Exception:
                pass
    return {"ok": len(failed) == 0, "done": done, "failed": failed,
            "freed_kb": round(freed_kb, 1), "reboot_pending": reboot_pending,
            # v1.7.86：把「没能登记」的原因带出去，上层据此说人话，而不是显示「已安排」
            "reboot_fail_reason": _reboot_fail_reason}


# ---- v1.7.94：Windows 原生 rd 快路径（实测比Python 逐文件删快一个数量级）----
_RD_MAX_SEC = 300


def _rd_quick_delete(path, max_sec=None):
    """用 `rd /s /q` 删整棵目录树。返回 (是否已删干净, 失败原因)。

    ★ 为什么必须有这个（实测，别再用推理代替数据）：
      暂存区在 **C 盘根目录**（_purge_stage() -> C:\aipc_purge），
      正是 360/阿里实时防护的高频盯防位置。Python `os.walk`+`os.remove`
      逐文件删在这里吞吐掉到个位数文件/秒 ——
      实测 1846 文件 / 1.39GB **删了 8 分 23 秒还没删完**。
      `rd /s /q` 是 Windows 原生批量删：内核侧一次提交，
      被实时防护逐个拦截的概率与耗时都低得多。
      ★ 注意：`rd` 必须经 `cmd /c` 调用（实测直接 subprocess(['rd',...]) 报 WinError 2）。

    硬约束：整个调用有墙钟上限（默认 300s），超时立刻返回 False，
    由调用方登记重启删兜底 —— **绝不硬等，绝不假装删干净**。
    """
    import subprocess as _sp
    _lim = int(max_sec or _RD_MAX_SEC)
    if _lim <= 0:
        return False, "超时上限为 0，未执行"
    if not path or not os.path.exists(path):
        return True, ""# 本来就不存在 = 已达成
    try:
        # ★ `rd` 是 cmd.exe 内建命令，**不是**独立可执行文件 ——
        #   实测 subprocess(['rd', ...]) 直接 WinError 2（rd 快路径 0.0s 失败）。
        #   必须经cmd /c。
        _p = _sp.Popen(
            ["cmd", "/c", "rd", "/s", "/q", path],
            stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
            shell=False, creationflags=getattr(_sp, "CREATE_NO_WINDOW", 0))
    except Exception as _e:
        return False, ("rd 启动失败: %s" % _e)[:120]
    try:
        _p.wait(timeout=_lim)
    except Exception:
        # ★ v1.7.96 P0：超时后必须确认 rd 进程【真的死了】再返回。
        #   实测事故：kill(cmd) 之后立刻 return False，调用方马上又对
        #   【同一棵树】起 _rd_parallel_children —— 老 rd 还在内核里删，
        #   新 rd 又进来，两条 rd 抢同一批 NTFS 元数据锁。
        #   进程列表铁证：同一个目录同时挂着两个 cmd /c rd。
        #   吞吐实测从 26.7 文件/秒 掉到 1.3 文件/秒。
        try:
            _p.kill()
        except Exception:
            pass
        try:
            _p.wait(timeout=20)
        except Exception:
            try:
                _sp.run(["taskkill", "/F", "/T", "/PID", str(_p.pid)],
                        stdout=_sp.DEVNULL, stderr=_sp.DEVNULL, timeout=25,
                        creationflags=getattr(_sp, "CREATE_NO_WINDOW", 0))
            except Exception:
                pass
            try:
                _p.wait(timeout=10)
            except Exception:
                pass
        return False, ("rd 超过 %d 秒未完成" % _lim)
    if os.path.exists(path):
        return False, "rd 结束但目录仍在（有文件被占用）"
    return True, ""


# ★ 实测最优并发度 = 3。别再往上加：
#   3 个 rd 并发 = 26.7 文件/秒（真实数据实测）
#   6 个 rd 并发 = 5.4 文件/秒
#   18 个 rd 并发 = 0.4~5.9 文件/秒
#   并发上去反而更慢（NTFS 元数据锁 + 杀软串行处理），3 是拐点。
_RD_PARALLEL_WORKERS = 3


def _rd_parallel_children(root, max_workers=_RD_PARALLEL_WORKERS,
                          per_rd_sec=600, budget_sec=1800):
    """并发删 root 下的子目录（每个子目录一个 rd）。返回没删掉的路径列表。

    ★ 真实数据实测（2026-10-07，这条推翻了我上一版的「串行更快」判断）：
        串行整树 rd：2.2 文件/秒（真实迁移垃圾）
        并发 3 个 rd：26.7 文件/秒  → 快 12 倍
      实验室里「并发更慢」是因为我测的是刚写的小文件，瓶颈是磁盘吞吐；
      真实数据的瓶颈是【每个文件的固定开销】，并发把等待重叠起来才是正解。

    ★ 为什么不用 with ThreadPoolExecutor：
      with 退出时执行 shutdown(wait=True) → join 每个 worker →
      一个卡死（坏道 / 死锁的杀软回调）就永远出不来。v1.7.88 已吃过这个亏。
      这里显式 shutdown(wait=False, cancel_futures=True)。
    """
    try:
        subs = [os.path.join(root, x) for x in os.listdir(root)]
    except Exception:
        return []
    dirs = [p for p in subs if os.path.isdir(p) and not os.path.islink(p)]
    files = [p for p in subs if not (os.path.isdir(p) and not os.path.islink(p))]
    leftover = []
    for p in files:
        try:
            _win_delete(p)
        except Exception:
            leftover.append(p)
    if not dirs:
        return leftover

    t0 = _time.time()
    _res = []
    _lk = threading.Lock()

    def _one(p):
        if _time.time() - t0 > budget_sec:
            with _lk:
                _res.append(p)
            return
        try:
            _ok, _why = _rd_quick_delete(p, max_sec=per_rd_sec)
        except Exception:
            _ok = False
        if not _ok and os.path.exists(p):
            with _lk:
                _res.append(p)

    pool = ThreadPoolExecutor(max_workers=max_workers)
    try:
        futs = [pool.submit(_one, p) for p in dirs]
        try:
            for f in as_completed(futs, timeout=budget_sec + 60):
                try:
                    f.result()
                except Exception:
                    pass
        except Exception:
            pass
    finally:
        try:
            pool.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
    return leftover + list(_res)


def _empty_dir_contents(path, on_progress=None, wait=True, max_sec=600):
    """清空目录内容（保留根目录本身）。v1.7.23 新增。

    ★ v1.7.95 P0 修复（我自己 v1.7.94 引入的回归，必须记住）：
      函数体里用了 max_sec 和 wait，但签名里**两个都没有** → NameError。
      而 NameError 被 1523 行的 `except Exception: pass` 和最外层的
      `except Exception: return []` 吞掉 —— 结果是：一个文件都没删，
      却返回 [] 让调用方以为「全部清理成功」。
      实测：5 个文件的小目录，调用后返回 []，5 个文件原地不动。
      这比「删一半」更恶劣 —— 是彻头彻尾的假成功。
      教训：**加代码时改了调用就要改签名；改完必须真跑一次破坏性验证。**
    

    用于 fast_purge rename 失败（Temp 等系统共享目录被进程占用无法改名）时的兜底。

    v1.7.85（老李 2026-10-04 实测根因②·「假成功」修复）：
    旧实现把删除丢进后台 daemon 线程后**立刻 return []**，而这个 [] 被 fast_purge
    原样返回、server 端 _clean_one 收到 skipped=[] 即判定「该项全部清理成功」，
    写进台账 done、报告标「已清理」。但后台线程此刻才刚开始跑、甚至可能立刻失败：
      实测 Temp 41179 个文件 → 调用返回时只删了 15 个 → 台账却说「已清理 3.3GB」。
    这就是「哐哐哐干半天、跳出来一句需要重启」的老病根。

    现在改为：
      · wait=True（默认，fast_purge 走的就是这条）：**同步等删除真的做完**再返回，
        返回值是【真实残留】——删不掉的就如实返回、登记重启删，绝不谎报。
      · wait=False：仍走后台（仅供明确不需要真实结果的调用方使用），
        此时返回 None 表示「结果未知」，调用方必须区别对待，不得当成「全部成功」。
    """
    root = os.path.abspath(path)
    result_box = {"residual": [], "done": False}

    def _worker():
        if not os.path.isdir(root):
            result_box["done"] = True
            return
        residual = []
        # ---- v1.7.94 P0：先试 Windows 原生 rd 整棵批量删（实测比 Python 逐文件删
        #   快一个数量级）。暂存区在 C 盘根目录是杀软高频盯防位置，
        #   逐文件删 1846 个文件实测要 8 分 23 秒 → 曾把迁移卡 37 分钟。
        #   rd 成功 = 秒回；失败/超时 → 落回原有分项逻辑，残留如实上报。
        try:
            # ① 先试整树 rd（快速路径，简单目录秒回）。上限 240 秒：
            #    够删干净就直接走人，不够也别在这里耗 —— 交给 ② 并发。
            _rd_ok, _rd_why = _rd_quick_delete(root, max_sec=min(max_sec, 240))
            if _rd_ok:
                if on_progress:
                    try:
                        on_progress(1, 1, 0)
                    except Exception:
                        pass
                result_box["residual"] = []
                result_box["done"] = True
                return
            # rd 没成功：把 root 重新建回来（rd /s 会连带删掉 root 本身）
            try:
                os.makedirs(root, exist_ok=True)
            except Exception:
                pass
        except Exception:
            pass
        # ② v1.7.95（实测纠偏）：整树 rd 没成 → **并发**删子目录。
        #    真实数据上并发 26.7 文件/秒 vs 串行 2.2 文件/秒，差 12 倍。
        #    （我上一版依据实验室小文件判定「串行更快」，是错的。）
        try:
            _left = _rd_parallel_children(root, budget_sec=max_sec)
        except Exception:
            _left = None
        if _left is not None and not _left:
            try:
                # v1.7.100：_win_delete 代替 os.rmdir（空壳真删，不进回收站）
                _win_delete(root)
            except Exception:
                pass
            if not os.path.isdir(root):
                if on_progress:
                    try:
                        on_progress(1, 1, 0)
                    except Exception:
                        pass
                result_box["residual"] = []
                result_box["done"] = True
                return
        try:
            for name in os.listdir(root):
                p = os.path.join(root, name)
                try:
                    if os.path.isdir(p) and not os.path.islink(p):
                        # v1.7.85：子目录用 rd 快路径（_fast_delete_dir 内部已含），
                        # 时限给足——Temp 下有 4 万+ 小文件，90 秒连零头都删不完。
                        residual.extend(_fast_delete_dir(p, on_progress=on_progress,
                                                           max_sec=max(600, max_sec)))
                    else:
                        try:
                            _win_delete(p)
                        except OSError:
                            residual.append(p)
                except OSError:
                    residual.append(p)
        except Exception:
            pass
        # v1.7.24：真实残留回报（弹窗/页面展示「未清理 X 项 + 重启删登记」）
        if residual:
            try:
                _schedule_reboot_delete_batch(residual)
            except Exception:
                pass
            try:
                _rb = sum(max(0, os.path.getsize(fp)) for fp in residual[:5000])
            except Exception:
                _rb = 0
            with _PURGE_RESIDUAL_LOCK:
                _PURGE_RESIDUAL["count"] += len(residual)
                _PURGE_RESIDUAL["bytes"] += _rb
        result_box["residual"] = residual
        result_box["done"] = True

    try:
        import threading as _th
        t = _th.Thread(target=_worker, daemon=True)
        with _PURGE_LOCK:
            _PURGE_THREADS.append(t)
        t.start()
        if wait:
            # 同步等：宁可这一步慢，也绝不能返回「假成功」——
            # 假成功会让报告说清了几 GB、实际一块没删，是最伤用户信任的失败方式。
            # v1.7.97 P0：join 必须带超时——worker 自身有 max_sec 预算，但个别 syscall
            # 可能死锁（坏道/被占 DLL），无超时 join 会永久挂起，把整个清理/迁移链路拖死。
            # 超时即视为「未确认完成」，返回 None（结果未知），调用方不得当成成功
            # （绝不返回 [] 谎报「全清完」）；daemon 线程继续在后台跑完，不阻塞调用方。
            t.join(timeout=max(60, max_sec + 300))
            if t.is_alive():
                return None
            return list(result_box.get("residual") or [])
        return None      # 结果未知，调用方不得当成成功
    except Exception:
        return None


def _schedule_reboot_delete_batch(files):
    """批量登记重启删：残留文件按父目录去重，目录级登记（幂等、安全护栏同单条版）。

    v1.7.86：改为复用 _reboot_register_count，返回 (成功数, 失败原因)，
    让调用方能如实告知用户「有几项没登记成功」，而不是只拿到一个数字。
    旧的批量实现与 server.py 里那份是重复代码，两边都只返回成功数 → 两边都会骗用户。
    """
    return _reboot_register_count(files)



# --------------------------------------------------------------------------
# 并行度配置（方案B）：迁移多个独立目录时并发执行的 worker 数。
# 数值越大越快（直到磁盘 IO 饱和）；消费级 SSD 建议 3，快盘可 4-5；
# 若目标盘是机械硬盘，建议保持 2-3 以免随机写入抖动。可在 scripts/config.json 调。
# --------------------------------------------------------------------------
def _load_cfg_int(key, default):
    try:
        _cfgp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
        with open(_cfgp, encoding="utf-8") as _f:
            return int(json.load(_f).get(key, default))
    except Exception:
        return default


MIGRATE_MAX_WORKERS = _load_cfg_int("migrate_parallel", 3)


# --------------------------------------------------------------------------
# 可安全迁移的目录：路径（不区分大小写）包含这些片段之一，即视为「程序数据」可迁移。
# 注意：全部位于 AppData / Program Files / 程序自带目录，不在用户个人根目录。
# 注意：浏览器缓存 / 配置数据走「绿区清理」即可，不再放入迁移，避免用户混淆
#       "迁移的是软件数据" vs "清理的是缓存"。
# --------------------------------------------------------------------------
SAFE_MIGRATE_PATTERNS = [
    (r"\\wechat files\\", "微信聊天文件"),
    (r"\\wechat files$", "微信聊天文件"),
    (r"\\wechat_files\\", "微信聊天文件"),
    (r"\\wechat_files$", "微信聊天文件"),
    (r"\\wexin files\\", "微信聊天文件"),
    (r"\\wexin_files\\", "微信聊天文件"),
    (r"\\xwechat files\\", "微信聊天文件"),
    (r"\\xwechat files$", "微信聊天文件"),
    (r"\\xwechat_files\\", "微信聊天文件"),
    (r"\\xwechat_files$", "微信聊天文件"),
    (r"\\weixin files\\", "微信聊天文件"),
    (r"\\weixin files$", "微信聊天文件"),
    (r"\\weixin_files\\", "微信聊天文件"),
    (r"\\weixin_files$", "微信聊天文件"),
    (r"\\tencent\\", "腾讯系程序数据"),
    (r"\\tencent$", "腾讯系程序数据"),
    (r"\\tencentfiles", "腾讯系聊天文件"),
    (r"\\wxwork", "企业微信数据"),
    (r"\\kingsoft", "金山系数据"),
    (r"\\steam\\steamapps", "Steam 游戏库"),
    (r"\\steam\\userdata", "Steam 用户数据"),
    (r"\\epic games\\", "Epic 游戏库"),
    (r"\\origin games\\", "Origin 游戏库"),
    (r"\\battle.net", "战网游戏数据"),
    (r"\\android\\sdk", "Android SDK"),
    (r"\\.android", "Android 模拟器/SDK 数据"),
    (r"\\.gradle", "Gradle 缓存"),
    (r"\\.m2\\repository", "Maven 仓库"),
    (r"\\.nuget", "NuGet 包缓存"),
    (r"\\.npm", "npm 缓存"),
    (r"\\pip\\cache", "pip 缓存"),
    (r"\\.cargo", "Cargo 仓库"),
    (r"\\.rustup", "Rust 工具链"),
    (r"\\ms-playwright", "Playwright 浏览器"),
    (r"\\uv\\cache", "uv 缓存"),
    (r"\\uv\\tool", "uv 工具缓存"),
    (r"\\yarn", "Yarn 缓存"),
    (r"\\go-build", "Go 编译缓存"),
    (r"\\go\\pkg", "Go 模块缓存"),
    (r"\\thunder network", "迅雷下载数据"),
    (r"\\xunlei", "迅雷数据"),
    (r"\\baidunetdisk", "百度网盘数据"),
    (r"\\nvidia corporation", "NVIDIA 数据"),
    (r"\\docker", "Docker 数据"),
    (r"\\node_modules", "Node 依赖库"),
    (r"\\feishu", "飞书数据"),
    (r"\\jianyingpro", "剪映数据"),
    (r"\\jianying", "剪映数据"),
    (r"\\kimi-desktop", "Kimi 桌面数据"),
    (r"\\adobe\\", "Adobe 数据"),
    (r"\\adobe$", "Adobe 数据"),
    (r"\\netease\\cloudmusic", "网易云音乐数据"),
    (r"\\qqmusic", "QQ 音乐数据"),
    (r"\\wechat devtools", "微信开发者工具数据"),
    (r"\\sogou", "搜狗输入法数据"),
    (r"\\vscode", "VS Code 数据"),
    (r"\\visual studio code", "VS Code 数据"),
    # ---- 即时通讯 / 国民软件（用户级程序数据）----
    (r"\\dingtalk", "钉钉数据"),
    (r"\\alipay", "支付宝数据"),
    (r"\\telegram", "Telegram 数据"),
    (r"\\discord", "Discord 数据"),
    (r"\\spotify", "Spotify 数据"),
    (r"\\youdao", "有道数据"),
    (r"\\xmind", "XMind 数据"),
    (r"\\lark", "飞书数据"),
    # ---- 游戏平台 / 游戏库（装在其它盘则可迁移；在 Program Files 需管理员会自动跳过）----
    (r"\\ubisoft game launcher", "育碧游戏数据"),
    (r"\\ubisoft games", "育碧游戏数据"),
    (r"\\gog galaxy", "GOG 游戏数据"),
    (r"\\ea games", "EA 游戏数据"),
    (r"\\ea desktop", "EA 游戏数据"),
    (r"\\rockstar games", "Rockstar 游戏数据"),
    (r"\\riot games", "Riot 游戏数据"),
    (r"\\activision", "动视游戏数据"),
    # ---- 开发 / 运行时 / 虚拟机（用户级，零管理员）----
    (r"\\.conda", "Conda 环境"),
    (r"\\.virtualenvs", "Python 虚拟环境"),
    (r"\\.gem", "RubyGems 缓存"),
    (r"\\.ivy2", "Ivy 缓存"),
    (r"\\.rvm", "RVM 缓存"),
    (r"\\android studio", "Android Studio 数据"),
    (r"\\.android\\avd", "Android 模拟器镜像"),
    (r"\\virtualbox vms", "VirtualBox 虚拟机"),
    (r"\\.vagrant", "Vagrant 数据"),
    (r"\\.minecraft", "Minecraft 数据"),
    # ---- 国民短视频 / 直播 / 创作（用户级程序数据，可迁移）----
    (r"\\douyin", "抖音数据"),
    (r"\\kuaishou", "快手数据"),
    (r"\\xiaohongshu", "小红书数据"),
    (r"\\xigua", "西瓜视频数据"),
    (r"\\bilibili", "B站数据"),
    (r"\\obs studio", "OBS 录制数据"),
    (r"\\capcut", "剪映国际版数据"),
    # ---- 网盘 / 云存储（用户级缓存+下载数据，可迁移）----
    (r"\\quark", "夸克网盘数据"),
    (r"\\115", "115 网盘数据"),
    (r"\\tycloud", "天翼云盘数据"),
    (r"\\weiyun", "微云数据"),
    (r"\\yunfile", "迅雷云盘数据"),
    # ---- 视频 / 音乐平台（缓存可迁移）----
    (r"\\iqiyi", "爱奇艺缓存"),
    (r"\\qqlive", "腾讯视频缓存"),
    (r"\\youku", "优酷缓存"),
    (r"\\kugou", "酷狗音乐数据"),
    (r"\\kuwo", "酷我音乐数据"),
    # ---- 电商 / 办公 / 笔记（用户级数据，可迁移）----
    (r"\\wangwang", "阿里旺旺数据"),
    (r"\\aliwangwang", "阿里旺旺数据"),
    (r"\\qiandao", "千牛数据"),
    (r"\\evernote", "印象笔记数据"),
    (r"\\youdaonote", "有道云笔记数据"),
    (r"\\wetype", "微信输入法数据"),
    (r"\\modao", "墨刀数据"),
    (r"\\figma", "Figma 数据"),
    # ---- 模拟器（安卓模拟器镜像/数据，可迁移）----
    (r"\\ldplayer", "雷电模拟器数据"),
    (r"\\nox", "夜神模拟器数据"),
    (r"\\mumu", "MuMu 模拟器数据"),
    (r"\\memu", "逍遥模拟器数据"),
    # ---- 本机实测漏网应用（2026-07-22 竞品截图对照后补全）----
    (r"\\kimi-work", "Kimi 数据"),
    (r"\\\.kimi-work", "Kimi 数据"),
    (r"\\omniwork", "Omniwork 数据"),
    (r"\\\.omniwork", "Omniwork 数据"),
    (r"\\autoclaw", "Autoclaw 数据"),
    (r"\\openclaw-autoclaw", "Autoclaw 数据"),
    (r"\\\.openclaw-autoclaw", "Autoclaw 数据"),
    # ---- AI IDE 隐藏点目录（借鉴 xiaoliu666 覆盖，通用 dev 机器 3~7GB）----
    # 注意：`.codebuddy` 是自家 WorkBuddy 运行时，留 EXCLUDE 不动；只加 AppData 的 CodeBuddy。
    (r"\\.lingma", "通义灵码 数据"),
    (r"\\.trae", "Trae IDE 数据"),
    (r"\\.trae-cn", "Trae CN 数据"),
    (r"\\trae solo", "Trae Solo 数据"),
    (r"\\.codex", "Codex 数据"),
    (r"\\.marscode", "MarsCode 数据"),
    (r"\\.codegeex", "CodeGeeX 数据"),
    (r"\\.vscode", "VS Code 用户数据"),
    (r"\\trae", "Trae IDE 数据"),
    (r"\\trae-cn", "Trae CN 数据"),
    (r"\\codebuddy", "CodeBuddy 数据"),
    (r"\\飞鸽客服", "飞鸽客服数据"),
    (r"\\accio", "Accio 数据"),
    (r"\\secoresdk", "360 安全浏览器数据"),
    (r"\\360safe", "360 安全卫士数据"),
    (r"\\com\.tencent\.yuanbao", "腾讯元宝数据"),
    (r"\\yuanbao", "腾讯元宝数据"),
    (r"\\programs", "Local Programs 开发工具"),
    # ---- 2026-07-29 覆盖率补全（老李：迁移是第一生产力，能迁的全迁）----
    (r"\\hexin", "同花顺/东方财富 数据"),
    (r"\\eastmoney", "同花顺/东方财富 数据"),
    (r"\\同花顺", "同花顺/东方财富 数据"),
    (r"\\gamer", "网易大神 游戏数据"),
    (r"\\hyrz", "网易大神 游戏数据"),
    (r"\\sogouweixin", "搜狗微信 浏览器数据"),
    (r"\\comfyui", "AI 绘图 (ComfyUI/StableDiffusion) 数据"),
    (r"\\stable-diffusion", "AI 绘图 (StableDiffusion) 数据"),
    (r"\\invokeai", "AI 绘图 (InvokeAI) 数据"),
    (r"\\automatic1111", "AI 绘图 (Automatic1111) 数据"),
    (r"\\fooocus", "AI 绘图 (Fooocus) 数据"),
    (r"\\lora", "AI 绘图 LoRA 模型"),
    (r"\\embeddings", "AI 绘图 Embedding 模型"),
    (r"\\models\\unet", "AI 绘图 ControlNet/UNet 模型"),
    (r"\\league of legends", "英雄联盟 游戏数据"),
    (r"\\genshin impact", "原神 游戏数据"),
    (r"\\honkai", "崩坏 游戏数据"),
    (r"\\star rail", "崩坏：星穹铁道 数据"),
    (r"\\zzz", "绝区零 数据"),
    (r"\\wuthering waves", "鸣潮 数据"),
    (r"\\valorant", "无畏契约 数据"),
    (r"\\crossfire", "穿越火线 数据"),
    (r"\\pubg", "绝地求生 数据"),
    (r"\\arena of valor", "王者荣耀 数据"),
    (r"\\qqgame", "QQ 游戏 数据"),
    (r"\\qqpcmgr", "腾讯电脑管家 数据"),
    (r"\\qq_guild", "QQ 频道数据"),
    (r"\\dnftrader", "DNF 数据"),
    # ---- 会议/办公协作 ----
    (r"\\wemeet", "腾讯会议 数据"),
    (r"\\tencent meeting", "腾讯会议 数据"),
    (r"\\zoom", "Zoom 数据"),
    (r"\\microsoft teams", "Teams 数据"),
    (r"\\slack", "Slack 数据"),
    (r"\\钉钉", "钉钉 数据"),
    (r"\\dingtalk", "钉钉 数据"),
    # ---- 米哈游 / 网易 / 更多游戏 ----
    (r"\\mihoyo", "米哈游 游戏数据"),
    (r"\\hoyoverse", "HoYoverse 游戏数据"),
    (r"\\netease games", "网易游戏 数据"),
    (r"\\neteasegame", "网易游戏 数据"),
    (r"\\onmyoji", "阴阳师 数据"),
    (r"\\identityv", "第五人格 数据"),
    (r"\\fantasy westward", "梦幻西游 数据"),
    # ---- JetBrains IDE 缓存（索引/本地历史巨大） ----
    (r"\\\.pycharm", "PyCharm 缓存"),
    (r"\\\.intellijidea", "IntelliJ IDEA 缓存"),
    (r"\\\.webstorm", "WebStorm 缓存"),
    (r"\\\.clion", "CLion 缓存"),
    (r"\\\.goland", "GoLand 缓存"),
    (r"\\\.rider", "Rider 缓存"),
    (r"\\\.phpstorm", "PhpStorm 缓存"),
    (r"\\\.datagrip", "DataGrip 缓存"),
    (r"\\\.rubymine", "RubyMine 缓存"),
    (r"\\\.fleet", "Fleet 缓存"),
    (r"\\\.androidstudio", "Android Studio 缓存"),
    (r"\\jetbrains", "JetBrains 工具缓存"),
    # ---- 云盘 ----
    (r"\\aliyundrive", "阿里云盘 数据"),
    (r"\\adrive", "阿里云盘 数据"),
    (r"\\nutstore", "坚果云 数据"),
    (r"\\jianguoyun", "坚果云 数据"),
    (r"\\onedrive\\settings", "OneDrive 设置缓存"),
    (r"\\onedrive\\logs", "OneDrive 日志缓存"),
    # ---- 创作/剪辑 ----
    (r"\\bijian", "必剪 数据"),
    (r"\\dujia", "度加 数据"),
    (r"\\miaojian", "秒剪 数据"),
    (r"\\jianying", "剪映 数据"),
    (r"\\capcut", "CapCut 数据"),
    (r"\\mastergo", "MasterGo 数据"),
    (r"\\pixso", "Pixso 数据"),
    (r"\\jsdesign", "即时设计 数据"),
    (r"\\instant design", "即时设计 数据"),
    # ---- 输入法 ----
    (r"\\xunfei", "讯飞输入法 数据"),
    (r"\\iflytek", "讯飞输入法 数据"),
    (r"\\baidu pinyin", "百度输入法 数据"),
    (r"\\bdime", "百度输入法 数据"),
    (r"\\qqpinyin", "QQ 拼音 数据"),
    (r"\\sogoupy", "搜狗输入法 数据"),
    (r"\\sogouinput", "搜狗输入法 数据"),
    # ---- 金融/交易 ----
    (r"\\dazhihui", "大智慧 数据"),
    (r"\\eastmoney", "东方财富 数据"),
    (r"\\hexin", "同花顺 数据"),
    (r"\\ths", "同花顺 数据"),
    (r"\\tdx", "通达信 数据"),
    (r"\\trade", "证券交易 数据"),
    # ---- 浏览器/下载（Profile 不迁，只迁可重下的缓存/下载目录） ----
    (r"\\chrome\\download", "Chrome 下载缓存"),
    (r"\\edge\\download", "Edge 下载缓存"),
]

# 迁移项对外展示名称：避免被误认为是「软件本身」，强调「数据/缓存/下载」。
MIGRATE_DISPLAY_NAMES = {
    "微信聊天文件": "微信聊天文件（图片/视频/文件）",
    "腾讯系程序数据": "微信/QQ 数据",
    "腾讯系聊天文件": "微信/QQ 聊天文件",
    "QQ 数据": "QQ 数据",
    "QQ NT 数据": "QQ NT 数据",
    "QQ 频道数据": "QQ 频道数据",
    "企业微信数据": "企业微信数据",
    "金山系数据": "WPS/金山办公 用户数据",
    "Steam 游戏库": "Steam 游戏库",
    "Steam 用户数据": "Steam 用户数据",
    "Epic 游戏库": "Epic 游戏库",
    "Origin 游戏库": "Origin 游戏库",
    "战网游戏数据": "战网游戏数据",
    "Android SDK": "Android SDK",
    "Android 模拟器/SDK 数据": "Android 模拟器数据",
    "Gradle 缓存": "Gradle 缓存",
    "Maven 仓库": "Maven 仓库",
    "NuGet 包缓存": "NuGet 包缓存",
    "npm 缓存": "npm 缓存",
    "pip 缓存": "pip 缓存",
    "Cargo 仓库": "Cargo 仓库",
    "Rust 工具链": "Rust 工具链",
    "Playwright 浏览器": "Playwright 浏览器",
    "uv 缓存": "uv 缓存",
    "Yarn 缓存": "Yarn 缓存",
    "Go 编译缓存": "Go 编译缓存",
    "Go 模块缓存": "Go 模块缓存",
    "迅雷下载数据": "迅雷下载数据",
    "迅雷数据": "迅雷数据",
    "百度网盘数据": "百度网盘 下载/缓存数据",
    "NVIDIA 数据": "NVIDIA 数据",
    "Docker 数据": "Docker 数据",
    "Node 依赖库": "Node 依赖库",
    "飞书数据": "飞书 用户数据",
    "剪映数据": "剪映 工程/缓存数据",
    "Kimi 桌面数据": "Kimi 桌面 用户数据",
    "Adobe 数据": "Adobe 用户数据",
    "网易云音乐数据": "网易云音乐 缓存/数据",
    "QQ 音乐数据": "QQ 音乐 缓存/数据",
    "微信开发者工具数据": "微信开发者工具 数据",
    "搜狗输入法数据": "搜狗输入法 用户数据",
    "VS Code 数据": "VS Code 扩展/数据",
    "钉钉数据": "钉钉 用户数据",
    "支付宝数据": "支付宝 用户数据",
    "Telegram 数据": "Telegram 数据",
    "Discord 数据": "Discord 缓存/数据",
    "Spotify 数据": "Spotify 缓存/数据",
    "有道数据": "有道 用户数据",
    "XMind 数据": "XMind 数据",
    "育碧游戏数据": "育碧 游戏数据",
    "GOG 游戏数据": "GOG 游戏数据",
    "EA 游戏数据": "EA 游戏数据",
    "Rockstar 游戏数据": "Rockstar 游戏数据",
    "Riot 游戏数据": "Riot 游戏数据",
    "动视游戏数据": "动视游戏数据",
    "Conda 环境": "Conda 虚拟环境",
    "Python 虚拟环境": "Python 虚拟环境",
    "RubyGems 缓存": "RubyGems 缓存",
    "Ivy 缓存": "Ivy 缓存",
    "RVM 缓存": "RVM 缓存",
    "Android Studio 数据": "Android Studio 数据",
    "Android 模拟器镜像": "Android 模拟器镜像",
    "VirtualBox 虚拟机": "VirtualBox 虚拟机",
    "Vagrant 数据": "Vagrant 数据",
    "Minecraft 数据": "Minecraft 数据",
    "抖音数据": "抖音 缓存/数据",
    "快手数据": "快手 缓存/数据",
    "小红书数据": "小红书 数据",
    "西瓜视频数据": "西瓜视频 缓存",
    "B站数据": "B站 缓存/数据",
    "OBS 录制数据": "OBS 录制数据",
    "OBS 数据": "OBS 数据",
    "剪映国际版数据": "CapCut 数据",
    "夸克网盘数据": "夸克网盘 下载/缓存数据",
    "115 网盘数据": "115 网盘 数据",
    "天翼云盘数据": "天翼云盘 数据",
    "微云数据": "微云 数据",
    "迅雷云盘数据": "迅雷云盘 数据",
    "爱奇艺缓存": "爱奇艺 缓存",
    "腾讯视频缓存": "腾讯视频 缓存",
    "优酷缓存": "优酷 缓存",
    "酷狗音乐数据": "酷狗音乐 数据",
    "酷我音乐数据": "酷我音乐 数据",
    "阿里旺旺数据": "阿里旺旺 数据",
    "千牛数据": "千牛 卖家数据",
    "印象笔记数据": "印象笔记 数据",
    "有道云笔记数据": "有道云笔记 数据",
    "微信输入法数据": "微信输入法 用户数据",
    "墨刀数据": "墨刀 数据",
    "Figma 数据": "Figma 数据",
    "雷电模拟器数据": "雷电模拟器 数据",
    "夜神模拟器数据": "夜神模拟器 数据",
    "MuMu 模拟器数据": "MuMu 模拟器 数据",
    "逍遥模拟器数据": "逍遥模拟器 数据",
    "Kimi 数据": "Kimi 用户数据",
    "Omniwork 数据": "Omniwork 用户数据",
    "Autoclaw 数据": "Autoclaw 数据",
    "飞鸽客服数据": "飞鸽客服 数据",
    "Accio 数据": "Accio 数据",
    "360 安全浏览器数据": "360 安全浏览器 数据",
    "360 安全卫士数据": "360 安全卫士 数据",
    "腾讯元宝数据": "腾讯元宝 数据",
    "Local Programs 开发工具": "Local Programs (git/node/python 等)",
    "通义灵码 数据": "通义灵码 用户数据",
    "Trae IDE 数据": "Trae IDE 数据",
    "Trae CN 数据": "Trae CN 用户数据",
    "Trae Solo 数据": "Trae Solo 数据",
    "Codex 数据": "Codex 用户数据",
    "MarsCode 数据": "MarsCode 用户数据",
    "CodeGeeX 数据": "CodeGeeX 用户数据",
    "VS Code 用户数据": "VS Code 用户数据",
    "CodeBuddy 数据": "CodeBuddy 用户数据",
    "腾讯会议 数据": "腾讯会议 录制/缓存数据",
    "Zoom 数据": "Zoom 录制/缓存数据",
    "Teams 数据": "Microsoft Teams 缓存数据",
    "Slack 数据": "Slack 缓存数据",
    "米哈游 游戏数据": "米哈游 游戏数据",
    "HoYoverse 游戏数据": "HoYoverse 游戏数据",
    "网易游戏 数据": "网易游戏 数据",
    "PyCharm 缓存": "PyCharm 缓存/索引",
    "IntelliJ IDEA 缓存": "IntelliJ IDEA 缓存/索引",
    "WebStorm 缓存": "WebStorm 缓存/索引",
    "CLion 缓存": "CLion 缓存/索引",
    "GoLand 缓存": "GoLand 缓存/索引",
    "Rider 缓存": "Rider 缓存/索引",
    "PhpStorm 缓存": "PhpStorm 缓存/索引",
    "DataGrip 缓存": "DataGrip 缓存/索引",
    "RubyMine 缓存": "RubyMine 缓存/索引",
    "Fleet 缓存": "Fleet 缓存/索引",
    "Android Studio 缓存": "Android Studio 缓存/索引",
    "JetBrains 工具缓存": "JetBrains 工具缓存",
    "阿里云盘 数据": "阿里云盘 下载/缓存数据",
    "坚果云 数据": "坚果云 数据",
    "OneDrive 设置缓存": "OneDrive 设置缓存",
    "OneDrive 日志缓存": "OneDrive 日志缓存",
    "必剪 数据": "必剪 工程/缓存数据",
    "度加 数据": "度加 工程/缓存数据",
    "秒剪 数据": "秒剪 工程/缓存数据",
    "MasterGo 数据": "MasterGo 数据",
    "Pixso 数据": "Pixso 数据",
    "即时设计 数据": "即时设计 数据",
    "讯飞输入法 数据": "讯飞输入法 用户数据",
    "百度输入法 数据": "百度输入法 用户数据",
    "QQ 拼音 数据": "QQ 拼音 用户数据",
    "大智慧 数据": "大智慧 行情/缓存数据",
    "东方财富 数据": "东方财富 行情/缓存数据",
    "同花顺 数据": "同花顺 行情/缓存数据",
    "通达信 数据": "通达信 行情/缓存数据",
    "证券交易 数据": "证券交易 行情/缓存数据",
    "Chrome 下载缓存": "Chrome 下载缓存",
    "Edge 下载缓存": "Edge 下载缓存",
}

MIN_MIGRATE_KB = 50 * 1024  # 降门槛到 50MB：扩大迁移覆盖面（junction 开销极小，50MB 起迁划算）


def _kb_h(kb):
    n = float(kb) * 1024
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return ("%.1f %s" % (n, unit)) if unit != "B" else ("%d %s" % (int(n), unit))
        n /= 1024


def _parse_gb(s):
    if not s:
        return 0.0
    m = re.search(r"([\d.]+)\s*(TB|GB|MB)?", str(s), re.I)
    if not m:
        return 0.0
    v = float(m.group(1))
    u = (m.group(2) or "GB").upper()
    if u == "TB":
        v *= 1024
    elif u == "MB":
        v /= 1024
    return v


def _match_label(path):
    # 归一化：结尾补一个反斜杠，使「文件夹本身」(如 ...\Tencent) 也能匹配 \tencent\ 规则
    p = path.lower().replace("/", "\\").rstrip("\\") + "\\"
    for pat, label in SAFE_MIGRATE_PATTERNS:
        if re.search(pat, p):
            return label
    return None


# v1.7.83（迁移覆盖度修复·2026-10-04）：体积优先兜底准入。
# 起因：老李本机实测 16 个真实大目录里只有「腾讯」能命中 SAFE_MIGRATE_PATTERNS，
# 其余（WorkBuddy 10.55G / 豆包系 4.07G / ima 1.05G / baidu / 各 AI 工具隐藏目录…）
# 全部 return None 被 `if not label: continue` 直接丢弃 → 明明能搬 26GB，报告只显示 4.9GB。
#
# 为什么这样改是安全的（与「清理」的根本区别）：
#   迁移 = 复制 → 校验字节一致 → 改名 → 建 junction，不删除任何数据、失败即还原；
#   清理 = 直接删除，误判不可逆。所以「白名单」这种宁错放的策略只该用于清理，
#   迁移侧用同样的白名单，等于把 100GB 里的几十 GB 活数据关在门外。
# 本兜底**只负责让目录通过 label 门槛**，后续所有安全拦截（个人目录 / 需管理员 /
# Temp / 白名单排除表）一条不少地照常执行；且额外排除「装程序的目录」与
# 「该清的缓存目录」，避免把软件本体或垃圾目录错误地当成搬家对象。
MIGRATE_FALLBACK_MIN_KB = 512 * 1024   # 兜底门槛 512MB
# 为什么是 512MB 而不是 1GB：v1.7.83 初版定 1GB，本机实测把 OpenAI(640MB) 这类
# 真实活数据卡在门外——门槛定高了就等于「白名单换了个马甲」，仍是漏扫。
# 512MB 是「搬一次值得、又不会把报告塞满」的平衡点（1GB 门槛实测漏掉 640MB 的
# OpenAI 数据目录）。真正的稀释风险由「只取 AppData 第一层子目录」+ 容器排除
# + 缓存/本体排除表共同控制，不需要靠体积门槛兜。
# 该清的目录（缓存/临时/更新包）——它们是「删」的对象，绝不该列进搬家清单
_MIGRATE_NOT_CACHE_SEGMENTS = (
    "\\cache", "\\caches", "\\temp", "\\tmp", "\\temporary", "\\log", "\\logs",
    "\\crash", "\\crashpad", "\\dump", "\\dumps", "\\update", "\\updates",
    "\\update\\", "\\patch", "\\installer", "\\download", "\\downloads",
    "\\pip", "\\conda", "\\npm", "\\yarn", "code cache", "\\gpu cache",
    "\\shadercache", "\\thumbnails", "\\thumbcache", "\\webcache",
)
# 软件本体目录（搬走会让升级/启动出问题，应走「卸载/改装到 D 盘」而非 junction）
_MIGRATE_NOT_APP_SEGMENTS = (
    "\\python", "\\python3", "\\windows", "\\microsoft", "\\office",
    "\\onedrive", "\\edge", "\\chromium", "\\node_modules", "\\.git",
    "\\site-packages", "\\conda", "\\anaconda",
)
# 「段名本身即纯缓存根」的目录：它们的价值全在清（删了自动重下），搬去 D 盘
# 只是把垃圾换个地方占着。§③ 的子串表拦不住这类——被扫的候选是根目录本身，
# 缓存（\cache）在它【里面】。实测本机 uv 3.66GB 100% 在 uv\cache。
_MIGRATE_PURE_CACHE_ROOTS = frozenset({
    "uv", "pip", "npm", "yarn", "pnpm", "node-gyp", "go-build",
    "ms-playwright", ".npm", ".gradle", ".cargo", ".nuget", ".m2", ".pnpm",
    "npx", "conda", "electron", "cypress", "jest", "playwright",
})
# 「工具自身工作区」黑名单：这些目录被 agent/工具实时读写，**搬走等于把脚下地板抽走**。
# 见 _is_self_workspace 的详细论证。
_SELF_WORKSPACE_NAMES = frozenset({
    "workbuddy", "codebuddy", ".workbuddy", ".codebuddy",
})


# 「容器目录」黑名单：这些目录**本身**绝不能当搬家对象。
# v1.7.83 修实测发现的致命 bug：兜底把 C:\Users\LQN\AppData 整个（22.2GB）当成
# 一个搬家候选——搬走它等于把所有软件的配置/登录态/正在运行的程序的数据根
# 整体挪到 D 盘，junction 也救不回来（大量程序硬编码 %APPDATA% 且会重解析子路径，
# 迁移中途任何一次软件自更新/修复都可能把数据写回旧位置或直接报错）。
# 规则：**只搬容器下面的东西，绝不搬容器本身**。
_MIGRATE_NEVER_MOVE_SEGMENTS = frozenset({
    "appdata", "local", "roaming", "locallow", "programdata",
    "application data", "local settings", "cookies",
    "users", "windows", "program files", "program files (x86)",
    "desktop.ini", "temp", "tmp",
})


def _is_container_dir_itself(path):
    """path 是否就是「容器目录本身」（AppData / Local / Roaming / 用户根 …）。

    命中即禁止当迁移候选——只允许搬容器**下面**的单个软件目录。
    搬容器 = 搬走所有软件的数据根，junction 也救不回来（实测踩过：
    曾把 C:\\Users\\LQN\\AppData 整个 22.2GB 列为搬家候选）。

    判据（按可靠性排序，命中任一即「容器本身」）：
      ① 该目录**本身就是**已知容器根：%APPDATA% / %LOCALAPPDATA% / LocalLow /
         AppData / ProgramData / 用户根 / Windows / Program Files ——
         用「路径相等」而非「父目录名匹配」，绝不受用户名/盘符影响。
      ② 它是上述容器的**直接子级**且自身名字也在容器名表里
         （如 ...\\AppData\\Local、...\\AppData/Roaming）——同样是容器，不是软件。
    非容器名的普通目录（Local\\Doubao、Roaming\\baidu）一律放行。
    """
    try:
        p = os.path.normcase(os.path.normpath(os.path.abspath(path)))
    except Exception:
        return False
    if not p:
        return True
    profile = os.path.normcase(os.path.normpath(os.path.expanduser("~")))
    local_env = os.environ.get("LOCALAPPDATA", "")
    roaming_env = os.environ.get("APPDATA", "")
    local_low = os.path.join(profile, "AppData", "LocalLow")

    # ① 本身就是已知容器根（路径相等判定，稳）
    _roots = {x for x in (profile, local_env, roaming_env, local_low,
                          os.path.join(profile, "AppData"),
                          os.environ.get("ProgramData", ""),
                          os.environ.get("SystemRoot", r"C:\Windows"),
                          os.environ.get("ProgramFiles", r"C:\Program Files")) if x}
    _roots = {os.path.normcase(os.path.normpath(x)) for x in _roots}
    if p in _roots:
        return True

    # ② 容器名目录，且父目录也是容器/用户根 → 它是容器的下一层容器，仍非软件目录
    segs = [s for s in p.split(os.sep) if s]
    if len(segs) >= 2 and segs[-1].lower() in _MIGRATE_NEVER_MOVE_SEGMENTS:
        parent = os.sep.join(segs[:-1])
        if parent in _roots:
            return True
    return False


def _is_self_workspace(path):
    """path 是否是**本工具自己**正在使用的工作区/安装目录（绝不能当迁移对象）。

    v1.7.83（实测抓到的致命风险）：兜底把 C:\\Users\\LQN\\WorkBuddy（10.8GB）
    列为迁移候选第一位 —— 而那正是 WorkBuddy agent 自己的工作区！
    工具运行中把自己的工作区搬到 D 盘，等于把脚下地板抽走：
      · 当前会话的读文件/写文件全部落到 junction 后的 D 盘，行为诡异；
      · 工具自身若因任何原因重启/回滚，工作区路径消失 → 直接不可用；
      · 违反「工具不得动用户的系统与自身运行环境」这条底线。
    与容器黑名单同级：这是**自身安全**红线，不因体积大而豁免。

    判据（任一命中即拒）：
      ① 路径位于当前进程工作目录 / 脚本所在 skills 目录的上层（即工具自身树）；
      ② 路径是 WorkBuddy / CodeBuddy 等**开发工具自身**的数据根
         （这些目录被 agent 实时读写，junction 切换期间必然出问题）；
      ③ 路径位于本工具部署目录（%USERPROFILE%\\.workbuddy）之内。
    """
    try:
        p = os.path.normcase(os.path.normpath(os.path.abspath(path)))
    except Exception:
        return True   # 判不清就当"是"，宁可不迁
    try:
        cur = os.path.normcase(os.path.normpath(os.getcwd()))
        here = os.path.normcase(os.path.normpath(
            os.path.dirname(os.path.abspath(__file__))))
    except Exception:
        cur = here = ""
    # ① 工作区自身：cwd 本身、cwd 的父目录（WorkBuddy 这类容器根）、skills 部署树
    _tool_roots = {x for x in (cur, os.path.dirname(cur), here,
                               os.path.dirname(here)) if x}
    _tool_roots |= {os.path.normcase(os.path.normpath(os.path.join(x, "skills")))
                    for x in list(_tool_roots)}
    for r in _tool_roots:
        if p == r or p.startswith(r + os.sep) or r.startswith(p + os.sep):
            return True
    # ② 开发工具自身的数据根（agent 实时读写）
    segs = [s.lower() for s in p.split(os.sep) if s]
    if segs and segs[-1] in _SELF_WORKSPACE_NAMES:
        return True
    # ③ %USERPROFILE%\.workbuddy（工具部署/记忆/会话根）之内
    wb = os.path.join(os.path.expanduser("~"), ".workbuddy")
    wb = os.path.normcase(os.path.normpath(wb))
    if p == wb or p.startswith(wb + os.sep):
        return True
    return False


# 「源码/开发工程」黑名单段名：命中即拒（绝不迁移）。
#
# ===== v1.7.85 实测抓到的第三根因 =====
# 兜底准入把 C:\Users\LQN\dsh（522MB）收进迁移清单，实测内容是：
#     node_modules + pnpm 布局（.ajv-zTLHelwo / .base64-js-EgdFJJg 这种随机后缀）
#     13946 个目录 / 62552 个文件 / 最深 13 层 / .ts .js .map .mjs 为主
# 它是一个**正在用的 node 开发工程**，不是任何软件的缓存或数据。
#
# 为什么必须拒（三条硬理由，不是「搬不动所以别搬」这种托辞）：
#   ① **搬走等于毁掉用户的工程环境**。node_modules 里有 pnpm 的 store 硬链接与
#      .bin 符号链接，跨盘 junction 后链接语义变化，`pnpm install`/构建会直接报错。
#      用户装这个 skill 是为了腾 C 盘，不是为了把自己的项目搞坏。
#   ② **这类目录是「活的」**。实测 D 盘落点在 22:25:38 仍有写入而 C 盘源 mtime
#      停在 8-15 —— 用户在迁移过程中还在改代码/跑构建。搬正在被写的工程目录 =
#      产出静默损坏的文件。
#   ③ **它是海量小文件**（62552 文件 / 8.5KB 均值 / 13 层深），实测仅 19 文件/秒。
#      这类目录会让整批迁移被单项拖住，老李实测整批卡了 4h48m 而其中 9 项早已搬完。
# 与「容器黑名单」「自身工作区」同级：这是**用户资产安全**红线。
_DEV_PROJECT_SEGMENTS = frozenset({
    "node_modules", "src", "source", "sources", "packages", "apps",
    "venv", ".venv", "virtualenv", "site-packages", ".git", ".svn", ".hg",
    "target", ".gradle", "cmake-build-debug", "cmake-build-release",
    ".next", ".nuxt", ".output", "dist-new", "vendor", "third_party",
})


def _is_dev_project(path):
    """path 是否是**用户的源码/开发工程目录**（绝不能当迁移对象）。

    与 _is_self_workspace 的区别：那一条护的是「本工具自己」，
    这一条护的是「用户的开发项目」——性质同样是不可碰的用户资产。

    判据（任一命中即拒）：
      ① 路径任一段是开发工程特征段名（node_modules/src/.git/venv…）；
      ② 路径自己就在某个 node_modules 之下（那是依赖树的一部分）；
      ③ 目录里同时存在【工程标志文件】+【源码目录】（package.json+src、
         pom.xml+src、go.mod…）—— 交叉验证，避免把普通软件数据目录误杀。
    """
    try:
        p = os.path.normcase(os.path.normpath(os.path.abspath(path)))
    except Exception:
        return True   # 判不清就当"是"，宁可不迁
    # ① / ② 段名命中
    segs = [s.lower() for s in p.split(os.sep) if s]
    for s in segs:
        if s in _DEV_PROJECT_SEGMENTS:
            return True
    # ③ 工程标志文件交叉验证（只列目录，IO 极小，不遍历内容）
    try:
        if not os.path.isdir(p):
            return False
        entries = set()
        with os.scandir(p) as it:
            for e in it:
                try:
                    entries.add(e.name.lower())
                except Exception:
                    pass
    except Exception:
        return False
    _marks = ("package.json", "pom.xml", "build.gradle", "go.mod", "cargo.toml",
              "pyproject.toml", "requirements.txt", "cmakelists.txt", ".csproj")
    _srcdirs = ("src", "source", "sources", "lib", "app", "apps", "packages")
    if (entries & set(_marks)) and (entries & set(_srcdirs)):
        return True
    # node_modules 直接躺在候选根下 —— pnpm/yarn 的项目根，一样是工程
    if "node_modules" in entries:
        return True
    return False


def _migrate_volume_fallback(path, kb):
    """白名单认不出来时的「体积优先」兜底：够大 + 属于可搬容器 + 不该清不搬 → 放行。

    返回可用的 label（形如 "generic:workbuddy"，保证 merge_candidates 按目录独立成组，
    不会把 WorkBuddy/豆包/ima 合成一个搬不了的 20GB 巨无霸），不满足返回 None。

    安全边界（缺一不可）：
      ⓪ **绝不动容器本身**（AppData / Local / Roaming / 用户根 …）——见
        _is_container_dir_itself。搬容器 = 搬走所有软件的数据根，junction 也救不回来。
        这是实测抓到的致命 bug，不是理论担忧。
      ⓿bis **绝不搬工具自身工作区**（WorkBuddy / CodeBuddy / ~/.workbuddy …）——
        见 _is_self_workspace。实测本机 C:\\Users\\LQN\\WorkBuddy（10.8GB）一度
        被列为候选第一位，而那正是 agent 自己的工作区，搬走等于抽掉脚下地板。
      ① 体积 ≥ 1GB —— 免得把一堆 30MB 的碎目录塞进报告，稀释用户注意力；
      ② 必须位于「可搬容器」内：AppData\\Local / AppData/Roaming / 用户根下的
         非个人目录（工具/应用数据区），个人文档目录一律不碰（由 _is_personal_root 兜底）；
      ③ 路径段命中缓存特征 → 拒（那是「清」的对象）；
      ④ 路径段命中软件本体特征 → 拒（那是「卸载」的对象）；
      ⑤ *.migrated.bak / *-updater 结尾 → 拒（前者是自身迁移残留该清、后者是更新包该清）。
    """
    if kb < MIGRATE_FALLBACK_MIN_KB:
        return None
    if _is_container_dir_itself(path):
        return None
    if _is_self_workspace(path):
        return None
    # v1.7.85 第三根因：用户的源码/开发工程绝不当搬家对象。
    # 实测 C:\Users\LQN\dsh（522MB / 62552 文件 / node_modules+pnpm / 13 层深）
    # 被兜底放行进清单，把整批迁移拖成 4h48m，而它是用户的活工程、搬走会毁工程。
    if _is_dev_project(path):
        return None
    try:
        p = os.path.normcase(os.path.realpath(path))
    except Exception:
        return None
    pl = p.lower()
    # ⑤ 自身迁移残留 / 更新包：永远该清，不该搬
    if pl.endswith(".migrated.bak") or "-updater" in os.path.basename(pl):
        return None
    # ③ 缓存特征段：该清不搬
    if any(seg in pl for seg in _MIGRATE_NOT_CACHE_SEGMENTS):
        return None
    # ③.5 段名本身就是纯缓存容器（uv / pip / npm 等工具的缓存根）：
    #   uv 的体积 100% 在 uv\cache 里（实测 3.66GB），搬它等于把缓存搬去 D 盘占着，
    #   而清掉才是真释放。靠 §③ 的 "\cache" 子串是拦不住的——被扫的候选是 uv 本身。
    _base_l = os.path.basename(pl.rstrip("\\/"))
    if _base_l in _MIGRATE_PURE_CACHE_ROOTS:
        return None
    # ④ 软件本体：该卸载/改装，不该 junction
    if any(seg in pl for seg in _MIGRATE_NOT_APP_SEGMENTS):
        return None
    # ② 可搬容器判定
    local = os.path.normcase(os.path.join(os.environ.get("LOCALAPPDATA", ""), "x")).lower()
    roaming = os.path.normcase(os.path.join(os.environ.get("APPDATA", ""), "x")).lower()
    base_local = os.path.dirname(local) if local else ""
    base_roaming = os.path.dirname(roaming) if roaming else ""
    prof = os.path.normcase(os.path.expanduser("~"))
    in_local = bool(base_local) and pl.startswith(base_local + os.sep)
    in_roaming = bool(base_roaming) and pl.startswith(base_roaming + os.sep)
    in_prof_root = pl.startswith(prof + os.sep) and pl.count(os.sep) == prof.count(os.sep) + 1
    if not (in_local or in_roaming or in_prof_root):
        return None
    # AppData 下必须只取「第一层子目录」（如 ...\Local\Doubao），更深层由 find_migratable_deep 负责，
    # 否则会与浅扫结果重复计入（体积翻倍）。
    if in_local or in_roaming:
        rest = pl[len(base_local if in_local else base_roaming) + 1:]
        if rest.count(os.sep) > 1:
            return None
    return "generic:" + os.path.basename(pl.rstrip("\\/"))


def _needs_admin(path):
    """判断该路径迁移是否需要管理员权限（Program Files / ProgramData / Windows）。

    这些目录建 junction 需写权限=管理员；且多为应用本体，应走卸载而非迁移。
    MVP 阶段迁移只做「用户目录内的程序数据」，成功率高、零管理员，避免"打折被骗"。
    """
    p = os.path.normcase(os.path.realpath(path)) if os.path.exists(path) else os.path.normcase(path)
    p = p.lower()
    for root in ("\\program files", "\\programdata", "c:\\windows", "\\windowsapps"):
        if root in p:
            return True
    return False


def _is_personal_root(path):
    """拒绝迁移个人根目录（安全红线）。"""
    prof = os.path.normcase(os.path.realpath(os.path.expanduser("~")))
    p = os.path.normcase(os.path.realpath(path))
    if p == prof or p.startswith(prof + os.sep):
        # 仅允许 AppData / 程序数据子目录，禁止用户可见个人库
        lower = p.lower()
        if any(seg in lower for seg in (
            "\\desktop", "\\pictures", "\\videos",
            "\\music", "\\downloads", "\\onedrive",
        )):
            return True
        # Documents 下允许 WeChat Files / xwechat_files(微信4.0) 等聊天数据迁移，但 Documents 根本身仍禁止
        if "\\documents" in lower:
            if any(seg in lower for seg in (
                "\\wechat files", "\\wechatfiles", "\\wechat_files",
                "\\xwechat files", "\\xwechat_files",
                "\\wexin files", "\\wexin_files",
                "\\weixin files", "\\weixin_files",
            )):
                return False
            return True
        # 用户根目录本身禁止
        if p == prof:
            return True
    return False


def find_migratable(groups, system=None):
    """从扫描结果里找出可安全迁移的大文件夹。

    返回列表：[{name, path, paths, size_kb, size_h, label, display_name, group_key}]，
    已按「父目录优先」去重，并按软件标签合并 Roaming/Local 等多处同源数据。
    """
    cands = []
    seen = set()
    for gkey, items in (groups or {}).items():
        for it in (items or []):
            if it.get("denied"):
                continue
            path = it.get("path")
            if not path or not os.path.isdir(path):
                continue
            kb = float(it.get("size_kb") or 0)
            if kb < MIN_MIGRATE_KB:
                continue
            label = _match_label(path)
            if not label:
                # v1.7.83：白名单认不出来不再直接丢弃，改走体积优先兜底
                # （够大 + 可搬容器 + 不该清不搬 → 放行）。见 _migrate_volume_fallback 的
                # 安全边界说明；下方 _is_personal_root / _needs_admin / Temp 拦截照常执行。
                label = _migrate_volume_fallback(path, kb)
                if not label:
                    continue
            # v1.7.85：开发工程拦截必须放在【白名单与兜底汇合之后】这个公共出口。
            # 之前只挂在 _migrate_volume_fallback 里 —— 那样白名单直收的项会绕过它，
            # 「用户根下的 node 工程恰好命中某条软件特征」时就会被放行，闸门形同虚设。
            if _is_dev_project(path):
                continue
            if _is_personal_root(path):
                continue
            if _needs_admin(path):
                # MVP：跳过 Program Files/ProgramData 等需管理员的目录（走卸载而非迁移）
                continue
            _pl = path.lower().replace("/", "\\")
            if "\\temp\\" in _pl or _pl.rstrip("\\").endswith("\\temp"):
                # Temp 下的数据是临时文件，应「清理」而非「迁移」（迁移了程序会重建）
                continue
            np_ = path.lower().rstrip("\\")
            if np_ in seen:
                continue
            seen.add(np_)
            cands.append({
                "name": it.get("name") or os.path.basename(path.rstrip("\\/")),
                "path": path,
                "size_kb": kb,
                "size_h": it.get("size_h") or _kb_h(kb),
                "label": label,
            })
    return merge_candidates(cands)


# 物理搬家的门槛与类型（与 scan.py find_large_user_files 对齐）
# v1.7.36（审查修复）：此前 scan.py 已把 MOVE_MIN_KB 降到 20MB（20480），但这里仍为
# 50MB，导致 scan 扫出的 20~50MB 大文件在消费端被二次过滤丢弃，v1.7.35「增强2·提高迁移量」
# 实际失效。统一为 20480，保证「扫出来的必能迁」铁律。migrate 只做兜底下限，绝不重复抬高。
MOVABLE_MIN_KB = 20480  # 20MB，与 scan.py MOVE_MIN_KB 严格一致

_OLD_DAYS = 365  # 12 个月（老李拍板）：文件这么久没动过 → 视为「可能早忘了」

def _under_onedrive(path):
    """保守判断 path 是否在 OneDrive 同步目录下。命中返回 True，拿不准一律当普通文件（不误拦）。"""
    try:
        p = os.path.normcase(os.path.abspath(path))
        home = os.path.normcase(os.path.expanduser("~"))
        if os.path.isdir(home):
            for name in os.listdir(home):
                if name.lower().startswith("onedrive"):
                    root = os.path.normcase(os.path.join(home, name))
                    if p == root or p.startswith(root + os.sep):
                        return True
    except Exception:
        pass
    return False

def _file_age_days(path):
    """返回文件最后修改距今天数；取不到返回 -1。"""
    try:
        return (_time.time() - os.path.getmtime(path)) / 86400.0
    except Exception:
        return -1.0


def find_movable_files(groups, system=None):
    """从扫描结果里找可【物理搬去 D 盘】的大用户文件（不涉程序，搬走即真释放 C 盘）。

    这些文件不建 junction（个人文件不需要原路径继续解析），直接 copy→校验→删源，
    比 junction 迁移更简单、零管理员、零丢失。返回 [{name, path, size_kb, size_h,
    label, mode, display_name}]，mode="move" 供 do_migrate / plan_migrations 区分。
    """
    out = []
    seen = set()
    for it in (groups or {}).get("large_user_files") or []:
        path = it.get("path")
        if not path or not os.path.isfile(path):
            continue
        kb = float(it.get("size_kb") or 0)
        if kb < MOVABLE_MIN_KB:
            continue
        np_ = os.path.normcase(os.path.realpath(path))
        if np_ in seen:
            continue
        seen.add(np_)
        age_days = _file_age_days(path)
        out.append({
            "name": it.get("name") or os.path.basename(path),
            "path": path,
            "size_kb": kb,
            "size_h": it.get("size_h") or _kb_h(kb),
            "label": "大文件·搬去D盘",
            "mode": "move",
            "display_name": "大文件·可搬去D盘（不删）",
            "age_days": age_days,
            "is_old": age_days >= _OLD_DAYS,
            "is_onedrive": _under_onedrive(path),
        })
    return out


def _live_fixed_disks(sysdrive):
    """实时枚举本机固定盘（非可移动/网络/U盘），返回 [(name, free_gb), ...]。
    全局适用：当扫描数据缺失盘信息时兜底，保证任意 Windows 客户机都能自动选到可用非系统盘。"""
    out = []
    if sys.platform.startswith("win"):
        try:
            k32 = ctypes.windll.kernel32
            DRIVE_FIXED = 3
            mask = k32.GetLogicalDrives()
            for i in range(26):
                if mask & (1 << i):
                    letter = chr(ord("A") + i)
                    root = letter + ":\\"
                    if root.lower() == sysdrive.lower():
                        continue
                    if k32.GetDriveTypeW(root) != DRIVE_FIXED:
                        continue
                    free = ctypes.c_ulonglong(0)
                    if k32.GetDiskFreeSpaceExW(root, ctypes.byref(free), None, None):
                        gb = free.value / (1024 ** 3)
                        if gb > 0:
                            out.append((root, gb))
        except Exception:
            pass
    else:
        import shutil as _sh
        for mp in ("/Volumes", "/mnt", "/media"):
            if os.path.isdir(mp):
                for name in os.listdir(mp):
                    p = os.path.join(mp, name)
                    try:
                        if os.path.ismount(p):
                            u = _sh.disk_usage(p)
                            gb = u.free / (1024 ** 3)
                            if gb > 0:
                                out.append((p, gb))
                    except Exception:
                        pass
    return out


def pick_target_drive(system):
    """选一个非 C 盘、剩余空间最大的盘作为迁移目标。

    优先用扫描数据；若 system 缺盘信息或所选盘不存在，则实时枚举本机固定盘兜底，
    保证任意 Windows 客户机（含无 D: 盘环境）都能自动选到可用非系统盘（全局健壮性）。
    v1.7.33：改为选择剩余空间最大的非系统固定盘（不再硬编码 D: 优先），
    避免在 E 盘空间更大时仍推荐 D 盘导致目标盘空间不足。"""
    sysdrive = (system or {}).get("disk_name") or "C:\\"
    sysdrive = sysdrive.lower().rstrip("\\") + "\\"

    candidates = []
    for d in (system or {}).get("disks") or []:
        name = (d.get("name") or "").lower().rstrip("\\") + "\\"
        if name == sysdrive:
            continue
        free = _parse_gb(d.get("free"))
        if free > 0:
            candidates.append((name, free))
    # 兜底：扫描数据缺失/不全时实时枚举本机固定盘
    if not candidates:
        candidates = _live_fixed_disks(sysdrive)
    if not candidates:
        return None
    # 选剩余空间最大的非系统盘（v1.33 去掉 D: 硬编码优先）
    candidates.sort(key=lambda x: x[1], reverse=True)
    return candidates[0][0]


def _safe_name(path):
    parts = [p for p in path.rstrip("\\").split("\\") if p]
    tail = "\\".join(parts[-2:]) if len(parts) >= 2 else parts[-1]
    tail = re.sub(r'[<>:"/\\|?*]', "_", tail)
    return tail


def compute_dst(src, mode, target_drive):
    """按 mode 计算迁移目标路径（与 plan_migrations 内逻辑一致，供 server 端按用户所选盘重算）。"""
    if mode == "move":
        try:
            _rel = os.path.relpath(src, os.path.expanduser("~"))
            if _rel.startswith(".."):
                raise ValueError
        except Exception:
            _rel = _safe_name(src)
        return os.path.join(target_drive, "AI_PC_Migrated", "Files", _rel)
    return os.path.join(target_drive, "AI_PC_Migrated", _safe_name(src))


def plan_migrations(cands, target_drive):
    """把候选列表转成执行计划 [{src, dst, size_kb, size_h, label, name, display_name, group_key}]。

    已合并的候选（含 paths 列表）会展开成多条执行记录，但保留同一 group_key 供前端分组展示。
    """
    if not target_drive:
        return []
    plan = []
    for c in cands:
        mode = c.get("mode", "junction")
        subs = c.get("paths") or [c]
        for sub in subs:
            # 兜底：自身/祖先已是 junction → 数据已在 D:，跳过（与 analyze 候选阶段过滤双保险）
            if _under_junction(sub["path"]):
                continue
            # 兜底：上一次迁移残留的 .migrated.bak（与 merge_candidates 双保险，Fix 3）
            # 加强：用「任一路径段以 .migrated.bak 结尾」整棵排除，避免残留目录下的
            # 真实子目录（360se6 / MultiTip…）因叶子不以此结尾而漏网。
            if any(seg.lower().endswith(".migrated.bak") for seg in sub["path"].replace("/", "\\").rstrip("\\").split("\\")):
                continue
            if mode == "move":
                # 物理搬家：保持相对结构放到 AI_PC_Migrated\Files\ 下（不建 junction）
                try:
                    _rel = os.path.relpath(sub["path"], os.path.expanduser("~"))
                    if _rel.startswith(".."):
                        raise ValueError
                except Exception:
                    _rel = _safe_name(sub["path"])
                dst = os.path.join(target_drive, "AI_PC_Migrated", "Files", _rel)
            else:
                dst = os.path.join(target_drive, "AI_PC_Migrated", _safe_name(sub["path"]))
            plan.append({
                "src": sub["path"],
                "dst": dst,
                "size_kb": sub.get("size_kb", c["size_kb"]),
                "size_h": sub.get("size_h", c["size_h"]),
                "label": c["label"],
                "name": c["name"],
                "display_name": c.get("display_name", c["label"]),
                "group_key": c.get("group_key", c["label"]),
                "mode": mode,
                "category": c.get("category", ""),
                "capacity_exceeded": bool(c.get("capacity_exceeded", False)),
            })
    return plan


def _disk_usage(drive):
    """返回 (free_gb, total_gb)；取不到返回 (0.0, 0.0)。全局适用（Windows 优先 ctypes，其他回退 shutil）。"""
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        free = ctypes.c_ulonglong(0)
        total = ctypes.c_ulonglong(0)
        if k32.GetDiskFreeSpaceExW(drive, ctypes.byref(free), ctypes.byref(total), None):
            return free.value / (1024 ** 3), total.value / (1024 ** 3)
    except Exception:
        pass
    try:
        import shutil as _sh
        u = _sh.disk_usage(drive)
        return u.free / (1024 ** 3), u.total / (1024 ** 3)
    except Exception:
        return 0.0, 0.0


def _disk_media_type(drive):
    """检测指定盘符的介质类型：'SSD' / 'HDD' / 'Unknown'（纯只读，不删不改）。

    用途（v1.7.51）：迁移前如实提示 HDD 用户「迁移较慢」，避免对机械硬盘虚假承诺
    ≤2/4/6 分钟 SLA（HDD 物理带宽 ~100MB/s，50G 物理拷贝必超 6 分钟——这是硬件瓶颈，
    软件无解，只能提示用户或引导暂关杀软/加排除）。

    方法：优先 PowerShell Get-PhysicalDisk（Storage 空间 API 的 MediaType 最准），
    失败回退 Win32_DiskDrive model 关键词猜测，再回退 Unknown。单机通常只有一块
    系统盘 + 一块数据盘、类型一致，取首个物理盘类型作近似即可满足预警需求。
    """
    try:
        ps = ("try { "
              "$pd = Get-PhysicalDisk -ErrorAction SilentlyContinue | "
              "Where-Object { $_.MediaType -in @('SSD','HDD') } | Select-Object -First 1; "
              "if ($pd) { $pd.MediaType } else { 'Unknown' } "
              "} catch { 'Unknown' }")
        r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", ps],
                           capture_output=True, text=True, creationflags=CREATE_NO_WINDOW, timeout=15)
        out = (r.stdout or "").strip()
        if out in ("SSD", "HDD"):
            return out
    except Exception:
        pass
    # 回退：Win32_DiskDrive model 关键词猜测
    try:
        r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                            "Get-CimInstance Win32_DiskDrive | Select-Object -First 1 Model"],
                           capture_output=True, text=True, creationflags=CREATE_NO_WINDOW, timeout=15)
        m = (r.stdout or "").lower()
        if any(k in m for k in ("ssd", "nvme", "solid", "m.2", "pcie")):
            return "SSD"
    except Exception:
        pass
    return "Unknown"


# ===== v1.7.94 P0：识别「无人引用的 .previous 垃圾」=====
# 本机实测（2026-10-06）：D:\AI_PC_Migrated 下堆了 41.3GB / 18.4 万文件的 .previous 垃圾。
# 机制根源：`_clean_previous_asides` 只在**迁移成功之后**才被调用（2799 行附近定义、
# 成功路径两处调用）。若某一项反复迁移失败（老李这台机的 Tencent 就是），
# 每轮都会再堆一个 .previous，**永远没人清** → 越攒越多，把目标盘吃干。
#
# ★ 判据（这是「万无一失」的关键，宁可少清也绝不能误删）：
#   只有当 **C 盘原路径已经是 junction** 时，该 .previous 才确定无人引用 ——
#   因为 junction 指向的是 D 盘的主目录（<stem>，不是 <stem>.previous），
#   .previous 里那份是上一轮的旧副本，没有任何程序会读它。
#   原路径**还不是** junction（说明该项尚未迁完）→ **一律不碰**，宁可留着。
def _is_reparse_junction(path):
    """是否是 junction/symlink（reparse point）。判据三重，与 analyze 保持同源口径。"""
    try:
        if os.path.isjunction(path):
            return True
    except Exception:
        pass
    try:
        if os.path.islink(path):
            return True
    except Exception:
        pass
    try:
        import ctypes
        from ctypes import wintypes
        _k = ctypes.WinDLL("kernel32")
        _k.GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
        _k.GetFileAttributesW.restype = wintypes.DWORD
        _a = _k.GetFileAttributesW(path)
        if _a != 0xFFFFFFFF and (_a & 0x400):
            return True
    except Exception:
        pass
    return False


_ASIDE_STALE_DAYS = 7.0
_ASIDE_MAX_SCAN_FILES = 400000


def _aside_name_ts(name):
    """从目录名「.previous.<时间戳>」里解出改名时刻。解不出返回 0。"""
    try:
        _s = str(name or "")
        _i = _s.lower().rfind(".previous.")
        if _i < 0:
            return 0.0
        _tail = _s[_i + len(".previous."):].strip()
        for _f in ("%Y%m%d_%H%M%S", "%Y%m%d%H%M%S", "%Y%m%d"):
            try:
                return float(_time.mktime(_time.strptime(_tail, _f)))
            except Exception:
                continue
    except Exception:
        pass
    return 0.0


def _aside_rename_bound(name, main_dir):
    """这份 .previous 大约是什么时候被改名、撂到一边的。

    ★ 目录自身的 mtime 不能拿来当改名时刻 —— 已实测证伪，记下来免得重犯：
        NTFS 上往子目录里写文件，不会向上更新父目录的 mtime；
        而 rename 一个目录，也不改它自己的 mtime。
        实测拿目录 mtime 当分界，7 份全被误判成「改名后还在被写」，
        假信号最大差 982 小时 —— 差点让 34GB 垃圾永远清不掉。

      真正可用的两个来源：
        A 目录名里的时间戳（工具改名时会带上，如 .previous.20261004_214402）
        B 同级主目录的创建时间（改名后立刻新建主目录来接收迁移数据）
    """
    _a = _aside_name_ts(name)
    _b = 0.0
    try:
        if main_dir and os.path.isdir(main_dir):
            _b = float(os.stat(main_dir).st_ctime)
    except Exception:
        _b = 0.0
    return max(_a, _b)


def _aside_last_write(path, max_files=_ASIDE_MAX_SCAN_FILES):
    """这份目录里最后一次有文件被写入是什么时候。逐个看，不抽样。
    返回 (时间戳, 看了几个文件)。看不出返回 (0.0, n)。"""
    _mx, _n = 0.0, 0
    try:
        for _dp, _dns, _fns in os.walk(path):
            for _f in _fns:
                _n += 1
                if _n > max_files:
                    return _mx, _n
                try:
                    _m = float(os.stat(os.path.join(_dp, _f)).st_mtime)
                except Exception:
                    continue
                if _m > _mx:
                    _mx = _m
    except Exception:
        pass
    return _mx, _n


def _aside_safety(aside_path, src_guess, main_dir, name="",
                  aside_stats=None, main_stats=None):
    """判定一份 .previous 能不能安全删。返回 (safe, reason, level)。

    ★ v1.7.95 判据重做。老李实测：33.5GB 迁移垃圾因判据太窄永远清不掉。

    ★★ 我走过一段弯路，记在这免得以后重犯：
      一开始想用「文件扩展名像不像用户数据」判断能不能删，两次实测都被打脸：
        · .svg 当成用户图片 → 实际是企业微信程序自己的 Flutter 图标
        · .msg 当成 Outlook 邮件 → 实际是 Tcl 语言包 af.msg
        · .png 当成照片 → 实际是 WPS 插件贴图、微信头像缓存
      结论：**看扩展名这条路走不通**，任何扩展名都可能被程序拿去做资源文件。

      正确的问法不是「这文件长得像不像用户数据」，而是：
      **这份数据是不是已经死了（没有任何东西在用它）**。

    四证齐全才删，缺一条就不删 —— 宁可让它占着地方：
      L1 是工具自己撂下的：名字含 .previous + 在迁移根目录里 + 同级有主目录
         → 用户不会手工往这种目录存东西，里面 100% 是程序写入物
      L2 改名之后再没人写过：最晚一次文件写入早于改名时刻
         （改名时刻 = max(目录名时间戳, 同级主目录创建时间)；
           两个都取不到就退化为「最晚写入距今超过 7 天」）
      L3 没有程序正打开它：查不到任何占用进程
      L4 数据另有副本，二选一：
         a C 盘原路径是真实目录且里面有东西 → 数据完整在 C 盘，程序正在用 C 盘
         b D 盘同级主目录存在且里面有东西 → .previous 是被它取代的旧副本

    ★ L4 的 a 不是必须条件。旧判据要求「C 盘原路径已经是联接」才敢删，
      这正是 Tencent 32.9GB 清不掉的根因 —— C 盘原路径是真实目录
      （说明数据完整在 C 盘、程序在用 C 盘），反而更说明 D 盘那份该删。
    """
    # ---- L1：是不是工具自己撂下的 ----
    _nm = name or (os.path.basename(aside_path) if aside_path else "")
    if ".previous" not in str(_nm).lower():
        return False, "目录名里没有 .previous 标记，不是工具撂下的，不碰", "unknown"
    _main_ok = bool(main_dir) and os.path.isdir(main_dir)
    if not _main_ok:
        return False, "同级主目录不存在，没法确认它是被取代的旧副本", "unknown"

    # ---- L4：数据是不是另有副本 ----
    if main_stats is None:
        try:
            main_stats = _dir_stats(main_dir)
        except Exception:
            main_stats = (0, 0)
    _main_files = int(main_stats[0] or 0)
    _c_real, _c_files = False, 0
    try:
        if src_guess and os.path.isdir(src_guess) and not _is_reparse_junction(src_guess):
            _c_real = True
            _c_files = int(_dir_stats(src_guess)[0] or 0)
    except Exception:
        _c_files = 0
    if not (_c_real and _c_files > 0) and _main_files <= 0:
        return False, "C 盘原路径和 D 盘主目录都是空的，不敢删——这份可能是唯一一份", "unknown"

    # ---- L2：改名之后再没人写过 ----
    _bound = _aside_rename_bound(_nm, main_dir)
    _last, _scanned = _aside_last_write(aside_path)
    if _bound > 0:
        if _last > _bound + 60:
            return False, ("改名之后（%s）还有程序在往里写东西（最晚写到 %s），不能删"
                           % (_time.strftime("%Y-%m-%d %H:%M", _time.localtime(_bound)),
                              _time.strftime("%Y-%m-%d %H:%M", _time.localtime(_last)))), "live"
    else:
        _age = ((_time.time() - _last) / 86400.0) if _last > 0 else 0.0
        if _age < _ASIDE_STALE_DAYS:
            return False, "判断不出它是什么时候撂下的，而且最近还有写入，不删", "unknown"

    # ---- L3：有没有程序正打开着它 ----
    try:
        _lockers = who_locks_dir(aside_path, max_files=40) or []
    except Exception:
        _lockers = []
    if _lockers:
        return False, ("还有程序正在用它（%s），不能删"
                       % "、".join([str(x) for x in _lockers[:3]])), "live"

    # ---- 四证齐全 ----
    if _c_real and _c_files > 0:
        return True, ("这份已经是死数据：C 盘原路径还存着 %d 个文件（程序在用 C 盘），"
                      "这份自改名后没人写过，也没有程序占用" % _c_files), "B"
    return True, ("这份已经是死数据：D 盘主目录已有 %d 个文件取代了它，"
                  "这份自改名后没人写过，也没有程序占用" % _main_files), "A"


def find_unreferenced_asides(migrate_root):
    """列出目标盘上的 .previous 目录，并逐份给出「能不能安全删」的判定。

    返回 [{"path", "stem", "size_kb", "files", "src_guess",
           "safe", "reason", "level", "older_round"}]
    ★ 只统计不删除。调用方拿它去决定能不能清。

    ★ v1.7.95：无论 safe 与否都如实统计体积。
      旧实现 safe=False 时把 size_kb 硬编码成 0 ——
      Tencent 那 32.9GB 因此在报告页上完全隐形，用户根本不知道占了地方。
    """
    out = []
    _main_cache = {}
    try:
        if not migrate_root or not os.path.isdir(migrate_root):
            return out
        for _n in os.listdir(migrate_root):
            if ".previous" not in _n:
                continue
            _full = os.path.join(migrate_root, _n)
            if not os.path.isdir(_full):
                continue
            # 反推原始目录名：Roaming_Tencent.previous.20261004_214402 -> Roaming_Tencent
            _stem_full = _n.split(".previous")[0]
            _main_dir = os.path.join(migrate_root, _stem_full)
            _src_guess = _find_appdata_source(_stem_full)
            if _stem_full not in _main_cache:
                try:
                    _main_cache[_stem_full] = _dir_stats(_main_dir)
                except Exception:
                    _main_cache[_stem_full] = (0, 0)
            _fc, _by = _dir_stats(_full)
            _safe, _reason, _level = _aside_safety(
                _full, _src_guess, _main_dir, name=_n,
                aside_stats=(_fc, _by), main_stats=_main_cache[_stem_full])
            # 带时间戳的历史轮次（.previous.<ts>）比裸 .previous 更老
            _tail = _n.split(".previous", 1)[1]
            _older = bool(_tail.lstrip("."))
            out.append({"path": _full, "stem": _stem_full,
                        "size_kb": float(_by or 0) / 1024.0,
                        "files": int(_fc or 0), "src_guess": _src_guess,
                        "referenced": _safe, "safe": _safe,
                        "reason": _reason, "level": _level,
                        "older_round": _older})
    except Exception:
        pass
    return out
def _find_appdata_source(stem_full):
    """由目标盘目录名反查 C 盘源路径。只查 AppData 下常见位置，不做全盘搜索。"""
    try:
        # stem 形如 "Roaming_Tencent" / "Local_DoubaoWork"
        parts = stem_full.split("_", 1)
        if len(parts) != 2:
            return ""
        scope, name = parts[0].lower(), parts[1]
        if scope not in ("roaming", "local", "locallow"):
            return ""
        base = os.environ.get("APPDATA") or os.path.join(
            os.path.expanduser("~"), "AppData", "Roaming")
        root = (base if scope == "roaming"
                else os.path.join(os.path.dirname(base), scope.capitalize()))
        p = os.path.join(root, name)
        return p if os.path.lexists(p) else ""
    except Exception:
        return ""


def _previous_asides_bytes(migrate_root):
    """目标盘上被 .previous 垃圾占用的字节数（只算无人引用的）。

    用于报告页如实告诉用户「看着剩 43GB，其实有 41GB 是迁移垃圾」——
    这正是「是什么就是什么」在容量维度上的体现。
    """
    total = 0.0
    try:
        for _it in find_unreferenced_asides(migrate_root):
            if _it.get("safe") and _it.get("size_kb"):
                total += float(_it["size_kb"]) * 1024.0
    except Exception:
        pass
    return total


# v1.7.94：单项 .previous 删除的硬超时（秒）。实测 68,072 个文件会超过 120s，
# 超过这个时间就放弃这一项 —— 下次启动还会再来，绝不硬等、绝不阻塞启动主链路。
# v1.7.95：整轮清理的总时限（秒）。这是后台 daemon 线程里的等待，
# 不阻塞启动、不阻塞扫描、不阻塞弹窗。
#
# ★ 这一行改过三次方向，三次都是被实测推着改的，别再拍脑袋：
#   ① 120s →装不下 68067 个文件的单项（v1.7.94）
#   ② 1800s→ 实验室测出「并发抢 IO、串行更快」，于是拉长单项时限逼它串行。
#          结果真跑崩了：卡在某一项上，其余 6 份干等，12 分钟只删 7 个文件。
#   ③ 现在：多项并行 + 总时限兜底 —— 单项卡住不再拖累别人。
_PER_PURGE_TIMEOUT_SEC = 1800
# 同时并行清理几份 .previous。
# ★ 设过 1（想让并发额度集中给单份内部的 rd），实测代价很大：
#   7 份串行排队 + 30 分钟总时限 → 只轮到 2 份，剩下 5 份被 cancel 掉。
#   账面上「清理 0 项」，磁盘上却真少了 3.11 GB。宁可让 7 份一起慢慢推进。
_ASIDE_PURGE_WORKERS = 3


# ============================================================================
# ★★★ v1.7.96 P0：迁移垃圾清理【单飞锁】——同一时刻只允许一波清理在跑。
#
# 为什么必须有（2026-10-07 报告页实操事故，不是推理）：
#   run.py 启动时触发的【后台自愈】还没跑完，用户在报告页又点一次「清掉这 27.6 GB」，
#   两波各自对【同一批目录】起 rd。进程列表铁证：同一个目录同时挂着两个 cmd /c rd。
#   后果：NTFS 元数据锁互抢，吞吐 26.7 文件/秒 → 1.3 文件/秒（4.8 万文件要删 10 小时）。
#   对用户来说，这跟「点了没反应」没有区别 —— 而老李的要求是万无一失。
#
# 锁分两层，缺一不可：
#   · 进程内标志：同一个进程里两次调用（线程级并发）；
#   · 跨进程锁文件：run.py 进程 与 server.py 进程是【两个进程】，标志互不可见。
# 锁带 pid + 时间戳：持有者进程死了 / 超时未心跳 → 视为过期，允许接管，绝不死锁。
# ============================================================================
# TTL 2 小时：万一某个 worker 卡死不退，锁也会自己过期，绝不会永久锁死用户。
_ASIDE_CLEAN_LOCK_TTL_SEC = 2 * 3600
_ASIDE_CLEAN_STATE = {"held": False, "path": ""}
# 这一轮提交出去的所有清理任务 —— 用来判断锁能不能放。
_ASIDE_CLEAN_PENDING = []


def _pid_alive(pid):
    """查 pid 是否还活着。只用「查询」权限打开进程，绝不发信号（Windows 上
    os.kill 会真的终止进程，不能拿来做存活探测）。"""
    try:
        import ctypes
        pid = int(pid)
        if pid <= 0:
            return False
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
        if h:
            try:
                code = ctypes.c_ulong(0)
                k32.GetExitCodeProcess(h, ctypes.byref(code))
                return int(code.value) == 259      # STILL_ACTIVE
            finally:
                k32.CloseHandle(h)
        return False
    except Exception:
        return False


def _aside_clean_acquire(base):
    """拿清理锁。返回 (True, "") 或 (False, 原因)。"""
    try:
        if _ASIDE_CLEAN_STATE.get("held"):
            return False, "上一轮清理还在进行中，不用再点，等它跑完即可"
    except Exception:
        pass
    lf = ""
    try:
        lf = os.path.join(base, "aside_clean.lock")
        os.makedirs(base, exist_ok=True)
    except Exception:
        lf = ""
    if lf:
        try:
            if os.path.exists(lf):
                try:
                    import json as _j, time as _t2
                    with open(lf, "r", encoding="utf-8") as f:
                        _d = _j.load(f) or {}
                    _pid = int(_d.get("pid") or 0)
                    _ts = float(_d.get("ts") or 0)
                    if _pid and _pid != os.getpid() and _pid_alive(_pid) \
                            and (_t2.time() - _ts) < _ASIDE_CLEAN_LOCK_TTL_SEC:
                        return False, "上一轮清理还在进行中（进程 %d），不用再点" % _pid
                except Exception:
                    pass
            import json as _j, time as _t2
            _tmp = lf + ".%d.tmp" % os.getpid()
            with open(_tmp, "w", encoding="utf-8") as f:
                _j.dump({"pid": os.getpid(), "ts": _t2.time()}, f)
            try:
                os.replace(_tmp, lf)
            except Exception:
                try:
                    # v1.7.100：_win_delete 直删，避免锁临时文件被安全删除层搬进回收站
                    _win_delete(_tmp)
                except Exception:
                    pass
        except Exception:
            pass
    _ASIDE_CLEAN_STATE["held"] = True
    _ASIDE_CLEAN_STATE["path"] = lf
    return True, ""


def _aside_clean_release():
    try:
        _ASIDE_CLEAN_STATE["held"] = False
    except Exception:
        pass
    try:
        _ASIDE_CLEAN_PENDING[:] = []
    except Exception:
        pass
    lf = ""
    try:
        lf = _ASIDE_CLEAN_STATE.get("path") or ""
    except Exception:
        lf = ""
    if lf:
        try:
            if os.path.exists(lf):
                # v1.7.100：_win_delete 直删（锁文件不留进回收站）
                _win_delete(lf)
        except Exception:
            pass
def auto_cleanup_stale_asides(dry_run=False, on_done=None):
    """v1.7.94：清理**无人引用**的 .previous 迁移垃圾（启动自愈）。

    只清 `find_unreferenced_asides` 判定 safe=True 的那些。判据是「死数据四证」：
      工具自己撂下的 / 改名后无人写过 / 没有程序占用 / 数据另有副本。
    四证缺一**一律跳过**，跳过原因取自判据给出的原文，不做二次加工。

    ★ v1.7.95 修掉了让 33.5GB 永远清不掉的旧判据：
      旧判据要求「C 盘原路径已经是 junction」才敢删，而 Tencent 那份的原路径
      恰恰是**真实目录**（数据完整在 C 盘、程序正在用 C 盘）——
      这本该是「D 盘这份更该删」的证据，旧判据却反过来把它当成「不敢删」。

    返回 {"items": 清理项数, "freed_kb": 释放量, "skipped": 跳过项数, "details": [...]}
    ★ dry_run=True 时只报告不删除（供报告页展示「有多少垃圾可清」）。
    """
    out = {"items": 0, "freed_kb": 0.0, "skipped": 0, "details": [], "freed_gb": 0.0}
    try:
        from license import get_data_dir as _gd
        _base = _gd()
    except Exception:
        _base = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"),
                             "AI_PC_Butler")
    try:
        with open(os.path.join(_base, "last_target_drive.txt"), "r",
                  encoding="utf-8") as f:
            _drv = (f.read() or "").strip().rstrip("\\")
    except Exception:
        _drv = ""
    roots = []
    if _drv:
        roots.append(os.path.join(_drv, "AI_PC_Migrated"))
    # 无记录时也扫一下常见目标盘（只扫 D/E，且只判 safe，绝不做别的）
    for _d in ("D:", "E:"):
        roots.append(os.path.join(_d, "AI_PC_Migrated"))
    # ★ v1.7.96：去重。_drv 是 D: 时 D:\AI_PC_Migrated 会被加两次，
    #   而 find_unreferenced_asides 每扫一次都要 walk 整棵树（8 万文件级），
    #   扫两遍是纯浪费（实测扫描就要 100 秒级）。
    _rk = set()
    _roots2 = []
    for _r in roots:
        try:
            _key = os.path.normcase(os.path.abspath(_r))
        except Exception:
            _key = _r
        if _key in _rk:
            continue
        _rk.add(_key)
        _roots2.append(_r)
    roots = _roots2

    # ★★★ v1.7.96 P0：单飞锁。拿不到就直接返回 busy，绝不起第二波。
    #   （dry_run 只是看看有多少垃圾，不动磁盘，不需要锁。）
    _lock_held = False
    if not dry_run:
        _ok_l, _why_l = _aside_clean_acquire(_base)
        if not _ok_l:
            out["busy"] = True
            out["error"] = _why_l
            return out
        _lock_held = True

    try:
        _seen = set()
        for _root in roots:
            try:
                if not os.path.isdir(_root):
                    continue
                # ★ v1.7.95：先把要删的【全部挑出来】，再并行删。
                #   旧实现是 for 循环里逐项 _do_purge + join —— 完全串行。
                #   实测代价：卡在 kingsoft 余下 1472 个被占用的文件上，12 分钟只动了 7 个，
                #   后面 6 份 Tencent（约 7.9 万文件）一个都没开始。互不相干的东西不该排队。
                _todos = []
                for it in find_unreferenced_asides(_root):
                    if it["path"] in _seen:
                        continue
                    _seen.add(it["path"])
                    if not it.get("safe"):
                        out["skipped"] += 1
                        # ★ v1.7.95：如实转述判据给出的原因，不许写死。
                        #   旧文案写死「原路径还不是 junction」—— 判据换成死数据四证之后
                        #   这句就成了假话。老李要求「是什么就是什么」，假话必须改。
                        out["details"].append({"path": it["path"], "action": "skip_unsafe",
                                               "reason": it.get("reason") or "不满足安全判据",
                                               "size_kb": it.get("size_kb") or 0.0})
                        continue
                    if not it.get("size_kb"):
                        continue
                    if dry_run:
                        out["items"] += 1
                        out["freed_kb"] += float(it["size_kb"])
                        out["details"].append({"path": it["path"], "action": "would_clean",
                                               "size_kb": it["size_kb"]})
                    else:
                        _todos.append(it)

                if _todos:
                    # 大的先开工（大份通常是好删的主体，别让小份占着并发位）
                    _todos.sort(key=lambda z: -(float(z.get("size_kb") or 0)))
                    _lk_o = threading.Lock()
                    _wg = max(1, min(_ASIDE_PURGE_WORKERS, len(_todos)))

                    _settled = set()

                    def _do_purge(_p, _kb):
                        try:
                            fast_purge(_p)
                        except Exception as _pe:
                            with _lk_o:
                                _settled.add(_p)
                                out["details"].append({"path": _p, "action": "failed",
                                                       "reason": repr(_pe)[:180],
                                                       "size_kb": _kb})
                            return
                        # ★ v1.7.95 P0：**不许信「没抛异常」= 删完了**。
                        #   实测 fast_purge 内部把异常全吞了照样返回，外面看到的就是成功，
                        #   磁盘却一个字节没少（7 项 34.35GB 全在，D 盘可用空间纹丝不动）。
                        #   唯一可信的判据是**磁盘现在到底还有没有这个目录**。
                        if os.path.exists(_p):
                            with _lk_o:
                                _settled.add(_p)
                                out["details"].append(
                                    {"path": _p, "action": "timeout", "size_kb": _kb,
                                     "reason": "这轮没删干净（多半正被程序占用），下次启动接着来"})
                        else:
                            with _lk_o:
                                _settled.add(_p)
                                out["items"] += 1
                                out["freed_kb"] += _kb
                                out["details"].append({"path": _p, "action": "cleaned",
                                                       "size_kb": _kb})
                            try:
                                print("[migrate] stale aside cleaned: %s (%.1f MB)"
                                      % (_p, _kb / 1024.0))
                            except Exception:
                                pass

                    # ★ 铁律：绝不用 with ThreadPoolExecutor（shutdown(wait=True) 会 join
                    #   每个 worker，一个卡死就永远出不来，v1.7.88 已吃过这个亏）。
                    _pool = ThreadPoolExecutor(max_workers=_wg)
                    try:
                        _fs = [_pool.submit(_do_purge, t["path"],
                                            float(t["size_kb"])) for t in _todos]
                        # 记下来：锁要等到这些任务全部干完才放，不能超时就放。
                        try:
                            _ASIDE_CLEAN_PENDING.extend(_fs)
                        except Exception:
                            pass
                        try:
                            for f in as_completed(_fs, timeout=_PER_PURGE_TIMEOUT_SEC):
                                try:
                                    f.result()
                                except Exception:
                                    pass
                        except Exception:
                            pass
                    finally:
                        # ★ cancel_futures=False：超时后**不取消**还没轮到的那份，
                        #   让后台把活干完。设 True 时 7 份里 5 份被直接取消，
                        #   磁盘实际释放了 3.11GB，账上却报「清理 0 项」。
                        try:
                            _pool.shutdown(wait=False, cancel_futures=False)
                        except Exception:
                            pass
                    # ★ 临走前按【磁盘实际状态】逐份核账 —— 不管上面的线程跑到哪一步，
                    #   已经删掉的就是删掉了，不许因为超时就记成 0。
                    for t in _todos:
                        _p = t["path"]
                        if _p in _settled:
                            continue
                        _kb = float(t.get("size_kb") or 0)
                        if not os.path.exists(_p):
                            out["items"] += 1
                            out["freed_kb"] += _kb
                            out["details"].append({"path": _p, "action": "cleaned",
                                                   "size_kb": _kb})
                        else:
                            # 还在：如实记「这轮没弄完」，并量一下实际还剩多少
                            try:
                                _fc, _by = _dir_stats(_p)
                                _left_kb = float(_by or 0) / 1024.0
                            except Exception:
                                _left_kb = _kb
                            out["details"].append(
                                {"path": _p, "action": "timeout", "size_kb": _kb,
                                 "left_kb": _left_kb,
                                 "reason": "还剩 %.2f GB 没清完，后台接着清，下次启动也会继续"
                                           % (_left_kb / 1048576.0)})
            except Exception:
                continue
        out["freed_gb"] = round(out["freed_kb"] / 1048576.0, 3)
        try:
            if on_done:
                on_done(out)
        except Exception:
            pass
        return out


    finally:
        # _ASIDE_LOCK_HOLD_V1796
        # 锁什么时候能放？——只有这一轮【所有】清理任务都真的干完了才能放。
        # 因为 as_completed 超时后 worker 仍在后台跑（cancel_futures=False 是故意的：
        # 超时不该把已经删到一半的活掐掉）。此刻放锁 = 用户再点一次又会起第二波。
        if _lock_held:
            try:
                _pend = [f for f in _ASIDE_CLEAN_PENDING if not f.done()]
                if not _pend:
                    _aside_clean_release()
                else:
                    def _release_when_done(_fs):
                        for _f in _fs:
                            try:
                                _f.result()
                            except Exception:
                                pass
                        _aside_clean_release()
                        try:
                            _ASIDE_CLEAN_PENDING[:] = []
                        except Exception:
                            pass
                    threading.Thread(target=_release_when_done,
                                     args=(list(_pend),), daemon=True).start()
            except Exception:
                try:
                    _aside_clean_release()
                except Exception:
                    pass

def route_capacity(cands, target_drive, reserve_pct=0.20):
    """容量闸：把候选分流成「自动迁移 / 因空间不足暂缓（可勾选部分迁移）」。

    铁律（老李拍板 + 2026-08-01 审查修正 P1-B）：
      · 迁移的设计就是「建 junction」：app 数据目录（微信/QQ/腾讯系/WPS/Steam…）默认
        整目录 junction 迁移——原路径变指向其它盘的联接，软件照常用，以后新文件也落其它盘
        （根治 C 盘满）；散落个人大文件（下载/视频/ISO）才走 mode=move（仅释放、非根治）；
      · 空间分配「根治优先」：先填整目录 junction（prog），再填散落个人大文件 mode=move（pers）；
      · 装不下的（含 OneDrive 同步文件）→ deferred_pers（留 C 盘、进迁移卡带
        capacity_exceeded 标记，用户可勾选部分迁移），**绝不进黄区**——「能迁移的
        绝不放黄区（删不删你说了算）」；
      · 程序数据装不下 → deferred_prog（同机制，绝不删）。
    保证两条安全底线：
      1) 绝不把其他盘干爆 —— 目标盘预留 reserve_pct（20%）可用空间；
      2) 绝不删除程序数据 —— 溢出部分只「暂缓迁移」（留 C 盘），绝不清删。
    不依赖任何单机特例，面向任意 Windows 客户机。
    """
    res = {
        "migrated_pers": [], "yellow_pers": [], "migrated_prog": [], "deferred_prog": [],
        "deferred_pers": [],
        "capacity": {"target": target_drive, "reserve_pct": reserve_pct,
                      "free_gb": 0.0, "total_gb": 0.0, "reserve_gb": 0.0, "usable_gb": 0.0},
        "need_external_drive": False,
    }
    if not target_drive:
        # 无目标盘：个人文件与程序数据统一暂缓（留 C 盘、进迁移卡，绝不进黄区）
        for c in cands:
            (res["deferred_pers"] if c.get("mode") == "move" else res["deferred_prog"]).append(c)
        return res

    free_gb, total_gb = _disk_usage(target_drive)
    # 预留空间：固定 10GB 上限（v1.7.33 从 20GB 降到 10GB），小盘按 15% 预留兜底。
    reserve_gb = min(RESERVE_GB, total_gb * 0.15) if total_gb > 0 else RESERVE_GB
    usable_gb = max(0.0, free_gb - reserve_gb)
    res["capacity"].update(free_gb=free_gb, total_gb=total_gb, reserve_gb=reserve_gb, usable_gb=usable_gb)
    if usable_gb <= 0:
        # 目标盘自身已不足预留 → 全部暂缓 + 提示外接硬盘，绝不自动搬、绝不进黄区
        res["need_external_drive"] = True
        for c in cands:
            (res["deferred_pers"] if c.get("mode") == "move" else res["deferred_prog"]).append(c)
        return res

    pers = [c for c in cands if c.get("mode") == "move"]
    prog = [c for c in cands if c.get("mode") != "move"]

    # ===== v1.7.94 P0：容量闸必须按【峰值】算，不是按【净大小】算 =====
    # 【实测坐实的漏洞】2026-10-06 本机查证：route_capacity 全文 "previous"/"aside"
    # 命中 **0 次** —— 它完全不知道迁移过程中目标盘会多出一份副本。
    #
    # 【真实用户会怎么炸】
    #   D 盘剩 25GB，用户想迁一个 10GB 目录：
    #     旧判据：remaining(15GB) >= size(10GB) → **放行**
    #     实际搬运时目标盘旧副本被挪成 .previous → **峰值占 20GB**
    #     → D 盘实际只剩 5GB，远低于 RESERVE_GB=10GB 预留线
    #     → 用户新存的聊天记录写不进去，微信弹「磁盘空间不足」
    # 我们对外承诺「绝不把其他盘干爆」，**这条承诺在 .previous 路径上是破的**。
    # 本机已自证：41.3GB .previous 垃圾就是这么攒出来的。
    #
    # 【修法】prog 类（junction 整目录迁移）按 **ASIDE_PEAK_FACTOR（2.0）倍**计预算：
    #   拷一份到目标 = N；旧副本挪成 .previous = 再一份 N；两份在切换成功前并存，
    #   只有 junction 建好后 _clean_previous_asides 才收掉 .previous。按 N 判必然压破预留。
    # pers 类（散落个人文件 move）只拷不产生副本，仍按 1 倍。
    prog_cost_factor = ASIDE_PEAK_FACTOR
    pers_cost_factor = 1.0
    res["capacity"]["aside_peak_factor"] = prog_cost_factor
    # 已被 .previous 垃圾占住的盘，报告里要如实显示（用户看着 43GB 可能只剩 2GB）
    try:
        _aside_root = os.path.join(target_drive, "AI_PC_Migrated")
        _aside_gb = _previous_asides_bytes(_aside_root) / (1024 ** 3)
    except Exception:
        _aside_gb = 0.0
    res["capacity"]["wasted_aside_gb"] = round(_aside_gb, 2)

    # 根治优先：先填「整目录 junction 迁移」（prog，未来文件也落其它盘 = 根治 C 盘满），
    # 再填「散落个人大文件 mode=move」（pers，仅释放、非根治）。空间不足时优先保住根治项。
    prog_sorted = sorted(prog, key=lambda c: (c.get("size_kb") or 0), reverse=True)
    remaining = usable_gb
    for c in prog_sorted:
        size_gb = (c.get("size_kb") or 0) / (1024 ** 2)
        need_gb = size_gb * prog_cost_factor
        if size_gb > 0 and remaining >= need_gb:
            remaining -= need_gb
            res["migrated_prog"].append(c)
        else:
            try:
                c["need_gb_peak"] = round(need_gb, 2)
            except Exception:
                pass
            res["deferred_prog"].append(c)

    # 散落个人大文件：OneDrive 同步文件不自动搬（会断同步）→ deferred_pers（绝不删）；
    # 其余按年龄降序，能装进 remaining 的自动迁，装不下的进 deferred_pers（可勾选部分迁移）。
    pers_sorted = sorted(pers, key=lambda c: (c.get("age_days") or 0), reverse=True)
    for c in pers_sorted:
        size_gb = (c.get("size_kb") or 0) / (1024 ** 2)
        need_gb = size_gb * pers_cost_factor
        if c.get("is_onedrive") or (size_gb > 0 and remaining < need_gb):
            try:
                c["need_gb_peak"] = round(need_gb, 2)
            except Exception:
                pass
            res["deferred_pers"].append(c)
        else:
            remaining -= need_gb
            res["migrated_pers"].append(c)
    return res


# --------------------------------------------------------------------------
# 执行层
# --------------------------------------------------------------------------
def _run(cmd, timeout=3600):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout, shell=False,
                            creationflags=CREATE_NO_WINDOW)
        out = r.stdout.decode("utf-8", "replace") if isinstance(r.stdout, (bytes, bytearray)) else (r.stdout or "")
        err = r.stderr.decode("utf-8", "replace") if isinstance(r.stderr, (bytes, bytearray)) else (r.stderr or "")
        return r.returncode, out, err
    except Exception as e:  # noqa
        return -1, "", str(e)


def is_admin():
    """判断当前进程是否以管理员身份运行（迁移建 junction 必须）。"""
    try:
        if sys.platform.startswith("win"):
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        return os.getuid() == 0
    except Exception:
        return False


def _create_junction(src, dst):
    """在原位置 src 创建一个指向 dst 的目录联接（junction）。需要管理员。"""
    rc, _out, err = _run(["cmd", "/c", "mklink", "/J", src, dst])
    if rc != 0 and not is_admin():
        # 常见失败原因：未提权。给调用方更明确的提示，便于前端引导用户。
        err = (err or "").strip()
        if not err or "privilege" in err.lower() or "access" in err.lower():
            err = "需要管理员权限才能建立目录联接。请右键以管理员身份运行 WorkBuddy 后重试。"
    return rc == 0, err


def _dir_stats(path, _cache=None):
    """递归统计目录（文件数, 总字节数）。使用 os.scandir 单次 syscall 拿类型+大小，
    比 os.walk + os.path.getsize 快数倍到数十倍（小文件/杀软场景下尤其明显）。"""
    if _cache is not None and path in _cache:
        return _cache[path]
    total = 0
    count = 0
    try:
        for entry in os.scandir(path):
            try:
                if entry.is_dir(follow_symlinks=False):
                    c, b = _dir_stats(entry.path, _cache)
                    count += c
                    total += b
                elif entry.is_file(follow_symlinks=False):
                    count += 1
                    total += entry.stat(follow_symlinks=False).st_size
            except OSError:
                pass
    except OSError:
        pass
    res = (count, total)
    if _cache is not None:
        _cache[path] = res
    return res


def _count_files(path):
    """统计目录内文件总数（用于迁移进度分母）。失败返回 0。"""
    return _dir_stats(path)[0]


def _dir_size_bytes(path):
    """递归统计目录字节大小。失败返回 0。"""
    return _dir_stats(path)[1]


def _schedule_reboot_delete(path):
    """注册「下次重启自动删除」。

    用于迁移成功后 .bak 因被 explorer.exe 占用 shell 扩展 DLL 而 rmtree 失败的场景：
    用 MoveFileExW(path, NULL, MOVEFILE_DELAY_UNTIL_REBOOT) 写入
    HKEY_LOCAL_MACHINE 下的 Session Manager\\PendingFileRenameOperations，Windows 在下次启动时
    递归清理该目录。**需要管理员权限**（要写 HKLM）。

    ===== v1.7.86 修一个「骗用户」的缺陷 =====
    旧注释写着「本服务已是管理员态，满足」—— 那是**假设，不是事实**。
    用户没以管理员身份重开 WorkBuddy 时，MoveFileExW 写 HKLM 失败返回 0，
    旧实现直接 return False，上层却照样显示「已安排重启后自动清理」。
    结果：用户看到「已安排」，满心期待重启，结果文件原封不动躺在 C 盘。
    这与「报告说清得了、实际清不掉」是**同一类欺骗**，只是发生在重启环节。

    现在：把「为什么失败」如实返回，上层据此明确告诉用户「没登记成功 +
    请以管理员身份重开」，绝不默默显示「已安排」。

    返回：(ok, reason) 元组。reason 仅在 ok=False 时有意义（人话，可直接展示）。
    """
    if not sys.platform.startswith("win"):
        return (False, "只有 Windows 才能登记重启后自动清理")
    try:
        import ctypes
        MOVEFILE_DELAY_UNTIL_REBOOT = 0x4
        k32 = ctypes.windll.kernel32
        k32.MoveFileExW.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32]
        k32.MoveFileExW.restype = ctypes.c_int
        rc = k32.MoveFileExW(ctypes.c_wchar_p(_lp(path)), None, MOVEFILE_DELAY_UNTIL_REBOOT)
        if rc != 0:
            return (True, "")
        # rc == 0：查不清具体原因就按最常见的两种归类，如实告诉用户下一步
        if not is_admin():
            return (False, "登记失败：需要管理员权限。请退出 WorkBuddy，右键选择"
                           "「以管理员身份运行」重新打开，再点一次清理")
        return (False, "登记失败：系统拒绝了这次登记（路径可能已被占用或权限不足）。"
                       "这些文件仍在 C 盘，不会丢，重启后你可以手动删掉")
    except Exception as e:
        return (False, "登记失败：%s" % (str(e)[:80] or "系统异常"))


def _reboot_register_count(files):
    """批量登记并**如实返回**（成功数, 失败原因）。

    v1.7.86：旧实现只返回成功数，调用方无从知道「有一部分其实没登记成功」，
    于是照样对用户说「已安排重启后自动清理」。现在把失败原因一起带出去。
    """
    dirs = set()
    try:
        for fp in (files or []):
            try:
                if not os.path.isfile(fp):
                    continue
                d = os.path.dirname(fp)
                if not d:
                    continue
                pl = d.lower().replace("/", "\\")
                if ("\\windows\\system32" in pl or "\\windows\\winsxs" in pl
                        or "\\windows\\servicing" in pl):
                    continue
                dirs.add(d)
            except Exception:
                continue
    except Exception:
        pass
    ok_n = 0
    first_err = ""
    for d in dirs:
        try:
            _ok, _why = _schedule_reboot_delete(d)
        except Exception:
            _ok, _why = False, "登记失败：系统异常"
        if _ok:
            ok_n += 1
        elif not first_err:
            first_err = _why
    return (ok_n, first_err)


def _ensure_reboot_commit(src, bak, real_dst):
    """v1.7.82（过审改造）起：本函数恒返回 False——本工具绝不再注册任何开机/登录自启任务。

    历史行为（v1.7.81 及之前）：通过 schtasks 注册登录任务在重启后自动完成迁移；
    现改为「重启电脑 → 重新打开本工具 → 启动兜底自动补齐」（auto_cleanup_orphan_baks
    会对 junction 已切换的 .migrated.bak 就地补齐零头并清理，零丢失）。
    数据已复制到目标盘且校验一致（do_migrate 零丢失铁律保证），本函数返回 False 时
    调用方走 staged/诚实失败路径，源目录始终未动。保留函数签名仅为兼容调用点。"""
    return False


def _clean_previous_asides(real_dst):
    """切换成功后清理 D 盘上被 AIPC-DST-FOREIGN-FIX 挪开的旧副本暂存
    （real_dst.previous / real_dst.previous.<ts>），避免重复拷贝在 D 盘堆积占满空间。
    只删明确是本次迁移产生的 .previous 暂存，绝不碰用户数据。"""
    try:
        _pd = os.path.dirname(real_dst)
        _stem = os.path.basename(real_dst.rstrip("\\/"))
        for _n in os.listdir(_pd):
            if _n == _stem + ".previous" or _n.startswith(_stem + ".previous."):
                try:
                    fast_purge(os.path.join(_pd, _n))
                except Exception:
                    pass
    except Exception:
        pass


# v1.7.82（过审改造）：v1.7.81 及之前的「用户态计划任务兜底」旗标
# （_recycle_task_registered / _purge_stage_task_registered）已随任务注册通道一并删除。
# 残留清理现改为就地执行（_run_recycle_pending_cleanup / _run_purge_stage_cleanup），
# 并由工具启动兜底（auto_cleanup_orphan_baks）每轮再清扫一遍。


def _recycle_pending_path():
    """精确兜底清单路径：只记录本次改名进回收站的 $R/$I 具体条目（绝不碰用户回收站其他项）。"""
    try:
        import license as _lic
        _d = _lic.get_data_dir()
    except Exception:
        # AIPC-DATADIR-FIX-MIGFB：兜底也走 Roaming + USERPROFILE，杜绝与激活目录分家。
        _base = os.path.join(
            os.environ.get("USERPROFILE") or os.path.expanduser("~"),
            "AppData", "Roaming")
        _d = os.path.join(_base, "AI_PC_Butler")
    try:
        os.makedirs(_d, exist_ok=True)
    except Exception:
        pass
    return os.path.join(_d, "recycle_pending.json")


def _record_recycle_entries(moved_r):
    """把本次搬进回收站的 $R（及对应 $I）追加到精确兜底清单，供工具打开时/迁移后就地定点删除。

    与进程存活、管理员权限都无关：即使 server 在后台删线程完成前退出，C 盘也会在下次登录
    被定点回收，且只动我们自己的 $R/$I，绝不误删用户回收站里其他的（即用户自己删的）文件。
    """
    if not moved_r:
        return
    try:
        _p = _recycle_pending_path()
        _cur = []
        try:
            if os.path.exists(_p):
                with open(_p, "r", encoding="utf-8") as _f:
                    _cur = json.load(_f) or []
                if not isinstance(_cur, list):
                    _cur = []
        except Exception:
            _cur = []
        for _r in moved_r:
            _cur.append(_r)
            try:
                _bn = os.path.basename(_r)
                if _bn.startswith("$R") and len(_bn) > 2:
                    _cur.append(os.path.join(os.path.dirname(_r), "$I" + _bn[2:]))
            except Exception:
                pass
        _seen, _uniq = set(), []
        for _x in _cur:
            if _x not in _seen:
                _seen.add(_x)
                _uniq.append(_x)
        with open(_p, "w", encoding="utf-8") as _f:
            json.dump(_uniq, _f)
    except Exception:
        pass


def _run_recycle_pending_cleanup():
    """立即清理「迁移残留回收站条目」（运行 empty_recycle_pending.ps1）。

    v1.7.82（过审改造）：v1.7.81 及之前是注册【用户态·下次登录】计划任务来执行本清理；
    现已彻底移除任务注册，改为两处就地执行——①每次迁移回收后立即跑一遍（本函数
    的全部调用点）；②工具每次启动时跑一遍（auto_cleanup_orphan_baks），覆盖
    「server 进程在后台删除完成前退出 / 用户重启」的残留场景。
    只删 recycle_pending.json 里记录的我们自己的 $R/$I，绝不碰用户回收站其他文件；
    删不掉的（被锁）留在清单，下次打开工具再重试。幂等、无窗口、失败静默。"""
    if not sys.platform.startswith("win"):
        return False
    try:
        import subprocess as _sp
        _ps1 = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "empty_recycle_pending.ps1")
        if not os.path.exists(_ps1):
            return False
        _sp.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
             "-File", _ps1],
            capture_output=True, text=True, encoding="utf-8", errors="ignore",
            timeout=120, creationflags=CREATE_NO_WINDOW,
        )
        return True
    except Exception:
        return False


def _run_purge_stage_cleanup():
    """立即清空「fast_purge 暂存区（aipc_purge）」（运行 empty_purge_stage.ps1）。

    v1.7.82（过审改造）：v1.7.81 及之前是注册【用户态·下次登录】计划任务（P0 修复：
    server 退出/重启导致暂存区残留永久占 C 盘）；现已彻底移除任务注册，改为两处就地
    执行——①每次 fast_purge 入暂存区后立即跑一遍（本函数的全部调用点）；②工具每次
    启动时跑一遍（auto_cleanup_orphan_baks），保证下次打开工具时 C 盘一定被释放。
    只清空我们自己的 aipc_purge 暂存目录，绝不碰用户其他文件。幂等、无窗口、失败静默。"""
    if not sys.platform.startswith("win"):
        return False
    try:
        import subprocess as _sp
        _ps1 = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "empty_purge_stage.ps1")
        if not os.path.exists(_ps1):
            return False
        _sp.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
             "-File", _ps1],
            capture_output=True, text=True, encoding="utf-8", errors="ignore",
            timeout=120, creationflags=CREATE_NO_WINDOW,
        )
        return True
    except Exception:
        return False


# v1.7.86：v1.7.85 之前的暂存区在 %TEMP%\aipc_purge。修完「暂存区不能放 Temp 里」
# 这个 bug 之后，**新代码改用 C:\aipc_purge，但旧目录里的东西没人管** ——
# _run_purge_stage_cleanup 只清 empty_purge_stage.ps1 指向的那一个路径。
# 结果：从旧版本升级上来的用户，那 2.2GB 会**永远留在 C 盘上**，而且工具自己不知道。
# （本机实测：Temp\aipc_purge 残留 2.2GB / 45 个子项 / 8642 个文件，
#   其中 Doubao.migrated.bak 1208MB、_copytree_bench 593MB —— 后者是我自己的测试目录。）
#
# 修法：启动自愈时把**所有已知历史暂存区**都清一遍。
# 安全性：只清 `aipc_purge` 这个我们自己命名的目录，且只清它的**子项**，
# 绝不碰 Temp 里的其他文件，也绝不删 Temp 本身。
def _purge_stage_dirs():
    """v1.7.100：列出**所有**可能的暂存区目录（真实暂存区 + 历史 %TEMP% 路径）。

    v1.7.85 之前暂存区在 %TEMP%\\aipc_purge；之后改为同卷的 C:\\aipc_purge /
    C:\\ProgramData\\aipc_purge。清理逻辑若只认 %TEMP% 那条老路，现代码真正在用的
    C:\\aipc_purge 就**永远没有启动自愈兜底**——进程被杀/断电/删到一半停下的残留
    会一直占着 C 盘（实测老李机器 C:\\aipc_purge 长期残留几十 MB）。
    """
    _out = []
    try:
        _out.append(os.path.join(_tf.gettempdir(), "aipc_purge"))
    except Exception:
        pass
    for _d in _PURGE_STAGE_CANDIDATES:
        if _d and _d not in _out:
            _out.append(_d)
    return _out


def _is_safe_purge_stage(path):
    """双保险：路径必须以 aipc_purge 结尾，杜绝误删。"""
    try:
        _norm = os.path.normcase(os.path.normpath(path))
    except Exception:
        return False
    return _norm.endswith("\\aipc_purge")


def _cleanup_legacy_purge_stages():
    """清理暂存区（aipc_purge）里的全部残留项。

    v1.7.100：不再只清 %TEMP% 下的历史路径 —— 覆盖 _purge_stage_dirs() 全部候选，
    含当前在用的 C:\\aipc_purge / C:\\ProgramData\\aipc_purge。
    """
    _done = 0
    for _legacy in _purge_stage_dirs():
        if not _is_safe_purge_stage(_legacy) or not os.path.isdir(_legacy):
            continue
        try:
            _names = os.listdir(_legacy)
        except Exception:
            continue
        for _name in _names:
            _p = os.path.join(_legacy, _name)
            try:
                # v1.7.100（真实释放铁律）：文件【必须走 _win_delete】，不能用 os.remove。
                #   原因：部分运行环境会把 os.remove 重定向到回收站 —— 那样只是「把
                #   暂存区里的东西搬进回收站」，文件仍然占着 C 盘，等于没清。
                #   _win_delete 用 DeleteFileW / RemoveDirectoryW / cmd rd 直接删除，
                #   确保空间真正释放。
                #
                #   注意：**不要对已在暂存区里的残留再走 fast_purge**（它会再 rename
                #   一次，造出 p_<pid>_<ts>_p_<pid>_<ts>_... 的嵌套垃圾，实测踩到）。
                #   暂存区里的东西已经在同卷暂存区里了，就地 WinAPI / rd 删即可。
                try:
                    _win_delete(_p)
                except Exception:
                    pass
                # 删不掉的（被占用锁文件，如 INetCache 的 MSIMGSIZ.DAT 被系统服务独占）
                # 登记「重启后删」，否则会永久留在 C 盘占盘。
                if os.path.exists(_p):
                    try:
                        _schedule_reboot_delete(_p)
                    except Exception:
                        pass
                _done += 1
            except Exception:
                continue
        if _done:
            try:
                print("[migrate] purge stage cleaned: %d item(s) cumulative, stage=%s"
                      % (_done, _legacy))
            except Exception:
                pass
    return _done
    """在 root 下按深度找 *.migrated.bak（depth=1 仅直接子项，>1 多探一层）。安全、不抛错。"""
    _out = []
    if not root or not os.path.isdir(root):
        return _out
    try:
        for _d in os.listdir(root):
            _p = os.path.join(root, _d)
            if _d.lower().endswith(".migrated.bak"):
                _out.append(_p)
            elif depth > 1 and os.path.isdir(_p):
                try:
                    for _e in os.listdir(_p):
                        if _e.lower().endswith(".migrated.bak"):
                            _out.append(os.path.join(_p, _e))
                except Exception:
                    continue
    except Exception:
        pass
    return _out


def _cleanup_legacy_tasks():
    """v1.7.82（过审改造）：清理旧版本（v1.7.81 及之前）遗留在用户电脑上的 AIPC_* 计划任务。

    本工具从 v1.7.82 起绝不再创建任何计划任务；本函数只做【清理】——枚举系统任务表，
    把旧版本注册的 AIPC_* 任务逐个删除（对不存在的任务 /delete 无副作用）。升级用户
    的电脑由此彻底告别本工具的开机/登录任务。枚举与删除全程静默、best-effort。"""
    try:
        import subprocess as _sp
        _r = _sp.run(["schtasks", "/query", "/fo", "csv", "/nh"],
                     capture_output=True, text=True, encoding="utf-8", errors="ignore",
                     timeout=30, creationflags=CREATE_NO_WINDOW)
        for _line in (_r.stdout or "").splitlines():
            _line = _line.strip()
            if not _line.startswith('"') or "AIPC_" not in _line:
                continue
            try:
                _tn = _line.split('","')[0].strip().strip('"')
                _tn = _tn.rsplit("\\", 1)[-1]  # 兼容「主机名\任务名」/「\任务名」两种 CSV 形态
                if _tn.startswith("AIPC_"):
                    _sp.run(["schtasks", "/delete", "/tn", _tn, "/f"],
                            stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
                            timeout=20, creationflags=CREATE_NO_WINDOW)
            except Exception:
                continue
    except Exception:
        pass


def auto_cleanup_orphan_baks():
    """启动兜底（v1.7.82 重写）：工具每次打开时自动完成迁移收尾，不再依赖任何计划任务。

    ① 扫描用户目录常见根下的 *.migrated.bak：
       - junction 已切换（主体已在目标盘）的：先 _complete_bak 就地补齐被锁零头
         （零丢失铁律：只删目标盘已有同名同大小的文件），补齐后 classify 确认安全才清进回收站；
         仍被锁的文件留在 .bak，下次打开工具再补——这就是「重启电脑 → 重新打开本工具
         → 自动完成收尾」的落地实现；
       - junction 未建立的：源还没切换，等用户重试迁移处理，本兜底仅按 classify 安全口径清理。
    ② 立即清扫「迁移残留回收站条目」与「fast_purge 暂存区」（v1.7.81 及之前由
       「下次登录」计划任务负责，现已改为就地执行）。
    ③ 清理旧版本遗留在用户电脑上的 AIPC_* 计划任务（只删不建，见 _cleanup_legacy_tasks）。
    ①②③ 全部在后台 daemon 线程执行，绝不阻塞启动；全程 try/except，绝不抛错、绝不删不安全项。
    """
    def _bg():
        try:
            # v1.7.86：先清扫暂存区残留。
            # v1.7.100：_cleanup_legacy_purge_stages 已覆盖**全部**候选暂存区
            #   （%TEMP%\aipc_purge 历史路径 + 当前在用的 C:\aipc_purge /
            #   C:\ProgramData\aipc_purge）。原实现只清 %TEMP% 那条老路，
            #   现代码真正在用的 C:\aipc_purge 反而没有启动兜底 —— 进程被杀/断电/
            #   删到一半停下的残留会长期占着 C 盘（实测老李机器 C:\aipc_purge 残留数十MB）。
            try:
                _cleanup_legacy_purge_stages()
            except Exception:
                pass
            _up = os.environ.get("USERPROFILE") or os.path.expanduser("~")
            _shallow = [os.path.join(_up, d) for d in ("", "Documents", "Desktop",
                                                       "Downloads", "Pictures", "Videos", "Music")]
            _deep = [os.path.join(_up, "AppData", "Roaming"),
                     os.path.join(_up, "AppData", "Local"),
                     os.path.join(_up, "AppData", "LocalLow")]
            _found = []
            for _r in _shallow:
                _found += _scan_bak_one(_r, 1)
            for _r in _deep:
                _found += _scan_bak_one(_r, 2)
            _found = list(dict.fromkeys(_found))
            _plain_safe = []          # junction 未建立、但 classify 判定可直接安全清理的
            for _b in _found:
                try:
                    _jok, _why, _src, _dst = classify_bak_residual(_b, check_files=False)
                    if _dst and os.path.exists(_dst):
                        # junction 已切换：就地补齐零头（重开工具自动收尾的核心），补齐后才清理
                        try:
                            _complete_bak(_b, _dst)
                        except Exception:
                            pass
                        try:
                            _safe_b, _w2, _s2, _d2 = classify_bak_residual(_b)
                            if _safe_b:
                                recycle_bin_fast_purge([_b], empty_full_bin=False)
                        except Exception:
                            pass
                    else:
                        try:
                            _safe_b, _why2, _src2, _dst2 = classify_bak_residual(_b)
                            if _safe_b:
                                _plain_safe.append(_b)
                        except Exception:
                            continue
                except Exception:
                    continue
            if _plain_safe:
                recycle_bin_fast_purge(_plain_safe, empty_full_bin=False)
            # 原计划任务兜底职责 → 就地清扫
            try:
                _run_recycle_pending_cleanup()
            except Exception:
                pass
            try:
                _run_purge_stage_cleanup()
            except Exception:
                pass
            # 旧版本遗留任务清理（只删不建）
            _cleanup_legacy_tasks()
        except Exception:
            pass
    try:
        import threading as _th
        _th.Thread(target=_bg, daemon=True, name="aipc-startup-cleanup").start()
    except Exception:
        pass


def _schedule_reboot_complete(bak, dst):
    """v1.7.82（过审改造）起：本函数恒返回 False——绝不再注册任何开机/登录自启任务。

    历史行为（v1.7.81 及之前）：为主体已切换 junction、零头被占用的 partial 项注册
    「下次登录自动补齐」任务；现改为「重启电脑 → 重新打开本工具 → 启动兜底自动补齐」：
    auto_cleanup_orphan_baks 会对 junction 已切换的 .migrated.bak 调 _complete_bak
    就地补齐（只删目标盘已有同名同大小的文件，零丢失）。保留函数签名仅为兼容调用点。"""
    return False


def _log_rm(src, lockers):
    """客观取证：把 rename 失败时的真实占用进程写到调试日志（仅追加，不影响主流程）。
    用于上线后定位『到底是哪个进程在锁』，避免靠猜。"""
    try:
        import datetime
        here = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(here, "AIPC_RM_DEBUG.log"), "a", encoding="utf-8") as f:
            f.write("[%s] rename blocked: %s -> lockers=%s\n" % (
                datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), src, lockers))
    except Exception:
        pass


def _rm_release(src):
    """精准释放握持本目录的进程（Restart Manager），子进程隔离以保证主进程不崩溃。

    返回占用者名单（用于取证与提示）或 None（失败/非提权/不可用）。
    真正的 C 层调用在 _rm_helper.py 子进程里执行——即使它崩溃也只是子进程死掉，
    主迁移进程通过 returncode 感知后安全走兜底（L3 重启提交 / 诚实失败），绝不连累主迁移。"""
    try:
        import json as _json
        here = os.path.dirname(os.path.abspath(__file__))
        helper = os.path.join(here, "_rm_helper.py")
        if not os.path.exists(helper):
            return None
        r = subprocess.run(
            [sys.executable, helper, "release", src],
            capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=40,
            creationflags=CREATE_NO_WINDOW,
        )
        if r.returncode != 0:
            return None
        data = _json.loads(r.stdout.strip() or "{}")
        return data.get("lockers")
    except Exception:
        return None


# v1.7.82（过审改造）：原 _reboot_commit_script / _schedule_reboot_commit（经 _rm_helper
# 子进程注册 schtasks 开机任务 + MoveFileEx 开机改名）已整体删除，迁移收尾改为
# 「重启电脑 → 重新打开本工具 → 启动兜底自动补齐」，不再注册任何开机/登录自启任务。


def _detect_av_filters():
    """通过 fltmc 检测是否装有会拦截目录改名的第三方杀毒/安全软件内核过滤驱动。

    返回可读的杀毒产品名列表（空=未检出）。仅用于给用户诚实的失败原因，不做任何改动。
    实测：fltmc instances 在普通提权下可读；但 fltmc unload 对受保护驱动被拒（0x801f0010），
    即这类驱动无法在用户态强制卸载——这正是迁移改名的终极挡路石。"""
    try:
        r = subprocess.run(["fltmc", "instances"], capture_output=True,
                           text=True, encoding="utf-8", errors="ignore", timeout=20,
                           creationflags=CREATE_NO_WINDOW)
        out = (r.stdout + r.stderr).lower()
    except Exception:
        return []
    prods = []
    if any(k in out for k in ("360fsflt", "360antisteal", "360box64", "360qpesv",
                              "sysdiag", "dsark", "360")):
        prods.append("360安全卫士")
    # fltmc 里阿里驱动的实例名未必含 alibaba/mphelper，故再补进程级检测
    try:
        pr = subprocess.run(["tasklist", "/FO", "CSV"], capture_output=True,
                            text=True, encoding="utf-8", errors="ignore", timeout=20,
                            creationflags=CREATE_NO_WINDOW).stdout.lower()
        if any(k in pr for k in ("alibabaprotect", "mphelper")):
            prods.append("阿里杀毒(AlibabaProtect)")
    except Exception:
        pass
    if "阿里杀毒(AlibabaProtect)" not in prods and any(k in out for k in ("alibabaprotect", "mphelper")):
        prods.append("阿里杀毒(AlibabaProtect)")
    # Windows Defender（微软内置杀毒，实时防护默认开；其 WdFilter 驱动会拦截改名）
    if ("wdfilter" in out or "msmpen" in pr) and "Windows Defender" not in prods:
        prods.append("Windows Defender(微软内置杀毒)")
    # 其他常见第三方杀毒（本机未装，仅作通用覆盖）
    for kw, nm in (("avp", "卡巴斯基"), ("ksafe", "金山毒霸"),
                   ("zhudongfangyu", "360主动防御"), ("norton", "诺顿"),
                   ("mcafee", "迈克菲"), ("ahu", "火绒")):
        if kw in out and nm not in prods:
            prods.append(nm)
    return prods


def _acl_normalize(src):
    """对 src 做 ACL 规范化（取得所有权 + 授予当前用户完全控制），覆盖『权限拒绝型』改名失败
    （winerror=5 且非受保护杀软驱动时，多为子文件所有者/ACL 被设为拒绝管理员 DELETE）。
    返回 True 表示执行成功（不管是否真的解决）。大目录可能耗时数分钟（takeown /R 递归）。"""
    try:
        user = os.environ.get("USERNAME") or "LQN"
        subprocess.run(["takeown", "/F", src, "/R", "/D", "Y"],
                       capture_output=True, timeout=900,
                       encoding="utf-8", errors="ignore",
                       creationflags=CREATE_NO_WINDOW)
        subprocess.run(["icacls", src, "/grant", user + ":F", "/T", "/C"],
                       capture_output=True, timeout=900,
                       encoding="utf-8", errors="ignore",
                       creationflags=CREATE_NO_WINDOW)
        return True
    except Exception:
        return False


def _relock_rename(src, bak, real_dst, release_locks, quick=False):
    """把 src 改名为 bak（为建 junction 让路），对抗『目录被进程/驱动占用』导致 os.rename 失败。

    quick=True：用于「复制阶段就已知有文件被锁」的场景——此时死磕用户态释放价值不大，
    缩短 L1 轮次并跳过最慢的 L3 全系统句柄枚举（约 26s → 6s），
    避免多项并行时把总耗时拖过 5 分钟。对抗强度不变的完整模式仍用于正常路径。

    分层对抗（全部失败才诚实告知用户，绝不谎报『某个程序』）：
    L1 强制关闭-改名紧循环：release_locks 快速杀白名单进程（微信/QQ 看门狗等）后紧接改名，
       赶在复活窗口前完成；失败再杀再改，循环多轮。
    L2 Restart Manager 精准释放：枚举并强关握持本资源的进程/服务（不限白名单），再连续改名。
       （子进程隔离，崩溃不连累主迁移；占用者名单写入 AIPC_RM_DEBUG.log 客观取证。）
    L3 实测定位真凶：用 lockfinder 全系统句柄枚举找出『真正握持 src 句柄』的进程名（不靠猜），
       同时用 _detect_av_filters 检测受保护杀毒内核驱动；若无非受保护杀软且疑似 ACL 权限型
       （winerror=5），做一次 ACL 规范化（takeown+icacls）再试，覆盖 beacon 类纯权限场景。
    L4（v1.7.82 起恒不成立）：绝不注册任何开机/登录任务，直接落 L5。
    L5 诚实失败：给出可操作的真实原因——若检出受保护杀软驱动，告知用户重启电脑后重开
       本工具重试（重启后内核锁放开），或临时退出杀软/加排除项后重试；
       若 lockfinder 找到普通进程则点名；否则给通用指引。源完好零丢失、不强制。

    返回 dict: {renamed, reboot, lockers, msg}
    reboot 恒为 False（v1.7.82 起：不再有「注册任务后重启自动完成」通道，收尾统一走
    「重启电脑 → 重新打开本工具 → 启动兜底自动补齐」）。字段保留仅为兼容调用点。
    """
    # 清理可能残留的旧 bak，避免改名目标已存在
    # ★ v1.7.94：改后台删 + 短等让路（实测同步删 1.39GB 卡了 37 分钟）
    if os.path.exists(bak):
        try:
            _bg_purge(bak)
        except Exception:
            pass
        for _w in range(12):
            if not os.path.exists(bak):
                break
            _time.sleep(0.1)
        if os.path.exists(bak):
            try:
                os.rename(bak, bak + ".old")
            except Exception:
                pass
    # L1：强制关闭-改名紧循环（赶在看门狗复活窗口前改名成功）
    for _attempt in range(2 if quick else 6):
        if release_locks:
            try:
                release_locks(src)
            except Exception:
                pass
        _time.sleep(0.15)  # 杀完让文件句柄释放
        # 连续快速尝试 rename（0.1s 一次，15 次 ≈ 1.5s，覆盖看门狗复活前的窗口）
        for _ in range(15):
            try:
                os.rename(src, bak)
                return {"renamed": True, "reboot": False, "lockers": [], "msg": ""}
            except OSError:
                _time.sleep(0.1)
    # L2：Restart Manager 精准释放（子进程隔离，崩溃不连累主迁移）
    lm = _rm_release(src)
    if lm is not None:
        if lm:
            _log_rm(src, lm)
        for _ in range(10):
            try:
                os.rename(src, bak)
                return {"renamed": True, "reboot": False, "lockers": lm, "msg": ""}
            except OSError:
                _time.sleep(0.1)
    # L3：实测定位真凶（不再猜进程名）；quick 模式跳过全系统句柄枚举（最慢的一环）
    real_lockers = []
    if not quick:
        try:
            _here = os.path.dirname(os.path.abspath(__file__))
            if _here not in sys.path:
                sys.path.insert(0, _here)
            from lockfinder import find_locking_process_names
            real_lockers = find_locking_process_names(src) or []
        except Exception:
            real_lockers = []
    av = _detect_av_filters()
    # ===== v1.7.93：新增 L2.5 —— 目录级实测占用者（本地进程内，不走子进程）=====
    # 为什么要加这一层（实测 _live_test/probe_relock.py 拿到的硬数据）：
    #   · `_rm_release`（L2，走 _rm_helper 子进程 + RM 释放）实测 **0.7 秒返回 None**
    #     —— 在真锁存在的情况下，它一个占用者都没报出来，等于这一层是坏的；
    #   · 我新加的 `who_locks_dir`（本地 Rstrtmgr，逐文件查）实测 **0.28 秒返回真名**。
    # 所以真凶信息只能靠后者拿。L3 的 lockfinder 在 quick 模式下被跳过，
    # 而非 quick 模式下要跑 26 秒全系统句柄枚举 —— 都不适合快速失败路径。
    #
    # ★ 另一个实测发现：`_detect_av_filters()` 在**本机没装 360** 的情况下返回了
    #   ['360安全卫士','阿里杀毒(AlibabaProtect)']，于是 L5 把原因归给「杀软内核驱动拦截」——
    #   **这是误报，也是一种甩锅**（把原因推给一个不存在的软件）。
    #   因此下面在「没查到进程」时，要先看 who_locks_dir 有没有结果，
    #   有结果就说真名；只有连它也为空，才轮到杀软那个说法，且用词要留余地。
    _dir_lockers = who_locks_dir(src, max_files=24)
    if _dir_lockers and not real_lockers:
        real_lockers = list(_dir_lockers)
    try:
        print("[migrate] relock diag src=%s av=%s rm_release=%s dir_lockers=%s"
              % (src, av, lm, _dir_lockers))
    except Exception:
        pass
    # L3.5：无非受保护杀软且疑似 ACL 权限型（winerror=5 类）→ 规范化后重试，覆盖纯权限场景
    if not av:
        if _acl_normalize(src):
            for _ in range(10):
                try:
                    os.rename(src, bak)
                    return {"renamed": True, "reboot": False, "lockers": real_lockers, "msg": ""}
                except OSError:
                    _time.sleep(0.1)
    # L4：v1.7.82（过审改造）起不再注册任何开机/登录任务，本分支恒不成立，直接走 L5
    # 诚实失败。数据已完整复制到目标盘且校验一致；用户关闭占用程序（或重启电脑）后
    # 重新点击迁移即可秒级完成增量切换，源始终未动、零丢失。
    try:
        if _ensure_reboot_commit(src, bak, real_dst):  # v1.7.82 起恒返回 False（双保险）
            msg = ("无法立即重命名源目录（%s）：数据已完整备在 D 盘。已为你安排——重启电脑后，"
                   "系统会在开机早期自动把该目录切换为联接并释放 C 盘空间，重启前微信/QQ 等软件照常使用，无任何影响。"
                   % (("受保护的杀毒/安全软件（%s）实时防护拦截" % "、".join(av)) if av
                      else "仍有程序占用该目录"))
            return {"renamed": False, "reboot": True, "lockers": (real_lockers or []), "msg": msg}
    except Exception:
        pass
    # L5：诚实失败，给可操作指引
    # ★ v1.7.93 改优先级：**实测到的进程名 > 杀软推测**。
    #   理由（probe_relock.py 实测）：`_detect_av_filters()` 在本机未装 360 时
    #   仍返回 ['360安全卫士','阿里杀毒(AlibabaProtect)'] —— 它是**推测性检测**，
    #   会误报。而 who_locks_dir 是实测。所以查到进程名时必须先说进程名，
    #   绝不能把原因推给一个可能根本不存在的杀软（那也是甩锅）。
    if real_lockers:
        msg = ("无法重命名源：实测到 %s 正占用这个目录。源未改动，数据零丢失。"
               "请关闭该程序后点「补齐剩余」，或重启电脑后重新打开本工具（届时自动接着搬）。"
               % "、".join(real_lockers))
    elif av:
        names = "、".join(av)
        msg = ("无法重命名源：这个文件夹被占用，但我**没能定位到具体是哪个程序**"
               "（系统自带的检测怀疑与 %s 有关，但不一定是它）。源未改动、数据零丢失。"
               "请关闭正在运行的软件后点「补齐剩余」，或重启电脑后重新打开本工具。"
               % names)
    else:
        msg = ("无法重命名源：该文件夹被某程序占用（实测未能定位具体进程名），源未改动，数据零丢失。"
               "请关闭可能占用它的程序后重试；若装有杀毒/安全软件，请将其临时退出或把此文件夹加入排除列表后重试。")
    return {"renamed": False, "reboot": False, "lockers": (real_lockers or lm or []),
            "msg": msg}


def _move_with_progress_fallback(src, dst, on_progress=None, total_mb=1, deadline=None):
    """兜底：逐文件并发移动。返回 True 表示 src 已不存在。"""
    import threading, time as _t
    from concurrent.futures import ThreadPoolExecutor, as_completed

    files = []
    try:
        for _dp, _dn, _fn in os.walk(src):
            for _f in _fn:
                files.append(os.path.join(_dp, _f))
    except Exception:
        pass
    if not files:
        try:
            shutil.move(src, dst)
            return True
        except Exception:
            return False

    total = len(files)
    if on_progress and total:
        try:
            on_progress(0, total_mb, src)
        except Exception:
            pass

    done_cnt = {"n": 0}
    lock = threading.Lock()
    last_emit = [0.0]

    def _worker(fp):
        rel = os.path.relpath(fp, src)
        target = os.path.join(dst, rel)
        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            shutil.move(fp, target)
            return True
        except Exception:
            return False

    # ===== v1.7.91：修回退路径卡死（老李 2026-10-06 破坏性实测揪出）=====
    # 病根：原实现用 `with ThreadPoolExecutor` + `as_completed` 遍历等**全部** future，
    # __exit__ / as_completed 都会 join 每个 worker —— 只要**一个** shutil.move 卡住
    # （网盘断开、DLL 持锁、坏道读死），整个迁移就永久挂起，用户界面一直转圈。
    # 破坏性实测（2026-10-06）：20 文件里注入 1 个 sleep 400 秒的 move
    #   → 本函数 150 秒仍未返回，确认卡死。主路径 _copy_tree 同期已修（有 60s 硬时限），
    #   但 robocopy 一失败就回退到这里 = 修复被绕过。
    # 修法与 v1.7.86 主路径同款：显式建 executor，按时间预算收割，
    #   到点立刻 shutdown(wait=False, cancel_futures=True) 返回，卡住的那个 worker
    #   留在后台线程（daemon，进程退出即回收）—— 迁移判失败、如实交给调用方回退，
    #   绝不假装成功也绝不让用户干等。
    _t_start = _t.time()
    _budget = float(deadline) if deadline else 120.0
    # 每文件至少留一点时间：1.5s/个，最少 30s、最多 600s，避免大目录必然超时
    _budget = max(30.0, min(600.0, max(_budget, len(files) * 1.5)))
    _ex = None
    _timed_out = [False]
    try:
        _ex = ThreadPoolExecutor(max_workers=8)
        futs = [_ex.submit(_worker, fp) for fp in files]
        try:
            for fu in as_completed(futs, timeout=_budget):
                fu.result()
                with lock:
                    done_cnt["n"] += 1
                    cur = done_cnt["n"]
                now = _t.time()
                if (now - last_emit[0] >= 0.3) or (cur >= total):
                    last_emit[0] = now
                    if on_progress:
                        try:
                            progress_mb = min(int(cur * total_mb / total), total_mb)
                            on_progress(progress_mb, total_mb, src)
                        except Exception:
                            pass
        except Exception as _e:
            from concurrent.futures import TimeoutError as _FTimeout
            if not isinstance(_e, _FTimeout):
                raise
            # 到预算仍未收齐 = 至少一个 worker 卡死
            _timed_out[0] = True
            _left = total - done_cnt["n"]
            print("[migrate] fallback move TIMEOUT %.0fs src=%s done=%d/%d 卡住%d"
                  % (_t.time() - _t_start, src, done_cnt["n"], total, max(0, _left)))
    except Exception:
        pass
    finally:
        if _ex is not None:
            # 关键：wait=False 不 join 卡住的 worker；cancel_futures 只撤未开始的
            try:
                _ex.shutdown(wait=False, cancel_futures=True)
            except Exception:
                pass
    if _timed_out[0]:
        print("[migrate] fallback move return False (timed out) src=%s done=%d/%d"
              % (src, done_cnt["n"], total))
        if on_progress:
            try:
                on_progress(min(int(done_cnt["n"] * total_mb / total), total_mb), total_mb, src)
            except Exception:
                pass
        # 如实返回 False：src 还有残留 → 调用方判定失败，不会误建 junction
        return not os.path.exists(src)
    # 清理空目录
    # v1.7.100（真实释放铁律）：走 _win_delete 不用 os.rmdir。两个原因：
    #   ① os.rmdir 被运行环境安全删除层重定向到回收站 → 空壳留原位，源目录还在，
    #      junction 建不起来、迁移被判失败；
    #   ② 海量目录时逐个 os.rmdir 会撞「批量删除安全闸」被 SystemExit 杀线程
    #      （这正是 v1.7.92 run.py 快照回收搞瘫报告页的同一个闸）。
    try:
        for _dp, _dn, _fn in os.walk(src, topdown=False):
            for _d in _dn:
                try:
                    _win_delete(os.path.join(_dp, _d))
                except Exception:
                    pass
    except Exception:
        pass
    try:
        if os.path.isdir(src) and not os.listdir(src):
            _win_delete(src)
    except Exception:
        pass

    moved = not os.path.exists(src)
    if moved and on_progress:
        try:
            on_progress(total_mb, total_mb, src)
        except Exception:
            pass
    return moved


def _move_with_progress(src, dst, on_progress=None, max_workers=8):
    """移动 src→dst 并实时回传进度。优先使用 robocopy /E /MOVE /J /XJ /MT:64 快速搬运，
    （/J 非缓冲大文件 I/O、/XJ 跳过联接点防翻倍、/MT:64 多线程）；
    失败或 robocopy 不可用则退回逐文件并发移动。

    进度以「已迁移 MB / 总 MB」为单位，比文件数更稳定，避免小文件目录出现
    「几十 GB 要几小时」的观感。任何情况都不丢数据：移动未完成时 src 仍有残留，
    调用方会判定失败。返回 True 表示 src 已成功移走（数据完整落在 dst，
    原位置可建 junction）。
    """
    import threading, time as _t, subprocess

    if not os.path.isdir(src):
        try:
            shutil.move(src, dst)
            return True
        except Exception:
            return False

    total_bytes = _dir_size_bytes(src)
    total_mb = max(1, total_bytes // (1024 * 1024))

    if on_progress:
        try:
            on_progress(0, total_mb, src)
        except Exception:
            pass

    # 优先 robocopy 快速路径
    robocopy_path = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "robocopy.exe")
    if os.path.exists(robocopy_path):
        try:
            os.makedirs(dst, exist_ok=True)
            # /J 非缓冲 I/O：游戏/视频/虚拟机镜像等大文件搬运快数倍且不污染系统缓存；
            # /XJ 跳过联接点：防止把已建立的 junction 当真目录复制造成翻倍/死循环；
            # /MT:64 多线程：相比默认/32 显著提升大目录搬家吞吐。
            cmd = [robocopy_path, src, dst, "/E", "/MOVE", "/J", "/XJ", "/MT:64", "/NP", "/NFL", "/NDL", "/R:0", "/W:0"]
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, errors="ignore", startupinfo=si,
                                    creationflags=CREATE_NO_WINDOW)

            def _monitor():
                last_emit = 0.0
                while proc.poll() is None:
                    _t.sleep(0.5)
                    try:
                        dst_bytes = _dir_size_bytes(dst)
                        cur_mb = min(dst_bytes // (1024 * 1024), total_mb)
                        now = _t.time()
                        if now - last_emit >= 0.5 or cur_mb >= total_mb:
                            last_emit = now
                            if on_progress:
                                try:
                                    on_progress(cur_mb, total_mb, src)
                                except Exception:
                                    pass
                    except Exception:
                        pass

            mon = threading.Thread(target=_monitor, daemon=True)
            mon.start()
            try:
                proc.wait(timeout=7200)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            mon.join(timeout=2.0)

            # 最终进度
            try:
                dst_bytes = _dir_size_bytes(dst)
                cur_mb = min(dst_bytes // (1024 * 1024), total_mb)
                if on_progress:
                    try:
                        on_progress(cur_mb, total_mb, src)
                    except Exception:
                        pass
            except Exception:
                pass

            if not os.path.exists(src):
                if on_progress:
                    try:
                        on_progress(total_mb, total_mb, src)
                    except Exception:
                        pass
                return True

            # 残留少量被锁文件：兜底逐文件清理
            return _move_with_progress_fallback(src, dst, on_progress, total_mb)
        except Exception:
            pass

    return _move_with_progress_fallback(src, dst, on_progress, total_mb)


# --------------------------------------------------------------------------
# 零丢失迁移执行层（复制-校验-切换）：do_migrate 专用
# --------------------------------------------------------------------------
def _dir_file_count(path):
    """统计目录内文件总数。失败返回 -1（与 0 区分，便于校验）。"""
    try:
        n = 0
        for _dp, _dn, _fn in os.walk(path):
            n += len(_fn)
        return n
    except Exception:
        return -1


def _resolve_dst(dst):
    """返回实际目标路径。为支持重入/恢复，dst 已存在则直接复用（不递增 _2），
    避免复制-校验-切换里把完整副本误判到 _2 造成重复/孤儿目录。
    专用迁移目录 AI_PC_Migrated 下同名即同迁移项，复用安全。"""
    return dst


# ======================================================================
# v1.7.93：待续搬清单（老李 2026-10-06 第三条要求「扫描出来的就必须能处理」）
# ======================================================================
# 【老李原话】「不能迁移的是不是重启继续迁移还是怎么处理」
#   改动前的答案 = 【不是】：卡住 → 报告失败 → 要用户自己记住退出软件、再手动点一次。
#   改动后的答案 = 【是】：卡住 → 落盘排队 → 下次打开工具**自动接着搬完**。
#
# 【为什么这不是「假装解决」】
#   前提是零丢失：源目录在失败时一个字节都没动（复制-校验-切换的既有保证）。
#   所以「排队等下一轮」和「放弃」有本质区别：
#     放弃 = 用户要自己想起来、自己再点一次、还得知道是哪一项。
#     排队 = 用户什么都不用记；下次打开工具它自己搬完，搬完自动划掉清单。
#   而且清单里存的是**目标路径**，续搬走 robocopy /E 增量，只补缺失文件，
#   绝不重搬已搬好的部分 —— 这正是 robocopy 增量语义天然擅长的场景。
def _resume_queue_path():
    """待续搬清单文件路径（与 license.get_data_dir 同源，勿自造口径）。"""
    try:
        import license as _lic
        base = _lic.get_data_dir()
    except Exception:
        base = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"),
                            "AI_PC_Butler")
    return os.path.join(base, "migrate_resume.json")


# ============================================================
# v1.7.93：把「是什么就是什么」做成可查的事实，取代「多半是软件占用」
# ============================================================
# 老李 2026-10-06 原话：「问题以及操作必须明确，是什么就是什么？」
# 我原来在报告页写「把微信 / QQ / 浏览器 / 网盘这些软件先退出（它们会锁住文件）」——
# 这是**猜测**，而且是甩锅：用户只想知道「到底是谁锁着」，我却给了一份万能清单让他猜。
#
# 【为什么以前做不到 —— 现在实测能做】
# 2026-10-06 真跑 robocopy 抓它的输出（_live_test/robo_q.py），锁住 f020.dat 得到：
#     错误 32 (0x00000020) 正在复制文件 C:\...\src\f020.dat
#     另一个程序正在使用此文件，进程无法访问。
#     rc=9   用时=0.2s
# 三个事实：
#   ① **robocopy 根本不卡**（/R:0 /W:0 下 0.2 秒返回）——「卡死」另有真凶；
#   ② 错误码 32 = ERROR_SHARING_VIOLATION = 「另一个程序正在使用此文件」，
#      这个文件名**本来就在 robocopy 输出里**，但我们 stdout=DEVNULL 主动扔了；
#   ③ Restart Manager（Rstrtmgr.dll）能直接给出占用进程的**真实名称**。
#      实测（_live_test/rm_probe.py）：子进程持锁 → RM 返回 [(pid, 'thon')]，
#      即「哪个程序」是可查的事实，不是推测。
#
# 所以本模块的定位：**把猜测换成查证**。查得到就报名字，查不到就如实说「查不到」
# （绝不回退到「多半是…」这种废话）。

# RM API 的两个 ctypes 坑（都是本次实测踩出来的，记在这里防止后来者重踩）：
#   ① 必须显式声明 argtypes/restype —— ctypes 默认按 C int 传参，
#      而 DWORD/UINT 是 32 位，参数错位会让 API 直接失败返回空，
#      表现就是「RM 查不出来」（我第一版就是这样，连自己的进程都认不出）。
#   ② RmGetList 第二次调用时数组长度必须用【探测返回的 need】，
#      不能用 cnt —— cnt 是「当前数组里已有几个」，探测时恒为 0，
#      拿 0 当长度 → 数组空 → 第二次仍返 234 → 同样表现为「查不出来」。
_RM_READY = None          # None=未探测 True=可用 False=不可用
_RM_LOCK = None


def _rm_api():
    """惰性加载 Restart Manager。返回 (rstrtmgr, 结构类) 或 None。"""
    global _RM_READY, _RM_LOCK
    if _RM_READY is False:
        return None
    try:
        import threading as _th
        if _RM_LOCK is None:
            _RM_LOCK = _th.Lock()
        _RM_LOCK.acquire()
        try:
            if _RM_READY:
                from ctypes import wintypes as _wt
                # 结构类已在首次调用时建好，缓存在函数属性上
                return (_RM_DLL, _wt, _RM_UNIQUE_PROCESS, _RM_PROCESS_INFO)
            import ctypes
            from ctypes import wintypes
            dll = ctypes.WinDLL("Rstrtmgr")

            class RM_UNIQUE_PROCESS(ctypes.Structure):
                _fields_ = [("dwProcessId", wintypes.DWORD),
                            ("ProcessStartTime", ctypes.c_uint64)]

            class RM_PROCESS_INFO(ctypes.Structure):
                _fields_ = [("RMUniqueProcess", RM_UNIQUE_PROCESS),
                            ("strAppName", wintypes.WCHAR * 256),
                            ("strServiceShortName", wintypes.WCHAR * 64),
                            ("ApplicationType", wintypes.DWORD),
                            ("AppStatus", ctypes.c_ulong),
                            ("TSSessionId", wintypes.DWORD),
                            ("bRestartable", wintypes.BOOL)]

            dll.RmStartSession.argtypes = [ctypes.POINTER(wintypes.DWORD),
                                           wintypes.DWORD, ctypes.c_wchar_p]
            dll.RmStartSession.restype = wintypes.DWORD
            dll.RmRegisterResources.argtypes = [wintypes.DWORD, wintypes.UINT,
                                                ctypes.POINTER(ctypes.c_wchar_p),
                                                wintypes.UINT, ctypes.c_void_p,
                                                wintypes.UINT, ctypes.c_void_p]
            dll.RmRegisterResources.restype = wintypes.DWORD
            dll.RmGetList.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.UINT),
                                      ctypes.POINTER(wintypes.UINT), ctypes.c_void_p,
                                      ctypes.POINTER(wintypes.DWORD)]
            dll.RmGetList.restype = wintypes.DWORD
            dll.RmEndSession.argtypes = [wintypes.DWORD]
            dll.RmEndSession.restype = wintypes.DWORD

            globals()["_RM_DLL"] = dll
            globals()["_RM_UNIQUE_PROCESS"] = RM_UNIQUE_PROCESS
            globals()["_RM_PROCESS_INFO"] = RM_PROCESS_INFO
            _RM_READY = True
            return (dll, wintypes, RM_UNIQUE_PROCESS, RM_PROCESS_INFO)
        finally:
            _RM_LOCK.release()
    except Exception:
        try:
            _RM_LOCK and _RM_LOCK.release()
        except Exception:
            pass
        _RM_READY = False
        return None


def who_locks(path):
    """查出正占用某个文件的进程。返回 [(pid, 进程名), ...]；查不到返回 []。

    ★ 这是「是什么就是什么」的数据来源。任何异常都吞掉并返回空列表 ——
      诊断功能绝不允许反过来把主流程搞崩。
    """
    try:
        api = _rm_api()
        if not api:
            return []
        _dll, _wt, _UP, _PI = api
        import ctypes
        _h = _wt.DWORD(0)
        _key = ctypes.create_unicode_buffer(33)
        if _dll.RmStartSession(ctypes.byref(_h), 0, _key) != 0:
            return []
        _out = []
        try:
            _arr = (ctypes.c_wchar_p * 1)(os.path.abspath(path))
            if _dll.RmRegisterResources(_h, 1, _arr, 0, None, 0, None) != 0:
                return []
            _need, _cnt, _reboot = _wt.UINT(0), _wt.UINT(0), _wt.DWORD(0)
            _dll.RmGetList(_h, ctypes.byref(_need), ctypes.byref(_cnt), None,
                           ctypes.byref(_reboot))
            # 坑②：数组长度用【探测返回的 need】，不是 cnt。
            _n = max(1, int(_need.value))
            _infos = (_PI * _n)()
            _cnt = _wt.UINT(_n)
            if _dll.RmGetList(_h, ctypes.byref(_need), ctypes.byref(_cnt), _infos,
                              ctypes.byref(_reboot)) == 0:
                for _i in range(_cnt.value):
                    _nm = _infos[_i].strAppName or _infos[_i].strServiceShortName or ""
                    _out.append((int(_infos[_i].RMUniqueProcess.dwProcessId), str(_nm)))
        finally:
            try:
                _dll.RmEndSession(_h)
            except Exception:
                pass
        return _out
    except Exception:
        return []


def who_locks_dir(dirpath, max_files=40):
    """对一个目录逐文件试查「谁锁着」，汇总去重。

    为什么要逐文件：Windows 上「目录被占用」几乎总是**目录里某个文件**被独占
    （微信打开聊天记录就锁 .db），RM 对目录本身通常查不到任何进程。
    只查目录 = 永远查不出 = 等于没有这个功能。
    """
    out = []
    seen = set()
    try:
        if not os.path.isdir(dirpath):
            return out
        n = 0
        for _dp, _dn, _fn in os.walk(dirpath):
            for _f in _fn:
                if n >= max_files:
                    return out
                n += 1
                for _pid, _nm in who_locks(os.path.join(_dp, _f)):
                    if _nm and _nm not in seen:
                        seen.add(_nm)
                        out.append(str(_nm))
    except Exception:
        pass
    return out


# robocopy 退出码 → 人话（实测依据见 _live_test/robo_q.py）
_ROBO_RC_TEXT = {
    0: "全部成功",
    1: "有文件被复制成功",
    2: "目标上有额外的文件（不影响）",
    3: "有文件被复制，目标上有额外文件（不影响）",
    4: "部分文件没搬动",
    5: "部分文件没搬动，目标上有额外文件",
    6: "部分文件没搬动，且有文件不匹配",
    7: "有文件没搬动，且有文件不匹配",
    8: "有多个文件没搬动（通常是文件被占用）",
    9: "有文件被占用而没能搬动",
}


def explain_robo_log(log_path, src_root="", limit=6):
    """解析 robocopy 输出日志 → 人话诊断（老李要「是什么就是什么」）。

    返回 {"rc_text":..., "errors":[{file, code, text}], "locked_by":[名字...], "summary": "..."}
    ★ 绝不猜测：解析不到就如实说「解析不出来」，绝不说「多半是…」。
    """
    out = {"rc_text": "", "errors": [], "locked_by": [], "summary": "", "codes": []}
    try:
        with open(log_path, "r", encoding="gbk", errors="replace") as f:
            txt = f.read()
    except Exception:
        return out
    # 抓 ERROR 行：形如「错误 32 (0x00000020) 正在复制文件 <路径>」
    import re as _re
    for m in _re.finditer(r"错误\s+(\d+)\s*\(0x[0-9A-Fa-f]+\)\s*正在复制文件\s+(.+?)\s*$",
                          txt, _re.M):
        code = int(m.group(1))
        fpath = m.group(2).strip()
        # 错误码 → 人话（只写实测确认过的，不写猜的）
        if code == 32:
            meaning = "另一个程序正在使用此文件"
        elif code == 5:
            meaning = "拒绝访问（权限不足）"
        elif code == 3:
            meaning = "找不到指定路径"
        elif code == 2:
            meaning = "找不到指定文件"
        else:
            meaning = "系统错误码 %d" % code
        out["errors"].append({"file": fpath, "code": code, "text": meaning})
        if code not in out["codes"]:
            out["codes"].append(code)
    # 只对前几个报错文件查占用进程（RM 查询有成本，不逐个全查）
    for _e in out["errors"][:limit]:
        try:
            for _pid, _nm in who_locks(_e["file"]):
                # ★ locked_by 只放**进程名字符串**。
                #   我第一版误存了 (pid, name) 元组 → 后面 "、".join() 抛 TypeError
                #   → 整个 summary 组装崩掉 → 表现为「locked_by 一直是空的」，
                #   差点让我误判成「RM 查不到」。教训：诊断链路上的一处类型错误，
                #   会伪装成「功能不存在」。
                if _nm and _nm not in out["locked_by"]:
                    out["locked_by"].append(str(_nm))
        except Exception:
            pass
    # 组装人话摘要
    # ★ 这段整体包 try：诊断功能绝不允许反过来把迁移搞崩（老李铁律）。
    #   上一版正因为一句 join 的 TypeError 让整个 explain 抛出去，
    #   在 _copy_tree 里被 except 吞掉 → 用户看到的还是「正被程序占用」。
    try:
        if not out["errors"]:
            out["summary"] = "robocopy 没报任何错误"
        else:
            n = len(out["errors"])
            _first = out["errors"][0]["file"]
            _base = os.path.basename(_first)
            if out["codes"] == [32]:
                if out["locked_by"]:
                    out["summary"] = ("有 %d 个文件正被「%s」占用而没能搬走，"
                                      "例如 %s。退出那个软件后我就能搬完它。"
                                      % (n, "、".join(out["locked_by"]), _base))
                else:
                    out["summary"] = ("有 %d 个文件被其他程序占用（例如 %s），"
                                      "但系统没告诉我具体是哪个程序在用。" % (n, _base))
            else:
                out["summary"] = ("有 %d 个文件搬不动（例如 %s，原因：%s）"
                                  % (n, _base, out["errors"][0]["text"]))
    except Exception as _ex:
        out["summary"] = ("有 %d 个文件搬不动（例如 %s）"
                          % (len(out["errors"]), os.path.basename(out["errors"][0]["file"])))
        try:
            out["diag_error"] = repr(_ex)
        except Exception:
            pass
    return out


def _load_resume_queue():
    """读待续搬清单。任何异常都返回空列表（绝不因读档失败阻断主流程）。"""
    p = _resume_queue_path()
    try:
        if not os.path.isfile(p):
            return []
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        items = d.get("items") if isinstance(d, dict) else d
        return [x for x in (items or []) if isinstance(x, dict) and x.get("src")]
    except Exception:
        return []


def _save_resume_queue(items):
    """写待续搬清单（原子写：先写 .tmp 再替换，防半截文件毁掉清单）。"""
    p = _resume_queue_path()
    tmp = p + ".tmp"
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"updated": _time.time(), "items": list(items or [])},
                      f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return True
    except Exception:
        try:
            if os.path.exists(tmp):
                # v1.7.100：_win_delete 直删（清单临时文件不留进回收站）
                _win_delete(tmp)
        except Exception:
            pass
        return False


def enqueue_resume(src, dst, reason="", size_kb=0.0, name=""):
    """把一项放进「待续搬」清单（同一 src 只留一条，重复调用会更新原因）。"""
    try:
        items = _load_resume_queue()
        src = os.path.normpath(src)
        for it in items:
            if os.path.normpath(it.get("src") or "") == src:
                it["dst"] = dst
                it["reason"] = reason or it.get("reason", "")
                it["tries"] = int(it.get("tries") or 0) + 1
                it["ts"] = _time.time()
                _save_resume_queue(items)
                return True
        items.append({"src": src, "dst": dst, "name": name or os.path.basename(src),
                      "reason": reason, "size_kb": float(size_kb or 0.0),
                      "tries": 1, "ts": _time.time()})
        _save_resume_queue(items)
        return True
    except Exception:
        return False


def pending_resume_count():
    """待续搬清单里还有几项（报告页要如实显示，不能让人以为已经全搬完）。"""
    n = 0
    for it in _load_resume_queue():
        src = it.get("src") or ""
        try:
            if not os.path.lexists(src):
                continue          # 源已经没了 = 已被别处处理完，不算待续
        except Exception:
            continue
        n += 1
    return n


def resume_pending_migrations(on_progress=None, on_warn=None, dry_run=False):
    """启动时自动接着搬上次卡住的项 —— 让「扫出来的」最终一定能「处理完」。

    为什么需要它（老李 2026-10-06 第三条要求）：
      迁移卡住的绝大多数原因是「有软件在用这些文件」（微信/QQ/网盘/浏览器缓存）。
      那些软件下次打开本工具时多半已经退出了 —— 于是**这一轮本来就搬得完**。
      旧逻辑让人自己记得回来点一次；这里让工具自己做完。

    安全边界（三条都不可让步）：
      · 源目录保持不动（复制-校验-切换的既有保证），失败即下一轮再来；
      · 只走 robocopy /E 增量，已搬好的文件绝不重搬；
      · 搬成功的立刻出清单，搬失败的留在清单里等下一轮 —— 绝不静默丢弃。
    """
    items = _load_resume_queue()
    if not items:
        return {"done": [], "failed": [], "total_kb": 0.0, "dry_run": dry_run}
    results = {"done": [], "failed": [], "total_kb": 0.0, "dry_run": dry_run}
    keep = []
    try:
        print("[migrate] auto-resume: %d pending item(s)" % len(items))
    except Exception:
        pass
    for it in items:
        src = it.get("src") or ""
        dst = it.get("dst") or ""
        name = it.get("name") or os.path.basename(src)
        # 已经搬完了（junction 已建 / 源已不在）→ 出清单，不白搬
        if _is_junction(src) or not os.path.lexists(src):
            try:
                print("[migrate] auto-resume done already: %s" % src)
            except Exception:
                pass
            continue
        if not dst:
            keep.append(it)
            continue
        try:
            if dry_run:
                results["dry_run"] = True
                keep.append(it)
                continue
            ok = False
            kb = 0.0
            try:
                # v1.7.93：_migrate_one_copy 收的是 **meta 字典**（不是两个位置参数），
                # 且必填键有 7 个（src/dst/kb/res/total_mb/real_dst/mt）。传错签名或缺键
                # 会被 except 吞掉，表现为「清单项全被原样留下、done=0」——静默失效极难发现。
                # 这里**照 do_migrate 的正常路径补齐全部键**，不手搓简化版。
                _meta = {
                    "src": src,
                    "dst": dst,
                    "kb": float(it.get("size_kb") or 0.0),
                    "res": {},
                    "total_mb": float(it.get("size_kb") or 0.0) / 1024.0,
                    "real_dst": _resolve_dst(dst),
                    "mt": None,                       # 传 None → 由 _copy_tree 内部自适应
                    "release_locks": None,
                    "src_stats": _dir_stats(src),
                }
                _r0 = _migrate_one_copy(_meta)
                ok = bool(_r0.get("ok")) if isinstance(_r0, dict) else bool(_r0)
                kb = float((_r0.get("kb") or 0.0) if isinstance(_r0, dict) else 0.0)
            except Exception as e:
                try:
                    print("[migrate] auto-resume failed: %s err=%r" % (src, e))
                except Exception:
                    pass
                ok = False
            if ok:
                results["done"].append({"src": src, "dst": dst, "name": name,
                                        "ok": True, "bytes": int(kb * 1024),
                                        "kb": float(kb),
                                        "gb": round(float(kb or 0.0) / 1024 / 1024, 2),
                                        "msg": "上次卡住的这一项，这次已经搬完了。"})
                results["total_kb"] += float(kb or 0.0)
                try:
                    print("[migrate] auto-resume OK: %s (%.0f MB)" % (src, kb or 0.0))
                except Exception:
                    pass
            else:
                it["reason"] = it.get("reason") or "仍有文件被占用"
                it["tries"] = int(it.get("tries") or 0) + 1
                it["ts"] = _time.time()
                keep.append(it)
                results["failed"].append({"src": src, "dst": dst, "name": name,
                                          "ok": False, "bytes": 0, "kb": 0.0, "gb": 0.0,
                                          "msg": "这一项还有文件被占用，已留到下次自动继续。"})
        except Exception:
            keep.append(it)
    _save_resume_queue(keep)
    return results


def _is_junction(path):
    """判断 path 是否为 NTFS 目录联接（junction / mount point）。

    关键：os.path.islink 在 Windows 仅识别 symlink(IO_REPARSE_TAG_SYMLINK)，
    不识别 mklink /J 创建的 mount point。若用 islink 判定已迁移项会漏判，
    导致重跑时把 junction 当真实目录 rename 走、再 rmtree(bak) 误删 D 盘目标数据。
    故用 st_file_attributes 的 REPARSE_POINT(0x400) 位判断。"""
    try:
        st = os.lstat(path)
        return bool(st.st_file_attributes & 0x400)
    except Exception:
        return False


def _under_junction(path):
    """path 自身或任一祖先是 NTFS junction（已迁移到 D:）→ 返回 True。

    用于扫描/规划阶段剔除「数据实际已在 D:，只是逻辑路径还挂在 C: 下」的
    伪迁移候选。否则会把已经迁走的目录（如 Roaming\\kimi-desktop 整体已变
    junction）的子目录又当成 C 盘可迁移项重复列出，造成「明明迁过了又冒出
    来」的错觉。仅判定 reparse point，不跟随链接。"""
    p = os.path.normpath(path)
    if _is_junction(p):
        return True
    parent = os.path.dirname(p)
    while parent and parent != os.path.dirname(parent):
        if _is_junction(parent):
            return True
        parent = os.path.dirname(parent)
    return False


def _verify_equal(src, dst, src_stats=None):
    """校验 src 与 dst 完全一致：文件数 + 字节数 + 抽样内容哈希。

    分层策略（避免 v1.7.39「一票否决」倒退，也不误伤正常迁移）：
      1) 主校验：文件数 + 字节数完全一致（亚秒级，复用已缓存 src_stats）。
      2) 兜底校验：对 src 与 dst 按相对路径一一对应的少量文件做「首/尾块」内容哈希。
         仅当哈希不一致才判定不可信——堵死「同数量同字节但内容损坏」的假一致隐患
         （1.7.38 只比 count+bytes，无法发现这种极罕见但致命的误删源场景）。
      3) 容错：抽样文件若因瞬时占用读取失败，重试一次；仍失败则【跳过该项】，
         不因单个瞬时失败项把整次迁移误判为失败（这正是 v1.7.39 过度保守的倒退点）。
      4) 绝不做「任一 stat 失败即拒绝」——那会让已完整迁移的目录被误判 partial，
         C 盘空间不释放，损害「深/快释放」的核心承诺。

    加速：抽样哈希是有上限的（最多 _SAMPLE_HASH_FILES 个文件 × 首尾两段各 64KB），
    无论目录多大，额外耗时都远小于复制本身（复制分钟级，抽样毫秒级）。
    """
    if not (os.path.isdir(src) and os.path.isdir(dst)):
        return False
    ns, bs = src_stats if src_stats is not None else _dir_stats(src)
    nd, bd = _dir_stats(dst)
    if ns < 0 or nd < 0 or ns != nd:
        return False
    if not (bs == bd and bs > 0):
        return False
    # 兜底：抽样内容哈希（仅在同一数量+字节的前提下进行，成本有界）
    return _sampled_content_verify(src, dst)



def _walk_files_nolink(root):
    """递归产出 (相对路径, 绝对路径)，跳过 junction / 符号链接 —— 与 _dir_stats 口径一致。

    AIPC-DST-FOREIGN-FIX 的共用遍历器：下面两个逐路径判定都靠它，保证
    「统计口径」与「判定口径」用的是同一套文件集合，不会各算各的。
    """
    for _cur, _dirs, _files in os.walk(root):
        _keep = []
        for _d in _dirs:
            try:
                if getattr(os.lstat(os.path.join(_cur, _d)), "st_file_attributes", 0) & 0x400:
                    continue
            except OSError:
                pass
            _keep.append(_d)
        _dirs[:] = _keep
        _rel = os.path.relpath(_cur, root)
        for _fn in _files:
            _fp = os.path.join(_cur, _fn)
            try:
                if os.path.islink(_fp):
                    continue
            except OSError:
                continue
            yield (_fn if _rel == "." else os.path.join(_rel, _fn)), _fp


def _dst_is_redundant(dst, src):
    """目标是不是源的「冗余副本」：目标里每个文件在源里都有【同名同大小】。

    只有这种情况才允许把目标清掉重拷 —— 目标里的字节源里全都有，清了不丢数据。
    只要目标里有源里没有的东西（或同名但大小不同），立刻返回 False：那是用户唯一一份。
    AIPC-DST-FOREIGN-FIX：判定必须逐路径（聚合大小会漏判，见 _migrate_one_copy 注释）。
    """
    if not (os.path.isdir(dst) and os.path.isdir(src)):
        return False
    try:
        for _rel, _fp in _walk_files_nolink(dst):
            if os.lstat(_fp).st_size != os.lstat(os.path.join(src, _rel)).st_size:
                return False
    except OSError:
        return False
    return True


def _src_covered_by_dst(src, dst, src_stats=None):
    """源里每个文件在目标里都有【同名同大小】→ 源的数据一个字节不丢地都在目标上。

    用于目标盘上已经存在「源里没有的数据」的场景：此时不能要求两侧精确相等
    （目标本来就更多），只能要求「源被目标完整覆盖」。抽样内容哈希照做，防假一致。
    AIPC-DST-FOREIGN-FIX。
    """
    if not (os.path.isdir(src) and os.path.isdir(dst)):
        return False
    try:
        for _rel, _fp in _walk_files_nolink(src):
            if os.lstat(_fp).st_size != os.lstat(os.path.join(dst, _rel)).st_size:
                return False
    except OSError:
        return False
    return _sampled_content_verify(src, dst)


_SAMPLE_HASH_FILES = 6       # 最多抽样多少个文件
_SAMPLE_BLOCK = 64 * 1024    # 每段抽样 64KB（首/尾）

def _collect_samples(root, limit):
    """按相对路径收集 src 树里至多 limit 个文件的样本（确定性，跨树可对齐）。

    返回 dict: {相对路径: 绝对路径}。用 os.walk 的稳定顺序均匀取点，
    保证 src/dst 两侧样本路径一一对应，robocopy 保持了目录结构故可对齐。
    目录遍历/读取失败不抛异常，最多取到 limit 个即停（成本有界）。
    """
    out = {}
    try:
        total = 0
        stride = 1
        for _dirpath, _dirnames, filenames in os.walk(root):
            # 动态估算 stride：目标大概是 total/limit，避免首目录文件过多时前 limit 个
            # 全挤在同一个目录，导致样本分布不均匀。
            total += len(filenames)
            if total // max(limit, 1) > stride:
                stride = max(1, total // max(limit, 1))
            idx = 0
            for fn in filenames:
                if idx % stride == 0:
                    rel = os.path.relpath(os.path.join(_dirpath, fn), root)
                    out[rel] = os.path.join(_dirpath, fn)
                    if len(out) >= limit:
                        return out
                idx += 1
    except Exception:
        pass
    return out


def _hash_blocks(p, block=_SAMPLE_BLOCK):
    """计算文件「首块 + 尾块」的 SHA-256。失败返回 None（调用方决定容错）。"""
    try:
        size = os.path.getsize(p)
        h = hashlib.sha256()
        with open(p, "rb") as f:
            head = f.read(block)
            h.update(head)
            if size > block:
                f.seek(max(0, size - block))
                h.update(f.read(block))
        return h.hexdigest()
    except Exception:
        return None


def _same_headtail(src, dst):
    """首尾块哈希比对：True=可信一致（可安全删源）；False=无法确认一致（绝不删源，零丢失优先）。

    v1.7.97 P0：物理搬家 / .bak 补齐删源前，原先只比 getsize —— 同大小不同内容的「假一致」
    会导致误删源文件、D 盘副本也不一致却已丢 C 盘原文件（真丢失）。
    现加首尾块 SHA-256 校验：哈希任一侧读不到（被占用/瞬时失败）也判 False，
    宁可这次不删源、下次再清，也绝不冒丢失风险。
    """
    try:
        sh = _hash_blocks(src)
        dh = _hash_blocks(dst)
    except Exception:
        return False
    if sh is None or dh is None:
        return False
    return sh == dh


def _sampled_content_verify(src, dst):
    """抽样内容校验 src 与 dst。True=可信一致；False=内容不一致（不可信）。

    容错策略：样本文件瞬时读取失败（被占用）重试一次；仍失败则跳过该项，
    不因单个瞬时失败把整次判失败（保持 1.7.38 的宽松，避免误杀正常迁移）。
    但若某样本 src 与 dst 哈希都已读到且不一致 → 判定不可信，返回 False。
    """
    samples = _collect_samples(src, _SAMPLE_HASH_FILES)
    if not samples:
        return True  # 空目录或全失败：保持主校验结论，不额外判失败
    for rel, sp in samples.items():
        dp = os.path.join(dst, rel)
        if not os.path.isfile(dp):
            return False  # 目标缺失该样本 → 复制不完整，不可信
        sh = _hash_blocks(sp)
        dh = _hash_blocks(dp)
        if sh is None or dh is None:
            # 瞬时失败：重试一次，仍失败则跳过该项（不误杀正常迁移）
            sh = _hash_blocks(sp)
            dh = _hash_blocks(dp)
            if sh is None or dh is None:
                continue
        if sh != dh:
            return False  # 同数量同字节但内容不一致 → 假一致，不可信
    return True


def _copy_tree(src, dst, on_progress=None, total_mb=1, mt=64, total_files=0,
               should_cancel=None, io_sink=None, diag_out=None, io_grow_sink=None):
    """复制 src→dst（保留源），优先 robocopy /E /COPY:DAT /MT:mt。
    ★ v1.7.93：stdout 不再丢弃，改写入日志文件 —— robocopy 每个错误都带
      【文件名 + 错误码】，是我们唯一能「指名道姓说清谁锁着」的一手证据。
      实测见 _live_test/robo_q.py。
      diag_out：可选 dict，robocopy rc>=8 时回填 {src: {errors, locked_by, summary}}，
      供上层如实上报（老李 2026-10-06：是什么就是什么，不许说「多半是…」）。
    /COPY:DAT 仅复制数据+属性+时间戳，跳过 ACL/审计，比 /COPYALL 快且不破坏 junction 访问。

    ===== v1.7.85 三处必修（老李 2026-10-04 实测「迁移卡 4h48m、进度条假 93.4%」）=====
    修①超时不再 proc.kill()（只杀主进程，/MT:64 的 64 个子进程继续跑并继续写 D 盘）
         → 改用 _kill_proc_tree() 杀整棵树。
    修②【最关键】copytree 兜底分支**必须逐文件上报进度**。
         原实现在兜底分支里一次 on_progress 都不调 —— 页面进度条因此冻结在
         robocopy 最后一次上报的 93.4%，用户看到「快好了」而实际 4h48m 零进展。
         这就是那个假数字的确切来源。
    修③超时后不再「无脑 raise 回退 copytree」：先看 D 盘到底搬进去多少，
         搬完的部分就是搬完的（robocopy /E 是增量可续的），走 copytree 从断点补，
         并**给 copytree 也加上限时 + 进度上报**。真正搬不完则如实返回 False，
         让上层走「暂存待补齐」，而不是无限期耗着。

    ===== v1.7.86「卡住」的根因分析（老李 2026-10-05 指令：撤掉用户刹车，从根上解决）=====

    【先认一件事】v1.7.85 加的「整批 2 小时硬顶」是**假保险**：它只在 ticker 里
    置 st["cancel"]=True，而 do_migrate 真正卡住的地方根本不查这个标志位。
    也就是说：真出现「无限等待」时，那道硬顶一点用都没有。必须从**等待点本身**修。

    【实测枚举出的 4 处真漏洞，全部是「无上限等待」】
      ① _copy_tree 兜底分支里 `as_completed(_futs2, timeout=...)` 超时后，
         退出 for 但 **ThreadPoolExecutor 的 __exit__ 会 join 所有 worker** ——
         某个 shutil.copy2 卡在坏道/网络盘/被锁死的文件上，join 永远不返回。
         （这就是「明明到点了还卡着」的真凶）
      ② 兜底分支的 os.walk(src) 枚举待补文件，**没有任何时限**。
         68075 文件的树、深 13 层、或有挂死的网络路径 → 枚举本身就可能几十分钟。
      ③ do_migrate 主循环 `for _fu in as_completed(_futs)` —— **完全没有 timeout**。
         一个 worker 卡住 = 整批永远等它，前面已完成的成果一个都不交。
      ④ _complete_bak 调 _copy_tree 时传 on_progress=None（无进度），
         补齐过程对用户完全黑盒，且它自己也可能撞上 ①。

    【本版修法：给每一个等待点都加上「绝对时限 + 可打断」】
      - ① 用 `shutdown(wait=False, cancel_futures=True)` 替掉 `with` 的隐式 join；
        另起守护线程收割 future，绝不因单个 copy2 卡死而拖住主流程。
      - ② os.walk 换成带截止时间的自建栈遍历，每 2000 个文件查一次时钟与取消标志。
      - ③ 主循环 `as_completed(_futs, timeout=剩余预算)`；超时后**交出已完成成果**，
        未完成的项如实标为失败（源完好、已搬部分留在 D 盘可续补）。
      - ④ 补齐时传真实进度回调，让补齐也可见。

    【设计原则】宁可交出部分成果并如实说明，也不能交出「零成果 + 无限等待」。
    数据安全不变式：源目录在切换前始终完整保留，失败只影响「这次能搬多少」，不影响「会不会丢」。
    """
    robocopy = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "robocopy.exe")
    _cancelled = False
    if os.path.exists(robocopy):
        try:
            os.makedirs(dst, exist_ok=True)
            # ===== v1.7.89 实测推翻：/J 不能加（老李 2026-10-05 真机A/B）=====
            # 我原本按推理加了 /J（理由：「不做大文件预缓冲，白白多搬一趟」）——
            # 那是**推理，不是实测**。真跑 A/B 后结论正相反：
            #   /MT:32（无 /J）  777.6 秒  4.7 文件/秒   ← 旧参数基准
            #   /MT:8 （无 /J）  255.7 秒  14.2 文件/秒  ← 快 3.04 倍
            #   /MT:8  + /J    1101.9 秒  3.3 文件/秒   ← **比旧参数还慢 1.42 倍**
            # 原因：/J = unbuffered，**每个小文件都走一次同步写**、没有缓冲合并，
            # 在「3638 个文件 / 中位数 5.5KB」这种结构上磁盘寻道次数暴涨。
            # /J 只在**纯大文件**场景有意义，而迁移候选里那种结构不存在。
            # 教训（第二次踩）：**别拿推理当实测**。上一版刚犯过（漏了主循环的
            # with executor），这一版又差点犯（凭推理加 /J）。性能改动必须先 A/B。
            # 注：_move_into_stage 早年就带 /J，同样是搬小文件缓存，**疑似同样有害**，
            #     但本轮没有 A/B 数据，不擅自改（改要有据），记在待验证清单里。
            cmd = [robocopy, src, dst, "/E", "/COPY:DAT", "/MT:%d" % max(1, min(int(mt), 128)),
                   "/NP", "/NFL", "/NDL", "/R:0", "/W:0", "/XJ"]
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            # ★★ v1.7.93：stdout 不再丢进 DEVNULL，改为【写日志文件】★★
            # 老李 2026-10-06：「问题以及操作必须明确，是什么就是什么？」
            # 原来 DEVNULL 的理由是「防 64KB PIPE 缓冲死锁」—— 但那个坑只存在于
            # stdout=PIPE（没读端才会堵）。写**文件**同样零死锁风险，
            # 而收益是巨大的：robocopy 的每个错误都带着【文件名 + 错误码】，
            # 实测（_live_test/robo_q.py，锁 f020.dat）输出里明确写着：
            #     错误 32 (0x00000020) 正在复制文件 C:\...\src\f020.dat
            #     另一个程序正在使用此文件，进程无法访问。
            # 我们主动扔掉它，然后对用户说「多半是软件占用」—— 那是甩锅。
            # 现在：日志落盘 → 事后解析出「哪个文件、错误码、哪个进程」→ 如实上报。
            # 注意 /NFL /NDL 保留不动（它们只压制逐文件/逐目录列表，
            # **实测确认 ERROR 行的文件名照打不误**，去掉反而会让日志暴涨）。
            try:
                _log_dir = os.path.join(_resume_queue_path() + ".logs")
                os.makedirs(_log_dir, exist_ok=True)
                _safe = "".join(c for c in (name or "item") if c not in '\\/:*?"<>|')[:60]
                _log_path = os.path.join(_log_dir, "%s_%d.log" % (_safe, int(_time.time())))
            except Exception:
                _log_dir, _log_path = None, None
            _lf = None
            if _log_path:
                try:
                    _lf = open(_log_path, "wb")
                except Exception:
                    _lf = None
            proc = subprocess.Popen(cmd, stdout=(_lf if _lf is not None else subprocess.DEVNULL),
                                    stderr=subprocess.STDOUT,
                                    startupinfo=si, creationflags=CREATE_NO_WINDOW)
            if on_progress:
                try:
                    on_progress(0, total_mb, src)
                except Exception:
                    pass
            # 超时按【数据量 + 文件数】双维度动态设置。
            #
            # ===== v1.7.85 我自己引入的新 bug（实测抓到，必须修）=====
            # 上一轮我把公式从 max(120, min(3600, total_mb*2)) 收紧成
            # max(60, min(900, total_mb*1.0))，理由是「679MB 给 23 分钟太宽松」。
            # ——这个公式**只按 MB 算，漏了文件数这个维度**，而真实数据是：
            #     C:\Users\LQN\dsh = 522MB / 62552 个文件（平均 8.5KB，深 13 层，pnpm 布局）
            #     522MB -> timeout = 522 秒（8.7 分钟）
            #     但 robocopy 在这种「海量小文件 + 13 层深」结构上实测只有 ~19 文件/秒，
            #     62552 / 19 = 3292 秒（55 分钟）才搬得完
            #     522 << 3292  →  **必然超时**，杀 robocopy、增量重试、再超时……
            #     三轮下来就是老李看到的「卡 4h48m」。
            # 教训：**迁移耗时的瓶颈从来不是 MB，是文件数。** 只按 MB 定时限 = 必炸。
            #
            # 新公式：取两个维度里【更宽】的那个，谁慢听谁的。
            #
            # ===== 系数怎么定的（全部来自本机实测，不靠拍脑袋）=====
            # 实测 A：小米数据 679.8MB / 3433 文件 → 新 _copy_tree 73.8 秒搬完
            #          = 46.5 文件/秒、9.2 MB/s
            # 实测 B：C:\Users\LQN\dsh 522MB / 62552 文件（node_modules，深 13 层）
            #          在 D 盘侧 41 分钟只落 47240 文件 → ≈ 19 文件/秒
            # 实测 C（v1.7.89，老李真机A/B 干净环境，源=ima.copilot 661MB/3638文件）：
            #   /MT:32 → 777.6 秒  4.7 文件/秒
            #   /MT:8  → 255.7 秒 14.2 文件/秒  ← 采用
            # 取 **10 文件/秒** 作最坏假设（比实测 B 还留 1.9 倍余量，覆盖杀软扫描 /
            # HDD 寻道 / 碎片），即每文件 0.1 秒。MB 维度取 1 秒/MB（≈1MB/s，
            # 远低于实测 9.2MB/s，同样是保守侧）。
            #
            # 上限 3600s 是【单轮】硬顶；注意 MAX_RETRY=1 意味着最多 2 轮，
            # 所以最坏 = 7200s。robocopy /E 是增量的，第二轮只补缺失文件、通常秒级，
            # 真正会吃满 2 轮的只有「一直有文件被锁」这种异常，此时会如实判失败
            # 走「暂存待补齐」，由用户退出软件后补 —— 绝不无限期耗着。
            #
            # ===== v1.7.88：MB 维度系数 1.0→0.6（上限 3600→2400）=====
            # 提速后实测 661MB 只花 255.7 秒（≈2.6MB/s），而原公式按 1MB/s 给时限 =
            # 比实测宽松 7 倍；上限 3600s 更是把「4 分钟能搬完」的项算成「最多 1 小时」——
            # 用户看进度条当然觉得慢，因为**给的时限和实际速度根本不匹配**。
            # 现在按 0.6 秒/MB（≈1.7MB/s，仍比实测 2.6 保守 1.5 倍）、上限 2400s。
            _t_mb = float(total_mb or 0) * 0.6
            _t_files = float(total_files or 0) * 0.1
            timeout = max(60, min(2400, max(_t_mb, _t_files)))
            # v1.7.85：把超时真值写进日志，便于事后诊断（老李要求「不许骗用户」，
            # 排查时必须有据可查，不能靠猜）。migrate.py 全模块无 logger，
            # 沿用本模块既有风格走 print（server 侧会把子进程输出收进 server.log）。
            try:
                print("[migrate] copy_tree timeout=%.0fs src=%s mb=%s files=%s"
                      % (timeout, src, total_mb, total_files))
            except Exception:
                pass
            _robo_timed_out = False
            # v1.7.85：把「一次性 proc.wait(timeout)」改成【每 0.5 秒轮询】。
            # 原因有二：
            #   ① proc.wait() 是不可打断的阻塞调用，外层就算检测到「整批该收了」
            #      也叫不醒它，只能干等 timeout 走完 —— 取消/兜底形同虚设；
            #   ② 只有轮询才能同时守住「超时」和「用户主动取消」两条退出路径。
            _t0 = _time.time()
            _cancel_cb = should_cancel if should_cancel else None
            # ===== v1.7.93：用【目标目录体积】做真进度/真停滞信号 =====
            # 老李 2026-10-06 现场指控「这么容易就弹出卡住了 = 甩锅」，实测确认：
            #   robocopy 主路径 stdout 被丢进 DEVNULL（防 64KB 缓冲死锁）→
            #   主路径只在开工前 on_progress(0, ...) 一次，之后再无上报。
            #   实测 403/1079/3024 文件三组规模，回调都只有 2 次且内容都是 0.0MB。
            #   也就是说停滞检测读的那个数字**恒为 0**，「零进展」恒为真。
            #
            # 【真信号是什么】robocopy 往 dst 写文件 → dst 的真实体积在增长。
            # 每 0.5 秒扫一次 dst 体积，差分即为真实吞吐：
            #   · 体积在涨 = 进程真在搬（进度条也顺带变准了）；
            #   · 体积连续 N 秒不变 + 进程还活着 = 这才叫卡住（实测能干净区分）。
            _prog = {"bytes": 0, "last": 0.0, "ts": _time.time(),
                     "last_grow": _time.time()}
            _dst_real = os.path.normpath(dst)
            # v1.7.93：把实测字节回填给调用方的共享字典（st["io_bytes"]）。
            # 上层 ticker 的「停滞检测 / 速率 / ETA」都读它 —— 那才是真值。
            _io_sink = None
            if isinstance(io_sink, dict):
                _io_sink = io_sink
            # v1.7.93：本项最后一次「体积真增长」的时刻。ticker 用它判断
            # 「是这一项卡住了」而不是「整批都不动」，也用它来决定要不要弹停滞告警。
            _grow_sink = None
            if isinstance(io_grow_sink, dict):
                _grow_sink = io_grow_sink

            def _dst_bytes():
                """dst 当前真实体积（字节）。失败返回 -1，绝不让采样本身打断搬运。"""
                try:
                    _t = 0
                    for _dp, _dn, _fn in os.walk(_dst_real):
                        for _f in _fn:
                            try:
                                _t += os.path.getsize(os.path.join(_dp, _f))
                            except Exception:
                                pass
                    return _t
                except Exception:
                    return -1

            # 开工先采一次基线（此刻 dst 可能还不存在或为空）
            _b0 = _dst_bytes()
            _prog["last"] = _b0 if _b0 > 0 else 0.0
            _prog["bytes"] = _prog["last"]
            while True:
                try:
                    if proc.poll() is not None:
                        break
                except Exception:
                    break
                if _time.time() - _t0 >= timeout:
                    _robo_timed_out = True
                    break
                # 外部要求停止（整批兜底 / 用户点取消）→ 立刻收工，已搬的不白搬
                if _cancel_cb is not None:
                    try:
                        if _cancel_cb():
                            try:
                                print("[migrate] copy_tree cancelled src=%s" % src)
                            except Exception:
                                pass
                            _kill_proc_tree(proc)
                            _robo_timed_out = True
                            _cancelled = True
                            break
                    except Exception:
                        pass
                # ===== v1.7.93：每 0.5 秒采一次 dst 体积 → 真进度 =====
                # 这同时解决三件事：
                #   ① 进度条不再冻结（robocopy 自己不报，我们自己量）；
                #   ② 上层停滞检测拿到的是【真实搬运量】而不是恒为 0 的数字；
                #   ③ 能区分「进程活着但在搬」与「进程活着但磁盘零写入（真卡住）」。
                _now_t = _time.time()
                if _now_t - _prog["ts"] >= 0.5:
                    _cur_b = _dst_bytes()
                    if _cur_b >= 0:
                        if _cur_b > _prog["bytes"] + 65536:   # 真增长了（>64KB）
                            _prog["last_grow"] = _now_t
                            if _grow_sink is not None:
                                try:
                                    _grow_sink[src] = _now_t
                                except Exception:
                                    pass
                        _prog["bytes"] = _cur_b
                        # ★ 回填到共享状态：ticker 的停滞检测与速率/ETA 都读它。
                        #   这是「磁盘实测真值」，不是 on_progress 那个恒为 0 的数字。
                        if _io_sink is not None:
                            try:
                                _io_sink[src] = float(_cur_b)
                            except Exception:
                                pass
                        if on_progress and total_mb and total_mb > 0:
                            try:
                                # 封顶 99%：复制完成前绝不显示 100%（老李铁律）
                                _mb = min(_cur_b / 1048576.0, total_mb * 0.99)
                                on_progress(_mb, total_mb, src)
                            except Exception:
                                pass
                    _prog["ts"] = _now_t
                _time.sleep(0.5)
            if _robo_timed_out:
                if not _cancelled:
                    # 修①：杀整棵进程树。原 `proc.kill()` 只杀主进程，
                    # robocopy /MT:64 的 64 个工作进程会继续往 D 盘写 →
                    # ticker 误把「它们写的量」当成当前进度 → 进度条假 93.4% 永不变化。
                    _kill_proc_tree(proc)
            # ===== v1.7.93：关日志句柄 + 解析诊断（覆盖全部退出路径）=====
            # 放在这里而不是「成功分支」里，因为**超时往往正是被锁导致的**，
            # 日志里已经有真凶线索，绝不能只在 rc<=7 时才看。
            if _lf is not None:
                try:
                    _lf.flush()
                    _lf.close()
                except Exception:
                    pass
                _lf = None
            _rc = (proc.returncode & 0xFF) if proc.returncode is not None else None
            # 只要「有错误码」或「超时」就解析 —— 那才可能有值得上报的锁信息
            if _log_path and ((_rc is not None and _rc >= 8) or _robo_timed_out):
                try:
                    _diag = explain_robo_log(_log_path)
                    _diag["rc"] = _rc
                    _diag["timed_out"] = bool(_robo_timed_out)
                    _diag["cancelled"] = bool(_cancelled)
                    _diag["rc_text"] = (_ROBO_RC_TEXT.get(_rc, "退出码 %s" % _rc)
                                        if _rc is not None
                                        else ("超时中止" if _robo_timed_out else "未知"))
                    try:
                        print("[migrate] robo diag src=%s rc=%s timeout=%s -> %s | locked_by=%s"
                              % (src, _rc, _robo_timed_out, _diag.get("summary"),
                                 _diag.get("locked_by")))
                    except Exception:
                        pass
                    if isinstance(diag_out, dict):
                        diag_out[src] = _diag
                except Exception:
                    pass
            if not _robo_timed_out:
                if on_progress:
                    try:
                        on_progress(total_mb, total_mb, src)
                    except Exception:
                        pass
                # robocopy 退出码 0-3 视为成功；4-7 表示存在不匹配/未复制文件，
                # 对"零丢失"承诺而言应视为失败或至少触发更严格校验。
                rc = _rc if _rc is not None else 1
                return rc <= 3
            # 修③：走到这里说明 robocopy 超时。robocopy /E 是**增量可续**的，
            # 已搬过去的文件不会白搬 —— 落进下方 copytree 增量补齐（只拷缺失的）。
        except Exception:
            pass

    # v1.7.85：被外部取消（整批兜底 / 用户点取消）→ 立刻如实返回失败。
    # 绝不能落进下面的兜底分支继续磨 —— 那是「已经决定收工了还在干活」。
    # 已搬过去的部分留在 dst 上，下次点「继续」只补缺的，绝不重来。
    if _cancelled:
        try:
            print("[migrate] copy_tree return False (cancelled) src=%s" % src)
        except Exception:
            pass
        return False

    # ===== v1.7.85 修②：兜底分支改【多线程】+ 真实进度 + 硬时限 =====
    #
    # ===== 这里有一段被实测推翻的错误结论，必须留档以防再犯 =====
    # 我（上一轮）曾写：「单线程 shutil.copytree 是迁移卡 4h48m 的真病根」，
    # 依据是「300 个文件的 copytree 跑 16 分钟未完，折算 17-30 文件/秒」。
    # ❌ 这个结论是错的，两个硬证据推翻它：
    #   ① _bench_mt.py 实测：多线程 40 文件/秒 vs 单线程 copy2 **43 文件/秒**，
    #      只差 1.1 倍。单线程根本不慢，3433 文件只要 1.3 分钟。
    #   ② 那个「16 分钟跑 300 文件」的探针**样本被污染** —— 测量时机器上同时跑着
    #      卡死的 server + robocopy 孤儿进程在抢 IO，却被我当成金标准。
    # 真正的病根是【timeout 只按 MB 定、不看文件数】（已在上面修掉）+【假进度】。
    # 本兜底分支保留多线程不是因为「单线程是原罪」，而是因为 robocopy 已被硬顶打断，
    # 剩下的缺口确实需要并发补齐 + 逐文件真实进度（否则页面数字会骗人）。
    #
    # 修法（复用本文件 _move_with_progress 的成熟并发范式）：
    #   ① 先补一次 robocopy /J /MT:32 增量续搬（robocopy 超时前搬走的部分不白搬）
    #   ② 仍缺的走 ThreadPoolExecutor 并发 copy2（8~16 线程，按 CPU 自适应）
    #   ③ 逐文件真实计数 + 看门狗每 2 秒上报（进度条会动，不再冻结在 93.4%）
    #   ④ 硬时限：到点返回 False，如实让上层走「暂存待补齐」，绝不无限期耗着
    #
    # ⚠ v1.7.85 修一处真 bug：原来这里有 `fast_purge(dst)` —— 它会把 robocopy
    #   已经搬过去的部分【整块删掉】，然后从零重搬。这与上一行注释
    #   「已搬过的文件不会白搬」直接矛盾，也是「搬了 4 小时还在原地」的一层原因。
    #   现在改成：不删，增量续补。
    try:
        _existing_kept = os.path.isdir(dst)
    except Exception:
        _existing_kept = False
    if not on_progress:
        def on_progress(*_a, **_k):
            return None

    def _p0():
        try:
            on_progress(0, total_mb, src)
        except Exception:
            pass
    _p0()

    # ① 先补一次 robocopy 增量（/J 不缓冲直拷，单文件最快；/MT:32 自带并发）
    _robo = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "robocopy.exe")
    if os.path.exists(_robo):
        try:
            os.makedirs(dst, exist_ok=True)
            _p2 = subprocess.Popen(
                [_robo, src, dst, "/E", "/COPY:DAT", "/J", "/MT:32", "/NP", "/NFL", "/NDL",
                 "/R:0", "/W:0", "/XJ"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=CREATE_NO_WINDOW)
            try:
                _p2.wait(timeout=max(60, min(420, total_mb * 0.6)))
            except subprocess.TimeoutExpired:
                _kill_proc_tree(_p2)      # 修①：杀整棵树，不留孤儿继续写盘
        except Exception:
            pass

    # ② 枚举待补文件（robocopy 没搬完的），并发 copy2
    #
    # ===== v1.7.86 修漏洞②：os.walk 无时限 → 改为带截止时间的自建栈遍历 =====
    # 原 `for _dp,_dn,_fn in os.walk(src)` 在 68075 文件 / 深 13 层 / 挂死网络路径上
    # 可能枚举几十分钟，且完全不看取消标志。这里改成：
    #   · 显式栈遍历，每 2000 个文件查一次时钟与 should_cancel
    #   · 到截止时间就停，**把已枚举到的部分照常搬**（不回滚、不丢）
    #   · 绝不无限期耗在枚举上（枚举不完 → 剩余留给下次「继续」）
    _todo = []
    _already = 0
    _enum_deadline = _time.time() + 300.0     # 枚举阶段独立预算 5 分钟
    _enum_stop = False
    try:
        _stack = [src]
        _seen_dirs = 0
        while _stack:
            _cur_dir = _stack.pop()
            try:
                _entries = list(os.scandir(_cur_dir))
            except Exception:
                continue
            for _ent in _entries:
                try:
                    if _ent.is_dir(follow_symlinks=False):
                        _stack.append(_ent.path)
                        continue
                    if not _ent.is_file(follow_symlinks=False):
                        continue
                except Exception:
                    continue
                _s = _ent.path
                _d = os.path.join(dst, os.path.relpath(_s, src))
                try:
                    if os.path.isfile(_d) and os.path.getsize(_d) == os.path.getsize(_s):
                        _already += 1      # robocopy 已搬完，跳过（不重复搬）
                        continue
                except Exception:
                    pass
                _todo.append((_s, _d))
            _seen_dirs += 1
            # 每 2000 个文件查一次时钟/取消 —— 防止深树或坏道把枚举拖成无上限
            if _seen_dirs % 2000 == 0:
                if _time.time() > _enum_deadline:
                    _enum_stop = True
                    break
                if should_cancel is not None:
                    try:
                        if should_cancel():
                            _enum_stop = True
                            break
                    except Exception:
                        pass
    except Exception:
        pass
    if _enum_stop:
        try:
            print("[migrate] copy_tree enum stopped early src=%s (%d files found)"
                  % (src, len(_todo)))
        except Exception:
            pass

    _tot_n = _already + len(_todo)
    if _tot_n <= 0:
        # v1.7.85：删掉原来这里的 `_p0 = total_mb` —— 它是个从未被读取的赋值
        # （函数内已有名为 _p0 的 def），纯死代码，且三壳同步时会制造无谓 diff。
        try:
            on_progress(total_mb, total_mb, src)
        except Exception:
            pass
        return True

    # robocopy 已搬完的那部分，如实计入进度基数（既不重复搬，也不假装是 0）
    _base_mb = total_mb * (_already / float(_tot_n)) if _tot_n else 0.0
    _lock2 = threading.Lock()
    _cnt = {"n": _already}
    _deadline = _time.time() + min(900, max(150, len(_todo) * 0.8))
    _workers = max(2, min(16, (os.cpu_count() or 4) * 2))
    _stop_watch = threading.Event()

    def _cp1(pair):
        _s, _d = pair
        try:
            _dd = os.path.dirname(_d)
            if _dd:
                os.makedirs(_dd, exist_ok=True)
            shutil.copy2(_s, _d)
            return True
        except Exception:
            return False

    def _watch():
        # 看门狗：每 2 秒上报一次**真实**进度；到点后通知主循环收尾。
        # （原实现只在复制开始/结束各报一次，兜底路径里一次都不报 → 进度条冻结）
        while not _stop_watch.is_set():
            _time.sleep(2.0)
            with _lock2:
                _c = _cnt["n"]
            _mb = _base_mb + (total_mb - _base_mb) * (_c / float(_tot_n))
            try:
                on_progress(_mb, total_mb, src)
            except Exception:
                pass
            if _c >= _tot_n:
                return

    _wt = threading.Thread(target=_watch, daemon=True)
    _wt.start()
    _pending = list(_todo)
    # ===== v1.7.86 修漏洞①：`with ThreadPoolExecutor` 的 __exit__ 会 join 全部 worker =====
    # 这是「明明到点了还卡着」的真凶：as_completed 超时只让 for 循环退出，
    # 但 `with` 退出时 executor.shutdown(wait=True) 会等**所有** worker 结束；
    # 只要有一个 shutil.copy2 卡在坏道 / 挂死的网络路径 / 被锁死的文件上，
    # 主流程就永远走不下去 —— 之前的「整批 2 小时硬顶」对此完全无效
    # （它只置标志位，而这里等的是 future）。
    #
    # 修法：显式建 executor，**shutdown(wait=False, cancel_futures=True)** 立即返回；
    # 未启动的 future 直接取消；已在跑的 copy2 由守护线程后台收割，
    # 它们搬完的文件照样算成功（数据在磁盘上是安全的），主流程不等它们。
    _ex2 = ThreadPoolExecutor(max_workers=_workers)
    _pending_futs = []
    try:
        for _x in _pending:
            if should_cancel is not None:
                try:
                    if should_cancel():
                        break
                except Exception:
                    pass
            _pending_futs.append(_ex2.submit(_cp1, _x))
        _budget = max(1, int(_deadline - _time.time()))
        try:
            for _f2 in as_completed(_pending_futs, timeout=_budget):
                try:
                    if _f2.result():
                        with _lock2:
                            _cnt["n"] += 1
                except Exception:
                    pass
        except Exception:
            # 超时或被取消：已完成的已在 _cnt 里，未启动的现在取消
            pass
    finally:
        # 只对**未开始**的 future 调 cancel()；已在跑的让它在后台跑完（不浪费已搬数据）
        for _f3 in _pending_futs:
            try:
                _f3.cancel()
            except Exception:
                pass
        try:
            _ex2.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            # 老版本 Python 没有 cancel_futures
            try:
                _ex2.shutdown(wait=False)
            except Exception:
                pass
        except Exception:
            pass
        # 收割仍在跑的 future：搬完就记成功，绝不让主流程等它
        def _reap():
            for _f4 in _pending_futs:
                try:
                    if _f4.cancel():
                        continue          # 没跑起来的不用管
                    _ok4 = _f4.result()  # 已在跑的：等它，但不阻塞主流程
                except Exception:
                    _ok4 = False
                if _ok4:
                    with _lock2:
                        _cnt["n"] += 1
        threading.Thread(target=_reap, daemon=True).start()
        _stop_watch.set()

    with _lock2:
        _final_n = _cnt["n"]
    _timed_out = _final_n < _tot_n
    _mb = _base_mb + (total_mb - _base_mb) * (_final_n / float(_tot_n))
    try:
        on_progress(_mb, total_mb, src)
    except Exception:
        pass
    # 搬不完 = 如实 False，让上层走「暂存待补齐」。
    # 绝不能返回 True 骗上层说"搬完了"——那会切 junction 到不完整的目标，埋下数据丢失。
    return (not _timed_out)


# 保留旧名，向后兼容（do_migrate 已改用 _copy_tree，旧实现停用）
move_with_progress = _move_with_progress


def _robocopy_copy_file(src, dst, mt=64, timeout_per_mb=2):
    """单文件高速拷贝：优先 robocopy /J（非缓冲大文件 I/O，比 shutil.copy2 快数倍且
    不污染系统缓存），失败回退 shutil.copy2。返回 True 表示 dst 已存在且大小一致。

    提速原理：shutil.copy2 是 Python 层单线程 64KB 缓冲拷贝，对 10~50GB 大文件（视频/
    ISO/压缩包）极慢且每 chunk 都被杀软实时扫描；robocopy /J 走内核级非缓冲 I/O、
    /MT 多线程，是 Windows 上单文件拷贝的接近最优解。mode=move 个人大文件迁移因此
    从「最慢路径」提升到与 junction 路径同级的 robocopy 速度（v1.7.51 提速 Fix1a）。
    """
    try:
        if not (os.path.isfile(src) and os.path.getsize(src) > 0):
            return False
    except Exception:
        return False
    d = os.path.dirname(dst)
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    robocopy = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "robocopy.exe")
    if os.path.exists(robocopy):
        try:
            cmd = [robocopy, os.path.dirname(src), d, os.path.basename(src),
                   "/J", "/R:0", "/W:0", "/NP", "/NFL", "/NDL", "/MT:%d" % max(1, min(int(mt), 128))]
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                    creationflags=CREATE_NO_WINDOW)
            sz_mb = max(1, os.path.getsize(src) // (1024 * 1024))
            try:
                proc.wait(timeout=max(120, min(3600, sz_mb * timeout_per_mb)))
            except subprocess.TimeoutExpired:
                proc.kill()
                try:
                    proc.wait(timeout=5)
                except Exception:
                    pass
                return False
            if (proc.returncode & 0xFF) <= 3 and os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src):
                return True
        except Exception:
            pass
    # 回退：Python 原生拷贝（保底，慢但正确）
    try:
        shutil.copy2(src, dst)
        return os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src)
    except Exception:
        return False


# =============================================================================
# ★ v1.7.94：整目录锁住时「自动降级为逐子目录搬」
# =============================================================================
def _split_locked_dir_children(src, dst, min_kb=64):
    """把一个锁死的目录展开成「能改名搬走的子目录」列表。

    背景（本机实测，见 v1.7.94_改动说明）：
      Roaming 下的 Tencent 共 4.52GB / 11 个子目录，整目录改名失败（winerror=5），
      但其中 9 个子目录能改名，合计 4.28GB（94.7%）。
      只有 beacon(4MB)、WeType(0.3MB) 被搜狗输入法锁死。

    做法（每一步都用实测判据，绝不猜）：
      1. 逐个子目录做 rename 试探（能改名的立刻改回，零副作用）；
      2. 只把「能改名」且体积够的收进可搬列表；
      3. 锁死的子项单独查真实占用进程名（who_locks_dir），拿不到就如实说「没告诉我」。

    返回 (movable, blocked)
      movable = [{"src","dst","size_kb","files"}]  能搬的子目录
      blocked = [{"path","size_kb","files","lockers"}] 搬不动的，带真实占用进程名
    """
    movable, blocked = [], []
    try:
        entries = [e for e in os.scandir(src) if e.is_dir(follow_symlinks=False)]
    except Exception:
        return movable, blocked

    dst_parent = os.path.dirname(dst)
    stem = os.path.basename(dst) or os.path.basename(src)

    for e in entries:
        child = e.path
        name = e.name
        # ★ v1.7.94 P0（实测抓到）：迁移残留不是「用户数据」，绝不能当成正常
        #   子目录去搬 —— WeMail.migrated.bak / X.previous 就是上一轮的残渣，
        #   搬它们等于搬垃圾（还会让容量闸算错体积）。
        _low = name.lower()
        if (_low.endswith(".migrated.bak") or ".previous" in _low
                or _low.endswith(".bak") or _low.endswith(".tmp")):
            continue
        # 已经搬完的（源是 junction）也不再列 —— 列进去会走进 .bak 补齐分支，
        # 触发安全删除闸「等用户确认」，把整个迁移卡住（实测卡 4 分 49 秒）。
        if _is_junction(child) or os.path.islink(child):
            continue
        try:
            cfc, cby = _dir_stats(child)
        except Exception:
            cfc, cby = 0, 0
        size_kb = float(cby or 0) / 1024.0

        # 实测判据：这个子目录自己能不能改名（不能=有程序正用着）
        if classify_lock(child) == "free":
            if size_kb >= min_kb:
                movable.append({
                    "src": child,
                    "dst": os.path.join(dst_parent, stem, name),
                    "size_kb": size_kb,
                    "files": int(cfc or 0),
                    "name": name,
                })
            continue

        # 锁死 → 拿真实占用进程名。查不到就如实留空，绝不编。
        lockers = []
        try:
            lockers = [n for _, n in who_locks_dir(child, max_files=8)]
        except Exception:
            pass
        blocked.append({
            "path": child,
            "size_kb": size_kb,
            "files": int(cfc or 0),
            "name": name,
            "lockers": lockers,
        })
    return movable, blocked


def _describe_blocked_children(blocked):
    """把搬不动的子目录汇总成人话（指名道姓，不猜）。"""
    if not blocked:
        return ""
    parts = []
    for b in blocked:
        who = "、".join(b.get("lockers") or [])
        if who:
            parts.append("%s（%s 正用着）" % (b.get("name", ""), who))
        else:
            parts.append("%s（系统没告诉我被谁占用）" % (b.get("name", ""),))
    return "；".join(parts)



def do_migrate(plan, dry_run=False, on_progress=None, max_workers=None, release_locks=None,
               on_warn=None):
    """执行迁移计划（复制-校验-切换，零丢失、幂等、可重入、并行）。

    两遍：
      第一遍（串行，快）：护栏 / 幂等 / dry_run 判定；需实际搬运的项收集进 copy_items。
      第二遍（并行，方案B）：copy_items 用线程池并发执行「复制-校验-切换」
        （_migrate_one_copy）。各项目源目录互相独立，可安全并发；共享只读资源仅为
        目标盘剩余空间（用于进度估算），互不干扰。

    每项目逻辑（_migrate_one_copy）：
      0. 幂等/可重入：已 junction → 跳过；源不在且有目标 → 补 junction；目标已完整 → 直接切换
      1. 复制 src→real_dst（保留源，robocopy /COPY:DAT，输出排空）
      2. 校验文件数+字节数一致；不一致则源完好、标记失败（绝不删源）
      3. 同盘原子改名 src→src.migrated.bak，再 mklink /J src real_dst
      4. junction 失败 → 改名还原（同盘原子，零丢失）
      5. 成功 → 删除 .bak 释放 C 盘，记录 done

    进度（方案A/B）：复制期间不遍历目录；由 do_migrate 全局 ticker 用目标盘剩余空间
    变化（微秒级 syscall）驱动，按比例摊到各在途项目，避免并行时进度互相污染。

    核心保证：切换前 src 始终完整保留；任一环节失败都还原或保持源完好，绝不丢数据。
    返回 {done:[...], failed:[...], total_kb, dry_run}。

    ===== v1.7.93（老李 2026-10-06 第三条要求：扫描出来的就必须能处理）=====
    卡住的项不再「报告失败就完事」，而是**落进待续搬清单**（%APPDATA%/AI_PC_Butler/
    migrate_resume.json），下次打开工具时**自动接着搬完**（参见 resume_pending_migrations）。
    语义变化：
      以前 = 卡住 → 失败 → 要用户自己退出软件、再手动点一次迁移。
      现在 = 卡住 → 排队 → 你该关的软件还是要关，但**不用记得回来点**，
              下次打开工具它自己搬；搬完自动把清单划掉。
    零丢失前提不变：源目录一个字节都没动，只是排队等下一轮。
    """
    results = {"done": [], "failed": [], "total_kb": 0.0, "dry_run": dry_run, "target_disk_type": "Unknown"}
    # R5：目标盘空间校验（复制阶段目标盘需容纳完整副本）
    # v1.7.34（产品铁律2·可迁移性）：原实现是「整个 plan 总量超限 → 整批全部 failed」，
    # 连「容量够、本可迁成功」的项也被连坐失败 —— 直接违背「扫描出来的能迁的都该迁成」。
    # 改为**按项贪心过滤**：目标盘能装下的项照常迁移，装不下的项才标 failed（并带
    # capacity_exceeded 标记，前端如实展示"空间不足暂缓"），绝不连带失败能迁的项。
    if not dry_run and plan:
        _dst0 = os.path.normpath(plan[0].get("dst") or plan[0].get("src") or "")
        _drive = (os.path.splitdrive(_dst0)[0] + os.sep) if os.path.splitdrive(_dst0)[0] else os.sep
        try:
            _free = shutil.disk_usage(_drive).free / 1024.0
        except Exception:
            _free = None
        if _free is not None and _free < sum(float(i.get("size_kb", 0) or 0) for i in plan) * 1.1:
            # 留 10% 余量，按项贪心过滤：能装下的进 copy_items（继续正常迁移），
            # 装不下的进 failed（如实报告，不连坐能迁的项）
            _usable = _free * 0.9
            _accum = 0.0
            _kept = []
            _over = []
            for _i in plan:
                _kb = float(_i.get("size_kb", 0) or 0)
                if _accum + _kb <= _usable:
                    _accum += _kb
                    _kept.append(_i)
                else:
                    _i2 = dict(_i)
                    _i2["capacity_exceeded"] = True
                    _over.append(_i2)
            if _over:
                _msg = "目标盘剩余空间不足，以下项暂缓迁移（请先释放 %s 盘空间或减少勾选）" % (_drive.rstrip("\\/") or "目标盘")
                for _i in _over:
                    results["failed"].append({
                        "src": os.path.normpath(_i.get("src", "")),
                        "dst": os.path.normpath(_i.get("dst", "")),
                        "kb": float(_i.get("size_kb", 0) or 0),
                        "ok": False, "msg": _msg,
                        "capacity_exceeded": True,
                    })
            if _kept:
                plan = _kept
            else:
                # 连一项都装不下 → 全部如实失败，返回（避免空 plan 走后续逻辑）
                return _normalize_results(results)
    # ---- 第一遍：护栏 / 幂等 / dry_run 判定，收集需实际复制-切换的项 ----
    copy_items = []  # 每项: {src, dst, kb, res, total_mb, real_dst, mt}

    # =====================================================================
    # ★ v1.7.94（老李 2026-10-06 实测反馈「点迁移了，提示要重启才能完成迁移」）：
    #   整目录锁住 → 先强杀占用进程 → 仍锁则自动降级为逐子目录搬。
    #   依据：本机 Roaming 下的 Tencent 整目录锁死，但 9/11 子目录能改名、覆盖 94.7%。
    #   不这么做的话，4MB 的输入法子目录会拖死 4.5GB 的整项 —— 扫描出来的就处理不了。
    # =====================================================================
    _split_expanded = {}   # 原项 src -> {"movable": [...], "blocked": [...]}
    if not dry_run and plan:
        _replanned = []
        for _it in plan:
            try:
                _s = os.path.normpath(_it.get("src", ""))
                _d = os.path.normpath(_it.get("dst", ""))
                # 只对「junction 类的大目录」降级；个人文件 move / 已是 junction 的不动
                if (not _s or not _d) or _it.get("mode") == "move":
                    _replanned.append(_it); continue
                if not os.path.isdir(_s) or _is_junction(_s) or os.path.islink(_s):
                    _replanned.append(_it); continue
                if classify_lock(_s) == "free":
                    _replanned.append(_it); continue

                # 锁住了 → 先强杀占用进程再探一次（能解开就整目录搬，最省事）
                if release_locks:
                    try:
                        release_locks(_s)
                    except Exception:
                        pass
                    _time.sleep(0.8)
                if classify_lock(_s) == "free":
                    _replanned.append(_it); continue

                # 仍锁 → 降级：拆子目录
                _mov, _blk = _split_locked_dir_children(_s, _d)
                if _mov:
                    _split_expanded[_s.lower()] = {"movable": _mov, "blocked": _blk}
                    print("[migrate] v1.7.94 降级拆分：%s 整目录锁死，拆出 %d 个可搬子目录(%.2f GB)，"
                          "%d 个搬不动" % (_s, len(_mov), sum(x["size_kb"] for x in _mov) / 1048576.0, len(_blk)))
                else:
                    _replanned.append(_it)
            except Exception:
                _replanned.append(_it)
        # 把拆出来的子目录铺平成新 plan 项（各自建 junction，软件照常用）
        # ★ v1.7.94 P0（实测抓到）：这里必须遍历**原始 plan**，不能遍历 _replanned。
        #   锁住的原项在拆分时没被追加进 _replanned（它已被子项代替，这是对的），
        #   但若遍历 _replanned 就永远查不到它 → 可搬子项从不被加进新 plan →
        #   「静默丢弃，一个字节没搬」（实测 done=0 / 耗时 2.6s）。
        _final_plan = []
        for _it in plan:
            _s = os.path.normpath(_it.get("src", ""))
            _exp = _split_expanded.get(_s.lower())
            if not _exp:
                # 没被拆分的项：取 _replanned 里那份（可能已被强杀后整目录搬）
                _final_plan.append(_it); continue
            for _m in _exp["movable"]:
                _ni = dict(_it)
                _ni["src"] = _m["src"]
                _ni["dst"] = _m["dst"]
                _ni["size_kb"] = _m["size_kb"]
                _ni["kb"] = _m["size_kb"]
                _ni["display_name"] = os.path.join(
                    str(_it.get("display_name") or _it.get("name") or os.path.basename(_s)),
                    _m["name"])
                _ni["_from_split"] = True
                _final_plan.append(_ni)
        plan = _final_plan

        # 拆完后如实记账：搬不动的那几项单列，不静默吞掉
        for _src0, _exp in _split_expanded.items():
            if not _exp["blocked"]:
                continue
            _blk_kb = sum(b["size_kb"] for b in _exp["blocked"])
            _desc = _describe_blocked_children(_exp["blocked"])
            _plan_gb = sum(x["size_kb"] for x in _exp["movable"]) / 1048576.0
            _blk_gb = _blk_kb / 1048576.0
            _all_locked_by_kernel = all(not b.get("lockers") for b in _exp["blocked"])
            if _all_locked_by_kernel:
                # 查不到任何占用进程 + 本机确有过滤驱动 → 驱动层拦截。
                # ★ 绝不说「必须重启」：实测重启后微信/输入法立刻自启，目录照样锁死，
                #   用户只会陷入「重启 → 照样锁 → 再重启」的死循环。
                #   实测出路：降级拆分已搬走绝大部分，剩下的靠「关掉对应软件后补齐」。
                _tail = ("这 %.1f MB 是被系统级安全防护拦下的（我没查到是哪个程序在用，"
                         "这类拦截关掉软件也解不开，只能在安全软件里把它的"
                         "「实时防护/文件监控」暂时关掉再点一次迁移）。"
                         "**不用重启电脑。**" % (_blk_gb * 1024.0,))
            else:
                _tail = "关掉上面那个软件后点「补齐剩余」就能搬完，不用重启电脑。"
            # ★ 绝不说谎：拆分只是「打算搬」，此刻还没搬。
            #   实测踩坑：这里原本写「已经搬走 %.1f GB」，但 done=0 —— 用户点进去
            #   发现一个字节没动，比说「搬不了」更恶劣。现在只报「本轮正在搬的量」
            #   与「搬不动的量」，搬完的真实结果由各子项自己的 msg 如实汇报。
            results["failed"].append({
                "src": _src0, "dst": "",
                "kb": _blk_kb, "ok": False,
                "msg": ("这一项我拆开搬：正在搬 %.1f GB；另有 %.1f MB 搬不动 —— %s%s"
                        % (_plan_gb, _blk_gb * 1024.0, _desc, _tail)),
                "blocked_children": _exp["blocked"],
                "split_degraded": True,
                "planned_gb": round(_plan_gb, 2),
                "blocked_mb": round(_blk_gb * 1024.0, 1),
            })

    for item in plan:
        src = os.path.normpath(item["src"])
        dst = os.path.normpath(item["dst"])
        kb = float(item.get("size_kb", 0) or 0)
        res = {"src": src, "dst": dst, "kb": kb, "ok": False, "msg": ""}

        # ---- 物理搬家分支（mode=move）：copy→校验→删源，不建 junction、不查 personal_root ----
        # 个人大文件（视频/镜像/压缩包）搬去 D 盘即真释放 C 盘；不涉程序，无需原路径解析。
        if item.get("mode") == "move":
            if dry_run:
                res["ok"] = True
                res["msg"] = "（预览）将搬去 D 盘"
                results["done"].append(res)
                results["total_kb"] += kb
                continue
            if not os.path.exists(src) and os.path.exists(dst):
                res["ok"] = True
                res["msg"] = "已搬去 D 盘"
                results["done"].append(res)
                results["total_kb"] += kb
                continue
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                # v1.7.51 提速 Fix1a：单文件高速拷贝改用 robocopy /J（非缓冲大文件 I/O，
                # 比 shutil.copy2 快数倍且不污染缓存）；robocopy 不可用/失败时回退原生拷贝。
                if not _robocopy_copy_file(src, dst):
                    try:
                        shutil.copy2(src, dst)
                    except Exception:
                        pass
                # v1.7.97 P0：删源前加「首尾块哈希」校验，杜绝同大小不同内容的假一致误删。
                if (os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src)
                        and _same_headtail(src, dst)):
                    # v1.7.28（老李拍板：迁移删源接黄金组合）：删源改「rename 进回收站 +
                    # 写标准 $I + SHEmptyRecycleBinW 批量清空」——D 盘副本已校验一致、零丢失，
                    # C 盘空间**秒级释放**（不再被 360/火绒逐文件扫描持句柄延迟，20GB 实测
                    # 之前 30+ 分钟不释放 → 现在 SHEmpty 官方批量 API 杀软放行，秒清）。
                    # 【codex 副本 v1.7.29-candidate 安全修正】：删源改 empty_full_bin=False——
                    # 只精确删除本次自己搬进的 $R 条目，绝不 SHEmptyRecycleBinW 全清用户回收站
                    # （原 True 会把 C 盘用户真实删除的文件一起清掉）。rename 秒级感知不变，
                    # 物理释放由后台精确删除 $R 完成；是否合入线上由老板定夺。
                    import threading as _th
                    def _bg_rm_src():
                        try:
                            _res = fast_purge(src)
                            try:
                                _run_purge_stage_cleanup()
                            except Exception:
                                pass
                            # 删后校验：src 是否真没了。没删掉（被占用/杀软拦）→ 登记重启删兜底，
                            # 绝不静默（防卡 C 盘）。
                            if os.path.exists(src):
                                try:
                                    _schedule_reboot_delete(src)
                                except Exception:
                                    try:
                                        _win_delete(src)
                                    except OSError:
                                        pass
                        except Exception:
                            try:
                                _schedule_reboot_delete(src)
                            except Exception:
                                try:
                                    _win_delete(src)
                                except OSError:
                                    pass
                    try:
                        _t = _th.Thread(target=_bg_rm_src, daemon=True)
                        with _PURGE_LOCK:
                            _PURGE_THREADS.append(_t)
                        _t.start()
                        res["ok"] = True
                        res["msg"] = "已搬去 D 盘（D 盘副本已校验一致，C 盘原文件已秒级清理）"
                    except Exception:
                        try:
                            _win_delete(src)
                            res["ok"] = True
                            res["msg"] = "已搬去 D 盘（释放 C 盘空间）"
                        except OSError as _e:
                            res["ok"] = False
                            res["msg"] = "复制到 D 盘成功，但 C 盘原文件删除失败（可能被占用）：" + str(_e)[:120]
                else:
                    try:
                        _win_delete(dst)
                    except OSError:
                        pass
                    res["ok"] = False
                    res["msg"] = "复制后校验不一致，已取消（绝不删源）"
            except Exception as e:  # noqa
                res["ok"] = False
                res["msg"] = "搬移失败：" + str(e)[:160]
            (results["done"] if res["ok"] else results["failed"]).append(res)
            if res["ok"]:
                results["total_kb"] += kb
            continue

        # ---- 安全护栏 ----
        if _is_personal_root(src):
            res["msg"] = "出于安全，不迁移个人文件夹"
            results["failed"].append(res)
            continue
        # 已迁移（junction/symlink 在）→ 幂等跳过；但若还留着 .bak 残留（上次「主体已搬、
        # 零头被占」的部分完成项），说明用户是来「补齐剩余」的 → 就地搬完再返回，
        # 不必等重启（老李定调：退出软件后点一下就该补上）。
        if _is_junction(src) or os.path.islink(src):
            _bak = src + ".migrated.bak"
            if (not dry_run) and os.path.isdir(_bak):
                # v1.7.86：把真实进度回调透给补齐过程 —— 原来补齐是黑盒，
                # 用户看不到在动，容易以为又卡住了。
                def _comp_prog(_c, _t, _s=None, _src=src):
                    if on_progress:
                        try:
                            on_progress(_src, _c, _t, "补齐剩余")
                        except Exception:
                            pass
                _moved, _left = _complete_bak(_bak, _resolve_dst(dst), release_locks,
                                               on_progress=_comp_prog)
                # 补齐后把残留 .bak 的删除丢后台 —— 删除不是迁移成败判据（v1.7.94）
                try:
                    if os.path.exists(_bak) and not _is_junction(_bak):
                        _bg_purge(_bak)
                except Exception:
                    pass
                res["ok"] = True
                if _left > 0.001:
                    res["msg"] = ("又搬走 %.2f GB，还剩 %.2f GB 仍被占用；重启电脑后会自动搬完。"
                                  % (_moved, _left))
                    _mark(res, "partial", _moved, _left, "reboot")
                else:
                    res["msg"] = "剩余部分已全部搬完，C 盘空间已释放"
                    _mark(res, "done", _moved if _moved > 0 else (kb / 1024 / 1024), 0.0, "")
                results["done"].append(res)
                results["total_kb"] += kb
                continue
            res["ok"] = True
            res["msg"] = "已搬完（软件正常使用，C 盘空间已释放）"
            _mark(res, "done", kb / 1024 / 1024, 0.0, "")
            results["done"].append(res)
            results["total_kb"] += kb
            continue
        if not os.path.exists(src):
            # 源不在：可能已迁移(junction 被删) 或从未存在 → 尝试补 junction
            real_dst = _resolve_dst(dst)
            if os.path.exists(real_dst):
                ok, jerr = _create_junction(src, real_dst)
                if ok:
                    res["ok"] = True
                    res["msg"] = "已迁移（补建 junction）"
                    results["done"].append(res)
                    results["total_kb"] += kb
                    try:  # 清可能残留的 .bak
                        if os.path.exists(src + ".migrated.bak"):
                            fast_purge(src + ".migrated.bak")
                    except Exception:
                        pass
                else:
                    res["msg"] = "junction 创建失败（需管理员？数据在 " + real_dst + "）：" + (jerr or "")[:120]
                    results["failed"].append(res)
            else:
                res["msg"] = "源不存在且目标缺失"
                results["failed"].append(res)
            continue

        if dry_run:
            res["ok"] = True
            res["msg"] = "（预览）将迁移"
            results["done"].append(res)
            results["total_kb"] += kb
            continue

        # ---- 目标去重 + 父目录 ----
        dst_parent = os.path.dirname(dst)
        try:
            os.makedirs(dst_parent, exist_ok=True)
        except Exception as e:  # noqa
            res["msg"] = "创建目标目录失败：" + str(e)[:120]
            results["failed"].append(res)
            continue
        real_dst = _resolve_dst(dst)

        # v1.7.51 提速 Fix2：此处一次性统计源目录（count, bytes），缓存进 meta 供后续
        # 平均文件大小计算与 _migrate_one_copy 复用，避免对 300k 文件树重复 walk。
        src_stats = _dir_stats(src) if os.path.isdir(src) else (0, 0)
        total_bytes = src_stats[1]
        total_mb = max(1, total_bytes // (1024 * 1024))
        # ===== v1.7.89 提速（老李 2026-10-05 真机现场抓到）：/MT 不能再一刀切 32 =====
        # 旧实现：mt = 64 if 单路 else 32。这是**拍脑袋的固定值**，从没问过「这份数据长什么样」。
        # 3 路并发 × 每个 robocopy 32 线程 = 96 线程抢一块盘 → 互相打断寻道，比串行还慢。
        #
        # 真机 A/B 实测（源=ima.copilot 661MB / 3638 文件 / 中位数 5.5KB / 1 个 216MB 大文件，
        # 与豆包同构；D 盘已确认空闲）：
        #   /MT:32  777.6 秒  4.7 文件/秒   ← 旧参数
        #   /MT:16  315.2 秒  11.5 文件/秒  ← 快 2.47 倍
        #   /MT:8   255.7 秒  14.2 文件/秒  ← 快 3.04 倍 ★最优
        #   /MT:8+/J 1101.9 秒 3.3 文件/秒   ← 加 /J 反而比旧参数还慢 1.42 倍（已撤）
        # 结论：**并发越低越快**，32 是最差解。这种「海量小文件 + 少量大文件」的混合体，
        # 小文件的瓶颈是元数据开销与线程争抢（都要低并发），大文件的瓶颈是顺序写
        # （多线程只会互相打断寻道）—— 两种情况**都指向低并发**。
        #
        # 按文件结构自适应（数据来自实测，不靠拍脑袋）：
        #   · 平均文件大（≥1MB）→ 16（榨带宽，仍远低于 32）
        #   · 平均文件小（<1MB）→ 8（实测最优值）
        #   · 单路独占磁盘时略放开：小文件 12、大文件 24
        _nw = max_workers or MIGRATE_MAX_WORKERS
        _nfiles = int(src_stats[0] or 0)
        _avg_kb = (total_bytes / float(_nfiles) / 1024.0) if _nfiles > 0 else 0.0
        if _avg_kb >= 1024.0:            # 平均 ≥1MB：大文件为主
            mt = 24 if _nw <= 1 else 16
        else:                            # 平均 <1MB：小文件为主，实测 8 最优
            mt = 12 if _nw <= 1 else 8
        # 日志里写清「为什么是这个并发」，下次再慢能直接对号入座
        try:
            print("[migrate] plan item mt=%d (avg_file=%.1f KB, files=%d, parallel=%d) src=%s"
                  % (mt, _avg_kb, _nfiles, _nw, src))
        except Exception:
            pass
        copy_items.append({"src": src, "dst": dst, "kb": kb, "res": res,
                           "total_mb": total_mb, "real_dst": real_dst, "mt": mt,
                           "release_locks": release_locks, "src_stats": src_stats})

    if not copy_items:
        return _normalize_results(results)

    # ---- 并行路数自适应（v1.7.18 提速）----
    # 实测（2026-08-01，生产同源 _copy_tree）：大文件为主(游戏库/视频/镜像) 4 路比 3 路快
    # ~44%（13.9 vs 9.6 GB/min）；小文件密集(微信/QQ 聊天文件) 4 路反而比 3 路慢 ~44%
    # （4.2 vs 7.4 GB/min，线程争抢磁盘调度）。故按「平均文件大小」自适应：
    #   平均 ≥ 1MB（大文件为主）→ 用 4 路榨带宽；
    #   平均 < 1MB（小文件密集）→ 用 3 路防线程争抢（3 路在两类场景都达标：30G≤4min）。
    # 兜底不超用户配置（max_workers / migrate_parallel）。
    _cfg_workers = max_workers or MIGRATE_MAX_WORKERS
    try:
        _avg_mb = 0.0
        _tot_b = 0
        _tot_n = 0
        for _ci in copy_items:
            # v1.7.51 提速 Fix2：复用第一遍已缓存的 src_stats，不再对 300k 文件树重 walk
            _st = _ci.get("src_stats") or (_dir_stats(_ci["src"]) if os.path.isdir(_ci["src"]) else (0, 0))
            _tot_b += _st[1]
            _tot_n += _st[0]
        if _tot_n > 0:
            _avg_mb = (_tot_b / _tot_n) / (1024 * 1024)
    except Exception:
        _avg_mb = 1.0  # 异常时走保守 3 路
    _n = max(1, min(_cfg_workers, len(copy_items)))
    if _avg_mb >= 1.0:
        _n = max(_n, min(4, len(copy_items)))  # 大文件为主：优先 4 路（若配置允许且项数够）
    else:
        _n = min(_n, 3)  # 小文件密集：封顶 3 路，防止线程争抢拖慢

    # ---- 第二遍：并行执行「复制-校验-切换」（方案B）----
    # 各项目相互独立（不同源目录），可并发；共享只读资源仅为目标盘剩余空间（用于进度估算）。
    # 零丢失铁律不变：每项目切换前 src 始终完整；任一环节失败都还原或保持源完好。
    target_drive = (os.path.splitdrive(copy_items[0]["dst"])[0] + os.sep) or os.sep
    try:
        free0 = shutil.disk_usage(target_drive).free
    except Exception:
        free0 = None
    # v1.7.51：检测目标盘介质类型，供前端如实提示 HDD 用户迁移较慢（避免虚假 SLA）
    results["target_disk_type"] = _disk_media_type(target_drive)
    total_mb_all = sum(it["total_mb"] for it in copy_items)
    totmap = {it["src"]: it["total_mb"] for it in copy_items}
    st = {"lock": threading.Lock(), "cur": {it["src"]: 0.0 for it in copy_items},
          "done_bytes": 0.0, "total": total_mb_all, "totmap": totmap, "stop": False}

    def _emit():
        if not on_progress:
            return
        with st["lock"]:
            cur = st["done_bytes"] + sum(st["cur"].values())
            # v1.7.88：把速率与 ETA 一起带给调用方（老李「用户等不急」的正面解法）。
            # 用第 4 个可选参数传递 —— 老调用方（3 参）不受影响，签名向后兼容。
            _spd = st.get("speed_mb") or 0.0
            _eta = st.get("eta_sec") or 0
        try:  # 全局进度（src=None）
            on_progress(cur, total_mb_all, None, round(_spd, 2), int(_eta))
        except TypeError:
            # 老签名只接 3 个参数 → 退回旧调用方式，不因新增信息而崩
            try:
                on_progress(cur, total_mb_all, None)
            except Exception:
                pass
        except Exception:
            pass
        with st["lock"]:
            snap = list(st["cur"].items())
        for _s, _c in snap:  # 每项目平滑进度（由全局 free-space 变化按比例摊分）
            try:
                on_progress(_c, totmap.get(_s, 1), _s)
            except Exception:
                pass

    # v1.7.85：停滞检测（老李 2026-10-04 实测「迁移卡 4h48m、页面毫无察觉」）。
    # 只信「真实搬运量是否真的变了」，不信「时间是否在流逝」。
    # 原实现没有这一段 → copytree 兜底期间（0 字节进展）进度条永远显示
    # robocopy 死前的 93.4%，用户对着一个冻结的数字干等 4h48m。
    # 现在：停滞超过 _STALL_WARN_AFTER 秒就如实推 warn，页面明写「我卡住了」。
    st["last_stall_ts"] = _time.time()
    st["last_real_mb"] = -1.0
    st["stall_reported"] = 0
    st["cancel"] = False
    # v1.7.86：v1.7.85 的「用户刹车」（/cancel_migrate + 报告页「停止搬了」按钮）已撤除 ——
    # 那是未经产品决策就加到用户界面上��。改为从根上保证**每个等待点都有终点**：
    # 见 _copy_tree 的 4 处漏洞分析与 do_migrate 主循环的 _BATCH_TOTAL_CAP。
    # st["cancel"] 现在只由服务端自己的超时逻辑置位，不再有任何外部入口。
    # v1.7.85（P0·假进度根治）：st["real"] 存**每项的真实已搬 MB**（由 _copy_tree 逐文件报上来）。
    # ticker 原来只会用「D 盘空间变化」估算，那是猜测；现在有真数据就信真数据。
    # 2026-10-04 实测：页面 93.4% 实为 0% —— 估算值与真相脱节长达 4h48m。
    st["real"] = {}
    # v1.7.93：真停滞判据用的「磁盘实测字节」缓存（src → 真实写入字节数）。
    # 由 _copy_tree 的 robocopy 轮询循环每 0.5 秒采样 dst 体积差分后回填。
    # 为什么不复用 st["real"]：那是 on_progress 报上来的「进度」，而主路径下它恒为 0。
    st["io_bytes"] = {}
    # v1.7.93：每项最后一次「磁盘体积增长」的时刻，用来判「这一项单独卡住了」。
    # 之前只有全局累加值，无法区分「A 项在搬 B 项卡死」和「A、B 都没动」。
    st["io_last_grow"] = {}
    # v1.7.93：每项的 robocopy 诊断（哪个文件、错误码、谁锁着），供停滞播报如实上报。
    st["diag"] = {}
    st["batch_start_ts"] = _time.time()
    # ===== v1.7.88：让用户知道「还要多久」=====
    # 老李 2026-10-05 现场反馈的原话：「迁移的速度非常之慢，按照这个速度用户是等不急的」。
    # 慢是真的（见 mt 自适应那段的实测），但**界面只显示「已搬 3.2GB」，
    # 不显示「按当前速度还要 8 分钟」** —— 用户无法判断这是「在正常推进」还是「卡死了」。
    # 这是个纯产品问题，改起来零风险：ticker 每秒算一次真实速率，
    # 把 speed_mb / eta_sec 一起推给前端，页面直接显示「预计还需 x 分xx 秒」。
    st["speed_mb"] = 0.0
    st["eta_sec"] = 0
    # ===== v1.7.93：停滞阈值 30 → 15 秒，依据来自实测对照 =====
    # 旧值 30 秒注释只有一句「30 秒字节数没变 -> 判为停滞」，**零实测依据**，纯拍脑袋。
    # 实测对照（_live_test/signal_feasibility.py，真跑 robocopy + 独占锁）：
    #   正常搬运 1GB：「进程活着但磁盘零写入」最长 0.0 秒；
    #   人为锁死一个文件：持续 62.4 秒。
    # → 15 秒能干净区分两者，且真卡死时用户 15 秒就知道（比 30 秒体验好一倍）。
    _STALL_WARN_AFTER = 15      # 进程还活着 + 磁盘 15 秒零写入 -> 才判为卡住
    _warn_cb = on_warn if on_warn else None

    # v1.7.85：整批硬顶。单轮最坏 3600s（_copy_tree 上限），MAX_RETRY=1 → 单项最坏 7200s。
    # 但整批不该按「最慢的那一项」无限等 —— 用户要的是「大部分搬完」。
    # 取单轮上限 ×2（7200s = 2 小时）为整批兜底：正常批量（本机 9 项实测
    # 约 11GB，单轮最慢项 baidu 68075 文件按 10 文件/秒算 6807s）不会碰到它；
    # 碰到它就说明确实有异常项，此时交出已完成的部分 + 如实说明，比死等强。
    _BATCH_HARD_CAP = 7200

    def _ticker():
        while not st["stop"]:
            _time.sleep(1.0)
            # ===== v1.7.88：每秒算一次真实速率与剩余时间（让用户看得见「在推进」）=====
            # 用 st["real"]（_copy_tree 逐文件报上来的真实 MB）做差分，不用磁盘估算 ——
            # 估算会因「别的程序也在写 D 盘」而失真，速率会忽高忽低，ETA 跟着乱跳。
            try:
                    # v1.7.93：速率与 ETA 改用【磁盘实测字节】做差分。
                    # 原来用 st["real"]（on_progress 报上来），而 robocopy 主路径
                    # 只在开工前报一次 0 → 速率恒为 0 → ETA 恒为 0 → 页面「预计还需」永远空。
                    _now_real = sum(float(v or 0) for v in st.get("io_bytes", {}).values())
                    _now_ts = _time.time()
                    _prev_ts = st.get("_spd_ts") or _now_ts
                    _prev_mb = st.get("_spd_mb") or 0.0
                    _dt = _now_ts - _prev_ts
                    if _dt >= 1.0:
                        # 指数平滑，避免单秒抖动让 ETA 大跳
                        _inst = max(0.0, (_now_real - _prev_mb) / _dt)
                        _old = st.get("speed_mb") or 0.0
                        st["speed_mb"] = (_old * 0.6 + _inst * 0.4) if _old > 0 else _inst
                        st["_spd_ts"] = _now_ts
                        st["_spd_mb"] = _now_real
                    _cur_mb2 = st["done_bytes"] + sum(st["cur"].values())
                    _left_mb = max(0.0, float(total_mb_all or 0) - _cur_mb2)
                    _sp = st.get("speed_mb") or 0.0
                    st["eta_sec"] = int(_left_mb / _sp) if (_sp > 0.05 and _left_mb > 0.5) else 0
            except Exception:
                pass
            if free0 is not None and total_mb_all:
                try:
                    _fc = max(0, free0 - shutil.disk_usage(target_drive).free)
                    _gp = min(100.0, _fc / (1024 * 1024) / total_mb_all * 100.0)
                except Exception:
                    _gp = 0.0
            with st["lock"]:
                for _s in list(st["cur"].keys()):
                    # 封顶 99%：复制期间绝不能提前显示 100%。
                    # 100% 只在 worker 真正校验通过后才计入 done_bytes，杜绝「满格却失败」。
                    # v1.7.85：有真实搬运量就**只用真实量**，绝不与估算混算（混算就是骗用户）。
                    _real_mb = st["real"].get(_s)
                    if _real_mb is not None:
                        st["cur"][_s] = min(max(0.0, float(_real_mb)), totmap[_s] * 0.99)
                    else:
                        # 没有真实数据才退回估算（并保守打 0.5 折，宁少勿多）
                        st["cur"][_s] = totmap[_s] * min(_gp, 99.0) * 0.5 / 100.0
            # ---- v1.7.85 停滞检测 ----
            # ★ v1.7.93 改判据（老李 2026-10-06 指控「甩锅」的根因修复）：
            #   旧判据读 st["cur"] 里的搬运量，而 **robocopy 主路径的 on_progress
            #   只在开工前报一次 0**（stdout 被丢进 DEVNULL 防死锁）→ 这个数恒为 0
            #   → abs(0-0) > 0.05MB 恒为假 → 「零进展」恒为真 → 正常搬运也弹窗。
            #
            #   新判据（已实测零误报，见 _live_test/signal_feasibility.py）：
            #     进程还活着 + **目标目录真实体积在增长** = 正在搬，不报警；
            #     进程还活着 + 体积连续 _STALL_WARN_AFTER 秒不变 = 这才叫卡住。
            #   实测对照：正常搬运 1GB「活着但零写入」最长 0.0 秒；
            #             人为锁死文件 64 秒 → 62.4 秒。15 秒阈值可干净区分。
            try:
                with st["lock"]:
                    _doing = len(st["cur"])
                    # 汇总「磁盘实测增长量」：各 worker 把自己的真实字节数报上来
                    _io_bytes = sum(float(v or 0) for v in st.get("io_bytes", {}).values())
                    # v1.7.93：找出「体积没增长但还在跑」的那一项，
                    # 停滞播报时用它去查「谁锁着」—— 只有它可能是真凶。
                    _stall_src = ""
                    _stall_idle = _STALL_WARN_AFTER
                    for _s in list(st["cur"].keys()):
                        _d = (st.get("diag") or {}).get(_s) or {}
                        _g = st.get("io_last_grow", {}).get(_s) or 0.0
                        _idl = _time.time() - _g if _g else 0.0
                        if _idl >= max(_stall_idle, _STALL_WARN_AFTER):
                            _stall_src = _s
                            _stall_idle = max(_stall_idle, _idl)
                    if not _stall_src and st["cur"]:
                        _stall_src = list(st["cur"].keys())[0]
                _io_mb = _io_bytes / 1048576.0
                if _io_mb - st["last_real_mb"] > 0.05:   # 真推进了（>0.05MB）
                    st["last_real_mb"] = _io_mb
                    st["last_stall_ts"] = _time.time()
                    st["stall_reported"] = 0
                elif _doing:
                    _idle = _time.time() - st["last_stall_ts"]
                    # v1.7.93：只播报 **1 次**（原来 <3 会连播三遍）。
                    # 老李原话「这么容易就跳出这个窗口」—— 反复弹同一件事，
                    # 对用户就是噪音。真卡死到点就会被收工入队，播一次足够。
                    if _idle >= _STALL_WARN_AFTER and st["stall_reported"] < 1:
                        st["stall_reported"] += 1
                        # ★ v1.7.93：把「谁锁着哪个文件」一起带上去（实测证据，
                        #   不是猜）。查不到就不带 —— 前端会如实说「没告诉我」。
                        _ld, _er = [], []
                        try:
                            _dg = (st.get("diag") or {}).get(_stall_src) or {}
                            _ld = _dg.get("locked_by") or []
                            _er = [{"file": os.path.basename(x.get("file") or ""),
                                    "code": x.get("code"), "text": x.get("text")}
                                   for x in (_dg.get("errors") or [])[:6]]
                        except Exception:
                            pass
                        if _warn_cb:
                            try:
                                _warn_cb({"kind": "stall", "idle_sec": int(_idle),
                                          "progress_mb": round(_io_mb, 1),
                                          "total_mb": round(total_mb_all, 1),
                                          "pending": _doing,
                                          "locked_by": _ld, "errors": _er})
                            except Exception:
                                pass
                        st["last_stall_ts"] = _time.time()   # 播报后重置，防刷屏
            except Exception:
                pass
            # ---- v1.7.85 全局硬顶：单项超时不等于全局可以无限期耗着 ----
            #
            # 2026-10-04 实测：dsh 一项就把整批拖死，**另外 9 项在 21:44 前就复制完了，
            # 却因为 do_migrate 要等所有 future 而一个 junction 都没建** —— 用户视角就是
            # 「折腾 5 小时什么都没搬成」。这是单项超时之外的第二个放大器：
            # 只要有一项慢，全批的成果就被它绑为人质。
            #
            # 现在加一道**整批兜底**：超过 _BATCH_HARD_CAP 秒仍未搬完的，剩下的项
            # 直接中止（已搬部分留在 D 盘、源完好无损，用户下次点「继续」只补缺的），
            # 并如实告知「已搬完几项、哪几项没搬完」。宁可交出部分成果，
            # 也不能交出「零成果 + 无限等待」。
            #
            # v1.7.86：真正的「到点交出成果」已下沉到主循环的 as_completed(timeout=...) ——
            # 因为这一段只置标志位，而 do_migrate 真正等的是 future，置标志位拦不住它。
            # 本段保留：让仍在跑的 _copy_tree 主动收手（少浪费用户的电与时间）。
            if _BATCH_HARD_CAP and (not st["cancel"]):
                if (_time.time() - st["batch_start_ts"]) > _BATCH_HARD_CAP:
                    st["cancel"] = True
                    try:
                        print("[migrate] BATCH hard cap hit (%.0fs) -> abort remaining"
                              % _BATCH_HARD_CAP)
                    except Exception:
                        pass
                    if _warn_cb:
                        try:
                            _warn_cb({"kind": "batch_timeout",
                                      "idle_sec": int(_BATCH_HARD_CAP),
                                      "progress_mb": round(_cur_mb, 1),
                                      "total_mb": round(total_mb_all, 1),
                                      "pending": _doing})
                        except Exception:
                            pass
            _emit()

    def _should_cancel_now():
        """v1.7.86：是否该收工。**只看服务端自己的超时标志**，没有外部入口。

        v1.7.85 这里还会接用户的取消事件 —— 那条链路已随「停止搬了」按钮一并撤除。
        现在它纯粹是「整批预算到了就别再搬了」的内部信号。
        """
        return bool(st.get("cancel"))

    def _worker(meta):
        # v1.7.85（P0·假进度根治）：把「真实已搬 MB」回灌给 ticker。
        # 之前 _copy_tree 的 on_progress 传的是 None（复制阶段完全静默），
        # ticker 只能拿 D 盘空间变化瞎猜 → 老李实测 93.4% 实际 0%，猜了 4h48m。
        def _real_prog(_cur, _tot):
            with st["lock"]:
                st["real"][meta["src"]] = float(_cur or 0)
        _meta = dict(meta)
        _meta["on_item_progress"] = _real_prog
        # v1.7.85：把整批的 cancel 开关透给 _copy_tree，让「整批兜底超时」和
        # 「用户点取消」都能真正打断 robocopy，而不是置个没人看的标志位。
        _meta["should_cancel"] = _should_cancel_now
        # v1.7.93：把共享的「磁盘实测字节」字典传给 _copy_tree，
        # 让 robocopy 主路径的轮询循环把真实写入量回填进去。
        # 没有它，ticker 的停滞检测就只能读那个恒为 0 的 on_progress 数字。
        try:
            _meta["io_sink"] = st["io_bytes"]
        except Exception:
            pass
        # v1.7.93：把「每项最后一次真增长的时刻」也传下去，让 ticker 能判断
        # 「究竟是哪一项卡住了」而不是只知道「整批有东西卡住」。
        try:
            _grow = st["io_last_grow"]
            _src_key = meta.get("src")
            _grow.setdefault(_src_key, _time.time())
            _meta["io_grow_sink"] = _grow
        except Exception:
            pass
        _r = _migrate_one_copy(_meta)
        # v1.7.93：把该项的锁诊断收回共享状态，停滞播报时才能说出「谁锁着」。
        try:
            _dg = _r.get("lock_diag")
            if _dg:
                with st["lock"]:
                    st["diag"][meta["src"]] = _dg
        except Exception:
            pass
        with st["lock"]:
            if _r["ok"]:
                st["done_bytes"] += meta["total_mb"]
                st["cur"].pop(meta["src"], None)
                st["real"].pop(meta["src"], None)
            else:
                # 失败：保留「真实已达成量」（封顶 99%）在进度里，避免进度条从 ~99% 归零、
                # 也避免被前端误渲染成满格成功；失败项不计入 done_bytes，全局进度如实反映。
                _got = st["real"].get(meta["src"])
                _frac = (float(_got) / meta["total_mb"]) if (_got and meta["total_mb"]) else 0.0
                st["cur"][meta["src"]] = meta["total_mb"] * min(0.99, max(0.01, _frac))
        # ===== v1.7.93：单项失败也进「待续搬」清单 =====
        # 老李第三条要求：扫描出来的必须能处理完。绝大多数失败原因是「文件被占用」，
        # 而用户下次打开本工具时那些软件多半已退出 → 那一轮本来就搬得完。
        # 旧逻辑要用户自己记着回来点；现在自动排队、自动续搬。
        if not _r.get("ok"):
            try:
                _srcx = meta.get("src") or ""
                _dstx = _resolve_dst(meta.get("dst") or meta.get("real_dst") or "")
                if _srcx:
                    enqueue_resume(_srcx, _dstx,
                                   reason=str(_r.get("msg") or "")[:120] or "本轮没搬完",
                                   size_kb=float(meta.get("total_mb") or 0) * 1024,
                                   name=os.path.basename(_srcx.rstrip("\\/")))
            except Exception:
                pass
        return _r

    _tk = threading.Thread(target=_ticker, daemon=True)
    st["stop"] = False
    _tk.start()
    # ===== v1.7.86 修漏洞③：主循环 `as_completed(_futs)` 原本**完全没有 timeout** =====
    # 只要有一个 worker 卡住（坏道 / 网络路径 / 死锁文件 / 某个第三方 DLL 挂起），
    # 整批就永远等它 —— 前面 9 项就算全部搬完了，成果一个都交不出来。
    # 这就是老李看到的「折腾几小时什么都没搬成」的结构性原因。
    #
    # 现在：给主循环一个总预算。到点就**交出已完成的部分**，
    # 未完成的项如实标为失败（源目录完好，已搬部分留在 D 盘，下次点迁移只补缺的）。
    # 宁可交出部分成果，也不能交出「零成果 + 无限等待」。
    _BATCH_TOTAL_CAP = 7200        # 整批总预算 2 小时（含所有重试）
    _batch_deadline = _time.time() + _BATCH_TOTAL_CAP
    try:
        # ===== v1.7.88 真机实测揪出并修掉：v1.7.87 的漏洞③修法被 `with` 抵消了 =====
        # 当时只给 as_completed 加了 timeout，就以为「到点能交出成果」。真机实测证明**不行**：
        # `with ThreadPoolExecutor` 退出时执行 `shutdown(wait=True)`，会 join 每一个 worker。
        # 只要有一个 worker 卡住（坏道 / 网络路径 / 死锁文件 / 某个第三方 DLL 挂起），
        # `__exit__` 就永远出不来 —— as_completed 的超时形同虚设，主流程照样无限等待。
        # 实测证据：4 项里 1 项人为 sleep 120s，as_completed 已超时，
        # 但 100 秒真实时间内 do_migrate 仍未返回（_live_test/t4_no_hang.py）。
        #
        # 现在：不再用 `with`。
        #   ① 显式 _ex.shutdown(wait=False, cancel_futures=True) —— 不等任何卡死 worker；
        #   ② 已提交但没跑完的 future 标成功取消；
        #   ③ 仍在跑的 future 交给 daemon 收割线程，搬完就记成功，**绝不让主流程等它**。
        # 这跟 _complete_bak 里修漏洞①是同一套做法（单一真理源，两处必须一致 ——
        # 只改一处等于没改，这正是 v1.7.87 漏掉的那一半）。
        _ex = ThreadPoolExecutor(max_workers=_n)
        _futs = []
        for _m in copy_items:
            _fu = _ex.submit(_worker, _m)
            # v1.7.86：把 meta 挂到 future 上 —— 超时时要把「没跑完的项」
            # 如实记成失败并说清是哪几项，没有这个挂靠就只能报个总数，用户看不懂。
            try:
                _fu._aipc_meta = _m
            except Exception:
                pass
            _futs.append(_fu)
        _left = max(1, int(_batch_deadline - _time.time()))
        try:
            for _fu in as_completed(_futs, timeout=_left):
                try:
                    _r = _fu.result()
                    results["done" if _r["ok"] else "failed"].append(_r)
                    # ===== v1.7.88 真机实测揪出：并行路径**从不累加 total_kb** =====
                    # 串行分支每条都写了 total_kb += kb，唯独并行主循环这条 append 没写 →
                    # 只要走真实迁移，do_migrate 返回的 total_kb 恒为 0.0。
                    # 目前 server 不消费它（迁移量走 mig_records[].done_gb），所以页面上
                    # 没露馅；但这是**对外 API 说谎**，任何新调用方一信就错。
                    # 宁小不虚高：这里只加成功项的 kb，绝不把失败项算进去。
                    if _r.get("ok"):
                        results["total_kb"] += float(_r.get("kb") or 0)
                except Exception:
                    pass
        except FuturesTimeoutError:
            # 到预算仍未跑完 —— 如实记账，交出已完成的部分
            _hung = 0
            for _fu in _futs:
                if not _fu.done():
                    _hung += 1
                    _m = getattr(_fu, "_aipc_meta", None)
                results["failed"].append({
                    "src": (_m or {}).get("src", "?"),
                    "dst": (_m or {}).get("dst", ""),
                    "ok": False,
                    "bytes": 0,
                    "gb": 0.0,
                    "msg": ("这一项没在时间预算内搬完，已中止等待。"
                            "C 盘原数据完好无损，已搬走的部分保留在目标盘，"
                            "下次点「迁移」只会补没搬完的，不会重来。"),
                })
                # ===== v1.7.93：卡住的项落进「待续搬」清单 =====
                # 老李第三条要求：扫描出来的必须能处理完。旧逻辑到这里就结束了，
                # 要用户自己记住「哪一项没搬完、退了什么软件、回来再点一次」。
                # 现在把它排队：下次打开工具自动接着搬（resume_pending_migrations），
                # 用户什么都不用记。源目录仍完好，零丢失前提不变。
                try:
                    _ms = (_m or {}).get("src", "")
                    if _ms and _ms != "?":
                        enqueue_resume(_ms, (_m or {}).get("dst", ""),
                                       reason="没在时间预算内搬完",
                                       size_kb=float((_m or {}).get("total_mb") or 0) * 1024,
                                       name=os.path.basename(_ms.rstrip("\\/")))
                except Exception:
                    pass
            try:
                print("[migrate] batch budget %.0fs hit -> %d item(s) unfinished, "
                      "delivering completed part" % (_BATCH_TOTAL_CAP, _hung))
            except Exception:
                pass
        # ===== 无论正常跑完还是预算到点，都**不 join** 卡死的 worker =====
        try:
            for _fu in _futs:
                try:
                    _fu.cancel()
                except Exception:
                    pass
        except Exception:
            pass
        try:
            _ex.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            # 老 Python 没有 cancel_futures 参数
            try:
                _ex.shutdown(wait=False)
            except Exception:
                pass
        except Exception:
            pass
        # 收割仍在跑的 future：搬完就记成功，绝不让主流程等它
        def _reap_main():
            for _fu in _futs:
                try:
                    if _fu.cancel():
                        continue
                    _ok_r = _fu.result()
                except Exception:
                    continue
                if _ok_r and _ok_r.get("ok"):
                    try:
                        with st["lock"]:
                            st["late_done"] = st.get("late_done", 0) + 1
                    except Exception:
                        pass
        threading.Thread(target=_reap_main, daemon=True).start()
    finally:
        st["stop"] = True
        try:
            _tk.join(timeout=3)
        except Exception:
            pass
        _emit()
    return _normalize_results(results)


def _complete_bak(bak, dst, release_locks=None, on_progress=None):
    """就地补齐：把 .bak 里剩下的文件搬到已迁移的目标目录，搬成功一个删一个。

    用于「主体已切换 junction、零头被占用」的 partial 项——用户退出软件后点「补齐剩余」，
    这里立刻把残留搬完并释放 C 盘，不必等重启。
    零丢失铁律：只有确认目标已有同名同大小的文件，才删除 .bak 里的源文件。
    返回 (moved_gb, left_gb)。
    """
    if not os.path.isdir(bak):
        return (0.0, 0.0)
    _bst = _dir_stats(bak)
    before = _bst[1]
    if release_locks:
        try:
            release_locks(bak)
        except Exception:
            pass
    # v1.7.85：同 _copy_tree 主调用点 —— 补齐残留时也必须传文件数，
    # 否则海量小文件的 .migrated.bak 补齐会被按 MB 严重低估时限而中途超时。
    # v1.7.86：传真实进度回调（原来传 None → 补齐过程对用户完全黑盒，
    # 用户不知道是在动还是又卡住了，这是「卡住感」的另一个来源）。
    def _bak_prog(_cur, _tot, _s):
        try:
            if on_progress:
                on_progress(_cur, _tot, _s)
        except Exception:
            pass
    try:
        _copy_tree(bak, dst, on_progress=(_bak_prog if on_progress else None),
                   total_mb=max(1, before // (1024 * 1024)), mt=32,
                   total_files=int(_bst[0] or 0))
    except Exception:
        pass
    for _dp, _dn, _fn in os.walk(bak):
        _rel = os.path.relpath(_dp, bak)
        _tdir = os.path.join(dst, _rel)
        for _fl in _fn:
            _sf = os.path.join(_dp, _fl)
            _tf = os.path.join(_tdir, _fl)
            try:
                # v1.7.97 P0：删源前加「首尾块哈希」校验，杜绝同大小不同内容的假一致误删。
                # v1.7.100（真实释放铁律）：改走 _win_delete（DeleteFileW 直删）。
                #   原 os.remove 在部分运行环境里会把删除重定向到**回收站**——而回收站
                #   就在 C 盘上，等于「看起来删了、C 盘一点没松」，补齐剩余（本该立刻
                #   释放 C 盘的核心路径）反而成了占盘黑洞。
                if (os.path.exists(_tf) and os.path.getsize(_tf) == os.path.getsize(_sf)
                        and _same_headtail(_sf, _tf)):
                    try:
                        _win_delete(_sf)
                    except Exception:
                        pass
            except Exception:
                pass
    left = _dir_stats(bak)[1] if os.path.isdir(bak) else 0
    if left <= 0:
        # v1.7.100：整目录收尾同样禁用 shutil.rmtree（会被拦进回收站 / 撞批量闸），
        # 走 _fast_delete_dir（rd /s /q + WinAPI 扫尾，物理删除）。
        try:
            _fast_delete_dir(bak, max_sec=300)
        except Exception:
            pass
    return ((before - left) / (1024 ** 3), left / (1024 ** 3))


def _normalize_results(results):
    """兜底：确保每一条结果都带 status/done_gb/pending_gb/resume。

    没被 _mark 打过标的分支（护栏、幂等、dry_run、move、空间不足等）按 ok 推断，
    保证 server 层与报告永远拿得到结构化状态，不会出现「结果凭空消失」。
    """
    for _bucket in ("done", "failed"):
        for _r in results.get(_bucket) or []:
            if _r.get("status"):
                continue
            _gb = round(float(_r.get("kb") or 0) / 1024 / 1024, 2)
            if _r.get("ok"):
                _r["status"] = "done"
                _r["done_gb"] = _gb
                _r["pending_gb"] = 0.0
                _r["resume"] = ""
            else:
                _r["status"] = "failed"
                _r["done_gb"] = 0.0
                _r["pending_gb"] = _gb
                _r["resume"] = _r.get("resume") or "close_app"
    return results


def _mark(res, status, done_gb=0.0, pending_gb=0.0, resume=""):
    """给单项结果打上结构化状态，供 server 如实记账 + 报告诚实渲染。

    status:
      done           全部搬完，C 盘已释放（或后台正在释放）
      partial        主体已搬走、软件正常用，剩余零头待补齐（重开工具自动补齐）
      reboot         （v1.7.82 起不再产生此状态，保留仅为兼容历史数据渲染）
      staged         已在目标盘暂存副本，源未动；退出软件后可秒级补齐
      failed         没动成，源完好，数据零丢失
    resume: "" | "reboot"（重启电脑后重开本工具自动补齐） | "close_app"（退出软件后点补齐）
    """
    res["status"] = status
    res["done_gb"] = round(max(done_gb, 0.0), 2)
    res["pending_gb"] = round(max(pending_gb, 0.0), 2)
    res["resume"] = resume
    return res


def _lock_truth(diag_sink, src, swap=None):
    """v1.7.93：取出本次迁移的**实测**锁诊断。

    返回 (谁锁着, 涉及文件, 原因, 诊断字典)。
    老李 2026-10-06：「是什么就是什么。」—— 全部来自 robocopy 真实输出 +
    Restart Manager / lockfinder 真实进程，查不到就返回空，绝不编。

    ★ swap：_relock_rename 的返回值。它的 L2/L3 层本来就在用 RM + lockfinder
      实测定位真凶（返回 dict["lockers"] 里就是真实进程名），但这条信息以前
      只进了它自己的 msg，没进 res["lock_diag"] → 报告页拿不到 → 只能写
      「切换被挡住了」这种废话。E2E 实测（test_e2e_truth.py）正是栽在这里：
      复制阶段全部成功（robocopy 没报错），失败发生在改名那一步，
      于是 diag_sink 是空的、lockers 却有真凶。两侧都要接上。
    """
    _dg = (diag_sink or {}).get(src) or {}
    _who = [str(x) for x in (_dg.get("locked_by") or []) if x]
    # 改名阶段实测到的占用者，与复制阶段合并去重
    try:
        for _x in ((swap or {}).get("lockers") or []):
            _x = str(_x)
            if _x and _x not in _who:
                _who.append(_x)
    except Exception:
        pass
    _errs = _dg.get("errors") or []
    _fname = os.path.basename(_errs[0].get("file") or "") if _errs else ""
    _ftext = (_errs[0].get("text") or "") if _errs else ""
    return _who, _fname, _ftext, {
        "locked_by": _who,
        "errors": [{"file": os.path.basename(x.get("file") or ""),
                    "code": x.get("code"), "text": x.get("text")}
                   for x in _errs[:6]],
        "summary": _dg.get("summary") or "",
    }


def _why_blocked_text(who, fname, ftext):
    """把实测诊断拼成人话。老李要求：问题与操作必须明确，是什么就是什么。

    ★ 绝不说「多半是…」「可能是…」—— 那是把责任推给用户去猜。
      查得到就说名字；查不到就**如实说系统没告诉我**，并说清我下一步怎么做。
    """
    if who:
        _base = ("%s正锁着这个目录里的文件" % "、".join(who))
        if fname:
            _base += "（例如 %s）" % fname
        return _base + "。把那个软件退出来，我就能搬完。"
    if ftext:
        _base = "系统报错「%s」" % ftext
        if fname:
            _base += "，涉及文件 %s" % fname
        return (_base + "。系统没有告诉我具体是哪个程序在用，这里我不猜 —— "
                       "你关掉正在运行的软件再点一次，或重启电脑后我会自动接着搬。")
    _base = "还有文件没能搬过来"
    if fname:
        _base += "（例如 %s）" % fname
    return (_base + "。我会收工并记下来，下次你打开本工具自动接着搬，源目录一个字节没动。")


def _stage_reboot_fallback(src, real_dst, res, all_gb):
    """STAGED 兜底（老李铁律：显示可迁移就必须能干掉）。函数名保留自 v1.7.81 的
    「登记下次登录自动完成」通道；v1.7.82（过审改造）起该通道已彻底移除（绝不注册
    任何开机/登录任务），本函数恒按 staged 收尾。

    - 数据已完整备在目标盘（复制-校验已通过），源未动、零丢失；
    - 用户退出占用软件后点「补齐剩余」可秒级完成；或重启电脑后重新打开本工具，
      启动兜底（auto_cleanup_orphan_baks）会自动继续完成切换并释放 C 盘；
    - res["msg"] 由调用方在 staged 返回前已设好，本函数不改变源、不重复安抚。
    """
    return _mark(res, "staged", 0.0, all_gb, "close_app")


def _migrate_one_copy(meta):
    """单项目「复制-校验-切换」（方案B 并行 worker 调用）。零丢失、原子切换、可自愈。

    自我修复（根治「花了时间最后还失败」）：
      - 复制前先整组强杀所属软件（release_locks），降低被锁概率；
      - 若复制/校验因「个别文件被锁」失败，自动 release_locks 后增量补复制
        （robocopy /E 只拷缺失文件，重试仅秒级），最多重试 MAX_RETRY 次；
      - 同盘改名（原子切换）若被占，同样自动 release_locks 后重试。
    任一环节仍失败才返回失败，且源始终完好、绝不丢数据。
    返回修改后的 res 字典（含 ok/msg）。
    """
    src = meta["src"]
    dst = meta["dst"]
    kb = meta["kb"]
    res = meta["res"]
    total_mb = meta["total_mb"]
    real_dst = meta["real_dst"]
    mt = meta["mt"]
    release_locks = meta.get("release_locks")
    # 一次性统计源目录（文件数、字节数），后续校验/占比计算全部复用，避免重复 walk。
    # v1.7.51 提速 Fix2：优先复用调用方已缓存的 src_stats，避免重复全树 walk
    src_stats = meta.get("src_stats") or (_dir_stats(src) if os.path.isdir(src) else (0, 0))
    # v1.7.85：把「文件数」也传进 _copy_tree —— 超时必须由 MB 和文件数双维度决定，
    # 只看 MB 会对 node_modules 这类海量小文件严重低估（实测 522MB/62552 文件，
    # 按 MB 算 8.7 分钟就超时，按实测速率需要 55 分钟）。详见 _copy_tree 内注释。
    total_files = int(src_stats[0] or 0)
    # 第一时间锁探测（复制前）：被杀软内核锁(av_kernel)直接跳过；进程锁先强杀再探测，
    # 仍锁则跳过。避免投入数分钟复制后失败（根治「迁了半天最后全失败」）。
    # classify_lock 仅做瞬时改名试探（源在复制前即改名回，不复制任何数据），对 free 项零副作用。
    try:
        _bt0 = classify_lock(src)
    except Exception:
        _bt0 = "free"
    _all_gb = (kb / 1024 / 1024) if kb else (src_stats[1] / (1024 ** 3))
    # v1.7.33（老李定调：绝不一刀切）——这里曾是「一刀切」的真凶：
    # 目录里只要有**一个**文件被独占（微信运行中必然如此），锁探测就把整个目录直接跳过，
    # 一个字节都不搬。30GB 的微信因此原地不动，用户当然炸毛。
    # 现在改为：锁只作为「补齐建议」的线索，照样往下走——robocopy 会自动跳过锁着的文件
    # 把能搬的先搬走（/R:0 /W:0 对锁文件秒失败，不会卡住），
    # 之后主体够就切换 junction（partial），不够就留在目标盘暂存（staged）等补齐。
    _lock_hint = ""
    if _bt0 == "av_kernel":
        _lock_hint = "reboot"      # 杀软内核锁：重启时锁最少
    elif _bt0 == "process":
        _lock_hint = "close_app"   # 程序占用：退出软件即可
        if release_locks:
            try:
                release_locks(src)
            except Exception:
                pass
            _time.sleep(0.5)
            try:
                if classify_lock(src) == "free":
                    _lock_hint = ""
            except Exception:
                pass
    # 热修复提速：重试从 3 降到 1。一次复制失败（个别文件被锁）不再原地空转，
    # 直接走「主体切换 junction + 重启补齐」兜底（零丢失且立即释放 C 盘），避免迁移卡死数分钟。
    MAX_RETRY = 1

    # ---- 复制（保留源）+ 校验；已完整则跳过复制直接切换 ----
    # 复制前预释放：用户已选择迁移，关闭占用程序是预期行为，先杀一次所属软件组
    if release_locks:
        try:
            release_locks(src)
        except Exception:
            pass

    copied_ok = False
    # AIPC-DST-FOREIGN-FIX：目标盘上是否有「源里没有的数据」。有则成功条件放宽为
    # 「源被目标完整覆盖」（因为绝不能为了两边相等去删目标上的陌生数据）。
    dst_has_foreign = False
    for attempt in range(MAX_RETRY + 1):
        if attempt > 0 and release_locks:
            # 重试：释放锁后增量补复制（不 rmtree，robocopy /E 只拷缺失文件，秒级）
            try:
                release_locks(src)
            except Exception:
                pass
            _time.sleep(1.0)  # 等句柄回收
        if attempt == 0 and os.path.exists(real_dst):
            # 已有副本：校验一致则直接复用（省去数分钟重拷）
            if _verify_equal(src, real_dst, src_stats):
                copied_ok = True
                break
            # 上次没搬完留下的暂存副本 → 直接增量续传：robocopy /E 只补缺的那部分，
            # 秒级完成，绝不推倒重来让用户白等一遍。
            #
            # AIPC-DST-FOREIGN-FIX（P0，2026-09-16 在真实机器上实测到的必翻车点）：
            # 原实现用【聚合大小】(文件数+字节数都 ≤ 源) 猜「目标是不是源的子集」，猜错就翻车。
            # 真机实测：D:\AI_PC_Migrated\Roaming_Tencent = 12102 文件 / 4.69GB，
            # 源 C:\...\Roaming 下的 Tencent = 18931 文件 / 6.86GB —— 聚合上「≤ 源」成立，
            # 于是不清目标；可它里面还混着 8867 个源里根本没有的文件（程序自己轮换掉的
            # 日志 / sqlite-shm 等）。robocopy 增量补完后目标变成 18931+8867 个文件，
            # 而 _verify_equal 要求【文件数与字节数精确相等】→ 永远判不成功 → 迁移只停在
            # partial：白拷一遍、6.86GB 的 .bak 卡在 C 盘不释放，还给用户报一句不实的
            # 「还剩约 6.86 GB 正被占用」。
            #
            # 现在改成【逐路径】判定，二分处理，两条路都零丢失：
            #   · 目标是源的冗余副本（每个目标文件在源里都有同名同大小）→ 清掉重拷最干净；
            #   · 目标里有源里没有的数据（可能是用户唯一一份）→ 绝不清！同盘改名挪到
            #     <目标>.previous（元数据操作、秒级、零丢失），本次在一份干净目标上做；
            #     挪不动也不硬失败 → 退化为就地增量，成功条件放宽为「源被目标覆盖」。
            try:
                _ds = _dir_stats(real_dst)
            except Exception:
                _ds = (10 ** 9, 10 ** 18)
            if _ds[0] <= src_stats[0] and _ds[1] <= src_stats[1] and _dst_is_redundant(real_dst, src):
                try:
                    fast_purge(real_dst)
                except Exception:
                    pass
            else:
                _aside = real_dst + ".previous"
                try:
                    if os.path.exists(_aside):
                        _aside = _aside + "." + _time.strftime("%Y%m%d_%H%M%S")
                    os.rename(real_dst, _aside)
                    res["dst_prev_aside"] = _aside
                except Exception:
                    dst_has_foreign = True
        # v1.7.85（P0·假进度根源）：原来这里是 on_progress=None —— 复制阶段**一次进度都不报**，
        # 页面上的 93.4% 完全靠 do_migrate 的 ticker 估算，而 ticker 是拿「目标盘剩余空间变化量」
        # 反推的：D 盘被别的程序写入、或本次复制中途停滞，估算就永远停住。
        # 老李 2026-10-04 实测：迁移卡 4h48m，页面一直显示 634/679MB (93.4%)，
        # 而 D 盘实际上一个字节都没落 —— 该项已搬 0/679MB。
        # 现在把真实进度回调传下去（单项目维度），并加阶段日志，卡点下次能秒定位。
        def _item_prog(_cur, _tot, _s):
            if _s is not None and _s == src and meta.get("on_item_progress"):
                try:
                    meta["on_item_progress"](_cur, _tot)
                except Exception:
                    pass
        # v1.7.93：把 robocopy 的诊断结果收上来（哪个文件、错误码、谁锁着）。
        # 传下去后失败分支能据此说出**具体是谁锁着**，而不是「多半是软件占用」。
        _diag_sink = {}
        copied = _copy_tree(src, real_dst, on_progress=_item_prog, total_mb=total_mb, mt=mt,
                        total_files=total_files,
                        should_cancel=meta.get("should_cancel"),
                        io_sink=meta.get("io_sink"),
                        io_grow_sink=meta.get("io_grow_sink"),
                        diag_out=_diag_sink)
        if copied:
            # dst_has_foreign 时目标允许有源里没有的文件（绝不删用户数据），
            # 成功条件放宽为「源被目标完整覆盖」；其余情况仍要求两侧精确相等。
            if ((not dst_has_foreign and _verify_equal(src, real_dst, src_stats))
                    or (dst_has_foreign and _src_covered_by_dst(src, real_dst, src_stats))):
                copied_ok = True
                break
        # 复制不完整（被锁文件）：进入下一轮重试（release_locks 后增量补复制）
    if not copied_ok:
        # 自愈 + 白名单强杀后仍不完整：绝不「默默整体失败、C 盘一分不释放」。
        # 已复制的主体留在 real_dst；若主体占比足够（≥50%），立即切换 junction：
        #   软件马上可用、C 盘立即释放主体空间；残留的极少数死锁文件留在 .bak，
        #   安排「下次开机自动补齐」（届时锁最少，必能搬完 → C 盘彻底释放），零丢失。
        # 若主体占比过低（<50%，几乎没拷动），说明仍被严重占用，保持源完好返回失败，
        # 让用户关闭程序后重试，避免把残缺数据切上去。
        _copied = _dir_stats(real_dst)[1] if os.path.exists(real_dst) else 0
        _total = src_stats[1]
        _frac = (_copied / _total) if _total > 0 else 0.0
        if _frac >= 0.5:
            bak = src + ".migrated.bak"
            if os.path.exists(bak):
                # ★ v1.7.94：改后台删。实测同步 fast_purge 删 1.39GB 的 .bak
                #   把整个迁移卡了 37 分钟（数据早拷完，全耗在这一步）。
                #   清理不是迁移成败判据 —— junction 建好就算成功，.bak 删不掉有重启兜底。
                try:
                    _bg_purge(bak)
                except Exception:
                    pass
                # 等一小会儿让旧 .bak 改名让路（只等 1.2s，绝不硬等删完）
                for _w in range(12):
                    if not os.path.exists(bak):
                        break
                    _time.sleep(0.1)
            swap = _relock_rename(src, bak, real_dst, release_locks, quick=True)
            if swap["reboot"]:  # v1.7.82 起恒不成立（不再注册开机任务），保留仅为兼容
                res["ok"] = True
                res["reboot_commit"] = True
                res["committed_gb"] = round(kb / 1024 / 1024, 2) if kb else 0.0
                res["msg"] = swap["msg"]
                return _mark(res, "reboot", 0.0, _all_gb, "reboot")
            if not swap["renamed"]:
                # 已复制的主体保留在目标盘（暂存），退出软件后可秒级增量补齐，绝不白拷一遍
                # v1.7.93：原文案「软件正在使用中」= 让用户猜是谁 → 改为指名道姓。
                _w1, _f1, _t1, _d1 = _lock_truth(_diag_sink, src, swap)
                res["msg"] = ("已在目标盘备好 %.2f GB，但最后一步切换被挡住了：%s"
                              "数据已备好，不用重拷；你处理完上面那个软件后点「补齐剩余」，"
                              "或重启电脑后我自动接着搬。"
                              % (_copied / (1024 ** 3), _why_blocked_text(_w1, _f1, _t1)))
                if _d1:
                    res["lock_diag"] = _d1
                return _stage_reboot_fallback(src, real_dst, res, _all_gb)
            ok, jerr = _create_junction(src, real_dst)
            if ok:
                leftover = _dir_stats(bak)[1] if os.path.exists(bak) else 0
                leftover_gb = leftover / (1024 ** 3)
                sch = _schedule_reboot_complete(bak, real_dst)  # v1.7.82 起恒 False（不再注册任务）
                _clean_previous_asides(real_dst)
                res["ok"] = True
                res["partial"] = True
                if leftover_gb > 0.001:
                    # v1.7.82：零头不再靠开机任务搬，改由「重启电脑 → 重新打开本工具」
                    # 的启动兜底（auto_cleanup_orphan_baks → _complete_bak）自动补齐，零丢失。
                    # v1.7.93：这段文案原来写「正被占用」——猜测。现在有实测证据
                    # （哪些文件、哪个进程），直接指名，不再让用户猜。
                    _dg2 = (_diag_sink or {}).get(src) or {}
                    _who2 = _dg2.get("locked_by") or []
                    _who_txt = ("是 %s 在占用" % "、".join(_who2)) if _who2 else "还有文件没搬完"
                    res["msg"] = (
                        "主体已搬走、软件正常使用，C 盘已释放 %.2f GB。还剩约 %.2f GB（%s）。"
                        "重启电脑后重新打开本工具，会自动把剩余部分搬完。"
                        % (max(_all_gb - leftover_gb, 0.0), leftover_gb, _who_txt)
                    )
                    if _dg2:
                        _e2 = _dg2.get("errors") or []
                        res["lock_diag"] = {
                            "locked_by": _who2,
                            "errors": [{"file": os.path.basename(x.get("file") or ""),
                                        "code": x.get("code"),
                                        "text": x.get("text")} for x in _e2[:6]],
                            "summary": _dg2.get("summary") or "",
                        }
                    return _mark(res, "partial", max(_all_gb - leftover_gb, 0.0), leftover_gb, "reboot")
                res["msg"] = "已搬完（软件正常使用，C 盘空间已释放）"
                return _mark(res, "done", _all_gb, 0.0, "")
            else:
                try:
                    os.rename(bak, src)  # 还原，零丢失
                except Exception:
                    pass
                res["msg"] = ("已在目标盘备好 %.2f GB，但切换没成功，源一个字节没动。"
                              "退出相关软件后点「补齐剩余」即可秒级完成。" % (_copied / (1024 ** 3)))
                _w0, _f0, _t0, _d0 = _lock_truth(_diag_sink, src, swap)
                if _d0:
                    res["lock_diag"] = _d0
                return _stage_reboot_fallback(src, real_dst, res, _all_gb)
        # 主体只拷动一小部分：不丢弃已复制的数据（下次增量续传秒级），源保持完好。
        # 老李定调：能迁多少迁多少，绝不一刀切从头再来。
        if _copied > 0:
            _w2, _f2, _t2, _d2 = _lock_truth(_diag_sink, src, swap)
            res["msg"] = ("已在目标盘备好 %.2f / %.2f GB，但切换被挡住了：%s"
                          "剩下的会接着传（不用重来）。"
                          % (_copied / (1024 ** 3), _all_gb,
                             _why_blocked_text(_w2, _f2, _t2)))
            if _d2:
                res["lock_diag"] = _d2
            return _stage_reboot_fallback(src, real_dst, res, _all_gb)
        if _lock_hint == "reboot":
            res["msg"] = "整个目录被安全软件锁住（如 360 实时防护），一个字节都搬不动；源完好无损。重启电脑后重新打开本工具，再点一次迁移即可"
        else:
            # ===== v1.7.93：把「正被程序占用」升级为指名道姓 =====
            # 原来只有一句「正被程序占用」+ 让用户自己猜是哪个软件，
            # 这是甩锅。现在有 robocopy 的实测证据（哪个文件、错误码 32）
            # 和 Restart Manager 查出的真实占用进程名，直接说出来。
            _w3, _f3, _t3, _d3 = _lock_truth(_diag_sink, src, swap)
            res["msg"] = ("一个字节都没能搬动：%s源完好无损。" % _why_blocked_text(_w3, _f3, _t3))
            if _d3:
                res["lock_diag"] = _d3
        return _mark(res, "failed", 0.0, _all_gb, _lock_hint or "close_app")

    # ---- 原子切换：同盘改名 src→bak，再建 junction；被占则多层兜底（白名单杀→RM 精准释放→诚实失败）----
    bak = src + ".migrated.bak"
    swap = _relock_rename(src, bak, real_dst, release_locks)
    if swap["reboot"]:
        # v1.7.82 起恒不成立（不再注册开机任务），保留仅为兼容
        res["ok"] = True
        res["reboot_commit"] = True
        res["committed_gb"] = round(kb / 1024 / 1024, 2) if kb else 0.0
        res["msg"] = swap["msg"]
        return _mark(res, "reboot", 0.0, _all_gb, "reboot")
    if not swap["renamed"]:
        # 数据已完整备在目标盘，只差最后一步切换：保留副本，退出软件后秒级补齐
        # v1.7.93：原文案「软件正在使用中」= 猜测，改为指名道姓。
        _w4, _f4, _t4, _d4 = _lock_truth(_diag_sink, src, swap)
        res["msg"] = ("数据已完整备好在目标盘（%.2f GB），只差最后一步切换：%s"
                      "点「补齐剩余」，几秒钟就能完成。" % (_all_gb,
                                                        _why_blocked_text(_w4, _f4, _t4)))
        if _d4:
            res["lock_diag"] = _d4
        return _stage_reboot_fallback(src, real_dst, res, _all_gb)
    ok, jerr = _create_junction(src, real_dst)
    if not ok:
        try:
            os.rename(bak, src)  # 还原，零丢失
        except Exception:
            # 还原失败极罕见：数据在 bak(C盘) 与 real_dst(D盘) 均在，可手动处理
            pass
        res["msg"] = "最后一步切换没成功，源一个字节没动（数据零丢失）：" + (jerr or "")[:100]
        return _stage_reboot_fallback(src, real_dst, res, _all_gb)

    _clean_previous_asides(real_dst)
    # 成功：删除 .bak 释放 C 盘空间（junction 已确认可用；
    # 仅当 bak 是真实目录才删，避免误删 junction 指向的 D 盘目标数据）
    # v1.7.24（迁移 5 分钟达标）：删 .bak 改【后台异步】——复制/校验/rename/junction 全部秒级
    # ~分钟级，唯独删源（.bak）被杀软逐文件扫描（本机实测 23MB/s，13GB 要 9.5 分钟）。
    # 后台线程删（登记 _PURGE_THREADS，server 校准线程等待后磁盘实测），前台立即返回
    # 「迁移完成」；junction 已生效、软件正常用 D 盘数据，C 盘空间由后台逐步释放。
    #
    # v1.7.37（审查修复·P0，防止用户 C 盘被搞满）：原实现有致命缺陷——_bg_rm_bak 是
    # daemon 线程且 `except Exception: pass` 静默吞错，fast_purge 的残留返回被丢弃，
    # cleanup_ok 在线程删除前就恒为 True。一旦后台删源失败（杀软逐文件拦 / explorer 锁 /
    # server 进程退出杀掉 daemon 线程），.bak 就永久卡在 C 盘（aipc_purge 暂存区或回收站
    # $R），C 盘不释放但报告已谎报「已搬完」——用户 C 盘被慢慢塞满。现改为：
    #   1) 删除前先锁探测：源明显被锁（quick 改名失败过）→ 直接走重启删，不空转；
    #   2) 后台删除线程结束后【再校验】bak 是否真的没了；
    #   3) 若还在 → 登记重启删，并【确认登记成功】（MoveFileExW 写 HKLM 需管理员，
    #      失败则如实报「需管理员清理」，绝不谎报）；
    #   4) 把真实残留写回 _PURGE_RESIDUAL，供 server 校准线程如实展示「待重启清理 X GB」。
    # ===== v1.7.37（审查修复·P0，防止用户 C 盘被搞满）：删源必须「可验证 + 诚实」=====
    # 原实现致命缺陷：删源是 daemon 后台线程，主流程立刻返回「已搬完」；后台 fast_purge
    # 一旦失败（杀软逐文件拦 / explorer 锁 / server 退出杀掉 daemon），.bak 永久卡在
    # C 盘（暂存区或回收站 $R），C 盘不释放但报告谎报「已搬完」→ 用户 C 盘被慢慢塞满。
    #
    # 修复原则（既秒级又诚实）：
    #   1) 同步先做【快速改名探测】——把 .bak 尝试 rename 到暂存区（秒级元数据操作）。
    #      · rename 成功 → 说明目录大概率能删 → 后台删暂存区（fast_purge），前台秒级返回
    #        「已搬完，后台释放」，但残留会登记重启删兜底；
    #      · rename 失败（被 explorer/杀软占用）→ 同步登记重启删（写 HKLM，秒级），
    #        并【如实报】「已安排重启后自动清理 X GB」，绝不谎报「已搬完」。
    #   2) 登记重启删后【校验登记成功】（MoveFileExW 写 HKLM 需管理员）；失败则如实报
    #      「需管理员清理」，也不谎报。
    #   —— 这样无论哪种情况，用户看到的都是真实状态，绝不会再出现「报告已搬完、
    #      C 盘却没释放、.bak 悄悄卡着」的坑。
    cleanup_ok = True
    cleanup_msg = ""
    _bak_size = 0.0
    try:
        _bak_size = _dir_size_bytes(bak) / (1024 * 1024 * 1024)
    except Exception:
        pass
    try:
        if not _is_junction(bak) and os.path.exists(bak):
            # v1.7.50（无残留根治）：junction 已确认可用，旧源 .bak 改用与 mode=move
            # 同源的 recycle_bin_fast_purge（rename 进回收站，0.003s 元数据操作、杀软不拦；
            # 物理删除由函数内后台线程完成，20GB 实测秒级）——替代原先脆弱的「改名暂存区 +
            # 自管 daemon 删」（被杀软逐文件拦 / explorer 锁 / server 退出杀线程而失败 →
            # .bak 永久卡 C 盘）。
            # v1.7.55（统一机制，根治回收站残留）：迁移删 .bak 改用与「一键清」同源的
            # fast_purge（rename 进同卷暂存区 aipc_purge，毫秒级元数据操作，不进回收站）；
            # 物理删除由后台线程进行，v1.7.82 起再立即就地清扫一遍暂存区，且工具每次
            # 启动时 auto_cleanup_orphan_baks 也会清扫（覆盖 server 退出/重启场景，
            # 不再注册任何计划任务）——彻底去除回收站依赖与杀软拦 SHEmpty 风险。
            # 数据已校验在 D 盘、junction 已确认，零丢失；C 盘空间在暂存区被清空时释放。
            _residual = fast_purge(bak, size_kb=int(_bak_size * 1024 * 1024))
            if _residual:
                # 极少数被占用文件留在原 .bak → 登记重启删兜底，如实告知
                # v1.7.86：_schedule_reboot_delete 现在返回 (ok, reason)，
                # 必须解包 —— 旧写法把元组当布尔用，非空元组恒为 True，
                # 会把「登记失败」也报成「已为你安排重启自动清理」（骗用户）。
                _reboot_ok, _reboot_why = _schedule_reboot_delete(bak)
                cleanup_ok = False
                cleanup_msg = (
                    ("已迁移并建联接。临时备份 %.2f GB 被程序/安全软件占用暂时删不掉，"
                     "已为你安排：下次重启电脑时自动清理（无需手动操作）。重启后 C 盘将再释放这部分空间。"
                     % _bak_size) if _reboot_ok else
                    ("已迁移并建联接，但临时备份 %.2f GB 没能自动清理 —— %s。"
                     "数据都在其它盘上、C 盘原目录已建联接，可以正常使用；"
                     "这个备份目录在 %s，重启后可手动删掉。"
                     % (_bak_size, _reboot_why or "登记没成功", bak)))
            else:
                # .bak 整体已 rename 进 aipc_purge 暂存区（不再占原路径）；物理删除由后台线程完成，
                # v1.7.82 起再立即就地清扫一遍暂存区（工具启动时 auto_cleanup_orphan_baks 会再扫，
                # 覆盖 server 退出/重启场景），不再注册任何计划任务。
                cleanup_ok = True
                try:
                    _run_purge_stage_cleanup()
                except Exception:
                    pass
        # 登记真实残留统计（供 server 校准如实展示；仅当确实没清掉时）
        if not cleanup_ok:
            with _PURGE_RESIDUAL_LOCK:
                _PURGE_RESIDUAL["count"] += 1
                _PURGE_RESIDUAL["bytes"] += int(_bak_size * (1024 ** 3))
    except Exception as _e:
        cleanup_ok = False
        _reboot_ok, _reboot_why = _schedule_reboot_delete(bak)
        if _reboot_ok:
            cleanup_msg = ("已迁移并建联接。临时备份 %.2f GB 被系统占用无法立即删除，"
                           "已为你安排：下次重启电脑时自动清理（无需手动操作）。重启后 C 盘将再释放这部分空间。"
                           % _bak_size)
        else:
            # v1.7.86：把失败原因如实说清，不再笼统说「未能自动清理」让用户猜
            cleanup_msg = ("已迁移并建联接，但临时备份 %.2f GB 没能自动清理 —— %s。"
                           "数据都在其它盘上、软件照常用；这个备份在 %s，重启后可手动删掉。"
                           % (_bak_size, _reboot_why or "登记没成功", bak))
        if not cleanup_ok:
            with _PURGE_RESIDUAL_LOCK:
                _PURGE_RESIDUAL["count"] += 1
                _PURGE_RESIDUAL["bytes"] += int(_bak_size * (1024 ** 3))
    res["ok"] = True
    res["msg"] = ("已搬完（软件正常使用，C 盘空间回收中，稍后自动释放）" if cleanup_ok else cleanup_msg)
    if res.get("dst_prev_aside"):
        # AIPC-DST-FOREIGN-FIX：目标盘上原有的旧副本被挪开了，如实告知去向（绝不偷着删）
        res["msg"] = res["msg"] + ("；目标盘上原有的旧副本已另存为 %s（未删除，可自行确认）"
                                   % res["dst_prev_aside"])
    res["cleanup_warning"] = not cleanup_ok
    res["cleanup_bak"] = bak if not cleanup_ok else ""
    if cleanup_ok:
        return _mark(res, "done", _all_gb, 0.0, "")
    return _mark(res, "partial", 0.0, _all_gb, "reboot")


# --------------------------------------------------------------------------
# 深度迁移发现 + 候选合并
# --------------------------------------------------------------------------
def _dir_size_kb(path):
    """递归累计目录体积（KB）。失败返回 0。"""
    try:
        import path_rules as _pr
        return _pr.sum_file_sizes(path) / 1024.0
    except Exception:
        return 0.0


def _deep_migrate_roots():
    """深度扫描的锚点根：已知「程序数据」所在位置（用户级、零管理员）。

    注意：ProgramData 建 junction 需管理员，当前产品定位非管理员可用，故不扫；
    LocalLow 是很多游戏/UWP 数据藏身地，必须纳入。
    """
    profile = os.path.expanduser("~")
    local = os.environ.get("LOCALAPPDATA", os.path.join(profile, "AppData", "Local"))
    roaming = os.environ.get("APPDATA", os.path.join(profile, "AppData", "Roaming"))
    local_low = os.path.join(profile, "AppData", "LocalLow")
    return [
        (os.path.join(profile, "Documents"), 3),
        (local, 3),
        (roaming, 3),
        (local_low, 3),
    ]


def find_known_apps():
    """显式探测国民软件（微信/QQ/企业微信等）常见数据目录。

    作为 find_migratable_deep 的兜底：某些机器 Documents 很大、深度遍历预算被耗尽前还没走到
    WeChat Files，或者扫描器未把该目录上报，会导致迁移卡只剩「大文件」。本函数直接按已知
    路径探针检查，命中即算体积返回候选，确保微信/QQ 在登录状态下一定出现在迁移卡。
    """
    profile = os.path.expanduser("~")
    local = os.environ.get("LOCALAPPDATA", os.path.join(profile, "AppData", "Local"))
    roaming = os.environ.get("APPDATA", os.path.join(profile, "AppData", "Roaming"))
    local_low = os.path.join(profile, "AppData", "LocalLow")
    docs = os.path.join(profile, "Documents")
    probes = [
        # ---- 腾讯系 ----
        (os.path.join(docs, "WeChat Files"), "微信聊天文件"),
        (os.path.join(docs, "WeChatFiles"), "微信聊天文件"),
        (os.path.join(docs, "xwechat_files"), "微信聊天文件"),   # 微信 4.0 新数据目录（2026-07-31 补：原漏探测）
        (os.path.join(docs, "XWeChat Files"), "微信聊天文件"),   # 同上新版空格变体
        (os.path.join(docs, "Tencent Files"), "腾讯系聊天文件"),
        (os.path.join(docs, "TencentFiles"), "腾讯系聊天文件"),
        (os.path.join(docs, "WXWork"), "企业微信数据"),
        (os.path.join(docs, "WXWorkData"), "企业微信数据"),
        (os.path.join(roaming, "Tencent"), "腾讯系程序数据"),
        (os.path.join(local, "Tencent"), "腾讯系程序数据"),
        (os.path.join(roaming, "Tencent", "WeChat"), "微信聊天文件"),
        (os.path.join(local, "Tencent", "WeChat"), "微信聊天文件"),
        (os.path.join(roaming, "WeChat"), "微信聊天文件"),
        (os.path.join(local, "WeChat"), "微信聊天文件"),
        (os.path.join(roaming, "Tencent", "WXWork"), "企业微信数据"),
        (os.path.join(local, "Tencent", "WXWork"), "企业微信数据"),
        (os.path.join(roaming, "WXWork"), "企业微信数据"),
        (os.path.join(local, "WXWork"), "企业微信数据"),
        (os.path.join(roaming, "Tencent", "QQ"), "QQ 数据"),
        (os.path.join(local, "Tencent", "QQ"), "QQ 数据"),
        (os.path.join(roaming, "Tencent", "QQNT"), "QQ NT 数据"),
        (os.path.join(local, "Tencent", "QQNT"), "QQ NT 数据"),
        (os.path.join(roaming, "QQ"), "QQ 数据"),
        (os.path.join(local, "QQ"), "QQ 数据"),
        (os.path.join(roaming, "QQNT"), "QQ NT 数据"),
        (os.path.join(local, "QQNT"), "QQ NT 数据"),
        (os.path.join(roaming, "qq_guild"), "QQ 频道数据"),
        (os.path.join(local, "qq_guild"), "QQ 频道数据"),
        (os.path.join(docs, "QQ"), "QQ 数据"),
        (os.path.join(docs, "Tencent", "QQ"), "QQ 数据"),
        (os.path.join(docs, "Tencent", "QQNT"), "QQ NT 数据"),
        (os.path.join(roaming, "Tencent", "WeMeet"), "腾讯会议 数据"),
        (os.path.join(local, "Tencent", "WeMeet"), "腾讯会议 数据"),
        (os.path.join(roaming, "WeMeet"), "腾讯会议 数据"),
        (os.path.join(local, "WeMeet"), "腾讯会议 数据"),
        # ---- 会议/协作 ----
        (os.path.join(roaming, "Zoom"), "Zoom 数据"),
        (os.path.join(local, "Zoom"), "Zoom 数据"),
        (os.path.join(local, "Microsoft", "Teams"), "Teams 数据"),
        (os.path.join(roaming, "Microsoft", "Teams"), "Teams 数据"),
        (os.path.join(roaming, "Slack"), "Slack 数据"),
        (os.path.join(local, "Slack"), "Slack 数据"),
        # ---- 游戏 ----
        (os.path.join(roaming, "miHoYo"), "米哈游 游戏数据"),
        (os.path.join(local, "miHoYo"), "米哈游 游戏数据"),
        (os.path.join(roaming, "HoYoverse"), "HoYoverse 游戏数据"),
        (os.path.join(local, "HoYoverse"), "HoYoverse 游戏数据"),
        (os.path.join(docs, "Genshin Impact"), "米哈游 游戏数据"),
        (os.path.join(docs, "Star Rail"), "米哈游 游戏数据"),
        (os.path.join(docs, "ZZZ"), "米哈游 游戏数据"),
        (os.path.join(roaming, "Netease"), "网易游戏 数据"),
        (os.path.join(local, "Netease"), "网易游戏 数据"),
        (os.path.join(roaming, "NetEaseGame"), "网易游戏 数据"),
        (os.path.join(local, "NetEaseGame"), "网易游戏 数据"),
        (os.path.join(local_low, "Netease"), "网易游戏 数据"),
        (os.path.join(local_low, "miHoYo"), "米哈游 游戏数据"),
        # ---- JetBrains IDE ----
        (os.path.join(local, "JetBrains"), "JetBrains 工具缓存"),
        (os.path.join(roaming, "JetBrains"), "JetBrains 工具缓存"),
        # ---- 云盘 ----
        (os.path.join(local, "AliyunDrive"), "阿里云盘 数据"),
        (os.path.join(roaming, "AliyunDrive"), "阿里云盘 数据"),
        (os.path.join(local, "aDrive"), "阿里云盘 数据"),
        (os.path.join(roaming, "aDrive"), "阿里云盘 数据"),
        (os.path.join(local, "Nutstore"), "坚果云 数据"),
        (os.path.join(roaming, "Nutstore"), "坚果云 数据"),
        # ---- 创作/设计 ----
        (os.path.join(roaming, "Bijian"), "必剪 数据"),
        (os.path.join(local, "Bijian"), "必剪 数据"),
        (os.path.join(roaming, "Dujia"), "度加 数据"),
        (os.path.join(local, "Dujia"), "度加 数据"),
        (os.path.join(roaming, "MasterGo"), "MasterGo 数据"),
        (os.path.join(local, "MasterGo"), "MasterGo 数据"),
        (os.path.join(roaming, "Pixso"), "Pixso 数据"),
        (os.path.join(local, "Pixso"), "Pixso 数据"),
        (os.path.join(roaming, "JSDesign"), "即时设计 数据"),
        (os.path.join(local, "JSDesign"), "即时设计 数据"),
        # ---- 输入法 ----
        (os.path.join(roaming, "IFlyTek"), "讯飞输入法 数据"),
        (os.path.join(local, "IFlyTek"), "讯飞输入法 数据"),
        (os.path.join(roaming, "iFlytek"), "讯飞输入法 数据"),
        (os.path.join(local, "iFlytek"), "讯飞输入法 数据"),
        (os.path.join(roaming, "Baidu Pinyin"), "百度输入法 数据"),
        (os.path.join(local, "Baidu Pinyin"), "百度输入法 数据"),
        (os.path.join(roaming, "BaiduPinyin"), "百度输入法 数据"),
        (os.path.join(local, "BaiduPinyin"), "百度输入法 数据"),
        (os.path.join(roaming, "QQPinyin"), "QQ 拼音 数据"),
        (os.path.join(local, "QQPinyin"), "QQ 拼音 数据"),
        # ---- 电商/聊天 ----
        (os.path.join(roaming, "aliwangwangData"), "阿里旺旺数据"),
        (os.path.join(local, "aliwangwangData"), "阿里旺旺数据"),
        # ---- 金融 ----
        (os.path.join(roaming, "Eastmoney"), "东方财富 数据"),
        (os.path.join(local, "Eastmoney"), "东方财富 数据"),
        (os.path.join(roaming, "Dazhihui"), "大智慧 数据"),
        (os.path.join(local, "Dazhihui"), "大智慧 数据"),
        (os.path.join(roaming, "Hexin"), "同花顺 数据"),
        (os.path.join(local, "Hexin"), "同花顺 数据"),
        (os.path.join(roaming, "new_jyplug"), "同花顺 数据"),
        (os.path.join(local, "new_jyplug"), "同花顺 数据"),
        (os.path.join(roaming, "TdX"), "通达信 数据"),
        (os.path.join(local, "TdX"), "通达信 数据"),
        # ---- v1.7.35（增强1·扩大迁移覆盖）：游戏库 / 视频剪辑 / 下载网盘 ----
        # 这些是 C 盘爆满用户的大头（游戏本体数据 / 项目缓存 / 下载文件），
        # 均在用户目录（AppData/Documents/Downloads）下，不碰 Program Files 应用本体。
        # ---- 游戏库用户数据（Steam/Epic/战网等）----
        (os.path.join(docs, "My Games"), "游戏数据"),
        (os.path.join(roaming, "Steam"), "Steam 数据"),
        (os.path.join(local, "Steam"), "Steam 数据"),
        (os.path.join(roaming, "Epic Games"), "Epic 游戏数据"),
        (os.path.join(local, "Epic Games"), "Epic 游戏数据"),
        (os.path.join(roaming, "EpicGamesLauncher"), "Epic 游戏数据"),
        (os.path.join(local, "EpicGamesLauncher"), "Epic 游戏数据"),
        (os.path.join(local, "Battle.net"), "战网 游戏数据"),
        (os.path.join(local, "Blizzard Entertainment"), "暴雪 游戏数据"),
        (os.path.join(local, "Ubisoft Game Launcher"), "育碧 游戏数据"),
        (os.path.join(local, "Riot Games"), "拳头 游戏数据"),
        (os.path.join(local, "GOG Galaxy"), "GOG 游戏数据"),
        # ---- 视频剪辑 / 创作（项目缓存常达数十 GB）----
        (os.path.join(local, "JianyingPro"), "剪映 数据"),
        (os.path.join(roaming, "JianyingPro"), "剪映 数据"),
        (os.path.join(local, "CapCut"), "剪映国际版 数据"),
        (os.path.join(roaming, "CapCut"), "剪映国际版 数据"),
        (os.path.join(roaming, "Adobe", "Premiere Pro"), "PR 项目数据"),
        (os.path.join(roaming, "Adobe", "After Effects"), "AE 项目数据"),
        (os.path.join(local, "Adobe", "Premiere Pro"), "PR 项目数据"),
        (os.path.join(roaming, "Adobe", "Photoshop"), "PS 项目数据"),
        (os.path.join(local, "Adobe", "Media Cache"), "Adobe 媒体缓存"),
        (os.path.join(docs, "Adobe", "Premiere Pro"), "PR 项目数据"),
        (os.path.join(docs, "剪映"), "剪映 数据"),
        # ---- 下载 / 网盘（下载文件、离线缓存）----
        (os.path.join(local, "Thunder Network"), "迅雷 数据"),
        (os.path.join(roaming, "Thunder Network"), "迅雷 数据"),
        (os.path.join(local, "BaiduNetdisk"), "百度网盘 数据"),
        (os.path.join(roaming, "BaiduNetdisk"), "百度网盘 数据"),
        (os.path.join(local, "Quark Drive"), "夸克网盘 数据"),
        (os.path.join(roaming, "Quark Drive"), "夸克网盘 数据"),
        (os.path.join(local, "139yun"), "天翼云盘 数据"),
        (os.path.join(local, "Xunlei"), "迅雷 数据"),
        (os.path.join(roaming, "Xunlei"), "迅雷 数据"),
        (os.path.join(local, "115"), "115网盘 数据"),
        (os.path.join(roaming, "115"), "115网盘 数据"),
        (os.path.join(local, "123pan"), "123云盘 数据"),
    ]
    found = []
    for path, label in probes:
        if not os.path.isdir(path):
            continue
        if _under_junction(path):
            continue
        # v1.7.36（审查修复·安全红线）：探针里有几个落在 Documents 下的个人文件夹
        # （My Games 游戏存档、Adobe\Premiere Pro / 剪映 创作项目、原神/星穹铁道/绝区零
        # 游戏存档），它们是【个人文件】绝非「程序数据/缓存」。此前这里只靠 do_migrate
        # 的 _is_personal_root 在真正搬移时才兜底拦截，导致这些个人文件夹先出现在迁移
        # 候选卡（误导用户）→ 用户点了却报「出于安全不迁移」，体验不一致。现与
        # find_migratable / find_migratable_deep 保持一致，在候选生成阶段就剔除个人根。
        if _is_personal_root(path):
            continue
        # 用 path_rules 的 sum_file_sizes 做统一体积统计（跳过 junction、硬链接去重）
        try:
            import path_rules as _pr
            kb = _pr.sum_file_sizes(path) / 1024.0
        except Exception:
            kb = _dir_size_kb(path)
        if kb < MIN_MIGRATE_KB:
            continue
        # 再次用模式匹配确认标签（避免路径拼写差异导致误标）
        matched = _match_label(path)
        if matched:
            label = matched
        # v1.7.85：开发工程闸门同样要覆盖【深扫】这条通路。
        # 只堵浅扫那一条 = 用户项目里埋在更深层的 node_modules 照样会被挖成候选。
        if _is_dev_project(path):
            continue
        found.append({
            "name": os.path.basename(path.rstrip("\\/")),
            "path": path,
            "size_kb": kb,
            "size_h": _kb_h(kb),
            "label": label,
        })
    return found


def find_migratable_deep(max_depth=3, max_dirs=400000):
    """深度发现：在已知程序数据根下做更深遍历，挖出浅扫描(limit=40/depth=1)漏掉的大可迁移文件夹。

    与 find_migratable 的区别：find_migratable 只看扫描器已发现的目录（depth=1 + 每根≤40）；
    本函数主动下钻，并用 path_rules.APP_ROOT_MARKS + 迁移模式匹配筛选候选，因此能找到被浅扫描
    截断或埋得更深的目录（如 Documents\\WeChat Files、Tencent\\QQNT\\…\\FileStorage）。

    性能修复（根因：旧实现对每个命中目录调用 sum_file_sizes 再做一次完整 os.walk，
    形成 O(n^2) 磁盘遍历，实测单次可达数分钟，用户侧表现为「长时间无输出、以为卡死」）。
    新实现：单次 os.walk 同时完成「遍历 + 自底向上累计体积」，每个文件仅 stat 一次，
    体积语义与 sum_file_sizes 完全一致（跳过 junction 子树、硬链接去重），并受
    时间预算(50s) + 条目上限双护栏约束，绝不会无限/过久运行。
    """
    try:
        import path_rules as _pr
        APP_MARKS = _pr.APP_ROOT_MARKS
    except Exception:
        APP_MARKS = ()
    import time as _t
    _start = _t.time()
    # v1.7.83（覆盖度修复·实测根因）：原 _BUDGET=25s 是【4 个根共享】的单一预算，
    # 而 4 根在线程池里并行 + 抢 GIL + 每个文件都要 stat，实际每根只能分到 ~1/4 预算。
    # 实测本机：Roaming 单根裸 walk 就要 40s 才走完 30950 个目录，Tencent 排在第
    # 23239 个；带 stat 的深遍历更慢 → 25s 内连 Tencent 的门都没摸到，
    # find_migratable_deep 实测返回 **0 条候选**（此前一直以为是"没东西可搬"）。
    # 改为：**每根独立计时**（不再互相抢预算）+ 预算放宽到 45s。
    # 4 根并行 → 墙钟耗时仍 ≈ 最慢那一根（≈45s），与旧版 25s 墙钟同量级，
    # 但每根都能真正走完自己那棵树，深扫从"永远返回 0"变成"真能挖到东西"。
    _BUDGET_PER_ROOT = 45.0   # 秒：**每个锚点根各自**的遍历预算
    _WALK_CAP = 14           # 下钻深度硬上限（防异常深树）；候选仍按 max_depth(默认3) 筛选

    def _scan_one(root):
        """扫描单个锚点根，返回该根命中的候选列表（顺序 = os.walk 访问序）。

        v1.7.62：4 个锚点根（Documents/Local/Roaming/LocalLow）物理隔离、无父子关系，
        由外层 ThreadPoolExecutor 并行调用本函数。环检测/硬链接去重改为 per-root 局部
        （4 根物理隔离，跨根命中本就不可能，故结果与单线程共享集合时等价）。
        v1.7.83：预算改为 per-root（_root_start），修 4 根共享 25s 导致深扫恒返回 0。
        """
        if not os.path.isdir(root):
            return []
        _root_start = _t.time()   # 本根自己的计时起点，不与兄弟根共享
        _root_prefix = os.path.normcase(os.path.abspath(root))
        _leaf = {}            # dirpath -> 该目录「直接文件」字节数（不含子目录）
        _children = {}        # dirpath -> 子目录路径列表
        _order = []           # 访问顺序（父先于子），供后续逆序自底向上累计
        _seen_real = set()    # realpath 环检测：命中则不再下钻，避免 junction 互指造成的死循环
        _seen_ino = set()     # 硬链接去重：(st_dev, st_ino)
        try:
            for dp, dns, fns in os.walk(root, followlinks=False):
                if (_t.time() - _root_start) > _BUDGET_PER_ROOT:
                    break
                try:
                    rdp = os.path.realpath(dp)
                except OSError:
                    rdp = dp
                if rdp in _seen_real:
                    dns[:] = []
                    continue
                _seen_real.add(rdp)
                # junction 子目录：其目标不在 C:，跳过下钻且不计体积（与 sum_file_sizes 语义一致）
                # .migrated.bak 残留：上一次迁移的源改名残留，analyze 阶段本就会整棵排除，
                # 此处直接不下钻，既省遍历时间又避免把残留体积算进父目录（残留非当前可回收数据）
                _kept = []
                for d in dns:
                    sub = os.path.join(dp, d)
                    dl = d.lower()
                    if _is_junction(sub) or dl.endswith(".migrated.bak"):
                        continue
                    # v1.7.85：命中开发工程（node_modules / .git / src / venv …）整棵子树
                    # 不下钻。只在「候选收集点」过滤是不够的 —— 深扫会逐层走到
                    # dsh/src、dsh/tests、node_modules/.pnpm/... 再逐个判，白走几十万次
                    # stat（实测本机 dsh 一个目录就 13946 个子目录）。
                    if d.lower() in _DEV_PROJECT_SEGMENTS:
                        continue
                    _kept.append(d)
                if dp[len(_root_prefix):].count(os.sep) >= _WALK_CAP:
                    _kept = []   # 超过硬上限不再下钻（仍记录本层体积）
                dns[:] = _kept
                # 累计本目录「直接文件」体积（硬链接去重，避免把硬链接多份名字重复计入）
                # 改用 os.scandir 单次 syscall：Windows 下 FindFirstFile 已带大小/inode，
                # entry.stat() 不触发额外 syscall，比逐文件 os.stat 快约一个数量级（体积零偏差）。
                s = 0
                try:
                    for entry in os.scandir(dp):
                        try:
                            if not entry.is_file(follow_symlinks=False):
                                continue
                            st = entry.stat(follow_symlinks=False)
                            key = (st.st_dev, st.st_ino)
                            if key in _seen_ino:
                                continue
                            _seen_ino.add(key)
                            s += st.st_size
                        except OSError:
                            pass
                except OSError:
                    pass
                _leaf[dp] = s
                _children[dp] = [os.path.join(dp, d) for d in dns]
                _order.append(dp)
                if len(_seen_real) > max_dirs:
                    break
        except OSError:
            pass
        # 自底向上累计递归体积：children 先于 parent 被访问（os.walk topdown），逆序即后序
        _rec = {}
        for dp in reversed(_order):
            tot = _leaf.get(dp, 0)
            for ch in _children.get(dp, ()):
                tot += _rec.get(ch, 0)
            _rec[dp] = tot
        # 从累计结果里挑候选：非个人根、非管理员、非 temp、标签命中（或体积兜底通过）、
        # 且深度/体积达标。
        # 注意：**不在此处按 label 去重**——Roaming 下的 Tencent 与 Roaming\QQ 同为
        # 「腾讯系程序数据」但路径无前缀关系，merge_candidates 需要靠 label 分组把
        # 两者体积相加；单根内先去重会把后者丢掉、少算体积（v1.7.83 修）。
        local_found = []
        for dp in _order:
            if dp[len(_root_prefix):].count(os.sep) > max_depth:
                continue
            pl = dp.lower().replace("/", "\\")
            if "\\temp\\" in pl or pl.rstrip("\\").endswith("\\temp"):
                continue
            if _is_personal_root(dp) or _needs_admin(dp):
                continue
            kb = _rec.get(dp, 0) / 1024.0
            if kb < MIN_MIGRATE_KB:
                continue
            label = _match_label(dp)
            if not label:
                # v1.7.83：白名单认不出的走与浅扫同一套「体积优先兜底」，
                # 否则深扫修好预算也只认腾讯一家（实测 baidu/Doubao/ima/OpenAI… 全是 None）。
                # 兜底自带容器/缓存/本体排除，且 _is_container_dir_itself 会挡住
                # 「把 AppData 整棵搬走」这种致命候选。
                label = _migrate_volume_fallback(dp, kb)
                if not label:
                    continue
            local_found.append({
                "name": os.path.basename(dp.rstrip("\\/")),
                "path": dp,
                "size_kb": kb,
                "size_h": _kb_h(kb),
                "label": label,
            })
        return local_found

    found = []
    _roots = [os.path.expanduser(r) for r, _cap in _deep_migrate_roots()]
    with ThreadPoolExecutor(max_workers=4) as _ex:
        for _local in _ex.map(_scan_one, _roots):   # map 保持根顺序，结果顺序与单线程一致
            for _c in _local:
                _key = _c["path"].lower().rstrip("\\")
                if _key not in {x["path"].lower().rstrip("\\") for x in found}:
                    found.append(_c)
    return found


def merge_candidates(*cand_lists):
    """合并多来源候选，按父目录优先去重，并按软件标签合并展示。

    返回最终迁移候选列表（与 find_migratable 返回值同构）。
    """
    cands = []
    for lst in cand_lists:
        for c in (lst or []):
            # 排除上一次迁移残留的 .migrated.bak（源改名残留，被 explorer 锁住未删）：
            # 它不是用户新数据，重新当迁移候选会重复计入体积并误导「本次释放」。（Fix 3）
            # 加强：残留是名为「*.migrated.bak」的目录，其下子目录叶子不以此结尾，
            # 故用「任一路径段以 .migrated.bak 结尾」整棵排除（与 analyze 候选阶段双保险）。
            if any(seg.lower().endswith(".migrated.bak") for seg in c["path"].replace("/", "\\").rstrip("\\").split("\\")):
                continue
            cands.append(c)
    # 同物理路径去重（关键修复）：find_migratable（浅扫）与 find_migratable_deep（深扫）
    # 可能对同一目录各返回一条，原逻辑只做父子去重、未做同路径去重，导致该目录被「按标签合并」
    # 后体积翻倍（例：Roaming 下的 Tencent 浅扫 10.0GB + 深扫 9.6GB → 合并成 19.6GB）。
    # 同一路径只保留一次，体积取较大者（深扫通常更全）。
    _by_path = {}
    for c in cands:
        np_ = c["path"].lower().rstrip("\\")
        if np_ in _by_path:
            if c["size_kb"] > _by_path[np_]["size_kb"]:
                _by_path[np_] = c
        else:
            _by_path[np_] = c
    cands = list(_by_path.values())
    # 去重：若某候选是另一个候选的父/前缀，只保留父目录（更短、更稳）
    # 注意：必须先按路径长度升序，让父目录先进 norms，子目录才能被识别并跳过。
    cands.sort(key=lambda c: len(c["path"]))
    kept = []
    norms = []
    for c in cands:
        np_ = c["path"].lower().rstrip("\\")
        if any(np_.startswith(n + "\\") for n in norms):
            continue
        kept.append(c)
        norms.append(np_)

    # 合并：同一软件标签可能出现在 Roaming/Local 等多个位置，合并展示。
    groups = {}
    for c in kept:
        key = c["label"]
        groups.setdefault(key, []).append(c)

    merged = []
    for label, items in groups.items():
        items.sort(key=lambda x: x["size_kb"], reverse=True)
        primary = items[0]
        total_kb = sum(c["size_kb"] for c in items)
        merged.append({
            "name": primary["name"],
            "path": primary["path"],
            "paths": [{"path": c["path"], "size_kb": c["size_kb"],
                       "size_h": c.get("size_h", _kb_h(c["size_kb"]))} for c in items],
            "size_kb": total_kb,
            "size_h": _kb_h(total_kb),
            "label": label,
            "display_name": (primary["name"] if str(label).startswith("generic:")
                             else MIGRATE_DISPLAY_NAMES.get(label, label)),
            "group_key": label,
        })
    # 按大小降序，大项在前
    merged.sort(key=lambda x: x["size_kb"], reverse=True)
    return merged



# ---- v1.7.94：判别本机是否真的装了【第三方】文件系统过滤驱动（杀软内核态驱动）----
_AV_FILTER_DRIVER_CACHE = None

# Windows 自带的文件系统驱动：出现在过滤驱动组里的都属于系统自己，不是杀软。
# 实测踩坑：第一版判据没排除它们，导致 av_kernel 恒为真、判据形同虚设。
_WIN_BUILTIN_FS_GROUPS = ("boot file system", "file system", "file system filter",
                          "file system helper", "fsfilter")
_WIN_BUILTIN_FS_NAMES = frozenset((
    "cdfs", "exfat", "fastfat", "fat", "msfs", "npfs", "ntfs", "refs", "refs v1",
    "refsfilter", "udfs", "cimfs", "wcifs", "bindflt", "dfsc", "filters",
))


def _av_filter_drivers_present():
    """实测是否存在**第三方**杀软的文件系统过滤驱动。返回 bool。

    只认硬证据：注册表 Services 下 Type=2（驱动）且 Group 是文件系统过滤组，
    并且【排除 Windows 自带】的那一批（cdfs/exfat/ntfs/Npfs/... 每台机器都有，
    实测第一版没排除，导致本机明明没装杀软却返回 True → av_kernel 恒真 →
    所有锁住的目录都被判成「必须重启」，这正是「提示要重启」甩锅的根因之二）。

    查不到（无权限 / 系统不支持）时返回 False：宁可按 process 处置。
    因为 process 有明确出路（关掉进程就能搬），av_kernel 只有「重启」一条路。
    """
    global _AV_FILTER_DRIVER_CACHE
    if _AV_FILTER_DRIVER_CACHE is not None:
        return _AV_FILTER_DRIVER_CACHE
    found = False
    try:
        import winreg
        _SERVICE_DRIVER = 2
        _h = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM" + chr(92) + "CurrentControlSet" + chr(92) + "Services",
            0, winreg.KEY_READ)
        _i = 0
        while True:
            try:
                _sub = winreg.EnumKey(_h, _i)
            except OSError:
                break
            _i += 1
            # Windows 自带的那一套直接跳过（名字命中即 continue）
            if str(_sub).lower() in _WIN_BUILTIN_FS_NAMES:
                continue
            try:
                _sk = winreg.OpenKey(_h, _sub, 0, winreg.KEY_READ)
                try:
                    _t = winreg.QueryValueEx(_sk, "Type")[0]
                    try:
                        _g = str(winreg.QueryValueEx(_sk, "Group")[0]).lower()
                    except OSError:
                        _g = ""
                    if _t != _SERVICE_DRIVER or not _g:
                        continue
                    # 自带驱动组一律不算（Boot File System / File System 两大类）
                    if _g in _WIN_BUILTIN_FS_GROUPS:
                        continue
                    # 剩下的过滤组才可能是第三方（如 fsfilter 扩展、WdFilter 等）
                    found = True
                    break
                finally:
                    _sk.Close()
            except OSError:
                continue
        _h.Close()
    except Exception:
        found = False
    _AV_FILTER_DRIVER_CACHE = found
    return found

def classify_lock(path):
    """探测目录是否被锁，返回 'free' | 'process' | 'av_kernel'。

    对目录做一次安全改名试探（同卷元数据操作，瞬时、不复制数据）：
        改名成功 -> 立即改名回（带重试兜底）-> 'free'
        改名失败 -> 'process'（绝大多数情况，有程序正用着，可强杀）

    ★ v1.7.94 实测纠偏 —— 这是「提示要重启才能完成迁移」甩锅的根因之二：
      本机确实装了 360 / 阿里（注册表里 360Box64 / 360FsFlt / AliPaladin /
      PDDHIPS 四个 FSFilter 驱动），旧判据「有杀软过滤驱动 + 改名失败」
      就一律 av_kernel -> 前端弹「要重启才能完成迁移」。
      ★ 但实测打脸：强杀 48 个微信/企业微信/搜狗进程后，
        WeMail / xwechat / WXWork 立刻解锁。锁是那些程序自己占着的，不是杀软。
        而且重启后微信/输入法立刻自启 -> 目录照样锁死 -> 用户陷入死循环。

      现在的判据（只认实测，不靠「装了啥」推断）：
        改名失败时，若本机确有第三方 FSFilter 驱动，再用 Restart Manager
        逐文件查一遍真实占用：
          · 查到任何占用进程 -> 'process'（指名道姓，关掉它就能搬）
          · 一个进程都查不到还锁着 -> 'av_kernel'（确实驱动层拦截）

        且 av_kernel 判定后，调用方仍会用 _split_locked_dir_children
        降级为逐子目录搬 —— 宁可搬走 94.7%，也不整项拒绝。
    """
    _probe = path + ".aipc_probe_rename"
    try:
        os.rename(path, _probe)
    except OSError:
        # 改名失败 -> 默认按 process（有程序在用），不强判 av_kernel
        if not _av_filter_drivers_present():
            return "process"
        # 有过滤驱动：必须再确认「查不到任何占用进程」才判驱动层拦截
        try:
            _lk = who_locks_dir(path, max_files=12)
        except Exception:
            _lk = []
        if _lk:
            return "process"
        return "av_kernel"
    except Exception:
        return "process"
    # 改名成功 -> 立即改回（带重试，绝不留文件夹在改名态）
    for _ in range(10):
        try:
            os.rename(_probe, path)
            return "free"
        except Exception:
            _time.sleep(0.05)
    # 兜底：改名回失败（极罕见）。不能当 free 放行，记为 process 由真实迁移兜底。
    return "process"


if __name__ == "__main__":
    print("migrate 模块自检：")
    print("  SAFE_MIGRATE_PATTERNS =", len(SAFE_MIGRATE_PATTERNS), "条")
    print("  MIN_MIGRATE_KB =", MIN_MIGRATE_KB, "KB")
    print("  find_migratable_deep / merge_candidates =", "已就绪" if find_migratable_deep and merge_candidates else "缺失")
