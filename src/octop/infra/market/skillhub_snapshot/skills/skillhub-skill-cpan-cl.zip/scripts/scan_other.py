# -*- coding: utf-8 -*-
"""其他盘深度扫描（只读）。

用途：很多用户不止 C 盘爆满，D / E 等盘也可能爆满。本模块对「用户从报告页选定的
其他盘」做深度扫描，只列出占用大头的位置（文件夹 / 大文件）与体积、路径，
**不删、不搬、不修改任何文件**——删不删、能不能删由用户自己去看、去判断。

设计要点：
- 整盘顶层目录并行递归计算体积（ThreadPoolExecutor），进度按「完成的顶层目录」回调。
- 同时收集体积 >= 阈值的大文件（全局堆，取前 N 大），单独成榜。
- 跳过 NTFS junction / 重解析点，避免与真实目录重复计数（同 scan.py 的纪律）。
- 类型分类：文件夹含知名程序名 → 「程序」；文件按扩展名 → 视频/压缩包·镜像/安装包/备份·镜像/文档/文件。
- 仅盘符根目录扫描（D:\\），不接收任意子路径，防滥用。
"""
import os
import threading
import heapq
import concurrent.futures

# ---------- 系统盘判断 / 盘类型 ----------
try:
    import ctypes
    _K32 = ctypes.windll.kernel32
    try:
        # 【关键修复·符号溢出】GetCompressedFileSizeW 默认 ctypes 返回类型为带符号 c_int，
        # 当文件低 32 位最高位为 1（大小落在 [2GB,4GB)、[6GB,8GB)… 区间）时会被当成负数，
        # 导致：① 大文件体积算成负数被剔除出大文件榜（漏显）② 负数加进目录总体积使总容量偏少。
        # 显式声明为【无符号 32 位】返回，配合 hi<<32 拼出完整 64 位正数。
        _K32.GetCompressedFileSizeW.restype = ctypes.c_uint32
        _K32.GetCompressedFileSizeW.argtypes = [
            ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_uint32)
        ]
    except Exception:
        pass

    def _drive_type(root):
        try:
            return _K32.GetDriveTypeW(root)
        except Exception:
            return 0
except Exception:  # 非 Windows 兜底
    def _drive_type(root):
        return 3

# DRIVE_FIXED=3, DRIVE_RAMDISK=4（仅这两种视为「本地盘」参与扫描；跳过可移动/光驱/未知）
_FIXED_TYPES = (3, 4)
_FILE_ATTRIBUTE_REPARSE_POINT = 0x400


def _is_reparse_point(path):
    try:
        attrs = _K32.GetFileAttributesW(path)
        if attrs == 0xFFFFFFFF:
            return False
        return bool(attrs & _FILE_ATTRIBUTE_REPARSE_POINT)
    except Exception:
        return False


def get_allocated_size(path):
    """真实占盘字节数（NTFS 压缩 / 稀疏 / 去重 aware）。

    用 GetCompressedFileSizeW 取文件实际占用的簇大小，而非 st_size 的逻辑大小。
    例如 200GB 的稀疏 VHDX 可能只占用几 GB——st_size 会虚报 200GB，本函数返回真实几 GB。
    失败（权限/长路径/非 Windows）回退到 st_size，再失败返回 0。
    """
    try:
        k32 = globals().get("_K32")
        if k32 is None:
            return int(os.stat(path).st_size)
        p = path
        if len(p) > 250 and not p.startswith("\\\\?\\"):
            p = "\\\\?\\" + os.path.abspath(p)
        hi = ctypes.c_uint32(0)
        lo = k32.GetCompressedFileSizeW(ctypes.c_wchar_p(p), ctypes.byref(hi))
        if lo == 0xFFFFFFFF:  # 0xFFFFFFFF 必为失败（无文件能有此精确占用值）→ 回退 st_size
            return int(os.stat(path).st_size)
        return (hi.value << 32) | int(lo)
    except Exception:
        try:
            return int(os.stat(path).st_size)
        except Exception:
            return 0


def human(kb):
    """kb(整数) -> 人类可读字符串。"""
    kb = float(kb or 0)
    if kb >= 1073741824:  # 1 TiB
        return "%.2f TB" % (kb / 1073741824)
    if kb >= 1048576:
        return "%.2f GB" % (kb / 1048576)
    if kb >= 1024:
        return "%.1f MB" % (kb / 1024)
    return "%.0f KB" % kb


# ---------- 类型分类 ----------
_PROG_HINTS = (
    "program files", "program files (x86)", "steam", "steamapps", "epic", "epicgames",
    "wegame", "games", "game", "origin", "ubisoft", "adobe", "tencent", "netease",
    "xl", "battlenet", "unity", "unityhub", "android", "sdk", "java", "node",
    "python", "mysql", "postgresql", "mongodb", "docker", "wsl", "chrome", "firefox",
    "edge", "appdata", "microsoft", "visual studio", "jetbrains", "blender", "autodesk",
    "cad", "idm", "thunder", "xunlei", "potplayer", "vlc", "obs", "go", "rust",
    "maven", "gradle", "conda", "anaconda", "miniconda", "npm", "nuget", ".minecraft",
)
_VIDEO = {".mp4", ".mkv", ".avi", ".mov", ".flv", ".wmv", ".rmvb", ".ts", ".webm", ".m4v"}
_ARCHIVE = {".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".iso", ".img", ".bz2", ".xz"}
_INSTALL = {".exe", ".msi", ".dmg", ".deb", ".apk", ".msix", ".appx"}
_BACKUP = {".gho", ".vhd", ".vhdx", ".wim", ".tib", ".bak", ".img", ".qcow2", ".vmdk"}
_DOC = {".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".psd", ".ai", ".dwg", ".cdr"}


def _classify_kind(name, is_dir):
    nl = (name or "").lower()
    if is_dir:
        if any(h in nl for h in _PROG_HINTS):
            return "程序"
        return "文件夹"
    ext = os.path.splitext(nl)[1]
    if ext in _VIDEO:
        return "视频"
    if ext in _ARCHIVE:
        return "压缩包·镜像"
    if ext in _INSTALL:
        return "安装包"
    if ext in _BACKUP:
        return "备份·镜像"
    if ext in _DOC:
        return "文档"
    return "文件"


# ---------- 盘列举 ----------
def list_other_drives():
    """返回非 C 盘的本地固定盘列表（含总量/已用/可用）。无则空列表。"""
    import string
    import shutil
    sysdrive = (os.environ.get("SystemDrive", "C:") + "\\").upper().rstrip("\\") + "\\"
    out = []
    for letter in string.ascii_uppercase:
        root = "%s:\\" % letter
        if not os.path.exists(root):
            continue
        if root.upper() == sysdrive:
            continue
        try:
            if _drive_type(root) not in _FIXED_TYPES:
                continue
        except Exception:
            continue
        try:
            t, u, f = shutil.disk_usage(root)
            out.append({
                "name": root,
                "total": human(t // 1024),
                "used": human(u // 1024),
                "free": human(f // 1024),
                "free_gb": round(f / 1073741824.0, 2),
            })
        except Exception:
            continue
    return out


# ---------- 单目录体积 + 大文件收集（迭代，避免递归深度）----------
def _du_collect(path, min_file_kb, large_heap, large_lock, errors):
    total = 0
    max_mtime = 0
    try:
        max_mtime = os.stat(path).st_mtime  # 目录自身最后变更
    except Exception:
        pass
    stack = [path]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                entries = list(it)
        except (OSError, PermissionError):
            errors.append(cur)
            continue
        for e in entries:
            try:
                st = e.stat(follow_symlinks=False)
            except (OSError, PermissionError):
                continue
            if getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT:
                continue  # junction / 重定向点不占空间，跳过（防重复计数）
            if e.is_file(follow_symlinks=False):
                fsz = get_allocated_size(e.path)  # 真实占盘（压缩/稀疏 aware）
                total += fsz
                if st.st_mtime > max_mtime:
                    max_mtime = st.st_mtime
                if fsz // 1024 >= min_file_kb:
                    with large_lock:
                        heapq.heappush(large_heap, (fsz, e.path, st.st_mtime))
                        if len(large_heap) > 400:
                            heapq.heappop(large_heap)
            elif e.is_dir(follow_symlinks=False):
                stack.append(e.path)
    return total // 1024, int(max_mtime)


# ---------- 系统目录跳过（用户不该看到也不该动这些） ----------
_SKIP_DIRS_LOWER = frozenset({
    "$recycle.bin", "system volume information", "$windows.~bt",
    "$windows.~ls", "system recovery", "recovery",
})


def _should_skip_topdir(name):
    nl = (name or "").lower().strip()
    return nl in _SKIP_DIRS_LOWER


# ---------- 整盘扫描 ----------
def scan_drive(drive, on_item=None, on_done=None,
               min_file_kb=1048576, top_folders=40, top_files=60, max_workers=None):
    """扫描整盘（drive 形如 'D:\\' 或 'D:'）。

    - on_item(item, current, total)：每完成一个顶层目录/根文件回调（用于实时进度）。
    - on_done(result)：扫描结束回调。
    - 结果：{ok, drive, folders:[...top N 文件夹], large_files:[...top N 大文件],
             total_gb, disk_used_gb, scanned_dirs, error_count, errors}
      其中 total_gb = 已扫描顶层目录/根文件「真实占盘大小」之和（GetCompressedFileSize，
      压缩/稀疏/去重 aware），必小于等于 disk_used_gb（整盘物理占用），不存在倒挂。
      disk_used_gb = shutil.disk_usage 报告的实际物理占用（整盘真实已用）。
    只读操作，不修改磁盘任何内容。
    """
    import shutil
    drive = os.path.normpath(drive)
    root = drive if drive.endswith("\\") else drive + "\\"

    try:
        t, u, f = shutil.disk_usage(root)
        disk_used_gb = round(u / 1073741824.0, 2)
    except Exception:
        disk_used_gb = 0.0

    try:
        with os.scandir(root) as it:
            top = list(it)
    except (OSError, PermissionError) as e:
        res = {"ok": False, "drive": root, "error": "无法访问该盘：" + str(e),
               "folders": [], "large_files": [], "total_gb": 0,
               "disk_used_gb": disk_used_gb, "scanned_dirs": 0,
               "error_count": 0, "errors": []}
        if on_done:
            on_done(res)
        return res

    dirs = []
    root_files = []
    skipped_system = []
    for e in top:
        try:
            st = e.stat(follow_symlinks=False)
        except (OSError, PermissionError):
            continue
        if getattr(st, "st_file_attributes", 0) & _FILE_ATTRIBUTE_REPARSE_POINT:
            continue
        if e.is_dir(follow_symlinks=False):
            if _should_skip_topdir(e.name):
                skipped_system.append(e.name)
                continue
            dirs.append(e.path)
        elif e.is_file(follow_symlinks=False):
            root_files.append((e.path, get_allocated_size(e.path)))

    total_top = len(dirs) + (1 if root_files else 0)
    large_heap = []
    large_lock = threading.Lock()
    errors = []
    results = []
    done_count = [0]

    def _mk_item(p, size_bytes, is_dir, mtime=0):
        name = os.path.basename(p.rstrip("\\/")) or p
        kb = size_bytes // 1024
        return {"path": p, "name": name, "size_kb": kb, "size_h": human(kb),
                "type": "folder" if is_dir else "file",
                "kind": _classify_kind(name, is_dir),
                "last_used_ts": int(mtime) if mtime else 0}

    def _emit(item):
        results.append(item)
        done_count[0] += 1
        if on_item:
            try:
                on_item(item, done_count[0], total_top)
            except Exception:
                pass

    # 根层文件立即成项（无需递归）；体积达阈值的一并入大文件榜，避免「盘根大文件漏显」
    for p, sz in root_files:
        try:
            _mt = os.stat(p).st_mtime
        except Exception:
            _mt = 0
        _emit(_mk_item(p, sz, False, _mt))
        if sz // 1024 >= min_file_kb:
            with large_lock:
                heapq.heappush(large_heap, (sz, p, _mt))
                if len(large_heap) > 400:
                    heapq.heappop(large_heap)

    def worker(d):
        kb, mt = _du_collect(d, min_file_kb, large_heap, large_lock, errors)
        _emit(_mk_item(d, kb * 1024, True, mt))
        return kb

    if dirs:
        mw = max(4, min(max_workers or 16, (os.cpu_count() or 4) * 2))
        # v1.7.97 P0：绝不用 with ThreadPoolExecutor（shutdown(wait=True) 会 join 每个
        # worker，个别目录 I/O 阻塞就永远卡住整盘扫描 → 报告页出不来）。
        # 显式创建 + as_completed 带超时 + shutdown 不等待；超时的目录如实记入 errors。
        _SCAN_DEADLINE = max(60, int(os.environ.get("AIPC_SCAN_OTHER_DEADLINE", "180")))
        ex = concurrent.futures.ThreadPoolExecutor(max_workers=mw)
        _futs = [ex.submit(worker, d) for d in dirs]
        try:
            for _fu in concurrent.futures.as_completed(_futs, timeout=_SCAN_DEADLINE):
                _fu.result()
        except concurrent.futures.TimeoutError:
            _unfinished = [d for f, d in zip(_futs, dirs) if not f.done()]
            for d in _unfinished:
                errors.append(d)
        finally:
            ex.shutdown(wait=False, cancel_futures=True)

    results.sort(key=lambda r: r["size_kb"], reverse=True)
    folders = [r for r in results if r["type"] == "folder"][:top_folders]
    big = sorted(large_heap, reverse=True)[:top_files]
    large_files = [_mk_item(p, s, False, mt) for s, p, mt in big]

    total_used_kb = sum(r["size_kb"] for r in results)
    res = {
        "ok": True, "drive": root,
        "folders": folders, "large_files": large_files,
        "total_gb": round(total_used_kb / 1048576.0, 2),
        "disk_used_gb": disk_used_gb,
        "scanned_dirs": len(dirs), "root_files": len(root_files),
        "error_count": len(errors), "errors": errors[:20],
    }
    if on_done:
        try:
            on_done(res)
        except Exception:
            pass
    return res


if __name__ == "__main__":
    # 简单的本地自测（非 Windows 也能跑，只是盘检测为空）
    import json
    print("other drives:", json.dumps(list_other_drives(), ensure_ascii=False))
    if len(__import__("sys").argv) > 1:
        d = __import__("sys").argv[1]
        print("scanning", d)
        print(json.dumps(scan_drive(d, min_file_kb=1), ensure_ascii=False, indent=2))
