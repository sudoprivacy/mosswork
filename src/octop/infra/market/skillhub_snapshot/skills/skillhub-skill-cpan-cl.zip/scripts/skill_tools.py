#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""skill_tools.py — WB 对话框内执行的函数层（v1.7.21）。

把原来 server.py 里走 HTTP 的 action 逻辑抽成可直接调用的函数，供 WorkBuddy Agent
在对话框内执行（不再依赖浏览器报告页 / POST /action）。复用同一套引擎：
  - 清理：migrate.fast_purge（rename→批量删→残留重启删）
  - 迁移：migrate.do_migrate（复制-校验-切换 junction）
  - 授权：license.mode_allowed

用法（SKILL.md 工作流中 Agent 调用）：
  from skill_tools import clean_green, migrate_items, get_report_summary, get_migration_options, plan_selected_migration
"""
import os
import sys
import json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import license as license_mod
import migrate as migrate_mod

def get_license():
    """返回当前本机授权状态（无支付版：全功能开放，恒为已授权·高级版）。"""
    return {"tier": 2, "active": True, "version": "nopay", "exp": 0, "hwid": ""}

# 清理 / 迁移（WB 内执行，复用引擎）
# ---------------------------------------------------------------------------
def _tier_gate(min_tier, action_name):
    """无支付版：功能全开放，恒放行（返回 None）。"""
    return None


def clean_green(paths, on_progress=None):
    """一键清：并行 fast_purge 删除绿区缓存路径。

    paths: 报告 green[].trash_paths 展开后的路径列表
    返回 {ok, done:[], failed:[{path, reason}], reboot_pending: n}
    """
    # 档位检查：清理需基础版及以上（无支付版恒开放，直接放行）。
    gate = _tier_gate(1, "清理")
    if gate:
        return gate
    from concurrent.futures import ThreadPoolExecutor, as_completed
    done, failed = [], []
    reboot_pending = 0

    def _one(p):
        try:
            residual = migrate_mod.fast_purge(p, on_progress=on_progress)
            return p, residual
        except Exception as e:
            return p, ("ERR:" + str(e))

    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(_one, p) for p in paths]
        for fu in as_completed(futs):
            p, res = fu.result()
            if isinstance(res, list):
                done.append(p)
                if res:
                    reboot_pending += 1  # 有残留 = 已安排重启删
            else:
                failed.append({"path": p, "reason": str(res)})
    return {"ok": len(failed) == 0, "done": done, "failed": failed,
            "reboot_pending": reboot_pending}


def migrate_items(plan, on_progress=None):
    """执行迁移计划（复制-校验-切换 junction）。"""
    # 档位检查：迁移需高级版（无支付版恒开放，直接放行）。
    gate = _tier_gate(2, "迁移")
    if gate:
        return gate
    try:
        mres = migrate_mod.do_migrate(plan, dry_run=False, on_progress=on_progress,
                                      max_workers=None)
    except Exception as e:
        return {"ok": False, "done": [], "failed": [{"msg": str(e)}], "error": str(e)}
    return {"ok": True, "done": mres.get("done", []), "failed": mres.get("failed", [])}


# ---------------------------------------------------------------------------
# 报告摘要（供 Agent 对话框展示，不读完整 HTML）
# ---------------------------------------------------------------------------
def get_report_summary(analysis_path):
    """从 analysis.json 提取对话框展示用的摘要。

    绿区/迁移量**与报告页同源**（solution.green_reclaim_kb / migration.total_reclaim_kb），
    保证对话框与报告页数字完全一致（不重复自算，避免 7.2 vs 6.8 这种不一致）。
    """
    try:
        with open(analysis_path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return {"error": "读取报告失败：" + str(e)}
    sol = d.get("solution") or {}
    green_kb = float(sol.get("green_reclaim_kb") or 0)
    mig = d.get("migration") or {}
    mig_kb = float(mig.get("total_reclaim_kb") or 0)
    return {
        "green_gb": round(green_kb / 1024 / 1024, 1),
        "mig_gb": round(mig_kb / 1024 / 1024, 1),
        "green_count": len(d.get("green", [])),
        "mig_count": len(mig.get("candidates") or []),
        "scan_seconds": d.get("scan_seconds") or 0,
        "generated_at": d.get("generated_at") or "",
    }


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 交互能力扩展：迁移部分选择 / 档位能力
# ---------------------------------------------------------------------------
def tier_capabilities(tier):
    """按档位返回能力描述（无支付版：恒为高级版全能力）。"""
    return {"tier": 2, "name": "高级版", "clean": True, "migrate": True, "trash": True}


def get_migration_options(analysis_path):
    """返回迁移候选列表（含大小/目标盘容量，供用户部分选择）。

    返回 {options:[{id,name,size_gb,src,dst,capacity_exceeded}], target_drive, target_free_gb, total_gb}
    - capacity_exceeded=True 表示该候选已超出目标盘剩余空间（用户需挑选一部分）
    """
    try:
        with open(analysis_path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return {"error": "读取报告失败：" + str(e)}
    mig = d.get("migration") or {}
    plan = mig.get("plan") or []
    target_drive = mig.get("target_drive") or ""
    target_free_gb = float(mig.get("target_free_gb") or 0)
    options = []
    for i, p in enumerate(plan, 1):
        options.append({
            "id": i,
            "name": p.get("name") or p.get("display_name") or os.path.basename(p.get("src", "")),
            "size_gb": round(float(p.get("size_kb", 0) or 0) / 1024 / 1024, 1),
            "src": p.get("src", ""),
            "dst": p.get("dst", ""),
            "mode": p.get("mode", "junction"),
            "capacity_exceeded": bool(p.get("capacity_exceeded")),
        })
    total_gb = round(sum(o["size_gb"] for o in options), 1)
    return {"options": options, "target_drive": target_drive,
            "target_free_gb": target_free_gb, "total_gb": total_gb,
            "has_capacity_issue": any(o["capacity_exceeded"] for o in options)}


def plan_selected_migration(analysis_path, selected_ids):
    """按用户勾选的迁移项生成执行计划。

    selected_ids: 用户选择的 id 列表（来自 get_migration_options 的 options[].id）
    返回 do_migrate 可执行的 plan（含 src/dst/size_kb/mode）。
    """
    try:
        with open(analysis_path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return {"error": "读取报告失败：" + str(e)}
    plan = (d.get("migration") or {}).get("plan") or []
    chosen = []
    for p in plan:
        # 按顺序给每个 plan 项一个稳定 id（与 get_migration_options 一致）
        pass
    opts = get_migration_options(analysis_path).get("options", [])
    id_to_plan = {o["id"]: p for o, p in zip(opts, plan)}
    selected = [id_to_plan[i] for i in selected_ids if i in id_to_plan]
    if not selected:
        return {"error": "未选择任何迁移项"}
    return {"ok": True, "plan": selected, "count": len(selected),
            "total_gb": round(sum(float(p.get("size_kb", 0) or 0) for p in selected) / 1024 / 1024, 1)}


if __name__ == "__main__":
    # 自检
    lic = get_license()
    print("license:", json.dumps(lic, ensure_ascii=False)[:120])
