#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""license.py — 无支付版（pc-drive-safe-clean）最小许可模块。

NOPAY-BUILD：本版本已**物理删除全部支付/授权代码** —— 无 RSA 验签、无在线授权
台账、无口令兑换、无订单、无价目表、无本地授权服务。保留的只有被 server.py /
build_report.py / migrate.py / run.py 共用的纯本地基础设施（数据目录定位 +
机器指纹 + 档位常量），删掉它们整个产品会跑不起来。

对外契约（无支付版）：
  - get_data_dir()            用户数据目录（单一真理源，多候选自愈合并）
  - get_hwid()                稳定机器指纹（本地计算，绝不上报）
  - set_hwid_send_enabled()   隐私开关（仅本地记录）
  - current_tier()            恒 PRO_TIER（全功能开放）
  - can(feature)              恒 True
  - mode_allowed(mode)        恒允许（server.py /action 门控放行）
  - LOCAL_VERSION             兜底版本号
"""
import hashlib
import os
import sys

# ---------------------------------------------------------------------------
# 等级常量（server.py / skill_tools.py / build_report.py 引用）
# ---------------------------------------------------------------------------
FREE_TIER = 0
STANDARD_TIER = 1
PRO_TIER = 2

# feature -> minTier（无支付版全开放；保留表结构供 mode_allowed 校验 mode 名）
FEATURE_MIN_TIER = {
    "scan": FREE_TIER,
    "green_clean": STANDARD_TIER,
    "yellow_open": PRO_TIER,
    "trash_move": PRO_TIER,
    "migration_preview": PRO_TIER,
    "migration_exec": PRO_TIER,
}

# server.py /action mode -> feature
MODE_FEATURE = {
    "rm": "green_clean",
    "trash": "trash_move",
    "open": "yellow_open",
    "migrate": "migration_exec",
}

# 远端版本比较用的“当前版本号”（build_report / server 注入真实值，这里给兜底）
LOCAL_VERSION = "v1.7.101"

_HERE = os.path.dirname(os.path.abspath(__file__))

# 无支付版：本机恒为高级版（全功能开放）
_FIXED_TIER = PRO_TIER


# ===========================================================================
# 机器指纹（hwid）—— 与旧版逐字节一致的行为（本地计算，隐私开关可控）
# ===========================================================================
_HWID_CACHE = [None]  # 进程内缓存，避免热路径重复计算

# v1.7.64（安全合规）：设备指纹（MachineGuid / 卷序列号）使用开关。
_HWID_SEND_ENABLED = [True]


def set_hwid_send_enabled(enabled):
    """由前端隐私开关调用：是否允许使用真实设备指纹。
    False 时改用匿名安装 ID，不读取 MachineGuid 与卷序列号。"""
    _HWID_SEND_ENABLED[0] = bool(enabled)


def hwid_send_enabled():
    """当前是否允许使用真实设备指纹。"""
    return _HWID_SEND_ENABLED[0]


def _anon_install_id():
    """匿名安装 ID：仅在用户拒绝上报真实指纹时使用。随机生成、落盘本机，
    同一安装保持稳定，但不可追溯到真实硬件。"""
    import uuid
    _p = os.path.join(_HERE, ".anon_install_id")
    try:
        if os.path.isfile(_p):
            with open(_p, "r", encoding="utf-8") as f:
                v = f.read().strip()
                if v:
                    return "anon:" + v
    except Exception:
        pass
    v = uuid.uuid4().hex
    try:
        with open(_p, "w", encoding="utf-8") as f:
            f.write(v)
    except Exception:
        pass
    return "anon:" + v


def _win_volume_serial(root_path):
    """v1.7.86：用 Win32 API GetVolumeInformationW 直读卷序列号，返回大写十六进制串。

    为什么不用 wmic（v1.7.85 及以前）：
      - wmic 自 Windows 11 24H2 起被微软弃用，新版本逐步移除；
      - 企业 WDAC / AppLocker / 杀软常把 wmic.exe 拉黑，调用会失败；
      - 被安全策略拦时是**整个进程树被终止**（父进程一起死），不是抛异常，
        所以外层 try/except 根本救不回来。
    本函数纯 ctypes 调 kernel32：不 spawn 任何子进程、不受进程级黑名单影响、
    单次耗时在微秒级（原 wmic 单次数百毫秒）。
    读不到时返回 ""，由调用方走兜底。
    """
    if not (sys.platform == "win32" or sys.platform.startswith("win")):
        return ""
    try:
        import ctypes
        from ctypes import wintypes
        _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        _fn = _k32.GetVolumeInformationW
        _fn.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD,
                        wintypes.LPDWORD, wintypes.LPDWORD, wintypes.LPDWORD,
                        wintypes.LPWSTR, wintypes.DWORD]
        _fn.restype = wintypes.BOOL
        _name = ctypes.create_unicode_buffer(261)
        _serial = wintypes.DWORD(0)
        _max_comp = wintypes.DWORD(0)
        _flags = wintypes.DWORD(0)
        _fsname = ctypes.create_unicode_buffer(261)
        _ok = _fn(root_path, _name, ctypes.sizeof(_name) // 2,
                  ctypes.byref(_serial), ctypes.byref(_max_comp),
                  ctypes.byref(_flags), _fsname, ctypes.sizeof(_fsname) // 2)
        if not _ok:
            return ""
        _v = int(_serial.value)
        if _v <= 0:
            return ""
        return ("%08X" % _v)
    except Exception:
        return ""


def get_hwid():
    """返回稳定的本机指纹字符串。失败时用 hostname 兜底，保证永远有值。

    进程内缓存：hwid 在本机进程生命周期内恒定，缓存安全。
    用户关闭设备指纹上报时，返回匿名安装 ID，不读取 MachineGuid / 卷序列号。
    """
    if _HWID_CACHE[0] is not None:
        return _HWID_CACHE[0]
    if not _HWID_SEND_ENABLED[0]:
        _HWID_CACHE[0] = _anon_install_id()
        return _HWID_CACHE[0]
    parts = []
    try:
        if sys.platform == "win32" or sys.platform.startswith("win"):
            import winreg
            try:
                with winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        r"SOFTWARE\Microsoft\Cryptography") as k:
                    guid, _ = winreg.QueryValueEx(k, "MachineGuid")
                    parts.append("mg:" + str(guid))
            except Exception:
                pass
            # 系统盘卷序列号（稳定且难伪造）；Win32 API 直读，不起子进程
            _vsn = _win_volume_serial("C:\\")
            if _vsn:
                parts.append("vsn:" + _vsn)
        elif sys.platform == "darwin":
            try:
                import subprocess
                out = subprocess.run(
                    ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                    capture_output=True, text=True, timeout=5)
                m = __import__("re").search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out.stdout or "")
                if m:
                    parts.append("uuid:" + m.group(1))
            except Exception:
                pass
        else:
            mid = "/etc/machine-id"
            try:
                if os.path.exists(mid):
                    with open(mid, "r", encoding="utf-8") as f:
                        parts.append("mid:" + f.read().strip())
            except Exception:
                pass
    except Exception:
        pass

    if not parts:
        # 兜底：hostname + 固定 salt 的稳定哈希
        h = hashlib.sha256(
            ("aipcbutler|" + (__import__("socket").gethostname() or "unknown")).encode("utf-8")
        ).hexdigest()[:16]
        parts.append("host:" + h)

    _HWID_CACHE[0] = "|".join(parts)
    return _HWID_CACHE[0]


# ===========================================================================
# 用户数据目录（单一真理源；多候选目录自愈合并）
# ===========================================================================
_DATA_DIR_CACHE = [None]

# 跨候选目录自愈合并的稳定状态文件（缺哪个补哪个，绝不覆盖已有文件）
_STATE_FILES = (
    "clean_state.json", "privacy.json",
    "analysis_migrated.json", "recycle_pending.json", "last_report_url.txt",
)


def _roaming_base():
    """权威 Roaming AppData 目录（不依赖 APPDATA 环境变量）；取不到返回 ""。"""
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Application Support")
    if not (sys.platform == "win32" or sys.platform.startswith("win")):
        return ""
    # ① 注册表 Shell Folders（系统权威值，环境变量丢失也不受影响）
    try:
        import winreg
        with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders") as _k:
            _v, _t = winreg.QueryValueEx(_k, "AppData")
            if _v and os.path.isdir(_v):
                return _v
    except Exception:
        pass
    # ② SHGetFolderPathW(CSIDL_APPDATA = 0x001A)
    try:
        import ctypes
        _buf = ctypes.create_unicode_buffer(1024)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 0x001A, None, 0, _buf) == 0:
            _v = _buf.value
            if _v and os.path.isdir(_v):
                return _v
    except Exception:
        pass
    # ③ 环境变量
    _v = os.environ.get("APPDATA")
    if _v and os.path.isdir(_v):
        return _v
    # ④ USERPROFILE 兜底（比裸 expanduser("~") 更贴近真实用户目录）
    _up = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    return os.path.join(_up, "AppData", "Roaming")


def _candidate_data_dirs():
    """本项目历史上可能用过的所有数据目录（按优先级排序），去重且保序。"""
    # AIPC-DATA-DIR-OVERRIDE（v1.7.79）：显式指定数据目录时，**只认它**。
    # 两个用途：① 自动化 / 发布门禁在隔离目录里跑，不污染真实用户目录；
    # ② 运维兜底：数据目录异常时一个环境变量钉到指定位置，不必改代码重发版。
    _ov = (os.environ.get("AIPC_DATA_DIR") or "").strip()
    if _ov:
        _out = []
        for _p in _ov.split(os.pathsep):
            _p = _p.strip()
            if _p:
                _out.append(os.path.abspath(os.path.expanduser(_p)))
        if _out:
            return _out
    if sys.platform == "darwin":
        _raw = [os.path.expanduser("~/Library/Application Support/AI_PC_Butler")]
    elif not (sys.platform == "win32" or sys.platform.startswith("win")):
        _raw = [os.path.expanduser("~/.config/AI_PC_Butler"),
                os.path.expanduser("~/.ai_pc_butler")]
    else:
        _up = os.environ.get("USERPROFILE") or os.path.expanduser("~")
        _raw = []
        _rb = _roaming_base()
        if _rb:
            _raw.append(os.path.join(_rb, "AI_PC_Butler"))
        # 历史 bug 会落到这里（APPDATA 缺失时 expanduser("~") 的兜底目录）
        _raw.append(os.path.join(os.path.expanduser("~"), "AI_PC_Butler"))
        _raw.append(os.path.join(_up, "AI_PC_Butler"))
        # migrate.py 曾把回收站兜底清单写到 Local
        _la = os.environ.get("LOCALAPPDATA") or os.path.join(_up, "AppData", "Local")
        _raw.append(os.path.join(_la, "AI_PC_Butler"))
    _out, _seen = [], set()
    for _d in _raw:
        if not _d:
            continue
        _k = os.path.normcase(os.path.abspath(_d))
        if _k not in _seen:
            _seen.add(_k)
            _out.append(_d)
    return _out


def _consolidate_state(chosen, cands):
    """自愈：其它候选目录里已有的状态文件，补进选定目录（只补缺，绝不覆盖）。"""
    try:
        for _f in _STATE_FILES:
            _dst = os.path.join(chosen, _f)
            if os.path.exists(_dst):
                continue
            for _d in cands:
                if os.path.abspath(_d) == os.path.abspath(chosen):
                    continue
                _src = os.path.join(_d, _f)
                if os.path.isfile(_src):
                    try:
                        __import__("shutil").copy2(_src, _dst)
                    except Exception:
                        pass
                    break
    except Exception:
        pass


def get_data_dir():
    """跨平台用户数据目录（单一真理源）；不存在则创建。

    关键：多候选目录中优先选【已有 license.json】的那个（取 mtime 最新），
    保证"激活一次、永久可用"，彻底消除 APPDATA 环境变量导致的目录漂移。
    （无支付版没有 license.json，该分支自然落到第一个候选目录；
    历史老版本用户机器上的 license.json 仍会被优先选中，从而保留其
    clean_state.json 等状态文件的目录一致性。）
    结果进程内缓存，避免重复探测注册表 / 磁盘。
    """
    if _DATA_DIR_CACHE[0]:
        return _DATA_DIR_CACHE[0]
    cands = _candidate_data_dirs()
    chosen = cands[0] if cands else os.path.expanduser("~/AI_PC_Butler")
    _best, _best_mt = None, -1.0
    for _d in cands:
        _lp = os.path.join(_d, "license.json")
        if os.path.isfile(_lp):
            try:
                _mt = os.path.getmtime(_lp)
            except Exception:
                _mt = 0.0
            if _mt > _best_mt:
                _best, _best_mt = _d, _mt
    if _best:
        chosen = _best
    try:
        os.makedirs(chosen, exist_ok=True)
    except Exception:
        chosen = os.path.expanduser("~/.ai_pc_butler")
        try:
            os.makedirs(chosen, exist_ok=True)
        except Exception:
            pass
    _consolidate_state(chosen, cands)
    _DATA_DIR_CACHE[0] = chosen
    return chosen


# ===========================================================================
# 档位查询（无支付版：恒高级版，全功能开放）
# ===========================================================================
def current_tier():
    """当前有效等级。无支付版恒为 PRO_TIER（高级版，全功能）。"""
    return _FIXED_TIER


def can(feature):
    """当前许可是否覆盖某 feature。无支付版恒 True。"""
    return True


def mode_allowed(mode):
    """server.py /action 的 mode 是否允许。无支付版恒允许。"""
    feat = MODE_FEATURE.get(mode)
    if not feat:
        return False, FREE_TIER, "未知操作"
    return True, _FIXED_TIER, ""
