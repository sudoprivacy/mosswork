# -*- coding: utf-8 -*-
"""workbuddy-move-workspace 配套脚本 v2（支持批量）

用途：安全搬迁 WorkBuddy 项目/工作区文件夹，并保证旧对话记录仍可正常打开。

用法：
  单组: python move_workspace.py --old "旧路径" --new "新路径"
  批量: python move_workspace.py --batch "清单文件.txt"
        清单文件每行格式: 旧路径|新路径  （用 | 分隔）

功能（对每一组）：
  1. 移动 ~/.workbuddy/projects/<旧编码> 归档目录为 <新编码>（已存在则合并）
  2. 修复权威数据库 ~/.workbuddy/workbuddy.db（sessions.cwd / workspaces.path 等全部文本字段）
  3. 全盘修复缓存文件（projects/*.jsonl、sessions/*.json、app/sessions.json、artifact-index/*.json）
     中的旧路径引用 —— 兼容盘符大小写、单/双反斜杠、正斜杠全部书写变体
  4. 自动备份（~/.workbuddy/_pathfix_backup_<日期>/）+ JSON 合法性校验

注意：执行后必须重启 WorkBuddy，界面才会从数据库重新读取新路径。
"""
import os
import sys
import glob
import json
import shutil
import argparse
import sqlite3
import datetime


def encode_path(p):
    """路径编码：盘符小写、去冒号、反斜杠变横线
    D:\\360安全云盘同步版\\x -> d-360安全云盘同步版-x
    """
    p = p.rstrip('\\/')
    return (p[0].lower() + p[1:]).replace(':', '').replace('\\', '-')


def path_pairs(old, new):
    """生成 (旧路径变体, 同风格新值) 配对，兼容大小写盘符 × 斜杠形式
    同风格替换保证 JSON 转义双反斜杠 / 正斜杠 / 单反斜杠在替换后保持原风格，
    不会破坏 JSON 合法性。
    """
    def style(o, n, mode):
        if mode == 'bs':
            return o.replace('\\', '\\\\'), n.replace('\\', '\\\\')
        if mode == 'fs':
            return o.replace('\\', '/'), n.replace('\\', '/')
        return o, n

    bases = [(old, new)]
    if len(old) >= 2 and old[1] == ':':
        low_o = old[0].lower() + old[1:]
        low_n = (new[0].lower() + new[1:]) if (len(new) >= 2 and new[1] == ':') else new
        bases.append((low_o, low_n))

    pairs = []
    for o, n in bases:
        pairs.append(style(o, n, 'raw'))
        pairs.append(style(o, n, 'bs'))
        pairs.append(style(o, n, 'fs'))
    # 长变体优先（双反斜杠先于单反斜杠），去重
    seen = set()
    out = []
    for o, n in sorted(pairs, key=lambda x: len(x[0]), reverse=True):
        if o not in seen:
            seen.add(o)
            out.append((o, n))
    return out


def fix_text(text, pairs, new):
    for o, n in pairs:
        text = text.replace(o, n)
    return text


def fix_db(wb, pairs, new, bak):
    db = os.path.join(wb, 'workbuddy.db')
    if not os.path.exists(db):
        print('  [提示] workbuddy.db 不存在，跳过')
        return 0
    shutil.copy2(db, os.path.join(bak, 'workbuddy.db'))
    con = sqlite3.connect(db, timeout=20)
    cur = con.cursor()
    changed = 0
    for t in ('sessions', 'workspaces'):
        try:
            cols = [c[1] for c in cur.execute('PRAGMA table_info("%s")' % t)]
        except sqlite3.Error:
            continue
        for col in cols:
            try:
                rows = cur.execute('SELECT rowid, "%s" FROM "%s"' % (col, t)).fetchall()
            except sqlite3.Error:
                continue
            for rid, val in rows:
                # 只处理文本字段（int/float/blob 等跳过，避免 TypeError）
                if isinstance(val, str) and any(o in val for o, _ in pairs):
                    cur.execute('UPDATE "%s" SET "%s"=? WHERE rowid=?' % (t, col),
                                (fix_text(val, pairs, new), rid))
                    changed += 1
                    print('  db更新: %s.%s (rowid=%s)' % (t, col, rid))
    con.commit()
    con.close()
    return changed


def fix_files(wb, pairs, new, bak):
    EXCLUDE = {'logs', 'binaries', 'blobs', 'plugins', 'pending-telemetry',
               'traces', 'audit-log', 'file-history', 'shell-snapshots'}
    fixed = []
    for root, dirs, files in os.walk(wb):
        dirs[:] = [d for d in dirs if d not in EXCLUDE and not d.startswith('_pathfix_backup')]
        for f in files:
            fp = os.path.join(root, f)
            try:
                with open(fp, 'rb') as fh:
                    data = fh.read()
            except OSError:
                continue
            if b'\x00' in data:
                continue
            text = data.decode('utf-8', errors='replace')
            if any(o in text for o, _ in pairs):
                shutil.copy2(fp, os.path.join(bak, os.path.basename(fp) + '.' + str(len(fixed))))
                with open(fp, 'w', encoding='utf-8') as fh:
                    fh.write(fix_text(text, pairs, new))
                fixed.append(fp)
                print('  文件修复: %s' % fp)
    return fixed


def validate(files):
    bad = []
    for fp in files:
        # 只校验 JSON/JSONL 文件（.md/.html 等备份文件非 JSON，跳过）
        if not (fp.endswith('.json') or fp.endswith('.jsonl')):
            continue
        try:
            with open(fp, 'r', encoding='utf-8') as f:
                if fp.endswith('.jsonl'):
                    for line in f:
                        if line.strip():
                            json.loads(line)
                else:
                    json.load(f)
        except Exception as e:
            bad.append((fp, str(e)))
    return bad


def move_project_dir(wb, old, new, bak):
    """零删除策略：旧归档整体移入备份区（可恢复），再从备份区复制到新归档位置。
    全程不删除任何数据；清理需用户确认后手动进行。"""
    old_code = encode_path(old)
    new_code = encode_path(new)
    old_dir = os.path.join(wb, 'projects', old_code)
    new_dir = os.path.join(wb, 'projects', new_code)
    if not os.path.isdir(old_dir):
        print('  [提示] 归档目录不存在（该项目可能没有对话记录）: %s' % old_dir)
        return
    # 1) 旧归档移入备份区（源位置消失，但数据完整保留、可恢复）
    old_bak = os.path.join(bak, 'projects_old', old_code)
    os.makedirs(os.path.dirname(old_bak), exist_ok=True)
    if not os.path.exists(old_bak):
        shutil.move(old_dir, old_bak)
    print('  [保留] 旧归档已移入备份区（未删除，可恢复）: %s' % old_bak)
    # 2) 从备份区复制到新归档位置
    if os.path.isdir(new_dir):
        print('  新归档目录已存在，合并文件...')
        for f in os.listdir(old_bak):
            src = os.path.join(old_bak, f)
            dst = os.path.join(new_dir, f)
            if os.path.exists(dst):
                print('  [跳过] 文件名冲突（备份区完整保留）:', f)
            else:
                shutil.copy2(src, dst)
    else:
        shutil.copytree(old_bak, new_dir)
        print('  新归档已建立: %s' % new_dir)


def process_one(wb, old, new, bak):
    # 参数归一化：Git Bash/MSYS 会把参数里的 \ 转成 /，统一还原为 \ 避免 db 匹配失败
    old = old.replace('/', '\\')
    new = new.replace('/', '\\')
    print('处理: %s  ->  %s' % (old, new))
    print('  编码: %s -> %s' % (encode_path(old), encode_path(new)))
    move_project_dir(wb, old, new, bak)
    pairs = path_pairs(old, new)
    n_db = fix_db(wb, pairs, new, bak)
    fixed = fix_files(wb, pairs, new, bak)
    bad = validate(fixed)
    if bad:
        print('  [错误] JSON 校验失败: %s（可用备份恢复 %s）' % (bad, bak))
        return 1
    print('  完成: db %d 处, 文件 %d 个, 备份 %s' % (n_db, len(fixed), bak))
    return 0


def main():
    ap = argparse.ArgumentParser(description='搬迁 WorkBuddy 项目文件夹并保留旧对话（支持批量）')
    ap.add_argument('--old', help='旧路径（单组模式）')
    ap.add_argument('--new', help='新路径（单组模式）')
    ap.add_argument('--batch', help='批量清单文件，每行: 旧路径|新路径')
    args = ap.parse_args()

    if not args.batch and not (args.old and args.new):
        ap.error('必须提供 --old/--new 或 --batch')

    wb = os.path.expanduser(r'~\.workbuddy')
    bak = os.path.join(wb, '_pathfix_backup_' + datetime.date.today().strftime('%Y%m%d'))
    os.makedirs(bak, exist_ok=True)

    groups = []
    if args.batch:
        with open(args.batch, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '|' in line:
                    o, n = line.split('|', 1)
                    groups.append((o.strip(), n.strip()))
        print('批量清单: 共 %d 组' % len(groups))
    else:
        groups.append((args.old, args.new))

    rc = 0
    for old, new in groups:
        if old == new:
            print('跳过（新旧相同）: %s' % old)
            continue
        rc |= process_one(wb, old, new, bak)
        print()

    print('全部完成！请重启 WorkBuddy 使界面生效。')
    print('全程零删除：旧数据（含旧归档）均完整保留在备份目录: %s' % bak)
    print('请确认新位置一切正常后，再清理旧数据——可告诉我删除，或你自行删除该备份目录。')
    return rc


if __name__ == '__main__':
    sys.exit(main())
