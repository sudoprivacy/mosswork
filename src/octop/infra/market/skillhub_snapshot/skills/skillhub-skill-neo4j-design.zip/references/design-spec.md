# Neo4j 图数据库设计规范

## 命名规范

### 节点标签

| 规范 | 说明 | 示例 |
|------|------|------|
| PascalCase | 每个单词首字母大写 | `User`、`Product`、`OrderItem` |
| 单数名词 | 表示单个实体 | `Customer` 而非 `Customers` |
| 避免通用名 | 明确业务含义 | `PremiumUser` 而非 `Entity` |
| 中间节点 | 描述关系本身 | `UserGroup`、`Membership` |

### 关系类型

| 规范 | 说明 | 示例 |
|------|------|------|
| UPPER_SNAKE_CASE | 大写下划线 | `PLACED`、`BELONGS_TO` |
| 动词或介词 | 表达动作或归属 | `REVIEWED`、`IN_CATEGORY` |
| 方向明确 | 从主体指向客体 | `(:User)-[:PLACED]->(:Order)` |
| 避免双向冗余 | 一条关系覆盖双向查询 | `FRIEND_OF`，查询时用无向模式 |

### 属性名

| 规范 | 说明 | 示例 |
|------|------|------|
| camelCase | 小驼峰 | `createdAt`、`orderCount` |
| 布尔前缀 `is` / `has` | 布尔属性 | `isActive`、`hasSubscription` |
| 时间后缀 `At` | 时间戳属性 | `registeredAt`、`updatedAt` |
| ID 后缀 `Id` | 业务 ID | `userId`、`productId` |

---

## 图模型设计

### 节点设计原则

1. **节点 = 实体** — 现实中独立存在的事物（人/商品/订单/地点）
2. **属性 = 特征** — 实体的固有属性，不随时间变化的放在节点
3. **关系 = 行为/联系** — 实体间发生的动作或关联
4. **避免属性存 JSON** — 结构化数据建模为节点和关系，不压缩到 String 属性
5. **反规范化权衡** — 高读低频更新场景可冗余属性到相邻节点

### 关系类型 vs 中间节点

| 场景 | 直接关系 | 中间节点 |
|------|---------|---------|
| 简单关联 | `(:User)-[:KNOWS]->(:User)` | — |
| 带元数据关联 | `(:User)-[:PURCHASED {at: datetime()}]->(:Product)` | — |
| 多对多+属性 | — | `(:User)-[:MEMBER_OF]->(:Group)-[:HAS_ROLE]->(:Role)` |
| 超图关系（>2端） | — | `(:User)-[:PURCHASED]->(:Transaction)<-[:INCLUDED]-(:Product)` |

### 关系属性设计

适合放在关系上的属性（与具体交互相关）：
- 时间：`at`、`since`、`until`
- 度量：`quantity`、`amount`、`rating`
- 状态：`status`、`role`
- 元数据：`source`、`traceId`

---

## 索引设计

### 属性索引

```cypher
-- 单属性索引
CREATE INDEX idx_User_email FOR (n:User) ON (n.email)

-- 复合索引（等值+范围）
CREATE INDEX idx_Order_user_date FOR (n:Order) ON (n.userId, n.createdAt)

-- 基于文本的分词索引
CREATE TEXT INDEX idx_Article_content FOR (n:Article) ON (n.content)
```

### 全文索引

```cypher
CREATE FULLTEXT INDEX idx_Product_search
FOR (n:Product) ON EACH [n.name, n.description]
```

### 向量索引

```cypher
CREATE VECTOR INDEX idx_Product_embedding
FOR (n:Product) ON (n.embedding)
OPTIONS {indexConfig: {
  `vector.dimensions`: 1536,
  `vector.similarity_function`: "COSINE"
}}
```

### 约束

```cypher
-- 唯一约束
CREATE CONSTRAINT cst_User_uuid ON (n:User) ASSERT n.uuid IS UNIQUE

-- 节点键约束（唯一 + 存在）
CREATE CONSTRAINT cst_Order_key ON (n:Order) ASSERT (n.orderId) IS NODE KEY

-- 属性存在约束
CREATE CONSTRAINT cst_User_email_exists ON (n:User) ASSERT EXISTS (n.email)
```

---

## 遍历深度控制

| 场景 | 推荐深度 | 示例 |
|------|---------|------|
| 直接关系 | `[*1]` | `()-[:KNOWS]->()` |
| 二级关系 | `[*1..2]` 或 `[*2]` | 朋友的朋友 |
| 层级树 | `[*1..10]` | 组织树/类目树 |
| 推荐路径 | `[*1..4]` | 最短路径推荐 |
| 无限深度 | 永远禁止 `[*]` | 用 `[*1..N]` 明确上限 |

---

## 多数据库架构

```
Neo4j 实例
├── system（系统管理）
├── neo4j（默认数据库）
├── orders-graph（订单图）
└── knowledge-graph（知识图谱）

跨库查询：Composite Database (Fabric)
USE fabric.knowledge-graph
MATCH (c:Concept)
CALL {
  USE fabric.orders-graph
  MATCH (p:Product)-[:TAGGED]->(c)
  RETURN p
}
RETURN c, p
```
