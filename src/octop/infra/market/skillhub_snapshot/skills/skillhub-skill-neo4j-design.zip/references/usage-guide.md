# Neo4j 场景化操作指南

## 数据库管理

### 创建数据库

```cypher
CREATE DATABASE knowledge_graph
OPTIONS {existingData: 'use'}
```

### 查看数据库

```cypher
SHOW DATABASES
SHOW DATABASE knowledge_graph
```

### 停止/启动数据库

```cypher
STOP DATABASE knowledge_graph
START DATABASE knowledge_graph
```

---

## 节点和关系操作

### 创建节点

```cypher
CREATE (u:User {
  userId: "U-001",
  name: "Alice",
  email: "alice@example.com",
  createdAt: datetime()
})
```

### MERGE（幂等创建）

```cypher
MERGE (u:User {email: "alice@example.com"})
ON CREATE SET u.userId = "U-001", u.createdAt = datetime()
ON MATCH SET u.lastSeenAt = datetime()
```

### 创建关系

```cypher
MATCH (u:User {userId: "U-001"})
MATCH (o:Order {orderId: "ORD-001"})
CREATE (u)-[:PLACED {at: datetime()}]->(o)
```

### 批量创建

```cypher
UNWIND $items AS item
CREATE (u:User {
  userId: item.id,
  name: item.name,
  email: item.email
})
```

---

## 查询

### 基本查询

```cypher
MATCH (u:User {userId: "U-001"})
RETURN u.name, u.email
```

### 路径查询

```cypher
-- 朋友的朋友（2层）
MATCH (a:User {userId: "U-001"})-[:KNOWS*1..2]-(f:User)
WHERE a <> f
RETURN DISTINCT f

-- 最短路径
MATCH p = shortestPath((a:User {userId: "U-001"})-[:KNOWS*..]-(b:User {userId: "U-999"}))
RETURN p
```

### 聚合

```cypher
MATCH (u:User)-[:PLACED]->(o:Order)
RETURN u.userId, count(o) AS orderCount, sum(o.total) AS totalSpent
ORDER BY totalSpent DESC
```

### 子查询

```cypher
MATCH (u:User)
CALL {
  WITH u
  MATCH (u)-[:PLACED]->(o:Order)
  RETURN count(o) AS orderCount
}
RETURN u.name, orderCount
```

---

## 索引管理

### 创建索引

```cypher
CREATE INDEX idx_User_email FOR (n:User) ON (n.email)
CREATE TEXT INDEX idx_Article_content FOR (n:Article) ON (n.content)
CREATE FULLTEXT INDEX idx_Product_search FOR (n:Product) ON EACH [n.name, n.description]
CREATE VECTOR INDEX idx_Product_embed FOR (n:Product) ON (n.embedding)
  OPTIONS {indexConfig: {`vector.dimensions`: 1536, `vector.similarity_function`: "COSINE"}}
```

### 查看索引

```cypher
SHOW INDEXES
```

### 删除索引

```cypher
DROP INDEX idx_User_email
```

---

## 向量搜索

### 查询向量索引

```cypher
MATCH (n:Product)
CALL db.index.vector.queryNodes("idx_Product_embed", 10, $queryVector)
YIELD node, score
RETURN node.name, node.description, score
```

### MATCH + SEARCH（2026.01+）

```cypher
MATCH (n:Product)
CALL (n) SEARCH ON (n.embedding, $queryVector, 10) YIELD score
WHERE score > 0.7
RETURN n.name, score
```

---

## 约束管理

```cypher
-- 唯一约束
CREATE CONSTRAINT cst_User_uuid ON (n:User) ASSERT n.uuid IS UNIQUE

-- 节点键
CREATE CONSTRAINT cst_Order_key ON (n:Order) ASSERT (n.orderId) IS NODE KEY

-- 属性存在
CREATE CONSTRAINT cst_User_email_exists ON (n:User) ASSERT EXISTS (n.email)

-- VECTOR 属性类型约束（2025.10+）
CREATE CONSTRAINT cst_Product_vector_type
ON (n:Product) ASSERT n.embedding IS VECTOR(1536)
```

---

## 导入数据

### LOAD CSV

```cypher
LOAD CSV WITH HEADERS FROM 'file:///users.csv' AS row
CREATE (:User {
  userId: row.id,
  name: row.name,
  email: row.email
})
```

### neo4j-admin 批量导入

```bash
neo4j-admin database import full \
  --nodes=Product=nodes/products.csv \
  --nodes=User=nodes/users.csv \
  --relationships=PLACED=rels/placed.csv \
  knowledge_graph
```
