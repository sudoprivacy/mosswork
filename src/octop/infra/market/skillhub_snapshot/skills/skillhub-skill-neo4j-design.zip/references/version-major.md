# Neo4j 重大版本特性

> 加载时机：模块被启用时加载，用于对比用户使用的 Neo4j 版本，提示废弃/重大变更。
> 注意：Neo4j 自 2025.01 起从语义版本号（5.x）切换为 CalVer（YYYY.MM）命名。

---

## 2026.04 (2026-04-29)

### 废弃

- **无主要 API 废弃**。

### 新增重要模块/功能

- **ServerSeedProvider**：支持从 URI 远程获取种子文件，简化集群初始化。

---

## 2026.03 (2026-04-08)

### 新增重要模块/功能

- **路径模式（Path Modes）**：`MATCH p = (a)-/->(b)`（任意方向）、`MATCH p = (a)-[r]->(b) {mode: "walk"}` 等路径匹配模式。
- **`PROPERTY_EXISTS` 谓词**：`WHERE PROPERTY_EXISTS(n, 'email')` 语义更明确。
- **`currentQueryProgress` 列**：`SHOW TRANSACTIONS` 可查看当前查询进度。

---

## 2026.02 (2026-03)

### 新增重要模块/功能

- **Cypher 25 成为默认**：新建数据库默认使用 Cypher 25 语法。
- **`ALTER CURRENT GRAPH TYPE`（预览）**：声明式管理图类型（`SET` / `ADD` / `ALTER` / `DROP`），统一三元组/属性图操作。
- **Multi-Label / Multi-Rel-Type 向量索引**：单个向量索引覆盖多个标签或关系类型。

---

## 2026.01 (2026-01)

### 新增重要模块/功能

- **`SEARCH` 子句**：`MATCH ... CALL (n) SEARCH ON (n.embedding, queryVector, 10)` 在 MATCH 中直接进行向量相似度搜索。
- **查询缓存大小限制**：`server.memory.query_cache.max_size` 配置缓存上限。

---

## 2025.12 (2025-12)

### 新增重要模块/功能

- **动态标签/关系类型索引支持**：`MATCH (n:${dynamicLabel})` 可使用属性索引加速。
- **`bad-tolerance` 默认改为 -1（无限制）**：导入容忍更多错误行。
- **Property Shard Replica 配置**：分片副本数可配置。

---

## 2025.10 (2025-10)

### 新增重要模块/功能

- **原生 `VECTOR` 值类型**：向量嵌入作为第一类数据类型存储，`vector([0.1, 0.2, ...])` 构造函数。
- **向量函数族**：`vector_dimension_count()`、`vector_distance()`、`vector_norm()`。
- **Java 25 支持**。

---

## 2025.06 (2025-06)

### 新增重要模块/功能

- **Cypher 25 语言引入**：`WHEN`/`ELSE` 条件查询、`LET` 变量绑定、`FILTER` 子句、`NEXT` 顺序查询、`UNION` 块。
- **`cosh`/`sinh`/`tanh`/`coth` 双曲函数**。
- **`ALL` 关键字**：显式返回非 DISTINCT 结果。

---

## 2025.01 (2025-01)

### 废弃

- **Java 17 不支持** → Java 21 强制。
- **Discovery Service v1 移除** → 必须使用 v2。
- **debug.log 格式默认 JSON**，旧格式废弃。
- **Block format 强制推荐**：`standard` 和 `high_limit` 格式废弃。

### 依赖变更

- Java 21 强制，macOS <13 和 Windows Server 2016/2019 不再支持。

### 新增重要模块/功能

- **CalVer 版本命名的首个版本**：从语义版本号（5.x）切换到日历版本（YYYY.MM）。

---

## 5.26 LTS (2024-11)

### 新增重要模块/功能

- **最后一个 5.x LTS 版本**，长期支持主线。
- **向量索引成熟**：生产就绪的 VECTOR INDEX，支持 COSINE/EUCLIDEAN 相似度。
- **GenAI Plugin 预览**：原生集成 OpenAI/Azure/VertexAI/Bedrock 嵌入和补全。
- **文本索引（TEXT INDEX）**：模糊匹配/前缀搜索专用索引。

---

## 5.0 (2022-10)

### 新增重要模块/功能

- **复合数据库（Composite Database）**：多图代理查询（Fabric）。
- **全文索引重构**：`CREATE FULLTEXT INDEX` 新语法。
- **约束增强**：节点键约束（Node Key）、属性存在约束。
- **Cypher 增强**：子查询（CALL {}），EXISTS 子查询改进。
- **自治集群（Autonomous Clustering）**：简化集群管理。

---

> 本文件仅收录影响架构设计的特性。Bug 修复、安全补丁、底层优化等不在收录范围内。
