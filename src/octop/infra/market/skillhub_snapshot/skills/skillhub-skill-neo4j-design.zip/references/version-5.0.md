# Neo4j 5.x 深度版本特性

> 加载时机：Step 0 版本检查时自动加载（本文件版本 ≤ 用户目标版本时加载）。

---

## 5.26 LTS (2024-11)

- **Vector Index Production Ready**：`CREATE VECTOR INDEX idx_embed FOR (n:Product) ON (n.embedding) OPTIONS {indexConfig: {\`vector.dimensions\`: 1536, \`vector.similarity_function\`: "COSINE"}}`，`db.index.vector.query_nodes("idx_embed", 10, $queryVector)` 查询。 → 语义搜索/GraphRAG 基础能力就绪；相似度检索+图遍历在单次查询完成。[[ref]](https://neo4j.com/docs/cypher-manual/current/indexes-for-vector-search/)

- **GenAI Plugin Preview**：`apoc.ml.openai.embedding()` 等扩展过程调用外部 LLM 生成向量。 → 预览阶段非生产使用；为 2025.11 的原生 GenAI 集成铺路。[[ref]](https://neo4j.com/docs/cypher-manual/current/genai-integration/)

- **Text Index (TEXT INDEX)**：`CREATE TEXT INDEX idx_Article_content FOR (n:Article) ON (n.content)`，支持 `STARTS WITH`、`ENDS WITH`、`CONTAINS` 快速过滤。 → 模糊搜索/前缀匹配/后缀匹配场景，替代代价高昂的正则全扫描。[[ref]](https://neo4j.com/docs/cypher-manual/current/indexes-for-text-search/)

- **Block Format Strongly Recommended**：`dbms.db.format=block` 替代 `standard` 和 `high_limit`。 → 升级到 2025.01+ 前必须切换到 Block 格式；存储效率和恢复速度提升。[[ref]](https://neo4j.com/docs/operations-manual/current/database-administration/store-formats/)

---

## 5.0 (2022-10)

- **Composite Database (Fabric)**：`CREATE COMPOSITE DATABASE fabric` 联合多个独立数据库代理查询。单个 Cypher 查询可跨越多个图（`USE fabric.graph1`），结果在协调节点聚合。 → 跨业务域（用户图+订单图+商品图）联合查询无需数据合并；多租户 SaaS 物理隔离下的跨租户分析。[[ref]](https://neo4j.com/docs/operations-manual/current/database-administration/composite-databases/)

- **FULLTEXT INDEX Refactored**：`CREATE FULLTEXT INDEX idx_Product_desc FOR (n:Product) ON EACH [n.description, n.name]`，新索引语法，支持多属性跨标签。 → 比旧 `CALL db.index.fulltext.*` 过程更直观；配合 `db.index.fulltext.queryNodes()` 搜索。[[ref]](https://neo4j.com/docs/cypher-manual/current/indexes-for-full-text-search/)

- **Node Key Constraint**：`CREATE CONSTRAINT cst_User_key ON (n:User) ASSERT (n.uuid) IS NODE KEY`，属性组合唯一+存在性双重约束。 → 业务主键（非代理键）的场景；替代 UNIQUE + NOT NULL 两条约束的组合。[[ref]](https://neo4j.com/docs/cypher-manual/current/constraints/)

- **Property Existence Constraint**：`CREATE CONSTRAINT cst_User_email_exists ON (n:User) ASSERT EXISTS (n.email)`，属性不可为 null。 → Schema 强约束，防止不完整节点写入。[[ref]](https://neo4j.com/docs/cypher-manual/current/constraints/)

- **CALL {} Subquery**：`CALL { MATCH (n)-[:PURCHASED]->(p) RETURN count(p) AS cnt }` 子查询块，支持导入变量、UNION、后过滤。 → 复杂图遍历模块化；避免单条 Cypher 嵌套过深。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/call-subquery/)

- **EXISTS Subquery Improved**：`MATCH (u:User) WHERE EXISTS { MATCH (u)-[:PLACED]->(:Order) }` 图式存在性子查询，语义更明确。 → 替代 `WHERE size((u)-[:PLACED]->()) > 0`，性能更优（短路求值）。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/where/)

- **Autonomous Clustering**：`dbms.cluster.cluster_name` + `dbms.cluster.discovery` 参数简化集群发现，自动分配 Leader/Follower 角色。 → 不需要手工分配角色；滚动升级自动化。[[ref]](https://neo4j.com/docs/operations-manual/current/clustering/)

- **Administration Commands Enhanced**：`SHOW DATABASES`、`CREATE DATABASE`、`STOP/START DATABASE` 数据库生命周期管理。 → 与关系数据库风格一致的管理命令。[[ref]](https://neo4j.com/docs/cypher-manual/current/databases/)

---
