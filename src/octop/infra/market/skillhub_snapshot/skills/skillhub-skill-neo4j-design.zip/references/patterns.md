# Neo4j 业务图模型模板

## 1. 社交网络

```
(:User {userId, name, email, createdAt})
-[:KNOWS {since}]->(:User)
-[:FOLLOWS {at}]->(:User)
-[:SENT]->(:Message {text, createdAt})-[:TO]->(:User)
-[:LIKES {at}]->(:Post)
```

索引：
```cypher
CREATE CONSTRAINT cst_User_id ON (n:User) ASSERT n.userId IS UNIQUE
CREATE INDEX idx_User_name FOR (n:User) ON (n.name)
```

关键查询：
```cypher
-- 二度人脉
MATCH (me:User {userId: "U-001"})-[:KNOWS*2]-(fof:User)
WHERE NOT (me)-[:KNOWS]-(fof) AND me <> fof
RETURN DISTINCT fof
```

---

## 2. 推荐系统（协同过滤）

```
(:User)-[:PURCHASED]->(:Product)
(:User)-[:VIEWED {count}]->(:Product)
(:Product)-[:SIMILAR_TO {score}]->(:Product)
(:Product)-[:IN_CATEGORY]->(:Category)
```

推荐查询（买了也买了）：
```cypher
MATCH (me:User {userId: "U-001"})-[:PURCHASED]->(:Product)<-[:PURCHASED]-(other:User)-[:PURCHASED]->(rec:Product)
WHERE NOT (me)-[:PURCHASED]->(rec)
RETURN rec, count(*) AS strength
ORDER BY strength DESC LIMIT 10
```

向量索引（协同过滤 + 语义）：
```cypher
CREATE VECTOR INDEX idx_Product_embed
FOR (n:Product) ON (n.embedding)
OPTIONS {indexConfig: {`vector.dimensions`: 1536, `vector.similarity_function`: "COSINE"}}
```

---

## 3. 反欺诈（交易环检测）

```
(:User)-[:HAS]->(:Account {balance, createdAt})
(:Account)-[:SENT {amount, at}]->(:Transaction)-[:TO {amount}]->(:Account)
(:Account)-[:LINKED_TO]->(:Account) -- 共享设备/IP
```

环检测查询：
```cypher
MATCH p = (a1:Account)-[:SENT]->(:Transaction)-[:TO]->(a2:Account)-[:SENT]->(:Transaction)-[:TO]->(a1)
WHERE a1 <> a2 AND abs(a1.balance) > 0
RETURN p LIMIT 100
```

---

## 4. 知识图谱

```
(:Concept {name, description})
-[:RELATED_TO {type}]->(:Concept)
-[:HAS_PROPERTY]->(:Property {key, value})
(:Document)-[:MENTIONS]->(:Concept)
(:Concept)-[:BELONGS_TO]->(:Domain)
```

向量+图搜索（GraphRAG）：
```cypher
MATCH (c:Concept)
CALL db.index.vector.queryNodes("idx_Concept_embed", 20, $queryVector)
YIELD node, score
MATCH (node)-[r:RELATED_TO]-(related:Concept)
RETURN node.name, collect(related.name), score
```

---

## 5. 组织架构

```
(:Employee {name, title, email})
-[:REPORTS_TO {since}]->(:Employee)
-[:MEMBER_OF {role}]->(:Department {name})
-[:WORKS_ON {allocation}]->(:Project {name, deadline})
(:Department)-[:HAS_MANAGER]->(:Employee)
```

层级查询：
```cypher
MATCH path = (e:Employee {name: "Alice"})-[:REPORTS_TO*1..10]->(boss:Employee)
RETURN [n IN nodes(path) | n.name] AS chain
```

---

## 6. 供应链追溯

```
(:Product {sku, name, batchNo})
-[:CONTAINS]->(:Component {code, description})
-[:SOURCED_FROM]->(:Supplier {name, country})
-[:SHIPPED_VIA]->(:Shipment {trackingNo, shippedAt})
(:Component)-[:PROCESSED_BY]->(:Facility {name, location})
```

追溯查询：
```cypher
MATCH path = (p:Product {batchNo: "B-001"})-[:CONTAINS*1..5]-(end)
RETURN path
```
