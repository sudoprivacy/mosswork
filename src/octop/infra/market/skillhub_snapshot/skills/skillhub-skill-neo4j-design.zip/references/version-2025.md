# Neo4j CalVer (2025+) 深度版本特性

> 加载时机：Step 0 版本检查时自动加载（本文件版本 ≤ 用户目标版本时加载）。

---

## 2026.03 (2026-04-08)

- **Path Modes**：`MATCH p = (a)-/->(b)` 匹配任意方向路径，`{mode: "walk"}`（无重复节​点）、`{mode: "trail"}`（无重复边）、`{mode: "simple"}`（无重复节点除首尾）。 → 图遍历算法直接在 Cypher 中表达；无需 APOC 路径扩展过程。[[ref]](https://neo4j.com/docs/cypher-manual/current/patterns/)

- **`PROPERTY_EXISTS` Predicate**：`WHERE PROPERTY_EXISTS(n, 'email')` 取代 `WHERE n.email IS NOT NULL`（语义更精确，排除 Null 属性值误判）。 → 属性存在性检查与 Null 值检查分离。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/where/)

---

## 2026.02 (2026-03)

- **Cypher 25 Default for New Databases**：新建数据库默认使用 Cypher 25 语法，老数据库通过配置保持兼容。 → 新项目直接使用 Cypher 25 语法（`WHEN`/`FILTER`/`LET`/`NEXT`），不需要迁移步骤。[[ref]](https://neo4j.com/docs/upgrade-migration-guide/current/version-2025-2026/upgrade/)

- **Multi-Label Vector Index**：`CREATE VECTOR INDEX idx_multi FOR (n:Product:Article) ON (n.embedding)` 单个索引覆盖多标签。 → 多态节点（同一向量空间但不同标签）共享索引，减少内存占用。[[ref]](https://neo4j.com/docs/cypher-manual/current/indexes-for-vector-search/)

- **Multi-Rel-Type Vector Index**：同一条向量索引覆盖多种关系类型。 → 异构关系（如 `SIMILAR_TO`、`RELATED_TO`）的向量搜索统一管理。[[ref]](https://neo4j.com/docs/cypher-manual/current/indexes-for-vector-search/)

- **`ALTER CURRENT GRAPH TYPE`（Preview）**：声明式管理属性图类型、三元组、路径模式。 → 在同一个数据库内管理多种图数据模型而无需重启。[[ref]](https://neo4j.com/docs/upgrade-migration-guide/current/version-2025-2026/upgrade/)

---

## 2026.01 (2026-01)

- **`SEARCH` Subclause in MATCH**：`MATCH (n:Product) CALL (n) SEARCH ON (n.embedding, $queryVector, 10) RETURN n` 在 MATCH 内直接执行向量相似度搜索，结合图遍历过滤。 → GraphRAG 模式原生支持：向量搜索 + 图遍历在单条查询中完成。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/call-subquery/)

---

## 2025.12 (2025-12)

- **Dynamic Label/Rel-Type Property Index Support**：运行时解析的标签/关系类型可使用属性索引（此前只支持静态已知标签）。 → 动态 Schema 场景（多租户标签模式、泛型图遍历）不再退化全图扫描。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/match/)

- **`bad-tolerance` Default to -1**：`LOAD CSV` 和 `neo4j-admin database import` 默认容忍无限错误行。 → 批量导入不再因少量坏行中断；需关注导入后数据质量。[[ref]](https://neo4j.com/docs/operations-manual/current/tools/import/)

---

## 2025.11 (2025-11)

- **8 New Collection Functions**：`coll.distinct()`、`coll.flatten()`、`coll.sort()`、`coll.sortDescending()`、`coll.shuffle()`、`coll.reverse()`、`coll.unique()`、`coll.duplicates()`。 → 图遍历结果列表的清洗/排序/去重直接在 Cypher 中完成，不再用 APOC 或应用层处理。[[ref]](https://neo4j.com/docs/cypher-manual/current/functions/collection/)

- **GenAI Plugin**：`ai.text.embed(text, model)`、`ai.text.embedBatch(texts, model)`、`ai.text.completion(prompt, model)` 原生调用 OpenAI / Azure OpenAI / VertexAI / Bedrock。 → 图内 Embedding 生成无需外部 Python 服务；GraphRAG 数据管道在 Cypher 中端到端实现。[[ref]](https://neo4j.com/docs/cypher-manual/current/genai-integration/)

- **`MergeInto` & `MergeUniqueNode` Planner Operators**：`MERGE` 语句拆分为专用计划算子，减少锁竞争。 → 高并发 MERGE 场景（实时插入+去重）吞吐提升明显。[[ref]](https://neo4j.com/docs/cypher-manual/current/execution-plans/)

---

## 2025.10 (2025-10)

- **Native `VECTOR` Value Type**：`CREATE (n:Product {embedding: vector([0.1, 0.2, ...])})`，向量作为一等公民类型存储。`VECTOR` 属性类型约束确保维度一致。 → 不再依赖 `LIST<FLOAT>` 存向量；类型安全、索引兼容。[[ref]](https://neo4j.com/docs/cypher-manual/current/values-and-types/property-structural-constructed/#vector-type)

- **Vector Functions**：`vector_dimension_count(v)` 取维度、`vector_distance(v1, v2, "COSINE")` 计算距离、`vector_norm(v)` 归一化。 → 向量操作标准化；距离计算不依赖索引。[[ref]](https://neo4j.com/docs/cypher-manual/current/functions/vector/)

---

## 2025.06 (2025-06)

- **Cypher 25 — `WHEN`/`ELSE` Conditional Queries**：`WHEN condition THEN query ELSE otherQuery END` 条件分支查询。 → 按条件执行不同 Cypher 路径，不用应用层 if/else 拼接。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/conditional/)

- **Cypher 25 — `FILTER` Clause**：`MATCH (n) FILTER n.age > 18 RETURN n`，`WHERE` 的替代语法，与 SQL 风格更接近。 → SQL 开发者迁移更直观。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/filter/)

- **Cypher 25 — `LET` Clause**：`LET x = n.age * 2` 中间变量绑定，在 `WITH` 之前赋值。 → 复杂表达式在管道中间可读性更好。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/let/)

- **Cypher 25 — `NEXT` Keyword**：`RETURN a NEXT RETURN b` 顺序执行多个查询。 → 写后读一致性在同一事务内保持。[[ref]](https://neo4j.com/docs/cypher-manual/current/clauses/next/)

---

## 2025.01 (2025-01)

- **Java 21 Required**：不再支持 Java 17，插件/扩展编译目标切换到 Java 21。 → 使用 Neo4j Java API 的应用必须升级 JDK。[[ref]](https://neo4j.com/docs/operations-manual/current/installation/requirements/)

- **Discovery Service v2 Only**：v1 发现协议移除，集群节点发现统一用 v2。 → 升级前检查 `dbms.cluster.discovery.api_version=2`。[[ref]](https://neo4j.com/docs/operations-manual/current/clustering/)

- **debug.log JSON Format Default**：调试日志默认 JSON，结构化日志便于日志聚合系统解析。 → 原有的纯文本格式需要显式配置。[[ref]](https://neo4j.com/docs/operations-manual/current/monitoring/logging/)

---
