---
name: skillhub-skill-bili-download-tool
description: "下载 B 站视频/音频到本地。给链接（bilibili.com/video/BV...、b23.tv 短链）、BV 号，或 UP 主/收藏夹/多P合集链接，自动下成 mp4。默认 H.264 编码保证任何播放器都能打开，支持 1080P/720P/480P/仅音频 MP3、可选字幕 srt、可选读取浏览器登录态拿 1080P+。当用户想下载/保存 B 站视频、要 BV 号的视频文件、把 B 站视频转 MP3、或要 B 站字幕时使用。Triggers: download a Bilibili video, save bilibili video, bilibili to mp3, bilibili subtitles."
---

# B站视频下载器

## Overview

一条命令把 B 站视频落到本地，底下走 `yt-dlp`（B 站解析最靠谱的开源实现），外面包了一层
处理过兼容性坑的 CLI：

- 默认 **H.264 编码**——B 站同一清晰度会同时给 `avc1`/`hvc1`/`av01` 三版，yt-dlp 原生排序
  偏好 AV1（体积小），但 KMPlayer 经典版、部分电视盒子/车机解不了 AV1，会报「编码有问题」。
- 分辨率按**长边**过滤（`width<=1920 AND height<=1920`）——竖屏 1080P 是 1080×1920，
  用 `height<=1080` 会把竖屏视频整个筛掉，掉到 480P。
- 下载完用 `ffprobe` **实测**成品编码与分辨率，和期望不符会明确告警，不会让你以为下对了。

细节与排查见 `references/codec-and-formats.md`，日常使用不需要读。

> ⚠️ 仅下载用户有权保存的内容（自己投稿的、UP 主授权/公开允许下载的、个人学习存档）。
> 不要用于搬运、二次分发或商用他人作品。B 站《用户协议》对下载有明确限制。

## When to use

- 用户给出 B 站链接 / BV 号 / b23.tv 短链，说要下载、保存、存本地。
- 用户要把 B 站视频转成 MP3（听音频、做素材）。
- 用户要 B 站视频的字幕（srt）。
- 用户要下整个合集、UP 主投稿列表、收藏夹。

## 快速开始

脚本在 `<本 skill>/scripts/` 下。先确认环境：

```bash
python scripts/bili_doctor.py
```

输出全绿就可以下。任一项标 ✗ 按提示修，再回来。

```bash
# 最常用：1080P + H.264，存到 ./downloads
python scripts/bili_dl.py "https://www.bilibili.com/video/BV1xxxxxxxxx"

# 只要音频（mp3 192k）
python scripts/bili_dl.py "BV1xxxxxxxxx" -q audio

# 带字幕（需要登录态，见下）
python scripts/bili_dl.py "BV1xxxxxxxxx" --subs --cookies-from edge

# 整个合集 / UP 主列表
python scripts/bili_dl.py "https://space.bilibili.com/123456/video" --all

# 机器可读结果（AI 内部调用推荐加这个）
python scripts/bili_dl.py "BV1xxxxxxxxx" --json --quiet
```

`python` 不可用时换 `python3`。脚本只依赖 Python 标准库，**不需要 pip 装任何东西**；
真正干活的是系统里的 `yt-dlp` 可执行文件。

## 工作流

### 1. 先自检（首次 / 报错时）

```bash
python scripts/bili_doctor.py
```

四项都绿再往下：`yt-dlp`、`FFmpeg`、`ffprobe`、B 站接口连通性。

### 2. 确定参数

| 用户说法 | 用哪个参数 |
|---|---|
| 没说清晰度 | 默认 `-q 1080` 即可 |
| 「最高画质 / 原画」 | `-q best`（注意体积大，且通常需要登录） |
| 「小一点 / 够看就行」 | `-q 720` 或 `-q 480` |
| 「只要声音 / 转 mp3」 | `-q audio` |
| 「播放器打不开 / 编码有问题」 | 保持默认 `-c h264`，这是最兼容的 |
| 「文件太大」 | `-c av1`（体积约省一半，但需较新播放器） |

### 3. 执行并交付

```bash
python scripts/bili_dl.py "<链接>" -o "<输出目录>" --json --quiet
```

- 不带 `--json` 时打印人类可读进度；`--json` 时 stdout 是结构化结果，适合解析。
- 结果里 `filepath` 是成品绝对路径，`video_codec` / `width` / `height` 是 ffprobe **实测**值。
- 出现 `warning` 字段要转告用户（典型是「只拿到 480P，需要登录」）。
- 下载完成后用 present_files 把成品文件给用户。

### 4. 结果判读

| 现象 | 含义 | 怎么做 |
|---|---|---|
| `ok: true`，无 warning | 完全成功 | 交付 |
| `ok: true` + `warning` | 下到了，但清晰度低于期望 | 加 `--cookies-from edge` 重下 |
| `ok: false`，`error` 含「非 B 站链接」 | 链接不对 | 让用户重发 |
| `ok: false`，`error` 含 `Unsupported URL` | URL 形态不认识（如动态、专栏） | 要视频页链接 |

## 命令参数速查

```
bili_dl.py <链接...> [-o 目录] [-q best|1080|720|480|audio]
           [-c h264|av1|h265|any] [--subs]
           [--cookies-from edge|chrome|firefox|brave] [--cookies-file 路径]
           [--all] [--json] [--quiet]
```

- 多个链接可一次传，逐个下载。
- `-o` 默认 `./downloads`。
- `--all`：链接指向 UP 主/收藏夹/合集时下载全部。带 `?p=N` 的链接会自动只下第 N 个分P。
- 退出码：`0` 成功 / `1` 下载失败 / `2` 环境缺失 / `3` URL 无效。

## 登录态（拿 1080P+ 与字幕）

B 站未登录通常只给到 720P，1080P 及以上和字幕接口都需要登录。

```bash
# 从浏览器读（推荐）
python scripts/bili_dl.py "<链接>" --cookies-from edge

# 或用导出的 cookies.txt（Netscape 格式）
python scripts/bili_dl.py "<链接>" --cookies-file "C:/path/cookies.txt"
```

注意：

- 读取浏览器 cookie 时**浏览器最好先关掉**，Chrome/Edge 新版会用 DPAPI 加密，
  占用中可能读不到。
- **读取成功不等于拿到了登录态**：如果那个浏览器根本没登录 B 站，读出来是 0 条。
  判断依据是下载结果的实际清晰度，不是命令有没有报错。
- Chrome 自 v127 起对 cookie 加了额外保护，`--cookies-from chrome` 有可能失败。
  失败就换 Edge/Firefox，或用 cookies.txt（最稳）。
- cookies.txt 是个人凭证，不要上传、不要外发、不要写进代码仓库。

## 失败处理

| 现象 | 原因 | 处理 |
|---|---|---|
| `未找到 yt-dlp` | 环境缺 | `python -m pip install -U yt-dlp`，或设 `YTDLP_PATH` |
| `未找到 FFmpeg` | B 站音视频分流，必须合并 | 装 FFmpeg 并加进 PATH，或设 `FFMPEG_PATH` |
| `Requested format is not available` | 该视频没有这个清晰度/编码 | 改 `-q best` 或 `-c any` 重试 |
| `HTTP 403` / `Forbidden` | 需要登录或链接过期 | 加 `--cookies-from edge` |
| `This video is unavailable` | 视频被删/区限制/付费 | 告知用户，无法绕过 |
| 只有 480P | 未登录 | 加 `--cookies-from edge` |
| 字幕没下到 | 字幕需登录，且并非所有视频有字幕 | 先加 `--cookies-from edge`；仍无则视频本身无字幕 |
| 下载很慢 / 卡住 | 网络或分片问题 | 脚本已设 `--concurrent-fragments 4`、`--socket-timeout 30` 与重试 10 次；仍慢可换网络 |
| `Read timed out` + `mcdn.bilivideo.cn` | **B 站 PCDN 节点故障**，不是网络断了 | 删掉输出目录里的 `.part` 文件后重跑，会重新分配节点。同一视频换个时间下通常就好了 |
| 输出 `Deprecated Feature: Support for Python version 3.10` | yt-dlp 官方已弃用 3.10 运行时 | 与下载无关，脚本已过滤。长期建议用 Python 3.11+ 环境重装 yt-dlp |
| 解析突然全失败 | **yt-dlp 版本过旧**，B 站改了接口 | `python -m pip install -U yt-dlp` 后重试 |

最后一条是这类工具最常见的长期故障：B 站接口变动频繁，yt-dlp 通常几天内就会跟进修复。
遇到「昨天还能下今天全挂」，先升级 yt-dlp，不用怀疑脚本。

## 权限与隐私

- **联网域名**：仅 B 站官方域名（`bilibili.com`、`b23.tv`、`api.bilibili.com`、
  以及 B 站 CDN 的 `*.bilivideo.com` / `*.hdslb.com`）。无第三方服务器、无遥测。
- **本地存储**：输出目录里的视频/音频/字幕文件，以及 yt-dlp 自己的缓存。
- **凭证**：`--cookies-from` 只读取本机浏览器数据库，不落盘、不上传；
  `--cookies-file` 由用户自行保管，脚本只读不写。
- **系统权限**：网络访问、本地文件写入。不修改系统设置、不注册服务、不写注册表。

## Resources

- `scripts/bili_dl.py` — 主下载脚本（单视频 / 合集 / 字幕 / 音频 / JSON 输出）。
- `scripts/bili_doctor.py` — 环境自检（yt-dlp、FFmpeg、ffprobe、连通性、浏览器登录源）。
- `references/codec-and-formats.md` — 编码与分辨率的坑位说明、格式串推导、实测数据；
  仅当用户反馈「打不开 / 清晰度不对」或需要改脚本逻辑时读。
