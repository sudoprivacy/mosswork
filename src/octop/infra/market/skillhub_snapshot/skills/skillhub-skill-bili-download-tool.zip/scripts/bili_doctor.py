#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B 站下载器环境自检。

排查顺序按「最容易出问题的先查」：
yt-dlp 是否找到 → 版本是否过旧 → FFmpeg → B站连通性 → 登录态来源。

输出人可读报告；加 --json 输出机器可读结果。
退出码：0 一切正常 / 1 存在会阻断下载的问题
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from bili_dl import find_ffmpeg, find_ffprobe, find_ytdlp, ytdlp_version  # noqa: E402

BROWSERS = {
    "edge": [
        Path("C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"),
        Path("C:/Program Files/Microsoft/Edge/Application/msedge.exe"),
    ],
    "chrome": [
        Path("C:/Program Files/Google/Chrome/Application/chrome.exe"),
        Path("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"),
    ],
    "firefox": [Path("C:/Program Files/Mozilla Firefox/firefox.exe")],
    "brave": [Path("C:/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe")],
}


def check_bilibili() -> tuple[bool, str]:
    """探一下公开接口，确认网络与站点可达。"""
    url = "https://api.bilibili.com/x/web-interface/popular?ps=1&pn=1"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
        code = data.get("code")
        if code == 0:
            return True, "接口正常"
        return False, f"接口返回 code={code} {data.get('message', '')}"
    except urllib.error.URLError as e:
        return False, f"连接失败：{e.reason}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def ffmpeg_version(exe: str) -> str:
    try:
        r = subprocess.run([exe, "-version"], capture_output=True, timeout=20,
                           encoding="utf-8", errors="replace")
        first = (r.stdout or "").splitlines()
        return first[0].strip() if first else "未知"
    except Exception:
        return "无法执行"


def main() -> int:
    as_json = "--json" in sys.argv
    problems: list[str] = []
    report: dict = {
        "system": {
            "os": platform.platform(),
            "python": sys.version.split()[0],
            "arch": platform.machine(),
        }
    }

    # 1. yt-dlp
    ytdlp = find_ytdlp()
    if ytdlp:
        ver = ytdlp_version(ytdlp)
        report["ytdlp"] = {"found": True, "command": " ".join(ytdlp), "version": ver}
    else:
        report["ytdlp"] = {"found": False}
        problems.append("未找到 yt-dlp。安装：python -m pip install -U yt-dlp")

    # 2. FFmpeg
    ffmpeg = find_ffmpeg()
    if ffmpeg:
        report["ffmpeg"] = {"found": True, "path": ffmpeg, "version": ffmpeg_version(ffmpeg)}
        ffprobe = find_ffprobe(ffmpeg)
        report["ffprobe"] = {"found": bool(ffprobe), "path": ffprobe}
        if not ffprobe:
            problems.append("找到 ffmpeg 但没有 ffprobe，下载后无法校验编码（不影响下载本身）")
    else:
        report["ffmpeg"] = {"found": False}
        problems.append("未找到 FFmpeg，B 站视频无法合并（音视频分流）。")

    # 3. B站连通性
    ok, msg = check_bilibili()
    report["bilibili"] = {"reachable": ok, "message": msg}
    if not ok:
        problems.append(f"B 站接口不通：{msg}（检查网络/代理）")

    # 4. 登录态来源
    found_browsers = [name for name, paths in BROWSERS.items()
                      if any(p.is_file() for p in paths)]
    report["cookie_sources"] = {
        "browsers": found_browsers,
        "note": "1080P 及以上通常需要登录态；也可用 --cookies-file 指定 cookies.txt",
    }
    if not found_browsers:
        report["cookie_sources"]["note"] = (
            "未检测到常见浏览器，只能用 --cookies-file 提供 cookies.txt（1080P+ 需要）"
        )

    report["problems"] = problems
    report["ok"] = not problems

    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("=" * 56)
        print("B 站下载器 · 环境自检")
        print("=" * 56)
        s = report["system"]
        print(f"系统      {s['os']}  ({s['arch']})")
        print(f"Python    {s['python']}  (仅自检用，下载不依赖它)")

        y = report["ytdlp"]
        if y["found"]:
            print(f"yt-dlp    ✓ {y['version']}")
            print(f"           {y['command']}")
        else:
            print("yt-dlp    ✗ 未找到")

        f = report["ffmpeg"]
        if f["found"]:
            print(f"FFmpeg    ✓ {f['version'][:64]}")
            print(f"           {f['path']}")
        else:
            print("FFmpeg    ✗ 未找到")

        p = report["ffprobe"]
        print(f"ffprobe   {'✓ 已就绪' if p.get('found') else '✗ 缺失（仅影响编码校验）'}")

        b = report["bilibili"]
        print(f"B站连通   {'✓ ' + b['message'] if b['reachable'] else '✗ ' + b['message']}")

        cs = report["cookie_sources"]["browsers"]
        print(f"登录态源   {'、'.join(cs) if cs else '无浏览器'}")

        print("-" * 56)
        if problems:
            print("需要处理：")
            for i, item in enumerate(problems, 1):
                print(f"  {i}. {item}")
        else:
            print("一切正常，可以下载。")
        print("=" * 56)

    return 0 if not problems else 1


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
            sys.stderr.reconfigure(encoding="utf-8")
        except Exception:
            pass
    sys.exit(main())
