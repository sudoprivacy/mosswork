#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""B站视频下载 CLI —— 供 AI 技能调用。

设计要点：
1. 用 subprocess 调 yt-dlp，而不是 import yt_dlp。
   因为本机可能有多个 Python，装 yt-dlp 的往往不是默认那个，
   调可执行文件能绕开解释器环境问题。
2. 默认编码 H.264。B 站每个清晰度同时提供 avc1/hvc1/av01，
   yt-dlp 默认排序会选 AV1，旧播放器（KMPlayer 经典版等）打不开。
3. 分辨率用「长边」表达（width<=1920 AND height<=1920），
   因为竖屏 1080P 是 1080x1920，用 height<=1080 会把竖屏整个筛掉。
   这两个坑都是实测踩出来的，详见 references/codec-and-formats.md。

退出码：0 成功 / 1 下载失败 / 2 环境缺失 / 3 URL 无效
"""

from __future__ import annotations

import argparse
import itertools
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

# ---------------- 常量 ----------------

RESOLUTION_FILTERS = {
    "best": "",
    "1080": "[width<=1920][height<=1920]",
    "720": "[width<=1280][height<=1280]",
    "480": "[width<=854][height<=854]",
}

CODEC_FILTERS = {
    "h264": "[vcodec^=avc1]",
    "av1": "[vcodec^=av01]",
    "h265": "[vcodec^=hvc1]",
    "any": "",
}

CODEC_LABEL = {"h264": "H.264", "av1": "AV1", "h265": "H.265", "any": "任意"}

BILI_HOSTS = ("bilibili.com", "b23.tv")
BV_RE = re.compile(r"^(BV[0-9A-Za-z]{10})$", re.IGNORECASE)
AV_RE = re.compile(r"^av(\d+)$", re.IGNORECASE)

# 只有含这些特征的 URL 才当「列表」处理（UP主/收藏夹/合集）
PLAYLIST_HINTS = (
    "/medialist/", "/favlist", "/space/", "/series/",
    "?sid=", "&sid=", "?fid=", "&fid=", "/list/",
)

META_TMPL = (
    "##META##"
    "%(id)s\t%(title)s\t%(uploader)s\t%(duration)s\t"
    "%(format_id)s\t%(vcodec)s\t%(width)s\t%(height)s"
)
FILE_TMPL = "after_move:##FILE##%(filepath)s"


# ---------------- 环境探测 ----------------

def _try_version(cmd: list[str]) -> bool:
    try:
        r = subprocess.run(
            cmd + ["--version"], capture_output=True, timeout=25,
            encoding="utf-8", errors="replace",
        )
        return r.returncode == 0
    except Exception:
        return False


def find_ytdlp() -> list[str] | None:
    """返回可直接执行的 yt-dlp 命令前缀，找不到返回 None。

    优先级：YTDLP_PATH 环境变量 > PATH 里的 yt-dlp > 各 Python 的 -m yt_dlp。
    """
    env = os.environ.get("YTDLP_PATH")
    if env and Path(env).is_file():
        return [env]

    hit = shutil.which("yt-dlp")
    if hit and _try_version([hit]):
        return [hit]

    # 常见 Python 安装位置下的 Scripts/yt-dlp.exe
    roots = [
        Path.home() / "AppData/Local/Programs/Python",
        Path("C:/Program Files/Python"),
        Path("C:/Python"),
        Path.home() / "AppData/Local/Programs/Python/Python310",
    ]
    seen: set[str] = set()
    for root in roots:
        if not root.is_dir():
            continue
        for exe in root.glob("**/Scripts/yt-dlp.exe"):
            key = str(exe).lower()
            if key in seen:
                continue
            seen.add(key)
            if _try_version([str(exe)]):
                return [str(exe)]

    # 最后退回解释器模块方式
    for py in ("python", "python3", sys.executable):
        if not py:
            continue
        if _try_version([py, "-m", "yt_dlp"]):
            return [py, "-m", "yt_dlp"]
    return None


def ytdlp_version(cmd: list[str]) -> str:
    try:
        r = subprocess.run(cmd + ["--version"], capture_output=True, timeout=25,
                           encoding="utf-8", errors="replace")
        return r.stdout.strip().splitlines()[0] if r.stdout.strip() else "未知"
    except Exception:
        return "未知"


def find_ffmpeg() -> str | None:
    env = os.environ.get("FFMPEG_PATH")
    if env and Path(env).is_file():
        return env
    hit = shutil.which("ffmpeg")
    if hit:
        return hit
    for p in (
        Path("C:/ffmpeg/bin/ffmpeg.exe"),
        Path("C:/ffmpeg/ffmpeg.exe"),
        Path.home() / "AppData/Local/Programs/ffmpeg/bin/ffmpeg.exe",
    ):
        if p.is_file():
            return str(p)
    return None


def find_ffprobe(ffmpeg: str | None) -> str | None:
    hit = shutil.which("ffprobe")
    if hit:
        return hit
    if ffmpeg:
        sibling = Path(ffmpeg).with_name("ffprobe.exe" if os.name == "nt" else "ffprobe")
        if sibling.is_file():
            return str(sibling)
    return None


# ---------------- URL 处理 ----------------

def normalize_url(raw: str) -> str:
    s = raw.strip().strip("'\"")
    if BV_RE.match(s):
        return f"https://www.bilibili.com/video/{s}"
    if AV_RE.match(s):
        return f"https://www.bilibili.com/video/{s}"
    if s.startswith("//"):
        s = "https:" + s
    if not re.match(r"^[a-zA-Z]+://", s):
        s = "https://" + s
    return s


def is_bilibili(url: str) -> bool:
    try:
        host = (urlparse(url).netloc or "").lower().split(":")[0]
    except Exception:
        return False
    return any(host == h or host.endswith("." + h) for h in BILI_HOSTS)


def detect_playlist(url: str) -> tuple[bool, str | None]:
    """返回 (是否列表, 分P序号)。"""
    m = re.search(r"[?&]p=(\d+)", url)
    if m:
        return True, m.group(1)
    if any(k in url for k in PLAYLIST_HINTS):
        return True, None
    return False, None


def build_format_string(quality: str, codec: str) -> str:
    """拼 yt-dlp 的 -f 表达式。

    先试「指定编码 + 分辨率限制」，再退回「只限分辨率」，最后兜底 b。
    双重回退是必要的：某些老视频没有 avc1 版本，硬卡编码会直接失败。
    """
    if quality == "audio":
        return "ba/b"
    limit = RESOLUTION_FILTERS.get(quality, "")
    preferred = CODEC_FILTERS.get(codec, "")
    if preferred:
        return f"bv*{preferred}{limit}+ba/bv*{limit}+ba/b"
    return f"bv*{limit}+ba/b"


# ---------------- 下载 ----------------

def build_cmd(
    ytdlp: list[str],
    url: str,
    outdir: Path,
    fmt: str,
    *,
    ffmpeg: str | None,
    subs: bool,
    cookies_from: str | None,
    cookies_file: str | None,
    playlist_mode: str,
    playlist_items: str | None,
    quiet: bool,
) -> list[str]:
    cmd = ytdlp + [
        url,
        "-f", fmt,
        "-o", str(outdir / "%(title).150B [%(id)s].%(ext)s"),
        "--merge-output-format", "mp4",
        "--windows-filenames",
        "--newline",
        "--no-warnings",
        "--no-simulate",
        "--retries", "10",
        "--fragment-retries", "10",
        "--socket-timeout", "30",
        "--concurrent-fragments", "4",
        "--print", META_TMPL,
        "--print", FILE_TMPL,
    ]

    if fmt == "ba/b":
        cmd += ["--extract-audio", "--audio-format", "mp3", "--audio-quality", "192K"]

    if subs:
        cmd += [
            "--write-subs", "--write-auto-subs",
            "--sub-langs", "zh-Hans,zh-CN,zh,ai-zh",
            "--convert-subs", "srt",
        ]

    # 列表处理：--no-playlist 只下当前视频；分P 用 --playlist-items 精确指定
    if playlist_mode == "all":
        if playlist_items:
            cmd += ["--playlist-items", playlist_items]
    else:
        cmd += ["--no-playlist"]

    if cookies_from:
        cmd += ["--cookies-from-browser", cookies_from]
    if cookies_file:
        cmd += ["--cookies", cookies_file]

    if ffmpeg:
        cmd += ["--ffmpeg-location", str(Path(ffmpeg).parent)]

    if quiet:
        cmd += ["--quiet", "--no-progress"]
    return cmd


def run_download(cmd: list[str], quiet: bool) -> tuple[int, list[dict[str, str]], list[str], list[str]]:
    """执行下载，返回 (退出码, 元信息列表, 文件路径列表, 原始日志)。"""
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"

    metas: list[dict[str, str]] = []
    files: list[str] = []
    logs: list[str] = []

    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", env=env, bufsize=1,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip("\n")
        if line.startswith("##META##"):
            parts = line[len("##META##"):].split("\t")
            keys = ["id", "title", "uploader", "duration",
                    "format_id", "vcodec", "width", "height"]
            metas.append(dict(zip(keys, parts + [""] * (len(keys) - len(parts)))))
            continue
        if line.startswith("##FILE##"):
            files.append(line[len("##FILE##"):])
            continue
        if line.strip():
            # yt-dlp 用 Python 3.10 打包时会打印弃用警告，与下载无关，别混进错误信息
            if line.startswith("Deprecated Feature:"):
                continue
            logs.append(line)
            if not quiet:
                print(line, file=sys.stderr, flush=True)
    proc.wait()
    return proc.returncode, metas, files, logs


def probe_file(ffprobe: str | None, path: str) -> dict[str, Any]:
    if not ffprobe or not Path(path).is_file():
        return {}
    try:
        r = subprocess.run(
            [ffprobe, "-v", "error", "-show_entries",
             "stream=codec_name,codec_type,width,height:format=duration,size",
             "-of", "json", path],
            capture_output=True, timeout=60, encoding="utf-8", errors="replace",
        )
        data = json.loads(r.stdout or "{}")
    except Exception:
        return {}

    out: dict[str, Any] = {}
    for st in data.get("streams", []):
        if st.get("codec_type") == "video" and "video_codec" not in out:
            out["video_codec"] = st.get("codec_name")
            out["width"] = st.get("width")
            out["height"] = st.get("height")
        elif st.get("codec_type") == "audio" and "audio_codec" not in out:
            out["audio_codec"] = st.get("codec_name")
    fmt = data.get("format", {})
    if fmt.get("size"):
        out["filesize"] = int(fmt["size"])
    if fmt.get("duration"):
        out["duration"] = float(fmt["duration"])
    return out


# ---------------- 主流程 ----------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="B站视频下载（CLI）。默认下载 H.264 编码，兼容性最好。",
    )
    ap.add_argument("urls", nargs="+", help="视频链接 / BV 号 / b23.tv 短链")
    ap.add_argument("-o", "--output", default="./downloads", help="保存目录（默认 ./downloads）")
    ap.add_argument("-q", "--quality", default="1080", choices=list(RESOLUTION_FILTERS) + ["audio"],
                    help="清晰度：best/1080/720/480/audio（默认 1080）")
    ap.add_argument("-c", "--codec", default="h264", choices=list(CODEC_FILTERS),
                    help="编码：h264(默认,最兼容)/av1(体积最小)/h265/any")
    ap.add_argument("--subs", action="store_true", help="同时下载字幕（srt）")
    ap.add_argument("--cookies-from", default=None, choices=["edge", "chrome", "firefox", "brave"],
                    help="从浏览器读取登录态（1080P+ 通常需要）")
    ap.add_argument("--cookies-file", default=None, help="使用 cookies.txt 文件")
    ap.add_argument("--all", action="store_true", help="下载整个列表（UP主/收藏夹/多P合集）")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出结果")
    ap.add_argument("--quiet", action="store_true", help="不打印下载进度")
    args = ap.parse_args()

    ytdlp = find_ytdlp()
    if not ytdlp:
        print("错误：未找到 yt-dlp。安装：python -m pip install -U yt-dlp", file=sys.stderr)
        return 2

    ffmpeg = find_ffmpeg()
    if not ffmpeg:
        # B 站几乎全部走 DASH 分流（音视频分开），没有 FFmpeg 无法合并/转码
        print("错误：未找到 FFmpeg。B 站音视频分流，合并高画质与转 MP3 都需要它。\n"
              "  安装后重试，或设 FFMPEG_PATH 环境变量指向 ffmpeg.exe。",
              file=sys.stderr)
        return 2

    # 先校验链接再建目录，避免无效链接也留下一个空文件夹
    results: list[dict[str, Any]] = []
    overall_ok = True
    valid_urls: list[str] = []
    for raw in args.urls:
        url = normalize_url(raw)
        if is_bilibili(url):
            valid_urls.append(url)
        else:
            print(f"错误：不是 B 站链接 —— {raw}", file=sys.stderr)
            results.append({"url": raw, "ok": False, "error": "非 B 站链接"})
            overall_ok = False

    if not valid_urls:
        if args.json:
            print(json.dumps({"ok": False, "items": results}, ensure_ascii=False, indent=2))
        return 3

    outdir = Path(args.output).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    ffprobe = find_ffprobe(ffmpeg)

    for url in valid_urls:

        is_list, p_index = detect_playlist(url)
        if args.all:
            # 显式 --all 时按整个列表下，忽略 URL 里的 ?p=N
            playlist_mode, p_index = "all", None
        else:
            playlist_mode = "all" if is_list else "single"

        fmt = build_format_string(args.quality, args.codec)
        cmd = build_cmd(
            ytdlp, url, outdir, fmt,
            ffmpeg=ffmpeg, subs=args.subs,
            cookies_from=args.cookies_from, cookies_file=args.cookies_file,
            playlist_mode=playlist_mode, playlist_items=p_index,
            quiet=args.quiet,
        )

        if not args.quiet:
            print(f"→ {url}", file=sys.stderr)
            print(f"  清晰度 {args.quality} / 编码 {CODEC_LABEL[args.codec]} / 格式串 {fmt}", file=sys.stderr)

        code, metas, files, logs = run_download(cmd, args.quiet)

        # 字幕文件：与成品视频同名，后缀 .srt
        srt_files: list[str] = []
        if args.subs:
            for f in files:
                stem = Path(f).stem
                srt_files += [str(p) for p in outdir.glob(f"{stem}*.srt")]

        # 一个视频都没下到且退出码非 0 → 失败
        if code != 0 and not files:
            err = "\n".join(logs[-6:]) if logs else f"yt-dlp 退出码 {code}"
            if "Read timed out" in err or "mcdn.bilivideo.cn" in err:
                err += (
                    "\n【提示】这是 B 站 PCDN 节点故障（不是网络断了）。"
                    "删掉输出目录里对应的 .part 文件后重跑，通常会重新分配到可用节点。"
                )
            results.append({"url": url, "ok": False, "error": err})
            overall_ok = False
            continue

        pairs = list(itertools.zip_longest(metas, files or [], fillvalue=None))
        for meta, fp in pairs:
            meta = meta or {}
            info: dict[str, Any] = {
                "url": url,
                "ok": True,
                "id": meta.get("id"),
                "title": meta.get("title"),
                "uploader": meta.get("uploader"),
                "format_id": meta.get("format_id"),
                "vcodec_reported": meta.get("vcodec"),
                "filepath": fp,
            }
            if meta.get("duration") and meta["duration"] not in ("NA", "None"):
                try:
                    info["duration_sec"] = int(float(meta["duration"]))
                except ValueError:
                    pass

            probed = probe_file(ffprobe, fp) if fp else {}
            if probed:
                info["video_codec"] = probed.get("video_codec")
                info["audio_codec"] = probed.get("audio_codec")
                info["width"] = probed.get("width")
                info["height"] = probed.get("height")
                info["filesize"] = probed.get("filesize")
                if probed.get("duration"):
                    info["duration_sec"] = int(probed["duration"])

            if srt_files:
                info["subtitles"] = srt_files
            elif args.subs:
                # 不当作失败：B 站字幕接口需要登录态，且并非所有视频都有字幕
                info["subtitle_warning"] = (
                    "没取到字幕。B 站字幕接口需要登录态；若已登录，则该视频本身无字幕。"
                )

            # 清晰度没拿到期望值 → 明确警告，别让用户以为下成功了
            want = {"1080": 1080, "720": 720, "480": 480}.get(args.quality)
            got = info.get("height")
            if want and got and isinstance(got, int) and max(got, info.get("width") or 0) < want * 0.9:
                info["warning"] = (
                    f"只拿到 {info.get('width')}x{got}，低于期望的 {want}P。"
                    "B 站 1080P 通常需要登录：加 --cookies-from edge 重试。"
                )

            results.append(info)
            if not args.quiet and fp:
                print(f"  ✓ {Path(fp).name}", file=sys.stderr)

    if args.json:
        print(json.dumps({"ok": overall_ok, "output_dir": str(outdir), "items": results},
                         ensure_ascii=False, indent=2))
    else:
        ok_n = sum(1 for r in results if r.get("ok"))
        print(f"\n完成：成功 {ok_n} / 共 {len(results)}，保存到 {outdir}")
        for r in results:
            if r.get("ok") and r.get("warning"):
                print(f"  ⚠ {r.get('title')}: {r['warning']}")
            if not r.get("ok"):
                print(f"  ✗ {r.get('url')}: {str(r.get('error'))[:200]}")

    return 0 if overall_ok else 1


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
            sys.stderr.reconfigure(encoding="utf-8")
        except Exception:
            pass
    sys.exit(main())
