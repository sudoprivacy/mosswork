---
name: skillhub-skill-greenhelix-bundle-compliance-legal
description: "Navigate the regulatory landscape for autonomous AI agents. Covers EU AI Act compliance, contract lifecycle management, agent insurance and risk pools, and tax/ledger compliance. 4 guides, $186 value."
---

# Compliance & Legal Pack: 4-Guide Collection for Agent Governance and Regulatory Compliance

## Included Guides
| Guide | Individual Price |
|-------|-----------------|
| EU AI Act Compliance for Autonomous Agents | $39.00 |
| Agent Contract Lifecycle Management | $49.00 |
| The Agent Insurance Playbook | $49.00 |
| Agent Tax & Ledger Compliance Playbook | $49.00 |

## Total Value: $186.00 | Bundle Price: $149.00
