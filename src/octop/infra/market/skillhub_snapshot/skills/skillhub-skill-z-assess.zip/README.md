# z-assess（立项评估）

一句话：在"想清楚了"与"开工"之间加一道决策闸门——评四维、登风险、验假设，落到 Go / No-Go / 有条件 Go 三选一的结论，不和稀泥。这是 SDD 工具族普遍缺失的"值不值得做"闸门。

## 何时使用

说"可行性分析、可行性研究、立项评估、项目评估、值不值得做、要不要做、该不该做、go/no-go、投入产出、风险评估、上会评审、立项报告"，或判断该不该干时触发。

## 用法速览

- 问法：「X 值不值得做？给我个 Go/No-Go」；上线就绪：「X 要上线了，评审能不能上、还缺什么」；重评：「上次评估的条件满足了，重新评一次」
- 用法卡：聊天说 `z-assess help`，ZCode 下 `/z-assess-help` 直达
- 预期：对质 1–2 轮（把最大不确定项、红灯依据、危险假设摆给你），答"不知道"如实进假设清单

## 核心机制

- **三条铁律**：结论三选一、禁止和稀泥（"有条件 Go"的条件必须可检验有期限）；不虚构数字（无据标"未量化"进决策待补）；待核 ≠ 已知（不确定信息进风险与假设，不充当证据）。
- **Gate**：评估对象必须"已定义"（一句话目标+使用方）；只有模糊想法时可粗评，但结论只能是"有条件 Go（先澄清）"或 No-Go。
- **四维可行性**：技术/经济/操作/合规与进度，每维红黄绿灯+一句结论+最大不确定项；红灯必须写明"翻绿需要什么"。
- **风险登记 + 关键假设**：top 3–5 风险（概率/影响/缓解/再评估触发）；假设按"若为假伤害最大"排序，每条给最廉价验证方式。
- **基线后（部署期）**：评二期/重构/"值不值得继续"时输入优先读 SRS、变更记录与跟踪矩阵，报告落 `docs/05-管理/变更/`，不动冻结的 `00-立项/`。

## 与 z-系列的关系

```
z-flow-kickoff（编排：开场协议→契约→横幅→交接→续跑）
   └─ z-pyramid(拆解) → z-clarify(澄清→登记册) ⇄ z-chain(生态/干系人事实)
                              ↓
                       z-assess(本 skill：四维+风险+假设 → Go/No-Go)
                              ↓ Go
                       z-init(工程文档基线化) → 下游 spec/开发（松耦合，AGENTS.md 契约）
```

上游：z-clarify 供澄清产物与登记册（不重新澄清）、z-chain 供生态事实（空缺即风险证据）、z-pyramid 供报告表达结构；下游：z-init 在 Go 后消费本报告（风险种子化、条件转里程碑前置）。分工：评估"什么维度、什么结论"是本 skill 的事，"怎么表达清楚"才是 z-pyramid 的事。整链编排见 z-flow-kickoff；六技能相互独立、按需组合，联动方未安装时按各自文内退化规则执行。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`）；更新只需 `git -C ~/z-skill-series pull`，无需重装。GitHub HTTPS 不稳时可改用 SSH。

### 单独安装（任一 agent）

把 `skills/z-assess` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装已实测可用：`npx skills add zimy0033/z-skill-series/skills/z-assess`。

## License

MIT
