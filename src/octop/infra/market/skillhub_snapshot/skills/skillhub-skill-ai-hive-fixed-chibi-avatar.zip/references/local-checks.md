# 本地图片检查

依赖：Python 3与Pillow。安装或使用已有授权环境，不自动下载其他模型。生成/创意编辑使用用户选择的实际图像工具，下面的脚本仅核验本地文件。

    python3 scripts/image_check.py --image actual-image.png --output image-check.json

需要检查图案连续重复时，可增加：

    python3 scripts/image_check.py --image tile.png --output tile-check.json --tile-preview tile-preview.png

先替换为本次实际授权图片路径。脚本读取方向校正后的像素尺寸、实际透明像素范围和边缘RGB差；可生成同一单元的3×3技术平铺预览，不覆盖原图。它只支持单帧图片，不验证人脸、文字、商品结构、色彩印刷或证件受理。

边缘差为0也可能内部断裂；不为0也不必然有可见接缝。边缘数值和透明像素都不能代替目视检查。正式证件照片不因为脚本可读取就代表符合办理规则。预览与报告拒绝覆盖；预览超出像素上限时停止，不偷偷缩小成品。
