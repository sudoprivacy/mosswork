#!/usr/bin/env python3
"""Local Pillow inspection; optional tiled technical preview, never generative editing."""
import argparse
import json
from pathlib import Path
import sys
import warnings


def inspect(path, tile_preview=None):
    try:
        from PIL import Image, ImageChops, ImageOps, ImageStat
    except ImportError:
        raise ValueError("缺少Pillow，请在已授权的Python环境安装后运行；未完成图像检查") from None
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 100_000_000:
        raise ValueError("需要不超过100MB的本地图片，拒绝符号链接")
    Image.MAX_IMAGE_PIXELS = 30_000_000
    with warnings.catch_warnings():
        warnings.simplefilter("error", Image.DecompressionBombWarning)
        with Image.open(path) as original:
            original.verify()
        with Image.open(path) as original:
            fmt = original.format
            frames = getattr(original, "n_frames", 1)
            if frames != 1:
                raise ValueError("此脚本仅检查单帧图片；动态图请用实际媒体检查工具")
            oriented = ImageOps.exif_transpose(original)
            oriented.load()
            rgba = oriented.convert("RGBA")
            extrema = rgba.getchannel("A").getextrema()
            rgb = rgba.convert("RGB")
            w, h = rgb.size
            left = rgb.crop((0, 0, 1, h))
            right = rgb.crop((w - 1, 0, w, h))
            top = rgb.crop((0, 0, w, 1))
            bottom = rgb.crop((0, h - 1, w, h))
            xmean = sum(ImageStat.Stat(ImageChops.difference(left, right)).mean) / 3
            ymean = sum(ImageStat.Stat(ImageChops.difference(top, bottom)).mean) / 3
            result = {
                "format": fmt, "width_after_orientation": w, "height_after_orientation": h,
                "decoded": True, "frames_checked": frames,
                "has_any_nonopaque_pixels": extrema[0] < 255,
                "has_any_fully_transparent_pixels": extrema[0] == 0,
                "alpha_min": extrema[0], "alpha_max": extrema[1],
                "edge_rgb_mae_left_right": round(xmean, 3),
                "edge_rgb_mae_top_bottom": round(ymean, 3),
                "seamless_verified": False, "identity_verified": False,
                "official_photo_accepted": None,
                "note": "边缘RGB差仅为辅助数值，含透明图层时尤其需目视；不能证明无缝、人物正确或证照受理。",
            }
            if tile_preview:
                target = Path(tile_preview)
                if target.exists() or target.is_symlink():
                    raise ValueError("平铺预览已存在，拒绝覆盖")
                if w * h * 9 > 30_000_000:
                    raise ValueError("3×3预览超过3000万像素，请先明确另做小尺寸技术预览")
                sheet = Image.new("RGBA", (w * 3, h * 3))
                for y in range(3):
                    for x in range(3):
                        sheet.paste(rgba, (x * w, y * h))
                with target.open("xb") as out:
                    sheet.save(out, format="PNG")
                result["tile_preview_written"] = True
            return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--image", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--tile-preview")
    ns = p.parse_args()
    output = Path(ns.output)
    if output.exists() or output.is_symlink():
        raise ValueError("报告已存在，拒绝覆盖")
    if ns.tile_preview and Path(ns.tile_preview).resolve() == output.resolve():
        raise ValueError("报告与预览不能是同一文件")
    result = inspect(ns.image, ns.tile_preview)
    with output.open("x", encoding="utf-8") as out:
        json.dump(result, out, ensure_ascii=False, indent=2)
    print(json.dumps({"decoded": True, "output_written": True}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
