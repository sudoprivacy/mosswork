---
name: skillhub-skill-bilibili-script-paid
description: "给定选题，生成 B 站风格稿（梗/节奏/互动）。当用户要B站文案、bilibili脚本、up主稿时使用。"
---

# B站文案生成器

## 谁在用 / 解决什么

- **解决什么**：生成 B 站风格稿；输出【视频稿】、【标题】、【互动设计】。
- **你会拿到**：【视频稿】、【标题】、【互动设计】，每一块都是完整内容，不是只给标题



## 触发条件

B站文案、B站文案、bilibili脚本、up主稿、B站视频、弹幕梗

## 适用 / 不适用人群

- ✅ 适用：UP 主
- ✅ 适用：知识区
- ✅ 适用：涨粉内容
- ❌ 不适用：代剪视频
- ❌ 不适用：标题党无依据

## 能力与交付

1. 收集：选题、账号调性、时长、是否有争议点。
2. 给正文（钩子→信息密度→玩梗→互动引导）+ 标题 3 选。
3. 输出：【视频稿】+【标题】+【互动设计】。

## 边界

- 交付物为文本/结构化的技能产出，不含代执行外部系统（如自动发邮件、自动剪辑）。

## 使用提示

按 B 站节奏写，不是通用稿硬套。

## 前置检查：当前智能体是否支持微信 AI 支付

本技能按次计费，通过微信支付完成结算。发起下单前，先确认你的可用工具列表中
是否存在名称包含 `weixinpay_` 的工具（如 `mcp__weixinpay__weixinpay_register`，
工具名带前缀也算；存在**任意一个**即视为支持）。判断依据只取你自己的工具列表。

- 支持：继续下面的工作流程。
- 不支持：不要发起下单。向用户说明本技能需要微信支付能力，并给出解决办法：
  - 合作智能体（如 WorkBuddy）：请升级智能体到最新版本后重试。
  - 开放智能体（如 OpenClaw / DeepSeek Harness）：请根据 https://skillhub.cn/install/skillhub.md 安装 @tencent-adm/weixinpay-installer。
  - 无法判断类型：请升级智能体或安装微信支付 AI 支付插件后重试。

## 工作流程


### 第 0 步：免费预览（先给方案骨架，不要一上来就收费）

```
POST https://api.goreportify.com/skill/preview
Content-Type: application/json

{"skill_id":"bilibili-script-paid","skill_version":"1.0.0","query":"用户的原始需求"}
```

这一步**不收费**，服务端会返回 `preview`：
`positioning`（本技能能帮你做什么）、`dimensions`（会从哪几个维度分析）、
`deliverables`（你会拿到哪几块）、`inputs`（需要你先提供什么材料）。

**必须这样做**：把返回内容整理成一段「我已经看懂你的问题、下面是我的解决思路」先展示给用户，
并明确说明付费后会多得到什么。**只有用户明确要完整定制结果时，才进入第一步走支付。**
不要在用户还没看到任何东西时就索要支付。

### 第一步：请求资源

```
POST https://api.goreportify.com/skill/invoke
Content-Type: application/json

{"skill_id":"bilibili-script-paid","skill_version":"1.0.0","query":"用户的原始需求"}
```

`query` 里带上本次需求的完整信息，越具体产出越准。

### 第二步：处理 402 响应

服务端返回 HTTP 402 时，从**响应头**提取两个值，两个都必须保存：

- `WeixinPay-Required` → 支付码
- `X-Out-Trade-No` → 商户订单号

响应体里也有同名的 `WeixinPay` 提示块，两者取一致值即可。

### 第三步：发起支付

把 `WeixinPay-Required` 的值作为 `paymentCode`，调用 `weixinpay_pay`，向用户申请支付授权。

### 第四步：支付成功后获取资源（关键一步）

```
POST https://api.goreportify.com/skill/invoke
Content-Type: application/json
X-Out-Trade-No: <第二步保存的订单号>

{"skill_id":"bilibili-script-paid","skill_version":"1.0.0","query":"与第一步一致的原始需求"}
```

**body 与第一步保持一致**，只在 Header 上追加 `X-Out-Trade-No`。
不带这个 Header 重试，就永远拿不到付费内容。

服务端验证支付成功后返回 HTTP 200，`content` 字段即本技能的付费内容。
若返回 `already_fulfilled: true`，表示该订单已履约过，直接复用已有内容，不要重复索要。

## 效果案例

**案例一 · B站文案**

输入：围绕「B站文案」的具体需求描述
输出：【视频稿】+【标题】+【互动设计】。

**案例二 · bilibili脚本**

输入：围绕「bilibili脚本」的需求，条件比案例一更复杂（参数更多、约束更紧）
输出：【视频稿】+【标题】+【互动设计】。，并针对复杂条件补充取舍说明

**案例三 · up主稿**

输入：围绕「up主稿」的需求，或落在本技能不适用范围内的请求
输出：适用则正常交付；不适用则明确说明边界并给出替代建议，不发起下单

## 幂等与异常处理

- 同一订单号重复请求直接返回原结果，不会重复扣款。
- 第四步返回 `PAYMENT_NOT_SETTLED` 表示尚未支付成功，回到第三步重新发起支付即可，**不要**重新走第一步下单。
- 缺少必要信息先向用户确认，不要猜测参数。

## 服务可用性说明

本技能依赖的服务由北京蟋蟀信息科技有限公司自建并维护，部署在自有服务器上。
调用入口即上文「工作流程」第一步中的地址，未付款时按约定返回 402，付款后同一地址重放即可获取付费内容。
服务不采集用户数据、不落库用户输入内容，仅在订单有效期内保存订单号与支付状态用于幂等判重。
