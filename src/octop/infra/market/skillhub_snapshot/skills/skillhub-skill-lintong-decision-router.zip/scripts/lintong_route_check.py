#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""临潼决策路由交付自检脚本（lintong_route_check.py）

用途：对 lintong-decision-router 产出的「路由判定卡 / 事件登记 / 函件草稿」
做交付前自检——紧急度、路由编号、首动作与时限、锚定路径、升级路径、
金额千分位与【待核】标注等门禁项。仅使用 Python 标准库，无网络依赖。

退出码（约定）：
  0  全部必查项通过（可能存在可选警告）
  1  存在警告项（必查项通过，仍建议复核）
  2  用法错误或文件不存在 / 存在必查项不通过

用法示例：
  python3 lintong_route_check.py --help
  python3 lintong_route_check.py --file 路由判定卡.md
  python3 lintong_route_check.py --file a.md --file b.md --strict
  python3 lintong_route_check.py --self-test
"""
import argparse
import os
import re
import sys

# 必查项：路由六要素
REQUIRED = [
    ("紧急度", r"(紧急度|高紧急|中紧急|低紧急)", "缺紧急度判定（高/中/低）"),
    ("影响度", r"(影响度|高影响|中影响|低影响)", "缺影响度判定，无法定位二维矩阵"),
    ("路由编号", r"(路由\s*[①②③④⑤]|路由\s*[1-5]|路由①|路由②|路由③|路由④|路由⑤)",
     "缺路由编号（①—⑤）"),
    ("首动作", r"(首动作|24h|72h|24 小时|72 小时)", "缺首动作与时限"),
    ("锚定路径", r"(锚定|文件夹|L主|L竣工|L结算)", "缺锚定文件夹路径"),
    ("升级路径", r"(升级|云总|法务|财务线)", "缺升级路径说明"),
]

# 警告项
WARN_PATTERNS = [
    (r"【待核", "存在【待核】项，交付前请核实或黄高亮"),
    (r"(覆盖度|待补充)", "存在覆盖度缺口说明，确认是否影响判定"),
]


def read_text(path):
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as exc:  # 错误处理：读不到即记录
        print("  ! 无法读取 %s：%s" % (path, exc))
        return None


def check_text(text):
    fails, warns = [], []
    for label, pat, msg in REQUIRED:
        if not re.search(pat, text):
            fails.append("[必查] %s：%s" % (label, msg))
    for pat, msg in WARN_PATTERNS:
        if re.search(pat, text):
            warns.append("[警告] %s" % msg)
    # 金额规范性：出现「万元/元」数字但无千分位分隔则告警
    for m in re.finditer(r"(?<![\d,])(\d{4,})(?:\.\d+)?\s*(万元|元)", text):
        if "," not in m.group(1):
            warns.append("[警告] 金额疑似未加千分位：%s%s" % (m.group(1), m.group(2)))
            break
    return fails, warns


def self_test():
    good = ("路由判定卡\n紧急度：高\n影响度：高\n路由①：律师函\n首动作：24h 内收件登记并转法务\n"
            "锚定路径：L主-接手后/逾期贷款催收通知书\n升级路径：当日报云总\n金额：1,200 万元\n"
            "注：部分口径【待核】。")
    bad = "把这个事情处理一下。"
    gf, _ = check_text(good)
    bf, _ = check_text(bad)
    print("自检样例 A（应通过）：%s" % ("通过" if not gf else "未通过 -> %s" % gf))
    print("自检样例 B（应拦截）：%s" % ("拦截成功" if bf else "未拦截（异常）"))
    if not gf and bf:
        print("自检结果：脚本逻辑正常（退出码 0）")
        return 0
    print("自检结果：脚本逻辑异常（退出码 2）")
    return 2


def main():
    ap = argparse.ArgumentParser(
        description="临潼决策路由交付自检：紧急度/影响度/路由编号/首动作/锚定/升级路径")
    ap.add_argument("--file", action="append", default=[], help="待检查文件（可多次指定）")
    ap.add_argument("--strict", action="store_true", help="严格模式：出现警告即返回退出码 1")
    ap.add_argument("--self-test", action="store_true", help="运行内置自检样例")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    if not args.file:
        ap.print_help()
        print("\n错误：未指定 --file，也未使用 --self-test（退出码 2）")
        return 2

    total_fail, total_warn, missing = [], [], []
    for path in args.file:
        if not os.path.isfile(path):
            missing.append(path)
            continue
        text = read_text(path)
        if text is None:
            missing.append(path)
            continue
        print("检查：%s（%d 字符）" % (path, len(text)))
        f, w = check_text(text)
        for line in f:
            print("  x " + line)
        for line in w:
            print("  ~ " + line)
        total_fail += ["%s -> %s" % (os.path.basename(path), x) for x in f]
        total_warn += ["%s -> %s" % (os.path.basename(path), x) for x in w]

    if missing:
        print("\n失败：以下文件不存在或不可读：")
        for m in missing:
            print("  - " + m)
        return 2

    print("\n—— 汇总 ——")
    print("必查项不通过：%d 项；警告项：%d 项" % (len(total_fail), len(total_warn)))
    if total_fail:
        print("结论：未通过交付门禁（退出码 2）")
        return 2
    if total_warn and args.strict:
        print("结论：严格模式下存在警告，建议复核后再交付（退出码 1）")
        return 1
    print("结论：通过交付门禁（退出码 0）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
