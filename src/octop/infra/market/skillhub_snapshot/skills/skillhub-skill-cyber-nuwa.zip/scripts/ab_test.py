#!/usr/bin/env python3
"""
ab_test.py - 蒸馏效果A/B对比工具
用法: python3 ab_test.py <SKILL.md路径>

功能:
- 生成5个标准化测试问题
- 展示问题，让用户分别用Skill和通用AI回答
- 用户粘贴两份回答后，脚本从5个维度打分对比
- 输出对比报告
"""

import re
import sys
from pathlib import Path
from dataclasses import dataclass


@dataclass
class TestResult:
    question: str
    skill_answer: str
    ai_answer: str
    scores: dict  # 5个维度的评分


def extract_mental_models(content: str) -> list:
    """从SKILL.md中提取心智模型名称"""
    models = []
    model_section = re.search(
        r'##\s*核心心智模型[^#]*?((?:###.+?\n[\s\S]*?)+?)(?=\n##|\Z)',
        content, re.DOTALL
    )
    if model_section:
        models = re.findall(r'^###\s+(.+)$', model_section.group(1), re.MULTILINE)
    return models[:5]  # 最多取5个


def extract_expression_dna(content: str) -> dict:
    """从SKILL.md中提取表达DNA特征"""
    dna = {
        '句式特征': [],
        '高频词': [],
        '幽默风格': '未知'
    }
    
    dna_section = re.search(r'##\s*表达DNA[\s\S]*?(?=\n##|\Z)', content)
    if dna_section:
        dna_content = dna_section.group(0)
        
        # 提取高频词
        freq_words = re.search(r'高频词.*?[:：](.*?)(?:\n|$)', dna_content)
        if freq_words:
            dna['高频词'] = [w.strip() for w in re.findall(r'[「「](.+?)[」」]', freq_words.group(1))]
        
        # 提取幽默风格
        humor = re.search(r'幽默风格.*?[:：](.*?)(?:\n|$)', dna_content)
        if humor:
            dna['幽默风格'] = humor.group(1).strip()
    
    return dna


def generate_test_questions(content: str) -> list:
    """生成5个标准化测试问题"""
    models = extract_mental_models(content)
    
    # 从SKILL.md中提取人名
    name_match = re.search(r'^#\s+(.+?)思维框架', content, re.MULTILINE)
    person_name = name_match.group(1) if name_match else "此人"
    
    questions = [
        {
            'type': '已知测试',
            'question': f'{person_name}，你怎么看[此人公开讨论过的热门话题]？',
            'dimension': '心智模型使用率'
        },
        {
            'type': '边缘测试',
            'question': f'{person_name}所在领域最近出现了[新现象]，你怎么看？',
            'dimension': '独特性'
        },
        {
            'type': '风格测试',
            'question': f'用200字分析一个中性话题',
            'dimension': '表达风格匹配度'
        },
        {
            'type': '拒答边界测试',
            'question': f'你对[此人回避的话题]怎么看？',
            'dimension': '诚实度'
        },
        {
            'type': '综合测试',
            'question': f'如果你面临一个重大决策，你会如何思考？',
            'dimension': '信息密度'
        }
    ]
    
    return questions


def score_answers(question: str, skill_answer: str, ai_answer: str, content: str) -> dict:
    """对比评分（简化版，实际需要AI评估）"""
    # 这里提供一个框架，实际评分需要用户手动判断或用AI评估
    
    scores = {
        '心智模型使用率': {'skill': 0, 'ai': 0},
        '表达风格匹配度': {'skill': 0, 'ai': 0},
        '独特性': {'skill': 0, 'ai': 0},
        '诚实度': {'skill': 0, 'ai': 0},
        '信息密度': {'skill': 0, 'ai': 0}
    }
    
    # 简单启发式评分（实际应该用AI评估）
    models = extract_mental_models(content)
    
    # 心智模型使用率
    for model in models:
        if model in skill_answer:
            scores['心智模型使用率']['skill'] += 20
    
    # 表达风格匹配度（检查是否有表达DNA特征）
    dna = extract_expression_dna(content)
    for word in dna['高频词']:
        if word in skill_answer:
            scores['表达风格匹配度']['skill'] += 10
    
    # 独特性（简单对比长度和复杂度）
    scores['独特性']['skill'] = min(100, len(skill_answer) // 5)
    scores['独特性']['ai'] = min(100, len(ai_answer) // 5)
    
    # 诚实度（检查是否有不确定性表达）
    uncertainty_words = ['可能', '也许', '不确定', '推测', '基于模型']
    for word in uncertainty_words:
        if word in skill_answer:
            scores['诚实度']['skill'] += 20
    
    # 信息密度（检查是否有具体案例和数据）
    if re.search(r'\d+%', skill_answer):
        scores['信息密度']['skill'] += 30
    if re.search(r'[案例|例子|例如]', skill_answer):
        scores['信息密度']['skill'] += 30
    
    # 限制分数在0-100
    for dimension in scores:
        scores[dimension]['skill'] = min(100, scores[dimension]['skill'])
        scores[dimension]['ai'] = min(100, scores[dimension]['ai'])
    
    return scores


def run_ab_test(skill_path: str):
    """运行A/B测试"""
    skill_file = Path(skill_path)
    
    if not skill_file.exists():
        print(f"[ERROR] 文件不存在: {skill_path}")
        sys.exit(1)
    
    content = skill_file.read_text(encoding='utf-8', errors='ignore')
    
    print(f"\n{'='*70}")
    print(f"赛博女娲·蒸馏进阶版 A/B对比测试")
    print(f"Skill文件: {skill_path}")
    print(f"{'='*70}\n")
    
    # 提取信息
    models = extract_mental_models(content)
    print(f"提取到 {len(models)} 个心智模型:")
    for i, model in enumerate(models, 1):
        print(f"  {i}. {model}")
    print()
    
    # 生成测试问题
    questions = generate_test_questions(content)
    
    print(f"将测试 {len(questions)} 个问题:\n")
    for i, q in enumerate(questions, 1):
        print(f"  {i}. [{q['type']}] {q['question']}")
    print()
    
    print(f"{'='*70}")
    print("测试流程:")
    print("  1. 对每个问题，先用Skill回答，粘贴回答")
    print("  2. 再用通用AI回答同样问题，粘贴回答")
    print("  3. 脚本自动评分并输出对比报告")
    print(f"{'='*70}\n")
    
    input("按Enter键开始测试...")
    
    results = []
    
    for i, q in enumerate(questions, 1):
        print(f"\n{'='*70}")
        print(f"问题 {i}/{len(questions)}: {q['question']}")
        print(f"测试维度: {q['dimension']}")
        print(f"{'='*70}\n")
        
        print("请用Skill回答这个问题，然后粘贴回答:")
        skill_answer = input("> ").strip()
        
        print("\n请用通用AI回答同样问题，然后粘贴回答:")
        ai_answer = input("> ").strip()
        
        # 评分
        scores = score_answers(q['question'], skill_answer, ai_answer, content)
        
        results.append(TestResult(
            question=q['question'],
            skill_answer=skill_answer,
            ai_answer=ai_answer,
            scores=scores
        ))
        
        print(f"\n[INFO] 问题 {i} 已记录")
    
    # 输出对比报告
    print(f"\n\n{'='*70}")
    print("A/B对比测试报告")
    print(f"{'='*70}\n")
    
    # 计算平均分
    avg_scores = {
        '心智模型使用率': {'skill': 0, 'ai': 0},
        '表达风格匹配度': {'skill': 0, 'ai': 0},
        '独特性': {'skill': 0, 'ai': 0},
        '诚实度': {'skill': 0, 'ai': 0},
        '信息密度': {'skill': 0, 'ai': 0}
    }
    
    for result in results:
        for dimension in avg_scores:
            avg_scores[dimension]['skill'] += result.scores[dimension]['skill']
            avg_scores[dimension]['ai'] += result.scores[dimension]['ai']
    
    for dimension in avg_scores:
        avg_scores[dimension]['skill'] /= len(results)
        avg_scores[dimension]['ai'] /= len(results)
    
    # 输出评分表
    print("维度评分对比:\n")
    print(f"{'维度':<20} {'Skill':<10} {'通用AI':<10} {'差异':<10}")
    print("-" * 50)
    
    skill_wins = 0
    for dimension, scores in avg_scores.items():
        diff = scores['skill'] - scores['ai']
        diff_str = f"+{diff:.1f}" if diff > 0 else f"{diff:.1f}"
        print(f"{dimension:<20} {scores['skill']:<10.1f} {scores['ai']:<10.1f} {diff_str:<10}")
        if diff > 0:
            skill_wins += 1
    
    print(f"\n{'='*70}")
    print(f"总结: Skill在 {skill_wins}/5 个维度上优于通用AI")
    
    if skill_wins >= 3:
        print("✅ 通过标准：Skill在至少3个维度上显著优于通用AI")
        print("🎉 蒸馏效果良好！")
    else:
        print("⚠️ 未通过标准：Skill需要在至少3个维度上显著优于通用AI")
        print("💡 建议：回到Phase 2重新提炼，或检查表达DNA是否准确")
    
    print(f"{'='*70}\n")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法: python3 ab_test.py <SKILL.md路径>")
        print("")
        print("示例:")
        print("  python3 ab_test.py .claude/skills/charlie-munger-perspective/SKILL.md")
        sys.exit(1)
    
    run_ab_test(sys.argv[1])
