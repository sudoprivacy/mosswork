# download_subtitles.ps1 - PowerShell版本字幕下载脚本
# 用法: .\download_subtitles.ps1 -VideoURL <URL> [-OutputDir <目录>]
# 优先级: 人工字幕(中文) > 人工字幕(英文) > 自动生成字幕(中文) > 自动生成字幕(英文)

param(
    [Parameter(Mandatory=$true, HelpMessage="视频URL (YouTube/Bilibili等)")]
    [string]$VideoURL,
    
    [Parameter(HelpMessage="输出目录 (默认当前目录)")]
    [string]$OutputDir = "."
)

# 检查 yt-dlp 是否可用
function Test-YtDlp {
    try {
        $null = Get-Command yt-dlp -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

# 安装 yt-dlp
function Install-YtDlp {
    Write-Host "[INFO] yt-dlp 未安装，尝试用pip安装..." -ForegroundColor Yellow
    try {
        pip install yt-dlp -q
        Write-Host "[SUCCESS] yt-dlp 安装完成" -ForegroundColor Green
    } catch {
        Write-Host "[ERROR] yt-dlp 安装失败，请手动安装: pip install yt-dlp" -ForegroundColor Red
        exit 1
    }
}

# 尝试下载字幕
function Try-DownloadSubtitles {
    param(
        [string]$SubLang,
        [string]$SubType,  # "manual" or "auto"
        [string]$Description
    )
    
    Write-Host "`n[STEP] 尝试下载$Description..." -ForegroundColor Cyan
    
    $ytDlpArgs = @(
        "--skip-download",
        "--write-subs"
    )
    
    if ($SubType -eq "auto") {
        $ytDlpArgs += "--write-auto-subs"
    }
    
    $ytDlpArgs += @(
        "--sub-lang", $SubLang,
        "--sub-format", "srt/vtt/best",
        "--no-warnings",
        "-o", "$OutputDir\%(title)s.%(ext)s",
        $VideoURL
    )
    
    try {
        $output = & yt-dlp @ytDlpArgs 2>&1
        
        # 检查是否下载了字幕文件
        $srtFiles = Get-ChildItem -Path $OutputDir -Filter "*.srt" -ErrorAction SilentlyContinue
        $vttFiles = Get-ChildItem -Path $OutputDir -Filter "*.vtt" -ErrorAction SilentlyContinue
        
        if ($srtFiles -or $vttFiles) {
            Write-Host "[SUCCESS] 成功下载$Description" -ForegroundColor Green
            return $true
        }
    } catch {
        # 静默失败，继续尝试下一个
    }
    
    return $false
}

# 主流程
Write-Host "=========================================" -ForegroundColor Magenta
Write-Host "字幕下载工具 - 赛博女娲·蒸馏进阶版 (PowerShell版)" -ForegroundColor Magenta
Write-Host "目标URL: $VideoURL" -ForegroundColor Magenta
Write-Host "输出目录: $OutputDir" -ForegroundColor Magenta
Write-Host "=========================================`n" -ForegroundColor Magenta

# 创建输出目录
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

# 检查 yt-dlp
if (-not (Test-YtDlp)) {
    Install-YtDlp
}

Write-Host "[STEP 1] 检查可用字幕..." -ForegroundColor Cyan
try {
    & yt-dlp --list-subs $VideoURL 2>$null | Select-Object -First 50
} catch {
    # 静默失败
}

$downloaded = $false

# 尝试1：人工中文字幕
if (-not $downloaded) {
    $downloaded = Try-DownloadSubtitles -SubLang "zh-Hans,zh-Hant,zh,cmn" -SubType "manual" -Description "人工字幕(中文)"
}

# 尝试2：人工英文字幕
if (-not $downloaded) {
    $downloaded = Try-DownloadSubtitles -SubLang "en,en-US,en-GB" -SubType "manual" -Description "人工字幕(英文)"
}

# 尝试3：自动生成中文字幕
if (-not $downloaded) {
    $downloaded = Try-DownloadSubtitles -SubLang "zh-Hans,zh-Hant,zh" -SubType "auto" -Description "自动生成字幕(中文)"
}

# 尝试4：自动生成英文字幕
if (-not $downloaded) {
    $downloaded = Try-DownloadSubtitles -SubLang "en" -SubType "auto" -Description "自动生成字幕(英文)"
}

# 结果输出
if ($downloaded) {
    Write-Host "`n=========================================" -ForegroundColor Magenta
    Write-Host "下载完成！字幕文件：" -ForegroundColor Green
    Get-ChildItem -Path $OutputDir -Filter "*.srt" | ForEach-Object { Write-Host "  $($_.FullName)" }
    Get-ChildItem -Path $OutputDir -Filter "*.vtt" | ForEach-Object { Write-Host "  $($_.FullName)" }
    Write-Host "`n下一步：运行字幕清洗脚本" -ForegroundColor Cyan
    Write-Host "  python3 srt_to_transcript.py <字幕文件路径> [输出txt路径]" -ForegroundColor Cyan
    Write-Host "=========================================`n" -ForegroundColor Magenta
} else {
    Write-Host "`n[ERROR] 未能下载任何字幕" -ForegroundColor Red
    Write-Host "可能原因：" -ForegroundColor Yellow
    Write-Host "  1. 该视频没有字幕" -ForegroundColor Yellow
    Write-Host "  2. URL 格式有误" -ForegroundColor Yellow
    Write-Host "  3. 视频有地区限制" -ForegroundColor Yellow
    Write-Host "  4. yt-dlp 版本过旧，请运行: pip install -U yt-dlp" -ForegroundColor Yellow
    exit 1
}
