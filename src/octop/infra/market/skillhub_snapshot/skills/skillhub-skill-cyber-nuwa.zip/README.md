# 赛博女娲 (cyber-nuwa)

> 「写不进去的那部分，才是你真正的护城河。」——但写得进去的部分，已经足够强大。

**赛博女娲不是复制人，是提炼思维框架。**
捕捉的是 **HOW they think**，不是 **WHAT they said**。

---

## 项目简介

赛博女娲是一个 **AI Skill 蒸馏引擎**，输入人名/主题/模糊需求，自动：
1. 启动 6 个并行 Agent 多源调研
2. 提炼核心心智模型（3-7 个）+ 决策启发式（5-10 条）+ 表达 DNA
3. 生成可运行的人物 Skill
4. 8 项质量自动检查 + 必要时降级

**适用场景**：
- 思维顾问（让 AI 拥有某人的思考方式）
- 决策参考（用某人的方法论分析问题）
- 角色扮演（让 AI 像某人一样回应）
- 主题方法论（综合多人视角形成主题 Skill）

---

## 核心特性

| 特性 | 说明 |
|------|------|
| **6 Agent 并行调研** | 著作 / 对话 / 表达DNA / 他者视角 / 决策记录 / 时间线 |
| **心智模型三重验证** | 跨域复现 + 生成力 + 排他性 |
| **3 级降级策略** | L1 部分蒸馏 / L2 骨架蒸馏 / L3 放弃蒸馏 |
| **4 类测试** | 已知 / 边缘 / 风格 / 拒答（共 8 个 prompt 模板）|
| **A/B 对比** | 5 维度评分，验证蒸馏效果 |
| **本地素材优先** | 用户提供的 PDF/视频/书可作最高优先级来源 |

---

## 快速开始

### 触发方式

直接对 AI 说：
- `蒸馏芒格`
- `做一个费曼 skill`
- `造一个 XX 视角`
- `我想提升决策质量`（模糊需求，AI 会推荐候选）

### 工作流程

```
用户输入 → Phase 0 入口分流 → Phase 1 6 Agent 调研
        → Phase 1.5 质量Review → Phase 2 框架提炼
        → Phase 3 组装 SKILL.md → Phase 4 8 项检查
        → Phase 5 双 Agent 精炼 → 交付 Skill
```

详细流程见 [workflow-details.md](references/workflow-details.md)。

---

## 安装方式

### 方式 1：直接放置（推荐）

将整个 `cyber-nuwa/` 目录复制到：

```
~/.claude/skills/cyber-nuwa/        # macOS/Linux
%USERPROFILE%\.claude\skills\cyber-nuwa\  # Windows
```

### 方式 2：作为 Git Submodule

```bash
cd ~/.claude/skills/
git submodule add https://github.com/你的用户名/cyber-nuwa.git
```

### 方式 3：解压 zip

下载 `cyber-nuwa-v1.0.0.zip`，解压到上述目录。

---

## 文档结构

```
cyber-nuwa/
├── SKILL.md                      # 主文件（精简版 219 行）
├── CHANGELOG.md                  # 变更日志
├── README.md                     # 本文件
├── references/
│   ├── workflow-details.md       # Phase 0-5 详细操作手册
│   ├── glossary.md               # 术语白话对照完整版
│   ├── examples.md               # 蒸馏芒格+模糊需求 2 个完整示例
│   ├── boundaries.md             # 边界场景与错误模式
│   ├── extraction-framework.md   # 心智模型三重验证 + FDS 计算
│   ├── skill-template.md         # 蒸馏产出的 SKILL.md 模板
│   └── changelog-template.md     # 变更日志格式
└── scripts/
    ├── merge_research.py         # Phase 1.5 调研汇总
    ├── quality_check.py          # Phase 4 质量检查
    ├── ab_test.py                # Phase 4.7 A/B 对比
    ├── srt_to_transcript.py      # 字幕清洗
    ├── download_subtitles.sh     # macOS/Linux 字幕下载
    └── download_subtitles.ps1    # Windows 字幕下载
```

---

## 质检报告

由 [qinshuba-skill-inspector (V1.0.5.1)](https://github.com/firecangshu/qinshuba-skill-inspector) 检测：

| 项目 | 结果 |
|------|------|
| **综合分** | **4.92 / 5.00** |
| **等级** | **A（优秀）** |
| **P0/P1/P2 问题** | 0 / 0 / 0 |
| **发布准备度** | 通过 |

### 五维分项

| 维度 | 得分 | 权重 |
|------|------|------|
| T - Trust（可信任度）| 5.00 | 25% |
| R - Reliability（可靠性）| 5.00 | 20% |
| A - Adaptability（适用性）| 5.00 | 20% |
| C - Convention（规范性）| 4.44 | 15% |
| E - Effectiveness（有效性）| 5.00 | 20% |

---

## 边界场景

赛博女娲**不适合**这些场景（详细见 [boundaries.md](references/boundaries.md)）：

- 目标人物已去世且无新公开素材
- 目标人物公开素材极少（< 5 条来源）
- 素材大量造假/矛盾
- 目标是非公开人物但用户无本地素材
- 目标是行业/方法论（需走主题 Skill 路径）

---

## 贡献指南

### 如何贡献

1. **报告问题**：在 [Issues](https://github.com/你的用户名/cyber-nuwa/issues) 提交
2. **改进文档**：编辑 `references/` 下的文件，提交 PR
3. **新增脚本**：在 `scripts/` 下添加，遵守现有命名规范
4. **新增功能**：先在 [Discussions](https://github.com/你的用户名/cyber-nuwa/discussions) 讨论

### 提交规范

每次提交前：
1. 更新 `CHANGELOG.md`
2. 通过 quality_check.py 检查
3. 写明改动原因（commit message）

### 开发规范

- 中文沟通，简洁直接
- 白话 + 专业术语对照（项目用户群偏好）
- 先结论后细节
- 严格遵循现有项目结构

---

## 路线图

- [x] v1.0.0 首版发布
- [ ] v1.1.0 增加 A/B 测试自动评分（避免人工粘贴）
- [ ] v1.2.0 增加 FDS 评分自动计算（基于 embedding）
- [ ] v2.0.0 主题 Skill 完整支持（综合多人视角）
- [ ] v2.1.0 Web UI（可视化蒸馏过程）

---

## 致谢

- **检测工具**：[qinshuba-skill-inspector](https://github.com/firecangshu/qinshuba-skill-inspector)（firecangshu）
- **规范参考**：skill-creator（本地）
- **灵感来源**：「女娲造人」神话 + 思维框架可迁移性

---

## 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

---

## 联系方式

- 创建者：花叔 (https://x.com/AlchainHust)
- 项目主页：https://github.com/你的用户名/cyber-nuwa
- Issues：https://github.com/你的用户名/cyber-nuwa/issues
