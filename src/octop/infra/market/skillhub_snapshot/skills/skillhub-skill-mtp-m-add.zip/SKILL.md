---
name: skillhub-skill-mtp-m-add
description: "monster 的 MTP 0.2.4 变更资料入口。用户给文件、调研、会议结论、事实、需求或问题要求纳入项目时使用。"
---

# M-Add

```mermaid
flowchart LR
  A["看材料"] --> B["记来源与影响"] --> C["路由下一步"]
```

## Version Preflight

写入前读取 `$SKILL_DIR/MTP_VERSION` 和 `ai/mtp.json`。manifest 缺失、profile
不是 `lightweight`、缺少有效 `project_id` / `registry_id` 或版本不匹配时，返回
`m-new` 且零写。只有完整 Bundle `0.2.4` 项目才继续。

只读新材料；判断关联时增量读 `ai/brief.md`。

## 怎么做

1. 区分来源、事实、需求、假设、建议、问题与影响范围；缺来源或含义标为未知，不猜。
2. 来源、短摘要、确定性、影响写入 `ai/backlog.md`；推断不写成用户事实，不改 `ai/brief.md`/`ai/plan.md`。
3. 影响目标/范围/约束/成功标准/设计 → `m-define`；重拆多步 → `m-plan`；其余 → `m-build`。
4. 长文/二进制只记路径与短摘要，不复制正文。

四原则：Think Before Coding / Simplicity First / Surgical Changes / Goal-Driven Execution。
说明来源不确定性，只记路由所需最小事实；影响判断追溯到 AC/TC/验证。
不写 `CLAUDE.md` 或 `ai/lessons.md`；例行简单变更只记录并路由，不启动子 Agent。
