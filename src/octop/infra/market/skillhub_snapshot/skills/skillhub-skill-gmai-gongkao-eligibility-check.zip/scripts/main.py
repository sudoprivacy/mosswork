# -*- coding: utf-8 -*-
"""报考条件自查（gmai-gongkao-eligibility-check）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
建议输入信息：学历学位与专业全称；工作或应届情况；亲属任职情况
"""
import json, os, sys, time

SLUG = "gmai-gongkao-eligibility-check"
TITLE = "报考条件自查"
PRICE_FEN = 2990

# 检查项（标题, 关键词, 落地建议）—— 逐项对本技能领域定制
CHECKS = [
 [
  "专业匹配",
  [
   "专业目录",
   "大类",
   "相近"
  ],
  "按专业目录核对可报大类"
 ],
 [
  "应届身份",
  [
   "应届",
   "择业期"
  ],
  "判定应届生身份适用年份"
 ],
 [
  "回避情形",
  [
   "回避",
   "亲属"
  ],
  "排查任职回避情形"
 ],
 [
  "基层经历",
  [
   "基层",
   "工作经历",
   "认定"
  ],
  "核对工作经历认定口径"
 ],
 [
  "诚信记录",
  [
   "诚信",
   "失信"
  ],
  "提示诚信档案影响情形"
 ]
]

DELIVERABLES = ["资格自查对照表", "可报范围说明", "风险情形提示"]


def load_input(argv):
    path = argv[1] if len(argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f), path


def analyze(data):
    text = json.dumps(data, ensure_ascii=False)
    fields = [v for v in data.values() if str(v).strip()]
    rich = len(fields) >= 2 or sum(len(str(v)) for v in fields) >= 28
    rows = []
    full = 0
    for item, kws, advice in CHECKS:
        if any(k in text for k in kws):
            rows.append((item, 2, advice))
            full += 1
        elif rich:
            rows.append((item, 1, advice))
        else:
            rows.append((item, 0, advice))
    return rows, full, rich


def build_report(data, rows, full, rich, src):
    L = []
    L.append("# %s 分析报告" % TITLE)
    L.append("")
    L.append("- 技能：%s（`%s`）" % (TITLE, SLUG))
    L.append("- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0))
    L.append("- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    L.append("- 输入来源：%s" % os.path.basename(src))
    L.append("")
    L.append("## 输入概览")
    L.append("")
    for k, v in data.items():
        v = str(v)
        L.append("- **%s**：%s" % (k, v[:160] + ("…" if len(v) > 160 else "")))
    L.append("")
    L.append("## 逐项分析")
    L.append("")
    for i, (item, lv, advice) in enumerate(rows, 1):
        if lv == 2:
            L.append("%d. **%s**：输入中已包含直接相关信息，落地路径——%s" % (i, item, advice))
        elif lv == 1:
            L.append("%d. **%s**：现有材料可支撑基础分析（该项的直接关键词材料偏薄，结论深度依补充材料而定）；路径——%s" % (i, item, advice))
        else:
            L.append("%d. **%s**：输入信息暂缺，需补充材料后才能给出可靠结论；建议：%s" % (i, item, advice))
    partial = sum(1 for r in rows if r[1] == 1)
    score = int(round(100.0 * (full + 0.5 * partial) / len(CHECKS)))
    L.append("")
    L.append("## 综合评估")
    L.append("")
    L.append("- 信息充分度：**%d/100**（直接命中 %d 项 / 材料可支撑 %d 项 / 共 %d 项）" % (score, full, full + partial, len(CHECKS)))
    if score >= 80:
        L.append("- 判定：输入充分，可按上述落地路径直接执行。")
    elif score >= 50:
        L.append("- 判定：输入基本可用，优先补齐薄弱项信息后执行效果更佳。")
    else:
        L.append("- 判定：输入偏薄，请按「待补充信息」整理材料后重新分析。")
    L.append("")
    L.append("## 待补充信息")
    L.append("")
    missed = [r[0] for r in rows if r[1] == 0]
    weak = [r[0] for r in rows if r[1] == 1]
    if missed or weak:
        for m in missed:
            L.append("- 「%s」相关的原始材料或说明（必需）" % m)
        for m in weak:
            L.append("- 「%s」相关的补充材料（建议，可提升结论深度）" % m)
    else:
        L.append("- 无：输入已覆盖全部检查项。")
    L.append("")
    L.append("## 交付物")
    L.append("")
    for d in DELIVERABLES:
        L.append("- %s" % d)
    L.append("")
    L.append("> 本报告由 `%s` 基于规则分析生成，供决策参考，不构成任何绝对保证。" % SLUG)
    return "\n".join(L) + "\n"


def main():
    data, src = load_input(sys.argv)
    rows, full, rich = analyze(data)
    md = build_report(data, rows, full, rich, src)
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "report_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
