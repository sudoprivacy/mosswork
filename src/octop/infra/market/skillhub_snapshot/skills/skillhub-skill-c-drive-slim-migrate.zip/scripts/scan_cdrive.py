#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C 盘瘦身 · 只读扫描器 (READ-ONLY)
================================
本脚本只统计体积、列出大文件，**不修改、不删除、不移动任何文件**。
输出按 c-drive-slim 技能的三类分级：
  🟢 DELETE_CANDIDATE 删除候选(低风险)
  🟡 MOVE_CANDIDATE   移动到 D 盘候选(中风险)
  🔴 HIGH_RISK        高危仅提示(默认不动)

用法:
  python scan_cdrive.py [--top N] [--timeout SEC]
默认 top=15, timeout=50(单目录扫描超时秒数)。
"""

import os
import sys
import time

# ---------- 工具函数 ----------

def human(n):
    if n is None:
        return "未知"
    n = float(n)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024.0:
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} PB"


def walk_size(root, max_files=300000, timeout=50):
    """递归统计目录体积，返回 (总字节, [(size, path), ...], 是否被截断)。只读。"""
    total = 0
    files = []
    count = 0
    start = time.time()
    truncated = False
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    sz = os.path.getsize(fp)
                except OSError:
                    continue
                total += sz
                files.append((sz, fp))
                count += 1
                if count > max_files:
                    truncated = True
                    break
            if truncated:
                break
            if time.time() - start > timeout:
                truncated = True
                break
            # 防止符号链接/ junctions 无限循环: os.walk 默认不跟随, 安全
    except (OSError, PermissionError):
        # 权限不足(如 System Volume Information) -> 仅返回已能读取的部分
        pass
    return total, files, truncated


def size_of_path(p, timeout):
    """对单文件取大小；对目录递归统计。"""
    try:
        if os.path.isfile(p):
            return os.path.getsize(p), [], False
        if os.path.isdir(p):
            return walk_size(p, timeout=timeout)
    except OSError:
        pass
    return None, [], False


def top_files(files, n):
    return sorted(files, reverse=True)[:n]


# ---------- 候选目录定义 ----------

USER = os.environ.get("USERPROFILE", r"C:\Users")
LOCAL = os.environ.get("LOCALAPPDATA", os.path.join(USER, "AppData", "Local"))
ROAM = os.environ.get("APPDATA", os.path.join(USER, "AppData", "Roaming"))
TEMP = os.environ.get("TEMP") or os.environ.get("TMP") or os.path.join(LOCAL, "Temp")

CATEGORIES = {
    "DELETE_CANDIDATE": [
        (r"C:\Windows\Temp", "Windows 系统临时文件"),
        (TEMP, "当前用户临时文件"),
        (r"C:\Windows\SoftwareDistribution\Download", "Windows Update 下载缓存"),
        (os.path.join(LOCAL, "Microsoft", "Windows", "INetCache"), "系统 Web 缓存"),
        (os.path.join(LOCAL, "Google", "Chrome", "User Data", "Default", "Cache"), "Chrome 缓存"),
        (os.path.join(LOCAL, "Microsoft", "Edge", "User Data", "Default", "Cache"), "Edge 缓存"),
        (os.path.join(ROAM, "Mozilla", "Firefox", "Profiles"), "Firefox 配置/缓存"),
        (os.path.join(LOCAL, "npm-cache"), "npm 缓存"),
        (os.path.join(LOCAL, "pip", "Cache"), "pip 缓存"),
        (os.path.join(LOCAL, "yarn", "cache"), "yarn 缓存"),
    ],
    "MOVE_CANDIDATE": [
        (os.path.join(USER, "Downloads"), "下载目录(大文件)"),
        (os.path.join(USER, "Desktop"), "桌面"),
        (os.path.join(USER, "Documents"), "文档"),
        (os.path.join(USER, "Pictures"), "图片"),
        (os.path.join(USER, "Videos"), "视频"),
        (os.path.join(LOCAL, "WeChat"), "微信文件数据(FileStorage)"),
        (os.path.join(LOCAL, "WXWork"), "企业微信数据"),
        (os.path.join(ROAM, "Tencent", "QQ"), "QQ 接收文件"),
    ],
    "HIGH_RISK": [
        (r"C:\hiberfil.sys", "休眠文件(关休眠才释放)"),
        (r"C:\pagefile.sys", "虚拟内存(不建议动)"),
        (r"C:\Windows.old", "旧系统 Windows.old"),
        (r"C:\System Volume Information", "系统还原点"),
        (os.path.join(LOCAL, "Microsoft", "OneDrive"), "OneDrive 同步缓存"),
    ],
}

LABELS = {
    "DELETE_CANDIDATE": "🟢 删除候选(低风险, 进回收站须确认)",
    "MOVE_CANDIDATE": "🟡 移动到D盘候选(中风险, 先备份校验须确认)",
    "HIGH_RISK": "🔴 高危仅提示(默认不动, 需用户明确决定)",
}


# ---------- 主流程 ----------

def main():
    top_n = 15
    timeout = 50
    args = sys.argv[1:]
    for i, a in enumerate(args):
        if a == "--top" and i + 1 < len(args):
            try:
                top_n = int(args[i + 1])
            except ValueError:
                pass
        if a == "--timeout" and i + 1 < len(args):
            try:
                timeout = int(args[i + 1])
            except ValueError:
                pass

    print("=" * 72)
    print("C 盘瘦身 · 只读扫描报告 (本脚本不修改任何文件)")
    print("=" * 72)
    print(f"扫描用户: {USER}")
    print(f"Top-N 大文件: {top_n}   单目录超时: {timeout}s\n")

    totals = {}
    for cat, items in CATEGORIES.items():
        print("-" * 72)
        print(LABELS[cat])
        print("-" * 72)
        cat_total = 0
        cat_top = []
        for path, desc in items:
            if not os.path.exists(path):
                print(f"  [跳过] 不存在: {path}  ({desc})")
                continue
            sz, files, trunc = size_of_path(path, timeout)
            if sz is None:
                print(f"  [无权限/错误] {path}  ({desc})")
                continue
            cat_total += sz
            cat_top.extend(files)
            flag = " (扫描超时/截断)" if trunc else ""
            print(f"  {human(sz):>10}  {desc}{flag}")
            print(f"             {path}")
        totals[cat] = cat_total
        tfs = top_files(cat_top, top_n)
        if tfs:
            print(f"  --- Top {len(tfs)} 大文件 ---")
            for sz, fp in tfs:
                # 仅显示相对于该类别已知根的简短路径, 避免过长
                print(f"     {human(sz):>10}  {fp}")
        print(f"  >>> 本类合计可释放/可转移: {human(cat_total)}\n")

    print("=" * 72)
    print("汇总")
    print("=" * 72)
    print(f"  🟢 删除候选合计 : {human(totals.get('DELETE_CANDIDATE', 0))}")
    print(f"  🟡 移动到D盘合计: {human(totals.get('MOVE_CANDIDATE', 0))}")
    print(f"  🔴 高危仅提示    : {human(totals.get('HIGH_RISK', 0))} (默认不处置)")
    print("\n说明: 以上为只读估算。实际处置(删除/移动)须由用户逐项确认后执行。")
    print("=" * 72)


if __name__ == "__main__":
    main()
