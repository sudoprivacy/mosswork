# C 盘安全瘦身 · 候选目标清单与风险分级

本文件供 c-drive-slim 技能在执行前参考。所有路径均为 Windows 默认位置，将"用户名"替换为实际用户名（如 64826）。扫描只读，处置须经用户确认。

## 风险等级图例

- 低风险（删除候选）：纯临时/缓存，删除通常不影响系统运行。仍须用户确认后执行。
- 中风险（移动到 D 盘候选）：用户个人数据/大文件，建议转移而非删除，转移前先备份校验。
- 高危（仅提示，默认不动）：与系统运行强相关，处置需用户明确知晓副作用并二次确认。

---

## 低风险 · 删除候选（进回收站，须确认）

| 路径 | 说明 | 备注 |
|------|------|------|
| C:\Windows\Temp\* | Windows 系统临时文件 | 可清；正在被占用的会跳过 |
| %LOCALAPPDATA%\Temp\* | 当前用户临时文件 | 即 C:\Users\用户名\AppData\Local\Temp |
| C:\Windows\SoftwareDistribution\Download\* | Windows Update 下载缓存 | 清后下次更新会重新下载 |
| %LOCALAPPDATA%\Microsoft\Windows\INetCache\* | 系统 Web 缓存 | |
| 浏览器缓存：%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cache | Chrome 缓存 | 不影响书签/账号 |
| 浏览器缓存：%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Cache | Edge 缓存 | |
| 浏览器缓存：%APPDATA%\Mozilla\Firefox\Profiles\*\cache2 | Firefox 缓存 | |
| C:\Users\用户名\AppData\Local\npm-cache | npm 缓存 | npm cache clean --force 可清 |
| %LOCALAPPDATA%\pip\Cache | pip 缓存 | |
| %LOCALAPPDATA%\yarn\cache | yarn 缓存 | |
| C:\Users\用户名\Downloads 下的 .tmp / .log / 已确认无用安装包 | 下载目录垃圾 | 仅明确无用者，须逐项确认 |
| C:\ProgramData\Package Cache（部分） | 安装包缓存 | 仅可安全部分，谨慎 |

---

## 中风险 · 移动到 D 盘候选（先备份校验，须确认）

| 路径 | 说明 | 建议 |
|------|------|------|
| C:\Users\用户名\Downloads\ 下大文件（超过 500MB 的 iso/zip/视频） | 下载的大体积文件 | 移至 D:\C盘迁移资料\Downloads\ |
| C:\Users\用户名\Desktop\ 非程序类大文件 | 桌面大文件 | 移至 D 盘对应目录 |
| C:\Users\用户名\Documents\ / Pictures\ / Videos\ 中大文件 | 个人媒体/文档 | 移至 D:\C盘迁移资料\ |
| C:\Users\用户名\AppData\Local\WeChat\ 下 FileStorage | 微信接收的文件/图片/视频 | 大体积常见，建议转移 |
| C:\Users\用户名\Documents\WXWork\ 或 AppData\Local\WXWork | 企业微信文件数据 | 建议转移 |
| C:\Users\用户名\AppData\Roaming\Tencent\QQ\ | QQ 接收文件 | 建议转移 |
| 项目代码目录（如 C:\Users\用户名\source\、C:\projects） | 源码（非编译缓存） | 移至 D 盘，保留结构 |

注意：移动程序配置/数据库前必须确认对应软件已关闭，避免文件占用或数据损坏。

---

## 高危 · 仅提示，默认不动（需用户明确决定 + 二次确认）

| 路径/项 | 可释放空间 | 副作用 | 处置方式 |
|---------|-----------|--------|----------|
| C:\hiberfil.sys（休眠文件） | 数 GB | 关闭休眠后睡眠/休眠不可用 | 仅提示；用 powercfg -h off 须用户自行决定 |
| C:\pagefile.sys（虚拟内存） | 数 GB | 影响内存不足时系统稳定性 | 不碰 |
| Windows.old（实为 C:\Windows.old） | 可达数十 GB | 升级回退能力丢失 | 仅提示；用磁盘清理"以前的系统安装" |
| 系统还原点（System Volume Information） | 不定 | 失去还原能力 | 仅提示；由用户通过系统属性调整 |
| C:\$Recycle.Bin | 不定 | 清回收站 | 可提示用户自行清空 |
| C:\Users\用户名\AppData\Local\Microsoft\OneDrive | 不定 | 影响 OneDrive 同步缓存 | 仅提示，不自动删 |

---

## 禁止清单（No-Go，绝不递归删除/清空）

- C:\Windows（尤其 System32、WinSxS）、C:\Program Files、C:\Program Files (x86)
- C:\ProgramData（除明确安全的缓存子目录）
- C:\Users\用户名\AppData 中的程序配置/账号数据部分（非缓存）
- 桌面/下载/文档/图片/视频/音乐等个人目录：仅扫描与建议，删除/移动须逐项确认
- 任何驱动、注册表、环境变量"优化"——本技能不做

---

## 执行约束（对所有处置生效）

1. 删除候选默认进回收站（SendToRecycleBin），不用永久删除；要真正回收 C 盘空间，需在用户确认后清空回收站。
2. 移动先 `robocopy /E /COPY:DAT` 备份到 D 盘（勿用 /COPYALL 或 /COPY:DATSO，普通用户无 ACL 权限会失败），校验一致后用 `SHFileOperation` 把原文件**送回收站**（可逆，受安全网保护）；再用 `mklink /J` 在原路径建连接点让程序无感。注意系统回收站位于 C 盘，送回收站并不腾出 C 盘空间；**严禁用 ctypes/rmtree 永久删除用户目录原文件**（会绕过 safe-delete 安全网、曾致部分不可逆删除）；真正释放空间须用户单独确认后清空回收站。
3. 每批不超过 10 个文件/目录，逐批验证；失败立即暂停。
4. 任何删除/编辑/移动/重命名，未获用户明确确认不执行。
5. 影响系统运行的操作，仅提示，不自动执行。
