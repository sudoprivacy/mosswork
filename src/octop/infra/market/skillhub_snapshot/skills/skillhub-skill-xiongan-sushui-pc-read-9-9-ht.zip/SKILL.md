---
name: skillhub-skill-xiongan-sushui-pc-read-9-9-ht
description: "通过USB转RS485（CH340）读取温湿度传感器。触发词：读取温湿度、查看传感器数据、温湿度多少、连接温湿度传感器、9.9包邮温湿度、Modbus传感器等。"
---

# 雄安素水-连接9.9包邮温湿度

通过 USB 转 RS485 线缆（CH340），用 Modbus RTU 协议读取温湿度传感器数据。

## 前置条件：CH340 驱动

USB 转 RS485 线缆通常使用 CH340 芯片，电脑需安装驱动才能识别串口。

**检查是否已安装：** 打开设备管理器 → 端口（COM 和 LPT），查看是否有 `USB-SERIAL CH340` 字样的端口。如有则跳过安装。

**安装驱动：** 如未识别，前往以下地址下载 CH340 驱动并安装：
> https://xiazai.zol.com.cn/detail/62/619590.shtml

安装完成后重新插拔 USB 线缆，确认设备管理器中出现 CH340 串口（如 COM3、COM4 等），再进行后续操作。

## 传感器参数

| 参数 | 值 |
|------|-----|
| 设备地址 | 1 |
| 波特率 | 9600 |
| 校验位 | None（N） |
| 数据位 | 8 |
| 停止位 | 1 |
| 协议 | Modbus RTU |

## 寄存器定义

| 寄存器地址 | 含义 | 数据类型 |
|-----------|------|---------|
| 0 | 温度 × 10（整数） | 16-bit signed int |
| 1 | 湿度 × 10（整数） | 16-bit unsigned int |
| 2-3 | 温度（浮点大端） | 32-bit float（big-endian） |
| 4-5 | 湿度（浮点大端） | 32-bit float（big-endian） |

## 执行

本 skill 附带 batch JSON 文件 `scripts/read_sensor.json`。

**严格按照以下格式调用 `run_tool_batch`，使用 `file_path` 加载文件执行。不要自行构造 `actions` 列表内联传入。**

`run_tool_batch` 的 `file_path` 需要**绝对路径**。你在读取本 SKILL.md 时看到的目录路径即为本 skill 的绝对目录，请用它拼接出完整的 `file_path`。

```
run_tool_batch(
  file_path="<本skill目录>/scripts/read_sensor.json",
  args={
    "skill_dir": "<本skill目录>",
    "com_port": "COM19",
    "device_id": "1",
    "baudrate": "9600"
  }
)
```

### Batch 参数

逐项说明 `args` 中的每个参数：

* `skill_dir`：本 skill 的绝对目录路径。你在读取本 SKILL.md 时看到的目录路径。**必须传入实际路径。**
* `com_port`：CH340 串口号。默认 `COM19`。如果电脑上 CH340 是其他端口号（如 COM4、COM18），修改此值。可通过 `mode` 命令或设备管理器查看。
* `device_id`：Modbus 设备地址。默认 `1`。如果传感器地址被修改过，改为实际地址。
* `baudrate`：波特率。默认 `9600`。通常不需要修改。

### Batch 失败处理

如果 `run_tool_batch` 执行失败（返回 `ok: false` 或中途报错），请：

1. 先检查「Batch 参数」中列出的每个参数是否都已传入实际值，尤其 `skill_dir` 和 `com_port`。
2. 如果串口无法打开，检查 COM 口是否被其他程序占用，或尝试其他 CH340 端口（COM4、COM18）。
3. 如果提示 `ModuleNotFoundError: No module named 'pymodbus'`，执行 `pip install pymodbus pyserial -q` 安装依赖。
4. 如果串口不存在，可能需要安装 CH340 驱动。下载地址：https://xiazai.zol.com.cn/detail/62/619590.shtml，安装后重新插拔 USB 线缆，确认设备管理器中出现 CH340 串口后再重试。
5. 如果仍然失败，参照下方「分步参考」手动执行。
6. 执行完毕后，提示用户：「本次 batch 执行遇到问题，已改为手动完成。是否需要我用 edit_file 调整和优化这个 skill 的 batch 脚本？」

### 分步参考

以下是 batch 中每一步的详细说明，仅在需要调试或手动执行时参考：

1. **检查串口是否存在**：通过 `mode` 命令或 PowerShell 检查 CH340 串口。
2. **安装依赖**：`pip install pymodbus pyserial -q`（如未安装）。
3. **读取传感器**：用 pymodbus 读取 holding registers 0-5。
4. **解析数据**：整数温度 = 寄存器0 ÷ 10，整数湿度 = 寄存器1 ÷ 10；浮点值用 `struct.unpack('>f')` 解析寄存器2-3和4-5。
5. **输出结果**：格式化温度（℃）和湿度（%RH）。

### 注意事项

- pymodbus 3.x 版本使用 `device_id` 参数指定从机地址（而非 `slave` 或 `unit`）。
- 串口参数使用 `bytesize`（而非 `data_bits`）和 `stopbits`（而非 `stop_bits`）。
- 温度寄存器 0 的值可能为负数（当值 > 32767 时，需减去 65536）。
- 如果 COM19 被占用，可尝试 COM4 或 COM18（同一 CH340 芯片的其他端口）。

**执行方式提醒**：触发本 skill 时，直接使用上方的 `run_tool_batch(file_path=..., args=...)` 调用即可完成全部流程，无需自己逐步编写每一个 action。只有当 batch 执行失败时，才参照「Batch 失败处理」中的降级方案。