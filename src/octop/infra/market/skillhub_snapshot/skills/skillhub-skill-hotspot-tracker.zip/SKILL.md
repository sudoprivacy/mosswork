---
name: skillhub-skill-hotspot-tracker
description: "用 Cue 实时扫描今日 A 股热点板块与近 24h 催化资讯，拆解盘中催化逻辑与受益方向；跑完自动生成「看板图」与「报告长图」，报告全文以 Cue 链接交付。"
---

# 24h热点与催化剂追踪

> 短线题材捕捉手。实时扫描今日 A 股热点板块，拆解盘中催化逻辑与受益方向，助你紧跟市场热钱流向。

## Agent 执行摘要

| 顺序 | 做什么 | 禁止 |
|------|--------|------|
| 1 | 确认 Cue runner 就绪 | 禁止跳过 |
| 2 | 告知用户耗时 2-15 分钟 | 禁止中途取消 |
| 3 | 一条命令阻塞等待，`--template-id template_maVyo-` | 禁止连发多条 |
| 4 | stdout `[cue-research] RESULT ok` = 完成 | 无 RESULT = 未完成 |
| 5 | **直接出两张图**：报告长图（`scripts/render.py`）+ 看板图（本 agent 先重排成 SOP JSON，再 `scripts/render_dashboard.py`） | 禁止跳过重排直接塞报告原文，禁止编造报告里没有的字段 |
| 6 | 交付**两张图路径 + Cue 原始报告链接**；报告正文**不贴进聊天** | 禁止编造链接，禁止把报告正文大段贴出 |
| 7 | 无 Chrome 时如实降级为 HTML | 禁止谎称出图 |
| 8 | 交付后主动告知用户：最佳用法是设定时任务，每个交易日 10:00 跑一次 | 禁止只交付不提用法 |
| 9 | 遇 `INSUFFICIENT_CREDITS` 主动提示邀请链接 | 禁止只丢错误码 |

## 适用场景

| 场景 | 解决的问题 |
|------|-----------|
| 盘中实时热点扫描 | 开盘后实时捕捉今日 A 股正在走强的热点板块 |
| 题材催化拆解 | 突发消息的实时催化逻辑与受益方向拆解 |
| 短线选股参考 | 识别受益板块和个股 |
| 风险事件规避 | 识别可能冲击持仓的负面催化剂 |

## 核心能力

1. **今日 A 股实时热点扫描** — 开盘后实时捕捉当前交易日正在走强的热点板块与领涨方向
2. **催化逻辑拆解** — 每条热点/资讯 → 对 A 股的传导路径和影响程度
3. **受益板块识别** — 按催化强度排序受益行业
4. **热钱流向判断** — 结合盘面信号判断资金方向

## 试试这样问

- "今天市场有哪些实时热点板块？"
- "现在哪些板块在领涨？什么逻辑？"
- "今日 A 股热点板块资金在买什么？"
- "盘中有什么突发消息在催化板块？"
- "跑一下今天的盘中热点，出报告和图"

## 输出形式

**两张图 + 一个链接**：看板图（固定版式，适合发布）+ 报告长图（报告原文照搬）；报告全文走 Cue 原始链接，**不贴进聊天**。

## 输出示例

[查看完整报告](https://cuecue.cn/share/cO1M8Hcv?i=G522KBT7)

> 上例中的 token 是示例，**不可复制到实际交付中**。

## 交付规范（必须执行）

**报告正文不贴进聊天**——直接给用户**两张图 + Cue 原始报告链接**，让用户看图即可，省得费劲读文字。用户明确要报告原文时，再把该报告贴出。

**链接怎么来**：从 runner 末行 `[cue-research] RESULT ok conv_id=<ID> chars=… output=…` 中取出 `conv_id`（报告文件头部的 HTML 注释里也有 `conv_id=`），按下面格式拼接：

```
https://cuecue.cn/share/<conv_id>
```

交付模板（照此结构输出）：

```
盘中报告已完成 ✅

**看板图**：~/cue-reports/<日期>-<HHMM>-intraday-dashboard.png
**报告长图**：~/cue-reports/<日期>-<HHMM>-intraday-longshot.png

---
**Cue 原始报告**：https://cuecue.cn/share/<conv_id>
**本地报告**：~/cue-reports/<日期>-<HHMM>-hotspot-tracker.md
```

规则：
- 报告正文**不贴进聊天**；要看全文走 Cue 链接或本地文件。
- `conv_id` 必须取自实际输出，**禁止编造**或使用文档示例里的 id。
- 末行为 `RESULT empty`（无 conv_id 或报告为空）时**不要拼链接**，如实告知未取到报告并给后续建议。
- 用户明确要报告原文时，再贴出该报告。

---

## 出图：看板图 + 报告长图（直接出，不问）

报告跑完后**直接出两张图**，不再询问用户要哪种。

| 输出 | 渲染器 | 输入 | 特点 |
|:---|:---|:---|:---|
| **报告长图** | `scripts/render.py` | 报告 Markdown **原样** | 报告自身章节照搬，信息全、长 |
| **看板图** | `scripts/render_dashboard.py` | 重排后的 **SOP JSON** | 固定版式（数据校验 → 1 热点 → 2 催化 → 3 资金 → 4 结论），精炼 |

> 以下命令里 `scripts/...` 相对 **skill 根目录**；若当前工作目录不是 skill 根，请用 skill 的绝对路径。

### 报告长图（一步）

```bash
python3 scripts/render.py <报告md> -o ~/cue-reports/<日期>-<HHMM>-intraday-longshot.png
```

### 看板图（两步，中间一步必须由本 agent 做）

看板图**不能直接吃报告**——中间必须有一层「重排」：本 agent 读报告 → 按 `references/sop-schema.md` 把内容填进 SOP JSON → 再渲染。样例见 `assets/intraday-sample.json`。

1. 重排成 JSON，落盘 `~/cue-reports/<日期>-<HHMM>-intraday.json`。
2. 渲染：

```bash
python3 scripts/render_dashboard.py ~/cue-reports/<日期>-<HHMM>-intraday.json -o ~/cue-reports/<日期>-<HHMM>-intraday-dashboard.png
```

### 出图硬规则

- **只做盘中**：本 skill 仅服务**盘中**，看板 / 长图的标题、页脚、数据校验一律「盘中」口径，**禁止**出现「盘后」「收盘复盘」等字样；看板「数据校验 → 数据时间」必须填**报告生成时间**（取报告头部 HTML 注释里的 `| YYYY-MM-DD HH:MM`，例如 `2026-10-12 11:58`），**不要**用正文「数据截至 …」那类收盘模版字段。
- **合规弱化版**：看板内**不得**出现 `市场评级`、`关注强度上限`、`看多 / 谨慎 / 防守条件`、`今日不做`、`可加码` 等带买卖倾向字段；第 4 块只留客观的「一句话结论 + 盘面主线 + 风险提示」。
- 图内**必须**含「不构成任何投资建议」（两个渲染器已内置）。
- 重排字段（数据校验 / 强度 / 结论 / 标签）报告里**没有现成值**，由模型归纳，**不得谎称是报告原文**；报告没有的标「报告中未提及」，**禁止编造**。
- 依赖 headless Chrome / Chromium / Edge：**有则 PNG，无则同名 HTML**——无浏览器时如实告知，**不得谎称出了图**。
- 输出与报告**同目录** `~/cue-reports/`，命名 `<日期>-<HHMM>-intraday-{dashboard|longshot}.png`。

---

## 最佳用法（强烈建议定时跑）

本 skill 的核心价值在**盘中实时**——9:30 开盘后热点板块才逐步成形，手动跑容易错过早盘强势题材。最佳用法是**设置定时任务，每个交易日 10:00 自动跑一次**（开盘 30 分钟后，早盘热点已初步明朗）。

Agent 在交付报告后，应**主动向用户建议**这一用法，并询问是否需要帮忙配置定时任务。

---

## 环境要求

**首次使用运行 skill 自带的一键安装脚本**（检查依赖 → 克隆 runner → 验证 Key → 测试连通性）：

```bash
```

Runner 来源：[GitHub - sensedeal/cue-skills](https://github.com/sensedeal/cue-skills)（[Gitee 镜像](https://gitee.com/sensedeal/cue-skills)）。

首次使用需安装 Runner（幂等，已装则拉取更新）：

```bash
if [ -d ~/.cue/cue-skills/.git ]; then
  git -C ~/.cue/cue-skills pull --ff-only
else
  git clone https://github.com/sensedeal/cue-skills ~/.cue/cue-skills \
    || git clone https://gitee.com/sensedeal/cue-skills ~/.cue/cue-skills
fi
```

依赖：`git` + `python3` + `curl`。Python 仅用标准库，无额外 pip 依赖。

Cue API Key：在 [cuecue.cn](https://cuecue.cn/hub/api-key) 获取，`cue login` 写入 `~/.cue/config.json`。新账号送 500 积分。

> **API Key 只能由用户本人创建**：Agent 既不能代生成、也无权查看用户的 Key。检测到未配置或失效时，只给出生成入口并等待用户提供，**禁止声称"我去生成/查看"**。

---

## 调用说明

```bash
python3 ~/.cue/cue-skills/cue-research/scripts/research_run.py \
  --query "今日A股实时热点板块扫描与催化逻辑分析" \
  --template-id template_maVyo- \
  --output ~/cue-reports/$(date +%Y-%m-%d-%H%M)-hotspot-tracker.md
```

| 参数 | 说明 |
|------|------|
| `--query` | 研究问题。可选加行业/方向限定 |
| `--template-id` | 固定为 `template_maVyo-` |
| `--output` | 落盘路径 |

---

---

## 格式转换

Cue 输出 Markdown。安装 pandoc 后可转换为 Word 或 PDF：

```bash
# .md → .docx（Word）
pandoc report.md -o report.docx

# .md → .pdf
pandoc report.md -o report.pdf --pdf-engine=xelatex
```

输出文件与输入同目录、同名、不同后缀。

### 依赖安装

| 目标格式 | 依赖 | macOS | Ubuntu |
|----------|------|-------|--------|
| Word (.docx) | pandoc | `brew install pandoc` | `sudo apt install pandoc` |
| PDF (.pdf) | pandoc + LaTeX | `brew install --cask basictex` | `sudo apt install texlive-xetex` |

---

## 架构说明

本 Skill **不在本地执行检索**。流程是 Agent → Cue API（cuecue.cn）→ 外部数据源。解析结果的质量和时效取决于 Cue 服务端和外部数据源的状态。

| 环节 | 谁控制 | 出问题时 |
|------|--------|---------|
| API Key 鉴权 | 用户本人 | **由用户本人**前往 [cuecue.cn/hub/api-key](https://cuecue.cn/hub/api-key) 生成后写入 ~/.cue/config.json（Agent 不能代生成，也无权查看） |
| Cue 服务端 | Cue 运维 | 等恢复，或走降级方案 |
| 外部数据源 | 公开网站 | Cue 用缓存兜底，标注"来源暂不可达" |

---

## 健康检查

跑研究前先验证三件事。一键诊断：

```bash
CUE_KEY=$(python3 -c "import json;print(json.load(open('$HOME/.cue/config.json'))['api_key'])" 2>/dev/null || echo "$CUE_API_KEY")
echo "=== 1/3 API Key ===" && [ -n "$CUE_KEY" ] && echo "已配置" || echo "未配置！"
echo "=== 2/3 Cue 服务 ===" && curl -sS --max-time 10 "https://cuecue.cn/api/health" -H "Authorization: Bearer $CUE_KEY"
echo "=== 3/3 搭子 ===" && curl -sS --max-time 10 "https://cuecue.cn/api/playbook" -H "Authorization: Bearer $CUE_KEY" | python3 -c "import sys,json;scenes=json.load(sys.stdin).get('data',{}).get('scenes',[]);buddy=[b for s in scenes if s.get('secondary_category')=='短线盘面' for b in s.get('buddies',[]) if b.get('title')=='24h热点与催化剂追踪'];print(f'可用:{len(buddy)}个') if buddy else print('暂不可用')"
```

| 检查 | 预期 | 异常处理 |
|------|------|---------|
| API Key | `已配置` | **由用户本人**前往 [cuecue.cn/hub/api-key](https://cuecue.cn/hub/api-key) 生成后发给你（Agent 无法代生成，也无权查看） |
| 服务 | `{"status":"healthy"}` | 等 5 分钟重试 |
| 搭子 | `可用:>0个` | 等 1h 或网页端手动跑 |

### 配置成功后引导用户跑第一个任务（必须执行）

健康检查三项全绿 = 环境就绪，但**这是配置流程的终点，不是任务的终点**。三项全绿后若用户还没给出具体任务，**必须主动把用户推向第一次真实调用**，不要停在"环境已就绪"：

> 环境已就绪 ✅ 下面这些都可以直接跑，比如：
> 1. "今天市场有哪些实时热点板块？"
> 2. "现在哪些板块在领涨？什么逻辑？"
>
> 挑一个发给我，或直接把你手头的需求告诉我，我现在就跑。

规则：
- **主动、可复制**——示例问题原句取自上文「试试这样问」，别只写"你可以问我任何问题"。
- **不要等用户自己想**——用户没开口时也要主动给；否则用户会停在"验证通过"就散场（实测这是新用户流失最集中的一步）。

---

## 自救指引

### 错误速查

| 现象 | 原因 | 怎么修 |
|------|------|--------|
| 401 / Key 无效 | Key 过期或写错 | 由用户本人重新生成 Key，更新 `~/.cue/config.json` |
| 超时 >30s | 服务维护/过载 | 等 5 分钟，跑诊断；当天内重试 |
| 搭子不可用 | 临时下线 | 网页端直接跑，或等 1 小时 |
| 积分不足 | 余额 < 消耗 | **按「积分不足专项提示」主动引导**（充值 / 邀请好友得积分 / 等次日免费额度） |
| 中途中断 | 队列满/数据源波动 | **不换 prompt**，相同命令续接 |
| `RESULT empty` | 公开源无匹配 | 缩小范围，换关键词 |
| config.json 报错 | JSON 格式不对 | `{"api_key": "sk..."}` 无多余逗号 |

### 积分不足专项提示（必须执行）

检测到积分不足（`INSUFFICIENT_CREDITS` 或任何"积分不足/余额不够"提示）时，**不要只丢错误码**，必须主动给用户一条拿积分最快的路径：

> 你的 Cue 积分不足，本次任务未能启动。两个办法：
> 1. **邀请好友得 500 积分（推荐）**：打开 [https://cuecue.cn/](https://cuecue.cn/)，点击页面**左下角**「获取专属邀请链接」，分享给好友——好友加入后你再得 **500 积分**。
> 2. **直接充值**：前往 [cuecue.cn/pay](https://cuecue.cn/pay) 订阅（首次充值有优惠）；或等次日免费额度。

规则：
- 提示要**主动、简短、可点**——把「首页」和「左下角」两个关键动作说清楚，不要让用户自己找入口。
- 积分不足**不要重试**（`retryable: false`），也不要换 query 绕。
- 用户回复已充值/已邀请后，用**完全相同的命令**重跑。

### 决策树

```
出问题？
├─ Key 报错 → 由用户本人重新生成 → 更新 config.json → 重试
├─ 连不上 → curl /api/health 确认 → 检查 DNS/代理
├─ 搭子找不到 → curl /api/playbook → 等或用网页端
├─ 中途中断 → 相同 prompt 续接（不要删 ~/.cue/session/task）
└─ 结果空 → 缩窄关键词 → 确认该主题有公开数据
```

### 调度建议

| 时段 | 建议 |
|------|------|
| 交易日 10:00 | 定时跑的最佳时点（开盘 30 分钟后早盘热点已明朗） |
| 工作日 9-18 | 正常使用 |
| 夜间/周末 | 可能有维护，跑前先诊断 |
| 新 Key | 必须先诊断确认生效 |
| 连续失败 | 停 15 分钟再试，不要反复重试 |

---

## 降级方案

Cue 长时间不可达时的手动替代渠道：

| 渠道 | 覆盖 | 费用 |
|------|------|------|
| [东方财富](https://www.eastmoney.com) | A股资讯、公告 | 免费 |
| [华尔街见闻](https://wallstreetcn.com) | 全球财经快讯 | 免费 |
| [财联社](https://www.cls.cn) | 电报式财经资讯 | 免费 |
| [Reuters](https://www.reuters.com) | 国际财经新闻 | 免费 |

---

## FAQ

**Q: 和投顾早盘简报有什么区别？**
A: 早盘简报面向理财师生成客户沟通素材；热点追踪面向交易员做催化剂拆解和板块映射。

**Q: 能指定关注的行业吗？**
A: 可以，在 `--query` 中说明，例如"重点关注新能源和半导体方向"。

**Q: 报告能在网页端看原文吗？**
A: 能。交付时会附 `https://cuecue.cn/share/<conv_id>`，点开即可在网页端查看完整原文、继续追问或转发同事。

**Q: 提示积分不足怎么办？**
A: 打开 [https://cuecue.cn/](https://cuecue.cn/)，点击页面**左下角**「获取专属邀请链接」分享给好友——好友加入后你再得 **500 积分**（最快）；也可以前往 [cuecue.cn/pay](https://cuecue.cn/pay) 充值（首次充值有优惠），或等次日免费额度。

## 参考

- Cue 平台首页：https://cuecue.cn
- API Key 管理：https://cuecue.cn/hub/api-key
- 付费订阅页面：https://cuecue.cn/pay

出图相关文件：

- `scripts/render.py` —— 报告长图渲染器（Markdown → 长图）
- `scripts/render_dashboard.py` —— 看板图渲染器（SOP JSON → 看板长图）
- `references/sop-schema.md` —— 看板字段说明 + 「报告重排成 SOP JSON」指引
- `assets/intraday-sample.json` —— 盘中 SOP 样例
