---
name: skillhub-skill-slide-rebuild
description: "当用户要把截图转PPT、PDF转可编辑PPT、图片版PPT改字或重建流程图时使用。悦还原重建原生文字框、基础图形和连线；复杂区域保留图片。不从主题或大纲生成新演示，不输出原生统计图表。截图识别需要宿主视觉能力，运行需Python和Node.js。 悦系列 · 悦智AIGC组提供技术服务"
---

# 悦还原

V1：单张 PNG/JPG、原生 PDF 指定页面 -> 原生文字框、矩形/圆形/基础线条及独立图片对象。支持中文。保留原稿内容及比例；长报告提炼、原生统计图表、原生表格与复杂插画拆解不在本版范围。表格中的文字及基础线条可分开编辑。 悦系列 · 悦智AIGC组提供技术服务

## 执行入口

以下命令中的技能路径使用实际安装路径，`JOB` 使用用户工作区的新目录，引用含空格的路径。优先使用可运行的 `python`/`python3`，Windows 避免选择仅跳转商店的别名。

```bash
python "<技能目录>/scripts/slide_rebuild.py" doctor
python "<技能目录>/scripts/slide_rebuild.py" convert --input "<用户文件>" --output "<JOB>" --pages "2-5"
```

`--pages` 只用于 PDF，省略则处理全部（最多40页）。默认 `--renderer auto` 优先使用 LibreOffice，其次使用 Windows 已注册的 PowerPoint，否则明确记录未渲染。可指定 `--renderer powerpoint`；只读渲染生成文件，不修改用户源文件。

依赖缺失时按 [references/setup.md](references/setup.md) 使用现有运行时或安装到技能局部目录，然后重新检查。技能不访问模型 API、不索取 API Key、不自行上传文件到第三方。

## 截图和需要视觉处理的页面

`convert` 返回 `needs_vision` 是正常的分阶段结果，不是成功生成 PPT。打开 `JOB/scene.json` 以及对应 `JOB/source/page-NNN.png`。图片必须通过宿主的看图工具真实检查；不能根据文件名或示例猜测内容。读取 [references/scene-format.md](references/scene-format.md)，把图中可辨认的文字、形状、线条写入对应页面，按从底到顶的顺序排列。把已完成页面的 `status` 改为 `ready`。原生 PDF 的已完成页面保留，不能全部改成图片。

- 按视觉位置估计归一化坐标，保持原文、颜色、关系和原稿比例。
- 标题、段落、节点标签使用合理文字框，避免逐字创建对象。
- 原生 PDF 的 `font_size_source` 是原始坐标单位；看图估计的字号使用最终 PPT 的 `font_size_pt`。
- 照片、复杂插画和无法确认的公式可用 `crop` 命令裁成独立 PNG。不要把整页原图作背景再叠文字，避免改字后残留重影；裁剪区域内的文字不要另建重复文字框。
- 识别不清楚的数字和文字记录在页面 `warnings`（对象含 `code`、`message`）；不要杜撰数值。视觉识别受宿主模型能力和输入清晰度影响。
- 若宿主无法看图，说明截图识别所需能力缺失，保留任务目录；不能把整页图片 PPT 当作可编辑转换结果交付。

完成后：

```bash
python "<技能目录>/scripts/slide_rebuild.py" validate --job "<JOB>"
python "<技能目录>/scripts/slide_rebuild.py" build --job "<JOB>" --renderer auto
```

`scene.json` 可修正后重新 build。修正最多两轮；仍有问题就在结果里指出。

## 检查与交付

打开 `report.json`，读取真实的页数、原生对象计数、图片区域、字体映射及 `rendering.status`。已渲染时查看每页预览和原稿，重点核对数字、字形、换行、箭头方向、遗漏和遮挡。结构检查通过不等于外观检查通过；像素差异不是准确率。

交付 `result.pptx`、离线 `comparison.html` 和 `report.json` 的真实文件链接。说明哪些区域保留为图片、是否执行视觉检查。不要承诺100%还原，不把图片内部文字或SVG宣称为已可编辑，也不要声称在未实际测试的 PowerPoint/WPS/WorkBuddy 客户端验证过。
