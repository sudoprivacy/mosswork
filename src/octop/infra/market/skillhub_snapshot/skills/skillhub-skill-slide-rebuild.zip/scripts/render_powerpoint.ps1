param([Parameter(Mandatory=$true)][string]$InputPptx,
      [Parameter(Mandatory=$true)][string]$OutputDirectory,
      [int]$Width=1600, [int]$Height=900)
$ErrorActionPreference='Stop'
$ppt=$null
$deck=$null
$owned=$false
try {
    # Never attach to or modify an open user presentation.
    $ppt=New-Object -ComObject PowerPoint.Application
    $owned=($ppt.Presentations.Count -eq 0)
    $deck=$ppt.Presentations.Open([IO.Path]::GetFullPath($InputPptx),-1,0,0)
    [IO.Directory]::CreateDirectory([IO.Path]::GetFullPath($OutputDirectory)) | Out-Null
    for ($i=1; $i -le $deck.Slides.Count; $i++) {
        $name='page-{0:d3}.png' -f $i
        $deck.Slides.Item($i).Export((Join-Path $OutputDirectory $name),'PNG',$Width,$Height)
    }
} finally {
    if ($null -ne $deck) { $deck.Close(); [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($deck) }
    if ($null -ne $ppt) {
        if ($owned -and $ppt.Presentations.Count -eq 0) { $ppt.Quit() }
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($ppt)
    }
}
