'use strict';
const fs = require('node:fs');
const path = require('node:path');
// Prefer normal local dependencies. NODE_PATH is also supported by Node itself.
let PptxGenJS;
try { PptxGenJS = require('pptxgenjs'); }
catch (e) {
  console.error('Missing pptxgenjs 4.0.1. Run npm install in the skill folder.');
  process.exit(3);
}
if (process.argv[2] === '--doctor') {
  console.log(JSON.stringify({pptxgenjs: true, node: process.version}));
  process.exit(0);
}
async function main() {
  const [scenePath, target] = process.argv.slice(2);
  if (!scenePath || !target) throw Error('Usage: node build_pptx.cjs scene.json output.pptx');
  const scene = JSON.parse(fs.readFileSync(scenePath, 'utf8'));
  if (scene.validated !== true) throw Error('Use slide_rebuild.py build to validate the scene first.');
  const deck = new PptxGenJS();
  deck.defineLayout({name:'SOURCE', width:scene.slide_width_in, height:scene.slide_height_in});
  deck.layout = 'SOURCE';
  deck.author = 'Slide Rebuild'; deck.subject = 'Editable reconstruction';
  deck.title = 'Reconstructed slides'; deck.company = 'Slide Rebuild';
  deck.lang = 'zh-CN';
  const color = c => c.replace('#','').toUpperCase();
  for (const page of scene.pages) {
    const slide = deck.addSlide(); slide.background = {color:color(page.background)};
    const W=scene.slide_width_in, H=scene.slide_height_in;
    const scale=Math.min(W/page.width,H/page.height);
    const ox=(W-page.width*scale)/2, oy=(H-page.height*scale)/2;
    const box = b => ({x:ox+b[0]*page.width*scale, y:oy+b[1]*page.height*scale,
      w:Math.max(0.001,b[2]*page.width*scale), h:Math.max(0.001,b[3]*page.height*scale)});
    // Explicit z-order from the extractor/vision scene, never category sorting here.
    for (const e of page.elements) {
      const b=box(e.bbox), s=e.style || {}, name=`${e.id} (${e.type})`;
      if (e.type === 'text') {
        const fontPt=s.font_size_source ? s.font_size_source*scale*72 : s.font_size_pt;
        slide.addText(e.text, {...b,objectName:name,shapeName:name,
          fontFace:s.font_family || scene.font_family, fontSize:fontPt,
          bold:!!s.bold,italic:!!s.italic,color:color(s.color || '#000000'),
          align:s.align || 'left',valign:s.valign || 'top',margin:0,
          breakLine:false,paraSpaceAfterPt:0,lineSpacingMultiple:1.0,
          charSpacing:0,rotate:s.rotate || 0,
          // No automatic shrinking: render-and-compare catches problems explicitly.
          fit:'none',transparency:0,lang:'zh-CN'});
      } else if (e.type === 'shape') {
        const line={color:color(s.stroke || '#000000'),width:(s.stroke_width_source || 0)*scale*72,
          transparency:s.stroke ? 0 : 100};
        slide.addShape(deck.ShapeType[e.shape], {...b,shapeName:name,objectName:name,
          fill:{color:color(s.fill || '#FFFFFF'),transparency:s.fill ? 0 : 100},line,
          rotate:s.rotate || 0, radius:0.12});
      } else if (e.type === 'line') {
        const [x1,y1,x2,y2]=e.points;
        slide.addShape(deck.ShapeType.line, {
          x:ox+Math.min(x1,x2)*page.width*scale,y:oy+Math.min(y1,y2)*page.height*scale,
          w:Math.abs(x2-x1)*page.width*scale,h:Math.abs(y2-y1)*page.height*scale,
          flipH:x2<x1,flipV:y2<y1,shapeName:name,objectName:name,
          line:{color:color(s.stroke || '#000000'),width:Math.max(0.2,(s.stroke_width_source || 1)*scale*72),
            beginArrowType:e.start_arrow ? 'triangle' : undefined,
            endArrowType:e.end_arrow ? 'triangle' : undefined}});
      } else if (e.type === 'image') {
        // Assets have been decoded, bounded and copied to the job by Python.
        const absolute=path.resolve(path.dirname(scenePath), e.asset);
        const data='image/png;base64,'+fs.readFileSync(absolute).toString('base64');
        slide.addImage({...b,data,objectName:name,altText:e.reason || 'Preserved raster region'});
      }
    }
    slide.addNotes('Reconstructed from source page '+page.source_page+'. '+
      'Raster regions: '+page.elements.filter(e=>e.type==='image').length+
      '. See report.json for limitations.');
  }
  await deck.writeFile({fileName:target});
  console.log(JSON.stringify({output:target,pages:scene.pages.length}));
}
main().catch(e=>{ console.error(e.message); process.exit(2); });
