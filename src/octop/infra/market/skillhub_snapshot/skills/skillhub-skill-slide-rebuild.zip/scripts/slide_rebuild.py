#!/usr/bin/env python3
"""Portable staged screenshot/native-PDF -> editable PPTX workflow. No model API keys."""
from __future__ import annotations

import argparse
import base64
from collections import Counter
import hashlib
import html
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
if (ROOT / "_vendor").is_dir():
    sys.path.insert(0, str(ROOT / "_vendor"))
VERSION = "1.0.1"
MAX_PAGES = 40
MAX_PIXELS = 40_000_000
MAX_ELEMENTS = 2000
COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
NAMESPACES = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
              "a": "http://schemas.openxmlformats.org/drawingml/2006/main"}


class RebuildError(ValueError):
    pass


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path):
    if Path(path).stat().st_size > 12_000_000:
        raise RebuildError("JSON exceeds 12 MB")
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha256(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def number(value, label, low=None, high=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise RebuildError(f"{label} must be a finite number")
    if low is not None and value < low or high is not None and value > high:
        raise RebuildError(f"{label} outside supported range [{low}, {high}]")
    return value


def local_path(root, relative):
    if not isinstance(relative, str) or Path(relative).is_absolute():
        raise RebuildError("Assets must use job-relative paths")
    root = Path(root).resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise RebuildError(f"Missing asset or asset outside job: {relative}")
    return path


def dependencies():
    missing = [m for m in ("pdfplumber", "pypdfium2", "PIL") if importlib.util.find_spec(m) is None]
    if missing:
        raise RebuildError("Missing Python packages: " + ", ".join(missing) +
                           f". Install: {sys.executable} -m pip install -r \"{ROOT / 'requirements.txt'}\"")


def doctor():
    modules = {m: importlib.util.find_spec(m) is not None for m in ("pdfplumber", "pypdfium2", "PIL")}
    node = shutil.which("node")
    result = {"version": VERSION, "python": sys.version.split()[0], "python_modules": modules,
              "node": node, "soffice": find_soffice(),
              "powerpoint_registered": powerpoint_available(),
              "screenshot_recognition": "WorkBuddy host vision; no separate model API required",
              "rendering": "Optional PowerPoint on Windows or LibreOffice"}
    if node:
        check = subprocess.run([node, str(ROOT / "scripts/build_pptx.cjs"), "--doctor"],
                               capture_output=True, text=True, encoding="utf-8", timeout=20)
        result["pptxgenjs"] = check.returncode == 0
        if check.returncode:
            result["node_hint"] = "Run npm install in the skill folder, then retry."
    else:
        result["pptxgenjs"] = False
    result["ready"] = all(modules.values()) and bool(node) and result["pptxgenjs"]
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ready"] else 3


def rgb(value, default=None):
    if value is None:
        return default
    if isinstance(value, (int, float)):
        values = [value] * 3
    else:
        values = list(value)
        if len(values) == 1:
            values *= 3
        if len(values) == 4:
            c, m, y, k = values
            values = [1 - min(1, c+k), 1-min(1, m+k), 1-min(1, y+k)]
    if len(values) != 3:
        return default
    return "#" + "".join(f"{round(max(0, min(1, v))*255):02X}" for v in values)


def font_family():
    if os.name == "nt":
        return "Microsoft YaHei"
    if sys.platform == "darwin":
        return "PingFang SC"
    return "Noto Sans CJK SC"


def map_font(name):
    name = re.sub(r"^[A-Z]{6}\+", "", name or "")
    for needle, family in (("arial", "Arial"), ("helvetica", "Arial"), ("times", "Times New Roman"),
                           ("courier", "Courier New"), ("yahei", "Microsoft YaHei"),
                           ("simhei", "SimHei"), ("simsun", "SimSun"), ("pingfang", "PingFang SC")):
        if needle in name.lower():
            return family
    return font_family()


def box_for(obj, w, h):
    left = max(0, min(w, float(obj["x0"])))
    top = max(0, min(h, float(obj["top"])))
    right = max(left, min(w, float(obj["x1"])))
    bottom = max(top, min(h, float(obj["bottom"])))
    return [left / w, top / h, (right-left) / w, (bottom-top) / h]


def intersects(a, b, eps=0.00005):
    return min(a[0]+a[2], b[0]+b[2])-max(a[0], b[0]) > eps and \
           min(a[1]+a[3], b[1]+b[3])-max(a[1], b[1]) > eps


def union(a, b):
    x, y = min(a[0], b[0]), min(a[1], b[1])
    return [x, y, max(a[0]+a[2], b[0]+b[2])-x, max(a[1]+a[3], b[1]+b[3])-y]


def render_pdf_page(page, max_width=1600):
    w, h = page.get_size()
    scale = min(max_width / max(w, h), 2.5)
    bitmap = page.render(scale=scale)
    try:
        return bitmap.to_pil().convert("RGB").copy()
    finally:
        bitmap.close()


def selected_pages(spec, count):
    if spec is None:
        values = list(range(1, count+1))
    else:
        values = []
        for part in spec.split(","):
            match = re.fullmatch(r"\s*(\d+)(?:\s*-\s*(\d+))?\s*", part)
            if not match:
                raise RebuildError("Pages must look like 1,3-5")
            start, end = int(match[1]), int(match[2] or match[1])
            if start < 1 or end < start or end > count:
                raise RebuildError(f"Page range outside 1..{count}")
            values.extend(range(start, end+1))
        values = list(dict.fromkeys(values))
    if not values or len(values) > MAX_PAGES:
        raise RebuildError(f"Choose between 1 and {MAX_PAGES} pages")
    return values


def extract_text(page, warnings):
    """Merge horizontal characters by baseline, then split distant columns and styles."""
    chars = [c for c in page.dedupe_chars(tolerance=0.5).chars if c.get("text", "").strip()]
    horizontal = [c for c in chars if c.get("upright", True)]
    rows = []
    for c in sorted(horizontal, key=lambda c: (round(c["top"], 1), c["x0"])):
        row = next((r for r in reversed(rows[-8:])
                    if abs(r[0]["top"]-c["top"]) <= max(1.5, c["size"]*0.15)), None)
        if row is None:
            rows.append([c])
        else:
            row.append(c)
    result = []
    for row in rows:
        groups = []
        for c in sorted(row, key=lambda c: c["x0"]):
            if not groups:
                groups.append([c]); continue
            prev = groups[-1][-1]
            if c["x0"]-prev["x1"] > max(c["size"]*1.5, 12) or \
               c["fontname"] != prev["fontname"] or abs(c["size"]-prev["size"]) > 0.5 or \
               rgb(c.get("non_stroking_color")) != rgb(prev.get("non_stroking_color")):
                groups.append([c])
            else:
                groups[-1].append(c)
        for group in groups:
            text = ""
            previous = None
            for c in group:
                if previous and c["x0"]-previous["x1"] > max(0.8, c["size"]*0.15):
                    text += " "
                text += c["text"]
                previous = c
            c = group[0]
            # PDF glyph bounds are tighter than an Office line box; preserve the top anchor
            # and give the font its em height to avoid clipping descenders.
            x0, x1 = min(x["x0"] for x in group), max(x["x1"] for x in group)
            top = min(x["top"] for x in group)
            size = max(x["size"] for x in group)
            b = box_for({"x0": x0, "x1": min(page.width, x1+size*0.20), "top": top,
                         "bottom": min(page.height, top+size*1.35)}, page.width, page.height)
            result.append({"type": "text", "bbox": b, "text": text,
                           "style": {"font_family": map_font(c["fontname"]), "font_size_source": size,
                                     "bold": any(s in c["fontname"].lower() for s in ("bold", "black", "heavy")),
                                     "italic": any(s in c["fontname"].lower() for s in ("italic", "oblique")),
                                     "color": rgb(c.get("non_stroking_color"), "#000000")},
                           "source_method": "pdf_text"})
    substitutions = sorted({(c["fontname"], map_font(c["fontname"])) for c in horizontal})
    if substitutions:
        warnings.append({"code": "font_mapping", "details": [list(x) for x in substitutions],
                         "message": "字体按本机字体映射；字形与换行需检查。"})
    return result, [c for c in chars if not c.get("upright", True)]


def extract_page(page, preview, index, job):
    warnings = [{"code": "paint_order_approximation", "message": "复杂遮挡、透明度和剪裁可能近似重建，需对照预览。"}]
    texts, rotated = extract_text(page, warnings)
    shapes, fallback = [], []
    background = "#FFFFFF"
    w, h = page.width, page.height
    for obj in page.rects:
        b = box_for(obj, w, h)
        if not b[2] or not b[3]:
            continue
        style = {"fill": rgb(obj.get("non_stroking_color")) if obj.get("fill") else None,
                 "stroke": rgb(obj.get("stroking_color"), "#000000") if obj.get("stroke") else None,
                 "stroke_width_source": obj.get("linewidth", 1) or 1}
        if b[0] < 0.001 and b[1] < 0.001 and b[2] > 0.998 and b[3] > 0.998 and style["fill"]:
            background = style["fill"]
            continue
        shapes.append({"type": "shape", "shape": "rect", "bbox": b, "style": style,
                       "source_method": "pdf_rect"})
    for obj in page.lines:
        pts = obj.get("pts", [])
        if len(pts) < 2:
            continue
        (x1, y1), (x2, y2) = pts[0], pts[-1]
        if max(abs(x1-x2), abs(y1-y2)) < 0.05:
            continue
        points = [max(0, min(1, x1/w)), max(0, min(1, y1/h)),
                  max(0, min(1, x2/w)), max(0, min(1, y2/h))]
        b = [min(points[0], points[2]), min(points[1], points[3]),
             abs(points[2]-points[0]), abs(points[3]-points[1])]
        shapes.append({"type": "line", "bbox": b, "points": points,
                       "style": {"stroke": rgb(obj.get("stroking_color"), "#000000"),
                                 "stroke_width_source": obj.get("linewidth", 1) or 1},
                       "source_method": "pdf_line"})
    for obj in page.curves:
        b = box_for(obj, w, h)
        if b[2]*b[3] < 1e-8:
            continue
        ops = [p[0] for p in obj.get("path", [])]
        # Recognize only canonical four-cubic ellipses; arbitrary paths stay raster.
        shape = "ellipse" if ops.count("c") == 4 and ops.count("l") == 0 and ops.count("m") == 1 else None
        if shape:
            shapes.append({"type": "shape", "shape": shape, "bbox": b,
                           "style": {"fill": rgb(obj.get("non_stroking_color")) if obj.get("fill") else None,
                                     "stroke": rgb(obj.get("stroking_color"), "#000000") if obj.get("stroke") else None,
                                     "stroke_width_source": obj.get("linewidth", 1) or 1},
                           "source_method": "pdf_curve_approximation"})
        else:
            fallback.append(b)
    fallback.extend(box_for(obj, w, h) for obj in page.images)
    fallback.extend(box_for(obj, w, h) for obj in rotated)
    fallback = [b for b in fallback if b[2] > 0 and b[3] > 0]
    # Grow raster regions to cover complete intersecting text/shape objects. This
    # prevents editable text overlaying its own baked-in copy in a source crop.
    candidates = shapes + texts
    changed = True
    while changed:
        changed = False
        for i in range(len(fallback)):
            current = fallback[i]
            for e in candidates:
                if intersects(current, e["bbox"]):
                    enlarged = union(current, e["bbox"])
                    if any(abs(a-b) > 1e-7 for a, b in zip(current, enlarged)):
                        current = enlarged; changed = True
            fallback[i] = current
        for i in range(len(fallback)):
            for j in range(i+1, len(fallback)):
                if intersects(fallback[i], fallback[j]):
                    fallback[i] = union(fallback[i], fallback[j]); fallback.pop(j)
                    changed = True; break
            if changed:
                break
    native = [e for e in candidates if not any(intersects(e["bbox"], b) for b in fallback)]
    raster = []
    for i, b in enumerate(fallback):
        px = (math.floor(b[0]*preview.width), math.floor(b[1]*preview.height),
              math.ceil((b[0]+b[2])*preview.width), math.ceil((b[1]+b[3])*preview.height))
        asset = f"assets/page-{index:03}-region-{i+1:03}.png"
        preview.crop(px).save(job / asset)
        raster.append({"type": "image", "bbox": b, "asset": asset,
                       "reason": "复杂路径、图片或旋转文字区域保留为图片；区域内文字不可单独编辑。"})
    if raster:
        warnings.append({"code": "raster_regions", "count": len(raster),
                         "message": "部分区域保留为独立图片，内部元素不可编辑。"})
    if any("(cid:" in e.get("text", "") or "\ufffd" in e.get("text", "") for e in texts):
        warnings.append({"code": "unreliable_text_encoding", "message": "PDF 字符编码异常，需要看图重建。"})
    elements = native + raster
    # PDF paint order is not fully exposed by this extractor. Graphics first,
    # then preserved regions, then editable text, retaining order within each.
    elements.sort(key=lambda e: 2 if e["type"] == "text" else 1 if e["type"] == "image" else 0)
    for i, e in enumerate(elements):
        e["id"] = f"p{index}-e{i+1}"
    needs_vision = not any(e["type"] == "text" for e in native) or any(
        warning["code"] == "unreliable_text_encoding" for warning in warnings)
    return {"source_page": page.page_number, "width": w, "height": h,
            "source_image": f"source/page-{index:03}.png", "background": background,
            "status": "needs_vision" if needs_vision else "ready",
            "elements": elements, "warnings": warnings}


def prepare(input_path, output, pages=None):
    dependencies()
    from PIL import Image, ImageOps
    source, job = Path(input_path).resolve(), Path(output).resolve()
    if not source.is_file():
        raise RebuildError(f"Input not found: {source}")
    if source.stat().st_size > 150_000_000:
        raise RebuildError("Input exceeds 150 MB")
    if job.exists() and any(job.iterdir()):
        raise RebuildError("Choose a new or empty output directory; existing jobs are never overwritten by prepare")
    kind = source.suffix.lower()
    if kind not in (".pdf", ".png", ".jpg", ".jpeg"):
        raise RebuildError("V1 supports PDF, PNG and JPG only")
    if source.is_relative_to(job):
        raise RebuildError("Input must be outside the output directory")
    job.mkdir(parents=True, exist_ok=True)
    (job / "source").mkdir(exist_ok=True); (job / "assets").mkdir(exist_ok=True)
    result = {"schema_version": "1.0", "font_family": font_family(), "pages": []}
    if kind == ".pdf":
        import pdfplumber
        import pypdfium2 as pdfium
        with pdfplumber.open(source) as pdf:
            selected = selected_pages(pages, len(pdf.pages))
            doc = pdfium.PdfDocument(str(source))
            try:
                for i, page_num in enumerate(selected, 1):
                    pdf_page = doc[page_num-1]
                    try:
                        preview = render_pdf_page(pdf_page)
                    finally:
                        pdf_page.close()
                    preview.save(job / f"source/page-{i:03}.png")
                    result["pages"].append(extract_page(pdf.pages[page_num-1], preview, i, job))
            finally:
                doc.close()
    else:
        if pages:
            raise RebuildError("--pages applies only to PDF")
        with Image.open(source) as raw:
            if raw.width*raw.height > MAX_PIXELS:
                raise RebuildError("Screenshot exceeds 40 megapixels")
            image = ImageOps.exif_transpose(raw).convert("RGBA")
            bg = Image.new("RGBA", image.size, "white"); bg.alpha_composite(image)
            image = bg.convert("RGB")
        image.save(job / "source/page-001.png")
        result["pages"].append({"source_page": 1, "width": image.width, "height": image.height,
            "source_image": "source/page-001.png", "background": "#FFFFFF", "status": "needs_vision",
            "elements": [], "warnings": [{"code": "host_vision_required",
                "message": "请 WorkBuddy 看图后按 references/scene-format.md 填写页面元素；不能直接把整页图片作为结果。"}]})
    first = result["pages"][0]
    result["slide_width_in"] = 13.333333 if first["width"] >= first["height"] else 7.5
    result["slide_height_in"] = result["slide_width_in"]*first["height"]/first["width"]
    # Office supports slide dimensions in [1, 56] inches.
    if not 1 <= result["slide_height_in"] <= 56:
        raise RebuildError("Extreme page aspect ratio; crop the source before conversion")
    manifest = {"version": VERSION, "source_name": source.name, "source_sha256": sha256(source),
                "input_kind": kind.lstrip("."), "page_count": len(result["pages"]),
                "source_images": {p["source_image"]: sha256(job / p["source_image"]) for p in result["pages"]}}
    write_json(job / "job.json", manifest); write_json(job / "scene.json", result)
    pending = [p["source_page"] for p in result["pages"] if p["status"] != "ready"]
    return {"job": str(job), "scene": str(job / "scene.json"), "pages": len(result["pages"]),
            "status": "needs_vision" if pending else "ready", "needs_vision_pages": pending}


def validate_scene(scene, job):
    from PIL import Image
    if not isinstance(scene, dict):
        raise RebuildError("Scene must be a JSON object")
    if scene.get("schema_version") != "1.0":
        raise RebuildError("Unsupported scene schema_version")
    for key in ("slide_width_in", "slide_height_in"):
        number(scene.get(key), key, 1, 56)
    if not isinstance(scene.get("font_family"), str) or not scene["font_family"].strip():
        raise RebuildError("font_family is required")
    pages = scene.get("pages")
    if not isinstance(pages, list) or not 1 <= len(pages) <= MAX_PAGES:
        raise RebuildError("Invalid number of pages")
    for i, page in enumerate(pages, 1):
        if not isinstance(page, dict):
            raise RebuildError("Each page must be an object")
        if page.get("status") != "ready":
            raise RebuildError(f"Page {i} needs host vision. Read references/scene-format.md and fill scene.json first")
        number(page.get("width"), "width", 1, 100000)
        number(page.get("height"), "height", 1, 100000)
        number(page.get("source_page"), "source_page", 1, 100000)
        if not COLOR.fullmatch(page.get("background", "")):
            raise RebuildError("Invalid background color")
        local_path(job, page.get("source_image"))
        warnings = page.get("warnings", [])
        if not isinstance(warnings, list) or any(not isinstance(w, dict) or not isinstance(w.get("message", ""), str) for w in warnings):
            raise RebuildError("warnings must contain objects with string messages")
        elements = page.get("elements")
        if not isinstance(elements, list) or not 1 <= len(elements) <= MAX_ELEMENTS:
            raise RebuildError(f"Page {i} must have 1..{MAX_ELEMENTS} elements")
        ids = set()
        for e in elements:
            if not isinstance(e, dict):
                raise RebuildError("Each element must be an object")
            eid = e.get("id")
            if not isinstance(eid, str) or not eid or eid in ids:
                raise RebuildError("Element IDs must be unique nonempty strings per page")
            ids.add(eid)
            if e.get("type") not in ("text", "shape", "line", "image"):
                raise RebuildError(f"Unsupported element type: {e.get('type')}")
            b = e.get("bbox")
            if not isinstance(b, list) or len(b) != 4:
                raise RebuildError(f"{eid}: bbox must be [x,y,w,h]")
            for v in b:
                number(v, f"{eid} bbox", 0, 1)
            if b[0]+b[2] > 1.00001 or b[1]+b[3] > 1.00001:
                raise RebuildError(f"{eid}: bbox outside page")
            if e["type"] != "line" and (b[2] <= 0 or b[3] <= 0):
                raise RebuildError(f"{eid}: zero-size object")
            style = e.get("style", {})
            if not isinstance(style, dict):
                raise RebuildError("style must be an object")
            for k in ("color", "fill", "stroke"):
                if style.get(k) is not None and (not isinstance(style[k], str) or not COLOR.fullmatch(style[k])):
                    raise RebuildError(f"{eid}: invalid {k}")
            for k in ("bold", "italic"):
                if k in style and not isinstance(style[k], bool):
                    raise RebuildError(f"{eid}: {k} must be boolean")
            if "rotate" in style:
                number(style["rotate"], "rotate", 0, 360)
            if "stroke_width_source" in style:
                number(style["stroke_width_source"], "stroke_width_source", 0, 500)
            if e["type"] == "text":
                if not isinstance(e.get("text"), str) or not e["text"] or len(e["text"]) > 20000:
                    raise RebuildError(f"{eid}: empty/oversized text")
                if any(ord(c) < 32 and c not in "\n\t\r" for c in e["text"]):
                    raise RebuildError(f"{eid}: invalid control character")
                if "font_size_source" in style:
                    number(style["font_size_source"], "font_size_source", 0.1, 10000)
                else:
                    number(style.get("font_size_pt"), "font_size_pt", 1, 400)
                if style.get("align", "left") not in ("left", "center", "right"):
                    raise RebuildError("Unsupported text alignment")
                if style.get("valign", "top") not in ("top", "mid", "bottom"):
                    raise RebuildError("Unsupported text vertical alignment")
                if "font_family" in style and (not isinstance(style["font_family"], str) or not style["font_family"].strip()):
                    raise RebuildError("font_family must be a nonempty string")
            elif e["type"] == "shape" and e.get("shape") not in ("rect", "roundRect", "ellipse", "triangle", "chevron", "diamond"):
                raise RebuildError(f"{eid}: unsupported shape")
            elif e["type"] == "line":
                pts = e.get("points")
                if not isinstance(pts, list) or len(pts) != 4:
                    raise RebuildError("Line needs points [x1,y1,x2,y2]")
                for v in pts:
                    number(v, "line point", 0, 1)
                if abs(pts[0]-pts[2])+abs(pts[1]-pts[3]) < 1e-8:
                    raise RebuildError("Line cannot have zero length")
                for key in ("start_arrow", "end_arrow"):
                    if key in e and not isinstance(e[key], bool):
                        raise RebuildError("Arrow flags must be boolean")
            elif e["type"] == "image":
                asset = local_path(job, e.get("asset"))
                with Image.open(asset) as im:
                    if im.width*im.height > MAX_PIXELS:
                        raise RebuildError("Image asset too large")
                    im.verify()
                if asset.suffix.lower() != ".png":
                    raise RebuildError("Use crop command to produce PNG assets")
        if not any(e["type"] != "image" for e in elements):
            raise RebuildError(f"Page {i}: image-only output is not an editable reconstruction")
    return scene


def inspect_pptx(path):
    pages = []
    with ZipFile(path) as z:
        slide_names = sorted((n for n in z.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                             key=lambda n: int(re.search(r"slide(\d+)", n)[1]))
        for name in slide_names:
            root = ET.fromstring(z.read(name))
            texts = ["".join(x.itertext()) for x in root.findall(".//a:t", NAMESPACES)]
            objects = root.findall(".//p:sp", NAMESPACES)
            text_boxes = sum(1 for s in objects if s.find("p:txBody", NAMESPACES) is not None)
            line_shapes = sum(1 for s in objects if s.find("p:spPr/a:prstGeom", NAMESPACES) is not None
                              and s.find("p:spPr/a:prstGeom", NAMESPACES).get("prst") == "line")
            connectors = len(root.findall(".//p:cxnSp", NAMESPACES))
            pages.append({"native_text_runs": len(texts), "text": "\n".join(texts),
                          "native_objects": len(objects)+connectors,
                          "native_text_boxes": text_boxes,
                          "native_shapes": len(objects)-text_boxes-line_shapes,
                          "native_lines": line_shapes+connectors,
                          "pictures": len(root.findall(".//p:pic", NAMESPACES))})
        corrupt = z.testzip()
        if corrupt:
            raise RebuildError(f"Corrupt PPTX entry: {corrupt}")
    return pages


def find_soffice():
    found = shutil.which("soffice") or shutil.which("libreoffice")
    if found:
        return found
    for value in (r"C:\Program Files\LibreOffice\program\soffice.exe",
                  "/Applications/LibreOffice.app/Contents/MacOS/soffice"):
        if Path(value).is_file():
            return value
    return None


def powerpoint_available():
    if os.name != "nt":
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"PowerPoint.Application\CLSID"):
            return True
    except OSError:
        return False


def render_pptx(job, scene, renderer):
    """Render with a real Office-compatible engine; never label scene drawing as PPT rendering."""
    if renderer == "none":
        return {"status": "not_rendered", "engine": None, "message": "未执行视觉检查。"}
    selected = renderer
    if selected == "auto":
        selected = "libreoffice" if find_soffice() else "powerpoint" if powerpoint_available() else "none"
    if selected == "none":
        return {"status": "not_rendered", "engine": None,
                "message": "未找到可用的 LibreOffice 或 Windows PowerPoint，未执行视觉检查。"}
    target = job / "preview"
    target.mkdir(exist_ok=True)
    ratio = scene["slide_height_in"] / scene["slide_width_in"]
    width, height = (1600, round(1600*ratio)) if ratio <= 1 else (round(1600/ratio), 1600)
    try:
        if selected == "powerpoint":
            if os.name != "nt":
                raise RebuildError("PowerPoint renderer requires Windows desktop PowerPoint")
            shell = shutil.which("pwsh") or shutil.which("powershell")
            if not shell:
                raise RebuildError("PowerShell not found")
            # Execute trusted packaged source as a command, without changing any
            # machine execution policy. Paths travel in env vars, never shell text.
            script = (ROOT / "scripts/render_powerpoint.ps1").read_text(encoding="utf-8")
            command = "& {\n"+script+"\n} -InputPptx $env:SLIDE_REBUILD_INPUT -OutputDirectory $env:SLIDE_REBUILD_PREVIEW -Width $env:SLIDE_REBUILD_WIDTH -Height $env:SLIDE_REBUILD_HEIGHT"
            env = os.environ.copy()
            env.update({"SLIDE_REBUILD_INPUT": str(job / "result.pptx"), "SLIDE_REBUILD_PREVIEW": str(target),
                        "SLIDE_REBUILD_WIDTH": str(width), "SLIDE_REBUILD_HEIGHT": str(height)})
            cmd = [shell, "-NoProfile", "-Command", command]
            run = subprocess.run(cmd, capture_output=True, timeout=120, env=env)
            if run.returncode:
                raise RebuildError(run.stderr.decode("utf-8", errors="replace")[-1500:])
        else:
            binary = find_soffice()
            if not binary:
                raise RebuildError("LibreOffice not found")
            import pypdfium2 as pdfium
            # Unique user profile prevents interference with an existing LO session.
            with tempfile.TemporaryDirectory(prefix="slide-rebuild-lo-") as directory:
                cmd = [binary, "-env:UserInstallation=" + Path(directory).as_uri(), "--headless",
                       "--convert-to", "pdf", "--outdir", str(target), str(job / "result.pptx")]
                run = subprocess.run(cmd, capture_output=True, timeout=120)
                pdf_path = target / "result.pdf"
                if run.returncode or not pdf_path.is_file():
                    raise RebuildError("LibreOffice failed to export the PPTX")
                doc = pdfium.PdfDocument(str(pdf_path))
                try:
                    for i in range(len(doc)):
                        page = doc[i]
                        try:
                            im = render_pdf_page(page)
                            im.save(target / f"page-{i+1:03}.png")
                        finally:
                            page.close()
                finally:
                    doc.close()
        expected = [target / f"page-{i+1:03}.png" for i in range(len(scene["pages"]))]
        if not all(p.is_file() for p in expected):
            raise RebuildError("Renderer did not produce every slide")
        return {"status": "rendered", "engine": selected,
                "message": "已生成真实 PPT 渲染图；自动差异指标不能替代人工核对。"}
    except (OSError, subprocess.SubprocessError, RebuildError) as e:
        return {"status": "render_failed", "engine": selected, "message": str(e)}


def image_uri(path):
    return "data:image/png;base64," + base64.b64encode(Path(path).read_bytes()).decode("ascii")


def comparison(job, scene, report):
    from PIL import Image, ImageChops, ImageStat
    rows = []
    for i, page in enumerate(scene["pages"], 1):
        source = local_path(job, page["source_image"])
        preview = job / f"preview/page-{i:03}.png"
        rendered = report["rendering"]["status"] == "rendered" and preview.is_file()
        original_uri = image_uri(source)
        right = '<p class="pending">未执行或未完成 PPT 渲染检查</p>'
        metric = ""
        if rendered:
            with Image.open(source) as raw, Image.open(preview) as generated:
                # Compare after applying the same letterboxing as the PPT generator.
                a = raw.convert("RGB"); b = generated.convert("RGB").resize((800, max(1, round(800*generated.height/generated.width))))
                scale = min(b.width/a.width, b.height/a.height)
                a = a.resize((max(1, round(a.width*scale)), max(1, round(a.height*scale))))
                canvas = Image.new("RGB", b.size, page["background"])
                canvas.paste(a, ((b.width-a.width)//2, (b.height-a.height)//2))
                difference = ImageChops.difference(canvas, b)
                mae = sum(ImageStat.Stat(difference).mean)/(3*255)
                report["pages"][i-1]["pixel_mean_absolute_error"] = round(mae, 5)
                difference.save(job / f"preview/diff-{i:03}.png")
                metric = f"像素平均绝对差异：{mae:.4f}（越低越接近；不代表文字正确率）"
            right = f'<img alt="生成页面" src="{image_uri(preview)}">'
        stats = report["pages"][i-1]
        warning_text = "；".join(str(w.get("message", w.get("code", ""))) for w in stats["warnings"])
        rows.append(f'<section><h2>第 {i} 页 · 来源第 {page["source_page"]} 页</h2>'
                    f'<p>可编辑文字 {stats["elements"].get("text",0)} 个；图形/线条 '
                    f'{stats["elements"].get("shape",0)+stats["elements"].get("line",0)} 个；'
                    f'图片区域 {stats["elements"].get("image",0)} 个。</p>'
                    f'<div class="pair"><figure><figcaption>原稿</figcaption><img alt="原稿" src="{original_uri}"></figure>'
                    f'<figure><figcaption>生成的 PPT</figcaption>{right}</figure></div>'
                    f'<p>{html.escape(metric)}</p><p>{html.escape(warning_text)}</p></section>')
    content = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width">'
    content += '<title>幻灯片还原检查</title><style>body{font:15px/1.6 system-ui;margin:24px;background:#f4f6fa;color:#19304b}'
    content += 'section{background:white;padding:20px;margin:20px 0}.pair{display:grid;grid-template-columns:1fr 1fr;gap:18px}'
    content += 'figure{margin:0}img{width:100%;height:auto;border:1px solid #dde3ee}figcaption{font-weight:bold}.pending{padding:30px;background:#fff3d1}'
    content += '@media(max-width:800px){.pair{grid-template-columns:1fr}}</style><h1>幻灯片还原检查</h1>'
    content += '<p>文字、基础图形可编辑；照片与复杂区域保留为独立图片。请核对数字、换行与重叠区域。</p>'
    content += ''.join(rows) + '</html>'
    (job / "comparison.html").write_text(content, encoding="utf-8")


def check_manifest(job, scene):
    manifest = read_json(job / "job.json")
    if len(scene["pages"]) != manifest["page_count"]:
        raise RebuildError("Scene page count differs from prepared job")
    images = [p["source_image"] for p in scene["pages"]]
    if len(set(images)) != len(images) or set(images) != set(manifest["source_images"]):
        raise RebuildError("Scene must retain every prepared source page exactly once")
    for page in scene["pages"]:
        relative = page["source_image"]
        expected = manifest["source_images"].get(relative)
        if expected is None or sha256(local_path(job, relative)) != expected:
            raise RebuildError("Source image changed or does not belong to this job")
    return manifest


def build(job_path, renderer="auto"):
    dependencies()
    job = Path(job_path).resolve()
    scene = validate_scene(read_json(job / "scene.json"), job)
    manifest = check_manifest(job, scene)
    node = shutil.which("node")
    if not node:
        raise RebuildError("Node.js is required to build PPTX")
    # Never trust user-supplied validated flags; set it only in the private build input.
    scene["validated"] = True
    build_path = job / "_validated-scene.json"
    write_json(build_path, scene)
    # Invalidate old previews before a rebuild, so stale renders cannot look current.
    preview_dir = job / "preview"
    if preview_dir.is_dir():
        for p in preview_dir.glob("page-*.png"):
            p.unlink()
    temporary = job / "_result.pptx"
    try:
        run = subprocess.run([node, str(ROOT / "scripts/build_pptx.cjs"), str(build_path), str(temporary)],
                             capture_output=True, text=True, encoding="utf-8", timeout=180)
        if run.returncode:
            raise RebuildError(run.stderr.strip() or "PPTX generation failed")
        actual = inspect_pptx(temporary)
        if len(actual) != len(scene["pages"]):
            raise RebuildError("PPTX page count mismatch")
        for page, observed in zip(scene["pages"], actual):
            expected = "".join(e["text"] for e in page["elements"] if e["type"] == "text")
            if re.sub(r"\s", "", expected) != re.sub(r"\s", "", observed["text"]):
                raise RebuildError("Generated PPTX text differs from scene")
            if observed["native_objects"] == 0:
                raise RebuildError("Generated page contains no native editable objects")
        temporary.replace(job / "result.pptx")
    finally:
        if temporary.exists():
            temporary.unlink()
    rendering = render_pptx(job, scene, renderer)
    report = {"version": VERSION, "source_sha256": manifest["source_sha256"],
              "source_name": manifest["source_name"], "pptx_sha256": sha256(job / "result.pptx"),
              "scene_sha256": sha256(job / "scene.json"), "page_count": len(scene["pages"]),
              "structural_check": "passed", "rendering": rendering, "pages": []}
    for i, (page, observed) in enumerate(zip(scene["pages"], actual), 1):
        warnings = list(page.get("warnings", []))
        if any(e["type"] == "image" and e["bbox"][2]*e["bbox"][3] > .8 for e in page["elements"]):
            warnings.append({"code": "large_raster_region", "message": "大面积区域仍为图片，整体可编辑程度有限。"})
        report["pages"].append({"page": i, "source_page": page["source_page"],
            "elements": dict(Counter(e["type"] for e in page["elements"])),
            "pptx_objects": {k: v for k, v in observed.items() if k != "text"},
            "warnings": warnings})
    comparison(job, scene, report)
    write_json(job / "report.json", report)
    return {"status": "built", "pptx": str(job / "result.pptx"), "comparison": str(job / "comparison.html"),
            "report": str(job / "report.json"), "page_count": len(scene["pages"]), "rendering": rendering}


def crop(job_path, page_number, box, name):
    dependencies()
    from PIL import Image
    job = Path(job_path).resolve()
    scene = read_json(job / "scene.json")
    if not 1 <= page_number <= len(scene["pages"]):
        raise RebuildError("Invalid job page number")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
        raise RebuildError("Crop name must contain only letters, digits, underscores or hyphens")
    if len(box) != 4:
        raise RebuildError("Crop bbox must be x,y,w,h")
    x, y, w, h = [number(v, "crop bbox", 0, 1) for v in box]
    if w <= 0 or h <= 0 or x+w > 1.00001 or y+h > 1.00001:
        raise RebuildError("Crop outside page")
    target = job / f"assets/{name}.png"
    if target.exists():
        raise RebuildError("Crop name already exists; choose a new name")
    with Image.open(local_path(job, scene["pages"][page_number-1]["source_image"])) as image:
        image.crop((math.floor(x*image.width), math.floor(y*image.height), math.ceil((x+w)*image.width),
                    math.ceil((y+h)*image.height))).save(target)
    return {"asset": f"assets/{name}.png", "bbox": box}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor", help="Check dependencies without changing the environment")
    for command in ("prepare", "convert"):
        p = sub.add_parser(command)
        p.add_argument("--input", required=True); p.add_argument("--output", required=True)
        p.add_argument("--pages", help="1-based page selection, e.g. 1,3-5")
        if command == "convert":
            p.add_argument("--renderer", choices=("auto", "none", "libreoffice", "powerpoint"), default="auto")
    for command in ("build", "validate"):
        p = sub.add_parser(command); p.add_argument("--job", required=True)
        if command == "build":
            p.add_argument("--renderer", choices=("auto", "none", "libreoffice", "powerpoint"), default="auto")
    p = sub.add_parser("crop"); p.add_argument("--job", required=True)
    p.add_argument("--page", required=True, type=int); p.add_argument("--bbox", required=True)
    p.add_argument("--name", required=True)
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            return doctor()
        if args.command in ("prepare", "convert"):
            result = prepare(args.input, args.output, args.pages)
            if args.command == "convert" and result["status"] == "ready":
                result = build(args.output, args.renderer)
        elif args.command == "build":
            result = build(args.job, args.renderer)
        elif args.command == "validate":
            dependencies()
            scene = validate_scene(read_json(Path(args.job)/"scene.json"), Path(args.job))
            check_manifest(Path(args.job), scene)
            result = {"status": "valid", "pages": len(scene["pages"])}
        else:
            result = crop(args.job, args.page, [float(x) for x in args.bbox.split(",")], args.name)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, subprocess.SubprocessError, ImportError) as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
