# 环境与安装

需要 Python 3.10+、Node.js 18+ 和 PptxGenJS 4.0.1。PDF 与图像处理依赖列在 `requirements.txt`。不需要独立模型 API；截图由宿主 WorkBuddy 看图后生成结构。

在实际技能目录执行（不改用户系统配置）：

```bash
python -m pip install --target "<技能目录>/_vendor" -r "<技能目录>/requirements.txt"
npm install --prefix "<技能目录>" --omit=dev --ignore-scripts
python "<技能目录>/scripts/slide_rebuild.py" doctor
```

如果运行时已带有所需 Python 包，可直接使用；Node 的正常模块搜索和 `NODE_PATH` 同样可用。导入 ZIP 本身不等于已安装这些运行时。若技能目录只读，使用工作区副本安装依赖并运行。Windows PowerShell 路径含空格时用 `& "python完整路径" ...`。

可选视觉检查：

- LibreOffice：`--renderer auto` 优先发现 `soffice`，使用独立临时用户配置，不影响用户已打开的 LibreOffice；未找到时在 Windows 检查已注册 PowerPoint。
- Windows 桌面 PowerPoint：`--renderer powerpoint`。通过 COM 只读打开生成文件，导出 PNG 后关闭该文件；不修改源文件。未找到应用或渲染失败会在报告中明确记录。脚本不更改 PowerShell 执行策略。
- `--renderer none`：只做结构检查，报告必须标明未执行视觉检查。

常见问题：

- `needs_vision`：打开源图，按 scene-format.md 填写页面元素，再 build。
- `output directory`：prepare/convert 使用新目录；已有任务用 build。
- 找不到 `pptxgenjs`：在技能目录运行 npm install；不要把某台机器的绝对模块路径写进源码。
- 字体替换/换行：在 scene 中调整 `font_family`、`bbox`、字号，重新 build 后检查实际渲染。
- 中文需要本机可用的中文字体。Windows 通常可用微软雅黑/黑体，macOS 可用苹方，Linux 建议 Noto Sans CJK SC；输出不会嵌入或分发这些字体。
- 不支持加密、受损、极端比例 PDF；需要密码时用户应自行提供可正常打开的副本，脚本不绕过加密。
- PDF 中的复杂路径、剪裁、透明和遮挡可能近似；不支持区域保留局部图片并披露。
