# 页面结构 1.0

从 `prepare`/`convert` 生成的 `scene.json` 开始修改，保留顶层尺寸、`source_image` 和页码；`job.json` 与源图用于输入校验，不要修改。所有坐标以页面左上角为原点。

每页：`width`、`height` 为同一坐标单位；`bbox` 为 `[x,y,w,h]`，四项均为0..1，矩形不得超出页面。PDF 单位是pt；截图单位是像素。页面状态完成后设 `ready`。

```json
{
  "schema_version": "1.0",
  "slide_width_in": 13.333333,
  "slide_height_in": 7.5,
  "font_family": "Microsoft YaHei",
  "pages": [{
    "source_page": 1,
    "width": 1920,
    "height": 1080,
    "source_image": "source/page-001.png",
    "background": "#FFFFFF",
    "status": "ready",
    "warnings": [],
    "elements": [
      {"id":"card","type":"shape","shape":"roundRect","bbox":[0.08,0.30,0.25,0.20],
       "style":{"fill":"#E8F0FF","stroke":"#4472C4","stroke_width_source":2}},
      {"id":"label","type":"text","text":"需求确认","bbox":[0.10,0.36,0.21,0.07],
       "style":{"font_size_pt":24,"font_family":"Microsoft YaHei","color":"#17365D","bold":true,"align":"center"}},
      {"id":"arrow","type":"line","bbox":[0.34,0.40,0.15,0],"points":[0.34,0.40,0.49,0.40],
       "end_arrow":true,"style":{"stroke":"#4472C4","stroke_width_source":3}}
    ]
  }]
}
```

元素顺序就是底到顶的绘制顺序。ID 在同一页内唯一。仅支持以下类型：

- `text`：`text` 非空，`style.font_size_pt` 为最终 PPT 字号（pt）；或 `font_size_source` 为源页面坐标中的字号，按页面比例转换；二者同时提供时优先后者。可指定 `font_family`、`bold`、`italic`、`color`、`align`（left/center/right）、`valign`（top/mid/bottom）、`rotate`（0..360）。保留换行，不自动缩字。
- `shape`：`shape` 为 rect、roundRect、ellipse、triangle、chevron、diamond。`style.fill` 与 `style.stroke` 可为 `null`（透明），颜色使用 `#RRGGBB`。`stroke_width_source` 为源坐标单位。圆角采用原生近似；不保证原稿的精确圆角半径。
- `line`：额外提供 `points:[x1,y1,x2,y2]`，同样为归一化坐标；可设 `start_arrow`、`end_arrow`。箭头是可编辑线条，不保证与节点自动吸附。
- `image`：提供 job 相对 `asset`（PNG），以及 `reason` 说明不可编辑区域。用以下命令裁剪原图；禁止引用任务目录外文件或远程URL。

```bash
python "<技能目录>/scripts/slide_rebuild.py" crop --job "<JOB>" --page 1 --bbox "0.65,0.25,0.28,0.40" --name illustration
```

把返回的 `asset` 和 `bbox` 写进元素。区域内已经烘焙的文字不能再作为重复文字框。把无法识别文字等疑点加入页面 `warnings`，例如 `{"code":"uncertain_text","message":"右下角金额模糊，需核对。"}`。

同一个 PPT 所有页使用顶层尺寸；不同源比例通过等比缩放、居中留白适配，不能拉伸。截图字号应按最终页大小估计，而不是直接拿像素数当pt。

## 原生 PDF 视觉复核

提取器按基线合并文字、按字体/大间距拆分，生成矩形、直线与标准椭圆；任意复杂曲线和图片保留局部图片。字符编码异常或没有可编辑文字的页标记 needs_vision。近似图层顺序、未匹配字体、旋转文字和复杂透明剪裁都需要看图核对。
