# -*- coding: utf-8 -*-
"""留学申请规划（gmai-liuxue-application-planner-f81c）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
建议输入信息：GPA与语言成绩；实习科研经历；目标国家与专业
"""
import json, os, sys, time

SLUG = "gmai-liuxue-application-planner-f81c"
TITLE = "留学申请规划"
PRICE_FEN = 1990

# 检查项（标题, 关键词, 落地建议）—— 逐项对本技能领域定制
CHECKS = [
 [
  "选校梯度",
  [
   "选校",
   "梯度",
   "冲刺"
  ],
  "按背景设计冲刺匹配保底梯度"
 ],
 [
  "硬性条件",
  [
   "GPA",
   "语言",
   "GRE"
  ],
  "核对GPA与语言成绩缺口"
 ],
 [
  "背景提升",
  [
   "科研",
   "实习",
   "竞赛"
  ],
  "排布背景提升项目优先级"
 ],
 [
  "时间线",
  [
   "时间线",
   "截止",
   "轮次"
  ],
  "制定申请季时间线"
 ],
 [
  "文书定位",
  [
   "文书",
   "动机",
   "主线"
  ],
  "确定文书叙事主线"
 ]
]

DELIVERABLES = ["选校梯度清单", "申请时间线", "背景提升优先级表"]


def load_input(argv):
    path = argv[1] if len(argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f), path


def analyze(data):
    text = json.dumps(data, ensure_ascii=False)
    fields = [v for v in data.values() if str(v).strip()]
    rich = len(fields) >= 2 or sum(len(str(v)) for v in fields) >= 28
    rows = []
    full = 0
    for item, kws, advice in CHECKS:
        if any(k in text for k in kws):
            rows.append((item, 2, advice))
            full += 1
        elif rich:
            rows.append((item, 1, advice))
        else:
            rows.append((item, 0, advice))
    return rows, full, rich


def build_report(data, rows, full, rich, src):
    L = []
    L.append("# %s 分析报告" % TITLE)
    L.append("")
    L.append("- 技能：%s（`%s`）" % (TITLE, SLUG))
    L.append("- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0))
    L.append("- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    L.append("- 输入来源：%s" % os.path.basename(src))
    L.append("")
    L.append("## 输入概览")
    L.append("")
    for k, v in data.items():
        v = str(v)
        L.append("- **%s**：%s" % (k, v[:160] + ("…" if len(v) > 160 else "")))
    L.append("")
    L.append("## 逐项分析")
    L.append("")
    for i, (item, lv, advice) in enumerate(rows, 1):
        if lv == 2:
            L.append("%d. **%s**：输入中已包含直接相关信息，落地路径——%s" % (i, item, advice))
        elif lv == 1:
            L.append("%d. **%s**：现有材料可支撑基础分析（该项的直接关键词材料偏薄，结论深度依补充材料而定）；路径——%s" % (i, item, advice))
        else:
            L.append("%d. **%s**：输入信息暂缺，需补充材料后才能给出可靠结论；建议：%s" % (i, item, advice))
    partial = sum(1 for r in rows if r[1] == 1)
    score = int(round(100.0 * (full + 0.5 * partial) / len(CHECKS)))
    L.append("")
    L.append("## 综合评估")
    L.append("")
    L.append("- 信息充分度：**%d/100**（直接命中 %d 项 / 材料可支撑 %d 项 / 共 %d 项）" % (score, full, full + partial, len(CHECKS)))
    if score >= 80:
        L.append("- 判定：输入充分，可按上述落地路径直接执行。")
    elif score >= 50:
        L.append("- 判定：输入基本可用，优先补齐薄弱项信息后执行效果更佳。")
    else:
        L.append("- 判定：输入偏薄，请按「待补充信息」整理材料后重新分析。")
    L.append("")
    L.append("## 待补充信息")
    L.append("")
    missed = [r[0] for r in rows if r[1] == 0]
    weak = [r[0] for r in rows if r[1] == 1]
    if missed or weak:
        for m in missed:
            L.append("- 「%s」相关的原始材料或说明（必需）" % m)
        for m in weak:
            L.append("- 「%s」相关的补充材料（建议，可提升结论深度）" % m)
    else:
        L.append("- 无：输入已覆盖全部检查项。")
    L.append("")
    L.append("## 交付物")
    L.append("")
    for d in DELIVERABLES:
        L.append("- %s" % d)
    L.append("")
    L.append("> 本报告由 `%s` 基于规则分析生成，供决策参考，不构成任何绝对保证。" % SLUG)
    L.append("> 考试合规提示：本报告为备考参考，不构成通过或录取承诺；以官方招考公告为准。")
    L.append("")
    L.append("## 使用指引与边界声明")
    L.append("")
    L.append("- 分析方式：本报告由规则引擎对输入材料做关键词命中与完备度评估后生成，「逐项分析」的三档判定（直接命中/可支撑/信息暂缺）只反映材料可见信息，不代表实际业务上限。")
    L.append("- 下一步行动：优先补齐「待补充信息」中的必需项，再补充建议项；材料更新后重新运行本技能，可得到更完整的逐项结论与更高充分度评分。")
    L.append("- 适用边界：仅适用于%s类场景的规则化分析；涉及法规、税率、价格、平台政策的结论存在时效性，执行前请以官方最新口径为准。" % TITLE)
    L.append("- 数据安全：请勿在输入材料中包含密码、API密钥、完整证件号等敏感凭证；本技能在本地完成规则分析，不外传输入内容。")
    L.append("- 交付物使用：上述「交付物」清单即本次输出的组成部分，可直接复制到工作文档中使用；如需定制化扩展，请在输入中附上具体要求。")
    L.append("- 免责声明：本报告供决策参考，不构成法律、财务、税务、投资等专业意见；重大决策请咨询持牌专业人士。")
    L.append("- 复跑建议：同一输入多次运行结果一致；输入材料更新后请重新运行本技能以刷新结论。")
    L.append("- 常见问题：若「逐项分析」全部为「信息暂缺」，通常是输入表述与检查项关键词不匹配，请对照「待补充信息」调整措辞后重试。")
    return "\n".join(L) + "\n"


def main():
    data, src = load_input(sys.argv)
    rows, full, rich = analyze(data)
    md = build_report(data, rows, full, rich, src)
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "report_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
