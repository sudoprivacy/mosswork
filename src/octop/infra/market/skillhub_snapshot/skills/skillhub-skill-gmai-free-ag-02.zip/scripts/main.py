# -*- coding: utf-8 -*-
"""智能体失败重试策略模板固化包（gmai-free-ag-02）业务主脚本
免费技能：零费用，安装后可直接运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：智能体失败重试策略模板固化提示词成品（可直接使用，含变量位说明）；评测集与判据清单（用例 + 期望 + 判定规则）；迭代与防滥用说明（版本记录 + 拒答规则 + 复核点）
建议输入（专业字段）：业务与任务；提示词与评测；数据与调用授权
"""
import json, os, re, sys, time

SLUG = "gmai-free-ag-02"
TITLE = "智能体失败重试策略模板固化包"
PRICE_FEN = 0
CATEGORY = "AI工程与智能体运维"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['业务与任务', True, ['业务', '任务', '场景'], '决定提示词与评测目标'], ['提示词与评测', True, ['提示词', '评测', '用例'], '决定可评测的通过判据'], ['数据与调用授权', True, ['数据', '调用', '授权'], '无授权的数据不得进入提示词'], ['模型与版本', False, ['模型', '版本', '参数'], '版本与参数须可追溯'], ['提示词样例', False, ['样例', '输入样例', '对话'], '用于构造真实评测集'], ['幻觉与失败样例', False, ['幻觉', '失败样例', '错误'], '用于设计拒答与复核规则']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'finds': [['缺乏效果评测基线', '高', '上线前未建立标注集与指标基线', '效果无法量化，迭代方向靠主观感受', '建立评测集与指标（准确率/召回/幻觉率）基线'], ['提示词与配置散落在代码中', '中', '提示词硬编码，多环境不一致', '效果不可复现，验收无法对齐', '提示词外置为可版本化配置并纳入变更记录'], ['未设置调用超时与降级', '高', '模型调用无超时与重试上限', '上游抖动可拖垮整条链路', '设置超时、重试上限与降级兜底'], ['成本无归因', '中', '调用量按账号汇总，未按业务/租户拆分', '无法定位成本异常来源', '按业务维度打标并出成本报表'], ['输出未做安全过滤', '高', '模型输出直接渲染给用户', '可能泄露敏感信息或产生不当内容', '输出侧加过滤与敏感信息检查'], ['评测未覆盖边界场景', '中', '评测集仅含常规问法', '边界输入下效果骤降且不易发现', '补充边界与对抗样例，纳入回归集']], 'tools': "```bash\n# 建议在测试环境执行，勿在生产直接压测\ncurl -s -w '%{time_total}\\n' -X POST $ENDPOINT -d @sample.json | tail -1   # 单次延迟\npython -m pytest tests/eval -v          # 评测集回归（按实际框架替换）\n```"}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['提示词五要素结构：角色、任务、输入、约束、输出格式', '评测集构成口径：正例/反例/边界例 + 通过判据（准确率/一致性/拒答率）', '幻觉治理通行做法：不确定处显式标注 + 检索增强 + 人工复核点', '《生成式人工智能服务管理暂行办法》对内容与标识的相关要求', '提示词与模型版本须可追溯、可回滚（版本化管理）']
# 自检项（输入完备度）
CHECKS = [['智能体失败重试策略模板固化·任务与边界核查', ['智能体失败重试策略模板固化', '面向智能体运维场景'], '先界定模型能力边界与不可为事项，缺输入不编造事实'], ['智能体失败重试策略模板固化·提示词结构', ['面向智能体运维场景', '明确工具边界'], '提示词含角色 / 任务 / 输入 / 约束 / 输出格式五要素，可复用可版本化'], ['智能体失败重试策略模板固化·评测与回归', ['明确工具边界', '失败处理与人工接管点'], '给出评测集构成与通过判据（准确率 / 一致性 / 拒答率），可重复跑'], ['智能体失败重试策略模板固化·幻觉与滥用防护', ['智能体失败重试策略模板固化'], '标注不确定处、给出拒答规则与人工复核点，防止越权自动化'], ['智能体失败重试策略模板固化·诚信红线', ['伪造评测结果', '生成违法内容'], '不得伪造评测结果或生成违法内容，命中即终止']]
# 交付物构成
DELIVERABLES = ['智能体失败重试策略模板固化提示词成品（可直接使用，含变量位说明）', '评测集与判据清单（用例 + 期望 + 判定规则）', '迭代与防滥用说明（版本记录 + 拒答规则 + 复核点）']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L


# ---------------- doc 范式：通用文书 / 表格 / 清单 ----------------

def _sec_scope(ctx):
    L = ["| 输入项 | 要求 | 本次情况 |", "|---|---|---|"]
    for name, req, al, why in FIELDS:
        v = ctx["fv"](name)
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选",
                                       brief(v, 60) or "待补充"))
    L.append("")
    L.append("> 上表为本次成稿的口径基础。标注「待补充」的项不作臆测，正文中以【待补充】标出。")
    return L


def _sec_frame(ctx):
    L = ["| 段落 | 内容要点 | 产出形态 |", "|---|---|---|"]
    nd = len(DELIVERABLES)
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        if nd == 0:
            d = TITLE
        elif i <= nd:
            d = DELIVERABLES[i - 1]
        else:
            d = "并入「%s」" % DELIVERABLES[0]
        L.append("| 第 %d 段 · %s | %s | %s |" % (i, item, brief(advice, 46), brief(d, 30)))
    return L


def _sec_draft(ctx):
    L = ["以下为按本技能交付段落生成的成稿骨架。每段给出：**本段依据（取自你的输入）→ 撰写要点"
         "（本域专业口径）→ 自查关键词（交付前逐项核对）**；红线段落只标注禁止情形。", ""]
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        L.append("**%d. %s**" % (i, item))
        if "命中即终止" in advice:
            L.append("- 红线：%s" % advice)
            L.append("- 处理：命中不得变通承接，直接终止并说明理由。")
            L.append("")
            continue
        fn = FIELDS[(i - 1) % len(FIELDS)] if FIELDS else ("材料", True, [], "材料缺失")
        v = ctx["fv"](fn[0])
        L.append("- 本段依据：%s → %s" % (fn[0], brief(v, 70) or "【待补充：%s】" % fn[3]))
        L.append("- 撰写要点：%s" % advice)
        L.append("- 自查关键词：%s" % "、".join(kws[:3]))
        L.append("")
    return L


def _sec_basis(ctx):
    L = ["| 段落 | 依据来源（本域锚点） |", "|---|---|"]
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        a = ANCHORS[(i - 1) % len(ANCHORS)] if ANCHORS else "—"
        L.append("| 第 %d 段 · %s | %s |" % (i, item, a))
    return L


def _sec_deliver(ctx):
    L = []
    for d in DELIVERABLES:
        L.append("- 交付物：%s" % d)
    L.append("")
    L.append("- 留痕口径：保留输入原始材料、本报告与定稿版本号；变更须记说明，便于复现与回滚。")
    L.append("- 复用口径：替换【】内字段即可复用于同类场景；单位、时间窗或口径版本变更时，"
             "须重新核对本报告「四、口径与依据对照」。")
    return L


def _sec_finds(ctx):
    P = ctx["spec"]["params"] or {}
    fs = P.get("finds") or []
    if not fs:
        return []
    L = ["| 问题 | 等级 | 证据要点 | 影响 | 改进动作 |", "|---|---|---|---|---|"]
    for r in fs[:8]:
        L.append("| " + " | ".join(str(x) for x in list(r)[:5]) + " |")
    return L


def sections(ctx):
    """通用文书交付物：口径确认 → 结构骨架 → 成品正文 → 依据对照 → 交付留痕"""
    L = [
        ("一、需求与口径确认", _sec_scope(ctx)),
        ("二、交付结构骨架", _sec_frame(ctx)),
        ("三、成稿骨架与撰写口径", _sec_draft(ctx)),
        ("四、口径与依据对照", _sec_basis(ctx)),
    ]
    f = _sec_finds(ctx)
    if f:
        L.append(("五、本域常见问题与对策", f))
        L.append(("六、交付与留痕", _sec_deliver(ctx)))
    else:
        L.append(("五、交付与留痕", _sec_deliver(ctx)))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：免费（Free Skill · 零费用）",
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
