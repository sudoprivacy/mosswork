---
name: skillhub-skill-8d-report-paid
description: "按次付费的 8D 问题解决报告生成服务（Pay Skill）。用户提供产品异常信息后，调用已部署的收费接口生成符合 IATF16949 / ISO9001 审核习惯的 D1-D8 完整报告初稿，并在对话内完成支付。触发词：8D报告、8D 报告生成、付费 8D、生成 8D、客诉 8D、异常报告付费生成、按次付费 8D。当请求返回 HTTP 402、Payment-Needed 或 amtPaymentLink 时，必须加载 alipay-payment-skill 并按其流程处理。"
---

# 8D 报告自动生成（按次付费）

按次付费调用服务端收费接口，生成可直接交付客户的 8D 报告（D1-D8）初稿。单次价格 **¥1.00**，与支付宝服务登记价、服务端 402 账单金额一致。

## 触发条件

用户要求生成 8D 报告 / 8D 客诉报告 / 付费生成异常报告，并提供或可接受补充下列输入时触发。

## 输入参数

| 字段 | 必填 | 说明 |
|---|---|---|
| `product_model` | 是 | 产品型号 / 物料编码 |
| `industry` | 是 | 汽车零部件 / 消费电子 / 五金塑胶 / 新能源线束 / 其他 |
| `defect_description` | 是 | 不良现象详述（表现、发现工序、比例、时间） |
| `total_qty` / `defect_qty` / `escaped_qty` | 是 | 总批量、不良数、已流出客户端数量 |
| `severity` | 是 | 一般异常 / 严重异常 / 安全法规相关 |
| `suspect_scope` | 否 | 可疑批次、设备、班组、物料批次 |
| `responsible_dept` | 否 | 供应商 / 注塑车间 / 组装车间 / 冲压车间 / 其他 |
| `found_process` / `found_time` / `found_by` / `found_method` | 否 | 5W2H 补充项 |

缺失的必填项以「待确认（现场补充）」占位，服务端仍会输出完整框架，不编造数据。

## 依赖安装

买家侧官方支付能力（提供 `alipay-bot` 与 `alipay-payment-skill`）：

```bash
npx -y @alipay/agent-payment@latest install
```

## 调用方法

`scripts/8d-report-paid.mjs` 三个子命令，按 402 协议顺序执行：

```bash
# 1) 发起原始请求，未付款时返回 402 并保存账单与原始请求
node scripts/8d-report-paid.mjs probe --data '{"product_model":"BRK-2031","industry":"汽车零部件","defect_description":"孔中心距超差","total_qty":"12000","defect_qty":"384","escaped_qty":"2600","severity":"严重异常"}' --state-dir '.state/SESSION_KEY'

# 2) 把账单与原始请求交给官方 CLI，展示付款入口并等待用户确认
node scripts/8d-report-paid.mjs pay --session-id 'SESSION_KEY' --state-dir '.state/SESSION_KEY'

# 3) 用户付款后，复用同一订单查询并取回报告（不重新下单）
node scripts/8d-report-paid.mjs complete --out-shake-no 'OUT_SHAKE_NO' --state-dir '.state/SESSION_KEY'
```

- `--session-id` 取当前 Agent 会话标识，不得用订单号或随机值代替。
- `complete` 的 `--out-shake-no` 只从对客标签「订单号」「查询单号」后提取。
- 状态不明时先查单，不重复付款；成功路径不追加独立回执。

## 输出展示

取回结果后原样展示 `content` 字段中的报告正文，并给出 `out_trade_no`、`trade_no` 供核对。不展示支付链接、二维码原文或交易号等中间过程。

## 打包与排除

发布包只含 `SKILL.md`、`scripts/`、`references/`。**排除**：密钥、私钥文件、`.env`、`.state/` 状态文件、`node_modules`、`data/*.db`、任何支付账号字段。服务端源码独立部署，不放入本包。

## 仍需补充的真实配置

- 公网 HTTPS 部署地址：✅ 已固定为 `https://8d-api.vintsky.top/v1/8d-report`（已作为 `DEFAULT_RESOURCE_URL` 写入脚本）
  切换部署时必须同步走支付宝服务市场「修改服务」更新地址，否则验付会因 `resource_id` 不匹配失败
- 支付宝生产配置：
  - `ALIPAY_APP_ID` = `2021007113640517`（已取得，WEBAPP 已上线）
  - `ALIPAY_PUBLIC_KEY`：已导出到 `~/.config/2021007113640517-alipayPublicKey.keytext`
  - `ALIPAY_APP_PRIVATE_KEY`（PKCS#1）：仅由部署方注入，禁止交给 Agent
  - `ALIPAY_SELLER_ID` = `2088602124354090`（已取得，收款商户 PID）
  - `ALIPAY_SERVICE_ID` = `API_048216B57A554547`（已取得）
  - 服务地址：`https://8d-api.vintsky.top/v1/8d-report`（Cloudflare Workers + D1 部署，7x24 在线，与支付宝服务市场登记地址一致）
  - `ALIPAY_GATEWAY` = `https://openapi.alipay.com/gateway.do`
- 未完成确认前不发起真实付款。
