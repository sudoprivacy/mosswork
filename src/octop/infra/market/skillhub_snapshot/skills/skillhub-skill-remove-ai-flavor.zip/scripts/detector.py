#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""去AI味自动检测器 v5.1 — 50种模式+网文专区+W处方+指令库·即时诊断."""
import re, sys, json, argparse
from collections import Counter, defaultdict
from pathlib import Path

# ===== Web Novel Wordbank Loader =====
_WB = {}
_WB_FULL = {}
_wb_path = Path(__file__).parent / "wordbank_flat.json"
_wb_full_path = Path(__file__).parent / "wordbank.json"
if _wb_path.exists():
    try: _WB = json.loads(_wb_path.read_text(encoding="utf-8"))
    except: pass
if _wb_full_path.exists():
    try: _WB_FULL = json.loads(_wb_full_path.read_text(encoding="utf-8"))
    except: pass
_WB_KEYS = list(_WB.keys()) if _WB else []
_WB_CATEGORIES = {c["name"]: c for c in _WB_FULL.get("categories", [])} if _WB_FULL else {}

PATTERNS = {
    1: {
        "category": '假大空',
        "name": '意义拔高',
        "keywords": [
            '标志着',
            '具有.*意义',
            '里程碑式',
            '划时代',
            '深刻地',
            '深远地',
            '深远影响',
            '极大推动',
            '奠定了坚实基础',
            '开启了新纪元',
            '历史性',
            '重大突破',
            '革命性',
        ],
        "severity": 90,
        "auto": True,
        "priority": 'P1',
    },
    2: {
        "category": '假大空',
        "name": '模板化开头/结尾',
        "keywords": [
            '在当今.*背景下',
            '随着.*的发展',
            '在这个.*的时代',
            '综上所述',
            '总而言之',
            '展望未来',
            '未来可期',
            '在.*日益.*的今天',
            '不可逆转的趋势',
        ],
        "severity": 85,
        "auto": True,
        "priority": 'P0',
    },
    3: {
        "category": '假大空',
        "name": '空洞结论',
        "keywords": [
            '未来可期',
            '拭目以待',
            '前景广阔',
            '机遇与挑战并存',
            '值得期待',
            '大有可为',
            '前景光明',
            '任重道远',
        ],
        "severity": 80,
        "auto": True,
        "priority": 'P1',
    },
    4: {
        "category": '假大空',
        "name": '广告腔/旅游手册体',
        "keywords": [
            '坐落于',
            '令人叹为观止',
            '必去之地',
            '充满活力的',
            '自然美景',
            '丰富的文化遗产',
            '举世闻名',
            '风景如画',
            '美不胜收',
            '流连忘返',
        ],
        "severity": 75,
        "auto": True,
        "priority": 'P2',
    },
    5: {
        "category": 'AI高频词',
        "name": 'AI 词库',
        "keywords": [
            '此外',
            '然而',
            '因此',
            '总而言之',
            '值得注意的是',
            '值得一提的是',
            '不容忽视',
            '不可或缺',
            '至关重要',
            '极大地',
            '显著地',
            '有效地',
            '进一步',
            '充分',
            '深入',
            '毋庸置疑',
            '显而易见',
        ],
        "severity": 60,
        "auto": True,
        "threshold": 0.015,
        "priority": 'P2',
    },
    6: {
        "category": 'AI高频词',
        "name": '“进行”滥用',
        "regex": '进行了?(深入|全面|充分|系统|广泛|详细|认真)?的?(分析|研究|讨论|调查|处理|优化|探讨|评估|测试|审查|整理|开发)',
        "severity": 65,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    7: {
        "category": 'AI高频词',
        "name": '系词回避 — “是/有”变花哨',
        "keywords": [
            '作为.*的核心',
            '标志着.*',
            '扮演着.*角色',
            '发挥着.*作用',
            '构成了.*',
            '充当了.*',
            '起到.*作用',
        ],
        "severity": 55,
        "auto": True,
        "priority": 'P2',
    },
    8: {
        "category": 'AI高频词',
        "name": '“的”字堆砌',
        "severity": 40,
        "auto": False,
        "priority": 'P3',
        "manual_hint": '统计每句中“的”的出现次数, >=3个标记可疑, >=5个强烈提醒修改',
    },
    9: {
        "category": '翻译腔',
        "name": '被动语态泛滥',
        "regex": '被(发现|认为|称为|视作|当作|看作|评价为|证明|证实|接受|采纳)',
        "severity": 50,
        "auto": True,
        "threshold": 1,
        "priority": 'P3',
    },
    10: {
        "category": '翻译腔',
        "name": '“当…时” 英语思维',
        "regex": '当[^，,。.!！?？\\n]{1,30}时[，,]',
        "severity": 55,
        "auto": True,
        "threshold": 1,
        "priority": 'P3',
    },
    11: {
        "category": '翻译腔',
        "name": '“通过…的方式/手段”',
        "regex": '通过[^，,。.!！?？\\n]{1,20}的(方式|手段|途径|办法|方法|模式|策略|机制)',
        "severity": 60,
        "auto": True,
        "priority": 'P3',
    },
    12: {
        "category": '翻译腔',
        "name": '英文标点混用',
        "severity": 35,
        "auto": True,
        "priority": 'P4',
        "special": 'check_punctuation',
    },
    13: {
        "category": '结构模板',
        "name": '破折号泛用',
        "severity": 50,
        "auto": False,
        "priority": 'P3',
        "manual_hint": '统计——出现次数, 每500字超过2个标记可疑',
    },
    14: {
        "category": '结构模板',
        "name": '冒号列表体 / 加粗标题体',
        "severity": 45,
        "auto": False,
        "priority": 'P3',
        "manual_hint": '检查是否大量使用 **标题**: 内容 的列表结构',
    },
    15: {
        "category": '结构模板',
        "name": 'Emoji 装饰',
        "severity": 30,
        "auto": False,
        "priority": 'P4',
        "manual_hint": '统计emoji数量, 每500字超过3个标记可疑',
    },
    16: {
        "category": '结构模板',
        "name": '数字+抽象名词 万能结论',
        "regex": '[三四五六七八九十两][大个项关键因素要素维度核心要点步骤环节方面趋势特征]',
        "severity": 70,
        "auto": True,
        "priority": 'P3',
    },
    17: {
        "category": '结构模板',
        "name": '假范围 — “从…到…”矫揉用法',
        "regex": '从[^，,。.!！?？\\n]{1,40}到[^，,。.!！?？\\n]{1,40}',
        "severity": 55,
        "auto": True,
        "threshold": 2,
        "priority": 'P3',
    },
    18: {
        "category": '结构模板',
        "name": '模板化“挑战与前景”段',
        "keywords": [
            '尽管.*(面临|存在).*挑战',
            '前景广阔',
            '随着.*不断(进步|发展)',
            '这些挑战有望被克服',
        ],
        "severity": 75,
        "auto": True,
        "priority": 'P2',
    },
    19: {
        "category": '句式模板',
        "name": '着/了/过分析句',
        "keywords": [
            '标志着',
            '预示着',
            '凸显了',
            '反映了',
            '象征着',
            '意味着',
            '折射出',
            '映射出',
            '印证了',
            '揭示了',
        ],
        "severity": 70,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    20: {
        "category": '句式模板',
        "name": '“不仅…而且…” 泛滥',
        "regex": '不仅[^，,。.!！?？\\n]{1,30}(而且|还|也|更|更为|甚至)',
        "severity": 55,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    21: {
        "category": '句式模板',
        "name": '同义词强迫症',
        "severity": 40,
        "auto": False,
        "priority": 'P4',
        "manual_hint": '检查同一实体是否在一段内被换了三四种不同的称呼',
    },
    22: {
        "category": '句式模板',
        "name": '“在…方面/层面/维度” 过度',
        "regex": '在[^，,。.!！?？\\n]{1,20}(方面|层面|维度|角度|层次)',
        "severity": 60,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    23: {
        "category": '沟通腔',
        "name": '客服腔',
        "keywords": [
            '您说得非常对',
            '很高兴为您解答',
            '如有任何疑问请随时联系',
            '希望能帮到您',
            '感谢您的提问',
            '非常乐意为您服务',
            '请问还有什么需要帮助的吗',
            '祝您.*愉快',
        ],
        "severity": 85,
        "auto": True,
        "priority": 'P0',
    },
    24: {
        "category": '沟通腔',
        "name": '免责声明体',
        "keywords": [
            '截至目前',
            '根据现有资料',
            '具体细节尚不明确',
            '需要注意的是',
            '可能存在偏差',
            '仅供参考',
            '不构成.*建议',
            '以实际为准',
            '具体以.*为准',
        ],
        "severity": 70,
        "auto": True,
        "priority": 'P0',
    },
    25: {
        "category": '沟通腔',
        "name": '过度奉承',
        "keywords": [
            '非常好的问题',
            '非常准确',
            '分析得非常到位',
            '非常精辟',
            '非常深刻',
            '非常到位',
            '真是一个好问题',
            '问得太好了',
        ],
        "severity": 75,
        "auto": True,
        "priority": 'P0',
    },
    26: {
        "category": '沟通腔',
        "name": 'AI 态度的提问结尾',
        "regex": '(你认为呢|你怎么看|你觉得呢|您觉得呢|大家觉得呢|你们怎么看)[？?]',
        "severity": 65,
        "auto": True,
        "priority": 'P0',
    },
    27: {
        "category": '中文特有',
        "name": '网络用语过载',
        "keywords": [
            '绝绝子',
            'yyds',
            '栓Q',
            '家人们谁懂啊',
            '狠狠期待住了',
            '属实是绷不住了',
            '破防了',
            '我真的会谢',
            '纯纯的',
            '泰酷辣',
            '依托答辩',
            '芭比Q了',
            '典',
            '绷',
        ],
        "severity": 80,
        "auto": True,
        "threshold": 0,
        "priority": 'P4',
    },
    28: {
        "category": '中文特有',
        "name": '语气词过度',
        "severity": 50,
        "auto": False,
        "priority": 'P4',
        "manual_hint": '统计呢/吧/哦/啊/哈/呀的总出现次数, 每200字超过3个标记可疑',
    },
    29: {
        "category": '中文特有',
        "name": '矫揉表达',
        "keywords": [
            '不得不说',
            '必须指出',
            '可以毫不夸张地说',
            '众所周知',
            '谁也不能否认',
            '毋庸置疑',
            '无庸置疑',
            '不可否认',
            '不容置疑',
            '显然',
            '不言而喻',
            '毫无疑问',
        ],
        "severity": 65,
        "auto": True,
        "threshold": 1,
        "priority": 'P1',
    },
    30: {
        "category": '中文特有',
        "name": '分号滥用',
        "severity": 40,
        "auto": False,
        "priority": 'P4',
        "manual_hint": '统计英文分号(;)出现次数, 每500字超过2个标记可疑',
    },
    31: {
        "category": '中文特有',
        "name": '模糊来源',
        "keywords": [
            '业内人士指出',
            '专家认为',
            '观察人士表示',
            '多方观点认为',
            '有分析称',
            '据相关人士透露',
            '业界普遍认为',
            '消息人士称',
            '知情人士透露',
            '内部人士表示',
        ],
        "severity": 75,
        "auto": True,
        "priority": 'P1',
    },
    32: {
        "category": '填充冗余',
        "name": '填充短语',
        "keywords": [
            '为了.*(的目的|起见)',
            '由于.*(的原因|的事实)',
            '在.*(的情况下|的过程中)',
            '就.*而言',
            '从.*(的角度|来看)',
            '在.*的时间范围内',
            '基于.*(的考量|的考虑)',
        ],
        "severity": 55,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    33: {
        "category": '填充冗余',
        "name": '过度限定与模棱两可',
        "keywords": [
            '在一定程度上',
            '从某种(角度|程度|意义)来说',
            '可以说',
            '大体上',
            '一般而言',
            '似乎',
            '倾向于',
            '某种意义上',
            '某种程度上',
            '总体而言',
            '大致上',
        ],
        "severity": 60,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    34: {
        "category": '填充冗余',
        "name": '“有+抽象名词”万能搭配',
        "regex": '有(着)?(很强|极强|巨大|显著|重要|广泛|深远|相当|一定|良好|优异)的?(能力|潜力|优势|影响|意义|价值|作用|效果|前景|空间|竞争力|生命力|表现力)',
        "severity": 65,
        "auto": True,
        "threshold": 1,
        "priority": 'P2',
    },
    35: {
        "category": '填充冗余',
        "name": '连接词堆砌',
        "keywords": [
            '此外',
            '与此同时',
            '另外',
            '除此之外',
            '不仅如此',
            '而且',
            '同时',
            '再者',
            '另一方面',
            '进一步而言',
            '更值得关注的是',
        ],
        "severity": 55,
        "auto": True,
        "threshold": 0.01,
        "priority": 'P2',
    },
    36: {
        "category": '填充冗余',
        "name": '安全表达综合症',
        "keywords": [
            '各有(利弊|优劣|千秋)',
            '具体情况(具体分析|需具体)',
            '取决于多种因素',
            '需要进一步(研究|观察|探讨)',
            '仍有待(观察|研究|验证)',
            '值得注意的是',
            '不容忽视的是',
            '需要指出的是',
            '值得关注的是',
        ],
        "severity": 70,
        "auto": True,
        "threshold": 1,
        "priority": 'P1',
    },
    37: {
        "category": '填充冗余',
        "name": '概括性废话段',
        "keywords": [
            '随着.*(不断|深入|快速|日益).*(发展|进步|推进|深化|演进)',
            '在.*(新时代|新形势|新格局|新阶段)下',
            '面临.*(前所未有|严峻|复杂|新的).*(挑战|机遇|形势|局面)',
            '不断(提升|增强|深化|完善|优化)(自身|综合|核心).*(竞争力|实力|能力|水平)',
            '在激烈(的|的行业)竞争中立于不败之地',
            '推动.*(高质量|可持续|健康|快速).*发展',
            '发挥.*(重要|关键|核心|积极).*作用',
        ],
        "severity": 80,
        "auto": True,
        "priority": 'P1',
    },
    38: {
        "category": '填充冗余',
        "name": '弯引号/全角引号混用',
        "severity": 25,
        "auto": False,
        "priority": 'P4',
        "manual_hint": '检查中文文本中是否混用弯引号与全角引号, 正式中文文本应统一为全角引号',
    },
    39: {
        "category": '填充冗余',
        "name": '标题大小写(英文标题残留)',
        "severity": 20,
        "auto": False,
        "priority": 'P4',
        "manual_hint": '检查中英文混排标题中, 英文单词是否错误使用了Title Case',
    },
    40: {
        "category": '网文·神态眼神',
        "name": 'AI空洞眼神',
        "keywords": [
            '眼底闪过一丝', '眸色沉沉', '眸光深邃', '眼神复杂',
            '眼中闪过一丝玩味', '眼底满是温柔', '面无表情',
            '神色淡漠', '眼底闪过一丝错愕', '眼底闪过一丝慌乱',
            '眼底闪过一丝寒意',
        ],
        "severity": 85, "auto": True, "priority": 'W0', "genre": "webnovel",
    },
    41: {
        "category": '网文·嘴角笑容',
        "name": 'AI模板笑容',
        "keywords": [
            '唇角微微勾起', '勾起一抹冷笑', '嘲讽的笑',
            '莞尔一笑', '浅浅一笑', '似笑非笑',
        ],
        "severity": 85, "auto": True, "priority": 'W0', "genre": "webnovel",
    },
    42: {
        "category": '网文·副词虚词',
        "name": 'AI副词虚词泛滥',
        "keywords": _WB_KEYS if _WB_KEYS else [
            '不由得', '下意识', '不自觉', '不知为何',
            '微微', '缓缓', '忽而', '骤然', '陡然', '淡淡', '半晌', '良久', '稍稍',
        ],
        "severity": 70, "auto": True, "priority": 'W1', "genre": "webnovel",
        "threshold": 0.005,
    },
    43: {
        "category": '网文·心脏情绪',
        "name": 'AI心脏矫情句',
        "keywords": [
            '心脏猛地一缩', '心头一颤', '心跳漏了一拍',
            '心底涌上一股暖意', '心底涌上一股寒意', '五味杂陈',
        ],
        "severity": 80, "auto": True, "priority": 'W1', "genre": "webnovel",
    },
    44: {
        "category": '网文·动作专项',
        "name": 'AI模板动作',
        "keywords": [
            '骨节分明的手', '指尖泛白', '攥紧拳头', '抬手抚上脸颊',
            '微微低头', '转头看去', '身子一僵', '脚步一顿',
            '呼吸一滞', '呼吸微促', '轻吸一口气', '低声开口',
        ],
        "severity": 75, "auto": True, "priority": 'W2', "genre": "webnovel",
    },
    45: {
        "category": '网文·写景环境',
        "name": 'AI滤镜写景',
        "keywords": [
            '漫天星河', '月色皎洁', '晚风习习', '岁月静好',
            '云雾缭绕', '灯火璀璨', '暮色沉沉',
            '仙气缥缈', '月华如水', '落雪纷纷', '桃花漫天',
            '霓虹闪烁', '车水马龙', '夜色撩人',
        ],
        "severity": 65, "auto": True, "priority": 'W2', "genre": "webnovel",
    },
    46: {
        "category": '网文·人物外貌',
        "name": 'AI流水线外貌',
        "keywords": [
            '肤白如玉', '眉眼精致', '五官立体', '绝美倾城', '刀削斧凿',
        ],
        "severity": 70, "auto": True, "priority": 'W2', "genre": "webnovel",
    },
    47: {
        "category": '网文·对话语气',
        "name": 'AI对话后缀模板',
        "keywords": [
            '淡淡开口', '平静说道', '沉声开口', '温柔说道', '冷冷开口',
        ],
        "severity": 75, "auto": True, "priority": 'W2', "genre": "webnovel",
    },
    48: {
        "category": '网文·句式改写',
        "name": 'AI高频句式',
        "severity": 60, "auto": False, "priority": 'W3', "genre": "webnovel",
        "formulas": [
            {"ai": '微微抬眸，眼底闪过一丝', "rule": '删"微微"，"闪过一丝X意"→"X意已经漫了出来"'},
            {"ai": '不由得红了耳根', "rule": '删"不由得"，外在表现放在情绪前面'},
            {"ai": '晚风习习', "rule": '删"习习"等AI形容词，用具体动作代替'},
            {"ai": '冷冷一笑', "rule": '"冷冷笑"→"笑意浮于皮面"'},
            {"ai": '眼眶微微泛红', "rule": '"微微泛红"→用颜色词+动作'},
        ],
        "manual_hint": '检查是否使用AI高频句式模板，参考wordbank.json中的formulas',
    },
    49: {
        "category": '网文·极简速查',
        "name": 'AI高频替换词',
        "severity": 50, "auto": False, "priority": 'W3', "genre": "webnovel",
        "quick_ref": [
            {"ai": '微微', "human": '轻'},
            {"ai": '眸光一闪', "human": '眼睫一颤'},
            {"ai": '心头一暖', "human": '胸口漾开浅热'},
            {"ai": '冷冷一笑', "human": '笑意浮于表面'},
            {"ai": '缓缓抬起手', "human": '手慢慢抬起来'},
            {"ai": '不知说什么', "human": '喉间卡了话音'},
            {"ai": '十分好看', "human": '看着顺眼耐看'},
            {"ai": '充满杀意', "human": '周身戾气加重'},
        ],
        "manual_hint": '对照极简速查表逐句扫描替换',
    },
    50: {
        "category": '网文·标点专项',
        "name": 'AI标点检测',
        "severity": 65, "auto": True, "priority": 'W4', "genre": "webnovel",
        "special": 'check_punctuation_ai',
    },
}

import json as _json
_WB = {}
_wb_path = Path(__file__).parent / "wordbank_flat.json"
if _wb_path.exists():
    try: _WB = _json.loads(_wb_path.read_text(encoding="utf-8"))
    except: pass
_WB_KEYS = list(_WB.keys()) if _WB else []

LINKAGES = [
    {"id":'2+18+3',"name":'头尾公式',"patterns":[2, 18, 3],"min_matches":1,"strategy":'三者构成AI文章的标准汉堡结构,必须整段重写'},
    {"id":'5+35',"name":'词库爆炸',"patterns":[5, 35],"min_matches":2,"strategy":'先删光连接词,再逐个审查,两个模式合在一起说明全文是流水线体'},
    {"id":'19+1+29',"name":'分析三连',"patterns":[19, 1, 29],"min_matches":1,"strategy":'AI的事实-拔高-强调三部曲,删矫揉-降意义-改陈述'},
    {"id":'36+33',"name":'安全两件套',"patterns":[36, 33],"min_matches":2,"strategy":'不是逐句改的问题,需切换到有观点的分析'},
    {"id":'22+14+16',"name":'结构三模板',"patterns":[22, 14, 16],"min_matches":1,"strategy":'整段废弃,这三个模式组合=100%AI生成'},
    {"id":'6+11',"name":'双翻译腔',"patterns":[6, 11],"min_matches":2,"strategy":'先替换通过...的方式,再删多余的进行,都来自英语思维'},
    {"id":'23+25+26',"name":'客服三连',"patterns":[23, 25, 26],"min_matches":1,"strategy":'全删,这三个说明文本是从聊天回复直接粘贴的'},
    {"id":'32+33+36',"name":'废话三件套',"patterns":[32, 33, 36],"min_matches":2,"strategy":'填充+限定+安全=说了等于没说,删70%后重写核心'},
    # Web novel linkages
    {"id":'40+41+43',"name":'情绪三件套',"patterns":[40, 41, 43],"min_matches":1,"strategy":'AI网文的脸+嘴+心三板斧,整段改:把情绪从这三部位分散到全身'},
    {"id":'42+50',"name":'副词标点双杀',"patterns":[42, 50],"min_matches":1,"strategy":'先合并短句删逗号,再逐个删副词,双管齐下才能彻底去味'},
    {"id":'44+47',"name":'动作对话脱节',"patterns":[44, 47],"min_matches":1,"strategy":'角色行为完全模板化,需根据角色性格重新设计动作和说话方式'},
    {"id":'45+46',"name":'外貌写景悬浮',"patterns":[45, 46],"min_matches":1,"strategy":'都市文古风文仙侠文各自不同,按专项替换表处理'},
    {"id":'40+41+42+43',"name":'网文四重大满贯',"patterns":[40, 41, 42, 43],"min_matches":1,"strategy":'四大类AI烂词全部命中=100%AI生成网文,建议全文按词库逐句替换'},
]


def detect_pattern(text, pattern_id):
    results, lines = [], text.split("\n")
    pat = PATTERNS[pattern_id]
    if "keywords" in pat:
        for kw in pat["keywords"]:
            for i, line in enumerate(lines, 1):
                for m in re.finditer(kw, line):
                    pos = m.start()
                    ctx = line[max(0,pos-30):min(len(line),m.end()+30)]
                    results.append({"line":i,"col":pos+1,"match":m.group(),"context":ctx.strip(),
                        "pattern":pattern_id,"pattern_name":pat["name"],"category":pat["category"],
                        "priority":pat.get("priority","P3")})
    if "regex" in pat and pat.get("regex"):
        for i, line in enumerate(lines, 1):
            for m in re.finditer(pat["regex"], line):
                pos = m.start()
                ctx = line[max(0,pos-30):min(len(line),m.end()+30)]
                if not any(r["line"]==i and r["col"]==pos+1 for r in results):
                    results.append({"line":i,"col":pos+1,"match":m.group(),"context":ctx.strip(),
                        "pattern":pattern_id,"pattern_name":pat["name"],"category":pat["category"],
                        "priority":pat.get("priority","P3")})
    return results

def detect_punctuation(text):
    results = []
    for i, line in enumerate(text.split("\n"), 1):
        for m in re.finditer(r'(?<![0-9])\.(?![0-9]\.?)(?=[^\d\s，。！？、；：\u201c\u201d\u2018\u2019）)]|$)', line):
            pos = m.start()
            ctx = line[max(0,pos-10):min(len(line),m.end()+10)]
            results.append({"line":i,"col":pos+1,"match":"英文句号(.)","context":ctx.strip(),
                "pattern":12,"pattern_name":"英文标点混用","category":"翻译腔","priority":"P4"})
    return results

def detect_emoji(text):
    results = []
    ep = re.compile('[\U0001F300-\U0001F9FF]|[\U0001FA00-\U0001FA6F]|[\U0001FA70-\U0001FAFF]|[\u2600-\u27BF]|[\u2B50\u2764\u2705]|[\U0001F600-\U0001F64F]')
    for i, line in enumerate(text.split("\n"), 1):
        for m in ep.finditer(line):
            pos = m.start()
            ctx = line[max(0,pos-10):min(len(line),m.end()+10)]
            results.append({"line":i,"col":pos+1,"match":f"Emoji:{m.group()}","context":ctx.strip(),
                "pattern":15,"pattern_name":"Emoji装饰","category":"结构模板","priority":"P4"})
    return results

def detect_webnovel_ai(text):
    """Detect web novel AI vocabulary using wordbank and pattern 42 keywords."""
    results = []
    for i, line in enumerate(text.split("\n"), 1):
        for kw in _WB_KEYS:
            if kw in line:
                pos = line.find(kw)
                ctx = line[max(0,pos-20):min(len(line),pos+len(kw)+20)]
                results.append({"line":i,"col":pos+1,"match":kw,"context":ctx.strip(),
                    "pattern":42,"pattern_name":"AI副词虚词","category":"网文·副词虚词",
                    "priority":"W1","suggestion":_WB.get(kw,"")})
    return results

# Enhanced punctuation AI patterns (from wordbank)
_PUNCT_AI_RE = [
    (r"……{2,}", "滥用省略号", "禁用……表达犹豫：改用短句停顿替代"),
    (r"[^。！？\n]+(?:，[^。！？\n]+){3,}", "逗号连排", "一句话内逗号>2个，合并细碎短句"),
    (r"[^！。\n]*！.*！", "感叹号双连", "少用！多用。塑造隐忍克制情绪"),
    (r"[^、。，\n]+(?:、[^、。，\n]+){3,}", "顿号连排", "连续3个以上顿号分隔，AI万能排比"),
    ("！\\s*$", "感叹号结尾", "段落以感叹号结尾，情绪外放"),
    (r"，.*，.*，", "逗号三连", "一句话内3个逗号，流水句过重"),
]

def detect_punctuation_ai(text):
    results = []
    for i, line in enumerate(text.split("\n"), 1):
        for regex, name, desc in _PUNCT_AI_RE:
            for m in re.finditer(regex, line):
                pos = m.start()
                ctx = line[max(0,pos-20):min(len(line),m.end()+20)]
                results.append({"line":i,"col":pos+1,"match":m.group()[:30],"context":ctx.strip(),
                    "pattern":50,"pattern_name":f"标点AI({name})","category":"网文·标点专项",
                    "priority":"W4","suggestion":desc})
    return results

def count_char_stats(text):
    clean = re.sub(r"\s+","",text)
    tc = len(clean); dc = clean.count("——")
    tone_count = len(re.findall(r"[呢吧哦啊哈呀]",clean))
    sc = clean.count(";"); de_count = clean.count("的")
    sentences = [s.strip() for s in re.split(r"[。！？!?\n]",text) if s.strip()]
    de_ps = {"total_sentences":len(sentences),"de_count":de_count,
        "ratio":round(de_count/max(len(sentences),1),2),
        "high_de_sentences":[{"sentence":s[:80],"de_count":s.count("的")} for s in sentences if s.count("的")>=3][:10]}
    cq = clean.count("\u201c")+clean.count("\u201d")+clean.count("\u2018")+clean.count("\u2019")
    return {"total_chars":tc,"dash_count":dc,"tone_count":tone_count,"semicolon_count":sc,
        "de_stats":de_ps,"sentence_count":len(sentences),"curly_quotes":cq}

def analyze_linkages(ph):
    found = []
    for link in LINKAGES:
        matched, details = 0, {}
        for pid in link["patterns"]:
            if pid in ph and ph[pid] >= link["min_matches"]:
                matched += 1; details[pid] = ph[pid]
        if matched >= 2:
            found.append({"id":link["id"],"name":link["name"],"strategy":link["strategy"],"matched_patterns":details})
    return found

def calculate_score(all_results, stats, text, linkages=None):
    clean = re.sub(r"\s+","",text); tc = max(len(clean),1)
    ph = defaultdict(int)
    for r in all_results: ph[r["pattern"]] += 1
    raw, mx = 0, 0
    for pid, pat in PATTERNS.items():
        sv = pat.get("severity",50); mx += sv
        if pid in ph: raw += sv*(0.5+0.5*min(min(ph[pid],5)/3,1.0))
    score = min(100,int(raw/max(mx,1)*100))
    if stats["dash_count"]/max(tc,1)*1000>4: score = min(100,score+10)
    if stats["tone_count"]/max(tc,1)*1000>8: score = min(100,score+10)
    # Bonus: web novel density
    wn_hits = sum(ph.get(p,0) for p in range(40,51))
    wn_score = min(30, int(wn_hits/max(tc,1)*1000))
    score = min(100, score + wn_score)
    if linkages:
        wn_link = sum(1 for l in linkages if any(p in range(40,51) for p in l.get("matched_patterns",{})))
        if wn_link >= 3: score = min(100,score+20)
        elif wn_link >= 2: score = min(100,score+12)
        elif len(linkages)>=3: score = min(100,score+15)
        elif len(linkages)>=1: score = min(100,score+5)
    return score

def recommend_intensity(score):
    if score>=75: return "网文(全量去味)"
    elif score>=60: return "重度"
    elif score>=40: return "中度"
    elif score>=20: return "轻度"
    else: return "极轻"

def generate_prescription(ph, linkages, tc):
    rx = {"W0":[], "W1":[], "W2":[], "W3":[], "W4":[],
          "P0":[], "P1":[], "P2":[], "P3":[], "P4":[]}
    for pid, cnt in sorted(ph.items()):
        p = PATTERNS.get(pid)
        if not p: continue
        rx[p.get("priority","P3")].append({"pattern_id":pid,"name":p["name"],"category":p["category"],"hit_count":cnt,"severity":p.get("severity",50)})
    for k in rx: rx[k].sort(key=lambda x:x["severity"],reverse=True)
    return rx, [l["strategy"] for l in linkages] if linkages else []

def is_webnovel(ph):
    """Detect if text is web novel by pattern distribution."""
    wn_hits = sum(ph.get(p,0) for p in range(40,51))
    total = sum(ph.values())
    return total > 0 and wn_hits / total > 0.15

def report_text(all_results, stats, score, linkages=None, prescription=None, linkage_advice=None):
    ph = defaultdict(int)
    for r in all_results: ph[r["pattern"]] += 1
    lines = ["="*66,"  去AI味自动检测报告 v5.0  |  AI文库·即时诊断","="*66,"",
             f"  AI味评分: {score}/100 -> {recommend_intensity(score)}",
             f"  文本类型: {'【网文小说】' if is_webnovel(dict(ph)) else '通用文本'}",
             f"  总字符数: {stats['total_chars']}  |  句子数: {stats['sentence_count']}",
             f"  命中模式: {len(set(r['pattern'] for r in all_results))}种  |  命中次数: {len(all_results)}",""]
    if linkages:
        wn_link = sum(1 for l in linkages if any(p in range(40,51) for p in l.get("matched_patterns",{})))
        tip = " -> 网文大面积AI痕迹，建议全文按词库替换" if wn_link>=2 else (" -> 建议重度去味" if len(linkages)>=3 else "")
        for l in linkages: lines.append(f"    [{l['id']}] {l['name']}: {l['strategy']}")
        lines.append("")
    if prescription:
        lines.append("  -- 去味处方 --")
        for pl in ["W0","W1","W2","W3","W4","P0","P1","P2","P3","P4"]:
            items = prescription.get(pl,[])
            if items:
                names = ", ".join(i["name"] for i in items[:6])
                if len(items)>6: names += f" 等{len(items)}项"
                lines.append(f"  {pl}: {names}")
        lines.append("")
    bc = {}
    for r in all_results: bc.setdefault(r["category"],[]).append(r)
    for cat, items in bc.items():
        lines.append(f"-- {cat} ({len(items)}处) --")
        sh = {}
        for r in items[:30]:
            key = (r["pattern"],r["match"])
            sh[key] = sh.get(key,0)+1
        for (pid,match), cnt in sh.items():
            pn = PATTERNS[pid]["name"]; pp = PATTERNS[pid].get("priority","")
            sug = ""
            for r in items[:30]:
                if r["pattern"]==pid and r["match"]==match and r.get("suggestion"):
                    sug = f" -> {r['suggestion']}"; break
            lines.append(f"  [{pn}] [{pp}] {match} x{cnt}{sug}")
        lines.append("")
    if linkage_advice:
        lines.append("-- 联动策略 --")
        for a in linkage_advice: lines.append(f"  {a}")
        lines.append("")
    mi = [pid for pid,p in PATTERNS.items() if not p.get("auto") and p.get("manual_hint")]
    if mi:
        lines.append(f"-- 人工判断({len(mi)}种) --")
        for pid in mi: lines.append(f"  [{PATTERNS[pid]['name']}] {PATTERNS[pid]['manual_hint']}")
        lines.append("")
    lines.extend(["-- 字符统计 --",f"  破折号: {stats['dash_count']}次",f"  语气词: {stats['tone_count']}次",
                  f"  分号: {stats['semicolon_count']}次",f"  的: {stats['de_stats']['de_count']}次, 均{stats['de_stats']['ratio']}/句"])
    if stats['de_stats']['high_de_sentences']: lines.append(f"  高密的句: {len(stats['de_stats']['high_de_sentences'])}句")
    if stats.get('curly_quotes',0): lines.append(f"  弯引号: {stats['curly_quotes']}次")
    wn_chars = sum(len(r["match"]) for r in all_results if r.get("pattern",0) in range(40,51))
    if wn_chars and stats['total_chars'] > 0:
        pct = min(100, wn_chars / max(stats['total_chars'], 1) * 100)
        lines.append(f"  网文AI命中字符: {wn_chars}字 (占比{pct:.1f}%)")
    lines.extend(["","="*66])
    return "\n".join(lines)

def report_json(all_results, stats, score, linkages=None, prescription=None, linkage_advice=None):
    bp = {}
    for r in all_results:
        pid = str(r["pattern"])
        if pid not in bp: bp[pid] = {"name":r["pattern_name"],"category":r["category"],"priority":r.get("priority","P3"),"count":0,"hits":[]}
        bp[pid]["count"] += 1
        hit = {"line":r["line"],"match":r["match"],"context":r["context"]}
        if r.get("suggestion"): hit["suggestion"] = r["suggestion"]
        bp[pid]["hits"].append(hit)
    return json.dumps({"version":"5.0.0","score":score,"recommendation":recommend_intensity(score),
        "stats":{"total_chars":stats["total_chars"],"sentence_count":stats["sentence_count"],
            "total_hits":len(all_results),"patterns_found":len(bp),
            "dash_count":stats["dash_count"],"tone_count":stats["tone_count"],
            "semicolon_count":stats["semicolon_count"],"curly_quotes":stats.get("curly_quotes",0),
            "de_stats":stats["de_stats"]},
        "linkages":linkages or [],"linkage_advice":linkage_advice or [],
        "prescription":prescription or {},"patterns":bp}, ensure_ascii=False, indent=2)

def detect(text, mode="text", only=None, threshold=None):
    SPEC = {"check_punctuation":detect_punctuation,"check_webnovel_wordbank":detect_webnovel_ai,"check_punctuation_ai":detect_punctuation_ai}
    ar = []; tps = only if only else list(PATTERNS.keys())
    for pid in tps:
        if pid not in PATTERNS: continue
        p = PATTERNS[pid]
        if not p.get("auto",True): continue
        fn = SPEC.get(p.get("special",""))
        if fn: ar.extend(fn(text))
        else:
            rs = detect_pattern(text,pid)
            th = threshold if threshold is not None else p.get("threshold")
            if th is not None:
                wc = len(re.sub(r"\s+","",text))
                if len(rs)/max(wc,1) < th: continue
            ar.extend(rs)
    if 15 in tps: ar.extend(detect_emoji(text))
    st = count_char_stats(text)
    ph = defaultdict(int)
    for r in ar: ph[r["pattern"]] += 1
    lks = analyze_linkages(dict(ph))
    sc = calculate_score(ar,st,text,lks)
    rx, la = generate_prescription(dict(ph),lks,st["total_chars"])
    st["linkages"] = [{"id":l["id"],"name":l["name"],"strategy":l["strategy"]} for l in lks]
    st["prescription"] = rx; st["linkage_advice"] = la
    if mode=="json": return report_json(ar,st,sc,lks,rx,la)
    return report_text(ar,st,sc,lks,rx,la)

def detect_inline(text):
    SPEC = {"check_punctuation":detect_punctuation,"check_webnovel_wordbank":detect_webnovel_ai,"check_punctuation_ai":detect_punctuation_ai}
    ar = []
    for pid in [p for p,pt in PATTERNS.items() if pt.get("auto",True)]:
        pt = PATTERNS[pid]
        fn = SPEC.get(pt.get("special",""))
        if fn: ar.extend(fn(text))
        else: ar.extend(detect_pattern(text,pid))
    if 15 in PATTERNS: ar.extend(detect_emoji(text))
    st = count_char_stats(text)
    ph = defaultdict(int)
    for r in ar: ph[r["pattern"]] += 1
    lks = analyze_linkages(dict(ph))
    sc = calculate_score(ar,st,text,lks)
    rx, la = generate_prescription(dict(ph),lks,st["total_chars"])
    return sc, {"total_hits":len(ar),"patterns_found":len(set(r["pattern"] for r in ar)),
        "recommendation":recommend_intensity(sc),"linkages":[l["id"] for l in lks] if lks else [],
        "linkage_advice":la or [],"prescription":rx}

PREFS_DIR = Path.home()/".workbuddy"/"remove-ai-flavor"/"prefs"
PREFS_DIR.mkdir(parents=True,exist_ok=True)

def main():
    parser = argparse.ArgumentParser(description="去AI味检测器 v5.1 — 50模式+网文专区+W处方+指令库·即时诊断")
    parser.add_argument("text",nargs="?",help="文本"); parser.add_argument("--file","-f",help="文件路径")
    parser.add_argument("--json","-j",action="store_true"); parser.add_argument("--only","-o",help="指定模式,逗号分隔")
    parser.add_argument("--threshold","-t",type=float); parser.add_argument("--batch","-b",help="批量glob")
    parser.add_argument("--compare","-c",help="对比参考文件"); parser.add_argument("--save-prefs",help="保存偏好")
    parser.add_argument("--webnovel","-w",action="store_true",help="网文模式(仅检测40-50)")
    parser.add_argument("--genre","-g",help="指定体裁(webnovel/tech/social/formal/creative/academic)")
    parser.add_argument("--show-blacklist",action="store_true",help="显示网文禁用词列表")
    args = parser.parse_args()
    if args.save_prefs:
        (PREFS_DIR/f"{args.save_prefs}.json").write_text(
            json.dumps({"name":args.save_prefs,"version":"5.0.0","saved_at":__import__("datetime").datetime.now().isoformat()},
            ensure_ascii=False,indent=2),encoding="utf-8")
        print(f"  偏好已保存: {args.save_prefs}"); return
    if args.show_blacklist:
        if _WB:
            cats = _WB_FULL.get("categories",[]) if _WB_FULL else []
            print(f"  网文禁用词库 ({len(_WB_KEYS)}条)")
            if cats:
                for cat in cats:
                    items = [r["ai"] for r in cat.get("replacements",[])][:6]
                    print(f"  [{cat['name']}] {', '.join(items)}")
            else:
                for i, (ai, human) in enumerate(list(_WB.items())[:30], 1):
                    print(f"  {i}. {ai} -> {human}")
                if len(_WB)>30: print(f"  ... 共{len(_WB)}条")
        else:
            print("  词库文件未找到: wordbank_flat.json");
        return
    if args.batch:
        import glob as gm
        files = gm.glob(args.batch,recursive=True)
        if not files: print("无匹配文件",file=sys.stderr); sys.exit(1)
        ts = 0
        for fp in sorted(files):
            try: txt = Path(fp).read_text(encoding="utf-8")
            except: continue
            sc, sm = detect_inline(txt); ts += sc
            print(f"  [{sm['recommendation']}] {sc}/100 | {sm['total_hits']}处 | {fp}")
        if files: print(f"\n  平均: {ts/len(files):.1f}/100"); return
    if args.file:
        fp = Path(args.file)
        if not fp.exists(): print(f"错误:文件不存在-{args.file}",file=sys.stderr); sys.exit(1)
        txt = fp.read_text(encoding="utf-8")
    elif args.text: txt = args.text
    else:
        if not sys.stdin.isatty(): txt = sys.stdin.read()
        else: print("用法: detector.py <文本> 或 --file <文件>",file=sys.stderr); parser.print_help(); sys.exit(1)
    if args.compare:
        rp = Path(args.compare)
        if not rp.exists(): print(f"错误:参考文件不存在-{args.compare}",file=sys.stderr); sys.exit(1)
        rs, _ = detect_inline(rp.read_text(encoding="utf-8")); print(f"  参考评分: {rs}/100")
    only = None
    if args.webnovel:
        only = list(range(40,51))
    elif args.only:
        only = [int(x.strip()) for x in args.only.split(",")]
    if args.file:
        fp = Path(args.file)
        if not fp.exists(): print(f"错误:文件不存在-{args.file}",file=sys.stderr); sys.exit(1)
        txt = fp.read_text(encoding="utf-8")
    elif args.text: txt = args.text
    else:
        if not sys.stdin.isatty(): txt = sys.stdin.read()
        else: print("用法: detector.py <文本> 或 --file <文件>",file=sys.stderr); parser.print_help(); sys.exit(1)
    if args.compare:
        rp = Path(args.compare)
        if not rp.exists(): print(f"错误:参考文件不存在-{args.compare}",file=sys.stderr); sys.exit(1)
        rs, _ = detect_inline(rp.read_text(encoding="utf-8")); print(f"  参考评分: {rs}/100")
    result = detect(txt,mode="json" if args.json else "text",only=only,threshold=args.threshold)
    print(result)
    if args.compare:
        sc, _ = detect_inline(txt)
        delta = rs-sc
        print(f"\n  当前评分: {sc}/100")
        if delta>0: print(f"  去味效果: 降低{delta}分({delta/rs*100:.1f}%)")
        elif delta<0: print(f"  WARN: 升高{abs(delta)}分")
        else: print("  评分无变化")

if __name__=="__main__": main()
