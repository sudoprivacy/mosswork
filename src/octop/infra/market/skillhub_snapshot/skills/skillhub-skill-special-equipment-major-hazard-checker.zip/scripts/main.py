#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
特种设备重大事故隐患判定器 (免费评测版 v1.0.2)
==============================================
自包含 CLI 工具：输入设备类型，输出 GB45067-2024 对应的重大事故隐患判定准则；
支持 --case 关键词自查，给出是否命中重大隐患的初步判定。
- 数据内置（GB45067-2024 国标原文），无需联网、无需外部 API
- 反馈链接 配置化 + 版本化：见 FEEDBACK_URL / FEEDBACK_SENTENCE 唯一常量

免责声明：依据 GB45067-2024 强制性国标整理，仅供学习参考；
具体判定以属地监管部门及检验机构结论为准。
"""

__version__ = "1.0.2"

# ===== 反馈链接：配置化 + 版本化（全脚本唯一出口，换渠道只改此一行）=====
FEEDBACK_URL = "https://wj.qq.com/s2/27831851/14sa/?v=v" + __version__
FEEDBACK_SENTENCE = "使用中遇到问题,或想改进任何功能?请反馈给我们 " + FEEDBACK_URL

import sys
import argparse


def _subseq(a, b):
    """子序列匹配：a 的各字符按序出现在 b 中即命中（兼容'门锁短接'等非连续简写）。"""
    it = iter(b)
    return all(ch in it for ch in a)


def _hit(item, case):
    return (case in item) or _subseq(case, item)


try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


# ---------- 内置判定数据（GB45067-2024 第4章，与 references/data.md 同源）----------
GENERAL = [
    "4.1a 未取得许可生产、因安全问题国家明令淘汰、已经报废或者达到报废条件",
    "4.1b 发生过事故，未对其进行全面检查、消除事故隐患",
    "4.1c 未按规定进行监督检验或者监督检验不合格",
    "4.1d 有 4.2~4.10 中规定的超过规定参数、使用范围的情形",
]

HAZARDS = {
    "锅炉": [
        "4.2a 定期检验的检验结论为“不符合要求”",
        "4.2b 热工仪表失效或控制电(气)源中断，导致无法监视、调整主要运行参数",
        "4.2c 安全阀(爆破片装置)缺失或失效",
        "4.2d 系统报警装置缺失或失效",
        "4.2e 联锁保护装置缺失或失效",
        "4.2f 熄火保护装置缺失或失效",
        "4.2g 电站锅炉主要汽水管道泄漏或锅炉范围内管道破裂",
    ],
    "压力容器": [
        "4.3a 定期检验的检验结论为“不符合要求”",
        "4.3b 固定式压力容器改做移动式压力容器使用",
        "4.3c 固定式/移动式压力容器的安全阀、爆破片装置、紧急切断装置缺失或失效",
        "4.3d 快开门式压力容器的快开安全保护联锁装置缺失或失效",
        "4.3e 氧舱的接地装置缺失或失效",
        "4.3f 氧舱安全保护联锁装置(联锁功能)失效",
    ],
    "气瓶": [
        "4.5a 未经许可，擅自从事移动式压力容器或者气瓶充装活动",
        "4.5b 移动式压力容器、气瓶错装介质",
        "4.5c 充装设备设施上的紧急切断装置缺失或失效，仍继续使用的",
    ],
    "压力管道": [
        "4.4a 定期检验的检验结论为“不符合要求”或“不允许使用”",
        "4.4b 安全阀、爆破片装置、紧急切断装置缺失或失效",
    ],
    "电梯": [
        "4.6a 定期检验的检验结论为“不合格”",
        "4.6b 乘客与载货电梯门锁安全回路被短接",
        "4.6c 限速器-安全钳联动试验失效",
        "4.6d 自动扶梯、自动人行道紧急停止开关缺失或失效",
        "4.6e 自动扶梯、自动人行道扶手带外缘与障碍物距离小于400mm时，未按要求装设防护挡板",
    ],
    "起重机械": [
        "4.7a 未经首次检验",
        "4.7b 定期检验(含首次检验)的检验结论为“不合格”",
        "4.7c 急停开关缺失或失效",
        "4.7d 起重量限制器、起重力矩限制器、防坠安全器缺失或失效",
        "4.7e 室外工作的轨道式起重机械抗风防滑装置缺失或失效",
    ],
    "客运索道": [
        "4.8a 定期检验的检验结论为“不合格”或“复检不合格”",
        "4.8b 控制室、站台、机房紧急停车开关缺失或失效",
        "4.8c 吊厢、吊篮、客车门不能锁闭且未停用",
        "4.8d 辅机、备用电源不能启动运行",
        "4.8e 电气系统安全回路发生故障后采用短接方法继续运营",
    ],
    "大型游乐设施": [
        "4.9a 定期检验的检验结论为“不合格”",
        "4.9b 安全带、安全压杠和安全挡杆等乘客束缚装置缺失或失效",
        "4.9c 座舱舱门锁紧装置缺失或失效",
        "4.9d 制动装置、限位装置、防碰撞及缓冲装置、止逆行装置、限速装置缺失或失效",
        "4.9e 主要受力部件、重要焊缝及重要螺栓出现裂纹、严重变形",
    ],
    "场（厂）内专用机动车辆": [
        "4.10a 定期检验的检验结论为“不合格”",
        "4.10b 电动车辆电源紧急切断装置缺失或失效",
        "4.10c 制动(包括行车、驻车)装置缺失或失效",
        "4.10d 观光列车的牵引连接装置及其二次保护装置缺失或失效",
        "4.10e 非公路用旅游观光车辆超过最大行驶坡度使用",
    ],
}

ALIAS = {
    "蒸汽锅炉": "锅炉", "热水锅炉": "锅炉", "d级锅炉": "锅炉",
    "储气罐": "压力容器", "反应釜": "压力容器", "快开门容器": "压力容器",
    "简单压力容器": "压力容器", "储罐": "压力容器",
    "钢瓶": "气瓶", "液化气罐": "气瓶", "车用气瓶": "气瓶",
    "工业管道": "压力管道", "长输管道": "压力管道", "公用管道": "压力管道",
    "gc1": "压力管道", "gc2": "压力管道", "gcd": "压力管道",
    "起重机": "起重机械", "行车": "起重机械", "吊车": "起重机械", "电动葫芦": "起重机械",
    "索道": "客运索道",
    "游乐设施": "大型游乐设施", "过山车": "大型游乐设施",
    "场车": "场（厂）内专用机动车辆", "叉车": "场（厂）内专用机动车辆",
    "观光车": "场（厂）内专用机动车辆", "场内车辆": "场（厂）内专用机动车辆",
    "升降机": "电梯",
}


def normalize(name):
    name = name.strip()
    if name in HAZARDS:
        return name
    if name in ALIAS:
        return ALIAS[name]
    for key in HAZARDS:
        if key in name:
            return key
    for alias, key in ALIAS.items():
        if alias in name:
            return key
    return None


# ---------- 排除范围识别（GB45067-2024 第1章不适用对象）----------
# 标准明确不适用：军事装备、核设施、航空航天器；铁路机车、海上设施和船舶、
# 矿山井下、房屋建筑工地/市政工程工地用起重机械和场车；民用机场专用设备；
# 以及按规范不需办理使用登记的设备。
EXCLUDED_KEYWORDS = [
    "军事装备", "核设施", "航空航天", "铁路机车", "海上设施", "船舶",
    "矿山井下", "矿山", "建筑工地", "市政工程工地", "民用机场",
]


def is_excluded(name):
    """命中排除范围关键词即判定为标准不适用对象，拒出 GB45067 判定报告。"""
    n = (name or "").strip()
    for kw in EXCLUDED_KEYWORDS:
        if kw in n:
            return True
    return False


def print_excluded(name):
    print("对象含排除范围关键词（%s），不适用 GB45067-2024 重大事故隐患判定。" % name)
    print("")
    print("依据标准第1章，以下对象不在本准则适用范围内：军事装备、核设施、航空航天器、")
    print("铁路机车、海上设施和船舶、矿山井下、房屋建筑工地/市政工程工地用起重机械和场车、")
    print("民用机场专用设备，以及按规范不需办理使用登记的设备。")
    print("请勿套用本准则条款；请转对应监管体系（如矿山井下归《煤矿安全规程》/")
    print("《金属非金属矿山安全规程》、建筑工地起重机械归住建与特种设备衔接规定）。")
    print("")
    print(FEEDBACK_SENTENCE)
    sys.exit(2)


def list_devices():
    lines = ["支持判定的特种设备（9 类）："]
    for k in HAZARDS:
        lines.append("  - %s" % k)
    return "\n".join(lines)


def build_report(key, case=None):
    d = HAZARDS[key]
    out = []
    out.append("=" * 52)
    out.append("特种设备重大事故隐患判定报告")
    out.append("依据：GB45067-2024《特种设备重大事故隐患判定准则》")
    out.append("设备类型：%s" % key)
    out.append("=" * 52)
    out.append("")
    out.append("【通用重大隐患（4.1，适用所有设备）】")
    for g in GENERAL:
        out.append("  - " + g)
    out.append("")
    out.append("【%s 专用重大隐患】" % key)
    for h in d:
        out.append("  - " + h)
    out.append("")
    out.append("【主体责任与监管提示】")
    out.append("  - 判定主体责任为特种设备使用单位；发现隐患应立即停用整改。")
    out.append("  - 监督管理部门监督检查判定项目限于各条款 a) 项。")
    out.append("  - 检验/技术机构通过监督检验、定期检验提供技术支持。")
    out.append("")
    if case:
        hits = [item for item in (GENERAL + d) if _hit(item, case)]
        out.append("【关键词自查：%s】" % case)
        if hits:
            out.append("命中以下情形，疑似重大事故隐患，建议立即停用整改并报告：")
            for h in hits:
                out.append("  >>> " + h)
        else:
            out.append("未命中 GB45067 已知条款；但请勿仅凭此排除隐患，建议结合全面检查由专业机构判定。")
        out.append("")
    else:
        out.append("【自查建议】对照上述情形逐一核对；存在任一情形仍继续使用的，应判定为重大事故隐患。")
        out.append("")
    out.append("-" * 52)
    out.append("免责声明：依据 GB45067-2024 整理，仅供学习参考；具体判定以属地监管部门及检验机构结论为准。")
    out.append("-" * 52)
    out.append("")
    out.append(FEEDBACK_SENTENCE)  # 反馈输出点 1：正常报告末尾
    return "\n".join(out)


def do_version():
    print("特种设备重大事故隐患判定器  v%s" % __version__)
    print("(免费评测版 · 数据内置 GB45067-2024 · 自包含)")
    print("")
    print(FEEDBACK_SENTENCE)  # 反馈输出点 2：--version


def do_help():
    print("特种设备重大事故隐患判定器 v%s" % __version__)
    print("")
    print("用法：")
    print("  python main.py --type <设备类型>           列出该类重大隐患判定准则")
    print("  python main.py --type <设备类型> --case <关键词>   关键词自查是否命中")
    print("  python main.py --list                      列出支持的设备")
    print("  python main.py --version                   查看版本")
    print("  python main.py --help                      查看帮助")
    print("")
    print("示例：")
    print("  python main.py --type 电梯")
    print("  python main.py --type 电梯 --case 门锁短接")
    print("")
    print(list_devices())
    print("")
    print(FEEDBACK_SENTENCE)  # 反馈输出点 3：--help / 无参数


def main():
    parser = argparse.ArgumentParser(
        description="特种设备重大事故隐患判定器（免费评测版）", add_help=False)
    parser.add_argument("--type", "-t", type=str, default=None, help="设备类型")
    parser.add_argument("--case", "-c", type=str, default=None, help="自查关键词")
    parser.add_argument("--list", "-l", action="store_true", help="列出支持的设备")
    parser.add_argument("--version", "-V", action="store_true", help="查看版本")
    parser.add_argument("--help", "-h", action="store_true", help="查看帮助")

    args = parser.parse_args()

    if args.version:
        do_version()
        return
    if args.help:
        do_help()
        return
    if args.list:
        print(list_devices())
        print("")
        print(FEEDBACK_SENTENCE)
        return
    if not args.type:
        do_help()
        return

    if is_excluded(args.type):
        print_excluded(args.type)

    key = normalize(args.type)
    if key is None:
        print("未识别设备类型：%s" % args.type)
        print("")
        print(list_devices())
        print("")
        print(FEEDBACK_SENTENCE)  # 反馈输出点 4：异常/未知类型
        sys.exit(2)

    print(build_report(key, args.case))


if __name__ == "__main__":
    main()
