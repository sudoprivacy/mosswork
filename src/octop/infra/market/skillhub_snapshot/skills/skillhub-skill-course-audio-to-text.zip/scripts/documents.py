from pathlib import Path
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor
from .docx_styles import FONT_NAME, META_STYLE, TRANSCRIPT_LABEL_STYLE, configure_styles
from .structured_summary import render_structured_summary


def base_document(job, title):
    doc = Document()
    configure_styles(doc)
    doc.add_heading(title, 0)
    doc.add_paragraph("文件名：" + job["original_name"], META_STYLE)
    doc.add_paragraph("完成时间：" + job["result_received_at"], META_STYLE)
    import json
    metadata = json.loads(job.get("validation_json") or "{}")
    if metadata.get("duration_seconds") is not None:
        doc.add_paragraph(f"时长：{metadata['duration_seconds']:.2f} 秒", META_STYLE)
    return doc


TODO_COLUMN_WIDTHS_CM = (1.4, 10.0, 2.2, 2.3)
TODO_BODY_SIZE = Pt(11)
TODO_CELL_MARGIN_TWIPS = (("top", "80"), ("left", "120"), ("bottom", "80"), ("right", "120"))


BOLD_MARK = re.compile(r"\*\*(.+?)\*\*", re.S)


def _add_run(paragraph, value, *, size, bold=False, color=None):
    run = paragraph.add_run(value)
    run.font.name = FONT_NAME
    run.font.size = size
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return run


def _set_cell_text(cell, value, *, size, bold=False, color=None, center=False):
    # Remove leftover runs/paragraphs so exactly one clean paragraph remains.
    first = cell.paragraphs[0]
    for run in list(first.runs):
        run._r.getparent().remove(run._r)
    for paragraph in list(cell.paragraphs[1:]):
        paragraph._p.getparent().remove(paragraph._p)
    # Backend text may carry markdown-style **bold** markers (e.g. todo
    # contents); convert them to real bold runs so both the preview and
    # Word/WPS render them, instead of printing literal asterisks.
    position = 0
    for match in BOLD_MARK.finditer(value):
        if match.start() > position:
            _add_run(first, value[position:match.start()], size=size, bold=bold, color=color)
        _add_run(first, match.group(1), size=size, bold=True, color=color)
        position = match.end()
    if position < len(value):
        _add_run(first, value[position:], size=size, bold=bold, color=color)
    if not first.runs:  # empty cell still gets one run to keep structure sane
        _add_run(first, "", size=size, bold=bold, color=color)
    if center:
        first.alignment = WD_ALIGN_PARAGRAPH.CENTER


def _set_table_cell_margins(table):
    # tblCellMar must sit between tblLayout and tblLook in tblPr (OOXML schema
    # order); Word runs document repair if the order is wrong.
    tbl_pr = table._tbl.tblPr
    margins = OxmlElement("w:tblCellMar")
    for side, value in TODO_CELL_MARGIN_TWIPS:
        node = OxmlElement("w:" + side)
        node.set(qn("w:w"), value)
        node.set(qn("w:type"), "dxa")
        margins.append(node)
    anchor = tbl_pr.find(qn("w:tblLook"))
    if anchor is not None:
        anchor.addprevious(margins)
    else:
        tbl_pr.append(margins)


def add_todo_table(document, todos):
    from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
    from docx.shared import Cm, Emu
    table = document.add_table(rows=1, cols=4)
    table.style = "Table Grid"
    headers = ["序号", "待办事项", "负责人", "截止时间"]
    # Under fixed layout Word/WPS take column widths from w:tblGrid, NOT from
    # the cells' w:tcW (python-docx generates the grid equal-width). Scale the
    # intended widths to the page text column and write BOTH places, plus an
    # explicit tblW, so every renderer agrees.
    section = document.sections[0]
    available = section.page_width.twips - section.left_margin.twips - section.right_margin.twips
    intended = sum(Cm(value).twips for value in TODO_COLUMN_WIDTHS_CM)
    scale = available / intended
    column_twips = [int(Cm(value).twips * scale) for value in TODO_COLUMN_WIDTHS_CM]
    column_twips[1] += available - sum(column_twips)  # absorb rounding drift
    widths = tuple(Emu(twips * 635) for twips in column_twips)  # 1 twip = 635 EMU
    for grid_col, twips in zip(table._tbl.tblGrid.findall(qn("w:gridCol")), column_twips):
        grid_col.set(qn("w:w"), str(twips))
    tbl_w = table._tbl.tblPr.find(qn("w:tblW"))
    if tbl_w is not None:
        tbl_w.set(qn("w:w"), str(sum(column_twips)))
        tbl_w.set(qn("w:type"), "dxa")
    _set_table_cell_margins(table)
    # Header row: bold black centered text, no shading.
    for cell, value, width in zip(table.rows[0].cells, headers, widths):
        cell.width = width
        _set_cell_text(cell, value, size=TODO_BODY_SIZE, bold=True, center=True)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    # Body rows: centered short columns, no shading.
    for index, todo in enumerate(todos, 1):
        values = (str(index), todo.content, todo.owner or "", todo.deadline or "")
        row = table.add_row()
        for position, (cell, value, width) in enumerate(zip(row.cells, values, widths)):
            cell.width = width
            _set_cell_text(cell, value, size=TODO_BODY_SIZE,
                           center=position != 1)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    # Fixed layout (python-docx writes the single w:tblLayout in schema order).
    table.autofit = False


def speaker_order(speaker):
    match = re.fullmatch(r"发言人\s*(\d+)", speaker.speaker.strip())
    return (0, int(match.group(1))) if match else (1, 0)


def add_section(document, title, value):
    if value in (None, "", [], {}):
        return
    document.add_heading(title, 1)
    if isinstance(value, dict):
        for key, detail in value.items():
            document.add_paragraph(f"{key}: {detail}")
    elif isinstance(value, list):
        for detail in value:
            document.add_paragraph(str(detail), "List Bullet")
    else:
        document.add_paragraph(str(value))


def render_documents(job, result, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    transcript = base_document(job, "原文记录")
    transcript.add_heading("原文记录", 1)
    if result.transcript_segments:
        for segment in result.transcript_segments:
            label = segment.speaker or ""
            if segment.start_time is not None:
                seconds = int(segment.start_time)
                label = f"[{seconds // 3600:02}:{seconds // 60 % 60:02}:{seconds % 60:02}] " + label
            if label:
                transcript.add_paragraph(label, TRANSCRIPT_LABEL_STYLE)
            transcript.add_paragraph(segment.text)
    else:
        transcript.add_paragraph(result.transcript_text)
    title = result.additional_sections.get("笔记标题")
    summary = base_document(job, title.strip() if isinstance(title, str) and title.strip() else job["original_name"])
    for name in ("关键词", "概要"):
        add_section(summary, name, result.additional_sections.get(name))
    if result.full_summary:
        summary.add_heading("全文总结", 1)
        render_structured_summary(summary, result.full_summary)
    if result.speaker_summaries:
        summary.add_heading("分角色总结", 1)
        for speaker in sorted(result.speaker_summaries, key=speaker_order):
            summary.add_heading(speaker.speaker, 2)
            render_structured_summary(summary, speaker.summary)
    if result.todos:
        summary.add_heading("待办事项", 1)
        add_todo_table(summary, result.todos)
    for title, value in result.additional_sections.items():
        if title not in {"笔记标题", "关键词", "概要"}:
            add_section(summary, title, value)
    paths = [output_dir / (job["output_stem"] + suffix + ".docx")
             for suffix in ("_原文记录", "_智能总结")]
    staged = [p.with_suffix(".docx.part") for p in paths]
    try:
        transcript.save(staged[0])
        summary.save(staged[1])
        for source, destination in zip(staged, paths):
            source.replace(destination)
    finally:
        for path in staged:
            path.unlink(missing_ok=True)
    return paths
