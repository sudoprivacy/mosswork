"""Local DOCX -> prompt and model JSON -> HTML handoff (no API calls)."""

import asyncio
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

from .prompt_template import DEFAULT_PROMPT_TEMPLATE
from .report_renderer import main as render_report


def load_prompt_template():
    """Return the built-in report prompt template.

    The template ships as a plain constant in ``prompt_template`` so the
    report pipeline works out of the box on any machine, with no setup
    step, no key material and no external file to locate.
    """
    if not DEFAULT_PROMPT_TEMPLATE.strip():
        raise ValueError("内置报告提示词为空，无法生成会议简报。")
    return DEFAULT_PROMPT_TEMPLATE


def write_text_atomic(path: Path, text: str):
    """Keep the previous artifact intact if writing is interrupted."""
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".part", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def document_text(path: Path) -> str:
    document = Document(path)

    def blocks(parent):
        for block in parent.iter_inner_content():
            if isinstance(block, Paragraph):
                yield block.text
            elif isinstance(block, Table):
                for row in block.rows:
                    # Merged cells share an XML element; emit each only once per row.
                    seen = set()
                    cells = []
                    for cell in row.cells:
                        if cell._tc not in seen:
                            seen.add(cell._tc)
                            cells.append(" / ".join(blocks(cell)))
                    yield " | ".join(cells)

    text = "\n".join(blocks(document)).strip()
    if not text:
        raise ValueError(f"输入文档为空：{path.name}")
    return text


def prepare_report(transcript_path: Path, summary_path: Path, meeting_info: Path | None = None):
    transcript_path, summary_path = transcript_path.resolve(), summary_path.resolve()
    if transcript_path == summary_path:
        raise ValueError("原文记录和智能总结必须是两个不同的文件。")
    if transcript_path.parent != summary_path.parent:
        raise ValueError("请使用同一录音结果目录中的原文记录和智能总结。")
    for path in (transcript_path, summary_path):
        if path.suffix.lower() != ".docx" or not path.is_file():
            raise ValueError(f"需要已生成的 DOCX 文件：{path.name}")
    stem = transcript_path.stem.removesuffix("_原文记录")
    if summary_path.stem != stem + "_智能总结":
        raise ValueError("原文记录与智能总结文件名不匹配，请勿混用不同录音的文档。")
    template = load_prompt_template()
    values = {
        "transcript": document_text(transcript_path),
        "summary": document_text(summary_path),
        "meeting_info": meeting_info.read_text(encoding="utf-8-sig") if meeting_info else "未提供额外会议信息。",
    }
    # One pass: placeholders appearing inside the source documents remain source text.
    prompt = re.sub(r"\{\{(transcript|summary|meeting_info)\}\}", lambda match: values[match[1]], template)
    # The assembled prompt never touches the disk. It goes to stdout so the
    # host model can produce the structured result and pipe it straight into
    # the renderer; only the metadata below goes to stderr.
    print(prompt)
    return {
        "status": "report_pending",
        "output_dir": str(transcript_path.parent),
        "next_step": "宿主模型按标准输出中的提示词产出结构化结果，经标准输入管道传给 --render-report，HTML 直接写入 output_dir。中间过程不产生任何交付文件。",
    }


def save_report(report_path: Path, output_dir: Path | None = None):
    """Render the host model's report into a local HTML file.

    The model output arrives as a single JSON object. When ``report_path`` is
    ``-`` the object is read from standard input, which lets the caller pipe
    the model output straight into this command without an intermediate file
    on disk. A file path is still accepted for callers that already produced
    one.

    ``output_dir`` decides where the HTML lands. It defaults to the directory
    holding the report file; for the stdin form it is required, because there
    is no file to infer it from.
    """
    if str(report_path) == "-":
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("标准输入中没有可读取的模型产出。")
        if output_dir is None:
            raise ValueError("从标准输入渲染时必须用 --output-dir 指定 HTML 输出目录。")
        target_dir = Path(output_dir).resolve()
    else:
        report_path = report_path.resolve()
        if report_path.suffix.lower() != ".json":
            raise ValueError("--render-report 需要 .json 文件或 - 表示标准输入。")
        try:
            raw = report_path.read_text(encoding="utf-8-sig")
        except OSError:
            raise ValueError(f"无法读取报告文件：{report_path.name}") from None
        target_dir = Path(output_dir).resolve() if output_dir else report_path.parent
    try:
        report = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"报告数据不完整或格式错误（行 {exc.lineno}，列 {exc.colno}）。") from None
    required = {"meta", "summary", "decisions", "groups", "requirements", "strategies", "open_questions"}
    if not isinstance(report, dict) or set(report) != required:
        raise ValueError("请提供提示词要求的单个 JSON 对象，包含全部 7 个顶层字段；不要传入 HTML、代码围栏或 report 包装层。")
    result = asyncio.run(render_report(SimpleNamespace(params={"report": report})))
    target_dir.mkdir(parents=True, exist_ok=True)
    output = target_dir / result["filename"]
    if output.resolve().parent != target_dir.resolve():
        raise ValueError("HTML 输出文件必须位于指定的结果目录内。")
    write_text_atomic(output, result["html"])
    return {
        "status": "completed",
        "html_path": str(output),
        "filename": result["filename"],
        "task_count": result["task_count"],
        "group_count": result["group_count"],
    }
