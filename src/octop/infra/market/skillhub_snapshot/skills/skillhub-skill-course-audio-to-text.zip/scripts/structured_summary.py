"""Render summary text, consuming paired Chinese emphasis markers."""

import re

from .docx_styles import BODY_STYLE, SUMMARY_LEVEL_1_STYLE, SUMMARY_LEVEL_2_STYLE, add_top_border

LEVEL_1 = re.compile(r"^\s*[一二三四五六七八九十百]+、\s*.+$")
LEVEL_2 = re.compile(r"^\s*\d+[.．、]\s*.+$")
BODY_PREFIX = re.compile(r"^\s*[(（]\d+[)）]\s*[^：:]+[：:]")
QUOTED = re.compile(r"“[^“”]*”")


def append_summary_runs(paragraph, text, *, heading=False):
    bold = bytearray([int(heading)]) * len(text)
    removed = set()
    prefix = BODY_PREFIX.match(text)
    if prefix:
        bold[:prefix.end()] = b"\1" * prefix.end()
    # Both rules use original offsets; an emphasis range can cross the colon.
    for match in QUOTED.finditer(text):
        bold[match.start():match.end()] = b"\1" * len(match.group())
        removed.update((match.start(), match.end() - 1))
    characters, current = [], None
    for index, character in enumerate(text):
        if index in removed:
            continue
        if characters and bold[index] != current:
            paragraph.add_run("".join(characters)).bold = bool(current)
            characters = []
        characters.append(character)
        current = bold[index]
    if characters:
        paragraph.add_run("".join(characters)).bold = bool(current)


def render_structured_summary(document, text):
    for line in text.splitlines():
        if not line.strip():
            continue
        if LEVEL_1.match(line):
            paragraph = document.add_paragraph(style=SUMMARY_LEVEL_1_STYLE)
            append_summary_runs(paragraph, line, heading=True)
            add_top_border(paragraph)
        elif LEVEL_2.match(line):
            paragraph = document.add_paragraph(style=SUMMARY_LEVEL_2_STYLE)
            append_summary_runs(paragraph, line, heading=True)
        else:
            paragraph = document.add_paragraph(style=BODY_STYLE)
            append_summary_runs(paragraph, line)
