import time
from pathlib import Path
from typing import Protocol
from uuid import uuid4

from .models import NormalizedBackendResult, SubmitResult, TaskQueryResult


class BackendAdapter(Protocol):
    async def submit(self, file_path: Path, *, job_id: str) -> SubmitResult: ...
    async def query(self, task_id: str) -> TaskQueryResult: ...


class MockBackendAdapter:
    """Self-contained task IDs allow mock polling after process restart."""
    def __init__(self, processing_seconds: float = 0, failures: set[str] | None = None):
        self.processing_seconds = processing_seconds
        self.failures = failures or set()
        self.active_task_count = 0
        self.max_active_task_count = 0
        self.submitted_jobs: list[str] = []
        self._finished: set[str] = set()

    async def submit(self, file_path: Path, *, job_id: str) -> SubmitResult:
        self.active_task_count += 1
        self.max_active_task_count = max(self.max_active_task_count, self.active_task_count)
        self.submitted_jobs.append(job_id)
        outcome = "fail" if file_path.name in self.failures or job_id in self.failures else "ok"
        return SubmitResult(task_id=f"mock:{time.time() + self.processing_seconds}:{outcome}:{uuid4()}")

    async def query(self, task_id: str) -> TaskQueryResult:
        prefix, ready, outcome, _ = task_id.split(":")
        if prefix != "mock":
            raise ValueError("Not a mock task ID")
        if time.time() < float(ready):
            return TaskQueryResult(status="processing")
        if task_id not in self._finished:
            self.active_task_count = max(0, self.active_task_count - 1)
            self._finished.add(task_id)
        if outcome == "fail":
            return TaskQueryResult(status="failed", error_code="BACKEND_TASK_FAILED",
                                   error_message="Configured mock failure.")
        return TaskQueryResult(status="succeeded", result=NormalizedBackendResult(
            transcript_text="MOCK DATA — This text is simulated, not transcribed from the audio.",
            transcript_segments=[{"speaker": "示例说话人", "start_time": 0,
                                  "text": "模拟内容：本次会议讨论项目进度。"}],
            full_summary="模拟总结：讨论项目进度与下一步计划。",
            speaker_summaries=[{"speaker": "示例说话人", "summary": "模拟内容：介绍项目进展。"}],
            todos=[{"content": "模拟待办：确认下一步计划"}],
            additional_sections={"数据说明": "MOCK DATA — simulated output; not a real transcription."},
        ))
