"""Persist the API key and its non-secret recovery metadata in the skill-root .env."""
import json
import os
from pathlib import Path
import tempfile

from .models import SkillError


VARIABLE = "QINGFENG_API_KEY"
METADATA_VARIABLE = "QINGFENG_CREDENTIAL_METADATA"


class DotEnvCredentialStore:
    """A small, non-executing reader/writer for the two managed .env fields."""

    def __init__(self, path=None):
        self.path = Path(path) if path is not None else Path(__file__).resolve().parent.parent / ".env"

    @staticmethod
    def _decode_value(value):
        decoded = json.loads(value)
        if not isinstance(decoded, str):
            raise ValueError("Invalid .env string value")
        return decoded

    def load(self):
        try:
            if not self.path.exists():
                return None, {}
            text = self.path.read_text(encoding="utf-8")
            if not text.strip():
                return None, {}
            values = {}
            for line in text.splitlines():
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                name, separator, encoded = line.partition("=")
                if not separator or name not in {VARIABLE, METADATA_VARIABLE} or name in values:
                    raise ValueError("Invalid managed .env structure")
                values[name] = encoded
            if set(values) != {VARIABLE, METADATA_VARIABLE}:
                raise ValueError("Incomplete managed .env structure")
            key = self._decode_value(values[VARIABLE])
            metadata = json.loads(values[METADATA_VARIABLE])
            if (not key or any(char.isspace() or ord(char) < 32 for char in key)
                    or not isinstance(metadata, dict)):
                raise ValueError("Invalid managed credential data")
            return key, metadata
        except (OSError, UnicodeError, ValueError, TypeError):
            raise SkillError(
                "CREDENTIAL_FILE_READ_FAILED",
                "Could not read the private API-key file; run credential setup again.",
            ) from None

    def save(self, key, metadata):
        if (not isinstance(key, str) or not key
                or any(char.isspace() or ord(char) < 32 for char in key)
                or not isinstance(metadata, dict)):
            raise SkillError("AUTHENTICATION_FAILED", "Enter a nonempty API Key without whitespace.")
        content = (
            f"{VARIABLE}={json.dumps(key, ensure_ascii=False)}\n"
            f"{METADATA_VARIABLE}={json.dumps(metadata, ensure_ascii=False, separators=(',', ':'))}\n"
        )
        temporary = None
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, temporary = tempfile.mkstemp(
                prefix=".recording-transcription-credential-",
                dir=self.path.parent,
            )
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                if os.name == "posix":
                    os.fchmod(stream.fileno(), 0o600)
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            temporary = None
        except OSError:
            raise SkillError(
                "CREDENTIAL_FILE_WRITE_FAILED",
                "Could not persist the API key in the private skill credential file. The previous setting was preserved.",
            ) from None
        finally:
            if temporary is not None:
                try:
                    Path(temporary).unlink()
                except OSError:
                    pass
        return "private skill credential file"
