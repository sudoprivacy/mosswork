# Python；输入 report；输出 html、filename（String），task_count、group_count（Integer）。
import json
import re
from html import escape, unescape


async def main(args):
  raw = args.params.get("report")
  existing_html = None
  supplied_filename = ""
  for depth in range(12):
    if isinstance(raw, str):
      text = raw.lstrip("\ufeff").strip()
      fence = re.fullmatch(r"```(?:json|html)?\s*\n?(.*?)\n?```", text, re.S | re.I)
      if fence:
        text = fence.group(1).strip()
      if re.match(r"(?:<!doctype\s+html\s*>\s*)?<html\b", text, re.I):
        if not re.search(r"</html\s*>\s*$", text, re.I):
          raise ValueError("HTML 文档不完整，缺少结束标签；请检查上游输出是否被截断。")
        existing_html = text
        break
      try:
        raw = json.loads(text)
      except json.JSONDecodeError as exc:
        raise ValueError(f"report 不是合法 JSON 或完整 HTML（行 {exc.lineno}，列 {exc.colno}）；请检查输入内容是否完整。") from None
      continue
    if isinstance(raw, dict):
      if "summary" in raw or "groups" in raw:
        break
      if "html" in raw:
        if not isinstance(raw["html"], str) or not raw["html"].strip():
          raise ValueError("输入对象的 html 必须是非空字符串。")
        if isinstance(raw.get("filename"), str):
          supplied_filename = raw["filename"]
        raw = raw["html"]
        continue
      envelopes = [key for key in ("report", "output", "data") if key in raw]
      if len(envelopes) == 1:
        raw = raw[envelopes[0]]
        continue
      if len(envelopes) > 1:
        raise ValueError("输入包含多个候选结果字段，请将需要处理的单个字段绑定到 report。")
    break
  else:
    raise ValueError("输入包装或重复编码超过 12 层，请直接传入模型总结 JSON 或 html 字段。")
  if existing_html is not None:
    title_match = re.search(r"<title\b[^>]*>(.*?)</title\s*>", existing_html, re.S | re.I)
    plain_title = unescape(re.sub(r"<[^>]+>", "", title_match.group(1))).strip() if title_match else "会议待办清单"
    filename = supplied_filename.strip() or plain_title
    filename = re.sub(r"\.html?$", "", filename, flags=re.I)
    filename = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', filename).strip(' .')[:100] or '会议待办清单'
    if re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', filename, re.I):
      filename = '_' + filename
    task_count = 0
    group_count = 0
    for tag in re.findall(r"<[a-z][\w:-]*\b[^<>]*>", re.sub(r"<!--.*?-->|<style\b[^>]*>.*?</style\s*>|<script\b[^>]*>.*?</script\s*>", "", existing_html, flags=re.S | re.I), re.I):
      class_match = re.search(r'''\bclass\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))''', tag, re.I)
      if class_match:
        classes = next(item for item in class_match.groups() if item is not None).split()
        task_count += int("task" in classes)
        group_count += int("person" in classes)
    return {"html": existing_html, "filename": filename + '.html', "task_count": task_count, "group_count": group_count}

  if not isinstance(raw, dict):
    raise ValueError("report 必须是总结 JSON、包含 html 的返回对象或完整 HTML，请检查输入变量映射。")
  schema = json.loads('{"$schema": "https://json-schema.org/draft/2020-12/schema", "title": "MeetingReport", "type": "object", "properties": {"meta": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "period": {"type": "string"}, "meeting_date": {"type": "string"}, "source": {"type": "string"}, "notice": {"type": "string"}}, "required": [], "additionalProperties": false}, "summary": {"type": "object", "properties": {"headline": {"type": "string", "minLength": 1}, "detail": {"type": "string"}}, "required": ["headline"], "additionalProperties": false}, "decisions": {"type": "array", "items": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "content": {"type": "string", "minLength": 1}, "source": {"type": "string"}}, "required": ["title", "content"], "additionalProperties": false}}, "groups": {"type": "array", "items": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "source": {"type": "string"}, "tasks": {"type": "array", "items": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "status": {"type": "string", "enum": ["todo", "doing", "blocked", "done", "unknown"]}, "is_new": {"type": "boolean"}, "is_recurring": {"type": "boolean"}, "owner": {"type": "string"}, "deadline": {"type": "string"}, "key_deadline": {"type": "boolean"}, "content": {"type": "string"}, "acceptance": {"type": "string"}, "notes": {"type": "array", "items": {"type": "string"}}, "source": {"type": "string"}, "evidence": {"type": "string"}, "subtasks": {"type": "array", "items": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "status": {"type": "string", "enum": ["todo", "doing", "blocked", "done", "unknown"]}, "is_new": {"type": "boolean"}, "is_recurring": {"type": "boolean"}, "owner": {"type": "string"}, "deadline": {"type": "string"}, "key_deadline": {"type": "boolean"}, "content": {"type": "string"}, "acceptance": {"type": "string"}, "notes": {"type": "array", "items": {"type": "string"}}, "source": {"type": "string"}, "evidence": {"type": "string"}}, "required": ["title", "status"], "additionalProperties": false}}}, "required": ["title", "status"], "additionalProperties": false}}}, "required": ["title", "tasks"], "additionalProperties": false}}, "requirements": {"type": "array", "items": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "points": {"type": "array", "items": {"type": "string"}}, "source": {"type": "string"}}, "required": ["title", "points"], "additionalProperties": false}}, "strategies": {"type": "array", "items": {"type": "object", "properties": {"title": {"type": "string", "minLength": 1}, "content": {"type": "string", "minLength": 1}, "points": {"type": "array", "items": {"type": "string"}}, "principle": {"type": "string"}}, "required": ["title"], "additionalProperties": false}}, "open_questions": {"type": "array", "items": {"type": "string"}}}, "required": ["summary", "groups"], "additionalProperties": false}')
  stack = [(raw, schema, "report")]
  while stack:
    value, rule, path = stack.pop()
    kind = rule["type"]
    expected = {"object": dict, "array": list, "string": str, "boolean": bool}[kind]
    if not isinstance(value, expected):
      raise ValueError(f"{path} 类型错误，应为 {kind}，不要使用 null。")
    if kind == "object":
      if "status" in rule["properties"] and "status" not in value:
        value["status"] = "unknown"
      for required in rule.get("required", []):
        if required not in value:
          raise ValueError(f"缺少必填字段：{path}.{required}")
      for key, item in value.items():
        if key not in rule["properties"]:
          raise ValueError(f"未知字段：{path}.{key}，请遵循参数结构。")
        child_rule = rule["properties"][key]
        child_kind = child_rule["type"]
        if item is None and (key not in rule.get("required", []) or key == "status"):
          item = "unknown" if key == "status" else {"string": "", "array": [], "object": {}, "boolean": False}[child_kind]
          value[key] = item
        if child_kind == "boolean" and isinstance(item, str) and item.strip().lower() in ("true", "false"):
          item = item.strip().lower() == "true"
          value[key] = item
        if key == "status" and isinstance(item, str):
          item = {"待启动": "todo", "进行中": "doing", "受阻": "blocked", "已完成": "done", "待确认": "unknown", "待定": "unknown"}.get(item.strip(), item.strip())
          value[key] = item
        stack.append((item, child_rule, f"{path}.{key}"))
    elif kind == "array":
      for i, item in enumerate(value):
        stack.append((item, rule["items"], f"{path}[{i}]"))
    elif kind == "string":
      if len(value.strip()) < rule.get("minLength", 0):
        raise ValueError(f"{path} 不能为空。")
      if "enum" in rule and value not in rule["enum"]:
        raise ValueError(f"{path} 取值非法：允许 todo / doing / blocked / done / unknown。")
  data = {}
  stack = [(raw, data)]
  while stack:
    src, dst = stack.pop()
    entries = src.items() if isinstance(src, dict) else enumerate(src)
    for key, value in entries:
      if isinstance(value, dict):
        converted = {}
        stack.append((value, converted))
      elif isinstance(value, list):
        converted = [None] * len(value)
        stack.append((value, converted))
      elif isinstance(value, str):
        converted = escape(value.strip(), quote=True).replace("\n", "<br>")
      else:
        converted = value
      dst[key] = converted

  css = '*{margin:0;padding:0;box-sizing:border-box}body{font-family:"PingFang SC","Microsoft YaHei","Segoe UI",sans-serif;background:#f5f8ff;color:#3e4b65;font-size:15px;line-height:1.8;padding:0 14px 30px}.page{max-width:1000px;margin:auto;padding:0 30px 25px;background:linear-gradient(#fff,#f9fbff);overflow-wrap:anywhere;counter-reset:g}.head{position:relative;padding:24px 30px;margin:0 -30px 17px;background:radial-gradient(ellipse at 95% 30%,#b9caff85,transparent 35%),linear-gradient(110deg,#f8faff,#eff3ff);overflow:hidden}.eyebrow{font-size:12px;color:#5e48d1;font-weight:700;letter-spacing:2px;margin-bottom:6px}.head:after{content:"";position:absolute;right:52px;top:25px;width:68px;height:80px;border:1px solid #fff;border-radius:10px;background:linear-gradient(#7c8eff,#7c8eff) 13px 18px/40px 6px no-repeat,linear-gradient(#a3b2ff,#a3b2ff) 13px 34px/26px 5px no-repeat,linear-gradient(#b9c5ff,#b9c5ff) 13px 48px/34px 5px no-repeat,linear-gradient(#c4ceff,#c4ceff) 13px 61px/18px 4px no-repeat,#ffffffc9;box-shadow:9px 12px 22px #778eff29;transform:rotate(8deg)}h1{position:relative;z-index:1;color:#0f2050;font-size:30px;line-height:1.5;max-width:calc(100% - 125px)}.sub{font-size:13px;color:#52617d;margin-top:12px;max-width:calc(100% - 110px)}.tag{font-size:11px;color:#626d88;border:1px solid #d9defb;border-radius:4px;padding:1px 7px}.judge{display:grid;grid-template-columns:1.3fr 1fr;gap:25px;background:linear-gradient(115deg,#f0f2ff,#edf1ff);border-radius:14px;padding:22px 25px;margin-bottom:27px}.summary-main{display:flex;gap:19px;min-width:0}.summary-icon{flex:0 0 52px;height:52px;background:linear-gradient(135deg,#a8b4ff,#5265ff);border-radius:19px;color:#fff;display:flex;align-items:center;justify-content:center;font-size:29px}.summary-copy{min-width:0}.judge .jt{font-size:19px;color:#17265c;font-weight:700;margin-bottom:7px}.judge p{font-size:16px;color:#435271;line-height:1.95}.summary-side{border-left:1px solid #d8def5;padding-left:25px}.side-title{font-size:15px;font-weight:700;color:#304277;margin-bottom:9px}.judge .sub2{font-size:14px;line-height:2;color:#4e5d7b}.judge:not(:has(.summary-side)){grid-template-columns:1fr}h2{display:flex;align-items:center;gap:9px;font-size:19px;color:#182956;margin:28px 0 16px;break-after:avoid}h2:after{content:"";height:1px;background:#e6ecf7;flex:1;order:1;margin-left:8px}h2 .no{display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#b3beff,#687bff);color:#fff;border-radius:50%;width:23px;height:23px;flex:0 0 23px;font-size:13px;font-weight:500}.section-count{order:2;font-size:13px;color:#5363c9;font-weight:500;white-space:nowrap;margin-left:6px}ol.rules{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px;list-style:none;counter-reset:d}ol.rules li{position:relative;counter-increment:d;border:1px solid #edf1fb;border-radius:12px;background:#fff;box-shadow:0 5px 20px #5d7ca608;padding:17px 19px 17px 78px;font-size:14px;line-height:1.9}ol.rules li:before{content:counter(d,decimal-leading-zero);position:absolute;left:18px;top:17px;width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:#e9f4ff;color:#1469d4;font-size:23px;font-weight:650}ol.rules li:nth-child(even):before{background:#f0ebff;color:#6b46d6}ol.rules b{display:block;color:#263562;font-size:16px;margin-bottom:6px}.decision-content{color:#53627e;font-size:14px}.src{font-size:12px;color:#66758f;margin-top:9px}.ledger{display:grid;grid-template-columns:repeat(5,minmax(0,1fr)) 1.3fr;gap:11px}.ledger>.stat{position:relative;border:1px solid #edf1f9;border-radius:10px;min-height:92px;padding:16px 8px 12px 51px;box-shadow:0 4px 18px #778ca609;line-height:1.5}.stat-icon{position:absolute;left:13px;top:16px;display:flex;align-items:center;justify-content:center;width:29px;height:29px;border-radius:50%;font-size:19px;font-style:normal;background:#ffffffa0}.stat-label{display:block;font-size:14px;color:#52617d;white-space:nowrap}.stat-value{display:block;font-size:29px;font-weight:650;margin-top:4px}.p-todo{background:#f8fafc;color:#53627d}.p-doing{background:#f2faff;color:#196bd0}.p-fail{background:#fff7f7;color:#ce495c}.p-done{background:#f2fcf9;color:#0e8073}.p-unknown{background:#fffbf2;color:#99601d}.ledger>.stat:last-child{background:linear-gradient(125deg,#5265df,#465bd1);color:#fff;border-color:#8595ff}.stat:last-child .stat-label{color:#f5f6ff}.stat:last-child .stat-icon{background:#ffffff15}.ledger-note{font-size:12px;color:#66758f;margin:10px 1px 18px}.person{counter-increment:g;border:1px solid #e2eaf7;border-radius:13px;padding:0 10px 10px;margin:20px 0;background:linear-gradient(120deg,#f8fbff,#fff)}.phead{position:relative;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:2px 14px;align-items:center;padding:15px 6px 17px 55px}.phead:before{content:counter(g);position:absolute;left:5px;top:16px;width:33px;height:33px;background:linear-gradient(140deg,#7461de,#465edb);color:#fff;border:2px solid #ffffffbb;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:19px}.pname{grid-column:1;grid-row:1;font-size:17px;font-weight:700;color:#223260}.pline{grid-column:1;grid-row:2;font-size:12px;color:#66758f}.pcount{grid-column:2;grid-row:1/span 2;background:#edf3ff;color:#4d5fbd;border-radius:20px;font-size:13px;padding:5px 14px;white-space:nowrap}.ptasks{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.task{position:relative;padding:13px 14px 11px;background:#fff;border:1px solid #e6ecf6;border-radius:9px;min-width:0}.task .n{position:absolute;left:14px;top:14px;background:#edf1f8;color:#596b89;font-size:13px;font-weight:650;padding:1px 7px;border-radius:4px;min-width:34px;text-align:center}.task .tt{padding-left:46px;color:#22345e;font-weight:700;font-size:16px;line-height:1.9;min-height:27px;margin-bottom:9px}.flag{display:inline-block;white-space:nowrap;font-weight:500;font-size:12px;line-height:1.6;border:1px solid;border-radius:4px;padding:1px 6px;margin-left:5px}.f-todo{background:#f5f8fc;border-color:#dbe3ef;color:#586d89}.f-doing{background:#eff8ff;border-color:#b8dfff;color:#136dc4}.f-fail{background:#fff4f4;border-color:#ffcdd1;color:#ba3e50}.f-done{background:#edfbf7;border-color:#b7eadd;color:#0a7e70}.f-unknown{background:#fff9ef;border-color:#f8dba8;color:#9a6019}.f-new{background:#f7f3ff;border-color:#e1d5ff;color:#7252bc}.task .m{display:grid;grid-template-columns:72px minmax(0,1fr);gap:6px;font-size:14px;line-height:1.9;color:#4d5c77;margin:5px 0}.task .m>b{display:flex;gap:7px;align-items:flex-start;font-size:13px;color:#60718f;font-weight:400;white-space:nowrap;padding-top:1px}.field-icon{width:15px;height:15px;flex:0 0 15px;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round;margin-top:2px}.field-value{min-width:0}.task .m.node{background:#f2f5fa;color:#526987;padding:5px 7px;border-radius:4px;font-weight:600;margin:7px 0}.task .m.node b{color:inherit}.task:has(>.body>.tt>.f-doing)>.body>.m.node{background:#eef8ff;color:#1767c5}.task:has(>.body>.tt>.f-fail)>.body>.m.node{background:#fff0f1;color:#bd3c51}.task:has(>.body>.tt>.f-done)>.body>.m.node{background:#edfbf7;color:#087b6b}.task:has(>.body>.tt>.f-unknown)>.body>.m.node{background:#fff8ed;color:#8b570f}.task .m.warn{color:#8b653b}.subtask{border-left:2px solid #dce4ff;background:#f9fbff;padding:11px 12px;margin:12px 0 6px}.subtask .tt{padding:0;font-size:14px}.task:has(.subtask){grid-column:1/-1}.task-evidence{border-top:1px dashed #e7edf7;margin-top:10px;padding-top:7px;font-size:12px;color:#67758d}.task-evidence summary{cursor:pointer}.task-evidence blockquote{white-space:pre-wrap;background:#f7f9ff;border-left:2px solid #d9e1fa;padding:10px;margin-top:8px;font-size:13px}.quote{background:#f5f8ff;border-left:3px solid #c4d0ff;border-radius:0 9px 9px 0;padding:15px 19px;margin:12px 0 5px;font-size:14px;color:#53647f;line-height:2}.quote b{color:#344e86;font-size:15px}.quote+.src{margin:0 0 16px 4px}.table-wrap{overflow:hidden;border:1px solid #e4ebf8;border-radius:10px}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:14px}th{background:#f1f5ff;color:#5068a1;font-size:12px;text-align:left;padding:12px 15px}th:first-child{width:18%}th:last-child{width:22%}td{border-top:1px solid #edf1f8;padding:13px 15px;vertical-align:top;color:#536580}.node-table td:first-child{color:#4264b3;font-weight:600}.urgent td{background:#fff4f5}.biz{background:#f6f9ff;border:1px solid #e4ecfa;border-radius:11px;padding:17px 21px;margin:13px 0;color:#526583;font-size:14px;line-height:2}.biz .bt{color:#3e5c91;font-weight:700;font-size:15px;margin-bottom:7px}.biz ul{padding-left:18px}.biz li{margin:5px 0}.biz .flow{font-size:13px;color:#566c91;border-top:1px solid #e0e9f8;margin-top:11px;padding-top:10px}.chg{background:#fffbf3;border:1px solid #eee4cb;border-radius:9px;padding:17px 20px;margin:25px 0 10px;color:#82612f;font-size:13px;line-height:2}.chg .ct{color:#80561d;font-weight:700;margin-bottom:7px}.chg ul{padding-left:18px}.chg li{margin:5px 0}.empty{padding:14px;border:1px dashed #dce6f8;border-radius:8px;background:#f8faff;color:#61718c;font-size:14px}.foot{display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;border-top:1px solid #e7edf8;margin-top:27px;padding-top:16px;font-size:11px;color:#61718c}@media(max-width:850px){.judge{grid-template-columns:1fr}.summary-side{border-left:0;border-top:1px solid #d8def5;padding:16px 0 0}.ledger{grid-template-columns:repeat(3,minmax(0,1fr))}.ptasks{grid-template-columns:1fr}}@media(max-width:520px){body{padding:0}.page{padding:0 16px 22px}.head{padding:22px 17px;margin:0 -16px 15px}.head:after{display:none}h1{font-size:23px;max-width:none;line-height:1.6}.sub{max-width:none;font-size:12px}.judge{padding:19px 17px;gap:16px}.summary-main{gap:12px}.summary-icon{flex-basis:37px;height:37px;border-radius:13px;font-size:22px}.judge .jt{font-size:18px}.section-count{font-size:11px}h2{font-size:17px;gap:7px}.ledger{gap:7px}.ledger>.stat{padding:12px 6px 9px 39px;min-height:75px}.stat-icon{left:8px;top:13px;width:23px;height:23px;font-size:15px}.stat-label{font-size:11px}.stat-value{font-size:23px}.phead{padding-left:43px}.phead:before{width:28px;height:28px;font-size:16px;left:1px}.pname{font-size:15px}.pline{font-size:11px}.pcount{font-size:11px;padding:4px 9px}ol.rules{grid-template-columns:1fr}.task .m{grid-template-columns:63px minmax(0,1fr)}.task .m>b{gap:5px}.table-wrap{overflow-x:auto}.node-table{min-width:450px}}@media print{@page{size:A4;margin:13mm}body{padding:0;background:#fff}.page{padding:0}.head{margin:0;padding:15px 0}.head:after{display:none}h1{max-width:none;font-size:24px}.judge,.task{break-inside:avoid}.ledger{grid-template-columns:repeat(6,minmax(0,1fr))}.ledger>.stat{padding-left:10px;min-height:65px}.stat-icon,.task-evidence{display:none}.ptasks{grid-template-columns:repeat(2,minmax(0,1fr))}.phead,h2{break-after:avoid}.table-wrap{overflow:visible}.node-table{min-width:0}}h2 .no{font-size:0}h2 .no:before{content:"◎";font-size:19px}h2:nth-of-type(2) .no:before{content:"▸"}'
  meta = data.get("meta", {})
  title = meta.get("title") or "会议待办清单"
  plain_title = raw.get("meta", {}).get("title", "").strip() or "会议待办清单"
  head_title = escape(plain_title, quote=True)
  summary = data["summary"]
  groups = [group for group in data["groups"] if group["tasks"]]
  counts = {"todo": 0, "doing": 0, "blocked": 0, "done": 0, "unknown": 0}
  labels = {"todo": "待启动", "doing": "进行中", "blocked": "受阻", "done": "已完成", "unknown": "待确认"}
  flags = {"todo": "f-todo", "doing": "f-doing", "blocked": "f-fail", "done": "f-done", "unknown": "f-todo"}
  pills = {"todo": "p-todo", "doing": "p-doing", "blocked": "p-fail", "done": "p-done", "unknown": "p-todo"}
  task_count = 0
  subtask_count = 0
  new_count = 0
  recurring_count = 0
  milestones = []
  for gi, group in enumerate(groups, 1):
    for ti, task in enumerate(group["tasks"], 1):
      task_count += 1
      counts[task["status"]] += 1
      new_count += int(task.get("is_new", False))
      recurring_count += int(task.get("is_recurring", False))
      subtask_count += len(task.get("subtasks", []))
      for si, item in enumerate([task] + task.get("subtasks", [])):
        if item.get("key_deadline"):
          if not item.get("deadline"):
            raise ValueError(f"事项 {gi} 任务 {ti} 的关键节点缺少 deadline。")
          ref = f"{gi}.{ti}" + (f".{si}" if si else "")
          milestones.append((item, ref, group["title"]))

  out = ['<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">',
     '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
     f'<title>{head_title}</title><style>{css}</style></head><body><main class="page">',
     '<header class="head"><div class="eyebrow">MEETING BRIEF</div>']
  if meta.get("notice"):
    out.append(f'<span class="tag">{meta["notice"]}</span>')
  out.append(f'<h1>{title}</h1>')
  subtitle = []
  for field, label in [("period", "周期"), ("meeting_date", "会议日期"), ("source", "依据")]:
    if meta.get(field):
      subtitle.append(f'{label}：{meta[field]}')
  if subtitle:
    out.append('<div class="sub">' + ' ｜ '.join(subtitle) + '</div>')
  out.append('</header><section class="judge"><div class="summary-main"><div class="summary-icon" aria-hidden="true">▤</div><div class="summary-copy"><div class="jt">核心总结</div>')
  out.append(f'<p>{summary.get("headline") or "未提炼出明确结论"}</p>')
  out.append('</div></div>')
  if summary.get("detail"):
    out.append(f'<aside class="summary-side"><div class="side-title">背景与关注</div><p class="sub2">{summary["detail"]}</p></aside>')
  out.append(f'</section><h2><span class="no">一</span>会议已确认的关键决策<span class="section-count">共 {len(data.get("decisions", []))} 项关键决策</span></h2>')
  if data.get("decisions"):
    out.append('<ol class="rules">')
    for decision in data["decisions"]:
      out.append(f'<li><b>{decision["title"]}</b><div class="decision-content">{decision["content"]}</div>')
      if decision.get("source"):
        out.append(f'<div class="src">依据：{decision["source"]}</div>')
      out.append('</li>')
    out.append('</ol>')
  else:
    out.append('<p class="empty">未提及已确认的关键决策。</p>')
  out.append(f'<h2><span class="no">二</span>会议待办 · 按事项拆解<span class="section-count">共 {task_count} 项待办</span></h2><div class="ledger">')
  stat_icons = {"todo": "◷", "doing": "▷", "blocked": "!", "done": "✓", "unknown": "?"}
  for status, count in counts.items():
    stat_class = "p-unknown" if status == "unknown" else pills[status]
    out.append(f'<span class="stat {stat_class}"><i class="stat-icon" aria-hidden="true">{stat_icons[status]}</i><span class="stat-label">{labels[status]}</span><strong class="stat-value">{count}</strong></span>')
  out.append(f'<span class="stat p-doing"><i class="stat-icon" aria-hidden="true">≋</i><span class="stat-label">全部待办</span><strong class="stat-value">{task_count}</strong></span></div>')
  out.append(f'<div class="ledger-note">按事项归并为 {len(groups)} 组，共 {task_count} 条主任务，另含 {subtask_count} 条子任务。状态统计仅计主任务；新提 {new_count} 项、周期任务 {recurring_count} 项为附加属性，不重复计入合计。</div>')
  if not groups:
    out.append('<p class="empty">未提炼出明确可执行的待办。</p>')
  for gi, group in enumerate(groups, 1):
    out.append(f'<section class="person"><div class="phead"><span class="pname">事项 {gi} · {group["title"]}</span>')
    if group.get("source"):
      out.append(f'<span class="pline">来源：{group["source"]}</span>')
    out.append(f'<span class="pcount">{len(group["tasks"])} 项</span></div><div class="ptasks">')
    for ti, task in enumerate(group["tasks"], 1):
      out.append(f'<div class="task" id="task-{gi}-{ti}"><div class="n">{gi}.{ti}</div><div class="body">')
      for si, item in enumerate([task] + task.get("subtasks", [])):
        if si:
          out.append(f'<div class="subtask" id="task-{gi}-{ti}-{si}">')
        prefix = f'{ti}.{si} ' if si else ''
        status = item["status"]
        flag_class = "f-unknown" if status == "unknown" else flags[status]
        out.append(f'<div class="tt">{prefix}{item["title"]}<span class="flag {flag_class}">{labels[status]}</span>')
        if item.get("is_new"):
          out.append('<span class="flag f-new">本次新提</span>')
        if item.get("is_recurring"):
          out.append('<span class="flag f-new">周期任务</span>')
        out.append('</div>')
        icon_paths = {"content": "M3 3h10v12H3zM6 1h4v4H6zM6 8h4M6 11h3", "owner": "M11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0M2 15v-2a6 5 0 0 1 12 0v2z", "acceptance": "M3 2h10v12H3zM6 6l2 2 4-4M5 11h5", "deadline": "M2 4h12v10H2zM5 2v4M11 2v4M2 7h12M5 10h2", "notes": "M4 2h8v12l-4-3-4 3z", "source": "M4 2h8v12l-4-3-4 3z"}
        for field, label in [("content", "内容"), ("owner", "负责人"), ("acceptance", "验收"), ("deadline", "节点")]:
          value = item.get(field, "")
          if field in ("owner", "deadline"):
            value = value or "待确认"
          if value:
            css_class = 'm node' if field == 'deadline' else 'm'
            out.append(f'<div class="{css_class}"><b><svg class="field-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="{icon_paths[field]}"/></svg>{label}</b><span class="field-value">{value}</span></div>')
        for note in item.get("notes", []):
          if note:
            out.append(f'<div class="m warn"><b><svg class="field-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="{icon_paths["notes"]}"/></svg>注意</b><span class="field-value">{note}</span></div>')
        if item.get("source"):
          out.append(f'<div class="m"><b><svg class="field-icon" viewBox="0 0 16 16" aria-hidden="true"><path d="{icon_paths["source"]}"/></svg>来源</b><span class="field-value">{item["source"]}</span></div>')
        if item.get("evidence"):
          out.append(f'<details class="task-evidence"><summary>查看转写依据</summary><blockquote>{item["evidence"]}</blockquote></details>')
        if si:
          out.append('</div>')
      out.append('</div></div>')
    out.append('</div></section>')
  out.append('<h2><span class="no">三</span>工作要求与方法</h2>')
  if not data.get("requirements"):
    out.append('<p class="empty">未提及明确的工作要求与方法。</p>')
  for i, requirement in enumerate(data.get("requirements", []), 1):
    out.append(f'<div class="quote"><b>{i}. {requirement["title"]}</b>')
    for point in requirement["points"]:
      out.append(f'<br>{point}')
    out.append('</div>')
    if requirement.get("source"):
      out.append(f'<div class="src">— {requirement["source"]}</div>')
  out.append('<h2><span class="no">四</span>关键时间与节点</h2>')
  if milestones:
    out.append('<div class="table-wrap"><table class="node-table"><thead><tr><th>时间</th><th>事项 / 任务</th><th>负责人</th></tr></thead><tbody>')
    for item, ref, group_title in milestones:
      row_class = ' class="urgent"' if item['status'] == 'blocked' else ''
      out.append(f'<tr{row_class}><td>{item["deadline"]}</td><td>{group_title}<br>{ref} · {item["title"]}</td><td>{item.get("owner") or "待确认"}</td></tr>')
    out.append('</tbody></table></div>')
  else:
    out.append('<p class="empty">未提及明确的关键时间节点。</p>')
  out.append('<h2><span class="no">五</span>执行策略</h2>')
  if not data.get("strategies"):
    out.append('<p class="empty">未提及明确的执行策略。</p>')
  for strategy in data.get("strategies", []):
    out.append(f'<div class="biz"><div class="bt">{strategy["title"]}</div>')
    if strategy.get("content"):
      out.append(f'<div>{strategy["content"]}</div>')
    if strategy.get("points"):
      out.append('<ul>')
      for point in strategy["points"]:
        out.append(f'<li>{point}</li>')
      out.append('</ul>')
    if strategy.get("principle"):
      out.append(f'<div class="flow">原则：{strategy["principle"]}</div>')
    out.append('</div>')
  if data.get("open_questions"):
    out.append('<section class="chg"><div class="ct">待确认事项</div><ul>')
    for question in data["open_questions"]:
      out.append(f'<li>{question}</li>')
    out.append('</ul></section>')
  out.append(f'<footer class="foot"><span>{title} · 根据转写内容提炼</span><span>共 {len(groups)} 个事项 / {task_count} 条主任务</span></footer></main></body></html>')
  safe_title = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', plain_title).strip(' .')[:60] or '会议待办清单'
  if re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', safe_title, re.I):
    safe_title = '_' + safe_title
  date = raw.get('meta', {}).get('meeting_date', '')
  suffix = '_' + date if re.fullmatch(r'\d{4}-\d{2}-\d{2}', date) else ''
  return {"html": ''.join(out), "filename": safe_title + suffix + '.html', "task_count": task_count, "group_count": len(groups)}
