import json
import math
from pathlib import Path

import av

from .models import Settings, SkillError, ValidationResult

FORMATS = {
    ".mp3": {"mp3"}, ".wav": {"wav"}, ".aac": {"aac"},
    ".opus": {"ogg"}, ".ogg": {"ogg"}, ".flac": {"flac"},
    ".amr": {"amr"}, ".wma": {"asf"},
    ".mp4": {"mov", "mp4"}, ".m4a": {"mov", "mp4"},
    ".m4r": {"mov", "mp4"},
}

# Multipart types the intermediary accepts, keyed by the container name PyAV reports.
CONTAINER_MIME_TYPES = {
    "mp3": "audio/mpeg", "wav": "audio/wav", "aac": "audio/aac", "flac": "audio/flac",
    "ogg": "audio/ogg", "amr": "audio/amr", "asf": "audio/x-ms-wma",
    "mov": "audio/mp4", "mp4": "audio/mp4",
}
FALLBACK_MIME_TYPE = "application/octet-stream"


def upload_mime_type(validation_json: str | None) -> str:
    """Multipart content type for the container recorded during media validation.

    The value is derived from PyAV's detection result, never from the file name, so a
    renamed file cannot claim an accepted type. Unknown containers keep the generic
    fallback rather than guessing a type the backend would have to reject.
    """
    try:
        detected = json.loads(validation_json or "{}").get("detected_container") or ""
    except (AttributeError, ValueError):
        detected = ""
    if not isinstance(detected, str):
        return FALLBACK_MIME_TYPE
    for name in detected.split(","):
        mime = CONTAINER_MIME_TYPES.get(name.strip().lower())
        if mime:
            return mime
    return FALLBACK_MIME_TYPE


def validate_audio_file(path: Path, settings: Settings) -> ValidationResult:
    if not path.is_file():
        raise SkillError("FILE_NOT_FOUND", "Input is not a regular file.")
    extension = path.suffix.lower()
    if extension not in FORMATS:
        raise SkillError("UNSUPPORTED_EXTENSION", "Unsupported media extension.")
    size = path.stat().st_size
    if size > settings.max_file_size_bytes:
        raise SkillError("FILE_TOO_LARGE", "File exceeds the size limit.")
    try:
        with av.open(str(path)) as container:
            streams = list(container.streams.audio)
            if not streams:
                raise SkillError("NO_AUDIO_STREAM", "Media has no audio stream.")
            names = set(container.format.name.split(","))
            codecs = [s.codec_context.name for s in streams]
            if not names.intersection(FORMATS[extension]) or (
                extension == ".opus" and "opus" not in codecs
            ) or (extension == ".wma" and not any(c.startswith("wma") for c in codecs)):
                raise SkillError("FORMAT_MISMATCH", "Extension does not match the media format.")
            durations = [float(s.duration * s.time_base) for s in streams
                         if s.duration is not None and s.time_base is not None]
            durations = [d for d in durations if math.isfinite(d) and d >= 0]
            duration = max(durations) if durations else None
            if duration is None and container.duration is not None:
                candidate = float(container.duration / av.time_base)
                if math.isfinite(candidate) and candidate >= 0:
                    duration = candidate
            if duration is not None and duration > settings.max_duration_seconds:
                raise SkillError("AUDIO_TOO_LONG", "Audio exceeds the duration limit.")
            if "wav" in names:
                # A header alone advertises an audio stream. One packet probe is
                # sufficient for WAV; do not decode the recording to validate it.
                packet = next(container.demux(streams[0]), None)
                if packet is None or packet.size == 0:
                    raise SkillError("NO_AUDIO_FRAMES", "WAV contains no audio packets.")
            return ValidationResult(size_bytes=size, extension=extension,
                                    detected_container=container.format.name,
                                    detected_codecs=codecs, duration_seconds=duration)
    except SkillError:
        raise
    except Exception as exc:
        raise SkillError("MEDIA_PARSE_FAILED", "Media could not be parsed.") from exc
