import tempfile
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator
from urllib.parse import urlsplit


def skill_install_root() -> Path:
    """Return the directory that holds this skill package."""
    return Path(__file__).resolve().parent.parent


def validate_work_dir(path: Path) -> Path:
    """Reject result directories that must never receive final artifacts.

    The skill must not scatter deliverables into system temp storage, the
    user's home directory, or the skill package itself. Callers point
    ``--work-dir`` at a directory inside the current workspace; anything else
    is rejected before a single byte is written.

    A relative path resolves against the current working directory, which is
    the skill package root during a normal run. That is why the default
    ``outputs`` directory is refused here: it would write state and
    documents straight into the installed package.
    """
    resolved = Path(path).expanduser().resolve()
    package = skill_install_root()
    if resolved == package or package in resolved.parents:
        raise SkillError(
            "WORK_DIR_FORBIDDEN",
            "结果目录不能位于 Skill 安装目录内。请用 --work-dir 指定当前工作区内的目录，例如 <当前工作区>/录音转文字结果。")
    temp_root = Path(tempfile.gettempdir()).resolve()
    try:
        inside_cwd = resolved == Path.cwd().resolve() or Path.cwd().resolve() in resolved.parents
    except OSError:
        inside_cwd = False
    if not inside_cwd and (resolved == temp_root or temp_root in resolved.parents):
        raise SkillError(
            "WORK_DIR_FORBIDDEN",
            "结果目录不能位于系统临时目录。请用 --work-dir 指定当前工作区内的目录。")
    try:
        home = Path.home().resolve()
    except (OSError, RuntimeError):
        home = None
    if home is not None and resolved == home:
        raise SkillError(
            "WORK_DIR_FORBIDDEN",
            "结果目录不能直接使用用户主目录。请用 --work-dir 指定当前工作区内的子目录。")
    return resolved


class Settings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    backend_mode: Literal["mock", "real"] = "mock"
    api_base_url: str = "https://www.qingfengyq.com/api/v1"
    website_url: str = "https://www.qingfengyq.com/"
    authorization_page_url: str | None = "https://www.qingfengyq.com/oauth/authorize"
    # Separate OAuth base supports local development without weakening business API validation.
    oauth_api_base_url: str | None = None
    login_timeout_seconds: float = Field(default=600, gt=0, allow_inf_nan=False)
    oauth_exchange_timeout_seconds: float = Field(default=10, gt=0, le=30, allow_inf_nan=False)
    login_ack_grace_seconds: float = Field(default=5, ge=0, le=60, allow_inf_nan=False)
    skill_id: str = "skill-record-file-version"
    tool_id: str = "xiaoban_recording_file_skill"
    # Codes confirmed during integration (IC-02 / IC-05).
    # The balance rejection is a default because losing it has a real cost: the
    # generic 4xx branch treats the file as a terminal rejection, so a user who
    # recharges cannot continue from the saved progress and must re-upload.
    quota_error_codes: set[str] = Field(
        default_factory=lambda: {"PLATFORM_BILLING_BALANCE_NOT_ENOUGH"})
    authentication_error_codes: set[str] = Field(default_factory=set)
    retryable_import_codes: set[str] = Field(default_factory=set)
    timestamp_unit: Literal["seconds", "milliseconds"] | None = None
    import_attempt_limit: int = Field(default=3, ge=1, le=3)
    http_write_timeout: float = Field(default=300, gt=0)
    worker_count: int = Field(default=5, ge=1, le=5)
    max_file_size_bytes: int = Field(default=200 * 1024 * 1024, gt=0, le=200 * 1024 * 1024)
    max_duration_seconds: float = Field(default=10800, gt=0, le=10800)
    poll_interval_seconds: float = Field(default=5, ge=0)
    max_job_wall_time_seconds: float = Field(default=86400, gt=0)
    poll_retries: int = Field(default=4, ge=0)
    retry_base_seconds: float = Field(default=1, ge=0)
    http_connect_timeout: float = Field(default=10, gt=0)
    http_read_timeout: float = Field(default=60, gt=0)
    input_prepare_timeout_seconds: float = Field(default=300, gt=0, allow_inf_nan=False)
    max_redirects: int = Field(default=5, ge=0)
    strict_remote_urls: bool = False
    work_dir: Path = Path("outputs")

    @field_validator("api_base_url")
    @classmethod
    def validate_api_base(cls, value):
        url = urlsplit(value)
        if (url.scheme != "https" or not url.hostname or url.username or url.password
                or url.query or url.fragment or url.path.rstrip("/") != "/api/v1"):
            raise ValueError("API base must be an HTTPS URL ending in /api/v1 without credentials or query parameters")
        return value.rstrip("/")

    @field_validator("website_url")
    @classmethod
    def validate_browser_url(cls, value):
        if value is None:
            return value
        url = urlsplit(value)
        if url.scheme != "https" or not url.hostname or url.username or url.password or url.fragment:
            raise ValueError("Browser URLs must use HTTPS without credentials or fragments")
        return value

    @field_validator("authorization_page_url", "oauth_api_base_url")
    @classmethod
    def validate_oauth_url(cls, value, info):
        if value is None:
            return value
        url = urlsplit(value)
        local_http = url.scheme == "http" and url.hostname in {"127.0.0.1", "localhost"}
        if (not url.hostname or url.username or url.password or url.fragment
                or (url.scheme != "https" and not local_http)):
            raise ValueError("OAuth URLs require HTTPS, except HTTP loopback development hosts")
        if info.field_name == "oauth_api_base_url":
            if url.query or url.path.rstrip("/") != "/api/v1":
                raise ValueError("OAuth API base must end in /api/v1 without query parameters")
            return value.rstrip("/")
        return value

    @model_validator(mode="after")
    def distinct_codes(self):
        groups = [self.quota_error_codes, self.authentication_error_codes, self.retryable_import_codes]
        if any(groups[i] & groups[j] for i in range(3) for j in range(i + 1, 3)):
            raise ValueError("Integration error-code mappings must not overlap")
        return self


class AudioInput(BaseModel):
    source_type: Literal["local", "url", "attachment"] = "local"
    value: str
    display_name: str | None = None


class ResolvedInput(BaseModel):
    original_source: str
    original_name: str
    local_path: Path
    is_temporary: bool = False


class ValidationResult(BaseModel):
    size_bytes: int
    extension: str
    detected_container: str
    detected_codecs: list[str]
    duration_seconds: float | None = None
    has_audio: bool = True


class TranscriptSegment(BaseModel):
    speaker: str | None = None
    start_time: float | None = Field(default=None, ge=0)
    end_time: float | None = Field(default=None, ge=0)
    text: str


class SpeakerSummary(BaseModel):
    speaker: str
    summary: str


class TodoItem(BaseModel):
    content: str
    owner: str | None = None
    deadline: str | None = None


class NormalizedBackendResult(BaseModel):
    transcript_text: str
    transcript_segments: list[TranscriptSegment] = Field(default_factory=list)
    full_summary: str | None = None
    speaker_summaries: list[SpeakerSummary] = Field(default_factory=list)
    todos: list[TodoItem] = Field(default_factory=list)
    additional_sections: dict[str, object] = Field(default_factory=dict)
    source_metadata: dict[str, object] = Field(default_factory=dict)


class SubmitResult(BaseModel):
    task_id: str = Field(min_length=1)


class TaskQueryResult(BaseModel):
    status: Literal["processing", "succeeded", "failed"]
    result: NormalizedBackendResult | None = None
    error_code: str | None = None
    error_message: str | None = None


class SkillError(Exception):
    def __init__(self, code: str, message: str, *, stage: str | None = None,
                 retryable: bool = False, backend_code: str | None = None, http_status: int | None = None):
        super().__init__(message)
        self.code = code
        self.stage = stage
        self.retryable = retryable
        self.backend_code = backend_code
        self.http_status = http_status
