"""Only the Qingfeng intermediary is called. No upstream/internal endpoints."""
import asyncio
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

import httpx

from .media import upload_mime_type
from .http_logging import sensitive_http
from .models import NormalizedBackendResult, SkillError, SubmitResult, TaskQueryResult, TodoItem
from .repository import now

UPLOAD = "/third-party/tools/storage/file-upload"
ISSUE = "/third-party/skill-auth/issue"
IMPORT = "/third-party/skill-tools/office/xiaoban-recording-file"
QUERY = "/third-party/tools/communication/xiaoban-recording-file"


def valid_id(value):
    # Reject floats rather than silently lose precision in large numeric IDs.
    if isinstance(value, bool) or not isinstance(value, (str, int)) or not str(value).strip():
        raise ValueError("Missing identifier")
    return str(value)


def expiry(value):
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Expiry must contain a timezone")
    return parsed


class QingfengClient:
    def __init__(self, settings, credentials, transport=None):
        self.settings = settings
        self.credentials = credentials
        self._transport = transport
        self.client = None
        self.binding = None
        self.compatible_bindings = set()
        self._key = None
        self.authentication_failed = False
        self._secrets = set()

    async def __aenter__(self):
        self._key = self.credentials.get_api_key()
        self._secrets.add(self._key)
        self.binding = self.credentials.binding(self._key)
        self.compatible_bindings = self.credentials.compatible_bindings(self._key)
        timeout = httpx.Timeout(self.settings.http_read_timeout, connect=self.settings.http_connect_timeout,
                               write=self.settings.http_write_timeout)
        self.client = httpx.AsyncClient(timeout=timeout, transport=self._transport, follow_redirects=False,
                                       trust_env=False)
        return self

    async def __aexit__(self, *args):
        if self.client:
            await self.client.aclose()
        self._key = None
        self._secrets.clear()

    def safe_text(self, value):
        text = str(value)
        for secret in self._secrets:
            text = text.replace(secret, "[redacted]")
        return text

    def safe_detail(self, payload):
        """Backend rejection detail, redacted and bounded, for diagnosable failures."""
        candidate = None
        if isinstance(payload, dict):
            for key in ("detail", "message"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    candidate = value
                    break
        if candidate is None:
            return None
        text = re.sub(r"(?i)Bearer\s+\S+|sa_[A-Za-z0-9_-]+", "[redacted]", self.safe_text(candidate))
        text = re.sub(r"(https?://[^\s?]+)\?\S+", r"\1?[redacted]", text)
        return " ".join(text.split())[:300] or None

    def redact_result(self, value):
        if isinstance(value, str):
            return self.safe_text(value)
        if isinstance(value, dict):
            return {k: self.redact_result(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self.redact_result(v) for v in value]
        return value

    @sensitive_http
    async def request(self, path, *, stage, json=None, files=None, data=None, auth_code=None):
        if self.authentication_failed:
            raise SkillError("AUTHENTICATION_FAILED", "The API Key was rejected; check credentials before continuing.", stage=stage)
        headers = {"Authorization": f"Bearer {self._key}"}
        if auth_code is not None:
            self._secrets.add(auth_code)
            headers["X-Skill-Auth-Code"] = auth_code
        try:
            response = await self.client.post(self.settings.api_base_url + path, headers=headers,
                                              json=json, files=files, data=data)
        except httpx.TransportError:
            if stage == "polling":
                raise
            raise SkillError("RECOVERY_REQUIRED", "The remote operation outcome is unknown; verify it before retrying.", stage=stage) from None
        try:
            payload = response.json()
        except ValueError:
            payload = None
        code = None
        if isinstance(payload, dict):
            candidate = payload.get("code")
            if candidate is None and isinstance(payload.get("detail"), dict):
                candidate = payload["detail"].get("code")
            if isinstance(candidate, (str, int)):
                code = str(candidate)
        failed = not response.is_success or (isinstance(payload, dict) and payload.get("success") is False)
        if failed:
            safe_code = code if code and re.fullmatch(r"[A-Z][A-Z0-9_]{0,63}|[0-9]{1,5}", code) and self.safe_text(code) == code else None
            detail = self.safe_detail(payload)
            suffix = f" Backend detail: {detail}" if detail else ""
            diagnostics = {"backend_code": safe_code, "http_status": response.status_code}
            # HTTP 402 means the balance is short whatever code the platform
            # names it with, so it is treated as quota exhaustion alongside the
            # confirmed error codes. Only the quota branch keeps the file
            # resumable; the generic rejection branch below is terminal.
            quota_signal = (code in self.settings.quota_error_codes
                            or (response.status_code == 402
                                and code not in self.settings.authentication_error_codes))
            if quota_signal and stage in {"uploading", "authorizing"}:
                raise SkillError("INSUFFICIENT_QUOTA", "Remaining quota is insufficient for this file." + suffix, stage=stage, **diagnostics)
            if code in self.settings.authentication_error_codes or (response.status_code == 401 and stage != "importing"):
                self.authentication_failed = True
                raise SkillError("AUTHENTICATION_FAILED", "The API Key was rejected; check your configuration." + suffix, stage=stage, **diagnostics)
            if stage == "importing" and code in self.settings.retryable_import_codes:
                raise SkillError("IMPORT_RETRYABLE", "The backend explicitly rejected this import attempt." + suffix, stage=stage, retryable=True, **diagnostics)
            if stage == "polling":
                if response.status_code == 429 or response.status_code >= 500:
                    response.raise_for_status()
                if response.status_code in {401, 403}:
                    # Credential/permission refusal: stop requesting rather than retry in a loop.
                    # The imported task keeps its ID, so recovery stays possible.
                    self.authentication_failed = True
                    raise SkillError("AUTHENTICATION_FAILED", "The backend refused the result query; check credentials and permissions." + suffix, stage=stage, **diagnostics)
                # Any other failed query (gateway HTML, an unmapped 4xx, or a failure envelope)
                # says nothing about the imported task itself, so it stays a retryable read.
                raise SkillError("BACKEND_POLL_UNAVAILABLE",
                                 "The result query did not complete; the saved task remains recoverable." + suffix,
                                 stage=stage, retryable=True, **diagnostics)
            if response.is_success:
                # A 2xx envelope reporting failure leaves the business outcome unverified.
                raise SkillError("RECOVERY_REQUIRED", f"The backend reported failure (HTTP {response.status_code}) without a verified recovery mapping." + suffix, stage=stage, **diagnostics)
            if 400 <= response.status_code < 500 and response.status_code not in {408, 429}:
                # The server explicitly refused this request, so nothing was executed and no
                # recovery gate is needed. Only transient or server-side failures stay ambiguous.
                raise SkillError("BACKEND_REQUEST_REJECTED",
                                 f"The backend rejected this {stage} request (HTTP {response.status_code})." + suffix,
                                 stage=stage, **diagnostics)
            # Unknown write failures are not evidence that quota was not reserved.
            raise SkillError("RECOVERY_REQUIRED", f"The remote operation was rejected (HTTP {response.status_code}) without a verified recovery mapping." + suffix, stage=stage, **diagnostics)
        if not isinstance(payload, dict):
            if stage == "polling":
                # An unreadable query response says nothing about the imported task.
                raise SkillError("RESULT_INVALID", "The result query response could not be parsed; the saved task remains recoverable.",
                                 stage=stage, retryable=True)
            raise SkillError("RECOVERY_REQUIRED", "The backend response did not match the documented structure.", stage=stage)
        return payload


def map_result(data, settings):
    segments, speakers, source_times = [], [], []
    roles = data.get("rolesInfos") or []
    summaries = data.get("roleSummary") or []
    if not isinstance(roles, list) or not isinstance(summaries, list):
        raise ValueError("Invalid role arrays")
    for role in roles:
        if not isinstance(role, dict):
            raise ValueError("Invalid transcript segment")
        text = role.get("content")
        if not isinstance(text, str):
            raise ValueError("Invalid transcript content type")
        if not text.strip():
            continue
        times = {}
        if settings.timestamp_unit:
            for key, target in (("bg", "start_time"), ("ed", "end_time")):
                try:
                    value = float(role[key]) / (1000 if settings.timestamp_unit == "milliseconds" else 1)
                    if math.isfinite(value) and value >= 0:
                        times[target] = value
                except (KeyError, TypeError, ValueError):
                    pass
        label = role.get("roleName") or role.get("role")
        segments.append({"text": text, "speaker": str(label) if label is not None else None, **times})
        source_times.append({k: role.get(k) for k in ("bg", "ed") if isinstance(role.get(k), (str, int, float))})
    if not segments:
        raise ValueError("No usable transcript")
    for role in summaries:
        if not isinstance(role, dict):
            raise ValueError("Invalid speaker summary")
        label = role.get("roleName") or role.get("role")
        if label is not None and isinstance(role.get("summary"), str) and role["summary"].strip():
            speakers.append({"speaker": str(label), "summary": role["summary"]})
    todo_rows = data.get("todoList")
    if not isinstance(todo_rows, list):
        # Current intermediary nests the upstream response in raw; check there as fallback.
        raw = data.get("raw")
        raw_data = raw.get("data") if isinstance(raw, dict) else None
        todo_rows = raw_data.get("todoList") if isinstance(raw_data, dict) else None
    todos = []
    if isinstance(todo_rows, list):
        for row in todo_rows:
            if not isinstance(row, dict):
                continue
            content = row.get("todoContent")
            if not isinstance(content, str) or not content.strip():
                continue
            todos.append(TodoItem(
                content=" ".join(content.split()),
                owner=row.get("manager") or None,
                deadline=row.get("deadlineTime") or None,
            ))
    return NormalizedBackendResult(
        transcript_text="\n\n".join(s["text"] for s in segments), transcript_segments=segments,
        full_summary=data.get("noteSummary") or None, speaker_summaries=speakers, todos=todos,
        additional_sections={label: data[key] for key, label in
                             (("keywords", "关键词"), ("overviewInfo", "概要"), ("noteTitle", "笔记标题")) if data.get(key)},
        source_metadata={"segment_times": source_times, "timestamp_unit": settings.timestamp_unit},
    )


class RealBackendAdapter:
    mode = "real"

    def __init__(self, client, repository):
        from .authorization import FileAuthorizationService
        self.api = client
        self.repository = repository
        self.settings = client.settings
        self.binding = client.binding
        self.compatible_bindings = client.compatible_bindings
        self.authorization = FileAuthorizationService(client, repository)

    async def submit_job(self, job):
        job_id = job["job_id"]
        state = job["status"]
        if state in {"uploading", "authorizing", "importing", "recovery_required"}:
            raise SkillError("RECOVERY_REQUIRED", "An interrupted remote operation must be verified before continuing.", stage=state)
        if not job["file_id"]:
            path = Path(job["local_path"])
            if not path.is_file():
                raise SkillError("FILE_NOT_FOUND", "The prepared audio file is no longer available.")
            # Opening the file must succeed before recording a remote request.
            with path.open("rb") as handle:
                self.repository.update(job_id, status="uploading", upload_started_at=now())
                try:
                    payload = await self.api.request(UPLOAD, stage="uploading",
                        files={"file": (path.name, handle, upload_mime_type(job["validation_json"]))},
                        data={"biz_type": "audio", "scene": self.settings.skill_id})
                except SkillError as exc:
                    if exc.code in {"INSUFFICIENT_QUOTA", "AUTHENTICATION_FAILED"}:
                        self.repository.update(job_id, status="queued")
                    raise
            try:
                file_id = valid_id(payload.get("file_id"))
                duration = payload.get("audio_duration_seconds")
                duration = float(duration) if duration is not None else None
                if duration is not None and (not math.isfinite(duration) or duration <= 0):
                    duration = None
            except (ValueError, TypeError):
                raise SkillError("RECOVERY_REQUIRED", "Upload response is missing a usable file identifier.", stage="uploading") from None
            file_expiry = None
            if payload.get("expires_at"):
                try:
                    file_expiry = expiry(payload["expires_at"]).isoformat()
                except (ValueError, TypeError):
                    pass  # Optional upload expiry field is still an integration check.
            self.repository.update(job_id, file_id=file_id, server_duration=duration,
                                   file_expires_at=file_expiry, status="uploaded", uploaded_at=now())
        await self.authorization.authorize_file(job_id)
        job = self.repository.job(job_id)
        while job["import_attempts"] < self.settings.import_attempt_limit:
            try:
                expires_at = expiry(job["auth_expires_at"])
            except (ValueError, TypeError):
                raise SkillError(
                    "RECOVERY_REQUIRED",
                    "The saved authorization expiry cannot be verified; the code was retained.",
                    stage="importing",
                ) from None
            if expires_at <= datetime.now(timezone.utc):
                self.repository.update(job_id, auth_code=None)
                raise SkillError("RECOVERY_REQUIRED", "The saved authorization has expired.", stage="importing")
            code = job["auth_code"]
            if not code:
                message = ("This task references authorization stored by an older client, but the code is not present in SQLite."
                           if job["auth_reference"] else "The saved authorization code is unavailable.")
                raise SkillError("RECOVERY_REQUIRED", message, stage="importing")
            attempts = job["import_attempts"] + 1
            self.repository.update(job_id, status="importing", import_attempts=attempts,
                                   last_import_at=now(), submitted_at=job["submitted_at"] or now())
            try:
                payload = await self.api.request(IMPORT, stage="importing", json={"file_id": job["file_id"]}, auth_code=code)
            except SkillError as exc:
                if exc.code == "AUTHENTICATION_FAILED":
                    self.repository.update(job_id, status="authorized")
                if not exc.retryable:
                    raise
                failures = job["import_failures"] + 1
                self.repository.update(job_id, status="authorized", import_failures=failures,
                                       billing_state="refund_unconfirmed" if failures == 3 else "reserved",
                                       auth_code=None if failures == 3 else code)
                if attempts >= self.settings.import_attempt_limit:
                    raise SkillError("BACKEND_IMPORT_FAILED", "Import attempt limit reached; refund receipt is not confirmed.",
                                     stage="importing", backend_code=exc.backend_code, http_status=exc.http_status) from None
                await asyncio.sleep(self.settings.retry_base_seconds * 2 ** (attempts - 1))
                job = self.repository.job(job_id)
                continue
            try:
                if payload.get("success") is not True or payload.get("mode") != "import":
                    raise ValueError("Invalid import response")
                task_id = valid_id(payload["data"]["XB_NOTE_ID"])
            except (KeyError, TypeError, ValueError):
                raise SkillError("RECOVERY_REQUIRED", "Import response is missing a usable task identifier.", stage="importing") from None
            # Commit the recoverable task ID and remove the one-use code atomically.
            # A failed commit leaves the code and ambiguous-import gate intact.
            self.repository.update(job_id, backend_task_id=task_id, status="polling",
                                   billing_state="settled", auth_code=None)
            return SubmitResult(task_id=task_id)
        raise SkillError("RECOVERY_REQUIRED", "The saved authorization has no remaining import attempts.", stage="importing")

    async def query(self, task_id):
        payload = await self.api.request(QUERY, stage="polling", json={"XB_NOTE_ID": task_id})
        try:
            if payload.get("success") is not True or payload.get("mode") != "query":
                raise ValueError("Invalid query response")
            data = payload["data"]
            if valid_id(data["XB_NOTE_ID"]) != task_id:
                raise ValueError("Mismatched task")
            status = data["status"]
            if type(status) is not int:
                raise ValueError("Invalid status")
            if status in (1, 2, 5):
                return TaskQueryResult(status="processing")
            if status == 4:
                reason = data.get("errorMessage")
                reason = self.api.safe_text(reason) if isinstance(reason, str) else "Audio processing failed after import."
                reason = re.sub(r"(?i)Bearer\s+\S+|sa_[A-Za-z0-9_-]+", "[redacted]", reason)
                reason = re.sub(r"(https?://[^\s?]+)\?\S+", r"\1?[redacted]", reason)
                reason = reason[:500]
                return TaskQueryResult(status="failed", error_code="BACKEND_TASK_FAILED",
                                       error_message=reason + " No refund is confirmed.")
            if status != 3:
                raise ValueError("Unknown status")
            # A verified matching terminal response releases remote capacity even
            # when its result cannot yet be mapped. No raw response text is stored.
            rows = self.repository.connection.execute(
                "SELECT job_id,identity_binding FROM jobs WHERE backend_task_id=? AND backend_mode='real'",
                (task_id,)).fetchall()
            matching = [r["job_id"] for r in rows if r["identity_binding"] in
                        {self.binding, *self.compatible_bindings}]
            for job_id in matching:
                self.repository.update(job_id, result_received_at=now())
            try:
                result = map_result(self.api.redact_result(data), self.settings)
            except (ValueError, KeyError, TypeError):
                # Retain structural evidence, not arbitrary response strings/keys:
                # even unknown credentials embedded in transcript data stay out.
                diagnostic = json.dumps(result_shape(data))
                for job_id in matching:
                    self.repository.update(job_id, result_diagnostic_json=diagnostic)
                raise
            for job_id in matching:
                self.repository.update(job_id, result_diagnostic_json=None)
            return TaskQueryResult(status="succeeded", result=result)
        except (ValueError, KeyError, TypeError):
            # The read succeeded but its content cannot be used: still not a task-level failure.
            raise SkillError("RESULT_INVALID", "The result does not match the documented transcript schema.",
                             stage="polling", retryable=True) from None


def result_shape(data):
    """Allowlisted schema evidence; no free text, unknown keys, or scalar values.

    This deliberately cannot reconstruct the recording. Original result content
    remains on the backend and can be queried again using the saved task ID.
    """
    fields = {"rolesInfos", "content", "roleName", "role", "bg", "ed",
              "noteSummary", "roleSummary", "summary", "keywords", "overviewInfo", "noteTitle",
              "raw", "todoList", "todoContent", "manager", "deadlineTime", "todoType"}

    def shape(value, depth=0):
        if depth >= 4:
            return type(value).__name__
        if isinstance(value, dict):
            return {"type": "object", "fieldCount": len(value), "fields": {
                k: shape(v, depth + 1) for k, v in value.items() if k in fields}}
        if isinstance(value, list):
            return {"type": "array", "length": len(value), "items": [shape(v, depth + 1) for v in value[:200]]}
        return type(value).__name__

    return shape(data)
