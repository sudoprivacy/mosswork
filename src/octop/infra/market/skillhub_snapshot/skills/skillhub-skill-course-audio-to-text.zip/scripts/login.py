"""Native OAuth login: local code callback, one exchange, then key persistence."""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import secrets
import time
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit
import webbrowser

import httpx

from .models import SkillError
from .http_logging import sensitive_http


def credential_action(website_url="https://www.qingfengyq.com/"):
    return {"type": "configure_credentials", "url": website_url,
            "message": "Set up or replace the API key, then resume the saved operation.",
            "options": [
                {"id": "browser", "label": "Browser authorization and automatic setup (recommended)", "command": "--login"},
                {"id": "manual", "label": "Enter an existing API key privately", "command": "--configure-key"},
                {"id": "cancel", "label": "Cancel"},
            ]}


CLIENT_ID = "cyber-recording"
ABILITY_ID = "cyber-recording"
ABILITY_TYPE = "skill"
EXCHANGE_PATH = "/third-party/native-oauth/exchange"


@sensitive_http
def exchange_code(settings, code, state, *, transport=None):
    """Exchange once, without a pre-existing key, JWT, redirects or retries."""
    base = settings.oauth_api_base_url or settings.api_base_url
    try:
        with httpx.Client(timeout=settings.oauth_exchange_timeout_seconds,
                          transport=transport, trust_env=False, follow_redirects=False) as client:
            response = client.post(base + EXCHANGE_PATH,
                                   json={"client_id": CLIENT_ID, "code": code, "state": state})
    except httpx.HTTPError:
        raise SkillError("LOGIN_EXCHANGE_UNKNOWN", "The login code exchange outcome is unknown. Start fresh authorization; this code will not be exchanged again.") from None
    if response.status_code != 200:
        errors = {
            400: ("LOGIN_EXCHANGE_REJECTED", "The login code or request was rejected. Start fresh authorization; do not replay this code."),
            409: ("LOGIN_ACCOUNT_UNAVAILABLE", "The selected account cannot provide an API key. Check its status before signing in again."),
            429: ("LOGIN_EXCHANGE_RATE_LIMITED", "Too many authorization attempts. Wait before starting fresh authorization."),
            503: ("LOGIN_EXCHANGE_UNAVAILABLE", "The authorization service is unavailable. Start fresh authorization later."),
        }
        error, message = errors.get(response.status_code, (
            "LOGIN_EXCHANGE_FAILED", "The authorization exchange failed. Check the deployment and start fresh authorization; this code will not be replayed."))
        # Never echo the response body: it may include a key or the submitted code.
        raise SkillError(error, message, http_status=response.status_code)
    try:
        data = response.json()["data"]
        key = data["api_key"]
        if (data["client_id"] != CLIENT_ID or data["token_type"].lower() != "bearer"
                or not isinstance(key, str) or not key or any(c.isspace() or ord(c) < 32 for c in key)):
            raise ValueError("Invalid exchange response")
    except (ValueError, KeyError, TypeError, AttributeError):
        raise SkillError("LOGIN_EXCHANGE_INVALID", "The exchange response did not contain a valid API key for this client. Start fresh authorization; the code may already be consumed.") from None
    return key


def browser_login(settings, credentials, *, switch_account=False, opener=None, transport=None):
    if not settings.authorization_page_url:
        raise SkillError("BROWSER_LOGIN_UNAVAILABLE", "The Qingfeng authorization page is not configured. Use private manual entry (--configure-key).")
    state, nonce = secrets.token_urlsafe(16), secrets.token_urlsafe(16)
    # A single-threaded listener serializes concurrent callbacks. Once exchange starts,
    # queued repeats see its saved outcome rather than starting another exchange.
    outcome = {}

    def finish(identity, status, body, *, result=None, error=None):
        outcome.update(identity=identity, status=status, body=body, result=result, error=error,
                       expires=time.monotonic() + settings.login_ack_grace_seconds)

    class Callback(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, status, body=None):
            payload = json.dumps(body).encode() if body is not None else b""
            try:
                self.send_response(status)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                if self.headers.get("Access-Control-Request-Private-Network") == "true":
                    self.send_header("Access-Control-Allow-Private-Network", "true")
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
            except OSError:
                # Browser timeout/disconnect cannot undo a saved key or cause replay.
                pass

        def do_OPTIONS(self):
            if urlsplit(self.path).path != "/callback":
                self.reply(404, {"ok": False, "error": "not_found"})
            else:
                self.reply(204)

        def do_GET(self):
            parsed = urlsplit(self.path)
            params = parse_qs(parsed.query, keep_blank_values=True)
            if parsed.path != "/callback":
                self.reply(404, {"ok": False, "error": "not_found"})
                return
            if params.get("state") != [state]:
                self.reply(400, {"ok": False, "error": "state_mismatch"})
                return
            codes, errors = params.get("code", []), params.get("error", [])
            identity = (tuple(codes), tuple(errors))
            if outcome:
                if identity == outcome["identity"]:
                    self.reply(outcome["status"], outcome["body"])
                else:
                    self.reply(409, {"ok": False, "error": "attempt_finished"})
                return
            if errors == ["access_denied"] and not codes:
                error = SkillError("LOGIN_DENIED", "Browser authorization was denied. The previous key was preserved.")
                # Provisional website delivery acknowledgement approved by the user;
                # the CLI still fails as denied and no exchange/persistence occurs.
                finish(identity, 200, {"ok": True}, error=error)
            elif errors or len(codes) != 1 or not codes[0] or any(c.isspace() for c in codes[0]):
                error = SkillError("LOGIN_INVALID_CALLBACK", "The callback did not contain one valid login code. The previous key was preserved.")
                finish(identity, 400, {"ok": False, "error": error.code}, error=error)
            else:
                try:
                    key = exchange_code(settings, codes[0], state, transport=transport)
                    result = credentials.configure(key, switch_account=switch_account)
                except SkillError as error:
                    finish(identity, 502, {"ok": False, "error": error.code}, error=error)
                except Exception:
                    # Do not expose arbitrary HTTP/store exception text or attempt replay.
                    error = SkillError("LOGIN_CALLBACK_FAILED", "API-key setup could not complete. Check local configuration and start fresh authorization; this login code will not be replayed.")
                    finish(identity, 500, {"ok": False, "error": error.code}, error=error)
                else:
                    # Persistence and activation have both completed before success.
                    finish(identity, 200, {"ok": True}, result=result)
            self.reply(outcome["status"], outcome["body"])

    class Listener(HTTPServer):
        def get_request(self):
            connection, address = super().get_request()
            connection.settimeout(1)
            return connection, address

        def handle_error(self, request, client_address):
            # No request paths/tracebacks: the callback contains a one-time credential.
            if not outcome:
                error = SkillError("LOGIN_CALLBACK_FAILED", "The local callback could not be completed; restart authorization.")
                finish(None, 500, {"ok": False, "error": error.code}, error=error)

    try:
        with Listener(("127.0.0.1", 0), Callback) as server:
            if not 1024 <= server.server_port <= 65535:
                raise SkillError("LOGIN_LISTENER_FAILED", "The local callback port is outside the supported range.")
            callback = f"http://127.0.0.1:{server.server_port}/callback"
            url = urlsplit(settings.authorization_page_url)
            params = parse_qs(url.query, keep_blank_values=True)
            params.pop("callbackUrl", None)
            params.update(
                client_id=[CLIENT_ID],
                redirect_uri=[callback],
                state=[state],
                nonce=[nonce],
                ability_id=[ABILITY_ID],
                ability_type=[ABILITY_TYPE],
            )
            authorize_url = urlunsplit(url._replace(query=urlencode(params, doseq=True)))
            try:
                opened = (opener or webbrowser.open_new_tab)(authorize_url)
            except Exception:
                opened = False
            if not opened:
                raise SkillError("BROWSER_OPEN_FAILED", "Could not open the system browser. Use private manual entry or retry setup.")
            deadline = time.monotonic() + settings.login_timeout_seconds
            while True:
                remaining = (outcome["expires"] if outcome else deadline) - time.monotonic()
                if remaining <= 0:
                    if outcome:
                        break
                    raise SkillError("LOGIN_TIMEOUT", "Browser setup timed out. The previous key was preserved; start login again for a fresh link.")
                server.timeout = min(0.5, remaining)
                server.handle_request()
    except KeyboardInterrupt:
        raise SkillError("LOGIN_CANCELLED", "Browser setup cancelled; pending tasks were preserved. Check the saved setting if a callback already completed.") from None
    except OSError:
        raise SkillError("LOGIN_LISTENER_FAILED", "Could not start or use the local callback listener.") from None
    if outcome["error"] is not None:
        raise outcome["error"]
    return outcome["result"]
