import ipaddress
import re
import socket
import tempfile
from pathlib import Path
from typing import Protocol
from urllib.parse import unquote, urlsplit

import httpx

from .media import FORMATS
from .http_logging import sensitive_http
from .models import AudioInput, ResolvedInput, Settings, SkillError


def sanitize_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f\x7f]', "_", name).strip(" .")[:100]
    if name.upper().split(".")[0] in {"CON", "PRN", "AUX", "NUL", *[f"COM{i}" for i in range(1, 10)], *[f"LPT{i}" for i in range(1, 10)]}:
        name = "_" + name
    return name or "audio"


def validate_remote_url(url: str, strict: bool = False) -> None:
    parts = urlsplit(url)
    if parts.scheme not in {"http", "https"} or not parts.hostname or parts.username or parts.password:
        raise SkillError("DOWNLOAD_FAILED", "A valid HTTP(S) URL without embedded credentials is required.")
    if strict:
        addresses = socket.getaddrinfo(parts.hostname, parts.port or (443 if parts.scheme == "https" else 80))
        if any(not ipaddress.ip_address(item[4][0]).is_global for item in addresses):
            raise SkillError("DOWNLOAD_FAILED", "Remote URL resolves to a non-public address.")


class AttachmentResolver(Protocol):
    async def materialize(self, attachment: AudioInput) -> ResolvedInput: ...


class MockAttachmentResolver:
    """Treat an attachment value as an already materialized local path."""
    async def materialize(self, attachment: AudioInput) -> ResolvedInput:
        path = Path(attachment.value).expanduser().resolve()
        return ResolvedInput(original_source=attachment.value,
                             original_name=attachment.display_name or path.name,
                             local_path=path)


@sensitive_http
async def resolve_input(item: AudioInput, client: httpx.AsyncClient, settings: Settings,
                        attachment_resolver: AttachmentResolver) -> ResolvedInput:
    if item.source_type == "attachment":
        resolved = await attachment_resolver.materialize(item)
        if item.display_name:
            resolved = resolved.model_copy(update={"original_name": item.display_name})
        return resolved
    if item.source_type == "local":
        path = Path(item.value).expanduser().resolve()
        return ResolvedInput(original_source=item.value, original_name=item.display_name or path.name,
                             local_path=path)
    name = item.display_name or Path(unquote(urlsplit(item.value).path)).name
    extension = Path(name).suffix.lower()
    if extension not in FORMATS:
        raise SkillError("UNSUPPORTED_EXTENSION", "URL needs a supported filename or display_name.")
    temporary = None
    try:
        url = item.value
        for redirect in range(settings.max_redirects + 1):
            validate_remote_url(url, settings.strict_remote_urls)
            async with client.stream("GET", url, follow_redirects=False) as response:
                if response.is_redirect:
                    if redirect == settings.max_redirects or not response.headers.get("location"):
                        raise SkillError("DOWNLOAD_FAILED", "Invalid or excessive redirects.")
                    url = str(response.url.join(response.headers["location"]))
                    continue
                response.raise_for_status()
                length = response.headers.get("content-length", "")
                if length.isdigit() and int(length) > settings.max_file_size_bytes:
                    raise SkillError("DOWNLOAD_TOO_LARGE", "Download exceeds the size limit.")
                temp_dir = settings.work_dir / "temporary"
                temp_dir.mkdir(parents=True, exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=temp_dir, suffix=extension, delete=False) as handle:
                    temporary = Path(handle.name)
                    size = 0
                    async for chunk in response.aiter_bytes(chunk_size=65536):
                        size += len(chunk)
                        if size > settings.max_file_size_bytes:
                            raise SkillError("DOWNLOAD_TOO_LARGE", "Download exceeds the size limit.")
                        handle.write(chunk)
                return ResolvedInput(original_source=item.value, original_name=name,
                                     local_path=temporary.resolve(), is_temporary=True)
        raise SkillError("DOWNLOAD_FAILED", "Download did not complete.")
    except BaseException as exc:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        if isinstance(exc, (SkillError, KeyboardInterrupt, SystemExit)) or not isinstance(exc, Exception):
            raise
        raise SkillError("DOWNLOAD_FAILED", "Could not download the media file.") from exc
