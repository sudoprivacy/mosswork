import argparse
import asyncio
import getpass
import json
import sys
import warnings
from pathlib import Path

from .authorization import authorize_file
from .backend import MockBackendAdapter
from .credentials import CredentialProvider
from .models import AudioInput, Settings, SkillError
from .login import browser_login, credential_action
from .workflow import resume_incomplete_jobs, run_skill


def main():
    parser = argparse.ArgumentParser(description="录音转文字·智能会议：批量转写录音并生成原文记录和智能总结。默认使用模拟模式，真实模式会使用清风权益。")
    parser.add_argument("inputs", nargs="*", help="Local files or HTTP(S) URLs")
    parser.add_argument("--inputs-json", type=Path, help="JSON array of AudioInput objects")
    parser.add_argument("--settings", type=Path, help="Explicit non-secret Settings JSON; the private credential .env cannot be used here")
    parser.add_argument("--backend", choices=["mock", "real"], default=None)
    parser.add_argument("--api-base-url", help="HTTPS API prefix ending in /api/v1")
    parser.add_argument("--work-dir", type=Path)
    parser.add_argument("--resume", metavar="BATCH_ID")
    parser.add_argument("--ack-recovery", metavar="BATCH_ID", help="Release the recovery gate for files whose remote outcome you verified")
    parser.add_argument("--remote-task-id", metavar="TASK_ID", help="With --ack-recovery: attach the verified remote task ID so only its result is queried")
    parser.add_argument("--confirm-abandoned", action="store_true", help="With --ack-recovery: confirm the previous remote operation produced nothing usable")
    parser.add_argument("--job", action="append", default=[], metavar="JOB_ID", help="Limit --ack-recovery to specific files; repeatable")
    parser.add_argument("--prepare-report", type=Path, metavar="TRANSCRIPT_DOCX", help="Assemble the report prompt and print it to stdout; no network")
    parser.add_argument("--summary-docx", type=Path, help="Matching smart-summary DOCX for --prepare-report")
    parser.add_argument("--meeting-info", type=Path, help="Optional UTF-8 user-provided meeting information for --prepare-report")
    parser.add_argument("--render-report", type=Path, metavar="REPORT", help="Render the model report into the fixed-template HTML; pass - to read it from stdin")
    parser.add_argument("--output-dir", type=Path, metavar="DIR", help="Directory that receives the rendered HTML; required when reading the report from stdin")
    parser.add_argument("--authorize-file", metavar="FILE_ID", help="Authorize an uploaded file and RESERVE quota; does not import it")
    parser.add_argument("--file-name", help="Display name for standalone authorization")
    parser.add_argument("--configure-key", action="store_true", help="Read an API Key privately and save it for this skill")
    parser.add_argument("--login", action="store_true", help="Open browser authorization and persist the returned API key")
    parser.add_argument("--switch-account", action="store_true", help="With setup, select another account without transferring saved tasks")
    parser.add_argument("--authorization-page-url", help="OAuth authorization page (default: Qingfeng existing-host candidate)")
    parser.add_argument("--oauth-api-base-url", help="OAuth-only API prefix; defaults to --api-base-url, supports HTTP loopback development")
    parser.add_argument("--login-timeout", type=float, help="Callback wait in seconds (default 600)")
    parser.add_argument("--poll-interval", type=float)
    parser.add_argument("--mock-seconds", type=float, default=0)
    parser.add_argument("--mock-fail", action="append", default=[])
    args = parser.parse_args()
    modes = sum(bool(x) for x in (args.resume, args.ack_recovery, args.authorize_file, args.configure_key, args.login, args.prepare_report, args.render_report))
    if modes > 1 or (modes and (args.inputs or args.inputs_json)):
        parser.error("Choose only one operation: batch inputs, resume, ack-recovery, authorization, login, prepare-report, or render-report")
    if args.prepare_report and not args.summary_docx:
        parser.error("--prepare-report requires --summary-docx")
    if (args.summary_docx or args.meeting_info) and not args.prepare_report:
        parser.error("--summary-docx and --meeting-info require --prepare-report")
    if args.output_dir and not args.render_report:
        parser.error("--output-dir requires --render-report")
    if args.switch_account and not (args.login or args.configure_key):
        parser.error("--switch-account requires --login or --configure-key")
    if not modes and not args.inputs and not args.inputs_json:
        parser.error("Provide input files or an operation")
    if args.remote_task_id or args.confirm_abandoned or args.job:
        if not args.ack_recovery:
            parser.error("--remote-task-id, --confirm-abandoned and --job require --ack-recovery")
    if args.ack_recovery and not (args.remote_task_id or args.confirm_abandoned):
        parser.error("--ack-recovery requires exactly one of --remote-task-id or --confirm-abandoned")
    if args.ack_recovery and args.remote_task_id and args.confirm_abandoned:
        parser.error("Choose exactly one of --remote-task-id or --confirm-abandoned")
    if args.prepare_report or args.render_report:
        # Local post-processing must never enter credential setup or a paid workflow.
        from .meeting_report import prepare_report, save_report
        try:
            if args.prepare_report:
                # The prompt itself goes to stdout so the host model can pipe it
                # onward; the metadata goes to stderr so stdout stays clean.
                result = prepare_report(args.prepare_report, args.summary_docx, args.meeting_info)
                print(json.dumps(result, ensure_ascii=False, indent=2), file=sys.stderr)
                return 0
            result = save_report(args.render_report, args.output_dir)
        except ValueError as exc:
            result = {"status": "failed", "errorCode": "REPORT_INVALID", "errorMessage": str(exc)}
        except TypeError as exc:
            result = {"status": "failed", "errorCode": "REPORT_INVALID", "errorMessage": str(exc)}
        except Exception:
            result = {"status": "failed", "errorCode": "REPORT_FILE_ERROR", "errorMessage": "无法读取文档或写入报告文件；请检查文件格式与访问权限。原有 DOCX 和转写状态已保留。"}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"] in {"report_pending", "completed"} else 1
    try:
        data = {}
        if args.settings:
            if args.settings.name == ".env" or args.settings.name.startswith(".env."):
                parser.error("The private credential .env cannot be used as a settings file")
            data = json.loads(args.settings.read_text())
        overrides = {"backend_mode": args.backend, "api_base_url": args.api_base_url,
                     "work_dir": args.work_dir, "poll_interval_seconds": args.poll_interval,
                     "authorization_page_url": args.authorization_page_url,
                     "oauth_api_base_url": args.oauth_api_base_url,
                     "login_timeout_seconds": args.login_timeout}
        data.update({k: v for k, v in overrides.items() if v is not None})
        settings = Settings.model_validate(data)
        if args.login:
            result = browser_login(settings, CredentialProvider(settings.api_base_url), switch_account=args.switch_account)
        elif args.configure_key:
            with warnings.catch_warnings():
                warnings.simplefilter("error", getpass.GetPassWarning)
                try:
                    key = getpass.getpass("API Key (hidden): ")
                except getpass.GetPassWarning:
                    raise SkillError("LOGIN_PRIVATE_INPUT_UNAVAILABLE", "Hidden input is unavailable here. Run --configure-key in a local terminal or use browser setup.") from None
            result = CredentialProvider(settings.api_base_url).configure(key, switch_account=args.switch_account)
        elif args.authorize_file:
            result = asyncio.run(authorize_file(args.authorize_file, settings, file_name=args.file_name))
        elif args.ack_recovery:
            from .recovery import acknowledge_recovery
            result = asyncio.run(acknowledge_recovery(
                args.ack_recovery, settings, job_ids=args.job or None,
                remote_task_id=args.remote_task_id, confirm_abandoned=args.confirm_abandoned))
            result = {"backend": settings.backend_mode, **result}
        else:
            backend = MockBackendAdapter(processing_seconds=args.mock_seconds, failures=set(args.mock_fail)) if settings.backend_mode == "mock" else None
            if args.resume:
                result = asyncio.run(resume_incomplete_jobs(args.resume, settings, backend))
            else:
                inputs = [AudioInput(source_type="url" if v.startswith(("http://", "https://")) else "local", value=v)
                          for v in args.inputs]
                if args.inputs_json:
                    inputs.extend(AudioInput.model_validate(item) for item in json.loads(args.inputs_json.read_text()))
                if not inputs:
                    parser.error("At least one input is required")
                result = asyncio.run(run_skill(inputs, settings, backend))
            result = {"backend": settings.backend_mode, **result}
    except SkillError as exc:
        result = {"status": "failed", "errorCode": exc.code, "errorMessage": str(exc)}
        if exc.http_status is not None:
            result["httpStatus"] = exc.http_status
        if exc.code in {"CREDENTIALS_REQUIRED", "AUTHENTICATION_FAILED"} or exc.code.startswith(("LOGIN_", "BROWSER_", "CREDENTIAL_FILE_")):
            result["actions"] = [credential_action()]
    except (KeyboardInterrupt, EOFError):
        result = {"status": "cancelled", "message": "API-key setup cancelled; pending tasks were preserved."}
    except (ValueError, TypeError, OSError):
        # Validation exceptions can echo input values: keep settings and paths out.
        result = {"status": "failed", "errorCode": "INVALID_INPUT", "errorMessage": "Check the supplied inputs, settings and local file access."}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"completed", "authorized", "configured", "acknowledged"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
