import asyncio
import logging
import sys
import traceback
from contextlib import asynccontextmanager
from pathlib import Path

import httpx

from .backend import MockBackendAdapter
from .documents import render_documents
from .inputs import MockAttachmentResolver, resolve_input, sanitize_filename
from .media import validate_audio_file
from .models import AudioInput, NormalizedBackendResult, Settings, SkillError, validate_work_dir
from .repository import BLOCKED, TERMINAL_ERROR_CODES, Repository, now
from .ownership import exclusive_workdir
from .credentials import CredentialProvider
from .real_backend import QingfengClient, RealBackendAdapter

logger = logging.getLogger(__name__)


async def poll_until_finished(job, backend, repository, settings, capacity_changed=None):
    failures = 0
    count = job["poll_count"]
    while True:
        count += 1
        repository.update(job["job_id"], poll_count=count, last_polled_at=now())
        try:
            try:
                response = await backend.query(job["backend_task_id"])
                if response.status == "succeeded":
                    repository.update(job["job_id"], result_received_at=now())
            finally:
                # The real adapter also persists terminal evidence before mapping;
                # notify even when mapping raises, before any local retry delay.
                if capacity_changed:
                    await capacity_changed(job["job_id"])
        except SkillError as exc:
            # A failed read never confirms the state of an imported task, so a retryable query
            # error uses the bounded budget and then leaves the job recoverable.
            if not exc.retryable or failures >= settings.poll_retries:
                raise
            await asyncio.sleep(settings.retry_base_seconds * 2 ** failures)
            failures += 1
            continue
        except (httpx.TransportError, httpx.HTTPStatusError) as exc:
            retryable = not isinstance(exc, httpx.HTTPStatusError) or (
                exc.response.status_code == 429 or exc.response.status_code >= 500)
            if retryable and failures < settings.poll_retries:
                await asyncio.sleep(settings.retry_base_seconds * 2 ** failures)
                failures += 1
                continue
            raise SkillError("BACKEND_POLL_UNAVAILABLE",
                             "The result query did not complete; the saved task remains recoverable.",
                             stage="polling") from exc
        failures = 0
        if response.status == "failed":
            raise SkillError(response.error_code or "BACKEND_TASK_FAILED",
                             response.error_message or "Backend task failed.")
        if response.status == "succeeded":
            if response.result is None:
                raise SkillError("RESULT_INVALID", "Backend success response has no result.",
                                 stage="polling", retryable=True)
            return response.result
        await asyncio.sleep(settings.poll_interval_seconds)


async def process_job(job, backend, repository, settings, renderer, capacity_changed=None):
    job_id = job["job_id"]
    if job["normalized_result_json"]:
        result = NormalizedBackendResult.model_validate_json(job["normalized_result_json"])
    else:
        if not job["backend_task_id"]:
            if isinstance(backend, RealBackendAdapter):
                submission = await backend.submit_job(repository.job(job_id))
            else:
                repository.update(job_id, status="submitting", submitted_at=now())
                try:
                    submission = await backend.submit(Path(job["local_path"]), job_id=job_id)
                except Exception as exc:
                    raise SkillError("BACKEND_SUBMIT_FAILED", "Submission failed; confirm backend state before retrying.") from exc
                # No await between receiving the task ID and committing it.
                repository.update(job_id, backend_task_id=submission.task_id, status="polling")
            job["backend_task_id"] = submission.task_id
            if capacity_changed:
                await capacity_changed(job_id)
        repository.update(job_id, status="polling")
        result = await poll_until_finished(job, backend, repository, settings, capacity_changed)
        job["result_received_at"] = now()
        repository.update(job_id, status="result_received", normalized_result_json=result.model_dump_json(),
                          result_received_at=job["result_received_at"])
    repository.update(job_id, status="generating_documents")
    try:
        if job.get("output_directory_name"):
            output_dir = settings.work_dir / job["output_directory_name"]
            if output_dir.resolve().parent != settings.work_dir.resolve():
                raise ValueError("Invalid persisted output directory")
        else:
            # Rows created before the per-recording directory layout retain the
            # original batch directory so document-only recovery stays idempotent.
            output_dir = settings.work_dir / job["batch_id"]
        transcript, summary = renderer(job, result, output_dir)
    except Exception as exc:
        raise SkillError("DOCX_GENERATION_FAILED", "Could not generate Word documents; the result is saved.") from exc
    repository.update(job_id, status="completed", transcript_docx_path=str(transcript.resolve()),
                      summary_docx_path=str(summary.resolve()), completed_at=now(),
                      error_code=None, error_message=None, error_stage=None, resume_stage=None,
                      backend_error_code=None, http_status=None)


async def run_workers(jobs, backend, repository, settings, renderer):
    if not jobs:
        return  # Completed-only resume must not poll unrelated older batches.
    requested_batches = {j["batch_id"] for j in jobs}
    # Recover compatible existing remote tasks first, including older batches.
    # An unknown task ID/other credential identity stays a blocker, never replayed.
    selected = {j["job_id"]: j for j in jobs}
    for job in repository.remote_active_jobs(settings.backend_mode):
        if not job["backend_task_id"] or job["backend_mode"] != settings.backend_mode:
            continue
        try:
            repository.verify_identity([job], settings.backend_mode, getattr(backend, "binding", None),
                                       getattr(backend, "compatible_bindings", ()))
        except SkillError:
            continue
        selected.setdefault(job["job_id"], job)
    jobs = sorted(selected.values(), key=lambda j: not bool(j["backend_task_id"]))
    condition = asyncio.Condition()
    reserved, running = set(), set()
    pending_remote = {j["job_id"] for j in jobs if j["backend_task_id"]}

    async def capacity_changed(job_id):
        async with condition:
            if repository.job(job_id)["backend_task_id"]:
                # Durable occupancy now owns the slot; local result work must not
                # retain a second reservation after the remote task terminates.
                reserved.discard(job_id)
            condition.notify_all()

    async def admit(job):
        async with condition:
            pending_remote.discard(job["job_id"])
            if not job["backend_task_id"] and not job["normalized_result_json"]:
                while len({j["job_id"] for j in repository.remote_active_jobs(settings.backend_mode)} | reserved) >= 5:
                    if not running and not pending_remote:
                        raise SkillError("REMOTE_CAPACITY_WAITING", "Five unresolved remote tasks occupy capacity. Resume the blocking tasks before submitting this file.")
                    await condition.wait()
                # Claim before upload/authorization. Persisted import evidence takes
                # over this temporary reservation before any import request is sent.
                reserved.add(job["job_id"])
            running.add(job["job_id"])

    queue = asyncio.Queue()
    for job in jobs:
        queue.put_nowait(job)
    for _ in range(settings.worker_count):
        queue.put_nowait(None)

    async def worker():
        while True:
            job = await queue.get()
            try:
                if job is None:
                    return
                # The protection budget applies to this execution attempt. Explicit
                # recovery grants a fresh budget without resubmitting an existing task.
                remaining = settings.max_job_wall_time_seconds
                try:
                    await admit(job)
                    async with asyncio.timeout(remaining):
                        await process_job(job, backend, repository, settings, renderer, capacity_changed)
                except SkillError as exc:
                    repository.record_error(job["job_id"], exc)
                except TimeoutError:
                    repository.record_error(job["job_id"], SkillError(
                        "RECOVERY_REQUIRED", "Job time limit reached; its remote outcome is not cancelled or refunded."))
                except Exception:
                    # Avoid leaking URL query strings or backend payloads in exception messages.
                    frames = [(f.filename, f.lineno, f.name) for f in traceback.extract_tb(sys.exc_info()[2])]
                    logger.error("Unexpected job failure: batch=%s job=%s frames=%s", job["batch_id"], job["job_id"], frames)
                    stage = repository.job(job["job_id"])["status"]
                    code = "RECOVERY_REQUIRED" if stage in {"uploading", "authorizing", "importing", "authorized", "polling"} else "INTERNAL_ERROR"
                    repository.record_error(job["job_id"], SkillError(code, "Unexpected processing failure; saved state is retained."))
            finally:
                if job is not None:
                    async with condition:
                        reserved.discard(job["job_id"])
                        running.discard(job["job_id"])
                        condition.notify_all()
                queue.task_done()

    tasks = [asyncio.create_task(worker()) for _ in range(settings.worker_count)]
    try:
        await asyncio.gather(*tasks)
        await queue.join()
        for batch_id in {j["batch_id"] for j in jobs} - requested_batches:
            cleanup(repository, batch_id)
            repository.finalize(batch_id, settings.website_url)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


def cleanup(repository, batch_id):
    for job in repository.jobs(batch_id):
        if job["status"] in {"completed", "failed"} and job["is_temporary"] and job["local_path"]:
            try:
                Path(job["local_path"]).unlink(missing_ok=True)
            except OSError:
                logger.warning("Temporary-file cleanup deferred: job=%s", job["job_id"])


@asynccontextmanager
async def backend_session(settings, repository, backend=None, credentials=None, api_transport=None):
    if backend is not None:
        if getattr(backend, "mode", "mock") != settings.backend_mode:
            raise SkillError("RECOVERY_REQUIRED", "Configured mode does not match the supplied backend.")
        yield backend
    elif settings.backend_mode == "real":
        credentials = credentials or CredentialProvider(settings.api_base_url)
        async with QingfengClient(settings, credentials, api_transport) as client:
            yield RealBackendAdapter(client, repository)
    else:
        yield MockBackendAdapter()


async def prepare_jobs(inputs, jobs, repository, settings, attachment_resolver, transport):
    timeout = httpx.Timeout(settings.http_read_timeout, connect=settings.http_connect_timeout)
    # This client has no platform credentials, including when an API client is open.
    async with httpx.AsyncClient(timeout=timeout, transport=transport) as client:
        for item, job in zip(inputs, jobs):
            if job["status"] not in {"pending", "resolving", "validating"}:
                continue
            try:
                repository.update(job["job_id"], status="resolving")
                if job["is_temporary"] and job["local_path"] and Path(job["local_path"]).is_file():
                    from .models import ResolvedInput
                    resolved = ResolvedInput(original_source=job["original_source"], original_name=job["original_name"],
                                             local_path=Path(job["local_path"]), is_temporary=True)
                else:
                    async with asyncio.timeout(settings.input_prepare_timeout_seconds):
                        resolved = await resolve_input(item, client, settings, attachment_resolver)
                repository.update(job["job_id"], status="validating", local_path=str(resolved.local_path),
                                  is_temporary=int(resolved.is_temporary), original_name=resolved.original_name)
                validation = validate_audio_file(resolved.local_path, settings)
                stem = sanitize_filename(Path(resolved.original_name.replace("\\", "/")).stem)
                if job["output_directory_name"]:
                    candidate = job["output_directory_name"]
                elif job["output_stem"]:
                    # A populated legacy stem with no directory field belongs to
                    # the former batch-directory layout and must not be reassigned.
                    candidate = job["output_stem"]
                else:
                    candidate = repository.assign_output_directory(job["job_id"], stem)
                repository.update(job["job_id"], status="queued", output_stem=candidate,
                                  validation_json=validation.model_dump_json())
            except TimeoutError:
                repository.record_error(job["job_id"], SkillError("INPUT_PREPARATION_TIMEOUT",
                    "Input download/materialization exceeded its total time limit; partial downloads were removed.", stage="resolving"))
            except SkillError as exc:
                repository.record_error(job["job_id"], exc)
            except Exception:
                repository.fail(job["job_id"], "INTERNAL_ERROR", "Could not prepare this input.")


@exclusive_workdir
async def run_skill(inputs, settings=None, backend=None, attachment_resolver=None,
                    renderer=render_documents, transport=None, credentials=None, api_transport=None):
    settings = settings or Settings()
    settings.work_dir = validate_work_dir(settings.work_dir)
    repository = Repository(settings.work_dir / "skill_state.sqlite3")
    batch_id = repository.create_batch(inputs, backend_mode=settings.backend_mode)
    try:
        async with backend_session(settings, repository, backend, credentials, api_transport) as active:
            for job in repository.jobs(batch_id):
                repository.update(job["job_id"], identity_binding=getattr(active, "binding", None))
            await prepare_jobs(inputs, repository.jobs(batch_id), repository, settings,
                               attachment_resolver or MockAttachmentResolver(), transport)
            await run_workers([j for j in repository.jobs(batch_id) if j["status"] == "queued"],
                              active, repository, settings, renderer)
    except SkillError as exc:
        for job in repository.jobs(batch_id):
            if job["status"] not in {"completed", "failed"} | BLOCKED:
                repository.record_error(job["job_id"], exc)
    finally:
        try:
            cleanup(repository, batch_id)
            result = repository.finalize(batch_id, settings.website_url)
        finally:
            repository.close()
    return result


@exclusive_workdir
async def resume_incomplete_jobs(batch_id, settings=None, backend=None, renderer=render_documents,
                                 credentials=None, api_transport=None, transport=None):
    settings = settings or Settings()
    settings.work_dir = validate_work_dir(settings.work_dir)
    repository = Repository(settings.work_dir / "skill_state.sqlite3")
    try:
        if not repository.connection.execute("SELECT 1 FROM batches WHERE batch_id=?", (batch_id,)).fetchone():
            raise SkillError("RECOVERY_REQUIRED", "Unknown batch ID.")
        async with backend_session(settings, repository, backend, credentials, api_transport) as active:
            jobs = repository.jobs(batch_id)
            repository.verify_identity(jobs, settings.backend_mode, getattr(active, "binding", None),
                                       getattr(active, "compatible_bindings", ()))
            for job in jobs:
                if job["status"] == "completed" or job["error_code"] in TERMINAL_ERROR_CODES:
                    continue
                if job["identity_binding"] != getattr(active, "binding", None):
                    repository.update(job["job_id"], identity_binding=getattr(active, "binding", None))
                stage = job["resume_stage"] or job["status"]
                if job["status"] == "recovery_required" and not job["backend_task_id"] and not job["normalized_result_json"]:
                    # No reconciliation API is documented. Do not silently clear this gate.
                    continue
                if job["status"] in {"waiting_credentials", "waiting_entitlement", "waiting_poll", "waiting_capacity"}:
                    repository.update(job["job_id"], status=stage, error_code=None, error_message=None,
                                      error_stage=None, resume_stage=None)
                if job["backend_task_id"]:
                    repository.update(job["job_id"], status="polling", error_code=None, error_message=None)
                if job["normalized_result_json"]:
                    repository.update(job["job_id"], status="result_received", error_code=None, error_message=None)
            jobs = repository.jobs(batch_id)
            inputs = [AudioInput(source_type=j["source_type"], value=j["original_source"], display_name=j["original_name"]) for j in jobs]
            await prepare_jobs(inputs, jobs, repository, settings, MockAttachmentResolver(), transport)
            resumable = []
            for job in repository.jobs(batch_id):
                if job["status"] in {"completed", "failed"} | BLOCKED:
                    continue
                if settings.backend_mode == "mock" and not job["backend_task_id"] and not job["normalized_result_json"] and job["status"] != "queued":
                    repository.record_error(job["job_id"], SkillError("RECOVERY_REQUIRED", "An interrupted submission requires review."))
                else:
                    resumable.append(job)
            await run_workers(resumable, active, repository, settings, renderer)
        return repository.finalize(batch_id, settings.website_url)
    finally:
        cleanup(repository, batch_id)
        repository.close()
