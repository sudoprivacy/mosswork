"""Load and persist the Qingfeng API key in the skill-root .env file."""
import hashlib

from .models import SkillError
from .environment import DotEnvCredentialStore


class CredentialProvider:
    def __init__(self, api_base_url, api_key=None, credential_file=None):
        self.credential_file = credential_file if credential_file is not None else DotEnvCredentialStore()
        self._injected_api_key = api_key
        self._active_api_key = None
        self.key_reference = "api:" + hashlib.sha256(api_base_url.encode()).hexdigest()

    def get_api_key(self):
        persisted = self.credential_file.load()[0] if self._injected_api_key is None and self._active_api_key is None else None
        key = self._injected_api_key or self._active_api_key or persisted
        if not key or not key.strip():
            raise SkillError("CREDENTIALS_REQUIRED", "Obtain and configure an API Key at https://www.qingfengyq.com/.")
        if any(c.isspace() or ord(c) < 32 for c in key):
            raise SkillError("AUTHENTICATION_FAILED", "The configured API Key contains whitespace.")
        return key

    def configure(self, key, *, switch_account=False):
        if not key or any(c.isspace() or ord(c) < 32 for c in key):
            raise SkillError("AUTHENTICATION_FAILED", "Enter a nonempty API Key without whitespace.")
        previous = set()
        if not switch_account:
            try:
                old_key = self.get_api_key()
                previous = self.compatible_bindings(old_key) | {self.binding(old_key)}
            except SkillError as exc:
                if exc.code not in {"CREDENTIALS_REQUIRED", "AUTHENTICATION_FAILED", "CREDENTIAL_FILE_READ_FAILED"}:
                    raise
        metadata = {"key_reference": self.key_reference, "binding": self.binding(key),
                    "previous_bindings": sorted(previous - {self.binding(key)})}
        destination = self.credential_file.save(key, metadata)
        self._injected_api_key = None
        self._active_api_key = key
        return {"status": "configured", "destination": destination,
                "accountMode": "switch" if switch_account else "same_account",
                "message": "API key saved and active for the skill.",
                "recoveryMessage": ("Existing tasks retain their original account binding. Select the intended account on the website."
                                    if switch_account else "Saved task IDs and file authorization references are preserved. Same-account ownership is assumed, not server-verified.")}

    def compatible_bindings(self, api_key):
        if self._injected_api_key is not None:
            return set()
        key, metadata = self.credential_file.load()
        if (key != api_key or metadata.get("key_reference") != self.key_reference
                or metadata.get("binding") != self.binding(api_key)):
            return set()
        values = metadata.get("previous_bindings", [])
        return {value for value in values if isinstance(value, str) and len(value) == 64} if isinstance(values, list) else set()

    def binding(self, api_key):
        return hashlib.sha256((self.key_reference + ":" + api_key).encode()).hexdigest()
