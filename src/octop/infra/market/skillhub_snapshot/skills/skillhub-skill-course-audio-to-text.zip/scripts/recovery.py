"""Explicit release of the recovery gate for a file whose remote write is unconfirmed.

When the platform never confirms the outcome of a paid remote write -- an
upload, a quota reservation or an import -- the file stops in
``recovery_required``. The skill cannot guess whether the remote side charged
the user or created anything, and replaying the write would risk charging
twice, so the file waits.

This module is the only way out. The user states on the record what they
verified on the platform, and the skill applies exactly that:

``--remote-task-id``
    The remote task exists and the user read its identifier from the
    platform. The identifier is bound to the file so the skill polls that
    existing task. Nothing is uploaded, authorized or charged again.

``--confirm-abandoned``
    The remote operation produced nothing usable -- no task was created and
    the previous quota reservation did not take effect. The gate is cleared
    and the file is re-armed from the last checkpoint that is still valid.

The acknowledgement is deliberately not a blanket "try again": every branch
reuses whatever the previous attempt already paid for, so an acknowledgement
can never turn into a second charge.
"""
from datetime import datetime, timezone

from .credentials import CredentialProvider
from .models import SkillError, validate_work_dir
from .ownership import exclusive_workdir
from .repository import Repository, needs_acknowledgement

RESOLUTION_REMOTE_TASK = "remote_task"
RESOLUTION_ABANDONED = "abandoned"


def _authorization_usable(job):
    """True when a saved authorization code can still be redeemed.

    A live code means the quota for this file was already reserved, so the
    import may be retried with it and no second reservation is needed.
    """
    from .real_backend import expiry

    if not job["auth_code"]:
        return False
    try:
        expires_at = expiry(job["auth_expires_at"])
    except (TypeError, ValueError):
        return False
    return expires_at > datetime.now(timezone.utc)


def _upload_usable(job):
    """True when the uploaded file may still be reused.

    An unknown expiry is treated as usable: the platform, not this skill, is
    the authority on whether the identifier is still valid, and a rejected
    upload is reported as such instead of being silently retried.
    """
    from .real_backend import expiry

    if not job["file_id"]:
        return False
    try:
        expires_at = expiry(job["file_expires_at"])
    except (TypeError, ValueError):
        return True
    return expires_at > datetime.now(timezone.utc)


@exclusive_workdir
async def acknowledge_recovery(batch_id, settings, *, job_ids=None,
                               remote_task_id=None, confirm_abandoned=False):
    """Release the recovery gate for the files a user has verified.

    Returns a summary of what was acknowledged and the command that continues
    the batch. It never contacts the platform.
    """
    if bool(remote_task_id) == bool(confirm_abandoned):
        raise SkillError("RECOVERY_ACK_INVALID",
                         "Choose exactly one of --remote-task-id or --confirm-abandoned.")
    if remote_task_id is not None and not str(remote_task_id).strip():
        raise SkillError("RECOVERY_ACK_INVALID", "The remote task identifier must not be empty.")
    if remote_task_id is not None:
        from .real_backend import valid_id
        try:
            remote_task_id = valid_id(remote_task_id)
        except ValueError:
            raise SkillError("RECOVERY_ACK_INVALID",
                             "The remote task identifier is not a usable task ID.") from None

    settings.work_dir = validate_work_dir(settings.work_dir)
    repository = Repository(settings.work_dir / "skill_state.sqlite3")
    try:
        known = repository.connection.execute(
            "SELECT batch_id FROM batches WHERE batch_id=?", (batch_id,)).fetchone()
        if known is None:
            raise SkillError("RECOVERY_REQUIRED", "Unknown batch ID.")

        jobs = repository.jobs(batch_id)
        targets = [job for job in jobs if needs_acknowledgement(job)]
        if job_ids:
            wanted = {str(value) for value in job_ids}
            selected = [job for job in targets if job["job_id"] in wanted]
            missing = wanted - {job["job_id"] for job in selected}
            if missing:
                raise SkillError("RECOVERY_ACK_INVALID",
                                 "These files are not waiting for a manual confirmation: "
                                 + ", ".join(sorted(missing)))
            targets = selected
        if not targets:
            raise SkillError("RECOVERY_ACK_INVALID",
                             "No file in this batch is waiting for a manual confirmation.")

        # The acknowledgement names a remote outcome, so it must belong to the
        # same account and API deployment that produced the file. The mode comes
        # from the batch itself, so the operator does not have to repeat it.
        mode = targets[0]["backend_mode"]
        provider = CredentialProvider(settings.api_base_url)
        if mode == "real":
            key = provider.get_api_key()
            binding, compatible = provider.binding(key), provider.compatible_bindings(key)
        else:
            # A simulated batch has no account identity to verify.
            binding, compatible = None, ()
        repository.verify_identity(targets, mode, binding, compatible)

        acknowledged = []
        for job in targets:
            if remote_task_id is not None:
                repository.update(
                    job["job_id"], backend_task_id=str(remote_task_id).strip(), status="polling",
                    error_code=None, error_message=None, error_stage=None,
                    resume_stage=None, completed_at=None)
                acknowledged.append({
                    "jobId": job["job_id"], "fileName": job["original_name"],
                    "resolution": RESOLUTION_REMOTE_TASK, "taskId": str(remote_task_id).strip(),
                    "charged": False,
                    "message": "The remote task is attached. The next resume only queries it; nothing is uploaded or charged again.",
                })
                continue

            upload_usable = _upload_usable(job)
            authorization_usable = _authorization_usable(job)
            fields = {
                "status": "queued", "error_code": None, "error_message": None,
                "error_stage": None, "resume_stage": None, "completed_at": None,
                "import_attempts": 0, "import_failures": 0, "submitted_at": None,
            }
            if not upload_usable:
                # The file is uploaded again, so the authorization issued for the
                # previous upload cannot be redeemed against the new file ID.
                fields.update(file_id=None, server_duration=None, file_expires_at=None,
                              auth_code=None, auth_reference=None,
                              auth_expires_at=None, auth_expire_seconds=None)
            elif not authorization_usable:
                # The upload survives, so only the authorization grant is dropped
                # and a fresh one is requested for the same file.
                fields.update(auth_code=None, auth_reference=None,
                              auth_expires_at=None, auth_expire_seconds=None)
            repository.update(job["job_id"], **fields)
            acknowledged.append({
                "jobId": job["job_id"], "fileName": job["original_name"],
                "resolution": RESOLUTION_ABANDONED,
                "charged": bool(job["billing_state"] == "reserved" and not authorization_usable),
                "reusedAuthorization": authorization_usable,
                "reusedUpload": upload_usable,
                "message": ("The previous remote operation is confirmed abandoned. The file is re-armed "
                            "from the last checkpoint that is still valid."),
            })

        summary = repository.finalize(batch_id, settings.website_url)
        return {
            "status": "acknowledged", "batchId": batch_id,
            "acknowledged": acknowledged, "items": summary["items"],
            "nextCommand": f"--resume {batch_id} --backend {settings.backend_mode}",
        }
    finally:
        repository.close()
