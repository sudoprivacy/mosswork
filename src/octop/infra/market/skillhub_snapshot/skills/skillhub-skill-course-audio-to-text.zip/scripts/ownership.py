"""Nonblocking process ownership for the state database, released by the OS."""
from contextlib import contextmanager
from functools import wraps
from inspect import signature
import os

from .models import Settings, SkillError, validate_work_dir


@contextmanager
def work_directory_lock(work_dir):
    database = (work_dir / "skill_state.sqlite3").resolve()
    database.parent.mkdir(parents=True, exist_ok=True)
    # Never unlink this file: another process may already have opened its inode.
    with (database.parent / (database.name + ".lock")).open("a+b") as handle:
        if os.name == "nt":
            import msvcrt
            handle.seek(0, 2)
            if not handle.tell():
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            acquire = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            release = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            acquire = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            release = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        try:
            acquire()
        except OSError:
            raise SkillError("WORK_DIRECTORY_BUSY", "Another instance owns this work directory. Wait for it to finish before running or resuming.") from None
        try:
            yield
        finally:
            release()


def exclusive_workdir(function):
    """Guard public execution entry points before they open or mutate SQLite."""
    parameters = signature(function)

    @wraps(function)
    async def owned(*args, **kwargs):
        arguments = parameters.bind(*args, **kwargs)
        settings = arguments.arguments.get("settings") or Settings()
        # Validate before locking: taking the lock creates the work directory,
        # so a forbidden path must be refused before anything is written.
        settings.work_dir = validate_work_dir(settings.work_dir)
        with work_directory_lock(settings.work_dir):
            return await function(*args, **kwargs)
    return owned
