"""Keep HTTP-library diagnostics safe only within this skill's sensitive calls."""
from contextvars import ContextVar
from functools import wraps
from inspect import iscoroutinefunction
import logging
from threading import Lock

import httpx

_sensitive = ContextVar("recording_transcription_smart_meeting_sensitive_http", default=False)
_installation_lock = Lock()
_installed = False


def _install():
    global _installed
    with _installation_lock:
        if _installed:
            return
        previous = logging.getLogRecordFactory()

        def safe_record(*args, **kwargs):
            record = previous(*args, **kwargs)
            if not _sensitive.get() or record.name.split(".")[0] not in {"httpx", "httpcore"}:
                return record
            # HTTPcore DEBUG may include request/response headers or exception
            # representations. Do not attempt to enumerate credential names.
            message, values = "Sensitive HTTP transport diagnostic omitted.", ()
            if (record.name == "httpx" and record.msg == 'HTTP Request: %s %s "%s %d %s"'
                    and isinstance(record.args, tuple) and len(record.args) == 5):
                try:
                    url = httpx.URL(record.args[1]).copy_with(query=None, fragment=None, userinfo=b"")
                    message = "HTTP Request: %s %s (status=%s)"
                    values = (record.args[0], str(url), record.args[3])
                except (ValueError, TypeError):
                    pass
            record.msg, record.args = message, values
            record.exc_info = record.exc_text = record.stack_info = None
            return record

        # Chain the host's factory; unrelated libraries and concurrent operations
        # retain their original records, levels, handlers, and logging behavior.
        logging.setLogRecordFactory(safe_record)
        _installed = True


def sensitive_http(function):
    @wraps(function)
    async def asynchronous(*args, **kwargs):
        _install()
        token = _sensitive.set(True)
        try:
            return await function(*args, **kwargs)
        finally:
            _sensitive.reset(token)

    @wraps(function)
    def synchronous(*args, **kwargs):
        _install()
        token = _sensitive.set(True)
        try:
            return function(*args, **kwargs)
        finally:
            _sensitive.reset(token)
    return asynchronous if iscoroutinefunction(function) else synchronous
