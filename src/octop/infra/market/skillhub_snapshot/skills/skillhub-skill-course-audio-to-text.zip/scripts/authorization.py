"""File-specific authorization reserves quota; it is not a balance query."""
import json
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

from .models import SkillError, validate_work_dir
from .repository import TERMINAL_ERROR_CODES, now
from .real_backend import ISSUE, expiry
from .ownership import exclusive_workdir


class FileAuthorizationService:
    def __init__(self, client, repository):
        self.api = client
        self.repository = repository

    async def authorize_file(self, job_id):
        job = self.repository.job(job_id)
        self.repository.verify_identity([job], "real", self.api.binding, self.api.compatible_bindings)
        if not job["file_id"]:
            raise SkillError("AUTHORIZATION_FAILED", "Authorization requires an uploaded file ID.")
        if job["backend_task_id"]:
            raise SkillError("AUTHORIZATION_FAILED", "This file has already been imported; resume its query instead.")
        if job["status"] in {"authorizing", "importing", "recovery_required"}:
            raise SkillError("RECOVERY_REQUIRED", "Verify the previous authorization/import operation before requesting another code.")
        if job["import_attempts"] >= self.api.settings.import_attempt_limit:
            raise SkillError("RECOVERY_REQUIRED", "The existing authorization has no remaining import attempts.")
        if job["auth_code"]:
            try:
                expires_at = expiry(job["auth_expires_at"])
            except (ValueError, TypeError):
                raise SkillError(
                    "RECOVERY_REQUIRED",
                    "The existing authorization expiry cannot be verified; the saved code was retained and no new code was requested.",
                ) from None
            if expires_at <= datetime.now(timezone.utc):
                # A valid backend expiry timestamp has definitively elapsed.
                self.repository.update(job_id, auth_code=None)
                raise SkillError("RECOVERY_REQUIRED", "The existing authorization is expired; no new code was requested.")
            return self._public_result(job)
        if job["auth_reference"]:
            raise SkillError(
                "RECOVERY_REQUIRED",
                "This task references authorization stored by an older client, but the code is not present in SQLite; no new code was requested.",
            )
        if len(self.repository.remote_active_jobs("real")) >= 5:
            raise SkillError("REMOTE_CAPACITY_WAITING", "Five unresolved remote tasks occupy capacity; no new authorization was requested.")
        try:
            # This committed marker is both the local-write preflight and the durable
            # ambiguity gate. If the following paid request has an unknown outcome,
            # restart recovery cannot silently issue a second authorization.
            self.repository.update(job_id, status="authorizing", authorization_started_at=now())
        except Exception:
            raise SkillError("LOCAL_STATE_UNAVAILABLE", "Local task state is not writable; no paid authorization was requested.", stage="authorizing") from None
        try:
            payload = await self.api.request(ISSUE, stage="authorizing", json={
                "skill_id": self.api.settings.skill_id, "tool_ids": [self.api.settings.tool_id],
                "context": {"file_id": job["file_id"]},
            })
        except SkillError as exc:
            if exc.code in {"INSUFFICIENT_QUOTA", "AUTHENTICATION_FAILED"}:
                self.repository.update(job_id, status="uploaded")
            raise
        # Accept the documented envelope variants (root or "data").
        envelope = payload.get("data") if isinstance(payload.get("data"), dict) else payload
        # IC-03/IC-04: a successful issue already reserves quota, so the code and every field
        # needed to recover are persisted before the response is judged against the strict
        # schema. An unexpected or newly added field must never discard the code.
        code = envelope.get("auth_code")
        if not isinstance(code, str) or not code or any(c.isspace() for c in code):
            raise SkillError("RECOVERY_REQUIRED", "Authorization may have reserved quota without returning a usable code; verify it before retrying.", stage="authorizing")
        try:
            expires_at = expiry(envelope["expires_at"])
        except (KeyError, TypeError, ValueError):
            expires_at = None
        # expire_seconds is optional: a server that publishes only expires_at is accepted, and
        # a derived lifetime stays internal bookkeeping rather than a billing figure.
        seconds = envelope.get("expire_seconds")
        if type(seconds) is not int or not 0 < seconds <= 2592000:
            seconds = self._derived_expiry_seconds(expires_at)
        reference = f"auth:{self.api.binding}:{job_id}"
        try:
            self.api._secrets.add(code)
            self.repository.update(job_id, auth_reference=reference, auth_code=code,
                                   auth_expires_at=expires_at.isoformat() if expires_at else None,
                                   auth_expire_seconds=seconds,
                                   billing_json=json.dumps(self._billing_metadata(envelope)),
                                   billing_state="reserved", status="authorized", authorized_at=now())
        except Exception:
            raise SkillError("RECOVERY_REQUIRED", "Authorization was issued but could not be saved reliably; verify it before retrying.", stage="authorizing") from None
        if expires_at is None or expires_at <= datetime.now(timezone.utc):
            # The code is saved above, so this stays recoverable instead of being discarded.
            raise SkillError("RECOVERY_REQUIRED", "The issued authorization was saved but its expiry cannot be verified; verify it before importing.", stage="authorizing")
        return self._public_result(self.repository.job(job_id))

    @staticmethod
    def _derived_expiry_seconds(expires_at):
        """Lifetime implied by expires_at; internal only and never presented as billed quota."""
        if expires_at is None:
            return None
        remaining = int((expires_at - datetime.now(timezone.utc)).total_seconds())
        return remaining if 0 < remaining <= 2592000 else None

    def _billing_metadata(self, envelope):
        """Sanitized scalar billing and reservation fields; unusable values are omitted."""
        billing = {}
        for key in ("deduct_value", "pre_deduct_amount"):
            if key in envelope:
                try:
                    amount = Decimal(str(envelope[key]))
                except (InvalidOperation, TypeError, ValueError):
                    continue
                if amount.is_finite() and amount >= 0:
                    billing[key] = str(amount)
        for key in ("billing_status", "settlement_source", "platform_transaction_id"):
            value = envelope.get(key)
            if isinstance(value, str) and value.strip():
                billing[key] = self.api.safe_text(" ".join(value.split()))[:128]
        return billing

    @staticmethod
    def _public_result(job):
        return {"jobId": job["job_id"], "fileId": job["file_id"], "status": "authorized",
                "expiresAt": job["auth_expires_at"], "expireSeconds": job["auth_expire_seconds"],
                "billing": json.loads(job["billing_json"] or "{}"),
                "message": "Authorization reserves quota. This is not a read-only entitlement check."}


@exclusive_workdir
async def authorize_file(file_id, settings, credentials=None, api_transport=None, file_name=None):
    """Standalone persisted authorization, reusable by subsequent batch recovery.

    A successful call reserves quota. Repeated calls reuse the same saved grant.
    No authorization code is returned in the public result.
    """
    from .credentials import CredentialProvider
    from .inputs import sanitize_filename
    from .models import AudioInput
    from .real_backend import QingfengClient, valid_id
    from .repository import Repository

    if settings.backend_mode != "real":
        raise SkillError("AUTHORIZATION_FAILED", "Standalone authorization requires real mode.")
    file_id = valid_id(file_id)
    repository = Repository(validate_work_dir(settings.work_dir) / "skill_state.sqlite3")
    try:
        provider = credentials or CredentialProvider(settings.api_base_url)
        async with QingfengClient(settings, provider, api_transport) as client:
            existing = repository.connection.execute(
                "SELECT job_id FROM jobs WHERE backend_mode='real' AND file_id=? ORDER BY rowid DESC LIMIT 1",
                (file_id,)).fetchone()
            if existing:
                job = repository.job(existing[0])
                repository.verify_identity([job], "real", client.binding, client.compatible_bindings)
                batch_id = job["batch_id"]
                if job["status"] in {"waiting_entitlement", "waiting_credentials", "waiting_capacity"}:
                    repository.update(job["job_id"], status=job["resume_stage"] or "uploaded",
                                      error_code=None, error_message=None, resume_stage=None)
            else:
                name = file_name or file_id
                batch_id = repository.create_batch([AudioInput(value=file_id, display_name=name)],
                                                   backend_mode="real", identity_binding=client.binding)
                job = repository.jobs(batch_id)[0]
                output_name = repository.assign_output_directory(
                    job["job_id"], sanitize_filename(Path(name.replace("\\", "/")).stem)
                )
                repository.update(job["job_id"], file_id=file_id, status="uploaded",
                                  output_stem=output_name, uploaded_at=now())
            try:
                result = await FileAuthorizationService(client, repository).authorize_file(job["job_id"])
                return {"batchId": batch_id, **result}
            except SkillError as exc:
                # Command rejection must not demote a confirmed terminal task.
                current = repository.job(job["job_id"])
                if current["status"] != "completed" and current["error_code"] not in TERMINAL_ERROR_CODES:
                    repository.record_error(job["job_id"], exc)
                return {"batchId": batch_id, "jobId": job["job_id"], "status": "failed",
                        "errorCode": exc.code, "errorMessage": str(exc),
                        "actions": repository.finalize(batch_id, settings.website_url)["actions"]}
    finally:
        repository.close()
