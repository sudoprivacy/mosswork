"""Local audio batch workflow with an explicitly simulated backend."""
