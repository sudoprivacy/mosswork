import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit
from uuid import uuid4

from .models import SkillError
from .login import credential_action

BLOCKED = {"waiting_entitlement", "waiting_credentials", "waiting_poll", "recovery_required", "waiting_capacity"}
# Codes that confirm the backend reached a final business state for the imported task.
TERMINAL_ERROR_CODES = {"BACKEND_TASK_FAILED"}


def needs_acknowledgement(job):
    """True when a blocked job cannot be resumed and needs a human decision.

    A job blocked in ``recovery_required`` has an unverified remote outcome:
    the platform never confirmed whether the paid write took effect. The
    resume path deliberately refuses to replay such a job, so it reports it as
    awaiting acknowledgement rather than as resumable.
    """
    if job["status"] != "recovery_required":
        return False
    # A saved task identifier means the remote task is known and can be
    # polled; a saved result means only the documents are missing.
    return not job["backend_task_id"] and not job["normalized_result_json"]


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Repository:
    """Short synchronous transactions never yield to another asyncio worker."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA foreign_keys=ON")
        self.connection.executescript("""
        CREATE TABLE IF NOT EXISTS batches (
            batch_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, finished_at TEXT,
            status TEXT NOT NULL, total_count INTEGER NOT NULL,
            success_count INTEGER NOT NULL DEFAULT 0, failed_count INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS jobs (
            job_id TEXT PRIMARY KEY, batch_id TEXT NOT NULL REFERENCES batches(batch_id),
            source_type TEXT NOT NULL, original_source TEXT NOT NULL, original_name TEXT NOT NULL,
            local_path TEXT, is_temporary INTEGER DEFAULT 0, validation_json TEXT,
            status TEXT NOT NULL, backend_task_id TEXT, created_at TEXT NOT NULL,
            submitted_at TEXT, last_polled_at TEXT, poll_count INTEGER DEFAULT 0,
            result_received_at TEXT, completed_at TEXT, normalized_result_json TEXT,
            transcript_docx_path TEXT, summary_docx_path TEXT, output_stem TEXT,
            error_code TEXT, error_message TEXT);
        """)
        columns = {r[1] for r in self.connection.execute("PRAGMA table_info(jobs)")}
        additions = {
            "backend_mode": "TEXT NOT NULL DEFAULT 'mock'", "identity_binding": "TEXT",
            "file_id": "TEXT", "server_duration": "REAL", "file_expires_at": "TEXT",
            "upload_started_at": "TEXT", "uploaded_at": "TEXT", "authorization_started_at": "TEXT",
            "authorized_at": "TEXT", "auth_reference": "TEXT", "auth_code": "TEXT", "auth_expires_at": "TEXT",
            "auth_expire_seconds": "INTEGER", "billing_json": "TEXT", "billing_state": "TEXT",
            "import_attempts": "INTEGER NOT NULL DEFAULT 0", "import_failures": "INTEGER NOT NULL DEFAULT 0",
            "last_import_at": "TEXT", "resume_stage": "TEXT", "error_stage": "TEXT",
            "backend_error_code": "TEXT", "http_status": "INTEGER",
            "result_diagnostic_json": "TEXT", "output_directory_name": "TEXT",
        }
        with self.connection:
            for name, definition in additions.items():
                if name not in columns:
                    self.connection.execute(f"ALTER TABLE jobs ADD COLUMN {name} {definition}")

    def create_batch(self, inputs, *, backend_mode="mock", identity_binding=None):
        batch_id = str(uuid4())
        with self.connection:
            self.connection.execute("INSERT INTO batches(batch_id,created_at,status,total_count) VALUES(?,?,?,?)",
                                    (batch_id, now(), "running", len(inputs)))
            for item in inputs:
                self.connection.execute("""INSERT INTO jobs(job_id,batch_id,source_type,original_source,
                    original_name,status,created_at) VALUES(?,?,?,?,?,?,?)""",
                    (str(uuid4()), batch_id, item.source_type, item.value,
                    item.display_name or Path(unquote(urlsplit(item.value).path) if item.source_type == "url"
                                               else item.value).name, "pending", now()))
            self.connection.execute("UPDATE jobs SET backend_mode=?,identity_binding=? WHERE batch_id=?",
                                    (backend_mode, identity_binding, batch_id))
        return batch_id

    def update(self, job_id, **fields):
        allowed = {r[1] for r in self.connection.execute("PRAGMA table_info(jobs)")}
        if not fields or not fields.keys() <= allowed - {"job_id", "batch_id"}:
            raise ValueError("Invalid job update")
        with self.connection:
            self.connection.execute(f"UPDATE jobs SET {','.join(k + '=?' for k in fields)} WHERE job_id=?",
                                    (*fields.values(), job_id))

    def jobs(self, batch_id):
        return [dict(row) for row in self.connection.execute("SELECT * FROM jobs WHERE batch_id=? ORDER BY rowid", (batch_id,))]

    def job(self, job_id):
        row = self.connection.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        if row is None:
            raise ValueError("Unknown job ID")
        return dict(row)

    def assign_output_directory(self, job_id, preferred_name):
        """Persist one user-visible directory name for a new job.

        The work-directory ownership lock serializes callers. The database value
        is the recovery source of truth; existing filesystem directories are also
        reserved so a new task never publishes into an unrelated folder.
        """
        job = self.job(job_id)
        if job["output_directory_name"]:
            return job["output_directory_name"]
        used = {row[0].casefold() for row in self.connection.execute(
            "SELECT output_directory_name FROM jobs WHERE output_directory_name IS NOT NULL"
        )}
        try:
            used.update(path.name.casefold() for path in self.path.parent.iterdir() if path.is_dir())
        except OSError:
            pass
        candidate, index = preferred_name, 1
        while candidate.casefold() in used:
            index += 1
            candidate = f"{preferred_name} ({index})"
        with self.connection:
            self.connection.execute(
                "UPDATE jobs SET output_directory_name=?,output_stem=? WHERE job_id=?",
                (candidate, candidate, job_id),
            )
        return candidate

    def remote_active_jobs(self, backend_mode=None):
        """Rebuild conservative occupancy from durable evidence across all batches.

        An ambiguous import retains a slot even without a task ID. Definitively
        rejected attempts do not. Authorization alone never creates a remote task.
        Admission supplies a mode so simulated tasks cannot occupy real slots.
        """
        active = []
        for row in self.connection.execute("SELECT * FROM jobs ORDER BY rowid"):
            job = dict(row)
            if backend_mode is not None and job["backend_mode"] != backend_mode:
                continue
            if (job["status"] == "completed" or job["normalized_result_json"]
                    or job["result_received_at"] or job["error_code"] in TERMINAL_ERROR_CODES):
                continue
            stage = job["resume_stage"] or job["status"]
            ambiguous_import = (job["submitted_at"] and
                job["error_code"] not in {"BACKEND_REQUEST_REJECTED", "AUTHENTICATION_FAILED", "BACKEND_IMPORT_FAILED"}
                and (stage in {"importing", "submitting"} or
                     job["import_attempts"] > job["import_failures"]))
            if job["backend_task_id"] or ambiguous_import:
                active.append(job)
        return active

    def record_error(self, job_id, error):
        job = self.job(job_id)
        if error.code == "REMOTE_CAPACITY_WAITING":
            state = "waiting_capacity"
        elif error.code == "INSUFFICIENT_QUOTA":
            state = "waiting_entitlement"
        elif error.code in {"CREDENTIALS_REQUIRED", "AUTHENTICATION_FAILED"}:
            state = "waiting_credentials"
        elif error.code == "BACKEND_POLL_UNAVAILABLE":
            # The imported task is untouched; only its read failed.
            state = "waiting_poll"
        elif error.code == "RESULT_INVALID" and (error.stage or job["status"]) == "polling":
            # An unusable query response is a read-level problem, not a task-level failure.
            state = "waiting_poll"
        elif error.code == "RECOVERY_REQUIRED":
            state = "recovery_required"
        else:
            state = "failed"
        stage = job["resume_stage"] if job["status"] in BLOCKED else job["status"]
        self.update(job_id, status=state, resume_stage=stage, error_stage=error.stage or stage,
                    error_code=error.code, error_message=str(error), completed_at=now(),
                    backend_error_code=error.backend_code, http_status=error.http_status)

    def verify_identity(self, jobs, mode, binding, compatible_bindings=()):
        for job in jobs:
            stage = job["resume_stage"] or job["status"]
            safe_to_rebind = (not job["file_id"] and not job["auth_reference"] and not job["auth_code"]
                              and not job["backend_task_id"]
                              and stage in {"pending", "resolving", "validating", "queued"})
            if job["backend_mode"] != mode or (job["identity_binding"] and job["identity_binding"] not in {binding, *compatible_bindings} and not safe_to_rebind):
                raise SkillError("RECOVERY_REQUIRED", "Recovery requires the original backend, API deployment and credential identity.")

    def fail(self, job_id, code, message):
        self.update(job_id, status="failed", error_code=code, error_message=message, completed_at=now())

    def finalize(self, batch_id, website_url="https://www.qingfengyq.com/"):
        jobs = self.jobs(batch_id)
        succeeded = sum(j["status"] == "completed" for j in jobs)
        failed = sum(j["status"] == "failed" or j["status"] in BLOCKED for j in jobs)
        blocked = sum(j["status"] in BLOCKED for j in jobs)
        quota = sum(j["status"] == "waiting_entitlement" for j in jobs)
        recovery_jobs = [j for j in jobs if j["status"] == "recovery_required"]
        actions = []
        if any(j["status"] == "waiting_capacity" for j in jobs):
            actions.append({"type": "resume_capacity", "message": "Remote task capacity is occupied. Recover the blocking tasks, then resume this batch; waiting files have not started new remote operations.",
                            "blockers": [{"jobId": j["job_id"], "batchId": j["batch_id"],
                                          "taskId": j["backend_task_id"], "status": j["status"]}
                                         for j in self.remote_active_jobs(jobs[0]["backend_mode"])]})
        if quota:
            message = f"当前剩余额度不足以处理这些文件。请前往 [清风官网]({website_url}) 充值，完成后回复‘已充值’，我会从保存的进度继续处理。"
            if succeeded:
                message += "已完成的文件会保留。"
            actions.append({"type": "recharge", "url": website_url, "message": message})
        if any(j["status"] == "waiting_credentials" for j in jobs):
            actions.append(credential_action(website_url))
        if any(j["status"] == "waiting_poll" for j in jobs):
            actions.append({"type": "resume_polling",
                            "message": "The result query could not be completed. Resume later to keep polling the saved task; no new authorization or charge is needed."})
        if recovery_jobs:
            actions.append({"type": "review_recovery",
                            "message": "Verify the saved remote operation before retrying; no refund is confirmed. "
                                       "Confirm the remote task ID to attach it, or confirm the operation was abandoned to run the file again.",
                            "items": [{"jobId": j["job_id"], "batchId": j["batch_id"],
                                       "fileName": j["original_name"], "status": j["status"],
                                       "requiresAcknowledgement": needs_acknowledgement(j),
                                       "taskId": j["backend_task_id"],
                                       "acknowledgeCommand": f"--ack-recovery {batch_id} --remote-task-id <远端任务ID> --job {j['job_id']}",
                                       "abandonCommand": f"--ack-recovery {batch_id} --confirm-abandoned --job {j['job_id']}"}
                                      for j in recovery_jobs]})
        status = ("running" if succeeded + failed < len(jobs) else
                  "completed" if succeeded == len(jobs) else "partial_success" if succeeded else "failed")
        with self.connection:
            self.connection.execute("UPDATE batches SET status=?,success_count=?,failed_count=?,finished_at=? WHERE batch_id=?",
                                    (status, succeeded, failed, None if status == "running" else now(), batch_id))
        return {"batchId": batch_id, "status": status, "total": len(jobs), "succeeded": succeeded,
                "failed": failed, "blocked": blocked, "quotaBlocked": quota, "actions": actions,
                "items": [{"jobId": j["job_id"], "fileName": j["original_name"],
                    "status": j["status"], "transcriptDocx": j["transcript_docx_path"],
                    "summaryDocx": j["summary_docx_path"], "errorCode": j["error_code"],
                    "errorMessage": j["error_message"], "errorStage": j["error_stage"],
                    "backendCode": j["backend_error_code"], "httpStatus": j["http_status"],
                    # Recovery work that costs nothing stays available: a blocked state, a saved
                    # result whose documents still need rendering, or an imported task that can be
                    # re-queried. A completed job has no pending work left, and a backend-confirmed
                    # terminal state has none either.
                    #
                    # A job whose remote outcome is unknown is different: the resume path refuses
                    # to replay it, so it must not be advertised as resumable. It waits for a human
                    # decision, reported separately as requiresAcknowledgement.
                    "resumable": (not needs_acknowledgement(j)
                                  and (j["status"] in BLOCKED
                                       or bool(j["normalized_result_json"] and j["status"] != "completed")
                                       or bool(j["backend_task_id"] and j["status"] != "completed"
                                               and j["error_code"] not in TERMINAL_ERROR_CODES))),
                    "requiresAcknowledgement": needs_acknowledgement(j)}
                    for j in jobs]}

    def close(self):
        self.connection.close()
