"""Shared presentation rules for both recording exports."""

from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

FONT_NAME = "Microsoft YaHei"
DARK_BLUE = "1F4E79"
BLUE = "2F75B5"
BLACK = "000000"
GRAY = "666666"
BORDER_COLOR = "D9D9D9"
BORDER_SIZE = 8  # OOXML eighth-points: 1 pt.

DOC_TITLE_STYLE = "Title"
MODULE_HEADING_STYLE = "Heading 1"
SPEAKER_HEADING_STYLE = "Heading 2"
SUMMARY_LEVEL_1_STYLE = "Summary Level 1"
SUMMARY_LEVEL_2_STYLE = "Summary Level 2"
BODY_STYLE = "Normal"
META_STYLE = "Recording Metadata"
TRANSCRIPT_LABEL_STYLE = "Transcript Label"

# size, bold, color, before, after, line spacing, keep with next
STYLE_SPECS = {
    BODY_STYLE: (12, False, BLACK, 0, 3, 1.15, False),
    DOC_TITLE_STYLE: (19, True, DARK_BLUE, 0, 14, 1.0, True),
    MODULE_HEADING_STYLE: (17.5, True, DARK_BLUE, 16, 8, 1.0, True),
    SPEAKER_HEADING_STYLE: (16, True, BLUE, 14, 6, 1.0, True),
    SUMMARY_LEVEL_1_STYLE: (16, True, BLUE, 14, 6, 1.0, True),
    SUMMARY_LEVEL_2_STYLE: (13.5, True, BLUE, 10, 4, 1.0, True),
    META_STYLE: (11, False, GRAY, 0, 6, 1.5, False),
    TRANSCRIPT_LABEL_STYLE: (11, False, GRAY, 0, 6, 1.5, True),
}


def configure_styles(document):
    for name, spec in STYLE_SPECS.items():
        style = (document.styles[name] if name in document.styles
                 else document.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH))
        if name != BODY_STYLE:
            style.base_style = document.styles[BODY_STYLE]
        size, bold, color, before, after, spacing, keep = spec
        style.font.name = FONT_NAME
        style.font.size = Pt(size)
        style.font.bold = bold
        style.font.italic = False
        style.font.color.rgb = RGBColor.from_string(color)
        fonts = style.element.get_or_add_rPr().get_or_add_rFonts()
        for attribute in list(fonts.attrib):
            if "theme" in attribute.lower():
                del fonts.attrib[attribute]
        for attribute in ("ascii", "hAnsi", "eastAsia"):
            fonts.set(qn("w:" + attribute), FONT_NAME)
        paragraph = style.paragraph_format
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        paragraph.first_line_indent = Pt(0)
        paragraph.space_before = Pt(before)
        paragraph.space_after = Pt(after)
        paragraph.line_spacing = spacing
        paragraph.keep_with_next = keep
        paragraph.widow_control = True
        # Templates can carry decorative rules (notably below Title).
        # Chapter rules belong only to the paragraphs created by the renderer.
        for border in style.element.xpath('./w:pPr/w:pBdr'):
            border.getparent().remove(border)


def add_top_border(paragraph):
    properties = paragraph._p.get_or_add_pPr()
    borders = properties.find(qn("w:pBdr"))
    if borders is None:
        borders = OxmlElement("w:pBdr")
        properties.append(borders)
    top = borders.find(qn("w:top"))
    if top is None:
        top = OxmlElement("w:top")
        borders.append(top)
    for name, value in {"val": "single", "sz": str(BORDER_SIZE),
                        "color": BORDER_COLOR, "space": "6"}.items():
        top.set(qn("w:" + name), value)
