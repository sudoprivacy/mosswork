#!/usr/bin/env python3
"""Label a hairstyle preview image with a Chinese name + note bar at the bottom.

Usage:
    python label_haircut.py <input_image> "<中文名>" "<副标>" <output_image>

Example:
    python label_haircut.py gen.png "前刺" "不烫好打理" label_前刺.png
"""
import sys
import os
from PIL import Image, ImageDraw, ImageFont


def find_font(size):
    """Pick a Chinese-capable font, cross-platform best-effort."""
    candidates = [
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttf",
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
    ]
    for p in candidates:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size, index=0)
            except Exception:
                try:
                    return ImageFont.truetype(p, size)
                except Exception:
                    continue
    return ImageFont.load_default()


def main():
    if len(sys.argv) != 5:
        print("Usage: python label_haircut.py <input> <中文名> <副标> <output>")
        sys.exit(1)

    inp, cn, sub, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
    img = Image.open(inp).convert("RGBA")
    w, h = img.size
    draw = ImageDraw.Draw(img)

    bar_h = int(h * 0.12)
    draw.rectangle([0, h - bar_h, w, h], fill=(15, 15, 18, 195))

    cn_font = find_font(int(h * 0.058))
    sub_font = find_font(int(h * 0.033))
    draw.text((26, h - bar_h + 16), cn, font=cn_font, fill=(255, 255, 255, 255))
    draw.text((28, h - bar_h + 16 + int(h * 0.058) + 6), sub, font=sub_font, fill=(205, 205, 210, 255))

    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    img.convert("RGB").save(out, "PNG")
    print("saved", out)


if __name__ == "__main__":
    main()
