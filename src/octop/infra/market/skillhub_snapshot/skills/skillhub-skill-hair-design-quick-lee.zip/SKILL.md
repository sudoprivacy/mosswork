---
name: skillhub-skill-hair-design-quick-lee
description: "从单张人像照片生成多种发型的 AI 试戴预览图。当用户上传人像或自拍，想看自己（或照片中的人）换不同发型的效果、在理发前对比选项，或需要一张带清晰标注的参考图时使用。技能会自动识别照片中人物的性别，主动推荐 2 款合适发型供确认，并允许从发型库中选择其他发型，再产出多张真实感的换发效果图，每张底部标注发型名称（中文 + 英文 + 如「不烫好打理」等提示）。覆盖男士发型 20+ 款、女士发型 16 款，从短发、碎盖、纹理烫到个性前卫款式均有。"
---

# Hairstyle Preview (发型预览)

Turn one portrait photo into a set of labeled, realistic hairstyle try-on images so the user can compare options before a haircut.

## When to use
- User uploads a portrait/selfie and asks "what hairstyle suits me", "try a different haircut", "show me some hairstyles", or wants a reference image to show a barber.
- User wants to compare several hairstyles side by side, each clearly named.

## Workflow

### 1. Receive the photo
Obtain the portrait image path from the user. A front-facing, clearly-lit photo works best.

### 2. Detect gender (NEW)
Determine whether the subject is **male (男)** or **female (女)** BEFORE picking styles — the recommended library differs by gender.
- **Vision path (preferred):** If the current model can see images, look at the photo and decide the gender directly from visual cues (hair length aside, judge facial features / bone structure / presentation). State the conclusion briefly, e.g. "识别为男生".
- **Fallback path:** If the model cannot view images in this environment, DO NOT guess. Ask the user once: "这张照片里是男生还是女生？" and wait for the answer. Never assume.
- Record the decided gender; all subsequent style picks and recommendations come from the matching section of `references/hairstyles.md` (男士发型 / 女士发型).

### 3. Proactively recommend 2 styles + confirm (NEW)
Read `references/hairstyles.md`, open the section for the detected gender, and pick **2 styles** the agent judges most suitable based on the visible face shape (round / square / long / oval) and hair type (coarse / fine / curly). State the recommendation concisely with a one-line reason each.

Then use `AskUserQuestion` to confirm before any image generation:
- Use **multiSelect: true** so the user can pick any combination.
- Options (up to 4): the **2 recommended styles** first (mark them clearly, e.g. label "(推荐)"), plus 1–2 other popular styles from the same-gender library as quick alternates.
- The tool auto-provides an "Other" free-text field — tell the user they can type any style name from the library there (or just name it in chat).
- Keep the pre-generation chat short. Do NOT generate until the user confirms the selection.

If the user names specific styles up front (e.g. "生成前刺和狼尾"), skip the recommendation step and generate only those.

### 4. Generate images (image-to-image)
For each confirmed style, call the ImageGen tool with:
- `image`: [user photo path]
- `input_fidelity`: "0.85"
- `size`: "1024x1024"
- `quality`: "high"
- `prompt`: the style's English prompt copied from `references/hairstyles.md` (prompts already include the correct gender wording — "a man" / "a woman" — and the common studio prefix)
- `output_dir`: a working directory, e.g. `<workspace>/generated-images`

CRITICAL — avoid filename collisions:
- ImageGen derives the output filename from the prompt + timestamp. Generating multiple images in the same second (parallel calls) can overwrite each other.
- Generate ONE image at a time, sequentially. After each call, capture the returned `localPath` before starting the next.

### 5. Label each image
For every generated image, run the labeling script:
```
python <skill_dir>/scripts/label_haircut.py <generated_image_path> "<中文名>" "<副标>" <output_path>
```
- `<中文名>`: the style's Chinese name (e.g. `前刺` / `空气刘海锁骨发`)
- `<副标>`: the style's note (e.g. `不烫好打理` / `需纹理烫`)
- `<output_path>`: a clear filename containing the style key, e.g. `<workspace>/generated-images/label_前刺.png`

The script draws a semi-transparent bottom bar with the Chinese name + note and saves the labeled copy. It auto-selects a Chinese-capable font (macOS: Hiragino Sans GB / PingFang; Linux: Noto Sans CJK).

### 6. Present
Call `present_files` with all labeled image paths so the user can compare them in one view.

### 7. Advise (recommended)
After presenting, give a short recommendation based on the user's face shape and hair type, and offer a barber/ stylist script (length, layers, bangs, perm) for the chosen style. Mention that these are AI references — a real cut will differ, but direction / length / layers are reproducible.

## Notes
- ImageGen costs ~5-10 credits per image. Inform the user before generating (total = count × 5-10).
- **Gender drives the library:** men's styles live under `### 男士发型`; women's under `### 女士发型`. Always pick from the correct section.
- Round faces: keep some fringe to lengthen the face; very short crops that fully expose the forehead suit longer faces or full hairlines.
- Coarse / unruly hair: prefer natural-texture styles over stiff uniform spikes; tell the barber not to straighten.
- The labeling script requires Pillow. If missing, install into the managed venv: `pip install Pillow`.
