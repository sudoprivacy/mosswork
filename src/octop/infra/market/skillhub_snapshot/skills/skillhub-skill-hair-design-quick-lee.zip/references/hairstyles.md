# 发型库 / Hairstyle Library

每种发型包含：中文名、英文名、图底副标、关键特征、以及用于 ImageGen 图生图的英文 prompt。

**两个分区**（按性别选择，不要混用）：
- `### 男士发型`（下方第一节）
- `### 女士发型`（下方第二节）

**通用前缀**：`realistic photograph, high quality, sharp focus, neutral light grey background, soft studio lighting.`
- 男士 prompt 前缀：`Professional portrait of a man, `
- 女士 prompt 前缀：`Professional portrait of a woman, `
生成时把对应前缀 + 风格描述全文复制传给 ImageGen 即可（图生图会保留原图的脸型与五官）。

---

### 1. 前刺 (textured-crop)
- 中文名: 前刺
- 英文名: Textured Crop
- 副标: 不烫好打理
- 特征: 头顶 5-6cm，两侧渐变，刘海向前向上的刺感，硬发质出效果最好
- prompt: Modern textured crop with NO perm, natural black hair: sides faded very short with a clean low taper, top left medium 5-6cm with layered texture, fringe cut short and textured styled forward and slightly upward into separated spiky points, matte finish, some forehead visible, youthful trendy look.

### 2. 美式短碎 (short-textured-crop)
- 中文名: 美式短碎
- 英文名: Short Textured Crop
- 副标: 不烫好打理
- 特征: 头顶 3-4cm，比前刺更短更硬朗，两侧接近青皮
- prompt: American short textured crop with NO perm, natural black hair: sides faded very short to near skin with a sharp taper, top left short 3-4cm cut into choppy texture, fringe styled forward into separated short spikes, matte finish, some forehead visible, hardy sharp youthful look.

### 3. 碎盖短发 (tousled-crop)
- 中文名: 碎盖短发
- 英文名: Tousled Crop
- 副标: 不烫好打理
- 特征: 头顶 5-6cm，刘海自然碎散、不刻意分缝，最随手
- prompt: Modern tousled crop with NO perm, natural black hair: sides faded short with a low taper, top left medium 5-6cm with soft layered texture, fringe cut into natural scattered pieces falling loosely and casually across the forehead without a defined part line, matte finish, effortless casual look.

### 4. 美式渐变寸头 (high-and-tight-fade)
- 中文名: 美式渐变寸头
- 英文名: High-and-Tight Fade
- 副标: 不烫好打理
- 特征: 头顶 1-2cm，两侧推光渐变，零打理；圆脸慎选（显脸圆）
- prompt: Clean American high-and-tight fade with NO perm, natural black hair: sides and back faded down to bare skin with a sharp gradient, top left very short 1-2cm, hair lying flat and natural with a slight forward direction, no styling products, athletic hard-man look.

### 5. 韩式微分碎盖 (korean-two-block)
- 中文名: 韩式微分碎盖
- 英文名: Korean Two-Block
- 副标: 需纹理烫
- 特征: 头顶 8-10cm，微分刘海，通常需纹理烫才出蓬松感
- prompt: Korean two-block haircut, natural black hair: sides faded short with a clean low taper, top left longer 8-10cm with layered texture, fringe parted slightly off-center in a loose curtain style falling naturally across the forehead with airy separated strands, matte finish. (Usually needs a texture perm for volume.)

### 6. 侧分 Undercut (side-part-undercut)
- 中文名: 侧分 Undercut
- 英文名: Side-Part Undercut
- 副标: 易显老(成熟)
- 特征: 头顶 5-6cm，侧分服帖，硬朗但偏成熟
- prompt: Side-part undercut with NO perm, natural black hair: sides faded very short with a sharp taper, top left medium 5-6cm combed into a tidy side-part with a hard part line, hair lies naturally flat and smooth, slightly matte, sharp masculine look.

### 7. 飞机头 (quiff)
- 中文名: 飞机头
- 英文名: Quiff
- 副标: 不烫可选
- 特征: 头顶 6-8cm，前上吹蓬，比油头蓬松年轻、比前刺更正式
- prompt: Modern quiff with NO perm, natural black hair: sides faded short with a taper, top left 6-8cm swept up and back into height and volume at the front, matte finish, confident look.

### 8. 逗号刘海 (comma-fringe)
- 中文名: 逗号刘海
- 英文名: Comma Fringe
- 副标: 不烫好打理
- 特征: 刘海往一侧带弧形成逗号状，复古潮感
- prompt: Comma-fringe crop with NO perm, natural black hair: sides faded short with a low taper, top left 5-6cm, fringe swept to one side with a curved comma shape, matte textured, stylish look.

### 9. 中分碎盖 (center-part-crop)
- 中文名: 中分碎盖
- 英文名: Center-Part Crop
- 副标: 不烫好打理
- 特征: 中分碎刘海，自然随意
- prompt: Center-part textured crop with NO perm, natural black hair: sides faded short with a low taper, top left 5-6cm, fringe parted in the middle and scattered naturally, matte casual look.

### 10. 法式短发 (french-crop)
- 中文名: 法式短发
- 英文名: French Crop
- 副标: 不烫好打理
- 特征: 头顶 4-5cm，齐短刘海向前，干净利落
- prompt: French crop with NO perm, natural black hair: sides faded short with a taper, top left 4-5cm, a straight short fringe cut blunt across the forehead, matte, neat look.

### 11. 三七分 (side-swept)
- 中文名: 三七分
- 英文名: Side-Swept
- 副标: 不烫好打理
- 特征: 头顶 6-7cm，三七分流向一侧，干净
- prompt: Side-swept crop with NO perm, natural black hair: sides faded short with a taper, top left 6-7cm, hair side-swept in a 3:7 ratio with a loose fringe, matte, clean look.

### 12. 圆寸 (buzz-cut)
- 中文名: 圆寸
- 英文名: Buzz Cut
- 副标: 零打理
- 特征: 全头均匀极短 3-6mm，无渐变，最省事；考验头型
- prompt: Uniform buzz cut with NO perm, natural black hair: entire head clipped very short and even at 3-6mm, no fade, hair lying flat, no products, athletic minimal look.

### 13. 纹理烫短发 (wavy-texture-perm)
- 中文名: 纹理烫短发
- 英文名: Wavy Texture Perm
- 副标: 需纹理烫
- 特征: 头顶剪碎 + 纹理烫增加蓬松，发量少/细软适用
- prompt: Wavy textured perm crop, natural black hair: top cut into layers with a soft wavy texture perm for volume, sides faded short with a taper, matte voluminous look. (Requires a perm.)

### 14. 背头 (slicked-back)
- 中文名: 背头
- 英文名: Slicked Back
- 副标: 成熟(易显老)
- 特征: 全往后梳服帖，成熟气场
- prompt: Slicked-back look with NO perm, natural black hair: sides faded short with a taper, top hair combed straight back and flat with a matte pomade, no fringe, mature sharp look.

### 15. 狼尾 (wolf-cut)
- 中文名: 狼尾
- 英文名: Wolf Cut
- 副标: 个性不烫
- 特征: 顶侧短、后颈留长层次，前卫
- prompt: Wolf cut with NO perm, natural black hair: short on top and sides, long layered lengths left at the back and nape, textured and edgy, trendy look.

### 16. 现代鲻鱼头 (modern-mullet)
- 中文名: 现代鲻鱼头
- 英文名: Modern Mullet
- 副标: 个性不烫
- 特征: 顶侧短、后略长但克制，比狼尾收敛
- prompt: Modern subtle mullet with NO perm, natural black hair: top and sides kept short, back slightly longer but understated, textured, edgy yet wearable look.

### 17. 日系栗子头 (japanese-short)
- 中文名: 日系栗子头
- 英文名: Japanese Short
- 副标: 不烫好打理
- 特征: 顶部圆润短 4-5cm，柔和干净
- prompt: Japanese short crop with NO perm, natural black hair: top rounded and short 4-5cm, sides faded short, soft natural finish, neat cute look.

### 18. 莫西干 (mohawk)
- 中文名: 莫西干
- 英文名: Mohawk
- 副标: 个性
- 特征: 两侧推光，中间留条立起，张扬
- prompt: Mohawk with NO perm, natural black hair: sides shaved or faded down to the skin, a center strip left long 6-10cm styled upward, bold daring look.

### 19. 刺猬头 (spiky)
- 中文名: 刺猬头
- 英文名: Spiky
- 副标: 不烫好打理
- 特征: 全头向前上抓刺，活力
- prompt: Spiky crop with NO perm, natural black hair: top left 4-5cm, all hair pushed up into short separated spikes, matte, energetic look.

### 20. 港风短碎 (hongkong-textured)
- 中文名: 港风短碎
- 英文名: Hong Kong Textured
- 副标: 复古潮
- 特征: 微卷自然纹理碎盖，复古潮流感
- prompt: Hong-Kong-style textured crop with NO perm, natural black hair: sides faded short, top left 5-6cm with a slightly wavy natural texture, retro trendy look.

---

## 选型速查（按脸型 / 需求）

- 圆脸想显脸长：前刺、美式短碎、碎盖短发、飞机头（保留头顶高度，别推太光）
- 硬发质不顺：前刺、碎盖短发、美式短碎（自然纹理，别拉直）
- 最省事零打理：美式渐变寸头、圆寸（但圆脸慎选寸头）
- 细软/发量少：纹理烫短发、韩式微分碎盖（靠烫出蓬松）
- 想年轻不显老：避开侧分 Undercut、背头

---

### 女士发型 (women's section)

女士 prompt 统一前缀：`Professional portrait of a woman, realistic photograph, high quality, sharp focus, neutral light grey background, soft studio lighting.`

#### 21. 空气刘海锁骨发 (air-bangs-collarbone)
- 中文名: 空气刘海锁骨发
- 英文名: Air-Bangs Collarbone Hair
- 副标: 减龄·好打理
- 特征: 锁骨长度、轻薄空气刘海，发尾微内扣，清纯减龄
- prompt: Airy see-through bangs with collarbone-length hair, natural black hair, soft and youthful, slight inward curve at the ends, fresh look, no perm needed.

#### 22. 法式刘海中长发 (french-bangs-medium)
- 中文名: 法式刘海中长发
- 英文名: French Bangs Medium
- 副标: 法式慵懒
- 特征: 法式微风刘海 + 过肩中长发，随性chic
- prompt: French-style wispy bangs with medium-length hair past the shoulders, natural texture, effortlessly chic look.

#### 23. 齐肩内扣波波头 (inward-bob)
- 中文名: 齐肩内扣波波头
- 英文名: Inward-Curl Bob
- 副标: 显脸小·好打理
- 特征: 肩长波波头、发尾内扣，修饰脸型、易打理
- prompt: Shoulder-length bob with ends curved inward, soft bangs optional, neat and face-slimming, easy to maintain.

#### 24. 大波浪长卷 (big-waves-long)
- 中文名: 大波浪长卷
- 英文名: Big Wavy Long Curls
- 副标: 女人味·需烫
- 特征: 长发大卷，蓬松浪漫，靠烫/卷
- prompt: Long hair with big loose glamorous waves, voluminous and feminine, requires a perm or curling.

#### 25. 木马卷中长发 (horse-arch-curls)
- 中文名: 木马卷中长发
- 英文名: Horse-Arch Curls
- 副标: 蓬松·需烫
- 特征: 中长发木马卷，蓬松复古，显发量
- prompt: Medium-length hair with horse-arch style big curls for volume, retro glam look, requires perm.

#### 26. 八字刘海高层次 (curtain-bangs-layered)
- 中文名: 八字刘海高层次
- 英文名: Curtain Bangs Layered
- 副标: 修饰颧骨·不烫
- 特征: 八字刘海向外翻、高层次中长发，修饰颧骨显脸小
- prompt: Curtain bangs (figure-8 parted bangs) with layered medium-length hair, bangs sweep outward to frame the face and slim the cheeks, no perm needed.

#### 27. 辛芷蕾发型 (xinzhilei-shag)
- 中文名: 辛芷蕾发型
- 英文名: Xin-Zhilei Shag
- 副标: 慵懒高级·不烫
- 特征: 八字刘海 + 厚重层次，慵懒高级感
- prompt: Xin-Zhilei-style shag: curtain fringe with heavy layers through the length, effortless high-fashion lazy look, no perm needed.

#### 28. 黑长直 (long-straight)
- 中文名: 黑长直
- 英文名: Long Straight Black
- 副标: 清纯·好打理
- 特征: 过肩黑长直，中/偏分，清纯简单
- prompt: Long straight black hair past the shoulders, clean center or side part, pure and simple, easy care.

#### 29. 精灵短发 (pixie)
- 中文名: 精灵短发
- 英文名: Pixie Cut
- 副标: 个性利落
- 特征: 两侧后脑推短、头顶略长带纹理，利落前卫
- prompt: Short pixie cut, very short on the sides and back, slightly longer textured top, bold and low-maintenance, edgy look.

#### 30. 日系狼尾(女) (female-wolf-cut)
- 中文名: 日系狼尾(女)
- 英文名: Female Wolf Cut
- 副标: 个性·不烫
- 特征: 顶侧短、后颈留长层次，女版狼尾前卫
- prompt: Female wolf cut: short textured top and sides, long layered lengths left at the back and nape, edgy trendy look, no perm.

#### 31. 公主切 (hime-cut)
- 中文名: 公主切
- 英文名: Hime Cut
- 副标: 二次元·个性
- 特征: 长直发 + 脸侧齐鬓角 + 齐刘海，动漫感
- prompt: Hime cut: straight long hair with blunt frontal sidelocks framing the face and blunt bangs, anime-inspired, distinctive look.

#### 32. 羊毛卷 (wool-roll-perm)
- 中文名: 羊毛卷
- 英文名: Wool-Roll Perm
- 副标: 显发量·需烫
- 特征: 细密小卷，蓬松显发量，俏皮
- prompt: Tight small curly perm (wool-roll), voluminous and adds hair volume, playful, requires perm.

#### 33. 蛋卷头 (egg-roll-perm)
- 中文名: 蛋卷头
- 英文名: Egg-Roll Perm
- 副标: 甜美·需烫
- 特征: 中长发均匀小 S 卷，甜美
- prompt: Egg-roll perm: uniform small S-waves through medium-length hair, sweet and cute, requires perm.

#### 34. 齐刘海妹妹头 (blunt-bangs-bob)
- 中文名: 齐刘海妹妹头
- 英文名: Blunt-Bangs Bob
- 副标: 减龄可爱
- 特征: 齐刘海 + 下巴长度短波波，可爱减龄
- prompt: Short bob with blunt straight bangs, cute and youthful, jaw-length, neat look.

#### 35. 慵懒微卷中长 (lazy-waves)
- 中文名: 慵懒微卷中长
- 英文名: Lazy Tousled Waves
- 副标: 日常·不烫
- 特征: 中长发自然微卷，日常随意
- prompt: Medium-length hair with lazy tousled natural waves, effortless everyday look, no perm needed.

#### 36. 女版鲻鱼头 (female-mullet)
- 中文名: 女版鲻鱼头
- 英文名: Female Mullet
- 副标: 前卫·不烫
- 特征: 顶侧短、后略长但克制，女版mullet
- prompt: Female mullet: short top and sides, longer at the back but understated, edgy yet wearable, no perm.

---

## 女士选型速查（按脸型 / 需求）

- 圆脸想显脸小：八字刘海高层次、辛芷蕾、齐肩内扣波波头（用刘海/层次拉长）
- 方脸想柔化：大波浪长卷、木马卷、空气刘海锁骨发
- 发量少/细软想蓬松：羊毛卷、蛋卷头、木马卷（靠烫）
- 想个性不撞款：精灵短发、日系狼尾(女)、公主切、女版鲻鱼头
- 最省事好打理：黑长直、空气刘海锁骨发、慵懒微卷中长（不烫）

