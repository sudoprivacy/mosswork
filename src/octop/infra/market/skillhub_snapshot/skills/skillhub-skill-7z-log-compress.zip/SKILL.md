---
name: skillhub-skill-7z-log-compress
description: "Archive and clean up files by age with FastCopy on Windows. Use when the user asks to copy or move files older than N days from a source to a destination, then delete files older than M days in the destination, or to detect/install FastCopy. Do not use for generic robocopy/copy tasks that do not involve FastCopy."
---

# FastCopy 按时间归档 / 清理

用 FastCopy 完成“按文件年龄搬运 + 目标清理”的批处理式任务。这个技能源自用户的 `GMTCFastCopy.BAT`（用 `/cmd=move` + `/cmd=delete` 处理 `\\192.168.1.10\mes_ftp` 下的 `*.7z`），这里把它泛化成一个可复用的脚本。

一句话概括：把源路径中符合条件的文件（修改时间早于 N 天，可再按扩展名包含 / 排除过滤）拷贝或移动到目标路径；完成后，再在目标路径中删除修改时间早于 M 天的文件。

## 两种操作：拷贝 / 移动

- 拷贝（默认）：把源里符合条件的文件复制到目标，源文件保留。用户说“拷贝 / 复制 / 备份”时用这个。
- 移动：把源里符合条件的文件移动到目标，源文件不再保留。用户说“移动 / 搬走 / 转移”时用这个。

对应到 `-Mode`：拷贝用 `force_copy`（覆盖，默认）、`diff`（仅新增或大小 / 日期变化）、`noexist_only`（仅新增）；移动用 `move`。无论哪种操作，完成后都会再按 `-DeleteDays` 清理目标目录里的旧文件。

## 什么时候用

- 用户要求“先拷贝（或移动）N 天之前的文件，再在目标目录删除 M 天之前的文件”。
- 用户要求检查 FastCopy 是否安装、或静默安装 FastCopy。
- 明确要使用 FastCopy（而不是 robocopy / PowerShell Copy-Item）。

## 工作流程

1. 定位 `FastCopy.exe`（按顺序）：
   - `C:\Program Files\FastCopy\FastCopy.exe`
   - `C:\Program Files (x86)\FastCopy\FastCopy.exe`
   - `%LOCALAPPDATA%\FastCopy\FastCopy.exe`、`%LOCALAPPDATA%\Programs\FastCopy\FastCopy.exe`
   - PATH 里的 `FastCopy.exe`
   - 注册表卸载项（HKLM / WOW6432Node / HKCU）中 `DisplayName` 含 FastCopy 的 `InstallLocation` 或 `DisplayIcon`
2. 未找到时静默安装（优先 winget）：
   - 优先 `winget install --id FastCopy.FastCopy --exact --silent --accept-package-agreements --accept-source-agreements`（不带 `--version`，默认装最新版）。
   - winget 不可用或失败时，打开 https://fastcopy.net.cn/ 实时解析最新安装包链接（例如当前为 `https://fastcopy.jp/archive/FastCopy5.11.3_installer.exe`；页面发布新版后自动取新版，不要写死版本号），下载后 `/SILENT` 静默安装。
   - 官网链接也下载不了时（其安装包实际托管在 GitHub raw，国内可能连不上），改用镜像 `https://dforest.watch.impress.co.jp/library/f/fastcopy/11574/FastCopy5.12.0_installer.exe` 下载并 `/SILENT` 安装。
3. 调用脚本执行拷贝/搬运和清理。

脚本已经封装了上面的检测与安装逻辑，用 PowerShell 直接运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\fastcopy-archive.ps1" `
  -Source "\\192.168.1.10\mes_ftp\gmtcftp" `
  -Destination "D:\MES_FTP\gmtcftp" `
  -CopyDays 182 -DeleteDays 730 `
  -Include "*.7z" -Exclude "AssemblyLog.7z;test.7z"
```

包含 / 排除过滤（`-Include` / `-Exclude`）都是可选的，**默认是全部**：两个都不传就处理所有文件。常用写法：`-Include "*.7z" -Exclude "AssemblyLog.7z;test.7z"`。

只清理、不拷贝（`-SkipCopy`，此时不需要 `-Source` / `-CopyDays`）：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\fastcopy-archive.ps1" `
  -Destination "D:\MES_FTP\gmtcftp" -SkipCopy -DeleteDays 730 -Include "*.7z"
```

参数：

- `-Source` 源路径（拷贝/搬运的来源；`-SkipCopy` 时可省略）
- `-Destination` 目标路径（拷贝去向，也是清理对象，必填）
- `-CopyDays` 只处理修改时间早于 N 天的文件（`-SkipCopy` 时可省略）
- `-DeleteDays` 在目标里删除修改时间早于 N 天的文件；不填则需要 `-SkipDelete`
- `-Include` 包含过滤器（可选，默认全部、不过滤），如 `*.7z`
- `-Exclude` 排除过滤器（可选，默认不排除），多个用 `;` 分隔，如 `AssemblyLog.7z;test.7z`
- `-Mode` 操作模式：拷贝用 `force_copy`（覆盖，默认）/ `diff` / `noexist_only`；移动用 `move`（源文件会移走）
- `-SkipCopy` 跳过拷贝/搬运，只按 `-DeleteDays` 清理目标目录（此时不需要 `-Source` / `-CopyDays`）
- `-WhatIf` 只打印将执行的命令，不真正执行（先跑一次看效果）
- `-SkipDelete` 跳过删除步骤
- `-FastCopyPath` 手动指定 `FastCopy.exe`；`-NoInstall` 禁止自动安装；`-InstallerUrl` 手动指定安装包地址；`-LogDir` 日志目录

## 定时自动运行（Windows 计划任务）

脚本幂等：重复执行只会按“修改时间早于 N 天”的筛选再跑一遍，已处理过的文件不会重复拷贝 / 删除，一天跑几次也安全。建议每天固定时间跑一次。

```powershell
schtasks /create /tn "FastCopyArchive" /tr "powershell -NoProfile -ExecutionPolicy Bypass -File \"C:\Users\Roan\.codex\skills\fastcopy-archive\scripts\fastcopy-archive.ps1\" -Source \"\\192.168.1.10\mes_ftp\gmtcftp\" -Destination \"D:\MES_FTP\gmtcftp\" -CopyDays 182 -DeleteDays 730 -Include \"*.7z\" -Exclude \"AssemblyLog.7z;test.7z\"" /sc daily /st 08:00
```

说明：

- `/tn` 是任务名，`/sc daily /st 08:00` 表示每天 08:00 运行；把脚本绝对路径和 `-Source` / `-Destination` 等换成实际值。
- `/tr` 整条命令外层加双引号，内部的双引号用 `\"` 转义（示例已按此写法）。
- 默认以当前用户身份、仅在该用户登录时运行；若源是网络共享或需要无人值守，请改用有相应权限的账号，可加 `/ru 用户名 /rp 密码`，或在“任务计划程序”里勾选“不管用户是否登录都要运行”。
- 已有同名任务时加 `/f` 覆盖；删除任务用 `schtasks /delete /tn "FastCopyArchive" /f`。

## 日志位置

每次运行的 FastCopy 日志默认写到 `%TEMP%\fastcopy-archive-logs`，展开后是：

```text
C:\Users\<你的账号>\AppData\Local\Temp\fastcopy-archive-logs
```

例如账号名是 `Roan` 时就是 `C:\Users\Roan\AppData\Local\Temp\fastcopy-archive-logs`（**示例里的 `Roan` 换成你自己的 Windows 账号名**）。每次运行生成 `force_copy_<时间戳>.log`（拷贝/移动）和 `delete_<时间戳>.log`（删除）两类的日志文件。

想放到别的位置，运行时加 `-LogDir`，例如 `-LogDir "D:\MES_FTP\logs"`。

## FastCopy 命令行要点

- 模式值没有 `copy`：`/cmd=` 合法值为 `force_copy | diff | noexist_only | update | exist_diff | exist_update | sync | sync_update | move | move_noexist | delete | verify | verify_read | verify_check`。
- `/to_date=-ND` 选择修改时间早于 N 天的条目（BAT 里 `-182D`、`-730D` 就是这个）。
- `/include="*.7z"` 与 `/exclude="a.7z;b.7z"` 做包含/排除过滤，多个排除用 `;` 分隔。
- `/auto_close` 结束后自动关闭；`/log /logfile="..."` 写日志。
- 删除必须带 `/no_confirm_del`，否则会弹确认框卡住。更彻底的静默可用 `/no_ui`（会自动带出 `/no_confirm_del`、`/no_confirm_stop`、`/force_close`）。
- 想等待完成再继续：用 `Start-Process -Wait`（脚本已处理），或命令行里 `start "" /wait FastCopy.exe ...`。

## 安全

删除不可恢复。执行前必须确认 `-Destination` 与 `-DeleteDays` 正确，并且用户确实要求删除。先用 `-WhatIf` 预览命令，再真正执行。脚本在删除前会打印将要执行的完整命令。
