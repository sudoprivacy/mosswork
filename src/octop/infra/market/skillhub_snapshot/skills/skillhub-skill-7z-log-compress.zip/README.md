# FastCopy 按时间归档 / 清理

@fastcopy-archive

使用 FastCopy 在 Windows 上按文件年龄完成归档与清理：先检查 FastCopy 是否已安装（未安装时优先用 winget 静默安装，失败再从 fastcopy.net.cn 实时解析最新安装包并静默安装），然后把源路径中修改时间早于 N 天、且符合扩展名包含 / 排除条件的文件拷贝或移动到目标路径，最后在目标路径中删除修改时间早于 M 天的文件。支持计划任务每天定时自动运行。

两种操作：**拷贝**（默认，源文件保留）与 **移动**（源文件移走）。

当用户提出以下意图时触发：

- 用 FastCopy 拷贝 / 移动 N 天之前的文件
- 清理目标目录中 M 天之前的文件
- 检查 FastCopy 是否安装、静默安装 FastCopy
- 设置 FastCopy 定时归档 / 清理任务
- 按扩展名包含 / 排除过滤文件（例如只处理 `*.7z`）

v1.0.0

## 1 安装 / 使用

本技能已安装在本地 `C:\Users\Roan\.codex\skills\fastcopy-archive`，无需手动配置，说一句话即可触发（见第 3 节）。

## 2 核心脚本

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Roan\.codex\skills\fastcopy-archive\scripts\fastcopy-archive.ps1" `
  -Source "\\192.168.1.10\mes_ftp\gmtcftp" -Destination "D:\MES_FTP\gmtcftp" `
  -CopyDays 182 -DeleteDays 730 -Include "*.7z" -Exclude "AssemblyLog.7z;test.7z"
```

## 3 使用示例（⭐ 重要：教用户怎么“叫”技能出来用）

不用记命令行，说人话就能触发。一句话里只要带上“FastCopy / N 天前 / 归档 / 清理 / 拷贝 / 移动 / 删除 / 定时”等关键词，AI 就会自动调用本技能。下面是照着说就能用的例子，以及技能会做什么。

### 3.1 常规：拷贝 + 清理

你说：

> 用 FastCopy 把 `\\192.168.1.10\mes_ftp\gmtcftp` 里 182 天前的 `*.7z` 拷到 `D:\MES_FTP\gmtcftp`，再删掉那边 730 天前的。

技能做：检查 / 安装 FastCopy → 拷贝 182 天前的 `*.7z` → 删除目标里 730 天前的 `*.7z`。

### 3.2 只要拷贝，先不删

你说：

> 把 `D:\mes\gmtcftp` 里 90 天前的文件复制到 `E:\backup\gmtcftp`，先不要删。

技能做：只跑拷贝步骤，自动带 `-SkipDelete`。

### 3.3 移动：搬过去后源里不再保留

你说：

> 用 FastCopy 把 `D:\src` 里 3 天前的文件移到 `D:\dest`。

技能做：用 `-Mode move` 把源里 3 天前的文件移动到目标，源文件会被移除。

### 3.4 指定扩展名 + 排除

你说：

> 移动 90 天前的 `*.7z`，但排除 `AssemblyLog.7z` 和 `test.7z`。

技能做：用 `-Include "*.7z" -Exclude "AssemblyLog.7z;test.7z"`，模式为 `move`。

### 3.5 只清理，不拷贝

你说：

> 删除 `D:\MES_FTP\gmtcftp` 里 730 天前的 `*.7z`。

技能做：带 `-SkipCopy -DeleteDays 730 -Include "*.7z"`，跳过拷贝，只对目标目录执行删除（不需要 `-Source` / `-CopyDays`）：

`fastcopy-archive.ps1 -Destination "D:\MES_FTP\gmtcftp" -SkipCopy -DeleteDays 730 -Include "*.7z"`

### 3.6 首次使用：先预览再动手（推荐）

你说：

> 先看看会动哪些文件，别真删。

技能做：带 `-WhatIf` 运行，只打印将要执行的 FastCopy 命令，不真正拷贝 / 删除。

### 3.7 安装 FastCopy

你说：

> 帮我装 FastCopy。

技能做：先找已安装的 FastCopy；找不到就优先 `winget` 静默安装，失败再从 fastcopy.net.cn 下载最新版 `/SILENT` 安装。

### 3.8 设置定时任务

你说：

> 每天早上 8 点自动跑一次。

技能做：生成并注册 `schtasks` 计划任务（见第 5 节），或给你可直接执行的命令。

## 4 关键参数

- `-Source` 源路径（`-SkipCopy` 时可省略）
- `-Destination` 目标路径（必填，也是清理对象）
- `-CopyDays` 只处理修改时间早于 N 天的文件（`-SkipCopy` 时可省略）
- `-DeleteDays` 在目标里删除修改时间早于 N 天的文件
- `-Include` / `-Exclude` 扩展名包含 / 排除（可选，默认全部）
- `-Mode` 操作模式：拷贝用 `force_copy`（覆盖，默认）/ `diff` / `noexist_only`；移动用 `move`（源文件会移走）
- `-SkipCopy` 跳过拷贝，只清理目标目录（`-Source` / `-CopyDays` 可省略）；`-SkipDelete` 跳过删除
- `-WhatIf` 只预览命令不执行

## 5 定时任务（每天 08:00）

```powershell
schtasks /create /tn "FastCopyArchive" /tr "powershell -NoProfile -ExecutionPolicy Bypass -File \"C:\Users\Roan\.codex\skills\fastcopy-archive\scripts\fastcopy-archive.ps1\" -Source \"\\192.168.1.10\mes_ftp\gmtcftp\" -Destination \"D:\MES_FTP\gmtcftp\" -CopyDays 182 -DeleteDays 730 -Include \"*.7z\" -Exclude \"AssemblyLog.7z;test.7z\"" /sc daily /st 08:00
```

任务每次运行的日志同样保存在下面的默认日志目录里（见第 6 节）。

## 6 日志位置

默认日志目录：`%TEMP%\fastcopy-archive-logs`，展开后是：

```text
C:\Users\<你的账号>\AppData\Local\Temp\fastcopy-archive-logs
```

例如账号名是 `Roan` 时就是 `C:\Users\Roan\AppData\Local\Temp\fastcopy-archive-logs`（**示例里的 `Roan` 换成你自己的 Windows 账号名**）。每次运行会生成 `force_copy_<时间戳>.log`（拷贝 / 移动）和 `delete_<时间戳>.log`（删除）两类的日志文件。

想改到别的位置，运行时加 `-LogDir`，例如 `-LogDir "D:\MES_FTP\logs"`。
