<#
.SYNOPSIS
    FastCopy age-based copy/move + delete (archival) helper.

.DESCRIPTION
    Locates (and, if missing, silently installs) FastCopy on Windows, then:
      1. copies/moves files older than -CopyDays from -Source to -Destination,
      2. optionally deletes files older than -DeleteDays inside -Destination.

.EXAMPLE
    .\fastcopy-archive.ps1 -Source "\\server\share" -Destination "D:\archive" `
        -CopyDays 182 -DeleteDays 730 -Include "*.7z"
#>
[CmdletBinding()]
param(
    [string]$Source = '',
    [Parameter(Mandatory = $true)][string]$Destination,
    [ValidateRange(0, 365000)][int]$CopyDays = -1,
    [ValidateRange(0, 365000)][int]$DeleteDays = -1,
    [switch]$SkipCopy,
    [switch]$SkipDelete,
    [string]$Include = '',
    [string]$Exclude = '',
    [ValidateSet('force_copy', 'diff', 'update', 'noexist_only', 'move')][string]$Mode = 'force_copy',
    [string]$FastCopyPath = '',
    [switch]$NoInstall,
    [string]$InstallerUrl = '',
    [string]$LogDir = '',
    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'

function Write-Step {
    param([string]$Message)
    Write-Host $Message
}

function Get-FastCopyPath {
    $candidates = New-Object System.Collections.Generic.List[string]

    foreach ($p in @(
        (Join-Path $env:ProgramFiles 'FastCopy\FastCopy.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'FastCopy\FastCopy.exe'),
        (Join-Path $env:LOCALAPPDATA 'FastCopy\FastCopy.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\FastCopy\FastCopy.exe')
    )) {
        if ($p -and -not $candidates.Contains($p)) { $candidates.Add($p) }
    }

    $cmd = Get-Command 'FastCopy.exe' -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { $candidates.Insert(0, $cmd.Source) }

    $regRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $apps = foreach ($root in $regRoots) {
        Get-ItemProperty -Path $root -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like '*FastCopy*' }
    }
    foreach ($app in $apps) {
        if ($app.InstallLocation) {
            $candidates.Add((Join-Path $app.InstallLocation 'FastCopy.exe'))
        }
        if ($app.DisplayIcon) {
            $icon = ($app.DisplayIcon -split ',')[0].Trim('"')
            if ($icon -like '*FastCopy.exe') { $candidates.Add($icon) }
        }
    }

    foreach ($p in $candidates) {
        if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) {
            return (Resolve-Path -LiteralPath $p).Path
        }
    }
    return $null
}

function Compare-VersionString {
    param([string]$A, [string]$B)
    $a = @($A -split '\.' | ForEach-Object { $n = 0; [int]::TryParse($_, [ref]$n) | Out-Null; $n })
    $b = @($B -split '\.' | ForEach-Object { $n = 0; [int]::TryParse($_, [ref]$n) | Out-Null; $n })
    $len = [Math]::Max($a.Count, $b.Count)
    for ($i = 0; $i -lt $len; $i++) {
        $av = if ($i -lt $a.Count) { $a[$i] } else { 0 }
        $bv = if ($i -lt $b.Count) { $b[$i] } else { 0 }
        if ($av -ne $bv) { return ($av - $bv) }
    }
    return 0
}

function Resolve-InstallerUrl {
    param([string]$UserUrl)
    if ($UserUrl) { return $UserUrl }
    try {
        $html = (Invoke-WebRequest -Uri 'https://fastcopy.net.cn/' -UseBasicParsing -TimeoutSec 30).Content
        $linkMatches = [regex]::Matches($html, 'https://fastcopy\.jp/archive/FastCopy([0-9][0-9A-Za-z.]*)_installer\.exe')
        if ($linkMatches.Count -eq 0) { return $null }
        $best = $null
        foreach ($m in $linkMatches) {
            $ver = [string]$m.Groups[1].Value
            if (-not $best -or (Compare-VersionString -A $ver -B $best.Version) -gt 0) {
                $best = [pscustomobject]@{ Url = $m.Value; Version = $ver }
            }
        }
        return $best.Url
    } catch {
        Write-Verbose "Could not discover installer from fastcopy.net.cn: $($_.Exception.Message)"
    }
    return $null
}

function Invoke-FastCopyRun {
    param([string]$Exe, [string[]]$ArgList)
    $line = $ArgList -join ' '
    if ($WhatIf) {
        Write-Host ("[WhatIf] {0} {1}" -f $Exe, $line)
        return
    }
    $p = Start-Process -FilePath $Exe -ArgumentList $line -Wait -PassThru
    if ($p.ExitCode -ne 0) {
        throw ("FastCopy exited with code {0}: {1} {2}" -f $p.ExitCode, $Exe, $line)
    }
}

# 1. Locate or install FastCopy
$fastcopy = $null
if ($FastCopyPath) {
    if (-not (Test-Path -LiteralPath $FastCopyPath -PathType Leaf)) {
        throw "FastCopyPath not found: $FastCopyPath"
    }
    $fastcopy = (Resolve-Path -LiteralPath $FastCopyPath).Path
} else {
    $fastcopy = Get-FastCopyPath
}

if (-not $fastcopy) {
    if ($NoInstall) {
        throw 'FastCopy.exe was not found and -NoInstall was specified. Install FastCopy or pass -FastCopyPath.'
    }
    if ($WhatIf) {
        Write-Host '[WhatIf] FastCopy is missing; would install it silently (winget first).'
        throw 'Cannot continue with -WhatIf while FastCopy is missing.'
    }

    Write-Step 'FastCopy is not installed. Installing silently (winget first)...'

    $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Step 'Trying winget: winget install --id FastCopy.FastCopy --exact --silent --accept-package-agreements --accept-source-agreements'
        & winget.exe install --id FastCopy.FastCopy --exact --silent --accept-package-agreements --accept-source-agreements
        Write-Step ("winget exited with code {0}." -f $LASTEXITCODE)
        $fastcopy = Get-FastCopyPath
    }

    if (-not $fastcopy) {
        $downloadSources = New-Object System.Collections.Generic.List[string]
        $discovered = Resolve-InstallerUrl -UserUrl $InstallerUrl
        if ($discovered) { $downloadSources.Add($discovered) }
        # Last-resort mirrors, used when winget and the official link both fail (e.g. the official file is hosted on GitHub raw and unreachable).
        foreach ($m in @(
            'https://dforest.watch.impress.co.jp/library/f/fastcopy/11574/FastCopy5.12.0_installer.exe'
        )) {
            if (-not $downloadSources.Contains($m)) { $downloadSources.Add($m) }
        }

        if ($downloadSources.Count -eq 0) {
            throw 'FastCopy could not be installed via winget, and no installer link was found. Open https://fastcopy.net.cn/ to locate the download URL and pass it via -InstallerUrl.'
        }

        foreach ($src in $downloadSources) {
            $tmp = Join-Path $env:TEMP ("FastCopySetup_{0}.exe" -f [guid]::NewGuid().ToString('N'))
            try {
                Write-Step "winget unavailable or failed; downloading installer: $src"
                Invoke-WebRequest -Uri $src -OutFile $tmp -UseBasicParsing -TimeoutSec 120
                $bytes = [System.IO.File]::ReadAllBytes($tmp)
                if ($bytes.Length -lt 2 -or $bytes[0] -ne 0x4D -or $bytes[1] -ne 0x5A) {
                    throw "Downloaded file does not look like a Windows executable (MZ magic). URL: $src"
                }
                Write-Step 'Running installer: /SILENT'
                $p = Start-Process -FilePath $tmp -ArgumentList '/SILENT' -Wait -PassThru
                if ($p.ExitCode -ne 0) {
                    Write-Warning "FastCopy installer exited with code $($p.ExitCode)."
                }
                $fastcopy = Get-FastCopyPath
                if ($fastcopy) { break }
            } catch {
                Write-Warning "Download/install from $src failed: $($_.Exception.Message)"
            } finally {
                Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
            }
        }
    }

    if (-not $fastcopy) {
        throw 'FastCopy installation failed (winget and all download sources). Install it manually or pass -FastCopyPath.'
    }
}

Write-Step "Using FastCopy: $fastcopy"

# 2. Validate inputs
if ($SkipCopy -and $SkipDelete) {
    throw 'Nothing to do: -SkipCopy and -SkipDelete were both specified.'
}
if (-not $SkipCopy) {
    if (-not $Source) {
        throw 'Source is required unless -SkipCopy is specified.'
    }
    if (-not (Test-Path -LiteralPath $Source)) {
        throw "Source path not found: $Source"
    }
    if ($CopyDays -lt 0) {
        throw 'CopyDays is required unless -SkipCopy is specified.'
    }
} elseif (-not (Test-Path -LiteralPath $Destination)) {
    throw "Destination path not found: $Destination"
}
if (-not $SkipDelete -and $DeleteDays -lt 0) {
    throw 'DeleteDays is required unless -SkipDelete is specified.'
}

if (-not $LogDir) {
    $LogDir = Join-Path $env:TEMP 'fastcopy-archive-logs'
}
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$copyLog = Join-Path $LogDir ("{0}_{1}.log" -f $Mode, $stamp)
$deleteLog = Join-Path $LogDir ("delete_{0}.log" -f $stamp)

$copySummary = if ($SkipCopy) { '(skipped)' } else { $CopyDays }
Write-Step ("Mode={0}, CopyDays={1}, DeleteDays={2}, Include={3}, Exclude={4}" -f $Mode, $copySummary, $DeleteDays, ($(if ($Include) { $Include } else { '(all)' })), ($(if ($Exclude) { $Exclude } else { '(none)' })))

# 3. Copy / move files older than CopyDays
if (-not $SkipCopy) {
    $copyArgs = @('/cmd=' + $Mode)
    if ($Include -and $Include -ne '*') { $copyArgs += '/include="' + $Include + '"' }
    if ($Exclude) { $copyArgs += '/exclude="' + $Exclude + '"' }
    $copyArgs += '/auto_close'
    $copyArgs += '/to_date=-{0}D' -f $CopyDays
    $copyArgs += '/log'
    $copyArgs += '/logfile="' + $copyLog + '"'
    $copyArgs += '"' + $Source + '"'
    $copyArgs += '/to="' + $Destination + '"'

    Write-Step "Step 1/2: $Mode files older than $CopyDays days: $Source -> $Destination"
    Invoke-FastCopyRun -Exe $fastcopy -ArgList $copyArgs
} else {
    Write-Step 'Copy step skipped (-SkipCopy).'
}

# 4. Delete files older than DeleteDays in Destination
if (-not $SkipDelete) {
    $deleteArgs = @('/cmd=delete', '/no_confirm_del')
    if ($Include -and $Include -ne '*') { $deleteArgs += '/include="' + $Include + '"' }
    if ($Exclude) { $deleteArgs += '/exclude="' + $Exclude + '"' }
    $deleteArgs += '/auto_close'
    $deleteArgs += '/to_date=-{0}D' -f $DeleteDays
    $deleteArgs += '/log'
    $deleteArgs += '/logfile="' + $deleteLog + '"'
    $deleteArgs += '"' + $Destination + '"'

    Write-Step "Step 2/2: delete files older than $DeleteDays days in $Destination"
    Invoke-FastCopyRun -Exe $fastcopy -ArgList $deleteArgs
} else {
    Write-Step 'Delete step skipped (-SkipDelete).'
}

Write-Step "Done. Logs: $LogDir"
