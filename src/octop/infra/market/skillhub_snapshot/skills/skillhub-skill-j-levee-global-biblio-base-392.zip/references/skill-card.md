## Description: <br>
Tmp Gbb Publish enables agents to search Chinese and global academic literature, inspect article details, retrieve available full text, and guide users through SmartLib quota and payment flows. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[j-levee](https://clawhub.ai/user/j-levee) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and research-focused agents use this skill to find academic papers, patents, standards, theses, supporting citations, and literature-review sources across SmartLib Chinese journal records and global literature metadata. It can show search results, article details, source links, available OA PDFs, Chinese journal full-text downloads, quota status, and recharge options. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill stores a user email and creates or uses an external SmartLib account. <br>
Mitigation: Ask for the user's email explicitly, use it only for SmartLib account and quota management, and avoid this skill for sensitive research topics unless the data-sharing model is acceptable. <br>
Risk: Searches and downloads use external literature, OA, quota, and payment services. <br>
Mitigation: Tell users when external services are involved, confirm the account email before payment actions, and show quota or cost context before billable downloads or recharge flows. <br>
Risk: Security evidence marks the release as suspicious because account, quota, payment, and download flows have limited scoping and disclosure. <br>
Mitigation: Review the skill before deployment, confirm the SmartLib service relationship, and restrict use where payment handling or external data sharing is not approved. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/j-levee/skills/global-biblio-base) <br>
- [README](artifact/README.md) <br>
- [Pipeline Optimization Guide](artifact/PIPELINE.md) <br>
- [SmartLib Account and Billing](artifact/references/account.md) <br>


## Skill Output: <br>
**Output Type(s):** [Text, Markdown, Files, Guidance] <br>
**Output Format:** [Markdown responses with literature result tables, article details, source links, quota notices, and download or payment guidance] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include PDF download links or files when full text is available; paid or quota-limited actions depend on SmartLib account state.] <br>

## Skill Version(s): <br>
3.9.2 (source: server release evidence and SKILL.md frontmatter) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
