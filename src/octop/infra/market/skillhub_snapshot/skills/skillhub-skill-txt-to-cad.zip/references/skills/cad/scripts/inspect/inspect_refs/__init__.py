"""Selector reference inspection helpers."""
