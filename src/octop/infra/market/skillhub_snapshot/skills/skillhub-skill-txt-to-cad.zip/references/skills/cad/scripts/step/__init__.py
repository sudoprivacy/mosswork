"""Unified STEP generation CLI."""
