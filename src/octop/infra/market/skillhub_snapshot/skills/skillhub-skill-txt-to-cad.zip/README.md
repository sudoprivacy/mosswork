# Text-to-CAD WorkBuddy Plugin

A WorkBuddy plugin for creating, modifying, inspecting, and validating STEP-first parametric CAD parts and assemblies from natural language.

## Installation

### Prerequisites

1. Install Python 3.10+
2. Install required dependencies:

```bash
pip install -r skills/cad/requirements.txt
```

Or install the cadpy package directly:

```bash
pip install -e ~/.claude/plugins/marketplaces/text-to-cad/skills/cad/scripts/packages/cadpy
```

### Plugin Installation

1. Copy the `workbuddy-plugin` directory to your WorkBuddy plugins folder
2. Restart WorkBuddy to load the plugin

## Usage

### Creating CAD Models

Describe the part you want to create in natural language:

```
Create a circular flange with:
- Outer diameter: 80mm
- Thickness: 20mm
- Center hole: 30mm diameter
- 6 bolt holes on 60mm bolt circle diameter
- M8 threaded holes
- 1mm chamfer on outer edge
```

### Commands

The plugin provides these scripts:

```bash
# Generate STEP file from Python source
python scripts/step path/to/model.py

# Inspect and validate geometry
python scripts/inspect refs path/to/model.step --facts --planes --positioning

# Generate visual snapshot
python scripts/snapshot --input path/to/model.step --output path/to/output.png
```

## Supported Features

- Parametric modeling with build123d
- STEP/STP file generation
- STL/3MF/GLB exports
- Geometry inspection and validation
- Visual snapshot generation
- Assembly creation with labels
- Mating datum positioning

## Examples

### Circular Flange

```python
from build123d import *
from math import cos, sin, radians

# Parameters
outer_diameter = 80.0
thickness = 20.0
center_hole_diameter = 30.0
bolt_circle_diameter = 60.0
bolt_hole_count = 6
bolt_hole_diameter = 8.0
chamfer_size = 1.0

def make_flange() -> Solid:
    with BuildPart() as part:
        Cylinder(radius=outer_diameter / 2, height=thickness)
        chamfer(part.edges(), chamfer_size)
        with Locations((0, 0, thickness / 2)):
            Hole(radius=center_hole_diameter / 2)
        for i in range(bolt_hole_count):
            angle = i * 360 / bolt_hole_count
            x = (bolt_circle_diameter / 2) * cos(radians(angle))
            y = (bolt_circle_diameter / 2) * sin(radians(angle))
            with Locations((x, y, thickness / 2)):
                Hole(radius=bolt_hole_diameter / 2)
    return part.part

def gen_step():
    return make_flange()
```

## License

MIT License - see LICENSE file for details

## Credits

Based on [earthtojake/text-to-cad](https://github.com/earthtojake/text-to-cad)
