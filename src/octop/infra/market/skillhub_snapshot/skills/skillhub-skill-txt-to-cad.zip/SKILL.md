---
name: skillhub-skill-txt-to-cad
description: "Create, modify, inspect, and validate STEP-first parametric CAD parts and assemblies from natural language. Use for CAD specs, reference images, 2D technical drawings, STEP/STP generation or direct inspection, Python CAD source, geometry facts, measurements, snapshots, and secondary STL/3MF/native GLB outputs from CAD geometry. Supports build123d Python modeling with parametric design, assembly cr"
---

# CAD Generation, Inspection, and Validation

## Overview

This skill enables AI agents to create or modify parametric CAD models from natural-language requirements, generate validated STEP/STP artifacts, inspect geometry references, and return checked outputs. STEP is treated as the primary CAD artifact. STL, 3MF, and native GLB are secondary export workflows.

## Requirements

### Dependencies

Install the required packages before using this skill:

```bash
pip install -e ~/.claude/plugins/marketplaces/text-to-cad/skills/cad/scripts/packages/cadpy
```

This will install:
- build123d (parametric CAD modeling)
- cadquery-ocp (OpenCASCADE Python bindings)
- All required dependencies

### Tools

From the CAD skill directory, the launcher commands are:

```bash
python scripts/step ...      # STEP generation, GLB/topology artifacts, mesh sidecars
python scripts/inspect ...   # refs, measure, align, frame, diff
python scripts/snapshot ...  # PNG/GIF visual review packets
```

## When to Use This Skill

Use this skill when the user asks for:
- CAD files, STEP/STP files, build123d source
- Mechanical parts, assemblies, enclosures, brackets, fixtures
- Holes, counterbores, countersinks, slots, pockets, bosses, standoffs, ribs, fillets, chamfers, shells
- Reference images or 2D technical drawings of a part to reproduce
- STL, 3MF, or native GLB output from CAD geometry
- Geometry measurements, alignment checks, or validation

Do NOT use this skill for:
- Render-only concept art
- CAM toolpaths
- Engineering certification
- FEA conclusions
- Architectural BIM
- Freehand illustration

## Default Assumptions

Use these defaults unless the user specifies otherwise:

- **Units**: millimeters
- **Origin**: center of the main part or assembly
- **Base plane**: XY
- **Up/extrusion axis**: positive Z
- **Output geometry**: closed, positive-volume solids
- **Small plastic enclosure wall**: 2.0-3.0 mm when unspecified
- **Cosmetic fillet**: 1.0-3.0 mm when safe for local geometry
- **M3/M4/M5 normal clearance holes**: 3.4/4.5/5.5 mm unless another standard is requested

## Modeling Workflow

### 1. Classify the Task

Determine the task type:
- New part from scratch
- New assembly
- Source modification
- Direct STEP/STP inspection
- Reference selection
- Measurement/alignment check
- Snapshot review
- Secondary output request (STL/3MF/GLB)

### 2. Write a Natural-Language CAD Brief

Extract from the user's request:
- Dimensions and units
- Coordinate convention
- Feature intent
- Output paths
- Assumptions
- Validation targets

### 3. Plan Before Coding

Define before editing:
- Parameters (named variables for dimensions)
- Intent labels
- Source paths
- Expected bounding boxes
- Mating/positioning datums

### 4. Author build123d Python Source

Create a Python file with `gen_step()` function:

```python
from build123d import *

# Parameters as named variables
outer_diameter = 80.0
thickness = 20.0
hole_diameter = 30.0

def make_part() -> Solid:
    """Create the part geometry"""
    with BuildPart() as part:
        # Base solid
        Cylinder(radius=outer_diameter / 2, height=thickness)
        
        # Subtractive features
        with Locations((0, 0, thickness / 2)):
            Hole(radius=hole_diameter / 2)
        
        # Fillets/chamfers last
        chamfer(part.edges(), 1.0)
    
    return part.part

def gen_step():
    """Generate STEP file - required function signature"""
    return make_part()
```

### 5. Generate STEP File

Run the step generation script:

```bash
python ~/.claude/plugins/marketplaces/text-to-cad/skills/cad/scripts/step path/to/your_model.py
```

This generates:
- `.step` file (primary CAD artifact)
- `.glb` file (for viewer)
- Topology artifacts

### 6. Validate Geometry

Run baseline inspection:

```bash
python ~/.claude/plugins/marketplaces/text-to-cad/skills/cad/scripts/inspect refs path/to/model.step --facts --planes --positioning
```

This returns:
- Face/edge/vertex counts
- Bounding box dimensions
- Major plane identification
- Positioning information

### 7. Generate Snapshot

Create visual verification:

```bash
python ~/.claude/plugins/marketplaces/text-to-cad/skills/cad/scripts/snapshot --input path/to/model.step --output path/to/output.png --appearance workbench
```

## Modeling Best Practices

### Design Strategy

- **Choose construction that makes spec dimensions direct parameters**
- **Order operations**: Base solid -> Major additions -> Subtractive features -> Shell -> Through holes -> Fillets/chamfers last
- **Overshoot boolean tools**: Extend cutting tools 1mm past entry/exit faces
- **Sanity-check proportions**: Compare expected vs actual bounding box

### Parameters First

Always use named variables for dimensions:

```python
# Good - named parameters
outer_diameter = 80.0
thickness = 20.0

# Bad - magic numbers
Cylinder(radius=40, height=20)
```

### Coordinate System

Declare the convention:

```text
Origin: center of primary part
XY: main base/sketch plane
+Z: up/extrusion direction
```

### Common Failure Modes

Avoid these issues:
- Fillet radius larger than local edge geometry
- Open sketch profile produces invalid face
- Face selector changes after boolean or fillet
- Part origin is arbitrary
- Coincident or coplanar tool/target faces

### Fillet/Chamfer Tips

- Fillets are the most failure-prone operation
- Postpone fillets to the end of modeling
- If chamfer fails, try smaller radius or different edge selection
- Select edges carefully after boolean operations change topology

## Assembly Workflow

For assemblies with multiple parts:

```python
from build123d import *
from cadpy.assembly import AssemblyHelper, label_shape

def make_assembly():
    asm = AssemblyHelper("my_assembly")
    
    base = asm.add(make_base(), "base")
    lid = asm.add(make_lid(), "lid")
    
    # Add hardware with labels
    screw = label_shape(
        Cylinder(radius=2.0, height=8.0),
        "m4_screw",
        "front_left"
    )
    
    return asm.compound
```

## Export Workflows

### Primary: STEP

STEP is the primary CAD artifact. Always generate STEP first.

### Secondary: STL/3MF/GLB

For 3D printing or web visualization:

```bash
python scripts/step path/to/model.py --stl --3mf
```

### DXF (2D Drawings)

For 2D technical drawings, use the DXF skill separately.

## Validation Checklist

Before delivering CAD files:

- [ ] STEP file exists and is non-empty
- [ ] Bounding box matches expected dimensions
- [ ] All holes are through-holes where specified
- [ ] Fillets/chamfers applied correctly
- [ ] No self-intersecting geometry
- [ ] Snapshot visually reviewed
- [ ] Inspection passes without errors

## Code Style Guidelines

- Write minimal, concise Python code
- Use meaningful parameter names
- Comment non-obvious geometry decisions
- Keep functions short (<50 lines)
- Separate parameter definition from geometry creation

## Example: Circular Flange

```python
from build123d import *
from math import cos, sin, radians

# Flange parameters
outer_diameter = 80.0
thickness = 20.0
center_hole_diameter = 30.0
bolt_circle_diameter = 60.0
bolt_hole_count = 6
bolt_hole_diameter = 8.0
chamfer_size = 1.0

bolt_angles = [i * 360 / bolt_hole_count for i in range(bolt_hole_count)]

def make_flange() -> Solid:
    with BuildPart() as part:
        # Base cylinder
        Cylinder(radius=outer_diameter / 2, height=thickness)
        
        # Chamfer outer edges
        chamfer(part.edges(), chamfer_size)
        
        # Center hole
        with Locations((0, 0, thickness / 2)):
            Hole(radius=center_hole_diameter / 2)
        
        # Bolt holes
        for angle in bolt_angles:
            x = (bolt_circle_diameter / 2) * cos(radians(angle))
            y = (bolt_circle_diameter / 2) * sin(radians(angle))
            with Locations((x, y, thickness / 2)):
                Hole(radius=bolt_hole_diameter / 2)
    
    return part.part

def gen_step():
    return make_flange()
```

Generate and validate:

```bash
python scripts/step flange.py
python scripts/inspect refs flange.step --facts --planes --positioning
python scripts/snapshot --input flange.step --output flange.png
```

## Troubleshooting

### Chamfer/Fillet Fails

- Try smaller radius value
- Select specific edges instead of all edges
- Apply chamfer before boolean operations if possible
- Check for coincident faces

### Invalid Geometry

- Ensure all sketches are closed profiles
- Verify boolean tools overshoot target faces
- Check for self-intersecting edges
- Validate parameter proportions

### Script Errors

- Verify cadpy package is installed
- Check Python file encoding (use UTF-8)
- Ensure `gen_step()` function exists
- Validate build123d imports
