#!/usr/bin/env python3
"""
发型设计师（9宫格发型设计预览图生成） - 执行任务接口（真实调用时使用）
调用方式: python scripts/execute_task.py --portrait-image "人物肖像底图(Base64或URL)"

仅使用 Python 标准库，无需安装第三方依赖。
appKey 获取：通过手机验证获取，详见 skill.md 前置准备。
"""

import argparse
import json
import os
import getpass
import urllib.request
import urllib.error
import urllib.parse

# 合法的成品图宽高比枚举
VALID_ASPECT_RATIOS = ["1:1", "3:4", "4:3", "16:9", "9:16"]


def execute_task(
    portrait_image: str,
    aspect_ratio: str = "3:4",
    need_text: bool = False,
    mode: str = "sync"
) -> dict:
    """
    执行9宫格发型设计预览图生成任务

    Args:
        portrait_image: 人物肖像基底图，标准 Base64 编码字符串（或普通图片URL），必填
        aspect_ratio: 成品图像宽高比例，可选 1:1, 3:4, 4:3, 16:9, 9:16，默认 3:4
        need_text: 是否在每个宫格生成文字标题和描述（发型名称和特点），默认 False
        mode: 调用模式 async 或 sync

    Returns:
        dict: 包含 showapi_res_body、showapi_res_code 等字段的响应，
              成功后 showapi_res_body 中含 task_id
    """
    # 1. 获取凭证：优先环境变量，无则交互式输入
    # appKey 获取方式：通过手机验证获取，详见 skill.md 前置准备
    app_key = os.environ.get("SHOWAPI_APP_KEY")
    if not app_key:
        print("未检测到环境变量 SHOWAPI_APP_KEY，请输入 AppKey：")
        print("（获取方式：通过手机验证获取，详见 skill.md 前置准备）")
        app_key = getpass.getpass(prompt="AppKey: ")

    if not app_key.strip():
        raise ValueError("AppKey 不能为空，请重新运行并输入有效凭证。")

    # 2. 入参校验与数据清洗
    if not portrait_image or not str(portrait_image).strip():
        raise ValueError(
            "portrait_image 不能为空，请提供人物肖像基底图"
            "（标准 Base64 编码字符串或普通图片URL）。"
        )
    portrait_image = str(portrait_image).strip()

    if aspect_ratio not in VALID_ASPECT_RATIOS:
        raise ValueError(
            f"aspect_ratio 取值不合法：{aspect_ratio}，"
            f"可选枚举：{'、'.join(VALID_ASPECT_RATIOS)}。"
        )

    # 3. 构建请求
    url = "https://route.showapi.com/flow/execute/6a841ba13c51f2e3110047dd"
    headers = {
        "Content-Type": "application/json"
    }

    # 构建请求体
    payload = {
        "portrait_image": portrait_image,
        "aspect_ratio": aspect_ratio,
        "need_text": bool(need_text)
    }

    # 4. 构建查询参数（包含 appKey）
    query_params = urllib.parse.urlencode({"appKey": app_key, "mode": mode})
    full_url = f"{url}?{query_params}"

    # 5. 发起请求
    req = urllib.request.Request(
        full_url,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            if response.status >= 400:
                raise Exception(f"HTTP请求失败: {response.status}")

            data = json.loads(response.read().decode("utf-8"))

            # 6. 业务错误处理
            if data.get("showapi_res_code", -1) != 0:
                error_msg = data.get("showapi_res_error", "未知错误")
                raise Exception(f"API错误: {error_msg}")

            return data

    except urllib.error.HTTPError as e:
        raise Exception(f"HTTP请求失败: {e.code}, {e.reason}")
    except urllib.error.URLError as e:
        raise Exception(f"请求失败: {str(e.reason)}")
    except Exception as e:
        raise Exception(f"请求异常: {str(e)}")


def main():
    parser = argparse.ArgumentParser(
        description="发型设计师 - 9宫格发型设计预览图生成（异步提交任务）"
    )
    parser.add_argument(
        "--portrait-image", "-p",
        required=True,
        help="人物肖像基底图（标准 Base64 编码字符串或普通图片URL）"
    )
    parser.add_argument(
        "--aspect-ratio", "-a",
        default="3:4",
        choices=VALID_ASPECT_RATIOS,
        help="成品图像宽高比例，默认 3:4"
    )
    parser.add_argument(
        "--need-text", "-t",
        action="store_true",
        help="是否在每个宫格生成文字标题和描述（发型名称和特点）"
    )
    parser.add_argument(
        "--async",
        dest="mode",
        action="store_const",
        const="async",
        default="sync",
        help="使用异步模式（推荐，任务提交后仅返回 task_id）"
    )

    args = parser.parse_args()

    result = execute_task(
        portrait_image=args.portrait_image,
        aspect_ratio=args.aspect_ratio,
        need_text=args.need_text,
        mode=args.mode
    )

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()