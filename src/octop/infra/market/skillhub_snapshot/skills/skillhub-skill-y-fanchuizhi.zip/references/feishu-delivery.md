# 飞书交付全流程（含踩过的坑）

## 一、环境准备（Windows Git Bash 必做）

`lark-cli` 在 Git Bash 里常因 PATH 异常报 `dirname: command not found`。**每条命令前置**：

```bash
export PATH="/usr/bin:/bin:$PATH"
```

后面所有命令默认带这个前缀。

## 二、找客户文件夹

```bash
lark-cli drive +search --query "客户名关键词" --as user --format json
```

拿到 `folder_token`。云盘结构约定：

- 根目录：`A项目名称`
- 客户子目录：`/快赢/2026年/` 下，按客户建文件夹
- 客户文件夹内已有：【0】模仿期流程规划、【1】定位报告、【2】双高字幕、【3】跨界模仿、【4】违规处理

## 三、编号与命名

| 编号 | 含义 |
|---|---|
| 【0】 | 模仿期 |
| 【1】 | 定位报告 |
| 【2】 | 双高字幕 |
| 【3】 | 跨界模仿 |
| 【4】 | 违规处理 |
| 【5】起 | 按客户体系顺延（**泛垂直放大层级用【5】**） |

**命名格式**：`【客户名】·赋能【N】-泛垂直放大层级`
示例：`【统匠装饰】·赋能【5】-泛垂直放大层级`

## 四、生成 md 并导入

**不要直接传 HTML**——HTML 导入会把 `<style>` 那段 CSS 当正文带进去。先转 md 再导入。

```bash
lark-cli drive +import \
  --file "泛垂直放大层级-客户名.md" \
  --type docx \
  --folder-token "<folder_token>" \
  --name "【客户名】·赋能【5】-泛垂直放大层级" \
  --as user --format json
```

返回里取 `document.token` 和 URL。

## 五、导入后四项校验（不做完不算交付）

```bash
# ① 结构是否完整
lark-cli docs +fetch --doc '<token>' --scope outline --as user --format json

# ② 是否有 ** 残留
lark-cli docs +fetch --doc '<token>' --scope keyword --keyword '\*\*' --as user --format json

# ③ 定位某张表（拿 block id + 看内容）
lark-cli docs +fetch --doc '<token>' --scope keyword --keyword '表内关键词' --detail with-ids --as user --format json

# ④ 看某章节 XML（要改结构时用）
lark-cli docs +fetch --doc '<token>' --scope section --start-block-id '<h2的block_id>' --detail with-ids --doc-format xml --as user --format json
```

## 六、常用编辑命令

```bash
# 删块（如重复标题）
lark-cli docs +update --doc '<token>' --command block_delete --block-id '<id>' --as user --format json

# 整块替换（重写表格 / 换内容）
lark-cli docs +update --doc '<token>' --command block_replace --block-id '<id>' \
  --as user --format json --content '<table>...</table>'

# 文字替换（清 ** 残留）
lark-cli docs +update --doc '<token>' --command str_replace \
  --pattern '**原文**' --content '<b>原文</b>' --as user --format json

# 在块后插入
lark-cli docs +update --doc '<token>' --command block_insert_after --block-id '<id>' \
  --as user --format json --content '<blockquote><p>...</p></blockquote>'
```

## 七、五个必踩的坑（已验证，务必避开）

**1. md 里不要写 `#` 一级标题**
导入后正文 h1 会和文档名重复。md 从 `##` 开头，标题只写在 `--name` 里。
（已发生：统匠文档正文开头重复标题，用 `block_delete` 删掉）

**2. 表格列宽导入后被均分**
三列表会被均成 244/244/244，前两列内容短就显得空一大截。
修法：`block_replace` 重写，带 `<colgroup><col width="170"/><col width="90"/><col width="560"/></colgroup>`，短列收紧、长列撑满，单元格加 `vertical-align="top"`。

**3. `**加粗**` 紧贴中文引号时不被转换**
如 `只要是**"这类人"**就会被戳中`，导入后 `**` 裸露在正文。
修法：导入后必搜 `\*\*`，用 `str_replace` 逐个改成 `<b>`。

**4. `block_replace` / `block_insert_after` 之后 block id 会变**
下一步操作前必须重新 fetch 拿新 id，**不能沿用旧 id**。

**5. 命令可能被沙箱重试，导致 import 执行两次 → 云盘出现两份同名文档**
现象：命令回显为空，或日志出现 `Sandbox bypassed (escalation-approved)`，实际跑了两次。
**所以每次 import 后必须列一次目录确认只有一份：**

```bash
lark-cli drive files list --folder-token "<token>" --as user --format json | grep '"name"'
```

发现两份时，**先对比再删**（用 revision_id 和关键词判断哪份是新的，新版通常含最新修订内容）：

```bash
lark-cli docs +fetch --doc '<可疑token>' --scope outline --as user --format json   # 看 revision_id
lark-cli drive +delete --file-token "<要删的token>" --type docx --yes --as user --format json
```

删除是 high-risk-write，必须带 `--yes`。删完再 list 复核一次。飞书回收站 30 天内可恢复。

## 八、Callout 配色（Sam 的固定风格）

md 里的 `>` 引用导入飞书后是**默认样式、没有颜色**，所以 emoji 语义必须先写对。
本地 HTML 版本按这套 RGB 上色：

| Emoji | 语义 | 底色 | 边框 |
|---|---|---|---|
| 🎈 | 开场导语、一句话主旨 | (255,245,235) | (254,212,164) |
| 💡 | 提示、解读、"为什么重要" | (240,251,239) | 绿系 |
| 🟣 | 变体提示 | (246,241,254) | 紫系 |
| ❌ | 误区、错误做法 | (254,241,241) | (249,142,139) |
| 🚫 | 禁令红线 | 红底 | 红 |
| 📌 | 固定要点 | (240,244,255) | 蓝系 |
| 🎯 | 目标 / 建议 | 蓝底 | 蓝系 |
| 🎬 | 拍摄 / 执行提示 | (254,255,240) | 浅黄 |

**表格列宽修复的现成模板**（直接改内容即可复用）：

```
--command block_replace --block-id '<table_id>' --content '<table><colgroup>...</colgroup>...'
```

- 三列（层级 / 占比 / 选题）：`170 / 90 / 560`
- 四列（时间 / 层级 / 内容类型 / 选题）：`80 / 150 / 190 / 400`（层级列要放得下"L-1（下沉层）"）
- 单元格一律加 `vertical-align="top"`，表头加 `background-color="light-gray"`
- 单元格内多条选题用 `<ul><li>`，不要用 `·` 前缀

**拿表格 block id 的技巧**：`--scope keyword` 搜**表内的具体文本**更稳（如 `L-1 下沉层`、`周一`），搜表头词（如「选题方向与示例」）有时搜不到。

**给飞书文档上色**：md 导入阶段做不到，需要导入后用 `docs +update` 改 callout 块的颜色属性。
⚠️ 该属性名在 CLI 上**尚未实测**，先用一条块试，成功再批量；失败就保留 emoji 前缀 + 默认样式，不硬来。

## 九、交付收尾

1. `present_files` 给飞书链接
2. 同步本地 md 和 HTML（避免飞书与本地两个版本不一致）
3. 确认客户名与云盘文件夹名是否统一（例：正式名"统匠装饰"，文件夹却写"统匠装潢设计"），不一致时提醒 Sam 是否统一
