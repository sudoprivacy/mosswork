#!/usr/bin/env node
'use strict';

/**
 * 发票查验 CLI —— 走 BFF（piaohh.top/wvticket）AI Pay 额度模式
 *
 * 流程：临时用户 → 收集发票（图片/PDF OCR | Excel | JSON）→ AI Pay 端点创建查验任务
 *       （额度不足返回 402 + 付款链接，付款后 --proof 重试）→ 轮询 → 导出 Excel
 *
 * 图片/PDF OCR 走 piaohh.top/api/upload-invoice（现有接口）
 * 查验任务走 /api/aipay/ai/check-invoice-task（¥0.01/次，新号送 10 次）
 * 查验结果自动保存到桌面 ~/Desktop/发票查验_YYYYMMDD/
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

// ---------------------------- 常量 ----------------------------

const BFF_BASE = process.env.INVOICE_BFF_BASE || 'https://piaohh.top/wvticket';
const OCR_BASE = process.env.INVOICE_OCR_BASE || 'https://piaohh.top';
const TOKEN_FILE = path.join(os.homedir(), '.invoice-verify', 'token.json');
const PENDING_FILE = path.join(os.homedir(), '.invoice-verify', 'pending_payment.json');
const AI_CHECK_PATH = '/api/aipay/ai/check-invoice-task'; // AI Pay 额度模式端点
const TOKEN_TTL_MS = 30 * 60 * 1000; // 30 分钟
const POLL_INTERVAL_MS = 3000;       // 轮询间隔
const POLL_TIMEOUT_MS = 10 * 60 * 1000; // 轮询超时 10 分钟

const MIME = {
  '.pdf': 'application/pdf',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.bmp': 'image/bmp',
};

// ---------------------------- HTTP 工具 ----------------------------

async function http(method, url, opts = {}) {
  const { headers, body, signal, timeout } = opts;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout || 120000);
  try {
    const res = await fetch(url, {
      method,
      headers,
      body,
      signal: signal || controller.signal,
    });
    const text = await res.text();
    let data;
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = null; }
    return { status: res.status, ok: res.ok, text, data, headers: res.headers };
  } finally {
    clearTimeout(timer);
  }
}

async function bffPost(path, body, token, extraHeaders) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  Object.assign(headers, extraHeaders || {});
  const { status, data, text } = await http('POST', BFF_BASE + path, {
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (status >= 400 && !data) {
    throw new Error(`BFF ${path} HTTP ${status}: ${text.slice(0, 200)}`);
  }
  return data || {};
}

const SHOT_BASE = process.env.INVOICE_SHOT_BASE || 'https://piaohh.top/phh/api/screenshots';

// ---------------------------- 补拿截图/PDF ----------------------------

async function fetchScreenshots(taskList, outDir) {
  const screenshotsDir = path.join(outDir, '查验截图');
  const pdfsDir = path.join(outDir, '查验pdf');
  fs.mkdirSync(screenshotsDir, { recursive: true });
  fs.mkdirSync(pdfsDir, { recursive: true });

  const results = [];
  for (const task of taskList) {
    const base = task.fphm;
    const got = [];
    // PNG → screenshots/
    try {
      const res = await fetch(`${SHOT_BASE}/${base}.png`);
      if (res.ok && (res.headers.get('content-type') || '').includes('text') === false) {
        const buf = Buffer.from(await res.arrayBuffer());
        const dst = path.join(screenshotsDir, base + '.png');
        fs.writeFileSync(dst, buf);
        got.push('查验截图/' + base + '.png');
      }
    } catch (_) {}
    // PDF → pdfs/
    try {
      const res = await fetch(`${SHOT_BASE}/${base}.pdf`);
      if (res.ok && (res.headers.get('content-type') || '').includes('text') === false) {
        const buf = Buffer.from(await res.arrayBuffer());
        const dst = path.join(pdfsDir, base + '.pdf');
        fs.writeFileSync(dst, buf);
        got.push('查验pdf/' + base + '.pdf');
      }
    } catch (_) {}
    results.push({ fphm: base, files: got });
  }
  return results;
}

// ---------------------------- 临时用户管理 ----------------------------

function loadTokenCache() {
  try {
    if (fs.existsSync(TOKEN_FILE)) {
      return JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8'));
    }
  } catch (_) {}
  return null;
}

function saveTokenCache(cache) {
  try {
    fs.mkdirSync(path.dirname(TOKEN_FILE), { recursive: true });
    fs.writeFileSync(TOKEN_FILE, JSON.stringify(cache, null, 2), 'utf8');
  } catch (_) {}
}

function randomHex(n) { return crypto.randomBytes(n).toString('hex'); }
function randomPhone() {
  // 13 开头 + 10 位数字，共 11 位
  let s = '13';
  for (let i = 0; i < 9; i++) s += Math.floor(Math.random() * 10);
  return s;
}

async function ensureToken() {
  const cached = loadTokenCache();

  // token 未过期 → 直接用
  if (cached && cached.token && cached.expiresAt && Date.now() < cached.expiresAt) {
    return cached.token;
  }

  // token 过期但有账号密码 → 重新登录（不新建用户）
  if (cached && cached.account && cached.password) {
    console.log('🔑 token 过期，重新登录...');
    const loginRes = await bffPost('/auth/login', { account: cached.account, password: cached.password });
    const token = (loginRes.data && loginRes.data.token) || null;
    if (token) {
      const renewed = { ...cached, token, expiresAt: Date.now() + TOKEN_TTL_MS };
      saveTokenCache(renewed);
      return token;
    }
    console.log('   登录失败，重建用户...');
  }

  // 没有账号或登录失败 → 新建用户
  const username = `iv_${Date.now().toString(36)}_${randomHex(4)}`;
  const email = `${username}@skill.local`;
  const phone = randomPhone();
  const password = randomHex(8);

  console.log('🆕 创建临时用户...');
  const createRes = await bffPost('/users/create', {
    username, email, phone, password, grantCheckNum: 10, // 与 AI 渠道首次赠送次数对齐
  });
  if (!createRes || (createRes.status !== 200 && createRes.code !== 200)) {
    throw new Error(`创建用户失败: ${JSON.stringify(createRes)}`);
  }
  const userId = (createRes.data && (createRes.data.id || createRes.data.userId)) || createRes.data;

  console.log('🔑 登录拿 token...');
  const loginRes = await bffPost('/auth/login', { account: email, password });
  const token = (loginRes.data && loginRes.data.token) || null;
  if (!token) {
    throw new Error(`登录失败: ${JSON.stringify(loginRes)}`);
  }

  saveTokenCache({
    username, email, phone, password, account: email, userId, token,
    createdAt: Date.now(),
    expiresAt: Date.now() + TOKEN_TTL_MS,
  });
  console.log('✅ 临时用户就绪，token 已缓存');
  return token;
}

// ---------------------------- OCR（图片/PDF） ----------------------------

async function ocrFile(file) {
  if (!fs.existsSync(file)) throw new Error(`文件不存在: ${file}`);
  const ext = path.extname(file).toLowerCase();
  const type = MIME[ext];
  if (!type) throw new Error(`不支持的文件类型: ${ext}`);

  const form = new FormData();
  form.append('file', new Blob([fs.readFileSync(file)], { type }), path.basename(file));

  const { ok, data, text } = await http('POST', OCR_BASE + '/api/upload-invoice', {
    body: form,
    timeout: 180000,
  });
  if (!ok || !data || Number(data.code) !== 200) {
    throw new Error(`OCR 失败: ${(data && data.message) || 'HTTP 错误'}`);
  }
  const rows = (data.data || []).filter((r) => r && String(r.fphm || '').trim());
  if (rows.length === 0) throw new Error('OCR 未识别出发票号码');
  return rows.map((r) => ({
    fphm: String(r.fphm || '').trim(),
    fpdm: String(r.fpdm || '').trim(),
    kprq: String(r.kprq || '').trim(),
    je: String(r.je || r.kpje || '').trim(),
  }));
}

// ---------------------------- 上传到 BFF ----------------------------

async function importExcel(token, file) {
  if (!fs.existsSync(file)) throw new Error(`文件不存在: ${file}`);
  const buffer = fs.readFileSync(file);
  const form = new FormData();
  form.append('file', new Blob([buffer], { type: 'application/octet-stream' }), path.basename(file));

  const headers = {};
  if (token) headers.Authorization = 'Bearer ' + token;

  const { status, data, text } = await http('POST', BFF_BASE + '/importInvoice/uploadExcel', {
    headers,
    body: form,
    timeout: 180000,
  });
  if (status >= 400 || !data || (data.status !== 200 && data.code !== 200)) {
    throw new Error(`Excel 解析失败: ${(data && data.message) || text}`);
  }
  const inner = data.data || data;
  const records = (inner && Array.isArray(inner.successRecords)) ? inner.successRecords : [];
  return records
    .map((r) => ({
      fphm: String(r.fphm || '').trim(),
      fpdm: String(r.fpdm || '').trim(),
      kprq: String(r.kprq || '').trim(),
      je: String(r.je || '').trim(),
    }))
    .filter((r) => r.fphm);
}

// ---------------------------- AI Pay 查验任务（额度模式，余额不足返回 402） ----------------------------

function savePendingPayment(payload) {
  try {
    fs.mkdirSync(path.dirname(PENDING_FILE), { recursive: true });
    fs.writeFileSync(PENDING_FILE, JSON.stringify(payload, null, 2), 'utf8');
  } catch (_) {}
}

function loadPendingPayment() {
  try {
    if (fs.existsSync(PENDING_FILE)) return JSON.parse(fs.readFileSync(PENDING_FILE, 'utf8'));
  } catch (_) {}
  return null;
}

function loadProof(value) {
  const raw = value.startsWith('@') ? fs.readFileSync(value.slice(1), 'utf8') : value;
  const proof = String(raw).trim();
  if (!proof) throw new Error('Payment-Proof 为空');
  return proof;
}

async function aiCreateTasks(token, userId, items, paymentProof) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  if (paymentProof) headers['payment-proof'] = paymentProof;

  const invoices = items.map((it) => ({
    invoiceNum: it.fphm,
    invoiceCode: it.fpdm || '',
    invoiceDate: it.kprq,
    amountOrCheckNum: it.je,
  }));

  const { status, data, text, headers: resHeaders } = await http('POST', BFF_BASE + AI_CHECK_PATH, {
    headers,
    body: JSON.stringify({ userId: String(userId), invoices }),
    timeout: 180000,
  });

  // 额度不足：402 + amtPaymentLink（付款链接在响应 header）
  if (status === 402) {
    return {
      needPayment: true,
      paymentLink: (resHeaders && resHeaders.get('amtpaymentlink')) || '',
      message: (data && data.message) || '核验次数不足',
      shortage: (data && data.shortage) || invoices.length,
      currentQuota: (data && data.current_quota) || 0,
    };
  }

  if (status >= 400 && !data) {
    throw new Error(`AI Pay 端点 HTTP ${status}: ${text.slice(0, 200)}`);
  }
  if (!data || data.code !== 'SUCCESS') {
    throw new Error(`创建查验任务失败: ${JSON.stringify(data || text).slice(0, 300)}`);
  }
  const d = data.data || {};
  const tasks = Array.isArray(d.tasks) ? d.tasks : (d.task ? [d.task] : []);
  return { needPayment: false, queueList: tasks, quota: d.quota };
}

function isTaskDone(task) {
  // checkStatus: 0=待查验, 1=查验中, 2=完成, 3=失败
  return task.checkStatus === 2 || task.checkStatus === 3;
}

async function pollTasks(token, taskIds) {
  const deadline = Date.now() + POLL_TIMEOUT_MS;
  let allDone = false;
  let lastList = null;

  while (Date.now() < deadline) {
    // 不传 ids，直接按当前用户查
    const res = await bffPost('/check-invoice-task/checkInvoiceTaskList', {
      page: 1,
      size: 200,
    }, token);

    const list = (res.data && (res.data.list || res.data)) || [];
    lastList = Array.isArray(list) ? list : [];

    if (lastList.length === 0) {
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    // 只关心我们这次创建的任务
    const myTasks = taskIds && taskIds.length > 0
      ? lastList.filter((t) => taskIds.includes(t.id))
      : lastList;

    allDone = myTasks.every(isTaskDone);
    const doneCount = myTasks.filter(isTaskDone).length;
    const passCount = myTasks.filter((t) => t.checkStatus === 2).length;
    const failCount = myTasks.filter((t) => t.checkStatus === 3).length;
    const remain = myTasks.length - doneCount;

    if (remain > 0) {
      process.stdout.write(`\r⏳ 查验中... 通过 ${passCount} / 失败 ${failCount} / 剩余 ${remain}   `);
    } else {
      console.log(`\n✅ 全部完成：通过 ${passCount}，失败 ${failCount}`);
    }

    if (allDone) break;
    await sleep(POLL_INTERVAL_MS);
  }

  if (!allDone) {
    console.log('\n⚠️ 轮询超时，导出当前状态');
  }
  return lastList;
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

// ---------------------------- 导出 ----------------------------

async function exportAndDownload(token, taskList, outDir) {
  const ids = taskList.map((t) => t.id).filter((x) => x != null);
  if (ids.length === 0) throw new Error('没有可导出的查验任务');

  const res = await bffPost('/check-invoice-task/detail/export', { ids }, token);
  if (res.code !== 200) throw new Error(`导出失败: ${JSON.stringify(res)}`);
  // res.data.downloadUrl / fileName
  const inner = res.data || res;
  const { downloadUrl, fileName } = inner;

  console.log(`📥 下载结果：${fileName}`);
  const dlRes = await fetch(downloadUrl);
  if (!dlRes.ok) throw new Error(`下载失败 HTTP ${dlRes.status}`);
  const buf = Buffer.from(await dlRes.arrayBuffer());

  const safeName = (fileName || '查验结果.xlsx').replace(/[\\/:*?"<>|]/g, '_');
  const outPath = path.join(outDir, safeName);
  fs.writeFileSync(outPath, buf);
  console.log(`✅ 已保存: ${outPath}`);
  return outPath;
}

// ---------------------------- 输入解析 ----------------------------

function normalizeItem(raw, index) {
  if (!raw || typeof raw !== 'object') return null;
  const pick = (keys) => {
    for (const k of Object.keys(raw)) {
      if (keys.some((alias) => String(k).trim().toLowerCase() === alias.toLowerCase())) return raw[k];
    }
    return undefined;
  };
  return {
    fphm: String(pick(['fphm', '发票号码', '发票号']) ?? '').replace(/\s+/g, ''),
    fpdm: String(pick(['fpdm', '发票代码']) ?? '').replace(/\s+/g, ''),
    kprq: String(pick(['kprq', '开票日期', '日期']) ?? '').replace(/[-\s]/g, ''),
    je: String(pick(['je', 'kpje', '开票金额', '价税合计', '金额']) ?? '').replace(/[￥¥,\s]/g, ''),
    source: raw.source || `#${index}`,
  };
}

function readJsonItems(value) {
  const raw = value.startsWith('@') ? fs.readFileSync(value.slice(1), 'utf8') : value;
  let data;
  try { data = JSON.parse(raw); } catch (e) { throw new Error(`--json 不是合法 JSON: ${e.message}`); }
  const list = Array.isArray(data) ? data : [data];
  return list.map((item, idx) => normalizeItem(item, idx + 1)).filter(Boolean);
}

function parseArgs(argv) {
  const opts = {
    jsonInputs: [],
    files: [],        // 图片/PDF/Excel
    out: null,
    pollTimeout: POLL_TIMEOUT_MS,
    proof: null,      // Payment-Proof（付款后重试）
    help: false,
  };
  const need = (i, flag) => {
    if (i + 1 >= argv.length) throw new Error(`参数 ${flag} 缺少值`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    switch (arg) {
      case '--json': opts.jsonInputs.push(need(i, arg)); i++; break;
      case '--file': opts.files.push(need(i, arg)); i++; break;
      case '--out': opts.out = need(i, arg); i++; break;
      case '--poll-timeout': opts.pollTimeout = Number(need(i, arg)); i++; break;
      case '--proof': opts.proof = need(i, arg); i++; break;
      case '-h':
      case '--help': opts.help = true; break;
      default: throw new Error(`未知参数: ${arg}`);
    }
  }
  return opts;
}

function usage() {
  return `发票查验 CLI（AI Pay 额度模式）

用法：
  node verify.js --json '[{"fphm":"...","kprq":"20250701","je":"100.00"}]'
  node verify.js --file invoice.pdf --file invoice.jpg
  node verify.js --file 批量发票.xlsx
  node verify.js --proof @支付凭证.txt        # 付款后带凭证重试

参数：
  --json <json|@file>     JSON 数组或单个对象
  --file <path>           发票图片/PDF/Excel，可重复
  --out <dir>             输出目录（默认 ~/Desktop/发票查验_时间戳/）
  --poll-timeout <ms>     轮询超时（默认 600000）
  --proof <str|@file>     支付凭证 Payment-Proof（付款后重试上次查验）
  -h, --help              显示帮助

计费：
  新账号首次赠送 10 次核验额度；额度用完返回 402 付款链接
  （¥0.01/次），付款后用 --proof 重试即自动创建查验任务

输出：
  默认在桌面新建文件夹，包含查验结果 Excel 和执行日志
`;
}

// ---------------------------- 主流程 ----------------------------

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { console.log(usage()); return 0; }

  // 收集发票明细（--proof 付款重试时从待支付记录恢复，否则从入参收集）
  let allItems = [];
  let paymentProof = null;

  if (opts.proof) {
    paymentProof = loadProof(opts.proof);
    const pending = loadPendingPayment();
    if (!pending || !Array.isArray(pending.items) || pending.items.length === 0) {
      throw new Error('未找到待支付记录，请重新执行原查验命令，付款后再用 --proof 重试');
    }
    allItems = pending.items;
    console.log(`💳 付款重试：共 ${allItems.length} 张发票`);
  } else {
    if (!opts.jsonInputs.length && !opts.files.length) {
      throw new Error('至少提供 --json 或 --file');
    }

    // Step 1: 处理图片/PDF/OCR
    const ocrFiles = opts.files.filter((f) => /\.(pdf|png|jpe?g|webp|bmp)$/i.test(f));
    const excelFiles = opts.files.filter((f) => /\.(xlsx?|csv)$/i.test(f));

    for (const file of ocrFiles) {
      console.log(`🔍 OCR: ${path.basename(file)}`);
      try {
        const items = await ocrFile(file);
        console.log(`   识别到 ${items.length} 张发票`);
        allItems.push(...items);
      } catch (e) {
        console.error(`   ❌ ${e.message}`);
      }
    }

    // Step 2: 处理 Excel
    for (const file of excelFiles) {
      console.log(`📊 解析 Excel: ${path.basename(file)}`);
      try {
        const items = await importExcel(null, file);
        console.log(`   解析到 ${items.length} 张发票`);
        allItems.push(...items);
      } catch (e) {
        console.error(`   ❌ ${e.message}`);
      }
    }

    // Step 3: 处理 JSON
    for (const value of opts.jsonInputs) {
      console.log('📝 解析 JSON 数据');
      const items = readJsonItems(value);
      allItems.push(...items);
    }
  }

  if (allItems.length === 0) {
    throw new Error('没有可查验的发票记录');
  }

  // 校验四要素（AI 端点强制要求：发票号码/开票日期/金额）
  const validItems = [];
  for (const it of allItems) {
    const missing = [];
    if (!it.fphm) missing.push('发票号码fphm');
    if (!it.kprq) missing.push('开票日期kprq');
    if (!it.je) missing.push('金额je');
    if (missing.length === 0) {
      validItems.push(it);
    } else {
      console.warn(`⚠️ 跳过缺字段发票（缺 ${missing.join('、')}）: ${it.fphm || it.source || '(无号码)'}`);
    }
  }
  if (validItems.length === 0) {
    throw new Error('所有发票都缺少必填字段（发票号码/开票日期/金额），无法查验');
  }

  // 临时用户
  const token = await ensureToken();
  const cached = loadTokenCache();
  const userId = cached && cached.userId;
  if (!userId) {
    throw new Error('本地凭证缺少 userId，请删除 ~/.invoice-verify/token.json 后重试（将自动重建账号）');
  }

  // 准备输出目录
  const dateTag = new Date().toISOString().slice(0, 10);
  const outDir = opts.out || path.join(os.homedir(), 'Desktop', `发票查验_${dateTag}`);
  fs.mkdirSync(outDir, { recursive: true });
  console.log(`📁 输出目录: ${outDir}`);

  // Step 4: 通过 AI Pay 端点创建查验任务（额度模式，余额不足返回 402）
  console.log(`🚀 提交 ${validItems.length} 条查验任务...`);
  const createRes = await aiCreateTasks(token, userId, validItems, paymentProof);

  if (createRes.needPayment) {
    console.log('');
    console.log('💳 核验额度不足，需要付款');
    console.log(`   ${createRes.message}`);
    if (createRes.paymentLink) {
      console.log('');
      console.log('   👉 支付宝 AI 付预下单凭证号（amt_pre_pay_id）：');
      console.log(`   ${createRes.paymentLink}`);
    }
    console.log(`   应付金额：¥${(createRes.shortage * 0.01).toFixed(2)}（${createRes.shortage} 次 × ¥0.01/次）`);

    savePendingPayment({
      userId,
      items: validItems,
      savedAt: new Date().toISOString(),
      amtPrePayId: createRes.paymentLink,
    });
    console.log('');
    console.log('✅ 通过支付宝 AI 付渠道完成付款后，把返回的支付凭证（Payment-Proof，base64 JSON）保存为文件，执行：');
    console.log('   node verify.js --proof @凭证文件.txt');
    console.log('   将自动验付到账并创建查验任务、导出结果');
    console.log('');
    return 3; // 特殊退出码：需要付款
  }

  const queueList = createRes.queueList;
  const taskIds = queueList.map((q) => q.id).filter((x) => x != null);

  if (createRes.quota) {
    console.log(`💰 本次消耗 ${createRes.quota.consumed} 次，剩余额度 ${createRes.quota.balance} 次`);
  }

  // Step 5: 轮询
  console.log('⏳ 查验中...');
  const finalList = await pollTasks(token, taskIds);

  // Step 6: 导出 Excel
  if (finalList.length > 0) {
    try {
      await exportAndDownload(token, finalList, outDir);
    } catch (e) {
      console.error(`❌ 导出失败: ${e.message}`);
    }
  }

  // Step 6.5: 补拿截图/PDF（BFF 公网 URL，分文件夹）
  const myTasksAll = taskIds.length > 0
    ? finalList.filter((t) => taskIds.includes(t.id))
    : finalList;
  if (myTasksAll.length > 0) {
    console.log(`🖼️  补拿 ${myTasksAll.length} 张票的截图/PDF...`);
    const shotResults = await fetchScreenshots(myTasksAll, outDir);
    const got = shotResults.reduce((s, r) => s + (r.files ? r.files.length : 0), 0);
    console.log(`   ✅ 共拿到 ${got} 个文件`);
  }

  // 汇总：只关心本次创建的任务
  const myTasks = taskIds.length > 0
    ? finalList.filter((t) => taskIds.includes(t.id))
    : finalList;
  const total = myTasks.length;
  const pass = myTasks.filter((t) => t.checkStatus === 2).length;
  const fail = myTasks.filter((t) => t.checkStatus === 3).length;
  const remain = total - pass - fail;
  console.log('');
  console.log('═══ 查验结果汇总 ═══');
  console.log(`共 ${total} 张：✅ 通过 ${pass}  ❌ 失败 ${fail}  ⏳ 剩余 ${remain}`);
  console.log(`📁 结果目录: ${outDir}`);
  console.log('');

  return fail > 0 ? 1 : 0;
}

main()
  .then((code) => process.exit(code))
  .catch((e) => {
    console.error(`❌ 错误: ${e.message}`);
    process.exit(2);
  });
