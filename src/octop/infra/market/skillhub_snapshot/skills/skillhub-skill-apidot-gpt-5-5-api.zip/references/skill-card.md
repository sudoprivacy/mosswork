## Description: <br>
Use APIDot for GPT 5.5 API workflows, including OpenAI-compatible chat, long-horizon agentic execution, complex coding, research synthesis, document analysis, streaming planning, usage tracking, API key safety guidance, and APIDot docs routing. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jiehao71727](https://clawhub.ai/user/jiehao71727) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to route GPT 5.5 integration questions to APIDot documentation, model pages, examples, and safe API-key handling guidance. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Broad trigger phrases may surface this skill for general GPT API or document-analysis questions. <br>
Mitigation: Confirm the user specifically wants APIDot GPT 5.5 guidance before following APIDot links or using an APIDot API key. <br>
Risk: API keys, prompts, documents, customer data, request metadata, or generated responses could be exposed during integration work. <br>
Mitigation: Keep APIDOT_API_KEY server-side, avoid public logs or chat output for sensitive data, and use current APIDot docs for request and response details. <br>


## Reference(s): <br>
- [APIDot GPT 5.5 Reference](references/api.md) <br>
- [APIDot Docs](https://apidot.ai/docs) <br>
- [APIDot GPT 5.5 Model Page](https://apidot.ai/models/gpt-5-5) <br>
- [APIDot GPT 5.5 API Docs](https://apidot.ai/docs/gpt-5-5) <br>
- [APIDot Quickstart](https://apidot.ai/docs/quickstart) <br>
- [APIDot Error Guidance](https://apidot.ai/docs/errors) <br>
- [APIDot Examples](https://github.com/APIDotAI/apidot-examples) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, markdown, configuration] <br>
**Output Format:** [Markdown guidance with documentation links and integration notes] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Documentation-only output; no executable code or automatic API calls.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
