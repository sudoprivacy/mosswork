---
name: skillhub-skill-apidot-gpt-5-5-api
description: "APIDot API key for real API calls. Store it server-side only."
---

# APIDot GPT 5.5 API

Use APIDot as a GPT 5.5-focused API surface for long-horizon agents, complex coding, research synthesis, document analysis, streaming-aware chat planning, and usage-aware routing.

This skill is for routing GPT 5.5 questions to the right APIDot docs, model page, reference notes, and integration guidance. It is documentation-only: it includes no scripts, makes no network requests, and does not store credentials.

This release contains `SKILL.md` plus non-executable notes in `references/api.md`. It includes no executable files, install-time automation, review automation helpers, bundled API clients, automatic network calls, or stored credentials.

## Start on APIDot

Use these APIDot entry points when coming from ClawHub:

- Open the GPT 5.5 model page: https://apidot.ai/models/gpt-5-5
- Read GPT 5.5 API docs: https://apidot.ai/docs/gpt-5-5
- Open the account dashboard: https://apidot.ai/dashboard/api-key
- Use general APIDot examples: https://github.com/APIDotAI/apidot-examples

## Search Terms

Use this skill for searches and requests phrased as GPT 5.5, GPT 5 5, gpt-5.5, gpt-5-5, GPT API, OpenAI-compatible chat, long-horizon agent, agentic coding, research synthesis, document analysis, or APIDot GPT API.

## When To Use

Use this skill when the user asks to:

- Build a GPT 5.5 API integration with APIDot.
- Use GPT 5.5 as a premium escalation model for hard coding, research, document, or agent tasks.
- Plan OpenAI-compatible chat request handling, response parsing, streaming behavior, or usage tracking.
- Compare GPT 5.5 with lighter APIDot chat models for routing decisions.
- Design long-horizon agent prompts with clear objective, constraints, evidence, checks, and stopping criteria.
- Find APIDot GPT 5.5 docs, model pages, or examples.

## Security Rules

- Treat `APIDOT_API_KEY` as a secret.
- Keep APIDot API keys in server-side environment variables or a backend secret manager.
- Never place an API key in browser code, frontend bundles, public repos, logs, screenshots, or chat output.
- Do not make live API calls unless the user explicitly asks and provides a safe server-side environment.
- Treat prompts, source documents, customer data, tool inputs, generated responses, usage records, and request IDs as sensitive unless the user explicitly says they can be shared.
- Do not invent API facts, commercial terms, model availability, reliability claims, performance claims, or competitor comparisons.
- Use current APIDot docs and model pages for model-specific request fields and current product details.

## GPT 5.5 Workflow

APIDot GPT 5.5 integrations usually start by choosing the right chat path and escalation policy:

1. Confirm whether the application needs OpenAI-compatible chat behavior or a Responses-style workflow described by the current docs.
2. Use GPT 5.5 for execution-heavy tasks where sustained reasoning is worth the premium model cost.
3. Keep system instructions, conversation history, token limits, sampling controls, and streaming choices within the documented request shape.
4. Read response fields and usage fields from the current APIDot docs.
5. Store request metadata, model choice, user identity, and usage records server-side when auditability or cost routing matters.
6. Keep prompts, private documents, customer data, tool inputs, and generated responses out of public logs.

Do not guess model-specific payload fields. If the user needs copyable request examples, point them to the current APIDot docs or general APIDot examples.

## Model Routing

Start from the user's GPT 5.5 task, then open the matching APIDot source:

| User Goal | Start Here |
| --- | --- |
| Browse APIDot GPT 5.5 model page | https://apidot.ai/models/gpt-5-5 |
| Build with GPT 5.5 | https://apidot.ai/docs/gpt-5-5 |
| Read APIDot API docs | https://apidot.ai/docs |
| Learn APIDot quickstart flow | https://apidot.ai/docs/quickstart |
| Review errors and retries | https://apidot.ai/docs/errors |
| Use general APIDot examples | https://github.com/APIDotAI/apidot-examples |

For GPT 5.5 request modes, prefer the live APIDot model page and docs page. Do not copy request fields from another chat model family unless the APIDot docs show the same field.

Use `references/api.md` for a local, non-executable summary of GPT 5.5 model routing, request planning, and integration notes.

## Integration Guidance

- Use `apidot-chat-api` when the user needs broad APIDot chat guidance across several model families.
- Use this skill when the user is specifically building with GPT 5.5 through APIDot.
- Ask whether the application needs long-horizon coding, research synthesis, document analysis, agent planning, support escalation, or streaming before choosing request shape.
- Prefer the current APIDot docs for supported model IDs, request fields, streaming behavior, response wrappers, and usage fields.
- Validate conversation roles, content shape, token settings, and streaming choices before sending requests from a backend.
- Retry transient network failures with backoff. Do not retry invalid requests unchanged.
- Avoid logging API keys, private prompts, customer data, private documents, tool arguments, private context, or generated responses that may contain sensitive data.

## Official Links

- Website: https://apidot.ai
- Docs: https://apidot.ai/docs
- GPT 5.5 model page: https://apidot.ai/models/gpt-5-5
- GPT 5.5 docs: https://apidot.ai/docs/gpt-5-5
- Quickstart: https://apidot.ai/docs/quickstart
- API key dashboard: https://apidot.ai/dashboard/api-key
- Main examples: https://github.com/APIDotAI/apidot-examples
- GitHub organization: https://github.com/APIDotAI
- Support: support@apidot.ai
