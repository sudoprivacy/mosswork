---
name: skillhub-skill-graphrag-neo4j-gbrain
description: "知识图谱与向量记忆：GraphRAG 3.3.0（CT129 官方管线，全局/局部查询）、Neo4j（图存储与 Cypher 推理）、gbrain（PG 向量记忆）的集成使用指南"
---

# GraphRAG + Neo4j + gbrain 集成指南

## 架构

```
用户查询
    ↓
GraphRAG 3.3.0 (CT129, graphrag.capitaltrain.cn) — 实体关系图谱 / 社区摘要 / 全局与局部检索
    ↓
Neo4j (CT114, neo4j.capitaltrain.cn) — 谓词逻辑存储与图遍历
    ↓
gbrain (PostgreSQL via haproxy.capitaltrain.cn:5432) — 向量记忆存储
```

> 内网地址不在本文硬编码，运行时经 Consul 服务发现解析（`consul catalog service <name>`）。

> 2026-10-31 起 GraphRAG 已替换为微软官方 3.3.0 管线。旧的 12KB 手搓包装（`/api/trim`）随 LXC114 幽灵服务于 2026-10-24 退役，**不再提供记忆压缩接口**。

## GraphRAG 调用

### 健康检查

```bash
curl https://graphrag.capitaltrain.cn/health
# {"status":"ok","service":"graphrag","version":"3.3.0","index_ready":true,"indexing":false}
```

### 查询

```bash
curl -s -X POST https://graphrag.capitaltrain.cn/v1/query \
  -H "Content-Type: application/json" \
  -d '{"query":"GraphRAG 部署在哪个容器？","method":"local"}'
```

- `method`：`global`（跨域总结）、`local`（实体/局部事实）、`drift`（综述探索）、`basic`（原文事实问答，最忠实）。
- 精确事实优先 `basic` / `local`；`global` 依赖索引期社区报告，适合主题级总结。

### 重建索引

```bash
curl -s -X POST https://graphrag.capitaltrain.cn/v1/index
curl -s https://graphrag.capitaltrain.cn/v1/status
```

语料目录在 CT129 `/opt/graphrag/project/input/`。详细运维见 `seekkey/graphrag-ops`。

## Neo4j 调用

### 连接信息

- **Bolt**: 从环境变量 `NEO4J_BOLT_URL` 读取（形如 `bolt://<host>:7687`）；内网地址不写死，运行时用 `consul catalog service neo4j` 解析 CT114 的地址
- **HTTP/Browser**: `https://neo4j.capitaltrain.cn`
- **用户**: `neo4j`
- **密码**: 从 Infisical / Vault 注入的环境变量 `NEO4J_PASSWORD` 读取，严禁写入脚本

### 创建三元组

```python
import os
from neo4j import GraphDatabase

driver = GraphDatabase.driver(
    os.environ["NEO4J_BOLT_URL"],
    auth=("neo4j", os.environ["NEO4J_PASSWORD"]),
)
with driver.session() as s:
    s.run("MERGE (n:Concept {name: $name}) SET n.type = $type", name="n8n", type="tool")
    s.run("""
        MATCH (a:Concept {name: 'n8n'}), (b:Concept {name: 'Neo4j'})
        MERGE (a)-[:INTEGRATES_WITH]->(b)
    """)
driver.close()
```

### 查询关系

```python
result = s.run("""
    MATCH (a:Concept)-[r]->(b:Concept)
    RETURN a.name, type(r), b.name
""")
for record in result:
    print(f"{record['a.name']} -[{record['type(r)']}]-> {record['b.name']}")
```

## gbrain (PG 向量记忆)

### 连接信息

- **Host (HAProxy / Patroni 集群)**: `haproxy.capitaltrain.cn`
- **Port**: `5432`（写）/ `5433`（只读）
- **DB**: `gbrain`
- **User**: `gbrain`
- **密码**: 从 Infisical 读取并注入 `PGPASSWORD`，禁止硬编码

### gbrain CLI 工具（已配置就绪）

```bash
# 查看记忆库状态与切片统计
gbrain status

# 关键词/语义检索
gbrain search "三更道场" --limit 5

# 按前缀列出页面
gbrain list --prefix "canon/"
```

### 使用 pgvector 做向量搜索

```sql
CREATE EXTENSION IF NOT EXISTS vector;

INSERT INTO memories (content, embedding)
VALUES ('n8n workflow 设计', ai_embedding('n8n workflow 设计'));

SELECT content, 1 - (embedding <=> ai_embedding('工作流')) AS similarity
FROM memories
ORDER BY embedding <=> ai_embedding('工作流')
LIMIT 5;
```

## 当前模型

GraphRAG 3.3.0 通过 LiteLLM 网关调用：
- **Completion**: `vertex/gemini-3.8-flash` @ `https://litellm.capitaltrain.cn/v1`
- **Embedding**: `fleet-bge-m3`（1024 维，内网）
- **密钥**: Consul KV `litellm/keys/graphrag` / CT129 `/opt/graphrag/.env`，不落仓库
