#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风电EPC施工承包合同生成器
用法: python gen_construction_contract.py <project_profile.json> [output.docx]
读取统一项目档案的 meta + contract 段，输出专业排版 DOCX（标题层级/付款表/里程碑表/签署栏）。
条款按电力系统新能源风电工程惯例编写，商务数字取自档案，缺项以【 】占位。
"""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import office_common as oc


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = Path(sys.argv[1])
    d = json.loads(src.read_text(encoding="utf-8"))
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_name("施工承包合同.docx")
    kind = d.get("energy_kind", "wind")
    c = d["contract"]
    name = d["project_name"]
    site = d.get("site_type", "陆上")
    wtg = ""
    if d.get("wtg_count") and d.get("wtg_mw"):
        wtg = f"，机组配置{d['wtg_mw']}MW×{d['wtg_count']}台"

    doc = oc.new_doc(kind)
    oc.add_cover(doc, f"{name}\n施工承包合同",
                 f"CONSTRUCTION CONTRACT · 合同编号 {c['doc_no']}",
                 d["meta_pairs"], kind)

    doc.add_paragraph(
        "根据《中华人民共和国民法典》《中华人民共和国建筑法》《建设工程质量管理条例》"
        "《建设工程安全生产管理条例》《电力建设工程施工技术管理导则》《保障中小企业款项支付条例》"
        "等法律法规及电力行业现行标准，遵循平等、自愿、公平、诚实信用原则，发包人（甲方）与"
        "承包人（乙方）就本风力发电工程施工事宜协商一致，订立本合同，共同遵守。")

    doc.add_heading("第一章  工程概况与承包范围", level=1)
    doc.add_heading("第1条  工程概况", level=2)
    doc.add_paragraph(
        f"工程名称：{name}；建设地点：{d['location']}；工程类别：{site}风力发电场；"
        f"建设规模：装机容量{d['capacity_mw']}MW{wtg}；并网电压等级：{d['voltage']}。")
    doc.add_heading("第2条  承包范围与供货界面", level=2)
    doc.add_paragraph(c["scope"])
    doc.add_paragraph(f"甲供设备：{c['owner_supply']}。", style="List Bullet")
    doc.add_paragraph(f"乙供材料：{c['contractor_supply']}。", style="List Bullet")
    doc.add_paragraph(
        "风电机组、塔筒、主变压器等甲供大件设备的现场交货、保管、吊装配合及缺陷索赔界面，"
        "按附件《甲供设备交接与保管责任书》执行。", style="List Bullet")

    doc.add_heading("第二章  合同价款与支付", level=1)
    doc.add_heading("第3条  合同价款", level=2)
    doc.add_paragraph(
        f"本合同采用{c['price_mode']}方式。暂定合同价款为人民币{c['contract_price_text']}"
        f"（¥{c['contract_price_cny']:,.2f}），含增值税。工程量按竣工图及现场实测计量，"
        f"综合单价除约定可调因素外原则上固定，最终以经审定的竣工结算为准。")
    doc.add_heading("第4条  工程款支付节点", level=2)
    oc.add_table(doc, ["支付节点", "支付比例", "支付条件"],
                 c["payment_nodes"], kind, widths=[3.5, 3.0, 8.5])
    doc.add_paragraph(
        "工程款支付前乙方应提供等额合规增值税专用发票；甲方按《保障中小企业款项支付条例》"
        "约定账期付款，不得以其上游回款作为拒付、迟付理由。", style="List Bullet")

    doc.add_heading("第三章  工期与关键节点", level=1)
    doc.add_heading("第5条  工期", level=2)
    doc.add_paragraph(
        f"总工期{c['duration_days']}日历天。计划开工日期以甲方书面开工令为准；"
        f"因甲方原因、设计变更、甲供设备迟供、不可抗力及异常恶劣天气（含大风窗口期不满足吊装条件）"
        f"导致的停窝工，经书面签证后相应顺延工期。")
    doc.add_heading("第6条  关键里程碑", level=2)
    oc.add_table(doc, ["里程碑节点", "计划完成时间"], c["milestones"], kind,
                 widths=[8.0, 7.0])

    doc.add_heading("第四章  质量、安全与验收", level=1)
    doc.add_heading("第7条  质量标准", level=2)
    doc.add_paragraph(f"工程质量应达到国家及电力行业现行验收规范合格标准，执行{c['quality_std']}")
    doc.add_heading("第8条  安全生产与农民工权益", level=2)
    doc.add_paragraph(
        "乙方须建立安全生产责任制，落实安全文明施工措施，重大危险性作业（大型起重吊装、"
        "临近带电体作业、高处作业、有限空间作业等）编制专项方案并按规定组织专家论证；"
        "实行农民工实名制管理并设立工资专用账户，甲方按合同约定将人工费拨入专户，"
        "保障农民工工资按月足额支付。")
    doc.add_heading("第9条  验收", level=2)
    doc.add_paragraph(
        "按隐蔽工程、分部分项、单位工程分级验收；风机基础、接地装置、集电线路等隐蔽工程"
        "须经监理旁站与影像留档；单机调试、并网调试与整场性能考核（含可利用率、功率曲线）"
        "合格后方可进入试运行及移交。验收不合格由承包人限期返工，费用自负，工期不予顺延。")

    doc.add_heading("第五章  变更、结算、违约与争议", level=1)
    doc.add_heading("第10条  工程变更与现场签证", level=2)
    doc.add_paragraph(
        "变更须由甲方或监理书面指令；现场签证应在事件发生后7日内报送，逾期视为承包人"
        "认可现状。计价有对应单价的按单价执行，无单价的由双方协商确定并签认价格确认单。"
        "签证坚持“一事一签、当期双签”，无书面签认不予计入结算。")
    doc.add_heading("第11条  竣工结算", level=2)
    doc.add_paragraph(
        "乙方应于竣工验收合格后28日内提交完整结算资料；甲方（或其委托的造价咨询单位）"
        "应在收到之日起28日内完成审核，逾期未提出书面异议的，视同认可结算文件。"
        "无争议部分应先行支付，不得以“以最终审计为准”无限期拖延结算与付款。")
    doc.add_heading("第12条  违约责任", level=2)
    doc.add_paragraph(c["delay_penalty"])
    doc.add_heading("第13条  争议解决", level=2)
    doc.add_paragraph("因本合同发生的争议，双方协商不成的，提交工程所在地人民法院诉讼解决。")

    doc.add_heading("第六章  附则", level=1)
    doc.add_paragraph(f"缺陷责任期（质保期）为{c['warranty_months']}个月，自整场竣工验收合格之日起算。")
    doc.add_paragraph("本合同附件与本合同具有同等法律效力，包括但不限于：", style="List Bullet")
    for a in c["attachments"]:
        doc.add_paragraph(a, style="List Bullet")
    doc.add_paragraph(
        "【法律提示】本文本为工作底稿，合同价款为暂定值，签署前须经法务与造价审核，"
        "最终以经审定的竣工结算为准。")

    doc.add_heading("签署栏", level=1)
    oc.add_signature_block(doc, [
        ("发包人（甲方）", [f"单位（章）：{d['owner']}", "法定代表人/授权代表：", "日期：      年   月   日"]),
        ("承包人（乙方）", [f"单位（章）：{d['contractor']}", "法定代表人/授权代表：", "日期：      年   月   日"]),
    ], kind)

    oc.add_footer(doc, f"{d['project_short']} · 施工承包合同（{c['doc_no']}）")
    doc.save(out)
    print(f"OK 施工承包合同已生成: {out}")


if __name__ == "__main__":
    main()
