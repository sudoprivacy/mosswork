#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风电EPC汇报PPT生成器（16:9 主题化，计价单位 元/kW）
用法: python gen_report_pptx.py <project_profile.json> <type> [output.pptx]
  type = budget     成本/预算汇报（读 categories + meta；末页含成本价vs项目报价判定）
       = scheme     施工方案汇报（读 org + contract）
       = settlement 结算汇报（读 settlement 段；末页明确本项目是否盈利）
"""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import office_common as oc

CHECK_ONSHORE = (4500, 8000)
CHECK_OFFSHORE = (10000, 18000)


def _check_range(d):
    return CHECK_OFFSHORE if "海" in d.get("site_type", "陆上") else CHECK_ONSHORE


def cost_summary(d):
    """返回 (各科目[(name,万元,占比%)], 总投资万元, 元/kW)。"""
    cap_kw = d["capacity_mw"] * 1e3
    cats, grand = [], 0.0
    for c in d["categories"]:
        sub = sum(it["qty"] * it["price"] / 1e4 for it in c["items"])
        cats.append([c["name"], sub]); grand += sub
    unit = grand * 1e4 / cap_kw
    rows = [[n, f"{v:,.0f}", f"{v/grand*100:.1f}%"] for n, v in cats]
    return rows, grand, unit


# ============================ 成本/预算汇报 ============================
def build_budget(deck, d):
    name = d["project_name"]
    rows, grand, unit = cost_summary(d)
    lo, hi = _check_range(d)
    site = d.get("site_type", "陆上")
    deck.cover(f"{name}\n成本预算汇报",
               f"COST BUDGET REVIEW · {d['capacity_mw']}MW {site}风电",
               [f"建设地点：{d['location']}",
                f"编制单位：{d['contractor']}",
                f"汇报日期：{d['date']}"])
    bench = d.get("benchmark_price_per_kw")
    toc_items = ["项目概况", "投资总额与单位造价", "成本构成分析"]
    if bench:
        toc_items.append("成本价与项目报价对比判定")
    toc_items.append("结论与建议")
    deck.toc(toc_items)

    deck.section("项目概况", f"{d['capacity_mw']}MW {site}风电场")
    wtg = ""
    if d.get("wtg_count") and d.get("wtg_mw"):
        wtg = f"机组配置 {d['wtg_mw']}MW×{d['wtg_count']}台；"
    deck.content("一、项目概况", [
        ("建设规模", f"{wtg}装机容量 {d['capacity_mw']}MW，并网电压等级 {d['voltage']}。"),
        ("建设地点", d["location"]),
        ("计价口径", d["tax_note"] + "，全表统一口径，避免重复计税。"),
    ])

    deck.section("投资总额与单位造价")
    deck.kpi("二、投资关键指标", [
        (f"{grand/10000:.2f}", "静态总投资（亿元）"),
        (f"{unit:,.0f}", "单位造价（元/kW）"),
        (f"{d['capacity_mw']}", "装机（MW）"),
        ("✔" if lo <= unit <= hi else "⚠", "造价区间校核"),
    ])

    deck.section("成本构成分析")
    deck.table_slide("三、成本科目构成", ["费用科目", "金额（万元）", "占总投资"],
                     rows, note="标注\"指标估算\"项以询价/合同价为准。")

    # —— 末页判定：成本价 vs 项目给出价（红色明确"可以施工/不可施工"）——
    concl_no = "五" if bench else "四"
    if bench:
        bench = float(bench)
        diff = bench - unit
        diff_wan = diff * d["capacity_mw"] * 1e3 / 1e4
        feasible = unit <= bench
        verdict = "结论：可以施工 ✔" if feasible else "结论：不可施工 ✘"
        if feasible:
            detail = (f"成本价 {unit:,.0f} 元/kW ≤ 项目给出价 {bench:,.0f} 元/kW，"
                      f"盈余 {diff:,.0f} 元/kW（约 {diff_wan:,.0f} 万元，占项目给出总额 {diff/bench*100:.1f}%）")
        else:
            detail = (f"成本价 {unit:,.0f} 元/kW ＞ 项目给出价 {bench:,.0f} 元/kW，"
                      f"超出 {-diff:,.0f} 元/kW（约 {-diff_wan:,.0f} 万元），须降本或重新议价")
        deck.section("成本价与项目报价对比判定", "成本测算价 vs 项目给出价")
        deck.verdict("四、成本价与项目报价对比判定",
                     [(f"{unit:,.0f} 元/kW", "成本价（本次测算）"),
                      (f"{bench:,.0f} 元/kW", "项目给出价（对比/限价）"),
                      (f"{diff:+,.0f} 元/kW", "差额（给出价−成本价）")],
                     verdict, detail)

    deck.section("结论与建议")
    concl_blocks = [
        ("造价水平", f"单位造价 {unit:,.0f} 元/kW，"
         + ("处于行业合理区间。" if lo <= unit <= hi else "偏离参考区间，建议复核科目与单价。")),
        ("成本重点", "风电机组（含塔筒）占比最高，机组集采与吊装组织为降本关键；集电线路与基础次之。"),
        ("风险提示", "大件运输与吊装措施费须逐项单列；主材（钢材/铜/机组）价格波动建议约定调价机制。"),
    ]
    if bench:
        concl_blocks.insert(0, ("对比判定",
                                ("可以施工：成本价低于项目给出价，按当前成本方案推进并锁定机组与主材价格。" if unit <= bench
                                 else "不可施工：成本价高于项目给出价，须先降本（机组集采/优化基础与道路/削减措施费）或重新议价。")))
    deck.content(f"{concl_no}、结论与建议", concl_blocks)
    deck.closing()


# ============================ 施工方案汇报 ============================
def build_scheme(deck, d):
    name, o, c = d["project_name"], d["org"], d["contract"]
    site = d.get("site_type", "陆上")
    deck.cover(f"{name}\n施工方案汇报",
               f"CONSTRUCTION SCHEME · {d['capacity_mw']}MW {site}风电",
               [f"建设地点：{d['location']}",
                f"总承包单位：{d['contractor']}",
                f"汇报日期：{d['date']}"])
    deck.toc(["工程概况", "施工部署", "总进度计划", "主要施工方案", "质量安全保障"])
    deck.section("工程概况")
    deck.content("一、工程概况", [
        ("工程规模", o["overview"]),
        ("承包范围", c["scope"]),
    ])
    deck.section("施工部署与进度")
    deck.content("二、施工部署", [("总体部署", o["deploy"])])
    deck.table_slide("三、总进度计划（共%d天）" % o["duration_days"],
                     ["施工阶段", "计划时间"], o["schedule"])
    deck.section("主要施工方案")
    deck.content("四、主要施工方案", [(t, b) for t, b in o["methods"]])
    deck.section("质量安全保障")
    deck.content("五、质量·安全·文明施工", [
        ("质量保证", o["quality"]),
        ("安全生产", o["safety"]),
        ("文明施工", o["civilized"]),
    ])
    deck.closing("方案汇报完毕 · 敬请指正")


# ============================ 竣工结算汇报 ============================
def _calc_side(side):
    within = sum(r[2] for r in side["contract_items"])
    adj = sum(r[1] for r in side["adjustments"])
    ded = sum(r[1] for r in side["deductions"])
    total = within + adj + ded
    return dict(within=within, adj=adj, ded=ded, total=total)


def build_settlement(deck, d):
    name = d["project_name"]
    st = d["settlement"]
    ow, sb = st["to_owner"], st["to_sub"]
    cow, csb = _calc_side(ow), _calc_side(sb)
    site = d.get("site_type", "陆上")

    # 项目利润 = 对甲方结算收入 − 全成本（对乙方施工分包 + 其他成本台账）
    other_cost = st.get("other_cost_cny", 0)   # 设备采购/设计/监理等其他成本合计（元）
    total_cost = csb["total"] + other_cost
    profit = cow["total"] - total_cost
    margin = profit / cow["total"] * 100 if cow["total"] else 0
    is_profit = profit >= 0

    deck.cover(f"{name}\n竣工结算汇报",
               f"FINAL SETTLEMENT · {d['capacity_mw']}MW {site}风电",
               [f"结算编号：{st['report_no']}",
                f"承包单位：{d['contractor']}",
                f"汇报日期：{d['date']}"])
    deck.toc(["结算概述", "对甲方结算（收入）", "对乙方结算（支出）",
              "利润测算", "本项目盈亏判定"])

    deck.section("结算概述")
    deck.content("一、结算概述", [
        ("项目情况", f"{d['capacity_mw']}MW {site}风电场，已全容量并网并通过竣工验收。"),
        ("结算依据", "EPC合同及补充协议、设计变更、现场签证、竣工图与实测工程量、政策性文件。"),
        ("计价口径", d["tax_note"] + "，全套结算文件统一口径。"),
    ])

    deck.section("对甲方结算（收入侧）")
    deck.kpi("二、对甲方结算关键指标", [
        (f"{ow['contract_price']/1e8:.4f}", "合同价（亿元）"),
        (f"{cow['total']/1e8:.4f}", "结算总额（亿元）"),
        (f"{cow['adj']/1e4:,.0f}", "变更签证增加（万元）"),
        (f"{cow['ded']/1e4:,.0f}", "扣减合计（万元）"),
    ])

    deck.section("对乙方结算（支出侧）")
    deck.table_slide("三、对乙方（施工分包）结算构成",
                     ["项目", "金额（万元）"],
                     [["合同内按实结算", f"{csb['within']/1e4:,.2f}"],
                      ["调整增加（变更/签证/价差）", f"{csb['adj']/1e4:,.2f}"],
                      ["扣减合计", f"{csb['ded']/1e4:,.2f}"],
                      ["对乙方结算总额", f"{csb['total']/1e4:,.2f}"]],
                     note="支出侧仅含施工分包；设备/设计/监理等其他成本按各自合同另册归集。")

    deck.section("利润测算")
    deck.kpi("四、项目全成本利润测算", [
        (f"{cow['total']/1e8:.4f}", "结算收入（亿元）"),
        (f"{total_cost/1e8:.4f}", "全成本（亿元）"),
        (f"{profit/1e4:,.0f}", "利润（万元）"),
        (f"{margin:.1f}%", "利润率"),
    ])

    # —— 末页判定：本项目是否盈利（红色明确结论）——
    deck.section("本项目盈亏判定", "结算收入 − 全成本")
    if is_profit:
        verdict = "结论：本项目盈利 ✔"
        detail = (f"结算收入 {cow['total']/1e4:,.2f} 万元 − 全成本 {total_cost/1e4:,.2f} 万元 "
                  f"= 利润 {profit/1e4:,.2f} 万元，利润率 {margin:.1f}%")
    else:
        verdict = "结论：本项目亏损 ✘"
        detail = (f"结算收入 {cow['total']/1e4:,.2f} 万元 − 全成本 {total_cost/1e4:,.2f} 万元 "
                  f"= 亏损 {-profit/1e4:,.2f} 万元，利润率 {margin:.1f}%，须复盘成本超支与索赔挂账")
    deck.verdict("五、本项目盈亏判定",
                 [(f"{cow['total']/1e4:,.0f} 万元", "结算收入（对甲方）"),
                  (f"{total_cost/1e4:,.0f} 万元", "全成本（分包+其他）"),
                  (f"{profit/1e4:+,.0f} 万元", "利润（收入−成本）")],
                 verdict, detail)
    deck.closing("结算汇报完毕 · 敬请审定")


BUILDERS = {"budget": build_budget, "scheme": build_scheme, "settlement": build_settlement}
NAMES = {"budget": "成本预算汇报", "scheme": "施工方案汇报", "settlement": "竣工结算汇报"}


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    src = Path(sys.argv[1]); rtype = sys.argv[2]
    if rtype not in BUILDERS:
        sys.exit(f"未知类型 {rtype}，可选: {list(BUILDERS)}")
    d = json.loads(src.read_text(encoding="utf-8"))
    out = Path(sys.argv[3]) if len(sys.argv) > 3 else src.with_name(NAMES[rtype] + ".pptx")
    deck = oc.Deck(d.get("energy_kind", "wind"))
    BUILDERS[rtype](deck, d)
    deck.save(out)
    print(f"OK {NAMES[rtype]}已生成: {out} (共{len(deck.prs.slides._sldIdLst)}页)")


if __name__ == "__main__":
    main()
