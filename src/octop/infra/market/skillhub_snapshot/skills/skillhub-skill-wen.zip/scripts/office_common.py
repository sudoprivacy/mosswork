# -*- coding: utf-8 -*-
"""
office_common.py —— 风电EPC文档/演示共享排版引擎
供 gen_construction_contract.py / gen_construction_org.py / gen_report_pptx.py 复用。
提供：统一主题色、DOCX 专业样式（标题层级/表格/封面/签署栏）、PPTX 主题化 Deck。
依赖：python-docx, python-pptx
"""
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from pptx import Presentation
from pptx.util import Inches, Pt as PPt, Emu
from pptx.dml.color import RGBColor as PColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# ---------------- 主题（按能源类型切换配色） ----------------
THEMES = {
    "pv":      {"primary": "1F6E43", "accent": "35A26A", "dark": "0E3B24", "light": "E4F1EA", "name": "光伏"},
    "wind":    {"primary": "1F5FA8", "accent": "3E86D6", "dark": "123A66", "light": "E1ECF9", "name": "风电"},
    "storage": {"primary": "9A5B12", "accent": "D08A2A", "dark": "5E3708", "light": "F6EAD5", "name": "储能"},
}

def theme(kind="pv"):
    return THEMES.get(kind, THEMES["pv"])

def _rgb(hexs):
    return RGBColor(int(hexs[0:2], 16), int(hexs[2:4], 16), int(hexs[4:6], 16))

def _prgb(hexs):
    return PColor(int(hexs[0:2], 16), int(hexs[2:4], 16), int(hexs[4:6], 16))

# ======================================================================
#  DOCX 部分
# ======================================================================
CN_FONT = "微软雅黑"
CN_BODY = "宋体"
EN_FONT = "Times New Roman"

def _set_style_font(style, cn, en, size=None, bold=None, color=None):
    f = style.font
    f.name = en
    if size is not None:
        f.size = Pt(size)
    if bold is not None:
        f.bold = bold
    if color is not None:
        f.color.rgb = _rgb(color)
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:eastAsia"), cn)
    rfonts.set(qn("w:ascii"), en)
    rfonts.set(qn("w:hAnsi"), en)

def new_doc(kind="pv"):
    """创建带完整专业样式的文档。"""
    th = theme(kind)
    doc = Document()
    # 页面 A4 + 页边距
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    sec.top_margin = sec.bottom_margin = Cm(2.5)
    sec.left_margin = sec.right_margin = Cm(2.8)

    st = doc.styles
    _set_style_font(st["Normal"], CN_BODY, EN_FONT, size=10.5, color="222222")
    st["Normal"].paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    st["Normal"].paragraph_format.line_spacing = 1.35
    st["Normal"].paragraph_format.space_after = Pt(4)

    for name, size, color in [("Heading 1", 15, th["primary"]),
                              ("Heading 2", 12.5, th["dark"]),
                              ("Heading 3", 11, th["dark"])]:
        if name in st:
            _set_style_font(st[name], CN_FONT, EN_FONT, size=size, bold=True, color=color)
            st[name].paragraph_format.space_before = Pt(10)
            st[name].paragraph_format.space_after = Pt(6)
    if "Title" in st:
        _set_style_font(st["Title"], CN_FONT, EN_FONT, size=22, bold=True, color=th["primary"])
    if "List Bullet" in st:
        _set_style_font(st["List Bullet"], CN_BODY, EN_FONT, size=10.5, color="222222")
    doc._pv_theme = th
    return doc

def add_cover(doc, title, subtitle, meta_pairs, kind="pv"):
    """封面：色带标题 + 副标题 + 信息表。"""
    th = theme(kind)
    for _ in range(2):
        doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(title)
    run.font.name = CN_FONT
    run.font.size = Pt(26)
    run.font.bold = True
    run.font.color.rgb = _rgb(th["primary"])
    rpr = run._element.get_or_add_rPr()
    rf = OxmlElement("w:rFonts"); rf.set(qn("w:eastAsia"), CN_FONT); rpr.append(rf)
    # 装饰横线
    hr = doc.add_paragraph(); hr.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _bottom_border(hr, th["accent"])
    sp = doc.add_paragraph(); sp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = sp.add_run(subtitle); r2.font.size = Pt(13); r2.font.color.rgb = _rgb(th["dark"])
    r2.font.name = CN_FONT
    rpr = r2._element.get_or_add_rPr(); rf = OxmlElement("w:rFonts"); rf.set(qn("w:eastAsia"), CN_FONT); rpr.append(rf)
    for _ in range(3):
        doc.add_paragraph()
    # 信息表
    t = doc.add_table(rows=0, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for k, v in meta_pairs:
        row = t.add_row().cells
        row[0].text = k; row[1].text = str(v)
        _cell_style(row[0], bold=True, bg=th["light"], w=Cm(4.5))
        _cell_style(row[1], w=Cm(10))
    _table_borders(t, th["accent"])
    doc.add_page_break()

def _bottom_border(paragraph, color):
    pPr = paragraph._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), "18")
    bottom.set(qn("w:space"), "6"); bottom.set(qn("w:color"), color)
    pbdr.append(bottom); pPr.append(pbdr)

def _cell_style(cell, bold=False, bg=None, align=None, color=None, w=None, size=10):
    if w is not None:
        cell.width = w
    for p in cell.paragraphs:
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.space_before = Pt(2)
        if align == "center":
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif align == "right":
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        for r in p.runs:
            r.font.bold = bold; r.font.size = Pt(size)
            r.font.name = CN_BODY
            if color:
                r.font.color.rgb = _rgb(color)
            rpr = r._element.get_or_add_rPr()
            rf = OxmlElement("w:rFonts"); rf.set(qn("w:eastAsia"), CN_BODY); rpr.append(rf)
    if bg:
        tcPr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear")
        shd.set(qn("w:fill"), bg); tcPr.append(shd)
    # 垂直居中
    tcPr = cell._tc.get_or_add_tcPr()
    va = OxmlElement("w:vAlign"); va.set(qn("w:val"), "center"); tcPr.append(va)

def _table_borders(table, color="999999", sz="6"):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}")
        e.set(qn("w:val"), "single"); e.set(qn("w:sz"), sz)
        e.set(qn("w:space"), "0"); e.set(qn("w:color"), color)
        borders.append(e)
    tblPr.append(borders)

def add_table(doc, headers, rows, kind="pv", widths=None, first_col_left=True):
    """带表头底色的专业表格。"""
    th = theme(kind)
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = str(h)
        _cell_style(hdr[i], bold=True, bg=th["primary"], align="center", color="FFFFFF")
    for r_i, row in enumerate(rows):
        cells = t.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = "" if val is None else str(val)
            al = "left" if (i == 0 and first_col_left) else "center"
            bg = th["light"] if r_i % 2 == 1 else None
            _cell_style(cells[i], bg=bg, align=al)
    if widths:
        for i, w in enumerate(widths):
            for row in t.rows:
                row.cells[i].width = Cm(w)
    _table_borders(t, th["accent"])
    doc.add_paragraph()
    return t

def add_footer(doc, text):
    sec = doc.sections[0]
    p = sec.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text)
    r.font.size = Pt(8); r.font.color.rgb = _rgb("888888")
    r.font.name = CN_BODY

def add_signature_block(doc, parties, kind="pv"):
    """签署栏：parties = [(甲方标签, 内容行列表), ...]"""
    doc.add_paragraph()
    t = doc.add_table(rows=0, cols=len(parties))
    for r in range(4):
        cells = t.add_row().cells
        for c, (label, lines) in enumerate(parties):
            cells[c].text = (label if r == 0 else (lines[r-1] if r-1 < len(lines) else ""))
            _cell_style(cells[c], bold=(r == 0), align="left", size=10.5)


# ======================================================================
#  PPTX 部分  (16:9 主题化 Deck)
# ======================================================================
class Deck:
    def __init__(self, kind="pv"):
        self.th = theme(kind)
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)
        self.prs.slide_height = Inches(7.5)
        self.W, self.H = self.prs.slide_width, self.prs.slide_height
        self.blank = self.prs.slide_layouts[6]
        self._section_no = 0

    # --- 基础绘制 ---
    def _slide(self):
        return self.prs.slides.add_slide(self.blank)

    def _rect(self, s, x, y, w, h, hexc, line=None):
        sh = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
        sh.fill.solid(); sh.fill.fore_color.rgb = _prgb(hexc)
        if line:
            sh.line.color.rgb = _prgb(line); sh.line.width = PPt(1)
        else:
            sh.line.fill.background()
        sh.shadow.inherit = False
        return sh

    def _text(self, s, x, y, w, h, text, size, color, bold=False,
              align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, font="微软雅黑", spacing=1.1):
        tb = s.shapes.add_textbox(x, y, w, h)
        tf = tb.text_frame; tf.word_wrap = True
        tf.vertical_anchor = anchor
        lines = text.split("\n")
        for i, ln in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align; p.line_spacing = spacing
            r = p.add_run(); r.text = ln
            r.font.size = PPt(size); r.font.bold = bold
            r.font.name = font; r.font.color.rgb = _prgb(color)
        return tb

    def _footer(self, s, note):
        self._rect(s, 0, self.H - Inches(0.32), self.W, Inches(0.32), self.th["dark"])
        self._text(s, Inches(0.5), self.H - Inches(0.33), Inches(8), Inches(0.3),
                   note, 9, "FFFFFF", anchor=MSO_ANCHOR.MIDDLE)
        self._text(s, self.W - Inches(3.5), self.H - Inches(0.33), Inches(3), Inches(0.3),
                   "wind-epc-manager", 9, "FFFFFF", align=PP_ALIGN.RIGHT, anchor=MSO_ANCHOR.MIDDLE)

    # --- 幻灯片类型 ---
    def cover(self, title, subtitle, meta_lines):
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, self.th["dark"])
        self._rect(s, 0, Inches(2.4), self.W, Inches(0.12), self.th["accent"])
        self._rect(s, Inches(0.9), Inches(2.7), Inches(6), Inches(1.6),
                   self.th["dark"])  # spacer (same color) — keep title clean
        self._text(s, Inches(0.9), Inches(2.6), Inches(11.5), Inches(1.7),
                   title, 40, "FFFFFF", bold=True)
        self._text(s, Inches(0.95), Inches(4.3), Inches(11), Inches(0.7),
                   subtitle, 20, self.th["accent"], bold=True)
        self._text(s, Inches(0.95), Inches(5.6), Inches(11), Inches(1.2),
                   "\n".join(meta_lines), 14, "D6E4EC")
        return s

    def toc(self, items):
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, "FFFFFF")
        self._rect(s, 0, 0, Inches(4.2), self.H, self.th["primary"])
        self._text(s, Inches(0.6), Inches(0.9), Inches(3.2), Inches(1.2),
                   "目录\nCONTENTS", 30, "FFFFFF", bold=True)
        y = Inches(1.1)
        for i, it in enumerate(items, 1):
            self._text(s, Inches(4.7), y, Inches(0.9), Inches(0.7),
                       f"{i:02d}", 26, self.th["accent"], bold=True)
            self._text(s, Inches(5.7), y + Inches(0.05), Inches(7), Inches(0.7),
                       it, 18, self.th["dark"], bold=True, anchor=MSO_ANCHOR.MIDDLE)
            y += Inches(1.05)
        self._footer(s, "")
        return s

    def section(self, title, subtitle=""):
        self._section_no += 1
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, self.th["primary"])
        self._text(s, Inches(0.9), Inches(2.6), Inches(3), Inches(2),
                   f"{self._section_no:02d}", 96, self.th["accent"], bold=True)
        self._rect(s, Inches(0.95), Inches(4.3), Inches(4), Inches(0.08), "FFFFFF")
        self._text(s, Inches(0.95), Inches(4.5), Inches(11), Inches(1.2),
                   title, 32, "FFFFFF", bold=True)
        if subtitle:
            self._text(s, Inches(0.98), Inches(5.6), Inches(11), Inches(0.8),
                       subtitle, 15, "D6E4EC")
        return s

    def content(self, title, blocks):
        """blocks = [(小标题, 正文), ...] 卡片式排布。"""
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, "FFFFFF")
        self._rect(s, 0, 0, self.W, Inches(1.15), self.th["primary"])
        self._rect(s, Inches(0.55), Inches(0.28), Inches(0.14), Inches(0.6), self.th["accent"])
        self._text(s, Inches(0.85), Inches(0.2), Inches(11.5), Inches(0.8),
                   title, 24, "FFFFFF", bold=True, anchor=MSO_ANCHOR.MIDDLE)
        y = Inches(1.5)
        gap = (self.H - Inches(1.5) - Inches(0.5)) / max(len(blocks), 1)
        for sub, body in blocks:
            self._rect(s, Inches(0.6), y + Inches(0.05), Inches(0.1), gap - Inches(0.35),
                       self.th["accent"])
            self._text(s, Inches(0.9), y, Inches(11.6), Inches(0.5),
                       sub, 16, self.th["primary"], bold=True)
            self._text(s, Inches(0.92), y + Inches(0.5), Inches(11.6), gap - Inches(0.7),
                       body, 13, "333333", spacing=1.25)
            y += gap
        self._footer(s, "")
        return s

    def table_slide(self, title, headers, rows, note=""):
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, "FFFFFF")
        self._rect(s, 0, 0, self.W, Inches(1.15), self.th["primary"])
        self._rect(s, Inches(0.55), Inches(0.28), Inches(0.14), Inches(0.6), self.th["accent"])
        self._text(s, Inches(0.85), Inches(0.2), Inches(11.5), Inches(0.8),
                   title, 24, "FFFFFF", bold=True, anchor=MSO_ANCHOR.MIDDLE)
        rN, cN = len(rows) + 1, len(headers)
        gt = s.shapes.add_table(rN, cN, Inches(0.7), Inches(1.5),
                                Inches(11.9), Inches(0.5) * rN).table
        for i, h in enumerate(headers):
            c = gt.cell(0, i); c.text = str(h)
            self._style_ppt_cell(c, bold=True, bg=self.th["primary"], color="FFFFFF", size=12)
        for r_i, row in enumerate(rows, 1):
            for c_i, val in enumerate(row):
                c = gt.cell(r_i, c_i); c.text = "" if val is None else str(val)
                bg = self.th["light"] if r_i % 2 == 0 else "FFFFFF"
                al = PP_ALIGN.LEFT if c_i == 0 else PP_ALIGN.CENTER
                self._style_ppt_cell(c, bg=bg, color="333333", size=11, align=al)
        if note:
            self._text(s, Inches(0.7), self.H - Inches(0.75), Inches(11), Inches(0.4),
                       note, 10, "888888")
        self._footer(s, "")
        return s

    def _style_ppt_cell(self, cell, bold=False, bg="FFFFFF", color="333333",
                        size=11, align=PP_ALIGN.CENTER):
        cell.fill.solid(); cell.fill.fore_color.rgb = _prgb(bg)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        cell.margin_left = Inches(0.1); cell.margin_right = Inches(0.08)
        cell.margin_top = Inches(0.02); cell.margin_bottom = Inches(0.02)
        for p in cell.text_frame.paragraphs:
            p.alignment = align
            for r in p.runs:
                r.font.size = PPt(size); r.font.bold = bold
                r.font.name = "微软雅黑"; r.font.color.rgb = _prgb(color)

    def kpi(self, title, cards):
        """cards = [(数值, 标签), ...] 最多4张。"""
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, "FFFFFF")
        self._rect(s, 0, 0, self.W, Inches(1.15), self.th["primary"])
        self._rect(s, Inches(0.55), Inches(0.28), Inches(0.14), Inches(0.6), self.th["accent"])
        self._text(s, Inches(0.85), Inches(0.2), Inches(11.5), Inches(0.8),
                   title, 24, "FFFFFF", bold=True, anchor=MSO_ANCHOR.MIDDLE)
        n = len(cards); cw = Inches(2.9); gap = Inches(0.3)
        total = cw * n + gap * (n - 1)
        x = (self.W - total) / 2
        for val, label in cards:
            self._rect(s, x, Inches(2.6), cw, Inches(2.2), self.th["light"])
            self._rect(s, x, Inches(2.6), cw, Inches(0.12), self.th["accent"])
            self._text(s, x, Inches(3.0), cw, Inches(1.0), str(val), 30,
                       self.th["primary"], bold=True, align=PP_ALIGN.CENTER,
                       anchor=MSO_ANCHOR.MIDDLE)
            self._text(s, x, Inches(4.0), cw, Inches(0.6), label, 14, "555555",
                       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            x += cw + gap
        self._footer(s, "")
        return s

    def verdict(self, title, cards, verdict_text, detail=""):
        """报价对比判定页：对比卡片 + 红色大字明确结论。
        cards = [(数值, 标签), ...]；verdict_text 以红色加粗大字显示（如"结论：可以实施"）。
        """
        RED = "C00000"
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, "FFFFFF")
        self._rect(s, 0, 0, self.W, Inches(1.15), self.th["primary"])
        self._rect(s, Inches(0.55), Inches(0.28), Inches(0.14), Inches(0.6), self.th["accent"])
        self._text(s, Inches(0.85), Inches(0.2), Inches(11.5), Inches(0.8),
                   title, 24, "FFFFFF", bold=True, anchor=MSO_ANCHOR.MIDDLE)
        # 对比卡片
        n = max(len(cards), 1)
        cw = Inches(3.4); gap = Inches(0.35)
        total = cw * n + gap * (n - 1)
        x = (self.W - total) / 2
        for val, label in cards:
            self._rect(s, x, Inches(1.65), cw, Inches(1.9), self.th["light"])
            self._rect(s, x, Inches(1.65), cw, Inches(0.1), self.th["accent"])
            self._text(s, x, Inches(1.95), cw, Inches(0.95), str(val), 28,
                       self.th["primary"], bold=True, align=PP_ALIGN.CENTER,
                       anchor=MSO_ANCHOR.MIDDLE)
            self._text(s, x, Inches(2.95), cw, Inches(0.5), label, 13, "555555",
                       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            x += cw + gap
        # 红色结论横幅（明确答案）
        self._rect(s, Inches(1.2), Inches(4.05), self.W - Inches(2.4), Inches(1.55),
                   "FDECEC", line=RED)
        self._text(s, Inches(1.2), Inches(4.2), self.W - Inches(2.4), Inches(0.95),
                   verdict_text, 34, RED, bold=True, align=PP_ALIGN.CENTER,
                   anchor=MSO_ANCHOR.MIDDLE)
        if detail:
            self._text(s, Inches(1.4), Inches(5.15), self.W - Inches(2.8), Inches(0.5),
                       detail, 13, RED, align=PP_ALIGN.CENTER)
        self._footer(s, "")
        return s

    def closing(self, text="感谢聆听 · 敬请指正"):
        s = self._slide()
        self._rect(s, 0, 0, self.W, self.H, self.th["dark"])
        self._rect(s, Inches(4.6), Inches(3.9), Inches(4), Inches(0.1), self.th["accent"])
        self._text(s, 0, Inches(2.9), self.W, Inches(1), text, 34, "FFFFFF",
                   bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        return s

    def save(self, path):
        self.prs.save(path)
