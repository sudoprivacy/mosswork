#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风电EPC施工组织设计生成器
用法: python gen_construction_org.py <project_profile.json> [output.docx]
读取统一项目档案的 meta + org 段，输出专业排版 DOCX。
"""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import office_common as oc


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = Path(sys.argv[1])
    d = json.loads(src.read_text(encoding="utf-8"))
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_name("施工组织设计.docx")
    kind = d.get("energy_kind", "wind")
    o = d["org"]
    name = d["project_name"]

    doc = oc.new_doc(kind)
    oc.add_cover(doc, f"{name}\n施工组织设计",
                 f"CONSTRUCTION ORGANIZATION DESIGN · 编号 {o['doc_no']}",
                 d["meta_pairs"], kind)

    doc.add_heading("第一章  编制依据与工程概况", level=1)
    doc.add_heading("第1条  编制依据", level=2)
    doc.add_paragraph(o["basis"])
    doc.add_heading("第2条  工程概况", level=2)
    doc.add_paragraph(o["overview"])

    doc.add_heading("第二章  施工部署与进度计划", level=1)
    doc.add_heading("第3条  施工部署", level=2)
    doc.add_paragraph(o["deploy"])
    doc.add_heading("第4条  总进度计划", level=2)
    doc.add_paragraph(f"总工期{o['duration_days']}日历天，各阶段安排如下：")
    oc.add_table(doc, ["施工阶段", "计划时间"], o["schedule"], kind, widths=[9.0, 6.0])

    doc.add_heading("第三章  主要施工方案", level=1)
    for i, (title, body) in enumerate(o["methods"], 5):
        doc.add_heading(f"第{i}条  {title}", level=2)
        doc.add_paragraph(body)

    base = 5 + len(o["methods"])
    doc.add_heading("第四章  质量保证措施", level=1)
    doc.add_heading(f"第{base}条  质量控制", level=2)
    doc.add_paragraph(o["quality"])

    doc.add_heading("第五章  安全生产措施", level=1)
    doc.add_heading(f"第{base+1}条  安全管理", level=2)
    doc.add_paragraph(o["safety"])

    doc.add_heading("第六章  文明施工与环水保措施", level=1)
    doc.add_heading(f"第{base+2}条  文明施工与生态保护", level=2)
    doc.add_paragraph(o["civilized"])

    doc.add_heading("说明", level=1)
    doc.add_paragraph("本施工组织设计在施工图会审后据实调整。", style="List Bullet")
    doc.add_paragraph(
        "重大危险性作业（风机大件吊装、塔筒/机舱/叶片起吊、临近带电体作业、高边坡道路施工等）"
        "另行编制专项施工方案，并按规定组织专家论证。", style="List Bullet")
    doc.add_paragraph("大件运输须编制专项运输方案，勘查桥涵承载与转弯半径，办理超限运输许可。",
                      style="List Bullet")
    doc.add_paragraph("【提示】本文本为工作底稿，正式实施前须经项目技术负责人审批。")

    oc.add_footer(doc, f"{d['project_short']} · 施工组织设计（{o['doc_no']}）")
    doc.save(out)
    print(f"OK 施工组织设计已生成: {out}")


if __name__ == "__main__":
    main()
