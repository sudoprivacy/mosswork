# -*- coding: utf-8 -*-
"""
gen_settlement_excel.py —— 风电EPC 竣工结算书 XLSX 生成器（双向：对甲方 + 对乙方）
用法:
    python gen_settlement_excel.py <项目档案.json> <输出.xlsx>
生成三个工作表：双向汇总 / 对甲方结算明细 / 对乙方结算明细。
合计行全部使用 Excel 公式（SUM），保证审核时可追溯勾稽。
依赖: openpyxl, 项目档案 settlement 段（见 assets/sample_pv_project.json）
"""
import sys, json, io
from pathlib import Path
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

# ---------------- 主题样式（与技能配色一致） ----------------
C_PRIMARY, C_DARK, C_LIGHT, C_ACCENT = "1F5FA8", "123A66", "E1ECF9", "3E86D6"
C_WARN = "FFF3E0"

F_TITLE = Font(name="微软雅黑", size=16, bold=True, color=C_PRIMARY)
F_SUB   = Font(name="微软雅黑", size=10, color="666666")
F_HDR   = Font(name="微软雅黑", size=10, bold=True, color="FFFFFF")
F_BODY  = Font(name="宋体", size=10, color="222222")
F_BOLD  = Font(name="微软雅黑", size=10, bold=True, color=C_DARK)
F_TOTAL = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")

FILL_HDR   = PatternFill("solid", fgColor=C_PRIMARY)
FILL_BAND  = PatternFill("solid", fgColor=C_LIGHT)
FILL_TOTAL = PatternFill("solid", fgColor=C_DARK)
FILL_SEC   = PatternFill("solid", fgColor=C_ACCENT)
FILL_WARN  = PatternFill("solid", fgColor=C_WARN)

THIN = Side(style="thin", color="9DB6D6")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
AL_C = Alignment(horizontal="center", vertical="center", wrap_text=True)
AL_L = Alignment(horizontal="left", vertical="center", wrap_text=True)
AL_R = Alignment(horizontal="right", vertical="center")
NUMFMT = "#,##0.00"

def _cell(ws, r, c, v, font=F_BODY, fill=None, align=AL_L, num=False, border=True):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = font
    if fill: cell.fill = fill
    cell.alignment = align
    if border: cell.border = BORDER
    if num: cell.number_format = NUMFMT
    return cell

def _title(ws, text, sub, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    _cell(ws, 1, 1, text, F_TITLE, align=AL_C, border=False)
    ws.row_dimensions[1].height = 30
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    _cell(ws, 2, 1, sub, F_SUB, align=AL_C, border=False)
    ws.row_dimensions[2].height = 16

def _headers(ws, r, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        _cell(ws, r, i, h, F_HDR, FILL_HDR, AL_C)
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[r].height = 22

# ---------------- 明细表（单侧） ----------------
def sheet_side(wb, name, side, prof):
    ws = wb.create_sheet(name)
    ws.sheet_view.showGridLines = False
    st = prof["settlement"]
    _title(ws, f"{name}明细表",
           f"{prof['project_name']} · {side['contract_name']} · 结算对方：{side['party']} · "
           f"口径：{prof['tax_note']} · 编号：{st['report_no']}", 6)
    r = 4
    _headers(ws, r, ["序号", "项目内容", "合同金额(元)", "结算金额(元)", "差额(元)", "备注/审核说明"],
             [7, 34, 16, 16, 14, 44])
    r += 1
    # —— A 合同内分项 ——
    sec_a = r
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    _cell(ws, r, 1, "A　合同内工程价款（按实结算）", F_BOLD, FILL_BAND, AL_L)
    r += 1
    a_start = r
    for i, (nm, ca, sa, note) in enumerate(side["contract_items"], 1):
        band = FILL_BAND if i % 2 == 0 else None
        _cell(ws, r, 1, f"A{i}", F_BODY, band, AL_C)
        _cell(ws, r, 2, nm, F_BODY, band, AL_L)
        _cell(ws, r, 3, ca, F_BODY, band, AL_R, num=True)
        _cell(ws, r, 4, sa, F_BODY, band, AL_R, num=True)
        c = _cell(ws, r, 5, f"=D{r}-C{r}", F_BODY, band, AL_R); c.number_format = NUMFMT
        _cell(ws, r, 6, note, F_BODY, band, AL_L)
        r += 1
    a_end = r - 1
    _cell(ws, r, 1, "", F_BOLD, FILL_SEC); _cell(ws, r, 2, "A小计", F_HDR, FILL_SEC, AL_L)
    for col in (3, 4, 5):
        c = _cell(ws, r, col, f"=SUM({get_column_letter(col)}{a_start}:{get_column_letter(col)}{a_end})",
                  F_HDR, FILL_SEC, AL_R); c.number_format = NUMFMT
    _cell(ws, r, 6, "", F_BODY, FILL_SEC)
    a_sub = r; r += 1
    # —— B 调整增加 ——
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    _cell(ws, r, 1, "B　调整增加（已批变更/签证/价差）", F_BOLD, FILL_BAND, AL_L); r += 1
    b_start = r
    for i, (nm, amt, note) in enumerate(side["adjustments"], 1):
        _cell(ws, r, 1, f"B{i}", F_BODY, None, AL_C)
        _cell(ws, r, 2, nm, F_BODY, None, AL_L)
        _cell(ws, r, 3, None, F_BODY, None, AL_R)
        _cell(ws, r, 4, amt, F_BODY, None, AL_R, num=True)
        _cell(ws, r, 5, None, F_BODY, None, AL_R)
        _cell(ws, r, 6, note, F_BODY, None, AL_L)
        r += 1
    b_end = r - 1
    _cell(ws, r, 1, "", F_HDR, FILL_SEC); _cell(ws, r, 2, "B小计", F_HDR, FILL_SEC, AL_L)
    _cell(ws, r, 3, None, F_HDR, FILL_SEC)
    c = _cell(ws, r, 4, f"=SUM(D{b_start}:D{b_end})", F_HDR, FILL_SEC, AL_R); c.number_format = NUMFMT
    _cell(ws, r, 5, None, F_HDR, FILL_SEC); _cell(ws, r, 6, "", F_HDR, FILL_SEC)
    b_sub = r; r += 1
    # —— C 扣减项 ——
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
    _cell(ws, r, 1, "C　扣减项（负数计列）", F_BOLD, FILL_BAND, AL_L); r += 1
    c_start = r
    for i, (nm, amt, note) in enumerate(side["deductions"], 1):
        _cell(ws, r, 1, f"C{i}", F_BODY, None, AL_C)
        _cell(ws, r, 2, nm, F_BODY, None, AL_L)
        _cell(ws, r, 3, None, F_BODY, None, AL_R)
        _cell(ws, r, 4, amt, F_BODY, None, AL_R, num=True)
        _cell(ws, r, 5, None, F_BODY, None, AL_R)
        _cell(ws, r, 6, note, F_BODY, None, AL_L)
        r += 1
    c_end = r - 1
    _cell(ws, r, 1, "", F_HDR, FILL_SEC); _cell(ws, r, 2, "C小计", F_HDR, FILL_SEC, AL_L)
    _cell(ws, r, 3, None, F_HDR, FILL_SEC)
    c = _cell(ws, r, 4, f"=SUM(D{c_start}:D{c_end})", F_HDR, FILL_SEC, AL_R); c.number_format = NUMFMT
    _cell(ws, r, 5, None, F_HDR, FILL_SEC); _cell(ws, r, 6, "", F_HDR, FILL_SEC)
    c_sub = r; r += 1
    # —— 汇总区 ——
    rate = side["retention_rate"]
    rows = [
        ("结算总额（A+B+C）", f"=D{a_sub}+D{b_sub}+D{c_sub}", "以本行为准报送审核", FILL_TOTAL, F_TOTAL),
        (f"质量保证金（{rate*100:.0f}%）", None, "缺陷责任期满无息返还", None, F_BOLD),
        ("累计已收/付款", -side["paid"], "以银行回单为准", None, F_BOLD),
        ("本次应结净额", None, "结算总额-质保金-已收付", FILL_TOTAL, F_TOTAL),
    ]
    total_row = r
    for i, (nm, val, note, fill, font) in enumerate(rows):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        _cell(ws, r, 1, nm, font, fill, AL_L)
        for cc_ in (2, 3):
            mc = ws.cell(row=r, column=cc_)
            mc.font = font; mc.border = BORDER
            if fill: mc.fill = fill
        if i == 1:
            val = f"=-ROUND(D{total_row}*{rate},2)"
        if i == 3:
            val = f"=D{total_row}+D{total_row+1}+D{total_row+2}"
        cc = _cell(ws, r, 4, val, font, fill, AL_R); cc.number_format = NUMFMT
        _cell(ws, r, 5, "", font, fill)
        _cell(ws, r, 6, note, font, fill, AL_L)
        ws.row_dimensions[r].height = 20
        r += 1
    # —— 待批项（不计入） ——
    if side.get("pending"):
        r += 1
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=6)
        _cell(ws, r, 1, "D　待批争议项（未计入结算总额，跟办中）", F_BOLD, FILL_WARN, AL_L); r += 1
        for i, (nm, amt, stat, strat) in enumerate(side["pending"], 1):
            _cell(ws, r, 1, f"D{i}", F_BODY, FILL_WARN, AL_C)
            _cell(ws, r, 2, nm, F_BODY, FILL_WARN, AL_L)
            _cell(ws, r, 3, stat, F_BODY, FILL_WARN, AL_C)
            _cell(ws, r, 4, amt, F_BODY, FILL_WARN, AL_R, num=True)
            ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=6)
            _cell(ws, r, 5, strat, F_BODY, FILL_WARN, AL_L)
            mc = ws.cell(row=r, column=6); mc.fill = FILL_WARN; mc.border = BORDER
            r += 1
    ws.freeze_panes = "A5"
    return total_row  # 结算总额所在行（供汇总表引用）

# ---------------- 工程结算明细表（参照成本表，预算 vs 结算对比） ----------------
def sheet_cost_detail(wb, prof):
    """参照 gen_cost_excel 的成本明细表结构，按五大成本科目列出竣工结算明细，
    含预算/结算数量、单价、合价(万元)、单位指标(元/kW)、占比、增减额、增减率。
    结算数量/单价缺省取预算值（即按预算结算）；可在档案 categories 各项填
    settled_qty / settled_price 表达结算增减。所有合价/占比/增减均用 Excel 公式勾稽。"""
    ws = wb.create_sheet("工程结算明细表")
    ws.sheet_view.showGridLines = False
    st = prof["settlement"]
    cap_kw = int(prof["capacity_mw"] * 1e3)
    headers = ["科目编码", "费用科目", "单位",
               "预算数量", "预算单价(元)", "结算数量", "结算单价(元)",
               "预算合价(万元)", "结算合价(万元)", "增减额(万元)",
               "预算单位指标(元/kW)", "结算单位指标(元/kW)",
               "预算占比", "结算占比", "增减率", "单价来源", "备注"]
    widths = [9, 30, 7, 11, 13, 11, 13, 14, 14, 13, 15, 15, 11, 11, 10, 12, 26]
    ncols = len(headers)
    _title(ws, f"{prof['project_short']} 竣工结算明细表（按成本科目）",
           f"编号：{st['report_no']} · 装机容量：{prof['capacity_mw']}MW（{prof.get('site_type','陆上')}）· "
           f"计价口径：{prof['tax_note']} · 编制日期：{prof['date']} · 单位：元/kW",
           ncols)
    r = 4
    _headers(ws, r, headers, widths)
    r += 1
    cats = prof.get("categories", [])
    first_data = r
    # 预计算总计行号，供占比分母引用
    total_rows = sum(len(c["items"]) + 2 for c in cats)
    grand_row = r + total_rows
    subtotal_rows = []
    for cat in cats:
        # 分类标题行
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        _cell(ws, r, 1, f"【{cat['name']}】", F_BOLD, FILL_BAND, AL_L)
        for c in range(3, ncols + 1):
            _cell(ws, r, c, "", F_BODY, FILL_BAND)
        ws.row_dimensions[r].height = 19
        r += 1
        a = r
        for it in cat["items"]:
            bq, bp = it["qty"], it["price"]
            sq = it.get("settled_qty", bq)
            sp = it.get("settled_price", bp)
            band = FILL_BAND if (r - first_data) % 2 == 0 else None
            _cell(ws, r, 1, it["code"], F_BODY, band, AL_C)
            _cell(ws, r, 2, it["name"], F_BODY, band, AL_L)
            _cell(ws, r, 3, it["unit"], F_BODY, band, AL_C)
            _cell(ws, r, 4, bq, F_BODY, band, AL_R, num="#,##0.##")
            _cell(ws, r, 5, bp, F_BODY, band, AL_R, num="#,##0")
            _cell(ws, r, 6, sq, F_BODY, band, AL_R, num="#,##0.##")
            _cell(ws, r, 7, sp, F_BODY, band, AL_R, num="#,##0")
            h = _cell(ws, r, 8, f"=D{r}*E{r}/10000", F_BODY, band, AL_R); h.number_format = "#,##0.00"
            i = _cell(ws, r, 9, f"=F{r}*G{r}/10000", F_BODY, band, AL_R); i.number_format = "#,##0.00"
            j = _cell(ws, r, 10, f"=I{r}-H{r}", F_BODY, band, AL_R); j.number_format = "#,##0.00"
            k = _cell(ws, r, 11, f"=H{r}*10000/{cap_kw}", F_BODY, band, AL_R); k.number_format = "#,##0.00"
            l = _cell(ws, r, 12, f"=I{r}*10000/{cap_kw}", F_BODY, band, AL_R); l.number_format = "#,##0.00"
            m = _cell(ws, r, 13, f"=H{r}/$H${grand_row}", F_BODY, band, AL_R); m.number_format = "0.0%"
            n = _cell(ws, r, 14, f"=I{r}/$I${grand_row}", F_BODY, band, AL_R); n.number_format = "0.0%"
            o = _cell(ws, r, 15, f'=IF(H{r}=0,0,J{r}/H{r})', F_BODY, band, AL_R); o.number_format = "0.0%"
            _cell(ws, r, 16, it.get("source", "指标估算"), F_BODY, band, AL_C)
            _cell(ws, r, 17, it.get("note", ""), F_BODY, band, AL_L)
            r += 1
        b = r - 1
        # 分类小计
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        _cell(ws, r, 1, f"【{cat['name']}】小计", F_HDR, FILL_SEC, AL_L)
        for c in range(3, ncols + 1):
            _cell(ws, r, c, "", F_BODY, FILL_SEC)
        h = _cell(ws, r, 8, f"=SUM(H{a}:H{b})", F_HDR, FILL_SEC, AL_R); h.number_format = "#,##0.00"
        i = _cell(ws, r, 9, f"=SUM(I{a}:I{b})", F_HDR, FILL_SEC, AL_R); i.number_format = "#,##0.00"
        j = _cell(ws, r, 10, f"=I{r}-H{r}", F_HDR, FILL_SEC, AL_R); j.number_format = "#,##0.00"
        k = _cell(ws, r, 11, f"=H{r}*10000/{cap_kw}", F_HDR, FILL_SEC, AL_R); k.number_format = "#,##0.00"
        l = _cell(ws, r, 12, f"=I{r}*10000/{cap_kw}", F_HDR, FILL_SEC, AL_R); l.number_format = "#,##0.00"
        m = _cell(ws, r, 13, f"=H{r}/$H${grand_row}", F_HDR, FILL_SEC, AL_R); m.number_format = "0.0%"
        n = _cell(ws, r, 14, f"=I{r}/$I${grand_row}", F_HDR, FILL_SEC, AL_R); n.number_format = "0.0%"
        o = _cell(ws, r, 15, f'=IF(H{r}=0,0,J{r}/H{r})', F_HDR, FILL_SEC, AL_R); o.number_format = "0.0%"
        subtotal_rows.append(r)
        r += 1
    # 总计行
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
    _cell(ws, r, 1, "EPC竣工结算造价合计", F_TOTAL, FILL_TOTAL, AL_L)
    for c in range(3, ncols + 1):
        _cell(ws, r, c, "", F_TOTAL, FILL_TOTAL)
    sumref = ",".join(f"H{s}" for s in subtotal_rows)
    sumref_i = ",".join(f"I{s}" for s in subtotal_rows)
    h = _cell(ws, r, 8, f"=SUM({sumref})", F_TOTAL, FILL_TOTAL, AL_R); h.number_format = "#,##0.00"
    i = _cell(ws, r, 9, f"=SUM({sumref_i})", F_TOTAL, FILL_TOTAL, AL_R); i.number_format = "#,##0.00"
    j = _cell(ws, r, 10, f"=I{r}-H{r}", F_TOTAL, FILL_TOTAL, AL_R); j.number_format = "#,##0.00"
    k = _cell(ws, r, 11, f"=H{r}*10000/{cap_kw}", F_TOTAL, FILL_TOTAL, AL_R); k.number_format = "#,##0.00"
    l = _cell(ws, r, 12, f"=I{r}*10000/{cap_kw}", F_TOTAL, FILL_TOTAL, AL_R); l.number_format = "#,##0.00"
    m = _cell(ws, r, 13, f"=H{r}/$H${r}", F_TOTAL, FILL_TOTAL, AL_R); m.number_format = "0.0%"
    n = _cell(ws, r, 14, f"=I{r}/$I${r}", F_TOTAL, FILL_TOTAL, AL_R); n.number_format = "0.0%"
    o = _cell(ws, r, 15, f'=IF(H{r}=0,0,J{r}/H{r})', F_TOTAL, FILL_TOTAL, AL_R); o.number_format = "0.0%"
    r += 2
    # 校核行（公式引用总计行）
    rows_chk = [
        ("预算静态总投资（万元）", f"=H{grand_row}"),
        ("竣工结算造价合计（万元）", f"=I{grand_row}"),
        ("结算较预算增减（万元）", f"=J{grand_row}"),
        ("预算单位造价（元/kW）", f"=K{grand_row}"),
        ("竣工结算单位造价（元/kW）", f"=L{grand_row}"),
    ]
    for nm, val in rows_chk:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
        _cell(ws, r, 1, nm, F_BOLD, FILL_BAND, AL_L)
        cc = _cell(ws, r, 5, val, F_BOLD, FILL_BAND, AL_R); cc.number_format = "#,##0.00"
        for c in range(6, ncols + 1):
            _cell(ws, r, c, "", F_BODY, FILL_BAND)
        r += 1
    # 口径说明
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    note = ("说明：本表为EPC内部工程造价科目结算明细（与成本预算表同口径），逐项列示预算与结算的数量、单价、合价、"
            "单位指标（元/kW）及增减。结算数量/单价缺省等于预算（按预算结算）；档案 categories 各项填 settled_qty/"
            "settled_price 可表达结算增减。本表合计与“双向汇总”表的“全成本”口径不同（后者为对甲方收入扣分包及其他"
            "成本后的利润测算，含甲供核减、待批签证等），两者不可直接相减，以双方盖章的结算审定单为准。")
    _cell(ws, r, 1, note, F_SUB, FILL_WARN, AL_L, border=False)
    ws.row_dimensions[r].height = 54
    ws.freeze_panes = "A5"
    return r

# ---------------- 汇总表 ----------------
def sheet_summary(wb, prof, ow_row, sb_row):
    ws = wb.create_sheet("双向汇总", 0)
    ws.sheet_view.showGridLines = False
    st = prof["settlement"]
    _title(ws, f"{prof['project_short']} 竣工结算书（双向汇总）",
           f"编号：{st['report_no']} · 结算周期：{st['period']} · 造价咨询：{st['audit_org']} · "
           f"口径：{prof['tax_note']} · 编制日期：{prof['date']}", 5)
    r = 4
    _headers(ws, r, ["项目", "对甲方结算(收入侧)", "对乙方结算(支出侧)", "差额", "说明"],
             [26, 20, 20, 18, 40])
    r += 1
    OW, SB = "对甲方结算明细", "对乙方结算明细"
    ow, sb = st["to_owner"], st["to_sub"]
    lines = [
        ("结算对方", ow["party"], sb["party"], "", ""),
        ("依据合同", ow["contract_name"], sb["contract_name"], "", ""),
        ("合同价", ow["contract_price"], sb["contract_price"], None, "签约价款"),
        ("结算总额", f"='{OW}'!D{ow_row}", f"='{SB}'!D{sb_row}", None, "含已批变更签证价差、扣减后"),
        (f"质量保证金", f"='{OW}'!D{ow_row+1}", f"='{SB}'!D{sb_row+1}", None, "3%，缺陷责任期满返还"),
        ("累计已收/付款", f"='{OW}'!D{ow_row+2}", f"='{SB}'!D{sb_row+2}", None, "以银行回单为准"),
        ("本次应结净额", f"='{OW}'!D{ow_row+3}", f"='{SB}'!D{sb_row+3}", None, "结算总额-质保金-已收付"),
    ]
    total_sum_row = None
    for i, (nm, v1, v2, _, note) in enumerate(lines):
        band = FILL_BAND if i % 2 == 1 else None
        numeric = i >= 2
        bold = nm in ("结算总额", "本次应结净额")
        font = F_BOLD if bold else F_BODY
        _cell(ws, r, 1, nm, font, band, AL_L)
        _cell(ws, r, 2, v1, font, band, AL_R if numeric else AL_L, num=numeric)
        _cell(ws, r, 3, v2, font, band, AL_R if numeric else AL_L, num=numeric)
        if numeric:
            c = _cell(ws, r, 4, f"=B{r}-C{r}", font, band, AL_R); c.number_format = NUMFMT
        else:
            _cell(ws, r, 4, "", font, band)
        _cell(ws, r, 5, note, F_BODY, band, AL_L)
        ws.row_dimensions[r].height = 20
        if nm == "结算总额":
            total_sum_row = r
        r += 1

    # —— 全成本利润测算与盈亏结论（含其他成本 other_cost_cny） ——
    r += 1
    other_cost = st.get("other_cost_cny", 0)
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
    _cell(ws, r, 1, "项目全成本利润测算（判定本项目是否盈利）", F_TOTAL, FILL_TOTAL, AL_L)
    ws.row_dimensions[r].height = 22
    r += 1
    inc_ref = f"B{total_sum_row}"          # 对甲方结算总额=结算收入
    sub_ref = f"C{total_sum_row}"          # 对乙方结算总额=施工分包成本
    prof_rows = [
        ("结算收入（对甲方结算总额）", f"={inc_ref}", "收入侧"),
        ("施工分包成本（对乙方结算总额）", f"={sub_ref}", "支出侧-施工"),
        ("其他成本（设备/设计/监理等台账）", other_cost, "档案 other_cost_cny"),
    ]
    first_prof = r
    for nm, val, note in prof_rows:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        _cell(ws, r, 1, nm, F_BODY, None, AL_L)
        for cc_ in (2, 3):
            mc = ws.cell(row=r, column=cc_); mc.border = BORDER
        c = _cell(ws, r, 4, val, F_BODY, None, AL_R); c.number_format = NUMFMT
        _cell(ws, r, 5, note, F_BODY, None, AL_L)
        r += 1
    # 全成本合计
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
    _cell(ws, r, 1, "项目全成本合计（分包+其他）", F_BOLD, FILL_BAND, AL_L)
    for cc_ in (2, 3):
        mc = ws.cell(row=r, column=cc_); mc.border = BORDER; mc.fill = FILL_BAND
    c = _cell(ws, r, 4, f"=D{first_prof+1}+D{first_prof+2}", F_BOLD, FILL_BAND, AL_R)
    c.number_format = NUMFMT
    _cell(ws, r, 5, "", F_BODY, FILL_BAND)
    cost_row = r; r += 1
    # 利润
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
    _cell(ws, r, 1, "项目利润（结算收入 − 全成本）", F_TOTAL, FILL_TOTAL, AL_L)
    for cc_ in (2, 3):
        mc = ws.cell(row=r, column=cc_); mc.border = BORDER; mc.fill = FILL_TOTAL
        mc.font = F_TOTAL
    c = _cell(ws, r, 4, f"=D{first_prof}-D{cost_row}", F_TOTAL, FILL_TOTAL, AL_R)
    c.number_format = NUMFMT
    _cell(ws, r, 5, "正=盈利 / 负=亏损", F_TOTAL, FILL_TOTAL, AL_L)
    profit_row = r; r += 1
    # 利润率
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
    _cell(ws, r, 1, "项目利润率（利润 ÷ 结算收入）", F_BOLD, FILL_BAND, AL_L)
    for cc_ in (2, 3):
        mc = ws.cell(row=r, column=cc_); mc.border = BORDER; mc.fill = FILL_BAND
    c = _cell(ws, r, 4, f"=IF(D{first_prof}=0,0,D{profit_row}/D{first_prof})", F_BOLD, FILL_BAND, AL_R)
    c.number_format = "0.00%"
    _cell(ws, r, 5, "", F_BODY, FILL_BAND)
    rate_row = r; r += 1
    # 盈亏结论行（红色）
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
    concl = _cell(ws, r, 1,
                  f'=IF(D{profit_row}>=0,'
                  f'"结论：本项目盈利 —— 利润 "&TEXT(D{profit_row},"#,##0.00")&" 元，利润率 "&TEXT(D{rate_row},"0.00%")&"，盈亏平衡有保障。",'
                  f'"结论：本项目亏损 —— 亏损 "&TEXT(-D{profit_row},"#,##0.00")&" 元，利润率 "&TEXT(D{rate_row},"0.00%")&"，须复盘成本超支与签证挂账。")',
                  Font(name="微软雅黑", size=12, bold=True, color="C00000"),
                  PatternFill("solid", fgColor="FDECEC"), AL_L)
    ws.row_dimensions[r].height = 30
    r += 2
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
    _cell(ws, r, 1, "说明：①“支出侧”仅归集施工分包结算，设备/设计/监理等成本按各自合同另册结算，毛差≠项目利润；"
                    "②待批变更签证未计入结算总额，见各明细表D区；③所有金额以双方盖章的结算审定单为最终生效依据。",
          F_SUB, FILL_WARN, AL_L, border=False)
    ws.row_dimensions[r].height = 34
    # 签署栏
    r += 2
    for label in ["编制（造价员）：", "复核（商务经理）：", "审核（总工/审计）：", "批准（项目经理）："]:
        _cell(ws, r, 1, label, F_BOLD, align=AL_L, border=False)
        _cell(ws, r, 2, "签字：", F_BODY, align=AL_L, border=False)
        _cell(ws, r, 3, "日期：", F_BODY, align=AL_L, border=False)
        r += 1
    ws.freeze_panes = "A5"

def main():
    if len(sys.argv) < 3:
        print("用法: python gen_settlement_excel.py <项目档案.json> <输出.xlsx>"); sys.exit(1)
    prof = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    out = sys.argv[2]
    st = prof["settlement"]
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    ow_row = sheet_side(wb, "对甲方结算明细", st["to_owner"], prof)
    sb_row = sheet_side(wb, "对乙方结算明细", st["to_sub"], prof)
    sheet_summary(wb, prof, ow_row, sb_row)
    sheet_cost_detail(wb, prof)          # 新增：参照成本表的工程结算明细表
    # 顺序调整：将“工程结算明细表”移到“双向汇总”之后、甲乙双方明细之前
    wb.move_sheet("工程结算明细表", -2)
    wb.save(out)
    # 控制台校核输出（脚本内计算，与Excel公式同口径）
    def tot(side):
        return (sum(x[2] for x in side["contract_items"])
                + sum(x[1] for x in side["adjustments"])
                + sum(x[1] for x in side["deductions"]))
    t1, t2 = tot(st["to_owner"]), tot(st["to_sub"])
    other = st.get("other_cost_cny", 0)
    profit = t1 - t2 - other
    margin = profit / t1 * 100 if t1 else 0
    print(f"OK 竣工结算书已生成: {out}")
    print(f"   对甲方结算总额 {t1:,.2f} 元 | 对乙方 {t2:,.2f} 元 | 毛差 {t1-t2:,.2f} 元")
    print(f"   全成本利润 {profit:,.2f} 元 | 利润率 {margin:.2f}% | {'盈利' if profit>=0 else '亏损'}")

if __name__ == "__main__":
    main()
