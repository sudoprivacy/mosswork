# -*- coding: utf-8 -*-
"""
gen_settlement_report.py —— 竣工结算报告 DOCX 生成器（对甲方 + 对乙方 双向）
用法:
    python gen_settlement_report.py <项目档案.json> <输出.docx>
数据取自统一项目档案的 settlement 段；全部合计由脚本计算，保证勾稽一致。
依赖: python-docx, office_common.py
"""
import sys, json, io
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.path.insert(0, str(Path(__file__).parent))
from office_common import new_doc, add_cover, add_table, add_footer, add_signature_block

# ---------------- 金额工具 ----------------
def fmt(x):
    return f"{x:,.2f}"

def wan(x):
    return f"{x/10000:,.2f}万元"

CN_NUM = "零壹贰叁肆伍陆柒捌玖"
CN_UNIT = ["", "拾", "佰", "仟"]
CN_SEC = ["", "万", "亿", "万亿"]

def rmb_upper(n):
    """人民币大写（精确到分）。"""
    if n < 0:
        return "负" + rmb_upper(-n)
    yuan = int(n)
    jiao = int(round((n - yuan) * 100))
    j, f = divmod(jiao, 10)
    if yuan == 0:
        out = ""
    else:
        out = ""
        sec_i = 0
        while yuan > 0:
            sec = yuan % 10000
            yuan //= 10000
            if sec:
                s = ""
                zero = False
                for i in range(4):
                    d = (sec // (10 ** i)) % 10
                    if d == 0:
                        if s and not zero:
                            s = "零" + s
                            zero = True
                    else:
                        s = CN_NUM[d] + CN_UNIT[i] + s
                        zero = False
                out = s + CN_SEC[sec_i] + out
            elif out and not out.startswith("零"):
                out = "零" + out
            sec_i += 1
        out = out.lstrip("零") + "元"
    if j == 0 and f == 0:
        return (out or "零元") + "整"
    r = out
    if j:
        r += CN_NUM[j] + "角"
    elif f:
        r += "零"
    if f:
        r += CN_NUM[f] + "分"
    return r

# ---------------- 结算侧计算 ----------------
def calc(side):
    within = sum(r[2] for r in side["contract_items"])          # 合同内按实结算
    adj = sum(r[1] for r in side["adjustments"])                # 调整增加
    ded = sum(r[1] for r in side["deductions"])                 # 扣减(负数)
    total = within + adj + ded                                  # 结算总额
    retention = round(total * side["retention_rate"], 2)        # 质保金
    due = total - retention - side["paid"]                      # 应收/应付尾款
    pending = sum(r[1] for r in side.get("pending", []))
    return dict(within=within, adj=adj, ded=ded, total=total,
                retention=retention, due=due, pending=pending)

def side_rows(side, c):
    """结算汇总公式表行。"""
    rows = [["①", "合同内工程价款（按实结算）", fmt(c["within"]), "按竣工图工程量×合同单价"]]
    rows += [["②", f"调整增加：{r[0]}", fmt(r[1]), r[2]] for r in side["adjustments"]]
    rows += [["③", f"扣减：{r[0]}", fmt(r[1]), r[2]] for r in side["deductions"]]
    rows.append(["④", "结算总额（①+②+③）", fmt(c["total"]), rmb_upper(c["total"])])
    rows.append(["⑤", f"质量保证金（{side['retention_rate']*100:.0f}%）", fmt(-c["retention"]),
                 "缺陷责任期满无息返还"])
    rows.append(["⑥", "累计已收付款", fmt(-side["paid"]), "以银行回单为准"])
    rows.append(["⑦", "本次应结净额（④-⑤-⑥）", fmt(c["due"]), rmb_upper(c["due"])])
    return rows

def item_rows(side):
    rows = []
    for name, ca, sa, note in side["contract_items"]:
        diff = sa - ca
        rows.append([name, fmt(ca), fmt(sa), fmt(diff), note])
    ca_sum = sum(r[1] for r in side["contract_items"])
    sa_sum = sum(r[2] for r in side["contract_items"])
    rows.append(["合  计", fmt(ca_sum), fmt(sa_sum), fmt(sa_sum - ca_sum), ""])
    return rows

# ---------------- 主流程 ----------------
def main():
    if len(sys.argv) < 3:
        print("用法: python gen_settlement_report.py <项目档案.json> <输出.docx>"); sys.exit(1)
    prof = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    out = sys.argv[2]
    kind = prof.get("energy_kind", "wind")
    st = prof["settlement"]
    ow, sb = st["to_owner"], st["to_sub"]
    cow, csb = calc(ow), calc(sb)

    doc = new_doc(kind)
    add_cover(doc, "竣工结算报告",
              f"{prof['project_name']}（{st['report_no']}）",
              prof["meta_pairs"] + [["结算周期", st["period"]],
                                    ["造价咨询单位", st["audit_org"]],
                                    ["计价口径", prof["tax_note"]]],
              kind)

    # 一、结算概述
    doc.add_heading("一、结算概述", level=1)
    gross = cow["total"] - csb["total"]
    doc.add_paragraph(
        f"本报告为{prof['project_name']}竣工结算报告，计价口径为{prof['tax_note']}。"
        f"经计量核对与造价审核：对甲方（收入侧）结算总额 {fmt(cow['total'])} 元"
        f"（{rmb_upper(cow['total'])}）；对乙方（支出侧，本册仅含施工分包）结算总额 "
        f"{fmt(csb['total'])} 元（{rmb_upper(csb['total'])}）。"
        f"两侧结算毛差 {fmt(gross)} 元（{wan(gross)}），其余成本以采购与服务合同台账另册归集。")
    doc.add_paragraph(
        "本报告遵循“先计量、后计价，先审量、后审价”原则；措施费单列不打包，"
        "变更签证坚持“一事一签、当期双签”，无书面签认不予计入。")

    # 二、结算依据
    doc.add_heading("二、结算依据", level=1)
    for b in st["basis"]:
        doc.add_paragraph(b, style="List Bullet")

    # 三、对甲方结算
    doc.add_heading("三、对甲方结算（收入侧）", level=1)
    doc.add_paragraph(f"结算对方：{ow['party']}；依据合同：{ow['contract_name']}，"
                      f"合同价 {fmt(ow['contract_price'])} 元。")
    doc.add_heading("3.1 合同内分项结算对比", level=2)
    add_table(doc, ["分项内容", "合同金额(元)", "结算金额(元)", "差额(元)", "备注"],
              item_rows(ow), kind, widths=[4.2, 3.0, 3.0, 2.4, 4.4])
    doc.add_heading("3.2 结算汇总", level=2)
    add_table(doc, ["序", "项目", "金额(元)", "说明"],
              side_rows(ow, cow), kind, widths=[1.0, 5.2, 3.2, 7.0], first_col_left=False)
    doc.add_heading("3.3 待批争议项（未计入结算总额）", level=2)
    add_table(doc, ["事项", "金额(元)", "当前状态", "处理策略"],
              [[r[0], fmt(r[1]), r[2], r[3]] for r in ow["pending"]],
              kind, widths=[4.6, 2.2, 2.6, 7.0])

    # 四、对乙方结算
    doc.add_heading("四、对乙方结算（支出侧）", level=1)
    doc.add_paragraph(f"结算对方：{sb['party']}；依据合同：{sb['contract_name']}，"
                      f"合同价 {fmt(sb['contract_price'])} 元。执行“量价双审”：先复核竣工图量与现场实测，"
                      f"再核对综合单价与认价单，双合格方可进入汇总。")
    doc.add_heading("4.1 合同内分项结算对比", level=2)
    add_table(doc, ["分项内容", "合同金额(元)", "结算金额(元)", "差额(元)", "备注"],
              item_rows(sb), kind, widths=[4.2, 3.0, 3.0, 2.4, 4.4])
    doc.add_heading("4.2 结算汇总", level=2)
    add_table(doc, ["序", "项目", "金额(元)", "说明"],
              side_rows(sb, csb), kind, widths=[1.0, 5.2, 3.2, 7.0], first_col_left=False)
    doc.add_heading("4.3 分包报审待定项（未计入）", level=2)
    add_table(doc, ["事项", "金额(元)", "当前状态", "处理策略"],
              [[r[0], fmt(r[1]), r[2], r[3]] for r in sb["pending"]],
              kind, widths=[4.6, 2.2, 2.6, 7.0])

    # 五、双向对比
    doc.add_heading("五、双向结算对比与利润监控", level=1)
    add_table(doc, ["指标", "对甲方(收入侧)", "对乙方(支出侧)", "差额"],
              [["合同价", fmt(ow["contract_price"]), fmt(sb["contract_price"]),
                fmt(ow["contract_price"] - sb["contract_price"])],
               ["合同内按实结算", fmt(cow["within"]), fmt(csb["within"]),
                fmt(cow["within"] - csb["within"])],
               ["调整增加(变更/签证/价差)", fmt(cow["adj"]), fmt(csb["adj"]),
                fmt(cow["adj"] - csb["adj"])],
               ["扣减合计", fmt(cow["ded"]), fmt(csb["ded"]), fmt(cow["ded"] - csb["ded"])],
               ["结算总额", fmt(cow["total"]), fmt(csb["total"]), fmt(gross)],
               ["质保金", fmt(cow["retention"]), fmt(csb["retention"]),
                fmt(cow["retention"] - csb["retention"])],
               ["本次应结净额", fmt(cow["due"]), fmt(csb["due"]),
                fmt(cow["due"] - csb["due"])]],
              kind, widths=[4.6, 3.6, 3.6, 3.6])
    doc.add_paragraph(
        "说明：本册“支出侧”仅归集施工分包结算；设备采购、设计、监理等其他成本按各自合同另行结算，"
        "利润分析须以全成本台账口径为准，毛差不等于项目利润。")

    # 六、全成本利润测算与盈亏结论
    doc.add_heading("六、全成本利润测算与盈亏结论", level=1)
    other_cost = st.get("other_cost_cny", 0)
    total_cost = csb["total"] + other_cost
    profit = cow["total"] - total_cost
    margin = profit / cow["total"] * 100 if cow["total"] else 0
    is_profit = profit >= 0
    add_table(doc, ["项目", "金额(元)", "说明"],
              [["结算收入（对甲方结算总额）", fmt(cow["total"]), "收入侧"],
               ["施工分包成本（对乙方结算总额）", fmt(csb["total"]), "支出侧-施工"],
               ["其他成本（设备/设计/监理等台账）", fmt(other_cost), "档案 other_cost_cny"],
               ["项目全成本合计", fmt(total_cost), "施工分包+其他成本"],
               ["项目利润（收入−全成本）", fmt(profit), rmb_upper(profit)],
               ["项目利润率", f"{margin:.2f}%", "利润÷结算收入"]],
              kind, widths=[6.0, 4.5, 5.0], first_col_left=True)
    concl = doc.add_paragraph()
    label = "结论：本项目盈利。" if is_profit else "结论：本项目亏损。"
    run = concl.add_run(
        f"{label}经全成本口径测算，项目利润 {fmt(profit)} 元（{wan(profit)}），"
        f"利润率 {margin:.2f}%。"
        + ("盈亏平衡有保障，建议按期归集尾款并释放质保金。" if is_profit
           else "须立即复盘成本超支与待批签证挂账，通过索赔/变更报审与降本措施改善最终损益。"))
    run.font.bold = True
    run.font.color.rgb = __import__("docx").shared.RGBColor(0xC0, 0x00, 0x00)
    doc.add_paragraph(
        "注：本盈亏结论为全成本口径，其他成本取自项目成本台账（档案 other_cost_cny 字段）；"
        "若该字段缺省则视为 0，利润将等于收入减施工分包成本，须结合实际台账修正。")

    # 七、风险提示与跟办
    doc.add_heading("七、风险提示与跟办事项", level=1)
    for txt in [
        f"待批变更/签证合计（甲方侧）{fmt(cow['pending'])} 元未计入结算总额，须在结算审核期内限期批复，逾期转索赔程序；",
        "对甲方结算书报送后，书面确认“逾期未答复视同认可”条款的适用性，防止“以审计为准”无时限拖延；",
        "对乙方尾款支付执行背靠背条款前提审查：甲方对应款项到账凭证、分包无未结罚款与安全整改事项；",
        "质保金到期日历入台账，缺陷责任期满30日内发起返还流程，避免超期沉淀；",
        "本报告所有金额以双方盖章确认的结算审定单为最终生效依据。"]:
        doc.add_paragraph(txt, style="List Bullet")

    # 八、审核意见与签署
    doc.add_heading("八、审核意见与签署", level=1)
    doc.add_paragraph("本结算报告经编制、复核、审核三级校审，报送双方确认。")
    add_signature_block(doc, [
        ("编制（造价员）：", ["签字：", "日期：", "执业章："]),
        ("复核（商务经理）：", ["签字：", "日期：", ""]),
        ("审核（总工/审计）：", ["签字：", "日期：", ""]),
        ("批准（项目经理）：", ["签字：", "日期：", "单位章："]),
    ], kind)

    add_footer(doc, f"{prof['project_short']} · 竣工结算报告 {st['report_no']} · "
                    f"{prof['date']} · 金额未经双方盖章确认前不作为付款依据")
    doc.save(out)
    print(f"OK 竣工结算报告已生成: {out}")
    print(f"   对甲方结算总额 {fmt(cow['total'])} 元 | 对乙方 {fmt(csb['total'])} 元 | 毛差 {fmt(cow['total']-csb['total'])} 元")
    print(f"   全成本利润 {fmt(profit)} 元 | 利润率 {margin:.2f}% | {'盈利' if is_profit else '亏损'}")

if __name__ == "__main__":
    main()
