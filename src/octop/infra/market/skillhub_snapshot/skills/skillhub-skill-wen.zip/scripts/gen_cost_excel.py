#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
风电EPC项目成本明细表生成器（计价单位：元/kW）—— 全联动模型
用法: python gen_cost_excel.py <project.json> [output.xlsx]

【联动铁律】本生成器输出的是全公式联动模型，不是静态数字表：
  · 「参数输入」页的装机容量、机组台数、项目给出价、校核区间为蓝色可改输入；
  · 「成本明细表」的数量、单价为可改输入，合价/单位指标/占比/小计/总计全部公式引用；
  · 校核提示与「可以施工 / 不可施工」结论行由 IF 公式生成，随输入自动更新。
  改任意一个输入数字，整表（含结论文字）自动重算。

输入 JSON 结构（可直接用统一项目档案 sample_wind_project.json）:
{
  "project_name": "某100MW陆上风电场EPC工程",
  "capacity_mw": 100,             # 装机容量 MW（风电以 MW/kW 计）
  "wtg_count": 20,                # 风电机组台数（可选，用于台均造价校核）
  "wtg_mw": 5.0,                  # 单机容量 MW（可选）
  "site_type": "陆上",            # 陆上/海上（决定造价校核区间）
  "tax_note": "含税（设备13%/建安9%/服务6%）",
  "benchmark_price_per_kw": 6200, # 对比价/业主限价/目标成本（元/kW，可选）
  "categories": [
    {"code": "1", "name": "设备及安装工程费", "items": [
        {"code":"1.1","name":"风电机组（含塔筒）","qty":100000,"unit":"kW",
         "price":1800,"source":"合同价","note":"5.0MW×20台 双馈/直驱"} , ...
    ]}, ...
  ]
}
金额单位: price 为"元/单位"，合价自动计算为 万元；同时输出 元/kW 与 占比。
"""
import json
import sys
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("缺少 openpyxl，请先安装: pip install openpyxl")

# ---------- 样式常量（风电蓝主题） ----------
C_TITLE = "123A66"      # 深蓝
C_HEAD = "1F5FA8"       # 表头蓝
C_CAT = "DCE7F6"        # 分类行浅蓝
C_TOTAL = "FCE4D6"      # 合计行浅橙
C_WARN = "C00000"
C_INPUT = "DDEBF7"      # 可改输入底色（浅蓝）
C_INPUT_FONT = "0033CC"  # 可改输入字色（蓝）
THIN = Side(style="thin", color="9DB6D6")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# 单位造价校核区间(元/kW, 含税静态总投资) —— 与 references/cost.md 保持一致
CHECK_RANGE_ONSHORE = (4500, 8000)
CHECK_RANGE_OFFSHORE = (10000, 18000)

# 「参数输入」页固定单元格地址（成本明细表统一引用这些地址）
P = "参数输入"
P_CAP_MW = f"{P}!$B$4"     # 装机容量 MW
P_WTG_N = f"{P}!$B$5"      # 机组台数
P_BENCH = f"{P}!$B$7"      # 项目给出价 元/kW
P_LO = f"{P}!$B$8"         # 校核下限
P_HI = f"{P}!$B$9"         # 校核上限
P_CAP_KW = f"{P}!$B$10"    # 装机容量 kW（派生公式）


def fmt_cell(ws, cell, *, bold=False, size=11, color="000000", fill=None,
             align="center", num=None, wrap=False):
    c = ws[cell] if isinstance(cell, str) else cell
    c.font = Font(name="微软雅黑", bold=bold, size=size, color=color)
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    c.alignment = Alignment(horizontal=align, vertical="center", wrap_text=wrap)
    c.border = BORDER
    if num:
        c.number_format = num
    return c


def build_param_sheet(wb, data, check_range):
    """参数输入页：蓝色单元格为可改输入，成本表全部引用此处。"""
    ws = wb.create_sheet(P, 0)
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 52

    ws.merge_cells("A1:C1")
    ws["A1"] = "参数输入区（蓝色单元格可直接修改，全表自动重算）"
    fmt_cell(ws, "A1", bold=True, size=14, color="FFFFFF", fill=C_TITLE, align="left")
    ws.row_dimensions[1].height = 30

    lo, hi = check_range
    rows = [
        ("项目名称", data.get("project_name", ""), "文本，用于表头", False),
        ("装机容量（MW）", data["capacity_mw"], "★核心输入，驱动全部元/kW 指标", True),
        ("机组台数（台）", data.get("wtg_count", ""), "用于台均造价校核", True),
        ("单机容量（MW）", data.get("wtg_mw", ""), "仅表头展示", True),
        ("项目给出价（元/kW）", data.get("benchmark_price_per_kw", ""),
         "★业主限价/中标价/目标成本，填了才出「能不能干」判定", True),
        ("造价校核下限（元/kW）", lo, f"{data.get('site_type', '陆上')}风电参考区间下限", True),
        ("造价校核上限（元/kW）", hi, f"{data.get('site_type', '陆上')}风电参考区间上限", True),
    ]
    r = 3
    for name, val, note, editable in rows:
        ws.cell(row=r, column=1, value=name)
        fmt_cell(ws, ws.cell(row=r, column=1), bold=True, align="left", fill=C_CAT)
        ws.cell(row=r, column=2, value=val if val != "" else None)
        fmt_cell(ws, ws.cell(row=r, column=2), bold=True,
                 color=C_INPUT_FONT if editable else "000000",
                 fill=C_INPUT if editable else None,
                 num="#,##0.00" if isinstance(val, (int, float)) else None)
        ws.cell(row=r, column=3, value=note)
        fmt_cell(ws, ws.cell(row=r, column=3), size=9, color="777777", align="left")
        r += 1

    # B10：装机容量 kW（派生公式，非输入）
    ws.cell(row=r, column=1, value="装机容量（kW）")
    fmt_cell(ws, ws.cell(row=r, column=1), bold=True, align="left", fill=C_CAT)
    ws.cell(row=r, column=2, value="=B4*1000")
    fmt_cell(ws, ws.cell(row=r, column=2), bold=True, num="#,##0")
    ws.cell(row=r, column=3, value="由装机容量(MW)自动换算，请勿手改")
    fmt_cell(ws, ws.cell(row=r, column=3), size=9, color="777777", align="left")
    r += 2

    ws.merge_cells(f"A{r}:C{r}")
    ws[f"A{r}"] = ("说明：本模型为全公式联动表。修改本页蓝色参数或成本明细表的数量/单价，"
                   "合价、单位指标、占比、小计、总计、校核提示与施工判定结论均自动重算，"
                   "无需重新生成文件。")
    fmt_cell(ws, f"A{r}", size=9, color="555555", align="left", wrap=True)
    ws.row_dimensions[r].height = 32
    return ws


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = Path(sys.argv[1])
    data = json.loads(src.read_text(encoding="utf-8"))
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_suffix(".xlsx")

    site_type = data.get("site_type", "陆上")
    check_range = CHECK_RANGE_OFFSHORE if "海" in site_type else CHECK_RANGE_ONSHORE
    cap_kw_py = data["capacity_mw"] * 1e3  # 仅用于控制台回显

    wb = Workbook()
    ws = wb.active
    ws.title = "成本明细表"
    ws.sheet_view.showGridLines = False
    build_param_sheet(wb, data, check_range)
    wb.active = wb.sheetnames.index("成本明细表")

    headers = ["科目编码", "费用科目", "数量", "单位", "单价(元)",
               "合价(万元)", "单位指标(元/kW)", "占总投资比", "单价来源", "备注"]
    widths = [10, 32, 12, 8, 14, 14, 15, 12, 12, 30]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    # 标题区（引用参数页，改参数标题同步变）
    ws.merge_cells("A1:J1")
    ws.row_dimensions[1].height = 34
    fmt_cell(ws, "A1", bold=True, size=16, color="FFFFFF", fill=C_TITLE)
    ws["A1"] = f'={P}!B3&" —— 成本组成明细表"'
    ws.merge_cells("A2:J2")
    tax = data.get("tax_note", "含税")
    ws["A2"] = (f'="装机容量："&TEXT({P_CAP_MW},"#,##0.##")&" MW（{site_type}）"'
                f'&IF({P_WTG_N}="","","　|　机组配置："&TEXT({P}!$B$6,"#,##0.##")'
                f'&"MW × "&TEXT({P_WTG_N},"#,##0")&"台")'
                f'&"　|　计价口径：{tax}"')
    fmt_cell(ws, "A2", size=10, color="444444", align="left")

    # 表头
    r = 4
    for i, h in enumerate(headers, 1):
        fmt_cell(ws, ws.cell(row=r, column=i), bold=True, color="FFFFFF", fill=C_HEAD)
        ws.cell(row=r, column=i, value=h)
    ws.row_dimensions[r].height = 22

    # ---------- 明细行：数量/单价为输入，合价与单位指标为公式 ----------
    grand_py = 0.0
    r += 1
    for cat in data["categories"]:
        cat_row = r
        r += 1
        first = r
        for it in cat.get("items", []):
            grand_py += it["qty"] * it["price"] / 1e4
            ws.cell(row=r, column=1, value=it["code"])
            ws.cell(row=r, column=2, value=it["name"])
            ws.cell(row=r, column=3, value=it["qty"])       # 输入
            ws.cell(row=r, column=4, value=it["unit"])
            ws.cell(row=r, column=5, value=it["price"])     # 输入
            ws.cell(row=r, column=6, value=f"=C{r}*E{r}/10000")                    # 合价
            ws.cell(row=r, column=7,
                    value=f"=IF({P_CAP_KW}=0,0,F{r}*10000/{P_CAP_KW})")            # 元/kW
            ws.cell(row=r, column=9, value=it.get("source", "指标估算"))
            ws.cell(row=r, column=10, value=it.get("note", ""))
            for i in range(1, 11):
                editable = i in (3, 5)
                fmt_cell(ws, ws.cell(row=r, column=i),
                         align="left" if i in (2, 10) else "center",
                         num="#,##0.00" if i in (5, 6, 7) else None,
                         color=C_INPUT_FONT if editable else "000000",
                         fill=C_INPUT if editable else None,
                         wrap=(i == 10))
            r += 1
        cat["_row"] = cat_row
        cat["_first"] = first
        cat["_last"] = r - 1

    grand_row = r  # 总计行

    # ---------- 小计行：SUM 公式 ----------
    for cat in data["categories"]:
        row, f0, f1 = cat["_row"], cat["_first"], cat["_last"]
        sum_f = f"=SUM(F{f0}:F{f1})" if f1 >= f0 else "=0"
        ws.cell(row=row, column=1, value=cat["code"])
        ws.cell(row=row, column=2, value=f"【{cat['name']}】小计")
        ws.cell(row=row, column=6, value=sum_f)
        ws.cell(row=row, column=7, value=f"=IF({P_CAP_KW}=0,0,F{row}*10000/{P_CAP_KW})")
        ws.cell(row=row, column=8, value=f"=IF($F${grand_row}=0,0,F{row}/$F${grand_row})")
        for i in range(1, 11):
            fmt_cell(ws, ws.cell(row=row, column=i), bold=True, fill=C_CAT,
                     align="left" if i == 2 else "center",
                     num="#,##0.00" if i in (6, 7) else ("0.0%" if i == 8 else None))

    # ---------- 明细行占比：公式引用总计 ----------
    for cat in data["categories"]:
        for rr in range(cat["_first"], cat["_last"] + 1):
            ws.cell(row=rr, column=8,
                    value=f"=IF($F${grand_row}=0,0,F{rr}/$F${grand_row})")
            fmt_cell(ws, ws.cell(row=rr, column=8), num="0.0%")

    # ---------- 总计行：各小计求和 ----------
    cat_refs = "+".join(f"F{c['_row']}" for c in data["categories"]) or "0"
    ws.cell(row=grand_row, column=2, value="项目静态总投资")
    ws.cell(row=grand_row, column=6, value=f"={cat_refs}")
    ws.cell(row=grand_row, column=7,
            value=f"=IF({P_CAP_KW}=0,0,F{grand_row}*10000/{P_CAP_KW})")
    ws.cell(row=grand_row, column=8, value=f"=IF($F${grand_row}=0,0,1)")
    for i in range(1, 11):
        fmt_cell(ws, ws.cell(row=grand_row, column=i), bold=True, size=12, fill=C_TOTAL,
                 align="left" if i == 2 else "center",
                 num="#,##0.00" if i in (6, 7) else ("0.0%" if i == 8 else None))
    ws.row_dimensions[grand_row].height = 24
    r = grand_row + 2

    UC = f"G{grand_row}"   # 单位造价（元/kW）
    TT = f"F{grand_row}"   # 静态总投资（万元）

    # ---------- 校核提示：IF 公式，随参数自动切换 ----------
    ws.merge_cells(f"A{r}:J{r}")
    ws[f"A{r}"] = (
        f'=IF(AND({UC}>={P_LO},{UC}<={P_HI}),'
        f'"✔ 校核：单位造价 "&TEXT({UC},"#,##0")&" 元/kW，处于{site_type}风电参考区间 "'
        f'&TEXT({P_LO},"#,##0")&"~"&TEXT({P_HI},"#,##0")&" 元/kW 内。",'
        f'"⚠ 预警：单位造价 "&TEXT({UC},"#,##0")&" 元/kW，超出{site_type}风电参考区间 "'
        f'&TEXT({P_LO},"#,##0")&"~"&TEXT({P_HI},"#,##0")&" 元/kW，请核查科目缺漏或单价异常！")'
    )
    fmt_cell(ws, f"A{r}", bold=True, color=C_WARN, align="left")
    check_row = r
    r += 1

    # 台均造价校核（公式）
    if data.get("wtg_count"):
        ws.merge_cells(f"A{r}:J{r}")
        ws[f"A{r}"] = (f'=IF({P_WTG_N}=0,"","参考：单台机组分摊造价约 "'
                       f'&TEXT({TT}/{P_WTG_N},"#,##0.00")&" 万元/台（含配套建安及分摊费用）。")')
        fmt_cell(ws, f"A{r}", size=9, color="555555", align="left")
        r += 1

    ws.merge_cells(f"A{r}:J{r}")
    ws[f"A{r}"] = ("说明：标注\"指标估算\"的单价为行业典型区间取值，正式商务报价须以询价/合同价为准；"
                   "本表为静态投资，建设期利息及铺底流动资金另计。")
    fmt_cell(ws, f"A{r}", size=9, color="777777", align="left")
    r += 2

    # ---------- 对比价判定总结区（全公式，结论随参数变） ----------
    bench = data.get("benchmark_price_per_kw")
    if bench:
        ws.merge_cells(f"A{r}:J{r}")
        ws[f"A{r}"] = "四、成本价与项目报价对比判定总结"
        fmt_cell(ws, f"A{r}", bold=True, size=13, color="FFFFFF", fill=C_TITLE, align="left")
        ws.row_dimensions[r].height = 24
        r += 1

        cmp_rows = [
            ("成本测算单价（本表计算的成本价）",
             f'=TEXT({UC},"#,##0.00")&" 元/kW"',
             f'="总额 "&TEXT({TT},"#,##0.00")&" 万元"'),
            ("项目给出价（对比价/中标价/限价）",
             f'=TEXT({P_BENCH},"#,##0.00")&" 元/kW"',
             f'="总额 "&TEXT({P_BENCH}*{P_CAP_KW}/10000,"#,##0.00")&" 万元"'),
            ("差额（项目给出价 − 成本价）",
             f'=TEXT({P_BENCH}-{UC},"+#,##0.00;-#,##0.00")&" 元/kW"',
             f'=TEXT(({P_BENCH}-{UC})*{P_CAP_KW}/10000,"+#,##0.00;-#,##0.00")&" 万元"'),
        ]
        for name, v1, v2 in cmp_rows:
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
            ws.cell(row=r, column=1, value=name)
            for col in range(1, 5):
                fmt_cell(ws, ws.cell(row=r, column=col), bold=True, fill=C_CAT, align="left")
            ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=7)
            ws.cell(row=r, column=5, value=v1)
            for col in range(5, 8):
                fmt_cell(ws, ws.cell(row=r, column=col), bold=True)
            ws.merge_cells(start_row=r, start_column=8, end_row=r, end_column=10)
            ws.cell(row=r, column=8, value=v2)
            for col in range(8, 11):
                fmt_cell(ws, ws.cell(row=r, column=col))
            r += 1

        # 结论行 —— IF 公式，文字随输入自动切换
        ws.merge_cells(f"A{r}:J{r}")
        ws[f"A{r}"] = (
            f'=IF({P_BENCH}="","结论：未填写项目给出价，无法判定。请在「参数输入」页 B7 填入业主限价/中标价。",'
            f'IF({UC}<={P_BENCH},'
            f'"结论：可以施工 —— 成本价 "&TEXT({UC},"#,##0.00")&" 元/kW ≤ 项目给出价 "'
            f'&TEXT({P_BENCH},"#,##0.00")&" 元/kW，盈余空间 "&TEXT({P_BENCH}-{UC},"#,##0.00")'
            f'&" 元/kW（约 "&TEXT(({P_BENCH}-{UC})*{P_CAP_KW}/10000,"#,##0.00")&" 万元，占项目给出总额 "'
            f'&TEXT(({P_BENCH}-{UC})/{P_BENCH},"0.0%")&"），具备实施条件。",'
            f'"结论：不可施工 —— 成本价 "&TEXT({UC},"#,##0.00")&" 元/kW ＞ 项目给出价 "'
            f'&TEXT({P_BENCH},"#,##0.00")&" 元/kW，超出 "&TEXT({UC}-{P_BENCH},"#,##0.00")'
            f'&" 元/kW（约 "&TEXT(({UC}-{P_BENCH})*{P_CAP_KW}/10000,"#,##0.00")'
            f'&" 万元），须降本至 ≤"&TEXT({P_BENCH},"#,##0.00")&" 元/kW 或议价后方可实施。"))'
        )
        fmt_cell(ws, f"A{r}", bold=True, size=13, color=C_WARN,
                 fill="FDECEC", align="left", wrap=True)
        ws.row_dimensions[r].height = 40
        verdict_row = r
        r += 1
        ws.merge_cells(f"A{r}:J{r}")
        ws[f"A{r}"] = ("判定规则：成本价 ≤ 项目给出价 → 可以施工；成本价 ＞ 项目给出价 → 不可施工。"
                       "本行结论由 IF 公式生成，修改「参数输入」页或任一数量/单价后自动更新。")
        fmt_cell(ws, f"A{r}", size=9, color="777777", align="left")

        # 条件格式：可施工转绿，不可施工保持红
        from openpyxl.formatting.rule import FormulaRule
        ws.conditional_formatting.add(
            f"A{verdict_row}:J{verdict_row}",
            FormulaRule(formula=[f'AND({P_BENCH}<>"",{UC}<={P_BENCH})'],
                        font=Font(name="微软雅黑", bold=True, size=13, color="1E7D32"),
                        fill=PatternFill("solid", fgColor="E8F5E9"), stopIfTrue=False),
        )
        ws.conditional_formatting.add(
            f"A{check_row}:J{check_row}",
            FormulaRule(formula=[f'AND({UC}>={P_LO},{UC}<={P_HI})'],
                        font=Font(name="微软雅黑", bold=True, size=11, color="1E7D32"),
                        stopIfTrue=False),
        )

    ws.freeze_panes = "A5"
    wb.save(out)

    unit_cost_py = grand_py * 1e4 / cap_kw_py
    print(f"OK 已生成（全联动模型）: {out}")
    print(f"静态总投资: {grand_py:,.2f} 万元 | 单位造价: {unit_cost_py:,.2f} 元/kW（Python 端预览值）")
    if bench:
        print(f"项目给出价: {float(bench):,.2f} 元/kW | "
              f"判定结论: {'可以施工' if unit_cost_py <= float(bench) else '不可施工'}（Excel 内由 IF 公式实时计算）")
    print("提示：数量/单价/参数输入页任一改动，Excel 将自动重算合价、占比、单位造价与判定结论。")


if __name__ == "__main__":
    main()
