#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
IMA 知识库上传第二步：把本地文件 PUT 到腾讯云 COS。

背景：ima-mcp 的 create_media 会返回 cos_credential（临时密钥），
需要自行把文件上传到 COS，再调 add_knowledge 入库。
本脚本用标准库实现 COS XML API 签名（sha1/HMAC-SHA1），不依赖 qcloud_cos SDK。

用法：
    python ima_cos_upload.py <本地文件路径> <cos_credential.json 路径> [content_type]

cos_credential.json 即 create_media 返回的 cos_credential 对象，需包含：
    secret_id / secret_key / token / bucket_name / region / cos_key / start_time / expired_time

成功时 stdout 打印 "UPLOAD_OK <http_status>"，失败打印 "UPLOAD_FAIL <status>\n<body>" 并以非 0 退出。
"""
import hashlib
import hmac
import json
import sys
import urllib.request
import urllib.error
import urllib.parse


def _hmac_sha1(key: bytes, msg: str) -> str:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha1).hexdigest()


def build_authorization(secret_id, secret_key, method, uri, key_time, headers_to_sign):
    sign_key = _hmac_sha1(secret_key.encode("utf-8"), key_time)

    # header list 必须按 key 小写字典序
    items = sorted((k.lower(), v) for k, v in headers_to_sign.items())
    header_list = ";".join(k for k, _ in items)
    header_str = "&".join(
        "%s=%s" % (k, urllib.parse.quote(str(v), safe="")) for k, v in items
    )

    http_string = "\n".join([method.lower(), uri, "", header_str, ""])
    string_to_sign = "\n".join(
        ["sha1", key_time, hashlib.sha1(http_string.encode("utf-8")).hexdigest(), ""]
    )
    signature = _hmac_sha1(sign_key.encode("utf-8"), string_to_sign)

    return (
        "q-sign-algorithm=sha1"
        "&q-ak=%s&q-sign-time=%s&q-key-time=%s"
        "&q-header-list=%s&q-url-param-list=&q-signature=%s"
        % (secret_id, key_time, key_time, header_list, signature)
    )


def upload(file_path, cred, content_type="application/octet-stream"):
    with open(file_path, "rb") as f:
        body = f.read()

    host = "%s.cos.%s.myqcloud.com" % (cred["bucket_name"], cred["region"])
    cos_key = cred["cos_key"].lstrip("/")
    uri = "/" + cos_key
    url = "https://%s%s" % (host, uri)
    key_time = "%s;%s" % (cred["start_time"], cred["expired_time"])

    headers_to_sign = {
        "host": host,
        "content-type": content_type,
        "content-length": str(len(body)),
    }
    auth = build_authorization(
        cred["secret_id"], cred["secret_key"], "put", uri, key_time, headers_to_sign
    )

    req = urllib.request.Request(url, data=body, method="PUT")
    req.add_header("Host", host)
    req.add_header("Content-Type", content_type)
    req.add_header("Content-Length", str(len(body)))
    req.add_header("Authorization", auth)
    if cred.get("token"):
        req.add_header("x-cos-security-token", cred["token"])

    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return resp.status, resp.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    file_path, cred_path = sys.argv[1], sys.argv[2]
    content_type = sys.argv[3] if len(sys.argv) > 3 else "application/octet-stream"

    with open(cred_path, "r", encoding="utf-8") as f:
        cred = json.load(f)
    if "cos_credential" in cred:  # 容忍直接丢 create_media 完整返回
        cred = cred["cos_credential"]

    status, text = upload(file_path, cred, content_type)
    if 200 <= status < 300:
        print("UPLOAD_OK %s" % status)
        sys.exit(0)
    print("UPLOAD_FAIL %s\n%s" % (status, text))
    sys.exit(1)


if __name__ == "__main__":
    main()
