# md_to_xlsx.py（六级岗位动作流·转换脚本）
#
# 将 6 级 Markdown 标题（##层级2 / ###层级3 / ####层级4 / #####层级5 / ######层级6）
# 转换为合并单元格 xlsx，并支持禁词/层级/主谓自检。
#
# 最新版更新：在 5 级动作链基础上新增「层级6 结果性交付文档」列；
#             层级6 归属其所在「层级3 节点」（将某层级3 下全部层级4 动作汇总提炼成《》文档）；
#             层级1/2/3/4/6 纵向合并相同单元格（层级5 为最细动作，不合并；层级6 合并范围与层级3 一致）；
#             按层级2分组着色、极淡莫兰迪 6 色块 + L1 中性浅灰脊；表头深蓝白字、细边框、冻结首行。

# -*- coding: utf-8 -*-
"""将 6 级 Markdown 标题转换为合并单元格 xlsx，并支持禁词/层级/主谓自检。

用法:
    python3 md_to_xlsx.py <input.md> [output.xlsx] ["<岗位名>"]
    python3 md_to_xlsx.py --check <input.md>          # 仅自检，不生成 xlsx

Markdown 约定:
    # 文档标题（不进入表格）
    ## 层级2（动作目标，动宾短语）
    ### 层级3（手段动作，动宾短语）
    #### 层级4（支撑动作，动宾短语）
    ##### 层级5（最细动作步骤，纯动作）
    ###### 层级6（结果性交付文档，用《》括起来；归属其所在层级3节点）
层级1(岗位名)由第 3 个参数传入，缺省为"岗位价值链"。

语句格式: 价值链主打动宾短语，主谓结构不推荐（仅确需区分责任主体时保留并点明主语）。
"""

import sys, re
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side

# ---- 价值链编写标准：禁词自检（与 SKILL.md 禁止清单一致）----
# 硬性禁词：命中即视为违规
FORBIDDEN_HARD = {
    "时间": ["定期", "不定期", "每月", "每周", "每日", "年度", "季度", "实时", "及时",
            "常态", "日常", "周期", "长期", "短期", "持续", "随时", "阶段性",
            "当天", "次日", "当月", "当季"],
    "状态(形容人)": ["努力", "积极", "确保", "保证"],
    "状态(形容事物)": ["稳定", "平衡", "精准", "良好", "顺畅", "紧盯",
                     "良好的", "稳定的", "顺畅的", "精准的", "平衡的"],
    "数量": ["至少", "最多", "左右", "以上", "以下"],
    "抽象": ["原则", "标准", "注意事项", "要素", "逻辑", "构成"],
    "职责式长句": ["优化", "提高", "提升", "加强", "完善", "搞定"],
    "时态/判定状态": ["是否", "提前"],
    "分类说明": ["内部招聘", "外部招聘", "中高层", "需背调", "不需要背调"],
    "条件触发": ["后方可", "须经", "方可", "通过后方可"],
}
# 主语前缀（疑似主谓结构，软警告：价值链主打动宾）
SUBJECT_PREFIX = ["部门", "专员", "负责人", "经理", "主管", "工程师", "公司",
                  "我们", "他们", "采购", "销售", "财务", "人事", "行政",
                  "运营", "客服", "技术", "生产", "质量", "物流", "组长", "主管"]
# 数值量词（如 15个/35项/3次）
QUANT_RE = re.compile(r"\d+\s*(个|项|次|名|份|条|种)")
# 软性需复核词（可能是判断依据而非具体动作）
FORBIDDEN_WARN = ["分析", "判断", "选择", "确认", "确定", "获得", "建立", "提炼"]


def _parse_l6_by_l3(path):
    """第一遍：找出每个层级3节点对应的层级6结果性文档（归属其所属层级3节点）。

    返回 (l6_by_l3, l3_nodes)：
      - l6_by_l3: {(l2, l3): "《文档名》"}
      - l3_nodes: set of (l2, l3)，用于检查每个层级3节点是否都声明了层级6
    """
    l6_by_l3 = {}
    l3_nodes = set()
    cur_l2 = None
    cur_l3 = None
    with open(path, encoding="utf-8") as f:
        for line in f:
            m2 = re.match(r"^##\s+(.*)$", line.rstrip("\n"))
            if m2:
                cur_l2 = m2.group(1).strip()
                cur_l3 = None
                continue
            m3 = re.match(r"^###\s+(.*)$", line.rstrip("\n"))
            if m3:
                cur_l3 = m3.group(1).strip()
                if cur_l2 is not None:
                    l3_nodes.add((cur_l2, cur_l3))
                continue
            if cur_l2 is not None and cur_l3 is not None:
                m6 = re.match(r"^######\s+(.*)$", line.rstrip("\n"))
                if m6:
                    l6_by_l3[(cur_l2, cur_l3)] = m6.group(1).strip()
    return l6_by_l3, l3_nodes


def parse_md(path, l1="岗位价值链"):
    """第二遍：生成行。每层(2/3/4)记录当前节点，遇层级5生成一行；层级6取所属层级3节点。"""
    l6_by_l3, _ = _parse_l6_by_l3(path)
    rows = []
    cur = {2: None, 3: None, 4: None}
    with open(path, encoding="utf-8") as f:
        for line in f:
            m = re.match(r"^(#{2,5})\s+(.*)$", line.rstrip("\n"))
            if not m:
                continue
            level = len(m.group(1))
            text = m.group(2).strip()
            if level == 2:
                cur[2], cur[3], cur[4] = text, None, None
            elif level == 3:
                cur[3], cur[4] = text, None
            elif level == 4:
                cur[4] = text
            elif level == 5:
                if None in (cur[2], cur[3], cur[4]):
                    continue
                l6 = l6_by_l3.get((cur[2], cur[3]))
                rows.append([l1, cur[2], cur[3], cur[4], text, l6])
    return rows


def check(path):
    """扫描所有节点，输出禁词与层级自检报告。返回 (issues, warns, level_ok, missing_l6)。"""
    issues, warns = [], []
    levels_seen = set()
    l6_by_l3, l3_nodes = _parse_l6_by_l3(path)
    with open(path, encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            m = re.match(r"^(#{2,6})\s+(.*)$", line.rstrip("\n"))
            if not m:
                continue
            level = len(m.group(1))
            levels_seen.add(level)
            text = m.group(2).strip()
            # 层级6 为成果文档名：仅校验《》包裹，不套用动作节点禁词/主谓/数量扫描
            if level == 6:
                if not (text.startswith("《") and text.endswith("》")):
                    warns.append((lineno, "层级6未用《》括起来", text))
                continue
            # 以下禁词/长度/主谓校验仅作用于层级1~5 动作节点
            # 节点长度
            if len(text) > 20:
                issues.append((lineno, "节点过长(>20字)", text))
            # 硬性禁词
            for cat, words in FORBIDDEN_HARD.items():
                for w in words:
                    if w in text:
                        issues.append((lineno, "禁词[%s]:%s" % (cat, w), text))
                        break
            # 数值量词
            if QUANT_RE.search(text):
                issues.append((lineno, "数量刻度", text))
            # 软性复核词
            for w in FORBIDDEN_WARN:
                if w in text:
                    warns.append((lineno, "需复核[判断依据?]:%s" % w, text))
                    break
            # 主谓结构软检测：疑似"主语+动作"，价值链主打动宾
            if len(text) > 4:
                for p in SUBJECT_PREFIX:
                    if text.startswith(p):
                        warns.append((lineno, "疑似主谓结构(主打动宾)", text))
                        break
    level_ok = levels_seen.issuperset({2, 3, 4, 5, 6})
    # 层级6 完整性：每个层级3节点是否都有对应结果性文档
    missing_l6 = sorted([(l2, l3) for (l2, l3) in l3_nodes if (l2, l3) not in l6_by_l3])
    return issues, warns, level_ok, missing_l6


def build(rows, out):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["层级1", "层级2", "层级3", "层级4", "层级5", "层级6"])
    for r in rows:
        ws.append(r)

    thin = Side(style="thin", color="BBBBBB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hf = Font(bold=True, color="FFFFFF")
    fill = openpyxl.styles.PatternFill("solid", fgColor="4472C4")
    ctr = Alignment(horizontal="center", vertical="center", wrap_text=True)
    lft = Alignment(horizontal="left", vertical="center", wrap_text=True)

    for c in range(1, 7):
        cell = ws.cell(1, c)
        cell.font = hf
        cell.fill = fill
        cell.alignment = ctr
        cell.border = border

    # 按层级2分组着色：每个 L2 一种极淡莫兰迪色块，同组统一色；L1 岗位名列用中性浅灰做脊
    l2_palette_cols = ["EAF1F8", "EAF4EC", "F8EEF0", "FAF3E8", "F0EBF6", "E9F3F3"]
    spine_fill = openpyxl.styles.PatternFill("solid", fgColor="F5F5F5")
    palette = {}
    def l2_color(l2):
        if l2 not in palette:
            palette[l2] = l2_palette_cols[len(palette) % len(l2_palette_cols)]
        return openpyxl.styles.PatternFill("solid", fgColor=palette[l2])
    for idx, r in enumerate(range(2, ws.max_row + 1)):
        bf = l2_color(rows[idx][1])
        for c in range(1, 7):
            cell = ws.cell(r, c)
            cell.border = border
            cell.alignment = lft if c == 5 else ctr
            cell.fill = spine_fill if c == 1 else bf

    # 纵向合并相同单元格：层级1/2/3/4/6（层级5 为最细动作步骤，逐行不合并）
    # 层级6 归属层级3节点，合并后与层级3 列范围一致
    for col in (1, 2, 3, 4, 6):
        start = 2
        for r in range(3, ws.max_row + 2):
            if r == ws.max_row + 1 or ws.cell(r, col).value != ws.cell(start, col).value:
                if r - 1 > start:
                    ws.merge_cells(start_row=start, start_column=col, end_row=r - 1, end_column=col)
                    ws.cell(start, col).alignment = ctr
                start = r

    for i, w in enumerate([14, 20, 22, 22, 30, 28], 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    ws.freeze_panes = "A2"
    wb.save(out)
    return wb


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        print("用法: python3 md_to_xlsx.py <input.md> [output.xlsx] [\"<岗位名>\"]  或  --check <input.md>")
        sys.exit(1)
    if args[0] == "--check":
        inp = args[1]
        issues, warns, level_ok, missing_l6 = check(inp)
        print("=== 自检报告: %s ===" % inp)
        print("层级完整性(需含##/###/####/#####/######共6级):", "OK" if level_ok else "缺失层级!")
        if missing_l6:
            print("⚠ 以下层级3节点缺少层级6结果性文档《》：")
            for l2, l3 in missing_l6:
                print("   - [%s] %s" % (l2, l3))
        else:
            print("层级6完整性: 每个层级3节点均已声明结果性文档")
        print("硬性违规数:", len(issues))
        for ln, cat, txt in issues:
            print("  L%-4d [%-16s] %s" % (ln, cat, txt))
        print("需人工复核数:", len(warns))
        for ln, cat, txt in warns:
            print("  L%-4d [%-16s] %s" % (ln, cat, txt))
        sys.exit(0)

    inp = args[0]
    out = args[1] if len(args) > 1 else "价值链.xlsx"
    l1 = args[2] if len(args) > 2 else "岗位价值链"
    # 生成前先自检并提示
    issues, warns, level_ok, missing_l6 = check(inp)
    if not level_ok:
        print("[警告] 层级不完整，需含 ##/###/####/#####/###### 共 6 级")
    if missing_l6:
        print("[警告] 以下层级3节点缺少层级6《》结果性文档：%s"
              % "、".join("%s/%s" % (l2, l3) for l2, l3 in missing_l6))
    if issues:
        print("[警告] 发现 %d 处硬性禁词/格式问题，建议修正后再交付:" % len(issues))
        for ln, cat, txt in issues[:20]:
            print("  L%-4d [%-16s] %s" % (ln, cat, txt))
        if len(issues) > 20:
            print("  ...共 %d 处" % len(issues))
    rows = parse_md(inp, l1)
    wb = build(rows, out)
    print("OK rows:", len(rows) + 1, "merges:", len(wb.active.merged_cells.ranges))
