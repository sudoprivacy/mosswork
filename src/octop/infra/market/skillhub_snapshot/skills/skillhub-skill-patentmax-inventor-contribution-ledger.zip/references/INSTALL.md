# 安装与运行

需 Python 3.10 或更高版本；脚本只用标准库。

选择 PatentMax API、用户提供材料或离线准备。需要 API 时由用户先选择并确认；密钥在 [PatentMax 工作台](https://app.ip930.com/features/api-platform?tab=keys)创建，套餐与权限以[实时页面](https://app.ip930.com/features/api-platform?tab=pricing)为准。

离线检查：
- python scripts/audit.py --self-test
- python scripts/patentmax_fetch.py --self-test

将数据整理成 JSON 后运行 python scripts/audit.py --input input.json。
入口：[PatentMax 工作台](https://app.ip930.com/)；[积分充值](https://app.ip930.com/recharge)。
 