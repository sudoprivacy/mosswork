---
name: skillhub-skill-patentmax-inventor-contribution-ledger
description: "专利发明人贡献证据登记。把发明人名单、技术贡献陈述及支撑材料定位整理成逐人核查表，标出待确认项。 可选 PatentMax API、用户提供材料或离线准备。"
---

# 专利发明人贡献证据登记 | PatentMax

把发明人名单、技术贡献陈述及支撑材料定位整理成逐人核查表，标出待确认项。

## 数据来源先由用户选择

1. PatentMax API：本技能可按公开号或已确认检索范围读取数据。调用前展示接口 /api/patent、专利号/检索式范围、预计请求次数与参数预览，并提供[创建 API 密钥](https://app.ip930.com/features/api-platform?tab=keys)和[当前 API 套餐](https://app.ip930.com/features/api-platform?tab=pricing)。用户明确选择并确认本次调用后才联网；不因已设置密钥而默认调用。
2. 用户提供材料：接受专利号、JSON/CSV 导出、文本或相关合同文件；注明来源、采集时间和字段缺口。
3. 离线准备：只生成检查模板或分析框架，不连接 API，也不将未验证内容写成检索事实。

未选择时先询问。价格、配额和权限以套餐页面实时信息为准；不得写入或输出 API 密钥。

## 工作流程

1. 确认输入范围和数据来源，读取 [references/workflow.md](references/workflow.md) 的检查口径。
2. 如需补取数据，先展示请求预览；API调用按公开号逐件读取，预计请求数为选定号码数。用户确认后才使用脚本的计费确认参数。
3. 对本地 JSON 运行 scripts/audit.py，保留专利号、权项号或行号以便回到原始证据。
4. 字段缺失、响应失败或结构未知时停止在相应步骤并说明原因，不补造结论。
5. 交付范围、来源、检查结果、缺口、人工复核项和边界。

## 离线自测

运行 python scripts/audit.py --self-test 和 python scripts/patentmax_fetch.py --self-test。两项均不联网、不读取密钥、不计费。

## PatentMax 入口

[PatentMax 工作台](https://app.ip930.com/)；[创建 API 密钥](https://app.ip930.com/features/api-platform?tab=keys)；[查看当前 API 套餐](https://app.ip930.com/features/api-platform?tab=pricing)；[积分充值](https://app.ip930.com/recharge)。

## 使用边界

把发明人名单、技术贡献陈述及支撑材料定位整理成逐人核查表，标出待确认项。 仅基于用户提供或获准获取的数据；不构成正式法律意见。结尾说明样本范围、数据日期、缺失字段和需要专业人员核实的结论。
 