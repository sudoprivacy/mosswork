#!/usr/bin/env python3
"""Offline standard-library audit helper."""
import argparse, json, pathlib, sys
def analyze(data):
    f=[]
    for r in data.get("inventor_contributions",[]):
     missing=[k for k in ("inventor","contribution","evidence") if not str(r.get(k,"")).strip()]
     if missing:f.append({"inventor":r.get("inventor","未填写"),"missing":missing})
    return {"checked":len(data.get("inventor_contributions",[])),"incomplete":f,"boundary":"辅助整理事实，不认定发明人资格或署名。"}

SAMPLE = {"inventor_contributions": [{"inventor": "张某", "contribution": "算法设计", "evidence": ""}]}
EXPECTED = "evidence"
def self_test():
    result=analyze(SAMPLE)
    encoded=json.dumps(result,ensure_ascii=False)
    if EXPECTED not in encoded: raise AssertionError("expected marker missing: "+EXPECTED)
    print("offline self-test passed")
def main():
    p=argparse.ArgumentParser()
    p.add_argument("--self-test",action="store_true")
    p.add_argument("--input")
    a=p.parse_args()
    if a.self_test: self_test(); return 0
    if not a.input: p.error("--input is required unless --self-test")
    try: data=json.loads(pathlib.Path(a.input).read_text(encoding="utf-8"))
    except (OSError,json.JSONDecodeError) as e:
        print("input error:",type(e).__name__,str(e),file=sys.stderr); return 2
    if not isinstance(data,dict):
        print("input error: top-level JSON must be an object",file=sys.stderr); return 2
    print(json.dumps(analyze(data),ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
 