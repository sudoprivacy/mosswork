#!/usr/bin/env python3
"""Minimal PatentMax API fetcher. Dry-run is default; network requires explicit confirmation."""
import argparse, json, os, pathlib, sys, urllib.error, urllib.parse, urllib.request
BASE='https://api.ip930.com'
ALLOWED={'/api/search','/api/patent','/api/legal','/api/citation','/api/similar','/api/ration','/api/a/portrait'}
def main():
 p=argparse.ArgumentParser(description='PatentMax API request preview or confirmed fetch')
 p.add_argument('--endpoint',choices=sorted(ALLOWED),required=False)
 p.add_argument('--param',action='append',default=[],metavar='KEY=VALUE')
 p.add_argument('--out',default='patentmax-response.json')
 p.add_argument('--confirm-billable',action='store_true',help='用户已查看当前套餐并明确确认执行')
 p.add_argument('--self-test',action='store_true')
 a=p.parse_args()
 if a.self_test:
  assert '/api/search' in ALLOWED and '/api/patent' in ALLOWED
  print('offline self-test passed; no network and no key read')
  return 0
 if not a.endpoint: p.error('--endpoint is required unless --self-test')
 params={}
 for item in a.param:
  if '=' not in item: p.error('--param must use KEY=VALUE')
  k,v=item.split('=',1)
  if not k or k in params: p.error('empty or duplicate parameter')
  params[k]=v
 if a.endpoint in {'/api/search','/api/ration'} and ('q' not in params or len(params['q'])>4000): p.error('endpoint requires q (max 4000 chars)')
 if a.endpoint=='/api/ration' and 'dimension' not in params: p.error('/api/ration requires dimension')
 if a.endpoint=='/api/a/portrait' and 'name' not in params: p.error('/api/a/portrait requires name')
 if a.endpoint in {'/api/patent','/api/legal','/api/citation','/api/similar'} and 'pn' not in params: p.error('this endpoint requires stable publication number pn')
 url=BASE+a.endpoint+'?'+urllib.parse.urlencode(params)
 print('PatentMax request preview:',url)
 if not a.confirm_billable:
  print('Dry run only. Check the live plan and obtain user confirmation before adding --confirm-billable.')
  return 0
 key=os.environ.get('PATENTMAX_API_KEY')
 if not key: print('PATENTMAX_API_KEY is not set',file=sys.stderr); return 2
 req=urllib.request.Request(url,headers={'Authorization':'Bearer '+key,'Accept':'application/json','User-Agent':'PatentMax-Skill/1.0'})
 try:
  with urllib.request.urlopen(req,timeout=45) as resp:
   raw=resp.read(8_000_001)
   if len(raw)>8_000_000: raise ValueError('response exceeds 8 MB safety limit')
   data=json.loads(raw.decode('utf-8-sig'))
 except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,ValueError,json.JSONDecodeError) as e:
  print('PatentMax API request failed:',type(e).__name__,str(e),file=sys.stderr); return 1
 out=pathlib.Path(a.out); out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print('Saved response:',out)
 return 0
if __name__=='__main__': raise SystemExit(main())
