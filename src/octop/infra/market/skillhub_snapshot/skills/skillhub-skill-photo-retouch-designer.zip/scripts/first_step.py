#!/usr/bin/env python3
"""One short first-step command: metadata, local plan, live quote and a link.

Never opens a browser, uploads a photo, authorizes execution or creates an order.
"""
import argparse
import json
import sys
import time
from pathlib import Path
from activity import engage
from client import Client, DEFAULT_BASE, LocalStateError


def first_step(client, options=None, image=None, request_id=None, plan_only=False):
    started = time.monotonic()
    timings = {}

    def timed(name, operation):
        phase_started = time.monotonic()
        try:
            return operation()
        finally:
            timings[name] = round(max(0, time.monotonic()-phase_started), 3)

    def finished(value):
        return {**value, 'elapsed_seconds': round(time.monotonic()-started, 2),
                'timings_seconds': dict(timings)}

    activity = {'confirmed': False, 'billable': False}
    if not request_id:
        saved = timed('local_plan', lambda: client.plan(options, image))
        request_id = saved['request_id']
        try:
            activity = timed('usage_record', lambda: engage(client.state, client.base, client=client))
        except Exception:
            pass  # Metadata is never a prerequisite for the visible plan.
    else:
        phase_started = time.monotonic()
        job = client.load_job(request_id)
        if not job.get('planned') or job.get('task_id') or job.get('continuation_authorization'):
            raise ValueError('原请求已进入执行或已授权，请用client.py progress/status恢复，不重新准备首轮')
        from portrait_plan import compile_plan
        saved = {'request_id': request_id, 'plan_saved': True, 'summary': compile_plan(job['retouch_plan'])['summary']}
        timings['local_plan'] = round(max(0, time.monotonic()-phase_started), 3)
    result = {**saved, 'activity_confirmed': activity['confirmed'], 'payment_created': False,
              'execution_authorized': False, 'photo_uploaded': False, 'browser_open_attempted': False}
    if plan_only:
        return finished({**result, 'stage': 'plan_only'})
    # Keep network waits short. A slow service must not hold the first reply.
    old_timeout, old_deadline = client.network_timeout, client.network_deadline
    client.network_timeout, client.network_deadline = 4, min(started+10, time.monotonic()+6)
    try:
        quote = timed('quote', lambda: client.quote(include_profile=False))
        body=client.load_job(request_id)['body']
        client.check_mode(body,quote)
        result.update(quote=quote, account_url=quote['account_url'], stage='awaiting_confirmation')
        try:
            link = timed('checkout_link', lambda: client.checkout(request_id, open_browser=False))
            result.update(checkout_url=link['checkout_url'], link_available=True)
            spec = body['resolution']
            amount = quote['resolution_prices_fen'][spec]
            disclosure = ('接下来会按确认方案处理这张照片。照片和修改要求将由办公 Skill 平台及受托图片处理、'
                          '存储服务处理；正式执行前会确认本次费用。')
            action='处理这张照片'
            if body.get('mode')=='generate':
                disclosure='接下来会按确认方案生成一张图片。创作要求将由办公 Skill 平台及受托图片处理、存储服务处理；正式执行前会确认本次费用。'
                action='生成这张图'
            elif body.get('mode')=='stylize':
                disclosure='接下来会用原图按确认方案创作一张图片。原图和创作要求将由办公 Skill 平台及受托图片处理、存储服务处理；正式执行前会确认本次费用。'
                action='按原图完成这张创作'
            account = quote['account']
            if account.get('registered') and account.get('balance_fen', -1) >= amount and not quote.get('first_recharge_required'):
                next_step = f'确认开始可回复“确定”，我会沿用当前绑定的账户，接着{action}。'
            else:
                next_step = ('确认开始可回复“开通”或者“确定”，我就打开统一账户和收银台 —— '
                             f'[开通服务]({link["checkout_url"]})，你登录绑定账户完成后回来接着{"修这张" if body.get("mode","retouch")=="retouch" else action}，不用重新描述。')
            result['confirmation_markdown'] = f'{disclosure}\n\n本次 {spec} **¥{amount/100:.2f}**。{next_step}'
        except (ValueError, OSError, KeyError, TypeError):
            result.update(link_available=False, notice='专属入口暂不可用，请先展示方案与统一账户链接；保留原请求，稍后补取入口。')
    except (ValueError, OSError, KeyError, TypeError):
        result.update(stage='quote_unavailable', link_available=False,
                      notice='实时价目暂不可用，先交付方案；不要猜余额或价格、请求执行授权或重建原请求。')
    finally:
        client.network_timeout, client.network_deadline = old_timeout, old_deadline
    return finished(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, default=Path.home()/'.photo-retouch-designer')
    parser.add_argument('--request-id', help='Retry link/quote on the saved original request; no new opening event')
    parser.add_argument('--image')
    parser.add_argument('--mode', choices=('retouch','stylize','generate'), default='retouch')
    parser.add_argument('--request', help='Verbatim original user request')
    parser.add_argument('--change', action='append', default=[])
    parser.add_argument('--preserve', action='append', default=[])
    parser.add_argument('--style', default='natural')
    parser.add_argument('--scene', default='auto')
    parser.add_argument('--intensity', default='light')
    parser.add_argument('--resolution', default='2K')
    parser.add_argument('--size', default='auto', help='auto resolves the original photo ratio locally')
    parser.add_argument('--composition', default='keep')
    parser.add_argument('--allow-change', action='append', default=[])
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    try:
        if not args.request_id and (not args.request or not args.change):
            raise ValueError('请先明确原话和本次修改或创作要求')
        options = {'mode': args.mode, 'original_prompt': args.request, 'changes': args.change, 'preserve': args.preserve,
                   'style': args.style, 'scene': args.scene, 'intensity': args.intensity,
                   'resolution': args.resolution, 'size': args.size, 'composition': args.composition,
                   'change_permissions': {k: True for k in args.allow_change}}
        result = first_step(Client(DEFAULT_BASE, args.state), options, args.image, args.request_id, args.plan_only)
        print(json.dumps({'ok': True, **result}, ensure_ascii=False))
        return 0
    except (LocalStateError, PermissionError):
        print(json.dumps({'ok': False, 'code': 'PRIVATE_STATE_UNAVAILABLE',
                          'error': '当前工作区无法保存本次方案，请先展示建议，再选宿主已授权的私有工作区。已有请求请沿原请求恢复。',
                          'request_id': args.request_id, 'payment_created': False, 'photo_uploaded': False}, ensure_ascii=False))
        return 2
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(json.dumps({'ok': False, 'code': 'FIRST_STEP_UNAVAILABLE', 'error': str(error) if isinstance(error, ValueError) else '首轮准备暂不可用，先给出建议并保留原请求',
                          'request_id': args.request_id, 'payment_created': False, 'photo_uploaded': False}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
