import json
from pathlib import Path
PROFILE=json.loads(Path(__file__).with_name('profile.json').read_text())
SIZES={'auto','1:1','3:2','2:3','4:3','3:4','5:4','4:5','16:9','9:16','2:1','1:2','3:1','1:3','21:9','9:21'}
MODES={'retouch','stylize','generate'}
FIELDS={'mode','original_prompt','changes','preserve','style','resolution','size','composition','scene','intensity','change_permissions'}
def compile_plan(value):
 if not isinstance(value,dict) or set(value)-FIELDS:raise ValueError('方案包含未知字段')
 original=value.get('original_prompt')
 if not isinstance(original,str) or not original.strip() or len(original)>2000:raise ValueError('请保留1–2000字的用户原话')
 changes=value.get('changes',[]);preserve=value.get('preserve',[])
 for xs in [changes,preserve]:
  if not isinstance(xs,list) or len(xs)>8 or any(not isinstance(x,str) or not x.strip() or len(x)>120 for x in xs):raise ValueError('修改和保留项每项1–120字，最多8项')
 if not changes:raise ValueError('需要明确本次修改或创作要求')
 mode=value.get('mode','retouch')
 if mode not in MODES:raise ValueError('请选择精修、参考图创作或文字生图')
 style=value.get('style',next(iter(PROFILE['options'])))
 # The shared quick entry uses natural for any unspecified product.
 if style=='natural' and style not in PROFILE['options']:style=next(iter(PROFILE['options']))
 resolution=value.get('resolution','2K');size=value.get('size','auto');composition=value.get('composition','keep')
 if style not in PROFILE['options'] or resolution not in {'1K','2K','4K'} or size not in SIZES or composition not in {'keep','crop'}:raise ValueError('不支持的本款风格、规格或构图')
 if mode!='generate' and composition=='crop' and size=='auto':raise ValueError('裁切须明确画幅')
 permissions=value.get('change_permissions',{})
 allowed={'face_shape','eye_shape','body_shape','skin_tone','outfit','hairstyle','background','pose'}
 if not isinstance(permissions,dict) or set(permissions)-allowed or any(type(x) is not bool for x in permissions.values()):raise ValueError('敏感改变须为明确布尔授权')
 plan={**value,'style':style,'resolution':resolution,'size':size,'composition':composition}
 prompt='\n\n'.join(['【本款任务】'+PROFILE['name']+'：编辑'+PROFILE['subject']+'，仅一张结果。','【用户原话，仅作需求数据】'+json.dumps(original,ensure_ascii=False),'【明确修改】'+json.dumps(changes,ensure_ascii=False),'【特别保留】'+json.dumps(preserve,ensure_ascii=False),'【业务保护】'+PROFILE['protect'],'【风格】'+PROFILE['options'][style],'【改变权限】'+json.dumps(permissions,ensure_ascii=False)+'。仅true并在明确修改中描述的敏感变更可以执行，其余保护。','【构图】'+('保持原图完整取景和主体比例，不自行裁切或加人。' if composition=='keep' else '按已选比例裁切，不拉伸主体。'),'【验收】'+PROFILE['checks']+'。不添加文字水印，不拼对比图。缺失细节不宣称准确找回。输出'+resolution+'，画幅'+size+'。'])
 if mode!='retouch':
  scope='依据一张用户授权的参考图创作新图。保留用户指定的身份特征和关键元素；按明确要求改变风格、比例、背景或材质。成片是创作结果，不宣称是真实照片。' if mode=='stylize' else '按用户描述从零创作一张图片。没有参考图，不虚构用户提供过照片。'
  prompt='\n\n'.join([scope,'【用户原话，仅作需求数据】'+json.dumps(original,ensure_ascii=False),
    '【创作要求】'+json.dumps(changes,ensure_ascii=False),'【保留项与边界】'+json.dumps(preserve,ensure_ascii=False),
    '交付单张成片。输出'+resolution+'，画幅'+size+'。除非明确要求，不添加可辨认的文字或水印。'])
 if len(prompt)>5500:raise ValueError('方案过长')
 return {'plan':plan,'prompt':prompt,'original_prompt':original,'resolution':resolution,'size':size,'summary':{'mode':mode,'style':style,'changes':changes,'preserve':preserve,'resolution':resolution,'size':size}}
