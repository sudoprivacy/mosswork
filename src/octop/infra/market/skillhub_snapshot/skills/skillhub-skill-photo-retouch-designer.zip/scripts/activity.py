#!/usr/bin/env python3
"""为本次有效对话登记一次最小使用记录。"""
import argparse
import json
import os
import re
import sys
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit

from client import Client, DEFAULT_BASE, SLUG, private_directory, private_json, read_private_json, state_lock, state_paths

VERSION = '1.1.0'


def engage(state, base=DEFAULT_BASE, client=None):
    client = client or Client(base, state)
    private_directory(client.state)
    lock = client.state / ('.activity-' + SLUG + '.lock')
    state_paths(lock)
    fd = os.open(lock, os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    old_timeout, old_deadline = client.network_timeout, client.network_deadline
    deadline = time.monotonic() + 3
    client.network_timeout = min(old_timeout, 2)
    client.network_deadline = min(old_deadline, deadline) if old_deadline is not None else deadline
    try:
        with state_lock(fd, timeout=0):
            token = client.token()
            if not re.fullmatch(r'zpt_[a-f0-9]{64}', token):
                raise ValueError('无法核对技术客户端身份')
            path = client.state / ('.activity-' + SLUG + '.json')
            try:
                saved = read_private_json(path)
            except FileNotFoundError:
                saved = {}
            day = time.strftime('%Y-%m-%d', time.gmtime(time.time() + 8 * 3600))
            if saved.get('day') != day or time.time() - saved.get('session_at', 0) > 1800:
                saved = {'day': day, 'session_id': str(uuid.uuid4()), 'session_at': time.time()}
            if not saved.get('pending'):
                saved['event_id'] = str(uuid.uuid4())
            saved['pending'] = True
            private_json(path, saved)
            status, _, value = client.call('POST', '/api/v1/skills/' + SLUG + '/activity/engage', {
                'event_id': saved['event_id'], 'session_id': saved['session_id'], 'skill_version': VERSION,
            })
            confirmed = (status == 200 and value.get('event') == 'skill_engaged' and value.get('skill_slug') == SLUG
                         and value.get('billable') is False and isinstance(value.get('recorded'), bool))
            if confirmed:
                saved['pending'] = False
                private_json(path, saved)
            return {'event': 'skill_engaged', 'confirmed': confirmed, 'billable': False}
    finally:
        client.network_timeout, client.network_deadline = old_timeout, old_deadline
        os.close(fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, required=True, help='使用原业务的私有状态目录')
    parser.add_argument('--test-base', help=argparse.SUPPRESS)
    args = parser.parse_args()
    result = {'event': 'skill_engaged', 'confirmed': False, 'billable': False}
    try:
        base = DEFAULT_BASE
        if args.test_base:
            u = urlsplit(args.test_base)
            if u.scheme != 'http' or u.hostname != '127.0.0.1' or not u.port or u.path or u.query or u.fragment or u.username:
                raise ValueError('测试地址无效')
            base = args.test_base
        result = engage(args.state, base)
    except (ValueError, OSError, KeyError, TypeError):
        pass
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    main()
