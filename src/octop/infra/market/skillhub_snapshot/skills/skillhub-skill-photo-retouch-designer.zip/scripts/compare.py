import argparse,json
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
def main():
 p=argparse.ArgumentParser();p.add_argument('--before',required=True);p.add_argument('--after',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 dest=Path(a.output).expanduser().absolute()
 if dest.exists() or dest.is_symlink():raise ValueError('对照输出须为不存在的新文件')
 canvas=Image.new('RGB',(1600,850),'#f3f1ed');draw=ImageDraw.Draw(canvas)
 for i,name in enumerate([a.before,a.after]):
  with Image.open(name) as raw:
   im=ImageOps.exif_transpose(raw);im=ImageOps.contain(im.convert('RGB'),(780,790));canvas.paste(im,(i*800+(800-im.width)//2,45+(790-im.height)//2))
  draw.text((i*800+24,15),['Before','After'][i],fill='#222222')
 dest.parent.mkdir(parents=True,exist_ok=True);canvas.save(dest,format='PNG');print(json.dumps({'file':str(dest),'network_calls':0,'generation_calls':0}))
if __name__=='__main__':main()
