#!/usr/bin/env python3
"""Thin buyer client. Keeps credentials/order state private; never makes payments."""
import argparse
import hashlib
import json
import os
import secrets
import struct
import sys
import time
import webbrowser
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from portrait_plan import compile_plan
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, parse_qs
from urllib.request import Request, build_opener, HTTPRedirectHandler, ProxyHandler

DEFAULT_BASE = "https://skill.zhaopintong.com"
SLUG = "photo-retouch-designer"


def image_dimensions(raw):
    """Read PNG/JPEG display dimensions, including JPEG EXIF rotation."""
    if raw.startswith(b'\x89PNG\r\n\x1a\n') and raw[12:16] == b'IHDR' and len(raw) >= 24:
        width, height = struct.unpack('>II', raw[16:24])
    elif raw.startswith(b'\xff\xd8'):
        pos, orientation, dimensions = 2, 1, None
        while pos + 4 <= len(raw):
            if raw[pos] != 255: break
            while pos < len(raw) and raw[pos] == 255: pos += 1
            if pos >= len(raw): break
            marker = raw[pos]; pos += 1
            if marker in {0xD9, 0xDA}: break
            if marker in {0x01, *range(0xD0, 0xD8)}: continue
            length = int.from_bytes(raw[pos:pos+2], 'big')
            if length < 2 or pos + length > len(raw): break
            segment = raw[pos+2:pos+length]; pos += length
            if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF} and len(segment) >= 5:
                height, width = struct.unpack('>HH', segment[1:5]); dimensions = width, height
            if marker == 0xE1 and segment.startswith(b'Exif\0\0'):
                tiff = segment[6:]
                endian = 'little' if tiff[:2] == b'II' else 'big' if tiff[:2] == b'MM' else None
                if endian and len(tiff) >= 8 and int.from_bytes(tiff[2:4], endian) == 42:
                    offset = int.from_bytes(tiff[4:8], endian)
                    if offset + 2 <= len(tiff):
                        count = int.from_bytes(tiff[offset:offset+2], endian)
                        for i in range(min(count, 256)):
                            entry = tiff[offset+2+i*12:offset+14+i*12]
                            if len(entry) != 12: break
                            if int.from_bytes(entry[:2], endian) == 0x112 and int.from_bytes(entry[2:4], endian) == 3 and int.from_bytes(entry[4:8], endian) == 1:
                                orientation = int.from_bytes(entry[8:10], endian)
        if not dimensions: raise ValueError('无法读取原图尺寸，请提供完整PNG/JPEG')
        width, height = dimensions
        if orientation in {5, 6, 7, 8}: width, height = height, width
    else:
        raise ValueError('无法读取原图尺寸，请提供完整PNG/JPEG')
    if not width or not height: raise ValueError('原图尺寸无效')
    return width, height


def source_ratio(raw):
    from portrait_plan import SIZES
    import math
    width, height = image_dimensions(raw)
    ratios = {s: int(s.split(':')[0])/int(s.split(':')[1]) for s in SIZES if s != 'auto'}
    nearest = min(sorted(ratios), key=lambda s: abs(math.log((width/height)/ratios[s])))
    if abs((width/height)/ratios[nearest]-1) > 0.02:
        raise ValueError('原图比例不属于常用画幅，请先确认可接受的输出比例；不能默认裁成方图')
    return nearest, width, height


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs): return None


class LocalStateError(ValueError):
    """The original checkpoint is still authoritative when a write fails."""


def private_directory(path):
    if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise LocalStateError("私有状态目录不能使用符号链接")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    # On Windows permissions are inherited from the approved workspace ACL.
    if os.name != "nt" and path.stat().st_mode & 0o077:
        path.chmod(0o700)


def state_paths(path):
    journal = path.with_name(path.name + ".events.jsonl")
    if any(p.is_symlink() for p in (path, journal, *path.parents)):
        raise LocalStateError("私有状态文件不能使用符号链接")
    return journal


@contextmanager
def state_lock(fd, timeout=0.6):
    deadline = time.monotonic() + timeout
    if os.name == "nt":
        import msvcrt

        def acquire():
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
    else:
        import fcntl

        def acquire():
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    while True:
        try:
            acquire()
            break
        except OSError as error:
            if time.monotonic() >= deadline:
                raise LocalStateError("原请求状态暂时被占用，请稍后续接同一请求") from error
            time.sleep(0.04)
    yield  # The owner closes the descriptor and releases the lock.


def private_json(path, value):
    # Append a checksummed checkpoint. No truncate, rename, replace or deletion:
    # ordinary state updates do not request a host's destructive-file permission.
    journal = state_paths(path)
    payload = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    if len(payload.encode()) > 200_000:
        raise ValueError("私有检查点超过大小限制")
    record = json.dumps({'v': 1, 'payload': payload, 'sha256': hashlib.sha256(payload.encode()).hexdigest()},
                        ensure_ascii=False, separators=(',', ':')).encode()
    try:
        private_directory(path.parent)
        fd = os.open(journal, os.O_RDWR | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        try:
            if os.name != "nt" and os.fstat(fd).st_mode & 0o077:
                os.fchmod(fd, 0o600)
            with state_lock(fd), os.fdopen(fd, 'ab', closefd=False) as f:
                f.write(b'\n' + record + b'\n')
                f.flush()
                os.fsync(fd)
        finally:
            os.close(fd)
    except PermissionError as error:
        raise LocalStateError("当前工作区不能写入原请求状态，请保留原请求并迁移到获准的私有目录") from error
    # The journal is authoritative. The legacy file is only a compatibility snapshot.
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(value, f, ensure_ascii=False, indent=2)
    except (FileExistsError, PermissionError):
        pass


def read_private_json(path):
    journal=state_paths(path)
    if journal.exists():
        with journal.open('rb') as f:
            f.seek(max(0,journal.stat().st_size-2_000_000));tail=f.read(2_000_000)
        for line in reversed(tail.splitlines()):
            try:
                record=json.loads(line);payload=record['payload']
                if record['v']!=1 or not isinstance(payload,str) or hashlib.sha256(payload.encode()).hexdigest()!=record['sha256']: continue
                value=json.loads(payload)
                if isinstance(value,dict): return value
            except (ValueError,KeyError,TypeError): continue
    return json.loads(path.read_text(encoding="utf-8"))


class Client:
    def __init__(self, base, state):
        u = urlsplit(base)
        local = u.hostname in {"127.0.0.1", "localhost", "::1"}
        if u.username or u.password or u.query or u.fragment or u.path not in {"", "/"}:
            raise ValueError("Base URL must be an origin without credentials or path")
        if u.scheme != "https" and not (u.scheme == "http" and local): raise ValueError("HTTPS required outside loopback")
        self.base, self.state = base.rstrip("/"), state.expanduser().absolute()
        if self.state.is_symlink() or any(p.is_symlink() for p in self.state.parents):
            raise LocalStateError("私有状态目录不能使用符号链接")
        # Scope identity to service origin; do not forward a credential to a new host.
        self.identity = self.state / ("identity-" + hashlib.sha256(self.base.encode()).hexdigest()[:16] + ".json")
        self.opener = build_opener(NoRedirect(), ProxyHandler({}))
        self.network_timeout = 30
        self.network_deadline = None

    def token(self):
        journal=state_paths(self.identity)
        if self.identity.exists() or journal.exists():
            return read_private_json(self.identity)["token"]
        private_directory(self.state)
        status, _, value = self.call("POST", "/api/v1/clients/register", {"name": "照片精修设计师客户端"}, auth=False)
        if status != 201 or not isinstance(value.get("token"), str): raise ValueError("暂时无法准备统一账户入口，请稍后重试")
        private_json(self.identity, {"token": value["token"], "client_id": value.get("id"), "base": self.base})
        return value["token"]

    def call(self, method, path, body=None, headers=None, auth=True, raw=False):
        if not path.startswith("/api/") or path.startswith("//"): raise ValueError("Only service API paths are allowed")
        h = dict(headers or {})
        if auth: h["Authorization"] = "Bearer " + self.token()
        data = body
        if body is not None and not isinstance(body, bytes):
            h["Content-Type"] = "application/json"; data = json.dumps(body, ensure_ascii=False).encode()
        try:
            timeout = self.network_timeout
            if self.network_deadline is not None:
                timeout = min(timeout, self.network_deadline-time.monotonic())
                if timeout <= 0: raise TimeoutError('本次查询已到等待上限')
            response = self.opener.open(Request(self.base+path, data=data, method=method, headers=h), timeout=timeout)
        except HTTPError as e: response = e
        with response:
            content = response.read(64_000_001 if raw else 2_000_001)
            if len(content) > (64_000_000 if raw else 2_000_000): raise ValueError("Response exceeds client size limit")
            return response.status, response.headers, content if raw else json.loads(content)

    def jobpath(self, request_id):
        import re
        if not re.fullmatch(r"[A-Za-z0-9_-]{8,80}", request_id): raise ValueError("Invalid request ID")
        return self.state / "jobs" / (request_id + ".json")

    def load_job(self, request_id):
        path = self.jobpath(request_id)
        if path.is_symlink() or path.parent.is_symlink(): raise ValueError("Job state cannot be a symlink")
        job = read_private_json(path)
        if job.get("skill_slug") != SLUG or job.get("base") != self.base:
            raise ValueError("任务不属于当前Skill或服务，请使用原Skill客户端恢复")
        return job

    def relocate(self, rid, destination):
        """Copy only this request and its existing identity, entirely locally."""
        job = self.load_job(rid)
        identity = read_private_json(self.identity)
        if identity.get("base") != self.base or not identity.get("token"):
            raise LocalStateError("原统一账户凭证无法核对，请从原工作区恢复")
        target = Client(self.base, destination)
        if target.state == self.state or self.state in target.state.parents or target.state in self.state.parents:
            raise LocalStateError("请选择另一处独立、获准且可长期保留的私有目录")
        for path, value in ((target.identity, identity), (target.jobpath(rid), job)):
            journal = state_paths(path)
            if (path.exists() or journal.exists()) and read_private_json(path) != value:
                raise LocalStateError("目标目录已有不同的账户或请求，请保留它并选择专用目录")
        images = []
        for entry in job.get("local_images", []):
            name = entry["filename"]
            if name not in {rid + ".png", rid + ".jpg"}:
                raise LocalStateError("原参考图检查点无法核对")
            source = self.state / "references" / name
            state_paths(source)
            raw = source.read_bytes()
            if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
                raise LocalStateError("原参考图已变化，请核对原请求")
            target_path = target.state / "references" / name
            state_paths(target_path)
            if target_path.exists() and target_path.read_bytes() != raw:
                raise LocalStateError("目标目录已有不同原图，请保留它并选择专用目录")
            images.append((target_path, raw))
        private_directory(target.state)
        for path, raw in images:
            private_directory(path.parent)
            try:
                with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "wb") as file:
                    file.write(raw)
            except FileExistsError:
                if path.is_symlink() or path.read_bytes() != raw:
                    raise LocalStateError("目标目录已有不同原图，请保留它并选择专用目录")
        private_json(target.identity, identity)
        private_json(target.jobpath(rid), job)
        return {"request_id": rid, "state_relocated": True, "state_path": str(target.state)}

    def plan(self, options, image):
        options = dict(options)
        mode = options.get('mode','retouch')
        if (mode=='generate') == bool(image):
            raise ValueError('文字生图无需参考图，精修与参考图创作必须提供一张原图')
        raw = Path(image).expanduser().read_bytes() if image else None
        if raw is not None and len(raw) > 10_000_000:
            raise ValueError("请提供不超过10MB的PNG/JPEG参考图")
        if raw is not None and options.get('composition', 'keep') == 'keep' and options.get('size', 'auto') == 'auto':
            options['size'], width, height = source_ratio(raw)
        else:
            width = height = None
        compiled = compile_plan(options)
        saved = self._save_plan(compiled["prompt"], [image] if image else [], compiled["resolution"], compiled["size"],
                                compiled["original_prompt"], raw_image=raw, retouch_plan=compiled["plan"])
        return {**saved, "summary": compiled["summary"], "source_dimensions": {"width": width, "height": height} if width else None}


    def quote(self, include_profile=True):
        status, _, result = self.call("GET", "/api/v1/skills/"+SLUG+"/photo-retouch/quote")
        if status != 200: raise ValueError(result.get("message", "价目暂不可用"))
        account = result["account"]
        profile = {}
        if include_profile and account.get('registered'):
            status, _, profile = self.call("GET", "/api/v1/account")
            if status != 200: raise ValueError("账户信息暂不可用，请稍后查询，不要猜测扣款账户")
        name = profile.get("name") if account.get("registered") and profile.get("account_type") in {"member", "registered"} else None
        contacts = account.get("contacts") or []
        contact = profile.get("email_mask") or profile.get("phone_mask") or (contacts[0] if contacts else None)
        display_name = "访客（未登录统一账户）"
        if account.get("registered"):
            display_name = name or contact or "已绑定统一账户（名称暂不可用）"
            if name and contact and name != contact: display_name += "（" + contact + "）"
        # Keep the selected Skill's allowance/balance; /account also contains
        # a different Skill's allowance and must not replace this quote.
        result["account"] = {**account, "name": name, "display_name": display_name}
        result["account_url"] = self.base + "/account"
        return result

    def validate_checkout(self, result):
        u=urlsplit(result.get("checkout_url", ""));origin=urlsplit(self.base)
        if (u.scheme,u.netloc)!=(origin.scheme,origin.netloc) or u.path!="/checkout" or not u.fragment or not parse_qs(u.query).get("session"):
            raise ValueError("收银台地址无效")
        return result

    def checkout(self, rid=None, open_browser=False, refresh=False):
        if open_browser and not rid: raise ValueError("请先保存原请求，再打开关联收银台")
        job=self.load_job(rid) if rid else None
        if job and job.get("checkout") and not refresh:
            result=self.validate_checkout(dict(job["checkout"]))
        else:
            status, _, result = self.call("POST", "/api/v1/cashier/sessions", {"skill_slug": SLUG})
            if status != 201: raise ValueError("统一收银台暂不可用，请稍后重试；没有发起充值或生图")
            self.validate_checkout(result)
        if job is not None:
            job["checkout"]=result
            if open_browser and not job.get("browser_open_attempted"):
                # Persist before handing off to the browser, including on interruption.
                job["browser_open_attempted"]=True
                private_json(self.jobpath(rid),job)
                try: job["browser_request_accepted"]=bool(webbrowser.open(result["checkout_url"],new=2))
                except (OSError,webbrowser.Error): job["browser_request_accepted"]=False
            private_json(self.jobpath(rid),job)
        return {**result,"request_id":rid,"account_url":self.base+"/account","payment_created":False,
                "browser_open_attempted":bool(job and job.get("browser_open_attempted")),
                "browser_request_accepted":bool(job and job.get("browser_request_accepted")),
                "browser_page_loaded":"unknown"}

    def open_and_follow(self, rid, refresh=False, timeout=45, progress=None, max_charge=None, consent=False):
        # The link is handed off before waiting; only an explicit prior invoke
        # authorization can unlock automatic submission. A browser open alone
        # never grants payment or image-processing permission.
        if max_charge is not None or consent:
            job=self.load_job(rid);body=job["body"]
            if not consent or type(max_charge) is not int or not 0<=max_charge<=body.get("expected_price_fen",-1) or body.get("external_processing_consent") is not True:
                raise ValueError("请先准备原请求，并提供已确认的费用上限和图片处理授权")
            job["continuation_authorization"]={"max_charge_fen":max_charge,"external_consent":True,"confirmed_at":datetime.now(timezone.utc).isoformat()}
            private_json(self.jobpath(rid),job)
        link=self.checkout(rid,open_browser=True,refresh=refresh)
        if progress:progress({"stage":"checkout_handoff",**link})
        authorization=self.load_job(rid).get("continuation_authorization") or {}
        resume=authorization.get("external_consent") is True and type(authorization.get("max_charge_fen")) is int
        result=self.watch(rid,timeout=timeout,resume=resume,max_charge=authorization.get("max_charge_fen") if resume else None,consent=resume,progress=progress)
        return {**result,"checkout_url":link["checkout_url"],"automatic_followup":True,"next_action":"继续查询同一请求；单段超时不是付款失败，不要求用户再回复已付"}

    def start(self,rid,amount,consent,timeout=45,handoff_only=False,progress=None):
        if not consent or type(amount) is not int or amount<0: raise ValueError("开启前须确认本次报价和图片处理授权")
        if not 1<=timeout<=60: raise ValueError("每段等待须为1–60秒")
        job=self.load_job(rid)
        if job.get('task_id'):
            result=self.status(rid)
            return {**result,'followup_required':result.get('status') in {'queued','running'},'next_action':'查询或下载原任务，不重新开启'}
        quote=self.quote(include_profile=False)
        self.check_mode(job["body"], quote)
        price=quote["resolution_prices_fen"][job["body"]["resolution"]]
        if price!=amount or job["body"].get("expected_price_fen", price)!=amount:raise ValueError('报价已变化，请重新向用户确认本次金额')
        job['continuation_authorization']={'max_charge_fen':amount,'external_consent':True,'confirmed_at':datetime.now(timezone.utc).isoformat()}
        private_json(self.jobpath(rid),job)
        # “开通” is the one explicit confirmation. Hand off the real shared
        # account/cashier before uploading or submitting the saved portrait.
        account = quote["account"]
        if handoff_only and account.get("registered") and account.get("balance_fen", -1) >= amount and not quote.get("first_recharge_required"):
            return {"stage":"ready", "request_id":rid, "followup_required":True,
                    "next_action":"沿同一请求执行已授权修图，无需再打开收银台"}
        link=self.checkout(rid,open_browser=True)
        if progress:progress({'stage':'checkout_handoff',**link})
        if handoff_only:
            return {**link,'http_status':200,'stage':'checkout_handoff','followup_required':True,'automatic_followup':False,
                    'next_action':'立即显示真实收银台链接，同轮按已确认上限watch --resume；不要求再回复已付'}
        return self.watch(rid,timeout=timeout,resume=True,max_charge=amount,consent=True,progress=progress)

    @staticmethod
    def check_mode(body, quote):
        mode=body.get("mode","retouch")
        if mode!="retouch" and mode not in quote.get("image_modes", []):
            raise ValueError("当前服务暂未开放本次创作模式，保留原方案")

    def _save_plan(self, prompt, images, resolution, size, original_prompt=None, raw_image=None, retouch_plan=None):
        if not isinstance(original_prompt,str) or not original_prompt.strip() or len(original_prompt)>6000: raise ValueError("请保留用户原始需求并先增强提示词")
        if not prompt.strip() or len(prompt)>5500: raise ValueError("修图指令须为1–5500字符，保留人物保护规则空间")
        mode=(retouch_plan or {}).get("mode","retouch")
        if resolution not in {"1K","2K","4K"} or len(images)!=(0 if mode=="generate" else 1):
            raise ValueError("请选择1K/2K/4K，并核对本次模式的参考图")
        private_directory(self.state)
        rid=secrets.token_hex(16);copies=[]
        for value in images:
            raw = raw_image if raw_image is not None else Path(value).expanduser().resolve().read_bytes()
            mime="image/png" if raw.startswith(bytes([137,80,78,71,13,10,26,10])) else "image/jpeg" if raw[:3]==bytes([255,216,255]) else None
            if len(raw)>10_000_000 or not mime: raise ValueError("请提供不超过10MB的PNG/JPEG参考图")
            filename=rid+(".png" if mime=="image/png" else ".jpg");folder=self.state/"references"
            private_directory(folder)
            with os.fdopen(os.open(folder/filename,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),"wb") as f: f.write(raw)
            copies.append({"filename":filename,"sha256":hashlib.sha256(raw).hexdigest(),"mime":mime})
        job={"skill_slug":SLUG,"base":self.base,"planned":True,"local_images":copies,
             "body":{"request_id":rid,"original_prompt":original_prompt,"prompt":prompt,"upload_ids":[],"resolution":resolution,"size":size}}
        if mode!="retouch":job["body"]["mode"]=mode
        if retouch_plan is not None:
            job["retouch_plan"] = retouch_plan
        private_json(self.jobpath(rid),job)
        return {"request_id":rid,"plan_saved":True,"prepared":False,"network_calls":0,"payment_created":False}

    def prepare_plan(self, rid, amount, consent):
        if not consent: raise ValueError("请先确认本次修图方案、实际报价与图片处理授权")
        job=self.load_job(rid);body=job["body"]
        if not job.get("planned"):
            if body.get("expected_price_fen")!=amount: raise ValueError("不能改变原请求冻结报价")
            return {"request_id":rid,"prepared":True,"already_prepared":True}
        q=self.quote(include_profile=False)
        if not q["account"].get("registered"): raise ValueError("请先在统一页面登录绑定账户，保留原请求")
        if q["resolution_prices_fen"].get(body["resolution"])!=amount: raise ValueError("价目已变化，请重新确认价格")
        self.check_mode(body,q)
        if body["size"] not in q["sizes"]: raise ValueError("不支持此画幅")
        for entry in job["local_images"][len(body["upload_ids"]):]:
            filename=entry["filename"]
            if filename not in {rid+".png",rid+".jpg"}: raise ValueError("原参考图检查点无效")
            path=self.state/"references"/filename
            if path.is_symlink() or path.parent.is_symlink(): raise ValueError("Private reference cannot be a symlink")
            raw=path.read_bytes()
            if hashlib.sha256(raw).hexdigest()!=entry["sha256"]: raise ValueError("保存的参考图已变化，请核对原请求")
            boundary="zpt"+secrets.token_hex(16)
            data=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="reference"\r\nContent-Type: {entry["mime"]}\r\n\r\n').encode()+raw+f"\r\n--{boundary}--\r\n".encode()
            status,_,result=self.call("POST","/api/v1/uploads",data,{"Content-Type":"multipart/form-data; boundary="+boundary})
            if status!=201: raise ValueError("参考图上传失败，保留原请求")
            body["upload_ids"].append(result["upload_id"]);private_json(self.jobpath(rid),job)
        body.update(expected_price_fen=amount,external_processing_consent=True);job["planned"]=False
        private_json(self.jobpath(rid),job)
        return {"request_id":rid,"prepared":True,"charge_fen":amount,"list_price_fen":amount,"resolution":body["resolution"],"account":q["account"],"payment_created":False}

    def progress(self, rid):
        job=self.load_job(rid);checked=datetime.now(timezone.utc).isoformat()
        if job.get("task_id"):
            task=self.status(rid)
            return {**task,"stage":task.get("status","unknown"),"checked_at":checked,"plan_saved":True}
        order=None
        if not job.get("planned"):
            status,_,order=self.call("GET","/api/v1/skills/"+SLUG+"/requests/"+rid)
            if status==200 and order.get("task_id"):
                job["task_id"]=order["task_id"];private_json(self.jobpath(rid),job)
                task=self.status(rid)
                return {**task,"stage":task.get("status","unknown"),"checked_at":checked,"plan_saved":True}
            if status not in {200,404}:raise ValueError("原订单进度暂不可用，请保留原请求，不重新生成")
        q=self.quote(include_profile=False);body=job["body"];price=body.get("expected_price_fen",q["resolution_prices_fen"][body["resolution"]]);account=q["account"]
        free=False;ready=(account["registered"] and not q.get("first_recharge_required") and account["balance_fen"]>=price) or bool(order and order.get("order_status")=="paid")
        result={"request_id":rid,"stage":"ready" if ready else "awaiting_account" if not account["registered"] else "awaiting_balance",
                "checked_at":checked,"plan_saved":True,"prepared":not job.get("planned"),"account":account,"list_price_fen":price,
                "charge_fen":0 if free else price,"latest_recharge":None,"payment_progress":"not_queried"}
        if order and order.get("order_status"):
            result["original_order"]={k:order.get(k) for k in ["out_trade_no","order_status","payment_mode","amount_fen"]}
            if order["order_status"] in {"refunded","refund_pending","refund_failed","fulfillment_failed"}:
                result["stage"]=order["order_status"]
            elif not ready and account["registered"] and order["payment_mode"]=="wechat":result["stage"]="awaiting_payment"
        if job.get("continuation_authorization"):
            result["authorized_max_charge_fen"]=job["continuation_authorization"]["max_charge_fen"]
        if job.get("checkout") and result["stage"] in {"awaiting_account", "awaiting_balance", "awaiting_payment"}:
            session=parse_qs(urlsplit(self.validate_checkout(job["checkout"])["checkout_url"]).query)["session"][0]
            status,_,value=self.call("GET","/api/v1/cashier/sessions/"+session+"/progress")
            if status!=200:
                result["payment_progress"]="unavailable"
                result["progress_http_status"]=status
            else:
                if value.get("skill_slug")!=SLUG: raise ValueError("收银台进度不属于当前Skill")
                result["latest_recharge"]=value.get("latest_recharge");result["payment_progress"]="observed"
                result["recharge_checked_at"]=value.get("checked_at")
        return result

    def poll(self, operation, deadline):
        previous = self.network_deadline
        self.network_deadline = min(previous, deadline) if previous is not None else deadline
        try:
            return operation()
        finally:
            self.network_deadline = previous

    def watch(self, rid, timeout=45, resume=False, max_charge=None, consent=False, open_checkout=False, progress=None):
        if not 1<=timeout<=60: raise ValueError("每段查询等待须为1–60秒")
        if resume and (not consent or type(max_charge) is not int or max_charge<0): raise ValueError("自动续接前须确认本次最高费用和外部处理授权")
        job=self.load_job(rid)  # Check ownership before any network or browser action.
        if resume:
            job["continuation_authorization"]={"max_charge_fen":max_charge,"external_consent":True,"confirmed_at":datetime.now(timezone.utc).isoformat()}
            private_json(self.jobpath(rid),job)
        deadline=time.monotonic()+timeout;opened=False;recovered=False
        while True:
            try:
                value = self.poll(lambda: self.progress(rid), deadline)
            except (TimeoutError, URLError) as error:
                if time.monotonic() < deadline and not isinstance(getattr(error, "reason", None), TimeoutError):
                    raise
                return {"request_id":rid,"stage":"unknown","wait_timed_out":True,"followup_required":True,
                        "next_action":"本轮查询已到时限，请稍后核对原请求"}
            if progress: progress(value)
            stage=value["stage"]
            if stage=="ready":
                if not resume: return value
                if value["charge_fen"]>max_charge: return {**value,"stage":"confirmation_required","auto_resumed":False}
                self.prepare_plan(rid,value["list_price_fen"],consent)
                result=self.invoke(rid,min(max_charge,value["list_price_fen"]))
                return {**result,"auto_resumed":result["http_status"]<400 and bool(result.get("task_id"))}
            if stage=="interrupted" and resume and not recovered:
                recovered=True
                result=self.status(rid,recover=True)
                if result["http_status"]>=400: return result
                if progress: progress({**result,"stage":"recovering_original"})
                continue
            if stage not in {"awaiting_account","awaiting_balance","awaiting_payment","queued","running"}: return value
            if open_checkout and not opened and stage in {"awaiting_account","awaiting_balance"}:
                link=self.checkout(rid,open_browser=True);opened=True
                if progress: progress({"stage":"checkout_handoff",**link})
            if time.monotonic()>=deadline: return {**value,"wait_timed_out":True,"next_action":"稍后查询原请求，不重新提交"}
            time.sleep(min(5,max(0,deadline-time.monotonic())))

    def prepare(self, prompt, images, resolution, size, amount, consent, original_prompt=None):
        if not consent: raise ValueError("请先取得本次图片与指令交给招聘通平台及其受托图片处理服务的授权")
        rid=self._save_plan(prompt,images,resolution,size,original_prompt)["request_id"]
        return self.prepare_plan(rid,amount,consent)

    def invoke(self,rid,max_charge=None):
        job=self.load_job(rid)
        if job.get("planned"): raise ValueError("创作方案已保存，先准备同一请求，不直接生图")
        body=dict(job["body"])
        if max_charge is None:
            max_charge=(job.get("continuation_authorization") or {}).get("max_charge_fen")
        if max_charge is None:
            raise ValueError("执行前须确认本次最高费用；请使用start或携带--max-charge-fen")
        if max_charge is not None:
            if type(max_charge) is not int or not 0<=max_charge<=body["expected_price_fen"]: raise ValueError("本次最高费用无效")
            body["max_charge_fen"]=max_charge
            if body.get("external_processing_consent") is True:
                job["continuation_authorization"]={"max_charge_fen":max_charge,"external_consent":True,"confirmed_at":datetime.now(timezone.utc).isoformat()}
                private_json(self.jobpath(rid),job)
        status,_,result=self.call("POST","/api/v1/skills/"+SLUG+"/invoke",body)
        if status==402:
            self.validate_checkout(result)
            job["checkout"]=result
            job["order_id"]=result.get("out_trade_no")
        if result.get("task_id"): job["task_id"]=result["task_id"]
        private_json(self.jobpath(rid),job)
        return {"http_status":status,"request_id":rid,"service":SLUG,**result}

    def status(self,rid,recover=False):
        job=self.load_job(rid)
        if not job.get("task_id"): raise ValueError("尚未取得任务号，请用同一invoke REQUEST_ID续接原请求，不新建prepare")
        suffix="/api/v1/photo-retouch/tasks/"+job["task_id"]+"/recover" if recover else "/api/v1/tasks/"+job["task_id"]
        status,_,result=self.call("POST" if recover else "GET",suffix,{} if recover else None)
        if isinstance(result.get("result"),dict):
            result["result"]={key:value for key,value in result["result"].items() if key not in {"checks","model","upstream"}}
            result["result"]["service"]="skill.zhaopintong.com"
        if result.get("error"):
            result["error"]="原任务待核对，请恢复原结果，勿重新生成" if result.get("status")=="interrupted" else "图片生成未成功，请联系招聘通平台核对原任务"
        return {"http_status":status,"request_id":rid,"service":"photo-retouch-designer",**result}

    def wait(self,rid,timeout=45,progress=None):
        if not 1<=timeout<=60: raise ValueError("每段等待时间须为1–60秒")
        deadline=time.monotonic()+timeout
        while True:
            try:
                result = self.poll(lambda: self.status(rid), deadline)
            except (TimeoutError, URLError) as error:
                if time.monotonic() < deadline and not isinstance(getattr(error, "reason", None), TimeoutError):
                    raise
                return {"request_id":rid,"stage":"unknown","wait_timed_out":True,
                        "next_action":"本轮查询已到时限，请稍后核对原任务"}
            if result["http_status"]!=200 or result.get("status") not in {"queued","running"}: return result
            if time.monotonic()>=deadline: return {**result,"wait_timed_out":True,"next_action":"稍后查询同一任务"}
            if progress: progress(result)
            time.sleep(min(10,max(0,deadline-time.monotonic())))

    def download(self,rid,output):
        job=self.load_job(rid);result=self.status(rid)
        if result.get("status")!="succeeded": raise ValueError("原任务未成功交付")
        status,_,raw=self.call("GET","/api/v1/tasks/"+job["task_id"]+"/files/0",raw=True)
        if status!=200: raise ValueError("结果已过期或不可下载")
        if not (raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8\xff')):
            raise ValueError("原结果不是有效的PNG/JPEG响应，请保留原任务核对，不重新生成")
        path=Path(output).expanduser().absolute();path.parent.mkdir(parents=True,exist_ok=True)
        existing_result_verified=False
        try:
            with path.open("xb") as f: f.write(raw)
        except FileExistsError:
            if path.is_symlink() or not path.is_file() or path.stat().st_size!=len(raw) or hashlib.sha256(path.read_bytes()).digest()!=hashlib.sha256(raw).digest():
                raise ValueError("目标已有不同文件，请指定新路径；已保留原文件和原任务，不重新生成")
            existing_result_verified=True
        delivery={"file":str(path),"request_id":rid,"task_id":job["task_id"],"service":"photo-retouch-designer","billing":result.get("billing"),"account":result.get("account"),"result":result.get("result"),"account_url":self.base+"/account"}
        delivery.update(file_sha256=hashlib.sha256(raw).hexdigest(),existing_result_verified=existing_result_verified)
        try:
            delivery["checkout_url"]=self.checkout(rid,refresh=True)["checkout_url"]
            delivery["recharge_link_available"]=True
        except (ValueError,OSError,URLError,KeyError):
            # A voluntary recharge link must never turn a delivered image into a failure.
            delivery["recharge_link_available"]=False
            delivery["recharge_notice"]="图片已保存，充值入口暂不可用，可前往统一账户。"
        return delivery


def main():
    parser=argparse.ArgumentParser(description="照片精修设计师：方案封装、统一充值、单张交付与原任务恢复")
    parser.add_argument("--state",type=Path,default=Path.home()/".photo-retouch-designer")
    sub=parser.add_subparsers(dest="command",required=True)
    sub.add_parser("quote")
    p=sub.add_parser("relocate");p.add_argument("request_id");p.add_argument("--to",type=Path,required=True)
    p=sub.add_parser("plan");p.add_argument("--plan-file",type=Path,required=True);p.add_argument("--image")
    p=sub.add_parser("prepare-plan");p.add_argument("request_id");p.add_argument("--price-fen",type=int,required=True);p.add_argument("--consent-external",action="store_true")
    p=sub.add_parser("start");p.add_argument("request_id");p.add_argument("--price-fen",type=int,required=True);p.add_argument("--consent-external",action="store_true");p.add_argument("--timeout",type=int,default=45);p.add_argument("--handoff-only",action="store_true")
    p=sub.add_parser("checkout");p.add_argument("request_id");p.add_argument("--open",action="store_true");p.add_argument("--refresh",action="store_true");p.add_argument("--no-watch",action="store_true");p.add_argument("--timeout",type=int,default=45);p.add_argument("--max-charge-fen",type=int);p.add_argument("--consent-external",action="store_true")
    p=sub.add_parser("watch");p.add_argument("request_id");p.add_argument("--timeout",type=int,default=45);p.add_argument("--resume",action="store_true");p.add_argument("--max-charge-fen",type=int);p.add_argument("--consent-external",action="store_true");p.add_argument("--open-checkout",action="store_true")
    for name in ["progress","invoke","status","recover","download","wait"]:
        p=sub.add_parser(name);p.add_argument("request_id")
        if name=="invoke":p.add_argument("--max-charge-fen",type=int)
        if name=="download":p.add_argument("--output",required=True)
        if name=="wait":p.add_argument("--timeout",type=int,default=45)
    args=parser.parse_args()
    def progress(value):
        stage = value.get("stage", value.get("status"))
        message = {"checkout_handoff": "统一账户入口已准备", "awaiting_account": "等待绑定统一账户",
                   "awaiting_balance": "等待余额可用", "awaiting_payment": "正在核对支付进度",
                   "ready": "已核对账户和费用条件", "queued": "图片任务已排队", "running": "正在处理图片",
                   "recovering_original": "正在取回原任务", "succeeded": "处理完成，正在核对成片"}.get(stage)
        if message:
            print(message, file=sys.stderr, flush=True)
    try:
        client=Client(DEFAULT_BASE,args.state)
        if args.command=="plan":result=client.plan(json.loads(args.plan_file.read_text(encoding="utf-8")),args.image)
        elif args.command=="relocate":result=client.relocate(args.request_id,args.to)
        elif args.command=="quote":result=client.quote()
        elif args.command=="prepare-plan":result=client.prepare_plan(args.request_id,args.price_fen,args.consent_external)
        elif args.command=="start":result=client.start(args.request_id,args.price_fen,args.consent_external,args.timeout,args.handoff_only,progress)
        elif args.command=="progress":result=client.progress(args.request_id)
        elif args.command=="watch":result=client.watch(args.request_id,args.timeout,args.resume,args.max_charge_fen,args.consent_external,args.open_checkout,progress)
        elif args.command=="checkout":
            if args.open and not args.no_watch:
                result=client.open_and_follow(args.request_id,args.refresh,args.timeout,progress,max_charge=args.max_charge_fen,consent=args.consent_external)
            else:
                if args.max_charge_fen is not None or args.consent_external:raise ValueError("只打开入口不产生修图授权；续接请使用watch --resume")
                result=client.checkout(args.request_id,args.open,args.refresh)
        elif args.command=="invoke":result=client.invoke(args.request_id,args.max_charge_fen)
        elif args.command=="download":result=client.download(args.request_id,args.output)
        elif args.command=="wait":result=client.wait(args.request_id,args.timeout,progress)
        else:result=client.status(args.request_id,args.command=="recover")
        print(json.dumps({"ok":result.get("http_status",200)<400,**result},ensure_ascii=False))
        return 2 if result.get("http_status",200)>=400 else 0
    except (LocalStateError, PermissionError) as error:
        print(json.dumps({"ok":False,"code":"PRIVATE_STATE_UNAVAILABLE",
                          "error":str(error) if isinstance(error, LocalStateError) else "当前工作区无法读写原任务，请保留原请求",
                          "request_id":getattr(args,"request_id",None),"service":SLUG},ensure_ascii=False))
    except ValueError as error:
        print(json.dumps({"ok":False,"code":"INVALID_INPUT_OR_STATE","error":str(error),"request_id":getattr(args,"request_id",None),"service":SLUG,"next_action":"保留原请求并核对；不要自动新建收费任务"},ensure_ascii=False))
    except (OSError,URLError,KeyError,TypeError):
        print(json.dumps({"ok":False,"code":"OUTCOME_UNKNOWN","error":"状态尚未核实，请用原请求progress查单；不要据此判断未扣费或重新生成","request_id":getattr(args,"request_id",None),"service":SLUG},ensure_ascii=False))
    return 2


if __name__=="__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    sys.exit(main())
