#!/usr/bin/env python3
"""风格契约门禁 —— 校验声音文件是否合格，并测量正文的声音指纹。

与 check_chapter_draft.py 的分工：
- check_chapter_draft.py 管「事实」：字数、场景节点证据、哈希、事务状态。
- 本脚本管「声音」：写手拿到的契约是不是一份真契约，正文离本书自己的基线有多远。

它刻意不做的事：判断文笔好不好。它只回答两个可计算的问题——
1. 这一章的声音契约，是实物样本契约，还是一串形容词？
2. 这一章正文的统计指纹，偏离本书声音基线多少？

设计前提：**声音无法被形容词描述，但可以被测量**。句长分布、短句占比、
逗号密度、对话段比例这些统计量不是文笔，但它们正是读者识别「同一个作者」的
物理载体。给一本书建立指纹基线，每章复测一次，文风漂移就从主观感觉变成差值。

用法：
    python scripts/check_style_contract.py <book-dir> --chapter 12
    python scripts/check_style_contract.py <book-dir> --chapter 12 --draft path.md --json
    python scripts/check_style_contract.py <book-dir> --guide-only     # 建书阶段，尚无草稿
"""

import argparse
import json
import os
import re
import sys
from typing import Dict, List, Optional, Tuple

GUIDE_REL = "story/style_guide.md"
EXEMPLARS_REL = "story/style_exemplars.md"

MIN_SAMPLE_BLOCKS = 3
MIN_CONTENT_QUOTES = 4
MIN_CONTRASTS = 3

# 只比对句级指标。段落级指标（平均段长、对话段占比）不参与基线比对——
# 声音样本是「行级摘录」，段落结构在样本里本就被打散，拿它比段落长度必然失真。
# 它们仍会出现在报告的指纹里，作为正文自身形态的参考。
METRICS: Tuple[Tuple[str, str, float], ...] = (
    ("meanSentenceLen", "平均句长", 0.35),
    ("shortSentenceRatio", "短句占比（≤6 字）", 0.50),
    ("longSentenceRatio", "长句占比（≥30 字）", 0.65),
    ("sentenceLenSd", "句长起伏（标准差）", 0.65),
    ("commaPerSentence", "逗号密度（逗号 / 句）", 0.50),
)

_SENT_SPLIT = re.compile(r"[。！？!?…]+")
_CJK = re.compile(r"[\u4e00-\u9fff]")
_LIST_MARK = re.compile(r"^\s*(?:[-*+]|\d+[.、)])\s*")
_CODE_REF = re.compile(r"([CWLKF])([1-6])\b")
_PATH_REF = re.compile(r"style-presets/([A-Za-z0-9_\-]+)/([A-Za-z0-9_\-]+\.md)")


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def _section(text: str, heading: str) -> str:
    """取某个 ## 标题下的正文，标题允许带英文后缀。"""
    pattern = re.compile(
        rf"(?ms)^##\s+{re.escape(heading)}[^\n]*\n(.*?)(?=^##\s+|\Z)"
    )
    match = pattern.search(text)
    return match.group(1) if match else ""


def _body(line: str) -> str:
    return re.sub(r"^\s*>\s?", "", line).strip()


def _plain(line: str) -> str:
    return _LIST_MARK.sub("", line).strip()


def _presets_root() -> str:
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "references",
        "style-presets",
    )


def _corpus_from_guide(text: str) -> str:
    """只取「## 声音样本」下各 ### 小节里的引用行，跳过段首说明。"""
    section = _section(text, "声音样本")
    if not section.strip():
        return ""
    lines: List[str] = []
    for block in re.split(r"(?m)^###\s+", section)[1:]:
        for line in block.splitlines():
            if line.strip().startswith(">"):
                body = _body(line)
                if body and "来源" not in body:
                    lines.append(body)
    return "\n\n".join(lines)


def _corpus_from_exemplars(text: str) -> str:
    """丢弃文件头使用说明（第一个 ## 之前），只取样本区内的实物句子。"""
    head = re.search(r"(?m)^##\s+", text)
    body_text = text[head.start():] if head else text
    lines: List[str] = []
    for line in body_text.splitlines():
        stripped = line.strip()
        if stripped.startswith(">"):
            body = _body(line)
            if body and "来源" not in body:
                lines.append(body)
        elif stripped.startswith(("- 原文：", "- 改后：")):
            lines.append(re.sub(r"^-\s*(?:原文|改后)：", "", stripped).strip("「」"))
    return "\n\n".join(lines)


def _load_preset_codes() -> Dict[str, str]:
    """扫描预设库，建立 编号 -> 文件 的映射，用于校验引用真实性。"""
    codes: Dict[str, str] = {}
    root = _presets_root()
    if not os.path.isdir(root):
        return codes
    for group in sorted(os.listdir(root)):
        group_dir = os.path.join(root, group)
        if not os.path.isdir(group_dir):
            continue
        for name in sorted(os.listdir(group_dir)):
            if not name.endswith(".md"):
                continue
            match = re.match(r"([a-z])(\d)-", name)
            if match:
                codes[f"{match.group(1).upper()}{match.group(2)}"] = f"{group}/{name}"
    return codes


def check_guide(text: str, presets: Dict[str, str]) -> Tuple[List[str], List[str], dict]:
    errors: List[str] = []
    warnings: List[str] = []
    section = _section(text, "声音样本")
    blocks = re.findall(r"(?m)^###\s+\S", section) if section.strip() else []
    section_lines = section.splitlines() if section.strip() else []
    quotes = [
        _body(line)
        for line in section_lines
        if line.strip().startswith(">") and "来源" not in line
    ]
    quotes = [q for q in quotes if len(q) >= 6]
    contrasts = sum(1 for line in text.splitlines() if _plain(line).startswith("不要"))

    if not section.strip():
        errors.append(
            "style_guide.md 缺少「## 声音样本」段——形容词清单对写作几乎无效，"
            "必须先写入实物样本（对话 / 动作 / 独白 / 章末各一两段）"
        )
    else:
        if len(blocks) < MIN_SAMPLE_BLOCKS:
            errors.append(
                f"「声音样本」段只有 {len(blocks)} 类样本，至少需要 {MIN_SAMPLE_BLOCKS} 类"
                "（建议覆盖对话、动作、独白、章末）"
            )
        if len(quotes) < MIN_CONTENT_QUOTES:
            errors.append(
                f"「声音样本」段只找到 {len(quotes)} 条实物句子，至少需要 {MIN_CONTENT_QUOTES} 条"
            )
    if contrasts < MIN_CONTRASTS:
        warnings.append(
            f"「不要 → 要的样子」对照只有 {contrasts} 组，建议至少 {MIN_CONTRASTS} 组"
            "（只有禁令会让文风向最安全的方向塌陷）"
        )

    refs = set()
    for group, name in _PATH_REF.findall(text):
        refs.add(f"{group}/{name}")
        if not os.path.isfile(os.path.join(_presets_root(), group, name)):
            errors.append(f"引用了不存在的风格预设文件：style-presets/{group}/{name}")
    codes = set()
    for letter, digit in _CODE_REF.findall(text):
        code = f"{letter.upper()}{digit}"
        codes.add(code)
        if presets and code not in presets:
            errors.append(f"引用了不存在的风格预设编号：{code}")
    if not refs and not codes:
        warnings.append(
            "style_guide.md 没有声明采用了哪个风格预设——无法复核这套声音是否有出处，"
            "也无法在预设升级时回溯"
        )

    contract = {
        "sampleBlocks": len(blocks),
        "contentQuotes": len(quotes),
        "contrasts": contrasts,
        "presetRefs": sorted(refs),
        "presetCodes": sorted(codes),
    }
    return errors, warnings, contract


def check_exemplars(text: str) -> Tuple[List[str], List[str], dict]:
    errors: List[str] = []
    warnings: List[str] = []
    corpus = _corpus_from_exemplars(text)
    sources = re.findall(r"(?m)^>\s*来源[：:]\s*(.+?)\s*$", text)
    if not corpus.strip():
        warnings.append(
            "style_exemplars.md 没有任何实物样本——质量跨章累积机制等于关闭。"
            "冷读判定「本章最有效的一段」后应立即回填到这里。"
        )
    if corpus.strip() and not sources:
        warnings.append("style_exemplars.md 的样本没有标注来源，无法回溯与清理")
    handwritten = sum(1 for s in sources if re.match(r"作者(手写|指定)", s.strip()))
    if corpus.strip() and handwritten == 0:
        warnings.append(
            "style_exemplars.md 尚无作者手写样本，当前全部为仿写——"
            "仿写只示范「这一类声音」，不示范「这本书的声音」"
        )
    contract = {
        "sampleLines": len([line for line in corpus.splitlines() if line.strip()]),
        "sources": sources,
        "handwritten": handwritten,
    }
    return errors, warnings, contract


def fingerprint(text: str) -> dict:
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    sentences = [s.strip() for s in _SENT_SPLIT.split(text) if _CJK.search(s)]
    if not sentences:
        return {}
    lengths = [len(re.sub(r"\s+", "", s)) for s in sentences]
    count = len(lengths)
    mean = sum(lengths) / count
    variance = sum((value - mean) ** 2 for value in lengths) / count
    para_lengths = [len(re.sub(r"\s+", "", p)) for p in paragraphs] or [0]
    commas = text.count("，") + text.count(",")
    dialogue = sum(1 for p in paragraphs if re.match(r"^[「『\"“]", p))
    return {
        "sentences": count,
        "paragraphs": len(paragraphs),
        "meanSentenceLen": round(mean, 2),
        "sentenceLenSd": round(variance ** 0.5, 2),
        "shortSentenceRatio": round(sum(1 for v in lengths if v <= 6) / count, 4),
        "longSentenceRatio": round(sum(1 for v in lengths if v >= 30) / count, 4),
        "commaPerSentence": round(commas / count, 3),
        "dialogueParagraphRatio": round(dialogue / max(len(paragraphs), 1), 4),
        "meanParagraphLen": round(sum(para_lengths) / max(len(para_lengths), 1), 2),
    }


def compare(base: dict, observed: dict) -> List[str]:
    """比值类指标必须相对差与绝对差同时越界才算漂移。

    短句占比从 0.05 涨到 0.10 是 100% 相对偏离，却毫无实际意义；
    加绝对下限可以避免小基数把噪声报成漂移。
    """
    drifts: List[str] = []
    for key, label, threshold in METRICS:
        baseline = base.get(key)
        current = observed.get(key)
        if not baseline or current is None:
            continue
        relative = abs(current - baseline) / baseline
        floor = 0.08 if key.endswith("Ratio") else 0.0
        if relative > threshold and abs(current - baseline) >= floor:
            direction = "偏长/偏多" if current > baseline else "偏短/偏少"
            drifts.append(
                f"{label}：基线 {baseline} → 本章 {current}"
                f"（{direction}，偏离 {relative * 100:.0f}%，阈值 {threshold * 100:.0f}%）"
            )
    return drifts


def _draft_path(book_dir: str, chapter: int, explicit: Optional[str]) -> Optional[str]:
    if explicit:
        path = explicit if os.path.isabs(explicit) else os.path.join(book_dir, explicit)
        return path if os.path.isfile(path) else None
    runtime = os.path.join(book_dir, "story", "runtime")
    for name in (f"chapter-{chapter:04d}.draft.md", f"chapter-{chapter}.draft.md"):
        candidate = os.path.join(runtime, name)
        if os.path.isfile(candidate):
            return candidate
    for pattern in (f"{chapter:04d}_*.md", f"{chapter}_*.md"):
        matches = sorted(__import__("glob").glob(os.path.join(book_dir, "chapters", pattern)))
        if matches:
            return matches[0]
    return None


def analyze_style(
    book_dir: str, chapter: int, draft: Optional[str] = None, check_draft: bool = True
) -> dict:
    """校验声音契约并测量本章指纹。返回可直接落盘的报告。"""
    errors: List[str] = []
    warnings: List[str] = []
    infos: List[str] = []

    guide_path = os.path.join(book_dir, GUIDE_REL)
    exemplars_path = os.path.join(book_dir, EXEMPLARS_REL)
    presets = _load_preset_codes()

    guide_text = _read(guide_path) if os.path.isfile(guide_path) else ""
    exemplars_text = _read(exemplars_path) if os.path.isfile(exemplars_path) else ""

    if not guide_text.strip():
        errors.append(
            "缺少 story/style_guide.md——这本书没有声音契约。"
            "先读 references/style-presets/README.md 选一种声音，再落这份文件"
        )
        guide_contract = {}
    else:
        guide_errors, guide_warnings, guide_contract = check_guide(guide_text, presets)
        errors.extend(guide_errors)
        warnings.extend(guide_warnings)

    exemplars_contract = {}
    if exemplars_text.strip():
        ex_errors, ex_warnings, exemplars_contract = check_exemplars(exemplars_text)
        errors.extend(ex_errors)
        warnings.extend(ex_warnings)
    else:
        warnings.append("缺少 story/style_exemplars.md——跨章质量累积机制未启用")

    baseline_corpus = "\n\n".join(
        part for part in (
            _corpus_from_guide(guide_text),
            _corpus_from_exemplars(exemplars_text),
        ) if part.strip()
    )
    baseline = fingerprint(baseline_corpus) if baseline_corpus.strip() else {}

    draft_path: Optional[str] = None
    observed: dict = {}
    drift: List[str] = []
    if not check_draft:
        infos.append("仅校验契约结构；基线指纹已算出，接入草稿后即可逐项比对")
    else:
        draft_path = _draft_path(book_dir, chapter, draft)
        if draft_path:
            observed = fingerprint(_read(draft_path))
            if baseline and observed:
                drift = compare(baseline, observed)
                if drift:
                    warnings.append(
                        "本章正文的声音指纹偏离本书基线，共 "
                        f"{len(drift)} 项——可能是文风漂移，也可能是有意的节奏变化，请人工确认："
                    )
                    warnings.extend(drift)
                else:
                    infos.append(f"声音指纹与基线一致（{len(METRICS)} 项指标全部在阈值内）")
            elif not baseline:
                infos.append("无声音基线可比对（样本库为空），本章只做了契约结构校验")
        else:
            warnings.append(f"找不到第 {chapter} 章草稿，本次只校验了声音契约结构")

    return {
        "schemaVersion": "4.1",
        "chapter": chapter,
        "status": "fail" if errors else "pass",
        "draftPath": os.path.relpath(draft_path, book_dir).replace(os.sep, "/") if draft_path else "",
        "errors": errors,
        "warnings": warnings,
        "infos": infos,
        "contract": {"guide": guide_contract, "exemplars": exemplars_contract},
        "driftThreshold": {key: threshold for key, _, threshold in METRICS},
        "comparableMetrics": [key for key, _, _ in METRICS],
        "baseline": baseline,
        "draft": observed,
        "drift": drift,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="风格契约门禁：声音文件结构校验与指纹测量")
    parser.add_argument("book_dir", help="书籍根目录")
    parser.add_argument("--chapter", type=int, default=0, help="章节编号")
    parser.add_argument("--draft", help="草稿路径（相对书根或绝对路径）")
    parser.add_argument("--guide-only", action="store_true", help="只校验声音文件结构，不比对指纹")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    args = parser.parse_args()

    if not os.path.isdir(args.book_dir):
        print(f"错误：目录不存在 {args.book_dir}", file=sys.stderr)
        raise SystemExit(1)
    if not args.guide_only and args.chapter < 1:
        print("错误：需要 --chapter（或使用 --guide-only）", file=sys.stderr)
        raise SystemExit(1)

    report = analyze_style(
        args.book_dir, args.chapter, args.draft, check_draft=not args.guide_only
    )

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("[PASS] Style contract gate passed" if report["status"] == "pass"
              else "[FAIL] Style contract gate failed")
        for message in report["errors"]:
            print(f"  [ERROR] {message}")
        for message in report["warnings"]:
            print(f"  [WARN] {message}")
        for message in report["infos"]:
            print(f"  [INFO] {message}")
    raise SystemExit(0 if report["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
