#!/usr/bin/env python3
"""从磁盘为单章重建有限、可追溯的主代理工作包。

包的顺序即注意力顺序，这是本文件最重要的设计决定：

1. 声音契约在最前——它决定「怎么写」。既有风格文件根本没有进过工作包，
   写手看不到任何一句实物样本，只能靠上一章的惯性漂移。
2. 创作简报在中间——它决定「写什么、为什么值得写」。结构化 intent 是给门禁
   用的机器契约，直接 dump JSON 会诱导写手「填表」而不是「写戏」。
3. 事实账本在后面——它决定「不能写错什么」。
4. 机器契约与落笔自检在最后——字数下限只对门禁有意义，摆在首行等于把
   完成字数设成生成目标。
"""

import argparse
import glob
import hashlib
import json
import os
import re

from _contract import chapter_length_limits, file_sha256

STYLE_SOURCES = (
    ("story/style_guide.md", 6000, True),
    ("story/style_exemplars.md", 6000, False),
)

FINAL_CHECKLIST = (
    "## 五、落笔前最后一眼",
    "",
    "- 前三行已经在戏里：有人在做某事、有话正被说出、有异常正被察觉——不是回顾上一章。",
    "- 本章至少一处具体压力、关系、信息或代价发生了不可与章首互换的变化。",
    "- 描写都在改变读者对行动、人物或局面的理解；删掉后情节不受影响的段落应合并或删除。",
    "- 章末停在能量上升沿，最后一句之后不再写任何总结、金句或计划宣布。",
    "- 通读一遍刚写的正文：哪些句子是「完成度汇报」，而不是「事情正在发生」？改掉它们。",
)


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def _clip(text: str, limit: int, tail: bool = False) -> str:
    if len(text) <= limit:
        return text
    return ("…\n" + text[-limit:]) if tail else (text[:limit] + "\n…")


def _cell(value) -> str:
    text = str(value if value is not None else "").strip().replace("|", "/")
    return text or "—"


def _bullets(items, empty: str = "（未声明）") -> str:
    values = [str(item).strip() for item in items or [] if str(item).strip()]
    return "\n".join(f"- {value}" for value in values) if values else f"- {empty}"


def _render_brief(intent: dict) -> str:
    """把 intent.json 渲染成叙事简报，而不是把机器契约原样倒给写手。"""
    parts = []

    question = str(intent.get("dramaticQuestion", "")).strip()
    parts += ["### 本章戏剧问题", "", question or "（未声明）"]

    pov = str(intent.get("pov", "")).strip()
    if pov:
        parts += ["", f"**视角**：{pov}"]

    time_arch = intent.get("timeArchitecture") or {}
    if time_arch:
        span = " → ".join(
            value for value in (
                str(time_arch.get("start", "")).strip(),
                str(time_arch.get("end", "")).strip(),
            ) if value
        )
        lines = [
            "### 时间安排",
            "",
            f"- 覆盖：{span or '（未声明）'}；耗时 {_cell(time_arch.get('elapsed'))}",
        ]
        if time_arch.get("cutReason"):
            lines.append(f"- 这样切章的理由：{time_arch['cutReason']}")
        segments = time_arch.get("segments") or []
        if segments:
            lines += [
                "",
                "| 段 | 模式 | 时间 | 地点 | 这一段承担什么 | 压缩/跳时理由 |",
                "| --- | --- | --- | --- | --- | --- |",
            ]
            for segment in sorted(segments, key=lambda row: row.get("order", 0)):
                span = " → ".join(
                    value for value in (
                        str(segment.get("start", "")).strip(),
                        str(segment.get("end", "")).strip(),
                    ) if value
                )
                lines.append(
                    "| {sid} | {mode} | {span} | {loc} | {purpose} | {cut} |".format(
                        sid=_cell(segment.get("segmentId")),
                        mode=_cell(segment.get("mode")),
                        span=_cell(span),
                        loc=_cell(segment.get("location")),
                        purpose=_cell(segment.get("purpose")),
                        cut=_cell(segment.get("cutReason")),
                    )
                )
        parts += [""] + lines

    beats = intent.get("sceneBeats") or []
    if beats:
        lines = ["### 本章要成立的场景", ""]
        for beat in beats:
            lines.append(
                "#### {bid} · {mode} · {function}".format(
                    bid=_cell(beat.get("beatId")),
                    mode=_cell(beat.get("mode")),
                    function=_cell(beat.get("dramaticFunction")),
                )
            )
            lines.append(f"- 压力 / 目标：{_cell(beat.get('goalOrPressure'))}")
            lines.append(f"- 转折 / 冲突：{_cell(beat.get('conflictOrTurn'))}")
            lines.append(f"- 必须发生的结果：{_cell(beat.get('requiredResult'))}")
            lines.append(f"- 时空锚点：{_cell(beat.get('timeSpaceAnchor'))}")
            lines.append(f"- 描写职责：{_cell(beat.get('descriptionObligation'))}")
            if beat.get("participants"):
                lines.append("- 在场：" + "、".join(str(name) for name in beat["participants"]))
            if beat.get("timeSegmentId"):
                lines.append(f"- 所属时间段：{beat['timeSegmentId']}")
            lines.append("")
        parts += lines

    novelty = intent.get("noveltyFingerprint")
    lines = ["### 与近章相比新在哪里", ""]
    if intent.get("noveltyDelta"):
        lines += [str(intent["noveltyDelta"]), ""]
    if isinstance(novelty, dict):
        lines.append(f"- 目标：{_cell(novelty.get('goal'))}")
        lines.append(f"- 阻碍：{_cell(novelty.get('obstacle'))}")
        lines.append(f"- 转折：{_cell(novelty.get('turn'))}")
        lines.append(f"- 结果：{_cell(novelty.get('outcome'))}")
        lines.append(f"- 情绪落点：{_cell(novelty.get('emotionalEndpoint'))}")
        chain = novelty.get("actionChain") or []
        if chain:
            lines.append("- 行动链：" + " → ".join(str(step) for step in chain))
        fresh = novelty.get("newInformation") or []
        if fresh:
            lines.append("- 新增信息：" + "、".join(str(item) for item in fresh))
    else:
        lines.append("- （未填写结构化指纹）")
    parts += lines

    permissions = intent.get("knowledgePermissions") or []
    if permissions:
        lines = [
            "### 谁知道什么（超出这张表的知情即为越权）",
            "",
            "| 角色 | 开场已知 | 本章获知（路径） | 仍然不知道 |",
            "| --- | --- | --- | --- |",
        ]
        for permission in permissions:
            acquired = permission.get("acquiredThisChapter") or []
            learned = "；".join(
                "{fact}（{mode}）".format(
                    fact=_cell(item.get("fact")),
                    mode=_cell(item.get("acquisitionMode")),
                )
                for item in acquired
            )
            lines.append(
                "| {who} | {known} | {learned} | {unknown} |".format(
                    who=_cell(permission.get("character")),
                    known=_cell("、".join(permission.get("knownAtStart") or [])),
                    learned=_cell(learned),
                    unknown=_cell("、".join(permission.get("stillUnknown") or [])),
                )
            )
        parts += [""] + lines

    pairs = intent.get("relationshipPermissions") or []
    if pairs:
        lines = [
            "### 关系此刻允许什么（超出即越级，需本章可见催化）",
            "",
            "| 关系对 | 开场阶段 | 现在允许 | 本章计划变化 | 催化事件 | 变化后的后效 |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
        for pair in pairs:
            lines.append(
                "| {pid} | {stage} | {allowed} | {change} | {catalyst} | {aftermath} |".format(
                    pid=_cell(pair.get("pairId")),
                    stage=_cell(pair.get("stageAtStart")),
                    allowed=_cell("、".join(pair.get("allowedFamiliarity") or [])),
                    change=_cell(pair.get("plannedChange")),
                    catalyst=_cell(pair.get("catalystEventId")),
                    aftermath=_cell(pair.get("aftermath")),
                )
            )
        parts += [""] + lines

    return "\n".join(parts).rstrip()


def build_work_packet(book_dir: str, chapter: int) -> tuple[str, dict]:
    runtime = os.path.join(book_dir, "story", "runtime")
    intent_path = os.path.join(runtime, f"chapter-{chapter:04d}.intent.json")
    if not os.path.isfile(intent_path):
        raise ValueError("缺少当前章 intent.json")
    intent = json.loads(_read(intent_path))
    if intent.get("chapter") != chapter:
        raise ValueError("intent 章号与工作包章号不一致")
    participants = sorted({
        character
        for beat in intent.get("sceneBeats", [])
        for character in beat.get("participants", [])
    })
    fact_ids = sorted({
        use.get("factId", "")
        for beat in intent.get("sceneBeats", [])
        for use in beat.get("knowledgeUses", [])
        if use.get("factId")
    })
    pair_ids = sorted({
        pair_id
        for beat in intent.get("sceneBeats", [])
        for pair_id in beat.get("relationshipRefs", [])
    })
    sources = [intent_path]
    parts = [
        "# 当前章主代理工作包",
        "> 由文件重建；不得传给无背景冷读子代理。\n"
        "> 顺序即注意力顺序：先声音，再戏，后事实，机器契约在末尾。",
    ]

    parts += ["## 一、声音契约（决定「怎么写」）", ""]
    style_found = []
    for rel, limit, required in STYLE_SOURCES:
        path = os.path.join(book_dir, rel)
        if os.path.isfile(path) and _read(path).strip():
            sources.append(path)
            style_found.append(rel)
            parts += [f"### {rel}", "", _clip(_read(path), limit), ""]
        elif required:
            parts += [
                f"### {rel}（缺失）",
                "",
                "本书尚无声音样本。落笔前先与作者确认 5–10 段「这就是本书要的声音」的实物段落"
                "（作者手写或从已封板章节中挑选），写入该文件；只有形容词清单的风格文件对写作几乎无效。",
                "",
            ]
    if style_found:
        parts += [
            "> 上面是本书的声音样本与禁令。禁令只说明不要写成什么样；样本才说明要写成什么样。",
            "> 落笔时以样本的句长、意象密度、叙述距离和对话语气为准，不以形容词描述为准。",
            "",
        ]

    parts += ["## 二、权威章节意图（创作简报）", "", _render_brief(intent), ""]

    parts += ["## 三、事实账本", ""]
    previous = []
    for path in sorted(glob.glob(os.path.join(book_dir, "chapters", "*.md"))):
        match = re.match(r"^(\d+)_", os.path.basename(path))
        if match and int(match.group(1)) < chapter:
            previous.append(path)
    previous = previous[-2:]
    if previous:
        parts += ["### 最近正式章结尾（只作行文惯性参考，不得复述其中情节）", ""]
        for path in previous:
            sources.append(path)
            parts += [f"#### {os.path.basename(path)}", _clip(_read(path), 1800, tail=True), ""]

    for rel, limit in (("story/current_focus.md", 3500), ("story/chapter_summaries.md", 4500), ("story/pending_hooks.md", 3500)):
        path = os.path.join(book_dir, rel)
        if os.path.isfile(path):
            sources.append(path)
            parts += [f"### {rel}", _clip(_read(path), limit, tail=("summaries" in rel)), ""]

    state_path = os.path.join(book_dir, "story", "current_state.md")
    if os.path.isfile(state_path):
        sources.append(state_path)
        terms = set(participants + fact_ids + pair_ids)
        relevant = [line for line in _read(state_path).splitlines() if any(term and term in line for term in terms)]
        parts += [
            "### 本章相关状态",
            "",
            "\n".join(relevant) if relevant else "（未命中稳定 ID；须先补全账本引用）",
            "",
        ]

    role_paths = glob.glob(os.path.join(book_dir, "story", "roles", "**", "*.md"), recursive=True)
    for path in sorted(role_paths):
        name = os.path.splitext(os.path.basename(path))[0]
        if name in participants:
            sources.append(path)
            parts += [f"### 角色：{name}", _clip(_read(path), 3000), ""]

    book_path = os.path.join(book_dir, "book.json")
    book = json.loads(_read(book_path))
    sources.append(book_path)
    minimum, target, maximum = chapter_length_limits(book)

    parts += [
        "## 四、机器契约（供门禁校验，不是写作目标）",
        "",
        f"- 本章字符下限 {minimum}；目标 {target}；软上限 {maximum}。",
        "- 字数不足时补完缺失的戏剧工作（冲突过程、选择、后效、动作可读性、关系变化），"
        "不得复述前情、同义心理、无作用景物或提前解释后文。",
        "- 每个场景节点都需能在正文中定位到具体段落与精确短引，用于事后举证。",
        "",
    ]

    parts += list(FINAL_CHECKLIST)

    packet = re.sub(r"\n{3,}", "\n\n", "\n\n".join(parts)).rstrip() + "\n"
    # 标题前必须有空行，否则表格与标题会粘在一起，Markdown 渲染出来的提示可读性很差。
    packet = re.sub(r"(?<!\n)\n(?=#{1,6} )", "\n\n", packet)
    packet = re.sub(r"\n{3,}", "\n\n", packet)
    manifest_sources = [{
        "path": os.path.relpath(path, book_dir).replace(os.sep, "/"),
        "sha256": file_sha256(path),
    } for path in sources]
    manifest = {
        "schemaVersion": "4.1",
        "chapter": chapter,
        "participants": participants,
        "factIds": fact_ids,
        "pairIds": pair_ids,
        "styleSources": style_found,
        "sources": manifest_sources,
        "packetSha256": "sha256:" + hashlib.sha256(packet.encode("utf-8")).hexdigest(),
    }
    return packet, manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="重建当前章主代理工作包")
    parser.add_argument("book_dir")
    parser.add_argument("--chapter", type=int, required=True)
    parser.add_argument("--output")
    parser.add_argument("--print", dest="print_packet", action="store_true",
                        help="把工作包写到标准输出，便于直接阅读")
    args = parser.parse_args()
    packet, manifest = build_work_packet(args.book_dir, args.chapter)
    if args.print_packet:
        import sys
        sys.stdout.write(packet)
    runtime = os.path.join(args.book_dir, "story", "runtime")
    output = args.output or os.path.join(runtime, f"chapter-{args.chapter:04d}.work-packet.md")
    if not os.path.isabs(output):
        output = os.path.join(args.book_dir, output)
    os.makedirs(os.path.dirname(output), exist_ok=True)
    temp = output + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        handle.write(packet)
    os.replace(temp, output)
    manifest_path = os.path.splitext(output)[0] + ".json"
    with open(manifest_path + ".tmp", "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    os.replace(manifest_path + ".tmp", manifest_path)
    if not args.print_packet:
        print(json.dumps({"ok": True, "output": output, "manifest": manifest_path}, ensure_ascii=False))


if __name__ == "__main__":
    main()
