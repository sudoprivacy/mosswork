#!/usr/bin/env python3
"""
班主任工作台 - HTML 生成脚本

将班级名单数据注入工作台模板，生成可在电脑端和手机端直接打开使用的
单文件 HTML 工作台。

用法:
  python generate_workbench.py --data class_data.json --output workbench.html
  python generate_workbench.py --data class_data.json            # 默认输出到当前目录
  cat class_data.json | python generate_workbench.py             # 从 stdin 读取

数据格式 (JSON):
{
  "meta": {
    "className": "24软件技术1班",
    "grade": "高职",
    "teacher": "汤老师",
    "settings": { "theme": "blue", "widgets": [...], "customFields": [...] }
  },
  "students": [
    { "id": "s1", "name": "张三", "studentId": "20240101", "gender": "男", ... }
  ],
  "tasks": [...],
  "announcements": [...],
  "activities": [...],
  "attendance": {},
  "communicationLog": []
}

作者: WorkBuddy Skill - homeroom-teacher-workbench
"""

import sys
import os
import json
import re
import argparse
from pathlib import Path
from datetime import datetime


# 脚本所在目录
SCRIPT_DIR = Path(__file__).parent.resolve()
# 模板目录 (相对于脚本的上两级 assets/workbench-template/)
TEMPLATE_DIR = SCRIPT_DIR.parent / "assets" / "workbench-template"

# 软性性能提示阈值（超过此人数，单文件 HTML 滚动/渲染可能变慢）
PERF_WARN_STUDENTS = 300


class GenerationError(Exception):
    """生成过程中的用户级错误，配合 run() 输出友好提示。"""

    def __init__(self, message, hint=None):
        super().__init__(message)
        self.message = message
        self.hint = hint

    def __str__(self):
        return self.message


def die(msg, hint=None, code=2):
    """打印友好错误信息并退出。"""
    print(f"\n❌ 生成失败：{msg}", file=sys.stderr)
    if hint:
        print(f"   💡 建议：{hint}", file=sys.stderr)
    sys.exit(code)


# ============================================================
# 按学段聚焦的推荐配置（差异化核心：不做"18个模块全开"，而是给每个学段一套够用的配置）
# 用户可在工作台「设置」里随时改，这里只负责"开局就对"。
# ============================================================
GRADE_ALIASES = [
    (('幼儿园', '幼儿', '学前', 'kindergarten'), '幼儿园'),
    (('小学', 'primary'), '小学'),
    (('高中', 'high school'), '高中'),
    (('高职', '中职', '大专', '大学', 'college', 'vocational'), '高职'),
    (('初中', '中学', 'middle school'), '初中'),
]

GRADE_PRESETS = {
    '幼儿园': {
        'focus': '接送安全 · 过敏与特异体质 · 情绪与如厕 · 高频家校沟通',
        'customFields': ['过敏源', '接送人', '情绪状态'],
        'hiddenModules': ['scores', 'dorm', 'timetable', 'cadres', 'duty'],
        'coreModules': ['core-todo', 'core-safety', 'core-growth', 'core-comm', 'core-project'],
        'quickActions': ['allPresent', 'comm', 'journal', 'task', 'student', 'point', 'backup', 'exportcenter'],
    },
    '小学': {
        'focus': '行为习惯养成 · 作业收交 · 值日 · 家校沟通 · 校园安全',
        'customFields': ['家长职业', '特长爱好', '值日组', '是否托管'],
        'hiddenModules': ['dorm', 'scores'],
        'coreModules': ['core-todo', 'core-safety', 'core-growth', 'core-comm', 'core-moral', 'core-project'],
        'quickActions': ['allPresent', 'rollcall', 'homework', 'point', 'task', 'comm', 'leave', 'backup', 'exportcenter'],
    },
    '初中': {
        'focus': '叛逆期纪律 · 成绩分化 · 控辍保学 · 心理与手机管理',
        'customFields': ['宿舍号', '违纪记录', '培优组'],
        'hiddenModules': [],
        'coreModules': ['core-todo', 'core-followup', 'core-safety', 'core-dropout', 'core-growth',
                        'core-comm', 'core-moral', 'core-project'],
        'quickActions': ['allPresent', 'rollcall', 'leave', 'homework', 'point', 'task', 'comm', 'backup', 'exportcenter'],
    },
    '高中': {
        'focus': '升学与成绩跟踪 · 选科 · 心理疏导 · 住宿管理',
        'customFields': ['选科方向', '宿舍号', '班委职务', '专业意向'],
        'hiddenModules': ['duty'],
        'coreModules': ['core-todo', 'core-followup', 'core-safety', 'core-dropout', 'core-growth',
                        'core-comm', 'core-moral', 'core-project'],
        'quickActions': ['allPresent', 'leave', 'point', 'task', 'comm', 'journal', 'report', 'backup', 'exportcenter'],
    },
    '高职': {
        'focus': '实习管理 · 宿舍 · 控辍保学(流失率) · 征兵 · 就业与政治面貌',
        'customFields': ['宿舍号', '实习单位', '政治面貌', '建档立卡'],
        'hiddenModules': ['duty'],
        'coreModules': ['core-todo', 'core-followup', 'core-safety', 'core-dropout', 'core-growth',
                        'core-comm', 'core-moral', 'core-project', 'core-enlist'],
        'quickActions': ['allPresent', 'leave', 'point', 'task', 'comm', 'journal', 'report', 'backup', 'exportcenter'],
    },
}


def normalize_grade(grade):
    """把各种写法归一化到 幼儿园/小学/初中/高中/高职。"""
    if not grade:
        return ''
    g = str(grade).strip()
    for names, canon in GRADE_ALIASES:
        for n in names:
            if n in g:
                return canon
    return ''


def apply_grade_preset(data, grade, extra_fields=None, force=False):
    """按学段套用推荐配置。

    force=True 用于名单直转模式（新建班级）；
    force=False 用于 JSON 模式，只填补用户没设置过的项，不覆盖用户配置。
    """
    canon = normalize_grade(grade)
    preset = GRADE_PRESETS.get(canon)
    if not preset:
        return data

    meta = data.setdefault('meta', {})
    settings = meta.setdefault('settings', {})

    # 自定义字段：预设字段 + 用户 --field 指定的字段（去重、保序）
    fields = list(preset.get('customFields', []))
    for f in (extra_fields or []):
        if f and f not in fields:
            fields.append(f)
    if force or not settings.get('customFields'):
        settings['customFields'] = fields

    for key in ('hiddenModules', 'coreModules', 'quickActions'):
        if force or not settings.get(key):
            settings[key] = list(preset.get(key, []))

    # 记录用了哪套预设，便于用户知道"为什么默认长这样"
    meta['gradePreset'] = canon
    meta['gradeFocus'] = preset.get('focus', '')
    return data


def load_template_files():
    """读取模板文件: index.html, styles.css, app.js"""
    html_path = TEMPLATE_DIR / "index.html"
    css_path = TEMPLATE_DIR / "styles.css"
    js_path = TEMPLATE_DIR / "app.js"

    if not html_path.exists():
        print(f"错误: 模板文件不存在: {html_path}", file=sys.stderr)
        sys.exit(1)

    html = html_path.read_text(encoding="utf-8")
    css = css_path.read_text(encoding="utf-8") if css_path.exists() else ""
    js = js_path.read_text(encoding="utf-8") if js_path.exists() else ""

    return html, css, js


def parse_roster(text, auto_ids=True):
    """
    解析纯文本/CSV 名单为 students 数组。

    支持格式:
      - 每行一个学生: "张三" 或 "张三,20240101,男,138xxx"
      - CSV 列序: 姓名,学号,性别,电话,宿舍,家长姓名,家长电话 (多余列忽略)
      - 逗号/空格/顿号分隔的一行名单: "张三、李四、王五"
    """
    students = []
    text = text.strip()
    if not text:
        return students

    # 判断是否多列 (含分隔符且分隔后第二列看起来不像纯数字续名)
    lines = [l.strip() for l in text.split("\n") if l.strip()]

    for i, line in enumerate(lines):
        # 统一分隔符
        parts = [p.strip() for p in re.split(r'[,，、\t]', line) if p.strip()]
        if not parts:
            continue

        if len(parts) == 1:
            # 单列: 可能是单名，也可能是一行多个名字(空格分隔)
            names = parts[0].split()
            if len(names) > 1:
                for n in names:
                    students.append({"name": n})
            else:
                students.append({"name": parts[0]})
        else:
            s = {"name": parts[0]}
            if len(parts) > 1 and parts[1]: s["studentId"] = parts[1]
            if len(parts) > 2 and parts[2]: s["gender"] = parts[2]
            if len(parts) > 3 and parts[3]: s["phone"] = parts[3]
            if len(parts) > 4 and parts[4]: s["dorm"] = parts[4]
            if len(parts) > 5 and parts[5]: s["parentName"] = parts[5]
            if len(parts) > 6 and parts[6]: s["parentPhone"] = parts[6]
            # 第7列以后忽略 (与 CSV 头部对应时) —— 若第一行是表头则跳过
            students.append(s)

    # 跳过 CSV 表头行
    if students and students[0].get("name") in ("姓名", "名字", "name", "Name", "NAME"):
        students = students[1:]

    if auto_ids:
        for i, s in enumerate(students):
            if not s.get("id"):
                s["id"] = f"s{i+1}"

    return students


def build_data_from_roster(roster_text, class_name="我的班级", grade="", teacher="",
                           theme="warm", custom_fields=None, motto=""):
    """从纯文本名单直接构建完整班级数据。"""
    students = parse_roster(roster_text)
    if not students:
        raise GenerationError(
            "名单解析结果为空",
            hint="请确认名单文件非空。支持：每行一个姓名（如「张三」）、顿号/逗号分隔（如「张三、李四」）、或带表头的 CSV（姓名,学号,性别...）。首行若为「姓名」表头会自动跳过。"
        )

    import secrets
    today = datetime.now().strftime("%Y-%m-%d")
    return {
        "meta": {
            "classId": "c" + secrets.token_hex(4),
            "className": class_name,
            "grade": grade,
            "teacher": teacher,
            "motto": motto,
            "createdAt": today,
            "studentCount": len(students),
            "settings": {
                "theme": theme,
                "widgets": ["stats", "attendance", "trend", "tasks", "schedule", "birthday", "announcements", "duty"],
                "customFields": custom_fields or []
            }
        },
        "students": students,
        "seating": {"rows": 6, "cols": 6, "map": {}},
        "attendance": {},
        "tasks": [],
        "communicationLog": [],
        "announcements": [],
        "activities": [],
        "exams": [],
        "duty": {"groups": [], "startDate": today, "content": "扫地、擦黑板、倒垃圾、摆桌椅、关门窗"},
        "cadres": [],
        "honors": [],
        "timetable": {"rows": 9, "weekend": False, "grid": {}},
        "points": [],
        "dormChecks": [],
        "meetingPlans": [],
        "comments": {},
        "journal": [],
        "leaves": [],
        "homeworks": [],
        "coreTodo": [],
        "coreFollow": [],
        "safety": [],
        "dropout": [],
        "growth": [],
        "projects": [],
        "enlist": [],
        "moralLib": []
    }


def validate_data(data):
    """验证班级数据结构完整性，补全缺失字段"""
    if not isinstance(data, dict):
        print("错误: 数据必须是 JSON 对象", file=sys.stderr)
        sys.exit(1)

    # 补全 meta
    if "meta" not in data:
        data["meta"] = {}
    meta = data["meta"]
    meta.setdefault("className", "我的班级")
    meta.setdefault("grade", "")
    meta.setdefault("teacher", "")
    meta.setdefault("motto", "")
    # 多班管理唯一 ID（同一班级重复生成保持不变，新班级自动分配）
    if not meta.get("classId"):
        import secrets
        meta["classId"] = "c" + secrets.token_hex(4)
    meta.setdefault("createdAt", datetime.now().strftime("%Y-%m-%d"))
    meta.setdefault("studentCount", len(data.get("students", [])))
    meta.setdefault("settings", {})
    meta["settings"].setdefault("theme", "warm")
    meta["settings"].setdefault("widgets", ["stats", "attendance", "trend", "tasks", "schedule", "birthday", "announcements", "duty"])
    meta["settings"].setdefault("customFields", [])

    # 补全学生 ID
    for i, s in enumerate(data.get("students", [])):
        if not s.get("id"):
            s["id"] = f"s{i+1}"

    # 补全其他集合
    data.setdefault("attendance", {})
    data.setdefault("tasks", [])
    data.setdefault("communicationLog", [])
    data.setdefault("announcements", [])
    data.setdefault("activities", [])
    data.setdefault("exams", [])
    data.setdefault("seating", {"rows": 6, "cols": 6, "map": {}})
    data.setdefault("duty", {"groups": [], "startDate": datetime.now().strftime("%Y-%m-%d"), "content": "扫地、擦黑板、倒垃圾、摆桌椅、关门窗"})
    data.setdefault("cadres", [])
    data.setdefault("honors", [])
    data.setdefault("timetable", {"rows": 9, "weekend": False, "grid": {}})
    data.setdefault("points", [])
    data.setdefault("dormChecks", [])
    data.setdefault("meetingPlans", [])
    data.setdefault("comments", {})
    data.setdefault("journal", [])
    data.setdefault("leaves", [])
    data.setdefault("homeworks", [])
    data.setdefault("coreTodo", [])
    data.setdefault("coreFollow", [])
    data.setdefault("safety", [])
    data.setdefault("dropout", [])
    data.setdefault("growth", [])
    data.setdefault("projects", [])
    data.setdefault("enlist", [])
    data.setdefault("moralLib", [])

    return data


def _validate_and_warn(data):
    """校验学生数据，剔除非法条目并给出性能提示；整体结构非法直接报错。

    目标：遇到文件格式/数据问题时给出清晰提示，而不是静默失败或卡死。
    """
    students = data.get("students")
    if not isinstance(students, list):
        raise GenerationError(
            "学生数据格式错误：students 必须是数组",
            hint='请确认 JSON 中 "students": [...] 是一个学生对象数组，每个对象至少包含 "name" 字段。'
        )

    # 剔除缺少姓名的非法条目（不整体失败，但明确告知跳过了哪些）
    bad = [i for i, s in enumerate(students)
           if not isinstance(s, dict) or not str(s.get("name", "")).strip()]
    if bad:
        shown = bad[:10]
        more = "..." if len(bad) > 10 else ""
        print(f"⚠️ 已跳过 {len(bad)} 条缺少姓名的学生记录（位置：{shown}{more}）", file=sys.stderr)
        drop = set(bad)
        kept = [s for i, s in enumerate(students) if i not in drop]
        data["students"] = kept
        students = kept

    if not students:
        raise GenerationError(
            "学生列表为空",
            hint="名单/JSON 中没有解析到任何有效学生。请检查输入是否包含姓名列，或重新粘贴名单后重试。"
        )

    n = len(students)
    if n > PERF_WARN_STUDENTS:
        print(
            f"⚠️ 班级人数较多（{n} 人）。单文件 HTML 在 {PERF_WARN_STUDENTS} 人以上时，"
            f"学生花名册、成绩录入等页面滚动与渲染可能变慢，但功能与数据均正常可用。",
            file=sys.stderr
        )


def generate_workbench(data, output_path=None):
    """
    将班级数据注入模板，生成完整的 HTML 工作台文件。

    Args:
        data: 班级数据字典
        output_path: 输出文件路径，None 则返回字符串
    Returns:
        生成的 HTML 内容字符串
    """
    # 验证并补全数据
    data = validate_data(data)

    # 读取模板
    html_template, css_content, js_content = load_template_files()

    # 准备替换内容
    # CSS: 去掉开头的注释行，直接插入
    css_block = "\n" + css_content + "\n    "

    # JS: 去掉 IIFE 包裹不需要——直接插入
    js_block = "\n" + js_content + "\n  "

    # 数据: JSON 序列化
    data_block = json.dumps(data, ensure_ascii=False, indent=2)

    # 执行替换
    result = html_template
    result = result.replace("/*{{STYLES}}*/", css_block)
    result = result.replace("/*{{JS}}*/", js_block)
    result = result.replace("/*{{CLASS_DATA}}*/", data_block)

    # 写入文件
    if output_path:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(result, encoding="utf-8")
        print(f"已生成: {output.resolve()}")
        print(f"班级: {data['meta']['className']}  |  人数: {len(data.get('students', []))}  |  主题: {data['meta']['settings']['theme']}")
        return str(output.resolve())
    else:
        return result


def main():
    parser = argparse.ArgumentParser(
        description="班主任工作台 HTML 生成器",
        epilog="""
快捷方式 (名单直转):
  python generate_workbench.py --roster roster.txt --name "三年二班" --grade "小学"
  echo "张三 李四 王五" | python generate_workbench.py --name "我的班级"
        """
    )
    parser.add_argument(
        "--data", "-d",
        help="班级数据 JSON 文件路径"
    )
    parser.add_argument(
        "--roster", "-r",
        help="纯文本/CSV 名单文件路径 (每行: 姓名 或 姓名,学号,性别,电话,宿舍,家长,家长电话)"
    )
    parser.add_argument(
        "--output", "-o",
        help="输出 HTML 文件路径 (默认: 当前目录下 <className>_工作台.html)"
    )
    parser.add_argument(
        "--name",
        help="班级名称"
    )
    parser.add_argument(
        "--grade", "-g",
        help="学段 (幼儿园/小学/初中/高中/高职)"
    )
    parser.add_argument(
        "--teacher", "-t",
        help="班主任姓名"
    )
    parser.add_argument(
        "--motto", "-m",
        help="班级口号 (显示在概览页顶部)"
    )
    parser.add_argument(
        "--field", action="append",
        help="学生自定义字段 (可多次使用: --field 宿舍号 --field 政治面貌)"
    )
    parser.add_argument(
        "--theme",
        choices=["warm", "pink", "blue", "green", "orange", "purple", "dark"],
        help="主题色: warm=暖阳(米白浅黄,教育风) pink=樱粉(浅红,教育风) blue/green/orange/purple/dark (默认: warm)"
    )

    args = parser.parse_args()

    # ---- 数据来源: JSON / roster / stdin ----
    if args.data:
        data_path = Path(args.data)
        if not data_path.exists():
            raise GenerationError(
                f"数据文件不存在: {data_path}",
                hint="请检查 --data 后面的路径是否正确，使用绝对路径更稳妥。"
            )
        try:
            data = json.loads(data_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise GenerationError(
                f"JSON 解析失败（{data_path.name} 第 {e.lineno} 行第 {e.colno} 列）",
                hint=f"检查该行附近的引号、逗号、括号是否成对；可用在线 JSON 校验工具定位。原始错误：{e.msg}"
            )
        # JSON 模式：只补用户没设置过的项，不覆盖已有配置
        grade_for_preset = args.grade or (data.get('meta', {}) or {}).get('grade', '')
        data = apply_grade_preset(data, grade_for_preset, extra_fields=None, force=False)
        # JSON 模式下 --name/--theme 作为覆盖
        if args.name:
            data.setdefault("meta", {})["className"] = args.name
        if args.theme:
            data.setdefault("meta", {}).setdefault("settings", {})["theme"] = args.theme

    elif args.roster:
        roster_path = Path(args.roster)
        if not roster_path.exists():
            raise GenerationError(
                f"名单文件不存在: {roster_path}",
                hint="请检查 --roster 后面的路径是否正确，使用绝对路径更稳妥。"
            )
        roster_text = roster_path.read_text(encoding="utf-8-sig")
        data = build_data_from_roster(
            roster_text,
            class_name=args.name or "我的班级",
            grade=args.grade or "",
            teacher=args.teacher or "",
            theme=args.theme or "blue",
            custom_fields=args.field,
            motto=args.motto or ""
        )
        # 按学段套用聚焦配置（新建班级 → force 覆盖默认）
        data = apply_grade_preset(data, args.grade, extra_fields=args.field, force=True)

    else:
        # 从 stdin 读取: 优先尝试 JSON，失败则按纯文本名单解析
        raw = sys.stdin.read().strip()
        if not raw:
            print("错误: 未提供数据。请使用 --data (JSON) 或 --roster (名单) 参数，或通过 stdin 传入。", file=sys.stderr)
            sys.exit(1)
        try:
            data = json.loads(raw)
            if args.name:
                data.setdefault("meta", {})["className"] = args.name
            if args.theme:
                data.setdefault("meta", {}).setdefault("settings", {})["theme"] = args.theme
            _g = args.grade or (data.get('meta', {}) or {}).get('grade', '')
            data = apply_grade_preset(data, _g, extra_fields=None, force=False)
        except json.JSONDecodeError:
            # 若内容看起来像 JSON（以 { 或 [ 开头）却解析失败，明确报错而非静默当名单处理
            if raw.lstrip().startswith(("{", "[")):
                raise GenerationError(
                    "通过 stdin 传入的内容看起来是 JSON，但解析失败",
                    hint="请确认 JSON 格式正确（引号、逗号、括号成对），或改用 --data 文件方式传入。"
                )
            # 否则按纯文本名单解析
            data = build_data_from_roster(
                raw,
                class_name=args.name or "我的班级",
                grade=args.grade or "",
                teacher=args.teacher or "",
                theme=args.theme or "blue",
                custom_fields=args.field,
                motto=args.motto or ""
            )

    # ---- 数据校验与友好提示（避免卡死/静默失败） ----
    _validate_and_warn(data)

    # 确定输出路径
    output_path = args.output
    if not output_path:
        class_name = data.get("meta", {}).get("className", "班级")
        output_path = f"{class_name}_工作台.html"

    generate_workbench(data, output_path)


if __name__ == "__main__":
    try:
        main()
    except GenerationError as e:
        print(f"\n❌ 生成失败：{e.message}", file=sys.stderr)
        if e.hint:
            print(f"   💡 建议：{e.hint}", file=sys.stderr)
        sys.exit(2)
    except (KeyError, TypeError, ValueError) as e:
        print(f"\n❌ 生成失败：数据格式有误（{e}）", file=sys.stderr)
        print("   💡 建议：检查 JSON 结构是否完整，或改用 --roster 名单直转模式。", file=sys.stderr)
        sys.exit(2)
    except OSError as e:
        print(f"\n❌ 生成失败：文件读写错误（{e}）", file=sys.stderr)
        print("   💡 建议：确认输出目录有写入权限，或换一个输出路径（--output）。", file=sys.stderr)
        sys.exit(2)
    except Exception as e:  # noqa: BLE001
        print(f"\n❌ 生成失败：未知错误（{type(e).__name__}: {e}）", file=sys.stderr)
        print("   💡 建议：请附上输入文件与完整报错联系作者，或改用 --roster 名单直转模式重试。", file=sys.stderr)
        sys.exit(3)
