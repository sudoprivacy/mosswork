/* ================================================================
 * 班主任工作台 - 核心应用逻辑
 * 功能: 数据管理 / 视图渲染 / 导航路由 / 考勤 / 任务 / 沟通 / 个性化
 * 数据源: localStorage 持久化，页面刷新不丢失
 * ================================================================ */

(function () {
  'use strict';

  // ---- 数据存储 ----
  const Store = {
    key: 'hw_class_data',
    registryKey: 'hw_class_registry',

    get() {
      try {
        const raw = localStorage.getItem(this.key);
        if (raw) return JSON.parse(raw);
        // 首次打开: 从模板注入的数据初始化
        if (window.__CLASS_DATA__) {
          this.save(window.__CLASS_DATA__);
          return window.__CLASS_DATA__;
        }
      } catch (e) { console.error('读取数据失败', e); }
      return null;
    },

    save(data) {
      try {
        localStorage.setItem(this.key, JSON.stringify(data));
        return true;
      } catch (e) {
        console.error('保存数据失败', e);
        Toast.show('保存失败，存储空间可能不足');
        return false;
      }
    },

    update(fn) {
      const data = this.get();
      if (!data) return;
      fn(data);
      this.save(data);
    },

    // ---- 多班管理 ----
    classKey(id) { return 'hw_class_data_' + id; },

    getRegistry() {
      try {
        const raw = localStorage.getItem(this.registryKey);
        if (raw) return JSON.parse(raw);
      } catch (e) {}
      return [];
    },

    saveRegistry(list) {
      localStorage.setItem(this.registryKey, JSON.stringify(list));
    },

    currentId() {
      const data = this.get();
      return (data && data.meta && data.meta.classId) || 'main';
    },

    // 注册当前班级（init 时调用，兼容旧数据）
    ensureRegistered() {
      const data = this.get();
      if (!data) return;
      if (!data.meta.classId) { data.meta.classId = 'main'; this.save(data); }
      const reg = this.getRegistry();
      const entry = reg.find(c => c.id === data.meta.classId);
      if (!entry) {
        reg.push({ id: data.meta.classId, name: data.meta.className || '我的班级' });
        this.saveRegistry(reg);
      } else if (entry.name !== data.meta.className) {
        entry.name = data.meta.className;
        this.saveRegistry(reg);
      }
    },

    switchTo(id) {
      const current = this.get();
      const curId = this.currentId();
      if (id === curId) return false;
      // 保存当前班级
      if (current) localStorage.setItem(this.classKey(curId), JSON.stringify(current));
      // 加载目标班级
      const raw = localStorage.getItem(this.classKey(id));
      if (!raw) { Toast.show('目标班级数据不存在'); return false; }
      localStorage.setItem(this.key, raw);
      return true;
    },

    createClass(name) {
      const current = this.get();
      const curId = this.currentId();
      if (current) localStorage.setItem(this.classKey(curId), JSON.stringify(current));

      const id = 'c' + Date.now().toString(36);
      const newData = {
        meta: {
          classId: id,
          className: name,
          grade: '', teacher: '', motto: '',
          createdAt: Utils.today(),
          settings: { theme: 'warm', widgets: ['stats','attendance','trend','tasks','schedule','birthday','announcements','duty'], customFields: [] }
        },
        students: [],
        seating: { rows: 6, cols: 6, map: {} },
        attendance: {}, tasks: [], communicationLog: [],
        announcements: [], activities: [], exams: [],
        duty: { groups: [], startDate: Utils.today(), content: '扫地、擦黑板、倒垃圾、摆桌椅、关门窗' },
        cadres: [], honors: []
      };
      localStorage.setItem(this.key, JSON.stringify(newData));
      const reg = this.getRegistry();
      reg.push({ id, name });
      this.saveRegistry(reg);
      return true;
    },

    deleteClass(id) {
      const reg = this.getRegistry().filter(c => c.id !== id);
      this.saveRegistry(reg);
      localStorage.removeItem(this.classKey(id));
    }
  };

  // ---- Toast 提示 ----
  const Toast = {
    el: null,
    timer: null,
    show(msg) {
      if (!this.el) {
        this.el = document.createElement('div');
        this.el.className = 'toast';
        document.body.appendChild(this.el);
      }
      this.el.textContent = msg;
      this.el.classList.add('show');
      clearTimeout(this.timer);
      this.timer = setTimeout(() => this.el.classList.remove('show'), 2200);
    }
  };

  // ---- Modal 管理 ----
  const Modal = {
    overlay: null,
    titleEl: null,
    bodyEl: null,
    footerEl: null,

    init() {
      this.overlay = document.getElementById('modal-overlay');
      this.titleEl = document.getElementById('modal-title');
      this.bodyEl = document.getElementById('modal-body');
      this.footerEl = document.getElementById('modal-footer');
    },

    open(title, bodyHtml, footerHtml) {
      this.titleEl.textContent = title;
      this.bodyEl.innerHTML = bodyHtml;
      this.footerEl.innerHTML = footerHtml || '';
      this.overlay.classList.add('show');
    },

    close() {
      this.overlay.classList.remove('show');
    }
  };

  // ---- 工具函数 ----
  const Utils = {
    avatarColor(name) {
      const colors = ['#4f6df5','#059669','#ea580c','#7c3aed','#0ea5e9','#ec4899','#eab308','#8b5cf6','#14b8a6','#f97316'];
      let h = 0;
      for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
      return colors[Math.abs(h) % colors.length];
    },

    formatDate(d) {
      if (!d) return '';
      const dt = typeof d === 'string' ? new Date(d) : d;
      const y = dt.getFullYear();
      const m = String(dt.getMonth() + 1).padStart(2, '0');
      const day = String(dt.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    },

    today() { return this.formatDate(new Date()); },

    relativeDate(d) {
      if (!d) return '';
      const target = new Date(d);
      const now = new Date();
      const diff = Math.ceil((target - now) / 86400000);
      if (diff === 0) return '今天';
      if (diff === 1) return '明天';
      if (diff === -1) return '昨天';
      if (diff > 0 && diff <= 7) return `${diff}天后`;
      if (diff < 0) return `${-diff}天前`;
      return this.formatDate(d);
    },

    escapeHtml(str) {
      if (!str) return '';
      return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    },

    uid() { return Date.now().toString(36) + Math.random().toString(36).substr(2, 5); },

    // 生日处理: birthday 格式为 "MM-DD"，返回距今天数(0-364)，null 表示无生日
    daysUntilBirthday(birthday) {
      if (!birthday) return null;
      const parts = String(birthday).split('-');
      if (parts.length < 2) return null;
      const month = parseInt(parts[0], 10) - 1;
      const day = parseInt(parts[1], 10);
      if (isNaN(month) || isNaN(day) || month < 0 || month > 11 || day < 1 || day > 31) return null;
      const now = new Date();
      let next = new Date(now.getFullYear(), month, day);
      if (next < new Date(now.getFullYear(), now.getMonth(), now.getDate())) {
        next = new Date(now.getFullYear() + 1, month, day);
      }
      return Math.round((next - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
    },

    birthdayLabel(birthday) {
      const days = this.daysUntilBirthday(birthday);
      if (days === null) return '';
      if (days === 0) return '今天生日';
      if (days === 1) return '明天生日';
      return `${days}天后生日`;
    },

    shiftDate(dateStr, offsetDays) {
      const d = new Date(dateStr);
      d.setDate(d.getDate() + offsetDays);
      return this.formatDate(d);
    },

    weekdayLabel(dateStr) {
      const d = new Date(dateStr);
      return ['日','一','二','三','四','五','六'][d.getDay()];
    },

    download(filename, content, type) {
      const blob = new Blob([content], { type: type || 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  // ---- 通用 UI 辅助 ----
  function uiBar(pct, color, label) {
    pct = Math.max(0, Math.min(100, parseInt(pct, 10) || 0));
    const c = color || 'var(--primary)';
    const txt = (label !== undefined && label !== null) ? label : (pct + '%');
    return `<div class="progress-wrap"><div class="progress"><div class="progress-fill" style="width:${pct}%;background:${c}"></div></div><span class="progress-num">${Utils.escapeHtml(String(txt))}</span></div>`;
  }
  function uiPill(text, cls) { return `<span class="pill ${cls || 'pill-gray'}">${Utils.escapeHtml(text)}</span>`; }
  function uiRisk(level) {
    const map = { '高': 'pill-red', '中': 'pill-orange', '低': 'pill-gray', '红': 'pill-red', '橙': 'pill-orange', '黄': 'pill-blue' };
    return `<span class="pill ${map[level] || 'pill-gray'}">${Utils.escapeHtml(level)}风险</span>`;
  }

  // ---- 核心管理：可配置子模块 ----
  const CORE_MODULES = [
    { id: 'core-todo',      icon: '\u{1F4CC}', label: '今日核心待办' },
    { id: 'core-followup',  icon: '\u{1F4CB}', label: '重点事项跟进' },
    { id: 'core-safety',    icon: '\u{1F9FA}', label: '安全·特异体质' },
    { id: 'core-dropout',   icon: '\u{1F6AA}', label: '控辍保学跟踪' },
    { id: 'core-growth',    icon: '\u{1F331}', label: '学生成长档案' },
    { id: 'core-comm',      icon: '\u{1F4DE}', label: '家校沟通中心' },
    { id: 'core-moral',     icon: '\u{1F6A9}', label: '思政德育库' },
    { id: 'core-project',   icon: '\u{1F3DB}\u{FE0F}', label: '专项任务跟踪' },
    { id: 'core-enlist',    icon: '\u{1F396}\u{FE0F}', label: '学生征兵记录' }
  ];
  // 子模块 -> 数据数组 key
  const CORE_DATA_KEY = { todo: 'coreTodo', follow: 'coreFollow', safety: 'safety', dropout: 'dropout', growth: 'growth', project: 'projects', enlist: 'enlist' };
  // 子模块 type -> 视图 id
  const CORE_VIEW = { todo: 'core-todo', follow: 'core-followup', safety: 'core-safety', dropout: 'core-dropout', growth: 'core-growth', project: 'core-project', enlist: 'core-enlist' };
  // 思政德育预设库
  const PRESET_MORAL = [
    { title: '防诈骗安全教育', category: '安全教育', goal: '提高学生识别电信诈骗、网络刷单等骗局的能力', steps: '1.播放典型案例 2.讲解"三不一多"原则 3.签订反诈承诺书' },
    { title: '交通安全伴我行', category: '安全教育', goal: '规范上下学交通行为，杜绝违规骑行', steps: '1.交通安全法规讲解 2.校园周边隐患排查 3.签署安全承诺书' },
    { title: '消防安全与应急疏散', category: '安全教育', goal: '掌握火灾逃生与灭火器使用常识', steps: '1.消防知识宣讲 2.应急疏散演练 3.灭火器实操' },
    { title: '防溺水专题教育', category: '安全教育', goal: '强化"六不"原则，远离危险水域', steps: '1.溺水案例警示 2.防溺水"六不"学习 3.家校联防告知' },
    { title: '网络安全与文明上网', category: '安全教育', goal: '引导健康用网，防范网络暴力与沉迷', steps: '1.网络素养讲座 2.文明上网公约 3.家长协同监管' },
    { title: '爱国主义教育', category: '思政教育', goal: '厚植家国情怀，增强民族自豪感', steps: '1.观看主题纪录片 2.国旗下讲话 3.撰写心得体会' },
    { title: '感恩教育与责任担当', category: '德育', goal: '培养感恩之心与对家庭、社会的责任感', steps: '1."写给父母一封信" 2.志愿服务体验 3.分享交流' },
    { title: '诚信考试动员', category: '考试动员', goal: '严肃考风考纪，树立诚信应考意识', steps: '1.考纪宣讲 2.诚信签名 3.经验分享' },
    { title: '心理健康教育', category: '德育', goal: '缓解学业焦虑，学会情绪调节', steps: '1.心理团辅 2.压力管理小技巧 3.一对一关怀' },
    { title: '生涯规划与人生启迪', category: '人生启迪', goal: '帮助学生认识自我，初步规划发展方向', steps: '1.兴趣测评 2.优秀校友分享 3.个人规划书' }
  ];

  // 当前启用的核心子模块（按设置过滤）
  function coreChildren() {
    const data = Store.get();
    const enabled = data && data.meta && data.meta.settings && data.meta.settings.coreModules;
    if (!enabled || !enabled.length) return CORE_MODULES.slice();
    return CORE_MODULES.filter(m => enabled.includes(m.id));
  }
  // 扁平化的可导航叶子（用于键盘、移动端）
  function navLeaves() {
    const out = [];
    visibleNavItems().forEach(it => { if (it.group) out.push(...coreChildren()); else out.push(it); });
    return out;
  }
  // 按 id 查找导航项（含子模块）
  function findNavLeaf(id) {
    for (const it of NAV_ITEMS) {
      if (it.id === id) return it;
      if (it.group) { const c = coreChildren().find(x => x.id === id); if (c) return c; }
    }
    return null;
  }

  // ---- 模块自定义顺序 / 显隐（设置页"模块排序"控制）----
  function getNavOrder() {
    const data = Store.get();
    const s = (data && data.meta && data.meta.settings) || {};
    return Array.isArray(s.navOrder) ? s.navOrder : [];
  }
  function getHiddenModules() {
    const data = Store.get();
    const s = (data && data.meta && data.meta.settings) || {};
    return Array.isArray(s.hiddenModules) ? s.hiddenModules : [];
  }
  // 永不隐藏的模块（否则用户会把自己锁死）
  const NAV_ALWAYS_VISIBLE = ['overview', 'settings'];
  // 可见并按自定义顺序排序的导航项（未排序的保持默认相对顺序）
  function visibleNavItems() {
    const hidden = getHiddenModules();
    const items = NAV_ITEMS.filter(it => !hidden.includes(it.id));
    const order = getNavOrder();
    return items.slice().sort((a, b) => {
      const ia = order.indexOf(a.id);
      const ib = order.indexOf(b.id);
      if (ia === -1 && ib === -1) return 0;
      if (ia === -1) return 1;
      if (ib === -1) return -1;
      return ia - ib;
    });
  }

  // ---- 导航配置 ----
  const NAV_ITEMS = [
    { id: 'overview',      icon: '\u{1F3E0}', label: '工作台' },
    { id: 'students',      icon: '\u{1F465}', label: '学生花名册' },
    { id: 'attendance',    icon: '\u{1F4C5}', label: '课程签到' },
    { id: 'leave',         icon: '\u{1F4E9}', label: '请假审批' },
    { id: 'homework',      icon: '\u{1F4DD}', label: '作业收缴' },
    { id: 'tasks',         icon: '\u{2705}', label: '待办任务' },
    { id: 'scores',        icon: '\u{1F4D8}', label: '成绩录入' },
    { id: 'timetable',     icon: '\u{1F4D6}', label: '课程表' },
    { id: 'seating',       icon: '\u{1F3AB}', label: '座次表' },
    { id: 'duty',          icon: '\u{1F9F9}', label: '值日表' },
    { id: 'cadres',        icon: '\u{1F396}\u{FE0F}', label: '班干部名单' },
    { id: 'honors',        icon: '\u{1F3C5}', label: '荣誉墙' },
    { id: 'points',        icon: '\u{1F4AF}', label: '操行积分' },
    { id: 'dorm',          icon: '\u{1F6CF}\u{FE0F}', label: '宿舍管理' },
    { id: 'communication', icon: '\u{1F4DE}', label: '家校沟通' },
    { id: 'announcements', icon: '\u{1F4E2}', label: '班级公告' },
    { id: 'activities',     icon: '\u{1F3C6}', label: '班级活动' },
    { id: 'core',          icon: '\u{1F9ED}', label: '核心管理', group: true },
    { id: 'exportcenter',  icon: '\u{1F4E4}', label: '导出中心' },
    { id: 'settings',      icon: '\u{2699}\u{FE0F}', label: '设置' }
  ];

  // 手机底部导航显示前5个 + 更多
  const MOBILE_NAV_VISIBLE = 5;

  // ---- 首页快捷操作（可在设置中增删排序）----
  // nav: 跳转到某模块；run: 直接调用 App 方法（一步到位，减少点击层级）
  const QUICK_ACTIONS = [
    { id: 'allPresent', icon: '\u2705', label: '一键全到校', run: 'markAllPresent' },
    { id: 'rollcall',   icon: '\u{1F3B2}', label: '随机点名', nav: 'students' },
    { id: 'leave',      icon: '\u{1F4E9}', label: '请假审批', nav: 'leave' },
    { id: 'homework',   icon: '\u{1F4DD}', label: '作业收缴', nav: 'homework' },
    { id: 'point',      icon: '\u{1F4AF}', label: '记一笔积分', run: 'openPointModal' },
    { id: 'task',       icon: '\u{1F5D2}\u{FE0F}', label: '新建待办', run: 'openTaskModal' },
    { id: 'comm',       icon: '\u{1F4DE}', label: '记沟通', run: 'openCommModal' },
    { id: 'journal',    icon: '\u{1F4D3}', label: '写日志', run: 'openJournalModal' },
    { id: 'student',    icon: '\u{1F464}', label: '新增学生', run: 'openStudentModal' },
    { id: 'report',     icon: '\u{1F4C4}', label: '导出周报', run: 'exportWeeklyReport' },
    { id: 'backup',     icon: '\u{1F4BE}', label: '导出备份', run: 'exportData' },
    { id: 'exportcenter', icon: '\u{1F4E4}', label: '导出中心', nav: 'exportcenter' }
  ];

  // ---- 当前视图状态 ----
  let currentView = 'overview';
  let currentStudentFilter = '';
  let currentStudentStarredOnly = false;
  let currentAttendanceDate = Utils.today();
  let currentActivitiesTab = 'list';   // 活动模块: list=活动列表, meetings=班会计划
  let currentCommTab = 'log';          // 沟通模块: log=沟通记录, contacts=家长通讯录
  let seatSwapFrom = null;             // 座位表: 点击交换的第一个座位

  // ---- 视图渲染器 ----
  const Views = {

    // ========== 概览 ==========

    // 首页快捷操作条（属于视图层，供 overview 调用；开关由 App.toggleQuickAction 控制）
    quickActionsHtml() {
      const data = Store.get();
      const s = (data && data.meta && data.meta.settings) || {};
      const ids = Array.isArray(s.quickActions)
        ? s.quickActions
        : QUICK_ACTIONS.slice(0, 8).map(a => a.id);
      const acts = QUICK_ACTIONS.filter(a => ids.includes(a.id));
      if (!acts.length) return '';
      return `<div class="quick-actions">
        <div class="quick-title">\u26A1 快捷操作<span class="quick-hint">（可在设置里增删）</span></div>
        <div class="quick-grid">
          ${acts.map(a => `<button class="quick-btn" onclick="${a.nav ? `App.navigate('${a.nav}')` : `App.${a.run}()`}" title="${a.label}">
            <span class="qa-icon">${a.icon}</span><span class="qa-label">${a.label}</span>
          </button>`).join('')}
        </div>
      </div>`;
    },

    overview() {
      const data = Store.get();
      if (!data) return '<div class="empty-state"><div class="icon">\u{1F4ED}</div><div class="text">暂无数据</div></div>';

      const today = Utils.today();
      const todayAtt = data.attendance[today] || { present: [], absent: [], late: [] };
      const presentCount = (todayAtt.present || []).length;
      const absentCount = (todayAtt.absent || []).length;
      const lateCount = (todayAtt.late || []).length;
      const total = data.students.length;
      const attRate = total > 0 ? Math.round((presentCount / total) * 100) : 0;

      const pendingTasks = (data.tasks || []).filter(t => t.status !== 'done');
      const highPriorityTasks = pendingTasks.filter(t => t.priority === 'high');
      const todayActivities = (data.activities || []).filter(a => {
        const diff = Math.ceil((new Date(a.date) - new Date()) / 86400000);
        return diff >= 0 && diff <= 7;
      });

      const settings = data.meta.settings || {};
      const widgets = settings.widgets || ['stats','attendance','trend','tasks','schedule','birthday','announcements','duty'];
      const motto = data.meta.motto || '';

      let html = '';

      // 快捷操作（一步直达，可在"设置 → 快捷操作"里增删）
      html += this.quickActionsHtml();

      // 班级口号横幅
      if (motto) {
        html += `<div class="motto-banner">\u{1F31F} ${Utils.escapeHtml(motto)}</div>`;
      }

      // 备份提醒 (超过7天未备份)
      const lastBackup = localStorage.getItem('hw_last_backup');
      const backupDays = lastBackup ? Math.floor((Date.now() - new Date(lastBackup).getTime()) / 86400000) : null;
      if (data.students.length > 0 && (backupDays === null || backupDays > 7)) {
        html += `<div class="backup-warning">
          \u{26A0}\u{FE0F} ${backupDays === null ? '尚未备份过数据' : '已 ' + backupDays + ' 天未备份数据'}，数据仅存于本机浏览器，
          <a href="javascript:void(0)" onclick="App.exportData()" style="color:inherit;text-decoration:underline;">立即导出备份</a>
        </div>`;
      }

      // ===== 主页双板块（常规工作 + 特色工作）=====
      html += this.homeSections(data, { today, todayAtt, presentCount, absentCount, lateCount, total });

      // 近期生日 (未来30天)
      let upcomingBirthdays = [];
      if (widgets.includes('birthday')) {
        upcomingBirthdays = data.students
          .map(s => ({ s, days: Utils.daysUntilBirthday(s.birthday) }))
          .filter(x => x.days !== null && x.days <= 30)
          .sort((a, b) => a.days - b.days);
      }

      // 统计卡片
      if (widgets.includes('stats')) {
        html += `<div class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon blue">\u{1F465}</div>
            <div class="stat-info"><div class="stat-value">${total}</div><div class="stat-label">班级人数</div></div>
          </div>
          <div class="stat-card">
            <div class="stat-icon green">\u{2705}</div>
            <div class="stat-info"><div class="stat-value">${attRate}%</div><div class="stat-label">今日出勤率</div></div>
          </div>
          <div class="stat-card">
            <div class="stat-icon orange">\u{1F4DD}</div>
            <div class="stat-info"><div class="stat-value">${pendingTasks.length}</div><div class="stat-label">待办任务</div></div>
          </div>
          <div class="stat-card">
            <div class="stat-icon red">\u{1F6A9}</div>
            <div class="stat-info"><div class="stat-value">${highPriorityTasks.length}</div><div class="stat-label">高优先任务</div></div>
          </div>
        </div>`;
      }

      // 内容网格
      html += '<div class="content-grid">';

      // 今日考勤
      if (widgets.includes('attendance')) {
        html += `<div class="card">
          <div class="card-header"><span><span class="icon">\u{1F4C5}</span>今日考勤</span>
            <button class="btn-icon" onclick="App.navigate('attendance')">\u{2192}</button>
          </div>
          <div class="flex gap-3 flex-wrap">
            <span class="tag green">\u{2705} 到校 ${presentCount}</span>
            <span class="tag orange">\u{23F1} 迟到 ${lateCount}</span>
            <span class="tag red">\u{1F6D1} 缺勤 ${absentCount}</span>
          </div>
          ${total > 0 ? `<div class="chart-container" style="height:140px;"><canvas id="att-chart"></canvas></div>` : ''}
        </div>`;
      }

      // 出勤趋势 (最近7天折线图)
      if (widgets.includes('trend')) {
        html += `<div class="card" style="grid-column: 1 / -1;">
          <div class="card-header"><span><span class="icon">\u{1F4C8}</span>最近7天出勤趋势</span></div>
          <div class="chart-container" style="height:180px;"><canvas id="trend-chart"></canvas></div>
        </div>`;
      }

      // 本周值日
      if (widgets.includes('duty')) {
        const dutyInfo = App.dutyGroupForWeek(0);
        if (dutyInfo && dutyInfo.group) {
          const studentById = {};
          data.students.forEach(s => { studentById[s.id] = s; });
          const members = (dutyInfo.group.members || []).map(id => (studentById[id] || {}).name).filter(Boolean);
          const dutyContent = (data.duty && data.duty.content) || '';
          html += `<div class="card">
            <div class="card-header"><span><span class="icon">\u{1F9F9}</span>本周值日</span>
              <button class="btn-icon" onclick="App.navigate('duty')">\u{2192}</button>
            </div>
            <div class="duty-group-name">${Utils.escapeHtml(dutyInfo.group.name)}</div>
            <div class="flex gap-2 flex-wrap mt-2">${members.map(m => `<span class="tag green">${Utils.escapeHtml(m)}</span>`).join('') || '<span class="text-sm text-secondary">组内暂无成员</span>'}</div>
            ${dutyContent ? `<div class="text-sm text-secondary mt-2">\u{1F4CB} ${Utils.escapeHtml(dutyContent)}</div>` : ''}
          </div>`;
        }
      }

      // 近期生日
      if (widgets.includes('birthday') && upcomingBirthdays.length > 0) {
        html += `<div class="card">
          <div class="card-header"><span><span class="icon">\u{1F382}</span>近期生日</span></div>
          ${upcomingBirthdays.map(({ s, days }) => `
            <div class="birthday-row ${days === 0 ? 'today' : ''}">
              <span class="birthday-name">${Utils.escapeHtml(s.name)}</span>
              <span class="birthday-date">${Utils.escapeHtml(s.birthday)}</span>
              <span class="tag ${days === 0 ? 'red' : days <= 3 ? 'orange' : 'blue'}">${Utils.birthdayLabel(s.birthday)}</span>
            </div>
          `).join('')}
        </div>`;
      }

      // 待办任务
      if (widgets.includes('tasks')) {
        const topTasks = pendingTasks.slice(0, 5);
        html += `<div class="card">
          <div class="card-header"><span><span class="icon">\u{1F4DD}</span>待办任务</span>
            <button class="btn-icon" onclick="App.navigate('tasks')">\u{2192}</button>
          </div>
          ${topTasks.length > 0 ? topTasks.map(t => `
            <div class="task-item">
              <div class="task-checkbox ${t.status === 'done' ? 'done' : ''}" onclick="App.toggleTask('${t.id}')"></div>
              <div class="task-content ${t.status === 'done' ? 'done' : ''}">
                <div class="task-title">${Utils.escapeHtml(t.title)}</div>
                <div class="task-meta">
                  <span class="tag ${t.priority === 'high' ? 'red' : t.priority === 'medium' ? 'orange' : 'gray'}">${t.priority === 'high' ? '高' : t.priority === 'medium' ? '中' : '低'}</span>
                  ${t.deadline ? `<span>\u{1F4C5} ${Utils.relativeDate(t.deadline)}</span>` : ''}
                </div>
              </div>
            </div>
          `).join('') : '<div class="empty-state"><div class="icon">\u{1F389}</div><div class="text">暂无待办任务</div></div>'}
        </div>`;
      }

      // 近期活动
      if (widgets.includes('schedule') && todayActivities.length > 0) {
        html += `<div class="card">
          <div class="card-header"><span><span class="icon">\u{1F3C6}</span>近期活动</span></div>
          <div class="timeline">
            ${todayActivities.map(a => `
              <div class="timeline-item">
                <div class="time">${Utils.relativeDate(a.date)}</div>
                <div class="content">${Utils.escapeHtml(a.title)}</div>
              </div>
            `).join('')}
          </div>
        </div>`;
      }

      // 最新公告
      if (widgets.includes('announcements') && data.announcements && data.announcements.length > 0) {
        const recent = data.announcements.slice(-3).reverse();
        html += `<div class="card">
          <div class="card-header"><span><span class="icon">\u{1F4E2}</span>最新公告</span>
            <button class="btn-icon" onclick="App.navigate('announcements')">\u{2192}</button>
          </div>
          ${recent.map(a => `
            <div style="padding:8px 0;border-bottom:1px solid var(--border);">
              <div class="text-bold text-sm">${Utils.escapeHtml(a.title)}</div>
              <div class="text-sm text-secondary">${Utils.escapeHtml(a.content).substring(0,60)}${a.content.length > 60 ? '...' : ''}</div>
              <div class="text-sm text-secondary" style="margin-top:2px;">${Utils.formatDate(a.date)}</div>
            </div>
          `).join('')}
        </div>`;
      }

      html += '</div>';

      // 渲染后画图表
      setTimeout(() => {
        if (total > 0 && document.getElementById('att-chart')) {
          App.drawAttendanceChart(presentCount, lateCount, absentCount);
        }
        if (document.getElementById('trend-chart')) {
          App.drawTrendChart();
        }
      }, 50);

      return html;
    },

    // ===== 主页双板块 =====
    homeSections(data, ctx) {
      const { today, todayAtt, presentCount, absentCount, lateCount, total } = ctx;
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });
      const nameOf = (id) => (studentById[id] || {}).name || '?';

      // --- 常规工作数据 ---
      // 早读考勤
      const lateNames = (todayAtt.late || []).map(nameOf);
      const absentNames = (todayAtt.absent || []).map(nameOf);
      const todayLeaves = (data.leaves || []).filter(l =>
        l.status !== 'rejected' && l.startDate <= today && l.endDate >= today);
      const leaveNames = todayLeaves.map(l => nameOf(l.studentId));

      // 课堂纪律 (本周积分)
      const weekStart = Utils.shiftDate(today, -6);
      const weekPoints = (data.points || []).filter(p => p.date >= weekStart);
      const praiseMap = {};   // 正分
      const warnMap = {};     // 负分
      weekPoints.forEach(p => {
        if (p.delta >= 0) praiseMap[p.studentId] = (praiseMap[p.studentId] || 0) + p.delta;
        else warnMap[p.studentId] = (warnMap[p.studentId] || 0) + p.delta;
      });
      const praiseTop = Object.entries(praiseMap).sort((a, b) => b[1] - a[1]).slice(0, 3);
      const warnList = Object.entries(warnMap).filter(([, v]) => v < 0);

      // 作业收缴
      const homeworks = (data.homeworks || []).slice(0, 3);

      // 课间巡查 (工作日志)
      const journals = (data.journal || []).slice(-2).reverse();

      // --- 特色工作数据 ---
      const meetings = (data.meetingPlans || []).slice().sort((a, b) => (a.week || 0) - (b.week || 0));
      const nextMeeting = meetings.find(m => m.status !== 'done');
      const meetingDone = meetings.filter(m => m.status === 'done').length;

      const followUps = (data.communicationLog || []).filter(l => l.followUp);
      const lastComm = (data.communicationLog || []).slice(-1)[0];

      const upcomingBdays = data.students
        .map(s => ({ s, days: Utils.daysUntilBirthday(s.birthday) }))
        .filter(x => x.days !== null && x.days <= 30);
      const pointTotals = {};
      (data.points || []).forEach(p => { pointTotals[p.studentId] = (pointTotals[p.studentId] || 0) + p.delta; });
      const pointTop3 = Object.entries(pointTotals).sort((a, b) => b[1] - a[1]).slice(0, 3);

      const nextAct = (data.activities || []).filter(a => new Date(a.date) >= new Date(new Date().toDateString()))
        .sort((a, b) => new Date(a.date) - new Date(b.date))[0];
      const photoCount = (data.activities || []).reduce((n, a) => n + ((a.photos || []).length), 0);

      // 卡片渲染辅助
      const card = (id, icon, iconCls, title, badge, badgeCls, body) => `
        <div class="home-card" onclick="App.openHomeCard('${id}')">
          <div class="home-card-top">
            <div class="home-card-icon ${iconCls}">${icon}</div>
            <div class="home-card-title">${title}</div>
            ${badge ? `<span class="home-card-badge" style="background:var(--${badgeCls}-light);color:var(--${badgeCls});">${badge}</span>` : ''}
          </div>
          <div class="home-card-body">${body || '<span style="color:var(--text-tertiary)">点击查看详情</span>'}</div>
        </div>`;

      let html = '';

      // ===== 常规工作 =====
      html += `<div class="home-section"><span class="home-section-title">\u{1F4C2} 常规工作</span><span class="home-section-line"></span></div>`;
      html += '<div class="home-card-grid">';

      html += card('attendance', '\u{1F4C5}', 'cyan', '早读考勤',
        total > 0 ? presentCount + '/' + total : '', 'info',
        `\u51FA\u52E4<b>${presentCount}</b>\u8FDF\u5230<b>${lateCount}</b>\u7F3A\u52E4<b>${absentCount}</b>\u8BF7\u5047<b>${todayLeaves.length}</b>` +
        (lateNames.length ? `<br>\u8FDF\u5230: <b>${lateNames.join('、')}</b>` : '') +
        (absentNames.length ? `<br>\u7F3A\u52E4: <b>${absentNames.join('、')}</b>` : '') +
        (leaveNames.length ? `<br>\u8BF7\u5047: <b>${leaveNames.join('、')}</b>` : ''));

      html += card('discipline', '\u{1F3AD}', 'orange', '课堂纪律',
        weekPoints.length + '笔', 'warning',
        praiseTop.length ? `\u8868\u626C: <b>${praiseTop.map(([sid, v]) => nameOf(sid) + '+' + v).join(' ')}</b>` : '' +
        (praiseTop.length && warnList.length ? '<br>' : '') +
        (warnList.length ? `\u9700\u5173\u6CE8: <b>${warnList.map(([sid, v]) => nameOf(sid) + v).join(' ')}</b>` : '') +
        (!praiseTop.length && !warnList.length ? '\u672C\u5468\u6682\u65E0\u7EAA\u5F8B\u8BB0\u5F55\uFF0C\u70B9\u51FB\u8BB0\u5F55\u64CD\u884C\u79EF\u5206' : ''));

      html += card('homework', '\u{1F4DD}', 'blue', '作业收缴',
        homeworks.length > 0 ? Math.round((homeworks[0].submitted || []).length / Math.max(total, 1) * 100) + '%' : '', 'success',
        homeworks.length > 0 ? homeworks.map(hw => {
          const sub = (hw.submitted || []).length;
          const un = total - sub;
          return `${Utils.escapeHtml(hw.subject || '通用')}: <b>${sub}/${total}</b>${un > 0 ? ' <span style="color:var(--danger)">(欠' + un + ')</span>' : ' \u{2705}'}`;
        }).join('<br>') : '\u6682\u65E0\u6536\u4F5C\u4E1A\u4EFB\u52A1\uFF0C\u70B9\u51FB\u521B\u5EFA');

      html += card('patrol', '\u{1F6E1}\u{FE0F}', 'green', '课间巡查',
        journals.length + '条', 'info',
        journals.map(j => `\u3010${Utils.escapeHtml(j.tag || '')}\u3011${Utils.escapeHtml(j.content).substring(0, 24)}${j.content.length > 24 ? '...' : ''}`).join('<br>') ||
        '\u6682\u65E0\u5DE1\u67E5\u8BB0\u5F55\uFF0C\u70B9\u51FB\u5FEB\u901F\u8BB0\u4E00\u7B14');

      html += '</div>';

      // ===== 特色工作 =====
      html += `<div class="home-section"><span class="home-section-title">\u{2B50} 特色工作</span><span class="home-section-line"></span></div>`;
      html += '<div class="home-card-grid">';

      html += card('meetings', '\u{1F4CB}', 'purple', '主题班会',
        meetingDone + '/' + meetings.length, 'info',
        nextMeeting ? `\u4E0B\u4E00\u6B21: \u7B2C<b>${nextMeeting.week}</b>\u5468 \u3010${Utils.escapeHtml(nextMeeting.topic)}\u3011` : '\u672C\u5B66\u671F\u8BA1\u5212\u5DF2\u5168\u90E8\u5B8C\u6210 \u{1F389}' +
        (meetings.length === 0 ? '\u6682\u65E0\u73ED\u4F1A\u8BA1\u5212\uFF0C\u70B9\u51FB\u7B16\u5212' : ''));

      html += card('comm', '\u{1F4DE}', 'blue', '家校沟通',
        followUps.length > 0 ? followUps.length + '待跟进' : '已清零', followUps.length > 0 ? 'danger' : 'success',
        (followUps.length > 0 ? `\u5F85\u8DDF\u8FDB: <b>${followUps.slice(0, 3).map(l => Utils.escapeHtml(l.studentName)).join('、')}</b><br>` : '') +
        (lastComm ? `\u6700\u8FD1: ${Utils.formatDate(lastComm.date)} ${Utils.escapeHtml(lastComm.studentName)}(${Utils.escapeHtml(lastComm.type)})` : '\u6682\u65E0\u6C9F\u901A\u8BB0\u5F55'));

      html += card('growth', '\u{1F338}', 'pink', '学生成长',
        upcomingBdays.length > 0 ? upcomingBdays[0].s.name + ' 生日' : '', 'warning',
        (upcomingBdays.length > 0 ? `\u8FD130\u5929\u751F\u65E5: <b>${upcomingBdays.slice(0, 3).map(x => x.s.name).join('、')}</b><br>` : '') +
        (pointTop3.length > 0 ? `\u79EF\u5206\u699C: <b>${pointTop3.map(([sid, v]) => nameOf(sid) + '(' + (v > 0 ? '+' : '') + v + ')').join(' ')}</b>` : '\u70B9\u51FB\u67E5\u770B\u6210\u957F\u6863\u6848'));

      html += card('acts', '\u{1F3C6}', 'orange', '班级活动',
        nextAct ? Utils.relativeDate(nextAct.date) : '', 'success',
        (nextAct ? `\u4E0B\u4E00\u573A: <b>${Utils.escapeHtml(nextAct.title)}</b> (${Utils.formatDate(nextAct.date)})` : '\u6682\u65E0\u6392\u671F\u6D3B\u52A8') +
        (photoCount > 0 ? `<br>\u5DF2\u5B58\u7167\u7247 <b>${photoCount}</b> \u5F20` : ''));

      html += '</div>';

      return html;
    },

    // ========== 学生管理 ==========
    students() {
      const data = Store.get();
      if (!data) return '';

      const filter = currentStudentFilter.toLowerCase();
      let filtered = data.students;
      if (filter) {
        filtered = filtered.filter(s =>
            (s.name || '').toLowerCase().includes(filter) ||
            (s.studentId || '').toLowerCase().includes(filter));
      }
      if (currentStudentStarredOnly) {
        filtered = filtered.filter(s => s.starred);
      }
      // 星标学生排前面
      filtered = filtered.slice().sort((a, b) => (b.starred ? 1 : 0) - (a.starred ? 1 : 0));

      const starredCount = data.students.filter(s => s.starred).length;

      let html = `
        <div class="flex gap-2 items-center mb-3 flex-wrap">
          <div class="search-box" style="flex:1;min-width:150px;">
            <span>\u{1F50D}</span>
            <input type="text" placeholder="搜索姓名/学号..." value="${Utils.escapeHtml(currentStudentFilter)}"
              oninput="App.studentFilter(this.value)">
          </div>
          <button class="btn ${currentStudentStarredOnly ? 'btn-primary' : 'btn-outline'}" onclick="App.toggleStarredFilter()">
            \u{2B50} 重点关注 ${starredCount > 0 ? '(' + starredCount + ')' : ''}
          </button>
          <button class="btn btn-outline" onclick="App.randomPick()">\u{1F3B2} 随机点名</button>
          <button class="btn btn-outline" onclick="App.openImportStudents()">\u{1F4E5} 导入名单</button>
          <button class="btn btn-outline" onclick="App.openCommentsModal()">\u{1F4DD} 期末评语</button>
          <button class="btn btn-primary" onclick="App.openStudentModal()">+ 添加</button>
          <button class="btn btn-outline" onclick="App.exportStudents()">导出</button>
        </div>
      `;

      if (filtered.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F465}</div><div class="text">未找到学生</div></div>';
        return html;
      }

      html += '<div class="student-grid">';
      filtered.forEach(s => {
        const color = Utils.avatarColor(s.name || '?');
        const initial = (s.name || '?').charAt(0);
        const infoRows = [];
        if (s.gender) infoRows.push(`<div class="student-info-row"><span>性别</span><span>${Utils.escapeHtml(s.gender)}</span></div>`);
        if (s.birthday) infoRows.push(`<div class="student-info-row"><span>生日</span><span>${Utils.escapeHtml(s.birthday)}</span></div>`);
        if (s.phone) infoRows.push(`<div class="student-info-row"><span>电话</span><span>${Utils.escapeHtml(s.phone)}</span></div>`);
        if (s.parentName) infoRows.push(`<div class="student-info-row"><span>家长</span><span>${Utils.escapeHtml(s.parentName)}</span></div>`);
        if (s.parentPhone) infoRows.push(`<div class="student-info-row"><span>家长电话</span><span>${Utils.escapeHtml(s.parentPhone)}</span></div>`);
        if (s.dorm) infoRows.push(`<div class="student-info-row"><span>宿舍</span><span>${Utils.escapeHtml(s.dorm)}</span></div>`);
        if (s.notes) infoRows.push(`<div class="student-info-row"><span>备注</span><span>${Utils.escapeHtml(s.notes)}</span></div>`);

        // 自定义字段
        if (s.customFields) {
          Object.entries(s.customFields).forEach(([k, v]) => {
            infoRows.push(`<div class="student-info-row"><span>${Utils.escapeHtml(k)}</span><span>${Utils.escapeHtml(String(v))}</span></div>`);
          });
        }

        html += `<div class="student-card ${s.starred ? 'starred' : ''}" onclick="App.openStudentDetail('${s.id}')">
          <button class="star-btn ${s.starred ? 'on' : ''}" title="重点关注" onclick="event.stopPropagation();App.toggleStar('${s.id}')">${s.starred ? '\u{2B50}' : '\u{2606}'}</button>
          <div class="student-card-top">
            <div class="student-avatar" style="background:${color}">${Utils.escapeHtml(initial)}</div>
            <div>
              <div class="student-name">${Utils.escapeHtml(s.name)}</div>
              <div class="student-id">${Utils.escapeHtml(s.studentId || '')}</div>
            </div>
          </div>
          ${infoRows.join('')}
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 考勤 ==========
    attendance() {
      const data = Store.get();
      if (!data) return '';

      const dateStr = currentAttendanceDate;
      const dayAtt = data.attendance[dateStr] || { present: [], absent: [], late: [] };
      const presentSet = new Set(dayAtt.present || []);
      const absentSet = new Set(dayAtt.absent || []);
      const lateSet = new Set(dayAtt.late || []);

      let html = `
        <div class="flex gap-2 items-center mb-3 flex-wrap">
          <div class="flex gap-2 items-center">
            <button class="btn btn-outline btn-sm" onclick="App.shiftAttendanceDate(-1)" title="前一天">\u{2190}</button>
            <input type="date" class="input" style="width:auto;" value="${dateStr}" onchange="App.setAttendanceDate(this.value)">
            <button class="btn btn-outline btn-sm" onclick="App.shiftAttendanceDate(1)" title="后一天">\u{2192}</button>
            ${dateStr === Utils.today() ? '<span class="tag blue">今天 \u00B7 周' + Utils.weekdayLabel(dateStr) + '</span>' : '<span class="tag gray">周' + Utils.weekdayLabel(dateStr) + '</span>'}
          </div>
          <button class="btn btn-primary" onclick="App.markAllPresent()">全部到校</button>
          <button class="btn btn-outline" onclick="App.clearAttendance()">清空</button>
        </div>
      `;

      const presentCount = presentSet.size;
      const absentCount = absentSet.size;
      const lateCount = lateSet.size;
      const total = data.students.length;
      const unmarked = total - presentCount - absentCount - lateCount;

      html += `<div class="stats-grid" style="margin-bottom:16px;">
        <div class="stat-card"><div class="stat-icon green">\u{2705}</div><div class="stat-info"><div class="stat-value">${presentCount}</div><div class="stat-label">到校</div></div></div>
        <div class="stat-card"><div class="stat-icon orange">\u{23F1}</div><div class="stat-info"><div class="stat-value">${lateCount}</div><div class="stat-label">迟到</div></div></div>
        <div class="stat-card"><div class="stat-icon red">\u{1F6D1}</div><div class="stat-info"><div class="stat-value">${absentCount}</div><div class="stat-label">缺勤</div></div></div>
        <div class="stat-card"><div class="stat-icon cyan">\u{2753}</div><div class="stat-info"><div class="stat-value">${unmarked}</div><div class="stat-label">未标记</div></div></div>
      </div>`;

      html += '<div class="attendance-grid">';
      data.students.forEach(s => {
        let status = 'unmarked';
        let statusText = '未标记';
        if (presentSet.has(s.id)) { status = 'present'; statusText = '到校'; }
        else if (lateSet.has(s.id)) { status = 'late'; statusText = '迟到'; }
        else if (absentSet.has(s.id)) { status = 'absent'; statusText = '缺勤'; }

        html += `<div class="attendance-item ${status}" onclick="App.cycleAttendance('${s.id}')">
          <div class="name">${Utils.escapeHtml(s.name)}</div>
          <div class="status">${statusText}</div>
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 请假审批 ==========
    leave() {
      const data = Store.get();
      if (!data) return '';

      const leaves = data.leaves || [];
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      const pending = leaves.filter(l => l.status === 'pending');
      const approved = leaves.filter(l => l.status === 'approved');
      const rejected = leaves.filter(l => l.status === 'rejected');
      const sick = leaves.filter(l => l.type === '病假' && l.status !== 'rejected').length;
      const personal = leaves.filter(l => l.type === '事假' && l.status !== 'rejected').length;

      // 待审批天数计算
      const days = (l) => {
        const d = Math.round((new Date(l.endDate) - new Date(l.startDate)) / 86400000) + 1;
        return isNaN(d) || d < 1 ? 1 : d;
      };

      let html = `
        <div class="flex gap-2 items-center mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openLeaveModal()">+ 登记请假</button>
          ${pending.length > 0 ? `
            <button class="btn btn-outline" onclick="App.toggleLeaveSelectAll()">\u{2611} 全选待批 (${pending.length})</button>
            <button class="btn btn-outline" style="color:var(--success);border-color:var(--success);" onclick="App.batchApproveLeaves()">\u{2705} 批量通过</button>
            <button class="btn btn-outline" style="color:var(--danger);border-color:var(--danger);" onclick="App.batchRejectLeaves()">\u{274C} 批量驳回</button>
          ` : ''}
        </div>
        <div class="stats-grid" style="margin-bottom:16px;">
          <div class="stat-card"><div class="stat-icon orange">\u{23F3}</div><div class="stat-info"><div class="stat-value">${pending.length}</div><div class="stat-label">待审批</div></div></div>
          <div class="stat-card"><div class="stat-icon green">\u{2705}</div><div class="stat-info"><div class="stat-value">${approved.length}</div><div class="stat-label">已批准</div></div></div>
          <div class="stat-card"><div class="stat-icon red">\u{274C}</div><div class="stat-info"><div class="stat-value">${rejected.length}</div><div class="stat-label">已驳回</div></div></div>
          <div class="stat-card"><div class="stat-icon cyan">\u{1F48A}</div><div class="stat-info"><div class="stat-value">${sick + personal}</div><div class="stat-label">累计(病${sick}/事${personal})</div></div></div>
        </div>
      `;

      if (leaves.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4E9}</div><div class="text">暂无请假记录<br><span class="text-sm">学生请假时在此登记，支持批量审批</span></div></div>';
        return html;
      }

      // 待审批（含勾选框）
      if (pending.length > 0) {
        html += `<div class="card"><div class="card-header"><span><span class="icon">\u{23F3}</span>待审批 (${pending.length})</span></div>`;
        pending.forEach(l => {
          const s = studentById[l.studentId] || {};
          html += `<div class="leave-card">
            <label class="flex gap-2 items-center" style="cursor:pointer;">
              <input type="checkbox" class="leave-check" value="${l.id}" style="width:18px;height:18px;accent-color:var(--primary);">
              <div class="flex-1">
                <div class="flex gap-2 items-center flex-wrap">
                  <span class="text-bold">${Utils.escapeHtml(s.name || '?')}</span>
                  <span class="tag ${l.type === '病假' ? 'red' : l.type === '事假' ? 'orange' : 'gray'}">${Utils.escapeHtml(l.type)}</span>
                  <span class="text-sm text-secondary">${l.startDate} ~ ${l.endDate} (${days(l)}天)</span>
                </div>
                <div class="text-sm text-secondary mt-1">\u{1F4AC} ${Utils.escapeHtml(l.reason || '未填事由')}</div>
              </div>
            </label>
            <div class="flex gap-1 mt-2">
              <button class="btn btn-outline btn-sm" style="color:var(--success);border-color:var(--success);" onclick="App.approveLeave('${l.id}')">\u{2705} 通过</button>
              <button class="btn btn-outline btn-sm" style="color:var(--danger);border-color:var(--danger);" onclick="App.rejectLeave('${l.id}')">\u{274C} 驳回</button>
              <button class="btn-icon" onclick="App.deleteLeave('${l.id}')">\u{1F5D1}</button>
            </div>
          </div>`;
        });
        html += '</div>';
      }

      // 历史记录
      const history = [...approved, ...rejected].sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
      if (history.length > 0) {
        html += `<div class="card" style="margin-top:12px;"><div class="card-header"><span><span class="icon">\u{1F4DC}</span>审批历史 (${history.length})</span></div>`;
        history.slice(0, 20).forEach(l => {
          const s = studentById[l.studentId] || {};
          html += `<div class="setting-row">
            <span>
              <span class="text-bold">${Utils.escapeHtml(s.name || '?')}</span>
              <span class="tag ${l.type === '病假' ? 'red' : 'orange'}">${Utils.escapeHtml(l.type)}</span>
              <span class="text-sm text-secondary">${l.startDate}~${l.endDate}(${days(l)}天)</span>
              ${l.reason ? `<br><span class="text-sm text-secondary">${Utils.escapeHtml(l.reason)}</span>` : ''}
            </span>
            <span class="flex gap-2 items-center">
              <span class="tag ${l.status === 'approved' ? 'green' : 'red'}">${l.status === 'approved' ? '已批' : '已驳回'}</span>
              <button class="btn-icon" onclick="App.deleteLeave('${l.id}')">\u{1F5D1}</button>
            </span>
          </div>`;
        });
        html += '</div>';
      }

      return html;
    },

    // ========== 作业收交 ==========
    homework() {
      const data = Store.get();
      if (!data) return '';

      const homeworks = data.homeworks || [];
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openHomeworkModal()">+ 新建收作业</button>
        </div>
      `;

      if (homeworks.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4DD}</div><div class="text">暂无收作业任务<br><span class="text-sm">创建后逐人标记已交/未交，未交名单一键催交</span></div></div>';
        return html;
      }

      // 按创建时间倒序
      const sorted = homeworks.slice().reverse();

      sorted.forEach(hw => {
        const submitted = hw.submitted || [];
        const unsubmitted = data.students.filter(s => !submitted.includes(s.id));
        const rate = data.students.length > 0 ? Math.round(submitted.length / data.students.length * 100) : 0;

        html += `<div class="card" style="margin-bottom:12px;">
          <div class="card-header">
            <span>
              <span class="tag blue">${Utils.escapeHtml(hw.subject || '通用')}</span>
              <span class="text-bold">${Utils.escapeHtml(hw.title)}</span>
              ${hw.deadline ? `<span class="text-sm text-secondary">(截止 ${Utils.relativeDate(hw.deadline)})</span>` : ''}
            </span>
            <span class="flex gap-2 items-center">
              <span class="tag ${rate === 100 ? 'green' : rate >= 60 ? 'orange' : 'red'}">已交 ${submitted.length}/${data.students.length} (${rate}%)</span>
              <button class="btn-icon" onclick="App.deleteHomework('${hw.id}')">\u{1F5D1}</button>
            </span>
          </div>
          <div class="hw-progress"><div class="hw-progress-bar" style="width:${rate}%;"></div></div>
          <div class="flex gap-2 mt-2 flex-wrap">
            <button class="btn btn-outline btn-sm" onclick="App.markAllSubmitted('${hw.id}')">\u{2705} 全部已交</button>
            ${unsubmitted.length > 0 ? `<button class="btn btn-outline btn-sm" style="color:var(--danger);border-color:var(--danger);" onclick="App.copyRemindText('${hw.id}')">\u{1F4E3} 一键催交(${unsubmitted.length}人未交)</button>` : '<span class="tag green">\u{1F389} 全部交齐</span>'}
          </div>
          <div class="hw-student-list mt-2">
            ${data.students.map(s => {
              const done = submitted.includes(s.id);
              return `<span class="hw-chip ${done ? 'done' : 'undone'}" onclick="App.toggleHomeworkSubmit('${hw.id}', '${s.id}')">
                ${done ? '\u{2705} ' : '\u{2B1C} '}${Utils.escapeHtml(s.name)}
              </span>`;
            }).join('')}
          </div>
        </div>`;
      });

      return html;
    },

    // ========== 任务 ==========
    tasks() {
      const data = Store.get();
      if (!data) return '';

      const tasks = data.tasks || [];
      const pending = tasks.filter(t => t.status !== 'done');
      const done = tasks.filter(t => t.status === 'done');

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openTaskModal()">+ 新建任务</button>
          <button class="btn btn-outline" onclick="App.openJournalModal()">\u{1F4DD} 工作日志</button>
        </div>
      `;

      html += '<div class="card mb-3">';
      html += '<div class="card-header"><span><span class="icon">\u{1F4DD}</span>待办 (' + pending.length + ')</span></div>';
      if (pending.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F389}</div><div class="text">所有任务已完成</div></div>';
      } else {
        pending.sort((a, b) => {
          const p = { high: 0, medium: 1, low: 2 };
          return (p[a.priority] || 2) - (p[b.priority] || 2);
        });
        pending.forEach(t => {
          html += renderTaskItem(t);
        });
      }
      html += '</div>';

      if (done.length > 0) {
        html += '<div class="card">';
        html += '<div class="card-header"><span><span class="icon">\u{2705}</span>已完成 (' + done.length + ')</span></div>';
        done.forEach(t => { html += renderTaskItem(t); });
        html += '</div>';
      }

      return html;

      function renderTaskItem(t) {
        const pTag = t.priority === 'high'
          ? '<span class="tag red">高</span>'
          : t.priority === 'medium'
          ? '<span class="tag orange">中</span>'
          : '<span class="tag gray">低</span>';
        const cTag = t.category ? `<span class="tag blue">${Utils.escapeHtml(t.category)}</span>` : '';
        const noteLine = t.note ? `<div class="task-note">${Utils.escapeHtml(t.note)}</div>` : '';
        return `<div class="task-item">
          <div class="task-checkbox ${t.status === 'done' ? 'done' : ''}" onclick="App.toggleTask('${t.id}')"></div>
          <div class="task-content ${t.status === 'done' ? 'done' : ''}">
            <div class="task-title">${Utils.escapeHtml(t.title)}</div>
            ${noteLine}
            <div class="task-meta">${pTag} ${cTag} ${t.deadline ? '<span>\u{1F4C5} ' + Utils.relativeDate(t.deadline) + '</span>' : ''}</div>
          </div>
          <button class="btn-icon" onclick="App.openTaskModal('${t.id}')">\u{270F}\u{FE0F}</button>
          <button class="btn-icon" onclick="App.deleteTask('${t.id}')">\u{1F5D1}</button>
        </div>`;
      }
    },

    // ========== 成绩管理 ==========
    scores() {
      const data = Store.get();
      if (!data) return '';

      const exams = data.exams || [];

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openExamModal()">+ 新建考试</button>
          <button class="btn btn-outline" onclick="App.openClassCompare()">\u{1F4CA} 班级对比</button>
        </div>
      `;

      if (exams.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4D8}</div><div class="text">暂无考试记录<br><span class="text-sm">点击"新建考试"登记第一次考试</span></div></div>';
        return html;
      }

      // 按日期倒序
      const sorted = exams.slice().sort((a, b) => new Date(b.date) - new Date(a.date));

      html += '<div class="content-grid">';
      sorted.forEach(e => {
        const stats = App.examStats(e);
        const pTag = stats.count > 0 ? 'green' : 'gray';
        html += `<div class="card">
          <div class="card-header">
            <span><span class="icon">\u{1F4D8}</span>${Utils.escapeHtml(e.name)}</span>
            <span class="text-sm text-secondary">${Utils.formatDate(e.date)}</span>
          </div>
          ${stats.count > 0 ? `
            <div class="flex gap-3 flex-wrap mb-2">
              <span class="tag blue">平均 ${stats.avg}分</span>
              <span class="tag ${stats.passRate >= 80 ? 'green' : stats.passRate >= 60 ? 'orange' : 'red'}">及格率 ${stats.passRate}%</span>
              <span class="tag green">最高 ${stats.max}分</span>
              <span class="tag red">最低 ${stats.min}分</span>
              <span class="tag gray">${stats.count}人参考</span>
            </div>
          ` : '<div class="text-sm text-secondary mb-2">尚未录入分数</div>'}
          <div class="flex gap-2">
            <button class="btn btn-primary btn-sm" onclick="App.openScoreEntry('${e.id}')">\u{270F}\u{FE0F} 录入分数</button>
            ${stats.count > 0 ? `<button class="btn btn-outline btn-sm" onclick="App.openExamStats('${e.id}')">\u{1F4CA} 统计分析</button>` : ''}
            <button class="btn btn-outline btn-sm" style="color:var(--danger);" onclick="App.deleteExam('${e.id}')">\u{1F5D1}</button>
          </div>
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 座位表 ==========
    seating() {
      const data = Store.get();
      if (!data) return '';

      const seating = data.seating || { rows: 6, cols: 6, map: {} };
      const rows = seating.rows || 6;
      const cols = seating.cols || 6;
      const map = seating.map || {};
      const versions = seating.versions || [];

      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      const seatedCount = Object.values(map).filter(v => v && studentById[v]).length;
      const unseated = data.students.filter(s => !Object.values(map).includes(s.id));

      let html = `
        <div class="flex gap-2 items-center mb-3 flex-wrap">
          <div class="flex gap-2 items-center">
            <label class="text-sm text-secondary">行</label>
            <input type="number" class="input" style="width:64px;" min="1" max="12" value="${rows}" onchange="App.setSeatSize('rows', this.value)">
            <label class="text-sm text-secondary">列</label>
            <input type="number" class="input" style="width:64px;" min="1" max="12" value="${cols}" onchange="App.setSeatSize('cols', this.value)">
          </div>
          <button class="btn btn-primary" onclick="App.openSmartSeatModal()">\u{1F9E9} 智能排座</button>
          <button class="btn btn-outline" onclick="App.saveSeatVersion()">\u{1F4BE} 保存为版本</button>
          <button class="btn btn-outline" onclick="App.clearSeats()" style="color:var(--danger);">清空座位</button>
          <span class="tag blue">已排 ${seatedCount}/${data.students.length}</span>
        </div>
        ${versions.length > 0 ? `<div class="card mb-3" style="padding:10px 14px;">
          <div class="text-sm text-secondary mb-2">\u{1F4BE} 已保存的座位版本:</div>
          <div class="flex gap-2 flex-wrap">
            ${versions.map(v => `
              <span class="tag blue" style="cursor:pointer;" onclick="App.loadSeatVersion('${v.id}')">\u{1F4C2} ${Utils.escapeHtml(v.name)} \u2192 加载</span>
              <button class="btn-icon" onclick="App.deleteSeatVersion('${v.id}')">\u{1F5D1}</button>
            `).join('')}
          </div>
        </div>` : ''}
        ${unseated.length > 0 ? `<div class="card mb-3" style="padding:10px 14px;">
          <div class="text-sm text-secondary mb-2">未排座学生（点击座位后选择学生，或使用智能排座）:</div>
          <div class="flex gap-2 flex-wrap">${unseated.map(s => `<span class="tag gray">${Utils.escapeHtml(s.name)}</span>`).join('')}</div>
        </div>` : ''}
        <div class="card seat-card">
          <div class="seat-podium">\u{1F3EB} 讲台</div>
          <div class="seat-grid" style="grid-template-columns:repeat(${cols}, 1fr);">
            ${Array.from({ length: rows * cols }, (_, i) => {
              const r = Math.floor(i / cols), c = i % cols;
              const key = `${r}-${c}`;
              const sid = map[key];
              const student = sid ? studentById[sid] : null;
              const aisleAfter = (c === Math.floor(cols / 2) - 1) ? 'aisle-after' : '';
              const swapCls = seatSwapFrom === key ? 'seat-swap-from' : '';
              if (student) {
                return `<div class="seat-cell occupied ${student.starred ? 'seat-starred' : ''} ${aisleAfter} ${swapCls}" onclick="App.seatCellClick('${key}')">
                  <span class="seat-name">${Utils.escapeHtml(student.name)}</span>
                  ${student.starred ? '<span class="seat-star">\u{2B50}</span>' : ''}
                </div>`;
              }
              return `<div class="seat-cell empty ${aisleAfter} ${swapCls}" onclick="App.seatCellClick('${key}')">+</div>`;
            }).join('')}
          </div>
        </div>
        <div class="text-sm text-secondary mt-2" style="padding:0 4px;">\u{1F4A1} 点击座位安排/移除学生；\u{1F517} 先点一个已坐座位再点另一个可<b>交换</b>两人。带 \u{2B50} 的是重点关注学生。中间为过道。</div>
      `;

      return html;
    },

    // ========== 值日轮换表 ==========
    duty() {
      const data = Store.get();
      if (!data) return '';

      const duty = data.duty || {};
      const groups = duty.groups || [];
      const content = duty.content || '扫地、擦黑板、倒垃圾、摆桌椅、关门窗';

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openDutyAutoModal()">\u{267E}\u{FE0F} 自动分组</button>
          <button class="btn btn-outline" onclick="App.openDutyGroupModal()">+ 手动建组</button>
          <button class="btn btn-outline" onclick="App.editDutyContent()">\u{270F}\u{FE0F} 值日内容</button>
        </div>
      `;

      if (groups.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F9F9}</div><div class="text">尚未创建值日组<br><span class="text-sm">点击"自动分组"按名单顺序均分值日组</span></div></div>';
        return html;
      }

      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      // 本周 / 下周值日
      const thisWeek = App.dutyGroupForWeek(0);
      const nextWeek = App.dutyGroupForWeek(1);

      html += '<div class="content-grid">';

      if (thisWeek && thisWeek.group) {
        const members = (thisWeek.group.members || []).map(id => (studentById[id] || {}).name).filter(Boolean);
        html += `<div class="card duty-current">
          <div class="card-header"><span><span class="icon">\u{1F4CC}</span>本周值日</span>
            <button class="btn btn-outline btn-sm" onclick="App.openDutyOverrideModal(0)">调整</button>
          </div>
          <div class="duty-group-name">${Utils.escapeHtml(thisWeek.group.name)}</div>
          <div class="flex gap-2 flex-wrap mt-2">${members.map(m => `<span class="tag blue">${Utils.escapeHtml(m)}</span>`).join('') || '<span class="text-sm text-secondary">组内暂无成员</span>'}</div>
        </div>`;
      }

      if (nextWeek && nextWeek.group) {
        const members = (nextWeek.group.members || []).map(id => (studentById[id] || {}).name).filter(Boolean);
        html += `<div class="card">
          <div class="card-header"><span><span class="icon">\u{1F552}</span>下周值日</span>
            <button class="btn btn-outline btn-sm" onclick="App.openDutyOverrideModal(1)">调整</button>
          </div>
          <div class="duty-group-name" style="color:var(--text-secondary);">${Utils.escapeHtml(nextWeek.group.name)}</div>
          <div class="flex gap-2 flex-wrap mt-2">${members.map(m => `<span class="tag gray">${Utils.escapeHtml(m)}</span>`).join('') || '<span class="text-sm text-secondary">组内暂无成员</span>'}</div>
        </div>`;
      }

      // 值日内容
      html += `<div class="card">
        <div class="card-header"><span><span class="icon">\u{1F4CB}</span>值日内容</span></div>
        <div class="text-sm">${Utils.escapeHtml(content)}</div>
      </div>`;

      html += '</div>';

      // 全部值日组
      html += `<div class="card"><div class="card-header"><span><span class="icon">\u{1F5C2}\u{FE0F}</span>全部值日组 (${groups.length}组轮换)</span></div>`;
      groups.forEach((g, i) => {
        const members = (g.members || []).map(id => (studentById[id] || {}).name).filter(Boolean);
        const isCurrent = thisWeek && thisWeek.group && thisWeek.group.id === g.id;
        html += `<div class="setting-row">
          <span>${isCurrent ? '\u{1F4CC} ' : ''}${Utils.escapeHtml(g.name)} <span class="text-sm text-secondary">(${members.length}人)</span></span>
          <span class="flex gap-2 items-center">
            <span class="text-sm text-secondary">${members.map(m => Utils.escapeHtml(m)).join('、').substring(0, 40) || '空组'}</span>
            <button class="btn-icon" onclick="App.openDutyGroupModal('${g.id}')">\u{270F}\u{FE0F}</button>
            <button class="btn-icon" onclick="App.deleteDutyGroup('${g.id}')">\u{1F5D1}</button>
          </span>
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 班干部 ==========
    cadres() {
      const data = Store.get();
      if (!data) return '';

      const cadres = data.cadres || [];
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      const PRESET_TITLES = ['班长','副班长','团支书','学习委员','纪律委员','卫生委员','体育委员','文艺委员','宣传委员','生活委员'];
      const usedTitles = new Set(cadres.map(c => c.title));

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openCadreModal()">+ 任命班干部</button>
          ${PRESET_TITLES.filter(t => !usedTitles.has(t)).slice(0, 4).map(t =>
            `<button class="btn btn-outline btn-sm" onclick="App.openCadreModal(null, '${t}')">+ ${t}</button>`
          ).join('')}
        </div>
      `;

      if (cadres.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F396}\u{FE0F}</div><div class="text">暂无班干部<br><span class="text-sm">点击"任命班干部"或上方快捷按钮</span></div></div>';
        return html;
      }

      const ICONS = { '班长':'\u{1F3AF}', '副班长':'\u{1F3AF}', '团支书':'\u{1F534}', '学习委员':'\u{1F4D6}', '纪律委员':'\u{1F6E1}\u{FE0F}', '卫生委员':'\u{1F9F9}', '体育委员':'\u{26BD}', '文艺委员':'\u{1F3A4}', '宣传委员':'\u{1F4F0}', '生活委员':'\u{1F9EA}' };

      html += '<div class="cadre-grid">';
      cadres.forEach(c => {
        const s = studentById[c.studentId] || {};
        const color = s.name ? Utils.avatarColor(s.name) : '#9ca3af';
        html += `<div class="card cadre-card">
          <div class="cadre-icon">${ICONS[c.title] || '\u{1F396}\u{FE0F}'}</div>
          <div class="cadre-title">${Utils.escapeHtml(c.title)}</div>
          <div class="flex gap-2 items-center mt-1">
            <div class="student-avatar" style="background:${color};width:30px;height:30px;font-size:0.8rem;">${Utils.escapeHtml((s.name||'?').charAt(0))}</div>
            <div>
              <div class="text-bold text-sm">${Utils.escapeHtml(s.name || '未指定')}</div>
              ${s.starred ? '<div class="text-sm">\u{2B50} 重点关注</div>' : ''}
            </div>
          </div>
          <div class="text-sm text-secondary mt-1">${c.electedDate ? '任职: ' + Utils.formatDate(c.electedDate) : ''}</div>
          ${c.note ? `<div class="text-sm text-secondary">${Utils.escapeHtml(c.note)}</div>` : ''}
          <div class="flex gap-1 mt-2">
            <button class="btn-icon" onclick="App.openCadreModal('${c.id}')">\u{270F}\u{FE0F}</button>
            <button class="btn-icon" onclick="App.deleteCadre('${c.id}')">\u{1F5D1}</button>
          </div>
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 荣誉墙 ==========
    honors() {
      const data = Store.get();
      if (!data) return '';

      const honors = data.honors || [];
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap items-center">
          <button class="btn btn-primary" onclick="App.openHonorModal()">+ 记录荣誉</button>
          ${honors.length > 0 ? `<span class="tag blue">\u{1F3C5} 累计 ${honors.length} 项</span>` : ''}
        </div>
      `;

      if (honors.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F3C5}</div><div class="text">荣誉墙还是空的<br><span class="text-sm">记录班级和学生的每一份荣誉</span></div></div>';
        return html;
      }

      const LEVEL_CLS = { '国家级': 'gold', '省级': 'purple', '市级': 'blue', '区县级': 'cyan', '校级': 'green', '班级': 'gray' };

      const sorted = honors.slice().sort((a, b) => new Date(b.date) - new Date(a.date));
      html += '<div class="honor-grid">';
      sorted.forEach(h => {
        const levelCls = LEVEL_CLS[h.level] || 'gray';
        const names = (h.students || []).map(id => (studentById[id] || {}).name).filter(Boolean);
        html += `<div class="card honor-card level-${levelCls}">
          <div class="flex gap-2 items-center justify-between mb-2">
            <span class="tag ${levelCls}">\u{1F3C5} ${Utils.escapeHtml(h.level || '校级')}</span>
            <span class="tag ${h.type === '团体' ? 'blue' : 'green'}">${Utils.escapeHtml(h.type || '个人')}</span>
          </div>
          <div class="honor-title">${Utils.escapeHtml(h.title)}</div>
          <div class="text-sm text-secondary mt-1">\u{1F4C5} ${Utils.formatDate(h.date)}</div>
          ${names.length > 0 ? `<div class="flex gap-1 flex-wrap mt-2">${names.map(n => `<span class="tag gray">${Utils.escapeHtml(n)}</span>`).join('')}</div>` : ''}
          ${h.description ? `<div class="text-sm text-secondary mt-2">${Utils.escapeHtml(h.description)}</div>` : ''}
          <div class="flex gap-1 mt-2">
            <button class="btn-icon" onclick="App.openHonorModal('${h.id}')">\u{270F}\u{FE0F}</button>
            <button class="btn-icon" onclick="App.deleteHonor('${h.id}')">\u{1F5D1}</button>
          </div>
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 课程表 ==========
    timetable() {
      const data = Store.get();
      if (!data) return '';

      const tt = data.timetable || { rows: 9, weekend: false, grid: {} };
      const rows = tt.rows || 9;
      const weekend = !!tt.weekend;
      const days = weekend ? ['周一','周二','周三','周四','周五','周六','周日'] : ['周一','周二','周三','周四','周五'];
      const grid = tt.grid || {};

      // 节次标签 (上午1-4/下午5-8/晚9+)
      const rowLabel = (r) => {
        const n = r + 1;
        if (n <= 4) return `上午${n}`;
        if (n <= 8) return `下午${n - 4}`;
        return `晚${n - 8}`;
      };

      let html = `
        <div class="flex gap-2 items-center mb-3 flex-wrap">
          <label class="text-sm text-secondary">节数</label>
          <input type="number" class="input" style="width:64px;" min="4" max="14" value="${rows}" onchange="App.setTTSize('rows', this.value)">
          <div class="switch ${weekend ? 'on' : ''}" onclick="App.toggleTTWeekend()"></div>
          <span class="text-sm text-secondary">含周末</span>
          <button class="btn btn-outline" onclick="App.clearTimetable()" style="color:var(--danger);">清空课程表</button>
        </div>
        <div class="card timetable-card">
          <div class="table-wrapper">
            <table class="data-table timetable-table">
              <thead><tr><th></th>${days.map(d => `<th>${d}</th>`).join('')}</tr></thead>
              <tbody>
                ${Array.from({ length: rows }, (_, r) => `
                  <tr>
                    <td class="tt-row-label">${rowLabel(r)}</td>
                    ${days.map((_, c) => {
                      const val = grid[`${r}-${c}`] || '';
                      return `<td class="tt-cell ${val ? 'filled' : ''}" onclick="App.editTTCell(${r}, ${c})">${Utils.escapeHtml(val) || '<span class="tt-plus">+</span>'}</td>`;
                    }).join('')}
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
        <div class="text-sm text-secondary mt-2">\u{1F4A1} 点击空格填写课程，再点可修改。上午1-4节、下午5-8节、晚自习从第9节起。</div>
      `;

      return html;
    },

    // ========== 操行积分 ==========
    points() {
      const data = Store.get();
      if (!data) return '';

      const logs = data.points || [];
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      // 计算每生总分
      const totals = {};
      logs.forEach(p => {
        if (!totals[p.studentId]) totals[p.studentId] = { sum: 0, cnt: 0 };
        totals[p.studentId].sum += Number(p.delta) || 0;
        totals[p.studentId].cnt++;
      });
      const ranking = Object.entries(totals)
        .map(([sid, t]) => ({ sid, name: (studentById[sid] || {}).name || '?', ...t }))
        .sort((a, b) => b.sum - a.sum);

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openPointModal()">+ 记录加减分</button>
          <button class="btn btn-outline" onclick="App.exportPoints()">导出积分明细</button>
          ${logs.length > 0 ? `<span class="tag blue">\u{1F3AF} 本学期累计 ${logs.length} 笔</span>` : ''}
        </div>
      `;

      if (logs.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4AF}</div><div class="text">暂无积分记录<br><span class="text-sm">课堂表现、作业、纪律、活动均可加减分</span></div></div>';
        return html;
      }

      html += '<div class="content-grid">';

      // 排行榜
      html += `<div class="card">
        <div class="card-header"><span><span class="icon">\u{1F3C6}</span>积分排行</span></div>
        ${ranking.slice(0, 10).map((r, i) => `
          <div class="setting-row">
            <span>${i < 3 ? ['\u{1F947}','\u{1F948}','\u{1F949}'][i] : (i+1) + '.'} ${Utils.escapeHtml(r.name)}</span>
            <span class="text-bold" style="color:${r.sum >= 0 ? 'var(--success)' : 'var(--danger)'};">${r.sum > 0 ? '+' : ''}${r.sum}分 (${r.cnt}笔)</span>
          </div>
        `).join('')}
      </div>`;

      // 快捷加减分说明
      html += `<div class="card">
        <div class="card-header"><span><span class="icon">\u{1F4A1}</span>常用分值参考</span></div>
        <div class="text-sm" style="line-height:2;">
          \u{1F44D} 课堂积极发言 +2 &nbsp; 作业优秀 +3<br>
          \u{1F3C6} 竞赛获奖 +5~10 &nbsp; 好人好事 +3<br>
          \u26A0\uFE0F 迟到 -2 &nbsp; 旷课 -5 &nbsp; 违纪 -5~10
        </div>
      </div>`;

      html += '</div>';

      // 积分流水
      html += `<div class="card"><div class="card-header"><span><span class="icon">\u{1F4DC}</span>积分流水 (最近20笔)</span></div>`;
      logs.slice(-20).reverse().forEach(p => {
        const s = studentById[p.studentId] || {};
        html += `<div class="setting-row">
          <span>${Utils.formatDate(p.date)} ${Utils.escapeHtml(s.name || '?')}</span>
          <span class="flex gap-2 items-center">
            <span class="text-sm text-secondary">${Utils.escapeHtml(p.reason || '')}</span>
            <span class="tag ${p.delta >= 0 ? 'green' : 'red'}">${p.delta > 0 ? '+' : ''}${p.delta}</span>
            <button class="btn-icon" onclick="App.deletePoint('${p.id}')">\u{1F5D1}</button>
          </span>
        </div>`;
      });
      html += '</div>';

      return html;
    },

    // ========== 宿舍管理 ==========
    dorm() {
      const data = Store.get();
      if (!data) return '';

      // 按宿舍号分组
      const dormMap = {};
      const noDorm = [];
      data.students.forEach(s => {
        if (s.dorm) {
          if (!dormMap[s.dorm]) dormMap[s.dorm] = [];
          dormMap[s.dorm].push(s);
        } else {
          noDorm.push(s);
        }
      });
      const dormNames = Object.keys(dormMap).sort();

      const checks = data.dormChecks || [];

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openDormCheckModal()">+ 记录卫生检查</button>
          ${dormNames.length > 0 ? `<span class="tag blue">\u{1F6CF}\u{FE0F} ${dormNames.length}间宿舍 \u00B7 ${data.students.length - noDorm.length}人住宿</span>` : ''}
        </div>
      `;

      if (dormNames.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F6CF}\u{FE0F}</div><div class="text">暂无宿舍信息<br><span class="text-sm">在"学生"模块编辑学生档案填写宿舍号即可自动分组</span></div></div>';
        return html;
      }

      // 宿舍卡片
      html += '<div class="content-grid">';
      dormNames.forEach(dn => {
        const members = dormMap[dn];
        // 该宿舍检查统计
        const dnChecks = checks.filter(c => c.dorm === dn);
        const lastCheck = dnChecks[dnChecks.length - 1];
        const avg = dnChecks.length > 0
          ? Math.round(dnChecks.reduce((a, c) => a + Number(c.score || 0), 0) / dnChecks.length * 10) / 10
          : null;
        html += `<div class="card">
          <div class="card-header">
            <span><span class="icon">\u{1F6CF}\u{FE0F}</span>${Utils.escapeHtml(dn)} <span class="text-sm text-secondary">(${members.length}人)</span></span>
            ${avg !== null ? `<span class="tag ${avg >= 90 ? 'green' : avg >= 75 ? 'orange' : 'red'}">平均 ${avg}分</span>` : ''}
          </div>
          <div class="flex gap-2 flex-wrap">
            ${members.map(m => `<span class="tag ${m.starred ? 'orange' : 'gray'}">${Utils.escapeHtml(m.name)}${m.starred ? ' \u{2B50}' : ''}</span>`).join('')}
          </div>
          ${lastCheck ? `<div class="text-sm text-secondary mt-2">最近检查: ${Utils.formatDate(lastCheck.date)} ${lastCheck.score}分${lastCheck.note ? ' \u00B7 ' + Utils.escapeHtml(lastCheck.note) : ''}</div>` : ''}
        </div>`;
      });
      html += '</div>';

      // 未分配宿舍
      if (noDorm.length > 0) {
        html += `<div class="card" style="margin-top:12px;"><div class="card-header"><span><span class="icon">\u{2753}</span>未分配宿舍 (${noDorm.length}人)</span></div>
          <div class="flex gap-2 flex-wrap">${noDorm.map(s => `<span class="tag gray">${Utils.escapeHtml(s.name)}</span>`).join('')}</div>
        </div>`;
      }

      // 检查记录
      if (checks.length > 0) {
        html += `<div class="card" style="margin-top:12px;"><div class="card-header"><span><span class="icon">\u{1F4CB}</span>卫生检查记录 (最近15次)</span></div>`;
        checks.slice(-15).reverse().forEach(c => {
          html += `<div class="setting-row">
            <span>${Utils.formatDate(c.date)} \u00B7 ${Utils.escapeHtml(c.dorm)}</span>
            <span class="flex gap-2 items-center">
              ${c.note ? `<span class="text-sm text-secondary">${Utils.escapeHtml(c.note)}</span>` : ''}
              <span class="tag ${c.score >= 90 ? 'green' : c.score >= 75 ? 'orange' : 'red'}">${c.score}分</span>
              <button class="btn-icon" onclick="App.deleteDormCheck('${c.id}')">\u{1F5D1}</button>
            </span>
          </div>`;
        });
        html += '</div>';
      }

      return html;
    },

    // ========== 家校沟通 ==========
    communication() {
      const data = Store.get();
      if (!data) return '';

      // Tab: 沟通记录 / 家长通讯录
      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn ${currentCommTab === 'log' ? 'btn-primary' : 'btn-outline'}" onclick="App.switchCommTab('log')">\u{1F4DE} 沟通记录</button>
          <button class="btn ${currentCommTab === 'contacts' ? 'btn-primary' : 'btn-outline'}" onclick="App.switchCommTab('contacts')">\u{1F4D1} 家长通讯录</button>
        </div>
      `;

      if (currentCommTab === 'contacts') {
        return html + this.contacts();
      }

      const logs = data.communicationLog || [];
      html += `
        <div class="flex gap-2 mb-3">
          <button class="btn btn-primary" onclick="App.openCommModal()">+ 记录沟通</button>
        </div>
      `;

      if (logs.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4DE}</div><div class="text">暂无沟通记录</div></div>';
        return html;
      }

      html += '<div class="card"><div class="table-wrapper"><table class="data-table"><thead><tr><th>日期</th><th>学生</th><th>方式</th><th>内容</th><th>跟进</th><th></th></tr></thead><tbody>';
      logs.slice().reverse().forEach(l => {
        html += `<tr>
          <td>${Utils.formatDate(l.date)}</td>
          <td>${Utils.escapeHtml(l.studentName)}</td>
          <td><span class="tag ${l.type === '电话' ? 'green' : l.type === '面谈' ? 'blue' : 'gray'}">${Utils.escapeHtml(l.type)}</span></td>
          <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${Utils.escapeHtml(l.content)}</td>
          <td>${l.followUp ? '<span class="tag red">需跟进</span>' : '<span class="tag green">已处理</span>'}</td>
          <td><button class="btn-icon" onclick="App.deleteComm('${l.id}')">\u{1F5D1}</button></td>
        </tr>`;
      });
      html += '</tbody></table></div></div>';
      return html;
    },

    // 家长通讯录
    contacts() {
      const data = Store.get();
      const list = data.students.filter(s => s.parentName || s.parentPhone);
      if (list.length === 0) {
        return '<div class="empty-state"><div class="icon">\u{1F4D1}</div><div class="text">暂无家长联系方式<br><span class="text-sm">在学生档案中填写家长姓名/电话/职业后自动生成</span></div></div>';
      }
      let html = '<div class="card"><div class="table-wrapper"><table class="data-table"><thead><tr><th>学生</th><th>家长</th><th>职业</th><th>联系电话</th></tr></thead><tbody>';
      list.forEach(s => {
        html += `<tr>
          <td><span class="text-bold">${Utils.escapeHtml(s.name)}</span>${s.starred ? ' \u{2B50}' : ''}</td>
          <td>${Utils.escapeHtml(s.parentName || '-')}</td>
          <td>${Utils.escapeHtml(s.parentJob || '-')}</td>
          <td>${s.parentPhone ? `<a class="contact-call" href="tel:${Utils.escapeHtml(s.parentPhone)}">\u{1F4F1} ${Utils.escapeHtml(s.parentPhone)}</a>` : '-'}</td>
        </tr>`;
      });
      html += '</tbody></table></div></div>';
      html += '<div class="text-sm text-secondary mt-2">\u{1F4F1} \u7535\u8BDD\u53F7\u7801\u53EF\u76F4\u63A5\u70B9\u51FB\u62E8\u6253\uFF08\u624B\u673A\u6D4F\u89C8\u5668\u652F\u6301\uFF09</div>';
      return html;
    },

    // ========== 公告 ==========
    announcements() {
      const data = Store.get();
      if (!data) return '';

      const items = data.announcements || [];
      let html = `
        <div class="flex gap-2 mb-3">
          <button class="btn btn-primary" onclick="App.openAnnModal()">+ 发布公告</button>
        </div>
      `;

      if (items.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4E2}</div><div class="text">暂无公告</div></div>';
        return html;
      }

      html += '<div class="content-grid">';
      items.slice().reverse().forEach(a => {
        html += `<div class="card">
          <div class="card-header"><span class="text-bold">${Utils.escapeHtml(a.title)}</span></div>
          <div class="text-sm" style="white-space:pre-wrap;">${Utils.escapeHtml(a.content)}</div>
          <div class="flex justify-between items-center mt-2">
            <span class="text-sm text-secondary">${Utils.formatDate(a.date)}</span>
            <button class="btn-icon" onclick="App.deleteAnn('${a.id}')">\u{1F5D1}</button>
          </div>
        </div>`;
      });
      html += '</div>';
      return html;
    },

    // ========== 活动 / 班会计划 ==========
    activities() {
      const data = Store.get();
      if (!data) return '';

      // Tab 切换: 活动列表 / 班会计划
      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn ${currentActivitiesTab === 'list' ? 'btn-primary' : 'btn-outline'}" onclick="App.switchActivitiesTab('list')">\u{1F3C6} 班级活动</button>
          <button class="btn ${currentActivitiesTab === 'meetings' ? 'btn-primary' : 'btn-outline'}" onclick="App.switchActivitiesTab('meetings')">\u{1F4CB} 班会计划</button>
        </div>
      `;

      if (currentActivitiesTab === 'meetings') {
        return html + this.meetingPlans();
      }

      const items = data.activities || [];
      html += `
        <div class="flex gap-2 mb-3">
          <button class="btn btn-primary" onclick="App.openActModal()">+ 添加活动</button>
        </div>
      `;

      if (items.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F3C6}</div><div class="text">暂无活动</div></div>';
        return html;
      }

      const sorted = items.slice().sort((a, b) => new Date(a.date) - new Date(b.date));
      html += '<div class="card"><div class="timeline">';
      sorted.forEach(a => {
        const isPast = new Date(a.date) < new Date(new Date().toDateString());
        html += `<div class="timeline-item" style="${isPast ? 'opacity:0.65;' : ''}">
          <div class="time">${Utils.relativeDate(a.date)} (${Utils.formatDate(a.date)})</div>
          <div class="content">
            <span class="text-bold">${Utils.escapeHtml(a.title)}</span>
            ${a.description ? '<br><span class="text-sm text-secondary">' + Utils.escapeHtml(a.description) + '</span>' : ''}
            ${(a.photos || []).length ? `<div class="act-photos">${a.photos.map((p, i) => `<img src="${p}" class="act-photo" onclick="App.viewPhoto('${a.id}', ${i})">`).join('')}</div>` : ''}
          </div>
          <span class="flex gap-1" style="margin-top:4px;">
            <button class="btn-icon" title="编辑/加照片" onclick="App.openActModal('${a.id}')">\u{270F}\u{FE0F}</button>
            <button class="btn-icon" onclick="App.deleteAct('${a.id}')">\u{1F5D1}</button>
          </span>
        </div>`;
      });
      html += '</div></div>';
      return html;
    },

    // 班会计划（按周次编排）
    meetingPlans() {
      const data = Store.get();
      const plans = data.meetingPlans || [];
      const doneCount = plans.filter(p => p.status === 'done').length;

      let html = `
        <div class="flex gap-2 mb-3 flex-wrap">
          <button class="btn btn-primary" onclick="App.openMeetingModal()">+ 添加班会计划</button>
          ${plans.length > 0 ? `<span class="tag blue">\u{1F4CB} ${plans.length}次计划 \u00B7 已开 ${doneCount} 次</span>` : ''}
        </div>
      `;

      if (plans.length === 0) {
        html += '<div class="empty-state"><div class="icon">\u{1F4CB}</div><div class="text">暂无班会计划<br><span class="text-sm">按周次编排学期班会主题，如: 第1周·开学收心、第4周·学风建设</span></div></div>';
        return html;
      }

      const sorted = plans.slice().sort((a, b) => (a.week || 0) - (b.week || 0));
      html += '<div class="card">';
      sorted.forEach(p => {
        html += `<div class="setting-row">
          <span>
            <span class="text-bold">第${p.week}周</span> \u00B7 ${Utils.escapeHtml(p.topic)}
            ${p.date ? `<span class="text-sm text-secondary">(${Utils.formatDate(p.date)})</span>` : ''}
            ${p.status === 'done' ? '<span class="tag green">已开</span>' : '<span class="tag gray">未开</span>'}
            ${p.content ? `<br><span class="text-sm text-secondary">${Utils.escapeHtml(p.content)}</span>` : ''}
          </span>
          <span class="flex gap-1">
            <button class="btn-icon" title="切换已开/未开" onclick="App.toggleMeetingStatus('${p.id}')">${p.status === 'done' ? '\u{1F501}' : '\u{2705}'}</button>
            <button class="btn-icon" onclick="App.openMeetingModal('${p.id}')">\u{270F}\u{FE0F}</button>
            <button class="btn-icon" onclick="App.deleteMeeting('${p.id}')">\u{1F5D1}</button>
          </span>
        </div>`;
      });
      html += '</div>';
      return html;
    },

    // ========== 导出中心（生态适配）==========
    exportcenter() {
      const data = Store.get();
      if (!data) return '';

      const card = (title, icon, desc, rows) => `
        <div class="card ec-card">
          <div class="card-title">${icon} ${title}</div>
          <div class="text-sm text-secondary mb-2">${desc}</div>
          ${rows.map(r => `<div class="setting-row"><span>${r.label}</span><button class="btn btn-outline btn-sm" onclick="${r.fn}">导出</button></div>`).join('')}
        </div>`;

      const csvRows = [
        { label: '学生名单（含家长联系方式）', fn: "App.exportStudentsCsv()" },
        { label: '考勤记录（按日期明细）', fn: "App.exportAttendanceCsv()" },
        { label: '成绩单（历次考试）', fn: "App.exportScoresCsv()" },
        { label: '操行积分流水', fn: "App.exportPointsCsv()" },
        { label: '家校沟通记录', fn: "App.exportCommCsv()" },
        { label: '请假记录', fn: "App.exportLeavesCsv()" },
        { label: '作业收缴情况', fn: "App.exportHomeworkCsv()" }
      ];
      const mdRows = [
        { label: '工作日志（班主任留痕）', fn: "App.exportMarkdown('journal')" },
        { label: '期末评语合集', fn: "App.exportMarkdown('comments')" },
        { label: '班会方案合集', fn: "App.exportMarkdown('meetings')" },
        { label: '班级大事记（活动/荣誉）', fn: "App.exportMarkdown('chronicle')" }
      ];

      return `
        <div class="export-center">
          <div class="ec-intro">
            <b>把工作台里的数据"取出来"用。</b>
            表格导出为 CSV（带 BOM，<b>WPS 表格 / Excel / 飞书多维表格</b> 可直接打开或导入）；
            文字导出为 Markdown（可直接粘进 <b>腾讯 IMA 知识库 / 飞书文档 / WPS 智能文档</b>）；
            换设备用「全量 JSON 备份」。文件保存在浏览器"下载"目录。
          </div>
          <div class="ec-grid">
            ${card('表格 · CSV', '\u{1F4CA}', 'WPS / Excel / 飞书多维表格通用', csvRows)}
            ${card('文档 · Markdown', '\u{1F4DD}', '供 IMA 知识库 / 飞书 / WPS 智能文档', mdRows)}
          </div>
          <div class="card ec-card">
            <div class="card-title">\u{1F4BE} 备份与迁移</div>
            <div class="text-sm text-secondary mb-2">JSON 是唯一能完整恢复工作台的备份格式，请定期导出并存到网盘。</div>
            <div class="setting-row"><span>全量数据备份（换电脑 / 换浏览器用）</span><button class="btn btn-outline btn-sm" onclick="App.exportData()">导出 JSON</button></div>
            <div class="setting-row"><span>本周周报（考勤/任务/沟通汇总）</span><button class="btn btn-outline btn-sm" onclick="App.exportWeeklyReport()">生成周报</button></div>
            <div class="setting-row"><span>从备份恢复</span><button class="btn btn-outline btn-sm" onclick="document.getElementById('ec-import-file').click()">选择备份文件</button></div>
            <input type="file" id="ec-import-file" accept=".json" style="display:none;" onchange="App.importData(this)">
          </div>
          <div class="text-sm text-secondary mt-3">
            \u{1F4A1} 提示：导出的 JSON 备份可放进 <b>百度网盘 / 微云 / 飞书云文档</b> 等任意网盘做异地保存；这是目前唯一可靠的"云同步"方式（工作台没有服务器，不会自动上传任何数据）。
          </div>
        </div>`;
    },

    // ========== 设置 ==========
    settings() {
      const data = Store.get();
      if (!data) return '';
      const s = data.meta.settings || {};
      const widgets = s.widgets || ['stats','attendance','trend','tasks','schedule','birthday','announcements','duty'];
      const customFields = s.customFields || [];

      let html = '<div class="content-grid"><div class="card">';

      // 班级信息
      html += `<div class="setting-group">
        <div class="setting-group-title">班级信息</div>
        <div class="form-group"><label class="form-label">班级名称</label>
          <input type="text" class="input" id="set-classname" value="${Utils.escapeHtml(data.meta.className || '')}"></div>
        <div class="form-group"><label class="form-label">班主任姓名</label>
          <input type="text" class="input" id="set-teacher" value="${Utils.escapeHtml(data.meta.teacher || '')}"></div>
        <div class="form-group"><label class="form-label">班级口号 (显示在工作台顶部)</label>
          <input type="text" class="input" id="set-motto" value="${Utils.escapeHtml(data.meta.motto || '')}" placeholder="如: 团结奋进，全面发展"></div>
        <div class="setting-row">
          <span>学校 Logo (显示在侧边栏，96\u00D796 自动压缩)</span>
          <span class="flex gap-2">
            <button class="btn btn-outline btn-sm" onclick="document.getElementById('logo-file').click()">上传图片</button>
            ${localStorage.getItem('hw_logo') ? `<button class="btn btn-outline btn-sm" style="color:var(--danger);" onclick="App.removeLogo()">移除</button>` : ''}
          </span>
        </div>
        <input type="file" id="logo-file" accept="image/*" style="display:none;" onchange="App.uploadLogo(this)">
        <button class="btn btn-primary btn-sm" onclick="App.saveClassInfo()">保存班级信息</button>
      </div>`;

      // 主题
      const THEME_LIST = [
        { id: 'warm',  name: '暖阳 \u{1F31E} 米白浅黄' },
        { id: 'pink',  name: '樱粉 \u{1F338} 浅红' },
        { id: 'blue',  name: '清爽蓝' },
        { id: 'green', name: '自然绿' },
        { id: 'orange', name: '活力橙' },
        { id: 'purple', name: '典雅紫' },
        { id: 'dark',  name: '暗色' }
      ];
      html += `<div class="setting-group">
        <div class="setting-group-title">主题色 (前两款为教育淡雅风，推荐)</div>
        <div class="theme-options">
          ${THEME_LIST.map(t => `
            <div class="theme-btn theme-${t.id} ${s.theme === t.id ? 'active' : ''}" data-val="${t.id}" title="${t.name}" onclick="App.setTheme('${t.id}')"></div>
          `).join('')}
        </div>
        <div class="text-sm text-secondary mt-1">当前: ${THEME_LIST.find(t => t.id === (s.theme || 'warm'))?.name || '暖阳 \u{1F31E} 米白浅黄'}</div>
      </div>`;

      // 班级管理 (多班切换)
      const reg = Store.getRegistry();
      html += `<div class="setting-group">
        <div class="setting-group-title">班级管理</div>
        <div class="setting-row">
          <span>我的班级 (${reg.length}个)</span>
          <button class="btn btn-outline btn-sm" onclick="App.openClassSwitcher()">切换 / 新建</button>
        </div>
      </div>`;

      // 概览模块
      html += `<div class="setting-group">
        <div class="setting-group-title">概览模块</div>
        ${[
          { id: 'stats', label: '统计卡片' },
          { id: 'attendance', label: '今日考勤' },
          { id: 'trend', label: '出勤趋势图' },
          { id: 'birthday', label: '近期生日提醒' },
          { id: 'duty', label: '本周值日' },
          { id: 'tasks', label: '待办任务' },
          { id: 'schedule', label: '近期活动' },
          { id: 'announcements', label: '最新公告' }
        ].map(w => `
          <div class="setting-row">
            <span>${w.label}</span>
            <div class="switch ${widgets.includes(w.id) ? 'on' : ''}" onclick="App.toggleWidget('${w.id}')"></div>
          </div>
        `).join('')}
      </div>`;

      // 核心管理模块
      const coreEnabled = s.coreModules || CORE_MODULES.map(m => m.id);
      html += `<div class="setting-group">
        <div class="setting-group-title">核心管理模块 (可自由增删，左侧栏显示)</div>
        ${CORE_MODULES.map(m => `
          <div class="setting-row">
            <span><span class="icon">${m.icon}</span> ${m.label}</span>
            <div class="switch ${coreEnabled.includes(m.id) ? 'on' : ''}" onclick="App.toggleCoreModule('${m.id}')"></div>
          </div>
        `).join('')}
      </div>`;

      // 模块排序 / 置顶 / 显隐（解决"功能多但常用的找不到、调整顺序麻烦"）
      const hiddenModules = getHiddenModules();
      html += `<div class="setting-group">
        <div class="setting-group-title">模块排序与显隐 <span class="text-sm text-secondary">(常用的置顶，不用的隐藏)</span></div>
        <div class="nav-order-list">
          ${visibleNavItems().map(m => `
            <div class="nav-order-row">
              <span class="no-icon">${m.icon}</span>
              <span class="no-label">${m.label}</span>
              <span class="no-actions">
                <button class="btn-icon" title="置顶" onclick="App.pinNavItem('${m.id}')">\u2B50</button>
                <button class="btn-icon" title="上移" onclick="App.moveNavItem('${m.id}', -1)">\u2191</button>
                <button class="btn-icon" title="下移" onclick="App.moveNavItem('${m.id}', 1)">\u2193</button>
                <div class="switch ${hiddenModules.includes(m.id) ? '' : 'on'}" title="显示 / 隐藏" onclick="App.toggleHideModule('${m.id}')"></div>
              </span>
            </div>
          `).join('')}
        </div>
        ${hiddenModules.length ? `<div class="text-sm text-secondary mt-2">已隐藏 ${hiddenModules.length} 个模块 · <a href="javascript:void(0)" onclick="App.resetHiddenModules()">全部恢复显示</a></div>` : ''}
        <div class="mt-2"><button class="btn btn-outline btn-sm" onclick="App.resetNavOrder()">恢复默认顺序</button></div>
      </div>`;

      // 首页快捷操作
      const qaIds = Array.isArray(s.quickActions) ? s.quickActions : QUICK_ACTIONS.slice(0, 8).map(a => a.id);
      html += `<div class="setting-group">
        <div class="setting-group-title">首页快捷操作 <span class="text-sm text-secondary">(高频动作一步直达)</span></div>
        <div class="qa-toggle-grid">
          ${QUICK_ACTIONS.map(a => `
            <button class="qa-toggle ${qaIds.includes(a.id) ? 'on' : ''}" onclick="App.toggleQuickAction('${a.id}')">
              <span class="icon">${a.icon}</span> ${a.label}
            </button>
          `).join('')}
        </div>
      </div>`;

      // 自定义字段
      html += `<div class="setting-group">
        <div class="setting-group-title">学生自定义字段</div>
        <div id="custom-fields-list">
          ${customFields.map((f, i) => `
            <div class="setting-row">
              <span>${Utils.escapeHtml(f)}</span>
              <button class="btn-icon" onclick="App.removeCustomField(${i})">\u{1F5D1}</button>
            </div>
          `).join('') || '<div class="text-sm text-secondary mb-2">暂无自定义字段</div>'}
        </div>
        <div class="flex gap-2 mt-2">
          <input type="text" class="input" id="new-field-name" placeholder="字段名称(如: 社团)">
          <button class="btn btn-primary btn-sm" onclick="App.addCustomField()">添加</button>
        </div>
      </div>`;

      html += '</div>';

      // 数据管理
      html += '<div class="card">';
      html += `<div class="setting-group">
        <div class="setting-group-title">数据管理</div>
        <div class="setting-row"><span>导出本周周报 (考勤/任务/沟通汇总)</span><button class="btn btn-outline btn-sm" onclick="App.exportWeeklyReport()">生成周报</button></div>
        <div class="setting-row"><span>导出中心 (CSV / Markdown，适配 WPS·飞书·IMA)</span><button class="btn btn-outline btn-sm" onclick="App.navigate('exportcenter')">打开</button></div>
        <div class="setting-row"><span>导出全部数据</span><button class="btn btn-outline btn-sm" onclick="App.exportData()">导出 JSON</button></div>
        <div class="setting-row"><span>导入数据</span><button class="btn btn-outline btn-sm" onclick="document.getElementById('import-file').click()">选择文件</button></div>
        <div class="setting-row"><span>清空全部数据</span><button class="btn btn-outline btn-sm" style="color:var(--danger);" onclick="App.clearAllData()">清空</button></div>
        <input type="file" id="import-file" accept=".json" style="display:none;" onchange="App.importData(this)">
      </div>`;
      html += '</div></div>';

      return html;
    },

    // ========== 核心管理 仪表盘 ==========
    core() {
      const data = Store.get();
      if (!data) return '';
      const enabled = coreChildren();
      const todo = data.coreTodo || [];
      const follow = data.coreFollow || [];
      const safety = data.safety || [];
      const dropout = data.dropout || [];
      const growth = data.growth || [];
      const projects = data.projects || [];
      const enlist = data.enlist || [];
      const comm = data.communicationLog || [];
      const moralLib = data.moralLib || [];

      const stats = {
        'core-todo':      { n: todo.filter(t => !t.done).length, total: todo.length, risk: todo.some(t => !t.done && t.priority === '高') },
        'core-followup':  { n: follow.length, total: follow.length, prog: follow.length ? Math.round(follow.reduce((a, b) => a + (+b.progress || 0), 0) / follow.length) : 0 },
        'core-safety':    { n: safety.length, total: safety.length, risk: safety.some(s => s.level === '高') },
        'core-dropout':   { n: dropout.length, total: dropout.length, risk: dropout.some(d => d.level === '红') },
        'core-growth':    { n: growth.length, total: growth.length },
        'core-comm':      { n: comm.length, total: comm.length },
        'core-moral':     { n: moralLib.length, total: moralLib.length },
        'core-project':   { n: projects.length, total: projects.length, prog: projects.length ? Math.round(projects.reduce((a, b) => a + (+b.progress || 0), 0) / projects.length) : 0 },
        'core-enlist':    { n: enlist.length, total: enlist.length }
      };

      // 风险横幅
      const risks = [];
      const highTodo = todo.filter(t => !t.done && t.priority === '高').length;
      if (highTodo) risks.push({ t: `高优先级待办未完成 ${highTodo} 项`, l: '高' });
      const redDrop = dropout.filter(d => d.level === '红' && d.status !== '流失').length;
      if (redDrop) risks.push({ t: `控辍保学红色预警 ${redDrop} 人`, l: '高' });
      const highSafe = safety.filter(s => s.level === '高').length;
      if (highSafe) risks.push({ t: `特异体质高风险 ${highSafe} 人`, l: '高' });
      const noPhone = data.students.filter(s => !s.parentPhone).length;
      if (noPhone) risks.push({ t: `${noPhone} 名学生缺少家长电话`, l: '中' });
      const contacted = {};
      comm.forEach(c => { if (c.studentName) { const d = new Date(c.date || 0); if (!contacted[c.studentName] || d > contacted[c.studentName]) contacted[c.studentName] = d; } });
      const uncontacted = data.students.filter(s => { const d = contacted[s.name]; return s.parentPhone && (!d || Math.ceil((Date.now() - d) / 86400000) > 30); }).length;
      if (uncontacted) risks.push({ t: `${uncontacted} 名家长超30天未沟通`, l: '中' });

      let html = '';
      if (risks.length) {
        html += `<div class="risk-banner">
          <div class="risk-banner-title">⚠️ 风险提醒 (${risks.length})</div>
          ${risks.map(r => `<div class="risk-banner-item">${uiRisk(r.l)} ${Utils.escapeHtml(r.t)}</div>`).join('')}
        </div>`;
      } else {
        html += `<div class="safe-banner">✅ 暂无高危风险项，继续保持</div>`;
      }

      html += `<div class="core-grid">`;
      enabled.forEach(m => {
        const st = stats[m.id] || { n: 0, total: 0 };
        let metric = '';
        if (m.id === 'core-followup' || m.id === 'core-project') metric = uiBar(st.prog || 0, 'var(--primary)', (st.prog || 0) + '% 平均进度');
        else if (st.risk) metric = uiRisk('高');
        else metric = `<span class="text-sm text-secondary">${st.n} 条记录</span>`;
        html += `<div class="card core-module-card" onclick="App.navigate('${m.id}')" style="cursor:pointer;">
          <div class="flex items-center gap-2 mb-2"><span class="icon" style="font-size:1.4rem;">${m.icon}</span><b>${m.label}</b>${st.risk ? '<span class="nav-badge" style="margin-left:auto;">!</span>' : ''}</div>
          ${metric}
          <div class="text-sm text-secondary mt-1">${st.n} / ${st.total} 条</div>
        </div>`;
      });
      html += `</div>`;

      html += `<div class="content-grid mt-3">
        <div class="card"><div class="card-header"><span>📊 各模块风险 / 未完成项</span></div><canvas id="chart-core-risk" height="180"></canvas></div>
        <div class="card"><div class="card-header"><span>📈 重点 / 专项任务平均进度</span></div><canvas id="chart-core-progress" height="180"></canvas></div>
      </div>`;

      html += `<div class="text-sm text-secondary mt-3">💡 点击模块卡片进入对应工作台；「设置 → 核心管理模块」可自由增删子模块。常用智能工具：<a href="javascript:void(0)" onclick="App.navigate('seating')">智能座次表</a> · <a href="javascript:void(0)" onclick="App.randomPick()">智能随机点名</a> · <a href="javascript:void(0)" onclick="App.navigate('duty')">值日排班</a></div>`;

      return html;
    },

    // ========== 核心管理 通用列表 ==========
    coreList(type) {
      const cfg = CORE_TYPES[type];
      const data = Store.get();
      const arr = (data[CORE_DATA_KEY[type]] || []);
      const byId = {}; data.students.forEach(s => byId[s.id] = s);
      const listHtml = arr.length ? arr.map(it => `
        <div class="card core-item">
          <div class="core-item-body">${cfg.card(it, byId)}</div>
          <div class="core-item-actions">
            <button class="btn-icon" title="编辑" onclick="App.openCoreModal('${type}','${it.id}')">✏️</button>
            <button class="btn-icon" title="删除" onclick="App.deleteCoreItem('${type}','${it.id}')">🗑️</button>
          </div>
        </div>`).join('') : '<div class="empty-state"><div class="icon">📭</div><div class="text">暂无记录，点击右上角添加</div></div>';
      const header = `<div class="flex gap-2 mb-3 flex-wrap items-center">
        <button class="btn btn-primary" onclick="App.openCoreModal('${type}')">+ ${cfg.addLabel || '添加'}</button>
        <span class="tag blue">共 ${arr.length} 条</span>
      </div>`;
      let chart = '';
      if (type === 'dropout') chart = `<div class="card mt-3"><div class="card-header"><span>📊 预警等级分布</span></div><canvas id="chart-dropout" height="180"></canvas></div>`;
      if (type === 'safety') chart = `<div class="card mt-3"><div class="card-header"><span>📊 特异体质类型分布</span></div><canvas id="chart-safety" height="180"></canvas></div>`;
      return header + `<div class="core-list">${listHtml}</div>` + chart;
    },

    'core-todo'() { return this.coreList('todo'); },
    'core-followup'() { return this.coreList('follow'); },
    'core-safety'() { return this.coreList('safety'); },
    'core-dropout'() { return this.coreList('dropout'); },
    'core-growth'() { return this.coreList('growth'); },
    'core-project'() { return this.coreList('project'); },
    'core-enlist'() { return this.coreList('enlist'); },

    // ========== 家校沟通中心 ==========
    'core-comm'() {
      const data = Store.get();
      const comm = data.communicationLog || [];
      const byName = {};
      comm.forEach(c => { if (c.studentName) { const d = new Date(c.date || 0); if (!byName[c.studentName] || d > byName[c.studentName]) byName[c.studentName] = d; } });
      const withPhone = data.students.filter(s => s.parentPhone);
      const contactedCount = withPhone.filter(s => byName[s.name]).length;
      const uncontacted = data.students.filter(s => { const d = byName[s.name]; return s.parentPhone && (!d || Math.ceil((Date.now() - d) / 86400000) > 30); });
      const thisMonth = comm.filter(c => c.date && c.date.slice(0, 7) === Utils.today().slice(0, 7)).length;
      const followUp = comm.filter(c => c.followUp).length;

      let html = `<div class="stats-grid">
        <div class="stat-card"><div class="stat-num">${contactedCount}/${withPhone.length}</div><div class="stat-label">已建联家长</div></div>
        <div class="stat-card"><div class="stat-num">${thisMonth}</div><div class="stat-label">本月沟通次数</div></div>
        <div class="stat-card"><div class="stat-num" style="color:var(--warning)">${uncontacted.length}</div><div class="stat-label">超30天未沟通</div></div>
        <div class="stat-card"><div class="stat-num">${followUp}</div><div class="stat-label">待跟进</div></div>
      </div>`;

      if (uncontacted.length) {
        html += `<div class="risk-banner"><div class="risk-banner-title">⚠️ 需主动沟通 (超30天)</div>
          ${uncontacted.map(s => `<div class="risk-banner-item">${uiPill(s.name, '')} ${Utils.escapeHtml(s.parentPhone || '')}</div>`).join('')}</div>`;
      }

      html += `<div class="card mb-3"><div class="card-header"><span>📊 家长沟通覆盖</span></div><canvas id="chart-comm" height="180"></canvas></div>`;
      html += `<div class="flex gap-2 mb-2"><button class="btn btn-primary" onclick="App.openCommModal()">+ 记录沟通</button><button class="btn btn-outline" onclick="App.navigate('communication')">查看全部记录</button></div>`;
      const recent = comm.slice().sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0)).slice(0, 12);
      html += recent.length ? `<div class="core-list">` + recent.map(c => `
        <div class="card core-item"><div class="core-item-body">
          <b>${Utils.escapeHtml(c.studentName || '')}</b> ${uiPill(c.type || '电话', 'pill-blue')} <span class="text-sm text-secondary">${Utils.escapeHtml(c.date || '')}</span>${c.followUp ? uiPill('待跟进', 'pill-orange') : ''}
          <div class="text-sm">${Utils.escapeHtml(c.content || '')}</div>
        </div></div>`).join('') + `</div>` : '<div class="empty-state"><div class="icon">📭</div><div class="text">暂无沟通记录</div></div>';
      return html;
    },

    // ========== 思政德育活动库 ==========
    'core-moral'() {
      const data = Store.get();
      if (!data.moralLib || !data.moralLib.length) {
        Store.update(d => { d.moralLib = PRESET_MORAL.map(m => ({ id: Utils.uid(), ...m })); });
        return this['core-moral']();
      }
      const lib = data.moralLib;
      const listHtml = lib.map(m => `
        <div class="card core-item"><div class="core-item-body">
          <div class="flex items-center gap-2"><b>${Utils.escapeHtml(m.title)}</b>${uiPill(m.category, 'pill-green')}</div>
          <div class="text-sm text-secondary">目标：${Utils.escapeHtml(m.goal || '')}</div>
          <div class="text-sm">步骤：${Utils.escapeHtml(m.steps || '')}</div>
          <div class="flex gap-2 mt-2">
            <button class="btn btn-outline btn-sm" onclick="App.addMoralToActivity('${m.id}')">+ 加入班级活动</button>
            <button class="btn-icon" onclick="App.deleteMoral('${m.id}')">🗑️</button>
          </div>
        </div></div>`).join('');
      return `<div class="flex gap-2 mb-3 flex-wrap items-center">
        <button class="btn btn-primary" onclick="App.openMoralModal()">+ 添加主题</button>
        <span class="tag blue">共 ${lib.length} 个主题</span>
      </div>` + `<div class="core-list">${listHtml}</div>`;
    }

  };

  // 核心管理子模块字段配置
  const CORE_TYPES = {
    todo: {
      title: '今日核心待办事项', addLabel: '添加待办',
      fields: [
        { k: 'content', label: '待办内容', type: 'text', req: true, ph: '如：收缴数学作业、联系家长' },
        { k: 'priority', label: '优先级', type: 'select', options: ['高', '中', '低'], def: '中' },
        { k: 'due', label: '时限', type: 'text', ph: '如：今天 / 本周五 / 15:00' }
      ],
      card: (it) => `<b>${Utils.escapeHtml(it.content)}</b> ${uiPill(it.priority + '优先', it.priority === '高' ? 'pill-red' : it.priority === '中' ? 'pill-orange' : 'pill-gray')}${it.due ? `<div class="text-sm text-secondary">⏰ ${Utils.escapeHtml(it.due)}</div>` : ''}<div class="setting-row" style="border:none;padding:6px 0;"><span class="text-sm">${it.done ? '✅ 已完成' : '⬜ 未完成'}</span><div class="switch ${it.done ? 'on' : ''}" onclick="App.toggleCoreDone('todo','${it.id}')"></div></div>`
    },
    follow: {
      title: '近期重点事项跟进', addLabel: '添加事项',
      fields: [
        { k: 'title', label: '事项标题', type: 'text', req: true },
        { k: 'owner', label: '负责人', type: 'text', ph: '如：班主任/班委/家长' },
        { k: 'status', label: '状态', type: 'select', options: ['未开始', '进行中', '已完成', '暂缓'], def: '进行中' },
        { k: 'progress', label: '进度(%)', type: 'number', def: 0 },
        { k: 'due', label: '截止日期', type: 'date' },
        { k: 'note', label: '备注', type: 'textarea' }
      ],
      card: (it) => `<b>${Utils.escapeHtml(it.title)}</b>${it.owner ? `<span class="text-sm text-secondary"> · ${Utils.escapeHtml(it.owner)}</span>` : ''} ${uiPill(it.status, it.status === '已完成' ? 'pill-green' : it.status === '进行中' ? 'pill-blue' : 'pill-gray')}${uiBar(it.progress, 'var(--primary)')}${it.due ? `<div class="text-sm text-secondary">📅 ${Utils.escapeHtml(it.due)}</div>` : ''}${it.note ? `<div class="text-sm">${Utils.escapeHtml(it.note)}</div>` : ''}`
    },
    safety: {
      title: '学生安全与特异体质', addLabel: '添加记录', studentRef: true,
      fields: [
        { k: 'studentId', label: '学生', type: 'student', req: true },
        { k: 'type', label: '类型', type: 'select', options: ['过敏', '心脏病', '哮喘', '近视/视力', '癫痫', '心理关注', '伤残/行动不便', '其他特异体质'], def: '其他特异体质' },
        { k: 'level', label: '风险等级', type: 'select', options: ['高', '中', '低'], def: '中' },
        { k: 'desc', label: '情况说明', type: 'textarea', ph: '如：青霉素过敏，需随身备药' },
        { k: 'measures', label: '防护/应对措施', type: 'textarea' }
      ],
      card: (it, byId) => `${byId[it.studentId] ? `<b>${Utils.escapeHtml(byId[it.studentId].name)}</b>` : '<span class="text-sm text-secondary">未关联学生</span>'} ${uiPill(it.type, 'pill-blue')} ${uiRisk(it.level)}${it.desc ? `<div class="text-sm">${Utils.escapeHtml(it.desc)}</div>` : ''}${it.measures ? `<div class="text-sm text-secondary">措施：${Utils.escapeHtml(it.measures)}</div>` : ''}`
    },
    dropout: {
      title: '控辍保学跟踪', addLabel: '添加跟踪', studentRef: true,
      fields: [
        { k: 'studentId', label: '学生', type: 'student', req: true },
        { k: 'level', label: '预警等级', type: 'select', options: ['红', '橙', '黄'], def: '黄' },
        { k: 'status', label: '状态', type: 'select', options: ['在控', '已劝返', '流失'], def: '在控' },
        { k: 'reason', label: '辍学风险原因', type: 'textarea', ph: '如：家庭困难、厌学、外出务工' },
        { k: 'measures', label: '帮扶措施', type: 'textarea' },
        { k: 'lastContact', label: '最近一次联系', type: 'date' }
      ],
      card: (it, byId) => `${byId[it.studentId] ? `<b>${Utils.escapeHtml(byId[it.studentId].name)}</b>` : ''} ${uiRisk(it.level)} ${uiPill(it.status, it.status === '在控' ? 'pill-green' : it.status === '已劝返' ? 'pill-orange' : 'pill-red')}${it.reason ? `<div class="text-sm">原因：${Utils.escapeHtml(it.reason)}</div>` : ''}${it.lastContact ? `<div class="text-sm text-secondary">📞 ${Utils.escapeHtml(it.lastContact)}</div>` : ''}`
    },
    growth: {
      title: '学生成长档案', addLabel: '添加记录', studentRef: true,
      fields: [
        { k: 'studentId', label: '学生', type: 'student', req: true },
        { k: 'date', label: '记录日期', type: 'date', def: Utils.today() },
        { k: 'type', label: '类型', type: 'select', options: ['思想品德', '学业进步', '特长发展', '社会实践', '获奖荣誉', '心理关爱', '其他'], def: '其他' },
        { k: 'content', label: '成长记录', type: 'textarea', req: true }
      ],
      card: (it, byId) => `${byId[it.studentId] ? `<b>${Utils.escapeHtml(byId[it.studentId].name)}</b>` : ''} ${uiPill(it.type, 'pill-green')}${it.date ? `<span class="text-sm text-secondary"> · ${Utils.escapeHtml(it.date)}</span>` : ''}<div class="text-sm">${Utils.escapeHtml(it.content)}</div>`
    },
    project: {
      title: '学校专项任务跟踪', addLabel: '添加任务',
      fields: [
        { k: 'title', label: '任务标题', type: 'text', req: true },
        { k: 'owner', label: '牵头人', type: 'text', ph: '如：班主任/年级组' },
        { k: 'status', label: '状态', type: 'select', options: ['未启动', '推进中', '已完成', '待验收'], def: '推进中' },
        { k: 'progress', label: '进度(%)', type: 'number', def: 0 },
        { k: 'due', label: '截止日期', type: 'date' },
        { k: 'note', label: '说明', type: 'textarea' }
      ],
      card: (it) => `<b>${Utils.escapeHtml(it.title)}</b>${it.owner ? `<span class="text-sm text-secondary"> · ${Utils.escapeHtml(it.owner)}</span>` : ''} ${uiPill(it.status, it.status === '已完成' ? 'pill-green' : it.status === '推进中' ? 'pill-blue' : 'pill-gray')}${uiBar(it.progress, 'var(--primary)')}${it.due ? `<div class="text-sm text-secondary">📅 ${Utils.escapeHtml(it.due)}</div>` : ''}${it.note ? `<div class="text-sm">${Utils.escapeHtml(it.note)}</div>` : ''}`
    },
    enlist: {
      title: '学生征兵记录', addLabel: '添加记录', studentRef: true,
      fields: [
        { k: 'studentId', label: '学生', type: 'student', req: true },
        { k: 'status', label: '阶段', type: 'select', options: ['意向', '报名', '体检', '政审', '入伍', '退兵'], def: '意向' },
        { k: 'date', label: '记录日期', type: 'date', def: Utils.today() },
        { k: 'note', label: '备注', type: 'textarea', ph: '如：应征地、兵种意向' }
      ],
      card: (it, byId) => `${byId[it.studentId] ? `<b>${Utils.escapeHtml(byId[it.studentId].name)}</b>` : ''} ${uiPill(it.status, it.status === '入伍' ? 'pill-green' : (it.status === '意向' || it.status === '报名') ? 'pill-blue' : 'pill-orange')}${it.date ? `<span class="text-sm text-secondary"> · ${Utils.escapeHtml(it.date)}</span>` : ''}${it.note ? `<div class="text-sm">${Utils.escapeHtml(it.note)}</div>` : ''}`
    }
  };

  // ---- 主应用 ----
  const App = {
    init() {
      const data = Store.get();
      if (!data) return;

      // 应用主题
      const theme = (data.meta.settings && data.meta.settings.theme) || 'warm';
      document.documentElement.setAttribute('data-theme', theme);

      // 多班注册（兼容旧数据）
      Store.ensureRegistered();

      // 恢复侧边栏折叠状态
      if (localStorage.getItem('hw_nav_collapsed') === '1') {
        document.body.classList.add('nav-collapsed');
        const btn = document.getElementById('nav-collapse-btn');
        if (btn) btn.textContent = '\u00BB';
      }

      Modal.init();
      this.renderNav();
      this.navigate('overview');

      // 首次使用引导
      if (!localStorage.getItem('hw_onboarded')) {
        setTimeout(() => this.showOnboarding(), 400);
      }

      // 监听关闭模态框
      document.getElementById('modal-overlay').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) Modal.close();
      });

      // ESC 关闭 / 数字键切换模块（桌面端快捷键）
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          Modal.close();
          document.querySelector('.mobile-more-menu')?.classList.remove('show');
          document.getElementById('pick-overlay')?.classList.remove('show');
        }
        // 数字键 1-9、0 快速切换模块（0 = 第10个，输入框聚焦时忽略）
        if (/^[0-9]$/.test(e.key)) {
          const active = document.activeElement;
          const typing = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT' || active.isContentEditable);
          const modalOpen = document.getElementById('modal-overlay')?.classList.contains('show');
          if (!typing && !modalOpen) {
            const idx = e.key === '0' ? 9 : parseInt(e.key, 10) - 1;
            if (navLeaves()[idx]) this.navigate(navLeaves()[idx].id);
          }
        }
      });
    },

    // ---- 首次使用引导 ----
    showOnboarding() {
      const data = Store.get();
      const bodyHtml = `
        <div style="text-align:center;padding:8px 0 4px;">
          <div style="font-size:2.6rem;">\u{1F44B}</div>
          <div class="text-bold" style="font-size:1.1rem;margin:6px 0 2px;">欢迎使用班主任工作台</div>
          <div class="text-sm text-secondary">${Utils.escapeHtml(data.meta.className || '')} \u00B7 数据保存在本机浏览器，不上传任何服务器</div>
        </div>
        <div style="margin-top:14px;">
          <div class="setting-row"><span>\u{1F3E0} <b>概览页</b>看全局：考勤、任务、生日、值日一目了然</span></div>
          <div class="setting-row"><span>\u{1F4C5} <b>考勤页</b>点学生头像轮换状态：到校\u2192迟到\u2192缺勤</span></div>
          <div class="setting-row"><span>\u{1F4E9} <b>请假页</b>登记请假条，支持勾选批量审批</span></div>
          <div class="setting-row"><span>\u{1F4DD} <b>作业页</b>创建收作业任务，未交名单一键催交</span></div>
          <div class="setting-row"><span>\u{1F3B2} <b>学生页</b>随机点名：点1人/3人/5人，可排除已点</span></div>
          <div class="setting-row"><span>\u2699\uFE0F <b>设置页</b>换主题、编辑班级口号、多班切换</span></div>
        </div>
        <div class="text-sm text-secondary mt-2" style="background:var(--warning-light);padding:8px 12px;border-radius:8px;color:#92400e;">
          \u26A0\uFE0F 重要：数据仅存于浏览器，请每周到"设置\u2192导出JSON"备份一次
        </div>
        <div class="text-sm text-secondary mt-2">\u{1F4F1} 手机使用：把此文件发到手机（微信/邮件），用浏览器打开即可，界面自动适配。电脑端可按数字键 1-9 快速切换模块。</div>
      `;
      const footerHtml = `
        <button class="btn btn-primary" style="width:100%;" onclick="localStorage.setItem('hw_onboarded','1');Modal.close()">\u{1F680} 开始使用</button>
      `;
      Modal.open('', bodyHtml, footerHtml);
    },

    // ---- 侧边栏折叠 ----
    toggleNavCollapse() {
      document.body.classList.toggle('nav-collapsed');
      const collapsed = document.body.classList.contains('nav-collapsed');
      localStorage.setItem('hw_nav_collapsed', collapsed ? '1' : '0');
      const btn = document.getElementById('nav-collapse-btn');
      if (btn) btn.textContent = collapsed ? '\u00BB' : '\u00AB';
    },

    // ---- 学校 Logo 上传 ----
    uploadLogo(input) {
      const file = input.files[0];
      if (!file) return;
      if (!/^image\//.test(file.type)) { Toast.show('请选择图片文件'); return; }
      const reader = new FileReader();
      reader.onload = (e) => {
        // 压缩为 96x96 以控制 localStorage 体积
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const size = 96;
          canvas.width = size; canvas.height = size;
          const ctx = canvas.getContext('2d');
          // 含透明背景的 PNG 用 padding 保持比例
          const scale = Math.min(size / img.width, size / img.height);
          const w = img.width * scale, h = img.height * scale;
          ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
          const dataUrl = canvas.toDataURL('image/png');
          try {
            localStorage.setItem('hw_logo', dataUrl);
            this.renderNav();
            Toast.show('学校 Logo 已更新');
          } catch (err) {
            Toast.show('保存失败，存储空间不足');
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    },

    removeLogo() {
      if (!confirm('移除学校 Logo，恢复默认图标？')) return;
      localStorage.removeItem('hw_logo');
      this.renderNav();
      Toast.show('已恢复默认');
      this.navigate('settings');
    },

    renderNav() {
      // 桌面侧边栏
      const sidebar = document.querySelector('.sidebar .nav-list');
      if (sidebar) {
        const coreOpen = localStorage.getItem('hw_core_open') !== '0';
        sidebar.innerHTML = visibleNavItems().map(item => {
          if (item.group) {
            const children = coreChildren();
            return `<li class="nav-group">
              <button class="nav-item nav-group-toggle ${currentView === 'core' ? 'active' : ''}" data-view="core" onclick="App.navigate('core')" title="${item.label}">
                <span class="icon">${item.icon}</span><span class="nav-label-text"> ${item.label}</span>
                <span class="nav-caret ${coreOpen ? 'open' : ''}" onclick="event.stopPropagation();App.toggleCoreNav()">&#9662;</span>
              </button>
              <ul class="sub-nav ${coreOpen ? 'show' : ''}">
                ${children.map(c => `<li><button class="nav-item sub-item ${currentView === c.id ? 'active' : ''}" data-view="${c.id}" onclick="App.navigate('${c.id}')">${c.label}</button></li>`).join('')}
              </ul>
            </li>`;
          }
          return `<li><button class="nav-item ${currentView === item.id ? 'active' : ''}" data-view="${item.id}" onclick="App.navigate('${item.id}')" title="${item.label}">
            <span class="icon">${item.icon}</span><span class="nav-label-text"> ${item.label}</span>
          </button></li>`;
        }).join('');
      }

      // 班级信息（点击可切换班级）+ 学校Logo
      const data = Store.get();
      if (data && data.meta) {
        const reg = Store.getRegistry();
        const logoEl = document.getElementById('sidebar-logo');
        if (logoEl) {
          const logoImg = localStorage.getItem('hw_logo');
          logoEl.innerHTML = logoImg
            ? `<img src="${logoImg}" alt="校徽" class="school-logo"><span>${data.meta.className || '班主任工作台'}</span>`
            : `<span class="icon">\u{1F3EB}</span><span>班主任工作台</span>`;
        }
        const headerSub = document.querySelector('.sidebar-header .subtitle');
        if (headerSub) {
          headerSub.innerHTML = `<span class="class-switcher" onclick="App.openClassSwitcher()" title="点击切换班级">
            ${Utils.escapeHtml(data.meta.className || '')} \u00B7 ${data.students.length}人
            ${reg.length > 1 ? '<span class="switcher-badge">\u21C4</span>' : ''}
          </span>`;
        }
        // 更新页面标题
        document.title = `${data.meta.className || '班级'} \u00B7 班主任工作台`;
      }

      // 手机底部导航
      const mobileNav = document.querySelector('.mobile-nav-list');
      if (mobileNav) {
        const visible = navLeaves().slice(0, MOBILE_NAV_VISIBLE);
        mobileNav.innerHTML = visible.map(item => `
          <li><button class="mobile-nav-item" data-view="${item.id}" onclick="App.navigate('${item.id}')">
            <span class="icon">${item.icon}</span> ${item.label}
          </button></li>
        `).join('') + `
          <li><button class="mobile-nav-item" onclick="App.toggleMoreMenu()">
            <span class="icon">\u{2630}</span> 更多
          </button></li>
        `;
      }

      // 手机更多菜单
      const moreMenu = document.querySelector('.mobile-more-menu');
      if (moreMenu) {
        const rest = navLeaves().slice(MOBILE_NAV_VISIBLE);
        moreMenu.innerHTML = `<div class="mobile-more-grid">
          ${rest.map(item => `
            <button class="mobile-more-item" onclick="App.navigate('${item.id}');App.toggleMoreMenu(false)">
              <span class="icon">${item.icon}</span> ${item.label}
            </button>
          `).join('')}
        </div>`;
      }
    },

    navigate(view) {
      currentView = view;
      const content = document.getElementById('content');
      if (!content) return;

      const item = findNavLeaf(view);
      const header = document.getElementById('main-header');
      if (header && item) {
        header.innerHTML = `
          <div>
            <div class="main-title"><span class="icon">${item.icon}</span>${item.label}</div>
          </div>
          <div class="main-subtitle">${Utils.today()}</div>
        `;
      }

      const renderFn = Views[view];
      content.innerHTML = renderFn ? Views[view]() : '<div class="empty-state">视图不存在</div>';

      // 图表视图：渲染后绘制
      if (['core', 'core-dropout', 'core-comm', 'core-safety'].includes(view)) {
        setTimeout(() => this.drawCoreCharts(), 40);
      }

      // 更新导航高亮
      document.querySelectorAll('.nav-item, .mobile-nav-item').forEach(el => {
        el.classList.toggle('active', el.dataset.view === view);
      });

      // 关闭移动端菜单
      document.querySelector('.mobile-more-menu')?.classList.remove('show');

      // 滚动到顶部
      window.scrollTo(0, 0);
    },

    toggleMoreMenu(force) {
      const menu = document.querySelector('.mobile-more-menu');
      if (!menu) return;
      if (force === false) menu.classList.remove('show');
      else menu.classList.toggle('show');
    },

    // ---- 学生 ----
    studentFilter(val) {
      currentStudentFilter = val;
      clearTimeout(this._filterTimer);
      this._filterTimer = setTimeout(() => this.navigate('students'), 200);
    },

    toggleStarredFilter() {
      currentStudentStarredOnly = !currentStudentStarredOnly;
      this.navigate('students');
    },

    toggleStar(id) {
      Store.update(data => {
        const s = data.students.find(x => x.id === id);
        if (s) s.starred = !s.starred;
      });
      this.navigate('students');
    },

    openStudentModal(id) {
      const data = Store.get();
      const s = id ? data.students.find(x => x.id === id) : {};
      const customFields = (data.meta.settings && data.meta.settings.customFields) || [];

      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">姓名 *</label>
          <input type="text" class="input" id="s-name" value="${Utils.escapeHtml(s.name || '')}">
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">学号</label><input type="text" class="input" id="s-sid" value="${Utils.escapeHtml(s.studentId || '')}"></div>
          <div class="form-group"><label class="form-label">性别</label>
            <select class="select" id="s-gender"><option value="">请选择</option><option value="男" ${s.gender==='男'?'selected':''}>男</option><option value="女" ${s.gender==='女'?'selected':''}>女</option></select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">生日 (月-日)</label><input type="text" class="input" id="s-birthday" value="${Utils.escapeHtml(s.birthday || '')}" placeholder="如: 08-25"></div>
          <div class="form-group"><label class="form-label">学生电话</label><input type="text" class="input" id="s-phone" value="${Utils.escapeHtml(s.phone || '')}"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">宿舍</label><input type="text" class="input" id="s-dorm" value="${Utils.escapeHtml(s.dorm || '')}"></div>
          <div class="form-group"><label class="form-label">&nbsp;</label><div class="setting-row" style="border:none;padding:8px 0;"><span>重点关注 \u{2B50}</span><div class="switch ${s.starred ? 'on' : ''}" id="s-starred" onclick="this.classList.toggle('on')"></div></div></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">身高(cm)</label><input type="number" class="input" id="s-height" value="${Utils.escapeHtml(s.height || '')}" placeholder="如: 165"></div>
          <div class="form-group"><label class="form-label">视力</label><select class="select" id="s-vision"><option value="">请选择</option><option value="正常" ${s.vision==='正常'?'selected':''}>正常</option><option value="近视" ${s.vision==='近视'?'selected':''}>近视</option><option value="远视" ${s.vision==='远视'?'selected':''}>远视</option><option value="弱视" ${s.vision==='弱视'?'selected':''}>弱视</option></select></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">家长姓名</label><input type="text" class="input" id="s-pname" value="${Utils.escapeHtml(s.parentName || '')}"></div>
          <div class="form-group"><label class="form-label">家长电话</label><input type="text" class="input" id="s-pphone" value="${Utils.escapeHtml(s.parentPhone || '')}"></div>
        </div>
        <div class="form-group"><label class="form-label">家长职业</label>
          <input type="text" class="input" id="s-pjob" value="${Utils.escapeHtml(s.parentJob || '')}" placeholder="如: 医生 / 个体经营 / 务工" list="p-job-list">
          <datalist id="p-job-list">${['医生','教师','公务员','企业职员','个体经营','务工','务农','自由职业','其他'].map(j => `<option value="${j}">`).join('')}</datalist>
        </div>
        <div class="form-group"><label class="form-label">备注</label><textarea class="textarea" id="s-notes">${Utils.escapeHtml(s.notes || '')}</textarea></div>
        ${customFields.length > 0 ? '<div class="form-group"><label class="form-label">自定义字段</label></div>' : ''}
        ${customFields.map(f => `
          <div class="form-group"><label class="form-label">${Utils.escapeHtml(f)}</label>
            <input type="text" class="input" id="s-cf-${Utils.escapeHtml(f)}" value="${Utils.escapeHtml(s.customFields && s.customFields[f] || '')}">
          </div>
        `).join('')}
      `;

      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveStudent('${id || ''}')">保存</button>
      `;

      Modal.open(id ? '编辑学生' : '添加学生', bodyHtml, footerHtml);
    },

    saveStudent(id) {
      const data = Store.get();
      const name = document.getElementById('s-name').value.trim();
      if (!name) { Toast.show('请输入姓名'); return; }

      const customFields = (data.meta.settings && data.meta.settings.customFields) || [];
      const cfValues = {};
      customFields.forEach(f => {
        const el = document.getElementById('s-cf-' + f);
        if (el && el.value.trim()) cfValues[f] = el.value.trim();
      });

      const student = {
        name,
        studentId: document.getElementById('s-sid').value.trim(),
        gender: document.getElementById('s-gender').value,
        birthday: document.getElementById('s-birthday').value.trim(),
        phone: document.getElementById('s-phone').value.trim(),
        dorm: document.getElementById('s-dorm').value.trim(),
        height: document.getElementById('s-height').value.trim(),
        vision: document.getElementById('s-vision').value,
        starred: !!(document.getElementById('s-starred') && document.getElementById('s-starred').classList.contains('on')),
        parentName: document.getElementById('s-pname').value.trim(),
        parentPhone: document.getElementById('s-pphone').value.trim(),
        parentJob: document.getElementById('s-pjob').value.trim(),
        notes: document.getElementById('s-notes').value.trim()
      };
      if (Object.keys(cfValues).length > 0) student.customFields = cfValues;

      if (id) {
        const idx = data.students.findIndex(s => s.id === id);
        if (idx >= 0) data.students[idx] = { ...data.students[idx], ...student };
      } else {
        student.id = Utils.uid();
        data.students.push(student);
      }

      Store.save(data);
      Modal.close();
      Toast.show('保存成功');
      this.navigate('students');
    },

    openStudentDetail(id) {
      const data = Store.get();
      const s = data.students.find(x => x.id === id);
      if (!s) return;

      const today = Utils.today();
      const todayAtt = data.attendance[today] || { present: [], absent: [], late: [] };
      let attStatus = '未标记';
      if ((todayAtt.present || []).includes(id)) attStatus = '到校';
      else if ((todayAtt.late || []).includes(id)) attStatus = '迟到';
      else if ((todayAtt.absent || []).includes(id)) attStatus = '缺勤';

      const commLogs = (data.communicationLog || []).filter(l => l.studentName === s.name);

      // 历次成绩
      const exams = (data.exams || []).filter(e => e.scores && e.scores[id] !== undefined)
        .sort((a, b) => new Date(b.date) - new Date(a.date));
      const scoreRows = exams.map(e => {
        const full = e.fullScore || 100;
        const v = Number(e.scores[id]);
        const tagCls = v >= full * 0.85 ? 'green' : v >= full * 0.6 ? 'blue' : 'red';
        return `<div class="setting-row"><span>${Utils.escapeHtml(e.name)} (${Utils.formatDate(e.date)})</span><span class="tag ${tagCls}">${v} / ${full}</span></div>`;
      }).join('');

      // 班干部职务
      const cadreTitles = (data.cadres || []).filter(c => c.studentId === id).map(c => c.title);
      // 荣誉
      const honorCount = (data.honors || []).filter(h => (h.students || []).includes(id)).length;
      const honorNames = (data.honors || []).filter(h => (h.students || []).includes(id)).map(h => h.title);

      // 学期考勤统计
      let attStat = { present: 0, late: 0, absent: 0 };
      Object.values(data.attendance || {}).forEach(day => {
        if ((day.present || []).includes(id)) attStat.present++;
        if ((day.late || []).includes(id)) attStat.late++;
        if ((day.absent || []).includes(id)) attStat.absent++;
      });
      const attDays = attStat.present + attStat.late + attStat.absent;
      const attRate = attDays > 0 ? Math.round((attStat.present + attStat.late) / attDays * 100) : null;

      // 请假历史
      const myLeaves = (data.leaves || []).filter(l => l.studentId === id).slice().reverse();

      // 操行积分明细
      const myPoints = (data.points || []).filter(p => p.studentId === id).slice().reverse();
      const pointSum = myPoints.reduce((a, p) => a + Number(p.delta || 0), 0);

      // 评语
      const comment = (data.comments || {})[id] || '';

      const bodyHtml = `
        <div class="flex gap-3 items-center mb-3">
          <div class="student-avatar" style="background:${Utils.avatarColor(s.name)};width:50px;height:50px;font-size:1.3rem;">${Utils.escapeHtml((s.name||'?').charAt(0))}</div>
          <div class="flex-1"><div class="text-bold" style="font-size:1.1rem;">${Utils.escapeHtml(s.name)} ${s.starred ? '\u{2B50}' : ''}</div><div class="text-sm text-secondary">${Utils.escapeHtml(s.studentId || '')}</div></div>
          <button class="btn btn-outline btn-sm" onclick="App.toggleStar('${id}');Modal.close()">${s.starred ? '取消星标' : '\u{2B50} 星标'}</button>
        </div>
        <div class="setting-row"><span>性别</span><span>${Utils.escapeHtml(s.gender || '-')}</span></div>
        ${s.birthday ? `<div class="setting-row"><span>生日</span><span>${Utils.escapeHtml(s.birthday)} <span class="tag ${Utils.daysUntilBirthday(s.birthday) === 0 ? 'red' : 'blue'}">${Utils.birthdayLabel(s.birthday)}</span></span></div>` : ''}
        <div class="setting-row"><span>学生电话</span><span>${Utils.escapeHtml(s.phone || '-')}</span></div>
        <div class="setting-row"><span>宿舍</span><span>${Utils.escapeHtml(s.dorm || '-')}</span></div>
        <div class="setting-row"><span>家长姓名</span><span>${Utils.escapeHtml(s.parentName || '-')}</span></div>
        <div class="setting-row"><span>家长电话</span><span>${s.parentPhone ? `<a class="contact-call" href="tel:${Utils.escapeHtml(s.parentPhone)}">${Utils.escapeHtml(s.parentPhone)}</a>` : '-'}</span></div>
        ${s.parentJob ? `<div class="setting-row"><span>家长职业</span><span>${Utils.escapeHtml(s.parentJob)}</span></div>` : ''}
        <div class="setting-row"><span>今日考勤</span><span class="tag ${attStatus === '到校' ? 'green' : attStatus === '缺勤' ? 'red' : attStatus === '迟到' ? 'orange' : 'gray'}">${attStatus}</span></div>
        ${attRate !== null ? `<div class="setting-row"><span>学期考勤</span><span class="text-sm">到${attStat.present} \u00B7 迟${attStat.late} \u00B7 缺${attStat.absent} <span class="tag ${attRate >= 95 ? 'green' : attRate >= 85 ? 'orange' : 'red'}">${attRate}%</span></span></div>` : ''}
        ${cadreTitles.length > 0 ? `<div class="setting-row"><span>班干部</span><span>${cadreTitles.map(t => `<span class="tag purple">${Utils.escapeHtml(t)}</span>`).join(' ')}</span></div>` : ''}
        ${honorCount > 0 ? `<div class="setting-row"><span>个人荣誉</span><span class="tag gold">\u{1F3C5} ${honorCount} 项</span></div>${honorNames.map(n => `<div class="text-sm text-secondary" style="padding:1px 0 1px 12px;">\u00B7 ${Utils.escapeHtml(n)}</div>`).join('')}` : ''}
        ${pointSum !== 0 || myPoints.length > 0 ? `<div class="setting-row"><span>操行积分</span><span class="tag ${pointSum >= 0 ? 'green' : 'red'}">${pointSum > 0 ? '+' : ''}${pointSum}分 (${myPoints.length}笔)</span></div>` : ''}
        ${s.notes ? `<div class="setting-row"><span>备注</span><span>${Utils.escapeHtml(s.notes)}</span></div>` : ''}
        ${s.customFields ? Object.entries(s.customFields).map(([k,v]) => `<div class="setting-row"><span>${Utils.escapeHtml(k)}</span><span>${Utils.escapeHtml(String(v))}</span></div>`).join('') : ''}
        ${myLeaves.length > 0 ? `<div class="card-header mt-3"><span>\u{1F4E9} 请假记录 (${myLeaves.length})</span></div>
          ${myLeaves.slice(0, 5).map(l => `<div class="setting-row"><span>${l.startDate}~${l.endDate} \u00B7 ${l.type}${l.reason ? '<br><span class="text-sm text-secondary">' + Utils.escapeHtml(l.reason) + '</span>' : ''}</span><span class="tag ${l.status === 'approved' ? 'green' : l.status === 'rejected' ? 'red' : 'orange'}">${l.status === 'approved' ? '已批' : l.status === 'rejected' ? '已驳回' : '待批'}</span></div>`).join('')}` : ''}
        ${myPoints.length > 0 ? `<div class="card-header mt-3"><span>\u{1F4AF} 积分明细 (${myPoints.length})</span></div>
          ${myPoints.slice(0, 8).map(p => `<div class="setting-row"><span>${p.date} ${Utils.escapeHtml(p.reason || '')}</span><span class="tag ${p.delta >= 0 ? 'green' : 'red'}">${p.delta > 0 ? '+' : ''}${p.delta}</span></div>`).join('')}` : ''}
        ${scoreRows ? `<div class="card-header mt-3"><span>\u{1F4D8} 历次成绩 (${exams.length})</span></div>${scoreRows}` : ''}
        ${comment ? `<div class="card-header mt-3"><span>\u{1F4DD} 期末评语</span></div><div class="text-sm" style="line-height:1.8;padding:6px 0;">${Utils.escapeHtml(comment)}</div>` : ''}
        ${commLogs.length > 0 ? `<div class="card-header mt-3"><span>沟通记录 (${commLogs.length})</span></div>
          ${commLogs.map(l => `<div class="setting-row"><span>${Utils.formatDate(l.date)}</span><span>${Utils.escapeHtml(l.type)}: ${Utils.escapeHtml(l.content.substring(0,30))}...</span></div>`).join('')}` : ''}
      `;

      const footerHtml = `
        <button class="btn btn-outline" style="color:var(--danger);" onclick="App.deleteStudent('${id}')">删除</button>
        <button class="btn btn-outline" onclick="App.openCommModal('${Utils.escapeHtml(s.name)}')">记录沟通</button>
        <button class="btn btn-primary" onclick="App.openStudentModal('${id}')">编辑</button>
      `;

      Modal.open(`学生档案 \u00B7 ${Utils.escapeHtml(s.name)}`, bodyHtml, footerHtml);
    },

    deleteStudent(id) {
      if (!confirm('确认删除该学生？')) return;
      Store.update(data => {
        data.students = data.students.filter(s => s.id !== id);
      });
      Modal.close();
      Toast.show('已删除');
      this.navigate('students');
    },

    exportStudents() {
      const data = Store.get();
      const customFields = (data.meta.settings && data.meta.settings.customFields) || [];
      const headers = ['姓名','学号','性别','生日','电话','宿舍','重点关注','家长姓名','家长电话','备注', ...customFields];
      const csv = '\uFEFF' + headers.join(',') + '\n' +
        data.students.map(s => {
          const row = [
            s.name, s.studentId, s.gender, s.birthday, s.phone, s.dorm,
            s.starred ? '是' : '', s.parentName, s.parentPhone, s.notes,
            ...customFields.map(f => (s.customFields || {})[f] || '')
          ];
          return row.map(v => '"' + (v || '').toString().replace(/"/g, '""') + '"').join(',');
        }).join('\n');
      Utils.download(`${data.meta.className}_名单.csv`, csv, 'text/csv;charset=utf-8');
      Toast.show('已导出 CSV');
    },

    // ---- 考勤 ----
    setAttendanceDate(d) {
      currentAttendanceDate = d;
      this.navigate('attendance');
    },

    shiftAttendanceDate(offset) {
      currentAttendanceDate = Utils.shiftDate(currentAttendanceDate, offset);
      this.navigate('attendance');
    },

    cycleAttendance(studentId) {
      const date = currentAttendanceDate;
      // 先读取当前状态（在修改之前）
      const data = Store.get();
      const att = data.attendance[date] || { present: [], absent: [], late: [] };
      const wasPresent = (att.present || []).includes(studentId);
      const wasLate = (att.late || []).includes(studentId);
      const wasAbsent = (att.absent || []).includes(studentId);

      // 轮换: 未标记 -> 到校 -> 迟到 -> 缺勤 -> 未标记
      Store.update(d => {
        if (!d.attendance[date]) d.attendance[date] = { present: [], absent: [], late: [] };
        const a = d.attendance[date];
        a.present = (a.present || []).filter(id => id !== studentId);
        a.absent = (a.absent || []).filter(id => id !== studentId);
        a.late = (a.late || []).filter(id => id !== studentId);

        if (!wasPresent && !wasLate && !wasAbsent) {
          a.present.push(studentId);  // 未标记 -> 到校
        } else if (wasPresent) {
          a.late.push(studentId);     // 到校 -> 迟到
        } else if (wasLate) {
          a.absent.push(studentId);   // 迟到 -> 缺勤
        }
        // 缺勤 -> 未标记（已清空，不添加）
      });

      this.navigate('attendance');
    },

    markAllPresent() {
      const date = currentAttendanceDate;
      Store.update(data => {
        data.attendance[date] = {
          present: data.students.map(s => s.id),
          absent: [],
          late: []
        };
      });
      Toast.show('已全部标记为到校');
      this.navigate('attendance');
    },

    clearAttendance() {
      if (!confirm('清空当日考勤记录？')) return;
      const date = currentAttendanceDate;
      Store.update(data => { delete data.attendance[date]; });
      Toast.show('已清空');
      this.navigate('attendance');
    },

    // ---- 任务 ----
    openTaskModal(id) {
      const data = Store.get();
      const t = id ? (data.tasks || []).find(x => x.id === id) : {};
      const bodyHtml = `
        <div class="form-group"><label class="form-label">任务标题 *</label><input type="text" class="input" id="t-title" value="${Utils.escapeHtml(t.title || '')}"></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">优先级</label>
            <select class="select" id="t-priority">
              <option value="low" ${t.priority==='low'?'selected':''}>低</option>
              <option value="medium" ${t.priority==='medium'||!t.priority?'selected':''}>中</option>
              <option value="high" ${t.priority==='high'?'selected':''}>高</option>
            </select>
          </div>
          <div class="form-group"><label class="form-label">截止日期</label><input type="date" class="input" id="t-deadline" value="${t.deadline || ''}"></div>
        </div>
        <div class="form-group"><label class="form-label">分类</label>
          <select class="select" id="t-category">
            <option value="">请选择</option>
            ${['行政','教学','德育','安全','活动','其他'].map(c => `<option value="${c}" ${t.category===c?'selected':''}>${c}</option>`).join('')}
          </select>
        </div>
        <div class="form-group"><label class="form-label">备注</label><textarea class="textarea" id="t-note" style="min-height:60px;" placeholder="补充说明(可选)">${Utils.escapeHtml(t.note || '')}</textarea></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveTask('${id || ''}')">保存</button>
      `;
      Modal.open(id ? '编辑任务' : '新建任务', bodyHtml, footerHtml);
    },

    saveTask(id) {
      const title = document.getElementById('t-title').value.trim();
      if (!title) { Toast.show('请输入任务标题'); return; }
      const task = {
        title,
        priority: document.getElementById('t-priority').value,
        deadline: document.getElementById('t-deadline').value,
        category: document.getElementById('t-category').value,
        note: document.getElementById('t-note').value.trim()
      };
      Store.update(data => {
        if (!data.tasks) data.tasks = [];
        if (id) {
          const idx = data.tasks.findIndex(t => t.id === id);
          if (idx >= 0) data.tasks[idx] = { ...data.tasks[idx], ...task };
        } else {
          task.id = Utils.uid();
          task.status = 'pending';
          data.tasks.push(task);
        }
      });
      Modal.close();
      Toast.show('保存成功');
      this.navigate('tasks');
    },

    toggleTask(id) {
      Store.update(data => {
        const t = (data.tasks || []).find(x => x.id === id);
        if (t) t.status = t.status === 'done' ? 'pending' : 'done';
      });
      Toast.show('已更新');
      this.navigate(currentView);
    },

    deleteTask(id) {
      if (!confirm('删除该任务？')) return;
      Store.update(data => { data.tasks = (data.tasks || []).filter(t => t.id !== id); });
      Toast.show('已删除');
      this.navigate('tasks');
    },

    // ---- 沟通 ----
    openCommModal(studentName) {
      const data = Store.get();
      const bodyHtml = `
        <div class="form-group"><label class="form-label">学生 *</label>
          <select class="select" id="c-student">
            <option value="">请选择</option>
            ${data.students.map(s => `<option value="${Utils.escapeHtml(s.name)}" ${studentName===s.name?'selected':''}>${Utils.escapeHtml(s.name)}</option>`).join('')}
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">沟通方式</label>
            <select class="select" id="c-type">
              <option value="电话">电话</option>
              <option value="面谈">面谈</option>
              <option value="微信">微信</option>
              <option value="家访">家访</option>
              <option value="其他">其他</option>
            </select>
          </div>
          <div class="form-group"><label class="form-label">日期</label><input type="date" class="input" id="c-date" value="${Utils.today()}"></div>
        </div>
        <div class="form-group"><label class="form-label">沟通内容 *</label><textarea class="textarea" id="c-content" placeholder="记录沟通要点..."></textarea></div>
        <div class="setting-row"><span>需要后续跟进</span><div class="switch" id="c-follow" onclick="this.classList.toggle('on')"></div></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveComm()">保存</button>
      `;
      Modal.open('记录沟通', bodyHtml, footerHtml);
    },

    saveComm() {
      const studentName = document.getElementById('c-student').value;
      if (!studentName) { Toast.show('请选择学生'); return; }
      const content = document.getElementById('c-content').value.trim();
      if (!content) { Toast.show('请输入沟通内容'); return; }
      const log = {
        id: Utils.uid(),
        studentName,
        type: document.getElementById('c-type').value,
        date: document.getElementById('c-date').value,
        content,
        followUp: document.getElementById('c-follow').classList.contains('on')
      };
      Store.update(data => {
        if (!data.communicationLog) data.communicationLog = [];
        data.communicationLog.push(log);
      });
      Modal.close();
      Toast.show('已记录');
      this.navigate('communication');
    },

    deleteComm(id) {
      if (!confirm('删除该记录？')) return;
      Store.update(data => { data.communicationLog = (data.communicationLog || []).filter(l => l.id !== id); });
      Toast.show('已删除');
      this.navigate('communication');
    },

    // ---- 公告 ----
    openAnnModal() {
      const bodyHtml = `
        <div class="form-group"><label class="form-label">公告标题 *</label><input type="text" class="input" id="a-title"></div>
        <div class="form-group"><label class="form-label">公告内容 *</label><textarea class="textarea" id="a-content" style="min-height:120px;"></textarea></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveAnn()">发布</button>
      `;
      Modal.open('发布公告', bodyHtml, footerHtml);
    },

    saveAnn() {
      const title = document.getElementById('a-title').value.trim();
      if (!title) { Toast.show('请输入标题'); return; }
      const content = document.getElementById('a-content').value.trim();
      if (!content) { Toast.show('请输入内容'); return; }
      Store.update(data => {
        if (!data.announcements) data.announcements = [];
        data.announcements.push({ id: Utils.uid(), title, content, date: Utils.today() });
      });
      Modal.close();
      Toast.show('已发布');
      this.navigate('announcements');
    },

    deleteAnn(id) {
      if (!confirm('删除该公告？')) return;
      Store.update(data => { data.announcements = (data.announcements || []).filter(a => a.id !== id); });
      Toast.show('已删除');
      this.navigate('announcements');
    },

    // ---- 活动 ----
    openActModal(id) {
      const data = Store.get();
      const a = id ? (data.activities || []).find(x => x.id === id) : null;
      this._actPhotos = ((a && a.photos) || []).slice();
      const photos = this._actPhotos;
      const bodyHtml = `
        <div class="form-group"><label class="form-label">活动名称 *</label><input type="text" class="input" id="act-title" value="${Utils.escapeHtml(a ? a.title : '')}"></div>
        <div class="form-group"><label class="form-label">日期 *</label><input type="date" class="input" id="act-date" value="${a ? a.date : ''}"></div>
        <div class="form-group"><label class="form-label">描述</label><textarea class="textarea" id="act-desc">${Utils.escapeHtml(a ? a.description : '')}</textarea></div>
        <div class="form-group"><label class="form-label">活动照片 (自动压缩，最多6张)</label>
          <div class="flex gap-2 items-center flex-wrap">
            <button class="btn btn-outline btn-sm" onclick="document.getElementById('act-photo-file').click()">\u{1F4F7} 添加照片</button>
            <span class="text-sm text-secondary" id="act-photo-count">${photos.length} 张</span>
          </div>
          <div class="act-photos mt-2" id="act-photos">${photos.map(p => `<img src="${p}" class="act-photo">`).join('')}</div>
          <input type="file" id="act-photo-file" accept="image/*" style="display:none;" onchange="App.addActPhoto(this)">
          <div class="text-sm text-secondary mt-1">\u26A0\uFE0F \u7167\u7247\u5B58\u4E8E\u6D4F\u89C8\u5668\u672C\u5730\uFF0C\u5BB9\u91CF\u6709\u9650\u5EFA\u8BAE\u6BCF\u6B21\u5C11\u91CF\u4E0A\u4F20</div>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveAct('${id || ''}')">保存</button>
      `;
      Modal.open(id ? '编辑活动' : '添加活动', bodyHtml, footerHtml);
    },

    _actPhotos: [],

    addActPhoto(input) {
      const file = input.files[0];
      if (!file) return;
      if (this._actPhotos.length >= 6) { Toast.show('最多6张照片'); return; }
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          // 压缩到最大 480px 边、JPEG 0.7 质量
          const max = 480;
          const scale = Math.min(max / img.width, max / img.height, 1);
          const canvas = document.createElement('canvas');
          canvas.width = Math.round(img.width * scale);
          canvas.height = Math.round(img.height * scale);
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
          this._actPhotos.push(dataUrl);
          const wrap = document.getElementById('act-photos');
          if (wrap) wrap.innerHTML = this._actPhotos.map(p => `<img src="${p}" class="act-photo">`).join('');
          const cnt = document.getElementById('act-photo-count');
          if (cnt) cnt.textContent = this._actPhotos.length + ' 张';
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
      input.value = '';
    },

    saveAct(id) {
      const title = document.getElementById('act-title').value.trim();
      if (!title) { Toast.show('请输入活动名称'); return; }
      const date = document.getElementById('act-date').value;
      if (!date) { Toast.show('请选择日期'); return; }
      const description = document.getElementById('act-desc').value.trim();
      const photos = this._actPhotos.slice();
      this._actPhotos = [];
      try {
        Store.update(data => {
          if (!data.activities) data.activities = [];
          if (id) {
            const a = data.activities.find(x => x.id === id);
            if (a) { a.title = title; a.date = date; a.description = description; if (photos.length) a.photos = photos; }
          } else {
            data.activities.push({ id: Utils.uid(), title, date, description, photos });
          }
        });
        Modal.close();
        Toast.show('已保存');
        this.navigate('activities');
      } catch (err) {
        Toast.show('保存失败，存储空间不足，请减少照片');
      }
    },

    deleteAct(id) {
      if (!confirm('删除该活动？')) return;
      Store.update(data => { data.activities = (data.activities || []).filter(a => a.id !== id); });
      Toast.show('已删除');
      this.navigate('activities');
    },

    // ---- 成绩管理 ----
    examStats(exam) {
      const values = Object.values(exam.scores || {}).filter(v => v !== null && v !== undefined && v !== '');
      if (values.length === 0) return { count: 0 };
      const nums = values.map(Number);
      const full = exam.fullScore || 100;
      const passLine = full * 0.6;
      const avg = Math.round(nums.reduce((a, b) => a + b, 0) / nums.length * 10) / 10;
      const passRate = Math.round(nums.filter(v => v >= passLine).length / nums.length * 100);
      return {
        count: nums.length,
        avg,
        passRate,
        max: Math.max(...nums),
        min: Math.min(...nums),
        excellent: nums.filter(v => v >= full * 0.85).length
      };
    },

    openExamModal() {
      const bodyHtml = `
        <div class="form-group"><label class="form-label">考试名称 *</label>
          <input type="text" class="input" id="e-name" placeholder="如: 第一次月考"></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">日期</label><input type="date" class="input" id="e-date" value="${Utils.today()}"></div>
          <div class="form-group"><label class="form-label">满分</label><input type="number" class="input" id="e-full" value="100" min="10" max="1000"></div>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveExam()">创建</button>
      `;
      Modal.open('新建考试', bodyHtml, footerHtml);
    },

    saveExam() {
      const name = document.getElementById('e-name').value.trim();
      if (!name) { Toast.show('请输入考试名称'); return; }
      const exam = {
        id: Utils.uid(),
        name,
        date: document.getElementById('e-date').value,
        fullScore: parseInt(document.getElementById('e-full').value, 10) || 100,
        scores: {}
      };
      Store.update(data => {
        if (!data.exams) data.exams = [];
        data.exams.push(exam);
      });
      Modal.close();
      Toast.show('考试已创建，请录入分数');
      this.openScoreEntry(exam.id);
    },

    deleteExam(id) {
      if (!confirm('删除该考试及全部分数？')) return;
      Store.update(data => { data.exams = (data.exams || []).filter(e => e.id !== id); });
      Toast.show('已删除');
      this.navigate('scores');
    },

    openScoreEntry(examId) {
      const data = Store.get();
      const exam = (data.exams || []).find(e => e.id === examId);
      if (!exam) return;

      const rows = data.students.map((s, i) => `
        <div class="score-entry-row">
          <span class="score-entry-name">${Utils.escapeHtml(s.name)}${s.starred ? ' \u{2B50}' : ''}</span>
          <input type="number" class="input score-entry-input" data-sid="${s.id}"
            value="${(exam.scores || {})[s.id] !== undefined ? exam.scores[s.id] : ''}"
            placeholder="-" min="0" max="${exam.fullScore}">
        </div>
      `).join('');

      const bodyHtml = `
        <div class="text-sm text-secondary mb-2">\u{1F4D8} ${Utils.escapeHtml(exam.name)} (满分 ${exam.fullScore}) — 直接输入分数，留空为缺考</div>
        <div class="score-entry-list">${rows}</div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveScores('${examId}')">保存全部</button>
      `;
      Modal.open('录入分数', bodyHtml, footerHtml);
    },

    saveScores(examId) {
      const inputs = document.querySelectorAll('.score-entry-input');
      Store.update(data => {
        const exam = (data.exams || []).find(e => e.id === examId);
        if (!exam) return;
        if (!exam.scores) exam.scores = {};
        inputs.forEach(inp => {
          const sid = inp.dataset.sid;
          const v = inp.value.trim();
          if (v === '') delete exam.scores[sid];
          else exam.scores[sid] = Math.max(0, Math.min(exam.fullScore, Number(v)));
        });
      });
      Modal.close();
      Toast.show('分数已保存');
      this.navigate('scores');
    },

    openExamStats(examId) {
      const data = Store.get();
      const exam = (data.exams || []).find(e => e.id === examId);
      if (!exam) return;
      const stats = this.examStats(exam);
      if (stats.count === 0) { Toast.show('暂无分数'); return; }

      const full = exam.fullScore || 100;
      // 分数段: 按满分比例分5档
      const buckets = [0, 0, 0, 0, 0];
      Object.values(exam.scores).forEach(v => {
        const n = Number(v);
        if (isNaN(n)) return;
        const ratio = n / full;
        if (ratio < 0.6) buckets[0]++;
        else if (ratio < 0.7) buckets[1]++;
        else if (ratio < 0.8) buckets[2]++;
        else if (ratio < 0.9) buckets[3]++;
        else buckets[4]++;
      });

      // 排名
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });
      const ranking = Object.entries(exam.scores)
        .map(([sid, v]) => ({ name: (studentById[sid] || {}).name || '?', score: Number(v), starred: !!(studentById[sid] || {}).starred }))
        .sort((a, b) => b.score - a.score);

      const top10 = ranking.slice(0, 10).map((r, i) => `
        <div class="setting-row">
          <span>${i + 1}. ${Utils.escapeHtml(r.name)}${r.starred ? ' \u{2B50}' : ''}</span>
          <span class="text-bold">${r.score}分</span>
        </div>
      `).join('');

      const bodyHtml = `
        <div class="flex gap-3 flex-wrap mb-3">
          <span class="tag blue">平均 ${stats.avg}分</span>
          <span class="tag green">及格率 ${stats.passRate}%</span>
          <span class="tag orange">优秀(85%+) ${stats.excellent}人</span>
          <span class="tag gray">参考 ${stats.count}人</span>
        </div>
        <div class="card-header"><span>\u{1F4CA} 分数段分布</span></div>
        <div class="chart-container" style="height:180px;"><canvas id="exam-chart"></canvas></div>
        <div class="card-header mt-3"><span>\u{1F3C6} 前十名</span></div>
        ${top10}
      `;

      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">关闭</button>
      `;
      Modal.open(`统计分析 - ${Utils.escapeHtml(exam.name)}`, bodyHtml, footerHtml);

      // 渲染柱状图
      setTimeout(() => {
        const ctx = document.getElementById('exam-chart');
        if (!ctx || typeof Chart === 'undefined') return;
        const maxRatio = Math.ceil(full / 10) * 10;
        new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ['不及格', '60-69%', '70-79%', '80-89%', '90-100%'],
            datasets: [{
              data: buckets,
              backgroundColor: ['#ef4444', '#f59e0b', '#eab308', '#22c55e', '#4f6df5'],
              borderRadius: 4
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0, font: { size: 10 } } }, x: { ticks: { font: { size: 10 } } } }
          }
        });
      }, 50);
    },

    // ---- 请假审批 ----
    openLeaveModal() {
      const data = Store.get();
      if (data.students.length === 0) { Toast.show('请先添加学生'); return; }
      const bodyHtml = `
        <div class="form-group"><label class="form-label">学生 *</label>
          <select class="select" id="lv-student">
            <option value="">请选择</option>
            ${data.students.map(s => `<option value="${s.id}">${Utils.escapeHtml(s.name)}</option>`).join('')}
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">类型</label>
            <select class="select" id="lv-type"><option value="病假">病假</option><option value="事假">事假</option><option value="其他">其他</option></select>
          </div>
          <div class="form-group"><label class="form-label">申请日期</label>
            <input type="date" class="input" id="lv-apply" value="${Utils.today()}"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">开始日期 *</label>
            <input type="date" class="input" id="lv-start" value="${Utils.today()}"></div>
          <div class="form-group"><label class="form-label">结束日期 *</label>
            <input type="date" class="input" id="lv-end" value="${Utils.today()}"></div>
        </div>
        <div class="form-group"><label class="form-label">事由</label>
          <textarea class="textarea" id="lv-reason" placeholder="如: 发烧38.5度，家长来电请假"></textarea></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveLeave()">保存</button>
      `;
      Modal.open('登记请假', bodyHtml, footerHtml);
    },

    saveLeave() {
      const studentId = document.getElementById('lv-student').value;
      if (!studentId) { Toast.show('请选择学生'); return; }
      const startDate = document.getElementById('lv-start').value;
      const endDate = document.getElementById('lv-end').value;
      if (!startDate || !endDate) { Toast.show('请选择起止日期'); return; }
      if (endDate < startDate) { Toast.show('结束日期不能早于开始日期'); return; }
      Store.update(d => {
        if (!d.leaves) d.leaves = [];
        d.leaves.push({
          id: Utils.uid(),
          studentId,
          type: document.getElementById('lv-type').value,
          startDate,
          endDate,
          reason: document.getElementById('lv-reason').value.trim(),
          applyDate: document.getElementById('lv-apply').value,
          status: 'pending'
        });
      });
      Modal.close();
      Toast.show('已登记，待审批');
      this.navigate('leave');
    },

    approveLeave(id) {
      Store.update(d => {
        const l = (d.leaves || []).find(x => x.id === id);
        if (l) l.status = 'approved';
      });
      Toast.show('\u2705 已批准（记得在考勤页标记缺勤）');
      this.navigate('leave');
    },

    rejectLeave(id) {
      Store.update(d => {
        const l = (d.leaves || []).find(x => x.id === id);
        if (l) l.status = 'rejected';
      });
      Toast.show('已驳回');
      this.navigate('leave');
    },

    toggleLeaveSelectAll() {
      const checks = document.querySelectorAll('.leave-check');
      const allChecked = Array.from(checks).every(c => c.checked);
      checks.forEach(c => { c.checked = !allChecked; });
    },

    batchApproveLeaves() {
      const ids = Array.from(document.querySelectorAll('.leave-check:checked')).map(c => c.value);
      if (ids.length === 0) { Toast.show('请先勾选要审批的请假条'); return; }
      if (!confirm(`批量通过 ${ids.length} 条请假申请？`)) return;
      Store.update(d => {
        (d.leaves || []).forEach(l => { if (ids.includes(l.id)) l.status = 'approved'; });
      });
      Toast.show(`\u2705 已批量通过 ${ids.length} 条（记得在考勤页标记缺勤）`);
      this.navigate('leave');
    },

    batchRejectLeaves() {
      const ids = Array.from(document.querySelectorAll('.leave-check:checked')).map(c => c.value);
      if (ids.length === 0) { Toast.show('请先勾选要审批的请假条'); return; }
      if (!confirm(`批量驳回 ${ids.length} 条请假申请？`)) return;
      Store.update(d => {
        (d.leaves || []).forEach(l => { if (ids.includes(l.id)) l.status = 'rejected'; });
      });
      Toast.show(`已批量驳回 ${ids.length} 条`);
      this.navigate('leave');
    },

    deleteLeave(id) {
      if (!confirm('删除该请假记录？')) return;
      Store.update(d => { d.leaves = (d.leaves || []).filter(l => l.id !== id); });
      Toast.show('已删除');
      this.navigate('leave');
    },

    // ---- 作业收交 ----
    openHomeworkModal() {
      const bodyHtml = `
        <div class="form-row">
          <div class="form-group"><label class="form-label">科目</label>
            <input type="text" class="input" id="hw-subject" list="hw-subjects" placeholder="如: 数学">
            <datalist id="hw-subjects">${['语文','数学','英语','物理','化学','生物','政治','历史','地理','专业课','实训'].map(s => `<option value="${s}">`).join('')}</datalist>
          </div>
          <div class="form-group"><label class="form-label">截止日期</label>
            <input type="date" class="input" id="hw-deadline" value="${Utils.today()}"></div>
        </div>
        <div class="form-group"><label class="form-label">作业内容 *</label>
          <input type="text" class="input" id="hw-title" placeholder="如: 第三章练习册 P45-46"></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveHomework()">创建</button>
      `;
      Modal.open('新建收作业', bodyHtml, footerHtml);
    },

    saveHomework() {
      const title = document.getElementById('hw-title').value.trim();
      if (!title) { Toast.show('请输入作业内容'); return; }
      Store.update(d => {
        if (!d.homeworks) d.homeworks = [];
        d.homeworks.push({
          id: Utils.uid(),
          subject: document.getElementById('hw-subject').value.trim(),
          title,
          deadline: document.getElementById('hw-deadline').value,
          submitted: [],
          createdAt: Utils.today()
        });
      });
      Modal.close();
      Toast.show('收作业任务已创建');
      this.navigate('homework');
    },

    deleteHomework(id) {
      if (!confirm('删除该收作业任务？')) return;
      Store.update(d => { d.homeworks = (d.homeworks || []).filter(h => h.id !== id); });
      Toast.show('已删除');
      this.navigate('homework');
    },

    toggleHomeworkSubmit(hwId, studentId) {
      Store.update(d => {
        const hw = (d.homeworks || []).find(h => h.id === hwId);
        if (!hw) return;
        if (!hw.submitted) hw.submitted = [];
        const idx = hw.submitted.indexOf(studentId);
        if (idx >= 0) hw.submitted.splice(idx, 1);
        else hw.submitted.push(studentId);
      });
      this.navigate('homework');
    },

    markAllSubmitted(hwId) {
      Store.update(d => {
        const hw = (d.homeworks || []).find(h => h.id === hwId);
        if (hw) hw.submitted = d.students.map(s => s.id);
      });
      Toast.show('已全部标记为已交');
      this.navigate('homework');
    },

    copyRemindText(hwId) {
      const data = Store.get();
      const hw = (data.homeworks || []).find(h => h.id === hwId);
      if (!hw) return;
      const unsubmitted = data.students.filter(s => !(hw.submitted || []).includes(s.id));
      if (unsubmitted.length === 0) { Toast.show('全部已交齐'); return; }

      const text = `\u3010${data.meta.className} 交作业提醒\u3011\n` +
        `${hw.subject ? hw.subject + ' - ' : ''}${hw.title}\n` +
        `${hw.deadline ? '截止日期: ' + hw.deadline + '\n' : ''}` +
        `以下 ${unsubmitted.length} 位同学尚未提交:\n` +
        unsubmitted.map(s => s.name).join('、') +
        `\n请尽快交给课代表，谢谢配合!\u{1F64F}`;

      // 尝试复制到剪贴板
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
          Toast.show(`\u{1F4CB} 催交信息已复制，去粘贴到班级群吧`);
        }).catch(() => {
          this.showRemindModal(text);
        });
      } else {
        this.showRemindModal(text);
      }
    },

    showRemindModal(text) {
      const bodyHtml = `
        <div class="text-sm text-secondary mb-2">长按/全选复制以下催交信息，粘贴到班级群：</div>
        <textarea class="textarea" style="min-height:160px;" onclick="this.select()">${Utils.escapeHtml(text)}</textarea>
      `;
      const footerHtml = `<button class="btn btn-primary" onclick="Modal.close()">知道了</button>`;
      Modal.open('\u{1F4E3} 催交信息', bodyHtml, footerHtml);
    },

    // ---- 值日轮换 ----
    dutyGroupForWeek(offsetWeeks) {
      const data = Store.get();
      const duty = data.duty || {};
      const groups = duty.groups || [];
      if (groups.length === 0) return null;

      // 以 startDate 那一周的周一为基准计算周序号
      const start = duty.startDate || data.meta.createdAt || Utils.today();
      const startMonday = new Date(start);
      const sd = startMonday.getDay() === 0 ? 7 : startMonday.getDay();
      startMonday.setDate(startMonday.getDate() - sd + 1);
      startMonday.setHours(0, 0, 0, 0);

      const now = new Date();
      const monday = new Date(now);
      const nd = now.getDay() === 0 ? 7 : now.getDay();
      monday.setDate(now.getDate() - nd + 1);
      monday.setHours(0, 0, 0, 0);
      monday.setDate(monday.getDate() + offsetWeeks * 7);

      const weekIndex = Math.round((monday - startMonday) / (7 * 86400000));

      // 手动覆盖优先
      const override = (duty.overrides || {})[String(weekIndex)];
      if (override) {
        const g = groups.find(x => x.id === override);
        if (g) return { group: g, weekIndex };
      }
      const idx = ((weekIndex % groups.length) + groups.length) % groups.length;
      return { group: groups[idx], weekIndex };
    },

    openDutyAutoModal() {
      const data = Store.get();
      if (data.students.length === 0) { Toast.show('请先添加学生'); return; }
      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">分成几个值日组?</label>
          <input type="number" class="input" id="duty-group-count" value="4" min="2" max="10">
          <div class="text-sm text-secondary mt-1">将按名单顺序均分 ${data.students.length} 名学生（自动分组会清空现有分组）</div>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.autoDutyGroups()">生成分组</button>
      `;
      Modal.open('自动分组', bodyHtml, footerHtml);
    },

    autoDutyGroups() {
      const n = Math.max(2, Math.min(10, parseInt(document.getElementById('duty-group-count').value, 10) || 4));
      const data = Store.get();
      const cnNum = ['一','二','三','四','五','六','七','八','九','十'];
      Store.update(d => {
        if (!d.duty) d.duty = {};
        d.duty.groups = [];
        d.duty.startDate = d.duty.startDate || Utils.today();
        for (let i = 0; i < n; i++) {
          d.duty.groups.push({ id: Utils.uid(), name: `\u7B2C${cnNum[i] || i+1}\u7EC4`, members: [] });
        }
        data.students.forEach((s, i) => {
          d.duty.groups[i % n].members.push(s.id);
        });
      });
      Modal.close();
      Toast.show(`已分成 ${n} 组并开始轮换`);
      this.navigate('duty');
    },

    openDutyGroupModal(id) {
      const data = Store.get();
      const groups = (data.duty && data.duty.groups) || [];
      const g = id ? groups.find(x => x.id === id) : null;

      const memberSet = new Set(g ? g.members : []);
      const checkboxes = data.students.map(s => `
        <label class="duty-member-check">
          <input type="checkbox" value="${s.id}" ${memberSet.has(s.id) ? 'checked' : ''}>
          ${Utils.escapeHtml(s.name)}${s.starred ? ' \u{2B50}' : ''}
        </label>
      `).join('');

      const bodyHtml = `
        <div class="form-group"><label class="form-label">组名</label>
          <input type="text" class="input" id="dg-name" value="${Utils.escapeHtml(g ? g.name : '')}" placeholder="如: 第一组"></div>
        <div class="form-group"><label class="form-label">组员 (勾选)</label>
          <div class="duty-member-list">${checkboxes}</div>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveDutyGroup('${id || ''}')">保存</button>
      `;
      Modal.open(g ? '编辑值日组' : '新建值日组', bodyHtml, footerHtml);
    },

    saveDutyGroup(id) {
      const name = document.getElementById('dg-name').value.trim();
      if (!name) { Toast.show('请输入组名'); return; }
      const members = Array.from(document.querySelectorAll('.duty-member-check input:checked')).map(cb => cb.value);
      Store.update(d => {
        if (!d.duty) d.duty = {};
        if (!d.duty.groups) d.duty.groups = [];
        if (!d.duty.startDate) d.duty.startDate = Utils.today();
        if (id) {
          const g = d.duty.groups.find(x => x.id === id);
          if (g) { g.name = name; g.members = members; }
        } else {
          d.duty.groups.push({ id: Utils.uid(), name, members });
        }
      });
      Modal.close();
      Toast.show('已保存');
      this.navigate('duty');
    },

    deleteDutyGroup(id) {
      if (!confirm('删除该值日组？')) return;
      Store.update(d => {
        if (d.duty && d.duty.groups) {
          d.duty.groups = d.duty.groups.filter(g => g.id !== id);
        }
      });
      Toast.show('已删除');
      this.navigate('duty');
    },

    openDutyOverrideModal(offset) {
      const data = Store.get();
      const duty = data.duty || {};
      const groups = duty.groups || [];
      if (groups.length === 0) { Toast.show('请先创建值日组'); return; }
      const current = this.dutyGroupForWeek(offset);
      const label = offset === 0 ? '本周' : '下周';

      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">指定${label}值日组 (当前: ${current && current.group ? Utils.escapeHtml(current.group.name) : '无'})</label>
          <select class="select" id="do-group">
            ${groups.map(g => `<option value="${g.id}" ${current && current.group && current.group.id === g.id ? 'selected' : ''}>${Utils.escapeHtml(g.name)} (${g.members.length}人)</option>`).join('')}
          </select>
          <div class="text-sm text-secondary mt-1">调整只影响${label}，后续周次恢复自动轮换</div>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.setDutyOverride(${offset})">确定</button>
      `;
      Modal.open(`调整${label}值日`, bodyHtml, footerHtml);
    },

    setDutyOverride(offset) {
      const gid = document.getElementById('do-group').value;
      const info = this.dutyGroupForWeek(offset);
      if (!info) return;
      Store.update(d => {
        if (!d.duty) d.duty = {};
        if (!d.duty.overrides) d.duty.overrides = {};
        d.duty.overrides[String(info.weekIndex)] = gid;
      });
      Modal.close();
      Toast.show('已调整');
      this.navigate('duty');
    },

    editDutyContent() {
      const data = Store.get();
      const content = (data.duty && data.duty.content) || '扫地、擦黑板、倒垃圾、摆桌椅、关门窗';
      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">值日内容 (顿号分隔)</label>
          <textarea class="textarea" id="dc-content">${Utils.escapeHtml(content)}</textarea>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveDutyContent()">保存</button>
      `;
      Modal.open('值日内容', bodyHtml, footerHtml);
    },

    saveDutyContent() {
      const content = document.getElementById('dc-content').value.trim();
      Store.update(d => {
        if (!d.duty) d.duty = {};
        d.duty.content = content;
      });
      Modal.close();
      Toast.show('已保存');
      this.navigate('duty');
    },

    // ---- 班干部 ----
    openCadreModal(id, presetTitle) {
      const data = Store.get();
      const c = id ? (data.cadres || []).find(x => x.id === id) : null;
      const title = c ? c.title : (presetTitle || '');

      const bodyHtml = `
        <div class="form-group"><label class="form-label">职位名称 *</label>
          <input type="text" class="input" id="c-title" value="${Utils.escapeHtml(title)}" list="cadre-titles" placeholder="如: 班长">
          <datalist id="cadre-titles">
            ${['班长','副班长','团支书','学习委员','纪律委员','卫生委员','体育委员','文艺委员','宣传委员','生活委员'].map(t => `<option value="${t}">`).join('')}
          </datalist>
        </div>
        <div class="form-group"><label class="form-label">担任学生</label>
          <select class="select" id="c-student">
            <option value="">请选择</option>
            ${data.students.map(s => `<option value="${s.id}" ${c && c.studentId === s.id ? 'selected' : ''}>${Utils.escapeHtml(s.name)}</option>`).join('')}
          </select>
        </div>
        <div class="form-group"><label class="form-label">任职日期</label>
          <input type="date" class="input" id="c-date" value="${c ? c.electedDate : Utils.today()}"></div>
        <div class="form-group"><label class="form-label">备注 (推选情况等)</label>
          <input type="text" class="input" id="c-note" value="${Utils.escapeHtml(c ? c.note : '')}" placeholder="如: 全票通过"></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveCadre('${id || ''}')">保存</button>
      `;
      Modal.open(id ? '编辑班干部' : '任命班干部', bodyHtml, footerHtml);
    },

    saveCadre(id) {
      const title = document.getElementById('c-title').value.trim();
      if (!title) { Toast.show('请输入职位名称'); return; }
      const studentId = document.getElementById('c-student').value;
      const cadre = {
        title,
        studentId,
        electedDate: document.getElementById('c-date').value,
        note: document.getElementById('c-note').value.trim()
      };
      Store.update(d => {
        if (!d.cadres) d.cadres = [];
        if (id) {
          const idx = d.cadres.findIndex(c => c.id === id);
          if (idx >= 0) d.cadres[idx] = { ...d.cadres[idx], ...cadre };
        } else {
          cadre.id = Utils.uid();
          d.cadres.push(cadre);
        }
      });
      Modal.close();
      Toast.show('已保存');
      this.navigate('cadres');
    },

    deleteCadre(id) {
      if (!confirm('删除该班干部记录？')) return;
      Store.update(d => { d.cadres = (d.cadres || []).filter(c => c.id !== id); });
      Toast.show('已删除');
      this.navigate('cadres');
    },

    // ---- 荣誉墙 ----
    openHonorModal(id) {
      const data = Store.get();
      const h = id ? (data.honors || []).find(x => x.id === id) : null;
      const selected = new Set(h ? (h.students || []) : []);

      const studentChecks = data.students.map(s => `
        <label class="duty-member-check">
          <input type="checkbox" value="${s.id}" ${selected.has(s.id) ? 'checked' : ''}>
          ${Utils.escapeHtml(s.name)}
        </label>
      `).join('');

      const bodyHtml = `
        <div class="form-group"><label class="form-label">荣誉名称 *</label>
          <input type="text" class="input" id="h-title" value="${Utils.escapeHtml(h ? h.title : '')}" placeholder="如: 校运会团体第一名"></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">等级</label>
            <select class="select" id="h-level">
              ${['班级','校级','区县级','市级','省级','国家级'].map(l => `<option value="${l}" ${h && h.level === l ? 'selected' : ''}>${l}</option>`).join('')}
            </select>
          </div>
          <div class="form-group"><label class="form-label">类型</label>
            <select class="select" id="h-type">
              <option value="团体" ${h && h.type === '团体' ? 'selected' : ''}>团体</option>
              <option value="个人" ${!h || h.type === '个人' ? 'selected' : ''}>个人</option>
            </select>
          </div>
        </div>
        <div class="form-group"><label class="form-label">获得日期</label>
          <input type="date" class="input" id="h-date" value="${h ? h.date : Utils.today()}"></div>
        <div class="form-group"><label class="form-label">相关学生 (个人荣誉勾选本人，团体可选)</label>
          <div class="duty-member-list">${studentChecks}</div>
        </div>
        <div class="form-group"><label class="form-label">描述</label>
          <textarea class="textarea" id="h-desc" placeholder="获奖详情...">${Utils.escapeHtml(h ? h.description : '')}</textarea></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveHonor('${id || ''}')">保存</button>
      `;
      Modal.open(id ? '编辑荣誉' : '记录荣誉', bodyHtml, footerHtml);
    },

    saveHonor(id) {
      const title = document.getElementById('h-title').value.trim();
      if (!title) { Toast.show('请输入荣誉名称'); return; }
      const students = Array.from(document.querySelectorAll('.duty-member-list input:checked')).map(cb => cb.value);
      const honor = {
        title,
        level: document.getElementById('h-level').value,
        type: document.getElementById('h-type').value,
        date: document.getElementById('h-date').value,
        students,
        description: document.getElementById('h-desc').value.trim()
      };
      Store.update(d => {
        if (!d.honors) d.honors = [];
        if (id) {
          const idx = d.honors.findIndex(x => x.id === id);
          if (idx >= 0) d.honors[idx] = { ...d.honors[idx], ...honor };
        } else {
          honor.id = Utils.uid();
          d.honors.push(honor);
        }
      });
      Modal.close();
      Toast.show('已记录');
      this.navigate('honors');
    },

    deleteHonor(id) {
      if (!confirm('删除该荣誉记录？')) return;
      Store.update(d => { d.honors = (d.honors || []).filter(h => h.id !== id); });
      Toast.show('已删除');
      this.navigate('honors');
    },

    // ---- 课程表 ----
    setTTSize(dimension, value) {
      const v = Math.max(4, Math.min(14, parseInt(value, 10) || 9));
      Store.update(d => {
        if (!d.timetable) d.timetable = { rows: 9, weekend: false, grid: {} };
        d.timetable.rows = v;
      });
      this.navigate('timetable');
    },

    toggleTTWeekend() {
      Store.update(d => {
        if (!d.timetable) d.timetable = { rows: 9, weekend: false, grid: {} };
        d.timetable.weekend = !d.timetable.weekend;
      });
      this.navigate('timetable');
    },

    editTTCell(r, c) {
      const data = Store.get();
      const tt = data.timetable || { grid: {} };
      const key = `${r}-${c}`;
      const current = (tt.grid || {})[key] || '';

      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">课程名称</label>
          <input type="text" class="input" id="tt-val" value="${Utils.escapeHtml(current)}" placeholder="如: 语文 / 数学 / 体育" list="tt-common">
          <datalist id="tt-common">
            ${['语文','数学','英语','物理','化学','生物','政治','历史','地理','体育','音乐','美术','班会','自习','实训'].map(c2 => `<option value="${c2}">`).join('')}
          </datalist>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" style="color:var(--danger);" onclick="App.saveTTCell(${r}, ${c}, true)">清空</button>
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveTTCell(${r}, ${c}, false)">保存</button>
      `;
      Modal.open('编辑课程', bodyHtml, footerHtml);
    },

    saveTTCell(r, c, clear) {
      const val = clear ? '' : document.getElementById('tt-val').value.trim();
      Store.update(d => {
        if (!d.timetable) d.timetable = { rows: 9, weekend: false, grid: {} };
        if (!d.timetable.grid) d.timetable.grid = {};
        const key = `${r}-${c}`;
        if (val) d.timetable.grid[key] = val;
        else delete d.timetable.grid[key];
      });
      Modal.close();
      this.navigate('timetable');
    },

    clearTimetable() {
      if (!confirm('清空全部课程？')) return;
      Store.update(d => {
        if (d.timetable) d.timetable.grid = {};
      });
      Toast.show('已清空');
      this.navigate('timetable');
    },

    // ---- 操行积分 ----
    openPointModal() {
      const data = Store.get();
      if (data.students.length === 0) { Toast.show('请先添加学生'); return; }
      const bodyHtml = `
        <div class="form-group"><label class="form-label">学生 *</label>
          <select class="select" id="p-student">
            <option value="">请选择</option>
            ${data.students.map(s => `<option value="${s.id}">${Utils.escapeHtml(s.name)}</option>`).join('')}
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">分值 * (正=加分 负=减分)</label>
            <input type="number" class="input" id="p-delta" placeholder="如: 2 或 -5"></div>
          <div class="form-group"><label class="form-label">日期</label>
            <input type="date" class="input" id="p-date" value="${Utils.today()}"></div>
        </div>
        <div class="form-group"><label class="form-label">事由</label>
          <input type="text" class="input" id="p-reason" list="p-reasons" placeholder="如: 课堂积极发言">
          <datalist id="p-reasons">
            ${['课堂积极发言','作业优秀','竞赛获奖','好人好事','帮助同学','迟到','旷课','违纪','宿舍卫生差','作业未交'].map(r => `<option value="${r}">`).join('')}
          </datalist>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.savePoint()">保存</button>
      `;
      Modal.open('记录加减分', bodyHtml, footerHtml);
    },

    savePoint() {
      const studentId = document.getElementById('p-student').value;
      if (!studentId) { Toast.show('请选择学生'); return; }
      const delta = parseInt(document.getElementById('p-delta').value, 10);
      if (isNaN(delta) || delta === 0) { Toast.show('请输入非零分值'); return; }
      Store.update(d => {
        if (!d.points) d.points = [];
        d.points.push({
          id: Utils.uid(),
          studentId,
          delta,
          reason: document.getElementById('p-reason').value.trim(),
          date: document.getElementById('p-date').value
        });
      });
      Modal.close();
      Toast.show(delta > 0 ? `\u{1F44D} 已加 ${delta} 分` : `已减 ${-delta} 分`);
      this.navigate('points');
    },

    deletePoint(id) {
      if (!confirm('删除该积分记录？')) return;
      Store.update(d => { d.points = (d.points || []).filter(p => p.id !== id); });
      Toast.show('已删除');
      this.navigate('points');
    },

    exportPoints() {
      const data = Store.get();
      const logs = data.points || [];
      if (logs.length === 0) { Toast.show('暂无积分记录'); return; }
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });
      const totals = {};
      logs.forEach(p => { totals[p.studentId] = (totals[p.studentId] || 0) + Number(p.delta); });
      let txt = `\u{1F4AF} ${data.meta.className} 操行积分明细\n生成时间: ${Utils.today()}\n${'='.repeat(36)}\n\n【积分汇总】\n`;
      Object.entries(totals).sort((a, b) => b[1] - a[1]).forEach(([sid, sum], i) => {
        txt += `${i + 1}. ${(studentById[sid] || {}).name || '?'}: ${sum > 0 ? '+' : ''}${sum}分\n`;
      });
      txt += `\n【明细流水】\n`;
      logs.forEach(p => {
        txt += `${p.date} ${(studentById[p.studentId] || {}).name || '?'} ${p.delta > 0 ? '+' : ''}${p.delta}分 ${p.reason || ''}\n`;
      });
      Utils.download(`${data.meta.className}_操行积分.txt`, txt);
      Toast.show('已导出');
    },

    // ---- 宿舍管理 ----
    openDormCheckModal() {
      const data = Store.get();
      const dormSet = new Set(data.students.filter(s => s.dorm).map(s => s.dorm));
      const dorms = Array.from(dormSet).sort();
      if (dorms.length === 0) { Toast.show('暂无宿舍信息，请先在学生档案填写宿舍号'); return; }

      const bodyHtml = `
        <div class="form-row">
          <div class="form-group"><label class="form-label">宿舍 *</label>
            <select class="select" id="dc-dorm">${dorms.map(d2 => `<option value="${Utils.escapeHtml(d2)}">${Utils.escapeHtml(d2)}</option>`).join('')}</select>
          </div>
          <div class="form-group"><label class="form-label">得分 * (0-100)</label>
            <input type="number" class="input" id="dc-score" min="0" max="100" value="90"></div>
        </div>
        <div class="form-group"><label class="form-label">日期</label>
          <input type="date" class="input" id="dc-date" value="${Utils.today()}"></div>
        <div class="form-group"><label class="form-label">备注</label>
          <input type="text" class="input" id="dc-note" placeholder="如: 地面有头发、阳台杂物多"></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveDormCheck()">保存</button>
      `;
      Modal.open('记录卫生检查', bodyHtml, footerHtml);
    },

    saveDormCheck() {
      const score = parseInt(document.getElementById('dc-score').value, 10);
      if (isNaN(score) || score < 0 || score > 100) { Toast.show('请输入0-100的分数'); return; }
      Store.update(d => {
        if (!d.dormChecks) d.dormChecks = [];
        d.dormChecks.push({
          id: Utils.uid(),
          dorm: document.getElementById('dc-dorm').value,
          score,
          date: document.getElementById('dc-date').value,
          note: document.getElementById('dc-note').value.trim()
        });
      });
      Modal.close();
      Toast.show('已记录');
      this.navigate('dorm');
    },

    deleteDormCheck(id) {
      if (!confirm('删除该检查记录？')) return;
      Store.update(d => { d.dormChecks = (d.dormChecks || []).filter(c => c.id !== id); });
      Toast.show('已删除');
      this.navigate('dorm');
    },

    // ---- 班会计划 ----
    switchActivitiesTab(tab) {
      currentActivitiesTab = tab;
      this.navigate('activities');
    },

    switchCommTab(tab) {
      currentCommTab = tab;
      this.navigate('communication');
    },

    openMeetingModal(id) {
      const data = Store.get();
      const p = id ? (data.meetingPlans || []).find(x => x.id === id) : null;
      const bodyHtml = `
        <div class="form-row">
          <div class="form-group"><label class="form-label">周次 *</label>
            <input type="number" class="input" id="m-week" min="1" max="30" value="${p ? p.week : 1}"></div>
          <div class="form-group"><label class="form-label">日期 (可选)</label>
            <input type="date" class="input" id="m-date" value="${p ? p.date : ''}"></div>
        </div>
        <div class="form-group"><label class="form-label">班会主题 *</label>
          <input type="text" class="input" id="m-topic" value="${Utils.escapeHtml(p ? p.topic : '')}" placeholder="如: 开学收心、学风建设、感恩教育" list="m-topics">
          <datalist id="m-topics">
            ${['开学收心','学风建设','安全教育','心理健康','感恩教育','爱国主义','诚信考试','生涯规划','网络安全','防欺凌','劳动教育','期中总结'].map(t => `<option value="${t}">`).join('')}
          </datalist>
        </div>
        <div class="form-group"><label class="form-label">内容要点</label>
          <textarea class="textarea" id="m-content" placeholder="流程、素材、分工等">${Utils.escapeHtml(p ? p.content : '')}</textarea></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveMeeting('${id || ''}')">保存</button>
      `;
      Modal.open(id ? '编辑班会计划' : '添加班会计划', bodyHtml, footerHtml);
    },

    saveMeeting(id) {
      const week = parseInt(document.getElementById('m-week').value, 10);
      if (isNaN(week) || week < 1) { Toast.show('请输入有效周次'); return; }
      const topic = document.getElementById('m-topic').value.trim();
      if (!topic) { Toast.show('请输入班会主题'); return; }
      const plan = {
        week,
        topic,
        date: document.getElementById('m-date').value,
        content: document.getElementById('m-content').value.trim()
      };
      Store.update(d => {
        if (!d.meetingPlans) d.meetingPlans = [];
        if (id) {
          const idx = d.meetingPlans.findIndex(p => p.id === id);
          if (idx >= 0) d.meetingPlans[idx] = { ...d.meetingPlans[idx], ...plan };
        } else {
          plan.id = Utils.uid();
          plan.status = 'planned';
          d.meetingPlans.push(plan);
        }
      });
      Modal.close();
      Toast.show('已保存');
      this.navigate('activities');
    },

    toggleMeetingStatus(id) {
      Store.update(d => {
        const p = (d.meetingPlans || []).find(x => x.id === id);
        if (p) p.status = p.status === 'done' ? 'planned' : 'done';
      });
      this.navigate('activities');
    },

    deleteMeeting(id) {
      if (!confirm('删除该班会计划？')) return;
      Store.update(d => { d.meetingPlans = (d.meetingPlans || []).filter(p => p.id !== id); });
      Toast.show('已删除');
      this.navigate('activities');
    },

    // ---- 学生评语批量生成 ----
    generateComment(s, data) {
      const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

      // 出勤统计
      const att = { present: 0, late: 0, absent: 0 };
      Object.values(data.attendance || {}).forEach(day => {
        if ((day.present || []).includes(s.id)) att.present++;
        if ((day.late || []).includes(s.id)) att.late++;
        if ((day.absent || []).includes(s.id)) att.absent++;
      });

      // 成绩统计
      const exams = (data.exams || []).filter(e => e.scores && e.scores[s.id] !== undefined)
        .sort((a, b) => new Date(a.date) - new Date(b.date));
      let scorePart = '';
      if (exams.length > 0) {
        const scores = exams.map(e => Number(e.scores[s.id]));
        const avg = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
        const trend = scores.length >= 2 ? scores[scores.length - 1] - scores[0] : 0;
        if (avg >= 90) {
          scorePart = pick([
            `学习上勤于钻研，各科成绩名列前茅，平均分达${avg}分，是同学们学习的榜样`,
            `学习态度端正、方法得当，${avg}分的平均成绩体现了扎实的功底`
          ]);
        } else if (avg >= 75) {
          scorePart = pick([
            `学习认真踏实，平均成绩${avg}分${trend > 0 ? '，且呈稳步上升趋势，值得肯定' : '，基础知识掌握较牢固'}`,
            `能按时完成学习任务，平均分${avg}分${trend > 0 ? '，进步明显' : '，学习状态稳定'}`
          ]);
        } else if (avg >= 60) {
          scorePart = pick([
            `学习上有一定自觉性，平均分${avg}分${trend > 0 ? '，较开学有明显进步，望继续保持' : '，但仍有较大提升空间，需加强薄弱学科'}`,
            `基础尚可（平均${avg}分），${trend > 0 ? '成绩稳步上升' : '若能投入更多时间钻研，成绩定能更上一层楼'}`
          ]);
        } else {
          scorePart = pick([
            `学习基础较薄弱（平均${avg}分），需要端正学习态度、夯实基础，遇到困难及时向老师和同学求助`,
            `本学期学习成绩有待提高（平均${avg}分），希望下学期制定学习计划，迎头赶上`
          ]);
        }
      }

      // 出勤句
      let attPart = '';
      if (att.absent >= 3) {
        attPart = `本学期缺勤${att.absent}次，需引起重视，保证出勤是学习的基本前提`;
      } else if (att.late >= 3) {
        attPart = `有迟到${att.late}次的情况，望养成守时习惯`;
      } else if (att.present > 0 && att.late === 0 && att.absent === 0) {
        attPart = pick(['出勤情况良好，从不迟到缺勤', '能坚持按时到校，纪律观念强']);
      }

      // 职务
      const cadreTitles = (data.cadres || []).filter(c => c.studentId === s.id).map(c => c.title);
      let rolePart = '';
      if (cadreTitles.length > 0) {
        rolePart = pick([
          `担任${cadreTitles.join('、')}期间认真负责，是老师的得力助手`,
          `作为${cadreTitles[0]}，工作尽心尽责，为班级建设贡献了力量`
        ]);
      }

      // 荣誉
      const honorCount = (data.honors || []).filter(h => (h.students || []).includes(s.id)).length;
      let honorPart = '';
      if (honorCount > 0) {
        honorPart = `本学期获得${honorCount}项荣誉，为班级争光`;
      }

      // 积分
      const pointSum = (data.points || []).filter(p => p.studentId === s.id)
        .reduce((a, p) => a + Number(p.delta || 0), 0);
      let pointPart = '';
      if (pointSum >= 10) pointPart = '操行表现突出，多次受到表扬加分';
      else if (pointSum <= -5) pointPart = '操行积分偏低，需加强自律意识';

      // 开场 + 结尾
      const opener = pick([
        `${s.name}同学：`,
        `该生本学期`
      ]);
      const closer = s.starred
        ? pick(['老师会持续关注你的成长，有困难随时来找老师，期待下学期更好的你！', '愿你敞开心扉、迎难而上，老师和同学们都是你坚实的后盾。'])
        : pick(['希望再接再厉，新学期取得更大进步！', '愿你戒骄戒躁、扬长补短，期待你更精彩的表现！', '望保持优点、改进不足，争做更优秀的自己！']);

      // 拼接
      const parts = [opener];
      if (scorePart) parts.push(scorePart + '。');
      if (rolePart) parts.push(rolePart + '。');
      if (honorPart) parts.push(honorPart + '。');
      if (attPart) parts.push(attPart + '。');
      if (pointPart) parts.push(pointPart + '。');
      parts.push(closer);
      return parts.join('');
    },

    openCommentsModal() {
      const data = Store.get();
      if (data.students.length === 0) { Toast.show('请先添加学生'); return; }
      const comments = data.comments || {};

      const rows = data.students.map(s => `
        <div class="comment-row">
          <div class="flex gap-2 items-center mb-1">
            <span class="text-bold">${Utils.escapeHtml(s.name)}</span>
            <button class="btn btn-outline btn-sm" onclick="App.regenerateComment('${s.id}')">\u{1F504} 重新生成</button>
            <span class="text-sm text-secondary" id="comment-len-${s.id}">${(comments[s.id] || '').length}字</span>
          </div>
          <textarea class="textarea" id="comment-${s.id}" oninput="App.autoSaveComment('${s.id}')" placeholder="点击左上角'重新生成'或直接在此编写...">${Utils.escapeHtml(comments[s.id] || '')}</textarea>
        </div>
      `).join('');

      const bodyHtml = `
        <div class="text-sm text-secondary mb-2">\u{1F4A1} 评语基于学生出勤、成绩、职务、荣誉、操行积分自动生成，可逐条修改。修改自动保存。</div>
        <div class="comment-list">${rows}</div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" style="color:var(--primary);" onclick="App.regenerateAllComments()">\u{1F504} 全部重新生成</button>
        <button class="btn btn-outline" onclick="Modal.close()">关闭</button>
        <button class="btn btn-primary" onclick="App.exportComments()">\u{1F4E5} 导出全部评语</button>
      `;
      Modal.open('\u{1F4DD} 期末评语生成', bodyHtml, footerHtml);
    },

    regenerateComment(sid) {
      const data = Store.get();
      const s = data.students.find(x => x.id === sid);
      if (!s) return;
      const text = this.generateComment(s, data);
      Store.update(d => {
        if (!d.comments) d.comments = {};
        d.comments[sid] = text;
      });
      const ta = document.getElementById('comment-' + sid);
      if (ta) {
        ta.value = text;
        const len = document.getElementById('comment-len-' + sid);
        if (len) len.textContent = text.length + '字';
      }
      Toast.show(`已为${s.name}重新生成`);
    },

    regenerateAllComments() {
      if (!confirm('将覆盖全部现有评语，重新生成？')) return;
      const data = Store.get();
      data.students.forEach(s => {
        const text = this.generateComment(s, data);
        const ta = document.getElementById('comment-' + s.id);
        if (ta) {
          ta.value = text;
          const len = document.getElementById('comment-len-' + s.id);
          if (len) len.textContent = text.length + '字';
        }
      });
      Store.update(d => {
        d.comments = {};
        data.students.forEach(s => { d.comments[s.id] = this.generateComment(s, data); });
      });
      Toast.show('已全部重新生成');
    },

    autoSaveComment(sid) {
      const ta = document.getElementById('comment-' + sid);
      if (!ta) return;
      const len = document.getElementById('comment-len-' + sid);
      if (len) len.textContent = ta.value.length + '字';
      clearTimeout(this._commentTimer);
      this._commentTimer = setTimeout(() => {
        Store.update(d => {
          if (!d.comments) d.comments = {};
          d.comments[sid] = ta.value;
        });
      }, 500);
    },

    exportComments() {
      const data = Store.get();
      const comments = data.comments || {};
      const has = data.students.some(s => (comments[s.id] || '').trim());
      if (!has) { Toast.show('请先生成评语'); return; }
      let txt = `\u{1F4DD} ${data.meta.className} 学生评语\n班主任: ${data.meta.teacher || '-'}\n生成日期: ${Utils.today()}\n${'='.repeat(36)}\n\n`;
      data.students.forEach(s => {
        const c = (comments[s.id] || '').trim();
        if (c) txt += `${s.name}（${s.studentId || ''}）\n${c}\n\n`;
      });
      Utils.download(`${data.meta.className}_学生评语.txt`, txt);
      Toast.show('已导出');
    },

    // ---- 班级成绩对比 ----
    openClassCompare() {
      // 读取所有班级数据
      const reg = Store.getRegistry();
      const current = Store.get();
      const curId = Store.currentId();
      if (reg.length < 2) {
        Toast.show('只有一个班级。请在"设置→班级管理"创建其他班级后，才能进行班级间对比');
        return;
      }

      // 收集所有班的考试 (按 名称+日期 匹配)
      const classExams = []; // {className, exams: [...]}
      reg.forEach(c => {
        let data = null;
        if (c.id === curId) {
          data = current;
        } else {
          try {
            const raw = localStorage.getItem('hw_class_data_' + c.id);
            if (raw) data = JSON.parse(raw);
          } catch (e) {}
        }
        if (data && (data.exams || []).length > 0) {
          classExams.push({ className: data.meta.className, exams: data.exams });
        }
      });

      if (classExams.length === 0) {
        Toast.show('暂无任何班级的考试数据');
        return;
      }

      // 找各班同名同日期的考试
      const refExams = classExams[0].exams;
      let bodyHtml = '';

      refExams.forEach(exam => {
        const matches = [];
        classExams.forEach(ce => {
          const m = ce.exams.find(e => e.name === exam.name && e.date === exam.date);
          if (m) matches.push({ className: ce.className, stats: this.examStats(m) });
        });
        if (matches.length < 2) return; // 只有一个班有这场考试，跳过

        // 排序: 按平均分
        matches.sort((a, b) => (b.stats.avg || 0) - (a.stats.avg || 0));
        const bestAvg = matches[0].stats.avg;
        const bestPass = matches.slice().sort((a, b) => (b.stats.passRate || 0) - (a.stats.passRate || 0))[0];

        bodyHtml += `
          <div class="card-header" style="margin-top:14px;">\u{1F4D8} ${Utils.escapeHtml(exam.name)} (${Utils.formatDate(exam.date)})</div>
          <div class="table-wrapper"><table class="data-table"><thead><tr><th>班级</th><th>平均分</th><th>及格率</th><th>优秀数</th><th>最高分</th><th>最低分</th><th>参考</th></tr></thead><tbody>
          ${matches.map(m => `
            <tr>
              <td>${Utils.escapeHtml(m.className)}${m.stats.avg === bestAvg ? ' \u{1F947}' : ''}</td>
              <td class="text-bold">${m.stats.avg}</td>
              <td>${m.stats.passRate}%${m.stats.passRate === bestPass.stats.passRate ? ' \u{1F3C6}' : ''}</td>
              <td>${m.stats.excellent}</td>
              <td>${m.stats.max}</td>
              <td>${m.stats.min}</td>
              <td>${m.stats.count}人</td>
            </tr>
          `).join('')}
          </tbody></table></div>
        `;
      });

      if (!bodyHtml) {
        bodyHtml = '<div class="empty-state"><div class="icon">\u{1F4CA}</div><div class="text">暂无多班同场考试<br><span class="text-sm">各班使用相同考试名称和日期录入后，即可在此对比</span></div></div>';
      }

      const footerHtml = `<button class="btn btn-outline" onclick="Modal.close()">关闭</button>`;
      Modal.open('\u{1F4CA} 班级成绩对比', bodyHtml, footerHtml);
    },

    // ---- 主页卡片详情面板 ----
    openHomeCard(type) {
      const data = Store.get();
      if (!data) return;
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });
      const nameOf = (id) => (studentById[id] || {}).name || '?';
      const today = Utils.today();

      let title = '', body = '', gotoView = '', gotoLabel = '\u524D\u5F80\u6A21\u5757';

      if (type === 'attendance') {
        const att = data.attendance[today] || { present: [], absent: [], late: [] };
        const todayLeaves = (data.leaves || []).filter(l => l.status !== 'rejected' && l.startDate <= today && l.endDate >= today);
        title = '\u{1F4C5} \u65E9\u8BFB\u8003\u52E4\u8BE6\u60C5';
        gotoView = 'attendance';
        body = `
          <div class="flex gap-2 flex-wrap mb-3">
            <span class="tag green">\u2705 \u5230\u6821 ${(att.present || []).length}</span>
            <span class="tag orange">\u23F1 \u8FDF\u5230 ${(att.late || []).length}</span>
            <span class="tag red">\u{1F6D1} \u7F3A\u52E4 ${(att.absent || []).length}</span>
            <span class="tag blue">\u{1F4E9} \u8BF7\u5047 ${todayLeaves.length}</span>
          </div>
          ${(att.late || []).length ? `<div class="card-header">\u8FDF\u5230\u540D\u5355</div><div class="flex gap-2 flex-wrap mb-2">${(att.late || []).map(id => `<span class="tag orange">${nameOf(id)}</span>`).join('')}</div>` : ''}
          ${(att.absent || []).length ? `<div class="card-header">\u7F3A\u52E4\u540D\u5355</div><div class="flex gap-2 flex-wrap mb-2">${(att.absent || []).map(id => `<span class="tag red">${nameOf(id)}</span>`).join('')}</div>` : ''}
          ${todayLeaves.length ? `<div class="card-header">\u4ECA\u65E5\u8BF7\u5047</div>${todayLeaves.map(l => `<div class="setting-row"><span>${nameOf(l.studentId)} \u00B7 ${l.type}</span><span class="text-sm text-secondary">${l.startDate}~${l.endDate} \u00B7 ${l.status === 'approved' ? '已批' : '待批'}</span></div>`).join('')}` : ''}
          <div class="chart-container mt-2" style="height:160px;"><canvas id="home-att-chart"></canvas></div>
        `;
      } else if (type === 'discipline') {
        const weekStart = Utils.shiftDate(today, -6);
        const weekPoints = (data.points || []).filter(p => p.date >= weekStart).slice().reverse();
        title = '\u{1F3AD} \u8BFE\u5802\u7EAA\u5F8B\uFF08\u672C\u5468\u64CD\u884C\u79EF\u5206\uFF09';
        gotoView = 'points';
        body = weekPoints.length ? weekPoints.map(p => `
          <div class="setting-row">
            <span>${p.date} \u00B7 ${nameOf(p.studentId)}</span>
            <span class="flex gap-2 items-center"><span class="text-sm text-secondary">${Utils.escapeHtml(p.reason || '')}</span>
            <span class="tag ${p.delta >= 0 ? 'green' : 'red'}">${p.delta > 0 ? '+' : ''}${p.delta}</span></span>
          </div>`).join('') : '<div class="empty-state"><div class="text">\u672C\u5468\u6682\u65E0\u7EAA\u5F8B\u8BB0\u5F55</div></div>';
      } else if (type === 'homework') {
        title = '\u{1F4DD} \u4F5C\u4E1A\u6536\u7F34\u7EDF\u8BA1';
        gotoView = 'homework';
        body = (data.homeworks || []).slice(0, 5).map(hw => {
          const sub = (hw.submitted || []).length;
          const un = data.students.filter(s => !(hw.submitted || []).includes(s.id));
          const rate = data.students.length ? Math.round(sub / data.students.length * 100) : 0;
          return `<div style="padding:8px 0;border-bottom:1px solid var(--border);">
            <div class="flex gap-2 items-center justify-between">
              <span><span class="tag blue">${Utils.escapeHtml(hw.subject || '通用')}</span> ${Utils.escapeHtml(hw.title)}</span>
              <span class="tag ${rate === 100 ? 'green' : rate >= 60 ? 'orange' : 'red'}">${sub}/${data.students.length} (${rate}%)</span>
            </div>
            ${un.length ? `<div class="text-sm mt-1" style="color:var(--danger);">\u672A\u4EA4: ${un.map(s => s.name).join('、')}</div>` : '<div class="text-sm mt-1" style="color:var(--success);">\u2705 \u5168\u90E8\u4EA4\u9F50</div>'}
          </div>`;
        }).join('') || '<div class="empty-state"><div class="text">\u6682\u65E0\u6536\u4F5C\u4E1A\u4EFB\u52A1</div></div>';
      } else if (type === 'patrol') {
        title = '\u{1F6E1}\u{FE0F} \u8BFE\u95F4\u5DE1\u67E5 / \u5DE5\u4F5C\u7559\u75D5';
        gotoView = 'tasks';
        const logs = (data.journal || []).slice(-10).reverse();
        body = logs.map(l => `<div class="setting-row">
          <span><span class="tag ${l.tag === '安全' ? 'red' : l.tag === '教学' ? 'blue' : 'gray'}">${Utils.escapeHtml(l.tag || '其他')}</span> ${Utils.formatDate(l.date)}<br><span class="text-sm">${Utils.escapeHtml(l.content)}</span></span>
        </div>`).join('') || '<div class="empty-state"><div class="text">\u6682\u65E0\u5DE1\u67E5\u8BB0\u5F55</div></div>';
      } else if (type === 'meetings') {
        title = '\u{1F4CB} \u4E3B\u9898\u73ED\u4F1A\u8BA1\u5212';
        gotoView = 'activities';
        const plans = (data.meetingPlans || []).slice().sort((a, b) => (a.week || 0) - (b.week || 0));
        body = plans.map(p => `<div class="setting-row">
          <span><b>\u7B2C${p.week}\u5468</b> \u00B7 ${Utils.escapeHtml(p.topic)}${p.content ? `<br><span class="text-sm text-secondary">${Utils.escapeHtml(p.content).substring(0, 50)}${p.content.length > 50 ? '...' : ''}</span>` : ''}</span>
          <span class="tag ${p.status === 'done' ? 'green' : 'gray'}">${p.status === 'done' ? '已开' : '未开'}</span>
        </div>`).join('') || '<div class="empty-state"><div class="text">\u6682\u65E0\u73ED\u4F1A\u8BA1\u5212\uFF0C\u53EF\u53C2\u8003\u73ED\u4F1A\u8D44\u6E90\u5E93\u7B56\u5212</div></div>';
      } else if (type === 'comm') {
        title = '\u{1F4DE} \u5BB6\u6821\u6C9F\u901A';
        gotoView = 'communication';
        const followUps = (data.communicationLog || []).filter(l => l.followUp);
        const recent = (data.communicationLog || []).slice(-8).reverse();
        body = (followUps.length ? `<div class="card-header" style="color:var(--danger);">\u26A0\uFE0F \u5F85\u8DDF\u8FDB (${followUps.length})</div>${followUps.map(l => `<div class="setting-row"><span>${Utils.formatDate(l.date)} ${Utils.escapeHtml(l.studentName)}<br><span class="text-sm text-secondary">${Utils.escapeHtml(l.content).substring(0, 40)}</span></span><span class="tag red">\u9700\u8DDF\u8FDB</span></div>`).join('')}` : '<div class="tag green mb-2">\u2705 \u65E0\u5F85\u8DDF\u8FDB\u4E8B\u9879</div>') +
          `<div class="card-header mt-2">\u6700\u8FD1\u6C9F\u901A</div>` +
          (recent.map(l => `<div class="setting-row"><span>${Utils.formatDate(l.date)} ${Utils.escapeHtml(l.studentName)} (${Utils.escapeHtml(l.type)})<br><span class="text-sm text-secondary">${Utils.escapeHtml(l.content).substring(0, 50)}</span></span></div>`).join('') || '<div class="text-sm text-secondary">\u6682\u65E0\u8BB0\u5F55</div>');
      } else if (type === 'growth') {
        title = '\u{1F338} \u5B66\u751F\u6210\u957F\u6863\u6848';
        gotoView = 'students';
        const bdays = data.students.map(s => ({ s, days: Utils.daysUntilBirthday(s.birthday) })).filter(x => x.days !== null && x.days <= 30).sort((a, b) => a.days - b.days);
        const totals = {};
        (data.points || []).forEach(p => { totals[p.studentId] = (totals[p.studentId] || 0) + p.delta; });
        const top = Object.entries(totals).sort((a, b) => b[1] - a[1]).slice(0, 5);
        const honorCount = (data.honors || []).length;
        body = (bdays.length ? `<div class="card-header">\u{1F382} \u8FD130\u5929\u751F\u65E5</div>${bdays.map(({ s, days }) => `<div class="setting-row"><span>${Utils.escapeHtml(s.name)}</span><span class="tag ${days === 0 ? 'red' : 'blue'}">${Utils.birthdayLabel(s.birthday)}</span></div>`).join('')}` : '') +
          `<div class="card-header mt-2">\u{1F4AF} \u64CD\u884C\u79EF\u5206\u699C</div>` +
          (top.map(([sid, v], i) => `<div class="setting-row"><span>${i < 3 ? ['\u{1F947}','\u{1F948}','\u{1F949}'][i] : (i + 1) + '.'} ${nameOf(sid)}</span><span class="text-bold" style="color:${v >= 0 ? 'var(--success)' : 'var(--danger)'};">${v > 0 ? '+' : ''}${v}</span></div>`).join('') || '<div class="text-sm text-secondary">\u6682\u65E0\u79EF\u5206</div>') +
          `<div class="text-sm text-secondary mt-2">\u{1F3C5} \u73ED\u7EA7\u8363\u8A89\u7D2F\u8BA1 ${honorCount} \u9879 \u00B7 \u70B9\u51FB\u5B66\u751F\u5934\u50CF\u53EF\u67E5\u770B\u5B8C\u6574\u6210\u957F\u6863\u6848\uFF08\u8003\u52E4/\u6210\u7EE9/\u804C\u52A1/\u8363\u8A89/\u79EF\u5206/\u8BC4\u8BED\uFF09</div>`;
      } else if (type === 'acts') {
        title = '\u{1F3C6} \u73ED\u7EA7\u6D3B\u52A8';
        gotoView = 'activities';
        const acts = (data.activities || []).slice().sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
        body = acts.map(a => `
          <div style="padding:8px 0;border-bottom:1px solid var(--border);">
            <div class="flex gap-2 items-center justify-between">
              <span class="text-bold">${Utils.escapeHtml(a.title)}</span>
              <span class="tag blue">${Utils.formatDate(a.date)}</span>
            </div>
            ${a.description ? `<div class="text-sm text-secondary mt-1">${Utils.escapeHtml(a.description)}</div>` : ''}
            ${(a.photos || []).length ? `<div class="act-photos">${a.photos.map((p, i) => `<img src="${p}" class="act-photo" onclick="App.viewPhoto('${a.id}', ${i})">`).join('')}</div>` : ''}
          </div>`).join('') || '<div class="empty-state"><div class="text">\u6682\u65E0\u6D3B\u52A8\u8BB0\u5F55</div></div>';
      } else {
        return;
      }

      const footerHtml = `
        ${gotoView ? `<button class="btn btn-outline" onclick="Modal.close();App.navigate('${gotoView}')">${gotoLabel} \u2192</button>` : ''}
        <button class="btn btn-primary" onclick="Modal.close()">关闭</button>
      `;
      Modal.open(title, body, footerHtml);

      // 考勤饼图
      if (type === 'attendance') {
        setTimeout(() => {
          const ctx = document.getElementById('home-att-chart');
          if (!ctx || typeof Chart === 'undefined') return;
          const att = data.attendance[today] || {};
          new Chart(ctx, {
            type: 'doughnut',
            data: {
              labels: ['到校', '迟到', '缺勤'],
              datasets: [{ data: [(att.present || []).length, (att.late || []).length, (att.absent || []).length], backgroundColor: ['#22c55e', '#f59e0b', '#ef4444'], borderWidth: 0 }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 8 } } } }
          });
        }, 50);
      }
    },

    viewPhoto(actId, idx) {
      const data = Store.get();
      const a = (data.activities || []).find(x => x.id === actId);
      if (!a || !(a.photos || [])[idx]) return;
      Modal.open('\u{1F4F7} \u7167\u7247', `<img src="${a.photos[idx]}" class="act-photo-large">`, `<button class="btn btn-primary" onclick="Modal.close()">关闭</button>`);
    },

    // ---- 工作日志 ----
    openJournalModal() {
      const data = Store.get();
      const logs = data.journal || [];

      const listHtml = logs.slice(-30).reverse().map(l => `
        <div class="setting-row">
          <span>
            <span class="tag ${l.tag === '教学' ? 'blue' : l.tag === '德育' ? 'green' : l.tag === '安全' ? 'red' : l.tag === '家校' ? 'orange' : 'gray'}">${Utils.escapeHtml(l.tag || '其他')}</span>
            <span class="text-sm text-secondary">${Utils.formatDate(l.date)}</span>
            <br><span class="text-sm">${Utils.escapeHtml(l.content)}</span>
          </span>
          <button class="btn-icon" onclick="App.deleteJournal('${l.id}')">\u{1F5D1}</button>
        </div>
      `).join('');

      const bodyHtml = `
        <div class="form-row">
          <div class="form-group"><label class="form-label">日期</label>
            <input type="date" class="input" id="j-date" value="${Utils.today()}"></div>
          <div class="form-group"><label class="form-label">分类</label>
            <select class="select" id="j-tag">
              ${['教学','德育','安全','家校','行政','其他'].map(t => `<option value="${t}">${t}</option>`).join('')}
            </select></div>
        </div>
        <div class="form-group"><label class="form-label">今日工作记录</label>
          <textarea class="textarea" id="j-content" placeholder="如: 处理宿舍矛盾、约谈家长、组织班会..."></textarea></div>
        <div class="card-header" style="margin-top:8px;"><span>\u{1F4DC} 历史记录 (${logs.length}条)</span></div>
        ${listHtml || '<div class="text-sm text-secondary" style="padding:8px 0;">暂无记录</div>'}
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">关闭</button>
        <button class="btn btn-primary" onclick="App.saveJournal()">记一笔</button>
      `;
      Modal.open('\u{1F4DD} 工作日志（班主任留痕）', bodyHtml, footerHtml);
    },

    saveJournal() {
      const content = document.getElementById('j-content').value.trim();
      if (!content) { Toast.show('请输入工作内容'); return; }
      Store.update(d => {
        if (!d.journal) d.journal = [];
        d.journal.push({
          id: Utils.uid(),
          date: document.getElementById('j-date').value,
          tag: document.getElementById('j-tag').value,
          content
        });
      });
      document.getElementById('j-content').value = '';
      Toast.show('已记录');
      this.openJournalModal(); // 刷新列表
    },

    deleteJournal(id) {
      if (!confirm('删除该日志？')) return;
      Store.update(d => { d.journal = (d.journal || []).filter(l => l.id !== id); });
      this.openJournalModal();
    },

    // ---- 随机点名 ----
    // 本次会话已点名单（页面刷新后重置）
    _pickedThisSession: [],

    randomPick(count, excludePicked) {
      const data = Store.get();
      if (!data || data.students.length === 0) { Toast.show('暂无学生'); return; }

      // 未传 count → 先弹模式选择
      if (count === undefined) {
        const pickedN = this._pickedThisSession.length;
        const bodyHtml = `
          <div class="form-group">
            <label class="form-label">点名模式</label>
            <div class="smart-seat-options">
              <label class="smart-seat-opt"><input type="radio" name="pick-mode" value="1" checked>
                <div><b>\u{1F3AF} 点 1 人</b><div class="text-sm text-secondary">课堂提问、单人回答</div></div></label>
              <label class="smart-seat-opt"><input type="radio" name="pick-mode" value="3">
                <div><b>\u{1F465} 点 3 人</b><div class="text-sm text-secondary">小组讨论、上台演示</div></div></label>
              <label class="smart-seat-opt"><input type="radio" name="pick-mode" value="5">
                <div><b>\u{1F4AA} 点 5 人</b><div class="text-sm text-secondary">背诵抽查、任务分派</div></div></label>
            </div>
          </div>
          <div class="setting-row" style="border:none;">
            <span>排除本次已点过的 ${pickedN} 人</span>
            <div class="switch" id="pick-exclude" onclick="this.classList.toggle('on')"></div>
          </div>
          ${pickedN > 0 ? `<div class="text-sm text-secondary">已点: ${this._pickedThisSession.map(n => Utils.escapeHtml(n)).join('、')}</div>` : ''}
        `;
        const footerHtml = `
          <button class="btn btn-outline" onclick="Modal.close()">取消</button>
          ${pickedN > 0 ? `<button class="btn btn-outline" onclick="App.resetPicked()">重置已点</button>` : ''}
          <button class="btn btn-primary" onclick="App.confirmPick()">开始点名</button>
        `;
        Modal.open('\u{1F3B2} 随机点名', bodyHtml, footerHtml);
        return;
      }

      // 选取候选名单
      let pool = data.students;
      if (excludePicked && this._pickedThisSession.length > 0) {
        pool = data.students.filter(s => !this._pickedThisSession.includes(s.name));
        if (pool.length === 0) {
          Toast.show('所有人都点过了，已自动重置');
          this._pickedThisSession = [];
          pool = data.students;
        }
      }
      const n = Math.min(count, pool.length);

      // 创建全屏遮罩
      let overlay = document.getElementById('pick-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'pick-overlay';
        overlay.className = 'pick-overlay';
        document.body.appendChild(overlay);
      }

      const roll = () => {
        const shuffled = pool.slice().sort(() => Math.random() - 0.5).slice(0, n);
        overlay.innerHTML = `
          <div class="pick-card">
            <div class="pick-label">\u{1F3B2} 随机点名中...</div>
            <div class="pick-name" style="${n > 1 ? 'font-size:2rem;' : ''}">${shuffled.map(s => Utils.escapeHtml(s.name)).join(' \u00B7 ')}</div>
          </div>
        `;
        return shuffled;
      };

      let final = roll();
      const timer = setInterval(() => { final = roll(); }, 80);

      // 2秒后停止
      setTimeout(() => {
        clearInterval(timer);
        final.forEach(s => { if (!this._pickedThisSession.includes(s.name)) this._pickedThisSession.push(s.name); });
        overlay.innerHTML = `
          <div class="pick-card done">
            <div class="pick-label">\u{1F3AF} ${n > 1 ? '本次点到 ' + n + ' 位同学' : '恭喜点到'}</div>
            <div class="pick-name" style="${n > 1 ? 'font-size:2.2rem;line-height:1.5;' : ''}">${final.map(s => Utils.escapeHtml(s.name)).join('<br>')}</div>
            <div class="pick-meta">${final.map(s => s.starred ? Utils.escapeHtml(s.name) + ' \u{2B50}重点关注' : '').filter(Boolean).join(' ')}</div>
            <div class="flex gap-2 mt-3">
              <button class="btn btn-outline" style="color:#fff;border-color:rgba(255,255,255,0.5);" onclick="App.randomPick()">再来一次</button>
              <button class="btn btn-primary" onclick="document.getElementById('pick-overlay').classList.remove('show')">关闭</button>
            </div>
          </div>
        `;
      }, 2000);

      overlay.classList.add('show');
      // 点击遮罩空白处关闭
      overlay.onclick = (e) => { if (e.target === overlay) overlay.classList.remove('show'); };
    },

    confirmPick() {
      const mode = document.querySelector('input[name="pick-mode"]:checked');
      const exclude = document.getElementById('pick-exclude').classList.contains('on');
      Modal.close();
      this.randomPick(parseInt(mode.value, 10), exclude);
    },

    resetPicked() {
      this._pickedThisSession = [];
      Modal.close();
      Toast.show('已重置点名记录');
      this.randomPick();
    },

    // ---- 工作台内导入学生 ----
    openImportStudents() {
      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">粘贴名单 (每行一名学生)</label>
          <textarea class="textarea" id="import-text" style="min-height:120px;" placeholder="支持格式:
张三
李四,20240101,女
王五、赵六
(姓名,学号,性别,电话,宿舍 可选多列)"></textarea>
        </div>
        <div class="form-group">
          <label class="form-label">或上传 Excel / CSV 文件</label>
          <input type="file" class="input" id="import-csv" accept=".csv,.txt,.xlsx,.xls" onchange="App.loadImportFile(this)">
          <div class="text-sm text-secondary mt-1">\u{1F4C4} 支持 .xlsx / .xls / .csv，自动读取第一个工作表（需联网加载解析库）</div>
        </div>
        <div id="import-preview" class="text-sm text-secondary"></div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-outline" onclick="App.previewImport()">解析预览</button>
        <button class="btn btn-primary" onclick="App.confirmImportStudents()">确认导入</button>
      `;
      Modal.open('导入学生名单', bodyHtml, footerHtml);
    },

    loadImportFile(input) {
      const file = input.files[0];
      if (!file) return;
      const isExcel = /\.(xlsx|xls)$/i.test(file.name);

      if (isExcel) {
        // Excel: 使用 SheetJS 解析（CDN 加载）
        if (typeof XLSX === 'undefined') {
          Toast.show('Excel 解析库未加载（需联网），请将文件另存为 CSV 后重试');
          return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const wb = XLSX.read(e.target.result, { type: 'array' });
            const ws = wb.Sheets[wb.SheetNames[0]];
            const csv = XLSX.utils.sheet_to_csv(ws, { FS: ',' });
            document.getElementById('import-text').value = csv;
            this.previewImport();
            Toast.show(`已读取工作表「${wb.SheetNames[0]}」`);
          } catch (err) {
            Toast.show('Excel 解析失败，请检查文件格式');
          }
        };
        reader.readAsArrayBuffer(file);
        return;
      }

      // CSV / TXT
      const reader = new FileReader();
      reader.onload = (e) => {
        document.getElementById('import-text').value = e.target.result;
        this.previewImport();
      };
      reader.readAsText(file, 'utf-8');
    },

    parseImportText(text) {
      const students = [];
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      for (const line of lines) {
        const parts = line.split(/[,，、\t]/).map(p => p.trim()).filter(Boolean);
        if (!parts.length) continue;
        if (parts[0] === '姓名' || parts[0] === '名字' || parts[0] === 'name') continue; // 表头
        if (parts.length === 1) {
          students.push({ name: parts[0] });
        } else {
          const s = { name: parts[0] };
          if (parts[1]) s.studentId = parts[1];
          if (parts[2]) s.gender = parts[2];
          if (parts[3]) s.phone = parts[3];
          if (parts[4]) s.dorm = parts[4];
          students.push(s);
        }
      }
      return students;
    },

    previewImport() {
      const text = document.getElementById('import-text').value;
      const parsed = this.parseImportText(text);
      const el = document.getElementById('import-preview');
      if (parsed.length === 0) {
        el.innerHTML = '<span style="color:var(--danger);">未解析到学生，请检查格式</span>';
      } else {
        el.innerHTML = `\u2705 解析到 <b>${parsed.length}</b> 名学生: ${parsed.map(s => Utils.escapeHtml(s.name)).join('、')}`;
      }
    },

    confirmImportStudents() {
      const text = document.getElementById('import-text').value;
      const parsed = this.parseImportText(text);
      if (parsed.length === 0) { Toast.show('未解析到学生'); return; }

      const data = Store.get();
      const existing = new Set(data.students.map(s => s.name));
      const added = [];
      Store.update(d => {
        parsed.forEach(p => {
          if (existing.has(p.name)) return; // 跳过重名
          p.id = Utils.uid();
          d.students.push(p);
          added.push(p.name);
        });
      });
      Modal.close();
      if (added.length > 0) {
        Toast.show(`已导入 ${added.length} 人${parsed.length !== added.length ? '（' + (parsed.length - added.length) + ' 人重名跳过）' : ''}`);
      } else {
        Toast.show('全部为重名学生，未导入');
      }
      this.navigate('students');
    },

    // ---- 座位表 ----
    setSeatSize(dimension, value) {
      const v = Math.max(1, Math.min(12, parseInt(value, 10) || 6));
      Store.update(data => {
        if (!data.seating) data.seating = { rows: 6, cols: 6, map: {} };
        if (!data.seating.map) data.seating.map = {};
        data.seating[dimension] = v;
      });
      this.navigate('seating');
    },

    seatCellClick(key) {
      const data = Store.get();
      const seating = data.seating || { rows: 6, cols: 6, map: {} };
      const map = seating.map || {};
      const current = map[key];
      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      // 交换模式: 已选中一个座位，再点另一个座位
      if (seatSwapFrom !== null && seatSwapFrom !== key) {
        Store.update(d => {
          const m = d.seating.map;
          const a = m[seatSwapFrom];
          const b = m[key];
          if (b) m[seatSwapFrom] = b; else delete m[seatSwapFrom];
          if (a) m[key] = a; else delete m[key];
        });
        const n1 = current ? (studentById[current] || {}).name : '';
        const n2 = map[seatSwapFrom] ? (studentById[map[seatSwapFrom]] || {}).name : '';
        seatSwapFrom = null;
        Toast.show(`已交换${n1 || '空位'} \u21C4 ${n2 || '空位'}`);
        this.navigate('seating');
        return;
      }

      // 点击已占座位: 第一次点=选中交换，第二次点=取消选中并询问移除
      if (current && studentById[current]) {
        if (seatSwapFrom === key) {
          seatSwapFrom = null;
          const s = studentById[current];
          if (confirm(`座位上是「${s.name}」，确定移除？`)) {
            Store.update(d => { delete d.seating.map[key]; });
            Toast.show('已移除');
          }
          this.navigate('seating');
          return;
        }
        seatSwapFrom = key;
        Toast.show('已选中，再点另一个座位交换');
        this.navigate('seating');
        return;
      }
      seatSwapFrom = null;

      // 空座位: 弹窗选择学生（排除已就座的）
      const seatedIds = Object.values(map);
      const available = data.students.filter(s => !seatedIds.includes(s.id));
      if (available.length === 0) {
        Toast.show('所有学生都已安排座位');
        return;
      }

      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">选择学生放入此座位</label>
          <select class="select" id="seat-student">
            ${available.map(s => `<option value="${s.id}">${Utils.escapeHtml(s.name)}${s.starred ? ' \u{2B50}' : ''}</option>`).join('')}
          </select>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.saveSeat('${key}')">安排座位</button>
      `;
      Modal.open('安排座位', bodyHtml, footerHtml);
    },

    saveSeat(key) {
      const sid = document.getElementById('seat-student').value;
      if (!sid) return;
      Store.update(data => {
        if (!data.seating) data.seating = { rows: 6, cols: 6, map: {} };
        if (!data.seating.map) data.seating.map = {};
        data.seating.map[key] = sid;
      });
      Modal.close();
      Toast.show('座位已安排');
      this.navigate('seating');
    },

    // ---- 智能排座 ----
    openSmartSeatModal() {
      const data = Store.get();
      if (data.students.length === 0) { Toast.show('请先添加学生'); return; }
      const hasScores = (data.exams || []).some(e => e.scores && Object.keys(e.scores).length > 0);
      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">选择排座策略</label>
          <div class="smart-seat-options">
            <label class="smart-seat-opt"><input type="radio" name="seat-strategy" value="order" checked>
              <div><b>\u{1F4DD} 按名单顺序</b><div class="text-sm text-secondary">学号/名单顺序依次排入</div></div></label>
            <label class="smart-seat-opt"><input type="radio" name="seat-strategy" value="random">
              <div><b>\u{1F3B2} 随机打乱</b><div class="text-sm text-secondary">随机排座，适合定期换座</div></div></label>
            <label class="smart-seat-opt"><input type="radio" name="seat-strategy" value="gender">
              <div><b>\u{1F46B} 男女间隔</b><div class="text-sm text-secondary">男女生相邻间隔排列</div></div></label>
            <label class="smart-seat-opt"><input type="radio" name="seat-strategy" value="score" ${hasScores ? '' : 'disabled'}>
              <div><b>\u{1F4C8} 成绩混排 ${hasScores ? '' : '(需先录入成绩)'}</b><div class="text-sm text-secondary">高低分蛇形搭配，同桌互补</div></div></label>
            <label class="smart-seat-opt"><input type="radio" name="seat-strategy" value="front">
              <div><b>\u{1F505} 身高/视力优先前排</b><div class="text-sm text-secondary">近视/个子矮自动排前排，保护视力</div></div></label>
          </div>
        </div>
        <div class="text-sm text-secondary">\u26A0\uFE0F 智能排座将覆盖当前座位安排（可先"保存为版本"留底）</div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">取消</button>
        <button class="btn btn-primary" onclick="App.smartArrangeSeats()">开始排座</button>
      `;
      Modal.open('\u{1F9E9} 智能排座', bodyHtml, footerHtml);
    },

    smartArrangeSeats() {
      const strategy = document.querySelector('input[name="seat-strategy"]:checked');
      if (!strategy) return;
      const data = Store.get();

      let ordered = data.students.slice();

      if (strategy.value === 'random') {
        // Fisher-Yates 洗牌
        for (let i = ordered.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [ordered[i], ordered[j]] = [ordered[j], ordered[i]];
        }
      } else if (strategy.value === 'gender') {
        // 男女分开后交替
        const males = ordered.filter(s => s.gender === '男');
        const females = ordered.filter(s => s.gender !== '男');
        const mixed = [];
        const first = males.length >= females.length ? males : females;
        const second = first === males ? females : males;
        for (let i = 0; i < first.length; i++) {
          mixed.push(first[i]);
          if (second[i]) mixed.push(second[i]);
        }
        ordered = mixed;
      } else if (strategy.value === 'score') {
        // 按最近一次考试分数排序，蛇形分排（高低搭配同桌/前后互补）
        const lastExam = (data.exams || [])
          .filter(e => e.scores && Object.keys(e.scores).length > 0)
          .sort((a, b) => new Date(b.date) - new Date(a.date))[0];
        if (!lastExam) { Toast.show('暂无成绩数据，请先录入成绩'); return; }
        const scored = ordered.map(s => ({ s, v: Number(lastExam.scores[s.id] ?? -1) }))
          .sort((a, b) => b.v - a.v);
        // 蛇形: 1,2,3,4 名一组，组内顺序正反交替 → 前后排高低互补
        const cols = (data.seating && data.seating.cols) || 6;
        const result = [];
        for (let i = 0; i < scored.length; i += cols) {
          const row = scored.slice(i, i + cols).map(x => x.s);
          if ((i / cols) % 2 === 1) row.reverse(); // 奇数行反转 → 蛇形
          result.push(...row);
        }
        ordered = result;
      } else if (strategy.value === 'front') {
        // 身高/视力优先前排：近视/弱视、个子矮排前面
        ordered = ordered.slice().sort((a, b) => {
          const key = (s) => {
            const needFront = (s.vision && s.vision !== '正常' && s.vision !== '') ? 0 : 1;
            const h = parseInt(s.height, 10);
            return needFront * 10000 + (isNaN(h) ? 9999 : h);
          };
          return key(a) - key(b);
        });
      }

      Store.update(d => {
        if (!d.seating) d.seating = { rows: 6, cols: 6, map: {} };
        if (!d.seating.map) d.seating.map = {};
        d.seating.map = {};
        const { rows, cols } = d.seating;
        let idx = 0;
        for (let r = 0; r < rows && idx < ordered.length; r++) {
          for (let c = 0; c < cols && idx < ordered.length; c++) {
            d.seating.map[`${r}-${c}`] = ordered[idx].id;
            idx++;
          }
        }
      });
      Modal.close();
      const label = { order: '按名单顺序', random: '随机打乱', gender: '男女间隔', score: '成绩混排', front: '身高/视力优先前排' }[strategy.value];
      Toast.show(`已完成${label}排座`);
      this.navigate('seating');
    },

    // ---- 座位版本管理 ----
    saveSeatVersion() {
      const name = prompt('为当前座位表命名（如: 月考版、常规版）:', `座位表 ${Utils.today()}`);
      if (name === null) return;
      Store.update(d => {
        if (!d.seating) d.seating = { rows: 6, cols: 6, map: {} };
        if (!d.seating.versions) d.seating.versions = [];
        d.seating.versions.push({
          id: Utils.uid(),
          name: name || '未命名',
          map: JSON.parse(JSON.stringify(d.seating.map || {})),
          createdAt: Utils.today()
        });
      });
      Toast.show('座位版本已保存');
      this.navigate('seating');
    },

    loadSeatVersion(id) {
      if (!confirm('加载版本将覆盖当前座位安排，继续？')) return;
      Store.update(d => {
        const v = ((d.seating || {}).versions || []).find(x => x.id === id);
        if (v) d.seating.map = JSON.parse(JSON.stringify(v.map));
      });
      Toast.show('已加载版本');
      this.navigate('seating');
    },

    deleteSeatVersion(id) {
      if (!confirm('删除该座位版本？')) return;
      Store.update(d => {
        if (d.seating && d.seating.versions) {
          d.seating.versions = d.seating.versions.filter(v => v.id !== id);
        }
      });
      Toast.show('已删除');
      this.navigate('seating');
    },

    clearSeats() {
      if (!confirm('清空全部座位安排？')) return;
      Store.update(data => {
        if (data.seating) data.seating.map = {};
      });
      Toast.show('已清空');
      this.navigate('seating');
    },

    // ---- 设置 ----
    saveClassInfo() {
      const className = document.getElementById('set-classname').value.trim();
      const teacher = document.getElementById('set-teacher').value.trim();
      const motto = document.getElementById('set-motto').value.trim();
      Store.update(data => {
        if (className) data.meta.className = className;
        data.meta.teacher = teacher;
        data.meta.motto = motto;
      });
      // 同步班级注册表名称
      Store.ensureRegistered();
      this.renderNav();
      Toast.show('班级信息已保存');
      this.navigate('settings');
    },

    // ---- 多班切换 ----
    openClassSwitcher() {
      const reg = Store.getRegistry();
      const data = Store.get();
      const curId = Store.currentId();
      const curName = (data && data.meta.className) || '当前班级';

      const listHtml = reg.map(c => `
        <div class="class-switch-row ${c.id === curId ? 'current' : ''}" onclick="App.switchClass('${c.id}')">
          <span class="text-bold">${Utils.escapeHtml(c.name)}</span>
          ${c.id === curId ? '<span class="tag blue">\u5F53\u524D</span>' : ''}
          ${c.id !== curId ? `<button class="btn-icon" onclick="event.stopPropagation();App.confirmDeleteClass('${c.id}','${Utils.escapeHtml(c.name)}')">\u{1F5D1}</button>` : ''}
        </div>
      `).join('');

      const bodyHtml = `
        <div class="form-group">
          <label class="form-label">我的班级 (${reg.length}个)</label>
          ${listHtml || '<div class="text-sm text-secondary">暂无班级</div>'}
        </div>
        <div class="card-header mt-3"><span>\u{1F195} 新建班级</span></div>
        <div class="flex gap-2 mt-2">
          <input type="text" class="input" id="new-class-name" placeholder="新班级名称，如: 24软件技术2班">
          <button class="btn btn-primary btn-sm" onclick="App.createClassFromSwitcher()">创建</button>
        </div>
      `;
      const footerHtml = `
        <button class="btn btn-outline" onclick="Modal.close()">关闭</button>
      `;
      Modal.open(`\u{1F3EB} 班级切换 \u00B7 ${Utils.escapeHtml(curName)}`, bodyHtml, footerHtml);
    },

    switchClass(id) {
      if (Store.switchTo(id)) {
        Modal.close();
        Toast.show('已切换班级，正在加载...');
        setTimeout(() => location.reload(), 600);
      }
    },

    createClassFromSwitcher() {
      const name = document.getElementById('new-class-name').value.trim();
      if (!name) { Toast.show('请输入新班级名称'); return; }
      if (Store.createClass(name)) {
        Modal.close();
        Toast.show(`班级「${name}」已创建`);
        setTimeout(() => location.reload(), 600);
      }
    },

    confirmDeleteClass(id, name) {
      if (!confirm(`删除班级「${name}」及其全部数据？此操作不可恢复！`)) return;
      if (!confirm('再次确认：真的要删除吗？建议先导出备份。')) return;
      Store.deleteClass(id);
      Toast.show('已删除');
      this.openClassSwitcher();
    },

    setTheme(theme) {
      document.documentElement.setAttribute('data-theme', theme);
      Store.update(data => {
        if (!data.meta.settings) data.meta.settings = {};
        data.meta.settings.theme = theme;
      });
      this.navigate('settings');
      Toast.show('主题已切换');
    },

    toggleWidget(widgetId) {
      Store.update(data => {
        if (!data.meta.settings) data.meta.settings = {};
        if (!data.meta.settings.widgets) data.meta.settings.widgets = ['stats','attendance','trend','tasks','schedule','birthday','announcements','duty'];
        const w = data.meta.settings.widgets;
        const idx = w.indexOf(widgetId);
        if (idx >= 0) w.splice(idx, 1);
        else w.push(widgetId);
      });
      this.navigate('settings');
    },

    addCustomField() {
      const input = document.getElementById('new-field-name');
      const name = input.value.trim();
      if (!name) { Toast.show('请输入字段名'); return; }
      Store.update(data => {
        if (!data.meta.settings) data.meta.settings = {};
        if (!data.meta.settings.customFields) data.meta.settings.customFields = [];
        if (!data.meta.settings.customFields.includes(name)) data.meta.settings.customFields.push(name);
      });
      Toast.show('已添加');
      this.navigate('settings');
    },

    removeCustomField(index) {
      Store.update(data => {
        if (data.meta.settings && data.meta.settings.customFields) {
          data.meta.settings.customFields.splice(index, 1);
        }
      });
      Toast.show('已移除');
      this.navigate('settings');
    },

    // ---- 数据管理 ----
    exportData() {
      const data = Store.get();
      Utils.download(`${data.meta.className}_数据_${Utils.today()}.json`, JSON.stringify(data, null, 2), 'application/json');
      localStorage.setItem('hw_last_backup', Utils.today()); // 记录备份时间
      Toast.show('已导出并记录备份时间');
    },

    importData(fileInput) {
      const file = fileInput.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const imported = JSON.parse(e.target.result);
          if (!imported.meta || !imported.students) throw new Error('格式不正确');
          if (confirm('导入将覆盖当前数据，确定继续？')) {
            Store.save(imported);
            Toast.show('导入成功，正在刷新...');
            setTimeout(() => location.reload(), 1000);
          }
        } catch (err) {
          Toast.show('导入失败：文件格式不正确');
        }
      };
      reader.readAsText(file);
    },

    clearAllData() {
      if (!confirm('警告：将清空全部数据且无法恢复！确认？')) return;
      if (!confirm('再次确认：真的要清空全部数据吗？')) return;
      localStorage.removeItem(Store.key);
      Toast.show('已清空，正在刷新...');
      setTimeout(() => location.reload(), 1000);
    },

    // ---- 图表 ----
    drawAttendanceChart(present, late, absent) {
      const ctx = document.getElementById('att-chart');
      if (!ctx || typeof Chart === 'undefined') return;
      new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['到校', '迟到', '缺勤'],
          datasets: [{
            data: [present, late, absent],
            backgroundColor: ['#22c55e', '#f59e0b', '#ef4444'],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 8 } }
          }
        }
      });
    },

    drawTrendChart() {
      const ctx = document.getElementById('trend-chart');
      if (!ctx || typeof Chart === 'undefined') return;
      const data = Store.get();
      if (!data || data.students.length === 0) return;

      const labels = [];
      const rates = [];
      for (let i = 6; i >= 0; i--) {
        const d = Utils.shiftDate(Utils.today(), -i);
        labels.push(`${d.substring(5)}`);
        const att = data.attendance[d];
        if (att && att.present) {
          const marked = (att.present.length || 0) + ((att.late || []).length) + ((att.absent || []).length);
          const attended = att.present.length + (att.late || []).length;
          rates.push(marked > 0 ? Math.round(attended / data.students.length * 100) : null);
        } else {
          rates.push(null);
        }
      }

      new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            label: '出勤率 (%)',
            data: rates,
            borderColor: '#4f6df5',
            backgroundColor: 'rgba(79, 109, 245, 0.1)',
            fill: true,
            tension: 0.35,
            pointRadius: 4,
            pointBackgroundColor: '#4f6df5',
            spanGaps: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { min: 0, max: 100, ticks: { stepSize: 25, font: { size: 10 } } },
            x: { ticks: { font: { size: 10 } } }
          }
        }
      });
    },

    // ---- 周报导出 ----
    exportWeeklyReport() {
      const data = Store.get();
      if (!data) return;

      const days = [];
      for (let i = 6; i >= 0; i--) {
        days.push(Utils.shiftDate(Utils.today(), -i));
      }

      const studentById = {};
      data.students.forEach(s => { studentById[s.id] = s; });

      let report = `\u{1F4CB} ${data.meta.className} 班主任周报\n`;
      report += `周期: ${days[0]} ~ ${days[6]}\n`;
      report += `班主任: ${data.meta.teacher || '-'}  |  班级人数: ${data.students.length}\n`;
      report += `${'='.repeat(38)}\n\n`;

      // 出勤汇总
      report += '\u{1F4C5} 一、出勤汇总\n';
      let hasAtt = false;
      days.forEach(d => {
        const att = data.attendance[d];
        if (att) {
          hasAtt = true;
          const absentNames = (att.absent || []).map(id => (studentById[id] || {}).name).filter(Boolean);
          const lateNames = (att.late || []).map(id => (studentById[id] || {}).name).filter(Boolean);
          report += `  ${d} (${Utils.weekdayLabel(d)}): 到校${(att.present || []).length} 迟到${lateNames.length} 缺勤${absentNames.length}`;
          if (lateNames.length) report += ` | 迟到: ${lateNames.join('、')}`;
          if (absentNames.length) report += ` | 缺勤: ${absentNames.join('、')}`;
          report += '\n';
        }
      });
      if (!hasAtt) report += '  本周无考勤记录\n';

      // 任务汇总
      report += `\n\u{2705} 二、任务完成情况\n`;
      const allTasks = data.tasks || [];
      const doneTasks = allTasks.filter(t => t.status === 'done');
      const pendingTasks = allTasks.filter(t => t.status !== 'done');
      report += `  已完成: ${doneTasks.length} 项  |  进行中: ${pendingTasks.length} 项\n`;
      if (doneTasks.length) {
        report += '  已完成: ' + doneTasks.map(t => t.title).join('、') + '\n';
      }
      if (pendingTasks.length) {
        report += '  进行中:\n';
        pendingTasks.forEach(t => {
          report += `    - [${t.priority === 'high' ? '高' : t.priority === 'medium' ? '中' : '低'}] ${t.title}${t.deadline ? ' (截止 ' + t.deadline + ')' : ''}\n`;
        });
      }

      // 沟通汇总
      report += `\n\u{1F4DE} 三、家校沟通\n`;
      const weekComms = (data.communicationLog || []).filter(l => days.includes(l.date));
      if (weekComms.length === 0) {
        report += '  本周无沟通记录\n';
      } else {
        weekComms.forEach(l => {
          report += `  ${l.date} ${l.studentName} (${l.type}): ${l.content}\n`;
          if (l.followUp) report += `    \u26A0\uFE0F 需跟进\n`;
        });
      }

      // 近期活动
      report += `\n\u{1F3C6} 四、近期活动预告\n`;
      const upcoming = (data.activities || []).filter(a => {
        const diff = Math.ceil((new Date(a.date) - new Date()) / 86400000);
        return diff >= 0 && diff <= 14;
      });
      if (upcoming.length === 0) {
        report += '  暂无\n';
      } else {
        upcoming.forEach(a => { report += `  ${a.date} ${a.title}\n`; });
      }

      // 近期生日
      const birthdays = data.students
        .map(s => ({ name: s.name, days: Utils.daysUntilBirthday(s.birthday), bd: s.birthday }))
        .filter(x => x.days !== null && x.days <= 14);
      if (birthdays.length) {
        report += `\n\u{1F382} 五、近期生日\n`;
        birthdays.forEach(b => { report += `  ${b.name} (${b.bd}) - ${Utils.birthdayLabel(b.bd)}\n`; });
      }

      report += `\n${'='.repeat(38)}\n\u{1F3E1} 由班主任工作台自动生成`;

      // 尝试打开打印窗口，失败则下载文本
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html><head><title>${data.meta.className} 周报</title>
          <style>body{font-family:system-ui,'PingFang SC','Microsoft YaHei',sans-serif;max-width:680px;margin:24px auto;padding:0 16px;color:#1a1a2e;line-height:1.8;}
          pre{white-space:pre-wrap;font-size:14px;}</style></head>
          <body><pre>${Utils.escapeHtml(report)}</pre>
          <script>window.print()<\/script></body></html>
        `);
        printWindow.document.close();
        Toast.show('周报已生成，可打印或另存为 PDF');
      } else {
        Utils.download(`${data.meta.className}_周报_${Utils.today()}.txt`, report);
        Toast.show('周报已下载');
      }
    },

    // ---- 核心管理 ----
    toggleCoreNav() {
      const open = localStorage.getItem('hw_core_open') !== '0';
      localStorage.setItem('hw_core_open', open ? '0' : '1');
      this.renderNav();
    },

    toggleCoreModule(id) {
      Store.update(data => {
        if (!data.meta.settings) data.meta.settings = {};
        if (!data.meta.settings.coreModules) data.meta.settings.coreModules = CORE_MODULES.map(m => m.id);
        const arr = data.meta.settings.coreModules;
        const idx = arr.indexOf(id);
        if (idx >= 0) arr.splice(idx, 1); else arr.push(id);
      });
      this.renderNav();
      this.navigate('settings');
    },

    // ===== 模块排序 / 置顶 / 显隐 =====
    // 把当前顺序固化成完整数组（含未排过序的模块），便于上移/下移/置顶
    _materializeNavOrder(data) {
      if (!data.meta.settings) data.meta.settings = {};
      const ids = NAV_ITEMS.map(i => i.id);
      const cur = Array.isArray(data.meta.settings.navOrder) ? data.meta.settings.navOrder : [];
      const ordered = cur.filter(id => ids.includes(id));
      ids.forEach(id => { if (!ordered.includes(id)) ordered.push(id); });
      data.meta.settings.navOrder = ordered;
      return ordered;
    },
    moveNavItem(id, dir) {
      Store.update(data => {
        const arr = this._materializeNavOrder(data);
        const i = arr.indexOf(id);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= arr.length) return;
        const t = arr[i]; arr[i] = arr[j]; arr[j] = t;
      });
      this.renderNav();
      this.navigate('settings');
    },
    pinNavItem(id) {
      Store.update(data => {
        const arr = this._materializeNavOrder(data);
        const i = arr.indexOf(id);
        if (i <= 0) return;
        arr.splice(i, 1);
        arr.unshift(id);
      });
      Toast.show('\u2B50 已置顶');
      this.renderNav();
      this.navigate('settings');
    },
    toggleHideModule(id) {
      if (NAV_ALWAYS_VISIBLE.includes(id)) {
        Toast.show('「工作台」和「设置」不可隐藏');
        return;
      }
      Store.update(data => {
        if (!data.meta.settings) data.meta.settings = {};
        const arr = Array.isArray(data.meta.settings.hiddenModules) ? data.meta.settings.hiddenModules : [];
        const i = arr.indexOf(id);
        if (i >= 0) arr.splice(i, 1); else arr.push(id);
        data.meta.settings.hiddenModules = arr;
      });
      this.renderNav();
      this.navigate('settings');
    },
    resetNavOrder() {
      Store.update(data => {
        if (data.meta.settings) data.meta.settings.navOrder = [];
      });
      Toast.show('已恢复默认顺序');
      this.renderNav();
      this.navigate('settings');
    },
    resetHiddenModules() {
      Store.update(data => {
        if (data.meta.settings) data.meta.settings.hiddenModules = [];
      });
      Toast.show('已恢复显示全部模块');
      this.renderNav();
      this.navigate('settings');
    },

    toggleQuickAction(id) {
      Store.update(data => {
        if (!data.meta.settings) data.meta.settings = {};
        const cur = Array.isArray(data.meta.settings.quickActions)
          ? data.meta.settings.quickActions
          : QUICK_ACTIONS.slice(0, 8).map(a => a.id);
        const i = cur.indexOf(id);
        if (i >= 0) cur.splice(i, 1); else cur.push(id);
        data.meta.settings.quickActions = cur;
      });
      this.navigate('settings');
    },

    // ===== 导出中心：CSV（WPS/Excel/飞书）=====
    exportCsv(filename, header, rows) {
      const esc = v => {
        const s = (v === null || v === undefined) ? '' : String(v);
        return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      };
      const lines = [header.map(esc).join(',')].concat((rows || []).map(r => r.map(esc).join(',')));
      // 加 BOM，保证 WPS/Excel 打开中文不乱码
      Utils.download(filename, '\uFEFF' + lines.join('\r\n'), 'text/csv;charset=utf-8');
      Toast.show('\u2705 已导出 ' + filename);
    },
    exportStudentsCsv() {
      const data = Store.get();
      const cf = (data.meta.settings && data.meta.settings.customFields) || [];
      const header = ['姓名', '学号', '性别', '生日', '学生电话', '宿舍', '家长姓名', '家长职业', '家长电话', '备注', '重点关注'].concat(cf);
      const rows = data.students.map(s => [
        s.name, s.studentId || '', s.gender || '', s.birthday || '', s.phone || '', s.dorm || '',
        s.parentName || '', s.parentJob || '', s.parentPhone || '', s.notes || '', s.starred ? '是' : ''
      ].concat(cf.map(f => (s.customFields || {})[f] || '')));
      this.exportCsv(`${data.meta.className}_学生名单_${Utils.today()}.csv`, header, rows);
    },
    exportAttendanceCsv() {
      const data = Store.get();
      const nameOf = id => (data.students.find(s => s.id === id) || {}).name || id;
      const rows = Object.keys(data.attendance || {}).sort().map(date => {
        const a = data.attendance[date] || {};
        return [date, (a.present || []).map(nameOf).join('、'), (a.late || []).map(nameOf).join('、'), (a.absent || []).map(nameOf).join('、')];
      });
      if (!rows.length) { Toast.show('暂无考勤记录'); return; }
      this.exportCsv(`${data.meta.className}_考勤记录_${Utils.today()}.csv`, ['日期', '到校', '迟到', '缺勤'], rows);
    },
    exportScoresCsv() {
      const data = Store.get();
      const rows = [];
      (data.exams || []).forEach(ex => {
        data.students.forEach(s => {
          const v = (ex.scores || {})[s.id];
          if (v === undefined || v === null || v === '') return;
          rows.push([ex.name, ex.date || '', s.name, s.studentId || '', v, ex.fullScore || 100]);
        });
      });
      if (!rows.length) { Toast.show('暂无成绩记录'); return; }
      this.exportCsv(`${data.meta.className}_成绩单_${Utils.today()}.csv`, ['考试', '日期', '姓名', '学号', '分数', '满分'], rows);
    },
    exportPointsCsv() {
      const data = Store.get();
      const rows = (data.points || []).map(p => [
        p.date || '', (data.students.find(s => s.id === p.studentId) || {}).name || p.studentId,
        p.delta, p.reason || ''
      ]);
      if (!rows.length) { Toast.show('暂无积分记录'); return; }
      this.exportCsv(`${data.meta.className}_操行积分_${Utils.today()}.csv`, ['日期', '姓名', '分值', '事由'], rows);
    },
    exportCommCsv() {
      const data = Store.get();
      const rows = (data.communicationLog || []).map(l => [l.date || '', l.studentName || '', l.type || '', (l.content || '').replace(/\n/g, ' '), l.followUp ? '需跟进' : '']);
      if (!rows.length) { Toast.show('暂无沟通记录'); return; }
      this.exportCsv(`${data.meta.className}_家校沟通_${Utils.today()}.csv`, ['日期', '学生', '方式', '内容', '跟进'], rows);
    },
    exportLeavesCsv() {
      const data = Store.get();
      const st = { pending: '待审批', approved: '已通过', rejected: '已驳回' };
      const rows = (data.leaves || []).map(l => [
        l.applyDate || '', (data.students.find(s => s.id === l.studentId) || {}).name || l.studentId,
        l.type || '', l.startDate || '', l.endDate || '', l.reason || '', st[l.status] || l.status || ''
      ]);
      if (!rows.length) { Toast.show('暂无请假记录'); return; }
      this.exportCsv(`${data.meta.className}_请假记录_${Utils.today()}.csv`, ['申请日期', '姓名', '类型', '开始', '结束', '事由', '状态'], rows);
    },
    exportHomeworkCsv() {
      const data = Store.get();
      const rows = [];
      (data.homeworks || []).forEach(h => {
        const sub = h.submitted || [];
        const unsub = data.students.filter(s => !sub.includes(s.id));
        rows.push([h.createdAt || '', h.subject || '', h.title || '', h.deadline || '', sub.length, data.students.length, unsub.map(s => s.name).join('、')]);
      });
      if (!rows.length) { Toast.show('暂无作业记录'); return; }
      this.exportCsv(`${data.meta.className}_作业收缴_${Utils.today()}.csv`, ['发布日期', '科目', '内容', '截止', '已交', '应交', '未交名单'], rows);
    },

    // ===== 导出中心：Markdown（IMA / 飞书 / WPS）=====
    exportMarkdown(kind) {
      const data = Store.get();
      const cls = data.meta.className || '班级';
      let title = '', body = '';

      if (kind === 'journal') {
        title = `${cls} 班主任工作日志`;
        const list = (data.journal || []).slice().reverse();
        if (!list.length) { Toast.show('暂无工作日志'); return; }
        body = list.map(j => `## ${j.date || ''}\n\n${j.content || ''}`).join('\n\n');
      } else if (kind === 'comments') {
        title = `${cls} 期末评语`;
        const cs = data.comments || {};
        const keys = Object.keys(cs).filter(k => cs[k]);
        if (!keys.length) { Toast.show('暂无期末评语'); return; }
        body = keys.map(id => {
          const s = data.students.find(x => x.id === id) || {};
          return `### ${s.name || id}\n\n${cs[id]}`;
        }).join('\n\n');
      } else if (kind === 'meetings') {
        title = `${cls} 班会方案`;
        const ms = (data.meetingPlans || []).slice().sort((a, b) => (a.week || 0) - (b.week || 0));
        if (!ms.length) { Toast.show('暂无班会方案'); return; }
        body = ms.map(m => `## 第${m.week || '?'}周 · ${m.title || '未命名'}\n\n- 状态：${m.status === 'done' ? '已开展' : '计划中'}\n- 日期：${m.date || '待定'}\n\n${m.content || ''}`).join('\n\n');
      } else {
        title = `${cls} 班级大事记`;
        const acts = (data.activities || []).map(a => `- ${a.date || ''} 【活动】${a.title || ''}${a.description ? ' — ' + a.description : ''}`);
        const hons = (data.honors || []).map(h => `- ${h.date || ''} 【荣誉·${h.level || ''}】${h.title || ''}`);
        if (!acts.length && !hons.length) { Toast.show('暂无活动或荣誉记录'); return; }
        body = `## 班级活动\n\n${acts.join('\n') || '（暂无）'}\n\n## 班级荣誉\n\n${hons.join('\n') || '（暂无）'}`;
      }

      const md = `# ${title}\n\n> 导出自班主任工作台 · ${Utils.today()} · 班主任：${data.meta.teacher || '—'}\n\n${body}\n`;
      Utils.download(`${title}_${Utils.today()}.md`, md, 'text/markdown;charset=utf-8');
      Toast.show('\u2705 已导出 Markdown，可直接存入 IMA 知识库');
    },

    openCoreModal(type, id) {
      const cfg = CORE_TYPES[type];
      const data = Store.get();
      const it = id ? (data[CORE_DATA_KEY[type]] || []).find(x => x.id === id) : {};
      const fields = cfg.fields.map(f => {
        const val = it[f.k] != null ? it[f.k] : (f.def != null ? f.def : '');
        if (f.type === 'select') {
          return `<div class="form-group"><label class="form-label">${f.label}${f.req ? ' *' : ''}</label><select class="select" id="cf-${type}-${f.k}">${f.options.map(o => `<option value="${o}" ${String(val) === o ? 'selected' : ''}>${o}</option>`).join('')}</select></div>`;
        } else if (f.type === 'textarea') {
          return `<div class="form-group"><label class="form-label">${f.label}${f.req ? ' *' : ''}</label><textarea class="textarea" id="cf-${type}-${f.k}" placeholder="${f.ph || ''}">${Utils.escapeHtml(val)}</textarea></div>`;
        } else if (f.type === 'student') {
          return `<div class="form-group"><label class="form-label">${f.label}${f.req ? ' *' : ''}</label><select class="select" id="cf-${type}-${f.k}"><option value="">请选择</option>${data.students.map(s => `<option value="${s.id}" ${String(val) === s.id ? 'selected' : ''}>${Utils.escapeHtml(s.name)}</option>`).join('')}</select></div>`;
        }
        return `<div class="form-group"><label class="form-label">${f.label}${f.req ? ' *' : ''}</label><input type="${f.type === 'date' ? 'date' : (f.type === 'number' ? 'number' : 'text')}" class="input" id="cf-${type}-${f.k}" value="${Utils.escapeHtml(val)}" placeholder="${f.ph || ''}"></div>`;
      }).join('');
      const footerHtml = `<button class="btn btn-outline" onclick="Modal.close()">取消</button><button class="btn btn-primary" onclick="App.saveCoreItem('${type}','${id || ''}')">保存</button>`;
      Modal.open((id ? '编辑' : '添加') + ' · ' + cfg.title, `<div class="core-form">${fields}</div>`, footerHtml);
    },

    saveCoreItem(type, id) {
      const cfg = CORE_TYPES[type];
      const obj = { id: id || Utils.uid() };
      for (const f of cfg.fields) {
        const el = document.getElementById('cf-' + type + '-' + f.k);
        if (!el) continue;
        let v = el.value;
        if (f.type === 'number') v = parseInt(v, 10) || 0;
        if (f.req && !String(v).trim() && f.type !== 'number') { Toast.show('请填写：' + f.label); return; }
        obj[f.k] = v;
      }
      Store.update(d => {
        const key = CORE_DATA_KEY[type];
        if (!d[key]) d[key] = [];
        const arr = d[key];
        const idx = arr.findIndex(x => x.id === obj.id);
        if (idx >= 0) arr[idx] = obj; else arr.push(obj);
      });
      Modal.close();
      Toast.show('已保存');
      this.navigate(CORE_VIEW[type]);
    },

    deleteCoreItem(type, id) {
      if (!confirm('删除该记录？')) return;
      Store.update(d => { const key = CORE_DATA_KEY[type]; if (d[key]) d[key] = d[key].filter(x => x.id !== id); });
      Toast.show('已删除');
      this.navigate(CORE_VIEW[type]);
    },

    toggleCoreDone(type, id) {
      Store.update(d => { const arr = d[CORE_DATA_KEY[type]] || []; const it = arr.find(x => x.id === id); if (it) it.done = !it.done; });
      this.navigate(CORE_VIEW[type]);
    },

    drawCoreCharts() {
      if (typeof Chart === 'undefined') return;
      const data = Store.get();
      const cr = document.getElementById('chart-core-risk');
      if (cr) {
        const todoOpen = (data.coreTodo || []).filter(t => !t.done).length;
        const dropoutRisk = (data.dropout || []).filter(d => d.level === '红' || d.level === '橙').length;
        const safetyRisk = (data.safety || []).filter(s => s.level === '高' || s.level === '中').length;
        const commMissing = data.students.filter(s => { const c = (data.communicationLog || []).filter(l => l.studentName === s.name); return s.parentPhone && (!c.length || Math.ceil((Date.now() - new Date(c[c.length - 1].date || 0)) / 86400000) > 30); }).length;
        const noPhone = data.students.filter(s => !s.parentPhone).length;
        this._chart(cr, 'bar', ['未完成待办', '控辍红/橙', '安全高/中', '未沟通家长', '缺家长电话'], [todoOpen, dropoutRisk, safetyRisk, commMissing, noPhone], ['#ef4444', '#f97316', '#eab308', '#0ea5e9', '#8b5cf6']);
      }
      const cp = document.getElementById('chart-core-progress');
      if (cp) {
        const follow = data.coreFollow || []; const projects = data.projects || [];
        const fp = follow.length ? Math.round(follow.reduce((a, b) => a + (+b.progress || 0), 0) / follow.length) : 0;
        const pp = projects.length ? Math.round(projects.reduce((a, b) => a + (+b.progress || 0), 0) / projects.length) : 0;
        this._chart(cp, 'bar', ['重点事项', '专项任务'], [fp, pp], ['#4f6df5', '#059669']);
      }
      const cd = document.getElementById('chart-dropout');
      if (cd) {
        const dropout = data.dropout || [];
        const cnt = { '红': 0, '橙': 0, '黄': 0 };
        dropout.forEach(d => { if (cnt[d.level] != null) cnt[d.level]++; });
        this._chart(cd, 'doughnut', ['红', '橙', '黄'], [cnt['红'], cnt['橙'], cnt['黄']], ['#ef4444', '#f97316', '#eab308']);
      }
      const cs = document.getElementById('chart-safety');
      if (cs) {
        const safety = data.safety || [];
        const m = {}; safety.forEach(s => { m[s.type] = (m[s.type] || 0) + 1; });
        const labels = Object.keys(m); const vals = labels.map(k => m[k]);
        this._chart(cs, 'bar', labels, vals, labels.map((_, i) => ['#4f6df5', '#059669', '#ea580c', '#7c3aed', '#0ea5e9', '#ec4899', '#eab308', '#8b5cf6'][i % 8]));
      }
      const cc = document.getElementById('chart-comm');
      if (cc) {
        const withPhone = data.students.filter(s => s.parentPhone);
        const contacted = withPhone.filter(s => (data.communicationLog || []).some(l => l.studentName === s.name)).length;
        this._chart(cc, 'doughnut', ['已建联', '未建联'], [contacted, withPhone.length - contacted], ['#059669', '#e5e7eb']);
      }
    },

    _chart(canvas, kind, labels, vals, colors) {
      // 离线或 CDN 不可用时 Chart 未定义：静默跳过，不影响列表/进度/风险展示
      if (typeof Chart === 'undefined' || !canvas || !canvas.getContext) return;
      const ctx = canvas.getContext('2d');
      if (canvas._chart) canvas._chart.destroy();
      canvas._chart = new Chart(ctx, {
        type: kind,
        data: { labels, datasets: [{ data: vals, backgroundColor: colors, borderWidth: 0 }] },
        options: { responsive: true, plugins: { legend: { display: kind !== 'bar' } }, scales: kind === 'bar' ? { y: { beginAtZero: true, ticks: { precision: 0 } } } : {} }
      });
    },

    addMoralToActivity(id) {
      const data = Store.get();
      const m = (data.moralLib || []).find(x => x.id === id);
      if (!m) return;
      Store.update(d => {
        if (!d.activities) d.activities = [];
        d.activities.push({ id: Utils.uid(), title: m.title, date: Utils.today(), desc: (m.category || '') + '：' + (m.goal || ''), type: '班会' });
      });
      Toast.show('已加入班级活动：' + m.title);
    },

    deleteMoral(id) {
      if (!confirm('删除该主题？')) return;
      Store.update(d => { if (d.moralLib) d.moralLib = d.moralLib.filter(x => x.id !== id); });
      this.navigate('core-moral');
    },

    openMoralModal() {
      const bodyHtml = `
        <div class="form-group"><label class="form-label">主题标题 *</label><input type="text" class="input" id="m-title"></div>
        <div class="form-group"><label class="form-label">分类</label><select class="select" id="m-cat"><option>安全教育</option><option>思政教育</option><option>德育</option><option>考试动员</option><option>人生启迪</option><option>其他</option></select></div>
        <div class="form-group"><label class="form-label">教育目标</label><textarea class="textarea" id="m-goal"></textarea></div>
        <div class="form-group"><label class="form-label">实施步骤</label><textarea class="textarea" id="m-steps"></textarea></div>`;
      const footerHtml = `<button class="btn btn-outline" onclick="Modal.close()">取消</button><button class="btn btn-primary" onclick="App.saveMoral()">保存</button>`;
      Modal.open('添加思政德育主题', bodyHtml, footerHtml);
    },

    saveMoral() {
      const title = document.getElementById('m-title').value.trim();
      if (!title) { Toast.show('请输入标题'); return; }
      Store.update(d => { if (!d.moralLib) d.moralLib = []; d.moralLib.push({ id: Utils.uid(), title, category: document.getElementById('m-cat').value, goal: document.getElementById('m-goal').value.trim(), steps: document.getElementById('m-steps').value.trim() }); });
      Modal.close(); Toast.show('已添加'); this.navigate('core-moral');
    }
  };

  // 暴露到全局
  window.App = App;
  window.Modal = Modal;
  window.Toast = Toast;

  // 启动
  document.addEventListener('DOMContentLoaded', () => App.init());
})();
