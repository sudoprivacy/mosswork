# When a run goes wrong

## A task stays queued

Keep polling that task with `beatra.tasks.get`. Queued and running work is the
original work; a second submission of the same slot charges twice for one
image. The plan, the copy, and every finished image stay usable.

## The create response never came back

First call `beatra.tasks.list`, then `beatra.tasks.get`, and match the frozen
request (slot, photo, prompt, canvas, time). Only when no task exists, retry
the identical payload with the same `client_request_id`. An ambiguous match is
not a match and never authorizes a new request.

## The price on the card looks wrong

Read `beatra.models.list` again for that capability and show the number it
just returned. Never reuse a price from an earlier set or poster.

## An image does not look like the real product

Name what moved before offering anything. A small local drift (a logo mark, a
lid detail) is one `beatra.images.edit` with that image as `images[0]`, on its
own card and ID. A structural drift (wrong shape or colour) is a new transform
of that slot on its own card and ID. Until it is fixed, say that image must not
be listed. When the image cannot be viewed, say it was not checked by looking.

## The poster text is wrong or invented

One `beatra.images.edit` with an `edit_regions` box repaints the band plain or
fixes the characters, on its own card and ID, or the seller covers it before
publishing. Do not regenerate the whole poster hoping for cleaner letters, and
never leave an invented price, discount, or date on a poster.

## The seller changes a slot after the yes

Say so at once, with the added price. The changed slot is new work on its own
card with a new ID; unchanged slots keep their images and are not made again.

## A slot comes back failed

Report the terminal error and what the task reports as charged. Re-running
that slot is new work on its own card with a new ID; do not quietly add a
seventh call to a six-slot set.

## The balance ran out mid-set

Stop the set where it is, relay the official message and top-up URL, and list
which slots finished and which did not. After the seller says they topped up,
continue only the unfinished slots with their original IDs and arguments; do
not rebuild the plan or re-price finished slots.
