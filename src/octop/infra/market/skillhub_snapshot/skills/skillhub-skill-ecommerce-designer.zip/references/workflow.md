# Listing image workflow

The set plan, the selling-point copy, the detail-page order, the platform
sizes, and the poster plan are free and need no connection. Everything below
starts only after the plan it uses is frozen and the seller has answered that
call's production card.

## The six-slot plan

Six slots are the default. Each slot answers one buyer question and has one
fact source; a slot whose fact is missing is left out or replaced, and the plan
keeps it so the seller can add the fact later.

| Slot | Role | Buyer question | Fact source |
| --- | --- | --- | --- |
| 1 | Main image | What exactly is this product? | the product photo |
| 2 | White-background image | What does it look like on its own? | the product photo |
| 3 | Selling-point image | Which approved benefit matters first? | a line the seller gave or approved; a performance figure only with its basis named on the card (label, spec sheet or test report) |
| 4 | Lifestyle scene | Where and how is it used? | the use the seller named |
| 5 | Close-up detail | What does the material or finish look like? | what the photo shows |
| 6 | Size or packaging image | How big is it, or what arrives? | sizes or box contents the seller gave |

The detail page is these six images in this order. A longer detail page with
many modules is outside one product's set; say so and keep to the set.

Sizes to note in the plan, each with "check the platform's seller backend for
the current rule": Taobao, JD, and Pinduoduo main images at 1:1 from 800×800;
the Amazon main image on pure white, the product filling most of the frame,
long side 1600 or more. A 1:1 canvas at the 2K tier covers all four.

## Production card

Show this before each paid call, in the user's language, and wait. Only the
slots of one product's listing set may share a card, each on its own line.

```text
Work:      Listing image set for the travel thermos (image transform from your photo), 6 images at 1:1
           1  Main image        thermos upright, three-quarter view, soft daylight      (no words)           <price>  5466b0cd-3eec-4bba-90d9-9df87b363739
           2  White background  thermos alone on pure white, filling most of the frame  (no words)           <price>  3a4b84c8-6301-47f6-adb0-dedfb21195e9
           3  Selling point     open thermos on a desk, steam rising from the lid      "Keeps drinks warm"  <price>  85c8e0f3-e121-420d-a1da-c0e4d114c5c3
           4  Lifestyle scene   held in one hand on a morning commute                  (no words)           <price>  d03d16e2-2a9d-4219-87a0-a2ea6fa68c9a
           5  Close-up detail   silver lid and logo, macro, side light                 (no words)           <price>  c28c3a1a-1231-49cd-b006-0bba9289f077
           6  In the bag        thermos slipped into a tote's side pocket              (no words)           <price>  f22591a9-7373-4ab6-b503-96913b8527c4
Credits:   <live price per image from beatra.models.list> each, <total> for 6
Count:     6 paid calls, one image each, at most 2 running at a time
Identity:  one new ID per slot, listed above (a changed slot mints a new one)
If we stop: the plan and copy stay yours, and every finished image is yours
If the balance is short: I pass on the official message and top-up link, stop, and continue the unfinished slots with the same IDs after you top up
```

"Keeps drinks warm" is a category-level line: it goes on an image only after
the seller's yes on this card. Slot 6 replaces the size or packaging view
because the seller gave no size or box contents; it shows the travel use the
seller named. A poster, a fix, a scene image, and a motion clip each get
their own card.

## Upload the product photo and read the card

Confirm the photo shows the exact product and colour being listed, inspect
its MIME type, size, and dimensions, then upload it:

```bash
python3 scripts/mcp_client.py upload "./thermos-front.jpg" --mime-type image/jpeg
python3 scripts/mcp_client.py call beatra.models.list
```

```json
{"capability": "image_to_image"}
```

Read the live card for source formats and limits, canvas, and the current
price per image. Keep `model` as `auto` and `count` at 1.

## Write slot prompts that hold the set together

Each slot prompt has four parts in this order: the slot and its purpose; the
statement that image 1 is the exact product; that slot's must-keeps (shape,
colour, logo, label, included items); and one shared direction clause reused
word for word in every slot. Write the shared clause once from the seller's
direction, naming surface, light, depth, and finish, and say what is in the
frame rather than what must stay out. Carry a selling point through the picture
first; an on-image line is quoted exactly and named as the only words.

## Make each slot

One `beatra.images.transform` per slot, with the product photo as `images[0]`
and any confirmed brand or scene reference after it in its stated order:

```json
{
  "prompt": "Slot 3, the selling-point image. Image 1 is the exact product: a matte sage-green travel thermos with a silver lid. Keep its shape, colour, lid, and logo exactly. The thermos stands open on a commuter's desk with steam rising from the lid. The only words in the image, exactly: \"Keeps drinks warm\". Shared direction: soft daylight from the left on a pale warm-grey surface, shallow depth, clean satin finish.",
  "model": "auto",
  "count": 1,
  "canvas": {"type": "preset", "tier": "2K", "aspect": "1:1"},
  "images": [{"type": "artifact", "artifact_id": "artifact_product_photo"}],
  "client_request_id": "85c8e0f3-e121-420d-a1da-c0e4d114c5c3"
}
```

The white-background slot asks for the product alone on pure white, filling
most of the frame, with the same must-keeps. A six-slot set is six requests;
never ask one call for six images. Keep at most two tasks running on one
connection, or the lower live limit, and poll each with `beatra.tasks.get`
before submitting the next.

## Review the set

When the result is visible, check each image against the photo: product
shape, colour, logo, label, included items, and every on-image character. Then
check the set together: order, repetition, and one shared look. An image that
does not match the real product is reported as not fit to list. When an image
cannot be viewed, say it was not checked by looking and give the seller the
must-keeps to check.

## Store poster

```json
{"capability": "text_to_image"}
```

Use `beatra.images.generate` for a poster without the product photo, or
`{"capability": "image_to_image"}` and `beatra.images.transform` with the photo
as `images[0]` when the product should appear. Without a real photo, an empty
display stand or festival elements carry the poster and the seller places
their own product photo later.

```json
{
  "prompt": "Double 11 store sale poster, vertical 3:4. An empty round display stand at the centre on a deep red and warm gold backdrop with soft falling ribbons and bokeh lights. A plain solid deep-red band across the top third is left empty for the seller's own headline, and a plain band at the bottom is left empty for the offer. The image contains no letters, numbers, prices, or logos.",
  "model": "auto",
  "count": 1,
  "canvas": {"type": "preset", "tier": "2K", "aspect": "3:4"},
  "client_request_id": "c398bbd9-4b6d-48de-a7a8-420743125d48"
}
```

With the uploaded product photo, call `beatra.models.list` with
`{"capability": "image_to_image"}` and submit one `beatra.images.transform`
with the photo as `images[0]`:

```json
{
  "prompt": "Store anniversary sale poster, vertical 3:4. Image 1 is the exact product: a matte sage-green travel thermos with a silver lid; keep its shape, colour, lid, and logo exactly. The thermos stands on a round display stand at the lower centre, warm gold light and soft confetti on a deep green backdrop. A plain solid deep-green band across the top third is left empty for the seller's own headline. The image contains no letters, numbers, prices, or logos other than the product's own logo.",
  "model": "auto",
  "count": 1,
  "canvas": {"type": "preset", "tier": "2K", "aspect": "3:4"},
  "images": [{"type": "artifact", "artifact_id": "artifact_product_photo"}],
  "client_request_id": "51e25750-e14c-4cd8-8c0b-d0626d031768"
}
```

When the seller asks for words on the poster, quote the frozen headline and
offer exactly, using only offers the seller gave, and say they are the only
words in the image. Before delivery, inspect the whole poster for garbled
characters and invented numbers, prices, or offers.

## Fix one image

One `beatra.images.edit` repairs a wrong character, repaints a stray mark in
the words band, or makes one bounded change, on its own card and ID, with the
delivered image as `images[0]`.

```json
{"capability": "image_edit"}
```

```json
{
  "prompt": "Repaint the marked band as a plain solid deep red with no letters, numbers, or logos; keep everything else unchanged.",
  "images": [{"type": "artifact", "artifact_id": "artifact_delivered_poster"}],
  "edit_regions": [{"image_index": 0, "x": 0.08, "y": 0.04, "width": 0.84, "height": 0.22}],
  "model": "auto",
  "count": 1,
  "client_request_id": "a1f4e048-5c97-4bd1-86df-25b2ac6f3976"
}
```

To change an image the seller already has (a new background on their own
shot, a stray object removed), inspect it, upload it with
`python3 scripts/mcp_client.py upload "<file>" --mime-type <type>`, and make it
`images[0]` of one edit:

```json
{
  "prompt": "Replace only the background with a plain light-grey studio sweep and a soft shadow under the product; keep the product's shape, colour, label, and position unchanged.",
  "images": [{"type": "artifact", "artifact_id": "artifact_seller_image"}],
  "model": "auto",
  "count": 1,
  "client_request_id": "b2457bf4-a743-40cd-aed5-85974430aa7b"
}
```

When the product itself drifted in structure (wrong shape, wrong lid), a new
transform of that slot is new work on a new card, not an edit.

## Scene and mood images

```json
{"capability": "text_to_image"}
```

```json
{
  "prompt": "Cosy autumn desk scene for a store banner, square 1:1: a wool scarf, an open notebook, and warm window light on a wooden desk, an empty spot at the centre where a product photo can be placed later. The image contains no letters, numbers, or logos.",
  "model": "auto",
  "count": 1,
  "canvas": {"type": "preset", "tier": "2K", "aspect": "1:1"},
  "client_request_id": "a37fe1f7-e846-47e7-8897-4dbb9185b2ef"
}
```

Deliver it with the line that it is not a photo of the real product and must
not be listed as the main image.

## Motion clip from an accepted image

```json
{"capability": "image_to_video"}
```

When the card carries a `free_first_video` offer, the seller's first clip
inside the offer's `applies_to` limits costs nothing: say so and put the
card's sentence on the card, along with the live estimate the service charges
if it cannot apply the offer. Without the offer, quote the live estimate. Use
the accepted image's artifact; do not upload it again.

```json
{
  "image": {"type": "artifact", "artifact_id": "artifact_accepted_poster"},
  "prompt": "Slow camera push toward the display stand while warm light sweeps across the backdrop and ribbons drift. The product, logo, and any words stay still and sharp.",
  "model": "auto",
  "duration": 5,
  "client_request_id": "f7c39151-6511-4214-b782-b2c5b1bb40b3"
}
```

Read the durations the live card admits first. Use 5 seconds, or the admitted
length closest to it, stated on the card. Omit `aspect_ratio`; the shape
follows the image where the live card allows, so say that on the card and
report the clip's delivered shape. Motion can bend letters and fine product
shapes; say so on the card when the image carries words or a logo. One clip per
card. A main-image video with several shots belongs on a product-video
workflow.

## Variants and more than one product

One set covers one product. When the photos show more than one colour and the
seller has not said which leads, ask which one before the card. Other variants
take one of two routes, chosen before any paid call: one added range slot,
only from a photo that really shows every variant together, or a separate set
per variant from that variant's own photos. Several products are several sets
that share the slot template and the shared direction clause, never a fact or
a photo.

## Worked set

Product: a travel thermos for Taobao, with one front photo; the seller gave
the colour and lid but no capacity or warm-keeping hours. First reply, with no
tool call: the six-slot plan (main image, white background, selling point
"Keeps drinks warm", lifestyle commute scene, lid close-up, and an in-the-bag
use view in place of the size or packaging slot, since no size or box contents
were given), four selling-point lines without numbers, the detail-page order,
the platform sizes, and one line asking for capacity, warm-keeping hours, and
material. The seller replies "make the images". One set card lists six slots,
each price, the total, and six IDs; the seller says yes. Six transforms run two
at a time. Delivery lists six images in slot order with their dimensions and
`billing.net_charged_credits`, says slot 5's lid logo looks slightly different
from the photo and should not be listed until fixed, reminds the seller to
label the images as AI-generated, and offers one next step: name the slot to
change.

## Account balance

When the user asks how many credits remain or whether a live estimate fits the
current balance, call `beatra.wallet.get`. When they ask what was charged, call
`beatra.wallet.ledger`. Do not invent an account-balance tool, a top-up tool, or
an account mutation. Use the `topup_url` returned by `beatra.wallet.get` or the
URL inside an `insufficient_balance` error. Live prices still come from
`beatra.models.list`, never from ledger rows. When a model card comes back with
a `top_up` block, relay its tiers as the card lists them and in that order; do
not rank them or pick one for the user.
