---
name: skillhub-skill-houyer-craft-anything-2026
description: "借助 Craft Anything（github.com/storytold/craft-anything）研究任意软件的工作原理，并在编码代理协助下重建/复刻它。当用户要求\"复刻这个网站/游戏/应用\"、\"研究某个软件是怎么实现的\"、\"逆向分析这个程序/固件/数据库/packet capture\"、\"craft anything\"、\"重建/rebuild 某个目标\"时使用本技能。支持的目标类型包括：网站、native 程序、.NET/Java/Electron 应用、Android/Apple 应用、固件、packet captures、数据库和游戏文件。"
---

# Craft Anything

## Overview

Craft Anything 是一个开源引擎（Rust 实现，GitHub: https://github.com/storytold/craft-anything ），提供 320 个工具（每个既是 CLI 子命令又是 MCP 工具），用于**研究（Study）任意软件目标并产出证据记录（evidence records）**，再由编码代理（coding agent）执行**重建（Build）→ 校验（Check）→ 就绪（Ready）**的完整流程。本技能指导 WorkBuddy 通过 `craft-anything-cli` 驱动该引擎，完成"理解任意软件 + 打造自己的版本"。

关键认知：
- **检查/研究不需要 AI**——引擎工具是确定性的；只有 Build（重建）步骤需要本机已登录的编码代理（Claude Code 支持最完善，Codex/Copilot/Grok/ACP 代理亦可）。
- 所有工具的输出都是**证据记录**，带有 confidence（置信度）、coverage（覆盖度）、limitations（局限性）；大结果先返回摘要，需用 `core_evidence_browse` 工具分页浏览。

## 前提检查

在执行任何任务前，先确认 CLI 可用：

```sh
craft-anything-cli doctor
```

- 若命令不存在或 doctor 报告缺项，按 `references/installation.md` 中的说明安装（Windows 用 Releases 页的 portable zip 或 .msi；也可 `cargo install --path apps/craft-anything-cli` 从源码构建，需 Rust 1.97+）。安装完成后重新运行 doctor 验证。
- Build 步骤需要本机已登录的编码代理；doctor 会指出缺什么。若用户未安装任何编码代理，向用户说明并让其选择是否安装。
- 项目默认存放在 `Documents/Craft Anything`，每个项目含 `craft.json`、`capture/`、`app/`、`checks/`、`investigation.cany/`、`inbox/`。

## 工作流程

### 1. 只研究不重建（Study-only）

当用户只想了解某个目标"是什么/怎么做的"时：

```sh
craft-anything-cli commands          # 列出全部工具，按 toolset 分组
```

从 `commands` 输出中挑选与目标类型匹配的工具逐个调用（例如分析网站结构、检查 native 二进制、解析游戏文件）。无需 AI 参与检查。结果为证据记录，直接向用户总结置信度、覆盖度与局限性。

### 2. 完整重建（Full rebuild）

当用户要求复刻/重建一个目标时：

```sh
# 重建一个网站
craft-anything-cli rebuild https://example.com "Recreate this website"

# 目标来自 stdin（"-"），并限制迭代轮数
craft-anything-cli rebuild - "A snake game in Rust" --rounds 1

# 在已有项目上继续迭代
craft-anything-cli rebuild https://example.com "Make the header blue" --continue-in "<project folder>"

# 编辑用户已有的文件夹（说明 --existing edit 等）
craft-anything-cli rebuild - "Add a contact form" --project-folder "<folder>" --existing edit
```

参数要点：
- 第一个参数为 URL 或 `-`（stdin）；第二个参数为自然语言描述（向用户确认想要什么，必要时翻译为英文描述）。
- `--rounds <n>` 限制迭代轮数；`--deep` / `--clean-room` 为单次运行切换 Deep 或 Clean room 模式。
- `--project-folder` 指定项目文件夹；若文件夹已有内容，必须向用户确认它们是"应用本身"（builder 就地编辑）还是"素材"（应用生成在旁边 `app/` 目录），并据此传 `--existing edit` 等参数。
- rebuild 过程会在终端中提问——在非交互 shell 中运行时，预先与用户确认关键选项，或让用户直接在终端中执行。

### 3. 浏览大型证据结果

对大结果（如整站分析）：

1. 先读取返回的摘要。
2. 用 `core_evidence_browse` 工具（CLI 子命令或 MCP 工具）分页浏览详情。
3. 向用户汇报时突出：发现了什么、置信度如何、有哪些局限性。

### 4. MCP 模式（可选）

若需要将全部工具作为 MCP server 提供给客户端：

```sh
craft-anything-cli mcp
```

如用户希望在 WorkBuddy 中以 MCP 方式接入，按 WorkBuddy 的 MCP 配置流程把该命令写入 `~/.workbuddy/mcp.json`，并提醒用户需在连接器管理页"信任"新 server 后才会生效。

## 注意事项

- 项目处于 **early alpha**：与 Claude Code 配合的网站/应用/游戏完整流程已可用；其他代理与 API-key 方式的 Build 尚未实测——失败时如实告知并建议改用 Claude Code。
- 逆向分析仅用于学习与研究目的；提醒用户尊重目标软件的许可证与知识产权，不要直接抄袭受版权保护的素材。
- 完整工具清单见上游 `docs/tools.md` 与 `docs/tool-status.md`；逐工具用法以 `craft-anything-cli commands` 的本地输出为准。
- 安装细节、平台包矩阵、常见问题见 `references/installation.md`。
