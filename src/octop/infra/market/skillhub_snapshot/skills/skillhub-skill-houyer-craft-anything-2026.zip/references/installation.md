# Craft Anything CLI 安装与平台参考

上游仓库：https://github.com/storytold/craft-anything （MIT/Apache-2.0 双许可）

## 安装方式

### 1. 预编译包（推荐）

从 GitHub Releases 页面（https://github.com/storytold/craft-anything/releases ）下载：

| 平台 | 包 | 备注 |
|---|---|---|
| Windows | x64 / arm64 / x86 的 `.msi` 安装包或 portable `.zip` | 均已代码签名；portable zip 解压即用，把 CLI 所在目录加入 PATH |
| macOS | universal `.dmg`（App）+ universal CLI `.zip` | 0.2.0 之后 App 内已含 CLI；浏览器下载可能触发 quarantine，用终端 `curl` 下载或 `xattr -d com.apple.quarantine` 移除隔离属性 |
| Linux | AppImage / Flatpak / `.deb` / `.rpm` / tarball | AppImage 内置 CLI，可用 `<AppImage> --cli <command>` 调用；Flatpak 沙箱无法启动浏览器，不适合研究网站 |
| FreeBSD | x86_64 tarball | |
| Web (WebAssembly) | `craft-anything-web-<ver>.zip` | 仅浏览器内查看器（识别文件是什么，文件不离开浏览器）；解压后托管到任意静态服务器即可 |

### 2. 从源码构建

```sh
git clone https://github.com/storytold/craft-anything && cd craft-anything
cargo install --path apps/craft-anything-cli   # 安装为 craft-anything-cli
```

- 需要 Rust **1.97+**（`rustup update`）。
- Debian/Ubuntu 桌面端需先装 libxkbcommon、wayland、x11 等依赖。

## 验证安装

```sh
craft-anything-cli doctor    # 检查 CLI、编码代理、引擎是否就绪
craft-anything-cli commands  # 列出全部 320 个工具，按 toolset 分组
```

## 编码代理（Build 步骤依赖）

Build 需要本机已登录的编码代理，Craft Anything 不接触用户的账号：

- **Claude Code**：支持最完善（运行用户自己的 `claude` 程序，使用其自身登录）。
- **Codex**：适配器已建但未实测。
- **GitHub Copilot / Grok Build**：通过 ACP，需分别 `copilot login` / `grok login`。
- **ACP 兼容代理**：Gemini CLI、Qwen Code、opencode、goose、Hermes、Maki、Devin（Maki 与 Devin 已实测）。
- 问题/分析类调用可用 Anthropic、OpenAI、OpenRouter、xAI（需 `XAI_API_KEY`）及本地 OpenAI 兼容服务器。

运行 `craft-anything-cli doctor` 可查看缺少什么。

## 项目目录结构

新项目默认存放在 `Documents/Craft Anything`（Settings → General 可改）：

```
<project>/
├── craft.json           # 项目元数据
├── capture/             # 对目标的采集数据
├── app/                 # 重建生成的应用（"素材"模式下生成在此）
├── checks/              # 校验结果
├── investigation.cany/  # 调查/证据数据
└── inbox/               # 收件箱
```

## 版本状态

项目处于 **early alpha**（文档基于 v0.6.1）。与 Claude Code 配合的网站/应用/游戏完整流程已可用；其他代理与 API-key 方式的 Build 尚未实测。
