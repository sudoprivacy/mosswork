---
name: skillhub-skill-dalle-3-batch-asset-generator
description: "使用 OpenAI Images API（POST /v1/images/generations）和 DALL-E 3，通过结构化提示模板应用品牌指南，从单一简述生成多个图像变体。使用重试逻辑处理并发生成请求以符合速率限制。"
---

# DALL-E 3 批量资产生成器

使用 OpenAI Images API（POST /v1/images/generations）和 DALL-E 3，通过结构化提示模板应用品牌指南，从单一简述生成多个图像变体。使用重试逻辑处理并发生成请求以符合速率限制。

## 安装

使用与您的环境匹配的上游安装或设置路径：
- npm install openai
- npx jsr add @openai/openai

来自上游的要求和注意事项：
- 此库的完整 API 可在 [api.md 文件](api.md) 中找到，并包含许多 [代码示例](https://github.com/1991513ccie-png/skills)。
- // 如果您有访问 Node fs 的权限，我们建议使用 fs.createReadStream()：
- await client.chat.completions.create({ messages: [{ role: 'user', content: '如何使用 Python 列出目录中的所有文件？' }], model: 'gpt-5.2' }, {

基本用法或入门笔记：
- sh
- deno add jsr:@openai/openai
- 这些命令将使模块可以从 @openai/openai 作用域中导入。如果您...

- Source: https://github.com/1991513ccie-png/skills
- Extracted from upstream docs: https://raw.githubusercontent.com/openai/openai-node/HEAD/README.md
