# 建筑、工程与工程管理领域国际期刊参考手册

## 领域定位

本手册聚焦 **AI（计算机视觉/NLP/知识图谱/深度学习）× MR（混合现实/AR/VR）× BIM（数字孪生/建筑信息模型）** 在建筑全生命周期中的交叉研究，覆盖以下专业领域的国际英文期刊：

- 建筑学（Architecture）& 土木工程（Civil Engineering）
- 工程管理（Engineering / Construction Management）
- 施工技术（Construction Technology）
- 智能建造（Intelligent / Smart Construction）
- AI+建筑（AI Applications in AEC：计算机视觉、NLP、生成式AI、知识图谱）
- MR+建筑（AR/VR/MR in AEC：沉浸式可视、现场引导、数字孪生交互）
- BIM / 数字孪生（BIM & Digital Twin）

---

## 一、交叉领域场景图谱

### AI × MR × BIM 技术交汇矩阵

以下矩阵展示三大核心技术在不同建筑生命周期阶段的交叉应用场景，每个场景对应一组优先投稿期刊。

| 生命周期阶段 | AI × BIM | MR × BIM | AI × MR × BIM |
|------------|----------|---------|--------------|
| **设计阶段** | 生成式设计（GAN/Diffusion）、AI 规范审查、知识图谱驱动设计 | VR 沉浸式设计评审、MR 方案比选、全息模型展示 | AI 实时分析 MR 评审反馈、智能设计修改建议 |
| **施工阶段** | CV 进度监控、缺陷自动检测、NLP 安全报告分析、施工调度 AI | AR 现场施工引导、隐蔽工程可视化、MR 远程协作 | **智能巡检**：AI 分析 MR 现场数据 vs BIM 偏差检测、MR 智能装配引导 |
| **运维阶段** | 数字孪生+AI 预测维护、能耗 AI 优化、故障诊断 | MR 设施管理、AR 维修手册叠加、设备状态可视化 | AI+MR 交互式数字孪生、智能空间理解导航 |
| **拆除/改造** | 建筑垃圾 AI 分拣、结构安全性 AI 评估 | MR 改造方案预览、管线 AR 透视 | AI 识别可回收材料 + MR 拆除方案可视化 |

### 各场景对应的投稿潜力分析

| 应用场景 | 技术主导 | AEC 核心期刊 | 最佳跨界期刊 | 跨界优势 |
|---------|---------|------------|------------|---------|
| AI 生成式设计 | AI 主导 | Automation in Construction | EAAI, Expert Systems with Applications | AI 方法创新在 AI 期刊评价更高 |
| CV 施工进度监控 | AI 主导 | Automation in Construction | Engineering Applications of AI | CV 算法贡献可投纯 AI 期刊 |
| MR 现场施工引导 | MR 主导 | Automation in Construction | Virtual Reality (Springer) | VR 期刊看重交互创新 |
| AR 装配/培训 | MR 主导 | ECAM, Buildings | Virtual Reality, IJHCS | HCI 维度是差异化加分项 |
| IoT+AI 能耗预测 | AI+IoT 主导 | Building and Environment | Sensors, IEEE IoT Journal | 传感器方法学适合 IoT 期刊 |
| 数字孪生+AI 运维 | BIM+AI 主导 | Automation in Construction, ITcon | Sustainable Cities and Society | 可持续叙事提升 IF 天花板 |
| Scan-to-BIM（点云→BIM） | AI+C V 主导 | Automation in Construction | ISPRS, IJGIS | 遥感/摄影测量期刊直接对口 |
| NLP 工程文档解析 | AI 主导 | Advanced Engineering Informatics | Expert Systems with Applications | NLP 模型创新在 AI 期刊更受认可 |
| 建筑碳排放 AI 预测 | AI+可持续 | Building and Environment | J. of Cleaner Production | 可持续期刊 IF 极高（11+） |
| 知识图谱+建筑规范 | AI 主导 | Advanced Engineering Informatics | EAAI | 知识工程是 AI 期刊核心方向 |

---

## 二、期刊评价指标体系

### 审稿周期

| 等级 | 周期 | 推荐策略 |
|------|------|----------|
| 极快 | < 4 周 | 保障档首选 |
| 较快 | 4-6 周 | 核心档/保障档 |
| 一般 | 6-10 周 | 核心档 |
| 较慢 | 10-14 周 | 主推档 |
| 慢 | > 14 周 | 仅顶级论文 |

### 接受率

| 等级 | 接受率 | 推荐策略 |
|------|--------|----------|
| 高 | > 35% | 保障档 |
| 中等偏上 | 25-35% | 核心档 |
| 中等 | 15-25% | 主推档 |
| 较低 | < 15% | 仅极高质量论文 |

### APC 分级（美元）

| 等级 | 费用 | 说明 |
|------|------|------|
| 免费 | $0 | 传统订阅期刊（混合模式选非 OA），不产生 APC |
| 低价 | < $1,000 | 部分学会期刊或发展中地区期刊 |
| 中等 | $1,000-$2,000 | MDPI、Frontiers 等常见 OA 出版商 |
| 较高 | $2,000-$3,000 | Elsevier/Springer/Taylor & Francis 旗下 OA |
| 高 | > $3,000 | 顶级 OA 期刊 |

### JCR 分区说明

- **SCI Q1**：顶级期刊，IF 排名前 25%
- **SCI Q2**：高质量期刊，IF 排名 25-50%
- **SCI Q3**：中等期刊，IF 排名 50-75%
- **SCI Q4**：入门级 SCI 期刊，IF 排名 75-100%
- **ESCI**：新兴期刊，已被 WoS 收录但尚未获得 IF
- **Scopus（非SCI）**：被 Scopus 收录但未被 WoS 收录

---

## 三、AEC 核心期刊数据库

### A. BIM / 智能建造 / 建筑自动化

#### Automation in Construction
- **出版商**：Elsevier（荷兰）
- **ISSN**：0926-5805
- **IF**：~11.3（2024）；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周
- **接受率**：~15-20%
- **APC**：混合模式，非 OA 免费；OA 约 $3,150
- **方向**：BIM、数字孪生、建筑机器人、自动化施工、AI 在建造中的应用
- **定位**：🏆 主推档 | AEC 数字化顶级期刊
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐⭐ | 最核心目标期刊
- **特点**：审稿严格，要求方法创新和数据扎实；国人发文量高

#### Journal of Information Technology in Construction (ITcon)
- **出版商**：ITcon（开放获取）
- **ISSN**：1874-4753
- **IF**：~3.5；Scopus Q1，ESCI
- **审稿周期**：约 6-8 周
- **接受率**：~25-30%
- **APC**：**完全免费**（OA 无 APC）
- **方向**：BIM、信息技术在建筑中的应用、建筑信息化
- **定位**：✅ 核心档 | BIM/IT 方向优质免费 OA
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐ | IT+BIM 直接对口

#### Journal of Intelligent Construction（清华大学出版社）
- **出版商**：清华大学出版社 / SciOpen
- **ISSN**：2958-3861
- **IF**：暂无（2023 年创刊）
- **审稿周期**：约 4-6 周
- **APC**：创刊期免费/低价
- **方向**：智能建造、智慧工地、建造机器人、建筑施工数字化
- **定位**：🛡️ 保障档 | 中国主办，对国内学者友好
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐⭐ | 定位完全对口

#### Smart Construction (ELSPublishing)
- **出版商**：ELSPublishing
- **IF**：暂无（新创期刊）
- **审稿周期**：约 4-6 周
- **APC**：低（新刊优惠期）
- **方向**：智能建造、数字施工、自动化
- **定位**：🛡️ 保障档 | 新创期刊，审稿快门槛低
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐ |

#### Architectural Intelligence（Springer Nature）
- **出版商**：Springer Nature
- **ISSN**：2731-6726
- **IF**：暂无（2024 年创刊）
- **审稿周期**：约 4-8 周
- **APC**：创刊初期可能免费或低价
- **方向**：AI 与建筑交叉——生成式 AI、智能设计、参数化设计
- **定位**：🛡️ 保障档 | AI+建筑前沿新刊
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐⭐ | AI+建筑直接对口

---

### B. 施工管理 / 工程管理 / 项目管理

#### Journal of Construction Engineering and Management (JCEM)
- **出版商**：ASCE（美国土木工程师学会）
- **ISSN**：0733-9364
- **IF**：~4.5；JCR Q1，中科院 2 区
- **审稿周期**：约 6-8 周
- **接受率**：~20-25%
- **APC**：混合模式，非 OA 免费
- **方向**：施工技术、项目进度控制、质量管理、成本优化、安全管理
- **定位**：🏆 主推档 | 全球最具影响力的施工管理期刊
- **AI/MR/BIM 匹配度**：⭐⭐⭐ | 传统施工管理，对新技术论文接纳度中等

#### International Journal of Project Management (IJPM)
- **出版商**：Elsevier
- **ISSN**：0263-7863
- **IF**：~6.0；JCR Q1，SSCI/SCI 双收录，中科院 1 区
- **审稿周期**：约 8-12 周
- **接受率**：~15%
- **APC**：混合模式，非 OA 免费
- **方向**：项目生命周期管理、风险评估、组织行为、大型项目管理
- **定位**：🏆 主推档 | 项目管理顶级期刊
- **AI/MR/BIM 匹配度**：⭐⭐ | 偏管理学，技术论文需包装为管理贡献

#### Journal of Management in Engineering (JME)
- **出版商**：ASCE
- **ISSN**：0742-597X
- **IF**：~5.0；JCR Q1，中科院 1 区
- **审稿周期**：约 8-10 周
- **接受率**：~18-22%
- **APC**：混合模式，非 OA 免费
- **方向**：工程管理、组织行为、创新管理
- **定位**：🏆 主推档 | ASCE 管理类旗舰

#### Engineering, Construction and Architectural Management (ECAM)
- **出版商**：Emerald
- **ISSN**：0969-9988
- **IF**：~3.5；JCR Q2，Scopus
- **审稿周期**：约 4-6 周（**较快**）
- **接受率**：~30-35%
- **APC**：混合模式
- **方向**：建筑工程管理、实证研究、案例分析、施工管理实践
- **定位**：✅ 核心档 | 审稿快，实践导向论文友好
- **AI/MR/BIM 匹配度**：⭐⭐⭐ | 新技术应用论文可以投

#### Construction Management and Economics
- **出版商**：Taylor & Francis
- **ISSN**：0144-6193
- **IF**：~3.0；JCR Q2
- **审稿周期**：约 8-10 周
- **接受率**：~25-30%
- **APC**：混合模式
- **方向**：工程经济学视角、PPP 模式、投融资结构、绩效评价

#### Built Environment Project and Asset Management (BEPAM)
- **出版商**：Emerald
- **ISSN**：2044-124X
- **IF**：~2.0；Scopus Q2，ESCI
- **审稿周期**：约 6-8 周
- **接受率**：~30-35%
- **APC**：混合模式
- **方向**：建筑环境项目管理、资产管理、设施管理

#### International Journal of Construction Management
- **出版商**：Taylor & Francis
- **ISSN**：1562-3599
- **IF**：~3.0；Scopus Q1，ESCI
- **审稿周期**：约 6-8 周
- **接受率**：~30%
- **APC**：混合模式
- **方向**：施工管理全领域

#### Construction Innovation
- **出版商**：Emerald
- **ISSN**：1471-4175
- **IF**：~3.0；JCR Q2，SCIE
- **审稿周期**：约 6-8 周
- **接受率**：~25-30%
- **APC**：混合模式
- **方向**：建筑创新技术、新技术应用、创新管理
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐ | 创新技术直接对口

---

### C. 建筑 / 建筑工程 / 结构 / 材料

#### Journal of Building Engineering
- **出版商**：Elsevier（荷兰）
- **ISSN**：2352-7102
- **IF**：7.4（2024）；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-10 周（LetPub 速度评分 8.1/10）
- **接受率**：~25-30%
- **APC**：混合模式，非 OA 免费（Gold OA ~10%）
- **方向**：建筑工程综合——结构、材料、能源、施工
- **定位**：🏆 主推档 | 建筑工程热门综合期刊
- **AI/MR/BIM 匹配度**：⭐⭐⭐ | 综合覆盖，但对纯 IT 论文匹配度一般

#### Building and Environment
- **出版商**：Elsevier
- **ISSN**：0360-1323
- **IF**：~7.0；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周
- **接受率**：~20%
- **APC**：混合模式，非 OA 免费
- **方向**：建筑环境科学、室内环境、建筑能耗、热舒适
- **AI/MR/BIM 匹配度**：⭐⭐ | 偏物理环境，AI+环境监测方向可投

#### Energy and Buildings
- **出版商**：Elsevier
- **ISSN**：0378-7788
- **IF**：~6.7；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-10 周
- **APC**：混合模式
- **方向**：建筑能耗、节能技术、暖通空调
- **AI/MR/BIM 匹配度**：⭐⭐ | AI 能耗预测方向可投

#### Buildings (MDPI)
- **出版商**：MDPI（瑞士）
- **ISSN**：2075-5309
- **IF**：~3.0；JCR Q2，中科院 3 区
- **审稿周期**：约 4-6 周（**快**）
- **接受率**：~45-50%
- **APC**：CHF 2,400（约 $2,600）
- **方向**：建筑科学全领域——BIM、智能建筑、结构、材料、能源、施工管理
- **定位**：✅ 核心档 | 收稿广、审稿快、接受率高
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐ | 包容性强，新技术论文容易命中

#### Architectural Engineering and Design Management
- **出版商**：Taylor & Francis
- **ISSN**：1745-2007
- **IF**：~2.5；JCR Q3，SCIE
- **审稿周期**：约 6-8 周
- **接受率**：~30%
- **APC**：混合模式

#### Journal of Civil Engineering and Management
- **出版商**：VILNIUS TECH（立陶宛）
- **ISSN**：1392-3730
- **IF**：~4.0；JCR Q1
- **审稿周期**：约 6-8 周
- **APC**：OA，约 €700（**极低**）
- **方向**：土木工程与管理交叉
- **定位**：✅ 核心档 | 性价比极高的 Q1 OA 期刊

#### KSCE Journal of Civil Engineering
- **出版商**：Springer（韩国土木工程师学会）
- **ISSN**：1226-7988
- **IF**：~2.0；JCR Q3，SCIE
- **审稿周期**：约 6-10 周
- **接受率**：~30-35%
- **APC**：混合模式
- **定位**：✅ 核心档 | 国人友好，接受率较高

#### Frontiers in Built Environment
- **出版商**：Frontiers（瑞士）
- **ISSN**：2297-3362
- **IF**：~2.5；Scopus Q2，ESCI
- **审稿周期**：约 6-10 周
- **接受率**：~40%
- **APC**：OA，约 $1,150
- **方向**：建筑环境全领域——结构、施工、交通、建筑物理
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐ | 包容性强

#### Advances in Civil Engineering (Hindawi/Wiley)
- **出版商**：Hindawi（Wiley 旗下）
- **ISSN**：1687-8086
- **IF**：~1.8；JCR Q4，SCIE
- **审稿周期**：约 4-6 周
- **接受率**：~40-50%
- **APC**：OA，约 $1,300
- **定位**：🛡️ 保障档 | 接受率高、审稿快
- **注意**：2023-2024 年 Hindawi 撤稿风波，投稿前核实当前状态

#### Smart and Sustainable Built Environment
- **出版商**：Emerald
- **ISSN**：2046-6099
- **IF**：~3.5；JCR Q2，SCIE
- **审稿周期**：约 6-8 周
- **方向**：智能建筑、可持续建筑环境、智慧城市

---

### D. AI+建筑 / 工程信息学

#### Advanced Engineering Informatics
- **出版商**：Elsevier
- **ISSN**：1474-0346
- **IF**：~6.5；JCR Q1，中科院 1 区
- **审稿周期**：约 8-10 周
- **接受率**：~20-25%
- **APC**：混合模式
- **方向**：工程信息学、AI 在工程中的应用、知识工程
- **定位**：🏆 主推档 | AI+工程交叉方向顶刊
- **AI/MR/BIM 匹配度**：⭐⭐⭐⭐⭐ | 直接对口

#### Computer-Aided Civil and Infrastructure Engineering
- **出版商**：Wiley
- **ISSN**：1093-9687
- **IF**：~9.0；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周
- **接受率**：~15%
- **APC**：混合模式
- **方向**：计算机辅助工程、土木基础设施智能化
- **定位**：🏆 主推档 | 计算+土木交叉顶级

---

## 四、跨领域 / 弱相关潜力期刊

> **跨界投稿策略**：当论文的核心技术贡献（如 AI 算法创新、MR 交互设计、IoT 传感方案）超出传统 AEC 期刊的评价框架时，应考虑向该技术主导学科的期刊投稿。建筑应用场景作为差异化亮点，在 AI/VR/IoT 等期刊中反而具有竞争优势。

### E1. AI / 计算机科学 / 工程应用类

#### Engineering Applications of Artificial Intelligence (EAAI)
- **出版商**：Elsevier
- **ISSN**：0952-1976
- **IF**：~7.5（2024）；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周（投稿量极大，近年激增）
- **接受率**：~20-25%
- **APC**：混合模式
- **方向**：AI 在各工程分支中的应用
- **投稿潜力**：⭐⭐⭐⭐⭐ | AI+BIM/施工的论文天然对口
- **跨界策略**：强调 AI 方法的创新性，建筑场景作为应用验证
- **风险提示**：2025 年投稿量激增 6000+，官网紧急调整审稿流程

#### Expert Systems with Applications
- **出版商**：Elsevier
- **ISSN**：0957-4174
- **IF**：~8.5；JCR Q1，中科院 1 区
- **审稿周期**：约 6-8 周
- **接受率**：~18-22%
- **APC**：混合模式
- **方向**：专家系统、知识工程、AI 应用系统
- **投稿潜力**：⭐⭐⭐⭐ | AI 知识图谱+建筑规范审查方向对口
- **跨界策略**：强调知识表示和推理方法，建筑领域是应用案例

#### Applied Soft Computing
- **出版商**：Elsevier
- **ISSN**：1568-4946
- **IF**：~7.2；JCR Q1，中科院 1 区
- **审稿周期**：约 8-10 周
- **接受率**：~22-25%
- **APC**：混合模式
- **方向**：软计算方法（模糊逻辑、进化算法、神经网络）应用
- **投稿潜力**：⭐⭐⭐ | 施工调度优化、建筑能耗多目标优化

#### Neural Computing and Applications
- **出版商**：Springer
- **ISSN**：0941-0643
- **IF**：~5.6；JCR Q2，中科院 2 区
- **审稿周期**：约 6-10 周
- **接受率**：~25-30%
- **APC**：混合模式
- **方向**：神经计算与深度学习在各领域的应用
- **投稿潜力**：⭐⭐⭐ | CV 施工监控、深度学习 BIM 应用

---

### E2. VR / MR / 可视化 / 计算机图形学类

#### Virtual Reality (Springer)
- **出版商**：Springer
- **ISSN**：1359-4338
- **IF**：~5.5；JCR Q1（Computer Graphics），中科院 2 区
- **审稿周期**：约 6-8 周
- **接受率**：~25-30%
- **APC**：混合模式
- **方向**：VR、AR、MR 技术及应用——人机交互、可视化
- **投稿潜力**：⭐⭐⭐⭐⭐ | MR 建筑应用的核心跨界目标
- **跨界策略**：强调 MR 交互技术创新，建筑施工是差异化应用场景

#### The Visual Computer
- **出版商**：Springer
- **ISSN**：0178-2789
- **IF**：~3.5；JCR Q2，中科院 3 区
- **审稿周期**：约 6-10 周
- **接受率**：~28-33%
- **APC**：混合模式
- **方向**：计算机图形学、可视化、几何建模
- **投稿潜力**：⭐⭐⭐ | BIM 可视化、3D 重建、点云渲染

#### Computers & Graphics
- **出版商**：Elsevier
- **ISSN**：0097-8493
- **IF**：~2.5；JCR Q2
- **审稿周期**：约 8-10 周
- **方向**：计算机图形学、交互技术
- **投稿潜力**：⭐⭐⭐ | MR 渲染、AR 交互

---

### E3. IoT / 传感器 / 数据科学类

#### Sensors (MDPI)
- **出版商**：MDPI
- **ISSN**：1424-8220
- **IF**：~3.4；JCR Q2，中科院 3 区
- **审稿周期**：约 4-6 周（**极快**）
- **接受率**：~50%
- **APC**：CHF 2,600（约 $2,800）
- **方向**：传感器技术及应用——IoT、环境监测、结构健康监测
- **投稿潜力**：⭐⭐⭐⭐ | 建筑施工传感器、结构监测、BIM+IoT 数据采集
- **跨界策略**：强调传感器方案创新，建筑施工是应用场景
- **注意**：MDPI 系列，确认本单位认可政策

#### IEEE Internet of Things Journal
- **出版商**：IEEE
- **ISSN**：2327-4662
- **IF**：~10.6；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周
- **接受率**：~15%
- **APC**：混合模式
- **方向**：IoT 架构、应用、安全——智慧城市、智能建筑
- **投稿潜力**：⭐⭐⭐ | 智能楼宇 IoT 系统架构方向

#### Future Generation Computer Systems
- **出版商**：Elsevier
- **ISSN**：0167-739X
- **IF**：~7.5；JCR Q1
- **方向**：下一代计算系统——云计算、边缘计算、数字孪生
- **投稿潜力**：⭐⭐⭐ | 建筑数字孪生计算架构

---

### E4. 可持续 / 智慧城市 / 低碳类

#### Sustainable Cities and Society
- **出版商**：Elsevier
- **ISSN**：2210-6707
- **IF**：~11.7；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 6-10 周
- **接受率**：~20%
- **APC**：混合模式
- **方向**：智慧城市、可持续城市基础设施、低碳建筑
- **投稿潜力**：⭐⭐⭐⭐ | AI+建筑碳排放/BIM+可持续方向极佳
- **跨界策略**：突出可持续/减碳叙事，AI/BIM 是技术手段

#### Journal of Cleaner Production
- **出版商**：Elsevier
- **ISSN**：0959-6526
- **IF**：~11.1；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周
- **接受率**：~22-25%
- **APC**：混合模式
- **方向**：清洁生产、循环经济、全生命周期评估
- **投稿潜力**：⭐⭐⭐⭐ | 建筑碳排放、绿色建材、LCA+AI
- **跨界策略**：强调清洁生产/循环经济贡献

#### Cities
- **出版商**：Elsevier
- **ISSN**：0264-2751
- **IF**：~6.7；JCR Q1，SSCI
- **审稿周期**：约 8-12 周
- **方向**：城市规划、城市政策、智慧城市治理
- **投稿潜力**：⭐⭐⭐ | 城市尺度的 BIM/AI 应用

---

### E5. 制造 / 机器人 / 工业工程类

#### Journal of Intelligent Manufacturing
- **出版商**：Springer
- **ISSN**：0956-5515
- **IF**：~12.0；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-10 周
- **接受率**：~15-18%
- **方向**：智能制造、工业 4.0、AI 驱动的制造
- **投稿潜力**：⭐⭐⭐ | 建筑机器人、自动化施工、3D 打印建筑

#### Robotics and Computer-Integrated Manufacturing
- **出版商**：Elsevier
- **ISSN**：0736-5845
- **IF**：~10.4；JCR Q1
- **方向**：机器人技术与计算机集成制造
- **投稿潜力**：⭐⭐⭐ | 施工机器人、BIM 驱动的预制装配

---

### E6. HCI / 人机交互类

#### International Journal of Human-Computer Studies (IJHCS)
- **出版商**：Elsevier
- **ISSN**：1071-5819
- **IF**：~5.0；JCR Q1，SSCI/SCI 双收录
- **审稿周期**：约 8-12 周
- **接受率**：~18-22%
- **APC**：混合模式
- **方向**：人机交互研究——可用性、用户体验、交互设计
- **投稿潜力**：⭐⭐⭐⭐ | MR 建筑交互的用户研究、AR 可用性评估
- **跨界策略**：强调人机交互方法论，建筑场景是实证研究载体

---

### E7. 遥感 / 测绘 / 地理信息类

#### ISPRS Journal of Photogrammetry and Remote Sensing
- **出版商**：Elsevier
- **ISSN**：0924-2716
- **IF**：~12.7；JCR Q1，中科院 1 区 Top
- **审稿周期**：约 8-12 周
- **接受率**：~18-22%
- **方向**：摄影测量、遥感、点云处理、3D 重建
- **投稿潜力**：⭐⭐⭐⭐ | Scan-to-BIM、激光扫描+AI、点云到 BIM 自动重建
- **跨界策略**：强调遥感/测绘技术创新，建筑 BIM 是应用出口

#### International Journal of Geographical Information Science (IJGIS)
- **出版商**：Taylor & Francis
- **ISSN**：1365-8816
- **IF**：~5.7；JCR Q1
- **方向**：地理信息科学、空间分析、GIS
- **投稿潜力**：⭐⭐⭐ | GIS+BIM 集成、城市尺度建筑数据

---

## 五、快速选刊矩阵

### 按梯度分类速查

#### 🏆 主推档（冲刺）— IF > 4.0，Q1 区

| 期刊 | IF | 核心匹配方向 |
|------|-----|------------|
| ISPRS Journal of Photogrammetry | 12.7 | 点云→BIM |
| J. of Intelligent Manufacturing | 12.0 | 建筑机器人 |
| Sustainable Cities and Society | 11.7 | AI+低碳建筑 |
| Automation in Construction | 11.3 | BIM/数字孪生/AI |
| J. of Cleaner Production | 11.1 | 碳排放+AI |
| IEEE IoT Journal | 10.6 | 智能楼宇 IoT |
| Robotics and CIM | 10.4 | 施工机器人 |
| Computer-Aided Civil and Infra. Eng. | 9.0 | 计算+土木 |
| Expert Systems with Applications | 8.5 | AI 知识工程 |
| Engineering Applications of AI | 7.5 | AI 工程应用 |
| Future Generation Computer Systems | 7.5 | 数字孪生计算 |
| Journal of Building Engineering | 7.4 | 建筑工程综合 |
| Applied Soft Computing | 7.2 | 软计算优化 |
| Building and Environment | 7.0 | 建筑环境 |
| Energy and Buildings | 6.7 | 建筑能源 |
| Cities | 6.7 | 智慧城市 |
| Advanced Engineering Informatics | 6.5 | AI+工程信息学 |
| International Journal of Project Management | 6.0 | 项目管理 |

#### ✅ 核心档（稳妥）— IF 2.0-4.0，Q2-Q3 区

| 期刊 | IF | 核心匹配方向 |
|------|-----|------------|
| IJGIS | 5.7 | GIS+BIM |
| Neural Computing and Applications | 5.6 | 深度学习应用 |
| Virtual Reality (Springer) | 5.5 | MR 建筑应用 |
| IJHCS | 5.0 | MR 人机交互 |
| Journal of Civil Engineering and Management | 4.0 | 土木工程与管理 |
| Smart and Sustainable Built Environment | 3.5 | 智能可持续 |
| ECAM | 3.5 | 建筑工程管理 |
| ITcon | 3.5 | BIM/IT（免费） |
| The Visual Computer | 3.5 | 可视化 |
| Sensors (MDPI) | 3.4 | IoT 传感器 |
| Buildings (MDPI) | 3.0 | 建筑全领域 |
| Construction Management and Economics | 3.0 | 工程经济学 |
| Int. J. of Construction Management | 3.0 | 施工管理 |
| Construction Innovation | 3.0 | 建筑创新 |
| Computers & Graphics | 2.5 | 计算机图形 |
| Architectural Eng. and Design Mgmt. | 2.5 | 工程设计管理 |
| Frontiers in Built Environment | 2.5 | 建筑环境综合 |
| Built Environment Proj. & Asset Mgmt. | 2.0 | 项目资产管理 |
| KSCE Journal of Civil Engineering | 2.0 | 土木工程综合 |

#### 🛡️ 保障档（保底）— IF < 2.0 或暂无 IF

| 期刊 | IF | 核心匹配方向 |
|------|-----|------------|
| Advances in Civil Engineering | 1.8 | 土木工程广泛 |
| Journal of Intelligent Construction | 暂无 | 智能建造（新刊） |
| Architectural Intelligence | 暂无 | AI+建筑（新刊） |
| Smart Construction | 暂无 | 智能建造（新刊） |

---

## 六、搜索策略与工具

### 中文渠道

```
site:letpub.com.cn "BIM" OR "建筑信息模型" "审稿周期"
"智能建造" OR "智慧工地" SCI期刊 审稿周期 录用
"AI" OR "深度学习" "建筑" OR "施工" SCI 投稿经验
"混合现实" OR "AR" OR "VR" "建筑" 期刊
site:zhihu.com "Automation in Construction" 投稿经验
```

### 英文渠道

```
"{keyword}" journal SCImago quartile
"BIM" OR "digital twin" construction journal acceptance rate
"mixed reality" OR "augmented reality" construction journal
"AI" OR "deep learning" "building" journal fast review
"computer vision" construction site monitoring journal
```

### 期刊查询关键平台

| 平台 | 用途 | URL |
|------|------|-----|
| LetPub 期刊查询 | 审稿周期、录用率、国人投稿经验 | letpub.com.cn |
| SCImago Journal Rank | Q 分区、H-index | scimagojr.com |
| DOAJ | OA 期刊合法性核查 | doaj.org |
| JCR | 官方影响因子（需机构订阅） | jcr.clarivate.com |
| 中科院分区表 | 国内分区参考 | fenqubiao.com |

---

## 七、投稿避坑指南

### 掠夺性期刊预警

- 承诺"保证录用"或极短审稿周期（< 1 周）
- 期刊名称与知名期刊极其相似
- 未在 DOAJ / Scopus / WoS 中收录
- 大量发送垃圾邮件征集稿件

### 时效性提醒

- **Hindawi/Wiley**：2023-2024 年大规模撤稿，投稿前务必核实当前状态
- **MDPI**：审稿快、接受率高，但部分高校/学科不认可，投稿前了解本单位政策
- **新创期刊**：审稿快门槛低，但 IF 和认可度需时间积累
- **Elsevier/Springer 混合模式**：可选非 OA 发表省去 APC，但文章传播力略低

### 跨界投稿特别注意

- **Cover Letter 策略**：向 AI/VR/IoT 期刊投稿时，Cover Letter 应强调技术创新（算法/交互/系统），建筑场景作为差异化应用亮点而非核心卖点
- **引用策略**：投稿非 AEC 期刊时，建议引用目标期刊近 2 年发表的 3-5 篇该领域论文，建立学科关联
- **关键词策略**：跨界投稿时，标题和关键词应同时包含技术术语和领域术语（如 "Deep Learning for Automated BIM..."）

---

> **数据说明**：以上 IF、审稿周期、APC 等数据基于 2024-2025 年公开信息整理，可能已有变动。推荐时需通过 WebSearch 实时核实最新数据，并在输出中标注数据来源和年份。

---

## 八、论文质量评估 — 期刊映射速查

### 质量-期刊梯度映射

| 质量等级 | 加权分 | 推荐期刊 IF 范围 | 示例期刊（AEC核心） | 示例期刊（跨界） |
|:-------:|:-----:|:---------------:|-------------------|-----------------|
| **A 级** | 4.0-5.0 | IF 7-12+ | Automation in Construction (11.3), J. of Building Engineering (7.4) | Sustainable Cities and Society (11.7), ISPRS (12.7) |
| **B 级** | 3.0-3.9 | IF 3-7 | JCEM (4.5), ECAM (3.5), Buildings (3.0) | EAAI (7.5), Virtual Reality (5.5), Sensors (3.4) |
| **C 级** | 2.0-2.9 | IF 1.5-4 | ITcon (3.5), KSCE (2.0), Frontiers in Built Env. (2.5) | Neural Computing (5.6), Computers & Graphics (2.5) |
| **D 级** | 1.0-1.9 | IF < 2 / 无 | Advances in Civil Eng. (1.8), J. of Intelligent Construction (新刊) | Smart Construction (新刊), Architectural Intelligence (新刊) |
| **E 级** | < 1.0 | 不建议投稿 | — | — |

### C/D 级低成本/免费期刊速查

| 期刊 | APC | 审稿周期 | 质量等级适配 |
|------|-----|:-------:|:----------:|
| ITcon | **免费** | 6-8 周 | C 级首选 |
| J. of Civil Engineering and Management | ~€700 | 6-8 周 | C 级 |
| Smart Construction | 新刊低价 | 4-6 周 | C/D 级 |
| Architectural Intelligence | 创刊期免费 | 4-8 周 | C/D 级 |
| J. of Intelligent Construction | 创刊期免费 | 4-6 周 | C/D 级 |
| JCEM (选非OA) | 免费 | 6-8 周 | B/C 级 |
| J. of Building Engineering (选非OA) | 免费 | 8-10 周 | A/B 级 |
