---
name: skillhub-skill-bili-main-life
description: "当用户想按 B 站「生活」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：生活、B站分区、rid 160。"
---

# B 站分区 · 生活

- 一级分区 rid：`160`；网页路由：`/v/life/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 94 条榜单条目，覆盖 7 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 三农 | 3 | 9 | 251 |
| 亲子 | 1 | 10 | 254 |
| 出行 | 8 | 10 | 250 |
| 手工 | 2 | 9 | 161 |
| 搞笑 | 46 | 10 | 138 |
| 日常 | 28 | 10 | 21 |
| 绘画 | 6 | 9 | 162 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 三农

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 要东西教程 | 农民入门指南_Official | [BV1LzRvYiEkw](https://www.bilibili.com/video/BV1LzRvYiEkw) | 214.3 万 |
| 这叫实力，懂吗 | 农人你三哥 | [BV1uDdnYREW1](https://www.bilibili.com/video/BV1uDdnYREW1) | 156.5 万 |
| 重磅十年规划发布！不是刻意低调！我们离农业强国还有多远？【主播说三农】 | 央视农业 | [BV152dpYKEsx](https://www.bilibili.com/video/BV152dpYKEsx) | 112.4 万 |
| 猪友们开饭了，又来砍猪食了 | 山野农夫瑙叔 | [BV11HRqYREiG](https://www.bilibili.com/video/BV11HRqYREiG) | 628.5 万 |
| 十年后再看今天 | 乡村教师日记 | [BV1yNRBYxEiq](https://www.bilibili.com/video/BV1yNRBYxEiq) | 78.6 万 |

### 亲子

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 《后丘摔了》 | 灿灿的远 | [BV1NpZdYUEAZ](https://www.bilibili.com/video/BV1NpZdYUEAZ) | 384.7 万 |
| 惟愿不负所学，不辱所托。努力把翻译做好，也希望没让大家失望。昨天200多斤的我跑了一天，回家直接瘫了，大家的留言我都看见了，今晚继续发作品，和大家聊聊这段经历 | 瑞哥英语_RyanChen | [BV1AtZ2YWE8D](https://www.bilibili.com/video/BV1AtZ2YWE8D) | 244.6 万 |
| 老公工作很辛苦，能做的只有让他回到家之后放松一下，有口热饭吃，能感受到温暖。 | 肖小芳和小谋哥 | [BV1BVR1YPENs](https://www.bilibili.com/video/BV1BVR1YPENs) | 134.5 万 |
| 男人，就得少说多做 | 淦淦惹 | [BV1gYfMY8Er3](https://www.bilibili.com/video/BV1gYfMY8Er3) | 75.8 万 |
| 我萌姐还是有两下子的(o^^o) | 这很吴雨 | [BV1tVdEYGEAL](https://www.bilibili.com/video/BV1tVdEYGEAL) | 55.4 万 |

### 出行

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 假装自己是日本社畜，错过末班地铁是什么下场？ | 康哟喂 | [BV1cVRSYSEWC](https://www.bilibili.com/video/BV1cVRSYSEWC) | 656.4 万 |
| 不看地图，我以为我来到了缅北 | 虎牙青年Plus | [BV1PSZfYoEuF](https://www.bilibili.com/video/BV1PSZfYoEuF) | 2476.8 万 |
| 幼年被父母抛弃后历尽苦难，最终身体崩溃挂壁东莞成为大神 | 摩的司机徐师傅 | [BV1BPZrYeESc](https://www.bilibili.com/video/BV1BPZrYeESc) | 273.3 万 |
| 水位下降，重庆水库里竟然发现千手观音！ | 逸明文化古迹 | [BV19BZ9YfEKz](https://www.bilibili.com/video/BV19BZ9YfEKz) | 218.7 万 |
| “有些人天生就喜欢这种氛围感” | 夷则青枫 | [BV1agZZYvExy](https://www.bilibili.com/video/BV1agZZYvExy) | 232.2 万 |

### 手工

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 我也有美美的遐蝶啦~ | 徐大花xudahua | [BV1d4R9YxEom](https://www.bilibili.com/video/BV1d4R9YxEom) | 436.9 万 |
| 穷且益坚，不坠青云之志 | 老猫吖cat | [BV1MEZ2Y8Ei8](https://www.bilibili.com/video/BV1MEZ2Y8Ei8) | 243.5 万 |
| 山猫脸下的真面目…… | 一杯不二茶 | [BV1trZmYYEvR](https://www.bilibili.com/video/BV1trZmYYEvR) | 281.4 万 |
| 标题：那些年买过的宿舍小零食！ | 谭井同学 | [BV1ttRRYyEtH](https://www.bilibili.com/video/BV1ttRRYyEtH) | 1491.1 万 |
| 微缩布书《锈湖往事》进来云玩一下吧 | 灰岩浣 | [BV15nZRYcE8o](https://www.bilibili.com/video/BV15nZRYcE8o) | 124.5 万 |

### 搞笑

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| speed和麦克阿瑟会晤 | 麦克阿瑟MacArthur | [BV1yXR9YBERZ](https://www.bilibili.com/video/BV1yXR9YBERZ) | 468.8 万 |
| 人类历史上第一次宿舍太空飞行 | 小叮当的伙伴们 | [BV1YTRDYkEUi](https://www.bilibili.com/video/BV1YTRDYkEUi) | 450.3 万 |
| 这样的房间你们喜欢吗？ | _张天琪 | [BV1ZXZRYMEpf](https://www.bilibili.com/video/BV1ZXZRYMEpf) | 1094.6 万 |
| 雀巢工作室史上最沉重的一期 | 7鲸尾 | [BV11iZXYGEF9](https://www.bilibili.com/video/BV11iZXYGEF9) | 440.0 万 |
| 身体：复！活！吧！我的主人！！ | 进击的金厂长 | [BV1eHZpYgELq](https://www.bilibili.com/video/BV1eHZpYgELq) | 244.2 万 |

### 日常

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 我们的两名消防员在救援中牺牲了 | 辽宁共青团 | [BV1x8RXYvEti](https://www.bilibili.com/video/BV1x8RXYvEti) | 369.2 万 |
| 人不可貌相 | 小猫影视CONECOFILM | [BV1NjZdYXE2N](https://www.bilibili.com/video/BV1NjZdYXE2N) | 423.0 万 |
| “主播 能不能做点二次元的丧葬用品？” | 汤木檀泽 | [BV1eZR1YAE8j](https://www.bilibili.com/video/BV1eZR1YAE8j) | 672.9 万 |
| 你们上学捉弄同桌嘛，哈哈哈啊哈 | 脱缰凯Kk | [BV1hERRYDE7i](https://www.bilibili.com/video/BV1hERRYDE7i) | 405.7 万 |
| 马上36岁啦，我还在做自己真好～ | 晋晋除了吃还是吃 | [BV1tzRBYAECn](https://www.bilibili.com/video/BV1tzRBYAECn) | 209.5 万 |

### 绘画

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| ♥⚡耗时270000秒只为让她摇起来⚡ | 枭樾特犟 | [BV1SKRdYUE2b](https://www.bilibili.com/video/BV1SKRdYUE2b) | 433.3 万 |
| 我的毕设动画完成了！！《浮生一戏》预告PV | 丁丁框sheya | [BV1prRoYCEPR](https://www.bilibili.com/video/BV1prRoYCEPR) | 255.5 万 |
| 小 画 家 判 官 | 幼儿园园长老凛 | [BV1YiZQYpExi](https://www.bilibili.com/video/BV1YiZQYpExi) | 285.1 万 |
| 只要你学会5000个魔法，我就答应和你结婚…… | Mr-Ferret | [BV1gARdYDEFS](https://www.bilibili.com/video/BV1gARdYDEFS) | 143.6 万 |
| 画人体，参考网站得了MVP！ | 蒲尔A | [BV1haZmYzEtb](https://www.bilibili.com/video/BV1haZmYzEtb) | 46.3 万 |

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：家居房产（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=160." https://api.bilibili.com/x/web-interface/ranking/v2?rid=160&type=all. Accessed 6 Nov. 2026.
