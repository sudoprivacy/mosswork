---
name: skillhub-skill-bilibili-automation-ops
description: "B站自动化运营。统一完成定时发布、自动回复、内容调度、数据监控告警，把B站运营动作收回到聊天里。触发词：B站自动发布、B站定时发视频、B站运营助手、自动回复弹幕、B站数据监控。"
---

# B站自动化运营

## 适用场景
用自动化手段完成B站日常运营动作，减少重复操作，提升内容分发效率。

## 功能说明

> 将发帖、回复、监控、数据导出等运营动作集成到工作流中，支持定时任务、关键词监控、自动预警。

## 这个案例能帮你做什么

- 定时发布视频/动态，无需手动操作
- 自动回复热门评论，提升互动率
- 监控竞品账号动态，及时响应
- 数据异常自动告警（播放量骤降、负面评论激增等）

## 你需要的 Skills

| 类型 | Skill / 工具 | 用途 | 来源 |
|---|---|---|---|
| 外部（需安装） | `bilibili-universal` | 抓取视频数据、评论、弹幕 | `clawhub install bilibili-universal` |
| 外部（需安装） | `bilibili-video-publish` | 视频发布 API 调用 | `clawhub install bilibili-video-publish` |
| 外部（可选） | `automation_update` | 定时任务调度 | WorkBuddy 内置 |
| 凭证 | B站 Cookie | 登录态访问API | 浏览器开发者工具 |

## 快速体验版（先跑一轮）

```text
你是我的B站运营助手。
请先做一个不直接操作的预演：
1. 监控我关注的3个UP主的最新动态
2. 分析最近一周我的视频数据
3. 起草一条明日发布的动态草稿
4. 本轮不要真实发帖、不要回复
```

## 稳定自动版（可长期运行）

### 1) 安装依赖

```bash
npx clawhub@latest install bilibili-universal
npx clawhub@latest install bilibili-video-publish
```

### 2) 配置 B站 Cookie

```bash
# 获取方法：浏览器登录 bilibili.com → F12 → Network → 复制 Cookie 字段
export BILI_COOKIE="buvid3=xxx; SESSDATA=xxx; bili_jct=xxx"
```

### 3) 常见操作命令

**定时发布：**
```bash
# 使用 automation_update 创建定时任务
automation_update create --name "B站定时发布" --prompt "发布视频到B站" --rrule "FREQ=DAILY;BYHOUR=18;BYMINUTE=0"
```

**自动回复热门评论：**
```bash
# 抓取视频最新评论，按规则回复
python3 <bilibili-universal路径>/bili-fetch.py comments <BV号> --ps 20
```

**数据监控：**
```bash
# 每日数据快照
python3 <bilibili-universal路径>/bili-harvest.py user <mid> --videos 10
```

### 4) 自动化场景示例

**场景一：每日发布计划**
```text
每天早上9点：
1. 检查我的发布日历
2. 如果今天有视频要发，自动生成发布草稿
3. 发送提醒给我确认
4. 确认后自动发布
```

**场景二：评论监控**
```text
每2小时检查我的视频评论：
- 点赞数超过10的评论自动标记
- 出现负面情绪关键词时告警
- 高价值问题整理成待回复清单
```

**场景三：竞品监控**
```text
每天跟踪以下UP主的新动态：
- UP主A
- UP主B
- UP主C

有新视频时：
1. 提取标题、播放量、弹幕关键词
2. 与我的内容做对比分析
3. 输出差异点和可借鉴之处
```

**场景四：数据异常告警**
```text
监控指标：
- 单视频播放量低于预期50%
- 连续3天粉丝零增长
- 负面评论占比超过20%

触发条件达成时，立即通知
```

## 风险与边界

- **风控限制**：B站对高频操作有严格限制，建议：
  - 发帖间隔 ≥ 2小时
  - 评论抓取 ≤ 20条/次
  - 避免短时间内大量操作
- **写入操作需确认**：发帖、回复、点赞等操作必须先预览再执行
- **Cookie 安全**：Cookie 不要提交到公开仓库，使用环境变量或加密存储
- **账号隔离**：自动化运营建议使用独立小号，保护主账号安全

## 使用建议

- 先跑"只读模式"熟悉流程，再逐步开放写操作
- 建立内容日历和发布模板，提高效率
- 定期复盘数据，调整自动化规则
- 关注B站官方政策变化，及时调整策略

## 成功标准

- 能完成定时发布、评论监控、数据导出中的至少一类核心动作
- 自动化流程稳定运行，无频繁报错
- 数据异常能及时告警，不漏关键信息

## 源文件
基于 awesome-openclaw-zh 开源项目改编  
原始文件：x-twitter-automation-ops.md
