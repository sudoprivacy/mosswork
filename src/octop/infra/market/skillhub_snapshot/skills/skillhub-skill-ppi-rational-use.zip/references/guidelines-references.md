# 指南全清单与完整参考文献

> 从 SKILL.md 拆分出的低中频参考内容,由主文件导航引用。
> 拆分为独立文件以控制 SKILL.md 正文长度(≤500行规范)。

---

### 2.1 国家卫健委层面

| 文件 | 制定机构 | 年份 | 核心定位 |
|---|---|---|---|
| **《质子泵抑制剂临床应用指导原则(2020年版)》** | 国家卫健委合理用药专家委员会(国卫办医函〔2020〕973号) | 2020-12 | **最权威**——规定适应证、用法用量、疗程、特殊人群、相互作用、监管措施。临床药师/处方审核的母法 |
| 《质子泵抑制剂预防性应用专家共识》 | 中华医学会 | 2018 | SRMD、围手术期、抗栓药联合、NSAIDs 等预防用药指征 |
| 《质子泵抑制剂优化应用专家共识》 | 中国药学会医院药学专委会+中华医学会临床药学分会 | 2020 | 适应证、不良反应、肝/肾/老年/儿童/妊娠/哺乳剂量细化 |
| 《质子泵抑制剂审方规则专家共识(2022版)》 | 重庆市医院协会药事管理专委会(陆军军医大学第一附属医院) | 2022 | 6种PPI标准化审方规则+4级警示干预+12条特殊场景 |
| 《预防性使用质子泵抑制剂及处方精简专家指导意见》 | 广东省药学会 | 2019 | 处方精简(Deprescribing)落地框架 |
| 《浙江省质子泵抑制剂院内合理应用管控专家共识》 | 浙江省临床药学专委会 | 2021 | 院内管控表(围手术期/化疗止吐/糖皮质激素等) |
| 《湖南省质子泵抑制剂的临床应用指导原则(试行)》 | 湖南省临床药学专委会 | 2016 | 省级落地版 |

### 2.2 中华医学会消化学分会

| 文件 | 年份 |
|---|---|
| 《2020年中国胃食管反流病专家共识》 | 2020 |
| 《2022中国胃食管反流病多学科诊疗共识》(GERD MDT) | 2022 |
| 《2022中国幽门螺杆菌感染治疗指南》 | 2022 |
| 《第六次全国幽门螺杆菌感染处理共识报告》(2022整合) | 2022 |
| 《消化性溃疡诊断与治疗共识意见(2022年,上海)》 | 2022/2023 |
| 《消化性溃疡基层诊疗指南(2023年)》 | 2023 |
| 《中国胃食管反流病多学科诊疗共识2022(一)/(二)》 | 2022 |
| 《胃癌诊疗规范(2018年版)》——围手术期SU预防段 | 2018 |

### 2.3 国际指南(英文检索要点)

| 指南 | 机构 | 年份 |
|---|---|---|
| **AGA Clinical Practice Update on De-Prescribing of PPIs** | American Gastroenterological Association | **2022** — 10条最佳实践建议,本Skill第七节重点引用 |
| ACG Clinical Guideline:GERD | American College of Gastroenterology | 2022(Katz et al.,Am J Gastroenterol 117:27–56) |
| ACG Clinical Guideline:H. pylori Treatment | American College of Gastroenterology | 2024(Chey et al.) — 优化含铋四联 14d 为一线 |
| AGA Clinical Practice Update:P-CAB Integration | AGA | 2024 — P-CAB临床定位专家综述 |
| Maastricht VI/Florence Consensus Report | European Helicobacter & Microbiota Study Group | 2022 — P-CAB 一/二线根除优于或非劣于PPI |
| 日本胃肠病学会《胃食管反流病循证临床实践指南》 | JSGE | 2021 |
| 日本胃肠病学会《消化性溃疡循证临床实践指南》 | JSGE | 2020 — 推荐伏诺拉生联合阿莫西林/克拉霉素作为一线 |
| NICE CG184:Dyspepsia/GORD Investigation & Management | NICE(UK) | 2014(2024更新子文件) |
| ACCF/ACG/AHA Expert Consensus on PPI+Thienopyridines | ACC/AHA | 2010 + 2018 更新 — 氯吡格雷相互作用 |
| MHRA Drug Safety Updates | MHRA(UK) | 2010/2012/2015 — 骨折、低镁、SCLE |

### 2.4 特殊人群/共病共识

| 文件 | 年份 | 要点 |
|---|---|---|
| 《老年人质子泵抑制剂合理应用专家共识》 | 2015 | 老年首选泮托拉唑、雷贝拉唑(相互作用少);监测骨质疏松、感染;起始常规剂量,避免长期大剂量 |
| 《儿童质子泵抑制剂合理使用专家共识(2019年版)》 | 2019 | 限GERD/PU/Hp;按体重;FDA:奥美拉唑≥1月、艾司奥美拉唑≥1月、兰索拉唑≥1岁、泮托拉唑≥5岁 |
| 《加速康复外科围手术期药物治疗管理医药专家共识》 | — | 围手术期:H2RA或PPI;能口服者避免静脉;不建议所有手术都预防 |

---

### 12.1 一级权威(国家卫健委 + 中华医学会最新)
1. 国家卫生健康委合理用药专家委员会.《质子泵抑制剂临床应用指导原则(2020年版)》.国卫办医函〔2020〕973号. 2020-12.
1'. **中华医学会消化病学分会幽门螺杆菌学组.《中国成年人幽门螺杆菌感染诊断、治疗与预防临床实践指南》.中华内科杂志,2026,65(7):651-. ⭐2026-07**——P-CAB定位升级、Hp根除方案重大调整
1''. **中华医学会消化内镜学分会,中华医学会消化病学分会,中华医学会心血管病学分会.《抗血小板药物消化道黏膜损伤防治多学科专家共识》.中华心血管病杂志,2026,54(7):758-783. ⭐2026-07**——抗血小板药消化道损伤全程管理
1'''. **中华医学会老年医学分会.《老年人抑酸剂合理应用中国专家共识(2026版)》.中华老年医学杂志,2026,45(4):483-496. DOI:10.3760/cma.j.issn.0254-9026.2026.04.001 ⭐2026-04**——取代2015版,23条GRADE推荐
1''''. **中国药理学会药源性疾病学专业委员会.《酸相关疾病药物治疗专家共识》.中国全科医学,2026,29(19):2593-2607. ⭐2026**——ARDs分类、NAB、难治性Hp、NSAIDs联用时机

### 12.1b 药物说明书(检索自 sino-drug-instructions-search)
- 奥美拉唑/艾司奥美拉唑、兰索拉唑、泮托拉唑、雷贝拉唑、艾普拉唑、**安奈拉唑**、伏诺拉生、替戈拉生、凯普拉生说明书要点 → 详见同目录 `pi_drug_labels.md`

### 12.2 共识/指南(中华医学会/药学会)
2. 中华医学会消化病学分会.《2020年中国胃食管反流病专家共识》.中华消化杂志,2020,10:649-663.
3. 中华医学会消化病学分会幽门螺杆菌学组.《2022中国幽门螺杆菌感染治疗指南》.中华消化杂志,2022,11:745-756.
4. 中华消化杂志编辑委员会.《消化性溃疡诊断与治疗共识意见(2022年,上海)》.中华消化杂志,2023,03:176-192.
5. 中国胃食管反流病多学科诊疗共识(2022).中华胃食管反流病电子杂志,2022,09(02):51-86.
6. 中国药学会医院药学专委会等.《质子泵抑制剂优化应用专家共识》.中国医院药学杂志,2020,40(21):2195-2213.
7. 中华医学会.《质子泵抑制剂预防性应用专家共识》.中国医师杂志,2018,20(12):1775-1778.
8. 重庆市医院协会药事管理专委会.《质子泵抑制剂审方规则专家共识(2022版)》.中国药房,2022,33(8).
9. 广东省药学会.《预防性使用质子泵抑制剂及处方精简专家指导意见》. 2019.
10. 浙江省临床药学专委会.《浙江省质子泵抑制剂院内合理应用管控专家共识》. 2021.
11. 中华医学会老年医学分会.《老年人质子泵抑制剂合理应用专家共识》.中华老年医学杂志,2015,34(10):1045-1048.
12. 中国医师协会儿科医师分会.《儿童质子泵抑制剂合理使用专家共识(2019年版)》.中国实用儿科杂志,2019,34(12):977-981.

### 12.3 国际指南
13. Katz PO, Dunbar KB, Schnoll-Sussman FH, et al. ACG Clinical Guideline:Gastroesophageal Reflux Disease. Am J Gastroenterol. 2022;117(1):27–56.
14. Chey WD, Howden CW, Moss SF, et al. ACG Clinical Guideline:Treatment of Helicobacter pylori Infection. Am J Gastroenterol. 2024.
15. Targownik L, Fisher DA, Saini SD. AGA Clinical Practice Update on De-Prescribing of Proton Pump Inhibitors. Gastroenterology. 2022.
16. Laine L, Barkun AN, Saltzman JR, et al. ACG Clinical Guideline:Upper GI and Ulcer Bleeding. Am J Gastroenterol. 2021.
17. Abraham NS, Hlatky MA, Antman EM, et al. ACCF/ACG/AHA 2010 Expert Consensus Document on Concomitant Use of PPI and Thienopyridines. Circulation. 2010.
18. Malfertheiner P, Megraud F, Rokkas T, et al. Management of H. pylori Infection:Maastricht VI/Florence Consensus Report. Gut. 2022.
19. Iwakiri K, Fujiwara Y, Manabe N, et al. Evidence-based Clinical Practice Guidelines for GERD 2021. J Gastroenterol. 2022.
20. Kamada T, Satoh K, Itoh T, et al. Evidence-based Clinical Practice Guidelines for Peptic Ulcer Disease 2020. J Gastroenterol. 2021.
21. MHRA Drug Safety Update:PPIs and risk of fracture(2012);hypomagnesaemia(2012);CDI(2010);SCLE(2015).
22. **Sugimoto M, Kamada T, Ito M, et al. Evidence-based clinical practice guidelines for peptic ulcer disease 2026(第4版). J Gastroenterol. 2026 Aug 24. DOI:10.1007/s00535-026-02504-3 ⭐JSGE 2026**——25个CQ,伏诺拉生地位前移
23. **Rationalizing Proton Pump Inhibitor Use:Southeast Asia Consensus Recommendations**(SEA PPI Rationalization Working Group,14位专家,6国,20条声明,含START/STOPP标准). 2025.
24. **Second Asian Consensus Report on Functional Dyspepsia(2025)**. J Gastroenterol Hepatol. 2025. DOI:10.1111/jgh.70222——FD中PPI可考虑,无应答12周停用;P-CAB治FD证据不足
25. **Namikawa K, Björnsson ES. Rebound Acid Hypersecretion after Withdrawal of Long-Term PPI Treatment—Are PPIs Addictive? Int J Mol Sci. 2024;25(10):5459.**
26. **Reimer C, Søndergaard B, Hilsted L, Bytzer P. Proton-pump inhibitor therapy induces acid-related symptoms in healthy volunteers after withdrawal of therapy. Gastroenterology. 2009;137(1):80-87.**(8周PPI后停药:44% vs 15%出现症状)
27. Histamine 2-Receptor Antagonists Tachyphylaxis:A Scoping Review. Laryngoscope. 2026;136(6):2412-2425.

---

> 以上内容供临床参考,所有诊疗决策以最新指南原文及药品说明书为准。
