# 【1块钱工程·模块标注】
# 技能: 本机一键管理助手
# 模块: M5 安装与快捷方式
# 职责: 把 App 模板落到用户本机、生成桌面快捷方式
# 上游: M3 页面模板 index.html
# 下游: 桌面与开始菜单快捷方式
# 改这里影响: 安装结果与快捷方式；不动对话行为
# -*- coding: utf-8 -*-
"""1块钱工程共享底座 · 在本机安装本地系统（通用版 · v1.3.1）

用法：
    python scaffold_app.py --target <安装目录> [--port 8766] [--name 自定义名称] [--no-shortcut]

行为：
1. 复制 app_template 到目标目录（已存在时只补齐文件，不覆盖已有数据）；
2. 写入配置（名称、端口）；
3. 生成两枚本机专属图标（常规 icon.ico 与醒目 icon_hot.ico）；
4. 同时创建两处快捷方式：桌面 ＋ 开始菜单（1块钱工程 目录）；首次安装用醒目态
   （★ 新安装 前缀 + 高亮图标），用户完成一次双击打开后由本地系统自动恢复常态；
5. 在安装目录生成恢复入口：恢复桌面快捷方式.bat（一键恢复）、restore_shortcut.py
   （按删除前最后状态精确恢复）、restore_shortcut.ps1（无 Python 时兜底）、
   备用桌面快捷方式.lnk（可拖拽到桌面）；
6. 在 data\\shortcut_state.json 记录快捷方式最后状态，改名／打开／改布局时同步更新；
7. 打印访问地址。

数据与运行均在本机，不上传云端。
"""
import os
import sys
import json
import shutil
import struct
import argparse
import hashlib
import math

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(os.path.dirname(HERE), "app_template")
START_MENU_DIRNAME = "1块钱工程"


def default_name():
    """安装目录名优先取展示名（show），其次原名（name），最后兜底。"""
    p = os.path.join(TPL, "app_config.json")
    try:
        with open(p, "r", encoding="utf-8") as f:
            c = json.load(f)
        return c.get("show") or c.get("name") or "本地助手"
    except Exception:
        return "本地助手"


# ---------------- 图标生成（纯标准库，无第三方依赖） ----------------
def make_icon(path, seed, size=64, hot=False):
    """生成一张 ICO：深蓝底 + 深绿圆环 + 由 seed 决定的本机专属纹样；hot 为醒目态。"""
    h = hashlib.md5(seed.encode("utf-8")).digest()
    cx = cy = (size - 1) / 2.0
    r = size * 0.40
    rows = []
    for y in range(size):
        row = []
        for x in range(size):
            dx, dy = x - cx, y - cy
            d = (dx * dx + dy * dy) ** 0.5
            t = (x + y) / (2.0 * size)
            b = int(0x1a + (0x0f - 0x1a) * t)
            g = int(0x33 + (0x6f - 0x33) * t)
            r_ = int(0x5a + (0x2f - 0x5a) * t)
            if abs(d - r) < size * 0.055:
                r_, g, b = 0x1f, 0xa8, 0x7a
            if d < size * 0.16:
                r_, g, b = 0x2f, 0x6f, 0xd0
            for i in range(4):
                ang = (h[i] / 255.0) * 6.28318 + i * 1.5708
                px = cx + r * 1.25 * (0.82 + 0.18 * (h[i + 4] / 255.0)) * (1 if i % 2 else -1) * abs(math.cos(ang))
                py = cy + r * 1.25 * (0.82 + 0.18 * (h[i + 8] / 255.0)) * (1 if i < 2 else -1) * abs(math.sin(ang))
                if (x - px) ** 2 + (y - py) ** 2 < (size * 0.075) ** 2:
                    r_, g, b = 0x1f, 0xd0, 0xa0
            if hot:
                r_, g, b = min(255, int(r_ * 1.75)), min(255, int(g * 1.55)), min(255, int(b * 1.35))
            row.append((b, g, r_, 255))
        rows.append(row)

    pix = bytearray()
    for y in range(size - 1, -1, -1):
        for (bb, gg, rr, aa) in rows[y]:
            pix += bytes((bb, gg, rr, aa))
    mask = bytearray((size * size) // 8)
    bih = struct.pack("<IiiHHIIiiII", 40, size, size * 2, 1, 32, 0, len(pix) + len(mask), 0, 0, 0, 0)
    img = bih + bytes(pix) + bytes(mask)
    icondir = struct.pack("<HHH", 0, 1, 1)
    entry = struct.pack("<BBBBHHII", size, size, 0, 0, 1, 32, len(img), 22)
    with open(path, "wb") as f:
        f.write(icondir + entry + img)
    return path



# ---------------- 快捷方式位置 ----------------
FOLDERID_DESKTOP = "{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"
FOLDERID_PROGRAMS = "{A77F5D77-2E2B-44C3-A6A2-ABA601054A51}"


def _known_folder(guid_str):
    """用 Windows Shell API 取已知目录的真实路径。

    为什么不能只拼字符串：桌面可能被组策略／注册表重定向，系统语言也可能不是
    中英文（如日文系统的「デスクトップ」），拼出来的路径会不存在，导致快捷方式
    静默不生成。这里优先问系统要，取不到再退回常见拼法。
    """
    if os.name != "nt":
        return ""
    try:
        import ctypes

        class _GUID(ctypes.Structure):
            _fields_ = [("Data1", ctypes.c_ulong),
                        ("Data2", ctypes.c_ushort),
                        ("Data3", ctypes.c_ushort),
                        ("Data4", ctypes.c_ubyte * 8)]

        ole32 = ctypes.windll.ole32
        shell32 = ctypes.windll.shell32
        IIDFromString = ole32.IIDFromString
        IIDFromString.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(_GUID)]
        IIDFromString.restype = ctypes.c_long
        SHGetKnownFolderPath = shell32.SHGetKnownFolderPath
        SHGetKnownFolderPath.argtypes = [ctypes.POINTER(_GUID),
                                        ctypes.c_uint32,
                                        ctypes.c_void_p,
                                        ctypes.POINTER(ctypes.c_wchar_p)]
        SHGetKnownFolderPath.restype = ctypes.c_long

        g = _GUID()
        if IIDFromString(guid_str, ctypes.byref(g)) != 0:
            return ""
        p = ctypes.c_wchar_p()
        if SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(p)) != 0:
            return ""
        s = p.value or ""
        try:
            ole32.CoTaskMemFree(p)
        except Exception:
            pass
        return s
    except Exception:
        return ""


def desktop_dir():
    """用户桌面目录：系统 API → ~/Desktop → ~/OneDrive/Desktop。"""
    d = _known_folder(FOLDERID_DESKTOP)
    if d and os.path.isdir(d):
        return d
    for c in (os.path.join(os.path.expanduser("~"), "Desktop"),
              os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop")):
        if os.path.isdir(c):
            return c
    return ""


def start_menu_dir(create=False):
    """用户级开始菜单 Programs 目录，下挂「1块钱工程」子目录。"""
    base = _known_folder(FOLDERID_PROGRAMS)
    if not base or not os.path.isdir(base):
        appdata = os.environ.get("APPDATA", "")
        if not appdata:
            appdata = os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
        base = os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs")
    d = os.path.join(base, START_MENU_DIRNAME)
    if create:
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            return ""
    return d if os.path.isdir(d) else ""


# ---------------- 快捷方式创建 ----------------
def create_shortcut_at(lnk, bat, target_dir, name, icon_path):
    """在指定位置创建一枚快捷方式，成功返回 ""，失败返回原因。"""
    try:
        import win32com.client  # type: ignore
        sh = win32com.client.Dispatch("WScript.Shell")
        sc = sh.CreateShortcut(lnk)
        sc.TargetPath = bat
        sc.WorkingDirectory = target_dir
        sc.IconLocation = icon_path + ",0"
        sc.Description = name
        sc.Save()
        return ""
    except Exception as ex:
        ps = (
            "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
            "$s.TargetPath='%s';$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Save()"
            % (lnk.replace("'", "''"), bat.replace("'", "''"),
               target_dir.replace("'", "''"), icon_path.replace("'", "''"))
        )
        code = os.system('powershell -NoProfile -Command "%s"' % ps.replace('"', '\\"'))
        if code == 0 and os.path.exists(lnk):
            return ""
        return str(ex)


def create_shortcut(target_dir, name, icon_path, lnk_name):
    """兼容旧调用：在桌面创建快捷方式，返回 (lnk, err)。"""
    bat = os.path.join(target_dir, "启动助手.bat")
    desk = desktop_dir()
    if not desk:
        return "", "找不到桌面目录"
    lnk = os.path.join(desk, lnk_name + ".lnk")
    err = create_shortcut_at(lnk, bat, target_dir, name, icon_path)
    return ("" if err else lnk), err


# ---------------- 快捷方式状态账本 ----------------
def state_path(target):
    return os.path.join(target, "data", "shortcut_state.json")


def write_state(target, name, icon_normal, icon_hot, desk, sm, opened_once=False):
    d = os.path.join(target, "data")
    os.makedirs(d, exist_ok=True)
    st = {
        "shortcut_name": name,
        "display_name": name,
        "icon_normal": icon_normal,
        "icon_hot": icon_hot,
        "icon_state": "normal" if opened_once else "hot",
        "opened_once": opened_once,
        "desktop_lnk": os.path.join(desk, name + ".lnk") if desk else "",
        "desktop_dir": desk,
        "start_menu_lnk": os.path.join(sm, name + ".lnk") if sm else "",
        "start_menu_dir": sm,
        "auto_rebuild": True,
        "updated_at": __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    p = state_path(target)
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                old = json.load(f)
            if isinstance(old, dict):
                # 保留用户已有的开关与打开记录，只刷新指针
                for k in ("auto_rebuild", "opened_once"):
                    if k in old:
                        st[k] = old[k]
        except Exception:
            pass
    with open(p, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=2)
    return p


# ---------------- 恢复入口（写进安装目录） ----------------
RESTORE_PY = """# -*- coding: utf-8 -*-
\"\"\"1块钱工程 · 按删除前的最后状态恢复桌面与开始菜单快捷方式。\"\"\"
import os
import sys
import json
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
STATE = os.path.join(DATA, "shortcut_state.json")
BAT = os.path.join(HERE, "\\u542f\\u52a8\\u52a9\\u624b.bat")


def load_state():
    try:
        with open(STATE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def make(lnk, icon, desc):
    try:
        import win32com.client
        sh = win32com.client.Dispatch("WScript.Shell")
        sc = sh.CreateShortcut(lnk)
        sc.TargetPath = BAT
        sc.WorkingDirectory = HERE
        sc.IconLocation = icon + ",0"
        sc.Description = desc
        sc.Save()
        return ""
    except Exception as ex:
        try:
            import subprocess, base64
            ps = (
                "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
                "$s.TargetPath='%s';$s.WorkingDirectory='%s';"
                "$s.IconLocation='%s,0';$s.Description='%s';$s.Save()"
                % (lnk.replace("'", "''"), BAT.replace("'", "''"),
                   HERE.replace("'", "''"), icon.replace("'", "''"),
                   (desc or "").replace("'", "''"))
            )
            enc = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
            r = subprocess.run(["powershell", "-NoProfile",
                                "-ExecutionPolicy", "Bypass",
                                "-EncodedCommand", enc],
                               capture_output=True, timeout=90)
            if r.returncode == 0 and os.path.exists(lnk):
                return ""
        except Exception:
            pass
        return str(ex)


def known_folder(guid_str):
    # 问系统要已知目录的真实路径，取不到返回空串。桌面可能被重定向、
    # 系统语言也可能是非中英文，只拼字符串会拼出不存在的路径，
    # 导致快捷方式静默不生成。
    if os.name != "nt":
        return ""
    try:
        import ctypes

        class _G(ctypes.Structure):
            _fields_ = [("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort),
                        ("Data3", ctypes.c_ushort), ("Data4", ctypes.c_ubyte * 8)]

        ole32 = ctypes.windll.ole32
        shell32 = ctypes.windll.shell32
        ole32.IIDFromString.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(_G)]
        ole32.IIDFromString.restype = ctypes.c_long
        shell32.SHGetKnownFolderPath.argtypes = [
            ctypes.POINTER(_G), ctypes.c_uint32, ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_wchar_p)]
        shell32.SHGetKnownFolderPath.restype = ctypes.c_long
        g = _G()
        if ole32.IIDFromString(guid_str, ctypes.byref(g)) != 0:
            return ""
        p = ctypes.c_wchar_p()
        if shell32.SHGetKnownFolderPath(ctypes.byref(g), 0, None,
                                        ctypes.byref(p)) != 0:
            return ""
        s = p.value or ""
        try:
            ole32.CoTaskMemFree(p)
        except Exception:
            pass
        return s
    except Exception:
        return ""


def desktop_default():
    # 桌面目录：系统 API → ~/Desktop → ~/OneDrive/Desktop
    for d in (known_folder("{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}"),
              os.path.join(os.path.expanduser("~"), "Desktop"),
              os.path.join(os.path.expanduser("~"), "OneDrive", "Desktop")):
        if d and os.path.isdir(d):
            return d
    return ""


def main():
    st = load_state()
    name = st.get("shortcut_name") or st.get("display_name") or "\\u672c\\u5730\\u52a9\\u624b"
    hot = not st.get("opened_once", False)
    icon = st.get("icon_hot") if hot else st.get("icon_normal")
    if not icon or not os.path.exists(icon):
        icon = os.path.join(HERE, "icon_hot.ico" if hot else "icon.ico")
    targets = []
    d = st.get("desktop_dir") or desktop_default()
    if d:
        targets.append(d)
    s = st.get("start_menu_dir") or ""
    if s:
        targets.append(s)
    ok = 0
    for t in targets:
        try:
            os.makedirs(t, exist_ok=True)
        except Exception:
            pass
        if not os.path.isdir(t):
            continue
        lnk = os.path.join(t, name + ".lnk")
        err = make(lnk, icon, name)
        if err:
            print("\\u5931\\u8d25\\uff1a%s\\uff08%s\\uff09" % (lnk, err))
        else:
            ok += 1
            print("\\u5df2\\u6062\\u590d\\uff1a%s" % lnk)
    print("=" * 46)
    print("\\u5feb\\u6377\\u65b9\\u5f0f\\u540d\\u79f0\\uff1a%s" % name)
    print("\\u6210\\u529f\\u6062\\u590d\\uff1a%d \\u5904" % ok)
    if ok == 0:
        print("\\u5168\\u90e8\\u5931\\u8d25\\uff0c\\u8bf7\\u68c0\\u67e5\\u5b89\\u88c5\\u76ee\\u5f55\\u662f\\u5426\\u5b8c\\u6574\\u3002")


if __name__ == "__main__":
    main()
"""

RESTORE_PS1 = """$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$statePath = Join-Path $here "data\\shortcut_state.json"
$name = "本地助手"
$icon = Join-Path $here "icon.ico"
if (Test-Path $statePath) {
  try {
    $st = Get-Content $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($st.shortcut_name) { $name = $st.shortcut_name }
    $hot = -not $st.opened_once
    if ($hot -and $st.icon_hot) { $icon = $st.icon_hot }
    elseif ($st.icon_normal) { $icon = $st.icon_normal }
  } catch {}
}
$bat = Join-Path $here "启动助手.bat"
$desk = [Environment]::GetFolderPath("Desktop")
if (-not $desk) { $desk = Join-Path $HOME "Desktop" }
$sm = Join-Path $env:APPDATA "Microsoft\\Windows\\Start Menu\\Programs\\1块钱工程"
$made = 0
foreach ($d in @($desk, $sm)) {
  if (-not $d) { continue }
  if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
  $lnk = Join-Path $d ($name + ".lnk")
  $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
  $s.TargetPath = $bat
  $s.WorkingDirectory = $here
  $s.IconLocation = "$icon,0"
  $s.Description = $name
  $s.Save()
  $made++
  Write-Output ("已恢复：" + $lnk)
}
if ($made -eq 0) { Write-Output "未能恢复，请检查安装目录是否完整。" }
"""

LAUNCH_BAT = """@echo off
chcp 65001>nul
cd /d "__TARGET_DIR__"
setlocal enabledelayedexpansion
set "PYEXE="
if exist "python_path.txt" set /p PYEXE=<"python_path.txt"
if defined PYEXE if exist "!PYEXE!" goto havepy
where python >nul 2>nul && (set "PYEXE=python" & goto havepy)
where python3 >nul 2>nul && (set "PYEXE=python3" & goto havepy)
goto nopy

:havepy
"!PYEXE!" server.py
goto done

:nopy
echo.
echo 未找到 Python 运行环境，无法启动本助手。
echo 请先在本机安装 Python 3，或联系作者协助处理。
echo 安装目录：__TARGET_DIR__
pause
exit /b 1

:done
"""

RECOVER_BAT = """@echo off
chcp 65001>nul
cd /d "%~dp0"
setlocal enabledelayedexpansion
set "PYEXE="
if exist "python_path.txt" set /p PYEXE=<"python_path.txt"
if defined PYEXE if exist "!PYEXE!" goto havepy
where python >nul 2>nul && (set "PYEXE=python" & goto havepy)
where python3 >nul 2>nul && (set "PYEXE=python3" & goto havepy)
goto nopy

:havepy
"!PYEXE!" "restore_shortcut.py"
goto done

:nopy
powershell -NoProfile -ExecutionPolicy Bypass -File "restore_shortcut.ps1"

:done
echo.
echo 如未成功，可把本目录下的「备用桌面快捷方式.lnk」手动拖到桌面。
pause
"""


def write_recovery(target, name, icon_normal, icon_hot, desk, sm):
    """生成恢复小程序与备用快捷方式（全部平铺在安装目录根）。"""
    os.makedirs(target, exist_ok=True)
    with open(os.path.join(target, "restore_shortcut.py"), "w", encoding="utf-8", newline="\n") as f:
        f.write(RESTORE_PY)
    with open(os.path.join(target, "restore_shortcut.ps1"), "w", encoding="utf-8", newline="\r\n") as f:
        f.write(RESTORE_PS1)
    with open(os.path.join(target, "恢复桌面快捷方式.bat"), "w", encoding="utf-8", newline="\r\n") as f:
        f.write(RECOVER_BAT)
    with open(os.path.join(target, "python_path.txt"), "w", encoding="utf-8", newline="\n") as f:
        f.write(sys.executable)
    # 备用快捷方式：供用户手动拖拽到桌面（拖拽是移动，故另留一枚并提示）
    spare = os.path.join(target, "备用桌面快捷方式.lnk")
    create_shortcut_at(spare, os.path.join(target, "启动助手.bat"),
                       target, name, icon_hot)
    return spare


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", default="")
    ap.add_argument("--port", type=int, default=8766)
    ap.add_argument("--name", default="")
    ap.add_argument("--no-shortcut", action="store_true")
    args = ap.parse_args()

    name = args.name or default_name()
    target = os.path.abspath(args.target or os.path.join(os.path.expanduser("~"), name))
    os.makedirs(target, exist_ok=True)

    copied = 0
    for root, dirs, files in os.walk(TPL):
        rel = os.path.relpath(root, TPL)
        dst_root = target if rel == "." else os.path.join(target, rel)
        os.makedirs(dst_root, exist_ok=True)
        for fn in files:
            dst = os.path.join(dst_root, fn)
            if not os.path.exists(dst):
                shutil.copy2(os.path.join(root, fn), dst)
                copied += 1

    for d in ["data", "inbox", "exports"]:
        os.makedirs(os.path.join(target, d), exist_ok=True)

    # 图标（按安装路径与机器名生成，每台不同；hot 为未打开时的醒目态）
    import socket
    seed = "%s|%s|%s" % (socket.gethostname(), target, os.environ.get("USERNAME", ""))
    icon = os.path.join(target, "icon.ico")
    icon_hot = os.path.join(target, "icon_hot.ico")
    make_icon(icon, seed)
    make_icon(icon_hot, seed + "|hot", hot=True)

    # 启动脚本（带 Python 探测，避免解释器路径写死失效）
    bat = os.path.join(target, "启动助手.bat")
    with open(bat, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(LAUNCH_BAT.replace("__TARGET_DIR__", target)
                .replace("__PY_EXE__", sys.executable))

    # 两处快捷方式：桌面 ＋ 开始菜单
    desk = desktop_dir()
    sm = start_menu_dir(True)
    lnk, smlnk, err = "", "", ""
    if not args.no_shortcut:
        if desk:
            lnk = os.path.join(desk, name + ".lnk")
            err = create_shortcut_at(lnk, bat, target, name, icon_hot)
            if err:
                lnk = ""
        else:
            err = err or "找不到桌面目录"
        if sm:
            smlnk = os.path.join(sm, name + ".lnk")
            e2 = create_shortcut_at(smlnk, bat, target, name, icon_hot)
            if e2:
                smlnk = ""
                err = err or e2

    # 恢复入口与状态账本
    spare = write_recovery(target, name, icon, icon_hot, desk, sm)
    stp = write_state(target, name, icon, icon_hot, desk, sm, opened_once=False)

    rt = {"port": args.port, "name": name}
    rt_path = os.path.join(target, "data", "runtime.json")
    if os.path.exists(rt_path):
        try:
            with open(rt_path, "r", encoding="utf-8") as f:
                old = json.load(f)
            if isinstance(old, dict):
                rt.update({k: v for k, v in old.items() if k != "name"})
        except Exception:
            pass
    rt["shortcut_path"] = lnk
    rt["start_menu_path"] = smlnk
    rt["icon_normal"] = icon
    rt["icon_hot"] = icon_hot
    with open(rt_path, "w", encoding="utf-8") as f:
        json.dump(rt, f, ensure_ascii=False, indent=2)

    print("=" * 56)
    print("安装目录：%s" % target)
    print("新增文件：%d" % copied)
    print("本机图标：%s（醒目态 %s）" % (icon, icon_hot))
    print("桌面快捷方式：%s" % (lnk or ("未创建 —— %s" % (err or "已跳过"))))
    print("开始菜单：%s" % (smlnk or "未创建"))
    print("恢复入口：%s" % os.path.join(target, "恢复桌面快捷方式.bat"))
    print("备用快捷方式：%s" % spare)
    print("状态账本：%s" % stp)
    print("访问地址：http://127.0.0.1:%d/" % args.port)
    print("=" * 56)
    print("新安装的快捷方式使用醒目图标，双击打开一次后自动恢复常态图标。")
    print("双击桌面快捷方式即可启动；数据与历史全部保存在安装目录内的 data 文件夹。")
    print("快捷方式丢失后：双击安装目录里的「恢复桌面快捷方式.bat」即可按最后状态恢复。")


if __name__ == "__main__":
    main()
