# 【1块钱工程·模块标注】
# 技能: 本机一键管理助手
# 模块: M5 安装与快捷方式
# 职责: 把用户反馈按 SMTP／本机邮件客户端两种通道送达作者
# 上游: 本地系统反馈按钮
# 下游: 作者收件邮箱
# 改这里影响: 反馈能否送达；不动其他能力
# -*- coding: utf-8 -*-
"""生成给作者的脱敏反馈报告（由用户自行决定是否发送）。

用法：
    python feedback_report.py --skill-dir <技能安装目录> [--out 报告路径]

脱敏规则：剔除本地路径、邮箱、手机号、身份证号、长段原文；产品名称保留品类，不保留客户名。
"""
import os
import re
import json
import argparse
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))


def scrub(text):
    if not isinstance(text, str):
        return text
    t = text
    t = re.sub(r"[A-Za-z]:[\\/][^\s，。；\"]+", "[路径]", t)
    t = re.sub(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b", "[邮箱]", t)
    t = re.sub(r"\b1[3-9]\d{9}\b", "[手机号]", t)
    t = re.sub(r"\b\d{17}[\dXx]\b", "[证件号]", t)
    t = re.sub(r"(https?://)\S+", "[链接]", t)
    if len(t) > 120:
        t = t[:120] + "…（已截断）"
    return t


def load_tail(path, n=50):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return []
    arr = data if isinstance(data, list) else [data]
    return arr[-n:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill-dir", default=os.path.dirname(HERE))
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    skill = os.path.abspath(args.skill_dir)
    out = args.out or os.path.join(skill, "data", "反馈报告_%s.md" % datetime.datetime.now().strftime("%Y%m%d"))

    prof = os.path.join(skill, "data", "profile.md")
    fb = os.path.join(skill, "data", "feedback.json")

    lines = ["# 全网营销与推广助手 · 脱敏反馈报告", "",
             "生成时间：%s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             "本报告中不含路径、联系方式与原文长段，可直接发送。", ""]

    if os.path.exists(prof):
        with open(prof, "r", encoding="utf-8") as f:
            lines += ["## 一、使用画像", "", scrub(f.read()[-3000:]), ""]
    else:
        lines += ["## 一、使用画像", "", "暂无记录。", ""]

    items = load_tail(fb)
    if items:
        lines += ["## 二、用户反馈", ""]
        for it in items:
            lines.append("- [%s] %s" % (scrub(it.get("time", "")), scrub(it.get("text", ""))))
    else:
        lines += ["## 二、用户反馈", "", "暂无记录。", ""]

    lines += ["", "## 三、建议回传方式", "",
              "将本文件内容复制后发送给作者即可；如需附案例，请先自行脱敏客户名称与具体数据。", ""]

    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("已生成：%s" % out)


if __name__ == "__main__":
    main()
