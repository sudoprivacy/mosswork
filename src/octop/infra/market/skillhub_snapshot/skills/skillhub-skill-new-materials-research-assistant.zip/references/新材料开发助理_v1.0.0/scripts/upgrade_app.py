# 【1块钱工程·模块标注】
# 技能: 本机一键管理助手
# 模块: M5 安装与快捷方式
# 职责: 版本升级、保留用户设置、失败回滚
# 上游: M4 本地服务 server.py
# 下游: 本地数据目录
# 改这里影响: 升级结果与用户既有设置；改错会丢数据
# -*- coding: utf-8 -*-
"""1块钱工程共享底座 · 升级已安装的本地系统（通用版 · v1.1.1）

用法：
    python upgrade_app.py --target <安装目录>

行为：
1. 检查目标目录是否为有效安装（存在 version.json）；
2. 备份被替换的程序文件到 backup_日期时间；
3. 覆盖后端、界面与配置等程序文件（不动 data / inbox / exports 里的用户数据）；
4. 清理旧版本遗留的多余目录；
5. 打印升级结果。

用户数据（data、inbox、exports）一律不覆盖。
"""
import os
import sys
import json
import shutil
import argparse
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(os.path.dirname(HERE), "app_template")

PROGRAM_FILES = ["server.py", "app.js", "index.html", "style.css",
                 "app_config.json", "version.json", "邮件反馈配置说明.txt"]
LEGACY_DIRS = ["static"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True)
    ap.add_argument("--no-backup", action="store_true")
    args = ap.parse_args()

    target = os.path.abspath(args.target)
    if not os.path.exists(os.path.join(target, "version.json")):
        print("目标目录不是有效的安装目录（缺少 version.json）：%s" % target)
        return 1

    with open(os.path.join(target, "version.json"), "r", encoding="utf-8") as f:
        old = json.load(f)
    with open(os.path.join(TPL, "version.json"), "r", encoding="utf-8") as f:
        new = json.load(f)
    print("当前版本：%s → 升级到：%s" % (old.get("version", "?"), new.get("version", "?")))

    bak = ""
    if not args.no_backup:
        bak = os.path.join(target, "backup_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        os.makedirs(bak, exist_ok=True)

    replaced = 0
    for fn in PROGRAM_FILES:
        src = os.path.join(TPL, fn)
        if not os.path.exists(src):
            continue
        dst = os.path.join(target, fn)
        if os.path.exists(dst) and bak:
            shutil.copy2(dst, os.path.join(bak, fn))
        shutil.copy2(src, dst)
        replaced += 1

    for d in LEGACY_DIRS:
        p = os.path.join(target, d)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            print("已清理旧版本遗留目录：%s" % d)

    for d in ["data", "inbox", "exports"]:
        os.makedirs(os.path.join(target, d), exist_ok=True)

    print("=" * 56)
    print("升级完成：覆盖程序文件 %d 个" % replaced)
    print("备份目录：%s" % (bak or "未备份"))
    print("用户数据未改动：data / inbox / exports")
    print("=" * 56)
    return 0


if __name__ == "__main__":
    sys.exit(main())
