# 平台解析参考

## 抖音 (douyin.com / v.douyin.com)

### URL 模式
- 短链：`https://v.douyin.com/xxxxxxx/`
- 长链：`https://www.douyin.com/video/{aweme_id}`

### 数据提取
```python
# HTML 中的 JSON 数据块位置
# 搜索 "videoInfoRes" 可找到视频元数据
import re, json

# 提取视频描述
desc_match = re.search(r'"desc":"(.*?)"', html)

# 提取互动数据
stats_pattern = r'"comment_count":(\d+),"digg_count":(\d+),"play_count":(\d+)'

# 提取作者信息
author_pattern = r'"nickname":"(.*?)"'
```

### 注意事项
- 短链需要 `-L` 跟随重定向
- 视频具体内容（画面/语音中的店名）无法从 HTML 提取
- 评论区需要 JS 渲染，curl 无法获取

---

## 小红书 (xiaohongshu.com / xhslink.com)

### URL 模式
- 短链：`https://xhslink.com/xxxxxxx`
- 长链：`https://www.xiaohongshu.com/explore/{note_id}`

### 数据提取
- 搜索 `window.__INITIAL_STATE__` 或 `noteData`
- 小红书帖子通常有详细的文字描述，包含店名和地址

---

## B站 (bilibili.com)

### URL 模式
- `https://www.bilibili.com/video/{bvid}`

### 数据提取
- 搜索 `window.__INITIAL_STATE__` 获取视频信息
- 视频描述通常在 `desc` 字段

---

## 大众点评 (dianping.com)

### 数据提取
- 店铺页面直接包含店名、地址、人均、推荐菜等结构化信息
- 反爬较严，可能需要多次尝试或使用 web_search 替代

---

## 美团 (meituan.com)

### 数据提取
- 类似大众点评，包含结构化店铺信息
- 搜索 `shopInfo` 或 `poiInfo` JSON 块

---

## 微博 (weibo.com)

### URL 模式
- `https://weibo.com/{uid}/{mid}`
- `https://m.weibo.cn/detail/{mid}`

### 数据提取
- 搜索 `$render_data` 或 `status` JSON
- 微博正文通常包含完整的探店文字
