#!/usr/bin/env python3
"""B站视频集抓取工具：获取分P信息、下载音频（供语音转写用）。

用法:
  bili_fetch.py info  <bvid>                       # 输出视频集信息 JSON（含每P的cid与url）
  bili_fetch.py audio <bvid> <cid> <output.m4a>    # 下载某P最高音质音频

仅用标准库。输出文件为 m4a 容器（实际是 m4s 音轨，可直接用于语音识别）。
"""
import json
import os
import sys
import urllib.request

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
BVID_CACHE = "/tmp/.bili_buvid3"


def get_buvid3():
    """获取访客 cookie（buvid3），B站 view/playurl 接口在无 cookie 时可能拒绝。"""
    if os.path.exists(BVID_CACHE):
        return open(BVID_CACHE).read().strip()
    req = urllib.request.Request(
        "https://api.bilibili.com/x/frontend/finger/spi",
        headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/"})
    d = json.load(urllib.request.urlopen(req, timeout=30))
    b3 = d["data"]["b_3"]
    with open(BVID_CACHE, "w") as f:
        f.write(b3)
    return b3


def headers(referer=None):
    h = {"User-Agent": UA,
         "Referer": referer or "https://www.bilibili.com/",
         "Cookie": "buvid3=" + get_buvid3()}
    return h


def get_json(url, referer=None):
    return json.load(urllib.request.urlopen(
        urllib.request.Request(url, headers=headers(referer)), timeout=30))


def fmt(sec):
    return f"{sec // 60}:{sec % 60:02d}"


def cmd_info(bvid):
    d = get_json(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}")
    if d.get("code") != 0:
        print(json.dumps({"error": d.get("message"), "code": d.get("code")},
                         ensure_ascii=False))
        sys.exit(1)
    v = d["data"]
    pages = [{
        "p": i + 1,
        "cid": p["cid"],
        "title": p["part"],
        "duration": fmt(p["duration"]),
        "seconds": p["duration"],
        "url": f"https://www.bilibili.com/video/{bvid}/?p={i + 1}",
    } for i, p in enumerate(v["pages"])]
    out = {
        "bvid": bvid,
        "title": v["title"],
        "owner": v["owner"]["name"],
        "desc": v["desc"],
        "page_count": len(pages),
        "pages": pages,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))


def cmd_audio(bvid, cid, out_path):
    u = (f"https://api.bilibili.com/x/player/playurl?bvid={bvid}"
         f"&cid={cid}&fnval=16&fourk=1")
    d = get_json(u, referer=f"https://www.bilibili.com/video/{bvid}/")
    if d.get("code") != 0:
        print(json.dumps({"error": d.get("message")}, ensure_ascii=False))
        sys.exit(1)
    auds = sorted(d["data"]["dash"]["audio"],
                  key=lambda x: x.get("bandwidth", 0), reverse=True)
    best = auds[0]
    req = urllib.request.Request(
        best["baseUrl"],
        headers={"User-Agent": UA,
                 "Referer": f"https://www.bilibili.com/video/{bvid}/"})
    data = urllib.request.urlopen(req, timeout=300).read()
    with open(out_path, "wb") as f:
        f.write(data)
    print(json.dumps({"saved": out_path, "bytes": len(data),
                      "bandwidth": best.get("bandwidth")},
                     ensure_ascii=False))


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "info" and len(sys.argv) == 3:
        cmd_info(sys.argv[2])
    elif cmd == "audio" and len(sys.argv) == 5:
        cmd_audio(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
