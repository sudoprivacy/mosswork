# 资料库文档写入速查

本 skill 产出文档写入「资料库」。文档的创建、读回与编辑通过资料库提供的文档写入能力完成，具体调用方式以资料库能力文档的最新说明为准；本文只保留实测验证过的数据格式与易错点，避免重新试错。

## 操作与用法

| 操作 | 说明 |
|------|------|
| 列空间 / 列节点 | 通过资料库的空间查询接口取得 space-id 与 parent-node-id（默认空间「资料库」也在查询结果中） |
| 创建文档 | 以标题、space-id、parent-id、正文内容为参数创建，创建前先做 dry-run 校验 |
| 读回文档块 | 按文档 ID 读回带 id 的块结构，用于取后续插入的锚点 |
| 编辑文档 | 按文档 ID 提交 actions 数组，提交前先做 dry-run 校验 |

## actions 数据格式（易错点）

- **必须是纯数组**，不是 `{actions:[...]}` 包一层。
- 每个元素只有三个字段：`id`（锚点 blockId）、`type`（`insert_after` / `delete` / `update_title`）、`content`（insert 类必填，伪 XML 字符串）。
- `update_title`：`{"type":"update_title","title":"新标题"}`，无需 id。
- 替换一个块 = 先 `insert_after` 新内容，再 `delete` 旧块（两条 action 按顺序执行）。

```json
[
  {"type":"insert_after","id":"<blockId>","content":"<Paragraph>新内容</Paragraph>"},
  {"type":"delete","id":"<blockId>"},
  {"type":"update_title","title":"新标题"}
]
```

## 内容块伪 XML 语法

```
<Heading level="1">标题</Heading>          # level 1/2/3
<Paragraph>正文，可内嵌 <Mark bold>加粗</Mark></Paragraph>
<BulletedList>列表项文本</BulletedList>     # 一个块 = 一个列表项
<BlockQuote>
    <Paragraph>引用内容</Paragraph>
</BlockQuote>
<Divider />
<Table>
<TableRow>
<TableCell>
<Paragraph>单元格文本</Paragraph>
</TableCell>
</TableRow>
</Table>
```

注意：
- 标签内容里不要用未转义的换行排版，块与块之间用 `\n\n` 分隔。
- 表格必须整表一个 content；单元格内可嵌 `<Mark bold>`。

## 分段插入策略（长文档必用）

1. 先插第一段（锚点用上一集末尾 blockId 或文档骨架的占位块）。
2. 读回文档块，取**新插入内容最后一个块**的 id。
3. 以下一段 `insert_after` 到该 id，重复。
4. 表格单独一次 insert（锚到目标小节的 Heading id），插完后读回 `<Table id="...">`，把表格之后的内容锚到表格 id。

单段 content 控制在 **1–3KB**；超过 3KB 拆段。

## 每集插入的标准结构

**视频 URL 放在每集最顶部**，紧跟小节头之后；**不写原始逐字稿**。

```
<Divider />
<Heading level="1">Pn · 集标题</Heading>
<Paragraph>视频链接：https://www.bilibili.com/video/<BVID>/?p=n</Paragraph>
<BlockQuote><Paragraph>来源：《课程名》（BV号，UP主）第 n P，时长 m:ss · 主题一句话。</Paragraph></BlockQuote>
<Heading level="1">一句话概括</Heading> <Paragraph>…</Paragraph>
<Heading level="1">一、…</Heading> …（整理稿，2–5 节，必要时插 1 张表）
```

- 每集都用自己的 `?p=n`，不要复用触发链接里的 p 值。
- 整理稿要能独立读懂——因为没有逐字稿兜底，口语省略的步骤、指代（"这个按钮"）必须补成具体名称。
- 文档开头一段导语（BlockQuote）：写明来源视频集全名、BV号、UP主、总集数、本次收录的集数与主题范围。
- 全文收录时，可在导语后附一张「全N集清单」索引表（列：集数 / 主题 / 一句话要点），每集小节标题与表中"集数"列保持一致。

## 新建文档 vs 追加（本 skill 的默认策略）

- **默认新建独立文档**，标题 = 视频集名称（`info` 返回的 `title`，可去掉"已付费、允许白嫖、一键三连、附全套资料"这类营销片段，课程主体名与年份版本保留）。
- 资料库已有同名文档时，先问用户「新建副本」还是「在原文末尾追加」，不要覆盖。
- 只有在用户明确要求「接到 XX 文档后面」时，才走追加流程（读末尾 blockId → 分段 insert_after → 更新导语清单）。
