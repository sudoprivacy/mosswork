# caiyouyun-compliance-self-protect

> 财友云（律令科技）财税技能包 · 本地运行 · 零网络 · 免 API Key

**displayName**：财务合规自保工具包（证据留存/职责分离/异常上报）

**一句话**：【财友云】财务岗位合规自保清单：输入岗位与业务场景，输出个人风险排查清单（证据留存/审批留痕/职责分离/异常上报路径/禁止事项）与动作建议，守住职业红线。

## 运行

```bash
python scripts/compliance-self-protect.py --help
```

详见 `SKILL.md`。
