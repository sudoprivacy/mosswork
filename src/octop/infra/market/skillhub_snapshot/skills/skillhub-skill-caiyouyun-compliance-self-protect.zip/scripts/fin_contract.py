#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""fin_contract.py — 财税技能包规范 v2 的落地内核（强制，55 个包统一调用）

规范来源：《财务人 WorkBuddy 自动化工作流 SOP 手册》第 2/5/26 节。
八条硬约束在本文件里被写成代码，不靠自觉：

1. 输出四件套：主表 / 异常表 / 校验表 / 处理日志 —— 缺一不可
2. 三级执行：plan（只说方案）→ preview（默认小样本）→ --execute（才落盘）
3. 输出进 _out/，源文件零改动
4. 输入契约：口径不清就拒绝，不猜
5. 统一 JSONL 日志（跨技能可查）
6. 人工复核声明（emit 时自动附在校验表末尾）
7. 拒绝权：refuse() 明说"算不出"，绝不给看似合理的错数
8. 敏感字段默认脱敏
"""
import datetime
import hashlib
import json
import os
import re
import sys

LOG_NAME = "fin-log.jsonl"
REVIEW_NOTE = ("本结果由本地工具生成，仅供财务复核使用；入账 / 付款 / 申报 / 税务口径 / "
               "重大异常的最终结论必须由对应财务岗位人工确认。")


# ---------- 拒绝权 ----------
def refuse(reason, howto=None):
    """口径不清、参数过期、无法唯一匹配时调用。禁止绕过它给数。"""
    print("【算不出】%s" % reason)
    if howto:
        print("建议：%s" % howto)
    print("本包不会给一个看似合理的替代数字 —— 财税场景算错比不做更危险。")
    sys.exit(2)


def need(cond, reason, howto=None):
    if not cond:
        refuse(reason, howto)


# ---------- 三级执行 ----------
def check_execute(args, what="写盘"):
    """没有 --execute 就只预览，返回 False；返回 True 才允许落盘"""
    if getattr(args, "execute", False):
        return True
    print("[预览模式] 未%s。确认无误后加 --execute 执行。" % what)
    return False


def sample(rows, n=20):
    """SOP：先用 20-50 行小样本试跑"""
    n = getattr(sample, "_n", n)
    return rows[:n]


# ---------- 脱敏 ----------
def mask_name(s):
    s = str(s or "")
    return (s[0] + "*" * (len(s) - 1)) if len(s) > 1 else "*" * len(s)


def mask_id(s):
    """身份证 / 税号 / 统一社会信用代码：保留前 4 后 2"""
    s = str(s or "")
    return (s[:4] + "*" * max(0, len(s) - 6) + s[-2:]) if len(s) > 6 else "*" * len(s)


def mask_card(s):
    """银行卡：保留后 4 位"""
    s = re.sub(r"\D", "", str(s or ""))
    return ("*" * max(0, len(s) - 4) + s[-4:]) if len(s) > 4 else "*" * len(s)


def mask_phone(s):
    s = re.sub(r"\D", "", str(s or ""))
    return (s[:3] + "****" + s[-4:]) if len(s) >= 7 else "*" * len(s)


def mask_amount(v, ratio=0.618):
    """金额保形脱敏：按固定比例缩放，保留数量级与正负，破坏真实值"""
    try:
        f = float(v)
    except Exception:
        return v
    r = round(f * ratio, 2)
    return int(r) if r == int(r) else r


MASKERS = {"name": mask_name, "id": mask_id, "card": mask_card, "phone": mask_phone, "amount": mask_amount}


def mask_row(row, kinds):
    """kinds: {列索引: 类型}"""
    return [MASKERS[k](v) if i in kinds else v for i, v in enumerate(row)]


# ---------- 日志 ----------
def sha256_of(path):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for b in iter(lambda: f.read(1 << 16), b""):
                h.update(b)
        return h.hexdigest()[:16]
    except Exception:
        return ""


def write_log(out_dir, slug, version, entry):
    os.makedirs(out_dir, exist_ok=True)
    rec = {"ts": datetime.datetime.now().isoformat(timespec="seconds"),
           "skill": slug, "version": version}
    rec.update(entry)
    with open(os.path.join(out_dir, LOG_NAME), "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


# ---------- 四件套输出 ----------
def emit_four(slug, version, out_dir, base, main, exc=None, checks=None,
              src=None, row_in=0, amount_in=None, amount_out=None, amount_exc=None,
              rule_version="1.0", operator="", assert_amount=True):
    """输出固定四件套。main/exc = (columns, rows)

    金额守恒（不是"主表=输入"，那是错的）：
        输入金额 = 主表金额 + 异常表金额
    异常行被排除后主表必然小于输入，必须把异常金额算进来才守恒。
    差异超 0.01 元 -> 拒绝输出（SOP：合计校验前后不等，停止输出）
    """
    import fin_xlsx_lite as X
    os.makedirs(out_dir, exist_ok=True)
    written = []

    mcols, mrows = main
    mp = os.path.join(out_dir, "%s_主表.csv" % base)
    X.write_csv(mp, list(mcols) + ["_来源文件", "_原始行号"] if src else list(mcols), mrows)
    written.append(mp)

    ecols, erows = exc if exc else (None, None)
    if ecols is None and erows:
        ecols = mcols
    if erows:
        ep = os.path.join(out_dir, "%s_异常表.csv" % base)
        X.write_csv(ep, list(ecols) + ["_异常原因", "_风险等级", "_原始行号"], erows)
        written.append(ep)
    else:
        ep = os.path.join(out_dir, "%s_异常表.csv" % base)
        X.write_csv(ep, ["说明"], [["本次未发现异常记录（0 条）"]])
        written.append(ep)

    # 校验表
    ck = list(checks or [])
    ck.append(("主表行数", len(mrows)))
    ck.append(("异常行数", len(erows or [])))
    ck.append(("输入行数", row_in))
    if amount_in is not None and amount_out is not None:
        exc_amt = float(amount_exc or 0.0)
        diff = round(amount_in - amount_out - exc_amt, 2)
        ck.append(("主表金额合计", round(amount_out, 2)))
        ck.append(("异常表金额合计", round(exc_amt, 2)))
        ck.append(("守恒差异（入-主-异）", diff))
        if assert_amount and abs(diff) > 0.01:
            cp = os.path.join(out_dir, "%s_校验表.csv" % base)
            X.write_csv(cp, ["校验项", "值"], [[str(a), str(b)] for a, b in ck] +
                        [["结论", "金额不守恒，已停止输出（差异 %s 元）" % diff]])
            refuse("金额不守恒：输入 %s ≠ 主表 %s + 异常 %s（差 %s 元）"
                   % (round(amount_in, 2), round(amount_out, 2), round(exc_amt, 2), diff),
                   "检查异常表里的排除行金额是否统计完整，或确认金额列口径（含税 / 不含税）")
    elif amount_in is not None:
        ck.append(("输入金额合计", round(amount_in, 2)))
    ck.append(("人工复核", REVIEW_NOTE))
    cp = os.path.join(out_dir, "%s_校验表.csv" % base)
    X.write_csv(cp, ["校验项", "值"], [[str(a), str(b)] for a, b in ck])
    written.append(cp)

    write_log(out_dir, slug, version, {
        "input": os.path.basename(src) if src else "",
        "input_sha256": sha256_of(src) if src else "",
        "row_in": row_in, "row_out": len(mrows), "row_exc": len(erows or []),
        "amount_in": None if amount_in is None else round(amount_in, 2),
        "amount_out": None if amount_out is None else round(amount_out, 2),
        "amount_exc": None if amount_exc is None else round(amount_exc, 2),
        "rule_version": rule_version, "operator": operator,
        "outputs": [os.path.basename(p) for p in written]})
    return written


def show_checks(out_dir, base):
    p = os.path.join(out_dir, "%s_校验表.csv" % base)
    if os.path.exists(p):
        print("--- 校验表 ---")
        for line in open(p, encoding="utf-8-sig").read().splitlines():
            print("  " + line.replace(",", " | ", 1))
