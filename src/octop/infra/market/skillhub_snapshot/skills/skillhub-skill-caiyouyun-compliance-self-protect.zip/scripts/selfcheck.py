#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selfcheck.py — caiyouyun-tax-plan-advisor 交付前自检门禁（本包自带，纯标准库）

用途：在把本技能交付 / 打包 / 发布之前跑一次，用退出码判定「这份技能是否可交付」。
这不是文档清单，是会真跑的检查 —— 任何一项 FAIL 都必须先修好再交付。

用法：
  python scripts/selfcheck.py            # 完整自检
  python scripts/selfcheck.py --quick    # 跳过「入口脚本可运行」一项（更快）
  python scripts/selfcheck.py --json     # 机器可读输出

退出码（与本包 SKILL.md「退出码（脚本契约）」同构）：
  0  全部通过
  2  用法错误（路径不对 / 参数不认识）
  3  门禁未通过（存在 FAIL 项）
  4  环境问题（Python 版本过低 / 入口脚本跑不起来）
  8  部分通过（无 FAIL，但有 WARN）
"""
import io
import json
import os
import re
import subprocess
import sys

PKG = 'caiyouyun-compliance-self-protect'
EXPECT_SLUG = 'caiyouyun-compliance-self-protect'
ENTRY = 'scripts/compliance-self-protect.py'          # 相对包根的入口脚本路径，None 表示纯知识型包
BRAND = '财友云'
HAS_SCRIPTS = True
NEED_SECTIONS = [('## 输出规范', '^##\\s*(输出规范|输出契约|输出格式|输出结构|输出字段|输出物|输出内容|交付物|交付形态)'), ('## 反例对照', '^##\\s*(反例对照|反例)'), ('## 退出码（脚本契约）', '^##\\s*退出码')]   # [(显示名, 正则)]

EXIT_OK, EXIT_USAGE, EXIT_FAIL, EXIT_ENV, EXIT_PARTIAL = 0, 2, 3, 4, 8
BAN_EXT = ('.pyc', '.bak', '.zip', '.skill', '.skillignore')
BAN_DIR = ('__pycache__', '.git', 'node_modules', '.smoke', '.publish-log')

FAIL, WARN = [], []


def say(msg):
    sys.stdout.write(msg + '\n')


def fail(code, msg):
    FAIL.append('%s | %s' % (code, msg))


def warn(code, msg):
    WARN.append('%s | %s' % (code, msg))


def frontmatter(md):
    m = re.match(r'^---\s*\n(.*?)\n---', md, re.S)
    if not m:
        return {}
    fm = {}
    for line in m.group(1).splitlines():
        mm = re.match(r'^([A-Za-z_][\w-]*)\s*:\s*(.*)$', line)
        if mm:
            fm[mm.group(1)] = mm.group(2).strip()
    return fm


def main():
    quick = '--quick' in sys.argv
    as_json = '--json' in sys.argv
    for a in sys.argv[1:]:
        if a not in ('--quick', '--json'):
            say('用法：python scripts/selfcheck.py [--quick] [--json]')
            return EXIT_USAGE

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if not os.path.isdir(root):
        say('找不到包根目录：%s' % root)
        return EXIT_USAGE

    # ---- 1. SKILL.md 存在 ----
    smd = os.path.join(root, 'SKILL.md')
    md = ''
    if not os.path.isfile(smd):
        fail('S1', '缺少 SKILL.md')
    else:
        md = open(smd, encoding='utf-8', errors='replace').read()

    # ---- 2. 基本字段 + 合规声明（license 或 ATTRIBUTION.md，二者其一即可）----
    fm = frontmatter(md) if md else {}
    for f in ('name', 'description'):
        if not fm.get(f):
            fail('S2', 'frontmatter 缺字段：%s' % f)
    has_lic = bool(fm.get('license'))
    has_attr = os.path.isfile(os.path.join(root, 'ATTRIBUTION.md'))
    if not (has_lic or has_attr):
        fail('S2', '合规声明缺失：既无 frontmatter license，也无 ATTRIBUTION.md')
    if EXPECT_SLUG and fm.get('slug') and fm['slug'].strip().strip('"').strip("'") != EXPECT_SLUG:
        warn('S2w', 'frontmatter slug=%s 与期望 %s 不一致' % (fm['slug'].strip(), EXPECT_SLUG))

    # ---- 3. 必备章节 ----
    for label, pat in NEED_SECTIONS:
        if not re.search(pat, md, re.M):
            fail('S3', '缺少必备章节：%s' % label)
    if not re.search(r'^##\s*何时不触发', md, re.M) and not re.search(r'^##\s*不触发', md, re.M):
        warn('S3w', '缺少「何时不触发」章节（建议补，防多技能互抢触发）')

    # ---- 4. 打包卫生：禁止文件 ----
    for rt, dirs, fs in os.walk(root):
        for dn in list(dirs):
            if dn in BAN_DIR:
                fail('S4', '存在禁止目录：%s' % os.path.relpath(os.path.join(rt, dn), root))
        for fn in fs:
            if fn.lower().endswith(BAN_EXT):
                fail('S4', '存在禁止文件：%s' % os.path.relpath(os.path.join(rt, fn), root))

    # ---- 5. 脚本可编译 + 入口可运行 ----
    if HAS_SCRIPTS:
        sdir = os.path.join(root, 'scripts')
        pys = []
        for rt, _, fs in os.walk(sdir):
            for fn in fs:
                if fn.endswith('.py'):
                    pys.append(os.path.join(rt, fn))
        if not pys:
            fail('S5', '声明有脚本但 scripts/ 下无 .py')
        for p in pys:
            try:
                src = open(p, encoding='utf-8', errors='replace').read()
                compile(src, p, 'exec')
            except SyntaxError as e:
                fail('S5', '语法错误：%s:%s %s' % (os.path.relpath(p, root), e.lineno, e.msg))
            except Exception as e:
                warn('S5w', '无法读取：%s (%s)' % (os.path.relpath(p, root), type(e).__name__))
        if ENTRY and not quick:
            ep = os.path.join(root, ENTRY.replace('/', os.sep))
            if not os.path.isfile(ep):
                fail('S5', '入口脚本不存在：%s' % ENTRY)
            else:
                try:
                    r = subprocess.run([sys.executable, ep, '--help'], capture_output=True, timeout=25,
                                       cwd=os.path.dirname(ep))
                    out = (r.stdout or b'').decode('utf-8', 'replace')
                    err = (r.stderr or b'').decode('utf-8', 'replace')
                    if r.returncode != 0 or not out.strip():
                        mm = re.search(r"No module named '([^']+)'", err)
                        if mm or 'ImportError' in err:
                            warn('S5w', '入口脚本第三方依赖未安装：%s —— 先 pip install -r requirements.txt'
                                 '（本包已声明，属环境问题，不是包的缺陷）' % (mm.group(1) if mm else '?'))
                        else:
                            fail('S5', '入口脚本 --help 未正常返回（exit=%s）' % r.returncode)
                except subprocess.TimeoutExpired:
                    fail('S5', '入口脚本 --help 超时（25s）')
                except Exception as e:
                    fail('S5', '入口脚本无法运行：%s' % type(e).__name__)

    # ---- 6. 交付物声明 ----
    if HAS_SCRIPTS and not re.search(r'输出规范|输出契约|输出格式|输出结构|输出字段|输出物', md, re.M):
        warn('S6w', '未声明输出规范')

    passed = not FAIL
    if as_json:
        say(json.dumps({'pkg': PKG, 'brand': BRAND, 'fail': FAIL, 'warn': WARN,
                        'passed': passed}, ensure_ascii=False))
    else:
        say('自检：%s（%s）' % (PKG, BRAND))
        say('  检查项：SKILL.md / frontmatter / 必备章节 / 打包卫生 / 脚本可运行' + ('' if quick else ' / 入口 --help'))
        if FAIL:
            say('  FAIL %d 项：' % len(FAIL))
            for x in FAIL:
                say('    ✗ ' + x)
        if WARN:
            say('  WARN %d 项：' % len(WARN))
            for x in WARN:
                say('    ! ' + x)
        if not FAIL and not WARN:
            say('  ✓ 全部通过')
        elif not FAIL:
            say('  ✓ 无 FAIL，%d 项警告' % len(WARN))

    if FAIL:
        return EXIT_FAIL
    return EXIT_PARTIAL if WARN else EXIT_OK


if __name__ == '__main__':
    sys.exit(main())
