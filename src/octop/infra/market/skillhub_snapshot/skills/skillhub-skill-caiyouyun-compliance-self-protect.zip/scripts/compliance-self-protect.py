#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""compliance-self-protect.py — 合规自保工具包生成器

零依赖：Python 3.8+ 标准库。不联网、不改源文件。
财务人/企业常见合规风险点（私户收款、虚开发票、两套账、社保挂靠、阴阳合同等），
逐条给出：风险等级 + 自保动作 + 红线。输入场景清单，命中内置合规风险库；
未命中进异常表标「须人工判断」，绝不编造一条风险凑数。

铁律（不可逾越）：
  · 只做风险识别与自保动作提示，不做法律辩护、不替你评估「会不会被查」；
  · 红线是法律底线提示，具体个案以主管机关与司法机关认定为准；
  · 任何涉嫌违法的筹划意图，本包明确拒绝并提示合规路径。
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fin_xlsx_lite as X          # noqa: E402
import fin_contract as C           # noqa: E402

SLUG = "caiyouyun-compliance-self-protect"
VERSION = "0.1.0"
RULE_VERSION = "2026.10"

# 合规风险库：(风险等级, 自保动作, 红线)
KB = {
    "私户收款": ("高", "经营收入走对公账户、及时入账；不得用个人银行卡收经营款", "通过个人银行账户隐匿经营收入逃税属违法"),
    "公转私": ("高", "对公付款有真实业务与凭证；分红/薪酬依法代扣个税", "无真实业务大额公转私、变相抽逃资金涉合规风险"),
    "虚开发票": ("高", "合同/资金/发票三流一致，交易背景真实", "无真实交易开具/接受发票属刑事风险"),
    "两套账": ("高", "只设一套真实账，规范核算与凭证管理", "设置账外账、逃避缴纳税款违法"),
    "社保挂靠": ("中高", "按实申报缴费基数、合法用工关系", "虚构劳动关系代缴社保违规"),
    "阴阳合同": ("高", "对外合同一致、据实申报纳税", "以低报合同逃避税款违法"),
    "无票支出": ("中", "尽量取得合规发票；小额零星按税法标准扣除并留痕", "不得买卖/虚开发票用于税前扣除"),
    "存货账实不符": ("中", "定期盘点、盘盈盘亏按准则合规处理", "不得借存货调节利润、逃避纳税"),
    "关联方资金占用": ("中高", "规范往来科目、依规计息与披露", "违规占用资金涉合规与刑事责任"),
    "个税未代扣": ("中高", "全员全额代扣代缴个人所得税并按时申报", "应扣未扣面临补税、滞纳金与罚款"),
    "进销项不匹配": ("中", "进销匹配、异常抵扣凭证及时核查转出", "接受异常增值税抵扣凭证涉税务风险"),
    "大额现金交易": ("中", "优先转账/票据结算，减少现金使用并留痕", "借大额现金隐匿交易违法"),
    "迟报不报": ("中高", "按期申报；逾期立即补报并说明", "拒不申报/虚假申报违法"),
    "发票异常": ("中", "核验发票真伪与抬头，异常发票不退不抵", "接受失控/异常发票涉风险"),
}

ALIAS = {
    "私户": "私户收款", "个人卡": "私户收款", "个人银行账户": "私户收款", "公款私存": "私户收款",
    "公转私": "公转私", "对私转账": "公转私",
    "虚开": "虚开发票", "虚开发票": "虚开发票", "代开": "虚开发票", "票货不符": "虚开发票",
    "两套账": "两套账", "账外账": "两套账", "内外账": "两套账",
    "社保": "社保挂靠", "挂靠社保": "社保挂靠", "社保基数": "社保挂靠", "虚构劳动关系": "社保挂靠",
    "阴阳合同": "阴阳合同", "阳合同": "阴阳合同", "合同不一致": "阴阳合同",
    "无票": "无票支出", "无发票": "无票支出", "白条": "无票支出", "收据入账": "无票支出",
    "存货": "存货账实不符", "盘亏": "存货账实不符", "盘盈": "存货账实不符",
    "关联": "关联方资金占用", "资金占用": "关联方资金占用", "大股东借款": "关联方资金占用",
    "个税": "个税未代扣", "代扣代缴": "个税未代扣", "未申报个税": "个税未代扣",
    "进销": "进销项不匹配", "进销项": "进销项不匹配", "抵扣异常": "进销项不匹配",
    "现金": "大额现金交易", "大额现金": "大额现金交易",
    "迟报": "迟报不报", "不报": "迟报不报", "漏报": "迟报不报", "逾期申报": "迟报不报",
    "发票异常": "发票异常", "失控票": "发票异常", "异常凭证": "发票异常",
}


def norm(s):
    return re.sub(r"[\s\u3000]+", "", str(s or ""))


def resolve(scene):
    t = norm(scene)
    if t in KB:
        return t
    if t in ALIAS:
        return ALIAS[t]
    for k in KB:
        if k in t:
            return k
    for a, k in ALIAS.items():
        if a in t:
            return k
    return None


def main():
    ap = argparse.ArgumentParser(description="合规自保工具包（本地、零网络）")
    ap.add_argument("file", nargs="?", help="场景清单 .xlsx / .csv（首行表头：场景）")
    ap.add_argument("--topic", nargs="*", help="直接指定场景（可多个，与 file 二选一）")
    ap.add_argument("--out-dir", default="", help="产物目录（默认 <cwd>/_out）")
    ap.add_argument("--operator", default="", help="操作人（写入留痕）")
    ap.add_argument("--execute", action="store_true", help="真正写盘（默认只预览）")
    args = ap.parse_args()

    rows = []
    if args.topic:
        rows = [[t, ""] for t in args.topic]
    elif args.file:
        if not os.path.isfile(args.file):
            C.refuse("找不到输入文件：%s" % args.file, "支持 .xlsx / .csv，首行写 场景")
        try:
            tb = X.read_table(args.file)
            cols, raw = tb["columns"], tb["rows"]
        except Exception as e:
            C.refuse("文件读不出表头：%s" % e, "要求首行是表头（场景）")
        cols = [str(c).strip() for c in cols]
        i_s = -1
        for i, h in enumerate(cols):
            if norm(h) in ("场景", "风险点", "事项", "问题", "关注", "场景/风险点"):
                i_s = i
                break
        if i_s < 0:
            C.refuse("缺「场景」列（别名：风险点 / 事项 / 问题）", "至少要有场景列")
        i_n = -1
        for i, h in enumerate(cols):
            if norm(h) in ("说明", "备注", "补充"):
                i_n = i
                break
        for r in raw:
            s = norm(r[i_s]) if 0 <= i_s < len(r) else ""
            n = norm(r[i_n]) if 0 <= i_n < len(r) else ""
            rows.append([s, n])
    else:
        C.refuse("缺少输入", "用法：compliance-self-protect.py <场景清单.csv>  或  --topic 虚开发票")

    main_rows, exc_rows = [], []
    for n, (s, note) in enumerate(rows, start=1):
        if not s:
            exc_rows.append(["", "", "行内无场景，无法匹配", "高", n])
            continue
        key = resolve(s)
        if not key:
            exc_rows.append([s, "", "未收录风险点，须人工判断或换表述", "中", n])
            continue
        lvl, act, red = KB[key]
        main_rows.append([key, lvl, act, red, note])

    if len(main_rows) + len(exc_rows) != len(rows):
        C.refuse("条目不守恒：输入 %d ≠ 主表 %d + 异常 %d"
                 % (len(rows), len(main_rows), len(exc_rows)), "本包不放行对不上账的结果")

    mcols = ["风险点", "风险等级", "自保动作", "红线", "备注"]
    ecols = ["场景", "备注", "异常原因", "风险等级"]
    checks = [
        ("核验口径", "已收录风险点 → 自保清单；未收录 → 异常表，不编造"),
        ("风险库条目", len(KB)),
        ("规则版本", RULE_VERSION),
        ("重要声明", "本包仅做风险识别与自保动作提示，不做法律辩护；红线以主管机关/司法机关认定为准；涉嫌违法的筹划意图本包拒绝"),
        ("条目守恒", "输入 %d = 主表 %d + 异常 %d" % (len(rows), len(main_rows), len(exc_rows))),
    ]

    out_dir = args.out_dir or os.path.join(os.getcwd(), "_out")
    print("--- 合规自保清单（共 %d 条，%d 条须人工判断）---" % (len(main_rows), len(exc_rows)))
    for r in main_rows:
        print("  [%s] %s | 红线：%s" % (r[1], r[0], r[3][:24]))
    if exc_rows:
        print("--- 须人工判断（%d 条）---" % len(exc_rows))
        for r in exc_rows:
            print("  %s %s" % (str(r[0])[:18], r[2]))

    if not C.check_execute(argparse.Namespace(execute=args.execute), "落盘四件套"):
        return 0

    C.emit_four(SLUG, VERSION, out_dir, "合规自保", (mcols, main_rows), (ecols, exc_rows),
                checks=checks, src=args.file or ("(--topic %s)" % " ".join(args.topic)), row_in=len(rows),
                rule_version=RULE_VERSION, operator=args.operator, assert_amount=False)
    print("\n已生成四件套 -> %s" % out_dir)
    C.show_checks(out_dir, "合规自保")
    return 0


if __name__ == "__main__":
    sys.exit(main())
