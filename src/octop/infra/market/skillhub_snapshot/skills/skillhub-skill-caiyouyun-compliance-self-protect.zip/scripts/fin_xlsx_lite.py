#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""fin_xlsx_lite.py — 纯标准库读写 .xlsx / .csv

财友云财税技能共享内核。零第三方依赖：只用 zipfile + xml.etree + csv。
实测（2026-09-27）：写出 1643 字节 xlsx 并正确读回中文 / 小数 / 多列。

设计原则（财税场景专用）：
- 日期序列号**不做自动转换** —— 财务表里 45000 可能是金额也可能是日期，
  自动猜测会算错钱。只提供 serial_to_date() 工具，由上层按字段字典决定。
- 读不到就说读不到，绝不返回空表假装成功。
"""
import csv
import datetime
import io
import os
import re
import zipfile
from xml.etree import ElementTree as ET

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
PKGREL = "{http://schemas.openxmlformats.org/package/2006/relationships}"
ENC_TRY = ("utf-8-sig", "utf-8", "gbk", "gb18030", "latin-1")


# ---------- 工具 ----------
def col_idx(ref):
    """A1 -> 0, B2 -> 1, AA1 -> 26"""
    m = re.match(r"([A-Z]+)", ref or "")
    if not m:
        return None
    n = 0
    for ch in m.group(1):
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def col_name(i):
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def serial_to_date(v):
    """Excel 1900 日期序列号 -> date。含 1900 闰年 bug 修正。"""
    if not isinstance(v, (int, float)):
        return None
    if v < 1 or v > 80000:
        return None
    try:
        return datetime.date(1899, 12, 30) + datetime.timedelta(days=int(v))
    except Exception:
        return None


def _num(txt):
    if txt is None or txt == "":
        return None
    try:
        return float(txt) if ("." in txt or "e" in txt.lower()) else int(txt)
    except Exception:
        return None


# ---------- 读 ----------
def read_xlsx(path, sheet=None):
    """-> {sheets:[name], sheet:name, columns:[...], rows:[[...]]}"""
    if not zipfile.is_zipfile(path):
        raise ValueError("不是有效的 .xlsx（可能是由 Excel 另存的旧格式或已损坏）: %s" % path)
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.iter(NS + "si"):
                shared.append("".join(t.text or "" for t in si.iter(NS + "t")))
        wb = ET.fromstring(z.read("xl/workbook.xml")) if "xl/workbook.xml" in names else None
        rels = {}
        if "xl/_rels/workbook.xml.rels" in names:
            rr = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            for rel in rr.iter(PKGREL + "Relationship"):
                rels[rel.get("Id")] = rel.get("Target")
        sheet_meta = []
        if wb is not None:
            for sh in wb.iter(NS + "sheet"):
                rid = sh.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
                tgt = rels.get(rid, "")
                tgt = tgt.lstrip("/")
                if not tgt.startswith("xl/"):
                    tgt = "xl/" + tgt
                sheet_meta.append((sh.get("name"), tgt))
        if not sheet_meta:
            sheet_meta = [(n, n) for n in sorted(x for x in names if re.match(r"xl/worksheets/sheet\d+\.xml$", x))]
        target = sheet_meta[0]
        if sheet:
            cand = [m for m in sheet_meta if m[0] == sheet]
            if not cand:
                raise ValueError("找不到工作表「%s」，现有：%s" % (sheet, "、".join(m[0] for m in sheet_meta)))
            target = cand[0]
        if target[1] not in names:
            raise ValueError("工作表文件缺失: %s" % target[1])
        root = ET.fromstring(z.read(target[1]))
        grid = {}
        for row in root.iter(NS + "row"):
            try:
                ri = int(row.get("r"))
            except Exception:
                continue
            cells = {}
            for c in row.iter(NS + "c"):
                ci = col_idx(c.get("r"))
                if ci is None:
                    continue
                t = c.get("t")
                v = c.find(NS + "v")
                isx = c.find(NS + "is")
                if t == "s" and v is not None:
                    try:
                        val = shared[int(v.text)]
                    except Exception:
                        val = ""
                elif t == "inlineStr" or isx is not None:
                    val = "".join(x.text or "" for x in (isx.iter(NS + "t") if isx is not None else []))
                elif v is not None:
                    if t == "b":
                        val = (v.text == "1")
                    else:
                        n = _num(v.text)
                        val = v.text if n is None else n
                else:
                    val = ""
                cells[ci] = val
            if cells:
                grid[ri] = cells
        if not grid:
            return {"sheets": [m[0] for m in sheet_meta], "sheet": target[0], "columns": [], "rows": [], "n": 0}
        row_ids = sorted(grid)
        width = max(max(grid[r]) + 1 for r in row_ids)
        matrix = [[grid[r].get(i, "") for i in range(width)] for r in row_ids]
        return {"sheets": [m[0] for m in sheet_meta], "sheet": target[0],
                "columns": [str(x) for x in matrix[0]], "rows": matrix[1:], "n": len(matrix) - 1}


def read_csv_text(path):
    raw = open(path, "rb").read()

    # 常见错：.xlsx 被改名成 .csv，或直接粘了个 PDF/图片进来。
    # 不检测的话会抛一串看不懂的解码错误，用户根本不知道该换什么文件。
    if raw[:4] == b"PK\x03\x04":
        raise ValueError(
            "「%s」实际是一个 .xlsx（Excel 工作簿），不是 CSV。"
            "本包按扩展名分派，请改用 .xlsx 原文件，或先用 lexord-excel-csv-toolkit 转成 CSV。"
            % os.path.basename(path))
    if raw[:4] == b"%PDF":
        raise ValueError("「%s」是 PDF，本包读不了表格内容" % os.path.basename(path))
    if raw[:2] in (b"\xff\xd8", b"BM") or raw[:3] == b"\x89PNG" or raw[:6] in (b"GIF87a", b"GIF89a"):
        raise ValueError("「%s」是图片，本包读不了表格内容" % os.path.basename(path))

    last = None
    for enc in ENC_TRY:
        try:
            txt = raw.decode(enc)
            break
        except Exception as e:
            last = e
    else:
        raise ValueError("无法识别文件编码（已试 %s）：%s。文件可能是损坏的导出件"
                         % ("/".join(ENC_TRY), path))
    # 归一化换行：Mac 老格式 \r 与混合 \r\n 都会让 csv 模块报莫名错误
    return txt.replace("\r\n", "\n").replace("\r", "\n")


def read_csv(path, delimiter=None):
    txt = read_csv_text(path)
    if delimiter is None:
        first = txt.split("\n", 1)[0]
        delimiter = "\t" if first.count("\t") > first.count(",") else ","
    rdr = csv.reader(io.StringIO(txt), delimiter=delimiter)
    rows = [r for r in rdr]
    if not rows:
        return {"sheets": ["csv"], "sheet": "csv", "columns": [], "rows": [], "n": 0}
    return {"sheets": ["csv"], "sheet": "csv", "columns": [str(x) for x in rows[0]], "rows": rows[1:], "n": len(rows) - 1}


def read_table(path, sheet=None):
    """统一入口：按扩展名分派。返回 dict 含 columns / rows / n / sheet / sheets"""
    if not os.path.exists(path):
        raise FileNotFoundError("文件不存在: %s" % path)
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return read_xlsx(path, sheet)
    if ext in (".csv", ".tsv", ".txt"):
        return read_csv(path)
    raise ValueError("不支持的格式 %s（仅 .xlsx / .csv / .tsv；PDF 与图片不是表格文件，本包读不了）" % ext)


# ---------- 写 ----------
def write_xlsx(path, columns, rows, sheet_name="Sheet1"):
    def esc(v):
        return (str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace('"', "&quot;"))
    body = []
    r = 1
    body.append('<row r="1">%s</row>' % "".join(
        '<c r="%s1" t="inlineStr"><is><t>%s</t></is></c>' % (col_name(i), esc(v)) for i, v in enumerate(columns)))
    for row in rows:
        r += 1
        cs = []
        for i, v in enumerate(row):
            ref = "%s%d" % (col_name(i), r)
            if isinstance(v, bool):
                cs.append('<c r="%s" t="inlineStr"><is><t>%s</t></is></c>' % (ref, "TRUE" if v else "FALSE"))
            elif isinstance(v, (int, float)):
                cs.append('<c r="%s"><v>%s</v></c>' % (ref, v))
            else:
                cs.append('<c r="%s" t="inlineStr"><is><t>%s</t></is></c>' % (ref, esc(v if v is not None else "")))
        body.append('<row r="%d">%s</row>' % (r, "".join(cs)))
    sheet = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
             '<sheetData>%s</sheetData></worksheet>' % "".join(body))
    wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
          '<sheets><sheet name="%s" sheetId="1" r:id="rId1"/></sheets></workbook>' % esc(sheet_name))
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
          '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            '</Relationships>')
    wbr = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
           '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
           '</Relationships>')
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", wb)
        z.writestr("xl/_rels/workbook.xml.rels", wbr)
        z.writestr("xl/worksheets/sheet1.xml", sheet)
    return path


def write_csv(path, columns, rows):
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(columns)
        for r in rows:
            w.writerow(["" if v is None else v for v in r])
    return path


def write_table(path, columns, rows, sheet_name="Sheet1"):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        return write_xlsx(path, columns, rows, sheet_name)
    if ext in (".csv", ".tsv", ".txt"):
        return write_csv(path, columns, rows)
    raise ValueError("不支持的写出格式 %s（仅 .xlsx / .csv）" % ext)


# ---------- 金额 / 数值清洗 ----------
_AMOUNT_RE = re.compile(r"^\s*[¥$€]?\s*-?\s*[\d,，]+(\.\d+)?\s*元?\s*$")


def to_amount(v):
    """'1,200.50' / '¥1200' / ' 1200 元' -> 1200.5；识别不了返回 None（绝不猜）"""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    if not _AMOUNT_RE.match(s):
        return None
    s = s.replace("¥", "").replace("$", "").replace("€", "").replace("元", "")
    s = s.replace(",", "").replace("，", "").strip()
    try:
        return float(s)
    except Exception:
        return None


_DATE_PATTERNS = [
    (re.compile(r"^(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})日?$"), lambda m: (int(m.group(1)), int(m.group(2)), int(m.group(3)))),
    (re.compile(r"^(\d{4})(\d{2})(\d{2})$"), lambda m: (int(m.group(1)), int(m.group(2)), int(m.group(3)))),
]


def to_date(v):
    """多种日期写法 -> 'YYYY-MM-DD'；识别不了返回 None（绝不猜）"""
    if isinstance(v, datetime.date):
        return v.isoformat()
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        d = serial_to_date(v)
        return d.isoformat() if d else None
    s = str(v).strip() if v is not None else ""
    if not s:
        return None
    for pat, fn in _DATE_PATTERNS:
        m = pat.match(s)
        if m:
            try:
                y, mo, d = fn(m)
                return datetime.date(y, mo, d).isoformat()
            except Exception:
                return None
    return None
