#!/usr/bin/env python3
# 把目录下的 srt 字幕转成带时间戳的纯文本
# 用法: srt_to_txt.py <目录>
import sys, glob, os, re

out = sys.argv[1]
for f in sorted(glob.glob(os.path.join(out, "*.srt"))):
    blocks = open(f, encoding="utf-8").read().strip().split("\n\n")
    parts, last = [], -999
    for b in blocks:
        L = b.split("\n")
        if len(L) < 3: continue
        h, m, s = L[1].split(" --> ")[0].split(":")
        sec = int(h)*3600 + int(m)*60 + float(s.replace(",", "."))
        txt = " ".join(x.strip() for x in L[2:]).strip()
        if not txt: continue
        if sec - last >= 25:
            parts.append(f"\n\n[{int(sec)//60:02d}:{int(sec)%60:02d}] "); last = sec
        parts.append(txt)
    dst = re.sub(r"\.[a-z-]+\.srt$", ".txt", f)
    open(dst, "w", encoding="utf-8").write("".join(parts).strip())
    print("TXT:", dst)
