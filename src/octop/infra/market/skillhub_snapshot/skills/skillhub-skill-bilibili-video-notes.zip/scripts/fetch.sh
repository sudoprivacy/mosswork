#!/usr/bin/env bash
# 拉取 B站 视频字幕并转成带时间戳的纯文本
# 用法: fetch.sh <输出目录> <B站链接或BV号> [更多链接...]
# 环境变量: BILI_BROWSER=chrome|edge|firefox|safari|brave (默认 chrome)
set -uo pipefail

OUT="${1:-}"; shift || true
BROWSER="${BILI_BROWSER:-chrome}"

if [ -z "$OUT" ] || [ $# -eq 0 ]; then
  echo "用法: fetch.sh <输出目录> <链接1> [链接2 ...]" >&2; exit 2
fi
mkdir -p "$OUT"

if ! command -v yt-dlp >/dev/null 2>&1; then
  echo "MISSING_YTDLP: 未安装 yt-dlp，请先执行 brew install yt-dlp" >&2; exit 3
fi

norm() {   # 只给了 BV 号时补成完整链接
  case "$1" in
    BV*|bv*) echo "https://www.bilibili.com/video/$1" ;;
    *)       echo "$1" ;;
  esac
}

ok=0; fail=0
for raw in "$@"; do
  URL="$(norm "$raw")"
  echo "==== $URL ===="

  # 1) 看有哪些字幕
  LIST="$(yt-dlp --cookies-from-browser "$BROWSER" --skip-download --list-subs "$URL" 2>&1)"
  if echo "$LIST" | grep -q "HTTP Error 412"; then
    echo "ERR_412: B站风控拦截。请确认已在 $BROWSER 中登录 B站，且 cookie 可读（必要时先完全退出浏览器再重试）" >&2
    fail=$((fail+1)); continue
  fi
  if echo "$LIST" | grep -qi "Unable to extract\|ERROR:"; then
    echo "$LIST" | grep -i "ERROR" | head -3 >&2
    fail=$((fail+1)); continue
  fi

  # 2) 选字幕语言：人工 zh 优先，其次 AI 中文，最后任意 AI 语言
  LANG=""
  echo "$LIST" | grep -qE "^zh[[:space:]]"    && LANG="zh"
  [ -z "$LANG" ] && echo "$LIST" | grep -qE "^ai-zh[[:space:]]" && LANG="ai-zh"
  [ -z "$LANG" ] && LANG="$(echo "$LIST" | grep -oE '^ai-[a-z]+' | head -1)"
  if [ -z "$LANG" ]; then
    echo "NO_SUBS: 这个视频没有任何字幕（人工或AI）。可改用：网页端「AI视频总结」复制文本，或下载音频后本地转写" >&2
    fail=$((fail+1)); continue
  fi
  echo "字幕语言: $LANG"

  # 3) 下载字幕
  yt-dlp --cookies-from-browser "$BROWSER" --skip-download \
         --write-subs --sub-langs "$LANG" --sub-format srt \
         -o "$OUT/%(title).80s.%(ext)s" "$URL" 2>&1 | grep -E "Writing video subtitles|ERROR" || true

  ok=$((ok+1))
done

# 4) 全部 srt 转成带时间戳的纯文本
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
python3 "$SCRIPT_DIR/srt_to_txt.py" "$OUT"

echo "----"
echo "成功 $ok 个，失败 $fail 个，输出目录: $OUT"
