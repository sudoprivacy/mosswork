---
name: skillhub-skill-bilibili-thumbnail-maker
description: "使用 AI 将视频选题、标题、脚本、关键帧、人物照、商品图或参考图制作成 B站封面、B站视频封面、哔哩哔哩封面、可发布的 B站缩略图和 AI B站封面。打造主体明确、层级清晰、适合缩略图浏览的封面视觉与标题留白，B站封面设计覆盖知识讲解、数码评测、生活Vlog、游戏、美食、影视与娱乐内容；也可将已选封面精修为账号系列风格。"
---

# B站视频封面制作

根据视频选题、标题、脚本、关键帧截图、人物照、商品图、视觉参考或已选方案，制作一张 B站视频缩略图。复用已知的频道风格和观众背景，以最短路径完成清晰的缩略图。

## 选择创作路线

- **生成封面：** 不需要源图时，根据视频选题、标题、钩子或脚本使用 `beatra.images.generate`。
- **从图片合成：** 上传导出的关键帧、人物图、商品图或有顺序的参考，使用 `beatra.images.transform`。用户只有视频文件时，请提供一张导出的关键帧或截图；此图片工作流不会从视频中抽取帧。
- **精修已选缩略图：** 用 `beatra.images.edit` 精修已选图片，并将其放在 `images[0]`；局部修改最多两个规范化区域。

本 Skill 制作新的视觉素材；只评估现有封面时使用 `cover-performance-preflight`，所需结果是视频本身时使用 `product-video-studio`。

## 整理缩略图简报

复用选题、标题、频道系列风格、目标观众、视觉参考和必须保留的信息。选题或标题是硬输入：封面必须能和标题一起读，两者都缺时先问再付费。画布以用户说明的投放位置、源帧或当前发布要求为准；只有当横版视频缩略图确为用户目标时才提出横版画布，并在付费调用前冻结准确画布。若描述多个候选，必须是结构差，不是换色。

规划一个醒目的主体、清楚的小尺寸层级、一个视觉钩子、标题安全区和有顺序的图片角色。优先使用标题安全区，而不是承诺准确生成的中文文字或 logo。用户要求图中文字时，在付费确认中纳入准确短文案，并且只在确实可见时逐字检查。

## 准备并确认一次付费请求

每个远程 Beatra 操作只能使用本 Skill 随包的 `scripts/mcp_client.py`。不要配置或调用宿主 Beatra Connector，也不要使用 REST/OpenAPI 作为回退。通过随包客户端上传本地图片，并按保留的输入顺序标注每个 artifact 的角色。上传不会检查媒体；只根据可访问图片和结果做视觉判断。

默认保持 `model: "auto"` 和 `count: 1`，除非用户选择其他值。只有可用性、控制项、兼容性或价格需要真实决定时才调用 `beatra.models.list`。生成前展示并冻结提示词、准确画布、图片角色及顺序、标题处理、模型、控制项和数量。策划免费，生成请求是付费工作。

获批后，创建不含用户内容的稳定不透明 `client_request_id`，只提交一次。提示词、图片或顺序、画布、模型、数量或控制项发生变化就会开始新的付费工作，需要新的确认和请求 ID。请求结构见工作流（references/workflow.md）。

## 跟踪、检查与交付

记录返回的 `task_id`，只用 `beatra.tasks.get` 轮询该任务。ID 遗失时，通过 `beatra.tasks.list` 找到候选，再用 `tasks.get` 核验选中的任务。只有原始创建响应确实未知时，才用相同 ID 重放完全相同的请求。慢轮询、连接、更新或授权错误都不能成为替代付费请求的理由。

只有用户要求时才使用 `beatra.tasks.cancel`。返回 `409` 表示原任务仍在运行，应继续跟踪。结果可见后，检查小尺寸识别度、主体层级、安全区对比、裁切风险、已确认画布和必须保留的信息。交付 artifact 链接、已观察到的尺寸、任务 ID、解析后的模型和返回的 `billing.net_charged_credits`。最多提供一个尚未执行的聚焦精修。

## 按任务查阅参考

- 请求结构、源图顺序和编辑：工作流（references/workflow.md）
- 初次安装或授权过期：安装与认证（references/installation-and-auth.md）
- 随包客户端诊断：随包 MCP Client 连接诊断（references/mcp-connection.md）
- 注册：安装注册（references/installation-registration.md）
- 轮询和输出字段：任务与结果（references/tasks-and-results.md）
- 计费与恢复：计费、错误与恢复（references/billing-errors-and-recovery.md）
- 断开连接：卸载与断开（references/uninstall-and-disconnect.md）
- 更新与安全：更新与安全（references/updates-and-security.md）

## 更新与安全

本 Skill 会自动更新。内置客户端每天最多一次从 Beatra 官网读取本渠道的版本信息
（中国大陆网络走 www.beatra.cn 与 cdn.beatra.cn）。有新版本时，它下载官方发布包，
逐个文件校验 SHA-256，再替换本 Skill 自己的文件；你放进这个目录的其他文件不会被
改动。替换过程中断时，下次运行会自动恢复到替换前的状态。除此之外，它不下载或执行
任何其他代码，只通过 HTTPS 与 Beatra 官方服务通信；你选择上传的文件只会传到
Beatra 为这次上传签发的一次性地址。

关闭自动更新：`python3 scripts/mcp_client.py update --auto off`。关闭后，客户端每天
最多提示一次在你安装它的商店里更新的命令。详见更新与安全（references/updates-and-security.md）。
