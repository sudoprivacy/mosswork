# -*- coding: utf-8 -*-
"""市场强度增速分析 · 调用壳。

只从外部服务取回已算好的结果并渲染，不含任何取数逻辑或业务规则。

配置（二选一）：
  1) 环境变量 GROWTH_API_URL = 服务根地址
  2) 技能根目录 config.json，内容形如 {"api_url": "服务根地址"}
可选：GROWTH_API_TOKEN（服务端启用令牌时携带）。

产物：output/市场强度_增速分析_<日期>.html 与同名 .json
"""
import os
import json
import urllib.request
import urllib.error
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT_DIR = os.path.join(ROOT, "output")
os.makedirs(OUT_DIR, exist_ok=True)


def service_url():
    u = os.environ.get("GROWTH_API_URL", "").strip()
    if not u:
        cfg = os.path.join(ROOT, "config.json")
        if os.path.exists(cfg):
            with open(cfg, "r", encoding="utf-8") as f:
                u = (json.load(f).get("api_url") or "").strip()
    if not u:
        raise SystemExit(
            "未配置服务地址。请设置环境变量 GROWTH_API_URL，"
            "或在技能根目录放置 config.json（含 api_url）。"
        )
    return u.rstrip("/")


def api_endpoint(path):
    """把服务地址与端点路径正确拼接，保留地址中原有的查询参数（如分享码）。"""
    p = urlsplit(service_url())
    query = parse_qsl(p.query, keep_blank_values=True)
    base = p.path.rstrip("/")
    return urlunsplit((p.scheme, p.netloc, base + path, urlencode(query), ""))


def fetch():
    req = urllib.request.Request(api_endpoint("/api/growth"),
                                 headers={"Accept": "application/json"})
    tok = os.environ.get("GROWTH_API_TOKEN", "").strip()
    if tok:
        req.add_header("X-Growth-Token", tok)
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise SystemExit("服务返回错误 %s，请稍后重试或检查服务地址。" % e.code)
    except Exception:
        raise SystemExit("无法连接服务。请确认服务地址正确且服务在线。")
    if not isinstance(data, dict) or "date" not in data:
        raise SystemExit("服务返回的数据格式异常，请稍后重试。")
    return data


# ---------------- 结果渲染（不含任何计算） ----------------
def fmt_g(v):
    return "—" if v is None else ("%+.2f%%" % v)


def named(items, n):
    if not items:
        return "无"
    s = "、".join("%s（%s）" % (x["name"], fmt_g(x["growth"])) for x in items)
    if len(items) < n:
        s += "　［要求 %d 项，实际 %d 项］" % (n, len(items))
    return s


def row_html(x):
    bull_cls = "bull" if x["bull"] else "bear"
    bull_txt = "牛市" if x["bull"] else "熊市"
    tag_html = ('<span class="tag">%s</span>' % x["tag"]) if x.get("tag") else "—"
    return ("<tr><td class='name'>%s</td><td>%+.3f</td><td>%+.3f</td>"
            "<td class='%s'>%s</td><td class='%s'>%s</td><td>%s</td></tr>" %
            (x["name"], x["today"], x["yesterday"],
             "pos" if (x["growth"] or 0) >= 0 else "neg", fmt_g(x["growth"]),
             bull_cls, bull_txt, tag_html))


def table_block(title, rows):
    body = "\n".join(row_html(x) for x in rows)
    return """<div class="card">
  <div class="card-h">%s<span class="cnt">%d 项</span></div>
  <div class="tbl-wrap"><table>
    <thead><tr><th>名称</th><th>当天强度</th><th>昨天强度</th><th>增速</th><th>牛市判定</th><th>入选</th></tr></thead>
    <tbody>%s</tbody>
  </table></div>
</div>""" % (title, len(rows), body)


def elim_block(rows):
    if not rows:
        body = ("<tr><td colspan='6' style='text-align:center;color:#9a988f;'>"
                "无（当前无牛市且增速为负的项）</td></tr>")
    else:
        body = "\n".join(
            "<tr><td class='name'>%s</td><td>%s</td><td>%+.3f</td><td>%+.3f</td>"
            "<td class='neg'>%s</td><td>牛市</td></tr>" % (
                x["name"], x.get("category", "—"),
                x["today"], x["yesterday"], fmt_g(x["growth"]),
            ) for x in rows
        )
    return """<div class="card">
  <div class="card-h">已剔除 · 牛市且增速为负<span class="cnt">%d 项</span></div>
  <div class="tbl-wrap"><table>
    <thead><tr><th>名称</th><th>类别</th><th>当天强度</th><th>昨天强度</th><th>增速</th><th>牛市判定</th></tr></thead>
    <tbody>%s</tbody>
  </table></div>
</div>""" % (len(rows), body)


def main():
    d = fetch()
    date = d["date"]
    win = "、".join(d.get("window", []))

    summary = """<div class="card sum">
  <div class="card-h">四类入选名单</div>
  <ul class="sum-list">
    <li><b>指数 · 增速最快 2 个：</b>%s</li>
    <li><b>指数 · 牛市且增速最快 2 个：</b>%s</li>
    <li><b>行业 · 增速最快 3 个：</b>%s</li>
    <li><b>行业 · 牛市且增速最快 3 个：</b>%s</li>
  </ul>
</div>""" % (
        named(d.get("idx_fast2", []), 2),
        named(d.get("idx_bull_fast2", []), 2),
        named(d.get("ind_fast3", []), 3),
        named(d.get("ind_bull_fast3", []), 3),
    )

    html = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>市场强度增速分析 %s</title>
<style>
  body{font-family:-apple-system,'Microsoft YaHei','Segoe UI',sans-serif;background:#f5f6f4;color:#2b2a27;margin:0;padding:28px 18px 60px;}
  .wrap{max-width:960px;margin:0 auto;}
  h1{font-size:23px;margin:0 0 4px;color:#245b7a;}
  .sub{color:#6b6a64;font-size:13px;margin-bottom:18px;line-height:1.7;}
  .sub b{color:#245b7a;}
  .card{background:#fff;border:1px solid #e7e5df;border-radius:12px;margin-bottom:18px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.04);}
  .card-h{font-size:16px;font-weight:700;color:#245b7a;padding:13px 16px;border-bottom:1px solid #eef0ee;display:flex;justify-content:space-between;align-items:center;}
  .cnt{font-size:12px;color:#9a988f;font-weight:500;}
  .tbl-wrap{overflow-x:auto;}
  table{border-collapse:collapse;width:100%%;font-size:13.5px;}
  th,td{padding:9px 14px;text-align:right;border-bottom:1px solid #f0efe9;white-space:nowrap;}
  th{background:#f7f9fa;color:#5a5852;font-weight:600;text-align:right;}
  td.name,th:first-child{text-align:left;font-weight:600;}
  tr:hover td{background:#fafcff;}
  .pos{color:#c0392b;font-weight:600;}
  .neg{color:#2e7d32;font-weight:600;}
  .bull{color:#c0392b;font-weight:700;}
  .bear{color:#2e7d32;font-weight:700;}
  .tag{display:inline-block;background:#eaf1f6;color:#245b7a;border:1px solid #cfe0ec;border-radius:6px;padding:2px 7px;font-size:11.5px;margin-left:2px;}
  .sum .sum-list{margin:0;padding:14px 20px 16px 36px;line-height:2;}
  .sum .sum-list b{color:#245b7a;}
</style></head><body><div class="wrap">
  <h1>市场强度增速分析</h1>
  <div class="sub">
    数据日期 <b>%s</b> · 3 日窗口 <b>%s</b>
  </div>
  %s
  %s
  %s
  %s
</div></body></html>""" % (
        date, date, win,
        summary,
        table_block("指数类 — 按增速降序", d.get("idx_detail", [])),
        table_block("行业类 — 按增速降序", d.get("ind_detail", [])),
        elim_block(d.get("eliminated", [])),
    )

    stamp = date.replace("/", "")
    out_html = os.path.join(OUT_DIR, "市场强度_增速分析_%s.html" % stamp)
    out_json = os.path.join(OUT_DIR, "市场强度_增速分析_%s.json" % stamp)
    with open(out_html, "w", encoding="utf-8") as f:
        f.write(html)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)

    print("\n=== 市场强度增速分析 · %s ===" % date)
    print("窗口:", win)
    print("指数 · 增速最快 2 个:", named(d.get("idx_fast2", []), 2))
    print("指数 · 牛市且增速最快 2 个:", named(d.get("idx_bull_fast2", []), 2))
    print("行业 · 增速最快 3 个:", named(d.get("ind_fast3", []), 3))
    print("行业 · 牛市且增速最快 3 个:", named(d.get("ind_bull_fast3", []), 3))
    print("\n输出 HTML:", out_html)
    print("输出 JSON:", out_json)


if __name__ == "__main__":
    main()
