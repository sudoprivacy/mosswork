---
name: skillhub-skill-1288888
description: "AI-friendly MCP server for Hacker News. Use when the user wants to browse current HN top stories, look up a story by id, or says things like 「帮我看一下 Hacker News 现在的热门」「用 MCP 拉一下 HN top stories」「获取 Hacker News 前 10 条」「调用 get_top_stories」. Ships with a built-in fixture — no API key, no network required."
---

# hackernews-mcp

A read-only **MCP** server exposing Hacker News top stories to LLM agents.
Designed for the `skillhub` marketplace.

## When to use

Trigger this skill when the user:

- Asks for **Hacker News / HN** top or hot stories.
- Wants to **look up one HN story** by its numeric id.
- Explicitly names the tool (`get_top_stories`, `get_story_by_id`) or the
  server (`hackernews-mcp`).

Example trigger phrases (Chinese and English):

- 「帮我看一下 Hacker News 现在的热门」
- 「用 MCP 拉一下 HN top stories」
- 「获取 Hacker News 前 10 条」
- "show me the current HN front page"
- "call get_top_stories with limit 5"

## Tools

| Tool | Description | Arguments |
|------|-------------|-----------|
| `get_top_stories` | Current top stories from Hacker News | `limit: int = 10`, clamped to `[1, 30]` |
| `get_story_by_id`  | Fetch a single story by its id       | `story_id: int` |

Both tools return a **UTF-8 JSON string**. `get_top_stories` returns an
array of `{id, title, url, score}` objects; `get_story_by_id` returns a
single-element array, or `{}` when the id does not exist. `url` is
`null` for self-posts (`Ask HN`, `Show HN`).

Out-of-range `limit` values are **clamped, not rejected** — the LLM may
miscount items, and forgiving behaviour avoids noisy retries. Non-int
`limit` values raise `TypeError`.

## Prerequisites

- Python **3.10+** (uses `from __future__ import annotations` and
  `X | Y` union syntax in docs)
- One runtime dependency: `mcp>=1.0.0`

## Install

```bash
cd day032/skill
pip install -r requirements.txt
```

## Run

The server speaks MCP over **stdio**:

```bash
python server.py           # primary entry
python -m hackernews_mcp   # module entry (same effect)
python main.py             # thin alias
```

### Register with an MCP host

```json
{
  "mcpServers": {
    "hackernews": {
      "command": "python",
      "args": ["/absolute/path/to/day032/skill/server.py"]
    }
  }
}
```

### Smoke test without an MCP host

```bash
python -c "from server import get_top_stories, get_story_by_id; print(get_top_stories(3))"
python -c "from server import get_story_by_id; print(get_story_by_id(1))"
```

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

11 unit tests cover: limit clamping (0 / negative / above-max / non-int
/ bool), default limit, JSON shape, existing / missing / non-positive
story ids, and `Story` immutability.

## Data source

The default data layer returns `MOCK_STORIES`, a curated, deterministic
fixture (10 stories, stable ordering). This keeps the server fully
offline and its output reproducible — valuable when the agent needs a
predictable answer.

To swap in the real Hacker News Firebase API later, replace the body of
`load_stories()` in `server.py`. **The tool surface does not change** —
this is the single integration point by design.

## Project layout

```
skill/
├── SKILL.md             # this file — marketplace-facing entry doc
├── chatmcp.yaml         # skillhub metadata (name / description / config)
├── server.py            # MCP server + tools (data + validation + logging)
├── main.py              # `python main.py` thin wrapper
├── __init__.py          # `python -m hackernews_mcp` entry point
├── requirements.txt     # runtime deps (mcp)
├── requirements-dev.txt # + pytest
├── README.md            # human-readable docs
├── LICENSE              # MIT
├── .gitignore
└── tests/
    └── test_server.py   # unit tests
```

## License

MIT — see [LICENSE](LICENSE).
