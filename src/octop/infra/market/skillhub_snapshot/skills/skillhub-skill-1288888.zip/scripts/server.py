"""
hackernews-mcp: AI-friendly MCP server for Hacker News.

Exposes read-only tools that an LLM agent can call to browse the front
page of Hacker News.  The default implementation ships a curated,
deterministic MOCK_STORIES fixture so the server runs out-of-the-box
without any network access or API key.  The data layer is intentionally
isolated in ``load_stories()`` so a live HN client can be dropped in
later without touching the tool surface.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from typing import List, Optional

from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
# MCP transports do their own framing, so keep server-side logging terse.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("hackernews_mcp")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_LIMIT: int = 10
MIN_LIMIT: int = 1
MAX_LIMIT: int = 30  # Keep the LLM's context window happy.

# ---------------------------------------------------------------------------
# Domain model
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Story:
    """A single Hacker News story.

    ``frozen=True`` guarantees the fixture cannot be mutated by accident,
    which matters when the same list may be read concurrently by several
    tool invocations.
    """

    id: int
    title: str
    url: Optional[str]
    score: int

    def to_dict(self) -> dict:
        return asdict(self)


# A small, hand-curated fixture.  Ordering is intentionally stable so the
# tool output is deterministic across calls.
MOCK_STORIES: List[Story] = [
    Story(1,  "Show HN: I built a tiny MCP server",                 "https://example.com/mcp",          512),
    Story(2,  "Ask HN: What are you working on this week?",         None,                               328),
    Story(3,  "Rust 2.0 roadmap announced",                        "https://example.com/rust",          891),
    Story(4,  "Why local-first software matters",                  "https://example.com/local-first",  445),
    Story(5,  "Postgres tips from production",                     "https://example.com/pg",           267),
    Story(6,  "The rise of AI agents in 2026",                      "https://example.com/agents",       703),
    Story(7,  "A deep dive into SQLite internals",                 "https://example.com/sqlite",       389),
    Story(8,  "Open source LLM tooling roundup",                   "https://example.com/llm",          214),
    Story(9,  "How we cut API latency by 80%",                     "https://example.com/latency",      556),
    Story(10, "Writing a kernel module in Zig",                    "https://example.com/zig",          178),
]


# ---------------------------------------------------------------------------
# Data layer (swap-in point for a real HN client)
# ---------------------------------------------------------------------------
def load_stories() -> List[Story]:
    """Return the current top stories.

    Kept as a function (not a constant) so a future implementation can
    transparently fetch from the HN Firebase API.  Returns a *copy* of
    the fixture list to defend against external mutation.
    """
    return list(MOCK_STORIES)


# ---------------------------------------------------------------------------
# Serialisation helper
# ---------------------------------------------------------------------------
def _to_json(stories: List[Story]) -> str:
    """Serialise stories to a pretty, UTF-8 JSON string."""
    return json.dumps(
        [s.to_dict() for s in stories],
        ensure_ascii=False,
        indent=2,
    )


def _validate_limit(limit: int) -> int:
    """Clamp ``limit`` into the allowed range.

    We *clamp* rather than raise because the LLM may miscount items and
    rejecting the call would force a noisy retry.  Clamping is forgiving
    and the response shape is unchanged.
    """
    if not isinstance(limit, int) or isinstance(limit, bool):
        # bool is a subclass of int in Python — reject it explicitly.
        raise TypeError(f"limit must be int, got {type(limit).__name__}")
    return max(MIN_LIMIT, min(limit, MAX_LIMIT))


# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------
mcp = FastMCP("hackernews-mcp")


@mcp.tool()
def get_top_stories(limit: int = DEFAULT_LIMIT) -> str:
    """Return the current top stories from Hacker News.

    Args:
        limit: How many stories to return.  Clamped to the inclusive
            range ``[1, 30]``.  Defaults to 10.

    Returns:
        A UTF-8 JSON string — an array of ``{id, title, url, score}``
        objects, ordered by their rank on the front page.
    """
    n = _validate_limit(limit)
    stories = load_stories()[:n]
    log.info("get_top_stories(limit=%s) -> %d stories", n, len(stories))
    return _to_json(stories)


@mcp.tool()
def get_story_by_id(story_id: int) -> str:
    """Look up a single story by its numeric Hacker News id.

    Args:
        story_id: The integer id (e.g. ``1``).

    Returns:
        A UTF-8 JSON object for the matching story, or an empty object
        if no story with that id exists.
    """
    if not isinstance(story_id, int) or isinstance(story_id, bool):
        raise TypeError(f"story_id must be int, got {type(story_id).__name__}")
    if story_id <= 0:
        return "{}"

    for story in load_stories():
        if story.id == story_id:
            return _to_json([story])

    log.info("get_story_by_id(%s) -> not found", story_id)
    return "{}"


if __name__ == "__main__":
    # stdio transport by default — matches the mcpServers config in README.
    mcp.run()
