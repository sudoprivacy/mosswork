"""Package entry point for ``python -m hackernews_mcp``."""

from __future__ import annotations

import logging
import sys

from .server import mcp

log = logging.getLogger("hackernews_mcp")


def main() -> int:
    """Run the MCP server over stdio.  Returns non-zero on failure."""
    try:
        mcp.run()
        return 0
    except KeyboardInterrupt:  # pragma: no cover - CLI signal
        log.info("Interrupted, shutting down.")
        return 130
    except Exception as exc:  # pragma: no cover - safety net
        log.exception("Fatal error: %s", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
