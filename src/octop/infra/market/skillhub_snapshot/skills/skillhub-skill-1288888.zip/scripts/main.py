"""Allow ``python main.py`` as a thin alias for the MCP server entry."""

from __future__ import annotations

from . import main

if __name__ == "__main__":
    raise SystemExit(main())
