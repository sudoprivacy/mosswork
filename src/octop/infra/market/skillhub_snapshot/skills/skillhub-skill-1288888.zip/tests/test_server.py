"""Unit tests for the hackernews-mcp tool functions.

Run with ``python -m pytest -q`` from the ``skill/`` directory.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

# Make sure we can import the package regardless of where pytest is invoked.
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import server  # noqa: E402  (import after sys.path tweak)


class TestGetTopStories:
    def test_default_limit_returns_ten(self):
        result = json.loads(server.get_top_stories())
        assert isinstance(result, list)
        assert len(result) == 10
        for item in result:
            assert {"id", "title", "url", "score"} <= set(item.keys())

    def test_custom_limit(self):
        for n in (1, 3, 5):
            result = json.loads(server.get_top_stories(n))
            assert len(result) == n

    def test_limit_above_max_is_clamped(self):
        result = json.loads(server.get_top_stories(999))
        # Clamped to MAX_LIMIT but also to actual fixture length.
        assert 1 <= len(result) <= server.MAX_LIMIT

    def test_limit_below_min_is_clamped(self):
        result = json.loads(server.get_top_stories(0))
        # Clamped up to MIN_LIMIT.
        assert len(result) == 1

    def test_negative_limit_is_clamped(self):
        result = json.loads(server.get_top_stories(-7))
        assert len(result) == 1

    def test_limit_must_be_int(self):
        with pytest.raises(TypeError):
            server.get_top_stories("10")  # type: ignore[arg-type]
        with pytest.raises(TypeError):
            server.get_top_stories(True)  # type: ignore[arg-type]

    def test_unicode_is_preserved(self):
        result = server.get_top_stories(1)
        # ensure_ascii=False must leave non-ASCII chars untouched.
        if any(ord(c) > 127 for c in result):
            assert "\\u" not in result


class TestGetStoryById:
    def test_existing_id(self):
        result = json.loads(server.get_story_by_id(1))
        assert result == [{
            "id": 1,
            "title": "Show HN: I built a tiny MCP server",
            "url": "https://example.com/mcp",
            "score": 512,
        }]

    def test_missing_id(self):
        assert server.get_story_by_id(9999) == "{}"

    def test_non_positive_id(self):
        assert server.get_story_by_id(0) == "{}"
        assert server.get_story_by_id(-1) == "{}"

    def test_id_must_be_int(self):
        with pytest.raises(TypeError):
            server.get_story_by_id("1")  # type: ignore[arg-type]


class TestStoryDataclass:
    def test_is_frozen(self):
        s = server.Story(1, "t", "u", 1)
        with pytest.raises(Exception):
            s.id = 999  # type: ignore[misc]

    def test_to_dict_round_trip(self):
        s = server.Story(2, "Ask HN", None, 100)
        assert s.to_dict() == {"id": 2, "title": "Ask HN", "url": None, "score": 100}
