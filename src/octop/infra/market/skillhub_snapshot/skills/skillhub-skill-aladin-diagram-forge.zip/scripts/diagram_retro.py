#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阿拉丁·架构图工坊 — 设计偏好沉淀与复用闭环（diagram_retro.py）。

把每次画图生成的结果（图型 / 格式 / 方向 / 是否分组 / 语法校验结果）沉淀为
本地验证库 diagram_playbook.json，并据历史给出：

  - 下次默认偏好（最常用图型 / 格式 / 方向 / 是否分组、最常用节点形状）
  - 易踩坑预警（哪种格式历史上最常校验不过、平均几处问题，给换格式/避坑建议）

形成「生成 → 沉淀 → 复用 → 越画越贴合你的习惯、越画越稳」的闭环，与自家
aladin / omni 家族「验证库反哺」范式一致。纯标准库，零依赖、不联网、数据不出本机。
"""
import argparse
import json
import os
import sys

PB_NAME = "diagram_playbook.json"

DEFAULT_FMT_BY_TYPE = {  # 各图型的"安全默认格式"建议（仅作 benchmark 提示）
    "architecture": "mermaid",
    "flowchart": "mermaid",
    "sequence": "mermaid",
    "class": "puml",
    "state": "mermaid",
    "er": "puml",
}


# ---------------- 持久化 ----------------
def load_playbook(path):
    if os.path.exists(path):
        try:
            d = json.load(open(path, encoding="utf-8"))
            if isinstance(d, dict) and "records" in d:
                return d
        except Exception:
            pass
    return {"version": 1, "records": []}


def save_playbook(path, pb):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(pb, f, ensure_ascii=False, indent=2)


def _rec(title, dtype, fmt, direction, grouped, passed, issues, nodes, edges):
    return {
        "title": title or "",
        "type": dtype or "",
        "format": fmt or "",
        "direction": direction or "",
        "grouped": bool(grouped),
        "validation_passed": bool(passed),
        "issues_count": int(issues or 0),
        "node_count": int(nodes or 0),
        "edge_count": int(edges or 0),
    }


# ---------------- 对外可调用：记录一次生成 ----------------
def record_build(out_dir, rec, playbook_path=None):
    """供 diagram_build.py --playbook 调用，把一次生成结果写入验证库。"""
    pb_path = playbook_path or os.path.join(out_dir or os.getcwd(), PB_NAME)
    pb = load_playbook(pb_path)
    pb["records"].append(rec)
    save_playbook(pb_path, pb)
    return pb_path


# ---------------- 汇总 ----------------
def suggest(pb):
    recs = pb.get("records", [])
    if not recs:
        return {
            "default_format": "mermaid",
            "default_direction": "TB",
            "default_grouped": False,
            "top_type": "flowchart",
            "top_shapes": ["rect"],
            "samples": 0,
        }
    # 各字段计数
    from collections import Counter
    # 跳过首次多格式产出记录的 format="all"，避免污染最爱格式判定
    fmt_c = Counter(r.get("format", "") for r in recs if r.get("format") and r.get("format") != "all")
    type_c = Counter(r.get("type", "") for r in recs if r.get("type"))
    dir_c = Counter(r.get("direction", "") for r in recs if r.get("direction"))
    grp = [r for r in recs if r.get("grouped")]
    # 通过率最高的格式作为默认格式（同等通过率取使用频次最高）
    pass_by_fmt = {}
    for r in recs:
        f = r.get("format")
        if not f or f == "all":
            continue
        d = pass_by_fmt.setdefault(f, {"n": 0, "ok": 0})
        d["n"] += 1
        if r.get("validation_passed"):
            d["ok"] += 1
    scored = []
    for f, d in pass_by_fmt.items():
        rate = d["ok"] / d["n"] if d["n"] else 0
        scored.append((rate, fmt_c.get(f, 0), f))
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    default_format = scored[0][2] if scored else "mermaid"
    default_direction = dir_c.most_common(1)[0][0] if dir_c else "TB"
    default_grouped = (len(grp) / len(recs)) >= 0.5 if recs else False
    top_type = type_c.most_common(1)[0][0] if type_c else "flowchart"
    return {
        "default_format": default_format,
        "default_direction": default_direction,
        "default_grouped": bool(default_grouped),
        "top_type": top_type,
        "top_shapes": ["rect"],
        "samples": len(recs),
        "fmt_usage": dict(fmt_c),
        "type_usage": dict(type_c),
    }


def benchmark(pb, dtype, fmt):
    recs = pb.get("records", [])
    same = [r for r in recs if r.get("type") == dtype and r.get("format") == fmt]
    out = {"type": dtype, "format": fmt, "samples": len(same)}
    if not same:
        out["note"] = "暂无同类历史数据，建议格式：%s" % DEFAULT_FMT_BY_TYPE.get(dtype, "mermaid")
        out["pass_rate"] = None
        out["avg_issues"] = None
        out["recommend"] = DEFAULT_FMT_BY_TYPE.get(dtype, "mermaid")
        return out
    ok = sum(1 for r in same if r.get("validation_passed"))
    avg_iss = sum(r.get("issues_count", 0) for r in same) / len(same)
    rate = ok / len(same)
    out["pass_rate"] = round(rate, 2)
    out["avg_issues"] = round(avg_iss, 1)
    # 同图型、其它格式里通过率更高的，给换格式建议
    alt = {}
    for r in recs:
        if r.get("type") != dtype:
            continue
        f = r.get("format")
        d = alt.setdefault(f, {"n": 0, "ok": 0})
        d["n"] += 1
        if r.get("validation_passed"):
            d["ok"] += 1
    best_fmt, best_rate = fmt, rate
    for f, d in alt.items():
        if d["n"] == 0:
            continue
        rr = d["ok"] / d["n"]
        if rr > best_rate:
            best_fmt, best_rate = f, rr
    out["recommend"] = best_fmt
    if best_fmt != fmt and best_rate > rate:
        out["note"] = ("该图型历史上 %s 格式通过率 %.0f%%，高于 %s 的 %.0f%%，"
                       "复杂图建议优先用 %s 避免渲染翻车"
                       % (best_fmt, best_rate * 100, fmt, rate * 100, best_fmt))
    elif avg_iss >= 1:
        out["note"] = ("该组合历史上平均 %.1f 处语法问题，生成后留意括号配平 /"
                       " subgraph 与 end 配对 / 节点引用" % avg_iss)
    else:
        out["note"] = "该组合历史上较稳，放心用"
    return out


# ---------------- 子命令 ----------------
def cmd_add(args):
    pb = load_playbook(args.playbook)
    if args.json:
        meta = json.load(open(args.json, encoding="utf-8"))
        rec = _rec(meta.get("title"), meta.get("type"), meta.get("format"),
                   meta.get("direction"), meta.get("grouped"),
                   meta.get("validation_passed"), meta.get("issues_count"),
                   meta.get("node_count"), meta.get("edge_count"))
    else:
        rec = _rec(args.title, args.type, args.format, args.direction,
                   args.grouped, args.validation_passed, args.issues_count,
                   args.node_count, args.edge_count)
    pb["records"].append(rec)
    save_playbook(args.playbook, pb)
    print("✅ 已沉淀 1 条画图记录（共 %d 条）→ %s" % (len(pb["records"]), args.playbook))


def cmd_summary(args):
    pb = load_playbook(args.playbook)
    recs = pb.get("records", [])
    if not recs:
        print("⚠️ 验证库为空，先跑几次 diagram_build.py --playbook 或 diagram_retro.py seed")
        return
    s = suggest(pb)
    print("📊 画图验证库（共 %d 条记录）" % len(recs))
    print("   最常用图型   : %s（%s）" % (s["top_type"], s.get("type_usage", {})))
    print("   默认输出格式 : %s（使用频次 %s）" % (s["default_format"], s.get("fmt_usage", {})))
    print("   默认方向     : %s" % s["default_direction"])
    print("   常分组?      : %s" % ("是" if s["default_grouped"] else "否"))
    # 各格式通过率
    from collections import defaultdict
    stat = defaultdict(lambda: {"n": 0, "ok": 0, "iss": 0})
    for r in recs:
        f = r.get("format")
        if not f or f == "all":
            continue
        stat[f]["n"] += 1
        if r.get("validation_passed"):
            stat[f]["ok"] += 1
        stat[f]["iss"] += r.get("issues_count", 0)
    print("   各格式健康度:")
    for f, d in sorted(stat.items(), key=lambda x: -(x[1]["ok"] / x[1]["n"])):
        rate = d["ok"] / d["n"] if d["n"] else 0
        avg = d["iss"] / d["n"] if d["n"] else 0
        print("     - %-9s 通过率 %.0f%%  平均问题 %.1f 处" % (f, rate * 100, avg))


def cmd_suggest(args):
    pb = load_playbook(args.playbook)
    s = suggest(pb)
    if s["samples"] == 0:
        print("⚠️ 验证库为空，暂无偏好可推荐；先 diagram_retro.py seed 或跑几次 --playbook")
        return
    print("💡 基于你历史的默认偏好（下次 diagram_build.py --playbook 自动套用）:")
    print("   默认格式 : %s" % s["default_format"])
    print("   默认方向 : %s" % s["default_direction"])
    print("   默认分组 : %s" % ("是" if s["default_grouped"] else "否"))
    print("   常画图型 : %s" % s["top_type"])


def cmd_benchmark(args):
    pb = load_playbook(args.playbook)
    b = benchmark(pb, args.type, args.format)
    print("🔍 画图避坑评估（type=%s, format=%s）" % (args.type, args.format))
    print("   同类样本 : %d" % b["samples"])
    if b.get("pass_rate") is not None:
        print("   通过率   : %.0f%%" % (b["pass_rate"] * 100))
        print("   平均问题 : %.1f 处" % b["avg_issues"])
    print("   推荐格式 : %s" % b["recommend"])
    print("   建议     : %s" % b["note"])


def cmd_seed(args):
    pb = load_playbook(args.playbook)
    seeds = [
        _rec("订单服务架构", "architecture", "mermaid", "TB", True, True, 0, 6, 5),
        _rec("登录流程", "flowchart", "mermaid", "TB", False, True, 0, 5, 4),
        _rec("下单时序", "sequence", "mermaid", "", False, True, 1, 4, 3),
        _rec("用户表 ER", "er", "puml", "", False, True, 0, 3, 2),
    ]
    pb["records"].extend(seeds)
    save_playbook(args.playbook, pb)
    print("✅ 已写入 %d 条示例记录（共 %d 条）→ %s" % (len(seeds), len(pb["records"]), args.playbook))


def main():
    ap = argparse.ArgumentParser(description="画图设计偏好沉淀与复用闭环")
    pp = argparse.ArgumentParser(add_help=False)
    pp.add_argument("--playbook", default=PB_NAME, help="验证库路径(默认 ./%s)" % PB_NAME)
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add", parents=[pp], help="沉淀一次画图结果")
    a.add_argument("--json", help="直接读取 build 产出的 <prefix>.meta.json")
    a.add_argument("--title")
    a.add_argument("--type")
    a.add_argument("--format")
    a.add_argument("--direction", default="")
    a.add_argument("--grouped", action="store_true")
    a.add_argument("--validation_passed", action="store_true")
    a.add_argument("--issues_count", type=int, default=0)
    a.add_argument("--node_count", type=int, default=0)
    a.add_argument("--edge_count", type=int, default=0)
    a.set_defaults(func=cmd_add)

    s = sub.add_parser("summary", parents=[pp], help="查看画图偏好画像")
    s.set_defaults(func=cmd_summary)

    sg = sub.add_parser("suggest", parents=[pp], help="给出下次默认偏好")
    sg.set_defaults(func=cmd_suggest)

    b = sub.add_parser("benchmark", parents=[pp], help="评估某组合易踩坑并推荐格式")
    b.add_argument("--type", required=True)
    b.add_argument("--format", required=True)
    b.set_defaults(func=cmd_benchmark)

    sd = sub.add_parser("seed", parents=[pp], help="写入示例记录上手即见")
    sd.set_defaults(func=cmd_seed)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
