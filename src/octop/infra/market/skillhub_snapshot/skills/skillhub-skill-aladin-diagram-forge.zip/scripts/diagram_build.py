#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阿拉丁·架构图工坊 — 图生成器 + 语法校验器。

把 ir.json 渲染为 6 类工程图的源文件（mermaid / PlantUML / DOT），
并在生成后做纯本地语法校验（括号配平、子图开合、节点引用、关键字合法性）。
纯标准库，零依赖。
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# mermaid 节点形状 → 包裹符号
MM_OPEN = {"rect": "[", "rounded": "(", "cylinder": "[(", "diamond": "{",
           "actor": "([", "stadium": "([", "hexagon": "{{", "parallelogram": "[/",
           "doublecircle": "((("}
MM_CLOSE = {"rect": "]", "rounded": ")", "cylinder": ")]", "diamond": "}",
            "actor": "])", "stadium": ")]", "hexagon": "}}", "parallelogram": "/]",
            "doublecircle": ")))"}
MM_EDGE = {"->": "-->", "dotted": "-.->", "thick": "==>", "solid": "-->",
           "arrow": "->>", "dottedarrow": "-.->>"}
PUML_SHAPE = {"cylinder": "database", "diamond": "diamond", "actor": "actor",
              "hexagon": "hexagon", "parallelogram": "rectangle",
              "doublecircle": "circle", "default": "rectangle"}


def _mm_label(label):
    """mermaid 标签转义：含特殊符号则加双引号。"""
    if label is None:
        return ""
    s = str(label)
    if any(ch in s for ch in "[](){}|<>\"'"):
        s = s.replace('"', "'")
        return '"%s"' % s
    return s


def _node_def_mm(n):
    shape = n.get("shape", "rect")
    op = MM_OPEN.get(shape, "[")
    cl = MM_CLOSE.get(shape, "]")
    return "%s%s%s%s" % (n["id"], op, _mm_label(n.get("label", n["id"])), cl)


def _edge_mm(e):
    arr = MM_EDGE.get(e.get("kind", "->"), "-->")
    if e.get("label"):
        return "%s %s|%s| %s" % (e["from"], arr, e["label"], e["to"])
    return "%s %s %s" % (e["from"], arr, e["to"])


# ---------------- mermaid ----------------
def gen_mermaid(ir):
    t = ir.get("type", "flowchart")
    L = []
    if t in ("sequence",):
        L.append("sequenceDiagram")
        for n in ir.get("nodes", []):
            L.append("  participant %s as %s" % (n["id"], _mm_label(n.get("label", n["id"]))))
        for e in sorted(ir.get("edges", []), key=lambda x: x.get("order", 0)):
            lab = (": " + e["label"]) if e.get("label") else ""
            L.append("  %s->>%s%s" % (e["from"], e["to"], lab))
        return "\n".join(L)
    if t == "class":
        L.append("classDiagram")
        for n in ir.get("nodes", []):
            L.append("  class %s {" % n["id"])
            for fld in n.get("fields", []):
                L.append("    %s" % fld)
            L.append("  }")
        for e in ir.get("edges", []):
            L.append("  %s --> %s" % (e["from"], e["to"]))
        return "\n".join(L)
    if t == "state":
        L.append("stateDiagram-v2")
        for e in ir.get("edges", []):
            lab = (": " + e["label"]) if e.get("label") else ""
            L.append("  %s --> %s%s" % (e["from"], e["to"], lab))
        return "\n".join(L)
    if t == "er":
        L.append("erDiagram")
        for e in ir.get("edges", []):
            card = e.get("cardinality", "||--o{")
            L.append("  %s %s %s : %s" % (e["from"], card, e["to"], e.get("label", "rel")))
        for n in ir.get("nodes", []):
            if n.get("fields"):
                L.append("  %s {" % n["id"])
                for fld in n["fields"]:
                    L.append("    %s" % fld)
                L.append("  }")
        return "\n".join(L)
    # architecture / flowchart
    L.append("graph %s" % ir.get("direction", "TB").upper())
    for n in ir.get("nodes", []):
        L.append("  " + _node_def_mm(n))
    for g in ir.get("groups", []):
        L.append("  subgraph %s[%s]" % (g["id"], _mm_label(g.get("label", g["id"]))))
        for m in g.get("members", []):
            L.append("    %s" % m)
        L.append("  end")
    for e in ir.get("edges", []):
        L.append("  " + _edge_mm(e))
    return "\n".join(L)


# ---------------- PlantUML ----------------
def gen_puml(ir):
    t = ir.get("type", "flowchart")
    L = ["@startuml"]
    if t == "sequence":
        for n in ir.get("nodes", []):
            L.append("actor %s as %s" % (n["id"], n.get("label", n["id"])))
        for e in sorted(ir.get("edges", []), key=lambda x: x.get("order", 0)):
            lab = (" : " + e["label"]) if e.get("label") else ""
            L.append("%s -> %s%s" % (e["from"], e["to"], lab))
    elif t == "class":
        for n in ir.get("nodes", []):
            L.append("class %s {" % n["id"])
            for fld in n.get("fields", []):
                L.append("  %s" % fld)
            L.append("}")
        for e in ir.get("edges", []):
            L.append("%s --> %s" % (e["from"], e["to"]))
    elif t == "state":
        for e in ir.get("edges", []):
            lab = (" : " + e["label"]) if e.get("label") else ""
            L.append("%s --> %s%s" % (e["from"], e["to"], lab))
    elif t == "er":
        for n in ir.get("nodes", []):
            L.append("class %s {" % n["id"])
            for fld in n.get("fields", []):
                L.append("  %s" % fld)
            L.append("}")
        for e in ir.get("edges", []):
            L.append("%s --> %s" % (e["from"], e["to"]))
    else:  # architecture / flowchart
        for n in ir.get("nodes", []):
            shp = PUML_SHAPE.get(n.get("shape", "rect"), "rectangle")
            L.append('%s "%s" as %s' % (shp, n.get("label", n["id"]), n["id"]))
        for e in ir.get("edges", []):
            lab = (" : " + e["label"]) if e.get("label") else ""
            L.append("%s --> %s%s" % (e["from"], e["to"], lab))
    L.append("@enduml")
    return "\n".join(L)


# ---------------- Graphviz DOT ----------------
def gen_dot(ir):
    t = ir.get("type", "flowchart")
    L = ["digraph G {", "  rankdir=%s;" % ir.get("direction", "TB").upper()]
    for n in ir.get("nodes", []):
        shp = "cylinder" if n.get("shape") == "cylinder" else (
            "diamond" if n.get("shape") == "diamond" else "box")
        L.append('  %s [label="%s", shape=%s];' % (
            n["id"], str(n.get("label", n["id"])).replace('"', "'"), shp))
    for e in ir.get("edges", []):
        lab = (' [label="%s"]' % e["label"].replace('"', "'")) if e.get("label") else ""
        L.append("  %s -> %s%s;" % (e["from"], e["to"], lab))
    L.append("}")
    return "\n".join(L)


GEN = {"mermaid": gen_mermaid, "puml": gen_puml, "dot": gen_dot}
EXT = {"mermaid": "mmd", "puml": "puml", "dot": "dot"}


# ---------------- 语法校验 ----------------
def validate_mermaid(text):
    issues = []
    lines = text.splitlines()
    head = next((l for l in lines if l.strip()), "")
    h = head.strip().lower()
    valid_headers = ("graph", "flowchart", "sequencediagram", "classdiagram",
                     "statediagram", "erdiagram")
    if not any(h.startswith(v) for v in valid_headers):
        issues.append("缺少合法图头（应为 graph/flowchart/sequenceDiagram/classDiagram/stateDiagram/erDiagram）")
    # 括号配平（节点定义区）
    # 跳过边/关系行：ER 的 ||--o{ 、流程的 --> 、时序的 ->> 含合法花括号，不能计入
    depth = 0
    for ln in lines:
        s = ln.strip()
        if s.startswith(("subgraph", "end", "class", "participant")):
            continue
        if "--" in s or "||" in s or "->>" in s or s.startswith("end"):
            continue
        for ch in s:
            if ch in "([{":
                depth += 1
            elif ch in ")]}":
                depth -= 1
        if depth < 0:
            issues.append("括号不匹配（右括号多于左括号）：%s" % s)
            depth = 0
    if depth != 0:
        issues.append("括号未配平：疑似节点定义缺闭合符号")
    # subgraph 开合
    sub = sum(1 for l in lines if l.strip().lower().startswith("subgraph"))
    end = sum(1 for l in lines if l.strip().lower() == "end")
    if sub != end:
        issues.append("subgraph(%d) 与 end(%d) 数量不一致" % (sub, end))
    # 节点引用检查（边引用的 id 是否声明）
    declared = set(re.findall(r"^\s*([A-Za-z0-9_]+)\s*[\[(\{]", text, re.M))
    declared |= set(re.findall(r"participant\s+([A-Za-z0-9_]+)", text))
    declared |= set(re.findall(r"class\s+([A-Za-z0-9_]+)", text))
    for m in re.finditer(r"^\s*([A-Za-z0-9_]+)\s*(?:-->|-.->|==>|->>|--)\s*(?:\|[^|]*\|\s*)?([A-Za-z0-9_]+)", text, re.M):
        for ref in (m.group(1), m.group(2)):
            if ref not in declared and ref not in ("[*]",):
                issues.append("边引用了未声明的节点：%s" % ref)
                break
    return issues


def validate_puml(text):
    issues = []
    if "@startuml" not in text:
        issues.append("缺少 @startuml")
    if "@enduml" not in text:
        issues.append("缺少 @enduml")
    if text.count("{") != text.count("}"):
        issues.append("PlantUML 类体大括号未配平")
    return issues


def validate_dot(text):
    issues = []
    if text.count("{") != text.count("}"):
        issues.append("DOT 大括号未配平")
    if not text.strip().startswith("digraph") and not text.strip().startswith("graph"):
        issues.append("DOT 缺少 digraph/graph 声明")
    return issues


VALIDATORS = {"mermaid": validate_mermaid, "puml": validate_puml, "dot": validate_dot}


def main():
    ap = argparse.ArgumentParser(description="ir.json → 多图型源文件 + 语法校验")
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--type", default="auto",
                    choices=["auto", "architecture", "flowchart", "sequence",
                             "class", "state", "er"])
    ap.add_argument("--format", default="all", choices=["all", "mermaid", "puml", "dot"])
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--name", default=None, help="输出文件名前缀（默认用 ir.title）")
    ap.add_argument("--dir", default=None, choices=["TB", "LR", "BT", "RL"],
                    help="图方向（默认 TB；--playbook 时套用历史最爱方向）")
    ap.add_argument("--playbook", default=None,
                    help="设计偏好复用：传入 diagram_playbook.json 路径即开启（未指定 --format 时套用历史最爱格式、未指定 --dir 时套用历史方向、并自动沉淀本次生成）")
    args = ap.parse_args()

    with open(args.inp, encoding="utf-8") as f:
        ir = json.load(f)
    ir_type = args.type
    if ir_type == "auto":
        ir_type = ir.get("type", "flowchart")
    ir["type"] = ir_type

    # 方向：显式 --dir > --playbook 历史方向 > IR 自带 > 默认 TB
    if args.dir:
        ir["direction"] = args.dir
    elif args.playbook and os.path.exists(args.playbook):
        try:
            import diagram_retro as dr
            sug = dr.suggest(dr.load_playbook(args.playbook))
            ir.setdefault("direction", sug["default_direction"])
            if not ir.get("direction"):
                ir["direction"] = sug["default_direction"]
        except Exception:
            ir.setdefault("direction", "TB")
    else:
        ir.setdefault("direction", "TB")

    # 格式：--playbook 且未显式指定单格式时，套用历史最爱格式（减少重复产出）
    fmts = ["mermaid", "puml", "dot"] if args.format == "all" else [args.format]
    if args.playbook and args.format == "all" and os.path.exists(args.playbook):
        try:
            import diagram_retro as dr
            sug = dr.suggest(dr.load_playbook(args.playbook))
            fmts = [sug["default_format"]]
            print("🎯 已按你的历史偏好套用格式：%s" % sug["default_format"])
        except Exception:
            pass
    prefix = args.name or re.sub(r"[^\w一-龥]+", "_", ir.get("title", "diagram"))[:40]
    os.makedirs(args.out, exist_ok=True)
    report = []
    for fmt in fmts:
        gen = GEN.get(fmt)
        src = gen(ir) if gen else None
        if src is None:
            report.append((fmt, None, ["该图型不支持 %s 格式" % fmt]))
            continue
        fname = os.path.join(args.out, "%s.%s" % (prefix, EXT[fmt]))
        with open(fname, "w", encoding="utf-8") as f:
            f.write(src + "\n")
        issues = VALIDATORS[fmt](src)
        report.append((fmt, fname, issues))
        status = "✅ 通过" if not issues else "⚠️ %d 处待查" % len(issues)
        print("%s [%s] %s → %s" % (fmt, ir_type, status, fname))
        for it in issues:
            print("    - %s" % it)
    # 校验报告 json
    rep = {"type": ir_type, "files": [{"format": r[0], "path": r[1],
            "issues": r[2]} for r in report]}
    with open(os.path.join(args.out, prefix + ".validate.json"), "w", encoding="utf-8") as f:
        json.dump(rep, f, ensure_ascii=False, indent=2)
    total_issues = sum(len(r[2] or []) for r in report)
    print("\n📋 校验汇总：%d 格式 / %d 处问题" % (len(report), total_issues))

    # ---- 偏好沉淀（--playbook）----
    if args.playbook:
        meta = {
            "title": ir.get("title", ""),
            "type": ir_type,
            "format": fmts[0] if len(fmts) == 1 else "all",
            "direction": ir.get("direction", "TB"),
            "grouped": bool(ir.get("groups")),
            "validation_passed": total_issues == 0,
            "issues_count": total_issues,
            "node_count": len(ir.get("nodes", [])),
            "edge_count": len(ir.get("edges", [])),
        }
        with open(os.path.join(args.out, prefix + ".meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
        try:
            import diagram_retro as dr
            pb_path = dr.record_build(args.out, meta, args.playbook)
            print("🧠 已沉淀本次生成到验证库 → %s（下次 --playbook 越画越贴合你）" % pb_path)
        except Exception as e:
            print("⚠️ 偏好沉淀跳过：%s" % e)
        # 架构图无分组、但历史常分组 → 提示
        if ir_type in ("architecture",) and not ir.get("groups") and os.path.exists(args.playbook):
            try:
                import diagram_retro as dr
                sug = dr.suggest(dr.load_playbook(args.playbook))
                if sug.get("default_grouped"):
                    print("💡 历史显示你常给架构图加分组；可在 ir.json 的 groups 里按层/域归类，可读性更高")
            except Exception:
                pass


if __name__ == "__main__":
    main()
