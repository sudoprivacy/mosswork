#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阿拉丁·架构图工坊 — 多源输入归一器。

把多种输入收口成统一中间表示 ir.json：
  - code   : 扫描代码目录，抽模块依赖 → 架构图 IR
  - mermaid: 解析 .mmd → IR（best-effort，支持 graph/flowchart/sequence/class/state/er）
  - puml   : 解析 PlantUML → IR（best-effort）
  - dot    : 解析 Graphviz DOT → IR（best-effort）
  - text   : 文本流程描述 → 流程图 IR
  - json   : 直接透传已存在的 ir.json（做基础校验）

纯标准库，零依赖。
"""
import argparse
import json
import os
import re
import sys

EXT_LANG = {
    ".py": "python", ".js": "javascript", ".ts": "typescript",
    ".tsx": "typescript", ".jsx": "javascript", ".java": "java", ".go": "go",
}
# 导入语句正则（按语言）
IMPORT_PATTERNS = {
    "python": [
        re.compile(r"^\s*import\s+([\w\.]+)"),
        re.compile(r"^\s*from\s+([\w\.]+)\s+import"),
    ],
    "javascript": [
        re.compile(r"^\s*import\s+.*?\s+from\s+['\"]([^'\"]+)['\"]"),
        re.compile(r"^\s*require\s*\(\s*['\"]([^'\"]+)['\"]\s*\)"),
    ],
    "typescript": [
        re.compile(r"^\s*import\s+.*?\s+from\s+['\"]([^'\"]+)['\"]"),
        re.compile(r"^\s*import\s+['\"]([^'\"]+)['\"]"),
        re.compile(r"^\s*require\s*\(\s*['\"]([^'\"]+)['\"]\s*\)"),
    ],
    "java": [
        re.compile(r"^\s*import\s+([\w\.]+)\s*;"),
    ],
    "go": [
        re.compile(r"^\s*import\s+['\"]([^'\"]+)['\"]"),
        re.compile(r"^\s*import\s+\(\s*([\s\S]*?)\s*\)"),
    ],
}
# 忽略的内部/第三方依赖前缀（只画项目内部模块关系）
IGNORE_PREFIXES = ("__", ".", "/", "http", "node_modules", "vendor")
THIRD_PARTY_MARKERS = ("react", "vue", "express", "flask", "django", "spring",
                       "numpy", "pandas", "os", "sys", "json", "time", "logging",
                       "fmt", "net/http", "github.com", "golang.org", "@types")


def _norm_module(path, root):
    """把文件路径规范成模块 id（相对 root 的目录/文件名）。"""
    rel = os.path.relpath(path, root)
    rel = rel.replace("\\", "/")
    stem = os.path.splitext(rel)[0]
    return stem


def scan_code(path, ignore_dirs=None):
    ignore_dirs = set(ignore_dirs or ["node_modules", "venv", ".venv",
                                       "__pycache__", ".git", "dist", "build",
                                       "vendor", "target"])
    nodes = {}
    file_deps = {}  # mod -> set(raw import strings)
    root = os.path.abspath(path)
    # 第一遍：收集所有模块节点 + 每个文件的原始依赖
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        for fn in files:
            ext = os.path.splitext(fn)[1].lower()
            if ext not in EXT_LANG:
                continue
            fpath = os.path.join(base, fn)
            mod = _norm_module(fpath, root)
            if mod not in nodes:
                nodes[mod] = {"id": mod, "label": mod.split("/")[-1], "shape": "rect"}
            lang = EXT_LANG[ext]
            try:
                with open(fpath, encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
            except Exception:
                continue
            deps = set()
            if lang == "go":
                text = "".join(lines)
                for pat in IMPORT_PATTERNS["go"]:
                    for m in pat.finditer(text):
                        deps.add(m.group(1).strip())
            else:
                for line in lines:
                    for pat in IMPORT_PATTERNS[lang]:
                        m = pat.match(line)
                        if m:
                            deps.add(m.group(1).strip())
            file_deps[mod] = deps
    # 第二遍：所有模块已知后，再解析依赖边（避免增量解析漏边）
    edges = []
    for mod, deps in file_deps.items():
        for dep in deps:
            if dep.startswith(IGNORE_PREFIXES):
                continue
            target = _resolve_dep(dep, nodes, root)
            if target and target != mod:
                edges.append({"from": mod, "to": target, "label": "依赖", "kind": "->"})
    # 去重边
    seen = set()
    uniq = []
    for e in edges:
        key = (e["from"], e["to"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(e)
    return {
        "title": os.path.basename(root) + " · 模块依赖架构图",
        "type": "architecture",
        "nodes": list(nodes.values()),
        "edges": uniq,
        "groups": [],
    }


def _resolve_dep(dep, nodes, root):
    """把 import 路径解析为项目内已知模块 id（best-effort）。"""
    dep = dep.replace("\\", "/")
    # 直接命中
    if dep in nodes:
        return dep
    # 末段命中
    last = dep.split("/")[-1]
    for nid in nodes:
        if nid.split("/")[-1] == last:
            return nid
    # 前缀命中（a.b.c → a/b）
    cand = dep.replace(".", "/")
    if cand in nodes:
        return cand
    for nid in nodes:
        if nid.endswith("/" + cand) or nid == cand:
            return nid
    return None


def parse_mermaid(text):
    """best-effort 解析 mermaid 文本 → IR。"""
    lines = [l.rstrip() for l in text.splitlines()]
    header = next((l for l in lines if l.strip() and not l.strip().startswith("%%")), "")
    h = header.strip().lower()
    ir = {"title": "从 mermaid 导入", "nodes": [], "edges": [], "groups": []}
    if h.startswith("sequencediagram"):
        ir["type"] = "sequence"
        return _parse_mermaid_sequence(lines, ir)
    if h.startswith("classdiagram"):
        ir["type"] = "class"
        return _parse_generic(lines, ir, "class")
    if h.startswith("statediagram"):
        ir["type"] = "state"
        return _parse_generic(lines, ir, "state")
    if h.startswith("erdiagram"):
        ir["type"] = "er"
        return _parse_generic(lines, ir, "er")
    # 默认 flowchart / graph
    ir["type"] = "flowchart"
    return _parse_mermaid_flow(lines, ir)


def _parse_mermaid_flow(lines, ir):
    node_re = re.compile(r"^\s*([A-Za-z0-9_]+)(\[[^\]]*\]|\([^)]*\)|\{[^}]*\}|\($[^$]*$\)|\[[^\]]*\])")
    edge_re = re.compile(r"^\s*([A-Za-z0-9_]+)\s*(--?>|---|\.->|==>)\s*(.+)$")
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("%%") or s.startswith("subgraph") or s.startswith("end") or s.startswith("direction"):
            # 子图分组
            m = re.match(r"subgraph\s+([A-Za-z0-9_]+)\[?([^\]]*)\]?", s)
            if m:
                ir["groups"].append({"id": m.group(1), "label": m.group(2) or m.group(1), "members": []})
            continue
        me = edge_re.match(s)
        if me:
            src = me.group(1)
            rest = me.group(3)
            # 拆分目标 + 标签
            label = ""
            mm = re.match(r"\|([^|]*)\|\s*([A-Za-z0-9_]+)", rest)
            if mm:
                label, tgt = mm.group(1), mm.group(2)
            else:
                tgt = rest.strip().split()[0].strip("[](){}")
            for nid in (src, tgt):
                if nid and not any(n["id"] == nid for n in ir["nodes"]):
                    ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
            if src and tgt:
                ir["edges"].append({"from": src, "to": tgt, "label": label, "kind": "->"})
            continue
        mn = node_re.match(s)
        if mn:
            nid = mn.group(1)
            if not any(n["id"] == nid for n in ir["nodes"]):
                ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
    return ir


def _parse_mermaid_sequence(lines, ir):
    parts = []
    for ln in lines:
        s = ln.strip()
        if not s or s.lower().startswith("sequencediagram") or s.startswith("%%"):
            continue
        if s.lower().startswith("participant"):
            nm = re.sub(r"participant\s+", "", s).split("as")[0].strip()
            ir["nodes"].append({"id": nm, "label": nm, "shape": "actor"})
            continue
        m = re.match(r"([^->]+)(->>+)(.+)", s)
        if m:
            src = m.group(1).strip()
            tgt = m.group(3).strip()
            for nid in (src, tgt):
                if nid and not any(n["id"] == nid for n in ir["nodes"]):
                    ir["nodes"].append({"id": nid, "label": nid, "shape": "actor"})
            ir["edges"].append({"from": src, "to": tgt, "label": "", "kind": "->", "order": len(ir["edges"])})
    return ir


def _parse_generic(lines, ir, kind):
    for ln in lines:
        s = ln.strip()
        if not s or s.startswith("%") or s.lower().startswith(kind + "diagram"):
            continue
        m = re.match(r"([A-Za-z0-9_]+)\s*(\{|\[|\()", s)
        if m:
            nid = m.group(1)
            if not any(n["id"] == nid for n in ir["nodes"]):
                ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
        em = re.match(r"([A-Za-z0-9_]+)\s*(--|>|<|\.\.|\|>|\*--)\s*([A-Za-z0-9_]+)", s)
        if em:
            a, b = em.group(1), em.group(3)
            for nid in (a, b):
                if nid and not any(n["id"] == nid for n in ir["nodes"]):
                    ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
            ir["edges"].append({"from": a, "to": b, "label": "", "kind": "->"})
    return ir


def parse_puml(text):
    ir = {"title": "从 PlantUML 导入", "type": "flowchart",
          "nodes": [], "edges": [], "groups": []}
    for ln in text.splitlines():
        s = ln.strip()
        if not s or s.startswith("@") or s.startswith("!") or s.startswith("'"):
            continue
        m = re.match(r"(class|interface|rectangle|component|node|database|actor|usecase)\s+(\w+)", s)
        if m:
            nid = m.group(2)
            if not any(n["id"] == nid for n in ir["nodes"]):
                ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
        em = re.match(r"(\w+)\s*(--|>|\.\.|\|->|\-left\->|\-up\->)\s*(\w+)", s)
        if em:
            a, b = em.group(1), em.group(3)
            for nid in (a, b):
                if nid and not any(n["id"] == nid for n in ir["nodes"]):
                    ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
            ir["edges"].append({"from": a, "to": b, "label": "", "kind": "->"})
    return ir


def parse_dot(text):
    ir = {"title": "从 DOT 导入", "type": "flowchart",
          "nodes": [], "edges": [], "groups": []}
    for ln in text.splitlines():
        s = ln.strip()
        m = re.match(r"(\w+)\s*->\s*(\w+)", s)
        if m:
            a, b = m.group(1), m.group(2)
            for nid in (a, b):
                if nid and not any(n["id"] == nid for n in ir["nodes"]):
                    ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
            ir["edges"].append({"from": a, "to": b, "label": "", "kind": "->"})
    return ir


def parse_text(text):
    """文本流程描述 → 流程图 IR（每行一步，含 → 的解析为边）。"""
    ir = {"title": "从文本流程导入", "type": "flowchart",
          "nodes": [], "edges": [], "groups": []}
    steps = []
    for raw in text.splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        s = re.sub(r"^\d+[.、]\s*", "", s)
        steps.append(s)
    # 检测 → 边
    edge_found = False
    for s in steps:
        if "→" in s or "->" in s:
            edge_found = True
            parts = re.split(r"→|->", s)
            a = parts[0].strip()
            b = parts[-1].strip()
            for nid in (a, b):
                if nid and not any(n["id"] == nid for n in ir["nodes"]):
                    ir["nodes"].append({"id": nid, "label": nid, "shape": "rect"})
            ir["edges"].append({"from": a, "to": b, "label": "", "kind": "->"})
    if not edge_found:
        # 顺序串联
        prev = None
        for s in steps:
            nid = "step%d" % (len(ir["nodes"]) + 1)
            ir["nodes"].append({"id": nid, "label": s, "shape": "rect"})
            if prev:
                ir["edges"].append({"from": prev, "to": nid, "label": "", "kind": "->"})
            prev = nid
    return ir


def main():
    ap = argparse.ArgumentParser(description="多源输入归一为 ir.json")
    sub = ap.add_subparsers(dest="cmd", required=True)

    pc = sub.add_parser("code")
    pc.add_argument("--path", required=True)
    pc.add_argument("--out", required=True)

    pm = sub.add_parser("mermaid")
    pm.add_argument("--in", dest="inp", required=True)
    pm.add_argument("--out", required=True)

    pp = sub.add_parser("puml")
    pp.add_argument("--in", dest="inp", required=True)
    pp.add_argument("--out", required=True)

    pd_ = sub.add_parser("dot")
    pd_.add_argument("--in", dest="inp", required=True)
    pd_.add_argument("--out", required=True)

    pt = sub.add_parser("text")
    pt.add_argument("--in", dest="inp", required=True)
    pt.add_argument("--out", required=True)

    pj = sub.add_parser("json")
    pj.add_argument("--in", dest="inp", required=True)
    pj.add_argument("--out", required=True)

    args = ap.parse_args()
    if args.cmd == "code":
        ir = scan_code(args.path)
    else:
        with open(args.inp, encoding="utf-8", errors="ignore") as f:
            txt = f.read()
        if args.cmd == "mermaid":
            ir = parse_mermaid(txt)
        elif args.cmd == "puml":
            ir = parse_puml(txt)
        elif args.cmd == "dot":
            ir = parse_dot(txt)
        elif args.cmd == "text":
            ir = parse_text(txt)
        elif args.cmd == "json":
            ir = json.loads(txt)
            assert "nodes" in ir or "type" in ir, "ir.json 缺少 nodes/type"
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(ir, f, ensure_ascii=False, indent=2)
    print("✅ 归一完成：%d 节点 / %d 边 / %d 分组 → %s" %
          (len(ir.get("nodes", [])), len(ir.get("edges", [])),
           len(ir.get("groups", [])), args.out))


if __name__ == "__main__":
    main()
