#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阿拉丁·架构图工坊 — 汇总报告生成器。

把生成的图源文件汇总为：
  - diagrams.html : 自包含预览（mermaid 经 CDN 实时渲染，PlantUML/DOT 附源码）
  - diagrams.md   : 图清单 + 嵌入代码块，可直接贴 README
纯标准库，零依赖。
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def playbook_note(pb_path, ir_type):
    """基于本地验证库，给本次汇总报告附一段『画图建议』（纯文本）。"""
    if not pb_path or not os.path.exists(pb_path):
        return ""
    try:
        import diagram_retro as dr
        pb = dr.load_playbook(pb_path)
        recs = pb.get("records", [])
        if not recs:
            return ""
        # 当前图型下各格式通过率
        from collections import defaultdict
        stat = defaultdict(lambda: {"n": 0, "ok": 0, "iss": 0})
        for r in recs:
            if r.get("type") != ir_type:
                continue
            f = r.get("format")
            if not f or f == "all":
                continue
            stat[f]["n"] += 1
            if r.get("validation_passed"):
                stat[f]["ok"] += 1
            stat[f]["iss"] += r.get("issues_count", 0)
        if not stat:
            return ""
        lines = ["基于你历史验证的画图建议（数据来自本地 diagram_playbook.json）："]
        for f, d in sorted(stat.items(), key=lambda x: -(x[1]["ok"] / x[1]["n"])):
            rate = d["ok"] / d["n"] if d["n"] else 0
            avg = d["iss"] / d["n"] if d["n"] else 0
            lines.append("- %s 格式：同类 %d 次，通过率 %.0f%%，平均 %.1f 处语法问题"
                         % (f, d["n"], rate * 100, avg))
        best = dr.benchmark(pb, ir_type, stat.most_common(1)[0][0]) if stat else None
        # 找通过率最高的格式
        top_fmt = max(stat.items(), key=lambda x: (x[1]["ok"] / x[1]["n"], -x[1]["iss"] / x[1]["n"]))[0]
        lines.append("- 同图型最稳格式：%s，下次可优先用" % top_fmt)
        return "\n".join(lines)
    except Exception:
        return ""


def build_html(ir, files, note=""):
    title = ir.get("title", "架构图预览")
    blocks = []
    for fmt, path in files:
        with open(path, encoding="utf-8") as f:
            content = f.read()
        if fmt == "mermaid":
            blocks.append(
                '<section class="card"><h3>mermaid · %s</h3>'
                '<div class="mermaid">%s</div></section>' % (_esc(path), _esc(content)))
        else:
            note2 = ("PlantUML：可贴 https://www.plantuml.com/plantuml/ 或本地 plantuml.jar 渲染"
                     if fmt == "puml" else
                     "DOT：用 graphviz `dot -Tsvg xxx.dot -o xxx.svg` 渲染")
            blocks.append(
                '<section class="card"><h3>%s · %s</h3>'
                '<p class="note">%s</p>'
                '<pre><code>%s</code></pre></section>' % (fmt, _esc(path), note2, _esc(content)))
    if note:
        blocks.append(
            '<section class="card"><h3>🧠 基于你历史验证的画图建议</h3>'
            '<pre><code>%s</code></pre></section>' % _esc(note))
    html = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title>
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true, theme:"default"});</script>
<style>
  body{font-family:-apple-system,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;
       margin:0;background:#f5f6f8;color:#1f2329}
  header{background:#2b6cff;color:#fff;padding:18px 24px}
  header h1{margin:0;font-size:20px}
  main{max-width:960px;margin:0 auto;padding:20px}
  .card{background:#fff;border-radius:10px;padding:16px 18px;margin-bottom:18px;
         box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .card h3{margin:0 0 12px;font-size:15px;color:#2b6cff}
  .note{color:#888;font-size:12px;margin:0 0 8px}
  pre{background:#0f172a;color:#e2e8f0;padding:14px;border-radius:8px;overflow:auto;font-size:13px}
  code{font-family:"JetBrains Mono",Consolas,monospace}
</style></head>
<body><header><h1>%s</h1><p>阿拉丁·架构图工坊 · 本地生成预览</p></header>
<main>%s</main></body></html>""" % (_esc(title), _esc(title), "\n".join(blocks))
    return html


def build_md(ir, files, note=""):
    lines = ["# %s" % ir.get("title", "架构图"), "",
             "> 由阿拉丁·架构图工坊（aladin-diagram-forge）生成。", ""]
    for fmt, path in files:
        with open(path, encoding="utf-8") as f:
            content = f.read()
        lines.append("## %s" % os.path.basename(path))
        lines.append("```%s" % ("mermaid" if fmt == "mermaid" else fmt))
        lines.append(content.rstrip())
        lines.append("```")
        lines.append("")
    if note:
        lines.append("## 🧠 基于你历史验证的画图建议")
        lines.append("")
        lines.append("```")
        lines.append(note)
        lines.append("```")
        lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="汇总图源为 HTML/MD 预览")
    ap.add_argument("--in", dest="inp", required=True, help="ir.json")
    ap.add_argument("--dir", required=True, help="图源文件所在目录")
    ap.add_argument("--html", default=None)
    ap.add_argument("--md", default=None)
    ap.add_argument("--playbook", default=None,
                    help="附「基于你历史验证的画图建议」（传入 diagram_playbook.json 路径）")
    args = ap.parse_args()

    with open(args.inp, encoding="utf-8") as f:
        ir = json.load(f)
    # 收集目录里的图源文件
    order = {"mmd": 0, "puml": 1, "dot": 2}
    files = []
    for fn in sorted(os.listdir(args.dir)):
        ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
        if ext in order and fn != "diagrams.html":
            files.append((ext, os.path.join(args.dir, fn)))
    files.sort(key=lambda x: order.get(x[0], 9))

    note = playbook_note(args.playbook, ir.get("type", "flowchart")) if args.playbook else ""

    if args.html:
        html = build_html(ir, files, note)
        with open(args.html, "w", encoding="utf-8") as f:
            f.write(html)
        print("✅ HTML 预览 → %s" % args.html)
    if args.md:
        md = build_md(ir, files, note)
        with open(args.md, "w", encoding="utf-8") as f:
            f.write(md)
        print("✅ MD 清单 → %s" % args.md)
    if not args.html and not args.md:
        print("⚠️ 至少指定 --html 或 --md")


if __name__ == "__main__":
    main()
