# 设计偏好复用闭环 · 操作手册

> 本手册说明 `aladin-diagram-forge` 的「设计偏好复用闭环」（第 4 步）：让画图工具记住你的习惯，越用越贴合、越画越稳。
> 配套脚本：`scripts/diagram_retro.py`（add / summary / suggest / benchmark / seed）。

## 为什么需要这个闭环

前 3 步（归一 → 生成 → 汇总）解决「把图画出来」。但开发者画图是**高频重复动作**——反复选格式、反复定方向、反复踩同样的语法坑。如果没有沉淀，每次都要重新决策、重新试错。

闭环把每次生成结果（图型 / 格式 / 方向 / 分组 / 语法校验结果）写进一个纯本地验证库 `diagram_playbook.json`，下次生成时自动复用你的历史最优选择，并提前预警你常踩的坑。形成：

```
生成 → 沉淀 → 复用 → 越画越贴合习惯、越画越稳
```

与自家 `aladin` / `omni` 家族「验证库反哺」范式一致（topic/roi/bgm/shoot/script/secure/bid/cicd/material/skill-manager/excel/clip/traffic/engage 同源）。

## 验证库长什么样

`diagram_playbook.json`（纯本地、零联网）：

```json
{
  "version": 1,
  "records": [
    {"title":"订单服务架构","type":"architecture","format":"mermaid","direction":"TB",
     "grouped":true,"validation_passed":true,"issues_count":0,"node_count":6,"edge_count":5},
    {"title":"登录流程","type":"flowchart","format":"mermaid","direction":"TB",
     "grouped":false,"validation_passed":true,"issues_count":0,"node_count":5,"edge_count":4}
  ]
}
```

只记统计性偏好，**不含任何图的业务内容**，可放心提交进版控。

## 子命令速查

### seed — 写入示例，上手即见
```bash
"$PY" $SK/scripts/diagram_retro.py seed --playbook diagram_playbook.json
```

### add — 沉淀一次生成
```bash
# 方式一：直接读 build 产出的 <prefix>.meta.json
"$PY" $SK/scripts/diagram_retro.py add --playbook diagram_playbook.json --json ./out/订单服务架构.meta.json

# 方式二：显式传参
"$PY" $SK/scripts/diagram_retro.py add --playbook diagram_playbook.json \
  --title "登录流程" --type flowchart --format mermaid --validation_passed --node_count 5 --edge_count 4
```
> 其实你不用手动 add：`diagram_build.py --playbook` 生成完会自动把本次结果写进验证库。

### summary — 看你的画图画像
```bash
"$PY" $SK/scripts/diagram_retro.py summary --playbook diagram_playbook.json
```
输出：最常用图型、各格式使用频次、默认方向、常分组与否，以及**各格式的通过率与健康度**（平均几处语法问题）。

### suggest — 给出下次默认偏好
```bash
"$PY" $SK/scripts/diagram_retro.py suggest --playbook diagram_playbook.json
```
输出：默认格式 / 默认方向 / 默认分组 / 常画图型——这正是 `diagram_build.py --playbook` 自动套用的依据。

### benchmark — 画某类图前先评估易踩坑
```bash
"$PY" $SK/scripts/diagram_retro.py benchmark --type architecture --format mermaid --playbook diagram_playbook.json
```
输出：该组合历史样本数、通过率、平均问题数，并**推荐最稳格式** + 避坑建议（如「复杂图优先用 dot 避免 subgraph/end 配对翻车」）。

## 自动复用（推荐用法）

```bash
# 生成时自动套用你最爱格式/方向，并记录本次生成
"$PY" $SK/scripts/diagram_build.py --in ir.json --playbook diagram_playbook.json --out ./out

# 汇总报告附「基于你历史验证的画图建议」
"$PY" $SK/scripts/diagram_report.py --in ir.json --dir ./out \
  --html diagrams.html --md diagrams.md --playbook diagram_playbook.json
```

`--playbook` 的行为：
- 未显式 `--format` → 套用历史最爱格式（少产重复文件）；
- 未显式 `--dir` → 套用历史最爱方向；
- 架构图无分组、但历史上你常分组 → 提示加 groups 提升可读性；
- 生成完自动把本次结果写进验证库。

## 反哺效果

- **少决策**：格式/方向不用每次想，工具替你记；
- **避坑**：报告提前告诉你哪类图、哪种格式历史上最容易校验不过，换格式或留意括号；
- **粘性**：越用画像越准，迁移成本变高、复访率上升——这正是闭环提升转化的核心。

## 隐私与安全

- 验证库纯本地、零联网、数据不出本机；
- 只含统计性偏好，不含业务结构；
- 想重来：`rm diagram_playbook.json` 即可，不影响任何已生成的图。
