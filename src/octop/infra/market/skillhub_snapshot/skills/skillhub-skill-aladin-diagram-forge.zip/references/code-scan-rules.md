# 代码 → 架构图 抽取规则

`diagram_ingest.py code --path <dir>` 把代码目录扫描成模块依赖架构图。

## 支持的语种与抽取方式

| 扩展名 | 语言 | 依赖识别 |
|--------|------|----------|
| `.py` | Python | `import x` / `from x import` |
| `.js` / `.jsx` | JavaScript | `import ... from 'x'` / `require('x')` |
| `.ts` / `.tsx` | TypeScript | `import ... from 'x'` / `require('x')` |
| `.java` | Java | `import x;` |
| `.go` | Go | `import "x"` / `import (...)` |

## 模块如何定义

- 每个源码文件 = 一个模块，id 为「相对扫描根目录的路径（去扩展名）」。
  - 例：`src/order/service.py` → 模块 id `src/order/service`
- 同目录文件互引时，边会落在 `[目录]/[文件]` 粒度，清晰反映包内结构。

## 边如何定义

- 一条 `import/require` 命中项目内某已知模块 → 生成一条 `from(当前模块) --> to(目标模块)` 依赖边。
- 自动**去重**相同 `(from,to)` 边。

## 默认忽略（不出图）

- 目录：`node_modules` `venv` `.venv` `__pycache__` `.git` `dist` `build` `vendor` `target`
- 第三方/标准库依赖（不画进架构图，避免噪音）：`react` `vue` `express` `flask` `django`
  `spring` `numpy` `pandas` `os` `sys` `json` `time` `fmt` `net/http` `github.com` `golang.org` 等

## 调优建议

- 大仓先 `cd` 到子模块目录再扫，图更聚焦。
- 扫描后 `git diff` / 人工核对，剔除 vendored 或自动生成的目录。
- 想强调「服务层」可用 Hy3 把扫描结果补 `groups` 字段后再渲染。

## 已知边界

- 仅**静态 import 级**依赖，不含运行时动态加载、反射、字符串拼装的调用。
- 跨语言的「HTTP/gRPC 调用」不在此列（需要运行态或约定注释），属架构师补充范畴。
