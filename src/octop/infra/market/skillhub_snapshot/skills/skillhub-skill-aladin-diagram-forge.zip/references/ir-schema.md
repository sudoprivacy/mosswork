# ir.json 中间表示规范

所有图都先落成统一的 `ir.json`，再由 `diagram_build.py` 渲染成任意格式。这样「自然语言 / 代码 / 现有图」三种输入殊途同归。

## 顶层字段

| 字段 | 必填 | 说明 |
|------|------|------|
| `title` | 否 | 图标题（也用作输出文件名前缀） |
| `type` | 是 | `architecture` / `flowchart` / `sequence` / `class` / `state` / `er` |
| `direction` | 否 | 架构/流程图方向：`TB`（上↓下，默认）/ `LR`（左→右） |
| `nodes` | 是 | 节点数组 |
| `edges` | 否 | 边数组 |
| `groups` | 否 | 架构图子图分组 |

## 节点 node

```json
{
  "id": "order",            // 唯一标识，英文/数字/下划线
  "label": "订单服务",       // 显示文字
  "shape": "rect",          // 形状：rect/rounded/cylinder/diamond/actor
  "fields": ["+id: Long", "+create(): void"]  // class/er 用
}
```

`shape` 可选值：

| shape | 含义 | mermaid 形态 |
|-------|------|--------------|
| `rect` | 矩形（默认） | `id[label]` |
| `rounded` | 圆角 | `id(label)` |
| `cylinder` | 圆柱（库/存储） | `id[(label)]` |
| `diamond` | 菱形（判断） | `id{label}` |
| `actor` | 角色/参与者 | `id([label])` |

## 边 edge

```json
{
  "from": "gw", "to": "order",
  "label": "调用",        // 边上的文字（可选）
  "kind": "->",           // 箭头：->(实线)/dotted(虚线)/thick(粗线)
  "order": 0,             // sequence 用，消息顺序
  "cardinality": "||--o{" // er 用，关系基数
}
```

## 分组 group（仅 architecture）

```json
{"id":"svc","label":"服务层","members":["order","pay"]}
```

## 六类图型最小示例

**architecture**
```json
{"type":"architecture","nodes":[{"id":"gw","label":"网关","shape":"rounded"},
 {"id":"svc","label":"服务","shape":"rect"}],"edges":[{"from":"gw","to":"svc","label":"路由"}]}
```

**sequence**
```json
{"type":"sequence","nodes":[{"id":"u","label":"用户","shape":"actor"},
 {"id":"s","label":"服务","shape":"actor"}],
 "edges":[{"from":"u","to":"s","label":"请求","order":0},{"from":"s","to":"u","label":"响应","order":1}]}
```

**class**
```json
{"type":"class","nodes":[{"id":"Order","fields":["+id: Long","+pay(): void"]}],
 "edges":[{"from":"Order","to":"User"}]}
```

**state**
```json
{"type":"state","edges":[{"from":"[*]","to":"Idle"},{"from":"Idle","to":"Run","label":"start"},{"from":"Run","to":"[*]","label":"done"}]}
```

**er**
```json
{"type":"er","nodes":[{"id":"USER","fields":["int id","string name"]},
 {"id":"ORDER","fields":["int id"]}],
 "edges":[{"from":"USER","to":"ORDER","cardinality":"||--o{","label":"places"}]}
```
