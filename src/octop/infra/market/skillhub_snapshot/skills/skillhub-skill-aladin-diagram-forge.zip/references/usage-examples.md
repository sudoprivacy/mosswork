# 完整场景示例

## 场景 1：代码目录 → 模块依赖架构图（最常用）

```bash
PY="C:/Users/adam/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SK="aladin-diagram-forge"
"$PY" $SK/scripts/diagram_ingest.py code --path ./my_project --out ir.json
"$PY" $SK/scripts/diagram_build.py --in ir.json --type architecture --format all --out ./out
"$PY" $SK/scripts/diagram_report.py --in ir.json --dir ./out --html diagrams.html
```

适用：接手新仓库、给新人讲依赖、写架构文档、Code Review 前快速摸清边界。

## 场景 2：自然语言需求 → 时序图

让 Hy3 按 `references/ir-schema.md` 把需求落成 `ir.json`（type=sequence），例如：

```json
{"type":"sequence","nodes":[{"id":"u","label":"用户","shape":"actor"},
 {"id":"api","label":"API","shape":"actor"},{"id":"db","label":"DB","shape":"actor"}],
 "edges":[{"from":"u","to":"api","label":"下单","order":0},
          {"from":"api","to":"db","label":"落库","order":1},
          {"from":"db","to":"api","label":"OK","order":2},
          {"from":"api","to":"u","label":"结果","order":3}]}
```

```bash
"$PY" $SK/scripts/diagram_build.py --in seq.json --type sequence --format mermaid --out ./out
```

## 场景 3：库表 → ER 图

```json
{"type":"er","nodes":[{"id":"USER","fields":["int id PK","string name"]},
 {"id":"ORDER","fields":["int id PK","int user_id FK"]}],
 "edges":[{"from":"USER","to":"ORDER","cardinality":"||--o{","label":"places"}]}
```

```bash
"$PY" $SK/scripts/diagram_build.py --in er.json --type er --format all --out ./out
```

## 场景 4：现有 mermaid → 转 PlantUML / DOT

```bash
"$PY" $SK/scripts/diagram_ingest.py mermaid --in arch.mmd --out ir.json
"$PY" $SK/scripts/diagram_build.py --in ir.json --format puml --out ./out
```

## 最佳实践

1. **同一份 ir.json 换图型**：`--type` 一改即可重渲染，不用重画。
2. **先校验再贴**：生成后看 `.validate.json`，有 ⚠️ 先修再提交。
3. **进版本控制**：图源 `.mmd/.puml/.dot` 是纯文本，可随代码评审。
4. **接 PPT**：把 `diagrams.html` 或图源交给 omni-deck-studio，做「需求→图→PPT」交付。

## 场景 5：设计偏好复用闭环（越画越懂你）

第一次你还得想「用 mermaid 还是 puml」「横向还是纵向」，画了几周后这些选择其实早就固化了。闭环让工具替你记住：

```bash
PB="diagram_playbook.json"
SK="aladin-diagram-forge"

# 1) 先 seed 4 条示例（或自己跑几次 --playbook 自然积累）
"$PY" $SK/scripts/diagram_retro.py seed --playbook $PB

# 2) 生成时加 --playbook：自动套用你最爱格式/方向，并写回本次结果
"$PY" $SK/scripts/diagram_build.py --in ir.json --playbook $PB --out ./out

# 3) 看画像 / 求建议
"$PY" $SK/scripts/diagram_retro.py summary --playbook $PB   # 各格式通过率、常画图型
"$PY" $SK/scripts/diagram_retro.py suggest --playbook $PB   # 下次默认格式/方向/分组

# 4) 画某类图前先评估易踩坑
"$PY" $SK/scripts/diagram_retro.py benchmark --type architecture --format mermaid --playbook $PB

# 5) 出报告时附「基于你历史验证的画图建议」
"$PY" $SK/scripts/diagram_report.py --in ir.json --dir ./out --html diagrams.html --md diagrams.md --playbook $PB
```

**效果**：第 2 步不再问格式；第 4 步提前告诉你「架构图用 mermaid 历史上平均 1.2 处括号问题，复杂图优先 dot」；第 5 步报告自带避坑提示。画图越多，画像越准，换机器把 `diagram_playbook.json` 一带就走。

## FAQ

- **Q：没有 Node/Graphviz 能渲染吗？** A：能。`.mmd` 在 GitHub/很多 Markdown 渲染器直接显示；`diagrams.html` 用浏览器+CDN 即看；只要不强制本地渲染器，零依赖可用。
- **Q：代码扫描把第三方库画进来了？** A：默认忽略常见第三方/标准库；若仍有，检查是否在忽略名单，或缩窄扫描目录。
- **Q：中文标签乱码？** A：脚本统一 UTF-8；图源文件用 UTF-8 保存即可，mermaid/PlantUML 均原生支持中文。
- **Q：--playbook 会上传我的图吗？** A：不会。验证库只记格式/方向/分组/校验结果等统计偏好，纯本地、零联网；想清掉直接删 `diagram_playbook.json`。
