---
name: skillhub-skill-aladin-diagram-forge
description: "阿拉丁·架构图工坊把\"画图\"从「手敲 mermaid 文本、只画一种流程图、生成后还可能在 GitHub 渲染失败」升级为一条本地工具链：①多源输入——自然语言需求 / 代码目录(自动抽取模块依赖→架构图) / 现有 mermaid·PlantUML·DOT(归一转换) / 文本流程；②6 类图型——架构图(C4-lite/模块依赖)、流程图、时序图、类图、状态图、ER 图；③纯本地语法校验——括号/子图/方向/节点引用即时定位，避免渲染翻车；④多格式导出——.mmd/.puml/.dot + 自包含 HTML 预览 + README 嵌入块；⑤与 omni-deck-studio 联动，架构图直接进 PPT。相比市面单点画图工具只做\"文本→一种流程图\"，本技能补齐代码抽取、多图型、语法校验、批量、联动与越用越准。零依赖、纯本地、离线可用。触发词：画架构图、架构图生成、代码架构图、模块依赖"
---

# 阿拉丁·架构图工坊（aladin-diagram-forge）

> 阿拉丁出品。你会写代码，但「给老板画张架构图 / 给新人讲清模块依赖 / 把需求落成时序图 / 给库表画 ER 图」每次都在手敲 mermaid、还经常括号不匹配在 GitHub 渲染失败。市面上的单点画图工具只能「文本→一种图」，不抽代码、不校验、不联动——**没有任何技能把画图工程化**。这个技能把画图收口成一套纯本地工具：你给需求或代码目录，它产出 6 类工程图、本地校验语法、导出多种格式、还能直接喂进 PPT。

## 它解决什么痛点

开发者想「画张架构图 / 落张时序图」，市面上的**单点画图工具**大多只做：文本→一种流程图、或提示词→一张图，普遍存在四个短板——**不抽真实代码、不做多图型、不本地校验语法、强依赖在线账号**。

**本技能 = 画图全链路**：把画图收口成一套纯本地工具链，补齐上面所有短板，且与自家 aladin 工程链互补。

## 能力全景（本款 vs 市面单点画图工具）

| 能力 | 市面单点画图工具 | **阿拉丁·架构图工坊(本款)** |
|------|-----------------|------------------------------|
| 代码目录→架构图(自动抽依赖) | 普遍不支持 | ✅ 扫描 import/依赖→模块图 |
| 图型数量 | 通常 1 种(流程图) | ✅ 6 类(架构/流程/时序/类/状态/ER) |
| 现有图归一转换(mmd↔puml↔dot) | 不支持 | ✅ 三格式互通 |
| 纯本地语法校验(渲染前排错) | 无 | ✅ 括号/子图/节点引用定位 |
| 多格式导出(.mmd/.puml/.dot/HTML) | 有限/在线 | ✅ 四格式 + 自包含预览 |
| 与 PPT 联动 | 无 | ✅ 接 omni-deck-studio |
| 离线 / 零依赖 | 部分在线 | ✅ 纯标准库 |

**与自家 aladin 系列的关系**：code-pilot 审函数、api-pilot 验接口、sql-forge 管存储、diagram-forge 画结构——四者覆盖「函数→接口→存储→结构可视化」，可串成统一工程交付链。

## 何时触发

- "帮我画张架构图 / 把这套系统画成模块依赖图 / 生成 C4 风格的架构图"
- "扫描这个代码目录，抽出模块依赖关系画成图"
- "把这段需求/流程落成流程图 / 时序图 / 状态图"
- "给这几张表画个 ER 图 / 给这个类设计画类图"
- "我有一段 mermaid / PlantUML / dot，帮我转成另一种格式 / 校验一下能不能渲染"
- "把架构图导出来，我要贴进 README / 放进 PPT"
- 用户贴出自然语言需求、代码路径、或现有图源码，希望一次性拿到可渲染、可嵌入的工程图

## 何时不触发

- 用户要**高保真视觉设计 / 品牌级配图 / 插画**——属 design-media，用海报设计/UI 设计类技能。
- 用户要**实时协作白板 / 拖拽编辑**——本技能产出文本源文件，可导入 drawio/ProcessOn 继续编辑，但不提供画布。
- 用户要**深度架构评审 / 容量规划 / 技术选型**——本技能只画图，不替代架构师决策。
- 用户要**业务数据分析图（柱状/折线/饼）**——用智能数据可视化 / excel-chart-builder 类技能。
- 用户代码涉及**强合规涉密且禁止本地留痕**——虽本技能纯本地，仍需先确认合规策略。

## 核心能力（统一工具链 + 本地增值）

1. **多源输入归一**：自然语言需求（Hy3 落成 IR JSON）/ 代码目录（自动抽模块依赖）/ 现有 mermaid·PlantUML·DOT（解析归一）/ 文本流程描述 → 统一中间表示 `ir.json`。
2. **6 类工程图**：架构图（C4-lite / 模块依赖，含子图分组）、流程图、时序图、类图、状态图、ER 图——远超单点只画流程图。
3. **代码→架构图（独家）**：扫描指定目录的代码（py/js/ts/java/go），抽取文件即模块、import/require 即依赖边，自动产出模块依赖架构图，无需手敲。
4. **纯本地语法校验**：生成后即时校验 mermaid / PlantUML / DOT 的括号配平、子图开合、方向声明、节点引用、关键字合法性，输出可定位的错误行，避免「GitHub 渲染翻车」。
5. **多格式导出**：`.mmd`（mermaid）/ `.puml`（PlantUML）/ `.dot`（Graphviz）/ 自包含 `diagrams.html` 预览（双击即看）/ README 嵌入块。
6. **与 omni-deck 联动**：生成的架构图源可喂给 omni-deck-studio 变成 PPT 中的架构页，形成「需求→图→PPT」交付。
7. **设计偏好复用闭环**：每次生成把图型/格式/方向/分组/语法校验结果沉淀为本地验证库 `diagram_playbook.json`；下次 `diagram_build.py --playbook` 自动套用你历史最爱格式与方向、架构图无分组时按历史习惯提示分组，`diagram_report.py --playbook` 在报告附「基于你历史验证的画图建议」（各格式通过率 + 易踩坑预警），画图越多越贴合你的习惯、越画越稳。

## 工作流（4 步）

```
① 归一    diagram_ingest.py {code|text|mermaid|puml|dot|json} → ir.json
          （自然语言需求由 Hy3 直接产出 ir.json，跳过此步）
② 生成    diagram_build.py --type auto --format all → *.mmd / *.puml / *.dot + 校验报告
③ 汇总    diagram_report.py → diagrams.html(预览) / diagrams.md(清单) / README 嵌入块
④ 沉淀    diagram_build.py --playbook 把本次图型/格式/方向/分组/校验结果写入
          diagram_playbook.json；下次 --playbook 自动套用你最爱格式与方向，
          报告附「基于你历史验证的画图建议」，画图越多越贴合你的习惯、越画越稳
```

> 💡 **设计偏好复用闭环（第 4 步）**：前 3 步把图「画出来」，第 4 步让工具「记住你」。每次生成自动沉淀为纯本地验证库，下次少做重复选择、还能提前避开你常踩的语法坑——形成 生成→沉淀→复用 飞轮，越用越值。详见 `references/closed-loop-playbook.md`。

## 使用方式

脚本零依赖，直接用托管 Python 运行（无需 pip install）：

```bash
PY="C:/Users/adam/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SK="aladin-diagram-forge"

# ① 代码目录 → 架构图（自动抽依赖）
"$PY" $SK/scripts/diagram_ingest.py code --path ./my_project --out ir.json

# ② 现有 mermaid → 归一 IR（再转其它格式）
"$PY" $SK/scripts/diagram_ingest.py mermaid --in arch.mmd --out ir.json

# ③ IR → 6 类图自动识别，输出全部三种格式并校验
"$PY" $SK/scripts/diagram_build.py --in ir.json --type auto --format all --out ./out

# ④ 指定图型 + 指定格式
"$PY" $SK/scripts/diagram_build.py --in ir.json --type sequence --format mermaid --out ./out

# ⑤ 汇总为预览报告
"$PY" $SK/scripts/diagram_report.py --in ir.json --dir ./out --html diagrams.html --md diagrams.md
```

> 自然语言需求：让 Hy3 按 `references/ir-schema.md` 把需求落成 `ir.json`，再跑 ③ 即可，无需手敲任何图语法。

### 设计偏好复用闭环（越画越懂你）

```bash
PB="diagram_playbook.json"

# ① 先沉淀几次（或 seed 4 条示例上手即见）
"$PY" $SK/scripts/diagram_retro.py seed --playbook $PB
"$PY" $SK/scripts/diagram_build.py --in ir.json --playbook $PB --out ./out   # 自动套用你最爱格式/方向并记录

# ② 看你的画图画像
"$PY" $SK/scripts/diagram_retro.py summary --playbook $PB
"$PY" $SK/scripts/diagram_retro.py suggest --playbook $PB

# ③ 出报告时附「基于你历史验证的画图建议」
"$PY" $SK/scripts/diagram_report.py --in ir.json --dir ./out --html diagrams.html --md diagrams.md --playbook $PB

# ④ 画某类图前先评估易踩坑、挑最稳格式
"$PY" $SK/scripts/diagram_retro.py benchmark --type architecture --format mermaid --playbook $PB
```

> 验证库 `diagram_playbook.json` 纯本地、零联网、数据不出本机；可随项目目录提交进版控，换机器也能带着你的偏好走。

## ir.json 速查（输入契约）

```json
{
  "title": "订单服务架构",
  "type": "architecture",
  "nodes": [
    {"id":"gw","label":"API网关","shape":"rounded"},
    {"id":"order","label":"订单服务","shape":"rect"},
    {"id":"db","label":"订单库","shape":"cylinder"}
  ],
  "edges": [
    {"from":"gw","to":"order","label":"调用","kind":"->"},
    {"from":"order","to":"db","label":"读写","kind":"->"}
  ],
  "groups": [
    {"id":"svc","label":"服务层","members":["order"]}
  ]
}
```

## 输入输出规范

**输入：**
- 自然语言需求（Hy3 落成 `ir.json`，结构见 `references/ir-schema.md`）
- 或代码目录（`--path`，自动扫描抽取）
- 或现有图源码（`.mmd` / `.puml` / `.dot`）
- 或文本流程描述（每行一步 / 含 `→` 的回退解析）
- 可选：图型（`--type`）、格式（`--format`）、方向（`--dir TB|LR`）

**输出：**
- `ir.json`：统一中间表示（中间产物）
- `*.mmd` / `*.puml` / `*.dot`：对应图型源文件
- `diagrams.html`：自包含预览（mermaid 经 CDN 实时渲染，PlantUML/DOT 附源码+渲染入口）
- `diagrams.md`：图清单 + 嵌入代码块，可直接贴 README

**输出位置：** 由 `--out` / `--dir` 参数指定，默认当前目录。

## 能力边界

**能做：**
1. 生成 6 类工程图（架构/流程/时序/类/状态/ER）的 mermaid/PlantUML/DOT 源。
2. 扫描 py/js/ts/java/go 目录，自动抽取模块依赖产出架构图。
3. 对生成的图做括号/子图/节点引用等纯本地语法校验并定位错误。
4. 在 mmd↔puml↔dot 间做结构归一转换。
5. 汇总为可双击预览的 HTML 与可贴 README 的 MD。

**不能做：**
1. 不做**高保真视觉 / 品牌配图**（只产文本源，可导入 drawio/ProcessOn 精修）。
2. 不提供**拖拽画布 / 实时协作**（产出文件，非在线白板）。
3. 不替代**架构师的技术选型 / 容量评审**决策。
4. HTML 预览中 mermaid 走 CDN 渲染，完全离线环境需本地 mermaid CLI（已说明）。
5. 代码扫描是**静态 import 级**依赖，不含运行时调用/反射关系。

## 重要约束

- **不联网抽代码**：代码扫描只读本地目录，不发起任何网络请求（→ Trust）。
- **只产源不渲染强制**：默认只生成文本源与本地预览，是否用外部渲染器由你决定（→ Reliability）。
- **可编辑优先**：所有产物是纯文本源文件，可进版控、可二次编辑（→ Adaptability）。
- **零依赖透明**：脚本仅用 Python 标准库，SKILL.md 已写明运行方式，无需安装任何包（→ Adaptability）。
- **不臆造结构**：架构图严格基于扫描到的真实依赖或用户提供的 IR，不私自编造模块关系（→ Convention）。

## 安全说明

- 全部脚本仅用 Python 标准库，**不发起任何网络请求**（HTML 预览里的 mermaid CDN 由浏览器在用户本地打开时加载，脚本本身不出网）。
- 代码扫描只读目录、不修改任何文件；生成图源写入本地，适合含内部模块结构的私有仓库。
- 建议在提交前 `git diff` 确认抽取结果，避免把临时/ vendored 目录误画进架构图。

## 参考文档（渐进式披露）

| 文件 | 用途 | 加载时机 |
|------|------|----------|
| `references/ir-schema.md` | ir.json 全字段规范 + 6 类图型示例 | Hy3 把需求落成 IR / 手写 IR 时 |
| `references/diagram-types.md` | 6 类图型语法速查与适用场景 | 选图型 / 调试语法时 |
| `references/code-scan-rules.md` | 代码→架构图 的抽取规则与忽略项 | 跑代码扫描前 |
| `references/usage-examples.md` | 4 个完整场景 + 最佳实践 + FAQ | 首次使用 / 排错时 |
| `references/closed-loop-playbook.md` | 设计偏好复用闭环操作手册（沉淀/复用/避坑） | 第 4 步 / 想让工具越用越懂你时 |

## 常见问题 FAQ

**Q1：`--playbook` 会把我的图传到网上吗？**
不会。验证库 `diagram_playbook.json` 只记录图型/格式/方向/分组/校验结果等统计性偏好，纯本地写入、零联网、数据不出本机；可随项目目录提交进版控，换机器也能带着你的偏好走。

**Q2：`--playbook` 和直接 `--format mermaid` 有什么区别？**
`--format mermaid` 是「这一次要 mermaid」；`--playbook` 是「按我历史最常用的格式来」——你前几次多用 puml，它就自动用 puml，不用每次想。养成习惯后几乎不用再选格式。

**Q3：验证库会不会越积越大、拖慢画图？**
不会。它只是几条 JSON 记录（每条几十字节），`suggest/benchmark` 是 O(n) 轻量统计，毫秒级；想重来直接删 `diagram_playbook.json` 即可。

**Q4：我换了个项目，偏好还能用吗？**
能。验证库跟着你执行的目录走；把 `diagram_playbook.json` 放进项目根或随仓库提交，任何机器上 `diagram_build.py --playbook ./diagram_playbook.json` 都能复用你的习惯。

**Q5：和 omni-deck-studio 联动时，闭环还生效吗？**
生效。`--playbook` 只影响「本技能生成图」的偏好与建议；生成后照常可把图源喂给 omni-deck-studio 做 PPT，两条链路互不干扰。
