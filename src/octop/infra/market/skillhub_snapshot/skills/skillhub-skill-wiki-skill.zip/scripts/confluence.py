#!/usr/bin/env python3
"""Confluence REST CLI for the OpenCode inke-wiki skill.

This script replaces the local mcp-confluence-server package for agent use. It targets
Confluence Server/Data Center style REST APIs with PAT bearer auth.
"""
from __future__ import annotations

import argparse
import base64
import html
import getpass
import json
import mimetypes
import os
import re
import ssl
import sys
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

SKILL_DIR = Path(__file__).resolve().parent
DOWNLOADS = Path.home() / "Downloads"
MD_OUTPUT = DOWNLOADS / "confluence-md-to-xhtml.result"
DOCX_OUTPUT = DOWNLOADS / "confluence-docx-to-xhtml.result"
CONFIG_FILE = SKILL_DIR / "config.json"
DEFAULT_BASE_URL = ""
DEFAULT_TIMEOUT_SECONDS = int(os.environ.get("CONFLUENCE_TIMEOUT_SECONDS", "60"))
PAT_HELP_PATH = "/plugins/personalaccesstokens/usertokens.action"


class CliError(Exception):
    def __init__(self, message: str, *, status: Optional[int] = None, details: Any = None):
        super().__init__(message)
        self.status = status
        self.details = details


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise CliError(f"Argument error: {message}")


@dataclass
class Config:
    base_url: str
    pat: str

    @property
    def api_base(self) -> str:
        return f"{self.base_url}/rest/api"


def pat_help_url(base_url: str) -> str:
    cleaned = (base_url or "").strip().rstrip("/")
    return f"{cleaned}{PAT_HELP_PATH}" if cleaned else f"https://<Wiki基础域名>{PAT_HELP_PATH}"


def read_saved_config() -> Dict[str, str]:
    if not CONFIG_FILE.exists():
        return {}
    try:
        # Accept UTF-8 files with or without BOM so manual Windows edits do not break config loading.
        raw = CONFIG_FILE.read_text(encoding="utf-8-sig")
        data = json.loads(raw)
    except Exception as exc:
        raise CliError(f"Could not read saved config at {CONFIG_FILE}") from exc
    if not isinstance(data, dict):
        raise CliError(f"Invalid saved config format at {CONFIG_FILE}")
    result: Dict[str, str] = {}
    base_url = str(data.get("base_url", "")).strip()
    pat = str(data.get("pat", "")).strip()
    if base_url:
        result["base_url"] = base_url.rstrip("/")
    if pat:
        result["pat"] = pat
    return result


def write_saved_config(base_url: str, pat: str) -> None:
    payload = {"base_url": base_url.rstrip("/"), "pat": pat}
    CONFIG_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except Exception:
        pass


def prompt_for_config(base_url: str = DEFAULT_BASE_URL, pat: str = "") -> Config:
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise CliError(
            "Missing or incomplete Confluence config. "
            f"Run `python3 ./confluence.py setup` once in {SKILL_DIR}. "
            f"PAT page: {pat_help_url(base_url)}"
        )
    print("Confluence config is missing or incomplete. Let's save it once so future commands work automatically.")
    print(f"If you still need a PAT, open: {pat_help_url(base_url)}")
    entered_base_url = input(f"Confluence base URL [{base_url}]: ").strip() or base_url
    entered_pat = pat.strip() or getpass.getpass("Confluence PAT: ").strip()
    if not entered_base_url:
        raise CliError("Confluence base URL is required")
    if not entered_pat:
        raise CliError("Confluence PAT is required")
    write_saved_config(entered_base_url, entered_pat)
    return Config(base_url=entered_base_url.rstrip("/"), pat=entered_pat)


def load_config(require_auth: bool = True) -> Config:
    saved = read_saved_config()
    base_url = saved.get("base_url", "").strip().rstrip("/") or DEFAULT_BASE_URL
    pat = saved.get("pat", "").strip()
    if require_auth and (not base_url or not pat):
        return prompt_for_config(base_url=base_url)
    return Config(base_url=base_url, pat=pat)


class ConfluenceClient:
    def __init__(self, config: Config, *, insecure: bool = False):
        self.config = config
        self.ssl_context = ssl._create_unverified_context() if insecure else None

    def _open(self, req: urllib.request.Request):
        kwargs = {"timeout": DEFAULT_TIMEOUT_SECONDS}
        if self.ssl_context is not None:
            kwargs["context"] = self.ssl_context
        return urllib.request.urlopen(req, **kwargs)

    def request(
        self,
        method: str,
        endpoint: str,
        *,
        query: Optional[Dict[str, Any]] = None,
        body: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> Any:
        if not endpoint.startswith("/"):
            endpoint = "/" + endpoint
        url = self.config.api_base + endpoint
        if query:
            clean_query = {k: v for k, v in query.items() if v is not None}
            if clean_query:
                url += "?" + urllib.parse.urlencode(clean_query, doseq=True)

        req_headers = {
            "Authorization": f"Bearer {self.config.pat}",
            "Accept": "application/json",
        }
        data: Optional[bytes] = None
        if body is not None:
            req_headers["Content-Type"] = "application/json"
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        if headers:
            req_headers.update(headers)

        req = urllib.request.Request(url, data=data, headers=req_headers, method=method.upper())
        try:
            with self._open(req) as resp:
                raw = resp.read()
                return parse_response(raw, resp.headers.get("Content-Type"))
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            text = raw.decode("utf-8", errors="replace") if raw else ""
            raise CliError(
                f"Confluence API error: {exc.code} {exc.reason} - {text}",
                status=exc.code,
                details=response_details(text),
            ) from exc
        except urllib.error.URLError as exc:
            raise CliError(f"Confluence request failed: {exc.reason}") from exc

    def upload_multipart(
        self,
        endpoint: str,
        *,
        filename: str,
        data: bytes,
        content_type: Optional[str],
        comment: Optional[str],
    ) -> Any:
        boundary = f"----opencode-confluence-{uuid.uuid4().hex}"
        guessed_type = content_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"
        safe_filename = multipart_filename(Path(filename).name)
        parts: List[bytes] = []
        parts.append(f"--{boundary}\r\n".encode())
        parts.append(f'Content-Disposition: form-data; name="file"; filename="{safe_filename}"\r\n'.encode())
        parts.append(f"Content-Type: {guessed_type}\r\n\r\n".encode())
        parts.append(data)
        parts.append(b"\r\n")
        if comment:
            parts.append(f"--{boundary}\r\n".encode())
            parts.append(b'Content-Disposition: form-data; name="comment"\r\n\r\n')
            parts.append(comment.encode("utf-8"))
            parts.append(b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        payload = b"".join(parts)

        if not endpoint.startswith("/"):
            endpoint = "/" + endpoint
        url = self.config.api_base + endpoint
        req = urllib.request.Request(
            url,
            data=payload,
            method="POST",
            headers={
                "Authorization": f"Bearer {self.config.pat}",
                "Accept": "application/json",
                "X-Atlassian-Token": "no-check",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "Content-Length": str(len(payload)),
            },
        )
        try:
            with self._open(req) as resp:
                return parse_response(resp.read(), resp.headers.get("Content-Type"))
        except urllib.error.HTTPError as exc:
            text = exc.read().decode("utf-8", errors="replace")
            raise CliError(
                f"Attachment upload error: {exc.code} {exc.reason} - {text}",
                status=exc.code,
                details=response_details(text),
            ) from exc
        except urllib.error.URLError as exc:
            raise CliError(f"Attachment upload failed: {exc.reason}") from exc

    def get_content(self, content_id: str, expand: Optional[List[str]] = None) -> Any:
        query = {"expand": ",".join(expand)} if expand else None
        return self.request("GET", f"/content/{content_id}", query=query)

    def search_content(self, cql: str, limit: int = 25) -> Any:
        return self.request("GET", "/content/search", query={"cql": cql, "limit": limit})

    def get_spaces(self, limit: int = 25) -> Any:
        return self.request("GET", "/space", query={"limit": limit})

    def create_content(self, *, content_type: str, title: str, space_key: str, body: str, parent_id: Optional[str]) -> Any:
        payload: Dict[str, Any] = {
            "type": content_type,
            "title": title,
            "space": {"key": space_key},
            "body": {"storage": {"value": body, "representation": "storage"}},
        }
        if parent_id:
            payload["ancestors"] = [{"id": parent_id}]
        return self.request("POST", "/content", body=payload)

    def update_content(self, *, content_id: str, title: str, body: str, version: int) -> Any:
        payload = {
            "version": {"number": version},
            "title": title,
            "type": "page",
            "body": {"storage": {"value": body, "representation": "storage"}},
        }
        return self.request("PUT", f"/content/{content_id}", body=payload)


def parse_response(raw: bytes, content_type: Optional[str]) -> Any:
    if not raw:
        return None
    text = raw.decode("utf-8", errors="replace")
    if content_type and "json" not in content_type.lower():
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def response_details(text: str) -> Any:
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def parse_expand(value: Optional[str]) -> Optional[List[str]]:
    if not value:
        return None
    return [part.strip() for part in value.split(",") if part.strip()]


def success(command: str, data: Any, **extra: Any) -> Dict[str, Any]:
    payload = {"ok": True, "command": command, "data": data}
    payload.update(extra)
    return payload


def failure(command: str, error: Exception, *, debug: bool = False) -> Dict[str, Any]:
    payload: Dict[str, Any] = {"ok": False, "command": command, "error": str(error)}
    if isinstance(error, CliError):
        if error.status is not None:
            payload["status"] = error.status
        if error.details is not None:
            payload["details"] = error.details
    if debug:
        payload["traceback"] = traceback.format_exc()
    return payload


def multipart_filename(filename: str) -> str:
    return filename.replace("\\", "\\\\").replace('"', '\\"').replace("\r", "_").replace("\n", "_")


def content_version(client: ConfluenceClient, content_id: str) -> int:
    current = client.get_content(content_id, ["version"])
    try:
        return int(current["version"]["number"])
    except Exception as exc:
        raise CliError(f"Could not read current version from content {content_id}", details=current) from exc


def clean_update_body(body: str, *, url_encoded: bool = False) -> str:
    if url_encoded:
        try:
            return urllib.parse.unquote(body).strip()
        except Exception:
            return body.strip()
    return body.strip()


def expand_user_path(path: str) -> Path:
    return Path(path).expanduser().resolve()


def ensure_source_file(path: str, suffixes: Iterable[str]) -> Path:
    source = expand_user_path(path)
    if not source.exists() or not source.is_file():
        raise CliError(f"Source file does not exist: {source}")
    allowed = {s.lower() for s in suffixes}
    if source.suffix.lower() not in allowed:
        raise CliError(f"Unsupported file extension {source.suffix}; expected one of {sorted(allowed)}")
    return source


def write_download_result(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def markdown_to_xhtml(markdown_text: str) -> str:
    try:
        import markdown as markdown_lib  # type: ignore
        return markdown_lib.markdown(
            markdown_text,
            extensions=["extra", "toc", "sane_lists", "nl2br"],
            output_format="xhtml",
        )
    except Exception:
        return f"<p>{html.escape(markdown_text)}</p>"


def docx_to_xhtml(docx_path: Path) -> str:
    try:
        import mammoth  # type: ignore
        with docx_path.open("rb") as source:
            result = mammoth.convert_to_html(source)
            return result.value
    except Exception:
        with zipfile.ZipFile(docx_path) as zf:
            xml = zf.read("word/document.xml").decode("utf-8", errors="replace")
        text = " ".join(re.findall(r">([^<]+)<", xml))
        return f"<p>{html.escape(text.strip())}</p>"


def build_parser() -> JsonArgumentParser:
    parser = JsonArgumentParser(description="Confluence REST CLI for inke-wiki")
    subparsers = parser.add_subparsers(dest="command", required=True)

    def add_request_args(command_parser: argparse.ArgumentParser) -> None:
        command_parser.add_argument(
            "--insecure",
            action="store_true",
            help="Temporarily skip TLS certificate verification for HTTPS requests",
        )
        command_parser.add_argument("--debug", action="store_true")

    setup = subparsers.add_parser("setup", help="Save Confluence config locally for future use")
    setup.add_argument("--baseUrl", default=DEFAULT_BASE_URL)
    setup.add_argument("--pat")
    setup.add_argument("--force", action="store_true")
    setup.add_argument("--debug", action="store_true")

    get_content = subparsers.add_parser("get-content", help="Fetch content by ID")
    get_content.add_argument("--contentId", required=True)
    get_content.add_argument("--expand")
    add_request_args(get_content)

    search = subparsers.add_parser("search-content", help="Search wiki content with CQL")
    search.add_argument("--cql", required=True)
    search.add_argument("--limit", type=int, default=25)
    add_request_args(search)

    spaces = subparsers.add_parser("get-spaces", help="List spaces")
    spaces.add_argument("--limit", type=int, default=25)
    add_request_args(spaces)

    create = subparsers.add_parser("create-content", help="Create a page")
    create.add_argument("--type", required=True)
    create.add_argument("--title", required=True)
    create.add_argument("--spaceKey", required=True)
    create.add_argument("--body", required=True)
    create.add_argument("--parentId")
    add_request_args(create)

    update = subparsers.add_parser("update-content", help="Update a page")
    update.add_argument("--id", required=True)
    update.add_argument("--title", required=True)
    update.add_argument("--body", required=True)
    update.add_argument("--version", type=int)
    update.add_argument("--urlEncodedBody", action="store_true")
    add_request_args(update)

    debug_update = subparsers.add_parser("debug-update-content", help="Update a page with verification details")
    debug_update.add_argument("--id", required=True)
    debug_update.add_argument("--title", required=True)
    debug_update.add_argument("--body", required=True)
    debug_update.add_argument("--version", type=int)
    debug_update.add_argument("--urlEncodedBody", action="store_true")
    add_request_args(debug_update)

    upload = subparsers.add_parser("upload-attachment", help="Upload an attachment")
    upload.add_argument("--contentId", required=True)
    upload.add_argument("--file")
    upload.add_argument("--filename")
    upload.add_argument("--data")
    upload.add_argument("--isBase64", action="store_true")
    upload.add_argument("--contentType")
    upload.add_argument("--comment")
    add_request_args(upload)

    md = subparsers.add_parser("content-from-markdown", help="Convert markdown and optionally create/update")
    md.add_argument("--filePath", required=True)
    md.add_argument("--action", required=True, choices=["save", "create", "update"])
    md.add_argument("--spaceKey")
    md.add_argument("--newTitle")
    md.add_argument("--contentId")
    md.add_argument("--title")
    add_request_args(md)

    docx = subparsers.add_parser("content-from-docx", help="Convert docx and optionally save")
    docx.add_argument("--filePath", required=True)
    docx.add_argument("--action", required=True, choices=["save"])
    docx.add_argument("--debug", action="store_true")

    return parser


def main() -> int:
    parser = build_parser()
    try:
        args = parser.parse_args()
        if args.command == "setup":
            base_url = args.baseUrl.strip().rstrip("/") or DEFAULT_BASE_URL
            pat = args.pat.strip() if args.pat else ""
            if not base_url:
                raise CliError("Confluence base URL is required")
            if not pat:
                if not sys.stdin.isatty() or not sys.stdout.isatty():
                    raise CliError("Provide --pat, or run setup in an interactive terminal")
                pat = getpass.getpass("Confluence PAT: ").strip()
            if not pat:
                raise CliError("Confluence PAT is required")
            if args.force or not CONFIG_FILE.exists():
                write_saved_config(base_url, pat)
            else:
                existing = read_saved_config()
                write_saved_config(base_url or existing.get("base_url", DEFAULT_BASE_URL), pat or existing.get("pat", ""))
            print(json.dumps(success("setup", {"configFile": str(CONFIG_FILE), "baseUrl": base_url}), ensure_ascii=False, indent=2))
            return 0

        require_auth = args.command not in {"content-from-markdown", "content-from-docx"} or args.action != "save"
        config = load_config(require_auth=require_auth)
        client = ConfluenceClient(config, insecure=bool(getattr(args, "insecure", False)))

        if args.command == "get-content":
            result = client.get_content(args.contentId, parse_expand(args.expand))
            print(json.dumps(success("get-content", result), ensure_ascii=False, indent=2))
            return 0

        if args.command == "search-content":
            result = client.search_content(args.cql, args.limit)
            print(json.dumps(success("search-content", result), ensure_ascii=False, indent=2))
            return 0

        if args.command == "get-spaces":
            result = client.get_spaces(args.limit)
            print(json.dumps(success("get-spaces", result), ensure_ascii=False, indent=2))
            return 0

        if args.command == "create-content":
            result = client.create_content(
                content_type=args.type,
                title=args.title,
                space_key=args.spaceKey,
                body=args.body,
                parent_id=args.parentId,
            )
            print(json.dumps(success("create-content", result), ensure_ascii=False, indent=2))
            return 0

        if args.command in {"update-content", "debug-update-content"}:
            previous_version = args.version if args.version is not None else content_version(client, args.id)
            next_version = previous_version + 1
            cleaned_body = clean_update_body(args.body, url_encoded=args.urlEncodedBody)
            result = client.update_content(content_id=args.id, title=args.title, body=cleaned_body, version=next_version)
            if args.command == "debug-update-content":
                verification = client.get_content(args.id, ["body.storage", "version"])
                payload = {
                    "id": args.id,
                    "title": args.title,
                    "previousVersion": previous_version,
                    "updatedVersion": next_version,
                    "updateResponse": result,
                    "verification": verification,
                }
                print(json.dumps(success("debug-update-content", payload), ensure_ascii=False, indent=2))
            else:
                print(json.dumps(success("update-content", result), ensure_ascii=False, indent=2))
            return 0

        if args.command == "upload-attachment":
            if args.file:
                source = expand_user_path(args.file)
                data = source.read_bytes()
                filename = source.name
            elif args.data and args.filename:
                data = base64.b64decode(args.data) if args.isBase64 else args.data.encode("utf-8")
                filename = args.filename
            else:
                raise CliError("Provide either --file or both --filename and --data")
            result = client.upload_multipart(
                f"/content/{args.contentId}/child/attachment",
                filename=filename,
                data=data,
                content_type=args.contentType,
                comment=args.comment,
            )
            print(json.dumps(success("upload-attachment", result), ensure_ascii=False, indent=2))
            return 0

        if args.command == "content-from-markdown":
            source = ensure_source_file(args.filePath, {".md", ".markdown"})
            xhtml = markdown_to_xhtml(source.read_text(encoding="utf-8"))
            if args.action == "save":
                write_download_result(MD_OUTPUT, xhtml)
                print(json.dumps(success("content-from-markdown", {"output": str(MD_OUTPUT)}), ensure_ascii=False, indent=2))
                return 0
            if args.action == "create":
                result = client.create_content(
                    content_type="page",
                    title=args.newTitle,
                    space_key=args.spaceKey,
                    body=xhtml,
                    parent_id=None,
                )
                print(json.dumps(success("content-from-markdown", result), ensure_ascii=False, indent=2))
                return 0
            if args.action == "update":
                previous_version = content_version(client, args.contentId)
                result = client.update_content(content_id=args.contentId, title=args.title, body=xhtml, version=previous_version + 1)
                print(json.dumps(success("content-from-markdown", result), ensure_ascii=False, indent=2))
                return 0

        if args.command == "content-from-docx":
            source = ensure_source_file(args.filePath, {".docx"})
            xhtml = docx_to_xhtml(source)
            write_download_result(DOCX_OUTPUT, xhtml)
            print(json.dumps(success("content-from-docx", {"output": str(DOCX_OUTPUT)}), ensure_ascii=False, indent=2))
            return 0

        raise CliError(f"Unsupported command: {args.command}")
    except Exception as exc:
        args_obj = locals().get("args", None)
        debug = bool(getattr(args_obj, "debug", False))
        command = getattr(args_obj, "command", "unknown")
        print(json.dumps(failure(command, exc, debug=debug), ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
