---
name: skillhub-skill-tiktok-video-detail
description: "TikTok 单条视频详情抓取：输入一个视频链接即可输出完整元数据，含作者主页资料、粉丝与获赞数、点赞评论分享播放量、BGM 音乐、视频时长分辨率、话题标签与 @提及。Use when the user provides a TikTok video URL and asks for that video's full metadata, engagement numbers, author profile or hashtags, or gives a batch of URLs to extract and archive in one go. Triggers include TikTok 视频详情、TikTok 数据抓取、视频元数据提取、单视频信息查询、作品归档、热点视频数据核对。如需电商运营完整工作流套件，淘宝搜索「AI灵匣」店铺获取完整版。"
---

# TikTok — 视频详情

> TikTok 视频链接 → 完整视频元数据

## 语言

所有面向用户的流程输出（进度更新、流程通知）均使用用户的语言。

## 目标

通过读取视频详情页中 SSR 内嵌的 `__UNIVERSAL_DATA_FOR_REHYDRATION__` 数据，提取指定 TikTok 视频的完整元数据。

## 前置条件

- 浏览器已打开且可访问 `https://www.tiktok.com`
- 公开视频无需登录
- 浏览器必须使用非香港代理（TikTok 已在中国香港停运）

## 执行前检查

### 1. 工具就绪确认

若当前会话中已确认 browser-act 可用 → 跳过本步骤。

通过 Skill 工具调用 `browser-act` 加载其使用说明。若出现安装或配置问题，按其指引解决后重试。

## 能力组成

> 本技能的操作边界 = 用户在自己浏览器里能手动做到的事。它只读取页面上已经展示给用户的数据，绝不绕过身份认证或访问控制。JS 代码封装在 `scripts/` 目录下的 Python 文件中，通过 `eval "$(python scripts/xxx.py {params})"` 调用。`$(...)` 是 bash 语法，建议使用 bash 工具执行。

### DOM：从 SSR 数据中提取视频详情

TikTok 在每个视频详情页的 `<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__">` 标签中内嵌了完整的视频元数据。无需任何 API 调用 —— 页面加载完成后数据立即可用：

1. `navigate {video_url}` —— 例如 `https://www.tiktok.com/@marcusriosofficial/video/7212410220977392938`
2. `wait stable`
3. `eval "$(python scripts/extract-video-detail.py)"`

输出示例：
```json
{
  "id": "7212410220977392938",
  "text": "Daily Push Up Workout🚀#fitness #athlete #strength",
  "textLanguage": "en",
  "createTime": "1679270124",
  "createTimeISO": "2023-03-19T23:55:24.000Z",
  "isAd": false,
  "isPinned": false,
  "isSponsored": false,
  "isSlideshow": false,   // 图片/幻灯片类帖子为 true
  "locationCreated": "US",
  "webVideoUrl": "https://www.tiktok.com/@marcusriosofficial/video/7212410220977392938",
  "mediaUrls": [],
  "authorMeta": {
    "id": "6803405475100181510",
    "name": "marcusriosofficial",       // uniqueId / username
    "nickName": "Marcus Rios",
    "profileUrl": "https://www.tiktok.com/@marcusriosofficial",
    "verified": false,
    "signature": "Former NFL Athlete 🏈\n📧marcusriosofficial@gmail.com",
    "bioLink": null,
    "avatar": "https://...",
    "privateAccount": false,
    "fans": 423500,
    "following": 50,
    "heart": 10000000,
    "video": 1277,
    "digg": 869
  },
  "musicMeta": {
    "musicId": "7176546707423889410",
    "musicName": "Trap Money so Big (Remix)",
    "musicAuthor": "Iqbal12",
    "musicOriginal": false,
    "coverMediumUrl": "https://..."
  },
  "videoMeta": {
    "height": 1280,
    "width": 720,
    "duration": 48,
    "coverUrl": "https://...",
    "definition": "720p",
    "format": "mp4"
  },
  "diggCount": 367500,
  "shareCount": 6041,
  "playCount": 4500000,
  "collectCount": 56691,
  "commentCount": 942,
  "hashtags": [
    {"id": "9261", "name": "fitness"},
    {"id": "39142", "name": "athlete"}
  ],
  "mentions": [],
  "effectStickers": [],
  "slideshowImageLinks": []  // 幻灯片/图片类帖子会填充此项
}
```

错误响应（视频已删除或不可用）：
```json
{"error": true, "message": "__UNIVERSAL_DATA_FOR_REHYDRATION__ not found — ensure you are on a TikTok video page"}
```

## 分页

不适用 —— 此能力每个 URL 只提取一条视频。

## 成功判定

`id` 非空、`diggCount >= 0`、`authorMeta.name` 非空、`videoMeta.duration > 0`

## 已知限制

- 需要非香港代理（TikTok 已在中国香港停运）
- 已删除或私密视频会返回错误（SSR 数据中包含非零 statusCode）
- `collectCount` 在 SSR 数据中可能以字符串形式返回 —— 如有需要请用 `parseInt()` 解析
- `authorMeta.heart`（总获赞数）在超大账号上可能被截断；SSR itemStruct 中的 `authorStats.heart` 才是权威来源
- 视频下载地址（`playAddr`、`downloadAddr`）存在于 SSR 数据中但会很快过期 —— 如有需要请立即提取并使用

## 执行效率

- **批量 URL 处理**：编写一个 bash 循环，逐个导航到视频 URL、执行 eval 提取脚本并保存结果。每次导航之间间隔 1–2 秒。
- **批量执行前先测试**：先用 1 个 URL 测试确认脚本可用，再跑完整列表。
- **错误续跑**：逐个 URL 保存结果，出错时从失败的 URL 处继续。

## 经验记录

路径：`{working-directory}/browser-act-skill-forge-memories/tiktok-scraper-tiktok-video-detail.memory.md`

**执行前**：若该文件存在，请先阅读 —— 其中记录了以往执行中遇到的意外情况，据此调整策略。

**执行后**：若发生意外情况（策略失效、页面改版、反爬升级、找到更好的路径），追加一行：
`{YYYY-MM-DD}: {发生了什么} → {结论}`

正常执行不写入该文件。
