# -*- coding: utf-8 -*-
"""
预测问题数据源（单一数据源）
- 供 compact_issues.py 合并时追加
- 也可独立运行：python scripts/predict_issues.py --csv out.csv
每条必须包含 6 个字段：问题描述 / 类型 / 根本原因 / 解决方案 / 备注 / 是否已修复
"""

PREDICT_ISSUES = [
    # ── 原有 10 条 ──────────────────────────────────────────────
    {
        "问题描述": "WebDriver 版本不匹配导致浏览器自动化失败",
        "类型": "环境问题",
        "根本原因": "Chrome/Edge 自动更新后，chromedriver/edgedriver 版本与浏览器不一致，Selenium/Playwright 报错 'session not created'",
        "解决方案": "用 webdriver-manager 自动管理驱动版本（pip install webdriver-manager）；固定浏览器版本关闭自动更新；定期更新驱动",
        "备注": "常见于 Windows Chrome 用户",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "pypi 镜像源连接超时导致 pip install 失败",
        "类型": "环境问题",
        "根本原因": "清华/阿里云等国内镜像源偶发网络波动或维护，返回连接超时或 443 错误",
        "解决方案": "配置多镜像源备用：-i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn；失败时换阿里云镜像或官方源",
        "备注": "建议命令中同时指定 trusted-host",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "HTML 混合大小写标签导致页面渲染异常",
        "类型": "代码问题",
        "根本原因": "AI 生成的 HTML 中大小写混用（如 <DIV> 和 </div>），不同浏览器解析行为不一致，部分元素丢失",
        "解决方案": "统一使用小写标签；用 HTML 验证工具（如 htmlhint）检查；多浏览器测试验证",
        "备注": "HTML5 规范要求小写，但浏览器容错导致问题隐蔽",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "URL 路径含中文或空格导致浏览器打不开文件",
        "类型": "代码问题",
        "根本原因": "本地文件路径含中文或空格，直接用 file:// 打开时路径未做 URL 编码，空格被截断",
        "解决方案": "用 urllib.parse.quote() 对路径做 URL 编码；或统一用下划线/拼音命名避免中文；启动本地 HTTP 服务器访问",
        "备注": "file:// 协议对中文和空格敏感",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "GitHub API 请求超出速率限制（403/429）",
        "类型": "环境问题",
        "根本原因": "未认证 GitHub API 每小时 60 次限制；高频请求后被限流，返回 403/429",
        "解决方案": "加请求间隔（time.sleep）；用 GITHUB_TOKEN 环境变量认证（5000次/小时）；超出限制时等待重试；用 GitHub 镜像做只读查询",
        "备注": "免费账户限速严格，批量操作要注意",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "JSON 数据含 NaN/Inf 导致 json.dumps 报错",
        "类型": "代码问题",
        "根本原因": "numpy.float64('nan')、math.inf 等不是标准 JSON 类型，json.dumps 直接报错",
        "解决方案": "用自定义 JSON encoder 处理 NaN→null、Inf→'Infinity'；或预先用 round(x, 10) 截断；在 API 返回前过滤异常数值",
        "备注": "numpy 数据传给前端 API 时常见",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "WPS 和 Office 格式兼容性问题",
        "类型": "兼容性问题",
        "根本原因": "WPS 生成的 .docx/.xlsx 在 Office 中样式错位；两者对 OOXML 标准实现有细微差异",
        "解决方案": "优先用 .doc/.xls 兼容模式；导出时另存为对方格式；避免特殊宏和嵌入对象；双软件测试",
        "备注": "重要文档建议同时在两个软件中测试",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "Playwright/Selenium 找不到下拉框选项（select 元素）",
        "类型": "代码问题",
        "根本原因": "页面加载异步，元素还没渲染就查找；选项被 disabled；或用了 div 模拟而非标准 select",
        "解决方案": "用 page.waitForSelector 等待元素；用 selectByLabel/text 而非 value；检查是否在 iframe 内",
        "备注": "动态加载页面常见问题",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "Windows Store 版 Node.js 导致命令找不到",
        "类型": "环境问题",
        "根本原因": "从 Microsoft Store 安装的 Node.js 路径在 PATH 中指向 Store 应用包装器，实际 node.exe 路径不同",
        "解决方案": "从 nodejs.org 官网下载 LTS 安装包重新安装，覆盖 Store 版；验证：node -v",
        "备注": "Windows 11 有时自动推送 Store 版 Node.js",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "CSS z-index 层叠冲突导致元素被遮挡",
        "类型": "代码问题",
        "根本原因": "多个模块/弹窗的 z-index 未统一基准，父容器和子元素 z-index 独立导致层叠混乱",
        "解决方案": "统一页面级 z-index 基准（如最大 1000）；用 CSS 变量管理层级；重要弹窗用更高值并设父容器 position:relative",
        "备注": "多模块页面和弹窗叠加时常见",
        "是否已修复": "预防建议",
    },

    # ── 新增 20 条 ──────────────────────────────────────────────
    {
        "问题描述": "pip 安装后 PowerShell 找不到命令（命令行报 '不是内部或外部命令'）",
        "类型": "环境问题",
        "根本原因": "pip 把包装到了用户级 Scripts 目录，但该目录不在 PATH 中；或安装后未重开终端，PATH 未刷新",
        "解决方案": "重开 PowerShell 让 PATH 生效；或用 python -m pip 调用；或将 Scripts 目录加入系统 PATH；推荐用 python -m 前缀避免歧义",
        "备注": "Windows 下优先用 python -m pip install xxx",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "ModuleNotFoundError: No module named 'cv2'（OpenCV 导入失败）",
        "类型": "代码问题",
        "根本原因": "OpenCV 的 PyPI 包名是 opencv-python，不是 cv2；import 名和安装名不一致导致混淆",
        "解决方案": "执行 pip install opencv-python（不是 pip install cv2）；代码中仍用 import cv2",
        "备注": "常见新手坑，安装名与导入名不同",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "IndentationError: unexpected indent（缩进混用 Tab 和空格）",
        "类型": "代码问题",
        "根本原因": "编辑器同时用了 Tab 和空格缩进，Python 不允许混用，解析时缩进层级错乱",
        "解决方案": "在编辑器里开启『显示空白字符』，统一设为 4 个空格；用编辑器的『将 Tab 转为空格』功能；VSCode 右下角可切换",
        "备注": "团队协作时统一 .editorconfig 可避免",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "JSON 文件格式错误导致 json.load 失败（末尾缺逗号/多余逗号/编码问题）",
        "类型": "代码问题",
        "根本原因": "手工编辑 JSON 时漏写逗号、末尾多逗号，或文件含 BOM 头、非 UTF-8 编码，json.load 直接抛 JSONDecodeError",
        "解决方案": "用 json.tool 校验：python -m json.tool file.json；保存时选 UTF-8 无 BOM；避免手改大 JSON，改用程序生成",
        "备注": "BOM 头会让解析在第一行报错",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "UnicodeDecodeError: 'gbk' codec can't decode byte（读文件乱码）",
        "类型": "代码问题",
        "根本原因": "Windows 默认用 GBK 读文本，但文件实际是 UTF-8，遇到非 GBK 字符就解码失败",
        "解决方案": "open(path, encoding='utf-8') 显式指定编码；批量处理用 errors='replace' 兜底；统一文件保存为 UTF-8",
        "备注": "跨平台传文件时最容易出现",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "浏览器 CORS 跨域错误（Access-Control-Allow-Origin 缺失）",
        "类型": "代码问题",
        "根本原因": "前端 fetch 本地后端（如 localhost:3000 调 localhost:5000）属于跨域，后端未返回 CORS 头被浏览器拦截",
        "解决方案": "后端加 CORS 中间件（Flask: flask-cors；Node: cors 包）；开发期可用 Vite/Webpack 代理；不要用 file:// 直接打开前端",
        "备注": "file:// 协议没有 origin，调试 API 时更易踩坑",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "ImportError: No module named 'requests'（未装 requests 就 import）",
        "类型": "代码问题",
        "根本原因": "requests 不是 Python 标准库，需单独 pip install；有些环境自带 urllib 但没有 requests",
        "解决方案": "pip install requests；若不想装第三方库，用标准库 urllib.request 替代",
        "备注": "标准库够用时优先用 urllib，减少依赖",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "NameError: name 'x' is not defined（函数内修改全局变量未声明 global）",
        "类型": "代码问题",
        "根本原因": "在函数内给全局变量赋值会被当成新建局部变量，若之前又读取它就会报未定义；需显式声明 global",
        "解决方案": "在函数开头写 global x；或更推荐把变量作为参数传入、返回值传出，避免依赖全局状态",
        "备注": "尽量用函数参数/返回值代替全局变量",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "CSS flex 布局子元素溢出或不换行",
        "类型": "代码问题",
        "根本原因": "flex 子项默认 min-width:auto 不会收缩到内容以下，长内容会撑破容器；或父容器没设 flex-wrap:wrap 导致不换行",
        "解决方案": "给子项加 min-width:0 允许收缩；需要换行时父容器加 flex-wrap:wrap；限制宽度用 max-width 而非 width",
        "备注": "文字/图片溢出 flex 容器时第一反应加 min-width:0",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "TypeError: 'NoneType' object is not subscriptable（对 None 取下标）",
        "类型": "代码问题",
        "根本原因": "某函数本应返回列表/字典却返回了 None（如忘记 return、或条件分支漏返回），下游再对它 [] 或 .get() 就报错",
        "解决方案": "检查该函数所有分支都有 return；调用处加 if result is None 兜底；用断言或日志确认返回值",
        "备注": "常伴随『函数只写了 pass』类问题",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "Windows 路径反斜杠在 Python 字符串中被转义（\\n \\t 等）",
        "类型": "代码问题",
        "根本原因": "Windows 路径用反斜杠 C:\\Users\\x，但 \\U \\x 在 Python 字符串里是转义序列，路径被错误解析",
        "解决方案": "用原始字符串 r'C:\\Users\\x'；或改用正斜杠 'C:/Users/x'（Python 接受）；或用 pathlib.Path 拼路径",
        "备注": "pathlib 跨平台最省心",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "KeyError: 'xxx'（访问字典不存在的键）",
        "类型": "代码问题",
        "根本原因": "用 data['key'] 取值但键不存在；常见于解析 JSON/接口返回时字段名拼写或大小写不一致",
        "解决方案": "改用 data.get('key', 默认值) 提供兜底；或先用 if 'key' in data 判断；解析接口返回时打印完整结构确认字段名",
        "备注": "接口字段变动是高频诱因",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "端口被占用导致服务启动失败（Address already in use）",
        "类型": "环境问题",
        "根本原因": "上一次运行的进程没完全退出，仍占用 3000/5000/8080 等端口，新进程绑定失败",
        "解决方案": "换端口或杀掉占用进程：Windows 用 netstat -ano | findstr :3000 找 PID 再 taskkill /PID x /F；开发期用热重载避免反复启停",
        "备注": "Ctrl+C 没杀干净时最容易出现",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "SyntaxError: invalid character（中文标点混入代码）",
        "类型": "代码问题",
        "根本原因": "从网页/聊天复制代码时，全角括号、全角逗号、中文引号混进了 Python/JS 源码，解释器无法识别",
        "解决方案": "把全角符号（（），。；『』）换成半角；复制代码后粘贴到编辑器并检查红色波浪线；用 IDE 的 lint 及时发现",
        "备注": "微信/网页复制代码的高频坑",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "JavaScript 用 let/const 重复声明同名变量报错",
        "类型": "代码问题",
        "根本原因": "在同一作用域用 let/const 重复声明同一变量（或和函数参数重名），JS 引擎报 Identifier 'x' has already been declared",
        "解决方案": "给变量改不同名字；或合并声明；确认作用域层级；避免全局和局部同名",
        "备注": "和 var 不同，let/const 不允许重复声明",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "ValueError: could not convert string to float（脏数据转换失败）",
        "类型": "代码问题",
        "根本原因": "从 CSV/输入框读到的字符串含空值、逗号千位符、百分号或中文，float() 无法解析",
        "解决方案": "转换前先清洗：s.strip().replace(',', '').replace('%', '')；用 try/except 跳过脏数据；用 pandas 的 to_numeric(errors='coerce')",
        "备注": "处理用户上传的 Excel/CSV 时必踩",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "Git 提交出现 'LF will be replaced by CRLF' 警告",
        "类型": "环境问题",
        "根本原因": "Windows 用 CRLF、Linux/Mac 用 LF，Git 的 autocrlf 配置不一致，提交时自动转换并提示",
        "解决方案": "统一配置：Windows 设 git config --global core.autocrlf true，团队其他人设 input；或在仓库加 .gitattributes 锁定换行符",
        "备注": "跨平台协作的换行符经典坑",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "RecursionError: maximum recursion depth exceeded（递归无终止）",
        "类型": "代码问题",
        "根本原因": "递归函数忘记写终止条件，或终止条件永远不满足，调用栈无限增长直到超过默认上限（1000）",
        "解决方案": "检查 base case 是否正确且可达；把深层递归改写为循环；必要时 sys.setrecursionlimit 提高上限（治标不治本）",
        "备注": "树/链表/分治递归最易漏 base case",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "CSS position: fixed 在带 transform 的父元素内失效",
        "类型": "代码问题",
        "根本原因": "CSS 规范规定：祖先元素有 transform/filter/perspective 时，fixed 会相对该祖先定位而非视口，导致『钉不住』",
        "解决方案": "把 fixed 元素移出带 transform 的容器；或改用 position:sticky；或去掉祖先的 transform（用其他方式实现动画）",
        "备注": "弹窗/吸顶导航常踩这个隐坑",
        "是否已修复": "预防建议",
    },
    {
        "问题描述": "Python 列表浅拷贝导致两个变量互相影响",
        "类型": "代码问题",
        "根本原因": "用 list2 = list1 只是让两个变量指向同一对象，改一个另一个也变；嵌套列表的 copy() 也只是浅拷贝",
        "解决方案": "用 list1.copy() 或 list(list1) 做浅拷贝；嵌套结构用 copy.deepcopy；明确区分『赋值』和『拷贝』",
        "备注": "改了 A 发现 B 也变了，八成是浅拷贝",
        "是否已修复": "预防建议",
    },
]


def main():
    import argparse
    import csv
    import os

    parser = argparse.ArgumentParser(description="导出预测问题列表")
    parser.add_argument("--csv", help="输出 CSV 路径（默认打印到控制台）")
    args = parser.parse_args()

    cols = ["问题描述", "类型", "根本原因", "解决方案", "备注", "是否已修复"]

    if args.csv:
        os.makedirs(os.path.dirname(os.path.abspath(args.csv)) or ".", exist_ok=True)
        with open(args.csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            w.writerows(PREDICT_ISSUES)
        print(f"已导出 {len(PREDICT_ISSUES)} 条到 {args.csv}")
    else:
        for i, it in enumerate(PREDICT_ISSUES, 1):
            print(f"{i:2d}. [{it['类型']}] {it['问题描述']}")


if __name__ == "__main__":
    main()
