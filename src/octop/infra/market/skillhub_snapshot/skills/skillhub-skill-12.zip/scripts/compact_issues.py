"""
issue-log-compactor
将多个问题记录 CSV 去重融合，补全根因和解决方案，追加预测问题。
用法:
  python compact_issues.py --files "f1.csv","f2.csv" --output "out.csv"
"""
import argparse
import csv
import os
import re
import sys


# ── 导入预测问题（单一数据源：scripts/predict_issues.py）────────────────────
import sys as _sys
import os as _os

_script_dir = _os.path.dirname(_os.path.abspath(__file__))
_sys.path.insert(0, _os.path.join(_script_dir, "scripts"))
try:
    from predict_issues import PREDICT_ISSUES
except Exception as _e:  # pragma: no cover
    print(f"[警告] 无法加载预测问题模块: {_e}", file=_sys.stderr)
    PREDICT_ISSUES = []


# ── 辅助函数 ────────────────────────────────────────────────────────────────

def nv(d, k):
    """取字典值，安全处理 None。"""
    v = d.get(k) or ""
    if v is None:
        v = ""
    return v.strip() if isinstance(v, str) else str(v).strip()


def has_content(item):
    return bool(item["问题描述"] or item["根本原因"] or item["解决方案"])


# ── 字段归一化映射 ─────────────────────────────────────────────────────────

FIELD_MAP = {
    "问题编号": "问题描述",
    "问题现象": "问题描述",
    "根本原因": "根本原因",
    "根因": "根本原因",
    "原因": "根本原因",
    "错误现象": "问题描述",
    "错误信息": "问题描述",
    "解决方案": "解决方案",
    "解决方法": "解决方案",
    "类型": "类型",
    "问题类型": "类型",
    "工具/语言": "类型",
    "备注": "备注",
    "是否已修复": "是否已修复",
    "影响范围": "备注",
    "影响文件/位置": "备注",
    "场景": "备注",
    "根因分析": "根本原因",
}


def normalize_record(raw: dict) -> dict:
    out = {"问题描述": "", "类型": "", "根本原因": "", "解决方案": "", "备注": "", "是否已修复": ""}
    for orig, std in FIELD_MAP.items():
        if std in out and nv(raw, orig):
            out[std] = nv(raw, orig)
    out["_src"] = nv(raw, "_src")
    return out


# ── 已知重复组（正则 → 合并后的标准化描述）──────────────────────────────────

DUP_PATTERNS = [
    # PowerShell && 不兼容 CMD/Shell 语法
    re.compile(r"&&|\|\||；.*&&|&amp;&amp;"),
    # Python/QClaw 程序路径过时
    re.compile(r"0\.2\.33|0\.2\.35|QClaw.*python"),
    # edit 工具 oldText 匹配失败
    re.compile(r"oldText.*匹配|匹配.*oldText"),
    # PowerShell 路径含空格
    re.compile(r"路径.*空格|空格.*路径"),
    # BOM 头导致解析失败
    re.compile(r"BOM|utf-8-sig"),
    # Python 依赖缺失
    re.compile(r"ModuleNotFoundError|pip.*install|缺少.*依赖"),
    # 429 限流
    re.compile(r"429|限流|rate.limit", re.I),
    # 图片 404
    re.compile(r"404|英雄.*卡片|src.*错误"),
]


def which_dup_group(desc: str) -> int | None:
    """返回匹配的重复组编号（0起），无匹配返回 None。"""
    for i, pat in enumerate(DUP_PATTERNS):
        if pat.search(desc):
            return i
    return None


def norm_key(s: str) -> str:
    """归一化关键词（去除标点空格，保留数字）"""
    s = s.lower()
    s = re.sub(r'[\s\.,;:!?，。；：！？\-\(\)\[\]（）、"\/\\\|\'"'']', '', s)
    return s[:60]


# ── 自动补全规则 ────────────────────────────────────────────────────────────

CAUSE_PATTERNS = [
    (re.compile(r"solve_ode_adams", re.I),
     "return 语句返回 3 个值 xs, ys[:n+1], ys[:n+1]，但函数签名只声明返回 2 个值，调用方解包报错"),
    (re.compile(r"walrus|:=.*invalid.escape", re.I),
     "非标准转义序列（如 \\p）在普通字符串中非法；部分 Python 环境不支持海象运算符 :="),
    (re.compile(r"zeeman", re.I),
     "AI 生成函数名时在 def 和函数名之间误加了空格，Python 不允许函数名含空格"),
    (re.compile(r"defPage_rank|defpage", re.I),
     "AI 生成时在 def 关键字后又误写了 def 前缀，导致 def defPage_rank 语法错误"),
    (re.compile(r"bessel.?Neumann|bessel_sum", re.I),
     "AI 生成函数名时中间误加了空格，函数名不能有空格"),
    (re.compile(r"PowerShell.*stdin|stdin.*PowerShell|管道.*编码|编码.*管道", re.I),
     "PowerShell 管道输入时内容按系统默认编码（GBK/ANSI）传给 Python stdin，而非 UTF-8，导致中文被错误解析"),
    (re.compile(r"PowerShell.*stdout|stdout.*重定向|重定向.*乱码", re.I),
     "PowerShell 用系统默认编码（GBK）写文件，Python 输出的 UTF-8 字节被错误解析成乱码"),
    (re.compile(r"429|限流|rate.limit", re.I),
     "请求频率过高触发目标服务器限流；网络偶发超时"),
    (re.compile(r"图片.*404|英雄卡片|404.*图片", re.I),
     "卡片或图片的 src 路径指向不存在的文件，或文件名拼写错误"),
    (re.compile(r"math\.sec|math\.csc|sec.*不存在|csc.*不存在", re.I),
     "Python math 标准库不包含 sec/csc 函数（只有 sin/cos/tan 及其反函数）"),
    (re.compile(r"divergence.*空|函数体只有.pass|未实现.*散度", re.I),
     "函数体只有 pass 或注释，实际计算逻辑未实现，调用返回 None"),
    (re.compile(r"Chernoff|delta.*遮蔽|生成器.*delta", re.I),
     "列表推导式中变量遮蔽外层函数参数，导致公式计算逻辑错误"),
]

SOL_PATTERNS = [
    (re.compile(r"solve_ode_adams", re.I),
     "修正 return 为 return xs, ys（去掉重复的第二个返回值），或将第二个改为 xs[n+1:]"),
    (re.compile(r"walrus|:=.*invalid.escape", re.I),
     "海象运算符改回普通赋值；非标准转义用 raw string (r'...') 或转义 \\"),
    (re.compile(r"zeeman", re.I),
     "函数重命名为 zeeman_splitting；修复对应元组拆包错误"),
    (re.compile(r"defPage_rank|defpage", re.I),
     "函数重命名为 page_rank，去掉多余 def 前缀"),
    (re.compile(r"bessel.?Neumann|bessel_sum", re.I),
     "函数重命名为 bessel_Neumann_sum"),
    (re.compile(r"PowerShell.*stdin|stdin.*PowerShell|管道.*编码|编码.*管道", re.I),
     "给 Python 脚本加 sys.stdin.reconfigure(encoding='utf-8')；或直接调用函数而非用管道喂输入"),
    (re.compile(r"PowerShell.*stdout|stdout.*重定向|重定向.*乱码", re.I),
     "让 Python 脚本直接用 with open(file, 'w', encoding='utf-8') 写文件，不要依赖 shell 重定向"),
    (re.compile(r"429|限流|rate.limit", re.I),
     "降低请求频率，加 time.sleep 限速；超时时加重试机制；备用来源"),
    (re.compile(r"图片.*404|英雄卡片|404.*图片", re.I),
     "改为正确的文件路径；写脚本校验所有引用文件存在且服务器返回 200"),
    (re.compile(r"math\.sec|sec.*不存在", re.I),
     "改为 1/math.cos(x) 或导入 mpmath；在 calculus.py 导入区加 try/except"),
    (re.compile(r"math\.csc|csc.*不存在", re.I),
     "改为 1/math.sin(x) 或导入 mpmath；在 calculus.py 导入区加 try/except"),
    (re.compile(r"divergence.*空|未实现.*散度", re.I),
     "实现散度计算：∂Fx/∂x + ∂Fy/∂y + ∂Fz/∂z，按给定维数计算偏导数"),
    (re.compile(r"Chernoff|delta.*遮蔽", re.I),
     "生成器改为 for d in [delta] 或直接写 2 * math.exp(-n * delta**2 / 2)，去掉 min 和遮蔽变量"),
    (re.compile(r"numpy.*int64|int64.*serializable|JSON.*int64", re.I),
     "扩展 _to_list()：加 np.integer→int、np.floating→float、np.bool_→bool；对 dict 递归处理"),
]


def fill_missing(item: dict):
    d = item["问题描述"]
    if not d:
        return
    if not item["根本原因"]:
        for pat, cause in CAUSE_PATTERNS:
            if pat.search(d):
                item["根本原因"] = cause
                break
    if not item["解决方案"]:
        for pat, sol in SOL_PATTERNS:
            if pat.search(d):
                item["解决方案"] = sol
                break


# ── 去重 ────────────────────────────────────────────────────────────────────

def merge_items(keep: dict, add: dict):
    for k in ["根本原因", "解决方案", "备注"]:
        if not keep.get(k) and add.get(k):
            keep[k] = add[k]
        elif keep.get(k) and add.get(k) and add[k] not in keep[k]:
            keep[k] = keep[k] + "；" + add[k]
    srcs = set(keep.get("_src", "").split(" / "))
    for s in add.get("_src", "").split(" / "):
        if s:
            srcs.add(s)
    keep["_src"] = " / ".join(sorted(srcs))
    return keep


def deduplicate(items: list) -> list:
    """
    两阶段去重：
    1. 已知重复组：描述匹配同一正则 → 合并
    2. 关键词相似：归一化后前30字符相同 → 合并
    """
    # 阶段1：按重复组编号分桶
    groups: dict[int, list] = {}
    orphans: list = []
    for item in items:
        g = which_dup_group(item["问题描述"])
        if g is not None:
            groups.setdefault(g, []).append(item)
        else:
            orphans.append(item)

    merged = []
    for g, bucket in groups.items():
        if len(bucket) == 1:
            merged.append(bucket[0])
        else:
            base = bucket[0]
            for item in bucket[1:]:
                merge_items(base, item)
            merged.append(base)

    # 阶段2：余项按归一化关键词去重（前30字符）
    key_map: dict[str, dict] = {}
    for item in orphans:
        k = norm_key(item["问题描述"])
        if not k:
            merged.append(item)
            continue
        prefix = k[:30]
        if prefix not in key_map:
            key_map[prefix] = item
        else:
            key_map[prefix] = merge_items(key_map[prefix], item)
    merged.extend(key_map.values())
    return merged


# ── 主程序 ──────────────────────────────────────────────────────────────────

def read_csv(path: str) -> list:
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: str, items: list):
    cols = ["问题描述", "类型", "根本原因", "解决方案", "备注", "是否已修复"]
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(items)


def main(argv=None):
    parser = argparse.ArgumentParser(description="问题记录去重融合工具")
    parser.add_argument("--files", "-f", required=True,
                        help="逗号分隔的 CSV 文件路径")
    parser.add_argument("--output", "-o",
                        help="输出文件路径（默认：第一个文件目录下 问题汇总_去重合并.csv）")
    args = parser.parse_args(argv)

    paths = [p.strip().strip('"') for p in args.files.split(",") if p.strip()]
    missing = [p for p in paths if not os.path.exists(p)]
    if missing:
        print("\n[错误] 以下文件不存在，请检查路径（注意：路径含空格时需用引号包裹，或用 \\ 转义）：", file=sys.stderr)
        for p in missing:
            print(f"   - {p}", file=sys.stderr)
        print("\n提示：", file=sys.stderr)
        print("   1) 确认文件真实路径，例如：C:\\Users\\Administrator\\Desktop\\问题.csv", file=sys.stderr)
        print("   2) 路径含空格时务必用双引号：\"C:\\我的文件\\a.csv\"", file=sys.stderr)
        print("   3) 可用 dir /b \\*.csv 列出当前目录的 CSV 文件名\n", file=sys.stderr)
        sys.exit(2)

    all_raw = []
    for path in paths:
        try:
            rows = read_csv(path)
        except Exception as e:
            print(f"[错误] 读取失败 {path}: {e}", file=sys.stderr)
            sys.exit(3)
        src = os.path.basename(path)
        for r in rows:
            r["_src"] = src
        print(f"[OK] {src}: {len(rows)} 条")
        all_raw.extend(rows)

    if not all_raw:
        print("\n[错误] 没有可处理的数据。请确认 CSV 文件包含表头行（如 问题描述,类型,根本原因,解决方案,备注,是否已修复）。", file=sys.stderr)
        sys.exit(1)

    normalized = [normalize_record(r) for r in all_raw]
    normalized = [r for r in normalized if has_content(r)]
    print(f"有效记录: {len(normalized)} 条")

    unique = deduplicate(normalized)
    print(f"去重后: {len(unique)} 条")

    for item in unique:
        fill_missing(item)

    for pi in PREDICT_ISSUES:
        pi["_src"] = "预测追加"
    unique.extend(PREDICT_ISSUES)

    if args.output:
        out_path = args.output
    else:
        out_dir = os.path.dirname(paths[0]) or "."
        out_path = os.path.join(out_dir, "问题汇总_去重合并.csv")

    write_csv(out_path, unique)
    print(f"\n已保存: {out_path}")
    print(f"共 {len(unique)} 条（含 {len(PREDICT_ISSUES)} 条预测问题）")


if __name__ == "__main__":
    main()
