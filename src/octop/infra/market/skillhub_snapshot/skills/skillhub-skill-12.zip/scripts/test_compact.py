# -*- coding: utf-8 -*-
"""
issue-log-compactor 测试套件
运行方式（任选其一）：
  python tests/test_compact.py        # 无需 pytest，直接跑
  pytest tests/test_compact.py        # 用 pytest 跑（会显示更详细报告）
"""
import os
import sys
import csv
import tempfile

# 把脚本目录加入 path，便于 import
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import compact_issues as ci
from predict_issues import PREDICT_ISSUES


def _mk(desc="", typ="", cause="", sol="", note="", fixed=""):
    return {
        "问题描述": desc, "类型": typ, "根本原因": cause,
        "解决方案": sol, "备注": note, "是否已修复": fixed, "_src": "test",
    }


# ── 1. 字段归一化：异源字段名映射正确 ──────────────────────────────────────
def test_field_normalize():
    raw = {
        "问题编号": "P001",          # → 问题描述
        "根因分析": "根因内容",       # → 根本原因
        "解决方法": "解决内容",       # → 解决方案
        "工具/语言": "Python",        # → 类型
        "影响文件/位置": "a.py",      # → 备注
        "是否已修复": "是",
        "_src": "x.csv",
    }
    out = ci.normalize_record(raw)
    assert out["问题描述"] == "P001"
    assert out["根本原因"] == "根因内容"
    assert out["解决方案"] == "解决内容"
    assert out["类型"] == "Python"
    assert out["备注"] == "a.py"
    assert out["是否已修复"] == "是"
    print("[PASS] test_field_normalize")


# ── 2. 去重：同一重复组的正则匹配条目应合并 ────────────────────────────────
def test_dedup_same_group():
    items = [
        _mk(desc="用 && 拼接命令在 PowerShell 里不兼容", cause="A"),
        _mk(desc="CMD 和 Shell 的 && 语法在 PowerShell 失败", sol="B"),
    ]
    res = ci.deduplicate(items)
    assert len(res) == 1, f"期望合并为 1 条，实际 {len(res)}"
    assert res[0]["根本原因"] and res[0]["解决方案"], "合并后应补全双方字段"
    print("[PASS] test_dedup_same_group")


# ── 3. 去重：不同问题不应被误合并 ──────────────────────────────────────────
def test_dedup_no_false_merge():
    items = [
        _mk(desc="pip 安装后命令找不到", cause="PATH 未刷新"),
        _mk(desc="JSON 含 NaN 导致 dumps 报错", cause="非标准类型"),
        _mk(desc="CORS 跨域被浏览器拦截", cause="缺 CORS 头"),
        _mk(desc="UnicodeDecodeError 读文件乱码", cause="GBK 读 UTF-8"),
    ]
    res = ci.deduplicate(items)
    assert len(res) == 4, f"不同问题不应合并，实际 {len(res)}"
    print("[PASS] test_dedup_no_false_merge")


# ── 4. 自动补全：根据关键词推断根因/解决方案 ───────────────────────────────
def test_fill_missing():
    item = _mk(desc="函数 solve_ode_adams 返回 3 个值但签名只声明 2 个")
    ci.fill_missing(item)
    assert item["根本原因"], "应自动补根本原因"
    assert item["解决方案"], "应自动补解决方案"
    assert "return xs, ys" in item["解决方案"]
    print("[PASS] test_fill_missing")


# ── 5. 输出格式：生成合法 6 列 CSV ─────────────────────────────────────────
def test_output_csv_format():
    items = [
        _mk(desc="测试问题一", cause="c1", sol="s1", typ="代码问题"),
        _mk(desc="测试问题二", cause="c2", sol="s2", typ="环境问题"),
    ]
    fd, path = tempfile.mkstemp(suffix=".csv", prefix="compact_test_")
    os.close(fd)
    try:
        ci.write_csv(path, items)
        with open(path, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 2
        for r in rows:
            assert set(["问题描述", "类型", "根本原因", "解决方案", "备注", "是否已修复"]) <= set(r.keys())
            assert r["问题描述"] and r["根本原因"] and r["解决方案"]
    finally:
        os.remove(path)
    print("[PASS] test_output_csv_format")


# ── 6. 预测问题数据源：数量与字段完整性 ────────────────────────────────────
def test_predict_issues():
    assert len(PREDICT_ISSUES) == 30, f"应有 30 条预测问题，实际 {len(PREDICT_ISSUES)}"
    req = ["问题描述", "类型", "根本原因", "解决方案", "备注", "是否已修复"]
    for it in PREDICT_ISSUES:
        for k in req:
            assert it.get(k), f"预测问题缺字段 {k}: {it.get('问题描述')}"
        assert it["是否已修复"] == "预防建议"
    # 描述不应重复
    descs = [it["问题描述"] for it in PREDICT_ISSUES]
    assert len(descs) == len(set(descs)), "预测问题描述不应重复"
    print("[PASS] test_predict_issues")


# ── 7. 端到端：合并真实样例文件（若存在）────────────────────────────────────
def test_end_to_end():
    s1 = os.path.join(ROOT, "examples", "sample_input.csv")
    s2 = os.path.join(ROOT, "examples", "sample_input_alt.csv")
    if not (os.path.exists(s1) and os.path.exists(s2)):
        print("[SKIP] test_end_to_end（示例文件不存在）")
        return
    fd, out = tempfile.mkstemp(suffix=".csv", prefix="compact_e2e_")
    os.close(fd)
    try:
        ci.main(argv=[
            "--files", f"{s1},{s2}",
            "--output", out,
        ])
        with open(out, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        # 两个文件共 7 条；其中 2 条 && 命令问题应合并为 1 条 → 6 条 + 30 预测 = 36
        assert len(rows) == 36, f"期望 36 条（6 条真实 + 30 预测），实际 {len(rows)}"
        # 验证 solve_ode_adams 被自动补全
        joined = "\n".join(r["解决方案"] or "" for r in rows)
        assert "return xs, ys" in joined, "solve_ode_adams 应自动补全解决方案"
    finally:
        if os.path.exists(out):
            os.remove(out)
    print("[PASS] test_end_to_end")


def main():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except AssertionError as e:
            print(f"[FAIL] {t.__name__}: {e}")
        except Exception as e:
            print(f"[ERROR] {t.__name__}: {e}")
    print(f"\n结果: {passed}/{len(tests)} 通过")
    sys.exit(0 if passed == len(tests) else 1)


if __name__ == "__main__":
    main()
