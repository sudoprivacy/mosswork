---
name: skillhub-skill-12
description: "将多个问题记录 CSV 去重融合，补全根因和解决方案，追加 30 条预测问题，输出统一汇总表"
---

# issue-log-compactor — 问题记录去重融合

> 将多个来源的问题记录 CSV 去重融合，补全缺失字段，追加 30 条预测类问题，输出统一汇总表。

## 适用场景

- 你从不同渠道（Kimi 会话、故障排查笔记、代码问题记录、网络排查表）积累了多份问题 CSV
- 字段名不统一、有重复、部分缺根因/解决方案
- 想要一份干净、去重、信息完整的汇总表

## 核心能力

1. **多文件读取** — 支持不同字段名的 CSV，自动归一化到 6 个标准列
2. **智能去重** — 按「重复组正则 + 关键词」两阶段去重，同类问题保留最完整的那条
3. **自动补全** — 对描述完整但根因/解决方案缺失的记录，基于关键词推断补全
4. **预测追加** — 末尾追加 30 条常见后续问题（预防建议类），详见下

## 文件结构

```
issue-log-compactor/
├── SKILL.md                  # 本说明
├── compact_issues.py         # 主脚本：融合 + 去重 + 补全 + 追加预测
├── scripts/
│   └── predict_issues.py     # 预测问题单一数据源（30 条），可独立运行
├── tests/
│   └── test_compact.py       # 测试套件（7 项，无需 pytest）
└── examples/
    ├── sample_input.csv          # 标准 6 列格式示例
    ├── sample_input_alt.csv      # 异源字段名格式示例
    ├── sample_output.csv         # 合并后示例输出（可直接打开查看效果）
    └── predict_issues.csv        # 导出的 30 条预测问题
```

## 使用方式

### 基础：合并多个 CSV

```powershell
python "skills/issue-log-compactor/compact_issues.py" `
  --files "C:\xxx\问题1.csv","C:\xxx\问题2.csv","C:\xxx\问题3.csv" `
  --output "C:\xxx\问题汇总_去重合并.csv"
```

### 路径含空格 / 中文（必须用双引号包裹）

```powershell
python "skills/issue-log-compactor/compact_issues.py" `
  --files "D:\我的文件\问题1.csv","D:\我的文件\问题2.csv" `
  --output "D:\我的文件\问题汇总_去重合并.csv"
```

### 单文件：输出到同目录

省略 `--output` 时，自动输出到第一个文件所在目录下的 `问题汇总_去重合并.csv`：

```powershell
python "skills/issue-log-compactor/compact_issues.py" --files "C:\xxx\问题.csv"
```

### 只查看 / 导出预测问题

```powershell
# 控制台列出 30 条
python "skills/issue-log-compactor/scripts/predict_issues.py"
# 导出为 CSV
python "skills/issue-log-compactor/scripts/predict_issues.py" --csv "D:\预测问题.csv"
```

### 跑测试（验证工具本身没问题）

```powershell
python "skills/issue-log-compactor/tests/test_compact.py"
# 或： pytest "skills/issue-log-compactor/tests/test_compact.py"
```

## 输入要求

CSV 文件需包含表头，字段名可以是以下任意一种（自动识别并归一化）：

| 原始字段名 | 映射到标准列 |
|-----------|------|
| 问题描述 / 问题现象 / 问题编号 / 错误现象 / 错误信息 | 问题描述 |
| 类型 / 问题类型 / 工具/语言 | 类型 |
| 根本原因 / 根因 / 原因 / 根因分析 | 根本原因 |
| 解决方案 / 解决方法 | 解决方案 |
| 备注 / 影响范围 / 影响文件/位置 / 场景 | 备注 |
| 是否已修复 | 是否已修复 |

> 编码：输入支持 `utf-8-sig`（带 BOM，Excel 导出常见）和 `utf-8`；输出固定 `utf-8-sig`，Excel 直接双击不乱码。

## 输出格式

列固定为 6 列：

```
问题描述,类型,根本原因,解决方案,备注,是否已修复
```

## 去重规则（保守策略，避免误删）

去分两阶段，宁可少合并也不错删：

1. **重复组正则** — 描述命中同一已知模式（如下）即视为同类，合并并补全字段
2. **关键词相似** — 归一化（去标点空格）后前 30 字符相同才合并

已知重复组（持续扩充）：

| 模式 | 典型表现 |
|------|---------|
| PowerShell && 不兼容 | PowerShell 不支持 CMD 的 `&&`/`\|` 链式语法 |
| Python 路径过时 | QClaw/Python 程序路径 `v0.2.33` → `v0.2.35` 变更 |
| edit 工具 oldText 匹配 | oldText 无法精确匹配含特殊字符的代码 |
| PowerShell 空格路径 | 路径含空格导致命令参数传递错误 |
| BOM 头问题 | 文件 BOM 头 / GBK 编码导致 JSON 解析失败 |
| Python 依赖缺失 | `ModuleNotFoundError`、缺少 `pip install` 的库 |
| 429 限流 | 请求频率过高触发服务器限流 |
| 图片 404 | 资源引用路径错误 / 文件不存在 |

## FAQ

**Q：合并后条数和我预期的不一样？**
A：去重是「保守策略」——只有命中重复组正则、或归一化前 30 字符完全一致才合并。如果你的两份 CSV 对同一个问题用了差别较大的措辞，不会被自动合并，需要人工判断后补充重复组规则（在 `compact_issues.py` 的 `DUP_PATTERNS` 里加一条正则）。

**Q：提示「文件不存在」？**
A：常见原因：① 路径拼错；② 路径含空格/中文但没用双引号包裹；③ 用了相对路径但当前目录不对。用 `dir /b "*.csv"` 确认真实文件名和位置。

**Q：根因/解决方案是空的是为什么？**
A：自动补全只覆盖内置关键词（如 `solve_ode_adams`、`429`、`BOM` 等）。不在覆盖范围内的，需要你手动补充——这正好是「人工审核」环节。

**Q：预测的 30 条问题我不想加？**
A：在 `compact_issues.py` 里把 `PREDICT_ISSUES` 的引用去掉即可（或把 `scripts/predict_issues.py` 里对应条目注释掉）。它们统一标记为「预防建议」，不影响真实记录。

**Q：字段名我的 CSV 里没有怎么办？**
A：只要「问题描述」这一列有内容即可，其余列缺失会自动留空，再由自动补全规则兜底。

## 预测追加的 30 条问题（预防建议）

完整内容见 `scripts/predict_issues.py` 与 `examples/predict_issues.csv`。概览：

| # | 问题 | 类型 |
|---|------|------|
| 1 | WebDriver 版本不匹配导致浏览器自动化失败 | 环境问题 |
| 2 | pypi 镜像源连接超时导致 pip install 失败 | 环境问题 |
| 3 | HTML 混合大小写标签导致页面渲染异常 | 代码问题 |
| 4 | URL 路径含中文/空格导致浏览器打不开文件 | 代码问题 |
| 5 | GitHub API 请求超出速率限制（403/429） | 环境问题 |
| 6 | JSON 数据含 NaN/Inf 导致 json.dumps 报错 | 代码问题 |
| 7 | WPS 和 Office 格式兼容性问题 | 兼容性问题 |
| 8 | Playwright/Selenium 找不到下拉框选项 | 代码问题 |
| 9 | Windows Store 版 Node.js 导致命令找不到 | 环境问题 |
| 10 | CSS z-index 层叠冲突导致元素被遮挡 | 代码问题 |
| 11 | pip 安装后 PowerShell 找不到命令 | 环境问题 |
| 12 | ModuleNotFoundError: No module named 'cv2' | 代码问题 |
| 13 | IndentationError: 缩进混用 Tab 和空格 | 代码问题 |
| 14 | JSON 文件格式错误导致 json.load 失败 | 代码问题 |
| 15 | UnicodeDecodeError: 'gbk' 读 UTF-8 乱码 | 代码问题 |
| 16 | 浏览器 CORS 跨域错误 | 代码问题 |
| 17 | ImportError: No module named 'requests' | 代码问题 |
| 18 | NameError: 全局变量未声明 global | 代码问题 |
| 19 | CSS flex 子元素溢出或不换行 | 代码问题 |
| 20 | TypeError: 'NoneType' object is not subscriptable | 代码问题 |
| 21 | Windows 路径反斜杠在字符串中被转义 | 代码问题 |
| 22 | KeyError: 访问字典不存在的键 | 代码问题 |
| 23 | 端口被占用导致服务启动失败 | 环境问题 |
| 24 | SyntaxError: 中文标点混入代码 | 代码问题 |
| 25 | JS let/const 重复声明同名变量 | 代码问题 |
| 26 | ValueError: 脏数据转 float 失败 | 代码问题 |
| 27 | Git 提交 'LF will be replaced by CRLF' 警告 | 环境问题 |
| 28 | RecursionError: 递归无终止 | 代码问题 |
| 29 | CSS position: fixed 在 transform 父级失效 | 代码问题 |
| 30 | Python 列表浅拷贝导致变量互相影响 | 代码问题 |
