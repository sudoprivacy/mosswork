---
name: skillhub-skill-h3-cloud-video-factory
description: "在任意云端（AutoDL/恒源云等）或本地 Linux/WSL2 + NVIDIA GPU 部署 MiniMax H3，批量生产「参考视频借动作 + 定妆照换人」的换装视频。内含可直接运行的工作流 JSON 模板、60 秒自检医生、素材预处理、批量 runner、看门狗自愈，从租机/装环境/下模型/配工作流/批量/补帧到交付的完整可复现流程。触发词：H3视频、H3换装、云端跑H3、H3批量出片、MiniMax H3部署、R2V视频换装、角色换衣视频。"
---

# H3 视频工厂（云端/本地通用版）v3.0

> 实战沉淀：AutoDL RTX PRO 6000 96G 全流程跑通，单批 115 支全量出片验证。
> **v3.0 变化**：补齐可直接提交的工作流 JSON 模板 + 60 秒自检医生 + 路径配置化 + 五步出片。

> 💡 **先想清楚再动手**：H3 是 40G 级主模型 + 15G 级编码器的重型工厂。**只做一两条换装视频，直接用 MiniMax 官方 API（7 元/条，1-2 分钟）更划算**；本技能的价值在**批量（50+ 条）、自部署、控成本**——单条试玩请先试官方，别一上来就租机器烧钱。

## 📑 速查目录

| 章 | 内容 | 什么时候看 |
|---|---|---|
| 一 | [选型决策树](#一选型决策树先别急着租机器) | 还没开始，先判断值不值 |
| 二 | [五步出片（端到端）](#二五步出片端到端照抄就能跑) | **第一次用，直接看这章** |
| 三 | [能力边界](#三能力边界能不能做) | 想确认能不能做 |
| 四 | [通用部署步骤](#四通用部署步骤任意平台) | 装环境 |
| 五 | [模型下载](#五模型下载魔搭免翻墙) | 下模型 |
| 六 | [R2V 换装工作流](#六r2v-换装工作流核心) | 配工作流 |
| 七 | [平台对照表](#七平台对照表autodl-vs-其他) | 选云平台 |
| 八 | [批量生产](#八批量生产runner看门狗) | 跑批量 |
| 九 | [错误速查表](#九错误速查表故障排查专用) | **出故障了** |
| 十 | [性能与成本实测](#十性能与成本实测) | 算钱/算时间 |
| 十一 | [省钱与交付](#十一省钱与日常交付) | 日常操作 |
| 十二 | [FAQ](#十二faq选型与效果专用) | 选型/效果类疑问 |

> **导航约定**：出故障查第九章；想问"要不要/能不能/多少钱"查第十二章。两章不重叠。

---

## 一、选型决策树（先别急着租机器）

```
你要做几条换装视频？
│
├─ 1~10 条 ──────────> 用 MiniMax 官方 API（7元/条，1-2分钟，零部署）
│                        ★ 别自部署，环境+模型就要 2 小时
│
├─ 10~50 条 ─────────> 看预算
│   ├─ 不着急、想省钱 ──> 自部署，turbo 4 步（¥0.5-0.8/条）
│   └─ 要快、要省事 ────> 官方 API（¥7/条，总成本 70-350 元）
│
└─ 50 条以上 ────────> 自部署，本技能主场
                        100 条 turbo 4 步 ≈ ¥50-80 机时
                        对比官方 API ≈ ¥700，省 90%
```

| 方案 | 单条成本 | 单条耗时 | 前期投入 | 适合 |
|---|---|---|---|---|
| 官方 API | ¥7 | 1-2 分钟 | 无 | ≤50 条、求快、不想折腾 |
| 自部署满配 20 步 | ≈¥4 | 38 分钟 | 2 小时 + 63G 模型 | 追求质量天花板 |
| 自部署 turbo 8 步 | ≈¥1.5 | 16-18 分钟 | 同上 | 质量/速度甜点 |
| **自部署 turbo 4 步** | **≈¥0.5-0.8** | **8-10 分钟** | 同上 | **批量首选** |

> 成本按 AutoDL RTX PRO 6000（会员 ¥5.98/时）实测折算，8.8s / 768P 竖屏为基准。

---

## 二、五步出片（端到端，照抄就能跑）

> 全程 5 条命令。第 1 步改配置、第 5 步出片，中间交给脚本。

### 第 1 步：改配置文件（唯一需要手工改路径的地方）

```bash
cp h3_config.env my_h3.env
# 编辑 my_h3.env，只改这 5 行，其余保持默认：
#   COMFY_ROOT=/你的/ComfyUI/根目录
#   OUT_DIR=/你的/输出目录
#   STATE_FILE=/你的/断点文件.json
#   VIDEOS_DIR=$COMFY_ROOT/input/videos
#   IMAGES_DIR=$COMFY_ROOT/input
```

> 所有脚本都读这个文件，**任何脚本里都不要再手改路径**。

### 第 2 步：准备素材（裁剪、配对一次性搞定）

```bash
# 视频池 × 定妆照池 随机配对
python h3_prepare_inputs.py --videos ./我的视频 --images ./定妆照 \
    --comfy-input $COMFY_ROOT/input --out pairs.json --pairing random

# 或者：一张定妆照配全部视频
python h3_prepare_inputs.py --videos ./我的视频 --fixed-image cover001.png \
    --comfy-input $COMFY_ROOT/input --out pairs.json
```

这条命令自动做完四件事：**超 15s 的视频裁到 14.2s** → **21:9 多视图拼图裁出中间列** → **实体复制到 ComfyUI/input** → **随机配对生成 pairs.json**。

### 第 3 步：60 秒体检（别跳过）

```bash
python h3_doctor.py --config my_h3.env
```

会依次检查：Python/torch 版本 → GPU 显存 → 磁盘空间 → 4 个模型文件（含 aria2 空壳采样校验）→ ComfyUI 连通性 → **工作流每个节点类型是否在你的 ComfyUI 里注册** → 输入素材合规性。

每项错误都给中文原因 + 可直接复制的修复命令。见到 `体检完成：全部通过` 再进第 4 步。

> ⚠️ **这一步最关键**：它能提前抓出「ComfyUI 版本不对导致 H3 节点不存在」「模型是 aria2 空壳」这两个会让你白等 40 分钟的坑。

### 第 4 步：重启 ComfyUI（新素材必须重启才会被扫描到）

```bash
# 停掉旧的，重新启动（软链不识别，必须实体文件 + 重启）
cd $COMFY_ROOT && python main.py --listen 127.0.0.1 --port 8188
```

### 第 5 步：先跑 1 条验效果，再放开批量

```bash
python h3_runner.py --config my_h3.env --pairs pairs.json --only 1   # 验效果
python h3_runner.py --config my_h3.env --pairs pairs.json            # 全量批量
```

成品在 `OUT_DIR`，断点文件自动记录进度，**中断后重跑会跳过已完成的**。

---

## 三、能力边界（能/不能做什么）

### ✅ 能做什么
- 任意 **Linux + NVIDIA GPU（≥24G 显存，48-96G 最佳）** 部署 MiniMax H3
- **R2V 换装**（已实测）：参考视频借动作/机位/场景 + 定妆照换人换衣 → 出片
- 批量生产：100+ 条无人值守，断点续跑，看门狗自愈
- 出片后补帧 30fps 交付

### ❌ 不能做什么
- **不支持无 NVIDIA GPU 的环境**（Mac / 纯 CPU 不行）
- 显存 <24G 跑不动满配 BF16（可试 int8 + turbo 低显存组合，但会明显变慢）
- 参考视频 **单条最长 15s / 360 帧**（超长必须先裁剪，第 2 步脚本已自动处理）
- 非 ComfyUI 0.33+ 或定制版源码不支持 nvfp4 编码器
- 文本编码器 Qwen3-VL 对**长提示词（>200 字）**支持有限，建议精简

### ⚠️ 未实测声明（不编数据）
- **T2V / I2V（文生视频 / 图生视频）本技能只提供模型清单，不提供工作流模板**——我们只在 R2V 换装场景跑通过 115 支，FL2V 链路未实机验证，避免给你一份跑不通的模板。有需要请自行从 ComfyUI 导出 FL2V 工作流，runner 的「按节点类型自动定位」机制同样适用。

### 输入 / 输出约定
| 项 | 要求 |
|---|---|
| 输入参考视频 | mp4，≤15s，人物动作清晰，**实体文件在 ComfyUI/input/ 下**（软链不识别）|
| 输入定妆照 | png/jpg 全身正面优先；多视图拼图需裁中间列（脚本自动做）|
| 输出 | mp4，24fps，分辨率随参考视频比例（竖屏 768×1344 / 横屏 1280×720）|

---

## 四、通用部署步骤（任意平台）

### A. AutoDL 专线（开箱最快）

```bash
# A1 租机：GPU ≥48G（推荐 RTX PRO 6000），数据盘 ≥200G
# A2 建 conda 环境（nvfp4 编码器必需 Python 3.13）
conda create -n h3 python=3.13 -y && conda activate h3
# A3 torch cu130（阿里云镜像直链，别用官方源太慢）
pip install torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 \
  --index-url https://mirrors.aliyun.com/pytorch-wheels/cu130
# 注意: torchaudio 保持 2.9.1 配套（2.11 会找 libcudart.so.13 报错）
# A4 ComfyUI 0.33.0 + marduk191 定制版源码覆盖（nvfp4 必需）
#    标准版 nvfp4 解析有 bug，覆盖 comfy/ 目录后必须清缓存:
find $COMFY_ROOT -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null
# A5 启动
python main.py --listen 127.0.0.1 --port 8188
```

### B. 通用平台（任意云 / 本地 WSL2）

```bash
# B1 检查 GPU: nvidia-smi（无输出则先装驱动/CUDA）
# B2 Python 3.13 + 虚拟环境（同 A2）
# B3 装 torch：按你的 CUDA 版本选 index-url；cu130 用阿里云 pytorch-wheels/cu130
# B4 ComfyUI 同 A4
# B5 WSL2 需在 Windows 侧装好 NVIDIA 驱动（WSL 内 nvidia-smi 可见即 OK）
```

### 验证就绪
```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"  # 期望 cu130 True
curl http://127.0.0.1:8188/system_stats                                        # ComfyUI API 通
```

---

## 五、模型下载（魔搭免翻墙）

### 🎯 先决定下多少（新手必看，别白下 131G）

| 你要干什么 | 需要下 | 合计 |
|---|---|---|
| **只跑换装视频（R2V）** | ref2va 40.2G + nvfp4 编码器 15.7G + 双 VAE 5.8G + R2V turbo LoRA 2G | **≈63G ✅ 最小集** |
| 还要文生视频/图生视频 | 追加 fl2va 40.2G + FL2V turbo LoRA 2G | ≈106G（模板需自备）|
| 显存紧张（<24G）| int8 版替换（21G 主模 + 27G 编码器）| ≈55G 但更慢 |
| 要速度不要极致画质 | 主力换 `pruned_fp8_scaled` 19.5G | 下载减半 |

> 💡 **下载脚本已内置最小集逻辑**：`python h3_download_models.py $COMFY_ROOT` 默认只下 R2V 最小集（63G），加 `--all` 才追加 T2V/I2V 模型。

### 下载清单（放对应目录）

| 文件 | 大小 | 放哪 | 用途 |
|---|---|---|---|
| `minimax_h3_ref2va_pruned_bf16.safetensors` | 40.2G | models/diffusion_models/ | **R2V 换装主力** |
| `minimax_h3_fl2va_pruned_bf16.safetensors` | 40.2G | models/diffusion_models/ | T2V/I2V 主模型（模板自备）|
| `qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors` | 15.7G | models/text_encoders/ | 文本编码器（画质最优）|
| `minimax_h3_video_vae_fp16.safetensors` | 5.2G | models/vae/ | 视频 VAE |
| `minimax_h3_audio_vae_fp32.safetensors` | 0.6G | models/vae/ | 音频 VAE |
| `minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors` | 2.0G | models/loras/ | R2V turbo LoRA |
| `minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors` | 2.0G | models/loras/ | FL2V turbo LoRA |
| 提速备选 `pruned_fp8_scaled` | 19.5G | diffusion_models/ | FP8 版，质量接近 BF16 快一倍 |

### 🔑 下载铁律（血的教训）

```bash
# ✅ 只用 modelscope SDK（魔搭，国内免翻墙）
pip install modelscope
modelscope download --model Comfy-Org/MiniMax-H3 --local_dir <models对应目录> <文件路径>

# ❌ 绝不用 aria2 下魔搭 → 产出"零填充空壳"（文件大小对但数据全 0，曾排查 3 小时）
# 下载后必须采样非零校验（h3_doctor.py 已内置此项）:
python -c "
with open('<文件>','rb') as f: f.seek(<size>//2); print('OK' if f.read(8) != b'\x00'*8 else 'EMPTY SHELL')
"
# GB vs GiB: 40.2GB = 37.46GiB（ls 显示 38G 正常，字节数匹配即完整）
```

---

## 六、R2V 换装工作流（核心）

### 节点链路
```
VHS_LoadVideo(参考视频 150) ──> IMAGE ──> MiniMaxH3ReferenceToVideo(136).ref_videos
                          └──> AUDIO ──> .ref_video_audios      ← 音轨也喂，可带原声
LoadImage(定妆照 137) ─────────────────> .ref_images
CLIPTextEncode(正/负提示词 138/139) ────> .positive / .negative
CLIPLoader(qwen3vl nvfp4, type=minimax 128) ──> .clip
VAELoader(视频 VAE 119) ──────────────> .vae
VAELoader(音频 VAE 120) ──────────────> .audio_vae
UNETLoader(ref2va_bf16 127) ──[+LoraLoaderModelOnly 131 turbo]──> .model
```
采样链：`RandomNoise(123) → BasicGuider(124) → KSamplerSelect(126) → BasicScheduler(129) → SamplerCustomAdvanced(125)`
输出链：`VAEDecode(122) + VAEDecodeAudio(121) → CreateVideo(130, fps=24) → SaveVideo(92)`

### 📦 开箱即用的工作流模板（v3.0 新增）

| 文件 | 步数 | 用途 |
|---|---|---|
| `scripts/workflows/r2v_video.json` | 20 步满配 | 质量天花板，单条约 38 分钟 |
| `scripts/workflows/r2v_video_turbo.json` | 4 步 + turbo LoRA | **批量首选**，单条 8-10 分钟 |

> 两个模板的节点 ID 与上面链路图完全一致。runner 采用**按节点类型自动定位**（不依赖固定 ID），所以你自己从 ComfyUI 导出的工作流也能直接喂给 runner。

### 关键参数

| 参数 | 值 | 说明 |
|---|---|---|
| width/height | **768×1344** 竖屏 9:16（横屏 1280×720）| 短边 768P 标准，随参考视频比例 |
| length | 帧数对齐公式（见下）| H3 要求帧数落在 `5+17n` 序列上 |
| ref_image_size | **max**（2048px 保真）/ match | max 慢但身份准 |
| steps | 20（满配）/ 4（turbo+LoRA）| 步数↓ 速度↑ |
| 提示词 | `Replace the person in <Video 1> with the subject from <Picture 1>. Keep camera motion and scene layout from <Video 1>. Match identity, hair, and outfit of <Picture 1>.` | 三段式换人（必须用标签引用）|

**帧数对齐公式**（实战版，已跑通 115 支）：
```python
length = 5 + round((dur * 24 - 5) / 17) * 17   # dur = 视频秒数
# 8.8s  -> 209 帧 (不是 211，需落在 5+17n 上)
# 14.2s -> 345 帧
```
> 早期笔记里"8.8s→212 帧"是未做 17 对齐的原始值，**以本公式为准**。runner 已内置自动计算。

### 提示词引用锁定语法（补头/换人必用）
- `<Picture 1>` → `ref_images.ref_image_0`；`<Video 1>` → `ref_videos.ref_video_0`；H3 编码器是 Qwen3-VL，**中文直接可用**
- 参考视频只拍到脖子以下需要"补头"时，人物描述必须指向 `<Picture 1>`（指向 `<Video 1>` 会因无头可参而依旧无头）

---

## 七、平台对照表：AutoDL vs 其他

| 环节 | AutoDL | 其他云（恒源云/青椒云等）| 本地 Linux/WSL2 |
|---|---|---|---|
| 租机 | 控制台选 RTX PRO 6000 | 选 ≥48G 卡 | — |
| 无卡模式维护 | ✅ ¥0.1/时（下载/维护用）| 看平台是否提供 | — |
| 关机省钱 | ✅ 停计费只收数据盘 | 看平台计费 | 关机即省 |
| SSH | 控制台拿 host/port/密码 | 平台提供 | localhost |
| 注意 | 换 GPU 后设备节点可能丢 | 同左 | 驱动要自装 |
| 模型下载 | 魔搭直连 | 同左 | 同左（国内网络）|

---

## 八、批量生产（runner + 看门狗）

### 串行 runner（断点续跑 + 逐条超时保护）

```bash
python h3_runner.py --config my_h3.env --pairs pairs.json --only 1        # 跑第 1 条
python h3_runner.py --config my_h3.env --pairs pairs.json --from 4 --n 20 # 从第 4 条起跑 20 条
python h3_runner.py --config my_h3.env --pairs pairs.json --only 3,6,9    # 只跑不连续索引
python h3_runner.py --config my_h3.env --pairs pairs.json --steps 8 --width 1280 --height 720
```

| 机制 | 说明 |
|---|---|
| 断点续跑 | 每条完成即写 state JSON，重启自动 skip 已完成的 |
| 超时保护 | 单支超时（默认 1500s）自动 POST `/interrupt` 放行下一条，防卡死堵队列 |
| 自动定位节点 | 按 class_type 扫描定位 LoadVideo/LoadImage/RandomNoise，不依赖固定节点 ID |
| 自动算帧数 | ffprobe 读时长 → 套 `5+17n` 公式 → 写入工作流 |
| 中文报错 | 提交失败区分「模型名对不上」「节点类型不存在」等，直接给修复方向 |

### 看门狗（无人值守必需）

- 职责：① ComfyUI 进程死 / API 无响应 >150s → 自动重启 + 清队列；② runner 不在 → 按 conf 重建
- conf 每行**必须带参数**：`run_h3_xxx.py --from 4 --n 2`（只写脚本名会在重建时从头跑）

```bash
# 幂等启动模板（防 ssh 命令重复执行产生双实例）
if pgrep -f "run_h3_yiyue_[1]69.py" >/dev/null 2>&1; then
  echo "已在运行 -> 跳过"
else
  (setsid nohup $PY -u run_h3_yiyue_169.py $ARGS > log 2>&1 < /dev/null &)
fi
```
- ★ `pgrep/pkill` 自匹配防护：模式写 `xxx_[1]69.py`（字符类技巧，pgrep 永不自杀）
- ★ 多实例错乱铁律：**不要逐个 kill，直接重启 ComfyUI** → 清 state → 单启 runner → 最后启看门狗

---

## 九、错误速查表（故障排查专用）

> 本章只收**报错/异常**类问题。想问"要不要/能不能/多少钱"请看第十二章 FAQ。

| 症状 | 根因 | 解法 |
|---|---|---|
| 加载 nvfp4 编码器报 `utf-32-be` 解码错 | torch <2.9.1 或 Python<3.13 | torch 升 2.9.1+cu130 + Python 3.13 |
| `libcudart.so.13` 缺失 | torchaudio 版本错 | torchaudio 装 2.8.0/2.9.1 配套 |
| nvfp4 解析失败 | 标准版 ComfyUI bug | marduk191 定制版覆盖 + 清 `__pycache__` |
| 提交报 `Prompt outputs failed validation` | 节点类型不存在或连线断了 | 跑 `h3_doctor.py` 校验节点注册 |
| 提交报 `value not in list` | 模型文件名/采样器名对不上 | 核对 `models/` 下实际文件名 |
| LoadVideo 报 `Invalid video file` | 软链不识别 | 实体复制到 input/ + **重启 ComfyUI** |
| 文件大小对但全是 0 | aria2 下魔搭空壳 | 改 modelscope SDK + 采样非零校验 |
| 参考视频 >15s 报错 | H3 上限 360 帧 | `ffmpeg -y -v error -i in.mp4 -t 14.2 -c copy out.mp4` |
| 出片"无头"（视频只拍身体）| 提示词指向了视频 | 提示词让"人物"指向 `<Picture 1>` |
| 输出视频没有声音 | 音频链路没接全 | 确认 `ref_video_audios` ← LoadVideo 音频口，且 VAEDecodeAudio + CreateVideo 已接 |
| 同一条出两个文件 `_00001_/_00002_` | 同名重跑 | 识别序号，删旧的 |
| **【批量】** 第 3 条起卡死（GPU 0% 但显存占着）| int8 模型重复加载挂起 | 单支 timeout + `/interrupt`；根治是重启 ComfyUI |
| **【批量】** 双实例重复渲染 | ssh 命令偶发执行两次 | 幂等启动 + pgrep 锚定；**用 `ps` 数进程确认，别只看日志** |
| **【批量】** 看门狗自杀 | `pkill -f` 匹配到自身 | 字符类技巧 `xxx_[1]69.py` |
| **【批量】** 重启后显存没清 | 进程残留 | 按精确 PID `kill -9`（禁裸 `pkill`），`nvidia-smi` 确认归零 |
| **【批量】** 找不到视频文件 | 文件名带 ID 后缀（如 `055_7416501374852107539.mp4`）| runner 已内置模糊匹配 `%03d_*.mp4` |
| CUDA OOM | `--highvram` 模型常驻 | 用默认 auto 加载 |
| 磁盘爆 | 下载写到了 `/tmp` | 写数据盘，别用 `/tmp` |

---

## 十、性能与成本实测

| 模式 | 一条耗时（8.8s / 768P 竖屏）| 费用 | 说明 |
|---|---|---|---|
| 满配 20 步 BF16 | 38 分钟 | ≈¥4 | 质量天花板 |
| turbo 8 步 | 16-18 分钟 | ≈¥1.5 | 质量/速度甜点 |
| **turbo 4 步** | **8-10 分钟** | **≈¥0.5-0.8** | **批量首选** |
| FP8 模型 | 约快一倍 | 同上 | 质量接近 BF16 |
| 官方 API（4×H100）| 1-2 分钟 | ¥7 | 多卡 + FP8 |

**参考基准**：本地 RTX 3060（int8 + lowvram）跑 R2V 一条 ≈ 49 分钟 → 云端 PRO 6000 提速约 5 倍。

**提速路线（按性价比排序）**：turbo 4 步 → FP8 模型 → 更短视频（帧数 -43%）→ 多卡并行（成本 ×4+，收益有限）。

---

## 十一、省钱与日常交付

```text
1. 开机（GPU 模式）→ ComfyUI 自动起 → 提交任务
2. 跑完 → 下载成品 → 关机（停机只收数据盘）
3. 下载/维护模型 → 无卡模式（AutoDL ¥0.1/时）
```

- 关机 ≠ 释放：关机保留数据盘（继续计费），**释放 = 全删**
- 模型约 75G 驻留显存：连续跑第 2 条起省 2-3 分钟加载
- 补帧到 30fps：
  ```bash
  ffmpeg -i in.mp4 -vf 'minterpolate=fps=30:mi_mode=mci:mc_mode=aobmc:me_mode=bidir' \
         -c:v libx264 -crf 18 out_30fps.mp4
  ```
- ⚠️ 交付后**重置云密码**（防泄露）

---

## 十二、FAQ（选型与效果专用）

> 本章只回答**选型 / 参数 / 效果**类疑问。报错了请去第九章。

**Q1: 我该选哪种模式？**
A: 看第一章决策树。批量（50+ 条）用 turbo 4 步；求质量用满配 20 步；只做几条就用官方 API。

**Q2: 我下载的 40G 模型，ls 显示只有 38G，是不是没下全？**
A: 正常，GB vs GiB 换算（40.2GB = 37.46GiB）。用**字节数**精确比对判断是否完整，别看 ls 数值。

**Q3: 换出来的人不像定妆照怎么办？**
A: 四步排查 ① `ref_image_size` 用 `max` ② 提示词三段式必须带 `<Picture 1>` 标签 ③ 定妆照要全身正面 ④ 确认工作流 `ref_images` 真接到了 LoadImage。

**Q4: 显存只有 24G 能跑吗？**
A: 满配 BF16 不行。用 int8 模型组合（21G 主模 + 27G 编码器）+ turbo LoRA + 降分辨率，可以跑但明显变慢。

**Q5: 能跑 T2V/I2V（文生视频 / 图生视频）吗？**
A: 能力上可以（模型清单见第五章），但**本技能未提供 FL2V 工作流模板**——我们只在 R2V 换装场景实测过 115 支，FL2V 未实机验证，不给你一份没跑过的模板。可自行从 ComfyUI 导出，runner 的自动定位机制同样适用。

**Q6: 一次批量多少条合适？**
A: 建议先 `--only 1` 跑通一条验效果，再全量。115 支全量 turbo 模式约 30-48 小时，配看门狗无人值守。

**Q7: 参考视频怎么选效果最好？**
A: 人物动作清晰、机位稳定、时长 8-15s、光线正常。多人/快速剪辑/剧烈晃动的视频效果会明显下降。

---

## 📎 配套脚本清单

| 脚本 | 用途 | 什么时候用 |
|---|---|---|
| `h3_config.env` | **路径与参数配置（唯一改路径的地方）** | 第一步改它 |
| `h3_doctor.py` | 60 秒全身体检（环境/显存/磁盘/模型/节点注册/素材）| **每次跑批量前** |
| `h3_prepare_inputs.py` | 素材预处理：裁超长视频 + 拼图裁中间列 + 配对生成 pairs.json | 准备素材时 |
| `h3_runner.py` | 批量串行 runner：断点续跑 + 超时保护 + 自动定位节点 | 出片主力 |
| `h3_download_models.py` | 魔搭一键下载（默认 63G 最小集，含空壳校验）| 下模型时 |
| `h3_watchdog.sh` | 看门狗：ComfyUI + runner 双向自愈（路径同样走配置）| 无人值守 |
| `workflows/r2v_video.json` | 工作流模板 · 满配 20 步 | 追求质量 |
| `workflows/r2v_video_turbo.json` | 工作流模板 · 4 步 turbo（批量首选）| 批量出片 |

---

*v3.0.0 · 2026-09-03 · 依据 SkillHub 评测报告重构：补齐工作流模板 / 新增自检医生 / 路径配置化 / 五步出片 · 数据均来自 AutoDL RTX PRO 6000 实测*
