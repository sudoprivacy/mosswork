#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H3 模型全家桶下载器 (魔搭, 国内免翻墙) — 任意平台通用
用法: python h3_download_models.py /path/to/ComfyUI [--only-ref2va]
说明: 只下 R2V 换装需要的最小集 (ref2va 40G + nvfp4 编码器 15.7G + 双 VAE + turbo LoRA)
      --all 追加 fl2va 40G (T2V/I2V)
      下载后自动采样非零校验, 揪出 aria2 空壳问题
"""
import os
import subprocess
import sys

def sh(cmd):
    print(">>", cmd, flush=True)
    subprocess.check_call(cmd, shell=True)

def main():
    if len(sys.argv) < 2:
        print("用法: python h3_download_models.py /path/to/ComfyUI [--all]")
        sys.exit(1)
    base = sys.argv[1].rstrip("/")
    all_flag = "--all" in sys.argv

    dirs = {
        "diffusion_models": os.path.join(base, "models", "diffusion_models"),
        "text_encoders": os.path.join(base, "models", "text_encoders"),
        "vae": os.path.join(base, "models", "vae"),
        "loras": os.path.join(base, "models", "loras"),
    }
    for d in dirs.values():
        os.makedirs(d, exist_ok=True)

    dl = ("modelscope download --model Comfy-Org/MiniMax-H3 --local_dir {d} {path}")

    # R2V 换装主力 + 编码器 (最小集)
    files = [
        ("diffusion_models", "diffusion_models/minimax_h3_ref2va_pruned_bf16.safetensors", 40.2),
        ("text_encoders", "text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors", 15.7),
        ("vae", "vae/minimax_h3_video_vae_fp16.safetensors", 5.2),
        ("vae", "vae/minimax_h3_audio_vae_fp32.safetensors", 0.6),
        ("loras", "loras/minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors", 2.0),
    ]
    if all_flag:
        files.append(("diffusion_models", "diffusion_models/minimax_h3_fl2va_pruned_bf16.safetensors", 40.2))
        files.append(("loras", "loras/minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors", 2.0))

    for cat, path, size_gb in files:
        dest = os.path.join(dirs[cat], os.path.basename(path))
        if os.path.exists(dest) and os.path.getsize(dest) > size_gb * 0.9 * 1e9:
            print(f"SKIP 已存在: {dest}", flush=True)
            continue
        sh(dl.format(d=dirs[cat], path=path))

        # 采样非零校验 (抓空壳)
        print("校验中...", flush=True)
        sz = os.path.getsize(dest)
        with open(dest, "rb") as f:
            f.seek(sz // 2)
            sample = f.read(8)
        if sample == b"\x00" * 8:
            print(f"❌ 空壳! {dest} — 删除重下", flush=True)
            os.remove(dest)
            sh(dl.format(d=dirs[cat], path=path))
        else:
            print(f"✅ OK {dest}", flush=True)

    print("\n全部完成。清单:")
    for cat, d in dirs.items():
        for f in sorted(os.listdir(d)):
            print(f"  {cat}/{f}: {os.path.getsize(os.path.join(d, f))/1e9:.1f}G")

if __name__ == "__main__":
    main()
