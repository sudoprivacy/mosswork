#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H3 视频工厂 · 批量串行 runner（可直接运行，非占位模板）

相比旧版模板的四个修复:
  1. 路径全部来自 --config 配置文件，不再硬编码 /root/autodl-tmp
  2. 节点定位改为「按 class_type 自动扫描」，你自己从 ComfyUI 导出的工作流也能用
  3. 修复 seed 从未写入工作流的 bug（旧版 seed 参数传了但没进 RandomNoise 节点）
  4. 全部报错改中文，并附带可复制的修复命令

用法:
    python h3_runner.py --config h3_config.env --pairs pairs.json --workflow workflows/r2v_video_turbo.json
    python h3_runner.py --config h3_config.env --fixed-image cover001.png --videos-dir /path/videos
    python h3_runner.py --config h3_config.env --pairs pairs.json --only 1        # 先跑通 1 条
    python h3_runner.py --config h3_config.env --pairs pairs.json --from 4 --n 20 # 从第 4 条起跑 20 条
    python h3_runner.py --config h3_config.env --pairs pairs.json --steps 8 --width 1280 --height 720
"""
import argparse
import glob
import json
import os
import random
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

# 每个节点类型对应的「要改的字段」，用于自动定位
TARGET_FIELDS = {
    "VHS_LoadVideo": "video",
    "LoadImage": "image",
    "RandomNoise": "noise_seed",
    "MiniMaxH3ReferenceToVideo": None,
}
DEFAULTS = {
    "COMFY_API": "http://127.0.0.1:8188",
    "TIMEOUT_S": "1500",
    "POLL_S": "6",
    "FPS": "24",
    "STATE_FILE": "h3_state.json",
    "WORKFLOW": "workflows/r2v_video_turbo.json",
}


def load_config(path):
    cfg = dict(DEFAULTS)
    if path and os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
        cfg["_dir"] = os.path.dirname(os.path.abspath(path))
    elif path:
        print(f"[警告] 配置文件不存在: {path}，改用命令行参数与默认值")
    else:
        print("[警告] 未指定 --config，建议先 cp h3_config.env 改成本机路径")
    return cfg


def resolve(cfg, key, override=None, must=False):
    """取参数：命令行 > 配置文件 > 默认值；相对路径按配置文件目录解析"""
    val = override or cfg.get(key, "")
    if not val:
        if must:
            print(f"[错误] 缺少必要参数 {key}：请在配置文件里设置或用命令行传入")
            sys.exit(1)
        return ""
    if key.endswith(("_DIR", "_ROOT")) and not os.path.isabs(val):
        val = os.path.join(cfg.get("_dir", os.getcwd()), val)
    return val


def api(base, path, obj=None, timeout=60):
    req = urllib.request.Request(base + path,
                                 data=json.dumps(obj).encode() if obj else None,
                                 headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read())


def probe_duration(path):
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                              "format=duration", "-of",
                              "default=noprint_wrappers=1:nokey=1", path],
                             capture_output=True, text=True, timeout=30)
        return float(out.stdout.strip())
    except Exception:
        return None


def calc_length(dur, fps=24):
    """H3 帧数对齐公式：5 + round((总帧数-5)/17)*17"""
    if not dur:
        return None
    return 5 + round((dur * fps - 5) / 17) * 17


def find_nodes(wf):
    """按 class_type 扫描定位关键节点，返回 {用途: 节点ID}"""
    found = {}
    for nid, node in wf.items():
        ct = node.get("class_type")
        if ct == "VHS_LoadVideo":
            found["video"] = nid
        elif ct == "LoadImage":
            found["image"] = nid
        elif ct == "RandomNoise":
            found["seed"] = nid
        elif ct in ("MiniMaxH3ReferenceToVideo", "MiniMaxH3ImageToVideo",
                    "MiniMaxH3TextToVideo"):
            found["h3"] = nid
    return found


def build_workflow(tpl_path, video_file, image_file, seed, length=None,
                   steps=None, width=None, height=None):
    """载入模板并替换素材/种子/尺寸；节点位置自动定位，不依赖固定 ID"""
    with open(tpl_path, encoding="utf-8") as f:
        wf = json.load(f)
    nodes = find_nodes(wf)

    missing = [k for k in ("video", "image") if k not in nodes]
    if missing:
        print(f"[错误] 工作流里找不到节点: {missing}。"
              f"请确认用的是 H3 R2V 工作流（需含 VHS_LoadVideo 与 LoadImage）")
        sys.exit(1)

    wf[nodes["video"]]["inputs"]["video"] = video_file
    wf[nodes["image"]]["inputs"]["image"] = image_file

    if "seed" in nodes:
        wf[nodes["seed"]]["inputs"]["noise_seed"] = seed
    else:
        print("[警告] 工作流里没有 RandomNoise 节点，无法设置随机种子，"
              "同一素材会重复出同一结果")

    if "h3" in nodes:
        ins = wf[nodes["h3"]]["inputs"]
        if length:
            ins["length"] = length
        if width:
            ins["width"] = width
        if height:
            ins["height"] = height

    if steps:
        for nid, node in wf.items():
            if node.get("class_type") == "BasicScheduler":
                node["inputs"]["steps"] = steps
                break
        else:
            print("[警告] 工作流里没有 BasicScheduler 节点，--steps 未生效")
    return wf


def run_one(comfy, wf, timeout_s, poll_s, idx):
    try:
        r = api(comfy, "/prompt", {"prompt": wf})
        pid = r.get("prompt_id")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")[:400]
        hint = ""
        if "value not in list" in body:
            hint = "多半是模型文件名或采样器名对不上，用 h3_doctor.py 校验工作流"
        elif "Prompt outputs failed validation" in body:
            hint = "节点连线断了或节点类型不存在，用 h3_doctor.py 校验节点注册情况"
        print(f"  第 {idx} 条提交失败（HTTP {e.code}）: {body}")
        if hint:
            print(f"  可能原因: {hint}")
        return "submit_error"
    except Exception as e:
        print(f"  第 {idx} 条提交失败: {e}")
        print("  检查: ComfyUI 是否还活着（curl <COMFY_API>/system_stats）")
        return "submit_error"

    t0 = time.time()
    while time.time() - t0 < timeout_s:
        time.sleep(poll_s)
        try:
            h = api(comfy, "/history/" + pid)
        except Exception:
            continue
        if pid in h:
            st = h[pid].get("status", {})
            if st.get("completed"):
                return "done"
            if st.get("status_str") == "error":
                msgs = [m for m in st.get("messages", [])
                        if isinstance(m, list) and m[0] == "execution_error"]
                if msgs:
                    print(f"  报错内容: {str(msgs[0][1])[:300]}")
                print("  常见原因: 显存不足 / 视频超 15s / 模型加载失败，"
                      "详见 SKILL.md 错误速查表")
                return "error"
    try:
        req = urllib.request.Request(comfy + "/interrupt", data=b"", method="POST")
        urllib.request.urlopen(req, timeout=10)
        print(f"  第 {idx} 条超过 {timeout_s}s 未出片，已中断放行下一条")
        print("  若反复超时：GPU 利用率是否长期 0%（int8 模型重复加载会挂起），"
              "建议重启 ComfyUI 后重跑")
    except Exception:
        pass
    return "timeout"


def load_pairs(args, videos_dir):
    if args.pairs:
        if not os.path.exists(args.pairs):
            print(f"[错误] pairs 文件不存在: {args.pairs}")
            print("  用 h3_prepare_inputs.py 自动生成，格式 {idx:{video,image}}")
            sys.exit(1)
        return json.load(open(args.pairs, encoding="utf-8"))
    if args.fixed_image and videos_dir:
        if not os.path.isdir(videos_dir):
            print(f"[错误] 参考视频目录不存在: {videos_dir}")
            sys.exit(1)
        pairs = {}
        for f in sorted(os.listdir(videos_dir)):
            m = re.match(r"(\d+)_", f) or re.match(r"(\d+)\.", f)
            if m and f.lower().endswith((".mp4", ".mov", ".webm")):
                pairs[int(m.group(1))] = {"video": f, "image": args.fixed_image}
        return pairs
    print("[错误] 需要 --pairs，或 --fixed-image 搭配 --videos-dir")
    print("  示例: python h3_prepare_inputs.py --videos-dir ./videos "
          "--fixed-image cover001.png --out pairs.json")
    sys.exit(1)


def find_video(videos_dir, name):
    """支持 055.mp4 与 055_7416501374852107539.mp4 两种命名"""
    if os.path.isabs(name) or not videos_dir:
        return name
    m = re.match(r"(\d+)", name)
    if m:
        n = int(m.group(1))
        for pat in ("%03d_*.mp4", "%03d.mp4", "%d_*.mp4", "%d.mp4"):
            hit = glob.glob(os.path.join(videos_dir, pat % n))
            if hit:
                return os.path.basename(hit[0])
    return name


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", help="h3_config.env 路径")
    ap.add_argument("--workflow", help="工作流 JSON（覆盖配置）")
    ap.add_argument("--pairs", help="pairs JSON {idx:{video,image}}")
    ap.add_argument("--fixed-image", dest="fixed_image", help="固定参考图")
    ap.add_argument("--videos-dir", dest="videos_dir", help="参考视频目录（覆盖配置）")
    ap.add_argument("--state", help="断点文件（覆盖配置）")
    ap.add_argument("--from", dest="start", type=int)
    ap.add_argument("--n", type=int)
    ap.add_argument("--only", help="只跑指定索引，逗号分隔，如 3,6")
    ap.add_argument("--steps", type=int, help="覆盖采样步数")
    ap.add_argument("--width", type=int, help="覆盖宽度（横屏用 1280）")
    ap.add_argument("--height", type=int, help="覆盖高度（横屏用 720）")
    args = ap.parse_args()

    cfg = load_config(args.config)
    comfy = cfg.get("COMFY_API", DEFAULTS["COMFY_API"])
    timeout_s = int(cfg.get("TIMEOUT_S", 1500))
    poll_s = int(cfg.get("POLL_S", 6))
    fps = int(cfg.get("FPS", 24))

    wf_path = resolve(cfg, "WORKFLOW", args.workflow, must=True)
    if not os.path.isabs(wf_path):
        # 依次按「配置文件目录」「脚本目录」找，用户把配置拷到别处也不会断
        cands = []
        if cfg.get("_dir"):
            cands.append(os.path.join(cfg["_dir"], wf_path))
        cands.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), wf_path))
        wf_path = next((c for c in cands if os.path.exists(c)), cands[0])
    if not os.path.exists(wf_path):
        print(f"[错误] 工作流文件不存在: {wf_path}")
        print("  用 scripts/workflows/r2v_video.json（满配）或 r2v_video_turbo.json（提速）")
        print("  先跑 python h3_doctor.py --config h3_config.env 做一次全身体检")
        sys.exit(1)

    videos_dir = resolve(cfg, "VIDEOS_DIR", args.videos_dir)
    state_file = resolve(cfg, "STATE_FILE", args.state) or "h3_state.json"

    state = {}
    if os.path.exists(state_file):
        state = json.load(open(state_file, encoding="utf-8"))
        done_n = sum(1 for v in state.values() if v.get("status") == "done")
        print(f"载入断点文件: {state_file}（已完成 {done_n} 条，自动跳过）")

    pairs = load_pairs(args, videos_dir)
    only = None
    if args.only:
        only = set(int(x) for x in re.split(r"[,\s]+", args.only.strip()) if x)

    print(f"工作流: {os.path.basename(wf_path)} | ComfyUI: {comfy} | "
          f"共 {len(pairs)} 条 | 单条超时 {timeout_s}s")
    print("-" * 62)

    for idx in sorted(int(k) for k in pairs):
        key = str(idx)
        if state.get(key, {}).get("status") == "done":
            print(f"跳过 {idx}（已完成）")
            continue
        if only is not None and idx not in only:
            continue
        if args.start and idx < args.start:
            continue
        if args.n and args.start and idx >= args.start + args.n:
            break

        video = find_video(videos_dir, pairs[key].get("video", ""))
        image = pairs[key].get("image", "")
        if not video:
            print(f"[{idx}] 找不到参考视频，跳过")
            state[key] = {"status": "no_video"}
            continue

        length = None
        if videos_dir:
            dur = probe_duration(os.path.join(videos_dir, video))
            length = calc_length(dur, fps)
            if dur and dur > 15.0:
                print(f"[{idx}] 警告: 参考视频 {dur:.1f}s 超过 15s 上限，"
                      f"建议先裁剪: ffmpeg -y -v error -i in.mp4 -t 14.2 -c copy out.mp4")

        seed = random.randint(0, 2 ** 31 - 1)
        wf = build_workflow(wf_path, video, image, seed, length,
                            args.steps, args.width, args.height)
        print(f"[{idx}] 提交: {video} + {image}" +
              (f" | 帧数 {length}" if length else "") + f" | seed {seed}")

        st = run_one(comfy, wf, timeout_s, poll_s, idx)
        state[key] = {"status": st, "video": video, "image": image,
                      "seed": seed, "time": time.strftime("%Y-%m-%d %H:%M:%S")}
        try:
            json.dump(state, open(state_file, "w", encoding="utf-8"),
                      ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"  警告: 断点文件写入失败 {e}")
        print(f"  -> {st}")

    done = sum(1 for v in state.values() if v.get("status") == "done")
    bad = sum(1 for v in state.values() if v.get("status") not in ("done", None))
    print("-" * 62)
    print(f"本轮结束：完成 {done} 条，异常 {bad} 条")
    if bad:
        print(f"重跑失败项: python h3_runner.py --config {args.config or 'h3_config.env'} "
              f"--pairs {args.pairs or 'pairs.json'} --only <失败的编号>")
    print(f"出片目录见配置 OUT_DIR；补帧命令见 SKILL.md 第九节")


if __name__ == "__main__":
    main()
