#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H3 视频工厂 · 素材预处理（一条命令备好全部输入）

把「裁超长视频 + 多视图拼图裁中间列 + 实体复制到 ComfyUI/input + 随机配对 + 生成 pairs.json」
合并成一条命令，解决手工操作 6 步且步骤间有依赖的问题。

用法:
    # 视频池 x 定妆照池 随机配对
    python h3_prepare_inputs.py --videos ./videos --images ./portraits \
        --comfy-input /path/to/ComfyUI/input --out pairs.json --pairing random

    # 一张定妆照 配 全部视频
    python h3_prepare_inputs.py --videos ./videos --fixed-image cover001.png \
        --comfy-input /path/to/ComfyUI/input --out pairs.json

    # 只预处理、不配对
    python h3_prepare_inputs.py --videos ./videos --comfy-input /path/input --no-pairing

依赖: ffmpeg/ffprobe 必需（裁视频）；Pillow 可选（裁多视图拼图，没有则跳过）
"""
import argparse
import json
import os
import random
import re
import shutil
import subprocess
import sys
MAX_SEC = 15.0
CUT_TO = 14.2
VIDEO_EXT = (".mp4", ".mov", ".webm", ".mkv")
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")


def run(cmd, desc=""):
    """返回 (是否成功, stdout, stderr) —— 注意 ffprobe 的结果在 stdout 不在 stderr

    Windows 坑：subprocess 直接调 "ffprobe" 时 CreateProcess 只自动补 .exe 不补 .bat，
    而 conda 安装的 ffmpeg 正是 ffmpeg.bat，会直接 FileNotFoundError。
    因此这里先用 shutil.which 解析成绝对路径再调用。
    """
    exe = shutil.which(cmd[0]) or cmd[0]
    cmd = [exe] + list(cmd[1:])
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        return r.returncode == 0, (r.stdout or ""), (r.stderr or "")[-300:]
    except FileNotFoundError:
        return False, "", f"命令不存在: {cmd[0]}"
    except Exception as e:
        return False, "", str(e)


def probe_duration(path):
    ok, out, _ = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                      "-of", "default=noprint_wrappers=1:nokey=1", path])
    if not ok:
        return None
    try:
        return float(out.strip().splitlines()[-1])
    except Exception:
        return None


def process_videos(src_dir, dst_dir, auto_cut=True):
    """扫描源视频：超 15s 自动裁剪，其余复制，统一落到 dst_dir/videos/"""
    out_dir = os.path.join(dst_dir, "videos")
    os.makedirs(out_dir, exist_ok=True)
    files = sorted(f for f in os.listdir(src_dir)
                   if f.lower().endswith(VIDEO_EXT))
    if not files:
        print(f"[错误] {src_dir} 里没有视频文件（支持 {', '.join(VIDEO_EXT)}）")
        sys.exit(1)

    kept, cut, failed = [], [], []
    for f in files:
        src = os.path.join(src_dir, f)
        dur = probe_duration(src)
        dst = os.path.join(out_dir, f)
        if dur is None:
            print(f"  [!!] {f}: 读不出时长，跳过（确认 ffmpeg 已装、文件未损坏）")
            failed.append(f)
            continue
        if dur > MAX_SEC:
            if not auto_cut:
                print(f"  [!!] {f}: {dur:.1f}s 超限且未开 --auto-cut，跳过")
                failed.append(f)
                continue
            base, ext = os.path.splitext(f)
            dst = os.path.join(out_dir, f"{base}_cut{ext}")
            ok, _, err = run(["ffmpeg", "-y", "-v", "error", "-i", src, "-t",
                              str(CUT_TO), "-c", "copy", dst])
            if ok:
                print(f"  [裁] {f}: {dur:.1f}s -> {CUT_TO}s")
                cut.append(os.path.basename(dst))
            else:
                print(f"  [!!] {f}: 裁剪失败 {err}")
                failed.append(f)
        else:
            if os.path.abspath(src) != os.path.abspath(dst):
                shutil.copy2(src, dst)
            print(f"  [复] {f}: {dur:.1f}s 合规")
            kept.append(f)
    print(f"  小计: 合规 {len(kept)} / 已裁 {len(cut)} / 失败 {len(failed)}")
    return sorted(kept + cut), out_dir


def process_images(src_dir, dst_dir, fixed=None, auto_crop=True):
    """处理定妆照：检测 21:9 多视图拼图并裁出中间列全身图"""
    os.makedirs(dst_dir, exist_ok=True)
    if fixed:
        src = fixed if os.path.isabs(fixed) else os.path.join(src_dir, fixed)
        if not os.path.exists(src):
            print(f"[错误] 定妆照不存在: {src}")
            sys.exit(1)
        shutil.copy2(src, os.path.join(dst_dir, os.path.basename(src)))
        print(f"  固定定妆照: {os.path.basename(src)}")
        return [os.path.basename(src)]

    if not src_dir or not os.path.isdir(src_dir):
        return []
    try:
        from PIL import Image
    except ImportError:
        print("  [??] 未装 Pillow，跳过多视图拼图裁切（pip install pillow）")
        files = sorted(f for f in os.listdir(src_dir) if f.lower().endswith(IMAGE_EXT))
        for f in files:
            shutil.copy2(os.path.join(src_dir, f), os.path.join(dst_dir, f))
        return files

    files = sorted(f for f in os.listdir(src_dir) if f.lower().endswith(IMAGE_EXT))
    result = []
    for f in files:
        src = os.path.join(src_dir, f)
        try:
            img = Image.open(src)
            w, h = img.size
            if auto_crop and w / h > 2.0:
                col = w // 3
                cropped = img.crop((col, 0, col * 2, h))
                base, ext = os.path.splitext(f)
                out_name = f"{base}_full{ext}"
                cropped.save(os.path.join(dst_dir, out_name))
                print(f"  [裁] {f}: 拼图 {w}x{h} -> 中间列 {out_name}")
                result.append(out_name)
            else:
                shutil.copy2(src, os.path.join(dst_dir, f))
                print(f"  [复] {f}: {w}x{h}")
                result.append(f)
        except Exception as e:
            print(f"  [!!] {f}: 处理失败 {e}")
    return sorted(result)


def build_pairs(videos, images, pairing, seed):
    """生成 {idx: {video, image}}，支持 random / sequential / fixed"""
    if not images:
        return {str(i + 1): {"video": v} for i, v in enumerate(videos)}
    if pairing == "sequential":
        seq = [images[i % len(images)] for i in range(len(videos))]
    elif pairing == "fixed":
        seq = [images[0]] * len(videos)
    else:
        rnd = random.Random(seed)
        seq = [rnd.choice(images) for _ in videos]
        if len(set(seq)) > 1:
            rnd.shuffle(seq)
    return {str(i + 1): {"video": v, "image": img}
            for i, (v, img) in enumerate(zip(videos, seq))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--videos", required=True, help="源参考视频目录")
    ap.add_argument("--images", help="源定妆照目录")
    ap.add_argument("--fixed-image", dest="fixed_image", help="固定用这一张定妆照")
    ap.add_argument("--comfy-input", dest="comfy_input", required=True,
                    help="ComfyUI/input 目录（必须是实体目录，软链不被识别）")
    ap.add_argument("--out", default="pairs.json", help="输出 pairs.json 路径")
    ap.add_argument("--pairing", default="random",
                    choices=["random", "sequential", "fixed"])
    ap.add_argument("--seed", type=int, default=42, help="随机配对种子，便于复现")
    ap.add_argument("--no-cut", dest="auto_cut", action="store_false",
                    help="超 15s 视频不裁剪，直接跳过")
    ap.add_argument("--no-pairing", dest="do_pairing", action="store_true",
                    help="只做预处理，不生成 pairs.json")
    args = ap.parse_args()

    if not os.path.isdir(args.videos):
        print(f"[错误] 参考视频目录不存在: {args.videos}")
        sys.exit(1)
    if not shutil.which("ffprobe"):
        print("[错误] 没找到 ffprobe，请先安装 ffmpeg（apt install ffmpeg / conda install ffmpeg）")
        sys.exit(1)

    print("=" * 62)
    print(" H3 视频工厂 · 素材预处理")
    print("=" * 62)
    print(f"\n--- 一、参考视频（上限 {MAX_SEC}s，超限裁到 {CUT_TO}s）---")
    videos, vdir = process_videos(args.videos, args.comfy_input, args.auto_cut)

    print("\n--- 二、定妆照（21:9 拼图自动裁中间列）---")
    images = process_images(args.images, args.comfy_input, args.fixed_image)

    if args.do_pairing or not videos:
        print(f"\n只做预处理，未生成 pairs.json。视频在: {vdir}")
        return

    pairs = build_pairs(videos, images, args.pairing, args.seed)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(pairs, f, ensure_ascii=False, indent=2)

    print(f"\n--- 三、配对结果（{args.pairing}，seed={args.seed}）---")
    for k in list(pairs)[:5]:
        print(f"  {k}: {pairs[k]['video']} + {pairs[k].get('image', '(未配图)')}")
    if len(pairs) > 5:
        print(f"  ... 共 {len(pairs)} 条")
    print(f"\n已生成: {args.out}")
    print(f"视频目录: {vdir}")
    print("\n下一步:")
    print("  1) 重启 ComfyUI（新素材必须重启才会被扫描到，这步不能省）")
    print("  2) python h3_doctor.py --config h3_config.env    # 60 秒体检")
    print(f"  3) python h3_runner.py --config h3_config.env --pairs {args.out} --only 1")
    print("     先跑通 1 条确认效果，再放开批量")
    print("=" * 62)


if __name__ == "__main__":
    main()
