#!/bin/bash
# h3_watchdog.sh — H3 批量看门狗（进程自愈，无人值守必需）
#
# 职责:
#   1. ComfyUI 进程死 / API(/system_stats) 无响应 -> 自动重启 ComfyUI + 清显存
#   2. 名单里每个 runner 若进程不在 -> 按 conf 自动重建（runner 自带断点续跑，不丢进度）
#
# 用法:
#   ./h3_watchdog.sh --config h3_config.env        # 推荐：路径全部来自配置
#   ./h3_watchdog.sh --comfy-dir /path/ComfyUI --py /path/python
#   setsid /bin/bash h3_watchdog.sh --config h3_config.env > /dev/null 2>&1 &
#
# 注意: 本脚本被 pkill 时会匹配自身名称，停用请用精确 PID，不要 pkill -f
set -u

# ===== 读取配置 =====
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE=""
COMFY_DIR_ARG=""
PY_ARG=""
CONF_ARG=""
LOGDIR_ARG=""

while [ $# -gt 0 ]; do
  case "$1" in
    --config)     CONFIG_FILE="$2"; shift 2;;
    --comfy-dir)  COMFY_DIR_ARG="$2"; shift 2;;
    --py)         PY_ARG="$2"; shift 2;;
    --runners)    CONF_ARG="$2"; shift 2;;
    --logdir)     LOGDIR_ARG="$2"; shift 2;;
    -h|--help)    sed -n '2,20p' "$0"; exit 0;;
    *) echo "未知参数: $1（用 --help 看用法）"; exit 1;;
  esac
done

# 配置文件：命令行 > 脚本同目录默认 > 无
[ -z "$CONFIG_FILE" ] && [ -f "$SCRIPT_DIR/h3_config.env" ] && CONFIG_FILE="$SCRIPT_DIR/h3_config.env"
if [ -n "$CONFIG_FILE" ]; then
  if [ -f "$CONFIG_FILE" ]; then
    # KEY=VALUE 格式，可直接 source
    set -a; . "$CONFIG_FILE"; set +a
    echo "已加载配置: $CONFIG_FILE"
  else
    echo "错误: 配置文件不存在 -> $CONFIG_FILE"
    exit 1
  fi
fi

PY="${PY_ARG:-${PY_PATH:-$(command -v python3 || command -v python)}}"
COMFY_DIR="${COMFY_DIR_ARG:-${COMFY_ROOT:-}}"
CONF="${CONF_ARG:-${WATCH_CONF:-}}"
LOGDIR="${LOGDIR_ARG:-${LOG_DIR:-$(pwd)}}"
API="${COMFY_API:-http://127.0.0.1:8188}"

# ===== 必要项校验（没配就明说，不要闷头跑错）=====
MISSING=0
if [ -z "$COMFY_DIR" ]; then
  echo "错误: 未配置 COMFY_ROOT（ComfyUI 根目录）"
  echo "  在 h3_config.env 里加一行: COMFY_ROOT=/你的/ComfyUI/路径"
  MISSING=1
elif [ ! -d "$COMFY_DIR" ]; then
  echo "错误: COMFY_ROOT 目录不存在 -> $COMFY_DIR"
  MISSING=1
fi
if [ -z "$PY" ] || ! command -v "$PY" > /dev/null 2>&1; then
  echo "错误: 找不到可用的 python（PY=$PY）"
  echo "  在 h3_config.env 里加一行: PY_PATH=/root/miniconda3/envs/h3/bin/python"
  MISSING=1
fi
[ "$MISSING" -eq 1 ] && exit 1

mkdir -p "$LOGDIR"
echo "ComfyUI : $COMFY_DIR"
echo "Python  : $PY"
echo "API     : $API"
echo "日志    : $LOGDIR/h3_watchdog.log"
echo "runner 名单: ${CONF:-（未配置 WATCH_CONF，只监控 ComfyUI）}"

restart_comfy() {
  echo "[$(date '+%F %T')] ComfyUI 无响应，重启中" >> "$LOGDIR/h3_watchdog.log"
  # 1) 按精确 PID 杀干净（禁 pkill 裸模式，会误杀）
  for pid in $(ps -eo pid,cmd | grep "$COMFY_DIR/main.py" | grep -v grep | awk '{print $1}'); do
    kill -9 "$pid" 2>/dev/null
  done
  sleep 5
  # 2) 确认显存清空
  if ! nvidia-smi --query-gpu=memory.used --format=csv,noheader 2>/dev/null \
       | head -1 | grep -q '^0 '; then
    echo "[$(date '+%F %T')] WARN: 显存未清零，可能有残留进程" >> "$LOGDIR/h3_watchdog.log"
  fi
  # 3) 重启
  (setsid nohup "$PY" "$COMFY_DIR/main.py" --listen 127.0.0.1 --port 8188 \
     >> "$LOGDIR/comfy_run.log" 2>&1 < /dev/null &)
  sleep 20
  # 4) 清掉卡住的队列
  curl -s -m 10 -X POST "$API/queue" -H 'Content-Type: application/json' \
       -d '{"clear":true}' > /dev/null 2>&1 || true
}

comfy_alive() {
  curl -s -m 5 "$API/system_stats" > /dev/null 2>&1
}

while true; do
  # --- 1. ComfyUI 健康 ---
  if ! comfy_alive; then
    restart_comfy
  fi
  # --- 2. runner 自愈 ---
  if [ -n "$CONF" ] && [ -f "$CONF" ]; then
    while IFS= read -r entry; do
      [ -z "$entry" ] && continue
      case "$entry" in \#*) continue;; esac
      runner=$(echo "$entry" | awk '{print $1}')
      # 字符类技巧防自匹配: run_xxx.py -> r[u]n_xxx.py，pgrep 永不匹配自身
      pattern="${runner:0:1}[${runner:1:1}]${runner:2}"
      if ! pgrep -f "$pattern" > /dev/null 2>&1; then
        echo "[$(date '+%F %T')] runner 不在，重建: $entry" >> "$LOGDIR/h3_watchdog.log"
        (cd "$LOGDIR" && setsid nohup "$PY" -u $entry >> "$LOGDIR/batch.log" 2>&1 < /dev/null &)
        sleep 3
      fi
    done < "$CONF"
  fi
  sleep 30
done
