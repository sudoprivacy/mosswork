#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""H3 视频工厂 · 60 秒自检医生

一键体检：环境 → 显存 → 磁盘 → 模型完整性 → ComfyUI 连通 → 工作流节点注册
          → 输入素材合规性。每项错误都给中文原因 + 具体修复命令。

用法:
    python h3_doctor.py --config h3_config.env
    python h3_doctor.py --comfy-root /path/to/ComfyUI   # 不写配置也能跑
    python h3_doctor.py --config h3_config.env --workflow ../workflows/r2v_video.json
"""
import argparse
import json
import os
import sys
import urllib.request

OK, BAD, WARN = "[OK]", "[!!]", "[??]"


class Report:
    def __init__(self):
        self.rows = []

    def add(self, level, item, detail, fix=""):
        self.rows.append((level, item, detail, fix))
        print(f"{level} {item}: {detail}")
        if fix:
            print(f"       修复 -> {fix}")

    @property
    def failed(self):
        return [r for r in self.rows if r[0] == BAD]


def load_config(path):
    """解析 KEY=VALUE 配置，# 开头为注释"""
    cfg = {}
    if not path or not os.path.exists(path):
        return cfg
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            cfg[k.strip()] = v.strip()
    return cfg


def human_gb(nbytes):
    return nbytes / (1024 ** 3)


def probe_duration(path):
    """用 ffprobe 读视频时长；没装返回 None

    Windows 坑：conda 装的 ffmpeg 是 ffmpeg.bat，而 subprocess 的 CreateProcess
    只自动补 .exe 不补 .bat，直接调 "ffprobe" 会 FileNotFoundError。
    所以先用 shutil.which 解析成绝对路径。
    """
    import shutil
    import subprocess
    exe = shutil.which("ffprobe")
    if not exe:
        return None
    try:
        out = subprocess.run(
            [exe, "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True, timeout=30)
        return float(out.stdout.strip().splitlines()[-1])
    except Exception:
        return None


def check_env(rep):
    print("\n--- 一、运行环境 ---")
    v = sys.version_info
    ok = v.major == 3 and v.minor >= 13
    rep.add(OK if ok else BAD, "Python 版本",
            f"{v.major}.{v.minor}.{v.micro}" + ("" if ok else "（需 3.13+）"),
            "" if ok else "conda create -n h3 python=3.13 -y && conda activate h3")

    try:
        import torch
        rep.add(OK if torch.cuda.is_available() else BAD, "torch / CUDA",
                f"torch {torch.__version__}, CUDA 可用={torch.cuda.is_available()}",
                "" if torch.cuda.is_available() else
                "pip install torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 "
                "--index-url https://mirrors.aliyun.com/pytorch-wheels/cu130")
        if torch.cuda.is_available():
            total = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
            used = torch.cuda.memory_allocated(0) / (1024 ** 3)
            free = total - used
            if total < 24:
                rep.add(BAD, "GPU 显存",
                        f"共 {total:.1f}G，可用 {free:.1f}G（低于 24G 跑不动满配 BF16）",
                        "改 int8 模型组合 + turbo LoRA + 降分辨率，或换 >=48G 的卡")
            elif free < 40:
                rep.add(WARN, "GPU 显存",
                        f"共 {total:.1f}G，可用 {free:.1f}G（偏紧，模型约需 75G 常驻）",
                        "确认无残留进程占用：nvidia-smi 后按 PID kill -9")
            else:
                rep.add(OK, "GPU 显存", f"共 {total:.1f}G，可用 {free:.1f}G")
    except ImportError:
        rep.add(BAD, "torch / CUDA", "未安装 torch",
                "pip install torch==2.9.1 torchvision==0.24.1 torchaudio==2.9.1 "
                "--index-url https://mirrors.aliyun.com/pytorch-wheels/cu130")


def check_disk(rep, comfy_root):
    print("\n--- 二、磁盘空间 ---")
    if not comfy_root or not os.path.isdir(comfy_root):
        rep.add(BAD, "ComfyUI 目录", f"不存在: {comfy_root}",
                "改 h3_config.env 里的 COMFY_ROOT 为你的实际路径")
        return
    try:
        st = os.statvfs(comfy_root)
        free = human_gb(st.f_bavail * st.f_frsize)
        if free < 70:
            rep.add(BAD, "磁盘剩余", f"{free:.1f}G（最小集 63G + 成品，至少要 80G）",
                    "清理 output/ 旧成品，或扩数据盘；别下载到 /tmp")
        elif free < 120:
            rep.add(WARN, "磁盘剩余", f"{free:.1f}G（够跑 R2V 最小集，下全量 131G 不够）",
                    "只跑 R2V 就够；要 T2V/I2V 需再扩盘")
        else:
            rep.add(OK, "磁盘剩余", f"{free:.1f}G")
    except Exception as e:
        rep.add(WARN, "磁盘剩余", f"读取失败: {e}")


def check_models(rep, comfy_root, cfg):
    print("\n--- 三、模型文件（含空壳校验）---")
    if not comfy_root or not os.path.isdir(comfy_root):
        rep.add(BAD, "模型检查", "ComfyUI 目录不存在，跳过",
                "先配好 COMFY_ROOT")
        return
    wanted = [
        ("models/diffusion_models", cfg.get("MODEL_UNET",
         "minimax_h3_ref2va_pruned_bf16.safetensors"), 40.2),
        ("models/text_encoders", cfg.get("MODEL_CLIP",
         "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"), 15.7),
        ("models/vae", cfg.get("MODEL_VAE_VIDEO",
         "minimax_h3_video_vae_fp16.safetensors"), 5.2),
        ("models/vae", cfg.get("MODEL_VAE_AUDIO",
         "minimax_h3_audio_vae_fp32.safetensors"), 0.6),
    ]
    for sub, name, exp_gb in wanted:
        p = os.path.join(comfy_root, sub, name)
        if not os.path.exists(p):
            rep.add(BAD, f"模型 {name[:38]}", "缺失",
                    f"modelscope download --model Comfy-Org/MiniMax-H3 "
                    f"--local_dir {os.path.join(comfy_root, sub)} {name}")
            continue
        size = human_gb(os.path.getsize(p))
        with open(p, "rb") as f:
            f.seek(os.path.getsize(p) // 2)
            shell = f.read(8) == b"\x00" * 8
        if shell:
            rep.add(BAD, f"模型 {name[:38]}",
                    f"{size:.1f}G 但中间采样全零 = aria2 空壳，数据没真写进去",
                    f"删掉重下（必须用 modelscope SDK，禁止 aria2）: rm {p}")
        elif abs(size - exp_gb) > exp_gb * 0.15:
            rep.add(WARN, f"模型 {name[:38]}",
                    f"{size:.1f}G，与预期 {exp_gb}G 偏差较大（GB/GiB 换算会差约 7%）",
                    "用字节数精确比对魔搭仓库，别只看 ls 数值")
        else:
            rep.add(OK, f"模型 {name[:38]}", f"{size:.1f}G，非零校验通过")


def comfy_object_info(api):
    with urllib.request.urlopen(api + "/object_info", timeout=15) as r:
        return json.loads(r.read())


def check_comfy(rep, api):
    print("\n--- 四、ComfyUI 服务 ---")
    try:
        info = comfy_object_info(api)
        rep.add(OK, "ComfyUI API", f"{api} 已连通，已注册 {len(info)} 类节点")
        return info
    except Exception as e:
        rep.add(BAD, "ComfyUI API", f"{api} 连不上: {e}",
                "cd <COMFY_ROOT> && python main.py --listen 127.0.0.1 --port 8188")
        return None


def check_workflow(rep, wf_path, info, comfy_root):
    print("\n--- 五、工作流模板 ---")
    if not wf_path or not os.path.exists(wf_path):
        rep.add(BAD, "工作流文件", f"找不到: {wf_path}",
                "用 scripts/workflows/r2v_video.json（满配）或 r2v_video_turbo.json（提速）")
        return
    try:
        wf = json.load(open(wf_path, encoding="utf-8"))
    except Exception as e:
        rep.add(BAD, "工作流文件", f"JSON 解析失败: {e}", "重新下载模板文件")
        return
    rep.add(OK, "工作流文件", f"{os.path.basename(wf_path)}，{len(wf)} 个节点")

    if info is None:
        rep.add(WARN, "节点注册校验", "ComfyUI 未连通，跳过（连上后重跑本项最关键）")
    else:
        miss = []
        for nid, node in wf.items():
            ct = node.get("class_type")
            if ct not in info:
                miss.append(f"{nid}:{ct}")
        if miss:
            rep.add(BAD, "节点注册校验",
                    f"{len(miss)} 个节点类型在你的 ComfyUI 里不存在: {', '.join(miss[:5])}",
                    "多半是 ComfyUI 版本不够（需 0.33+ 定制版才支持 nvfp4/H3 节点），"
                    "或用 marduk191 定制版源码覆盖 comfy/ 后清 __pycache__")
        else:
            rep.add(OK, "节点注册校验",
                    f"全部 {len(wf)} 个节点的类型均已注册，可以提交")

    if not comfy_root or not os.path.isdir(comfy_root):
        return
    fdir = {"UNETLoader": "models/diffusion_models", "CLIPLoader": "models/text_encoders",
            "VAELoader": "models/vae", "LoraLoaderModelOnly": "models/loras"}
    for nid, node in wf.items():
        ct = node.get("class_type")
        if ct in fdir:
            key = {"UNETLoader": "unet_name", "CLIPLoader": "clip_name",
                   "VAELoader": "vae_name", "LoraLoaderModelOnly": "lora_name"}[ct]
            fname = node.get("inputs", {}).get(key)
            if fname and not os.path.exists(os.path.join(comfy_root, fdir[ct], fname)):
                rep.add(BAD, f"节点 {nid} {ct}",
                        f"引用的模型文件不存在: {fname}",
                        f"下载到 {fdir[ct]}/，或改工作流里的文件名")

    for nid, node in wf.items():
        for key, val in node.get("inputs", {}).items():
            if isinstance(val, str) and val.startswith("CHANGE_ME"):
                rep.add(WARN, f"节点 {nid}",
                        f"字段 {key} 还是占位符 {val}，提交前必须替换",
                        "用 h3_prepare_inputs.py 自动生成 pairs.json 并交给 runner 填充")


def check_inputs(rep, wf_path, videos_dir, images_dir):
    print("\n--- 六、输入素材 ---")
    if videos_dir and os.path.isdir(videos_dir):
        vids = [f for f in os.listdir(videos_dir)
                if f.lower().endswith((".mp4", ".mov", ".webm"))]
        if not vids:
            rep.add(BAD, "参考视频", f"{videos_dir} 里没有视频文件",
                    "把参考视频实体复制进来（软链不被识别），复制后重启 ComfyUI")
        else:
            over = []
            for f in vids:
                d = probe_duration(os.path.join(videos_dir, f))
                if d and d > 15.0:
                    over.append(f"{f}({d:.1f}s)")
            if over:
                rep.add(BAD, "参考视频",
                        f"共 {len(vids)} 个，其中 {len(over)} 个超过 15s 上限: "
                        f"{', '.join(over[:3])}",
                        "ffmpeg -y -v error -i in.mp4 -t 14.2 -c copy out.mp4（H3 限 360 帧）")
            else:
                rep.add(OK, "参考视频", f"{len(vids)} 个，时长均合规（<=15s）")
    elif videos_dir:
        rep.add(BAD, "参考视频", f"目录不存在: {videos_dir}", "改 h3_config.env 的 VIDEOS_DIR")

    if images_dir and os.path.isdir(images_dir):
        imgs = [f for f in os.listdir(images_dir)
                if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
        rep.add(OK if imgs else BAD, "定妆照",
                f"{len(imgs)} 张" if imgs else "目录里没有图片",
                "" if imgs else "放入全身正面定妆照；多视图拼图需先裁中间列")
    elif images_dir:
        rep.add(BAD, "定妆照", f"目录不存在: {images_dir}", "改 h3_config.env 的 IMAGES_DIR")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", help="h3_config.env 路径")
    ap.add_argument("--comfy-root", dest="comfy_root", help="ComfyUI 根目录（覆盖配置）")
    ap.add_argument("--workflow", help="工作流 JSON 路径（覆盖配置）")
    ap.add_argument("--videos-dir", dest="videos_dir", help="参考视频目录（覆盖配置）")
    ap.add_argument("--images-dir", dest="images_dir", help="定妆照目录（覆盖配置）")
    args = ap.parse_args()

    cfg = load_config(args.config)
    comfy_root = args.comfy_root or cfg.get("COMFY_ROOT", "")
    api = cfg.get("COMFY_API", "http://127.0.0.1:8188")
    wf = args.workflow or cfg.get("WORKFLOW", "")
    if wf and not os.path.isabs(wf):
        # 依次按「配置文件目录」「脚本目录」找，用户把配置拷到别处也不会断
        cands = []
        if args.config:
            cands.append(os.path.join(os.path.dirname(os.path.abspath(args.config)), wf))
        cands.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), wf))
        wf = next((c for c in cands if os.path.exists(c)), cands[0])
    videos_dir = args.videos_dir or cfg.get("VIDEOS_DIR", "")
    images_dir = args.images_dir or cfg.get("IMAGES_DIR", "")
    if not args.config:
        print("[??] 未指定 --config，仅用命令行参数；建议 cp h3_config.env 改成本机路径")

    print("=" * 62)
    print(" H3 视频工厂 · 60 秒自检")
    print("=" * 62)

    rep = Report()
    check_env(rep)
    check_disk(rep, comfy_root)
    check_models(rep, comfy_root, cfg)
    info = check_comfy(rep, api)
    check_workflow(rep, wf, info, comfy_root)
    check_inputs(rep, wf, videos_dir, images_dir)

    print("\n" + "=" * 62)
    if rep.failed:
        print(f" 体检完成：{len(rep.failed)} 项不通过，按上方「修复」提示处理后重跑")
        print(" 建议：先跑通 1 条再批量（python h3_runner.py --only 1）")
        sys.exit(1)
    print(" 体检完成：全部通过，可以开始出片")
    print(" 下一步：python h3_prepare_inputs.py 生成 pairs.json，再交给 runner 批量跑")
    print("=" * 62)


if __name__ == "__main__":
    main()
