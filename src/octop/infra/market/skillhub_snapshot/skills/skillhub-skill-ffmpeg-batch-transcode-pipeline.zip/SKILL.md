---
name: skillhub-skill-ffmpeg-batch-transcode-pipeline
description: "通过NVENC、VAAPI或VideoToolbox进行硬件加速编码，编排并行FFmpeg转码作业。使用ffmpeg -f hls支持HLS自适应码率封装，包含多个-map流和fmp4分段格式化以用于DASH输出。"
---

# FFmpeg 批量转码流水线

Orchestrates parallel FFmpeg transcoding jobs with hardware-accelerated encoding via NVENC, VAAPI, or VideoToolbox. Supports HLS adaptive bitrate packaging using ffmpeg -f hls with multiple -map streams and fmp4 segment formatting for DASH output.

## Installation

No source-backed install or usage instructions could be extracted automatically. Review the upstream project before running this skill in a sensitive workflow.

- Source: https://github.com/1991513ccie-png/skills
