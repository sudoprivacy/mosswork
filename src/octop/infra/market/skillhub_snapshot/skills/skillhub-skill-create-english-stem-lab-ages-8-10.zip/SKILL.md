---
name: skillhub-skill-create-english-stem-lab-ages-8-10
description: "为8–10岁、以中文为母语的儿童，把数学、科学、地理、技术和工程知识点制作成英语 STEM 互动课，交付可独立打开的 HTML、拖拽分类或排序实验、可旋转的2.5D结构图、双语术语支架、即时检查和个性化知识点扩展。用于家长或老师制作海外课程风格的探究课、预习复习材料和兴趣项目；不替代正式实验安全指导，不采集儿童个人信息，也不声称未经核对的课程认证或官方对齐。"
---

# 8–10岁英语 STEM 互动实验室

## 不可变交付合同

开始设计前必须完整读取 `references/lesson-contract.md`。`lesson.json` 的根对象必须直接包含以下字段，名称不得改写、嵌套或替换：

`title`、`age`、`english_level`、`subject`、`duration_minutes`、`knowledge_points`、`objectives`、`vocabulary`、`visual_model`、`interactions`、`checks`、`bilingual_support`、`privacy_mode`。

不要改成 `learner.age`、`learning_objectives`、`target_language.vocabulary` 或包在 `lesson` 对象中。可以增加字段，但不能缺少或重命名上述字段。默认同时交付 `lesson.json` 与 `lesson.html`；若用户只要求聊天内方案，仍须给出符合该根结构的 JSON，并写清 HTML 的拖拽、旋转和键盘操作设计。交付前必须让校验脚本通过。

## 工作流

1. 收集年龄、英语水平、学科、知识点、已有误区、兴趣、课程时长、单位制和目标课程体系。信息不全时，默认按9岁、A1、18分钟、国际英语和公制处理。
2. 将输入整理为2–4个递进知识点，并列出：
   - 学科目标；
   - 学术英语目标；
   - 一个可观察或可操作的问题；
   - 一个需要纠正的常见误区。
3. 建立事实底稿。涉及数字、单位、地理边界、科学过程或课程标准时，保留来源和核对日期；不要用流行类比替代准确概念。
4. 按以下结构设计：
   - `Mission`：提出一个真实问题。
   - `Key Language`：给6–12个术语、儿童英文定义和按需中文提示。
   - `Interactive Model`：用2–7层可旋转结构解释组成、系统、循环、比例或空间关系。
   - `Drag Lab`：至少一个分类、配对、排序、标注或变量选择任务。
   - `Explain Your Choice`：要求使用句架说明理由。
   - `Check & Transfer`：3–5题检查，并把知识迁移到新情境。
5. 按 `references/lesson-contract.md` 生成 `lesson.json` 和离线单文件 `lesson.html`。同时支持触摸、鼠标和键盘操作。
6. 运行：
   `python3 scripts/validate_lesson.py lesson.json`
   修复所有错误后再交付。
7. 附上家长/老师卡：知识点、关键术语、孩子可能卡住的位置、可追加的下一个知识点。

## 教学设计要求

- 英语承担学科学习功能，不要先把整课翻成中文再附英文词汇。
- 允许中文作为按需支架；默认先显示英文，点击后再显示中文解释。
- 每个互动都要服务一个明确知识点，不添加与目标无关的小游戏。
- 对真实实验给出成人陪同、材料和风险提示；不得建议儿童独自接触火、电、药品、锋利器具或未知化学品。
- 不要求注册、上传照片/录音、输入学校或联系方式；不嵌入广告、分析脚本或外链聊天。

## 课程对齐

- 用户未指定体系时，采用课程中性、可迁移的核心概念。
- 用户指定新西兰、澳大利亚或英格兰课程时，先读 `references/curriculum-routing.md` 并检查当前官方版本。
- 把“参考某课程的年龄段与主题顺序”和“获得官方认证”严格区分；不得暗示后者。
