import unittest

from validate_lesson import validate_lesson


def valid_lesson():
    return {
        "title": "Build the Water Cycle",
        "age": 9,
        "english_level": "A1",
        "subject": "science",
        "duration_minutes": 18,
        "knowledge_points": ["Water changes state", "Water moves in a cycle"],
        "objectives": ["Order three water-cycle processes."],
        "vocabulary": [
            {
                "term": "evaporation",
                "definition_en": "Liquid water changes into water vapour.",
                "hint_zh": "蒸发",
            }
        ],
        "visual_model": {
            "type": "layered-2.5d",
            "rotation_control": True,
            "layers": ["sea", "vapour", "cloud", "rain"],
        },
        "interactions": [
            {"type": "drag_drop", "goal": "Build the cycle.", "keyboard_alternative": True},
            {"type": "sequence", "goal": "Order the steps.", "keyboard_alternative": True},
        ],
        "checks": [{"prompt": "Why do clouds form?", "answer": "Vapour cools."}],
        "bilingual_support": {"hint_mode": "tap-to-reveal"},
        "privacy_mode": "no-personal-data",
    }


class LessonValidationTest(unittest.TestCase):
    def test_accepts_valid_lesson(self):
        self.assertTrue(validate_lesson(valid_lesson())["valid"])

    def test_rejects_wrong_age(self):
        lesson = valid_lesson()
        lesson["age"] = 7
        with self.assertRaisesRegex(ValueError, "age must"):
            validate_lesson(lesson)

    def test_requires_keyboard_alternative(self):
        lesson = valid_lesson()
        lesson["interactions"][0]["keyboard_alternative"] = False
        with self.assertRaisesRegex(ValueError, "keyboard_alternative"):
            validate_lesson(lesson)


if __name__ == "__main__":
    unittest.main()

