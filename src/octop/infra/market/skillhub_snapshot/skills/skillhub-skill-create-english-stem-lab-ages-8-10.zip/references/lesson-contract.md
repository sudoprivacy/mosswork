# 课程数据合同（8–10岁）

生成 UTF-8 JSON 对象，至少包含：

```json
{
  "title": "Build the Water Cycle",
  "age": 9,
  "english_level": "A1",
  "subject": "science",
  "duration_minutes": 18,
  "knowledge_points": ["Water changes state", "Water moves in a cycle"],
  "objectives": ["Order evaporation, condensation and precipitation."],
  "vocabulary": [
    {"term": "evaporation", "definition_en": "Liquid water changes into water vapour.", "hint_zh": "蒸发"}
  ],
  "visual_model": {
    "type": "layered-2.5d",
    "rotation_control": true,
    "layers": ["sea", "vapour", "cloud", "rain"]
  },
  "interactions": [
    {"type": "drag_drop", "goal": "Put each process in the cycle.", "keyboard_alternative": true},
    {"type": "sequence", "goal": "Explain what happens next.", "keyboard_alternative": true}
  ],
  "checks": [{"prompt": "Why do clouds form?", "answer": "Water vapour cools and condenses."}],
  "bilingual_support": {"hint_mode": "tap-to-reveal"},
  "privacy_mode": "no-personal-data"
}
```

约束：

- `age` 必须为8–10。
- `knowledge_points` 保持2–4个；`duration_minutes` 保持12–25分钟。
- 至少一个 `drag_drop` 互动；优先再加入 `sequence`、`classify`、`label` 或 `variable`.
- `visual_model.layers` 至少2层，并提供旋转控制。
- 互动反馈要求学生说明选择理由，不能只显示对错。
- HTML 使用原生 HTML/CSS/JavaScript并内联资源；不要联网、登录或追踪。
- 同时支持触摸、鼠标、键盘和“减少动态效果”系统设置。

