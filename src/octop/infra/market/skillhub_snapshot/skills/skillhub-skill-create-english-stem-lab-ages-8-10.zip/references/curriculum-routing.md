# 课程与语言等级路由

只在用户要求课程对齐时读取并核对当前版本：

- 新西兰课程官方入口：https://newzealandcurriculum.tahurangi.education.govt.nz/
- 新西兰数学与统计 Years 0–10：https://newzealandcurriculum.tahurangi.education.govt.nz/new-zealand-curriculum-online/new-zealand-curriculum/current-curriculum-documents/nzc---mathematics-and-statistics-years-0-8/5637289330.p
- 英格兰国家课程：https://www.gov.uk/government/collections/national-curriculum
- 澳大利亚课程 Version 9：https://v9.australiancurriculum.edu.au/
- CEFR Companion Volume：https://www.coe.int/en/web/common-european-framework-reference-languages/cefr-companion-volume-and-its-language-versions

路由规则：

1. 先按孩子的学科先备知识和英语水平定难度，再映射海外课程阶段。
2. CEFR只描述语言使用能力，不代表STEM掌握程度。
3. 新西兰课程处于分阶段更新期；生成时核对实施年份，草案不得写成现行强制内容。
4. 明确写“参考/映射”还是“逐条对齐”；不暗示官方认证。
5. 对单位、拼写和术语按目标地区本地化，但保持同一科学事实。

