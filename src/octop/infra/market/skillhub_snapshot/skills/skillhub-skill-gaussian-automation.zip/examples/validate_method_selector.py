"""
method_selector 推荐器验证脚本（v1.6.0 新增）
=============================================

两部分，互不依赖：

1. **推荐逻辑回归**（默认执行，纯 Python，无需 Gaussian）
   对「任务 × 分子类型 × 尺寸 × 环境」的组合断言推荐结果是否符合预期：
   基组降配是否触发、弥散函数是否自动补、U 前缀是否自动加、色散是否被正确跳过等。

2. **关键字真机可用性的体现**（可选，``--real``）
   用推荐矩阵里出现的方法/基组/关键字跑水分子单点，确认本机 Gaussian 是否接受。
   实测结论会写进 SKILL.md 的「推荐矩阵真机可用性」表。

用法：
    python examples/validate_method_selector.py            # 只跑逻辑回归
    python examples/validate_method_selector.py --real     # 追加真机关键字验证
    python examples/validate_method_selector.py --arch x64 # 指定 arch 基准（默认自动探测）

退出码：全部通过 0，否则 1。
"""
from __future__ import annotations

import os
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(_HERE, "..", "references")))

import gaussian_automation as g  # noqa: E402


# ---------------------------------------------------------------------------
# 1. 推荐逻辑回归
# ---------------------------------------------------------------------------
# 每项: (说明, kwargs, 期望字段 dict) —— 期望字段支持 'mb' / 'route_has' / 'route_not'
#      / 'flags_has' / 'warn_substr' / 'opt_contains'
LOGIC_CASES = [
    ("常规有机优化：x64 下走 ωB97X-D/def2-SVP",
     dict(n_atoms=20, molecule="organic", task="opt_freq", arch="x64"),
     {"mb": "wB97XD/def2SVP", "route_has": ["Opt", "Freq"],
      "route_not": ["EmpiricalDispersion=GD3BJ"]}),

    ("同任务在 32 位小体系上限边缘不会偷偷降配",
     dict(n_atoms=20, molecule="organic", task="opt_freq", arch="x86"),
     {"mb": "wB97XD/def2SVP"}),

    ("中等体系 + 32 位 → 自动把 def2-SVP 降配到 6-31G(d) 并给警告",
     dict(n_atoms=45, molecule="organic", task="opt_freq", arch="x86"),
     {"mb": "wB97XD/6-31G(d)", "warn_substr": "降配"}),

    ("超大体系 + 32 位 → 不降成垃圾基组，改为提醒半经验/ONIOM",
     dict(n_atoms=150, molecule="organic", task="opt_freq", arch="x86"),
     {"warn_substr": "不推荐直接上全量子化学层"}),

    ("阴离子 → 自动补弥散函数（def2-SVP → aug-cc-pVDZ）",
     dict(n_atoms=15, molecule="organic", task="opt_freq", charge=-1, arch="x64"),
     {"mb": "wB97XD/aug-cc-pVDZ", "flags_has": ["anion"]}),

    ("开壳层 → 自动加 U 前缀",
     dict(n_atoms=10, molecule="organic", task="opt_freq", mult=2, arch="x64"),
     {"method": "UwB97XD", "route_has": ["SCF=XQC"]}),

    ("过渡金属 → 必须用 def2/LANL2DZ 类赝势基组",
     dict(atoms=["Fe", "N", "N", "C", "C"], n_atoms=25, task="opt", arch="x64"),
     {"mb": "TPSSh/def2SVP", "class": "tm_complex"}),

    ("含 Br 的重元素 → 判为 heavy_element",
     dict(atoms=["C", "H", "H", "H", "Br"], task="opt", arch="x64"),
     {"class": "heavy_element", "basis": "B3LYP/def2SVP"}),

    ("EPR → UB3LYP + EPR-III（x64）",
     dict(n_atoms=5, molecule="organic", task="epr", mult=2, arch="x64"),
     {"mb": "UB3LYP/EPR-III", "route_has": ["NMR"]}),

    ("NMR 属单点物性 → 不额外加 Grimme 色散",
     dict(n_atoms=20, molecule="organic", task="nmr", arch="x64"),
     {"route_not": ["EmpiricalDispersion=GD3BJ"]}),

    ("弱相互作用显式要求色散时可以强制打开",
     dict(n_atoms=20, molecule="organic", task="weak", arch="x64",
          dispersion="gd3bj"),
     {"task": "weak"}),

    ("构象/叠加确有影响时非共价必须色散：默认 cluster 自动带 GD3BJ 或自带",
     dict(n_atoms=20, molecule="cluster", task="weak", arch="x64"),
     {"class": "cluster"}),

    ("溶剂 → 自动追加 SCRF=(PCM,Solvent=...)",
     dict(n_atoms=20, molecule="organic", task="opt_freq", solvent="Water", arch="x64"),
     {"route_has": ["SCRF=(PCM,Solvent=Water)"]}),

    ("热化学 accurate → 复合方法 CBS-QB3（且不带 Opt 关键字）",
     dict(n_atoms=8, molecule="organic", task="thermo", quality="accurate", arch="x64"),
     {"mb": "CBS-QB3", "route_not": ["Opt"]}),

    ("同一任务 fast/standard/accurate 三档必须给出不同组合",
     dict(n_atoms=15, molecule="organic", task="opt_freq", arch="x64"),
     {"tiers_differ": True}),

    ("任务别名（中文）可用",
     dict(n_atoms=20, molecule="organic", task="红外", arch="x64"),
     {"task": "ir"}),

    ("分子别名（中文）可用",
     dict(n_atoms=20, molecule="金属配合物", task="opt", arch="x64"),
     {"class": "tm_complex"}),

    ("biopolymer 且量大 → fast 档直接给半经验",
     dict(n_atoms=200, molecule="biopolymer", task="conformer", quality="fast", arch="x64"),
     {"method": "PM6"}),
]


def check_logic(arch_base: str | None) -> int:
    print("=" * 72)
    print("推荐逻辑回归（无需 Gaussian）")
    print("=" * 72)
    failures = 0

    for title, kwargs, expect in LOGIC_CASES:
        kw = dict(kwargs)
        if "arch" in kw and kw.get("arch") == "auto":
            kw["arch"] = arch_base
        elif "arch" not in kw:
            kw["arch"] = arch_base
        try:
            r = g.recommend_method(**kw)
        except Exception as exc:
            print(f"  [FAIL] {title}\n        异常: {type(exc).__name__}: {exc}")
            failures += 1
            continue

        problems = []
        for key, want in expect.items():
            if key == "tiers_differ":
                mbs = set()
                for q in ("fast", "standard", "accurate"):
                    k2 = dict(kw)
                    k2["quality"] = q
                    mbs.add(g.recommend_method(**k2)["mb"])
                if len(mbs) < 2:
                    problems.append(f"三档组合未区分: {mbs}")
                continue
            if key == "class":
                got = r["molecule"]
            elif key == "method":
                got = r["method"]
            elif key == "basis":
                got = r["basis"]
            elif key == "mb":
                got = r["mb"]
            elif key == "task":
                got = r["task"]
            elif key == "route_has":
                missing = [w for w in want if w not in r["route"]]
                if missing:
                    problems.append(f"路由缺少 {missing}")
                continue
            elif key == "route_not":
                bad = [w for w in want if w in r["route"]]
                if bad:
                    problems.append(f"路由不该含 {bad}")
                continue
            elif key == "flags_has":
                missing = [w for w in want if w not in r["molecule_flags"]]
                if missing:
                    problems.append(f"缺少标记 {missing}")
                continue
            elif key == "warn_substr":
                allwarn = " | ".join(r["warnings"])
                if want not in allwarn:
                    problems.append(f"警告未出现 {want!r}（实际: {allwarn[:120]}）")
                continue
            else:
                got = r.get(key)

            if isinstance(want, str) and key == "basis":
                # 允许 "方法/基组" 形式直接比对
                got = f"{r['method']}/{r['basis']}" if r["basis"] else r["method"]
            if got != want:
                problems.append(f"{key} 期望 {want!r} 实得 {got!r}")

        if problems:
            failures += 1
            print(f"  [FAIL] {title}")
            for p in problems:
                print(f"         {p}")
            print(f"         实际: mb={r['mb']}  route={r['route']}")
        else:
            print(f"  [ OK ] {title}\n         {r['route']}")

    print()
    print(f"逻辑回归：{len(LOGIC_CASES) - failures}/{len(LOGIC_CASES)} 通过")
    return failures


# ---------------------------------------------------------------------------
# 2. 关键字真机可用性
# ---------------------------------------------------------------------------
WATER = (["O", "H", "H"],
         [[0.0, 0.0, 0.1173], [0.0, 0.757, -0.4692], [0.0, -0.757, -0.4692]])
OH = (["O", "H"], [[0.0, 0.0, 0.0], [0.0, 0.0, 0.97]])
CH3BR = (["C", "H", "H", "H", "Br"],
         [[0.0, 0.0, 0.0], [0.5, 0.9, 0.0], [-0.5, 0.9, 0.0],
          [0.0, -0.5, 0.8], [0.0, 0.0, 1.94]])

# 说明：expect_ok=False 的项记录「本机构建确实不支持」，推荐器已在 METHOD_INFO 里标注。
REAL_CASES = [
    ("B3LYP-GD3BJ 色散关键字",     "# B3LYP/6-31G(d) EmpiricalDispersion=GD3BJ",   WATER,  0, 1, True),
    ("ωB97X-D/def2-SVP",           "# wB97XD/def2SVP",                             WATER,  0, 1, True),
    ("M06-2X/6-311+G(d,p)",        "# M062X/6-311+G(d,p) Int=UltraFine",           WATER,  0, 1, True),
    ("CAM-B3LYP TD-DFT",           "# CAM-B3LYP/6-311+G(d,p) TD=(NStates=3)",      WATER,  0, 1, True),
    ("B3LYP/def2-TZVP",            "# B3LYP/def2TZVP",                             WATER,  0, 1, True),
    ("B3LYP/aug-cc-pVDZ",          "# B3LYP/aug-cc-pVDZ",                          WATER,  0, 1, True),
    ("B3LYP/aug-cc-pVTZ",          "# B3LYP/aug-cc-pVTZ",                          WATER,  0, 1, True),
    ("B3LYP/6-311++G(2d,p)",       "# B3LYP/6-311++G(2d,p)",                       WATER,  0, 1, True),
    ("NMR=GIAO",                   "# B3LYP/6-311+G(d,p) NMR=GIAO",                WATER,  0, 1, True),
    ("NMR=(GIAO,SpinSpin)",        "# B3LYP/6-311+G(d,p) NMR=(GIAO,SpinSpin)",     WATER,  0, 1, True),
    ("TPSSh/def2-SVP",             "# TPSSh/def2SVP",                              WATER,  0, 1, True),
    ("PBE1PBE/def2-SVP",           "# PBE1PBE/def2SVP",                            WATER,  0, 1, True),
    ("PBE0（本机构建不识别 → 失败）", "# PBE0/def2SVP",                              WATER,  0, 1, False),
    ("B2PLYP 双杂化",               "# B2PLYP/6-31G(d)",                            WATER,  0, 1, True),
    ("APFD（实测 g09 D.01 可用）",   "# APFD/6-31G(d)",                              WATER,  0, 1, True),
    ("PM6 半经验",                  "# PM6 Opt",                                    WATER,  0, 1, True),
    ("PM7（G16-only，预期失败）",    "# PM7 Opt",                                    WATER,  0, 1, False),
    ("CBS-QB3 复合方法",            "# CBS-QB3",                                    WATER,  0, 1, True),
    ("G4 复合方法",                 "# G4",                                         WATER,  0, 1, True),
    ("LANL2DZ 赝势（CH3Br）",       "# B3LYP/LANL2DZ",                              CH3BR, 0, 1, True),
    ("SDD 赝势（CH3Br）",           "# B3LYP/SDD",                                  CH3BR, 0, 1, True),
    ("MP2/aug-cc-pVDZ",            "# MP2/aug-cc-pVDZ",                            WATER,  0, 1, True),
    ("UB3LYP/EPR-III NMR（自由基）", "# UB3LYP/EPR-III NMR",                        OH, 0, 2, True),
]


def check_real() -> int:
    print("=" * 72)
    print("关键字真机可用性验证（需要本机 Gaussian）")
    print("=" * 72)

    info = g.find_gaussian()
    if not info["found"]:
        print("  未探测到本机 Gaussian，跳过真机验证。")
        return 0
    print(f"  本机 Gaussian: {info['exe']}  arch={info.get('arch')}\n")

    os.environ.update({
        "GAUSS_EXEDIR": info["exedir"],
        ("g09root" if info["family"] == "g09" else "g16root"): info["root"],
        "GAUSS_SCRDIR": tempfile.mkdtemp(prefix="gauss_scr_"),
        "PATH": info["exedir"] + ";" + os.environ.get("PATH", ""),
    })
    mem = "1000MB" if info.get("arch") == "x86" else "2GB"
    out_dir = tempfile.mkdtemp(prefix="msel_out_")

    failures = 0
    for label, route, (atoms, coords), charge, mult, expect_ok in REAL_CASES:
        gjf = os.path.join(tempfile.gettempdir(), "msel_probe.gjf")
        g.write_gjf(gjf, atoms, coords, charge=charge, mult=mult,
                    route=route, mem=mem, nproc=1, title=label)
        try:
            res = g.run_and_save(gjf, out_dir=out_dir, timeout=900)
            ok = bool(res.get("ok"))
        except Exception as exc:
            print(f"  [EXCEPTION] {label}: {type(exc).__name__}: {exc}")
            failures += 1
            continue
        passed = (ok == expect_ok)
        mark = "OK " if passed else "FAIL"
        if not passed:
            failures += 1
        tail = "（预期失败，符合）" if (not expect_ok and not ok) else ""
        print(f"  [{mark}] {label:<28} ok={ok} rc={res.get('returncode')} {tail}")
        if not ok and expect_ok:
            logtxt = ""
            try:
                logtxt = open(res["log"], encoding="utf-8", errors="ignore").read()
            except Exception:
                pass
            err = [ln for ln in logtxt.splitlines() if "Error" in ln or "QPErr" in ln]
            if err:
                print(f"         末条错误: {err[-1][:120]}")

    print()
    print(f"真机关键字验证：{len(REAL_CASES) - failures}/{len(REAL_CASES)} 符合预期")
    return failures


if __name__ == "__main__":
    arg_arch = None
    real = False
    for a in sys.argv[1:]:
        if a == "--real":
            real = True
        elif a == "--arch":
            pass
        elif a.isdigit():
            pass
    # 简易参数解析：--arch x64
    if "--arch" in sys.argv:
        i = sys.argv.index("--arch")
        if i + 1 < len(sys.argv):
            arg_arch = sys.argv[i + 1]

    bad = check_logic(arg_arch)
    if real:
        bad += check_real()
    sys.exit(1 if bad else 0)
