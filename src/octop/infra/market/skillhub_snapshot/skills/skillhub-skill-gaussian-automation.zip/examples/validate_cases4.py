"""
Gaussian 自动化 skill —— 第四批 10 复杂案例 回归测试（v1.7.0）
====================================================================

不依赖 Gaussian：直接解析 cases4.py 在本机 32 位 g09 D.01 真机产出的 10 份
.log，断言本次为 parser 扩展新增的 9 个字段、断键对称破缺 J 计算、以及
非平衡 PCM 标记等均被正确解析。用于 CI / 复跑时快速发现解析回退。

字段覆盖：
  oniom_energies  md_trajectory  s2  pcm_nonequilibrium  nto_occupations
  nbo_e2  hirshfeld_charges  scan2d  ccsd_t_energy

构建限制（本机 32 位 g09 D.01）的两个案例按“预期 None / rc=1”断言：
  oniom  —— L101 FFGetT bug，无法解析层标记原子名 -> oniom_energies 为 None
  nto    —— 本构建不打印 NTO 块（需 G16）           -> nto_occupations 为 None

用法：
    python validate_cases4.py
退出码 0 = 全部通过；非 0 = 有断言失败。
"""
from __future__ import annotations

import os
import sys

SKILL_REF = r"C:/Users/Eric Ye/.workbuddy/skills/gaussian-automation/references"
sys.path.insert(0, SKILL_REF)

import gaussian_automation as g
from gaussian_automation import recipes  # CASE_CATALOG

# 指向 cases4.py 的输出目录（真机日志所在）
OUT_ROOT = r"C:/Users/Eric Ye/WorkBuddy/2026-10-11-16-38-20/gaussian_cases/cases4"

# 每个案例对应的真机日志路径（与 cases4.py 的 out_dir / 文件名一致）
LOG_MAP = {
    "oniom":      os.path.join(OUT_ROOT, "oniom", "oniom.log"),
    "admp":       os.path.join(OUT_ROOT, "admp", "admp.log"),
    "bs_dft_hs":  os.path.join(OUT_ROOT, "bs_dft", "o2_hs.log"),
    "bs_dft":     os.path.join(OUT_ROOT, "bs_dft", "o2_bs.log"),
    "noneq_pcm":  os.path.join(OUT_ROOT, "noneq_pcm", "noneq_pcm_emission.log"),
    "nto":        os.path.join(OUT_ROOT, "nto", "nto.log"),
    "nbo_e2":     os.path.join(OUT_ROOT, "nbo_e2", "nbo_e2.log"),
    "scan2d":     os.path.join(OUT_ROOT, "scan2d", "scan2d.log"),
    "hirshfeld":  os.path.join(OUT_ROOT, "hirshfeld", "hirshfeld.log"),
    "link1":      os.path.join(OUT_ROOT, "link1", "link1.log"),
    "ccsd_t":     os.path.join(OUT_ROOT, "ccsd_t", "ccsd_t.log"),
}

PASS, FAIL = 0, 0


def check(name: str, cond: bool, detail: str = ""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}" + (f"  ({detail})" if detail else ""))
    else:
        FAIL += 1
        print(f"  FAIL  {name}" + (f"  ({detail})" if detail else ""))


def parse(key: str):
    p = LOG_MAP[key]
    if not os.path.exists(p):
        print(f"  [skip] 日志缺失: {p}")
        return None
    return g.parse_log(p)


def main():
    print(f"[setup] skill version = {g.__version__}")
    print(f"[setup] OUT_ROOT = {OUT_ROOT}")

    # ---- 0) 配方目录完整性 ----
    print("\n[0] CASE_CATALOG 第四批 10 案例")
    for k in ["oniom", "admp", "bs_dft", "noneq_pcm", "nto",
              "nbo_e2", "scan2d", "hirshfeld", "link1", "ccsd_t"]:
        check(f"recipe '{k}' 存在", k in recipes.CASE_CATALOG,
              recipes.CASE_CATALOG.get(k, {}).get("title", ""))
    check("版本号 == 1.7.0", g.__version__ == "1.7.0", g.__version__)
    check("oniom g09_d01_ok == False", recipes.CASE_CATALOG["oniom"].get("g09_d01_ok") is False)
    check("nto   g09_d01_ok == False", recipes.CASE_CATALOG["nto"].get("g09_d01_ok") is False)

    # ---- 1) ADMP：分子动力学轨迹 ----
    print("\n[1] ADMP 轨迹")
    d = parse("admp")
    if d:
        mt = d.get("md_trajectory")
        check("md_trajectory 为非空列表", isinstance(mt, list) and len(mt) > 0)
        if mt:
            ok_pairs = all(isinstance(p, (list, tuple)) and len(p) == 2
                           and isinstance(p[0], int) and isinstance(p[1], float) for p in mt)
            check("每条轨迹为 (步, 能量) 且能量为 float", ok_pairs)
            es = [p[1] for p in mt]
            check("轨迹能量在 [-77,-76] Ha 区间", all(-77 < e < -76 for e in es),
                  f"末步 E={es[-1]:.6f}")
        check("admp 正常终止", d.get("normal_termination") is True)

    # ---- 2) 断键对称破缺：<S²> 与 J ----
    print("\n[2] Broken-Symmetry 反铁磁耦合")
    dhs = parse("bs_dft_hs")
    dbs = parse("bs_dft")
    if dhs and dbs:
        s2_hs = dhs.get("s2")
        s2_bs = dbs.get("s2")
        check("HS <S**2> 近 2.0（三重态）", s2_hs is not None and abs(s2_hs - 2.0) < 0.2,
              f"S2_HS={s2_hs}")
        check("BS <S**2> 近 0（破缺单重态）", s2_bs is not None and s2_bs < 1.0,
              f"S2_BS={s2_bs}")
        e_hs = dhs.get("scf_energy")
        e_bs = dbs.get("scf_energy")
        if None not in (e_hs, e_bs, s2_hs, s2_bs):
            J = (e_bs - e_hs) / (s2_hs - s2_bs)
            check("J_AB 有限且物理（|J|<50 kcal/mol）", abs(J * 627.509) < 50,
                  f"J={J*627.509:+.2f} kcal/mol")
        check("bs_dft 正常终止", dbs.get("normal_termination") is True)

    # ---- 3) 非平衡 PCM 荧光 ----
    print("\n[3] 非平衡 PCM 发射")
    d = parse("noneq_pcm")
    if d:
        check("pcm_nonequilibrium == True", d.get("pcm_nonequilibrium") is True)
        st = d.get("excited_states") or []
        check("excited_states 非空", len(st) > 0, f"{len(st)} 态")
        if st:
            check("S1 为有限能量 (eV)", isinstance(st[0][2], (int, float)) and 0 < st[0][2] < 15,
                  f"S1={st[0][2]:.3f} eV")
        check("noneq_pcm 正常终止", d.get("normal_termination") is True)

    # ---- 4) NTO（构建限制：应为 None） ----
    print("\n[4] NTO（本机构建限制）")
    d = parse("nto")
    if d:
        check("nto_occupations 为 None（需 G16）", d.get("nto_occupations") is None)
        check("nto 仍能正常终止（路由被接受）", d.get("normal_termination") is True)

    # ---- 5) NBO E(2) ----
    print("\n[5] NBO E(2)")
    d = parse("nbo_e2")
    if d:
        check("nbo_e2 为列表字段", isinstance(d.get("nbo_e2"), list))
        check("nbo_charges 非空", bool(d.get("nbo_charges")))
        check("nbo_e2 正常终止", d.get("normal_termination") is True)

    # ---- 6) 2D 扫描（关键：修复前能量跨度 ~89.6 Ha 的解析 bug） ----
    print("\n[6] 2D 势能面扫描")
    d = parse("scan2d")
    if d:
        s2d = d.get("scan2d")
        check("scan2d 为非空列表", isinstance(s2d, list) and len(s2d) > 0)
        if s2d:
            n = len(s2d)
            es = [p[1] for p in s2d]
            ok_pts = all(isinstance(p, (list, tuple)) and len(p) == 2
                         and isinstance(p[0], list) and isinstance(p[1], float) for p in s2d)
            check("每条为 (坐标列表, 能量)", ok_pts, f"{n} 点")
            # 水的 2D 扫描能量应全在 ~-76 Ha 附近，跨度远小于 1 Ha
            check("网格点能量跨度 < 1 Ha（修复前为 89.6）",
                  (max(es) - min(es)) < 1.0, f"span={max(es)-min(es):.5f} Ha")
            check("能量在 [-77,-76] Ha 区间", all(-77 < e < -76 for e in es))
        check("scan2d 优化收敛", d.get("converged") is True)

    # ---- 7) Hirshfeld 电荷 ----
    print("\n[7] Hirshfeld 电荷")
    d = parse("hirshfeld")
    if d:
        hc = d.get("hirshfeld_charges")
        check("hirshfeld_charges 为非空列表", isinstance(hc, list) and len(hc) > 0)
        if hc:
            ok_q = all(isinstance(x, (list, tuple)) and len(x) == 2
                       and isinstance(x[1], float) for x in hc)
            check("每条为 (符号, 电荷)", ok_q)
            # 水分子：O 带负、H 带正
            syms = [x[0] for x in hc]
            sign_ok = ("O" in syms and "H" in syms)
            check("含 O 与 H 原子", sign_ok, ",".join(syms))
        check("hirshfeld 正常终止", d.get("normal_termination") is True)

    # ---- 8) 多步作业链 LINK1 ----
    print("\n[8] --Link1-- 多步链")
    d = parse("link1")
    if d:
        check("link1 整体正常终止（含 TD 第3步）", d.get("normal_termination") is True)
        st = d.get("excited_states") or []
        check("第3步 TD 产出激发态", len(st) > 0, f"{len(st)} 态")

    # ---- 9) CCSD(T) ----
    print("\n[9] CCSD(T)")
    d = parse("ccsd_t")
    if d:
        e = d.get("ccsd_t_energy")
        check("ccsd_t_energy 为有限 float", isinstance(e, float) and e < 0, f"{e}")
        check("ccsd_t 正常终止", d.get("normal_termination") is True)

    # ---- 10) ONIOM（构建限制：应为 None + rc=1） ----
    print("\n[10] ONIOM（本机构建限制）")
    d = parse("oniom")
    if d:
        check("oniom_energies 为 None（L101 FFGetT bug）", d.get("oniom_energies") is None)
        check("oniom 在本机构建未正常终止（rc=1 预期）", d.get("normal_termination") is False)

    print("\n" + "=" * 60)
    print(f"结果：{PASS} 通过 / {FAIL} 失败")
    print("=" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
