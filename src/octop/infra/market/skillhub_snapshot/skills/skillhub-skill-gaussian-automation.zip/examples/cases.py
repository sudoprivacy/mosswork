"""
Gaussian 自动化 · 5 个综合案例
================================
覆盖四类核心计算，全部通过 gaussian_automation skill 自动完成：
  案例1  HOMO-LUMO 轨道能隙          —— 乙烯  B3LYP/6-31G(d) Opt
  案例2  TDDFT 激发态(UV-Vis)        —— 甲醛  B3LYP/6-31G(d) Opt TD=(NStates=6)
  案例3  过渡态搜索(TS)               —— HCN⇌HNC  B3LYP/6-31G(d) Opt=(QST2) Freq
  案例4  静电势(ESP 拟合电荷)         —— 水    B3LYP/6-31G(d) Pop=MK
  案例5  Opt+Freq+TDDFT+ESP 全流程    —— 苯    B3LYP/6-31G(d) Opt Freq TD=(NStates=5) Pop=MK

本机 Gaussian：D:\\Gaussian09\\G09W\\g09.exe（32 位 IA32，内存须 <= 1.5GB）。
"""
import os
import sys
import datetime

SKILL_REF = r"C:/Users/Eric Ye/.workbuddy/skills/gaussian-automation/references"
sys.path.insert(0, SKILL_REF)

from gaussian_automation import write_gjf, run_and_save, parse_log, find_gaussian, resolve_nprocs

HERE = os.path.dirname(os.path.abspath(__file__))
IN = os.path.join(HERE, "inputs")
OUT = os.path.join(HERE, "results")
os.makedirs(IN, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

# ---------- 本机 Gaussian 自动探测 ----------
info = find_gaussian()
if not info["found"]:
    raise SystemExit("未找到 Gaussian，请先确认安装或显式提供 exe 路径。")
EXE = info["exe"]
ARCH = info.get("arch", "unknown")
MEM = "1500MB" if ARCH == "x86" else "4GB"
# 用户要求使用 75% 逻辑核数；v1.3.0 已取消 32 位核数封顶，arch 仅作信息展示。
NPROC_USER = "75%"
NPROC = resolve_nprocs(NPROC_USER, arch=ARCH)
print(f"Gaussian: {EXE}  arch={ARCH}  -> mem={MEM}, 请求核数={NPROC_USER} 解析={NPROC}核(v1.3.0 已取消32位封顶)")

# 必须把 Gaussian 运行环境注入进程环境（否则内部 Link 找不到 l1.exe 等）
SCR = os.path.join(HERE, "scratch")
os.makedirs(SCR, exist_ok=True)
os.environ.update({
    "GAUSS_EXEDIR": info["exedir"],
    "g09root": info["root"],
    "GAUSS_SCRDIR": SCR,
    "PATH": info["exedir"] + ";" + os.environ.get("PATH", ""),
})

# ---------- 分子坐标（Å） ----------
def fmt_block(atoms, coords):
    return "\n".join(
        f"{s:>2s}    {x:14.8f}{y:14.8f}{z:14.8f}"
        for s, (x, y, z) in zip(atoms, coords)
    )

# 乙烯 C2H4（平面 D2h）
ethylene = (["C", "C", "H", "H", "H", "H"], [
    [0.0, 0.0,  0.6695], [0.0, 0.0, -0.6695],
    [0.0,  0.9289,  1.2321], [0.0, -0.9289,  1.2321],
    [0.0,  0.9289, -1.2321], [0.0, -0.9289, -1.2321],
])
# 甲醛 H2CO（平面）
formaldehyde = (["C", "O", "H", "H"], [
    [0.0, 0.0, 0.0], [0.0, 0.0, 1.21],
    [0.0,  0.939, -0.54], [0.0, -0.939, -0.54],
])
# HCN（反应物，线性）
hcn = (["H", "C", "N"], [[-1.06, 0.0, 0.0], [0.0, 0.0, 0.0], [1.16, 0.0, 0.0]])
# HNC（产物，线性；与反应物保持相同原子顺序 H,C,N，便于 QST2 对齐）
hnc = (["H", "C", "N"], [[-0.99, 0.0, 0.0], [1.17, 0.0, 0.0], [0.0, 0.0, 0.0]])
# 水 H2O（C2v）
water = (["O", "H", "H"], [
    [0.0, 0.0, 0.0], [0.758, 0.586, 0.0], [-0.758, 0.586, 0.0],
])
# 苯 C6H6（平面六元环，程序化）
import math
_benz_a, _benz_b = [], []
for i in range(6):
    t = math.radians(i * 60.0)
    _benz_a.append("C"); _benz_b.append([1.39 * math.cos(t), 1.39 * math.sin(t), 0.0])
for i in range(6):
    t = math.radians(i * 60.0)
    _benz_a.append("H"); _benz_b.append([2.48 * math.cos(t), 2.48 * math.sin(t), 0.0])
benzene = (_benz_a, _benz_b)

report = []
def log(msg):
    print(msg); report.append(str(msg))

def scf_str(d):
    return f"{d['scf_energy']:.6f}" if d.get("scf_energy") is not None else "N/A"

log("=" * 70)
log("Gaussian 自动化 · 5 个综合案例")
log("时间: " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
log(f"Gaussian: {EXE}  arch={ARCH}  mem={MEM} 请求核数={NPROC_USER} 实际={NPROC}核")
log("=" * 70)

# ---------- 案例 1: HOMO-LUMO ----------
log("\n>>> 案例1  HOMO-LUMO 轨道能隙 (乙烯)")
g1 = os.path.join(IN, "ethylene.gjf")
write_gjf(g1, *ethylene, charge=0, mult=1,
          route="# B3LYP/6-31G(d) Opt", title="Ethylene HOMO-LUMO (B3LYP/6-31G(d))",
          mem=MEM, nproc=NPROC, chk="ethylene")
r1 = run_and_save(g1, out_dir=OUT, nprocs=NPROC_USER, make_fchk=True)
d1 = parse_log(r1["log"])
if d1["homo_lumo"]:
    homo, lumo = d1["homo_lumo"]
    log(f"  正常终止={d1['normal_termination']}  收敛={d1['converged']}  SCF={scf_str(d1)}")
    log(f"  HOMO={homo:.4f}  LUMO={lumo:.4f} Hartree  -> 能隙={(lumo-homo)*27.2114:.3f} eV")

# ---------- 案例 2: TDDFT ----------
log("\n>>> 案例2  TDDFT 激发态 (甲醛)")
g2 = os.path.join(IN, "formaldehyde_td.gjf")
write_gjf(g2, *formaldehyde, charge=0, mult=1,
          route="# B3LYP/6-31G(d) Opt TD=(NStates=6)", title="Formaldehyde TDDFT (B3LYP/6-31G(d), 6 states)",
          mem=MEM, nproc=NPROC, chk="formaldehyde_td")
r2 = run_and_save(g2, out_dir=OUT, nprocs=NPROC_USER, make_fchk=True)
d2 = parse_log(r2["log"])
if d2["excited_states"]:
    log(f"  正常终止={d2['normal_termination']}  SCF={scf_str(d2)}")
    for st, lab, ev, nm, f in d2["excited_states"][:6]:
        log(f"  S{st} {lab:12s} {ev:7.3f} eV  {nm:8.1f} nm  f={f:.4f}")
else:
    log(f"  [!] 未解析到激发态 (normal={d2['normal_termination']})")

# ---------- 案例 3: 过渡态 TS 搜索 ----------
log("\n>>> 案例3  过渡态搜索 乙烷 C-C 扭转 (Opt=(TS,CalcFC,MaxCyc=100) Freq)")
g3 = os.path.join(IN, "ethane_ts.gjf")
# Gaussian 手册经典范例：乙烷重叠式（扭转角~0°）即 C-C 旋转过渡态初猜。
# 非共线、PES 简单，Opt=(TS,CalcFC) 稳定收敛；Freq 后恰好 1 个虚频（扭转）即确认 TS。
ts_atoms = ["C", "C", "H", "H", "H", "H", "H", "H"]
ts_coords = [
    [ 0.000, 0.000, 0.000],
    [ 1.540, 0.000, 0.000],
    [-0.363, 1.029, 0.000],
    [-0.363,-0.515, 0.891],
    [-0.363,-0.515,-0.891],
    [ 1.903, 1.029, 0.000],
    [ 1.903,-0.515, 0.891],
    [ 1.903,-0.515,-0.891],
]
write_gjf(g3, ts_atoms, ts_coords, charge=0, mult=1,
          route="# B3LYP/6-31G(d) Opt=(TS,CalcFC,MaxCyc=100) Freq",
          title="Ethane C-C rotation transition state (eclipsed, TS,CalcFC, B3LYP/6-31G(d))",
          mem=MEM, nproc=NPROC, chk="ethane_ts")
r3 = run_and_save(g3, out_dir=OUT, nprocs=NPROC_USER, make_fchk=True)
d3 = parse_log(r3["log"])
log(f"  正常终止={d3['normal_termination']}  收敛={d3['converged']}")
log(f"  虚频数量 n_imag = {d3['n_imaginary']}  -> {'是过渡态' if d3['n_imaginary']==1 and d3['converged'] else '非单一虚频，需核查'}")
if d3["frequencies"]:
    negs = [f for f in d3["frequencies"] if f < 0]
    log(f"  虚频值: {['%.2f'%v for v in negs]} cm^-1")

# ---------- 案例 4: 静电势 ESP ----------
log("\n>>> 案例4  静电势(ESP 拟合电荷) (水)")
g4 = os.path.join(IN, "water_esp.gjf")
write_gjf(g4, *water, charge=0, mult=1,
          route="# B3LYP/6-31G(d) Pop=MK", title="Water ESP (Merz-Kollman) charges, B3LYP/6-31G(d)",
          mem=MEM, nproc=NPROC, chk="water_esp")
r4 = run_and_save(g4, out_dir=OUT, nprocs=NPROC_USER, make_fchk=True)
d4 = parse_log(r4["log"])
log(f"  正常终止={d4['normal_termination']}  SCF={scf_str(d4)}")
if d4["esp_charges"]:
    for s, c in d4["esp_charges"]:
        log(f"    {s}: q(ESP)={c:+.4f}")
else:
    log("  [!] 未解析到 ESP 电荷（建议确认 Pop=MK 是否输出）")

# ---------- 案例 5: 全流程 ----------
log("\n>>> 案例5  全流程 Opt+Freq+TDDFT+ESP (苯)")
g5 = os.path.join(IN, "benzene_all.gjf")
write_gjf(g5, *benzene, charge=0, mult=1,
          route="# B3LYP/6-31G(d) Opt Freq TD=(NStates=5) Pop=MK",
          title="Benzene full workflow (Opt+Freq+TDDFT+ESP), B3LYP/6-31G(d)",
          mem=MEM, nproc=NPROC, chk="benzene_all")
r5 = run_and_save(g5, out_dir=OUT, nprocs=NPROC_USER, make_fchk=True)
d5 = parse_log(r5["log"])
log(f"  正常终止={d5['normal_termination']}  收敛={d5['converged']}  SCF={scf_str(d5)}")
if d5["homo_lumo"]:
    homo, lumo = d5["homo_lumo"]
    log(f"  HOMO-LUMO 能隙={(lumo-homo)*27.2114:.3f} eV  (HOMO={homo:.4f}, LUMO={lumo:.4f})")
log(f"  频率虚频数 n_imag={d5['n_imaginary']}  (0=真实极小点)")
if d5["excited_states"]:
    s1 = d5["excited_states"][0]
    log(f"  TDDFT S1: {s1[2]:.3f} eV ({s1[3]:.1f} nm, f={s1[4]:.4f}, {s1[1]})")
if d5["esp_charges"]:
    log(f"  ESP 电荷(前3): " + " ".join(f"{s}{c:+.3f}" for s, c in d5["esp_charges"][:3]))

log("\n" + "=" * 70)
log("全部案例完成。输入在 inputs/，日志/结果在 results/。")
log("=" * 70)

with open(os.path.join(HERE, "cases_report.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(report) + "\n")
print("\n报告已写入 cases_report.txt")
