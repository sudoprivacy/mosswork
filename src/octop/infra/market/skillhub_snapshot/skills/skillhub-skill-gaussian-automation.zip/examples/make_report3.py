"""
生成第三批 15 案例报告 cases3_report.txt（只读真实 .log，不调 Gaussian）。
"""
from __future__ import annotations
import os
import sys

SKILL_REF = os.path.join(os.path.dirname(__file__), "..", "references")
sys.path.insert(0, os.path.abspath(SKILL_REF))
import gaussian_automation as g

ROOT = sys.argv[1] if len(sys.argv) > 1 else \
    r"C:/Users/Eric Ye/WorkBuddy/2026-09-25-20-46-25/gaussian_cases/cases3"
OUT = os.path.join(ROOT, "cases3_report.txt")

L = []
def p(s=""):
    L.append(s)

p("=" * 72)
p("Gaussian 自动化 skill —— 第三批 15 案例报告（v1.5.0）")
p("环境：Gaussian 09 Rev D.01 32 位 (D:\\Gaussian09\\G09W\\g09.exe)")
p("      %mem=1000MB   nprocs='70%' (16 逻辑核 -> 注入 %nprocshared=11)")
p("生成自 gaussian_cases/cases3/ 下真实 .log 解析结果")
p("=" * 72)
p()
p("总览：新增 15 个配方（配方总数 32）；本机 g09 D.01 跑通 11 项，4 项 G16-only。")
p("  G16-only（本机构建缺模块，rc=2057）：franck_condon / vibronic / eom_ccsd / ecd")
p()

def parse(name):
    d = g.parse_log(os.path.join(ROOT, name))
    return d

# 1. excited_pes
p("-" * 72)
p("1. 激发态势能面 (excited_pes)  —— 甲醛 C=O 伸缩冻结几何 TD 单点扫描")
p("   做法：沿 C=O 键长 1.0->1.5 A 取 6 个几何，各跑 # B3LYP/6-31G(d) TD=(NStates=3) 单点")
for tag in ("ex_pes_1.00", "ex_pes_1.30", "ex_pes_1.50"):
    d = parse(tag + ".log")
    es = d.get("excited_states") or []
    s1 = es[0][2] if es else None
    p(f"   {tag}: S1={s1:.2f} eV  SCF={d.get('scf_energy'):.4f} Ha")
p("   结论：S1 能级随 C=O 伸长由 ~5.5 降至 ~2.4 eV，激发态势能曲线合理（避开 TD Opt 松弛扫描不收敛）。")

# 2. fluorescence
p("-" * 72)
p("2. 荧光/磷光 (fluorescence)  —— 甲醛")
d0 = parse("fluor_s0.log"); d1 = parse("fluor_s1.log"); dem = parse("fluor_emission.log"); dt1 = parse("phos_t1.log")
p(f"   S0 优化: 收敛={d0.get('converged')}  SCF={d0.get('scf_energy'):.4f} Ha  虚频={d0.get('n_imaginary')}")
p(f"   S1 优化: 收敛={d1.get('converged')}  激发态 S1={ (d1.get('excited_states') or [('','',0)])[0][2]:.2f} eV")
dem_es = dem.get("excited_states") or []
p(f"   荧光垂直发射 (S1 几何上 TD 单点): S1->S0 = {(dem_es[0][2] if dem_es else 0):.2f} eV")
p(f"   磷光 T1 (UB3LYP mult=3 优化): 收敛={dt1.get('converged')}  SCF={dt1.get('scf_energy'):.4f} Ha")
p(f"   0-0 磷光近似 = E(T1)-E(S0) = {dt1.get('scf_energy')-d0.get('scf_energy'):.3f} Ha")

# 3. excited_solvation
p("-" * 72)
p("3. 态特异性溶剂化 (excited_solvation)  —— 甲醛 气相 vs PCM(水)")
dg = parse("exsol_gas.log"); dp = parse("exsol_pcm.log")
sg = (dg.get("excited_states") or [('','',0)])[0][2]
sp = (dp.get("excited_states") or [('','',0)])[0][2]
p(f"   气相 S1={sg:.2f} eV   PCM(水) S1={sp:.2f} eV   pcm_active={dp.get('pcm_active')}")
p(f"   溶剂化致色移 (蓝移)：+{sp-sg:.2f} eV（tddft 在激发态下重组反应场）")

# 4. anharmonic
p("-" * 72)
p("4. 非谐振频率 (anharmonic)  —— H2O  # B3LYP/6-31G(d) Freq=(Anharmonic)")
da = parse("anharmonic.log")
af = da.get("anharmonic_frequencies") or []
p("   Fundamental Bands (Harmonic -> Anharmonic, cm^-1):")
for mode, h, a in af:
    p(f"     模式 {mode}: {h:.2f} -> {a:.2f}  (非谐振偏移 {a-h:.2f})")

# 5. preresonance_raman
p("-" * 72)
p("5. 预共振拉曼 (preresonance_raman)  —— 甲醛  # ... Freq=Raman CPHF=RdFreq + 页脚 32000 cm^-1")
dr = parse("preresonance_raman.log")
ra = dr.get("raman_activities") or []
p(f"   raman_activities 解析成功，{len(ra)} 个模式（最大 {max(ra) if ra else 0:.2f}）; 频率数={len(dr.get('frequencies') or [])}")

# 6. nmr_jcoupling
p("-" * 72)
p("6. NMR 屏蔽+J 耦合 (nmr_jcoupling)  —— 甲醇  # B3LYP/6-31G(d) NMR=(GIAO,SpinSpin)")
dn = parse("nmr_jcoupling.log")
jc = dn.get("j_couplings") or []
sh = dn.get("nmr_shieldings") or []
p(f"   自旋-自旋耦合 J (Hz, 下三角, 前 6): " + ", ".join(f"{a}-{b}={v:.1f}" for a,b,v in jc[:6]))
p(f"   GIAO 屏蔽常数 (ppm): " + ", ".join(f"{s}={v:.1f}" for s,v in sh))

# 7. vcd
p("-" * 72)
p("7. 振动圆二色性 (vcd)  —— gauche H2O2  # UB3LYP/6-31G(d) Freq=(VCD)（真实极小点）")
dv = parse("vcd.log")
vi = dv.get("vcd_intensities") or []
p(f"   vcd_intensities: {len(vi)} 模式，最大 |Rot.str.|={max(abs(x) for x in vi):.2f}；虚频={dv.get('n_imaginary')}")

# 8. optrot
p("-" * 72)
p("8. 旋光 ORD (optrot)  —— H2O2  # B3LYP/6-31G(d) Polar=(OptRot)")
do = parse("optrot.log")
p(f"   静态光学旋光 Beta = {do.get('optical_rotation'):+.4f} au")

# 9. roa
p("-" * 72)
p("9. 拉曼光学活性 (roa)  —— H2O2  # UB3LYP/6-31G(d) Freq=(ROA) CPHF=RdFreq + 页脚 18797 cm^-1")
dro = parse("roa.log")
ri = dro.get("roa_intensities") or []
p(f"   roa_intensities: {len(ri)} 模式（极小体系值≈0，工作流已验证）；虚频={dro.get('n_imaginary')}")

# 10. vibrot
p("-" * 72)
p("10. 振动-转动耦合 (vibrot)  —— H2O2  # B3LYP/6-31G(d) Freq=(VibRot)")
dvb = parse("vibrot.log")
va = dvb.get("vibrot_alpha") or []
p(f"   vibrot_alpha 矩阵 {len(va)} 行 x {len(va[0]) if va else 0} 列 (cm^-1)：")
for row in va:
    p("      " + "  ".join(f"{x:+.3f}" for x in row))

# 11. hyperfine
p("-" * 72)
p("11. 超精细/g 张量 (hyperfine)  —— OH 自由基  # UB3LYP/6-31G(d) NMR (mult=2)")
dh = parse("hyperfine.log")
hf = dh.get("hyperfine_couplings") or []
gt = dh.get("g_tensor") or []
p(f"   超精细耦合 A_iso (MHz): " + ", ".join(f"{s}={v:.1f}" for s,v in hf))
p(f"   电子 g 张量主值: " + ", ".join(f"{x:.4f}" for x in gt))

# G16-only
p("-" * 72)
p("12-15. G16-only（本机 g09 D.01 缺模块，标记 g09_d01_ok=False，路由为 G16 正确写法）")
p("   franck_condon / vibronic : # B3LYP/6-31G(d) TD=(NStates=5) Freq=(ReadFC,FCHT) Geom=AllCheck")
p("                              （FCHT/FC 模块缺失 -> rc=2057；G16 输出振动电子吸收/发射谱）")
p("   eom_ccsd                  : # CCSD/6-31G EOM=(EE,NStates=5)  （EOM 模块缺失 -> rc=2057）")
p("   ecd                       : # B3LYP/6-31G(d) TD=(NStates=8) CPolar  （CPolar 关键字缺失 -> rc=2057；")
p("                              G16 下 ecd_transitions 字段生效）")
p()
p("=" * 72)
p("回归测试：examples/validate_cases3.py 对以上 11 个本机 .log 断言 8 新字段非 None，")
p("全部通过（无需 Gaussian 即可运行）。")
p("=" * 72)

with open(OUT, "w", encoding="utf-8", newline="\n") as f:
    f.write("\n".join(L) + "\n")
print("written:", OUT)
