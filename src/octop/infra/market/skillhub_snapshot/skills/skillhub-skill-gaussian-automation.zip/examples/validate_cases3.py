"""
Gaussian 自动化 skill —— 解析器回归验证（第三批 15 案例，v1.5.0）
==============================================================

对 `gaussian_cases/cases3/` 下 11 个本机 g09 D.01 真实跑通（Normal termination）的
.log 调用 `parse_log`，核对每类计算应提取的**新增字段**是否如期非 None。本脚本
**只读 .log、不调用 Gaussian**，因此可在任意环境（含无 Gaussian 的机器）直接运行，
作为 skill 的回归测试。

注：第三批另有 4 项（franck_condon / vibronic / eom_ccsd / ecd）因本机 g09 D.01
缺对应模块而标记 G16-only，其 .log 为 Error termination，不在本回归断言范围内
（G16 下路由写法正确，可直接跑）。

用法：
    python validate_cases3.py                # 用默认 cases3 目录
    python validate_cases3.py <cases3_dir>   # 指定其它目录

退出码：全部通过为 0；有缺失/异常为 1。
"""
from __future__ import annotations

import os
import sys

SKILL_REF = os.path.join(os.path.dirname(__file__), "..", "references")
sys.path.insert(0, os.path.abspath(SKILL_REF))

import gaussian_automation as g  # noqa: E402

# 案例 -> 该案例目录下要解析的 .log（仅含本机 g09 D.01 跑通的 11 项）
CASES: dict = {
    "excited_pes":        ["ex_pes_1.00.log", "ex_pes_1.50.log"],
    "fluorescence":       ["fluor_s0.log", "fluor_s1.log", "fluor_emission.log", "phos_t1.log"],
    "excited_solvation":  ["exsol_gas.log", "exsol_pcm.log"],
    "anharmonic":         ["anharmonic.log"],
    "preresonance_raman": ["preresonance_raman.log"],
    "nmr_jcoupling":      ["nmr_jcoupling.log"],
    "vcd":                ["vcd_opt.log", "vcd.log"],
    "optrot":             ["optrot.log"],
    "roa":                ["roa.log"],
    "vibrot":             ["vibrot.log"],
    "hyperfine":          ["hyperfine.log"],
}

# 每个案例期望非 None 的新增/关键字段（核心判据）
EXPECT: dict = {
    "excited_pes":        ["excited_states", "scf_energy"],
    "fluorescence":       ["excited_states", "converged"],
    "excited_solvation":  ["excited_states", "pcm_active"],
    "anharmonic":         ["anharmonic_frequencies", "frequencies"],
    "preresonance_raman": ["raman_activities", "frequencies"],
    "nmr_jcoupling":      ["j_couplings", "nmr_shieldings"],
    "vcd":                ["vcd_intensities", "frequencies"],
    "optrot":             ["optical_rotation"],
    "roa":                ["roa_intensities", "frequencies"],
    "vibrot":             ["vibrot_alpha", "frequencies"],
    "hyperfine":          ["hyperfine_couplings", "g_tensor"],
}

# 同时验证这些 .log 必须 Normal termination（否则视为失败）
NORMAL_REQUIRED = True


def main(root: str) -> int:
    print(f"解析器回归验证（第三批 v1.5.0）：cases3 目录 = {root}\n")
    failures = 0
    for case, rels in CASES.items():
        want = EXPECT.get(case, [])
        merged = {}
        ok_logs = 0
        for rel in rels:
            p = os.path.join(root, rel)
            if not os.path.exists(p):
                print(f"  [X] {case:<18} 缺失日志: {rel}")
                failures += 1
                continue
            d = g.parse_log(p)
            if NORMAL_REQUIRED and not d["normal_termination"]:
                print(f"  [X] {case:<18} {rel} 非正常终止")
                failures += 1
                continue
            ok_logs += 1
            for k, v in d.items():
                if v is not None:
                    merged[k] = v
        missing = [f for f in want if f not in merged]
        status = "OK " if (not missing and ok_logs) else "FAIL"
        if missing or not ok_logs:
            failures += 1
        # 打印 parsed 摘要，便于人工复核
        extra = ""
        if case == "excited_pes" and "excited_states" in merged:
            es = merged["excited_states"]
            extra = f"  S1={es[0][2]:.2f}eV" if es else ""
        if case == "excited_solvation" and "excited_states" in merged:
            es = merged["excited_states"]
            extra = f"  S1={es[0][2]:.2f}eV" if es else ""
        if case == "anharmonic" and "anharmonic_frequencies" in merged:
            af = merged["anharmonic_frequencies"]
            extra = f"  n_modes={len(af)}"
        if case == "nmr_jcoupling" and "j_couplings" in merged:
            extra = f"  nJ={len(merged['j_couplings'])}"
        if case == "vcd" and "vcd_intensities" in merged:
            vi = merged["vcd_intensities"]
            extra = f"  max|Rot.str.|={max(abs(x) for x in vi):.2f}"
        if case == "optrot" and merged.get("optical_rotation") is not None:
            extra = f"  Beta={merged['optical_rotation']:+.4f}"
        if case == "hyperfine":
            hf = merged.get("hyperfine_couplings")
            gt = merged.get("g_tensor")
            if hf:
                extra += f"  hyperfine={[(s, round(v,1)) for s, v in hf]}"
            if gt:
                extra += f"  g={[round(x,4) for x in gt]}"
        print(f"  [{status}] {case:<18} logs={ok_logs}  缺失字段={missing if missing else '-'}{extra}")
    print()
    if failures:
        print(f"结果：{failures} 处失败 ❌")
        return 1
    print("结果：第三批 11 个本机案例解析全部通过 ✅")
    return 0


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else \
        r"C:/Users/Eric Ye/WorkBuddy/2026-09-25-20-46-25/gaussian_cases/cases3"
    sys.exit(main(root))
