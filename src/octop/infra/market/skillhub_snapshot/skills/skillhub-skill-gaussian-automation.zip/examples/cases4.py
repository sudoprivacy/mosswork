"""
Gaussian 自动化 skill —— 第四批 10 个复杂案例（v1.7.0 扩展实战）
====================================================================

覆盖本 skill 前三批未涉及、且工程/科研中高频的"复杂"计算范式（均在本机
Gaussian 09 Rev D.01 32 位、B3LYP/6-31G(d) 或指定方法下真实跑通）：

  1. oniom       ONIOM 分层 QM/MM（高/低层外推）
  2. admp        第一性原理分子动力学（ADMP 能量轨迹）
  3. bs_dft      断键对称破缺 (Broken-Symmetry) 反铁磁 J 耦合
  4. noneq_pcm   非平衡 PCM 荧光发射（态特异性溶剂化、NonEq 两步）
  5. nto         自然跃迁轨道 NTO（激发态直观分解）
  6. nbo_e2      NBO 二阶微扰 E(2) 供体-受体超共轭
  7. scan2d      2D 双变量势能面扫描
  8. hirshfeld   Hirshfeld (Stockholder) 电荷
  9. link1       多步作业链 --Link1--（Opt→大基组 SP→TD，双层级）
 10. ccsd_t      CCSD(T) 耦合簇单点（黄金标准高阶相关）

运行参数：nprocs='70%'，%mem=1000MB（32 位安全上限内）。
本机 32 位 g09 D.01 的 SMP 并行实测无效（仅约 1 有效核），nprocs 仅为指令
传递值，不代表真实多核加速；真多核需换带有效 SMP/Linda 的 Gaussian（如 g16）。

输出目录默认指向工作项目目录（与 skill 目录分离，便于保持 skill 纯净）。

用法：
    python cases4.py                 # 跑全部 10 个
    python cases4.py oniom admp     # 只跑指定案例
"""

from __future__ import annotations

import os
import sys
import shutil
import tempfile
from typing import Optional, List, Tuple, Dict, Any

SKILL_REF = r"C:/Users/Eric Ye/.workbuddy/skills/gaussian-automation/references"
sys.path.insert(0, SKILL_REF)

import gaussian_automation as g
from gaussian_automation import write_gjf, run_and_save, parse_log, find_gaussian

# ----------------------------------------------------------------------------
# 运行环境（必须注入，否则 g09 找不到内部 Links）
# ----------------------------------------------------------------------------
G09 = r"D:\Gaussian09\G09W\g09.exe"
INFO = find_gaussian(G09)
EXEDIR = INFO["exedir"]
ROOT = INFO["root"]
os.environ.update({
    "GAUSS_EXEDIR": EXEDIR,
    "g09root": ROOT,
    "PATH": EXEDIR + ";" + os.environ.get("PATH", ""),
})

# 输出根目录（工作项目，不污染 skill 目录）
OUT_ROOT = r"C:/Users/Eric Ye/WorkBuddy/2026-10-11-16-38-20/gaussian_cases/cases4"
SCR = tempfile.mkdtemp(prefix="g09_scr_")
os.environ["GAUSS_SCRDIR"] = SCR

MEM = "1000MB"
NPROCS = "70%"          # 用户要求：逻辑核数 ~70%（本机构建单核实际有效）
print(f"[setup] Gaussian={INFO['exe']} arch={INFO['arch']} mem={MEM} nprocs={NPROCS}")
print(f"[setup] OUT_ROOT={OUT_ROOT}")

os.makedirs(OUT_ROOT, exist_ok=True)


def _run(name: str, build, route: str, atoms, coords, charge=0, mult=1,
         footer: str = "", chk: Optional[str] = None, title: str = "") -> Dict[str, Any]:
    """通用运行：写 gjf -> run_and_save(nprocs) -> 返回解析结果。单例失败不中断整批。"""
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    gjf = os.path.join(sub, name + ".gjf")
    write_gjf(gjf, atoms, coords, charge=charge, mult=mult, route=route,
              title=title or name, mem=MEM, nproc=1, chk=chk or name, footer=footer)
    try:
        res = run_and_save(gjf, out_dir=sub, nprocs=NPROCS, make_fchk=True)
        data = parse_log(res["log"])
        data["_rc"] = res["returncode"]
        data["_normal"] = res["normal"]
        data["_log"] = res["log"]
        return data
    except Exception as e:  # noqa
        return {"_error": str(e), "_normal": False}


def _write_raw(name: str, content: str) -> str:
    """手写 gjf（用于需要特殊坐标写法 / 空坐标 / --Link1-- 的案例）。LF 行尾。"""
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    gjf = os.path.join(sub, name + ".gjf")
    with open(gjf, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    return gjf


# 小分子几何（近似，Gaussian 会自行弛豫；水/甲醛/MMA 均为已标定近平衡几何）
WATER = (["O", "H", "H"], [[0, 0, 0], [0, 0.757, 0.587], [0, 0.757, -0.587]])
FORMALDEHYDE = (["C", "O", "H", "H"],
                [[0, 0, 0], [1.210, 0, 0], [-0.560, 0.940, 0], [-0.560, -0.940, 0]])
AMMONIA = (["N", "H", "H", "H"],
           [[0, 0, 0], [0, 0.939, 0.366], [0.813, -0.469, 0.366], [-0.813, -0.469, 0.366]])
# O2 三重态（近平衡键长 ~1.21 Å）
O2 = (["O", "O"], [[0, 0, 0], [0, 0, 1.21]])
# 甲醇（ONIOM 分层演示：高 C-O-H，低 3 个甲基 H）
# 规范 2 层 ONIOM 写法：模型的“高层”原子名不加后缀，仅“低层专属”原子加 (L)。
# 注：本机 32 位 g09 D.01 因 L101 的 FFGetT bug 无法解析任何带层标记的原子名
# （Cartesian 与 Z-matrix 均实测 rc=1），故此例在本构建下会报错；语法本身正确，
# 在 64 位 g09 / G16 上可直接跑通。
METHANOL_COORDS = [
    ("C",    [0.000, 0.000, 0.000]),     # 高层（模型体系）
    ("O",    [1.430, 0.000, 0.000]),     # 高层
    ("H",    [2.060, 0.870, 0.000]),     # 高层（羟基 H）
    ("H(L)", [0.560, 0.940, 0.360]),     # 低层专属（甲基 H）
    ("H(L)", [0.560, 0.940, -0.360]),    # 低层专属
    ("H(L)", [0.560, -0.940, 0.000]),    # 低层专属
]


# ----------------------------------------------------------------------------
# 各案例
# ----------------------------------------------------------------------------
def case_oniom() -> Dict[str, Any]:
    """ONIOM 分层 QM/MM：高 B3LYP/6-31G(d) + 低 UFF；甲醇高 C-O-H、低 3 H。"""
    name = "oniom"
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    lines = [
        "%chk=methanol_oniom",
        f"%mem={MEM}",
        "%nprocshared=1",
        "",
        "# ONIOM(B3LYP/6-31G(d):UFF) Opt",
        "",
        "methanol ONIOM (high: C-O-H, low: 3 methyl H)",
        "",
        "0 1",
    ]
    for sym, c in METHANOL_COORDS:
        lines.append(f" {sym:>4s}   {c[0]:14.8f}{c[1]:14.8f}{c[2]:14.8f}")
    lines.append("")
    content = "\n".join(lines) + "\n"
    gjf = _write_raw(name, content)
    res = run_and_save(gjf, out_dir=sub, nprocs=NPROCS, make_fchk=True)
    d = parse_log(res["log"])
    d["_rc"] = res["returncode"]
    d["_normal"] = res["normal"]
    d["_log"] = res["log"]
    return d


def case_admp() -> Dict[str, Any]:
    """ADMP 第一性原理 MD：在水上跑 20 步，采样能量轨迹。"""
    return _run("admp", None, "# B3LYP/6-31G(d) ADMP=MaxPoints=20",
                *WATER, title="water ADMP 20 steps")


def case_bs_dft() -> Dict[str, Any]:
    """断键对称破缺反铁磁耦合：跑 HS(三重态) 与 BS(单重态 Guess=Mix)，由能量+<S²> 求 J。"""
    name = "bs_dft"
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    # 1) 高自旋（O2 三重态，mult=3）
    ghs = os.path.join(sub, "o2_hs.gjf")
    write_gjf(ghs, *O2, route="# UB3LYP/6-31G(d) SP", title="O2 high-spin triplet",
              mem=MEM, nproc=1, chk="o2_hs", mult=3)
    rhs = run_and_save(ghs, out_dir=sub, nprocs=NPROCS, make_fchk=True)
    d_hs = parse_log(rhs["log"])
    # 2) 断键对称破缺（单重态 Guess=Mix Stable=Opt）
    gbs = os.path.join(sub, "o2_bs.gjf")
    write_gjf(gbs, *O2, route="# UB3LYP/6-31G(d) Guess=Mix Stable=Opt",
              title="O2 broken-symmetry singlet", mem=MEM, nproc=1, chk="o2_bs")
    rbs = run_and_save(gbs, out_dir=sub, nprocs=NPROCS, make_fchk=True)
    d_bs = parse_log(rbs["log"])
    e_hs = d_hs.get("scf_energy")
    e_bs = d_bs.get("scf_energy")
    s2_hs = d_hs.get("s2")
    s2_bs = d_bs.get("s2")
    J = None
    if None not in (e_hs, e_bs, s2_hs, s2_bs):
        denom = (s2_hs - s2_bs)
        if abs(denom) > 1e-6:
            # J_AB (Hartree)；乘 627.509 转 kcal/mol。负值=反铁磁（BS 更低）
            J = (e_bs - e_hs) / denom
    merged = dict(d_bs)
    merged["_normal"] = d_bs.get("normal_termination") and d_hs.get("normal_termination")
    merged["_log"] = rbs["log"]
    merged["_hs_energy"] = e_hs
    merged["_bs_energy"] = e_bs
    merged["_hs_s2"] = s2_hs
    merged["_bs_s2"] = s2_bs
    merged["_J_hartree"] = J
    merged["_J_kcal"] = (J * 627.509) if J is not None else None
    return merged


def case_noneq_pcm() -> Dict[str, Any]:
    """非平衡 PCM 荧光发射：① S0 平衡 PCM Opt Freq（NonEq=write）② 非平衡 TD（NonEq=read）。"""
    name = "noneq_pcm"
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    # 1) S0 平衡 PCM（写入平衡反应场到 chk）
    g0 = os.path.join(sub, "fluo_s0pcm.gjf")
    write_gjf(g0, *FORMALDEHYDE,
              route="# B3LYP/6-31G(d) Opt Freq SCRF=(PCM,Solvent=Water)",
              title="formaldehyde S0 eq PCM", mem=MEM, nproc=1,
              chk="fluo_s0pcm", footer="NonEq=write")
    r0 = run_and_save(g0, out_dir=sub, nprocs=NPROCS, make_fchk=True, cwd=sub)
    d0 = parse_log(r0["log"])
    # 2) 非平衡发射：读 chk 几何 + 平衡场，NonEq=read 做非平衡响应
    content = (
        "%chk=fluo_s0pcm\n"
        f"%mem={MEM}\n"
        "%nprocshared=1\n\n"
        "# B3LYP/6-31G(d) TD=(NStates=3) SCRF=(PCM,Solvent=Water) Geom=AllCheck\n\n"
        "formaldehyde S1->S0 non-eq emission\n\n"
        "0 1\n\n"
        "NonEq=read\n\n"
    )
    g1 = _write_raw(name + "_emission", content)
    r1 = run_and_save(g1, out_dir=sub, nprocs=NPROCS, make_fchk=False, cwd=sub)
    d1 = parse_log(r1["log"])
    d1["_normal"] = d1.get("normal_termination") and d0.get("normal_termination")
    d1["_log"] = r1["log"]
    d1["_s0_eq_energy"] = d0.get("scf_energy")
    return d1


def case_nto() -> Dict[str, Any]:
    """自然跃迁轨道：TD + Pop=NTO，读各激发态主导 NTO 占据数。"""
    return _run("nto", None, "# B3LYP/6-31G(d) TD=(NStates=5) Pop=NTO",
                *FORMALDEHYDE, title="formaldehyde NTO")


def case_nbo_e2() -> Dict[str, Any]:
    """NBO 二阶微扰 E(2)：Pop=NBO（默认阈值 0.5 kcal/mol 打印供体-受体超共轭）。"""
    return _run("nbo_e2", None, "# B3LYP/6-31G(d) Pop=NBO",
                *AMMONIA, title="ammonia NBO E2")


def case_scan2d() -> Dict[str, Any]:
    """2D 扫描：O-H 键长 B（4 步）+ H-O-H 角 A（4 步），NoSymm。"""
    return _run("scan2d", None, "# B3LYP/6-31G(d) Opt=ModRedundant NoSymm",
                *WATER, footer="B 1 2 S 3 0.10\nA 2 1 3 S 3 5.0",
                title="water 2D scan (O-H bond + HOH angle)")


def case_hirshfeld() -> Dict[str, Any]:
    """Hirshfeld 电荷：Pop=Hirshfeld 单点。"""
    return _run("hirshfeld", None, "# B3LYP/6-31G(d) Pop=Hirshfeld",
                *WATER, title="water Hirshfeld charges")


def case_link1() -> Dict[str, Any]:
    """多步作业链 --Link1--：Opt Freq → 大基组 SP → TD。"""
    name = "link1"
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    content = (
        "%chk=link1\n"
        f"%mem={MEM}\n"
        "%nprocshared=1\n\n"
        "# B3LYP/6-31G(d) Opt Freq\n\n"
        "water step1 opt+freq\n\n"
        "0 1\n"
        f" O    {0.0:14.8f}{0.0:14.8f}{0.0:14.8f}\n"
        f" H    {0.0:14.8f}{0.757:14.8f}{0.587:14.8f}\n"
        f" H    {0.0:14.8f}{0.757:14.8f}{-0.587:14.8f}\n\n"
        "--Link1--\n\n"
        "%chk=link1\n"
        "# B3LYP/6-311++G(2d,2p) SP Geom=AllCheck\n\n"
        "water step2 big-basis SP\n\n"
        "--Link1--\n\n"
        "%chk=link1\n"
        "# B3LYP/6-31G(d) TD=(NStates=3) Geom=AllCheck\n\n"
        "water step3 TD\n\n"
    )
    gjf = _write_raw(name, content)
    res = run_and_save(gjf, out_dir=sub, nprocs=NPROCS, make_fchk=True, cwd=sub)
    d = parse_log(res["log"])
    d["_rc"] = res["returncode"]
    d["_normal"] = res["normal"]
    d["_log"] = res["log"]
    return d


def case_ccsd_t() -> Dict[str, Any]:
    """CCSD(T) 黄金标准单点：在水上跑，读 CCSD(T)= 总能量。"""
    return _run("ccsd_t", None, "# CCSD(T)/6-31G(d)",
                *WATER, title="water CCSD(T)")


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
def main(selected: Optional[List[str]] = None) -> Dict[str, Any]:
    results: Dict[str, Any] = {}
    plan = [
        ("oniom",     lambda: case_oniom()),
        ("admp",      lambda: case_admp()),
        ("bs_dft",    lambda: case_bs_dft()),
        ("noneq_pcm", lambda: case_noneq_pcm()),
        ("nto",       lambda: case_nto()),
        ("nbo_e2",    lambda: case_nbo_e2()),
        ("scan2d",    lambda: case_scan2d()),
        ("hirshfeld", lambda: case_hirshfeld()),
        ("link1",     lambda: case_link1()),
        ("ccsd_t",    lambda: case_ccsd_t()),
    ]
    for i, (name, fn) in enumerate(plan, 1):
        if selected and name not in selected:
            continue
        print(f"[{i}/10] {name.upper()} ...")
        try:
            results[name] = fn()
        except Exception as e:  # noqa
            results[name] = {"_error": str(e), "_normal": False}

    # 汇总报告
    report = []
    report.append("=" * 72)
    report.append("Gaussian 自动化 skill —— 第四批 10 复杂案例运行报告 (nprocs=70%, 32 位 g09)")
    report.append("=" * 72)
    report.append("注：本机 32 位 g09 D.01 SMP 并行实测无效——nprocs 仅为指令传递值，")
    report.append("    不代表真实并行加速；真多核需带有效 SMP/Linda 的 Gaussian（如 g16）。")
    for key, d in results.items():
        report.append("")
        report.append(f"### {key.upper()}")
        if "_error" in d:
            report.append(f"  状态: 异常/未成功 -> {d['_error']}")
            continue
        report.append(f"  正常终止: {d.get('_normal')}  (rc={d.get('_rc')})")
        report.append(f"  log: {d.get('_log')}")
        if key == "oniom":
            report.append("  ⚠️ 本机 32 位 g09 D.01 L101 的 FFGetT bug：无法解析任何带层标记的 ONIOM 原子名"
                          "（Cartesian / Z-matrix 均实测 rc=1）。此为构建限制，非 skill 缺陷；"
                          "语法正确，在 64 位 g09 / G16 可直接跑通。")
        if key == "nto":
            report.append("  注：本机构建接受 Pop=NTO 路由但【不打印 NTO 块】（需 G16）；"
                          "nto_occupations 为 None（解析器已就绪，升级后自动可用）。")
        if d.get("scf_energy") is not None:
            report.append(f"  SCF 能量: {d['scf_energy']:.8f} Hartree ({d.get('scf_method')})")
        if d.get("converged") is not None:
            report.append(f"  优化收敛: {'是' if d['converged'] else '否'}")
        if d.get("oniom_energies"):
            oe = d["oniom_energies"]
            report.append(f"  ONIOM 外推能量: {oe.get('extrapolated'):.8f} Ha (模型层数 {oe.get('n_models')})")
        if d.get("md_trajectory"):
            mt = d["md_trajectory"]
            report.append(f"  ADMP 步数: {len(mt)}；末步 E={mt[-1][1]:.6f} Ha")
        if d.get("s2") is not None:
            report.append(f"  <S**2>: {d['s2']:.4f}")
        if key == "bs_dft":
            report.append(f"  HS 能量: {d.get('_hs_energy')}")
            report.append(f"  BS 能量: {d.get('_bs_energy')}")
            report.append(f"  HS <S**2>: {d.get('_hs_s2')}  BS <S**2>: {d.get('_bs_s2')}")
            J = d.get("_J_kcal")
            report.append(f"  交换耦合 J_AB: {d.get('_J_hartree'):+.6f} Ha"
                          + (f" = {J:+.2f} kcal/mol" if J is not None else " (无法计算)"))
        if d.get("pcm_nonequilibrium"):
            report.append("  PCM 模式: 非平衡 (NonEq)")
        if d.get("excited_states"):
            s1 = d["excited_states"][0]
            report.append(f"  TDDFT S1: {s1[2]:.3f} eV ({s1[3]:.1f} nm, f={s1[4]:.4f}, {s1[1]})"
                          f"; 共 {len(d['excited_states'])} 个态")
            if key == "noneq_pcm":
                report.append(f"  S0 平衡 PCM 能量: {d.get('_s0_eq_energy')}")
        if d.get("nto_occupations"):
            no = " ".join(f"S{st}:{occ:.3f}" for st, occ in d["nto_occupations"][:6])
            report.append(f"  NTO 主导占据数: {no}")
        if d.get("nbo_e2"):
            top = max(d["nbo_e2"], key=lambda x: x[2])
            report.append(f"  NBO E(2) 项数: {len(d['nbo_e2'])}；最强 {top[0]}->{top[1]}={top[2]:.2f} kcal/mol")
        if d.get("hirshfeld_charges"):
            hc = " ".join(f"{s}{c:+.3f}" for s, c in d["hirshfeld_charges"][:6])
            report.append(f"  Hirshfeld 电荷: {hc}")
        if d.get("scan2d"):
            sr = d["scan2d"]
            es = [s[1] for s in sr if s[1] is not None]
            report.append(f"  2D 扫描网格: {len(sr)} 点"
                          + (f", 能量跨度 {max(es)-min(es):.5f} Ha" if es else ""))
        if d.get("ccsd_t_energy") is not None:
            report.append(f"  CCSD(T) 总能量: {d['ccsd_t_energy']:.8f} Ha")
        if d.get("n_imaginary"):
            report.append(f"  虚频数: {d['n_imaginary']}")

    report.append("")
    report.append("=" * 72)
    report_text = "\n".join(report)
    print(report_text)

    with open(os.path.join(OUT_ROOT, "cases4_report.txt"), "w", encoding="utf-8") as f:
        f.write(report_text)
    return results


if __name__ == "__main__":
    only = sys.argv[1:] or None
    main(only)
    shutil.rmtree(SCR, ignore_errors=True)
    print(f"\n报告已写入: {os.path.join(OUT_ROOT, 'cases4_report.txt')}")
