"""
GaussianAutomation 使用示例（v1.1.0）
====================================
演示：生成输入 -> （自动探测 Gaussian）运行计算 -> 归档 .log/.chk -> 解析结果。

注意：
  - 运计算需要本机已安装 Gaussian；不传 g16 时会自动探测本机安装。
  - 若没有 Gaussian，把下方 RUN 保持 False，可直接体验解析与“探测”功能。
"""

from __future__ import annotations

import os
import sys

# 让本示例能直接 import 工具包（包位于 references/ 下）
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "references"))

from gaussian_automation import (
    write_gjf, run_gaussian, run_and_save, parse_log, summarize,
    write_xyz, find_gaussian,
)

# ----------------------------------------------------------------------
# 1) 准备分子：水分子（直角坐标，Angstrom）
# ----------------------------------------------------------------------
atoms = ["O", "H", "H"]
coords = [
    [0.00000000, 0.00000000, 0.11730000],
    [0.00000000, 0.75545000, -0.46920000],
    [0.00000000, -0.75545000, -0.46920000],
]
write_xyz(os.path.join(HERE, "water.xyz"), atoms, coords, comment="water")

# ----------------------------------------------------------------------
# 2) 生成 Gaussian 输入文件
# ----------------------------------------------------------------------
gjf = os.path.join(HERE, "water.gjf")
write_gjf(
    path=gjf, atoms=atoms, coords=coords,
    charge=0, mult=1,
    route="# B3LYP/6-31G(d) Opt Freq",
    title="water opt+freq",
    mem="1GB", nproc=4, chk="water.chk",
)
print(f"[1] 已生成输入文件: {gjf}")

# ----------------------------------------------------------------------
# 3) 自动探测本机 Gaussian（v1.1.0 新增）
# ----------------------------------------------------------------------
info = find_gaussian()
if info["found"]:
    print(f"[2] 探测到 Gaussian: {info['exe']} ({info['family']})")
else:
    print("[2] 未在本机探测到 Gaussian（运行计算前需安装或显式传入 exe）。")
    print("     已搜索:", "; ".join(info["searched"]) or "PATH / GAUSS_EXEDIR")

# ----------------------------------------------------------------------
# 4) 运行计算并保存结果（v1.1.0 新增）
# ----------------------------------------------------------------------
RUN = False  # 改为 True 并尝试运行（需要本机 Gaussian）
if RUN and info["found"]:
    res = run_and_save(gjf, out_dir=os.path.join(HERE, "results"),
                       chk="water", make_fchk=True)
    print(f"[3] 返回码={res['returncode']} 正常终止={res['normal']} ok={res['ok']}")
    print("    .log :", res["log"])
    print("    .chk :", res["chk"])
    print("    .fchk:", res["fchk"])
    target = res["log"]
else:
    # 没有 Gaussian 也能体验解析：用内置示例 log
    target = os.path.join(HERE, "sample_water.log")
    print("[3] 跳过实际计算（无 Gaussian），改用示例输出文件演示解析：")
    print(summarize(target))

# ----------------------------------------------------------------------
# 5) 直接调用 parse_log 取结构化数据
# ----------------------------------------------------------------------
data = parse_log(target)
print("\n[4] 结构化结果（节选）:")
print("  SCF 能量 :", data["scf_energy"], data["scf_method"])
print("  收敛      :", data["converged"])
print("  频率      :", data["frequencies"])
print("  热力学 G  :", data["sum_free_energy"])
print("  偶极矩    :", data["dipole"])
print("  HOMO/LUMO :", data["homo_lumo"])
