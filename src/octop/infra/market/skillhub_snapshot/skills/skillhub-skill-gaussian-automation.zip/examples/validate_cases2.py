"""
Gaussian 自动化 skill —— 解析器回归验证（第二批 12 案例）
========================================================

对 `gaussian_cases/cases2/` 下 12 个真实 .log 调用 `parse_log`，核对每类计算
应提取的关键字段是否如期非 None。本脚本**只读 .log、不调用 Gaussian**，
因此可在任意环境（含无 Gaussian 的机器）直接运行，作为 skill 的回归测试。

用法：
    python validate_cases2.py                # 用默认 cases2 目录
    python validate_cases2.py <cases2_dir>   # 指定其它目录

退出码：全部通过为 0；有缺失/异常为 1。
"""
from __future__ import annotations

import os
import sys

SKILL_REF = os.path.join(os.path.dirname(__file__), "..", "references")
sys.path.insert(0, os.path.abspath(SKILL_REF))

import gaussian_automation as g  # noqa: E402

# 案例 -> 该案例目录下要解析的 .log（irc 含 TS 与 IRC 两个）
CASES: dict = {
    "irc":    ["irc/ethane_irc.log", "irc/ethane_ts.log"],
    "nmr":    ["nmr/nmr.log"],
    "scan":   ["scan/scan.log"],
    "mp2":    ["mp2/mp2.log"],
    "nbo":    ["nbo/nbo.log"],
    "pcm":    ["pcm/pcm.log"],
    "raman":  ["raman/raman.log"],
    "bsse":   ["bsse/water_dimer.log"],
    "polar":  ["polar/polar.log"],
    "cis":    ["cis/cis.log"],
    "stable": ["stable/stable.log"],
    "tdopt":  ["tdopt/tdopt.log"],
}

# 每个案例期望非 None 的字段（核心判据）
EXPECT: dict = {
    "irc":    ["scf_energy", "polarizability"],
    "nmr":    ["nmr_shieldings"],
    "scan":   ["scan_results"],
    "mp2":    ["mp2_correlation", "mp2_total"],
    "nbo":    ["nbo_charges"],
    "pcm":    ["pcm_active"],                      # g09 D.01 默认 PCM 不打印 ΔG_solv，仅确认启用
    "raman":  ["raman_activities", "frequencies"],
    "bsse":   ["bsse_corrected_energy", "complexation_energy_corrected"],
    "polar":  ["polarizability", "isotropic_polarizability"],
    "cis":    ["cis_energy", "excited_states"],
    "stable": ["stability"],
    "tdopt":  ["excited_states", "converged"],
}


def main(root: str) -> int:
    print(f"解析器回归验证：cases2 目录 = {root}\n")
    failures = 0
    for case, rels in CASES.items():
        want = EXPECT.get(case, [])
        # 合并该案例所有 log 的字段（任一命中即算通过）
        merged = {}
        ok_logs = 0
        for rel in rels:
            p = os.path.join(root, rel)
            if not os.path.exists(p):
                print(f"  [X] {case:<6} 缺失日志: {rel}")
                failures += 1
                continue
            d = g.parse_log(p)
            if not d["normal_termination"]:
                print(f"  [X] {case:<6} {rel} 非正常终止")
                failures += 1
                continue
            ok_logs += 1
            for k, v in d.items():
                if v is not None:
                    merged[k] = v
        missing = [f for f in want if f not in merged]
        status = "OK " if not missing and ok_logs else "FAIL"
        if missing or not ok_logs:
            failures += 1
        print(f"  [{status}] {case:<6} logs={ok_logs}  缺失字段={missing if missing else '-'}")
    print()
    if failures:
        print(f"结果：{failures} 处失败 ❌")
        return 1
    print("结果：全部 12 案例解析通过 ✅")
    return 0


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else \
        r"C:/Users/Eric Ye/WorkBuddy/2026-09-24-10-38-17/gaussian_cases/cases2"
    sys.exit(main(root))
