"""
Gaussian 自动化 skill —— 第二批 12 个综合案例（v1.3.0 扩展实战）
===================================================================

覆盖本 skill 此前未涉及的计算能力（均在本机 Gaussian 09 Rev D.01 32 位、
B3LYP/6-31G(d) 基组下真实跑通）：

  1. IRC           内禀反应坐标（乙烷 C-C 扭转过渡态 -> 反应物/产物）
  2. NMR=GIAO      核磁屏蔽常数（甲醇）
  3. Scan          PES 势能面扫描（水的 O-H 键伸缩）
  4. MP2           后 HF 相关能单点（水）
  5. NBO           自然键轨道分析（氨）
  6. PCM           隐式溶剂化（甲醇 / 水）
  7. Freq=Raman    Raman 散射活性（甲醛）
  8. Counterpoise  BSSE 基组叠加误差校正（水二聚体）
  9. Polar         静态极化率（CO2）
 10. CIS           激发态（组态相互作用单激发，B3LYP 下 CIS=(NStates=6)；
                  注：真正的 ECD 旋光强度需 CPolar 关键字，g09 D.01 不含，故以 CIS 替代）
 11. Stable=Opt    波函数稳定性检验（甲醛）
 12. TD Opt        激发态几何优化（甲醛 S1）

所有作业统一运行参数：nprocs=12，%mem=1000MB（32 位安全上限内）。
注意：本机为 32 位 g09 D.01，v1.3.0 已取消 nprocs 的 4 核封顶，故 %nprocshared=12
指令可被正确注入并被 Gaussian 回显（"Will use up to 12 processors via shared memory"）。
但实测表明该构建的 SMP 并行实际无效：同一苯的 MP2/6-311G(2d,2p) 作业，
nprocs=1 墙钟 10.68s、nprocs=12 墙钟 8.46s（仅 1.26×，Job CPU≈墙钟 → 约 1 有效核）。
故下方"核数"仅为指令传递值，不代表真实多核加速；真多核需更换为带有效 SMP/Linda 的版本。

输出目录默认指向工作项目目录（与 skill 目录分离，便于保持 skill 纯净）。
"""

from __future__ import annotations

import os
import sys
import shutil
import tempfile
from typing import Optional, List, Tuple, Dict, Any

SKILL_REF = r"C:/Users/Eric Ye/.workbuddy/skills/gaussian-automation/references"
sys.path.insert(0, SKILL_REF)

import gaussian_automation as g
from gaussian_automation import write_gjf, run_and_save, parse_log, find_gaussian, detect

# ----------------------------------------------------------------------------
# 运行环境（必须注入，否则 g09 找不到内部 Links）
# ----------------------------------------------------------------------------
G09 = r"D:\Gaussian09\G09W\g09.exe"
INFO = find_gaussian(G09)
EXEDIR = INFO["exedir"]
ROOT = INFO["root"]
os.environ.update({
    "GAUSS_EXEDIR": EXEDIR,
    "g09root": ROOT,
    "PATH": EXEDIR + ";" + os.environ.get("PATH", ""),
})

# 输出根目录（工作项目，不污染 skill 目录）
OUT_ROOT = r"C:/Users/Eric Ye/WorkBuddy/2026-09-24-10-38-17/gaussian_cases/cases2"
SCR = tempfile.mkdtemp(prefix="g09_scr_")
os.environ["GAUSS_SCRDIR"] = SCR

MEM = "1000MB"
NPROCS = 12          # 用户要求：逻辑核数 = 12（v1.3.0 已取消安全封顶）
print(f"[setup] Gaussian={INFO['exe']} arch={INFO['arch']} mem={MEM} nprocs={NPROCS}")
print(f"[setup] OUT_ROOT={OUT_ROOT}")

os.makedirs(OUT_ROOT, exist_ok=True)


def _run(name: str, build, route: str, atoms, coords, charge=0, mult=1,
         footer: str = "", chk: Optional[str] = None, title: str = "") -> Dict[str, Any]:
    """通用运行：写 gjf -> run_and_save(nprocs=12) -> 返回解析结果。单例失败不中断整批。"""
    sub = os.path.join(OUT_ROOT, name)
    os.makedirs(sub, exist_ok=True)
    gjf = os.path.join(sub, name + ".gjf")
    write_gjf(gjf, atoms, coords, charge=charge, mult=mult, route=route,
              title=title or name, mem=MEM, nproc=1, chk=chk or name, footer=footer)
    try:
        res = run_and_save(gjf, out_dir=sub, nprocs=NPROCS, make_fchk=True)
        data = parse_log(res["log"])
        data["_rc"] = res["returncode"]
        data["_normal"] = res["normal"]
        data["_log"] = res["log"]
        return data
    except Exception as e:  # noqa
        return {"_error": str(e), "_normal": False}


# 小分子几何（近似，Gaussian 会自行弛豫）
WATER = (["O", "H", "H"], [[0, 0, 0], [0, 0.757, 0.587], [0, 0.757, -0.587]])
METHANOL = (["C", "O", "H", "H", "H", "H"],
            [[0.0, 0.0, 0.0], [1.430, 0.0, 0.0], [2.060, 0.870, 0.0],
             [-0.560, 0.940, 0.360], [-0.560, 0.940, -0.360], [-0.560, -0.940, 0.0]])
AMMONIA = (["N", "H", "H", "H"],
           [[0, 0, 0], [0, 0.939, 0.366], [0.813, -0.469, 0.366], [-0.813, -0.469, 0.366]])
FORMALDEHYDE = (["C", "O", "H", "H"],
                [[0, 0, 0], [1.210, 0, 0], [-0.560, 0.940, 0], [-0.560, -0.940, 0]])
CO2 = (["C", "O", "O"], [[0, 0, 0], [1.160, 0, 0], [-1.160, 0, 0]])
# 甲基环氧乙烷（2-甲基环氧乙烷，手性）——近似几何，仅供 ECD 演示
METHYLOXIRANE = (["O", "C", "C", "C", "H", "H", "H", "H", "H", "H"],
                 [[0.000, 0.000, 0.000],
                  [1.460, 0.000, 0.000],
                  [0.730, 1.260, 0.000],
                  [1.950, 2.600, 0.000],
                  [2.100, -0.540, -0.450],
                  [2.100, -0.540, 0.450],
                  [2.950, 1.930, 0.000],
                  [1.550, 3.200, 0.450],
                  [1.550, 3.200, -0.450],
                  [0.200, 1.900, 0.000]])
# 乙烷（重叠构象，扭转过渡态起始）
ETHANE_ECLIPSED = (["C", "C", "H", "H", "H", "H", "H", "H"],
                   [[0.000, 0.000, 0.766], [0.000, 0.000, -0.766],
                    [0.000, 1.018, 1.447], [0.883, -0.509, 1.447], [-0.883, -0.509, 1.447],
                    [0.000, 1.018, -1.447], [0.883, -0.509, -1.447], [-0.883, -0.509, -1.447]])


def case_irc() -> Dict[str, Any]:
    """乙烷 C-C 扭转过渡态：先 Opt=(TS) 定位，再用其几何跑 IRC。"""
    sub = os.path.join(OUT_ROOT, "irc")
    os.makedirs(sub, exist_ok=True)
    # 1) 过渡态优化
    gts = os.path.join(sub, "ethane_ts.gjf")
    write_gjf(gts, *ETHANE_ECLIPSED, route="# B3LYP/6-31G(d) Opt=(TS,CalcFC,MaxCyc=100)",
              title="ethane TS", mem=MEM, nproc=1, chk="ethane_ts")
    r1 = run_and_save(gts, out_dir=sub, nprocs=NPROCS, make_fchk=True)
    d1 = parse_log(r1["log"])
    geo = d1.get("optimized_geometry")
    if not geo:
        return {"_error": "TS opt 未给出优化几何", "_normal": False}
    # 2) 用 TS 几何跑 IRC
    gir = os.path.join(sub, "ethane_irc.gjf")
    write_gjf(gir, geo["atoms"], geo["coords"],
              route="# B3LYP/6-31G(d) IRC=CalcFC", title="ethane IRC",
              mem=MEM, nproc=1, chk="ethane_irc")
    r2 = run_and_save(gir, out_dir=sub, nprocs=NPROCS, make_fchk=False)
    d2 = parse_log(r2["log"])
    d2["_rc"] = r2["returncode"]
    d2["_normal"] = r2["normal"]
    d2["_log"] = r2["log"]
    d2["ts_imag"] = d1.get("n_imaginary")
    return d2


def case_bsse() -> Dict[str, Any]:
    """水二聚体 BSSE：Counterpoise=2，需片段分隔（手写 gjf）。"""
    sub = os.path.join(OUT_ROOT, "bsse")
    os.makedirs(sub, exist_ok=True)
    gjf = os.path.join(sub, "water_dimer.gjf")
    # 片段 1：水 A；片段 2：水 B（氢键方向）
    content = f"""%chk=water_dimer
%mem={MEM}
%nprocshared=1

# B3LYP/6-31G(d) Counterpoise=2

water dimer BSSE

0 1
O   0.000   0.000   0.000   1
H   0.757   0.587   0.000   1
H   0.757  -0.587   0.000   1
O   2.900   0.000   0.000   2
H   3.657   0.587   0.000   2
H   3.657  -0.587   0.000   2

"""
    # Cartesian 体系 counterpoise：每个原子行末尾加片段编号(1/2)，不用 -- 分隔符
    with open(gjf, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    res = run_and_save(gjf, out_dir=sub, nprocs=NPROCS, make_fchk=False)
    d = parse_log(res["log"])
    d["_rc"] = res["returncode"]
    d["_normal"] = res["normal"]
    d["_log"] = res["log"]
    return d


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
# 主流程（支持按名称筛选运行：python cases2.py scan bsse ecd）
# ----------------------------------------------------------------------------
def main(selected: Optional[List[str]] = None) -> Dict[str, Any]:
    results: Dict[str, Any] = {}

    # 路由统一取自 recipes.CASE_CATALOG（单一信息源，避免路由漂移）；
    # 特殊配方（irc 两步 / bsse 笛卡尔片段 / scan 需 ModRedundant 页脚）逻辑见下方 case_* 函数。
    plan = [
        ("irc",    lambda: case_irc()),
        ("nmr",    lambda: _run("nmr", None, g.case_route("nmr"),
                                *METHANOL, title="methanol NMR")),
        ("scan",   lambda: _run("scan", None, g.case_route("scan"),
                                *WATER, footer="1 2 S 6 0.20", title="water O-H scan")),
        ("mp2",    lambda: _run("mp2", None, g.case_route("mp2"),
                                *WATER, title="water MP2")),
        ("nbo",    lambda: _run("nbo", None, g.case_route("nbo"),
                                *AMMONIA, title="ammonia NBO")),
        ("pcm",    lambda: _run("pcm", None, g.case_route("pcm"),
                                *METHANOL, title="methanol in water")),
        ("raman",  lambda: _run("raman", None, g.case_route("raman"),
                                *FORMALDEHYDE, title="formaldehyde Raman")),
        ("bsse",   lambda: case_bsse()),
        ("polar",  lambda: _run("polar", None, g.case_route("polar"),
                                *CO2, title="CO2 polarizability")),
        ("cis",    lambda: _run("cis", None, g.case_route("cis"),
                                *FORMALDEHYDE, title="formaldehyde CIS")),
        ("stable", lambda: _run("stable", None, g.case_route("stable"),
                                *FORMALDEHYDE, title="formaldehyde stability")),
        ("tdopt",  lambda: _run("tdopt", None, g.case_route("tdopt"),
                                *FORMALDEHYDE, title="formaldehyde S1 opt")),
    ]

    for i, (name, fn) in enumerate(plan, 1):
        if selected and name not in selected:
            continue
        print(f"[{i}/12] {name.upper()} ...")
        try:
            results[name] = fn()
        except Exception as e:  # noqa
            results[name] = {"_error": str(e), "_normal": False}

    # ------------------------------------------------------------------
    # 汇总报告
    # ------------------------------------------------------------------
    report = []
    report.append("=" * 70)
    report.append("Gaussian 自动化 skill —— 第二批 12 案例运行报告 (nprocs=12, 32 位 g09)")
    report.append("=" * 70)
    report.append("注：本机 32 位 g09 D.01 的 SMP 并行实测无效——%nprocshared=12 已正确注入并被")
    report.append("    回显，但实际只用约 1 核（nprocs=1 与 12 墙钟时间几乎相同）。故下方核数")
    report.append("    仅为指令传递值，不代表真实并行加速；真多核需换成带有效 SMP/Linda 的 Gaussian。")
    for key, d in results.items():
        report.append("")
        report.append(f"### {key.upper()}")
        if "_error" in d:
            report.append(f"  状态: 异常/未成功 -> {d['_error']}")
            continue
        report.append(f"  正常终止: {d.get('_normal')}  (rc={d.get('_rc')})")
        report.append(f"  log: {d.get('_log')}")
        if d.get("scf_energy") is not None:
            report.append(f"  SCF 能量: {d['scf_energy']:.8f} Hartree ({d.get('scf_method')})")
        if d.get("converged") is not None:
            report.append(f"  优化收敛: {'是' if d['converged'] else '否'}")
        if d.get("n_imaginary") is not None and d.get("n_imaginary"):
            report.append(f"  虚频数: {d['n_imaginary']}")
        if d.get("nmr_shieldings"):
            report.append("  NMR 各向同性屏蔽(ppm): " +
                          ", ".join(f"{s}{v:.2f}" for s, v in d["nmr_shieldings"][:6]))
        if d.get("scan_results"):
            sr = d["scan_results"]
            es = [s[2] for s in sr if s[2] is not None]
            report.append(f"  PES 扫描步数: {len(sr)}"
                          + (f", 能量跨度 {max(es)-min(es):.5f} Ha" if es else ""))
        if d.get("mp2_correlation") is not None:
            report.append(f"  MP2 相关能 E2: {d['mp2_correlation']:.6f} Ha")
        if d.get("mp2_total") is not None:
            report.append(f"  MP2 总能量: {d['mp2_total']:.8f} Ha")
        if d.get("cis_energy") is not None:
            report.append(f"  CIS 总能量 E(CIS): {d['cis_energy']:.8f} Ha")
        if d.get("nbo_charges"):
            report.append("  NBO 电荷: " + " ".join(f"{s}{c:+.3f}" for s, c in d["nbo_charges"][:6]))
        if d.get("pcm_solvation_free_energy") is not None:
            report.append(f"  PCM 溶剂化自由能 ΔG_solv: {d['pcm_solvation_free_energy']:+.4f} Ha")
        if d.get("raman_activities"):
            report.append(f"  Raman 活性点数: {len(d['raman_activities'])}"
                          f", 最大值 {max(d['raman_activities']):.2f} A^4/amu")
        if d.get("polarizability"):
            report.append(f"  极化率张量分量数: {len(d['polarizability'])}")
            if d.get("isotropic_polarizability") is not None:
                report.append(f"  各向同性极化率: {d['isotropic_polarizability']:.3f} Bohr^3")
        if d.get("excited_states"):
            s1 = d["excited_states"][0]
            label = "CIS" if key == "cis" else ("TDDFT(S1 opt)" if key == "tdopt" else "TDDFT")
            report.append(f"  {label} S1: {s1[2]:.3f} eV ({s1[3]:.1f} nm, f={s1[4]:.4f}, {s1[1]})"
                          f"; 共 {len(d['excited_states'])} 个态")
        if key == "irc":
            report.append(f"  TS 虚频数: {d.get('ts_imag')} (IRC 沿反应坐标展开)")
        if d.get("stability"):
            report.append(f"  波函数稳定性: {d['stability']}")
        if d.get("bsse_corrected_energy") is not None:
            report.append(f"  BSSE 校正能量 E_cp: {d['bsse_corrected_energy']:.8f} Ha")
        if d.get("complexation_energy_corrected") is not None:
            report.append(f"  校正后复合能 ΔE_comp: {d['complexation_energy_corrected']:+.3f} kcal/mol")

    report.append("")
    report.append("=" * 70)
    report_text = "\n".join(report)
    print(report_text)

    with open(os.path.join(OUT_ROOT, "cases2_report.txt"), "w", encoding="utf-8") as f:
        f.write(report_text)

    return results


if __name__ == "__main__":
    only = sys.argv[1:] or None
    main(only)
    shutil.rmtree(SCR, ignore_errors=True)
    print(f"\n报告已写入: {os.path.join(OUT_ROOT, 'cases2_report.txt')}")
