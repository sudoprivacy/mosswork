"""统一解析 5 个案例的 .log，生成 cases_report.txt。"""
import os, sys
SKILL_REF = r"C:/Users/Eric Ye/.workbuddy/skills/gaussian-automation/references"
sys.path.insert(0, SKILL_REF)
from gaussian_automation import parse_log

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "results")

CASES = [
    ("案例1  HOMO-LUMO 轨道能隙 (乙烯, B3LYP/6-31G(d) Opt)", "ethylene.log"),
    ("案例2  TDDFT 激发态 (甲醛, B3LYP/6-31G(d) Opt TD=(NStates=6))", "formaldehyde_td.log"),
    ("案例3  过渡态搜索 (乙烷 C-C 扭转, B3LYP/6-31G(d) Opt=(TS,CalcFC) Freq)", "ethane_ts.log"),
    ("案例4  静电势 ESP 拟合电荷 (水, B3LYP/6-31G(d) Pop=MK)", "water_esp.log"),
    ("案例5  全流程 Opt+Freq+TDDFT+ESP (苯, B3LYP/6-31G(d))", "benzene_all.log"),
]

lines = []
def log(s): lines.append(str(s))

log("=" * 72)
log("Gaussian 自动化 · 5 个综合案例 · 结果汇总")
log("计算方法: B3LYP/6-31G(d)   本机: D:\\Gaussian09\\G09W\\g09.exe (32 位, %mem=1500MB)")
log("=" * 72)

for title, fn in CASES:
    log("")
    log(">>> " + title)
    d = parse_log(os.path.join(OUT, fn))
    log(f"  正常终止={d['normal_termination']}  优化收敛={d['converged']}")
    if d["scf_energy"] is not None:
        log(f"  SCF 能量={d['scf_energy']:.6f} Hartree ({d['scf_method']})")
    if d["homo_lumo"]:
        h, l = d["homo_lumo"]
        log(f"  HOMO/LUMO={h:.4f}/{l:.4f} Hartree  能隙={ (l-h)*27.2114:.3f} eV")
    if d["n_imaginary"] is not None:
        is_ts = d["n_imaginary"] == 1 and d["converged"]
        log(f"  虚频数={d['n_imaginary']}  -> {'过渡态 ✓' if is_ts else ('真实极小点 ✓' if d['n_imaginary']==0 and d['converged'] else '需核查')}")
        if d["n_imaginary"]:
            negs = [f for f in d["frequencies"] if f < 0]
            log(f"  虚频: {['%.2f'%v for v in negs]} cm^-1")
    if d["excited_states"]:
        log("  TDDFT 激发态(前3):")
        for st, lab, ev, nm, f in d["excited_states"][:3]:
            log(f"    S{st} {lab:12s} {ev:7.3f} eV  {nm:8.1f} nm  f={f:.4f}")
    if d["esp_charges"]:
        log("  ESP 拟合电荷: " + " ".join(f"{s}{c:+.3f}" for s, c in d["esp_charges"]))
    if d["sum_free_energy"] is not None:
        log(f"  G(298K) 绝对自由能={d['sum_free_energy']:.6f} Hartree")

log("")
log("=" * 72)
log("全部案例结束。输入在 inputs/，日志/结果在 results/。")
log("=" * 72)

with open(os.path.join(HERE, "cases_report.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
print("\n报告已写入 cases_report.txt")
