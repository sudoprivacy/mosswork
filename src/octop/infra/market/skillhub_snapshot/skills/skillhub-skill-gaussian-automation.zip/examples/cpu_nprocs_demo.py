"""
CPU 逻辑核数自动解析示例（v1.3.0 新增）
=====================================

演示：
  1. 自动探测本机逻辑 CPU 核数
  2. 用「绝对核数 / 百分比 / 小数比例」三种写法解析并行核数
  3. 从 gjf 首行读取 %nprocs= / %nprocshared=
  4. 把核数写回 gjf（apply_nprocs_to_gjf）
  5. 在 run_and_save 中直接传 nprocs=（若本机有 Gaussian 则真跑一个极小任务）

无需 Gaussian 也能跑前 4 部分；第 5 部分会自动探测，找不到则跳过。
"""

from __future__ import annotations

import os
import sys
import tempfile

# 让脚本在「直接运行」与「作为模块」时都能 import 到 gaussian_automation
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path.insert(0, os.path.join(_ROOT, "references"))

from gaussian_automation import (
    logical_cpu_count, resolve_nprocs, apply_nprocs_to_gjf, explain_nprocs,
    write_gjf, run_and_save, find_gaussian,
)


def demo_pure():
    """前 4 部分：纯函数，无需 Gaussian。"""
    total = logical_cpu_count()
    print(f"[1] 本机逻辑 CPU 核数 = {total}\n")

    print("[2] 三种核数写法解析（本机 16 核为例）：")
    for inp in (12, "75%", 0.75):
        print(f"    resolve_nprocs(user_input={inp!r}) -> {resolve_nprocs(user_input=inp)}")
    print(f"    越界夹紧 -> resolve_nprocs(user_input=999) = {resolve_nprocs(user_input=999)}")
    print(f"    32 位不再封顶 -> resolve_nprocs(user_input=8, arch='x86') = "
          f"{resolve_nprocs(user_input=8, arch='x86')}\n")

    # 写一个含 %nprocs=8 的 gjf，演示“首行输入 %nprocs=8 即表示 8 核”
    gjf = os.path.join(tempfile.gettempdir(), "demo_nprocs.gjf")
    with open(gjf, "w", encoding="utf-8") as f:
        f.write("%nprocs=8\n%mem=1GB\n# B3LYP/6-31G(d) Opt\n\ntitle\n\n0 1\nO 0 0 0\nH 0 0.9 0\n\n")
    print("[3] 从 gjf 首行 %nprocs=8 解析：")
    print(f"    resolve_nprocs(gjf_path={gjf!r}) -> {resolve_nprocs(gjf_path=gjf)}")
    print(f"    explain_nprocs -> {explain_nprocs(gjf_path=gjf)}\n")

    print("[4] 把核数写回 gjf 首行：")
    out = os.path.join(tempfile.gettempdir(), "demo_nprocs_written.gjf")
    apply_nprocs_to_gjf(gjf, 4, out_path=out, directive="%nprocs")
    print("---- demo_nprocs_written.gjf ----")
    print(open(out, encoding="utf-8").read())


def demo_run():
    """第 5 部分：若本机有 Gaussian，真跑一个极小任务验证 nprocs 注入。"""
    info = find_gaussian()
    if not info["found"]:
        print("[5] 未探测到 Gaussian，跳过实际运行演示。")
        return

    print(f"[5] 探测到 Gaussian: {info['exe']} (arch={info['arch']})，运行极小值任务验证 nprocs 注入：")
    # 注入运行环境（GAUSS_SCRDIR 等），否则可能找不到内部 Link
    os.environ.update({
        "GAUSS_EXEDIR": info["exedir"],
        "g09root" if info["family"] == "g09" else "g16root": info["root"],
        "GAUSS_SCRDIR": tempfile.mkdtemp(prefix="gauss_scr_"),
        "PATH": info["exedir"] + ";" + os.path.abspath(os.environ.get("PATH", "")),
    })

    mem = "1500MB" if info["arch"] == "x86" else "4GB"
    gjf = os.path.join(tempfile.gettempdir(), "demo_water.gjf")
    write_gjf(gjf, ["O", "H", "H"],
              [[0, 0, 0], [0, 0.757, 0.587], [0, 0.757, -0.587]],
              route="# B3LYP/6-31G(d) Opt", mem=mem, nproc=1, chk="demo_water")

    # 用百分比指定核数；v1.3.0 起 32 位不再封顶（arch 仅信息展示）
    res = run_and_save(gjf, out_dir=tempfile.mkdtemp(prefix="gauss_out_"),
                       nprocs="50%", make_fchk=False)
    log = open(res["log"], encoding="utf-8", errors="ignore").read()
    import re
    echoed = re.findall(r"%nproc\w*=\d+", log)
    procs = re.search(r"Will use up to\s+(\d+)\s+processors", log)
    print(f"    运行副本 Link0: {echoed}  |  实际并行: "
          f"{procs.group(1) if procs else 'n/a'} 核  |  Normal termination: "
          f"{'Normal termination' in log}  |  ok={res['ok']}")


if __name__ == "__main__":
    demo_pure()
    print("=" * 60)
    demo_run()
