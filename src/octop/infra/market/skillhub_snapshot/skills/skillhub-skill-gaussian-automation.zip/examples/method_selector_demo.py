"""
计算方法 / 基组自动推荐示例（v1.6.0 新增）
=========================================

演示 ``method_selector`` 模块：给它「体系大小 + 分子类型 + 计算任务」，
它给出 Gaussian 的方法/基组组合、完整路由、为什么这么选、备选方案与后续步骤。

本脚本**纯逻辑、无需 Gaussian**（第 6 步会尝试探测本机 Gaussian，找不到就跳过运行部分）。

运行：
    python examples/method_selector_demo.py
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
sys.path.insert(0, os.path.join(_ROOT, "references"))

from gaussian_automation import (  # noqa: E402
    recommend_method, recommend_for_xyz, detect_molecule_class, size_tier,
    explain_recommendation, recommendation_matrix, task_guide,
    list_tasks, list_molecules, case_route, write_gjf, find_gaussian,
)


def banner(title: str) -> None:
    print()
    print("#" * 66)
    print("#", title)
    print("#" * 66)


def demo_guide():
    banner("1. 任务 → 推荐组合速查表（task_guide）")
    print(task_guide())


def demo_detect():
    banner("2. 分子类型自动判别（detect_molecule_class）")
    samples = {
        "苯酚 C6H5OH":       (["C"] * 6 + ["H"] * 6 + ["O"], 0, 1),
        "Fe(II) 配合物":      (["Fe", "N", "N", "N", "N", "C", "C"], 2, 1),
        "甲基碘 CH3I":        (["C", "H", "H", "H", "I"], 0, 1),
        "羧酸根阴离子":        (["C", "C", "O", "O", "H", "H", "H"], -1, 1),
        "OH 自由基":          (["O", "H"], 0, 2),
    }
    for name, (atoms, chg, mult) in samples.items():
        d = detect_molecule_class(atoms, charge=chg, mult=mult)
        print(f"  {name:<16} -> {d['class']:<14} "
              f"({d['label']})  flags={d['flags'] or '-'}")
        for ev in d["evidence"]:
            print(f"      · {ev}")


def demo_scenarios():
    banner("3. 三个完整场景（explain_recommendation 输出全链路解释）")

    print("\n【场景 A】14 原子有机分子，常规优化 + 频率")
    print(explain_recommendation(recommend_method(
        atoms=["C"] * 6 + ["H"] * 6 + ["O"] * 2, task="opt_freq")))

    print("\n【场景 B】含 Fe 的配合物，找过渡态（standard 档）")
    print(explain_recommendation(recommend_method(
        atoms=["Fe"] + ["N"] * 4 + ["C"] * 8 + ["H"] * 12,
        n_atoms=45, task="ts", quality="standard", charge=2, mult=1)))

    print("\n【场景 C】阴离子 + NMR，64 位 g16 机器（对比 32 位的降配结果）")
    for arch in ("x64", "x86"):
        r = recommend_method(atoms=["C", "C", "O", "O", "H", "H", "H"],
                             charge=-1, task="nmr", quality="standard", arch=arch)
        print(f"  arch={arch}: {r['route']}   [{r['resource_label']}]")


def demo_size_effect():
    banner("4. 体系大小如何改变推荐（32 位 vs 64 位）")
    print(f"  {'原子数':<8} {'档位':<10} {'32 位 g09':<26} {'64 位 g16':<26}")
    print("  " + "-" * 70)
    for n in (5, 20, 45, 80, 150):
        r32 = recommend_method(n_atoms=n, task="opt_freq", quality="standard", arch="x86")
        r64 = recommend_method(n_atoms=n, task="opt_freq", quality="standard", arch="x64")
        print(f"  {n:<8} {size_tier(n):<10} {r32['mb']:<26} {r64['mb']:<26}")
    print("\n  说明：32 位 Gaussian 的瓶颈是 %mem（≤~1.5GB），推荐器会按原子数自动降配基组并给出警告。")


def demo_matrix():
    banner("5. 某一任务下「分子类型 → 推荐」的矩阵")
    print(recommendation_matrix(task="opt_freq", quality="standard", arch="x64"))
    print()
    print(recommendation_matrix(task="barrier", quality="standard", arch="x64"))


def demo_pipeline():
    banner("6. 与既有模块联动：推荐 → gjf → 配方路由")
    r = recommend_method(atoms=["C"] * 6 + ["H"] * 6, task="opt_freq")
    print(f"  推荐 mb        : {r['mb']}")
    print(f"  推荐 route     : {r['route']}")
    print(f"  填进既有配方   : {case_route('freq', mb=r['mb'])}")
    print(f"  关联配方列表   : {r['recipes']}")

    out_dir = os.path.join(_HERE, "_recommend_out")
    os.makedirs(out_dir, exist_ok=True)
    gjf = os.path.join(out_dir, "recommended.gjf")
    write_gjf(
        gjf, ["C", "O", "O"],              # 示意：CO2
        [[0.0, 0.0, 0.0], [0.0, 0.0, 1.16], [0.0, 0.0, -1.16]],
        charge=0, mult=1,
        route=r["route"],
        mem=r["mem"], nproc=1, chk="recommended",
    )
    print(f"\n  已生成示例输入文件（不运行）：{gjf}")
    print("  ---- 文件内容 ----")
    print("  " + open(gjf, encoding="utf-8").read().replace("\n", "\n  ")[:600])

    info = find_gaussian()
    if not info["found"]:
        print("  本机未探测到 Gaussian，跳过实际运行。")
        return
    try:
        from gaussian_automation import run_and_save
        os.environ.update({
            "GAUSS_EXEDIR": info["exedir"],
            ("g09root" if info["family"] == "g09" else "g16root"): info["root"],
            "PATH": info["exedir"] + ";" + os.environ.get("PATH", ""),
        })
        # 上面的 CO2 是线性分子、Opt 不易展开；换成水做极小演示
        from gaussian_automation import write_gjf as _w
        demo_gjf = os.path.join(out_dir, "water_recommended.gjf")
        _w(demo_gjf, ["O", "H", "H"],
           [[0, 0, 0.1173], [0, 0.757, -0.4692], [0, -0.757, -0.4692]],
           route=r["route"], mem="1000MB" if info["arch"] == "x86" else "2GB", nproc=1)
        res = run_and_save(demo_gjf, out_dir=out_dir)
        print(f"  推荐组合实跑：ok={res['ok']}  log={res['log']}")
    except Exception as exc:   # pragma: no cover
        print(f"  实跑跳过（{type(exc).__name__}: {exc}）")


if __name__ == "__main__":
    print(f"支持的任务类型（{len(list_tasks())}）: {', '.join(list_tasks())}")
    print(f"支持的分子类型（{len(list_molecules())}）: {', '.join(list_molecules())}")
    demo_guide()
    demo_detect()
    demo_scenarios()
    demo_size_effect()
    demo_matrix()
    demo_pipeline()
