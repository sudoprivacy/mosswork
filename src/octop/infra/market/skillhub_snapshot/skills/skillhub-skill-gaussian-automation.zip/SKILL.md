---
name: skillhub-skill-gaussian-automation
description: "Gaussian 自动化（gaussian-automation）：纯标准库 Python 工具包，覆盖 Gaussian 计算自动化的完整闭环——生成 .gjf 输入、自动探测并调用本机 g16/g09 执行、解析 .log 提取能量/频率/结构/热力学量、生成并归档 .log 与 .chk 结果文件。核心资产 references/gaussian_automation/ 为可直接 import 的 gaussian_automation 包（gjf_writer / runner / log_parser / detect / cpu / utils / recipes / method_selector 模块），examples/ 含完整可跑示例。适用：计算方法与基组的自动选型、批量建模、构象扫描、反应能计算、势能面扫描、光谱计算（IR/Raman/VCD/ROA/UV-Vis/荧"
---

# Gaussian 自动化（Python 工具包）

> **v1.7.0 第四批 10 复杂案例（2026-10-11）**：在前三批 32 个配方基础上新增 **10 个高阶/复杂计算范式**，并在解析器新增 **9 个字段**，全部在**本机 32 位 Gaussian 09 Rev D.01（`D:\Gaussian09\G09W\g09.exe`、`%mem=1000MB`、`nprocs=70%`）真机实测**。10 案例 = `oniom / admp / bs_dft / noneq_pcm / nto / nbo_e2 / scan2d / hirshfeld / link1 / ccsd_t`；**其中 8 个本机跑通（正常终止）**，2 个标记 `g09_d01_ok=False`（构建限制，非语法错误）：`oniom`（本机构建 L101 的 `FFGetT` bug 无法解析任何带层标记的原子名，需 64 位 g09/G16）、`nto`（本机构建接受 `Pop=NTO` 路由但不打印 NTO 块，需 G16）。新增解析字段：`oniom_energies` / `md_trajectory` / `s2` / `pcm_nonequilibrium` / `nto_occupations` / `nbo_e2` / `hirshfeld_charges` / `scan2d` / `ccsd_t_energy`。新增 9 个真机固化坑（见「第四批案例关键坑」）：ONIOM 层标记 32 位 `FFGetT`、ModRedundant 2D 扫描类型字母在前+`NoSymm`、断键对称破缺 HS 必须 `mult=2S+1` 且 BS 用 `Guess=Mix Stable=Opt`、非平衡 PCM 两步 `NonEq=write/read`（第②步 SCRF 勿带 `,Read`）、NTO 本机构建不打印块、NBO E(2) 不能用 `$NBO E2=` 页脚（用默认 `Pop=NBO`）、`--Link1--` 多步每段自带 `%chk`、`CCSD(T)=` 的 D 记法解析。一键编排 `examples/cases4.py` + 回归测试 `examples/validate_cases4.py`（**45/45 断言通过，无需 Gaussian**）。配方总数达 **42 个**。

> **v1.6.0 计算方法 / 基组推荐引擎（`method_selector`，2026-09-27）**：新增方法/基组自动选型能力——输入**体系大小 + 分子类型 + 计算任务 + 本机资源**，输出可直接写进 `.gjf` 的路由行。① `recommend_method()` 返回 `{mb, route, why, alternatives, warnings, follow_up, recipes...}`；② `detect_molecule_class()` 由元素组成自动判别 7 类分子与 anion/cation/open_shell/heavy_halogen/large 修饰标记；③ `recommend_for_xyz()` 从结构文件直接推荐；④ 支持 19 类任务（opt/ts/thermo/weak/uvvis/nmr/epr/nlo/optrot/anharmonic 等，含中文别名）与 fast/standard/accurate 三档精度；⑤ 资源感知：按「原子数档位 × Gaussian 位数」自动降配基组，禁止把 DFT 降到无极化/极小基组，超预算时提示改用半经验 PM6 或 ONIOM；⑥ 自动规则：负电荷补弥散函数、开壳层加 U 前缀、金属加 `SCF=XQC`、自带色散的泛函不重复叠加 Grimme、指定溶剂追加 `SCRF=(PCM,...)``。示例 `examples/method_selector_demo.py`（纯逻辑无需 Gaussian）、回归验证 `examples/validate_method_selector.py`（**18/18 逻辑断言通过**，`--real` 追加 23 项真机关键字验证 **23/23 符合预期**）。真机实测两处反直觉结论已固化：**本机 g09 D.01 不识别 `PBE0` 关键字（必须写 `PBE1PBE`）**、**`APFD` 在本机反而可用**（而 `PM7` 确为 G16-only）。
> **v1.1.0**（2026-09-24）：**新增两大能力 —— ① 本机 Gaussian 自动探测与版本兼容；② .log / .chk 结果文件的生成与保存**。
> **v1.1.0 实战补遗**（2026-09-24 晚）：探测结果新增 `arch` 字段（自动识别 32/64 位，用于约束内存）；新增「实战经验」章节，固化苯酚 B3LYP/6-311G(d,p) 全流程踩坑——**32 位内存上限（%mem≤1.5GB）**、**初始几何共线导致优化器停在对称鞍点（一对简并虚频）**、**必须跑 Freq 验证真实极小点**，以及 Opt→Freq→SP 一键编排范式。
> **v1.1.0 实战补遗 II**（2026-09-24）：解析器新增字段 `excited_states`（TDDFT 激发态：能级/波长/振子强度/对称性）、`mulliken_charges`/`esp_charges`（Mulliken 与 ESP 拟合电荷）、`n_imaginary`（虚频计数，用于过渡态判定）。
> **v1.3.0 第二批 12 案例**（2026-09-24）：搜索并补齐 Gaussian 此前未覆盖的 12 项计算能力——**IRC / NMR=GIAO / PES 扫描 / MP2 / NBO / PCM / Freq=Raman / Counterpoise BSSE / Polar / CIS / Stable=Opt / TD Opt**，全部在本机 32 位 g09（`%mem=1000MB`、`nprocs=12`）真实跑通；解析器据此新增 `nmr_shieldings` / `scan_results` / `mp2_correlation` / `mp2_total` / `cis_energy` / `raman_activities` / `polarizability` / `isotropic_polarizability` / `stability` / `nbo_charges` / `bsse_corrected_energy` / `complexation_energy_corrected` 等字段，并固化 4 个实战坑（ModRedundant `N1 N2 S nsteps stepsize` + `NoSymm`；Counterpoise Cartesian 片段编号写法；`CPolar`/`ECD` 在 g09 D.01 不存在 → 以 CIS 替代；runner 写 `_run.gjf` 必须 LF 行尾）。
> **v1.3.0 补遗：取消 32 位 nprocs 安全封顶**（2026-09-24）：用户要求取消 `resolve_nprocs` 对 32 位 Gaussian 的 4 核封顶——`arch` 仅作信息展示，不再参与核数封顶。**注意**：`%nprocshared=N` 指令本 skill 会正确注入并被 Gaussian 回显（日志 `Will use up to N processors`），但**实际多核利用率取决于 Gaussian 构建本身**。本机 32 位 g09 D.01 的 SMP 并行实测无效——`nprocs=1` 与 `nprocs=12` 跑同一任务墙钟时间几乎相同（10.7s vs 8.5s），`Job CPU time`≈墙钟，说明实际只用约 1 核。故核数不会因 32 位而崩溃（崩溃只来自内存），但**不要指望本机构建靠 nprocs 提速**；真要多核需换带有效 SMP/Linda 并行的 Gaussian 版本（如 g16）。
> **v1.3.0**（2026-09-24）：**新增 CPU 逻辑核数自动解析模块 `cpu.py`**——`logical_cpu_count()` 探测本机逻辑核数；`resolve_nprocs()` 把「用户输入 / gjf 已有 `%nprocs=` `%nprocshared=`」解析为最终核数，支持**绝对核数(12)、百分比(75%)、小数比例(0.75)** 三种写法，并自动约束到 `[1, 逻辑核数]`；`apply_nprocs_to_gjf()` 在 gjf 的 Link 0 区写入/更新核数指令。`run_gaussian()` / `run_and_save()` 新增 `nprocs=` 参数：传入后会把解析结果以 `%nprocshared=` 注入运行副本（覆盖 gjf 原值；v1.3.0 后续已取消 32 位 4 核封顶，核数由调用者按内存余量自定，见上）。**同时把「5 个综合实战案例」（HOMO-LUMO / TDDFT / 过渡态 / ESP / 全流程）正式纳入 v1.3.0 的实战验证基准**：案例脚本 `examples/cases.py` 已改用 `nprocs='75%'` 调用真实跑通，相关实战经验（环境注入 `os.environ`、TDDFT n→π* 弱振子强度、非共线过渡态范例、Pop=MK 单点、32 位规模控制）一并固化入本文档。
> **v1.4.0 基于 12 案例优化**（2026-09-25）：新增 `recipes.py` 计算类型配方目录（`CASE_CATALOG`，17 个配方：opt/freq/ts/tddft/esp + 第二批 12 项），把路由模板、坑点、对应解析字段收敛为单一信息源；`examples/cases2.py` 改为全部从 `case_route()` 取路由。**解析器修复 PCM**：g09 D.01 默认 PCM 不打印 `Free energy of solvation`，新增 `pcm_active` 标记，并新增 `solvation_free_energy(pcm_log, gas_log)` 用「溶液 SCF − 气相 SCF」相减求 ΔG_solv（g16 等会直接打印该值）。新增 `examples/validate_cases2.py` 解析器回归测试——对 12 个真实 `.log` 断言关键字段非 None，**无需 Gaussian 即可运行**。
> **v1.5.0 第三批 15 案例**（2026-09-25）：补全用户指定的 14 个高阶主题（其中 4 个已被既有配方覆盖而跳过，另补 1 个 vibronic 吸收/发射，共新增 15 个配方，配方总数达 32）。真实跑通环境仍为 32 位 g09 D.01（`D:\Gaussian09\G09W\g09.exe`、`%mem=1000MB`、**`nprocs='70%'`** ≈ 11 逻辑核）。**本批新增 8 个解析字段**：`anharmonic_frequencies`（非谐振频率）、`j_couplings`（NMR 自旋-自旋耦合 J，Hz）、`vcd_intensities`（VCD 旋转强度）、`optical_rotation`（静态旋光 Beta）、`roa_intensities`（ROA 强度）、`vibrot_alpha`（振动-转动 α 矩阵）、`hyperfine_couplings`（EPR 超精细 A_iso, MHz）、`g_tensor`（电子 g 张量主值）；`ecd_transitions` 亦预留（G16 下生效）。**本机 g09 D.01 跑通 11 项**；**4 项标记 G16-only**（本机构建不含其模块，路由仍为该版本正确写法）：`franck_condon`/`vibronic`（FCHT/FC 模块缺失）、`eom_ccsd`（EOM 模块缺失）、`ecd`（CPolar 关键字缺失）。本批关键实战坑已固化：激发态势能面改用「冻结几何 + TD 单点扫描」避开 TD Opt 松弛扫描不收敛；非谐振用 Plain `Freq=(Anharmonic)`（VPT2 子选项报错）；VCD 须先在真实极小点（n_imag=0）上算；ROA 必须 `CPHF=RdFreq` + 页脚激光频率；EPR 超精细/ g 张量用开壳层 `UB3LYP NMR`（G16 的 `Hyperfine=` 关键字本机构建不识别）。一键编排 `examples/cases3.py` + 回归测试 `examples/validate_cases3.py`（无需 Gaussian）。

- **① 自动探测**：`run_gaussian()` / `run_and_save()` 在不传 `g16` 时，自动搜索系统 PATH、各平台常见安装目录（Windows `C:\G16W`、Linux `/opt/gaussian/g16` 等）与环境变量 `GAUSS_EXEDIR`，识别 g16/g09 并构造兼容运行环境（`GAUSS_EXEDIR` / `g16root` 等）。无需硬编码可执行路径，跨版本/跨机器通用。
- **③ CPU 核数自动解析**：`logical_cpu_count()` / `resolve_nprocs()` / `apply_nprocs_to_gjf()` 让用户用「数字 / 百分比 / 小数」任意指定并行核数，无需手算。v1.3.0 起**不再对 32 位做核数封顶**——核数上限由调用者按机器内存余量自定（32 位的真正瓶颈是 `%mem`，不是核数，见下）。
- **② 结果生成与保存**：`run_and_save()` 一键运行并把 `.log` 与 `.chk` 归档到指定目录；可通过 `chk=` 显式命名（若 `.gjf` 未写 `%chk=` 会自动注入到副本中，确保生成 `.chk`）；可选 `make_fchk=True` 调用 `formchk` 转成可读 `.fchk`。
- **④ 计算方法/基组推荐（v1.6.0）**：`recommend_method()` 按「体系大小 + 分子类型 + 计算任务 + 本机资源」推荐方法/基组并直接产出路由行。详见下方「计算方法 / 基组自动推荐」章节——**生成 .gjf 之前先跑它**，可省去手挑泛函/基组的决策成本。

## 工具包结构

```
gaussian_automation/
├── __init__.py        # 统一导出
├── gjf_writer.py      # 生成 .gjf 输入（Link0 / 路由 / 坐标 / 连接性 / 页脚；支持 XYZ 生成）
├── runner.py          # 调用 g16/g09 执行 + 自动探测 + .log/.chk 结果保存
├── log_parser.py      # 解析 .log（SCF 能量 / 收敛 / 频率 / 结构 / 热力学 / 偶极 / HOMO-LUMO）
├── detect.py          # 本机 Gaussian 安装探测与版本兼容
├── cpu.py             # CPU 逻辑核数探测 + %nprocs 解析与注入（v1.3.0 新增）
├── recipes.py         # 计算类型配方目录 CASE_CATALOG（v1.7.0，42 个配方）
├── method_selector.py # 计算方法/基组推荐引擎（v1.6.0 新增）
└── utils.py           # XYZ 读写、元素符号↔原子序数互转
```

## 优先路径：把 gaussian_automation 包拷进项目再 import

本技能不依赖任何第三方库。使用流程：

1. 把 `references/gaussian_automation/` 整个目录复制到用户项目的 `gaussian_automation/`（或直接 `import` 本技能自带副本）。
2. 在项目中 `from gaussian_automation import ...` 即可。
3. 快速验证解析（无需 Gaussian）：`python examples/demo.py` 会解析内置 `examples/sample_water.log`。

```python
# 典型三步
from gaussian_automation import write_gjf, run_and_save, parse_log

write_gjf("water.gjf", atoms=["O","H","H"], coords=[...],
          route="# B3LYP/6-31G(d) Opt Freq", chk="water.chk")

# g16=None → 自动探测本机 Gaussian；结果归档到 results/
res = run_and_save("water.gjf", out_dir="results", chk="water", make_fchk=True)

data = parse_log(res["log"])
print(data["scf_energy"], data["frequencies"], data["sum_free_energy"])
```

## 标准工作流

### 第 0 步：前置条件

1. 本机已安装 Gaussian（G16 / G09 均可），有有效许可证。
2. Python ≥ 3.7（纯标准库，无需 pip 安装任何包）。
3. 让 Gaussian 可执行文件可被发现：优先加入系统 PATH，或设置环境变量 `GAUSS_EXEDIR` 指向 Gaussian 可执行文件所在目录（如 `C:\G16W`）。若都不满足，可在调用时显式传 `g16=r"C:\G16W\g16.exe"`。

### 第 0.5 步（推荐）：先让它帮你选方法与基组（v1.6.0）

写 `.gjf` 之前先问一句推荐器，省去手挑泛函/基组的决策成本，也能避免「32 位机器上选了跑不动的基组」这类返工：

```python
from gaussian_automation import recommend_method, explain_recommendation, write_gjf

r = recommend_method(atoms=["C"]*6 + ["H"]*6 + ["O"]*2,   # 或直接 n_atoms=14
                     task="opt_freq", quality="standard")
print(r["mb"])                    # wB97XD/def2SVP
print(r["route"])                 # # wB97XD/def2SVP Opt Freq
print(explain_recommendation(r))  # 理由 / 注意事项 / 警告 / 备选方案 / 后续步骤

write_gjf("phenol.gjf", atoms, coords, charge=0, mult=1,
          route=r["route"], mem=r["mem"], nproc=8, chk="phenol")
```

不了解该用哪个泛函、哪个基组？直接把 `task` / `quality` / 分子类型丢给它即可，完整矩阵见下方「计算方法 / 基组自动推荐」章节。

### 第 1 步：生成输入文件（gjf_writer）

```python
from gaussian_automation import write_gjf, write_gjf_from_xyz

write_gjf(
    path="job.gjf",
    atoms=["C","H","H","H","H"],
    coords=[...],                 # 每项 [x,y,z] (Å)
    charge=0, mult=1,
    route="# B3LYP/6-31G(d) Opt Freq",
    title="my job",
    mem="2GB", nproc=8,          # ⚠️ 见下方“内存/核数”说明；32 位 Gaussian 务必降到 ~1500MB
    chk="job.chk",               # 设了才会生成 .chk
)
# 或从 XYZ 直接生成
write_gjf_from_xyz("job.gjf", "geom.xyz", route="# M062X/def2SVP Opt")
```
`write_gjf` 还支持 `connectivity`（连接性行）与 `footer`（额外作业步 / gen 基组 / modredundant 等）。

### 第 2 步：运行计算（runner + 自动探测）

```python
from gaussian_automation import run_gaussian, run_and_save

# 最简：自动探测本机 Gaussian
log_path, rc = run_gaussian("job.gjf")
print(rc, log_path)

# 一键运行并归档结果（v1.1.0 推荐）
res = run_and_save(
    "job.gjf",
    out_dir="results",           # .log / .chk 写到这里
    chk="job",                   # 显式命名；gjf 无 %chk= 时自动注入
    make_fchk=True,              # 额外生成 results/job.fchk
)
# res = {"log","chk","fchk","returncode","normal","ok"}
```

要点：
- `g16=None`（默认）→ 调用 `detect.find_gaussian()` 自动探测；找不到抛清晰异常（列出已搜索位置）。
- 显式指定：`run_gaussian("job.gjf", g16=r"C:\G16W\g16.exe")`。
- 批量：`run_gaussian_batch(["a.gjf","b.gjf"], on_done=callback)`。
- `.chk` 由 Gaussian 在 `%chk=` 指定时生成（二进制检查点）；`run_and_save` 会复制到 `out_dir`。
- **内存 / 核数**：`%mem` 与 `%nprocshared` 要匹配机器与 Gaussian 位数。探测结果里新增 `arch` 字段（`"x86"`=32 位 / `"x64"`）。**32 位 Gaussian（如本机 G09 Rev D.01 IA32 构建）`%mem` 必须 ≤ ~1.5GB（建议 1000–1500MB），否则一启动即崩溃；核数本身不受 32 位限制**（但本机该 g09 构建的 SMP 并行实际无效，nprocs 多少对墙钟时间几乎无影响，见下方「坑 1 补注」）。64 位 G16 可用 `4GB`/`8` 等更大值。建议用 `info = find_gaussian(); mem = "1000MB" if info["arch"]=="x86" else "4GB"`。
- **核数自动解析（v1.3.0）**：不想手算核数？直接用 `nprocs=` 让工具解析。详见下一节。

### 第 2.5 步：CPU 核数自动解析（%nprocs，v1.3.0 新增）

本机逻辑核数（`os.cpu_count()`，含超线程）会被 `logical_cpu_count()` 自动探测；`resolve_nprocs()` 把用户输入或 gjf 已有指令解析为最终核数；`run_gaussian` / `run_and_save` 的 `nprocs=` 参数会把解析结果以 `%nprocshared=` 注入运行副本（自动覆盖 gjf 原值）。v1.3.0 起**不再对 32 位做核数封顶**——核数由调用者按机器内存余量自行决定（32 位的真正瓶颈是 `%mem`，不是核数）。

**三种写法**：
```python
from gaussian_automation import logical_cpu_count, resolve_nprocs, apply_nprocs_to_gjf

print(logical_cpu_count())          # 如 16（本机逻辑核数）

# 1) 绝对核数：用 12 核
resolve_nprocs(user_input=12)                       # -> 12
# 2) 百分比：本机 16 核的 75% -> 12 核
resolve_nprocs(user_input="75%")                    # -> 12
resolve_nprocs(user_input=0.75)                    # -> 12（0~1 小数视为比例）
# 3) 读取 gjf 首行 %nprocs=8（或 %nprocshared=8）
resolve_nprocs(gjf_path="job.gjf")                 # -> 8（gjf 写了 %nprocs=8 即表示 8 核）
# 越界自动夹紧到 [1, 逻辑核数]；v1.3.0 起不再对 32 位做核数封顶（arch 仅作信息展示）
resolve_nprocs(user_input=999)                     # -> 16（=逻辑核数）
resolve_nprocs(user_input=8, arch="x86")           # -> 8（不再封顶；arch 仅信息展示）
```

**实战：运行时直接指定核数（推荐）**
```python
from gaussian_automation import write_gjf, run_and_save, find_gaussian

info = find_gaussian()                 # arch 仅作信息展示（v1.3.0 起不再用于核数封顶）
mem  = "1500MB" if info.get("arch") == "x86" else "4GB"

write_gjf("water.gjf", ["O","H","H"], coords, route="# B3LYP/6-31G(d) Opt",
          mem=mem, chk="water")

# nprocs 三种写法任选其一；不传则沿用 gjf 自身设置
res = run_and_save("water.gjf", out_dir="results", nprocs="75%")   # 本机 16 核 -> 实际生效核数见 .log（注：本机 32 位 g09 SMP 并行无效，见坑 1 补注）
print(res["ok"])

# 也可先把核数写进 gjf 首行（%nprocs= 会被自动识别并归一化为 %nprocshared=）
apply_nprocs_to_gjf("water.gjf", 8, directive="%nprocs")          # 首行写入 %nprocs=8
```

要点：
- gjf 里写 `%nprocs=8`（用户习惯写法）或 `%nprocshared=8` 都能被识别；工具在运行副本中统一归一化为 `%nprocshared=`，保证所有 Gaussian 版本都接受。
- 优先级：**`nprocs=` 显式输入 > gjf 已有指令 > 默认（全部逻辑核）**。
- 32 位 Gaussian：v1.3.0 已取消核数封顶（`arch="x86"` 仅作信息展示，不再强制 ≤4）。**32 位真正的地址空间限制来自 `%mem`**（如 `400MW`≈3.2GB 会崩），核数指令本身可拉高（如本机 `%nprocshared=12` 会被正确注入并回显）——但**本机 32 位 g09 D.01 的 SMP 并行实测无效，实际只用约 1 核，不要指望靠 nprocs 提速**（详见下方坑 1 补注）。请务必把 `%mem` 压在 ~1.5GB 内。显式传 `g16` 而不让工具自动探测时，同样需自行控制内存/核数。
- `%mem` 单位坑：Gaussian 的 `MW` = megawords ≈ 8 bytes/word（400MW≈3.2GB），容易把 32 位进程撑爆；日常用 `MB`（如 `1500MB`）更直观安全。

### 第 3 步：解析输出（log_parser）

```python
from gaussian_automation import parse_log, summarize

d = parse_log("results/job.log")
d["scf_energy"]          # 最终 SCF 能量 (Hartree)
d["converged"]           # 几何优化是否收敛
d["frequencies"]         # 振动频率列表 (cm^-1)
d["intensities"]         # 对应红外强度
d["optimized_geometry"]  # {"atoms":[...], "coords":[[x,y,z],...]}
d["sum_free_energy"]     # 含热校正吉布斯自由能
d["dipole"]              # 偶极矩 (Debye)
d["homo_lumo"]           # (HOMO, LUMO)
d["excited_states"]      # [(state, label, eV, nm, f), ...]  TDDFT 激发态
d["mulliken_charges"]    # [(symbol, charge), ...]  Mulliken 电荷
d["esp_charges"]        # [(symbol, charge), ...]  ESP(Merz-Kollman) 拟合电荷
d["n_imaginary"]        # 虚频(负频率)数目；过渡态判定：==1 且 converged 即一阶鞍点
d["normal_termination"]  # 是否 "Normal termination"
# —— 第二批 12 案例新增字段 ——
d["nmr_shieldings"]     # [(symbol, ppm), ...]        NMR 各向同性屏蔽常数 (GIAO)
d["scan_results"]       # [(step, 坐标值, 能量), ...] PES 扫描（Opt=ModRedundant）
d["mp2_correlation"]    # MP2 相关能 E2 (Hartree)
d["mp2_total"]          # MP2 总能量 EUMP2 (Hartree)
d["cis_energy"]         # CIS 总能量 E(CIS) (Hartree)
d["pcm_solvation_free_energy"] # PCM 溶剂化自由能（g09 D.01 通常 None，需气相相减）
d["raman_activities"]   # [float, ...]               Raman 散射活性
d["polarizability"]     # [xx, xy, xz, yy, yz, zz]   极化率张量
d["isotropic_polarizability"]   # 各向同性极化率 (Bohr^3)
d["stability"]          # "stable" / "unstable"       波函数稳定性
d["nbo_charges"]        # [(symbol, charge), ...]     NBO 自然电荷
d["bsse_corrected_energy"]     # Counterpoise 校正后能量 (Hartree)
d["complexation_energy_corrected"] # 校正后复合能 (kcal/mol)
# —— 第三批 15 案例新增字段（v1.5.0）——
d["anharmonic_frequencies"]   # [(mode, harmonic, anharmonic), ...]  非谐振频率 (cm^-1)
d["j_couplings"]              # [(sym_i, sym_j, Hz), ...]             NMR 自旋-自旋耦合常数 (下三角)
d["vcd_intensities"]          # [float, ...]                         振动圆二色性旋转强度（与 frequencies 对应）
d["optical_rotation"]         # float|None                            静态光学旋光 Beta (au)
d["roa_intensities"]          # [float, ...]                         拉曼光学活性强度（与 frequencies 对应）
d["vibrot_alpha"]             # [[...], ...]                          振动-转动相互作用常数矩阵 (cm^-1)
d["hyperfine_couplings"]      # [(symbol, A_iso_MHz), ...]           EPR 超精细耦合 (各向同性, MHz)
d["g_tensor"]                 # [Gx, Gy, Gz]                          电子 g 张量主值 (ppm)
d["ecd_transitions"]          # [(state, rotatory), ...]|None        ECD 旋光强度（仅 G16 CPolar 生效，g09 下 None）
# —— 第四批 10 案例新增字段（v1.7.0）——
d["oniom_energies"]     # {"extrapolated":float, "n_models":int}|None  ONIOM 分层外推能量（g09 D.01 因 FFGetT bug 为 None，需 G16）
d["md_trajectory"]      # [(step:int, energy:float), ...]|None        第一性原理 MD（ADMP）能量轨迹
d["s2"]                 # float|None                              <S**2> 期望值（开壳层/断键对称破缺；闭壳层为 None）
d["pcm_nonequilibrium"] # bool                                   是否使用非平衡 PCM（NonEq=write/read 两步）
d["nto_occupations"]    # [(state, occ), ...]|None               NTO 主导占据数（g09 D.01 下为 None，需 G16）
d["nbo_e2"]             # [(donor, acceptor, E2_kcal), ...]      NBO 二阶微扰 E(2) 供体-受体超共轭（无超阈值对时为 []）
d["hirshfeld_charges"]  # [(symbol, charge), ...]|None           Hirshfeld (Stockholder) 电荷
d["scan2d"]             # [(coords_list, energy), ...]|None      2D 双变量势能面扫描网格点（每条 = 一组内坐标 + 该点能量）
d["ccsd_t_energy"]      # float|None                             CCSD(T)= 总能量 (Hartree)
print(summarize("results/job.log"))   # 人类可读摘要
```
所有字段“尽力而为”：缺失则对应字段为 `None`。

## 典型应用场景

- **批量构象/分子扫描**：遍历 XYZ / SMILES 列表 → 批量 `write_gjf` → `run_gaussian_batch` → 汇总 `parse_log` 取能量。
- **反应能 / 相对能量**：对每个物种跑单点能或 Opt+Freq，用 `sum_free_energy` 算反应焓/自由能。
- **光谱计算**：Freq 作业后解析 `frequencies` / `intensities` 画图。
- **失败重试 / 作业监控**：`run_and_save(... )["ok"]` 驱动重试逻辑。
- **集群提交**：把 `run_gaussian` 换成提交 SLURM/PBS 的封装，解析层完全复用。
- **.chk 后处理**：`run_and_save(..., make_fchk=True)` 生成 `.fchk`，供 Multiwfn / GaussView 等读取波函数/轨道。

## 实战经验（来自苯酚 B3LYP/6-311G(d,p) 全流程）

以下是从一次真实计算（苯酚：几何优化 → 单点能 → 频率）中沉淀出的硬性经验，务必先看一遍再上机。

### 坑 1：32 位 Gaussian 的内存上限（最致命）
- 若 Gaussian 是 **32 位 IA32 构建**（如本机 Gaussian 09 Rev D.01，横幅写 `IA32W-G09RevD.01`），`%mem` 申请超过约 2–3 GB 会**直接崩溃**，`.log` 末尾常只抛一个 `Error` 或不输出。这是位数限制，不是字面上的内存不足。
- **对策**：`%mem=1000MB`（保守可取 1000–1500MB）是稳妥值（本机实测苯酚 13 原子、6-311G(d,p) 约 1 分钟完成）。`find_gaussian()` 现已返回 `arch`（x86/x64），可据此自动选内存。**核数不是 32 位崩溃的诱因**——但本机该 g09 D.01 构建的 SMP 并行实测无效（见下方「坑 1 补注」），故 nprocs 设多少对墙钟几乎无影响，不必纠结核数：
  ```python
  info = find_gaussian()
  mem = "1000MB" if info.get("arch") == "x86" else "4GB"
  # 32 位真正限制是内存，不是核数；本机构建多核并行无效，nprocs 仅作指令传递
  nproc = 12 if info.get("arch") == "x86" else 8
  ```
- 判断位数的另一个办法：看 Gaussian 启动横幅是否含 `IA32` 字样（含 → 32 位）。
- **坑 1 补注（SMP 并行实测无效）**：本机 g09 D.01（IA32）虽会在日志回显 `Will use up to N processors via shared memory` 并接受 `%nprocshared=N`，但**实测并不真正多核并行**——同一 MP2 任务 `nprocs=1` 墙钟 10.7s、`nprocs=12` 墙钟 8.5s（仅 1.26× 加速），且 `Job CPU time` ≈ 墙钟，表明实际只用约 1 核。这是该 32 位 SMP 构建的固有限制；本 skill 的 nprocs 指令传递本身无误，但若需真正多核加速，请换用带有效 SMP/Linda 并行的 Gaussian（如 g16 或正确编译的 g09 SMP 版）。

### 坑 2：初始几何共线 → 优化器停在对称鞍点（隐蔽坑）
- 构造初始坐标时，**切勿把含 H 的轻原子沿两个重原子的连线放置**。示例：苯酚若把 O–H 氢放在 C→O 延长线上，会导致 **C–O–H 严格共线（180°）**。优化器在对称性下被卡在鞍点——力矩/梯度恰好为零，于是报"Optimization completed"却**不是极小点**。
- 该鞍点在频率分析里会暴露为**一对简并虚频**（本例为 -1240.85 / -1161.22 cm⁻¹，对应 O–H 在平面内/外弯曲）。能量也比真实极小点高（本例鞍点 -307.50398 vs 真实 -307.55186 Hartree）。
- **对策**：给一个物理合理的非共线初始角（苯酚 C–O–H ≈ 120°）。修正后同一作业收敛到真实极小点，虚频消失。

### 坑 3：只看 "Optimization completed" 不可靠，必须跑 Freq 验证
- "优化完成"≠"真实极小点"。**Opt 之后务必跑 Freq（或合并 `Opt Freq` 单作业）**，确认**无虚频**才算数。频率还能顺带给出红外谱与热力学量。
- 本例合并 `Opt Freq` 作业结果：33 个实频、0 虚频 → 确认真实极小点。298.15 K 热力学：ZPE=0.104306、热校正 G=0.075318、绝对 G=-307.476542 Hartree；最强 IR 峰 1200.42 cm⁻¹（C–O 伸缩/环呼吸），O–H 伸缩 3829.57 cm⁻¹（B3LYP 高估且无非谐校正，偏高属正常）。

### 推荐工作流：Opt → Freq → SP（可一键编排）
```python
from gaussian_automation import write_gjf, run_and_save, parse_log, find_gaussian

info = find_gaussian()                 # 自动探测 + 架构
exe  = info["exe"]
mem  = "1500MB" if info.get("arch") == "x86" else "4GB"

# 1) 几何优化（同时把 chk 留好，供后续 Freq 用）
write_gjf("phenol_opt.gjf", atoms, coords, charge=0, mult=1,
          route="# B3LYP/6-311G(d,p) Opt", mem=mem, nproc=4, chk="phenol_opt.chk")
o = run_and_save("phenol_opt.gjf", out_dir="results", g16=exe, make_fchk=True)
opt = parse_log(o["log"])
assert opt["converged"] and opt["normal_termination"], "优化失败"

# 2) 频率（合并 Opt Freq 单作业，保证频率与几何严格一致、且能验证极小点）
og = opt["optimized_geometry"]
write_gjf("phenol_ofq.gjf", og["atoms"], og["coords"], charge=0, mult=1,
          route="# B3LYP/6-311G(d,p) Opt Freq", mem=mem, nproc=4, chk="phenol_ofq.chk")
f = run_and_save("phenol_ofq.gjf", out_dir="results", g16=exe, make_fchk=True)
fr = parse_log(f["log"])
imag = [v for v in fr["frequencies"] if v < 0]
print("虚频数:", len(imag), "(0 = 真实极小点)")

# 3) 单点能（用优化结构重新算，可换更大基组/加色散）
sp = run_and_save("phenol_sp.gjf", out_dir="results", g16=exe)
print("SP SCF:", parse_log(sp["log"])["scf_energy"])
```

## 注意事项与故障排查

- **找不到 Gaussian**：先确认 `g16`/`g09` 在 PATH，或设置 `GAUSS_EXEDIR`；也可显式传 `g16` 绝对路径。`find_gaussian()` 返回 `{"found":False,"searched":[...]}` 时，异常信息会列出已搜索目录。常见安装目录已内置（Windows 含 `C:\G16W`、`D:\Gaussian09\G09W`、`D:\Gaussian16\G16W` 等；Linux 含 `/opt/gaussian/g16` 等）。若你的安装路径特殊，可直接 `find_gaussian(r"绝对路径")` 或把目录加进 `GAUSS_EXEDIR`。
- **32 位 Gaussian 崩溃**：`%mem` 务必 ≤ ~1.5GB，否则一启动即崩（详见上方“实战经验 · 坑 1”）。**核数不受 32 位限制**——本机 32 位 g09 实测 `nprocs=12` 正常，无需 ≤4。
- **版本兼容**：探测逻辑同时识别 g16 与 g09，并据可执行文件名设置 `g16root` / `g09root` 与 `GAUSS_EXEDIR`。Linux 下若 Gaussian 仍需 `source g16.profile`，建议在调用前于环境里 source，或把对应目录加入 `GAUSS_EXEDIR`。
- **没有 .chk 文件**：检查 `.gjf` 是否写了 `%chk=xxx`（或用 `run_and_save(..., chk="xxx")` 自动注入）。`.chk` 生成在 `cwd`（默认 `.gjf` 所在目录），`run_and_save` 会把它复制到 `out_dir`。
- **formchk 失败**：`make_fchk=True` 时若 `formchk` 不在 PATH，可显式传入 `g16` 让其从同目录定位 `formchk`。
- **解析字段为 None**：说明该作业未产出对应信息（如未做 Freq 则无频率；未收敛则 `converged=False` 但 `optimized_geometry` 可能为空）——先 `summarize()` 看整体状态。
- **Windows 中文路径**：建议工作目录与文件名使用 ASCII，避免 Gaussian 旧版本对中文路径的支持问题。

## 5 个综合实战案例（HOMO-LUMO / TDDFT / 过渡态 / ESP / 全流程）

以下 5 个案例作为 **v1.3.0** 的实战验证基准，已在本机（Gaussian 09 Rev D.01 32 位，`D:\Gaussian09\G09W\g09.exe`，`%mem=1500MB`）用 `nprocs='75%'` 调用新版核数特性真实跑通（75% 逻辑核 = 12 核；v1.3.0 后续已取消 32 位 4 核封顶，核数按内存余量自由设定），方法统一为 **B3LYP/6-31G(d)**。一键编排脚本见 `examples/cases.py`，结果汇总见 `examples/make_report.py`。

| 案例 | 主题 | 路线（route） | 关键结果 |
|------|------|---------------|----------|
| 1 | HOMO-LUMO 能隙 | `# ... Opt` | 乙烯能隙 7.73 eV（实验~7.6） |
| 2 | TDDFT 激发态 | `# ... Opt TD=(NStates=6)` | 甲醛 S1=4.02 eV(n→π*, f≈0)、S3=9.15 eV(π→π*, f=0.14) |
| 3 | 过渡态搜索 | `# ... Opt=(TS,CalcFC,MaxCyc=100) Freq` | 乙烷扭转 TS，1 个虚频 -304.67 cm⁻¹ → 确认过渡态 |
| 4 | 静电势(ESP) | `# ... Pop=MK` | 水：O=-0.757、H=+0.378（物理合理） |
| 5 | 全流程 | `# ... Opt Freq TD=(NStates=5) Pop=MK` | 苯：能隙 6.73 eV、S1=5.60 eV、ESP 电荷、无虚频 |

### 关键经验

**0. 环境必须注入 os.environ（最高频踩坑）**
`run_and_save` 通过继承 `os.environ` 调用 Gaussian。若只调 `find_gaussian()` 而不把环境写进 `os.environ`，会报 `No executable for file l1.exe. Search path GAUSS_EXEDIR is ""`——内部 Link 找不到。务必：
```python
info = find_gaussian()
os.environ.update({
    "GAUSS_EXEDIR": info["exedir"], info["root"] and ("g09root" if info["family"]=="g09" else "g16root"): info["root"],
    "GAUSS_SCRDIR": "./scratch", "PATH": info["exedir"] + ";" + os.environ.get("PATH",""),
})
```

**1. HOMO-LUMO**：普通 `# ... Opt` 作业即可；能隙换算 `(LUMO-HOMO)*27.2114` 得 eV。`homo_lumo` 取闭壳层 alpha 最高占据/最低空轨道。

**2. TDDFT**：路线用 `Opt TD=(NStates=N)`（优化后在同结构做 TD）。解析后读 `excited_states=[(state,label,eV,nm,f),...]`。注意 n→π* 跃迁振子强度 `f≈0`（对称禁阻，如甲醛 S1），π→π* 的 `f` 才显著——别误以为没算出来。

**3. 过渡态**：
- **优先用非共线体系**（如 Gaussian 手册经典的**乙烷 C-C 扭转过渡态**：重叠式初猜 + `Opt=(TS,CalcFC,MaxCyc=100) Freq`），PES 简单、稳定收敛。
- **判定标准**：Freq 后 `n_imaginary==1`（恰好 1 个虚频）且 `converged` → 一阶鞍点（过渡态）。`n_imaginary` 字段直接给出虚频计数。
- **避免线性过渡态**：如 HCN⇌HNC 是线性三原子，Gaussian 构建内坐标时会报 `Problem with coordinate system`；即便用 `Opt=(TS,CalcFC)` 也容易因曲率步不收敛失败。
- **慎用 QST2**：g09 的 QST2 对第二结构读取有怪癖，常报 `End of file in ZSymb.`（即便 .gjf 格式看似正确）。单步 TS 搜索用 `Opt=(TS,CalcFC)` + 合理初猜更稳。

**4. 静电势 ESP**：路线用 `# ... Pop=MK`（Merz-Kollman）或 `Pop=CHelpG`，解析读 `esp_charges=[(symbol,charge),...]`。物理预期：电负性大的原子带负电（如水 O 负、H 正）。注意 `Pop=MK` 是**单点计算**，没有优化步骤，因此 `converged=None` 属正常（不是失败）。若想要可视化 ESP 分布，可改用 `Cube=(ESP,Density)` 生成 `.cube` 文件后用 Multiwfn/GaussView 看。

**5. 32 位规模控制**：本机 32 位 Gaussian 内存 ≤1.5GB，分子尽量小（≤~12 原子、6-31G(d) 基组足够）；苯（12 原子）的 Opt+Freq+TDDFT+ESP 全流程约几分钟可完成。

## 计算类型配方速查（recipes.CASE_CATALOG）

v1.4.0 把上述全部计算类型（5 个基础 + 第二批 12 个）沉淀为一份**可复用配方目录** `references/gaussian_automation/recipes.py`；**v1.5.0 第三批再新增 15 个高阶配方**（激发态/光谱/EPR 类），**v1.7.0 第四批再新增 10 个复杂配方**（ONIOM/ADMP/断键对称破缺/非平衡 PCM/NTO/NBO E(2)/2D 扫描/Hirshfeld/Link1 链/CCSD(T)），配方总数达 **42 个**。每个配方含：路由模板、用途、本机 g09 D.01 可用性（`g09_d01_ok`）、关键坑、对应解析字段、特殊步骤标记。

```python
from gaussian_automation import CASE_CATALOG, case_route, list_cases, catalog_summary

# 查看全部 42 个配方名
print(list_cases())                      # ['opt','freq','ts','tddft','esp','irc','nmr','scan',...,'oniom','admp','bs_dft',...]

# 取某类型的完整路由行（自动填入方法/基组，默认 B3LYP/6-31G(d)）
print(case_route("nmr"))                # # B3LYP/6-31G(d) NMR=GIAO
print(case_route("mp2"))                # # MP2/6-31G(d)   （MP2 固定方法，mb 无效）
print(catalog_summary())                # 人类可读的速查表
```

特殊配方（`special` 标记）普通 `write_gjf(route=...)` 不够，需额外步骤——这些坑已在下方实战章节固化：

- `irc` → `ts_then_irc`：先 Opt=(TS) 定位过渡态，再用其几何跑 `IRC=CalcFC`。
- `scan`/`scan2d` → `modredundant_footer`：路由加 `Opt=ModRedundant NoSymm`，并在 gjf 页脚写扫描指令。⚠️ **扫描代码类型字母在前**：键长 `B 1 2 S 3 0.10`、角 `A 2 1 3 S 3 5.0`（原子号在类型字母之后）；2D 扫描写两条。
- `bsse` → `counterpoise_cartesian`：手写 gjf，Cartesian 坐标每个原子行末加片段编号(1/2)，不用 `--` 分隔符。
- `oniom` → `oniom_layers`：手写 gjf，坐标段用层标记（模型“高层”原子名不加后缀、仅“低层专属”原子加 `(L)`）。⚠️ **本机 32 位 g09 D.01 的 L101 对带层标记的原子名触发 `FFGetT` 硬错（rc=1）**，语法本身正确，需 64 位 g09/G16。
- `bs_dft` → `bs_workflow`：跑两次——① 高自旋 `mult=2S+1` 直算得 E_HS 与 `<S²>_HS`；② 断键对称破缺 `mult=1 Guess=Mix Stable=Opt` 得 E_BS 与 `<S²>_BS`；J_AB = (E_BS−E_HS)/(<S²>_HS−<S²>_BS) × 627.509 kcal/mol。
- `noneq_pcm` → `noneq_workflow`：两步——① S0 平衡 PCM `Opt Freq` + 页脚 `NonEq=write`；② 读该 chk（`Geom=AllCheck`，**SCRF 勿带 `,Read`**）+ 页脚 `NonEq=read` 做 TD，得非平衡发射能。
- `nbo_e2` →（v1.7.0 起 `special=None`）：直接 `Pop=NBO` 即可触发 NBO 二阶微扰表（默认阈值 0.5 kcal/mol）；⚠️ **不能用页脚 `$NBO E2=10.0 $END` 自定义阈值**（本机构建报 `Unrecognizable keyword >>E2<<`）。
- `link1` → `link1_chain`：`--Link1--` 串联多步作业，每段自带 `%chk` 贯穿；中间步用 `Geom=AllCheck` 时**不写电荷/多重度卡**（从 chk 读）。

> 配方是**路由与知识的单一信息源**：`examples/cases2.py` 的 12 个案例全部通过 `case_route(...)` 取路由，SKILL 文档与脚本不再各写一份，避免漂移。

## 第四批 10 复杂案例（v1.7.0，本机 32 位 g09 D.01 真机实测）

本批覆盖前三批未涉及、且科研/工程中高频的“复杂”计算范式。全部在 `D:\Gaussian09\G09W\g09.exe`（`%mem=1000MB`、`nprocs=70%`、32 位 IA32 构建）**真实跑通验证**；一键编排见 `examples/cases4.py`，回归测试见 `examples/validate_cases4.py`（解析 10 份真机 `.log`，45/45 断言通过，无需 Gaussian）。

| 案例 | 主题 | 代表性路由 | 本机实测结果 | `g09_d01_ok` |
|---|---|---|---|---|
| `oniom` | ONIOM 分层 QM/MM | `# ONIOM(B3LYP/6-31G(d):UFF) Opt` | rc=1（L101 `FFGetT` bug，**无法解析层标记原子名**） | **False**（需 64 位 g09/G16） |
| `admp` | 第一性原理 MD | `# B3LYP/6-31G(d) ADMP=MaxPoints=20` | 正常终止；末步 E=−76.28335 Ha（水） | True |
| `bs_dft` | 断键对称破缺反铁磁耦合 | `# UB3LYP/6-31G(d) Guess=Mix Stable=Opt` | 正常终止；O₂ 得 J=+5.25 kcal/mol | True |
| `noneq_pcm` | 非平衡 PCM 荧光发射 | `# ... TD SCRF=(PCM,Solvent=Water) NonEq=read` | 正常终止；S1=4.141 eV（甲醛，NonEq） | True |
| `nto` | 自然跃迁轨道 NTO | `# ... TD=(NStates=5) Pop=NTO` | 正常终止但**不打印 NTO 块**（需 G16） | **False** |
| `nbo_e2` | NBO 二阶微扰 E(2) | `# B3LYP/6-31G(d) Pop=NBO` | 正常终止；氨无 E(2)>0.5（列表为空，属正常） | True |
| `scan2d` | 2D 双变量势能面扫描 | `# B3LYP/6-31G(d) Opt=ModRedundant NoSymm` | 正常终止；16 网格点，能量跨度 0.0504 Ha（水） | True |
| `hirshfeld` | Hirshfeld 电荷 | `# B3LYP/6-31G(d) Pop=Hirshfeld` | 正常终止；O=−0.4x、H=+0.2x e（水） | True |
| `link1` | 多步作业链 `--Link1--` | `# Opt Freq --Link1-- # ...SP --Link1-- # ...TD` | 3 步全部正常终止；S1=7.915 eV（水） | True |
| `ccsd_t` | CCSD(T) 黄金标准 | `# CCSD(T)/6-31G(d)` | 正常终止；E=−76.18058 Ha（水） | True |

> 本机 32 位 g09 D.01 的 SMP 并行无效，`nprocs=70%` 仅为指令传递值（详见坑 1 补注）；真多核需带有效 SMP/Linda 的 Gaussian（如 g16）。

### 第四批案例关键坑（v1.7.0 真机固化）

1. **ONIOM 层标记在 32 位 g09 D.01 触发 `FFGetT`（致命）**：本构建 L101 读取带层标记的原子名（Cartesian `C`/`H(L)` 与 Z-matrix 两种写法**均实测 rc=1**）会抛 `String too long in FFGetT`。这是构建限制，不是语法错误——规范 2 层写法（模型“高层”原子名不加后缀、仅“低层专属”原子加 `(L)`）在 64 位 g09/G16 可直接跑。本机 `oniom_energies` 解析字段已就绪，升级后即可用。

2. **ModRedundant 2D 扫描：扫描代码类型字母在前 + 必须 `NoSymm`**：页脚写法 `B 1 2 S 3 0.10`（B=键、原子 1–2、S=步长、3 步、增量 0.10 Å）与 `A 2 1 3 S 3 5.0`（A=角、顶点在 2）。类型字母（B/A）**必须在原子号之前**，写成 `1 2 S 3 0.10` 会被判 “Wanted an end-of-line” 而 rc=1。务必 `NoSymm`，否则对称性会折叠扫描变量。解析 `scan2d` 每条 =（一组内坐标值, 该点能量）。

3. **断键对称破缺（BS-DFT）反铁磁 J**：必须跑两次——① 高自旋 HS `mult=2S+1`（如 O₂ 三重态 `mult=3`），直算 E_HS 与 `<S²>_HS`；② 断键对称破缺 BS `mult=1 Guess=Mix Stable=Opt` 得 E_BS 与 `<S²>_BS`。J_AB = (E_BS−E_HS)/(<S²>_HS−<S²>_BS) × 627.509 kcal/mol（负=反铁磁）。⚠️ HS 忘写 `mult=3` 会退化为单重态、`<S²>_HS` 错得 ~0，J 失真；`<S²>` 取日志中**最后一个**（HF 收敛后打印）。

4. **非平衡 PCM 荧光：两步 `NonEq=write/read`**：① S0 平衡 PCM `Opt Freq`，页脚 `NonEq=write`（把平衡反应场存入 chk）；② 读该 chk（`Geom=AllCheck`）+ 页脚 `NonEq=read` 做 TD，得垂直发射能。⚠️ 第②步 SCRF **不要写 `,Read`**（由 `NonEq=read` 接管），否则与显式电荷/多重度卡冲突报错。解析 `pcm_nonequilibrium` 标记本步为非平衡模式。

5. **NTO 本机构建不打印块（需 G16）**：g09 D.01 接受 `Pop=NTO` 路由（rc=0）但不输出 NTO 占据数块；`nto_occupations` 在本机构建下为 `None`（G16 下为 `[(态, 占据数), ...]`）。

6. **NBO E(2) 不能用 `$NBO` 页脚自定义阈值**：本机构建对页脚 `$NBO E2=10.0 $END` 报 `Unrecognizable keyword >>E2<<`（rc=1）。改为路由直接 `Pop=NBO`（默认阈值 0.5 kcal/mol）即可触发 NBO 二阶微扰表。若体系无超过阈值的供体-受体对（如氨），`nbo_e2` 为**空列表**（非 `None`），属正常。

7. **`--Link1--` 多步作业链：每段自带 `%chk`，AllCheck 步不写电荷卡**：多步链中 `%chk` 不会自动跨 `--Link1--` 继承——后续步若只写 `Geom=AllCheck` 而不重复 `%chk`，Gaussian 会去找默认 `gxx.chk` 而报 `FileIO operation on non-existent file`（看似第 3 步莫名崩）。**每段都显式写 `%chk=同一名字`**。用 `Geom=AllCheck`/`Guess=Read` 的步**不要写电荷/多重度卡**（从 chk 读）。

8. **`CCSD(T)=` 的 D 记法解析**：g09 日志里 CCSD(T) 能量写作 `CCSD(T)= -0.76D+02`（D 记法），解析时需把 `D→E` 再转 float，否则抓不到。同理 ADMP 轨迹的 `Total energy ... A.U.` 也用 D 记法。

9. **`<S²>`（开壳层）解析**：仅开壳层（UHF/UB3LYP）收敛后打印；闭壳层 RHF 不打印 → `s2=None`（符合预期）。断键对称破缺判据读 HS/BS 各自的最后一行 `<S**2>`。

## 计算方法 / 基组自动推荐（method_selector，v1.6.0）

Gaussian 有上百个方法关键字、上千种基组——「25 原子的金属配合物找过渡态该用什么」这类问题不该每次从头决策。
本模块把常见组合沉淀成一份**可审计的推荐矩阵**：给约束，产出路由行，并交代清楚为什么选、代价多大、备选是什么、下一步做什么。

```python
from gaussian_automation import recommend_method, explain_recommendation

r = recommend_method(n_atoms=25, molecule="organic", task="opt_freq")
r["mb"]        # "wB97XD/def2SVP"
r["route"]     # "# wB97XD/def2SVP Opt Freq"
print(explain_recommendation(r))   # 理由 / 要点 / 警告 / 备选 / 后续步骤
```

### 输入维度

| 维度 | 取值 | 说明 |
|------|------|------|
| 分子类型 `molecule` | `organic` / `tm_complex` / `heavy_element` / `main_group` / `cluster` / `biopolymer` / `general` | 不给则由元素组成**自动判别**（也支持中文："金属配合物"、"团簇"） |
| 计算任务 `task` | 19 类，下附速查表；支持中文别名（"红外"、"能垒"、"耦合常数"…） | 决定主关键字（Opt / Freq / TD / NMR …）与精度取向 |
| 精度 `quality` | `fast` / `standard` / `accurate` | 同一任务的三档必然给出不同组合 |
| 环境 `arch` | `x86`（32 位 g09，≤~1.5GB）/ `x64`（常规 64 位） | 影响基组预算；不给时自动探测本机（`detect.find_gaussian()["arch"]`） |

**分子类型自动判别规则**（`detect_molecule_class`）：含过渡金属/镧系 → `tm_complex`；含 Z≥36 或 Br/I → `heavy_element`；其余 → `organic`。
另产出修饰标记：`anion`（负电荷 → 需弥散函数）、`cation`、`open_shell`（mult≠1 → 加 U 前缀）、`heavy_halogen`、`large` / `very_large`（>60 / >120 原子）。

### API 一览

| 函数 | 作用 |
|------|------|
| `recommend_method(n_atoms=, atoms=, molecule=, task=, quality=, charge=, mult=, solvent=, dispersion=, arch=)` | 核心推荐；`atoms=` 可同时提供元素组成与数量 |
| `recommend_for_xyz("mol.xyz", task=..., **kw)` | 从 XYZ 直接读结构来推荐 |
| `detect_molecule_class(atoms, charge, mult)` | 只想知道分子类型时用 |
| `explain_recommendation(rec)` | 把推荐结果渲染成人类可读报告 |
| `task_guide(quality=, molecule=, n_atoms=, arch=)` | 全部任务一行一条的速查表 |
| `recommendation_matrix(task, quality, arch)` | 某任务下「分子类型 → 组合」的矩阵 |
| `list_tasks()` / `list_molecules()` / `size_tier(n_atoms)` | 枚举支持的任务/类型；查询尺寸档位 |

推荐结果 `rec` 的关键字段：`mb`（方法/基组）、`route`（可直接写进 gjf）、`why` / `notes` / `warnings` / `alternatives` / `follow_up` / `recipes`、`options`（GD3BJ、SCF=XQC、SCRF…）、`mem` / `nproc_hint` / `cost` / `size_tier`。

### 任务 → 推荐速查表（standard 档，20 原子有机分子）

64 位环境（`task_guide(arch="x64")`）：

```
几何优化                     wB97XD/def2SVP             # wB97XD/def2SVP Opt
几何优化 + 频率（推荐默认）     wB97XD/def2SVP             # wB97XD/def2SVP Opt Freq
频率 / 热力学量                wB97XD/def2SVP             # wB97XD/def2SVP Freq
红外光谱                     wB97XD/def2SVP             # wB97XD/def2SVP Freq
拉曼光谱                     wB97XD/def2SVP             # wB97XD/def2SVP Freq=Raman
高精度单点能                  wB97XD/def2TZVP            # wB97XD/def2TZVP
反应能 / 热化学                wB97XD/def2TZVP            # wB97XD/def2TZVP
过渡态定位                    M062X/6-311+G(d,p)         # M062X/6-311+G(d,p) Opt=(TS,CalcFC,MaxCyc=100) Int=UltraFine
反应能垒（双层级）             M062X/6-311+G(d,p)         # M062X/6-311+G(d,p) Int=UltraFine
弱相互作用 / 结合能            wB97XD/aug-cc-pVDZ         # wB97XD/aug-cc-pVDZ
构象搜索 / 大规模筛选          B3LYP/6-31G(d)             # B3LYP/6-31G(d) Opt EmpiricalDispersion=GD3BJ
激发态 / UV-Vis（TD-DFT）    wB97XD/6-311+G(d,p)        # wB97XD/6-311+G(d,p) TD=(NStates=10)
NMR 化学位移（GIAO）          B3LYP/6-311+G(d,p)         # B3LYP/6-311+G(d,p) NMR=GIAO
NMR 自旋-自旋耦合常数 J        B3LYP/6-311+G(d,p)         # B3LYP/6-311+G(d,p) NMR=(GIAO,SpinSpin)
EPR 超精细耦合 / g 张量        UB3LYP/EPR-III             # UB3LYP/EPR-III NMR
自旋态能量差 / 磁性耦合         TPSSh/def2TZVP             # TPSSh/def2TZVP
极化率 / 非线性光学             wB97XD/aug-cc-pVDZ         # wB97XD/aug-cc-pVDZ Polar
旋光 (ORD) / 手性光学          B3LYP/aug-cc-pVDZ          # B3LYP/aug-cc-pVDZ Polar=(OptRot)
非谐振频率 VPT2               B3LYP/6-311G(d,p)          # B3LYP/6-311G(d,p) Freq=(Anharmonic) EmpiricalDispersion=GD3BJ
```

同一张表在 **32 位 g09**（`arch="x86"`）下会被自动降配（`task_guide(arch="x86")`）：除 TS/能垒降到 `M062X/def2SVP` 外，其余一律退到 `wB97XD/def2SVP`（ NMR/EPR 也降为 def2SVP / UB3LYP/def2SVP），因为 30 原子级 + 三-zeta 会撑爆 32 位的 ~1.5GB 地址空间。

### 分子类型 → 推荐矩阵（`recommendation_matrix`）

```
# opt_freq / standard / x64             # uvvis / standard / x64
有机         wB97XD/def2SVP            有机         wB97XD/6-311+G(d,p)
过渡金属     TPSSh/def2SVP             过渡金属     wB97XD/def2TZVP
含重元素     B3LYP/def2SVP             含重元素     wB97XD/def2SVP
主族/超价    wB97XD/def2SVP            主族/超价    wB97XD/6-311+G(d,p)
团簇         wB97XD/def2SVP            团簇         wB97XD/6-311+G(d,p)
生物大分子   B3LYP/6-31G(d)            生物大分子   wB97XD/6-311+G(d,p)
```

### 自动施加的规则（无需记忆）

| 触发条件 | 自动处理 |
|----------|----------|
| 阴离子 / 缺电子、NLO / ORD / UV-Vis / 弱相互作用 | 基组升到含弥散版本（6-31G(d)→6-31+G(d,p)、def2SVP→aug-cc-pVDZ、def2TZVP→aug-cc-pVTZ） |
| **含金属 / 重元素** | **不**自动套 Pople / aug-cc 全电子基组（会丢 ECP 或无定义），保持 def2 家族并给出警告 |
| mult ≠ 1 | 方法加 `U` 前缀（UB3LYP / UwB97XD…） |
| 过渡金属 / 开壳层 | 追加 `SCF=XQC`（SCF 难收敛时的兜底） |
| M06-2X 等 meta 泛函 | 追加 `Int=UltraFine` |
| 泛函自带色散（ωB97X-D、APFD、B2PLYP）或 M06-2X | **不**再叠加 Grimme（避免双计数）；B3LYP / PBE0 / TPSSh 等自动加 `EmpiricalDispersion=GD3BJ` |
| `solvent="Water"` | 追加 `SCRF=(PCM,Solvent=Water)` |
| 方法推荐 PBE0 | 路由改写为同义关键字 **PBE1PBE**（本机 g09 不识别 PBE0） |
| 复合方法（CBS-QB3 / G4） | 不追加 Opt/Freq 关键字（它们自带优化与频率） |

### 资源预算与降配

体系按原子数分档（`size_tier`）：`tiny ≤10 / small ≤30 / medium ≤60 / large ≤120 / very_large ≤250 / huge >250`。
每档有「基组阶梯索引上限」，超出即降配并写进 `warnings`：

| 尺寸档 | 32 位 g09（x86）上限 | 64 位 g16（x64）上限 |
|--------|---------------------|---------------------|
| tiny | 6-311+G(d,p) | aug-cc-pVTZ |
| small | def2SVP | aug-cc-pVDZ |
| medium | 6-31G(d) | def2TZVP |
| large | **低于下限** → 提示半经验/ONIOM | def2SVP |
| very_large / huge | 同上 | 6-31G(d,p) / 6-31G(d) |

**下限保护**：DFT 不会被降到 6-31G(d) 以下（无极化/极小基组做 DFT 没有意义）。当某档连 6-31G(d) 都超预算时，推荐器保留原组合并给出强警告：「本环境不推荐直接上全量子化学层 → ①PM6 初筛 ②ONIOM 分层 ③换 64 位」。

### 真机关键字可用性（本机 g09 D.01 IA32，%mem=1000MB，实跑 23 项）

`python examples/validate_method_selector.py --real` 会用推荐矩阵里出现的方法/基组跑水分子（或 OH 自由基）单点，**23/23 符合预期**：

```
✅ EmpiricalDispersion=GD3BJ / wB97XD/def2SVP / M062X/6-311+G(d,p) Int=UltraFine / CAM-B3LYP+TD
✅ def2TZVP / aug-cc-pVDZ / aug-cc-pVTZ / 6-311++G(2d,p) / NMR=GIAO / NMR=(GIAO,SpinSpin)
✅ TPSSh/def2SVP / PBE1PBE/def2SVP / B2PLYP / APFD / PM6 / CBS-QB3 / G4 / MP2/aug-cc-pVDZ
✅ B3LYP/LANL2DZ、B3LYP/SDD（CH3Br 赝势） / UB3LYP/EPR-III NMR（OH 自由基）
⛔ PBE0/def2SVP（rc=2057，须写 PBE1PBE） / PM7（G16-only，rc=2057）
```

**实战要点**：
1. **`PBE0` 关键字在本机 g09 D.01 不被识别**（rc=2057）。推荐器已内置别名，凡推荐到 PBE0 一律输出 `PBE1PBE`（实测 rc=0）。
2. **`APFD` 在本机反而可用**（先前以为 G16-only，实测 rc=0）；真正 G16-only 的是 **`PM7`**（rc=2057）。半经验用 `PM6`。
3. **32 位环境下别指望 aug-cc-pVTZ / CBS-QB3 跑真实体系**：上面的关键字都被接受（因为探针是水 / OH 自由基这类极小分子），但真实任务会因 `%mem` 直接崩溃——推荐器的「按尺寸降配」正是为此存在。
4. 复合方法（`CBS-QB3` / `G4`）**不要**和 `Opt Freq` 一起写；推荐器在识别到 composite 方法时会自动省掉任务关键字。

### 与 recipes / gjf_writer 联动

推荐出的 `mb` 就是 `case_route()` 要的参数，天然复用既有配方：

```python
from gaussian_automation import recommend_method, case_route, write_gjf, run_and_save

r = recommend_method(atoms=["C"]*6 + ["H"]*6, task="nmr", quality="standard", solvent="Chloroform")
print(case_route("nmr", mb=r["mb"]))       # # B3LYP/6-311+G(d,p) NMR=GIAO（溶剂等附加关键字在 r["route"] 里）

write_gjf("benzene.gjf", atoms, coords, charge=0, mult=1,
          route=r["route"], mem=r["mem"], nproc=8, chk="benzene")
res = run_and_save("benzene.gjf", out_dir="results", nprocs="70%")
```

相关文件：`references/gaussian_automation/method_selector.py`（引擎本体）、`examples/method_selector_demo.py`（演示，无需 Gaussian）、`examples/validate_method_selector.py`（18 项逻辑断言 + 23 项真机关键字验证）。

## 第二批 12 个综合实战案例（v1.3.0 扩展，nprocs=12）

搜索并补齐 Gaussian 此前未覆盖的 12 项计算能力，全部在本机（Gaussian 09 Rev D.01 32 位，`D:\Gaussian09\G09W\g09.exe`，`%mem=1000MB`、`nprocs=12`）真实跑通。一键编排脚本 `examples/cases2.py`（输出写到工作项目目录 `gaussian_cases/cases2/`，与 skill 目录分离以保持纯净），报告见 `cases2_report.txt`。**下表路由均来自 `recipes.CASE_CATALOG`（单一信息源）。**

| # | 计算能力 | 路线（route） | 体系 | 关键结果（已解析） |
|---|----------|---------------|------|--------------------|
| 1 | IRC 内禀反应坐标 | `# B3LYP/6-31G(d) IRC=CalcFC` | 乙烷 C-C 扭转 TS | SCF=-79.8275 Ha；沿反应坐标双向展开（日志 `Point Number` 递增） |
| 2 | NMR=GIAO 核磁屏蔽 | `# B3LYP/6-31G(d) NMR=GIAO` | 甲醇 | `nmr_shieldings`: C=161.18, O=309.47, H≈26–31 ppm |
| 3 | PES 扫描 | `# B3LYP/6-31G(d) Opt=ModRedundant NoSymm` | 水 O–H 伸缩 | `scan_results` 5 步，能量跨度 0.140 Ha（0.958→1.758 Å） |
| 4 | MP2 后 HF 相关能 | `# MP2/6-31G(d)` | 水 | `mp2_correlation` E2=-0.1885 Ha；`mp2_total` EUMP2=-76.1700 Ha |
| 5 | NBO 自然键轨道 | `# B3LYP/6-31G(d) Pop=NBO` | 氨 | `nbo_charges`: N=-1.110, H=+0.370（电负性符号正确） |
| 6 | PCM 隐式溶剂化 | `# B3LYP/6-31G(d) SCRF=(PCM,Solvent=Water)` | 甲醇 | 溶剂相 SCF=-115.5222 Ha；ΔG_solv 需 `solvation_free_energy(pcm,gas)` 相减（g09 D.01 不单独给） |
| 7 | Freq=Raman | `# B3LYP/6-31G(d) Freq=Raman` | 甲醛 | `raman_activities` 6 模式（最大 146.90 A⁴/amu）；各向同性极化率 12.85 Bohr³ |
| 8 | Counterpoise BSSE | `# B3LYP/6-31G(d) Counterpoise=2` | 水二聚体 | `bsse_corrected_energy`=-152.7750 Ha；`complexation_energy_corrected`=-5.21 kcal/mol |
| 9 | Polar 静态极化率 | `# B3LYP/6-31G(d) Polar` | CO₂ | 极化率张量 [7.64,0,7.64,0,0,21.71]；各向同性 12.33 Bohr³ |
| 10 | CIS 激发态 | `# B3LYP/6-31G(d) CIS=(NStates=6)` | 甲醛 | `excited_states`: S1=4.06 eV (n→π*, f≈0), S3=9.17 eV (f=0.16) |
| 11 | Stable=Opt 波函数稳定 | `# B3LYP/6-31G(d) Stable=Opt` | 甲醛 | `stability`="stable"（RHF 波函数稳定） |
| 12 | TD Opt 激发态优化 | `# B3LYP/6-31G(d) TD=(NStates=3) Opt` | 甲醛 | 在 S1 态优化几何；S1=4.04 eV（较单点略降） |

### 关键经验 / 实战坑（第二批 12 案例）

**1. PES 扫描：ModRedundant 的扫描代码 `S` 必须写在原子编号之后，且必须 `NoSymm`**
- 扫描步写在 footer（`gjf_writer` 的 `footer=` 参数）：`1 2 S 6 0.20` 表示对原子 1–2 的键长做 6 步、每步 +0.20 Å 的柔性扫描。`S` 这个扫描代码位于原子编号**之后**，不是 `B 1 2 S ...`（用元素符号 `B` 当原子号是错的，且 `S` 的位置也不对）。
- **务必加 `NoSymm`**：否则 g09 会对称化初始坐标，柔性扫描在对称约束下无法展开（l108 "No variables in Z-matrix"）。本例水的扫描靠 `Opt=ModRedundant NoSymm` 才跑通。
- 解析读 `scan_results=[(step, 坐标值, 能量), ...]`（来自 `Summary of ... Potential Surface Scan` 表）。

**2. Counterpoise BSSE：Cartesian 坐标用「片段编号」而非 `--` 分隔符**
- BSSE 需标识每个原子属于哪个片段。**Cartesian 体系**的正确写法是在每个原子坐标行**末尾加片段编号**（1 或 2），例如 `O 0.000 0.000 0.000 1`、`H 3.657 0.587 0.000 2`；**不要用 `--` 分隔符**——`--` 是 Z-matrix 输入才用的，Cartesian 下会触发 l101 "Center specification must be either integer or string"。
- 解析读 `bsse_corrected_energy`（E_cp）与 `complexation_energy_corrected`（ΔE_comp，kcal/mol）。

**3. ECD 旋光强度需 `CPolar`，但 g09 D.01 不含 → 以 CIS 替代**
- 真正做 ECD 需要 `TD=(NStates=N) CPolar` 让 g09 输出旋光强度（rotatory strength）。但**本机 g09 D.01 的 `CPolar` 关键字不存在**——测过 8 种变体均报 rc=2057 语法错误（`QPErr`）。要跑 ECD 需 G16 或带 CPolar 的版本。
- 作为替代，本批用 **`CIS=(NStates=6)`**（组态相互作用单激发）演示激发态：输出格式与 TDDFT 一致，解析复用 `excited_states` 字段。CIS 与 TDDFT 方法学不同（CIS 无 DFT 交换相关），但都给出激发能级/波长/振子强度，足以覆盖「激发态计算」这一能力。
- 若用 G16 想做 ECD：路线改为 `# TD=(NStates=8) CPolar`，解析器已预留 `ecd_transitions` 字段（g09 下为 None）。

**4. runner 写 `_run.gjf` 必须用 LF 行尾（Windows 致命坑）**
- g09 的 `--` 片段分隔符 / Z-matrix 变量对对 **CRLF 极其敏感**：Windows 默认 text 模式会把 `\n` 写成 `\r\n`，导致解析失败（l101/l108）。
- `runner._prepare_run_gjf` 现已用 `open(..., newline="\n")` 强制 LF 写入运行副本，彻底规避。所有案例脚本无需再手工处理行尾。

**5. nprocs 指令已正确注入，但本机构建的实际多核并行无效（重要）**
- 用户要求取消 `resolve_nprocs` 对 32 位的 4 核封顶后确认：本 skill 会正确把 `%nprocshared=12` 注入运行副本，Gaussian 也回显 `Will use up to 12 processors`，作业全程 `Normal termination`——**指令传递层面没问题**。
- **但实测本机 32 位 g09 D.01 的 SMP 并行无效**：同一任务 `nprocs=1` 墙钟 10.7s、`nprocs=12` 墙钟 8.5s（仅 1.26× 加速），且 `Job CPU time`≈墙钟时间，说明实际只跑了约 1 核。即 **nprocs 设多大对墙钟几乎没影响**，不要指望靠它提速；真要多核需换带有效 SMP/Linda 并行的 Gaussian 版本（如 g16 或正确编译的 g09 SMP 版）。
- **32 位的真正杀手仍是内存**（`mem=400MW`≈3.2GB 会撑爆地址空间），与核数无关。本批统一 `mem=1000MB` 是为了内存安全，与是否多核无关。

**6. PCM 溶剂化自由能：本机构建默认不打印，需「溶液 SCF − 气相 SCF」相减**
- 本机 32 位 g09 D.01 的默认 PCM 运行**不会**单独输出 `Free energy of solvation = ...` 这一行（溶剂化能量已含在 SCF 里）。解析器因此只标记 `pcm_active=True`，而 `pcm_solvation_free_energy=None`。
- 正确做法：用**同一分子、同一方法/基组**再跑一次气相计算（去掉 `SCRF`），然后用
  `log_parser.solvation_free_energy(pcm_log, gas_log)` 相减得到 ΔG_solv（Hartree，负值放能）。
- 较新版本（如 g16）会在 PCM 输出里直接打印该行，届时 `pcm_solvation_free_energy` 会自动提取，无需相减。

## 第三批 15 个综合实战案例（v1.5.0 扩展，nprocs='70%'）

围绕用户指定的 14 个高阶主题，先与既有配方比对：**4 个已被覆盖而跳过**（激发态能量与结构优化 → `tdopt`/`tddft`；红外 IR → `freq`；拉曼 Raman → `raman`；UV/Vis 的 TD-DFT/CIS → `tddft`/`cis`），另补 1 个 `vibronic`（振动电子吸收/发射，与 Franck-Condon 同底层），**共新增 15 个配方**（配方总数达 32）。全部在本机（Gaussian 09 Rev D.01 32 位，`D:\Gaussian09\G09W\g09.exe`，`%mem=1000MB`、`nprocs='70%'`，70%×16 逻辑核≈11 核）真实跑通验证。**11 项在本机跑通**，4 项（FCHT/FC、EOM、CPolar 模块本机构建缺失）标记 G16-only 但保留 G16 正确路由。一键编排脚本 `examples/cases3.py`（先 `cases3.py`、修正批 `cases3b.py`/`cases3c2.py`，输出写到 `gaussian_cases/cases3/`，与 skill 目录分离），回归测试 `examples/validate_cases3.py`。

| # | 计算能力（配方名） | 路线（route） | 体系 | 本机 g09 D.01 | 关键结果（已解析） |
|---|--------------------|---------------|------|---------------|--------------------|
| 1 | 激发态势能面（excited_pes） | `# {mb} TD=(NStates=3)`（冻结几何单点扫描） | 甲醛 C=O 1.0→1.5 Å | ✅ PASSED | S1 能级 5.51→2.38 eV（键越长 S1 越低，激发态势能曲线） |
| 2 | 荧光/磷光（fluorescence） | `# {mb} TD=(NStates=3) Opt` + S1 几何 TD 单点 | 甲醛 S0/S1/T1 | ✅ PASSED | 荧光垂直发射 S1→S0 ≈3.38 eV；磷光 T1→S0 由各自优化 SCF 相减 |
| 3 | 态特异性溶剂化（excited_solvation） | `# {mb} SCRF=(PCM,Solvent=Water) TD=(NStates=5)` | 甲醛 | ✅ PASSED | 气相 S1=1.95 eV → PCM(水) S1=2.23 eV（蓝移 ~0.28 eV，pcm_active=True） |
| 4 | 非谐振频率（anharmonic） | `# {mb} Freq=(Anharmonic)`（Plain，VPT2 子选项移除） | H₂O | ✅ PASSED | `anharmonic_frequencies`: ν1 3987.6→3804.0、ν2 3858.2→3693.6、ν3 1681.4→1629.0 cm⁻¹ |
| 5 | 预共振拉曼（preresonance_raman） | `# {mb} Freq=Raman CPHF=RdFreq` + 页脚频率 | 甲醛 | ✅ PASSED | `raman_activities` 共振增强后成功提取 |
| 6 | NMR 耦合常数（nmr_jcoupling） | `# {mb} NMR=(GIAO,SpinSpin)` | 甲醇 | ✅ PASSED | `j_couplings`: C–O≈779、C–H≈100、O–H≈170 Hz（下三角）；`nmr_shieldings` 见 GIAO |
| 7 | 振动圆二色性（vcd） | `# {mb} Freq=(VCD)`（真实极小点） | gauche H₂O₂ | ✅ PASSED | `vcd_intensities` 6 模式非零（最大 \|Rot.str.\|≈203），n_imag=0 |
| 8 | 旋光 ORD（optrot） | `# {mb} Polar=(OptRot)` | H₂O₂ | ✅ PASSED | `optical_rotation`=-0.0165 au（静态旋光 Beta） |
| 9 | 拉曼光学活性（roa） | `# {mb} Freq=(ROA) CPHF=RdFreq` + 页脚频率 | H₂O₂ | ✅ PASSED | `roa_intensities` 全模式（极小体系≈0，工作流已验证） |
| 10 | 振动-转动耦合（vibrot） | `# {mb} Freq=(VibRot)` | H₂O₂ | ✅ PASSED | `vibrot_alpha` 3×3 矩阵（cm⁻¹）提取成功 |
| 11 | 超精细/g 张量（hyperfine） | `# {mb} NMR`（开壳层 UB3LYP mult=2） | OH 自由基 | ✅ PASSED | `hyperfine_couplings`: O≈-51.7、H≈-67.2 MHz；`g_tensor`=[2.0077,2.0021,2.0712] |
| 12 | Franck-Condon（franck_condon） | `# {mb} TD=(NStates=5) Freq=(ReadFC,FCHT) Geom=AllCheck` | 甲醛 | ⛔ G16-only | 本机构建无 FCHT/FC 模块 → rc=2057；G16 可用，输出振动电子吸收谱 |
| 13 | 振动电子谱（vibronic） | `# {mb} TD=(NStates=5) Freq=(ReadFC,FCHT) Geom=AllCheck` | 甲醛 | ⛔ G16-only | 同 franck_condon，吸收+发射 vibronic 谱；FCHT 模块本机缺失 |
| 14 | EOM-CCSD（eom_ccsd） | `# CCSD/6-31G EOM=(EE,NStates=5)` | H₂O | ⛔ G16-only | 本机构建无 EOM 模块 → rc=2057；G16 可用作 TD-DFT 基准 |
| 15 | ECD（ecd） | `# {mb} TD=(NStates=8) CPolar` | H₂O₂ | ⛔ G16-only | 本机构建无 CPolar 关键字 → rc=2057；G16 可用，`ecd_transitions` 生效 |

> 表中 `mb` 默认 `B3LYP/6-31G(d)`（VCD/ROA/超精细用 `UB3LYP` 开壳层）。本机跑通的 11 项其 `.log` 均存于 `gaussian_cases/cases3/`，`validate_cases3.py` 断言其 8 个新字段非 None，**无需 Gaussian 即可回归**。

### 关键经验 / 实战坑（第三批 15 案例）

**1. 激发态势能面：避开 TD Opt 松弛扫描，用「冻结几何 + TD 单点扫描」**
- 本机构建下 `TD=(NStates=3) Opt=ModRedundant` 的松弛势能面扫描极易 link 9999 不收敛（首次尝试 `excited_pes.log` 即 Error termination）。
- **稳妥做法**：手动画一条内坐标（如甲醛 C=O 键长 1.0→1.5 Å，6 个几何），对每个几何跑本机普通的 `# {mb} TD=(NStates=3)` 单点（不优化），收集 `excited_states` 的 S1 能级即得激发态势能曲线。本例 S1 随 C=O 伸长由 5.51 降至 2.38 eV，趋势合理。

**2. 非谐振频率：VPT2 子选项在本机构建报错，用 Plain `Freq=(Anharmonic)`**
- `Freq=(Anharmonic,VPT2)` 在本机 g09 D.01 报 rc=2057（VPT2 子选项不被识别）。去掉子选项、改用 `# {mb} Freq=(Anharmonic)` 即通过，输出 `Fundamental Bands` 表（Harmonic/Anharmonic 两列）。G16 可再上 VPT2/DCPT2/HDCPT2 等高阶方案。

**3. VCD 必须在真实极小点（n_imag=0）上算**
- 直接在手性构象（如 H₂O₂ gauche）的输入几何上跑 `Freq=(VCD)`，若构象接近扭转鞍点会带虚频、信号失真。本例输入几何即出现 1 个虚频（n_imag=1）。
- **做法**：先用 `Opt=ModRedundant NoSymm` + 页脚冻结关键二面角（如 `3 1 2 4 F`）锁定手性极小点（`vcd_opt.log` n_imag=0），再在其几何（从 `.log` 取最后 "Input orientation" 显式坐标）上跑 `Freq=(VCD)`，得到 6 个非零旋转强度。
- ⚠️ 注意：`Freq=(VCD) Geom=AllCheck` 在本机构建会 `QPErr`（"ambiguous keyword"）——VCD 作业需显式坐标，不要用 Geom=AllCheck 读 chk。

**4. ROA 必须 `CPHF=RdFreq` + 页脚激光频率，否则中止**
- `Freq=(ROA)` 单独跑会报 `CPHF=RdFreq but no frequencies in input` 而中止。必须路由带 `CPHF=RdFreq` 并在页脚（footer）提供近共振激光频率（cm⁻¹），如 `18797.0`（≈532 nm）。
- 极小体系（如 H₂O₂）的 ROA 强度在所有散射几何下≈0，属正常物理（信号被对称性抵消），**工作流本身已验证通过**——别误判为计算失败。

**5. EPR 超精细与 g 张量：用开壳层 NMR，不用 `Hyperfine=` 关键字**
- 本机 g09 D.01 **无 `Hyperfine=` 关键字**（报 rc=2057）。可用路线是开壳层 NMR 作业：`mb` 传 `UB3LYP/6-31G(d)`、电荷/多重度设自由基（如 OH 自由基 charge=0 mult=2），路线 `# UB3LYP/6-31G(d) NMR`。
- 开壳层 NMR 自动输出 `Isotropic Fermi Contact Couplings`（超精细 A_iso, MHz）与 `g tensor` 主值，解析器分别落入 `hyperfine_couplings` / `g_tensor`。G16 用户可再追加 `Hyperfine=(FC,SD)` 取更全的各向异性超精细张量。

**6. 四项的 G16-only 限制（本机构建缺模块，已诚实标记 `g09_d01_ok=False`）**
- `franck_condon` / `vibronic`：依赖 FCHT/FC 模块，`Freq=(ReadFC,FCHT)` 与 `Freq=(ReadFC,FC)` 均 rc=2057。
- `eom_ccsd`：依赖 EOM 模块，`EOM=EE` / `EOM=(EE,NStates=5)` 均 rc=2057。
- `ecd`：依赖 `CPolar` 关键字，rc=2057。
- 这四项在 G16（或带对应模块的版本）上路由写法正确、可直接跑；解析器字段 `ecd_transitions` 已预留（G16 CPolar 下生效，g09 下为 None）。

**7. nprocs 提升至 70% 的实测结论（用户要求）**
- 用户要求把 CPU 利用率提到 70%：脚本统一用 `nprocs='70%'`（16 逻辑核 → 实际注入 `%nprocshared=11`），Gaussian 回显 `Will use up to 11 processors`、全程 Normal termination——**指令注入正常**。
- 但重申坑 1 补注：本机 32 位 g09 D.01 的 SMP 并行实测无效（nprocs=1 与 70% 墙钟时间几乎相同），`Job CPU time`≈墙钟，实际只用约 1 核。即 **70% 只保证指令到位，不等于真用 11 核**；内存仍是 32 位唯一硬约束（`%mem=1000MB`）。

## 目录结构（本技能自带）

```
gaussian-automation/
├── SKILL.md
├── references/
│   ├── gaussian_automation/      # 可直接 import 的 gaussian_automation 包（v1.3.0）
│   │   ├── __init__.py
│   │   ├── gjf_writer.py
│   │   ├── runner.py
│   │   ├── log_parser.py
│   │   ├── detect.py
│   │   ├── cpu.py                # CPU 逻辑核数探测 + %nprocs 解析与注入（v1.3.0）
│   │   ├── recipes.py           # 计算类型配方目录 CASE_CATALOG（v1.5.0，32 个配方）
│   │   ├── method_selector.py   # 计算方法/基组推荐引擎（v1.6.0 新增）
│   │   └── utils.py
│   └── gaussian_automation/README.md  # 工具包完整说明文档
└── examples/
    ├── demo.py                  # 完整流程示例（无 Gaussian 也可体验解析）
    ├── cpu_nprocs_demo.py       # CPU 核数自动解析示例（v1.3.0）
    ├── method_selector_demo.py  # 方法/基组推荐演示（v1.6.0，纯逻辑无需 Gaussian）
    ├── validate_method_selector.py # 推荐逻辑回归 18 项 + 真机关键字验证 23 项（v1.6.0）
    ├── cases.py                 # 5 个综合案例一键编排（运行时自生成 .gjf，已用 nprocs='75%' 跑通）
    ├── make_report.py           # 案例结果汇总（读取 results/*.log 生成）
    ├── cases_report.txt         # 5 案例预期结果汇总（运行时由脚本生成）
    ├── cases2.py                # 第二批 12 案例一键编排（nprocs=12，路由取自 recipes，输出到 gaussian_cases/cases2/）
    ├── validate_cases2.py       # 解析器回归验证：对 12 个真实 .log 断言关键字段（无需 Gaussian）
    ├── cases3.py                # 第三批 15 案例一键编排（nprocs='70%'，路由取自 recipes，输出到 gaussian_cases/cases3/）
    ├── validate_cases3.py       # 第三批解析器回归验证：对 11 个本机真实 .log 断言 8 新字段非 None（无需 Gaussian）
    └── sample_water.log         # 示例输出，供 demo.py 解析测试
```
