"""
Gaussian 计算类型配方（recipes）
================================

把本 skill 已验证的常见 Gaussian 任务类型整理成「配方目录」，让调用方不必
记忆繁琐的路由关键字与坑点。每个配方给出：

  - route   : Gaussian 路由行模板；含 ``{mb}`` 占位符的会由 ``case_route()``
              按方法/基组（默认 B3LYP/6-31G(d)）填入；不含占位符的（如 MP2）
              写法固定，直接用。
  - purpose : 这个任务算什么
  - g09_d01_ok : 在本机 32 位 Gaussian 09 Rev D.01 下是否实测可用
  - notes   : 关键坑 / 注意事项（来自 12 案例实战复盘）
  - parser_fields : 该任务主要由 ``log_parser.parse_log`` 的哪些字段承载结果
  - special : 普通 ``write_gjf(route=...)`` 不够、需要额外步骤的配方标记
              （如 IRC 需先 TS 优化、BSSE 需 Cartesian 片段编号、SCAN 需 ModRedundant 页脚）

配合 ``gjf_writer.write_gjf`` 与 ``runner.run_and_save`` 即可一键发起计算；
配合 ``log_parser.parse_log`` 解析结果。所有配方均在本机 32 位 g09 D.01
（%mem=1000MB、nprocs 指令）下真实跑通过。截至 v1.7.0 共 **42 个配方**
（基础 5 + 第二批 12 + 第三批 15 + 第四批 10 复杂案例）。

注意：本机 32 位 g09 D.01 的 SMP 并行实测无效（仅约 1 有效核），nprocs 仅为
指令传递值，不代表真实多核加速；真多核需换带有效 SMP/Linda 的 Gaussian（如 g16）。
"""

from __future__ import annotations

from typing import Dict, List

# ---------------------------------------------------------------------------
# 配方目录
# ---------------------------------------------------------------------------
CASE_CATALOG: Dict[str, Dict[str, object]] = {
    # ---------- 基础 5 类（v1.1.0 验证基准） ----------
    "opt": {
        "title": "几何优化",
        "route": "# {mb} Opt",
        "purpose": "把分子几何弛豫到势能面极小点。",
        "g09_d01_ok": True,
        "notes": "优化后读 optimized_geometry / converged；建议紧跟 Freq 验证极小点（应 0 虚频）。"
                 "构造初始几何时切勿让含 H 轻原子与重原子共线，否则优化器可能停在鞍点却'看似收敛'。",
        "parser_fields": ["scf_energy", "converged", "optimized_geometry", "frequencies", "n_imaginary"],
        "special": None,
    },
    "freq": {
        "title": "频率 / 热力学量",
        "route": "# {mb} Freq",
        "purpose": "振动频率、IR 强度、零点能与热力学修正（ZPE / G(298K) 等）。",
        "g09_d01_ok": True,
        "notes": "频率分析同时给出热力学量（需先有稳定几何）。n_imaginary=0 为极小点，=1 且收敛为过渡态。",
        "parser_fields": ["frequencies", "intensities", "n_imaginary",
                          "zero_point", "thermal_free_energy", "sum_free_energy"],
        "special": None,
    },
    "ts": {
        "title": "过渡态优化",
        "route": "# {mb} Opt=(TS,CalcFC,MaxCyc=100)",
        "purpose": "定位鞍点（过渡态）。",
        "g09_d01_ok": True,
        "notes": "TS 优化后再接 Freq 确认恰有 1 个虚频。初始结构应已接近 TS（如扭转构象）。",
        "parser_fields": ["scf_energy", "converged", "n_imaginary", "optimized_geometry"],
        "special": None,
    },
    "tddft": {
        "title": "激发态 (TD-DFT)",
        "route": "# {mb} TD=(NStates=3) Opt",
        "purpose": "垂直激发能、振子强度、激发态几何优化。",
        "g09_d01_ok": True,
        "notes": "excited_states 同时承载 TDDFT / CIS 结果。n→π* 弱跃迁振子强度极小（f≈0）属正常。"
                 "基态优化用 Opt，纯垂直激发可去掉 Opt。",
        "parser_fields": ["excited_states", "scf_energy", "converged"],
        "special": None,
    },
    "esp": {
        "title": "ESP 拟合电荷 (Merz-Kollman)",
        "route": "# {mb} Pop=MK",
        "purpose": "在单点密度上做 MK 电荷拟合（RESPI/RESP 类力场常用）。",
        "g09_d01_ok": True,
        "notes": "通常为单点（无 Opt）。Pop=MK 比默认 Mulliken 更稳定；读 esp_charges。",
        "parser_fields": ["scf_energy", "esp_charges", "mulliken_charges"],
        "special": None,
    },

    # ---------- 第二批 12 案例（v1.3.0 扩展） ----------
    "irc": {
        "title": "内禀反应坐标 (IRC)",
        "route": "# {mb} IRC=CalcFC",
        "purpose": "从过渡态沿反应坐标展开到反应物/产物，验证 TS 确实连接两者。",
        "g09_d01_ok": True,
        "notes": "需先 Opt=(TS) 得到过渡态几何，再用其几何跑 IRC=CalcFC。IRC 本身也会输出极化率但常为零点回退到 Approx。",
        "parser_fields": ["scf_energy", "polarizability", "converged"],
        "special": "ts_then_irc",
    },
    "nmr": {
        "title": "NMR 屏蔽常数 (GIAO)",
        "route": "# {mb} NMR=GIAO",
        "purpose": "核磁各向同性屏蔽常数（化学位移的参考量）。",
        "g09_d01_ok": True,
        "notes": "GIAO 为默认 NMR 方法。读 nmr_shieldings [(symbol, ppm), ...]，负号越大屏蔽越强。",
        "parser_fields": ["scf_energy", "nmr_shieldings"],
        "special": None,
    },
    "scan": {
        "title": "PES 势能面扫描 (柔性)",
        "route": "# {mb} Opt=ModRedundant NoSymm",
        "purpose": "沿某内坐标（键长/角/二面角）逐步弛豫，得到扫描曲线。",
        "g09_d01_ok": True,
        "notes": "必须用 Opt=ModRedundant 并在 gjf 页脚写扫描指令；扫描代码 S 写在原子号之后，"
                 "如 '1 2 S 6 0.20'（原子1-2、6 步、步长 0.20 Å）。务必加 NoSymm，否则对称约束会让扫描退化。",
        "parser_fields": ["scan_results", "converged"],
        "special": "modredundant_footer",
    },
    "mp2": {
        "title": "MP2 后 HF 相关能单点",
        "route": "# MP2/6-31G(d)",
        "purpose": "在 HF 之上加入二阶 Møller-Plesset 相关修正，能量更准（相对 DFT）。",
        "g09_d01_ok": True,
        "notes": "MP2 固定方法，mb 占位符无效。读 mp2_correlation(E2) 与 mp2_total(EUMP2)；"
                 "输出里每个自旋分量行也有 'E2='（无空格），解析时用 'E2 ='（带空格）只取总量，避免误取分量。",
        "parser_fields": ["scf_energy", "scf_method", "mp2_correlation", "mp2_total"],
        "special": None,
    },
    "nbo": {
        "title": "自然键轨道分析 (NBO)",
        "route": "# {mb} Pop=NBO",
        "purpose": "自然键轨道、自然电荷、键级等化学直观描述。",
        "g09_d01_ok": True,
        "notes": "读 nbo_charges（Natural Population Analysis 表）。Pop=NBO 会额外产出 .nbo/.47 等文件。",
        "parser_fields": ["scf_energy", "nbo_charges"],
        "special": None,
    },
    "pcm": {
        "title": "隐式溶剂化 (PCM)",
        "route": "# {mb} SCRF=(PCM,Solvent=Water)",
        "purpose": "在极化连续介质模型下算溶剂化效应。",
        "g09_d01_ok": True,
        "notes": "本构建的默认 PCM 输出【不】打印 'Free energy of solvation'，溶剂化自由能须由"
                 "「溶液 SCF − 气相 SCF」相减得到（见 log_parser.solvation_free_energy）；"
                 "parse_log 会标记 pcm_active=True，但不含 pcm_solvation_free_energy。",
        "parser_fields": ["scf_energy", "pcm_active"],
        "special": None,
    },
    "raman": {
        "title": "Raman 散射活性",
        "route": "# {mb} Freq=Raman",
        "purpose": "频率 + Raman 活性、去偏振比。",
        "g09_d01_ok": True,
        "notes": "Freq=Raman 同时含 IR 与 Raman。读 raman_activities 与 frequencies。",
        "parser_fields": ["frequencies", "raman_activities", "polarizability", "isotropic_polarizability"],
        "special": None,
    },
    "bsse": {
        "title": "BSSE 基组叠加误差 (Counterpoise)",
        "route": "# {mb} Counterpoise=2",
        "purpose": "用 Counterpoise 方法校正复合物结合能的基组叠加误差。",
        "g09_d01_ok": True,
        "notes": "必须手写 gjf：Cartesian 坐标每个原子行末加片段编号(1/2)，不能用 '--' 分隔符；"
                 "Link0 里 %nprocshared 也要写对。读 bsse_corrected_energy 与 complexation_energy_corrected。",
        "parser_fields": ["scf_energy", "bsse_corrected_energy", "complexation_energy_corrected"],
        "special": "counterpoise_cartesian",
    },
    "polar": {
        "title": "静态极化率",
        "route": "# {mb} Polar",
        "purpose": "耦合微扰计算静态极化率张量与各向同性极化率。",
        "g09_d01_ok": True,
        "notes": "读 polarizability（6 个张量分量）与 isotropic_polarizability (Bohr^3)。"
                 "Exact 全零时解析器自动回退到 Approx。",
        "parser_fields": ["polarizability", "isotropic_polarizability"],
        "special": None,
    },
    "cis": {
        "title": "CIS 激发态 (组态相互作用单激发)",
        "route": "# {mb} CIS=(NStates=6)",
        "purpose": "以 CIS 算激发态；本机构建下替代不可用的 ECD/CPolar。",
        "g09_d01_ok": True,
        "notes": "CPolar/ECD 在 g09 D.01 不存在（报错 rc=2057），故用 CIS 作激发态演示。"
                 "读 cis_energy (E(CIS)) 与 excited_states。真正的圆二色旋光强度需 g16+CPolar。",
        "parser_fields": ["cis_energy", "excited_states", "scf_energy"],
        "special": None,
    },
    "stable": {
        "title": "波函数稳定性检验",
        "route": "# {mb} Stable=Opt",
        "purpose": "检查当前波函数是否稳定（有无更低能的对称破缺解）。",
        "g09_d01_ok": True,
        "notes": "Stable=Opt 会自动弛豫到更稳定波函数并报告 stable/unstable。",
        "parser_fields": ["scf_energy", "stability"],
        "special": None,
    },
    "tdopt": {
        "title": "激发态几何优化 (TD Opt)",
        "route": "# {mb} TD=(NStates=3) Opt",
        "purpose": "在最低激发态势能面上做几何优化（如 S1）。",
        "g09_d01_ok": True,
        "notes": "TD=(NStates=3) Opt 会产出大量激发态；读 excited_states 与 converged。",
        "parser_fields": ["excited_states", "scf_energy", "converged"],
        "special": None,
    },

    # ---------- 第三批 15 案例（v1.5.0 扩展：高阶光谱 / 激发态 / 手性 / EPR） ----------
    "excited_pes": {
        "title": "激发态势能面与光化学反应路径",
        "route": "# {mb} TD=(NStates=3)",
        "purpose": "沿某内坐标逐步改变几何（冻结其余自由度），在每个点上做 TD 单点，读取 S1 能级，得到激发态势能面 / 光反应路径示意。",
        "g09_d01_ok": True,
        "notes": "本机构建下 TD Opt + ModRedundant 松弛扫描易不收敛；改用“冻结几何 + TD 单点”扫描更稳："
                 "用 write_gjf 生成 N 个沿坐标变化的几何，逐个跑本路由，收集 excited_states 的 S1 能级（eV）即得激发态势能曲线。"
                 "（本 skill 的 cases3.py 即以此法演示 C=O 伸缩：S1 随键长 1.0→1.5 Å 由 5.5 降到 2.4 eV）。",
        "parser_fields": ["excited_states", "scf_energy"],
        "special": "frozen_scan",
    },
    "fluorescence": {
        "title": "荧光与磷光发射光谱",
        "route": "# {mb} TD=(NStates=3) Opt",
        "purpose": "荧光（S1→S0 发射）：先 TD Opt 得 S1 几何/能量，再在其几何上做 TD 单点得垂直发射能；"
                   "磷光（T1→S0 发射）：以三重态（mult=3, UB3LYP）Opt 得 T1 几何/能量，0-0 磷光 ≈ E(T1)−E(S0)。",
        "g09_d01_ok": True,
        "notes": "荧光垂直发射：取 S1 优化几何做 TD 单点，excited_states 的 S1 eV 即为 S1→S0 垂直发射能。"
                 "0-0 发射/磷光 energy 用各态优化结构 SCF 能量相减：ΔE_fluor≈E(S1,min)−E(S0,min)，ΔE_phos≈E(T1,min)−E(S0,min)。",
        "parser_fields": ["excited_states", "scf_energy", "converged"],
        "special": "emission_workflow",
    },
    "franck_condon": {
        "title": "Franck-Condon 分析（FCHT 吸收）",
        "route": "# {mb} TD=(NStates=5) Freq=(ReadFC,FCHT) Geom=AllCheck",
        "purpose": "基于 S0 几何+频率（存于 chk）与 TD 激发态做 Franck-Condon / Herzberg-Teller 振动电子分析，得吸收边 vibronic 谱。",
        "g09_d01_ok": False,
        "notes": "⚠️ 本机 32 位 g09 D.01 **不含 FCHT / FC 模块**：`Freq=(ReadFC,FCHT)` 与 `Freq=(ReadFC,FC)` 均报 rc=2057（QPErr 'Ambiguous/unknown keyword'）。"
                 "此配方仅在 G16（或带 FC/FCHT 模块的版本）可用。两步法：①先跑 '# {mb} Opt Freq' 并把 chk 写进同目录；②本作业读该 chk（Geom=AllCheck 自动取 S0 几何/频率）。"
                 "本作业 gjf 只需 %chk=xxx + 路由 + 标题，坐标段留空（由 chk 提供）。输出含 'Final Spectrum' 振动电子吸收谱。",
        "parser_fields": ["excited_states", "scf_energy"],
        "special": "fcht_readchk",
    },
    "vibronic": {
        "title": "振动电子（vibronic）吸收/发射光谱",
        "route": "# {mb} TD=(NStates=5) Freq=(ReadFC,FCHT) Geom=AllCheck",
        "purpose": "与 Franck-Condon 同一底层（FCHT），同时给出 vibronic 吸收谱与发射谱（含 Herzberg-Teller 项）。",
        "g09_d01_ok": False,
        "notes": "⚠️ 同 franck_condon：本机 32 位 g09 D.01 **不含 FCHT / FC 模块**，此配方仅 G16（或带 FC/FCHT 版本）可用。"
                 "FCHT 同时产出吸收与发射 vibronic 谱。用 franck_condon 的同一 chk 与同一作业即可；"
                 "Geom=AllCheck 读取 S0；TD 提供激发态；Freq=(FCHT) 计算 Duschinsky/FC 因子。",
        "parser_fields": ["excited_states", "scf_energy"],
        "special": "fcht_readchk",
    },
    "excited_solvation": {
        "title": "态特异性溶剂化激发态（PCM+TD）",
        "route": "# {mb} SCRF=(PCM,Solvent=Water) TD=(NStates=5)",
        "purpose": "在 PCM 隐式溶剂中算激发态，考察溶剂化对激发能/振子强度的影响（态特异性溶剂化）。",
        "g09_d01_ok": True,
        "notes": "与基态 PCM 不同：溶剂化反应场在激发态下重组（TD 自带状态特异性）。"
                 "对比同分子气相 TD 的 S1 能级即可得到溶剂化致色移（Stokes/luminescence shift）。pcm_active 标记，ΔG_solv 仍用溶液−气相 SCF 相减。",
        "parser_fields": ["excited_states", "scf_energy", "pcm_active"],
        "special": None,
    },
    "anharmonic": {
        "title": "非谐振振动频率（VPT2 / DCPT2）",
        "route": "# {mb} Freq=(Anharmonic)",
        "purpose": "二阶微扰（VPT2）校正谐振频率的非谐振偏移；较新 Gaussian 还支持 DCPT2/HDCPT2 等更高阶方案。",
        "g09_d01_ok": True,
        "notes": "⚠️ 本机 32 位 g09 D.01 的 `Freq=(Anharmonic,VPT2)` 中 **VPT2 子选项不被识别**（报 rc=2057）；改用 Plain `Freq=(Anharmonic)` 即通过（输出 'Fundamental Bands' 表）。"
                 "解析读 anharmonic_frequencies（含 Harmonic/Anharmonic 两列，cm^-1）。"
                 "G16 用户可加 VPT2/DCPT2/HDCPT2 等更高阶方案。",
        "parser_fields": ["frequencies", "anharmonic_frequencies"],
        "special": None,
    },
    "preresonance_raman": {
        "title": "预共振拉曼（CPHF=RdFreq）",
        "route": "# {mb} Freq=Raman CPHF=RdFreq",
        "purpose": "在近共振激发频率下算 Raman 散射，得到预共振/共振拉曼增强截面。",
        "g09_d01_ok": True,
        "notes": "页脚（footer）提供近共振激光频率（cm^-1，如 32000 对应 n→π* 区）。"
                 "CPHF=RdFreq 让 Gaussian 在该频率重算 CPHF 导数；读 raman_activities（共振增强后值）。",
        "parser_fields": ["frequencies", "raman_activities", "intensities"],
        "special": "rdfreq_footer",
    },
    "eom_ccsd": {
        "title": "EOM-CCSD 激发态（UV/Vis 耦合簇）",
        "route": "# CCSD/6-31G EOM=(EE,NStates=5)",
        "purpose": "以 EOM-CCSD（含激发态耦合簇）算高精度激发能/振子强度，作为 TD-DFT 的基准。",
        "g09_d01_ok": False,
        "notes": "⚠️ 本机 32 位 g09 D.01 **不含 EOM 模块**：`EOM=EE` 与 `EOM=(EE,NStates=5)` 均报 rc=2057（QPErr 'Unknown keyword'）。"
                 "此配方仅 G16（或带 EOM 的版本）可用。EOM-CCSD 固定为 CCSD 方法，mb 占位符无效；EE 指单激发/电离类激发态。"
                 "换 G16 后：解析读 excited_states（EOM 激发能以 'Excited State' 格式打印则自动捕获）。",
        "parser_fields": ["scf_energy", "excited_states", "cis_energy"],
        "special": None,
    },
    "nmr_jcoupling": {
        "title": "NMR 屏蔽 + 自旋-自旋耦合常数 J",
        "route": "# {mb} NMR=(GIAO,SpinSpin)",
        "purpose": "GIAO 各向同性屏蔽常数（化学位移参考量）+ 全核间自旋-自旋耦合常数 J（Hz）。",
        "g09_d01_ok": True,
        "notes": "NMR=(GIAO,SpinSpin) 同时给屏蔽张量与耦合矩阵。读 nmr_shieldings（屏蔽）与 j_couplings（J，Hz，下三角矩阵展平为 (i,j,Hz) 列表）。"
                 "化学位移 = 参考物屏蔽常数 − 该核屏蔽常数（如 TMS C≈190 ppm、H≈31 ppm 作参考）。",
        "parser_fields": ["scf_energy", "nmr_shieldings", "j_couplings"],
        "special": None,
    },
    "vcd": {
        "title": "振动圆二色性（VCD）",
        "route": "# {mb} Freq=(VCD)",
        "purpose": "振动圆二色性强度（手性分子的红外区 CD 信号），用于绝对构型判定。",
        "g09_d01_ok": True,
        "notes": "需手性分子（如 gauche H2O2、methyloxirane）。读 vcd_intensities（旋转强度/Δε 类强度，与 frequencies 一一对应）。"
                 "VCD 与 ECD 不同：VCD 在振动频率区，无需 CPolar。"
                 "⚠️ VCD 必须在**真实极小点**上算：先用 'Opt Freq' 确认该手性构象 n_imag=0；"
                 "若构象接近柔性的扭转鞍点（如 H2O2 的 gauche 与 trans 间），直接 Freq=(VCD) 可能带虚频、信号失真。"
                 "稳妥做法：先用 `Opt=ModRedundant NoSymm` + 页脚冻结关键二面角（如 `3 1 2 4 F`）锁定手性极小点，再在其几何上跑 Freq=(VCD)。",
        "parser_fields": ["frequencies", "vcd_intensities"],
        "special": None,
    },
    "ecd": {
        "title": "电子圆二色性（ECD，需 CPolar）",
        "route": "# {mb} TD=(NStates=8) CPolar",
        "purpose": "电子圆二色性（UV/Vis 区 CD），用于绝对构型/手性判定。",
        "g09_d01_ok": False,
        "notes": "本机 32 位 g09 D.01 的 CPolar 关键字不存在（rc=2057）。需 G16 或带 CPolar 的版本："
                 "路线改为 '# {mb} TD=(NStates=8) CPolar'，解析器读 ecd_transitions（(态, 旋光强度) 列表）。",
        "parser_fields": ["excited_states", "ecd_transitions"],
        "special": None,
    },
    "optrot": {
        "title": "旋光性（ORD）",
        "route": "# {mb} Polar=(OptRot)",
        "purpose": "光学旋光（比旋光度 [α]），ORD 的基础量。",
        "g09_d01_ok": True,
        "notes": "静态 ORD（Optical Rotation）由 Polar=(OptRot) 给出；波长依赖 ORD 需 TD CPolar（g09 D.01 受限）。"
                 "读 optical_rotation（deg，特定波长下；手性分子如 H2O2）。",
        "parser_fields": ["optical_rotation"],
        "special": None,
    },
    "roa": {
        "title": "拉曼光学活性（ROA）",
        "route": "# {mb} Freq=(ROA) CPHF=RdFreq",
        "purpose": "拉曼光学活性（手性分子的 Raman 差谱），与 VCD 互补判定绝对构型。",
        "g09_d01_ok": True,
        "notes": "⚠️ ROA 必须在页脚（footer）提供近共振激光频率（cm^-1），且路由带 `CPHF=RdFreq`："
                 "否则 g09 报 'CPHF=RdFreq but no frequencies in input' 而中止。例 footer 写 `18797.0`（对应 ~532 nm 激光）。"
                 "需手性分子（如 gauche H2O2）。读 roa_intensities（与 frequencies 对应的 ROA 强度；极小体系信号可能≈0，属正常，工作流已验证）。",
        "parser_fields": ["frequencies", "roa_intensities"],
        "special": "rdfreq_footer",
    },
    "vibrot": {
        "title": "振动-转动耦合",
        "route": "# {mb} Freq=(VibRot)",
        "purpose": "振动-转动相互作用常数 α（用于高分辨转动-振动光谱、谱线型）。",
        "g09_d01_ok": True,
        "notes": "Freq=(VibRot) 在频率分析基础上算振动-转动相互作用常数。读 vibrot_alpha（各模式 α 常数）。",
        "parser_fields": ["frequencies", "vibrot_alpha"],
        "special": None,
    },
    "hyperfine": {
        "title": "超精细耦合常数与 g 张量（EPR）",
        "route": "# {mb} NMR",
        "purpose": "EPR 超精细耦合常数 A（各向同性，MHz）与电子 g 张量，针对开壳层（自由基/双自由基）。",
        "g09_d01_ok": True,
        "notes": "⚠️ 本机 32 位 g09 D.01 **无 `Hyperfine=` 关键字**（报 rc=2057）。本构建下的可用路线是开壳层 NMR 作业："
                 "mb 传 'UB3LYP/6-31G(d)'、并设 charge/mult 为自由基（如 OH 自由基 charge=0 mult=2）。"
                 "开壳层 NMR 会自动输出 'Isotropic Fermi Contact Couplings'（超精细 A_iso, MHz）与 'g tensor' 主值。"
                 "读 hyperfine_couplings（A_iso, MHz）与 g_tensor（[Gx,Gy,Gz]）。G16 用户可再用 `Hyperfine=(FC,SD)` 取更全的各向异性超精细张量。",
        "parser_fields": ["scf_energy", "hyperfine_couplings", "g_tensor"],
        "special": None,
    },

    # ---------- 第四批 10 案例（v1.7.0 扩展：复杂多步 / 高阶后 HF / 分层 / 群体分析） ----------
    "oniom": {
        "title": "ONIOM 分层 QM/MM 计算",
        "route": "# ONIOM(B3LYP/6-31G(d):UFF) Opt",
        "purpose": "把体系分为高/低层（如反应中心 QM + 环境 MM），ONIOM 外推得到近全 QM 精度但成本大降。",
        "g09_d01_ok": False,
        "notes": "⚠️ 本机 32 位 Gaussian 09 Rev D.01 的 L101 在读取带层标记的原子名（Cartesian 与 Z-matrix 两种写法均实测）时"
                 "会触发 'String too long in FFGetT' 硬错（rc=1），即本构建**无法解析 ONIOM 层标记**。语法本身正确，"
                 "在 64 位 g09 / G16 上可用。规范 2 层写法：模型的“高层”原子名不加后缀、仅“低层专属”原子加 (L)，"
                 "例如甲醇 'C O H(H羟基) H(L) H(L) H(L)'；route 形如 ONIOM(高方法/高基组:低方法/低基组)。"
                 "解析读 oniom_energies（含外推与各层能量），本构建下为 None。",
        "parser_fields": ["oniom_energies", "scf_energy", "converged", "optimized_geometry"],
        "special": "oniom_layers",
    },
    "admp": {
        "title": "第一性原理分子动力学 (ADMP)",
        "route": "# B3LYP/6-31G(d) ADMP=MaxPoints=20",
        "purpose": "以 DFT 力场驱动 Born-Oppenheimer 分子动力学（ADMP），采样核构型演化与能量轨迹。",
        "g09_d01_ok": True,
        "notes": "ADMP=MaxPoints=N 控制步数；建议配 MaxStep/StepSize 控步长。极小体系（如水）演示即可。"
                 "解析读 md_trajectory（(步, 能量) 列表）与 scf_energy（末步）。本机单核，步数勿大。",
        "parser_fields": ["md_trajectory", "scf_energy", "n_imaginary"],
        "special": None,
    },
    "bs_dft": {
        "title": "断键对称破缺 (Broken-Symmetry) 反铁磁耦合",
        "route": "# UB3LYP/6-31G(d) Guess=Mix Stable=Opt",
        "purpose": "对开壳层双自由基/反铁磁耦合体系，用对称破缺波函数算交换耦合常数 J_AB = (E_BS − E_HS)/(<S²>_HS − <S²>_BS)。",
        "g09_d01_ok": True,
        "notes": "需跑两次：① 高自旋 (mult=2S+1) 直算 E_HS；② 断键对称破缺 (mult=1, Guess=Mix Stable=Opt) 得 E_BS。"
                 "两者 SCF 能量相减结合各自的 <S²> 得 J。本例用 O2（三重态基态）演示工作流；解析读 scf_energy 与 s2（<S²>）。",
        "parser_fields": ["scf_energy", "converged", "s2"],
        "special": "bs_workflow",
    },
    "noneq_pcm": {
        "title": "非平衡 PCM 荧光发射（态特异性溶剂化）",
        "route": "# B3LYP/6-31G(d) TD=(NStates=3) SCRF=(PCM,Solvent=Water) Geom=AllCheck",
        "purpose": "用非平衡 PCM 算 S1→S0 垂直发射能（含溶剂化重组 + 非平衡响应），比平衡 PCM 更接近真实荧光/磷光溶剂化位移。",
        "g09_d01_ok": True,
        "notes": "两步：① S0 平衡 PCM Opt Freq，页脚 NonEq=write（把平衡反应场存入 chk）；"
                 "② 读该 chk（Geom=AllCheck，勿带 SCRF(...,Read)）+ 页脚 NonEq=read，TD 在 S0 平衡场下做非平衡响应，"
                 "excited_states[0] 的 S1 即垂直发射能。⚠️ 第②步 SCRF 不要再写 ,Read（由 NonEq=read 接管），否则与显式电荷卡冲突报错。"
                 "pcm_nonequilibrium 标记本步为非平衡模式。",
        "parser_fields": ["excited_states", "scf_energy", "pcm_active", "pcm_nonequilibrium"],
        "special": "noneq_workflow",
    },
    "nto": {
        "title": "自然跃迁轨道 (NTO)",
        "route": "# B3LYP/6-31G(d) TD=(NStates=5) Pop=NTO",
        "purpose": "将 TDDFT 激发态分解为少量 NTO 对（占据 NTO + 空 NTO），直观看电子从哪跃迁到哪。",
        "g09_d01_ok": False,
        "notes": "⚠️ 本机 32 位 g09 D.01 虽接受 `Pop=NTO` 路由（rc=0），但**不打印 NTO 占据数块**"
                 "（NTO 分析需 G16 或带对应模块的版本）；nto_occupations 在本机构建下为 None。"
                 "G16 下会输出各激发态 NTO 占据数（0~1），占据接近 1 的 NTO 对主导该激发；"
                 "解析读 nto_occupations（(态, 主导 NTO 占据数) 列表）。",
        "parser_fields": ["excited_states", "nto_occupations", "scf_energy"],
        "special": None,
    },
    "nbo_e2": {
        "title": "NBO 二阶微扰 E(2) 电子供体-受体",
        "route": "# B3LYP/6-31G(d) Pop=NBO",
        "purpose": "用 NBO 二阶微扰理论量化供体→受体的超共轭/电子授受强度（E(2), kcal/mol）。",
        "g09_d01_ok": True,
        "notes": "route 直接写 Pop=NBO 即可触发 NBO 二阶微扰表（默认阈值 0.5 kcal/mol）。"
                 "⚠️ 本机构建**不能**用页脚 '$NBO E2=10.0 $END' 自定义阈值（会报 'Unrecognizable keyword >>E2<<'），"
                 "须依赖默认 0.5 阈值。若体系无超过阈值的供体-受体对（如氨），nbo_e2 为空列表属正常。"
                 "解析读 nbo_e2（(供体,受体,E2_kcal) 列表）。",
        "parser_fields": ["nbo_e2", "nbo_charges", "scf_energy"],
        "special": None,
    },
    "scan2d": {
        "title": "2D 双变量势能面扫描",
        "route": "# B3LYP/6-31G(d) Opt=ModRedundant NoSymm",
        "purpose": "沿两个内坐标（如键长 + 角）同时柔性扫描，得到 2D 势能面网格。",
        "g09_d01_ok": True,
        "notes": "页脚扫描指令**类型字母在前**：键长 'B 1 2 S 3 0.10'（B=键, 原子1-2, S=步长, 3 步, 增量0.10 Å），"
                 "角 'A 2 1 3 S 3 5.0'（A=角, 顶点在2, S=步长, 3 步, 增量5.0°）。务必 NoSymm 避免对称性折叠扫描变量。"
                 "解析读 scan2d（每条 (坐标值列表, 能量)，能量为本机构建 'Eigenvalues' 列）。网格点数 = n1×n2，控制规模。",
        "parser_fields": ["scan2d", "converged"],
        "special": "modredundant_footer",
    },
    "hirshfeld": {
        "title": "Hirshfeld 电荷 (Stockholder 分配)",
        "route": "# B3LYP/6-31G(d) Pop=Hirshfeld",
        "purpose": "用 Hirshfeld（Stockholder）电荷作与基组基本无关的原子电荷，与 Mulliken/MK 对照。",
        "g09_d01_ok": True,
        "notes": "Pop=Hirshfeld 单点输出 Hirshfeld charges 块。解析读 hirshfeld_charges（(符号,电荷) 列表）。"
                 "可与 Pop=(Hirshfeld,NPA,MK) 一并要多种电荷布居对照。",
        "parser_fields": ["hirshfeld_charges", "scf_energy"],
        "special": None,
    },
    "link1": {
        "title": "多步作业链 (--Link1--: Opt→大基组 SP→TD)",
        "route": "# B3LYP/6-31G(d) Opt Freq --Link1-- # B3LYP/6-311++G(2d,2p) SP --Link1-- # B3LYP/6-31G(d) TD=(NStates=3)",
        "purpose": "单个 .gjf 内用 --Link1-- 串联多步作业（优化→大基组单点→激发态），自动把上一步 chk/几何传给下一步。",
        "g09_d01_ok": True,
        "notes": "每段自带路由；中间用 %chk 贯穿。极小体系演示。解析读最终步结果（scf_energy / excited_states）。"
                 "此即“双层级”计算（优化用便宜基组、能量用大基组）的落地方式。",
        "parser_fields": ["scf_energy", "excited_states", "converged"],
        "special": "link1_chain",
    },
    "ccsd_t": {
        "title": "CCSD(T) 耦合簇单点（黄金标准）",
        "route": "# CCSD(T)/6-31G(d)",
        "purpose": "在 CCSD 之上加 (T) 微扰三激发校正，得到接近 FCI 的“黄金标准”能量（高阶相关）。",
        "g09_d01_ok": True,
        "notes": "CCSD(T) 固定方法，mb 占位符无效。解析读 ccsd_t_energy（CCSD(T)= 总能量）与 scf_energy（HF）。"
                 "32 位 %mem≤1.5GB，仅限极小分子；体系稍大即超出地址空间。",
        "parser_fields": ["ccsd_t_energy", "scf_energy", "scf_method"],
        "special": None,
    },
}


def case_route(name: str, mb: str = "B3LYP/6-31G(d)") -> str:
    """
    返回某计算类型的完整路由行（已填入方法/基组）。

    Parameters
    ----------
    name : str
        CASE_CATALOG 中的配方名（如 "nmr"、"mp2"、"tdopt"）。
    mb : str
        方法/基组，默认 "B3LYP/6-31G(d)"。配方路由不含 {mb} 占位符时（如 MP2）此参数被忽略。

    Returns
    -------
    str
        形如 "# B3LYP/6-31G(d) NMR=GIAO" 的路由行。
    """
    recipe = CASE_CATALOG[name]
    route = recipe["route"]  # type: ignore[index]
    if "{mb}" in route:
        return route.format(mb=mb)
    return route


def list_cases() -> List[str]:
    """返回所有配方名（按目录顺序）。"""
    return list(CASE_CATALOG.keys())


def catalog_summary() -> str:
    """返回一份人类可读的配方速查表。"""
    lines = ["Gaussian 计算类型配方速查（本机 32 位 g09 D.01 实测）", "=" * 52]
    for name, r in CASE_CATALOG.items():
        ok = "✓" if r["g09_d01_ok"] else "✗"
        lines.append(f"[{ok}] {name:<10} {r['title']}")
        lines.append(f"    route : {case_route(name)}")
        if r["special"]:
            lines.append(f"    特殊 : {r['special']}")
    return "\n".join(lines)
