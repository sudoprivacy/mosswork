"""
通用小工具：XYZ 读写、元素符号/原子序数互转
============================================
"""

from __future__ import annotations

from typing import List, Tuple, Sequence, Optional, Dict, Any

# 原子序数 -> 元素符号（常用范围，覆盖 H~Xe）
NUMBER_TO_SYMBOL: Dict[int, str] = {
    1: "H", 2: "He", 3: "Li", 4: "Be", 5: "B", 6: "C", 7: "N", 8: "O", 9: "F",
    10: "Ne", 11: "Na", 12: "Mg", 13: "Al", 14: "Si", 15: "P", 16: "S", 17: "Cl",
    18: "Ar", 19: "K", 20: "Ca", 21: "Sc", 22: "Ti", 23: "V", 24: "Cr", 25: "Mn",
    26: "Fe", 27: "Co", 28: "Ni", 29: "Cu", 30: "Zn", 31: "Ga", 32: "Ge", 33: "As",
    34: "Se", 35: "Br", 36: "Kr", 37: "Rb", 38: "Sr", 39: "Y", 40: "Zr", 41: "Nb",
    42: "Mo", 43: "Tc", 44: "Ru", 45: "Rh", 46: "Pd", 47: "Ag", 48: "Cd", 49: "In",
    50: "Sn", 51: "Sb", 52: "Te", 53: "I", 54: "Xe",
}

SYMBOL_TO_NUMBER: Dict[str, int] = {v: k for k, v in NUMBER_TO_SYMBOL.items()}


def symbol_to_number(symbol: str) -> int:
    """元素符号 -> 原子序数。"""
    s = symbol.strip().capitalize()
    if s not in SYMBOL_TO_NUMBER:
        raise ValueError(f"未知元素符号: {symbol}")
    return SYMBOL_TO_NUMBER[s]


def number_to_symbol(num: int, default: str = "X") -> str:
    """原子序数 -> 元素符号；未知返回 default（默认 'X'）。"""
    return NUMBER_TO_SYMBOL.get(int(num), default)


def read_xyz(path: str) -> Tuple[List[str], List[List[float]], str]:
    """
    读取 XYZ 文件。

    返回
    ----
    (atoms, coords, comment)
      atoms   : 元素符号列表
      coords  : [[x, y, z], ...]
      comment : 第二行注释
    """
    with open(path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    if len(lines) < 2:
        raise ValueError(f"XYZ 文件格式异常: {path}")
    n = int(lines[0])
    comment = lines[1] if len(lines) > 1 else ""
    atoms: List[str] = []
    coords: List[List[float]] = []
    for ln in lines[2:2 + n]:
        parts = ln.split()
        if len(parts) < 4:
            continue
        atoms.append(parts[0])
        coords.append([float(parts[1]), float(parts[2]), float(parts[3])])
    return atoms, coords, comment


def write_xyz(path: str, atoms: Sequence[str], coords: Sequence[Sequence[float]],
              comment: str = "") -> str:
    """写出 XYZ 文件。"""
    if len(atoms) != len(coords):
        raise ValueError("原子符号数量与坐标数量不一致")
    lines = [str(len(atoms)), comment]
    for sym, (x, y, z) in zip(atoms, coords):
        lines.append(f"{sym:>2s}    {float(x):14.8f}{float(y):14.8f}{float(z):14.8f}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return path
