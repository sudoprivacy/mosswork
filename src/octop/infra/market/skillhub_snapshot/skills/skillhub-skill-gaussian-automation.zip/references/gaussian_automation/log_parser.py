"""
解析 Gaussian 输出文件 (.log / .out) 的常用工具
================================================
提取最常用的计算结果：是否正常终止、SCF 能量、优化是否收敛、
振动频率与红外强度、优化后的结构、热力学修正量、偶极矩、HOMO/LUMO。

所有提取均为“尽力而为 (best-effort)”：缺失的信息对应字段为 None。
"""

from __future__ import annotations

import re
from typing import Optional, List, Tuple, Dict, Any


def _to_float(s: str) -> Optional[float]:
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def parse_log(path: str) -> Dict[str, Any]:
    """
    解析一个 Gaussian 输出文件，返回一个字典。

    关键字段
    --------
    normal_termination : bool   是否 “Normal termination”
    error_termination  : bool   是否 “Error termination”
    error_message      : str|None  末条错误信息
    scf_energy         : float|None  最后一个 SCF 能量 (Hartree)
    scf_method         : str|None    SCF 方法名，如 RB3LYP
    converged          : bool|None   几何优化是否收敛
    frequencies        : list[float]  全部振动频率 (cm^-1)
    intensities        : list[float]  对应红外强度 (km/mol)
    optimized_geometry : dict|None    {"atoms":[...], "coords":[[x,y,z],...]}
    zero_point / thermal_energy / thermal_enthalpy / thermal_free_energy : float|None
    sum_energy / sum_enthalpy / sum_free_energy : float|None
    dipole             : dict|None    {"x","y","z","tot"} (Debye)
    homo_lumo          : tuple|None   (HOMO, LUMO) 能量 (Hartree, 闭壳层 alpha)
    excited_states     : list|None    TDDFT 激发态 [(state, label, eV, nm, f), ...]
    mulliken_charges   : list|None    Mulliken 电荷 [(symbol, charge), ...]
    esp_charges        : list|None    ESP 拟合电荷（Merz-Kollman）[(symbol, charge), ...]
    n_imaginary       : int          虚频（负频率）数目，用于过渡态判定
    nmr_shieldings    : list|None    NMR 各向同性屏蔽常数 [(symbol, ppm), ...]
    scan_results      : list|None    PES 扫描 (step, 扫描坐标值, 能量 Hartree)
    mp2_correlation   : float|None   MP2 相关能 (E2)
    mp2_total         : float|None   MP2 总能量
    cis_energy        : float|None   CIS 总能量 E(CIS)
    pcm_active        : bool        是否使用了 PCM/SCRF 隐式溶剂化
    pcm_solvation_free_energy : float|None  PCM 溶剂化自由能
    raman_activities   : list|None    Raman 散射活性
    polarizability    : list|None    极化率张量（展平数值）
    isotropic_polarizability : float|None  各向同性极化率 (Bohr^3)
    ecd_transitions   : list|None    ECD 旋光强度 [(state, rotatory), ...]
    stability         : str|None     "stable" / "unstable"（波函数稳定性）
    nbo_charges       : list|None    NBO 自然电荷 [(symbol, charge), ...]
    bsse_corrected_energy : float|None  Counterpoise 校正后能量
    complexation_energy_corrected : float|None  校正后复合能 (kcal/mol)
    anharmonic_frequencies : list|None  非谐振频率 [(mode, harmonic, anharmonic), ...]
    j_couplings        : list|None  自旋-自旋耦合常数 [(sym_i, sym_j, Hz), ...]
    vcd_intensities    : list|None  振动圆二色性强度（与 frequencies 对应）
    optical_rotation   : float|None  静态光学旋光 Beta (au)
    roa_intensities    : list|None  拉曼光学活性强度
    vibrot_alpha       : list|None  振动-转动相互作用常数矩阵 (cm^-1)
    hyperfine_couplings: list|None  超精细耦合 [(symbol, A_iso_MHz), ...]
    g_tensor           : list|None  电子 g 张量主值 [Gx, Gy, Gz] (ppm)
    """
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()

    result: Dict[str, Any] = {
        "path": path,
        "normal_termination": False,
        "error_termination": False,
        "error_message": None,
        "scf_energy": None,
        "scf_method": None,
        "converged": None,
        "frequencies": [],
        "intensities": [],
        "optimized_geometry": None,
        "zero_point": None,
        "thermal_energy": None,
        "thermal_enthalpy": None,
        "thermal_free_energy": None,
        "sum_energy": None,
        "sum_enthalpy": None,
        "sum_free_energy": None,
        "dipole": None,
        "homo_lumo": None,
        "excited_states": None,
        "mulliken_charges": None,
        "esp_charges": None,
        "n_imaginary": 0,
        "nmr_shieldings": None,
        "scan_results": None,
        "mp2_correlation": None,
        "mp2_total": None,
        "cis_energy": None,
        "pcm_active": False,
        "pcm_solvation_free_energy": None,
        "raman_activities": None,
        "polarizability": None,
        "isotropic_polarizability": None,
        "ecd_transitions": None,
        "stability": None,
        "nbo_charges": None,
        "bsse_corrected_energy": None,
        "complexation_energy_corrected": None,
        # ---- v1.5.0 第三批案例新增字段 ----
        "anharmonic_frequencies": None,   # [(mode, harmonic, anharmonic), ...] (cm^-1)
        "j_couplings": None,              # [(sym_i, sym_j, Hz), ...] 自旋-自旋耦合 (下三角)
        "vcd_intensities": None,          # [float, ...] 振动圆二色性强度（与 frequencies 对应）
        "optical_rotation": None,         # float 静态光学旋光 Beta (au)
        "roa_intensities": None,          # [float, ...] 拉曼光学活性强度
        "vibrot_alpha": None,             # [[...], ...] 振动-转动相互作用常数矩阵 (cm^-1)
        "hyperfine_couplings": None,      # [(symbol, A_iso_MHz), ...] 超精细耦合
        "g_tensor": None,                 # [Gx, Gy, Gz] (ppm) 电子 g 张量主值
        # ---- v1.7.0 第四批复杂案例新增字段 ----
        "oniom_energies": None,           # dict  ONIOM 分层能量 {"extrapolated":float,"n_models":int}
        "md_trajectory": None,            # [(step, energy), ...]  ADMP/MD 能量轨迹
        "s2": None,                       # float  <S**2> 期望值（开壳层/BS-DFT）
        "pcm_nonequilibrium": False,      # bool   是否使用非平衡 PCM (NonEq)
        "nto_occupations": None,          # [(state, dominant_occ), ...]  自然跃迁轨道主导占据数
        "nbo_e2": None,                   # [(donor, acceptor, E2_kcal), ...]  NBO 二阶微扰
        "hirshfeld_charges": None,        # [(symbol, charge), ...]  Hirshfeld 电荷
        "scan2d": None,                   # [(coords_list, energy), ...]  2D 势能面扫描
        "ccsd_t_energy": None,           # float  CCSD(T)= 总能量 (Hartree)
    }

    # ---------- 终止状态 ----------
    if "Normal termination of Gaussian" in text:
        result["normal_termination"] = True
    if "Error termination" in text:
        result["error_termination"] = True
        # 多步作业（--Link1--）任一步出错即视为整体未正常终止，
        # 即便前面某步打印过 "Normal termination"。
        result["normal_termination"] = False
        errs = re.findall(r"Error termination request.*?\n\s*(.*)", text)
        if errs:
            result["error_message"] = errs[-1].strip()
        else:
            em = re.findall(r"Error termination (?:via \w+ in|in) .*?at\s+(\S+)", text)
            if em:
                result["error_message"] = "Error termination in " + em[-1]

    # ---------- SCF 能量（取最后一个，通常是最终值） ----------
    scf = re.findall(
        r"SCF Done:\s*E\(([^)]+)\)\s*=\s*([-+]?\d+\.\d+)", text
    )
    if scf:
        result["scf_method"] = scf[-1][0]
        result["scf_energy"] = _to_float(scf[-1][1])
    # 一些作业（如 MP2）不带 "SCF Done"，改用 "Energy="
    if result["scf_energy"] is None:
        m = re.search(r"\bEnergy=\s*([-+]?\d+\.\d+)", text)
        if m:
            result["scf_energy"] = _to_float(m.group(1))

    # ---------- 几何优化收敛 ----------
    if "Optimization completed." in text:
        result["converged"] = True
    elif "Optimization stopped." in text or "not converged" in text:
        result["converged"] = False

    # ---------- 振动频率 + 红外强度 ----------
    freqs: List[float] = []
    intens: List[float] = []
    for line in text.splitlines():
        m = re.match(r"\s*Frequencies\s*--\s*(.+)", line)
        if m:
            freqs.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
        m = re.match(r"\s*IR Inten\s*--\s*(.+)", line)
        if m:
            intens.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
    result["frequencies"] = freqs
    result["intensities"] = intens

    # ---------- 优化后的结构：取最后一个 "Standard orientation" ----------
    blocks = re.findall(
        r"Standard orientation:\s*\n\s*-+\s*\n"
        r".*?Center.*?Number.*?Type.*?X.*?Y.*?Z.*?\n\s*-+\s*\n"
        r"(.*?)\s*-+\s*\n",
        text,
        flags=re.DOTALL,
    )
    if blocks:
        # 需要元素序号 -> 符号 的映射
        from .utils import number_to_symbol
        atoms: List[str] = []
        coords: List[List[float]] = []
        for raw in blocks[-1].strip().splitlines():
            parts = raw.split()
            if len(parts) >= 5:
                try:
                    num = int(parts[1])
                    x, y, z = float(parts[3]), float(parts[4]), float(parts[5])
                except ValueError:
                    continue
                atoms.append(number_to_symbol(num, "X"))
                coords.append([x, y, z])
        if atoms:
            result["optimized_geometry"] = {"atoms": atoms, "coords": coords}

    # ---------- 热力学修正量 ----------
    zp = re.search(r"Zero-point correction=\s*([-+]?\d+\.\d+)", text)
    if zp:
        result["zero_point"] = _to_float(zp.group(1))
    te = re.search(r"Thermal correction to Energy=\s*([-+]?\d+\.\d+)", text)
    if te:
        result["thermal_energy"] = _to_float(te.group(1))
    th = re.search(r"Thermal correction to Enthalpy=\s*([-+]?\d+\.\d+)", text)
    if th:
        result["thermal_enthalpy"] = _to_float(th.group(1))
    tg = re.search(r"Thermal correction to Gibbs Free Energy=\s*([-+]?\d+\.\d+)", text)
    if tg:
        result["thermal_free_energy"] = _to_float(tg.group(1))

    se = re.search(r"Sum of electronic and thermal Energies=\s*([-+]?\d+\.\d+)", text)
    if se:
        result["sum_energy"] = _to_float(se.group(1))
    sh = re.search(r"Sum of electronic and thermal Enthalpies=\s*([-+]?\d+\.\d+)", text)
    if sh:
        result["sum_enthalpy"] = _to_float(sh.group(1))
    sf = re.search(r"Sum of electronic and thermal Free Energies=\s*([-+]?\d+\.\d+)", text)
    if sf:
        result["sum_free_energy"] = _to_float(sf.group(1))

    # ---------- 偶极矩 ----------
    dip = re.search(
        r"Dipole moment.*?\n\s*X=\s*([-+]?\d+\.\d+)\s*"
        r"Y=\s*([-+]?\d+\.\d+)\s*Z=\s*([-+]?\d+\.\d+)\s*Tot=\s*([-+]?\d+\.\d+)",
        text,
        flags=re.DOTALL,
    )
    if dip:
        result["dipole"] = {
            "x": _to_float(dip.group(1)),
            "y": _to_float(dip.group(2)),
            "z": _to_float(dip.group(3)),
            "tot": _to_float(dip.group(4)),
        }

    # ---------- HOMO / LUMO（闭壳层 alpha 轨道，尽力而为） ----------
    occ: List[float] = []
    virt: List[float] = []
    for line in text.splitlines():
        m = re.match(r"\s*Alpha\s+occ\.\s+eigenvalues\s*--\s*(.+)", line)
        if m:
            occ.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
        m = re.match(r"\s*Alpha\s+virt\.\s+eigenvalues\s*--\s*(.+)", line)
        if m:
            virt.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
    if occ and virt:
        result["homo_lumo"] = (occ[-1], virt[0])

    # ---------- TDDFT 激发态 ----------
    # 形如: " Excited State   1:   Singlet-A      2.5126 eV  493.39 nm  f=0.0000  <S**2>=0.000"
    excitations: List[Tuple[int, str, float, float, float]] = []
    for line in text.splitlines():
        m = re.search(
            r"Excited State\s+(\d+):\s+(\S+)\s+"
            r"([-+]?\d+\.\d+)\s+eV\s+([-+]?\d+\.\d+)\s+nm\s+f=([-+]?\d+\.\d+)",
            line,
        )
        if m:
            excitations.append(
                (
                    int(m.group(1)),
                    m.group(2),
                    _to_float(m.group(3)),
                    _to_float(m.group(4)),
                    _to_float(m.group(5)),
                )
            )
    if excitations:
        result["excited_states"] = excitations

    # ---------- 原子电荷（Mulliken / ESP 拟合 / Hirshfeld） ----------
    def _parse_charges(header: str):
        out: List[Tuple[str, float]] = []
        idx = text.find(header)
        if idx == -1:
            return out
        rest = text[idx + len(header):]
        for ln in rest.splitlines():
            # 遇到 “汇总/求和” 行或 Hirshfeld 的 “summed into” 子块 / Tot 行即停止，
            # 避免误吞后续子块（如 Hirshfeld “合并到重原子” 的伪原子）或坐标数字。
            if "Sum of" in ln or "summed into" in ln or ln.strip().startswith("Tot"):
                break
            mc = re.match(r"\s*\d+\s+([A-Z][a-z]?)\s+([-+]?\d+\.\d+)", ln)
            if mc:
                out.append((mc.group(1), _to_float(mc.group(2))))
            elif out and ln.strip() == "":
                break
        return out

    mull = _parse_charges("Mulliken charges:")
    if mull:
        result["mulliken_charges"] = mull
    esp = _parse_charges("ESP charges:")
    if esp:
        result["esp_charges"] = esp
    # 注意：Hirshfeld 的真实电荷块标题为 “Hirshfeld charges, spin densities, ...”，
    # 日志前面另有一处 “Hirshfeld charges” 路由回显（无电荷表），须用更具体的标题精准定位。
    hir = _parse_charges("Hirshfeld charges, spin densities")
    if hir:
        result["hirshfeld_charges"] = hir

    # ---------- 虚频计数（过渡态判定） ----------
    result["n_imaginary"] = len([v for v in result["frequencies"] if v < 0])

    # ---------- NMR 各向同性屏蔽常数（GIAO） ----------
    nmr = []
    for line in text.splitlines():
        m = re.search(r"^\s*\d+\s+([A-Za-z]{1,2})\s+Isotropic\s*=\s*([-+]?\d+\.\d+)", line)
        if m:
            nmr.append((m.group(1), _to_float(m.group(2))))
    if nmr:
        result["nmr_shieldings"] = nmr

    # ---------- PES 扫描：扫描点坐标值 / 能量（Opt=ModRedundant 柔性扫描） ----------
    scan = []
    msum = re.search(
        r"Summary of .*?Potential Surface Scan\s*\n(.*?)(?:\n\s*-{3,}\s*\n|\Z)",
        text, flags=re.DOTALL | re.IGNORECASE,
    )
    if msum:
        block = msum.group(1)
        eig_line = next((l for l in block.splitlines() if "Eigenvalues" in l), None)
        var_line = None
        for l in block.splitlines():
            if l.strip().startswith("R1 ") or l.strip().startswith("R1\t"):
                var_line = l
                break
        if var_line is None:
            for l in block.splitlines():
                if re.match(r"^\s*[RDAX]\d*\s+[-+]?\d+\.\d+", l) and "Eigenvalues" not in l:
                    var_line = l
                    break
        if eig_line and var_line:
            eig = [float(x) for x in re.findall(r"[-+]?\d+\.\d+", eig_line)]
            coord = [float(x) for x in re.findall(r"[-+]?\d+\.\d+", var_line)]
            if len(eig) == len(coord):
                scan = [(i + 1, coord[i], eig[i]) for i in range(len(eig))]
    if scan:
        result["scan_results"] = scan

    # ---------- MP2 相关能与总能量 ----------
    # 注意：MP2 输出里每个自旋分量行也带 "E2="（如 "E2= -0.24...D-01"，等号前无空格），
    # 而“总”相关能写在同一段末尾的 "E2 = ... EUMP2 = ..."（等号两侧有空格）。
    # 因此这里用 E2\s+=\s*（等号前至少一个空格）只抓总量那一行，避免误取分量。
    m_e2 = re.search(r"E2\s+=\s*([-+]?\d+\.\d+[DEde][+-]?\d+)", text)
    if m_e2:
        result["mp2_correlation"] = _to_float(m_e2.group(1).replace("D", "E").replace("d", "e"))
    # 总 MP2 能量：EUMP2 = ...（HF 能量 + E2 相关修正）
    m_mp2 = re.search(r"EUMP2\s*=\s*([-+]?\d+\.\d+[DEde][+-]?\d+)", text)
    if m_mp2:
        result["mp2_total"] = _to_float(m_mp2.group(1).replace("D", "E").replace("d", "e"))

    # ---------- CIS 总能量 ----------
    m_cis = re.search(r"Total Energy,\s*E\(CIS\)\s*=\s*([-+]?\d+\.\d+)", text)
    if m_cis:
        result["cis_energy"] = _to_float(m_cis.group(1))

    # ---------- PCM 溶剂化：是否启用 + 自由能 ----------
    # 注意：Gaussian 09 D.01 默认 PCM 输出【不会】单独打印
    # "Free energy of solvation = ..." 这一行，溶剂化能量已含在 SCF 里；
    # 要得到 ΔG_solv 必须用工况相减（溶液 SCF − 气相 SCF）。g16 等较新版本
    # 会打印该行，故这里两种都抓：先尝试直接读行，读不到则标记 pcm_active 待用户补气相。
    result["pcm_active"] = (
        "Polarizable Continuum Model (PCM)" in text
        or "Self Consistent Reaction Field" in text
        or "continuum solvation" in text.lower()
    )
    m_pcm = re.search(r"Free energy of solvation\s*=\s*([-+]?\d+\.\d+)", text)
    if m_pcm:
        result["pcm_solvation_free_energy"] = _to_float(m_pcm.group(1))

    # ---------- Raman 散射活性 ----------
    raman = []
    for line in text.splitlines():
        m = re.match(r"\s*Raman Activ\s*--\s*(.+)", line)
        if m:
            raman.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
    if raman:
        result["raman_activities"] = raman

    # ---------- 极化率张量 / 各向同性极化率 ----------
    # 优先取 "Exact polarizability:"（耦合微扰精确值）；若其为全 0（如 IRC 未计算），
    # 则退而取 "Approx polarizability:"，避免把无意义的全零当作有效结果。
    m_pol = re.search(
        r"Exact polarizability:\s*(" + r"[-+]?\d+\.\d+(?:\s+[-+]?\d+\.\d+)*" + r")", text
    )
    pol_vals = None
    if m_pol:
        cand = [float(v) for v in m_pol.group(1).split()]
        if any(v != 0.0 for v in cand):
            pol_vals = cand
    if pol_vals is None:
        m_ap = re.search(
            r"Approx polarizability:\s*(" + r"[-+]?\d+\.\d+(?:\s+[-+]?\d+\.\d+)*" + r")", text
        )
        if m_ap:
            pol_vals = [float(v) for v in m_ap.group(1).split()]
    if pol_vals:
        result["polarizability"] = pol_vals
    m_iso = re.search(
        r"Isotropic polarizability for W=\s*[-+]?\d+\.\d+\s+([-+]?\d+\.\d+)", text
    )
    if m_iso:
        result["isotropic_polarizability"] = _to_float(m_iso.group(1))

    # ---------- ECD 旋光强度（TDDFT 配合 CPolar） ----------
    ecd = []
    for line in text.splitlines():
        m = re.search(
            r"Excited State\s+(\d+).*?Rotatory strength\s*=\s*([-+]?\d+\.\d+)", line
        )
        if m:
            ecd.append((int(m.group(1)), _to_float(m.group(2))))
    if ecd:
        result["ecd_transitions"] = ecd

    # ---------- 波函数稳定性 ----------
    if "The wavefunction is stable" in text:
        result["stability"] = "stable"
    elif "The wavefunction is unstable" in text:
        result["stability"] = "unstable"

    # ---------- NBO 自然电荷（Natural Population Analysis） ----------
    nbo = []
    idx = text.find("Summary of Natural Population Analysis")
    if idx != -1:
        for ln in text[idx:].splitlines():
            if ln.strip().startswith("="):
                break  # 表结束（分隔线）
            mc = re.match(r"^\s*([A-Z][a-z]?)\s+\d+\s+([-+]?\d+\.\d+)", ln)
            if mc:
                nbo.append((mc.group(1), _to_float(mc.group(2))))
    if nbo:
        result["nbo_charges"] = nbo

    # ---------- Counterpoise BSSE 校正后能量 / 复合校正能 ----------
    m_bsse = re.search(r"Counterpoise corrected energy\s*=\s*([-+]?\d+\.\d+)", text)
    if m_bsse:
        result["bsse_corrected_energy"] = _to_float(m_bsse.group(1))
    m_cp = re.search(
        r"complexation energy\s*=\s*([-+]?\d+\.\d+)\s*kcal/mole\s*\(corrected\)", text
    )
    if m_cp:
        result["complexation_energy_corrected"] = _to_float(m_cp.group(1))

    # ---------- 第三批案例新增字段（v1.5.0） ----------
    # 非谐振频率（VPT2）：Fundamental Bands 表（mode, 谐振, 非谐振）
    anh = []
    m_anh = re.search(
        r"Fundamental Bands \(DE w\.r\.t\. Ground State\)\s*\n(.*?)(?:\n\s*\n|\Z)",
        text, flags=re.DOTALL,
    )
    if m_anh:
        for ln in m_anh.group(1).splitlines():
            ma = re.match(
                r"^\s*(\d+)\(\d+\)\s+active\s+([-+]?\d+\.\d+)\s+([-+]?\d+\.\d+)", ln
            )
            if ma:
                anh.append((int(ma.group(1)), _to_float(ma.group(2)), _to_float(ma.group(3))))
    if anh:
        result["anharmonic_frequencies"] = anh

    # NMR 自旋-自旋耦合常数 J（Hz）：下三角矩阵（行 i 含 J(i,1)..J(i,i)，对角=0）
    # 行标签后每个值用 D 记法；提取非对角 (col, row) 非零项，并映射原子符号
    jc = []
    idx_j = text.find("Total nuclear spin-spin coupling J (Hz):")
    if idx_j != -1:
        atoms_sym = (result.get("optimized_geometry") or {}).get("atoms")
        capture = False
        for ln in text[idx_j:].splitlines():
            if "Minotr" in ln:
                break
            if re.match(r"^\s*1\s+[-+]?\d+\.\d+[DEde]", ln):
                capture = True
            if capture and ln.strip() == "":
                break
            mm = re.match(r"^\s*(\d+)\s+(.+)", ln)
            if capture and mm:
                row = int(mm.group(1))
                vals = [float(x.replace("D", "E").replace("d", "e"))
                        for x in re.findall(r"[-+]?\d+\.\d+[DEde][+-]?\d+", mm.group(2))]
                for k, v in enumerate(vals[:-1]):   # 去掉对角 0
                    col = k + 1
                    if col < row and abs(v) > 0:
                        if atoms_sym and len(atoms_sym) >= row:
                            jc.append((atoms_sym[col - 1], atoms_sym[row - 1], v))
                        else:
                            jc.append((col, row, v))
        if jc:
            result["j_couplings"] = jc

    # VCD 振动圆二色性：旋转强度 Rot. str.
    vcd = []
    for line in text.splitlines():
        m = re.match(r"\s*Rot\.\s*str\.\s*--\s*(.+)", line)
        if m:
            vcd.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
    if vcd:
        result["vcd_intensities"] = vcd

    # ORD 旋光性：静态 Optical Rotation Beta (au)
    m_or = re.search(r"Optical Rotation Beta=\s*([-+]?\d+\.\d+)", text)
    if m_or:
        result["optical_rotation"] = _to_float(m_or.group(1))

    # ROA 拉曼光学活性：ROA1 列
    roa = []
    for line in text.splitlines():
        m = re.match(r"\s*ROA1\s+Fr=\s*\S+\s*(.*)", line)
        if m:
            roa.extend(float(v) for v in re.findall(r"[-+]?\d+\.\d+", m.group(1)))
    if roa:
        result["roa_intensities"] = roa

    # 振动-转动相互作用常数矩阵（cm^-1 块）
    va = []
    m_va = re.search(
        r"Vibro-Rot alpha Matrix \(in cm\^?-1\)\s*\n(.*?)(?:Vibro-Rot alpha Matrix \(in MHz\)|\Z)",
        text, flags=re.DOTALL,
    )
    if m_va:
        for ln in m_va.group(1).splitlines():
            nums = re.findall(r"[-+]?\d+\.\d+", ln)
            if nums:
                va.append([float(x) for x in nums])
    if va:
        result["vibrot_alpha"] = va

    # EPR 超精细耦合（各向同性 Fermi 接触，MHz）与 g 张量
    hf = []
    idx_h = text.find("Isotropic Fermi Contact Couplings")
    if idx_h != -1:
        for ln in text[idx_h:].splitlines():
            if "Spin Dipole" in ln:
                break
            mm = re.match(r"^\s*\d+\s+([A-Z][a-z]?)\(\d+\)\s+[-+]?\d+\.\d+\s+([-+]?\d+\.\d+)", ln)
            if mm:
                hf.append((mm.group(1), _to_float(mm.group(2))))
        if hf:
            result["hyperfine_couplings"] = hf
    m_gt = re.search(r"g tensor \[g = g_e.*?\]:\s*\n(.*?)(?:g shifts relative|\Z)",
                     text, flags=re.DOTALL)
    if m_gt:
        gv = {}
        for ln in m_gt.group(1).splitlines():
            for comp in ("XX", "YY", "ZZ"):
                mm = re.search(rf"{comp}=\s*([-+]?\d+\.\d+[DEde][+-]?\d+)", ln)
                if mm:
                    gv[comp] = float(mm.group(1).replace("D", "E").replace("d", "e"))
        if "XX" in gv and "YY" in gv and "ZZ" in gv:
            result["g_tensor"] = [gv["XX"], gv["YY"], gv["ZZ"]]

    # ---------- 第四批复杂案例新增字段（v1.7.0） ----------

    # ONIOM 分层能量：外推能量 + 模型层数
    m_oniom = re.search(r"ONIOM: extrapolated energy\s*=\s*([-+]?\d+\.\d+)", text)
    if m_oniom:
        oniom = {"extrapolated": _to_float(m_oniom.group(1)), "n_models": 0}
        mc = re.findall(r"ONIOM: system\s+\d+\s+\(the REAL system\)", text)
        oniom["n_models"] = len(mc)
        result["oniom_energies"] = oniom

    # ADMP / MD 能量轨迹：(步, 能量)
    md = []
    steps = [int(m.group(1)) for m in re.finditer(r"ADMP step\s+(\d+)", text)]
    energies = []
    for m in re.finditer(
        r"Total energy\s+([-+]?\d+\.\d+[DEde][+-]?\d+)\s*A\.U\.", text
    ):
        energies.append(_to_float(m.group(1).replace("D", "E").replace("d", "e")))
    for i, e in enumerate(energies):
        step = steps[i] if i < len(steps) else i
        md.append((step, e))
    if md:
        result["md_trajectory"] = md

    # <S**2> 期望值（开壳层 / 断键对称破缺）：取最后一个非激发态的 <S**2> 行
    # （UHF 收敛后打印；闭壳层 RHF 通常不打印，故闭壳层 s2 为 None，符合预期）
    s2_vals = []
    for ln in text.splitlines():
        if "Excited State" in ln:
            continue
        mm = re.search(r"<S\*\*2>\s*=\s*([-+]?\d+\.\d+)", ln)
        if mm:
            s2_vals.append(_to_float(mm.group(1)))
    if s2_vals:
        result["s2"] = s2_vals[-1]

    # 非平衡 PCM（NonEq=write/read）
    result["pcm_nonequilibrium"] = bool(
        re.search(r"Non[- ]?equilibrium", text, flags=re.IGNORECASE)
        or "NonEq" in text
    )

    # 自然跃迁轨道 NTO：每个激发态的主导 NTO 占据数
    nto = []
    idx = 0
    while True:
        pos = text.find("NTOs for state", idx)
        if pos == -1:
            break
        # 在后续 ~400 字符内找 "Alpha occ" 行
        seg = text[pos:pos + 600]
        mm = re.search(r"Alpha occ\.\s*eigenvalues\s*--\s*([-+]?\d+\.\d+)", seg)
        st = re.search(r"NTOs for state\s+(\d+)", seg)
        if mm and st:
            nto.append((int(st.group(1)), _to_float(mm.group(1))))
        idx = pos + 1
    if nto:
        result["nto_occupations"] = nto

    # NBO 二阶微扰 E(2)：供体 -> 受体 与 E(2) 值 (kcal/mol)
    nbo_e2 = []
    idx_n = text.find("E(2)  E(j)-E(i)")
    if idx_n == -1:
        idx_n = text.find("second order perturbation")
    if idx_n != -1:
        # 只要跑了 NBO 二阶微扰（出现该表头），nbo_e2 就固定为列表（可能为空）。
        # 空列表代表“无超过阈值的供体-受体对”（如氨：无 E(2)>0.5 kcal/mol），属正常。
        for ln in text[idx_n:].splitlines():
            if "----" in ln or ln.strip().startswith("="):
                continue
            # 形如:  LP ( 1) O   1         BD*( 1) C   2      12.34    0.56    0.078
            m = re.search(
                r"([A-Za-z]+\*?\(\s*\d+\)\s+[A-Z][a-z]?\s*\d+)"
                r"\s+(?:->\s*)?([A-Za-z]+\*?\(\s*\d+\)\s+[A-Z][a-z]?\s*\d+)"
                r"\s+([-+]?\d+\.\d+)", ln
            )
            if m:
                nbo_e2.append((m.group(1).strip(), m.group(2).strip(), _to_float(m.group(3))))
        result["nbo_e2"] = nbo_e2

    # Hirshfeld 电荷已在本节前段用更具体的标题 "Hirshfeld charges, spin densities" 解析，
    # 此处不再重复（避免误匹配前面的路由回显 “Hirshfeld charges”）。

    # 2D 双变量势能面扫描：把每个网格点解析为 (坐标值列表, 能量)
    # 摘要表结构（每 5 列一组，末组可能不足 5 列）：
    #     1         2         3         4         5
    #   Eigenvalues --   -76.38..  -76.38..  ...     <- 每列即一个扫描点能量
    #         R1           0.957..   1.057..  ...     <- 各变量在每列的取值
    #         R2           ...
    #         A1           ...
    # 故须按 "一个 Eigenvalues 行 + 其后若干变量行" 成块解析，
    # 第 k 列 = 一个网格点：( [R1[k], R2[k], A1[k], ...], energies[k] )。
    scan2d = []
    msum2 = re.search(
        r"Summary of .*?Optimized Potential Surface Scan\s*\n(.*?)(?:\n\s*-{3,}\s*\n|\Z)",
        text, flags=re.DOTALL | re.IGNORECASE,
    )
    if msum2:
        block = msum2.group(1)
        lines = block.splitlines()
        i = 0
        while i < len(lines):
            ln = lines[i]
            if "Eigenvalues" in ln:
                energies = [float(x) for x in re.findall(r"[-+]?\d+\.\d+", ln)]
                # 收集随后的变量行（R1/R2/A1/...），直到下一个 Eigenvalues 行或块尾
                j = i + 1
                var_cols = []  # [(变量名, [该列取值...]), ...]
                while j < len(lines):
                    nxt = lines[j]
                    if "Eigenvalues" in nxt:
                        break
                    mvar = re.match(r"\s*([RDAX]\d*)\s+", nxt)
                    if mvar and re.search(r"[-+]?\d+\.\d+", nxt):
                        vals = [float(x) for x in re.findall(r"[-+]?\d+\.\d+", nxt)]
                        if vals:
                            var_cols.append((mvar.group(1), vals))
                    j += 1
                if energies and var_cols:
                    n = len(energies)
                    for k in range(n):
                        coords = [vc[1][k] for vc in var_cols if k < len(vc[1])]
                        scan2d.append((coords, energies[k]))
                i = j
            else:
                i += 1
    if scan2d:
        result["scan2d"] = scan2d

    # CCSD(T) 总能量（注意 D 记法：CCSD(T)= -0.76...D+02）
    m_cc = re.search(r"CCSD\(T\)=\s*([-+]?\d+\.\d+[DEde][+-]?\d+)", text)
    if m_cc:
        result["ccsd_t_energy"] = _to_float(m_cc.group(1).replace("D", "E").replace("d", "e"))

    return result


def solvation_free_energy(pcm_path: str, gas_path: str) -> Optional[float]:
    """
    计算 PCM 溶剂化自由能 ΔG_solv = E(溶液) − E(气相)。

    适用场景：Gaussian 09 D.01 默认 PCM 输出不打印 "Free energy of solvation"，
    必须从「同一分子、同一方法/基组」的两次计算中相减得到。两次计算都用
    `parse_log` 取最后的 SCF 能量（Hartree）即可。

    参数
    ----
    pcm_path : 隐式溶剂化计算的 .log 路径
    gas_path : 对应气相计算的 .log 路径

    返回
    ----
    float | None : 溶剂化自由能（Hartree，负值为放能）；任一 SCF 缺失则返回 None
    """
    d_pcm = parse_log(pcm_path)
    d_gas = parse_log(gas_path)
    if d_pcm.get("scf_energy") is None or d_gas.get("scf_energy") is None:
        return None
    return d_pcm["scf_energy"] - d_gas["scf_energy"]


def summarize(path: str) -> str:
    """解析并生成一段人类可读的摘要文本。"""
    d = parse_log(path)
    lines = [f"== {d['path']} =="]
    if d["normal_termination"]:
        lines.append("状态      : 正常结束 (Normal termination)")
    elif d["error_termination"]:
        lines.append(f"状态      : 异常终止 (Error: {d['error_message']})")
    else:
        lines.append("状态      : 未知（未见终止标记）")
    if d["scf_energy"] is not None:
        lines.append(f"SCF 能量  : {d['scf_energy']:.8f} Hartree ({d['scf_method']})")
    if d["converged"] is not None:
        lines.append(f"优化收敛  : {'是' if d['converged'] else '否'}")
    if d["frequencies"]:
        n = len(d["frequencies"])
        lines.append(f"频率数目  : {n} （最低={min(d['frequencies']):.2f} cm^-1）")
    geom = d["optimized_geometry"]
    if geom:
        lines.append(f"优化结构  : {len(geom['atoms'])} 个原子")
    if d["sum_free_energy"] is not None:
        lines.append(f"G(298K)   : {d['sum_free_energy']:.8f} Hartree")
    if d["dipole"]:
        lines.append(f"偶极矩    : {d['dipole']['tot']:.4f} Debye")
    if d["homo_lumo"]:
        homo, lumo = d["homo_lumo"]
        lines.append(f"HOMO/LUMO : {homo:.4f} / {lumo:.4f} Hartree")
        lines.append(f"  能隙 HOMO-LUMO : {(lumo - homo) * 27.2114:.4f} eV")
    if d["n_imaginary"]:
        lines.append(f"虚频数量  : {d['n_imaginary']} （过渡态判定：{'是' if d['n_imaginary'] == 1 and d['converged'] else '否'}）")
    if d["excited_states"]:
        s1 = d["excited_states"][0]
        lines.append(f"TDDFT S1  : {s1[2]:.3f} eV ({s1[3]:.1f} nm, f={s1[4]:.4f}, {s1[1]})")
    if d["esp_charges"]:
        chars = " ".join(f"{s}{c:+.3f}" for s, c in d["esp_charges"][:6])
        lines.append(f"ESP 电荷  : {chars} ...")
    if d["nmr_shieldings"]:
        sh = " ".join(f"{s}{v:.2f}" for s, v in d["nmr_shieldings"][:6])
        lines.append(f"NMR 屏蔽  : {sh} (ppm, 各向同性)")
    if d["scan_results"]:
        steps = len(d["scan_results"])
        es = [s[2] for s in d["scan_results"] if s[2] is not None]
        rng = f"{max(es)-min(es):.5f}" if es else "?"
        lines.append(f"PES 扫描  : {steps} 步，能量跨度 {rng} Hartree")
    if d["mp2_correlation"] is not None:
        lines.append(f"MP2 相关能: {d['mp2_correlation']:.6f} Hartree")
    if d["mp2_total"] is not None:
        lines.append(f"MP2 总能量: {d['mp2_total']:.8f} Hartree")
    if d["cis_energy"] is not None:
        lines.append(f"CIS 总能量: {d['cis_energy']:.8f} Hartree")
    if d["pcm_solvation_free_energy"] is not None:
        lines.append(f"PCM 溶剂化: ΔG_solv = {d['pcm_solvation_free_energy']:+.4f} Hartree")
    if d["raman_activities"]:
        lines.append(f"Raman 活性: {len(d['raman_activities'])} 个模式（最大值 {max(d['raman_activities']):.2f} A^4/amu）")
    if d["polarizability"]:
        lines.append(f"极化率    : {len(d['polarizability'])} 个张量分量")
    if d["ecd_transitions"]:
        e1 = d["ecd_transitions"][0]
        lines.append(f"ECD 旋光  : S{e1[0]} 旋光强度 = {e1[1]:+.4f}")
    if d["stability"]:
        lines.append(f"波函数稳定: {d['stability']}")
    if d["nbo_charges"]:
        chars = " ".join(f"{s}{c:+.3f}" for s, c in d["nbo_charges"][:6])
        lines.append(f"NBO 电荷  : {chars} ...")
    if d["bsse_corrected_energy"] is not None:
        lines.append(f"BSSE 校正 : E_cp = {d['bsse_corrected_energy']:.8f} Hartree")
    # ---- v1.5.0 第三批新增字段 ----
    if d["anharmonic_frequencies"]:
        af = d["anharmonic_frequencies"]
        lines.append(f"非谐振频率: {len(af)} 个模式（如 1: 谐振={af[0][1]:.1f} → 非谐振={af[0][2]:.1f} cm^-1）")
    if d["j_couplings"]:
        jc = " ".join(f"{a}-{b}={v:.1f}Hz" for a, b, v in d["j_couplings"][:6])
        lines.append(f"J 耦合    : {jc} ...")
    if d["vcd_intensities"]:
        lines.append(f"VCD 强度  : {len(d['vcd_intensities'])} 个模式（最大 |Rot.str.|={max(abs(x) for x in d['vcd_intensities']):.2f}）")
    if d["optical_rotation"] is not None:
        lines.append(f"旋光 Beta : {d['optical_rotation']:+.4f} au (静态 OR)")
    if d["roa_intensities"]:
        lines.append(f"ROA 强度  : {len(d['roa_intensities'])} 个模式（最大 |ROA1|={max(abs(x) for x in d['roa_intensities']):.2f}）")
    if d["vibrot_alpha"]:
        lines.append(f"振动-转动: {len(d['vibrot_alpha'])} 行 α 矩阵（cm^-1）")
    if d["hyperfine_couplings"]:
        hf = " ".join(f"{s}={v:.1f}MHz" for s, v in d["hyperfine_couplings"])
        lines.append(f"超精细    : {hf}")
    if d["g_tensor"]:
        gx, gy, gz = d["g_tensor"]
        lines.append(f"g 张量    : [{gx:.4f}, {gy:.4f}, {gz:.4f}] (自由电子 g_e=2.0023)")
    # ---- v1.7.0 第四批复杂案例新增字段 ----
    if d["oniom_energies"]:
        oe = d["oniom_energies"]
        lines.append(f"ONIOM 能量: 外推={oe.get('extrapolated'):.8f} Ha ({oe.get('n_models')} 层)")
    if d["md_trajectory"]:
        mt = d["md_trajectory"]
        lines.append(f"MD 轨迹   : {len(mt)} 步（末步 E={mt[-1][1]:.6f} Ha）")
    if d["s2"] is not None:
        lines.append(f"<S**2>    : {d['s2']:.4f}")
    if d["pcm_nonequilibrium"]:
        lines.append("PCM 模式  : 非平衡 (NonEq)")
    if d["nto_occupations"]:
        no = " ".join(f"S{st}:{occ:.3f}" for st, occ in d["nto_occupations"][:6])
        lines.append(f"NTO 占据  : {no} ...")
    if d["nbo_e2"]:
        top = max(d["nbo_e2"], key=lambda x: x[2])
        lines.append(f"NBO E(2)  : {len(d['nbo_e2'])} 项（最强 {top[0]}->{top[1]}={top[2]:.2f} kcal/mol）")
    if d["hirshfeld_charges"]:
        hc = " ".join(f"{s}{c:+.3f}" for s, c in d["hirshfeld_charges"][:6])
        lines.append(f"Hirshfeld : {hc} ...")
    if d["scan2d"]:
        lines.append(f"2D 扫描   : {len(d['scan2d'])} 个网格点")
    if d["ccsd_t_energy"] is not None:
        lines.append(f"CCSD(T)   : {d['ccsd_t_energy']:.8f} Hartree")
    return "\n".join(lines)
