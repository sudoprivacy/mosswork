"""
调用 Gaussian 执行计算的常用工具
================================
通过 subprocess 调用 g16 / g09 可执行文件。

v1.1.0 新增：
  - 自动探测本机 Gaussian 安装（g16=None 时调用 detect 模块）
  - 计算结果归档：确保 .log / .chk 被正确生成并保存到指定目录（run_and_save）
  - 可选 formchk 把 .chk 转成可读的 .fchk

典型用法
--------
    from gaussian_automation import run_gaussian, run_and_save, parse_log

    # 自动探测本机 Gaussian
    log_path, rc = run_gaussian("water.gjf")          # g16 留空即可
    data = parse_log(log_path)

    # 一键运行并归档 .log + .chk 到 results/ 目录
    res = run_and_save("water.gjf", out_dir="results", make_fchk=True)
    print(res["log"], res["chk"], res["fchk"])
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from typing import Optional, List, Tuple, Iterable, Dict, Any, Callable

from .cpu import resolve_nprocs, _parse_nprocs_from_gjf, _NPROC_RE


def _arch_hint(g16: Optional[str]) -> Optional[str]:
    """仅当未显式指定 Gaussian 时探测架构，用于 32 位保守核数上限。"""
    if g16 is not None:
        return None
    try:
        from .detect import find_gaussian
        return find_gaussian().get("arch")
    except Exception:
        return None


def _prepare_run_gjf(
    gjf_path: str,
    nprocs: Any = None,
    chk: Optional[str] = None,
    arch_hint: Optional[str] = None,
    work_dir: Optional[str] = None,
    base: Optional[str] = None,
) -> str:
    """
    根据需要返回实际用于运行的 gjf 路径，必要时生成注入副本。

    处理：
      - 归一化 gjf 中已有的 %nprocs= / %nprocshared= -> %nprocshared=（保证被接受）
      - 若传入 nprocs（绝对核数 / 百分比），按解析值覆盖
      - 若传入 chk 且原 gjf 无 %chk=，注入 %chk=
    返回原路径（无需改动时）或新生成的 *_run.gjf 副本路径。
    """
    work_dir = work_dir or os.path.dirname(os.path.abspath(gjf_path))
    base = base or os.path.splitext(os.path.basename(gjf_path))[0]

    has_gjf_nproc = os.path.isfile(gjf_path) and (_parse_nprocs_from_gjf(gjf_path) is not None)

    nproc_value: Optional[int] = None
    if has_gjf_nproc:
        nproc_value = resolve_nprocs(gjf_path=gjf_path, arch=arch_hint)
    if nprocs is not None:
        # 用户显式输入优先级最高
        nproc_value = resolve_nprocs(user_input=nprocs, gjf_path=gjf_path, arch=arch_hint)

    inject: List[str] = []
    if nproc_value is not None:
        inject.append(f"%nprocshared={nproc_value}")
    if chk and extract_chk_name(gjf_path) is None:
        inject.append(f"%chk={chk}.chk")

    if not inject:
        return gjf_path

    with open(gjf_path, "r", encoding="utf-8") as f:
        content = f.read()

    # 去掉原始文件里已有的 nproc / 将要注入的 %chk 行，避免重复指令
    filtered: List[str] = []
    for ln in content.splitlines():
        if _NPROC_RE.search(ln):
            continue
        if chk and re.match(r"\s*%chk\s*=", ln, re.IGNORECASE):
            continue
        filtered.append(ln)

    run_gjf = os.path.join(work_dir, base + "_run.gjf")
    # 用 LF 行尾写入：g09 的 -- 片段分隔符 / Z-matrix 变量对 CRLF 敏感，
    # Windows 默认 text 模式会把 \n 写成 \r\n 导致解析失败。
    with open(run_gjf, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(inject) + "\n" + "\n".join(filtered) + "\n")
    return run_gjf


def run_gaussian(
    gjf_path: str,
    g16: Optional[str] = None,
    log_path: Optional[str] = None,
    timeout: Optional[float] = None,
    env: Optional[Dict[str, str]] = None,
    cwd: Optional[str] = None,
    nprocs: Any = None,
) -> Tuple[str, int]:
    """
    运行单个 Gaussian 作业。

    参数
    ----
    gjf_path   输入 .gjf 文件路径（必须存在）
    g16        Gaussian 可执行文件路径或命令名。
               默认 None → 自动探测本机安装（find_gaussian）。
    log_path   输出 .log 路径；默认与 gjf 同目录同名 .log
    timeout    超时秒数；超时抛 TimeoutExpired
    env        额外环境变量（会与探测到的 Gaussian 环境合并）
    cwd        工作目录（.chk 会生成在此目录）
    nprocs     并行核数：int("12") / "75%" / 0.75；或 None 沿用 gjf 自身设置

    返回
    ----
    (log_path, returncode)
    """
    if not os.path.isfile(gjf_path):
        raise FileNotFoundError(f"找不到输入文件: {gjf_path}")

    base = os.path.splitext(gjf_path)[0]
    if log_path is None:
        log_path = base + ".log"

    # 解析/归一化核数指令（必要时生成 _run.gjf 副本）
    run_gjf = _prepare_run_gjf(
        gjf_path, nprocs=nprocs, chk=None,
        arch_hint=_arch_hint(g16),
        work_dir=cwd or os.path.dirname(os.path.abspath(gjf_path)),
        base=base,
    )

    # 自动探测 Gaussian 安装
    run_env = os.environ.copy()
    if g16 is None:
        from .detect import require_gaussian
        info = require_gaussian()
        g16 = info["exe"]
        run_env.update(info["env"])
    if env:
        run_env.update(env)

    args = [g16, run_gjf, log_path]
    proc = subprocess.run(
        args,
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=run_env,
        cwd=cwd,
    )
    return log_path, proc.returncode


def extract_chk_name(gjf_path: str) -> Optional[str]:
    """从 .gjf 中读取 %chk= 指定的 chk 基名（不含扩展名）。找不到返回 None。"""
    try:
        with open(gjf_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                m = re.match(r"\s*%chk\s*=\s*(\S+)", line, re.IGNORECASE)
                if m:
                    return os.path.splitext(m.group(1))[0]
    except Exception:
        pass
    return None


def formchk(chk_path: str, fchk_path: Optional[str] = None,
            g16: Optional[str] = None) -> str:
    """
    调用 Gaussian 的 formchk，把二进制 .chk 转为可读文本 .fchk，
    便于查看波函数/轨道信息或做后处理。返回 .fchk 路径。
    """
    if fchk_path is None:
        fchk_path = os.path.splitext(chk_path)[0] + ".fchk"

    form_exe = None
    if g16 is None:
        from .detect import find_gaussian
        info = find_gaussian()
        if info["found"]:
            cand = os.path.join(info["exedir"], "formchk")
            ext = ".exe" if os.name == "nt" else ""
            if os.path.isfile(cand + ext):
                form_exe = cand + ext
    if form_exe is None:
        form_exe = "formchk"  # 退而求其次：依赖 PATH

    subprocess.run(
        [form_exe, chk_path, fchk_path],
        check=False, capture_output=True, text=True,
    )
    return fchk_path


def run_and_save(
    gjf_path: str,
    out_dir: Optional[str] = None,
    g16: Optional[str] = None,
    make_fchk: bool = False,
    timeout: Optional[float] = None,
    cwd: Optional[str] = None,
    chk: Optional[str] = None,
    nprocs: Any = None,
) -> Dict[str, Any]:
    """
    运行 Gaussian 并把 .log / .chk 结果文件生成并归档到 out_dir。

    参数
    ----
    gjf_path   输入 .gjf
    out_dir    结果保存目录（.log 与 .chk 写到这里）；默认与 gjf 同目录
    g16        同 run_gaussian；None 时自动探测
    make_fchk  是否额外调用 formchk 生成 .fchk
    timeout    超时
    cwd        工作目录（.chk 生成处）；默认 gjf 所在目录
    chk        显式指定 chk 基名。若原 gjf 未写 %chk=，会自动注入到副本中，
               确保 Gaussian 生成 .chk 文件。
    nprocs     并行核数：int("12") / "75%" / 0.75；或 None 沿用 gjf 自身设置。
               会被解析为 %nprocshared= 并注入运行副本（覆盖 gjf 原值）。

    返回
    ----
    字典：{log, chk, fchk, returncode, normal, ok}
      log/.chk/.fchk 分别为对应文件路径（未生成则为 None）
      normal : 是否 “Normal termination”
      ok     : 返回码为 0 且正常终止
    """
    base = os.path.splitext(os.path.basename(gjf_path))[0]
    work_dir = cwd or os.path.dirname(os.path.abspath(gjf_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    else:
        out_dir = work_dir

    # 解析/归一化核数指令 + 必要时注入 %chk（统一生成 _run.gjf 副本）
    run_gjf = _prepare_run_gjf(
        gjf_path, nprocs=nprocs, chk=chk,
        arch_hint=_arch_hint(g16),
        work_dir=work_dir, base=base,
    )

    log_path = os.path.join(out_dir, base + ".log")
    chk_name = chk or extract_chk_name(run_gjf) or base
    chk_src = os.path.join(work_dir, chk_name + ".chk")
    chk_dst = os.path.join(out_dir, chk_name + ".chk")

    log_out, rc = run_gaussian(run_gjf, g16=g16, log_path=log_path,
                               timeout=timeout, cwd=work_dir)

    result: Dict[str, Any] = {
        "log": log_path, "chk": None, "fchk": None,
        "returncode": rc, "normal": False,
    }

    # 归档 .chk
    if os.path.isfile(chk_src):
        if os.path.abspath(chk_src) != os.path.abspath(chk_dst):
            shutil.copy2(chk_src, chk_dst)
        result["chk"] = chk_dst

    # 判断是否正常终止
    try:
        from .log_parser import parse_log
        result["normal"] = parse_log(log_path)["normal_termination"]
    except Exception:
        pass

    # 可选：formchk -> .fchk
    if make_fchk and result["chk"]:
        fchk_path = os.path.splitext(result["chk"])[0] + ".fchk"
        formchk(result["chk"], fchk_path, g16=g16)
        if os.path.isfile(fchk_path):
            result["fchk"] = fchk_path

    result["ok"] = (rc == 0 and result["normal"])
    return result


def run_gaussian_batch(
    gjf_paths: Iterable[str],
    g16: Optional[str] = None,
    timeout: Optional[float] = None,
    env: Optional[Dict[str, str]] = None,
    cwd: Optional[str] = None,
    on_done: Optional[Callable[[str, str, int], None]] = None,
    stop_on_error: bool = False,
) -> List[Dict[str, Any]]:
    """
    批量运行多个 Gaussian 作业（顺序执行）。

    参数
    ----
    gjf_paths      输入文件列表/生成器
    g16            同 run_gaussian
    timeout        单个作业超时
    env            环境变量
    cwd            工作目录
    on_done        每完成一个作业回调 (gjf_path, log_path, returncode)
    stop_on_error  遇到非零返回码是否立即停止

    返回
    ----
    结果列表，每项 {"gjf", "log", "returncode"}
    """
    results: List[Dict[str, Any]] = []
    for gjf in gjf_paths:
        log_path, rc = run_gaussian(
            gjf, g16=g16, timeout=timeout, env=env, cwd=cwd
        )
        rec = {"gjf": gjf, "log": log_path, "returncode": rc}
        results.append(rec)
        if on_done:
            on_done(gjf, log_path, rc)
        if stop_on_error and rc != 0:
            break
    return results
