"""
本机 Gaussian 安装探测与版本兼容
================================
自动搜索本机 Gaussian（g16 / g09）的安装路径与可执行文件，并构造兼容的运行环境。

探测顺序：
  1. 显式传入的 exe 路径
  2. 系统 PATH（shutil.which）
  3. 各平台常见安装目录
  4. 环境变量 GAUSS_EXEDIR 指向的目录

返回的信息包含：可执行文件绝对路径、版本字符串（尽力探测）、家族(g16/g09)、
安装根目录、可执行文件目录、以及建议注入的运行环境变量（GAUSS_EXEDIR / g16root 等）。
"""

from __future__ import annotations

import os
import shutil
import subprocess
import platform
import struct
from typing import Optional, Dict, Any, List

# 各平台常见安装根目录
COMMON_DIRS: Dict[str, List[str]] = {
    "Windows": [
        r"C:\G16W", r"C:\G09W",
        r"D:\Gaussian16\G16W", r"D:\Gaussian09\G09W",
        r"E:\Gaussian16\G16W", r"E:\Gaussian09\G09W",
        r"C:\Gaussian16\G16W", r"C:\Gaussian09\G09W",
        r"C:\Program Files\Gaussian\G16W",
        r"C:\Program Files\Gaussian\G09W",
        r"C:\gaussian\g16w", r"C:\gaussian\g09w",
    ],
    "Linux": [
        "/opt/gaussian/g16", "/opt/gaussian/g09",
        "/opt/g16", "/opt/g09",
        "/usr/local/gaussian/g16", "/usr/local/gaussian/g09",
    ],
    "Darwin": [
        "/Applications/Gaussian/g16", "/usr/local/gaussian/g16",
    ],
}

# 各平台可执行文件候选名
EXE_NAMES: Dict[str, List[str]] = {
    "Windows": ["g16.exe", "g09.exe", "g16", "g09"],
    "Linux": ["g16", "g09"],
    "Darwin": ["g16", "g09"],
}


def _which(names: List[str]) -> List[str]:
    found = []
    for n in names:
        p = shutil.which(n)
        if p:
            found.append(p)
    return found


def _probe_version(exe: str) -> Optional[str]:
    """尽力探测版本字符串：依次尝试 --version / -v / ? 参数。"""
    for flag in ("--version", "-v", "?"):
        try:
            out = subprocess.run(
                [exe, flag], capture_output=True, text=True, timeout=20
            )
            txt = (out.stdout + out.stderr).strip()
            if txt:
                return txt
        except Exception:
            continue
    return None


def _family_from_path(exe: str) -> str:
    low = exe.lower().replace("\\", "/")
    if "g16" in low:
        return "g16"
    if "g09" in low:
        return "g09"
    return "unknown"


def _detect_arch(exe: str) -> str:
    """
    读取可执行文件头判断架构：Windows 读 PE 头，其他平台按可执行文件大小特征兜底。
    返回 "x86"(32 位) / "x64"(64 位) / "unknown"。
    用途：32 位 Gaussian 无法分配大内存（%mem 须 <= ~1.5GB），据此自动给保守建议。
    """
    try:
        with open(exe, "rb") as f:
            head = f.read(4096)
    except Exception:
        return "unknown"
    # PE 格式（Windows）
    if head[:2] == b"MZ":
        try:
            e_lfanew = struct.unpack_from("<I", head, 0x3C)[0]
            if e_lfanew + 6 <= len(head) and head[e_lfanew:e_lfanew + 4] == b"PE\x00\x00":
                machine = struct.unpack_from("<H", head, e_lfanew + 4)[0]
                # 0x14c=x86, 0x8664=AMD64, 0x1c0=ARM64, 0x200=IA64
                return "x86" if machine in (0x14C,) else (
                    "x64" if machine in (0x8664, 0x200) else "unknown")
        except Exception:
            return "unknown"
    # ELF（Linux/macOS）：读取 ELF 类别字节，1=32 位，2=64 位
    if head[:4] == b"\x7fELF":
        try:
            return "x86" if head[4] == 1 else "x64"
        except Exception:
            return "unknown"
    return "unknown"


def _build_env(family: str, exedir: str, root: str) -> Dict[str, str]:
    """构造 Gaussian 运行所需的环境变量（尽力兼容）。"""
    env = {"GAUSS_EXEDIR": exedir}
    if family == "g16":
        env["g16root"] = root
    elif family == "g09":
        env["g09root"] = root
    return env


def find_gaussian(exe: Optional[str] = None) -> Dict[str, Any]:
    """
    探测本机 Gaussian 安装。

    返回 dict：
        found     : bool   是否找到
        exe       : str|None 可执行文件绝对路径
        version   : str|None 版本字符串
        family    : str|None "g16" / "g09" / "unknown"
        arch      : str|None "x86"(32 位) / "x64" / "unknown"
        root      : str|None 安装根目录
        exedir    : str|None 可执行文件所在目录
        env       : dict    建议注入的运行环境变量
        platform  : str     当前平台
        searched  : list    已搜索的目录列表
    """
    sysname = platform.system()  # 'Windows' / 'Linux' / 'Darwin'
    result: Dict[str, Any] = {
        "found": False,
        "exe": None,
        "version": None,
        "family": None,
        "arch": "unknown",
        "root": None,
        "exedir": None,
        "env": {},
        "platform": sysname,
        "searched": [],
    }
    names = EXE_NAMES.get(sysname, ["g16", "g09"])
    candidates: List[str] = []

    # 1) 显式传入
    if exe:
        candidates.append(exe)
    # 2) PATH
    candidates.extend(_which(names))
    # 3) 常见目录
    for d in COMMON_DIRS.get(sysname, []):
        result["searched"].append(d)
        if os.path.isdir(d):
            for n in names:
                p = os.path.join(d, n)
                if os.path.isfile(p):
                    candidates.append(p)
    # 4) 环境变量 GAUSS_EXEDIR
    gx = os.environ.get("GAUSS_EXEDIR")
    if gx and os.path.isdir(gx):
        for n in names:
            p = os.path.join(gx, n)
            if os.path.isfile(p):
                candidates.append(p)

    for c in candidates:
        if not (c and os.path.isfile(c)):
            continue
        absp = os.path.abspath(c)
        fam = _family_from_path(absp)
        ver = _probe_version(absp)
        arch = _detect_arch(absp)
        exedir = os.path.dirname(absp)
        # root：安装根目录。Windows 下令 g16.exe/g09.exe 位于 G16W/G09W/，
        #       其上一级即为 g16root/g09root（如 D:\Gaussian09）；
        #       Linux 下位于 g16root/g16/，上一级即 g16root。两者统一取 dirname。
        root = os.path.dirname(exedir)
        env = _build_env(fam, exedir, root)
        result.update(
            found=True, exe=absp, version=ver, arch=arch,
            family=fam, root=root, exedir=exedir, env=env,
        )
        return result

    return result


def require_gaussian(exe: Optional[str] = None) -> Dict[str, Any]:
    """
    探测 Gaussian；找不到则抛出清晰的异常（含已搜索路径）。
    成功时返回与 find_gaussian 相同的 dict。
    """
    info = find_gaussian(exe)
    if not info["found"]:
        searched = "\n   - ".join([""] + info["searched"] + ["(系统 PATH)", "(环境变量 GAUSS_EXEDIR)"])
        raise FileNotFoundError(
            "未在本机找到 Gaussian 安装。已搜索："
            f"{searched}\n请确认已安装 Gaussian，或显式传入 exe 路径，"
            "或设置环境变量 GAUSS_EXEDIR 指向 Gaussian 可执行文件所在目录。"
        )
    return info
