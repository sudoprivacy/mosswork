# GaussianAutomation —— Python 调用 Gaussian 的常用工具包

> 当前版本：**v1.6.0**

### v1.6.0 新增
- **计算方法 / 基组推荐引擎（`method_selector` 模块）**：给「体系大小 + 分子类型 + 计算任务 + 本机资源」，
  自动推荐 Gaussian 的方法与基组，直接产出可写进 `.gjf` 的路由行。
  - `recommend_method(n_atoms=..., molecule=..., task=..., quality=...)` 返回推荐字典
    （`mb` / `route` / `why` / `alternatives` / `warnings` / `follow_up` 等）
  - `detect_molecule_class(atoms, charge, mult)` 由元素组成自动判别分子类型
    （organic / tm_complex / heavy_element / main_group / cluster / biopolymer）与修饰标记
    （anion / cation / open_shell / heavy_halogen / large）
  - `recommend_for_xyz("mol.xyz", task="uvvis")` 直接从结构文件推荐
  - `explain_recommendation(rec)` 输出人类可读的完整解释；`task_guide()` / `recommendation_matrix()`
    输出速查表
  - 资源感知：按原子数分档（tiny→huge）× Gaussian 位数自动降配基组；32 位环境下
    6-31G(d) 以下的组合会被拦住并提示改用半经验 / ONIOM / 双层方案
  - 规则：负电荷与富电子自动补弥散函数；开壳层自动加 U 前缀；金属自动加 `SCF=XQC`；
    泛函自带色散时不重复叠加 Grimme；可一键追加 `SCRF=(PCM,Solvent=...)`


纯标准库实现，无需安装任何第三方依赖。适用于 Gaussian 计算自动化的常规场景：
**生成输入文件 → 调用 Gaussian 执行 → 解析输出结果**。

### v1.3.0 新增
- **CPU 逻辑核数自动解析（`cpu` 模块）**：`logical_cpu_count()` 探测本机逻辑核数；
  `resolve_nprocs()` 把「用户输入 / gjf 已有 `%nprocs=` `%nprocshared=`」解析为最终核数，
  支持**绝对核数(12)、百分比(75%)、小数比例(0.75)** 三种写法，并自动约束到 `[1, 逻辑核数]`；
  `apply_nprocs_to_gjf()` 在 gjf 的 Link 0 区写入/更新核数指令。
  `run_gaussian()` / `run_and_save()` 新增 `nprocs=` 参数：传入后解析结果以 `%nprocshared=`
  注入运行副本（覆盖 gjf 原值）。v1.3.0 起不再对 32 位做核数封顶，核数由调用者按内存余量自行决定（32 位的真正瓶颈是 `%mem`，不是核数）。

### v1.4.0 新增
- **计算类型配方目录（`recipes` 模块）**：`CASE_CATALOG` 汇总 17 个常用计算配方
  （opt / freq / ts / tddft / esp / irc / nmr / scan / mp2 / nbo / pcm / raman / bsse / polar / cis / stable / tdopt），
  每个含路由模板、用途、本机 g09 D.01 可用性、关键坑、对应解析字段与特殊步骤标记；
  `case_route(name, mb)` 按方法/基组渲染路由，`catalog_summary()` 输出速查表。
  第二批 12 案例的 `examples/cases2.py` 即全部由 `case_route()` 取路由，避免漂移。
- **解析器 PCM 修复**：本机 g09 D.01 默认 PCM 不打印 `Free energy of solvation`；新增
  `pcm_active` 字段标记溶剂化是否启用，并新增 `solvation_free_energy(pcm_log, gas_log)` 用
  「溶液 SCF − 气相 SCF」相减求 ΔG_solv（g16 等会直接打印该值，自动走另一分支）。
- **解析器回归测试**：新增 `examples/validate_cases2.py`，对 12 个真实 `.log` 断言关键字段
  非 None，无需 Gaussian 即可运行（已 12/12 通过）。

### v1.1.0 新增
- **自动探测本机 Gaussian**：`run_gaussian(gjf)`、`run_and_save(gjf)` 在 `g16=None` 时
  自动搜索 PATH、常见安装目录（Windows `C:\G16W`、Linux `/opt/gaussian/g16` 等）与
  环境变量 `GAUSS_EXEDIR`，识别 g16/g09 并构造兼容运行环境（`detect.find_gaussian`）。
- **.log / .chk 结果生成与保存**：新增 `run_and_save()`，一键运行并把 `.log` 与 `.chk`
  归档到指定目录；可通过 `chk=` 显式命名（若 gjf 未写 `%chk=` 会自动注入）；
  可选 `make_fchk=True` 调用 `formchk` 生成可读的 `.fchk`。

---

## 目录结构

```
GaussianAutomation/
├── gaussian_automation/        # 工具包本体（可直接 import）
│   ├── __init__.py
│   ├── gjf_writer.py           # 生成 .gjf 输入文件
│   ├── runner.py               # 调用 g16/g09 执行计算 + 结果保存
│   ├── log_parser.py           # 解析 .log 输出文件
│   ├── detect.py               # 本机 Gaussian 安装探测与版本兼容
│   ├── cpu.py                  # CPU 逻辑核数探测 + %nprocs 解析与注入（v1.3.0）
│   ├── recipes.py              # 计算类型配方目录 CASE_CATALOG（v1.5.0）
│   ├── method_selector.py      # 方法/基组推荐引擎（v1.6.0）
│   └── utils.py                # XYZ 读写、元素互转
├── examples/
│   ├── demo.py                 # 完整流程示例
│   ├── cpu_nprocs_demo.py      # CPU 核数自动解析示例（v1.3.0）
│   ├── method_selector_demo.py # 方法/基组推荐示例（v1.6.0，纯逻辑无需 Gaussian）
│   ├── validate_method_selector.py  # 推荐逻辑回归 + 可选真机关键字验证（v1.6.0）
│   ├── cases2.py               # 第二批 12 案例一键编排（路由取自 recipes）
│   ├── validate_cases2.py      # 解析器回归验证（对 12 个真实 .log 断言字段，无需 Gaussian）
│   ├── sample_water.log        # 示例输出（供无 Gaussian 时测试解析）
│   └── water.gjf / water.xyz   # 运行 demo 后生成的文件
└── README.md
```

---

## 快速开始

### 1. 生成输入文件

```python
from gaussian_automation import write_gjf

atoms = ["O", "H", "H"]
coords = [
    [0.0, 0.0,  0.1173],
    [0.0, 0.75545, -0.4692],
    [0.0, -0.75545, -0.4692],
]

write_gjf(
    path="water.gjf",
    atoms=atoms,
    coords=coords,
    charge=0, mult=1,
    route="# B3LYP/6-31G(d) Opt Freq",
    mem="2GB", nproc=8, chk="water.chk",
)
```

也可直接从 XYZ 文件生成：

```python
from gaussian_automation import write_gjf_from_xyz
write_gjf_from_xyz("water.gjf", "water.xyz",
                   route="# B3LYP/6-31G(d) Opt Freq")
```

### 2. 运行计算

```python
from gaussian_automation import run_gaussian

# 不传 g16 → 自动探测本机 Gaussian（g16/g09 均可，跨版本兼容）
log_path, rc = run_gaussian("water.gjf")
print("返回码:", rc, "输出:", log_path)

# 也可显式指定可执行文件（Windows 示例）
log_path, rc = run_gaussian("water.gjf", g16=r"C:\G16W\g16.exe")
```

批量运行（顺序执行）：

```python
from gaussian_automation import run_gaussian_batch
results = run_gaussian_batch(["a.gjf", "b.gjf", "c.gjf"])
```

> 自动探测失败时会抛出清晰异常，列出已搜索的 PATH、常见安装目录与环境变量 `GAUSS_EXEDIR`。

### 2.1 运行并保存结果（.log / .chk / .fchk）

```python
from gaussian_automation import run_and_save

res = run_and_save(
    "water.gjf",
    out_dir="results",        # 结果保存到 results/ 目录
    chk="water",              # 指定 chk 基名（若 gjf 未写 %chk= 会自动注入）
    make_fchk=True,           # 额外生成可读的 results/water.fchk
)
print(res["log"])    # results/water.log
print(res["chk"])    # results/water.chk
print(res["fchk"])   # results/water.fchk
print(res["ok"])     # 是否返回码 0 且正常终止
```

`.chk` 由 Gaussian 在 `%chk=` 指定时生成（二进制检查点文件）；`run_and_save` 会把它从
工作目录复制到 `out_dir`，并可选地 `formchk` 转成文本 `.fchk` 便于后处理 / 查看。

### 2.2 CPU 核数自动解析（v1.3.0）

不想手算核数？直接用 `nprocs=` 让工具解析。支持三种写法：绝对核数 `12`、百分比 `"75%"`、
小数比例 `0.75`（0~1 视为比例）。gjf 首行写 `%nprocs=8`（或 `%nprocshared=8`）也会被自动识别；
运行副本统一归一化为 `%nprocshared=`。v1.3.0 起不再对 32 位做核数封顶（32 位的瓶颈是内存而非核数）。

```python
from gaussian_automation import logical_cpu_count, resolve_nprocs, run_and_save

print(logical_cpu_count())                 # 本机逻辑核数（含超线程），如 16
print(resolve_nprocs(user_input="75%"))     # 12（= 16 * 75%）
print(resolve_nprocs(user_input=0.75))     # 12
print(resolve_nprocs(gjf_path="job.gjf"))  # gjf 写了 %nprocs=8 -> 8

# 运行时直接指定（推荐）
res = run_and_save("water.gjf", out_dir="results", nprocs="50%")
```

优先级：**`nprocs=` 显式输入 > gjf 已有指令 > 默认（全部逻辑核）**；越界值自动夹紧到 `[1, 逻辑核数]`。

### 2.3 计算方法 / 基组推荐（v1.6.0）

不想手工挑泛函和基组？给三个输入即可：

```python
from gaussian_automation import recommend_method, explain_recommendation

r = recommend_method(n_atoms=24, molecule="organic", task="opt_freq", quality="standard")
print(r["mb"])                    # wB97XD/def2SVP
print(r["route"])                 # # wB97XD/def2SVP Opt Freq
print(explain_recommendation(r))  # 完整解释：理由 / 警告 / 备选 / 后续步骤

# 从 xyz 自动取原子数与元素组成
r2 = recommend_for_xyz("mol.xyz", task="uvvis", solvent="Water")

# 与 recipes 联动：把推荐的方法/基组填进既有配方模板
from gaussian_automation import case_route
print(case_route("nmr", mb=r2["mb"]))
```

输入维度：

| 维度 | 取值 |
|------|------|
| 分子类型 `molecule` | `organic` / `tm_complex` / `heavy_element` / `main_group` / `cluster` / `biopolymer` / `general`（不给则由元素自动判别） |
| 任务 `task` | `opt` `opt_freq` `freq` `ir` `raman` `sp` `thermo` `ts` `barrier` `weak` `conformer` `uvvis` `nmr` `nmr_j` `epr` `spin_state` `nlo` `optrot` `anharmonic`（支持中文别名，见 `list_tasks()`） |
| 精度 `quality` | `fast` / `standard` / `accurate` |
| 环境 `arch` | `x86`（32 位 g09，≤~1.5GB）/ `x64`；不给则自动探测 |

推荐器会自动处理：负电荷补弥散函数、开壳层加 U 前缀、金属加 `SCF=XQC`、
自带色散的泛函不再叠加 Grimme、指定溶剂时追加 `SCRF=(PCM,Solvent=...)`，
并按「原子数 × Gaussian 位数」的预算自动降配基组（超出预算会带上 warning 说明）。

### 3. 解析输出

```python
from gaussian_automation import parse_log, summarize

data = parse_log("water.log")
print(data["scf_energy"])        # SCF 能量 (Hartree)
print(data["converged"])         # 优化是否收敛
print(data["frequencies"])       # 振动频率列表
print(data["sum_free_energy"])   # 含热校正吉布斯自由能
print(data["dipole"])            # 偶极矩
print(data["homo_lumo"])         # (HOMO, LUMO)

# 或直接打印一段人类可读摘要
print(summarize("water.log"))
```

---

## parse_log 返回字段一览

| 字段 | 含义 |
|------|------|
| `normal_termination` / `error_termination` | 是否“正常 / 异常终止” |
| `error_message` | 末条错误信息 |
| `scf_energy` / `scf_method` | 最终 SCF 能量 (Hartree) 及方法名 |
| `converged` | 几何优化是否收敛 |
| `frequencies` / `intensities` | 振动频率 (cm⁻¹) / 红外强度 (km/mol) |
| `optimized_geometry` | `{"atoms":[...], "coords":[[x,y,z],...]}` |
| `zero_point` / `thermal_energy` / `thermal_enthalpy` / `thermal_free_energy` | 热力学修正量 |
| `sum_energy` / `sum_enthalpy` / `sum_free_energy` | 含热校正的总能量/焓/自由能 |
| `dipole` | `{"x","y","z","tot"}` (Debye) |
| `homo_lumo` | `(HOMO, LUMO)` 能量 (Hartree，闭壳层 alpha) |
| `nmr_shieldings` | `[(symbol, ppm), ...]` NMR 各向同性屏蔽常数 (GIAO) |
| `scan_results` | `[(step, 坐标值, 能量), ...]` PES 扫描（Opt=ModRedundant） |
| `mp2_correlation` | MP2 相关能 E2 (Hartree) |
| `mp2_total` | MP2 总能量 EUMP2 (Hartree) |
| `cis_energy` | CIS 总能量 E(CIS) (Hartree) |
| `pcm_active` | `True` 表示作业使用了 PCM/SCRF 隐式溶剂化 |
| `pcm_solvation_free_energy` | PCM 溶剂化自由能（g16 等会直接打印，则非 None；**g09 D.01 默认 PCM 不打印**，需 `solvation_free_energy(pcm_log, gas_log)` 由「溶液 SCF − 气相 SCF」相减得到） |
| `solvation_free_energy(pcm_log, gas_log)` | 独立函数：返回 ΔG_solv = E(溶液) − E(气相)（Hartree，负值放能） |
| `raman_activities` | `[float, ...]` Raman 散射活性 |
| `polarizability` | `[xx, xy, xz, yy, yz, zz]` 极化率张量 |
| `isotropic_polarizability` | 各向同性极化率 (Bohr³) |
| `stability` | `"stable"` / `"unstable"` 波函数稳定性 |
| `nbo_charges` | `[(symbol, charge), ...]` NBO 自然电荷 |
| `bsse_corrected_energy` | Counterpoise 校正后能量 (Hartree) |
| `complexation_energy_corrected` | 校正后复合能 (kcal/mol) |

> 所有字段均为“尽力而为”解析：信息缺失时对应字段为 `None`。
>
> **第二批 12 案例**（v1.3.0 扩展）：本包还验证了 IRC / NMR=GIAO / PES 扫描 / MP2 / NBO / PCM / Freq=Raman / Counterpoise BSSE / Polar / CIS / Stable=Opt / TD Opt 共 12 项能力，均在本机 32 位 g09（`%mem=1000MB`、`nprocs=12` 指令以共享内存方式提交）真实跑通。注意：`%nprocshared=12` 虽被正确注入并回显，但该 32 位构建的 SMP 并行实际无效（仅约 1 有效核），"跑通"指作业正常收敛、非指多核加速。详见技能 `SKILL.md` 的「第二批 12 个综合实战案例」与坑 1 补注。

---

## 在无 Gaussian 的环境先体验解析

`examples/demo.py` 默认不会真正调用 Gaussian，而是直接解析内置的
`examples/sample_water.log`：

```bash
cd GaussianAutomation
python examples/demo.py
```

---

## 常见扩展思路

- **批量扫描**：遍历 XYZ / SMILES 列表 → 批量生成 gjf → `run_gaussian_batch` → 汇总 `parse_log`。
- **失败重试 / 作业监控**：`run_gaussian` 的返回值 `returncode` 可驱动重试逻辑。
- **自定义路由**：把 `route` 参数化（方法/基组/任务类型），结合配置文件做扫参。
- **集群提交**：把 `run_gaussian` 换成提交到 SLURM/PBS 的封装即可复用整个解析层。
