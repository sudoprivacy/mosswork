"""
计算方法 / 基组推荐引擎（method_selector）
=========================================

根据「体系大小 + 分子类型 + 计算任务 + 本机资源」自动推荐 Gaussian 的
方法（method）、基组（basis）与附加关键字，直接产出可写进 .gjf 的路由行。

解决的问题
----------
Gaussian 有上百种方法 / 上千种基组，手工挑选容易出错且不统一。本模块把
常见组合沉淀成一份**可审计的推荐矩阵**，输入你手头的真实约束，输出：

    "B3LYP/6-31G(d) Opt Freq EmpiricalDispersion=GD3BJ"

以及为什么这么选、代价如何、备选方案是什么、后续该做什么。

三个输入维度
------------
1. **分子类型**（可自动判别）：由元素组成 / 电荷 / 自旋多重度推断
   - ``organic`` 有机小分子（C/H/N/O/F/S/Cl/P 等，无金属）
   - ``tm_complex`` 过渡金属配合物
   - ``heavy_element`` 含重元素（Br/I 及 Z≥36），通常用 ECP
   - ``main_group`` 主族无机 / 缺电子或超价体系
   - ``cluster`` 团簇（水团簇、离子簇等靠非共价维系的聚集体）
   - ``biopolymer`` 生物大分子 / 多肽（通常 >150 原子）
   - ``general`` 未指定
   另有**修饰标记**（不互斥，由体系自动判定）：
   ``anion``（负电荷→需弥散函数）、``cation``、``open_shell``（mult≠1→U 前缀）、
   ``heavy_halogen``、``large``/``very_large``（尺寸）。

2. **计算任务**（task）：opt / opt_freq / freq / sp / thermo / ts / barrier /
   weak / conformer / uvvis / ir / raman / nmr / nmr_j / epr / spin_state /
   nlo / optrot / anharmonic 等。

3. **精度档位**（quality）：``fast`` / ``standard`` / ``accurate``。

资源约束（重要）
---------------
本机 32 位 g09（`detect.find_gaussian()["arch"] == "x86"`）的硬约束是 **%mem ≤ ~1.5GB**，
因此推荐器会按体系原子数**自动降配基组**，并在无法安全运行时给出 warning
（建议改用半经验 PM6 或 ONIOM 分层）。详见 ``_RESOURCE_PROFILES``。

典型用法
--------
    from gaussian_automation import recommend_method, explain_recommendation

    r = recommend_method(n_atoms=24, molecule="organic", task="opt_freq")
    print(r["mb"])          # "wB97XD/def2SVP"
    print(r["route"])       # "# wB97XD/def2SVP Opt Freq"
    print(explain_recommendation(r))

    # 直接从 xyz 自动推断体系规模与分子类型
    r = recommend_for_xyz("mol.xyz", task="uvvis", solvent="Water")

    # 与 recipes 配方联动：把推荐的方法/基组填进既有路由模板
    from gaussian_automation import case_route
    print(case_route("nmr", mb=r["mb"]))   # "# B3LYP/6-311+G(d,p) NMR=GIAO"
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .utils import SYMBOL_TO_NUMBER, symbol_to_number  # noqa: F401  (便于外部复用)


# ---------------------------------------------------------------------------
# 1. 方法属性表
# ---------------------------------------------------------------------------
# disp: 是否自带色散校正；None 表示需要外加 Grimme 校正
# kind: 用于展示与判断是否必须 Int=UltraFine 等
# g09_ok: 在本机 Gaussian 09 Rev D.01（32 位）是否可用；False 表示 G16-only
METHOD_INFO: Dict[str, Dict[str, Any]] = {
    "HF":         {"kind": "波函数(HF)",       "disp": None,       "g09_ok": True,  "note": ""},
    "MP2":        {"kind": "波函数(MP2)",      "disp": None,       "g09_ok": True,  "note": "对弥散/BSSE 敏感，常用 aug-cc-pVTZ + Counterpoise。"},
    "CCSD(T)":    {"kind": "波函数(CC)",       "disp": None,       "g09_ok": True,  "note": "极小体系(<10 重?)才可行；O(N^7)。"},
    "B3LYP":      {"kind": "杂化 GGA",         "disp": None,       "g09_ok": True,  "note": "通用稳妥；缺色散，非共价体系须加 GD3BJ。"},
    "PBE0":       {"kind": "杂化 GGA",         "disp": None,       "g09_ok": True,  "route_name": "PBE1PBE", "note": "过渡金属几何好；⚠️ 部分 g09 构建不识别 PBE0 关键字，路由会被改写成同义词 PBE1PBE。"},
    "TPSSh":      {"kind": "meta 杂化",        "disp": None,       "g09_ok": True,  "note": "过渡金属自旋态分裂的常用选择。"},
    "M062X":      {"kind": "meta 杂化(54%HF)", "disp": "partial",  "g09_ok": True,  "note": "反应能垒/热化学好；已含部分中程相关，通常不再叠加 GD3BJ。必须 Int=UltraFine。"},
    "wB97XD":     {"kind": "范围分离杂化",     "disp": "builtin",  "g09_ok": True,  "note": "自带 D2 色散，通用性最好的默认推荐之一。"},
    "CAM-B3LYP":  {"kind": "范围分离杂化",     "disp": None,       "g09_ok": True,  "note": "长程交换校正到位，电荷转移激发不会被严重低估。"},
    "B2PLYP":     {"kind": "双杂化",           "disp": "builtin",  "g09_ok": True,  "note": "需 MP2 相关步，成本高于普通杂化。"},
    # 注（本机 g09 D.01 IA32 实测）：APFD 可用（rc=0），PM7 不可用（rc=2057），
    # PBE0 关键字不被识别 → 必须写 PBE1PBE（见 route_name）。
    "APFD":       {"kind": "杂化 GGA",         "disp": "builtin",  "g09_ok": True,  "note": "自带色散；本机 g09 D.01 实测可用。"},
    "PM6":        {"kind": "半经验",           "disp": None,       "g09_ok": True,  "note": "超大体系统筛/初猜几何的唯一现实选择。"},
    "PM7":        {"kind": "半经验",           "disp": None,       "g09_ok": False, "note": "Gaussian 16 起才有；g09 报关键字错误。"},
    "CBS-QB3":    {"kind": "复合方法",         "disp": None,       "g09_ok": True,  "note": "含自动优化+频率，不接受额外 Opt/Freq 模型；体系需小(<~15 原子)且内存充足。"},
    "G4":         {"kind": "复合方法",         "disp": None,       "g09_ok": True,  "note": "比 CBS-QB3 更准也更贵；32 位内存很容易不够。"},
}


# ---------------------------------------------------------------------------
# 2. 基组阶梯与成本
# ---------------------------------------------------------------------------
# 越靠后越贵；索引用于「按资源预算降配」时做比较。
BASIS_LADDER: List[str] = [
    "STO-3G",            # 0  极小（仅教学/定性）
    "3-21G",             # 1  极小旧款双-zeta
    "6-31G",             # 2  无极化，仅超大体系兜底
    "6-31G(d)",          # 3  有机几何优化的事实标准
    "6-31G(d,p)",        # 4  含 H 极化
    "def2SVP",           # 5  现代 SV(P)，≈6-31G(d,p) 成本而质量更好；重元素自带 ECP
    "6-311G(d,p)",       # 6  三-zeta
    "6-311+G(d,p)",      # 7  三-zeta + 弥散（阴离子/激发表标配）
    "def2TZVP",          # 8  现代 TZVP，高精度单点主力
    "6-311++G(2d,p)",    # 9  高精度极化/弥散
    "aug-cc-pVDZ",       # 10 DZ + 完整弥散
    "aug-cc-pVTZ",       # 11 TZ + 完整弥散，很贵
    "def2QZVP",          # 12 QZ，很贵
]

_BASIS_RANK = {name: i for i, name in enumerate(BASIS_LADDER)}

# 不在阶梯内的特殊基组（便于 rank 计算时给出保守估计）
_SPECIAL_BASIS_RANK = {
    "LANL2DZ": 3,     # ECP 双-zeta，便宜但粗糙
    "SDD": 3,
    "EPR-III": 8,     # EPR 专用（赝势+丰富极化），中等偏贵
    "EPR-II": 7,
}


def _basis_rank(basis: str) -> int:
    """返回基组成本序号（越大越贵）。未知基组返回 -1。"""
    return _BASIS_RANK.get(basis, _SPECIAL_BASIS_RANK.get(basis, -1))


def _cheaper_or_equal(basis: str, max_rank: int) -> bool:
    r = _basis_rank(basis)
    return r >= 0 and r <= max_rank


# 负电荷 / 富电子 / 激发态等对弥散函数有硬需求时的升级映射
_DIFFUSE_UPGRADE: Dict[str, str] = {
    "STO-3G": "6-31+G",
    "3-21G": "6-31+G",
    "6-31G": "6-31+G",
    "6-31G(d)": "6-31+G(d,p)",
    "6-31G(d,p)": "6-31+G(d,p)",
    "def2SVP": "aug-cc-pVDZ",
    "def2SVPP": "aug-cc-pVDZ",
    "6-311G(d,p)": "6-311++G(d,p)",
    "6-311+G(d,p)": "6-311+G(d,p)",
    "def2TZVP": "aug-cc-pVTZ",
    "6-311++G(2d,p)": "6-311++G(2d,p)",
    "aug-cc-pVDZ": "aug-cc-pVDZ",
    "aug-cc-pVTZ": "aug-cc-pVTZ",
    "def2QZVP": "def2QZVP",
    "LANL2DZ": "LANL2DZ",
    "SDD": "SDD",
    "EPR-II": "EPR-II",
    "EPR-III": "EPR-III",
}


# ---------------------------------------------------------------------------
# 3. 分子类型自动判别
# ---------------------------------------------------------------------------
_TRANSITION_METALS = set(range(21, 31)) | set(range(39, 49)) | set(range(72, 81))
_LANTHANIDES = set(range(57, 72))
_HEAVY_Z = 36            # Z ≥ 36（Kr 及以后）通常需要 ECP
_HEAVY_HALOGENS = {35, 53}   # Br, I

MOLECULE_LABELS: Dict[str, str] = {
    "organic": "有机小分子（无金属）",
    "tm_complex": "过渡金属配合物",
    "heavy_element": "含重元素体系（需 ECP）",
    "main_group": "主族 / 缺电子超价体系",
    "cluster": "团簇 / 非共价聚集体",
    "biopolymer": "生物大分子 / 长链",
    "general": "未分类（通用）",
}

MOLECULE_ALIASES: Dict[str, str] = {
    "有机": "organic", "有机物": "organic", "小分子": "organic",
    "metal": "tm_complex", "tm": "tm_complex", "organometallic": "tm_complex",
    "配合物": "tm_complex", "金属配合物": "tm_complex", "过渡金属": "tm_complex",
    "heavy": "heavy_element", "重元素": "heavy_element", "ecd-bearing": "heavy_element",
    "main_group": "main_group", "主族": "main_group", "无机": "main_group",
    "cluster": "cluster", "团簇": "cluster", "水团簇": "cluster",
    "biopolymer": "biopolymer", "protein": "biopolymer", "多肽": "biopolymer",
    "蛋白": "biopolymer", "生物大分子": "biopolymer",
    "general": "general", "auto": "general", "通用": "general",
}


def _normalize_molecule(molecule: Optional[str]) -> Optional[str]:
    if not molecule:
        return None
    key = molecule.strip().lower()
    return MOLECULE_ALIASES.get(key, MOLECULE_ALIASES.get(molecule.strip(), key))


def detect_molecule_class(atoms: Sequence[str], charge: int = 0,
                          mult: int = 1) -> Dict[str, Any]:
    """
    由元素组成推断分子类型（基础类别 + 修饰标记）。

    Parameters
    ----------
    atoms : 元素符号序列
    charge, mult : 电荷与自旋多重度（用于 open_shell / anion / cation 标记）

    Returns
    -------
    dict: {"class", "label", "flags", "elements", "n_atoms", "n_heavy", "evidence"}
    """
    syms = [str(a).strip().capitalize() for a in atoms]
    nums: List[int] = []
    for s in syms:
        try:
            nums.append(symbol_to_number(s))
        except ValueError:
            nums.append(0)

    flags: List[str] = []
    evidence: List[str] = []

    has_tm = any(z in _TRANSITION_METALS or z in _LANTHANIDES for z in nums)
    has_heavy = any(z >= _HEAVY_Z for z in nums)
    has_heavy_halogen = any(z in _HEAVY_HALOGENS for z in nums)
    only_organics = all((z in (1, 5, 6, 7, 8, 9, 14, 15, 16, 17, 33, 34)) for z in nums if z)

    if has_tm:
        base = "tm_complex"
        evidence.append("检测到过渡金属/镧系元素")
    elif has_heavy or has_heavy_halogen:
        base = "heavy_element"
        evidence.append("检测到 Z≥36 的重元素或 Br/I，通常用 def2 系列（自带 ECP）或 LANL2DZ/SDD")
    else:
        base = "organic"
        if only_organics:
            evidence.append("仅含 H/B/C/N/O/F/Si/P/S/Cl/As/Se 等有机常见元素")
        else:
            evidence.append("以轻元素为主")

    if charge < 0:
        flags.append("anion")
        evidence.append(f"负电荷 ({charge})，阴离子/富电子体系需要弥散函数")
    elif charge > 0:
        flags.append("cation")
        evidence.append(f"正电荷 ({charge})，缺电子体系建议带弥散函数")
    if mult != 1:
        flags.append("open_shell")
        evidence.append(f"自旋多重度 mult={mult}（{'单自由基' if mult==2 else '多重态'}），方法需加 U/RO 前缀")
    if has_heavy_halogen:
        flags.append("heavy_halogen")
    n_atoms = len(syms)
    if n_atoms > 120:
        flags.append("very_large")
    elif n_atoms > 60:
        flags.append("large")

    n_heavy = sum(1 for z in nums if z > 1)
    return {
        "class": base,
        "label": MOLECULE_LABELS[base],
        "flags": flags,
        "elements": sorted(set(syms)),
        "n_atoms": n_atoms,
        "n_heavy": n_heavy,
        "evidence": evidence,
    }


# ---------------------------------------------------------------------------
# 4. 尺寸档位与资源预算
# ---------------------------------------------------------------------------
SIZE_TIERS: List[Tuple[str, int, str]] = [
    ("tiny", 10, "极小体系（≤10 原子）"),
    ("small", 30, "小体系（11–30 原子）"),
    ("medium", 60, "中等体系（31–60 原子）"),
    ("large", 120, "大体系（61–120 原子）"),
    ("very_large", 250, "超大体系（121–250 原子）"),
]


def size_tier(n_atoms: int) -> str:
    """按原子数返回尺寸档位名。"""
    for name, hi, _ in SIZE_TIERS:
        if n_atoms <= hi:
            return name
    return "huge"


def size_tier_label(tier: str) -> str:
    for name, _, label in SIZE_TIERS:
        if name == tier:
            return label
    return "巨型体系（>250 原子）"


# 资源画像：给定 Gaussian 位数，按尺寸档给出「基组阶梯索引上限」与提示
_RESOURCE_PROFILES: Dict[str, Dict[str, Any]] = {
    # 32 位 g09（本机）：瓶颈永远是 %mem（≤~1.5GB），不是核数
    "x86": {
        "label": "32 位 Gaussian（如 g09 IA32），%mem ≤ ~1500MB",
        "mem": "1500MB",
        "max_atoms_soft": 60,
        "budget": {
            "tiny": 7,          # 6-311+G(d,p)
            "small": 5,         # def2SVP
            "medium": 3,        # 6-31G(d)
            "large": 2,         # 6-31G（无极化，仅应急）
            "very_large": 0,    # 半经验 / ONIOM 兜底
            "huge": 0,
        },
        "nproc_hint": "本机构建的 SMP 并行实测无效，nprocs 只作指令传递；别指望靠核数提速",
    },
    # 64 位 g16 等常规机器
    "x64": {
        "label": "64 位 Gaussian（常规内存）",
        "mem": "4GB",
        "max_atoms_soft": 250,
        "budget": {
            "tiny": 11,         # aug-cc-pVTZ
            "small": 10,        # aug-cc-pVDZ
            "medium": 8,        # def2TZVP
            "large": 5,         # def2SVP
            "very_large": 4,    # 6-31G(d,p)
            "huge": 3,          # 6-31G(d)
        },
        "nproc_hint": "可用 nprocs='75%' 之类按比例占核",
    },
}


def _auto_arch() -> str:
    """尝试自动探测本机 Gaussian 架构；失败则假定 64 位。"""
    try:
        from .detect import find_gaussian
        info = find_gaussian()
        if info.get("found"):
            return info.get("arch") or "x64"
    except Exception:
        pass
    return "x64"


# ---------------------------------------------------------------------------
# 5. 任务 → 方法/基组 推荐矩阵
# ---------------------------------------------------------------------------
# 每个任务条目：
#   label    显示名
#   kernel   该任务对应的 Gaussian 主关键字（CB 之外附加到路由）
#   recipes  关联的 recipes.CASE_CATALOG 配方名（便于二次扩展）
#   notes    任务层面的通用提示
#   follow_up 后续该做什么
#   by_class 分子类型 → 候选列表；每项含 q(质量档)/method/basis/cost/why
TASK_TABLE: Dict[str, Dict[str, Any]] = {
    "opt": {
        "label": "几何优化",
        "kernel": "Opt",
        "recipes": ["opt"],
        "notes": [],
        "follow_up": ["优化后务必接 Freq（或 Opt Freq 单作业）确认无虚频"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "low",    "why": "杂化泛函 + 双-zeta 极化基组，构型搜索/常规有机首选，便宜且稳定。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2SVP",       "cost": "medium", "why": "ωB97X-D 自带色散，几何精度明显好于 B3LYP/6-31G(d)，且 def2-SVP 成本接近。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "TZVP 级几何，接近收敛；大型分子建议改双层（几何 cheap + 单点 TZVP）。"},
            ],
            "tm_complex": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "金属的稳妥起点；def2 系列对 Z>36 自带 ECP。"},
                {"q": "standard", "method": "TPSSh",  "basis": "def2SVP",       "cost": "medium", "why": "TPSSh 对 3d 金属配合物几何与自旋态平衡最好，是配合物的常用默认。"},
                {"q": "accurate", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "杂化 + TZVP 高精度；建议几何用 TPSSh/def2-SVP，单点再上这一档。"},
            ],
            "heavy_element": [
                {"q": "fast",     "method": "B3LYP",  "basis": "LANL2DZ",       "cost": "low",    "why": "赝势双-zeta，快速拿到合理几何；配体描述较粗。"},
                {"q": "standard", "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "def2 自带 ECP 且配体基组更均衡，是含重元素体系的主力。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "wB97X-D/def2-TZVP 兼顾色散与 ECP 精度。"},
            ],
            "main_group": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "low",    "why": "主族几何一般够用。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2SVP",       "cost": "medium", "why": "缺电子/超价体系易有电子相关，范围分离 + 色散更稳。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "超价（如 S(VI)、三中心键）需要三-zeta 才可靠。"},
            ],
            "cluster": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "low",    "why": "团簇初筛；必须加 GD3BJ 色散，否则氢键/分散主导的结构偏大。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2SVP",       "cost": "medium", "why": "团簇靠非共价维系，色散校正必要。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "结合能若要定量，单点需 TZVP + Counterpoise。"},
            ],
            "biopolymer": [
                {"q": "fast",     "method": "PM6",    "basis": "",              "cost": "low",    "why": "半经验，几百原子也能秒出结构，用于初筛/弛豫。"},
                {"q": "standard", "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "high",   "why": "全 DFT 优化大分子很贵；>200 原子优先 ONIOM 分层。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2SVP",       "cost": "high",   "why": "高精度层只放在活性位点（ONIOM 高层）。"},
            ],
        },
    },

    "opt_freq": {
        "label": "几何优化 + 频率（推荐默认）",
        "kernel": "Opt Freq",
        "recipes": ["opt", "freq"],
        "notes": ["频率必须在与优化完全相同的方法/基组下做，否则热力学修正不自洽。"],
        "follow_up": ["确认 n_imaginary == 0（虚频数），=0 才是真实极小点",
                      "读取 sum_free_energy 做反应自由能"],
        "by_class": "opt",   # 复用 opt 的候选（在 _resolve_entry 中处理）
    },

    "freq": {
        "label": "频率 / 热力学量",
        "kernel": "Freq",
        "recipes": ["freq"],
        "notes": ["谐振频率存在系统性偏高，与实验对比需按方法/基组取经验标度因子（常见 ~0.96–0.99）。",
                  "单独 Freq 作业必须与几何优化使用完全相同的方法/基组（含色散校正），否则不自洽。"],
        "follow_up": ["只需 ugly 高精度时考虑 Freq=(Anharmonic)（非谐，昂贵）"],
        "by_class": "opt",
    },

    "ir": {
        "label": "红外光谱",
        "kernel": "Freq",
        "recipes": ["freq"],
        "notes": ["IR 强度由偶极导数给出，普通 Freq 作业即可同时拿到频率与强度。",
                  "谐振近似的频率需乘 ~0.96–0.98 的经验标度因子后再与实验谱比对。"],
        "follow_up": ["解析 frequencies / intensities 即可画图，注意标度因子"],
        "by_class": "opt",
    },

    "raman": {
        "label": "拉曼光谱",
        "kernel": "Freq=Raman",
        "recipes": ["raman"],
        "notes": ["静态 Raman 用 Freq=Raman；近共振需 CPHF=RdFreq + 页脚激光频率。"],
        "follow_up": ["解析 raman_activities"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "medium", "why": "Raman 活性对极化函数敏感，最低用 6-31G(d)。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2SVP",       "cost": "medium", "why": "偏振导数 + 现代基组，强度更合理。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "定量强度需三-zeta。"},
            ],
        },
    },

    "sp": {
        "label": "高精度单点能（在已有几何上）",
        "kernel": "",
        "recipes": ["esp"],
        "notes": ["典型双层方案：几何用便宜组合优化，单点用高/贵组合算能量。",
                  "单点默认不加 Grimme 色散；若比较非共价复合物/堆积体系，显式传 dispersion='gd3bj'。"],
        "disp": "off",
        "follow_up": ["用 parse_log(...)['scf_energy'] 取能量"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "low",    "why": "仅需快速比较时用。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2TZVP",      "cost": "medium", "why": "单点的性价比主流：范围分离 + 三-zeta。"},
                {"q": "accurate", "method": "wB97XD", "basis": "aug-cc-pVTZ",   "cost": "high",   "why": "接近基组收敛的能量（体系必须很小）。"},
            ],
            "tm_complex": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "金属单点的最低成本起点。"},
                {"q": "standard", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "杂化 + TZVP + ECP，金属单点常用。"},
                {"q": "accurate", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "同上并加 SCRF 溶剂；CCSD(T) 仅极小模型可行。"},
            ],
            "heavy_element": [
                {"q": "fast",     "method": "B3LYP",  "basis": "LANL2DZ",       "cost": "low",    "why": "赝势省时。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2SVP",       "cost": "medium", "why": "def2 自带 ECP。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "重元素定量的现实上限。"},
            ],
        },
    },

    "thermo": {
        "label": "反应能 / 热化学（高精度能量）",
        "kernel": "",
        "recipes": ["freq"],
        "notes": ["反应自由能 = Σ(产物) − Σ(反应物)，各方物种必须同一方法/基组并都做 Freq 修正。",
                  "复合方法（CBS-QB3/G4）自带几何优化与频率，不要再外加 Opt/Freq 关键字。"],
        "follow_up": ["读 sum_free_energy / sum_enthalpy",
                      "溶剂化 ΔG_solv：g09 D.01 需用 solvation_free_energy(pcm_log, gas_log) 相减"],
        "disp": "off",
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "low",    "why": "趋势定性可用；绝对值误差较大。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2TZVP",      "cost": "medium", "why": "双层推荐：B3LYP-GD3BJ/6-31G(d) 优化 + 本组合单点，最实用。"},
                {"q": "accurate", "method": "CBS-QB3","basis": "",              "cost": "high",   "why": "复合方法 ≈ 化学精度 (~1 kcal/mol)；要求小体系且内存充足，32 位机上大概率撑不住。"},
            ],
            "tm_complex": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "金属相对能量对比。"},
                {"q": "standard", "method": "TPSSh",  "basis": "def2TZVP",      "cost": "high",   "why": "金属反应能量 / 自旋态能量差的常用选择。"},
                {"q": "accurate", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "配 SIANA 双层：几何 TPSSh/def2-SVP + 本单点。"},
            ],
        },
    },

    "ts": {
        "label": "过渡态定位",
        "kernel": "Opt=(TS,CalcFC,MaxCyc=100)",
        "recipes": ["ts", "irc"],
        "notes": ["必须给接近 TS 的初猜；CalcFC 起算 Hessian 比 ReadFC 稳。",
                  "线性/近线性三原子（如 HCN⇌HNC）容易报 Problem with coordinate system。"],
        "follow_up": ["Freq 确认恰有 1 个虚频（n_imaginary == 1）",
                      "跑 IRC=CalcFC 验证 TS 连接正确的反应物/产物"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "low",    "why": "TS 初筛；TS 附近常出现非共价接触，务必带 GD3BJ 色散。"},
                {"q": "standard", "method": "M062X",  "basis": "6-311+G(d,p)",  "cost": "medium", "why": "M06-2X 对有机反应能垒/TS 几何精度最好；需 Int=UltraFine，且已含色散不需额外 GD3BJ。"},
                {"q": "accurate", "method": "M062X",  "basis": "def2TZVP",      "cost": "high",   "why": "能垒定量：几何 M06-2X/6-311+G(d,p)，单点升 def2-TZVP。"},
            ],
            "tm_complex": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "金属 TS 起点；配合 SCF=XQC 提收敛率。"},
                {"q": "standard", "method": "TPSSh",  "basis": "def2SVP",       "cost": "high",   "why": "金属催化循环常用。"},
                {"q": "accurate", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "双层方案：几何用 TPSSh/def2-SVP，单点提到本档。"},
            ],
        },
    },

    "barrier": {
        "label": "反应能垒（双层级）",
        "kernel": "",
        "recipes": ["ts"],
        "notes": ["推荐：几何/TS 用便宜组合，能垒能量用高层单点修正。"],
        "follow_up": ["ΔE‡ = E(TS) − E(反应物)，两边几何都要 Freq 校正"],
        "by_class": "ts",
    },

    "weak": {
        "label": "弱相互作用 / 结合能",
        "kernel": "",
        "recipes": ["bsse"],
        "notes": ["必须加色散校正（GD3BJ 或自带色散的泛函），否则结合能严重偏小甚至不结合。",
                  "必须做 BSSE 校正：界面用 Counterpoise=2 + 片段编号（见 recipes 的 bsse 配方）。"],
        "follow_up": ["读 bsse_corrected_energy / complexation_energy_corrected"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31+G(d,p)",   "cost": "medium", "why": "弥散 + GD3BJ 是定量结合能的最低成本线。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "非共价相互作用的默认推荐；需配 Counterpoise。"},
                {"q": "accurate", "method": "MP2",    "basis": "aug-cc-pVDZ",   "cost": "high",   "why": "波函数基准（仍需 CP 校正）；只是仅极小体系。"},
            ],
            "cluster": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31+G(d,p)",   "cost": "medium", "why": "氢键团簇定量最低配置。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "团簇结合能常用。"},
                {"q": "accurate", "method": "MP2",    "basis": "aug-cc-pVDZ",   "cost": "high",   "why": "团簇基准参考值。"},
            ],
        },
    },

    "conformer": {
        "label": "构象搜索 / 大规模筛选",
        "kernel": "Opt",
        "recipes": ["opt"],
        "notes": ["分层策略：先用便宜方法批量出结构，再对 top-N 做高精度排序。"],
        "follow_up": ["汇总 scf_energy/sum_free_energy 排序", "低能构象再跑高精度单点"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "PM6",    "basis": "",              "cost": "low",    "why": "半经验快速铺开构象空间。"},
                {"q": "standard", "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "medium", "why": "DFT 重新优化全部候选。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "对筛选出的低能构象做最终单点排序。"},
            ],
        },
    },

    "uvvis": {
        "label": "激发态 / UV-Vis（TD-DFT）",
        "kernel": "TD=(NStates=10)",
        "recipes": ["tddft"],
        "notes": ["弥散函数必须加：Rydberg / CT / 高阶 π* 态没有弥散会明显偏高。",
                  "电荷转移 / 长程跃迁不要用全局杂化 B3LYP——会严重低估；改用 CAM-B3LYP 或 ωB97X-D。",
                  "本机构建无 FCHT/FC 模块，vibronic/Franck-Condon 谱图需 G16。"],
        "disp": "off",
        "follow_up": ["解析 excited_states 的 (eV, nm, f)", "n→π* 禁阻跃迁 f≈0 属正常"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31+G(d,p)",   "cost": "medium", "why": "局域 π→π* 的低成本选择；定量有限。"},
                {"q": "standard", "method": "wB97XD", "basis": "6-311+G(d,p)",  "cost": "high",   "why": "带弥散的三-zeta，垂直激发能的通用推荐。"},
                {"q": "accurate", "method": "CAM-B3LYP","basis": "def2TZVP",    "cost": "high",   "why": "CT/长程跃迁首选；毛细血管力强。"},
            ],
            "main_group": "default",
            "tm_complex": [
                {"q": "fast",     "method": "B3LYP",    "basis": "def2SVP",    "cost": "high",   "why": "含金属发色团的低成本起点；def2 自带 ECP。"},
                {"q": "standard", "method": "wB97XD",   "basis": "def2TZVP",   "cost": "high",   "why": "金属配合物常见 MLCT/LMCT，范围分离 + TZVP 才不会系统性低估。"},
                {"q": "accurate", "method": "CAM-B3LYP","basis": "def2TZVP",   "cost": "high",   "why": "长程校正最强；注意这里的弥散需求建议加 SCRF 溶剂或用更大 def2 家族。"},
            ],
            "heavy_element": [
                {"q": "fast",     "method": "B3LYP",  "basis": "LANL2DZ",       "cost": "medium", "why": "含重原子的发色团快速筛查。"},
                {"q": "standard", "method": "wB97XD", "basis": "def2SVP",       "cost": "high",   "why": "重金属 ECP + 含氢：光谱常见组合。"},
                {"q": "accurate", "method": "CAM-B3LYP","basis": "def2TZVP",    "cost": "high",   "why": "金属到配体电荷转移 MLCT 需范围分离。"},
            ],
        },
    },

    "nmr": {
        "label": "NMR 化学位移（GIAO）",
        "kernel": "NMR=GIAO",
        "recipes": ["nmr"],
        "notes": ["屏蔽常数对基组敏感，最低 def2-SVP，推荐 6-311+G(d,p) 以上。",
                  "化学位移 = 参考物屏蔽 − 选定核屏蔽（TMS: C≈190、H≈31 ppm 作常用参考）。"],
        "disp": "off",
        "follow_up": ["解析 nmr_shieldings"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "NMR 的最低可接受基组。"},
                {"q": "standard", "method": "B3LYP",  "basis": "6-311+G(d,p)",  "cost": "high",   "why": "屏蔽常数的常用配置。"},
                {"q": "accurate", "method": "B3LYP",  "basis": "6-311++G(2d,p)","cost": "high",   "why": "丰富极化 + 弥散，接近收敛。"},
            ],
            "tm_complex": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "金属配合物 NMR（含重原子使用 ECP）。"},
                {"q": "standard", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "过渡金属化学位移常用。"},
                {"q": "accurate", "method": "PBE0",   "basis": "def2TZVP",      "cost": "high",   "why": "同上，并考虑 PCM 溶剂与相对论效应。"},
            ],
        },
    },

    "nmr_j": {
        "label": "NMR 自旋-自旋耦合常数 J",
        "kernel": "NMR=(GIAO,SpinSpin)",
        "recipes": ["nmr_jcoupling"],
        "notes": ["J 耦合对基组更敏感，尤其 Fermi 接触项需要紧致核区基函数。"],
        "disp": "off",
        "follow_up": ["解析 nmr_shieldings 与 j_couplings"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d,p)",    "cost": "medium", "why": "仅趋势性。"},
                {"q": "standard", "method": "B3LYP",  "basis": "6-311+G(d,p)",  "cost": "high",   "why": "J 耦合的常用组合。"},
                {"q": "accurate", "method": "B3LYP",  "basis": "aug-cc-pVDZ",   "cost": "high",   "why": "相关一致 + 弥散，J 更可靠。"},
            ],
        },
    },

    "epr": {
        "label": "EPR 超精细耦合 / g 张量",
        "kernel": "NMR",
        "recipes": ["hyperfine"],
        "notes": ["本机构建无 Hyperfine= 关键字；可用路线是开壳层 NMR 作业（UB3LYP + mult≠1）。",
                  "超精细必须用 U 前缀的开壳层方法。"],
        "disp": "off",
        "follow_up": ["解析 hyperfine_couplings (MHz) 与 g_tensor"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "UB3LYP", "basis": "6-31G(d)",      "cost": "medium", "why": "快速定性。"},
                {"q": "standard", "method": "UB3LYP", "basis": "EPR-III",       "cost": "high",   "why": "EPR-III 专门为超精细设计（核区富集 + 丰富极化）。"},
                {"q": "accurate", "method": "UB3LYP", "basis": "aug-cc-pVTZ",   "cost": "high",   "why": "接近收敛的超精细常数（体系需很小）。"},
            ],
        },
    },

    "spin_state": {
        "label": "自旋态能量差 / 磁性耦合",
        "kernel": "",
        "recipes": ["sp"],
        "notes": ["自旋态分裂对 HF 交换成分极敏感：B3LYP 偏高、TPSSh 较低。",
                  "破缺态（BS-DFT）求磁耦合常数时注意自旋污染。"],
        "disp": "off",
        "follow_up": ["用 Stable=Opt 确认波函数稳定"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "def2SVP",       "cost": "medium", "why": "快速比较。"},
                {"q": "standard", "method": "TPSSh",  "basis": "def2TZVP",      "cost": "high",   "why": "10% HF 交换，自旋态能量差的常用推荐。"},
                {"q": "accurate", "method": "TPSSh",  "basis": "def2TZVP",      "cost": "high",   "why": "同上 + PCM 溶剂；进阶可调整 HF 交换（B3LYP* 需 iop(3/76=0.15)）。"},
            ],
        },
    },

    "nlo": {
        "label": "极化率 / 非线性光学性质",
        "kernel": "Polar",
        "recipes": ["polar"],
        "notes": ["极化率与超极化率对弥散 + 极化函数极度敏感，缺弥散会严重偏低。"],
        "disp": "off",
        "follow_up": ["解析 polarizability / isotropic_polarizability"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31+G(d,p)",   "cost": "medium", "why": "最低可接受。"},
                {"q": "standard", "method": "wB97XD", "basis": "aug-cc-pVDZ",   "cost": "high",   "why": "通用推荐：范围分离 + 完整弥散。"},
                {"q": "accurate", "method": "CAM-B3LYP","basis": "aug-cc-pVTZ", "cost": "high",   "why": "定量 NLO（体系需很小）。"},
            ],
        },
    },

    "optrot": {
        "label": "旋光 (ORD) / 手性光学",
        "kernel": "Polar=(OptRot)",
        "recipes": ["optrot"],
        "notes": ["旋光对基组（尤其弥散）极敏感，比 NMR 更难收敛。"],
        "disp": "off",
        "follow_up": ["解析 optical_rotation"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31+G(d,p)",   "cost": "medium", "why": "成本最低但仍然需要弥散。"},
                {"q": "standard", "method": "B3LYP",  "basis": "aug-cc-pVDZ",   "cost": "high",   "why": "静态旋光的常用推荐。"},
                {"q": "accurate", "method": "CAM-B3LYP","basis": "aug-cc-pVDZ", "cost": "high",   "why": "长程校正 + 完整弥散，从头预测旋光符号时更可靠。"},
            ],
        },
    },

    "anharmonic": {
        "label": "非谐振频率 VPT2",
        "kernel": "Freq=(Anharmonic)",
        "recipes": ["anharmonic"],
        "notes": ["本机构建不支持 VPT2 子选项；用 Plain Freq=(Anharmonic)。",
                  "非谐需要非常好的解析 Hessian 收敛性，且只在真实极小点上有意义。"],
        "follow_up": ["解析 anharmonic_frequencies"],
        "by_class": {
            "default": [
                {"q": "fast",     "method": "B3LYP",  "basis": "6-31G(d)",      "cost": "high",   "why": "非谐本身就很贵，基组通常只能让步到双-zeta。"},
                {"q": "standard", "method": "B3LYP",  "basis": "6-311G(d,p)",   "cost": "high",   "why": "常用非谐组合。"},
                {"q": "accurate", "method": "wB97XD", "basis": "def2TZVP",      "cost": "high",   "why": "仅极小分子可行。"},
            ],
        },
    },
}

# 任务别名（中英文均可用）
TASK_ALIASES: Dict[str, str] = {
    "optimize": "opt", "优化": "opt", "几何优化": "opt", "optimation": "opt",
    "optfreq": "opt_freq", "opt_freq": "opt_freq", "优化+频率": "opt_freq",
    "freq": "freq", "frequency": "freq", "频率": "freq",
    "ir": "ir", "infrared": "ir", "红外": "ir", "红外光谱": "ir",
    "raman": "raman", "拉曼": "raman", " Raman": "raman",
    "sp": "sp", "singlepoint": "sp", "single_point": "sp", "单点能": "sp", "单点": "sp",
    "energy": "thermo", "thermo": "thermo", "reaction_energy": "thermo",
    "反应能": "thermo", "热化学": "thermo", "自由能": "thermo",
    "ts": "ts", "transition_state": "ts", "过渡态": "ts",
    "barrier": "barrier", "能垒": "barrier", "活化能": "barrier",
    "weak": "weak", "binding": "weak", "noncovalent": "weak", "结合能": "weak",
    "弱相互作用": "weak", "非共价": "weak",
    "conformer": "conformer", "构象": "conformer", "构象搜索": "conformer", "筛选": "conformer",
    "uvvis": "uvvis", "uv": "uvvis", "excited": "uvvis", "tddft": "uvvis",
    "激发态": "uvvis", "紫外": "uvvis", "uv-vis": "uvvis",
    "nmr": "nmr", "核磁": "nmr", "化学位移": "nmr",
    "nmr_j": "nmr_j", "jcoupling": "nmr_j", "j耦合": "nmr_j", "耦合常数": "nmr_j",
    "epr": "epr", "hyperfine": "epr", "超精细": "epr", "esr": "epr", "g张量": "epr",
    "spin_state": "spin_state", "自旋态": "spin_state", "自旋": "spin_state",
    "nlo": "nlo", "polarizability": "nlo", "极化率": "nlo",
    "optrot": "optrot", "旋光": "optrot", "ord": "optrot",
    "anharmonic": "anharmonic", "非谐": "anharmonic", "anharm": "anharmonic",
}

QUALITY_ALIASES: Dict[str, str] = {
    "快": "fast", "fast": "fast", "rough": "fast", "cheap": "fast", "screen": "fast",
    "standard": "standard", "标准": "standard", "default": "standard", "推荐": "standard",
    "accurate": "accurate", "high": "accurate", "高精度": "accurate", "精确": "accurate",
}


def _normalize_task(task: str) -> str:
    key = str(task).strip().lower()
    key = TASK_ALIASES.get(key, TASK_ALIASES.get(str(task).strip(), key))
    if key not in TASK_TABLE:
        raise KeyError(
            f"未知任务类型 {task!r}；可用任务: {', '.join(list_tasks())}"
        )
    return key


def _normalize_quality(quality: str) -> str:
    key = str(quality).strip().lower()
    key = QUALITY_ALIASES.get(key, QUALITY_ALIASES.get(str(quality).strip(), key))
    if key not in ("fast", "standard", "accurate"):
        raise KeyError(f"未知精度档位 {quality!r}；可用: fast / standard / accurate")
    return key


def list_tasks() -> List[str]:
    """列出所有支持的计算任务名。"""
    return list(TASK_TABLE.keys())


def list_molecules() -> List[str]:
    """列出所有支持的分子类型名。"""
    return list(MOLECULE_LABELS.keys())


def _resolve_entry(task: str) -> Dict[str, Any]:
    """展开任务条目（by_class 支持字符串引用，如 "opt" 表示复用该任务的候选）。"""
    entry = TASK_TABLE[task]
    seen = set()
    while isinstance(entry.get("by_class"), str):
        ref = entry["by_class"]
        if ref in seen:
            break
        seen.add(ref)
        parent = TASK_TABLE[ref]
        merged = dict(parent)
        merged.update(entry)
        merged["by_class"] = parent["by_class"]
        entry = merged
        # 注意：合成后仍可能再次引用，循环继续展开
    return entry


def _pick_candidate(entry: Dict[str, Any], molclass: str, quality: str):
    """从候选列表按精度档取候选；缺档时退化为最接近的一档。"""
    by_class = entry["by_class"]
    cand_list = by_class.get(molclass) or by_class.get("default")
    if isinstance(cand_list, str):
        cand_list = by_class.get(cand_list, by_class.get("default"))
    if not cand_list:
        cand_list = by_class.get("default")
    if isinstance(cand_list, dict):
        cand_list = list(cand_list.values())

    order = {"fast": 0, "standard": 1, "accurate": 2}
    want = order[quality]
    by_q = {c["q"]: c for c in cand_list if "q" in c}
    if quality in by_q:
        return by_q[quality]
    # 退化：优先向下取便宜档，其次向上
    for step in range(1, 3):
        lo = want - step
        hi = want + step
        for idx in (lo, hi):
            for q, c in by_q.items():
                if order[q] == idx:
                    return c
    return cand_list[0]


# ---------------------------------------------------------------------------
# 6. 主推荐函数
# ---------------------------------------------------------------------------
def recommend_method(
    n_atoms: Optional[int] = None,
    atoms: Optional[Sequence[str]] = None,
    coords: Optional[Sequence[Sequence[float]]] = None,
    molecule: Optional[str] = None,
    task: str = "opt_freq",
    quality: str = "standard",
    charge: int = 0,
    mult: int = 1,
    solvent: Optional[str] = None,
    dispersion: str = "auto",
    arch: Optional[str] = None,
    extra_options: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """
    推荐 Gaussian 计算方法与基组。

    Parameters
    ----------
    n_atoms : 体系原子数（与 atoms/xyz 二选一；三者都给时以 atoms 为准）
    atoms : 元素符号列表，用于自动判别分子类型（也可同时充当 n_atoms 来源）
    coords : 坐标（可选，目前仅用于校验数量）
    molecule : 显式指定分子类型（organic / tm_complex / heavy_element /
               main_group / cluster / biopolymer / general）；不给则自动判别
    task : 计算任务名，见 ``list_tasks()``；支持中文别名
    quality : ``fast`` / ``standard`` / ``accurate``
    charge, mult : 电荷与自旋多重度（影响弥散函数与 U/RO 前缀）
    solvent : 溶剂名（如 "Water"），给出的追加 SCRF=(PCM,Solvent=...)
    dispersion : ``auto`` 自动判断；``none`` 不加；``gd3bj``/``gd3`` 强制
    arch : Gaussian 位数 ``"x86"`` / ``"x64"``；None 时尝试自动探测
    extra_options : 追加到路由的自定义关键字列表

    Returns
    -------
    dict —— 见下方 Recipe 结构（同时含 why / notes / warnings / alternatives / follow_up）
    """
    task_key = _normalize_task(task)
    quality_key = _normalize_quality(quality)
    entry = _resolve_entry(task_key)

    # --- 分子类型 ---
    auto_used = False
    detected: Optional[Dict[str, Any]] = None
    molclass = _normalize_molecule(molecule)
    if atoms:
        detected = detect_molecule_class(atoms, charge=charge, mult=mult)
        if molclass is None or molclass == "general":
            molclass = detected["class"]
            auto_used = True
        if n_atoms is None:
            n_atoms = detected["n_atoms"]
    if molclass is None:
        molclass = "general"
    if n_atoms is None:
        n_atoms = 20   # 未给定尺寸时按小分子处理

    flags: List[str] = list(detected["flags"]) if detected else []
    if charge < 0 and "anion" not in flags:
        flags.append("anion")
    if charge > 0 and "cation" not in flags:
        flags.append("cation")
    if mult != 1 and "open_shell" not in flags:
        flags.append("open_shell")
    elements = detected["elements"] if detected else []

    tier = size_tier(n_atoms)
    arch_key = (arch or _auto_arch()).lower()
    res = _RESOURCE_PROFILES.get(arch_key, _RESOURCE_PROFILES["x64"])

    # --- 选候选 ---
    cand = _pick_candidate(entry, molclass, quality_key)
    method: str = cand["method"]
    basis: str = cand.get("basis", "")
    cost: str = cand.get("cost", "medium")
    why: List[str] = [cand.get("why", "")] if cand.get("why") else []

    warnings: List[str] = []
    notes: List[str] = list(entry.get("notes", []))
    info = METHOD_INFO.get(method, {})
    if info.get("note"):
        notes.append(info["note"])
    if info.get("g09_ok") is False:
        warnings.append(
            f"{method} 在本机 g09 Rev D.01 不可用（{info.get('note') or '需 Gaussian 16'}）；"
            f"若关键字不被识别请改用备选方案。"
        )

    # --- 修饰 1：重元素必须赝势/def2 ---
    if molclass in ("tm_complex", "heavy_element") and basis in (
            "6-31G(d)", "6-31G(d,p)", "6-311G(d,p)", "6-311+G(d,p)"):
        warnings.append(
            f"{basis} 对第 4/5 周期以后的金属没有定义（或很差）；"
            f"已建议的 {method} 需要搭配 def2 系列（自带 ECP）或 LANL2DZ/SDD。"
        )

    # --- 修饰 2：负电荷 / 缺电子 → 弥散函数 ---
    need_diffuse = ("anion" in flags) or task_key in ("nlo", "optrot", "uvvis", "weak")
    if need_diffuse and basis:
        if molclass in ("tm_complex", "heavy_element"):
            # 含金属/重元素时不能自动套 Pople / aug-cc 全电子基组（很多压根没定义，或丢 ECP）
            warnings.append(
                f"含金属/重元素的体系需要弥散函数时，不建议自动换到 Pople / aug-cc 全电子基组"
                f"（要么没有对应定义，要么丢掉 ECP）；当前保持 {basis}，"
                f"需弥散请显式升级到更大的 def2 家族（如 def2TZVP）或用 Gen/GenECP 自定义。"
            )
        else:
            upgraded = _DIFFUSE_UPGRADE.get(basis)
            if upgraded and upgraded != basis:
                why.append(f"体系 {'带负电' if 'anion' in flags else '对电子密度尾部敏感'}，"
                           f"基组加入弥散函数：{basis} → {upgraded}")
                basis = upgraded
            elif upgraded is None:
                warnings.append(f"基组 {basis} 缺弥散函数，而该任务/体系通常需要 (+/aug-) 弥散函数。")

    # --- 修饰 3：按资源预算降配（有下限，不会把 DFT 降到极小/无极化基组） ---
    # 下限 = 6-31G(d)：比它更小的组合做 DFT 没有意义，此时改为提示换策略（半经验 / ONIOM / 64 位）。
    budget = res["budget"].get(tier, 0)
    floor_rank = 3   # 6-31G(d)
    if basis and _basis_rank(basis) > budget:
        if budget < floor_rank:
            warnings.append(
                f"{size_tier_label(tier)}（{n_atoms} 原子）在「{res['label']}」下连 "
                f"{method}/{BASIS_LADDER[floor_rank]} 都吃不消——本环境不推荐直接上全量子化学层。"
                f"建议：①先用半经验 PM6 弛豫/初筛；②做 ONIOM 分层把高层只放在关键位点；③换 64 位 Gaussian。"
            )
        else:
            budget = min(budget, len(BASIS_LADDER) - 1)
            replacement = BASIS_LADDER[budget]
            if need_diffuse:
                rep2 = _DIFFUSE_UPGRADE.get(replacement, replacement)
                if _basis_rank(rep2) <= budget:
                    replacement = rep2
            warnings.append(
                f"{size_tier_label(tier)}（{n_atoms} 原子）在「{res['label']}」下承受不起 {basis}；"
                f"已自动降配为 {replacement}。需要原精度请换 64 位 Gaussian、改用 ONIOM 分层，"
                f"或用「便宜组合优化 + 贵组合单点」的双层方案。"
            )
            basis = replacement
            cost = "medium"

    # --- 修饰 4：超大体系 / 32 位 → 半经验或 ONIOM ---
    semi_hint = None
    if tier in ("very_large", "huge"):
        if arch_key == "x86":
            semi_hint = "PM6"
            warnings.append(
                f"{size_tier_label(tier)}在 32 位 Gaussian 上几乎不可行；"
                f"建议①半经验 PM6 先弛豫，②用 ONIOM 把高层放在关键位点，③或换 64 位 g16。"
            )
        else:
            notes.append(
                f"{size_tier_label(tier)}：全量子化学层成本很高，推荐 ONIOM 分层——"
                f"高层（活性位点）用 {method}/{basis or 'def2SVP'}，低层用 PM6 或分子力学。"
            )
    if n_atoms > res["max_atoms_soft"] and method not in ("PM6", "PM7"):
        warnings.append(
            f"{n_atoms} 原子已超过该环境的软上限（~{res['max_atoms_soft']} 原子）；"
            f"请先小规模试算确认内存与耗时。"
        )

    # --- 修饰 5：关键字别名 + 开壳层 U/RO 前缀 ---
    open_shell = mult != 1
    alias = info.get("route_name")
    if alias and alias != method:
        why.append(f"部分 Gaussian 构建不识别 {method} 关键字，路由改用同义写法 {alias}"
                   f"（本机 g09 D.01 实测：{method} 报 rc=2057，{alias} 正常）。")
        method = alias
        info = METHOD_INFO.get(method, info)
    if open_shell and info.get("kind", "") not in ("半经验", "复合方法"):
        if not method.startswith(("U", "R")):
            method = "U" + method
            why.append(f"自旋多重度 mult={mult}，自动加 U 前缀改为非限制方法 {method}。")

    # --- 修饰 6：色散校正 ---
    # 原则：色散主要影响几何与非共价结合能。含几何的优化类任务默认加 Grimme GD3BJ；
    # 纯单点物性（NMR / EPR / 旋光 / NLO / 垂直激发）默认不加——它几乎不改变结果，
    # 只是白白增加开销（这些任务在 TASK_TABLE 里标了 "disp": "off"）。
    disp_kw: Optional[str] = None
    disp_mode = str(dispersion or "auto").lower()
    builtin_disp = info.get("disp")
    force_disp = disp_mode in ("gd3bj", "gd3", "on", "force")
    if disp_mode in ("none", "off"):
        want_disp = False
    elif force_disp:
        want_disp = True
    elif entry.get("disp") == "off" and molclass != "cluster":
        want_disp = False
    else:
        want_disp = True

    if not want_disp:
        why.append(f"「{entry['label']}」属单点物性/能量类，默认不加 Grimme 色散；"
                   f"若涉及非共价堆积可在 recommend_method(..., dispersion='gd3bj') 显式打开。")
    elif builtin_disp == "builtin":
        why.append(f"{method} 自带色散校正，不再叠加 Grimme（避免双计数）。")
    elif builtin_disp == "partial":
        why.append(f"{method} 已含中程相关/部分色散描述，通常不再叠加 GD3BJ。")
    elif builtin_disp is None and info.get("kind", "").startswith(("杂化", "meta")):
        disp_kw = "EmpiricalDispersion=GD3BJ"   # g09 D.01 支持；若报错退回 GD3
        why.append("该泛函不含色散，追加 EmpiricalDispersion=GD3BJ"
                   "（若本机构建不识别 GD3BJ，退回 EmpiricalDispersion=GD3）。")
    elif disp_mode == "none":
        disp_kw = None

    # --- 组装路由 ---
    options: List[str] = []
    if disp_kw:
        options.append(disp_kw)
    if info.get("ultrafine") or (task_key in ("ts", "barrier") and "M06" in method):
        options.append("Int=UltraFine")
    if molclass == "tm_complex" or open_shell:
        options.append("SCF=XQC")   # 金属/开壳层 SCF 难收敛时的兜底
    if solvent:
        options.append(f"SCRF=(PCM,Solvent={solvent})")
    for o in (extra_options or []):
        if o:
            options.append(str(o))

    mb = f"{method}/{basis}" if basis else method   # 复合方法/半经验无斜杠
    kernel = entry.get("kernel", "")
    route_parts = [f"# {mb}"]
    # 复合方法（CBS-QB3/G4）自带优化+频率，不追加任务关键字
    if info.get("kind") == "composite":
        kernel = ""
    if kernel:
        route_parts.append(kernel)
    route_parts.extend(options)
    route = " ".join(p for p in " ".join(route_parts).split() if p)

    # --- 备选方案 ---
    alternatives: List[Dict[str, str]] = []
    for c in (entry["by_class"].get(molclass) or entry["by_class"].get("default") or []):
        if not isinstance(c, dict) or "method" not in c:
            continue
        if c.get("method") == cand.get("method") and c.get("basis") == cand.get("basis"):
            continue
        alt_basis = c.get("basis", "")
        alt_method = c["method"]
        alt_alias = METHOD_INFO.get(alt_method, {}).get("route_name")
        if alt_alias:
            alt_method = alt_alias
        # 开壳层时备选方案同样需要 U 前缀
        if open_shell and alt_method.startswith(("B3LYP", "TPSSh", "PBE0", "M062X", "B2PLYP")) \
                and not alt_method.startswith(("U", "R")):
            alt_method = "U" + alt_method
        alt_mb = f"{alt_method}/{alt_basis}" if alt_basis else alt_method
        alternatives.append({
            "q": c.get("q", "-"),
            "role": {"fast": "更省算力", "standard": "通用推荐", "accurate": "更精确"}.get(c.get("q"), ""),
            "method": alt_method,
            "basis": alt_basis,
            "mb": alt_mb,
            "cost": c.get("cost", "-"),
            "when": c.get("why", ""),
        })

    return {
        "task": task_key,
        "task_label": entry["label"],
        "molecule": molclass,
        "molecule_label": MOLECULE_LABELS.get(molclass, molclass),
        "molecule_source": "auto" if auto_used else ("user" if molecule else "auto"),
        "molecule_flags": flags,
        "elements": elements,
        "n_atoms": n_atoms,
        "size_tier": tier,
        "size_tier_label": size_tier_label(tier),
        "quality": quality_key,
        "method": method,
        "basis": basis,
        "mb": mb,
        "dispersion": disp_kw or ("builtin" if builtin_disp else None),
        "open_shell": open_shell,
        "charge": charge,
        "mult": mult,
        "solvent": solvent,
        "options": options,
        "route": route,
        "cost": cost,
        "mem": res["mem"],
        "nproc_hint": res["nproc_hint"],
        "arch": arch_key,
        "resource_label": res["label"],
        "recipes": list(entry.get("recipes", [])),
        "why": why,
        "notes": notes,
        "warnings": warnings,
        "alternatives": alternatives,
        "follow_up": list(entry.get("follow_up", [])),
        "semi_hint": semi_hint,
    }


def recommend_for_xyz(xyz_path: str, **kwargs) -> Dict[str, Any]:
    """
    直接从 XYZ 文件推荐（自动读取原子数、元素组成并在需要时看第一行注释）。

    其他参数同 ``recommend_method``。
    """
    from .utils import read_xyz
    atoms, coords, comment = read_xyz(xyz_path)
    kwargs.setdefault("atoms", atoms)
    return recommend_method(coords=coords, **kwargs)


def explain_recommendation(rec: Dict[str, Any]) -> str:
    """把推荐结果渲染成人类可读的说明文本。"""
    lines: List[str] = []
    lines.append("=" * 60)
    lines.append(f"任务：{rec['task_label']}（{rec['task']}）    精度档：{rec['quality']}")
    lines.append(f"体系：{rec['molecule_label']}（{rec['molecule']}，"
                 f"{'自动判别' if rec['molecule_source']=='auto' else '用户指定'}）"
                 f"    {rec['n_atoms']} 原子  [{rec['size_tier_label']}]")
    if rec["molecule_flags"]:
        lines.append(f"标记：{', '.join(rec['molecule_flags'])}")
    lines.append(f"环境：{rec['resource_label']}")
    lines.append("-" * 60)
    lines.append(f"推荐： {rec['mb']}")
    lines.append(f"路由： {rec['route']}")
    lines.append(f"资源： %mem={rec['mem']}；{rec['nproc_hint']}   估算成本：{rec['cost']}")
    lines.append("-" * 60)
    if rec["why"]:
        lines.append("选择理由：")
        for w in rec["why"]:
            lines.append(f"  · {w}")
    if rec["options"]:
        lines.append(f"附加关键字：{'  '.join(rec['options'])}")
    if rec["notes"]:
        lines.append("任务要点：")
        for n in rec["notes"]:
            lines.append(f"  · {n}")
    if rec["warnings"]:
        lines.append("⚠ 警告：")
        for w in rec["warnings"]:
            lines.append(f"  ! {w}")
    if rec["alternatives"]:
        lines.append("备选方案：")
        for a in rec["alternatives"]:
            lines.append(f"  [{a['q']:<8}] {a['mb']:<28} {a['role']}（成本 {a['cost']}）")
            if a["when"]:
                lines.append(f"             {a['when']}")
    if rec["follow_up"]:
        lines.append("后续步骤：")
        for f in rec["follow_up"]:
            lines.append(f"  → {f}")
    if rec["recipes"]:
        lines.append(f"关联配方：{', '.join(rec['recipes'])}"
                     f"（可用 case_route('{rec['recipes'][0]}', mb=rec['mb']) 取模板）")
    lines.append("=" * 60)
    return "\n".join(lines)


def recommendation_matrix(task: str = "opt_freq", quality: str = "standard",
                          arch: Optional[str] = None) -> str:
    """打印某个任务下「分子类型 → 推荐组合」的速查表。"""
    tk = _normalize_task(task)
    qk = _normalize_quality(quality)
    entry = _resolve_entry(tk)
    lines = [f"{entry['label']}（{tk}）推荐矩阵 —— 精度档：{qk}", "=" * 66]
    for m in list_molecules():
        try:
            r = recommend_method(n_atoms=20, molecule=m, task=tk, quality=qk, arch=arch)
        except Exception:
            continue
        lines.append(f"{MOLECULE_LABELS[m]:<22} {r['mb']:<28} 成本={r['cost']}")
    return "\n".join(lines)


def task_guide(quality: str = "standard", molecule: str = "organic",
               n_atoms: int = 20, arch: Optional[str] = None) -> str:
    """列出所有任务的推荐（默认 standard 档，20 原子有机分子）速查表。"""
    qk = _normalize_quality(quality)
    lines = [f"Gaussian 任务 → 推荐方法/基组（{qk} 档，{molecule}，{n_atoms} 原子，arch={arch or 'auto'}）",
             "=" * 72]
    for tk in list_tasks():
        try:
            r = recommend_method(n_atoms=n_atoms, molecule=molecule, task=tk,
                                 quality=qk, arch=arch)
        except Exception:
            continue
        entry = _resolve_entry(tk)
        lines.append(f"{entry['label']:<24} {r['mb']:<26} route: {r['route']}")
    return "\n".join(lines)


if __name__ == "__main__":   # pragma: no cover
    import argparse

    ap = argparse.ArgumentParser(description="Gaussian 计算方法/基组推荐")
    ap.add_argument("--n", type=int, default=20, help="原子数")
    ap.add_argument("--task", default="opt_freq", help="计算任务")
    ap.add_argument("--molecule", default=None, help="分子类型")
    ap.add_argument("--quality", default="standard", help="fast/standard/accurate")
    ap.add_argument("--charge", type=int, default=0)
    ap.add_argument("--mult", type=int, default=1)
    ap.add_argument("--solvent", default=None)
    ap.add_argument("--guide", action="store_true", help="打印全部任务速查表")
    a = ap.parse_args()

    if a.guide:
        print(task_guide())
    else:
        rec = recommend_method(n_atoms=a.n, task=a.task, molecule=a.molecule,
                               quality=a.quality, charge=a.charge, mult=a.mult,
                               solvent=a.solvent)
        print(explain_recommendation(rec))
