"""
GaussianAutomation —— Python 调用 Gaussian 的常用工具包
========================================================

提供三大能力：
  1. gjf_writer  : 生成 Gaussian 输入文件 (.gjf)
  2. runner      : 通过 subprocess 调用 g16/g09 执行计算
  3. log_parser  : 解析 Gaussian 输出文件 (.log/.out)，提取能量/频率/结构/热力学量

纯标准库实现，无需第三方依赖。
"""

from .gjf_writer import write_gjf, write_gjf_from_xyz
from .runner import (
    run_gaussian, run_gaussian_batch, run_and_save,
    extract_chk_name, formchk,
)
from .log_parser import parse_log, summarize, solvation_free_energy
from .detect import find_gaussian, require_gaussian
from .recipes import CASE_CATALOG, case_route, list_cases, catalog_summary
from .method_selector import (
    recommend_method, recommend_for_xyz, detect_molecule_class, size_tier,
    explain_recommendation, recommendation_matrix, task_guide,
    list_tasks, list_molecules,
    METHOD_INFO, BASIS_LADDER, MOLECULE_LABELS, TASK_TABLE,
)
from .cpu import (
    logical_cpu_count, resolve_nprocs, apply_nprocs_to_gjf, explain_nprocs,
)
from .utils import (
    read_xyz, write_xyz,
    symbol_to_number, number_to_symbol,
    NUMBER_TO_SYMBOL, SYMBOL_TO_NUMBER,
)

__all__ = [
    "write_gjf",
    "write_gjf_from_xyz",
    "run_gaussian",
    "run_gaussian_batch",
    "run_and_save",
    "extract_chk_name",
    "formchk",
    "parse_log",
    "summarize",
    "solvation_free_energy",
    "find_gaussian",
    "require_gaussian",
    "CASE_CATALOG",
    "case_route",
    "list_cases",
    "catalog_summary",
    "recommend_method",
    "recommend_for_xyz",
    "detect_molecule_class",
    "size_tier",
    "explain_recommendation",
    "recommendation_matrix",
    "task_guide",
    "list_tasks",
    "list_molecules",
    "logical_cpu_count",
    "resolve_nprocs",
    "apply_nprocs_to_gjf",
    "explain_nprocs",
    "read_xyz",
    "write_xyz",
    "symbol_to_number",
    "number_to_symbol",
    "NUMBER_TO_SYMBOL",
    "SYMBOL_TO_NUMBER",
]

__version__ = "1.7.0"
