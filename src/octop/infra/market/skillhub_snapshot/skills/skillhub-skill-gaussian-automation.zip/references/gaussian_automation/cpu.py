"""
CPU 逻辑核数探测与 %nprocs 解析
================================

Gaussian 通过 Link 0 指令指定并行核数：
  - %nprocshared=N   共享内存并行（单节点多核，最常用）
  - %nprocs=N        部分版本接受的别名，本模块统一识别并归一化为 %nprocshared

本模块提供：
  - logical_cpu_count()        返回本机逻辑 CPU 核数（含超线程）
  - resolve_nprocs(...)         把“用户输入 / gjf 已有指令”解析为最终核数，
                                支持：绝对核数(12)、百分比(75%)、小数比例(0.75)
  - apply_nprocs_to_gjf(...)    在 gjf 的 Link 0 区写入/更新核数指令

解析优先级：user_input  >  gjf 中已有 %nprocs/%nprocshared  >  默认(全部逻辑核)
最终核数会被约束到 [1, 逻辑核数]（防呆上限）。
不再对 32 位 Gaussian 做保守封顶——核数由调用者自行保证在程序可承受范围
（例如 32 位 g09 并行核数过高可能因地址空间受限而崩溃，需自行权衡）。
"""

from __future__ import annotations

import os
import re
from typing import Optional, Dict, Any

# 同时匹配 %nprocs= 与 %nprocshared= （支持大小写与 % 后可选空格）
_NPROC_RE = re.compile(r"%\s*nproc(?:s|shared)\s*=\s*(\d+)", re.IGNORECASE)


def logical_cpu_count() -> int:
    """
    返回本机逻辑 CPU 核数（包含超线程）。
    探测失败（如某些受限容器）时退化返回 1，保证任何环境都可用。
    """
    try:
        n = os.cpu_count()
        if n and n > 0:
            return int(n)
    except Exception:
        pass
    return 1


def _parse_nprocs_from_gjf(gjf_path: str) -> Optional[int]:
    """
    从 gjf 的 Link 0 区读取 %nprocs= / %nprocshared= 的值。
    只扫描到路由行（# 开头）为止；找不到返回 None。
    """
    try:
        with open(gjf_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                m = _NPROC_RE.search(line)
                if m:
                    return int(m.group(1))
                stripped = line.strip()
                # 路由行出现即表示 Link 0 区结束
                if stripped.startswith("#"):
                    break
    except Exception:
        pass
    return None


def _parse_user_input(user_input: Any, total: int) -> int:
    """
    把用户输入解析为核数整数。

    支持的形式：
      12       -> 绝对核数 12
      "12"     -> 绝对核数 12
      "75%"    -> 比例：round(16 * 75 / 100) = 12
      "75 %"   -> 同上
      0.75     -> 比例：round(16 * 0.75) = 12
    无法解析时抛出 ValueError 并给出用法提示。
    """
    if user_input is None:
        raise ValueError("user_input 为空，无法解析核数")
    s = str(user_input).strip()

    # 百分比形式：'75%' 或 '75 %'
    m = re.match(r"^(\d+(?:\.\d+)?)\s*%$", s)
    if m:
        return max(1, int(round(total * float(m.group(1)) / 100.0)))

    # 0~1 之间的小数视为比例（如 0.75）
    try:
        v = float(s)
        if 0 < v < 1:
            return max(1, int(round(total * v)))
    except ValueError:
        pass

    # 绝对核数
    try:
        return max(1, int(round(float(s))))
    except ValueError:
        raise ValueError(
            f"无法解析核数输入: {user_input!r}\n"
            "应为：整数(如 12) 或 百分比(如 75%)，或 0~1 的比例(如 0.75)。"
        )


def resolve_nprocs(
    user_input: Any = None,
    total: Optional[int] = None,
    gjf_path: Optional[str] = None,
    max_procs: Optional[int] = None,
    arch: Optional[str] = None,
) -> int:
    """
    解析最终使用的核数。

    解析优先级：user_input  >  gjf 已有指令  >  默认(全部逻辑核)

    参数
    ----
    user_input  用户输入：int / "12" / "75%" / 0.75 （None 表示不指定）
    total       逻辑核数；缺省自动调用 logical_cpu_count()
    gjf_path    若提供，优先读取其中已写的 %nprocs= / %nprocshared=
    max_procs   硬上限；缺省 = total（不再对 32 位做保守封顶，
                由调用者自行保证数值在程序可承受范围）
    arch        架构 'x86'/'x64'，仅用于信息展示，不再参与核数封顶

    返回
    ----
    int 核数（已约束到 [1, total] 范围）
    """
    if total is None:
        total = logical_cpu_count()

    if max_procs is None:
        # 取消 32 位安全封顶：直接以逻辑核数为上限（防呆，非 32 位保护）
        max_procs = total

    value: Optional[int] = None
    source = "default(all logical cores)"

    # 1) 用户显式输入（最高优先级）
    if user_input is not None:
        try:
            value = _parse_user_input(user_input, total)
            source = f"user_input({user_input!r})"
        except ValueError:
            # 用户字符串写错时，退而读取 gjf，实在没有再用默认
            pass

    # 2) gjf 中已有指令
    if value is None and gjf_path:
        gv = _parse_nprocs_from_gjf(gjf_path)
        if gv is not None:
            value, source = gv, f"gjf({gv})"

    # 3) 默认全部逻辑核
    if value is None:
        value = total

    return max(1, min(int(value), total, max_procs))


def apply_nprocs_to_gjf(
    gjf_path: str,
    nprocs: int,
    out_path: Optional[str] = None,
    directive: str = "%nprocshared",
) -> str:
    """
    在 gjf 的 Link 0 区写入/更新核数指令。

    - 若已有 %nprocs= / %nprocshared=，原地替换为新值；
    - 否则作为首行插入。
    - 默认写 %nprocshared=（所有 Gaussian 版本通用）；
      也可传 directive="%nprocs" 以写用户习惯的 %nprocs=。

    返回实际写入的文件路径（out_path 或原文件）。
    """
    n = int(nprocs)
    if n < 1:
        raise ValueError("nprocs 必须 >= 1")

    with open(gjf_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.read().splitlines()

    target = f"{directive}={n}"
    new_lines: list = []
    replaced = False
    for ln in lines:
        if _NPROC_RE.search(ln):
            new_lines.append(target)
            replaced = True
        else:
            new_lines.append(ln)

    if not replaced:
        new_lines.insert(0, target)

    out = out_path or gjf_path
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(new_lines) + "\n")
    return out


def explain_nprocs(
    user_input: Any = None,
    gjf_path: Optional[str] = None,
    arch: Optional[str] = None,
) -> Dict[str, Any]:
    """返回一个可读的解析结果 dict，便于脚本/日志展示。"""
    total = logical_cpu_count()
    n = resolve_nprocs(user_input=user_input, total=total, gjf_path=gjf_path, arch=arch)
    gjf_val = _parse_nprocs_from_gjf(gjf_path) if gjf_path else None
    return {
        "logical_cpus": total,
        "gjf_nprocs": gjf_val,
        "user_input": user_input,
        "resolved_nprocs": n,
        "arch": arch,
    }
