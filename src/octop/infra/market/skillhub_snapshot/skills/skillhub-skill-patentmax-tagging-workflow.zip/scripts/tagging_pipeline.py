#!/usr/bin/env python3
"""PatentMax 标引流水线 —— 取数、出标引模板、核验证据、出标引报告。

给 AI 用的命令行工具。四个子命令：

  fetch     按检索式取候选集（默认只报预算，--yes 才联网）
  template  从候选集生成标引模板 CSV（AI 在标签列里填词）
  build     读标引结果 CSV，核验证据短语命中后出 HTML 报告
  selfcheck 离线自检（不联网、不读密钥、不计费）

设计原则：
- 每条标引必须给证据短语（出自标题或摘要），build 阶段逐条核验，
  没命中的标「证据未命中」，绝不静默放行。
- 字段名按候选名依次试（上游不统一），取不到写「未获取」，不补猜。
- 失败即停：接口报错时不写半截结果文件。
只用标准库。
"""

import argparse
import csv
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

BASE_URL = os.environ.get("PATENTMAX_BASE_URL", "https://api.ip930.com").rstrip("/")
API_KEY = os.environ.get("PATENTMAX_API_KEY", "").strip()
TIMEOUT = 60
PRICE_SEARCH = 0.10  # 元/次，仅用于预算提示，真实扣费以服务端为准

TAG_COLS = ["技术主题", "应用场景", "功能效果", "成熟度"]
BASE_COLS = ["公开号", "标题", "申请人", "申请日", "IPC", "摘要"]
MISSING = "未获取"


class Fail(Exception):
    """业务失败：消息直接给人看，不抛栈。"""


def pick(row, *names):
    if not isinstance(row, dict):
        return None
    for name in names:
        value = row.get(name)
        if value not in (None, "", []):
            return value
    return None


def rows_of(payload):
    if isinstance(payload, list):
        return [r for r in payload if isinstance(r, dict)]
    if not isinstance(payload, dict):
        return []
    for name in ("patents", "list", "data", "records", "rows"):
        value = payload.get(name)
        if isinstance(value, list):
            return [r for r in value if isinstance(r, dict)]
    return []


def s(value):
    """归一成可写 CSV 的字符串。"""
    if value in (None, "", []):
        return MISSING
    if isinstance(value, list):
        value = "；".join(str(v) for v in value)
    return str(value).strip() or MISSING


def api_get(path, params):
    if not API_KEY:
        raise Fail("未设置 API 密钥。先 export PATENTMAX_API_KEY=pm_live_xxx，"
                   "密钥在 https://api.ip930.com/features/api-platform 创建。")
    clean = {k: v for k, v in params.items() if v not in (None, "")}
    url = f"{BASE_URL}{path}?" + urllib.parse.urlencode(clean)
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {API_KEY}")
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:300]
        hint = {
            400: "参数有问题，检查检索式与分页取值。",
            401: "密钥无效或已撤销，确认完整密钥且未漏 Bearer 前缀。",
            402: "余额不足，到控制台充值后再试。",
            403: "该密钥无此接口权限。",
            429: "触发限流：测试密钥每天 30 次，或稍后重试。",
        }.get(exc.code, "")
        raise Fail(f"HTTP {exc.code}：{hint} 上游响应：{detail}") from exc
    except urllib.error.URLError as exc:
        raise Fail(f"网络请求失败：{exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise Fail("响应不是合法 JSON，上游可能异常。") from exc


def normalize(row):
    return {
        "公开号": s(pick(row, "documentNumber", "publicationNumber", "pn",
                        "publicNo", "openNumber")),
        "标题": s(pick(row, "title", "patentTitle", "name")),
        "申请人": s(pick(row, "assignee", "assignees", "applicant", "applicants",
                        "applicantName")),
        "申请日": s(pick(row, "applicationDate", "appDate", "filingDate")),
        "IPC": s(pick(row, "ipc", "ipcList", "ipcClassifications", "classification")),
        "摘要": s(pick(row, "abstract", "summary", "abstraction")),
        "法律状态": s(pick(row, "legalStatus", "legal_status", "legalState")),
        "_temp_id": pick(row, "id", "temporaryId", "_id") or "",
    }


def dedup_key(item):
    return item["公开号"]


# ---------------------------------------------------------------- fetch

def cmd_fetch(args):
    pages = max(1, min(26, args.pages))
    size = max(1, min(50, args.size))
    calls = pages
    budget = calls * PRICE_SEARCH
    print(json.dumps({
        "预算预览": {"接口调用次数": calls, "预计费用上限": f"约 ¥{budget:.2f}",
                    "说明": "按检索单价提示，真实扣费以服务端为准"},
    }, ensure_ascii=False, indent=2))
    if not args.yes:
        print(json.dumps({"提示": "仅预算预览，未联网、未写文件。确认后在命令末尾加 --yes 执行。"},
                         ensure_ascii=False))
        return

    items, seen = [], set()
    total_reported = None
    for page in range(1, pages + 1):
        payload = api_get("/api/search", {"q": args.query, "ds": args.scope,
                                          "page": page, "size": size})
        rows = rows_of(payload)
        if total_reported is None:
            total_reported = pick(payload, "total", "totalCount", "hits")
        if not rows:
            break
        for row in rows:
            item = normalize(row)
            key = dedup_key(item)
            if key == MISSING or key in seen:
                continue
            seen.add(key)
            items.append(item)
        time.sleep(0.3)

    out = {
        "检索式": args.query,
        "scope": args.scope,
        "页数": pages,
        "每页条数": size,
        "API回报命中总数": total_reported if total_reported is not None else MISSING,
        "去重后候选数": len(items),
        "抓取时间": time.strftime("%Y-%m-%d %H:%M:%S"),
        "candidates": items,
    }
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(json.dumps({"完成": f"候选 {len(items)} 件（去重后）已写入 {args.out}",
                      "命中总数回报": total_reported},
                     ensure_ascii=False))


# ---------------------------------------------------------------- template

def cmd_template(args):
    with open(args.candidates, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    items = data.get("candidates")
    if not isinstance(items, list) or not items:
        raise Fail(f"{args.candidates} 里没有可用的候选记录。")
    header = BASE_COLS + [f"标签-{c}" for c in TAG_COLS] + ["证据", "备注"]
    with open(args.out, "w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(header)
        for item in items:
            writer.writerow([item[c] for c in BASE_COLS] + [""] * (len(TAG_COLS) + 2))
    print(json.dumps({"完成": f"模板已写入 {args.out}（{len(items)} 行，标签列留空待填）",
                      "填表规则": ["标签-技术主题：1–2 个，用受控词表",
                                  "标签-应用场景：0–2 个",
                                  "标签-功能效果：0–3 个",
                                  "标签-成熟度：只按「法律状态」列填",
                                  "证据：每个标签的依据短语，用；分隔，必须出自标题或摘要原文"]},
                     ensure_ascii=False))


# ---------------------------------------------------------------- build

def split_tags(cell):
    parts = [p.strip() for p in str(cell or "").replace("|", "；").split("；")]
    return [p for p in parts if p]


def evidence_check(evidence_cell, title, abstract):
    """返回 (通过短语列表, 未命中短语列表)。空证据判未通过。"""
    phrases = split_tags(evidence_cell)
    if not phrases:
        return [], ["（未填写证据）"]
    haystack = f"{title}{abstract}".replace(" ", "").lower()
    hit, miss = [], []
    for phrase in phrases:
        needle = phrase.replace(" ", "").lower()
        (hit if needle and needle in haystack else miss).append(phrase)
    return hit, miss


def cmd_build(args):
    with open(args.result, "r", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        raise Fail(f"{args.result} 里没有数据行。")
    required = [c for c in BASE_COLS if c != "摘要"] + ["证据"]
    missing_cols = [c for c in required if c not in (rows[0] or {})]
    if missing_cols:
        raise Fail(f"CSV 缺少必需列：{'、'.join(missing_cols)}。请从 template 生成的模板填起。")

    # 可选：用候选集补全摘要，证据核验更可靠
    abstracts = {}
    if args.source_candidates and os.path.exists(args.source_candidates):
        with open(args.source_candidates, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        abstracts = {c["公开号"]: c["摘要"] for c in data.get("candidates", [])}

    table, flagged, untagged = [], [], 0
    for row in rows:
        pn = s(row.get("公开号"))
        title = s(row.get("标题"))
        abstract = s(row.get("摘要"))
        if abstract == MISSING:
            abstract = abstracts.get(pn, MISSING)
        tags = {c: split_tags(row.get(f"标签-{c}")) for c in TAG_COLS}
        n_tags = sum(len(v) for v in tags.values())
        if n_tags == 0:
            untagged += 1
        hit, miss = evidence_check(row.get("证据"), title, abstract)
        status = "通过" if not miss else "证据未命中"
        entry = {"公开号": pn, "标题": title, "申请人": s(row.get("申请人")),
                 "申请日": s(row.get("申请日")), "IPC": s(row.get("IPC")),
                 "标签": tags, "证据通过": hit, "证据未命中": miss,
                 "核验": status, "备注": s(row.get("备注"))}
        table.append(entry)
        if status != "通过":
            flagged.append(entry)

    dist = {c: {} for c in TAG_COLS}
    for entry in table:
        for col, values in entry["标签"].items():
            for v in values:
                dist[col][v] = dist[col].get(v, 0) + 1

    html = render_html(args, rows, table, dist, flagged, untagged)
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write(html)
    summary = {"完成": f"报告已写入 {args.out}", "总行数": len(table),
               "证据核验通过": len(table) - len(flagged),
               "证据核验未命中": len(flagged), "未标引行数": untagged}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if flagged:
        print(json.dumps({"警告": "存在证据未命中的标引，报告中已单列。请逐条复核："
                                  "要么改证据为摘要原文，要么删除无依据的标签。"},
                         ensure_ascii=False))


def esc(text):
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))


def render_html(args, rows, table, dist, flagged, untagged):
    def tag_cell(tags):
        parts = [f"{esc(col)}：{'、'.join(esc(v) for v in vals) if vals else '—'}"
                 for col, vals in tags.items()]
        return "<br>".join(parts)

    body_rows = []
    for e in table:
        badge = ("#1a7f37" if e["核验"] == "通过" else "#b42318")
        body_rows.append(
            "<tr><td>{pn}</td><td>{ti}</td><td>{ap}</td><td>{tag}</td>"
            "<td><span style='color:{c};font-weight:600'>{st}</span>"
            "<br><span style='color:#667085'>{ev}</span></td></tr>".format(
                pn=esc(e["公开号"]), ti=esc(e["标题"]), ap=esc(e["申请人"]),
                tag=tag_cell(e["标签"]), c=badge, st=esc(e["核验"]),
                ev="；".join(esc(p) for p in e["证据通过"]) or
                   "未命中：" + "；".join(esc(p) for p in e["证据未命中"])))

    dist_rows = []
    for col, counter in dist.items():
        if not counter:
            dist_rows.append(f"<tr><td>{esc(col)}</td><td>—</td><td>0</td></tr>")
            continue
        first = True
        for tag, count in sorted(counter.items(), key=lambda x: -x[1]):
            dist_rows.append(f"<tr><td>{esc(col) if first else ''}</td>"
                             f"<td>{esc(tag)}</td><td>{count}</td></tr>")
            first = False

    flag_html = ""
    if flagged:
        items = "".join(f"<li>{esc(e['公开号'])} {esc(e['标题'])}｜未命中："
                        f"{esc('；'.join(e['证据未命中']))}</li>" for e in flagged)
        flag_html = (f"<div class='warn'><strong>证据核验未命中 {len(flagged)} 条，"
                     f"交付前必须逐条复核：</strong><ul>{items}</ul></div>")

    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>专利标引报告</title>
<style>
body{{font-family:"Microsoft YaHei",sans-serif;margin:32px auto;max-width:1100px;color:#1d2939;line-height:1.6}}
h1{{font-size:22px}} h2{{font-size:17px;margin-top:28px;border-left:4px solid #175cd3;padding-left:10px}}
table{{border-collapse:collapse;width:100%;font-size:13px;margin-top:10px}}
th,td{{border:1px solid #d0d5dd;padding:6px 8px;text-align:left;vertical-align:top}}
th{{background:#f2f4f7}}
.meta{{color:#667085;font-size:13px}}
.warn{{background:#fef3f2;border:1px solid #fda29b;border-radius:6px;padding:10px 14px;margin-top:14px;font-size:13px}}
.note{{background:#f8f9fc;border:1px solid #e4e7ec;border-radius:6px;padding:10px 14px;margin-top:14px;font-size:13px;color:#475467}}
</style></head><body>
<h1>专利技术标引报告</h1>
<p class="meta">检索式：{esc(args.query if hasattr(args, "query") and args.query else "（见标引结果 CSV）")}｜
数据源：PatentMax API（IPRDB：CN/US/EP/JP/KR/WIPO）｜生成时间：{time.strftime('%Y-%m-%d %H:%M')}</p>
<p class="meta">标引行数 {len(table)}｜核验通过 {len(table) - len(flagged)}｜证据未命中 {len(flagged)}｜未标引 {untagged}</p>
{flag_html}
<h2>标签分布</h2>
<table><tr><th>维度</th><th>标签</th><th>件数</th></tr>{''.join(dist_rows)}</table>
<h2>逐件标引明细</h2>
<table><tr><th>公开号</th><th>标题</th><th>申请人</th><th>标签（技术主题/应用场景/功能效果/成熟度）</th><th>证据核验</th></tr>
{''.join(body_rows)}</table>
<div class="note"><strong>边界说明：</strong>本报告是对检索样本的逐件打标，标签由标题与摘要归纳并经证据短语核验，不代表专利价值评级，不构成法律意见；成熟度仅按检索时接口返回的法律状态标注，正式场合需以官方登记簿为准。摘要未提供的记录以「未获取」标示，不做补猜。</div>
</body></html>"""


# ---------------------------------------------------------------- selfcheck

def cmd_selfcheck(args):
    ok = []

    # 证据命中
    hit, miss = evidence_check("充磁；电镀工艺", "磁体充磁自动化控制软件", "用于钕铁硼电镀工艺监控")
    ok.append(("证据全部命中", hit == ["充磁", "电镀工艺"] and miss == []))
    hit2, miss2 = evidence_check("量子纠缠", "磁体充磁", "电镀监控")
    ok.append(("不相关短语判未命中", hit2 == [] and miss2 == ["量子纠缠"]))
    ok.append(("空证据判未通过", evidence_check("", "标题", "摘要")[1] == ["（未填写证据）"]))

    # 标签拆分
    ok.append(("标签按；与|拆分", split_tags("A；B|C") == ["A", "B", "C"]))
    ok.append(("空白标签剔除", split_tags("；A； ") == ["A"]))

    # 归一化：字段缺失写未获取
    item = normalize({"documentNumber": "CN1A", "title": "t"})
    ok.append(("缺失字段标未获取", item["申请人"] == MISSING and item["IPC"] == MISSING))

    # 去重键
    ok.append(("去重键取公开号", dedup_key(normalize({"pn": "CN1", "abstract": "x"})) == "CN1"))

    failed = [name for name, passed in ok if not passed]
    print(json.dumps({"自检项": len(ok), "通过": len(ok) - len(failed),
                      "失败": failed or "无"},
                     ensure_ascii=False, indent=2))
    sys.exit(1 if failed else 0)


# ---------------------------------------------------------------- main

def main():
    parser = argparse.ArgumentParser(description="PatentMax 标引流水线")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("fetch", help="按检索式取候选集（默认只报预算）")
    p.add_argument("--query", required=True, help="PatentMax 检索式")
    p.add_argument("--scope", default="all", choices=["all", "cn"])
    p.add_argument("--pages", type=int, default=2)
    p.add_argument("--size", type=int, default=50)
    p.add_argument("--out", default="候选集.json")
    p.add_argument("--yes", action="store_true", help="确认预算后联网执行")
    p.set_defaults(func=cmd_fetch)

    p = sub.add_parser("template", help="从候选集生成标引模板 CSV")
    p.add_argument("--candidates", required=True)
    p.add_argument("--out", default="标引模板.csv")
    p.set_defaults(func=cmd_template)

    p = sub.add_parser("build", help="核验标引结果并出 HTML 报告")
    p.add_argument("result", help="填好的标引结果 CSV")
    p.add_argument("--source-candidates", default="", help="候选集 JSON，用于补摘要做证据核验")
    p.add_argument("--query", default="", help="写进报告头的检索式")
    p.add_argument("--out", default="标引报告.html")
    p.set_defaults(func=cmd_build)

    p = sub.add_parser("selfcheck", help="离线自检（不联网）")
    p.set_defaults(func=cmd_selfcheck)

    args = parser.parse_args()
    try:
        args.func(args)
    except Fail as exc:
        print(json.dumps({"error": True, "message": str(exc)}, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
