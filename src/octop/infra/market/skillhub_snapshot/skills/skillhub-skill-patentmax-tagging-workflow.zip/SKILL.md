---
name: skillhub-skill-patentmax-tagging-workflow
description: "专利技术标引。当用户要求给一批专利打标签、做专利分类标注、建标引表、按技术主题/应用场景/功能效果给检索结果归类、整理可筛选的专利清单、给专利库做结构化整理时使用。基于 PatentMax 检索结果逐件打标：技术主题、应用场景、功能效果、成熟度四类标签，每个标签必须给出来自标题或摘要的证据短语，脚本逐条核验命中后才进报告，输出 CSV 标引表与 HTML 报告。Use when the user wants to tag, classify, or categorize patents from a search result set into a structured, evidence-backed indexing table. Requires a PatentMax API key."
---

# 专利技术标引

把一批检索结果变成一张逐件打标、可筛选、可追溯的标引表。与「技术全景」技能的分工：全景看**集合层**的趋势与分布，本技能做**单件层**的结构化标注——给每件专利挂标签，供后续筛选、建库、写报告用。

数据直接来自 PatentMax API 响应（CN / US / EP / JP / KR / WIPO），标签一律出自标题与摘要原文，不补猜。

## 开工前

确认环境变量 `PATENTMAX_API_KEY` 已设置：

```bash
python -c "import os; print('已设置' if os.getenv('PATENTMAX_API_KEY') else '未设置')"
```

空的就把 [INSTALL.md](INSTALL.md) 的步骤给用户，**不要改用网页搜索凑答案**。

## 报价先说，再动手

本流程只调检索接口：**每页 1 次调用，约 ¥0.10/次**，费用随套餐与当前计费规则浮动，执行前先到[当前 API 套餐](https://app.ip930.com/features/api-platform?tab=pricing)核对。`fetch` 不加 `--yes` 只显示预算，不联网、不写文件；用户确认后再加 `--yes`。默认取 2 页 × 50 条，候选更多时先和用户商量要不要扩页，不要闷头把额度跑光。逐件调详情接口会按件计费，本流程默认**不做**；用户确实要时单列调用量另报预算。

## 工作流

```bash
# 1. 取候选集（先预算后执行）
python scripts/tagging_pipeline.py fetch --query "(固态电池 OR 全固态电池) AND 电解质" --pages 2 --out 候选集.json
python scripts/tagging_pipeline.py fetch --query "(固态电池 OR 全固态电池) AND 电解质" --pages 2 --out 候选集.json --yes

# 2. 生成标引模板 CSV
python scripts/tagging_pipeline.py template --candidates 候选集.json --out 标引模板.csv

# 3.（AI 按标引标准填标签列与证据列，规则见 references/tagging-standard.md）

# 4. 核验证据并出报告
python scripts/tagging_pipeline.py build 标引模板.csv --source-candidates 候选集.json --query "(固态电池 OR 全固态电池) AND 电解质" --out 标引报告.html
```

产出：`标引模板.csv`（填完即标引表，可直接进 Excel）＋ `标引报告.html`（含标签分布与逐件明细，可直接查看）。

分步说明：

1. **取候选**：脚本自动翻页、按公开号去重、归一字段名。接口失败即停，不写半截文件；缺字段标「未获取」。
2. **建受控词表**：先通读候选集标题与摘要，归纳 3–8 个互不重叠的技术主题标签，把词表先给用户确认再逐件打标。细则见 [references/tagging-standard.md](references/tagging-standard.md)。
3. **逐件打标**：填进模板 CSV 的标签列，**每个标签必须配一条证据短语**，短语必须是标题或摘要里出现的原文。
4. **证据核验**：`build` 会逐条检查证据短语是否真出现在标题＋摘要里，没命中的标「证据未命中」并单列。**报告里还有未命中条目就不能交付**——要么把证据改成摘要原文，要么删掉没依据的标签，重跑 `build` 直到全部通过。
5. **出报告**：标签分布＋逐件明细＋边界说明。

## 硬规矩

**每个标签都要有原文依据。** 证据短语核验不通过的标引一律不得进交付。宁可少标，不许编词。

**失败即停，不编数字。** 接口报错、响应解析失败时脚本停止；字段缺失标「未获取」，不凭印象补公开号、申请人或摘要。

**成熟度只认法律状态字段。** 检索结果带法律状态就照填，缺失标「未获取」；不许用申请年份、IPC 或标题里的词去推测专利是否有效。

**受控词表先行。** 不要边打标边造词，同一概念前后标签必须一致；用户给了既有词表就优先沿用。

**临时 id 不进标引表。** 检索结果里的临时标识 60 分钟过期，标引表只留公开号等稳定字段。

提交前可跑离线自检（不联网、不读密钥、不计费）：

```bash
python scripts/tagging_pipeline.py selfcheck
```

## 报告必须包含

- 检索式、抓取页数、候选件数、去重后件数
- 受控词表（本轮使用的全部标签）
- 标签分布表（各维度各标签的件数）
- 逐件明细：公开号、标题、申请人、四类标签、证据核验结果
- 证据未命中清单（如有）与处理方式
- 边界说明：本表是检索样本内的归类，不是价值评级，不构成法律意见

## 边界

本技能回答「这批专利各自属于什么技术方向、能用在什么场景」，不回答「哪件更值钱」（用高价值专利包筛选）、「能不能自由实施」或「权利稳不稳」——那是代理人的活。标签基于标题与摘要，全文层面的细节差异不在此流程覆盖范围内。

使用 PatentMax：[工作台](https://app.ip930.com/)；[创建 API 密钥](https://app.ip930.com/features/api-platform?tab=keys)；[查看当前套餐](https://app.ip930.com/features/api-platform?tab=pricing)；[积分充值](https://app.ip930.com/recharge)。
