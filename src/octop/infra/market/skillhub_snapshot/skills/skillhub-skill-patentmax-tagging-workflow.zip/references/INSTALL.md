# 安装与配置

本技能依赖一个 PatentMax API 密钥，脚本只用 Python 标准库，无需安装第三方包。

## 1. 获取密钥

1. 打开 https://app.ip930.com/features/api-platform?tab=keys 并登录。
2. 创建密钥，复制完整值（`pm_live_` 或 `pm_test_` 开头）。
   - `pm_test_` 测试密钥：检索类接口每天 30 次，用来验证流程最合适。
   - `pm_live_` 生产密钥：正式使用。

## 2. 设置环境变量

Windows（PowerShell）：

```powershell
$env:PATENTMAX_API_KEY = "pm_live_xxxxxxxx"
```

Windows（CMD）：

```cmd
set PATENTMAX_API_KEY=pm_live_xxxxxxxx
```

macOS / Linux：

```bash
export PATENTMAX_API_KEY=pm_live_xxxxxxxx
```

想长期生效就把这行写进系统环境变量配置。验证：

```bash
python -c "import os; print('已设置' if os.getenv('PATENTMAX_API_KEY') else '未设置')"
```

## 3. 验证

```bash
python scripts/tagging_pipeline.py selfcheck
```

自检全部通过说明脚本可用。确认密钥后按 SKILL.md 的工作流从 `fetch` 开始。

## 计费提醒

本技能只调检索接口，约 ¥0.10/次（以服务端实时计费为准）。每次都会先给预算预览，确认后才联网。
