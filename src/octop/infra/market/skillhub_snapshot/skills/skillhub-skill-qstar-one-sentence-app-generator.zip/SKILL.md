---
name: skillhub-skill-qstar-one-sentence-app-generator
description: "# Q-Star 一句话生成 Android App"
---

# Q-Star 一句话生成 Android App

## 能力说明

把用户的一句话 App 需求生成可下载的 Android APK。服务端在支付确认后调用 Q-Star 国内构建节点完成 AI 代码生成、Gradle 编译、自动修复、签名和下载交付。

## 输入

- `prompt`：App 功能、页面和交互需求，必填
- `package_name`：可选，合法 Android 包名；不填则自动生成

## 输出

- APK 下载地址
- 应用包名
- 构建状态和完成时间
- 构建失败时的可诊断错误

## 约束

- 仅交付 Android APK，不承诺应用商店上架、后端服务或生产数据接入。
- 不在 Skill 包内保存密钥、Token、支付证书或完整 Cookie。
- 构建失败不交付不完整文件；服务端按付费服务规则处理失败退款。
- 不执行用户未明确授权的外部发布、登录、支付或数据写入。

## 收费调用接口

- 接口：`POST https://skill-api.q-star.ink/v1/skills/qstar-one-sentence-app-generator/invoke`
- 单次调用：人民币 29.90 元。
- 只有支付确认后才会启动 Android 构建。

**本 Skill 是异步交付，不要同步等待。** Android 构建通常需要 4–10 分钟，远超一次 HTTP 连接的存活时间（服务端反向代理 60 秒即断开）。调用方必须实现轮询循环。

### 三步流程

1. **首次请求** → `HTTP 402` `PAYMENT_REQUIRED`。保存响应中的 `WeixinPay-Required` 与 `X-Out-Trade-No`，完成 SkillHub/微信支付授权。
2. **支付后携原 `X-Out-Trade-No` 和逐字节一致的原始请求体重试** → `HTTP 202` `FULFILLMENT_IN_PROGRESS`，响应含 `poll_url`、`poll_interval_seconds`（30）、`estimated_seconds`（约 420）。此时构建已在服务端启动，**不要重复下单**。
3. **每 30 秒轮询一次**，直到取回结果：
   - 查状态：`GET /v1/skills/qstar-one-sentence-app-generator/status?out_trade_no=<订单号>`，返回 `order_status`、`build_status`、`ready`。该接口只回状态，不回结果。
   - 取结果：用原 `X-Out-Trade-No` 和原始请求体再次 `POST` invoke。完成后返回 `HTTP 200` `SUCCESS`，`data` 内含 `download_url`、`package_name`、`apk_path` 和 `finished_at`。

收到 `202` 就放弃、或因连接超时而放弃，会导致已付款但拿不到 APK。

### 状态码处理

| 状态码 | code | 含义与处理 |
|---|---|---|
| 402 | `PAYMENT_REQUIRED` | 尚未下单支付。按响应发起支付授权 |
| 402 | `PAYMENT_NOT_CONFIRMED` | 支付未确认。稍后携原订单号重试 |
| 202 | `FULFILLMENT_IN_PROGRESS` | **构建进行中，正常状态**。按 `poll_interval_seconds` 每 30 秒重试 |
| 409 | `FULFILLMENT_IN_PROGRESS` | 并发重试撞上另一个进行中的请求。同样等待 30 秒后重试 |
| 200 | `SUCCESS` | 交付完成。`already_fulfilled: true` 表示这是重复取回，不会重复计费 |
| 409 | `REQUEST_MISMATCH` | 请求体与下单时不一致。必须用原始请求体，逐字节相同 |
| 409 | `ORDER_REFUNDED` | 该订单已退款，不再交付。如需重来请重新下单 |
| 202 | `REFUND_PROCESSING` | 履约失败，退款处理中。无需重试 |
| 500 | `FULFILLMENT_FAILED` | 构建失败，**已自动发起原路退款**。不交付不完整文件 |
| 500 | `FULFILLMENT_AND_REFUND_FAILED` | 构建失败且自动退款未完成，已记录订单等待人工处理。请凭订单号联系服务方 |

### 计费与退款

- 按成功交付计费。构建失败时服务端置订单为失败并发起原路退款，不交付不完整文件。
- 结果幂等：交付完成后重复请求返回同一结果并带 `already_fulfilled: true`，不重复计费。
- 请求体必须逐字节一致；改动请求体返回 `409 REQUEST_MISMATCH`，不会另行计费。

## 示例请求

```json
{
  "prompt": "一个每日习惯打卡 App，可以添加习惯、标记完成，并显示今日完成数量。",
  "package_name": "com.example.habitcheck"
}
```
