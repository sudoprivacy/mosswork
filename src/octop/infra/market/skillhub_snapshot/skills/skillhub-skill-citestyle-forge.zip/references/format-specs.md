# 参考文献格式识别与解析规范

## 一、常见引用格式快速识别表

| 格式 | 关键特征 | 示例（期刊文章） |
|------|---------|-----------------|
| **GB/T 7714（顺序编码制）** | 方括号编号 `[1]`；中文文献标注 `[J]`（期刊）`[M]`（专著）`[C]`（会议）`[D]`（学位论文）`[N]`（报纸）`[S]`（标准）`[P]`（专利）`[EB/OL]`（电子资源）；年份后逗号接卷(期) | `[1] 张三, 李四. 论文标题[J]. 中国科学, 2023, 12(3): 45-52.` |
| **GB/T 7714（著者-出版年制）** | 无编号，括号年份 `(2023)` | `张三, 李四, 2023. 论文标题. 中国科学 12(3), 45-52.` |
| **APA (7th)** | 括号年份、作者 `Family, F. F.`、期刊斜体、卷(期)斜体加粗混合、DOI 以 `https://doi.org/` 开头 | `Smith, J. A., & Doe, B. C. (2023). Article title. Journal Name, 12(3), 45–52. https://doi.org/10.xxxx/xxxx` |
| **MLA (9th)** | 无年份前置、页码在末尾、期刊名斜体、卷.期格式 `vol, no. issue` | `Smith, John A., and Bob C. Doe. "Article Title." Journal Name, vol. 12, no. 3, 2023, pp. 45–52.` |
| **Chicago (Notes-Bibliography)** | 标题带引号、出版地: 出版社, 年份 | `Smith, John A. "Article Title." *Journal Name* 12, no. 3 (2023): 45–52.` |
| **Vancouver / AMA** | 上标或方括号编号、期刊缩写、无 DOI、页码 `:P-P.` | `1. Smith JA, Doe BC. Article title. J Name. 2023;12(3):45-52.` |
| **IEEE** | 方括号编号 `[1]`、作者缩写 `J. A. Smith`、标题带引号、卷/期/页用缩写词 `vol., no., pp.` | `[1] J. A. Smith and B. C. Doe, "Article title," J. Name, vol. 12, no. 3, pp. 45–52, 2023.` |
| **ACS** | 斜体期刊缩写、年份加粗、`DOI: 10.xxx` | `Smith, J. A.; Doe, B. C. Article Title. *J. Name* **2023**, *12*, 45–52. DOI: 10.xxxx/xxxx.` |
| **Harvard / Elsevier 著者-出版年** | `(2023)` 年份、`pp.` 页码、`doi:` 小写 | `Smith, J.A., Doe, B.C., 2023. Article title. J. Name 12 (3), 45–52. doi:10.xxxx/xxxx.` |
| **Springer 基础样式（编号制）** | 类似 IEEE 但无引号或结构稍异 | `1. Smith JA, Doe BC (2023) Article title. J Name 12:45–52` |
| **Science China Press 系** | 裸数字编号（无方括号无句点）、作者 `Family Initials`、年份在刊名后、卷后冒号接页码 | `1 Yu Y, Nakano M. Article title. Nature, 2003, 425: 145` |
| **Nature / Science 系** | 上标编号、期刊名加粗、卷加粗、无期号 | `Smith, J. A. & Doe, B. C. Article title. *J. Name* **12**, 45–52 (2023).` |
| **RSC 系（Chem. Soc. Rev. / Chem. Sci. / CrystEngComm 等）** | 顺序编号（无方括号或带句点）、末位作者前用 `and`、期刊缩写斜体、无标题、`年, 卷, 页码` | `1 K. N. Kim, Q. Y. Huang and C. L. Lei, Pest Manage. Sci., 2019, 75, 3135–3143.` |
| **Wiley 化学系（Angew. Chem. / Chem. Eur. J.）** | 方括号编号 `[1]`、一个编号下用 `a) b) c)` 合并多篇、作者缩写前置、无标题无期号无 DOI、e-locator 常见 | `[2] a) Y.-J. Ma, J.-J. Shi and Z.-Q. Liu, *Angew. Chem., Int. Ed.* **2023**, *62*, e202217054; b) ...` |
| **Wiley Advanced 系（Adv. Mater. / Adv. Opt. Mater. / Adv. Funct. Mater.）** | 方括号编号、同样省略标题与 DOI、年份紧随期刊缩写、卷后接文章号 | `[6] X. Zhang, Y. Li, *Adv. Mater.* **2019**, *31*, 1804540.` |

识别要点：
1. 先看编号方式：方括号 `[1]` / 上标 / 无编号（著者-出版年制）。
2. 看中文文献标识 `[J]/[M]/[C]` → GB/T 7714。
3. 看年份位置：开头括号 → APA/Harvard；末尾 → IEEE/Nature。
4. 看缩写词：`vol./no./pp.` → IEEE；`J. Name.` → Vancouver。
5. 期刊正文首页的"参考文献格式说明"(Guide for Authors / 投稿须知) 若可见，直接以其为准。

## 二、文献类型判定（GB/T 标识 → 内部类型）

| GB/T 标识 | 内部 type | 说明 |
|-----------|-----------|------|
| `[J]` | journal | 期刊文章 |
| `[M]` | book | 专著 |
| `[G]` | book | 汇编 |
| `[C]` | conference | 会议论文集 |
| `[D]` | thesis | 学位论文（institution = 授予单位）|
| `[N]` | newspaper | 报纸文章 |
| `[S]` | standard | 标准（标准号放 note 或 title 后）|
| `[P]` | patent | 专利 |
| `[R]` | report | 报告 |
| `[EB/OL]` `[J/OL]` | webpage / preprint | 电子资源 / 网络优先出版 |
| arXiv / bioRxiv / SSRN | preprint | 预印本 |

西文格式无类型标识时按结构判定：有 journal + vol + pages → journal；有 publisher + address 无卷期 → book；有 "In:" 或 "eds." → chapter；有 "Proc."/"Conference"/"Symposium" → conference；有 "Ph.D./Master thesis/dissertation" → thesis；有 URL 无卷期 → webpage。

## 三、解析注意事项（高优先级）

1. **去掉排版噪声**：`<b> <i> <sup>` 标签、DOI 超链接文字、上下标标记、多余空格和换行，在写入 JSON 前清除。
2. **作者完整列表**：不要截断 `et al.` / `等`，从原文尽力恢复全部作者；无法恢复时在 note 中注明 "原文献以 et al. 截断"。
3. **中文作者**：`张三` → family=`张`, given=`三`；复姓（欧阳、司马、诸葛、上官、司徒）→ family=复姓。
4. **西方作者**：`Smith, J. A.` → family=`Smith`, given=`J. A.`；`J. A. Smith` → family=`Smith`, given=`J. A.`。
5. **页码**：保留起止页 `45-52`（连字符统一为 `-`）；单页/e-locator 原样保留。
6. **DOI**：统一去掉 `https://doi.org/` 与 `doi:` 前缀，只留 `10.xxxx/xxxx`。
7. **年份**：只保留 4 位年份数字。
8. **无法确定的字段**：宁缺毋滥，置空字符串，不要臆造（尤其是卷、期、页码）。
9. **逐条对应**：输出条目顺序与原文编号顺序一致，便于用户核对。
10. **期刊自家样式的固有省略**：RSC / Wiley 系样式本身不著录文章标题与 DOI，此时 title/doi 留空属正常，不要视为缺失字段，也不必补造。
11. **合并编号（a/b/c 子条目）**：Wiley 系常见 `[2] a) ...; b) ...; c) ...` 一个编号合并多篇文献。拆分为独立条目，顺序保持原编号内顺序，并在 note 中标注原编号（如 `[25]a`）。
12. **软件引用**（Gaussian、CrystalExplorer 等）：type 按最接近的判（report/book），作者保留原文所列，版本号放 note。
13. **Nature 系 et al. 截断**：Nature 系正文样式只印首作者+et al.，JSON 只恢复首作者并在 note 注明"原文以 et al. 截断"。

## 四、输出 JSON Schema

顶层为数组，每条：
```json
{
  "type": "journal",
  "authors": [{"family": "Smith", "given": "J. A."}, {"family": "张", "given": "三"}],
  "title": "Article title",
  "container": "Journal full name / 书名 / 会议论文集名",
  "container_short": "期刊缩写（如原文用缩写且能识别全称，两者都给）",
  "year": "2023",
  "volume": "12",
  "issue": "3",
  "pages": "45-52",
  "publisher": "出版社",
  "address": "出版地",
  "edition": "3rd ed.",
  "editors": [{"family": "Wang", "given": "L."}],
  "doi": "10.1000/xyz123",
  "url": "https://...",
  "accessed": "2024-05-01",
  "institution": "学位论文授予单位 / 报告发布机构",
  "language": "zh 或 en",
  "note": "其他信息（标准号、专利号、et al. 截断说明等）"
}
```
authors 数组元素允许纯字符串（`"Smith, J. A."` 或 `"张三"`），脚本会自动归一化。
