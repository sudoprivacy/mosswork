# 引文样式文件生成指南（.csl / EndNote 样式配方）

## 一、需要从样本中提取的样式特征清单

生成样式文件前，从参考文献页（及正文中的文内引用）逐项确认以下特征：

**A. 引用体系**
- 数字编号制（numeric）还是著者-出版年制（author-date）
- 文内引用形态：上标数字（如 RSC、Nature）/ 方括号 `[1]`（IEEE、GB/T 7714）/ 圆括号 `(1)` / `(Author, Year)`
- 连续编号是否折叠（`[1-3]` vs `[1,2,3]`）

**B. 参考文献表条目结构（以期刊论文为例，按元素逐项记录）**
| 元素 | 需要确认的问题 |
|------|--------------|
| 作者 | 缩写前置还是后置（`J. A. Smith` vs `Smith, J. A.`）；缩写带点否、点后有空格否（`J.A.` vs `J. A.`）；分隔符（逗号/分号/空格）；末位作者前有无 `and`/`&`；et al. 阈值（≥N 人时只列前 M 人） |
| 标题 | 有无文章标题；是否加引号；句首大写还是标题式大写 |
| 刊名 | 全称还是缩写；是否斜体 |
| 年份 | 位置（作者后括号内 / 刊名后 / 条目末尾）；是否加粗 |
| 卷/期 | 卷是否加粗或斜体；期号有无、是否括号包裹 |
| 页码 | 起止页还是仅起始页；有无 `pp.`/`p.` 前缀；是否文章号（e-locator） |
| DOI | 有无；前缀形态（`doi:` / `DOI:` / `https://doi.org/`） |
| 条末标点 | 句点或其他 |

**C. 其他文献类型**：专著、会议、学位论文、专利、网页的著录结构（若样本中有）。

## 二、基准样式选取表（CSL 官方库）

官方库地址：`https://github.com/citation-style-language/styles`，
单文件 raw 下载：`https://raw.githubusercontent.com/citation-style-language/styles/master/<文件名>.csl`
按期刊名搜索：`https://www.zotero.org/styles?q=<期刊名>`

| 样式族 | 候选基准文件名 | 备注 |
|--------|--------------|------|
| RSC 系 | `royal-society-of-chemistry.csl` | 上标数字、无标题、年卷页 |
| ACS 系 | `american-chemical-society.csl` | 斜体刊名、年份加粗 |
| Nature 系 | `nature.csl` | 上标、卷加粗、年份末尾括号 |
| IEEE | `ieee.csl` | `[1]` 方括号编号 |
| Vancouver | `vancouver.csl` | 医学期刊 |
| APA 7 | `apa.csl` | 著者-出版年 |
| MLA 9 | `modern-language-association.csl` | |
| Chicago 著者-出版年 | `chicago-author-date.csl` | |
| Elsevier 编号（带标题） | `elsevier-with-titles.csl` | |
| Elsevier 编号（不带标题） | `elsevier-without-titles.csl` | |
| GB/T 7714-2015 顺序编码 | `china-national-standard-gb-t-7714-2015-numeric.csl` | 双语能力已合并进此文件（zh locale 机制）；独立的 `-bilingual` 后缀文件已不存在 |
| GB/T 7714-2015 著者-出版年 | `china-national-standard-gb-t-7714-2015-author-date.csl` | 同上，双语已合并 |
| Springer 基础（编号） | `springer-basic-brackets-no-et-al.csl` 等 | 变体多，先搜索 |
| Wiley 化学系（Angew./Chem. Eur. J. 等） | `angewandte-chemie.csl` | 官方库无 `chemistry-a-european-journal.csl`，以此同族样式为基准改造 |
| Wiley Advanced 系 | `advanced-materials.csl`、`advanced-optical-materials.csl` 等 | 多种 Advanced 子刊有独立样式，先按刊名搜索 |

注意事项：
1. 上表文件名以实际为准——raw URL 返回 404 时，立即改用 zotero.org/styles 搜索页确认真实文件名后再下载。
2. 许多期刊专用样式是 **dependent 样式**（整个文件只有十几行、含 `<link rel="independent-parent">`、无 citation/bibliography 定义）。dependent 样式不能作为修改基准——找到后按其 parent 链接下载父样式再改。
3. 下载的基准样式若与样本特征完全吻合，直接改 `<info>` 后交付，不必强行修改正文。

## 三、常见 CSL 修改模式（patch 配方）

> **冲突仲裁原则**：基准样式与样本特征冲突时，先回原文复核特征提取是否有误，再决定 patch——官方库样式的维护质量通常高于一次性特征提取。例如 Nature 系参考文献**含**文章标题，误判为"无标题"而删除 title 会造成错误分叉。

**文内引用形态**（`<citation>` 的 `<layout>`）：
```xml
<!-- 上标数字（RSC/Nature） -->
<layout delimiter="," vertical-align="sup">
  <text variable="citation-number"/>
</layout>
<!-- 方括号（IEEE/GB-T 7714） -->
<layout delimiter=", " prefix="[" suffix="]">
  <text variable="citation-number"/>
</layout>
<!-- 著者-出版年 -->
<layout prefix="(" suffix=")" delimiter="; ">
  <group delimiter=", ">
    <text macro="author-short"/>
    <text macro="issued-year"/>
  </group>
</layout>
```

**作者格式**（`<name>` 元素属性）：
- 缩写带点带空格：`initialize-with=". "`；带点无空格：`initialize-with="."`
- 姓在前：`name-as-sort-order="all"`（或 `first`）
- 分隔符：`delimiter=", "` 或 `delimiter="; "`
- 末位前 and：`and="text"`（英文 and）；`and="symbol"`（&）；无 and：去掉 and 属性
- et al.：`<name ... et-al-min="4" et-al-use-first="1"/>`（≥4 人只列首作者）
- GB/T 7714 中文 et al. 显示"等"：在 `<locale xml:lang="zh-CN">` 中重定义 `<term name="et-al">等</term>`（GB/T 基准样式已内置，勿删）

**参考文献表编号**：
```xml
<bibliography second-field-align="flush" entry-spacing="0">
  <layout suffix=".">
    <text variable="citation-number"/>   <!-- 条目前编号，配合 second-field-align 悬挂对齐 -->
```

**元素排版**：
- 刊名斜体：`<text variable="container-title" font-style="italic" form="short"/>`（`form="short"` = 缩写，依赖条目中存有 journalAbbreviation）
- 卷加粗：`<text variable="volume" font-weight="bold"/>`
- 期号括号：`<group prefix="(" suffix=")"><text variable="issue"/></group>`
- 无标题：删掉 layout 中对 title macro 的引用
- DOI：`<text variable="DOI" prefix="https://doi.org/"/>`（或 `DOI: ` 前缀）

**分叉（fork）基准样式后必须修改 `<info>`**：
1. `<title>` 改为目标期刊名；
2. `<id>` 与 `<link rel="self">` 改为 `http://www.zotero.org/styles/<新样式名>`（小写连字符，全网唯一）；
3. `<updated>` 改为当前时间戳（用 shell `date -u +%Y-%m-%dT%H:%M:%S+00:00` 获取，不要手算）；
4. 保留 `<rights>`（CC-BY-SA 许可要求）；在 `<contributor>` 中可添加生成本样式的说明。

## 四、EndNote 样式（.ens 获取 + 配方兜底）

`.ens` 是 Clarivate 私有二进制格式（MIME application/octet-stream，文本编辑器不可读），任何离线工具都无法可靠编写——只有 EndNote 软件本身能生成合法 .ens。**不要尝试手写二进制。**

**获取策略（按序）：**
1. 官方样式库 `https://endnote.com/downloads/styles/`（7000+ 样式，该站对 curl 返回 403，用 WebFetch 访问）：按期刊名搜索，命中则下载真 .ens 交付或把官方下载链接给用户。
2. 未命中时交付样式配方（下文），用户按方在 EndNote 中 3 分钟建成：`Edit → Output Styles → New Style`，逐项粘贴。

**配方文件需包含以下小节（每节给出可直接粘贴的内容）：**

1. **Citations → Templates**：文内引用模板，如 `[Bibliography Number]` 或 `(Author, Year)`
2. **Bibliography → Templates**：按文献类型各一行模板。EndNote 字段名：`Author` `Title` `Journal` `Secondary Title` `Volume` `Issue` `Pages` `Year` `DOI` `URL` `Publisher` `City` `Edition`。特殊符号：`|`（强制分隔，两侧空格仅在前一字段非空时保留）、`` ` ``（强制相邻，把标点绑定到前一字段）、`^`（单复数关联）
3. **Bibliography → Author Name**：名缩写格式（如 `A B.` / `A.B.`）、姓前姓后
4. **Author Lists**：et al. 阈值（如 "If 4 or more authors, list the first 1, abbreviate with et al."）
5. **Sort Order**：Order of appearance（数字制）/ Author + Year（著者-出版年）

示例（ACS 期刊文献模板）：
```
Journal Article: Author. Title. Journal Year, Volume (Issue), Pages.
```
示例（GB/T 7714 期刊文献模板）：
```
Journal Article: Author. Title[J]. Journal, Year, Volume(Issue): Pages.
```
（`[J]` 等类型标识在 EndNote 中需直接作为字面字符写入模板。）

## 五、NoteExpress 样式（.nes 获取 + 配方兜底）

`.nes` 同样是私有格式（实测公开样本文件头为二进制、非 XML，尽管部分教程称其"XML 架构"），无法离线凭空编写。术语澄清：`.nbib` 是 PubMed/NoteExpress 的**题录数据**交换格式，不是样式文件；NE 的引文样式文件是 `.nes`。

**获取策略（按序）：**
1. **NE 内置样式**：NoteExpress 内置 5000+ 期刊样式，提醒用户先在软件内搜索：主菜单 → 工具 → 样式 → 样式管理器 → 快速查找期刊名。命中最省事。
2. **公开渠道下载**：搜索 `<期刊名> .nes 下载`（高校图书馆页面、官方论坛 bbs.inoteexpress.com、GitHub）。下载后**先查文件头**：`<?xml` 开头则可作为基准 patch（罕见）；二进制则原样交付，用户在样式管理器点"安装"导入。
3. **NE 配方兜底**：按下文生成 `<期刊名>-noteexpress-style-recipe.txt`。

**NE 配方文件需包含以下小节**（对应 NE 样式编辑器左侧选项卡，每节给出可直接照抄的设置）：

1. **常规**：样式名称（填期刊名）、类别、注释
2. **引文 → 模板**：正文标号格式，如 `[序号]`（设为上标）或 `(作者, 年份)`
3. **题录 → 模板**：按题录类型各一行字段排列。NE 字段通过"插入字段"按钮插入：`作者` `标题` `期刊` `年` `卷` `期` `页码` `DOI` 等，标点直接键入
4. **题录 → 作者列表**：连接规则与连接符；缩写规则分 **Chinese / English 两个标签页**分别设置（中文"等"、英文"et al."），如"如果 4 个或更多，列出前 3 个作者"
5. **题录 → 作者姓名**：姓名格式（姓前/名前）、大小写（如姓全大写）、简写形式
6. **期刊命名格式**：全称 / 缩写 1 / 缩写 2，词首字母大写
7. **页码格式**：不改变 / 仅起始页；页码范围分隔符（`-`）
8. **日期格式**：一般选"不替换"

示例（GB/T 7714 期刊文章题录模板）：
```
期刊文章: 作者. 标题[J]. 期刊, 年, 卷(期): 页码.
```
（`[J]` 等类型标识作为字面字符直接键入模板；NE 内置多套 GB/T 7714 样式，中文期刊通常无需自建，提醒用户先搜内置库。）

**配方 → 可导入 .nes 的落地路径**（写进每个 NE 配方文件开头）：
1. NE → 工具 → 样式 → 样式管理器 → 新建样式（更省事的做法：先选中一个最接近的内置样式 → 编辑 → 另存为，再按配方逐项改）；
2. 按配方各小节在左侧选项卡逐项填入，保存时命名为期刊名 —— 此时样式已可直接使用；
3. 需要可分发/可导入的 `.nes` 文件时：样式管理器中选中该样式 → 导出（或另存为）即得 `.nes`；他人通过 样式管理器 → 安装新的样式 导入，或直接拷贝到 NE 安装目录 `Styles\` 后刷新。
4. `.nes` 为私有二进制，任何离线工具（包括本 skill）都无法代写——第 1–2 步的人工操作不可替代，约 3 分钟。

## 六、Wiley 系 a/b/c 合并编号后处理（wiley_abc_merge.py）

**结论先说**：「一个编号下 a) b) c) 合并多篇文献」在 CSL 1.0、EndNote、NoteExpress 中均**无法**由样式文件自动产生（官方 angewandte-chemie.csl 同样做不到），它是排版阶段的合并操作。因此样式文件按常规「一篇一个编号」交付，合并由 `scripts/wiley_abc_merge.py` 在投稿前完成。

**工作流**：
1. 用户在 Word 中去域化（Zotero: Unlink Citations / EndNote: Convert to Plain Text），另存纯文本 .txt；
2. 用户给出分组指令 groups.json，如 `[[2,3],[5,6,7]]`（哪些文献同处引用需合并，只有作者知道，不猜测）；
3. 运行 `python wiley_abc_merge.py 稿件.txt groups.json -o 输出.txt`；
4. 输出粘贴回 Word 投稿。

**脚本规则**（Angew./Chem. Eur. J. 惯例）：
- 每组占一个新编号，组内依次 a, b, c；未分组编号保持独立；
- 参考文献表合并为一行：`[n] a) 条目1 b) 条目2 …`；条目可跨行；
- 文内引用恰好覆盖全组 → 裸编号 `[n]`；引用部分成员 → `[na]`、`[na,nb]`；
- 其余 ≥3 个连续裸编号压缩为 `[x-y]`；支持原文内 `[1,3]`、`[4-6]` 混合写法；
- 输入要求：参考文献表以单独一行 `References` 或 `参考文献` 开头，条目以 `[n]` 起始。

## 七、中文渲染环境的本地化陷阱（zh-CN / zh locale）——最高频的"生成≠原稿"根因

**现象**：基准样式明明写的是英文 `et al.`、无"年"、半角横杠，但用户在 **NoteExpress / 中文版 Zotero** 里渲染出来却是"等""年""～"、刊名全称、还冒出 DOI。这不是基准逻辑错了，而是 **CSL 处理器按软件/系统 locale 把术语本地化** 了——`et al.`→"等"、`page-range-delimiter`→全角"～"、`in`→"收入："、`volume`→"卷"、`page`→"页"、日期加"年"等。只要文献库里混有会议/专著/析出类条目，就会触发这些中文 term。

**这是本 skill 实战中遇到的头号坑**：用户拿到的"生成结果和原模式不一致"，十有八九是它。基准样式无论选得多准，都会被中文 locale 打回原形。

**根治办法**：在 `.csl` 里用 `<locale xml:lang="zh-CN">` 与 `<locale xml:lang="zh">` 块，把 **vancouver.csl 可能吐出的所有 term** 强制覆盖为英文，并强制 `page-range-delimiter` 为半角 `-`、日期只出年份。下面是一份经过实战验证、可直接复用的完整覆盖块（粘到 `<info>` 之后、`<macro>` 之前）：

```xml
<!-- 中文渲染环境下强制英文术语，避免 et al.→等 / 年 / 收入：/ 卷 / 页 / ～ 等本地化伪影 -->
<locale xml:lang="zh-CN">
  <date delimiter=" " form="text">
    <date-part name="year"/>
    <date-part form="short" name="month" strip-periods="true"/>
    <date-part name="day"/>
  </date>
  <terms>
    <term name="et-al">et al.</term>
    <term name="page-range-delimiter">-</term>
    <term name="in">In:</term>
    <term name="available at">available from</term>
    <term name="internet">Internet</term>
    <term name="cited">cited</term>
    <term name="presented at">presented at</term>
    <term name="report">report</term>
    <term name="editor"><single>editor</single><multiple>editors</multiple></term>
    <term name="editors">editors</term>
    <term name="collection-editor"><single>editor</single><multiple>editors</multiple></term>
    <term name="translator"><single>translator</single><multiple>translators</multiple></term>
    <term name="editortranslator"><single>editor and translator</single><multiple>editors and translators</multiple></term>
    <term name="volume"><single>volume</single><multiple>volumes</multiple></term>
    <term form="short" name="volume"><single>vol.</single><multiple>vols.</multiple></term>
    <term name="page"><single>page</single><multiple>pages</multiple></term>
    <term form="short" name="page"><single>p.</single><multiple>pp.</multiple></term>
    <term name="part">part</term>
    <term form="short" name="part">part</term>
    <term name="supplement"><single>supplement</single><multiple>supplements</multiple></term>
    <term form="short" name="supplement"><single>suppl.</single><multiple>suppls.</multiple></term>
    <term name="section"><single>section</single><multiple>sections</multiple></term>
    <term form="short" name="section"><single>sect.</single><multiple>sects.</single></term>
    <term name="edition"><single>edition</single><multiple>editions</multiple></term>
    <term form="short" name="edition">ed.</term>
    <term name="month-01">Jan.</term><term name="month-02">Feb.</term><term name="month-03">Mar.</term>
    <term name="month-04">Apr.</term><term name="month-05">May</term><term name="month-06">Jun.</term>
    <term name="month-07">Jul.</term><term name="month-08">Aug.</term><term name="month-09">Sep.</term>
    <term name="month-10">Oct.</term><term name="month-11">Nov.</term><term name="month-12">Dec.</term>
  </terms>
</locale>
<locale xml:lang="zh">
  <!-- 同上，bare zh locale 兜底（部分处理器用 zh 而非 zh-CN） -->
  <terms>
    <term name="et-al">et al.</term>
    <term name="page-range-delimiter">-</term>
    <term name="in">In:</term>
    <term name="available at">available from</term>
    <term name="internet">Internet</term>
    <term name="cited">cited</term>
    <term name="presented at">presented at</term>
    <term name="report">report</term>
    <term name="editor"><single>editor</single><multiple>editors</multiple></term>
    <term name="collection-editor"><single>editor</single><multiple>editors</multiple></term>
    <term name="translator"><single>translator</single><multiple>translators</multiple></term>
    <term name="editortranslator"><single>editor and translator</single><multiple>editors and translators</multiple></term>
    <term form="short" name="volume"><single>vol.</single><multiple>vols.</multiple></term>
    <term form="short" name="page"><single>p.</single><multiple>pp.</multiple></term>
    <term form="short" name="part">part</term>
    <term form="short" name="supplement"><single>suppl.</single><multiple>suppls.</multiple></term>
    <term form="short" name="section"><single>sect.</single><multiple>sects.</multiple></term>
    <term form="short" name="edition">ed.</term>
  </terms>
</locale>
```

**配套要点**：
- 日期只渲染年份：把 `<date>` 的布局改成只含 `<date-part name="year"/>`，任何 locale 都不会加"年"。
- 页码写全 + 半角横杠：根元素加 `page-range-format="expanded"`，并如上覆盖 `page-range-delimiter` 为 `-`（en/zh-CN/zh 三处都要）。
- **仍无法纯靠样式解决的残留**（必须数据/软件侧配合）：① 期刊缩写依赖条目的「Journal Abbr / 期刊缩写」字段——Zotero 选中条目后右键「期刊」字段 →「Automatically abbreviate journal names」批量填好，否则 `form="short"` 只显示全称；② 若用户用的是 NoteExpress，除样式外还要在「作者列表 Chinese 标签」也设 `et al.`、日期格式选「不替换」、页码分隔符设 `-`、期刊命名格式选缩写——详见本文件第五节 NE 配方与下方第八节。

**本 skill 不内嵌样例 `.csl` 文件**：上方完整 zh-CN/zh 覆盖块即为可直接粘贴复用的成品级代码，配合第八节的分隔符 / 斜体 / DOI 精确 patch 配方，新任务直接以其为基准改 `<info>` 与少量特征即可，不必从零 patch，也避免 skill 携带非必要的交付格式文件。

## 八、会议论文（paper-conference）与 DOI 的额外注意

**A. 会议论文两个实战坑**
1. **双冒号 bug**：容器名前导词 `in` 在 locale 里定义成 `In:`（自带冒号），若外层包裹组用 `delimiter=": "`，会渲染成 `In:: 会议录名`。外层组 delimiter 应改为空格 `delimiter=" "`（期刊条目只有容器名一个子元素，delimiter 不生效，不受影响）。
2. **会议名取不到**：用户常把会议录名填在「Conference Name / 会议名称」字段（→ CSL `event`）而非「Book Title / 书名」字段（→ `container-title`）。`container-title` 宏对 `paper-conference` 应做兜底：
   ```xml
   <else-if type="paper-conference">
     <choose>
       <if variable="container-title"><text variable="container-title"/></if>
       <else-if variable="event"><text variable="event"/></if>
     </choose>
   </else-if>
   ```
   且 `container-preposition`（`In:`）只在 `container-title` 或 `event` 任一非空时才输出，避免孤零零的 `In:.`。
3. **渲染形态**：会议论文按连续出版物处理，有会议录名则 `In: <名>. 年;卷:页.`，无名称则干净串行 `年;卷:页.`（不要冒出 `Vol.`/`p.`/`In:` 空壳）。

   - **`;`/`:` 后是否留空格（易错，生成前必问）**：标准 NLM/Vancouver 是 `2018;57:1758-1784`（**无空格**）；但部分中文期刊/用户偏好带空格 `2018; 57: 1758-1784`。两者都合理，取决于目标刊。**带空格改两处分隔符**：`identifier-serial` 宏的卷页分隔 `delimiter=":"`→`": "`、`bibliography` 宏中年卷分隔 `delimiter=";"`→`"; "`（另 `date` 宏内 `delimiter=":"` 同步改 `": "` 以覆盖报纸类）。
   - **会议录名是否斜体（易错，生成前必问）**：标准 NLM 会议录名**不斜体**（仅期刊刊名斜体）；但本会话中用户明确要求会议名与期刊名一致斜体。若需斜体，在 `container-title` 宏的 `paper-conference` 分支给 `container-title` 与兜底 `event` 均加 `font-style="italic"`（见上方第七、八节 patch 配方）。**不要默认**，以当次要求为准。

**B. DOI 必须在前缀加前导空格**
`doi` 宏若写成 `<text variable="DOI" prefix="doi:"/>`，会与上一字段（页码/文章号）直接连排成 `100312.doi:10.…`（无空格）。改成 `prefix=" doi:"`，得到 `100312. doi:10.…`（句点+空格+doi），与 NLM 样例一致。无 DOI 时宏不输出，安全。

**C. DOI 是否出现是需向用户确认的设计决策**
同一用户可能先要求"无 DOI"（贴近原稿），后又要求"包含可点击 doi: 链接"。生成前在 Step 2 明确询问：是否含 DOI、前缀形态（`doi:` / `DOI:` / `https://doi.org/`）、是否置于条目末尾。不要把"无 DOI"当成永久默认——以用户当次要求为准。

## 九、交付检查清单

- [ ] 输出范围已与用户确认（csl / ens / nes 哪几轨）
- [ ] `.csl` 通过 `scripts/validate_csl.py` 校验（0 错误）
- [ ] `<info>` 的 id/self-link/updated 已按新样式重写
- [ ] 用样本中的 2–3 条真实文献在 Zotero 里实测渲染、与原文逐字符比对（交付说明中列出比对结果或提醒用户执行）
- [ ] 文内引用形态与正文样本一致（上标/方括号/著者-年）
- [ ] **中文环境加固已做**：若用户使用 NoteExpress / 中文版 Zotero，`.csl` 已加 `zh-CN`+`zh` locale 覆盖块强制英文术语、`page-range-delimiter="-"`、日期只出年份；并已在交付说明提醒「期刊缩写依赖 Journal Abbr 字段」「NE 中文标签也设 et al.」
- [ ] **DOI 形态已按用户当次要求确认**（含/不含、前缀形态、末尾位置），`doi` 宏前缀含前导空格避免 `页码.doi:` 连排
- [ ] **会议论文已处理**：`paper-conference` 按连续出版物 `年;卷:页` 渲染，`In:` 前导词不会双冒号，会议名从 `container-title` 或 `event` 兜底获取；`;`/`:` 后空格与会议名斜体已按 Step 2 决策③④ 落实
- [ ] EndNote 配方 .txt 与 .csl 特征一致（或官方 .ens 已获取）
- [ ] NoteExpress 配方 .txt 与 .csl 特征一致（或官方/公开 .nes 已获取、已提醒先搜 NE 内置样式）；配方文件开头含「→ .nes 落地路径」四步说明
- [ ] Wiley 化学系/Advanced 系样本：已声明 a/b/c 合并编号不在样式文件内，已告知 wiley_abc_merge.py 后处理流程
- [ ] 若期刊样式其实在官方库已存在，优先直接交付官方样式并附原链接，不要重复造轮子
