---
name: skillhub-skill-citestyle-forge
description: "引文样式文件生成。当用户提供目标期刊论文（PDF）或其参考文献页截图，需要为该期刊生成文献管理软件的引文样式文件——Zotero/Mendeley 的 .csl、EndNote 的 .ens（或样式配方）、NoteExpress 的 .nes（或样式配方）——以解决撰写论文时找不到目标期刊参考文献引用格式文件的问题时使用。用户可指定只输出其中一种或几种，默认三条轨全出。同时支持把参考文献解析为 .ris/.bib/.enw 文献导入文件（辅助能力）。触发场景：找不到某期刊的 csl/ens/nes、投稿需要特定参考文献格式、从论文反推期刊引文样式。"
---

# citestyle-forge — 期刊引文样式文件生成（.csl / .ens / .nes）

## Overview

从用户提供的目标期刊论文 PDF 或参考文献页图片中提取引文样式特征，输出三条轨的引文样式文件：

| 轨 | 软件 | 样式文件 | 可生成性 |
|----|------|---------|---------|
| A | Zotero / Mendeley / Pandoc | `.csl`（XML，开放规范） | **可直接生成** |
| B | EndNote | `.ens`（私有二进制） | 官方库命中→下载真文件；否则交付**样式配方 .txt**（按方 3 分钟在 EndNote 内建成） |
| C | NoteExpress | `.nes`（私有二进制） | 官方/第三方渠道命中→下载真文件；否则交付 **NE 样式配方 .txt** |

**用户可指定只输出其中一种或几种；未指定时默认三条轨全出。**
（辅助）还可把参考文献解析为 .ris/.bib/.enw 文献导入文件。

解决撰写论文时"找不到目标期刊参考文献引用格式文件"的问题。

## Workflow

### Step 0 — 确认输出范围

确认用户需要哪几轨（csl / ens / nes）。用户明确指定时只产出指定轨；未指定时三条轨全出。若只需其中一轨，跳过其余轨的所有步骤。

### Step 1 — 读取输入，提取两类样本

- **PDF**：用 Read 读取。除末尾参考文献页外，**务必浏览正文**，截取 2–3 处文内引用的真实形态（上标数字 / `[1]` / `(1)` / `(Author, Year)`）。
- **图片**：用 Read 读取截图。若只有参考文献表而没有文内引用样本，向用户说明文内引用形态将按样式族惯例推断。
- 若用户直接给出期刊名或粘贴参考文献文本，同样适用。

### Step 2 — 提取样式特征

对照 `references/style-recipes.md` 第一节的特征清单，逐项记录：引用体系（数字制/著者-出版年）、文内引用形态、参考文献表中作者格式、标题有无、刊名缩写与斜体、年份位置、卷期页码排版、DOI 形态。`references/format-specs.md` 中的格式识别表可辅助快速定位样式族。

**务必向用户确认的设计决策**（漏一个就返工）：① **是否包含 DOI** 及前缀形态（`doi:` / `DOI:` / `https://doi.org/`，置于条目末尾）——同一用户可能先后改主意，以当次要求为准，不要固化"无 DOI"默认；② **目标期刊名**若未在图中露出，主动询问，便于去官方库查逐字符一致的现成样式；③ **`;`/`:` 后是否留空格**——标准 NLM/Vancouver 为 `2018;57:1758-1784`（无空格），但用户可能要带空格 `2018; 57: 1758-1784`，生成前确认；④ **会议录名是否斜体**——标准 NLM 不斜体（仅期刊斜体），但用户可能要求会议名与期刊一致斜体，生成前确认。③④ 属"看起来像标准其实可变"的易错点，不要凭基准样式默认。

### Step 3 — 轨 A：生成 .csl（三级策略，按序尝试）

1. **优先查官方库**：按期刊名搜索 `https://www.zotero.org/styles?q=<期刊名>`（WebFetch）。命中则直接下载官方 .csl 交付，附原链接，不重复造轮子。
2. **未命中则以近缘样式为基准**：按 `references/style-recipes.md` 第二节的基准样式选取表，用 WebFetch 下载 `https://raw.githubusercontent.com/citation-style-language/styles/master/<文件名>.csl`，写入本地文件，再按该文件第三节的 patch 配方修改 XML 使其逐项匹配 Step 2 提取的特征。文件名 404 时先回搜索页确认真实文件名；命中 dependent 样式时按其 parent 链接改下父样式。GitHub raw 超时或中文文件名抓取失败时，改用 Contents API（`https://api.github.com/repos/citation-style-language/styles/contents/<文件名>.csl`）获取 base64 内容后本地解码。
3. **分叉后必改 `<info>`**：重写 title / id / self-link / updated（updated 用 `date -u` 取当前时间戳），保留 rights。详见 style-recipes.md 第三节末尾。

4. **中文渲染环境加固（关键，防"生成≠原稿"）**：若用户使用 NoteExpress / 中文版 Zotero，**必须在 `.csl` 写入 `zh-CN`+`zh` locale 覆盖块**，把 `et al.`/`in`/`volume`/`page`/月份等所有 term 强制为英文、`page-range-delimiter` 设为 `-`、日期只出年份——否则软件会按 locale 本地化出"等""年""～""收入："等伪影。完整覆盖块与会议/DOI 注意事项见 style-recipes.md **第七、八节**（含可直接粘贴的 zh-CN/zh 英文覆盖块、分隔符与斜体 patch 配方，无需内嵌样例文件）。

校验：`python <skill目录>/scripts/validate_csl.py <样式文件.csl>`，0 错误方可交付。

### Step 4 — 轨 B：EndNote .ens（二级策略）

`.ens` 是 Clarivate 私有二进制格式，任何离线工具都无法可靠编写——只有 EndNote 软件本身能生成合法的 .ens。按序尝试：

1. **官方样式库**：endnote.com 官方库有 7000+ 样式。用 WebFetch 访问 `https://endnote.com/downloads/styles/` 搜索期刊名（该站对 curl 返回 403，需用 WebFetch）。命中时：能下载则交付真 .ens；下载通道不可用时，把官方下载页链接给用户，并仍交付配方作为即时可用方案。
2. **样式配方兜底**：按 `references/style-recipes.md` 第四节语法生成 `<期刊名>-endnote-style-recipe.txt`（Templates / Author Name / Author Lists / Sort Order 等小节），内容与轨 A 特征一致，并说明使用方法：EndNote → Edit → Output Styles → New Style。

### Step 5 — 轨 C：NoteExpress .nes（三级策略）

`.nes` 同样为私有二进制（实测样本文件头非 XML），无法离线编写。按序尝试：

1. **软件内置样式**：NoteExpress 内置 5000+ 期刊样式——先提醒用户在 NE 样式管理器（工具 → 样式 → 样式管理器）中直接搜索期刊名，命中最省事。
2. **公开渠道下载**：搜索 `<期刊名> .nes 下载`（高校图书馆页面、NE 官方论坛 bbs.inoteexpress.com、GitHub 常有分享）。下载到的 .nes **先查文件头**：以 `<?xml` 开头则可作为基准 patch（罕见）；二进制则原样交付给用户安装（NE → 样式管理器 → 安装）。
3. **NE 配方兜底**：按 `references/style-recipes.md` 第五节的 NE 编辑器术语生成 `<期刊名>-noteexpress-style-recipe.txt`（常规 / 引文模板 / 题录模板 / 作者列表（含 Chinese/English 双语标签页）/ 作者姓名 / 期刊命名格式 / 页码格式 / 日期格式），内容与轨 A 特征一致。
4. **配方 → 可导入 .nes 的落地路径**（向用户说明）：配方是过渡形态，用户按配方在 NE 样式编辑器（样式管理器 → 新建样式，建议选最接近的内置样式改造）填好后「另存为」即得真 `.nes`——该文件可直接安装（样式管理器 → 安装新的样式）、复制到 NE 安装目录 `Styles\` 或导出分享给他人。`.nes` 为私有二进制，离线无法代写，此人工 3 分钟步骤不可替代。

术语澄清（如用户提及 .nbib）：`.nbib` 是 PubMed/NoteExpress 的**题录数据**交换格式，不是样式文件；NE 的引文样式文件是 `.nes`。

### Step 5.5 — Wiley 系「a) b) c) 合并编号」后处理（按需）

Wiley 化学系/Advanced 系「一个编号下 a) b) c) 合并多篇」**无法写进任何样式文件**（CSL 1.0、EndNote、NoteExpress 均不支持，官方 angewandte-chemie.csl 同样做不到）——这是格式能力上限，不要在样式文件里硬凑。解决方案是投稿前的后处理脚本：

```bash
python <skill目录>/scripts/wiley_abc_merge.py 稿件.txt groups.json -o 输出.txt
```

- 时机：Word 中「去域化/转为纯文本」（Zotero: Unlink Citations；EndNote: Convert to Plain Text）之后、投稿之前；
- groups.json 由用户指定分组（如 `[[2,3],[5,6,7]]`）——哪些文献在同一处被引用、需要合并，只有作者知道，脚本不猜测；
- 脚本自动完成：全文引用重新编号、整组引用折叠为裸编号 `[n]`、部分引用显示 `[nb]`、参考文献表合并为 `[n] a) … b) …`、连续编号压缩为区间。
- 详细规则见 style-recipes.md 第六节。

### Step 6 — （可选）生成文献导入文件

用户同时需要把样本文献导入文献库时，按 `references/format-specs.md` 的 JSON Schema 解析全部条目写入 refs.json，执行：

```bash
python <skill目录>/scripts/refs_to_formats.py <输出目录>/refs.json -o <输出目录>
```

生成 .ris/.bib/.enw。解析规则见 format-specs.md，务必通过脚本转换，不要手写 RIS/BibTeX。

### Step 7 — 交付

1. present_files 展示各轨产物（.csl / .ens 或配方 / .nes 或配方，及可选的 .ris/.bib/.enw）。
2. 回复中给出：输出范围（哪几轨）、识别出的样式族与判定依据、关键特征表、各轨来源（官方命中/近缘改造/配方兜底）、校验结果、实测提醒。
3. 安装方法提示：Zotero 双击 .csl；EndNote 按配方建库或官方下载；NoteExpress 样式管理器搜索或安装 .nes。

## Important Notes

- **官方库优先**：三个软件各有官方样式来源（Zotero 样式库 / endnote.com 7000+ / NE 内置 5000+），命中即用，只在确实没有时才改造或给配方。
- **诚实边界**：`.ens` 和 `.nes` 是私有二进制，离线无法凭空生成真文件——不要尝试手写二进制，配方是唯一可靠的兜底。`.csl` 是开放 XML，可以完全离线生成。
- **中文本地化是第一大坑（务必主动处理）**：用户（尤其 NoteExpress / 中文版 Zotero 用户）拿到样式后最常见的"和原稿不一致"不是基准选错，而是 **CSL 处理器按中文 locale 把术语本地化**（`et al.`→"等"、年份加"年"、页码分隔符变全角"～"、"收入：/卷/页"等）。无论基准多准都会被拉回中文。根治法见 style-recipes.md 第七节——在 `.csl` 写 `zh-CN`+`zh` locale 覆盖块强制英文。此外：① 期刊缩写依赖条目的「Journal Abbr」字段（Zotero 右键「期刊」→「Automatically abbreviate journal names」批量填），否则 `form="short"` 只显示全称；② 会议论文 `paper-conference` 有双冒号(`In::`)与会议名取不到(`event` 字段兜底)两个坑，详见第八节；③ DOI 宏前缀务必带前导空格，否则渲染成 `页码.doi:` 连排；另外 `;`/`:` 后空格、会议名斜体也属于"看似标准实则可变"的易错点，须在 Step 2 与用户确认，详见第八节。
- **本地软件驱动不可行**：EndNote 与 NoteExpress 均**无公开的样式编程接口**（无 CLI/COM/API 可创建或导出样式），GUI 自动化（模拟点击）脆弱且需用户在场，不作为默认方案；如用户坚持，仅在软件已安装且用户明确授权时，可尝试用 GUI 自动化按其配方逐步操作，并全程让用户确认。实测环境（2026-09）：本机未安装这两款软件。
- **a/b/c 合并编号不进样式文件**：任何样式文件都表达不了，统一走 Step 5.5 的后处理脚本，不要在 .csl/配方里声称支持。
- **文内引用与文献表同等重要**：只有参考文献页时文内引用部分只能推断，必须向用户声明。
- 中文期刊（GB/T 7714）：轨 A 直接以官方 `china-national-standard-gb-t-7714-2015-numeric.csl` 为基准；轨 C 提醒 NE 内置多套 GB/T 7714 样式直接可用。
- 冲突仲裁：基准样式与样本特征冲突时，先回原文复核特征提取是否有误，再决定 patch。

## Resources

### scripts/
- `validate_csl.py` — CSL 样式文件结构校验器（纯标准库）：XML 良构、info 块完整性、macro 引用一致性、citation-format 匹配。
- `refs_to_formats.py` — 辅助能力：结构化 JSON → RIS / BibTeX / EndNote 导入文件。文件头含输入 Schema 与用法。
- `wiley_abc_merge.py` — Wiley 系 a/b/c 合并编号后处理器（纯标准库）：纯文本稿件 + 分组 JSON → 全文重编号 + 文献表合并。文件头含详细用法与规则。

### references/
- `style-recipes.md` — **核心参考**：样式特征提取清单、CSL 基准样式选取表、CSL patch 配方、EndNote 配方语法与官方库获取、NoteExpress 配方语法与获取渠道、交付检查清单。Step 2–5 必读。**第七、八节为实战沉淀**：中文本地化陷阱与完整 zh-CN/zh locale 覆盖块、会议论文与 DOI 注意。
- `format-specs.md` — 16 种引用格式快速识别表、文献类型判定、文献数据解析注意事项与 JSON Schema（Step 2 辅助识别、Step 6 必读）。

## Changelog

- **v2.4.0**（2026-11-03）：补充两处"看似标准实则可变"的易错决策，沉淀自同一 NLM/Vancouver 变体的后续迭代——① **`;`/`:` 后空格**：标准 NLM 为 `2018;57:1758-1784`（无空格），但用户要求带空格 `2018; 57: 1758-1784`；补入 Step 2 决策清单③，并在 style-recipes.md 第八节给出精确分隔符改法（`identifier-serial`/`bibliography`/`date` 三处 `delimiter`）；② **会议录名斜体**：标准 NLM 不斜体（仅期刊斜体），但用户要求会议名与期刊一致斜体；补入决策清单④，并更新第八节（原"NLM 会议录名不斜体"表述改为"是否斜体应在 Step 2 确认"），注明 `container-title` 宏 `paper-conference` 分支加 `font-style="italic"` 的改法；③ 校准第八节表述，明确 `;`/`:` 后空格与会议名斜体均为可配置项并给出精确改法；④ **移除 skill 内嵌的示例 `.csl` 文件**（属非必要交付格式；第七、八节已含完整可复用的 zh-CN/zh 覆盖块与 patch 配方，无需样例文件）。
- **v2.3.0**（2026-11-02）：实战沉淀（一次 NLM/Vancouver 变体从零生成并多轮修正的经验）——① **中文本地化陷阱**：明确 CSL 在 NoteExpress/中文版 Zotero 下会被 locale 本地化为"等""年""～""收入："等，给出完整 `zh-CN`+`zh` locale 英文覆盖块（第七节）作为根治方案；② **期刊缩写依赖数据**：`form="short"` 需条目含「Journal Abbr」字段，给出 Zotero 批量缩写指引；③ **会议论文两个坑**：`In:` 双冒号（`In::`）与会议名从 `container-title`/`event` 兜底获取（第八节）；④ **DOI 前导空格**：`prefix=" doi:"` 避免 `页码.doi:` 连排；⑤ **DOI 是否出现为需确认的设计决策**，不再固化"无 DOI"默认；⑥ 曾新增 `references/examples/...-zh-hardened.csl` 可复用成品（已于 v2.4.0 移除，改由第七、八节的代码块与 patch 配方直接复用，避免 skill 携带非必要交付格式）。
- **v2.2.0**（2026-09-28）：回应三个能力问题——① NE 配方落地：补充「配方 → NE 编辑器另存为 → 可导入 .nes」的完整路径（.nes 私有二进制不可离线代写，人工 3 分钟步骤不可替代）；② Wiley a/b/c 合并编号：确认无法写入任何样式文件（CSL/EndNote/NE 均不支持），新增 `scripts/wiley_abc_merge.py` 后处理脚本——在去域化纯文本稿件上按用户分组指令完成全文重编号、整组折叠 `[n]`、部分引用 `[nb]`、文献表合并 `[n] a)…b)…`、区间压缩，已用两组合成样例全用例测试通过；③ 本地软件驱动：调研确认 EndNote/NoteExpress 均无样式编程接口（无 CLI/COM/API），GUI 自动化脆弱，仅作为用户明确授权下的备选；实测本机未安装两款软件。
- **v2.1.0**（2026-09-28）：输出范围扩展为三轨——新增轨 B（EndNote .ens）与轨 C（NoteExpress .nes），支持用户指定只输出其中一种或几种（默认全出）。经调研确认 .ens/.nes 均为私有二进制（实测 .nes 样本文件头非 XML），两轨采用「官方/公开渠道下载真文件 + 样式配方兜底」策略；.csl 轨保持完全离线生成。EndNote 配方与 NE 配方语法均写入 style-recipes.md。
- **v2.0.1**（2026-09-28）：经 9 个真实期刊样本全流程验证后修正——① 基准样式表更新：GB/T 7714 双语能力已并入 `china-national-standard-gb-t-7714-2015-numeric.csl`（独立 -bilingual 文件不存在）；补录 Wiley 化学系基准 `angewandte-chemie.csl` 与 Advanced 子刊独立样式；② 新增「冲突仲裁原则」：基准样式与样本特征冲突时先回原文复核特征提取，再决定 patch（防止把 Nature 系"有标题"误判为"无标题"而错误分叉）。
- **v2.0.0**（2026-09-28）：目标修正——主产物从文献数据导入文件（.ris/.bib/.enw）改为引文样式文件（.csl + EndNote 配方）。新增 CSL 三级生成策略（官方库命中→近缘基准改造→分叉重写 info）、validate_csl.py 校验器、style-recipes.md（特征清单/基准样式表/patch 配方/EndNote 语法）；原导入文件生成能力保留为辅助流程。
- **v1.1.0**（2026-09-28）：经 9 个真实样本（6 英文 PDF + 2 中文 PDF + 1 图片截图，429 条文献）验证后修复与增强——① 脚本不再把「无标题」误报为字段不全（Wiley/RSC 系样式本不著录标题），仅对缺作者/年份报警；② 识别表新增 RSC 系、Wiley 化学系、Wiley Advanced 系、Science China Press 系四种样式；③ 解析注意事项新增合并编号（a/b/c 子条目）拆分、软件引用、Nature 系 et al. 截断、样式固有省略等规则。
- **v1.0.0**（2026-09-28）：初始版本。识别 12 种常见引用格式，JSON→RIS/BibTeX/EndNote 三格式转换。
