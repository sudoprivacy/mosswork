#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
refs_to_formats.py — 将结构化参考文献 JSON 批量转换为文献管理软件可导入的格式文件。

支持输出：
  - RIS   (.ris)  : Zotero / Mendeley / EndNote / Citavi 通用导入格式
  - BibTeX(.bib)  : LaTeX / Zotero / JabRef
  - EndNote(.enw) : EndNote 官方导入格式（%0/%A/%T/...）

用法：
  python refs_to_formats.py refs.json -o <输出目录> [--formats ris,bib,enw]

输入 JSON 结构（顶层为对象或数组均可）：
  [
    {
      "type": "journal",            # journal|book|chapter|conference|thesis|
                                    # report|webpage|preprint|newspaper|standard|patent
      "authors": [                  # 每项可为 {"family":"张","given":"三"} 或纯字符串
        {"family": "Smith", "given": "John A."},
        "Zhang San"
      ],
      "title": "论文标题",
      "container": "期刊全名/书名/会议论文集名",
      "container_short": "期刊缩写(可选)",
      "year": "2023",
      "volume": "12",
      "issue": "3",
      "pages": "45-52",            # 也接受 "45–52"、"45"（单页）
      "publisher": "出版社",
      "address": "出版地",
      "edition": "3rd ed.",
      "editors": [ {"family":"Wang","given":"Li"} ],
      "doi": "10.1000/xyz123",
      "url": "https://...",
      "accessed": "2024-05-01",     # 网页访问日期
      "institution": "清华大学",     # 学位论文授予单位
      "language": "zh",             # zh|en|...
      "note": "备注(可选)"
    }
  ]

仅依赖标准库。作者为纯字符串时的解析规则：
  - 含逗号            -> "Family, Given"
  - 全 CJK 且 <=4 字  -> 首字为姓，其余为名（如 "张三" -> 姓"张" 名"三"）
  - 其余              -> 最后一个词为姓（西文习惯）
"""
import argparse
import json
import os
import re
import sys
import unicodedata

# ---------------------------------------------------------------- 作者解析

CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")


def _is_cjk(s: str) -> bool:
    return bool(s) and all(CJK_RE.match(ch) or ch in "·- " for ch in s)


def parse_author(raw):
    """归一化作者 -> {"family":..., "given":...}。"""
    if isinstance(raw, dict):
        fam = (raw.get("family") or "").strip()
        giv = (raw.get("given") or "").strip()
        if fam or giv:
            return {"family": fam, "given": giv}
        raw = (raw.get("name") or "").strip()
    if not isinstance(raw, str):
        return None
    raw = re.sub(r"\s+", " ", raw).strip()
    if not raw or raw.lower() in {"et al.", "et al", "等", "[et al]"}:
        return None
    if "," in raw:  # "Family, Given"
        fam, _, giv = raw.partition(",")
        return {"family": fam.strip(), "given": giv.strip()}
    if _is_cjk(raw):
        raw = raw.replace(" ", "")
        if len(raw) <= 4:
            if raw[:2] in ("欧阳", "司马", "诸葛", "上官", "司徒", "夏侯", "皇甫") and len(raw) >= 3:
                return {"family": raw[:2], "given": raw[2:]}
            return {"family": raw[0], "given": raw[1:]}
        return {"family": raw[:2], "given": raw[2:]}
    parts = raw.split()
    if len(parts) == 1:
        return {"family": parts[0], "given": ""}
    return {"family": parts[-1], "given": " ".join(parts[:-1])}


def parse_authors(items):
    if not items:
        return []
    if isinstance(items, str):
        items = [a for a in re.split(r"[;；]|\s+and\s+", items, flags=re.I) if a.strip()]
    out = []
    for it in items:
        a = parse_author(it)
        if a:
            out.append(a)
    return out


# ---------------------------------------------------------------- 工具函数

def author_ris(a):
    """RIS/EndNote 作者串: 'Family, Given'。"""
    if a["given"]:
        return f'{a["family"]}, {a["given"]}'
    return a["family"]


def author_bibtex(a):
    """BibTeX 作者串: 'Family, Given'（含逗号，BibTeX 语法原生支持）。"""
    return author_ris(a)


def split_pages(pages):
    """'45-52' -> ('45','52')；'45' -> ('45', None)。"""
    if not pages:
        return None, None
    p = re.sub(r"\s+", "", str(pages)).replace("–", "-").replace("—", "-").replace("‐", "-")
    p = p.lower().replace("pp.", "").replace("p.", "").lstrip("p")
    if "e" in p and "-" in p:  # e-locators 如 e12345
        return p, None
    if "-" in p:
        s, _, e = p.partition("-")
        return s.strip() or None, e.strip() or None
    return p, None


def clean(s):
    if s is None:
        return ""
    s = str(s)
    # 去掉从 PDF/网页复制时常带的残留标记
    s = re.sub(r"</?[a-zA-Z][^>]*>", "", s)          # <b> <sup> <i> ...
    s = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    return re.sub(r"\s+", " ", s).strip()


def norm_year(y):
    y = clean(y)
    m = re.search(r"(19|20)\d{2}", y)
    return m.group(0) if m else y


def norm_doi(doi):
    d = clean(doi)
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d, flags=re.I)
    d = re.sub(r"^doi:\s*", "", d, flags=re.I)
    return d


def cite_key(ref, idx):
    """生成 BibTeX citekey: firstauthorYYYYfirstword。"""
    a = ref.get("_authors") or []
    fam = re.sub(r"[^A-Za-z0-9\u4e00-\u9fff]", "", a[0]["family"]) if a else f"ref{idx}"
    year = norm_year(ref.get("year")) or "nd"
    title = clean(ref.get("title"))
    words = re.findall(r"[A-Za-z\u4e00-\u9fff]+", title)
    w = (words[0] if words else "untitled")[:15]
    return f"{fam[:20]}{year}{w.lower()}"


# ---------------------------------------------------------------- 类型映射

TYPE_MAP = {
    #  type          ris     bibtex           endnote
    "journal":     ("JOUR", "article",       "Journal Article"),
    "book":        ("BOOK", "book",           "Book"),
    "chapter":     ("CHAP", "incollection",   "Book Section"),
    "conference":  ("CONF", "inproceedings",  "Conference Proceedings"),
    "thesis":      ("THES", "phdthesis",      "Thesis"),
    "report":      ("RPRT", "techreport",     "Report"),
    "webpage":     ("ELEC", "misc",           "Web Page"),
    "preprint":    ("PRE",  "misc",           "Journal Article"),
    "newspaper":   ("NEWS", "article",        "Newspaper Article"),
    "standard":    ("RPRT", "techreport",     "Report"),
    "patent":      ("PAT",  "misc",           "Patent"),
}


def ref_type(ref):
    t = (clean(ref.get("type")) or "journal").lower()
    return TYPE_MAP.get(t, TYPE_MAP["journal"])


def normalize_ref(raw, idx):
    """清洗 + 解析作者，返回内部规范结构。"""
    ref = dict(raw)
    ref["title"] = clean(ref.get("title"))
    ref["container"] = clean(ref.get("container") or ref.get("journal"))
    ref["container_short"] = clean(ref.get("container_short") or ref.get("journal_short"))
    ref["year"] = norm_year(ref.get("year"))
    ref["doi"] = norm_doi(ref.get("doi"))
    for k in ("volume", "issue", "pages", "publisher", "address",
              "edition", "url", "accessed", "institution", "note", "language"):
        ref[k] = clean(ref.get(k))
    ref["_authors"] = parse_authors(ref.get("authors"))
    ref["_editors"] = parse_authors(ref.get("editors"))
    ref["_key"] = cite_key(ref, idx)
    return ref


# ---------------------------------------------------------------- RIS 输出

def to_ris(refs):
    blocks = []
    for i, r in enumerate(refs, 1):
        ty, _, _ = ref_type(r)
        L = []
        L.append(f"TY  - {ty}")
        for a in r["_authors"]:
            L.append(f"AU  - {author_ris(a)}")
        for e in r["_editors"]:
            L.append(f"A2  - {author_ris(e)}")
        if r["title"]:
            L.append(f"TI  - {r['title']}")
        if r["container"]:
            L.append(f"T2  - {r['container']}")
        if r["container_short"]:
            L.append(f"JA  - {r['container_short']}")
        if r["year"]:
            L.append(f"PY  - {r['year']}")
        if r["volume"]:
            L.append(f"VL  - {r['volume']}")
        if r["issue"]:
            L.append(f"IS  - {r['issue']}")
        sp, ep = split_pages(r["pages"])
        if sp:
            L.append(f"SP  - {sp}")
        if ep:
            L.append(f"EP  - {ep}")
        if r["publisher"]:
            L.append(f"PB  - {r['publisher']}")
        if r["address"]:
            L.append(f"CY  - {r['address']}")
        if r["edition"]:
            L.append(f"ED  - {r['edition']}")
        if r["doi"]:
            L.append(f"DO  - {r['doi']}")
        if r["url"]:
            L.append(f"UR  - {r['url']}")
        if r["institution"]:
            L.append(f"N1  - Institution: {r['institution']}")
        if r["accessed"]:
            L.append(f"N1  - Accessed: {r['accessed']}")
        if r["note"]:
            L.append(f"N1  - {r['note']}")
        L.append(f"ID  - {r['_key']}")
        L.append("ER  - ")
        blocks.append("\n".join(L))
    return "\n\n".join(blocks) + "\n"


# ---------------------------------------------------------------- BibTeX 输出

def bib_escape(s):
    return s.replace("\\", "").replace("{", "").replace("}", "")


def internal_type(ref):
    return (clean(ref.get("type")) or "journal").lower()


def to_bibtex(refs):
    entries = []
    for r in refs:
        ty, bt, _ = ref_type(r)
        it = internal_type(r)
        f = []
        if r["_authors"]:
            f.append("author = {%s}" % " and ".join(bib_escape(author_bibtex(a)) for a in r["_authors"]))
        if r["title"]:
            f.append("title = {%s}" % bib_escape(r["title"]))
        if r["container"]:
            if it in ("journal", "newspaper", "preprint"):
                f.append("journal = {%s}" % bib_escape(r["container"]))
            elif it == "standard":
                pass  # 标准号放 number 字段
            elif it == "conference":
                f.append("booktitle = {%s}" % bib_escape(r["container"]))
            else:
                f.append("booktitle = {%s}" % bib_escape(r["container"]))
        if r["year"]:
            f.append("year = {%s}" % r["year"])
        if r["volume"]:
            f.append("volume = {%s}" % bib_escape(r["volume"]))
        if r["issue"]:
            f.append("number = {%s}" % bib_escape(r["issue"]))
        if it == "standard" and r["container"]:
            f.append("number = {%s}" % bib_escape(r["container"]))
        if r["pages"]:
            p = r["pages"].replace("–", "--").replace("—", "--")
            f.append("pages = {%s}" % bib_escape(p))
        if r["_editors"]:
            f.append("editor = {%s}" % " and ".join(bib_escape(author_bibtex(e)) for e in r["_editors"]))
        if r["publisher"]:
            f.append("publisher = {%s}" % bib_escape(r["publisher"]))
        if r["address"]:
            f.append("address = {%s}" % bib_escape(r["address"]))
        if r["edition"]:
            f.append("edition = {%s}" % bib_escape(r["edition"]))
        if r["doi"]:
            f.append("doi = {%s}" % r["doi"])
        if r["url"]:
            f.append("url = {%s}" % r["url"])
        if r["institution"]:
            if bt == "techreport":
                f.append("institution = {%s}" % bib_escape(r["institution"]))
            elif bt in ("phdthesis", "mastersthesis"):
                f.append("school = {%s}" % bib_escape(r["institution"]))
        if bt == "misc" and r["url"] and not r["doi"]:
            f.append("howpublished = {\\url{%s}}" % r["url"])
        if r["accessed"]:
            f.append("note = {Accessed %s}" % r["accessed"])
        elif r["note"]:
            f.append("note = {%s}" % bib_escape(r["note"]))
        if r["language"] == "zh":
            f.append("language = {chinese}")
        entries.append("@%s{%s,\n  %s\n}" % (bt, r["_key"], ",\n  ".join(f)))
    return "\n\n".join(entries) + "\n"


# ---------------------------------------------------------------- EndNote 输出

def to_endnote(refs):
    blocks = []
    for r in refs:
        _, _, en = ref_type(r)
        L = []
        L.append(f"%0 {en}")
        for a in r["_authors"]:
            L.append(f"%A {author_ris(a)}")
        for e in r["_editors"]:
            L.append(f"%E {author_ris(e)}")
        if r["title"]:
            L.append(f"%T {r['title']}")
        if r["container"]:
            if internal_type(r) in ("journal", "newspaper", "preprint"):
                L.append(f"%J {r['container']}")
            else:
                L.append(f"%B {r['container']}")
        if r["year"]:
            L.append(f"%D {r['year']}")
        if r["volume"]:
            L.append(f"%V {r['volume']}")
        if r["issue"]:
            L.append(f"%N {r['issue']}")
        if r["pages"]:
            L.append(f"%P {r['pages']}")
        if r["publisher"]:
            L.append(f"%I {r['publisher']}")
        if r["address"]:
            L.append(f"%C {r['address']}")
        if r["edition"]:
            L.append(f"%7 {r['edition']}")
        if r["institution"]:
            L.append(f"%I {r['institution']}")
        if r["doi"]:
            L.append(f"%R {r['doi']}")
        if r["url"]:
            L.append(f"%U {r['url']}")
        if r["note"]:
            L.append(f"%X {r['note']}")
        blocks.append("\n".join(L))
    return "\n\n".join(blocks) + "\n"


# ---------------------------------------------------------------- 主流程

EXT = {"ris": ".ris", "bib": ".bib", "bibtex": ".bib", "enw": ".enw", "endnote": ".enw"}


def main():
    ap = argparse.ArgumentParser(description="结构化参考文献 JSON -> RIS/BibTeX/EndNote")
    ap.add_argument("input", help="输入 JSON 文件路径")
    ap.add_argument("-o", "--output-dir", default=".", help="输出目录（默认当前目录）")
    ap.add_argument("--formats", default="ris,bib,enw",
                    help="逗号分隔：ris,bib,enw（默认全部）")
    ap.add_argument("--basename", default="references", help="输出文件基础名（默认 references）")
    args = ap.parse_args()

    with open(args.input, encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict):
        data = data.get("references") or [data]
    refs = [normalize_ref(r, i) for i, r in enumerate(data, 1)]
    if not refs:
        sys.exit("错误：输入中未找到任何参考文献条目。")

    os.makedirs(args.output_dir, exist_ok=True)
    wanted = [f.strip().lower() for f in args.formats.split(",") if f.strip()]
    writers = {"ris": to_ris, "bib": to_bibtex, "bibtex": to_bibtex,
               "enw": to_endnote, "endnote": to_endnote}
    written = []
    for fmt in wanted:
        w = writers.get(fmt)
        if not w:
            print(f"跳过不支持的格式: {fmt}", file=sys.stderr)
            continue
        path = os.path.join(args.output_dir, args.basename + EXT[fmt])
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(w(refs))
        written.append(path)

    # 摘要输出
    print(f"共解析 {len(refs)} 条文献，已生成 {len(written)} 个文件：")
    for p in written:
        print("  " + os.path.abspath(p))
    missing = [f"{i}. {r['title'] or r['container'] or '(空条目)'}" for i, r in enumerate(refs, 1)
               if not r["_authors"] or not r["year"]]
    if missing:
        print("\n以下条目缺 作者/年份，请人工核对：")
        print("\n".join(missing))
    no_title = sum(1 for r in refs if not r["title"])
    if no_title:
        print(f"\n注：{no_title} 条无文章标题（若原文格式本身不著录标题，如 Wiley/Adv. Mater. 系样式，属正常现象）。")


if __name__ == "__main__":
    main()
