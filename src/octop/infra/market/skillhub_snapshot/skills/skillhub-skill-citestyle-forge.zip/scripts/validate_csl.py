#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_csl.py — CSL 1.0 引文样式文件结构校验（纯标准库，不依赖 citeproc）。

用法：
  python validate_csl.py <style.csl>

检查项：
  1. XML 格式良好（well-formed）
  2. 根元素为 CSL 命名空间下的 <style>，含 class / version 属性
  3. <info> 块完整：title、id、updated（ISO 8601）
  4. 恰有一个 <citation>；<bibliography> 缺失时仅警告
  5. macro 名称唯一；所有 <text macro="X"> 引用的 macro 均已定义
  6. citation 为数字制时检查 collapse / citation-number 配置是否合理（提示级）
  7. info/category 的 citation-format 与 <citation> 内容一致性（提示级）

退出码：0 = 通过（可有警告）；1 = 存在错误。
"""
import re
import sys
import xml.etree.ElementTree as ET

NS = "{http://purl.org/net/xbiblio/csl}"


def tag(el):
    return el.tag.replace(NS, "")


def main():
    if len(sys.argv) != 2:
        sys.exit("用法: python validate_csl.py <style.csl>")
    path = sys.argv[1]
    errors, warnings, notes = [], [], []

    # 1. well-formed
    try:
        tree = ET.parse(path)
    except ET.ParseError as e:
        sys.exit(f"[错误] XML 解析失败: {e}")
    root = tree.getroot()

    # 2. root element
    if tag(root) != "style":
        errors.append(f"根元素应为 <style>，实际为 <{tag(root)}>")
    else:
        if root.get("class") not in ("in-text", "note"):
            errors.append("<style> 缺少合法 class 属性（in-text | note）")
        if not root.get("version"):
            warnings.append("<style> 缺少 version 属性（建议 1.0）")

    # 3. info block
    info = root.find(f"{NS}info")
    if info is None:
        errors.append("缺少 <info> 块")
    else:
        for req in ("title", "id", "updated"):
            el = info.find(f"{NS}{req}")
            if el is None or not (el.text or "").strip():
                errors.append(f"<info> 缺少或为空: <{req}>")
        upd = info.find(f"{NS}updated")
        if upd is not None and upd.text and not re.match(r"^\d{4}-\d{2}-\d{2}T", upd.text.strip()):
            warnings.append("<updated> 非 ISO 8601 时间戳格式")
        sid = info.find(f"{NS}id")
        if sid is not None and sid.text and "zotero.org/styles/" in sid.text:
            notes.append(f"样式 ID: {sid.text.strip()}")
        if info.find(f"{NS}link[@rel='self']") is None:
            warnings.append("<info> 缺少 rel=\"self\" 链接（Zotero 样式库要求）")

    # 4. citation / bibliography
    citations = root.findall(f"{NS}citation")
    biblio = root.find(f"{NS}bibliography")
    if len(citations) == 0:
        errors.append("缺少 <citation> 元素")
    elif len(citations) > 1:
        errors.append(f"<citation> 元素过多: {len(citations)} 个（应为 1 个）")
    if biblio is None:
        warnings.append("缺少 <bibliography>（仅当期刊不要求参考文献表时可接受）")

    # 5. macros
    macros = root.findall(f"{NS}macro")
    names = [m.get("name") for m in macros]
    dup = {n for n in names if names.count(n) > 1}
    if dup:
        errors.append(f"macro 名称重复: {', '.join(sorted(dup))}")
    defined = set(names)
    used = {el.get("macro") for el in root.iter(f"{NS}text") if el.get("macro")}
    missing = used - defined
    if missing:
        errors.append(f"引用了未定义的 macro: {', '.join(sorted(missing))}")
    unused = defined - used
    if unused:
        warnings.append(f"定义了但未被引用的 macro（无害，可清理）: {', '.join(sorted(unused))}")

    # 6/7. citation-format consistency
    if info is not None and citations:
        cat = info.find(f"{NS}category")
        fmt = cat.get("citation-format") if cat is not None else None
        cit = citations[0]
        uses_num = cit.find(f".//{NS}text[@variable='citation-number']") is not None
        uses_author = cit.find(f".//{NS}names") is not None
        if fmt == "numeric" and not uses_num:
            warnings.append("category 声明 numeric，但 <citation> 未输出 citation-number")
        if fmt in ("author-date", "author") and not uses_author:
            warnings.append(f"category 声明 {fmt}，但 <citation> 未输出作者名")
        notes.append(f"引用格式类别: {fmt or '(未声明)'}")

    # report
    for n in notes:
        print(f"[信息] {n}")
    for w in warnings:
        print(f"[警告] {w}")
    for e in errors:
        print(f"[错误] {e}")
    if errors:
        sys.exit(f"\n校验未通过：{len(errors)} 个错误，{len(warnings)} 个警告。")
    print(f"\n校验通过：{len(warnings)} 个警告，0 个错误。")
    print("提示：本脚本只校验结构。最终渲染效果请在 Zotero 中安装后用原文示例条目实测比对。")


if __name__ == "__main__":
    main()
