#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wiley_abc_merge.py — Wiley 化学系「一个编号下 a) b) c) 合并多篇」后处理工具

CSL / EndNote / NoteExpress 均无法在样式文件中表达该格式（已验证：
官方 angewandte-chemie.csl 同样做不到）。本脚本在【投稿前去域化后
的纯文本稿件】上按用户指定的分组执行合并与全文重新编号。

用法:
    python wiley_abc_merge.py manuscript.txt groups.json -o out.txt

输入:
    manuscript.txt  UTF-8 纯文本稿件，文内引用形如 [1]、[2,3]、[4-6]、[2,5-7]；
                    参考文献表以单独一行 "References" 或 "参考文献" 开头，
                    条目以 "[n]" 起始（可跨行，续行不得另起 [n]）。
    groups.json     分组指令，如 [[2,3],[5,6,7]]，表示旧 2、3 合并为一组
                    （新编号下 a、b），旧 5、6、7 合并为一组（a、b、c）。
                    每组至少 2 个编号；组间不得重叠；未列入的编号保持独立。

输出规则（遵循 Angew. Chem. / Chem. Eur. J. 惯例）:
    - 每组占一个新编号，组内依次得字母 a, b, c...
    - 参考文献表组合并为一行: [n] a) 条目1 b) 条目2 ...
    - 文内某处引用恰好覆盖某组全部成员 → 显示裸编号 [n]
    - 引用组内部分成员 → 显示带字母形式 [na] / [na,nb]
    - 其余连续纯编号 ≥3 个压缩为区间 [x-y]
"""
import json
import re
import sys

CITE_RE = re.compile(r"\[(\d+(?:\s*(?:,|–|-)\s*\d+)*)\]")
BIB_START_RE = re.compile(r"^\s*(References|参考文献)\s*$", re.IGNORECASE)
BIB_ENTRY_RE = re.compile(r"^\s*\[(\d+)\]\s*")


def die(msg):
    sys.exit("错误: " + msg)


def parse_groups(path):
    with open(path, encoding="utf-8") as f:
        groups = json.load(f)
    if not isinstance(groups, list):
        die("groups.json 须为数组的数组，如 [[2,3],[5,6,7]]")
    seen = set()
    norm = []
    for g in groups:
        if not isinstance(g, list) or len(g) < 2 or not all(isinstance(x, int) for x in g):
            die("每组须为至少 2 个整数编号: %r" % (g,))
        if len(set(g)) != len(g):
            die("组内编号重复: %r" % (g,))
        for x in g:
            if x in seen:
                die("编号 %d 出现在多个组中" % x)
            seen.add(x)
        norm.append(sorted(g))
    return norm


def build_mapping(n_max, groups):
    """old -> (new_num, letter_or_None)；组内成员按组内顺序取字母。"""
    group_of = {}
    for g in groups:
        for i, old in enumerate(g):
            group_of[old] = (g, i)
    mapping, new_num, i = {}, 0, 1
    while i <= n_max:
        if i in group_of:
            g, _ = group_of[i]
            new_num += 1
            for j, old in enumerate(g):
                mapping[old] = (new_num, chr(ord("a") + j))
            i = g[-1] + 1  # 组已排序且要求连续时安全；不连续也按成员逐个映射
        else:
            new_num += 1
            mapping[i] = (new_num, None)
            i += 1
    return mapping, new_num


def fmt_item(num, letter):
    return "%d%s" % (num, letter) if letter else str(num)


def remap_cluster(old_nums, mapping, full_groups):
    """把一个引用簇的旧编号映射为新形式；整组全覆盖时折叠为裸编号。"""
    items = []  # (num, letter)
    i = 0
    while i < len(old_nums):
        n = mapping.get(old_nums[i])
        if n is None:
            die("文内引用了不存在的编号 [%d]" % old_nums[i])
        num, letter = n
        if letter:
            g = full_groups[num]  # 该新编号对应组的全部字母
            # 检查簇内是否恰好连续覆盖全组
            j = i
            letters = []
            while j < len(old_nums) and mapping[old_nums[j]][0] == num:
                letters.append(mapping[old_nums[j]][1])
                j += 1
            if letters == g:
                items.append((num, None))
            else:
                items.extend((num, L) for L in letters)
            i = j
        else:
            items.append((num, None))
            i += 1
    # 压缩连续裸编号（>=3 个为区间）
    out, k = [], 0
    while k < len(items):
        if items[k][1] is None:
            run = [items[k][0]]
            while (k + len(run) < len(items) and items[k + len(run)][1] is None
                   and items[k + len(run)][0] == run[-1] + 1):
                run.append(run[-1] + 1)
            if len(run) >= 3:
                out.append("%d-%d" % (run[0], run[-1]))
            else:
                out.extend(str(x) for x in run)
            k += len(run)
        else:
            out.append(fmt_item(*items[k]))
            k += 1
    return "[" + ",".join(out) + "]"


def expand_cite(content):
    """'2,5-7' -> [2,5,6,7]"""
    nums = []
    for part in re.split(r"\s*,\s*", content):
        m = re.match(r"^(\d+)\s*[-–]\s*(\d+)$", part)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            if b < a:
                die("引用区间倒置: [%s]" % part)
            nums.extend(range(a, b + 1))
        else:
            nums.append(int(part))
    return nums


def split_document(text):
    lines = text.split("\n")
    for idx, ln in enumerate(lines):
        if BIB_START_RE.match(ln):
            return lines[:idx], lines[idx + 1:]
    die("未找到参考文献表起始行（单独一行的 References 或 参考文献）")


def process_body(lines, mapping, full_groups):
    def repl(m):
        old = expand_cite(m.group(1))
        return remap_cluster(old, mapping, full_groups)
    return [CITE_RE.sub(repl, ln) for ln in lines]


def process_bib(lines, mapping):
    """解析 [n] 起始条目（可跨行），按新编号重组输出。"""
    entries = {}
    cur_no, cur_text = None, []
    def flush():
        if cur_no is not None:
            entries[cur_no] = " ".join(t.strip() for t in cur_text if t.strip())
    for ln in lines:
        m = BIB_ENTRY_RE.match(ln)
        if m:
            flush()
            cur_no, cur_text = int(m.group(1)), [ln[m.end():]]
        elif cur_no is not None:
            cur_text.append(ln)
    flush()
    if not entries:
        die("参考文献表中未解析到任何 [n] 条目")
    # 组: new_num -> [(letter, old_no)]
    by_new = {}
    for old in sorted(entries):
        num, letter = mapping[old]
        by_new.setdefault(num, []).append((letter, old, entries[old]))
    out = []
    for num in sorted(by_new):
        parts = by_new[num]
        if len(parts) == 1 and parts[0][0] is None:
            out.append("[%d] %s" % (num, parts[0][2]))
        else:
            seg = " ".join("%s) %s" % (L, txt) for L, _, txt in parts)
            out.append("[%d] %s" % (num, seg))
    return out, len(entries)


def main(argv):
    if len(argv) < 3 or "-o" not in argv:
        die("用法: python wiley_abc_merge.py manuscript.txt groups.json -o out.txt")
    src, gpath = argv[1], argv[2]
    out_path = argv[argv.index("-o") + 1]
    with open(src, encoding="utf-8") as f:
        text = f.read()
    groups = parse_groups(gpath)
    body, bib = split_document(text)
    n_in_bib = max(int(m.group(1)) for ln in bib
                   for m in [BIB_ENTRY_RE.match(ln)] if m)
    n_cited = max((n for ln in body for m in CITE_RE.finditer(ln)
                   for n in expand_cite(m.group(1))), default=0)
    n_max = max(n_in_bib, n_cited)
    for g in groups:
        if g[-1] > n_max:
            die("分组包含超出范围的编号: %r（最大编号 %d）" % (g, n_max))
    mapping, new_total = build_mapping(n_max, groups)
    full_groups = {}
    for g in groups:
        num = mapping[g[0]][0]
        full_groups[num] = [mapping[o][1] for o in g]
    new_body = process_body(body, mapping, full_groups)
    new_bib, n_entries = process_bib(bib, mapping)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(new_body))
        f.write("\nReferences\n")
        f.write("\n".join(new_bib) + "\n")
    print("完成: %d 条旧文献（%d 组合并）→ %d 个新编号" % (n_entries, len(groups), new_total))
    print("输出: " + out_path)


if __name__ == "__main__":
    main(sys.argv)
