# 扫描器与它的报告怎么读（路线甲）

## 一、怎么跑

```
powershell -NoProfile -ExecutionPolicy Bypass -File "<技能目录>/scripts/scan.ps1"
```

- 只认一个参数 `-OutDir <目录>`（默认写到 `%TEMP%\cclean-scan\`）。传任何别的参数它直接拒绝退出——它没有删除功能，也不存在“确认一下就能删”的开关。
- 跑完最后一行会打印报告 JSON 的完整路径，读那个文件。
- 耗时一般 1～10 分钟。⛔ 不用管理员权限跑第一次；读不到的地方它会如实计数，不会崩。
- ⚠️ **扫描 JSON 里有真实用户名和真实路径**，它只留在本机；写进 HTML 报告时路径一律换成 `%USERPROFILE%\...` 形式（硬禁令不变）。

## 二、它替你挡了哪些坑（所以你不用再手工量）

逐文件累加、含隐藏和系统文件、不跟目录联接走、遇错不中断——`measure.md` 第一部分的四条全部固化在代码里。另外三件手工量根本做不到的事它也做了：

1. **系统压缩（CompactOS/WOF）**：这类文件“大小”是假的，扫描器按真实占用计；
2. **硬链接去重**：同一份文件出现在几个目录只计一次，重复的总量单独记在 `crossCheck.hardlinkDupBytes`；
3. **云占位文件**：不占本地空间的“云端文件”不计入目录大小，总量记在 `crossCheck.placeholderBytes`。

## 三、字段表

| 字段 | 内容 | 用法 |
|---|---|---|
| `drive` | C 盘 `totalBytes / usedBytes / freeBytes` | 总账三个数的唯一来源 |
| `otherDrives` | 其他各盘的总量与剩余 | “搬去哪”的建议要引用这里的真数（如“D 盘还空 86 GB”） |
| `tree` | 全盘目录树，最多 4 层，每层最多 15 项（`__rest__` 是“其余更小的项目”合并项，`mergedCount` 是合并了几个） | 第三节钻取树的数据来源；`reparse:true` 的是路标（目录联接），内容在别处，计 0 是对的 |
| `rootFiles` | C 盘根上的散文件 | 一般很小，并进树的账即可 |
| `pageFiles` | `pagefile.sys / hiberfil.sys / swapfile.sys`（存在才列） | 红档；“内存不够时借用硬盘的那块地方” |
| `knownSpots` | 已知清理相关位置的实测大小（**不存在的机器上直接没有那条**） | 第四节步骤金额的来源，键名对照见下表 |
| `browsers` | 每个已装浏览器的缓存合计（跨全部用户档案） | `stepBrowsers` 直接用它，⛔ 没列的浏览器不许写 |
| `vhdx` | 虚拟磁盘镜像：`bytes`＝名义大小，`onDiskBytes`＝真实占用 | 红档，正确动作是迁移不是删；两个数不一致时报真实占用 |
| `apps` | 装机软件按注册表估算大小取前 30，含 `installDrive` | ⚠️ `estimatedBytes` 是注册表自报的，**不可靠，只作线索**；`installDrive` 不是 `C` 的要点名提醒“卸了不腾 C 盘” |
| `restorePoints` | `measured`＝量到了；`unknown_needs_admin`＝没权限没量到 | 没量到就在结尾灰字说明一句，⛔ 不许猜个数 |
| `crossCheck` | 总账交叉验证（见下） | 决定这份数据能不能直接用 |

### `crossCheck` 怎么读

- `deltaPct` = （已用空间 − 树总账）÷ 已用空间。**负数**＝树比已用多算了（残余硬链接、扫描期间文件变动）；**正数**＝有东西没量到（文件系统自身的元数据、没权限的区域、还原点）。
- **|delta| ≤ 5%**：直接用；**5%～10%**：能用，报告结尾灰字说明一句；**> 10%**：先看 `deniedCount` 和 `hardlinkDupBytes` 能不能解释，解释不了就停下来告诉用户，⛔ 不许硬出报告。
- `placeholderBytes` 很大时，在报告里说明“另有 X GB 是云端文件，不占本地空间”。

### `knownSpots` 键名对照（人话名 ＋ 默认档）

默认档只是起点，**每一项仍要过 `measure.md` 第二部分的裁决表**；判断不了的一律黄。

| 键 | 人话名 | 默认档 |
|---|---|---|
| `user_temp` / `windows_temp` | 软件/系统运行留下的临时文件 | 绿 |
| `wu_download` / `delivery_opt` | Windows 更新的下载缓存 | 绿 |
| `crash_dumps` / `minidump` / `wer_reports` | 软件出错时留下的现场记录 | 绿 |
| `thumb_cache` | 图片缩略图缓存 | 绿 |
| `recycle_bin` | 回收站里还没清空的东西 | 绿（先打开看一眼） |
| `npm_cache` / `npx_cache` / `pip_cache` / `yarn_cache` / `pnpm_store` / `nuget_packages` / `cargo_registry` / `gradle_caches` / `maven_repo` / `go_mod` | 装软件时下载的零件（各种开发缓存） | 绿，但删了要重新下载——按裁决表可能落黄 |
| `windows_old` / `upgrade_bt` / `upgrade_ws` / `winre_agent` | 旧系统的备份（升级残留） | 黄——刚升级过、系统还不稳就先放一个月 |
| `wechat_v3_files` / `wechat_v4_files` / `wechat_v4_appdata` | 微信的聊天文件和图片视频 | 黄——里面有他的聊天记录 |
| `qq_files` / `qq_nt` / `wxwork` / `dingtalk` | QQ／企业微信／钉钉的文件 | 黄 |
| `wps_data` | WPS 攒下的数据 | 黄 |
| `downloads` / `desktop` / `documents` / `pictures` / `videos` | 他自己的东西 | 黄，⛔ 永远不许进绿 |
| `onedrive_local` | 网盘的本地副本 | 黄 |
| `winsxs` / `msi_installer` | 系统组件仓库／安装包缓存 | 红 |
| `docker_wsl`（配合 `vhdx`） | 虚拟系统的磁盘镜像 | 红——迁移，不删除 |

## 四、从扫描 JSON 到报告 JSON（数字这样咬合）

⭐ **甲线铁律：报告里每一个数字都必须能在扫描 JSON 里指认出处。** 扫描器没量到的宁可不写。

1. `totals` ← `drive` 三个数换算成 GB。
2. **三个步骤先定**：`stepFolders.rows` ← 绿档 `knownSpots`（金额照抄）；`stepWindows.gb` ← 更新缓存＋回收站等系统清理覆盖项合计；`stepBrowsers` ← `browsers`。
3. **`bar.g` ＝ 三个步骤的合计**（同一组数，天然咬合）；`bar.y` ＝ 判黄各项合计；`bar.r` ＝ 已用 − 绿 − 黄（红兜底闭合总账）；`bar.free` ＝ 剩余。
4. `tree` ← 扫描树砍到每层 12 项、换人话名、逐项写 `what`/`effect`。`__rest__` 直接翻成“（其余更小的项目）”。
5. “清完剩多少”**不用写**——模板自动按 `bar.free ＋ 三步合计` 算。
6. `crossCheck.deltaPct` 在 5%～10% 之间时，结尾灰字说明一句。

## 五、清完对账（v2 新能力）

用户照报告清完后，**再跑一次扫描器**，用两份报告的 `drive.freeBytes` 之差告诉他“实际腾出了 X GB”。差得远就对着两份的 `knownSpots` 找哪步没做成（最常见：回收站没勾）。

---

*扫描器为本技能原创（作者：七也）。清理位置清单参考了 niuhai/skill-c-cleaner 与 dww911/c-drive-cleaner-skill（均为 MIT 许可）的路径知识。*
