#Requires -Version 5.1
<#
    scan.ps1 - C drive read-only scanner for the "cclean" skill (v2).
    Author: Qi Ye (SkillHub: @user_c26ce459/cclean)

    WHAT IT DOES
      Walks C:\ once (hidden/system files included, reparse points not followed),
      measures known cleanup-relevant locations, lists installed apps from the
      registry, and writes ONE report JSON file. Nothing else.

    READ-ONLY BY CONSTRUCTION
      This script contains no delete/move/rename/registry-write API at all.
      The only filesystem writes are: creating the report folder, and a single
      write call for the report file itself. A static gate in the dev tests
      greps this file for forbidden APIs and asserts exactly one write call.

    USAGE
      powershell -NoProfile -ExecutionPolicy Bypass -File .\scan.ps1 [-OutDir <dir>]

      Only -OutDir is accepted. Any other argument is refused (exit 2):
      there is no delete switch, and none can be added from the command line.

    OUTPUT
      <OutDir>\scan-YYYYMMDD-HHmmss.json   (default OutDir: %TEMP%\cclean-scan)
      Schema documented in references/scan.md. All console output is ASCII on
      purpose: the script must survive any codepage on any machine.
#>
[CmdletBinding(PositionalBinding = $false)]
param(
    [Parameter()][string]$OutDir,
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Rest
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ---------- Gate 1: refuse anything but -OutDir ----------
if ($Rest) {
    Write-Host ''
    Write-Host "  [REFUSED] Unknown argument(s): $($Rest -join ' ')" -ForegroundColor Red
    Write-Host '  This scanner only accepts -OutDir. It has no delete function,' -ForegroundColor Yellow
    Write-Host '  so no delete-looking switch will ever be accepted.' -ForegroundColor Yellow
    Write-Host '  Nothing was scanned, nothing was touched.' -ForegroundColor DarkGray
    Write-Host ''
    exit 2
}

if (-not $OutDir) { $OutDir = Join-Path $env:TEMP 'cclean-scan' }

$Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# ---------- Embedded C# walker (read-only; compiled in-memory) ----------
$WalkerSource = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace CcleanScan
{
    public class Node
    {
        public string Name;
        public string Path;
        public long Bytes;
        public DateTime MTime;
        public bool Hidden;
        public bool Reparse;
        public List<Node> Children;
        public int MergedCount;   // >0 on the synthetic "__rest__" node
    }

    public static class Walker
    {
        public static int DeniedCount = 0;
        public static List<string> DeniedSample = new List<string>();
        public static long PlaceholderBytes = 0;   // cloud placeholder files, not counted into Bytes
        public static long FileCount = 0;

        // FILE_ATTRIBUTE_OFFLINE | RECALL_ON_OPEN | RECALL_ON_DATA_ACCESS
        const int PLACEHOLDER_MASK = 0x1000 | 0x40000 | 0x400000;
        // Logical size lies for: FILE_ATTRIBUTE_SPARSE_FILE (0x200), COMPRESSED (0x800),
        // and REPARSE_POINT files (0x400) - Win10 CompactOS/WOF system compression marks
        // files as reparse points WITHOUT the compressed attribute. We therefore ask
        // GetCompressedFileSize for every file; for plain files it just returns the size.

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern uint GetCompressedFileSizeW(string lpFileName, out uint lpFileSizeHigh);

        // --- hardlink dedup: same file reachable via several paths must count once ---
        [StructLayout(LayoutKind.Sequential)]
        struct BY_HANDLE_FILE_INFORMATION
        {
            public uint FileAttributes;
            public System.Runtime.InteropServices.ComTypes.FILETIME CreationTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastAccessTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME LastWriteTime;
            public uint VolumeSerialNumber;
            public uint FileSizeHigh;
            public uint FileSizeLow;
            public uint NumberOfLinks;
            public uint FileIndexHigh;
            public uint FileIndexLow;
        }

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern IntPtr CreateFileW(string lpFileName, uint dwDesiredAccess, uint dwShareMode,
            IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool GetFileInformationByHandle(IntPtr hFile, out BY_HANDLE_FILE_INFORMATION lpFileInformation);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr hObject);

        static readonly IntPtr INVALID_HANDLE = new IntPtr(-1);
        static HashSet<ulong> SeenFileIds = new HashSet<ulong>();
        public static long HardlinkDupBytes = 0;
        public static int HandleFailCount = 0;

        // Returns true if this file is a hardlink duplicate of one already counted.
        // Opens with zero access rights (attributes only): cheap, works on locked files.
        static bool IsHardlinkDuplicate(FileInfo fi)
        {
            if (fi.Length < 1024) return false;   // sub-KB files: not worth a handle each
            IntPtr h = CreateFileW(fi.FullName, 0, 7, IntPtr.Zero, 3, 0x02000000, IntPtr.Zero);
            if (h == INVALID_HANDLE || h == IntPtr.Zero) { HandleFailCount++; return false; }
            try
            {
                BY_HANDLE_FILE_INFORMATION info;
                if (!GetFileInformationByHandle(h, out info)) return false;
                if (info.NumberOfLinks <= 1) return false;
                ulong id = ((ulong)info.FileIndexHigh << 32) | (ulong)info.FileIndexLow;
                if (id == 0) return false;
                return !SeenFileIds.Add(id);   // already seen => duplicate
            }
            finally { CloseHandle(h); }
        }

        static long FileBytes(FileInfo fi, int attrs)
        {
            uint high;
            uint low = GetCompressedFileSizeW(fi.FullName, out high);
            if (low == 0xFFFFFFFF && Marshal.GetLastWin32Error() != 0) return fi.Length;
            return ((long)high << 32) | (long)low;
        }

        // For the PS side (vhdx list): on-disk size of one file, with fallback.
        public static long OnDiskSize(string path, long fallback)
        {
            try
            {
                FileInfo fi = new FileInfo(Pfx(path));
                if (!fi.Exists) return fallback;
                return FileBytes(fi, (int)fi.Attributes);
            }
            catch (Exception) { return fallback; }
        }

        static string Pfx(string path)
        {
            if (path.StartsWith(@"\\?\")) return path;
            return @"\\?\" + path;
        }

        static string Strip(string path)
        {
            if (path.StartsWith(@"\\?\")) return path.Substring(4);
            return path;
        }

        static void Denied(string path)
        {
            DeniedCount++;
            if (DeniedSample.Count < 20) DeniedSample.Add(Strip(path));
        }

        // Full walk keeping child nodes down to keepDepth levels below the start.
        public static Node ScanTree(string path, int keepDepth, int maxKeep)
        {
            DirectoryInfo di = new DirectoryInfo(Pfx(path));
            return Walk(di, 0, keepDepth, maxKeep);
        }

        // Size-only walk (no nodes kept). Used for the known-spots measurements.
        public static long TotalSize(string path)
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(Pfx(path));
                if (!di.Exists) return -1;
                return SizeWalk(di);
            }
            catch (Exception) { return -1; }
        }

        static Node Walk(DirectoryInfo di, int depth, int keepDepth, int maxKeep)
        {
            Node n = new Node();
            n.Name = di.Name;
            n.Path = Strip(di.FullName);
            try { n.MTime = di.LastWriteTime; } catch (Exception) { }

            FileAttributes attrs = 0;
            try { attrs = di.Attributes; } catch (Exception) { }
            n.Hidden = (attrs & FileAttributes.Hidden) != 0;
            if ((attrs & FileAttributes.ReparsePoint) != 0)
            {
                n.Reparse = true;   // junction/symlink: do not follow, count as 0
                return n;
            }

            FileSystemInfo[] entries;
            try { entries = di.GetFileSystemInfos(); }
            catch (Exception) { Denied(di.FullName); return n; }

            List<Node> kids = null;
            if (depth < keepDepth) kids = new List<Node>();

            foreach (FileSystemInfo e in entries)
            {
                try
                {
                    FileInfo fi = e as FileInfo;
                    if (fi != null)
                    {
                        int ia = (int)fi.Attributes;
                        if ((ia & PLACEHOLDER_MASK) != 0) { PlaceholderBytes += fi.Length; }
                        else
                        {
                            long b = FileBytes(fi, ia);
                            if (IsHardlinkDuplicate(fi)) { HardlinkDupBytes += b; }
                            else { n.Bytes += b; }
                        }
                        FileCount++;
                    }
                    else
                    {
                        Node c = Walk((DirectoryInfo)e, depth + 1, keepDepth, maxKeep);
                        n.Bytes += c.Bytes;
                        if (kids != null) kids.Add(c);
                    }
                }
                catch (Exception) { Denied(e.FullName); }
            }

            if (kids != null)
            {
                kids.Sort(delegate(Node a, Node b) { return b.Bytes.CompareTo(a.Bytes); });
                if (kids.Count > maxKeep)
                {
                    Node rest = new Node();
                    rest.Name = "__rest__";
                    rest.Path = "";
                    int merged = 0;
                    for (int i = maxKeep - 1; i < kids.Count; i++)
                    {
                        rest.Bytes += kids[i].Bytes;
                        merged++;
                    }
                    rest.MergedCount = merged;
                    kids.RemoveRange(maxKeep - 1, kids.Count - (maxKeep - 1));
                    kids.Add(rest);
                }
                n.Children = kids;
            }
            return n;
        }

        static long SizeWalk(DirectoryInfo di)
        {
            FileAttributes attrs = 0;
            try { attrs = di.Attributes; } catch (Exception) { return 0; }
            if ((attrs & FileAttributes.ReparsePoint) != 0) return 0;

            FileSystemInfo[] entries;
            try { entries = di.GetFileSystemInfos(); }
            catch (Exception) { Denied(di.FullName); return 0; }

            long total = 0;
            foreach (FileSystemInfo e in entries)
            {
                try
                {
                    FileInfo fi = e as FileInfo;
                    if (fi != null)
                    {
                        int ia = (int)fi.Attributes;
                        if ((ia & PLACEHOLDER_MASK) == 0) total += FileBytes(fi, ia);
                    }
                    else total += SizeWalk((DirectoryInfo)e);
                }
                catch (Exception) { Denied(e.FullName); }
            }
            return total;
        }

        // ---------- JSON writer (manual, fast, no dependencies) ----------
        public static string ToJson(Node n)
        {
            StringBuilder sb = new StringBuilder();
            WriteNode(sb, n);
            return sb.ToString();
        }

        static void Esc(StringBuilder sb, string s)
        {
            sb.Append('"');
            if (s != null)
            {
                foreach (char c in s)
                {
                    if (c == '"' || c == '\\') { sb.Append('\\'); sb.Append(c); }
                    else if (c < ' ') { sb.Append("\\u"); sb.Append(((int)c).ToString("x4")); }
                    else sb.Append(c);
                }
            }
            sb.Append('"');
        }

        static void WriteNode(StringBuilder sb, Node n)
        {
            sb.Append("{\"name\":");
            Esc(sb, n.Name);
            sb.Append(",\"path\":");
            Esc(sb, n.Path);
            sb.Append(",\"bytes\":").Append(n.Bytes);
            sb.Append(",\"mtime\":");
            if (n.MTime == DateTime.MinValue) Esc(sb, "");
            else Esc(sb, n.MTime.ToString("yyyy-MM-dd"));
            if (n.Hidden) sb.Append(",\"hidden\":true");
            if (n.Reparse) sb.Append(",\"reparse\":true");
            if (n.MergedCount > 0) sb.Append(",\"mergedCount\":").Append(n.MergedCount);
            if (n.Children != null && n.Children.Count > 0)
            {
                sb.Append(",\"children\":[");
                for (int i = 0; i < n.Children.Count; i++)
                {
                    if (i > 0) sb.Append(',');
                    WriteNode(sb, n.Children[i]);
                }
                sb.Append(']');
            }
            sb.Append('}');
        }
    }
}
'@

Write-Host ''
Write-Host '  ===== C drive read-only scan =====' -ForegroundColor Cyan
Write-Host '  This tool only LOOKS. It cannot delete anything: there is no delete' -ForegroundColor Gray
Write-Host '  code in it. Expect 1-10 minutes depending on disk speed.' -ForegroundColor Gray
Write-Host ''
Write-Host '  [1/5] Compiling walker...' -ForegroundColor DarkGray
Add-Type -TypeDefinition $WalkerSource -Language CSharp

function Get-GB {
    param([long]$Bytes)
    return [math]::Round($Bytes / 1GB, 2)
}

# ---------- [2/5] Walk the tree ----------
Write-Host '  [2/5] Walking C:\ (hidden and system files included)...' -ForegroundColor DarkGray

$topEntries = Get-ChildItem -LiteralPath 'C:\' -Force -ErrorAction SilentlyContinue
$childJsons = New-Object System.Collections.Generic.List[string]
[long]$rootFilesBytes = 0
$rootFiles = @()

foreach ($entry in $topEntries) {
    if ($entry -is [System.IO.FileInfo]) {
        $rootFilesBytes += $entry.Length
        $rootFiles += [ordered]@{
            name  = $entry.Name
            bytes = [long]$entry.Length
            mtime = $entry.LastWriteTime.ToString('yyyy-MM-dd')
        }
        continue
    }
    $isReparse = (($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)
    if ($isReparse) {
        $childJsons.Add(('{{"name":{0},"path":{1},"bytes":0,"mtime":"","reparse":true}}' -f `
            (ConvertTo-Json ([string]$entry.Name)), (ConvertTo-Json ([string]$entry.FullName))))
        continue
    }
    $node = [CcleanScan.Walker]::ScanTree($entry.FullName, 2, 15)
    $childJsons.Add([CcleanScan.Walker]::ToJson($node))
    Write-Host ("      {0,-28} {1,10} GB" -f $entry.Name, (Get-GB $node.Bytes)) -ForegroundColor DarkGray
}

[long]$treeBytes = $rootFilesBytes
foreach ($j in $childJsons) {
    if ($j -match '"bytes":(\d+)') { $treeBytes += [long]$Matches[1] }
}

$treeJson = '{"name":"C:","path":"C:\\","bytes":' + $treeBytes + ',"mtime":"","children":[' + `
    ($childJsons -join ',') + ']}'

# ---------- [3/5] Known spots ----------
Write-Host '  [3/5] Measuring known cleanup-relevant locations...' -ForegroundColor DarkGray

# key = stable identifier the skill docs map to Chinese labels.
# path = display form with env vars; resolved before measuring.
$SpotDefs = @(
    @{ key = 'user_temp';        path = '%LOCALAPPDATA%\Temp' }
    @{ key = 'windows_temp';     path = '%SystemRoot%\Temp' }
    @{ key = 'wu_download';      path = '%SystemRoot%\SoftwareDistribution\Download' }
    @{ key = 'delivery_opt';     path = '%SystemRoot%\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization' }
    @{ key = 'crash_dumps';      path = '%LOCALAPPDATA%\CrashDumps' }
    @{ key = 'minidump';         path = '%SystemRoot%\Minidump' }
    @{ key = 'wer_reports';      path = '%ProgramData%\Microsoft\Windows\WER' }
    @{ key = 'thumb_cache';      path = '%LOCALAPPDATA%\Microsoft\Windows\Explorer' }
    @{ key = 'recycle_bin';      path = 'C:\$Recycle.Bin' }
    @{ key = 'windows_old';      path = 'C:\Windows.old' }
    @{ key = 'upgrade_bt';       path = 'C:\$WINDOWS.~BT' }
    @{ key = 'upgrade_ws';       path = 'C:\$Windows.~WS' }
    @{ key = 'winre_agent';      path = 'C:\$WinREAgent' }
    @{ key = 'winsxs';           path = '%SystemRoot%\WinSxS' }
    @{ key = 'msi_installer';    path = '%SystemRoot%\Installer' }
    @{ key = 'npm_cache';        path = '%LOCALAPPDATA%\npm-cache' }
    @{ key = 'npx_cache';        path = '%LOCALAPPDATA%\npm-cache\_npx' }
    @{ key = 'pip_cache';        path = '%LOCALAPPDATA%\pip\cache' }
    @{ key = 'yarn_cache';       path = '%LOCALAPPDATA%\Yarn\Cache' }
    @{ key = 'pnpm_store';       path = '%LOCALAPPDATA%\pnpm\store' }
    @{ key = 'nuget_packages';   path = '%USERPROFILE%\.nuget\packages' }
    @{ key = 'cargo_registry';   path = '%USERPROFILE%\.cargo\registry' }
    @{ key = 'gradle_caches';    path = '%USERPROFILE%\.gradle\caches' }
    @{ key = 'maven_repo';       path = '%USERPROFILE%\.m2\repository' }
    @{ key = 'go_mod';           path = '%USERPROFILE%\go\pkg\mod' }
    @{ key = 'wechat_v3_files';  path = '%USERPROFILE%\Documents\WeChat Files' }
    @{ key = 'wechat_v4_files';  path = '%USERPROFILE%\Documents\xwechat_files' }
    @{ key = 'wechat_v4_appdata';path = '%APPDATA%\Tencent\xwechat' }
    @{ key = 'qq_files';         path = '%USERPROFILE%\Documents\Tencent Files' }
    @{ key = 'qq_nt';            path = '%APPDATA%\Tencent\QQ\nt_qq' }
    @{ key = 'wxwork';           path = '%APPDATA%\Tencent\WXWork' }
    @{ key = 'dingtalk';         path = '%APPDATA%\DingTalk' }
    @{ key = 'wps_data';         path = '%APPDATA%\kingsoft' }
    @{ key = 'downloads';        path = '%USERPROFILE%\Downloads' }
    @{ key = 'desktop';          path = '%USERPROFILE%\Desktop' }
    @{ key = 'documents';        path = '%USERPROFILE%\Documents' }
    @{ key = 'pictures';         path = '%USERPROFILE%\Pictures' }
    @{ key = 'videos';           path = '%USERPROFILE%\Videos' }
    @{ key = 'onedrive_local';   path = '%USERPROFILE%\OneDrive' }
    @{ key = 'docker_wsl';       path = '%LOCALAPPDATA%\Docker\wsl' }
)

function Resolve-EnvPath {
    param([string]$Path)
    return [System.Environment]::ExpandEnvironmentVariables($Path)
}

$knownSpots = @()
foreach ($def in $SpotDefs) {
    $resolved = Resolve-EnvPath $def.path
    $bytes = [CcleanScan.Walker]::TotalSize($resolved)
    if ($bytes -lt 0) { continue }   # does not exist on this machine: omit entirely
    $mtime = ''
    try { $mtime = (Get-Item -LiteralPath $resolved -Force).LastWriteTime.ToString('yyyy-MM-dd') } catch { }
    $knownSpots += [ordered]@{
        key   = $def.key
        path  = $def.path
        bytes = [long]$bytes
        mtime = $mtime
    }
}

# Browser caches: per browser, sum of cache dirs across profiles.
$BrowserDefs = @(
    @{ name = 'Chrome';  base = '%LOCALAPPDATA%\Google\Chrome\User Data' }
    @{ name = 'Edge';    base = '%LOCALAPPDATA%\Microsoft\Edge\User Data' }
    @{ name = 'Brave';   base = '%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data' }
)
$CacheSubdirs = @('Cache', 'Code Cache', 'GPUCache', 'Service Worker\CacheStorage')
$browsers = @()
foreach ($b in $BrowserDefs) {
    $base = Resolve-EnvPath $b.base
    if (-not (Test-Path -LiteralPath $base -PathType Container)) { continue }
    [long]$cacheBytes = 0
    $profiles = @(Get-ChildItem -LiteralPath $base -Directory -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' })
    foreach ($p in $profiles) {
        foreach ($sub in $CacheSubdirs) {
            $c = [CcleanScan.Walker]::TotalSize((Join-Path $p.FullName $sub))
            if ($c -gt 0) { $cacheBytes += $c }
        }
    }
    $browsers += [ordered]@{ name = $b.name; cacheBytes = $cacheBytes; profiles = $profiles.Count }
}
$ffBase = Resolve-EnvPath '%LOCALAPPDATA%\Mozilla\Firefox\Profiles'
if (Test-Path -LiteralPath $ffBase -PathType Container) {
    [long]$ffBytes = 0
    $ffProfiles = @(Get-ChildItem -LiteralPath $ffBase -Directory -Force -ErrorAction SilentlyContinue)
    foreach ($p in $ffProfiles) {
        $c = [CcleanScan.Walker]::TotalSize((Join-Path $p.FullName 'cache2'))
        if ($c -gt 0) { $ffBytes += $c }
    }
    $browsers += [ordered]@{ name = 'Firefox'; cacheBytes = $ffBytes; profiles = $ffProfiles.Count }
}

# WSL / virtual disk images (vhdx): the classic "biggest single file" suspects.
$vhdx = @()
$vhdxRoots = @(
    (Resolve-EnvPath '%LOCALAPPDATA%\Packages'),
    (Resolve-EnvPath '%LOCALAPPDATA%\Docker'),
    (Resolve-EnvPath '%LOCALAPPDATA%\wsl')
)
foreach ($root in $vhdxRoots) {
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
    $found = Get-ChildItem -LiteralPath $root -Filter '*.vhdx' -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($f in $found) {
        $vhdx += [ordered]@{
            path        = $f.FullName
            bytes       = [long]$f.Length
            onDiskBytes = [long][CcleanScan.Walker]::OnDiskSize($f.FullName, $f.Length)
            mtime       = $f.LastWriteTime.ToString('yyyy-MM-dd')
        }
    }
}

# ---------- [4/5] Installed apps (registry, read-only) ----------
Write-Host '  [4/5] Reading installed apps from the registry...' -ForegroundColor DarkGray

$apps = @()
$uninstallRoots = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
foreach ($root in $uninstallRoots) {
    $items = @()
    try { $items = Get-ItemProperty -Path $root -ErrorAction SilentlyContinue } catch { }
    foreach ($it in $items) {
        $name = ''
        try { $name = [string]$it.DisplayName } catch { }
        if (-not $name) { continue }
        [long]$estBytes = 0
        try { if ($it.PSObject.Properties['EstimatedSize']) { $estBytes = [long]$it.EstimatedSize * 1KB } } catch { }
        $loc = ''
        try { if ($it.PSObject.Properties['InstallLocation']) { $loc = [string]$it.InstallLocation } } catch { }
        $drive = ''
        if ($loc -match '^([A-Za-z]):') { $drive = $Matches[1].ToUpperInvariant() }
        $apps += [ordered]@{
            name           = $name
            estimatedBytes = $estBytes
            installDrive   = $drive
        }
    }
}
$apps = @($apps | Sort-Object { -[long]$_.estimatedBytes } | Select-Object -First 30)

# Page/hibernation files on the drive root.
$pageFiles = @()
foreach ($pf in @('pagefile.sys', 'hiberfil.sys', 'swapfile.sys')) {
    try {
        $fi = New-Object System.IO.FileInfo ("C:\" + $pf)
        if ($fi.Exists) {
            $pageFiles += [ordered]@{ name = $pf; bytes = [long]$fi.Length }
        }
    } catch { }
}

# System restore usage: usually needs admin; report honestly either way.
$restore = [ordered]@{ status = 'unknown_needs_admin'; bytes = 0 }
try {
    $ss = Get-CimInstance -ClassName Win32_ShadowStorage -ErrorAction Stop
    [long]$ssBytes = 0
    foreach ($s in $ss) { $ssBytes += [long]$s.AllocatedSpace }
    $restore = [ordered]@{ status = 'measured'; bytes = $ssBytes }
} catch { }

# ---------- [5/5] Totals, cross-check, report ----------
Write-Host '  [5/5] Writing report...' -ForegroundColor DarkGray

$driveC = New-Object System.IO.DriveInfo 'C'
[long]$totalBytes = $driveC.TotalSize
[long]$freeBytes  = $driveC.AvailableFreeSpace
[long]$usedBytes  = $totalBytes - $freeBytes

$otherDrives = @()
foreach ($d in [System.IO.DriveInfo]::GetDrives()) {
    try {
        if ($d.DriveType -ne [System.IO.DriveType]::Fixed) { continue }
        if ($d.Name -like 'C*') { continue }
        $otherDrives += [ordered]@{
            name       = $d.Name.TrimEnd('\')
            totalBytes = [long]$d.TotalSize
            freeBytes  = [long]$d.AvailableFreeSpace
        }
    } catch { }
}

[long]$deltaBytes = $usedBytes - $treeBytes
$deltaPct = 0.0
if ($usedBytes -gt 0) { $deltaPct = [math]::Round([double]$deltaBytes / $usedBytes * 100, 1) }

$Stopwatch.Stop()

$doc = [ordered]@{
    schemaVersion  = 1
    generator      = 'cclean scan.ps1 v2.0.0 (author: Qi Ye)'
    scannedAt      = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    elapsedSeconds = [math]::Round($Stopwatch.Elapsed.TotalSeconds, 1)
    admin          = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    drive          = [ordered]@{ letter = 'C'; totalBytes = $totalBytes; freeBytes = $freeBytes; usedBytes = $usedBytes }
    otherDrives    = $otherDrives
    tree           = '__TREE__'
    rootFiles      = $rootFiles
    pageFiles      = $pageFiles
    knownSpots     = $knownSpots
    browsers       = $browsers
    vhdx           = $vhdx
    apps           = $apps
    restorePoints  = $restore
    crossCheck     = [ordered]@{
        treeBytes        = $treeBytes
        usedBytes        = $usedBytes
        deltaBytes       = $deltaBytes
        deltaPct         = $deltaPct
        placeholderBytes = [long][CcleanScan.Walker]::PlaceholderBytes
        hardlinkDupBytes = [long][CcleanScan.Walker]::HardlinkDupBytes
        handleFailCount  = [int][CcleanScan.Walker]::HandleFailCount
        fileCount        = [long][CcleanScan.Walker]::FileCount
        deniedCount      = [int][CcleanScan.Walker]::DeniedCount
        deniedSample     = @([CcleanScan.Walker]::DeniedSample)
    }
}

if (-not (Test-Path -LiteralPath $OutDir -PathType Container)) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
}
$reportPath = Join-Path $OutDir ('scan-' + (Get-Date).ToString('yyyyMMdd-HHmmss') + '.json')

$json = $doc | ConvertTo-Json -Depth 6
$json = $json.Replace('"__TREE__"', $treeJson)
[System.IO.File]::WriteAllText($reportPath, $json, (New-Object System.Text.UTF8Encoding($false)))

Write-Host ''
Write-Host ("  [OK] Scan finished in {0}s. {1} files seen, nothing touched." -f `
    [math]::Round($Stopwatch.Elapsed.TotalSeconds, 1), [CcleanScan.Walker]::FileCount) -ForegroundColor Green
Write-Host ("       C: total {0} GB / used {1} GB / free {2} GB" -f `
    (Get-GB $totalBytes), (Get-GB $usedBytes), (Get-GB $freeBytes)) -ForegroundColor Cyan
Write-Host ("       Tree accounts for {0} GB ({1}% gap to used space)" -f `
    (Get-GB $treeBytes), $deltaPct) -ForegroundColor Cyan
if ([CcleanScan.Walker]::HardlinkDupBytes -gt 0) {
    Write-Host ("       Hardlink duplicates not double-counted: {0} GB" -f `
        (Get-GB ([long][CcleanScan.Walker]::HardlinkDupBytes))) -ForegroundColor DarkGray
}
if ([CcleanScan.Walker]::DeniedCount -gt 0) {
    Write-Host ("       {0} entries could not be read (normal without admin rights)" -f `
        [CcleanScan.Walker]::DeniedCount) -ForegroundColor DarkGray
}
Write-Host ''
Write-Host ("  Report: {0}" -f $reportPath) -ForegroundColor Yellow
Write-Host ''
exit 0
