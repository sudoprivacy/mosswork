# OKRKPI撰写拆解助手 · 使用说明 (USAGE)

## 一句话
目标变可衡量 OKR/KPI 并层层拆解，对齐清晰、复盘有依据。

## 支持客户端
WorkBuddy / Claude / Cursor / Codex / Windsurf / Gemini / Copilot / OpenClaw（共 8 个，跨平台通用）

## 安装（多客户端示例）
- WorkBuddy：复制本技能文件夹到 `~/.workbuddy/skills/`
- Claude：复制本技能文件夹到 `~/.claude/skills/`
- Cursor：复制本技能文件夹到 `~/.cursor/skills/`
- Codex：复制本技能文件夹到 `~/.codex/skills/`
- Windsurf：复制本技能文件夹到 `~/.windsurf/skills/`
- Gemini：复制本技能文件夹到 `~/.gemini/skills/`
- Copilot：复制本技能文件夹到 `~/.copilot/skills/ (或 VS Code 用户目录)`
- OpenClaw：复制本技能文件夹到 `OpenClaw 的 skills 目录`

> 通用做法：把本技能整个文件夹（含 SKILL.md 与 USAGE.md）复制到对应客户端的 skills 目录下，重启 / 刷新客户端即可识别。

## 使用步骤
1. 安装后，在对话中描述你的需求并提及触发词（见 SKILL.md）。
2. 按 SKILL.md 的「工作流程」逐步提供输入。
3. 获得结构化输出，按需微调后直接使用。

## 注意事项
- 本技能为纯提示词 / 规则型，无需额外依赖、无需联网。
- 不同客户端加载入口略有差异，但技能内容完全一致。
- 不绑定任何平台独占工具，删除文件夹即卸载，无残留。
