#!/usr/bin/env python3
"""
封面标题字叠加脚本（sunny-article 技能专用）

用法:
    python3.11 add_cover_text.py <输入封面图> <输出图> "第一行" "第二行" ["副题小字"]

效果: 底部半透明绿色渐变衬底 + 白色粗体标题(带阴影) + 可选暖黄小字副题, 居中排版。
"""
import sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"


def center_text(overlay, draw, text, font, cy, fill=(255, 255, 255, 255), shadow=True):
    W, H = overlay.size
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    x = (W - tw) // 2 - bbox[0]
    if shadow:
        sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        sd.text((x + 4, cy + 4), text, font=font, fill=(0, 40, 20, 180))
        sh = sh.filter(ImageFilter.GaussianBlur(3))
        overlay.alpha_composite(sh)
    draw.text((x, cy), text, font=font, fill=fill)


def main():
    if len(sys.argv) < 5:
        print(__doc__)
        sys.exit(1)
    src, dst, line1, line2 = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
    subtitle = sys.argv[5] if len(sys.argv) > 5 else None

    img = Image.open(src).convert("RGBA")
    W, H = img.size

    # 底部渐变衬底
    grad = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    start = int(H * 0.55) + 1
    for y in range(start, H):
        a = int(200 * max(0.0, (y - H * 0.55) / (H * 0.45)) ** 1.3)
        gd.line([(0, y), (W, y)], fill=(20, 60, 30, a))
    overlay = Image.alpha_composite(img, grad)

    d = ImageDraw.Draw(overlay)
    font_big = ImageFont.truetype(FONT_PATH, int(W * 0.155))
    y1 = int(H * 0.68)
    center_text(overlay, d, line1, font_big, y1)
    center_text(overlay, d, line2, font_big, y1 + int(W * 0.185))
    if subtitle:
        font_small = ImageFont.truetype(FONT_PATH, int(W * 0.052))
        center_text(overlay, d, subtitle, font_small, y1 + int(W * 0.38), fill=(255, 240, 190, 255))

    overlay.convert("RGB").save(dst, quality=95)
    print(f"OK -> {dst} ({W}x{H})")


if __name__ == "__main__":
    main()
