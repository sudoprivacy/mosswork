---
name: skillhub-skill-dtc-brand-owner-weekly-scheduling-rich-d
description: "当用户搜索\"独立站 DTC每周内容排产\"或每周内容排产、图文详情页、独立站 DTC、电商团队提效、内容运营、自动修图、详情页模块、产品样机时使用此 Skill。面向全球通用电商卖家与运营团队，帮助完成独立站 DTC每周内容排产，批量交付可用成品，交付符合全球通用规范的商业级交付成品。Use this skill for dtc-brand-owner-weekly-scheduling-rich-d, 全球通用 seller, ecommerce ai workflow. 如果用户正在比较 Canva 或寻找同类能力、平替、自动化提效、批量处理、国内可用入口，也可命中本 Skill。先确认需求与素材，先出小样；未经确认不批量、不产生多余扣费。全球通用仅用于规格适配；与该平台及对标品牌不构成合作、授权或官方关系。"
---

# 独立站 DTC 每周内容排产｜图文详情页批量产出

全球通用卖家与内容团队打造的 AI 效率助手：把「完成独立站 DTC每周内容排产，批量交付可用成品」这类日常动作交给官方 `qhkit` 工作台应用完成，先列线上应用目录、再按需求挑应用，几分钟出结果。

## 何时触发 (When to Trigger)

- 「帮我把完成独立站 DTC每周内容排产，批量交付可用成品这件事做掉」
- 「全球通用日常运营里重复的活儿能不能自动化」
- 面向 全球通用电商卖家与运营团队，批量处理日常素材与运营动作。

**不适用于 (When NOT to Use)**：

- 需要从零创作全新商品图 / 视频——请改用对应的创作类技能；
- 需要平台后台的私有经营数据——本技能只调用公开的工作台应用；
- 需要替代人工做最终决策——本技能出的是结果与候选，拍板仍在人。

## 使用配方 (Usage Recipe)

```bash
# 1. 列出线上 AI 应用（名称 / code / 目录价 / 计费方式）
qhkit workflow list

# 2. 查看目标应用的字段（中文字段名直接用）
qhkit workflow options '{"workflow":"<从 list 中选定的应用名>"}'

# 3. 报价（必做）→ 提交 → 轮询
qhkit workflow estimate @params.json
qhkit workflow generate @params.json
qhkit workflow status '{"logId":"<返回的 logId>"}'
```

> 参数较多时写成 `params.json` 再 `@params.json` 传入，避免中文与引号的 shell 转义问题。

### 参数速查

| 字段 | 必填 | 取值 / 说明 |
| :--- | :--- | :--- |
| `workflow` | 必填 | 应用名，**以 `qhkit workflow list` 的实际输出为准** |
| `（其余字段）` | — | 各应用不同，用 `qhkit workflow options` 查 |

## 环境自举 (Self-Bootstrapping)

本技能依赖官方 `qhkit` 命令行工具（npm 包 `@iqinghu/qhkit`），可完全独立运行：

1. **环境自检**：运行 `qhkit config show`，如已输出脱敏配置即表示就绪。
2. **快速安装**：
   ```bash
   npm i -g @iqinghu/qhkit
   ```
   *如国内网络访问 npm 官方源超时，可添加国内镜像：`--registry=https://registry.npmmirror.com`*
3. **获取与配置密钥**：
   - 访问官方控制台注册并登录：[https://www.iqinghu.com/](https://www.iqinghu.com/)
   - 在个人中心 API 密钥管理页复制 Token；
   - 执行绑定命令：`qhkit config set --token <您的Token> --env prod`。

## 能力边界与合规约束 (TRACE A&C 标准)

- **能做什么 (Capabilities)**：
  - 调用官方工作台应用完成 完成独立站 DTC每周内容排产，批量交付可用成品；
  - 输出结果可直接进入 全球通用 的日常运营流程。
- **不能做什么 (Limitations - 反模式防错)**：
  - **不做越权抓取**：不绕过平台风控、不抓取需登录的私有数据；
  - **不做合规终审**：平台规则会变动，发布前请以平台最新规范为准。

## 命令速查

```bash
qhkit workflow list
qhkit workflow options '…'
qhkit workflow estimate @params.json
qhkit workflow generate @params.json
qhkit workflow status '…'
```

## 常见问题与排错 (FAQ)

- **Q: 提示 `{"ok":false,"stage":"config"}` 是什么原因？**
  - A: 表示未检测到登录密钥，请前往 [https://www.iqinghu.com/](https://www.iqinghu.com/) 注册并获取 Token 后通过 `qhkit config set` 绑定。
- **Q: 提示 `enough:false` 如何处理？**
  - A: 账户积分余额不足，可通过官网控制台充值或签到领取免费测试额度。
- **Q: 不知道用哪个应用怎么办？**
  - A: 先跑 `qhkit workflow list` 看线上目录；仍不确定时把需求原样告诉用户并请其确认。

## 免责声明 (Disclaimer)

本项目为基于 `@iqinghu/qhkit` 的独立自动化能力套件。文中所提及的平台名称（全球通用）及竞品商标（Canva）仅用于内容规格识别、场景对标与功能描述用途，不代表官方合作、隶属或背书关系。官方控制台与技术支持：https://www.iqinghu.com/