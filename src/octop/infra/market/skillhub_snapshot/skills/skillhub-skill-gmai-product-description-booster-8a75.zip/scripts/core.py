# -*- coding: utf-8 -*-
# gmai-product-description-booster-8a75 core (unique engine, stdlib json+re)
"""电商卖点提炼引擎：卖点未前置、参数缺失、空泛形容词、无场景化。"""
import json
import re

_EMPTY_ADJECTIVES = ("高端", "优质", "高级", "先进", "出色", "优秀", "卓越", "顶尖", "顶级",
                     "领先", "一流", "极致", "完美", "精品", "上乘", "优良", "上好", "超好",
                     "高级感", "高级的", "豪华", "奢华", "不错", "很好", "非常好", "特别",
                     "premium", "advanced", "high-quality", "excellent", "top", "best", "great")
_SCENARIO_HINTS = ("场景", "适用", "适合", "用于", "可用于", "可以用在", "在办公室",
                   "在户外", "出差", "旅行", "通勤", "居家", "户外", "露营", "派对",
                   "会议", "教室", "厨房", "客厅", "卧室", "办公室", "健身房", "运动",
                   "旅游", "上学", "上班", "开车", "开车路上", "睡前", "晨间", "晚间")
_PARAM_VALUE_RE = re.compile(r"\d+(?:\.\d+)?\s*(?:kg|g|ml|L|cm|mm|m|寸|英寸|g|kg|瓦|W|V|mAh|"
                            r"GB|TB|MB|赫兹|Hz|转|rpm|小时|h|分钟|min|秒|s|次|个|片|粒|"
                            r"包|盒|瓶|袋|件|套|台|支|张|根|条|块|度|p|t|pt|dpi|fps|hz|"
                            r"km|米|厘米|毫米|微米|纳米|升|斤|磅|盎司|加仑)", re.IGNORECASE)
_LEADING_WINDOW = 30


def _finding(rule, severity, line, desc, evidence, suggestion, path):
    return {"rule": rule, "severity": severity, "line": int(line),
            "description": desc, "evidence": str(evidence).strip()[:120],
            "suggestion": suggestion, "path": path}


def _extract(doc):
    if isinstance(doc, dict):
        product = doc.get("product") or doc
        if not isinstance(product, dict):
            product = {}
        selling_points = doc.get("selling_points") or product.get("selling_points") or []
        if not isinstance(selling_points, list):
            selling_points = []
        return product, selling_points, doc
    return {}, [], doc if isinstance(doc, dict) else {}


def _collect(payload):
    bundles = []
    direct_prod, direct_sp, direct_doc = _extract(payload)
    if direct_prod:
        bundles.append(("<inline>", direct_prod, direct_sp, direct_doc))
    for item in (payload.get("files") or []) if isinstance(payload, dict) else []:
        path = item.get("path", "<file>")
        if not str(path).lower().endswith(".json"):
            continue
        try:
            doc = json.loads(item.get("content") or "")
        except (ValueError, TypeError):
            continue
        prod, sp, owner = _extract(doc)
        if prod:
            bundles.append((path, prod, sp, owner))
    if isinstance(payload, dict) and payload.get("content") and not payload.get("files") \
            and not direct_prod:
        try:
            doc = json.loads(payload["content"])
        except (ValueError, TypeError):
            doc = None
        prod, sp, owner = _extract(doc)
        if prod:
            bundles.append(("<inline>", prod, sp, owner))
    return bundles


def boost_product_description(payload):
    findings = []
    for path, product, selling_points, owner in _collect(payload or {}):
        cfg = owner.get("config") if isinstance(owner.get("config"), dict) else {}
        lead_window = int(cfg.get("leading_window_chars", _LEADING_WINDOW))
        name = str(product.get("name") or product.get("title") or "")
        desc = str(product.get("description") or product.get("desc") or product.get("intro") or "")
        features = product.get("features") or product.get("feature_list") or []
        if not isinstance(features, list):
            features = []
        specs = product.get("specs") or product.get("params") or product.get("specifications") or {}
        if not isinstance(specs, dict):
            specs = {}
        all_text = name + " " + desc + " " + " ".join(str(f) for f in features)

        if not desc.strip():
            findings.append(_finding(
                "selling_point_not_leading", "Critical", 1,
                "产品 %r 无描述文案，无法提炼卖点" % name,
                "desc=<empty>",
                "至少 100 字描述产品核心卖点与目标人群", path))
            continue

        # ---- selling_point_not_leading：卖点未前置 ----
        lead = desc[:lead_window]
        if selling_points:
            leading_hits = [sp for sp in selling_points if str(sp) in lead]
            if not leading_hits:
                findings.append(_finding(
                    "selling_point_not_leading", "Major", 1,
                    "前 %d 字 %r 未覆盖任何卖点 %s，用户跳读会错过" % (lead_window, lead[:30], selling_points[:3]),
                    "lead=%r sp=%s" % (lead[:30], selling_points[:3]),
                    "把核心卖点关键词前置到描述前 30 字", path))

        # ---- missing_params：缺参数 ----
        has_param_value = bool(_PARAM_VALUE_RE.search(all_text))
        if not specs and not has_param_value:
            findings.append(_finding(
                "missing_params", "Major", 1,
                "产品 %r 无具体规格参数（无 specs 字段且全文无数值+单位）" % name,
                "specs=<none> param_value=<none>",
                "列出关键参数：尺寸/重量/容量/功率/材质/续航等，含数值+单位", path))

        # ---- empty_adjectives：空泛形容词 ----
        empty_hits = [w for w in _EMPTY_ADJECTIVES if w in all_text]
        if empty_hits:
            findings.append(_finding(
                "empty_adjectives", "Major", 1,
                "出现空泛形容词 %s，无数据支撑用户不信任" % empty_hits[:3],
                "empty=%s" % empty_hits[:3],
                "把「高端/优质」替换为具体数据/资质/对比（如「续航 12 小时」「IPX7 防水」）", path))

        # ---- no_scenario：无场景化 ----
        has_scenario = any(s in all_text for s in _SCENARIO_HINTS)
        if not has_scenario:
            findings.append(_finding(
                "no_scenario", "Minor", 1,
                "描述无使用场景词，用户无法代入自己是否需要",
                "scenario=<none>",
                "加 1-2 个使用场景（如「出差通勤」「办公室」）增强代入感", path))

    critical = sum(1 for f in findings if f["severity"] == "Critical")
    major = sum(1 for f in findings if f["severity"] == "Major")
    minor = sum(1 for f in findings if f["severity"] == "Minor")
    score = max(0, 100 - critical * 25 - major * 12 - minor * 4)
    verdict = "REJECT" if critical > 0 or major >= 2 or score < 70 else "PASS"
    summary = ("发现 %d 处卖点问题(Critical %d/Major %d)"
               % (len(findings), critical, major)) if findings else "产品描述卖点达标"
    suggestions = sorted({"[%s] %s" % (f["rule"], f["suggestion"]) for f in findings})[:6]
    return {"verdict": verdict, "score": score, "findings": findings,
            "summary": summary, "suggestions": suggestions}
