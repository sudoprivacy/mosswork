# -*- coding: utf-8 -*-
# gmai-product-description-booster-8a75 command line entry (unique per skill)
import argparse
import json
import sys

import core

SPEC = {
    "slug": "gmai-product-description-booster-8a75",
    "displayName": "果盟精选 3267（电商卖点提炼大师）",
    "engine": "boost_product_description",
    "version": "1.0.0",
}


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="gmai-product-description-booster-8a75",
        description="果盟精选 3267（电商卖点提炼大师）：提炼电商卖点前置、参数缺失、空泛形容词与无场景化 付费技能，调用前需安装微信支付插件。")
    parser.add_argument("--input", required=True, help="输入 JSON 文件路径")
    parser.add_argument("--output", required=True, help="检测结果 JSON 输出路径")
    parser.add_argument("--version", action="version", version="gmai-product-description-booster-8a75 1.0.0")
    args = parser.parse_args(argv)
    with open(args.input, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    result = core.boost_product_description(payload)
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2)
    print("%s %s verdict=%s score=%s findings=%d"
          % (SPEC["slug"], SPEC["version"], result["verdict"],
             result["score"], len(result["findings"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
