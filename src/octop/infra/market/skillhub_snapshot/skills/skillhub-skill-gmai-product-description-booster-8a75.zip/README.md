# 果盟精选 3267（电商卖点提炼大师）

提炼电商卖点前置、参数缺失、空泛形容词与无场景化

付费技能（X402 微信 Agent Pay，¥2.90/次），调用前需安装微信支付插件。

- 运行：`python main.py --input examples/input.json --output result.json`
- 测试：`python -m unittest discover -s test -v`
- 支付：见 SKILL.md「调用前置检查与支付引导」

### 示例

- 示例请求：用户说「本技能核心场景」，并附上相关材料或参数。
- 处理：技能先核对输入完备度，再按内置工作流逐项处理。
- 示例输出：结构化报告（结论 → 依据/数据 → 下一步行动清单），可直接复制使用。
