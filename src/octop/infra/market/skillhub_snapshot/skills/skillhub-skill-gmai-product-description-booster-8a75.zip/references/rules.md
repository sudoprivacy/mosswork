# 规则手册 - 果盟精选 3267（电商卖点提炼大师）

| rule | severity | 检测项 | 修复建议 |
|---|---|---|---|
| selling_point_not_leading | Major | 卖点未前置 | 卖点前置前30字 |
| missing_params | Major | 参数缺失 | 列规格+数值+单位 |
| empty_adjectives | Major | 空泛形容词 | 改具体数据 |
| no_scenario | Minor | 无场景化 | 加1-2个使用场景 |
