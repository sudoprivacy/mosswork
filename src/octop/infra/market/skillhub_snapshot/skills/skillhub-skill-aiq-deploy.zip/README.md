# NVIDIA AI-Q Blueprint 部署

- 唯一标识：`aiq-deploy`
- 显示名称：NVIDIA AI-Q Blueprint 部署
- 能力摘要：在 Docker Compose、CLI、Web UI 或 Kubernetes/Helm 路径部署并验证 NVIDIA AI-Q Blueprint，安全准备环境与密钥、选择运行模式、检查健康状态、排查故障和交接可访问研究后端。

## 案例素材

1. 研究团队需要本地后端供 AI-Q 深度研究使用，确认仓库与 Docker Compose 条件后创建被 Git 忽略的 `.env`，只提醒用户配置模型和检索密钥而不打印或索取密钥值。
2. 平台团队选择 Helm 部署到 Kubernetes，分别验证镜像、持久化 PostgreSQL、网络访问和健康端点，记录最终 `AIQ_SERVER_URL` 后交给研究工作流使用。
3. 服务启动失败时先检查端口、配置和容器日志，再运行健康检查；在未确认部署模式和安全清理范围前不删除卷、重置用户环境或覆盖既有 `.env`。
