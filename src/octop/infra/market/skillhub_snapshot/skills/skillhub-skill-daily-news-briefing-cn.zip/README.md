# 每日资讯简报生成

> **Daily News Briefing** · `daily-news-briefing-cn`

行业动态摘要、热点梳理与一句话解读。

*Daily digest of industry news, hot topics, and one-line analysis.*

---

## 📋 功能简介 / Features

每日资讯简报生成 Skill。自动生成当日资讯简报：① 行业动态摘要 ② 热点事件梳理 ③ 长文链接 ④ 一句话解读。支持自定义关注领域，输出 Markdown 简报可邮件/笔记存档。

## 🚀 快速开始 / Quick Start

1. 阅读 `SKILL.md` 了解完整使用方式
   *Read `SKILL.md` for full usage.*
2. 按需安装依赖（见 SKILL.md 环境要求）
   *Install dependencies as listed in SKILL.md.*
3. 用支持 SKILL.md 的 Agent（Claude Code / Codex / OpenClaw / WorkBuddy / Coze）加载使用
   *Load in any SKILL.md-capable agent (Claude Code / Codex / OpenClaw / WorkBuddy / Coze).*

## 📂 目录结构 / Structure

```
skill-daily-brief/
├── README.md
├── SKILL.md

```

## ✅ 兼容平台 / Platforms

Claude Code · Codex · OpenClaw · WorkBuddy · Coze

## ⚖️ 合规声明 / Compliance

- 纯本地运行，数据不上传（涉及数据采集时仅公开数据）
  *Runs fully local, no data upload (public data only when scraping).*
- 输出为辅助工具结果，不构成专业/投资/法律意见
  *Output is for assistance only, not professional/investment/legal advice.*
- 请遵守各平台服务条款
  *Respect platform ToS.*

## 📄 License

MIT
