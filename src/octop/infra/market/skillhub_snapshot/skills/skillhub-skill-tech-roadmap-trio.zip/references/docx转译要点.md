# SVG → Word 原生可编辑形状：转译要点（实测踩坑清单）

适用范围：`scripts/svg2docx.py`。以下每一条都是实测踩出来的，**改脚本前必读**。
任一条写错，Word 会直接报「打开文件时遇到错误」，且 `wml.xsd` 校验查不出来
（因为 `wps` 是微软 2010 扩展命名空间，ISO schema 包里没有声明，
`graphicData` 的 `xsd:any processContents="strict"` 只报一层就停）。

## 一、结构层（决定能不能打开）

1. **必须用 `wps:wsp`**
   `a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"` 内
   必须是 `<wps:wsp>`，文本走 `wps:txbx > w:txbxContent > w:p/w:r/w:t`。
   裸 `<a:sp>` + `a:txBody` 是 **PPT 语法**，XSD 能过但 Word 一律拒绝。
   子元素顺序：`cNvCnPr|cNvSpPr` → `spPr` → `style?` → `txbx?` → `bodyPr`。

2. **`wp:anchor` 子元素顺序**（ISO 29500-4 `dml-wordprocessingDrawing.xsd` 的 `CT_Anchor`）：
   ```
   simplePos, positionH, positionV, extent, effectExtent,
   wrapNone|wrapSquare|..., docPr, cNvGraphicFramePr, graphic
   ```
   ⚠️ **`wrapNone` 在 `docPr` 之前**（凭印象写成 docPr 在前，Word 判损坏）。
   不要把所有形状塞进同一个 anchor——每个形状一个独立浮动 anchor，
   `positionH/V relativeFrom="margin"`，`posOffset` = 画布坐标×K，形状内部 `a:off` 归零。

3. **`a:gd` 只有 `name` 和 `fmla` 两个属性，没有 `val`**
   圆角矩形必须写 `<a:gd name="adj" fmla="val 16667"/>`；
   写成 `val="16667"` → Word 报错且 XSD 查不出（本次排查中最隐蔽的一个）。
   圆角半径 = `adj/100000 × min(w,h)`，故 `adj = rx / min(w,h) × 100000`。

4. **`extent` 的 cx/cy 不能为 0**
   竖线 dx=0、横线 dy=0，取 `max(emu(d), 1)`（1 EMU 的偏差肉眼不可见）。

## 二、度量层（决定复原得像不像）

5. **字号换算：画布 px → pt 必须用实际比例 `K/12700`**
   `K = min(版心宽/viewBox宽, 版心高/viewBox高)`，即 `1px = K/12700 pt`。
   **不能用 96dpi 的 `px×0.75`**：794px 画布映射到 A4 版心后实际约 123dpi，
   按 0.75 换算会让文字放大约 28% → 框内换行 → 纵向溢出被裁（表现为「每个框都少最后一行」）。
   半点数向下取整，保证不大于 SVG 字号。

6. **中文必须指定 `w:rFonts w:eastAsia`**
   否则 Word 回退 **MS Mincho（日文明朝体）**，字形与度量都不对，垂向偏移。
   字体名取自 SVG 根元素 `font-family` 的第一个字体（默认 Microsoft YaHei）。

7. **行距用 `w:spacing lineRule="exact"`**
   抵消 Word 中文字体行高膨胀（约 1.4×）。行距值取 SVG 中 `tspan` 的 `dy`；
   单行时取 1.3×字号，且不小于 1.05×字号（否则 Word 裁剪）。

8. **文本框 `bodyPr` 的 `lIns/tIns/rIns/bIns` 必须为 0，`anchor="ctr"`，`wrap="none"`**
   前两者才能对齐 SVG 的 `text-anchor="middle"` + 居中基线算法
   （SVG 首行基线 = `h/2 - (n-1)*line/2 + fontSize*0.35`）。
   **`wrap` 必须用 `none`**：SVG 文本从不自动换行（超宽即溢出显示），
   `wrap="square"` 会让 Word 在框内折行（如「人—车—路—环境系统论」被拆成两行），
   进而纵向溢出——折行是比溢出更糟的偏差。

## 三、图形层（SVG 图元 → DrawingML）

| SVG | DrawingML | 要点 |
|---|---|---|
| `<rect rx="2">` | `prstGeom prst="roundRect"` + `a:gd fmla="val N"` | 见坑 3 |
| `<rect>` 无 rx | `prstGeom prst="rect"` | |
| `fill="none"` | `<a:noFill/>` | 位置在 `<a:ln>` 之前 |
| `stroke-width` | `<a:ln w="..."/>` | **按 K 缩放**（`emu(sw_px)`），不要写固定 pt 值 |
| `stroke-dasharray` | `<a:prstDash val="dash"/>` | 不支持自定义 dash 长度，只能近似 |
| `marker-end` | `<a:tailEnd type="triangle" w="sm" len="sm"/>` | 放在 `<a:ln>` 内，`prstDash` 之后 |
| `<line>` | `prstGeom prst="line"` | 方向用 `a:xfrm flipH/flipV`（line 默认左上→右下） |
| 闭合多边形 `<path ... Z>` | `a:custGeom` + `moveTo/lnTo/close` | 逐顶点还原；`path` 的 `w/h` = 形状 extent（EMU） |
| 多子路径 `<path>`（树状线） | 拆成多条独立直线 | 每个 `M..L..` 子路径按点对拆段 |
| `<text>` + `<tspan dy>` | 文本框多段落 | `dy` → exact 行距；`text-anchor="middle"` → `jc=center`，默认 start → `jc=left` |

`a:custGeom` 子元素顺序：`avLst, gdLst, ahLst, cxnLst, pathLst`（可省略中间项）。

## 四、验证方法（金标准，不靠猜）

1. **二分探针**：每类形状单独生成一份 docx，Word COM 批量打开，一次锁定违规类型。
   ```powershell
   $w = New-Object -ComObject Word.Application; $w.Visible=$false; $w.DisplayAlerts=0
   Get-ChildItem "_probe_*.docx" | ForEach-Object {
     try { $d = $w.Documents.Open($_.FullName, $false, $true); "$($_.Name) OK"; $d.Close($false) }
     catch { "$($_.Name) FAIL" } }
   $w.Quit()
   ```
2. **Word COM 实测**：`Documents.Open(path, $false, $true)`（只读）→ `ExportAsFixedFormat(pdf, 17)`。
   能打开 + `Shapes.Count` 正确 = 结构与 Word 兼容。
3. **渲染对照**：
   - Chrome 无头截图 SVG：`chrome.exe --headless --screenshot=ref.png --window-size=W,H --default-background-color=FFFFFFFF file:///...svg`
   - PDF → PNG：`pymupdf`；左右拼接：`PIL`
4. **文本比对**：`verify.py` 已改为**双向精确比对**（`Counter` 多重集差集）——
   SVG 每行必须在 DOCX 中出现，且 DOCX 不得多出 SVG 没有的文字。
   ⚠️ 不要退回「无分隔符拼接成一个大串再做子串匹配」：跨文本边界会产生大量伪匹配，
   实测把某形状文字换成 `ZZZZ` 都检不出来。
   注意：关键词命中必须限定在对应框的矩形内，否则跨框同名文本会误报。

## 五、OOXML 校验器的两个已知缺口

`ooxml_validator`（ISO 29500-4 schemas + `validate.py`，依赖 lxml/defusedxml）可用，但：
- **没有 `wps` 扩展 schema** → `wps:wsp` 必报 "No matching global element declaration"，是校验器缺口，不是文件缺陷；
- `--original` 与待测文件相同时 "NEW errors: 0" 是**假全绿**。要先用 lxml 直验，
  再做对照实验（故意打乱 anchor 子元素顺序，确认能报错）证明校验有效。

## 六、审计补充（v1.0.1，2026-09-28）

9. **颜色不能只认 `#hex`**
   `fill="black"` / `rgb(0,0,0)` / `#FFF` 若原样大写写入 `<a:srgbClr val="BLACK">`，
   Word 直接报「打开文件时遇到错误」。`hexclr()` 必须支持：命名色表、
   `rgb()/rgba()`（含百分比）、3/4/8 位 hex（正确展开或丢弃 alpha）；
   无法识别时返回 `None` 并回退默认色。

10. **path 不能只认大写 `M/L/Z`**
    本生成器只产 `M/L/Z`，但用户手工编辑过的 SVG 会出现相对指令与曲线。
    旧版对 `m/l/z` 直接产出 0 个点（**形状凭空消失且不报错**），
    对 `C/S/Q/A` 把控制点当顶点（几何畸变）。必须支持
    `Mm Ll Hh Vv Cc Ss Qq Tt Aa Zz`（含隐式重复指令），曲线按折线扁平化，
    椭圆弧按 SVG 规范 F.6.5 做端点→中心参数化。

11. **`--word` 的两条硬性前提**（`verify.py`）
    - **编码**：`os.popen(...).read()` 以 UTF-8 解码，而中文 Windows 上 PowerShell
      向管道写的是 **GBK**；只要输出含中文（Word 报错文案一定是中文），
      就会在最需要它报告问题时抛 `UnicodeDecodeError`。
      做法：写临时 `.ps1`（UTF-8 BOM）→ `subprocess` 取原始字节 → 多编码兜底解码。
    - **路径**：`subprocess` 启动的 PowerShell 会把相对路径解析到 `C:\Windows\System32`，
      必须一律 `os.path.abspath()`，否则 Word 报「找不到您的文件」。
    - **不要相信「坏文件能被检出」**：那可能只是脚本崩了。要断言「退出码=1 且无 Traceback」，
      两者同时成立才算真正检出。

12. **质检必须能拦住「人眼可见」的缺陷**（v1.0.1 新增四条不变式，见 `verify.py`）
    - 形状数下限：DOCX 形状数不得少于 SVG 可绘制图元数（转译是一对多）；
    - 几何越界：逐形状校验包围盒是否落在 viewBox 内（重建 K = 版心/画布）；
    - 文本双向精确比对（见第 4 条）；
    - 空产物拦截：SVG 0 图元直接判失败。
