#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
黑白技术路线图生成器 bw-roadmap
用法: python generate.py <spec.json> [输出目录]
输入: JSON 规格文件(字段见 examples/example1.json)
输出: <名称>.svg + <名称>-editor.html (零依赖可拖拽编辑器)
纯标准库实现。架构: layout(纯几何) -> render(纯字符串), 无二次修补。
"""
import json
import os
import sys

FS = {"title": 16, "parent": 12.5, "child": 10.5, "label": 11.5, "note": 10}
CANVAS_W = 794
LX, LW = 45, 100          # 左栏(阶段标签)
CX, CW = 170, 460         # 中栏(研究内容)
RX2 = 765                 # 右栏右缘(方法框右对齐)
ZONE_PAD = 12
TREE_GAP = 34
FLOW_GAP = 46
STYLE = """.node rect{fill:#ffffff;stroke:#000000;stroke-width:1.5;}
.node-title rect{stroke-width:2.5;}
.node-emphasis rect{stroke-width:3.5;}
.zone{fill:none;stroke:#000000;stroke-width:1;stroke-dasharray:2 3;}
.edge{stroke:#000000;fill:none;stroke-width:1.2;}
.edge-dashed{stroke-dasharray:6 4;}
text{fill:#000000;}
.t-title{font-size:16px;font-weight:700;}
.t-parent{font-size:12.5px;font-weight:700;}
.t-child{font-size:10.5px;}
.t-label{font-size:11.5px;font-weight:700;}
.t-note{font-size:10px;}"""

# ============ 工具 ============
# 全角/宽字符判定。旧版阈值 0x2E7F 漏掉了 U+2018–U+201D（“”‘’）、U+2014（——）、
# U+2026（……）等常用全角标点，导致宽度低估 18–23%，进而错判折行与溢出。
WIDE_RANGES = (
    (0x1100, 0x115F), (0x2000, 0x206F), (0x2E80, 0x303E), (0x3041, 0x33FF),
    (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xA000, 0xA4CF), (0xAC00, 0xD7A3),
    (0xF900, 0xFAFF), (0xFE10, 0xFE19), (0xFE30, 0xFE6F), (0xFF00, 0xFF60),
    (0xFFE0, 0xFFE6), (0x1F300, 0x1FAFF),
)

def is_wide(ch):
    o = ord(ch)
    for lo, hi in WIDE_RANGES:
        if lo <= o <= hi:
            return True
    return False

def measure(s, fs):
    w = 0.0
    for c in s:
        if is_wide(c):
            w += fs
        elif c == " ":
            w += 0.28 * fs
        else:
            w += 0.55 * fs
    return w

def wrap_text(s, fs, maxw, max_lines=2, warns=None, tag=""):
    lines, cur, cur_w = [], "", 0.0
    for c in s:
        w = fs if is_wide(c) else (0.28 * fs if c == " " else 0.55 * fs)
        if cur and cur_w + w > maxw:
            lines.append(cur)
            cur, cur_w = c, w
            if len(lines) == max_lines:
                break
        else:
            cur += c
            cur_w += w
    else:
        if cur:
            lines.append(cur)
    if cur and len(lines) == max_lines and "".join(lines) != s:
        if warns is not None:
            warns.append(f"文字超长被截断[{tag}]: {s}")
    return lines if lines else [""]

def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))

def fmt(v):
    s = "%.1f" % v
    return s.rstrip("0").rstrip(".")

def tspans(lines, x, dy=13):
    return "".join(
        f'<tspan x="{fmt(x)}"{f" dy=\"{dy}\"" if j else ""}>{esc(l)}</tspan>'
        for j, l in enumerate(lines))

# ============ 布局(纯几何) ============
def layout(spec, warns):
    stages = spec.get("stages") or []
    if not isinstance(stages, list):
        warns.append("stages 字段不是数组, 已按空处理")
        stages = []
    if len(stages) < 2:
        warns.append("阶段数少于 2, 建议至少 2 个研究阶段")
    emphasis = {str(e) for e in (spec.get("emphasis") or []) if e is not None}
    feedback = spec.get("feedback")

    title = str(spec.get("title") or "研究技术路线")
    need_tw = measure(title, FS["title"]) + 60
    if need_tw > 680:
        warns.append(f"标题过长(需 {need_tw:.0f}px > 上限 680px), 已钳制, 可能溢出: {title}")
    tw = min(max(need_tw, 300), 680)
    t_x = CX + CW / 2 - tw / 2

    zones = []
    y = 100
    for i, st in enumerate(stages, 1):
        if not isinstance(st, dict):
            st = {"name": st}
        items = []
        iy = y + ZONE_PAD
        contents = st.get("content") or [{}]
        if not isinstance(contents, list):
            contents = [contents]
        for k, c in enumerate(contents, 1):
            if not isinstance(c, dict):
                c = {"text": c}
            ptext = str(c.get("text") or "")
            pw = max(measure(ptext, FS["parent"]) + 28, 140)
            plines = [ptext]
            if pw > CW - 24:
                plines = wrap_text(ptext, FS["parent"], CW - 48, 2, warns, f"阶段{i}父框")
                pw = max(measure(l, FS["parent"]) for l in plines) + 28
            ph = 30 + 14 * (len(plines) - 1)
            children = c.get("children") or []
            if not isinstance(children, list):
                children = [children]
            children = [str(t) for t in children if t is not None]
            if not ptext and not children:
                warns.append(f"阶段{i}第{k}个内容块为空(既无文字也无子项)")
            n = len(children)
            cw_list, clines, child_h = [], [], 28
            if n:
                natural = [measure(t, FS["child"]) + 12 for t in children]
                gaps = (n - 1) * 10
                if sum(natural) + gaps <= CW - 24:
                    cw_list = natural
                    clines = [[t] for t in children]
                else:
                    target = max((CW - 24 - gaps) // n, 64)
                    for t in children:
                        clines.append(wrap_text(t, FS["child"], target - 10, 2, warns, f"阶段{i}子项"))
                        cw_list.append(target)
                    maxlines = max(len(l) for l in clines)
                    child_h = 28 if maxlines == 1 else 22 + 13 * maxlines
            ih = ph + (TREE_GAP + child_h if n else 0)
            kids = []
            for j, t in enumerate(children):
                kids.append({"cid": f"node-s{i}-c{k}-{j+1}", "lines": clines[j],
                             "w": cw_list[j]})
            items.append({"pid": f"node-s{i}-p{k}", "plines": plines, "pw": pw,
                          "ph": ph, "py": iy, "children": kids,
                          "child_h": child_h, "ih": ih, "key": f"{i}.{k}",
                          "tree_id": f"edge-tree-s{i}-{k}"})
            iy += ih + 26
        if items:
            iy -= 26
        zh = max(iy + ZONE_PAD - y, 64)
        yc = y + zh / 2
        sname = str(st.get("name") or f"阶段{i}")
        llines = wrap_text(sname, FS["label"], LW - 10, 2, warns, f"阶段{i}标签")
        lh = 36 if len(llines) == 1 else 48
        methods = [str(m) for m in (st.get("methods") or []) if m is not None][:3]
        mlines = methods
        mw = min(max((measure(t, FS["child"]) + 14 for t in mlines), default=0), 115)
        # 旧版把方法框宽度硬钳到 115px 且不告警，超长方法名直接溢出框外
        for t in mlines:
            need = measure(t, FS["child"]) + 14
            if need > 115:
                warns.append(f"阶段{i}研究方法过长(需 {need:.0f}px > 上限 115px), 会溢出方法框: {t}")
        mh = 36 if len(mlines) <= 1 else 22 + 15 * len(mlines)
        zones.append({"i": i, "name": sname, "y": y, "h": zh,
                      "yc": yc, "items": items, "llines": llines, "lh": lh,
                      "mlines": mlines, "mw": mw, "mh": mh})
        y += zh + FLOW_GAP
    y -= FLOW_GAP

    # feedback 合法性校验（旧版对越界/方向错误静默忽略，用户会误以为已画出反馈线）
    if feedback is not None:
        try:
            f_i, t_i = int(feedback["from"]), int(feedback["to"])
            if not (1 <= t_i < f_i <= len(stages)):
                warns.append(f"feedback 无效(from={feedback.get('from')}, to={feedback.get('to')}, "
                             f"阶段数={len(stages)}): 要求 1<=to<from<=阶段数, 已忽略")
                feedback = None
        except (KeyError, TypeError, ValueError):
            warns.append('feedback 字段格式错误(需 {"from":n,"to":n,"label":str}), 已忽略')
            feedback = None

    # emphasis 合法性校验（引用不存在的键会静默失效，用户以为已加粗强调）
    valid = set()
    for zi, z in enumerate(zones, 1):
        for k, it in enumerate(z["items"], 1):
            valid.add(f"{zi}.{k}")
            valid.update(f"{zi}.{k}.{j}" for j in range(1, len(it["children"]) + 1))
    for e in sorted(emphasis):
        if e not in valid:
            warns.append(f"emphasis 键不存在于图中, 已忽略: {e}")

    return {"title": title, "tw": tw, "t_x": t_x, "zones": zones,
            "feedback": feedback, "emphasis": emphasis, "H": y + 30}

# ============ 节点框渲染 ============
def node_g(nid, cls, x, y, w, h, lines, tcls, emph=False, extra=""):
    kls = "node " + cls + (" node-emphasis" if emph else "")
    off = {"t-title": 5.5, "t-parent": 4.2, "t-child": 3.6, "t-label": 4.2}.get(tcls, 4)
    if len(lines) == 1:
        ty = h / 2 + off
    else:
        ty = h / 2 - (len(lines) - 1) * 6.5 + off
    return (f'<g id="{nid}" class="{kls}" transform="translate({fmt(x)},{fmt(y)})" '
            f'data-w="{fmt(w)}" data-h="{fmt(h)}"{extra}>'
            f'<rect width="{fmt(w)}" height="{fmt(h)}" rx="2"/>'
            f'<text x="{fmt(w / 2)}" y="{fmt(ty)}" text-anchor="middle" class="{tcls}">'
            f'{tspans(lines, w / 2)}</text></g>')

# ============ 各层渲染 ============
def layer_zones(L):
    out = ['<g id="layer-zones">']
    for z in L["zones"]:
        out.append(f'<rect id="zone-s{z["i"]}" class="zone" x="{CX}" y="{fmt(z["y"])}" '
                   f'width="{CW}" height="{fmt(z["h"])}" data-stage="{z["i"]}"/>')
    out.append("</g>")
    return out

def layer_edges(L):
    out = ['<g id="layer-edges">']
    z = L["zones"]
    cx_mid = CX + CW / 2
    # 左侧竖脊线
    if len(z) >= 2:
        out.append(f'<line id="spine-left" class="edge" data-link="spine" '
                   f'x1="{LX + LW / 2}" y1="{fmt(z[0]["yc"])}" '
                   f'x2="{LX + LW / 2}" y2="{fmt(z[-1]["yc"])}"/>')
    # 主流程空心箭头(相邻分区之间)
    for a, b in zip(z, z[1:]):
        y0, y1 = a["y"] + a["h"], b["y"]
        tip = y1 - 2
        d = (f"M{fmt(cx_mid-10)},{fmt(y0+4)} L{fmt(cx_mid+10)},{fmt(y0+4)} "
             f"L{fmt(cx_mid+10)},{fmt(tip-8)} L{fmt(cx_mid+21)},{fmt(tip-8)} "
             f"L{fmt(cx_mid)},{fmt(tip)} L{fmt(cx_mid-21)},{fmt(tip-8)} "
             f"L{fmt(cx_mid-10)},{fmt(tip-8)} Z")
        out.append(f'<path id="edge-flow-{a["i"]}" class="edge" data-link="flow" '
                   f'data-from="zone-s{a["i"]}" data-to="zone-s{b["i"]}" '
                   f'fill="#ffffff" stroke="#000000" stroke-width="2" d="{d}"/>')
    # 反馈虚线(下→上, 走分区框右侧)
    fb = L.get("feedback")
    if fb:
        f_i, t_i = int(fb["from"]), int(fb["to"])
        if f_i > t_i and f_i <= len(z) and t_i >= 1:
            zf, zt = z[f_i - 1], z[t_i - 1]
            fx = CX + CW - 28
            out.append(f'<path id="edge-feedback" class="edge edge-dashed" data-link="feedback" '
                       f'data-from="zone-s{f_i}" data-to="zone-s{t_i}" '
                       f'marker-end="url(#arrow)" d="M{fmt(fx)},{fmt(zf["y"])} L{fmt(fx)},{fmt(zt["y"]+zt["h"])}"/>')
            out.append(f'<text id="label-feedback" class="t-note" x="{fmt(fx+8)}" '
                       f'y="{fmt((zf["y"] + zt["y"] + zt["h"]) / 2 + 30)}">{esc(fb.get("label", "反馈"))}</text>')
    # 树状连线 / 方法连线 / 标签连线
    for z in z:
        for it in z["items"]:
            if not it["children"]:
                continue
            p_cx = cx_mid
            p_bot = it["py"] + it["ph"]
            k_top = it["py"] + it["ph"] + TREE_GAP
            bus_y = (p_bot + k_top) / 2
            xs = [p_cx]
            d = f"M{fmt(p_cx)},{fmt(p_bot)} L{fmt(p_cx)},{fmt(bus_y)}"
            total = sum(c["w"] for c in it["children"]) + (len(it["children"]) - 1) * 10
            sx = cx_mid - total / 2
            for c in it["children"]:
                c_cx = sx + c["w"] / 2
                xs.append(c_cx)
                d += f" M{fmt(c_cx)},{fmt(bus_y)} L{fmt(c_cx)},{fmt(k_top)}"
                sx += c["w"] + 10
            d += f" M{fmt(min(xs))},{fmt(bus_y)} L{fmt(max(xs))},{fmt(bus_y)}"
            kids = ",".join(c["cid"] for c in it["children"])
            out.append(f'<path id="{it["tree_id"]}" class="edge" data-link="tree" '
                       f'data-parent="{it["pid"]}" data-children="{kids}" d="{d}"/>')
        if z["mlines"]:
            out.append(f'<line id="edge-m{z["i"]}" class="edge" data-link="method" '
                       f'data-from="node-m{z["i"]}" data-to="zone-s{z["i"]}" '
                       f'marker-end="url(#arrow)" x1="{fmt(RX2 - z["mw"])}" y1="{fmt(z["yc"])}" '
                       f'x2="{fmt(CX + CW + 6)}" y2="{fmt(z["yc"])}"/>')
        out.append(f'<line id="edge-l{z["i"]}" class="edge" data-link="label" '
                   f'data-from="node-stage{z["i"]}" data-to="zone-s{z["i"]}" '
                   f'x1="{LX + LW}" y1="{fmt(z["yc"])}" x2="{CX}" y2="{fmt(z["yc"])}"/>')
    out.append("</g>")
    return out

def layer_nodes(L):
    out = ['<g id="layer-nodes">']
    cx_mid = CX + CW / 2
    out.append(node_g("node-title", "node-title", L["t_x"], 36, L["tw"], 44,
                      [L["title"]], "t-title"))
    for z in L["zones"]:
        for it in z["items"]:
            px = cx_mid - it["pw"] / 2
            out.append(node_g(it["pid"], "", px, it["py"], it["pw"], it["ph"],
                              it["plines"], "t-parent", emph=it["key"] in L["emphasis"]))
            total = sum(c["w"] for c in it["children"]) + (len(it["children"]) - 1) * 10
            sx = cx_mid - total / 2
            cy = it["py"] + it["ph"] + TREE_GAP
            for j, c in enumerate(it["children"], 1):
                out.append(node_g(c["cid"], "", sx, cy, c["w"], it["child_h"],
                                  c["lines"], "t-child",
                                  emph=f'{it["key"]}.{j}' in L["emphasis"]))
                sx += c["w"] + 10
    out.append("</g>")
    return out

def layer_labels(L):
    out = ['<g id="layer-labels">']
    for z in L["zones"]:
        out.append(node_g(f"node-stage{z['i']}", "node-label", LX, z["yc"] - z["lh"] / 2,
                          LW, z["lh"], z["llines"], "t-label"))
        if z["mlines"]:
            off = 3.6 - (len(z["mlines"]) - 1) * 7.5
            ty = z["mh"] / 2 + off
            t = (f'<text x="{fmt(z["mw"] / 2)}" y="{fmt(ty)}" text-anchor="middle" class="t-child">'
                 f'{tspans(z["mlines"], z["mw"] / 2, 15)}</text>')
            out.append(f'<g id="node-m{z["i"]}" class="node node-label" '
                       f'transform="translate({fmt(RX2 - z["mw"])},{fmt(z["yc"] - z["mh"] / 2)})" '
                       f'data-w="{fmt(z["mw"])}" data-h="{fmt(z["mh"])}">'
                       f'<rect width="{fmt(z["mw"])}" height="{fmt(z["mh"])}" rx="2"/>{t}</g>')
    out.append("</g>")
    return out

def build_svg(L):
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {CANVAS_W} {fmt(L["H"])}" '
        f'font-family="Microsoft YaHei, sans-serif">',
        "  <style>\n" + "\n".join("    " + l for l in STYLE.splitlines()) + "\n  </style>",
        '  <defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
        'markerHeight="7" orient="auto-start-reverse">'
        '<path d="M0,0 L10,5 L0,10 Z" fill="#000000"/></marker></defs>',
    ]
    for layer in (layer_zones, layer_edges, layer_nodes, layer_labels):
        parts.extend("  " + s for s in layer(L))
    parts.append("</svg>")
    return "\n".join(parts)

# ============ 编辑器 JS(拖动/改字/导出) ============
EDITOR_JS = r"""
const svg=document.getElementById('diagram');const NS='http://www.w3.org/2000/svg';
function gbox(id){const el=document.getElementById(id);if(!el)return null;
 const w=+el.dataset.w||+el.getAttribute('width')||0,h=+el.dataset.h||+el.getAttribute('height')||0;
 let x=0,y=0;
 if(el.tagName==='rect'){x=+el.getAttribute('x');y=+el.getAttribute('y');}
 else{const m=/translate\(([-\d.]+)[ ,]([-\d.]+)\)/.exec(el.getAttribute('transform')||'');
  if(m){x=+m[1];y=+m[2];}}
 return{el,x,y,w,h,cx:x+w/2,cy:y+h/2};}
function redraw(){
 svg.querySelectorAll('[data-link="tree"]').forEach(p=>{
  const par=gbox(p.dataset.parent);const kids=p.dataset.children.split(',').map(gbox).filter(Boolean);
  if(!par||!kids.length)return;
  const busY=(par.y+par.h+kids[0].y)/2;const xs=kids.map(k=>k.cx);
  let d=`M${par.cx},${par.y+par.h} L${par.cx},${busY}`;
  d+=` M${Math.min(...xs,par.cx)},${busY} L${Math.max(...xs,par.cx)},${busY}`;
  kids.forEach(k=>d+=` M${k.cx},${busY} L${k.cx},${k.y}`);
  p.setAttribute('d',d);});
 svg.querySelectorAll('[data-link="flow"]').forEach(p=>{
  const A=gbox(p.dataset.from),B=gbox(p.dataset.to);if(!A||!B)return;
  const y0=A.y+A.h,y1=B.y,cx=(A.cx+B.cx)/2,tip=y1-2;
  p.setAttribute('d',`M${cx-10},${y0+4} L${cx+10},${y0+4} L${cx+10},${tip-8} L${cx+21},${tip-8} L${cx},${tip} L${cx-21},${tip-8} L${cx-10},${tip-8} Z`);});
 const fb=svg.querySelector('[data-link="feedback"]');
 if(fb){const A=gbox(fb.dataset.from),B=gbox(fb.dataset.to);
  if(A&&B){const fx=A.x+A.w-28;fb.setAttribute('d',`M${fx},${A.y} L${fx},${B.y+B.h}`);
   const lf=document.getElementById('label-feedback');
   if(lf){lf.setAttribute('x',fx+8);lf.setAttribute('y',(A.y+B.y+B.h)/2+30);}}}
 svg.querySelectorAll('[data-link="method"]').forEach(e=>{
  const M=gbox(e.dataset.from),Z=gbox(e.dataset.to);if(!M||!Z)return;
  e.setAttribute('x1',M.x);e.setAttribute('y1',M.y+M.h/2);
  e.setAttribute('x2',Z.x+Z.w+6);e.setAttribute('y2',M.y+M.h/2);});
 svg.querySelectorAll('[data-link="label"]').forEach(e=>{
  const M=gbox(e.dataset.from),Z=gbox(e.dataset.to);if(!M||!Z)return;
  e.setAttribute('x1',M.x+M.w);e.setAttribute('y1',M.y+M.h/2);
  e.setAttribute('x2',Z.x);e.setAttribute('y2',M.y+M.h/2);});
 const sp=svg.querySelector('[data-link="spine"]');
 if(sp){const ids=[...svg.querySelectorAll('g[id^="node-stage"]')].map(g=>gbox(g.id)).filter(Boolean);
  if(ids.length){sp.setAttribute('x1',ids[0].x+ids[0].w/2);sp.setAttribute('y1',ids[0].y+ids[0].h/2);
   sp.setAttribute('x2',ids[ids.length-1].x+ids[ids.length-1].w/2);
   sp.setAttribute('y2',ids[ids.length-1].y+ids[ids.length-1].h/2);}}}
let drag=null;
svg.addEventListener('pointerdown',e=>{const g=e.target.closest('g.node');
 if(!g||g.id==='node-title')return;
 const m=/translate\(([-\d.]+)[ ,]([-\d.]+)\)/.exec(g.getAttribute('transform')||'');
 drag={g,sx:e.clientX,sy:e.clientY,ox:+m[1],oy:+m[2]};svg.setPointerCapture(e.pointerId);});
svg.addEventListener('pointermove',e=>{if(!drag)return;
 const r=svg.getBoundingClientRect(),k=+svg.getAttribute('viewBox').split(' ')[2]/r.width;
 const nx=drag.ox+(e.clientX-drag.sx)*k,ny=drag.oy+(e.clientY-drag.sy)*k;
 drag.g.setAttribute('transform',`translate(${nx.toFixed(1)},${ny.toFixed(1)})`);redraw();});
svg.addEventListener('pointerup',()=>drag=null);
svg.addEventListener('dblclick',e=>{const g=e.target.closest('g.node');if(!g)return;
 const t=g.querySelector('text');if(!t)return;
 const old=[...t.querySelectorAll('tspan')].map(s=>s.textContent).join('\n')||t.textContent;
 const txt=prompt('修改节点文字（换行自动分行）：',old);if(txt===null)return;
 const lines=txt.split('\n').filter(s=>s.trim());const x0=t.getAttribute('x');
 t.textContent='';
 lines.forEach((ln,i)=>{const ts=document.createElementNS(NS,'tspan');
  ts.setAttribute('x',x0);if(i>0)ts.setAttribute('dy','14');ts.textContent=ln;t.appendChild(ts);});
 redraw();});
function exportSVG(){const s=new XMLSerializer().serializeToString(svg);
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([s],{type:'image/svg+xml'}));
 a.download='roadmap_edited.svg';a.click();}
redraw();
"""

def build_editor(svg_str, name):
    tpl = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>__NAME__ · 黑白路线图编辑器</title>
<style>
 body{font-family:"Microsoft YaHei",sans-serif;margin:0;background:#f2f2f2;color:#222;}
 #bar{background:#fff;border-bottom:1px solid #ccc;padding:8px 14px;display:flex;gap:10px;align-items:center;}
 #bar b{font-size:14px;}
 button{padding:5px 12px;border:1px solid #888;background:#fff;cursor:pointer;font-size:13px;}
 button:hover{background:#000;color:#fff;}
 #wrap{padding:16px;display:flex;justify-content:center;}
 svg{background:#fff;box-shadow:0 1px 6px rgba(0,0,0,.25);max-width:820px;width:100%;height:auto;}
 g.node{cursor:move;} g.node text{user-select:none;pointer-events:none;}
 #tip{font-size:12px;color:#666;margin-left:auto;}
</style>
</head>
<body>
<div id="bar"><b>__NAME__</b><button onclick="exportSVG()">导出 SVG</button>
<span id="tip">拖动＝移动节点｜双击＝修改文字｜连线自动跟随</span></div>
<div id="wrap">
__SVG__
</div>
<script>__JS__</script>
</body>
</html>"""
    return tpl.replace("__NAME__", esc(name)).replace("__SVG__", svg_str).replace("__JS__", EDITOR_JS)

# ============ 自检 ============
def self_check(L):
    msgs = []
    for z in L["zones"]:
        if z["h"] > 420:
            msgs.append(f"阶段{z['i']}分区过高({z['h']:.0f}px), 建议拆分内容")
    if not any(z["mlines"] for z in L["zones"]):
        msgs.append("全图未标注研究方法(方法-内容匹配是评审重点, 建议补充)")
    miss = [z["i"] for z in L["zones"] if not z["mlines"]]
    if miss and len(miss) < len(L["zones"]):
        msgs.append(f"阶段 {miss} 未标注研究方法, 请核对方法与内容是否匹配")
    if len(L["zones"]) > 6:
        msgs.append("阶段数超过 6, 层级偏多(建议 3–5 层)")
    # 旧版缺此检查：画布过高时输出 A4 会整体缩小，正文字号低于可读下限
    if L["H"] > 1200:
        msgs.append(f"画布偏高({L['H']:.0f}px, 建议<=1200): 输出到 A4 时字号会明显偏小, "
                    f"建议精简内容或合并阶段")
    return msgs

# ============ 主入口 ============
def main():
    if len(sys.argv) < 2:
        print("用法: python generate.py <spec.json> [输出目录]")
        sys.exit(1)
    spec_path = sys.argv[1]
    outdir = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.abspath(spec_path))
    try:
        with open(spec_path, "r", encoding="utf-8") as f:
            spec = json.load(f)
    except FileNotFoundError:
        print("[错误] 找不到 spec 文件:", spec_path); sys.exit(2)
    except json.JSONDecodeError as e:
        print(f"[错误] spec JSON 解析失败: {e}"); sys.exit(2)
    stages = spec.get("stages") or []
    if not isinstance(stages, list) or len(stages) < 2:
        n = len(stages) if isinstance(stages, list) else "非法"
        print(f"[错误] stages 至少需要 2 个有效阶段（当前 {n}），无法生成路线图；"
              f"若确需单阶段，请改用通用绘图工具")
        sys.exit(1)
    warns = []
    L = layout(spec, warns)
    svg = build_svg(L)
    os.makedirs(outdir, exist_ok=True)
    name = os.path.splitext(os.path.basename(spec_path))[0]
    svg_path = os.path.join(outdir, name + ".svg")
    html_path = os.path.join(outdir, name + "-editor.html")
    with open(svg_path, "w", encoding="utf-8") as f:
        f.write(svg)
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(build_editor(svg, spec.get("title", name)))
    print(f"[OK] SVG  -> {svg_path}")
    print(f"[OK] HTML -> {html_path}")
    print(f"画布: {CANVAS_W} x {fmt(L['H'])} | 阶段: {len(L['zones'])} | "
          f"内容块: {sum(len(z['items']) for z in L['zones'])}")
    for w in warns:
        print("[警告]", w)
    for m in self_check(L):
        print("[自检提示]", m)

if __name__ == "__main__":
    main()
