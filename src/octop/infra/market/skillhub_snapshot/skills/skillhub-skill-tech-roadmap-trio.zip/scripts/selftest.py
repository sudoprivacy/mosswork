#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selftest.py —— 技能自检（单元用例 + 端到端冒烟）。

用法:
    python selftest.py            # 单元 + 端到端（结构质检）
    python selftest.py --word     # 追加 Word COM 实测（需本机安装 Word）

依赖: 与 svg2docx.py 相同（python-docx）。退出码 0=通过，1=失败。
"""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import generate as G          # noqa: E402
import svg2docx as S          # noqa: E402

PY = sys.executable
FAILS = []


def check(name, got, want):
    ok = got == want
    print(("  \u2713 " if ok else "  \u2717 ") + name
          + ("" if ok else "  got=%r want=%r" % (got, want)))
    if not ok:
        FAILS.append(name)


def test_hexclr():
    print("[hexclr]")
    for v, w in [("#000000", "000000"), ("#ffffff", "FFFFFF"), ("none", None), ("", None),
                 ("black", "000000"), ("white", "FFFFFF"), ("red", "FF0000"),
                 ("rgb(0,0,0)", "000000"), ("rgb(255,128,0)", "FF8000"),
                 ("rgba(0,0,255,0.5)", "0000FF"), ("#FFF", "FFFFFF"),
                 ("transparent", None)]:
        check("hexclr(%r)" % v, S.hexclr(v), w)


def test_is_wide():
    print("[is_wide]")
    for ch, w in [("\u4e2d", True), ("A", False), ("1", False), (" ", False),
                  ("\u201c", True), ("\u201d", True), ("\u2014", True),
                  ("\u2026", True), ("\uff0c", True)]:
        check("is_wide(%r)" % ch, G.is_wide(ch), w)


def test_parse_path():
    print("[parse_path]")
    subs, cl = S.parse_path("M0,0 L10,0 L10,10 Z")
    check("M/L/Z 点数", len(subs[0]), 4)
    check("M/L/Z 闭合", cl, [True])
    subs, cl = S.parse_path("m0,0 l10,0 l0,10 z")
    check("相对指令 点数", len(subs[0]), 4)
    check("相对末点", (round(subs[0][2][0]), round(subs[0][2][1])), (10, 10))
    subs, cl = S.parse_path("M0,0 H10 V10")
    check("H/V 末点", (round(subs[0][-1][0]), round(subs[0][-1][1])), (10, 10))
    subs, cl = S.parse_path("M0,0 C0,10 10,10 10,0")
    check("三次贝塞尔分段数", len(subs[0]), 13)
    subs, cl = S.parse_path("M0,0 A5,5 0 0 1 10,0")
    check("椭圆弧点数>=3", len(subs[0]) >= 3, True)
    subs, cl = S.parse_path("M0,0 L0,10 M10,0 L10,10")
    check("多子路径数(树状线)", len(subs), 2)


SPEC = {
    "title": "自检用技术路线图",
    "stages": [
        {"name": "问题提出", "methods": ["文献研究法"],
         "content": [{"text": "现状分析", "children": ["文献梳理", "问题界定", "需求调研"]}]},
        {"name": "方案设计", "methods": ["设计研究法"],
         "content": [{"text": "框架构建", "children": ["模块划分", "流程设计"]}]},
        {"name": "应用验证", "methods": ["行动研究法", "准实验研究法"],
         "content": [{"text": "课堂应用", "children": ["实证研究", "效果评估"]}]},
    ],
    "feedback": {"from": 3, "to": 2, "label": "迭代优化"},
    "emphasis": ["2.1", "3.1.1"],
}


def test_e2e(want_word):
    print("[端到端]")
    with tempfile.TemporaryDirectory() as d:
        spec = os.path.join(d, "selftest.json")
        with open(spec, "w", encoding="utf-8") as f:
            json.dump(SPEC, f, ensure_ascii=False)
        r = subprocess.run([PY, os.path.join(HERE, "generate.py"), spec, d], capture_output=True)
        check("generate 退出码", r.returncode, 0)
        svg, docx = os.path.join(d, "selftest.svg"), os.path.join(d, "selftest.docx")
        check("SVG 已生成", os.path.exists(svg), True)
        r = subprocess.run([PY, os.path.join(HERE, "svg2docx.py"), svg], capture_output=True)
        check("svg2docx 退出码", r.returncode, 0)
        check("DOCX 已生成", os.path.exists(docx), True)
        args = [PY, os.path.join(HERE, "verify.py"), svg, docx]
        if want_word:
            args.append("--word")
        r = subprocess.run(args, capture_output=True)
        out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace"))
        check("verify 未崩溃", "Traceback" not in out, True)
        if want_word:
            print("     (--word) 退出码 %d（无 Word 环境下允许非 0）" % r.returncode)
        else:
            check("verify 退出码", r.returncode, 0)
            for line in out.strip().splitlines():
                if line.strip().startswith("\u2717"):
                    print("     " + line.strip())


def main():
    want_word = "--word" in sys.argv
    test_hexclr()
    test_is_wide()
    test_parse_path()
    test_e2e(want_word)
    print()
    if FAILS:
        print("失败 %d 项: %s" % (len(FAILS), ", ".join(FAILS)))
        return 1
    print("全部通过 \u2713")
    return 0


if __name__ == "__main__":
    sys.exit(main())
