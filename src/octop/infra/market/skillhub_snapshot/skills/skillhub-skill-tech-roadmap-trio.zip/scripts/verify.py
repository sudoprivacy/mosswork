#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify.py —— 三通道产物质检（SVG / DOCX 结构一致性 + 可选 Word 实测）。

基础模式（零可选依赖，必做）:
    python verify.py <input.svg> <input.docx>
  · SVG 元素构成统计（分区/直线/路径/节点框/标签框/文字行 + viewBox）
  · DOCX 形状数(wps:wsp)、零位图、wp:anchor 子元素顺序、a:gd 是否误用 val
  · 形状数下限：DOCX 形状数不得少于 SVG 可绘制图元数（转译是一对多，只会更多）
  · 几何越界：每个形状的「位置+尺寸」必须落在画布内（容差 2px）
  · 双向文本精确比对：SVG 每行都在 DOCX 中，且 DOCX 不得多出 SVG 没有的文字
  · 空产物拦截：SVG 有图元却 0 形状 → 直接判失败

增强模式（可选）:
    python verify.py <svg> <docx> --word      # 本机 Word COM 打开并导出 PDF 复验
    python verify.py <svg> <docx> --render    # Chrome 渲染 SVG（按 viewBox 定尺寸）+ 拼左右对照图

退出码：0=全部通过，1=存在问题，2=参数/文件错误。

──── 审计修复记录（v1.0.1）──────────────────────────────────────────────
A. `--word` 崩溃：旧版用 os.popen().read()，以 UTF-8 解码 PowerShell 输出；
   但中文 Windows 上 PowerShell 向管道写的是 GBK。Word 一旦报错（错误文案是中文），
   就在「最需要它报告问题」的时刻抛 UnicodeDecodeError。
   修复：写临时 .ps1（UTF-8 BOM，规避命令行引号地狱）→ subprocess 取原始字节 →
   多编码兜底解码（utf-8 → 本地编码 → gbk）。
B. 漏检（旧版对以下情形均判「全部通过」）：
   · 空壳 DOCX（0 形状）          → 新增「形状数下限」与「空产物拦截」
   · Word 打不开的非法文档          → --word 现为硬失败；基础模式亦新增结构强校验
   · 几何篡改（形状移出画布）        → 新增几何越界校验
   · 文本篡改（换字/删字）          → 文本比对由「子串包含于无分隔拼接串」改为双向精确比对
   · DOCX 多出 SVG 没有的文字       → 同上（旧版无反向检查）
C. `--render` 截图窗口固定 794×988 与 viewBox 高度不符 → 对照图纵向比例失真；
   改为按 viewBox 实际尺寸截图。
"""
import argparse
import locale
import os
import re
import subprocess
import sys
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter

SVGNS = "{http://www.w3.org/2000/svg}"
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
WP = "{http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing}"
TOL_PX = 2.0          # 几何容差（画布 px）
EMU_PER_TWIP = 635    # 1 twip = 635 EMU


def norm(s):
    return re.sub(r"\s+", "", s or "")


def svg_facts(svg_path):
    root = ET.parse(svg_path).getroot()
    g = {x.get("id"): x for x in root.findall(SVGNS + "g")}
    edges = g.get("layer-edges")

    # 文字行：与 svg2docx 的取法一致——有 tspan 用 tspan，否则用 text 自身
    lines = []
    for t in root.iter(SVGNS + "text"):
        ts = t.findall(SVGNS + "tspan")
        raw = [(x.text or "") for x in ts] or [(t.text or "")]
        lines.extend(v for v in (norm(x) for x in raw) if v)

    vb = [float(v) for v in (root.get("viewBox") or "0 0 794 988").split()]
    return {
        "zones": len(g.get("layer-zones").findall(SVGNS + "rect")) if g.get("layer-zones") is not None else 0,
        "lines": len(edges.findall(SVGNS + "line")) if edges is not None else 0,
        "paths": len(edges.findall(SVGNS + "path")) if edges is not None else 0,
        "edge_texts": len(edges.findall(SVGNS + "text")) if edges is not None else 0,
        "nodes": len(g.get("layer-nodes").findall(SVGNS + "g")) if g.get("layer-nodes") is not None else 0,
        "labels": len(g.get("layer-labels").findall(SVGNS + "g")) if g.get("layer-labels") is not None else 0,
        "texts": lines,
        "VW": vb[2] if len(vb) >= 4 else 794.0,
        "VH": vb[3] if len(vb) >= 4 else 988.0,
    }


def _box(el):
    if el is None:
        return None
    try:
        return float(el.get(W + "w")), float(el.get(W + "h"))
    except (TypeError, ValueError):
        return None


def docx_facts(docx_path):
    z = zipfile.ZipFile(docx_path)
    x = z.read("word/document.xml").decode("utf-8")
    root = ET.fromstring(x)

    texts = [norm(t.text) for t in root.iter(W + "t") if norm(t.text)]
    bad_order = 0
    geom = []
    for anc in root.iter(WP + "anchor"):
        kids = [c.tag.split("}")[-1] for c in anc]
        if "docPr" not in kids or "wrapNone" not in kids or kids.index("docPr") < kids.index("wrapNone"):
            bad_order += 1          # schema 要求 wrapNone 在 docPr 之前
        ph, pv, ext = (anc.find(WP + "positionH"), anc.find(WP + "positionV"),
                       anc.find(WP + "extent"))
        try:
            x_emu = float(ph.find(WP + "posOffset").text)
            y_emu = float(pv.find(WP + "posOffset").text)
            cx = float(ext.get("cx"))
            cy = float(ext.get("cy"))
            geom.append((x_emu, y_emu, cx, cy))
        except (AttributeError, TypeError, ValueError):
            pass

    # 页面内容区（EMU），用于重建缩放系数 K 做几何校验
    content = None
    pgsz = root.find(".//" + W + "pgSz")
    pgmar = root.find(".//" + W + "pgMar")
    if pgsz is not None and pgmar is not None:
        try:
            w_tw, h_tw = float(pgsz.get(W + "w")), float(pgsz.get(W + "h"))
            ml, mr = float(pgmar.get(W + "left")), float(pgmar.get(W + "right"))
            mt, mb = float(pgmar.get(W + "top")), float(pgmar.get(W + "bottom"))
            content = ((w_tw - ml - mr) * EMU_PER_TWIP, (h_tw - mt - mb) * EMU_PER_TWIP)
        except (TypeError, ValueError):
            content = None

    return {
        "shapes": x.count("<wps:wsp>"),
        "bitmap": ("pic:pic" in x) or any(n.startswith("word/media/") for n in z.namelist()),
        "texts": texts,
        "anchor_bad_order": bad_order,
        "gd_bad_attr": bool(re.search(r"<a:gd[^>]*\sval=", x)),   # 坑：a:gd 不该有 val
        "geom": geom,
        "content": content,
    }


def _decode(raw):
    """PowerShell 管道输出解码兜底：中文 Windows 上是 GBK，不是 UTF-8。"""
    if not raw:
        return ""
    encs = ["utf-8", locale.getpreferredencoding(False), "gbk", "cp936", "latin-1"]
    seen = set()
    for enc in encs:
        if not enc or enc in seen:
            continue
        seen.add(enc)
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace")


def run_word(docx, pdf):
    """用本机 Word 打开并导出 PDF。返回 (成功?, 输出文本)。写临时 .ps1 规避引号/编码问题。"""
    ps = (
        "$ErrorActionPreference='Stop'\n"
        "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8\n"
        "$OutputEncoding=[System.Text.Encoding]::UTF8\n"
        "$w=New-Object -ComObject Word.Application\n"
        "$w.Visible=$false\n$w.DisplayAlerts=0\n"
        "try{\n"
        "  $d=$w.Documents.Open('__DOCX__',$false,$true)\n"
        "  $d.ExportAsFixedFormat('__PDF__',17)\n"
        "  Start-Sleep -Milliseconds 800\n"
        "  Write-Output ('OK shapes=' + $d.Shapes.Count)\n"
        "  $d.Close($false)\n"
        "}catch{ Write-Output ('FAIL: ' + $_.Exception.Message) }\n"
        "finally{ try{ $w.Quit() }catch{} }\n"
    )
    ps = ps.replace("__DOCX__", docx.replace("'", "''")).replace("__PDF__", pdf.replace("'", "''"))
    tmp = os.path.join(tempfile.gettempdir(), "trio_verify_word.ps1")
    with open(tmp, "w", encoding="utf-8-sig") as f:
        f.write(ps)
    try:
        p = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", tmp],
                           capture_output=True)
        out = _decode(p.stdout) + _decode(p.stderr)
    except OSError as e:
        return False, "无法启动 PowerShell: %s" % e
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    return ("OK" in out), out.strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("svg")
    ap.add_argument("docx")
    ap.add_argument("--word", action="store_true")
    ap.add_argument("--render", action="store_true")
    a = ap.parse_args()

    for p in (a.svg, a.docx):
        if not os.path.isfile(p):
            print("[错误] 找不到文件:", p)
            sys.exit(2)
    # 坑：subprocess 启动的 PowerShell 会把相对路径解析到 C:\Windows\System32，
    # 必须一律转绝对路径，否则 Word 报「找不到您的文件」。
    a.svg = os.path.abspath(a.svg)
    a.docx = os.path.abspath(a.docx)

    ok = True
    s = svg_facts(a.svg)
    d = docx_facts(a.docx)

    print("=== SVG ===")
    print(f"  分区框 {s['zones']} | 直线 {s['lines']} | 路径 {s['paths']} | "
          f"独立文本 {s['edge_texts']} | 节点框 {s['nodes']} | 标签框 {s['labels']}")
    print(f"  文字行 {len(s['texts'])} | viewBox {s['VW']:.0f}×{s['VH']:.0f}")

    print("=== DOCX ===")
    print(f"  原生形状(wps:wsp) {d['shapes']} | 位图 {d['bitmap']} | "
          f"anchor顺序错误 {d['anchor_bad_order']} | a:gd误用val {d['gd_bad_attr']}")

    if d["bitmap"]:
        print("  ✗ 含位图，非纯矢量"); ok = False
    if d["anchor_bad_order"]:
        print(f"  ✗ {d['anchor_bad_order']} 个 anchor 子元素顺序违规（应 wrapNone 在 docPr 前）"); ok = False
    if d["gd_bad_attr"]:
        print("  ✗ a:gd 使用了 val 属性（应为 fmla=\"val N\"），Word 会报错"); ok = False

    # ---- 形状数下限：转译是一对多，DOCX 形状数只会 >= SVG 可绘制图元数 ----
    drawable = s["zones"] + s["lines"] + s["paths"] + s["edge_texts"] + s["nodes"] + s["labels"]
    print(f"=== 形状数 ===\n  SVG 可绘制图元 {drawable} -> DOCX 形状 {d['shapes']}")
    if drawable == 0:
        print("  ✗ SVG 不含任何可绘制图元（空产物，无法交付）"); ok = False
    elif d["shapes"] == 0:
        print("  ✗ SVG 有图元但 DOCX 0 形状（转译失败/空产物）"); ok = False
    elif d["shapes"] < drawable:
        print(f"  ✗ DOCX 形状数({d['shapes']}) 少于 SVG 图元数({drawable})，疑似图元丢失"); ok = False

    # ---- 几何越界：每个形状必须落在画布内 ----
    if d["content"] and d["geom"]:
        K = min(d["content"][0] / s["VW"], d["content"][1] / s["VH"])
        out_of = []
        for (x_emu, y_emu, cx_emu, cy_emu) in d["geom"]:
            x0, y0 = x_emu / K, y_emu / K
            x1, y1 = x0 + cx_emu / K, y0 + cy_emu / K
            if x0 < -TOL_PX or y0 < -TOL_PX or x1 > s["VW"] + TOL_PX or y1 > s["VH"] + TOL_PX:
                out_of.append((x0, y0, x1, y1))
        print(f"=== 几何 ===\n  形状 {len(d['geom'])} 个，越界 {len(out_of)} 个"
              + (f"（例: x {out_of[0][0]:.0f}~{out_of[0][2]:.0f}, y {out_of[0][1]:.0f}~{out_of[0][3]:.0f}）"
                 if out_of else ""))
        for b in out_of[:5]:
            print(f"   ✗ 越界: x {b[0]:.0f}~{b[2]:.0f}, y {b[1]:.0f}~{b[3]:.0f}")
        if out_of:
            ok = False

    # ---- 双向文本精确比对 ----
    svg_c, doc_c = Counter(s["texts"]), Counter(d["texts"])
    missing = list((svg_c - doc_c).elements())
    extra = list((doc_c - svg_c).elements())
    print(f"=== 文本比对 ===\n  SVG {len(s['texts'])} 行 | 缺失 {len(missing)} | 多出 {len(extra)}")
    for m in missing[:10]:
        print("   ✗ 缺失:", m)
    for e in extra[:10]:
        print("   ✗ 多出:", e)
    if missing or extra:
        ok = False

    # ---- 可选：本机 Word 实测 ----
    pdf = os.path.splitext(a.docx)[0] + "_预览.pdf"
    if a.word:
        if os.path.exists(pdf):
            try:
                os.remove(pdf)
            except OSError:
                pass
        good, out = run_word(a.docx, pdf)
        print("=== Word COM 实测 ===\n ", out[:300])
        if not good:
            print("  ✗ Word 无法打开该 DOCX"); ok = False
        elif not os.path.exists(pdf):
            print("  ✗ Word 已打开但未导出 PDF"); ok = False
        else:
            try:
                import pymupdf
                p = pymupdf.open(pdf)
                blob = norm(p[0].get_text())
                miss2 = [t for t in s["texts"] if t not in blob]
                print(f"  PDF 页数 {p.page_count} | 渲染缺失 {len(miss2)} 行")
                for m in miss2[:10]:
                    print("   ✗", m)
                if miss2:
                    ok = False
                if a.render:
                    png = os.path.splitext(a.docx)[0] + "_渲染.png"
                    p[0].get_pixmap(dpi=110).save(png)
                    print("  渲染图:", png)
            except ImportError:
                print("  (未装 pymupdf，跳过 PDF 文本比对)")

    # ---- 可选：PDF -> PNG（--word 未跑时复用已有 PDF）----
    doc_png = os.path.splitext(a.docx)[0] + "_渲染.png"
    if a.render and os.path.exists(pdf) and not os.path.exists(doc_png):
        try:
            import pymupdf
            pymupdf.open(pdf)[0].get_pixmap(dpi=110).save(doc_png)
            print("  PDF 渲染图:", doc_png)
        except ImportError:
            pass

    # ---- 可选：Chrome 渲染 SVG 参考图（按 viewBox 实际尺寸）+ 拼左右对照图 ----
    if a.render:
        chrome = None
        for c in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                  r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                  r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"):
            if os.path.exists(c):
                chrome = c
                break
        if chrome:
            ref = os.path.splitext(a.svg)[0] + "_参考.png"
            os.popen('"%s" --headless --disable-gpu --hide-scrollbars --screenshot="%s" '
                     '--window-size=%d,%d --default-background-color=FFFFFFFF "file:///%s"'
                     % (chrome, ref, round(s["VW"]), round(s["VH"]),
                        a.svg.replace("\\", "/"))).read()
            print("  SVG 参考图:", ref, "(存在)" if os.path.exists(ref) else "(失败)")
            try:
                from PIL import Image
                if os.path.exists(ref) and os.path.exists(doc_png):
                    A, B = Image.open(ref), Image.open(doc_png)
                    H = 1000
                    A2 = A.resize((max(int(A.width * H / A.height), 1), H))
                    B2 = B.resize((max(int(B.width * H / B.height), 1), H))
                    cvs = Image.new("RGB", (A2.width + B2.width + 30, H), "white")
                    cvs.paste(A2, (0, 0)); cvs.paste(B2, (A2.width + 30, 0))
                    out = os.path.splitext(a.docx)[0] + "_对照图.png"
                    cvs.save(out)
                    print("  左右对照图:", out)
            except ImportError:
                pass

    print("\n结论:", "全部通过 ✓" if ok else "存在问题 ✗")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
