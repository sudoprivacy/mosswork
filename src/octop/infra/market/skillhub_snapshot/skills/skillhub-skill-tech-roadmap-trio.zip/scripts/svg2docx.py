#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
svg2docx.py —— 把技术路线图 SVG 严格转译为 Word 原生可编辑形状（wps:wsp）。

与「按 spec 重算布局」的做法不同，本脚本以 SVG 为唯一数据源：逐个读取
rect / line / path / text，把几何、圆角(rx)、线宽(stroke-width)、虚实(stroke-dasharray)、
箭头(marker-end)、字号(font-size)、字重(font-weight)、行距(tspan dy) 一对一映射为
DrawingML。每个元素在 Word 中都是一个可独立选中、改字、拖动的原生对象，不含任何位图。

用法:
    python svg2docx.py <input.svg> [output.docx] [--margin 0.5] [--landscape] [--font 微软雅黑]

依赖: python-docx（仅用于建空文档与注入 XML，几何与形状全部手工生成）

════════════════════════════════════════════════════════════════════════
以下 10 条是实测踩过的坑，修改本脚本前务必读完，任一条写错都会让 Word 报
「打开文件时遇到错误」或渲染错位：
1. Word 文档中 a:graphicData(uri=.../2010/wordprocessingShape) 内必须是 <wps:wsp>，
   文本走 wps:txbx > w:txbxContent（WordprocessingML）。裸 a:sp/a:txBody 是 PPT 语法，
   XSD 验不出但 Word 一律拒绝。
2. wp:anchor 子元素顺序（ISO 29500-4 CT_Anchor）：simplePos, positionH, positionV,
   extent, effectExtent, wrapNone, docPr, cNvGraphicFramePr, graphic
   —— 注意 wrapNone 在 docPr 之前。
3. **a:gd 只有 name 与 fmla 两个属性，没有 val**。圆角必须写
   <a:gd name="adj" fmla="val 16667"/>；写成 val="16667" Word 直接报错且 XSD 查不出。
   圆角半径 = adj/100000 * min(w,h)，故 adj = rx/min(w,h)*100000。
4. 字号换算：画布 px -> pt 必须用实际比例 K/12700（本例约 0.66），
   **不能用 96dpi 的 0.75**，否则文字放大约 28%，框内换行、纵向溢出被裁。
5. 中文必须指定 w:rFonts w:eastAsia=<中文字体>，否则回退 MS Mincho（日文明朝体），
   字形与度量都不对。字体名取自 SVG 根元素 font-family 的第一个字体。
6. 线段方向用 a:xfrm flipH/flipV 表达（prstGeom=line 默认从左上画到右下）；
   extent 的 cx/cy 为 0 不合法，取 max(...,1)（竖线/横线同理）。
7. 行距用 w:spacing lineRule="exact"，抵消 Word 中文字体行高膨胀（约 1.4×）导致的裁剪；
   单行时取 1.3×字号。
8. 文本框 bodyPr 的 lIns/tIns/rIns/bIns 必须为 0，anchor="ctr"，wrap="none"，才能与 SVG 的
   text-anchor="middle" + 居中基线算法对齐（wrap=square 会让 Word 在框内折行导致纵向溢出）。
9. 颜色不能只认 #hex：black / rgb(0,0,0) / #FFF 原样写入 <a:srgbClr val="BLACK"> 会生成非法 hex，
   Word 直接报错。hexclr() 必须支持命名色、rgb()/rgba()（含百分比）、3/4/8 位 hex。
10. path 不能只认大写 M/L/Z：相对指令 m/l/z 会被静默丢弃（形状凭空消失），
    C/S/Q/A 曲线若按折线且把控制点当顶点会几何畸变。必须支持 Mm Ll Hh Vv Cc Ss Qq Tt Aa Zz。
"""
import argparse
import os
import re
import sys
import xml.etree.ElementTree as ET

from docx import Document
from docx.shared import Inches
from docx.enum.section import WD_ORIENT
from docx.oxml import parse_xml

SVGNS = "{http://www.w3.org/2000/svg}"

NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
      'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
      'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" '
      'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"')


# ----------------------------------------------------------------------------- 工具
def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


# 坑 9：SVG 颜色语法远不止 #rrggbb。命名色 / rgb() 若原样写入 <a:srgbClr val="BLACK">
# 会生成非法 hex，Word 直接报「打开文件时遇到错误」。短 hex（#FFF）同理。
NAMED_COLORS = {
    "black": "000000", "white": "FFFFFF", "red": "FF0000", "lime": "00FF00",
    "blue": "0000FF", "yellow": "FFFF00", "cyan": "00FFFF", "aqua": "00FFFF",
    "magenta": "FF00FF", "fuchsia": "FF00FF", "silver": "C0C0C0", "gray": "808080",
    "grey": "808080", "maroon": "800000", "olive": "808000", "green": "008000",
    "purple": "800080", "teal": "008080", "navy": "000080", "orange": "FFA500",
}
_RGB_RE = re.compile(r"rgba?\(\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)"
                     r"\s*(?:[,/]\s*[\d.]+%?\s*)?\)")


def hexclr(v):
    """SVG 颜色 -> 6 位 hex（无 #）。无法识别返回 None（调用方回退默认色）。
    支持 #rrggbb / #rgb / #rrggbbaa / rgb()/rgba() / 命名色 / none/transparent。"""
    if not v:
        return None
    v = v.strip()
    low = v.lower()
    if low in ("none", "", "transparent"):
        return None
    if low.startswith("#"):
        h = low[1:]
        if len(h) == 3:                                # #abc -> aabbcc
            h = "".join(c * 2 for c in h)
        elif len(h) == 4:                              # #rgba -> 丢弃 alpha
            h = "".join(c * 2 for c in h[:3])
        elif len(h) == 8:                              # #rrggbbaa -> 丢弃 alpha
            h = h[:6]
        if len(h) == 6 and re.fullmatch(r"[0-9a-f]{6}", h):
            return h.upper()
        return None
    m = _RGB_RE.fullmatch(low)
    if m:
        rgb = []
        for g in m.groups():
            x = float(g[:-1]) * 255 / 100 if g.endswith("%") else float(g)
            rgb.append(max(0, min(255, int(round(x)))))
        return "%02X%02X%02X" % tuple(rgb)
    return NAMED_COLORS.get(low)


def fnum(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def parse_translate(el):
    t = el.get("transform") or ""
    m = re.search(r"translate\(\s*(-?[\d.]+)[\s,]+(-?[\d.]+)\s*\)", t)
    if m:
        return float(m.group(1)), float(m.group(2))
    return 0.0, 0.0


def _bez3(p0, p1, p2, p3, n=12):
    """三次贝塞尔 -> 折线点（不含起点）。"""
    out = []
    for k in range(1, n + 1):
        t = k / n
        mt = 1 - t
        out.append((mt**3 * p0[0] + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0] + t**3 * p3[0],
                    mt**3 * p0[1] + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1] + t**3 * p3[1]))
    return out


def _bez2(p0, p1, p2, n=10):
    """二次贝塞尔 -> 折线点（不含起点）。"""
    out = []
    for k in range(1, n + 1):
        t = k / n
        mt = 1 - t
        out.append((mt * mt * p0[0] + 2 * mt * t * p1[0] + t * t * p2[0],
                    mt * mt * p0[1] + 2 * mt * t * p1[1] + t * t * p2[1]))
    return out


def _arc(x1, y1, rx, ry, phi_deg, laf, sf, x2, y2, n=20):
    """椭圆弧 -> 折线点（端点参数化转中心参数化，SVG 规范 F.6.5）。"""
    import math
    if rx == 0 or ry == 0:
        return [(x2, y2)]
    rx, ry = abs(rx), abs(ry)
    phi = math.radians(phi_deg % 360)
    cosp, sinp = math.cos(phi), math.sin(phi)
    dx, dy = (x1 - x2) / 2.0, (y1 - y2) / 2.0
    x1p, y1p = cosp * dx + sinp * dy, -sinp * dx + cosp * dy
    lam = x1p * x1p / (rx * rx) + y1p * y1p / (ry * ry)
    if lam > 1:
        s = math.sqrt(lam)
        rx *= s
        ry *= s
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    co = math.sqrt(max(num / den, 0.0)) if den else 0.0
    if laf == sf:
        co = -co
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx
    cx = cosp * cxp - sinp * cyp + (x1 + x2) / 2
    cy = sinp * cxp + cosp * cyp + (y1 + y2) / 2

    def _ang(ux, uy, vx, vy):
        nrm = math.hypot(ux, uy) * math.hypot(vx, vy)
        a = math.acos(max(-1.0, min(1.0, (ux * vx + uy * vy) / nrm))) if nrm else 0.0
        return -a if ux * vy - uy * vx < 0 else a

    th1 = _ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dth = _ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sf and dth > 0:
        dth -= 2 * math.pi
    elif sf and dth < 0:
        dth += 2 * math.pi
    return [(cosp * rx * math.cos(th1 + dth * k / n) - sinp * ry * math.sin(th1 + dth * k / n) + cx,
             sinp * rx * math.cos(th1 + dth * k / n) + cosp * ry * math.sin(th1 + dth * k / n) + cy)
            for k in range(1, n + 1)]


_PATH_ARGN = {"M": 2, "L": 2, "H": 1, "V": 1, "C": 6, "S": 4, "Q": 4, "T": 2, "A": 7, "Z": 0}


def parse_path(d):
    """解析 SVG path（支持 Mm Ll Hh Vv Cc Ss Qq Tt Aa Zz，含相对指令与隐式重复）。

    返回 (子路径列表, 闭合标志列表)：子路径为绝对坐标点列表，曲线按折线近似。
    坑 10：早期版本只认大写 M/L/Z —— 相对指令 m/l/z 会被静默丢弃（形状凭空消失），
    C/A 曲线被当成折线且把控制点当顶点（几何畸变），且都不报错。
    """
    tokens = re.findall(r"[MmLlHhVvCcSsQqTtAaZz]|-?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?",
                        d or "")
    subs, closed = [], []
    cur = []
    cx = cy = sx = sy = 0.0
    prev_ctrl = None
    i, cmd, C = 0, None, None
    while i < len(tokens):
        t = tokens[i]
        if re.fullmatch(r"[A-Za-z]", t):
            cmd = t
            i += 1
            if cmd in "Zz":
                if cur:
                    cur.append((sx, sy))
                subs.append(cur if cur else [(sx, sy)])
                closed.append(True)
                cur = []
                cx, cy = sx, sy
                prev_ctrl = None
                continue
        elif cmd is None:
            break
        else:
            # 隐式重复：M 之后的连续坐标视为 L
            if cmd in "Mm":
                cmd = "L" if cmd == "M" else "l"
            elif cmd in "Zz":
                break
        C = cmd
        need = _PATH_ARGN[C.upper()]
        if i + need > len(tokens):
            break
        nums = [float(x) for x in tokens[i:i + need]]
        i += need
        rel = C.islower()
        try:
            if C.upper() == "M":
                x, y = (cx + nums[0], cy + nums[1]) if rel else (nums[0], nums[1])
                if cur:
                    subs.append(cur)
                    closed.append(False)
                cur = [(x, y)]
                cx, cy = sx, sy = x, y
                prev_ctrl = None
            elif C.upper() == "L":
                x, y = (cx + nums[0], cy + nums[1]) if rel else (nums[0], nums[1])
                cur.append((x, y))
                cx, cy = x, y
                prev_ctrl = None
            elif C.upper() == "H":
                x = cx + nums[0] if rel else nums[0]
                cur.append((x, cy))
                cx = x
                prev_ctrl = None
            elif C.upper() == "V":
                y = cy + nums[0] if rel else nums[0]
                cur.append((cx, y))
                cy = y
                prev_ctrl = None
            elif C.upper() == "C":
                p = [(cx + nums[k], cy + nums[k + 1]) if rel else (nums[k], nums[k + 1])
                     for k in (0, 2, 4)]
                cur.extend(_bez3((cx, cy), p[0], p[1], p[2]))
                prev_ctrl = p[1]
                cx, cy = p[2]
            elif C.upper() == "S":
                x2, y2 = (cx + nums[0], cy + nums[1]) if rel else (nums[0], nums[1])
                x, y = (cx + nums[2], cy + nums[3]) if rel else (nums[2], nums[3])
                x1, y1 = (2 * cx - prev_ctrl[0], 2 * cy - prev_ctrl[1]) if prev_ctrl else (cx, cy)
                cur.extend(_bez3((cx, cy), (x1, y1), (x2, y2), (x, y)))
                prev_ctrl = (x2, y2)
                cx, cy = x, y
            elif C.upper() == "Q":
                x1, y1 = (cx + nums[0], cy + nums[1]) if rel else (nums[0], nums[1])
                x, y = (cx + nums[2], cy + nums[3]) if rel else (nums[2], nums[3])
                cur.extend(_bez2((cx, cy), (x1, y1), (x, y)))
                prev_ctrl = (x1, y1)
                cx, cy = x, y
            elif C.upper() == "T":
                x, y = (cx + nums[0], cy + nums[1]) if rel else (nums[0], nums[1])
                x1, y1 = (2 * cx - prev_ctrl[0], 2 * cy - prev_ctrl[1]) if prev_ctrl else (cx, cy)
                cur.extend(_bez2((cx, cy), (x1, y1), (x, y)))
                prev_ctrl = (x1, y1)
                cx, cy = x, y
            elif C.upper() == "A":
                rx, ry, rot, laf, sf = nums[0], nums[1], nums[2], int(nums[3]), int(nums[4])
                x, y = (cx + nums[5], cy + nums[6]) if rel else (nums[5], nums[6])
                cur.extend(_arc(cx, cy, rx, ry, rot, laf, sf, x, y))
                cx, cy = x, y
                prev_ctrl = None
        except (IndexError, ValueError):
            break
        if C.upper() not in "CSQT":
            prev_ctrl = None
    if cur:
        subs.append(cur)
        closed.append(False)
    return subs, closed


# ----------------------------------------------------------------------------- CSS
def parse_css(root):
    css = {}
    st = root.find(SVGNS + "style")
    if st is not None and st.text:
        for m in re.finditer(r"([^{}]+)\{([^{}]*)\}", st.text):
            sel = m.group(1).strip()
            props = {}
            for decl in m.group(2).split(";"):
                if ":" in decl:
                    k, v = decl.split(":", 1)
                    props[k.strip()] = v.strip()
            css.setdefault(sel, {}).update(props)
    return css


def style_for(css, tag, own_classes, anc_classes):
    """近似 CSS 匹配：`.ancestor tag` / `.own` / `tag`，按样式表出现顺序后者覆盖前者。"""
    props = {}
    for sel, p in css.items():
        parts = sel.split()
        if len(parts) == 2 and parts[1] == tag and parts[0].startswith("."):
            if parts[0][1:] in anc_classes:
                props.update(p)
        elif len(parts) == 1:
            s = parts[0]
            if s.startswith("."):
                if s[1:] in own_classes:
                    props.update(p)
            elif s == tag:
                props.update(p)
    return props


# ----------------------------------------------------------------------------- 生成器
class Builder:
    def __init__(self, K, font="Microsoft YaHei"):
        self.K = K
        self.font = font
        self.PX2PT = K / 12700.0          # 画布 px -> pt 的实际比例
        self.shapes = []                  # [(xml, x, y, w, h)]
        self._id = 300

    def nid(self):
        self._id += 1
        return self._id

    def emu(self, v):
        return int(round(v * self.K))

    # ---- 文本 ----
    def txbx_content(self, lines, font_px, bold, line_px, jc="center"):
        hp = max(int(font_px * self.PX2PT * 2), 6)      # 半点，向下取整
        line_tw = int(round(line_px * self.PX2PT * 20))  # exact 行距(twips)
        line_tw = max(line_tw, int(hp * 10.5))           # 不小于 1.05×字号，防裁剪
        f = self.font
        ps = []
        for ln in lines:
            rpr = (f'<w:rPr><w:rFonts w:ascii="{f}" w:hAnsi="{f}" '
                   f'w:eastAsia="{f}" w:cs="{f}"/>'
                   + ("<w:b/>" if bold else "")
                   + '<w:color w:val="000000"/>'
                   + f'<w:sz w:val="{hp}"/><w:szCs w:val="{hp}"/></w:rPr>')
            ps.append('<w:p><w:pPr><w:spacing w:before="0" w:after="0" '
                      f'w:line="{line_tw}" w:lineRule="exact"/>'
                      f'<w:jc w:val="{jc}"/></w:pPr>'
                      f'<w:r>{rpr}<w:t xml:space="preserve">{esc(ln)}</w:t></w:r></w:p>')
        return "".join(ps)

    # ---- 矩形 / 圆角矩形（可含文本）----
    def rect_shape(self, x, y, w, h, rx, lines, font_px, bold, line_px,
                   fill="FFFFFF", sw_px=1.5, dash=False):
        if rx and rx > 0:
            # 坑 3：a:gd 只有 name + fmla，没有 val
            adj = int(min(rx / min(w, h), 0.5) * 100000)
            geom = ('<a:prstGeom prst="roundRect"><a:avLst>'
                    f'<a:gd name="adj" fmla="val {adj}"/>'
                    '</a:avLst></a:prstGeom>')
        else:
            geom = '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
        fillxml = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else '<a:noFill/>'
        dashxml = '<a:prstDash val="dash"/>' if dash else ''
        lw = max(self.emu(sw_px), 1)
        if lines:
            txbx = (f'<wps:txbx><w:txbxContent>'
                    f'{self.txbx_content(lines, font_px, bold, line_px)}'
                    f'</w:txbxContent></wps:txbx>')
            cnv = '<wps:cNvSpPr txBox="1"/>'
            # 坑 8：insets 必须为 0；wrap="none" = 不自动换行（SVG 文本从不换行，
            # 超宽时溢出显示，与 SVG 行为一致；用 square 会在框内折行导致纵向溢出）
            body = ('<wps:bodyPr rot="0" anchor="ctr" wrap="none" '
                    'lIns="0" tIns="0" rIns="0" bIns="0"/>')
        else:
            txbx, cnv, body = "", "<wps:cNvSpPr/>", "<wps:bodyPr/>"
        xml = (f'<wps:wsp>{cnv}<wps:spPr>'
               f'<a:xfrm><a:off x="{self.emu(x)}" y="{self.emu(y)}"/>'
               f'<a:ext cx="{self.emu(w)}" cy="{self.emu(h)}"/></a:xfrm>'
               f'{geom}{fillxml}'
               f'<a:ln w="{lw}"><a:solidFill><a:srgbClr val="000000"/></a:solidFill>'
               f'{dashxml}</a:ln></wps:spPr>{txbx}{body}</wps:wsp>')
        self.shapes.append((xml, x, y, w, h))

    # ---- 无框纯文本 ----
    def text_only(self, x, y, w, h, lines, font_px, bold, line_px, jc="left"):
        xml = ('<wps:wsp><wps:cNvSpPr txBox="1"/><wps:spPr>'
               f'<a:xfrm><a:off x="{self.emu(x)}" y="{self.emu(y)}"/>'
               f'<a:ext cx="{self.emu(w)}" cy="{self.emu(h)}"/></a:xfrm>'
               '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
               '<a:noFill/><a:ln><a:noFill/></a:ln></wps:spPr>'
               f'<wps:txbx><w:txbxContent>'
               f'{self.txbx_content(lines, font_px, bold, line_px, jc=jc)}'
               f'</w:txbxContent></wps:txbx>'
               '<wps:bodyPr rot="0" anchor="ctr" wrap="none" '
               'lIns="0" tIns="0" rIns="0" bIns="0"/></wps:wsp>')
        self.shapes.append((xml, x, y, w, h))

    # ---- 直线 ----
    def line_shape(self, x1, y1, x2, y2, sw_px=1.2, dash=False, arrow=False):
        x = min(x1, x2); y = min(y1, y2)
        dx = abs(x2 - x1); dy = abs(y2 - y1)
        flip = ""
        if x2 < x1:
            flip += ' flipH="1"'
        if y2 < y1:
            flip += ' flipV="1"'
        end = '<a:tailEnd type="triangle" w="sm" len="sm"/>' if arrow else ''
        dashxml = '<a:prstDash val="dash"/>' if dash else ''
        lw = max(self.emu(sw_px), 1)
        xml = (f'<wps:wsp><wps:cNvCnPr/><wps:spPr>'
               f'<a:xfrm{flip}><a:off x="{self.emu(x)}" y="{self.emu(y)}"/>'
               f'<a:ext cx="{max(self.emu(dx), 1)}" cy="{max(self.emu(dy), 1)}"/></a:xfrm>'
               '<a:prstGeom prst="line"><a:avLst/></a:prstGeom>'
               f'<a:noFill/>'
               f'<a:ln w="{lw}"><a:solidFill><a:srgbClr val="000000"/></a:solidFill>'
               f'{dashxml}{end}</a:ln></wps:spPr><wps:bodyPr/></wps:wsp>')
        self.shapes.append((xml, x, y, max(dx, 0.01), max(dy, 0.01)))

    # ---- 自定义闭合多边形（阶段推进的空心箭头块等）----
    def poly_shape(self, pts, sw_px=2.0, fill="FFFFFF", closed=True):
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        x0, y0 = min(xs), min(ys)
        w, h = max(xs) - x0, max(ys) - y0
        mv = f'<a:moveTo><a:pt x="{self.emu(pts[0][0]-x0)}" y="{self.emu(pts[0][1]-y0)}"/></a:moveTo>'
        ln = "".join(f'<a:lnTo><a:pt x="{self.emu(p[0]-x0)}" y="{self.emu(p[1]-y0)}"/></a:lnTo>'
                     for p in pts[1:])
        close = "<a:close/>" if closed else ""
        fillxml = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else '<a:noFill/>'
        lw = max(self.emu(sw_px), 1)
        xml = (f'<wps:wsp><wps:cNvSpPr/><wps:spPr>'
               f'<a:xfrm><a:off x="{self.emu(x0)}" y="{self.emu(y0)}"/>'
               f'<a:ext cx="{self.emu(w)}" cy="{self.emu(h)}"/></a:xfrm>'
               '<a:custGeom><a:avLst/><a:gdLst/>'
               f'<a:pathLst><a:path w="{self.emu(w)}" h="{self.emu(h)}">'
               f'{mv}{ln}{close}</a:path></a:pathLst></a:custGeom>'
               f'{fillxml}'
               f'<a:ln w="{lw}"><a:solidFill><a:srgbClr val="000000"/></a:solidFill></a:ln>'
               f'</wps:spPr><wps:bodyPr/></wps:wsp>')
        self.shapes.append((xml, x0, y0, w, h))


def wrap_anchor(shape_xml, x, y, w, h, K, docpr_id):
    """坑 2：wp:anchor 子元素顺序 —— simplePos, positionH, positionV, extent,
       effectExtent, wrapNone, docPr, cNvGraphicFramePr, graphic"""
    emu = lambda v: int(round(v * K))
    return (f'<w:drawing {NS}>'
            f'<wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0" '
            f'relativeHeight="{251658240 + docpr_id}" behindDoc="0" locked="0" '
            f'layoutInCell="1" allowOverlap="1">'
            f'<wp:simplePos x="0" y="0"/>'
            f'<wp:positionH relativeFrom="margin"><wp:posOffset>{emu(x)}</wp:posOffset></wp:positionH>'
            f'<wp:positionV relativeFrom="margin"><wp:posOffset>{emu(y)}</wp:posOffset></wp:positionV>'
            f'<wp:extent cx="{max(emu(w), 1)}" cy="{max(emu(h), 1)}"/>'
            f'<wp:effectExtent l="0" t="0" r="0" b="0"/>'
            f'<wp:wrapNone/>'
            f'<wp:docPr id="{docpr_id}" name="S{docpr_id}"/>'
            f'<wp:cNvGraphicFramePr/>'
            f'<a:graphic><a:graphicData '
            f'uri="http://schemas.microsoft.com/office/word/2010/wordprocessingShape">'
            f'{shape_xml}'
            f'</a:graphicData></a:graphic>'
            f'</wp:anchor></w:drawing>')


# ----------------------------------------------------------------------------- 主流程
def build(svg_path, out_path, margin_in=0.5, landscape=False, font=None):
    tree = ET.parse(svg_path)
    root = tree.getroot()
    vb = [float(v) for v in (root.get("viewBox") or "0 0 794 988").split()]
    VW, VH = vb[2], vb[3]
    css = parse_css(root)

    # 坑 5：中文字体取自 SVG 根元素 font-family 的第一个字体
    if not font:
        fam = (root.get("font-family") or "Microsoft YaHei").split(",")[0]
        font = fam.strip().strip('"').strip("'") or "Microsoft YaHei"

    doc = Document()
    sec = doc.sections[0]
    if landscape:
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width, sec.page_height = Inches(11.69), Inches(8.27)
    else:
        sec.page_width, sec.page_height = Inches(8.27), Inches(11.69)
    m = Inches(margin_in)
    sec.left_margin = sec.right_margin = sec.top_margin = sec.bottom_margin = m
    cw_emu = int(sec.page_width) - 2 * int(m)
    ch_emu = int(sec.page_height) - 2 * int(m)
    K = min(cw_emu / VW, ch_emu / VH)
    B = Builder(K, font=font)
    if K / 12700.0 < 0.45:
        print("[警告] 画布 %.0f×%.0f + 页边距 %.2fin -> 1px=%.3fpt，正文(10.5px)仅约 %.1fpt，"
              "在 A4 上可能不可读；建议精简内容、减小 --margin 或改用 --landscape"
              % (VW, VH, margin_in, K / 12700.0, 10.5 * K / 12700.0))

    parent = {c: p for p in root.iter() for c in p}

    def anc_classes(el):
        s, p = set(), parent.get(el)
        while p is not None:
            for c in (p.get("class") or "").split():
                s.add(c)
            p = parent.get(p)
        return s

    def own_classes(el):
        return set((el.get("class") or "").split())

    # 按图层次序输出，保证 z-order 与 SVG 一致：zones -> edges -> nodes -> labels
    order = {"layer-zones": 0, "layer-edges": 1, "layer-nodes": 2, "layer-labels": 3}
    layers = [(g.get("id") or "", g) for g in root.findall(SVGNS + "g")]
    layers.sort(key=lambda t: order.get(t[0], 9))

    for lid, layer in layers:
        # ===== 分区虚线框 =====
        if lid == "layer-zones":
            for r in layer.findall(SVGNS + "rect"):
                st = style_for(css, "rect", own_classes(r), anc_classes(r))
                x, y = fnum(r.get("x")), fnum(r.get("y"))
                w, h = fnum(r.get("width")), fnum(r.get("height"))
                sw = fnum(r.get("stroke-width"), fnum(st.get("stroke-width"), 1))
                dash = bool((st.get("stroke-dasharray") or r.get("stroke-dasharray") or "").strip())
                B.rect_shape(x, y, w, h, fnum(r.get("rx")), [], 10, False, 10,
                             fill=None, sw_px=sw, dash=dash)

        # ===== 连线层 =====
        elif lid == "layer-edges":
            for el in layer:
                tag = el.tag.replace(SVGNS, "")
                if tag == "line":
                    st = style_for(css, "line", own_classes(el), anc_classes(el))
                    x1, y1 = fnum(el.get("x1")), fnum(el.get("y1"))
                    x2, y2 = fnum(el.get("x2")), fnum(el.get("y2"))
                    sw = fnum(el.get("stroke-width"), fnum(st.get("stroke-width"), 1.2))
                    dash = bool((st.get("stroke-dasharray") or el.get("stroke-dasharray") or "").strip())
                    B.line_shape(x1, y1, x2, y2, sw_px=sw, dash=dash,
                                 arrow=bool(el.get("marker-end")))
                elif tag == "path":
                    st = style_for(css, "path", own_classes(el), anc_classes(el))
                    subs, closed_flags = parse_path(el.get("d") or "")
                    sw = fnum(el.get("stroke-width"), fnum(st.get("stroke-width"), 1.2))
                    dash = bool((st.get("stroke-dasharray") or el.get("stroke-dasharray") or "").strip())
                    arrow = bool(el.get("marker-end"))
                    fill = hexclr(el.get("fill", st.get("fill", "none")))
                    if el.get("data-link") == "flow" or (
                            len(subs) == 1 and closed_flags and closed_flags[0]
                            and len(subs[0]) > 3):
                        # 闭合多边形：用 custGeom 逐顶点精确还原
                        if subs and subs[0]:
                            B.poly_shape(subs[0], sw_px=sw, fill=fill or "FFFFFF", closed=True)
                    else:
                        # 折线/树状线/反馈线：拆成独立直线段逐段还原
                        for sp in subs:
                            for a, b in zip(sp, sp[1:]):
                                B.line_shape(a[0], a[1], b[0], b[1],
                                             sw_px=sw, dash=dash, arrow=False)
                        if arrow and subs and len(subs[-1]) >= 2:
                            # marker-end 在整条 path 终点：最后一段补箭头
                            B.shapes.pop()
                            a, b = subs[-1][-2], subs[-1][-1]
                            B.line_shape(a[0], a[1], b[0], b[1],
                                         sw_px=sw, dash=dash, arrow=True)
                elif tag == "text":
                    # 独立文本（如反馈标签），无框；text-anchor 默认 start -> 左对齐
                    st = style_for(css, "text", own_classes(el), anc_classes(el))
                    fs = fnum(re.sub("px", "", st.get("font-size", "10px")), 10)
                    bold = st.get("font-weight", "400") in ("700", "bold")
                    tspans = el.findall(SVGNS + "tspan")
                    lines = [(x.text or "") for x in tspans] or [(el.text or "")]
                    x, y = fnum(el.get("x")), fnum(el.get("y"))
                    w = fs * max(len(s) for s in lines) * 1.05
                    jc = "center" if el.get("text-anchor") == "middle" else "left"
                    B.text_only(x, y - fs * 0.85, w, fs * 1.5, lines, fs, bold,
                                fs * 1.35, jc=jc)

        # ===== 节点框 / 标签框（g > rect + text）=====
        else:
            for g in layer.findall(SVGNS + "g"):
                ox, oy = parse_translate(g)
                r = g.find(SVGNS + "rect")
                t = g.find(SVGNS + "text")
                if r is None:
                    continue
                anc = anc_classes(r)
                st = style_for(css, "rect", own_classes(r), anc)
                w, h = fnum(r.get("width")), fnum(r.get("height"))
                sw = fnum(r.get("stroke-width"), fnum(st.get("stroke-width"), 1.5))
                dash = bool((st.get("stroke-dasharray") or r.get("stroke-dasharray") or "").strip())
                fill = hexclr(r.get("fill", st.get("fill", "#ffffff"))) or "FFFFFF"
                lines, fs, bold, line_px = [], 10, False, 13
                if t is not None:
                    tst = style_for(css, "text", own_classes(t), anc_classes(t))
                    fs = fnum(re.sub("px", "", tst.get("font-size", "10px")), 10)
                    bold = tst.get("font-weight", "400") in ("700", "bold")
                    tspans = t.findall(SVGNS + "tspan")
                    lines = [(x.text or "") for x in tspans] or [(t.text or "")]
                    dys = [fnum(x.get("dy")) for x in tspans[1:]]
                    line_px = dys[0] if dys and dys[0] > 0 else fs * 1.3
                B.rect_shape(ox, oy, w, h, fnum(r.get("rx")), lines, fs, bold, line_px,
                             fill=fill, sw_px=sw, dash=dash)

    # ---------- 写出：每个形状一个独立浮动 anchor ----------
    para = doc.add_paragraph()
    for i, (xml, x, y, w, h) in enumerate(B.shapes, start=1):
        run = para.add_run()
        run._r.append(parse_xml(wrap_anchor(xml, x, y, w, h, K, i)))
    doc.save(out_path)

    print("[OK]", out_path)
    print("形状数(独立 anchor):", len(B.shapes))
    print("viewBox: %.0f x %.0f | K=%.1f EMU/px | 1px=%.3fpt" % (VW, VH, K, K / 12700.0))
    print("画布尺寸: %.2f x %.2f in | 字体: %s" % (VW * K / 914400.0, VH * K / 914400.0, font))
    return len(B.shapes)


def main():
    ap = argparse.ArgumentParser(description="SVG -> Word 原生可编辑形状 DOCX")
    ap.add_argument("svg")
    ap.add_argument("out", nargs="?", default=None)
    ap.add_argument("--margin", type=float, default=0.5, help="页边距(in)，默认 0.5，须 >=0")
    ap.add_argument("--landscape", action="store_true", help="横向页面")
    ap.add_argument("--font", default=None, help="中文字体名，默认取自 SVG font-family")
    a = ap.parse_args()
    if not os.path.isfile(a.svg):
        print("[错误] 找不到 SVG 文件:", a.svg)
        sys.exit(2)
    if a.margin < 0:
        print("[错误] --margin 必须 >= 0，收到:", a.margin)
        sys.exit(2)
    page_w = 11.69 if a.landscape else 8.27
    if 2 * a.margin >= page_w - 0.5:
        print("[错误] --margin %.2fin 过大：页宽 %.2fin 扣掉两侧边距后不足 0.5in"
              % (a.margin, page_w))
        sys.exit(2)
    out = a.out or os.path.splitext(a.svg)[0] + ".docx"
    build(a.svg, out, margin_in=a.margin, landscape=a.landscape, font=a.font)


if __name__ == "__main__":
    main()
