# CHANGELOG

## 1.0.1（2026-09-28）—— 全面审计修复

对 v1.0.0 做全面严格审计，共发现 15 项缺陷（3 P0 / 6 P1 / 6 P2），全部修复并回归验证。
审计报告：`E:/Users/jowa/workbuddy/图形类/技术路线图三通道_审计报告.html`。

### 修复 · P0（使核心承诺失效）
- **verify.py `--word` 崩溃**：`os.popen().read()` 以 UTF-8 解码 PowerShell 的 GBK 输出，
  一旦输出含中文（Word 报错文案）即抛 `UnicodeDecodeError`。
  改为写临时 `.ps1`（UTF-8 BOM）+ `subprocess` 取原始字节 + 多编码兜底解码。
  同时修正相对路径问题（`subprocess` 的 PowerShell 会把相对路径解析到 `C:\Windows\System32`）。
- **verify.py 对「Word 打不开」判通过**：`--word` 现为硬失败；基础模式新增结构强校验。
- **svg2docx.py 非法颜色**：`hexclr()` 支持命名色 / `rgb()/rgba()` / 3·4·8 位 hex，
  此前 `black → "BLACK"` 会生成非法 `srgbClr` 使 Word 报错。

### 修复 · P1（静默产出错误交付物）
- **svg2docx.py `parse_path()` 重写**：支持 `Mm Ll Hh Vv Cc Ss Qq Tt Aa Zz`（含隐式重复），
  曲线折线扁平化，椭圆弧按 SVG F.6.5 转换；此前相对指令被静默丢弃、曲线几何畸变。
- **verify.py 新增四条不变式**：形状数下限（≥ SVG 图元数）、几何越界校验、
  文本双向精确比对、空产物拦截；此前这四类缺陷均判「全部通过」。
- **generate.py 溢出告警**：标题/方法框宽度钳制前先比较需求宽度并告警。
- **generate.py `is_wide()` 改为区间表**：覆盖 U+2000–206F 等，修正全角标点宽度低估 18–23%。

### 修复 · P2
- `--render` 截图尺寸按 viewBox 自适应（此前固定 794×988 致对照图比例失真）。
- `svg2docx.py` 增加 `--margin` 校验（负数/过大会报错）与 A4 可读性告警。
- 三个脚本统一「文件不存在」友好提示（退出码 2）。
- `generate.py` 空内容块 / 非法 `feedback` / 无效 `emphasis` 键改为告警；
  非字符串 `title/name` 安全降级（此前崩溃）。
- `generate.py` 新增画布过高（`H > 1200`）自检。
- SKILL.md 修正与实现不一致的 id 规则、自检范围与退出码语义。

### 新增
- `scripts/selftest.py` —— 零依赖自检：`hexclr` / `parse_path` / `is_wide` 单元用例，
  以及 spec→SVG→DOCX→verify 的端到端冒烟测试。

## 1.0.0（2026-09-28）

在 `bw-roadmap` 1.0.0 基础上扩展出第三条输出通道，技能改名「技术路线图-三通道」。

### 新增
- 通道③：`scripts/svg2docx.py` —— 以 SVG 为唯一数据源，逐元素（rect/line/path/text）
  转译为 Word 原生可编辑形状 `wps:wsp`，零位图，几何/圆角/线宽/虚实/箭头/字号/行距
  严格对应 SVG。支持 `--margin / --landscape / --font`。
- `scripts/verify.py` —— 三通道质检：SVG 元素统计、DOCX 形状数与零位图检查、
  `wp:anchor` 顺序检查、`a:gd` 误用 `val` 检查、逐 tspan 文本比对；
  `--word` 追加本机 Word COM 实测打开 + 导出 PDF 复验，
  `--render` 追加 Chrome 无头渲染 SVG + 左右对照图。
- `references/docx转译要点.md` —— SVG→DrawingML 转译的 8 条硬性坑点与验证方法
  （含 `a:gd` 无 `val` 属性、`wrapNone` 在 `docPr` 之前、px→pt 必须按 K/12700 等）。

### 变更
- SKILL.md 工作流由 4 步扩为 5 步：spec → SVG+HTML → DOCX → 质检 → 交付。
- 交付物从 2 件变为 3 件（.svg / -editor.html / .docx）。
- 迭代规则：改 spec 后需重跑 2→3→4 三通道全部刷新。

### 继承
- `scripts/generate.py`、`references/规范要点.md`、`examples/example1.json` 沿用 bw-roadmap 1.0.0。
