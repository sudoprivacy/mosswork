#!/usr/bin/env python3
"""知识卡片自动关联引擎 — 基于关键词共现匹配。"""

import os, re, sys, json
from collections import defaultdict

# Known tool/model names for semantic keyword expansion
TOOL_NAMES = [
    'codex', 'seedance', 'gemini', 'deepseek', 'gpt', 'claude', 'midjourney',
    'stable diffusion', 'lovart', 'comfyui', 'nanobanana', 'kimi', 'remotion',
    'photoshop', 'illustrator', 'wps', 'figma', 'notion', 'obsidian', 'ima',
    'workbuddy', 'fable', 'notebooklm', 'baoyu', 'guizang', 'superpowers',
    'playwright', 'github', 'cursor', 'solo', 'trae', 'flova', 'runway',
    'openspec', 'liblibai', '即梦', '哩布', '剪映', '可灵',
]

def extract_keywords(content):
    """从「## 关键词」小节提取关键词列表，含语义扩展。"""
    m = re.search(r'##\s*关键词[^\n]*\n(.*?)(?=\n##|\n---|\Z)', content, re.DOTALL | re.IGNORECASE)
    if not m:
        return []
    section = m.group(1)
    kws = re.split(r'[、，,\n]', section)
    base = [kw.strip().lower() for kw in kws if kw.strip() and len(kw.strip()) >= 2]

    # Semantic expansion: extract tool/model substrings from compound keywords
    expanded = set(base)
    for kw in base:
        kw_lower = kw.lower()
        for tool in TOOL_NAMES:
            # "seedance 2.0 mini" contains "seedance" → add "seedance"
            # "gpt5.6" prefix-matches "gpt"
            # "workbuddy搭建" contains "workbuddy"
            if tool in kw_lower and tool != kw_lower and len(tool) >= 2:
                expanded.add(tool)
            # Also check reversed: kw is inside tool (e.g. "nano" in "nanobanana")
            # Only if kw is ≥ 4 chars to avoid noise
            if len(kw_lower) >= 4 and kw_lower in tool:
                expanded.add(tool)

    return list(expanded)

def find_card_title(content):
    """Extract the card title from the first heading."""
    m = re.search(r'^#\s+(.+?)(?:\n|$)', content, re.MULTILINE)
    return m.group(1).strip() if m else ""

def has_related_section(content):
    """Check if card already has a 关联资料 section."""
    return bool(re.search(r'##\s*关联资料', content))

def write_related_section(content, related_cards):
    """Append or replace 关联资料 section."""
    lines = ['\n## 关联资料\n']
    for kw_shared, title in related_cards:
        lines.append(f'- **{title}**  `{kw_shared}`\n')
    section = ''.join(lines)

    if has_related_section(content):
        # Replace existing section
        content = re.sub(
            r'##\s*关联资料.*?(?=\n##|\n---|\Z)',
            section.strip(),
            content,
            flags=re.DOTALL
        )
    else:
        # Append before EOF
        content = content.rstrip() + '\n' + section
    return content

def main():
    cards_dir = None
    update = False
    args = sys.argv[1:]
    try:
        cards_dir = args[args.index('--cards-dir') + 1]
    except (ValueError, IndexError):
        print("Usage: link_cards.py --cards-dir DIR [--update]")
        sys.exit(1)
    update = '--update' in args

    card_files = sorted([f for f in os.listdir(cards_dir) if f.startswith('km_') and f.endswith('.md')])
    if not card_files:
        print("No card files found.")
        return

    # Phase 1: Extract keywords from all cards
    card_keywords = {}
    card_titles = {}
    card_contents = {}
    for f in card_files:
        path = os.path.join(cards_dir, f)
        with open(path, encoding='utf-8') as fp:
            content = fp.read()
        kws = extract_keywords(content)
        card_keywords[f] = kws
        card_titles[f] = find_card_title(content)
        card_contents[f] = content

    # Phase 2: Build inverted index
    inverted = defaultdict(set)
    for f, kws in card_keywords.items():
        for kw in set(kws):
            inverted[kw].add(f)

    unique_kws = len(inverted)
    print(f"扫描: {len(card_files)} 张卡片 | {unique_kws} 个唯一关键词")

    # Phase 3: Match
    linked_count = 0
    updated_count = 0
    for f in card_files:
        my_kws = set(card_keywords[f])
        if not my_kws:
            continue

        scores = defaultdict(int)
        for kw in my_kws:
            for other in inverted[kw]:
                if other != f:
                    scores[other] += 1

        top = sorted(scores.items(), key=lambda x: -x[1])[:10]
        if not top:
            continue

        linked_count += 1
        # Find shared keywords for each match
        related = []
        for other_f, score in top:
            shared = my_kws & set(card_keywords[other_f])
            related.append((', '.join(sorted(shared)[:3]), card_titles.get(other_f, other_f)))

        if update:
            new_content = write_related_section(card_contents[f], related)
            with open(os.path.join(cards_dir, f), 'w', encoding='utf-8') as fp:
                fp.write(new_content)
            updated_count += 1
        else:
            print(f"\n📎 {card_titles.get(f, f)[:50]}")
            for kw, title in related:
                print(f"   → {title[:40]} [{kw}]")

    print(f"\n有至少一个关联: {linked_count}/{len(card_files)} ({linked_count/len(card_files)*100:.1f}%)")
    if update:
        print(f"已更新: {updated_count} 张卡片")

    # Top keywords
    kw_freq = sorted(inverted.items(), key=lambda x: -len(x[1]))[:10]
    print(f"\n最高频共享关键词 Top 5:")
    for kw, cards in kw_freq[:5]:
        print(f"  `{kw}` — {len(cards)} 张卡片")

if __name__ == '__main__':
    main()
