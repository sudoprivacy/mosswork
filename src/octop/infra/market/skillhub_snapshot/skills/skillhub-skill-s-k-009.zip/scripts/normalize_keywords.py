#!/usr/bin/env python3
"""关键词规范化检测器 — 识别可标准化/可合并的非标准关键词。

检测模式：
1. 工具名变体：seedance 2.0 mini / seedance2.0 / Seedance → 统一为 seedance
2. 过于具体的装饰词：成都烟火、四句话、邵氏风格 → 建议替换为通用词
3. 中英混杂同义：ai快速制作 vs AI快速制作 → 统一小写
4. 单卡词：仅在1张卡出现的长关键词 → 建议添加通用父类词

用法:
    python3 normalize_keywords.py --cards-dir knowledge_cards/ [--apply]
"""

import os, re, sys
from collections import Counter, defaultdict

# 工具名标准化映射表
TOOL_CANONICAL = {
    'seedance 2.0': 'seedance', 'seedance2.0': 'seedance', 'seedance 2.0 mini': 'seedance',
    'gpt5.6': 'gpt', 'gpt-5.6': 'gpt', 'gpt 5.6': 'gpt',
    'gpt-image-2': 'gpt-image', 'gpt-image2': 'gpt-image', 'chatgpt-image2': 'gpt-image',
    'claude code': 'codex', 'claude fable': 'fable',
    'nanobanana pro': 'nanobanana', 'nano banana': 'nanobanana',
    '即梦ai': '即梦', '即梦 4.0': '即梦',
    'comfy ui': 'comfyui',
}

# 过于具体的装饰词检测模式（建议添加通用父类词）
DECORATIVE_PATTERNS = [
    (r'^[\u4e00-\u9fff]{1,3}[\u4e00-\u9fff]*(烟火|圣洁|森林|治愈|侘寂|邵氏)', '设计'),
    (r'^(四句话|三句话|一句话|三步|五步|七步)', '教程'),
    (r'(小白|新手|保姆级|零基础|入门)', '教程'),
    (r'^\d+[个条种]', '合集'),
]

def load_cards(cards_dir):
    cards = {}
    for f in sorted(os.listdir(cards_dir)):
        if not f.startswith('km_') or not f.endswith('.md'): continue
        path = os.path.join(cards_dir, f)
        with open(path, encoding='utf-8') as fp:
            content = fp.read()
        kws = []
        m = re.search(r'##\s*关键词\s*\n(.*?)(?=\n##|\n---|\Z)', content, re.DOTALL | re.IGNORECASE)
        if m:
            kws = [k.strip().lower() for k in re.split(r'[、，,\n]', m.group(1)) if k.strip() and len(k.strip()) >= 2]
        cards[f] = {'path': path, 'content': content, 'keywords': kws}
    return cards

def detect_issues(cards):
    """检测三类问题并生成建议。"""
    all_kws = Counter()
    kw_to_cards = defaultdict(set)
    for f, card in cards.items():
        for kw in card['keywords']:
            all_kws[kw] += 1
            kw_to_cards[kw].add(f)

    issues = []

    # Type 1: 工具名变体
    for f, card in cards.items():
        for kw in card['keywords']:
            for variant, canonical in TOOL_CANONICAL.items():
                if kw.lower() == variant.lower() or variant.lower() in kw.lower():
                    if canonical.lower() not in [k.lower() for k in card['keywords']]:
                        issues.append({
                            'file': f, 'type': '工具名变体',
                            'keyword': kw, 'suggestion': f'添加 `{canonical}`',
                            'severity': '🟡'
                        })

    # Type 2: 仅使用1次的长关键词（≥6字符）
    for kw, cnt in all_kws.items():
        if cnt == 1 and len(kw) >= 6:
            cards_with = kw_to_cards[kw]
            for f in cards_with:
                # 检查是否匹配装饰模式
                for pattern, parent in DECORATIVE_PATTERNS:
                    if re.match(pattern, kw):
                        existing = [k for k in cards[f]['keywords'] if k.lower() == parent.lower()]
                        if not existing:
                            issues.append({
                                'file': f, 'type': '单卡词→缺通用词',
                                'keyword': kw, 'suggestion': f'添加 `{parent}`',
                                'severity': '🟢'
                            })
                        break

    return issues, all_kws

def apply_fixes(cards, issues):
    """应用建议到卡片文件。"""
    file_fixes = defaultdict(list)
    for issue in issues:
        f = issue['file']
        if issue['type'] in ('工具名变体', '单卡词→缺通用词'):
            new_kw = issue['suggestion'].replace('添加 `', '').replace('`', '')
            file_fixes[f].append(new_kw)

    updated = 0
    for f, new_kws in file_fixes.items():
        card = cards[f]
        existing_kws = set(k.lower() for k in card['keywords'])
        to_add = [k for k in new_kws if k.lower() not in existing_kws]
        if not to_add:
            continue

        old_line = None
        for line in card['content'].split('\n'):
            if re.match(r'^##\s*关键词', line):
                old_line = line
                break
        if not old_line:
            continue

        new_line = old_line.rstrip() + '、' + '、'.join(to_add)
        new_content = card['content'].replace(old_line, new_line, 1)

        with open(card['path'], 'w', encoding='utf-8') as fp:
            fp.write(new_content)
        updated += 1

    return updated

def main():
    args = sys.argv[1:]
    try:
        cards_dir = args[args.index('--cards-dir') + 1]
    except (ValueError, IndexError):
        print("Usage: normalize_keywords.py --cards-dir DIR [--apply]")
        sys.exit(1)

    apply_mode = '--apply' in args
    cards = load_cards(cards_dir)
    issues, all_kws = detect_issues(cards)

    print(f'扫描: {len(cards)} 张卡片 | {len(all_kws)} 个唯一关键词')
    print(f'发现问题: {len(issues)} 条')
    print()

    by_severity = defaultdict(list)
    for issue in issues:
        by_severity[issue['severity']].append(issue)

    for sev in ['🟡', '🟢']:
        items = by_severity[sev]
        if not items: continue
        print(f'## {sev} {len(items)} 条')
        for issue in items:
            print(f'  [{issue["type"]}] {issue["file"]}: `{issue["keyword"]}` → {issue["suggestion"]}')
        print()

    if apply_mode and issues:
        updated = apply_fixes(cards, issues)
        print(f'✅ 已修复: {updated} 张卡片')

if __name__ == '__main__':
    main()
