#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Optional CNAS modules, with immutable inputs and portable case history. MIT."""
import argparse
import copy
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import uuid

import cnas_audit as core
from module_common import MODULES, inside, local_path, sha256, validate_workflow, tree_manifest, reject_links


class Context(dict):
    """Mapping and attribute interface for host-independent module adapters."""
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)


def adapter_for(module, action=None):
    if module not in MODULES:
        raise ValueError('Unknown module: ' + str(module))
    adapter = importlib.import_module(MODULES[module])
    if action is not None and action not in adapter.ACTIONS:
        raise ValueError('Unknown action: ' + str(action))
    return adapter


def dependencies(module=None, action=None):
    result = {}
    for name in ([module] if module else MODULES):
        adapter = adapter_for(name, action)
        result[name] = {}
        for key, info in adapter.ACTIONS.items():
            if action and action != key:
                continue
            result[name][key] = dict(info, available={dep: importlib.util.find_spec(dep) is not None
                                                     for dep in info['dependencies']})
    return result


def no_credentials(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if str(key).lower() in {'api_key', 'apikey', 'password', 'secret', 'access_token', 'authorization_header'} and item:
                raise ValueError('Credentials must be supplied by the host/environment, never in persisted requests')
            no_credentials(item)
    elif isinstance(value, list):
        for item in value:
            no_credentials(item)


def resolve_inputs(values, base, directory, runs, aliases):
    if not isinstance(values, dict):
        raise ValueError('inputs must be an object')
    result, upstream = {}, []
    for name, value in values.items():
        if isinstance(value, dict):
            rid = aliases.get(value.get('run'), value.get('run'))
            candidates = [r for r in runs if r['id'] == rid]
            if len(candidates) != 1 or candidates[0]['status'] == 'failed':
                raise ValueError('Unknown/failed upstream run: ' + str(rid))
            old = candidates[0]
            if 'role' in value:
                matches = [a['path'] for a in old['artifacts'] if a['role'] == value['role']]
            elif 'input' in value:
                matches = [old['request']['inputs'].get(value['input'])]
            else:
                raise ValueError('Input reference requires role or input')
            if len(matches) != 1 or not matches[0]:
                raise ValueError('Input reference is absent or ambiguous')
            path = local_path(directory, matches[0])
            upstream.append(rid)
        elif isinstance(value, str) and value:
            path = Path(value).expanduser()
            path = base / path if not path.is_absolute() else path
            reject_links(path)
            path = path.resolve()
        else:
            raise ValueError('Each input must be a path or {run, role/input} reference')
        if not path.exists() or path.is_symlink():
            raise ValueError('Input is missing or is a symbolic link: ' + str(name))
        if inside(path, core.SKILL_ROOT):
            raise ValueError('Business inputs must be outside the shared skill')
        result[name] = path
    return result, upstream


def snapshot_input(name, source, directory):
    is_dir = source.is_dir()
    manifest = tree_manifest(source) if is_dir else None
    fingerprint = core.digest(manifest) if is_dir else sha256(source)
    target = directory / 'inputs' / fingerprint / source.name
    if is_dir:
        target.mkdir(parents=True, exist_ok=True)
        for entry in manifest:
            dest = local_path(target, entry['path'])
            origin = local_path(source, entry['path'])
            if not dest.exists():
                core.atomic_bytes(dest, origin.read_bytes())
            if sha256(dest) != entry['sha256']:
                raise ValueError('Input snapshot copy mismatch')
        if tree_manifest(target) != manifest:
            raise ValueError('Directory snapshot differs from source')
    else:
        if not target.exists():
            core.atomic_bytes(target, source.read_bytes())
        if sha256(target) != fingerprint:
            raise ValueError('Input snapshot copy mismatch')
    relative = target.relative_to(directory).as_posix()
    return target, {'name': name, 'path': relative, 'kind': 'directory' if is_dir else 'file',
                    'sha256': fingerprint, 'original_name': source.name}, manifest


def basis_callback(directory, case, corpus, selections, used):
    def choose(code, version=None, revision=None):
        selected = [x for x in selections if x.get('document') == code]
        if len(selected) > 1:
            raise ValueError('Select one edition per document for a module run')
        selection = selected[0] if selected else {}
        for key, value in [('version', version), ('revision', revision)]:
            if value and selection.get(key) and value != selection[key]:
                raise ValueError('Module basis conflicts with explicit request selection')
        version = version or selection.get('version')
        revision = revision or selection.get('revision')
        pinned = [s['index_entry'] for s in case['snapshots'] if s['index_entry']['code'] == code
                  and (version is None or s['index_entry']['version'] == version)
                  and (revision is None or s['index_entry']['revision'] == revision)]
        if pinned:
            entry = core.select_entry(pinned)
            doc, entry = core.pin_document(directory, case, None, entry)
        else:
            if not version:
                raise ValueError('First use requires an explicitly selected basis version: ' + code)
            doc, entry = core.choose_with_case(corpus, argparse.Namespace(document=code, version=version, revision=revision), directory, case)
        metadata = doc['document']
        if metadata.get('effective_date') and case.get('assessment_date') and metadata['effective_date'] > case['assessment_date']:
            raise ValueError('Selected basis takes effect after the assessment date')
        provenance = {key: metadata.get(key) for key in ['doc_id', 'code', 'version', 'revision', 'effective_date']}
        provenance.update(source_sha256=doc['source']['sha256'], json_sha256=entry['sha256'])
        if provenance not in used:
            used.append(provenance)
        return {'document': doc, 'index_entry': entry, 'provenance': provenance}
    return choose


def portable_value(value, directory, paths):
    if isinstance(value, str):
        for old, new in paths.items():
            if value == old:
                return new
        try:
            if Path(value).is_absolute() and inside(value, directory):
                return Path(value).resolve().relative_to(directory).as_posix()
        except (ValueError, OSError):
            pass
        return value
    if isinstance(value, list):
        return [portable_value(v, directory, paths) for v in value]
    if isinstance(value, dict):
        return {k: portable_value(v, directory, paths) for k, v in value.items()}
    return value


def run_request(case_dir, request, request_base=None, corpus=None, aliases=None):
    no_credentials(request)
    if not isinstance(request, dict):
        raise ValueError('Request must be an object')
    module, action = request.get('module'), request.get('action')
    adapter = adapter_for(module, action)
    for key in ['options', 'authorization']:
        if key in request and not isinstance(request[key], dict):
            raise ValueError(key + ' must be an object')
    base = Path(request_base or '.').resolve()
    with core.case_lock(case_dir) as directory:
        case, unused = core.read_case(directory)
        workflow = case.setdefault('workflow', {'schema_version': '1.0.0', 'runs': []})
        sources, upstream = resolve_inputs(request.get('inputs', {}), base, directory, workflow['runs'], aliases or {})
        missing = [key for key in adapter.ACTIONS[action]['inputs'] if key not in sources]
        if missing:
            raise ValueError('Missing inputs: ' + ', '.join(missing))
        explicit_upstream = request.get('upstream_runs', [])
        if not isinstance(explicit_upstream, list):
            raise ValueError('upstream_runs must be a list')
        known = {r['id'] for r in workflow['runs']}
        for rid in explicit_upstream:
            rid = (aliases or {}).get(rid, rid)
            if rid not in known:
                raise ValueError('Unknown upstream run')
            upstream.append(rid)
        token = uuid.uuid4().hex[:12]
        run_id = case['case_id'] + ':M' + token
        output = directory / 'artifacts' / module / token / '文审输出'
        for source in sources.values():
            if source.is_dir() and inside(output, source):
                raise ValueError('Output cannot be inside an input directory')
        effective, input_records, before, pathmap = {}, [], {}, {}
        if module == 'standards' and 'ocr_config' in sources:
            from modules.standards.paddleocr_mcp_client import _config
            config = json.loads(sources['ocr_config'].read_text(encoding='utf-8-sig'))
            no_credentials(config)
            _config(config)
        for name, source in sources.items():
            dest, item, manifest = snapshot_input(name, source, directory)
            input_records.append(item)
            effective[name] = str(dest)
            before[name] = manifest if manifest is not None else item['sha256']
            pathmap[str(source)] = item['path']
            pathmap[str(dest)] = item['path']
        if module == 'standards' and action in {'rename_preview', 'rename_apply'}:
            folder = sources['folder']
            if inside(folder, directory) or inside(directory, folder):
                raise ValueError('Rename requires an explicitly selected source folder outside the case')
            effective['folder'] = str(folder)
        selections = request.get('basis', [])
        if not isinstance(selections, list) or not all(isinstance(x, dict) for x in selections):
            raise ValueError('basis must be a list of edition selections')
        used = []
        previous = copy.deepcopy(workflow['runs'])
        for old in previous:
            for artifact in old['artifacts']:
                artifact['relative_path'] = artifact['path']
                artifact['path'] = str(local_path(directory, artifact['path']))
        context = Context(skill_dir=str(core.SKILL_ROOT), case_dir=str(directory), output_dir=str(output),
                          assessment_date=case.get('assessment_date') or '', reviewer=request.get('reviewer', ''),
                          basis=basis_callback(directory, case, corpus, selections, used), previous_runs=previous)
        active = copy.deepcopy(request)
        active['inputs'] = effective
        error = None
        output.mkdir(parents=True, exist_ok=False)
        try:
            deps = dependencies(module, action)[module][action]['available']
            if not all(deps.values()):
                result = dict(status='blocked', stage=module + '.' + action, artifacts=[], summary={}, trace=[],
                              gates=[dict(id='optional_dependencies', passed=False, detail=deps)],
                              unresolved=['Missing optional packages: ' + ', '.join(k for k, v in deps.items() if not v)])
            else:
                result = adapter.run(action, active, context)
            if not isinstance(result, dict) or result.get('status') not in {'completed', 'needs_review', 'blocked'}:
                raise ValueError('Adapter returned an invalid module result')
            for key, kind in [('artifacts', list), ('summary', dict), ('trace', list), ('unresolved', list), ('gates', list)]:
                if not isinstance(result.get(key), kind):
                    raise ValueError('Invalid module result field: ' + key)
            if result.get('stage') != module + '.' + action:
                raise ValueError('Module result has wrong stage')
        except Exception as exc:
            error = str(exc)
            result = dict(status='failed', stage=module + '.' + action, artifacts=[], summary={}, trace=[], gates=[], unresolved=[error])
        # Both source and snapshot are checked, even when an adapter failed.
        for name, source in sources.items():
            try:
                actual = tree_manifest(source) if source.is_dir() else sha256(source)
                expected = before[name]
                rename = module == 'standards' and action == 'rename_apply' and name == 'folder' and request.get('authorization', {}).get('rename_sources') is True
                unchanged = sorted(x['sha256'] for x in actual) == sorted(x['sha256'] for x in expected) if rename else actual == expected
                if not unchanged:
                    raise ValueError('Source content changed during module run: ' + name)
                snap = local_path(directory, next(x['path'] for x in input_records if x['name'] == name))
                if (tree_manifest(snap) if snap.is_dir() else sha256(snap)) != expected:
                    raise ValueError('Input snapshot changed during module run: ' + name)
            except Exception as exc:
                error = str(exc)
                result['status'] = 'failed'
                result['unresolved'].append(error)
        roles = {}
        try:
            for artifact in result['artifacts']:
                path = Path(artifact['path']).resolve()
                if not inside(path, output) or not path.is_file() or path.is_symlink():
                    raise ValueError('Artifact escaped module output')
                roles[path] = artifact.get('role', 'auxiliary')
        except Exception as exc:
            error = str(exc)
            result['status'] = 'failed'
            result['unresolved'].append(error)
            roles = {}
        artifacts = []
        try:
            for entry in tree_manifest(output):
                path = local_path(output, entry['path'])
                artifacts.append(dict(path=path.relative_to(directory).as_posix(), role=roles.get(path, 'auxiliary'), sha256=entry['sha256']))
        except Exception as exc:
            artifacts = []
            error = str(exc)
            result['status'] = 'failed'
            result['unresolved'].append('Output inventory failed: ' + error)
        stored_request = copy.deepcopy(request)
        stored_request['inputs'] = {x['name']: x['path'] for x in input_records}
        metadata = portable_value({k: v for k, v in result.items() if k != 'artifacts'}, directory, pathmap)
        metadata.update(id=run_id, module=module, action=action, reviewer=context.reviewer,
                        at=core.utcnow(), request=stored_request, inputs=input_records, artifacts=artifacts,
                        upstream_runs=sorted(set(upstream)), basis=used)
        workflow['runs'].append(metadata)
        core.history_event(case, 'module_run', details={'run': copy.deepcopy(metadata)})
        validate_workflow(case, directory)
        core.save_case(directory, case)
        return {'case_id': case['case_id'], 'run': metadata, 'technical_error': error}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    core_commands = {'catalog', 'lookup', 'related', 'corpus-validate', 'case-init', 'case-record', 'case-transition', 'case-validate', 'report'}
    if argv and argv[0] in core_commands:
        return core.main(argv)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.epilog = 'Also accepts core commands: ' + ', '.join(sorted(core_commands)) + '. Use COMMAND --help.'
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('list'); p.add_argument('--module'); p.add_argument('--action')
    p = sub.add_parser('validate'); p.add_argument('--case-dir', required=True)
    for command in ['run', 'pipeline']:
        p = sub.add_parser(command)
        p.add_argument('--case-dir', required=True); p.add_argument('--request', required=True); p.add_argument('--corpus')
    args = parser.parse_args(argv)
    try:
        if args.command == 'list':
            result = dependencies(args.module, args.action)
        elif args.command == 'validate':
            with core.case_lock(args.case_dir) as directory:
                case, unused = core.read_case(directory)
                result = validate_workflow(case, directory)
        else:
            path = Path(args.request).resolve()
            request = json.loads(path.read_text(encoding='utf-8-sig'))
            if args.command == 'run':
                result = run_request(args.case_dir, request, path.parent, args.corpus)
            else:
                steps = request.get('steps', [])
                if not steps or not isinstance(steps, list):
                    raise ValueError('Pipeline requires nonempty steps')
                result, aliases = {'steps': [], 'stopped': False}, {}
                for step in steps:
                    if not isinstance(step, dict) or not step.get('id') or step['id'] in aliases:
                        raise ValueError('Pipeline step IDs must be unique')
                    item = run_request(args.case_dir, step['request'], path.parent, args.corpus, aliases)
                    result['steps'].append(item)
                    aliases[step['id']] = item['run']['id']
                    if item['run']['status'] != 'completed':
                        result['stopped'] = True
                        break
        print(json.dumps({'ok': True, 'result': result}, ensure_ascii=False, indent=2))
        failed = isinstance(result, dict) and (result.get('technical_error') or any(x.get('technical_error') for x in result.get('steps', [])))
        return 2 if failed else 0
    except (core.AuditError, OSError, ValueError, TypeError, KeyError, AttributeError, ImportError) as exc:
        print(json.dumps({'ok': False, 'error': {'code': getattr(exc, 'code', 'workflow_error'), 'message': str(exc)}}, ensure_ascii=False, indent=2))
        return 2


if __name__ == '__main__':
    sys.exit(main())
