# -*- coding: utf-8 -*-
"""Frozen 1.1.0 workflow adapter. Importing this file needs only the stdlib."""
import copy
from pathlib import Path

from ._io import canonical_hash, contained, load_json, verify_inventory, write_json

ACTIONS = {
    'inventory': dict(description='盘点全部物理文件并提取原生文本；扫描件保持待OCR', dependencies=['fitz'], inputs=['folder']),
    'split': dict(description='按源hash分段PDF并复用校验通过的缓存', dependencies=['fitz'], inputs=['primary']),
    'ocr_import': dict(description='导入实际宿主OCR调用结果，核查页段、源hash与PaddleOCR偏好', dependencies=[], inputs=['inventory', 'ocr_results']),
    'ocr_client': dict(description='显式配置通用HTTP/MCP客户端进行分段OCR；不读取Codex配置', dependencies=['fitz'], inputs=['inventory', 'ocr_config']),
    'build': dict(description='硬校验Agent核对records并输出覆盖/多方法/质量工作簿', dependencies=['openpyxl'], inputs=['inventory', 'records']),
    'rename_preview': dict(description='按已核实编号题名预览安全命名及授权范围hash', dependencies=[], inputs=['folder', 'inventory', 'records']),
    'rename_apply': dict(description='授权且预览hash、范围、源hash、冲突复检通过后重命名', dependencies=[], inputs=['folder', 'inventory', 'records', 'plan']),
}


def _outside(output, root):
    try:
        output.relative_to(root)
    except ValueError:
        return
    raise ValueError('Module output must be outside skill and source folder: %s' % root)


def _trace(inventory, reviewer, records=None):
    if records is not None:
        return [dict(reviewer=reviewer,
                     source_file=str(contained(inventory['source_root'], row['source_file'])),
                     source_sheet='records', source_row=row.get('source_row', i + 1),
                     json_pointer='/records/%d' % i,
                     evidence_refs=[row.get('evidence', '')]) for i, row in enumerate(records)]
    return [dict(reviewer=reviewer, source_file=str(contained(inventory['source_root'], x['relative_path'])),
                 source_sheet='', source_row=0, json_pointer='/files/%d' % i,
                 evidence_refs=['sha256:' + x['sha256']]) for i, x in enumerate(inventory['files'])]


def run(action, request, context):
    if action not in ACTIONS:
        raise ValueError('Unknown standards action: %s' % action)
    inputs, options = request.get('inputs', {}), request.get('options', {})
    for name in ACTIONS[action]['inputs']:
        if not inputs.get(name) or not Path(inputs[name]).exists():
            raise ValueError('standards.%s requires existing inputs.%s' % (action, name))
    out = Path(context['output_dir']).resolve()
    if not out.name.endswith('文审输出'):
        raise ValueError('Standards output_dir must end with 文审输出')
    _outside(out, Path(context['skill_dir']).resolve())
    if inputs.get('folder'):
        _outside(out, Path(inputs['folder']).resolve())
    for path in inputs.values():
        if isinstance(path, str) and out == Path(path).resolve():
            raise ValueError('Module output may not overwrite an input')
    out.mkdir(parents=True, exist_ok=True)
    artifacts, gates, unresolved, trace, summary = [], [], [], [], {}
    status = 'completed'
    reviewer = context.get('reviewer') or request.get('reviewer', '')

    def artifact(name, value, role):
        path = write_json(out / name, value)
        artifacts.append(dict(path=path, role=role))
        return path

    inventory = load_json(inputs['inventory']) if inputs.get('inventory') else None
    if inventory:
        # Explicit selection wins after migration; file hashes, never former drive letters,
        # establish physical identity. Root may snapshot the selected folder for read-only runs.
        if inputs.get('folder'):
            inventory = copy.deepcopy(inventory)
            inventory['source_root'] = str(Path(inputs['folder']).resolve())
        if inputs.get('cache_folder'):
            from .paddleocr_mcp_client import relocate_caches
            inventory = relocate_caches(inventory, inputs['cache_folder'])
        _outside(out, Path(inventory['source_root']).resolve())
    if action == 'inventory':
        from .inventory_documents import inventory_folder
        inventory = inventory_folder(inputs['folder'], out)
        artifact('inventory.json', inventory, 'standard_inventory')
        pending = [x['relative_path'] for x in inventory['files'] if x['status'] != 'ok']
        summary = dict(file_count=inventory['file_count'], pending_files=pending,
                       native_success_files=sum(x['status'] == 'ok' for x in inventory['files']),
                       coverage_passed=False, semantic_analysis='Agent-reviewed records not yet supplied')
        gates.append(dict(id='searchable_source_text', passed=bool(inventory['files']) and not pending,
                          detail='每个物理文件均独立盘点；待OCR、转换、加密、空文件不能标成功'))
        status = 'needs_review' if pending or not inventory['files'] else 'completed'
        unresolved = pending
        trace = _trace(inventory, reviewer)
    elif action == 'split':
        from .split_pdf_chunks import split_pdf
        manifest = split_pdf(inputs['primary'], out, options.get('chunk_size', 10))
        artifacts.append(dict(path=manifest['manifest_path'], role='ocr_chunk_manifest'))
        for chunk in manifest['chunks']:
            artifacts.append(dict(path=chunk['path'], role='ocr_pdf_chunk'))
        summary = dict(page_count=manifest['page_count'], chunk_count=len(manifest['chunks']),
                       source_sha256=manifest['source_sha256'], ocr_performed=False)
    elif action in {'ocr_import', 'ocr_client'}:
        from .paddleocr_mcp_client import import_results, configured_client
        if action == 'ocr_import':
            inventory = import_results(inventory, load_json(inputs['ocr_results']), out, options)
        else:
            inventory = configured_client(inventory, load_json(inputs['ocr_config']), out, options)
        artifact('inventory_ocr.json', inventory, 'standard_inventory')
        pending = [x['relative_path'] for x in inventory['files'] if x.get('status') != 'ok' or x.get('needs_ocr')]
        summary = dict(file_count=len(inventory['files']), pending_files=pending,
                       actual_modes=sorted({x.get('extraction_mode', '') for x in inventory['files']}),
                       successful_segments=sum(len(x.get('ocr_segments', {})) for x in inventory['files']),
                       failed_attempts=sum(x['status'] != 'ok' for x in inventory.get('ocr_attempts', [])))
        gates.append(dict(id='ocr_complete', passed=bool(inventory['files']) and not pending,
                          detail='源hash、真实工具证据、非空页段、全页覆盖均须通过'))
        status = 'needs_review' if pending else 'completed'
        unresolved = pending
        trace = _trace(inventory, reviewer)
    elif action == 'build':
        from .build_standard_excel import build_workbook
        records = load_json(inputs['records'])
        summary = build_workbook(inventory, records, out / '检测标准文本_结构化信息提取.xlsx')
        summary['inventory_sha256'] = canonical_hash(inventory)
        summary['records_sha256'] = canonical_hash(records)
        partial = request.get('authorization', {}).get('allow_partial_coverage') is True
        summary['partial_coverage_authorized'] = partial
        artifacts.append(dict(path=str(out / '检测标准文本_结构化信息提取.xlsx'), role='standard_workbook'))
        artifact('coverage.json', summary, 'standards_coverage')
        artifact('records_validated.json', records, 'standard_records')
        gates.extend([dict(id='physical_text_record_coverage', passed=summary['coverage_passed'],
                           detail='每个物理文件存在且源hash未变、可检索原文完整、核心字段及记录覆盖通过'),
                      dict(id='mechanical_quality_review', passed=not summary['warnings'],
                           detail='多方法、重复记录及待核原文仅作机械疑点，不自动形成不符合')])
        unresolved = ([dict(kind=key, files=summary[key]) for key in
                       ['missing_files', 'changed_files', 'uncovered_files', 'pending_files'] if summary[key]]
                      + summary['warnings'])
        status = ('needs_review' if partial else 'blocked') if not summary['coverage_passed'] else (
            'needs_review' if summary['warnings'] else 'completed')
        trace = _trace(inventory, reviewer, records.get('records', []))
    elif action == 'rename_preview':
        from .rename_standard_documents import build_plan
        records = load_json(inputs['records'])
        plan = build_plan(inputs['folder'], inventory, records, options.get('pdf_only', True))
        artifact('rename_plan.json', plan, 'standard_rename_preview')
        summary = dict(plan_sha256=plan['plan_sha256'], source_root=plan['source_root'],
                       rename_count=sum(x['status'] == 'rename' for x in plan['files']),
                       preview_only=True)
        trace = _trace(inventory, reviewer, records['records'])
    elif action == 'rename_apply':
        from .rename_standard_documents import apply_plan, rollback_committed
        records = load_json(inputs['records'])
        inventory, records, mapping = apply_plan(
            inputs['folder'], inventory, records, load_json(inputs['plan']), options.get('plan_sha256'),
            request.get('authorization', {}).get('rename_sources') is True)
        try:
            artifact('inventory_renamed.json', inventory, 'standard_inventory')
            artifact('records_renamed.json', records, 'standard_records')
            artifact('rename_map.json', mapping, 'standard_rename_mapping')
        except Exception:
            rollback_committed(inputs['folder'], mapping)
            for name in ['inventory_renamed.json', 'records_renamed.json', 'rename_map.json']:
                partial = out / name
                if partial.is_file():
                    partial.unlink()
            raise
        summary = dict(rename_count=mapping['renamed_count'], source_root=inventory['source_root'],
                       content_hashes_unchanged=True, plan_sha256=mapping['plan_sha256'])
        gates.append(dict(id='authorized_rename', passed=True,
                          detail='授权、预览hash、目录范围、内容hash及目标冲突复检通过'))
        trace = _trace(inventory, reviewer, records['records'])
    if inventory is not None and action not in {'build'}:
        missing, changed = verify_inventory(inventory)
        if missing or changed:
            raise ValueError('Physical source changed during action: %s / %s' % (missing, changed))
    # Include cache/chunk evidence in the case artifact register, not only paths inside JSON.
    registered = {str(Path(x['path']).resolve()) for x in artifacts}
    for path in sorted(p for p in out.rglob('*') if p.is_file()):
        if str(path.resolve()) in registered:
            continue
        name = path.relative_to(out).as_posix()
        role = ('native_text' if name.startswith('native_text/') else
                'ocr_cache' if name.startswith('ocr_cache/') else
                'ocr_text' if name.startswith('ocr_text/') else
                'ocr_chunk' if name.startswith('chunks/') else 'standards_evidence')
        artifacts.append(dict(path=str(path.resolve()), role=role))
    return dict(status=status, stage='standards.' + action, artifacts=artifacts,
                summary=summary, trace=trace, unresolved=unresolved, gates=gates)
