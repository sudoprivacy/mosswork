# -*- coding: utf-8 -*-
"""Render a styled CNAS audit workbook from a JSON exchange file."""

import argparse
import json
import math
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


PREFERRED_ISSUE_HEADERS = [
    "编号", "等级", "问题类别", "主表源行", "JSON Pointer/记录定位", "检测对象", "项目/参数",
    "标准名称", "标准号", "字段", "原始值摘要", "标准文本证据", "标准文本关键仪器设备",
    "问题说明", "修订建议", "置信度",
]


def clean(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False)
    return value


def headers_for(records, preferred=None):
    preferred = preferred or []
    present = []
    for key in preferred:
        if any(key in record for record in records):
            present.append(key)
    for record in records:
        for key in record:
            if key not in present:
                present.append(key)
    return present


def apply_table_style(sheet, widths=None, level_header="等级"):
    thin = Side(style="thin", color="B7B7B7")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.font = Font(name="微软雅黑", color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border
    header_map = {cell.value: cell.column for cell in sheet[1]}
    level_column = header_map.get(level_header)
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = border
        if level_column:
            cell = row[level_column - 1]
            fill = {
                "致命错误": "990000", "严重错误": "C00000", "一般错误": "F4CCCC",
                "警告": "FFF2CC", "待人工核验": "D9EAF7", "优化建议": "E2F0D9",
            }.get(str(cell.value or ""))
            if fill:
                cell.fill = PatternFill("solid", fgColor=fill)
            if str(cell.value or "") in {"致命错误", "严重错误"}:
                cell.font = Font(name="微软雅黑", color="FFFFFF", bold=True)
    if widths:
        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width
    else:
        for index in range(1, sheet.max_column + 1):
            sheet.column_dimensions[get_column_letter(index)].width = 24
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    sheet.row_dimensions[1].height = 32
    for row in sheet.iter_rows(min_row=2):
        line_count = 1
        for cell in row:
            width = sheet.column_dimensions[cell.column_letter].width or 24
            lines = str(cell.value or '').splitlines() or ['']
            estimated = sum(max(1, math.ceil(sum(2 if ord(ch) > 127 else 1 for ch in line) / max(4, width - 2))) for line in lines)
            line_count = max(line_count, estimated)
        sheet.row_dimensions[row[0].row].height = min(409, max(30, (line_count + 1) * 15))


def write_records_sheet(workbook, title, records, preferred=None, widths=None):
    sheet = workbook.create_sheet(title)
    headers = headers_for(records, preferred)
    if not headers:
        headers = ["说明"]
        records = [{"说明": "无记录"}]
    sheet.append(headers)
    for record in records:
        sheet.append([clean(record.get(header, "")) for header in headers])
    apply_table_style(sheet, widths)
    return sheet


def normalize_pairs(value):
    result = []
    for item in value or []:
        if isinstance(item, dict):
            if "项目" in item and "说明" in item:
                result.append([item["项目"], item["说明"]])
            elif len(item) == 1:
                key = next(iter(item))
                result.append([key, item[key]])
            else:
                result.append([json.dumps(item, ensure_ascii=False), ""])
        elif isinstance(item, (list, tuple)):
            result.append(list(item[:2]) + [""] * max(0, 2 - len(item)))
        else:
            result.append([str(item), ""])
    return result


def write_pairs_sheet(workbook, title, rows, headers):
    sheet = workbook.create_sheet(title)
    sheet.append(headers)
    for row in normalize_pairs(rows):
        sheet.append(row)
    apply_table_style(sheet, [34, 120], level_header="")
    return sheet

