# -*- coding: utf-8 -*-
"""Derive a single pinned PT model from the owning corpus at run time."""
import hashlib
import json
import re
from datetime import date
from pathlib import Path


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def compact(value):
    return re.sub(r'\s+', '', str(value or ''))


def _entry(field, subfield, frequency, refs, raw=None):
    field, subfield = compact(field), compact(subfield)
    field = field if field.endswith('领域') else field + '领域'
    subfield = subfield if subfield.endswith('子领域') else subfield + '子领域'
    frequency = compact(frequency)
    match = re.fullmatch(r'(\d+)次[/／](\d+)年', frequency)
    return {'value': field + '-' + subfield, 'domain': field, 'subdomain': subfield,
            'frequency': frequency, 'times_per_period': int(match.group(1)) if match else None,
            'period_years': int(match.group(2)) if match else None,
            'evidence_refs': refs, 'raw_cells': raw}


def derive(bundle):
    doc = bundle['document']
    entries, previous_field, previous_columns = [], '', None
    for ti, table in enumerate(doc.get('tables', [])):
        columns = [compact(v) for v in table.get('columns', [])]
        if len(columns) != 3 or columns[1:] != ['子领域', '最低参加频次']:
            continue
        if columns != previous_columns:
            previous_field = ''
        previous_columns = columns
        for ri, row in enumerate(table.get('rows', [])):
            cells = sorted(row.get('cells', []), key=lambda c: c.get('column', 0))
            raw = [c.get('text', '') for c in cells]
            if len(raw) != 3:
                raise ValueError('RL02 频次表存在非三列行，须核对原始 JSON: /tables/%d/rows/%d' % (ti, ri))
            field, subfield, frequency = map(compact, raw)
            if subfield == '子领域' and frequency == '最低参加频次':
                continue
            previous_field = field or previous_field
            if not previous_field or not subfield or not frequency:
                raise ValueError('RL02 频次行不完整: /tables/%d/rows/%d' % (ti, ri))
            refs = [{'doc_id': bundle['provenance']['doc_id'], 'table_id': table.get('id'),
                     'json_pointer': '/tables/%d/rows/%d' % (ti, ri),
                     'pages': table.get('pages', []), 'block_refs': table.get('block_refs', [])}]
            entries.append(_entry(previous_field, subfield, frequency, refs, raw))
    if not entries:
        raise ValueError('选定 RL02 JSON 未含可追溯频次表，不能使用内置副本或猜测')
    values = [e['value'] for e in entries]
    if len(values) != len(set(values)):
        raise ValueError('选定 RL02 存在重复领域/子领域，须显式消歧')
    # Conditions remain attached to the runtime model; never ship a second corpus.
    conditions = []
    blocks = {b['id']: b for b in doc.get('blocks', [])}
    for ci, clause in enumerate(doc.get('clauses', [])):
        number = str(clause.get('official_number') or '')
        if number.startswith('4') or number.startswith('B') or '附录B' in clause.get('title', ''):
            conditions.append({'official_number': number, 'title': clause.get('title', ''),
                               'json_pointer': '/clauses/%d' % ci,
                               'blocks': [blocks[b] for b in clause.get('own_block_refs', clause.get('block_refs', [])) if b in blocks]})
    return entries, conditions


def select_model(request, context):
    options = request.get('options', {})
    selections = [b for b in request.get('basis', []) if b.get('document') == 'CNAS-RL02']
    if len(selections) > 1:
        raise ValueError('PT 每次只能选择一个 CNAS-RL02 版本')
    selected = selections[0] if selections else {}
    version = options.get('basis_version') or selected.get('version')
    revision = options.get('basis_revision') or selected.get('revision')
    if selected.get('version') and version != selected['version']:
        raise ValueError('options.basis_version 与 request.basis 版本不一致')
    if selected.get('revision') and revision != selected['revision']:
        raise ValueError('options.basis_revision 与 request.basis 修订不一致')
    bundle = context.basis('CNAS-RL02', version, revision)
    provenance = bundle['provenance']
    if provenance.get('code') != 'CNAS-RL02' or (version and provenance.get('version') != version) or (revision and provenance.get('revision') != revision):
        raise ValueError('basis 回调未返回选定的 CNAS-RL02 版本')
    for key in ('source_sha256', 'json_sha256'):
        if not re.fullmatch('[0-9a-fA-F]{64}', str(provenance.get(key, ''))):
            raise ValueError('RL02 缺少完整 %s' % key)
    cutoff = options.get('as_of') or context.assessment_date
    if not cutoff:
        raise ValueError('PT 需要实际评审截止日期 assessment_date/as_of')
    cutoff_date = date.fromisoformat(cutoff)
    effective = provenance.get('effective_date')
    if not effective or date.fromisoformat(effective) > cutoff_date:
        raise ValueError('RL02 实施日期缺失或晚于评审截止日期')
    entries, conditions = derive(bundle)
    model = {'schema_version': '1.1.0', 'basis': provenance, 'allowed_domains': entries,
             'conditions': conditions, 'project_basis': None}
    path = request.get('inputs', {}).get('project_basis')
    if path:
        if options.get('project_basis_selected') is not True:
            raise ValueError('项目依据须由用户显式选择 project_basis_selected=true；不得按年份自动采用')
        project = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        required = ('code', 'version', 'effective_date', 'source_sha256', 'rows')
        if any(not project.get(k) for k in required):
            raise ValueError('项目依据缺少编号/版本/实施日期/源 SHA256/频次行')
        if not re.fullmatch('[0-9a-fA-F]{64}', str(project['source_sha256'])):
            raise ValueError('项目依据 source_sha256 必须为完整 SHA256')
        project_source = request.get('inputs', {}).get('project_basis_source')
        if not project_source or not Path(project_source).is_file() or file_hash(project_source) != project['source_sha256'].lower():
            raise ValueError('项目依据必须附 project_basis_source 实际源文件且 SHA256 匹配')
        if date.fromisoformat(project['effective_date']) > cutoff_date:
            raise ValueError('项目依据实施日期晚于评审截止日期')
        selected_rows = []
        for ri, row in enumerate(project['rows']):
            if not row.get('evidence_refs'):
                raise ValueError('项目依据每行须含源定位 evidence_refs')
            entry = _entry(row['domain'], row['subdomain'], row['frequency'], row['evidence_refs'])
            if not entry['times_per_period'] or not entry['period_years']:
                raise ValueError('项目依据频次未能明确解析: 第%d行' % (ri + 1))
            selected_rows.append(entry)
        if len({e['value'] for e in selected_rows}) != len(selected_rows):
            raise ValueError('项目依据包含重复领域')
        model['allowed_domains'] = selected_rows
        model['project_basis'] = {k: v for k, v in project.items() if k != 'rows'}
        model['project_basis']['data_sha256'] = file_hash(path)
    model['basis_fingerprint'] = fingerprint(model)
    return model
