# -*- coding: utf-8 -*-
"""Parameter splitting retained from audit-cnas-pt-frequency."""
def split_items(value):
    if value is None or not str(value).strip():
        return []
    text = str(value).strip()
    opening = {"（": "）", "(": ")", "【": "】", "[": "]", "{": "}"}
    closing = set(opening.values())
    stack, parts, buffer = [], [], []
    index = 0

    def flush():
        item = "".join(buffer).strip()
        buffer.clear()
        if item:
            parts.append(item)

    while index < len(text):
        char = text[index]
        if char in opening:
            stack.append(opening[char])
            buffer.append(char)
            index += 1
        elif char in closing:
            if stack and char == stack[-1]:
                stack.pop()
            buffer.append(char)
            index += 1
        elif not stack and char in "、，,；;":
            flush()
            index += 1
        elif not stack and char.isspace():
            end, contains_linebreak = index, False
            while end < len(text) and text[end].isspace():
                contains_linebreak = contains_linebreak or text[end] in "\r\n"
                end += 1
            whitespace = text[index:end]
            if contains_linebreak or len(whitespace) >= 2:
                flush()
            else:
                buffer.append(" ")
            index = end
        else:
            buffer.append(char)
            index += 1
    flush()
    return parts or [text]

