# -*- coding: utf-8 -*-
"""Render CNAS capability merge and integrity checks as a Word report."""

from datetime import datetime, timedelta, timezone
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Inches


SUMMARY_LABELS = {
    "primary_capability_records": "主表能力记录数",
    "supplement_capability_records": "补充表能力记录数",
    "equipment_master_records": "设备主表记录数",
    "matched_primary_records": "已匹配主表记录数",
    "unmatched_primary_records": "未匹配主表记录数",
    "primary_match_rate": "主表匹配率",
    "primary_records_with_equipment": "已补充设备的主表记录数",
    "equipment_enrichment_rate": "设备信息补充率",
    "records_with_all_equipment_ids_resolved": "设备编号全部解析的记录数",
    "unmatched_supplement_records": "未使用的补充表记录数",
    "records_with_english_clause": "英文条款号非空记录数",
    "records_with_english_limitation": "英文限制说明非空记录数",
    "records": "规范JSON能力记录数",
    "reviewer": "指定评审员",
    "reviewer_records": "指定评审员能力记录数",
}

CHECK_LABELS = {
    "primary_authoritative_content_equal": "主表全部权威字段与设备合并重放一致",
    "records_nonempty": "能力记录非空",
    "json_record_count_equals_primary": "JSON记录数等于主表能力记录数",
    "capability_ids_nonempty": "能力记录ID全部非空",
    "capability_ids_unique": "能力记录ID唯一",
    "equipment_master_ids_unique": "设备主表编号唯一",
    "all_referenced_equipment_ids_resolved": "合并阶段引用的设备编号全部解析",
    "all_equipment_references_resolved": "JSON引用的设备编号全部解析",
    "english_clause_field_present_in_all_records": "所有记录均含英文条款号字段",
    "english_limitation_field_present_in_all_records": "所有记录均含英文限制说明字段",
    "all_chinese_clauses_have_source_english_values": "中文条款号有值时均提取到源表英文值",
    "all_chinese_limitations_have_source_english_values": "中文限制说明有值时均提取到源表英文值",
    "json_records_equal_primary": "JSON记录数与主表记录数一致",
    "english_values_equal_primary": "英文条款号和限制说明与主表一致",
}

ISSUE_LABELS = {
    "duplicate_capability_ids": "重复能力记录ID",
    "duplicate_equipment_ids": "重复设备编号",
    "unresolved_equipment_references": "无法解析的设备编号引用",
    "ambiguous_match_attempts": "存在歧义的匹配候选",
    "unmatched_primary_rows": "未匹配的主表行",
    "unmatched_supplement_rows": "未使用的补充表行",
    "primary_rows_with_chinese_clause_but_no_source_english_clause": "中文条款号有值但源表英文条款号为空的主表行",
    "primary_rows_with_chinese_limitation_but_no_source_english_limitation": "中文限制说明有值但源表英文限制说明为空的主表行",
    "missing_capability_id_indexes": "缺少能力记录ID的JSON索引",
    "missing_clause_en_key_indexes": "缺少英文条款号字段的JSON索引",
    "missing_limitation_en_key_indexes": "缺少英文限制说明字段的JSON索引",
    "chinese_clause_without_source_english_primary_rows": "中文条款号有值但英文条款号为空的主表行",
    "chinese_limitation_without_source_english_primary_rows": "中文限制说明有值但英文限制说明为空的主表行",
}

MATCH_RULE_LABELS = {
    "exact_5_fields": "对象、参数、标准号、标准名称、条款完全一致",
    "exact_5_fields_duplicate_ordinal": "五字段重复组按顺序一一匹配",
    "exact_without_clause": "对象、参数、标准号、标准名称一致",
    "object_parameter_standard": "对象、参数、标准号一致",
    "parameter_standard_method": "参数、标准号、标准名称一致",
    "parameter_standard": "参数、标准号一致",
    "unmatched": "未匹配",
    "matched": "已匹配",
    "matched_by_duplicate_ordinal": "重复组按顺序匹配",
    "matched_duplicate_equivalent": "重复候选的设备及运营信息等价",
    "missing": "缺少匹配状态",
}


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "通过" if value else "未通过"
    return str(value)


def _format_value(key, value):
    if isinstance(value, bool):
        return "通过" if value else "未通过"
    if isinstance(value, float) and "rate" in key:
        return f"{value:.2%}"
    if value is None:
        return "未指定"
    if isinstance(value, (dict, list, tuple)):
        return str(value)
    return str(value)


def _has_content(value):
    if value is None or value is False or value == "":
        return False
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def _set_run_font(run, *, bold=False, color=None, size=10.5):
    run.font.name = "宋体"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)


def _shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), fill)


def _set_cell_text(cell, value, *, bold=False, color=None):
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run(_text(value))
    _set_run_font(run, bold=bold, color=color, size=9.5)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _add_table(document, headers, rows):
    table = document.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    total_width = 6.5
    proportions = ([0.30, 0.70] if len(headers) == 2 else [0.20, 0.62, 0.18] if len(headers) == 3 else [1.0 / len(headers)] * len(headers))
    for col, fraction in zip(table.columns, proportions):
        col.width = Inches(total_width * fraction)
    widths = [Inches(total_width * fraction) for fraction in proportions]
    for cell, width in zip(table.rows[0].cells, widths):
        cell.width = width
    repeat = OxmlElement("w:tblHeader")
    table.rows[0]._tr.get_or_add_trPr().append(repeat)
    for index, header in enumerate(headers):
        _set_cell_text(table.rows[0].cells[index], header, bold=True)
        _shade_cell(table.rows[0].cells[index], "D9EAF7")
    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            cells[index].width = widths[index]
            color = (192, 0, 0) if value == "未通过" else None
            _set_cell_text(cells[index], value, color=color)
    document.add_paragraph().paragraph_format.space_after = Pt(0)
    return table


def _add_heading(document, title, level=1):
    paragraph = document.add_heading(level=level)
    paragraph.paragraph_format.space_before = Pt(6)
    paragraph.paragraph_format.space_after = Pt(3)
    run = paragraph.add_run(title)
    _set_run_font(run, bold=True, size=16 if level == 1 else 12)
    return paragraph


def _issue_rows(value):
    if isinstance(value, dict):
        return [[key, _format_value(key, item)] for key, item in value.items()]
    if isinstance(value, (list, tuple)) and value and all(isinstance(item, dict) for item in value):
        keys = []
        for item in value:
            for key in item:
                if key not in keys:
                    keys.append(key)
        return [keys, [[_format_value(key, item.get(key, "")) for key in keys] for item in value]]
    return None


def _render_issue(document, label, value):
    _add_heading(document, label, level=3)
    structured = _issue_rows(value)
    if isinstance(structured, list) and len(structured) == 2 and structured and isinstance(structured[1], list) and structured[1] and isinstance(structured[1][0], list):
        _add_table(document, structured[0], structured[1])
        return
    if structured:
        _add_table(document, ["项目", "内容"], structured)
        return
    if isinstance(value, (list, tuple, set)):
        values = [str(item) for item in value]
        for start in range(0, len(values), 80):
            paragraph = document.add_paragraph("、".join(values[start:start + 80]))
            paragraph.paragraph_format.space_before = Pt(0)
            paragraph.paragraph_format.space_after = Pt(2)
        return
    paragraph = document.add_paragraph(_format_value("", value))
    paragraph.paragraph_format.space_after = Pt(2)


def _collect_checks(merge_report, validation_result):
    rows = []
    failures = []
    for source, report in (("合并匹配", merge_report), ("独立完整性校验", validation_result)):
        for key, passed in (report or {}).get("integrity_checks", {}).items():
            if not isinstance(passed, bool):
                continue
            label = CHECK_LABELS.get(key, key)
            rows.append([source, label, "通过" if passed else "未通过"])
            if not passed:
                failures.append(label)

    cross_check = (validation_result or {}).get("primary_cross_check")
    if cross_check:
        count_passed = bool(cross_check.get("json_records_equal_primary"))
        english_passed = not cross_check.get("english_value_mismatches", [])
        for key, passed in (
            ("json_records_equal_primary", count_passed),
            ("english_values_equal_primary", english_passed),
        ):
            label = CHECK_LABELS[key]
            rows.append(["主表交叉核对", label, "通过" if passed else "未通过"])
            if not passed:
                failures.append(label)
    return rows, failures


def validation_passed(merge_report=None, validation_result=None):
    rows, failures = _collect_checks(merge_report or {}, validation_result or {})
    return bool(rows) and not failures


def write_validation_report(path, *, merge_report=None, validation_result=None, metadata=None):
    """Write and reopen a human-readable DOCX validation report."""
    path = Path(path)
    if path.suffix.lower() != ".docx":
        raise ValueError("校验报告必须使用 .docx 格式；不再生成独立JSON校验报告")

    merge_report = merge_report or {}
    validation_result = validation_result or {}
    metadata = dict(metadata or {})
    metadata.setdefault("生成时间", datetime.now(timezone(timedelta(hours=8))).isoformat(timespec="seconds"))

    document = Document()
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = section.bottom_margin = Pt(54)
    section.left_margin = section.right_margin = Inches(1)

    normal = document.styles["Normal"]
    normal.font.name = "宋体"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(11)
    for style_name in ("Title", "Heading 1", "Heading 2", "Heading 3"):
        document.styles[style_name].font.color.rgb = RGBColor(0, 0, 0)
    for border in document.styles.element.xpath('.//w:pBdr'):
        border.getparent().remove(border)

    title = document.add_heading(level=0)
    title.alignment = 1
    title_run = title.add_run("检测能力合并与完整性校验报告")
    _set_run_font(title_run, bold=True, size=18)

    _add_heading(document, "一、报告信息")
    info_rows = [[key, _text(value) or "未提供"] for key, value in metadata.items()]
    _add_table(document, ["项目", "内容"], info_rows)

    check_rows, failures = _collect_checks(merge_report, validation_result)
    passed = bool(check_rows) and not failures
    _add_heading(document, "二、校验结论")
    paragraph = document.add_paragraph()
    paragraph.add_run("总体结论：")
    conclusion = paragraph.add_run("通过" if passed else "未通过")
    _set_run_font(conclusion, bold=True, color=(0, 128, 0) if passed else (192, 0, 0), size=11)
    if failures:
        detail = document.add_paragraph("未通过项目：" + "；".join(dict.fromkeys(failures)))
        detail.paragraph_format.space_after = Pt(2)

    _add_heading(document, "三、数据摘要")
    summary_rows = []
    for key, value in merge_report.get("summary", {}).items():
        summary_rows.append([SUMMARY_LABELS.get(key, key), _format_value(key, value)])
    for key in ("records", "equipment_master_records", "reviewer", "reviewer_records"):
        if key in validation_result:
            summary_rows.append([SUMMARY_LABELS.get(key, key), _format_value(key, validation_result[key])])
    _add_table(document, ["指标", "结果"], summary_rows or [["摘要", "无可用数据"]])

    _add_heading(document, "四、完整性检查")
    _add_table(document, ["检查来源", "检查项目", "结果"], check_rows or [["校验", "未生成检查项", "未通过"]])

    match_rows = []
    for key, value in merge_report.get("match_rule_counts", {}).items():
        match_rows.append(["匹配规则", MATCH_RULE_LABELS.get(key, key), value])
    for key, value in validation_result.get("match_status_counts", {}).items():
        match_rows.append(["匹配状态", MATCH_RULE_LABELS.get(key, key), value])
    if match_rows:
        _add_heading(document, "五、匹配统计")
        _add_table(document, ["类别", "规则或状态", "记录数"], match_rows)

    coverage = validation_result.get("method_field_coverage", {})
    if coverage:
        _add_heading(document, "六、中英文字段覆盖")
        coverage_labels = {
            "clause_en_key": "含英文条款号字段的记录数",
            "limitation_en_key": "含英文限制说明字段的记录数",
            "nonempty_clause_en": "英文条款号非空记录数",
            "nonempty_limitation_en": "英文限制说明非空记录数",
        }
        _add_table(
            document,
            ["项目", "记录数"],
            [[coverage_labels.get(key, key), value] for key, value in coverage.items()],
        )

    cross_check = validation_result.get("primary_cross_check")
    if cross_check:
        _add_heading(document, "七、主表交叉核对")
        _add_table(
            document,
            ["项目", "结果"],
            [
                ["主表能力记录数", cross_check.get("primary_records", "")],
                ["JSON记录数与主表一致", "通过" if cross_check.get("json_records_equal_primary") else "未通过"],
                ["英文值不一致项数", len(cross_check.get("english_value_mismatches", []))],
            ],
        )
        if cross_check.get("english_value_mismatches"):
            _render_issue(document, "英文值不一致明细", cross_check["english_value_mismatches"])

    standard_coverage = validation_result.get("structured_standard_coverage")
    if standard_coverage:
        _add_heading(document, "八、结构化标准覆盖")
        _add_table(
            document,
            ["项目", "记录数"],
            [
                ["目标记录", standard_coverage.get("target_records", 0)],
                ["已匹配记录", standard_coverage.get("matched_records", 0)],
                ["未匹配记录", standard_coverage.get("unmatched_records", 0)],
            ],
        )
        if standard_coverage.get("unmatched"):
            _render_issue(document, "结构化标准未匹配明细", standard_coverage["unmatched"])

    _add_heading(document, "九、问题明细")
    rendered_issue = False
    for source, issues in (
        ("合并匹配", merge_report.get("issues", {})),
        ("独立完整性校验", validation_result.get("issues", {})),
    ):
        for key, value in issues.items():
            if not _has_content(value):
                continue
            rendered_issue = True
            _render_issue(document, f"{source}：{ISSUE_LABELS.get(key, key)}", value)
    if not rendered_issue:
        paragraph = document.add_paragraph("未发现需列示的异常项。")
        paragraph.paragraph_format.space_after = Pt(0)

    path.parent.mkdir(parents=True, exist_ok=True)
    from .model import atomic_save
    atomic_save(document.save, path)
    reopened = Document(path)
    if not reopened.paragraphs:
        raise ValueError("Word校验报告重新打开后内容为空")
    return {"output": str(path), "passed": passed, "failed_checks": list(dict.fromkeys(failures))}

