# -*- coding: utf-8 -*-
"""Read-only comparison and evidence-bound semantic rendering, Python 3.8+."""
import hashlib
import json
import os
import re
from pathlib import Path
from collections import Counter

from . import comparison as diff

ACTIONS = {
    "compare": {"description": "比较评审前后责任并集，生成语义审查证据", "dependencies": [], "inputs": ["before", "after"]},
    "render": {"description": "复核完整语义决定并生成三段附加说明", "dependencies": [], "inputs": ["before", "after"]},
}


def _sha(path):
    h = hashlib.sha256()
    with open(str(path), "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _write(path, text):
    """Atomic replace plus actual UTF-8 readback, including network workspaces."""
    temporary = path.with_name(path.name + ".tmp-" + str(os.getpid()))
    temporary.write_bytes(text.encode("utf-8"))
    os.replace(str(temporary), str(path))
    if path.read_bytes() != text.encode("utf-8"):
        raise ValueError("输出重读校验失败：" + str(path))


def _evidence(dataset, collection, entity_id, reviewer):
    entity = dataset[collection].get(entity_id, {})
    rows = entity.get("rows", [entity.get("row")])
    return [{"reviewer": reviewer, "source_file": dataset["path"], "source_sheet": dataset["sheet"],
             "source_row": row, "json_pointer": "/{}/{}".format(collection, entity_id.replace("~", "~0").replace("/", "~1")),
             "evidence_refs": []} for row in rows if isinstance(row, int)]


def _collect(request, context):
    inputs, options = request.get("inputs", {}), request.get("options", {})
    reviewer = diff.compact(request.get("reviewer") or context.get("reviewer"))
    if not reviewer:
        raise ValueError("必须指定评审员姓名")
    paths = {key: Path(inputs.get(key, "")).expanduser() for key in ("before", "after")}
    for key, path in paths.items():
        if not path.is_file() or path.suffix.lower() not in (".xlsx", ".xlsm"):
            raise ValueError("{} 必须为存在的 .xlsx/.xlsm 文件".format(key))
    if paths["before"].resolve() == paths["after"].resolve():
        raise ValueError("评审前、评审后不能是同一个文件")
    hashes = {key: _sha(path) for key, path in paths.items()}
    datasets = {key: diff.load_dataset(path, options.get("sheet", diff.DEFAULT_SHEET)) for key, path in paths.items()}
    before, after = datasets["before"], datasets["after"]
    report = diff.analyze(before, after, reviewer, options.get("reason", ""))
    report["source_sha256"] = hashes
    trace = []
    for index, change in enumerate(report["changes"], 1):
        change["change_id"] = "C{:05d}".format(index)
        collection = {"object": "objects", "parameter": "parameters", "standard": "standards"}[change["level"]]
        change["evidence"] = []
        for dataset in (before, after):
            evidence = _evidence(dataset, collection, change["entity_id"], reviewer)
            change["evidence"].extend(evidence)
            trace.extend(evidence)
        # A removed/added entity includes its actual business values, not just an ID.
        change["before_record"] = before[collection].get(change["entity_id"])
        change["after_record"] = after[collection].get(change["entity_id"])
    scope = diff.scoped_standard_ids(before, after, reviewer)
    contexts = {}
    for dataset in (before, after):
        for std_id in sorted(scope):
            std = dataset["standards"].get(std_id)
            if std:
                pid = std["parameter_id"]
                contexts[pid] = diff.preferred_context(before, after, pid)
                trace.extend(_evidence(dataset, "standards", std_id, reviewer))
    report["parameter_contexts"] = contexts
    # Source relocation into case snapshots must not invalidate Agent decisions.
    # Row provenance remains in evidence, outside this content-only fingerprint.
    fingerprint_changes = [{k: v for k, v in change.items() if k != "evidence"} for change in report["changes"]]
    report["analysis_fingerprint"] = _digest({"reviewer": reviewer, "hashes": hashes, "changes": fingerprint_changes})
    if hashes != {key: _sha(path) for key, path in paths.items()}:
        raise ValueError("分析过程中源文件发生变化")
    return report, trace, datasets


def _full_context(context):
    label = context.get("object_label", "")
    param = context.get("parameter_label", "")
    return bool(re.search(r"[一二三四五六七八九十百零〇\d]+[、．.]", label)
                and re.search(r"[，,]\s*[^，,]+-.+", label)
                and re.match(r"[^-]+-.+", param))


def _number(index):
    digits = "零一二三四五六七八九"
    if index < 10:
        return digits[index]
    if index < 20:
        return "十" + (digits[index % 10] if index % 10 else "")
    if index < 100:
        return digits[index // 10] + "十" + (digits[index % 10] if index % 10 else "")
    return str(index)


def _sentence(text):
    """Append punctuation only when needed, retaining supplied prose verbatim."""
    if re.search(r'[。！？.!?…][”’"』」）)]*\s*$', text):
        return text
    return text + "。"


def _semantic(report, decisions, options):
    if not isinstance(decisions, dict):
        return None, ["需要 Agent 逐项审查后提供 decisions JSON；尚未生成可粘贴 TXT"]
    if decisions.get("analysis_fingerprint") != report["analysis_fingerprint"] or decisions.get("source_sha256") != report["source_sha256"]:
        raise ValueError("decisions 与当前源文件/分析指纹不一致，请重新比较")
    changes = {c["change_id"]: c for c in report["changes"]}
    contexts = report["parameter_contexts"]
    covered, groups, unresolved = set(), decisions.get("groups"), []
    if not isinstance(groups, list):
        raise ValueError("decisions.groups 必须为数组")
    buckets = {"nonrecommended": [], "restriction": [], "other": []}
    counted = {"nonrecommended": set(), "restriction": set()}
    transitions = {p["parameter_id"] for p in report["nonrecommended_parameters"]}
    semantic_ids = set()
    for index, group in enumerate(groups):
        category = group.get("category")
        if category not in ("nonrecommended", "restriction", "other", "identifier_only", "no_business_change"):
            raise ValueError("未知决定分类：" + str(category))
        ids = group.get("change_ids")
        if not isinstance(ids, list) or not ids or len(set(ids)) != len(ids):
            raise ValueError("每个决定必须引用非空、无重复的 change_ids")
        for cid in ids:
            if cid not in changes or cid in covered:
                raise ValueError("未知或重复覆盖的 change_id：" + str(cid))
            covered.add(cid)
        if group.get("confirmed") is not True:
            unresolved.append("第{}组尚未完成语义审查".format(index + 1))
        affected = {changes[cid]["context"].get("parameter_id") for cid in ids}
        pids = group.get("parameter_ids", [])
        if not isinstance(pids, list) or len(set(pids)) != len(pids):
            raise ValueError("parameter_ids 必须为无重复数组")
        for pid in pids:
            if pid not in contexts or pid not in affected:
                raise ValueError("决定引用范围外或无关参数：" + str(pid))
        text = group.get("text", "").strip()
        if not text or "\n" in text or "\r" in text:
            raise ValueError("每组必须提供单段自然语言 text（包括忽略决定的证据解释）")
        # Internal IDs belong in JSON provenance only.
        hidden_ids = {c["entity_id"] for c in changes.values() if len(str(c["entity_id"])) >= 8}
        if any(str(identifier) in text for identifier in hidden_ids) or re.search(r"objId|paramId|objStdId", text):
            raise ValueError("TXT 说明不得包含内部 ID")
        if category in ("identifier_only", "no_business_change"):
            # Omission is provable only for a paired ID rebuild with identical
            # business records. Agent prose cannot hide field changes/deletions.
            if any(changes[cid]["kind"] == "modified" for cid in ids):
                raise ValueError("忽略决定不能掩盖可见业务字段修改")
            signatures = {"before": Counter(), "after": Counter()}
            for cid in ids:
                change = changes[cid]
                for side in ("before", "after"):
                    record = change.get(side + "_record")
                    if record is not None:
                        business = {k: v for k, v in record.items() if k not in ("id", "rows", "row", "object_id", "parameter_id")}
                        signatures[side][(change["level"], _digest(business))] += 1
            if signatures["before"] != signatures["after"] or not signatures["before"]:
                raise ValueError("忽略决定必须证明前后业务记录相等；单纯删除/新增须描述业务变化")
            continue
        if category in ("nonrecommended", "restriction") and not pids:
            raise ValueError("不推荐/限制决定必须列出受影响参数")
        if any(not _full_context(contexts[pid]) for pid in pids):
            unresolved.append("第{}组缺少完整大类、对象或参数序号".format(index + 1))
        labels = []
        for pid in pids:
            label = contexts[pid]["object_label"] + "，" + contexts[pid]["parameter_label"]
            if label not in labels:
                labels.append(label)
        if not labels:
            labels = list(dict.fromkeys(changes[cid]["context"].get("object_label", "") for cid in ids))
            if any(not re.search(r"[一二三四五六七八九十百零〇\d]+[、．.]", label) or "-" not in label for label in labels):
                unresolved.append("第{}组缺少完整检测对象序号".format(index + 1))
        prefix = "；".join(labels)
        if category == "other":
            buckets[category].append(_sentence(prefix + "，" + text))
            continue
        if category == "nonrecommended":
            if any(changes[cid]["kind"] == "modified" and changes[cid]["field"] != "recommended" for cid in ids):
                raise ValueError("不推荐正文仅叙述决定与原因；其它业务字段修改必须另组描述")
            if group.get("basis") != "user_confirmed" and not set(pids).issubset(transitions):
                unresolved.append("删除/换 ID/新增否定状态须有用户明确不推荐证据")
            reason = options.get("reason", "")
        else:
            if group.get("scope_narrowed") is not True:
                unresolved.append("限制决定必须明确确认能力范围被缩小")
            reason = options.get("restriction_reason", "")
        if counted[category].intersection(pids):
            raise ValueError("同一参数的同类决定必须归并为一组，不能按方法重复描述")
        reasons = options.get("reasons", {}) if category == "nonrecommended" else options.get("restriction_reasons", {})
        chosen = {reasons.get(pid, reason) for pid in pids}
        if len(chosen) != 1 or not next(iter(chosen), ""):
            unresolved.append("第{}组缺少用户给定的{}原因，或不同原因须拆组".format(index + 1, "不推荐" if category == "nonrecommended" else "限制"))
            continue
        reason = next(iter(chosen))
        if not isinstance(reason, str) or "\n" in reason or "\r" in reason:
            raise ValueError("原因必须为用户给定的单段原文")
        if category == "nonrecommended":
            buckets[category].append(_sentence(prefix + "，不推荐原因为" + reason))
            semantic_ids.update(pids)
        else:
            buckets[category].append(_sentence(prefix + "，" + text.rstrip("。") + "，原因为" + reason))
        counted[category].update(pids)
    if covered != set(changes):
        raise ValueError("decisions 未完整覆盖源 changes：" + "、".join(sorted(set(changes) - covered)))
    if transitions - semantic_ids:
        unresolved.append("推荐从肯定转否定的参数尚未归入不推荐决定：" + "、".join(sorted(transitions - semantic_ids)))
    if counted["restriction"] & counted["nonrecommended"]:
        raise ValueError("同一参数不得同时计入不推荐和限制")
    return (buckets, counted), unresolved


def run(action, request, context):
    if action not in ACTIONS:
        raise ValueError("未知 notes 动作：" + str(action))
    output = Path(context["output_dir"]).resolve()
    output.mkdir(parents=True, exist_ok=True)
    report, trace, datasets = _collect(request, context)
    summary = report["summary"]
    unresolved, status, artifacts = [], "needs_review", []
    matched = summary["scoped_before_standard_records"] + summary["scoped_after_standard_records"] > 0
    if not matched:
        status = "blocked"
        unresolved.append("指定评审员在前后文件中均无命中；核对姓名和文件，拒绝生成 0 项 TXT")
    diagnostics = report["diagnostics"]
    if any(value for side in diagnostics.values() for value in side.values()):
        unresolved.append("源表存在未知列、缺失/重复 ID 或冲突值，须先澄清后出具 TXT")
    if action == "render" and matched:
        decisions = request.get("options", {}).get("decisions")
        decision_path = request.get("inputs", {}).get("decisions")
        if decision_path:
            decisions = json.loads(Path(decision_path).read_text(encoding="utf-8-sig"))
        rendered, missing = _semantic(report, decisions, request.get("options", {}))
        unresolved.extend(missing)
        report["semantic_decisions"] = decisions
        if rendered and not unresolved:
            buckets, counted = rendered
            lines = ["CNAS评审报告附加说明（{}负责项目）".format(report["metadata"]["reviewer"]), ""]
            for category, heading, empty in (
                ("nonrecommended", "一、不推荐参数共{}项。".format(len(counted["nonrecommended"])), "现场评审无不推荐参数。"),
                ("restriction", "二、限制参数共{}项。".format(len(counted["restriction"])), "现场评审未新增限制范围。"),
                ("other", "三、其它", "经核对，未发现其它系统业务字段修改。")):
                lines.append(heading)
                lines.extend(["（{}）{}".format(_number(i), text) for i, text in enumerate(buckets[category], 1)] or [empty])
                lines.append("")
            text = "\n".join(lines).rstrip() + "\n"
            path = output / "CNAS现场评审附加说明.txt"
            _write(path, text)
            artifacts.append({"path": str(path), "role": "notes_plain_text"})
            status = "completed"
            summary["confirmed_nonrecommended_parameter_count"] = len(counted["nonrecommended"])
            summary["confirmed_restricted_parameter_count"] = len(counted["restriction"])
    report["unresolved"] = unresolved
    report["issue_ready"] = status == "completed"
    json_path = output / "能力表前后差异分析.json"
    _write(json_path, json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    artifacts.insert(0, {"path": str(json_path), "role": "notes_detailed_analysis"})
    return {"status": status, "stage": "notes." + action, "artifacts": artifacts, "summary": summary,
            "trace": trace, "unresolved": unresolved,
            "gates": [{"id": "reviewer_matched", "passed": matched, "detail": "前后责任记录并集"},
                      {"id": "semantic_decisions_complete", "passed": status == "completed", "detail": "须完整覆盖 changes、确认限制及用户原因"}]}
