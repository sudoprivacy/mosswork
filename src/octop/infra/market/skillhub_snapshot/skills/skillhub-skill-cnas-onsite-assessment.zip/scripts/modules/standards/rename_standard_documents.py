# -*- coding: utf-8 -*-
"""Reviewable, hash-bound source renaming with scope and conflict rechecks."""
import copy
import os
import re
import unicodedata
import uuid
from collections import defaultdict
from pathlib import Path, PurePosixPath

from ._io import canonical_hash, contained, relative, sha256, verify_inventory

FORBIDDEN = str.maketrans(dict(zip('/\\:*?"<>|', '／＼：＊？＂＜＞｜')))
DASHES = str.maketrans({x: '-' for x in '—–−‐‑‒－'})


def clean_component(value, number=False):
    text = unicodedata.normalize('NFC', value)
    text = re.sub('[\x00-\x1f\x7f]+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    if number:
        text = text.translate(DASHES)
    text = text.translate(FORBIDDEN).rstrip(' .')
    if not text:
        raise ValueError('Verified standard number/name cannot be empty')
    return text


def build_plan(folder, inventory, record_doc, pdf_only=True):
    root = Path(folder).resolve()
    if root != Path(inventory['source_root']).resolve():
        raise ValueError('Rename folder differs from inventoried authorized scope')
    missing, changed = verify_inventory(inventory)
    if missing or changed:
        raise ValueError('Rename sources missing or changed: %s / %s' % (missing, changed))
    groups = defaultdict(list)
    for row in record_doc.get('records', []):
        groups[relative(row['source_file'])].append(row)
    paths = {relative(x['relative_path']) for x in inventory['files']}
    actual_paths = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if paths != actual_paths:
        raise ValueError('Physical folder changed since inventory (added/removed files)')
    if not paths or set(groups) != paths:
        raise ValueError('Every physical source must have records before rename preview')
    plan, targets = [], set()
    for item in inventory['files']:
        old = relative(item['relative_path'])
        rows = groups[old]
        numbers = {r.get('standard_number', '').strip() for r in rows}
        names = {r.get('standard_name', '').strip() for r in rows}
        if len(numbers) != 1 or len(names) != 1:
            raise ValueError('Standard identity is not unique for %s' % old)
        # Explicit original-text verification is necessary, never trust a filename.
        if not all(r.get('identity_verified') is True and r.get('evidence', '').strip() for r in rows):
            raise ValueError('Rename requires identity_verified=true plus original-text evidence: %s' % old)
        number = clean_component(next(iter(numbers)), number=True)
        name = clean_component(next(iter(names)))
        if name.startswith('《') and name.endswith('》'):
            name = name[1:-1].strip()
        source = contained(root, old)
        new = old
        if not pdf_only or source.suffix.lower() == '.pdf':
            basename = '%s《%s》%s' % (number, name, source.suffix)
            if len(basename) > 240:
                raise ValueError('Renamed basename exceeds 240 characters')
            new = (PurePosixPath(old).parent / basename).as_posix()
        target = contained(root, new)
        key = str(target).casefold()
        if key in targets:
            raise ValueError('Rename conflict: two physical files generate the same target')
        targets.add(key)
        if target.exists() and str(source).casefold() != key:
            raise ValueError('Rename target already exists; no overwrite: %s' % target)
        plan.append(dict(old_relative_path=old, new_relative_path=new, sha256=item['sha256'],
                         standard_number=number, standard_name=name,
                         status='unchanged' if old == new else 'rename'))
    result = dict(source_root=str(root), pdf_only=bool(pdf_only), files=plan,
                  inventory_sha256=canonical_hash(inventory), records_sha256=canonical_hash(record_doc))
    result['plan_sha256'] = canonical_hash(result)
    return result


def apply_plan(folder, inventory, record_doc, preview, supplied_hash, authorized=False):
    if authorized is not True:
        raise ValueError('rename_apply requires authorization.rename_sources=true')
    if not supplied_hash or supplied_hash != preview.get('plan_sha256'):
        raise ValueError('rename_apply requires the exact preview plan_sha256')
    payload = {k: v for k, v in preview.items() if k != 'plan_sha256'}
    if canonical_hash(payload) != supplied_hash:
        raise ValueError('Rename preview hash is invalid')
    fresh = build_plan(folder, inventory, record_doc, preview['pdf_only'])
    if fresh != preview:
        raise ValueError('Rename preview stale: scope, records, hashes or conflicts changed')
    root = Path(folder).resolve()
    staged = []
    try:
        # Rejecting existing targets avoids rename cycles; temporary names allow rollback.
        for item in fresh['files']:
            if item['status'] != 'rename':
                continue
            source = contained(root, item['old_relative_path'])
            target = contained(root, item['new_relative_path'])
            if sha256(source) != item['sha256'] or target.exists():
                raise ValueError('Source/target changed during rename apply')
            temp = source.with_name('.__standard_rename_' + uuid.uuid4().hex + source.suffix)
            source.rename(temp)
            staged.append(dict(source=source, target=target, temp=temp, state='temp', sha256=item['sha256']))
        for move in staged:
            if move['target'].exists():
                raise ValueError('Target created during rename apply; no overwrite')
            move['temp'].rename(move['target'])
            move['state'] = 'target'
        for move in staged:
            if sha256(move['target']) != move['sha256']:
                raise ValueError('Content hash changed during rename apply')
    except Exception:
        failures = []
        for move in reversed(staged):
            current = move['target'] if move['state'] == 'target' else move['temp']
            try:
                if move['source'].exists():
                    raise ValueError('Rollback source unexpectedly exists')
                current.rename(move['source'])
            except Exception as exc:
                failures.append(str(exc))
        if failures:
            raise ValueError('Rename failed and rollback needs manual recovery: %s' % failures)
        raise
    mapping = {x['old_relative_path']: x['new_relative_path'] for x in fresh['files']}
    updated_inventory, updated_records = copy.deepcopy(inventory), copy.deepcopy(record_doc)
    for item in updated_inventory['files']:
        item['relative_path'] = mapping[item['relative_path']]
        # Cache paths deliberately retained: they are evidence references, not source names.
    for row in updated_records.get('records', []):
        row['source_file'] = mapping[relative(row['source_file'])]
    for attempt in updated_inventory.get('ocr_attempts', []):
        attempt['source_file'] = mapping[relative(attempt['source_file'])]
    for item in updated_inventory['files']:
        for segment in item.get('ocr_segments', {}).values():
            segment['source_file'] = item['relative_path']
    updated_inventory['rename_plan_sha256'] = supplied_hash
    missing, changed = verify_inventory(updated_inventory)
    if missing or changed:
        raise ValueError('Post-rename inventory check failed')
    return updated_inventory, updated_records, dict(fresh, renamed_count=len(staged))


def rollback_committed(folder, mapping):
    """Restore names if publishing the three derived JSONs fails after rename."""
    root = Path(folder).resolve()
    for item in reversed(mapping['files']):
        if item['status'] != 'rename':
            continue
        old = contained(root, item['old_relative_path'])
        new = contained(root, item['new_relative_path'])
        if old.exists() or not new.is_file() or sha256(new) != item['sha256']:
            raise ValueError('Output publication failed; rename rollback needs manual recovery')
        new.rename(old)
