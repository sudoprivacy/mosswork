# -*- coding: utf-8 -*-
"""Actual host-result import or explicitly configured OCR transport.

No Codex configuration discovery, implicit tool name, credentials or network call.
Success is bound to source hash + complete page ranges + nonempty actual text.
"""
import asyncio
import copy
import json
import os
import re
from pathlib import Path

from ._io import atomic_bytes, canonical_hash, contained, relative, sha256, verify_inventory


def relocate_caches(inventory, folder):
    """Rebind migrated cache references within one explicitly selected tree by bytes."""
    result = copy.deepcopy(inventory)
    folder = Path(folder).resolve()
    if not folder.is_dir():
        raise ValueError('Explicit cache_folder must be a directory')
    candidates = None

    def relocate(record, path_field, hash_field):
        nonlocal candidates
        if not record.get(path_field):
            return
        current = Path(record[path_field])
        expected = record.get(hash_field)
        # Explicit cache scope is authoritative, even if the old machine path still exists.
        if candidates is None:
            candidates = [p for p in folder.rglob('*') if p.is_file()]
        matches = [p for p in candidates if p.name == current.name and expected and sha256(p) == expected]
        if not matches:
            raise ValueError('Migrated cache missing in selected tree: %s' % current.name)
        record[path_field] = str(sorted(matches)[0].resolve())

    for item in result.get('files', []):
        relocate(item, 'text_path', 'text_sha256')
        relocate(item, 'native_text_path', 'native_text_sha256')
        for segment in item.get('ocr_segments', {}).values():
            relocate(segment, 'text_path', 'text_sha256')
    return result


def _engine_allowed(engine, options):
    if not str(engine).strip():
        raise ValueError('OCR result must name the actual engine')
    preference = str(options.get('ocr_preference', 'PaddleOCR'))
    if 'paddleocr' in preference.casefold() and 'paddleocr' not in engine.casefold():
        if not options.get('allow_other_ocr', False):
            raise ValueError('PaddleOCR preference requires PaddleOCR; other OCR needs explicit allow_other_ocr')


def import_results(inventory, result_doc, output_dir, options=None):
    options = options or {}
    out = Path(output_dir).resolve()
    missing, changed = verify_inventory(inventory)
    if missing or changed:
        raise ValueError('OCR sources missing/changed since inventory: %s / %s' % (missing, changed))
    entries = result_doc.get('results', [])
    if not isinstance(entries, list):
        raise ValueError('ocr_results.results must be an array')
    result = copy.deepcopy(inventory)
    by_path = {x['relative_path']: x for x in result['files']}
    attempts = []
    for entry in entries:
        rel = relative(entry.get('source_file'))
        if rel not in by_path:
            raise ValueError('OCR result source not in inventory: %s' % rel)
        item = by_path[rel]
        if item['extension'] != '.pdf':
            raise ValueError('OCR import currently accepts PDF page ranges only')
        if entry.get('source_sha256') != item.get('sha256'):
            raise ValueError('OCR result source hash mismatch: %s' % rel)
        engine = str(entry.get('engine', ''))
        _engine_allowed(engine, options)
        # Provenance is supplied by the actual host invocation, never invented by this module.
        if not entry.get('tool') or not entry.get('evidence_ref'):
            raise ValueError('OCR result requires actual tool and invocation evidence_ref')
        first, last = entry.get('start_page'), entry.get('end_page')
        if (isinstance(first, bool) or isinstance(last, bool) or not isinstance(first, int)
                or not isinstance(last, int) or not 1 <= first <= last <= (item.get('page_count') or 0)):
            raise ValueError('OCR result page range is invalid: %s' % rel)
        key = '%04d-%04d' % (first, last)
        segments = item.setdefault('ocr_segments', {})
        attempt = dict(source_file=rel, start_page=first, end_page=last, engine=engine,
                       tool=str(entry['tool']), evidence_ref=str(entry['evidence_ref']),
                       status=str(entry.get('status', 'failed')), complete=entry.get('complete') is True,
                       attempt_count=entry.get('attempt_count', 1))
        text = entry.get('text', '')
        if not isinstance(text, str):
            raise ValueError('OCR result.text must be a string')
        if not text and entry.get('text_file'):
            text = Path(entry['text_file']).read_text(encoding='utf-8-sig')
        # Failed/empty responses remain retryable; a prior successful segment is retained.
        if entry.get('status') != 'ok' or not text.strip() or entry.get('complete') is not True:
            attempt.update(status='failed', reason='OCR tool failure, empty text or unconfirmed complete page range')
            attempts.append(attempt)
            continue
        cache_key = canonical_hash(dict(source_sha256=item['sha256'], first=first, last=last,
                                        engine=engine, text=text))
        target = out / 'ocr_cache' / item['sha256'] / (key + '-' + cache_key[:16] + '.txt')
        atomic_bytes(target, text.encode('utf-8'))
        segment = dict(attempt, text_path=str(target), text_sha256=sha256(target),
                       text_chars=len(text.strip()), cache_key=cache_key)
        segments[key] = segment
        attempts.append(attempt)
    for item in result['files']:
        segments = list(item.get('ocr_segments', {}).values())
        if not segments:
            continue
        accepted, covered, bodies = [], set(), []
        for segment in sorted(segments, key=lambda x: (x['start_page'], x['end_page'])):
            target = Path(segment['text_path'])
            if not target.is_file() or sha256(target) != segment.get('text_sha256'):
                raise ValueError('OCR cache missing/changed: %s' % target)
            pages = set(range(segment['start_page'], segment['end_page'] + 1))
            if pages & covered:
                raise ValueError('Overlapping OCR segments: %s; retry same range or start from inventory' % item['relative_path'])
            covered.update(pages)
            accepted.append(segment)
            bodies.append('\n\n===== pages %d-%d; %s =====\n%s' %
                          (segment['start_page'], segment['end_page'], segment['engine'],
                           target.read_text(encoding='utf-8-sig')))
        native_pages = {i + 1 for i, chars in enumerate(item.get('page_text_chars', [])) if chars >= 50}
        all_pages = set(range(1, (item.get('page_count') or 0) + 1))
        pending = sorted(all_pages - covered - native_pages)
        native = ''
        if item.get('text_path') and not item.get('extraction_mode', '').startswith('ocr'):
            native_path = Path(item['text_path'])
            if not native_path.exists() or sha256(native_path) != item.get('text_sha256'):
                raise ValueError('Native text cache missing/changed')
            native = native_path.read_text(encoding='utf-8-sig')
            item['native_text_path'] = str(native_path)
            item['native_text_sha256'] = item['text_sha256']
        elif item.get('native_text_path'):
            native_path = Path(item['native_text_path'])
            if sha256(native_path) != item.get('native_text_sha256'):
                raise ValueError('Native text cache changed')
            native = native_path.read_text(encoding='utf-8-sig')
        text = native + ''.join(bodies)
        merged = out / 'ocr_text' / (item['relative_path'] + '.txt')
        atomic_bytes(merged, text.encode('utf-8'))
        item.update(text_path=str(merged), text_sha256=sha256(merged),
                    extracted_text_chars=len(text.strip()), pending_pages=pending,
                    needs_ocr=bool(pending), status='pending_ocr' if pending else 'ok',
                    extraction_mode='ocr_import:' + ','.join(sorted({x['engine'] for x in accepted})))
    result['ocr_attempts'] = inventory.get('ocr_attempts', []) + attempts
    result['ocr_preference'] = options.get('ocr_preference', 'PaddleOCR')
    return result


def _config(config):
    """Explicit connection only. Auth values come from named environment variables."""
    if not config.get('engine') or not config.get('tool_name'):
        raise ValueError('OCR config requires engine and actual tool_name; neither has a default')
    if config.get('transport') not in {'stdio', 'http_json'}:
        raise ValueError('Explicit OCR config transport must be stdio or http_json')
    forbidden = {'token', 'password', 'api_key', 'authorization', 'headers', 'env'}
    if forbidden.intersection(str(k).casefold() for k in config):
        raise ValueError('OCR config must use header_env/env_names; do not embed credentials')
    if config['transport'] == 'http_json':
        from urllib.parse import urlparse
        parsed = urlparse(config.get('endpoint') or os.environ.get(config.get('endpoint_env', ''), ''))
        if parsed.scheme not in {'http', 'https'} or not parsed.netloc or parsed.username or parsed.password or parsed.query:
            raise ValueError('Explicit HTTP endpoint required; credentials/query are forbidden in URL')
    return config


def _lookup(value, dotted):
    for part in dotted.split('.'):
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


async def _stdio_calls(config, jobs, options):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    env = os.environ.copy()
    for name in config.get('env_names', []):
        if name not in os.environ:
            raise ValueError('Required OCR environment variable is unset: %s' % name)
    parameters = StdioServerParameters(command=config['command'], args=config.get('args', []), env=env)
    responses = []
    async with stdio_client(parameters) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            available = await session.list_tools()
            if config['tool_name'] not in {tool.name for tool in available.tools}:
                raise ValueError('Configured OCR tool is not available on explicit server')
            for job in jobs:
                answer = dict(status='failed', text='', complete=False)
                for attempt in range(max(1, min(int(options.get('retries', 2)), 5))):
                    try:
                        response = await asyncio.wait_for(
                            session.call_tool(config['tool_name'], job['arguments']),
                            timeout=max(1, min(int(options.get('timeout', 45)), 60)))
                        text = '\n'.join(x.text for x in response.content if getattr(x, 'type', None) == 'text')
                        # Explicit tool contract can attest successful calls cover full input;
                        # otherwise import the host-reviewed result with complete=true.
                        complete = config.get('success_is_complete') is True and not response.isError
                        answer = dict(status='failed' if response.isError else 'ok', text=text,
                                      complete=complete, attempt_count=attempt + 1)
                        if complete and text.strip():
                            break
                    except Exception:
                        answer['attempt_count'] = attempt + 1
                responses.append(answer)
    return responses


def configured_client(inventory, config, output_dir, options=None):
    """Explicit client call with per-range retry/cache. Transport errors stay pending."""
    options = options or {}
    config = _config(config)
    _engine_allowed(config['engine'], options)
    missing, changed = verify_inventory(inventory)
    if missing or changed:
        raise ValueError('OCR sources missing/changed: %s/%s' % (missing, changed))
    from .split_pdf_chunks import split_pdf
    jobs = []
    for item in inventory['files']:
        if not item.get('needs_ocr'):
            continue
        source = contained(inventory['source_root'], item['relative_path'])
        manifest = split_pdf(source, output_dir, options.get('chunk_size', 10))
        for chunk in manifest['chunks']:
            key = '%04d-%04d' % (chunk['start_page'], chunk['end_page'])
            cached = item.get('ocr_segments', {}).get(key)
            if cached and Path(cached['text_path']).exists() and sha256(cached['text_path']) == cached['text_sha256']:
                continue
            arguments = copy.deepcopy(config.get('arguments', {}))
            arguments[config.get('input_argument', 'file_path')] = chunk['path']
            jobs.append(dict(item=item, chunk=chunk, arguments=arguments))
    responses = []
    if config['transport'] == 'stdio':
        try:
            responses = asyncio.run(_stdio_calls(config, jobs, options))
        except ImportError:
            raise ValueError('Selected stdio OCR action requires the optional mcp package')
        except ValueError:
            raise
        except Exception:
            responses = [dict(status='failed', text='') for _ in jobs]
    else:
        import urllib.request
        endpoint = config.get('endpoint') or os.environ.get(config.get('endpoint_env', ''), '')
        headers = {'Content-Type': 'application/json'}
        for header, env_name in config.get('header_env', {}).items():
            if env_name not in os.environ:
                raise ValueError('Required OCR environment variable is unset: %s' % env_name)
            headers[header] = os.environ[env_name]
        for job in jobs:
            answer = dict(status='failed', text='')
            for attempt in range(max(1, min(int(options.get('retries', 2)), 5))):
                try:
                    data = json.dumps(dict(tool=config['tool_name'], arguments=job['arguments'])).encode('utf-8')
                    req = urllib.request.Request(endpoint, data=data, headers=headers, method='POST')
                    with urllib.request.urlopen(req, timeout=min(int(options.get('timeout', 45)), 60)) as response:
                        body = json.load(response)
                    text = _lookup(body, config.get('response_text_key', 'text'))
                    # A service must expose a success flag explicitly; a JSON error cannot become OCR text.
                    success = _lookup(body, config.get('response_success_key', 'success')) is True
                    complete = _lookup(body, config.get('response_complete_key', 'complete')) is True
                    answer = dict(status='ok' if success else 'failed', text=text if isinstance(text, str) else '',
                                  complete=complete, attempt_count=attempt + 1)
                    if answer['status'] == 'ok' and answer['text'].strip() and complete:
                        break
                except Exception:
                    # Never persist exception strings containing endpoints or secrets.
                    pass
            responses.append(answer)
    results = []
    for job, response in zip(jobs, responses):
        results.append(dict(response, source_file=job['item']['relative_path'],
                            source_sha256=job['item']['sha256'], engine=config['engine'],
                            tool=config['tool_name'], evidence_ref='explicit-client/chunk-sha256:' + job['chunk']['sha256'],
                            start_page=job['chunk']['start_page'], end_page=job['chunk']['end_page']))
    return import_results(inventory, {'results': results}, output_dir, options)
