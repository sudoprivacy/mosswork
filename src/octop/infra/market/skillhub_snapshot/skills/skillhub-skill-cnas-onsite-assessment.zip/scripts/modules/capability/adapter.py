# -*- coding: utf-8 -*-
"""Frozen CNAS workflow adapter. Never creates or confirms findings."""
from pathlib import Path

ACTIONS = {
    'merge': {'description': '主表权威合并并生成完整性Word和方法待核Word', 'dependencies': ['openpyxl', 'docx'], 'inputs': ['primary', 'supplement']},
    'audit': {'description': '核验阶段覆盖及Agent原文审核问题，生成评审员审核Excel', 'dependencies': ['openpyxl', 'docx'], 'inputs': ['merged', 'primary', 'supplement', 'validation_report', 'method_list', 'standards_inventory', 'standards_records', 'standards_workbook', 'issues']},
}


def run(action, request, context):
    from .model import context_value, sha256
    if action not in ACTIONS:
        raise ValueError('未知capability动作：' + str(action))
    inputs = request.get('inputs', {})
    for key in ACTIONS[action]['inputs']:
        if not isinstance(inputs.get(key), str) or not Path(inputs[key]).is_file():
            raise ValueError('缺少既有输入文件：inputs.' + key)
    output = Path(context_value(context, 'output_dir')).resolve()
    skill = Path(context_value(context, 'skill_dir')).resolve()
    forbidden_paths = [skill]
    for value in inputs.values():
        if isinstance(value, str):
            source = Path(value).resolve()
            if source.is_file():
                forbidden_paths.append(source.parent)
            elif source.is_dir():
                forbidden_paths.append(source)
    for forbidden in forbidden_paths:
        if output == forbidden or forbidden in output.parents:
            raise ValueError('output_dir须位于技能和输入目录树之外')
    output.mkdir(parents=True, exist_ok=True)
    snapshot = {key: sha256(value) for key, value in inputs.items() if isinstance(value, str) and Path(value).is_file()}
    if action == 'merge':
        result = merge_action(request, context, output)
    else:
        from .audit import audit_action
        result = audit_action(request, context, output)
    for key, digest in snapshot.items():
        if sha256(inputs[key]) != digest:
            raise ValueError('执行中输入文件变更：' + key)
    result['source_hashes'] = snapshot
    return result


def merge_action(request, context, output):
    from docx import Document
    from .model import read_inputs, reviewer_matches, context_value, write_json, sha256
    from .merge import merge
    from .methods import collect_lines, write_docx
    from .word_report import write_validation_report
    inputs, options = request['inputs'], request.get('options', {})
    primary, supplement, equipment, duplicates, sheets, maps = read_inputs(inputs['primary'], inputs['supplement'], options)
    capabilities, validation = merge(primary, supplement, equipment, duplicates)
    reviewer = context_value(context, 'reviewer', '') or request.get('reviewer', '')
    for item in capabilities:
        item['source'].update({'primary_file': str(Path(inputs['primary']).resolve()), 'primary_sheet': sheets['primary'], 'supplement_file': str(Path(inputs['supplement']).resolve()), 'supplement_sheet': sheets['supplement']})
    selected = [(i, x) for i, x in enumerate(capabilities) if reviewer_matches(x, reviewer)]
    if reviewer and not selected:
        raise ValueError('未找到评审员完整姓名对应记录：' + reviewer)
    # An independent replay checks complete authoritative content, not merely counts.
    repeated = read_inputs(inputs['primary'], inputs['supplement'], maps)
    replay, unused = merge(*repeated[:4])
    authoritative_equal = all(all(a.get(k) == b.get(k) for k in ('capability_id', 'category', 'object', 'parameter', 'method', 'application', 'equipment_ids', 'equipment', 'operational')) for a, b in zip(capabilities, replay)) and len(replay) == len(capabilities)
    validation['integrity_checks']['primary_authoritative_content_equal'] = authoritative_equal
    validation['integrity_checks']['capability_ids_nonempty'] = all(x['capability_id'] for x in capabilities)
    validation['integrity_checks']['records_nonempty'] = bool(capabilities)
    detail = {'records': len(capabilities), 'equipment_master_records': len(equipment), 'reviewer': reviewer, 'reviewer_records': len(selected), 'match_status_counts': {}, 'method_field_coverage': {key: sum(key in x['method'] for x in capabilities) for key in ('clause_en', 'limitation_en')}, 'primary_cross_check': {'primary_records': len(primary), 'json_records_equal_primary': len(primary) == len(capabilities), 'english_value_mismatches': []}, 'integrity_checks': {'primary_authoritative_content_equal': authoritative_equal}}
    detail['method_field_coverage'] = {'clause_en_key': len(capabilities), 'limitation_en_key': len(capabilities), 'nonempty_clause_en': sum(bool(x['method']['clause_en']) for x in capabilities), 'nonempty_limitation_en': sum(bool(x['method']['limitation_en']) for x in capabilities)}
    for item in capabilities:
        key = item['match']['status']
        detail['match_status_counts'][key] = detail['match_status_counts'].get(key, 0) + 1
    paths = {'merged': output / '检测能力_合并设备信息_AI规范版.json', 'validation_report': output / '检测能力_合并设备信息_完整性报告.docx', 'method_list': output / '方法有效性检查_待核清单.docx'}
    report = write_validation_report(paths['validation_report'], merge_report=validation, validation_result=detail, metadata={'主能力文件': str(Path(inputs['primary']).resolve()), '设备补充文件': str(Path(inputs['supplement']).resolve()), '规范JSON': str(paths['merged']), '指定评审员': reviewer or '全部', '审核边界': '只校验数据完整性和来源一致性；源英文空值原样保留。'})
    artifacts = [{'path': str(paths['merged']), 'role': 'capability_merged'}, {'path': str(paths['validation_report']), 'role': 'capability_validation_word'}]
    payload = {'schema_version': '1.1.0', 'sources': {'primary': str(Path(inputs['primary']).resolve()), 'equipment_supplement': str(Path(inputs['supplement']).resolve())}, 'source_hashes': {key: sha256(inputs[key]) for key in ('primary', 'supplement')}, 'column_mapping': maps, 'validation': validation, 'validation_passed': report['passed'], 'reviewer': reviewer, 'equipment_master': list(equipment.values()), 'capabilities': capabilities, 'stage_artifacts': {'validation_report': {'path': str(paths['validation_report']), 'sha256': sha256(paths['validation_report'])}}}
    entries, conflicts, unique_count = collect_lines([item for _, item in selected])
    if report['passed']:
        write_docx(paths['method_list'], entries)
        if [p.text for p in Document(paths['method_list']).paragraphs if p.text] != [entry['line'] for entry in entries]:
            raise ValueError('方法Word重开内容不一致')
        artifacts.append({'path': str(paths['method_list']), 'role': 'capability_method_list_word'})
        payload['stage_artifacts']['method_list'] = {'path': str(paths['method_list']), 'sha256': sha256(paths['method_list'])}
    write_json(paths['merged'], payload)
    unresolved = []
    for name, value in validation['issues'].items():
        if value:
            unresolved.append({'kind': name, 'detail': value})
    if conflicts:
        unresolved.append({'kind': 'standard_name_conflicts', 'detail': conflicts})
    trace = [{'reviewer': reviewer, 'source_file': item['source']['primary_file'], 'source_sheet': sheets['primary'], 'source_row': item['source']['primary_row'], 'json_pointer': '/capabilities/%d' % i, 'evidence_refs': [{'source_file': item['source']['supplement_file'], 'source_sheet': sheets['supplement'], 'source_rows': item['source']['supplement_rows'], 'sha256': payload['source_hashes']['supplement']}]} for i, item in selected]
    return {'status': 'blocked' if not report['passed'] else 'needs_review' if unresolved else 'completed', 'stage': 'capability.merge', 'artifacts': artifacts, 'summary': dict(validation['summary'], reviewer=reviewer, reviewer_records=len(selected), method_standard_count=unique_count, method_word_lines=len(entries) if report['passed'] else 0, validation_passed=report['passed']), 'trace': trace, 'unresolved': unresolved, 'gates': [{'id': 'primary_integrity', 'passed': report['passed'], 'detail': '完整性Word硬检查；英文来源空值仅披露，不编译、不补写。'}]}
