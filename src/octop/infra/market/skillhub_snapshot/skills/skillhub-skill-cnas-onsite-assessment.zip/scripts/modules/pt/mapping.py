# -*- coding: utf-8 -*-
"""Reviewed row mapping and safe copy-on-write workbook application."""
import json
import os
import shutil
import tempfile
from pathlib import Path
from .basis import file_hash, fingerprint
from .items import split_items

ALIASES = {'activity': ('能力验证类型',), 'parameter': ('项目/参数名称', '项目/参数'),
           'standard': ('依据方法标准编号', '依据方法/标准编号'),
           'domain': ('能力验证领域',), 'item_count': ('项次',)}


def text(value):
    return '' if value is None else str(value).strip()


def load(path):
    from openpyxl import load_workbook
    return load_workbook(path, data_only=False, keep_vba=Path(path).suffix.lower() == '.xlsm')


def locate(workbook, sheet=None):
    candidates = []
    for ws in workbook.worksheets:
        if sheet and ws.title != sheet:
            continue
        for row in range(1, min(ws.max_row, 30) + 1):
            values = {text(ws.cell(row, c).value): c for c in range(1, ws.max_column + 1)}
            columns = {key: next((values[a] for a in aliases if a in values), None)
                       for key, aliases in ALIASES.items()}
            if all(columns.values()):
                candidates.append((ws, row, columns))
    if len(candidates) != 1:
        raise ValueError('能力验证工作表/表头须唯一，可用 options.sheet 指定；候选数=%d' % len(candidates))
    return candidates[0]


def prepare(path, model, reviewer, sheet=None):
    path = Path(path)
    if path.name.startswith('~$') or path.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise ValueError('工作簿须为非临时 .xlsx/.xlsm 文件')
    source_hash = file_hash(path)
    wb = load(path)
    try:
        ws, header, columns = locate(wb, sheet)
        rows = []
        for r in range(header + 1, ws.max_row + 1):
            if not any(text(ws.cell(r, c).value) for c in range(1, ws.max_column + 1)):
                continue
            parameter = text(ws.cell(r, columns['parameter']).value)
            rows.append({'excel_row': r, 'sequence': text(ws.cell(r, 2).value),
                         'activity': text(ws.cell(r, columns['activity']).value),
                         'project_parameter': parameter,
                         'standard': text(ws.cell(r, columns['standard']).value),
                         'auto_item_count': len(split_items(parameter)) if parameter else None,
                         'domains': [], 'item_count_override': None, 'domain_item_counts': {},
                         'reviewed': False, 'review_note': '', 'evidence_refs': []})
        payload = {'schema_version': '1.1.0', 'workbook_name': path.name,
                   'workbook_sha256': source_hash, 'reviewer': reviewer,
                   'basis_fingerprint': model['basis_fingerprint'],
                   'sheet': ws.title, 'header_row': header, 'columns': columns,
                   'allowed_domains': model['allowed_domains'], 'domain_separator': '；', 'rows': rows}
        payload['preparation_fingerprint'] = immutable_fingerprint(payload)
        if file_hash(path) != source_hash:
            raise ValueError('生成映射期间源工作簿变化')
        return payload
    finally:
        wb.close()


def immutable_fingerprint(mapping):
    data = {k: v for k, v in mapping.items() if k not in ('rows', 'preparation_fingerprint')}
    mutable = {'domains', 'item_count_override', 'domain_item_counts', 'reviewed', 'review_note', 'evidence_refs'}
    data['rows'] = [{k: v for k, v in r.items() if k not in mutable} for r in mapping['rows']]
    return fingerprint(data)


def _snapshot(wb, sheet, editable):
    result = []
    for ws in wb.worksheets:
        cells = {}
        for row in ws.iter_rows():
            for cell in row:
                if ws.title == sheet and (cell.row, cell.column) in editable:
                    continue
                value = cell.value
                if value is not None and value != '':
                    cells[cell.coordinate] = (value, cell.data_type)
        result.append((ws.title, ws.max_row, ws.max_column, str(ws.merged_cells), cells,
                       [(i, d.height, d.hidden, d.outlineLevel) for i, d in ws.row_dimensions.items()],
                       [(i, d.width, d.hidden, d.outlineLevel) for i, d in ws.column_dimensions.items()]))
    return result


def apply(path, mapping, model, reviewer, output):
    expected = prepare(path, model, reviewer, mapping.get('sheet'))
    if immutable_fingerprint(mapping) != expected['preparation_fingerprint'] or mapping.get('preparation_fingerprint') != expected['preparation_fingerprint']:
        raise ValueError('映射与源文件/表头/行/所选依据/评审员的准备指纹不一致')
    row_ids = [r['excel_row'] for r in mapping['rows']]
    if len(row_ids) != len(set(row_ids)):
        raise ValueError('映射包含重复行')
    allowed = {r['value'] for r in model['allowed_domains']}
    missing, reviewed_rows = [], []
    for item in mapping['rows']:
        if item.get('reviewed') is not True:
            missing.append('第%d行尚未逐行审核' % item['excel_row'])
        domains = item.get('domains')
        if not isinstance(domains, list) or any(not isinstance(d, str) or d not in allowed for d in domains):
            raise ValueError('第%d行含非法/表外领域' % item['excel_row'])
        if len(domains) != len(set(domains)):
            raise ValueError('第%d行包含重复领域' % item['excel_row'])
        override = item.get('item_count_override')
        count = item['auto_item_count'] if override is None else override
        if isinstance(count, bool) or not isinstance(count, int) or count <= 0:
            raise ValueError('第%d行项次须为正整数' % item['excel_row'])
        if (override is not None or len(domains) != 1) and not text(item.get('review_note')):
            missing.append('第%d行空领域/多领域/人工项次须说明判断依据' % item['excel_row'])
        allocation = item.get('domain_item_counts', {})
        if allocation:
            if set(allocation) != set(domains) or any(isinstance(n, bool) or not isinstance(n, int) or n < 1 for n in allocation.values()) or sum(allocation.values()) != count:
                raise ValueError('第%d行 domain_item_counts 须逐域分配正整数且合计等于项次' % item['excel_row'])
        reviewed_rows.append(dict(item, item_count=count))
    if missing:
        return None, missing
    output = Path(output)
    if output.resolve() == Path(path).resolve() or output.exists():
        raise ValueError('禁止覆盖源文件或既有输出')
    wb = load(path)
    try:
        ws = wb[mapping['sheet']]
        dc, ic = mapping['columns']['domain'], mapping['columns']['item_count']
        editable = {(r['excel_row'], c) for r in reviewed_rows for c in (dc, ic)}
        # A target formula is source logic, never silently turn it into a constant.
        for r, c in editable:
            if ws.cell(r, c).data_type == 'f':
                raise ValueError('目标领域/项次单元格包含公式；需先解决映射目标，禁止覆盖公式')
        snapshot = _snapshot(wb, ws.title, editable)
        for item in reviewed_rows:
            ws.cell(item['excel_row'], dc).value = '；'.join(item['domains']) or None
            ws.cell(item['excel_row'], ic).value = item['item_count']
        with tempfile.TemporaryDirectory(prefix='cnas-pt-') as temporary:
            local = Path(temporary) / output.name
            wb.save(local)
            check = load(local)
            try:
                if _snapshot(check, ws.title, editable) != snapshot:
                    raise ValueError('工作簿行列/合并/其他值或公式发生变化')
                for item in reviewed_rows:
                    r = item['excel_row']
                    if check[ws.title].cell(r, ic).value != item['item_count'] or text(check[ws.title].cell(r, dc).value) != '；'.join(item['domains']):
                        raise ValueError('输出重开校验失败')
            finally:
                check.close()
            if file_hash(path) != mapping['workbook_sha256']:
                raise ValueError('源文件处理期间变化')
            output.parent.mkdir(parents=True, exist_ok=True)
            staged = output.with_name(output.name + '.partial')
            shutil.copyfile(local, staged)
            expected_hash = file_hash(local)
            if file_hash(staged) != expected_hash:
                raise ValueError('网络写入校验失败')
            os.replace(str(staged), str(output))
            if file_hash(output) != expected_hash:
                raise ValueError('输出读回 SHA256 校验失败')
        receipt = {'schema_version': '1.1.0', 'stage': 'pt.apply', 'reviewer': reviewer,
                   'source_sha256': mapping['workbook_sha256'], 'source_file': str(Path(path).resolve()),
                   'output_sha256': file_hash(output), 'output_file': str(output.resolve()),
                   'basis_fingerprint': model['basis_fingerprint'],
                   'preparation_fingerprint': mapping['preparation_fingerprint'],
                   'mapping_fingerprint': fingerprint(mapping), 'sheet': mapping['sheet'],
                   'reviewed_mapping': mapping, 'rows': reviewed_rows}
        return receipt, []
    finally:
        wb.close()
