# -*- coding: utf-8 -*-
"""Portable XLSX value reader, adapted from write-cnas-pt-summary."""
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET
from collections import OrderedDict
from datetime import date, datetime, timedelta
from pathlib import Path

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
DOC_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
BUILTIN_DATE_FORMAT_IDS = set(range(14, 23)) | set(range(27, 37)) | set(range(45, 48)) | set(range(50, 59))


class _Cell:
    def __init__(self, value=None):
        self.value = value


class _Worksheet:
    def __init__(self, title, values, max_row, max_column):
        self.title = title
        self._values = values
        self.max_row = max_row
        self.max_column = max_column

    def cell(self, row, column):
        return _Cell(self._values.get((row, column)))


class _Workbook:
    def __init__(self, sheets):
        self._sheets = OrderedDict((sheet.title, sheet) for sheet in sheets)
        self.sheetnames = list(self._sheets)

    def __getitem__(self, name):
        return self._sheets[name]

    def close(self):
        return None


def _column_number(cell_reference):
    match = re.match(r"([A-Z]+)", cell_reference.upper())
    if not match:
        return None
    number = 0
    for char in match.group(1):
        number = number * 26 + ord(char) - 64
    return number


def _xml_text(element):
    return "".join(node.text or "" for node in element.iter("{%s}t" % MAIN_NS))


def _looks_like_date_format(format_code):
    cleaned = re.sub(r'"[^"]*"|\\.|\[[^\]]*\]', "", format_code.lower())
    return bool(re.search(r"[ymdhis]", cleaned))


def _load_shared_strings(archive):
    if "xl/sharedStrings.xml" not in archive.namelist():
        return []
    root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    return [_xml_text(item) for item in root.findall("{%s}si" % MAIN_NS)]


def _load_date_style_indexes(archive):
    if "xl/styles.xml" not in archive.namelist():
        return set()
    root = ET.fromstring(archive.read("xl/styles.xml"))
    custom_formats = {}
    num_formats = root.find("{%s}numFmts" % MAIN_NS)
    if num_formats is not None:
        for element in num_formats.findall("{%s}numFmt" % MAIN_NS):
            try:
                custom_formats[int(element.get("numFmtId"))] = element.get("formatCode", "")
            except (TypeError, ValueError):
                continue
    date_styles = set()
    cell_xfs = root.find("{%s}cellXfs" % MAIN_NS)
    if cell_xfs is None:
        return date_styles
    for index, element in enumerate(cell_xfs.findall("{%s}xf" % MAIN_NS)):
        try:
            format_id = int(element.get("numFmtId", "0"))
        except ValueError:
            continue
        if format_id in BUILTIN_DATE_FORMAT_IDS or _looks_like_date_format(custom_formats.get(format_id, "")):
            date_styles.add(index)
    return date_styles


def _excel_serial_to_datetime(number, date_1904):
    epoch = datetime(1904, 1, 1) if date_1904 else datetime(1899, 12, 30)
    return epoch + timedelta(days=number)


def _cell_value(cell, shared_strings, date_styles, date_1904):
    cell_type = cell.get("t", "n")
    value_node = cell.find("{%s}v" % MAIN_NS)
    raw = value_node.text if value_node is not None and value_node.text is not None else ""
    if cell_type == "inlineStr":
        inline = cell.find("{%s}is" % MAIN_NS)
        return _xml_text(inline) if inline is not None else ""
    if cell_type == "s":
        try:
            return shared_strings[int(raw)]
        except (ValueError, IndexError):
            return raw
    if cell_type in ("str", "e", "d"):
        return raw
    if cell_type == "b":
        return raw == "1"
    if raw == "":
        return None
    try:
        number = float(raw)
    except ValueError:
        return raw
    try:
        style_index = int(cell.get("s", "0"))
    except ValueError:
        style_index = 0
    if style_index in date_styles:
        return _excel_serial_to_datetime(number, date_1904)
    return int(number) if number.is_integer() else number


def _resolve_sheet_paths(archive, workbook_root):
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    targets = {
        item.get("Id"): item.get("Target", "")
        for item in relationships.findall("{%s}Relationship" % PKG_REL_NS)
    }
    sheets = []
    sheets_node = workbook_root.find("{%s}sheets" % MAIN_NS)
    if sheets_node is None:
        return sheets
    for sheet in sheets_node.findall("{%s}sheet" % MAIN_NS):
        rel_id = sheet.get("{%s}id" % DOC_REL_NS)
        target = targets.get(rel_id, "")
        if target.startswith("/"):
            path = target.lstrip("/")
        else:
            path = posixpath.normpath(posixpath.join("xl", target))
        sheets.append((sheet.get("name", ""), path))
    return sheets


def _load_workbook_standard_library(path):
    with zipfile.ZipFile(path) as archive:
        workbook_root = ET.fromstring(archive.read("xl/workbook.xml"))
        workbook_properties = workbook_root.find("{%s}workbookPr" % MAIN_NS)
        date_1904 = workbook_properties is not None and workbook_properties.get("date1904") in ("1", "true")
        shared_strings = _load_shared_strings(archive)
        date_styles = _load_date_style_indexes(archive)
        worksheets = []
        for title, sheet_path in _resolve_sheet_paths(archive, workbook_root):
            root = ET.fromstring(archive.read(sheet_path))
            values = {}
            max_row = 0
            max_column = 0
            for cell in root.iter("{%s}c" % MAIN_NS):
                reference = cell.get("r", "")
                row_match = re.search(r"(\d+)$", reference)
                column = _column_number(reference)
                if row_match is None or column is None:
                    continue
                row = int(row_match.group(1))
                values[(row, column)] = _cell_value(cell, shared_strings, date_styles, date_1904)
                max_row = max(max_row, row)
                max_column = max(max_column, column)
            worksheets.append(_Worksheet(title, values, max_row, max_column))
    return _Workbook(worksheets)



load_workbook = _load_workbook_standard_library

def clean(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def domain_label(value):
    return re.sub(r"\s*[-—–－]\s*", "", clean(value))


def domain_signature(value):
    return re.sub(r"[\s\-\_—–－/／]+", "", clean(value)).lower()


def read_text(path):
    raw = Path(path).read_bytes()
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise ValueError("Cannot decode text file as UTF-8 or GB18030: %s" % path)


def parse_date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = clean(value)
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%Y年%m月%d日"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    match = re.search(r"(20\d{2})\D+(\d{1,2})\D+(\d{1,2})", text)
    if match:
        try:
            return date(*map(int, match.groups()))
        except ValueError:
            return None
    return None


def parse_item_times(value):
    if value is None or clean(value) == "":
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(?:项次|项)?", clean(value).replace(",", ""))
        if not match:
            return None
        number = float(match.group(1))
    if number <= 0 or not number.is_integer():
        return None
    return int(number)


def classify_result(result, remark):
    result_text = clean(result)
    remark_text = clean(remark)
    if "不满意" in result_text or "非满意" in result_text:
        return "unsatisfactory"
    if "满意" in result_text:
        return "satisfactory"
    pending_words = ("等待", "未出", "尚未", "待结果", "结果待", "待通知", "待样品")
    if any(word in result_text or word in remark_text for word in pending_words):
        return "pending"
    return "other"

