# -*- coding: utf-8 -*-
"""Authoritative unified PT adapter. Optional packages are action-local."""
import json
import os
import shutil
import tempfile
from pathlib import Path
from .basis import select_model, file_hash, fingerprint

ACTIONS = {
    'prepare': {'description': '生成逐行能力验证领域和项次审核映射', 'dependencies': ['openpyxl'], 'inputs': ['primary']},
    'apply': {'description': '复核映射并另存 Excel，保留源工作簿及阶段指纹', 'dependencies': ['openpyxl'], 'inputs': ['primary', 'mapping']},
    'summary': {'description': '按评审员和截止日生成统计诊断及可支持的 TXT', 'dependencies': [], 'inputs': ['primary']},
}


def _write(path, payload):
    path = Path(path)
    if path.exists():
        raise ValueError('禁止覆盖既有 PT 输出：%s' % path)
    content = payload if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False, indent=2) + '\n'
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='cnas-pt-json-') as directory:
        local = Path(directory) / path.name
        local.write_text(content, encoding='utf-8')
        staged = path.with_name(path.name + '.partial')
        shutil.copyfile(local, staged)
        expected = file_hash(local)
        if file_hash(staged) != expected:
            raise ValueError('PT 网络暂存文件校验失败')
        os.replace(str(staged), str(path))
        if file_hash(path) != expected:
            raise ValueError('PT 输出读回 SHA256 校验失败')
    return {'path': str(path.resolve()), 'role': 'diagnostic', 'sha256': expected}


def _prior_results(value):
    if isinstance(value, dict):
        if value.get('stage', '').startswith('pt.') and 'summary' in value:
            yield value
        for item in value.values():
            for result in _prior_results(item):
                yield result
    elif isinstance(value, list):
        for item in value:
            for result in _prior_results(item):
                yield result


def _trace(reviewer, path, sheet, rows, model):
    refs = {r['value']: r['evidence_refs'] for r in model['allowed_domains']}
    result = []
    for index, row in enumerate(rows):
        result.append({'reviewer': reviewer, 'source_file': str(Path(path).resolve()),
                       'source_sheet': sheet, 'source_row': row.get('excel_row', row.get('row')),
                       'json_pointer': '/rows/%d' % index,
                       'evidence_refs': [ref for domain in row.get('domains', []) for ref in refs.get(domain, [])] + row.get('evidence_refs', [])})
    return result


def run(action, request, context):
    if action not in ACTIONS:
        raise ValueError('未知 PT action: %s' % action)
    inputs, options = request.get('inputs', {}), request.get('options', {})
    for name in ACTIONS[action]['inputs']:
        if not inputs.get(name) or not Path(inputs[name]).is_file():
            raise ValueError('PT 缺少输入文件：%s' % name)
    output = Path(context.output_dir).resolve()
    if '文审输出' not in output.name:
        raise ValueError('PT 输出目录必须含“文审输出”')
    skill = Path(context.skill_dir).resolve()
    if output == skill or skill in output.parents:
        raise ValueError('运行期 PT 产物不得写入技能目录')
    for source in inputs.values():
        source = Path(source).resolve()
        if output == source.parent or source.parent in output.parents:
            raise ValueError('PT 输出须位于输入文件目录树之外')
    reviewer = context.reviewer or request.get('reviewer', '')
    if not reviewer:
        raise ValueError('PT 操作需要评审员，保证映射和统计可追溯')
    model = select_model(request, context)
    artifact = _write(output / 'pt_basis_model.json', model)
    artifact['role'] = 'runtime_basis_model'
    result = {'status': 'completed', 'stage': 'pt.' + action, 'artifacts': [artifact],
              'summary': {'basis_fingerprint': model['basis_fingerprint']}, 'trace': [],
              'unresolved': [], 'gates': [{'id': 'pinned_rl02', 'passed': True,
                                          'detail': '频次与统计统一使用所选版本、实施日期及来源 SHA256'}]}
    primary = inputs['primary']
    prior = list(_prior_results(context.previous_runs))
    if action == 'prepare':
        from .mapping import prepare
        mapping = prepare(primary, model, reviewer, options.get('sheet'))
        artifact = _write(output / 'pt_mapping.json', mapping)
        artifact['role'] = 'review_mapping'
        result['artifacts'].append(artifact)
        result['summary'].update({'preparation_fingerprint': mapping['preparation_fingerprint'],
                                  'workbook_sha256': mapping['workbook_sha256'], 'rows': len(mapping['rows'])})
        result['trace'] = _trace(reviewer, primary, mapping['sheet'], mapping['rows'], model)
        result['status'] = 'needs_review'
        result['unresolved'] = ['须逐行判断对象/参数/标准适用范围，填写 domains、reviewed；自动项次仅为初值']
        result['gates'].append({'id': 'semantic_row_review', 'passed': False, 'detail': result['unresolved'][0]})
    elif action == 'apply':
        from .mapping import apply
        mapping = json.loads(Path(inputs['mapping']).read_text(encoding='utf-8-sig'))
        for old in prior:
            summary = old['summary']
            if old['stage'] == 'pt.prepare' and summary.get('workbook_sha256') == file_hash(primary):
                if summary.get('preparation_fingerprint') != mapping.get('preparation_fingerprint'):
                    raise ValueError('apply 不符合本案 prepare 阶段指纹')
        workbook_output = output / ('能力验证_审核副本' + Path(primary).suffix.lower())
        receipt, missing = apply(primary, mapping, model, reviewer, workbook_output)
        result['trace'] = _trace(reviewer, primary, mapping.get('sheet', ''), mapping['rows'], model)
        if missing:
            result['status'] = 'blocked'
            result['unresolved'] = missing
            result['gates'].append({'id': 'semantic_row_review', 'passed': False, 'detail': '逐行审核未完成'})
            artifact = _write(output / 'pt_apply_diagnostics.json', {'missing': missing, 'ready_to_issue': False})
            result['artifacts'].append(artifact)
        else:
            artifact = _write(output / 'pt_apply_receipt.json', receipt)
            artifact['role'] = 'apply_receipt'
            result['artifacts'].extend([artifact, {'path': str(workbook_output.resolve()), 'role': 'reviewed_workbook', 'sha256': receipt['output_sha256']}])
            result['summary'].update({k: receipt[k] for k in ('source_sha256', 'output_sha256', 'preparation_fingerprint', 'mapping_fingerprint')})
            result['summary'].update({'total_rows': len(receipt['rows']),
                                      'matched_rows': sum(bool(r['domains']) for r in receipt['rows']),
                                      'unmatched_rows': sum(not r['domains'] for r in receipt['rows']),
                                      'multi_domain_rows': sum(len(r['domains']) > 1 for r in receipt['rows']),
                                      'item_count_overrides': sum(r['item_count_override'] is not None for r in receipt['rows']),
                                      'source_sha256_unchanged': file_hash(primary) == receipt['source_sha256']})
            result['gates'].append({'id': 'workbook_copy_verified', 'passed': True, 'detail': '重开核对源值、公式、合并、行列及源 SHA256'})
    else:
        from .summary import analyze
        receipt = json.loads(Path(inputs['receipt']).read_text(encoding='utf-8-sig')) if inputs.get('receipt') else None
        for old in prior:
            summary = old['summary']
            if old['stage'] == 'pt.apply' and summary.get('output_sha256') == file_hash(primary):
                if not receipt:
                    raise ValueError('本案组合流程须传入既有 apply receipt，保持映射指纹一致')
                for key in ('basis_fingerprint', 'mapping_fingerprint', 'preparation_fingerprint'):
                    if summary.get(key) != receipt.get(key):
                        raise ValueError('summary 与本案 apply 的 %s 不一致' % key)
        report = analyze(primary, model, reviewer, options, context.assessment_date, receipt)
        artifact = _write(output / 'pt_summary_diagnostics.json', report)
        artifact['role'] = 'summary_diagnostics'
        result['artifacts'].append(artifact)
        if report['ready_to_issue']:
            artifact = _write(output / '能力验证情况说明.txt', report['draft'] + '\n')
            artifact['role'] = 'summary_text'
            result['artifacts'].append(artifact)
        else:
            result['status'] = 'needs_review'
        result['summary'].update({'ready_to_issue': report['ready_to_issue'],
                                  'mapping_fingerprint': report['mapping_fingerprint'],
                                  'mapping_fingerprint_kind': report['mapping_fingerprint_kind'],
                                  'workbook_sha256': report['workbook_sha256'],
                                  'domain_count': len(report['domain_statistics']),
                                  'utilized_satisfactory_item_times': report['utilization']['satisfactory_item_times']})
        result['trace'] = _trace(reviewer, primary, report['inputs']['sheet'], report['reviewer_records'], model)
        for index, trace in enumerate(result['trace']):
            trace['json_pointer'] = '/reviewer_records/%d' % index
        result['unresolved'] = report['errors']
        result['gates'].append({'id': 'summary_supported', 'passed': report['ready_to_issue'],
                                'detail': '仅已确认统计领域的数量筛查及实际结果说明；不确认、分级或关闭不符合项'})
    return result
