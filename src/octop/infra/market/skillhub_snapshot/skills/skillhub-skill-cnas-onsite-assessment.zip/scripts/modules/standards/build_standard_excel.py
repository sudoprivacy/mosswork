# -*- coding: utf-8 -*-
"""Mechanical record checks and a traceable workbook; never infer source meaning."""
from collections import defaultdict
from pathlib import Path
import re

from ._io import relative, verify_inventory

FIELDS = ['standard_number', 'standard_name', 'category', 'parameter', 'clause',
          'references', 'multiple_methods', 'method_name', 'equipment_or_standards',
          'source_file', 'evidence', 'notes']
HEADERS = ['标准编号', '标准名称', '标准类别', '项目或参数名称', '对应的条款编号',
           '引用标准编号及名称（如适用）', '是否对同一种参数存在一种以上的检测方法',
           '每种检测方法的名称', '每种检测方法所需的关键仪器设备或标准品',
           '源文件', '证据定位/短摘录', '说明']


def validate_records(inventory, records, source_root=None):
    """Public API used by capability. Return report; technical schema faults raise."""
    if isinstance(records, dict):
        records = records.get('records', [])
    if not isinstance(records, list):
        raise ValueError('records must be an array or a records document')
    items = inventory.get('files', [])
    if not isinstance(items, list):
        raise ValueError('inventory.files must be an array')
    paths = [relative(x['relative_path']) for x in items]
    if len(paths) != len(set(x.casefold() for x in paths)):
        raise ValueError('Duplicate inventory physical paths')
    coverage, groups, warnings = defaultdict(int), defaultdict(list), []
    exact = set()
    for i, row in enumerate(records):
        if not isinstance(row, dict):
            raise ValueError('Record %d is not an object' % (i + 1))
        for field in FIELDS:
            if not isinstance(row.get(field), str):
                raise ValueError('Record %d requires string %s' % (i + 1, field))
            if field != 'notes' and not row[field].strip():
                raise ValueError('Record %d has empty required %s' % (i + 1, field))
        category = row['category']
        if category not in {'产品标准', '判定标准', '检测标准'} and not category.startswith('需人工确认'):
            raise ValueError('Record %d has invalid category' % (i + 1))
        if row['multiple_methods'] not in {'是', '否'}:
            raise ValueError('Record %d multiple_methods must be 是/否' % (i + 1))
        source = relative(row['source_file'])
        if source not in paths:
            raise ValueError('Record source not in physical inventory: %s' % source)
        coverage[source] += 1
        groups[(row['standard_number'].strip(), row['parameter'].strip())].append((i, row))
        identity = tuple(row[x] for x in FIELDS)
        if identity in exact:
            warnings.append(dict(kind='重复记录', record_index=i, detail='Same core/evidence fields repeated'))
        exact.add(identity)
        if category.startswith('需人工确认') or '需人工确认' in row['clause']:
            warnings.append(dict(kind='原文待核', record_index=i, detail=row['notes'] or category))
    for (number, parameter), group in groups.items():
        names = {s.strip() for _, row in group for s in re.split('[;；\n]+', row['method_name']) if s.strip()}
        flags = {row['multiple_methods'] for _, row in group}
        # Slash is NOT treated as proof of two methods (e.g. LC/MS).
        if '是' in flags and len(names) < 2:
            warnings.append(dict(kind='多方法证据不足', record_indices=[x[0] for x in group],
                                 detail='%s / %s: only one explicit method name' % (number, parameter)))
        if flags == {'否'} and len(names) > 1:
            warnings.append(dict(kind='多方法标记疑点', record_indices=[x[0] for x in group],
                                 detail='%s / %s: distinct methods all marked 否' % (number, parameter)))
        if len(flags) > 1:
            warnings.append(dict(kind='多方法标记不一致', record_indices=[x[0] for x in group],
                                 detail='%s / %s' % (number, parameter)))
    missing, changed = verify_inventory(inventory, source_root)
    uncovered = sorted(set(paths) - set(coverage))
    pending = [x['relative_path'] for x in items
               if x.get('status') != 'ok' or x.get('needs_ocr') or not x.get('extracted_text_chars')]
    complete = bool(items and records) and not (missing or changed or uncovered or pending)
    return dict(coverage_passed=complete, file_count=len(items), record_count=len(records),
                coverage=dict(coverage), missing_files=missing, changed_files=changed,
                uncovered_files=uncovered, pending_files=pending, warnings=warnings,
                standard_numbers=sorted({x['standard_number'] for x in records}),
                multiple_method_records=sum(x['multiple_methods'] == '是' for x in records))


def validate_documents(inventory, record_doc):
    return validate_records(inventory, record_doc)


def style_sheet(ws, widths):
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.fill = PatternFill('solid', fgColor='1F4E78')
        cell.font = Font(color='FFFFFF', bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical='center')
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical='top')
            # Original standard text beginning '=' must remain text, never a formula.
            if cell.data_type == 'f':
                cell.data_type = 's'
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[1].height = 42


def build_workbook(inventory, record_doc, output):
    from openpyxl import Workbook, load_workbook
    report = validate_records(inventory, record_doc)
    records = record_doc.get('records', [])
    wb = Workbook()
    ws = wb.active
    ws.title = '结构化提取'
    ws.append(HEADERS + ['records JSON Pointer', '源文件SHA256'])
    hashes = {x['relative_path']: x.get('sha256', '') for x in inventory['files']}
    for i, row in enumerate(records):
        ws.append([row[f] for f in FIELDS] + ['/records/%d' % i, hashes.get(relative(row['source_file']), '')])
    widths = [23, 40, 18, 30, 25, 45, 18, 35, 50, 55, 40, 40, 25, 68]
    style_sheet(ws, widths)
    wi = wb.create_sheet('文件清单与覆盖检查')
    wi.append(['相对路径', '字节数', '页数', '原生文本字符数', '实际文本字符数', '需OCR',
               '实际方式', '状态', '记录数', 'SHA256', '说明'])
    for item in inventory['files']:
        wi.append([item['relative_path'], item['size_bytes'], item.get('page_count'),
                   item.get('native_text_chars'), item.get('extracted_text_chars'),
                   '是' if item.get('needs_ocr') else '否', item.get('extraction_mode'),
                   item.get('status'), report['coverage'].get(item['relative_path'], 0),
                   item.get('sha256'), item.get('notes')])
    style_sheet(wi, [62, 14, 10, 18, 18, 10, 28, 20, 12, 68, 55])
    wm = wb.create_sheet('一参多法复核')
    wm.append(HEADERS)
    for row in records:
        if row['multiple_methods'] == '是':
            wm.append([row[f] for f in FIELDS])
    style_sheet(wm, widths)
    ww = wb.create_sheet('质量警告')
    ww.append(['类型', '内容', '记录索引（0起）'])
    for warning in report['warnings']:
        ww.append([warning['kind'], warning['detail'], str(warning.get('record_indices', warning.get('record_index', '')))])
    for key in ['missing_files', 'changed_files', 'uncovered_files', 'pending_files']:
        for value in report[key]:
            ww.append([key, value, ''])
    if ww.max_row == 1:
        ww.append(['程序检查通过', '仍需评审员核对原文、方法独立性及OCR准确性。', ''])
    style_sheet(ww, [25, 100, 28])
    wn = wb.create_sheet('处理说明')
    wn.append(['项目', '说明'])
    wn.append(['覆盖门槛', '通过' if report['coverage_passed'] else '未通过：仅为诊断工作簿，不能声明提取完成'])
    wn.append(['语义分析', 'records由Agent/评审员逐份核对；程序不推断条款、仪器或标准内容。'])
    wn.append(['多方法', '方法名数量仅为机械检查；原理、程序、仲裁/替代法需查原文。'])
    wn.append(['标准品', 'CRM、标准溶液、内标等与各方法分别对应，不从其他文件反向补造。'])
    style_sheet(wn, [25, 110])
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Save locally, replace, then reopen from actual target (including network filesystems).
    import tempfile
    import os
    fd, temp = tempfile.mkstemp(suffix='.xlsx')
    os.close(fd)
    try:
        wb.save(temp)
        from ._io import atomic_bytes
        atomic_bytes(path, Path(temp).read_bytes())
    finally:
        os.unlink(temp)
    reopened = load_workbook(str(path), read_only=True, data_only=False)
    try:
        if reopened['结构化提取'].max_row != len(records) + 1 or len(reopened.sheetnames) != 5:
            raise ValueError('Workbook readback failed')
    finally:
        reopened.close()
    return report
