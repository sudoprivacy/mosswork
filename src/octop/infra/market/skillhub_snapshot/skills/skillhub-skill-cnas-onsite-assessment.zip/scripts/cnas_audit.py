#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline CNAS source lookup and case records. Original implementation, MIT.

Python 3.8+, standard library only. This tool records human decisions; it does
not decide applicability, nonconformity, severity, or accreditation outcomes.
"""
import argparse
import base64
import collections
import contextlib
import copy
import datetime
import hashlib
import html
import json
import lzma
import os
from pathlib import Path
import re
import sys
import tempfile
import uuid
from urllib.parse import quote, unquote, urlsplit, urlunsplit

SKILL_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_VERSION = "1.0.0"
STATUSES = ("pending_confirmation", "confirmed", "rectifying", "pending_verification", "verified", "closed")
KINDS = ("scope", "checklist", "evidence", "experiment", "interview", "finding", "verification", "task", "report_note")
DISPLAY_LABELS = {
    "pending_confirmation": "待确认", "confirmed": "已确认", "rectifying": "整改中",
    "pending_verification": "待验证", "verified": "验证通过", "closed": "已关闭",
    "scope": "评审范围", "checklist": "检查计划", "evidence": "证据", "experiment": "试验 / 见证",
    "interview": "访谈", "finding": "评审发现", "verification": "验证记录", "task": "任务", "report_note": "报告备注",
    "nc": "不符合项", "observation": "观察项", "pending": "待核实", "general": "一般", "serious": "严重", "unassigned": "未分级",
}
VERIFY_STATES = {"extracted", "source_compared", "visually_checked", "unresolved"}
DOCUMENT_STORAGE = "cnas-json-lzma-base85-v1"
ASSET_STORAGE = "cnas-assets-lzma-base85-v1"
MAX_EXPANDED_BYTES = 64 * 1024 * 1024
LZMA_MEMORY_LIMIT = 128 * 1024 * 1024
BLOB_KEYS = {"data", "data_base64", "source_image_base64"}
TRANSITIONS = {
    "pending_confirmation": {"confirmed"},
    "confirmed": {"rectifying", "pending_verification"},
    "rectifying": {"pending_verification"},
    "pending_verification": {"verified", "rectifying"},
    "verified": {"closed", "rectifying"},
    "closed": set(),
}


class AuditError(Exception):
    def __init__(self, message, code="invalid_request", details=None):
        super().__init__(message)
        self.code, self.details = code, details


def require(test, message, code="integrity_error", details=None):
    if not test:
        raise AuditError(message, code, details)


def utcnow():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    expected = Path(path).stat().st_size
    count = 0
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
            count += len(chunk)
    require(count == expected == Path(path).stat().st_size, "Incomplete or changing file read: " + str(path))
    return h.hexdigest()


def parse_json_bytes(data, label):
    def unique_keys(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    try:
        return json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique_keys,
                          parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise AuditError("Cannot read JSON: " + str(label), "invalid_json", str(exc))


def read_raw_json(path):
    try:
        return parse_json_bytes(Path(path).read_bytes(), path)
    except OSError as exc:
        raise AuditError("Cannot read JSON: " + str(path), "invalid_json", str(exc))


def valid_sha(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def decode_transport(wrapper, expected_format):
    require(isinstance(wrapper, dict) and wrapper.get("storage_format") == expected_format and wrapper.get("encoding") == "lzma-base85", "Invalid transport wrapper")
    size = wrapper.get("uncompressed_bytes")
    require(isinstance(size, int) and not isinstance(size, bool) and 0 <= size <= MAX_EXPANDED_BYTES, "Transport declared size exceeds limit", "storage_limit")
    payload = wrapper.get("payload")
    require(isinstance(payload, str) and len(payload) <= (MAX_EXPANDED_BYTES + 1024 * 1024) * 5 // 4, "Invalid or oversized transport payload", "storage_limit")
    try:
        encoded = payload.encode("ascii")
        compressed = base64.b85decode(encoded)
        require(base64.b85encode(compressed) == encoded, "Noncanonical Base85 payload")
        if "payload_sha256" in wrapper:
            require(valid_sha(wrapper["payload_sha256"]) and hashlib.sha256(compressed).hexdigest() == wrapper["payload_sha256"], "Compressed payload hash mismatch")
        decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=LZMA_MEMORY_LIMIT)
        data = decoder.decompress(compressed, max_length=size + 1)
        require(len(data) <= size, "Transport output exceeds declared size", "storage_limit")
        require(len(data) == size and decoder.eof and not decoder.unused_data, "Truncated transport, length mismatch, or trailing/concatenated stream")
    except (UnicodeError, ValueError, lzma.LZMAError) as exc:
        raise AuditError("Invalid compressed transport payload", "invalid_storage", str(exc))
    result = parse_json_bytes(data, "decoded transport")
    require(canonical(result) == data, "Transport JSON must use the canonical representation")
    return result


def asset_path(document_path, wrapper):
    relative = wrapper.get("assets_file")
    sha = wrapper.get("assets_sha256")
    require(valid_sha(sha) and relative == "_assets/" + sha + ".json", "Invalid content-addressed asset path", "unsafe_path")
    return child_path(Path(document_path).resolve().parent, relative)


def load_assets(document_path, wrapper, asset_cache=None):
    path = asset_path(document_path, wrapper)
    require(path.is_file() and file_hash(path) == wrapper["assets_sha256"], "Missing or modified transport assets")
    cache_key = (str(path), wrapper["assets_sha256"])
    if asset_cache is not None and cache_key in asset_cache:
        return asset_cache[cache_key]
    assets = read_raw_json(path)
    values = decode_transport(assets, ASSET_STORAGE)
    require(isinstance(values, dict) and valid_sha(assets.get("content_sha256")) and digest(values) == assets["content_sha256"], "Asset content hash mismatch")
    require(all(valid_sha(key) and isinstance(value, str) and hashlib.sha256(value.encode("utf-8")).hexdigest() == key for key, value in values.items()), "Invalid asset key, value, or blob hash")
    if asset_cache is not None:
        asset_cache[cache_key] = values
    return values


def restore_blobs(value, blobs, within_figures=False):
    if isinstance(value, dict):
        if set(value) == {"__cnas_blob__"}:
            key = value["__cnas_blob__"]
            require(within_figures and isinstance(key, str) and key in blobs, "Missing or misplaced transport blob")
            return blobs[key]
        return {k: restore_blobs(v, blobs, within_figures or k == "figures") for k, v in value.items()}
    return [restore_blobs(v, blobs, within_figures) for v in value] if isinstance(value, list) else value


def read_json(path, asset_cache=None):
    value = read_raw_json(path)
    if not isinstance(value, dict) or value.get("storage_format") not in {DOCUMENT_STORAGE, ASSET_STORAGE}:
        return value
    if value["storage_format"] == ASSET_STORAGE:
        result = decode_transport(value, ASSET_STORAGE)
        require(isinstance(result, dict) and valid_sha(value.get("content_sha256")) and digest(result) == value["content_sha256"], "Asset content hash mismatch")
        require(all(valid_sha(k) and isinstance(v, str) and hashlib.sha256(v.encode("utf-8")).hexdigest() == k for k, v in result.items()), "Invalid asset blob mapping")
        return result
    template = decode_transport(value, DOCUMENT_STORAGE)
    result = restore_blobs(template, load_assets(path, value, asset_cache))
    require(isinstance(result, dict) and valid_sha(value.get("content_sha256")) and digest(result) == value["content_sha256"], "Restored document content hash mismatch")
    for key in ("schema_version", "corpus_version", "document"):
        require(key in value and value[key] == result.get(key), "Transport metadata mismatch: " + key)
    return result


def transport_wrapper(value, storage_format, preset=6):
    data = canonical(value)
    require(len(data) <= MAX_EXPANDED_BYTES, "Transport source exceeds uncompressed limit", "storage_limit")
    compressed = lzma.compress(data, format=lzma.FORMAT_XZ, preset=preset)
    return {"storage_format": storage_format, "encoding": "lzma-base85", "content_sha256": digest(value),
            "uncompressed_bytes": len(data), "payload_sha256": hashlib.sha256(compressed).hexdigest(),
            "payload": base64.b85encode(compressed).decode("ascii")}


def detach_blobs(original, blobs):
    def visit(value, within_figures=False):
        if isinstance(value, dict):
            require(set(value) != {"__cnas_blob__"}, "Original document collides with reserved transport blob marker")
            result = {}
            for key, item in value.items():
                if within_figures and key in BLOB_KEYS and isinstance(item, str) and len(item) > 128:
                    sha = hashlib.sha256(item.encode("utf-8")).hexdigest()
                    blobs.setdefault(sha, item)
                    result[key] = {"__cnas_blob__": sha}
                else:
                    result[key] = visit(item, within_figures or key == "figures")
            return result
        return [visit(v, within_figures) for v in value] if isinstance(value, list) else value
    return visit(original)


def atomic_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        expected = hashlib.sha256(data).hexdigest()
        with tempfile.TemporaryFile() as staged:
            staged.write(data)
            staged.flush()
            os.fsync(staged.fileno())
            staged.seek(0)
            with tempfile.NamedTemporaryFile(dir=str(path.parent), prefix=".cnas-", delete=False) as f:
                name = f.name
                for chunk in iter(lambda: staged.read(1024 * 1024), b""):
                    f.write(chunk)
                f.flush()
                os.fsync(f.fileno())
        require(file_hash(name) == expected, "Atomic staging readback hash mismatch")
        os.replace(name, str(path))
        require(file_hash(path) == expected, "Atomic target readback hash mismatch")
    finally:
        if name and os.path.exists(name):
            os.unlink(name)


def atomic_json(path, value):
    atomic_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def below(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def external_path(path):
    result = Path(path).expanduser().resolve()
    require(not below(result, SKILL_ROOT), "Runtime cases and reports must be outside the skill directory", "unsafe_path")
    return result


def child_path(root, relative):
    require(isinstance(relative, str) and relative and "\\" not in relative,
            "Invalid relative archive path", "unsafe_path")
    require(not Path(relative).is_absolute() and not re.match(r"^[A-Za-z]:", relative),
            "Absolute paths are forbidden", "unsafe_path")
    root = Path(root).resolve()
    target = (root / relative).resolve()
    require(below(target, root) and target != root, "Path escapes its container", "unsafe_path")
    return target


def iso_date(value):
    if value:
        try:
            datetime.date.fromisoformat(value)
        except (TypeError, ValueError):
            raise AuditError("Date must use YYYY-MM-DD", "invalid_date")
    return value


def verification(value, label):
    require(isinstance(value, dict) and value.get("state") in VERIFY_STATES and isinstance(value.get("notes"), str),
            "Invalid verification at " + label)


def keyed(items, label):
    require(isinstance(items, list), label + " must be a list")
    result = {}
    for item in items:
        require(isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"], "Missing ID in " + label)
        require(item["id"] not in result, "Duplicate ID in " + label + ": " + item["id"])
        result[item["id"]] = item
    return result


def validate_document(doc, entry=None):
    require(isinstance(doc, dict) and doc.get("schema_version") == SCHEMA_VERSION, "Unsupported document schema")
    for name in ("document", "source", "coverage"):
        require(isinstance(doc.get(name), dict), "Missing " + name)
    meta, source = doc["document"], doc["source"]
    for name in ("doc_id", "code", "title", "version", "revision", "kind"):
        require(isinstance(meta.get(name), str) and meta[name], "Missing document." + name)
    require(isinstance(meta.get("applicable_objects"), list) and isinstance(meta.get("domains"), list), "Missing applicability metadata")
    require(meta.get("currency_status") in {"as_supplied_not_current_verified", "verified", "historical", "future", "uncertain"}, "Invalid currency status")
    verification(meta.get("verification"), "document")
    for name in ("published_date", "effective_date"):
        require(name in meta, "Missing document." + name)
        iso_date(meta[name])
    require(re.fullmatch(r"[0-9a-fA-F]{64}", source.get("sha256", "")) is not None, "Invalid source hash")
    require(source.get("format") in {"pdf", "doc"}, "Unsupported source format")
    require(isinstance(source.get("official_urls"), list), "Missing official URLs")
    for name in ("file_name", "relative_archive_path", "extraction_method", "rights_note"):
        require(isinstance(source.get(name), str), "Missing source." + name)
    child_path(Path("."), source["relative_archive_path"])
    blocks = keyed(doc.get("blocks"), "blocks")
    clauses = keyed(doc.get("clauses"), "clauses")
    units = keyed(doc.get("units"), "units")
    tables = keyed(doc.get("tables"), "tables")
    figures = keyed(doc.get("figures"), "figures")
    require(isinstance(doc.get("relations"), list), "Missing relations")

    def refs(item, name, pool, required=True):
        value = item.get(name)
        require(isinstance(value, list) if required else value is None or isinstance(value, list), "Invalid " + name)
        if value is not None:
            require(all(isinstance(v, str) and v in pool for v in value), "Unresolved reference in " + name)
            require(len(value) == len(set(value)), "Duplicate reference in " + name)
        return value or []

    pages = doc.get("pages")
    require(isinstance(pages, list) and pages, "Missing pages")
    pnums, seen_blocks = set(), []
    for page in pages:
        pn = page.get("page")
        require(isinstance(pn, int) and not isinstance(pn, bool) and pn > 0 and pn not in pnums, "Invalid/duplicate page")
        pnums.add(pn)
        ids = refs(page, "block_refs", blocks)
        seen_blocks.extend(ids)
        text = "".join(blocks[b]["text"] for b in ids)
        actual = hashlib.sha256(text.encode("utf-8")).hexdigest()
        require(page.get("reconstructed_text_sha256") == actual, "Page reconstruction hash mismatch: " + str(pn))
        require(isinstance(page.get("source_text_sha256"), str) and re.fullmatch(r"[0-9a-fA-F]{64}", page["source_text_sha256"]), "Missing source page text hash")
        require(page["source_text_sha256"].lower() == actual, "Extracted source/page reconstruction hash mismatch: " + str(pn))
        require(page.get("text_chars") == len(text), "Page character count mismatch")
        require(all(blocks[b].get("page") == pn for b in ids), "Block/page mismatch")
        verification(page.get("verification"), "page")
    require(sorted(pnums) == list(range(1, len(pages) + 1)), "Physical pages must be contiguous from 1")
    require(len(seen_blocks) == len(set(seen_blocks)) and set(seen_blocks) == set(blocks), "Every block must belong to exactly one page")
    for block in blocks.values():
        require(isinstance(block.get("text"), str), "Invalid block text")
        require(block.get("kind") in {"text", "heading", "list_item", "note", "table_text", "layout", "figure_caption"}, "Invalid block kind")
        require(isinstance(block.get("source_position"), dict) and isinstance(block["source_position"].get("line"), int) and block["source_position"]["line"] > 0, "Missing source line")
        verification(block.get("verification"), "block")
    for clause in clauses.values():
        full = refs(clause, "block_refs", blocks)
        own = refs(clause, "own_block_refs", blocks)
        require(set(own) <= set(full), "Own blocks outside full clause")
        refs(clause, "unit_ids", units)
        kids = refs(clause, "child_ids", clauses)
        require(clause.get("parent_id") is None or clause.get("parent_id") in clauses, "Unknown clause parent")
        require(clause.get("parent_id") != clause["id"], "Clause cannot be its own parent")
        for cid in kids:
            require(clauses[cid].get("parent_id") == clause["id"], "Clause parent/child mismatch")
            require(set(clauses[cid]["block_refs"]) <= set(full), "Child text missing from full clause")
        trail, current = set(), clause
        while current.get("parent_id"):
            require(current["id"] not in trail, "Clause parent cycle")
            trail.add(current["id"])
            current = clauses[current["parent_id"]]
        for uid in clause["unit_ids"]:
            require(units[uid].get("clause_id") == clause["id"], "Unit/clause mismatch")
    for unit in units.values():
        for name in ("block_refs", "context_refs", "condition_refs", "note_refs"):
            refs(unit, name, blocks)
        require(unit.get("clause_id") is None or unit.get("clause_id") in clauses, "Unknown unit clause")
        require(unit.get("parent_unit_id") is None or unit.get("parent_unit_id") in units, "Unknown parent unit")
        verification(unit.get("verification"), "unit")
    for table in tables.values():
        refs(table, "block_refs", blocks)
        refs(table, "footnote_refs", blocks)
        require(table.get("derived_view") is True, "Tables must be marked derived views")
        require(isinstance(table.get("rows"), list) and isinstance(table.get("columns"), list), "Invalid table structure")
        for row in table["rows"]:
            require(isinstance(row.get("cells"), list), "Invalid table row")
            for cell in row["cells"]:
                require(isinstance(cell.get("text"), str) and isinstance(cell.get("rowspan"), int) and cell["rowspan"] > 0 and isinstance(cell.get("colspan"), int) and cell["colspan"] > 0, "Invalid table cell")
        verification(table.get("verification"), "table")
    for figure in figures.values():
        refs(figure, "block_refs", blocks)
        verification(figure.get("verification"), "figure")
    coverage = doc["coverage"]
    counts = {"page_count": len(pages), "pages_with_text": sum(bool(p["text_chars"]) for p in pages), "block_count": len(blocks), "clause_count": len(clauses), "unit_count": len(units), "table_count": len(tables)}
    for name, value in counts.items():
        require(coverage.get(name) == value, "Coverage count mismatch: " + name)
    require(coverage.get("status") in {"complete", "needs_review", "failed"}, "Invalid coverage status")
    require(isinstance(coverage.get("unresolved"), list) and isinstance(coverage.get("page_checks"), list) and isinstance(coverage.get("section_inventory"), list), "Missing coverage audit")
    checks = coverage["page_checks"]
    require(len(checks) == len(pages) and {p.get("page") for p in checks} == pnums, "Page checks must cover every physical page")
    require(all(p.get("text_reconstruction_ok") is True for p in checks), "Page reconstruction check failed")
    if coverage["status"] == "complete":
        require(not coverage["unresolved"], "Complete coverage cannot contain unresolved items")
    if entry:
        for key in ("doc_id", "code", "version", "revision", "title", "domains", "applicable_objects", "effective_date", "currency_status"):
            require(entry.get(key) == meta.get(key), "Index/document metadata mismatch: " + key)
        for key in ("clause_count", "unit_count"):
            require(entry.get(key) == counts[key], "Index/document count mismatch: " + key)
        require(entry.get("coverage_status") == coverage["status"], "Index coverage status mismatch")
    return counts


class Corpus:
    def __init__(self, path=None):
        path = Path(path) if path else SKILL_ROOT / "references" / "cnas" / "index.json"
        self.index_path = path / "index.json" if path.is_dir() else path
        self.root = self.index_path.resolve().parent
        self.index = read_json(self.index_path)
        self.asset_cache = {}
        require(self.index.get("schema_version") == SCHEMA_VERSION and isinstance(self.index.get("documents"), list), "Invalid corpus index")
        ids = set()
        for entry in self.index["documents"]:
            require(entry.get("doc_id") not in ids and entry.get("doc_id"), "Duplicate or missing index ID")
            ids.add(entry["doc_id"])
            child_path(self.root, entry.get("path"))
            require(re.fullmatch(r"[0-9a-fA-F]{64}", entry.get("sha256", "")) is not None, "Missing index document hash")

    def entries(self, code=None, version=None, revision=None, domain=None, obj=None):
        entries = self.index["documents"]
        return [e for e in entries if (code is None or e["code"] == code)
                and (version is None or e["version"] == version)
                and (revision is None or e["revision"] == revision)
                and (domain is None or domain in e.get("domains", []) or "general" in e.get("domains", []))
                and (obj is None or obj in e.get("applicable_objects", []) or "all" in e.get("applicable_objects", []))]

    def load(self, entry):
        path = child_path(self.root, entry["path"])
        require(file_hash(path) == entry["sha256"], "Corpus file hash mismatch: " + entry["doc_id"])
        doc = read_json(path, self.asset_cache)
        if "storage_format" in entry:
            envelope = read_raw_json(path)
            require(entry["storage_format"] == DOCUMENT_STORAGE and envelope.get("storage_format") == DOCUMENT_STORAGE, "Index transport format mismatch")
            require(entry.get("content_sha256") == digest(doc) and valid_sha(entry.get("source_json_sha256")), "Index transport provenance mismatch")
        validate_document(doc, entry)
        return doc


def select_entry(entries):
    require(bool(entries), "No exact matching document edition", "not_found")
    require(len(entries) == 1, "Document edition is ambiguous; specify version/revision", "ambiguous_document", entries)
    return entries[0]


def assemble(doc, refs):
    blocks = {b["id"]: b for b in doc["blocks"]}
    return {"block_refs": refs, "text": "".join(blocks[b]["text"] for b in refs),
            "pages": sorted({blocks[b]["page"] for b in refs}),
            "blocks": [blocks[b] for b in refs]}


def lookup_document(doc, entry, clause=None, unit=None, clause_id=None, assessment_date=None, include_figure_data=False):
    clauses = {c["id"]: c for c in doc["clauses"]}
    units = {u["id"]: u for u in doc["units"]}
    if unit:
        require(unit in units, "Unit does not exist in this edition", "not_found")
        selected_units = [units[unit]]
        selected_clause = clauses.get(units[unit]["clause_id"])
    else:
        matches = [c for c in clauses.values() if (c["id"] == clause_id if clause_id else c["official_number"] == clause)]
        candidates = [{"id": c["id"], "official_number": c["official_number"], "title": c["title"], "pages": assemble(doc, c["block_refs"])["pages"]} for c in matches]
        require(bool(matches), "Clause does not exist in this edition", "not_found")
        require(len(matches) == 1, "Official clause number has multiple structural occurrences; choose --clause-id or --unit", "ambiguous_clause", candidates)
        selected_clause = matches[0]
        selected_units = [units[u] for u in selected_clause["unit_ids"]]
    contents = []
    for u in selected_units:
        item = copy.deepcopy(u)
        item["original"] = assemble(doc, u["block_refs"])
        item["assembled_context"] = {"derived_view": True, "introductory_context": assemble(doc, u["context_refs"]),
                                     "conditions": assemble(doc, u["condition_refs"]), "notes": assemble(doc, u["note_refs"])}
        contents.append(item)
    warnings = []
    meta = doc["document"]
    if meta["currency_status"] != "verified":
        warnings.append("Supplied edition currency has not been established as current for this assessment.")
    if assessment_date:
        iso_date(assessment_date)
        if meta.get("effective_date") and meta["effective_date"] > assessment_date:
            warnings.append("Selected edition takes effect after the assessment date.")
    if doc["coverage"]["status"] != "complete":
        warnings.append("Corpus coverage requires review; consult unresolved items and original source.")
    selected_refs = set(selected_clause["block_refs"] if selected_clause else [])
    for item in selected_units:
        for field in ("block_refs", "context_refs", "condition_refs", "note_refs"):
            selected_refs.update(item[field])
    selected_pages = set(assemble(doc, list(selected_refs))["pages"])
    related_tables = [copy.deepcopy(t) for t in doc["tables"] if selected_refs.intersection(t["block_refs"])]
    related_figures = [copy.deepcopy(f) for f in doc["figures"] if selected_refs.intersection(f["block_refs"]) or (not f["block_refs"] and selected_pages.intersection(f.get("pages", [])))]
    if not include_figure_data:
        def omit_bytes(value):
            if isinstance(value, dict):
                out = {}
                omitted = []
                for k, v in value.items():
                    if any(token in k.lower() for token in ("base64", "data_uri", "image_data", "raster_data")) or (k == "data" and isinstance(v, str) and len(v) > 128):
                        omitted.append({"field": k, "characters": len(v) if isinstance(v, str) else None})
                    else:
                        out[k] = omit_bytes(v)
                if omitted:
                    out["omitted_binary_fields"] = omitted
                return out
            return [omit_bytes(v) for v in value] if isinstance(value, list) else value
        related_figures = omit_bytes(related_figures)
    return {"document": copy.deepcopy(meta), "corpus_version": doc.get("corpus_version"),
            "document_sha256": entry["sha256"], "source": copy.deepcopy(doc["source"]),
            "clause": dict(copy.deepcopy(selected_clause), original=assemble(doc, selected_clause["block_refs"])) if selected_clause else None,
            "units": contents, "tables": related_tables, "figures": related_figures, "coverage": copy.deepcopy(doc["coverage"]),
            "assessment_date": assessment_date, "warnings": warnings,
            "interpretation": "Original text is preserved in blocks; linked context is an assembled derived view. Applicability and conclusions require reviewer judgment."}


@contextlib.contextmanager
def case_lock(directory):
    directory = external_path(directory)
    require(directory.is_dir(), "Case directory does not exist", "not_found")
    lock = directory / ".case.lock"
    try:
        fd = os.open(str(lock), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise AuditError("Case is locked by another operation; inspect stale lock before removing it", "case_locked")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(str(os.getpid()))
        yield directory
    finally:
        lock.unlink()


def case_hash(case):
    payload = {k: v for k, v in case.items() if k != "integrity_sha256"}
    return digest(payload)


def history_event(case, event, record_id=None, details=None):
    previous = case["history"][-1]["sha256"] if case["history"] else None
    item = {"sequence": len(case["history"]) + 1, "at": utcnow(), "event": event,
            "record_id": record_id, "details": details or {}, "previous_sha256": previous}
    item["sha256"] = digest(item)
    case["history"].append(item)
    return item


def record_state(record):
    """Recoverable state, without recursive history references."""
    return copy.deepcopy({k: v for k, v in record.items() if k != "history"})


def save_case(directory, case):
    case["updated_at"] = utcnow()
    case["integrity_sha256"] = case_hash(case)
    atomic_json(Path(directory) / "case.json", case)


def read_case(directory):
    directory = external_path(directory)
    case = read_json(directory / "case.json")
    require(case.get("schema_version") == SCHEMA_VERSION and isinstance(case.get("case_id"), str), "Invalid case schema")
    require(case.get("integrity_sha256") == case_hash(case), "Case content hash mismatch")
    require(re.fullmatch(r"[A-Za-z0-9_-]{1,80}", case["case_id"]) is not None, "Invalid case ID")
    require(isinstance(case.get("records"), list) and isinstance(case.get("snapshots"), list) and isinstance(case.get("history"), list), "Invalid case collections")
    previous = None
    for number, event in enumerate(case["history"], 1):
        require(event.get("sequence") == number and event.get("previous_sha256") == previous, "Broken case history sequence")
        require(event.get("sha256") == digest({k: v for k, v in event.items() if k != "sha256"}), "Broken history event hash")
        previous = event["sha256"]
    snapshots, asset_cache = {}, {}
    for snap in case["snapshots"]:
        require(snap.get("doc_id") not in snapshots, "Duplicate snapshot ID")
        path = child_path(directory, snap.get("path"))
        require(file_hash(path) == snap.get("sha256"), "Pinned snapshot hash mismatch")
        doc = read_json(path, asset_cache)
        validate_document(doc, snap["index_entry"])
        require(snap["doc_id"] == doc["document"]["doc_id"] and snap["sha256"] == snap["index_entry"]["sha256"], "Snapshot metadata mismatch")
        snapshots[snap["doc_id"]] = (snap, doc)
    ids = set()
    for record in case["records"]:
        require(record.get("id", "").startswith(case["case_id"] + ":F") and record["id"] not in ids, "Invalid/foreign case record ID")
        ids.add(record["id"])
        validate_record(record, snapshots, case.get("assessment_date"))
        refs = record.get("history")
        require(isinstance(refs, list) and refs and all(isinstance(n, int) and 1 <= n <= len(case["history"]) for n in refs), "Invalid record history references")
        require(refs == sorted(set(refs)), "Duplicate or unordered record history references")
        events = [case["history"][n - 1] for n in refs]
        require(all(e.get("record_id") == record["id"] for e in events), "Foreign record history reference")
        last = events[-1]["details"]
        state = last.get("after", last.get("initial_record"))
        if state is not None:
            require(state == record_state(record), "Record state differs from its latest historical snapshot")
    if "workflow" in case:
        from module_common import validate_workflow
        validate_workflow(case, directory)
    return case, snapshots


def evidence_valid(value):
    return isinstance(value, list) and all(
        (isinstance(v, str) and bool(v.strip())) or
        (isinstance(v, dict) and isinstance(v.get("description"), str) and bool(v["description"].strip()) and ("url" not in v or isinstance(v["url"], str))) for v in value)


def evidence_present(value):
    return bool(value) and evidence_valid(value)


def validate_record(record, snapshots, assessment_date):
    require(record.get("kind", "finding") in KINDS, "Invalid record kind")
    require(record.get("status") in STATUSES, "Unknown record status")
    require(record.get("finding_type") in {"nc", "observation", "pending"}, "Invalid finding type")
    require(record.get("severity") in {"general", "serious", "unassigned"}, "Invalid severity")
    require(isinstance(record.get("facts"), str) and evidence_valid(record.get("evidence")), "Invalid facts/evidence")
    value = record.get("verification")
    if value is not None:
        require(isinstance(value, dict) and evidence_valid(value.get("evidence")), "Invalid verification evidence")
    for field in ("title", "notes", "assignee", "site"):
        require(field not in record or isinstance(record[field], str), "Invalid " + field)
    require("scope_refs" not in record or (isinstance(record["scope_refs"], list) and all(isinstance(v, str) for v in record["scope_refs"])), "Invalid scope_refs")
    require(isinstance(record.get("basis"), list), "Invalid basis")
    for basis in record["basis"]:
        require(basis.get("doc_id") in snapshots, "Basis references an unpinned document")
        snap, doc = snapshots[basis["doc_id"]]
        expected = lookup_document(doc, snap["index_entry"], unit=basis.get("unit_id"), clause_id=basis.get("clause_id") if not basis.get("unit_id") else None, assessment_date=assessment_date)
        require(basis.get("original_citation") == expected, "Protected original citation changed")
    if record["status"] != "pending_confirmation":
        confirmation_requirements(record)
    if record["status"] in {"verified", "closed"}:
        verification_requirements(record.get("verification"), "accepted")


def confirmation_requirements(record):
    require(record["facts"].strip(), "Formal confirmation requires recorded facts", "confirmation_required")
    if record.get("kind", "finding") == "finding":
        require(record["finding_type"] != "pending", "Pending finding type cannot be formally confirmed", "confirmation_required")
        require(evidence_present(record["evidence"]) and record["basis"], "Formal finding confirmation requires facts, evidence, and exact pinned basis", "confirmation_required")
        for basis in record["basis"]:
            citation = basis["original_citation"]
            meta, date = citation["document"], citation.get("assessment_date")
            require(not (meta.get("effective_date") and date and meta["effective_date"] > date), "Future-effective basis cannot confirm a finding for an earlier assessment date", "basis_not_effective")
            require(not (meta.get("currency_status") == "future" and not date), "Future edition requires a dated assessment before confirmation", "basis_not_effective")
    rc = record.get("reviewer_confirmation")
    require(isinstance(rc, dict) and rc.get("confirmed") is True and isinstance(rc.get("reviewer"), str) and rc["reviewer"].strip(), "Reviewer confirmation is required", "confirmation_required")


def verification_requirements(value, result):
    require(isinstance(value, dict) and evidence_present(value.get("evidence")) and isinstance(value.get("reviewer"), str) and value["reviewer"].strip() and value.get("result") == result, "Verification requires evidence, reviewer, and explicit " + result + " result", "verification_required")


def pin_document(directory, case, corpus, entry):
    existing = [s for s in case["snapshots"] if s["doc_id"] == entry["doc_id"]]
    if existing:
        snap = existing[0]
        path = child_path(directory, snap["path"])
        require(file_hash(path) == snap["sha256"], "Pinned snapshot hash mismatch")
        return read_json(path), snap["index_entry"]
    doc = corpus.load(entry)
    if case.get("corpus_version") is None:
        case["corpus_version"] = doc.get("corpus_version")
    require(re.fullmatch(r"[A-Za-z0-9_.-]+", entry["doc_id"]) is not None, "Document ID is unsafe for snapshots")
    relative = "snapshots/" + entry["doc_id"] + ".json"
    source = child_path(corpus.root, entry["path"])
    envelope = read_raw_json(source)
    if isinstance(envelope, dict) and envelope.get("storage_format") == DOCUMENT_STORAGE:
        load_assets(source, envelope)
        original_asset = asset_path(source, envelope)
        snapshot_asset = asset_path(child_path(directory, relative), envelope)
        if snapshot_asset.exists():
            require(file_hash(snapshot_asset) == envelope["assets_sha256"], "Existing snapshot asset is corrupted")
        else:
            atomic_bytes(snapshot_asset, original_asset.read_bytes())
            require(file_hash(snapshot_asset) == envelope["assets_sha256"], "Snapshot asset copy hash mismatch")
    atomic_bytes(child_path(directory, relative), source.read_bytes())
    case["snapshots"].append({"doc_id": entry["doc_id"], "path": relative, "sha256": entry["sha256"], "index_entry": copy.deepcopy(entry)})
    history_event(case, "document_pinned", details={"doc_id": entry["doc_id"], "sha256": entry["sha256"]})
    return doc, entry


def choose_with_case(corpus, args, directory=None, case=None):
    options = dict(code=args.document, version=args.version, revision=args.revision, domain=getattr(args, "domain", None), obj=getattr(args, "object", None))
    # Once an edition is pinned, use it even if the installed corpus changed.
    if case:
        pinned = [s["index_entry"] for s in case["snapshots"]]
        filtered = [e for e in pinned if e["code"] == args.document and e["version"] == args.version and (args.revision is None or e["revision"] == args.revision)]
        if filtered:
            filtered = [e for e in filtered if
                        (options["domain"] is None or options["domain"] in e.get("domains", []) or "general" in e.get("domains", []))
                        and (options["obj"] is None or options["obj"] in e.get("applicable_objects", []) or "all" in e.get("applicable_objects", []))]
            entry = select_entry(filtered)
            snap = next(s for s in case["snapshots"] if s["doc_id"] == entry["doc_id"])
            return read_json(child_path(directory, snap["path"])), entry
    corpus = corpus if isinstance(corpus, Corpus) else Corpus(corpus)
    entry = select_entry(corpus.entries(**options))
    return pin_document(directory, case, corpus, entry) if case is not None else (corpus.load(entry), entry)


def lookup_command(args):
    corpus = args.corpus
    if args.case_dir:
        with case_lock(args.case_dir) as directory:
            case, _ = read_case(directory)
            doc, entry = choose_with_case(corpus, args, directory, case)
            result = lookup_document(doc, entry, args.clause, args.unit, args.clause_id, args.assessment_date or case.get("assessment_date"), args.include_figure_data)
            save_case(directory, case)
            result["case_id"] = case["case_id"]
            result["pinned"] = True
            return result
    doc, entry = choose_with_case(corpus, args)
    return lookup_document(doc, entry, args.clause, args.unit, args.clause_id, args.assessment_date, args.include_figure_data)


def make_basis(spec, directory, case, corpus):
    require(isinstance(spec, dict), "Each basis must be an object", "invalid_request")
    require(isinstance(spec.get("document"), str) and isinstance(spec.get("version"), str), "Basis requires exact document and version", "invalid_request")
    require(sum(bool(spec.get(k)) for k in ("clause", "unit", "clause_id")) == 1, "Basis requires exactly one of clause/unit/clause_id", "invalid_request")
    args = argparse.Namespace(document=spec["document"], version=spec["version"], revision=spec.get("revision"))
    doc, entry = choose_with_case(corpus, args, directory, case)
    result = lookup_document(doc, entry, spec.get("clause"), spec.get("unit"), spec.get("clause_id"), case.get("assessment_date"))
    return {"doc_id": entry["doc_id"], "clause_id": result["clause"]["id"] if result["clause"] else None,
            "unit_id": spec.get("unit"), "original_citation": result}


def case_record(args):
    data = read_json(args.input)
    require(isinstance(data, dict), "Record input must be an object", "invalid_request")
    with case_lock(args.case_dir) as directory:
        case, _ = read_case(directory)
        corpus = args.corpus
        allowed = {"kind", "finding_type", "severity", "facts", "evidence", "basis", "reviewer_confirmation", "status", "title", "notes", "assignee", "site", "scope_refs"}
        require(not set(data) - allowed, "Unknown record input fields", "invalid_request", sorted(set(data) - allowed))
        status = data.get("status", "pending_confirmation")
        require(status in {"pending_confirmation", "confirmed"}, "Create pending or confirmed records; use transitions for later states", "invalid_transition")
        number = max([int(r["id"].split(":F")[-1]) for r in case["records"]] + [0]) + 1
        rid = case["case_id"] + ":F" + str(number).zfill(4)
        record = {"id": rid, "kind": data.get("kind", "finding"), "title": data.get("title", ""), "finding_type": data.get("finding_type", "pending"),
                  "severity": data.get("severity", "unassigned"), "status": status,
                  "facts": data.get("facts", ""), "evidence": data.get("evidence", []),
                  "basis": [make_basis(s, directory, case, corpus) for s in data.get("basis", [])],
                  "reviewer_confirmation": data.get("reviewer_confirmation"), "verification": None,
                  "notes": data.get("notes", ""), "created_at": utcnow(), "updated_at": utcnow(), "history": []}
        for name in ("assignee", "site", "scope_refs"):
            if name in data:
                record[name] = data[name]
        asset_cache = {}
        snaps = {s["doc_id"]: (s, read_json(child_path(directory, s["path"]), asset_cache)) for s in case["snapshots"]}
        validate_record(record, snaps, case.get("assessment_date"))
        event = history_event(case, "record_created", rid, {"status": status, "initial_record": record_state(record), "record_sha256": digest(record)})
        record["history"].append(event["sequence"])
        case["records"].append(record)
        save_case(directory, case)
        return {"case_id": case["case_id"], "record": record}


def case_transition(args):
    data = read_json(args.input) if args.input else {}
    require(isinstance(data, dict), "Transition input must be an object", "invalid_request")
    require(not set(data) - {"reviewer_confirmation", "verification", "facts", "evidence", "basis", "finding_type", "severity", "notes"}, "Unknown transition input fields", "invalid_request")
    with case_lock(args.case_dir) as directory:
        case, _ = read_case(directory)
        matches = [r for r in case["records"] if r["id"] == args.record_id]
        require(len(matches) == 1, "Record does not belong to this case", "not_found")
        record = matches[0]
        previous_state = record_state(record)
        before = record["status"]
        reason = args.reason or ""
        if args.action == "withdraw":
            require(args.to == "pending_confirmation" and before != "pending_confirmation" and reason.strip(), "Withdrawal requires a reason and pending_confirmation destination", "invalid_transition")
            record["reviewer_confirmation"] = None
            record["verification"] = None
        elif args.action == "reopen":
            require(before == "closed" and args.to == "rectifying" and reason.strip(), "Reopening requires a closed record, rectifying destination and reason", "invalid_transition")
            record["verification"] = None
        else:
            require(args.to in TRANSITIONS[before], "State jump is not allowed: " + before + " -> " + args.to, "invalid_transition")
        editing = set(data) & {"facts", "evidence", "basis", "finding_type", "severity", "notes"}
        require(not editing or before == "pending_confirmation", "Amend facts/classification/basis only while pending; withdraw first", "invalid_transition")
        for key in editing - {"basis"}:
            record[key] = data[key]
        if "basis" in data:
            corpus = args.corpus
            record["basis"] = [make_basis(s, directory, case, corpus) for s in data["basis"]]
        if "reviewer_confirmation" in data:
            require(args.to == "confirmed", "Reviewer confirmation belongs to confirmed transition", "invalid_transition")
            record["reviewer_confirmation"] = data["reviewer_confirmation"]
        if args.to == "verified":
            verification_requirements(data.get("verification"), "accepted")
            record["verification"] = data["verification"]
        elif before == "pending_verification" and args.to == "rectifying" and args.action == "transition":
            verification_requirements(data.get("verification"), "rejected")
            record["verification"] = data["verification"]
        elif "verification" in data:
            raise AuditError("Verification data is only accepted for verification result transitions", "invalid_transition")
        elif args.to == "rectifying":
            record["verification"] = None
        record["status"] = args.to
        record["updated_at"] = utcnow()
        asset_cache = {}
        snaps = {s["doc_id"]: (s, read_json(child_path(directory, s["path"]), asset_cache)) for s in case["snapshots"]}
        validate_record(record, snaps, case.get("assessment_date"))
        event = history_event(case, args.action, record["id"], {"from": before, "to": args.to, "reason": reason, "submitted": data, "before": previous_state, "after": record_state(record)})
        record["history"].append(event["sequence"])
        save_case(directory, case)
        return {"case_id": case["case_id"], "record": record}


def counts_for(case):
    findings = [r for r in case["records"] if r.get("kind", "finding") == "finding"]
    return {"total": len(case["records"]), "by_status": {s: sum(r["status"] == s for r in case["records"]) for s in STATUSES},
            "by_kind": {s: sum(r.get("kind", "finding") == s for r in case["records"]) for s in KINDS},
            "by_finding_type": {s: sum(r["finding_type"] == s for r in findings) for s in ("nc", "observation", "pending")},
            "by_severity": {s: sum(r["severity"] == s for r in findings) for s in ("general", "serious", "unassigned")}}


def safe_link(value):
    if not isinstance(value, str) or not value or any(ord(c) < 32 or ord(c) == 127 for c in value):
        return None
    decoded = value
    for _ in range(8):
        next_value = unquote(decoded)
        if next_value == decoded:
            break
        decoded = next_value
    else:
        return None
    if any(ord(c) < 32 or ord(c) == 127 for c in decoded) or "\\" in decoded:
        return None
    try:
        parsed, decoded_url = urlsplit(value), urlsplit(decoded)
    except ValueError:
        return None
    if parsed.scheme in {"https", "http"} and parsed.netloc and not parsed.username and not parsed.password and decoded_url.scheme in {"https", "http"}:
        return value
    if not parsed.scheme and not parsed.netloc and not decoded_url.scheme and not decoded_url.netloc and not decoded.startswith(("/", "\\")) and ".." not in decoded_url.path.split("/"):
        return value
    return None


def evidence_href(value, case_dir=None, report_dir=None):
    value = safe_link(value)
    if not value or case_dir is None or report_dir is None or urlsplit(value).scheme:
        return value
    parsed = urlsplit(value)
    decoded_path = unquote(parsed.path)
    for _ in range(7):
        if unquote(decoded_path) == decoded_path:
            break
        decoded_path = unquote(decoded_path)
    try:
        target = child_path(case_dir, decoded_path)
        relative = os.path.relpath(str(target), str(report_dir)).replace(os.sep, "/")
    except (AuditError, OSError, ValueError):
        return None
    return urlunsplit(("", "", quote(relative, safe="/"), parsed.query, parsed.fragment))


def render_evidence(values, case_dir=None, report_dir=None):
    result = []
    for value in values:
        label = value if isinstance(value, str) else value.get("description", "") if isinstance(value, dict) else str(value)
        url = evidence_href(value.get("url", ""), case_dir, report_dir) if isinstance(value, dict) else None
        text = html.escape(label)
        if url:
            text += ' <a href="' + html.escape(url, quote=True) + '" rel="noopener noreferrer">链接</a>'
        result.append("<li>" + text + "</li>")
    return "<ul>" + "".join(result) + "</ul>" if result else "—"


def render_report(case, case_dir=None, report_dir=None):
    from module_common import render_workflow
    esc = lambda value: html.escape(str(value), quote=True)
    display_label = lambda value: DISPLAY_LABELS.get(value, value) + " (" + value + ")"
    anchor = lambda record: "record-" + hashlib.sha256(record["id"].encode("utf-8")).hexdigest()
    rows = []
    for record in case["records"]:
        bases = []
        seen_context = set()
        for basis in record["basis"]:
            citation = basis["original_citation"]
            meta, source = citation["document"], citation["source"]
            clause = citation["clause"]
            excerpt = citation["units"][0]["original"] if basis.get("unit_id") else clause["original"]
            body = '<strong>' + esc(meta["code"] + " / " + meta["version"] + " / " + meta["revision"]) + '</strong><br>'
            body += '条款：' + esc(clause["official_number"] if clause else "无编号") + '；内部ID：' + esc(basis.get("unit_id") or basis.get("clause_id"))
            body += '；物理页：' + esc(", ".join(map(str, excerpt["pages"])))
            body += '<pre>' + esc(excerpt["text"]) + '</pre>'
            for unit in citation["units"]:
                ctx = unit["assembled_context"]
                for key, label in (("introductory_context", "关联引言"), ("conditions", "适用条件"), ("notes", "相关注")):
                    context_key = (citation["document_sha256"], key, tuple(ctx[key]["block_refs"]))
                    if ctx[key]["text"] and context_key not in seen_context:
                        body += '<details><summary>' + label + '（组装视图）</summary><pre>' + esc(ctx[key]["text"]) + '</pre></details>'
                        seen_context.add(context_key)
            body += '<small>来源 SHA-256：' + esc(source["sha256"]) + '<br>文档 SHA-256：' + esc(citation["document_sha256"]) + '<br>核验：' + esc(meta["verification"]["state"]) + '；' + esc(meta["verification"]["notes"]) + '<br>时效：' + esc(meta["currency_status"]) + '</small>'
            if citation["warnings"]:
                body += '<ul>' + ''.join('<li>' + esc(w) + '</li>' for w in citation["warnings"]) + '</ul>'
            verification_groups = collections.OrderedDict()
            for item in citation["units"]:
                state = item["verification"]
                verification_groups.setdefault((state["state"], state["notes"]), []).append(item["id"])
            for (state, notes), unit_ids in verification_groups.items():
                body += '<small class="unit-verification">单元核验：' + esc(state) + '；单元 ID：' + esc(', '.join(unit_ids)) + '<br>' + esc(notes) + '</small><br>'
            bases.append(body)
        confirmation = record.get("reviewer_confirmation") or {}
        verification_data = record.get("verification") or {}
        verification_html = esc(verification_data.get("result", "待核验")) + '<br>' + esc(verification_data.get("reviewer", "")) + render_evidence(verification_data.get("evidence", []), case_dir, report_dir)
        searchable = " ".join(str(record.get(k, "")) for k in ("id", "kind", "title", "facts", "finding_type", "severity", "status", "notes", "assignee", "site", "scope_refs"))
        workflow = '<dl><dt>记录种类</dt><dd>' + esc(display_label(record.get("kind", "finding"))) + '</dd><dt>负责人</dt><dd>' + esc(record.get("assignee", "")) + '</dd><dt>场所</dt><dd>' + esc(record.get("site", "")) + '</dd><dt>范围关联</dt><dd>' + esc(', '.join(record.get("scope_refs", []))) + '</dd><dt>备注 / 待核事项</dt><dd><pre>' + esc(record.get("notes", "")) + '</pre></dd></dl>'
        rows.append('<tr id="' + anchor(record) + '" tabindex="-1" data-status="' + esc(record["status"]) + '" data-search="' + esc(searchable.lower()) + '"><th scope="row">' + esc(record["id"]) + '<br>' + esc(record["title"]) + workflow + '</th><td>' + esc(display_label(record["finding_type"])) + '<br>' + esc(display_label(record["severity"])) + '<br>' + esc(display_label(record["status"])) + '</td><td><pre>' + esc(record["facts"]) + '</pre>' + render_evidence(record["evidence"], case_dir, report_dir) + '</td><td>' + '<hr>'.join(bases) + '</td><td>' + esc(confirmation.get("reviewer", "待确认")) + '</td><td>' + verification_html + '</td></tr>')
    counts = counts_for(case)
    template = (SKILL_ROOT / "assets" / "report.html").read_text(encoding="utf-8")
    replacements = {"TITLE": esc(case["title"]), "CASE_ID": esc(case["case_id"]), "DATE": esc(case.get("assessment_date") or "未指定"),
                    "COUNTS": esc(json.dumps(counts, ensure_ascii=False, sort_keys=True)), "ROWS": "".join(rows),
                    "STATUS_OPTIONS": "".join('<option value="' + s + '">' + esc(display_label(s)) + '</option>' for s in STATUSES),
                    "RECORD_OPTIONS": "".join('<option value="' + anchor(r) + '">' + esc(r["id"] + ' · ' + r["title"]) + '</option>' for r in case["records"]),
                    "DRAFT": "辅助评审草稿。已确认状态仅表示记录中留有评审员确认；统计不构成认可或合规结论。",
                    "MODULES": render_workflow(case, case_dir, report_dir)}
    return re.sub(r"@@([A-Z_]+)@@", lambda m: replacements[m.group(1)], template)


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", help="Corpus index.json or its directory (default: bundled corpus)")
    sub = parser.add_subparsers(dest="command", required=True)
    def command(name, help_text):
        p = sub.add_parser(name, help=help_text)
        p.add_argument("--corpus", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
        return p
    p = command("catalog", "List indexed metadata without loading document bodies")
    p.add_argument("--document"); p.add_argument("--version"); p.add_argument("--revision")
    p.add_argument("--domain"); p.add_argument("--object")
    p = command("lookup", "Return exact source clause/unit with linked context and provenance")
    p.add_argument("--document", required=True); p.add_argument("--version", required=True); p.add_argument("--revision")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--clause"); g.add_argument("--unit"); g.add_argument("--clause-id")
    p.add_argument("--domain"); p.add_argument("--object"); p.add_argument("--assessment-date", type=iso_date); p.add_argument("--case-dir")
    p.add_argument("--include-figure-data", action="store_true", help="Include optional embedded figure bytes; ordinary lookup omits them")
    p = command("related", "Show explicit cross-document relationships; no inferred content")
    p.add_argument("--document", required=True); p.add_argument("--version", required=True); p.add_argument("--revision")
    p = command("corpus-validate", "Check hashes, source reconstruction, IDs, references and coverage counts")
    p = command("case-init", "Create an isolated case outside the skill")
    p.add_argument("--case-dir", required=True); p.add_argument("--title", required=True); p.add_argument("--case-id"); p.add_argument("--assessment-date", type=iso_date)
    p = command("case-record", "Create a fact-based finding; exact basis is resolved and pinned")
    p.add_argument("--case-dir", required=True); p.add_argument("--input", required=True, help="UTF-8 JSON record file")
    p = command("case-transition", "Apply a validated human-confirmed state transition")
    p.add_argument("--case-dir", required=True); p.add_argument("--record-id", required=True)
    p.add_argument("--to", required=True, choices=STATUSES); p.add_argument("--input")
    p.add_argument("--action", choices=("transition", "withdraw", "reopen"), default="transition"); p.add_argument("--reason")
    p = command("case-validate", "Validate case integrity, pinned sources and record requirements")
    p.add_argument("--case-dir", required=True)
    p = command("report", "Export escaped standalone HTML or JSON with identical counts")
    p.add_argument("--case-dir", required=True); p.add_argument("--format", choices=("html", "json"), default="html"); p.add_argument("--output", required=True)
    return parser


def run(args):
    if args.command == "catalog":
        corpus = Corpus(args.corpus)
        return {"schema_version": SCHEMA_VERSION, "corpus_version": corpus.index.get("corpus_version"), "documents": corpus.entries(args.document, args.version, args.revision, args.domain, args.object)}
    if args.command == "lookup":
        return lookup_command(args)
    if args.command == "related":
        corpus = Corpus(args.corpus)
        entry = select_entry(corpus.entries(args.document, args.version, args.revision))
        doc = corpus.load(entry)
        return {"document": doc["document"], "relations": doc["relations"], "note": "Relations are explicit source metadata; cited external text is not included or inferred."}
    if args.command == "corpus-validate":
        corpus = Corpus(args.corpus)
        results = []
        for entry in corpus.entries():
            doc = corpus.load(entry)
            results.append({"doc_id": entry["doc_id"], "counts": validate_document(doc, entry), "coverage_status": doc["coverage"]["status"], "unresolved_count": len(doc["coverage"]["unresolved"])})
        return {"valid": True, "documents": len(results), "results": results, "note": "Structural integrity validation is distinct from source visual verification, semantic table completeness and current applicability."}
    if args.command == "case-init":
        directory = external_path(args.case_dir)
        require(not (directory / "case.json").exists(), "Case already exists", "already_exists")
        directory.mkdir(parents=True, exist_ok=True)
        require(not any(directory.iterdir()), "Initialize an empty directory to prevent cross-case mixing", "invalid_request")
        cid = args.case_id or "case-" + uuid.uuid4().hex[:12]
        require(re.fullmatch(r"[A-Za-z0-9_-]{1,80}", cid) is not None, "case-id must use 1-80 ASCII letters, digits, hyphens or underscores", "invalid_request")
        case = {"schema_version": SCHEMA_VERSION, "case_id": cid, "title": args.title,
                "assessment_date": args.assessment_date, "corpus_version": None, "created_at": utcnow(), "updated_at": utcnow(),
                "records": [], "snapshots": [], "history": []}
        with case_lock(directory):
            history_event(case, "case_created")
            save_case(directory, case)
        return {"case_id": cid, "case_dir": str(directory), "created": True}
    if args.command == "case-record":
        return case_record(args)
    if args.command == "case-transition":
        return case_transition(args)
    if args.command in {"case-validate", "report"}:
        with case_lock(args.case_dir) as directory:
            case, snapshots = read_case(directory)
            if args.command == "case-validate":
                return {"valid": True, "case_id": case["case_id"], "counts": counts_for(case), "pinned_documents": len(snapshots), "history_events": len(case["history"])}
            output = external_path(args.output)
            require(not below(output, directory / "snapshots") and output != directory / "case.json" and output != directory / ".case.lock", "Report cannot overwrite protected case files", "unsafe_path")
            require(not below(output, directory / "inputs") and not below(output, directory / "artifacts"), "Report cannot overwrite module inputs or artifacts", "unsafe_path")
            if args.format == "html":
                atomic_bytes(output, render_report(case, directory, output.parent).encode("utf-8"))
            else:
                atomic_json(output, {"case": case, "counts": counts_for(case), "draft": True, "note": "Auxiliary assessment draft; human confirmations are recorded per finding. Counts do not establish compliance."})
            return {"case_id": case["case_id"], "output": str(output), "format": args.format, "counts": counts_for(case), "draft": True}
    raise AuditError("Unknown command")


def main(argv=None):
    try:
        args = build_parser().parse_args(argv)
        result = run(args)
        print(json.dumps({"ok": True, "result": result}, ensure_ascii=False, indent=2))
        return 0
    except AuditError as exc:
        print(json.dumps({"ok": False, "error": {"code": exc.code, "message": str(exc), "details": exc.details}}, ensure_ascii=False, indent=2))
        return 2
    except (OSError, KeyError, TypeError, ValueError, AttributeError) as exc:
        print(json.dumps({"ok": False, "error": {"code": "invalid_data", "message": str(exc)}}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    sys.exit(main())
