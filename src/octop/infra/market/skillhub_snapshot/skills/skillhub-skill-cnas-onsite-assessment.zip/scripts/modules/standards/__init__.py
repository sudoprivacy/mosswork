# -*- coding: utf-8 -*-
"""Shared physical-document extraction; semantic records are reviewer supplied."""
