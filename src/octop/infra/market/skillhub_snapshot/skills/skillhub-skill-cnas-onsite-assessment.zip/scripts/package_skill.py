#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build offline target ZIPs from one metadata source; never publish. MIT."""
import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import sys
import tempfile
import zipfile
from urllib.parse import unquote, urlsplit

from cnas_audit import (ASSET_STORAGE, DOCUMENT_STORAGE, AuditError, Corpus, SKILL_ROOT,
                        below, canonical, detach_blobs, digest, read_json, require,
                        transport_wrapper, file_hash)

TARGET_BYTE_LIMIT = 10000000


def compact_corpus(files, corpus, preset=6):
    """Lossless per-document transport with one content-addressed image mapping."""
    compression = preset | lzma.PRESET_EXTREME if preset == 9 else preset
    blobs, templates, originals = {}, {}, {}
    for entry in corpus.entries():
        require("/" not in entry["path"] and "\\" not in entry["path"], "Compact transport requires document JSONs beside index.json", "unsupported_corpus_layout")
        original = corpus.load(entry)
        originals[entry["doc_id"]] = original
        templates[entry["doc_id"]] = detach_blobs(original, blobs)
    asset = canonical(transport_wrapper(blobs, ASSET_STORAGE, compression))
    asset_sha = hashlib.sha256(asset).hexdigest()
    asset_relative = "_assets/" + asset_sha + ".json"
    for name in list(files):
        if name.startswith("references/cnas/_assets/"):
            del files[name]
    files["references/cnas/" + asset_relative] = asset
    index = dict(corpus.index, documents=[])
    for entry in corpus.entries():
        original = originals[entry["doc_id"]]
        wrapper = transport_wrapper(templates[entry["doc_id"]], DOCUMENT_STORAGE, compression)
        wrapper.update(schema_version=original["schema_version"], corpus_version=original["corpus_version"],
                       document=original["document"], content_sha256=digest(original),
                       assets_file=asset_relative, assets_sha256=asset_sha)
        physical = canonical(wrapper)
        files["references/cnas/" + entry["path"]] = physical
        updated = dict(entry, sha256=hashlib.sha256(physical).hexdigest(), storage_format=DOCUMENT_STORAGE,
                       content_sha256=digest(original), source_json_sha256=entry.get("source_json_sha256", entry["sha256"]))
        index["documents"].append(updated)
    files["references/cnas/index.json"] = canonical(index)
    return {"storage_format": DOCUMENT_STORAGE, "unique_image_blobs": len(blobs), "compression_preset": preset, "extreme": preset == 9}


def frontmatter(meta, target, author=None, slug=None):
    required = ("name", "description", "version", "license", "metadata",
                "display_name", "display_name_en", "description_zh", "description_en")
    require(all(k in meta for k in required), "Canonical package metadata is incomplete")
    fields = {k: meta[k] for k in ("name", "description", "license")}
    fields["metadata"] = dict(meta["metadata"])
    compatibility = meta.get("compatibility", meta["metadata"].get("compatibility"))
    require(isinstance(compatibility, str) and compatibility.strip(), "Canonical compatibility metadata is missing")
    fields["metadata"]["compatibility"] = compatibility
    if target == "skillhub":
        selected_slug = slug or meta["name"]
        require(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", selected_slug) is not None, "Invalid SkillHub slug")
        fields.update(slug=selected_slug, version=meta["version"], displayName=meta["display_name"], summary=meta["description_zh"])
    elif target == "workbuddy":
        require(isinstance(author, str) and author.strip(), "WorkBuddy requires --author; publisher identity cannot be inferred", "author_required")
        fields.update({k: meta[k] for k in ("display_name", "display_name_en", "description_zh", "description_en", "version")})
        fields["author"] = author.strip()
    # JSON scalar/mapping syntax is valid YAML and avoids a YAML dependency.
    return "---\n" + "\n".join(k + ": " + json.dumps(v, ensure_ascii=False) for k, v in fields.items()) + "\n---\n"


def build(source, target, output, author=None, slug=None, compression_preset=9):
    source, output = Path(source).resolve(), Path(output).resolve()
    require(not below(output, source), "Package output must be outside the skill tree", "unsafe_path")
    require(output.suffix.lower() == ".zip", "--output must name a .zip file")
    meta = read_json(source / "references" / "package_metadata.json")
    generated = frontmatter(meta, target, author, slug)
    skill = (source / "SKILL.md").read_text(encoding="utf-8-sig")
    match = re.match(r"\A---\s*\n.*?\n---\s*\n", skill, re.DOTALL)
    require(match is not None, "SKILL.md must start with YAML frontmatter")
    corpus = Corpus(source / "references" / "cnas" / "index.json")
    require(corpus.entries(), "Cannot package an empty corpus")
    for entry in corpus.entries():
        corpus.load(entry)
    include_roots = {"scripts", "references", "assets", "agents"}
    root_files = {"SKILL.md", "LICENSE", "LICENSE.md", "NOTICE", "NOTICE.md", "THIRD_PARTY_NOTICES.md", "THIRD_PARTY_NOTICES.txt"}
    excluded_suffixes = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".zip", ".pyc", ".pyo", ".tmp", ".bak", ".log"}
    excluded_parts = {"__pycache__", ".git", ".pytest_cache", "tests", "cases", "runtime", "build", "dist", "node_modules"}
    files = {}
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(source)
        if set(relative.parts) & excluded_parts or any(p.startswith(".") for p in relative.parts):
            continue
        if (len(relative.parts) == 1 and relative.name not in root_files) or (len(relative.parts) > 1 and relative.parts[0] not in include_roots):
            continue
        if path.suffix.lower() in excluded_suffixes:
            continue
        require(not path.is_symlink() and below(path, source), "Symlink or file escape in package", "unsafe_path")
        content = path.read_bytes()
        require(len(content) == path.stat().st_size and hashlib.sha256(content).hexdigest() == file_hash(path), "Incomplete or changing package source read: " + relative.as_posix())
        files[relative.as_posix()] = content
    files["SKILL.md"] = (generated + skill[match.end():]).encode("utf-8")
    storage = {"storage_format": "plain-json"}
    if target in {"skillhub", "workbuddy"}:
        storage = compact_corpus(files, corpus, compression_preset)
    # Reference links must resolve in the archive, including licensing notices.
    for link in re.findall(r"\[[^\]]*\]\(([^)]+)\)", skill[match.end():]):
        target_link = link.strip().split()[0].strip("<>")
        parsed = urlsplit(target_link)
        if parsed.scheme or parsed.netloc or not parsed.path:
            continue
        path = unquote(parsed.path)
        require(not path.startswith(("/", "\\")) and "\\" not in path and ".." not in path.split("/"), "Unsafe SKILL.md reference link: " + target_link)
        require(path in files, "SKILL.md reference is absent from package: " + path, "missing_reference")
    manifest = {"schema_version": "1.0.0", "target": target, "name": meta["name"], "version": meta["version"],
                "corpus_version": corpus.index.get("corpus_version"),
                "storage": storage,
                "canonical_metadata_sha256": hashlib.sha256(canonical(meta)).hexdigest(),
                "files": [{"path": p, "sha256": hashlib.sha256(data).hexdigest()} for p, data in sorted(files.items())],
                "publication": "Not published; offline package only."}
    files["package-manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    expanded_bytes = sum(len(value) for value in files.values())
    if target in {"skillhub", "workbuddy"}:
        require(expanded_bytes < TARGET_BYTE_LIMIT, "Target expanded package exceeds 10,000,000 bytes; retry --compression-preset 9 without omitting content", "package_size_limit", {"uncompressed_bytes": expanded_bytes})
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        fd, temporary = tempfile.mkstemp(prefix=".cnas-package-", suffix=".zip", dir=str(output.parent))
        os.close(fd)
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(files.items()):
                info = zipfile.ZipInfo(name, (2020, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                archive.writestr(info, data)
        if target in {"skillhub", "workbuddy"}:
            require(os.path.getsize(temporary) < TARGET_BYTE_LIMIT, "Target ZIP exceeds 10,000,000 bytes", "package_size_limit")
        os.replace(temporary, str(output))
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
    return {"target": target, "output": str(output), "files": len(files), "documents": len(corpus.entries()),
            "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "zip_bytes": output.stat().st_size,
            "uncompressed_bytes": expanded_bytes, "storage": storage, "published": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=("standard", "skillhub", "workbuddy"), required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--author", help="Required only for WorkBuddy; actual author is never invented")
    parser.add_argument("--slug", help="SkillHub slug; defaults to canonical skill name")
    parser.add_argument("--source", default=str(SKILL_ROOT), help="Skill root; defaults to this script's parent skill")
    parser.add_argument("--compression-preset", type=int, choices=(6, 9), default=9, help="Lossless LZMA preset; 9 uses EXTREME to fit full 1.1.0 content within target limits")
    args = parser.parse_args(argv)
    try:
        print(json.dumps({"ok": True, "result": build(args.source, args.target, args.output, args.author, args.slug, args.compression_preset)}, ensure_ascii=False, indent=2))
        return 0
    except (AuditError, OSError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": {"code": getattr(exc, "code", "package_error"), "message": str(exc), "details": getattr(exc, "details", None)}}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    sys.exit(main())
