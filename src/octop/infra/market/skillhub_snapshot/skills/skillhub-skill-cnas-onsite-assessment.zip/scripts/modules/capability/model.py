# -*- coding: utf-8 -*-
"""Input model, explicit column mapping and read-only evidence checks."""
import hashlib
import json
import os
import re
import unicodedata
import tempfile
from pathlib import Path

PRIMARY = 'object_id category_zh object_sequence object_zh energy_star bluetooth parameter_id parameter_sequence parameter_zh field_codes method_id method_sequence method_zh standard_no clause limitation change_note recommended recommender object_id_en category_en object_sequence_en object_en parameter_id_en parameter_sequence_en parameter_en method_id_en method_sequence_en method_en standard_no_en clause_en limitation_en change_note_en'.split()
SUPPLEMENT = 'category_no object_zh object_en energy_star contains_all bluetooth parameter_zh parameter_en is_all field_codes appendix_expand method_zh method_en standard_no standard_no_en clause clause_en limitation limitation_en change_note change_note_en start_date tests_last_2_years equipment_ids assessment_assignment'.split()
EQUIPMENT = 'equipment_id type name model_spec measurement_range metrological_spec traceability_method confirmed note'.split()


def text(value):
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('JSON存在重复键：' + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding='utf-8-sig'), object_pairs_hook=unique)


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    temporary.write_bytes(payload)
    os.replace(str(temporary), str(path))
    if path.read_bytes() != payload:
        raise ValueError('输出回读不一致：' + str(path))


def atomic_save(save, path):
    """Stage OOXML locally; replace beneath the allocated output; read back hash."""
    path = Path(path)
    descriptor, local = tempfile.mkstemp(suffix=path.suffix)
    os.close(descriptor)
    try:
        save(local)
        payload = Path(local).read_bytes()
        temporary = path.with_name(path.name + '.tmp')
        temporary.write_bytes(payload)
        os.replace(str(temporary), str(path))
        if sha256(path) != hashlib.sha256(payload).hexdigest():
            raise ValueError('输出回读hash不一致：' + str(path))
    finally:
        os.unlink(local)


def reviewer_matches(record, reviewer):
    if not reviewer:
        return True
    assignment = text(record.get('operational', {}).get('assessment_assignment'))
    value = assignment or text(record.get('application', {}).get('recommender'))
    return reviewer in [x for x in re.split(r'[,，;；/、\s]+', value) if x]


def norm_standard(value):
    value = unicodedata.normalize('NFKC', text(value)).upper()
    value = value.translate(str.maketrans({'–': '-', '—': '-', '−': '-'}))
    # Keep punctuation that distinguishes standard identities; only normalize
    # whitespace and the common year colon/hyphen convention mechanically.
    value = re.sub(r'(?<=\d):(?=\d{4}(?:\D|$))', '-', value)
    return re.sub(r'\s+', '', value)


def context_value(context, key, default=None):
    return context.get(key, default) if isinstance(context, dict) else getattr(context, key, default)


def mapped_sheet(path, name, fields, options, role, default_start):
    from openpyxl import load_workbook
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        if name not in workbook.sheetnames:
            raise ValueError('工作表不存在：' + name)
        sheet = workbook[name]
        rows = []
        for source_row in sheet.iter_rows():
            values = []
            for cell in source_row:
                value = text(cell.value)
                # Preserve source display zeros only when explicitly declared
                # by its number format; never guess a six-digit code from value.
                if isinstance(cell.value, (int, float)) and not isinstance(cell.value, bool) and cell.value >= 0 and int(cell.value) == cell.value and re.fullmatch(r'0{2,}', cell.number_format or ''):
                    value = str(int(cell.value)).zfill(len(cell.number_format))
                values.append(value)
            rows.append(values)
        start = options.get(role + '_data_start_row', default_start)
        if not isinstance(start, int) or start < 2:
            raise ValueError(role + '_data_start_row必须为至少2的整数')
        mapping = options.get(role + '_column_map')
        if mapping is None:
            mapping = {}
            for row in rows[:start - 1]:
                for column, value in enumerate(row, 1):
                    if value in fields:
                        if value in mapping and mapping[value] != column:
                            raise ValueError('重复表头需显式column_map：' + value)
                        mapping[value] = column
        if not isinstance(mapping, dict) or set(mapping) != set(fields):
            raise ValueError(role + '_column_map须列全字段；无法可靠识别表头时请依据源表显式提供1起算列号：' + ', '.join(fields))
        columns = [value for value in mapping.values() if value is not None]
        if any(isinstance(v, bool) or not isinstance(v, int) or v < 1 or v > sheet.max_column for v in columns):
            raise ValueError('列号超范围：' + role)
        if len(set(columns)) != len(columns):
            raise ValueError('同一源列不得映射多个业务字段：' + role)
        # null is explicit absence, not translation or inferred content.
        required = {'primary': ['object_zh', 'parameter_zh', 'method_zh', 'standard_no'], 'supplement': ['object_zh', 'parameter_zh', 'standard_no', 'equipment_ids'], 'equipment': ['equipment_id', 'name']}[role]
        if any(mapping.get(key) is None for key in required):
            raise ValueError('必需业务字段不可设null：' + role)
        projected = []
        for number, row in enumerate(rows, 1):
            if number < start:
                continue
            values = [row[mapping[key] - 1] if mapping[key] is not None and mapping[key] <= len(row) else '' for key in fields]
            if any(value.startswith('=') for value in values):
                raise ValueError('业务源单元格含公式，须提供保留公式原件的已核实值副本：%s 第%d行' % (name, number))
            projected.append((number, values))
        return projected, mapping
    finally:
        workbook.close()


def read_inputs(primary, supplement, options):
    from .merge import parse_supplement, parse_equipment, split_ids
    sheets = {'primary': options.get('primary_sheet', '检测能力范围'), 'supplement': options.get('supplement_sheet', '检测能力范围'), 'equipment': options.get('equipment_sheet', '设备标准物质')}
    p_rows, p_map = mapped_sheet(primary, sheets['primary'], PRIMARY, options, 'primary', 3)
    s_rows, s_map = mapped_sheet(supplement, sheets['supplement'], SUPPLEMENT, options, 'supplement', 3)
    e_rows, e_map = mapped_sheet(supplement, sheets['equipment'], EQUIPMENT, options, 'equipment', 2)
    primaries = []
    obj = {}
    parameter = {}
    obj_id = param_id = ''
    for number, cells in p_rows:
        r = dict(zip(PRIMARY, cells))
        if r['object_zh']:
            new_object = not obj or r['object_zh'] != obj.get('name_zh') or bool(r['object_id'] and r['object_id'] != obj_id) or bool(r['object_sequence'] and r['object_sequence'] != obj.get('sequence'))
            obj_id = r['object_id'] or ('' if new_object else obj_id)
            obj = {'category_zh': r['category_zh'], 'category_en': r['category_en'], 'sequence': r['object_sequence'], 'name_zh': r['object_zh'], 'name_en': r['object_en'], 'energy_star': r['energy_star'] or 'N', 'bluetooth': r['bluetooth'] or 'N'}
            if new_object:
                parameter, param_id = {}, ''
        elif r['object_id'] and r['object_id'] != obj_id:
            raise ValueError('对象ID改变但缺少对象名称：主表第%d行' % number)
        if r['parameter_zh']:
            param_id = r['parameter_id']
            parameter = {'sequence': r['parameter_sequence'], 'name_zh': r['parameter_zh'], 'name_en': r['parameter_en'], 'field_codes': split_ids(r['field_codes'])}
        elif r['parameter_id'] and r['parameter_id'] != param_id:
            raise ValueError('参数ID改变但缺少参数名称：主表第%d行' % number)
        if not any(r[key] for key in ('method_id', 'method_zh', 'standard_no')):
            continue
        if not obj or not parameter:
            raise ValueError('能力记录无可追溯对象或参数：主表第%d行' % number)
        item = {key: r[key] for key in ('method_sequence', 'standard_no', 'standard_no_en', 'clause', 'clause_en', 'limitation', 'limitation_en', 'change_note', 'change_note_en', 'recommended', 'recommender')}
        item.update({'source_row': number, 'obj_id': obj_id, 'param_id': param_id, 'std_id': r['method_id'], 'method_name_zh': r['method_zh'], 'method_name_en': r['method_en'], 'object': dict(obj), 'parameter': dict(parameter)})
        primaries.append(item)
    supplement_rows = parse_supplement([[], []] + [cells for _, cells in s_rows])
    for item in supplement_rows:
        item['source_row'] = s_rows[item['source_row'] - 3][0]
    equipment, duplicates = parse_equipment([[]] + [cells for _, cells in e_rows])
    for item in equipment.values():
        item['source_row'] = e_rows[item['source_row'] - 2][0]
    for duplicate in duplicates:
        duplicate['rows'] = [e_rows[number - 2][0] for number in duplicate['rows']]
    if not primaries:
        raise ValueError('主表没有能力记录')
    maps = dict(options)
    maps.update({key + '_column_map': value for key, value in [('primary', p_map), ('supplement', s_map), ('equipment', e_map)]})
    return primaries, supplement_rows, equipment, duplicates, sheets, maps


def resolve_pointer(document, pointer):
    if not isinstance(pointer, str) or not pointer.startswith('/'):
        raise ValueError('必须提供RFC6901 JSON Pointer')
    value = document
    try:
        for token in pointer[1:].split('/'):
            if re.search(r'~(?![01])', token):
                raise ValueError('非法JSON Pointer转义')
            token = token.replace('~1', '/').replace('~0', '~')
            if isinstance(value, list):
                if not re.fullmatch(r'0|[1-9][0-9]*', token):
                    raise ValueError('数组Pointer索引须为规范非负整数')
                value = value[int(token)]
            else:
                value = value[token]
    except (KeyError, IndexError, ValueError, TypeError):
        raise ValueError('JSON Pointer无法定位：' + pointer)
    return value
