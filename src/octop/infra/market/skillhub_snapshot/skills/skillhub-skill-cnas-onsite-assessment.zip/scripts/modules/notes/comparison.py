#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Analyze before/after CNAS capability workbooks for one reviewer.

The script deliberately produces structured evidence rather than polished prose.
The skill using it is responsible for semantically grouping the changes and
writing the final CNAS additional-notes TXT.
"""

from __future__ import print_function

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

try:
    from .xlsx_reader import load_workbook
except ImportError as exc:
    raise SystemExit(
        "Skill 内部依赖文件缺失：scripts/_xlsx_reader.py。迁移时请复制完整 Skill 文件夹。"
    ) from exc


DEFAULT_SHEET = "检测能力范围"

FIELD_MAP = {
    "obj_cn": {
        "objId": "obj_id",
        "大类名称": "category_name_cn",
        "序号": "object_seq_cn",
        "检测对象": "object_name_cn",
        "能源之星": "energy_star",
        "蓝牙": "bluetooth",
    },
    "param_cn": {
        "paramId": "param_id",
        "序号": "param_seq_cn",
        "项目/参数名称": "param_name_cn",
        "领域代码": "field_code",
    },
    "std_cn": {
        "objStdId": "std_id",
        "序号": "std_seq_cn",
        "检测标准（方法）名称": "std_name_cn",
        "依据标准号": "standard_no_cn",
        "条款号": "clause_cn",
        "说明": "description_cn",
        "备注": "remarks_cn",
        "推荐": "recommended",
        "推荐人": "reviewer",
    },
    "obj_en": {
        "objId": "obj_id_en",
        "大类名称(英文)": "category_name_en",
        "序号": "object_seq_en",
        "检测对象(英文)": "object_name_en",
    },
    "param_en": {
        "paramId": "param_id_en",
        "序号": "param_seq_en",
        "项目/参数名称(英文)": "param_name_en",
    },
    "std_en": {
        "objStdId": "std_id_en",
        "序号": "std_seq_en",
        "检测标准（方法）名称(英文)": "std_name_en",
        "依据标准号(英文)": "standard_no_en",
        "条款号(英文)": "clause_en",
        "说明(英文)": "description_en",
        "备注(英文)": "remarks_en",
    },
}

OBJECT_FIELDS = [
    "category_name_cn", "object_seq_cn", "object_name_cn", "energy_star", "bluetooth",
    "category_name_en", "object_seq_en", "object_name_en",
]

PARAM_FIELDS = ["param_seq_cn", "param_name_cn", "field_code", "param_seq_en", "param_name_en"]

STANDARD_FIELDS = [
    "std_seq_cn", "std_name_cn", "standard_no_cn", "clause_cn", "description_cn",
    "remarks_cn", "recommended", "reviewer", "std_seq_en", "std_name_en",
    "standard_no_en", "clause_en", "description_en", "remarks_en",
]

FIELD_LABELS = {
    "category_name_cn": "大类名称", "object_seq_cn": "检测对象序号",
    "object_name_cn": "检测对象名称", "energy_star": "能源之星", "bluetooth": "蓝牙",
    "category_name_en": "大类英文名称", "object_seq_en": "检测对象英文序号",
    "object_name_en": "检测对象英文名称", "param_seq_cn": "参数序号",
    "param_name_cn": "参数名称", "field_code": "领域代码", "param_seq_en": "参数英文序号",
    "param_name_en": "参数英文名称", "std_seq_cn": "标准序号",
    "std_name_cn": "检测标准（方法）名称", "standard_no_cn": "依据标准号",
    "clause_cn": "条款号", "description_cn": "说明", "remarks_cn": "备注",
    "recommended": "推荐", "reviewer": "推荐人", "std_seq_en": "英文标准序号",
    "std_name_en": "检测标准（方法）英文名称", "standard_no_en": "英文依据标准号",
    "clause_en": "英文条款号", "description_en": "英文说明", "remarks_en": "英文备注",
    "parent_object": "所属检测对象", "parent_parameter": "所属参数", "record": "记录",
}

POSITIVE_STATUSES = {"是", "推荐", "y", "yes", "true", "1"}
NEGATIVE_STATUSES = {"否", "不推荐", "n", "no", "false", "0"}


def clean_value(value):
    """Return a JSON-safe value while preserving meaningful text changes."""
    if value is None:
        return None
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str):
        value = value.replace("\r\n", "\n").replace("\r", "\n")
        return None if not value.strip() else value
    return value


def compact(value):
    """Compact a value for labels and matching, not for evidence comparison."""
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def section_key(value):
    text = compact(value)
    is_english = "英文" in text
    if "检测对象项目/参数" in text:
        return "param_en" if is_english else "param_cn"
    if "检测对象标准" in text:
        return "std_en" if is_english else "std_cn"
    if "检测对象" in text:
        return "obj_en" if is_english else "obj_cn"
    return None


def build_column_map(ws):
    columns = {}
    unknown = []
    current_section = None
    for col in range(1, ws.max_column + 1):
        top = clean_value(ws.cell(1, col).value)
        if top is not None:
            current_section = section_key(top)
        header = compact(ws.cell(2, col).value)
        if not header:
            continue
        field = FIELD_MAP.get(current_section, {}).get(header)
        if field:
            columns[col] = field
        else:
            unknown.append({"column": col, "section": current_section, "header": header})
    required = {"obj_id", "param_id", "std_id", "recommended", "reviewer"}
    missing = sorted(required.difference(columns.values()))
    if missing:
        raise ValueError("表头缺少必需字段：{}".format("、".join(missing)))
    return columns, unknown


def choose_sheet(workbook, requested):
    if requested in workbook.sheetnames:
        return workbook[requested]
    candidates = []
    for ws in workbook.worksheets:
        row2 = {compact(ws.cell(2, c).value) for c in range(1, ws.max_column + 1)}
        if {"objId", "paramId", "objStdId", "推荐人"}.issubset(row2):
            candidates.append(ws)
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise ValueError("找不到工作表“{}”，也无法根据表头唯一识别能力表。".format(requested))
    raise ValueError(
        "工作表“{}”不存在，且根据表头识别到多个候选：{}。请使用 --sheet 指定。".format(
            requested, "、".join(ws.title for ws in candidates)
        )
    )


def update_entity(entity, row_data, fields, entity_kind, entity_id, row_number, diagnostics):
    for field in fields:
        value = row_data.get(field)
        if value is None:
            continue
        previous = entity.get(field)
        if previous is not None and previous != value:
            diagnostics["conflicting_values"].append({
                "entity_kind": entity_kind, "entity_id": entity_id, "field": field,
                "first": previous, "later": value, "row": row_number,
            })
        entity[field] = value


def fallback_id(prefix, pieces, occurrences):
    base = prefix + "|" + "|".join(compact(piece) for piece in pieces)
    number = occurrences.get(base, 0) + 1
    occurrences[base] = number
    return "{}|#{}".format(base, number)


def load_dataset(path, requested_sheet):
    workbook = load_workbook(filename=str(path), read_only=True, data_only=False)
    ws = choose_sheet(workbook, requested_sheet)
    columns, unknown = build_column_map(ws)
    diagnostics = {
        "unknown_columns": unknown, "missing_ids": [], "duplicate_standard_ids": [],
        "conflicting_values": [],
    }
    objects, parameters, standards = {}, {}, {}
    current_obj_id = None
    current_param_id = None
    current_category = {}
    fallback_occurrences = {}

    # Read-only worksheets are optimized for forward iteration. Random ws.cell()
    # access becomes extremely slow on large files, especially on network drives.
    for row_number, row_values in enumerate(ws.iter_rows(min_row=3, values_only=True), start=3):
        row_data = {
            field: clean_value(row_values[col - 1] if col <= len(row_values) else None)
            for col, field in columns.items()
        }
        if not any(value is not None for value in row_data.values()):
            continue
        for category_field in ("category_name_cn", "category_name_en"):
            if row_data.get(category_field) is not None:
                current_category[category_field] = row_data[category_field]
            elif category_field in current_category:
                row_data[category_field] = current_category[category_field]
        raw_obj_id = compact(row_data.get("obj_id"))
        raw_param_id = compact(row_data.get("param_id"))
        raw_std_id = compact(row_data.get("std_id"))
        if raw_obj_id:
            if current_obj_id and current_obj_id != raw_obj_id and not raw_param_id:
                current_param_id = None
            current_obj_id = raw_obj_id
        obj_id = raw_obj_id or current_obj_id
        if raw_param_id:
            current_param_id = raw_param_id
        param_id = raw_param_id or current_param_id
        if not obj_id or not param_id:
            diagnostics["missing_ids"].append({
                "row": row_number, "obj_id_missing": not bool(obj_id), "param_id_missing": not bool(param_id),
            })
            continue
        if raw_std_id:
            std_id = raw_std_id
        else:
            diagnostics["missing_ids"].append({"row": row_number, "std_id_missing": True})
            std_id = fallback_id("std", [obj_id, param_id, row_data.get("std_seq_cn"),
                                          row_data.get("standard_no_cn"), row_data.get("std_name_cn")],
                                 fallback_occurrences)

        obj = objects.setdefault(obj_id, {"id": obj_id, "rows": []})
        obj["rows"].append(row_number)
        update_entity(obj, row_data, OBJECT_FIELDS, "object", obj_id, row_number, diagnostics)
        param = parameters.setdefault(param_id, {"id": param_id, "object_id": obj_id, "rows": []})
        param["rows"].append(row_number)
        if param.get("object_id") != obj_id:
            diagnostics["conflicting_values"].append({
                "entity_kind": "parameter", "entity_id": param_id, "field": "object_id",
                "first": param.get("object_id"), "later": obj_id, "row": row_number,
            })
        param["object_id"] = obj_id
        update_entity(param, row_data, PARAM_FIELDS, "parameter", param_id, row_number, diagnostics)
        if std_id in standards:
            diagnostics["duplicate_standard_ids"].append({"std_id": std_id, "row": row_number})
            continue
        std = {"id": std_id, "object_id": obj_id, "parameter_id": param_id, "row": row_number}
        update_entity(std, row_data, STANDARD_FIELDS, "standard", std_id, row_number, diagnostics)
        standards[std_id] = std

    workbook.close()
    return {
        "path": str(path.resolve()), "sheet": ws.title, "objects": objects,
        "parameters": parameters, "standards": standards, "diagnostics": diagnostics,
    }


def reviewer_matches(value, reviewer):
    target, raw = compact(reviewer), compact(value)
    if not target or not raw:
        return False
    if raw == target:
        return True
    return target in [token for token in re.split(r"[,，;；、/\s]+", raw) if token]


def status_kind(value):
    raw = compact(value)
    lowered = raw.lower()
    if lowered in POSITIVE_STATUSES or raw in POSITIVE_STATUSES:
        return "positive"
    if lowered in NEGATIVE_STATUSES or raw in NEGATIVE_STATUSES:
        return "negative"
    return "unknown" if raw else "empty"


def format_sequence(value):
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return compact(value)


def object_label(dataset, obj_id):
    obj = dataset["objects"].get(obj_id, {}) if obj_id else {}
    category = compact(obj.get("category_name_cn"))
    seq = format_sequence(obj.get("object_seq_cn"))
    name = compact(obj.get("object_name_cn"))
    object_part = "{}-{}".format(seq, name) if seq and name else (name or seq)
    if category and object_part:
        return "{}，{}".format(category, object_part)
    return category or object_part or "检测对象信息缺失"


def parameter_label(dataset, param_id):
    param = dataset["parameters"].get(param_id, {}) if param_id else {}
    seq = format_sequence(param.get("param_seq_cn"))
    name = compact(param.get("param_name_cn"))
    if seq and name:
        return "{}-{}".format(seq, name)
    return name or seq or "参数信息缺失"


def standard_label(dataset, std_id):
    std = dataset["standards"].get(std_id, {}) if std_id else {}
    seq = format_sequence(std.get("std_seq_cn"))
    name = compact(std.get("std_name_cn"))
    number = compact(std.get("standard_no_cn"))
    base = "{}-{}".format(seq, name) if seq and name else (name or seq or "标准记录")
    return "{}（{}）".format(base, number) if number else base


def preferred_context(before, after, param_id):
    dataset = after if param_id in after["parameters"] else before
    param = dataset["parameters"].get(param_id, {})
    obj_id = param.get("object_id")
    return {
        "object_id": obj_id, "object_label": object_label(dataset, obj_id),
        "parameter_id": param_id, "parameter_label": parameter_label(dataset, param_id),
    }


def scoped_standard_ids(before, after, reviewer):
    result = set()
    for std_id in set(before["standards"]) | set(after["standards"]):
        left, right = before["standards"].get(std_id, {}), after["standards"].get(std_id, {})
        if reviewer_matches(left.get("reviewer"), reviewer) or reviewer_matches(right.get("reviewer"), reviewer):
            result.add(std_id)
    return result


def add_change(changes, kind, level, entity_id, field, before_value, after_value, context, label):
    changes.append({
        "kind": kind, "level": level, "entity_id": entity_id, "entity_label": label,
        "field": field, "field_label": FIELD_LABELS.get(field, field),
        "before": before_value, "after": after_value, "context": context,
    })


def entity_row_order(before, after, collection_name, entity_id):
    entity = after[collection_name].get(entity_id) or before[collection_name].get(entity_id) or {}
    rows = entity.get("rows") or [entity.get("row")]
    rows = [row for row in rows if isinstance(row, int)]
    return (min(rows) if rows else sys.maxsize, compact(entity_id))


def compare_entities(before, after, ids, collection_name, fields, level, changes):
    left_collection, right_collection = before[collection_name], after[collection_name]
    for entity_id in sorted(ids, key=lambda value: entity_row_order(before, after, collection_name, value)):
        left, right = left_collection.get(entity_id), right_collection.get(entity_id)
        if level == "object":
            context = {"object_id": entity_id, "object_label": object_label(after if right else before, entity_id)}
            label = context["object_label"]
        elif level == "parameter":
            context = preferred_context(before, after, entity_id)
            label = context["parameter_label"]
        else:
            base = right or left or {}
            context = preferred_context(before, after, base.get("parameter_id"))
            label = standard_label(after if right else before, entity_id)
        if left is None:
            add_change(changes, "added", level, entity_id, "record", None, "新增", context, label)
            continue
        if right is None:
            add_change(changes, "removed", level, entity_id, "record", "删除前存在", None, context, label)
            continue
        if (level == "parameter" and left.get("object_id") != right.get("object_id")
                and object_label(before, left.get("object_id")) != object_label(after, right.get("object_id"))):
            add_change(changes, "modified", level, entity_id, "parent_object",
                       object_label(before, left.get("object_id")), object_label(after, right.get("object_id")),
                       context, label)
        if (level == "standard" and left.get("parameter_id") != right.get("parameter_id")
                and parameter_label(before, left.get("parameter_id")) != parameter_label(after, right.get("parameter_id"))):
            add_change(changes, "modified", level, entity_id, "parent_parameter",
                       parameter_label(before, left.get("parameter_id")),
                       parameter_label(after, right.get("parameter_id")), context, label)
        for field in fields:
            left_value, right_value = left.get(field), right.get(field)
            if left_value != right_value:
                add_change(changes, "modified", level, entity_id, field, left_value, right_value, context, label)


def parameter_statuses(dataset, param_id, scope_ids):
    values = []
    for std_id in scope_ids:
        std = dataset["standards"].get(std_id)
        if std and std.get("parameter_id") == param_id:
            marker = (compact(std.get("recommended")), status_kind(std.get("recommended")))
            if marker not in values:
                values.append(marker)
    return [{"value": value, "kind": kind} for value, kind in values]


def analyze(before, after, reviewer, reason):
    scope_ids = scoped_standard_ids(before, after, reviewer)
    parameter_ids, object_ids = set(), set()
    for std_id in scope_ids:
        for dataset in (before, after):
            std = dataset["standards"].get(std_id)
            if std:
                if std.get("parameter_id"):
                    parameter_ids.add(std["parameter_id"])
                if std.get("object_id"):
                    object_ids.add(std["object_id"])
    changes = []
    compare_entities(before, after, object_ids, "objects", OBJECT_FIELDS, "object", changes)
    compare_entities(before, after, parameter_ids, "parameters", PARAM_FIELDS, "parameter", changes)
    compare_entities(before, after, scope_ids, "standards", STANDARD_FIELDS, "standard", changes)

    nonrecommended = []
    for param_id in sorted(parameter_ids, key=lambda value: entity_row_order(before, after, "parameters", value)):
        before_statuses = parameter_statuses(before, param_id, scope_ids)
        after_statuses = parameter_statuses(after, param_id, scope_ids)
        before_kinds = {item["kind"] for item in before_statuses}
        after_kinds = {item["kind"] for item in after_statuses}
        if "positive" in before_kinds and "negative" in after_kinds and "negative" not in before_kinds:
            item = preferred_context(before, after, param_id)
            item.update({"before_statuses": before_statuses, "after_statuses": after_statuses,
                         "reason": reason or None})
            nonrecommended.append(item)

    nonrecommended_ids = {item["parameter_id"] for item in nonrecommended}
    restriction_ids = {
        change["context"].get("parameter_id") for change in changes
        if change["kind"] == "modified" and change["field"] in ("description_cn", "description_en", "remarks_cn", "remarks_en", "clause_cn", "clause_en")
        and compact(change.get("after")) and change["context"].get("parameter_id") not in nonrecommended_ids
    }
    restriction_ids.discard(None)
    restriction_candidates = []
    for param_id in sorted(restriction_ids, key=lambda value: entity_row_order(before, after, "parameters", value)):
        item = preferred_context(before, after, param_id)
        item["description_changes"] = [
            change for change in changes
            if change["context"].get("parameter_id") == param_id and change["field"] in ("description_cn", "description_en", "remarks_cn", "remarks_en", "clause_cn", "clause_en")
        ]
        restriction_candidates.append(item)

    level_order = {"object": 0, "parameter": 1, "standard": 2}
    field_order = {field: index for index, field in enumerate(OBJECT_FIELDS + PARAM_FIELDS + STANDARD_FIELDS)}
    changes.sort(key=lambda change: (
        entity_row_order(before, after, "parameters", change["context"].get("parameter_id"))[0]
        if change["context"].get("parameter_id") else
        entity_row_order(before, after, "objects", change["context"].get("object_id"))[0],
        level_order.get(change["level"], 9),
        field_order.get(change["field"], 999),
        compact(change["entity_label"]),
    ))

    before_scope = sum(1 for std_id in scope_ids if std_id in before["standards"])
    after_scope = sum(1 for std_id in scope_ids if std_id in after["standards"])
    return {
        "metadata": {
            "generated_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
            "before_file": before["path"], "after_file": after["path"],
            "before_sheet": before["sheet"], "after_sheet": after["sheet"],
            "reviewer": reviewer, "nonrecommendation_reason": reason or None,
        },
        "summary": {
            "before_total_standard_records": len(before["standards"]),
            "after_total_standard_records": len(after["standards"]),
            "scoped_before_standard_records": before_scope,
            "scoped_after_standard_records": after_scope,
            "scoped_unique_parameters": len(parameter_ids),
            "nonrecommended_parameter_count": len(nonrecommended),
            "restriction_candidate_parameter_count": len(restriction_candidates),
            "change_event_count": len(changes),
            "added_event_count": sum(1 for change in changes if change["kind"] == "added"),
            "removed_event_count": sum(1 for change in changes if change["kind"] == "removed"),
            "modified_event_count": sum(1 for change in changes if change["kind"] == "modified"),
        },
        "nonrecommended_parameters": nonrecommended,
        "restriction_candidates": restriction_candidates,
        "changes": changes,
        "diagnostics": {"before": before["diagnostics"], "after": after["diagnostics"]},
    }


