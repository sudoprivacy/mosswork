# -*- coding: utf-8 -*-
"""Hash-bound restartable chunks, reclaimed shared image resources."""
from pathlib import Path

from ._io import load_json, sha256, write_json


def split_pdf(source, output_dir, chunk_size=10):
    import fitz
    if isinstance(chunk_size, bool) or not isinstance(chunk_size, int) or not 1 <= chunk_size <= 50:
        raise ValueError('chunk_size must be an integer between 1 and 50 (10–20 recommended)')
    source, out = Path(source).resolve(), Path(output_dir).resolve()
    identity = sha256(source)
    folder = out / 'chunks' / identity
    folder.mkdir(parents=True, exist_ok=True)
    manifest_path = folder / 'chunks.json'
    old = load_json(manifest_path) if manifest_path.exists() else {}
    cache = {x['start_page']: x for x in old.get('chunks', [])} if old.get('chunk_size') == chunk_size else {}
    chunks = []
    with fitz.open(str(source)) as pdf:
        if pdf.needs_pass:
            raise ValueError('Cannot split encrypted PDF without explicit decryption')
        for start in range(0, pdf.page_count, chunk_size):
            end = min(start + chunk_size, pdf.page_count)
            target = folder / ('pages_%04d_%04d.pdf' % (start + 1, end))
            prior = cache.get(start + 1, {})
            reusable = (target.is_file() and prior.get('end_page') == end and
                        prior.get('sha256') == sha256(target))
            if not reusable:
                with fitz.open() as chunk:
                    chunk.insert_pdf(pdf, from_page=start, to_page=end - 1)
                    body = chunk.tobytes(garbage=4, deflate=True, clean=True)
                from ._io import atomic_bytes
                atomic_bytes(target, body)
            chunks.append(dict(path=str(target), start_page=start + 1, end_page=end,
                               sha256=sha256(target), reused=reusable))
        result = dict(source=str(source), source_sha256=identity, page_count=pdf.page_count,
                      chunk_size=chunk_size, chunks=chunks)
    write_json(manifest_path, result)
    result['manifest_path'] = str(manifest_path)
    return result
