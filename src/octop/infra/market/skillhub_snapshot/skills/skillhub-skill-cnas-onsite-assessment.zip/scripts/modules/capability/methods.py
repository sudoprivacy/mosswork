# -*- coding: utf-8 -*-
"""Render a reviewer-scoped method download/validity checklist from capability JSON."""

import argparse
import json
import re
import unicodedata
from collections import OrderedDict
from pathlib import Path

from docx import Document
from docx.enum.text import WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.shared import Pt


INDUSTRY_PREFIXES = (
    "SN/T",
    "HG/T",
    "HJ",
    "JB/T",
    "JT/T",
    "LY/T",
    "NY/T",
    "QB/T",
    "FZ/T",
    "YY/T",
    "WS/T",
    "DL/T",
)
INTERNATIONAL_PREFIXES = (
    "ISO",
    "IEC",
    "ASTM",
    "EN",
    "DIN",
    "BS",
    "JIS",
    "AATCC",
    "AOAC",
    "AFPS",
    "IATA",
    "ICAO",
    "IMDG",
    "ST/SG",
)


def text(value):
    return "" if value is None else str(value).strip()


def compact(value):
    value = unicodedata.normalize("NFKC", text(value)).upper()
    value = value.replace("–", "-").replace("—", "-").replace("−", "-")
    return re.sub(r"\s+", "", value)


def comparable_name(value):
    value = unicodedata.normalize("NFKC", text(value))
    return re.sub(r"\s+", "", value)


def display_name(value):
    return text(value).replace("《", "").replace("》", "").strip()


def display_standard_no(value):
    """Apply mechanical formatting only; do not infer or correct semantics."""
    value = unicodedata.normalize("NFKC", text(value))
    value = value.replace("–", "-").replace("—", "-").replace("−", "-")
    value = re.sub(r"\s+", " ", value).strip()
    prefixes = ["GB/T", "GB/Z", "GB", *INDUSTRY_PREFIXES, *INTERNATIONAL_PREFIXES]
    for prefix in sorted(prefixes, key=len, reverse=True):
        value = re.sub(
            rf"^{re.escape(prefix)}\s*(?=\d)",
            prefix + " ",
            value,
            flags=re.IGNORECASE,
        )
        if re.match(rf"^{re.escape(prefix)}(?:\s|$)", value, flags=re.IGNORECASE):
            break
    return value or "标准编号未填写"


def standard_category(value):
    value = compact(value)
    if re.match(r"^GB(?:/T|/Z)?\d", value):
        return 0
    if any(value.startswith(prefix.replace(" ", "")) for prefix in INDUSTRY_PREFIXES):
        return 1
    if any(value.startswith(prefix.replace(" ", "")) for prefix in INTERNATIONAL_PREFIXES):
        return 2
    return 3


def natural_key(value):
    value = unicodedata.normalize("NFKC", text(value)).upper()
    return tuple((0, int(part)) if part.isdigit() else (1, part) for part in re.split(r"(\d+)", value))


from .model import reviewer_matches


def collect_lines(capabilities):
    groups = OrderedDict()
    for record in capabilities:
        method = record.get("method", {})
        number = text(method.get("standard_no"))
        name = text(method.get("name_zh"))
        key = compact(number) if number else "NO_NUMBER:" + comparable_name(name)
        groups.setdefault(key, []).append({"number": number, "name": name})

    entries = []
    conflict_groups = []
    for key, values in groups.items():
        number = next((value["number"] for value in values if value["number"]), "")
        names = OrderedDict()
        for value in values:
            name_key = comparable_name(value["name"])
            names.setdefault(name_key, value["name"])
        if len(names) > 1:
            conflict_groups.append(
                {
                    "standard_key": key,
                    "standard_no": display_standard_no(number),
                    "names": list(names.values()),
                }
            )
        for name in names.values() or ["标准名称未填写"]:
            shown_number = display_standard_no(number)
            shown_name = display_name(name) or "标准名称未填写"
            entries.append(
                {
                    "line": f"《{shown_name}》（{shown_number}）",
                    "category": standard_category(number),
                    "number": shown_number,
                    "name": shown_name,
                }
            )

    entries.sort(key=lambda item: (item["category"], natural_key(item["number"]), natural_key(item["name"])))
    return entries, conflict_groups, len(groups)


def write_docx(path, entries):
    document = Document()
    section = document.sections[0]
    section.top_margin = section.bottom_margin = Pt(54)
    section.left_margin = section.right_margin = Pt(54)

    normal = document.styles["Normal"]
    normal.font.name = "宋体"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(10.5)

    for entry in entries:
        paragraph = document.add_paragraph()
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        run = paragraph.add_run(entry["line"])
        run.font.name = "宋体"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        run.font.size = Pt(10.5)

    path.parent.mkdir(parents=True, exist_ok=True)
    from .model import atomic_save
    atomic_save(document.save, path)

