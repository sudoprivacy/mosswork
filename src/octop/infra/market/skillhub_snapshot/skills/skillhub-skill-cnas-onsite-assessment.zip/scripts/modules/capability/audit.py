# -*- coding: utf-8 -*-
"""Validates evidence submitted by an Agent; does not infer professional issues."""
from collections import Counter
from pathlib import Path
from .model import context_value, norm_standard, read_json, resolve_pointer, reviewer_matches, sha256, text, write_json

LEVELS = {'严重错误', '一般错误', '警告', '待人工核验', '优化建议'}


def verify_merge(inputs):
    from docx import Document
    from .model import read_inputs
    from .merge import merge
    from .methods import collect_lines
    data = read_json(inputs['merged'])
    if not data.get('validation_passed') or not data.get('validation', {}).get('integrity_checks') or not all(data['validation']['integrity_checks'].values()):
        raise ValueError('合并JSON完整性门槛未通过')
    for key in ('primary', 'supplement'):
        if data.get('source_hashes', {}).get(key) != sha256(inputs[key]):
            raise ValueError('第一阶段后源文件已变更：' + key)
    source = read_inputs(inputs['primary'], inputs['supplement'], data.get('column_mapping', {}))
    replay, report = merge(*source[:4])
    original = data.get('capabilities', [])
    fields = ('capability_id', 'category', 'object', 'parameter', 'method', 'application', 'operational', 'equipment_ids', 'equipment', 'match')
    if len(replay) != len(original) or any(any(a.get(k) != b.get(k) for k in fields) or a.get('source', {}).get('primary_row') != b['source']['primary_row'] for a, b in zip(original, replay)):
        raise ValueError('合并JSON与当前源表内容/源行不一致')
    for item in original:
        if item.get('source', {}).get('primary_sheet') != source[4]['primary']:
            raise ValueError('合并JSON主表工作表定位不一致')
        # Historical absolute paths are display metadata, never reopening inputs.
        item['source']['primary_file'] = str(Path(inputs['primary']).resolve())
        item['source']['supplement_file'] = str(Path(inputs['supplement']).resolve())
    for key in ('validation_report', 'method_list'):
        artifact = data.get('stage_artifacts', {}).get(key, {})
        if artifact.get('sha256') != sha256(inputs[key]):
            raise ValueError('第一阶段Word不匹配：' + key)
        Document(inputs[key])
    body = '\n'.join(p.text for p in Document(inputs['validation_report']).paragraphs)
    if '总体结论：通过' not in body:
        raise ValueError('完整性Word无通过结论')
    expected, _, _ = collect_lines([x for x in original if reviewer_matches(x, data.get('reviewer', ''))])
    if [p.text for p in Document(inputs['method_list']).paragraphs if p.text] != [e['line'] for e in expected]:
        raise ValueError('方法Word与合并JSON清单不一致')
    return data


def verify_standards(inputs):
    from openpyxl import load_workbook
    # ONE common implementation owns physical file checks and extraction schema.
    from ..standards.build_standard_excel import validate_records, FIELDS
    inventory, records = read_json(inputs['standards_inventory']), read_json(inputs['standards_records'])
    if inputs.get('standards_folder'):
        inventory['source_root'] = str(Path(inputs['standards_folder']).resolve())
    report = validate_records(inventory, records)
    workbook = load_workbook(inputs['standards_workbook'], read_only=True, data_only=False)
    try:
        required = {'结构化提取', '文件清单与覆盖检查', '一参多法复核', '质量警告'}
        if not required.issubset(workbook.sheetnames):
            raise ValueError('结构化标准Excel缺少覆盖/多方法工作表')
        rows = list(workbook['结构化提取'].iter_rows(min_row=2, values_only=True))
        content = records['records'] if isinstance(records, dict) else records
        if len(rows) != len(content) or any([text(value) for value in row[:len(FIELDS)]] != [text(record.get(key)) for key in FIELDS] for row, record in zip(rows, content)):
            raise ValueError('结构化标准Excel与records不一致')
        return inventory, content, report
    finally:
        workbook.close()


def coverage_for(data, records, reviewer, aliases, unavailable_files=None):
    index = {}
    for number, item in enumerate(records):
        index.setdefault(norm_standard(item['standard_number']), []).append(number)
    alias_map = {}
    if not isinstance(aliases, list):
        raise ValueError('standard_aliases须为含from/to/evidence的列表')
    for alias in aliases:
        if not all(text(alias.get(key)) for key in ('from', 'to', 'evidence')):
            raise ValueError('标准别名需显式from/to和证据')
        key = norm_standard(alias['from'])
        if key in alias_map:
            raise ValueError('同一标准存在重复别名决策')
        if norm_standard(alias['to']) not in index:
            raise ValueError('别名目标不存在于标准records')
        alias_map[key] = alias
    result = []
    for number, capability in enumerate(data['capabilities']):
        if not reviewer_matches(capability, reviewer):
            continue
        key = norm_standard(capability['method']['standard_no'])
        rule = '直接匹配'
        alias = None
        if key not in index and key in alias_map:
            alias = alias_map[key]
            key = norm_standard(alias['to'])
            rule = '显式证据别名'
        matches = index.get(key, [])
        if any(records[i]['source_file'].replace('\\', '/') in (unavailable_files or set()) for i in matches):
            matches = []
        result.append({'index': number, 'json_pointer': '/capabilities/%d' % number, 'reviewer': reviewer, 'source_file': capability['source']['primary_file'], 'source_sheet': capability['source']['primary_sheet'], 'source_row': capability['source']['primary_row'], 'standard_no': capability['method']['standard_no'], 'matched': bool(matches), 'rule': rule if matches else '未覆盖（不作能力问题）', 'standard_record_indexes': matches, 'structured_rows': [i + 2 for i in matches], 'structured_standards': list(dict.fromkeys(records[i]['standard_number'] for i in matches)), 'alias_evidence': alias['evidence'] if alias else ''})
    return result


def load_basis(context, options):
    callback = context_value(context, 'basis')
    if not callable(callback):
        raise ValueError('context.basis回调不可用')
    codes = ['CNAS-AL06', 'CNAS-EL-03', 'CNAS-CL01']
    for code in options.get('professional_basis', []):
        if not isinstance(code, str) or not code.startswith('CNAS-EL-'):
            raise ValueError('professional_basis只能显式选择CNAS-EL文件编号')
        if code not in codes:
            codes.append(code)
    resolved = {}
    for code in codes:
        item = callback(code)
        if not isinstance(item, dict) or not item.get('document') or not item.get('provenance', {}).get('json_sha256'):
            raise ValueError('正式依据缺少全文或固定指纹：' + code)
        resolved[code] = item
    return resolved


def evidence_display(refs):
    lines = []
    for ref in refs:
        if ref['type'] == 'standard':
            lines.append('%s | %s | %s | records SHA256 %s' % (ref['source_file'], ref['json_pointer'], ref['locator'], ref['records_sha256']))
        else:
            provenance = ref['provenance']
            lines.append('%s %s/%s | %s | %s | JSON SHA256 %s' % (ref['code'], provenance.get('version', ''), provenance.get('revision', ''), ref['json_pointer'], ref['locator'], provenance['json_sha256']))
    return '\n'.join(lines)


def validate_agent_issues(document, data, records, coverage, basis, inputs, reviewer):
    metadata = document.get('metadata', {})
    if not text(metadata.get('reviewed_by')) or metadata.get('reviewer') != reviewer:
        raise ValueError('issues.metadata须有reviewed_by及准确reviewer')
    if metadata.get('review_method') != 'agent_read_original':
        raise ValueError('issues必须声明Agent已读取原文：review_method=agent_read_original')
    if metadata.get('merged_sha256') != sha256(inputs['merged']) or metadata.get('standards_records_sha256') != sha256(inputs['standards_records']):
        raise ValueError('Agent审核输入指纹已变化')
    covered = {row['json_pointer']: row for row in coverage if row['matched']}
    reviewed = metadata.get('reviewed_pointers', [])
    if not isinstance(reviewed, list) or any(not isinstance(p, str) for p in reviewed) or len(set(reviewed)) != len(reviewed) or not set(reviewed).issubset(covered):
        raise ValueError('reviewed_pointers包含未覆盖/非指定评审员/重复记录')
    issues = document.get('issues')
    if not isinstance(issues, list):
        raise ValueError('issues须为数组；空数组仅表示该声明范围内未提交问题')
    grouped = {}
    for issue in issues:
        required = ['root_cause_key', 'level', 'category', 'field', 'original_value', 'description', 'suggestion', 'confidence', 'reviewer']
        if not isinstance(issue, dict) or any(not isinstance(issue.get(key), str) or not issue[key].strip() for key in required) or issue['level'] not in LEVELS or issue['reviewer'] != reviewer:
            raise ValueError('问题必填字段、等级或评审员不合法')
        pointers = issue.get('json_pointers', [])
        source_rows = issue.get('source_rows', [])
        refs = issue.get('evidence_refs', [])
        if not pointers or not isinstance(pointers, list) or any(not isinstance(p, str) for p in pointers) or not set(pointers).issubset(set(reviewed)):
            raise ValueError('问题定位必须属于Agent已审查且标准已覆盖的指定评审员记录')
        if source_rows != [covered[p]['source_row'] for p in pointers]:
            raise ValueError('问题源行与JSON Pointer不一致')
        if not refs or not isinstance(refs, list):
            raise ValueError('问题缺少可定位证据')
        for pointer in pointers:
            resolve_pointer(data, pointer + '/' + issue['field'].replace('.', '/'))
        for ref in refs:
            if not isinstance(ref, dict):
                raise ValueError('evidence_refs须为对象列表')
            if ref.get('type') == 'standard':
                pointer = ref.get('json_pointer', '')
                record = resolve_pointer({'records': records}, pointer)
                if not pointer.startswith('/records/') or not isinstance(record, dict) or record.get('source_file') != ref.get('source_file') or not text(ref.get('locator')):
                    raise ValueError('标准证据须定位真实records行、源文件和条款/页码')
                index = int(pointer.split('/')[2])
                if not any(index in covered[p]['standard_record_indexes'] for p in pointers):
                    raise ValueError('标准证据与受影响能力的覆盖标准不一致')
                ref['records_sha256'] = sha256(inputs['standards_records'])
            elif ref.get('type') == 'basis':
                code = ref.get('code')
                if code not in basis:
                    raise ValueError('问题引用未选定正式依据：' + str(code))
                resolve_pointer(basis[code]['document'], ref.get('json_pointer', ''))
                if not text(ref.get('locator')):
                    raise ValueError('正式依据缺少可读证据定位')
                ref['provenance'] = basis[code]['provenance']
            else:
                raise ValueError('证据type须为standard或basis；附加能力证明先整理为可核实证据')
        key = issue['root_cause_key']
        if key in grouped:
            previous = grouped[key]
            if any(previous[k] != issue[k] for k in ('level', 'category', 'description', 'suggestion', 'field')):
                raise ValueError('同根因问题结论冲突，请Agent先协调：' + key)
            for p, row in zip(pointers, source_rows):
                if p not in previous['json_pointers']:
                    previous['json_pointers'].append(p)
                    previous['source_rows'].append(row)
            for ref in refs:
                if ref not in previous['evidence_refs']:
                    previous['evidence_refs'].append(ref)
        else:
            grouped[key] = issue
    return list(grouped.values()), sorted(set(covered) - set(reviewed)), metadata


def audit_action(request, context, output):
    from openpyxl import Workbook, load_workbook
    from .workbook import write_records_sheet, write_pairs_sheet
    inputs, options = request['inputs'], request.get('options', {})
    reviewer = context_value(context, 'reviewer', '') or request.get('reviewer', '')
    if not reviewer:
        raise ValueError('audit必须指定评审员')
    data = verify_merge(inputs)
    inventory, records, standards_report = verify_standards(inputs)
    unavailable = {text(value).replace('\\', '/') for key in ('missing_files', 'changed_files', 'pending_files', 'uncovered_files') for value in standards_report.get(key, [])}
    coverage = coverage_for(data, records, reviewer, options.get('standard_aliases', []), unavailable)
    if not coverage:
        raise ValueError('指定评审员没有能力记录')
    basis = load_basis(context, options)
    complete = bool(standards_report['coverage_passed']) and all(row['matched'] for row in coverage)
    authorized = request.get('authorization', {}).get('allow_partial_coverage') is True
    gates = [{'id': 'merge_artifacts_and_sources', 'passed': True, 'detail': '主表重放、源hash、两份Word内容及hash一致'}, {'id': 'standard_coverage', 'passed': complete, 'detail': '物理文件、提取状态、records与工作簿及指定评审员标准清单对账'}, {'id': 'partial_coverage_authorized', 'passed': complete or authorized, 'detail': '覆盖不足仅在显式授权下审核已覆盖部分；未覆盖不判错'}]
    issues, unreviewed, metadata = [], [], {}
    if complete or authorized:
        issues, unreviewed, metadata = validate_agent_issues(read_json(inputs['issues']), data, records, coverage, basis, inputs, reviewer)
    unresolved = []
    for row in coverage:
        if not row['matched']:
            unresolved.append({'kind': 'standard_not_covered', 'json_pointer': row['json_pointer'], 'source_row': row['source_row'], 'standard_no': row['standard_no']})
    if not standards_report['coverage_passed']:
        unresolved.append({'kind': 'standards_stage_incomplete', 'detail': standards_report})
    if standards_report.get('warnings'):
        unresolved.append({'kind': 'standards_quality_warnings', 'detail': standards_report['warnings']})
    if unreviewed:
        unresolved.append({'kind': 'agent_not_reviewed', 'json_pointers': unreviewed})
    rows = []
    for number, issue in enumerate(issues, 1):
        affected = [resolve_pointer(data, p) for p in issue['json_pointers']]
        rows.append({'编号': number, '等级': issue['level'], '问题类别': issue['category'], '评审员': reviewer, '主表源行': issue['source_rows'], 'JSON Pointer/记录定位': issue['json_pointers'], '检测对象': list(dict.fromkeys(x['object']['name_zh'] for x in affected)), '项目/参数': list(dict.fromkeys(x['parameter']['name_zh'] for x in affected)), '标准名称': list(dict.fromkeys(x['method']['name_zh'] for x in affected)), '标准号': list(dict.fromkeys(x['method']['standard_no'] for x in affected)), '字段': issue['field'], '原始值摘要': issue['original_value'], '标准文本/依据证据': evidence_display(issue['evidence_refs']), '问题说明': issue['description'], '修订建议': issue['suggestion'], '置信度': issue['confidence'], '根因键': issue['root_cause_key']})
    status = 'blocked' if not complete and not authorized else 'needs_review'
    summary = {'reviewer': reviewer, 'target_records': len(coverage), 'matched_records': sum(row['matched'] for row in coverage), 'issues': len(issues), 'affected_records': len({p for issue in issues for p in issue['json_pointers']}), 'level_counts': dict(Counter(issue['level'] for issue in issues)), 'agent_reviewed_records': len(metadata.get('reviewed_pointers', [])), 'unreviewed_records': len(unreviewed), 'coverage_passed': complete, 'conclusion': '标准覆盖门槛未通过，未执行能力语义审核' if status == 'blocked' else '已校验Agent问题证据与定位，待评审员确认；不表示能力通过或不符合确认'}
    workbook = Workbook()
    workbook.remove(workbook.active)
    if status != 'blocked':
        write_records_sheet(workbook, '问题清单', rows, ['编号', '等级', '问题类别', '评审员', '主表源行', 'JSON Pointer/记录定位', '检测对象', '项目/参数', '标准名称', '标准号', '字段', '原始值摘要', '标准文本/依据证据', '问题说明', '修订建议', '置信度'], [7, 13, 25, 13, 16, 34, 25, 25, 35, 25, 26, 40, 65, 55, 55, 12, 25])
    write_pairs_sheet(workbook, '审核汇总', [[k, text(v) if not isinstance(v, dict) else str(v)] for k, v in summary.items()], ['项目', '说明'])
    coverage_rows = [{'评审员': row['reviewer'], '源文件': row['source_file'], '源工作表': row['source_sheet'], '主表源行': row['source_row'], 'JSON Pointer': row['json_pointer'], 'JSON标准号': row['standard_no'], '匹配方式': row['rule'], '结构化标准号': row['structured_standards'], '提取Excel行': row['structured_rows'], 'records索引': row['standard_record_indexes'], '别名证据': row['alias_evidence']} for row in coverage]
    write_records_sheet(workbook, '标准匹配与覆盖', coverage_rows)
    rules = [['审核边界', summary['conclusion']], ['Agent原文审核声明', str(metadata)], ['实际正式依据', str({code: item['provenance'] for code, item in basis.items()})], ['程序职责', '仅验证结构、阶段门槛、覆盖与证据定位；不根据关键词制造专业结论。'], ['保留口径', '主表权威；等义翻译/版次与纯空格不机械判错；多方法按原文独立程序确认；缺标准仅披露；同根因合并；评审员确认独立。'], ['阶段输入', str({key: str(Path(value).resolve()) for key, value in inputs.items()})]]
    write_pairs_sheet(workbook, '审核口径', rules, ['项目', '审核口径'])
    if unresolved:
        write_records_sheet(workbook, '待补充证据', unresolved)
    for sheet in workbook:
        # Preserve arbitrary source strings as text (including leading '=').
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str):
                    cell.data_type = 's'
        sheet.sheet_properties.pageSetUpPr.fitToPage = True
        sheet.page_setup.orientation = 'landscape'
        sheet.page_setup.paperSize = sheet.PAPERSIZE_A3
        sheet.page_setup.fitToWidth = 1
        sheet.page_setup.fitToHeight = 0
        sheet.print_title_rows = '1:1'
    path = output / ('能力标准覆盖_待补充.xlsx' if status == 'blocked' else '能力表审核_待评审员确认.xlsx')
    from .model import atomic_save
    atomic_save(workbook.save, path)
    check = load_workbook(path, read_only=True, data_only=False)
    if len(list(check['标准匹配与覆盖'].iter_rows(min_row=2))) != len(coverage):
        raise ValueError('审核Excel重开覆盖数量不一致')
    check.close()
    exchange = output / '能力审核_证据交换.json'
    write_json(exchange, {'metadata': metadata, 'summary': summary, 'issues': issues, 'coverage': coverage, 'basis': {code: item['provenance'] for code, item in basis.items()}})
    trace = [{'reviewer': reviewer, 'source_file': row['source_file'], 'source_sheet': row['source_sheet'], 'source_row': row['source_row'], 'json_pointer': row['json_pointer'], 'evidence_refs': [{'type': 'standard', 'json_pointer': '/records/%d' % i, 'source_file': records[i]['source_file'], 'locator': records[i]['evidence'], 'records_sha256': sha256(inputs['standards_records'])} for i in row['standard_record_indexes']]} for row in coverage]
    return {'status': status, 'stage': 'capability.audit', 'artifacts': [{'path': str(path), 'role': 'capability_coverage_workbook' if status == 'blocked' else 'capability_audit_workbook'}, {'path': str(exchange), 'role': 'capability_audit_exchange'}], 'summary': summary, 'trace': trace, 'unresolved': unresolved, 'gates': gates, 'basis_provenance': {code: item['provenance'] for code, item in basis.items()}}
