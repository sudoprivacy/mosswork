# -*- coding: utf-8 -*-
"""Inventory every physical file, preserving per-page native/OCR state."""
import zipfile
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree

from ._io import atomic_bytes, sha256

SUPPORTED = {'.pdf', '.doc', '.docx', '.txt'}


def inventory_folder(folder, output_dir):
    root, output = Path(folder).resolve(), Path(output_dir).resolve()
    if not root.is_dir():
        raise ValueError('Standard folder does not exist: %s' % root)
    files = []
    # Unsupported/temporary files are visible, never silently excluded from coverage.
    for source in sorted(p for p in root.rglob('*') if p.is_file()):
        rel, ext = source.relative_to(root).as_posix(), source.suffix.lower()
        if source.resolve() != source.absolute():
            raise ValueError('Symlink/reparse source is outside physical inventory policy: %s' % source)
        item = dict(relative_path=rel, extension=ext, size_bytes=source.stat().st_size,
                    sha256=sha256(source), page_count=None, native_text_chars=0,
                    extracted_text_chars=0, needs_ocr=False, status='ok',
                    extraction_mode='', notes='', page_text_chars=[], pending_pages=[])
        text = ''
        try:
            if item['size_bytes'] == 0:
                item.update(status='empty_file', notes='Empty physical source; no content inferred.')
            elif ext == '.pdf':
                import fitz
                with fitz.open(str(source)) as pdf:
                    item['page_count'] = pdf.page_count
                    if pdf.needs_pass:
                        item.update(status='encrypted', notes='Password required; no content extracted.')
                    else:
                        pages = [page.get_text('text') for page in pdf]
                        text = '\n\n'.join(pages)
                        counts = [len(part.strip()) for part in pages]
                        # A mixed native/scan PDF remains pending for each sparse page.
                        pending = [i + 1 for i, count in enumerate(counts) if count < 50]
                        item.update(page_text_chars=counts, pending_pages=pending,
                                    needs_ocr=bool(pending), extraction_mode='pdf_native_text',
                                    status='pending_ocr' if pending else 'ok')
            elif ext == '.docx':
                with zipfile.ZipFile(str(source)) as archive:
                    xml = ElementTree.fromstring(archive.read('word/document.xml'))
                ns = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
                text = '\n'.join(''.join(n.text or '' for n in p.iter(ns + 't'))
                                 for p in xml.iter(ns + 'p'))
                item['extraction_mode'] = 'docx_xml'
            elif ext == '.txt':
                try:
                    text = source.read_text(encoding='utf-8-sig')
                    item['extraction_mode'] = 'text_utf8'
                except UnicodeDecodeError:
                    text = source.read_text(encoding='gb18030')
                    item['extraction_mode'] = 'text_gb18030'
            elif ext == '.doc':
                item.update(status='conversion_required', extraction_mode='legacy_doc_unread',
                            notes='Import an actual read-only Word/converter result; not guessed.')
            else:
                item.update(status='unsupported', notes='Physical file retained; extraction unsupported.')
        except ImportError:
            raise ValueError('inventory PDF action requires PyMuPDF (import fitz)')
        except Exception as exc:
            item.update(status='read_error', notes='%s: %s' % (type(exc).__name__, exc))
        chars = len(text.strip())
        item.update(native_text_chars=chars, extracted_text_chars=chars)
        if item['status'] == 'ok' and not chars:
            item.update(status='empty_text', notes='No searchable text extracted.')
        if text:
            # Keep full original extension to avoid a.pdf/a.docx cache collision.
            cache = output / 'native_text' / (rel + '.txt')
            item['text_path'] = atomic_bytes(cache, text.encode('utf-8'))
            item['text_sha256'] = sha256(cache)
        files.append(item)
    return dict(source_root=str(root), generated_at=datetime.now().astimezone().isoformat(),
                file_count=len(files), files=files, semantic_analysis='Agent-reviewed records required')
