# -*- coding: utf-8 -*-
"""Capability merge and Agent-reviewed audit; optional libraries load on action."""
