# -*- coding: utf-8 -*-
"""Merge a CNAS primary capability workbook with an equipment supplement workbook."""

import hashlib
import re
import unicodedata
from collections import Counter, defaultdict




def text(value):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def norm(value):
    value = unicodedata.normalize("NFKC", text(value)).lower()
    value = re.sub(r"<[^>]+>", "", value)
    value = re.sub(r"[\s\u3000]+", "", value)
    return re.sub(r"[，,。；;：:（）()\[\]【】'\"“”‘’·—–\-_/\\]", "", value)


def split_ids(value):
    values = re.split(r"[,，;；\s]+", text(value))
    return list(dict.fromkeys(item.strip() for item in values if item.strip()))


def stable_id(*parts):
    raw = "\x1f".join(text(part) for part in parts).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]


def parse_supplement(data):
    rows = []
    current_object = {
        "category_no": "", "name_zh": "", "name_en": "", "energy_star": "N",
        "contains_all": "N", "bluetooth": "N",
    }
    current_parameter = {
        "name_zh": "", "name_en": "", "is_all": "N", "field_codes": [], "appendix_expand": "N",
    }
    for excel_row, source in enumerate(data[2:], start=3):
        row = list(source) + [""] * max(0, 25 - len(source))
        if not any(row[:25]):
            continue
        if row[1]:
            current_object = {
                "category_no": row[0], "name_zh": row[1], "name_en": row[2],
                "energy_star": row[3] or "N", "contains_all": row[4] or "N", "bluetooth": row[5] or "N",
            }
            current_parameter = {
                "name_zh": "", "name_en": "", "is_all": "N", "field_codes": [], "appendix_expand": "N",
            }
        if row[6]:
            current_parameter = {
                "name_zh": row[6], "name_en": row[7], "is_all": row[8] or "N",
                "field_codes": split_ids(row[9]), "appendix_expand": row[10] or "N",
            }
        if not row[11] and not row[13]:
            continue
        rows.append({
            "source_row": excel_row,
            "object": dict(current_object),
            "parameter": dict(current_parameter),
            "method_name_zh": row[11],
            "method_name_en": row[12],
            "standard_no": row[13],
            "standard_no_en": row[14],
            "clause": row[15],
            "clause_en": row[16],
            "limitation": row[17],
            "limitation_en": row[18],
            "change_note": row[19],
            "change_note_en": row[20],
            "start_date": row[21],
            "tests_last_2_years": row[22],
            "equipment_ids": split_ids(row[23]),
            "assessment_assignment": row[24],
        })
    return rows


def parse_equipment(data):
    equipment = {}
    duplicates = []
    for excel_row, source in enumerate(data[1:], start=2):
        row = list(source) + [""] * max(0, 9 - len(source))
        equipment_id = row[0]
        if not equipment_id:
            continue
        item = {
            "equipment_id": equipment_id,
            "type": row[1],
            "name": row[2],
            "model_spec": row[3],
            "measurement_range": row[4],
            "metrological_spec": row[5],
            "traceability_method": row[6],
            "confirmed": row[7],
            "note": row[8],
            "source_row": excel_row,
        }
        key = norm(equipment_id)
        if key in equipment:
            duplicates.append({"equipment_id": equipment_id, "rows": [equipment[key]["source_row"], excel_row]})
        else:
            equipment[key] = item
    return equipment, duplicates


def make_index(rows, fields):
    result = defaultdict(list)
    for index, row in enumerate(rows):
        result[tuple(norm(row.get(field, "")) for field in fields)].append(index)
    return result


def merge(primary, supplement, equipment, equipment_duplicates):
    tiers = [
        ("exact_5_fields", ("object_zh", "parameter_zh", "standard_no", "method_name_zh", "clause"), "high"),
        ("exact_without_clause", ("object_zh", "parameter_zh", "standard_no", "method_name_zh"), "high"),
        ("object_parameter_standard", ("object_zh", "parameter_zh", "standard_no"), "medium"),
        ("parameter_standard_method", ("parameter_zh", "standard_no", "method_name_zh"), "medium"),
        ("parameter_standard", ("parameter_zh", "standard_no"), "low"),
    ]
    for row in supplement:
        row["object_zh"] = row["object"].get("name_zh", "")
        row["parameter_zh"] = row["parameter"].get("name_zh", "")
    indexes = {name: make_index(supplement, fields) for name, fields, _ in tiers}
    probes = []
    for row in primary:
        probe = dict(row)
        probe["object_zh"] = row["object"].get("name_zh", "")
        probe["parameter_zh"] = row["parameter"].get("name_zh", "")
        probes.append(probe)

    capabilities = []
    match_counts = Counter()
    used_supplement = Counter()
    ambiguous = []
    unresolved_equipment = Counter()
    for primary_index, row in enumerate(primary):
        probe = probes[primary_index]
        match = None
        meta = {"status": "unmatched", "rule": None, "confidence": "none", "supplement_source_rows": []}
        for rule, fields, confidence in tiers:
            key = tuple(norm(probe.get(field, "")) for field in fields)
            candidates = indexes[rule].get(key, [])
            if len(candidates) == 1:
                chosen = candidates[0]
                match = supplement[chosen]
                used_supplement[chosen] += 1
                meta = {"status": "matched", "rule": rule, "confidence": confidence, "supplement_source_rows": [match["source_row"]]}
                break
            if len(candidates) > 1:
                ambiguous.append({"primary_row": row["source_row"], "rule": rule, "candidate_rows": [supplement[index]["source_row"] for index in candidates]})
                meta = {"status": "ambiguous", "rule": rule, "confidence": "none", "supplement_source_rows": []}
                break
        match_counts[meta["status"]] += 1
        equipment_ids = match["equipment_ids"] if match else []
        equipment_items = []
        for equipment_id in equipment_ids:
            item = equipment.get(norm(equipment_id))
            if item:
                equipment_items.append({key: value for key, value in item.items() if key != "source_row"})
            else:
                unresolved_equipment[equipment_id] += 1
        capability_id = row["std_id"] or stable_id(
            probe["object_zh"], probe["parameter_zh"], row["standard_no"], row["method_name_zh"], row["clause"], row["source_row"]
        )
        capabilities.append({
            "capability_id": capability_id,
            "category": {"name_zh": row["object"].get("category_zh", ""), "name_en": row["object"].get("category_en", "")},
            "object": {
                "id": row["obj_id"], "sequence": row["object"].get("sequence", ""),
                "name_zh": probe["object_zh"], "name_en": row["object"].get("name_en", ""),
                "energy_star": row["object"].get("energy_star", "N"), "bluetooth": row["object"].get("bluetooth", "N"),
            },
            "parameter": {
                "id": row["param_id"], "sequence": row["parameter"].get("sequence", ""),
                "name_zh": probe["parameter_zh"], "name_en": row["parameter"].get("name_en", ""),
                "field_codes": row["parameter"].get("field_codes", []),
            },
            "method": {
                "id": row["std_id"], "sequence": row["method_sequence"],
                "name_zh": row["method_name_zh"], "name_en": row["method_name_en"],
                "standard_no": row["standard_no"], "standard_no_en": row["standard_no_en"],
                "clause": row["clause"], "clause_en": row["clause_en"],
                "limitation": row["limitation"], "limitation_en": row["limitation_en"],
            },
            "application": {
                "change_note": row["change_note"], "change_note_en": row["change_note_en"],
                "recommended": row["recommended"], "recommender": row["recommender"],
            },
            "operational": {
                "start_date": match["start_date"] if match else "",
                "tests_last_2_years": match["tests_last_2_years"] if match else "",
                "assessment_assignment": match["assessment_assignment"] if match else "",
            },
            "equipment_ids": equipment_ids,
            "equipment": equipment_items,
            "match": meta,
            "source": {
                "primary_sheet": "检测能力范围", "primary_row": row["source_row"],
                "supplement_sheet": "检测能力范围", "supplement_rows": meta["supplement_source_rows"],
            },
        })

    unmatched_supplement = [row["source_row"] for index, row in enumerate(supplement) if not used_supplement[index]]
    capability_ids = [item["capability_id"] for item in capabilities]
    duplicate_capability_ids = sorted(key for key, count in Counter(capability_ids).items() if count > 1)
    matched = sum(count for status, count in match_counts.items() if status.startswith("matched"))
    with_equipment = sum(bool(item["equipment_ids"]) for item in capabilities)
    complete_equipment = sum(
        bool(item["equipment_ids"]) and len(item["equipment_ids"]) == len(item["equipment"])
        for item in capabilities
    )
    missing_clause_en = [item["source"]["primary_row"] for item in capabilities if item["method"]["clause"] and not item["method"]["clause_en"]]
    missing_limitation_en = [item["source"]["primary_row"] for item in capabilities if item["method"]["limitation"] and not item["method"]["limitation_en"]]
    report = {
        "summary": {
            "primary_capability_records": len(capabilities),
            "supplement_capability_records": len(supplement),
            "equipment_master_records": len(equipment),
            "matched_primary_records": matched,
            "unmatched_primary_records": len(capabilities) - matched,
            "primary_match_rate": round(matched / len(capabilities), 6) if capabilities else 0,
            "primary_records_with_equipment": with_equipment,
            "equipment_enrichment_rate": round(with_equipment / len(capabilities), 6) if capabilities else 0,
            "records_with_all_equipment_ids_resolved": complete_equipment,
            "unmatched_supplement_records": len(unmatched_supplement),
            "records_with_english_clause": sum(bool(item["method"]["clause_en"]) for item in capabilities),
            "records_with_english_limitation": sum(bool(item["method"]["limitation_en"]) for item in capabilities),
        },
        "match_rule_counts": dict(Counter(item["match"]["rule"] or "unmatched" for item in capabilities)),
        "integrity_checks": {
            "json_record_count_equals_primary": len(capabilities) == len(primary),
            "capability_ids_unique": not duplicate_capability_ids,
            "equipment_master_ids_unique": not equipment_duplicates,
            "all_referenced_equipment_ids_resolved": not unresolved_equipment,
            "english_clause_field_present_in_all_records": all("clause_en" in item["method"] for item in capabilities),
            "english_limitation_field_present_in_all_records": all("limitation_en" in item["method"] for item in capabilities),
        },
        "issues": {
            "duplicate_capability_ids": duplicate_capability_ids,
            "duplicate_equipment_ids": equipment_duplicates,
            "unresolved_equipment_references": dict(unresolved_equipment),
            "ambiguous_match_attempts": ambiguous,
            "unmatched_primary_rows": [item["source"]["primary_row"] for item in capabilities if not item["match"]["status"].startswith("matched")],
            "unmatched_supplement_rows": unmatched_supplement,
            "primary_rows_with_chinese_clause_but_no_source_english_clause": missing_clause_en,
            "primary_rows_with_chinese_limitation_but_no_source_english_limitation": missing_limitation_en,
        },
    }
    return capabilities, report

