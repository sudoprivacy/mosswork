# -*- coding: utf-8 -*-
"""Reviewer-scoped attendance and satisfactory-utilization diagnostics."""
import math
import re
from collections import OrderedDict
from datetime import date
from .basis import fingerprint, file_hash
from .xlsx_reader import load_workbook, clean, parse_date, parse_item_times

HEADERS = ('参加时间', '参加结果', '备注', '操作人', '能力验证领域', '项次')


def signature(value):
    return re.sub(r'[\s\-\_—–－/／]+', '', str(value)).lower()


def reviewer_matches(value, reviewer):
    """Match a complete operator name, including delimited multiple operators."""
    target, raw = clean(reviewer), clean(value)
    if not target or not raw:
        return False
    if raw == target:
        return True
    return target in [token for token in re.split(r'[,，;；、/\s]+', raw) if token]


def result_status(result, remark):
    # Negation/pending must win over the substring 满意.
    result = clean(result)
    if any(w in result for w in ('不满意', '非满意')):
        return 'unsatisfactory'
    if any(w in result for w in ('尚未', '未出', '等待', '待结果', '结果待', '待通知', '待样品', '待评价')):
        return 'pending'
    if '满意' in result and not any(w in result for w in ('是否', '可疑', '部分', '待确认', '未确认', '可能', '不符合')):
        return 'satisfactory'
    if not result and any(w in remark for w in ('尚未', '未出', '等待', '待结果', '结果待', '待通知', '待样品')):
        return 'pending'
    return 'other'


def locate(wb, sheet):
    candidates = []
    for name in wb.sheetnames:
        if sheet and name != sheet:
            continue
        ws = wb[name]
        for r in range(1, min(ws.max_row, 30) + 1):
            headers = {clean(ws.cell(r, c).value): c for c in range(1, ws.max_column + 1)}
            if all(h in headers for h in HEADERS):
                candidates.append((ws, r, headers))
    if len(candidates) != 1:
        raise ValueError('须唯一识别含必需统计列的能力验证表；候选数=%d' % len(candidates))
    return candidates[0]


def analyze(path, model, reviewer, options, assessment_date, receipt=None):
    cutoff = date.fromisoformat(options.get('as_of') or assessment_date)
    year = options.get('review_year', cutoff.year)
    years = options.get('years', 3)
    if isinstance(years, bool) or not isinstance(years, int) or years < 1:
        raise ValueError('years 须为正整数')
    if isinstance(year, bool) or not isinstance(year, int) or cutoff.year != year:
        raise ValueError('review_year 必须与实际截止日期同年')
    start = date(year - years + 1, 1, 1)
    tag = options.get('use_tag') or '%d利用' % year
    if not reviewer:
        raise ValueError('summary 需要指定评审员')
    source_hash = file_hash(path)
    if receipt:
        if receipt.get('output_sha256') != source_hash or receipt.get('basis_fingerprint') != model['basis_fingerprint'] or receipt.get('reviewer') != reviewer:
            raise ValueError('summary 与 apply 回执的工作簿/依据/评审员不一致')
        if not all(re.fullmatch('[0-9a-f]{64}', str(receipt.get(k, ''))) for k in ('mapping_fingerprint', 'preparation_fingerprint')):
            raise ValueError('apply 回执缺少映射/准备阶段指纹')
        mapping = receipt.get('reviewed_mapping')
        if not mapping or fingerprint(mapping) != receipt['mapping_fingerprint']:
            raise ValueError('apply 回执完整审核映射与 mapping_fingerprint 不一致')
        from .mapping import immutable_fingerprint
        if immutable_fingerprint(mapping) != receipt['preparation_fingerprint'] or mapping.get('basis_fingerprint') != model['basis_fingerprint']:
            raise ValueError('apply 回执准备指纹或选定依据不一致')
        expected_rows = []
        for row in mapping['rows']:
            expected_rows.append(dict(row, item_count=row['auto_item_count'] if row.get('item_count_override') is None else row['item_count_override']))
        if receipt.get('rows') != expected_rows:
            raise ValueError('apply 回执行决策与审核映射不一致')
    wb = load_workbook(path)
    try:
        ws, header, headers = locate(wb, options.get('sheet') or (receipt or {}).get('sheet'))
        records, errors, warnings = [], [], []
        allowed = {signature(r['value']): r for r in model['allowed_domains']}
        allocation_by_row = {r['excel_row']: r.get('domain_item_counts', {}) for r in (receipt or {}).get('rows', [])}
        for key, value in options.get('domain_item_counts', {}).items():
            row_number = int(key)
            if allocation_by_row.get(row_number) and allocation_by_row[row_number] != value:
                raise ValueError('summary 多领域项次分配与 apply 回执不一致')
            allocation_by_row[row_number] = value
        for row in range(header + 1, ws.max_row + 1):
            def value(h):
                return ws.cell(row, headers[h]).value if h in headers else None
            if not any(clean(ws.cell(row, c).value) for c in range(1, ws.max_column + 1)):
                continue
            when = parse_date(value('参加时间'))
            profi, plan = clean(value('profiCheckId')), clean(value('计划编号'))
            domains = [v.strip() for v in re.split('[；;\n]', clean(value('能力验证领域'))) if v.strip()]
            records.append({'row': row, 'date': when.isoformat() if when else None,
                            'operator': clean(value('操作人')), 'domain_raw': clean(value('能力验证领域')),
                            'domains': domains, 'item_times': parse_item_times(value('项次')),
                            'item_times_raw': clean(value('项次')), 'result': clean(value('参加结果')),
                            'remark': clean(value('备注')), 'profiCheckId': profi, 'plan_number': plan,
                            'project': clean(value('能力验证类型')),
                            'event_key': ('id:' + profi) if profi else ('plan:' + plan) if plan else None,
                            'status': result_status(value('参加结果'), clean(value('备注')))})
        # A continuation row may omit profiCheckId while retaining the same plan.
        # Resolve only a unique ID; never merge distinct IDs merely by similar text.
        plan_ids = {}
        for r in records:
            if r['plan_number'] and r['profiCheckId']:
                plan_ids.setdefault(r['plan_number'], set()).add(r['profiCheckId'])
        for r in records:
            if not r['profiCheckId'] and r['plan_number']:
                ids = plan_ids.get(r['plan_number'], set())
                if len(ids) == 1:
                    r['event_key'] = 'id:' + next(iter(ids))
                    r['event_key_resolved_from_plan'] = True
                elif len(ids) > 1 and reviewer_matches(r['operator'], reviewer):
                    errors.append('第%d行计划编号关联多个 profiCheckId，次数去重须复核' % r['row'])
        event_dates = {}
        for r in records:
            if r['event_key'] and r['date']:
                event_dates.setdefault(r['event_key'], set()).add(r['date'])
        selected = []
        for r in records:
            if not reviewer_matches(r['operator'], reviewer):
                continue
            dates = event_dates.get(r['event_key'], set())
            if not r['date'] and len(dates) == 1:
                r['date'] = next(iter(dates))
                r['date_inherited_from_event'] = True
            if not r['date']:
                errors.append('第%d行属于评审员但参加时间缺失/歧义，不能静默排除' % r['row'])
                continue
            if not start.isoformat() <= r['date'] <= cutoff.isoformat():
                continue
            if len(dates) > 1:
                errors.append('第%d行同一计划存在冲突日期，须核对' % r['row'])
            if not r['event_key']:
                errors.append('第%d行缺 profiCheckId 和计划编号，无法可靠去重' % r['row'])
                r['event_key'] = 'unresolved-row:%d' % r['row']
            selected.append(r)
        confirmed = [r for r in selected if r['domains'] and r['item_times'] is not None]
        if not confirmed:
            errors.append('近%d自然年无指定评审员已确认领域及有效项次的记录' % years)
        for r in selected:
            if r['domains'] and r['item_times'] is None:
                errors.append('第%d行已填领域但项次缺失/无效' % r['row'])
            if not r['domains'] and r['item_times'] is not None:
                warnings.append('第%d行领域为空，不计分领域参加；当年利用且满意时仍计总利用' % r['row'])
        groups = OrderedDict()
        for r in confirmed:
            domains = []
            for raw in r['domains']:
                entry = allowed.get(signature(raw))
                if not entry:
                    errors.append('第%d行领域未列入选定依据：%s' % (r['row'], raw))
                    continue
                if entry['value'] in domains:
                    errors.append('第%d行重复领域标签' % r['row'])
                    continue
                domains.append(entry['value'])
            allocation = allocation_by_row.get(r['row'], {})
            if len(domains) > 1:
                if set(allocation) != set(domains) or any(isinstance(n, bool) or not isinstance(n, int) or n < 1 for n in allocation.values()) or sum(allocation.values()) != r['item_times']:
                    errors.append('第%d行跨领域项次未明确分配，不能重复累计总项次' % r['row'])
                    allocation = {}
            for domain in domains:
                group = groups.setdefault(domain, {'events': set(), 'item_times': 0, 'source_rows': [],
                                                   'satisfactory': set(), 'pending': set(),
                                                   'unsatisfactory': set(), 'other': set()})
                group['events'].add(r['event_key'])
                group[r['status']].add(r['event_key'])
                group['item_times'] += r['item_times'] if len(domains) == 1 else allocation.get(domain, 0)
                group['source_rows'].append(r['row'])
        stats = []
        for domain, group in groups.items():
            stats.append(dict(domain=domain, times=len(group['events']), item_times=group['item_times'],
                              source_rows=group['source_rows'], **{s + '_times': len(group[s]) for s in ('satisfactory', 'pending', 'unsatisfactory', 'other')}))
        requested = options.get('applicable_domains')
        full_scope = options.get('full_scope') is True
        if full_scope and (not requested or not options.get('scope_evidence')):
            errors.append('full_scope 模式缺适用领域清单或范围证据 scope_evidence')
        requirement_domains = requested if requested is not None else list(groups)
        if not isinstance(requirement_domains, list):
            raise ValueError('applicable_domains 须为领域标签数组')
        checks = []
        for raw in requirement_domains:
            entry = allowed.get(signature(raw))
            if not entry:
                errors.append('适用领域清单含选定依据以外领域：%s' % raw)
                continue
            domain = entry['value']
            group = groups.get(domain, {'events': set()})
            n, period = entry['times_per_period'], entry['period_years']
            minimum = n * int(math.ceil(float(years) / period)) if n and period else None
            meets = minimum is not None and len(group['events']) >= minimum
            if not meets:
                errors.append('%s 的参加次数不足数量筛查值或频次原文不能可靠解析' % domain)
            checks.append({'domain': domain, 'minimum_frequency': entry['frequency'],
                           'derived_required_times': minimum, 'actual_times': len(group['events']),
                           'meets_quantity_screen': meets, 'evidence_refs': entry['evidence_refs'],
                           'screening_method': '最低次数 × ceil(自然年数量/原文周期年数)，不替代滚动周期、条款条件及评审判断'})
        if requested is not None:
            requested_keys = {signature(x) for x in requested}
            for domain in groups:
                if signature(domain) not in requested_keys:
                    errors.append('已确认统计域不在显式适用领域清单：%s' % domain)
        pending = [r for r in confirmed if r['status'] == 'pending']
        unsatisfactory = [r for r in confirmed if r['status'] == 'unsatisfactory']
        other = [r for r in confirmed if r['status'] == 'other']
        if unsatisfactory:
            errors.append('存在非满意结果，须人工核明并采用实际结果措辞：%s' % [r['row'] for r in unsatisfactory])
        if other:
            errors.append('参加结果无法判定，不能表述其余均满意：%s' % [r['row'] for r in other])
        marked = [r for r in selected if tag in r['remark']]
        invalid_used = [r for r in marked if r['item_times'] is None]
        if invalid_used:
            errors.append('标记%s但项次无效：%s' % (tag, [r['row'] for r in invalid_used]))
        used = [r for r in marked if r['status'] == 'satisfactory' and r['item_times'] is not None]
        excluded = [r for r in marked if r['status'] != 'satisfactory']
        if excluded:
            warnings.append('利用标记中非满意或未出结果已排除：%s' % [r['row'] for r in excluded])
        utilization = sum(r['item_times'] for r in used)
        ready = not errors
        draft = None
        if ready:
            phrase = '、'.join('%s能力验证%d次%d项次' % (s['domain'].replace('-', ''), s['times'], s['item_times']) for s in stats)
            pending_phrase = '、'.join('%d次%s能力验证结果未出' % (s['pending_times'], s['domain'].replace('-', '')) for s in stats if s['pending_times'])
            result_clause = '除%s外，其余均为满意' % pending_phrase if pending_phrase else '结果均为满意'
            basis = model['project_basis'] or model['basis']
            label = '%s:%s' % (basis.get('code', 'CNAS-RL02'), basis['version'])
            draft = ('近%d年来（%s至%s），按所供审核资料中的领域及项次统计（指定评审员：%s），实验室参加%s，%s。'
                     '上述统计领域的参加次数达到所选%s依据所列最低频次的数量筛查值；'
                     '本说明不替代完整申请范围覆盖及原文周期、条件的评审核实。'
                     '本次评审利用能力验证满意结果%d项次。') % (years, start, cutoff, reviewer, phrase, result_clause, label, utilization)
        row_fingerprint = fingerprint([{'row': r['row'], 'domains': r['domains'], 'item_times': r['item_times']} for r in records])
        report = {'schema_version': '1.1.0', 'basis_fingerprint': model['basis_fingerprint'],
                  'mapping_fingerprint': receipt['mapping_fingerprint'] if receipt else row_fingerprint,
                  'mapping_fingerprint_kind': 'reviewed_mapping' if receipt else 'standalone_workbook_rows',
                  'workbook_sha256': source_hash,
                  'inputs': {'xlsx': str(path), 'sheet': ws.title, 'reviewer': reviewer,
                             'review_year': year, 'use_tag': tag, 'window_start': str(start), 'window_end': str(cutoff),
                             'requirements_scope': 'explicit' if requested is not None else 'confirmed_domains',
                             'requirements_source': model['project_basis'] or model['basis']},
                  'domain_statistics': stats, 'frequency_checks': checks,
                  'pending_rows': pending, 'unsatisfactory_rows': unsatisfactory, 'other_result_rows': other,
                  'reviewer_records': selected,
                  'utilization': {'satisfactory_item_times': utilization, 'source_rows': [r['row'] for r in used],
                                  'source_item_times': [r['item_times'] for r in used],
                                  'marked_but_excluded_rows': [r['row'] for r in excluded],
                                  'unclassified_source_rows': [r['row'] for r in used if not r['domains']]},
                  'warnings': warnings, 'errors': errors, 'ready_to_issue': ready, 'draft': draft}
        if file_hash(path) != source_hash:
            raise ValueError('统计期间源工作簿发生变化')
        return report
    finally:
        wb.close()
