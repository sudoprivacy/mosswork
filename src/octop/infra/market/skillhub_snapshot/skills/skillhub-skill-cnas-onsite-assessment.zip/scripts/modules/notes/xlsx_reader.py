#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Small, dependency-free XLSX/XLSM value reader used by this skill.

This module implements only the workbook APIs required by
``analyze_capability_diff.py``.  It intentionally ignores formatting because
the CNAS comparison is based on cell values, not Excel styles.
"""

import datetime as dt
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path


_WORKBOOK_XML = "xl/workbook.xml"
_WORKBOOK_RELS_XML = "xl/_rels/workbook.xml.rels"
_SHARED_STRINGS_XML = "xl/sharedStrings.xml"
_RELATIONSHIP_ID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
_CELL_REFERENCE = re.compile(r"^([A-Za-z]+)([0-9]+)$")


def _local_name(tag):
    return tag.rsplit("}", 1)[-1]


def _column_number(letters):
    value = 0
    for char in letters.upper():
        value = value * 26 + ord(char) - ord("A") + 1
    return value


def _cell_coordinates(reference, fallback_row, fallback_column):
    match = _CELL_REFERENCE.match(reference or "")
    if not match:
        return fallback_row, fallback_column
    return int(match.group(2)), _column_number(match.group(1))


def _parse_numeric(text):
    if text is None or text == "":
        return None
    try:
        if not any(marker in text.lower() for marker in (".", "e")):
            return int(text)
        return float(text)
    except ValueError:
        return text


class _Cell:
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value


class XlsxWorksheet:
    def __init__(self, workbook, title, archive_path):
        self._workbook = workbook
        self.title = title
        self._archive_path = archive_path
        self._loaded = False
        self._rows = {}
        self._max_row = 0
        self._max_column = 0

    def _read_cell(self, cell):
        cell_type = cell.attrib.get("t", "n")
        formula = None
        raw_value = None
        inline_text = None
        for child in cell:
            name = _local_name(child.tag)
            if name == "f":
                formula = child.text or ""
            elif name == "v":
                raw_value = child.text
            elif name == "is":
                inline_text = "".join(
                    node.text or "" for node in child.iter() if _local_name(node.tag) == "t"
                )

        if formula is not None and not self._workbook.data_only:
            return "=" + formula
        if cell_type == "inlineStr":
            return inline_text
        if raw_value is None:
            return None
        if cell_type == "s":
            try:
                return self._workbook.shared_strings[int(raw_value)]
            except (ValueError, IndexError):
                raise ValueError(
                    "共享字符串索引无效：工作表“{}”，单元格{}。".format(
                        self.title, cell.attrib.get("r", "未知")
                    )
                )
        if cell_type == "b":
            return raw_value == "1"
        if cell_type == "d":
            try:
                return dt.datetime.fromisoformat(raw_value.replace("Z", "+00:00"))
            except ValueError:
                return raw_value
        if cell_type in {"str", "e"}:
            return raw_value
        return _parse_numeric(raw_value)

    def _load(self):
        if self._loaded:
            return
        try:
            stream = self._workbook._archive.open(self._archive_path)
        except KeyError as exc:
            raise ValueError(
                "Excel 内缺少工作表文件：{}（工作表“{}”）。".format(self._archive_path, self.title)
            ) from exc

        last_row = 0
        with stream:
            try:
                iterator = ET.iterparse(stream, events=("end",))
                for _, element in iterator:
                    if _local_name(element.tag) != "row":
                        continue
                    row_number = int(element.attrib.get("r") or (last_row + 1))
                    last_row = row_number
                    self._max_row = max(self._max_row, row_number)
                    row_values = self._rows.setdefault(row_number, {})
                    last_column = 0
                    for cell in element:
                        if _local_name(cell.tag) != "c":
                            continue
                        actual_row, column = _cell_coordinates(
                            cell.attrib.get("r"), row_number, last_column + 1
                        )
                        last_column = column
                        self._max_row = max(self._max_row, actual_row)
                        self._max_column = max(self._max_column, column)
                        value = self._read_cell(cell)
                        if value is not None:
                            self._rows.setdefault(actual_row, {})[column] = value
                    element.clear()
            except ET.ParseError as exc:
                raise ValueError("工作表 XML 损坏：{}。".format(self._archive_path)) from exc
        self._loaded = True

    @property
    def max_row(self):
        self._load()
        return self._max_row

    @property
    def max_column(self):
        self._load()
        return self._max_column

    def cell(self, row, column):
        self._load()
        return _Cell(self._rows.get(row, {}).get(column))

    def iter_rows(self, min_row=1, max_row=None, values_only=False):
        self._load()
        final_row = self._max_row if max_row is None else min(max_row, self._max_row)
        for row_number in range(min_row, final_row + 1):
            values = tuple(
                self._rows.get(row_number, {}).get(column)
                for column in range(1, self._max_column + 1)
            )
            if values_only:
                yield values
            else:
                yield tuple(_Cell(value) for value in values)


class XlsxWorkbook:
    def __init__(self, filename, data_only=False):
        self.filename = str(Path(filename))
        self.data_only = bool(data_only)
        try:
            self._archive = zipfile.ZipFile(self.filename, "r")
        except (OSError, zipfile.BadZipFile) as exc:
            raise ValueError("无法打开 Excel 文件或文件不是有效的 XLSX/XLSM：{}".format(filename)) from exc
        self._archive_names = set(self._archive.namelist())
        self._shared_strings = None
        self._worksheets = []
        self._worksheet_by_name = {}
        self._load_workbook_index()

    def _read_xml(self, archive_path, label):
        try:
            with self._archive.open(archive_path) as stream:
                return ET.parse(stream).getroot()
        except KeyError as exc:
            raise ValueError("Excel 内缺少{}：{}。".format(label, archive_path)) from exc
        except ET.ParseError as exc:
            raise ValueError("Excel 内的{} XML 损坏：{}。".format(label, archive_path)) from exc

    def _load_workbook_index(self):
        workbook_root = self._read_xml(_WORKBOOK_XML, "工作簿索引")
        relationships_root = self._read_xml(_WORKBOOK_RELS_XML, "工作簿关系文件")
        relationships = {}
        for relation in relationships_root.iter():
            if _local_name(relation.tag) != "Relationship":
                continue
            relation_id = relation.attrib.get("Id")
            target = relation.attrib.get("Target")
            if relation_id and target and relation.attrib.get("TargetMode") != "External":
                if target.startswith("/"):
                    archive_path = target.lstrip("/")
                else:
                    archive_path = posixpath.normpath(posixpath.join("xl", target.replace("\\", "/")))
                relationships[relation_id] = archive_path

        for sheet in workbook_root.iter():
            if _local_name(sheet.tag) != "sheet":
                continue
            title = sheet.attrib.get("name")
            relation_id = sheet.attrib.get(_RELATIONSHIP_ID)
            if relation_id is None:
                relation_id = next(
                    (value for key, value in sheet.attrib.items()
                     if key.startswith("{") and _local_name(key) == "id"),
                    None,
                )
            archive_path = relationships.get(relation_id)
            if not title or not archive_path:
                continue
            worksheet = XlsxWorksheet(self, title, archive_path)
            self._worksheets.append(worksheet)
            self._worksheet_by_name[title] = worksheet
        if not self._worksheets:
            raise ValueError("Excel 工作簿中未找到可读取的工作表。")

    @property
    def sheetnames(self):
        return [worksheet.title for worksheet in self._worksheets]

    @property
    def worksheets(self):
        return list(self._worksheets)

    @property
    def shared_strings(self):
        if self._shared_strings is not None:
            return self._shared_strings
        if _SHARED_STRINGS_XML not in self._archive_names:
            self._shared_strings = []
            return self._shared_strings
        root = self._read_xml(_SHARED_STRINGS_XML, "共享字符串表")
        strings = []
        for item in root:
            if _local_name(item.tag) != "si":
                continue
            strings.append("".join(
                node.text or "" for node in item.iter() if _local_name(node.tag) == "t"
            ))
        self._shared_strings = strings
        return self._shared_strings

    def __getitem__(self, title):
        try:
            return self._worksheet_by_name[title]
        except KeyError as exc:
            raise KeyError("工作表不存在：{}".format(title)) from exc

    def close(self):
        self._archive.close()


def load_workbook(filename, read_only=True, data_only=False):
    """Open an XLSX/XLSM workbook using Python's standard library only."""
    del read_only  # The reader is always read-only.
    return XlsxWorkbook(filename, data_only=data_only)


__all__ = ["load_workbook", "XlsxWorkbook", "XlsxWorksheet"]
