# -*- coding: utf-8 -*-
"""Small standard-library I/O and evidence identity helpers (Python 3.8+)."""
import hashlib
import json
import os
import tempfile
from pathlib import Path, PurePosixPath


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def atomic_bytes(path, body):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.__standard_', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(body)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, str(path))
        if path.read_bytes() != body:
            raise ValueError('Output readback mismatch: %s' % path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return str(path.resolve())


def write_json(path, value):
    return atomic_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def relative(value):
    value = str(value or '').replace('\\', '/')
    while value.startswith('./'):
        value = value[2:]
    path = PurePosixPath(value)
    if not value or path.is_absolute() or '..' in path.parts or ':' in value:
        raise ValueError('Invalid source relative path: %r' % value)
    return path.as_posix()


def contained(root, rel):
    root = Path(root).resolve()
    target = (root / relative(rel)).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise ValueError('Source path escapes authorized folder: %s' % target)
    return target


def verify_inventory(inventory, source_root=None):
    """Return missing/changed physical sources; reject duplicate/escaping entries."""
    root = Path(source_root or inventory['source_root']).resolve()
    seen, missing, changed = set(), [], []
    for item in inventory.get('files', []):
        rel = relative(item['relative_path'])
        if rel.casefold() in seen:
            raise ValueError('Duplicate inventory path: %s' % rel)
        seen.add(rel.casefold())
        target = contained(root, rel)
        if not target.is_file():
            missing.append(rel)
        elif not item.get('sha256') or sha256(target) != item['sha256']:
            changed.append(rel)
    return missing, changed
