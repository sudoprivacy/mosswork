#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standard-library provenance and stage integrity for optional modules. MIT."""
import hashlib
import json
import os
from pathlib import Path
import re

MODULES = {
    'capability': 'modules.capability.adapter',
    'standards': 'modules.standards.adapter',
    'pt': 'modules.pt.adapter',
    'notes': 'modules.notes.adapter',
}

def sha256(path):
    digest=hashlib.sha256()
    expected=Path(path).stat().st_size;count=0
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda:handle.read(1024*1024),b''):
            digest.update(chunk);count+=len(chunk)
    if count!=expected or Path(path).stat().st_size!=expected:raise ValueError('Incomplete or changing input read')
    return digest.hexdigest()

def inside(path,root):
    path,root=Path(path).resolve(),Path(root).resolve()
    return path==root or root in path.parents

def reject_links(path):
    """Reject lexical symlinks and Windows junction/reparse ancestors before resolve."""
    candidate=Path(os.path.abspath(str(path)))
    for part in [candidate]+list(candidate.parents):
        if part.is_symlink():raise ValueError('Symbolic links are not supported: '+str(part))
        try:attributes=getattr(part.lstat(),'st_file_attributes',0)
        except FileNotFoundError:continue
        if attributes & 0x400:raise ValueError('Reparse points are not supported: '+str(part))

def local_path(root,relative):
    if not isinstance(relative,str) or not relative or '\\' in relative:
        raise ValueError('Expected a portable relative project path')
    part=Path(relative)
    if part.is_absolute() or '..' in part.parts or ':' in relative:
        raise ValueError('Project path escapes the case')
    lexical=Path(root)/part
    reject_links(lexical)
    target=lexical.resolve()
    if not inside(target,root):raise ValueError('Project path escapes the case')
    return target

def tree_manifest(root):
    reject_links(root)
    root=Path(root).resolve()
    if not root.is_dir():raise ValueError('Expected an input directory')
    result=[]
    for path in sorted(root.rglob('*')):
        reject_links(path)
        if path.is_symlink() or not inside(path,root):raise ValueError('Symbolic links are not supported in input/output trees')
        if path.is_file():result.append({'path':path.relative_to(root).as_posix(),'sha256':sha256(path)})
    return result

def tree_hash(root):
    value=json.dumps(tree_manifest(root),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(value).hexdigest()

def validate_workflow(case,directory):
    workflow=case.get('workflow')
    if workflow is None:return {'runs':0}
    if not isinstance(workflow,dict) or workflow.get('schema_version')!='1.0.0' or not isinstance(workflow.get('runs'),list):
        raise ValueError('Invalid workflow schema')
    ids=set(); latest={}
    for event in case['history']:
        if event.get('event')=='module_run':
            run=event.get('details',{}).get('run')
            if not isinstance(run,dict):raise ValueError('Missing module history snapshot')
            latest[run.get('id')]=run
    for run in workflow['runs']:
        rid=run.get('id')
        if not isinstance(rid,str) or not rid.startswith(case['case_id']+':M') or rid in ids:
            raise ValueError('Invalid or duplicate module run ID')
        ids.add(rid)
        if run.get('module') not in MODULES or run.get('status') not in {'completed','needs_review','blocked','failed'}:
            raise ValueError('Invalid module run state')
        if latest.get(rid)!=run:raise ValueError('Module run differs from immutable history snapshot')
        for key in ['inputs','artifacts']:
            if not isinstance(run.get(key),list):raise ValueError('Invalid module '+key)
            for item in run[key]:
                file=local_path(directory,item.get('path'))
                is_dir=item.get('kind')=='directory' and key=='inputs'
                actual=tree_hash(file) if is_dir and file.is_dir() else sha256(file) if not is_dir and file.is_file() else None
                if not re.fullmatch('[a-f0-9]{64}',item.get('sha256','')) or actual!=item['sha256']:
                    raise ValueError('Module '+key+' hash mismatch: '+str(item.get('path')))
        for parent in run.get('upstream_runs',[]):
            if parent not in ids or parent==rid:raise ValueError('Unknown or forward module stage dependency')
        for basis in run.get('basis',[]):
            matching=[s for s in case.get('snapshots',[]) if s['doc_id']==basis['doc_id']]
            if len(matching)!=1 or matching[0]['sha256']!=basis['json_sha256']:
                raise ValueError('Module basis is not pinned to this case')
    if set(latest)!=ids:raise ValueError('Module run removed from history')
    return {'runs':len(ids),'by_status':{state:sum(r['status']==state for r in workflow['runs']) for state in ['completed','needs_review','blocked','failed']}}

def render_workflow(case,directory,report_dir):
    import html
    import os
    from urllib.parse import quote
    esc=lambda value:html.escape(str(value),quote=True)
    statuses={'completed':'操作完成','needs_review':'待复核','blocked':'受阻','failed':'技术失败'}
    stages={'capability.merge':'能力与设备信息合并','capability.audit':'检测能力审核','standards.inventory':'标准文件盘点','standards.split':'PDF分段','standards.ocr_import':'导入OCR结果','standards.ocr_client':'OCR识别','standards.build':'标准结构化结果','standards.rename_preview':'标准命名预览','standards.rename_apply':'标准重命名','pt.prepare':'能力验证审核准备','pt.apply':'能力验证审核副本','pt.summary':'能力验证统计说明','notes.compare':'现场前后差异比较','notes.render':'现场附加说明'}
    labels={'primary_capability_records':'主表能力记录','supplement_capability_records':'补充表记录','equipment_master_records':'设备记录','matched_primary_records':'匹配主表记录','unmatched_primary_records':'未匹配主表记录','primary_match_rate':'主表匹配率','reviewer':'指定评审员','reviewer_records':'评审员相关记录','method_standard_count':'方法标准数量','method_word_lines':'方法待核条目','validation_passed':'完整性校验','file_count':'物理文件数','native_success_files':'原生文本提取成功数','coverage_passed':'标准覆盖检查','page_count':'页数','chunk_count':'分段数','ocr_performed':'已执行OCR','successful_segments':'成功页段数','failed_attempts':'失败尝试数','rows':'待审核行数','total_rows':'总行数','matched_rows':'已匹配领域行数','unmatched_rows':'未匹配领域行数','multi_domain_rows':'多个领域行数','item_count_overrides':'项次人工调整数','source_sha256_unchanged':'源文件哈希未变','ready_to_issue':'材料具备出稿条件','utilization_items':'满意结果利用项次','counted_rows':'纳入统计行数','rename_count':'重命名数量','preview_only':'仅预览','content_hashes_unchanged':'内容哈希未变','partial_coverage_authorized':'已授权部分覆盖','matched_before_rows':'评审前相关行数','matched_after_rows':'评审后相关行数','change_count':'变化数量','not_recommended_count':'不推荐参数数','restriction_count':'限制参数数'}
    rows=[]
    for run in case.get('workflow',{}).get('runs',[]):
        links=[]
        for item in run['artifacts']:
            label=esc(Path(item['path']).name)
            if directory and report_dir:
                href=quote(os.path.relpath(local_path(directory,item['path']),report_dir).replace('\\','/'),safe='/')
                label='<a href="'+href+'">'+label+'</a>'
            links.append('<li>'+label+'</li>')
        facts=[]
        for key,label in labels.items():
            if key in run['summary'] and not isinstance(run['summary'][key],(dict,list)):
                value=run['summary'][key]
                shown=('是' if value else '否') if isinstance(value,bool) else str(value)
                facts.append('<li>'+label+'：'+esc(shown)+'</li>')
        gates=['<li>'+('通过' if g.get('passed') else '待处理')+'：'+esc(g.get('detail',''))+'</li>' for g in run.get('gates',[])]
        unresolved=run.get('unresolved',[])
        pending='<p>待核事项：</p><ul>'+''.join('<li>'+esc(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False))+'</li>' for x in unresolved)+'</ul>' if unresolved else ''
        details={k:run.get(k) for k in ['summary','basis','inputs','artifacts','trace']}
        body='<ul>'+''.join(facts)+'</ul><ul>'+''.join(gates)+'</ul>'+pending+'<details class="module-trace"><summary>展开完整结果和溯源</summary><pre>'+esc(json.dumps(details,ensure_ascii=False,indent=2))+'</pre></details>'
        rows.append('<tr data-module="'+esc(run['module'])+'"><td>'+esc(stages.get(run['stage'],run['stage']))+'<br><small>'+esc(run['id'])+'</small></td><td>'+esc(statuses[run['status']])+'<br>'+esc(run['reviewer'])+'</td><td>'+body+'</td><td><ul>'+''.join(links)+'</ul></td></tr>')
    return '<section id="module-workflow"><h2>任务阶段与业务产物</h2><p>模块完成表示本次操作完成；不代表评审员确认或不符合项关闭。打印保留概览、门槛、待核事项及产物；完整溯源见展开项与对应JSON。</p><div class="tools"><label>阶段检索 <input id="module-search" type="search"></label><span id="module-count">'+str(len(rows))+' 个阶段</span></div><div class="scroll"><table id="modules"><thead><tr><th>阶段</th><th>状态 / 评审员</th><th>结果及依据</th><th>产物</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table></div></section>'

def portable_request(request,input_map):
    """Persist case-relative inputs; credentials are never valid request content."""
    cleaned=json.loads(json.dumps(request,ensure_ascii=False))
    cleaned['inputs']=input_map
    return cleaned
