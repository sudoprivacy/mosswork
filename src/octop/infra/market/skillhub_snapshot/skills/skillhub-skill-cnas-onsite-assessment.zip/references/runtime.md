# 离线运行与数据接口

运行环境为 Python 3.8 或更新版本，仅用标准库。以下命令以技能目录为工作目录。案例必须保存在技能目录之外。脚本不联网、不上传、不发布，也不按关键词判断不符合或严重程度。原始代码适用 MIT，CNAS 原文保留自身权利说明。

## 查询与校验

```text
python scripts/cnas_audit.py --help
python scripts/cnas_audit.py catalog --document CNAS-CL01
python scripts/cnas_audit.py lookup --document CNAS-CL01 --version 2018 --clause 6.2.5
python scripts/cnas_audit.py related --document CNAS-CL01 --version 2018
python scripts/cnas_audit.py corpus-validate
```

所有业务命令成功时输出 `{"ok":true,"result":...}` 并返回 0；数据错误输出 `{"ok":false,"error":{"code":...,"message":...,"details":...}}` 并返回 2。`--help` 和参数用法错误遵循 argparse 默认行为。重定向中文时建议用 `python -X utf8`。

主命令前或子命令后可传入 `--corpus /path/to/index.json` 或该索引的目录，默认使用随技能分发的 `references/cnas/index.json`，与工作目录无关。`catalog` 只读取索引元数据；`lookup` 只加载选中文件，不要求把整个语料库读入模型上下文。标准包保留可读的完整普通 JSON；SkillHub / WorkBuddy 使用逐文档无损 LZMA / Base85 封装，普通解析器只能看到封装，须调用本脚本 `read_json` 或 CLI 还原全文，不能将 payload 当作依据内容。

`lookup` 必须提供 `--document`、`--version`，以及互斥的 `--clause` / `--unit` / `--clause-id` 之一。`--revision` 区分同版修订；多个版本候选返回 `ambiguous_document` 及候选，不自动择一。同一正式条款号有多个结构位置时返回 `ambiguous_clause` 及内部条款 ID、标题、页码，据此改用内部 ID 或单元 ID。

`--domain` 和 `--object` 仅筛选已标注领域 / 对象；`general` / `all` 分别保留通用领域 / 对象，不证明本次评审实际适用。`--assessment-date YYYY-MM-DD` 用于提示选用版本生效时间。时效未核实、覆盖需复核和晚于评审日生效的依据均返回警示；历史版本不与现行版本混合。

查询返回完整条款原文、单元原文、块 ID 与物理页码、关联引言 / 条件 / 注、源文件与 JSON 哈希、文档 / 单元 / 块核验状态、覆盖情况、相关表格 / 图示。上下文组装与表格结构为 `derived_view`，权威文本仍在规范块中。默认省略图对象中的 base64 等二进制字段并返回省略字段及长度，必要时使用 `--include-figure-data`。图标题不代表非文本含义已经核验。`related` 只呈现显式记录的关联，不递归下载引用标准或合并不同文件的同号条款。

`corpus-validate` 检查文件哈希、索引元数据、ID 唯一性、引用、逐页文本重建、块页归属、父子关系、表格结构、覆盖计数和页检查。这是结构完整性校验，不声称表格语义或所有原件已经目视核验；抽取核验状态、时效状态和覆盖状态各自保留。

## 案例和快照

```text
python scripts/cnas_audit.py case-init --case-dir ../assessment-case --title "本次现场评审" --assessment-date 2026-11-11
python scripts/cnas_audit.py lookup --document CNAS-CL01 --version 2018 --clause 6.2.5 --case-dir ../assessment-case
python scripts/cnas_audit.py case-record --case-dir ../assessment-case --input ../finding-input.json
python scripts/cnas_audit.py case-validate --case-dir ../assessment-case
```

初始化要求空目录，可选 `--case-id`（1–80 位 ASCII 字母、数字、连字符或下划线），默认随机生成。`case.json` 保存 `schema_version/case_id/title/assessment_date/corpus_version`、创建 / 更新时间、`records/snapshots/history/integrity_sha256`。`corpus_version` 在首次固定文件时记录，每份快照继续保留自身版本。

首次使用依据时，将其原样保存为 `snapshots/<doc_id>.json` 并固定索引条目与 SHA-256。封装文档同时复制已核验的内容寻址共享图像包至 `snapshots/_assets/<hash>.json`；不同资产内容使用不同文件名，不覆盖旧版本。后续查询优先使用该快照，安装语料更新不会改变历史记录；删除当前索引后，已固定依据仍可独立查询、校验和出报告。每次读快照均核对资产文件 SHA-256，同次操作可以复用已核验的解压结果，文件哈希仍逐次检查。增加新依据时才需要安装语料。复制案例应携带整个目录（包括 `_assets`），不混入其他案例的数据。

案例操作使用排他锁 `.case.lock`、同目录临时文件及 `os.replace` 原子替换，冲突直接失败。意外退出遗留锁时，应先确认没有其他进程使用，再由操作者清理。SHA-256 和历史链识别意外改动，不是数字签名。创建事件保存不可变的完整初始记录，修改和流转事件保存前后状态快照，支持恢复被修订的事实、证据及原文依据；现行记录须与最新历史快照一致。记录创建失败不会提交 `case.json`，可能遗留未被引用的快照，后续有效操作按索引重新固定。不得把运行案例或报告写进技能目录。

## 输入记录

```json
{
  "kind": "finding",
  "title": "发现摘要",
  "finding_type": "nc",
  "severity": "unassigned",
  "status": "pending_confirmation",
  "facts": "现场事实与具体范围",
  "evidence": [{"description": "证据的具体定位", "url": "evidence/record-01.pdf"}],
  "basis": [{"document": "CNAS-CL01", "version": "2018", "clause": "6.2.5"}],
  "assignee": "待指定",
  "site": "现场位置",
  "scope_refs": [],
  "notes": "待核事项"
}
```

`kind` 默认为 `finding`，另支持 `scope/checklist/evidence/experiment/interview/verification/task/report_note`。`finding_type` 为 `nc/observation/pending`，`severity` 为 `general/serious/unassigned`，均由评审员填写，不自动推断。`assignee/site/scope_refs` 为可选关联信息，不自动读取其他案例。

证据为非空描述字符串或含非空字符串 `description` 的对象，可带字符串 `url`；所有状态均校验形状。待确认草稿可以空证据列表；正式发现必须有事实、非空证据、确切且固定的依据和 `reviewer_confirmation:{"confirmed":true,"reviewer":"实际确认人"}`。`pending` 类型发现不能直接确认。依据生效日晚于评审日时不能确认；未来版本无评审日也不能确认。其他适用性仍需评审员判断。非 `finding` 记录确认要求事实和评审员确认，允许无证据或规范依据，例如范围分工；进入已验证或关闭状态仍要求验证材料。

每条依据必须有 `document/version`、可选 `revision`，以及 `clause/unit/clause_id` 之一。输入不接受自造规范原文；脚本从快照生成 `original_citation`，校验时重新构造比对。自动记录 ID 形如 `<case_id>:F0001`，不接受另一案例的记录 ID。

## 状态流转

```text
python scripts/cnas_audit.py case-transition --case-dir ../assessment-case --record-id CASE_ID:F0001 --to confirmed --input ../confirmation.json
python scripts/cnas_audit.py case-transition --case-dir ../assessment-case --record-id CASE_ID:F0001 --to rectifying
python scripts/cnas_audit.py case-transition --case-dir ../assessment-case --record-id CASE_ID:F0001 --to pending_verification
python scripts/cnas_audit.py case-transition --case-dir ../assessment-case --record-id CASE_ID:F0001 --to verified --input ../verification.json
python scripts/cnas_audit.py case-transition --case-dir ../assessment-case --record-id CASE_ID:F0001 --to closed
```

常规流转为 `pending_confirmation → confirmed → rectifying → pending_verification → verified → closed`，`confirmed` 也可直接进入 `pending_verification`。确认输入为 `{"reviewer_confirmation":{"confirmed":true,"reviewer":"实际确认人"}}`。

验证通过使用 `{"verification":{"result":"accepted","reviewer":"实际验证人","evidence":["具体验证证据"]}}`，从待验证进入已验证。验证不通过时同样填写评审员、证据，`result` 改为 `rejected`，转回 `rectifying`。`verified` 也可回到 `rectifying`，旧验证不继续作为关闭依据。

关闭后重开须用 `--action reopen --to rectifying --reason "具体原因"`。撤回确认须用 `--action withdraw --to pending_confirmation --reason "具体原因"`；现行确认 / 验证会清除，历史保留。事实、证据、依据、发现类型与程度仅可在待确认时修改，可在下一次确认的输入中同时提交修订字段；已确认的记录应先撤回。每次流转保存时间、前后状态、原因和提交内容。

## 报告

```text
python scripts/cnas_audit.py report --case-dir ../assessment-case --format html --output ../assessment-report.html
python scripts/cnas_audit.py report --case-dir ../assessment-case --format json --output ../assessment-report.json
```

两种格式调用同一统计函数，包含总记录、分状态 / 种类计数，以及仅针对 `finding` 的类型 / 程度计数。HTML 的完整案例统计不随筛选改变，另显示可见行数。报告标为辅助草稿，逐条展示实际确认信息；关闭率不能自动形成合规、推荐或认可结论。

HTML 无外部依赖，支持离线目录跳转、搜索、状态筛选和打印。顶部记录目录对应从记录 ID 确定性生成的稳定锚点；选择目标会先清除搜索和状态筛选，显示全部记录，再定位并聚焦该行，避免跳转到被隐藏内容。打印隐藏目录和筛选控件，允许长记录跨页，并为原文依据分配较宽列，避免整行移到下一页形成空白。状态、种类、发现类型和程度同时显示中文标签与内部码；记录种类、负责人、场所、范围关联和备注 / 待核事项完整呈现，用户文本及属性均转义。同一记录内相同文档、相同角色及块引用的引言 / 条件 / 注仅组装显示一次；同一条依据中核验状态和说明相同的单元合并展示一次并列出所有单元 ID，状态或说明不同的组分别保留；JSON 原文和引用不变。

只保留 HTTP(S) 与不向上越界的相对证据链接；百分号编码解码后同样检查，拒绝编码或明文的危险协议、越界路径、反斜线、控制字符、UNC、根路径等。相对证据 URL 以案例根目录为基准，导出时在确认目标仍位于案例内后，转换为相对 HTML 所在目录的链接，并编码中文或空格；跨盘符无法产生安全相对链接时仅显示证据文字。报告不能覆盖案例文件、快照或锁文件；可访问链接不等于证据真实或已核验。

`case-validate` 检查案例摘要、历史链、快照、状态要求及原文引文。开发校验命令为 `python -X utf8 -m unittest discover -s tests -v`；测试用临时合成语料和案例，覆盖版本歧义、重复条款、跨页与上下文、未来依据、快照保护、状态流转、篡改、注入、原子写入、锁、中文路径及目标包，不将测试数据带入 ZIP。

## 平台适配打包

```text
python scripts/package_skill.py --target standard --output ../cnas-onsite-assessment-standard.zip
python scripts/package_skill.py --target skillhub --output ../cnas-onsite-assessment-skillhub.zip
python scripts/package_skill.py --target workbuddy --author "实际作者" --output ../cnas-onsite-assessment-workbuddy.zip
```

唯一元数据源为 `references/package_metadata.json`。各目标保留同一 Markdown 正文和完整 JSON 语料；仅生成不同 frontmatter，并对有体积约束的平台采用无损传输封装。标准包保留 `name/description/license/metadata`，兼容性写在 `metadata.compatibility`；SkillHub 增加 `slug/version/displayName/summary`，可选 `--slug`；WorkBuddy 增加 `display_name/display_name_en/description_zh/description_en/version/author`。缺少 `--author` 即失败，不推断身份。

ZIP 根部直接放 `SKILL.md`，包含第三方权利说明 `THIRD_PARTY_NOTICES.txt`，并检查 SKILL.md 的全部相对 Markdown 引用均存在于包内。主包排除源 PDF / Word / Excel、测试、运行案例、缓存、隐藏路径和构建输出，生成包含文件哈希的 `package-manifest.json`。源文件存档独立提供。可用 `--source` 指定隔离测试技能根目录。打包前检查完整语料结构；出包不表示平台接收或发布。实际作者未确定时，仅交付标准与 SkillHub 包，WorkBuddy 适配器只在临时目录使用明确的合成作者验证。

传输契约见 [cnas-storage.schema.json](cnas-storage.schema.json)。SkillHub / WorkBuddy 每个文档仍为独立 JSON，`storage_format=cnas-json-lzma-base85-v1`；完整对象按本脚本 `canonical()` 紧凑编码后无损压缩，图对象中的指定长字符串按内容哈希共享。资产映射使用 `cnas-assets-lzma-base85-v1` 封装，路径只允许文档同级 `_assets/<64位小写SHA256>.json`。标准包和工作源 JSON 不受该打包变换影响。

目标索引的 `sha256` 钉住物理封装文件，`content_sha256` 钉住还原后完整对象，`source_json_sha256` 保留原始完整 JSON 文件哈希。读取依次检查封装 / 资产路径、文件哈希、严格 Base85、LZMA 单流与长度、图像字符串哈希、完整对象哈希及外层 / 内层元数据一致，再执行语料结构校验；不执行数据内容。每个封装最大声明输出 64 MiB，LZMA 解码内存上限 128 MiB，拒绝截断、超长、尾随和拼接流。

SkillHub / WorkBuddy 打包同时测量 ZIP 与完整解压文件总字节数，均须小于 10,000,000；默认 LZMA preset 6，若完整内容超过预算可加 `--compression-preset 9` 无损加强压缩，不删条款、表格、图像或溯源信息。平台实际兼容仍需其离线预检，不因 ZIP 生成成功而推断通过。
