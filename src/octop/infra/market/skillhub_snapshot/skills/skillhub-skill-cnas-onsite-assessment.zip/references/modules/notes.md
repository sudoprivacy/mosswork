# 评审前后能力表附加说明模块

本模块继承 `cnas-onsite-review-notes` 的只读 XLSX/XLSM 读取器和层级差异分析，并在统一运行器内完成证据核验及三段 TXT 输出。Python 3.8 标准库即可运行，源技能路径不是运行依赖。输出不代表确认、分级或关闭不符合项。

## 接口

`module: notes` 支持两个动作：

- `compare`：`inputs.before`、`inputs.after` 为两份现有 `.xlsx/.xlsm` 文件；`reviewer` 必填。`options.sheet` 可选，默认“检测能力范围”；找不到时按两行表头唯一识别。生成 `能力表前后差异分析.json`，包括源 SHA256、分析指纹、逐条 `change_id`、完整记录、前后行号证据、参数上下文、候选和诊断。此步骤返回 `needs_review`，无匹配评审员返回 `blocked`，不生成 TXT。
- `render`：仍指定同一 `before/after/reviewer`，另用 `inputs.decisions` 指定 UTF-8 JSON 文件，或在 `options.decisions` 内嵌决定。重新比较源表并核对指纹和源 hash，语义决定完整有效时生成上述详细 JSON 和 `CNAS现场评审附加说明.txt`；原因或确认不足返回 `needs_review`，只保留诊断 JSON。

`options.reason` 是用户给定的不推荐原因原文，`options.restriction_reason` 是已确认的限制原因；不同参数可分别通过 `options.reasons`、`options.restriction_reasons` 的参数 ID→原文映射提供。同组原因不同须拆组，未提供原因不得出具 TXT。原因不得由 Agent 猜测。

## Agent 语义审查及决定格式

Agent 必须完整读取分析 JSON，核对新增、删除、拆分、合并、名称、序号、中英文、标准依据、条款、说明、备注、领域代码及推荐人变化。将同一业务动作归并为一句自然语言，明确前后值；不同方法涉及同一参数的不推荐只写一组。标准删除、参数删除或内部 ID 改变本身均不表示不推荐。说明/条款/备注变化只是限制候选，规范名称和拼写不能自动算限制。

示例（所有占位指纹、ID 和变更编号必须来自实际 `compare` 输出）：

```json
{
  "analysis_fingerprint": "来自分析JSON",
  "source_sha256": {"before":"来自分析JSON", "after":"来自分析JSON"},
  "groups": [
    {"category":"nonrecommended", "change_ids":["C00001","C00002"], "parameter_ids":["参数内部ID"],
     "confirmed":true, "basis":"status_transition", "text":"两项方法的推荐状态均由是改为否"},
    {"category":"restriction", "change_ids":["C00003"], "parameter_ids":["另一参数ID"],
     "confirmed":true, "scope_narrowed":true, "text":"限制不做第三法"},
    {"category":"other", "change_ids":["C00004","C00005"], "parameter_ids":["第三参数ID"],
     "confirmed":true, "text":"将参数名称由“旧名称”改为“新名称”，并同步修改英文名称"}
  ]
}
```

每一条源 `changes` 必须且只能被一组 `change_ids` 引用；未知、漏项、重复、错指纹均拒绝处理。参数 ID 必须属于该组证据中的评审员责任记录。`confirmed:true` 表示该组经过语义审查，不能以粗糙模板直接填充。`other.text` 为可粘贴的实际业务修改描述，程序添加完整检测对象、参数序号及中文编号，不向 TXT 暴露内部 ID。不推荐正文由参数与用户给定原因生成；限制正文使用组内 `text` 及已确认原因。

不推荐的 `basis:status_transition` 仅适用于源表已存在肯定→否定证据；其它情况必须有用户明确证据并写 `basis:user_confirmed`，不能凭删除、换 ID 或新增否定状态作决定。`restriction` 必须有 `scope_narrowed:true`。同一参数不能重复按多种方法计数，也不能同时计入不推荐和限制。

纯样式差异从不进入 changes。纯 ID 重建可归并为 `category:identifier_only`（`no_business_change` 为同义审计分类），但前后业务记录多重集必须完全一致，且不能掩盖字段修改、单纯删除或新增；JSON 留下解释，TXT 不输出。无任何变化且匹配到评审员时，`groups:[]` 可生成真实的零变更三段 TXT。说明、空格或标点等实际系统内容修正须归入“其它”概括说明。

## 证据及出具条件

评审范围为前后“推荐人”命中记录的并集，保留推荐人被修改前的责任证据。层级字段补齐，对象须有大类序号及对象序号，参数须有参数序号。缺少完整序号、未知列、缺失 ID、重复标准 ID 或冲突值时只生成诊断，不给出可粘贴 TXT。前后均无匹配时禁止生成误导的“0项”报告。

所有产物只写入运行器提供的独立 `output_dir`；原表只读，源 hash 在读取前后核验。产物经 UTF-8 实际重读核验。详细 JSON 始终保留，TXT 固定为“不推荐参数、限制参数、其它”三部分。`completed` 仅表示材料生成完成，不提升任何评审结论状态。

## 验证

`python -S -m unittest discover -s tests -p test_notes_module.py -v` 使用标准库生成合成 XLSX/XLSM，检验多方法唯一参数计数、删除/换 ID、防止名称规范化误判限制、推荐人责任并集、其它字段归并、完整编号、缺原因、不匹配评审员、覆盖缺项、过期源指纹、源 hash 不变、样式忽略及真实 TXT 重读。
