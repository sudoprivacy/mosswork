# 单项与组合任务接口

`scripts/cnas_workflow.py` 是统一入口。原有 catalog、lookup、related、corpus-validate、case-init、case-record、case-transition、case-validate、report 参数保持原样；详见 [运行接口](../runtime.md)。以下命令只依赖 Python 3.8 标准库，选定业务动作时才加载可选包。

```text
python scripts/cnas_workflow.py list
python scripts/cnas_workflow.py list --module pt --action summary
python scripts/cnas_workflow.py case-init --case-dir <项目目录> --title <名称> --assessment-date 2026-11-11
python scripts/cnas_workflow.py run --case-dir <项目目录> --request <请求.json>
python scripts/cnas_workflow.py validate --case-dir <项目目录>
python scripts/cnas_workflow.py report --case-dir <项目目录> --format html --output <报告.html>
python scripts/cnas_workflow.py report --case-dir <项目目录> --format json --output <报告.json>
```

请求中的相对输入路径以请求文件所在目录为基准。所有项目必须在共享技能目录之外；运行结果位于案例 artifacts 下的独立 `文审输出` 目录。实际模块接口与字段分别见 [能力](capability.md)、[标准](standards.md)、[能力验证](pt.md)、[附加说明](notes.md)。

```json
{
  "module": "pt", "action": "summary", "reviewer": "评审员姓名",
  "inputs": {"primary": "能力验证_已审核.xlsx"},
  "options": {"as_of": "2026-11-11", "review_year": 2026},
  "basis": [{"document": "CNAS-RL02", "version": "2023", "revision": "supplied"}],
  "upstream_runs": [],
  "authorization": {"rename_sources": false, "allow_partial_coverage": false}
}
```

示例版本仅说明参数形式。先 catalog 查实际修订标识并结合评审日期选择；首次引用必须明确版本，后续可沿用本案例锁定依据。不得按年份自动升级。basis 回调返回完整 JSON 及 doc_id、版本、修订、实施日期、原文件哈希和案例 JSON 哈希。原始资料的现行有效性仍需评审员确认。

输入先以 SHA256 复制到案例 inputs，源文件和快照均在执行后复检。文件夹保留内部相对路径；原始绝对路径不成为案例状态依赖。后续请求可引用已有阶段产物：

```json
{"run":"案例ID:M阶段ID","role":"reviewed_workbook"}
```

将该对象用作某个 inputs 字段的值即可；role 必须唯一。也可用 `{"run":"阶段ID","input":"folder"}` 引用上游输入快照。原件已移走时不必重新寻找同内容文件。标准库存/缓存中旧路径只是提取时位置；迁移后消费库存时显式传入对应 folder（能力审核用 standards_folder）、必要时 cache_folder，按相对文件名及 SHA256 重新定位。重命名动作例外：folder 必须显式选择案例外的真实目录，不能重命名案例快照；重命名前后文件内容哈希集合必须相同。

准备映射、语义审查或能力差异决定时，从阶段产物复制一份到项目工作区编辑，再作为新输入，禁止改写已登记产物或输入快照。来源、评审员、源行、JSON Pointer、依据和未决项随每个阶段保留。技术异常保存 failed 阶段及诊断；缺依赖为 blocked；业务待核为 needs_review。以上状态独立于评审发现状态，不能自动确认、定级、通过验证或关闭。

`pipeline --case-dir ... --request ...` 接收 `{"steps":[{"id":"本批别名","request":{...}}]}`；后一步可用 `{run:本批别名,role:产物角色}`，字符串键需遵循 JSON 引号语法。步骤逐一提交，遇 failed、blocked 或 needs_review 停在已完成位置，保留结果。评审员/Agent完成语义审查后用新请求续接，不在缺证据时自动跨越。已有明确输入和授权可直接连续执行，无额外固定确认。

HTML 显示任务阶段、待核项、依据哈希及产物链接；其统计与 JSON 来自同一案例。搬移时复制整个案例目录（case.json、inputs、artifacts、snapshots），再从新目录验证/生成报告。单独报告 JSON 是状态导出，不包含二进制业务文件；续接必须保留整套目录。核心报告命令禁止覆盖快照、输入和阶段产物。

OCR 使用宿主已有工具导入结果或显式通用配置。凭证应由宿主/环境变量提供，不写入请求、输入配置或案例。程序不会读取特定 Agent 配置、默认选择服务或自动上传。各动作的语义分析范围、原文核对和人工判断责任仍按模块指南执行。
