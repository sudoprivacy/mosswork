# 公共标准原文提取模块（1.1.0）

此模块合并两项旧技能的五个不同实现，只保存公共实现，不复制规范正文。
程序负责物理文件盘点、原生文本、页段缓存、记录硬校验和Excel；Agent/评审员
负责逐份核对原文并提交 `records.json`。文件名、关键词和方法名数量都不能代替语义审核。
模块不创建、确认、分级或关闭不符合项。

## 统一入口与动作

以主技能 `scripts/cnas_workflow.py run --case-dir <目录> --request <请求JSON>` 调用。
请求 `module` 为 `standards`。所有派生成果在本次 `context.output_dir`（以“文审输出”结尾）；
原始文件仅在满足重命名授权及预览门槛时允许改名，字节内容不变。

| action | 必需inputs | options及说明 |
|---|---|---|
| `inventory` | `folder` | 每个物理文件独立登记，修改单、勘误、补充文件不得合并 |
| `split` | `primary`（PDF） | `chunk_size` 1–50，默认10，建议10–20；按源SHA256隔离缓存 |
| `ocr_import` | `inventory`, `ocr_results` | `ocr_preference` 默认PaddleOCR；`allow_other_ocr` 默认false |
| `ocr_client` | `inventory`, `ocr_config` | 同上；`chunk_size`、`retries`默认2且最多5、`timeout`默认45秒且最多60 |
| `build` | `inventory`, `records` | 总是输出诊断Excel和coverage.json；不足覆盖时 `blocked`，显式 `authorization.allow_partial_coverage=true` 时为 `needs_review`，覆盖门槛仍不通过 |
| `rename_preview` | `folder`, `inventory`, `records` | `pdf_only` 默认true；设置false可处理其他文件 |
| `rename_apply` | `folder`, `inventory`, `records`, `plan` | `options.plan_sha256` 必须等于预览值，且 `authorization.rename_sources=true` |

消费inventory的动作可额外传 `inputs.folder`，显式重新选择源文件目录；以相对路径和
SHA256确认文件身份，旧盘符不构成身份依据。未提供时使用清单中的 `source_root`。
迁移后应重新选择folder。OCR续跑可额外传 `inputs.cache_folder`，在明确选择的缓存树内
按原缓存文件名和SHA256重定位；找不到则报错，不读旧机器配置或改造假缓存。
同名字节完全相同的缓存副本可复用。`build`只核对原始物理文件hash，不要求重开旧文本缓存路径。

Python最低3.8。导入adapter及列出动作只需标准库；inventory/split/ocr_client的PDF
处理使用PyMuPDF（`fitz`）；build使用openpyxl；只有显式选择stdio客户端时才导入可选 `mcp`。
模块不自动安装依赖、不自动联网。使用TXT/DOCX时原生读取不导入PDF库。

## 原生文本与物理覆盖

清单保存 `source_root`、`file_count`、`files`。每项包含 `relative_path`、`sha256`、大小、
扩展名、PDF页数、原生及实际字符数、实际 `extraction_mode`、`status`、`needs_ocr`、
逐页字符数及 `pending_pages`。TXT区分UTF8/GB18030；DOCX直接读取XML；旧DOC为
`conversion_required`，不得据文件名补内容。暂不自动控制Word转换旧DOC，需另行提供实际转换结果。
不支持文件、临时文件、空文件亦保留盘点，不能静默减少物理分母。

PDF逐页原生文本少于50字符即保留待OCR，混合扫描PDF不会因其他页文字多而漏检。
这是保守技术门槛，不是标准内容判断；有意空白页也可能需要人工处理。
加密、损坏、空文本、缺文件、hash改变、待OCR任一存在，不能声明物理文本覆盖通过。

分段保留页号、源hash、段hash和manifest；只有hash匹配才能复用。PyMuPDF回收共享
图片资源，避免每个小段接近整本体积。OCR成功段保留文本hash与调用证据；失败段可续跑。
不同分段策略产生重叠时明确报错，应从原生inventory以统一分段重试，不静默拼接重复页。

## 宿主OCR导入与显式客户端

优先检查当前宿主工具清单并按用户要求调用实际PaddleOCR。模块本身不假设宿主工具名。
宿主实际调用完成后，提交 `ocr_results`：

```json
{"results":[{
  "source_file":"sample.pdf", "source_sha256":"实际64位SHA256",
  "start_page":1, "end_page":10, "status":"ok", "complete":true,
  "engine":"实际PaddleOCR引擎名称", "tool":"本次实际工具名称",
  "evidence_ref":"实际工具调用/结果的可追溯标识",
  "text":"本次实际返回的原文文本"
}]}
```

可用 `text_file`（现有UTF8文件）代替text；不得伪造 `evidence_ref`、完成标记或OCR引擎。
`complete=true` 是宿主/Agent核对该完整页段的明确声明；错误、缺此声明、空响应及不完整段
均记录失败并保留待OCR。每个源hash、页段边界须正确，无重叠；原生可靠页与成功OCR段共同
覆盖全页后才清除待OCR。关键数字、单位、标准号、条款应对照页面再次核对。
没有工具或调用失败只报告待处理；默认禁止用其他引擎替代PaddleOCR。
只有显式 `allow_other_ocr=true` 时允许其他引擎，且实际方法照实记录。

`ocr_client`仅接受显式JSON连接配置，不读取Codex配置、不内置服务/工具名，不输出或保存密钥。
HTTP JSON例（只表示协议结构，不是真实服务）：

```json
{
  "transport":"http_json", "engine":"PaddleOCR实际名称", "tool_name":"实际名称",
  "endpoint_env":"CNAS_OCR_ENDPOINT", "header_env":{"Authorization":"CNAS_OCR_AUTHORIZATION"},
  "input_argument":"file_path", "arguments":{},
  "response_text_key":"text", "response_success_key":"success", "response_complete_key":"complete"
}
```

HTTP提交 `{"tool":tool_name,"arguments":{...}}`，路径指向已生成PDF段。服务须能读取所选路径；
不默认上传字节。成功响应须含非空文本、布尔success和complete；可配置点分隔响应字段路径。
endpoint可显式给URL或通过环境变量指定；URL不得含凭据、查询串，配置不得内嵌token/password/api_key。
Authorization环境变量应包括服务要求的完整前缀。失败详情不持久化，以免泄露远端敏感响应。

显式stdio MCP配置使用 `transport:"stdio"`、`command`、`args`、`env_names`（仅环境变量名）、
实际 `tool_name`、`input_argument`、`arguments`、`engine`。客户端先列出工具确认存在再调用。
只有用户/集成方已核实该工具“成功即完整处理整个输入段”的协议时，才设置
`success_is_complete:true`；否则应通过宿主核查后导入结果，不会自动将未知完整性标成功。
stdio传输需要可选mcp包；实际PaddleOCR部署、网络和模型环境不包含在技能内。

## Agent核对records

根对象 `{"metadata":{},"records":[]}`。每条保留以下字符串字段；除notes可空，其他均必填。

| 字段 | 原文核对口径 |
|---|---|
| `standard_number`, `standard_name` | 原文编号/版本标识和题名，不凭文件名创造 |
| `category` | 产品标准、判定标准、检测标准，或“需人工确认（具体原因）” |
| `parameter` | 一行一个独立参数；运输/目录判定规则依原文模块，不虚构品名为实验参数 |
| `clause` | 精确到章、条、款、表、附录；不能核实时明确说明 |
| `references` | 只列明确引用；未见则“未见明确引用”；原文未给题名则注明，不凭记忆补全 |
| `multiple_methods` | 是/否；不同原理、独立程序、仲裁/替代法、不同样品完整程序须逐一核对 |
| `method_name` | 各独立方法分别列行或用分号/换行清楚分隔 |
| `equipment_or_standards` | 与每种方法对应的关键仪器、CRM、标准溶液、内标；未明确则“标准文本中未明确” |
| `source_file` | 与清单完全相符的相对路径；修改单、勘误各自对应物理来源 |
| `evidence` | 精确定位或短摘录，避免复制大段正文 |
| `notes` | OCR、适用范围、缺页、冲突或其他限制 |

仪器型号、读数形式、量程、试剂浓度、重复测量变化通常不是独立方法；资料性附录示例
不得自动作为规范性并列方法。来自引用标准的设备证据须明确说明来源，不反向补入主标准。
标“是”应有至少两个方法名；方法名内的 `/`（例如LC/MS）不能当作两种方法。
机械检查只给疑点；不能依关键词代替原文判断。

## Excel与能力模块接口

Excel包含“结构化提取”“文件清单与覆盖检查”“一参多法复核”“质量警告”“处理说明”。
保留每条records的JSON Pointer、原始源文件hash、精确条款及方法设备对应关系。
生成后从实际目标重新打开校验；原文以 `=` 开头也保持文本，不生成公式。
缺文件、扫描未OCR、无记录、占位异常等均在诊断中显式披露；空白/未覆盖不能装作成功。

公共API `modules.standards.build_standard_excel.validate_records(inventory, records, source_root=None)`
接受records数组或document。返回 `coverage_passed`、`coverage`、`missing_files`、
`changed_files`、`uncovered_files`、`pending_files`、`warnings`、`standard_numbers`、数量。
显式source_root可在迁移后覆盖旧绝对根目录；仍逐文件查hash。schema错误抛ValueError；
业务证据不足返回失败门槛，不据此生成能力不符合项。

## 重命名

每个物理文件须有记录，且每条相关记录另加 `identity_verified:true` 与原文evidence，
明确编号/题名已核实。规范名为 `标准编号《标准名称》`，保留扩展名/相对目录，年份连字符
统一半角，Windows非法字符替换全角，压缩空白。目标相同、编号/题名不唯一、目标已有、
越界、源文件新增/删除/hash改变一律拒绝；不加序号、不覆盖。

preview不改源；apply要求显式授权及相同plan_sha256，并重算计划和文件hash。执行异常尝试回滚。
输出新的inventory/records/map，不覆盖输入JSON，缓存证据路径保留并同步来源映射。
执行后以新名称重新查数量与内容hash。原字节不变；主流程应按rename_map处理预期的路径变化。

## 验证范围

测试均为独占合成文件：原生/扫描/混合状态、空/不支持/旧DOC、未OCR不能过门槛、缺源/hash改变、
多方法疑点、分段hash缓存、宿主导入失败后续跑、错误引擎偏好、真实本地HTTP重试、
Excel重开与源行/Pointer、重命名授权/冲突/hash/目录变化。合成OCR文本不是对真实PaddleOCR
服务器部署或识别准确性的验证。原技能为只读构建输入，差异及源hash保存在构建报告中。
