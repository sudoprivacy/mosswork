# 能力验证频次审核与情况说明

本模块融合逐行领域映射、项次复核、安全另存 Excel、评审员情况说明及 JSON 诊断。模块只产生分析和材料，不确认、分级或关闭不符合项。以运行时 `context.basis('CNAS-RL02', version, revision)` 返回的案例选定版本为依据；不另存一套规范库，不从安装者电脑路径读取资源，也不按版本年份自动选择较新文件。

## 统一动作

| action | 必需 inputs | 可选 inputs | 依赖 | 主要产物 |
|---|---|---|---|---|
| `prepare` | `primary`：源 `.xlsx/.xlsm` | 项目依据见后文 | openpyxl | `pt_mapping.json`、运行期依据模型 |
| `apply` | `primary`：相同源工作簿；`mapping`：逐行审核后的 JSON | 项目依据见后文 | openpyxl | 审核副本、`pt_apply_receipt.json` |
| `summary` | `primary`：已审核 Excel | `receipt`：组合流程 apply 回执；项目依据见后文 | 仅 Python 标准库 | `pt_summary_diagnostics.json`；支持出具时的单段 UTF-8 TXT |

`inputs` 的值全部是已有文件路径。`reviewer` 必填；通过 request 的 `basis` 选择唯一 CNAS-RL02 版本及修订；已选定的案例可由核心回调解析。各动作采用同一实际评审截止日。输出由统一入口分配在独立的 `文审输出` 目录，必须位于技能与输入目录树之外。原工作簿、既有输出均不覆盖。

通用 `options`：

- `basis_version`、`basis_revision`：可省略，若提供必须与 request.basis 一致。
- `as_of`：`YYYY-MM-DD`，默认 context.assessment_date；不得早于依据实施日。
- `sheet`：工作表名；有多张符合表头的表时必须指定。
- `project_basis_selected`：仅用于下述显式项目依据选择。

基础请求：

```json
{
  "module": "pt", "action": "prepare", "reviewer": "指定评审员",
  "inputs": {"primary": "<源工作簿绝对路径>"},
  "options": {"as_of": "2026-11-11"},
  "basis": [{"document": "CNAS-RL02", "version": "2023", "revision": "supplied"}]
}
```

使用主入口 `scripts/cnas_workflow.py run --case-dir <案例> --request <请求JSON>`。无需复制源技能或安装另一套依赖检查器；只在 prepare/apply 需要时使用 openpyxl。summary 始终使用内置标准库 XLSX 读取器，保留日期样式、1900/1904 日期系统、共享字符串及多工作表读取支持。

## prepare 与逐行判断

准备映射包含源文件完整 SHA256、工作表/表头/列位置、所有非空数据行、合法领域、原始对象/项目/标准、初步项次、评审员及准备指纹。`domains` 初始为空，`reviewed` 初始为 false，不按关键词自动定领域。

完整阅读所有行，按检测对象/基质、参数属性、活动上下文、方法适用范围、选定原文是否列明的顺序作出判断。仪器或检测技术相同不能说明所属领域相同。只允许使用运行期 `allowed_domains[].value` 的标签；标签由原文领域/子领域拼接，跨页合并的领域名连续继承，原单元格及表格/行/页/块来源保留在模型中。

每行填写：

```json
{
  "excel_row": 2,
  "domains": ["<allowed_domains 中的原始标签>"],
  "reviewed": true,
  "item_count_override": null,
  "domain_item_counts": {},
  "review_note": "核对对象、参数及方法适用范围的理由",
  "evidence_refs": [{"source_file": "<证据文件>", "location": "<页码或条款>"}]
}
```

只能修改 `domains`、`reviewed`、`item_count_override`、`domain_item_counts`、`review_note`、`evidence_refs`；源行、表头、初值、领域清单、评审员或依据变化均须重新 prepare。空领域表示当前依据无法可靠对应，不表示无需质量控制；空领域、多领域、人工项次覆盖都须填写判断理由。所有行都须明确 reviewed=true 后才另存 Excel。

容易误判的情形包括：水中微生物与水化学分析；化妆品微生物与化学分析；危险化学品分类与石油产品性能；一般聚合物、玩具和电子电气制品的有害物质；动植物病原体与物种/组织鉴定。食品污染物及皮革、鞋类、卫生用品等必须逐项查看选定依据，不套用相似行业；不因 ICP、GC-MS、PCR 等技术名称自动归类。

项次按独立项目/参数数目计算，不按领域数。保留源算法：顶层顿号、逗号、分号、换行或连续空白分隔；括号内分隔符、普通单空格、斜杠以及“和”不自动拆分。`铅、镉、汞、砷`为4；`甲（含乙、丙）；丁`为2。特殊并列/组合名称用正整数 `item_count_override` 并说明理由。

一行跨多个领域时 Excel 使用中文分号连接。summary 的分领域项次必须有明确分配：`domain_item_counts` 以领域标签为键、正整数为值、合计等于该行项次；否则保留参加次数诊断，但不得重复累计整行项次并出具 TXT。

## apply 与指纹门禁

apply 重新解析源 Excel、动态派生同一依据并核对准备指纹，拒绝行号重复/缺漏、输入替换、越表领域、非法项次、未审核行或目标单元格已有公式。领域和项次之外的源值/公式、所有工作表名称、行列数、合并、行高列宽及隐藏状态须在输出重开后保持；最后核对源 SHA256 未变。

输出本地暂存后复制并原子替换到唯一输出位置，写入和读回都核对 SHA256。回执保留源/输出哈希、basis_fingerprint、preparation_fingerprint、mapping_fingerprint、完整审核映射及执行行决策。指纹依赖内容而非旧绝对路径，可在案例迁移后按源字节继续。

同一案例中有 prepare/apply 历史时，后续动作必须匹配相应指纹；summary 读取 apply 的审核副本时须提供该回执。单独 summary 可接受用户给定的已审核 Excel 和明确选定依据，生成独立的来源/领域行指纹，不强制重跑 prepare/apply。

## summary 统计口径

summary 的可选 `options`：

- `review_year`：默认截止日期年份，若提供必须同年。
- `years`：默认3，正整数；起点为评审年度减 years 加1的1月1日，终点为实际截止日。
- `use_tag`：默认 `YYYY利用`。
- `domain_item_counts`：单独 summary 的多领域项次分配，例如 `{"2":{"<领域一>":1,"<领域二>":2}}`；组合流程不得与回执分配冲突。
- `applicable_domains`：可选的明确适用领域标签列表；提供时检查每个列明领域，否则只分析 Excel 已确认的统计领域。
- `full_scope`：可选布尔值。为 true 时须提供 applicable_domains 和 `scope_evidence`，后者可用证据引用数组；默认无此硬门槛。

将“操作人”按完整姓名匹配指定评审员且参加时间在窗口内的行纳入筛选。多名操作人可用逗号、中文逗号、分号、中文分号、顿号、斜杠或空白分隔；姓名必须完整相等，不能把“合成甲乙”纳入“合成甲”。此策略与 capability/notes 模块一致。prepare/apply 仍覆盖全工作簿逐行映射，不以操作人省略其他源行；评审员身份在映射和阶段指纹中严格绑定。已填领域且项次有效的行进入分领域参加统计；领域空白但当年利用、满意、项次有效的行仍计满意结果总利用项次。评审员无匹配、必需字段缺失或有效数据不足，不能输出零值成功报告。

次数优先按唯一 profiCheckId，缺失时按计划编号；续行有同一计划编号且能唯一关联 ID 时继承该 ID。同事件日期可从唯一已填日期继承；日期冲突或无法解析、两类事件标识均缺失时须复核。项次为有效正整数之和。未出结果纳入参加次数和项次，不能计满意利用；非满意或无法判定结果阻止未经支持的“其余均满意”措辞。默认利用总量仅统计本窗口、指定评审员、当年利用标记、满意结果且有效项次的记录。

最低频次沿用原程序数量筛查口径：最低次数乘 `ceil(统计自然年数/原文周期年数)`。这只是数量筛查，不能代替年度/滚动周期、原文例外和适用条件审核。TXT 限定实际已确认统计域，不声称全部申请范围已覆盖；原文完整条件及来源附在运行期模型中，保留给评审员核实。

当已确认领域未匹配依据、频次不可解析或数量不足、非满意/未判定结果、利用项次无效、缺少必要源材料时，`ready_to_issue=false`，仅保存诊断。不存在这些问题时输出单段 TXT，注明“按所供审核资料中的领域及项次统计（指定评审员：……）”，不把 Agent 填写的 reviewed 标记表述为评审员已实际人工确认；按实际未出结果表述，末句为当年满意利用总项次。诊断含 inputs、domain_statistics、frequency_checks、pending_rows、unsatisfactory_rows、other_result_rows、utilization、warnings、errors、ready_to_issue、全部阶段指纹及源行。

## 显式项目替代依据

不得凭文件名年份、目录里存在较新文件或模型推测来替换依据。只有用户明确选择的运行期数据可用：

1. `inputs.project_basis` 指向 JSON；`inputs.project_basis_source` 指向其实际原始依据文件；`options.project_basis_selected=true`。
2. JSON 必须含 code、version、effective_date、source_sha256、rows；源哈希须与实际文件 SHA256 一致，实施日期不得晚于评审截止日。
3. 每行含 domain、subdomain、frequency、evidence_refs；频次必须明确可解析。可以附 conditions 或适用范围说明；这些元数据保留在模型，禁止通过项目依据暗示已由 CNAS 官方发布。

```json
{
  "code": "<明确编号>", "version": "<明确版本>", "effective_date": "YYYY-MM-DD",
  "source_sha256": "<实际源文件的完整64位SHA256>",
  "rows": [{"domain": "<领域原文>", "subdomain": "<子领域原文>",
            "frequency": "<原文最低频次>", "evidence_refs": [{"page": 1, "row": 2}]}]
}
```

仍保留案例 pin 的 CNAS-RL02 来源及 fingerprint，项目依据数据本身和实际源文件均纳入本次统一模型。prepare、apply、summary 必须携带同一选定项目依据，不能各自挑选不同频次口径。

## 版本原文异常

现有 corpus 的 CNAS-RL02:2023 动态派生113条领域记录。原文表格中有 `1年/1次` 这一条目，模型原样保留，解析值为 null；若本次统计涉及该项，诊断要求核对原文并阻止自动数量结论，不擅自改写为 `1次/1年`。运行期模型保留其表格、行及块定位。
