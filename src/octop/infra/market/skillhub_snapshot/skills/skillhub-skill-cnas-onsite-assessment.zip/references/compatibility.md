# 兼容、分享与发布准备

本技能以 Agent Skills 目录结构交付，核心不依赖某家模型或工具名。使用具备本地文件读取能力的 Agent；基础查询、案例与报告仅用 Python 3.8+ 标准库。1.1.0 的能力合并/审核需要 openpyxl、python-docx；标准 PDF 盘点/分段需要 PyMuPDF（fitz），标准 Excel 需要 openpyxl；能力验证 prepare/apply 需要 openpyxl，summary 与前后差异只用标准库。依赖均按动作延迟加载，`cnas_workflow.py list` 检查当前可用性。缺少执行能力时不能声称已自动校验或持久化。

所有内部路径相对技能目录。JSON 资料随技能一起分发，运行不依赖原作者电脑、同步盘、外部共享数据库或 Office。新增文档的解析可以使用宿主工具；这是输入能力，不是查询内置资料的依赖。

通过 scripts/package_skill.py 从同一份源生成 standard、skillhub 或 workbuddy 包。ZIP 根目录包含 SKILL.md，规范 JSON、必需脚本及说明随包提供；不收录测试缓存、个人项目、真实评审记录、构建路径或原技能作者信息。

通用包中的资料为可读 JSON；两个平台目标包使用包内无损压缩封装和共享原图去重，降低 ZIP 及展开体积，正文、表格、条款关系与版本信息完整保留。仍使用同一 Python 查询接口，不下载外部数据库。该表示需要 Python 标准库中的 `lzma` 和 `base64`；不具备执行能力的宿主只能读取指导和目录元信息。恢复后的内容与主源逐对象比对，历史快照自带所需资产。

- standard：标准 name/description 等字段，适合遵循通用格式的 Agent。
- skillhub：添加 slug、version、displayName 等发布字段，包可用于发布前检查。默认 slug 可能被他人占用，可在打包时指定自己的唯一 slug。
- workbuddy：补充中英文展示信息和 author。用户选择在发布时填写署名，因此生成该发布包必须明确传入 --author，不继承其他作者身份。

元数据的唯一编辑来源为 references/package_metadata.json；各发布入口由打包脚本生成。技能版本与资料库版本独立记录。仅生成包不会登录平台或上传发布。

1.1.0 延续 corpus/schema 1.0.0，历史案例字段继续可读，新增可选 workflow 阶段记录。整体项目迁移方法见 [融合模块接口](modules/workflow.md)。平台包体积按 ZIP 和展开字节分别检查，必要时使用 `--compression-preset 9`；不得删减依据来满足体积限制。WorkBuddy 署名由发布者填写，例如 `python scripts/package_skill.py --target workbuddy --author <实际署名> --compression-preset 9 --output <项目外的目标.zip>`。

现有规范参考：
- [Agent Skills](https://agentskills.io/specification)
- [SkillHub 发布要求](https://skillhub.cn/ai/release.md)
- [WorkBuddy 技能格式](https://open.workbuddy.cn/docs/skill)

平台兼容结果分别记录格式校验、脚本运行和宿主实际试用。未运行的宿主不能标为实测通过；平台字段要求变更时仅更新对应适配，不分叉评审逻辑。

公开包仅含获授权的依据及原创内容。原文件溯源归档独立提供，版权按原件声明保留，MIT 不延伸到第三方标准。运行时产生的实验室资料和案例快照属于使用者项目，不应打入公开技能。
