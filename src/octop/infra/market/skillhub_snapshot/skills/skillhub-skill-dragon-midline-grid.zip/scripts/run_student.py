#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
龙头中线九宫格 — 云端版
========================================
零依赖：不读本地通达信、不连 pytdx、不装 playwright。
只读同一份市场公开数据快照，**只看位置**。

中线（20 个交易日 ≈ 4 周）视角：
    D1 趋势强度 × D2 加速度 划成 3×3 九宫格，
    每格标注该格历史的 T+20 胜率与平均涨幅，
    再按格子挑人 —— 主力格、弹性格、回避格。

定位：
    中线（20 个交易日 ≈ 4 周）视角，按位置分格，看这个位置能不能拿住 20 天

用法：
    python run_student.py [工作目录]
"""

import json
import os
import sys
import urllib.request
from datetime import datetime
from pathlib import Path

BASE = os.environ.get(
    "HOMEWORK_BASE",
    "https://focuskanpan-1319329855.cos.ap-shanghai.myqcloud.com",
).rstrip("/")
RELAY_URL = BASE + "/longlong_homework_relay.json"
BOARDS_URL = BASE + "/longlong_homework_boards.json"

# ── 九宫格历史胜率（2024-01-01 起全市场 340 万观测，跨牛熊，无前视）──────────────
# 值 = (T+20 胜率 %, T+20 平均涨幅 %, T+5 胜率 %)
GRID = {
    ("高", "低"): (43.7, 0.50, 40.9),
    ("高", "中"): (42.1, 0.33, 43.4),
    ("高", "高"): (40.6, -0.39, 42.8),
    ("中", "低"): (49.4, 1.31, 47.6),
    ("中", "中"): (51.0, 1.63, 49.0),
    ("中", "高"): (49.9, 1.95, 49.6),
    ("低", "低"): (48.3, 0.98, 47.2),
    ("低", "中"): (49.3, 1.06, 48.9),
    ("低", "高"): (50.3, 2.20, 48.9),
}
BASE_WIN20 = 49.3      # 全市场 T+20 基线
BASE_MEAN20 = 1.40     # 全市场 T+20 平均涨幅
BASE_WIN5 = 48.0       # 全市场 T+5 基线

# 格子角色
ROLE = {
    ("中", "中"): ("main", "中线主力", "趋势温和向上、加速也温和 —— 走得慢，但走得远"),
    ("低", "高"): ("flex", "中线弹性", "位置还没起来就刚加速 —— 赔率最高，也最需要止损"),
    ("中", "高"): ("watch", "短线最优", "五个交易日最猛的一格，中线也不差，但已开始加速"),
    ("高", "高"): ("avoid", "中线回避", "涨得最猛又刚加速 —— 越拿越亏，全表唯一负收益"),
    ("高", "中"): ("avoid", "中线回避", "趋势已经透支，加速还在放缓"),
    ("高", "低"): ("avoid", "中线回避", "涨完开始减速 —— 短线也最差，中线更没戏"),
}


def fetch_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_boards():
    """股票 -> 所属概念板块（按板块涨幅降序，取前 2 个）。失败返回空 dict，不阻断报告。"""
    try:
        data = fetch_json(BOARDS_URL)
    except Exception:
        return {}
    tmp = {}
    for b in data.get("boards", []):
        nm = b.get("name") or ""
        chg = b.get("chg") or 0
        for s in b.get("stocks", []):
            code = str(s.get("code") or "")
            if code:
                tmp.setdefault(code, []).append((chg, nm))
    return {k: [nm for _, nm in sorted(v, reverse=True)[:2]] for k, v in tmp.items()}


def d1_band(v):
    return "低" if v < 15 else ("中" if v <= 25 else "高")


def d2_band(v):
    return "低" if v < 12 else ("中" if v <= 22 else "高")


def pct(v, digits=2):
    """涨红跌绿"""
    c = "#ff4444" if (v or 0) >= 0 else "#44cc44"
    return '<span style="color:%s">%+.2f%%</span>' % (c, v or 0)


def stock_rows(items, boards_map, start=0):
    out = []
    for i, r in enumerate(items, start + 1):
        code = r["code"]
        mkt = "SH" if str(r.get("market")) == "1" else "SZ"
        sec = "、".join(boards_map.get(code, [])) or "—"
        out.append(
            '<tr>'
            '<td class="col-rank"><span class="rk">%d</span></td>'
            '<td class="col-code"><span class="code">%s.%s</span></td>'
            '<td class="col-name"><span class="name">%s</span></td>'
            '<td class="col-sec">%s</td>'
            '<td class="col-price">%.2f</td>'
            '<td class="col-bar"><b style="color:#ff7b72">%.1f</b></td>'
            '<td class="col-bar"><b style="color:#ffa657">%.1f</b></td>'
            '<td class="col-ret">%s</td>'
            '<td class="col-ret">%s</td>'
            '<td class="col-ret">%s</td>'
            '<td class="score-cell"><span class="score-badge">%.1f</span></td>'
            '</tr>'
            % (
                i, code, mkt, r["name"], sec, r["close"],
                r["d1"], r["d2"],
                pct(r.get("g5")), pct(r.get("g10")),
                '%.2f' % (r.get("vol_ratio") or 0),
                r["total"],
            )
        )
    return "".join(out)


def group_block(items, boards_map, title, sub, color, empty_msg):
    body = stock_rows(items, boards_map) if items else (
        '<tr><td colspan="11" style="padding:18px;color:#8b949e">%s</td></tr>' % empty_msg
    )
    return """<div class="grp" style="border-color:%(c)s">
<div class="grp-title" style="color:%(c)s">%(t)s<span class="grp-sub">%(s)s</span></div>
<div class="table-container" style="border:none;background:transparent">
<table>
<thead><tr>
  <th class="col-rank">#</th><th class="col-code">代码</th><th class="col-name">名称</th>
  <th class="col-sec">所属概念</th><th class="col-price">收盘</th>
  <th class="col-bar">D1 趋势</th><th class="col-bar">D2 加速</th>
  <th class="col-ret">5日%%</th><th class="col-ret">10日%%</th><th class="col-ret">量比</th>
  <th class="score-cell">总分</th>
</tr></thead>
<tbody>%(b)s</tbody>
</table>
</div></div>""" % {"c": color, "t": title, "s": sub, "b": body}


def build_html(payload, gen_time, boards_map):
    boards_map = boards_map or {}
    rankings = payload.get("rankings", [])
    total_n = len(rankings)
    date_label = payload.get("date", gen_time[:10])

    # 分格
    cells = {}
    for r in rankings:
        cells.setdefault((d1_band(r["d1"]), d2_band(r["d2"])), []).append(r)
    for v in cells.values():
        v.sort(key=lambda x: -x["total"])

    def members(key):
        return cells.get(key, [])

    main_cell = members(("中", "中"))
    flex_cell = members(("低", "高"))
    watch_cell = members(("中", "高"))
    avoid_cell = members(("高", "高")) + members(("高", "中")) + members(("高", "低"))

    # 九宫格主表
    def cell_cls(key):
        role = ROLE.get(key, ("", "", ""))[0]
        return {"main": "g-main", "flex": "g-flex", "watch": "g-watch", "avoid": "g-avoid"}.get(role, "")

    grid = ['<div class="grid-wrap">',
            '<div class="grid-title">中线九宫格 · D1 趋势强度 × D2 加速度'
            '<span class="grid-sub">格子内：今日只数 ／ 该格历史 T+20 胜率（▲＝高于全市场基线 '
            '%.1f%%）／ T+20 平均涨幅 ／ 短线 T+5 胜率对照</span></div>' % BASE_WIN20,
            '<table class="grid"><tr><th class="g-corner"></th><th>D2 低<br><small>&lt;12</small></th>'
            '<th>D2 中<br><small>12~22</small></th><th>D2 高<br><small>&gt;22</small></th></tr>']
    for b1 in ("高", "中", "低"):
        tip = {"高": "已透支", "中": "正当时", "低": "未启动"}[b1]
        grid.append('<tr><th class="g-row">D1 %s<br><small>%s</small></th>' % (b1, tip))
        for b2 in ("低", "中", "高"):
            k = (b1, b2)
            w20, m20, w5 = GRID[k]
            n = len(cells.get(k, []))
            role = ROLE.get(k, ("", "", ""))[0]
            tag = {"main": "主力", "flex": "弹性", "watch": "短线最优", "avoid": "回避"}.get(role, "")
            grid.append(
                '<td class="%s">'
                '<i class="tag">%s</i>'
                '<b>%d</b><em>只</em>'
                '<span class="w20">%s%.1f%%</span>'
                '<span class="m20">均值 %s%.2f%%</span>'
                '<span class="w5">短线T+5 %.1f%%</span>'
                '</td>' % (cell_cls(k), tag, n, "▲ " if w20 >= BASE_WIN20 else "", w20, "+" if m20 >= 0 else "", m20, w5)
            )
        grid.append('</tr>')
    grid.append('</table></div>')
    grid_html = "".join(grid)

    # 顶部提示：今日落在 D1 高整行的情况（只看位置，不评总分、不点名）
    avoid_cnt = sum(1 for r in rankings if d1_band(r["d1"]) == "高")
    hi_hi_cnt = sum(1 for r in rankings if d1_band(r["d1"]) == "高" and d2_band(r["d2"]) == "高")
    top_tip = ""
    if avoid_cnt:
        suffix = ("；其中 D1 高 + D2 高 %d 只，是全表唯一负收益格" % hi_hi_cnt) if hi_hi_cnt else ""
        top_tip = (
            '<div class="top-tip">今日有 <b>%d</b> 只落在 <b>D1 高 · 已透支</b>这一整行，'
            '该行中线 T+20 历史胜率 <b>40.6%%~43.7%%</b>、平均涨幅 <b>-0.39%%</b>'
            + suffix +
            '。九宫格的第一件事不是多挑几只，而是先把这一整行<b>挡在三档名单外面</b>。</div>'
        ) % avoid_cnt

    blocks = []
    blocks.append(group_block(
        main_cell, boards_map,
        "① 中线主力席 · D1 中 + D2 中",
        "T+20 胜率 51.0%%（基线 %.1f%%，超额 +1.7pt）· 今日 %d 只 · 建议持有 20 个交易日" % (BASE_WIN20, len(main_cell)),
        "#ff7b72", "今日没有落在这一格的股票"))
    blocks.append(group_block(
        flex_cell, boards_map,
        "② 中线弹性席 · D1 低 + D2 高",
        "T+20 平均涨幅 +2.20%%（全表最高）· 胜率 50.3%% · 今日 %d 只 · 位置低、刚加速，赔率高但务必带止损" % len(flex_cell),
        "#ffa657", "今日没有落在这一格的股票"))
    if watch_cell:
        blocks.append(group_block(
            watch_cell, boards_map,
            "③ 短线最优格 · D1 中 + D2 高",
            "T+5 胜率 49.6%%（全表最高）· T+20 也有 49.9%% · 今日 %d 只 · 想短打看这格，想拿四周看上面两格" % len(watch_cell),
            "#d2a8ff", ""))
    if avoid_cell:
        blocks.append(group_block(
            avoid_cell, boards_map,
            "④ 中线回避 · D1 高 整行",
            "T+20 胜率 40.6%%~43.7%%，全部低于基线，且全表唯一的负收益格就在这里 · 今日 %d 只 · 看着最猛，拿着最亏" % len(avoid_cell),
            "#5a6e7e", ""))

    note = (
        '<div class="note">'
        '<b>口径</b>：历史胜率＝2024 年 1 月 1 日起全市场逐日观测，340 万个样本，跨牛熊，无前视（信号日收盘买入，'
        '同票不做去重，用于胜率画像）。全市场 T+20 基线 %.1f%%、平均涨幅 +%.2f%%；T+5 基线 %.1f%%。<br>'
        '<b>为什么先看位置</b>：中线要拿 20 个交易日，四周里会发生什么没人能提前知道，'
        '但此刻站在什么位置是当场就算得出来的 —— 同样是涨 20%%，站 D1 中（15~25 分）和站 D1 高（>25 分），'
        'T+20 胜率能差出 10 个百分点以上。所以先按 D1×D2 定格子，再看该格的历史 T+20 胜率，'
        '最后才用总分在格子内排个先后。<br>'
        '<b>主力格和弹性格的区别</b>：主力格（D1 中 + D2 中）是稳 —— T+10 胜率 50.6%%、T+20 51.0%%，'
        '一路都赢过大盘，走三步退一步但四周下来赢面最大；'
        '弹性格（D1 低 + D2 高）是快 —— 位置还没抬起来就刚加速，T+10 胜率只有 48.4%%（跟大盘 48.6%% 差不多），'
        '到 T+20 才 50.3%%，靠的是平均涨幅 +2.20%%（全表最高）：赢的时候赢得更多，输的时候输得也快，必须带止损。<br>'
        '<b>D1 高这一行为什么要躲</b>：D1 高＝3 日、5 日、10 日涨幅都已经拉满，属于「已经涨完」；'
        '这时候无论 D2 高不高，中线四周后的胜率都只有 40%%~44%%，是全表唯一系统性亏钱的区域。'
        '而 D1 高 + D2 高（涨得猛又刚加速）更是 T+20 平均涨幅为负（-0.39%%）—— 越拿越亏。<br>'
        '<b>免责</b>：以上为历史统计规律，不构成投资建议；不点名个股、不承诺收益，'
        '仓位与止损请自行决定。数据截止 %s。'
        '</div>' % (BASE_WIN20, BASE_MEAN20, BASE_WIN5, date_label)
    )

    tpl = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>龙头中线九宫格 · 中线位置筛选</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0d1117;color:#c9d1d9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif;line-height:1.6;padding:20px}
.container{max-width:1500px;margin:0 auto}
.header{text-align:center;padding:28px 20px 22px;margin-bottom:18px;background:linear-gradient(135deg,#161b22,#1c2333);border:1px solid #30363d;border-radius:12px}
.header h1{font-size:1.9em;color:#58a6ff;margin-bottom:8px;letter-spacing:1px}
.header .subtitle{font-size:.95em;color:#8b949e}
.header .subtitle b{color:#e6edf3}
.header .stamp{font-size:.78em;color:#484f58;margin-top:10px}
.meta{display:flex;justify-content:center;gap:12px;margin-top:16px;flex-wrap:wrap}
.meta-item{text-align:center;padding:8px 16px;background:#0d1117;border-radius:8px;border:1px solid #21262d;min-width:92px}
.meta-item .num{font-size:1.35em;font-weight:bold}
.meta-item .label{font-size:.74em;color:#8b949e;margin-top:1px}
.top-tip{margin:0 0 18px;padding:13px 18px;background:rgba(255,123,114,.08);border:1px solid rgba(255,123,114,.4);border-radius:10px;font-size:.88em;color:#c9d1d9;line-height:1.75}
.top-tip b{color:#ff7b72}
.grid-wrap{margin-bottom:20px;background:#161b22;border:1px solid #30363d;border-radius:10px;padding:16px 16px 18px}
.grid-title{font-size:.92em;color:#c9d1d9;margin-bottom:14px;text-align:center;font-weight:600}
.grid-title .grid-sub{display:block;font-size:.82em;color:#8b949e;font-weight:400;margin-top:4px}
table.grid{width:100%;table-layout:fixed;border-collapse:separate;border-spacing:7px}
table.grid th{font-size:.8em;color:#8b949e;font-weight:600;padding:4px 2px;text-align:center;line-height:1.5}
table.grid th small{font-size:.85em;color:#484f58;font-weight:400}
table.grid th.g-row{color:#58a6ff;text-align:right;padding-right:10px;width:82px;line-height:1.5}
table.grid th.g-row small{display:block;color:#484f58;font-size:.85em}
table.grid td{position:relative;background:#0d1117;border:1px solid #21262d;border-radius:9px;padding:14px 6px 11px;text-align:center}
table.grid td b{font-size:1.6em;color:#e6edf3;font-weight:700}
table.grid td em{font-style:normal;font-size:.7em;color:#8b949e;margin-left:3px}
table.grid td .w20{display:block;font-size:.86em;font-weight:700;color:#8b949e;margin-top:5px}
table.grid td .m20{display:block;font-size:.74em;color:#6e7681;margin-top:1px}
table.grid td .w5{display:block;font-size:.7em;color:#484f58;margin-top:3px;border-top:1px dashed #21262d;padding-top:3px}
table.grid td .tag{position:absolute;top:-1px;left:-1px;font-style:normal;font-size:.62em;padding:1px 7px;border-radius:8px 0 8px 0;background:#21262d;color:#8b949e}
table.grid td.g-main{border-color:#ff7b72;background:rgba(255,123,114,.12);box-shadow:0 0 0 1px rgba(255,123,114,.25) inset}
table.grid td.g-main .w20{color:#ff7b72;font-size:.98em}
table.grid td.g-main .tag{background:#ff7b72;color:#0d1117;font-weight:700}
table.grid td.g-flex{border-color:#ffa657;background:rgba(255,166,87,.09)}
table.grid td.g-flex .w20{color:#ffa657}
table.grid td.g-flex .tag{background:#ffa657;color:#0d1117;font-weight:700}
table.grid td.g-watch{border-color:#d2a8ff;background:rgba(210,168,255,.07)}
table.grid td.g-watch .w20{color:#d2a8ff}
table.grid td.g-watch .tag{background:rgba(210,168,255,.25);color:#d2a8ff}
table.grid td.g-avoid{opacity:.72;border-color:#30363d}
table.grid td.g-avoid .w20{color:#5a6e7e}
table.grid td.g-avoid .tag{background:#30363d;color:#6e7681}
.grp{margin-bottom:20px;border:1px solid #30363d;border-radius:10px;background:#161b22;padding:14px}
.grp-title{font-size:.97em;font-weight:700;margin-bottom:10px}
.grp-sub{display:block;font-size:.78em;color:#8b949e;font-weight:400;margin-top:4px}
.table-container{overflow-x:auto;border-radius:8px}
table{width:100%;table-layout:fixed;border-collapse:collapse;font-size:.82em}
thead th{background:#1c2333;color:#8b949e;font-weight:600;padding:8px 4px;text-align:center;border-bottom:2px solid #30363d;white-space:nowrap}
tbody td{padding:7px 4px;text-align:center;border-bottom:1px solid #21262d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
tbody tr:hover{background:#1c2333}
.rk{color:#8b949e}
.code{font-family:'Courier New',monospace;color:#58a6ff;font-size:.9em}
.name{color:#c9d1d9;font-weight:500}
.col-rank{width:34px}.col-code{width:76px}.col-name{width:82px}.col-sec{width:150px;color:#8b949e;font-size:.86em}
.col-price{width:60px;color:#e6edf3}.col-bar{width:66px}.col-ret{width:64px}.score-cell{width:66px}
.score-badge{display:inline-block;min-width:46px;padding:2px 9px;border-radius:14px;font-weight:700;background:#21262d;color:#c9d1d9}
.note{margin-top:4px;padding:16px 18px;background:#161b22;border:1px solid #30363d;border-radius:10px;font-size:.79em;color:#8b949e;line-height:1.9}
.note b{color:#c9d1d9}
.footer{text-align:center;padding:18px;color:#484f58;font-size:.78em;margin-top:8px}
</style>
</head>
<body>
<div class="container">
<div class="header">
  <h1>龙头中线九宫格</h1>
  <div class="subtitle">从 <b>@@TOTAL@@</b> 只自选池中，按<b>位置</b>分成九格，筛出能拿 20 个交易日的中线标的</div>
  <div class="meta">
    <div class="meta-item"><div class="num" style="color:#58a6ff">@@TOTAL@@</div><div class="label">自选池总数</div></div>
    <div class="meta-item"><div class="num" style="color:#ff7b72">@@NMAIN@@</div><div class="label">中线主力</div></div>
    <div class="meta-item"><div class="num" style="color:#ffa657">@@NFLEX@@</div><div class="label">中线弹性</div></div>
    <div class="meta-item"><div class="num" style="color:#d2a8ff">@@NWATCH@@</div><div class="label">短线最优</div></div>
    <div class="meta-item"><div class="num" style="color:#5a6e7e">@@NAVOID@@</div><div class="label">中线回避</div></div>
  </div>
  <div class="stamp">数据截止 @@DATE@@ ｜ 报告生成 @@GEN@@ ｜ 涨=红 跌=绿</div>
</div>
@@TOPTIP@@
@@GRID@@
@@BLOCKS@@
@@NOTE@@
<div class="footer">龙头中线九宫格 · 位置决定能不能拿住 · 主力格看稳、弹性格看快、D1 高整行不看</div>
</div>
</body>
</html>"""
    # 用占位符替换，避免 CSS 里的 % （width:100% 等）与 %-格式化冲突
    for k, v in (
        ("@@TOTAL@@", str(total_n)),
        ("@@NMAIN@@", str(len(main_cell))),
        ("@@NFLEX@@", str(len(flex_cell))),
        ("@@NWATCH@@", str(len(watch_cell))),
        ("@@NAVOID@@", str(len(avoid_cell))),
        ("@@DATE@@", str(date_label)),
        ("@@GEN@@", str(gen_time)),
        ("@@TOPTIP@@", top_tip),
        ("@@GRID@@", grid_html),
        ("@@BLOCKS@@", "".join(blocks)),
        ("@@NOTE@@", note),
    ):
        tpl = tpl.replace(k, v)
    return tpl


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    workdir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    workdir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("龙头中线九宫格 · 云端版")
    print("=" * 60)

    print("\n[1/3] 拉取公开数据快照: %s" % RELAY_URL)
    try:
        payload = fetch_json(RELAY_URL)
    except Exception as e:
        print("[ERROR] 拉取失败: %s" % e)
        sys.exit(1)
    rankings = payload.get("rankings", [])
    if not rankings:
        print("[ERROR] 快照为空")
        sys.exit(1)
    print("  日期: %s  股票数: %d" % (payload.get("date"), len(rankings)))

    print("\n[2/3] 拉取板块数据（用于显示所属概念）...")
    boards_map = fetch_boards()
    print("  概念板块映射: %d 只股票" % len(boards_map))

    print("\n[3/3] 生成 HTML 报告...")
    gen_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    html = build_html(payload, gen_time, boards_map)
    html_path = workdir / "龙头中线九宫格.html"
    html_path.write_text(html, encoding="utf-8")
    print("  HTML: %s" % html_path)

    cells = {}
    for r in rankings:
        cells.setdefault((d1_band(r["d1"]), d2_band(r["d2"])), []).append(r)

    print("\n" + "=" * 60)
    print("中线九宫格（只数 ／ T+20 胜率 ／ T+20 均值）")
    print("=" * 60)
    print("%-8s%16s%16s%16s" % ("D1\\D2", "D2低", "D2中", "D2高"))
    for b1 in ("高", "中", "低"):
        line = "D1 %-5s" % b1
        for b2 in ("低", "中", "高"):
            w20, m20, _ = GRID[(b1, b2)]
            line += "%6d只 %5.1f%%" % (len(cells.get((b1, b2), [])), w20)
        print(line)

    for name, key in (("中线主力", ("中", "中")), ("中线弹性", ("低", "高"))):
        lst = sorted(cells.get(key, []), key=lambda x: -x["total"])
        print("\n%s（D1 %s + D2 %s）：%d 只" % (name, key[0], key[1], len(lst)))
        for i, r in enumerate(lst, 1):
            mkt = "SH" if str(r.get("market")) == "1" else "SZ"
            print("  %2d %s.%s %-6s 总分%5.1f  D1%5.1f D2%5.1f" % (
                i, r["code"], mkt, r["name"], r["total"], r["d1"], r["d2"]))

    print("\n[done] 报告已生成（零依赖，不读本地通达信）")


if __name__ == "__main__":
    main()
