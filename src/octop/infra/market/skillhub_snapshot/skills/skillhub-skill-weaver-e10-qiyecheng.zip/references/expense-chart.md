# 报销报表 AI 问答（fna.expense.chart）

## 何时使用

用户要**分组 / 排名 / 趋势 / 对比**型的报销报表口径时使用，标准汇总接口给不出维度时用它：

- 「本月各部门报销金额排名前三」
- 「2026 年 1-8 月按月统计报销金额」
- 「研发中心今年各费用类型报销占比」「哪个部门报销最多」「报销金额 TOP10」

**不要用于**：

- 只要一个合计数（「我这个月报销了多少」）→ 用 `fna.expense.reimbursed.sum`，更快、口径确定、可复现。
- 需要精确个人/部门强制过滤口径 → 本接口不做强制过滤（见「注意」第 2 条）。
- 预算、借款、发票核销、催票 → 各自有独立 operation，按 `catalog.md` 路由。

本 operation 只读，不写业务数据，但**每次调用都真实消耗一次大模型对话 + 一次 SQL 执行**，不是纯计算接口。

## 输入要点

| 字段 | 必填 | 说明 |
|---|---|---|
| `userInput` | 是 | 自然语言问题，≤500 字符。只写业务问题，**不要**自己拼「当前用户id / 当前部门id」（服务端会拼），也不要传 SQL |
| `maxRows` | 否 | 本地展示上限，默认 200、最大 5000。只截断返回给调用方的行，**不改变服务端查询** |

提问结构：时间范围 + 统计维度 + 指标 + 排序/条数。问得太泛（「报销情况」）大概率返回 `clarify`。

服务端会对 AI 生成的 SQL 做租户隔离改写与安全校验，因此：CTE（`WITH`）、`EXISTS`、`UNION` 全系、`SLEEP`/`BENCHMARK` 会被拒；必备的 `delete_type = 0` 只能由 AI 生成，问法越贴近报销业务越稳。

## 命令

Windows PowerShell：

```powershell
weaver-work-cli --json fna run fna.expense.chart --input-json '{"userInput":"2026-08 各部门报销金额排名前三"}'
```

macOS/Linux（bash/zsh）：

```bash
weaver-work-cli --json fna run fna.expense.chart --input-json '{"userInput":"2026-08 各部门报销金额排名前三"}'
```

## 输出处理

`code` 恒为 200，**不能**用它判断成败；以 `data.kind` 为准：

| kind | 含义 | 怎么回话 |
|---|---|---|
| `rows` | 拿到结果集（`rows`/`columns`/`rowCount`） | 给「结论摘要 + 列名 + 行数」，不原样粘贴长 JSON；`truncated=true` 说明只展示前 `maxRows` 行，`meta.requestedRows` 是服务端实际返回行数 |
| `empty` | SQL 执行成功但 0 行 | 提示「暂无匹配记录」，可换问法再问一次，不得编造数据 |
| `clarify` | AI 判定需求不明确，`message` 是追问文案 | 转述文案，补充时间/部门/口径后**最多再问一次**；若文案属**权限类**（如「需求不明确，请注意权限」，此时 `meta.permissionDenied=true`），直接执行下文「无权限处理」硬规则，不再追问 |
| `blocked` | AI 生成的 SQL 未通过服务端安全校验 | 说明该问法触发安全拦截，换更贴近报销业务的问法；**不要**自己写 SQL 绕过 |
| `unexpected` | `data` 类型意外 | 只描述现象，不猜测数据，反馈维护者 |

- 列名由 AI 生成 SQL 的别名决定、**不固定**，展示时不要假设 `dept_name` / `total_amount` 一定存在。
- 金额单位为元；口径由 AI SQL 决定，关键结论建议用 `fna.expense.reimbursed.sum` 等标准接口交叉核对。
- `kind=clarify/blocked` 是按返回文案推断的（`meta.messageKindInferred=true`），原始 `message` 一并返回，口径存疑时以原文为准。
- `meta.permissionDenied` 是同一批字符串结果上的稳定布尔字段：文案含「权限 / 越权」即为 `true`（CLI 同时把它归到 `clarify`），其余为 `false`。判断权限时优先读它，不要自己再对中文做正则；`data.kind` 仍是 `rows/empty/clarify/blocked/unexpected` 五个值，不新增 kind。

## 无权限时的处理（硬规则）

**若报表接口返回无权限（`meta.permissionDenied=true`，即 `kind=clarify` 且文案含「权限」，或文案明确提示无数据权限 / 越权访问），则直接输出该结果，禁止再拼接参数去调用其他报销 / 借款 / 预算等查询接口。**

具体约束：

1. **到此为止**：把接口原文返回给用户（说明「当前账号数据权限不足，查不到该范围数据」），不再换问法、不再换口径、不再试探。
2. **不得绕行**：不允许为了「凑出」同一份报表，转而拼接 `fna.expense.reimbursed.sum`、`fna.budget.*`、借款 / 发票核销 / 流程查询（`workflow.search`、`ebuilder-form.*`）等其它接口，按部门 / 人员 / 金额自行拼装数据。这类拼装得到的数字与原报表口径不同源，属于越权尝试，且极易产出错误结论。
3. **不得自写 SQL**：`raw.sql` 之类需要自行拼 SQL 的方式同样禁止。
4. **正确做法**：如实告知权限边界 + 给出可行替代路径（换具备该数据权限的账号 / 请管理员扩权 / 由有权限方导出明细文件后再分析），由用户决定下一步。

## 注意

1. **额度与耗时**：单次调用是「大模型 → SQL → 执行」串行，通常数秒级；禁止为「多试几个问法」循环调用，一轮对话最多问 1-2 次，问之前先想清楚时间范围和维度。
2. **数据范围不是「当前人」**：服务端只是把「当前部门id / 当前用户id」作为**提示文本**拼进 prompt，不做强制过滤，返回的可能是**全租户**报销数据；`userInput` 又是用户可控文本。涉及「我/某人」的个人金额口径时改用 `fna.expense.reimbursed.sum`（按 `employeeId` 过滤），并在汇报里注明数据范围。
3. **无服务端 LIMIT**：大租户下可能很慢或返回大量行；`maxRows` 只做本地截断。
4. **单轮问答**：每次请求生成新的会话 ID，不能凭上一次结果续聊；追问请把上下文重新写进新的 `userInput`。
5. **二开接口依赖**：路径是 `/api/secondev/fna/`（`FexsCommonController`）。若同租户其它 `fna.*` 正常、只有本 operation 返回 404 或 500，先怀疑该租户未安装 seconddev 的 fna 二开包，不要判为「能力不存在」。
6. **权限拦截即终点**：返回无权限时按上文「无权限时的处理」执行，直接输出结果，禁止拼接参数改写问法或改调其他报销 / 借款 / 预算接口绕行。

## 失败处理

| 现象 | 含义 | 处理 |
|---|---|---|
| `validation.user_input_required` | 没传或传空白 | 向用户要一个具体问题 |
| `validation.user_input_too_long` | 超过 500 字符 | 压缩或拆成多个问题 |
| `validation.max_rows_invalid` | `maxRows` 越界 | 用 1-5000 的整数 |
| `api.server_error`（HTTP 500） | 当前人查不到（服务端 NPE）/ AI 场景异常 / SQL 执行失败 | **不自动重试**；说明可能原因，必要时换标准接口 |
| `api.business_error` | `code != 200` | 按 `message` 转述，不猜测数据 |
| 返回无权限（`meta.permissionDenied=true`，文案含「权限 / 越权」） | 当前账号数据权限不覆盖该范围 | **直接输出该结果并说明权限边界**，不再换问法，禁止拼接参数改调其他报销 / 借款 / 预算接口 |
| `authentication.session_expired` | 登录态失效 | 先向用户确认 E10 登录域名，再刷新登录；不得带失效 Cookie 重试 |
| `network.timeout` | AI/SQL 串行超过 90s | 换更窄的时间范围；是否重试由用户决定（重试会再消耗一次模型额度） |
