---
name: skillhub-skill-weaver-e10-qiyecheng
description: "泛微齐业成费控中心（预算查询/费用中心/报销报表/借款管理/发票核销）的 E10 查询与提醒写操作能力，通过 weaver-work-cli fna 命令执行。"
---

# weaver-work-cli 齐业成费控（FNA）Skill

**CRITICAL — 开始前 MUST 先用 Read 工具读取 [`../weaver-e10-shared/SKILL.md`](../weaver-e10-shared/SKILL.md)，其中包含安装、E10 认证、JSON 输出和高风险写入规则。若共享规则不存在、CLI 未安装或读取失败，说明本技能的必需依赖缺失，必须调用宿主提供的提问/确认弹框，向用户说明必须补齐 `weaver-work-cli` 与共享 skill `weaver-e10-shared`（不补齐本技能无法执行）及补齐计划，并把下面两条待执行命令原样完整展示在确认信息中；Agent 不能在未确认时自行安装。用户明确确认后，Agent 必须直接代为按顺序执行且每条仅执行一次，不得要求或引导用户手动执行：① 缺 CLI 时执行 `npm install -g weaver-work-cli`；② 再执行 `weaver-work-cli skills install shared --target-dir <SKILLS_ROOT>` 装回共享 skill，`<SKILLS_ROOT>` 取本 SKILL.md 所在目录的上一级绝对目录（即与本技能同级的 skills 根目录），不要省略 `--target-dir`——省略会装进默认目录，导致本技能依然读不到共享规则。命令均成功后重新读取共享规则；仍读不到就停止并把结果报告用户，不得凭猜测继续。**
**`--is-connector` 判据**：用户明确使用连接器、或上下文要求用连接器完成任务 → 传 `true`；本次任务或上下文直接选择单独技能 → 不传；用户没有明确说明时，按**正在运行的这份 Skill 是哪一级**定——**用户级（条目标 `(user)`）不传，连接器级（标 `(connector)`）传**（同名 Skill 只会运行用户级那一份）。传 `true` 时不要再写 `--profile` / `--base-url`。完整规则见 [`../weaver-e10-shared/SKILL.md`](../weaver-e10-shared/SKILL.md)。

所有调用统一走 `weaver-work-cli fna ...`，禁止绕过 CLI 直接 curl/fetch E10 接口，禁止读取、复制、打印或解析 Cookie、ETEAMSID、Token 或 `~/.e10-cli` 等认证目录；登录诊断只允许 `weaver-work-cli auth root/status/profile list/profile current`、`weaver-work-cli doctor --e10` 和业务命令 JSON 错误。

## 适用场景（何时使用本技能）

用户提到事前申请单预算、预算执行报表、报销/借款/预付核销金额、报销报表 AI 问答（部门/期间/费用类型分组、排名、趋势）、全公司借款汇总与列表、提醒还款、发票核销金额与列表或催票时，使用本技能。

发票票夹与 OCR 走 `weaver-e10-yepiaotong`，人员与流程 ID 解析不属于本技能范围。

## 认证与请求头契约

登录与会话由 `weaver-e10-shared` 共享规则和 `weaver-work-cli auth ...` 命令体系统一托管。业务 Skill 不自建登录流程，不索取、打印或转存任何凭证。

`weaver-work-cli` 内部直连 E10 时，三项用户信息参数由 CLI 统一注入，业务侧只描述业务意图，不得自行拼装请求头、不得把凭证落到日志或回答正文。

**每一条发往 E10 的请求必须同时携带下列三项请求头，缺一不可**（下方表格为同一契约的展开说明）：

- Cookie: 完整原始 Cookie 串（由 `e10-login` 返回，禁止裁剪 / 去重 / 改写，整串透传）
- eteamsid: `e10-login` 返回的 ETEAMSID（原样透传，不得截断或改写）
- User-Agent: AgentType=<agentType>,IsAgent=true（每次请求必带，`<agentType>` 由 CLI 按运行上下文填充）

| 请求头 | 取值 | 要求 |
|---|---|---|
| `Cookie` | `e10-login` 返回的完整原始 Cookie 串 | 禁止裁剪 / 去重 / 改写，整串透传 |
| `eteamsid` | `e10-login` 返回的 ETEAMSID | 原样透传，不得截断或改写 |
| `User-Agent` | `AgentType=<agentType>,IsAgent=true` | 每次请求必带，`<agentType>` 由 CLI 按运行上下文填充 |

凭证只存在于 CLI 进程内存，业务 Skill 全程不读取、不打印、不解析。


## 能力范围

| 能力 | 说明 | 身份 |
|---|---|---|
| 预算查询 | 事前申请单预算详情、预算执行报表（只读） | 登录即可（接口公开） |
| 费用中心 | 报销金额合计、借款金额分段、预付核销金额（只读） | 登录即可（默认当前登录人） |
| 报销报表 AI 问答 | 自然语言问题 → AI 生成 SQL → 部门/期间/费用类型等分组报表（只读，每次消耗一次大模型对话 + 一次 SQL） | 登录即可（接口公开，结果可能是全租户范围） |
| 借款管理 | 全公司待还/还款中汇总、全员借款单列表（只读）；提醒还款（写） | 管理员 |
| 发票核销财务 | 金额 tab 汇总、核销列表（只读）；催票（写） | 财务/管理员 |

## 路由优先级

先判断用户意图归属哪个模块，再选择 operation；一个意图只选最匹配的一个接口，目标不明确先提问收窄，不自动切换近义接口。**只有借款/发票核销模块涉及提醒类写操作，先 `prepare` 出预览并请用户明确确认，再 `apply`；禁止未确认自动执行。**

- 「这个事前申请单预算还剩多少」「某 requestId 的预算情况」→ `fna.budget.application.detail`
- 「预算执行报表」「某模板/部门/期间预算执行情况」→ `fna.budget.execute.list`
- 「我/某人某段时间报销了多少」→ `fna.expense.reimbursed.sum`
- 「本月各部门报销金额排名」「按月份/费用类型统计报销金额」「报销金额 TOP10」→ `fna.expense.chart`
- 「还有多少借款没还」「各状态借款金额/笔数」→ `fna.expense.loan.sum`
- 「预付核销进度」「未到账多少」→ `fna.expense.prepay.writeoff.sum`
- 「全公司待还款/还款中多少钱」→ `fna.loan.main.page`
- 「列出借款单」「谁还欠多少」→ `fna.loan.main.list`
- 「提醒某人/批量提醒还款」→ `fna.loan.remind.repay.prepare` → 确认 → `fna.loan.remind.repay.apply`
- 「发票核销未核销/核销中多少」→ `fna.invoice.writeoff.summary`
- 「列出发票核销单」→ `fna.invoice.writeoff.list`
- 「催票/批量催票」→ `fna.invoice.writeoff.callticket.prepare` → 确认 → `fna.invoice.writeoff.callticket.apply`

## Operation 表（以 `weaver-work-cli fna schema` 为准）

| 操作 | 风险 | 说明 |
|---|---|---|
| `fna.budget.application.detail` | read | GET 事前申请单预算详情（requestId 必填） |
| `fna.budget.execute.list` | read | POST 预算执行报表（current/pageSize 必填） |
| `fna.expense.reimbursed.sum` | read | 报销金额合计（body 可为空） |
| `fna.expense.loan.sum` | read | 借款金额分段汇总（已知缺陷：仅统计首条借款记录；瞬时空响应自动重试） |
| `fna.expense.prepay.writeoff.sum` | read | 预付核销金额汇总 |
| `fna.expense.chart` | read | 报销报表 AI 问答（userInput 必填；按 data.kind=rows/empty/clarify/blocked/unexpected 判成败；每次消耗一次大模型对话 + 一次 SQL） |
| `fna.loan.main.page` | read | 借款首页汇总（dhk/hkz） |
| `fna.loan.main.list` | read | 借款首页列表（menuCode/permissionSetCode 必填） |
| `fna.loan.remind.repay.prepare` | write | 提醒还款预览（不发送） |
| `fna.loan.remind.repay.apply` | write | 提醒还款（confirm+continuation） |
| `fna.invoice.writeoff.summary` | read | 发票核销金额 tab |
| `fna.invoice.writeoff.list` | read | 发票核销列表 |
| `fna.invoice.writeoff.callticket.prepare` | write | 催票预览（不发送） |
| `fna.invoice.writeoff.callticket.apply` | write | 催票（confirm+continuation） |

## 前置依赖与口径约定

- **ID 解析不在本 Skill**：姓名→`employeeId`、流程名→`workflowId` 依赖人员/流程解析接口，源资料未提供；用户只给姓名/流程名时先索要数字 ID，禁止编造 ID 或接口。
- `menuCode`/`permissionSetCode` 环境相关（借款 `fesx_fna_borrowingManagement(.default)`、核销 `inv_write_off_financial(.default)`），不确定时先与用户核对实际值。
- 金额双套口径：`data` 原始精度字符串（计算）、`displayData` 格式化（展示/回传）；金额单位为元。
- 费用中心日期口径不同：报销按明细费用日期、借款按流程创建时间、预付核销按核销记录创建时间。
- 借款费用中心接口 requestId/employeeId/workflowId 只认**数字**（字符串会静默返回空）；超 2^53 的巨型 ID 保留字符串并提示人工核验。
- `fna.expense.chart` 是二开接口（`/api/secondev/fna/getExpenseChart`）：服务端只把当前人/当前部门作为**提示文本**拼进 prompt，不做强制过滤，返回可能是全租户数据；个人金额口径必须改用 `fna.expense.reimbursed.sum`（按 `employeeId` 过滤），并在汇报中注明数据范围。
- `fna.expense.chart` 返回 `meta.permissionDenied=true`（或文案含「权限 / 越权」）表示当前账号数据权限不覆盖该范围，按执行原则第 9 条**立即停住**，不得改调其它接口拼装同一份报表。

## 执行原则

1. 业务输入只描述业务对象与意图；认证与接口地址全部由 CLI 托管。
2. 列表/详情可能返回大响应：只保留回答所需字段，给摘要与总数，不原样粘贴超长 JSON。
3. 金额/比率为字符串时转数值使用（比率需去 `%`）。
4. 借款金额查询已知实现缺陷：对外汇报注明「可能仅反映首条记录口径」。
5. 写操作（remindRepay/callTicket）失败决策树：`partial` / `write_uncertain` / 登录失效 / 网络中断 → **立即停止，禁止自动重试**，做一次只读回查（`fna.loan.main.list` / `fna.invoice.writeoff.list`）后向用户汇报；若返回 `confirmation.required`，说明缺少明确确认，先 prepare 再确认后 apply。
6. 金额结论口径存疑时（如借款缺陷、瞬时空响应）先说明不确定性；`total=0` 或空列表提示「暂无记录」，不得伪造成功。
7. `fna.expense.chart` 的成败看 `data.kind` 而不是 `code`（`code` 恒为 200，追问/拦截也走 success）：`rows`/`empty` 属正常，`clarify` 按文案补口径后最多重问一次，`blocked` 换更贴近报销业务的问法而**不是**自己写 SQL；`unexpected` 只描述现象并反馈维护者。
8. `fna.expense.chart` 每次调用都真实消耗一次大模型对话 + 一次 SQL，一轮对话最多问 1-2 次，禁止循环试探；`maxRows` 只截断本地展示、不改变服务端查询；列名由 AI SQL 别名决定，不要假设固定列名。
9. **权限拦截即终点（硬规则）**：`fna.expense.chart` 返回 `meta.permissionDenied=true`，或文案明确提示无数据权限 / 越权访问时，把接口原文如实告知用户并说明「当前账号数据权限不足，查不到该范围数据」，然后给出替代路径（换具备该权限的账号 / 请管理员扩权 / 由有权限方导出明细后再分析），由用户决定下一步。**禁止**换问法、换口径继续试探，**禁止**改调 `fna.expense.reimbursed.sum`、`fna.budget.*`、借款 / 发票核销等其它接口按部门 / 人员 / 金额自行拼装同一份报表，**禁止**自写 SQL 绕过——拼装结果与原报表口径不同源，属于越权尝试且极易产出错误结论。详见 [references/expense-chart.md](references/expense-chart.md) 的「无权限时的处理」。

## References

| 需要 | 读取 |
|---|---|
| 接口目录与按模块路由 | [references/catalog.md](references/catalog.md) |
| 预算：事前申请单预算详情 / 预算执行报表 | [references/budget.md](references/budget.md) |
| 费用中心：报销 / 借款 / 预付核销 | [references/expense-center.md](references/expense-center.md) |
| 报销报表 AI 问答：自然语言出报表、五个 `kind`、无权限硬规则、额度与数据范围风险 | [references/expense-chart.md](references/expense-chart.md) |
| 借款管理：汇总 / 列表 / 提醒还款（prepare→apply） | [references/loan-management.md](references/loan-management.md) |
| 发票核销：金额 tab / 列表 / 催票（prepare→apply） | [references/invoice-writeoff.md](references/invoice-writeoff.md) |
| 源资料指纹与更新检测 | [references/source-manifest.json](references/source-manifest.json) |

## 命令示例

Windows PowerShell：

```powershell
weaver-work-cli --json fna run fna.budget.application.detail --input-json '{"requestId":"1001"}'
weaver-work-cli --json fna run fna.expense.loan.sum --input-json '{"employeeId":12345,"startDate":"2026-01-01","endDate":"2026-08-31"}'
weaver-work-cli --json fna run fna.expense.chart --input-json '{"userInput":"2026-08 各部门报销金额排名前三"}'
weaver-work-cli --json fna run fna.loan.main.list --input-json '{"current":1,"pageSize":20,"menuCode":"fesx_fna_borrowingManagement","permissionSetCode":"fesx_fna_borrowingManagement.default"}'
```

macOS/Linux（bash/zsh）：

```bash
weaver-work-cli --json fna run fna.budget.application.detail --input-json '{"requestId":"1001"}'
weaver-work-cli --json fna run fna.expense.loan.sum --input-json '{"employeeId":12345,"startDate":"2026-01-01","endDate":"2026-08-31"}'
weaver-work-cli --json fna run fna.expense.chart --input-json '{"userInput":"2026-08 各部门报销金额排名前三"}'
weaver-work-cli --json fna run fna.loan.main.list --input-json '{"current":1,"pageSize":20,"menuCode":"fesx_fna_borrowingManagement","permissionSetCode":"fesx_fna_borrowingManagement.default"}'
```

## 附件与文件安全

本 Skill 的 12 个接口均为查询/提醒类，**不涉及附件、图片或文件上传解析**。若后续扩展接口涉及附件或文件内容解析，必须先向用户说明「附件内容可能会发送到当前大模型服务处理，可能进入大模型上下文」，并在用户明确确认后才能处理；不得把用户仅提供路径或文件名视为同意解析或上传。

## 不在本 Skill 范围

- 借款「确认已还 confirmRepay」、核销明细等页面按钮能力（源资料未提供接口）→ 见 `weaver-work-cli fna schema` 的 `withheldOperations`，不得编造 operation 或直连接口。
- 报销报表 AI 问答只接受自然语言 `userInput`：不接受自写 SQL、不暴露 AI 生成的 SQL，也没有 `scope=self/dept/tenant` 之类的强制过滤参数（服务端未提供）。
- 报表返回无权限后改调其它报销/借款/预算/流程接口拼装同一份报表，或自写 SQL 绕过权限边界——属于越权尝试，一律禁止。
- 姓名/流程名 → ID 的解析、创建借款单/预付单/事前申请单等需联动工作流的写流程（未提供接口依据）。
- 其它模块（发票票夹、人事、流程待办）请路由到对应 Skill，不在此重复实现。
