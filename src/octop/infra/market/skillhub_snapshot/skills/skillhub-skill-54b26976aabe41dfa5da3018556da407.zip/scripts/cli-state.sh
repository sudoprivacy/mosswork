#!/bin/sh
set -e

# cli-state.sh — Output install state and token status for clf（财立方新闻 CLI）.
# Usage: sh scripts/cli-state.sh
#
# 输出 JSON（与 cli-state.ps1 同构）：
#   {
#     "platform": { "os": "...", "cliPath": "..." | null, "cliSource": "global|local|none" },
#     "cliExists": true | false,
#     "version":  { "current": "1.0.0" | null, "error": "..." | null },
#     "token":    { "status": "configured|default|error", "source": "env|config|auto|null", "error": "..." | null }
#   }

fail() { echo "Error: $1" >&2; exit 1; }

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr '\n' ' '
}

# ── paths ──
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
skill_dir=$(dirname -- "$script_dir")
default_cli_dir="$(dirname "$(dirname -- "$skill_dir")")/clf-cli"
cli_dir="${CLF_CLI_DIR:-$default_cli_dir}"
cli_file="$cli_dir/dist/index.js"

os="$(uname -s 2>/dev/null || echo unknown)"

# ── cli detection: PATH global > source dir (CLF_CLI_DIR / default) ──
cli_path=""
cli_source="none"
if command -v clf >/dev/null 2>&1 && clf --help >/dev/null 2>&1; then
  cli_path="$(command -v clf)"
  cli_source="global"
elif [ -f "$cli_file" ]; then
  cli_path="$cli_file"
  cli_source="local"
fi

if [ -n "$cli_path" ]; then
  cli_exists="true"
else
  cli_exists="false"
fi

# ── version（local：读 clf-cli/package.json；global：读 npm root -g 下的 clf-cli）──
version_current="null"
version_error="null"
if [ "$cli_exists" = "true" ]; then
  if [ "$cli_source" = "local" ]; then
    pkg_json="$(dirname "$(dirname -- "$cli_path")")/package.json"   # dist/../package.json
    if [ -f "$pkg_json" ]; then
      v="$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$pkg_json" | head -n 1)"
      if [ -n "$v" ]; then
        version_current="\"$v\""
      else
        version_error="\"version not found in $pkg_json\""
      fi
    else
      version_error="\"package.json not found: $pkg_json\""
    fi
  else
    npm_root="$(npm root -g 2>/dev/null || true)"
    if [ -n "$npm_root" ] && [ -f "$npm_root/clf-cli/package.json" ]; then
      v="$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$npm_root/clf-cli/package.json" | head -n 1)"
      if [ -n "$v" ]; then
        version_current="\"$v\""
      else
        version_error="\"version not found in $npm_root/clf-cli/package.json\""
      fi
    else
      version_error="\"global clf: package.json not found under npm root (npm root -g)\""
    fi
  fi
fi

# ── token state（解析 clf token 输出的「来源：」字段）──
token_status="error"
token_source="null"
token_error="null"
if [ "$cli_exists" = "true" ]; then
  if [ "$cli_source" = "local" ]; then
    if ! command -v node >/dev/null 2>&1; then
      token_error="\"node not found in PATH; cannot run clf token\""
    else
      set +e
      token_out="$(node "$cli_path" token 2>&1)"
      token_rc=$?
      set -e
      if [ "$token_rc" -eq 0 ] && [ -n "$token_out" ]; then
        src="$(printf '%s\n' "$token_out" | sed -n 's/.*来源：\(.*\)/\1/p' | head -n 1)"
        case "$src" in
          *环境变量*) token_status="configured"; token_source="\"env\"" ;;
          *配置文件*) token_status="configured"; token_source="\"config\"" ;;
          *未配置*) token_status="default"; token_source="null" ;;
          "") token_status="error"; token_error="\"clf token output did not contain 来源 field\"" ;;
          *) token_status="error"; token_error="\"unrecognized token source: $(json_escape "$src")\"" ;;
        esac
      else
        token_status="error"
        if [ -n "$token_out" ]; then
          token_error="\"$(json_escape "$token_out")\""
        else
          token_error="\"clf token failed with exit code $token_rc\""
        fi
      fi
    fi
  else
    set +e
    token_out="$(clf token 2>&1)"
    token_rc=$?
    set -e
    if [ "$token_rc" -eq 0 ] && [ -n "$token_out" ]; then
      src="$(printf '%s\n' "$token_out" | sed -n 's/.*来源：\(.*\)/\1/p' | head -n 1)"
      case "$src" in
        *环境变量*) token_status="configured"; token_source="\"env\"" ;;
        *配置文件*) token_status="configured"; token_source="\"config\"" ;;
        *未配置*) token_status="default"; token_source="null" ;;
        "") token_status="error"; token_error="\"clf token output did not contain 来源 field\"" ;;
        *) token_status="error"; token_error="\"unrecognized token source: $(json_escape "$src")\"" ;;
      esac
    else
      token_status="error"
      if [ -n "$token_out" ]; then
        token_error="\"$(json_escape "$token_out")\""
      else
        token_error="\"clf token failed with exit code $token_rc\""
      fi
    fi
  fi
else
  token_error="\"CLI not found, cannot check token.\""
fi

# ── output JSON ──
if [ -n "$cli_path" ]; then
  cli_path_json="\"$cli_path\""
else
  cli_path_json="null"
fi

printf '{\n'
printf '  "platform": {\n'
printf '    "os": "%s",\n' "$os"
printf '    "cliPath": %s,\n' "$cli_path_json"
printf '    "cliSource": "%s"\n' "$cli_source"
printf '  },\n'
printf '  "cliExists": %s,\n' "$cli_exists"
printf '  "version": {\n'
printf '    "current": %s,\n' "$version_current"
printf '    "error": %s\n' "$version_error"
printf '  },\n'
printf '  "token": {\n'
printf '    "status": "%s",\n' "$token_status"
printf '    "source": %s,\n' "$token_source"
printf '    "error": %s\n' "$token_error"
printf '  }\n'
printf '}\n'
