﻿#!/usr/bin/env pwsh

# cli-state.ps1 — Output install state and token status for clf（财立方新闻 CLI）.
# Usage: powershell scripts/cli-state.ps1
#
# 输出 JSON：
#   {
#     "platform": { "os": "windows", "cliPath": "...", "cliSource": "global|local|none" },
#     "cliExists": true | false,
#     "version":  { "current": "1.0.0" | null, "error": "..." | null },
#     "token":    { "status": "configured|default|error", "source": "env|config|auto|null", "error": "..." | null }
#   }
#
# 与 run-cli.ps1 的路径解析顺序一致：PATH 全局 clf > CLF_CLI_DIR > 默认 ../clf-cli。

param(
  [Parameter(Position = 0)]
  [string]$Command
)

$ErrorActionPreference = "Stop"

function Fail([string]$Message) {
  Write-Error "Error: $Message"
  exit 1
}

if ($Command -eq "help") {
  Write-Host "Usage: powershell scripts/cli-state.ps1"
  Write-Host ""
  Write-Host "Print install state and token status for clf."
  exit 0
}

if ($Command) {
  Fail "unknown argument: $Command"
}

# ── helpers ──────────────────────────────────────────────────────────

function Resolve-CommandCliPath([string]$CliCommandName) {
  $resolved = $null
  try {
    $resolved = (Get-Command $CliCommandName -ErrorAction SilentlyContinue).Source
  } catch {
    return $null
  }
  if (-not $resolved) { return $null }
  try {
    $null = & $resolved --help 2>&1
    if ($LASTEXITCODE -ne 0) { return $null }
  } catch {
    return $null
  }
  return $resolved.Replace("\", "/")
}

function Resolve-Node {
  try {
    return (Get-Command node -ErrorAction SilentlyContinue).Source
  } catch {
    return $null
  }
}

function ConvertTo-JsonEscaped([string]$Value) {
  return $Value.Replace("\", "\\").Replace('"', '\"').Replace("`t", "\t").Replace("`r", "").Replace("`n", " ")
}

# ── platform & paths ─────────────────────────────────────────────────

$Os = "windows"
$CliCommandName = "clf"
$CliFilename = "dist/index.js"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDir = Split-Path -Parent $ScriptDir
$DefaultCliDir = Join-Path (Split-Path -Parent (Split-Path -Parent $SkillDir)) "clf-cli"
$EnvCliDir = $env:CLF_CLI_DIR
$CliDir = if ($EnvCliDir) { $EnvCliDir } else { $DefaultCliDir }
$LocalCliFile = Join-Path $CliDir $CliFilename

# ── cli detection: PATH global > source dir (CLF_CLI_DIR / default) ──

$CliSource = "none"
$CliPath = $null

$CommandCliPath = Resolve-CommandCliPath $CliCommandName
if ($CommandCliPath) {
  $CliPath = $CommandCliPath
  $CliSource = "global"
} elseif (Test-Path $LocalCliFile) {
  $CliPath = $LocalCliFile.Replace("\", "/")
  $CliSource = "local"
}

$CliExists = $CliSource -ne "none"

# ── version ──────────────────────────────────────────────────────────

$VersionCurrent = "null"
$VersionError = "null"

if ($CliExists) {
  if ($CliSource -eq "local") {
    $pkgJson = Join-Path (Split-Path -Parent (Split-Path -Parent $CliPath)) "package.json"  # dist/../package.json
    try {
      if (Test-Path $pkgJson) {
        # 显式 UTF-8：PS 5.1 默认按 ANSI 读取无 BOM 的 UTF-8 文件会乱码
        $pkg = Get-Content -Path $pkgJson -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($pkg.version) {
          $VersionCurrent = "`"$($pkg.version)`""
        } else {
          $VersionError = "`"package.json exists but version is missing: $pkgJson`""
        }
      } else {
        $VersionError = "`"package.json not found next to dist/index.js: $pkgJson`""
      }
    } catch {
      $VersionError = "`"failed to read package.json: $pkgJson`""
    }
  } else {
    # global（npm 全局安装 / npm link）：从 npm root -g 读取 clf-cli/package.json
    $Npm = Get-Command npm -ErrorAction SilentlyContinue
    if ($Npm) {
      $npmRoot = & npm root -g 2>$null
      if ($LASTEXITCODE -eq 0 -and $npmRoot) {
        $pkgJson = Join-Path $npmRoot "clf-cli\package.json"
        try {
          if (Test-Path $pkgJson) {
            # 显式 UTF-8：PS 5.1 默认按 ANSI 读取无 BOM 的 UTF-8 文件会乱码
            $pkg = Get-Content -Path $pkgJson -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($pkg.version) {
              $VersionCurrent = "`"$($pkg.version)`""
            } else {
              $VersionError = "`"package.json exists but version is missing: $pkgJson`""
            }
          } else {
            $VersionError = "`"package.json not found: $pkgJson`""
          }
        } catch {
          $VersionError = "`"failed to read package.json: $pkgJson`""
        }
      } else {
        $VersionError = "`"global clf：无法获取 npm 全局目录（npm root -g 失败）`""
      }
    } else {
      $VersionError = "`"global clf：npm 不在 PATH，无法读取版本`""
    }
  }
}

# ── token state（解析 clf token 输出的「来源：」字段）──────────────

$TokenStatus = "error"
$TokenSource = "null"
$TokenError = "null"

if ($CliExists) {
  $tokenArgs = @("token")
  if ($CliSource -eq "local") {
    $Node = Resolve-Node
    if (-not $Node) {
      $TokenError = "`"node not found in PATH; cannot run clf token`""
    } else {
      # Node 输出 UTF-8，PS 5.1 默认按系统 ANSI 解码会乱码，临时切到 UTF-8
      $prevEncoding = $null
      try { $prevEncoding = [Console]::OutputEncoding; [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new() } catch {}
      $tokenResult = & $Node $CliPath @tokenArgs 2>&1
      $tokenExit = if ($null -ne $LASTEXITCODE) { [int]$LASTEXITCODE } else { 0 }
      $tokenOut = ($tokenResult | Out-String).Trim()
      try { if ($null -ne $prevEncoding) { [Console]::OutputEncoding = $prevEncoding } } catch {}
      if ($tokenExit -eq 0 -and $tokenOut) {
        $srcMatch = [regex]::Match($tokenOut, '来源：(.+)')
        if ($srcMatch.Success) {
          $src = $srcMatch.Groups[1].Value.Trim()
          if ($src -match '环境变量') {
            $TokenStatus = "configured"
            $TokenSource = "`"env`""
          } elseif ($src -match '配置文件') {
            $TokenStatus = "configured"
            $TokenSource = "`"config`""
          } elseif ($src -match '未配置') {
            $TokenStatus = "default"
            $TokenSource = "null"
          } else {
            $TokenStatus = "error"
            $TokenError = "`"unrecognized token source: $src`""
          }
        } else {
          $TokenStatus = "error"
          $TokenError = "`"clf token output did not contain 来源: field: $tokenOut`""
        }
      } else {
        $TokenStatus = "error"
        $TokenError = if ($tokenOut) { "`"$tokenOut`"" } else { "`"clf token failed with exit code $tokenExit`"" }
      }
    }
  } else {
    # global：直接执行 clf token（Node 输出 UTF-8，临时切输出编码防乱码）
    $prevEncoding = $null
    try { $prevEncoding = [Console]::OutputEncoding; [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new() } catch {}
    $tokenResult = & $CliPath @tokenArgs 2>&1
    $tokenExit = if ($null -ne $LASTEXITCODE) { [int]$LASTEXITCODE } else { 0 }
    $tokenOut = ($tokenResult | Out-String).Trim()
    try { if ($null -ne $prevEncoding) { [Console]::OutputEncoding = $prevEncoding } } catch {}
    if ($tokenExit -eq 0 -and $tokenOut) {
      $srcMatch = [regex]::Match($tokenOut, '来源：(.+)')
      if ($srcMatch.Success) {
        $src = $srcMatch.Groups[1].Value.Trim()
        if ($src -match '环境变量') {
          $TokenStatus = "configured"
          $TokenSource = "`"env`""
        } elseif ($src -match '配置文件') {
          $TokenStatus = "configured"
          $TokenSource = "`"config`""
        } elseif ($src -match '未配置') {
          $TokenStatus = "default"
          $TokenSource = "null"
        } else {
          $TokenStatus = "error"
          $TokenError = "`"unrecognized token source: $src`""
        }
      } else {
        $TokenStatus = "error"
        $TokenError = "`"clf token output did not contain 来源: field: $tokenOut`""
      }
    } else {
      $TokenStatus = "error"
      $TokenError = if ($tokenOut) { "`"$tokenOut`"" } else { "`"clf token failed with exit code $tokenExit`"" }
    }
  }
} else {
  $TokenError = "`"CLI not found, cannot check token.`""
}

# ── output JSON ──────────────────────────────────────────────────────

$cliExistsJson = if ($CliExists) { "true" } else { "false" }
$cliPathJson = if ($CliPath) { "`"$CliPath`"" } else { "null" }

Write-Output @"
{
  "platform": {
    "os": "$Os",
    "cliPath": $cliPathJson,
    "cliSource": "$CliSource"
  },
  "cliExists": $cliExistsJson,
  "version": {
    "current": $VersionCurrent,
    "error": $VersionError
  },
  "token": {
    "status": "$TokenStatus",
    "source": $TokenSource,
    "error": $TokenError
  }
}
"@
