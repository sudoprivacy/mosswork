﻿#!/usr/bin/env pwsh

# run-cli.ps1 — Execute clf（财立方新闻 CLI）via the resolved path.
# Usage: powershell scripts/run-cli.ps1 <command> [args...]
#
# 解析顺序（与 cli-state.ps1 一致）：
#   1. PATH 中的全局 clf 命令（验证 clf --help 可用）
#   2. CLF_CLI_DIR 环境变量指向的 clf-cli 源码目录（node dist/index.js）
#   3. 默认源码目录：技能包同级的 ../clf-cli（node dist/index.js）
#
# 说明：clf 是TypeScript + commander 工程（构建产物 dist/index.js），无需 --caller 注入；
# 本脚本只负责"路径解析 + 统一执行"，Agent 只选择命令与参数。

$ErrorActionPreference = "Stop"

function Fail([string]$Message) {
  Write-Error "Error: $Message"
  exit 1
}

# ── 解析 PATH 中的 clf 命令并验证可用 ──────────────────────────────
function Resolve-CommandCliPath([string]$CliCommandName) {
  $resolved = $null
  try {
    $resolved = (Get-Command $CliCommandName -ErrorAction SilentlyContinue).Source
  } catch {
    return $null
  }
  if (-not $resolved) { return $null }
  try {
    $null = & $resolved --help 2>&1
    if ($LASTEXITCODE -ne 0) { return $null }
  } catch {
    return $null
  }
  return $resolved
}

function Resolve-Node {
  try {
    return (Get-Command node -ErrorAction SilentlyContinue).Source
  } catch {
    return $null
  }
}

# ── main ────────────────────────────────────────────────────────────

if ($args.Count -eq 0) {
  Fail "missing CLI command"
}

$CliCommandName = "clf"
$CliFilename = "dist/index.js"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillDir = Split-Path -Parent $ScriptDir
$DefaultCliDir = Join-Path (Split-Path -Parent (Split-Path -Parent $SkillDir)) "clf-cli"
$EnvCliDir = $env:CLF_CLI_DIR
$CliDir = if ($EnvCliDir) { $EnvCliDir } else { $DefaultCliDir }
$CliFile = Join-Path $CliDir $CliFilename

# 1) PATH 中的全局 clf 命令
$CliPath = Resolve-CommandCliPath $CliCommandName
if ($CliPath) {
  & $CliPath @args
  exit $LASTEXITCODE
}

# 2) 源码目录中的 clf.mjs（node 执行）
if (Test-Path $CliFile) {
  $Node = Resolve-Node
  if (-not $Node) {
    Fail "node not found in PATH; clf 需要 Node.js >= 18"
  }
  & $Node $CliFile @args
  exit $LASTEXITCODE
}

Fail "clf not found. Run powershell scripts/cli-state.ps1 to inspect installation state first."
