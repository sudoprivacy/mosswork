#!/bin/sh
set -e

# run-cli.sh — Execute clf（财立方信息资讯 CLI）via the resolved path.
# Usage: sh scripts/run-cli.sh <command> [args...]
#
# 解析顺序（与 cli-state.sh 一致）：
#   1. PATH 中的全局 clf 命令（验证 clf --help 可用）
#   2. CLF_CLI_DIR 环境变量指向的 clf-cli 源码目录（node dist/index.js，需先 npm run build）
#   3. 默认源码目录：技能包同级的 ../clf-cli（node dist/index.js）
#
# 说明：clf 是 TypeScript + commander 工程（构建产物 dist/index.js）；
# 本脚本只负责"路径解析 + 统一执行"，Agent 只选择命令与参数。

fail() { echo "Error: $1" >&2; exit 1; }

# ── 解析 PATH 中的 clf 命令并验证可用 ──
resolve_command_cli_path() {
  resolved_path="$(command -v clf 2>/dev/null || true)"
  if [ -z "$resolved_path" ]; then
    return 1
  fi
  if "$resolved_path" --help >/dev/null 2>&1; then
    printf '%s\n' "$resolved_path"
    return 0
  fi
  return 1
}

# ── main ──
if [ "$#" -eq 0 ]; then
  fail "missing CLI command"
fi

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
skill_dir=$(dirname -- "$script_dir")
default_cli_dir="$(dirname "$(dirname -- "$skill_dir")")/clf-cli"
cli_dir="${CLF_CLI_DIR:-$default_cli_dir}"
cli_file="$cli_dir/dist/index.js"

# 1) PATH 中的全局 clf 命令
cli_path="$(resolve_command_cli_path || true)"
if [ -n "$cli_path" ]; then
  exec "$cli_path" "$@"
fi

# 2) 源码目录构建产物 dist/index.js（node 执行）
if [ -f "$cli_file" ]; then
  if ! command -v node >/dev/null 2>&1; then
    fail "node not found in PATH; clf 需要 Node.js >= 18"
  fi
  exec node "$cli_file" "$@"
fi

fail "clf not found. Run sh scripts/cli-state.sh to inspect installation state first."
