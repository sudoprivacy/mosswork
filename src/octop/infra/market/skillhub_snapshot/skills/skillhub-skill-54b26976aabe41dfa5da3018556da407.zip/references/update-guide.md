# clf CLI 手动更新指南

> `clf` 已发布到 CNB npm 制品库（`cailifangshuke/cailifangkehuduan/clfAgent`），
> 更新方式取决于安装来源：npm 制品库安装 → 升级包；源码安装 → 拉取源码。

## 方式一：npm 制品库安装的更新

```bash
npm install -g clf-cli@latest --registry=https://npm.cnb.cool/cailifangshuke/cailifangkehuduan/clfAgent/-/packages/
```

> 若已将制品库设为默认 registry（`npm config set registry ...`），可省略 `--registry` 参数。

## 方式二：源码安装的更新

1. 拉取最新源码：

```bash
cd <clf-cli 目录>
git pull
```

2. 使命令生效：

- **npm link 安装的** → 源码更新即时生效，无需操作
- **`npm install -g .` 安装的** → 重新执行：
  ```bash
  npm install -g .
  ```
- **不经安装直接运行**（`node dist/index.js` / 技能包脚本回退模式）→ 拉取源码后执行 `npm install && npm run build` 即生效

## 验证更新

```bash
clf -V          # 查看版本（需 ≥ 2.1.0 才支持编号加密输出）
clf --help
# 或通过技能包脚本查看版本（npm 安装与源码安装均可）：
powershell scripts/cli-state.ps1 | Select-String current    # Windows
sh scripts/cli-state.sh | grep current                      # macOS / Linux
```

> 编号（`c1.` 前缀）输出与解密功能需 clf-cli **≥ 2.1.0**；低于 2.1.0 时列表 / 详情按旧版明文 ID 行为运行，需先升级。

## 故障排查

- **npm 制品库更新失败（404）** → 确认最新版本已发布；查看已发布版本：
  ```bash
  npm view clf-cli versions --registry=https://npm.cnb.cool/cailifangshuke/cailifangkehuduan/clfAgent/-/packages/
  ```
- **更新后仍显示旧行为** → 确认安装来源与更新方式一致（npm 包 vs 源码）；源码方式检查 `git pull` 成功、无本地冲突（`git status`）
- **接口行为与文档不符** → 接口文档 `财立方客户端.openapi.3.0.json` 与 CLI 为独立演进，
  以 CLI 实际输出为准；如确属 CLI 缺陷，反馈给 clf-cli 维护者
