# clf CLI 手动安装指南

> `clf` 是财立方信息资讯命令行工具（TypeScript + commander 工程，构建产物 `dist/index.js`），
> 已发布到 CNB npm 制品库 `cailifangshuke/cailifangkehuduan/clfAgent`。
> 技能包同级的 `clf-cli/` 目录为源码（需先 `npm run build`），可跳过安装直接运行。

## 环境要求

- Node.js ≥ 18（内置 `fetch`）：`node --version`

## 方式一：从 CNB npm 制品库全局安装（推荐）

```bash
npm install -g clf-cli --registry=https://npm.cnb.cool/cailifangshuke/cailifangkehuduan/clfAgent/-/packages/
```

也可将制品库设为默认 registry 后安装（后续更新无需再带 `--registry`）：

```bash
npm config set registry https://npm.cnb.cool/cailifangshuke/cailifangkehuduan/clfAgent/-/packages/
npm install -g clf-cli
```

安装后可在任意目录使用 `clf` 命令（`clf --help` 验证）。

> 本制品库为 Public，拉取无需认证；私有制品库需在 `~/.npmrc` 配置
> `//npm.cnb.cool/...:_authToken=<访问令牌>` 后安装。

## 方式二：源码安装（开发）

在 `clf-cli` 项目目录执行：

```bash
npm install -g .      # 全局安装为 clf 命令
npm link              # 开发期软链（推荐，源码更新即时生效）
```

## 方式三：不经安装直接运行（源码模式）

```bash
# 先构建（首次或源码更新后）：
cd <clf-cli 路径> && npm install && npm run build
# 再直接运行：
node <clf-cli 路径>/dist/index.js <命令>
```

技能包脚本（`scripts/run-cli.ps1` / `scripts/run-cli.sh`）在未安装时会**自动回退**到
技能包同级的 `clf-cli/dist/index.js`（用 node 执行），因此即使不安装也可正常使用。

## 验证安装

```bash
clf --help
# 或通过技能包脚本：
powershell scripts/run-cli.ps1 hot      # Windows
sh scripts/run-cli.sh hot               # macOS / Linux
```

## 故障排查

- **`clf` 命令找不到** → 确认已执行方式一（`npm install -g clf-cli`）或方式二（`npm install -g .`）；或检查 PATH；或改用方式三直接运行
- **安装时报 404** → 确认 registry 地址正确（使用方式一的完整命令），或确认最新版本已发布到制品库
- **`node` 命令找不到** → 先安装 Node.js ≥ 18 并重新打开终端
- **`未知命令：xxx`** → 运行 `clf --help` 查看可用命令（channel / article / flash / subject / thinktank / mpress / search / token 等 16 个）
- **Windows 执行 .ps1 被拦截（ExecutionPolicy）** → `powershell -ExecutionPolicy Bypass -File scripts/run-cli.ps1 <命令>`
