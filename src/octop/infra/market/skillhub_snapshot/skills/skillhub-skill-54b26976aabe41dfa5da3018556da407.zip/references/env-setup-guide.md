# clf CLI Access-Token 配置指南

## 背景

- 财立方**详情接口**（`clf article detail` 普通文章分支）需要请求头 `Access-Token`；
  列表 / 搜索 / 快讯 / 热搜 / 专题 / 智库 / 融媒体**不需要** token。
- **token 机制**：token 由**用户传入**，CLI **不自动生成、不自动获取**。
  首次使用时执行 `clf token <新令牌>` 保存到 `~/.clf/config.json`，之后所有命令复用；
  或设置环境变量 `CLF_TOKEN`（优先级更高）。
- **编号密钥（clf-cli ≥ 2.1.0）**：编号加密密钥 `idKey` 由 CLI 自动生成，与 token 同存于
  `~/.clf/config.json`（权限 0600）。换机器或清除该文件后，历史编号（`c1.` 前缀）全部失效，
  需重新运行列表命令获取最新编号。

## 查看当前 token

```bash
clf token
# 或通过技能包脚本：
powershell scripts/run-cli.ps1 token     # Windows
sh scripts/run-cli.sh token              # macOS / Linux
```

输出包含当前生效 token、来源（环境变量 / 配置文件 / 未配置）、配置文件路径。

## 设置新 token

```bash
clf token <新令牌>
```

保存到 `~/.clf/config.json`（权限 0600）。`<新令牌>` 为裸值，不加引号。

## 清除已保存 token

```bash
clf token clear
```

清除后需重新 `clf token <新令牌>` 设置，否则详情接口不可用。

## 生效优先级

```
环境变量 CLF_TOKEN > 配置文件 ~/.clf/config.json（clf token <新令牌> 设置保存）
```

- 设置环境变量：`$env:CLF_TOKEN = "..."`（Windows PowerShell）或 `export CLF_TOKEN="..."`（macOS / Linux）
- 若设置了环境变量，配置文件中的 token 不生效
- 未配置 token 时调用详情接口，CLI 报错并引导：`请先运行：clf token <新令牌>`（绝不自动生成）

## 常见问题

- **`-21001 非法参数`（`clf article detail` 时）** → token 缺失或失效：`clf token` 查看 → `clf token <新令牌>` 更新 → 重试
- **`API Key 无效` 类提示** → 确认新 token 本身有效（联系财立方后端 / 管理员）
- **token 设置了但详情仍报错** → 检查是否被环境变量覆盖（环境变量优先），或确认 token 已同步到 `~/.clf/config.json`
