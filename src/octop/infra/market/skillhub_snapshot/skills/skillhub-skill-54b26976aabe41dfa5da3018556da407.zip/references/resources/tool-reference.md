# CLI 命令参数参考

> 财立方客户端全部 16 个 `clf` CLI 命令的完整参数和返回说明。
> 数据源：`财立方客户端.openapi.3.0.json`（接口均为 `POST` JSON，响应 `{ code, info, data }`，`code === 0` 成功）。
>
> 「接口 → CLI 映射」与「分层命令清单」两节由 `clf-cli/src/catalog.json` 自动生成，
> 运行 `node scripts/gen-skill-reference.mjs`（在 clf-cli 目录）重新生成，请勿手改。
>
> ⚠️ 编号约定（数据安全）：返回数据中的编号（原 id 字段，`c1.` 前缀）为加密值，
> 直接复制传给详情 / 翻页命令即可，CLI 自动识别还原；**不得解读、构造或向用户展示明文 ID**。
> 参数名（artid / recid / channelid 等）为接口协议字段名，保持不变。

## 接口 → CLI 映射

<!-- AUTO-GEN:MAPPING:START -->
| 接口 / 配置 | CLI 命令 | 层 |
|------------|---------|-----|
| Access-Token（配置） | `clf token [新令牌]` | [L0] |
| news/channel/all | `clf channel list` | [L0★] |
| news/article/list | `clf article list [--channelid <number>] [--startid <number>] [--pno <number>] [--psize <number>]` | [L1★] |
| v2/news/article/list | `clf article list-v2 <channelid> [--subchanid <number>] [--startid <number>] [--ptime <number>] [--pno <number>] [--psize <number>]` | [L1] |
| news/article/search | `clf article search <keyword> [--pno <number>] [--psize <number>] [--qtype <number>]` | [L1★] |
| news/article/spider | `clf flash list [--pno <number>] [--psize <number>] [--startid <number>]` | [L1] |
| news/subject/article | `clf subject list <subjectid> [--moduleid <number>] [--pno <number>] [--psize <number>] [--start <number>]` | [L1] |
| v2/news/mpress/list | `clf mpress list [--pno <number>] [--psize <number>] [--startid <number>]` | [L1] |
| tools/hotsearch | `clf search hot` | [L1] |
| v2/search/info | `clf search info` | [L1] |
| news/article/detail | `clf article detail <artid> [--qtype <number>]` | [L2★] |
| news/article/spidinfo | `clf flash detail <recid>` | [L2] |
| news/article/spidrelated | `clf flash related <recid>` | [L2] |
| news/thinktanks/detail | `clf thinktank detail <recid>` | [L2] |
| v2/news/mpress/detail | `clf mpress detail <recid>` | [L2] |
| v2/news/mpress/related | `clf mpress related <artid>` | [L2] |
<!-- AUTO-GEN:MAPPING:END -->

一键阅读路径：`clf channel list`（锚定频道）→ `clf article list --channelid <编号>`（列表）→ `clf article detail <编号>`（详情，需 Access-Token）。

## 分层命令清单

<!-- AUTO-GEN:LAYERS:START -->
### L0 配置与发现（2 个）

#### Access-Token（配置） [L0]
- CLI：`clf token [新令牌]`
- 说明：查看 / 设置 / 清除访问令牌（详情接口 news/article/detail 必需；token 由用户传入保存，CLI 不自动生成）
- 参数：
  - `新令牌` (string, 可选) — 设置固定 token 并保存复用（clear 清除配置）；不传则查看当前生效 token

#### news/channel/all [L0★]
- CLI：`clf channel list`
- 说明：获取全部频道列表（含子频道），阅读的第一步：锚定频道

### L1 列表与搜索（8 个）

#### news/article/list [L1★]
- CLI：`clf article list [--channelid <number>] [--startid <number>] [--pno <number>] [--psize <number>]`
- 说明：获取频道文章列表（按栏目分组，含文章编号 / 标题 / 发布时间）
- 参数：
  - `channelid` (number, 可选) — 频道编号（clf channel list 结果中的 [编号]），默认 1（推荐）
  - `startid` (number, 可选) — 起始文章编号 游标，默认 0
  - `pno` (number, 可选) — 页码，默认 1
  - `psize` (number, 可选) — 每页条数，默认 10

#### v2/news/article/list [L1]
- CLI：`clf article list-v2 <channelid> [--subchanid <number>] [--startid <number>] [--ptime <number>] [--pno <number>] [--psize <number>]`
- 说明：v2 版频道文章列表（支持子频道与时间游标，接口需 Client-Info 等头）
- 参数：
  - `channelid` (number, 必填) — 频道编号（clf channel list 结果中的 [编号]）
  - `subchanid` (number, 可选) — 子频道编号
  - `startid` (number, 可选) — 起始文章编号 游标，默认 0
  - `ptime` (number, 可选) — 时间游标（上次列表末尾文章的发布时间），默认 0
  - `pno` (number, 可选) — 页码，默认 1
  - `psize` (number, 可选) — 每页条数，默认 20

#### news/article/search [L1★]
- CLI：`clf article search <keyword> [--pno <number>] [--psize <number>] [--qtype <number>]`
- 说明：按关键词搜索新闻（返回文章编号 / 标题 / 摘要 / 发布时间）
- 参数：
  - `keyword` (string, 必填) — 搜索关键词（如：银行、河南、算力）
  - `pno` (number, 可选) — 页码，默认 1
  - `psize` (number, 可选) — 每页条数，默认 20
  - `qtype` (number, 可选) — 搜索类型，默认 -1（全部）

#### news/article/spider [L1]
- CLI：`clf flash list [--pno <number>] [--psize <number>] [--startid <number>]`
- 说明：获取 7×24h 即时财经快讯列表（短讯、更新快）
- 参数：
  - `pno` (number, 可选) — 页码，默认 1
  - `psize` (number, 可选) — 每页条数，默认 60
  - `startid` (number, 可选) — 起始快讯编号 游标，默认 0

#### news/subject/article [L1]
- CLI：`clf subject list <subjectid> [--moduleid <number>] [--pno <number>] [--psize <number>] [--start <number>]`
- 说明：专题稿件列表（专题聚合长文的稿件清单）
- 参数：
  - `subjectid` (number, 必填) — 专题 编号
  - `moduleid` (number, 可选) — 专题模块编号
  - `pno` (number, 可选) — 页码，默认 1
  - `psize` (number, 可选) — 每页条数，默认 10
  - `start` (number, 可选) — 起始偏移，默认 0

#### v2/news/mpress/list [L1]
- CLI：`clf mpress list [--pno <number>] [--psize <number>] [--startid <number>]`
- 说明：融媒体文章列表（资讯号 / 创作号内容）
- 参数：
  - `pno` (number, 可选) — 页码，默认 1
  - `psize` (number, 可选) — 每页条数，默认 20
  - `startid` (number, 可选) — 起始文章编号 游标

#### tools/hotsearch [L1]
- CLI：`clf search hot`
- 说明：获取热搜词列表（当前热门话题，可用于引导阅读 / 搜索方向）

#### v2/search/info [L1]
- CLI：`clf search info`
- 说明：获取热搜信息（v2，热搜词及热度）

### L2 详情阅读（6 个）

#### news/article/detail [L2★]
- CLI：`clf article detail <artid> [--qtype <number>]`
- 说明：阅读文章详情（需 Access-Token）：标题 / 原文链接 / 摘要 / 正文 / 阅读点赞
- 参数：
  - `artid` (number, 必填) — 文章编号（列表 / 搜索 / 快讯结果中的 [编号]）
  - `qtype` (number, 可选) — 文章类型，默认 0（普通文章）

#### news/article/spidinfo [L2]
- CLI：`clf flash detail <recid>`
- 说明：阅读快讯详情（标题 / 发布时间 / 正文）
- 参数：
  - `recid` (number, 必填) — 快讯编号（快讯列表中的 [编号]）

#### news/article/spidrelated [L2]
- CLI：`clf flash related <recid>`
- 说明：获取相关快讯列表
- 参数：
  - `recid` (number, 必填) — 快讯编号

#### news/thinktanks/detail [L2]
- CLI：`clf thinktank detail <recid>`
- 说明：智库报告详情（财立方智库研报，如豫企研报）
- 参数：
  - `recid` (number, 必填) — 智库报告 编号

#### v2/news/mpress/detail [L2]
- CLI：`clf mpress detail <recid>`
- 说明：融媒体文章详情（正文阅读）
- 参数：
  - `recid` (number, 必填) — 融媒体文章编号

#### v2/news/mpress/related [L2]
- CLI：`clf mpress related <artid>`
- 说明：融媒体文章相关推荐
- 参数：
  - `artid` (number, 必填) — 融媒体文章编号

<!-- AUTO-GEN:LAYERS:END -->

## 环境说明

| 环境 | 地址 | 说明 |
|------|------|------|
| `prod` | `app.dahecube.com/napi/` | 正式环境（默认），列表 / 搜索免 token |
| `pre` | `pre.dahecube.com/art/api/` | 预发环境 |
| `tst` | `tst.dahecube.com/art/api/` | 测试环境 |

切换环境：`clf article list --env tst`、`clf article search 银行 --env pre`。一般无需切换，默认 prod 即可。

## 返回结构速查

> 所有接口统一返回 `{ code, info, data }`：`code=0` 成功（`data` 为业务数据），
> `code=-21001` 非法参数（详情接口 token 缺失/无效或请求体缺字段），其他非 0 为业务错误（看 `info`）。

| CLI 命令 | 返回 `data` 关键字段 |
|----------|----------------------|
| `clf channel list` | 频道数组：`recid`（频道编号）、`chname`（频道名）、`subtitle`、`sublist[]`（子频道：`subchanid` / `chname`） |
| `clf article list` | `items[]` 按栏目分组：栏目 `itemTitle` + `itemData[]`（`recid` / `title` / `pubtime` / `summary`） |
| `clf article list-v2` | v2 版列表（`recid` / `title` / `pubtime` 等） |
| `clf article search` | `items[]`：`recid` / `title` / `content`（摘要）/ `pubtime` |
| `clf article detail` | 普通文章：`title` / `news_url` / `summary` / `content` / `statistics{readcnt,praise}` |
| `clf flash list` | 快讯数组：`recid` / `title` / `content` / `pubtime` |
| `clf flash detail` | 快讯：`title` / `content` / `pubtime` |
| `clf flash related` | 相关快讯数组：`recid` / `title` / `content` / `pubtime` |
| `clf subject list` | `{ pages, items[] }`，每项 `item` 嵌套文章对象（`recid` / `title` / `summary`） |
| `clf thinktank detail` | 智库详情：`title` / `furl`（报告文件地址）/ `introduction` 等 |
| `clf mpress list` | 融媒体文章数组：`recid` / `title` / `pubtime` |
| `clf mpress detail` | 融媒体详情：`title` / `news_url` / `content` / `statistics` |
| `clf mpress related` | 相关推荐数组 |
| `clf search hot` | 热搜词字符串数组 |
| `clf search info` | v2 热搜信息：`recid` / 热搜词 |
| `clf token` | 无接口；查看 / 设置 / 清除 `~/.clf/config.json` 中的 token |

## 关键约束

- **唯一调用路径**：一律通过 `clf` CLI 执行，禁止直接调用 HTTP 接口（详见 `SKILL.md` 全局约束）
- 详情阅读（`clf article detail`）需要 `Access-Token`，其余命令免 token
- **token 机制**：token 由用户传入并保存复用，CLI 不自动生成。设置：`clf token <新令牌>`；查看：`clf token`；清除：`clf token clear`；或设置环境变量 `CLF_TOKEN`（优先级最高）
- 所有列表命令分页：`--pno`（默认 1）/ `--psize`（默认 10 或 20 / 快讯 60）
- 列表 / 搜索结果中的 `[编号]`（`c1.` 前缀加密值）可直接复制用于 `clf article detail <编号>` / `clf flash detail <编号>`；编号不可解读、不可构造
- 时间过滤：`--since <日期>` / `--until <日期>`（按 `pubtime` 客户端过滤，日期为 `YYYY-MM-DD` 或 `YYYY-MM-DD HH:MM`），用于"昨夜今晨 / 当日稿件"场景
- 工具返回空列表时标注「暂无内容」，不视为错误
