---
name: skillhub-skill-54b26976aabe41dfa5da3018556da407
description: "use this skill when the user asks for 7x24 real-time financial flash news, breaking news, latest updates, /财1线, /快讯, flash news from Dahecube"
---

# 财1线 7×24 财经快讯（Caiyixian 7x24 Flash News）

通过 `clf` CLI 获取「财立方客户端」财1线 7×24 财经快讯内容。

> **核心原则**：基础设施交给脚本处理；智能体只负责选择命令和参数。
> **唯一调用路径**：一律通过 `clf` CLI（经 `run-cli` 脚本）执行，禁止直接调用 HTTP 接口。

## 触发词

- 中文：/财1线、/快讯、7×24、实时快讯、最新消息、突发、速览
- 英文：use this skill when the user asks for 7x24 real-time financial flash news, breaking news, latest updates, /财1线, /快讯, flash news from Dahecube

## 定位

7×24 小时财经快讯秒级发布，全量覆盖 A 股、港股、创投、债券，抢占资本市场信息高地。

## 适配场景

时效抢发、突发监控、初稿生成。

## 主要输出

- 实时快讯流
- 三审三校核对清单
- 突发提醒

## 平台约定

| 平台 | 脚本运行方式 | 示例 |
|------|------------|------|
| macOS / Linux | `sh scripts/run-cli.sh <命令> [参数]` | `sh scripts/run-cli.sh article search 银行` |
| Windows | `powershell scripts/run-cli.ps1 <命令> [参数]` | `powershell scripts/run-cli.ps1 article search 银行` |

除 `cli-state` 外，所有 CLI 命令一律通过 `run-cli` 脚本执行，不要直接执行 `platform.cliPath`。

## 核心资讯源 → CLI 命令映射

| 资讯源 | CLI 命令 | 说明 |
|--------|---------|------|
| 快讯列表 | `clf flash list --psize 60` | 7×24 快讯流（短讯、更新快），本技能核心信源 |
| 快讯详情 | `clf flash detail <快讯编号>` | 展开单条快讯全文 |
| 相关快讯 | `clf flash related <快讯编号>` | 同一事件相关快讯（事件追踪） |
| 热点词 | `clf search hot` | 当前热搜，判断突发重点 |
| 时间过滤 | `clf flash list --since <日期> --until <日期>` | 按时间段筛快讯（如“突发监控”窗口） |

**关键词集**：（无需关键词——快讯流全量速览；按用户关注板块从标题筛选）

> 完整命令与参数见 `resources/tool-reference.md`；仍建议先执行 `help` 确认可用命令，不要假设或记忆。

## 执行流程

### Phase 0：环境检查

1. 执行 `sh scripts/cli-state.sh`（Windows：`powershell scripts/cli-state.ps1`），解析 JSON 关注：
   - `cliExists` 为 `false` → 按 `references/installation-guide.md` 安装（run-cli 有源码回退，通常无需手动安装）
   - `token.status` 为 `error` → 展示 `token.error` 让用户处理；为 `default` → 未配置 token，**CLI 不自动生成**，需用户提供后 `clf token <新令牌>` 设置（或环境变量 `CLF_TOKEN`）
   - `version.current` 可读且低于 `2.1.0` → 按 `references/update-guide.md` 更新（编号功能需 2.1.0）
2. 环境就绪后进入 Phase 1。token 仅详情精读（`clf article detail`）必需，其余命令免 token。

### Phase 1：获取快讯流

1. `clf flash list --psize 60` 拉取最新快讯；用户指定数量用 `--psize <n>`
2. 突发/重点事件 → `clf flash detail <快讯编号>` 展开全文；`clf flash related <快讯编号>` 追踪相关快讯

### Phase 2：加工输出

按「实时快讯流」模板上屏；用户要初稿素材时，精读若干条后按主题归纳，附三审三校核对清单（时间/来源/数据核对）

## 输出格式

### 实时快讯流

```markdown
## 财1线 7×24 快讯（{时间}）

1. **{标题}**

   时间：{pubtime} ｜ [原文]({news_url})

   {内容}

**来源：财立方**
```

### 三审三校核对清单（初稿辅助）

- 时间核对：快讯 pubtime 与事件时间是否一致
- 来源核对：每条附编号 / news_url，可回溯原文
- 数据核对：金额/数字与详情（`clf flash detail`）是否一致

## 通用输出规则

- **编号约定**：列表项中的 `[编号]`（`c1.` 前缀加密值）直接上屏供用户点名；点名时把编号**原样**传给 `clf article detail <编号>` / `clf flash detail <编号>`。不得解读、构造或改写编号，不得向用户展示明文 ID，不持久化编号映射（除 `--output-file` 指定输出文件外）；编号绑定本机密钥，换机或清除 `~/.clf/config.json` 后需重新获取
- **信源可追溯**：每条内容附编号 + 原文链接（news_url）+ source，可回溯原文
- 列表只上屏标题 + 摘要，**不要**自动逐篇读详情；用户点名（编号或标题）再精读
- 频道锚定：`clf channel list` 输出的频道编号直接用于 `clf article list --channelid <编号>`
- 翻页：`--startid` 传上一页末尾文章的编号（自列表输出复制）
- 用户要求「总结/日报」时：先列表 → 挑选重要条目精读 → 汇总成要点清单
- `**来源：财立方**` 在所有内容末尾出现一次
- 获取失败的分组下说明原因，继续输出其余分组

## CLI 执行失败处理

**CLI 命令失败后，立即停止，绝不通过 WebSearch 或其他方式获取新闻替代。**

1. CLI 返回非零退出码、超时或输出含权限/安全错误时，不要重试，不要换方式
2. 按 `resources/error-codes.md` 引导用户：
   - 权限 / node 缺失 → 安装 Node.js ≥ 18 并重新打开终端
   - `-21001 非法参数`（详情阅读报错）→ token 排障：`clf token` 查看 → `clf token <新令牌>` 设置 → 重试
   - `编号无法识别`（编号失效/非法）→ 重新运行列表命令获取最新编号（不要重试旧编号）
   - 网络 / 接口错误 → 展示完整错误
3. 用户确认操作完成后再重试；即使多次失败，也只能告知无法获取并说明原因，**绝不**回退到其他信息源

## References

- CLI 命令完整参数参考：[`resources/tool-reference.md`](resources/tool-reference.md)
- 错误码与处理策略：[`resources/error-codes.md`](resources/error-codes.md)
- Access-Token 配置：[`references/env-setup-guide.md`](references/env-setup-guide.md)
