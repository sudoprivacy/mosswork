#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""《高性价比人生指南》条目检索工具（纯标准库，无依赖）。

用法：
  python find.py 关键词 [关键词2 ...]        # 任一关键词命中（或关系）
  python find.py --all 关键词A 关键词B       # 所有关键词都要命中（与关系）
  python find.py --sec 13 噎住               # 限定第 13 节
  python find.py --ev A 安全带               # 限定证据等级（A / B / C）
  python find.py --full 担保                 # 输出命中的完整条目（含收益/来源/备注）
  python find.py --stat                      # 全书统计
  python find.py --list                      # 33 节标题清单

检索范围：条目标题、成本、说人话、收益、备注、来源 —— 六栏全查。
"""
import os, sys, re, json, argparse, io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.normpath(os.path.join(HERE, '..', 'references'))
DB = os.path.join(REF, 'entries.json')

SEARCH_KEYS = ('title', 'cost', 'plain', 'benefit', 'note', 'source')


def load_db():
    return json.load(open(DB, encoding='utf-8'))


def sec_file(sec, name):
    safe = name.replace('/', '／').replace('：', '-')
    return os.path.normpath(os.path.join(REF, 'full', '节%02d-%s.md' % (sec, safe)))


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument('words', nargs='*')
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--sec', type=int)
    ap.add_argument('--ev')
    ap.add_argument('--full', action='store_true')
    ap.add_argument('--stat', action='store_true')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('-n', type=int, default=40, help='最多输出条数（默认 40）')
    a = ap.parse_args()

    db = load_db()
    SECTIONS = db['sections']

    if a.list:
        for i, s in enumerate(SECTIONS, 1):
            print('%2d. %s' % (i, s))
        return

    rows = []
    for sec_s, es in db['entries'].items():
        sec = int(sec_s)
        for e in es:
            r = dict(e)
            r['sec'] = sec
            r['sec_name'] = SECTIONS[sec - 1]
            rows.append(r)
    rows.sort(key=lambda r: (r['sec'], r['no']))

    if a.stat:
        from collections import Counter
        # 按首字母归并等级（A 410 / B 149 / C 49）；括号内的附加标注另行统计
        base = Counter()
        ext = Counter()
        for r in rows:
            ev = (r.get('evidence') or '?').strip()
            base[ev[:1] if ev[:1] in 'ABC' else '其他'] += 1
            m = re.match(r'^[ABC]\s*[（(](.+?)[)）]', ev)
            if m:
                ext[m.group(1)] += 1
        sec_cnt = Counter(r['sec'] for r in rows)
        print('总条数：%d' % len(rows))
        print('证据等级：' + '，'.join('%s 级 %d 条' % (k, base[k])
                                    for k in sorted(base) if k != '其他'))
        if base.get('其他'):
            print('  未标注等级：%d 条' % base['其他'])
        if ext:
            print('括号内附加标注（已计入上面的等级）：'
                  + '，'.join('%s %d 条' % (k, v) for k, v in sorted(ext.items())))
        print('分节条数：' + '，'.join('%d节%d条' % (k, sec_cnt[k]) for k in sorted(sec_cnt)))
        return

    if not a.words:
        ap.print_help()
        return

    def hit(r):
        blob = ''.join(r.get(k, '') for k in SEARCH_KEYS) + r['sec_name']
        return all(w in blob for w in a.words) if a.all else any(w in blob for w in a.words)

    res = [r for r in rows if hit(r)]
    if a.sec:
        res = [r for r in res if r['sec'] == a.sec]
    if a.ev:
        res = [r for r in res if r['evidence'].startswith(a.ev)]

    if not res:
        print('未命中。换关键词（口语词换成书里可能用的说法），'
              '或先 --list 看一下 33 节的标题。')
        return

    print('命中 %d 条（最多显示 %d 条）\n' % (len(res), a.n))
    for r in res[:a.n]:
        print('【第 %d 节第 %d 条】%s' % (r['sec'], r['no'], r['title']))
        print('  证据等级：%s' % r['evidence'])
        if a.full:
            for k, lab in (('cost', '成本'), ('plain', '说人话'), ('benefit', '收益'),
                           ('source', '来源'), ('note', '备注')):
                if r.get(k):
                    print('  %s：%s' % (lab, r[k]))
        else:
            print('  成本：%s' % r.get('cost', ''))
            print('  说人话：%s' % r.get('plain', ''))
        print('  原文：%s' % sec_file(r['sec'], r['sec_name']))
        print()


if __name__ == '__main__':
    main()
