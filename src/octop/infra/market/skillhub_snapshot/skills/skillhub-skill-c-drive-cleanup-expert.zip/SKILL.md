---
name: skillhub-skill-c-drive-cleanup-expert
description: "Windows C盘磁盘清理专家技能（C盘清理专家）。提供C盘空间分析、垃圾文件识别、安全清理建议、AppData深度扫描等工作流。当用户需要分析C盘空间占用、清理垃圾文件、释放磁盘空间、定位大文件或大文件夹时使用。支持三级安全分类（绿色/黄色/红色）指导清理决策。"
---

# C盘清理专家

## 概述

本技能提供 Windows C 盘空间分析与清理的完整工作流，包括空间扫描、垃圾文件目录参考、安全清理方案和深度分析脚本。核心目标是帮助用户安全地释放 C 盘空间，同时标注每项操作的风险等级。

## 何时使用

当用户请求涉及以下任何一项时触发本技能：
- "分析 C 盘空间" / "C 盘满了" / "C 盘空间不足"
- "清理 C 盘垃圾" / "释放 C 盘空间"
- "C 盘哪些文件最占空间"
- "AppData 为什么这么大"
- "Windows 磁盘清理"
- "找出 C 盘大文件"

## 工作流决策树

```
用户请求 C 盘清理
    |
    v
空间分析？ ──是──> 扫描 C 盘目录 + 生成占用排行报告
    | 否
    v
垃圾清理？ ──是──> 按安全等级分类 -> 绿色可直接清理 -> 黄色需确认 -> 红色不推荐
    | 否
    v
大文件定位？ ──是──> 扫描 Top 20/50 大文件 + 列出路径和大小
    | 否
    v
AppData 深度分析？ ──是──> 扫描 Local + Roaming 子目录 + 标记可清理项
```

## 核心任务

### 任务一：C 盘空间分析

获取 C 盘总容量和可用空间：
```powershell
$drive = Get-PSDrive C
$usedGB = [math]::Round($drive.Used / 1GB, 2)
$freeGB = [math]::Round($drive.Free / 1GB, 2)
$totalGB = [math]::Round(($drive.Used + $drive.Free) / 1GB, 2)
$pct = [math]::Round($drive.Used / ($drive.Used + $drive.Free) * 100, 1)
"Total: ${totalGB} GB | Used: ${usedGB} GB (${pct}%) | Free: ${freeGB} GB"
```

扫描 C 盘一级目录大小（PowerShell，需管理员权限扫描部分系统目录）：
```powershell
Get-ChildItem -Path C:\ -Directory -Force | ForEach-Object {
    $size = (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue |
             Measure-Object -Property Length -Sum).Sum
    [PSCustomObject]@{
        Directory = $_.FullName
        SizeGB = [math]::Round($size / 1GB, 2)
        SizeMB = [math]::Round($size / 1MB, 0)
    }
} | Sort-Object SizeMB -Descending
```

扫描用户目录各子文件夹大小：
```powershell
Get-ChildItem -Path "$env:USERPROFILE" -Directory -Force | ForEach-Object {
    $size = (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue |
             Measure-Object -Property Length -Sum).Sum
    [PSCustomObject]@{ Folder = $_.Name; SizeGB = [math]::Round($size / 1GB, 2) }
} | Sort-Object SizeGB -Descending
```

**Python 深度扫描（推荐，速度更快）：**
当 PowerShell 扫描大目录超时或缓慢时，使用 Python 脚本代替。纯只读扫描不触发任何安全限制。参考 `references/junk-file-catalog.md` 中的扫描示例。

### 任务二：垃圾文件识别与清理

详见 `references/junk-file-catalog.md`，包含 20+ 类垃圾文件的完整目录参考、用途说明和安全等级。

**安全清理等级定义：**
- **绿色**：可直接清理，不影响系统功能
- **黄色**：需确认后清理，影响部分功能但可恢复
- **红色**：不建议手动清理，可能导致系统故障

**安全清理原则（必须遵守）：**
1. 优先使用系统回收站接口，避免永久性清除
2. 清理前先备份重要数据
3. 每一类清理操作前向用户说明影响并征得确认
4. 不使用递归强制方式处理个人目录，不使用通配符批量处理系统目录
5. 若执行环境禁止删除操作，则生成可执行的清理脚本交付用户手工运行

**常用绿色清理项（执行时按上述原则生成对应命令）：**
- 用户临时文件：清理 `%TEMP%` 目录内容（优先移入回收站）
- npm 缓存：运行 npm 官方缓存清理命令
- pip 缓存：运行 pip 官方缓存清理命令
- DNS 缓存：刷新 DNS 解析缓存
- 回收站：通过系统「清空回收站」功能

**需管理员权限的清理项（仅描述，执行时由 AI 生成对应官方命令）：**
- 关闭休眠：通过「电源选项 → 选择电源按钮的功能 → 更改当前不可用的设置」关闭，可释放与内存大小相当的休眠文件
- 组件清理：使用「磁盘清理 → 清理系统文件」或系统官方组件清理命令
- Windows 更新缓存：先暂停更新服务，清理下载目录，再恢复服务

### 任务三：查找大文件

查找 C 盘最大的 20 个文件：
```powershell
Get-ChildItem -Path C:\ -Recurse -File -Force -ErrorAction SilentlyContinue |
    Sort-Object Length -Descending |
    Select-Object -First 20 |
    Select-Object @{N='SizeMB';E={[math]::Round($_.Length/1MB,2)}}, @{N='SizeGB';E={[math]::Round($_.Length/1GB,2)}}, FullName |
    Format-Table -AutoSize
```

### 任务四：AppData 深度分析

AppData 通常占用数十 GB，需单独深入分析。扫描 `Local` 和 `Roaming` 子目录：

```powershell
# Local 子目录 (>100MB)
Get-ChildItem -Path "$env:LOCALAPPDATA" -Directory -Force | ForEach-Object {
    $size = (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue |
             Measure-Object -Property Length -Sum).Sum
    if ($size -gt 100MB) { [PSCustomObject]@{ Name=$_.Name; SizeGB=[math]::Round($size/1GB,2) } }
} | Sort-Object SizeGB -Descending

# Roaming 子目录 (>100MB)
Get-ChildItem -Path "$env:APPDATA" -Directory -Force | ForEach-Object {
    $size = (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue |
             Measure-Object -Property Length -Sum).Sum
    if ($size -gt 100MB) { [PSCustomObject]@{ Name=$_.Name; SizeGB=[math]::Round($size/1GB,2) } }
} | Sort-Object SizeGB -Descending
```

**常见 AppData 大目录和清理建议：**

| 目录 | 常见大小 | 说明 | 清理建议 |
|------|----------|------|----------|
| `Local\Google\Chrome\User Data\Default\Service Worker` | 1-3 GB | Chrome 离线缓存 | 可在 Chrome 设置中清除 |
| `Local\Temp` | 1-5 GB | 用户临时文件 | 绿色，可直接清理 |
| `Roaming\Tencent\WeChat` | 2-6 GB | 微信聊天记录和缓存 | 红色，不建议清理（聊天记录） |
| `Roaming\Tencent\QQ` | 1-3 GB | QQ 数据和缓存 | 部分缓存可清理 |
| `Roaming\kingsoft\wps` | 2-5 GB | WPS 文档和模板 | 红色，包含用户文档 |
| `Local\npm-cache` | 0.5-2 GB | npm 包缓存 | 绿色，npm 官方命令清理 |
| `Local\pip\Cache` | 0.2-1 GB | pip 包缓存 | 绿色，pip 官方命令清理 |
| `Local\Microsoft\Windows\Explorer` | 0.5-2 GB | 缩略图缓存 | 黄色，重启后会重建 |
| `Local\go-build` | 0.1-0.5 GB | Go 编译缓存 | 绿色，可直接清理 |

## 清理方案生成

当执行环境无法直接清理时，生成 PowerShell 清理脚本交付用户手工执行：

```powershell
# 示例脚本结构（用于 C_Drive_Green_Cleanup.ps1）
# 1. 记录清理前临时目录占用
# 2. 对临时目录内容执行清理（按安全原则，优先移入回收站）
# 3. 记录清理后占用，输出释放空间
# 4. 每类操作前输出说明文字，等待用户确认
```

## 安全注意事项

1. **绝不**递归处理 `C:\Windows`、`C:\Program Files` 等系统目录
2. **绝不**使用通配符强制方式处理个人目录
3. 清理前务必备份重要数据
4. `C:\Windows\WinSxS` 组件库看似很大，但它是 Windows 系统的核心组件，不可手动处理
5. `C:\Windows\Installer` 存储安装包缓存，处理后会导致软件无法卸载/修复
6. 休眠文件关闭后无法使用休眠功能，需权衡

## 参考文档

- `references/junk-file-catalog.md` — Windows 垃圾文件完整目录参考（28 类文件，含路径、说明、安全等级）

## 版本历史

- v1.0.0 — 初始版本，包含空间分析、垃圾识别、安全清理、AppData 深度扫描四大任务
