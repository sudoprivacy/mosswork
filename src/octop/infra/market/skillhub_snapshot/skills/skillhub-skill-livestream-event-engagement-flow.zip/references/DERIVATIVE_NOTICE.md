# 衍生版本说明

- 原项目：[gtmagents/gtm-agents](https://github.com/gtmagents/gtm-agents)
- 原文件：`plugins/webinar-automation/skills/webinar-design/SKILL.md`
- 原始能力名：`webinar-design`
- 固定提交：`78e0419f4440bcb43bc80127e174ecf5adef1753`
- 原文件哈希：`14b1c3adcac104f3329c2f281f7da71b23588c7ed3029b8fa9f74ead5229e4a2`
- 许可证：`Apache-2.0`，全文见 `LICENSE.md`
- 新对象：`livestream-event-engagement-flow`
- 中文名称：直播主题活动互动环节与流程卡｜简诗 AI

本版本不是对上游名称的逐词翻译。它重新限定了中国业务对象、操作过程、证据要求、交付模板和国内示例，并保留上游来源、作者版权与许可证义务。任何真实发布、发送、付费、权限或生产操作仍需用户明确授权。
