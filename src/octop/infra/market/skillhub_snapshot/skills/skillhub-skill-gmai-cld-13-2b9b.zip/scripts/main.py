# -*- coding: utf-8 -*-
"""云服务表单收集方案卡（gmai-cld-13-2b9b）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：云服务表单收集方案卡方案卡（数据库/存储/LLM三件套选型）；实施步骤SOP（含RLS行级安全配置）；上线验收与用量测算表
建议输入（专业字段）：目标系统；审计范围；授权确认
"""
# === HUBFIX 友好错误处理（自动注入，勿删） ===
import sys as _hubfix_sys, os as _hubfix_os


def _hubfix_hook(_t, _v, _tb):
    """把底层异常翻译成用户能看懂的中文提示，并给出下一步动作。"""
    _m = str(_v) or _v.__class__.__name__
    _low = _m.lower()
    if isinstance(_v, FileNotFoundError) or "no such file" in _low:
        print("\n❌ 输入文件不存在：%s" % _m)
        print("   → 请检查文件路径是否正确、文件是否已被移动或删除，然后重新运行。")
    elif isinstance(_v, PermissionError):
        print("\n❌ 文件无访问权限：%s" % _m)
        print("   → 请关闭正在占用该文件的程序（如播放器/编辑器），或换一个有写入权限的输出目录。")
    elif isinstance(_v, ModuleNotFoundError) or "no module named" in _low:
        print("\n❌ 缺少依赖模块：%s" % _m)
        print("   → 请先在技能目录执行：pip install -r requirements.txt")
    elif "ffmpeg" in _low:
        print("\n❌ 未找到 ffmpeg（音视频处理依赖）：%s" % _m)
        print("   → 请先安装 ffmpeg 并把 ffmpeg.exe 所在目录加入系统 PATH，然后重新运行。")
    elif isinstance(_v, (ValueError, KeyError, TypeError)):
        print("\n❌ 输入内容或参数格式不受支持：%s" % _m)
        print("   → 请核对输入文件格式与字段是否符合「输入要求」；不确定时可先用 demo 示例文件试跑。")
    elif isinstance(_v, KeyboardInterrupt):
        print("\n⚠️ 已手动中断，未产生结果文件。")
    else:
        print("\n❌ 运行失败：%s" % _m)
        print("   → 常见原因是输入格式不受支持、依赖缺失或磁盘写入受限；"
              "可加 --help 查看用法，仍失败请附本段提示反馈。")
    _hubfix_sys.exit(2)


_hubfix_sys.excepthook = _hubfix_hook


def _hubfix_argerr(_self, _msg):
    """把 argparse 的英文用法报错也翻译成中文提示。"""
    print("\n❌ 参数有误：%s" % _msg)
    print("   → 请按上方用法（usage）补齐参数；不确定时执行 --help 查看全部参数说明。")
    _hubfix_sys.exit(2)


try:
    import argparse as _hubfix_argparse
    _hubfix_argparse.ArgumentParser.error = _hubfix_argerr
except Exception:
    pass
# === HUBFIX 友好错误处理结束 ===

import json, os, re, sys, time

SLUG = "gmai-cld-13-2b9b"
TITLE = "云服务表单收集方案卡"
PRICE_FEN = 1490
CATEGORY = "工具与云服务"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['目标系统', True, ['系统', '对象系统', '审计对象'], '明确受审系统与业务承载关系'], ['审计范围', True, ['范围', '边界', '审计边界'], '范围不清的审计结论不具效力'], ['授权确认', True, ['授权', '授权文件', '许可'], '无书面授权不得展开任何探测动作'], ['版本/环境', False, ['版本', '环境', '配置版本'], '记录版本以便复现与比对'], ['配置样本', False, ['配置', '配置片段', '样本'], '基线核对的实际依据'], ['已知问题', False, ['已知缺陷', '历史问题'], '复测时需逐项确认状态']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'finds': [['管理接口对公网开放', '高', '外网可达的管理端口，缺少来源限制', '管理面暴露，凭据泄露即可被控制', '限制来源 IP 或改走内网/跳板访问'], ['TLS 允许弱协议与弱套件', '中', '协商可回落至低版本协议', '传输数据存在被降级风险', '禁用低版本协议与弱算法，仅保留现代套件'], ['特权账号未启用多因素认证', '高', '关键账号仅口令认证', '口令泄露即等同于系统失陷', '对特权账号强制多因素认证'], ['审计日志留存不足', '中', '关键操作日志未集中收集', '事件发生后无法回溯', '集中采集并满足留存期限要求'], ['镜像基础版本存在已知高危漏洞', '严重', '基础镜像版本落后多个补丁周期', '可被已知漏洞直接利用', '升级基础镜像并重建工作负载'], ['备份未做过恢复演练', '中', '仅有备份任务记录，无恢复验证', '真实故障时无法确认可恢复', '每季度做一次恢复演练并留档']]}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['agent-browser 使用口径：用 exe 全路径直接调用；登录态用 --session-name 持久化，不重启 daemon', '爬取合规：遵守 robots 协议、频控≥5秒/页、不采集个人隐私字段、公开数据仅限自用分析', '定时任务幂等：同批数据重复执行不产生重复记录；失败重试须带任务标识', '资料库结构：目录-视图-权限-分享四层；看板字段口径先行', '云服务三件套：数据库（RLS 行级安全）/ 文件存储 / LLM API，密钥不入前端代码', '登录态安全：Cookie/Token 不落明文日志，过期先刷新再重试']
# 自检项（输入完备度）
CHECKS = [['云服务表单收集方案·环境与权限', ['云服务表单收集方案', 'RLS'], '先核对执行环境、登录态与最小权限'], ['云服务表单收集方案·执行与留痕', ['RLS', '安全要点'], '步骤化执行并留痕（日志/截图/落表）'], ['云服务表单收集方案·频控与合规', ['云服务表单收集方案', '上线验收'], '频控、robots与隐私字段红线逐项核对'], ['云服务表单收集方案·异常与重试', ['安全要点', '云服务表单收集方案卡'], '失败重试幂等与告警路径明确'], ['云服务表单收集方案·诚信红线', ['爬取隐私', '绕过鉴权'], '不得抓取个人隐私或绕过鉴权，命中即终止']]
# 交付物构成
DELIVERABLES = ['云服务表单收集方案卡方案卡（数据库/存储/LLM三件套选型）', '实施步骤SOP（含RLS行级安全配置）', '上线验收与用量测算表']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """技术审计交付物：范围授权 → 资产与基线 → 发现清单 → 优先级与验证 → 加固建议 → 复测"""
    P = ctx["spec"]["params"]; L = []
    sysname = ctx["fv"]("目标系统") or ctx["spec"]["title"]
    scope = ctx["fv"]("审计范围")
    auth = ctx["fv"]("授权确认")
    ver = ctx["fv"]("版本/环境")
    sample = ctx["fv"]("配置样本")
    known = ctx["fv"]("已知问题")
    finds = P.get("finds") or []         # [[发现, 严重度, 证据要点, 影响, 修复动作], ...]
    sev = {"严重": 0, "高": 0, "中": 0, "低": 0}
    for f in finds:
        if f[1] in sev:
            sev[f[1]] += 1

    L.append(("一、审计范围与授权确认", [
        "- 目标系统：%s" % brief(sysname, 50),
        "- 版本/环境：%s" % (brief(ver, 40) or "（未提供，须记录版本以便复现）"),
        "- 审计范围：%s" % (brief(scope, 60) or "（未提供，未界定范围的审计结论不具效力）"),
        "- 授权确认：%s" % (brief(auth, 40) or "（未提供，须先取得书面授权；无授权不展开任何探测动作）"),
        "",
        "> 审计只覆盖上述授权范围内的资产；范围外系统不在本次结论之内。",
    ]))

    _bl = [
        "| 核对项 | 基线要求 | 本次情况 | 结论 |", "|---|---|---|---|",
        "| 身份与权限 | 最小权限、特权账号受控、无共享账号 | %s | 待核实 |" % (brief(sample, 24) or "待补充"),
        "| 网络暴露面 | 仅开放必要端口，管理口不对外 | 待核实 | 待核实 |",
        "| 传输与存储加密 | 传输启用强套件，静态数据加密 | 待核实 | 待核实 |",
        "| 日志与留存 | 关键操作可审计、留存满足要求 | 待核实 | 待核实 |",
        "| 补丁与版本 | 无已知高危未修复版本 | %s | 待核实 |" % (brief(ver, 20) or "待补充"),
        "| 备份与恢复 | 定期备份并有恢复演练记录 | 待核实 | 待核实 |",
    ]
    if P.get("tools"):
        _bl += ["", "**只读核查命令示例**（请在授权环境执行，不改变系统状态）：", "", P["tools"]]
    L.append(("二、资产与配置基线核对", _bl))

    rows = ["| 编号 | 发现 | 严重度 | 证据要点 | 影响 | 修复动作 |", "|---|---|---|---|---|---|"]
    for i, f in enumerate(finds, 1):
        rows.append("| F%02d | %s | %s | %s | %s | %s |" % (i, f[0], f[1], f[2], f[3], f[4]))
    if not finds:
        rows.append("| F01 | 待按核对项展开 | 高 | 需提供配置样本与版本信息 | 无法评估 | 补充输入后重跑 |")
    L.append(("三、发现清单", rows))

    pri = ["| 优先级 | 范围 | 处理时限 | 验证方式 |", "|---|---|---|---|"]
    if sev["严重"]:
        pri.append("| P0 | 严重 %d 项 | 立即 | 修复后复测并留存证据 |" % sev["严重"])
    if sev["高"]:
        pri.append("| P1 | 高 %d 项 | 7 天内 | 复测 + 配置基线比对 |" % sev["高"])
    if sev["中"]:
        pri.append("| P2 | 中 %d 项 | 30 天内 | 抽样复核 |" % sev["中"])
    if sev["低"]:
        pri.append("| P3 | 低 %d 项 | 纳入版本迭代 | 例行巡检 |" % sev["低"])
    if len(pri) == 2:
        pri.append("| P1 | 待定级 | 补充证据后定级 | 复测 |")
    pri.append("| — | 排序依据 | 严重度 × 可达性（CVSS 基础分结合网络可达路径），可达性高的先修 | — |")
    L.append(("四、修复优先级与验证", pri))

    L.append(("五、加固建议", [
        "| 层面 | 建议动作 | 校验方式 |", "|---|---|---|",
        "| 访问控制 | 收敛权限至最小必要，特权操作双人复核并留痕 | 权限清单与实际比对 |",
        "| 网络 | 默认拒绝入站，仅放行必要端口；管理面隔离 | 策略与实测端口比对 |",
        "| 传输/存储 | 启用强加密套件，禁用弱协议与弱算法 | 扫描器与手工验证 |",
        "| 审计 | 关键操作日志集中收集，留存满足要求 | 抽样回溯一条操作链 |",
        "| 补丁 | 建立高危补丁 SLA（如 7 天内） | 版本台账与实际情况比对 |",
        "| 备份 | 定期恢复演练并留档 | 演练记录 |",
    ]))

    L.append(("六、复测与回归", [
        "- 复测范围：全部 P0/P1 项 + 受影响配置项回归。",
        "- 复测方式：同一工具与同一判定标准，出具前后对比证据。",
        "- 回归风险：加固可能影响业务，须在变更窗口执行并准备回滚步骤。",
        "- 已知问题（%s）应在复测时逐项确认状态。" % (brief(known, 40) or "未提供"),
        "",
        "> 本报告仅在授权范围内有效；修复与加固须在变更窗口内执行并留存前后对比证据，未获授权不得对生产系统实施变更或开展漏洞利用验证。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    # HUBFIX 主流程包裹
    try:
        main()
    except SystemExit:
        raise
    except Exception as _hubfix_err:
        _hubfix_hook(type(_hubfix_err), _hubfix_err, None)
