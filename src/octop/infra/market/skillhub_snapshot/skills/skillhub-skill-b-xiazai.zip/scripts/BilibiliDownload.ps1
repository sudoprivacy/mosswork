# 批量下载 B站合集/收藏夹/UP主视频 (BBDown 封装)
# 用法:
#   powershell -ExecutionPolicy Bypass -File BilibiliDownload.ps1 -Url "<链接>" -SaveDir "<目录>"
# 默认把视频存到桌面 Bilibili_Collection，BBDown.exe / ffmpeg.exe 默认在桌面。
param(
    [string]$Url     = "PASTE_URL_HERE",
    [string]$SaveDir = "$env:USERPROFILE\Desktop\Bilibili_Collection",
    [string]$BBDown  = "$env:USERPROFILE\Desktop\BBDown.exe",
    [string]$FFmpeg  = "$env:USERPROFILE\Desktop\ffmpeg.exe"
)

if (-not (Test-Path $BBDown)) {
    Write-Error "BBDown.exe 不存在: $BBDown  (请先用 get_bbdown.py 下载)"
    exit 1
}
if (-not (Test-Path $FFmpeg)) {
    Write-Warning "ffmpeg.exe 不存在, 混流可能失败, 请先放置 ffmpeg.exe 或用 --ffmpeg-path 指定"
}
New-Item -ItemType Directory -Force -Path $SaveDir | Out-Null

Write-Host "开始下载: $Url  ->  $SaveDir"
# -p ALL 下载全部分P；封面默认会下；未登录最高 480P。
& $BBDown $Url --work-dir $SaveDir -p ALL --ffmpeg-path $FFmpeg
