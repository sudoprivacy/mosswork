#!/usr/bin/env python3
"""下载 ffmpeg 单文件 (Windows) 到本地，供 BBDown 混流使用。
经 ghproxy.net 镜像访问 GitHub releases，规避国内直连超时。
"""
import sys
import os
import io
import zipfile
import urllib.request

PROXY = "https://ghproxy.net/https://github.com"
REPO = "BtbN/FFmpeg-Builds"
# 选用 win64 gpl 共享版（含 ffmpeg.exe）
DEFAULT_ASSET = "ffmpeg-master-latest-win64-gpl.zip"
DEFAULT_OUT = os.path.join(os.path.expanduser("~"), "Desktop")


def http_get(url, binary=False, timeout=240):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read() if binary else r.read().decode("utf-8", "ignore")


def find_asset():
    try:
        api = f"https://ghproxy.net/https://api.github.com/repos/{REPO}/releases/latest"
        data = http_get(api, timeout=60)
        import json
        rel = json.loads(data)
        for a in rel.get("assets", []):
            n = a["name"]
            if n.endswith(".zip") and "win64" in n and "gpl" in n and "shared" not in n:
                return f"https://ghproxy.net/{a['browser_download_url']}"
    except Exception as e:
        print("解析 latest release 失败, 回退硬编码:", e)
    return f"{PROXY}/{REPO}/releases/download/latest/{DEFAULT_ASSET}"


def main():
    out = DEFAULT_OUT
    if len(sys.argv) > 1:
        out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    asset = find_asset()
    print("下载资产:", asset)
    data = http_get(asset, binary=True, timeout=300)
    print("下载完成, 字节数:", len(data))
    z = zipfile.ZipFile(io.BytesIO(data))
    # BtbN 包结构: ffmpeg-master-latest-win64-gpl/bin/ffmpeg.exe
    name = next((n for n in z.namelist() if n.endswith("bin/ffmpeg.exe")), None)
    if not name:
        name = next((n for n in z.namelist() if n.lower().endswith("ffmpeg.exe")), None)
    if not name:
        z.extractall(out)
        print("未定位到 ffmpeg.exe，已解压全部内容到:", out)
        return
    with open(os.path.join(out, "ffmpeg.exe"), "wb") as f:
        f.write(z.read(name))
    print("已写出:", os.path.join(out, "ffmpeg.exe"))


if __name__ == "__main__":
    main()
