#!/usr/bin/env python3
"""带断点续传 + 自动重试的下载器（严格按 Content-Length / Content-Range 校验）。
经 ghproxy.net 镜像访问 GitHub releases。
用法:
  python dl_resume.py <asset_url> <output_path> [--retries 10] [--chunk 1MB]
"""
import sys
import os
import time
import urllib.request

UA = "Mozilla/5.0"


def head_size(url, timeout=30):
    try:
        req = urllib.request.Request(url, headers=UA, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            cl = r.headers.get("Content-Length")
            return int(cl) if cl else None
    except Exception:
        return None


def download(url, out_path, retries=10, chunk=1024 * 1024):
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    total = head_size(url)
    if total:
        print(f"  目标大小: {total/1e6:.2f} MB")
    for attempt in range(1, retries + 1):
        existing = os.path.getsize(out_path) if os.path.exists(out_path) else 0
        headers = {"User-Agent": UA}
        if existing > 0 and total and existing < total:
            headers["Range"] = f"bytes={existing}-"
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=60) as r:
                status = r.status
                if status == 206:
                    mode = "ab"
                else:
                    # 服务器忽略 Range 返回整文件 -> 从头重写
                    mode = "wb"
                    existing = 0
                written = existing
                with open(out_path, mode) as f:
                    while True:
                        buf = r.read(chunk)
                        if not buf:
                            break
                        f.write(buf)
                        written += len(buf)
                print(f"  [try {attempt}] 已落盘 {written/1e6:.2f} MB")
                if total and written < total:
                    print(f"  未下满，剩余 { (total-written)/1e6:.2f} MB，续传")
                    continue
                if total and written > total:
                    # 多写了（代理返回整文件且我们误判），截断重来
                    os.truncate(out_path, total)
                    print("  超出预期，已截断至目标大小")
                print(f"完成: {out_path} ({os.path.getsize(out_path)/1e6:.2f} MB)")
                return True
        except Exception as e:
            print(f"  [try {attempt}/{retries}] 出错: {e}")
            time.sleep(2)
    print("下载失败，已达最大重试次数")
    return False


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("usage: python dl_resume.py <url> <out> [--retries N]")
        sys.exit(1)
    url, out = sys.argv[1], sys.argv[2]
    retries = 10
    if "--retries" in sys.argv:
        retries = int(sys.argv[sys.argv.index("--retries") + 1])
    ok = download(url, out, retries=retries)
    sys.exit(0 if ok else 1)
