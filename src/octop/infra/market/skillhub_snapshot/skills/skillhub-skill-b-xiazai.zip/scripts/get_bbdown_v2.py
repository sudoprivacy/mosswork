#!/usr/bin/env python3
"""带断点续传的 BBDown 部署脚本（国内镜像，已验证 ghproxy.net 可用）。"""
import os
import io
import sys
import zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dl_resume import download

TAG = "1.6.3"
DEFAULT_OUT = os.path.join(os.path.expanduser("~"), "Desktop")
# 已验证可用：ghproxy.net 对该链接返回 200 / 8040728 字节 / application/octet-stream
ASSET = f"https://ghproxy.net/https://github.com/nilaoda/BBDown/releases/download/{TAG}/BBDown_{TAG}_20240814_win-x64.zip"


def main():
    out = DEFAULT_OUT
    args = sys.argv[1:]
    if "-o" in args:
        out = args[args.index("-o") + 1]
    os.makedirs(out, exist_ok=True)
    print("资产:", ASSET)
    zip_path = os.path.join(out, "BBDown_tmp.zip")
    ok = download(ASSET, zip_path, retries=12)
    if not ok:
        sys.exit(1)
    z = zipfile.ZipFile(zip_path)
    name = next((n for n in z.namelist() if n.lower().endswith("bbdown.exe")), None)
    if not name:
        z.extractall(out)
        print("已解压全部到:", out)
    else:
        with open(os.path.join(out, "BBDown.exe"), "wb") as f:
            f.write(z.read(name))
        print("已写出:", os.path.join(out, "BBDown.exe"))
    try:
        os.remove(zip_path)
    except OSError:
        pass


if __name__ == "__main__":
    main()
