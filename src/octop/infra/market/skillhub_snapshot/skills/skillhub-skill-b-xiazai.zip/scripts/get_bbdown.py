#!/usr/bin/env python3
"""下载 BBDown (nilaoda/BBDown) 单文件 exe 到本地（国内网络经 ghproxy 镜像）。

用法:
  python get_bbdown.py [--out DIR] [--tag 1.6.3]

说明:
  - 经 ghproxy.net 代理访问 GitHub releases，规避国内直连超时。
  - 优先从 releases/expanded_assets/<tag> 解析真实 win-x64 zip 资产名；
    解析失败时回退到已知最新稳定资产名。
  - 下载 zip 并解压出 BBDown.exe 到 --out 目录（默认桌面）。
"""
import sys
import os
import re
import io
import zipfile
import urllib.request

PROXY = "https://ghproxy.net/https://github.com"
REPO = "nilaoda/BBDown"
DEFAULT_TAG = "1.6.3"
DEFAULT_OUT = os.path.join(os.path.expanduser("~"), "Desktop")


def parse_args(argv):
    out, tag = DEFAULT_OUT, DEFAULT_TAG
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-o", "--out"):
            out = argv[i + 1]
            i += 2
            continue
        if a in ("-t", "--tag"):
            tag = argv[i + 1]
            i += 2
            continue
        i += 1
    return out, tag


def http_get(url, binary=False, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read() if binary else r.read().decode("utf-8", "ignore")


def find_win_zip(tag):
    # 优先从 expanded_assets 页解析真实 asset 名
    try:
        html = http_get(f"{PROXY}/{REPO}/releases/expanded_assets/{tag}")
        links = re.findall(r'href="([^"]*releases/download/[^"]+)"', html)
        cands = [l for l in links if l.endswith(".zip") and "win" in l.lower()]
        # 优先选 x64（绝大多数 Windows 为 x64），仅在没有 x64 时回退 arm64
        x64 = [l for l in cands if "x64" in l.lower()]
        arm64 = [l for l in cands if "arm64" in l.lower()]
        pick = (x64 or arm64 or cands)[0]
        if pick:
            url = pick
            if url.startswith("/"):
                url = "https://ghproxy.net/https://github.com" + url
            return url
    except Exception as e:
        print("解析 expanded_assets 失败, 回退硬编码:", e)
    # 回退：已知最新稳定资产名
    return f"{PROXY}/{REPO}/releases/download/{tag}/BBDown_{tag}_20240814_win-x64.zip"


def main():
    out, tag = parse_args(sys.argv[1:])
    os.makedirs(out, exist_ok=True)
    asset = find_win_zip(tag)
    print("下载资产:", asset)
    data = http_get(asset, binary=True, timeout=180)
    print("下载完成, 字节数:", len(data))
    z = zipfile.ZipFile(io.BytesIO(data))
    name = next((n for n in z.namelist() if n.lower().endswith("bbdown.exe")), None)
    if not name:
        z.extractall(out)
        print("已解压全部内容到:", out)
        return
    with open(os.path.join(out, "BBDown.exe"), "wb") as f:
        f.write(z.read(name))
    print("已写出:", os.path.join(out, "BBDown.exe"))


if __name__ == "__main__":
    main()
