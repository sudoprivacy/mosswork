---
name: skillhub-skill-b-xiazai
description: "B站视频合集、收藏夹、UP主视频的批量下载工作流。当用户要求批量下载B站视频、保存B站整套课程/合集/收藏夹离线观看、或获取B站UP主全部投稿时使用。基于 BBDown（B站专用下载器），固化国内网络部署、ugc_season 合集提取（用户只给了合集里某集链接时如何拉出全集）、BBDown 1.6.3 关键参数（-app/-p/-F/-M/-hs）、以及\"前台 inline 循环 + 时间预算 + 跳过即续传\"的沙箱稳健批量法。"
---

# B合集下载

批量下载 B站视频合集 / 收藏夹 / UP主投稿的实战工作流，基于专用工具 BBDown。本 skill 固化了**国内网络环境**下从零部署并跑通批量下载的完整路径，重点解决两个最常见的坑：
1. **用户给的往往是"合集里某一集"的链接**，而不是合集本身——需要先识别它归属的 `ugc_season`（合集/系列），拉出全集 BV 清单再批量下。
2. **沙箱网络放行规律**：B站 CDN 拉流只在"前台、不加沙箱标志"时才放行，长任务会自动转后台并断网。必须用 inline 循环 + 时间预算分批跑。

## 适用场景
- 用户发来 B站视频 / 合集 / 收藏夹 / UP主主页链接，要求"批量下载""保存整套课程""离线看"。
- 链接里带 `videopod.sections`、`?spm_id_from=...sections` 之类参数 → 多半是**合集播放页**，单链接只对应其中 1 集。

## 工具选型
- **主力：BBDown**（nilaoda/BBDown，B站专用）。支持合集 / 收藏夹 / UP主 / 分区批量抓取、分P选择、音视频混流。
- 备选：yt-dlp（通用，部分视频未登录也能 1080P，见第十节兜底）。
- 结论：批量场景优先 BBDown；BBDown 1.6.3 实测稳定。

## 一、部署 BBDown（国内网络）
直连 `github.com` 会被 SSL 掐断（`SSL: UNEXPECTED_EOF_WHILE_READING`），`mirror.ghproxy.com` 返回 502。**唯独 `ghproxy.net` 可用**。但 ghproxy 常中途断流（`IncompleteRead`），必须断点续传。

用有外网的托管 Python 跑本 skill 附带的 `scripts/get_bbdown_v2.py`（内部调用 `dl_resume.py`，先 HEAD 拿总长、按 `Range` 严格续传、校验大小）：
```
"C:/Users/1/.workbuddy/binaries/python/versions/3.13.12/python.exe" scripts/get_bbdown_v2.py -o "C:/Users/1/Desktop"
```
该脚本写死经验证的 ghproxy 资产链接（BBDown 1.6.3 win-x64），下载并解压出 `BBDown.exe` 到 Desktop。
若已能直连：`winget install --id nilaoda.BBDown` 或手动下 release 的 `BBDown.exe`。

**坑**：`winget`/`choco` 安装后可能不在当前 shell 的 PATH（需重开终端）。优先用单文件 `BBDown.exe` + 绝对路径调用。旧 `scripts/get_bbdown.py` 不带续传、易下出坏包，勿再用。

## 二、准备 ffmpeg
BBDown 混流依赖 ffmpeg。二选一：
- 本机已有 → 复制到 ASCII 路径：`copy "<含中文的路径>\ffmpeg.exe" "C:\Users\1\Desktop\ffmpeg.exe"`
- 没有 → 用本 skill 附带 `scripts/get_ffmpeg.py` 经 ghproxy 拉 BtbN 构建的 `ffmpeg.exe` 到桌面：
  ```
  "C:/Users/1/.workbuddy/binaries/python/versions/3.13.12/python.exe" scripts/get_ffmpeg.py "C:/Users/1/Desktop"
  ```
调用时一律显式指定：`--ffmpeg-path "C:/Users/1/Desktop/ffmpeg.exe"`（绝对路径，中文目录会被 BBDown 找不到）。

> **备选（更稳）**：本 skill 自带 `get_ffmpeg.py` 硬编码 BtbN "latest" 资产约 200MB，经 ghproxy 易 `IncompleteRead` 断流失败（实测）。更稳的做法是用 `imageio-ffmpeg` 的 pip 包取出单文件 `ffmpeg.exe`：
> ```
> "C:/Users/1/.workbuddy/binaries/python/envs/default/Scripts/python.exe" -m pip install -i https://mirrors.aliyun.com/pypi/simple/ imageio-ffmpeg
> "C:/Users/1/.workbuddy/binaries/python/envs/default/Scripts/python.exe" - <<'PY'
> import imageio_ffmpeg, shutil
> exe=imageio_ffmpeg.get_ffmpeg_exe(); shutil.copy(exe, "C:/Users/1/Desktop/ffmpeg.exe")
> print("ffmpeg ->", exe)
> PY
> ```
> 该 exe 体积约 87MB，含完整混流能力，BBDown `--ffmpeg-path` 直接可用。

## 三、关键参数认知（BBDown 1.6.3，已逐项核对 --help）
- **`-app` / `--use-app-api`（必带，未登录真实拉流）**：WEB 接口解析能拿流地址，但真正下载时 B站返回 `403 Forbidden`（playurl 风控）；`-tv` 同样 403；**唯独 `-app`（APP 接口）能免登录下到 480P**。命令里务必带 `-app`。
- **`-p` / `--select-page`**：选分P，**必须带值**。`-p ALL` 全下；`-p 1-10` 前 10；`-p 3,5` 指定；不写默认只下 P1。
- **`-F` / `--file-pattern`（单P文件名模板）**：用于单P视频命名，占位符 `<videoTitle>` `<bvid>` `<pageNumberWithZero>` 等。**跨合集全局编号必须用这里的占位符 + 手动循环计数器**（见第六、七节）。
- **`-M` / `--multi-file-pattern`（多P文件名模板）**：仅对"一个视频的多个分P"生效，默认 `<videoTitle>/[P<pageNumberWithZero>]<pageTitle>`。它的 `[Pxx]` 只在该视频内部编号，**不会跨合集连续**——给合集整体连续编号不要依赖它。
- **`-hs` / `--hide-streams`**：不打印所有可用音视频流，减少噪声（inline 循环里友好），无害，建议带。
- **`-info` / `--only-show-info`**：仅解析不下（探测分P数）。注意是 `-info` 不是 `--info`。
- **`--delay-per-page <秒>`**：分P之间间隔（默认无）。老教程写的 `--delay` / `-d` 在 1.6.3 **已不存在**，写了会被当未知参数报错。
- **封面**：默认下载（部分合集无独立封面则无 jpg）。`--skip-cover` 可关。
- **画质**：未登录最高 **480P 清晰**；1080P 高码率需先 `BBDown login` 扫码存 cookie。
- **`--save-archives-to-file`（勿用）**：把已下载记录写进 `downloaded.txt`，其 aid 判重会让后续重跑误判"已下载"跳过（即便文件已删）。断点续传改用"编号文件已存在即跳过"（见下文）。

## 四、先识别下载场景（决定走哪条命令）
**场景 A — 单视频多P / 收藏夹 / UP主主页**：BBDown 可直接吃这类链接，一次命令批量下（仍要前台分批，见第八节）。例：`BBDown <url> -p 1-5 ...`。
**场景 B — ugc_season 合集（最常见、也最易踩坑）**：用户只给了合集里某集的 BV 链接。BBDown 吃这个 BV **只会下那 1 集**，不会自动下整集合集。必须先识别它归属的 `ugc_season`，拉出全集 BV 清单，再用 inline 循环逐条下（第六、七节）。

判断是否合集：用 `-info` 看分P数；或直接查 API（第五节）。若 `-info` 显示只有 1 个分P、但用户说"合集"，基本就是场景 B。

## 五、场景 B 第一步：用 API 提取 ugc_season 全集 BV 清单
用有外网的托管 Python 查 `x/web-interface/view`（Bash 的 `curl` 在本机无外网，必须用托管 Python）：
```
"C:/Users/1/.workbuddy/binaries/python/versions/3.13.12/python.exe" - <<'PY'
import urllib.request, json, os
bvid="BV1EoRPYXEPr"   # ← 换成用户给的链接里的 BV 号
url=f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}"
req=urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0","Referer":"https://www.bilibili.com"})
data=json.load(urllib.request.urlopen(req, timeout=20))["data"]
us=data.get("ugc_season")
if not us:
    print("该链接是独立视频, 无合集 → 走场景 A"); raise SystemExit
out=[]
for sec in us["sections"]:
    for e in sec["episodes"]:
        out.append(e["bvid"])
# 去重保序
seen=set(); bvs=[b for b in out if not (b in seen or seen.add(b))]
d="C:/Users/1/Desktop/B站合集/"+us["title"]
os.makedirs(d, exist_ok=True)
open(os.path.join(d,"bvs.txt"),"w",encoding="utf-8").write("\n".join(bvs))
print("合集:", us["title"], "| 共", len(bvs), "集 | 目录:", d)
print("清单已写:", os.path.join(d,"bvs.txt"))
PY
```
跑完会得到 `bvs.txt`（每行一个 BV）和保存目录 `D`。把 `D` 记下来供第六步用。

> 收藏夹 / UP主全部投稿也可用 BBDown 直接吃链接（场景 A）；但若数量很大，同样建议先按上面思路把 BV 列表落到 `bvs.txt` 再走第六步循环，最稳。

## 六、场景 B 第二步：inline 循环逐条下载（沙箱稳健核心）
**关键：必须写在 Bash 工具里 inline 运行，不要写成 `bash dl.sh` / `bash -c` 脚本文件**——脚本文件会被判为长任务自动转后台、B站 CDN 拉流被沙箱掐断，只留 0 字节空壳。直接 inline：
```
cd "C:/Users/1/Desktop"
D="C:/Users/1/Desktop/B站合集/中国国际大学生创新大赛备赛教程"   # ← 换成第五节打印的目录
BD="C:/Users/1/Desktop/BBDown.exe"
FF="C:/Users/1/Desktop/ffmpeg.exe"
mapfile -t BVS < "$D/bvs.txt"
N=${#BVS[@]}
START=$(date +%s)
for ((i=0;i<N;i++)); do
  bv=${BVS[$i]}; num=$(printf "%03d" $((i+1)))
  ls "$D/${num}_"* >/dev/null 2>&1 && continue            # 已下则跳过 → 断点续传
  "$BD" "https://www.bilibili.com/video/$bv" -app -p ALL -hs -F "${num}_<videoTitle>" --work-dir "$D" --ffmpeg-path "$FF" >/dev/null 2>&1
  NOW=$(date +%s); if (( NOW-START > 500 )); then echo "到预算, 停在 $num, 下次续传"; break; fi
done
echo "mp4: $(ls -1 "$D"/*.mp4 2>/dev/null | wc -l) / $N"
```
要点：
- `-F "${num}_<videoTitle>"`：`num` 是循环里的 `001..169` 全局连续编号，`<videoTitle>` 是 BBDown 内置变量填标题 → 文件名 `001_标题.mp4`。
- **跳过即续传**：`ls "$D/${num}_"* && continue` —— 重跑同一条命令会自动补齐未下的、跳过已下的，可反复调用直到 `mp4 == N`。
- **时间预算 500s**：前台默认 120s 超时（部分环境更长）会转后台断网；用 `date +%s` 自限在 600s 窗口内停，下次续传。
- 每批跑完看末行计数，未到 `N` 就再发一次同样的 inline 命令续传。

## 七、场景 A 命令（单视频多P / 收藏夹 / UP主，前台分批）
```
"<BBDown.exe绝对路径>" "<链接>" -app -p 1-5 -hs -M "<videoTitle>/[P<pageNumberWithZero>]" --work-dir "<保存目录>" --ffmpeg-path "<ffmpeg.exe绝对路径>"
```
- `-p 1-5` 只下前 5 分P；换 `-p 6-10`、`-p 11-15` … 分批前台跑（同第八节沙箱规律，每批 1–3 分钟稳在前台）。
- `-M "<videoTitle>/[P<pageNumberWithZero>]"` 让文件落在 `标题/[P01].mp4` 子目录；要自定义总目录前缀就把标题作为路径前缀写进 `-M` / `--work-dir`。
- 收藏夹 / UP主主页链接 BBDown 也能直接吃，但**大数量仍要分批前台**（否则转后台断网），建议先用第五节思路落 `bvs.txt` 再走第六节循环。
- **同标题视频被误判重复（关键坑）**：BBDown 的"已存在则跳过"只认默认标题文件名、不认 `-M` 输出名。若合集内两视频标题完全相同（同一项目两条不同 BV 的路演），即便 `-M` 起了唯一名，BBDown 仍会因默认标题文件已存在而**跳过第二条**。解法：把冲突那条先下到另一临时 `--work-dir`（无同名文件），完成后 `mv`/`rename` 成唯一名移入正式目录；不要用 `-y` 之类（1.6.3 无可靠覆盖开关，会覆盖第一条）。

## 八、沙箱网络放行规律（本机实测，决定性）
- 本沙箱会**拦截 B站 CDN（`*.bilivideo.com`）**：在**后台**运行、或带 `dangerouslyDisableSandbox=true` 运行，都触发 `Sandbox Intercept` 导致拉流 403/失败。
- 只有**前台（foreground）且不加沙箱标志**的调用被系统自动放行（`Sandbox bypassed`）并成功。
- 但前台有超时上限（部分环境 120s，会转后台；转后台即失去网络放行）。因此：
  - **下载必须前台分批**，每批用 `date +%s` 时间预算自限在 600s 内（见第六、七节）。
  - **必须用 inline 命令、禁用脚本文件**：写成 `bash dl.sh` / `bash -c '...'` 会被判为长任务自动转后台（标准输出整段返回空），B站 CDN 拉流被掐，只生成 0 字节空壳暂存夹（形如 `11438...` 的数字目录 + 0 字节 `.tmp`）。直接在 Bash 工具里写 inline `for` 循环。
- **每批开始前清残留空壳**：`cd "$D"; find . -maxdepth 1 -type d -name '[0-9]*' -exec rm -rf {} + 2>/dev/null`，避免 0 字节暂存夹堆积。

## 九、登录拿高清（可选）
```
"<BBDown.exe>" login
```
手机 B站扫码，cookie 存本机，以后免登。之后用同样命令（第六节循环，去掉未登录限制即更高画质）重跑即可覆盖 / 补齐为更高画质，已下的会被跳过。

## 十、合规提醒（务必向用户说明）
- 仅限个人离线观看 / 学习 / 备份，勿二次上传、搬运、商用，遵守 B站《用户协议》与版权规定。
- 番剧、影视、付费内容受版权保护，工具未必能下、也不建议绕过。

## 十一、本机网络实测结论（2026-10-05 复核更新）
- **GitHub releases 下载**：直连 `github.com` → SSL 掐断；`mirror.ghproxy.com` → 502；**`ghproxy.net` → 200 可用**（见第一、二节，用续传脚本）。
- **BBDown 拉流**：未登录 WEB / TV 接口真实下载均 `403 Forbidden`，**只有 `-app`（APP 接口）能免登录下到 480P**（见第三节）。
- **沙箱放行（最关键，见第八节）**：后台 / 带 `dangerouslyDisableSandbox` 均被拦截 B站 CDN；仅**前台、不加沙箱标志**自动放行。**下载必须前台 inline 分批**。
- 若以上仍不通，兜底改用 `yt-dlp`（同样能批量下合集/收藏夹/UP主，部分视频未登录也能 1080P）：
  ```
  <py> -m venv <env>
  <env>/Scripts/python.exe -m pip install -i https://mirrors.aliyun.com/pypi/simple/ yt-dlp imageio-ffmpeg
  <env>/Scripts/python.exe -m yt_dlp -f "bestvideo[height=1080][vcodec^=avc1]+bestaudio[ext=m4a]/best" \
    --merge-output-format mp4 --ffmpeg-location "C:/Users/1/Desktop/" \
    -P "<保存目录>" -o "%(playlist_index)02d - %(title)s.%(ext)s" "<BV链接>"
  ```
  要点：`--ffmpeg-location` 必须指向**含 `ffmpeg.exe` 的目录**，否则只下分片不合并。

## 十二、按网站分P主题重命名（标准收尾步骤）
BBDown 默认把多分P视频输出成 `[P01].mp4`…`[P0N].mp4`（场景 A 的 `-M` 模板）或 `001_标题.mp4`（场景 B 的 `-F` 模板），文件名不含网站上的真实分P标题。B站每个分P都有独立标题（如冠/亚/季军 + 项目名），**下载完成后统一按网站分P主题重命名**，更易检索与按序播放。

**做法**：用托管 Python 查 `x/web-interface/view` 的 `pages[].part` 拿到每个分P的网站标题，把 `[Pxx].mp4` 重命名为 `[Pxx] <分P标题>.mp4`，并**保留 `[Pxx]` 序号前缀**以维持播放顺序（同一名次下多个分P、如多个"季军"，网站标题里无子序号，顺序不能乱）。

> 该 API 走 `api.bilibili.com`，前台托管 Python 可直连（非 B站 CDN，不受第八节沙箱拦截影响）。

```
"C:/Users/1/.workbuddy/binaries/python/versions/3.13.12/python.exe" - <<'PY'
import urllib.request, json, os, re
bvid="BV1QeCmYTEJF"                                   # ← 换成目标 BV
folder=r"C:/Users/1/Desktop/Bili_DL/2024中国国际大学生创新大赛总决赛录播"  # ← 换成实际目录
url=f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}"
req=urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0","Referer":"https://www.bilibili.com"})
pages={p["page"]: p["part"] for p in json.load(urllib.request.urlopen(req, timeout=20))["data"]["pages"]}
bad='/\\:*?"<>|'
for i in range(1, len(pages)+1):
    src=os.path.join(folder, f"[P{i:02d}].mp4")
    if not os.path.exists(src):
        src=os.path.join(folder, f"[P{i}].mp4")        # 兼容非补零写法
    if not os.path.exists(src):
        print("缺失:", f"[P{i}]"); continue
    clean=re.sub(f"[{re.escape(bad)}]", "", pages[i]).strip()
    dst=os.path.join(folder, f"[P{i:02d}] {clean}.mp4")
    if os.path.exists(dst): print("已存在, 跳过:", dst); continue
    os.rename(src, dst); print(f"P{i} -> {os.path.basename(dst)}")
PY
```

要点：
- **保留序号前缀**：同名次多个分P（如 4 个"季军"）靠 `[Pxx]` 锁顺序，切勿删。
- **清洗非法字符**：Windows 文件名禁止 `/ \ : * ? " < > |`，重命名前务必剔除（上面 `bad` 已处理）。中文全角引号 `""` 允许，无需替换。
- **适用范围**：主要用于场景 A 多分P视频；场景 B 合集里每个 BV 通常本身是独立单视频、标题已在文件名中，若某 BV 自身也多分P，对它的输出文件套用同一脚本即可。

## 验收
下载完成后核对（以场景 B 为例）：
```
cd "$D"
echo "mp4: $(ls -1 *.mp4 | wc -l) / $N"
echo "0字节: $(find . -maxdepth 1 -name '*.mp4' -size 0 | wc -l)"
echo "残留空壳: $(find . -maxdepth 1 -type d -name '[0-9]*' | wc -l)"
echo "总大小: $(du -sh . | cut -f1)"
# 编号连续性
miss=0; for i in $(seq 1 $N); do num=$(printf "%03d" $i); ls "${num}_"* >/dev/null 2>&1 || { echo "缺 $num"; miss=$((miss+1)); }; done; echo "缺: $miss"
```
合格标准：mp4 数 == 合集集数、`0字节 == 0`、无残留数字暂存夹、编号连续无缺。
- （推荐收尾）最终文件名已按网站分P主题重命名（见第十二节），而非仅 `[Pxx].mp4`。
