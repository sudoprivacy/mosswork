#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
候选人收入交叉对账脚本。

输入 JSON 文件（ledger.json，由 WorkBuddy 从个税截图/银行截图/简历提取后整理）：

{
  "candidate": "张三",
  "tax_records": [                       // 个税App"收入纳税明细"逐条
    {"month": "2025-11", "type": "工资薪金", "subtype": "正常工资薪金",
     "employer": "某科技（北京）有限公司", "gross": 40000.00, "tax": 7819.25},
    {"month": "2025-11", "type": "工资薪金", "subtype": "全年一次性奖金收入",
     "employer": "某科技（北京）有限公司", "gross": 120000.00, "tax": 11790.00},
    {"month": "2026-09", "type": "工资薪金", "subtype": "解除劳动合同一次性补偿",
     "employer": "某科技（北京）有限公司", "gross": 30000.00, "tax": 0.00}
  ],
  "bank_records": [                      // 银行"薪资"入账逐笔
    {"month": "2025-11", "date": "11-10 14:53", "amount": 28457.75,
     "summary": "网上代发代扣", "account": "7302"}
  ],
  "annual_totals": [                     // 个税App页顶合计（可选）
    {"year": "2025", "income_total": 601585.13, "tax_total": 74097.28}
  ],
  "resume": {                            // 简历信息（可选，用于时间线核验）
    "expected_salary": 600000,
    "employment_periods": [{"company": "某品牌", "start": "2024-10", "end": "2026-07"}],
    "education_periods": [{"school": "某大学（英国）", "start": "2017-09", "end": "2019-01"}]
  }
}

type/subtype 归类关键词：
  salary（正常工资薪金/工资薪金）、bonus（全年一次性奖金）、
  severance（解除劳动合同/补偿）。
银行摘要含"代发"视为薪资代发；其他摘要（如"支付宝"）单列为非代发入账。

用法：python cross_check.py ledger.json
输出：Markdown 对账表 + 疑点清单（stdout）。
"""
import json
import sys
from statistics import median

TOL = 0.02  # 分级容差（银行截图中金额可能被 OCR 误读分位）


def classify(subtype: str) -> str:
    s = (subtype or "") + ""
    if "解除劳动合同" in s or "补偿" in s:
        return "severance"
    if "一次性奖金" in s or "奖金" in s:
        return "bonus"
    return "salary"


def months_between(start: str, end: str) -> set:
    """返回 [start, end] 闭区间覆盖的月份集合（'YYYY-MM'）。"""
    sy, sm = map(int, start.split("-"))
    ey, em = map(int, end.split("-"))
    out, y, m = set(), sy, sm
    while (y, m) <= (ey, em):
        out.add(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


def main(path: str) -> None:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)

    tax = data.get("tax_records", [])
    bank = data.get("bank_records", [])
    resume = data.get("resume", {})
    totals = data.get("annual_totals", [])

    for r in tax:
        r["cat"] = classify(r.get("subtype", r.get("type", "")))

    # ---- 按月聚合 ----
    tax_by_month: dict = {}
    for r in tax:
        m = r["month"]
        e = tax_by_month.setdefault(m, {"gross": 0.0, "tax": 0.0, "cats": set(), "employers": set()})
        e["gross"] += r["gross"] or 0.0
        e["tax"] += r["tax"] or 0.0
        e["cats"].add(r["cat"])
        if r.get("employer"):
            e["employers"].add(r["employer"])

    bank_by_month: dict = {}
    non_payroll = []
    for r in bank:
        m = r["month"]
        if "代发" not in (r.get("summary") or "代发"):  # 摘要缺失时默认视为代发
            non_payroll.append(r)
            continue
        e = bank_by_month.setdefault(m, {"amount": 0.0, "dates": []})
        e["amount"] += r["amount"] or 0.0
        e["dates"].append(r.get("date", "?"))

    print(f"# 交叉对账结果：{data.get('candidate', '(未命名)')}\n")

    # ---- 逐月对账 ----
    print("## 逐月对账表\n")
    print("| 月份 | 个税类型 | 税前 | 个税 | 隐含扣款 | 银行到账 | 核验 |")
    print("|---|---|---:|---:|---:|---:|---|")

    deductions = []
    fatal, suspicious = [], []
    all_months = sorted(set(tax_by_month) | set(bank_by_month))
    for m in all_months:
        t, b = tax_by_month.get(m), bank_by_month.get(m)
        if t and b:
            ded = t["gross"] - t["tax"] - b["amount"]
            if t["gross"] == 0:
                # 零申报但有银行入账：欠薪补发或口径异常
                status = "⚠ 零申报却有入账"
                suspicious.append(f"{m}: 个税申报收入为0，但银行入账 {b['amount']:.2f}")
            elif ded < -TOL:
                status = "✗ 不自洽"
                fatal.append(f"{m}: 到账 {b['amount']:.2f} > 税前-税额 {t['gross']-t['tax']:.2f}，"
                             f"隐含扣款为负（物理不可能，强造假信号）")
            else:
                status = "✓"
                if "salary" in t["cats"]:
                    deductions.append((m, ded))
            print(f"| {m} | {'/'.join(sorted(t['cats']))} | {t['gross']:.2f} | {t['tax']:.2f} "
                  f"| {ded:+.2f} | {b['amount']:.2f} | {status} |")
        elif t and not b:
            note = "停薪/零申报" if t["gross"] == 0 else "⚠ 个税有申报但无银行入账"
            if t["gross"] > 0:
                suspicious.append(f"{m}: 个税申报 {t['gross']:.2f} 但银行无对应入账（欠薪或截图不全）")
            print(f"| {m} | {'/'.join(sorted(t['cats']))} | {t['gross']:.2f} | {t['tax']:.2f} "
                  f"| — | 缺银行 | {note} |")
        else:
            print(f"| {m} | — | — | — | — | {b['amount']:.2f} | ⚠ 有入账无个税申报 |")
            suspicious.append(f"{m}: 银行代发入账 {b['amount']:.2f}，个税无申报记录"
                              f"（或个税截图未覆盖该月份，需确认）")

    # ---- 奖金/补偿金精确核对（不扣社保，净额应分毫不差） ----
    print("\n## 奖金/补偿金精确核对\n")
    bonus_ok = True
    for r in tax:
        if r["cat"] in ("bonus", "severance") and r["gross"]:
            expected = round(r["gross"] - r["tax"], 2)
            hit = [x for x in bank if x["month"] == r["month"] and abs(x["amount"] - expected) <= TOL]
            if hit:
                print(f"- {r['month']} {r['subtype']}：{r['gross']:.2f} − {r['tax']:.2f} = "
                      f"{expected:.2f}，与银行到账精确吻合 ✓")
            else:
                bonus_ok = False
                msg = (f"{r['month']} {r['subtype']}：净额应为 {expected:.2f}，"
                       f"当月银行入账中未找到精确匹配")
                print(f"- {msg} ⚠")
                suspicious.append(msg)
    if not any(r["cat"] in ("bonus", "severance") for r in tax):
        print("-（材料中无奖金/补偿金记录）")

    # ---- 隐含扣款稳定性（仅工资月） ----
    print("\n## 隐含扣款（社保等）月度稳定性\n")
    if len(deductions) >= 2:
        vals = [d for _, d in deductions]
        med = median(vals)
        print(f"- 工资月份数：{len(vals)}；隐含扣款中位数：{med:+.2f}；"
              f"区间：[{min(vals):+.2f}, {max(vals):+.2f}]")
        spread = max(vals) - min(vals)
        if spread <= 500:
            print(f"- 极差 {spread:.2f} 元，高度稳定 → 数据自洽性强（P图很难做到）")
        elif spread <= 2000:
            print(f"- 极差 {spread:.2f} 元，基本稳定（可能有基数调整月份）")
        else:
            print(f"- 极差 {spread:.2f} 元，波动大 → 逐月核对差异来源")
            suspicious.append(f"隐含扣款月度波动大（极差 {spread:.2f} 元），需解释")
        for m, d in deductions:
            if abs(d - med) > 2000:
                print(f"  - 离群：{m} 隐含扣款 {d:+.2f}")
        if med < 0:
            fatal.append("隐含扣款中位数为负：系统性不自洽")
        elif med > 0.35 * max((t["gross"] for t in tax_by_month.values()), default=1):
            suspicious.append(f"隐含扣款中位数 {med:.2f} 占税前比例异常高，需解释（公积金？）")
    else:
        print("-（可对账的工资月份不足 2 个，无法评估稳定性）")

    # ---- 年度合计 ----
    print("\n## 年度合计核对\n")
    if totals:
        for at in totals:
            yr = at["year"]
            months = [m for m in tax_by_month if m.startswith(yr)]
            s_gross = sum(tax_by_month[m]["gross"] for m in months)
            s_tax = sum(tax_by_month[m]["tax"] for m in months)
            note = "（截图月份不全，仅供参考）" if len(months) < 12 else ""
            print(f"- {yr}：明细求和 税前 {s_gross:.2f} / 税额 {s_tax:.2f}；"
                  f"页顶合计 {at['income_total']:.2f} / {at['tax_total']:.2f} {note}")
            if len(months) >= 12:
                if abs(s_gross - at["income_total"]) > 1:
                    fatal.append(f"{yr} 年度收入合计与明细求和不符（差 "
                                 f"{at['income_total']-s_gross:.2f}）")
    per_year = {}
    for m, t in tax_by_month.items():
        y = m[:4]
        per_year.setdefault(y, 0.0)
        per_year[y] += t["gross"]
    for y in sorted(per_year):
        print(f"- {y} 证据支持税前总收入：{per_year[y]:.2f} 元")
    if resume.get("expected_salary"):
        # 峰值年度优先用个税App页顶年度合计（覆盖完整年），无则用明细求和
        peak = 0.0
        for y in sorted(per_year):
            cand = per_year[y]
            for at in totals:
                if at["year"] == y and len([m for m in tax_by_month if m.startswith(y)]) >= 12:
                    cand = max(cand, at["income_total"])
            peak = max(peak, cand)
        print(f"- 简历/期待薪资：{resume['expected_salary']:.0f} 元；"
              f"证据峰值年度税前 {peak:.2f} 元 → 锚点差 {resume['expected_salary']-peak:+.2f}")

    # ---- 非代发入账 ----
    if non_payroll:
        print("\n## 薪资类目下的非代发入账（追问来源）\n")
        for r in non_payroll:
            print(f"- {r['month']} {r.get('date','')} {r.get('summary','?')} +{r['amount']:.2f}")

    # ---- 时间线核验 ----
    print("\n## 时间线核验\n")
    emp = resume.get("employment_periods", [])
    edu = resume.get("education_periods", [])
    if emp and edu:
        overlaps = []
        for e in emp:
            em = months_between(e["start"], e["end"])
            for d in edu:
                dm = months_between(d["start"], d["end"])
                ov = em & dm
                if len(ov) >= 3:
                    overlaps.append(f"{e['company']}（{e['start']}~{e['end']}）与 "
                                    f"{d['school']}（{d['start']}~{d['end']}）重叠 "
                                    f"{len(ov)} 个月：{sorted(ov)[0]}~{sorted(ov)[-1]}")
        if overlaps:
            for o in overlaps:
                print(f"- ⚠ {o}")
                suspicious.append(f"教育/工作时间线重叠：{o}")
        else:
            print("- 教育/工作时间线无 ≥3 个月重叠")
        # 有效工龄（扣除与教育重叠的月份）
        all_emp = set()
        for e in emp:
            all_emp |= months_between(e["start"], e["end"])
        all_edu = set()
        for d in edu:
            all_edu |= months_between(d["start"], d["end"])
        effective = all_emp - all_edu
        if effective:
            print(f"- 简历口径工龄：{len(all_emp)} 个月；扣除教育重叠后有效工龄："
                  f"{len(effective)} 个月（约 {len(effective)/12:.1f} 年）")
    # 个税申报月份 vs 简历在职区间
    if emp:
        covered = set()
        for e in emp:
            covered |= months_between(e["start"], e["end"])
        outside = [m for m in sorted(tax_by_month) if m not in covered]
        if outside:
            print(f"- ⚠ 个税申报早于/晚于简历在职区间的月份：{outside}")
            suspicious.append(f"个税申报月份落在简历在职区间之外：{outside}")
        # 雇主切换点
        timeline = sorted((r["month"], r.get("employer", "?")) for r in tax if r.get("employer"))
        switches = []
        for i in range(1, len(timeline)):
            if timeline[i][1] != timeline[i - 1][1]:
                switches.append(f"{timeline[i][0]}：{timeline[i-1][1]} → {timeline[i][1]}")
        if switches:
            print("- 扣缴义务人切换时间点（结合降薪/停薪看经营风险）：")
            for s in switches:
                print(f"  - {s}")
        # 降薪/停薪轨迹（仅统计工资类申报，剔除奖金；降至0单独列停薪）
        sal = []
        for m in sorted(tax_by_month):
            g = sum(r["gross"] or 0.0 for r in tax if r["month"] == m and r["cat"] == "salary")
            if tax_by_month[m]["cats"] == {"salary"} or "salary" in tax_by_month[m]["cats"]:
                sal.append((m, g))
        drops = []
        for i in range(1, len(sal)):
            pm, pg = sal[i - 1]
            cm, cg = sal[i]
            if pg > 0 and 0 < cg < pg * 0.5:
                drops.append(f"{cm}：工资 {pg:.2f} → {cg:.2f}（降薪）")
        zero = [m for m, g in sal if g == 0]
        if drops:
            for d in drops:
                print(f"- ⚠ {d}")
        if zero:
            print(f"- ⚠ 停薪月份（零申报）：{zero}")

    # ---- 疑点汇总 ----
    print("\n## 疑点汇总\n")
    if fatal:
        print("**致命（强造假信号）**")
        for x in fatal:
            print(f"- {x}")
    if suspicious:
        print("\n**需要追问/解释**")
        for x in suspicious:
            print(f"- {x}")
    if not fatal and not suspicious:
        print("- 未发现逻辑不自洽项；材料高度自洽 → 收入数据大概率真实。"
              "注意：仍不排除P图，关键offer前建议视频实时共享屏幕核对个税App。")
    elif not fatal:
        print("\n（未出现致命信号，疑点均可追问后自证）")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    main(sys.argv[1])
