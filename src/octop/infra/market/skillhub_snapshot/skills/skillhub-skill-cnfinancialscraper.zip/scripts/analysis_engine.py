# -*- coding: utf-8 -*-
"""统计严谨性分析引擎（v12.1.0 新增）。

为什么单开一个模块：v8 的 analysis_enhanced.py 能给关键词、趋势标签和洞察文案，
但它的"趋势"是移动平均斜率拍阈值、异常是总体 z-score，结论没有置信区间，
也没有任何地方告诉调用方**哪些结论现在还不能下**。TRACE 评测里的 Reliability
要求"结果可复现、口径可解释"，所以本模块把统计推断原语与结论分级拆出来单独可测：

1. 统计原语：Wilson 比例区间 / Mann-Kendall 趋势检验 / Sen 斜率 /
   稳健 z-score（MAD）/ 两比例 z 检验。
2. analyze_records：把一批异构爬取记录收敛成
   "数据质量 → 分布 → 趋势 → 异常 → 关键词 → 能下的结论 / 不能下的结论" 的固定结构。
3. render_analysis_markdown：把上述结构渲染成带口径说明的 Markdown。
4. self_check：无网络自检，MCP 健康检查可直接调用。

统计口径（写死在这里，避免下游各自解释）：
- 比例与置信区间：Wilson 95%（z=1.96）；分母一律用**有效样本 n_used**。
  情感缺失记为 unknown：不进入 positive/neutral/negative 计数，但仍占分母。
- 时间窗：days>0 表示"最近 days 个自然日（含当天 00:00 起）"，按自然日
  零填充时间桶——某天没有记录就是 0 条，而不是把那天从序列里删掉。
  时间解析失败的记录不参与过滤、也不参与分桶，单独计入 unknown_time。
- 趋势：Mann-Kendall 检验（结值校正），正态近似 p 值用 math.erfc；
  仅当 p<0.05 且 S 的符号明确时才判 rising / falling，否则 no_trend。
- 异常：稳健 z = 0.6745 × (x − median) / MAD，|z| >= 3.5 记为异常；
  MAD=0（多数桶取值相同）时全部给 0——宁可不报，也不假报。
- 去重：先按 URL、再按（来源，标题）完全相同；只删完全重复，不做模糊合并。
- 结论分级：high 需 n>=3×min_sample 且来源>=3；medium 需 n>=min_sample 且
  来源>=2；其余 low；有效样本 < min_sample 时全部结论强制 low。
- 关键词 weight：归一化词频（该词频次 / 本批最高词频次，落在 (0,1]），
  只用于排序，不是概率或占比。
- 本模块只做描述统计与单调趋势检验，**不做因果识别**：相关/共现不等于因果。

纯标准库（math / statistics / datetime / collections），零 pip 依赖；
所有库函数返回 dict / list，不 print（仅 __main__ 自检时打印）。
"""
from __future__ import annotations

import json
import math
import re
import statistics
import time
from collections import Counter
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "WILSON_Z", "ANOMALY_Z", "MIN_TREND_BUCKETS", "METHODS",
    "wilson_interval", "mann_kendall", "sen_slope", "robust_zscores",
    "two_proportion_z_test",
    "normalize_record", "analyze_records",
    "render_analysis_markdown", "self_check",
]

#: Wilson 区间默认 z（95% 双侧）
WILSON_Z = 1.96
#: 稳健 z 异常阈值
ANOMALY_Z = 3.5
#: 少于多少个时间桶就不做趋势判断（Mann-Kendall 检验功效不足）
MIN_TREND_BUCKETS = 4
#: 比例显著性的默认 alpha
ALPHA = 0.05

#: 分析口径清单（原样进 analyze_records 的 methods 字段与 Markdown）
METHODS: List[str] = [
    "去重：先按 URL，再按（来源，标题）完全相同；只删完全重复，不做模糊合并",
    "比例估计：Wilson 95% 置信区间（二项分布正态近似，分母为有效样本）",
    "趋势：Mann-Kendall 检验（结值校正，p<0.05 判显著）+ Sen 斜率（中位成对斜率）",
    "异常：稳健 z-score（0.6745×离差/MAD，|z|>=3.5 记为异常）",
    "两期比例对比：两比例 z 检验（合并方差，双侧 p 值）",
    "关键词：优先复用 analysis_enhanced.extract_keywords，不可用时降级为中文 bigram 词频",
]

# 中文常见停用字（降级分词时过滤单字噪声；不做完整分词）
_STOP_CHARS = set("的了在是我有和就不人都一上也很到说要去你他会着没看好自己这那把"
                  "它为与及或等被让此由于因所该并其之而但如则于")
_RE_ZH_RUN = re.compile(r"[\u4e00-\u9fff]+")
_RE_EN_WORD = re.compile(r"[A-Za-z]{2,}")

_SENTIMENT_ALIASES = {
    "positive": "positive", "pos": "positive", "p": "positive",
    "正面": "positive", "积极": "positive", "利好": "positive", "乐观": "positive",
    "negative": "negative", "neg": "negative", "n": "negative",
    "负面": "negative", "消极": "negative", "利空": "negative", "悲观": "negative",
    "neutral": "neutral", "neut": "neutral", "中性": "neutral", "中立": "neutral",
}


# ============================================================================
# 1. 统计原语（模块级，可单测）
# ============================================================================

def _clamp_count(k: Any, n: Any) -> Tuple[int, int]:
    """把 (k, n) 收敛成非负整数，并保证 0 <= k <= n。"""
    try:
        ni = int(n)
    except (TypeError, ValueError):
        ni = 0
    try:
        ki = int(k)
    except (TypeError, ValueError):
        ki = 0
    ni = max(0, ni)
    return max(0, min(ki, ni)), ni


def wilson_interval(k: Any, n: Any, z: float = WILSON_Z) -> Dict[str, float]:
    """Wilson 比例置信区间。

    Args:
        k: 成功次数
        n: 试验次数（n<=0 时三项全 0.0，不抛异常）
        z: 标准正态分位数，默认 1.96（95% 双侧）

    Returns:
        {"low","high","point"}，point=k/n，low/high 已截断到 [0,1]。
    """
    ki, ni = _clamp_count(k, n)
    if ni <= 0:
        return {"low": 0.0, "high": 0.0, "point": 0.0}
    try:
        zz = float(z)
    except (TypeError, ValueError):
        zz = WILSON_Z
    zz = abs(zz) or WILSON_Z
    p = ki / ni
    denom = 1.0 + zz * zz / ni
    center = (p + zz * zz / (2.0 * ni)) / denom
    margin = zz * math.sqrt(p * (1.0 - p) / ni + zz * zz / (4.0 * ni * ni)) / denom
    return {
        "low": round(max(0.0, center - margin), 6),
        "high": round(min(1.0, center + margin), 6),
        "point": round(p, 6),
    }


def mann_kendall(values: Sequence[Any]) -> Dict[str, Any]:
    """Mann-Kendall 单调趋势检验（结值校正，双侧正态近似）。

    Args:
        values: 数值序列（按时间先后排列）

    Returns:
        {"n","s","z","p_value","trend"}；n<3 时 trend="insufficient_data"。
        trend 取值 rising / falling / no_trend / insufficient_data。
    """
    try:
        vals = [float(v) for v in values]
    except (TypeError, ValueError):
        vals = []
    n = len(vals)
    if n < 3:
        return {"n": n, "s": 0, "z": 0.0, "p_value": 1.0,
                "trend": "insufficient_data"}
    s = 0
    for i in range(n - 1):
        vi = vals[i]
        for j in range(i + 1, n):
            diff = vals[j] - vi
            if diff > 0:
                s += 1
            elif diff < 0:
                s -= 1
    # 结值校正方差
    tie_term = 0.0
    for _, count in Counter(vals).items():
        if count > 1:
            tie_term += count * (count - 1) * (2 * count + 5)
    var = (n * (n - 1) * (2 * n + 5) - tie_term) / 18.0
    if var <= 0:
        z = 0.0
    elif s > 0:
        z = (s - 1) / math.sqrt(var)
    elif s < 0:
        z = (s + 1) / math.sqrt(var)
    else:
        z = 0.0
    p_value = math.erfc(abs(z) / math.sqrt(2.0))
    if p_value < ALPHA and s > 0:
        trend = "rising"
    elif p_value < ALPHA and s < 0:
        trend = "falling"
    else:
        trend = "no_trend"
    return {
        "n": n,
        "s": s,
        "z": round(z, 6),
        "p_value": round(p_value, 6),
        "trend": trend,
    }


def sen_slope(points: Sequence[Sequence[Any]]) -> Dict[str, Any]:
    """Sen 斜率（中位成对斜率），对离群点稳健。

    Args:
        points: [(x, y), ...]，x 为时间/序号，y 为观测值

    Returns:
        {"n","slope","intercept"}；n<2 时 slope=0.0；所有 x 相同时 slope=0.0。
    """
    xs: List[float] = []
    ys: List[float] = []
    for item in points or []:
        try:
            x, y = item[0], item[1]
            xs.append(float(x))
            ys.append(float(y))
        except (TypeError, IndexError, ValueError):
            continue
    n = len(xs)
    if n == 0:
        return {"n": 0, "slope": 0.0, "intercept": 0.0}
    if n == 1:
        return {"n": 1, "slope": 0.0, "intercept": round(ys[0], 6)}
    slopes: List[float] = []
    for i in range(n - 1):
        for j in range(i + 1, n):
            dx = xs[j] - xs[i]
            if abs(dx) < 1e-12:
                continue
            slopes.append((ys[j] - ys[i]) / dx)
    if not slopes:
        return {"n": n, "slope": 0.0, "intercept": round(statistics.median(ys), 6)}
    slope = statistics.median(slopes)
    intercept = statistics.median(ys) - slope * statistics.median(xs)
    return {"n": n, "slope": round(slope, 6), "intercept": round(intercept, 6)}


def robust_zscores(values: Sequence[Any]) -> List[float]:
    """稳健 z-score：0.6745 × (x − median) / MAD。

    MAD=0（数据高度集中，如多数取值相同）时全部返回 0.0——无法判断异常，
    宁可漏报也不假报。

    Args:
        values: 数值序列

    Returns:
        与输入等长的 z 值列表（输入空列表时返回空列表）。
    """
    vals: List[float] = []
    for v in values or []:
        try:
            vals.append(float(v))
        except (TypeError, ValueError):
            vals.append(0.0)
    n = len(vals)
    if n == 0:
        return []
    med = statistics.median(vals)
    mad = statistics.median([abs(v - med) for v in vals])
    if mad <= 1e-12:
        return [0.0] * n
    return [round(0.6745 * (v - med) / mad, 6) for v in vals]


def two_proportion_z_test(k1: Any, n1: Any, k2: Any, n2: Any) -> Dict[str, Any]:
    """两比例 z 检验（合并方差，双侧）。

    Args:
        k1, n1: 第一组成功数与样本量
        k2, n2: 第二组成功数与样本量

    Returns:
        {"z","p_value","diff","significant"}；任一组 n<=0 或合并方差为 0 时
        z=0、p_value=1.0（不抛异常）。
    """
    a, na = _clamp_count(k1, n1)
    b, nb = _clamp_count(k2, n2)
    p1 = a / na if na else 0.0
    p2 = b / nb if nb else 0.0
    diff = p1 - p2
    if na <= 0 or nb <= 0:
        return {"z": 0.0, "p_value": 1.0, "diff": round(diff, 6),
                "significant": False}
    pooled = (a + b) / (na + nb)
    denom = math.sqrt(pooled * (1.0 - pooled) * (1.0 / na + 1.0 / nb))
    if denom <= 1e-12:
        return {"z": 0.0, "p_value": 1.0, "diff": round(diff, 6),
                "significant": False}
    z = diff / denom
    p_value = math.erfc(abs(z) / math.sqrt(2.0))
    return {
        "z": round(z, 6),
        "p_value": round(p_value, 6),
        "diff": round(diff, 6),
        "significant": bool(p_value < ALPHA),
    }


# ============================================================================
# 2. 记录归一化 / 去重 / 时间解析
# ============================================================================

def _text_of(value: Any) -> str:
    """任意值 → 去首尾空白的字符串；None/容器类给空串。"""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple, set, dict)):
        return ""
    if isinstance(value, bool):
        return ""
    return str(value).strip()


def _first_present(record: Dict[str, Any], names: Sequence[str]) -> Any:
    """按别名顺序取第一个非空字段。"""
    for name in names:
        if name not in record:
            continue
        value = record.get(name)
        if value is None:
            continue
        if isinstance(value, str) and not value.strip():
            continue
        return value
    return None


def _canon_sentiment(value: Any) -> str:
    """情感标签归一：中英文别名 → positive/neutral/negative；缺失 → unknown。"""
    text = _text_of(value).lower()
    if not text:
        return "unknown"
    return _SENTIMENT_ALIASES.get(text, "unknown")


def normalize_record(record: Dict[str, Any]) -> Dict[str, str]:
    """把各 scraper 的异构字段收敛成规范记录（缺字段不报错，给空串）。

    规范字段：title / summary / content / source / publish_time / url /
    sentiment / severity。

    Args:
        record: 原始记录 dict（非 dict 输入返回全空记录）

    Returns:
        8 个规范字段的 dict，值均为字符串；sentiment 归一为
        positive/neutral/negative/unknown，severity 缺失为 unknown。
    """
    if not isinstance(record, dict):
        record = {}
    title = _text_of(_first_present(record, ("title", "标题", "headline", "name")))
    summary = _text_of(_first_present(
        record, ("summary", "摘要", "abstract", "description", "desc")))
    content = _text_of(_first_present(
        record, ("content", "正文", "body", "text", "article")))
    source = _text_of(_first_present(
        record, ("source", "source_name", "来源", "media", "site", "channel")))
    ts_raw = _first_present(record, (
        "publish_time", "published_at", "pub_time", "published", "time",
        "date", "datetime", "ts", "发布时间", "时间", "日期"))
    url = _text_of(_first_present(
        record, ("url", "link", "链接", "href", "web_url")))
    sentiment = _canon_sentiment(_first_present(
        record, ("sentiment", "sentiment_label", "情感", "情绪", "polarity", "tone")))
    severity = _text_of(_first_present(
        record, ("severity", "严重程度", "level", "importance", "risk_level")))
    return {
        "title": title,
        "summary": summary,
        "content": content,
        "source": source,
        "publish_time": _text_of(ts_raw),
        "url": url,
        "sentiment": sentiment,
        "severity": severity or "unknown",
    }


def _parse_ts(value: Any) -> Optional[datetime]:
    """把各家时间串解析成 naive 本地 datetime；认不出返回 None。

    支持 ISO8601（T/毫秒/时区/Z）、"2026-10-01 09:00:00"、"2026/10/01"、
    "2026年10月1日 9:00"、"20261001" 以及 Unix 秒/毫秒时间戳。
    """
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        if value.tzinfo is not None:
            return value.astimezone().replace(tzinfo=None)
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value))
        except (OverflowError, OSError, ValueError):
            return None
    text = str(value).strip()
    if not text:
        return None
    if re.fullmatch(r"\d{10,13}", text):
        try:
            seconds = float(text) / (1000.0 if len(text) > 10 else 1.0)
            return datetime.fromtimestamp(seconds)
        except (OverflowError, OSError, ValueError):
            return None
    cleaned = (text.replace("年", "-").replace("月", "-")
               .replace("日", " ").replace("T", " "))
    if cleaned.endswith("Z"):
        cleaned = cleaned[:-1] + "+00:00"
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    dt: Optional[datetime] = None
    try:
        dt = datetime.fromisoformat(cleaned)
    except ValueError:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
                    "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d",
                    "%Y%m%d"):
            try:
                dt = datetime.strptime(cleaned[:19], fmt)
                break
            except ValueError:
                continue
    if dt is None:
        # 兜底：手工抽年月日时分秒（兼容 1 位月/日、中文混排）
        m = re.search(
            r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})"
            r"(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?", cleaned)
        if not m:
            return None
        try:
            dt = datetime(
                int(m.group(1)), int(m.group(2)), int(m.group(3)),
                int(m.group(4) or 0), int(m.group(5) or 0), int(m.group(6) or 0),
            )
        except ValueError:
            return None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt


def _coerce_now(now: Any) -> datetime:
    """now 参数归一：None→当前时间；datetime/date/时间戳/时间串均可。"""
    if now is None:
        return datetime.now()
    if isinstance(now, datetime):
        return now if now.tzinfo is None else now.astimezone().replace(tzinfo=None)
    if isinstance(now, date):
        return datetime(now.year, now.month, now.day)
    if isinstance(now, bool):
        return datetime.now()
    if isinstance(now, (int, float)):
        try:
            return datetime.fromtimestamp(float(now))
        except (OverflowError, OSError, ValueError):
            return datetime.now()
    return _parse_ts(now) or datetime.now()


def _dedupe_records(records: Sequence[Dict[str, str]]) -> Tuple[List[Dict[str, str]], int]:
    """去重：先按 URL，再按（来源，标题）完全相同。返回 (保留列表, 删除数)。"""
    kept: List[Dict[str, str]] = []
    seen_urls = set()
    seen_keys = set()
    removed = 0
    for rec in records:
        url = rec.get("url") or ""
        if url:
            if url in seen_urls:
                removed += 1
                continue
            seen_urls.add(url)
        key = (rec.get("source") or "", rec.get("title") or "")
        if key in seen_keys:
            removed += 1
            continue
        seen_keys.add(key)
        kept.append(rec)
    return kept, removed


# ============================================================================
# 3. 质量 / 时间桶 / 关键词 / 结论
# ============================================================================

def _grade_of(score: float) -> str:
    if score >= 85.0:
        return "A"
    if score >= 70.0:
        return "B"
    if score >= 55.0:
        return "C"
    return "D"


def _build_buckets(parsed: Sequence[Optional[datetime]],
                   ref_now: datetime, days: int) -> List[Dict[str, Any]]:
    """按自然日分桶。

    days>0：固定产出 days 个桶（从 days-1 天前到今天），缺失日期计 0；
    days<=0：只产出数据实际覆盖的日期。
    """
    if days > 0:
        start = datetime(ref_now.year, ref_now.month, ref_now.day) - timedelta(days=days - 1)
        dates = [start.date() + timedelta(days=i) for i in range(days)]
        counts: Dict[date, int] = {d: 0 for d in dates}
        for ts in parsed:
            if ts is None:
                continue
            counts[ts.date()] = counts.get(ts.date(), 0) + 1
        return [{"date": d.isoformat(), "count": counts.get(d, 0)} for d in dates]
    counter: Counter = Counter()
    for ts in parsed:
        if ts is not None:
            counter[ts.date()] += 1
    return [{"date": d.isoformat(), "count": counter[d]} for d in sorted(counter)]


def _bigram_counter(articles: Sequence[Dict[str, str]]) -> Counter:
    """降级关键词：中文 bigram 词频（去掉单字停用字后滑窗）。"""
    counter: Counter = Counter()
    en_counter: Counter = Counter()
    for art in articles:
        text = (art.get("title") or "") + " " + (art.get("summary") or "")
        for m in _RE_ZH_RUN.finditer(text):
            run = "".join(ch for ch in m.group(0) if ch not in _STOP_CHARS)
            for i in range(len(run) - 1):
                counter[run[i:i + 2]] += 1
        for word in _RE_EN_WORD.findall(text):
            en_counter[word.lower()] += 1
    if not counter:
        counter = en_counter
    return counter


def _extract_keywords(records: Sequence[Dict[str, str]], top_n: int = 15) -> List[Dict[str, Any]]:
    """关键词抽取：优先复用 analysis_enhanced.extract_keywords，失败降级 bigram。"""
    n = len(records)
    if n == 0:
        return []
    articles = [{"title": r.get("title") or "",
                 "summary": r.get("summary") or r.get("content") or ""}
                for r in records]
    counter: Counter = Counter()
    used_advanced = False
    try:
        try:
            from analysis_enhanced import extract_keywords  # type: ignore
        except ImportError:  # pragma: no cover - 仅在 scripts/ 不在 sys.path 时走到
            from scripts.analysis_enhanced import extract_keywords  # type: ignore
        kw = extract_keywords(articles, min_freq=1, bigram_min_freq=1,
                              trigram_min_freq=2)
        for attr in ("unigrams", "bigrams", "trigrams"):
            for item in getattr(kw, attr, None) or []:
                try:
                    term, count = item[0], item[1]
                except (TypeError, IndexError):
                    continue
                if not term:
                    continue
                try:
                    count_int = int(count)
                except (TypeError, ValueError):
                    continue
                if count_int > counter.get(term, 0):
                    counter[term] = count_int
        used_advanced = True
    except Exception:
        used_advanced = False
    if not used_advanced or not counter:
        counter = _bigram_counter(articles)
    pairs = [(term, count) for term, count in counter.most_common(top_n) if count > 0]
    if not pairs:
        return []
    top_count = max(count for _, count in pairs) or 1
    # weight 归一化到 (0,1]：该词频次 / 本批最高词频次，避免分词重复计数导致 >1
    return [{"term": term, "count": count,
             "weight": round(count / float(top_count), 4)}
            for term, count in pairs]


def _confidence(n: int, source_count: int, min_sample: int) -> str:
    """结论置信度分级：样本不足一律 low；high 需 3×样本且 3 源。"""
    if n < min_sample:
        return "low"
    if source_count >= 3 and n >= 3 * min_sample:
        return "high"
    if source_count >= 2:
        return "medium"
    return "low"


def _baseline_previous(baseline: Any) -> Optional[float]:
    """从 baseline 里取"上一期计数"：数字或 dict（previous/count/total/n/n_used/value）。"""
    if baseline is None or isinstance(baseline, bool):
        return None
    if isinstance(baseline, (int, float)):
        return float(baseline)
    if isinstance(baseline, dict):
        for key in ("previous", "count", "total", "n_used", "n", "value"):
            value = baseline.get(key)
            if isinstance(value, bool):
                continue
            if isinstance(value, (int, float)):
                return float(value)
    return None


def _change_vs_baseline(baseline: Any, current: int) -> Optional[Dict[str, Any]]:
    previous = _baseline_previous(baseline)
    if previous is None:
        return None
    delta_pct = None
    if previous > 0:
        delta_pct = round((current - previous) / previous * 100.0, 2)
    return {"previous": previous, "current": current, "delta_pct": delta_pct}


def _quality_view(used: Sequence[Dict[str, str]], n_input: int,
                  duplicates_removed: int, invalid_ignored: int,
                  out_of_window: int, unknown_time: int,
                  min_sample: int, days: int,
                  time_span_days: float) -> Dict[str, Any]:
    """数据质量评分（0-100）与级差 A-D。扣分项写进 issues，便于解释。"""
    n = len(used)
    source_counter: Counter = Counter(
        (r.get("source") or "未知来源") for r in used)
    named_source_count = sum(1 for name in source_counter if name != "未知来源")
    sources = [{"name": name, "count": count}
               for name, count in source_counter.most_common()]

    def rate(predicate) -> float:
        if n == 0:
            return 0.0
        return round(sum(1 for r in used if predicate(r)) / float(n), 4)

    completeness = {
        "title": rate(lambda r: bool(r.get("title"))),
        "summary": rate(lambda r: bool(r.get("summary") or r.get("content"))),
        "source": rate(lambda r: bool(r.get("source"))),
        "publish_time": rate(lambda r: bool(r.get("publish_time"))),
        "url": rate(lambda r: bool(r.get("url"))),
        "sentiment": rate(lambda r: r.get("sentiment") != "unknown"),
    }

    issues: List[str] = []
    if invalid_ignored:
        issues.append(f"忽略了 {invalid_ignored} 条非字典记录")
    if duplicates_removed:
        issues.append(f"去重删除 {duplicates_removed} 条重复记录（URL / 来源+标题）")
    if out_of_window:
        issues.append(f"{out_of_window} 条记录早于时间窗，已过滤")
    if unknown_time:
        issues.append(f"{unknown_time} 条记录发布时间无法解析，未参与时间过滤与分桶")
    if n == 0:
        issues.append("时间窗内没有可用记录")
    if n and n < min_sample:
        issues.append(f"有效样本 n={n} < 最小样本 {min_sample}，置信区间偏宽")
    if n and named_source_count < 2:
        issues.append(f"具名来源仅 {named_source_count} 个，缺少跨源交叉验证")
    low_fields = [f for f, v in completeness.items() if v < 0.8]
    if n and low_fields:
        issues.append("字段完整度偏低：" + "、".join(
            f"{f}={completeness[f]:.0%}" for f in low_fields))

    score = 0.0
    if n:
        score = 100.0
        if n < min_sample:
            score -= 25.0
        if named_source_count < 2:
            score -= 15.0
        mean_completeness = statistics.mean(completeness.values())
        score -= (1.0 - mean_completeness) * 40.0
        if duplicates_removed:
            score -= min(15.0, 15.0 * duplicates_removed / max(1, n_input))
        if unknown_time:
            score -= min(10.0, 10.0 * unknown_time / max(1, n_input))
        if days > 0 and n >= min_sample and time_span_days < days * 0.5:
            score -= 10.0
            issues.append(
                f"记录仅覆盖 {time_span_days:.1f}/{days} 天，时间代表性不足")
    score = round(max(0.0, min(100.0, score)), 1)
    return {
        "score": score,
        "grade": _grade_of(score),
        "n": n,
        "unique": n,
        "duplicates_removed": int(duplicates_removed),
        "source_count": int(named_source_count),
        "sources": sources,
        "time_span_days": round(float(time_span_days), 2),
        "completeness": completeness,
        "issues": issues,
        "unknown_time": int(unknown_time),
        "invalid_ignored": int(invalid_ignored),
        "out_of_window": int(out_of_window),
    }


def _build_conclusions(used: Sequence[Dict[str, str]],
                       distribution: Dict[str, Any],
                       trend: Dict[str, Any],
                       source_count: int, min_sample: int,
                       anomalies: Sequence[Dict[str, Any]],
                       parsed: Sequence[Optional[datetime]],
                       buckets: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """生成"能下的结论"，每条都带置信度、方法、样本量与证据/限制。"""
    n = len(used)
    conclusions: List[Dict[str, Any]] = []
    if n == 0:
        return conclusions
    senti = distribution.get("sentiment", {})
    counts = senti.get("counts", {})
    ci95 = senti.get("ci95", {})
    marked = {k: int(counts.get(k, 0))
              for k in ("positive", "neutral", "negative")}
    marked_total = sum(marked.values())
    label = {"positive": "正面", "neutral": "中性", "negative": "负面"}

    # 1) 情感分布（Wilson 区间）
    if marked_total > 0:
        dominant = max(marked, key=lambda k: marked[k])
        ci = ci95.get(dominant) or wilson_interval(marked[dominant], n)
        conclusions.append({
            "statement": (
                f"样本情感以{label[dominant]}为主：{marked[dominant]}/{n}"
                f"（{marked[dominant] / n:.1%}，95% CI {ci['low']:.1%}–{ci['high']:.1%}）"
            ),
            "confidence": _confidence(n, source_count, min_sample),
            "method": "Wilson 比例置信区间",
            "n": n,
            "evidence": [
                f"{label[k]} {marked[k]} 条" for k in marked
            ] + [f"95% CI：{ci['low']:.1%}–{ci['high']:.1%}"],
            "caveats": [] if counts.get("unknown", 0) == 0 else [
                f"另有 {counts.get('unknown', 0)} 条情感未知，仍计入分母"],
        })

    # 2) 趋势（Mann-Kendall + Sen）
    mk = trend.get("mann_kendall") or {}
    slope_info = trend.get("sens_slope") or {}
    direction = trend.get("direction")
    bucket_n = len(buckets)
    if bucket_n >= MIN_TREND_BUCKETS and mk.get("n"):
        slope = float(slope_info.get("slope", 0.0) or 0.0)
        p_value = float(mk.get("p_value", 1.0) or 1.0)
        trend_word = {"rising": "上升", "falling": "下降"}.get(direction)
        # 斜率很小时 2 位小数会显示成 +0.00，读起来像"上升但幅度为零"。
        # 分档：显著但幅度可忽略时明说"幅度不足以线性外推"，不硬套上升/下降。
        tiny = abs(slope) < 0.01
        slope_text = f"{slope:+.4f}" if tiny else f"{slope:+.2f}"
        if trend_word and tiny:
            statement = (f"记录数在时间窗内呈{trend_word}的单调次序"
                         f"（Mann-Kendall S={mk.get('s')}，p={p_value:.4f}），"
                         f"但 Sen 中位斜率≈0（{slope_text} 条/桶），"
                         f"幅度不足以作线性外推")
        elif trend_word:
            statement = (f"日均记录数呈{trend_word}趋势"
                         f"（Mann-Kendall S={mk.get('s')}，p={p_value:.4f}；"
                         f"Sen 斜率 {slope_text} 条/桶）")
        else:
            statement = (f"未检测到显著单调趋势（Mann-Kendall p={p_value:.3f}，"
                         f"Sen 斜率 {slope_text} 条/桶），不能解读为上升或下降")
        base_confidence = _confidence(n, source_count, min_sample)
        if trend_word:
            confidence = base_confidence
            if not (p_value < 0.01 and bucket_n >= 7) and confidence == "high":
                confidence = "medium"
            if tiny and confidence == "high":
                confidence = "medium"
        else:
            # "未检测到显著趋势"受检验功效限制，样本再大也只给 medium
            confidence = "medium" if base_confidence != "low" else "low"
        conclusions.append({
            "statement": statement,
            "confidence": confidence,
            "method": "Mann-Kendall 趋势检验 + Sen 斜率",
            "n": n,
            "evidence": [
                f"Mann-Kendall S={mk.get('s')}，z={mk.get('z')}，p={p_value:.4f}",
                f"Sen 斜率 {slope:+.4f} 条/桶，截距 {slope_info.get('intercept')}",
                f"时间桶 {bucket_n} 个",
            ],
            "caveats": (["趋势只说明单调方向，不说明幅度与原因"]
                        + (["Sen 斜率接近 0：显著的是单调次序，不是变化幅度"]
                           if tiny else [])),
        })

    # 3) 前后半段情感比例对比（两比例 z 检验）
    if bucket_n >= 4:
        dates = [b.get("date") for b in buckets]
        index_by_date = {d: i for i, d in enumerate(dates)}
        mid = bucket_n // 2
        first_n = first_pos = second_n = second_pos = 0
        sentiments = [r.get("sentiment") for r in used]
        for i, ts in enumerate(parsed):
            if ts is None:
                continue
            idx = index_by_date.get(ts.date().isoformat())
            if idx is None:
                continue
            is_pos = sentiments[i] == "positive"
            if idx < mid:
                first_n += 1
                first_pos += 1 if is_pos else 0
            else:
                second_n += 1
                second_pos += 1 if is_pos else 0
        if first_n >= 5 and second_n >= 5:
            test = two_proportion_z_test(first_pos, first_n, second_pos, second_n)
            share1 = first_pos / first_n
            share2 = second_pos / second_n
            conclusions.append({
                "statement": (
                    f"前半段正面比例 {share1:.1%}（{first_pos}/{first_n}）vs "
                    f"后半段 {share2:.1%}（{second_pos}/{second_n}），"
                    f"差异{'显著' if test['significant'] else '不显著'}"
                    f"（两比例 z 检验 z={test['z']:.2f}，p={test['p_value']:.3f}）"
                ),
                "confidence": _confidence(first_n + second_n, source_count, min_sample),
                "method": "两比例 z 检验",
                "n": first_n + second_n,
                "evidence": [
                    f"正面比例差 {test['diff']:+.2%}",
                    f"p={test['p_value']:.4f}（alpha=0.05）",
                ],
                "caveats": ["前后半段按时间桶等分，不是随机分组"],
            })

    # 4) 异常时点（稳健 z）
    if anomalies:
        conclusions.append({
            "statement": f"检测到 {len(anomalies)} 个异常时点（稳健 z >= {ANOMALY_Z}）",
            "confidence": _confidence(n, source_count, min_sample),
            "method": "稳健 z-score（MAD）",
            "n": n,
            "evidence": [
                f"{a.get('date')}：{a.get('count')} 条（z={a.get('z')}，{a.get('kind')}）"
                for a in anomalies[:3]
            ],
            "caveats": ["异常可能来自当日重大事件，也可能来自抓取时段偏差，需回原始来源核对"],
        })
    return conclusions


def _build_cannot_conclude(n_used: int, source_count: int, bucket_n: int,
                           unknown_time: int,
                           min_sample: int) -> List[Dict[str, str]]:
    """生成"不能下的结论"，每条都说明具体原因，而不是笼统免责。"""
    out: List[Dict[str, str]] = []
    if n_used < min_sample:
        out.append({
            "statement": "基于比例/排名的结论（如“某情感占主导”“某标的排第几”）",
            "reason": (f"有效样本 n={n_used} < 最小样本 {min_sample}，"
                       f"Wilson 区间过宽，排名差异无法与随机波动区分"),
        })
    if source_count < 2:
        out.append({
            "statement": "跨源一致性/交叉验证类结论",
            "reason": (f"有效具名来源仅 {source_count} 个，无法排除单一来源的"
                       f"选材、口径与利益相关性偏差"),
        })
    if bucket_n < MIN_TREND_BUCKETS:
        out.append({
            "statement": "趋势方向/拐点类结论",
            "reason": (f"时间桶仅 {bucket_n} 个（<{MIN_TREND_BUCKETS}），"
                       f"Mann-Kendall 检验功效不足"),
        })
    if unknown_time:
        out.append({
            "statement": "时间分布/峰值时点类结论",
            "reason": f"{unknown_time} 条记录发布时间无法解析，未参与时间过滤与分桶",
        })
    out.append({
        "statement": "因果关系结论（如“X 导致 Y”）",
        "reason": "本模块只做描述统计与单调趋势检验，未做因果识别（无对照/工具变量/自然实验）",
    })
    return out


def _build_caveats(n_used: int, duplicates_removed: int, out_of_window: int,
                   unknown_time: int, source_count: int, bucket_n: int) -> List[str]:
    caveats: List[str] = []
    if n_used == 0:
        caveats.append("没有可用记录，未执行任何统计推断。")
        return caveats
    caveats.append("样本为爬取快照，非概率抽样；比例与置信区间只描述本批次，不能外推为总体。")
    if duplicates_removed:
        caveats.append(f"去重删除 {duplicates_removed} 条完全重复记录（URL / 来源+标题）。")
    if out_of_window:
        caveats.append(f"{out_of_window} 条记录早于时间窗，已从统计中剔除。")
    if unknown_time:
        caveats.append(f"{unknown_time} 条记录时间无法解析：保留在分布里，但不参与趋势分桶与过滤。")
    if source_count < 2:
        caveats.append("仅单一来源（或来源缺失），缺少跨源交叉验证。")
    if bucket_n < MIN_TREND_BUCKETS:
        caveats.append(f"时间桶仅 {bucket_n} 个，未达 {MIN_TREND_BUCKETS} 个，不做趋势方向判断。")
    caveats.append("Wilson 区间基于二项分布正态近似，极小样本时偏窄；趋势检验只说明单调性，不说明幅度。")
    return caveats


# ============================================================================
# 4. analyze_records 主入口
# ============================================================================

def _empty_result(ref_now: datetime, days: int, min_sample: int,
                  started: float) -> Dict[str, Any]:
    """空/无可用记录时也保持与正常结果完全一致的键形状。"""
    return {
        "ok": False,
        "error_code": "E_NO_RECORDS",
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 2),
        "n_input": 0,
        "n_used": 0,
        "n_filtered": 0,
        "days": days,
        "as_of": ref_now.isoformat(timespec="seconds"),
        "quality": {
            "score": 0.0, "grade": "D", "n": 0, "unique": 0,
            "duplicates_removed": 0, "source_count": 0, "sources": [],
            "time_span_days": 0.0,
            "completeness": {"title": 0.0, "summary": 0.0, "source": 0.0,
                             "publish_time": 0.0, "url": 0.0, "sentiment": 0.0},
            "issues": ["时间窗内没有可用记录"],
            "unknown_time": 0, "invalid_ignored": 0, "out_of_window": 0,
        },
        "distribution": {
            "sentiment": {
                "counts": {"positive": 0, "neutral": 0, "negative": 0, "unknown": 0},
                "shares": {"positive": 0.0, "neutral": 0.0, "negative": 0.0, "unknown": 0.0},
                "ci95": {"positive": wilson_interval(0, 0),
                         "negative": wilson_interval(0, 0)},
            },
            "severity": {},
            "sources": {},
        },
        "trend": {
            "buckets": [],
            "direction": "insufficient_data",
            "mann_kendall": mann_kendall([]),
            "sens_slope": sen_slope([]),
            "change_vs_baseline": None,
        },
        "anomalies": [],
        "keywords": [],
        "conclusions": [],
        "cannot_conclude": [{
            "statement": "任何统计结论（比例、排名、趋势）",
            "reason": "没有可用记录（E_NO_RECORDS），无法做统计推断",
        }],
        "caveats": ["没有可用记录，未执行任何统计推断。"],
        "methods": list(METHODS),
    }


def analyze_records(records: Sequence[Dict[str, Any]], days: int = 7,
                    now: Any = None, min_sample: int = 10,
                    baseline: Any = None) -> Dict[str, Any]:
    """把一批异构爬取记录收敛成固定结构的统计严谨性结果。

    规则（测试按这些规则验）：
    1. 字段归一：title / summary / content / source / source_name /
       publish_time / time / date / url / sentiment / severity，缺字段不报错。
    2. 去重：先按 url，再按（source, title）完全相同；删除数记入
       quality.duplicates_removed。非 dict 记录忽略并记入 issues。
    3. 时间窗：days>0 表示"最近 days 个自然日（含当天 00:00 起）"；
       publish_time 解析失败的记录**不参与过滤**（保留，计入 unknown_time），
       days<=0 不过滤。
    4. 样本 < min_sample：至少一条结论 confidence="low"（实际全部强制 low），
       且 cannot_conclude 必含"比例/排名"类。
    5. 来源 <2：cannot_conclude 必含"跨源一致性/交叉验证"。
    6. 趋势桶 <4：trend.direction="insufficient_data"，caveats 说明原因。
    7. 异常：稳健 z>=3.5 记为 anomaly（date/count/z/kind）。
    8. 关键词：优先复用 analysis_enhanced.extract_keywords，失败降级 bigram。
    9. 空输入：ok=False、error_code="E_NO_RECORDS"，其余键保持同形状。

    Args:
        records: 原始记录列表（list[dict]）
        days: 时间窗（自然日数，含当天）；<=0 表示不按时间过滤
        now: 参考时间（datetime / 时间戳 / 时间串），默认当前时间
        min_sample: 最小有效样本量，用于结论分级与"不能下结论"判定
        baseline: 上一期计数（数字或含 previous/count/total/n 的 dict），可空

    Returns:
        dict，固定键：ok, error_code, elapsed_ms, n_input, n_used,
        n_filtered, days, as_of, quality, distribution, trend, anomalies,
        keywords, conclusions, cannot_conclude, caveats, methods。
    """
    started = time.perf_counter()
    ref_now = _coerce_now(now)
    try:
        days_int = int(days)
    except (TypeError, ValueError):
        days_int = 7
    try:
        min_sample_int = max(1, int(min_sample))
    except (TypeError, ValueError):
        min_sample_int = 10

    raw: List[Any] = []
    if records is not None:
        try:
            raw = list(records)
        except TypeError:
            raw = []
    n_input = len(raw)
    if n_input == 0:
        return _empty_result(ref_now, days_int, min_sample_int, started)

    normalized: List[Dict[str, str]] = []
    invalid_ignored = 0
    for item in raw:
        if isinstance(item, dict):
            normalized.append(normalize_record(item))
        else:
            invalid_ignored += 1

    deduped, duplicates_removed = _dedupe_records(normalized)

    # 时间过滤：解析失败的记录保留（不参与过滤），但计入 unknown_time
    cutoff: Optional[datetime] = None
    if days_int > 0:
        cutoff = datetime(ref_now.year, ref_now.month, ref_now.day) - timedelta(
            days=days_int - 1)
    used: List[Dict[str, str]] = []
    parsed: List[Optional[datetime]] = []
    unknown_time = 0
    out_of_window = 0
    for rec in deduped:
        ts = _parse_ts(rec.get("publish_time"))
        if ts is None:
            unknown_time += 1
            used.append(rec)
            parsed.append(None)
            continue
        if cutoff is not None and ts < cutoff:
            out_of_window += 1
            continue
        used.append(rec)
        parsed.append(ts)

    n_used = len(used)
    if n_used == 0:
        result = _empty_result(ref_now, days_int, min_sample_int, started)
        result.update({
            "ok": False,
            "error_code": "E_NO_RECORDS",
            "n_input": n_input,
            "n_used": 0,
            "n_filtered": n_input,
            "quality": {
                "score": 0.0, "grade": "D", "n": 0, "unique": 0,
                "duplicates_removed": duplicates_removed,
                "source_count": 0, "sources": [], "time_span_days": 0.0,
                "completeness": {"title": 0.0, "summary": 0.0, "source": 0.0,
                                 "publish_time": 0.0, "url": 0.0, "sentiment": 0.0},
                "issues": ["时间窗内没有可用记录"],
                "unknown_time": unknown_time,
                "invalid_ignored": invalid_ignored,
                "out_of_window": out_of_window,
            },
            "caveats": ["时间窗内没有可用记录，未执行任何统计推断。"],
        })
        result["elapsed_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
        return result

    # 分布
    senti_counts = {"positive": 0, "neutral": 0, "negative": 0, "unknown": 0}
    for rec in used:
        senti_counts[rec.get("sentiment") or "unknown"] += 1
    shares = {k: round(v / float(n_used), 4) for k, v in senti_counts.items()}
    distribution = {
        "sentiment": {
            "counts": senti_counts,
            "shares": shares,
            "ci95": {
                "positive": wilson_interval(senti_counts["positive"], n_used),
                "negative": wilson_interval(senti_counts["negative"], n_used),
            },
        },
        "severity": dict(Counter(
            (rec.get("severity") or "unknown") for rec in used).most_common()),
        "sources": dict(Counter(
            (rec.get("source") or "未知来源") for rec in used).most_common()),
    }

    # 时间桶 / 趋势 / 异常
    buckets = _build_buckets(parsed, ref_now, days_int)
    counts = [int(b["count"]) for b in buckets]
    mk = mann_kendall(counts)
    slope = sen_slope([(i, c) for i, c in enumerate(counts)])
    if len(buckets) < MIN_TREND_BUCKETS:
        direction = "insufficient_data"
    else:
        direction = mk["trend"]
    anomalies: List[Dict[str, Any]] = []
    if counts:
        zs = robust_zscores(counts)
        for i, (bucket, z) in enumerate(zip(buckets, zs)):
            if abs(z) >= ANOMALY_Z:
                anomalies.append({
                    "date": bucket["date"],
                    "count": counts[i],
                    "z": round(z, 2),
                    "kind": "spike" if z > 0 else "dip",
                })
    trend = {
        "buckets": buckets,
        "direction": direction,
        "mann_kendall": mk,
        "sens_slope": slope,
        "change_vs_baseline": _change_vs_baseline(baseline, n_used),
    }

    # 质量 / 关键词 / 结论
    valid_times = [ts for ts in parsed if ts is not None]
    if valid_times:
        time_span_days = (max(valid_times) - min(valid_times)).total_seconds() / 86400.0
    else:
        time_span_days = 0.0
    quality = _quality_view(
        used, n_input, duplicates_removed, invalid_ignored, out_of_window,
        unknown_time, min_sample_int, days_int, time_span_days)
    source_count = int(quality["source_count"])
    keywords = _extract_keywords(used)
    conclusions = _build_conclusions(
        used, distribution, trend, source_count, min_sample_int,
        anomalies, parsed, buckets)
    cannot_conclude = _build_cannot_conclude(
        n_used, source_count, len(buckets), unknown_time, min_sample_int)
    caveats = _build_caveats(
        n_used, duplicates_removed, out_of_window, unknown_time,
        source_count, len(buckets))

    return {
        "ok": True,
        "error_code": "",
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 2),
        "n_input": n_input,
        "n_used": n_used,
        "n_filtered": n_input - n_used,
        "days": days_int,
        "as_of": ref_now.isoformat(timespec="seconds"),
        "quality": quality,
        "distribution": distribution,
        "trend": trend,
        "anomalies": anomalies,
        "keywords": keywords,
        "conclusions": conclusions,
        "cannot_conclude": cannot_conclude,
        "caveats": caveats,
        "methods": list(METHODS),
    }


# ============================================================================
# 5. Markdown 渲染
# ============================================================================

def _fmt_pct(value: Any) -> str:
    try:
        return f"{float(value):.1%}"
    except (TypeError, ValueError):
        return "n/a"


def _fmt_num(value: Any, digits: int = 4) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "n/a"
    if math.isnan(number) or math.isinf(number):
        return "n/a"
    return f"{number:.{digits}f}"


def _fmt_ci(ci: Any) -> str:
    if not isinstance(ci, dict):
        return "n/a"
    return f"{_fmt_pct(ci.get('low'))}–{_fmt_pct(ci.get('high'))}"


def render_analysis_markdown(result: Any) -> str:
    """把 analyze_records 的结果渲染成 Markdown 报告（空/失败也不抛异常）。

    小节：一句话结论 / 数据质量 / 分布（含 95% CI）/ 趋势（含 MK p 值）/
    异常 / 关键词 / 能下的结论 / 不能下的结论 / 方法与口径。
    """
    lines: List[str] = ["# 数据分析报告 · 统计严谨性", ""]
    if not isinstance(result, dict):
        lines.append("> ⚠ 无法渲染：分析结果不是字典（预期 analyze_records 的返回值）。")
        return "\n".join(lines) + "\n"

    ok = bool(result.get("ok"))
    error_code = str(result.get("error_code") or "")
    if not ok:
        lines.append(f"> ⚠ 本次分析未完成：{error_code or '未知错误'}。"
                     f"以下保留可交付的结构性信息，但不应据此下结论。")
        lines.append("")

    lines.append(
        f"> 生成时间：{result.get('as_of') or '未知'}；时间窗：{result.get('days')} 天；"
        f"有效样本 {result.get('n_used', 0)}/{result.get('n_input', 0)} 条；"
        f"耗时 {result.get('elapsed_ms', 0)} ms"
    )
    lines.append("")

    # 一句话结论
    lines.append("## 一句话结论")
    conclusions = result.get("conclusions")
    if isinstance(conclusions, list) and conclusions:
        first = conclusions[0] if isinstance(conclusions[0], dict) else {}
        lines.append(f"{first.get('statement') or '（结论缺少 statement 字段）'}"
                     f"（confidence={first.get('confidence', 'unknown')}）")
    elif not ok:
        lines.append(f"无法给出结论：{error_code or '分析未完成'}。")
    else:
        lines.append("无可用结论（样本不足或输入为空）。")
    lines.append("")

    # 数据质量
    lines.append("## 数据质量")
    quality = result.get("quality") if isinstance(result.get("quality"), dict) else {}
    lines.append(f"- 质量评分：{_fmt_num(quality.get('score'), 1)}/100"
                 f"（等级 {quality.get('grade', 'D')}）")
    lines.append(f"- 有效样本：{quality.get('n', 0)} 条（去重后独立记录 "
                 f"{quality.get('unique', 0)} 条，去重删除 "
                 f"{quality.get('duplicates_removed', 0)} 条）")
    lines.append(f"- 来源数：{quality.get('source_count', 0)}；时间跨度："
                 f"{_fmt_num(quality.get('time_span_days'), 2)} 天")
    completeness = quality.get("completeness")
    if isinstance(completeness, dict) and completeness:
        parts = [f"{field}={_fmt_pct(rate)}"
                 for field, rate in completeness.items()]
        lines.append("- 字段完整度：" + "、".join(parts))
    issues = quality.get("issues")
    if isinstance(issues, list) and issues:
        lines.append("- 已知问题：")
        for issue in issues:
            lines.append(f"  - {issue}")
    else:
        lines.append("- 已知问题：无")
    lines.append("")

    # 分布
    lines.append("## 分布（95% Wilson 置信区间）")
    distribution = result.get("distribution") if isinstance(result.get("distribution"), dict) else {}
    sentiment = distribution.get("sentiment") if isinstance(distribution.get("sentiment"), dict) else {}
    counts = sentiment.get("counts") if isinstance(sentiment.get("counts"), dict) else {}
    shares = sentiment.get("shares") if isinstance(sentiment.get("shares"), dict) else {}
    ci95 = sentiment.get("ci95") if isinstance(sentiment.get("ci95"), dict) else {}
    label = {"positive": "正面", "neutral": "中性", "negative": "负面", "unknown": "未知"}
    lines.append("| 情感 | 计数 | 占比 | 95% CI |")
    lines.append("| --- | ---: | ---: | --- |")
    for key in ("positive", "neutral", "negative", "unknown"):
        ci = ci95.get(key)
        lines.append(f"| {label[key]} | {counts.get(key, 0)} | "
                     f"{_fmt_pct(shares.get(key, 0.0))} | "
                     f"{_fmt_ci(ci) if ci else '—'} |")
    severity = distribution.get("severity")
    if isinstance(severity, dict) and severity:
        lines.append("")
        lines.append("严重程度：" + "、".join(
            f"{name}×{count}" for name, count in severity.items()))
    sources = distribution.get("sources")
    if isinstance(sources, dict) and sources:
        lines.append("")
        lines.append("来源分布：" + "、".join(
            f"{name}×{count}" for name, count in list(sources.items())[:10]))
    lines.append("")

    # 趋势
    lines.append("## 趋势")
    trend = result.get("trend") if isinstance(result.get("trend"), dict) else {}
    mk = trend.get("mann_kendall") if isinstance(trend.get("mann_kendall"), dict) else {}
    slope = trend.get("sens_slope") if isinstance(trend.get("sens_slope"), dict) else {}
    direction_label = {
        "rising": "上升", "falling": "下降", "no_trend": "无显著单调趋势",
        "insufficient_data": "数据不足（不做趋势判断）",
    }.get(str(trend.get("direction")), str(trend.get("direction") or "未知"))
    lines.append(f"- 方向：{direction_label}")
    lines.append(f"- Mann-Kendall：S={mk.get('s', 'n/a')}，z={_fmt_num(mk.get('z'), 3)}，"
                 f"p={_fmt_num(mk.get('p_value'), 4)}（n={mk.get('n', 0)} 个时间桶）")
    lines.append(f"- Sen 斜率：{_fmt_num(slope.get('slope'), 4)} 条/桶，"
                 f"截距 {_fmt_num(slope.get('intercept'), 2)}")
    buckets = trend.get("buckets")
    if isinstance(buckets, list) and buckets:
        points = "、".join(f"{b.get('date')}={b.get('count')}"
                           for b in buckets if isinstance(b, dict))
        lines.append(f"- 时间桶（自然日零填充）：{points}")
    change = trend.get("change_vs_baseline")
    if isinstance(change, dict):
        delta = change.get("delta_pct")
        delta_text = f"{float(delta):+.1f}%" if isinstance(delta, (int, float)) else "n/a"
        lines.append(f"- 对比基线：上期 {change.get('previous')} → 本期 "
                     f"{change.get('current')}（{delta_text}）")
    else:
        lines.append("- 对比基线：未提供")
    lines.append("")

    # 异常
    lines.append("## 异常")
    anomalies = result.get("anomalies")
    if isinstance(anomalies, list) and anomalies:
        for item in anomalies:
            if not isinstance(item, dict):
                continue
            lines.append(f"- {item.get('date')}：{item.get('count')} 条"
                         f"（稳健 z={item.get('z')}，{item.get('kind')}）")
    else:
        lines.append("未检测到 |稳健 z| >= 3.5 的异常时点。")
    lines.append("")

    # 关键词
    lines.append("## 关键词")
    keywords = result.get("keywords")
    if isinstance(keywords, list) and keywords:
        for item in keywords[:15]:
            if not isinstance(item, dict):
                continue
            lines.append(f"- {item.get('term')}（{item.get('count')} 次，"
                         f"权重 {_fmt_num(item.get('weight'), 4)}）")
    else:
        lines.append("无可用关键词（文本过短或全部为停用词）。")
    lines.append("")

    # 能下的结论
    lines.append("## 能下的结论")
    if isinstance(conclusions, list) and conclusions:
        for idx, item in enumerate(conclusions, start=1):
            if not isinstance(item, dict):
                continue
            lines.append(f"{idx}. {item.get('statement')}"
                         f"（confidence={item.get('confidence', 'low')}，"
                         f"method={item.get('method', 'n/a')}，n={item.get('n', 'n/a')}）")
            evidence = item.get("evidence")
            if isinstance(evidence, list):
                for ev in evidence:
                    lines.append(f"   - 证据：{ev}")
            item_caveats = item.get("caveats")
            if isinstance(item_caveats, list):
                for caveat in item_caveats:
                    lines.append(f"   - 限制：{caveat}")
    else:
        lines.append("无（样本不足或没有可验证的统计结论）。")
    lines.append("")

    # 不能下的结论
    lines.append("## 不能下的结论")
    cannot = result.get("cannot_conclude")
    if isinstance(cannot, list) and cannot:
        for item in cannot:
            if not isinstance(item, dict):
                continue
            lines.append(f"- {item.get('statement')} —— 原因：{item.get('reason')}")
    else:
        lines.append("无。")
    lines.append("")

    # 方法与口径
    lines.append("## 方法与口径")
    methods = result.get("methods")
    if isinstance(methods, list) and methods:
        for method in methods:
            lines.append(f"- {method}")
    else:
        lines.append(f"- {METHODS[0]}")
    caveats = result.get("caveats")
    if isinstance(caveats, list) and caveats:
        lines.append("")
        lines.append("补充限制：")
        for caveat in caveats:
            lines.append(f"- {caveat}")
    return "\n".join(lines) + "\n"


# ============================================================================
# 6. 自检
# ============================================================================

def _self_check_records() -> List[Dict[str, Any]]:
    """自检用固定样本：12 条、3 源、7 天内（不依赖网络与当前时间）。"""
    base = datetime(2026, 11, 6, 9, 0, 0)
    sources = ("上海证券报", "中国证券报", "证券时报")
    sentiments = ("positive", "neutral", "negative")
    records: List[Dict[str, Any]] = []
    for i in range(12):
        ts = base - timedelta(days=i % 7, hours=i % 5)
        records.append({
            "title": f"银行板块流动性观察第{i}期，市场关注净息差",
            "summary": "银行板块流动性边际改善，市场关注净息差与资产质量变化。",
            "source": sources[i % 3],
            "publish_time": ts.strftime("%Y-%m-%d %H:%M:%S"),
            "url": f"https://example.com/news/{i}",
            "sentiment": sentiments[i % 3],
            "severity": ("high", "medium", "low")[i % 3],
        })
    return records


def self_check() -> Dict[str, Any]:
    """无网络自检：验证五个统计原语、空输入与形状约束。"""
    checks: Dict[str, bool] = {}
    errors: List[str] = []

    def run(name: str, fn) -> None:
        try:
            passed = bool(fn())
        except Exception as exc:  # noqa: BLE001 - 自检必须收集异常而不是炸掉
            checks[name] = False
            errors.append(f"E_SELF_CHECK: {name} 抛异常 "
                          f"{type(exc).__name__}: {exc}")
            return
        checks[name] = passed
        if not passed:
            errors.append(f"E_SELF_CHECK: {name} 未通过")

    def _wilson() -> bool:
        mid = wilson_interval(5, 10)
        zero = wilson_interval(0, 0)
        return (abs(mid["low"] - 0.2366) < 2e-3
                and abs(mid["high"] - 0.7634) < 2e-3
                and abs(mid["point"] - 0.5) < 1e-9
                and zero["low"] == zero["high"] == zero["point"] == 0.0)

    def _mann_kendall() -> bool:
        rising = mann_kendall(list(range(1, 11)))
        short = mann_kendall([1, 2])
        return (rising["trend"] == "rising" and rising["p_value"] < 0.05
                and rising["n"] == 10
                and short["trend"] == "insufficient_data")

    def _sen_slope() -> bool:
        fit = sen_slope([(0, 1), (1, 3), (2, 5), (3, 7)])
        return (abs(fit["slope"] - 2.0) < 1e-6
                and abs(fit["intercept"] - 1.0) < 1e-6)

    def _robust() -> bool:
        zs = robust_zscores(list(range(1, 11)) + [100])
        flat = robust_zscores([5, 5, 5])
        return (len(zs) == 11 and abs(zs[-1]) > 3.5 and abs(zs[5]) < 1e-9
                and flat == [0.0, 0.0, 0.0])

    def _two_proportion() -> bool:
        big = two_proportion_z_test(80, 100, 20, 100)
        small = two_proportion_z_test(50, 100, 55, 100)
        empty = two_proportion_z_test(0, 0, 0, 0)
        return (big["significant"] and not small["significant"]
                and empty["p_value"] == 1.0 and empty["z"] == 0.0)

    def _empty() -> bool:
        result = analyze_records([])
        rendered = render_analysis_markdown(result)
        return (result["ok"] is False and result["error_code"] == "E_NO_RECORDS"
                and isinstance(rendered, str) and "统计严谨性" in rendered)

    def _shape() -> bool:
        result = analyze_records(_self_check_records(), days=7,
                                 now=datetime(2026, 11, 6, 12, 0, 0))
        if not result["ok"]:
            return False
        if result["quality"]["grade"] not in ("A", "B", "C", "D"):
            return False
        if not result["distribution"]["sentiment"]["ci95"]["positive"]:
            return False
        if not result["conclusions"]:
            return False
        for item in result["conclusions"]:
            if not all(key in item for key in ("statement", "confidence",
                                               "method", "n", "evidence", "caveats")):
                return False
        return len(result["trend"]["buckets"]) == 7

    run("wilson_interval", _wilson)
    run("mann_kendall", _mann_kendall)
    run("sen_slope", _sen_slope)
    run("robust_zscores", _robust)
    run("two_proportion_z_test", _two_proportion)
    run("analyze_empty", _empty)
    run("analyze_shape", _shape)
    return {
        "ok": all(checks.values()),
        "checks": checks,
        "errors": errors,
    }


if __name__ == "__main__":
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))
