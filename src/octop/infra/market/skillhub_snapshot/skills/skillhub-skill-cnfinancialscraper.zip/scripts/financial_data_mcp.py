# -*- coding: utf-8 -*-
"""
金融数据 MCP 桥接模块 v12.1.0 (financial_data_mcp.py)

统一接入多源权威金融数据，按优先级自动选择最佳数据源。
设计原则：
1. 优先使用结构化 API（零爬虫风险）
2. 自动降级到备用数据源
3. 结果标准化为统一格式
4. 所有查询经过反爬管道保护

支持的数据源层级：
  Layer 0: akshare（权威结构化数据，13000+接口）
  Layer 1: 直连官方 API（东方财富/新浪/巨潮等公开接口）
  Layer 2: yfinance（全球市场数据）
  Layer 3: RSS / RSSHub 公开信息流
  Layer 4: 搜索引擎聚合兜底

v12.1.0 数据获取强化（新增能力全部向后兼容，旧调用签名不变）：
  - QueryResult 追加 as_of / fresh / stale / cache_hit / error_code /
    attempts / quality（新字段全部追加在末尾，位置构造不变）
  - 进程内缓存（按查询类型 TTL）+ 全源失败后的陈旧兜底（stale fallback）
  - 熔断指数退避：连续失败 3 次起冷却 30s，逐次翻倍，上限 600s
  - deadline_ms 整次查询预算；批量查询 query_many（并发、保序）
  - 健康快照 save_health / _load_health 往返（JSON，UTF-8）
"""
from __future__ import annotations

import copy
import json
import logging
import os
import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, asdict, replace
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

log = logging.getLogger(__name__)

# ============================================================================
# 1. 数据源枚举与注册
# ============================================================================

class DataSource(Enum):
    """支持的金融数据源。"""
    AKSHARE = auto()        # akshare — 中国金融数据之王
    EASTMONEY_API = auto()  # 东方财富直连 API
    SINA_HQ = auto()        # 新浪行情接口
    YAHOO_FINANCE = auto()  # yfinance (Yahoo Finance)
    FINNHUB = auto()        # Finnhub（美股/全球）
    ALPHA_VANTAGE = auto()  # Alpha Vantage
    TUSHARE = auto()        # Tushare（需token）
    RSS_FEEDS = auto()      # RSS 信息流
    SEARCH_FALLBACK = auto()# 搜索引擎兜底
    CNINFO = auto()         # 巨潮资讯（公告/报告）
    SSE_SZSE = auto()       # 上交所/深交所官方
    CSRC = auto()           # 证监会
    PBOC = auto()           # 央行
    MOF = auto()            # 财政部
    SAFE = auto()           # 外汇管理局
    NBS = auto()            # 国家统计局
    COINGECKO = auto()      # CoinGecko（无需 key 的加密币行情）
    EXCHANGERATE = auto()   # exchangerate.host（无需 key 的外汇）
    TENCENT_RT = auto()     # 腾讯实时行情（realtime_data_hub，强制绕开 HTTP 缓存）


@dataclass
class SourceHealth:
    """数据源健康状态。"""
    source: DataSource
    available: bool = True
    last_success: Optional[str] = None
    last_failure: Optional[str] = None
    consecutive_failures: int = 0
    total_queries: int = 0
    total_success: int = 0
    avg_latency_ms: float = 0.0
    priority: int = 0  # 越高越优先

    @property
    def success_rate(self) -> float:
        return self.total_success / self.total_queries if self.total_queries else 0.0


# ============================================================================
# 2. 数据源能力注册表
# ============================================================================

# 每个数据源支持的查询类型
SOURCE_CAPABILITIES: Dict[DataSource, List[str]] = {
    DataSource.AKSHARE: [
        "stock_quote", "fund_nav", "fund_list", "fund_manager",
        "bond_yield", "futures", "macro_gdp", "macro_cpi", "macro_ppi",
        "macro_pmi", "shibor", "repo_rate", "forex", "etf_flow",
        "margin_trading", "block_trade", "dragon_tiger",
        "hk_stock", "us_stock", "convertible_bond",
        "industry_board", "concept_board", "stock_financial",
        "etf_list", "etf_realtime", "index_quote",
        "macro_money_supply", "macro_social_financing",
        "macro_trade_balance", "macro_fdi",
        "bse_stock", "neeq_stock",
    ],
    DataSource.EASTMONEY_API: [
        "stock_quote", "fund_nav", "fund_list", "news",
        "announcements", "margin_trading", "block_trade",
        "etf_flow", "dragon_tiger", "shareholder_change",
        "stock_financial", "industry_board", "index_quote",
    ],
    DataSource.SINA_HQ: [
        "stock_quote", "index_quote", "hk_stock", "us_stock",
        "forex", "futures",
    ],
    DataSource.YAHOO_FINANCE: [
        "stock_quote", "us_stock", "stock_financial",
        "etf_list", "fund_nav", "index_quote",
        "hk_stock", "forex", "futures",
    ],
    DataSource.FINNHUB: [
        "stock_quote", "us_stock", "stock_financial",
        "news", "earnings",
    ],
    DataSource.ALPHA_VANTAGE: [
        "stock_quote", "us_stock", "forex", "futures",
        "stock_financial",
        "crypto_daily_vantage", "fx_daily_vantage", "av_stock_daily",
    ],
    DataSource.TUSHARE: [
        "stock_quote", "fund_nav", "fund_list",
        "stock_financial", "announcements", "macro_gdp",
        "tushare_stock_basic", "tushare_daily", "tushare_daily_basic",
        "tushare_income", "tushare_balancesheet", "tushare_cashflow",
        "tushare_fund_basic", "tushare_fund_nav",
        "tushare_index_basic", "tushare_index_daily",
        "tushare_futures_basic", "tushare_fut_daily",
    ],
    DataSource.CNINFO: [
        "announcements", "company_report",
    ],
    DataSource.SSE_SZSE: [
        "announcements", "stock_list",
    ],
    DataSource.PBOC: [
        "macro_money_supply", "shibor", "repo_rate",
        "lpr_rate", "bond_yield",
    ],
    DataSource.NBS: [
        "macro_gdp", "macro_cpi", "macro_ppi", "macro_pmi",
        "macro_trade_balance", "macro_fdi",
    ],
    DataSource.RSS_FEEDS: [
        "news", "regulatory",
    ],
    DataSource.SEARCH_FALLBACK: [
        "news", "announcements", "stock_quote",
    ],
    DataSource.COINGECKO: [
        "crypto_quote", "crypto_markets", "crypto_history",
        "crypto_ohlc", "crypto_global", "crypto_trending",
    ],
    DataSource.EXCHANGERATE: [
        "forex_realtime", "forex_pair", "forex_all_rates",
    ],
    DataSource.TENCENT_RT: [
        "rt_quote", "rt_overview", "rt_kline", "rt_fund_estimate", "rt_board",
        "stock_quote", "index_quote",
    ],
}

# 查询类型 → 默认数据源优先级（列表第一个是最优）
SOURCE_PRIORITY: Dict[str, List[DataSource]] = {
    "stock_quote":       [DataSource.AKSHARE, DataSource.EASTMONEY_API, DataSource.SINA_HQ,
                          DataSource.TENCENT_RT, DataSource.YAHOO_FINANCE],
    "fund_nav":          [DataSource.AKSHARE, DataSource.EASTMONEY_API, DataSource.TUSHARE],
    "fund_list":         [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "fund_manager":      [DataSource.AKSHARE],
    "bond_yield":        [DataSource.AKSHARE, DataSource.PBOC],
    "futures":           [DataSource.AKSHARE, DataSource.SINA_HQ, DataSource.YAHOO_FINANCE],
    "macro_gdp":         [DataSource.AKSHARE, DataSource.NBS, DataSource.TUSHARE],
    "macro_cpi":         [DataSource.AKSHARE, DataSource.NBS],
    "macro_ppi":         [DataSource.AKSHARE, DataSource.NBS],
    "macro_pmi":         [DataSource.AKSHARE, DataSource.NBS],
    "shibor":            [DataSource.AKSHARE, DataSource.PBOC],
    "repo_rate":         [DataSource.AKSHARE, DataSource.PBOC],
    "forex":             [DataSource.AKSHARE, DataSource.SINA_HQ, DataSource.YAHOO_FINANCE],
    "etf_flow":          [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "margin_trading":    [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "block_trade":       [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "dragon_tiger":      [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "hk_stock":          [DataSource.AKSHARE, DataSource.SINA_HQ, DataSource.YAHOO_FINANCE],
    "us_stock":          [DataSource.YAHOO_FINANCE, DataSource.AKSHARE, DataSource.FINNHUB],
    "convertible_bond":  [DataSource.AKSHARE],
    "industry_board":    [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "concept_board":     [DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "stock_financial":   [DataSource.AKSHARE, DataSource.EASTMONEY_API, DataSource.YAHOO_FINANCE],
    "etf_list":          [DataSource.AKSHARE, DataSource.YAHOO_FINANCE],
    "etf_realtime":      [DataSource.AKSHARE],
    "index_quote":       [DataSource.AKSHARE, DataSource.SINA_HQ, DataSource.EASTMONEY_API],
    "news":              [DataSource.EASTMONEY_API, DataSource.RSS_FEEDS, DataSource.SEARCH_FALLBACK],
    "announcements":     [DataSource.CNINFO, DataSource.EASTMONEY_API, DataSource.SSE_SZSE],
    "company_report":    [DataSource.CNINFO],
    "shareholder_change":[DataSource.AKSHARE, DataSource.EASTMONEY_API],
    "macro_money_supply":[DataSource.AKSHARE, DataSource.PBOC],
    "lpr_rate":          [DataSource.AKSHARE, DataSource.PBOC],
    "regulatory":        [DataSource.RSS_FEEDS, DataSource.SEARCH_FALLBACK],
    "bse_stock":         [DataSource.AKSHARE],
    "neeq_stock":        [DataSource.AKSHARE],
    "earnings":          [DataSource.FINNHUB, DataSource.YAHOO_FINANCE],
    # v10 扩充轨：不写进这张表，router.query("crypto_quote") 只会得到
    # "All 0 sources exhausted"——适配器注册了也没人调用它。
    "crypto_quote":      [DataSource.COINGECKO, DataSource.ALPHA_VANTAGE],
    "crypto_markets":    [DataSource.COINGECKO],
    "crypto_history":    [DataSource.COINGECKO],
    "crypto_ohlc":       [DataSource.COINGECKO],
    "crypto_global":     [DataSource.COINGECKO],
    "crypto_trending":   [DataSource.COINGECKO],
    "crypto_daily_vantage": [DataSource.ALPHA_VANTAGE],
    "forex_realtime":    [DataSource.EXCHANGERATE, DataSource.SINA_HQ, DataSource.AKSHARE],
    "forex_pair":        [DataSource.EXCHANGERATE, DataSource.SINA_HQ],
    "forex_all_rates":   [DataSource.EXCHANGERATE],
    "fx_daily_vantage":  [DataSource.ALPHA_VANTAGE],
    "av_stock_daily":    [DataSource.ALPHA_VANTAGE, DataSource.YAHOO_FINANCE],
    "tushare_stock_basic": [DataSource.TUSHARE],
    "tushare_daily":     [DataSource.TUSHARE, DataSource.AKSHARE],
    "tushare_daily_basic": [DataSource.TUSHARE, DataSource.AKSHARE],
    "tushare_income":    [DataSource.TUSHARE, DataSource.AKSHARE],
    "tushare_balancesheet": [DataSource.TUSHARE],
    "tushare_cashflow":  [DataSource.TUSHARE],
    "tushare_fund_basic": [DataSource.TUSHARE],
    "tushare_fund_nav":  [DataSource.TUSHARE, DataSource.AKSHARE],
    "tushare_index_basic": [DataSource.TUSHARE],
    "tushare_index_daily": [DataSource.TUSHARE],
    "tushare_futures_basic": [DataSource.TUSHARE],
    "tushare_fut_daily": [DataSource.TUSHARE],
    # v11 实时轨：走 realtime_data_hub（多源 + 绕开 HTTP 缓存）
    "rt_quote":          [DataSource.TENCENT_RT, DataSource.SINA_HQ, DataSource.EASTMONEY_API],
    "rt_overview":       [DataSource.TENCENT_RT],
    "rt_kline":          [DataSource.EASTMONEY_API, DataSource.TENCENT_RT],
    "rt_fund_estimate":  [DataSource.EASTMONEY_API],
    "rt_board":          [DataSource.EASTMONEY_API],
}


# ============================================================================
# 2.5 v12.1：缓存 TTL / 熔断退避 / 批量查询参数
# ============================================================================

#: 每查询类型的内存缓存 TTL（秒）。实时行情 5s、基金净值 60s、
#: 资金/龙虎榜类 300s、宏观月度数据 3600s，其余 120s。
CACHE_TTL_BY_TYPE: Dict[str, float] = {
    "stock_quote": 5.0,
    "index_quote": 5.0,
    "etf_realtime": 5.0,
    "fund_nav": 60.0,
    "fund_estimate": 60.0,
    "dragon_tiger": 300.0,
    "margin_trading": 300.0,
    "block_trade": 300.0,
    "macro_gdp": 3600.0,
    "macro_cpi": 3600.0,
    "macro_ppi": 3600.0,
    "macro_pmi": 3600.0,
    "macro_money_supply": 3600.0,
    "macro_social_financing": 3600.0,
    "macro_trade_balance": 3600.0,
    "macro_fdi": 3600.0,
}

#: 未列出的查询类型默认缓存 120 秒；未单列的 macro_* 前缀统一 3600 秒。
CACHE_TTL_DEFAULT = 120.0
CACHE_TTL_MACRO = 3600.0

#: 缓存条目上限：超过后按写入时间淘汰最旧的四分之一，避免长期运行内存无界增长。
CACHE_MAX_ENTRIES = 1024

#: 熔断：连续失败达到阈值后冷却 30s，之后每多失败一次翻倍，上限 600s。
COOLDOWN_THRESHOLD = 3
COOLDOWN_BASE_SECONDS = 30.0
COOLDOWN_MAX_SECONDS = 600.0

#: 批量查询并发上限（防止一次 submit 出几百个线程）。
BATCH_MAX_WORKERS = 16

#: 健康快照文件的 schema 版本（_load_health 同时兼容无版本号的旧文件）。
HEALTH_SCHEMA_VERSION = "12.1"


def _ttl_for_query_type(query_type: str) -> float:
    """返回某查询类型的默认缓存 TTL（秒）。"""
    if query_type in CACHE_TTL_BY_TYPE:
        return CACHE_TTL_BY_TYPE[query_type]
    if isinstance(query_type, str) and query_type.startswith("macro_"):
        return CACHE_TTL_MACRO
    return CACHE_TTL_DEFAULT


def _cooldown_seconds(consecutive_failures: int) -> float:
    """熔断冷却时长：3 次失败→30s、4 次→60s、5 次→120s……上限 600s。

    连续失败 < 3 时返回 0.0（不冷却）。公式对测试可断言，不加随机抖动。
    """
    if consecutive_failures < COOLDOWN_THRESHOLD:
        return 0.0
    exponent = int(consecutive_failures) - COOLDOWN_THRESHOLD
    return min(COOLDOWN_BASE_SECONDS * (2 ** exponent), COOLDOWN_MAX_SECONDS)


def _is_empty_value(value: Any) -> bool:
    """判断一个叶子值是否算"缺失"：None / 空白字符串 / 空容器。"""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, (list, tuple, dict, set)):
        return len(value) == 0
    return False


def _count_leaves(value: Any) -> Tuple[int, int]:
    """递归统计叶子字段数与非空叶子数。"""
    if isinstance(value, dict):
        if not value:
            return 0, 0
        fields = 0
        non_null = 0
        for item in value.values():
            if isinstance(item, (dict, list, tuple)):
                sub_fields, sub_non_null = _count_leaves(item)
            else:
                sub_fields, sub_non_null = 1, (0 if _is_empty_value(item) else 1)
            fields += sub_fields
            non_null += sub_non_null
        return fields, non_null
    if isinstance(value, (list, tuple)):
        fields = 0
        non_null = 0
        for item in value:
            sub_fields, sub_non_null = _count_leaves(item)
            fields += sub_fields
            non_null += sub_non_null
        return fields, non_null
    return 1, (0 if _is_empty_value(value) else 1)


def compute_data_quality(data: Any) -> Dict[str, Any]:
    """尽力而为地统计 data 的完整度，返回数据质量字段。

    - list/tuple：items=元素个数，fields/non_null=各记录的叶子字段递归累加
    - dict：items=1（单条记录），字段递归展开
    - 其它：items=1、fields=1（None 或无法统计时返回 {}）

    Returns:
        {"items": n, "fields": k, "non_null": m, "completeness": 0.0-1.0}；
        统计过程绝不抛异常——质量统计失败不应该把一次成功的查询变成错误。
    """
    try:
        if data is None:
            return {}
        if isinstance(data, (list, tuple)):
            items = len(data)
            fields = 0
            non_null = 0
            for row in data:
                sub_fields, sub_non_null = _count_leaves(row)
                fields += sub_fields
                non_null += sub_non_null
        elif isinstance(data, dict):
            items = 1
            fields, non_null = _count_leaves(data)
        else:
            items = 1
            fields, non_null = 1, (0 if _is_empty_value(data) else 1)
        completeness = round(non_null / fields, 4) if fields else 0.0
        return {
            "items": items,
            "fields": fields,
            "non_null": non_null,
            "completeness": completeness,
        }
    except Exception as exc:  # noqa: BLE001 — 质量统计是尽力而为，绝不影响查询
        log.debug(f"compute_data_quality failed: {exc}")
        return {}


# ============================================================================
# 3. akshare 适配器
# ============================================================================

class AkshareAdapter:
    """akshare 数据源适配器 — 中国金融数据首选。"""

    def __init__(self):
        self._available = False
        self._ak = None
        self._check()

    def _check(self):
        try:
            import akshare as ak
            self._ak = ak
            self._available = True
        except ImportError:
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    def query(self, query_type: str, params: Dict[str, Any]) -> Optional[Any]:
        """路由查询到对应的 akshare 接口。"""
        if not self._available:
            return None

        try:
            fn = self._ROUTE_TABLE.get(query_type)
            if fn:
                return fn(self, params)
        except Exception as e:
            log.warning(f"akshare query '{query_type}' failed: {e}")
        return None

    def _q_stock_quote(self, params: Dict) -> Any:
        """A股实时行情。给了 code 就只返回那一只——
        原先三个分支都返回全市场 5000+ 行表，等于把筛选推回调用方。"""
        code = str(params.get("code", "") or "").strip()
        spot = self._ak.stock_zh_a_spot_em()
        if not code or spot is None:
            return spot
        try:
            col = "代码" if "代码" in spot.columns else spot.columns[1]
            hit = spot[spot[col].astype(str).str.zfill(6) == code.zfill(6)]
            return hit if not hit.empty else None
        except Exception as e:
            log.warning(f"stock_quote filter by {code} failed: {e}")
            return None

    def _q_fund_nav(self, params: Dict) -> Any:
        """基金净值历史。"""
        code = params.get("code", "")
        if code:
            return self._ak.fund_open_fund_info_em(symbol=code, indicator="单位净值走势")
        return None

    def _q_fund_list(self, params: Dict) -> Any:
        """基金列表。"""
        return self._ak.fund_name_em()

    def _q_fund_manager(self, params: Dict) -> Any:
        """基金经理信息。"""
        return self._ak.fund_manager()

    def _q_bond_yield(self, params: Dict) -> Any:
        """国债收益率曲线。"""
        return self._ak.bond_zh_us_rate(start_date=params.get("start", "20240101"))

    def _q_futures(self, params: Dict) -> Any:
        """期货现货数据。"""
        symbol = params.get("symbol", "全部")
        return self._ak.futures_zh_spot(symbol=symbol)

    def _q_macro_gdp(self, params: Dict) -> Any:
        """GDP 数据。"""
        return self._ak.macro_china_gdp()

    def _q_macro_cpi(self, params: Dict) -> Any:
        """CPI 数据。"""
        return self._ak.macro_china_cpi()

    def _q_macro_ppi(self, params: Dict) -> Any:
        """PPI 数据。"""
        return self._ak.macro_china_ppi()

    def _q_macro_pmi(self, params: Dict) -> Any:
        """PMI 数据。"""
        return self._ak.macro_china_pmi()

    def _q_shibor(self, params: Dict) -> Any:
        """Shibor 利率。"""
        return self._ak.rate_interbank(market="上海银行同业拆借市场", symbol="Shibor人民币", indicator="今日")

    def _q_repo_rate(self, params: Dict) -> Any:
        """回购利率。"""
        return self._ak.rate_interbank(market="中国银行同业拆借市场", symbol="Chibor人民币", indicator="今日")

    def _q_forex(self, params: Dict) -> Any:
        """外汇汇率。"""
        symbol = params.get("symbol", "美元兑人民币")
        return self._ak.fx_spot_quote()

    def _q_etf_flow(self, params: Dict) -> Any:
        """ETF 资金流向。"""
        return self._ak.fund_etf_fund_daily_em()

    def _q_margin_trading(self, params: Dict) -> Any:
        """融资融券。"""
        return self._ak.stock_margin_detail_szse()

    def _q_block_trade(self, params: Dict) -> Any:
        """大宗交易。"""
        return self._ak.stock_dzjy_sctj()

    def _q_dragon_tiger(self, params: Dict) -> Any:
        """龙虎榜。"""
        return self._ak.stock_lhb_detail_em()

    def _q_hk_stock(self, params: Dict) -> Any:
        """港股行情。"""
        return self._ak.stock_hk_spot_em()

    def _q_convertible_bond(self, params: Dict) -> Any:
        """可转债数据。"""
        return self._ak.bond_cb_jsl()

    def _q_industry_board(self, params: Dict) -> Any:
        """行业板块。"""
        return self._ak.stock_board_industry_name_em()

    def _q_concept_board(self, params: Dict) -> Any:
        """概念板块。"""
        return self._ak.stock_board_concept_name_em()

    def _q_stock_financial(self, params: Dict) -> Any:
        """股票财务数据。"""
        code = params.get("code", "")
        if code:
            return self._ak.stock_financial_abstract_ths(symbol=code)
        return None

    def _q_etf_list(self, params: Dict) -> Any:
        """ETF 列表。"""
        return self._ak.fund_etf_spot_em()

    def _q_etf_realtime(self, params: Dict) -> Any:
        """ETF 实时行情。"""
        return self._ak.fund_etf_spot_em()

    def _q_index_quote(self, params: Dict) -> Any:
        """指数行情。"""
        return self._ak.stock_zh_index_spot_em()

    def _q_shareholder_change(self, params: Dict) -> Any:
        """股东增减持。"""
        return self._ak.stock_dzjy_mrtj()

    def _q_macro_money_supply(self, params: Dict) -> Any:
        """货币供应量(M0/M1/M2)。"""
        return self._ak.macro_china_money_supply()

    def _q_lpr_rate(self, params: Dict) -> Any:
        """LPR 利率。"""
        return self._ak.macro_china_lpr()

    def _q_bse_stock(self, params: Dict) -> Any:
        """北交所股票。"""
        return self._ak.stock_bj_a_spot_em()

    def _q_us_stock(self, params: Dict) -> Any:
        """美股行情(通过 akshare)。"""
        symbol = params.get("symbol", "")
        if symbol:
            return self._ak.stock_us_spot_em()
        return self._ak.stock_us_spot_em()

    _ROUTE_TABLE = {
        "stock_quote": _q_stock_quote,
        "fund_nav": _q_fund_nav,
        "fund_list": _q_fund_list,
        "fund_manager": _q_fund_manager,
        "bond_yield": _q_bond_yield,
        "futures": _q_futures,
        "macro_gdp": _q_macro_gdp,
        "macro_cpi": _q_macro_cpi,
        "macro_ppi": _q_macro_ppi,
        "macro_pmi": _q_macro_pmi,
        "shibor": _q_shibor,
        "repo_rate": _q_repo_rate,
        "forex": _q_forex,
        "etf_flow": _q_etf_flow,
        "margin_trading": _q_margin_trading,
        "block_trade": _q_block_trade,
        "dragon_tiger": _q_dragon_tiger,
        "hk_stock": _q_hk_stock,
        "convertible_bond": _q_convertible_bond,
        "industry_board": _q_industry_board,
        "concept_board": _q_concept_board,
        "stock_financial": _q_stock_financial,
        "etf_list": _q_etf_list,
        "etf_realtime": _q_etf_realtime,
        "index_quote": _q_index_quote,
        "shareholder_change": _q_shareholder_change,
        "macro_money_supply": _q_macro_money_supply,
        "lpr_rate": _q_lpr_rate,
        "bse_stock": _q_bse_stock,
        "us_stock": _q_us_stock,
    }


# ============================================================================
# 4. 东方财富直连 API 适配器
# ============================================================================

class EastmoneyApiAdapter:
    """东方财富公开 API 适配器（直接 HTTP，不经过爬虫管道）。"""

    # 已知的公开 API 端点
    ENDPOINTS = {
        "stock_quote": "https://push2.eastmoney.com/api/qt/stock/get",
        "stock_list": "https://push2.eastmoney.com/api/qt/clist/get",
        "fund_nav": "https://api.fund.eastmoney.com/f10/lsjz",
        "margin_trading": "https://datacenter-web.eastmoney.com/api/data/v1/get",
        "block_trade": "https://datacenter-web.eastmoney.com/api/data/v1/get",
        "etf_flow": "https://push2.eastmoney.com/api/qt/clist/get",
        "dragon_tiger": "https://datacenter-web.eastmoney.com/api/data/v1/get",
        "news": "https://np-listapi.eastmoney.com/comm/web/getNewsByColumns",
        "announcements": "https://np-anotice-stock.eastmoney.com/api/security/ann",
        "index_quote": "https://push2.eastmoney.com/api/qt/ulist.np/get",
    }

    def __init__(self):
        self._session = None
        self._available = True

    @property
    def available(self) -> bool:
        return self._available

    def query(self, query_type: str, params: Dict[str, Any]) -> Optional[Any]:
        """路由查询到东方财富 API。"""
        try:
            endpoint = self.ENDPOINTS.get(query_type)
            if not endpoint:
                return None
            return self._fetch_api(endpoint, query_type, params)
        except Exception as e:
            log.warning(f"Eastmoney API '{query_type}' failed: {e}")
            return None

    def _fetch_api(self, endpoint: str, query_type: str, params: Dict) -> Optional[Dict]:
        """发起 API 请求。"""
        try:
            try:
                from http_utils import http_get_json
            except ImportError:
                from scripts.http_utils import http_get_json

            api_params = self._build_params(query_type, params)
            url = endpoint
            if api_params:
                from urllib.parse import urlencode
                url = f"{endpoint}?{urlencode(api_params)}"

            return http_get_json(url, timeout=15)
        except Exception as e:
            log.debug(f"Eastmoney API fetch failed: {e}")
            return None

    def _build_params(self, query_type: str, params: Dict) -> Dict:
        """根据查询类型构建 API 参数。"""
        code = params.get("code", "")

        if query_type == "stock_quote" and code:
            # 东方财富个股行情接口
            market = "1" if code.startswith("6") else "0"  # 1=沪 0=深
            return {
                "secid": f"{market}.{code}",
                "fields": "f43,f44,f45,f46,f47,f48,f50,f51,f52,f55,f57,f58,f60,f116,f117,f162,f167,f168,f169,f170",
                "ut": "fa5fd1943c7b386f172d6893dbbd1d0c",
            }
        elif query_type == "stock_list":
            return {
                "pn": str(params.get("page", 1)),
                "pz": str(params.get("size", 50)),
                "fs": "m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23",
                "fields": "f1,f2,f3,f4,f5,f6,f7,f12,f14",
            }
        elif query_type == "index_quote":
            return {
                "fields": "f2,f3,f4,f12,f14",
                "secids": "1.000001,0.399001,0.399006,1.000688,1.000300",
            }
        return {}


# ============================================================================
# 5. yfinance 适配器
# ============================================================================

class YFinanceAdapter:
    """yfinance 适配器 — 全球市场数据。"""

    def __init__(self):
        self._available = False
        self._yf = None
        self._check()

    def _check(self):
        try:
            import yfinance as yf
            self._yf = yf
            self._available = True
        except ImportError:
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    def query(self, query_type: str, params: Dict[str, Any]) -> Optional[Any]:
        if not self._available:
            return None
        try:
            fn = self._ROUTE_TABLE.get(query_type)
            if fn:
                return fn(self, params)
        except Exception as e:
            log.warning(f"yfinance query '{query_type}' failed: {e}")
        return None

    def _ticker(self, symbol: str):
        return self._yf.Ticker(symbol)

    def _q_us_stock(self, params: Dict) -> Any:
        symbol = params.get("symbol", "AAPL")
        t = self._ticker(symbol)
        return {
            "info": t.info,
            "price": t.fast_info.last_price if hasattr(t, 'fast_info') else None,
            "history": t.history(period=params.get("period", "1mo")).to_dict(),
        }

    def _q_stock_quote(self, params: Dict) -> Any:
        """A股通过yfinance获取（后缀.SS/.SZ）。"""
        code = params.get("code", "")
        if not code:
            return None
        suffix = ".SS" if code.startswith("6") else ".SZ"
        t = self._ticker(f"{code}{suffix}")
        info = t.fast_info
        return {
            "last_price": info.last_price,
            "market_cap": info.market_cap,
            "currency": info.currency,
        }

    def _q_hk_stock(self, params: Dict) -> Any:
        code = params.get("code", "0700")
        t = self._ticker(f"{code}.HK")
        info = t.fast_info
        return {
            "last_price": info.last_price,
            "market_cap": info.market_cap,
            "currency": info.currency,
        }

    def _q_forex(self, params: Dict) -> Any:
        pair = params.get("pair", "USDCNY=X")
        t = self._ticker(pair)
        return {"price": t.fast_info.last_price}

    def _q_futures(self, params: Dict) -> Any:
        symbol = params.get("symbol", "CL=F")
        t = self._ticker(symbol)
        return {"price": t.fast_info.last_price}

    def _q_etf_list(self, params: Dict) -> Any:
        symbols = params.get("symbols", ["SPY", "QQQ", "IWM", "GLD", "TLT"])
        results = []
        for sym in symbols:
            try:
                t = self._ticker(sym)
                results.append({"symbol": sym, "price": t.fast_info.last_price})
            except Exception:
                pass
        return results

    def _q_index_quote(self, params: Dict) -> Any:
        indices = params.get("indices", {
            "^GSPC": "S&P500", "^DJI": "道琼斯", "^IXIC": "纳斯达克",
            "^HSI": "恒生指数", "^N225": "日经225",
        })
        results = {}
        for sym, name in indices.items():
            try:
                t = self._ticker(sym)
                results[name] = t.fast_info.last_price
            except Exception:
                pass
        return results

    _ROUTE_TABLE = {
        "us_stock": _q_us_stock,
        "stock_quote": _q_stock_quote,
        "hk_stock": _q_hk_stock,
        "forex": _q_forex,
        "futures": _q_futures,
        "etf_list": _q_etf_list,
        "index_quote": _q_index_quote,
    }


# ============================================================================
# 6. Finnhub 适配器
# ============================================================================

class FinnhubAdapter:
    """Finnhub API 适配器（美股/全球，免费API Key）。"""

    BASE_URL = "https://finnhub.io/api/v1"

    def __init__(self, api_key: str = ""):
        self._api_key = api_key or ""
        self._available = bool(self._api_key)

    @property
    def available(self) -> bool:
        return self._available

    def set_api_key(self, key: str):
        self._api_key = key
        self._available = bool(key)

    def query(self, query_type: str, params: Dict[str, Any]) -> Optional[Any]:
        if not self._available:
            return None
        try:
            fn = self._ROUTE_TABLE.get(query_type)
            if fn:
                return fn(self, params)
        except Exception as e:
            log.warning(f"Finnhub query '{query_type}' failed: {e}")
        return None

    def _fetch(self, path: str, params: Dict = None) -> Optional[Dict]:
        try:
            try:
                from http_utils import http_get_json
            except ImportError:
                from scripts.http_utils import http_get_json

            from urllib.parse import urlencode
            p = dict(params or {})
            p["token"] = self._api_key
            url = f"{self.BASE_URL}{path}?{urlencode(p)}"
            return http_get_json(url, timeout=15)
        except Exception as e:
            log.debug(f"Finnhub fetch failed: {e}")
            return None

    def _q_us_stock(self, params: Dict) -> Any:
        symbol = params.get("symbol", "AAPL")
        return self._fetch("/quote", {"symbol": symbol})

    def _q_stock_quote(self, params: Dict) -> Any:
        code = params.get("code", "")
        if not code:
            return None
        return self._fetch("/quote", {"symbol": code})

    def _q_news(self, params: Dict) -> Any:
        category = params.get("category", "general")
        return self._fetch("/news", {"category": category, "minId": 0})

    _ROUTE_TABLE = {
        "us_stock": _q_us_stock,
        "stock_quote": _q_stock_quote,
        "news": _q_news,
    }


# ============================================================================
# 7. RSS 适配器
# ============================================================================

class RssFeedAdapter:
    """RSS 信息流适配器（零爬虫风险的公开信息源）。"""

    FEEDS = {
        "financial_news": [
            "https://rsshub.app/cls/telegraph",      # 财联社电报
            "https://rsshub.app/wallstreetcn/live",   # 华尔街见闻
            "https://rsshub.app/yicai/brief",         # 第一财经
            "https://rsshub.app/caixin/latest",       # 财新
        ],
        "regulatory": [
            "https://rsshub.app/csrc/news",           # 证监会
            "https://rsshub.app/pbc/goutongjiaoliu",  # 央行
        ],
        "market": [
            "https://rsshub.app/eastmoney/report",    # 东方财富研报
            "https://rsshub.app/gelonghui/home",      # 格隆汇
        ],
    }

    def __init__(self):
        self._available = True

    @property
    def available(self) -> bool:
        return self._available

    def query(self, query_type: str, params: Dict[str, Any]) -> Optional[List[Dict]]:
        feeds = self.FEEDS.get(query_type, self.FEEDS.get("financial_news", []))
        limit = params.get("limit", 10)
        results = []
        for feed_url in feeds[:3]:  # 限制最多3个源
            try:
                items = self._fetch_feed(feed_url, limit)
                results.extend(items)
            except Exception as e:
                log.debug(f"RSS feed failed {feed_url}: {e}")
        return results[:limit] if results else None

    def _fetch_feed(self, url: str, limit: int = 10) -> List[Dict]:
        """解析 RSS feed（纯标准库实现）。"""
        try:
            try:
                from http_utils import fetch_text
            except ImportError:
                from scripts.http_utils import fetch_text

            xml_text = fetch_text(url, timeout=15, use_cache=True)
            if not xml_text:
                return []

            items = []
            import xml.etree.ElementTree as ET
            root = ET.fromstring(xml_text)

            # RSS 2.0
            for item in root.findall(".//item"):
                if len(items) >= limit:
                    break
                title = item.findtext("title", "")
                link = item.findtext("link", "")
                desc = item.findtext("description", "")
                pub = item.findtext("pubDate", "")
                items.append({
                    "title": title, "url": link,
                    "summary": desc[:200], "published": pub,
                    "source": "rss",
                })

            # Atom
            ns = {"atom": "http://www.w3.org/2005/Atom"}
            for entry in root.findall(".//atom:entry", ns):
                if len(items) >= limit:
                    break
                title = entry.findtext("atom:title", "", ns) or entry.findtext("{http://www.w3.org/2005/Atom}title", "")
                link_el = entry.find("atom:link", ns) or entry.find("{http://www.w3.org/2005/Atom}link")
                link = link_el.get("href", "") if link_el is not None else ""
                summary = entry.findtext("atom:summary", "", ns) or entry.findtext("{http://www.w3.org/2005/Atom}summary", "")
                items.append({
                    "title": title, "url": link,
                    "summary": summary[:200], "source": "rss",
                })

            return items
        except Exception as e:
            log.debug(f"RSS parse failed: {e}")
            return []


# ============================================================================
# 8. 统一金融数据路由器
# ============================================================================

@dataclass
class QueryResult:
    """统一的查询结果。

    v12.1 追加字段全部在末尾且带默认值，既有按位置构造
    （query_type, source, data, success, ...）的代码不受影响。

    字段说明（v12.1 新增部分）：
        as_of: 数据时点（ISO 字符串）；未知时回落到 timestamp
        fresh: 是否新鲜（实时取到=True；缓存命中且未过期=True；陈旧兜底=False）
        stale: True=所有实时源失败后回落到旧缓存
        cache_hit: 本次结果是否来自进程内缓存
        error_code: 失败时的错误码（E_SOURCE_EMPTY / E_DEADLINE /
                    E_QUERY_UNKNOWN / E_ALL_FAILED / E_BAD_REQUEST）
        attempts: 逐源尝试轨迹，元素形如
                  {"source","status","latency_ms","reason","error"}，
                  status ∈ ok / no_data / error / cooldown / skipped /
                  unavailable / not_configured
        quality: 数据完整度 {"items","fields","non_null","completeness"}；
                 构造时若 data 非 None 且未显式提供则自动统计
    """
    query_type: str
    source: str
    data: Any = None
    success: bool = False
    latency_ms: float = 0.0
    error: str = ""
    fallback_used: List[str] = field(default_factory=list)
    timestamp: str = ""
    # ---- v12.1 新增（全部追加在 timestamp 之后，保持位置兼容）----
    as_of: str = ""
    fresh: bool = True
    stale: bool = False
    cache_hit: bool = False
    error_code: str = ""
    attempts: List[Dict[str, Any]] = field(default_factory=list)
    quality: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat(timespec="seconds")
        if not self.as_of:
            self.as_of = self.timestamp
        if not self.quality and self.data is not None:
            computed = compute_data_quality(self.data)
            if computed:
                self.quality = computed


def _copy_query_result(result: QueryResult) -> QueryResult:
    """复制查询结果，避免调用方改到缓存里共享的列表/字典。

    data 可能是 DataFrame 等不可深拷贝对象，退化为浅拷贝（仍复制可变容器）。
    """
    try:
        return copy.deepcopy(result)
    except Exception:  # noqa: BLE001 — 深拷贝失败时退化为浅拷贝
        return replace(
            result,
            fallback_used=list(result.fallback_used),
            attempts=[dict(item) for item in result.attempts],
            quality=dict(result.quality),
        )


def _bad_request_result(query_type: str, reason: str) -> QueryResult:
    """构造批量查询里的"非法请求"结果（不抛异常）。"""
    return QueryResult(
        query_type=str(query_type or ""),
        source="none",
        success=False,
        error=f"E_BAD_REQUEST: {reason}",
        error_code="E_BAD_REQUEST",
        fresh=False,
    )


class FinancialDataRouter:
    """金融数据统一路由器。

    按优先级依次尝试多个数据源，自动降级到备用源。
    每个源独立健康追踪，连续失败的源会暂时跳过。

    用法:
        router = FinancialDataRouter()
        result = router.query("stock_quote", code="600519")
        if result.success:
            print(result.data)
        else:
            print(f"All sources failed: {result.fallback_used}")
    """

    # 内置源：不注册适配器实例，由 _builtin_query 直连
    BUILTIN_SOURCES = (DataSource.SINA_HQ, DataSource.SEARCH_FALLBACK,
                       DataSource.TENCENT_RT)

    def __init__(self,
                 finnhub_key: str = "",
                 tushare_token: str = "",
                 custom_priorities: Optional[Dict[str, List[str]]] = None,
                 health_file: Optional[str] = None):
        # 初始化适配器
        self._adapters: Dict[DataSource, Any] = {}
        self._health: Dict[DataSource, SourceHealth] = {}
        self._lock = threading.Lock()
        # v12.1：进程内查询缓存，key -> (QueryResult, stored_at_monotonic)
        self._cache: Dict[Any, Tuple[QueryResult, float]] = {}

        # 注册所有适配器
        self._register_adapter(DataSource.AKSHARE, AkshareAdapter())
        self._register_adapter(DataSource.EASTMONEY_API, EastmoneyApiAdapter())
        self._register_adapter(DataSource.SINA_HQ, None)  # 使用 http_utils 直连
        self._register_adapter(DataSource.YAHOO_FINANCE, YFinanceAdapter())
        self._register_adapter(DataSource.FINNHUB, FinnhubAdapter(finnhub_key))
        self._register_adapter(DataSource.RSS_FEEDS, RssFeedAdapter())
        self._register_adapter(DataSource.SEARCH_FALLBACK, None)  # 使用搜索模块
        self._register_adapter(DataSource.TENCENT_RT, None)       # 实时中枢走 _builtin_query

        # 加载健康状态
        if health_file:
            self._load_health(health_file)

        log.info(f"FinancialDataRouter initialized with "
                 f"{sum(1 for a in self._adapters.values() if a and getattr(a, 'available', True))} "
                 f"active adapters")

    def _register_adapter(self, source: DataSource, adapter: Any):
        self._adapters[source] = adapter
        self._health[source] = SourceHealth(source=source)

    # ------------------------------------------------------------------
    # v12.1：进程内缓存 / 熔断冷却 辅助
    # ------------------------------------------------------------------

    @property
    def cache_size(self) -> int:
        """当前进程内缓存条目数。"""
        with self._lock:
            return len(self._cache)

    @staticmethod
    def _make_cache_key(query_type: str, params: Dict[str, Any]) -> Any:
        """缓存键：(query_type, frozenset(排序后的参数项))。

        参数值不可哈希（list/dict）时退化为排序后的 JSON 指纹，
        保证同样参数总能落到同一个键上。
        """
        try:
            return (query_type, frozenset(sorted(params.items())))
        except TypeError:
            try:
                fingerprint = json.dumps(
                    params, ensure_ascii=False, sort_keys=True, default=str
                )
            except Exception:  # noqa: BLE001 — 极端不可序列化参数
                fingerprint = repr(sorted((str(k), repr(v)) for k, v in params.items()))
            return (query_type, fingerprint)

    def _cache_lookup(self, key: Any) -> Optional[Tuple[QueryResult, float]]:
        """读取缓存条目 (结果, 写入时刻)；不存在返回 None。"""
        with self._lock:
            return self._cache.get(key)

    def _cache_store(self, key: Any, result: QueryResult) -> None:
        """写入缓存（只应传入 success 且非 stale 的结果），必要时淘汰最旧条目。"""
        with self._lock:
            self._cache[key] = (_copy_query_result(result), time.monotonic())
            if len(self._cache) > CACHE_MAX_ENTRIES:
                overflow = len(self._cache) - CACHE_MAX_ENTRIES
                oldest = sorted(self._cache.items(), key=lambda kv: kv[1][1])[:overflow]
                for old_key, _ in oldest:
                    self._cache.pop(old_key, None)

    @staticmethod
    def _cooldown_remaining(health: SourceHealth) -> float:
        """该源熔断冷却的剩余秒数；0 表示可尝试（冷却结束即 half-open 放行）。"""
        if health.consecutive_failures < COOLDOWN_THRESHOLD:
            return 0.0
        if not health.last_failure:
            return 0.0
        try:
            last_fail = datetime.fromisoformat(health.last_failure)
        except (TypeError, ValueError):
            return 0.0
        elapsed = (datetime.now() - last_fail).total_seconds()
        return max(0.0, _cooldown_seconds(health.consecutive_failures) - elapsed)

    def list_sources(self) -> Dict[str, Any]:
        """列出所有数据源状态。"""
        result = {}
        for src, health in self._health.items():
            adapter = self._adapters.get(src)
            available = getattr(adapter, 'available', True) if adapter else adapter is not None
            result[src.name] = {
                "available": available,
                "success_rate": round(health.success_rate, 3),
                "total_queries": health.total_queries,
                "avg_latency_ms": round(health.avg_latency_ms, 1),
                "consecutive_failures": health.consecutive_failures,
                "capabilities": SOURCE_CAPABILITIES.get(src, []),
            }
        return result

    def list_capabilities(self) -> Dict[str, List[str]]:
        """列出每种查询类型的可用数据源列表。"""
        return {qt: [s.name for s in sources]
                for qt, sources in SOURCE_PRIORITY.items()}

    def query(self, query_type: str,
              preferred_source: Optional[str] = None,
              use_cache: bool = True,
              cache_ttl: Optional[float] = None,
              deadline_ms: Optional[float] = None,
              allow_stale: bool = True,
              **params) -> QueryResult:
        """统一查询入口。

        v12.1 新增参数（全部有默认值，旧调用 `query(qt, **params)` 不变）：
            use_cache: 是否读写进程内新鲜缓存（默认 True）。命中未过期缓存时
                       直接返回副本（cache_hit=True / fresh=True）。
            cache_ttl: 覆盖该查询类型的默认 TTL（秒）。传 0 表示不使用新鲜缓存。
            deadline_ms: 整次查询的时间预算（毫秒）。超预算后剩余源不再尝试，
                       在 attempts 里记 status="skipped"、reason="deadline"，
                       并以 error_code="E_DEADLINE" 失败返回。
            allow_stale: 实时源全部失败时，是否回落到同 key 的旧成功缓存
                       （success=True / stale=True / fresh=False /
                       cache_hit=True / error_code="E_STALE_FALLBACK"）。
                       陈旧兜底只由本参数控制，use_cache 只管新鲜缓存的读写。

        Args:
            query_type: 查询类型（如 "stock_quote", "fund_nav", "macro_cpi"）
            preferred_source: 优先使用的数据源名称（可选）
            **params: 查询参数（code, symbol, start_date 等）

        Returns:
            QueryResult。失败时 error_code 为 E_SOURCE_EMPTY（无缓存可兜底）/
            E_DEADLINE（预算耗尽）/ E_QUERY_UNKNOWN（未知查询类型）。
        """
        start = time.monotonic()
        deadline = None if deadline_ms is None else float(deadline_ms)
        ttl = float(cache_ttl) if cache_ttl is not None else _ttl_for_query_type(query_type)
        cache_key = self._make_cache_key(query_type, params)

        def _elapsed_ms() -> float:
            return (time.monotonic() - start) * 1000.0

        # 1) 新鲜缓存命中：直接返回副本，不再触碰任何数据源
        if use_cache:
            entry = self._cache_lookup(cache_key)
            if entry is not None:
                cached, stored_at = entry
                if (time.monotonic() - stored_at) <= ttl:
                    hit = _copy_query_result(cached)
                    hit.cache_hit = True
                    hit.fresh = True
                    hit.stale = False
                    hit.latency_ms = round(_elapsed_ms(), 1)
                    return hit

        attempts: List[Dict[str, Any]] = []
        fallback_used: List[str] = []
        deadline_hit = False

        # 确定数据源顺序
        sources = list(SOURCE_PRIORITY.get(query_type, []))

        # 如果指定了优先源，移到最前
        if preferred_source:
            try:
                preferred = DataSource[preferred_source.upper()]
                if preferred in sources:
                    sources.remove(preferred)
                    sources.insert(0, preferred)
            except KeyError:
                pass

        for index, source in enumerate(sources):
            # ---- deadline：预算耗尽后剩余源一律不再尝试 ----
            if deadline is not None and _elapsed_ms() >= deadline:
                for rest in sources[index:]:
                    attempts.append({"source": rest.name, "status": "skipped",
                                     "reason": "deadline"})
                    fallback_used.append(f"{rest.name}(deadline)")
                deadline_hit = True
                break

            adapter = self._adapters.get(source)
            health = self._health.get(source)
            if not health:
                attempts.append({"source": source.name, "status": "not_configured",
                                 "reason": "no health record"})
                continue

            # 跳过不可用的源
            if adapter and not getattr(adapter, 'available', True):
                attempts.append({"source": source.name, "status": "unavailable"})
                fallback_used.append(f"{source.name}(unavailable)")
                continue

            # 没有适配器、又不是内置源的，直接跳过并标 not_configured。
            # 让它进 _builtin_query 拿 None 会被记成 "(no_data)"，
            # 于是"这个源压根没接"和"接了但这次查不到"在台账里混成一件事。
            if adapter is None and source not in self.BUILTIN_SOURCES:
                attempts.append({"source": source.name, "status": "not_configured"})
                fallback_used.append(f"{source.name}(not_configured)")
                continue

            # ---- 熔断冷却：3 次→30s，4 次→60s……上限 600s；冷却结束即 half-open ----
            cooldown_left = self._cooldown_remaining(health)
            if cooldown_left > 0:
                attempts.append({"source": source.name, "status": "cooldown",
                                 "reason": "consecutive_failures",
                                 "cooldown_remaining_sec": round(cooldown_left, 3)})
                fallback_used.append(f"{source.name}(cooldown)")
                continue

            try:
                latency_start = time.monotonic()
                if adapter is None:
                    # 内置适配器（Sina HQ / Search / 实时中枢）
                    data = self._builtin_query(source, query_type, params)
                else:
                    data = adapter.query(query_type, params)
                latency = (time.monotonic() - latency_start) * 1000

                if data is not None:
                    # 成功
                    self._record_success(source, latency)
                    attempts.append({"source": source.name, "status": "ok",
                                     "latency_ms": round(latency, 1)})
                    result = QueryResult(
                        query_type=query_type,
                        source=source.name,
                        data=data,
                        success=True,
                        latency_ms=round(_elapsed_ms(), 1),
                        fallback_used=list(fallback_used),
                        attempts=attempts,
                    )
                    if use_cache:
                        self._cache_store(cache_key, result)
                    return _copy_query_result(result)

                # 空结果同样记一次失败：熔断和陈旧兜底都要把"这个源没给数据"算进去
                self._record_failure(source, "empty_result")
                attempts.append({"source": source.name, "status": "no_data",
                                 "latency_ms": round(latency, 1)})
                fallback_used.append(f"{source.name}(no_data)")

            except Exception as e:
                self._record_failure(source, str(e))
                attempts.append({"source": source.name, "status": "error",
                                 "error": str(e)[:200],
                                 "latency_ms": round(
                                     (time.monotonic() - latency_start) * 1000, 1)})
                fallback_used.append(f"{source.name}(error:{str(e)[:50]})")

        elapsed = round(_elapsed_ms(), 1)

        # 2) 全部源失败（且不是 deadline 中断）→ 陈旧兜底
        if not deadline_hit and allow_stale:
            entry = self._cache_lookup(cache_key)
            if entry is not None:
                cached, stored_at = entry
                age = max(0.0, time.monotonic() - stored_at)
                stale_hit = _copy_query_result(cached)
                stale_hit.success = True
                stale_hit.stale = True
                stale_hit.fresh = False
                stale_hit.cache_hit = True
                stale_hit.error_code = "E_STALE_FALLBACK"
                stale_hit.error = f"实时源全失败，返回 {int(age)} 秒前缓存"
                stale_hit.latency_ms = elapsed
                stale_hit.fallback_used = list(fallback_used)
                stale_hit.attempts = attempts
                return stale_hit

        # 3) 无缓存可兜底 → 失败
        if query_type not in SOURCE_PRIORITY:
            error_code = "E_QUERY_UNKNOWN"
            error = f"Unknown query type '{query_type}' (0 sources registered)"
        elif deadline_hit:
            error_code = "E_DEADLINE"
            error = f"Deadline {deadline_ms}ms exceeded after {len(attempts)} attempts"
        else:
            error_code = "E_SOURCE_EMPTY"
            error = f"All {len(fallback_used)} sources exhausted"
        return QueryResult(
            query_type=query_type,
            source="none",
            success=False,
            latency_ms=elapsed,
            error=error,
            fallback_used=fallback_used,
            error_code=error_code,
            attempts=attempts,
            fresh=False,
        )

    def query_many(self, requests: List[Dict[str, Any]], workers: int = 4,
                   deadline_ms: Optional[float] = None) -> Dict[str, Any]:
        """批量查询：并发执行，结果顺序与 requests 完全一致。

        requests 元素形如::

            {"query_type": "stock_quote", "params": {"code": "600519"},
             "preferred_source": "AKSHARE"}

        非法元素（不是 dict / 缺 query_type / params 不是 dict）不抛异常，
        对应结果为 success=False / error_code="E_BAD_REQUEST"。

        Args:
            requests: 请求列表
            workers: 并发线程数，内部夹到 [1, 16]
            deadline_ms: 整批的总预算（毫秒），按剩余预算分摊给每个子查询；
                         单个子查询仍以 error_code="E_DEADLINE" 报告超时。

        Returns:
            {"results": [QueryResult...],
             "summary": {"total", "ok", "failed", "stale", "cache_hits",
                         "elapsed_ms", "by_source": {source_name: 成功次数}}}
            注意 results 里是 QueryResult 对象，不做序列化。
        """
        start = time.monotonic()
        items = list(requests) if requests is not None else []

        def _run_one(index: int) -> QueryResult:
            request = items[index]
            if not isinstance(request, dict):
                return _bad_request_result("", "request item is not a dict")
            query_type = request.get("query_type")
            if not isinstance(query_type, str) or not query_type.strip():
                return _bad_request_result(str(query_type or ""), "missing query_type")
            params = request.get("params", {})
            if params is None:
                params = {}
            if not isinstance(params, dict):
                return _bad_request_result(query_type, "params must be a dict")
            preferred = request.get("preferred_source")
            if preferred is not None and not isinstance(preferred, str):
                return _bad_request_result(query_type, "preferred_source must be a str")
            try:
                query_deadline = None
                if deadline_ms is not None:
                    used_ms = (time.monotonic() - start) * 1000.0
                    query_deadline = max(0.0, float(deadline_ms) - used_ms)
                return self.query(query_type, preferred_source=preferred or None,
                                  deadline_ms=query_deadline, **params)
            except Exception as e:  # noqa: BLE001 — 单个子查询异常不拖垮整批
                log.warning(f"query_many item {index} failed: {e}")
                return QueryResult(
                    query_type=query_type, source="none", success=False,
                    error=f"E_ALL_FAILED: {e}", error_code="E_ALL_FAILED",
                    fresh=False,
                )

        max_workers = max(1, min(int(workers or 1), BATCH_MAX_WORKERS))
        results: List[QueryResult] = []
        if max_workers == 1 or len(items) <= 1:
            results = [_run_one(i) for i in range(len(items))]
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = [pool.submit(_run_one, i) for i in range(len(items))]
                for future in futures:
                    try:
                        results.append(future.result())
                    except Exception as e:  # noqa: BLE001 — 兜底，保证顺序与长度
                        results.append(QueryResult(
                            query_type="", source="none", success=False,
                            error=f"E_ALL_FAILED: {e}", error_code="E_ALL_FAILED",
                            fresh=False,
                        ))

        by_source: Dict[str, int] = {}
        for result in results:
            if result.success and result.source and result.source != "none":
                by_source[result.source] = by_source.get(result.source, 0) + 1
        summary = {
            "total": len(results),
            "ok": sum(1 for r in results if r.success),
            "failed": sum(1 for r in results if not r.success),
            "stale": sum(1 for r in results if r.stale),
            "cache_hits": sum(1 for r in results if r.cache_hit),
            "elapsed_ms": round((time.monotonic() - start) * 1000.0, 1),
            "by_source": by_source,
        }
        return {"results": results, "summary": summary}

    def _builtin_query(self, source: DataSource, query_type: str,
                       params: Dict) -> Optional[Any]:
        """内置数据源查询（Sina HQ / Search / 实时中枢）。"""
        if source == DataSource.SINA_HQ:
            return self._query_sina_hq(query_type, params)
        elif source == DataSource.SEARCH_FALLBACK:
            return self._query_search(query_type, params)
        elif source == DataSource.TENCENT_RT:
            return self._query_realtime(query_type, params)
        return None

    def _query_realtime(self, query_type: str, params: Dict) -> Optional[Any]:
        """实时行情中枢（强制绕过 HTTP 响应缓存）。"""
        try:
            try:
                from realtime_data_hub import get_hub
            except ImportError:
                from scripts.realtime_data_hub import get_hub
        except ImportError:
            return None
        hub = get_hub()
        if query_type == "rt_board":
            rows = hub.board(params.get("board", "industry"),
                             order=params.get("order", "desc"),
                             count=int(params.get("count", 20)))
            return rows or None
        if query_type == "rt_fund_estimate":
            nav = hub.fund_nav(params.get("code", params.get("symbol", "")))
            return nav or None
        if query_type == "rt_kline":
            bars = hub.bars(params.get("code", params.get("symbol", "")),
                            period=params.get("period", "day"),
                            count=int(params.get("count", 120)),
                            adjust=params.get("adjust", "qfq"))
            return bars or None
        codes = params.get("codes") or params.get("code") or params.get("symbol")
        if query_type == "rt_overview":
            return hub.market_overview()
        if not codes:
            return None
        if isinstance(codes, str):
            codes = [c.strip() for c in re.split(r"[,，;；\s]+", codes) if c.strip()]
        res = hub.quotes(list(codes))
        return res.data if res.ok else None

    def _query_sina_hq(self, query_type: str, params: Dict) -> Optional[Dict]:
        """新浪行情接口直连。"""
        code = params.get("code", "")
        if not code:
            return None
        try:
            try:
                from http_utils import fetch_text
            except ImportError:
                from scripts.http_utils import fetch_text

            prefix = "sh" if code.startswith("6") else "sz"
            url = f"https://hq.sinajs.cn/list={prefix}{code}"
            text = fetch_text(url, headers={
                "Referer": "https://finance.sina.com.cn/",
            }, timeout=10)
            if text and "=" in text and '"' in text:
                parts = text.split('"')[1].split(",")
                if len(parts) > 10:
                    return {
                        "name": parts[0],
                        "open": parts[1],
                        "yesterday_close": parts[2],
                        "current": parts[3],
                        "high": parts[4],
                        "low": parts[5],
                        "volume": parts[8],
                        "amount": parts[9],
                        "date": parts[30] if len(parts) > 30 else "",
                        "time": parts[31] if len(parts) > 31 else "",
                    }
        except Exception as e:
            log.debug(f"Sina HQ query failed: {e}")
        return None

    def _query_search(self, query_type: str, params: Dict) -> Optional[List[Dict]]:
        """搜索引擎兜底。"""
        query = params.get("query", params.get("code", ""))
        if not query:
            return None
        try:
            try:
                from search_engine import quick_search
            except ImportError:
                from scripts.search_engine import quick_search
            results = quick_search(query, engines=["baidu_html"], max_results=5)
            return results if results else None
        except Exception as e:
            log.debug(f"Search fallback failed: {e}")
        return None

    def _record_success(self, source: DataSource, latency_ms: float):
        with self._lock:
            h = self._health[source]
            h.total_queries += 1
            h.total_success += 1
            h.consecutive_failures = 0
            h.last_success = datetime.now().isoformat(timespec="seconds")
            # 移动平均延迟
            if h.avg_latency_ms == 0:
                h.avg_latency_ms = latency_ms
            else:
                h.avg_latency_ms = h.avg_latency_ms * 0.8 + latency_ms * 0.2

    def _record_failure(self, source: DataSource, reason: str):
        with self._lock:
            h = self._health[source]
            h.total_queries += 1
            h.consecutive_failures += 1
            h.last_failure = datetime.now().isoformat(timespec="seconds")

    def get_health(self) -> Dict[str, Any]:
        """获取所有数据源健康状态。"""
        with self._lock:
            return {src.name: {
                "available": getattr(self._adapters.get(src), 'available', True),
                "success_rate": round(h.success_rate, 3),
                "consecutive_failures": h.consecutive_failures,
                "avg_latency_ms": round(h.avg_latency_ms, 1),
            } for src, h in self._health.items()}

    # ------------------------------------------------------------------
    # v12.1：健康快照落盘 / 恢复
    # ------------------------------------------------------------------

    def save_health(self, path: str) -> Dict[str, Any]:
        """把各数据源健康快照写入 JSON 文件（UTF-8，ensure_ascii=False）。

        写入字段：total_queries / success / failure / consecutive_failures /
        avg_latency（另附 last_success / last_failure）。
        先写临时文件再 os.replace，避免中途失败留下半截 JSON。

        Returns:
            {"ok": bool, "path": str, "sources": int, "error": str}
        """
        snapshot: Dict[str, Any] = {}
        with self._lock:
            for src, health in self._health.items():
                snapshot[src.name] = {
                    "total_queries": health.total_queries,
                    "success": health.total_success,
                    "failure": max(0, health.total_queries - health.total_success),
                    "consecutive_failures": health.consecutive_failures,
                    "avg_latency": round(health.avg_latency_ms, 3),
                    "last_success": health.last_success,
                    "last_failure": health.last_failure,
                }
        payload = {
            "version": HEALTH_SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "sources": snapshot,
        }
        target = os.path.abspath(os.path.expanduser(str(path)))
        tmp_path = target + ".tmp"
        try:
            parent = os.path.dirname(target)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(tmp_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
            os.replace(tmp_path, target)
            return {"ok": True, "path": target, "sources": len(snapshot), "error": ""}
        except Exception as exc:  # noqa: BLE001 — 落盘失败不该让查询链路崩溃
            log.warning(f"save_health failed: {exc}")
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass
            return {"ok": False, "path": target, "sources": len(snapshot),
                    "error": f"E_HEALTH_WRITE_FAILED: {exc}"}

    def _load_health(self, path: str) -> int:
        """从 JSON 文件恢复健康状态，返回成功恢复的源数量。

        兼容两种结构：
          - {"version": ..., "saved_at": ..., "sources": {NAME: {...}}}
            （save_health 的产物）
          - 直接 {NAME: {...}} 的旧文件

        文件缺失 / JSON 损坏 / 未知源名一律静默跳过——健康文件是缓存性质，
        不应该让 FinancialDataRouter 的构造失败。
        """
        target = os.path.abspath(os.path.expanduser(str(path)))
        try:
            with open(target, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
        except (OSError, ValueError, TypeError):
            return 0
        if not isinstance(payload, dict):
            return 0
        entries = payload.get("sources")
        if not isinstance(entries, dict):
            entries = payload
        loaded = 0
        with self._lock:
            for name, entry in entries.items():
                if not isinstance(entry, dict):
                    continue
                try:
                    src = DataSource[str(name).upper()]
                except KeyError:
                    continue
                health = self._health.get(src)
                if health is None:
                    continue
                try:
                    health.total_queries = int(entry.get("total_queries", 0) or 0)
                    health.total_success = int(
                        entry.get("success", entry.get("total_success", 0)) or 0)
                    health.consecutive_failures = int(
                        entry.get("consecutive_failures", 0) or 0)
                    health.avg_latency_ms = float(
                        entry.get("avg_latency", entry.get("avg_latency_ms", 0.0)) or 0.0)
                except (TypeError, ValueError):
                    continue
                if entry.get("last_success"):
                    health.last_success = str(entry["last_success"])
                if entry.get("last_failure"):
                    health.last_failure = str(entry["last_failure"])
                loaded += 1
        return loaded


# ============================================================================
# 9. 全局实例与便捷函数
# ============================================================================

_global_router: Optional[FinancialDataRouter] = None
_router_lock = threading.Lock()


def get_router(**kwargs) -> FinancialDataRouter:
    """获取全局金融数据路由器（单例）。"""
    global _global_router
    with _router_lock:
        if _global_router is None:
            _global_router = FinancialDataRouter(**kwargs)
        return _global_router


def query_financial_data(query_type: str, **params) -> QueryResult:
    """便捷函数：统一查询金融数据。

    v12.1 起可直接透传 use_cache / cache_ttl / deadline_ms / allow_stale /
    preferred_source；其余键仍作为查询参数传给对应数据源。

    Examples:
        >>> result = query_financial_data("stock_quote", code="600519")
        >>> result = query_financial_data("macro_cpi")
        >>> result = query_financial_data("fund_nav", code="110011")
        >>> result = query_financial_data("stock_quote", code="600519", deadline_ms=3000)
        >>> result = query_financial_data("stock_quote", code="600519", use_cache=False)
    """
    return get_router().query(query_type, **params)


def query_financial_data_batch(requests: List[Dict[str, Any]],
                               workers: int = 4,
                               deadline_ms: Optional[float] = None
                               ) -> Dict[str, Any]:
    """便捷函数：批量查询金融数据（并发执行、结果顺序与请求一致）。

    requests 元素：{"query_type": str, "params": {...}, "preferred_source": 可选}。
    非法元素不抛异常，对应结果 success=False / error_code="E_BAD_REQUEST"。

    Returns:
        {"results": [QueryResult...],
         "summary": {"total", "ok", "failed", "stale", "cache_hits",
                     "elapsed_ms", "by_source": {source_name: 成功次数}}}
    """
    return get_router().query_many(requests, workers=workers,
                                   deadline_ms=deadline_ms)


def list_available_sources() -> Dict[str, Any]:
    """便捷函数：列出所有数据源状态。"""
    return get_router().list_sources()


def list_query_types() -> Dict[str, List[str]]:
    """便捷函数：列出所有支持的查询类型。"""
    return get_router().list_capabilities()


# ============================================================================
# 10. 自检
# ============================================================================

def self_check() -> Dict[str, Any]:
    """数据源桥接模块自检。

    v12.1 起额外报告进程内缓存条目数（cache_size）与批量查询能力（batch），
    既有键全部保留。
    """
    router = get_router()
    sources = router.list_sources()
    active = sum(1 for s in sources.values() if s["available"])
    return {
        "version": "v12.1.0",
        "total_sources": len(sources),
        "active_sources": active,
        "source_status": {k: ("✅" if v["available"] else "❌") + f" {v['success_rate']:.0%}"
                          for k, v in sources.items()},
        "supported_queries": len(SOURCE_PRIORITY),
        "query_types": list(SOURCE_PRIORITY.keys()),
        "akshare": "✅ installed" if AkshareAdapter().available else "❌ not installed (pip install akshare)",
        "yfinance": "✅ installed" if YFinanceAdapter().available else "❌ not installed (pip install yfinance)",
        "cache_size": router.cache_size,
        "batch": True,
    }


if __name__ == "__main__":
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))
