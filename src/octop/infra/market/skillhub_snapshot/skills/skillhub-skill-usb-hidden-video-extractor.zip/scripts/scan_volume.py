#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
scan_volume.py —— 原始卷扫描，定位"专用播放器"U 盘里藏着的视频。

适用：资源管理器看不到文件、但卷容量接近占满的 U 盘/光盘/移动硬盘。
原理：以原始设备方式打开卷（\\.\X: 或 \\.\Volume{GUID}），分块扫描
      视频文件特征码 + 文件名/JSON 目录清单线索，输出命中统计与附近可读串。

用法：
    python scan_volume.py --volume \\.\X: --cap 1073741824 --out scan.txt
    python scan_volume.py --volume X: --cap 0          # 全量扫描，打到 stdout
    python scan_volume.py --volume \\.\Volume{XXXX-...}  # 绕过盘符冲突
"""
import argparse
import re

# 视频特征码 / 文件名线索
SIGS = {
    "ftyp(MP4)": b"ftyp",
    "RIFF(AVI)": b"RIFF",
    "FLV": b"FLV\x01",
    "MKV(EBML)": b"\x1a\x45\xdf\xa3",
    "ASF(WMV)": b"\x30\x26\xb2\x75\x8e\x66\xcf\x11",
    ".mp4": b".mp4",
    ".avi": b".avi",
    ".flv": b".flv",
    ".mkv": b".mkv",
    ".wmv": b".wmv",
    ".mov": b".mov",
    ".m4v": b".m4v",
    ".mpg": b".mpg",
    ".ts": b".ts",
    ".dat": b".dat",
    "Videos/": b"Videos/",
    "StreamingAssets": b"StreamingAssets",
}


def norm_volume(v):
    r"""把 X: / X:\ 规范成 \\.\X:；已带 \\.\ 或 \\?\ 的保持不变。"""
    v = v.strip()
    if v.startswith("\\\\.\\") or v.startswith("\\\\?\\"):
        return v
    if len(v) == 2 and v[1] == ":":
        return "\\\\." + v
    if len(v) == 3 and v[1] == ":" and v[2] == "\\":
        return "\\\\." + v[:2]
    return v


def printable(b):
    return re.sub(rb"[^\x20-\x7e]", b".", b).decode("latin1")


def main():
    ap = argparse.ArgumentParser(description="原始卷扫描：定位隐藏视频特征码与目录清单")
    ap.add_argument("--volume", "-v", required=True, help=r"卷设备路径，如 X: 或 \\.\X: 或 \\.\Volume{GUID}")
    ap.add_argument("--cap", type=int, default=1073741824,
                    help="最多扫描字节数；0 表示全量（默认前 1GB 快速验证）")
    ap.add_argument("--out", "-o", default=None, help="结果输出文件；省略则打到 stdout")
    ap.add_argument("--chunk", type=int, default=16 * 1024 * 1024, help="读取块大小（默认 16MB）")
    args = ap.parse_args()

    lines = []
    log = (lambda s: (lines.append(s), print(s, flush=True))) if args.out is None else \
          (lambda s: lines.append(s))

    vol = norm_volume(args.volume)
    log("打开卷设备: %s" % vol)
    try:
        f = open(vol, "rb")
    except Exception as e:
        log("打开失败: %r" % e)
        if args.out:
            open(args.out, "w", encoding="utf-8").write("\n".join(lines))
        return

    CHUNK = args.chunk
    overlap = 128
    prev = b""
    offset = 0
    total = 0
    hits = {k: 0 for k in SIGS}
    samples = []
    try:
        while True:
            if args.cap and total >= args.cap:
                break
            buf = f.read(CHUNK)
            if not buf:
                break
            total += len(buf)
            scan = prev + buf
            for name, sig in SIGS.items():
                p = scan.find(sig)
                while p != -1:
                    hits[name] += 1
                    abs_off = offset - len(prev) + p
                    if len(samples) < 300:
                        seg = printable(scan[max(0, p - 60):p + 90])
                        samples.append((name, abs_off, seg))
                    p = scan.find(sig, p + 1)
            prev = buf[-overlap:]
            offset += len(buf)
            if total % (512 * 1024 * 1024) == 0:
                log("  进度 %.2f GB" % (total / 1e9))
        log("扫描结束 总字节=%d (%.2f GB)" % (total, total / 1e9))
    except Exception as e:
        log("扫描中断: %r @ %.2fGB" % (e, total / 1e9))

    log("--- 特征码命中 ---")
    for k, v in hits.items():
        if v:
            log("  %-18s : %d" % (k, v))
    log("--- 命中样本（最多 %d）---" % len(samples))
    for name, off, s in samples:
        log("  [%s] @0x%X : %s" % (name, off, s))
    try:
        f.close()
    except Exception:
        pass

    if args.out:
        open(args.out, "w", encoding="utf-8").write("\n".join(lines) + "\n")
        print("结果已写入 %s" % args.out)


if __name__ == "__main__":
    main()
