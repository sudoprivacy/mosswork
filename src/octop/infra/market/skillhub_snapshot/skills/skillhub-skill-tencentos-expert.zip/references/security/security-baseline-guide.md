---
name: security-baseline-guide
author: guoninzhang@tencent.com
---

# 等保三级安全加固 Skill

## 概述

基于 GB/T 22239-2019《信息安全技术 网络安全等级保护基本要求》三级标准，对 TencentOS Server 进行安全基线检查和自动加固。

## 功能特性

- **37 项安全检查**：覆盖等保三级 6 大安全域
- **双模式运行**：check（只检查不修改）和 harden（自动修复）
- **风险分级**：R1（高风险/必须）、R2（中风险/建议）、R3（低风险/可选）
- **高风险保护**：禁止 root 登录、防火墙、SELinux 等高风险项需交互确认
- **自动备份**：加固前自动备份所有修改的配置文件
- **灵活过滤**：支持按风险等级、指定项、排除项三种过滤方式

## 检查域

| 域 | 编号范围 | 检查项数 | 说明 |
|----|---------|---------|------|
| 身份鉴别 | 1.1-1.6 | 6 | 密码策略、登录失败锁定、会话超时 |
| 访问控制 | 2.1-2.8 | 8 | 账户管理、权限最小化、root 限制 |
| 安全审计 | 3.1-3.5 | 5 | 审计日志、审计规则、日志保护 |
| 入侵防范 | 4.1-4.6 | 6 | SSH 加固、端口管控、防火墙、SELinux |
| 恶意代码防范 | 5.1-5.3 | 3 | 软件源验证、安全更新 |
| 资源控制 | 6.1-6.11 | 9 | 系统参数、网络防护、内核加固 |

## 使用方式

### 检查全部项
```bash
bash tos_security_harden.sh check
```

### 仅检查高风险项
```bash
bash tos_security_harden.sh check -l R1
```

### 加固全部（排除高风险项）
```bash
bash tos_security_harden.sh harden -e 2.8,4.5,4.6
```

### 加固指定项
```bash
bash tos_security_harden.sh harden -i 1.1,1.2,2.1
```

### 静默模式
```bash
bash tos_security_harden.sh check -q
```

## 测试结果

在 TencentOS Server 3.3 (kernel 5.4.241) 上测试：

| 指标 | 结果 |
|------|------|
| Check 模式 | 37 项全部正确检测 |
| Harden 模式 | 17 项非高风险项全部成功加固 |
| 通过率提升 | 48.6% -> 94.6% (+46pp) |
| 高风险项保护 | 非交互模式自动 SKIP |
| 备份机制 | 12 个配置文件正确备份 |

## 注意事项

- 加固前务必先运行 check 模式了解当前状态
- 高风险项（2.8 禁止 root 登录、4.5 防火墙、4.6 SELinux）需在交互终端手动确认
- 加固会自动创建备份目录 `/var/backup/security_harden_<timestamp>/`
- 建议在非生产环境先行验证
