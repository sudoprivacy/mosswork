---
name: network-latency-guide
author: cloudmli@tencent.com
---

# 网络丢包与延迟排查 — 使用指南

## 简介

`network-latency` 技能用于排查网络丢包和延迟问题，帮助运维人员快速定位网络性能瓶颈。

与 `network-check`（解决"通不通"的连通性问题）不同，`network-latency` 解决的是"通但是慢/丢包"的性能问题。

通过渐进式诊断，从 TCP/IP 协议栈底层到上层逐层分析定位：

1. **网卡硬件层** — Ring Buffer 溢出、协商状态、CRC 错误
2. **网卡驱动层** — softnet backlog 溢出、中断不均衡
3. **协议栈层** — TCP 重传、conntrack 满、丢包路径跟踪
4. **nettrace 智能诊断** — 报文生命周期跟踪、故障自动诊断
5. **延迟专项** — RTT 分析、逐跳定位、TCP 拥塞、队列延迟、应用层延迟

无需记忆复杂的命令参数——只需描述你遇到的网络问题，AI 会自动选择诊断路径、执行命令、解读结果，并给出优化建议。

## 文件结构（v2.0.0）

> 网络延迟/丢包诊断模块采用扁平化多文件结构，所有文件统一存放在仓库根目录的 `references/` 和 `scripts/` 下。

```
references/
├── network-latency.md          # 主入口（路由规则 + 公共阈值表 + 版本差异）
├── network-packet-loss.md      # 丢包域完整诊断流程（Module 1~7）
├── network-latency-diag.md     # 延迟域完整诊断流程（Module 1~6）
├── network-nettrace.md         # nettrace 工具完整用法参考
├── network-faq-packet-loss.md  # 丢包域 FAQ/操作参考/命令速查
├── network-faq-latency.md      # 延迟域 FAQ/操作参考/命令速查/流程图
└── network-latency-guide.md    # 本使用指南

scripts/
└── network-latency-monitor.sh  # 长期监控脚本模板
```

| 文件 | 职责 |
|------|------|
| `references/network/network-latency.md` | 公共入口：安全原则、前置检查、适用场景、**诊断路由规则**、公共阈值参考表、TencentOS 版本差异 |
| `references/network/network-packet-loss.md` | 丢包域核心流程：Phase 0 问诊 → Module 1~7 诊断步骤 → 症状速查表 |
| `references/network/network-latency-diag.md` | 延迟域核心流程：Phase 0 问诊 → Module 1~6 诊断步骤 → 症状速查表 |
| `references/network/network-nettrace.md` | nettrace 安装、用法、AI 执行约束 |
| `references/network/network-faq-packet-loss.md` | 丢包域补充参考：FAQ + 操作参考 + 命令速查表 |
| `references/network/network-faq-latency.md` | 延迟域补充参考：FAQ + 操作参考 + 命令速查表 + 快速排查流程图 |

### AI 如何加载文件

1. AI 首先读取 `references/network/network-latency.md`，获取安全原则、前置检查、路由规则
2. 根据用户问题的关键词，通过**诊断路由规则**判断加载 `network-packet-loss.md` 或 `network-latency-diag.md`
3. 当需要 nettrace 详细用法时加载 `references/network/network-nettrace.md`
4. 当用户需要 FAQ 解答、操作参考或命令速查时，按需加载对应的 `references/network-faq-*.md`

## 问诊与分析模型（Phase 0）

> v2.0.0 新增：AI 在执行任何诊断命令之前，会先进行结构化问诊（Phase 0），收集关键上下文信息，选择最匹配的分析模型。

### 为什么 AI 会先提问？

传统的网络排查是"从头到尾逐步执行"。但实际问题有不同类型（持续型、间歇型、新发型），不同类型的最优排查路径不同。Phase 0 通过收集关键信息（目标 IP、网卡、问题模式等），**跳过不相关的步骤，直达问题根因**。

### 丢包分析模型

| 模型 | 适用场景 | 推荐诊断路径 |
|------|---------|-------------|
| M-1 持续型 | 丢包持续存在 | Module 1 → 2 → 3 → 4 → 5 |
| M-2 间歇型 | 丢包偶尔发生 | Module 1 → Module 4（nettrace 优先）→ 定向 |
| M-3 新发型 | 近期变更后出现 | Module 1 → dmesg → Module 2/6 |
| M-4 方向型 | 仅接收或仅发送方向 | Module 1 → Module 2/3（聚焦方向）→ Module 5 |

### 延迟分析模型

| 模型 | 适用场景 | 推荐诊断路径 |
|------|---------|-------------|
| M-1 持续型 | 延迟稳定偏高 | Module 1 → 2 → 3 → 4 → 6 |
| M-2 偶发型 | 延迟尖刺/抖动 | Module 1 → Module 5（nettrace 优先）→ 定向 |
| M-3 时段型 | 特定时段延迟增高 | Module 1 → Module 2（对比基线）→ Module 3（带宽） |
| M-4 新发型 | 近期变更后出现 | Module 1 → Step 3.3 → dmesg |

### 智能分支（BR）

诊断过程中，如果发现某个关键信号，AI 会通过智能分支（BR-1 ~ BR-5）跳转到最相关的 Module，避免执行不必要的中间步骤。

## 适用场景

| 场景 | 典型表现 | 使用本 Skill 的价值 |
|------|---------|-------------------:|
| 网络丢包 | ping 丢包、ethtool 看到 drop/error | 逐层定位丢包位置：网卡硬件→驱动→协议栈 |
| 网络延迟高 | ping RTT 偏高、应用响应慢 | mtr 逐跳定位 + nettrace 协议栈延迟分析 |
| 网络抖动 | 延迟不稳定、mdev 大 | 逐跳抖动定位 + 队列延迟排查 |
| TCP 重传率高 | 重传导致业务性能下降 | 重传率统计 + 拥塞窗口分析 + 抓包定位 |
| 传输速度慢 | 带宽跑不满、吞吐低 | BDP 分析 + TCP 缓冲区 + 拥塞算法诊断 |
| 网卡错误 | rx errors/drops 持续增长 | 硬件层（Ring Buffer/协商/CRC）精确定位 |
| 偶现网络问题 | 问题难以复现 | 部署长期监控脚本，自动捕获异常时段 |

## 使用方法

### 第 1 步：触发 Skill

在 AI 输入框中用自然语言描述需求即可，例如：

- "帮我排查到 10.0.0.1 的网络丢包"
- "网络延迟很高，帮我看看"
- "TCP 重传率很高，排查一下"
- "网卡 rx dropped 在增长，是什么原因"
- "帮我部署到 10.0.0.1 的网络质量监控，监控 3 天"

### 第 2 步：AI 问诊收集信息（Phase 0）

AI 会先问你几个关键问题（目标 IP、网卡名、问题模式等），然后根据你的回答自动选择最优排查路径。

### 第 3 步：AI 自动执行诊断

AI 根据选定的分析模型，按 Module 顺序执行诊断命令：

**丢包排查**（Module 1~7）：
1. **Module 1: 环境预检** — tc netem 排除 + 基本信息确认
2. **Module 2: 网卡硬件层** — Ring Buffer + 协商/硬件错误
3. **Module 3: 网卡驱动层** — 接口错误 + softnet backlog + 中断
4. **Module 4: nettrace 智能诊断** — 丢包监控 + 故障诊断 + 报文跟踪
5. **Module 5: 协议栈层** — IP/TCP/UDP 统计 + 扩展统计
6. **Module 6: 防火墙与连接跟踪** — conntrack + iptables/nftables
7. **Module 7: 降级方案** — perf + dropwatch + tcpdump

**延迟排查**（Module 1~6）：
1. **Module 1: 环境预检** — tc netem 排除 + 系统信息
2. **Module 2: RTT 基线与路径分析** — ping 基线 + mtr 逐跳
3. **Module 3: 传输层综合分析** — NIC 带宽 + TCP 拥塞 + 内核参数
4. **Module 4: 队列与软中断分析** — Qdisc + softirq + GRO + ARP
5. **Module 5: nettrace 协议栈延迟与 RTT** — 延迟分析 + RTT 统计
6. **Module 6: 应用层分析** — Socket Backlog + 进程调度 + 系统调用

> 💡 如果服务器上没有 nettrace，AI 会询问你是否需要安装。nettrace 是基于 eBPF 的网络诊断工具集，能够跟踪报文在内核协议栈中的完整生命周期，自动诊断网络故障并给出修复建议。

> ⚠️ **安全原则**：AI 只执行查询/诊断命令，**不自动修改网络配置**（路由、防火墙、sysctl、tc 队列等），修改建议仅作为参考。

### 第 4 步：查看诊断报告

报告包含以下内容：

- **基础测量结果** — 丢包率、RTT（min/avg/max/mdev）
- **逐层排查结果** — 各层级的统计数据和异常发现
- **问题定位** — 丢包/延迟发生在哪一层、具体原因
- **优化建议** — 针对性的改进方向（仅供参考，由用户决定是否执行）

## 诊断工具说明

本 Skill 使用多种工具协同诊断：

| 工具 | 用途 | 说明 |
|------|------|------|
| **ping** | 基础延迟和丢包率测量 | 所有系统自带，必备 |
| **mtr** | 逐跳丢包和延迟定位 | 综合 traceroute + ping，推荐安装 |
| **ethtool** | 网卡硬件层统计和配置查看 | 查看 Ring Buffer、协商状态、硬件错误 |
| **ip / ifconfig** | 接口错误统计 | 查看 dropped/errors/overrun |
| **ss** | TCP 连接内部信息 | 查看 RTT、拥塞窗口、重传、队列 |
| **nettrace** | ⭐ 智能网络诊断 | 丢包监控、故障诊断、报文跟踪、协议栈延迟分析 |
| **tcpdump** | 深度抓包分析 | 重传/RST/乱序分析，需 root |
| **iperf3** | 端到端带宽和抖动测试 | 需对端配合，会占用带宽 |

> **nettrace vs 传统方案**：nettrace 的 `--drop` 可替代 dropwatch，`--diag` 可自动诊断故障并给出修复建议，`--latency-show` 可分析协议栈各环节延迟。相比 perf 跟踪 `kfree_skb`，nettrace 提供了更丰富的诊断信息和更友好的使用体验。

## 长期监控模式

网络质量问题往往是偶现的，短时间诊断可能抓不到现场。本技能支持部署后台监控脚本，持续运行数天来捕获异常。

### 工作原理

监控脚本采用主循环 + 按需触发模式：
- 每轮 ping 测量丢包率和 RTT，追加到 `ping_stats.log`
- 超阈值时触发 tcpdump 短时抓包，记录到 `alerts.log`
- 定期采集 TCP 统计（ss -tin）和网卡统计（ethtool）

### 使用方式

- "帮我部署到 10.0.0.1 的网络质量监控，监控 3 天"
- "部署网络延迟监控脚本，丢包超过 1% 告警"

### 日志文件

监控脚本会在日志目录（默认 `/var/log/network-latency-monitor`）下生成：

| 文件 | 内容 |
|------|------|
| `ping_stats.log` | 每轮 ping 统计（时间戳+丢包率+RTT） |
| `tcp_stats.log` | 定期 ss -tin 统计 |
| `nic_stats.log` | ethtool 计数器增量 |
| `alerts.log` | 超阈值告警记录 |
| `capture/` | 超阈值时的 tcpdump 抓包文件 |
| `monitor.log` | 脚本运行日志 |

## 关键阈值参考

> 完整的公共阈值参考表请参见 `SKILL.md`。以下为快速参考。

### 丢包相关

| 指标 | 正常 | 需关注 | 严重 |
|------|------|--------|------|
| 丢包率 | 0% | 0.01%-0.1% | >0.1% |
| TCP 重传率 | <0.1% | 0.1%-1% | >1% |

### 延迟相关

| 指标 | 正常 | 需关注 | 严重 |
|------|------|--------|------|
| 同机房 RTT | <1ms | 1-5ms | >5ms |
| 同城 RTT | <5ms | 5-20ms | >20ms |
| 跨区域 RTT | <50ms | 50-100ms | >100ms |
| RTT 标准差/均值 | <10% | 10%-30% | >30% |

## 注意事项

- AI 只执行查询/诊断命令，**不自动修改网络配置**（路由、防火墙、sysctl），修改建议仅作为参考
- ping 始终可用，其他工具按需检测，缺失时给出 yum/dnf install 建议
- nettrace 和 tcpdump 需要 **root 权限**
- iperf3 需要对端配合，且会占用带宽，仅在用户确认后执行
- 目标 100% 丢包时建议先用 `network-check` 排查连通性
- nettrace 的流式命令必须用 `timeout` 包裹，避免无限运行

## 相关技能

- [network-check](../../network-check/) — 网络基础连通性排查（解决"通不通"问题）
- [sched-latency](../../sched-latency/) — 进程调度延迟分析（CPU 调度导致的网络处理延迟）
- [syscall-hotspot](../../syscall-hotspot/) — 系统调用热点分析（应用层系统调用性能问题）
