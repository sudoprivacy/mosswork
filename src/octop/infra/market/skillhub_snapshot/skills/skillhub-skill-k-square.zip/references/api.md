# IMA 订阅知识库 API 参考

本文件是 SKILL.md 的补充，包含所有订阅知识库相关接口的完整参数定义。

## 通用调用方式

所有 `/openapi/wiki/v1/*` 接口统一使用：

```bash
curl -s -X POST "https://ima.qq.com/$endpoint" \
    -H "ima-openapi-clientid: $IMA_OPENAPI_CLIENTID" \
    -H "ima-openapi-apikey: $IMA_OPENAPI_APIKEY" \
    -H "Content-Type: application/json" \
    -d "$body"
```

---

## 1. 创建订阅知识库

`/openapi/wiki/v1/create_knowledge_base`

知识库类型 `type` 取值：
- 1001 = 个人知识库
- 1002 = 共享知识库
- **1004 = 订阅知识库**（发布到广场，可被搜索和加入）

请求体：
```json
{
  "name": "string, 必填, 1-25字符",
  "cover_url": "string, 可选, 封面URL",
  "description": "string, 可选, 简介, 最长150字符",
  "recommended_questions": ["string, 可选, 最多3个推荐问题"],
  "type": 1004
}
```

返回：
```json
{
  "id": "string, 新知识库ID",
  "name": "string, 知识库名称"
}
```

## 2. 搜索广场上的订阅知识库

`/openapi/wiki/v1/search_knowledge_base_in_square`

请求体：
```json
{
  "question": "string, 必填, 搜索关键词",
  "cursor": "string, 必填, 首次为空字符串",
  "limit": "uint64, 必填, 1-20"
}
```

返回：
```json
{
  "items": [
    {
      "kb_name": "string",
      "kb_id": "string",
      "member_count": "uint64",
      "content_count": "uint64",
      "creator": "string",
      "match_reasons": "int32[]  1=名称 2=简介 3=创建者 4=媒体标题"
    }
  ],
  "next_cursor": "string, 为空表示无更多数据"
}
```

> 注意：此接口用 `next_cursor` 为空判断结束，无 `is_end` 字段。

## 3. 加入订阅知识库

`/openapi/wiki/v1/join_knowledge`

请求体：
```json
{
  "knowledge_base_id": "string, 必填",
  "name": "string, 必填, 知识库名称"
}
```

返回：空响应表示成功。

## 4. 更新知识库权限（加入类型等）

`/openapi/wiki/v1/update_knowledge_base_permission`

请求体：
```json
{
  "update_fields": [2],
  "id": "string, 必填, 知识库ID",
  "name": "string, 可选, 校验用",
  "join_type": "int32, join_type字段: 1=直接加入, 2=管理员批准加入, 3=付费加入"
}
```

返回：空响应表示成功。

也可同时更新导出状态：
```json
{
  "update_fields": [1, 2],
  "id": "string",
  "visible_export_status": "1=不可查看不可导出, 2=可查看不可导出, 3=可查看可导出",
  "join_type": "1|2|3"
}
```

## 5. 查询我的订阅知识库

`/openapi/wiki/v1/search_knowledge_base`

请求体：
```json
{
  "query": "",
  "cursor": "",
  "limit": 20,
  "query_user": true
}
```

返回中 `base_type` 字段标识知识库类型：
- "个人" / "共享" / **"我创建的订阅"** / **"我加入的订阅"**

通过 `base_type` 筛选出订阅类型知识库即可。

## 6. 更新知识库基本信息

`/openapi/wiki/v1/update_knowledge_base_basic_info`

请求体：
```json
{
  "update_fields": "int32[]  1=名称 2=封面 3=简介 4=推荐问题",
  "id": "string, 必填",
  "current_name": "string, 可选, 校验用",
  "name": "string, 当 update_fields 包含 1 时必填",
  "cover_url": "string, 当 update_fields 包含 2 时必填",
  "description": "string, 当 update_fields 包含 3 时必填",
  "recommended_questions": ["string"], "当 update_fields 包含 4 时必填"
}
```

返回：空响应表示成功。

## 7. 浏览知识库内容

`/openapi/wiki/v1/get_knowledge_list`

请求体：
```json
{
  "knowledge_base_id": "string, 必填",
  "folder_id": "string, 可选, 省略则根目录",
  "cursor": "string, 必填",
  "limit": "uint64, 必填, 1-50"
}
```

## 8. 导入URL到知识库

`/openapi/wiki/v1/import_urls`

请求体：
```json
{
  "knowledge_base_id": "string, 必填",
  "folder_id": "string, 可选",
  "urls": ["url1", "url2", "最多10个"]
}
```
