---
name: skillhub-skill-y2k-retro-future-video-600029
description: "Y2K复古未来视觉AI视频生成技能：能力为Y2K千禧复古未来风格视频的全流程AI生成，包括金属光泽、赛博荧光、CRT扫描线、故障艺术、早期互联网美学；适用场景为潮流品牌、音乐MV、社交媒体内容、游戏宣传需要Y2K风格视觉时；触发词包括Y2K、千禧风、复古未来、蒸汽波风格视频、赛博荧光、CRT故障风。"
---

# Y2K复古未来视觉AI视频生成

## 核心能力

本Skill提供Y2K复古未来视觉AI视频生成的全流程指导，覆盖金属光泽、赛博荧光、CRT扫描线、故障艺术、早期互联网美学等视觉类型，强调五维Prompt体系。

## 方法论基础

基于Y2K美学体系：色彩（青柠绿+热粉红彩虹渐变、赛博紫+电光蓝、磨砂青+银金属光泽）、材质（厚塑料、拉丝铝、像素数字噪点、故障艺术、低多边形3D渲染）、字体（像素字体、粗圆无衬线镀铬描边、未来感模板）、视觉特效（CRT扫描线、JPEG压缩伪影、早期CGI镜头光晕、全息闪烁）、题材（早期互联网美学、拨号上网、数字日记界面、赛博城市）。核心技法：五维Prompt体系+复古数字质感叠加。

## 工作流

### 阶段一：风格定调
1. 确定色彩体系（彩虹渐变/电光蓝紫/金属银灰）
2. 确定材质语言（厚塑料/拉丝铝/低多边形）
3. 确定视觉特效（CRT/故障/全息/光晕）
4. 确定题材（数字日记/赛博城市/复古广告）

### 阶段二：镜头生成
1. 五维Prompt：色彩+材质+字体+特效+题材
2. 注入复古数字质感："subtle CRT screen scanlines, jpeg compression artifacts, early CGI lens flare"
3. 人物/场景设定："character wearing a metallic silver jacket, background of shifting iridescent gradients"
4. 多版本生成对比风格浓度

### 阶段三：后期合成
1. 叠加CRT扫描线/故障效果层
2. 调色：高饱和荧光色+金属高光
3. 字体排版：像素/镀铬描边/粗圆无衬线
4. 音频：Y2K风格电子乐/8-bit音效

### 阶段四：质量审核
1. Y2K风格元素是否到位
2. 色彩是否过于杂乱
3. 故障/CRT效果是否过度
4. 复古感与可读性平衡

## Prompt工程规范

### 基础公式
```
Y2K + 色彩体系 + 材质语言 + 题材
```

### 进阶公式（五维体系）
```
色彩(渐变/荧光/金属) + 材质(塑料/拉丝铝/噪点) + 字体(像素/镀铬/未来感) + 特效(CRT/故障/全息) + 题材(互联网/赛博/复古广告)
```

### 常用模板
- 标准Y2K："Generate a short video clip in the Y2K aesthetic, featuring {主体} with a background of {色彩渐变}, apply subtle scanlines and a slight glitch effect, use a chunky futuristic font for on-screen text"
- 金属光泽："{主体} wearing a metallic silver jacket, shifting iridescent gradients background, pixelated digital art, holographic shimmering effect"
- CRT赛博："cyberpunk cityscape inspired by early 2000s sci-fi, CRT screen scanlines, neon purple and electric blue glow"

## 质量检查清单

- [ ] Y2K风格元素到位（色彩/材质/特效）
- [ ] 色彩体系统一不杂乱
- [ ] CRT/故障效果适度
- [ ] 金属光泽真实
- [ ] 字体风格匹配（如含文字）
- [ ] 题材表达清晰
- [ ] 复古感与可读性平衡
- [ ] 分辨率不低于1080P
- [ ] 视觉节奏符合预期
- [ ] 无低质量伪影（jpeg artifacts适度）

## 输入规范

用户需提供：
- 色彩偏好（彩虹/电光蓝紫/金属银，可选）
- 题材（数字日记/赛博城市/复古广告，可选）
- 用途（音乐MV/品牌/社交内容，可选）
- 特效浓度（轻/中/重，可选）
- 时长要求（可选，默认10-30秒）

## 输出规范

生成结果包含：
1. 风格方案（五维定调：色彩+材质+字体+特效+题材）
2. Prompt列表（五维体系模板）
3. 工具链推荐（具体工具+参数设置）
4. 后期合成指南（特效叠加/字体/音频）

## 工具推荐

| 阶段 | 推荐工具 | 用途 |
|------|---------|------|
| 视频生成 | Runway Gen3 / Pika / 可灵AI | Y2K动态生成 |
| 图像生成 | Midjourney / Stable Diffusion | 关键帧/风格参考 |
| 特效叠加 | After Effects / CapCut | CRT/故障效果 |
| 字体排版 | Photoshop / Canva | 像素/镀铬字体 |
| 音频 | Suno AI / 8bit音乐库 | Y2K电子乐 |

## 参考资源

详细方法论、Prompt词库、工具参数指南请参阅 `references/internal-manual.md`。
完整输出模板与规范请参阅 `assets/specifications.json`。
