# Y2K复古未来视觉AI视频生成

## 简介
专为Y2K千禧复古未来风格设计的AI视频生成技能，覆盖金属光泽、赛博荧光、CRT故障、早期互联网美学等视觉类型。

## 适用场景
本Skill适用于需要Y2K风格视频场景的用户，包括潮流品牌、音乐MV、社交媒体内容、游戏宣传。

## 安装与使用
1. 在SkillHub中搜索"Y2K复古未来视觉AI视频生成"
2. 点击安装
3. 在对话中直接描述你的Y2K视频需求即可触发

## 触发词示例
- "帮我做一个Y2K风格短视频"
- "生成一个千禧复古风音乐MV"
- "做CRT故障风的赛博城市视频"

## 技术栈
- AI视频生成：Runway / Pika / 可灵AI
- AI图像生成：Midjourney / Stable Diffusion
- 特效叠加：After Effects / CapCut
- 字体排版：Photoshop / Canva
- 音频：Suno AI / 8bit音乐库

## 版本历史
- v1.0.0 (2026-08-14): 初始版本发布

## 作者
userId=600029

## 许可
MIT License

## 定价
付费(19.9元)
