---
name: skillhub-skill-mtp-m-build
description: "monster 的 MTP 0.2.4 主流程执行入口。执行/继续/恢复已批准 Task。"
---

# M-Build

```mermaid
flowchart LR
  A["Preflight"] --> B["取块"] --> C["实施/验证"] --> D["Acceptance"]
```

## Version Preflight

写入前读取 `$SKILL_DIR/MTP_VERSION` 和 `ai/mtp.json`。manifest 缺失、profile
不是 `lightweight`、缺少有效 `project_id` / `registry_id` 或版本不匹配时，返回
`m-new` 且零写。只有完整 Bundle `0.2.4` 项目才继续。

## 读哪块

| 状态 | 读 |
|---|---|
| 开始、选路径 | `blocks/path.md` |
| 写 `ai/`/收尾地图 | `blocks/project-memory.md` |
| Build 失败、阶段完成 | `blocks/failure-lesson.md` |
| 验完/审查/验收 | `blocks/acceptance.md` |
| 停手/检查点/Registry/发布 | `blocks/continuity.md` 等 |

## 硬要求

1. 机器校验才是 Gate；"稍后补测试"、"看起来没问题"、外部 Skill 声称都不算证据。
2. Execution Continuity：只按闭合清单停手（方向/分歧/发布/plan 失效/不可自愈）。
3. 审查 Agent-对-Agent，不得降级自审；修复只做定点复查、不得扩大；删除入 `.pending-delete/`。
