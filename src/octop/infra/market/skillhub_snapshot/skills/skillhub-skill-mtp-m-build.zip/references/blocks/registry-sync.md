trigger: 项目创建/升级、entry point 或 capability 变化、或要 Acceptance 前同步事实
budget: 900
next: 同步成功才能做依赖 Registry 的 Acceptance

# Registry Sync Gate

项目创建或升级，以及已接受的 entry point、interface、capability、Active Lesson、portable
location 或 lifecycle 变化，均触发 Project Passport/Registry 同步；纯内部变化不触发。Registry
相关 Task 只有发布整合到 local `main` 后才能 Acceptance。不可用、冲突或脏状态时保留本地事实与
证据、清理自有临时资源，并只在 `ai/NEXT.md` 写 `registry pending`，下一次相关 MTP 调用重试；
不得把 pending 写入 Passport。Lesson/Registry 证据不能替代 AC/TC 覆盖、fresh verification、必需
审查或既有机器 Gate。

**刷新命令**：摘要与 tags 只能由 Passport 派生（不读 `ai/brief.md`、`IMPL_LOG`、`NEXT`、`plan`、
`lessons` 或 git log）。触发点只有三个：`m-new` setup、本 Sync Gate、显式 refresh；三者共用同一
入口：

```bash
python3 <m-new>/scripts/plan_setup.py --target <项目根> --refresh-registry --json
```

刷新失败（`registry-summary-not-ready`）说明 Passport 四节没填全或摘要空洞，先补 Passport，不得
手写记录绕过。公共 `publish` 对 `kind: project` 会拒绝占位摘要、实质 tag 少于 3 个、摘要等于
title、以及源项目没有可核对的 Passport 块的手写记录。
