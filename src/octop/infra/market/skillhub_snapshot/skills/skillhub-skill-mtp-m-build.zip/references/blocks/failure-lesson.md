trigger: Build 失败后、阶段或里程碑完成时
budget: 1300
next: 修好并验证后只做一次 Lesson Check，再回 acceptance.md

# 失败与阶段沉淀

## Failure To Lesson Feedback

每次 Build 失败后，先记录 `scripts/lesson_gate.py failure_decision` 的结果。仅"首次、低风险、
修复明显、非复发、非高代价且无 tag 命中"的失败可记 `skip-lookup`；其他失败均先查询本地 Active
Lessons，且本地证据不足或跨项目经验可能相关时再查询 Registry 的 Active Lessons。Candidate 和
Deprecated 不进入普通共享检索。

修复后必须先通过针对性验证，再执行且只执行一次 Lesson Check，写入 `no-lesson`、`candidate` 或
`active` 之一，并保留根因、必要动作、验证和证据；Candidate/Active 另保留 fingerprint 和 tags。
未通过验证、缺字段或立即标为 Deprecated 都不得进入审查。两次已验证的匹配复发，或一次证据完整的
高代价事件，自动晋升 Active；Deprecated 只用于之后有新 Active Lesson 替代既有 Active Lesson 的
生命周期更新。

## Phase Knowledge Check（L-013）

在计划预先声明的阶段/里程碑完成、真实交接前与发布前，主 Agent 必须回看该阶段，按三类分流沉淀并
留下机器可判的检查记录——**缺记录不得把该阶段标记完成**：

1. `lessons`：可复发或高代价经验 → `ai/lessons.md`；
2. `capability`：可跨项目复用的成果 → Capability Card / Registry；
3. `docs`：关键决策或当前事实 → 对应项目文档。

每类取 `record` / `none` / `no-new-deposit` 之一；全无新增时也必须留 `no-new-deposit` 结论。值域
封闭，任何非法值 fail closed。判定见 `scripts/lesson_gate.py phase_knowledge_check` 与
`phase_completion_blocked`。该机制不同于每次失败修复后的 Lesson Check：前者提炼整个阶段的项目
记忆，后者只裁定该失败是否形成 Lesson。私有 Agent 记忆只能辅助，不得替代共享项目证据。
