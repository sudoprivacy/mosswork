trigger: 写入前建检查点、或要 accept / rollback
budget: 700
next: accept 后回 acceptance.md；rollback 结果写回同一状态文件

# Checkpoint And Rollback

执行写入前，主 Agent 使用 `scripts/execution_checkpoint.py create` 在仓库外记录 clean
`base_commit`、Task 身份和当前 plan revision。验证与 Acceptance 完成后，使用 `accept` 记录 clean
HEAD 为 `accepted_commit` 及非空 verification evidence。`rollback` 只接受当前 HEAD 正好是 accepted
commit、目标是其祖先、计划身份仍匹配、无 active writer 且 `external_effects` 为空的状态；它用
`git revert base_commit..accepted_commit` 保留历史，冲突自动 abort。数据库、凭据、远程或其他外部
副作用不由 Git 自动补偿，直接 fail closed。checkpoint 状态文件必须位于仓库外；rollback 结果、验证
证据和 resulting commit 写回同一状态文件。
