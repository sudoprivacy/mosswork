trigger: Git 不可用、要发布/安装/打 tag，或核对版本头
budget: 900
next: 发布是边界：停下问 owner

# Git 能力与发布位置

Git 与 Registry locator 状态由 `scripts/capability_matrix.py` 统一判定；`execution_checkpoint.py`
在 create/accept/rollback 入口前置该 Gate，并以 `registry_capability(op)` 暴露同一判定，供 Registry
sync 与 Registry 相关 Acceptance（`lesson_gate.registry_sync_gate` 的 publication `reason`）复用，
不允许出现第二套可用性判断。无 Git 时本地修复、受影响验证与 Lesson Check 继续，共享查找/同步、
Registry 相关 Acceptance、checkpoint、rollback、tag、formal-release 全部 blocked；locator 缺失时
仅在 bootstrap 后恢复；locator 失效时要求显式 repair 且始终非 Accepting。

## Release Position

发布/分发在协议中**有位**：formal release 是独立的一步，只在 Git 可用时执行，且是**发布边界**
（闭合清单）——需 owner 明确授权，不随 build 自动发生。rollback 对发布动作 fail closed：数据库、
凭据、远程推送、安装或 tag 等外部副作用不由 Git 自动补偿。
一个 Task 的 `Acceptance` 不自动等于联网发布、安装或跨电脑同步。

版本头必须单一：`skills/mtp/VERSION`、`ai/mtp.json` 的 `mtp_version`、README 标题与 CHANGELOG 的
最新段必须一致，避免版本双头。
