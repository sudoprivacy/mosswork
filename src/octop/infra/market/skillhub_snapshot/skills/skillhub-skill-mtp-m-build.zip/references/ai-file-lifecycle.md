# `ai/` 长文件生命周期（L-031 ⑤⑥⑦）

> 本文件是 `ai/` 根文档治理的**唯一规范**。`project_memory.py` 的常量与之一一对应；
> 两边不一致视为缺陷，由测试 `test_ai_file_lifecycle.py` 拦住。

## 头部块

每个 `ai/` 根文档的**前 2 KB** 是恢复入口，只放三样东西：

1. **当前状态一句话**：做到哪、卡在哪。
2. **红线 ≤ 5 条**：违反即返工的硬约束，每条一行。
3. **入口指针**：细节在哪读（`ai/brief.md`、`ai/plan.md`、归档路径）。

规则：

- 头部块只写**指针**，不写细节；细节写到被指向的文件。
- 恢复流程只读头部块，其余内容**按引用读取**，不做全量加载。
- 章节定位一律用**标题文本**（`## 主线`），禁用行号锚（行号会因插入而失效）。
- 「红线 ≤ 5 条」是硬上限；超过 5 条说明该拆到 `ai/brief.md` 的边界节。

## marker

marker 用于标记可整段搬移的区间，与 `MTP:MAP` 命名空间**互不相干**。

| 用途 | 形式 |
|---|---|
| 区间开始 | `<!-- MTP:ROT:BEGIN segment=<name> -->` |
| 区间结束 | `<!-- MTP:ROT:END segment=<name> -->` |
| owner 收线确认 | `MTP:ROT-CONFIRM <segment> <ver> <iso8601> <digest>` |

规则：

- `segment` 用 `[A-Za-z0-9._-]+`，同名 segment 在**整个 `ai/` 内唯一**。
- 禁止嵌套；未闭合或嵌套一律 fail closed，零写。
- 搬移后原位置只留**恰一行**指针：`> 已迁至 <path>（segment=<name>）`。
- `backlog.md` 是表格，不支持 marker；它的收线靠 `State: resolved` 行规则。
- `brief.md` 是合同文件，不做 marker 化，只按版本整段迁移。
- `MTP:ROT-CONFIRM` 每段每版本**只允许一次**，由 owner 在 L2 收线时给出；出现两条即拒绝。
- `digest` 必须等于该次 `rotate --preview` 输出的 `preview_digest`——确认绑定的是**审过的那份正文与目标**；
  缺失即 `rot-confirm-unbound`，不符即 `rot-confirm-digest-mismatch`。

## L0

**L0 = 每次写入前跑得起的机械检测**，只看字节与计数，不做内容判断。

| 对象 | 预算（字节） | 超限处理 |
|---|---|---|
| `ai/NEXT.md`（含头部块） | 2048 | warn |
| `ai/brief.md` | 24576 | warn |
| `ai/plan.md` | 49152 | warn |
| `ai/backlog.md` | 65536 | warn |
| `ai/lessons.md` | 16384 | warn |
| `ai/review.md` | 24576 | warn |
| `ai/OWNER_DECISIONS.md` | 24576 | warn |
| `ai/` 根文档合计 | 49152 | warn |
| `ai/backlog.md` 的 open 条目数 | 15 | warn |
| 含红线条款的文件 | 上述预算 + 500 | warn |

- 检测结果只产生 **suggestion**，不阻断写入；建议的 key 固定为 `<file>:<kind>`（例：`ai/NEXT.md:over-budget`），**不含任何数值**，便于跨次运行去重。
- `kind` 词表：`over-budget`、`under-budget`、`over-total`、`backlog-open`、`red-line-extra`。
- 红线例外 +500 只作用于**明确写了红线条款**的文件，不得用于整体放宽。

## L2

**L2 = 版本收线时的段落轮换**，是唯一会移动正文的动作。

1. 收线前对每个 `segment` 跑 `project_memory.py rotate --preview`：输出源文件、起止行、字节数、目标路径、`preview_digest` 与 `preview_at`，零写。
2. **owner 确认（apply 之前）**：owner 看完 preview 后，在 `ai/IMPL_LOG.md` 写**一条**
   `MTP:ROT-CONFIRM <segment> <ver> <iso8601> <digest>`——`digest` 原样复制该次 preview 的
   `preview_digest`，时间必须晚于 `preview_at`。缺失、重复、版本不符、时间倒置或 digest 不符，
   `rotate --apply` 一律零写拒绝。
3. `rotate --apply`：带 `--version <ver> --preview-at <preview_at> --expect-digest <digest>`。
   段落原文（含 marker 行）搬到 `ai/archive/<ver>/<file>-<ver>.md`，原位置留一行指针，
   并在 `ai/IMPL_LOG.md` 追加一行 `rotate:` 记账。
4. 搬移前检查根文件内是否仍有对段落的字符串引用；命中即拒绝搬移并给出行号。
5. 工具只检查根文件内部引用，**必须显式声明「未检查外部指针」**。

## 禁止

- 禁止新增 `ai/` 根文件；需要新文件先在 `ai/plan.md` 声明并更新 `CLAUDE.md` 的固定集合。
- 禁止用行号锚定位段落。
- 禁止在头部块写细节或复制长上下文。
- 禁止让 marker 跨越 `MTP:MAP` 块边界。
- 禁止 `rotate` 复用 `sync` / `sync-current-state` 的写事务。
- 禁止在未做备份的情况下对真实 `Registry` 做任何写操作。
- 禁止把本规范的阈值复制到第二处真源：数值只在 `project_memory.py` 定义一次。
