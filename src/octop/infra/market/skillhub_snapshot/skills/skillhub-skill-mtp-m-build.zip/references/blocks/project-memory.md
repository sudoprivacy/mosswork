trigger: 要写 `ai/`、同步地图、收尾 Task、选 Lesson
budget: 1400
next: 回到 SKILL.md 路由；失败转 failure-lesson.md

# Project Memory

`CLAUDE.md` 全量同步只在用户明确请求时进入 Direct Path；**`Current State` 例外，由 Task 收尾自动
重写**。主 Agent 先核对全部十个固定区块及 `ai/brief.md`、`ai/NEXT.md` 等事实源，再形成完整
projection；目标、范围、边界或当前状态存在冲突时，以 `conflicts` 路由 `m-define` 且零写。无冲突时
使用 `scripts/project_memory.py sync` 的 dry-run digest 和 `--explicit-request --actor primary` 执行；
helper 只更新缺失或陈旧的 MTP map 子区块，保留其余用户内容，重复同步字节不变。

**Task 收尾（D-4）**：每个 Task 验收或发布动作完成后，主 Agent 必须跑
`scripts/project_memory.py sync-current-state --apply`，从 `ai/NEXT.md` 机械生成 `Current State`
（重复执行字节不变），再跑 `lint` 确认无 error。该生成器是 `Current State` 的**唯一写者**；手写
该节视为违规。

**文档检查**：`lint --target <项目>` 同时给出三项只读质量检查——`missing-h1` / `placeholder-h1` /
`junk-h1`（`#` 一级标题必须是项目真名）、`structure-missing-tree` / `structure-lists-generated` /
`structure-path-missing`（`Structure` 必须有 ` ```text ` 目录树、不列生成物、一级路径真实存在）、
`name-title-mismatch`（H1 与项目目录名一致）。`name-title-mismatch` 默认 `warn`，把
`project_memory.py` 的 `NAME_TITLE_ENFORCEMENT` 改为 `block` 后进 error 并阻断。`lint` 输出另含
`budget_suggestions`（本版本恒为空，留给 L-031 T5 接线）。

**`ai/` 文件生命周期（L-031）**：头部块构成、`MTP:ROT` marker、L0 检测阈值、L2 收线轮换与禁止项，
唯一规范见 [ai-file-lifecycle.md](../references/ai-file-lifecycle.md)；阈值数值只在 `project_memory.py` 的
`AI_FILE_BUDGETS` / `AI_FILE_TOTAL_BUDGET` / `BACKLOG_OPEN_WARN` / `AI_FILE_RED_LINE_EXTRA` 定义一次。

## Lessons 选择与写入

`ai/lessons.md` 不属于默认上下文。执行前根据当前 Task 的 tools、platforms、paths 和 failure
symptoms 调用 `scripts/project_memory.py select`，只读取匹配的 Active Lessons。只有主 Agent 可用
`lessons` 子命令写入：已验证且可能复发的问题先记 Candidate；不同执行 attempt 复发两次后晋升，或
在高代价事件的根因、动作和验证证据完整时直接晋升。普通日志、猜测、风格偏好和一次性低代价事件不
记录；失效 lesson 用明确 update/delete 原位维护。Child Agent 不得写 `CLAUDE.md` 或
`ai/lessons.md`。
