trigger: Task 开始、或要判断走哪条路径
budget: 900
next: 实施；失败转到 failure-lesson.md

# 路径与 Gate

所有执行、审查和验收遵循 Think Before Coding、Simplicity First、Surgical Changes 和
Goal-Driven Execution。只实现 Task 所需的最小差异；每个改动和阻塞发现必须能追溯到目标、AC、TC、
强制合同或明确威胁模型，无关发现写 backlog。

**Direct Path**：用户请求清晰、边界明确、局部、可逆且可确定验证，并且没有实质歧义、共享合同、
业务数据迁移、权限或安全边界、远程不可逆副作用、大范围删除、真实并发或不可验证行为时，主 Agent
立即直接实施。此路径不要求 `ai/plan.md`、`plan_commit` 或 `ai/NEXT.md`，不启动 Plan、Reviewer 或
子 Agent，不建立审查 artifact，也不运行无关完整 Gate；只运行受影响验证，通过后立即停止。目标验证
失败时停止并报告当前失败，不以失败为理由扩大审查或测试范围。

**Planned Simple Path**：Task 为 `execution=primary`、`review=self`、`risk=low` 时，立即由主 Agent
顺序实施和自审；升级信号与 Direct Path 相同。不启动 Reviewer 或子 Agent，不建立独立审查 artifact，
只跑受影响验证；不加载并发、工作树或多阶段审查规则。验证通过后记录 Acceptance 并立即停止。

**Complex Path**：其余 Task 才读取 `references/execution-rules.json` 与
`references/complex-execution.md`，并用 `scripts/execution_policy.py` 的纯决策检查。任何缺失、未知、
陈旧或冲突条件都按不可用处理并零授权写入；简单路径不得加载这些规则。保留 primary/child 能力、
BASE、取消、packet、writer、review、artifact HEAD、Gate 和 AI 边界；审查修复只做原发现及直接影响
面的定点复查，Reviewer 不得扩大已批准威胁模型。

## Gate Guardrails

"稍后补测试"、"看起来没问题"、"改动太小不用审查"、Reviewer 不可用，或外部 Skill 声称已验证，
都不是通过 AC、TC、受影响验证、强制审查或 Acceptance 的证据。机器校验仍是 Gate；缺少必要证据时
停止或按 Task 合同 Blocked，不能借 Direct Path、委派或外部 Skill 扩大授权。

普通简单工作不需要用户先授权。对一个精确动作的明确授权只消除该动作是否被允许的歧义；它不能覆盖
真实安全边界，也不能把升级信号改写成简单路径。

Superpowers 或其他外部 Skill 只能提供 TDD、调试、验证或编码方法；不能扩大 Task 路径、新增
Agent/审查/commit，或覆盖 MTP gate。冲突时停止并交由主 Agent 解决。

## 计划身份

主 Agent 是唯一调度者、集成者和 `ai/` 状态写入者。Direct Path 以外的 Task，先确认 `plan_commit`
是真实 Git commit，再读取该 commit 的 `ai/plan.md` 中唯一的语义计划块及 `ai/NEXT.md` 指向的当前
Task；用 plan validator 核对 `plan_revision`、BASE、Task ID 和完整 Task 合同，不信任状态布尔值或
调用方提供的计划对象。
