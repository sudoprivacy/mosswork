# Complex Execution Rules

Load this reference only after the M-Build complex-path trigger is true. The JSON contract and
`execution_policy.py` remain authoritative; this file keeps the branch procedure out of the simple
path context.

1. Recover cancellation first: inspect active rows and live children, interrupt residual writers,
   and do not dispatch until they terminate. Hard UI cancellation does not guarantee cascade; late
   results are invalid and never auto-integrated.
2. Before isolated dispatch, verify Accepted dependencies, exact fresh worktree/root/branch, BASE
   baseline PASS, current plan identity, and no path or exclusive-resource conflict. A failed
   baseline authorizes zero writes.
3. Use a fresh worker for a new Task; reuse a terminated worker only for the same Task fix. Workers
   create no descendants. One writer owns each file/resource; parallel work requires disjoint
   declared and actual scope.
4. Packets contain only the whitelist fields, use a unique historical `dispatch_id`, and obey active,
   packet, report, and same-blocker redispatch limits. Workers do not write `ai/`, integrate, install,
   push, publish, handle credentials, or start background processes.
5. Worker outcomes stop at Review or Blocked, never Accepted. Low-risk work is self review, medium is
   combined, and high-risk implementation is spec then quality on one fixed artifact HEAD. Missing
   mandatory reviewers block. Combined review is one full pass; after a repair, recheck only the
   original finding and direct impact unless scope or a public contract changed. P0/P1 findings
   require contract evidence, reproduction, real premise and user consequence; otherwise record P2
   or backlog. Historical issues, hypothetical threats, style preferences and future enhancements
   do not block the current Task.
6. The primary Agent checks the real diff, scope, ancestry and clean HEAD. A fresh Gate follows
   identity-preserving integration before writing `ai/NEXT.md`, `ai/review.md` and `ai/IMPL_LOG.md`.

External Skills may provide TDD, debugging, verification or coding technique only. They cannot widen
scope, add agents/reviews/commits, override the Gate, or resolve a conflict; the primary Agent stops
and resolves such a conflict.
