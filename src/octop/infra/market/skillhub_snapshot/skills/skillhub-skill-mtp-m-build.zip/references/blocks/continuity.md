trigger: 判断能不能继续、要不要停下来问用户、或要删东西
budget: 900
next: 继续执行；遇发布边界转 capability-release.md

# Execution Continuity

一个已批准的 plan（`approval: approved`）是**一次性连续执行授权**：在批准的范围内顺序跑完全部
Task，**不逐 Task 停下来问用户**。此契约覆盖整个 plan，包括连续性契约交付之前的 Task
（RECON/BASE/REGISTRY）。

只有**闭合清单**才产生用户交互，且必须停下：

1. 方向性新决策（改变方向或范围的新决定）；
2. 真实分歧（未解决的真实分歧）；
3. 发布边界（release / distribution 边界）；
4. plan 失效（已批准 plan 不再成立）；
5. 无法自愈的阻塞失败（需用户提权 / 需用户数据 / 需外部凭证）。

**审查走 Agent-对-Agent**：由子 Agent 或另一个会话/Agent 通道（如 OC）完成，不拉用户；缺少独立
审查者时按 Task 合同 Blocked，**不得降级为自审**。低风险 `review=self` 无需独立审查者。

**删除走暂存后置清理**：执行中要删除的内容先移入暂存目录 `.pending-delete/`（不进 Git），任务
完成后**一次性清理**——删除不产生中途用户交互。未入库内容的删除视为不可逆，须先入库再删。

机器判定见 `scripts/execution_policy.py` 的 `continuity_requires_user` /
`continuity_allows_auto_continue` / `continuity_review_ok` / `stage_deletion`。
