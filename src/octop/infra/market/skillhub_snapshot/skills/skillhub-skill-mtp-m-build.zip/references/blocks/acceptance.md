trigger: Task 验证通过、准备审查、Acceptance 或发布判定
budget: 700
next: 交审查 → 记录 Acceptance

# 验收证据

计划 Task 的 Acceptance 要求每个 TC 一条 `passed` 证据；证据必须含检查与结果，并同时绑定
`task_id`、批准的 `plan_commit`、规范化 `plan_revision` 和固定 `artifact_head`。缺失、失败、
跳过、重复、陈旧或无关证据一律不接受；Direct Path 仍只运行受影响验证，不进入计划证据流程。

审查与停手合同在 [continuity.md](continuity.md)：审查走 Agent-对-Agent、不得降级为自审、
修复只做定点复查；发布是独立边界，见 [capability-release.md](capability-release.md)。
