#!/usr/bin/env python3
"""Deterministic failure, Lesson Check and Registry-sync gates for M-Build."""

from __future__ import annotations

import importlib.util
import re
from pathlib import Path
from typing import Any


def _load_capability_provider():
    path = Path(__file__).resolve().parent / "execution_checkpoint.py"
    spec = importlib.util.spec_from_file_location("mtp_execution_checkpoint_provider", path)
    if spec is None or spec.loader is None:
        raise LessonGateError("capability provider unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_PROVIDER = None


def _registry_capability(op: str) -> dict[str, Any]:
    """Evaluate one Registry-dependent M-Build operation against the live state.

    The same provider that gates checkpoint and rollback (AC-014X-7) also gates
    Registry sync and Registry-relevant Acceptance, so the matrix stays the single
    source of truth and a caller can never forge or omit the availability verdict.
    """
    global _PROVIDER
    if _PROVIDER is None:
        _PROVIDER = _load_capability_provider()
    return _PROVIDER.registry_capability(op)


class LessonGateError(ValueError):
    """Raised when a Lesson or Acceptance gate is incomplete."""


IMMEDIATE_STATUSES = {"no-lesson", "candidate", "active"}
MACHINE_GATE_KEYS = {"ac_tc_coverage", "fresh_verification", "required_review"}
DISCOVERABLE_KEYS = {
    "project_created", "project_upgraded", "entrypoints", "interfaces",
    "capabilities", "active_lessons", "portable_location", "lifecycle",
}
GIT_REVISION = re.compile(r"[0-9a-f]{40}")


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise LessonGateError(f"{field} is required")
    return value.strip()


def _tags(value: Any) -> dict[str, list[str]]:
    fields = ("tools", "platforms", "paths", "symptoms")
    if not isinstance(value, dict) or set(value) != set(fields):
        raise LessonGateError("lesson tags are incomplete")
    if any(not isinstance(value[key], list) for key in fields):
        raise LessonGateError("lesson tags are invalid")
    return {key: sorted({str(item) for item in value[key] if str(item).strip()}) for key in fields}


def failure_decision(
    failure: dict[str, Any], local_lesson_ids: list[str] | None = None,
) -> dict[str, Any]:
    """Choose the smallest permitted lookup path after every failed attempt."""
    if not isinstance(failure, dict):
        raise LessonGateError("failure is invalid")
    local = list(local_lesson_ids or [])
    first_low_risk = (
        isinstance(failure.get("attempt"), int)
        and not isinstance(failure.get("attempt"), bool)
        and failure.get("attempt") == 1
        and failure.get("risk") == "low"
        and failure.get("evident_fix") is True
        and failure.get("recurring") is False
        and failure.get("high_cost") is False
        and failure.get("tag_match") is False
    )
    if first_low_risk:
        return {
            "decision": "skip-lookup",
            "reason": "first-occurrence-low-risk-evident-fix",
            "selected_lesson_ids": [],
        }
    if local:
        return {
            "decision": "local-first",
            "reason": "matching-local-active-lessons",
            "selected_lesson_ids": sorted(set(local)),
            "shared_fallback": True,
        }
    return {
        "decision": "local-first-then-shared",
        "reason": "failure-requires-reusable-guidance",
        "selected_lesson_ids": [],
        "shared_fallback": True,
    }


def lesson_check(repair: dict[str, Any]) -> dict[str, Any]:
    """Require verification and exactly one immediate Lesson classification."""
    if not isinstance(repair, dict) or repair.get("verified") is not True:
        raise LessonGateError("targeted verification must pass before Lesson Check")
    status = repair.get("status")
    if status not in IMMEDIATE_STATUSES:
        raise LessonGateError("immediate Lesson Check status is invalid")
    result = {
        "status": status,
        "root_cause": _text(repair.get("root_cause"), "root_cause"),
        "required_action": _text(repair.get("required_action"), "required_action"),
        "verification": _text(repair.get("verification"), "verification"),
        "evidence": _text(repair.get("evidence"), "evidence"),
    }
    if status in {"candidate", "active"}:
        result["fingerprint"] = _text(repair.get("fingerprint"), "fingerprint")
        result["tags"] = _tags(repair.get("tags"))
    return result


def can_review(repair: dict[str, Any]) -> bool:
    try:
        lesson_check(repair)
    except LessonGateError:
        return False
    return True


def promote_candidate(candidate: dict[str, Any]) -> str:
    """Return the only legal promotion outcome for verified reusable evidence."""
    if not isinstance(candidate, dict) or candidate.get("verified") is not True:
        raise LessonGateError("candidate evidence is not verified")
    occurrences = candidate.get("verified_recurrences", 0)
    if not isinstance(occurrences, int) or isinstance(occurrences, bool):
        raise LessonGateError("verified_recurrences is invalid")
    complete = all(_text(candidate.get(field), field) for field in (
        "root_cause", "required_action", "verification", "evidence",
    ))
    if candidate.get("high_cost") is True and complete:
        return "active"
    if occurrences >= 2 and complete:
        return "active"
    return "candidate"


def supersede_active(active: dict[str, Any], replacement: dict[str, Any]) -> dict[str, Any]:
    """Deprecation is legal only when an existing Active Lesson is superseded."""
    if not isinstance(active, dict) or active.get("status") != "active":
        raise LessonGateError("only an Active Lesson can be superseded")
    _text(active.get("id"), "active lesson id")
    checked = lesson_check(replacement)
    if checked["status"] != "active":
        raise LessonGateError("replacement must be Active")
    return {"deprecated_id": active["id"], "replacement_status": "active"}


def discoverable_change(changes: dict[str, Any]) -> bool:
    if not isinstance(changes, dict):
        raise LessonGateError("changes are invalid")
    return any(changes.get(key) is True for key in DISCOVERABLE_KEYS)


def registry_sync_gate(
    changes: dict[str, Any], publication: dict[str, Any] | None,
) -> dict[str, Any]:
    """Keep unsynchronized state project-local and block Registry-relevant acceptance.

    AC-014X-7: the live capability matrix is the ONLY source of truth for whether
    Registry sync may proceed. The caller's ``publication`` is never trusted on its
    own -- without Git, or with a missing/invalid locator, sync is blocked with the
    matrix reason even if a ``published`` record is supplied.
    """
    triggered = discoverable_change(changes)
    if not triggered:
        return {"decision": "not-triggered", "acceptance": "allowed", "passport": "unchanged"}
    capability = _registry_capability("registry-sync")
    if not capability["available"]:
        return {
            "decision": "registry-pending", "acceptance": "blocked",
            "persist": "ai/NEXT.md-only", "passport": "unchanged",
            "reason": capability["reason"],
            "cleanup": "owned-temporary-resources", "preserve": "local-facts-and-evidence",
            "retry": "next-relevant-mtp-invocation",
        }
    revision = publication.get("registry_revision") if isinstance(publication, dict) else None
    if isinstance(publication, dict) and publication.get("status") == "published" \
            and isinstance(revision, str) and GIT_REVISION.fullmatch(revision):
        return {
            "decision": "synced", "acceptance": "allowed",
            "registry_revision": revision,
        }
    reason = publication.get("reason", capability["reason"]) if isinstance(publication, dict) else capability["reason"]
    return {
        "decision": "registry-pending", "acceptance": "blocked",
        "persist": "ai/NEXT.md-only", "passport": "unchanged", "reason": reason,
        "cleanup": "owned-temporary-resources", "preserve": "local-facts-and-evidence",
        "retry": "next-relevant-mtp-invocation",
    }


def acceptance_gate(
    repair: dict[str, Any], changes: dict[str, Any], publication: dict[str, Any] | None,
    machine_gates: dict[str, Any],
) -> dict[str, Any]:
    check = lesson_check(repair)
    sync = registry_sync_gate(changes, publication)
    if sync["acceptance"] != "allowed":
        raise LessonGateError("Registry Sync Gate blocks Acceptance")
    if not isinstance(machine_gates, dict) or set(machine_gates) != MACHINE_GATE_KEYS \
            or any(machine_gates[key] is not True for key in MACHINE_GATE_KEYS):
        raise LessonGateError("existing machine Gates are incomplete")
    return {
        "lesson_check": check,
        "registry_sync": sync,
        "machine_gates": dict(sorted(machine_gates.items())),
        "acceptance": "allowed",
    }



# --- MTP 0.2.0 phase knowledge check (L-013) ------------------------------------
# Three deposit classes; a phase may legitimately deposit nothing, but the review
# must be recorded explicitly (no-new-deposit) — an absent record blocks phase
# completion / handoff / release.
#
# Class mapping (L-013 "决策/可复用能力/领域知识" -> deposit routing). The three
# classes are the L-013 *destinations*, and the third one ("key decisions / current
# facts -> that project's own document") is keyed ``docs`` because it lands in project
# documents rather than in the Registry:
#   lessons    : recurring / high-cost experience -> ai/lessons.md
#   capability : cross-project reusable outcome   -> Capability Card / Registry
#   docs       : key decisions / current facts     -> the project's own documents
DEPOSIT_CLASSES = ("lessons", "capability", "docs")
NO_NEW_DEPOSIT = "no-new-deposit"
DEPOSIT_ACTIONS = ("record", "none", NO_NEW_DEPOSIT)


def phase_knowledge_check(deposit: dict[str, Any]) -> dict[str, Any]:
    """Validate a phase/ milestone knowledge-deposit review (L-013).

    ``deposit`` must carry per-class actions (``lessons``/``capability``/``docs`` — one
    of ``record``/``none``/``no-new-deposit``) and, when nothing is recorded, an explicit
    ``no-new-deposit`` conclusion. The value domain is closed: any value outside the
    three permitted actions fails closed, so a non-empty string can never masquerade as a
    deposited record. Missing/invalid shape fails closed.
    """
    if not isinstance(deposit, dict):
        raise LessonGateError("phase knowledge deposit missing")
    if set(deposit) != set(DEPOSIT_CLASSES):
        raise LessonGateError("phase knowledge deposit fields invalid")
    actions = []
    for cls in DEPOSIT_CLASSES:
        value = deposit[cls]
        # Closed value domain: only the three permitted actions count as a record.
        if not isinstance(value, str) or value.strip() not in DEPOSIT_ACTIONS:
            raise LessonGateError(f"phase knowledge deposit {cls} invalid")
        actions.append(value.strip())
    recorded_classes = [cls for cls in DEPOSIT_CLASSES if deposit[cls].strip() == "record"]
    if not recorded_classes:
        # Nothing recorded: the review must still carry the explicit conclusion marker,
        # and ``no-new-deposit`` is only legal when no class also claims ``record``.
        if NO_NEW_DEPOSIT not in actions:
            raise LessonGateError("phase knowledge deposit requires no-new-deposit")
        decision = NO_NEW_DEPOSIT
    else:
        if NO_NEW_DEPOSIT in actions:
            raise LessonGateError("no-new-deposit conflicts with recorded deposits")
        decision = "deposited"
    return {
        "classes": {cls: deposit[cls] for cls in DEPOSIT_CLASSES},
        "deposited": recorded_classes,
        "decision": decision,
    }


def phase_completion_blocked(deposit: dict[str, Any] | None) -> bool:
    """A phase may not be marked complete without a valid knowledge-check record."""
    if deposit is None:
        return True
    try:
        phase_knowledge_check(deposit)
    except LessonGateError:
        return True
    return False


def recommend_mechanism(occurrences: int, high_cost: bool = False) -> str:
    """B-5: a recurring lesson (>=2 verified occurrences) or a high-cost event is a
    mechanism candidate rather than a one-off lesson."""
    if not isinstance(occurrences, int) or isinstance(occurrences, bool) or occurrences < 1:
        raise LessonGateError("occurrences invalid")
    if high_cost or occurrences >= 2:
        return "mechanism-candidate"
    return "lesson-only"


def handoff_evidence(

    check: dict[str, Any], registry_revision: str | None, registry_pending: bool,
) -> dict[str, Any]:
    checked = lesson_check(dict(check, verified=True))
    if not isinstance(registry_pending, bool):
        raise LessonGateError("registry_pending is invalid")
    if registry_revision is not None:
        registry_revision = _text(registry_revision, "registry revision")
    if registry_pending and registry_revision is not None:
        raise LessonGateError("pending handoff cannot claim a Registry revision")
    return {
        "lesson_check": checked,
        "consulted_registry_revision": registry_revision,
        "registry_pending": registry_pending,
    }
