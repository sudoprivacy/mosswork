#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CONTRACT_PATH = ROOT / "references/rollback-contract.json"
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
REVISION_RE = re.compile(r"^[0-9a-f]{64}$")
STATUSES = {"started", "accepted", "rolled-back"}
STATE_FIELDS = {
    "version", "task_id", "plan_commit", "plan_revision", "base_commit",
    "accepted_commit", "resulting_commit", "status", "verification",
    "rollback_verification", "active_writer", "external_effects", "repo",
}


class CheckpointError(RuntimeError):
    pass


def _load_capability_matrix():
    path = Path(__file__).resolve().parents[2] / "m-build" / "scripts" / "capability_matrix.py"
    spec = importlib.util.spec_from_file_location("mtp_capability_matrix_cp", path)
    if spec is None or spec.loader is None:
        raise CheckpointError("capability matrix unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_registry_helper():
    path = Path(__file__).resolve().parents[2] / "m-new" / "assets" / "template" / "ai" / "registry.py"
    spec = importlib.util.spec_from_file_location("mtp_registry_cp", path)
    if spec is None or spec.loader is None:
        raise CheckpointError("registry helper unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _locator_facts() -> tuple[str | None, bool]:
    """Read-only probe of the same-OS-user Registry locator (AC-014X-2/3).

    Returns the raw locator value and whether it currently resolves. The probe never
    writes, never scans the filesystem for a Registry and never guesses a default: a
    locator that is absent stays absent, and one that is present but unusable stays
    raw-but-invalid so the matrix can demand explicit repair.
    """
    try:
        helper = _load_registry_helper()
    except Exception:
        return None, False
    try:
        return helper.resolve_registry()["path"], True
    except Exception:
        pass
    try:
        values = helper.read_locator_values()
    except Exception:
        return None, False
    return (values[0] if values else None), False


def registry_capability(op: str) -> dict[str, Any]:
    """Evaluate one Registry-dependent M-Build operation against the live state.

    Public on purpose: Registry sync and Registry-relevant Acceptance
    (`lesson_gate.registry_sync_gate`) must be blocked by the same AC-014X-7
    judgement that blocks checkpoint and rollback, so the caller feeds this
    reason into the publication record instead of inventing a second, divergent
    availability verdict. This function only observes; the matrix decides.
    """
    cap = _load_capability_matrix()
    git_ok = cap.git_available()
    locator_raw, locator_valid = _locator_facts() if git_ok else (None, False)
    state = cap.classify_locator_state(git_ok, locator_raw, locator_valid)
    outcome = cap.eval_capability("m-build", state)[cap.Op(op)]
    return {
        "op": cap.Op(op).value,
        "state": state.value,
        "available": outcome is cap.Outcome.CONTINUE,
        "reason": cap.reason_for(outcome),
    }


def _capability_gate(op: str) -> None:
    """Block Registry-dependent checkpoint ops under AC-014X-7.

    Checkpoint, acceptance and rollback are listed by AC-014X-7 among the operations
    that are blocked without Git, resume only after bootstrap with a missing locator,
    and require explicit repair with an invalid one.
    """
    decision = registry_capability(op)
    if not decision["available"]:
        raise CheckpointError(str(decision["reason"]))


def _contract() -> dict[str, Any]:
    try:
        value = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise CheckpointError("invalid rollback contract") from error
    if not isinstance(value, dict) or value.get("version") != "0.2.4":
        raise CheckpointError("invalid rollback contract")
    if set(value.get("state_fields", [])) != STATE_FIELDS:
        raise CheckpointError("rollback state fields do not match contract")
    return value


def _git(repo: Path, *arguments: str, check: bool = True) -> str:
    result = subprocess.run(
        ["git", *arguments], cwd=repo, capture_output=True, text=True,
    )
    if check and result.returncode:
        detail = (result.stderr or result.stdout).strip() or "git command failed"
        raise CheckpointError(detail)
    return result.stdout.strip()


def _repo(path: Path) -> Path:
    repo = path.resolve()
    if not repo.is_dir():
        raise CheckpointError("repository is not a directory")
    root = Path(_git(repo, "rev-parse", "--show-toplevel")).resolve()
    if root != repo:
        raise CheckpointError("repository must be the worktree root")
    return repo


def _clean(repo: Path) -> None:
    if _git(repo, "status", "--porcelain=v1", "--untracked-files=all"):
        raise CheckpointError("worktree must be clean")


def _state_path(path: Path, repo: Path, *, must_exist: bool) -> Path:
    if path.is_symlink():
        raise CheckpointError("checkpoint state cannot be a symlink")
    absolute = path.resolve(strict=False)
    if absolute == repo or repo in absolute.parents:
        raise CheckpointError("checkpoint state must be outside repository")
    if must_exist and not absolute.is_file():
        raise CheckpointError("checkpoint state is missing")
    if not must_exist and absolute.exists():
        raise CheckpointError("checkpoint state already exists")
    if not absolute.parent.is_dir():
        raise CheckpointError("checkpoint state parent is missing")
    return absolute


def _write_state(path: Path, state: dict[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.mtp-checkpoint-tmp")
    if temporary.exists() or temporary.is_symlink():
        raise CheckpointError("checkpoint temporary path already exists")
    try:
        temporary.write_text(
            json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _commit(repo: Path, value: str, field: str) -> str:
    if not isinstance(value, str) or not COMMIT_RE.fullmatch(value):
        raise CheckpointError(f"{field} must be a full commit id")
    resolved = _git(repo, "rev-parse", "--verify", f"{value}^{{commit}}")
    if resolved != value:
        raise CheckpointError(f"{field} is not the resolved commit")
    return value


def _revision(value: str) -> str:
    if not isinstance(value, str) or not REVISION_RE.fullmatch(value):
        raise CheckpointError("plan_revision must be a SHA-256 digest")
    return value


def _ancestor(repo: Path, ancestor: str, descendant: str) -> None:
    result = subprocess.run(
        ["git", "merge-base", "--is-ancestor", ancestor, descendant],
        cwd=repo, capture_output=True, text=True,
    )
    if result.returncode:
        raise CheckpointError("commit ancestry validation failed")


def _strings(value: Any, field: str) -> list[str]:
    if not isinstance(value, list) or not value or not all(isinstance(item, str) and item.strip() for item in value):
        raise CheckpointError(f"{field} must contain nonempty strings")
    return value


def _load_state(path: Path, repo: Path) -> dict[str, Any]:
    state_file = _state_path(path, repo, must_exist=True)
    try:
        value = json.loads(state_file.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise CheckpointError("invalid checkpoint state") from error
    if not isinstance(value, dict) or set(value) != STATE_FIELDS:
        raise CheckpointError("checkpoint state fields are invalid")
    if value["version"] != "0.2.4" or not isinstance(value["task_id"], str) or not value["task_id"].strip():
        raise CheckpointError("checkpoint identity is invalid")
    if value["status"] not in STATUSES or not isinstance(value["active_writer"], bool):
        raise CheckpointError("checkpoint status is invalid")
    _commit(repo, value["plan_commit"], "plan_commit")
    _commit(repo, value["base_commit"], "base_commit")
    for field in ("accepted_commit", "resulting_commit"):
        if value[field] is not None:
            _commit(repo, value[field], field)
    _revision(value["plan_revision"])
    if not isinstance(value["verification"], list) or not all(
            isinstance(item, str) and item.strip() for item in value["verification"]):
        raise CheckpointError("verification is invalid")
    if not isinstance(value["rollback_verification"], list) or not all(
            isinstance(item, str) and item.strip() for item in value["rollback_verification"]):
        raise CheckpointError("rollback_verification is invalid")
    if not isinstance(value["external_effects"], list) or not all(
            isinstance(item, str) and item.strip() for item in value["external_effects"]):
        raise CheckpointError("external_effects is invalid")
    if value["repo"] != str(repo):
        raise CheckpointError("checkpoint repository identity is stale")
    return value


def _identity(state: dict[str, Any], task_id: str, plan_commit: str, plan_revision: str) -> None:
    if state["task_id"] != task_id or state["plan_commit"] != plan_commit or state["plan_revision"] != plan_revision:
        raise CheckpointError("checkpoint plan identity is stale")


def _effects_clear(state: dict[str, Any]) -> None:
    if state["external_effects"]:
        raise CheckpointError("external effects are outside local Git rollback")


def create_checkpoint(
    repo_path: Path,
    state_path: Path,
    task_id: str,
    plan_commit: str,
    plan_revision: str,
    *,
    active_writer: bool = False,
    external_effects: list[str] | None = None,
) -> dict[str, Any]:
    _contract()
    _capability_gate("checkpoint")
    repo = _repo(repo_path)
    _clean(repo)
    if active_writer:
        raise CheckpointError("active writer prevents checkpoint")
    effects = external_effects or []
    if effects:
        raise CheckpointError("external effects are unsupported")
    state_file = _state_path(state_path, repo, must_exist=False)
    head = _git(repo, "rev-parse", "HEAD")
    plan = _commit(repo, plan_commit, "plan_commit")
    _ancestor(repo, plan, head)
    revision = _revision(plan_revision)
    if not isinstance(task_id, str) or not task_id.strip():
        raise CheckpointError("task_id is required")
    state = {
        "version": "0.2.4", "task_id": task_id, "plan_commit": plan,
        "plan_revision": revision, "base_commit": head, "accepted_commit": None,
        "resulting_commit": None, "status": "started", "verification": [],
        "rollback_verification": [], "active_writer": False, "external_effects": [],
        "repo": str(repo),
    }
    _write_state(state_file, state)
    return {"decision": "checkpoint-created", "state": state}


def accept_checkpoint(
    repo_path: Path,
    state_path: Path,
    task_id: str,
    plan_commit: str,
    plan_revision: str,
    verification: list[str],
    *,
    active_writer: bool = False,
) -> dict[str, Any]:
    _contract()
    _capability_gate("checkpoint")
    repo = _repo(repo_path)
    state = _load_state(state_path, repo)
    _identity(state, task_id, plan_commit, plan_revision)
    if state["status"] != "started":
        raise CheckpointError("checkpoint is not awaiting acceptance")
    if active_writer or state["active_writer"]:
        raise CheckpointError("active writer prevents acceptance")
    _effects_clear(state)
    _clean(repo)
    current = _git(repo, "rev-parse", "HEAD")
    _ancestor(repo, state["base_commit"], current)
    if current == state["base_commit"]:
        raise CheckpointError("acceptance requires a resulting commit")
    evidence = _strings(verification, "verification")
    state.update({
        "accepted_commit": current, "resulting_commit": current,
        "status": "accepted", "verification": evidence,
    })
    _write_state(_state_path(state_path, repo, must_exist=True), state)
    return {"decision": "checkpoint-accepted", "state": state}


def rollback_checkpoint(
    repo_path: Path,
    state_path: Path,
    task_id: str,
    plan_commit: str,
    plan_revision: str,
    verification: list[str],
    *,
    active_writer: bool = False,
) -> dict[str, Any]:
    _contract()
    _capability_gate("rollback")
    repo = _repo(repo_path)
    state = _load_state(state_path, repo)
    _identity(state, task_id, plan_commit, plan_revision)
    if state["status"] != "accepted" or state["accepted_commit"] is None:
        raise CheckpointError("checkpoint is not rollback-ready")
    if active_writer or state["active_writer"]:
        raise CheckpointError("active writer prevents rollback")
    _effects_clear(state)
    _clean(repo)
    current = _git(repo, "rev-parse", "HEAD")
    if current != state["accepted_commit"]:
        raise CheckpointError("current HEAD is not the accepted checkpoint")
    _ancestor(repo, state["base_commit"], state["accepted_commit"])
    evidence = _strings(verification, "rollback_verification")
    result = subprocess.run(
        ["git", "revert", "--no-edit", f"{state['base_commit']}..{state['accepted_commit']}"],
        cwd=repo, capture_output=True, text=True,
    )
    if result.returncode:
        subprocess.run(["git", "revert", "--abort"], cwd=repo, capture_output=True, text=True)
        raise CheckpointError((result.stderr or result.stdout).strip() or "git revert failed")
    _clean(repo)
    state.update({
        "resulting_commit": _git(repo, "rev-parse", "HEAD"),
        "rollback_verification": evidence, "status": "rolled-back",
    })
    _write_state(_state_path(state_path, repo, must_exist=True), state)
    return {"decision": "checkpoint-rolled-back", "state": state}


def main() -> int:
    parser = argparse.ArgumentParser(description="Record and revert accepted local Git Task checkpoints")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("create", "accept", "rollback"):
        item = subparsers.add_parser(command)
        item.add_argument("--repo", type=Path, required=True)
        item.add_argument("--state", type=Path, required=True)
        item.add_argument("--task-id", required=True)
        item.add_argument("--plan-commit", required=True)
        item.add_argument("--plan-revision", required=True)
        if command != "create":
            item.add_argument("--verification", action="append", required=True)
        item.add_argument("--active-writer", action="store_true")
    try:
        args = parser.parse_args()
        repo = args.repo.resolve()
        if args.command == "create":
            result = create_checkpoint(repo, args.state, args.task_id, args.plan_commit, args.plan_revision, active_writer=args.active_writer)
        elif args.command == "accept":
            result = accept_checkpoint(repo, args.state, args.task_id, args.plan_commit, args.plan_revision, args.verification, active_writer=args.active_writer)
        else:
            result = rollback_checkpoint(repo, args.state, args.task_id, args.plan_commit, args.plan_revision, args.verification, active_writer=args.active_writer)
    except (CheckpointError, OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        print(f"execution-checkpoint-error: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
