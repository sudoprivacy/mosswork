#!/usr/bin/env python3
"""Optional-Git capability matrix for the MTP 0.2.0 Bootstrap workflow.

Pure, dependency-free decision logic for AC-014X-7. Given the Git availability
and the Registry locator state, it returns the exact continue / bootstrap / repair
/ block outcome for every Registry-dependent operation across M-Define, M-Plan and
M-Build. The module never touches the filesystem, the network or any Registry; it
only decides. Callers (discover, checkpoint, ...) load this module and consult the
decision before performing a Registry-dependent operation.

State model (per AC-014X-7):
  - ABSENT_GIT:    Git binary missing -> all Registry-dependent ops BLOCK.
  - VALID:         Git present + one valid same-OS-user locator -> all available.
  - MISSING:       Git present, no locator -> resume only after bootstrap (BOOTSTRAP).
  - INVALID:       Git present, locator present but unusable -> explicit repair
                   required and remains non-accepting (REPAIR).

The six Registry-dependent operations are identical across the three skills, so the
outcome is uniform by state; the `skill` argument is retained so the matrix stays
explicit and future per-skill nuance is a local change rather than a new contract.
"""

from __future__ import annotations

import subprocess
from enum import Enum
from typing import Dict


class LocatorState(str, Enum):
    ABSENT_GIT = "absent-git"
    VALID = "valid"
    MISSING = "missing"
    INVALID = "invalid"


class Op(str, Enum):
    SHARED_LOOKUP = "shared-lookup"
    REGISTRY_SYNC = "registry-sync"
    CHECKPOINT = "checkpoint"
    ROLLBACK = "rollback"
    TAG = "tag"
    FORMAL_RELEASE = "formal-release"


class Outcome(str, Enum):
    CONTINUE = "continue"        # available; the operation may proceed
    BOOTSTRAP = "bootstrap"      # blocked until locator bootstrap completes
    REPAIR = "repair"            # explicit repair required, never auto-accepting
    BLOCK = "block"              # unavailable under the current state


SKILLS = ("m-define", "m-plan", "m-build")
OPS = tuple(Op)

# AC-014X-7: the outcome is governed only by the locator state; it is uniform
# across the three skills for these six Registry-dependent operations.
_OUTCOME_BY_STATE: Dict[LocatorState, Outcome] = {
    LocatorState.VALID: Outcome.CONTINUE,
    LocatorState.ABSENT_GIT: Outcome.BLOCK,
    LocatorState.MISSING: Outcome.BOOTSTRAP,
    LocatorState.INVALID: Outcome.REPAIR,
}


def git_available() -> bool:
    """Detect a usable Git binary without raising (AC-014X-1).

    A missing or broken Git installation must not crash the caller; it only
    downgrades Registry-dependent capabilities so the basic document/local path
    can continue. Detection is a single `git --version` probe with a bounded
    timeout and no filesystem scan.
    """
    try:
        result = subprocess.run(
            ["git", "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def classify_locator_state(
    git_available_flag: bool,
    locator_raw: str | None,
    locator_valid: bool,
) -> LocatorState:
    """Map raw facts to a LocatorState (no I/O beyond the git probe done by caller)."""
    if not git_available_flag:
        return LocatorState.ABSENT_GIT
    if not locator_raw or not str(locator_raw).strip():
        return LocatorState.MISSING
    return LocatorState.VALID if locator_valid else LocatorState.INVALID


def eval_capability(skill: str, state: LocatorState) -> Dict[Op, Outcome]:
    """Return the outcome for every Registry-dependent op under `state`.

    Raises ValueError on an unknown skill and TypeError on a non-LocatorState
    state so misconfiguration fails closed rather than silently continuing.
    """
    if skill not in SKILLS:
        raise ValueError(f"unknown skill: {skill!r}")
    if not isinstance(state, LocatorState):
        raise TypeError("state must be a LocatorState")
    outcome = _OUTCOME_BY_STATE[state]
    return {op: outcome for op in OPS}


def reason_for(outcome: Outcome) -> str:
    """Stable machine reason for an unavailable outcome (used by callers' errors)."""
    return {
        Outcome.CONTINUE: "available",
        Outcome.BLOCK: "git-unavailable",
        Outcome.BOOTSTRAP: "registry-locator-missing",
        Outcome.REPAIR: "registry-locator-invalid",
    }[outcome]
