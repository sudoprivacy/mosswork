#!/usr/bin/env python3
"""Pure fail-closed decisions for the MTP 0.2.0 execute Skill."""

from __future__ import annotations

import importlib.util
import json
import re
import subprocess
from pathlib import Path, PurePosixPath
from typing import Any, Callable


RULES_PATH = Path(__file__).resolve().parents[1] / "references/execution-rules.json"
PLAN_VALIDATOR_PATH = Path(__file__).resolve().parents[2] / "m-plan/scripts/validate_plan.py"
CURRENT_MANIFEST_FIELDS = {"mtp_version", "profile", "project_id", "registry_id"}
PROJECT_ID_RE = re.compile(r"prj-[a-z0-9][a-z0-9-]{2,63}")
REGISTRY_ID = "mtp-local-registry-v1"


def _load_plan_validator() -> Any:
    spec = importlib.util.spec_from_file_location("mtp01_plan_validator", PLAN_VALIDATOR_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("MTP plan validator unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


PLAN = _load_plan_validator()
PUBLIC_SKILL_IDS = {
    "m-add",
    "m-define",
    "m-plan",
    "m-build",
    "m-give",
    "m-take",
    "m-new",
}
TASK_FIELDS = {"task_id", *PLAN.TASK_FIELDS}
RISK_REVIEW = PLAN.RISK_REVIEW
PRIMARY_ONLY_PATHS = PLAN.STATE_ONLY_PATHS
SIMPLE_REQUIRED = {"clear_bounded_scope", "local_scope", "reversible", "deterministic_verification"}
SIMPLE_FORBIDDEN = {
    "material_ambiguity", "shared_contract", "business_data_migration",
    "permission_or_security_boundary", "remote_irreversible_effect",
    "broad_deletion", "real_concurrency", "unverifiable_behavior",
}


def load_rules() -> dict[str, Any]:
    return json.loads(RULES_PATH.read_text(encoding="utf-8"))


def version_preflight(manifest: Any, skill_version: str = "0.2.4") -> dict[str, Any]:
    if not isinstance(manifest, dict):
        return {"route": "m-new", "write_allowed": False}
    if (
        set(manifest) != CURRENT_MANIFEST_FIELDS
        or manifest.get("profile") != "lightweight"
        or manifest.get("mtp_version") != skill_version
        or skill_version != "0.2.4"
        or not isinstance(manifest.get("project_id"), str)
        or PROJECT_ID_RE.fullmatch(manifest["project_id"]) is None
        or manifest.get("registry_id") != REGISTRY_ID
    ):
        return {"route": "m-new", "write_allowed": False}
    return {"route": "m-build", "write_allowed": True}


def is_simple_task(task: Any) -> bool:
    return isinstance(task, dict) and (
        task.get("execution") == "primary"
        and task.get("review") == "self"
        and task.get("risk") == "low"
    )


def simple_risk_allowed(signals: Any) -> bool:
    expected = SIMPLE_REQUIRED | SIMPLE_FORBIDDEN
    return isinstance(signals, dict) and set(signals) == expected and all(
        signals[key] is True for key in SIMPLE_REQUIRED
    ) and all(signals[key] is False for key in SIMPLE_FORBIDDEN)


def choose_direct_execution(
    signals: Any,
    *,
    permission_uncertainty: bool = False,
    exact_action_authorized: bool = False,
) -> dict[str, Any]:
    expected = SIMPLE_REQUIRED | SIMPLE_FORBIDDEN
    if not isinstance(signals, dict) or set(signals) != expected \
            or any(not isinstance(value, bool) for value in signals.values()) \
            or not isinstance(permission_uncertainty, bool) \
            or not isinstance(exact_action_authorized, bool):
        return {"decision": "ESCALATE", "authorized": False, "reasons": ["invalid_signals"]}

    reasons = sorted(key for key in SIMPLE_FORBIDDEN if signals[key])
    reasons.extend(sorted(key for key in SIMPLE_REQUIRED if not signals[key]))
    if permission_uncertainty and not exact_action_authorized:
        reasons.append("permission_uncertainty")
    if reasons:
        if "material_ambiguity" in reasons:
            route = "m-define"
        elif reasons == ["permission_uncertainty"]:
            route = "request-exact-authorization"
        else:
            route = "planned-path"
        return {"decision": "ESCALATE", "authorized": False, "reasons": reasons, "route": route}
    return {
        "decision": "primary-direct",
        "authorized": True,
        "plan_required": False,
        "child_calls": 0,
        "reviewer_calls": 0,
        "review_artifact": False,
        "full_gate": False,
        "verification": "targeted",
        "stop_on_pass": True,
    }


def direct_completion(targeted_verification_passed: Any) -> str:
    return "ACCEPTED-STOP" if targeted_verification_passed is True else "BLOCKED-STOP"


def validate_task_contract(task: Any) -> list[str]:
    if not isinstance(task, dict) or set(task) != TASK_FIELDS:
        return ["task contract fields"]
    errors: list[str] = []
    for field in ("task_id", "goal", "artifact", "baseline_verification", "verification", "completion_signal", "rollback"):
        if not isinstance(task.get(field), str) or not task[field].strip():
            errors.append(f"task contract {field}")
    for field in ("dependencies", "exclusive_resources", "acceptance_criteria", "test_cases"):
        value = task.get(field)
        if not isinstance(value, list) or not all(isinstance(item, str) and item for item in value):
            errors.append(f"task contract {field}")
    allowed_paths = task.get("allowed_paths")
    if (
        not isinstance(allowed_paths, list)
        or not allowed_paths
        or not all(isinstance(path, str) and path.strip() for path in allowed_paths)
    ):
        errors.append("task contract allowed_paths")
    if not task["acceptance_criteria"] or not task["test_cases"]:
        errors.append("task contract evidence missing")
    risk = task.get("risk")
    expected_review = RISK_REVIEW.get(risk) if isinstance(risk, str) else None
    if expected_review is None or task.get("review") != expected_review:
        errors.append("task review does not match risk")
    if task.get("execution") not in {"primary", "delegate", "parallel"}:
        errors.append("task execution invalid")
    if task.get("risk") == "low" and task.get("execution") != "primary":
        errors.append("low risk work must use primary execution")
    if isinstance(allowed_paths, list) and all(isinstance(path, str) for path in allowed_paths) and any(
        _scope_touches_primary_state(path) for path in allowed_paths
    ):
        errors.append("task scope includes primary-only state")
    return errors


def _full_sha(value: Any) -> bool:
    return isinstance(value, str) and PLAN.COMMIT_RE.fullmatch(value) is not None


def read_git(arguments: list[str]) -> str:
    result = subprocess.run(
        ["git", *arguments],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or "Git read failed")
    return result.stdout


def validate_approved_plan(task: Any, context: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    current_commit = context.get("current_plan_commit")
    current_revision = context.get("current_plan_revision")
    if not _full_sha(current_commit):
        return ["current plan_commit invalid"]

    git_reader = context.get("git_reader", read_git)
    if not callable(git_reader):
        return ["Git reader unavailable"]
    try:
        git_reader(["cat-file", "-e", f"{current_commit}^{{commit}}"])
    except (OSError, RuntimeError, TypeError, ValueError, subprocess.SubprocessError):
        return ["current plan_commit is not a readable Git commit"]
    try:
        plan_text = git_reader(["show", f"{current_commit}:ai/plan.md"])
    except (OSError, RuntimeError, TypeError, ValueError, subprocess.SubprocessError):
        return ["current plan_commit has no ai/plan.md"]
    try:
        approved_plan = PLAN.load_marked_plan(plan_text)
    except (TypeError, ValueError, json.JSONDecodeError):
        return ["committed plan invalid"]
    if PLAN.validate_plan(approved_plan):
        return ["committed plan invalid"]

    revision = PLAN.plan_revision(approved_plan)
    if current_revision != revision:
        errors.append("current plan_revision mismatch")
    if context.get("current_task_id") != task.get("task_id"):
        errors.append("current task_id mismatch")

    approved_tasks = [
        item for item in approved_plan["task_contracts"]
        if item["task_id"] == task.get("task_id")
    ]
    if not approved_tasks:
        errors.append("task_id is not approved")
    elif approved_tasks[0] != task:
        errors.append("task contract is not approved")
    return errors


def validate_common_preflight(task: Any, context: Any) -> list[str]:
    if not isinstance(context, dict):
        return ["complex context missing"]
    errors = validate_task_contract(task)
    errors.extend(validate_approved_plan(task, context))
    _required_bool(context, "residual_agents_cleared", errors)
    _required_bool(context, "dependencies_accepted", errors)
    _required_bool(context, "baseline_passed", errors)
    if not _full_sha(context.get("expected_base_sha")):
        errors.append("base SHA invalid")
    if context.get("baseline_base_sha") != context.get("expected_base_sha"):
        errors.append("baseline not run at BASE")
    if context.get("baseline_command") != task.get("baseline_verification"):
        errors.append("baseline command drift")
    errors.extend(validate_writer_scope({
        "allowed_paths": task.get("allowed_paths"),
        "actual_paths": [],
        "exclusive_resources": task.get("exclusive_resources"),
    }, context.get("active_tasks")))

    capabilities = context.get("capabilities")
    if task.get("review") != "self" and (
        not isinstance(capabilities, dict) or capabilities.get("reviewer") is not True
    ):
        errors.append("reviewer capability unavailable")
    return sorted(set(errors))


def choose_execution(
    task: Any,
    complex_context: dict[str, Any] | None = None,
    rules_loader: Callable[[], dict[str, Any]] = load_rules,
) -> dict[str, Any]:
    if is_simple_task(task):
        errors = validate_common_preflight(task, complex_context)
        if not isinstance(complex_context, dict) or not simple_risk_allowed(complex_context.get("risk_signals")):
            errors.append("simple task risk signals")
        return {
            "decision": "BLOCKED" if errors else "primary-self",
            "authorized": not errors,
            "child_calls": 0,
            "loaded_complex_rules": False,
            **({"errors": errors} if errors else {}),
        }
    rules = rules_loader()
    execution = task.get("execution") if isinstance(task, dict) else None
    errors = validate_common_preflight(task, complex_context)
    if errors:
        return {
            "decision": "BLOCKED",
            "authorized": False,
            "child_calls": 0,
            "loaded_complex_rules": True,
            "errors": errors,
            "required_review": task.get("review") if isinstance(task, dict) else None,
        }
    if execution == "primary":
        return {
            "decision": "primary-sequential",
            "authorized": True,
            "child_calls": 0,
            "loaded_complex_rules": True,
            "errors": [],
            "required_review": task.get("review") if isinstance(task, dict) else None,
        }

    capabilities = complex_context.get("capabilities") if isinstance(complex_context, dict) else None
    capability = capability_decision(
        capabilities,
        mandatory_review=task.get("review") != "self" if isinstance(task, dict) else True,
        user_approval=complex_context.get("explicit_user_approval") is True
        if isinstance(complex_context, dict) else False,
    )
    if capability != "isolated-dispatch":
        fallback_errors = validate_primary_fallback_context(complex_context)
        if fallback_errors:
            return {
                "decision": "BLOCKED",
                "authorized": False,
                "child_calls": 0,
                "loaded_complex_rules": True,
                "errors": fallback_errors,
                "required_review": task.get("review") if isinstance(task, dict) else None,
            }
        return {
            "decision": capability,
            "authorized": capability == "primary-sequential",
            "child_calls": 0,
            "loaded_complex_rules": True,
            "errors": [] if capability == "primary-sequential" else ["implementation capability unavailable"],
            "required_review": task.get("review") if isinstance(task, dict) else None,
        }

    errors = validate_preflight(task, complex_context, rules)
    return {
        "decision": "BLOCKED" if errors else "isolated-dispatch",
        "authorized": not errors,
        "child_calls": 0 if errors else 1,
        "loaded_complex_rules": True,
        "errors": errors,
        "required_review": task.get("review") if isinstance(task, dict) else None,
    }


def _required_bool(context: dict[str, Any], key: str, errors: list[str]) -> bool:
    value = context.get(key)
    if value is not True:
        errors.append(key)
        return False
    return True


def validate_preflight(
    task: Any,
    context: Any,
    rules: dict[str, Any] | None = None,
) -> list[str]:
    rules = rules or load_rules()
    errors: list[str] = []
    if (
        not isinstance(task, dict)
        or not isinstance(task.get("execution"), str)
        or task.get("execution") not in {"primary", "delegate", "parallel"}
    ):
        return ["complex task contract"]
    if not isinstance(context, dict):
        return ["complex context missing"]

    errors.extend(validate_common_preflight(task, context))
    if task.get("execution") == "primary":
        return sorted(set(errors))
    if task.get("execution") == "parallel" and context.get("parallel_benefit") is not True:
        errors.append("parallel benefit missing")

    capability = capability_decision(
        context.get("capabilities"),
        mandatory_review=task.get("review") != "self",
        user_approval=False,
    )
    if capability != "isolated-dispatch":
        errors.append("implementation dispatch capability unavailable")
        return sorted(set(errors))

    worktree = context.get("worktree")
    if not isinstance(worktree, dict):
        errors.append("worktree missing")
    else:
        reused_fix_worktree = (
            context.get("same_task_fix") is True
            and context.get("same_worker") is True
            and context.get("prior_worker_terminal") is True
        )
        if worktree.get("exists_before") is not False and not reused_fix_worktree:
            errors.append("worktree already exists")
        if worktree.get("isolated") is not True:
            errors.append("write isolation missing")
        if worktree.get("root") != worktree.get("expected_root"):
            errors.append("wrong worktree root")
        if worktree.get("branch") != worktree.get("expected_branch"):
            errors.append("wrong worktree branch")

    if context.get("descendant_requested") is not False:
        errors.append("descendant request forbidden")
    packet = context.get("packet")
    errors.extend(validate_dispatch(
        packet,
        context.get("used_dispatch_ids", set()),
        context.get("active_child_count"),
        rules,
    ))
    if isinstance(packet, dict):
        expected_values = {
            "task_id": task.get("task_id"),
            "task_contract": task,
            "plan_commit": context.get("current_plan_commit"),
            "plan_revision": context.get("current_plan_revision"),
            "base_sha": context.get("expected_base_sha"),
            "dependency_shas": context.get("expected_dependency_shas"),
            "allowed_paths": task.get("allowed_paths"),
            "exclusive_resources": task.get("exclusive_resources"),
            "baseline_verification": task.get("baseline_verification"),
            "verification": task.get("verification"),
            "workspace_root": context.get("expected_workspace_root"),
            "worktree": worktree.get("root") if isinstance(worktree, dict) else None,
            "branch": worktree.get("branch") if isinstance(worktree, dict) else None,
        }
        for field, expected in expected_values.items():
            if expected is None or packet.get(field) != expected:
                errors.append(f"stale packet {field}")
        if packet.get("child_prohibitions") != rules["child_prohibitions"]:
            errors.append("child prohibitions drift")
        expected_report_schema = {
            "fields": rules["worker_report_fields"],
            "outcomes": list(rules["worker_outcomes"]),
            "max_bytes": rules["budgets"]["max_worker_report_bytes"],
        }
        if packet.get("report_schema") != expected_report_schema:
            errors.append("report schema drift")

    errors.extend(validate_worker_assignment(context))
    retries = context.get("prior_same_blocker_redispatches")
    if isinstance(retries, bool) or retries not in {0, 1}:
        errors.append("same blocker redispatch limit")
    return sorted(set(errors))


def validate_dispatch(
    packet: Any,
    used_dispatch_ids: Any,
    active_child_count: Any,
    rules: dict[str, Any] | None = None,
) -> list[str]:
    rules = rules or load_rules()
    errors: list[str] = []
    expected = set(rules["packet_fields"])
    if not isinstance(packet, dict) or set(packet) != expected:
        return ["packet fields"]
    if any(value is None or value == "" for value in packet.values()):
        errors.append("packet empty value")
    if not isinstance(used_dispatch_ids, set):
        errors.append("dispatch history missing")
        used: set[str] = set()
    else:
        used = used_dispatch_ids
    if packet.get("dispatch_id") in used:
        errors.append("dispatch id reused")
    if not isinstance(active_child_count, int) or isinstance(active_child_count, bool):
        errors.append("active child count missing")
    elif active_child_count >= rules["budgets"]["max_active_children"]:
        errors.append("active child limit")
    try:
        packet_bytes = len(json.dumps(packet, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    except (TypeError, ValueError):
        errors.append("packet not serializable")
    else:
        if packet_bytes > rules["budgets"]["max_packet_bytes"]:
            errors.append("packet too large")
    return errors


def _scope_path(value: str) -> PurePosixPath:
    for suffix in ("/**", "/*"):
        if value.endswith(suffix):
            value = value[: -len(suffix)]
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("unsafe scope path")
    return path


def _path_overlaps(left: str, right: str) -> bool:
    try:
        left_path = _scope_path(left)
        right_path = _scope_path(right)
        return left_path == right_path or left_path in right_path.parents or right_path in left_path.parents
    except (AttributeError, TypeError, ValueError):
        return True


def _path_within(actual: str, allowed: str) -> bool:
    try:
        actual_path = _scope_path(actual)
        allowed_path = _scope_path(allowed)
        if allowed.endswith(("/**", "/*")):
            return actual_path == allowed_path or allowed_path in actual_path.parents
        return actual_path == allowed_path
    except (TypeError, ValueError):
        return False


def _scope_touches_primary_state(scope: str) -> bool:
    try:
        candidate = _scope_path(scope)
        for state_path in PRIMARY_ONLY_PATHS:
            state = _scope_path(state_path)
            if _path_within(state_path, scope) or state in candidate.parents:
                return True
        return False
    except (AttributeError, TypeError, ValueError):
        return True


def _valid_scope_list(value: Any, *, nonempty: bool) -> bool:
    return (
        isinstance(value, list)
        and (bool(value) if nonempty else True)
        and all(isinstance(path, str) and bool(path.strip()) for path in value)
    )


def _scope_record_errors(record: Any, label: str) -> list[str]:
    if not isinstance(record, dict):
        return [f"{label} scope record invalid"]
    errors: list[str] = []
    for field, nonempty in (
        ("allowed_paths", True),
        ("actual_paths", False),
        ("exclusive_resources", False),
    ):
        values = record.get(field)
        if not _valid_scope_list(values, nonempty=nonempty):
            errors.append(f"{label} scope {field} invalid")
        elif field in {"allowed_paths", "actual_paths"} and any(
            _scope_touches_primary_state(path) for path in values
        ):
            errors.append(
                "task scope includes primary-only state"
                if label == "candidate"
                else f"{label} scope includes primary-only state"
            )
    return errors


def validate_writer_scope(candidate: Any, active_tasks: Any) -> list[str]:
    if not isinstance(candidate, dict) or not isinstance(active_tasks, list):
        return ["scope context missing"]
    errors: list[str] = []
    errors.extend(_scope_record_errors(candidate, "candidate"))
    valid_active: list[dict[str, Any]] = []
    for active in active_tasks:
        active_errors = _scope_record_errors(active, "active")
        errors.extend(active_errors)
        if not active_errors:
            valid_active.append(active)
    if errors:
        return sorted(set(errors))

    candidate_paths = [
        *candidate["allowed_paths"],
        *candidate["actual_paths"],
    ]
    if any(_scope_touches_primary_state(path) for path in candidate_paths):
        errors.append("task scope includes primary-only state")
    for actual in candidate["actual_paths"]:
        if not any(_path_within(actual, allowed) for allowed in candidate["allowed_paths"]):
            errors.append("actual path outside declared scope")
    candidate_resources = set(candidate["exclusive_resources"])
    for active in valid_active:
        active_paths = [*active["allowed_paths"], *active["actual_paths"]]
        if any(_path_overlaps(left, right) for left in candidate_paths for right in active_paths):
            errors.append("path overlap")
        if candidate_resources.intersection(active["exclusive_resources"]):
            errors.append("resource overlap")
    return sorted(set(errors))


def validate_parallel_scope(candidate: Any, active_tasks: Any) -> list[str]:
    return validate_writer_scope(candidate, active_tasks)


def validate_worker_assignment(context: Any) -> list[str]:
    if not isinstance(context, dict):
        return ["worker context missing"]
    errors: list[str] = []
    if context.get("descendant_requested") is not False:
        errors.append("descendant request forbidden")
    new_task = context.get("new_task") is True
    same_task_fix = context.get("same_task_fix") is True
    if new_task == same_task_fix:
        errors.append("worker assignment kind conflict")
    elif new_task:
        if context.get("worker_fresh") is not True:
            errors.append("new task requires fresh worker")
    elif same_task_fix:
        if context.get("prior_worker_terminal") is not True:
            errors.append("prior worker still active")
        if context.get("same_worker") is not True and context.get("worker_fresh") is not True:
            errors.append("replacement worker must be fresh")
    return errors


def capability_decision(
    capabilities: Any,
    *,
    mandatory_review: bool = False,
    user_approval: bool = False,
) -> str:
    values = capabilities if isinstance(capabilities, dict) else {}
    available = lambda key: values.get(key) is True
    if mandatory_review and not available("reviewer"):
        return "BLOCKED"
    if not available("child"):
        return "primary-sequential"
    if not available("write_isolation") or not available("interrupt"):
        return "primary-sequential" if user_approval else "BLOCKED"
    return "isolated-dispatch"


def validate_primary_fallback_context(context: Any) -> list[str]:
    if not isinstance(context, dict):
        return ["primary fallback context missing"]
    artifacts = {
        "packet": "child packet",
        "worktree": "worktree",
        "branch": "branch",
        "worker_result": "worker result",
        "result": "worker result",
    }
    return [
        f"primary fallback retains {label}"
        for key, label in artifacts.items()
        if key in context
    ]


def transition(current: str, event: str, rules: dict[str, Any] | None = None) -> str | None:
    rules = rules or load_rules()
    if current in rules["terminal_task_states"]:
        return None
    for item in rules["transitions"]:
        if item["on"] == event and item["from"] in {current, "AnyNonTerminal"}:
            return item["to"]
    return None


def review_stage(
    review: str,
    artifact_head: str,
    approvals: Any,
    *,
    artifact_changed: bool = False,
    reviewer_available: bool = True,
) -> str:
    valid = {} if artifact_changed or not isinstance(approvals, dict) else {
        key: value for key, value in approvals.items() if value == artifact_head
    }
    if review == "self":
        return "approved" if "self" in valid else "self-review"
    if not reviewer_available:
        return "BLOCKED"
    if review == "combined":
        return "approved" if "combined" in valid else "combined-review"
    if review == "two-stage":
        if "spec" not in valid:
            return "spec-review"
        return "approved" if "quality" in valid else "quality-review"
    if review == "independent":
        return "approved" if "independent" in valid else "independent-review"
    return "BLOCKED"


def review_finding_route(finding: Any, rules: dict[str, Any] | None = None) -> str:
    rules = rules or load_rules()
    if not isinstance(finding, dict):
        return "P2-backlog"
    policy = rules["proportional_work"]
    if finding.get("omitted_real_threat") is True:
        return "REPLAN"
    if finding.get("category") in policy["nonblocking_finding_categories"]:
        return policy["unsupported_finding"]
    threat = finding.get("threat")
    if threat is not None and threat not in policy["threat_model"]:
        return policy["unsupported_finding"]
    if finding.get("severity") not in {"P0", "P1"}:
        return policy["unsupported_finding"]
    if any(not isinstance(finding.get(field), str) or not finding[field].strip()
           for field in policy["blocking_finding_requires"]):
        return policy["unsupported_finding"]
    return "BLOCKING"


def combined_review_action(
    full_reviews: int,
    targeted_rechecks: int,
    change: str,
    rules: dict[str, Any] | None = None,
) -> str:
    rules = rules or load_rules()
    policy = rules["proportional_work"]["medium_review"]
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0
           for value in (full_reviews, targeted_rechecks)):
        return "BLOCKED"
    if change in policy["restart_full_on"]:
        return "full-review"
    if full_reviews < policy["full_reviews"]:
        return "full-review"
    if change == "finding_fix" and full_reviews == policy["full_reviews"] \
            and targeted_rechecks < policy["targeted_rechecks"]:
        return "targeted-recheck"
    return "STOP"


def validate_result(
    result: Any,
    *,
    expected_head: str,
    expected_dispatch_id: str,
    actual_changed_paths: Any,
    task: Any,
    active_tasks: Any,
    base_is_ancestor: bool,
    worktree_clean: bool,
    cancelled: bool,
    late: bool,
    rules: dict[str, Any] | None = None,
) -> list[str]:
    rules = rules or load_rules()
    errors: list[str] = []
    if not isinstance(result, dict):
        return ["result missing"]
    if set(result) != set(rules["worker_report_fields"]):
        return ["worker report fields"]
    if result.get("outcome") not in rules["worker_outcomes"]:
        errors.append("unknown worker outcome")
    if result.get("head_sha") != expected_head:
        errors.append("stale result HEAD")
    if result.get("dispatch_id") != expected_dispatch_id:
        errors.append("stale dispatch result")
    if base_is_ancestor is not True:
        errors.append("base is not ancestor")
    if worktree_clean is not True:
        errors.append("artifact worktree not clean")
    if cancelled or late:
        errors.append("invalidated result")
    if not isinstance(result.get("changed_paths"), list) or not all(
        isinstance(path, str) and path for path in result.get("changed_paths", [])
    ):
        errors.append("changed paths invalid")
    if result.get("changed_paths") != actual_changed_paths:
        errors.append("reported paths differ from actual diff")
    if isinstance(task, dict):
        errors.extend(validate_parallel_scope({
            "allowed_paths": task.get("allowed_paths", []),
            "actual_paths": actual_changed_paths if isinstance(actual_changed_paths, list) else [],
            "exclusive_resources": task.get("exclusive_resources", []),
        }, active_tasks))
    else:
        errors.append("result task contract missing")
    if not isinstance(result.get("verification"), str) or not result.get("verification"):
        errors.append("verification missing")
    if not isinstance(result.get("concerns"), str):
        errors.append("concerns invalid")
    try:
        size = len(json.dumps(result, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    except (TypeError, ValueError):
        errors.append("worker report not serializable")
    else:
        if size > rules["budgets"]["max_worker_report_bytes"]:
            errors.append("worker report too large")
    return errors


def integration_review_preserved(kind: str, artifact_head: str, integrated_head: str) -> bool:
    return kind == "fast-forward" and artifact_head == integrated_head


def acceptance_allowed(
    checks: Any,
    rules: dict[str, Any] | None = None,
    *,
    planned: bool = True,
    task: Any = None,
    evidence: Any = None,
    identity: Any = None,
) -> bool:
    rules = rules or load_rules()
    gates_pass = isinstance(checks, dict) and set(checks) == set(rules["acceptance"]) and all(
        checks[item] is True for item in rules["acceptance"]
    )
    if not gates_pass or not isinstance(planned, bool):
        return False
    return not planned or not validate_acceptance_evidence(task, evidence, identity)


EVIDENCE_FIELDS = {
    "task_id", "plan_commit", "plan_revision", "artifact_head",
    "tc_id", "check", "status", "result",
}


def validate_acceptance_evidence(task: Any, evidence: Any, identity: Any) -> list[str]:
    """Fail closed unless every planned TC has fresh passing artifact evidence."""
    _, coverage, errors = PLAN.evidence_ids(task)
    if errors:
        return [f"task evidence: {error}" for error in errors]
    if not isinstance(identity, dict) or set(identity) != {
        "task_id", "plan_commit", "plan_revision", "artifact_head",
    }:
        return ["evidence identity invalid"]
    if not _full_sha(identity["plan_commit"]) or not _full_sha(identity["artifact_head"]):
        return ["evidence commit identity invalid"]
    if not isinstance(identity["plan_revision"], str) or len(identity["plan_revision"]) != 64 \
            or not all(char in "0123456789abcdef" for char in identity["plan_revision"]):
        return ["evidence plan revision invalid"]
    if not isinstance(evidence, list) or not evidence:
        return ["evidence missing"]
    observed: set[str] = set()
    for item in evidence:
        if not isinstance(item, dict) or set(item) != EVIDENCE_FIELDS:
            errors.append("evidence fields invalid")
            continue
        if any(item[field] != identity[field] for field in identity):
            errors.append("evidence identity mismatch")
        tc_id = item.get("tc_id")
        if tc_id not in coverage:
            errors.append("evidence unknown test case")
        elif tc_id in observed:
            errors.append("evidence duplicate test case")
        else:
            observed.add(tc_id)
        if item.get("status") != "passed":
            errors.append("evidence status is not passed")
        if not isinstance(item.get("check"), str) or not item["check"].strip():
            errors.append("evidence check missing")
        if not isinstance(item.get("result"), str) or not item["result"].strip():
            errors.append("evidence result missing")
    if observed != set(coverage):
        errors.append("evidence does not cover every test case")
    return sorted(set(errors))


def acceptance_with_evidence(checks: Any, task: Any, evidence: Any, identity: Any, rules: dict[str, Any] | None = None) -> bool:
    return acceptance_allowed(checks, rules, task=task, evidence=evidence, identity=identity)


def cancellation_state(hard_ui_cancel: bool, rules: dict[str, Any] | None = None) -> dict[str, Any]:
    rules = rules or load_rules()
    return {
        "task_state": rules["cancellation"]["task_state"],
        "dispatch_state": rules["cancellation"]["dispatch_state"],
        "cascade_guaranteed": False,
        "must_reconcile_on_resume": hard_ui_cancel,
    }


def resume_allowed(*, residual_writers_terminal: bool, user_resume: bool, new_dispatch_id: bool) -> bool:
    return residual_writers_terminal is True and user_resume is True and new_dispatch_id is True


def validate_report(kind: str, report: Any, failure_excerpt: Any = "", rules: dict[str, Any] | None = None) -> list[str]:
    rules = rules or load_rules()
    errors: list[str] = []
    if not isinstance(report, str) or not isinstance(failure_excerpt, str):
        return ["report must be text"]
    key = "max_worker_report_bytes" if kind == "worker" else "max_reviewer_report_bytes"
    if kind not in {"worker", "reviewer"}:
        return ["unknown report kind"]
    if len(report.encode("utf-8")) > rules["budgets"][key]:
        errors.append("report too large")
    if len(failure_excerpt.encode("utf-8")) > rules["budgets"]["max_failure_excerpt_bytes"]:
        errors.append("failure excerpt too large")
    return errors


def external_skill_request(requested: Any, task: Any, rules: dict[str, Any] | None = None) -> list[str]:
    rules = rules or load_rules()
    if not isinstance(requested, dict) or not isinstance(task, dict):
        return ["external request missing"]
    errors: list[str] = []
    if requested.get("technique") not in rules["external_skill_precedence"]["allowed"]:
        errors.append("external technique unavailable")
    if set(requested.get("allowed_paths", [])) - set(task.get("allowed_paths", [])):
        errors.append("external scope widened")
    if requested.get("add_agents", 0) != 0:
        errors.append("external agents forbidden")
    if requested.get("add_reviews", 0) != 0:
        errors.append("external reviews forbidden")
    if requested.get("add_commits", 0) != 0:
        errors.append("external commits forbidden")
    if requested.get("override_gate") is not False:
        errors.append("external gate override forbidden")
    return errors


# --- MTP 0.2.0 execution-continuity contract (AC-CON-1..4) -----------------------
# A finished plan approval is a one-shot authorization to run the whole plan through
# without stopping for the user, EXCEPT for the closed list below. Review is
# agent-to-agent; deletions are staged then cleaned; only these conditions interact
# with the user.

CONTINUITY_STOP_REASONS = (
    "directional-new-decision",       # a new decision that changes direction/scope
    "genuine-disagreement",           # an unresolved real disagreement
    "release-boundary",               # a release / distribution boundary
    "plan-invalidated",               # the approved plan no longer holds
    "unrecoverable-blocked-failure",  # needs user privilege / data / credentials
)
# Delete-staging: deletions are staged to this gitignored dir, then cleaned once at
# the end of the run; a mid-run deletion never asks the user.
DELETE_STAGING_DIR = ".pending-delete"
# The independent reviewer is another session / another Agent channel (e.g. OC); if
# none is available the continuity contract is Blocked rather than downgraded to
# self-review.
INDEPENDENT_REVIEWER_KINDS = ("other-session", "other-agent-channel")


def continuity_requires_user(reason: Any) -> bool:
    """Whether a stop reason must interact with the user (closed list)."""
    return isinstance(reason, str) and reason in CONTINUITY_STOP_REASONS


def continuity_allows_auto_continue(reason: Any) -> bool:
    """Fail-open toward continuation: only an explicit closed-list reason stops.

    The contract is "an approved plan runs continuously", so the safe default is to
    *continue*: an unknown reason is NOT a stop (continuity by default under an
    approved plan). Only a reason on the closed list interacts with the user.
    """
    return not continuity_requires_user(reason)


def continuity_review_ok(review: Any, reviewer_kind: Any) -> bool:
    """Independent review must be agent-to-agent; missing reviewer is Blocked."""
    if review in ("self", None, ""):
        return True  # self / low-risk needs no independent reviewer
    return reviewer_kind in INDEPENDENT_REVIEWER_KINDS


def stage_deletion(target: str, staging_dir: str = DELETE_STAGING_DIR) -> str:
    """Return the staged path for a deletion (never delete mid-run)."""
    name = target.rstrip("/").split("/")[-1] or "item"
    return f"{staging_dir}/{name}"
