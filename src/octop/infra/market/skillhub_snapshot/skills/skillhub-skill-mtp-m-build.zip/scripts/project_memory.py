#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
CONTRACT_PATH = ROOT / "references/project-memory.json"
MTP_BEGIN = "<!-- MTP:BEGIN version=0.2.4 -->"
MTP_END = "<!-- MTP:END -->"
HEADING_RE = re.compile(r"^## (.+?)\s*$", re.MULTILINE)
LESSON_REGIONS = {
    "candidates": (
        "<!-- MTP:LESSONS:BEGIN kind=candidates -->",
        "<!-- MTP:LESSONS:END kind=candidates -->",
    ),
    "active": (
        "<!-- MTP:LESSONS:BEGIN kind=active -->",
        "<!-- MTP:LESSONS:END kind=active -->",
    ),
}


class MemoryError(RuntimeError):
    pass


def load_contract() -> dict[str, Any]:
    value = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or value.get("version") != "0.2.4":
        raise MemoryError("invalid project-memory contract")
    return value


def _json_file(path: Path) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise MemoryError("input must be a regular file")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise MemoryError("invalid JSON input") from error
    if not isinstance(value, dict):
        raise MemoryError("JSON input must be an object")
    return value


def _digest(kind: str, source: bytes, payload: dict[str, Any]) -> str:
    identity = {
        "contract_sha256": hashlib.sha256(CONTRACT_PATH.read_bytes()).hexdigest(),
        "kind": kind,
        "payload": payload,
        "source_sha256": hashlib.sha256(source).hexdigest(),
    }
    encoded = json.dumps(identity, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _safe_file(path: Path, *, required: bool) -> bytes:
    if path.is_symlink():
        raise MemoryError(f"managed path cannot be a symlink: {path.name}")
    if not path.exists():
        if required:
            raise MemoryError(f"managed path is missing: {path.name}")
        return b""
    if not path.is_file():
        raise MemoryError(f"managed path is not a file: {path.name}")
    return path.read_bytes()


def _atomic_write(path: Path, content: bytes, mode: int) -> None:
    temporary = path.with_name(f".{path.name}.mtp-memory-tmp")
    if temporary.exists() or temporary.is_symlink():
        raise MemoryError("temporary memory path already exists")
    try:
        temporary.write_bytes(content)
        temporary.chmod(mode)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _map_markers(section: str) -> tuple[str, str]:
    return (
        f"<!-- MTP:MAP:BEGIN section={section} -->",
        f"<!-- MTP:MAP:END section={section} -->",
    )


def _replace_projection(section: str, existing: str | None, body: str) -> str:
    begin, end = _map_markers(section)
    managed = f"{begin}\n{body.strip()}\n{end}"
    if existing is None:
        return f"## {section}\n\n{managed}\n"
    if existing.count(begin) != existing.count(end):
        raise MemoryError(f"invalid project-map markers: {section}")
    if existing.count(begin) > 1:
        raise MemoryError(f"duplicate project-map markers: {section}")
    if begin not in existing:
        heading_end = existing.find("\n")
        suffix = existing[heading_end + 1:].lstrip("\n") if heading_end >= 0 else ""
        return f"## {section}\n\n{managed}\n" + (f"\n{suffix}" if suffix else "")
    start = existing.index(begin)
    end_start = existing.find(end, start + len(begin))
    if end_start == -1:
        raise MemoryError(f"invalid project-map marker order: {section}")
    finish = end_start + len(end)
    return existing[:start] + managed + existing[finish:]


def render_project_map(existing: bytes, projection: dict[str, Any]) -> bytes:
    contract = load_contract()["project_map"]
    sections = projection.get("sections")
    conflicts = projection.get("conflicts")
    if set(projection) != {"sections", "conflicts"}:
        raise MemoryError("project-map projection fields")
    if not isinstance(conflicts, list) or not all(isinstance(item, str) and item for item in conflicts):
        raise MemoryError("project-map conflicts must be a string list")
    if conflicts:
        raise MemoryError("project-map facts conflict")
    expected = contract["sections"]
    # G-1: partial update is allowed — a provided section must be a known section and
    # non-empty; sections left out keep their current content.
    if not isinstance(sections, dict) or not sections:
        raise MemoryError("project-map sections must be a non-empty mapping")
    unknown = [name for name in sections if name not in expected]
    if unknown:
        raise MemoryError(f"unknown project-map section: {unknown[0]}")
    if not all(isinstance(value, str) and value.strip() for value in sections.values()):
        raise MemoryError("project-map section content is incomplete")
    if any(HEADING_RE.search(value) or "<!-- MTP:" in value for value in sections.values()):
        raise MemoryError("project-map section content contains structural markup")
    try:
        text = existing.decode("utf-8")
    except UnicodeDecodeError as error:
        raise MemoryError("CLAUDE.md must be UTF-8") from error
    if text.count(MTP_BEGIN) != 1 or text.count(MTP_END) != 1:
        raise MemoryError("CLAUDE.md requires one MTP managed block")
    start = text.index(MTP_BEGIN) + len(MTP_BEGIN)
    finish = text.index(MTP_END, start)
    block = text[start:finish].strip("\n")
    matches = [match for match in HEADING_RE.finditer(block) if match.group(1) in expected]
    current: dict[str, str] = {}
    preamble = block[:matches[0].start()].rstrip() if matches else block.rstrip()
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(block)
        value = block[match.start():end].rstrip() + "\n"
        if match.group(1) in current:
            raise MemoryError(f"duplicate project-map section: {match.group(1)}")
        current[match.group(1)] = value
    # Resolve the effective content: prefer the new value; a section left out keeps its
    # current body; a section present in neither must be supplied (map stays complete).
    rendered = []
    for section in expected:
        if section in sections:
            rendered.append(_replace_projection(section, current.get(section), sections[section]).rstrip())
        elif section in current:
            rendered.append(current[section].rstrip())
        else:
            raise MemoryError(f"project-map section has no existing value: {section}")
    if preamble:
        rendered.insert(0, preamble)
    managed = "\n\n".join(rendered) + "\n"
    return (text[:start] + "\n" + managed + MTP_END + text[finish + len(MTP_END):]).encode("utf-8")


def project_map_template() -> dict[str, Any]:
    """G-1 ``--show-template``: a fill-in skeleton listing every managed section."""
    expected = load_contract()["project_map"]["sections"]
    return {
        "sections": {section: f"<{section} content>" for section in expected},
        "conflicts": [],
    }


# L-017 map-quality lint. The project map is a POINTER entry, not a content container:
# - End-to-End Flow must be the project's own pipeline, never the MTP protocol flow;
# - no section should be bloated (a whole spec pasted in) or a bare stub ("see X.md").
# Write paths (m-new scaffold, sync apply) fail closed on the protocol signature; reads
# (lint / corpus scans) only warn. An explicit `<!-- mtpl:flow-is-project-specific -->`
# comment inside the section exempts it (downgraded to a notice).
FLOW_EXEMPT_MARKER = "mtpl:flow-is-project-specific"
PROTOCOL_PAIRS = (("plan", "lesson check"), ("define", "registry sync"))
SECTION_MAX_BYTES = 1200
SECTION_MIN_BYTES = 80
# T-021-MAPQUALITY: every template section carries this explicit token, so a scaffolded
# map is never mistaken for project facts. Stock bodies below are what the templates
# ship; a section that still equals one of them was never filled in.
UNREPLACED_MARKER = "待替换"
STOCK_SECTION_BODIES: dict[str, set[str]] = {
    "Project": {
        "- 名称: `{{PROJECT_NAME}}`\n- Project ID: `{{PROJECT_ID}}`  ·  Registry ID: `mtp-local-registry-v1`  ·  Lifecycle: `active`\n- Accepted source revision: `{{SOURCE_REVISION}}`\n- 入口: `AGENTS.md`、`ai/NEXT.md`、`ai/check.sh`\n- 事实源: `ai/brief.md`；选择经验: `ai/lessons.md`（按需，不默认加载）。\n- Registry records are projections; 本项目与其引用的证据为准。",
        "- 待替换：项目名称、Project ID、Registry ID、生命周期、Accepted source revision，以及入口与事实源的指针（事实源 `ai/brief.md`）。",
    },
    "Current State": {
        "- 阶段: 建项目后先塑形再实现。\n- 进度与当前 Task: 见 `ai/NEXT.md`。",
        "- 待替换：当前阶段一句话（做到哪了）；进度与当前 Task 只留指针，指向 `ai/NEXT.md`，细节不在这里展开。",
    },
    "End-to-End Flow": {
        '<!-- 占位：替换为本项目**真实的端到端流水线**（输入 → 处理 → 输出/交付，含失败/回退回路）。\n     依据**项目本体**（入口脚本 / 输入 / 输出）提炼，**不要**写 MTP 协议流程；节点要短、细节外链。\n     规范见 m-new `references/claude-md-guide.md`。 -->\n```mermaid\nflowchart LR\n  P["待替换为本项目流水线"] --> Q["…"] --> R["输出/交付"]\n```',
        '```mermaid\nflowchart LR\n  P["待替换为本项目流水线"] --> Q["…"] --> R["输出/交付"]\n```',
    },
    "Structure": {
        "- 根目录文件夹（用途）: `<源目录>/` … ；`references/` 项目参考；`ai/` 项目事实与流程状态。\n- `ai/`: `brief.md` 事实源 · `NEXT.md` 进度/当前 Task · `plan.md` 计划 · `review.md` 审查 · `lessons.md` 经验 · `backlog.md` 待办 · `check.sh` 质量门。",
        "- 待替换：根目录每个文件夹**是干什么用的**（给人看）；`ai/` 各文件分别「答什么问题」。路径集中写在这里，别处只放指针。",
        "- 待替换：根目录每个文件夹**是干什么用的**（给人看）；`ai/` 各文件分别「答什么问题」。路径集中写在这里，别处只放指针。\n- `ai/` 根固定集合（不得新增）：`brief / NEXT / plan / lessons / backlog / OWNER_DECISIONS / IMPL_LOG / review / HANDOFF` + `facts.json / mtp.json / check.sh / registry.py`；额外文件会被 `m-new` 收尾检查告警。",
        "- 待替换：把下面示例换成项目真实结构（只列导航节点；每行 `←` 写用途，深度 2–3 层，禁列生成物）。\n\n```text\n<项目根目录名>/\n├── <目录>/        ← <用途>\n├── <入口文件>     ← <用途>\n└── ai/            ← MTP 状态与证据\n```\n\n`ai/` 根固定集合（不得新增）：`brief / NEXT / plan / lessons / backlog / OWNER_DECISIONS / IMPL_LOG / review / HANDOFF` + `facts.json / mtp.json / check.sh / registry.py`；额外文件会被 `m-new` 收尾检查告警。",
    },
    "Entry Points": {
        "- Agent 规则: `AGENTS.md`；当前 Task: `ai/NEXT.md`；质量门: `ai/check.sh`；Registry helper: `ai/registry.py`。",
        "- 待替换：本项目的 Agent 入口、当前 Task、质量门、Registry helper 分别是什么；只列表，不展开内容。",
    },
    "Scope": {
        "- 先在建项目时把目标与范围写进 `ai/brief.md`，再规划实现。",
        "- 待替换：本项目做什么、不做什么（目标与范围）；判据与细节放 `ai/brief.md`，这里只留要点。",
    },
    "Boundaries": {
        "- 不臆测未确认的产品 / 安全 / 数据边界，写进 `ai/brief.md` 为准。",
        "- 待替换：本项目的硬边界（产品 / 安全 / 数据 / 依赖 / 不可逆操作）；未确认的边界不得臆测。",
    },
    "Project Rules And Lessons": {
        "- 项目专属规则在此；通用 Agent 规则见 `AGENTS.md`；可复用经验在 `ai/lessons.md`（按需加载）。\n- 每次修复失败后: 先验证成功 → 判断复发/高代价 → Lesson Check → 重跑 Acceptance。\n- **细节不在此展开**：领域口径、字段、流程细节放 `ai/brief.md` 与项目 `references/`，此处只留指针。",
        "- 待替换：项目专属规则**要点** + 指针（通用规则 → `AGENTS.md`）；**细节不在此展开**，领域口径放 `ai/brief.md` 与 `references/`。",
    },
    "Required Behaviors": {
        "- 触发: 计划 Task 就绪 → 动作: 按合同执行 → 验证: 跑其声明的 Gate。",
        "- 待替换：本项目自己的「触发 → 动作 → 验证」；不要照抄通用流程，只写本项目的硬性行为。",
    },
    "Document Navigation": {
        "- 阅读次序: 先本文件 `CLAUDE.md` → `ai/brief.md`（事实）→ 按需项目 `references/`、测试、实现证据。\n- 跨项目: Registry 全量 index → 目标 `CLAUDE.md` → 只读相关的 `ai/`/测试/证据；不整包乱开。",
        "- 待替换：本项目从哪读到哪（`CLAUDE.md` → `ai/brief.md` → 按需证据）；跨项目先读目标 `CLAUDE.md`，不整包乱开。",
    },
}


# T-022-GATE: map and naming quality gates. H1 / Structure / Name==title are read-only
# checks. ``NAME_TITLE_ENFORCEMENT`` stays "warn" until T-022-BACKFILL has rewritten every
# active Registry record; flipping it to "block" is the only switch.
NAME_TITLE_ENFORCEMENT = "warn"
NAME_TITLE_MODES = ("warn", "block")
H1_PLACEHOLDERS = frozenset({
    "待替换", "claude.md", "项目", "project", "untitled", "tbd", "todo", "name",
})
GENERATED_DIRECTORIES = (
    "node_modules", "__pycache__", ".git", "dist", "build", "target", "venv", ".venv",
    ".pytest_cache", ".mypy_cache", "coverage", ".next",
)
TREE_ENTRY_RE = re.compile(r"^[├└]──\s+(?P<name>[^←]+?)\s*(?:←.*)?$")
MAP_GATE_CODES = frozenset({
    "missing-h1", "empty-h1", "placeholder-h1", "junk-h1",
    "structure-missing-tree", "structure-lists-generated", "structure-path-missing",
    "name-title-mismatch",
})
# L-031 ⑤⑥⑦: the ai/ file lifecycle budgets. These numbers are defined here once;
# skills/mtp/skills/m-build/references/ai-file-lifecycle.md mirrors the table and
# tests/mtp01/test_ai_file_lifecycle.py compares the two item by item.
AI_FILE_BUDGETS = {
    "ai/NEXT.md": 2048,
    "ai/brief.md": 24576,
    "ai/plan.md": 49152,
    "ai/backlog.md": 65536,
    "ai/lessons.md": 16384,
    "ai/review.md": 24576,
    "ai/OWNER_DECISIONS.md": 24576,
}
AI_FILE_TOTAL_BUDGET = 49152
AI_FILE_RED_LINE_EXTRA = 500
BACKLOG_OPEN_WARN = 15
ROT_MARKER_RE = re.compile(
    r"<!-- MTP:ROT:(?P<kind>BEGIN|END) segment=(?P<segment>[A-Za-z0-9._-]+) -->",
)
ROT_CONFIRM_RE = re.compile(
    r"MTP:ROT-CONFIRM (?P<segment>[A-Za-z0-9._-]+) (?P<version>[0-9A-Za-z.-]+) "
    r"(?P<stamp>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2}))"
    r"(?: (?P<digest>[0-9a-f]{64}))?",
)
AI_FILE_SUGGESTION_KINDS = frozenset({
    "over-budget", "under-budget", "over-total", "backlog-open", "red-line-extra",
})
# Files rotate scans. brief.md is a contract file and backlog.md is a table; both are
# reported, never silently skipped.
ROT_SCAN_FILES = (
    "NEXT.md", "brief.md", "plan.md", "backlog.md", "lessons.md", "review.md",
    "OWNER_DECISIONS.md", "IMPL_LOG.md",
)
ROT_POINTER_TEMPLATE = "> 已迁至 {destination}（segment={segment}）"
ROT_END_RE = re.compile(rb"<!-- MTP:ROT:END [^>]*-->")
MTP_ROT_LOG_PREFIX = "rotate:"


def _rot_segments(text: str) -> list[dict[str, Any]]:
    """ROT segments as ``{segment, start, end}`` (1-based, marker lines included).

    Nested, duplicated, mismatched and unclosed markers all fail closed.
    """
    segments: list[dict[str, Any]] = []
    opened: tuple[int, str] | None = None
    names: set[str] = set()
    for number, line in enumerate(text.splitlines(), 1):
        match = ROT_MARKER_RE.search(line)
        if match is None:
            continue
        kind, name = match.group("kind"), match.group("segment")
        if kind == "BEGIN":
            if opened is not None:
                if opened[1] == name:
                    raise MemoryError("duplicate-rot-segment")
                raise MemoryError("nested-rot-marker")
            opened = (number, name)
        else:
            if opened is None:
                raise MemoryError("unexpected-rot-end")
            if opened[1] != name:
                raise MemoryError("mismatched-rot-marker")
            segments.append({"segment": name, "start": opened[0], "end": number})
            opened = None
            names.add(name)
    if opened is not None:
        raise MemoryError("unclosed-rot-marker")
    if len(names) != len(segments):
        raise MemoryError("duplicate-rot-segment")
    return segments


def _rot_inbound_references(
    root: Path, segment: str, source: Path, skip: tuple[int, int],
) -> list[str]:
    """String references to ``segment`` outside the block being moved, by file:line."""
    needle = f"segment={segment}"
    hits: list[str] = []
    for name in ROT_SCAN_FILES:
        path = root / "ai" / name
        if not path.is_file():
            continue
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if path == source and skip[0] <= number <= skip[1]:
                continue
            if needle in line:
                hits.append(f"{path.relative_to(root).as_posix()}:{number}")
    return hits


BACKLOG_TERMINAL_STATES = frozenset({"resolved", "wontfix", "archived"})
# Only an explicit ``State: <value>`` marker closes an entry. Scanning the whole row
# would treat "unresolved issue remains open" as resolved.
BACKLOG_STATE_RE = re.compile(r"State:\s*(?P<state>[A-Za-z-]+)")


def _backlog_open_count(path: Path) -> int:
    """Open backlog entries: table rows keyed by ``X-NNN`` without a terminal state."""
    if not path.is_file():
        return 0
    total = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        if len(cells) < 2 or re.fullmatch(r"[A-Z]-\d{3}", cells[0]) is None:
            continue
        match = BACKLOG_STATE_RE.search(stripped)
        if match and match.group("state").lower() in BACKLOG_TERMINAL_STATES:
            continue
        total += 1
    return total


def _project_version(root: Path) -> str | None:
    path = root / "ai/mtp.json"
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("mtp_version")
    except (OSError, json.JSONDecodeError):
        return None


def _version_tuple(value: str) -> tuple[int, ...] | None:
    parts = re.findall(r"\d+", value)
    return tuple(int(part) for part in parts) if parts else None


def _archived_versions(root: Path) -> set[str]:
    archive = root / "ai/archive"
    if not archive.is_dir():
        return set()
    return {item.name for item in archive.iterdir() if item.is_dir()}


def budget_report(
    target: Path, *, previous: dict[str, Any] | None = None, version: str | None = None,
) -> dict[str, Any]:
    """L0 report: per-file byte budgets, backlog open count, and suggestion keys.

    The report never writes. ``escalate`` is true for a suggestion whose exact key was
    already present in the previous version's recorded report.
    """
    root = target.resolve()
    files: dict[str, Any] = {}
    suggestions: list[dict[str, Any]] = []
    for relative, limit in AI_FILE_BUDGETS.items():
        path = root / relative
        size = path.stat().st_size if path.is_file() else 0
        over = size > limit
        files[relative] = {"bytes": size, "budget": limit, "over": over}
        if over:
            suggestions.append({
                "key": f"{relative}:over-budget", "kind": "over-budget", "file": relative,
            })
    # The total covers every root ai/ document, not only the seven with their own
    # budget: a single oversized IMPL_LOG must still trip the aggregate warning.
    root_docs = [item for item in (root / "ai").glob("*.md") if item.is_file()]
    total = sum(item.stat().st_size for item in root_docs)
    if total > AI_FILE_TOTAL_BUDGET:
        suggestions.append({"key": "ai/:over-total", "kind": "over-total", "bytes": total})
    open_count = _backlog_open_count(root / "ai/backlog.md")
    if open_count > BACKLOG_OPEN_WARN:
        suggestions.append({
            "key": "ai/backlog.md:backlog-open",
            "kind": "backlog-open",
            "open_count": open_count,
        })
    previous_keys = {
        item.get("key") for item in (previous or {}).get("suggestions", [])
    }
    current_version = version or _project_version(root)
    previous_version = (previous or {}).get("version")
    # Escalation needs evidence that the previous report came from the version right
    # before this one: both versions known, the previous one archived, and nothing
    # archived in between. A same-version re-run, an unknown version, a later version
    # or a skipped version all stay non-escalating.
    archived = _archived_versions(root)
    current_parts = _version_tuple(current_version) if current_version else None
    previous_parts = _version_tuple(previous_version) if previous_version else None
    precedes = False
    if (
        current_parts is not None
        and previous_parts is not None
        and previous_version in archived
        and previous_parts < current_parts
    ):
        between = [
            _version_tuple(name) for name in archived
            if _version_tuple(name) is not None and name != previous_version
        ]
        precedes = not any(
            previous_parts < parts < current_parts for parts in between if parts
        )
    for item in suggestions:
        item["escalate"] = bool(item["key"] in previous_keys and precedes)
    report = {
        "version": current_version,
        "files": files,
        "total_bytes": total,
        "total_budget": AI_FILE_TOTAL_BUDGET,
        "backlog": {"open_count": open_count, "warn": BACKLOG_OPEN_WARN},
        "suggestions": suggestions,
        "escalate": any(item["escalate"] for item in suggestions),
    }
    return report


def _rot_confirms(root: Path, segment: str) -> list[dict[str, Any]]:
    """Every ``MTP:ROT-CONFIRM`` line for ``segment`` in ai/IMPL_LOG.md, in order."""
    path = root / "ai/IMPL_LOG.md"
    if not path.is_file():
        return []
    found: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        match = ROT_CONFIRM_RE.search(line)
        if match is None or match.group("segment") != segment:
            continue
        found.append({
            "segment": segment,
            "version": match.group("version"),
            "stamp": match.group("stamp"),
            "digest": match.group("digest"),
        })
    return found


def _parse_stamp(value: str):
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise MemoryError("invalid-iso8601") from error


def rotate(
    target: Path, *, segment: str, destination: str, apply: bool,
    version: str | None = None, preview_at: str | None = None,
    expect_digest: str | None = None,
) -> dict[str, Any]:
    """Move a marked segment to an archive file, leaving exactly one pointer line."""
    root = target.resolve()
    located: list[tuple[Path, dict[str, Any]]] = []
    for name in ROT_SCAN_FILES:
        path = root / "ai" / name
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        for item in _rot_segments(text):
            if item["segment"] == segment:
                located.append((path, item))
    if not located:
        raise MemoryError("rot-segment-not-found")
    if len(located) > 1:
        raise MemoryError("rot-segment-not-unique")
    source, block = located[0]
    if source.name == "backlog.md":
        raise MemoryError("unsupported-table-format")
    if source.name == "brief.md":
        raise MemoryError("unsupported-contract-file")

    # Bytes, not text: read_text would fold CRLF into LF and re-serialise the whole file.
    raw = source.read_bytes()
    lines = raw.splitlines(keepends=True)
    body_bytes = b"".join(lines[block["start"] - 1:block["end"]])
    newline = b"\r\n" if b"\r\n" in raw[:4096] else b"\n"
    payload = {
        "decision": "rotate",
        "segment": segment,
        "source": source.relative_to(root).as_posix(),
        "start": block["start"],
        "end": block["end"],
        "bytes": len(body_bytes),
        "destination": destination,
        "inbound_references": _rot_inbound_references(
            root, segment, source, (block["start"], block["end"]),
        ),
        "external_pointers_checked": False,
        "applied": False,
    }
    # Real ancestry, archive-only, and never onto a live document. ``startswith`` on a
    # string would accept a sibling directory that merely shares the prefix.
    destination_path = (root / destination).resolve()
    archive_root = (root / "ai/archive").resolve()
    protected = {(root / "ai" / name).resolve() for name in ROT_SCAN_FILES}
    if not destination_path.is_relative_to(root):
        raise MemoryError("unsafe-rotation-destination")
    if destination_path == source.resolve() or destination_path in protected:
        raise MemoryError("rotation-destination-in-document")
    if not destination_path.is_relative_to(archive_root):
        raise MemoryError("rotation-destination-outside-archive")
    # A segment may not straddle an MTP:MAP block boundary.
    if b"<!-- MTP:MAP:" in body_bytes:
        raise MemoryError("rot-segment-crosses-map-block")
    payload["preview_digest"] = hashlib.sha256(
        body_bytes + b"\n" + destination.encode("utf-8")
    ).hexdigest()
    payload["preview_at"] = preview_at or datetime.now(timezone.utc).isoformat(timespec="seconds")
    if expect_digest is not None and expect_digest != payload["preview_digest"]:
        raise MemoryError("stale-preview")
    if payload["inbound_references"]:
        payload["blocked"] = "inbound-references"
        return payload
    if not apply:
        return payload
    # AC-L031T6-2: apply is gated on a preview and on the owner's confirmation line.
    if not preview_at:
        raise MemoryError("rotate-requires-preview")
    confirms = _rot_confirms(root, segment)
    if not confirms:
        raise MemoryError("rot-confirm-missing")
    if len(confirms) > 1:
        # One confirmation per segment per version; picking the latest would silently
        # accept an older approval written after the reviewed content changed.
        raise MemoryError("rot-confirm-ambiguous")
    confirm = confirms[0]
    if version is None or confirm["version"] != version:
        raise MemoryError("rot-confirm-version-mismatch")
    if _parse_stamp(confirm["stamp"]) <= _parse_stamp(preview_at):
        raise MemoryError("rot-confirm-not-after-preview")
    if confirm["digest"] is None:
        # Without the digest the confirmation cannot be tied to what was reviewed.
        raise MemoryError("rot-confirm-unbound")
    if confirm["digest"] != payload["preview_digest"]:
        raise MemoryError("rot-confirm-digest-mismatch")

    pointer = (
        ROT_POINTER_TEMPLATE.format(destination=destination, segment=segment).encode("utf-8")
        + newline
    )
    previous_archive = (
        destination_path.read_bytes() if destination_path.is_file() else None
    )
    log_path = root / "ai/IMPL_LOG.md"
    log_is_source = source.resolve() == log_path.resolve()
    previous_log = None if log_is_source else (
        log_path.read_bytes() if log_path.is_file() else None
    )
    try:
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        prefix = b"" if previous_archive is None else (previous_archive + newline)
        destination_path.write_bytes(prefix + body_bytes)
        updated = (
            b"".join(lines[:block["start"] - 1]) + pointer + b"".join(lines[block["end"]:])
        )
        entry = f"- {MTP_ROT_LOG_PREFIX} {segment} -> {destination}".encode("utf-8") + newline

        def with_entry(content: bytes) -> bytes:
            # Keep the entry inside the log's marked region: append before the last ROT
            # end marker, so it never dangles outside the segment that owns it.
            markers = list(ROT_END_RE.finditer(content))
            if markers:
                position = markers[-1].start()
                return content[:position] + entry + content[position:]
            return content.rstrip(b"\r\n") + newline + entry

        if log_is_source:
            updated = with_entry(updated)
        _atomic_write(source, updated, stat.S_IMODE(source.stat().st_mode))
        if not log_is_source:
            base = previous_log if previous_log is not None else b"# Implementation Log\n"
            log_path.write_bytes(with_entry(base))
    except Exception:
        if previous_archive is None:
            destination_path.unlink(missing_ok=True)
        else:
            destination_path.write_bytes(previous_archive)
        source.write_bytes(raw)
        if not log_is_source:
            if previous_log is None:
                log_path.unlink(missing_ok=True)
            else:
                log_path.write_bytes(previous_log)
        raise
    payload["applied"] = True
    return payload


FENCE_OPEN_RE = re.compile(r"^ {0,3}(?P<char>[`~])(?P<ticks>\1{2,})(?P<info>.*)$")


def _fence_open(line: str) -> tuple[str, int] | None:
    """CommonMark opening fence: backtick or tilde, at least three long."""
    match = FENCE_OPEN_RE.match(line)
    if match is None:
        return None
    if match.group("char") == "`" and "`" in match.group("info"):
        return None
    return match.group("char"), 1 + len(match.group("ticks"))


def _fence_closes(line: str, char: str, length: int) -> bool:
    """A closing fence uses the same character, is at least as long, and ends the line."""
    stripped = line.lstrip(" ")
    if len(line) - len(stripped) > 3:
        return False
    run = 0
    while run < len(stripped) and stripped[run] == char:
        run += 1
    if run < length:
        return False
    return stripped[run:].strip() == ""


def _first_h1(text: str) -> str | None:
    """The document's real H1; heading-like lines inside fenced code are ignored."""
    fence: tuple[str, int] | None = None
    for line in text.splitlines():
        if fence is not None:
            if _fence_closes(line, *fence):
                fence = None
            continue
        opened = _fence_open(line)
        if opened is not None:
            fence = opened
            continue
        if line.startswith("# "):
            return line[2:].strip()
        if line.startswith("## "):
            return None
    return None


def _h1_problem(value: str | None) -> dict[str, Any] | None:
    if value is None:
        return {"code": "missing-h1"}
    if not value:
        return {"code": "empty-h1"}
    if UNREPLACED_MARKER in value or value.casefold() in H1_PLACEHOLDERS:
        return {"code": "placeholder-h1", "value": value}
    if not any(character.isalnum() or "一" <= character <= "鿿" for character in value):
        return {"code": "junk-h1", "value": value}
    return None


def _tree_entries(tree: str) -> list[tuple[int, str]]:
    """(depth, path) for every tree entry, with ``←`` comments stripped.

    Each nesting level is a four-character cell: ``│   `` (a continued branch) or four
    spaces (the indent under a final branch). The entry itself starts with ``├── `` or
    ``└── ``, so a nested node is never mistaken for a first-level one.
    """
    entries: list[tuple[int, str]] = []
    for line in tree.splitlines():
        position = 0
        depth = 0
        while True:
            if line.startswith(("│   ", "    "), position):
                depth += 1
                position += 4
            elif line.startswith(("├── ", "└── "), position):
                path = line[position + 4:].split("←", 1)[0].strip().rstrip("/").strip()
                if path:
                    entries.append((depth, path))
                break
            else:
                break
    return entries


def _tree_first_level(tree: str) -> list[str]:
    names: list[str] = []
    for depth, path in _tree_entries(tree):
        if depth != 0:
            continue
        name = path.split("/", 1)[0].strip()
        if name and name not in names:
            names.append(name)
    return names


def _tree_components(tree: str) -> set[str]:
    """Every path component in the tree; ``←`` comments never contribute."""
    components: set[str] = set()
    for _, path in _tree_entries(tree):
        for part in path.split("/"):
            part = part.strip()
            if part:
                components.add(part)
    return components


def _structure_problems(body: str, project_root: Path | None) -> list[dict[str, Any]]:
    """AC-GATE-2: a text tree, no generated directories, first level must exist."""
    match = re.search(r"```text\r?\n(?P<tree>.*?)```", body, re.DOTALL)
    if match is None:
        return [{"code": "structure-missing-tree"}]
    tree = match.group("tree")
    problems: list[dict[str, Any]] = []
    # Only real path components count: a ``←`` comment mentioning dist is not an entry.
    components = _tree_components(tree)
    for name in GENERATED_DIRECTORIES:
        if name in components:
            problems.append({"code": "structure-lists-generated", "name": name})
    if project_root is not None:
        for first in _tree_first_level(tree):
            if not (project_root / first).exists():
                problems.append({"code": "structure-path-missing", "path": first})
    return problems


def _name_title_problem(name: str | None, title: str | None) -> dict[str, Any] | None:
    if name is None or title is None:
        return None
    if " ".join(name.split()) == " ".join(title.split()):
        return None
    return {"code": "name-title-mismatch", "name": name, "title": title}


def _section_body(text: str, name: str) -> str | None:
    begin = f"<!-- MTP:MAP:BEGIN section={name} -->"
    end = f"<!-- MTP:MAP:END section={name} -->"
    if begin not in text or end not in text:
        return None
    return text.split(begin, 1)[1].split(end, 1)[0]


def map_lint(text: str, *, budget_max: int = SECTION_MAX_BYTES, budget_min: int = SECTION_MIN_BYTES,
             scan: bool = False, sections: list[str] | None = None,
             project_root: Path | None = None, title: str | None = None,
             name_title: str | None = None) -> dict[str, Any]:
    """L-017 + T-021-MAPQUALITY map-quality lint.

    ``scan=True`` (read path): the protocol-flow signature and unreplaced placeholders
    are warnings.
    ``scan=False`` (write path): both are fail-closed (errors).

    Path-independent: a missing or empty contracted section is an error, and a section
    whose body still equals a shipped stock body is a warning (never filled in).
    """
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    flow = _section_body(text, "End-to-End Flow")
    if flow is not None:
        low = flow.lower()
        exempt = FLOW_EXEMPT_MARKER in low
        hit = next((pair for pair in PROTOCOL_PAIRS if all(word in low for word in pair)), None)
        if hit is not None:
            entry = {"code": "protocol-flow-signature", "pair": list(hit)}
            if exempt:
                warnings.append({**entry, "note": "exempted by marker"})
            elif scan:
                warnings.append(entry)
            else:
                errors.append(entry)
    for section in sections if sections is not None else load_contract()["project_map"]["sections"]:
        body = _section_body(text, section)
        if body is None:
            errors.append({"code": "missing-section", "section": section})
            continue
        stripped = body.strip()
        if not stripped:
            errors.append({"code": "empty-section", "section": section})
            continue
        if UNREPLACED_MARKER in stripped:
            entry = {"code": "unreplaced-placeholder", "section": section}
            (warnings if scan else errors).append(entry)
        elif stripped in STOCK_SECTION_BODIES.get(section, set()):
            warnings.append({"code": "section-identical-to-template", "section": section})
        size = len(body.encode("utf-8"))
        if size > budget_max:
            warnings.append({"code": "section-over-budget", "section": section, "bytes": size, "max": budget_max})
        elif size < budget_min:
            warnings.append({"code": "section-under-budget", "section": section, "bytes": size, "min": budget_min})
    h1 = _first_h1(text)
    h1_problem = _h1_problem(h1)
    if h1_problem is not None:
        warnings.append(h1_problem)
    structure = _section_body(text, "Structure")
    if structure is not None:
        warnings.extend(_structure_problems(structure, project_root))
    enforcement = name_title or NAME_TITLE_ENFORCEMENT
    mismatch = _name_title_problem(h1, title)
    if mismatch is not None:
        entry = {**mismatch, "mode": enforcement}
        (errors if enforcement == "block" else warnings).append(entry)
    # AC-GATE-5: the schema is fixed now so T-022-L031-T5 can fill it without shape
    # churn. This task never emits an entry.
    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "budget_suggestions": [],
    }


def enforce_map_lint(text: str) -> None:
    """Fail-closed write-path check: raise on the protocol-flow signature (L-017)."""
    result = map_lint(text)
    if result["errors"]:
        raise MemoryError("project-map lint failed: " + "; ".join(e["code"] for e in result["errors"]))


def inspect_sync(target: Path, projection: dict[str, Any], *, explicit: bool, actor: str) -> dict[str, Any]:
    path = target / "CLAUDE.md"
    source = _safe_file(path, required=True)
    # G-1: a partial projection is accepted — render_project_map fills omitted sections
    # from the current map, so a caller may supply only the sections that changed.
    digest = _digest("sync", source, projection)
    # G-2: report the target file path (not just a boolean) so callers know where to write.
    target_path = "CLAUDE.md"
    conflicts = projection.get("conflicts")
    if actor != "primary":
        return {"decision": "forbidden-writer", "route": "m-build", "write_allowed": False,
                "plan_digest": digest, "target_path": target_path}
    if explicit is not True:
        return {"decision": "not-requested", "route": "m-build", "write_allowed": False,
                "plan_digest": digest, "target_path": target_path}
    if isinstance(conflicts, list) and conflicts:
        return {"decision": "fact-conflict", "route": "m-define", "write_allowed": False,
                "plan_digest": digest, "target_path": target_path}
    rendered = render_project_map(source, projection)
    return {
        "decision": "current" if rendered == source else "sync",
        "route": "m-build",
        "write_allowed": False,
        "plan_digest": digest,
        "target_path": target_path,
        "changed": rendered != source,
    }


def apply_sync(target: Path, projection: dict[str, Any], expected_digest: str, *, explicit: bool, actor: str) -> dict[str, Any]:
    path = target / "CLAUDE.md"
    # G-1: partial projections are handled by render_project_map (omitted sections keep
    # their current content), so no pre-resolution step is needed here.
    preview = inspect_sync(target, projection, explicit=explicit, actor=actor)
    if preview["decision"] not in {"sync", "current"}:
        raise MemoryError("project-map synchronization is not writable")
    # G-1: when no digest is supplied, fall back to the dry-run digest (one call, not two).
    expected_digest = expected_digest or preview["plan_digest"]
    if preview["plan_digest"] != expected_digest:
        raise MemoryError("plan digest mismatch")
    source = _safe_file(path, required=True)
    rendered = render_project_map(source, projection)
    # L-017 write-path lint: fail closed on the protocol-flow signature (never on size).
    enforce_map_lint(rendered.decode("utf-8"))
    if rendered != source:
        _atomic_write(path, rendered, stat.S_IMODE(path.stat().st_mode))
    return {**preview, "applied": rendered != source, "write_allowed": True}


CURRENT_STATE_SECTION = "Current State"


def current_state_from_next(next_text: str) -> str:
    """Deterministic ``Current State`` body derived only from ``ai/NEXT.md`` facts.

    No interpretation: the machine takes the declared task/state and plan revision and
    renders one fixed shape, so re-running it on unchanged input is byte-identical
    (AC-MAPTRIGGER-4) and this generator is the section's only writer.
    """
    state = "未记录"
    revision = "未记录"
    for line in next_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("- task/state:") and state == "未记录":
            value = stripped.split(":", 1)[1].strip()
            if value:
                state = value
        elif stripped.startswith("- plan_revision:") and revision == "未记录":
            value = stripped.split(":", 1)[1].strip().strip("`")
            if value:
                revision = value[:12]
    return (
        f"- 当前 Task：{state}\n"
        f"- 计划 revision：{revision}\n"
        "- 进度明细与下一步：`ai/NEXT.md`（本行由 project_memory 机械生成，勿手改）"
    )


def map_status(target: Path) -> dict[str, Any]:
    """Read-only map readiness + staleness (AC-MAPTRIGGER-1/-3/-5).

    ``ready`` is false while any contracted section is an unreplaced placeholder (or is
    missing/empty). ``stale`` is true when the ``Current State`` body differs from what
    ``current_state_from_next`` would generate from the current ``ai/NEXT.md``.
    """
    path = target / "CLAUDE.md"
    if not path.is_file():
        return {"ready": False, "pending": [], "stale": False, "reason": "missing-claude-md", "errors": []}
    text = path.read_text(encoding="utf-8")
    lint = map_lint(text)
    quality = map_lint(text, scan=True, project_root=target, title=target.name)
    gate = [
        entry for entry in (*quality["errors"], *quality["warnings"])
        if entry["code"] in MAP_GATE_CODES
    ]
    pending = sorted({
        error["section"] for error in lint["errors"]
        if error["code"] == "unreplaced-placeholder" and error.get("section")
    })
    stale = False
    next_path = target / "ai/NEXT.md"
    if next_path.is_file():
        expected = current_state_from_next(next_path.read_text(encoding="utf-8"))
        actual = _section_body(text, CURRENT_STATE_SECTION)
        stale = actual is not None and actual.strip() != expected.strip()
    return {
        "ready": not lint["errors"],
        "pending": pending,
        "stale": stale,
        "gate": gate,
        "errors": sorted({error["code"] for error in lint["errors"]}),
    }


def apply_current_state(target: Path, *, actor: str = "primary") -> dict[str, Any]:
    """Regenerate ``Current State`` from ``ai/NEXT.md`` through the sync write path."""
    next_path = target / "ai/NEXT.md"
    if not next_path.is_file():
        raise MemoryError("current-state generator requires ai/NEXT.md")
    body = current_state_from_next(next_path.read_text(encoding="utf-8"))
    projection = {"sections": {CURRENT_STATE_SECTION: body}, "conflicts": []}
    preview = inspect_sync(target, projection, explicit=True, actor=actor)
    if preview["decision"] not in {"sync", "current"}:
        raise MemoryError(f"current-state update is not writable: {preview.get('decision')}")
    return apply_sync(target, projection, preview["plan_digest"], explicit=True, actor=actor)


def empty_lessons() -> bytes:
    return render_lessons({"candidates": [], "active": []})


def render_lessons(state: dict[str, list[dict[str, Any]]]) -> bytes:
    parts = ["# Project Lessons", "", "## Candidates", ""]
    for key, heading in (("candidates", None), ("active", "## Active Lessons")):
        if heading:
            parts.extend((heading, ""))
        begin, end = LESSON_REGIONS[key]
        data = json.dumps(state[key], ensure_ascii=False, indent=2, sort_keys=True)
        parts.extend((begin, "```json", data, "```", end, ""))
    return ("\n".join(parts).rstrip() + "\n").encode("utf-8")


def parse_lessons(content: bytes) -> dict[str, list[dict[str, Any]]]:
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError as error:
        raise MemoryError("lessons must be UTF-8") from error
    state: dict[str, list[dict[str, Any]]] = {}
    for key, (begin, end) in LESSON_REGIONS.items():
        pattern = re.compile(re.escape(begin) + r"\s*```json\s*(.*?)\s*```\s*" + re.escape(end), re.DOTALL)
        matches = pattern.findall(text)
        if len(matches) != 1:
            raise MemoryError(f"lessons requires one {key} region")
        try:
            value = json.loads(matches[0])
        except json.JSONDecodeError as error:
            raise MemoryError(f"invalid {key} lessons JSON") from error
        if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
            raise MemoryError(f"invalid {key} lessons")
        state[key] = value
    candidate_fields = set(load_contract()["lessons"]["candidate_fields"])
    active_fields = set(load_contract()["lessons"]["active_fields"])
    for candidate in state["candidates"]:
        if set(candidate) != candidate_fields or not isinstance(candidate.get("fingerprint"), str) \
                or not isinstance(candidate.get("count"), int) or isinstance(candidate.get("count"), bool) \
                or not isinstance(candidate.get("evidence"), list):
            raise MemoryError("invalid candidate lesson fields")
        _tags(candidate.get("tags"))
        evidence = [_evidence(item) for item in candidate["evidence"]]
        if candidate["count"] != len({item["attempt"] for item in evidence}) \
                or candidate["count"] != len(evidence):
            raise MemoryError("candidate lesson count does not match distinct attempts")
    for lesson in state["active"]:
        _active_lesson(lesson, active_fields)
    return state


def _tags(value: Any) -> dict[str, list[str]]:
    fields = load_contract()["lessons"]["tag_fields"]
    if not isinstance(value, dict) or set(value) != set(fields):
        raise MemoryError("lesson tags fields")
    if not all(isinstance(value[field], list) and all(isinstance(item, str) and item for item in value[field]) for field in fields):
        raise MemoryError("lesson tags values")
    return {field: sorted(set(value[field])) for field in fields}


def _evidence(value: Any) -> dict[str, str]:
    if not isinstance(value, dict) or set(value) != {"attempt", "detail"} \
            or not all(isinstance(value[field], str) and value[field].strip() for field in value):
        raise MemoryError("lesson evidence fields")
    return value


def _active_lesson(value: Any, fields: set[str] | None = None) -> dict[str, Any]:
    expected = fields or set(load_contract()["lessons"]["active_fields"])
    if not isinstance(value, dict) or set(value) != expected \
            or not isinstance(value.get("evidence"), list):
        raise MemoryError("invalid active lesson fields")
    value = json.loads(json.dumps(value))
    value["tags"] = _tags(value.get("tags"))
    for field in expected - {"tags", "evidence"}:
        if not isinstance(value[field], str) or not value[field].strip():
            raise MemoryError("active lesson fields must be nonempty strings")
    if not value["evidence"]:
        raise MemoryError("active lesson evidence is incomplete")
    value["evidence"] = [_evidence(item) for item in value["evidence"]]
    return value


def _active_from_event(event: dict[str, Any]) -> dict[str, Any]:
    required = set(load_contract()["lessons"]["active_fields"]) - {"id", "evidence"}
    if any(not isinstance(event.get(field), str) or not event[field].strip() for field in required - {"tags"}):
        raise MemoryError("active lesson evidence is incomplete")
    evidence = _evidence(event.get("evidence"))
    fingerprint = event.get("fingerprint")
    if not isinstance(fingerprint, str) or not fingerprint:
        raise MemoryError("lesson fingerprint")
    return {
        "id": "L-" + hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()[:10].upper(),
        "title": event["title"],
        "tags": _tags(event["tags"]),
        "trigger": event["trigger"],
        "symptom": event["symptom"],
        "root_cause": event["root_cause"],
        "required_action": event["required_action"],
        "verification": event["verification"],
        "evidence": [evidence],
    }


def update_lessons(state: dict[str, list[dict[str, Any]]], event: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    result = json.loads(json.dumps(state))
    action = event.get("action")
    if action == "delete":
        lesson_id = event.get("id")
        result["active"] = [item for item in result["active"] if item.get("id") != lesson_id]
        result["candidates"] = [item for item in result["candidates"] if item.get("fingerprint") != event.get("fingerprint")]
        return result
    if action == "update":
        lesson = _active_lesson(event.get("lesson"))
        matches = [index for index, item in enumerate(result["active"]) if item.get("id") == lesson["id"]]
        if len(matches) != 1:
            raise MemoryError("updated lesson id is not active")
        result["active"][matches[0]] = lesson
        return result
    if action != "record" or event.get("verified") is not True:
        return result
    # AC-LES-2: pre-write dedup. An exact match against an active lesson is the same
    # knowledge — merge by keeping the existing record instead of adding a duplicate.
    # (A same-fingerprint candidate is a recurrence attempt and is handled below.)
    lookup = lesson_duplicate_lookup(result, event)
    if lookup["decision"] == "duplicate-active":
        return result
    active = _active_from_event(event)
    if any(item.get("id") == active["id"] for item in result["active"]):
        return result
    if event.get("high_cost") is True:
        result["active"].append(active)
        return result
    if event.get("potentially_recurring") is not True:
        return result
    fingerprint = event["fingerprint"]
    candidate = next((item for item in result["candidates"] if item.get("fingerprint") == fingerprint), None)
    evidence = event["evidence"]
    if candidate is None:
        candidate = {"fingerprint": fingerprint, "tags": active["tags"], "count": 0, "evidence": []}
        result["candidates"].append(candidate)
    attempts = {item.get("attempt") for item in candidate["evidence"]}
    if evidence["attempt"] not in attempts:
        candidate["evidence"].append(evidence)
        candidate["count"] = len(candidate["evidence"])
    if candidate["count"] >= load_contract()["lessons"]["recurrence_attempts"]:
        active["evidence"] = candidate["evidence"]
        result["candidates"].remove(candidate)
        result["active"].append(active)
    return result


def select_lessons(state: dict[str, list[dict[str, Any]]], query: dict[str, Any]) -> list[dict[str, Any]]:
    wanted = _tags(query)
    return [
        lesson for lesson in state["active"]
        if any(set(lesson["tags"][field]) & set(wanted[field]) for field in wanted)
    ]


# AC-LES-2: before recording a lesson, look it up to avoid piling up duplicates. An
# exact fingerprint hit means "same knowledge already recorded"; a near hit (high tag
# and text similarity) means "similar knowledge exists — review before adding".
LESSON_NEAR_THRESHOLD = 0.5


def _lesson_text(entry: dict[str, Any]) -> str:
    return " ".join(str(entry.get(k, "")) for k in ("title", "trigger", "symptom", "root_cause"))


def lesson_duplicate_lookup(
    state: dict[str, list[dict[str, Any]]], event: dict[str, Any],
) -> dict[str, Any]:
    """Pre-write dedup advisory: exact active match, else near-match candidates (AC-LES-2).

    An exact fingerprint that is already an *active* lesson is the same knowledge —
    merge instead of adding. A same-fingerprint *candidate* is a recurring attempt, not
    a duplicate, so it is not reported here (the recurrence path counts it). Near matches
    (overlapping tags) are reported so the caller can review before adding a duplicate.
    """
    fingerprint = event.get("fingerprint")
    if not isinstance(fingerprint, str) or not fingerprint:
        raise MemoryError("lesson fingerprint")
    active = _active_from_event(event)
    tags = _tags(event.get("tags"))
    near: list[dict[str, Any]] = []
    for lesson in state["active"]:
        if lesson.get("id") == active["id"] or lesson.get("fingerprint") == fingerprint:
            return {"decision": "duplicate-active", "match_id": lesson["id"], "near": []}
        overlap = sum(len(set(lesson["tags"][field]) & set(tags[field])) for field in tags)
        total = sum(len(set(tags[field])) for field in tags) or 1
        tag_score = overlap / total
        if tag_score >= LESSON_NEAR_THRESHOLD:
            near.append({"id": lesson["id"], "score": round(tag_score, 3)})
    near.sort(key=lambda item: (-item["score"], item["id"]))
    return {"decision": "near-match" if near else "new", "match_id": None, "near": near}


def inspect_lessons(target: Path, event: dict[str, Any], *, actor: str) -> dict[str, Any]:
    path = target / "ai/lessons.md"
    source = _safe_file(path, required=True)
    digest = _digest("lessons", source, event)
    if actor != "primary":
        return {"decision": "forbidden-writer", "write_allowed": False, "plan_digest": digest}
    rendered = render_lessons(update_lessons(parse_lessons(source), event))
    return {"decision": "current" if rendered == source else "update", "write_allowed": False, "plan_digest": digest, "changed": rendered != source}


def apply_lessons(target: Path, event: dict[str, Any], expected_digest: str, *, actor: str) -> dict[str, Any]:
    preview = inspect_lessons(target, event, actor=actor)
    if preview["decision"] not in {"update", "current"} or preview["plan_digest"] != expected_digest:
        raise MemoryError("lessons update is not writable or digest changed")
    path = target / "ai/lessons.md"
    source = _safe_file(path, required=True)
    rendered = render_lessons(update_lessons(parse_lessons(source), event))
    if rendered != source:
        _atomic_write(path, rendered, stat.S_IMODE(path.stat().st_mode))
    return {**preview, "applied": rendered != source, "write_allowed": True}


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Manage MTP project maps and lessons",
        epilog="Use `template` to print a fill-in skeleton for the project map (G-1).",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command, argument in (("sync", "projection"), ("lessons", "event")):
        item = subparsers.add_parser(command)
        item.add_argument("--target", type=Path, required=True)
        item.add_argument(f"--{argument}", type=Path, required=True)
        item.add_argument("--actor", required=True)
        item.add_argument("--apply", action="store_true")
        item.add_argument("--check-only", action="store_true", help="Preview only, never write")
        item.add_argument("--expect-plan-digest")
        if command == "sync":
            item.add_argument("--explicit-request", action="store_true")
    select = subparsers.add_parser("select")
    select.add_argument("--target", type=Path, required=True)
    select.add_argument("--query", type=Path, required=True)
    subparsers.add_parser("template", help="Print a fill-in project-map skeleton")
    lint = subparsers.add_parser("lint", help="Read-only map-quality lint (L-017; warns only)")
    lint.add_argument("--target", type=Path, required=True)
    lint.add_argument("--max-bytes", type=int, default=SECTION_MAX_BYTES)
    lint.add_argument("--min-bytes", type=int, default=SECTION_MIN_BYTES)
    lint.add_argument("--name-title", choices=NAME_TITLE_MODES, default=NAME_TITLE_ENFORCEMENT)
    status = subparsers.add_parser("status", help="Read-only map readiness and staleness")
    status.add_argument("--target", type=Path, required=True)
    rotate_parser = subparsers.add_parser(
        "rotate", help="Move an MTP:ROT segment into an archive file (L-031 L2)",
    )
    rotate_parser.add_argument("--target", type=Path, required=True)
    rotate_parser.add_argument("--segment", required=True)
    rotate_parser.add_argument("--to", required=True)
    rotate_parser.add_argument("--preview", action="store_true")
    rotate_parser.add_argument("--apply", action="store_true")
    rotate_parser.add_argument("--version")
    rotate_parser.add_argument("--preview-at")
    rotate_parser.add_argument("--expect-digest")
    budget_parser = subparsers.add_parser(
        "budget", help="L0 budget report (read-only unless --record is given)",
    )
    budget_parser.add_argument("--target", type=Path, required=True)
    budget_parser.add_argument("--previous", type=Path)
    budget_parser.add_argument("--record", type=Path)
    budget_parser.add_argument("--version")
    budget_parser.add_argument("--text", action="store_true")
    refresh = subparsers.add_parser(
        "sync-current-state", help="Regenerate Current State from ai/NEXT.md (sole writer)",
    )
    refresh.add_argument("--target", type=Path, required=True)
    refresh.add_argument("--actor", default="primary")
    refresh.add_argument("--apply", action="store_true")
    try:
        args = parser.parse_args()
        if args.command == "template":
            print(json.dumps(project_map_template(), ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            return 0
        if args.command == "lint":
            target = args.target.resolve()
            text = _safe_file(target / "CLAUDE.md", required=True).decode("utf-8")
            print(json.dumps(
                map_lint(
                    text, budget_max=args.max_bytes, budget_min=args.min_bytes, scan=True,
                    project_root=target, title=target.name, name_title=args.name_title,
                ),
                ensure_ascii=False, sort_keys=True,
            ))
            return 0
        if args.command == "status":
            print(json.dumps(map_status(args.target.resolve()), ensure_ascii=False, sort_keys=True))
            return 0
        if args.command == "budget":
            previous = _json_file(args.previous) if args.previous else None
            report = budget_report(args.target, previous=previous, version=args.version)
            if args.record:
                args.record.parent.mkdir(parents=True, exist_ok=True)
                _atomic_write(
                    args.record,
                    (json.dumps(report, ensure_ascii=False, sort_keys=True, indent=1) + "\n").encode("utf-8"),
                    0o644,
                )
            if args.text:
                for item in report["suggestions"]:
                    suffix = " (escalate)" if item["escalate"] else ""
                    print(f"  warn: {item['key']}{suffix}")
                print(
                    f"  bytes={report['total_bytes']}/{report['total_budget']} "
                    f"open={report['backlog']['open_count']}/{report['backlog']['warn']}"
                )
                return 0
            print(json.dumps(report, ensure_ascii=False, sort_keys=True))
            return 0
        if args.command == "rotate":
            if args.preview and args.apply:
                print("project-memory-error: choose --preview or --apply", file=sys.stderr)
                return 2
            result = rotate(
                args.target, segment=args.segment, destination=args.to, apply=args.apply,
                version=args.version, preview_at=args.preview_at,
                expect_digest=args.expect_digest,
            )
            print(json.dumps(result, ensure_ascii=False, sort_keys=True))
            return 0
        if args.command == "sync-current-state":
            target = args.target.resolve()
            if args.apply:
                result = apply_current_state(target, actor=args.actor)
            else:
                body = current_state_from_next(
                    _safe_file(target / "ai/NEXT.md", required=True).decode("utf-8"))
                result = {"sections": {CURRENT_STATE_SECTION: body}, "write_allowed": False}
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            return 0
        target = args.target.resolve()
        write = getattr(args, "apply", False) and not getattr(args, "check_only", False)
        if args.command == "sync":
            payload = _json_file(args.projection)
            if write:
                result = apply_sync(target, payload, args.expect_plan_digest or "", explicit=args.explicit_request, actor=args.actor)
            else:
                result = inspect_sync(target, payload, explicit=args.explicit_request, actor=args.actor)
        elif args.command == "lessons":
            payload = _json_file(args.event)
            if write:
                result = apply_lessons(target, payload, args.expect_plan_digest or "", actor=args.actor)
            else:
                result = inspect_lessons(target, payload, actor=args.actor)
        else:
            state = parse_lessons(_safe_file(target / "ai/lessons.md", required=True))
            result = {"lessons": select_lessons(state, _json_file(args.query)), "write_allowed": False}
    except (MemoryError, OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        print(f"project-memory-error: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
