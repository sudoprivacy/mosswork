---
name: skillhub-skill-bili-main-food
description: "当用户想按 B 站「美食」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：美食、B站分区、rid 211。"
---

# B 站分区 · 美食

- 一级分区 rid：`211`；网页路由：`/v/food/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 97 条榜单条目，覆盖 5 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 田园美食 | 1 | 6 | 214 |
| 美食侦探 | 29 | 10 | 212 |
| 美食制作 | 26 | 8 | 76 |
| 美食测评 | 10 | 10 | 213 |
| 美食记录 | 31 | 10 | 215 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 田园美食

数据来源：二级分区 7 日榜，可用 6 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 西班牙抓红魔虾，一只200元，今天能赚多少钱？ | Yooupi食途 | [BV1NQR9YgEP2](https://www.bilibili.com/video/BV1NQR9YgEP2) | 280.2 万 |
| 华农兄弟：翻山越岭挖苦笋，只为喝口苦笋老鸭汤 | 华农兄弟 | [BV11ERqYoE4D](https://www.bilibili.com/video/BV11ERqYoE4D) | 95.4 万 |
| 大庆赶海，退潮后发现大海螺吸在石头上吃生蚝，还有一片海菜地 | 大庆赶海 | [BV1izR2YNEGm](https://www.bilibili.com/video/BV1izR2YNEGm) | 188.1 万 |
| 10块买了一桶方便面，带回营地烧烤可乐泡面，配上鸡腿太好吃了 | 肉吃面条 | [BV11XR9YBE7Y](https://www.bilibili.com/video/BV11XR9YBE7Y) | 253.1 万 |
| 春天里绝望的钓鱼佬 | 荷塘星星 | [BV1C6R1YyEmA](https://www.bilibili.com/video/BV1C6R1YyEmA) | 18.2 万 |

### 美食侦探

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 398一碗面我到底是不是大冤种 | 小李有点饿01 | [BV1Z3R1YeEus](https://www.bilibili.com/video/BV1Z3R1YeEus) | 346.6 万 |
| 断更半个月的时间里，我想做点不一样的事情 | 老王在中国 | [BV1UVdpYZEhC](https://www.bilibili.com/video/BV1UVdpYZEhC) | 309.0 万 |
| 上海夜晚的碳水快乐！15元爆辣鸡杂面，草莓10元三斤！ | 盗月社食遇记 | [BV1JZZmYQEM3](https://www.bilibili.com/video/BV1JZZmYQEM3) | 224.7 万 |
| 打破27秒吃面纪录赢奖金1288元！同时挑战全马破四，一次打破双纪录，能成功吗？ | 橙飞一下 | [BV1PsZ2YxEcJ](https://www.bilibili.com/video/BV1PsZ2YxEcJ) | 285.1 万 |
| 上海新餐厅，癫出新高度。人均4k吃大象粑粑，臭味糊糊，啃树叶舔冰块，这顿饭抽象得我想退钱 | 米雪食记 | [BV1NoR2YXECu](https://www.bilibili.com/video/BV1NoR2YXECu) | 194.1 万 |

### 美食制作

数据来源：二级分区 7 日榜，可用 8 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【兰州牛肉面】老板来碗牛肉面，不要面 | 我的样子平平无奇 | [BV1MdZyY4ENX](https://www.bilibili.com/video/BV1MdZyY4ENX) | 286.7 万 |
| 比起玩皇室战争，观众更想看煮意大利面 | 塔米糕ovo | [BV1dcZZY6EgS](https://www.bilibili.com/video/BV1dcZZY6EgS) | 269.5 万 |
| 什么叫非遗：一连7天都不软不塌！还酥得掉渣！ | 绵羊料理 | [BV1QxRfYaEBR](https://www.bilibili.com/video/BV1QxRfYaEBR) | 355.2 万 |
| 这个汉堡……是假的 | 梧萌 | [BV1NkRBYcEKw](https://www.bilibili.com/video/BV1NkRBYcEKw) | 514.5 万 |
| 三十块搞定的家庭版麻辣烤鱼，麻麻辣辣肉也很嫩，味道不差外面的。 | 吃不胖的放心 | [BV1YAZGYkEWY](https://www.bilibili.com/video/BV1YAZGYkEWY) | 378.9 万 |

### 美食测评

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 网上爆火的大锅卤菜，味道真的好吃吗？帅小伙重金尝试！ | 记录生活的蛋黄派 | [BV1yuZSYPE6J](https://www.bilibili.com/video/BV1yuZSYPE6J) | 433.0 万 |
| 终于买到鲜活东北林蛙了！！满肚子的籽太香了！！！ | 大祥哥来了 | [BV146dHYHEeQ](https://www.bilibili.com/video/BV146dHYHEeQ) | 163.1 万 |
| 曾经4年狂开7000家店的塔斯汀，如今为啥吃的人不多了？ | 馋大鑫 | [BV1awR2Y8EhG](https://www.bilibili.com/video/BV1awR2Y8EhG) | 321.5 万 |
| 小伙北京出租屋自律生活，终于吃上淄博烧烤啦 | 咸鱼梦想家vlog | [BV1vNZ2YuE7w](https://www.bilibili.com/video/BV1vNZ2YuE7w) | 278.6 万 |
| 爆辣死神鬼椒面！220w超高辣度，广东辣王挑战成功！ | 赛亚人阿廖 | [BV1eHZoYMERE](https://www.bilibili.com/video/BV1eHZoYMERE) | 479.6 万 |

### 美食记录

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 《广州美食不完全攻略》 | 李哥我饿了 | [BV1oFRzYmE9T](https://www.bilibili.com/video/BV1oFRzYmE9T) | 177.6 万 |
| 来看一个300万博主，开的烧烤店一天能挣多少钱？ | 胖龙的小生活 | [BV1LwZ2Y3EdW](https://www.bilibili.com/video/BV1LwZ2Y3EdW) | 372.3 万 |
| 又接到调戏女主角的戏了，今天跟蒋老师一起演，女主角都被吓坏了 | 张二要自律 | [BV1TXR2YxEzH](https://www.bilibili.com/video/BV1TXR2YxEzH) | 454.8 万 |
| 第一次在芬兰摆新疆硬核牛羊盛宴！西域美食征服芬英老外胃！拉条子烤包子碳烤羊肉串香晕全场抢破头！ | 雨琪在芬兰 | [BV13tRmYaE6r](https://www.bilibili.com/video/BV13tRmYaE6r) | 166.6 万 |
| 老外丢掉的牛胸油能掀起多大风浪？速来看我炸厨房！ | 西班牙陈挺 | [BV14vZ1YfE9r](https://www.bilibili.com/video/BV14vZ1YfE9r) | 171.9 万 |

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=211." https://api.bilibili.com/x/web-interface/ranking/v2?rid=211&type=all. Accessed 6 Nov. 2026.
