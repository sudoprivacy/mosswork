#!/usr/bin/env python3
"""
MCP Streamable HTTP client for image-to-image skill.
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
import uuid

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
CONFIG_PATH = os.path.join(SKILL_DIR, "skill-config.json")
SESSION_FILE = os.path.join(SCRIPT_DIR, ".mcp_session_id")


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def resolve_server_url(arg_url):
    url = arg_url or load_config().get("mcpServerUrl", "")
    if not url:
        raise SystemExit("未配置 mcpServerUrl")
    return url if url.endswith("/") else url + "/"


def get_sk():
    sk = os.environ.get("DAGENT_IMAGE_API_KEY", "")
    if not sk:
        raise SystemExit("未读取到环境变量 DAGENT_IMAGE_API_KEY")
    return sk


def build_jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": str(uuid.uuid4())[:8], "method": method}
    if params is not None:
        payload["params"] = params
    return payload


def read_sse_response(resp):
    while True:
        line = resp.readline().decode("utf-8", errors="replace").strip()
        if not line:
            break
        if line.startswith("data:"):
            data = line[5:].strip()
            if data.startswith("{"):
                return data
    return ""


def send_request(url, payload, session_id=None):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
    }
    if session_id:
        headers["Mcp-Session-Id"] = session_id

    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            new_sid = resp.headers.get("Mcp-Session-Id")
            content_type = resp.headers.get("Content-Type", "")
            if "text/event-stream" in content_type:
                return read_sse_response(resp), new_sid
            return resp.read().decode("utf-8"), new_sid
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace") if e.fp else ""
        print(json.dumps({"error": f"HTTP {e.code}: {e.reason}", "detail": detail}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(json.dumps({"error": str(e.reason)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)


def save_session_id(session_id):
    if session_id:
        with open(SESSION_FILE, "w", encoding="utf-8") as f:
            f.write(session_id)


def load_session_id():
    if os.path.exists(SESSION_FILE):
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip() or None
    return None


def clear_session_id():
    if os.path.exists(SESSION_FILE):
        try:
            os.remove(SESSION_FILE)
        except OSError:
            pass


def ensure_session(url):
    session_id = load_session_id()
    if session_id:
        try:
            body, new_sid = send_request(url, build_jsonrpc("tools/list"), session_id)
            if "result" in json.loads(body):
                if new_sid:
                    save_session_id(new_sid)
                    return new_sid
                return session_id
        except Exception:
            clear_session_id()

    clear_session_id()
    body, new_sid = send_request(url, build_jsonrpc("initialize", {
        "protocolVersion": "2024-11-05",
        "capabilities": {},
        "clientInfo": {"name": "dagent-image-to-image-client", "version": "1.0.0"},
    }))
    if new_sid:
        save_session_id(new_sid)
        send_request(url, {"jsonrpc": "2.0", "method": "notifications/initialized"}, new_sid)
        return new_sid
    return None


def unwrap_mcp_response(raw):
    if not isinstance(raw, dict):
        return raw
    if "result" in raw and isinstance(raw["result"], dict):
        content = raw["result"].get("content", [])
        if content and isinstance(content[0], dict) and "text" in content[0]:
            text = content[0]["text"]
            if raw["result"].get("isError"):
                return {"code": 500, "msg": text, "result": None}
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"code": 200, "msg": "", "result": text}
    return raw


def call_tool(url, session_id, tool_name, params):
    payload = build_jsonrpc("tools/call", {"name": tool_name, "arguments": params})
    body, new_sid = send_request(url, payload, session_id)
    if new_sid:
        save_session_id(new_sid)
        session_id = new_sid
    return unwrap_mcp_response(json.loads(body)), session_id


def cmd_call(args):
    url = resolve_server_url(args.server_url)
    session_id = ensure_session(url)
    params = {}
    if args.params_file:
        # utf-8-sig: 自动兼容 Windows PowerShell 写出的带 BOM 文件
        with open(args.params_file, "r", encoding="utf-8-sig") as f:
            params = json.load(f)
    elif args.params:
        if args.params.startswith("@"):
            with open(args.params[1:], "r", encoding="utf-8-sig") as f:
                params = json.load(f)
        else:
            params = json.loads(args.params)
    if args.with_sk:
        rule = params.setdefault("rule", {})
        rule["sk"] = get_sk()
    result, _ = call_tool(url, session_id, args.tool_name, params)
    print(json.dumps(result, ensure_ascii=False), flush=True)


def cmd_poll(args):
    url = resolve_server_url(args.server_url)
    session_id = ensure_session(url)
    deadline = time.time() + args.timeout
    last_result = None
    while time.time() <= deadline:
        result, session_id = call_tool(url, session_id, "get_generate_result", {"rule": {"taskId": args.task_id}})
        last_result = result
        status = result.get("status") if isinstance(result, dict) else None
        if status in ("success", "failed"):
            print(json.dumps(result, ensure_ascii=False), flush=True)
            return
        time.sleep(args.interval)
    print(json.dumps({"status": "failed", "msg": "轮询超时", "result": last_result}, ensure_ascii=False), flush=True)


def main():
    parser = argparse.ArgumentParser(description="MCP image-to-image client")
    subparsers = parser.add_subparsers(dest="command")

    call_parser = subparsers.add_parser("call")
    call_parser.add_argument("tool_name")
    call_parser.add_argument("--params", default=None)
    call_parser.add_argument("--params-file", dest="params_file", default=None)
    call_parser.add_argument("--server-url", dest="server_url", default=None)
    call_parser.add_argument("--with-sk", action="store_true")

    poll_parser = subparsers.add_parser("poll")
    poll_parser.add_argument("task_id")
    poll_parser.add_argument("--server-url", dest="server_url", default=None)
    poll_parser.add_argument("--timeout", type=int, default=600)
    poll_parser.add_argument("--interval", type=int, default=5)

    args = parser.parse_args()
    if args.command == "call":
        cmd_call(args)
    elif args.command == "poll":
        cmd_poll(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
