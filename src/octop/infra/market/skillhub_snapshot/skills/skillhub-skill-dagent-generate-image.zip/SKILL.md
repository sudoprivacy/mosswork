---
name: skillhub-skill-dagent-generate-image
description: ">"
---

# DAgent 图片生成

支持两种模式：

- **文生图**：根据用户输入的图片需求生成提示词，调用 MCP `generate_image_task`。
- **图生图**：根据用户提供的参考图片和编辑要求，先上传图片，再调用 MCP `generate_detail_task`。

两种模式提交任务后，都使用 `get_generate_result` 轮询任务结果并展示生成图片。

---

## MCP 服务配置

| 配置项 | 说明 |
|--------|------|
| 配置文件 | 当前技能目录下的 `skill-config.json` |
| MCP 地址 | 读取当前技能目录下 `skill-config.json` 的 `mcpServerUrl` 值 |
| 调用脚本 | `scripts/call_mcp.py` |
| SK 来源 | Windows：PowerShell `$env:DAGENT_IMAGE_API_KEY`；macOS：zsh/bash `$DAGENT_IMAGE_API_KEY` |

运行前必须根据当前操作系统读取并确认环境变量 `DAGENT_IMAGE_API_KEY` 存在。不得要求用户提供密钥，也不得在输出中展示密钥。若不存在，停止流程并提示用户：

```text
未读取到环境变量 DAGENT_IMAGE_API_KEY，请先配置后再生成图片。
```

---

## 触发条件

当用户输入满足以下任一场景时，必须使用此技能：

- 需要根据文字生成图片、AI 绘图、商品图、详情图或海报图
- 需要基于参考图生成图片、进行图片编辑或制作电商素材
- 用户描述了图片主体、场景、风格、构图、尺寸比例等生成要求
- 用户要求为淘宝、天猫、京东、拼多多、抖音、小红书、亚马逊等电商平台生成图片素材

---

## 参数提取规则

先根据用户是否提供参考图片选择生成模式：

- 提供本地图片、上传图片或公网图片 URL：使用图生图流程。
- 未提供参考图片：使用文生图流程。

### 文生图参数

用于 `generate_image_task`：

| 目标字段 | 来源 | 说明 |
|----------|------|------|
| `prompt` | 用户输入文本 | 将用户的图片需求整理为生成图片的提示词，包含主体、场景、风格、构图和其他要求 |
| `sizeRatio` | 用户输入文本中的图片尺寸 | 解析 `1:1`、`3:4`、`4:3`、`9:16`、`16:9` 等比例；未解析到时传空值 |
| `sk` | 系统环境变量 | Windows 读取 `$env:DAGENT_IMAGE_API_KEY`，macOS 读取 `$DAGENT_IMAGE_API_KEY`，由 `--with-sk` 注入 |

### 图生图参数

用于 `generate_detail_task`：

| 目标字段 | 来源 | 说明 |
|----------|------|------|
| `sizeRatio` | 用户输入中的尺寸比例 | 例如 `1:1`、`3:4`、`4:3`、`9:16`、`16:9`；未提供时传空值 |
| `language` | 用户输入 | 生成语言；未提供时传空值 |
| `productInformation` | 用户输入 | 商品、场景、风格、卖点和详情图要求；未提供时传空值 |
| `modulesNum` | 用户输入 | 正整数；未提供时默认 `1` |
| `platform` | 用户输入 | 目标电商平台；未提供时传空值 |
| `imageUrls` | 图片上传结果 | 使用 `upload_oss` 返回的 `result`；多张参考图需逐张上传 |
| `sk` | 系统环境变量 | Windows 读取 `$env:DAGENT_IMAGE_API_KEY`，macOS 读取 `$DAGENT_IMAGE_API_KEY`，由 `--with-sk` 注入 |

---

## 工作流程

### 第一步：根据操作系统检查环境变量

#### Windows（PowerShell）

```powershell
$dagentImageApiKey = $env:DAGENT_IMAGE_API_KEY
if ([string]::IsNullOrWhiteSpace($dagentImageApiKey)) {
    throw "未读取到环境变量 DAGENT_IMAGE_API_KEY，请先配置后再生成图片。"
}
```

#### macOS（zsh/bash）

```bash
if [ -z "${DAGENT_IMAGE_API_KEY:-}" ]; then
  echo "未读取到环境变量 DAGENT_IMAGE_API_KEY，请先配置后再生成图片。" >&2
  exit 1
fi
```

后续命令必须在完成检查的同一个终端会话中执行。`--with-sk` 会通过 Python 的 `os.environ.get("DAGENT_IMAGE_API_KEY")` 读取当前进程继承的环境变量并注入 `rule.sk`。不得输出密钥值。若不存在，停止流程并提示用户：

```text
未读取到环境变量 DAGENT_IMAGE_API_KEY，请先配置后再生成图片。
```

### 临时参数文件刷新规则（强制）

每次使用 `--params-file` 调用 MCP 前，必须严格按以下顺序处理对应的临时参数文件：

1. 确定本次调用对应的参数文件路径，只删除该确切路径上的旧文件。
2. 基于当前用户输入以及本次流程刚取得的结果，重新构造完整参数，并一次性写入新的 JSON 文件；禁止追加内容或复用上一次调用的文件内容。
3. 重新读取并解析该 JSON，确认文件有效且字段值来自本次请求。若删除、写入或校验失败，立即停止，不得调用 MCP。
4. 校验通过后立即调用对应 MCP 工具，期间不得用其他请求覆盖该参数文件。

删除旧文件可按当前操作系统执行。将示例文件名替换为本次调用实际使用的参数文件名：

#### Windows（PowerShell）

```powershell
$paramsFile = "_upload_oss_params.json"
Remove-Item -LiteralPath $paramsFile -Force -ErrorAction SilentlyContinue
```

#### macOS（zsh/bash）

```bash
params_file="_upload_oss_params.json"
rm -f -- "$params_file"
```

此规则适用于 `_upload_oss_params.json`、`_generate_image_task_params.json` 和 `_generate_detail_task_params.json`。`get_generate_result` 的 `poll` 命令不使用临时参数文件，无需执行此步骤。

### 第二步：获取图生图参考图片

仅在用户提供参考图片时执行此步骤。

| 情况 | 处理方式 |
|------|----------|
| 用户提供本地图片路径 | 读取图片文件并转换为 Base64 |
| 用户上传图片 | 读取上传图片并转换为 Base64 |
| 用户提供公网图片 URL | 若无法直接转 Base64，则先下载到本地临时文件后转换 |

先按“临时参数文件刷新规则”删除旧的 `_upload_oss_params.json`，再将本次图片的 Base64 写入同名新文件：

```json
{
  "rule": {
    "imageBase64": "<图片base64>"
  }
}
```

调用 MCP 工具 `upload_oss`，通过 `--with-sk` 注入环境变量。以下命令在 Windows PowerShell 和 macOS zsh/bash 中通用：

```shell
python scripts/call_mcp.py call upload_oss --params-file _upload_oss_params.json --with-sk
```

`code == 200` 且 `result` 不为空时，记录 `result` 作为 `imageUrls`；否则展示 `msg` 并终止流程。

### 第三步：提交生成图片任务

#### 文生图

无参考图片时，先按“临时参数文件刷新规则”删除旧的 `_generate_image_task_params.json`，再根据本次用户输入写入同名新文件：

```json
{
  "rule": {
    "prompt": "<根据用户输入整理的图片生成提示词>",
    "sizeRatio": "<解析出的尺寸比例，未解析到时为空>"
  }
}
```

调用 MCP 工具 `generate_image_task`。脚本会通过 `--with-sk` 自动读取环境变量并写入 `rule.sk`：

```shell
python scripts/call_mcp.py call generate_image_task --params-file _generate_image_task_params.json --with-sk
```

> 参数文件可不包含 `sk`，`--with-sk` 会自动注入到 `rule.sk`。

返回格式：

```json
{
  "code": 200,
  "msg": "请求成功",
  "result": ""
}
```

`result` 为任务 ID。

| 情况 | 处理方式 |
|----------|------|
| `code == 200` 且 `result` 不为空 | 记录 `result` 作为 `taskId`，进入轮询流程 |
| `code != 200` 或 `result` 为空 | 展示 `msg`，并终止流程 |

#### 图生图

有参考图片时，先按“临时参数文件刷新规则”删除旧的 `_generate_detail_task_params.json`，再将本次用户输入的图生图要求和本次上传返回的图片 URL 写入同名新文件：

```json
{
  "rule": {
    "sizeRatio": "<解析出的尺寸比例，未解析到时为空>",
    "language": "<生成语言，未提供时为空>",
    "productInformation": "<用户对商品、场景、风格、卖点和详情图的要求>",
    "modulesNum": 1,
    "platform": "<目标电商平台，未提供时为空>",
    "imageUrls": ["<upload_oss返回的图片URL>"]
  }
}
```

调用 MCP 工具 `generate_detail_task`，通过 `--with-sk` 注入环境变量：

```shell
python scripts/call_mcp.py call generate_detail_task --params-file _generate_detail_task_params.json --with-sk
```

返回格式：

```json
{
  "code": 200,
  "msg": "请求成功",
  "result": ""
}
```

`result` 为任务 ID。`code == 200` 且 `result` 不为空时进入轮询；否则展示 `msg` 并终止流程。

### 第四步：轮询生成结果

调用 MCP 工具 `get_generate_result`：

```shell
python scripts/call_mcp.py poll <taskId> --timeout 600 --interval 5
```

等价 MCP 参数：

```json
{
  "rule": {
    "taskId": "<对应生成任务返回的result>"
  }
}
```

轮询规则：

| 配置 | 值 |
|------|----|
| 超时时间 | 10 分钟（600 秒） |
| 轮询间隔 | 5 秒 |
| `status == running` | 继续轮询 |
| `status == success` | 展示 `imageInfos` 中所有 `ossImageUrl` 图片 |
| `status == failed` | 展示失败原因 |

返回格式：

```json
{
  "status": "",
  "imageInfos": [
    {
      "ossImageUrl": "",
      "imageStatus": ""
    }
  ]
}
```

---

## 输出格式

### 生成成功

必须提取 `imageInfos` 中每个非空的 `ossImageUrl`，并直接使用 `MEDIA:` 前缀逐行渲染。不得使用 Markdown 图片语法，不得只输出普通 URL：

```text
MEDIA:<ossImageUrl1>
MEDIA:<ossImageUrl2>
```

### 生成失败

优先展示接口返回的失败原因：

```text
图片生成失败：<失败原因>
```

若 `imageInfos` 中存在失败项，可补充展示对应图片状态。

### 轮询超时

```text
图片生成超时，请稍后使用任务 ID 查询结果：<taskId>
```

---

## 注意事项（执行时必须遵守）

1. 必须根据操作系统读取 `DAGENT_IMAGE_API_KEY`：Windows 使用 PowerShell 的 `$env:DAGENT_IMAGE_API_KEY`，macOS 使用 zsh/bash 的 `$DAGENT_IMAGE_API_KEY`。禁止要求用户提供密钥，禁止在命令、参数文件、日志或回复中明文输出密钥；未读取到密钥时必须立即停止生成流程并提示用户配置环境变量。
2. 环境变量检查和 Python 调用必须在同一个终端会话中执行，确保子进程可以通过 `os.environ.get("DAGENT_IMAGE_API_KEY")` 读取密钥。
3. 每次通过 `--params-file` 调用 MCP 前，必须先删除对应的旧临时参数文件，再使用本次请求的最新数据完整重写并校验；禁止追加或复用旧参数。删除、写入或校验失败时不得调用 MCP。
4. 生成成功后，必须提取接口返回的每个非空 `ossImageUrl`，并严格以 `MEDIA:<ossImageUrl>` 格式逐行直接渲染。禁止使用 Markdown 图片语法，禁止仅输出普通 URL，也禁止改用其他渲染格式。
5. 上述规则为强制规则，执行本技能的任何步骤时均不得跳过、替换或弱化。
