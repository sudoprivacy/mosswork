# 一键闭环梦之队

> 七角色专家团协作编排：主理人建团调度，六产线成员（代码/内容/视频/OPC治理/技能治理/工具门禁）独立产出、结论为准；L0-L3 免审认证分级（A类永不清零），四 Phase SOP 与协作铁律。Use when 综合性多产线任务需要角色化协作编排时。

> IP 名：一键闭环梦之队 ｜ 产品标识：OPC-SKILL-02

## 适合谁

- 需要「一键闭环梦之队」能力的 OPC 内容创作者与技能工程师。

## 触发方式/触发词

- 在 WorkBuddy 中直接描述上述 Use when 场景即可触发；
- 或命令行按 SKILL.md 的 Instructions 工作流执行。

## 快速开始

1. 阅读 SKILL.md 的 Instructions 工作流；
2. 按需将本技能目录纳入技能库或被主流程引用；
3. 执行后以 SKILL.md 的 Output 模板输出交付物；
4. 执行细节见 references/ 领域清单。

## 文件结构

```
一键闭环梦之队/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── DESIGN.md
├── _meta.json
└── references/
    ├── 一键闭环梦之队-checklist.md
    ├── 一键闭环梦之队-pitfalls.md
    ├── 一键闭环梦之队-templates.md
    └── 一键闭环梦之队-workflow.md
```

## 验证证据

- 结构合规：SCK validate 0 问题；质量审计目标 100%。
- 前置条件满足时按工作流执行；不满足时静默结束或如实标注。

## 安全边界

对外发布、资金、合同、删改生产数据、不可确定性修复一律安全挂起升级人工。

版本: 见 CHANGELOG 首条 ｜ 作者: 灯泡（WorkBuddy OPC）
