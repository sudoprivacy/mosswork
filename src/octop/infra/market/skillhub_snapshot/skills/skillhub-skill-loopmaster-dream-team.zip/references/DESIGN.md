# 一键闭环梦之队 · 设计说明 v1.0.0

> IP 名：一键闭环梦之队 ｜ 产品标识：OPC-SKILL-02

## 系统架构

本技能为单点能力单元：SKILL.md（定义与触发）→ Instructions 工作流（执行）→
Output 模板（交付）。与主流程的关系：被「全链路闭环按推荐执行工作流」等编排层按需调用。

## 文件结构（references 明细）

```text
一键闭环梦之队/
├── references\一键闭环梦之队-checklist.md
├── references\一键闭环梦之队-pitfalls.md
├── references\一键闭环梦之队-templates.md
├── references\一键闭环梦之队-workflow.md
```

- references 清单：
- references\一键闭环梦之队-checklist.md
- references\一键闭环梦之队-pitfalls.md
- references\一键闭环梦之队-templates.md
- references\一键闭环梦之队-workflow.md

## 候选方案对比

| 决策点 | 已采纳 | 已否决 | 否决理由 |
|--------|--------|--------|----------|
| 结构形态 | SCK 六段标准结构 | 自由格式文档 | 自由格式无法机器审计与稳定触发 |
| 文档拆分 | SKILL+README+DESIGN+CHANGELOG 四件套 | 单文件全塞 | 单文件不利于渐进加载与维护追溯 |

## 已知局限

- 边界：不执行真实对外动作（发布/资金/合同/删数据）；超出能力范围的任务应升级人工。
- 本次升级为结构合规级；领域内容深度增强需按业务继续充实 Instructions 段。

## 决策记录

### ADR-001 结构合规优先
先达 SCK 满分结构（可机器复现），再做内容深耕。依据：结构是触发与审计前提。

### ADR-002 SKILL-DESIGN 边界声明
SKILL.md 只承载触发与工作流；设计取舍与决策记录归 DESIGN.md；安装与验证归 README.md。
