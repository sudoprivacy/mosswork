# CHANGELOG

## v1.0.1（2026-09-11）

- P0 整编：frontmatter 补 slug/triggers/template（修 L1 门禁 FAIL）；标题去裸版本号。

## 2026-08-20 · 专家包分装为 SKILL 冲榜版

- 由专家包方法论分装（轻装：无内嵌引擎，纯方法论+四件套）；IP 名：一键闭环梦之队，产品标识：OPC-SKILL-02。

## v1.0.0（2026-08-20）

- 结构合规升级：重构为 SCK 六段结构；补 README/DESIGN/CHANGELOG/文件结构表；
  description 合规化（单行双引号 ≤200 字 + Use when）；validate 0 问题、质量审计满分目标。
- 原始工作流内容保留于 SKILL.md Instructions 段。
