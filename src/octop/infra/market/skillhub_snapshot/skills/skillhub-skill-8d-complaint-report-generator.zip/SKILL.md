---
name: skillhub-skill-8d-complaint-report-generator
description: "从结构化客诉数据一键生成符合客户审阅要求的 8D 报告（Word）。当用户要写客户投诉 8D 报告、D0-D8 整改报告、客诉处理报告、供应商投诉 8D、质量异常 8D 回复时使用。支持缺失项自动生成待确认清单、PPM 不良率计算、签署栏排版，输出可直接提交给客户的 docx。 本技能能力通过按次计费接口提供，接口说明见文末「业务接口说明」章节。"
---

# 客诉 8D 报告生成器

## 何时用

- 客户投诉后需要出一份正式 8D 报告提交客户
- 供应商投诉回复、内部质量异常整改报告
- 需要把已有的客诉记录（Excel/邮件/微信）整理成标准 8D 格式
- 客户审阅退回，要求补齐 D3-D7 某些环节

**不适用**：需要真正做根因分析（本技能只负责报告呈现，分析请配合「质量异常根因分析」技能）；需要跑 SPC 判异。

## 前置条件

```bash
pip install python-docx
```

## 三步工作流

### 第 1 步：收集客诉信息

向用户收集下列信息。**逐项追问，缺一项就记下来，不要自己编**：

| 字段 | 说明 | 必填 |
|---|---|---|
| `comp_code` | 客诉编号，格式 `CS+年月日+序号`，如 CS20261024-01 | ✅ |
| `customer_name` | 客户名称 | ✅ |
| `order_no` | 订单号 | |
| `batch_code` | 关联批次号 | |
| `product_name` / `spec_model` | 产品名称 / 规格型号 | |
| `qty_ng` / `qty_total` | 不良数量 / 交付总数（都给才计算 PPM） | |
| `severity` | 轻微 / 一般 / 严重 / 致命 | ✅ |
| `comp_date` | 客诉日期 YYYY-MM-DD | ✅ |
| `reporter` | 报告人 | |
| `team` | D1 小组构成 | ✅ |
| `problem` | D2 问题描述（现象+数量+范围，**不要写原因**） | ✅ |
| `interim` | D3 临时围堵（隔离/挑选/停线/库存管控） | ✅ |
| `root_cause` | D4 根本原因分析 | ✅ |
| `corrective` | D5 永久纠正措施 | ✅ |
| `implemented` | D6 实施与效果验证（**要有数据**） | ✅ |
| `preventive` | D7 预防再发措施（含**横向展开**） | ✅ |
| `closed_note` | D8 关闭确认与经验总结 | |
| `status` | 处理中 / 已关闭 | |

### 第 2 步：写 JSON 并生成

把收集到的信息写成 JSON 文件，然后：

```bash
python scripts/generate_8d_report.py --input complaint.json --output "8D报告.docx"
```

先看样例了解格式：

```bash
python scripts/generate_8d_report.py --demo --output "8D报告_样例.docx"
```

### 第 3 步：交付

用 `present_files` 展示生成的 docx，并同时把「待确认清单」内容口头告知用户。

## 8D 各步的写法要点（这是质量关键）

报告能不能过客户审阅，取决于内容质量而不只是排版。按下面写：

| 步骤 | 必须写清 | 常见错误 |
|---|---|---|
| **D2 问题描述** | 现象 + 数量 + 比例 + 批次范围 + 客户使用环节 | ❌ 混入了原因分析（原因属于 D4） |
| **D3 临时围堵** | 何时围堵、围堵范围（库存/在途/客户端）、客户侧动作 | ❌ 只写"已隔离"，没说隔离了多少件 |
| **D4 根本原因** | 要挖到**系统性原因**（为什么以前没发现/为什么没防住），不是直接原因 | ❌ 直接原因当根本原因（"来料镀层起皮"不是根因） |
| **D5 永久纠正** | 改什么（工艺/设备/文件/监控）+ 谁负责 + 何时完成 | ❌ 只写"加强培训"这类无效措施 |
| **D6 验证** | **必须有量化数据**：整改后多少批次、多少件、不良率从多少降到多少 | ❌ 只写"已实施，未再发生" |
| **D7 预防再发** | 分三层：横向展开（查了哪些其他线/产品）、机制固化（写入文件/标准）、监控（如何防再发） | ❌ 不做横向展开，客户一定会退 |
| **D8 关闭** | 经验沉淀 + 文件修订 + 培训完成情况 | |

## 核心原则：不编造

生成器**不会**用模板文字填充空缺。缺失项在报告中显示「（待填写）」，并汇总成「待确认清单」章节。

原因：8D 报告是要提交给客户的正式文件，任何未经确认的陈述都可能在后续审计中被质疑。

如果用户说"你先填上"，请先复述你要填的内容让用户确认，或者明确标注"（草稿-待核实）"。

## 行业适配

报告结构（D1-D8）是 AIAG/VDA 通用格式，跨行业适用。需按用户行业调整的只有：

- **D2 的检验项目名称**（磁材是磁通/Br/Hcj/BHmax，食品是感官/菌落/理化，汽车是尺寸/扭矩/气密）
- **D4 的工艺词汇**

修改 `scripts/generate_8d_report.py` 中的 `DEMO` 数据即可快速产出行业样例。

## 常见追问

**Q: 能生成 PDF 吗？**
A: 先生成 docx，再用 Word 另存为 PDF。脚本不直接产出 PDF，因为 PDF 需要额外依赖且排版控制不如 docx 稳定。

**Q: 能批量生成多份吗？**
A: 可以。写一个循环调用脚本，或者用 `--input` 逐个传入。但注意每份的待确认清单都要人工过一遍。

**Q: D3 和 D5 有什么区别？**
A: D3 是**临时**措施（马上止血，隔离/挑选/停线），D5 是**永久**措施（改工艺/文件/设备防再发）。D3 是保护客户，D5 是保护自己。

**Q: 客户投诉严重度怎么定？**
A: 致命=安全/法规风险；严重=批量失效或关键性能不达标；一般=功能或外观缺陷；轻微=不影响使用。严重度决定围堵范围和响应时限。

## 参考资料

需要更细的写法示例时读 `references/8d-writing-guide.md`（含磁材、五金注塑、食品三个行业的完整 8D 实例）。

---

## 业务接口说明

本技能的分析与生成能力由计费服务提供，通过 HTTP 接口调用，单次 ¥9.90。

### 接口

```
POST https://pingguye.cn/a2m/8d-complaint-report-generator
Content-Type: application/json
```

请求体为业务参数（JSON），示例：

```bash
node scripts/pay-call.mjs 8d-complaint-report-generator data=@report.json
```

### 调用方式（四步链路）

随包的 `scripts/pay-call.mjs` 提供完整的按次付费链路（Node.js 18+）：

```bash
# 第 1 步 quote：取账单（服务端返回 402 与 Payment-Needed 账单头，调用器把账单原文存入状态文件）
node scripts/pay-call.mjs 8d-complaint-report-generator quote data=@complaint.json

# 第 2 步 pay：调支付宝官方买家侧 CLI 生成收银台入口（收款链接 + 二维码）
#   官方包：npx -y @alipay/agent-payment@latest install   → alipay-bot 402-buyer-pay
node scripts/pay-call.mjs 8d-complaint-report-generator pay --intent "8d-complaint-report-generator 按次调用"

# 第 3 步 prove：携带 Payment-Proof 与同一 out_trade_no 重发原请求取货
node scripts/pay-call.mjs 8d-complaint-report-generator prove --proof "<Payment-Proof>"

# 第 4 步 status：查看订单状态与最近一次交付结果
node scripts/pay-call.mjs 8d-complaint-report-generator status
```

**AI 付钱包门禁**（首次使用需先开通并绑定付款账号）：

```bash
node scripts/pay-call.mjs 8d-complaint-report-generator wallet check              # 查开通/绑定状态
node scripts/pay-call.mjs 8d-complaint-report-generator wallet apply              # 申请开通（支付宝扫码）
node scripts/pay-call.mjs 8d-complaint-report-generator wallet bind --code <6位授权码>
node scripts/pay-call.mjs 8d-complaint-report-generator wallet close              # 解绑换号
```

`pay` 会先自动检查钱包：未开通时只给开通指引、不出付款码（避免扫出开通页而不是收银台）；
已确认就绪时可加 `--skip-wallet-check` 跳过检查。支付链接约 5 分钟过期，请现生成现扫。

**职责分工**：账单签名、支付凭证验付（`payment.verify`）与商家履约确认（`notify_type=FULFILL`）
由商家服务端实现；技能端只做客户端编排 —— 取账单、生成支付入口、携带凭证重试、取结果。

### 计费协议

服务遵循支付宝 A2M（AI 按量付费）协议，接口行为如下：

| 环节 | 行为 |
|---|---|
| 账单下发 | 未支付时返回 HTTP 402，账单以 `Payment-Needed` 响应头下发；调用器将其原样保存到 `~/.a2m-orders/` |
| 凭证重试 | 支付完成后以 `Payment-Proof` 请求头重试，**请求参数与 `out_trade_no` 保持一致**，不新建订单 |
| 订单校验 | 服务端调用支付宝支付凭证验证接口（`payment.verify`）校验凭证与订单；校验不通过时不交付结果 |
| 履约回执 | 交付结果后服务端发送履约回执（`notify_type=FULFILL`），回执失败时订单保持可重试状态 |
| 订单幂等 | 订单持久化于服务端（状态机 `PENDING → PAID → FULFILLED`），重复提交复用同一订单号，不重复计费、不重复交付 |

支付环节的处理遵循支付宝官方 `alipay-payment-skill` 的 402 协议规范。

### 运行依赖

- Node.js 18+（执行 `scripts/pay-call.mjs`）
- 订单状态目录 `~/.a2m-orders/`（可写）

### 状态处理约定

- 订单状态不明确时查询原订单，不新建订单、不重复提交支付
- 缺少必要参数时向用户确认后再发起请求
- 计费金额以接口返回的 `Payment-Needed` 为准
