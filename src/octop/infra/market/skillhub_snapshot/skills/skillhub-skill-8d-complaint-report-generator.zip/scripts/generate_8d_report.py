#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
客诉 8D 报告生成器
==================

输入一份 JSON 客诉数据，输出一份排版规范的 8D 报告（.docx）。

用法::

    python generate_8d_report.py --input complaint.json --output "8D报告.docx"
    python generate_8d_report.py --demo --output "8D报告_样例.docx"
    cat complaint.json | python generate_8d_report.py --output out.docx

依赖::

    pip install python-docx

JSON 字段（全部可选，缺失项在报告中留空并列入"待确认清单"）::

    comp_code      客诉编号，如 CS20261024-01
    customer_name  客户名称
    order_no       订单号
    batch_code     关联批次号
    product_name   产品名称
    spec_model     规格型号
    qty_ng         不良数量
    qty_total      交付总数（给了就算 PPM）
    severity       严重度：轻微 / 一般 / 严重 / 致命
    comp_date      客诉日期 YYYY-MM-DD
    reporter       报告人
    team           D1 成立小组
    problem        D2 问题描述
    interim        D3 临时围堵措施
    root_cause     D4 根本原因分析
    corrective     D5 永久纠正措施
    implemented    D6 对策实施与效果验证
    preventive     D7 预防再发措施
    closed_note    D8 关闭确认与经验总结

设计要点
--------
* 不做任何"自动编造"。缺字段 → 留空 + 进"待确认清单"，绝不用模板文字填充。
* 中文正文使用微软雅黑，西文 Calibri，避免 Word 里字体回退导致的排版错乱。
* python-docx 不设置 width=None（会抛异常），列宽一律用 Cm 显式指定。
"""

import argparse
import json
import os
import sys
from datetime import datetime

try:
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
except ImportError:
    sys.stderr.write(
        "缺少依赖 python-docx。请执行: pip install python-docx\n"
    )
    sys.exit(2)

# ---------------------------------------------------------------- 主题色
BRAND = RGBColor(0x3C, 0x34, 0x89)      # 深紫（主色）
BRAND_LIGHT = "EDEAF5"
HEADER_BG = "3C3489"
GRAY = RGBColor(0x59, 0x59, 0x59)

D_STEPS = [
    ("D1", "成立小组", "team"),
    ("D2", "问题描述", "problem"),
    ("D3", "临时围堵措施", "interim"),
    ("D4", "根本原因分析", "root_cause"),
    ("D5", "永久纠正措施", "corrective"),
    ("D6", "对策实施与效果验证", "implemented"),
    ("D7", "预防再发措施", "preventive"),
    ("D8", "关闭确认与经验总结", "closed_note"),
]

BASIC_FIELDS = [
    ("客诉编号", "comp_code"),
    ("客户名称", "customer_name"),
    ("订单号", "order_no"),
    ("关联批次", "batch_code"),
    ("产品名称", "product_name"),
    ("规格型号", "spec_model"),
    ("不良数量", "qty_ng"),
    ("交付总数", "qty_total"),
    ("严重度", "severity"),
    ("客诉日期", "comp_date"),
    ("报告人", "reporter"),
    ("当前状态", "status"),
]


# ---------------------------------------------------------------- 字体工具
def set_font(run, size=10.5, bold=False, color=None, name="微软雅黑"):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.name = "Calibri"
    if color is not None:
        run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rf = rpr.get_or_add_rFonts()
    rf.set(qn("w:eastAsia"), name)
    rf.set(qn("w:ascii"), "Calibri")
    rf.set(qn("w:hAnsi"), "Calibri")
    return run


def style_document(doc):
    """统一正文字体。"""
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)
    rpr = normal.element.get_or_add_rPr()
    rf = rpr.get_or_add_rFonts()
    rf.set(qn("w:eastAsia"), "微软雅黑")
    pf = normal.paragraph_format
    pf.space_after = Pt(4)
    pf.line_spacing = 1.25


def shade_cell(cell, hexcolor):
    """给表格单元格填充底色。"""
    from docx.oxml import OxmlElement
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)


def set_col_widths(table, widths_cm):
    """python-docx 必须逐单元格设置列宽，且每个单元格都要设。"""
    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            if idx < len(widths_cm):
                cell.width = Cm(widths_cm[idx])


def fill_cell(cell, text, size=9.5, bold=False, color=None, align=None):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.space_before = Pt(1)
    if align is not None:
        p.alignment = align
    # 数值等非字符串统一转成文本，避免 python-docx 内部遍历字符时报错
    run = p.add_run("" if text is None else str(text))
    set_font(run, size=size, bold=bold, color=color)
    return cell


# ---------------------------------------------------------------- 报告主体
def build_report(data):
    doc = Document()
    style_document(doc)

    for section in doc.sections:
        section.top_margin = Cm(2.2)
        section.bottom_margin = Cm(2.0)
        section.left_margin = Cm(2.4)
        section.right_margin = Cm(2.4)

    # ---- 标题
    t = doc.add_paragraph()
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t.paragraph_format.space_after = Pt(2)
    set_font(t.add_run("客户投诉 8D 报告"), size=20, bold=True, color=BRAND)

    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub.paragraph_format.space_after = Pt(10)
    code = data.get("comp_code") or "（编号待确认）"
    set_font(sub.add_run(f"编号：{code}"), size=10, color=GRAY)

    # ---- 一、客诉基本信息
    h1 = doc.add_paragraph()
    h1.paragraph_format.space_before = Pt(6)
    h1.paragraph_format.space_after = Pt(4)
    set_font(h1.add_run("一、客诉基本信息"), size=13, bold=True, color=BRAND)

    rows = []
    for label, key in BASIC_FIELDS:
        val = data.get(key)
        if val is None or str(val).strip() == "":
            val = ""
        rows.append((label, str(val)))
    # 补齐成 4 列（label/value/label/value）
    if len(rows) % 2 == 1:
        rows.append(("", ""))

    tb = doc.add_table(rows=len(rows) // 2, cols=4)
    tb.style = "Table Grid"
    tb.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i in range(0, len(rows), 2):
        r = i // 2
        fill_cell(tb.cell(r, 0), rows[i][0], bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
        shade_cell(tb.cell(r, 0), BRAND_LIGHT)
        fill_cell(tb.cell(r, 1), rows[i][1])
        fill_cell(tb.cell(r, 2), rows[i + 1][0], bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
        shade_cell(tb.cell(r, 2), BRAND_LIGHT)
        fill_cell(tb.cell(r, 3), rows[i + 1][1])
    set_col_widths(tb, [3.2, 5.3, 3.2, 5.3])

    # ---- PPM
    if data.get("qty_ng") and data.get("qty_total"):
        try:
            qn_ = float(data["qty_ng"])
            qt = float(data["qty_total"])
            if qt > 0:
                ppm = round(qn_ / qt * 1_000_000, 1)
                p = doc.add_paragraph()
                p.paragraph_format.space_before = Pt(4)
                set_font(p.add_run(f"不良率（PPM）：{ppm:,.1f} PPM "
                                   f"（{qn_:g} / {qt:g}）"), size=10, bold=True, color=BRAND)
        except (TypeError, ValueError):
            pass

    # ---- 二、8D 过程
    h2 = doc.add_paragraph()
    h2.paragraph_format.space_before = Pt(12)
    h2.paragraph_format.space_after = Pt(4)
    set_font(h2.add_run("二、8D 过程"), size=13, bold=True, color=BRAND)

    st_tb = doc.add_table(rows=len(D_STEPS), cols=3)
    st_tb.style = "Table Grid"
    st_tb.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (dcode, dname, key) in enumerate(D_STEPS):
        fill_cell(st_tb.cell(i, 0), dcode, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
        shade_cell(st_tb.cell(i, 0), BRAND_LIGHT)
        fill_cell(st_tb.cell(i, 1), dname, bold=True)
        val = data.get(key)
        val = "" if val is None else str(val)
        fill_cell(st_tb.cell(i, 2), val if val.strip() else "（待填写）")
    set_col_widths(st_tb, [1.5, 4.0, 11.5])

    # ---- 三、待确认清单
    missing = []
    for label, key in BASIC_FIELDS:
        if key == "status":
            continue
        if not str(data.get(key) or "").strip():
            missing.append(label)
    for dcode, dname, key in D_STEPS:
        if not str(data.get(key) or "").strip():
            missing.append(f"{dcode} {dname}")

    if missing:
        h3 = doc.add_paragraph()
        h3.paragraph_format.space_before = Pt(12)
        h3.paragraph_format.space_after = Pt(4)
        set_font(h3.add_run("三、待确认清单"), size=13, bold=True, color=BRAND)

        note = doc.add_paragraph()
        set_font(note.add_run(
            "以下项目在输入数据中为空，需补充后方可提交。生成器不会自动填充内容，"
            "以避免报告中出现未经确认的陈述。"), size=9.5, color=GRAY)

        mb = doc.add_table(rows=len(missing), cols=2)
        mb.style = "Table Grid"
        for i, item in enumerate(missing):
            fill_cell(mb.cell(i, 0), str(i + 1), bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
            shade_cell(mb.cell(i, 0), BRAND_LIGHT)
            fill_cell(mb.cell(i, 1), item)
        set_col_widths(mb, [1.5, 15.5])

    # ---- 签署
    h4 = doc.add_paragraph()
    h4.paragraph_format.space_before = Pt(16)
    h4.paragraph_format.space_after = Pt(6)
    set_font(h4.add_run("四、签署"), size=13, bold=True, color=BRAND)

    sig = doc.add_table(rows=2, cols=4)
    sig.style = "Table Grid"
    labels = [("编制", ""), ("审核", ""), ("批准", ""), ("日期", "")]
    for i, (lab, _) in enumerate(labels):
        fill_cell(sig.cell(0, i), lab, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
        shade_cell(sig.cell(0, i), BRAND_LIGHT)
        fill_cell(sig.cell(1, i), "", size=10.5)
    set_col_widths(sig, [4.25, 4.25, 4.25, 4.25])

    tail = doc.add_paragraph()
    tail.paragraph_format.space_before = Pt(10)
    tail.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_font(tail.add_run(f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}"),
             size=9, color=GRAY)

    return doc


# ---------------------------------------------------------------- 数据读取
DEMO = {
    "comp_code": "CS20261024-01",
    "customer_name": "示例精密制造有限公司",
    "order_no": "SO-2026-0918",
    "batch_code": "B20260915-07",
    "product_name": "钕铁硼永磁体 N42SH",
    "spec_model": "20×10×5 mm",
    "qty_ng": 120,
    "qty_total": 5000,
    "severity": "严重",
    "comp_date": "2026-10-18",
    "reporter": "张工",
    "team": "质量部（王工）、工艺部（李工）、生产部（赵工）、采购部（孙工）",
    "problem": "客户来料检验发现表面镀层起皮，抽样 5000 片中 120 片异常，主要集中于同批次 B20260915-07。",
    "interim": "2 小时内对该批次库存 8600 片实施隔离封存；已通知客户暂停上线使用。",
    "root_cause": "该批次电镀槽液中镍含量偏低且 pH 波动超出工艺窗口（实测 5.8~6.4，规范 6.0±0.2），"
                  "叠加槽液温度偏高导致结合力下降。追查发现电镀工序在 9 月 15 日更换了酸洗槽，"
                  "换槽后未做首件槽液全项分析即投产。",
    "corrective": "① 更换老化槽液并重新建槽；② 恢复槽液全项分析频次至每班次一次；"
                  "③ 换槽后增加首件镀层结合力剥离测试，合格方可放行投产。",
    "implemented": "9 月 28 日完成整改并连续跟踪 5 个批次共 24000 片，镀层起皮不良率由 2.4% 降至 0.02%，"
                   "未再发生客户投诉。",
    "preventive": "① 将「换槽后首件确认」写入电镀作业指导书并纳入换型 checklist；"
                  "② 槽液 pH、镍含量纳入在线监控，异常自动报警；"
                  "③ 横向展开检查其他 3 条电镀线，排查同类风险。",
    "closed_note": "问题已闭环，工艺文件已更新并完成培训签到（12 人）。"
                   "沉淀一条质量经验：换槽后首件槽液全项分析缺失 → 需制度化。",
    "status": "已关闭",
}


def load_payload(args):
    if args.demo:
        return dict(DEMO)
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            return json.load(f)
    if not sys.stdin.isatty():
        raw = sys.stdin.read().strip()
        if raw:
            return json.loads(raw)
    sys.stderr.write(
        "缺少输入。请用 --input <file.json>、--demo，或从标准输入传入 JSON。\n"
    )
    sys.exit(2)


def main():
    ap = argparse.ArgumentParser(
        description="客诉 8D 报告生成器（输入 JSON，输出 Word 报告）")
    ap.add_argument("--input", "-i", help="客诉数据 JSON 文件路径")
    ap.add_argument("--output", "-o", default="8D报告.docx", help="输出 docx 路径")
    ap.add_argument("--demo", action="store_true", help="使用内置样例数据")
    args = ap.parse_args()

    data = load_payload(args)
    if not isinstance(data, dict):
        sys.stderr.write("输入必须是 JSON 对象。\n")
        sys.exit(2)

    doc = build_report(data)

    outdir = os.path.dirname(os.path.abspath(args.output))
    if outdir:
        os.makedirs(outdir, exist_ok=True)
    doc.save(args.output)
    print(f"已生成：{os.path.abspath(args.output)}")


if __name__ == "__main__":
    main()
