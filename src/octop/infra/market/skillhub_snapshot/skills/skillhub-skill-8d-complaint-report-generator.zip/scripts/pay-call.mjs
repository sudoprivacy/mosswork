#!/usr/bin/env node
/**
 * 业务接口调用器（支付宝 A2M 按量计费协议）
 *
 * 职责划分：
 *   · 商家服务端负责出账签名、支付凭证验付与商家履约确认（notify_type=FULFILL）；
 *     技能端只做客户端编排：拿到账单 → 生成付款入口 → 携带凭证重试 → 取结果。
 *   · 账单协议：
 *       未支付时服务端返回 HTTP 402，并在 Payment-Needed 响应头下发账单；
 *       支付完成后携带 Payment-Proof 头重试，请求参数与 out_trade_no 保持一致；
 *       服务端校验凭证与订单后交付结果，并发送履约确认回执；
 *       订单状态持久化于服务端（状态机 PENDING → PAID → FULFILLED），重复提交复用同一订单号。
 *
 * 四步链路：
 *   quote  取账单（402），把 Payment-Needed 原文与原始参数存入状态文件
 *   pay    调支付宝官方买家侧 CLI 生成支付入口（收款链接 + 二维码）
 *   prove  携带 Payment-Proof 重发原请求取货（参数与订单号保持一致）
 *   status 查看订单状态
 *   wallet 支付宝 AI 付钱包门禁（check / apply / bind / close）
 *
 * 用法：
 *   node pay-call.mjs <service_key> quote [key=value ...]
 *   node pay-call.mjs <service_key> pay [--url <资源URL>] [--intent <付款说明>]
 *                                      [--bot <alipay-bot路径>] [--skip-wallet-check]
 *   node pay-call.mjs <service_key> prove [--proof <凭证>] [--proof-file <文件>]
 *   node pay-call.mjs <service_key> status
 *   node pay-call.mjs <service_key> wallet check|apply|bind --code <6位授权码>|close
 *
 * 环境变量：
 *   A2M_ENDPOINT   接口前缀（默认 https://pingguye.cn/a2m）
 *   A2M_STATE_DIR  订单状态目录（默认 ~/.a2m-orders）
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const ENDPOINT = process.env.A2M_ENDPOINT || 'https://pingguye.cn/a2m';
const STATE_DIR = process.env.A2M_STATE_DIR ||
  path.join(os.homedir(), '.a2m-orders');

/* ------------------------------------------------------------------ 工具 */

const argv = process.argv.slice(2);
if (argv.length < 2) {
  console.error('用法: node pay-call.mjs <service_key> <quote|pay|prove|status|wallet> [选项]');
  process.exit(2);
}
const serviceKey = argv[0];
const cmd = argv[1];
const rest = argv.slice(2);

function stateFile() {
  return path.join(STATE_DIR, `${serviceKey}.json`);
}
function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); }
  catch { return {}; }
}
function saveState(st) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  fs.writeFileSync(stateFile(), JSON.stringify(st, null, 2), 'utf8');
}
function die(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

/** 解析 key=value 与 --flag value 两种参数 */
function parseArgs(list) {
  const params = {};
  const flags = {};
  for (let i = 0; i < list.length; i++) {
    const a = list[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = list[i + 1];
      if (next && !next.startsWith('--')) { flags[key] = next; i++; }
      else flags[key] = true;
    } else {
      const eq = a.indexOf('=');
      if (eq > 0) params[a.slice(0, eq)] = a.slice(eq + 1);
    }
  }
  return { params, flags };
}

async function callService(params, proof = '') {
  const headers = { 'Content-Type': 'application/json' };
  if (proof) headers['Payment-Proof'] = proof;
  const body = { ...params };
  let res;
  try {
    res = await fetch(`${ENDPOINT}/${serviceKey}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
    });
  } catch (e) {
    die(`网络错误：${String(e).slice(0, 120)}`);
  }
  const needed = res.headers.get('payment-needed');
  const text = await res.text();
  let payload;
  try { payload = JSON.parse(text); } catch { payload = { raw: text }; }
  return { status: res.status, needed, payload };
}

/* ------------------------------------------- 支付宝官方买家侧 CLI（alipay-bot） */

/** 按顺序探测 alipay-bot 的安装位置 */
function findBot(explicit) {
  if (explicit && typeof explicit === 'string') {
    if (fs.existsSync(explicit)) return explicit;
    return null;
  }
  const exe = process.platform === 'win32' ? 'alipay-bot.exe' : 'alipay-bot';
  const home = os.homedir();
  const cands = [
    path.join(home, '.local', 'bin', exe),
    path.join(home, '.local', 'share', 'alipay-bot-cli', 'runtime', exe),
    path.join(home, '.openclaw-autoclaw', 'alipay-bot-cli', 'bin', exe),
  ];
  for (const c of cands) if (fs.existsSync(c)) return c;
  // nvm 下的多版本 node
  const nvmRoot = path.join(home, '.nvm', 'versions', 'node');
  try {
    for (const d of fs.readdirSync(nvmRoot).sort()) {
      const p = path.join(nvmRoot, d, 'bin', exe);
      if (fs.existsSync(p)) return p;
    }
  } catch { /* nvm 不存在 */ }
  return null;
}

/** 调用官方 CLI。业务错误写在 stdout 的 JSON 里，必须先解析 JSON 再判退出码。 */
function runBot(bot, args, timeoutMs = 60000) {
  const res = spawnSync(bot, [...args, '-o', 'json'], {
    encoding: 'utf8', timeout: timeoutMs,
  });
  const out = (res.stdout || '').trim();
  let data = null;
  try {
    data = JSON.parse(out);
  } catch {
    const i = out.indexOf('{');
    if (i >= 0) { try { data = JSON.parse(out.slice(i)); } catch { data = null; } }
  }
  return { code: res.status ?? -1, data, raw: out, stderr: res.stderr || '' };
}

/** 钱包状态：ready / pending / none / unknown */
function checkWallet(bot, timeoutMs = 30000) {
  const r = runBot(bot, ['check-wallet'], timeoutMs);
  if (!r.data) return { state: 'unknown', data: r.data, raw: r.raw };
  if (r.data.code === 200) {
    const url = r.data.accessUrl || r.data.access_url || '';
    return { state: url ? 'pending' : 'ready', data: r.data, raw: r.raw };
  }
  if (r.data.code === 500) return { state: 'none', data: r.data, raw: r.raw };
  return { state: 'unknown', data: r.data, raw: r.raw };
}

/**
 * 判别拿到的是「开通码」还是「付款码」。
 * accessUrl 里 token= 段 base64 解码后前缀是 agentWallet_applyCreate_ → 开通码；
 * 二维码文件名 wallet-bind-*.png → 开通码，payment-confirm-*.png → 付款码。
 */
function isApplyCode(url, qrPath) {
  if (qrPath && /wallet-bind/i.test(qrPath)) return true;
  const m = /token=([^&]+)/.exec(url || '');
  if (!m) return false;
  try {
    const dec = Buffer.from(m[1], 'base64').toString('utf8');
    return dec.includes('agentWallet_applyCreate');
  } catch { return false; }
}

/* ------------------------------------------------------------------ 命令 */

async function cmdQuote() {
  const { params } = parseArgs(rest);
  const st = loadState();
  if (st.out_trade_no) params.out_trade_no = st.out_trade_no;

  const r = await callService(params);
  if (r.status === 200) {
    console.log(JSON.stringify(r.payload, null, 2));
    console.error('\n✅ 该订单已履约，直接返回结果。');
    saveState({ ...st, last_result: r.payload, updated_at: Date.now() });
    return;
  }
  if (r.status !== 402) {
    console.error(JSON.stringify({ ok: false, stage: 'error', http_status: r.status, body: r.payload }, null, 2));
    process.exit(1);
  }

  // 保存账单原文与原始参数，供 pay / prove 复用（订单幂等的依据）
  const bill = r.needed || '';
  let billObj = {};
  try { billObj = JSON.parse(Buffer.from(bill, 'base64').toString('utf8')); } catch { /* 非 base64 */ }
  saveState({
    ...st,
    out_trade_no: r.payload.out_trade_no || billObj.out_trade_no || '',
    payment_needed: bill,
    bill: billObj,
    url: `${ENDPOINT}/${serviceKey}`,
    method: 'POST',
    params,
    goods_name: billObj.goods_name || '',
    amount: billObj.amount || r.payload.amount || '',
    currency: billObj.currency || 'CNY',
    updated_at: Date.now(),
  });

  console.error('【第 1 步 · quote】账单已取得，需要付费后才能取结果。');
  console.error(`  订单号  ：${r.payload.out_trade_no || billObj.out_trade_no || '-'}`);
  console.error(`  金额    ：${billObj.amount || r.payload.amount || '-'} ${billObj.currency || 'CNY'}`);
  console.error(`  商品    ：${billObj.goods_name || '-'}`);
  console.error(`  服务    ：${billObj.service_id || '-'}`);
  console.error('');
  console.error('【第 2 步 · pay】生成支付入口（支付宝官方收银台）：');
  console.error(`  node pay-call.mjs ${serviceKey} pay --intent "${billObj.goods_name || '技能调用'}"`);
  console.error('');
  console.error('【第 3 步 · prove】付款后携带凭证重试取货：');
  console.error(`  node pay-call.mjs ${serviceKey} prove --proof "<Payment-Proof>"`);
  process.exit(402);
}

function cmdPay() {
  const { flags } = parseArgs(rest);
  const st = loadState();
  if (!st.payment_needed) {
    die('[pay] 状态文件里没有账单，请先执行 quote。');
  }
  const bot = findBot(flags.bot);
  if (!bot) {
    console.error('[pay] 找不到 alipay-bot（买家侧官方支付 CLI）。先安装：');
    console.error('      npx -y @alipay/agent-payment@latest install');
    console.error('      装完重新执行本命令；若不在 PATH，用 --bot 指定完整路径。');
    process.exit(1);
  }

  // 钱包门禁：未开通就造付款码，会扫出「请勿重复绑定」之类的开通页
  if (!flags['skip-wallet-check']) {
    const w = checkWallet(bot, 30000);
    if (w.state === 'none') {
      console.error('[pay] 当前环境的支付宝 AI 付钱包还没开通（code=500 未开通），');
      console.error('      直接生成付款码会扫出开通页而不是收银台。');
      console.error('      先开通：node pay-call.mjs ' + serviceKey + ' wallet apply');
      process.exit(2);
    }
    if (w.state === 'pending') {
      console.error('[pay] 钱包已申请但还没完成授权，先把授权码绑上：');
      console.error('      node pay-call.mjs ' + serviceKey + ' wallet bind --code <6位授权码>');
      process.exit(2);
    }
  }

  // 账单原文落临时文件（权限 600），交给官方 CLI 读取
  const billFile = path.join(os.tmpdir(),
    `.a2m-bill-${st.out_trade_no || 'tmp'}.txt`);
  fs.writeFileSync(billFile, st.payment_needed, 'utf8');
  try { fs.chmodSync(billFile, 0o600); } catch { /* Windows 忽略 */ }

  const intent = flags.intent ||
    `${st.goods_name || 'SkillHub 技能调用'} ${st.amount || ''}元`;
  const url = flags.url || st.url || `${ENDPOINT}/${serviceKey}`;
  const method = flags.method || st.method || 'POST';

  const args = ['402-buyer-pay',
    '-f', billFile,
    '-r', url,
    '-m', method,
    '-i', intent,
  ];
  console.error(`[pay] 调支付宝官方 CLI 生成支付入口：${bot} 402-buyer-pay ...`);
  const r = runBot(bot, args, Number(flags.timeout || 90000));

  if (!r.data) {
    console.error(`[pay] 官方 CLI 无 JSON 输出（退出码 ${r.code}）`);
    console.error((r.stderr || r.raw || '').slice(0, 1200));
    process.exit(1);
  }
  if (r.data.success === false || r.data.code !== undefined && r.data.code !== 200) {
    const err = r.data.errorCode || '';
    if (err === 'TRADE_PROGRESS_FAILED' ||
        /买家和卖家不能相同/.test(r.data.errorMsg || '')) {
      console.error('[pay] 支付宝拒绝：买家和卖家不能相同（errorCode=TRADE_PROGRESS_FAILED）。');
      console.error('      当前环境绑定的付款账号就是本技能的收款账号，自己买自己的商品不被允许。');
      console.error('      自测请换一个第三方账号：wallet close → wallet apply → 用那个号扫码 →');
      console.error('      wallet bind --code <6位授权码> → 再执行 pay。');
      process.exit(3);
    }
    console.error('[pay] 生成支付入口失败：');
    console.error(JSON.stringify(r.data, null, 2).slice(0, 1500));
    process.exit(1);
  }

  const short = r.data.shortAccessUrl || r.data.shortUrl || '';
  const longUrl = r.data.accessUrl || '';
  const qr = (r.data.mediaPaths || [])[0] || '';
  const shake = r.data.outShakeNo || '';

  console.log('');
  console.log('=== 支付入口（支付宝官方生成）===');
  console.log(`商品    ：${r.data.goodsName || st.goods_name || '-'}`);
  console.log(`金额    ：${r.data.amount || st.amount || '-'} ${st.currency || 'CNY'}`);
  console.log(`订单号  ：${st.out_trade_no || '-'}`);
  if (short) console.log(`付款链接：${short}`);
  if (longUrl && longUrl !== short) console.log(`完整链接：${longUrl}`);
  if (qr) console.log(`二维码  ：${qr}`);
  console.log('');
  console.log('把上面的链接或二维码给本环境已绑定的那个支付宝账号扫码付款。');
  console.log('付款后执行：');
  console.log(`  node pay-call.mjs ${serviceKey} prove --proof "<Payment-Proof>"`);
  if (shake) console.log(`（官方凭证号 outShakeNo：${shake}）`);

  if (isApplyCode(longUrl || short, qr)) {
    console.error('');
    console.error('⚠️ 拿到的是【开通码】不是【付款码】——说明本环境的 AI 付钱包还没绑好。');
    console.error('   请用支付宝扫码完成开通/绑定，然后把 6 位授权码执行：');
    console.error(`     node pay-call.mjs ${serviceKey} wallet bind --code <6位授权码>`);
    process.exit(2);
  }
  console.error('');
  console.error('⏱  支付链接约 5 分钟过期，扫码要趁热；过期表现为「链接打不开」。');
}

async function cmdProve() {
  const { flags } = parseArgs(rest);
  const st = loadState();
  if (!st.out_trade_no) die('[prove] 状态文件里没有订单号，请先执行 quote。');

  let proof = flags.proof || '';
  if (!proof && flags['proof-file']) {
    try { proof = fs.readFileSync(flags['proof-file'], 'utf8').trim(); } catch { /* 无文件 */ }
  }
  if (!proof) die('[prove] 缺少 Payment-Proof（用 --proof 或 --proof-file 提供）');

  // 原参数与同一 out_trade_no 一起重发，服务端据此校验并保证不重复交付
  const params = { ...(st.params || {}), out_trade_no: st.out_trade_no };
  const r = await callService(params, proof);

  if (r.status === 200) {
    console.log(JSON.stringify(r.payload, null, 2));
    console.error('\n✅ 交付成功。');
    saveState({ ...st, last_result: r.payload, status: 'FULFILLED', updated_at: Date.now() });
    return;
  }
  console.error(JSON.stringify({ ok: false, stage: 'prove', http_status: r.status,
    body: r.payload }, null, 2));
  if (r.status === 402) {
    console.error('');
    console.error('仍需付费。请确认：');
    console.error('  1) 付款是否已完成（账单链接 5 分钟过期，超时要重新 quote → pay）；');
    console.error('  2) Payment-Proof 是否为本次账单对应的凭证；');
    console.error('  3) 付款账号是否为商家自身（自己不能买自己的商品）。');
  }
  process.exit(1);
}

function cmdStatus() {
  const st = loadState();
  if (!st.out_trade_no) {
    console.log('本技能还没有订单记录。先执行 quote。');
    return;
  }
  console.log('=== 订单状态 ===');
  console.log(`订单号    ：${st.out_trade_no}`);
  console.log(`金额      ：${st.amount || '-'} ${st.currency || 'CNY'}`);
  console.log(`商品      ：${st.goods_name || '-'}`);
  console.log(`服务标识  ：${(st.bill || {}).service_id || '-'}`);
  console.log(`本地状态  ：${st.status || (st.last_result ? 'FULFILLED' : 'PENDING')}`);
  console.log(`最近更新  ：${st.updated_at ? new Date(st.updated_at).toLocaleString() : '-'}`);
  if (st.last_result) {
    console.log('');
    console.log('=== 最近一次交付结果 ===');
    console.log(JSON.stringify(st.last_result, null, 2).slice(0, 1500));
  }
}

function cmdWallet() {
  const action = rest[0] || 'check';
  const { flags } = parseArgs(rest.slice(1));
  const bot = findBot(flags.bot);
  if (!bot) {
    console.error('[wallet] 找不到 alipay-bot（买家侧官方支付 CLI）。先安装：');
    console.error('         npx -y @alipay/agent-payment@latest install');
    process.exit(1);
  }
  console.error(`[wallet] CLI：${bot}`);

  if (action === 'check') {
    const w = checkWallet(bot);
    console.log(JSON.stringify(w.data || {}, null, 2));
    console.error(`[wallet] 状态：${w.state}`);
    if (w.state === 'none') {
      console.error('');
      console.error('支付宝 AI 付是「一个智能体环境绑一个支付宝账号」：');
      console.error('  谁扫码开通，以后就只能用那个账号在本环境付款。');
      console.error('下一步：node pay-call.mjs ' + serviceKey + ' wallet apply');
      process.exit(3);
    }
    if (w.state === 'pending') {
      console.error('已申请但还没完成授权。用支付宝扫码后把 6 位授权码绑上：');
      console.error('  node pay-call.mjs ' + serviceKey + ' wallet bind --code <6位授权码>');
      process.exit(2);
    }
    console.error('钱包已就绪，可以直接付款：node pay-call.mjs ' + serviceKey + ' pay');
    return;
  }

  if (action === 'apply') {
    const argv2 = ['apply-wallet'];
    if (flags['agent-name']) argv2.push('-a', flags['agent-name']);
    const r = runBot(bot, argv2);
    if (!r.data) {
      console.error('[wallet] 官方 CLI 无 JSON 输出，原文：');
      console.error(r.raw.slice(0, 1200));
      process.exit(1);
    }
    console.log(JSON.stringify(r.data, null, 2));
    for (const k of ['shortAccessUrl', 'shortUrl', 'accessUrl']) {
      if (r.data[k]) console.error(`${k}：${r.data[k]}`);
    }
    console.error('用支付宝扫码开通，然后把 6 位授权码绑上：');
    console.error('  node pay-call.mjs ' + serviceKey + ' wallet bind --code <6位授权码>');
    return;
  }

  if (action === 'bind') {
    if (!flags.code) die('[wallet] 缺授权码。用法：wallet bind --code <6位授权码>');
    const r = runBot(bot, ['bind-wallet', '-c', String(flags.code)]);
    if (!r.data) {
      console.error('[wallet] 官方 CLI 无 JSON 输出，原文：');
      console.error(r.raw.slice(0, 1200));
      process.exit(1);
    }
    console.log(JSON.stringify(r.data, null, 2));
    if (r.data.code === 200 || r.data.success) {
      console.error('绑定完成，现在可以付款：node pay-call.mjs ' + serviceKey + ' pay');
      return;
    }
    console.error('绑定未成功。若提示「请勿重复绑定」，说明该账号已在别处绑定过。');
    process.exit(1);
  }

  if (action === 'close') {
    const r = runBot(bot, ['close-wallet']);
    if (!r.data) {
      console.error('[wallet] 官方 CLI 无 JSON 输出，原文：');
      console.error(r.raw.slice(0, 1200));
      process.exit(1);
    }
    console.log(JSON.stringify(r.data, null, 2));
    for (const k of ['shortAccessUrl', 'shortUrl', 'accessUrl']) {
      if (r.data[k]) console.error(`${k}：${r.data[k]}`);
    }
    console.error('解绑后本环境可重新绑定另一个支付宝账号。');
    return;
  }

  die('[wallet] 未知动作：' + action);
}

/* ------------------------------------------------------------------ 入口 */

switch (cmd) {
  case 'quote': await cmdQuote(); break;
  case 'pay': cmdPay(); break;
  case 'prove': await cmdProve(); break;
  case 'status': cmdStatus(); break;
  case 'wallet': cmdWallet(); break;
  default:
    console.error('未知命令：' + cmd);
    console.error('可用：quote | pay | prove | status | wallet');
    process.exit(2);
}
