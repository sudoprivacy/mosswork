#!/usr/bin/env python3
"""
"3个点" 指标 — 通达信 SKDJ 变体技术指标
基础指标输出型技能：A(结构化JSON) + C(图表) 双产物，B(自然语言)由智能体按需生成

定位: 纯指标计算与数据输出，输出信号供其他智能体参考和进一步处理。

用法:
  python3 three_points.py <code> [options]

  参数:
    code         股票/ETF代码 (如: 159206, 600519, 000001)
    --period     分析周期: 6m / 1y / all (默认: 6m)
    --data-file  外部K线数据JSON文件 (来自通达信MCP等，优先使用)
    --output     图表输出路径 (默认: /workspace/<code>_3points.png)
    --json       输出JSON格式分析结果 (默认，供智能体消费)
    --no-chart   不生成图表

数据获取优先级: 外部数据(--data-file) → 新浪财经API → 统一错误提示
"""

import json
import sys
import os
import argparse
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 常量
# ============================================================
DATA_FETCH_ERROR_MSG = "数据获取失败，请稍后重试"

OUTPUT_REMARKS = """
---
⚠️ 重要提示（"3个点"指标使用反例与黑名单）：

【不要做的事】
1. 不要基于单一"选股信号"直接买入 — 信号仅为技术参考，不构成投资建议
2. 不要在单边上涨行情中用此指标寻找买点 — 趋势行情中可能长期超买，不触发选股信号
3. 不要用于短线波段操作 — 34日通道+13日EMA双重平滑，信号滞后于价格转折，适合中长线
4. 不要在信号少于3次时信任回测胜率 — 小样本下胜率统计意义不足，可能虚高
5. 不要忽略仓位管理和止损 — 本指标仅提供方向判断，不含仓位/止损/止盈规则
6. 不要将此指标作为唯一决策依据 — 需结合趋势（如60日均线）、成交量、基本面综合判断

【本指标的核心定位】
此技能为选股指标体系中的基础指标模块。输出信号供其他智能体参考和进一步处理，
不直接面向最终用户做独立的交易决策建议。
"""

# ============================================================
# 核心指标计算
# ============================================================
def calc_three_points(df):
    """
    计算"3个点"指标
    
    参数:
      df: DataFrame, 需包含 收盘/最高/最低 列
    
    返回:
      df: 附加列 — VAR1, VAR2, VAR3, XX, YY, buy_signal, sell_signal, 
           cross_up_20, xx_above_yy, cross_xx_yy, cross_yy_xx
    """
    close = df['收盘'].values.astype(float)
    high = df['最高'].values.astype(float)
    low = df['最低'].values.astype(float)
    
    # VAR1 := (2*CLOSE+HIGH+LOW)/4
    var1 = (2 * close + high + low) / 4
    
    # VAR2 := LLV(LOW,34)
    var2 = pd.Series(low).rolling(window=34, min_periods=1).min().values
    
    # VAR3 := HHV(HIGH,34)
    var3 = pd.Series(high).rolling(window=34, min_periods=1).max().values
    
    # XX: EMA((VAR1-VAR2)/(VAR3-VAR2)*100,13)
    rsv = np.where((var3 - var2) > 1e-9, (var1 - var2) / (var3 - var2) * 100, 50.0)
    xx = pd.Series(rsv).ewm(span=13, adjust=False, min_periods=1).mean().values
    
    # YY: EMA(0.667*REF(XX,1)+0.333*XX,2)
    xx_ref1 = np.roll(xx, 1)
    xx_ref1[0] = xx[0]
    temp = 0.667 * xx_ref1 + 0.333 * xx
    yy = pd.Series(temp).ewm(span=2, adjust=False, min_periods=1).mean().values
    
    # 前值
    xx_prev = np.roll(xx, 1); xx_prev[0] = xx[0]
    yy_prev = np.roll(yy, 1); yy_prev[0] = yy[0]
    
    # 选股信号: CROSS(XX,YY) AND XX<20
    cross_xx_yy = (xx_prev < yy_prev) & (xx > yy)
    buy_signal = cross_xx_yy & (xx < 20)
    
    # 逃顶信号: FILTER(CROSS(YY,XX) AND XX>80, 3)
    cross_yy_xx = (yy_prev < xx_prev) & (yy > xx)
    raw_sell = cross_yy_xx & (xx > 80)
    # FILTER(condition, 3): 过滤掉前3日内已出现的信号
    sell_signal = raw_sell.copy()
    last_sell = -999
    for i in range(len(sell_signal)):
        if raw_sell[i] and (i - last_sell > 3):
            sell_signal[i] = True
            last_sell = i
        elif raw_sell[i] and (i - last_sell <= 3):
            sell_signal[i] = False
    
    # CROSS(XX,20)
    xx_cross_20 = (xx_prev < 20) & (xx >= 20)
    
    # YY < XX (红色带条件)
    xx_above_yy = xx > yy
    
    df = df.copy()
    df['VAR1'] = var1
    df['VAR2'] = var2
    df['VAR3'] = var3
    df['XX'] = xx
    df['YY'] = yy
    df['buy_signal'] = buy_signal
    df['sell_signal'] = sell_signal
    df['cross_xx_20'] = xx_cross_20
    df['xx_above_yy'] = xx_above_yy
    df['cross_xx_yy'] = cross_xx_yy
    df['cross_yy_xx'] = cross_yy_xx
    
    return df


# ============================================================
# 数据获取
# ============================================================
def determine_market(code):
    """判断证券所属市场"""
    if code.startswith(('159', '16', '18')) or (len(code) == 6 and code[0] in '023'):
        return 'sz'
    elif code.startswith(('51', '58', '56')):
        return 'sz'
    elif code.startswith('6'):
        return 'sh'
    else:
        return 'sz'


def fetch_data_sina(code, start_date=None, end_date=None):
    """从新浪财经API获取日K线数据（兜底方案）"""
    market = determine_market(code)
    symbol = f"{market}{code}"
    
    import requests
    url = "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData"
    params = {"symbol": symbol, "scale": "240", "ma": "no", "datalen": "500"}
    
    resp = requests.get(url, params=params, timeout=30)
    data = resp.json()
    
    if not data or not isinstance(data, list) or len(data) == 0:
        raise ValueError("新浪财经返回空数据")
    
    df = pd.DataFrame(data)
    df['日期'] = pd.to_datetime(df['day'])
    df = df.rename(columns={
        'open': '开盘', 'high': '最高', 'low': '最低',
        'close': '收盘', 'volume': '成交量'
    })
    for col in ['开盘', '最高', '最低', '收盘', '成交量']:
        df[col] = df[col].astype(float)
    df = df.sort_values('日期').reset_index(drop=True)
    
    # 按日期过滤
    if start_date:
        df = df[df['日期'] >= pd.Timestamp(start_date)]
    if end_date:
        df = df[df['日期'] <= pd.Timestamp(end_date)]
    
    return df, market


def process_external_data(external_data, code):
    """
    处理外部传入的K线数据（来自通达信MCP等数据源）
    
    参数:
      external_data: dict 或 list, 包含 K线数据
        dict格式: {"code": "...", "market": "...", "data": [...]}
        list格式: [{"date": "...", "open": ..., "high": ..., ...}, ...]
      code: 证券代码
    
    返回:
      (df, market)
    """
    import re
    
    market = determine_market(code)
    rows = []
    
    if isinstance(external_data, dict):
        # 外层dict格式
        if 'market' in external_data:
            market = external_data['market']
        raw_data = external_data.get('data', external_data.get('items', external_data.get('kline', [])))
    elif isinstance(external_data, list):
        raw_data = external_data
    else:
        raise ValueError("无法解析外部数据格式")
    
    if not raw_data:
        raise ValueError("外部数据为空")
    
    for row in raw_data:
        # 兼容多种字段命名: date/day/time, open, high, low, close, volume/vol
        date_str = row.get('date', row.get('day', row.get('time', '')))
        if not date_str:
            continue
        
        rows.append({
            '日期': str(date_str)[:10],  # 截取日期部分
            '开盘': float(row.get('open', row.get('开盘', 0))),
            '最高': float(row.get('high', row.get('最高', 0))),
            '最低': float(row.get('low', row.get('最低', 0))),
            '收盘': float(row.get('close', row.get('收盘', 0))),
            '成交量': float(row.get('volume', row.get('vol', row.get('成交量', 0)))),
        })
    
    if not rows:
        raise ValueError("外部数据解析后为空")
    
    df = pd.DataFrame(rows)
    df['日期'] = pd.to_datetime(df['日期'])
    df = df.sort_values('日期').reset_index(drop=True)
    
    return df, market


def fetch_data(code, start_date=None, end_date=None, external_data=None, data_source='auto'):
    """
    获取K线数据，按优先级依次尝试
    
    优先级: 外部传入数据 > 新浪财经API
    
    参数:
      code:           证券代码
      start_date:     起始日期
      end_date:       截止日期
      external_data:  外部传入的K线数据（dict/list），通常来自通达信MCP
      data_source:    数据源偏好 'auto'|'sina' (auto模式下优先使用external_data)
    
    返回:
      (df, market)
    
    异常:
      所有数据源均失败时抛出 RuntimeError(DATA_FETCH_ERROR_MSG)
    """
    errors = []
    
    # 策略1: 使用外部传入数据（来自通达信MCP等）
    if external_data is not None:
        try:
            df, market = process_external_data(external_data, code)
            return df, market
        except Exception as e:
            errors.append(f"外部数据: {e}")
    
    # 策略2: 新浪财经API
    try:
        df, market = fetch_data_sina(code, start_date, end_date)
        return df, market
    except Exception as e:
        errors.append(f"新浪财经: {e}")
    
    # 全部失败
    raise RuntimeError(DATA_FETCH_ERROR_MSG)


# ============================================================
# 回测分析
# ============================================================
def backtest(df, buy_col='buy_signal', sell_col='sell_signal'):
    """回测买卖信号"""
    hold_periods = [1, 3, 5, 10, 20, 30]
    buys = df[df[buy_col]]
    
    # 持有期收益
    hold_results = {p: [] for p in hold_periods}
    for _, row in buys.iterrows():
        idx = df[df['日期'] == row['日期']].index[0]
        bp = row['收盘']
        for period in hold_periods:
            si = min(idx + period, len(df) - 1)
            ret = (df.loc[si, '收盘'] - bp) / bp * 100
            hold_results[period].append(ret)
    
    # 完整交易配对
    trades = []
    in_pos = False
    entry = {}
    for i in range(len(df)):
        if df.iloc[i][buy_col] and not in_pos:
            in_pos = True
            entry = {'idx': i, 'date': df.iloc[i]['日期'], 'price': df.iloc[i]['收盘']}
        elif df.iloc[i][sell_col] and in_pos:
            exit_price = df.iloc[i]['收盘']
            ret = (exit_price - entry['price']) / entry['price'] * 100
            trades.append({
                'buy_date': str(entry['date'].date()),
                'buy_price': round(entry['price'], 3),
                'sell_date': str(df.iloc[i]['日期'].date()),
                'sell_price': round(exit_price, 3),
                'return_pct': round(ret, 2),
                'hold_days': (df.iloc[i]['日期'] - entry['date']).days
            })
            in_pos = False
    
    # 强制平仓
    if in_pos:
        last = df.iloc[-1]
        ret = (last['收盘'] - entry['price']) / entry['price'] * 100
        trades.append({
            'buy_date': str(entry['date'].date()),
            'buy_price': round(entry['price'], 3),
            'sell_date': str(last['日期'].date()),
            'sell_price': round(last['收盘'], 3),
            'return_pct': round(ret, 2),
            'hold_days': (last['日期'] - entry['date']).days,
            'note': 'forced_close'
        })
    
    # 基准收益
    first_p = df.iloc[0]['收盘']
    last_p = df.iloc[-1]['收盘']
    bh_return = (last_p - first_p) / first_p * 100
    
    return {
        'hold_periods': hold_periods,
        'hold_results': {str(k): [round(vv, 2) for vv in v] for k, v in hold_results.items()},
        'trades': trades,
        'buy_hold_return': round(bh_return, 2),
        'total_buy_signals': len(buys),
        'total_sell_signals': int(df[sell_col].sum()),
    }


# ============================================================
# 绘图
# ============================================================
def plot_chart(df, code, output_path):
    """生成3个子图的指标分析图表"""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    
    plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'SimHei', 'Noto Sans CJK SC', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, axes = plt.subplots(3, 1, figsize=(16, 12), gridspec_kw={'height_ratios': [2, 1, 1]})
    fig.suptitle(f'{code} — "3个点"指标分析', fontsize=15, fontweight='bold')
    
    buy_pts = df[df['buy_signal']]
    sell_pts = df[df['sell_signal']]
    
    # 图1: 价格 + 买卖信号
    ax1 = axes[0]
    ax1.plot(df['日期'], df['收盘'], 'b-', linewidth=1.2, label='收盘价', alpha=0.85)
    ax1.fill_between(df['日期'], df['最低'], df['最高'], alpha=0.12, color='blue')
    
    if len(buy_pts) > 0:
        ax1.scatter(buy_pts['日期'], buy_pts['收盘'], color='red', marker='^', s=140,
                    zorder=5, edgecolors='darkred', label=f'选股信号({len(buy_pts)}次)')
        for _, r in buy_pts.iterrows():
            ax1.annotate(f"¥{r['收盘']:.2f}", (r['日期'], r['收盘']),
                        textcoords="offset points", xytext=(0, 12), fontsize=7,
                        color='red', ha='center', fontweight='bold')
    
    if len(sell_pts) > 0:
        ax1.scatter(sell_pts['日期'], sell_pts['收盘'], color='green', marker='v', s=140,
                    zorder=5, edgecolors='darkgreen', label=f'逃顶信号({len(sell_pts)}次)')
    
    ax1.set_ylabel('价格', fontsize=11)
    ax1.legend(loc='upper left', fontsize=8)
    ax1.grid(True, alpha=0.25)
    ax1.set_title('价格走势与买卖信号', fontsize=12)
    
    # 图2: XX / YY 指标
    ax2 = axes[1]
    ax2.plot(df['日期'], df['XX'], 'steelblue', linewidth=1.2, label='XX (K线)', alpha=0.85)
    ax2.plot(df['日期'], df['YY'], 'coral', linewidth=1.2, label='YY (D线)', alpha=0.85)
    ax2.axhline(y=80, color='gray', linestyle='--', alpha=0.4)
    ax2.axhline(y=20, color='gray', linestyle='--', alpha=0.4)
    ax2.fill_between(df['日期'], 0, 20, alpha=0.06, color='green')
    ax2.fill_between(df['日期'], 80, 100, alpha=0.06, color='red')
    
    # 标记金叉/死叉点
    cross_up = df[df['cross_xx_yy']]
    cross_dn = df[df['cross_yy_xx']]
    for _, r in cross_up.iterrows():
        ax2.annotate('始', (r['日期'], r['XX']), fontsize=7, color='red', ha='center', va='bottom')
    for _, r in cross_dn.iterrows():
        ax2.annotate('终', (r['日期'], r['YY']), fontsize=7, color='green', ha='center', va='top')
    
    # 标记XX上穿20
    xx_up20 = df[df['cross_xx_20']]
    for _, r in xx_up20.iterrows():
        ax2.axvline(x=r['日期'], color='orange', linestyle=':', alpha=0.4, linewidth=0.7)
    
    ax2.set_ylabel('SKDJ值', fontsize=11)
    ax2.set_ylim(-2, 102)
    ax2.legend(loc='upper left', fontsize=8)
    ax2.grid(True, alpha=0.25)
    ax2.set_title('"3个点"指标 [XX(34,13) / YY(2)]', fontsize=12)
    
    # 图3: 成交量
    ax3 = axes[2]
    colors = ['#e74c3c' if df.iloc[i]['收盘'] >= df.iloc[i]['开盘'] else '#2ecc71'
              for i in range(len(df))]
    ax3.bar(df['日期'], df['成交量'], color=colors, alpha=0.55, width=0.8)
    ax3.set_ylabel('成交量', fontsize=11)
    ax3.set_xlabel('日期', fontsize=11)
    ax3.grid(True, alpha=0.25)
    ax3.set_title('成交量', fontsize=12)
    ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x/1e8:.1f}亿' if x >= 1e8 else f'{x/1e4:.0f}万'))
    
    plt.tight_layout(rect=[0, 0, 1, 0.97])
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    return output_path


# ============================================================
# 主分析函数 — 供智能体调用
# ============================================================
def analyze(code, period='6m', output_chart=True, output_dir='/workspace', external_data=None):
    """
    主分析函数，供智能体调用
    
    输出产物:
      A. 结构化JSON (dict) — 智能体消费的核心数据
      C. PNG图表 (文件) — 给用户看的可视化
    
    参数:
      code:           股票/ETF代码
      period:         分析周期 '6m'(6个月) / '1y'(1年) / 'all'(全部)
      output_chart:   是否输出图表
      output_dir:     输出目录
      external_data:  外部传入的K线数据（dict/list），用于优先数据源
    
    返回:
      dict: 包含完整分析结果的字典
    """
    # 确定日期范围
    end_date = datetime.now()
    if period == '6m':
        start_date = end_date - timedelta(days=200)
    elif period == '1y':
        start_date = end_date - timedelta(days=400)
    else:
        start_date = end_date - timedelta(days=500)
    
    # 获取数据（外部数据优先，新浪兜底）
    try:
        df, market = fetch_data(code, start_date=start_date, end_date=end_date, external_data=external_data)
    except RuntimeError:
        # 所有数据源都失败，返回统一错误信息
        return {"error": DATA_FETCH_ERROR_MSG, "_remarks": OUTPUT_REMARKS.strip()}
    except Exception as e:
        return {"error": DATA_FETCH_ERROR_MSG, "_remarks": OUTPUT_REMARKS.strip()}
    
    # 保存全量数据
    df_full = df.copy()
    
    # 计算指标
    df = calc_three_points(df)
    df_full = calc_three_points(df_full)
    
    # 按周期过滤显示数据
    period_start = end_date - timedelta(days={'6m': 183, '1y': 365, 'all': 9999}[period])
    df_period = df[df['日期'] >= pd.Timestamp(period_start)].copy()
    
    if len(df_period) == 0:
        return {"error": "指定周期内无数据", "_remarks": OUTPUT_REMARKS.strip()}
    
    # 回测
    bt_result = backtest(df_full)
    
    # 信号列表
    period_buys = df_period[df_period['buy_signal']]
    period_sells = df_period[df_period['sell_signal']]
    
    # 统计
    n = len(df_period)
    xx_oversold = (df_period['XX'] < 20).sum() / n * 100 if n > 0 else 0
    xx_overbought = (df_period['XX'] > 80).sum() / n * 100 if n > 0 else 0
    
    # 最新状态
    latest = df.iloc[-1]
    latest_status = 'oversold' if latest['XX'] < 20 else ('overbought' if latest['XX'] > 80 else 'neutral')
    
    # 构建结构化JSON输出
    result = {
        'meta': {
            'code': code,
            'market': market,
            'period': period,
            'data_range': {
                'start': str(df_period['日期'].iloc[0].date()),
                'end': str(df_period['日期'].iloc[-1].date()),
                'trading_days': n,
            },
            'generated_at': datetime.now().isoformat(),
        },
        'signals': {
            'buy_signals': [
                {'date': str(r['日期'].date()), 'close': round(r['收盘'], 3), 'XX': round(r['XX'], 2)}
                for _, r in period_buys.iterrows()
            ],
            'sell_signals': [
                {'date': str(r['日期'].date()), 'close': round(r['收盘'], 3), 'XX': round(r['XX'], 2)}
                for _, r in period_sells.iterrows()
            ],
            'buy_count': len(period_buys),
            'sell_count': len(period_sells),
        },
        'indicator_stats': {
            'XX_mean': round(df_period['XX'].mean(), 2),
            'XX_median': round(df_period['XX'].median(), 2),
            'XX_std': round(df_period['XX'].std(), 2),
            'XX_min': round(df_period['XX'].min(), 2),
            'XX_max': round(df_period['XX'].max(), 2),
            'oversold_pct': round(xx_oversold, 1),
            'overbought_pct': round(xx_overbought, 1),
        },
        'backtest': bt_result,
        'latest': {
            'date': str(latest['日期'].date()),
            'close': round(latest['收盘'], 3),
            'XX': round(latest['XX'], 2),
            'YY': round(latest['YY'], 2),
            'status': latest_status,
            'xx_above_yy': bool(latest['xx_above_yy']),
        },
        '_remarks': OUTPUT_REMARKS.strip(),
    }
    
    # 绘图
    if output_chart:
        chart_path = os.path.join(output_dir, f'{code}_3points.png')
        plot_chart(df_period, code, chart_path)
        result['chart'] = chart_path
    
    return result


# ============================================================
# CLI入口
# ============================================================
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='"3个点"指标分析工具')
    parser.add_argument('code', help='股票/ETF代码')
    parser.add_argument('--period', default='6m', choices=['6m', '1y', 'all'], help='分析周期')
    parser.add_argument('--json', action='store_true', default=True, help='JSON格式输出 (默认)')
    parser.add_argument('--no-chart', action='store_true', help='不生成图表')
    parser.add_argument('--output', default=None, help='图表输出路径')
    parser.add_argument('--data-file', default=None, help='外部K线数据JSON文件路径（来自通达信MCP等数据源）')
    
    args = parser.parse_args()
    output_dir = os.path.dirname(args.output) if args.output else '/workspace'
    
    # 加载外部数据文件
    external_data = None
    if args.data_file:
        try:
            with open(args.data_file, 'r', encoding='utf-8') as f:
                external_data = json.load(f)
        except Exception as e:
            print(json.dumps({
                "error": f"读取外部数据文件失败: {e}",
                "_remarks": OUTPUT_REMARKS.strip()
            }, ensure_ascii=False, indent=2))
            sys.exit(1)
    
    result = analyze(
        code=args.code,
        period=args.period,
        output_chart=not args.no_chart,
        output_dir=output_dir,
        external_data=external_data,
    )
    
    # 覆盖图表路径
    if args.output and 'chart' in result:
        os.rename(result['chart'], args.output)
        result['chart'] = args.output
    
    # 默认输出JSON（供智能体消费）
    print(json.dumps(result, ensure_ascii=False, indent=2))
