---
name: skillhub-skill-runapi-flux-2
description: "Optional RunAPI API key; runapi login or saved CLI config can also authenticate the runapi binary."
---

# Flux 2 on RunAPI

Generate and edit images with Flux 2 through RunAPI. The default path for one-off agent tasks is the `runapi` CLI; SDKs are for application integration.

## Routing decision

- One-off generation, editing, or transformation for the user → use the **CLI path** with the `runapi` binary.
- Building an app, backend, worker, library, or production codebase → use the **SDK integration path**.

## CLI path

The `runapi` binary is the runtime dependency. Authenticate with `runapi login` (browser) or set `RUNAPI_API_KEY`; a saved CLI config also works — no required environment variable.

Inspect the available actions and request fields with CLI help:

```shell
runapi flux-2 --help
runapi flux-2 text-to-image --help
```

Run a one-off task (synchronous — polls until the task completes):

```shell
runapi flux-2 text-to-image --input-file request.json
```

Submit asynchronously and poll separately:

```shell
runapi flux-2 text-to-image --async --input-file request.json
runapi wait <task-id> --service flux-2 --action text-to-image
```

Available actions: `text-to-image`.

## SDK integration path

When integrating Flux 2 into an app, backend, worker, or library — not for one-off tasks — use a RunAPI SDK package:

- JavaScript / TypeScript: `@runapi.ai/flux-2`
- Ruby: `runapi-flux_2`
- Go: `github.com/runapi-ai/flux-2-sdk/go`

## References

- Model overview, pricing, and rate limits: https://runapi.ai/models/flux-2.md
- Provider comparison: https://runapi.ai/providers/black-forest-labs.md
- Full model catalog: https://runapi.ai/models.md

## Variants

- [Flux 2 Pro text to image](https://runapi.ai/models/flux-2/pro-text-to-image.md)
- [Flux 2 Pro image to image](https://runapi.ai/models/flux-2/pro-image-to-image.md)
- [Flux 2 Flex text to image](https://runapi.ai/models/flux-2/flex-text-to-image.md)
- [Flux 2 Flex image to image](https://runapi.ai/models/flux-2/flex-image-to-image.md)

