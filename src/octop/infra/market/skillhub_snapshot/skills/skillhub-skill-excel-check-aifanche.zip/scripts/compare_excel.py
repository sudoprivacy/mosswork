"""Compare two read-only inputs with shared rules and reliable typed identity keys."""
from copy import deepcopy
import argparse,json,re,sys,tempfile
from pathlib import Path
from excel_parser import AuditError,LIMITS,digest,raw,missing,kind,exact,source_value,read_snapshot
from rules_engine import audit,load_config,validate_config,fingerprint
from quality_metrics import sheet_metrics

def load_mapping(path=None):
    if not path:return {'sheets':[]}
    p=Path(path)
    if p.stat().st_size>1024*1024:raise AuditError('映射配置超过1MB。')
    def pairs(items):
        d={}
        for k,v in items:
            if k in d:raise AuditError('映射JSON有重复键。')
            d[k]=v
        return d
    try:c=json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs)
    except (ValueError,UnicodeError):raise AuditError('映射配置不是有效JSON。')
    return validate_mapping(c)

def validate_mapping(c):
    if not isinstance(c,dict) or set(c)!={'sheets'} or not isinstance(c['sheets'],list):raise AuditError('映射须为包含sheets数组的对象。')
    used_before=set();used_after=set()
    for pair in c['sheets']:
        if not isinstance(pair,dict) or set(pair)-{'before','after','keys','fields'} or not {'before','after'}<=set(pair):raise AuditError('Sheet映射需before/after，可选keys/fields。')
        if any(not isinstance(pair[x],str) or not pair[x].strip() for x in ('before','after')):raise AuditError('Sheet名称不能为空。')
        if pair['before'] in used_before or pair['after'] in used_after:raise AuditError('不支持一对多、多对一或重复Sheet映射。')
        used_before.add(pair['before']);used_after.add(pair['after'])
        keys=pair.get('keys',[]);fields=pair.get('fields',{})
        if not isinstance(keys,list) or any(not isinstance(x,str) or not x.strip() for x in keys) or len(set(keys))!=len(keys):raise AuditError('主键须为无重复的字段名数组。')
        if not isinstance(fields,dict) or any(not isinstance(k,str) or not k.strip() or not isinstance(v,str) or not v.strip() for k,v in fields.items()) or len(set(fields.values()))!=len(fields):raise AuditError('字段映射须一一对应，名称不能为空。')
    return c

def pair_sheets(before,after,mapping):
    pairs=[];used_b=set();used_a=set()
    for p in mapping['sheets']:
        if p['before'] not in before or p['after'] not in after:raise AuditError('显式映射的Sheet不存在，请确认文件及名称。')
        pairs.append(p);used_b.add(p['before']);used_a.add(p['after'])
    for name in before:
        if name in after and name not in used_b and name not in used_a:
            pairs.append({'before':name,'after':name});used_b.add(name);used_a.add(name)
    for name in before:
        if name not in used_b:pairs.append({'before':name,'after':None})
    for name in after:
        if name not in used_a:pairs.append({'before':None,'after':name})
    return pairs

def mapped_config(config,pairs):
    """Translate the ONE canonical before-name policy, never invent a second policy."""
    out=deepcopy(config);out['sheets']={}
    for p in pairs:
        b,a=p['before'],p['after']
        if not b or not a:continue
        if b not in config['sheets']:continue
        s=deepcopy(config['sheets'][b]);mapping=p.get('fields',{})
        referenced=set(s.get('required_fields',[])+s.get('key_fields',[])+s.get('required_columns',[]))
        referenced.update(x for group in s.get('unique_keys',[]) for x in group)
        for key in ('field_types','numeric_ranges','date_ranges','allowed_values'):referenced.update(s.get(key,{}))
        targets=[mapping.get(field,field) for field in referenced]
        if len(targets)!=len(set(targets)):
            raise AuditError('字段映射使多个规则字段合并到同一目标，可能覆盖规则；请补全一一对应映射或确认比较方案。')
        for key in ('required_fields','key_fields','required_columns'):
            if key in s:s[key]=[mapping.get(x,x) for x in s[key]]
        if 'unique_keys' in s:s['unique_keys']=[[mapping.get(x,x) for x in g] for g in s['unique_keys']]
        for key in ('field_types','numeric_ranges','date_ranges','allowed_values'):
            if key in s:s[key]={mapping.get(x,x):v for x,v in s[key].items()}
        out['sheets'][a]=s
    # Before-only rules still run on before; after-only sheets get the same default engine.
    return validate_config(out)

def reliable_keys(table,keys):
    if not keys:return None,'未指定唯一主键；不能按行号匹配。',[]
    if not table['usable']:return None,'表结构不明确，不能进行记录匹配。',[]
    if set(keys)-set(table['headers']):return None,'主键字段不存在：'+','.join(sorted(set(keys)-set(table['headers']))),[]
    found={};bad=[]
    for rec in table['records']:
        cells=[rec['cells'][x] for x in keys]
        if any(kind(c) in ('公式','错误值') or missing(c.value) for c in cells):
            bad.append((rec['row'],','.join(c.coordinate for c in cells),'主键为空/公式/错误格'));continue
        key=tuple(exact(c) for c in cells)
        if key in found:bad.append((rec['row'],','.join(c.coordinate for c in cells),'主键与第'+str(found[key]['row'])+'行重复'))
        else:found[key]=rec
    if bad:return None,'主键有缺失或重复；整张配对Sheet停止逐条匹配。',bad
    return found,'主键完整且唯一',[]

def compare(before_path,after_path,config=None,mapping=None,after_config=None):
    config=validate_config(config or {});mapping=validate_mapping(mapping or {'sheets':[]})
    # A direct caller cannot bypass mapping validation by passing an arbitrary object.
    if not isinstance(mapping,dict) or 'sheets' not in mapping:raise AuditError('映射配置不合法。')
    if after_config is not None and fingerprint(config)!=fingerprint(after_config):raise AuditError('前后检查规则不一致；请确认同一套规则后重试，不生成质量改善结论。')
    paths=[Path(before_path).resolve(),Path(after_path).resolve()];hashes=[digest(p) for p in paths]
    # Preliminary shared parsing: avoids applying renamed fields to an unrelated schema.
    neutral=deepcopy(config)
    for s in neutral['sheets'].values():
        for key in list(s):
            if key!='header_row':s.pop(key)
    rb=audit(paths[0],neutral)
    # After header row can be explicitly named by before policy, paired by mapping.
    headers_after={'sheets':{},'checks':config['checks'],'iqr_min_samples':config['iqr_min_samples'],'iqr_multiplier':config['iqr_multiplier']}
    for p in mapping['sheets']:
        if p.get('before') in config['sheets']:headers_after['sheets'][p['after']]={'header_row':config['sheets'][p['before']].get('header_row',1)}
    # Same-name headers when not explicitly mapped.
    from openpyxl import load_workbook
    from excel_parser import inspect_archive
    inspect_archive(paths[1]);wb=load_workbook(paths[1],read_only=True,keep_links=False)
    try:after_names=set(wb.sheetnames)
    finally:wb.close()
    for name,s in config['sheets'].items():
        if name in after_names and name not in headers_after['sheets']:headers_after['sheets'][name]={'header_row':s.get('header_row',1)}
    ra=audit(paths[1],headers_after)
    sb=read_snapshot(paths[0],neutral,rb['overview']);sa=read_snapshot(paths[1],headers_after,ra['overview'])
    pairs=pair_sheets(sb,sa,mapping)
    before_policy=deepcopy(config);after_policy=mapped_config(config,pairs)
    # Missing schema fields are reported as field-existence violations in comparison,
    # not silently skipped or used as a reason to drop the whole comparison.
    for p in pairs:
        b,a=p['before'],p['after']
        for policy,name,table in ((before_policy,b,sb.get(b)),(after_policy,a,sa.get(a))):
            if not name or not table or name not in policy['sheets']:continue
            s=policy['sheets'][name];refs=set(s.get('required_fields',[])+s.get('key_fields',[])+list(s.get('field_types',{})))
            for key in ('numeric_ranges','date_ranges','allowed_values'):refs.update(s.get(key,{}))
            refs.update(x for group in s.get('unique_keys',[]) for x in group)
            s['required_columns']=sorted(set(s.get('required_columns',[]))|refs)
    rb=audit(paths[0],before_policy);ra=audit(paths[1],after_policy)
    result={'before':str(paths[0]),'after':str(paths[1]),'before_hash':hashes[0],'after_hash':hashes[1],
            'rule_fingerprint':fingerprint(config),'rules':config,'mapping':mapping,
            'overview':[],'metrics':[],'records':[],'changes':[],'structure':[],'unmatched':[],
            'before_audit':rb,'after_audit':ra}
    def emit(target,row):
        if sum(len(result[k]) for k in ('records','changes','structure','unmatched'))>=LIMITS['issues']:raise AuditError('差异明细超过10万条，停止而非截断输出。')
        result[target].append(row)
    for p in pairs:
        b,a=p['before'],p['after'];label=(b or '无')+' → '+(a or '无')
        overview=[b,a,sb[b]['status'] if b else '不存在',sa[a]['status'] if a else '不存在','仅整体指标/结构，未确认记录匹配']
        result['overview'].append(overview)
        bm=sheet_metrics(rb,b);am=sheet_metrics(ra,a)
        for metric in (bm or am):
            bv=bm[metric] if bm else None;av=am[metric] if am else None
            bc=bv['count'] if bv else None;ac=av['count'] if av else None
            br=bv['ratio'] if bv else None;ar=av['ratio'] if av else None
            result['metrics'].append([b,a,metric,bc,ac,ac-bc if bc is not None and ac is not None else None,
                bv['denominator'] if bv else None,av['denominator'] if av else None,br,ar,ar-br if br is not None and ar is not None else None,(bv or av)['unit']])
        if not b or not a:
            overview[4]='无Sheet配对，不推断记录对应'
            emit('structure',[b,a,'新增Sheet' if a else '删除Sheet','', '', '仅比较结构及可用指标，不按行号推断记录对应。'])
            emit('unmatched',[label,'整体','无Sheet配对',None,None,'另一侧Sheet不存在；没有生成逐条记录对应关系。']);continue
        if b!=a:emit('structure',[b,a,'Sheet映射',b,a,'用户显式指定对应，不代表内容完全相同。'])
        if sb[b]['state']!=sa[a]['state']:emit('structure',[b,a,'可见性变化',sb[b]['state'],sa[a]['state'],'只记录结构事实。'])
        if not sb[b]['usable'] or not sa[a]['usable']:
            overview[4]='表结构未确认，不逐条比较'
            emit('unmatched',[label,'整体','表结构未确认',None,None,'已跳过记录和字段映射；指标未检查值留空，不作质量判断。']);continue
        fieldmap=dict(p.get('fields',{}));bh=sb[b]['headers'];ah=sa[a]['headers']
        if set(fieldmap)-set(bh) or set(fieldmap.values())-set(ah):raise AuditError('显式字段映射在源表中不存在，请确认，不能猜测。')
        for field in bh:
            if field not in fieldmap and field in ah and field not in fieldmap.values():fieldmap[field]=field
        if len(set(fieldmap.values()))!=len(fieldmap):raise AuditError('字段映射不是一一对应。')
        for field in bh:
            if field not in fieldmap:emit('structure',[b,a,'删除字段',field,'',f'{b}!表头第{sb[b]["header_row"]}行'])
        for field in ah:
            if field not in fieldmap.values():emit('structure',[b,a,'新增字段','',field,f'{a}!表头第{sa[a]["header_row"]}行'])
        for old,new in fieldmap.items():
            if old!=new:emit('structure',[b,a,'字段映射',old,new,'按用户指定名称对应；含义是否相同需用户确认。'])
        if [fieldmap[x] for x in bh if x in fieldmap]!=[x for x in ah if x in fieldmap.values()]:emit('structure',[b,a,'字段顺序变化',bh,ah,'按字段名匹配，不按列序号匹配。'])
        keys=p.get('keys',[]);afterkeys=[fieldmap.get(k,k) for k in keys]
        left,why_b,bad_b=reliable_keys(sb[b],keys);right,why_a,bad_a=reliable_keys(sa[a],afterkeys)
        if left is None or right is None:
            overview[4]='未指定或主键不可靠，不逐条比较'
            emit('unmatched',[label,'整体','无法精确匹配',None,None,'处理前：'+why_b+'；处理后：'+why_a])
            for side,bad in (('前',bad_b),('后',bad_a)):
                for row,coord,why in bad:emit('unmatched',[label,side,why,row,coord,'整张配对Sheet不生成新增/删除/修改的推断。'])
            continue
        overview[4]='双方主键完整且唯一，已逐条比较'
        for key,rec in left.items():
            if key not in right:emit('records',['删除记录',b,rec['row'],a,None,repr(key),{f:raw(source_value(c)) for f,c in rec['cells'].items()},','.join(c.coordinate for c in rec['cells'].values())])
        for key,rec in right.items():
            if key not in left:emit('records',['新增记录',b,None,a,rec['row'],repr(key),{f:raw(source_value(c)) for f,c in rec['cells'].items()},','.join(c.coordinate for c in rec['cells'].values())])
        for key,old in left.items():
            if key not in right:continue
            new=right[key]
            for bf,af in fieldmap.items():
                oc,nc=old['cells'][bf],new['cells'][af]
                if kind(oc)=='公式' and not isinstance(oc.value,str) or kind(nc)=='公式' and not isinstance(nc.value,str):
                    emit('unmatched',[label,'字段','数组/复杂公式未比较',old['row'],oc.coordinate+' / '+nc.coordinate,'无法可靠序列化该公式对象，不视为相同。']);continue
                if exact(oc)!=exact(nc):emit('changes',[repr(key),b,old['row'],oc.coordinate,bf,raw(source_value(oc)),a,new['row'],nc.coordinate,af,raw(source_value(nc)),f'原类型={kind(oc)}；新类型={kind(nc)}；变化不等于错误。'])
    if [digest(p) for p in paths]!=hashes:raise AuditError('比较期间源文件变化，停止交付。')
    return result

def run(before,after,output_dir,config_path=None,mapping_path=None,before_config=None,after_config=None):
    if sys.version_info<(3,11):raise AuditError('需要Python 3.11或更高版本。')
    if config_path and (before_config or after_config):raise AuditError('共享规则与前后单独规则不能同时提供。')
    if bool(before_config)!=bool(after_config):raise AuditError('检查规则不一致：请提供共享规则，或前后两份相同规则。')
    config=load_config(config_path or before_config)
    other=load_config(after_config) if after_config else None
    result=compare(before,after,config,load_mapping(mapping_path),other)
    out=Path(output_dir).resolve();out.mkdir(parents=True,exist_ok=True)
    directory=Path(tempfile.mkdtemp(prefix='excel-compare-',dir=out))
    from report_generator import render_report,render_comparison
    try:
        for side in ('before','after'):
            target=directory/('处理前' if side=='before' else '处理后');target.mkdir()
            render_report(result[side+'_audit'],target)
        render_comparison(result,directory)
        (directory/'本次比较规则.json').write_text(json.dumps({'rules':result['rules'],'mapping':result['mapping']},ensure_ascii=False,indent=2)+'\n')
        if digest(Path(before))!=result['before_hash'] or digest(Path(after))!=result['after_hash']:raise AuditError('输出期间源文件发生变化，停止交付。')
    except Exception:
        # Only our just-created report artifacts, never source files or prior runs.
        for folder in (directory/'处理前',directory/'处理后'):
            if folder.is_dir():
                for name in ('Excel数据体检报告.xlsx','数据质量摘要.md'):
                    p=folder/name
                    if p.is_file():p.unlink()
                folder.rmdir()
        for name in ('Excel数据差异对比报告.xlsx','差异对比摘要.md','本次比较规则.json'):
            p=directory/name
            if p.is_file():p.unlink()
        directory.rmdir();raise
    return result,directory

def main(argv=None):
    p=argparse.ArgumentParser(description='只读比较两份Excel，绝不按行号猜测记录对应。')
    p.add_argument('before');p.add_argument('after');p.add_argument('--output-dir',required=True)
    p.add_argument('--config');p.add_argument('--mapping');p.add_argument('--before-config');p.add_argument('--after-config')
    a=p.parse_args(argv)
    try:
        r,d=run(a.before,a.after,a.output_dir,a.config,a.mapping,a.before_config,a.after_config)
        print(json.dumps({'status':'completed','source_unchanged':True,'report':str(d/'Excel数据差异对比报告.xlsx'),'summary':str(d/'差异对比摘要.md'),'unmatched_items':len(r['unmatched']),'directory':str(d)},ensure_ascii=False));return 0
    except (AuditError,OSError,ValueError) as e:print('未完成比较：'+str(e)+'；原文件未由本工具修改。',file=sys.stderr)
    except ImportError:print('无法运行，请按README安装requirements。',file=sys.stderr)
    except Exception as e:print('未完成比较：文件无法可靠读取（'+type(e).__name__+'），请另存副本重试；不能当作比较通过。',file=sys.stderr)
    return 2

if __name__=='__main__':sys.exit(main())
