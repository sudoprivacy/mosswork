"""Validated declarative rules only. No eval, exec, code generation or network."""
from copy import deepcopy
from datetime import date, datetime
import json, math, re
from pathlib import Path
from excel_parser import AuditError, RULES, LIMITS, digest, missing, kind, raw, source_value, date_parse, read_snapshot
import basic_checks

SHEET_KEYS={'header_row','required_fields','key_fields','unique_keys','field_types',
            'required_columns','allowed_values','numeric_ranges','date_ranges'}
TYPES={'text','identifier','number','integer','decimal','date'}

def num(v):return type(v) in (int,float) and math.isfinite(v)

def date_value(v):
    if isinstance(v,datetime):return v.date()
    if isinstance(v,date):return v
    if not isinstance(v,str):return None
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%Y.%m.%d','%Y年%m月%d日','%Y-%m-%d %H:%M:%S'):
        try:return datetime.strptime(v,fmt).date()
        except ValueError:pass
    return None

def type_ok(v,t):
    if t in ('number','decimal'):return num(v)
    if t=='integer':return num(v) and v==int(v)
    if t=='date':return date_value(v) is not None
    return isinstance(v,str)

def fields(values,label):
    if not isinstance(values,list) or any(not isinstance(x,str) or not x.strip() for x in values) or len(set(values))!=len(values):
        raise AuditError(label+'须为无重复、非空字段名的数组。')

def endpoint(v,dates=False):
    if dates:
        if not isinstance(v,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',v):raise AuditError('日期边界须为YYYY-MM-DD。')
        try:return date.fromisoformat(v)
        except ValueError:raise AuditError('日期边界不是有效日期。')
    if not num(v):raise AuditError('数值边界须为有限数值，不接受文字、布尔或空值。')
    return v

def validate_config(config):
    if not isinstance(config,dict) or set(config)-{'sheets','checks','iqr_min_samples','iqr_multiplier'}:
        raise AuditError('规则最外层须为对象，且仅包含sheets/checks/iqr_min_samples/iqr_multiplier。')
    c=deepcopy(config)
    check=c.get('checks',{})
    if not isinstance(check,dict) or set(check)-set(RULES) or any(type(x) is not bool for x in check.values()):raise AuditError('checks规则名或开关不合法。')
    c['checks']={r:check.get(r,True) for r in RULES}
    n=c.get('iqr_min_samples',8);factor=c.get('iqr_multiplier',1.5)
    if type(n) is not int or not 8<=n<=100000 or not num(factor) or not 1<=factor<=10:raise AuditError('IQR至少8个样本，系数须在1至10之间。')
    c.update(iqr_min_samples=n,iqr_multiplier=factor)
    sheets=c.setdefault('sheets',{})
    if not isinstance(sheets,dict):raise AuditError('sheets须为工作表名称映射。')
    for name,s in sheets.items():
        if not isinstance(name,str) or not name.strip() or not isinstance(s,dict) or set(s)-SHEET_KEYS:raise AuditError('工作表名称或配置项目不合法。')
        if type(s.get('header_row',1)) is not int or not 1<=s.get('header_row',1)<=LIMITS['rows']:raise AuditError('header_row须为正整数且不超行数上限。')
        for key in ('required_fields','key_fields','required_columns'):fields(s.get(key,[]),key)
        groups=s.get('unique_keys',[])
        if not isinstance(groups,list):raise AuditError('unique_keys须为字段组合数组。')
        for group in groups:
            fields(group,'unique_keys')
            if not group:raise AuditError('唯一字段组合不能为空。')
        if len({tuple(g) for g in groups})!=len(groups):raise AuditError('唯一性规则有重复组合。')
        ft=s.get('field_types',{})
        if not isinstance(ft,dict) or any(not isinstance(k,str) or not k.strip() or not isinstance(v,str) or v not in TYPES for k,v in ft.items()):raise AuditError('field_types不合法，支持text/identifier/integer/decimal/number/date。')
        if s.get('required_fields') and not c['checks']['missing'] or s.get('unique_keys') and not c['checks']['duplicates'] or ft and not c['checks']['types']:
            raise AuditError('明确的必填/唯一/类型规则与对应检查关闭设置冲突，请确认。')
        for key in ('allowed_values','numeric_ranges','date_ranges'):
            entries=s.get(key,{})
            if not isinstance(entries,dict):raise AuditError(key+'须为字段名映射。')
            for field,rule in entries.items():
                if not isinstance(field,str) or not field.strip() or not isinstance(rule,dict):raise AuditError(key+'字段或规则格式不正确。')
                allowed={'values','allow_empty'} if key=='allowed_values' else {'min','max','include_min','include_max','allow_empty'}
                if set(rule)-allowed:raise AuditError(key+'有未知参数。')
                if any(type(rule[x]) is not bool for x in ('allow_empty','include_min','include_max') if x in rule):raise AuditError('边界包含及空值参数须为true/false。')
                rule.setdefault('allow_empty',True)
                if key=='allowed_values':
                    vals=rule.get('values')
                    if not isinstance(vals,list) or not vals or any(type(x) not in (str,int,float,bool) or isinstance(x,float) and not math.isfinite(x) for x in vals):raise AuditError('允许值须为非空的JSON标量数组，不支持null/对象/代码。')
                    if any(isinstance(v,str) and not v.strip() for v in vals):raise AuditError('允许值集合不放空白字符串；空值策略请通过allow_empty指定。')
                    if ft.get(field) and any(not type_ok(x,ft[field]) for x in vals):raise AuditError(field+'的允许值与字段类型冲突，请确认规则。')
                else:
                    if not {'min','max'}&set(rule):raise AuditError('范围至少提供一个边界。')
                    rule.setdefault('include_min',True);rule.setdefault('include_max',True)
                    lo=endpoint(rule['min'],key=='date_ranges') if 'min' in rule else None
                    hi=endpoint(rule['max'],key=='date_ranges') if 'max' in rule else None
                    if lo is not None and hi is not None and (lo>hi or lo==hi and not (rule['include_min'] and rule['include_max'])):raise AuditError(field+'的范围为空或上下界冲突，请确认。')
                    allowed_types={'date'} if key=='date_ranges' else {'integer','decimal','number'}
                    if field in ft and ft[field] not in allowed_types:raise AuditError(field+'的范围与字段类型冲突。')
                    if key=='numeric_ranges' and ft.get(field)=='integer' and lo is not None and hi is not None:
                        integer_lo=math.ceil(lo) if rule['include_min'] else math.floor(lo)+1
                        integer_hi=math.floor(hi) if rule['include_max'] else math.ceil(hi)-1
                        if integer_lo>integer_hi:raise AuditError(field+'要求整数，但指定区间内不存在整数，请确认。')
        if set(s.get('numeric_ranges',{}))&set(s.get('date_ranges',{})):raise AuditError('同一字段不能同时使用数值范围和日期范围。')
        # Detect clearly impossible permitted values versus a range.
        for field,allowed in s.get('allowed_values',{}).items():
            for key in ('numeric_ranges','date_ranges'):
                if field in s.get(key,{}):
                    rule=s[key][field]
                    if not any(in_range(v,rule,key=='date_ranges') for v in allowed['values']):raise AuditError(field+'的允许值集合与范围完全冲突。')
    return c

def in_range(value,rule,dates=False):
    v=date_value(value) if dates else value if num(value) else None
    if v is None:return False
    lo=endpoint(rule['min'],dates) if 'min' in rule else None
    hi=endpoint(rule['max'],dates) if 'max' in rule else None
    return not ((lo is not None and (v<lo or v==lo and not rule.get('include_min',True))) or
                (hi is not None and (v>hi or v==hi and not rule.get('include_max',True))))

def load_config(path=None):
    if not path:return validate_config({})
    p=Path(path)
    if p.stat().st_size>1024*1024:raise AuditError('规则文件超过1MB。')
    def pairs(items):
        d={}
        for k,v in items:
            if k in d:raise AuditError('JSON规则有重复键：'+k)
            d[k]=v
        return d
    try:return validate_config(json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs))
    except (ValueError,UnicodeError):raise AuditError('规则不是有效UTF-8 JSON，请参考配置示例。')

def audit(path,config=None):
    config=validate_config(config or {})
    extended=any(any(s.get(k) for k in ('required_columns','allowed_values','numeric_ranges','date_ranges')) or 'integer' in s.get('field_types',{}).values() for s in config['sheets'].values())
    if not extended:
        base=deepcopy(config)
        for s in base['sheets'].values():
            if 'field_types' in s:s['field_types']={k:('number' if v=='decimal' else v) for k,v in s['field_types'].items()}
        result=basic_checks.audit(path,base)
        set_levels(result,config)
        result['config']=config;result['rule_fingerprint']=fingerprint(config);refresh_counts(result)
        return result
    # Extended types are reduced only for the existing baseline type checker;
    # integer integrality and all additional rules are enforced below.
    base=deepcopy(config)
    missing_columns={}
    # Read structural decisions with a neutral baseline before applying business rules.
    neutral=deepcopy(config)
    for s in neutral['sheets'].values():
        for k in list(s):
            if k!='header_row':s.pop(k)
    preliminary=basic_checks.audit(path,neutral)
    snapshot=read_snapshot(path,config,preliminary['overview'])
    for name,s in base['sheets'].items():
        headers=snapshot[name]['headers']
        declared=s.get('required_columns',[])
        absent=set(declared)-set(headers) if snapshot[name]['usable'] or snapshot[name]['empty'] else set()
        missing_columns[name]=absent
        for key in ('required_fields','key_fields'):
            s[key]=[x for x in s.get(key,[]) if x not in absent]
        s['unique_keys']=[g for g in s.get('unique_keys',[]) if not set(g)&absent]
        s['field_types']={k:('number' if v in ('integer','decimal') else v) for k,v in s.get('field_types',{}).items() if k not in absent}
        for key in ('required_columns','allowed_values','numeric_ranges','date_ranges'):s.pop(key,None)
    result=basic_checks.audit(path,base)
    set_levels(result,config)
    def add(sheet,row,coord,field,type_,value,basis):
        if len(result['issues'])>=LIMITS['issues']:raise AuditError('问题超过10万条，停止而非输出截断报告。')
        result['issues'].append(dict(sheet=sheet,row=row,cell=coord,field=field,type=type_,certainty='确定问题',level='规则违规',severity='高',value=raw(value),basis=basis,advice='请核对来源和已确认的规则；本工具不修改数据。'))
    skipped_custom={}
    for name,s in config['sheets'].items():
        table=snapshot[name]
        headers=table['headers']
        for field in sorted(missing_columns[name]):
            add(name,table['header_row'],f'A{table["header_row"]}',field,'要求字段不存在','',
                '用户明确要求该字段存在；位置指向表头/检查起点，缺失字段无实际单元格；全空Sheet也不满足字段存在规则。')
            result['notes'].append((name,field+'不存在，依赖它的记录级规则未执行。'))
        if not table['usable']:
            if s:result['notes'].append((name,'表内没有可用数据区域，记录级自定义规则未执行，不表示已通过。'))
            continue
        for key in ('allowed_values','numeric_ranges','date_ranges'):
            for field in s.get(key,{}):
                if field not in headers and field not in missing_columns[name]:raise AuditError(name+'配置字段不存在：'+field)
        for record in table['all_records']:
            for field,cell in record['cells'].items():
                value=cell.value
                rules=[(key,s.get(key,{}).get(field)) for key in ('allowed_values','numeric_ranges','date_ranges')]
                if kind(cell) in ('公式','错误值'):
                    if any(rule for _,rule in rules) or s.get('field_types',{}).get(field)=='integer':
                        skipped_custom[name,field]=skipped_custom.get((name,field),0)+1
                    continue
                if s.get('field_types',{}).get(field)=='integer' and num(value) and value!=int(value) and config['checks']['types']:
                    add(name,record['row'],cell.coordinate,field,'整数类型不符合规则',source_value(cell),'用户要求整数，原始数值存在小数部分；未转换。')
                for key,rule in rules:
                    if rule is None:continue
                    if missing(value):
                        if not rule['allow_empty']:add(name,record['row'],cell.coordinate,field,'自定义规则不允许空值',value,key+'明确设置allow_empty=false。')
                        continue
                    if key=='allowed_values':
                        # bool and numeric values must not compare equal by Python coercion.
                        good=any(value==v and (type(value) is bool)==(type(v) is bool) for v in rule['values'])
                    else:good=in_range(value,rule,key=='date_ranges')
                    if not good:add(name,record['row'],cell.coordinate,field,{'allowed_values':'不在允许值集合','numeric_ranges':'不满足数值范围','date_ranges':'不满足日期范围'}[key],source_value(cell),
                                    '用户规则='+json.dumps(rule,ensure_ascii=False)+'；不转换文本数值；日期范围按日比较。')
    for (name,field),count in skipped_custom.items():result['notes'].append((name,f'{field}有{count}个公式/错误格，自定义范围/集合/整数规则未执行，不视为通过。'))
    if preliminary['source_sha256']!=result['source_sha256']:raise AuditError('规则检查期间源文件变化，停止交付。')
    result['config']=config;result['rule_fingerprint']=fingerprint(config)
    refresh_counts(result)
    if digest(Path(path))!=result['source_sha256']:raise AuditError('检查期间源文件变化，停止交付。')
    return result

def fingerprint(config):
    import hashlib
    return hashlib.sha256(json.dumps(validate_config(config),sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def set_levels(result,config):
    for x in result['issues']:
        x['level']='确定错误' if x['type'] in ('公式缓存错误','Excel已有错误值') else '规则违规' if x['certainty']=='确定问题' else x['certainty']
        declared=config.get('sheets',{}).get(x['sheet'],{}).get('field_types',{}).get(x['field'])
        if x['type']=='字段类型不符合规则' and declared in ('integer','decimal'):
            x['basis']=x['basis'].replace('类型为number','类型为'+declared)

def refresh_counts(result):
    from collections import Counter
    for o in result['overview']:
        issues=[x for x in result['issues'] if x['sheet']==o['sheet']]
        o.update(certain=sum(x['certainty']=='确定问题' for x in issues),suspected=sum(x['certainty']=='疑似异常' for x in issues),info=sum(x['certainty']=='检查提示' for x in issues),
                 errors=sum(x['level']=='确定错误' for x in issues),violations=sum(x['level']=='规则违规' for x in issues),counts=dict(Counter(x['type'] for x in issues)))
    hits=Counter()
    for x in result['issues']:
        if x['type']=='要求字段不存在':continue  # A1 is a header pointer, not a violation of the existing first field.
        columns={m[1] for coord in x['cell'].split(',') if (m:=re.fullmatch(r'([A-Z]+)\d+',coord))}
        for column in columns:hits[x['sheet'],column]+=1
    for f in result['fields']:f['anomalies']=hits[f['sheet'],f['column']]
