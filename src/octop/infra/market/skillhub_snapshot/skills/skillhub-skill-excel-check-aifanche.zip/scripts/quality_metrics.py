"""Metrics explicitly retain denominators and uncertainty; no quality score."""
def sheet_metrics(result,sheet):
    o=next((x for x in result['overview'] if x['sheet']==sheet),None)
    if o is None:return None
    issues=[x for x in result['issues'] if x['sheet']==sheet]
    rows=o['rows'];cells=rows*o['fields'];blocked=o.get('structure_blocked',False)
    def metric(value,denom,unit):
        return {'count':None if blocked else value,'denominator':None if blocked else denom,
                'ratio':value/denom if denom and not blocked else None,'unit':unit}
    duplicates={x['row'] for x in issues if x['type'] in ('完全重复记录','关键字段重复','唯一约束重复')}
    formats={x['cell'] for x in issues if x['type'] in ('字段类型不符合规则','混合数据类型','日期无法解析','日期格式混用','整数类型不符合规则')}
    return {
        '数据行数':{'count':rows,'denominator':None,'ratio':None,'unit':'行；结构不明时仅候选范围'},
        '字段数量':{'count':o['fields'],'denominator':None,'ratio':None,'unit':'字段；结构不明时仅候选范围'},
        '缺失值':metric(o['missing'],cells,'缺失格/数据格'),
        '重复记录':metric(len(duplicates),rows,'后续重复行/数据行；不重复计同一行'),
        '数据格式问题':metric(len(formats),cells,'格式命中格/数据格；同格去重'),
        '公式或已有错误':metric(sum(x['level']=='确定错误' for x in issues),o.get('scanned_cells',0),'已有错误命中数/实际扫描格（含标题/表头）；不代表重算'),
        '疑似异常':metric(sum(x['level']=='疑似异常' for x in issues),rows,'疑似命中次数/数据行；可大于1'),
        '自定义规则违规':metric(sum(x['level']=='规则违规' for x in issues),rows,'规则命中次数/数据行；可大于1')}
