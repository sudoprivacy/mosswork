from __future__ import annotations
from collections import Counter, defaultdict
from datetime import date, datetime, time
import argparse, hashlib, json, math, os, re, statistics, sys, tempfile, unicodedata, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from excel_parser import *

def safe_cell(ws,value):
    """Write every source-derived string as literal OOXML text, never a formula."""
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
    if isinstance(value,(list,dict)): value=json.dumps(value,ensure_ascii=False,default=raw)
    if isinstance(value,str):
        value=ILLEGAL_CHARACTERS_RE.sub(lambda m:f'\\u{ord(m[0]):04x}',value)
        if len(value)>30000: value=value[:30000]+'…[报告显示截断，原件未改]'
    cell=WriteOnlyCell(ws,value=value)
    if isinstance(value,str): cell.data_type='s'
    return cell


def render_report(result,directory):
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb=Workbook(write_only=True)
    wb.properties.creator='Excel 数据体检';wb.properties.title='数据质量检查报告'
    def tab(name,headers,rows,widths):
        ws=wb.create_sheet(name);ws.sheet_view.showGridLines=False;ws.freeze_panes='C2' if name=='问题明细' else 'A2'
        for j,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(j)].width=w
        cells=[safe_cell(ws,x) for x in headers]
        for cell in cells:
            cell.font=Font(name='Arial',size=11,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='234D44');cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
        ws.row_dimensions[1].height=34;ws.append(cells)
        count=1
        for values in rows:
            count+=1;row=[]
            max_lines=1
            for j,value in enumerate(values):
                cell=safe_cell(ws,value);cell.font=Font(name='Arial',size=11)
                cell.alignment=Alignment(vertical='top',wrap_text=True)
                if value in ('确定错误','规则违规','疑似异常'):
                    cell.font=Font(name='Arial',size=11,bold=True,color='865A10' if value=='疑似异常' else '9C2F26')
                if isinstance(value,float) and 0<=value<=1 and name=='字段质量概况': cell.number_format='0.0%'
                if name=='检查总览' and j==8 and isinstance(value,(int,float)):cell.number_format='0.0%'
                rendered=raw(cell.value)
                lines=sum(max(1,math.ceil(sum(2 if unicodedata.east_asian_width(ch) in ('W','F') else 1 for ch in part)/max(4,widths[j]-3))) for part in rendered.split('\n'))
                max_lines=max(max_lines,lines)
                row.append(cell)
            ws.row_dimensions[count].height=min(409,max(30,max_lines*16+12))
            ws.append(row)
        ws.auto_filter.ref=f'A1:{get_column_letter(len(headers))}{count}'
    tab('检查总览',['文件名','工作表名称','可见性','检查状态','数据行数','字段数','完全空白行','缺失单元格','缺失比例','确定错误数量','规则违规数量','疑似异常数量','检查提示数量','各类问题数量'],
        ([result['source_name'],o['sheet'],o['state'],o['status'],o['rows'],o['fields'],o['blanks'] if not o.get('structure_blocked') else '未检查',o['missing'] if not o.get('structure_blocked') else '未检查',o['missing_ratio'] if not o.get('structure_blocked') else '未检查',o['errors'],o['violations'],o['suspected'],o['info'],json.dumps(o['counts'],ensure_ascii=False)] for o in result['overview']),[28,20,14,28,14,12,14,14,14,14,14,14,14,55])
    tab('问题明细',['序号','Sheet名称','行号','单元格位置','字段名称','问题类型','结果等级','严重程度','原始值','判断依据','处理建议'],
        ([i,x['sheet'],x['row'],x['cell'],x['field'],x['type'],x['level'],x['severity'],x['value'],x['basis'],x['advice']] for i,x in enumerate(result['issues'],1)),[10,18,10,24,24,24,18,14,35,62,50])
    tab('字段质量概况',['Sheet名称','字段名称','列位置','数据类型概况','非空数量','缺失数量','缺失比例','异常数量（命中次数）'],
        ([f['sheet'],f['field'],f['column'],f['types'],f['nonempty'],f['missing'],f['ratio'],f['anomalies']] for f in result['fields']),[20,24,12,48,14,14,14,22])
    notes=[('版本','1.0 完整版（1.0.0）'),('输入SHA-256',result['source_sha256']),('检查规则',json.dumps(result['config'],ensure_ascii=False)),('规则指纹',result['rule_fingerprint']),
        ('计数口径','数据行含内部空白行，不含末尾空白/仅格式行。问题数按规则命中次数，不是独立坏单元格数；同格可命中多项。缺失统计是事实，不等于错误。'),
        ('适用条件','每Sheet一张单层表，默认首行为非空、不重复的文本字段名；结构不明的Sheet跳过字段检查。不能保证识别任意多表混排。'),
        ('公式限制','只查看已有Excel错误类型和公式缓存，不计算公式，不执行宏；缓存可能过期。无缓存不是公式错误。公式不参与重复、格式及IQR。'),
        ('字段限制','日期仅识别明确年/月/日及原生日期；不猜月日顺序、序列号；文本数字不强制转换。IQR不是业务规则，零/负数不自动报错。'),
        ('IQR条件','默认纯数值非编号列，至少8个有限数值，inclusive四分位数、1.5倍IQR；IQR为0跳过。'),
        ('只读及隐私','源文件不写入；未处理评论、图片、图表、隐藏行列标记、外部数据连接的语义，也未判断宏内容。报告含原始值，视同敏感文件。'),
        ('性能上限','30MB输入、200MB解压、30Sheet、每Sheet10万行/200列、全簿100万格、10万条问题；超限整体停止，不输出部分通过。'),
        ('安全文本','报告中的源文本以文字类型保存，包括=、+、-、@开头内容；非法控制字符转义，超长显示截断。极长内容可用编辑栏查看；不要将其复制到其他表后执行。')]
    notes.extend((sheet,message) for sheet,message in result['notes'])
    tab('检查规则与限制说明',['范围/规则','说明'],notes,[28,115])
    report=directory/'Excel数据体检报告.xlsx';wb.save(report)
    # Verify the actual saved artifact, including injection protection.
    check=load_workbook(report,read_only=True,data_only=False,keep_links=False)
    try:
        if check.sheetnames!=['检查总览','问题明细','字段质量概况','检查规则与限制说明']: raise AuditError('报告结构校验失败。')
        for ws in check:
            if any(c.data_type=='f' for row in ws for c in row): raise AuditError('报告文本安全校验失败。')
    finally: check.close()
    errors=sum(o['errors'] for o in result['overview']);violations=sum(o['violations'] for o in result['overview']);suspect=sum(o['suspected'] for o in result['overview'])
    def md(s): return re.sub(r'([\\`*_{}\[\]<>|#!])',r'\\\1',raw(s)).replace('\n',' ')
    summary=['# 数据质量摘要','',f'文件：{md(result["source_name"])}',f'版本：{VERSION}',f'原件校验 SHA-256：{result["source_sha256"]}',
             '',f'共读取{len(result["overview"])}张工作表；发现{errors}条确定错误、{violations}条规则违规、{suspect}条疑似异常（按规则命中计数，不是独立坏记录数）。',
             '确定错误是文件已存储的Excel错误；规则违规来自用户明确约束；疑似异常不是错误。不表示其他数据已获业务验收。','', '## 检查了哪些数据','']
    for o in result['overview']: summary.append(f'- {md(o["sheet"])}：{o["rows"]}行、{o["fields"]}字段；{o["status"]}；{o["state"]}。')
    for label in ('确定错误','规则违规','疑似异常'):
        summary+=['',f'## {label}','']
        counts=Counter(x['type'] for x in result['issues'] if x['level']==label)
        summary += [f'- {md(k)}：{v}条。' for k,v in counts.items()] or ['本次启用范围内未发现；不代表未执行项目没有问题。']
    summary+=['','## 优先处理和人工判断','',
              '先核对Excel已有错误及明确业务约束；再确认疑似重复/日期格式，最后评估统计离群值。不要按报告自动删除记录。',
              '每条具体问题请在Excel报告“问题明细”按Sheet、行及坐标回查。“检查提示”和跳过项目不能当作检查通过。',
              '未指定必填字段时，空值仅做统计；相同姓名/日期不默认是业务重复；没有规则时不把零、负数当错。',
              '公式未计算，空缓存可能为正常空结果；宏不运行。复杂表头、合并单元格、多表混排需人工确认。',
              '报告含原始值，请按源文件同等权限保存。程序本地执行且没有网络调用；外部对话工具如何处理文件需另行确认。','', '## 未执行或需要确认','']
    summary += [f'- {md(s)}：{md(n)}' for s,n in result['notes']]
    summary+=['', '禁用规则：'+('、'.join(k for k,v in result['checks'].items() if not v) or '无')]
    (directory/'数据质量摘要.md').write_text('\n'.join(summary)+'\n',encoding='utf-8')


def render_comparison(result,directory):
    from openpyxl import Workbook,load_workbook
    from openpyxl.styles import Font,PatternFill,Alignment
    from openpyxl.utils import get_column_letter
    wb=Workbook(write_only=True);wb.properties.creator='Excel 数据体检'
    def tab(name,headers,rows,widths):
        ws=wb.create_sheet(name);ws.sheet_view.showGridLines=False;ws.freeze_panes='C2'
        for i,width in enumerate(widths,1):ws.column_dimensions[get_column_letter(i)].width=width
        cells=[safe_cell(ws,x) for x in headers]
        for c in cells:
            c.font=Font(name='Arial',size=11,bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='234D44');c.alignment=Alignment(wrap_text=True,vertical='center',horizontal='center')
        ws.row_dimensions[1].height=40;ws.append(cells)
        n=1
        for values in rows:
            n+=1;row=[];height=30
            for i,value in enumerate(values):
                c=safe_cell(ws,value);c.font=Font(name='Arial',size=11);c.alignment=Alignment(wrap_text=True,vertical='top')
                if name=='数据质量指标变化' and i in (8,9,10) and isinstance(value,(float,int)):
                    c.number_format='0.000" 次/行"' if values[2] in ('疑似异常','自定义规则违规') else '0.0%'
                length=sum(2 if unicodedata.east_asian_width(ch) in ('W','F') else 1 for ch in raw(c.value))
                height=max(height,min(409,math.ceil(length/max(4,widths[i]-3))*16+12));row.append(c)
            ws.row_dimensions[n].height=height;ws.append(row)
        ws.auto_filter.ref=f'A1:{get_column_letter(len(headers))}{n}'
    tab('对比总览',['处理前Sheet','处理后Sheet','处理前状态','处理后状态','记录匹配状态'],result['overview'],[25,25,35,35,55])
    tab('数据质量指标变化',['处理前Sheet','处理后Sheet','指标','处理前数量','处理后数量','变化量(后-前)','处理前分母','处理后分母','处理前比率','处理后比率','比率变化','比率口径'],result['metrics'],[22,22,26,16,16,20,16,16,16,16,16,60])
    tab('新增与删除记录',['变化类型','处理前Sheet','处理前行','处理后Sheet','处理后行','主键(含原始类型)','原始记录','对应侧单元格'],result['records'],[18,22,14,22,14,36,85,50])
    tab('已匹配记录的字段变化',['主键(含原始类型)','处理前Sheet','原行号','原位置','原字段','原始值','处理后Sheet','新行号','新位置','新字段','新值','说明'],result['changes'],[36,22,12,18,22,40,22,12,18,22,40,48])
    tab('Sheet和字段结构变化',['处理前Sheet','处理后Sheet','结构变化类型','处理前','处理后','依据/来源'],result['structure'],[22,22,22,42,42,75])
    tab('无法匹配及待确认事项',['比较分组','来源侧/范围','原因','来源行号','来源单元格','限制与处理'],result['unmatched'],[40,16,40,14,40,90])
    notes=[['比较前文件',Path(result['before']).name],['比较后文件',Path(result['after']).name],['前文件SHA-256',result['before_hash']],['后文件SHA-256',result['after_hash']],
           ['统一逻辑规则指纹',result['rule_fingerprint']],['检查规则',json.dumps(result['rules'],ensure_ascii=False)],['映射规则',json.dumps(result['mapping'],ensure_ascii=False)],
           ['同一规则','对比以同一份已验证的逻辑规则执行；字段/Sheet映射仅改名。要求规则的字段消失时作为字段存在性违规，不当零问题。两份单独规则不一致则拒绝比较。'],
           ['统计口径','变化量=处理后-处理前。比率附分母；规则/疑似每行命中次数用次/行，可能大于1，不是坏行百分比。公式/已有错误以含标题表头的实际扫描格为分母。数据格包括空值；检查范围见双方报告。'],
           ['规模变化','行/字段增减、删除问题行或检查覆盖变化均会影响数量，数量下降不等于修复正确。不存在或未检查的指标留空，不把它当0。'],
           ['身份匹配','只有用户指定的主键/组合主键在双方完整、唯一且非公式/错误值时才匹配；内部完全空白行不作为业务记录。任一侧不可靠则整张配对Sheet降级，禁止按行号猜测。'],
           ['类型与值','按原始类型和值比较，不转数值、不去空格、不忽略大小写。数值1与1.0相等，文字001与数字1不同；主键修改会呈现新增/删除，不猜为同一记录。'],
           ['字段映射','未映射同名字段自动对应；改名字段仅按用户显式映射。未知映射、重复映射拒绝。无主键仍输出结构及整体质量，不自动选择姓名或第一列作键。'],
           ['公式与格式','公式比较保存的公式文本，不重算或单独比较缓存值，不核验渲染样式/图表/批注/宏/隐藏行列。已有缓存错误在双方质量报告中呈现。'],
           ['解释与安全','变化不是错误，不自动清洗，不提供任何写回入口。报告原始值是文字，超长显示会标截断；两份源文件及报告均需同等权限保护。'],
           ['数据规模上限','每份输入沿用30MB、200MB解压、30Sheet、全簿100万格等限制；差异明细合计超过10万条停止，不输出截断通过。']]
    tab('比较规则与限制说明',['项目','说明'],notes,[32,120])
    output=directory/'Excel数据差异对比报告.xlsx';wb.save(output)
    check=load_workbook(output,read_only=True,data_only=False,keep_links=False)
    try:
        if len(check.worksheets)!=7 or any(c.data_type=='f' for ws in check for row in ws for c in row):raise AuditError('差异报告安全或结构校验失败。')
    finally:check.close()
    lines=['# Excel数据差异对比摘要','',f'配对/单侧Sheet分组：{len(result["overview"])}；新增/删除记录明细：{len(result["records"])}；已匹配字段变化：{len(result["changes"])}；无法匹配及待确认事项：{len(result["unmatched"])}。',
           '', '这里只报告可验证的变化，不把变化当作错误，也不凭问题数量下降认定质量改善。',
           '两侧检查报告分别位于“处理前”“处理后”目录。请同时看数量、分母、比率和来源位置。空白指标表示不存在/未执行，不是0。',
           '未给可靠主键时，只比较整体指标和结构。主键变更表现为新增/删除，公式不重算；业务含义是否相同需人工确认。',
           '原文件未由本工具修改，摘要不包含自动修复结论。详见差异报告“无法匹配及待确认事项”。']
    (directory/'差异对比摘要.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


