from __future__ import annotations
from collections import Counter, defaultdict
from datetime import date, datetime, time
import argparse, hashlib, json, math, os, re, statistics, sys, tempfile, unicodedata, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from dataclasses import dataclass

VERSION="1.0.0"
LIMITS=dict(file_mb=30,unpacked_mb=200,sheets=30,rows=100000,columns=200,cells=1000000,issues=100000,xml_entries=5000)
RULES=("missing","duplicates","types","dates","outliers","formula_errors")

class AuditError(Exception):
    """Safe, user-facing failure."""


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def missing(v):
    return v is None or isinstance(v, str) and not v.strip()


def kind(cell):
    v = cell.value
    if missing(v): return '空值'
    if cell.data_type == 'f': return '公式'
    if cell.data_type == 'e': return '错误值'
    if isinstance(v, bool): return '布尔'
    if isinstance(v, (datetime, date, time)): return '日期/时间'
    if isinstance(v, (int, float)): return '数值'
    return '文本'


def raw(v):
    if isinstance(v, (datetime, date, time)): return v.isoformat()
    return str(v) if v is not None else ''


def source_value(cell):
    value = cell.value
    if (kind(cell) == '数值' and math.isfinite(value) and value >= 0
            and value == int(value) and re.fullmatch('0{2,1000}', cell.number_format)):
        return f'存储值={raw(value)}；显示值={int(value):0{len(cell.number_format)}d}；格式={cell.number_format}'
    return value


def exact(cell):
    # Type-aware; identifier text "001" never becomes number 1. int 1 == float 1.0.
    k = kind(cell)
    return (k, cell.value if k == '数值' else raw(cell.value))


def inspect_archive(path):
    """Bound package expansion, reject DTD/entities, inspect actual sheet coordinates."""
    if path.suffix.lower() not in ('.xlsx', '.xlsm'):
        raise AuditError('仅支持.xlsx和.xlsm；旧版.xls及二进制.xlsb需先另存为.xlsx。')
    if not path.is_file(): raise AuditError('找不到输入文件，请检查路径或重新提供文件。')
    if path.stat().st_size > LIMITS['file_mb']*1024**2:
        raise AuditError('文件超过30MB上限，请拆分工作簿后检查。')
    meta = {}
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        if len(infos) > LIMITS['xml_entries'] or sum(i.file_size for i in infos) > LIMITS['unpacked_mb']*1024**2:
            raise AuditError('解压规模超过安全上限，请拆分文件。')
        if len({i.filename for i in infos}) != len(infos): raise AuditError('工作簿含重复包条目，请重新另存文件。')
        total_cells = 0
        for info in infos:
            if info.flag_bits & 1: raise AuditError('文件已加密，请先在本地解密副本。')
            if info.filename.endswith(('.xml', '.rels')):
                with z.open(info) as stream:
                    tail = b''
                    for block in iter(lambda: stream.read(65536), b''):
                        sample = (tail+block).replace(b'\x00',b'').upper()
                        if b'<!DOCTYPE' in sample or b'<!ENTITY' in sample:
                            raise AuditError('文件含不支持的XML声明，已停止读取。')
                        tail = (tail+block)[-64:]
            if re.fullmatch(r'xl/worksheets/[^/]+\.xml', info.filename):
                rows = cols = count = 0
                merges = []
                with z.open(info) as stream:
                    for _, e in ET.iterparse(stream, events=('end',)):
                        tag = e.tag.rsplit('}', 1)[-1]
                        if tag == 'c':
                            match = re.fullmatch(r'([A-Z]+)([1-9][0-9]*)', e.get('r', ''))
                            if not match: raise AuditError('单元格坐标不完整，不能保证定位，请重新另存文件。')
                            column = 0
                            for ch in match[1]: column = column*26+ord(ch)-64
                            rows, cols = max(rows, int(match[2])), max(cols, column)
                            count += 1
                        elif tag == 'mergeCell': merges.append(e.get('ref'))
                        e.clear()
                total_cells += rows*cols
                if rows > LIMITS['rows'] or cols > LIMITS['columns'] or total_cells > LIMITS['cells']:
                    raise AuditError('使用范围超过10万行/200列/全簿100万格上限（含格式占用）；请删除多余格式或拆分。')
                meta['/'+info.filename] = (rows, cols, merges)
        if len(meta) > LIMITS['sheets']: raise AuditError('超过30张工作表上限，请拆分检查。')
    return meta


def date_parse(v):
    if isinstance(v, (datetime, date)): return '原生日期'
    if not isinstance(v, str): return None
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d', '%Y年%m月%d日', '%Y-%m-%d %H:%M:%S'):
        try:
            datetime.strptime(v, fmt)
            return fmt
        except ValueError: pass
    return None


@dataclass(frozen=True)
class SnapshotCell:
    value: object
    data_type: str
    number_format: str
    coordinate: str


def read_snapshot(path, config, overview):
    """Read values using the SAME archive limits and audited structural decisions."""
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter
    path=Path(path).resolve();original=digest(path);parts=inspect_archive(path)
    statuses={x['sheet']:x for x in overview}
    book=load_workbook(path,read_only=True,data_only=False,keep_links=False)
    snapshot={}
    try:
        for ws in book.worksheets:
            status=statuses[ws.title];header=config.get('sheets',{}).get(ws.title,{}).get('header_row',1)
            rows,cols,_=parts['/'+ws._worksheet_path.lstrip('/')]
            content=[]
            if rows and cols:
                ws.reset_dimensions();content=list(ws.iter_rows(max_row=rows,max_col=cols))
                while content and all(missing(x.value) for x in content[-1]):content.pop()
            usable=not status.get('structure_blocked') and bool(content) and header<=len(content)
            names=[x.value for x in content[header-1][:status['fields']]] if usable else []
            records=[];all_records=[]
            if usable:
                for row in range(header+1,len(content)+1):
                    cells={}
                    for i,name in enumerate(names):
                        source=content[row-1][i]
                        cells[name]=SnapshotCell(source.value,source.data_type,source.number_format,f'{get_column_letter(i+1)}{row}')
                    all_records.append({'row':row,'cells':cells})
                    # Internal blank rows stay in metrics, not business identity matching.
                    if not all(missing(x.value) for x in cells.values()):records.append({'row':row,'cells':cells})
            snapshot[ws.title]={'headers':names,'records':records,'all_records':all_records,'header_row':header,
                               'usable':usable,'empty':not bool(content),'state':ws.sheet_state,'status':status['status']}
    finally:book.close()
    if digest(path)!=original:raise AuditError('读取快照期间源文件变化，请关闭编辑后重试。')
    return snapshot


