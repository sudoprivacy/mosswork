from __future__ import annotations
from collections import Counter, defaultdict
from datetime import date, datetime, time
import argparse, hashlib, json, math, os, re, statistics, sys, tempfile, unicodedata, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from excel_parser import *
from rules_engine import load_config, audit
from report_generator import safe_cell, render_report

def run(input_path, output_dir, config_path=None, save_rules=False):
    if sys.version_info < (3,11): raise AuditError('需要Python 3.11或更高版本。')
    src=Path(input_path).resolve()
    config=load_config(config_path)
    result=audit(src,config)
    out=Path(output_dir).resolve()
    # Always a new run directory; no overwrite of input, prior reports or arbitrary existing files.
    out.mkdir(parents=True,exist_ok=True)
    directory=Path(tempfile.mkdtemp(prefix='excel-audit-',dir=out))
    try:
        render_report(result,directory)
        if save_rules:(directory/'本次规则.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        if digest(src)!=result['source_sha256']: raise AuditError('检查期间原件发生变化，请关闭编辑后重试。')
    except Exception:
        # Only remove the two known generated artifacts within our unique run folder.
        for name in ('Excel数据体检报告.xlsx','数据质量摘要.md','本次规则.json'):
            p=directory/name
            if p.is_file(): p.unlink()
        directory.rmdir()
        raise
    return result,directory


def main(argv=None):
    parser=argparse.ArgumentParser(description='Excel数据体检1.0.0：只读检查，生成独立报告，不修改原件。')
    parser.add_argument('input',help='.xlsx或.xlsm输入文件')
    parser.add_argument('--output-dir',required=True,help='报告父目录，每次创建独立子目录')
    parser.add_argument('--config',help='可选JSON规则配置')
    parser.add_argument('--save-rules',action='store_true',help='在本次新目录保存已验证的规则，供重复使用')
    args=parser.parse_args(argv)
    try:
        result,directory=run(args.input,args.output_dir,args.config,args.save_rules)
        print(json.dumps({'status':'completed','source_unchanged':True,
                          'needs_review':any(o.get('structure_blocked') for o in result['overview']),
                          'report':str(directory/'Excel数据体检报告.xlsx'),
                          'rules':str(directory/'本次规则.json') if args.save_rules else None,
                          'summary':str(directory/'数据质量摘要.md')},ensure_ascii=False))
        return 0
    except ImportError:
        print('无法运行：缺少依赖。请按README安装 requirements.txt 后重试。',file=sys.stderr)
    except PermissionError:
        print('未完成检查：没有读写权限或文件被占用。请关闭占用程序或更换报告目录；原件未由本工具修改。',file=sys.stderr)
    except zipfile.BadZipFile:
        print('未完成检查：文件不是有效的xlsx/xlsm包，可能已损坏或有密码保护。请用本地办公软件打开并另存未加密副本；原件未由本工具修改。',file=sys.stderr)
    except (OSError,ET.ParseError) as exc:
        print('未完成检查：文件路径、存储空间或内部XML读取失败。请检查文件并另存副本后重试；原件未由本工具修改。',file=sys.stderr)
    except (AuditError, ValueError) as exc:
        print('未完成检查：'+str(exc)+' 原文件未由本工具修改。',file=sys.stderr)
    except Exception as exc:
        print(f'未完成检查：文件结构不受支持或读取失败（{type(exc).__name__}）。请先用Excel本地打开并另存副本；不要将此次视为通过。',file=sys.stderr)
    return 2


if __name__=='__main__':sys.exit(main())
