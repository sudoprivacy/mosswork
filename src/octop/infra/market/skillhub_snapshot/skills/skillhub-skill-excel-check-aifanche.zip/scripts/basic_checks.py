from __future__ import annotations
from collections import Counter, defaultdict
from datetime import date, datetime, time
import argparse, hashlib, json, math, os, re, statistics, sys, tempfile, unicodedata, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

from excel_parser import *

def audit(path, config=None):
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter, range_boundaries
    config = config or {}
    path = Path(path).resolve()
    before = digest(path) if path.is_file() else None
    archive = inspect_archive(path)
    enabled = {r: config.get('checks', {}).get(r, True) for r in RULES}
    result = dict(source_name=path.name, source_sha256=before, version=VERSION,
                  overview=[], issues=[], fields=[], notes=[], checks=enabled)
    def note(sheet, message): result['notes'].append((sheet, message))
    def add(sheet, row, coord, field, type_, certainty, value, why, advice):
        if len(result['issues']) >= LIMITS['issues']:
            raise AuditError('问题明细超过10万条，未输出截断报告；请分批或缩小规则范围。')
        result['issues'].append(dict(sheet=sheet, row=row, cell=coord, field=field, type=type_,
                                     certainty=certainty, severity='高' if certainty=='确定问题' else '提示',
                                     value=raw(value), basis=why, advice=advice))
    books = []
    try:
        for cache in (False, True):
            books.append(load_workbook(path, read_only=True, data_only=cache, keep_links=False))
        wb, cached = books
        if not wb.worksheets: raise AuditError('工作簿没有可读取的数据工作表，请另存为包含普通Sheet的.xlsx副本。')
        unknown = set(config.get('sheets', {}))-set(wb.sheetnames)
        if unknown: raise AuditError('配置中的工作表不存在：'+', '.join(sorted(unknown)))
        for ws in wb.worksheets:
            name = ws.title
            c = config.get('sheets', {}).get(name, {})
            header_row = c.get('header_row', 1)
            # Actual XML bounds, not potentially forged <dimension> hints.
            part = '/' + ws._worksheet_path.lstrip('/')
            if part not in archive: raise AuditError('工作表资源未能匹配，不能保证完整检查。')
            rows, cols, merges = archive[part]
            ov = dict(sheet=name, state=ws.sheet_state, rows=0, fields=0, blanks=0,
                      missing=0, missing_ratio=0, status='已检查', skipped=0)
            result['overview'].append(ov)
            if ws.sheet_state != 'visible': note(name, '隐藏工作表仍纳入检查；报告可能包含隐藏业务数据，请勿直接公开。')
            if not rows or not cols:
                ov['status']='空工作表';note(name, '无已存储单元格。');continue
            ws.reset_dimensions()
            data = list(ws.iter_rows(min_row=1, max_row=rows, max_col=cols))
            while data and all(missing(x.value) for x in data[-1]): data.pop()
            ov['scanned_cells']=len(data)*cols
            if not data or header_row > len(data):
                ov['status']='空工作表或指定表头不存在';note(name, ov['status']);continue
            used_cols = max((i+1 for r in data for i,x in enumerate(r) if not missing(x.value)), default=0)
            headers = [x.value for x in data[header_row-1][:used_cols]]
            records = [(i+header_row+1, r[:used_cols]) for i,r in enumerate(data[header_row:])]
            ov['rows'],ov['fields'] = len(records),used_cols
            ambiguous = any(not isinstance(x,str) or not x.strip() for x in headers) or len(set(map(raw,headers))) != len(headers)
            ambiguous |= any(range_boundaries(m)[1] <= header_row <= range_boundaries(m)[3] for m in merges)
            ambiguous |= any([x.value for x in r] == headers for _,r in records)
            ambiguous |= bool(merges)  # Merged data rows also break one-record-per-row semantics.
            if ambiguous:
                ov['status']='需要人工确认表结构';ov['skipped']=len(records);ov['structure_blocked']=True
                add(name,header_row,f'A{header_row}', '', '表结构不明确', '检查提示',headers,
                    '空/重复/非文本表头、合并单元格或数据区重复表头，不能可靠按单层表解释。',
                    '确认表头；可配置header_row。多表混排/合并数据请另存为单层表后重试。')
                note(name, '已跳过完整性、重复、格式、离群检查；不是零问题通过。仍扫描已有错误值与公式缓存。')
            else:
                names = [str(x) for x in headers]
                selected = set(c.get('required_fields',[])+c.get('key_fields',[])+list(c.get('field_types',{})))
                selected.update(x for group in c.get('unique_keys',[]) for x in group)
                if selected-set(names): raise AuditError(f'{name}找不到配置字段：'+', '.join(sorted(selected-set(names))))
                nonblank = []
                for row,r in records:
                    if all(missing(x.value) for x in r):
                        ov['blanks']+=1
                        add(name,row,f'A{row}:{get_column_letter(used_cols)}{row}','', '完全空白记录行','检查提示','',
                            '表头之后至末条非空记录之间，该行全部为空。','确认是否为分隔行；未自动删除。')
                    else: nonblank.append((row,r))
                # Missing denominators include internal blank records, exclude trailing styled empties.
                for j,field in enumerate(names):
                    col=[(row,r[j]) for row,r in records]
                    counts=Counter(kind(x) for _,x in col)
                    miss=sum(missing(x.value) for _,x in col)
                    field_start=len(result['issues'])
                    if enabled['missing'] and field in c.get('required_fields',[]):
                        for row,x in col:
                            if missing(x.value): add(name,row,f'{get_column_letter(j+1)}{row}',field,'必填字段缺失','确定问题',source_value(x),'用户明确指定该字段为必填。','核对来源并补齐；不猜值。')
                    dtype=c.get('field_types',{}).get(field)
                    active=[(row,x) for row,x in col if kind(x) not in ('空值','公式','错误值')]
                    kinds={kind(x) for _,x in active}
                    if enabled['types']:
                        if dtype:
                            for row,x in active:
                                good = kind(x)=='数值' if dtype=='number' else kind(x)=='文本' if dtype in ('text','identifier') else bool(date_parse(x.value))
                                if not good:
                                    add(name,row,x.coordinate,field,'字段类型不符合规则','确定问题',source_value(x),
                                        f'用户指定类型为{dtype}，本格为{kind(x)}。','核对字段规则和原始输入；不要直接批量转换编号。')
                        elif len(kinds)>1:
                            for row,x in active:
                                add(name,row,x.coordinate,field,'混合数据类型','疑似异常',source_value(x),
                                    '同列出现'+ '、'.join(sorted(kinds))+'；没有指定业务类型。','确认该列是否允许混合类型；文本数字可能是编号。')
                    looks_date = dtype=='date' or dtype is None and any(re.search(r'\d{4}[-/.年]\d{1,2}[-/.月]',raw(x.value)) or isinstance(x.value,(date,datetime)) for _,x in active)
                    if enabled['dates'] and looks_date:
                        parsed=[(row,x,date_parse(x.value)) for row,x in active]
                        formats={fmt for _,_,fmt in parsed if fmt}
                        for row,x,fmt in parsed:
                            if not fmt and (dtype=='date' or re.match(r'^\d{4}[-/.年]',raw(x.value))):
                                add(name,row,x.coordinate,field,'日期无法解析','确定问题' if dtype=='date' else '疑似异常',x.value,
                                    '不能按已支持的明确年/月/日格式解析；未推断月日顺序或Excel序列号。','确认日期意图；如2026-02-30则需核对来源。')
                            elif fmt and len(formats)>1:
                                add(name,row,x.coordinate,field,'日期格式混用','疑似异常',x.value,
                                    '同列有多种可解析日期表示：'+', '.join(sorted(formats)),'确认是否需统一展示，不代表日期值错误。')
                    nums=[(row,x) for row,x in active if kind(x)=='数值' and math.isfinite(x.value)]
                    native_dates=[x.number_format for _,x in active if kind(x)=='日期/时间']
                    if enabled['dates'] and len(set(native_dates))>1:
                        note(name,field+'存在不同原生日期显示格式，请核对是否有意。')
                    if enabled['outliers']:
                        suitable = dtype=='number' or dtype is None and kinds=={'数值'} and not re.search(r'编号|编码|序号|ID$|代码|邮编|电话',field,re.I) and not any(re.fullmatch('0{2,}',x.number_format) for _,x in nums)
                        if not suitable or len(nums)<config.get('iqr_min_samples',8):
                            note(name,field+'：未执行IQR（非纯数值/疑似编号或有效样本不足）。')
                        else:
                            vals=[x.value for _,x in nums]
                            q1,_,q3=statistics.quantiles(vals,n=4,method='inclusive')
                            spread=q3-q1
                            if not all(math.isfinite(v) for v in (q1,q3,spread)):
                                note(name,field+'：未执行IQR（数值范围过大，无法可靠计算四分位数）。')
                            elif not spread: note(name,field+'：未执行IQR（四分位距为0）。')
                            else:
                                multiplier=config.get('iqr_multiplier',1.5)
                                lower,upper=q1-multiplier*spread,q3+multiplier*spread
                                for row,x in nums:
                                    if x.value<lower or x.value>upper:
                                        add(name,row,x.coordinate,field,'统计离群值','疑似异常',x.value,
                                            f'IQR inclusive；n={len(vals)}，Q1={q1:g}，Q3={q3:g}，系数={multiplier:g}，范围[{lower:g}, {upper:g}]。','仅为统计提示，请结合业务判断；不自动修改。')
                    count=len(result['issues'])-field_start
                    result['fields'].append(dict(sheet=name,field=field,column=get_column_letter(j+1),
                        types='；'.join(f'{k}:{v}' for k,v in sorted(counts.items())),nonempty=len(col)-miss,
                        missing=miss,ratio=miss/len(col) if col else 0,anomalies=count))
                    ov['missing']+=miss
                ov['missing_ratio']=ov['missing']/(len(records)*used_cols) if records and used_cols else 0
                if enabled['duplicates']:
                    groups=[('完全重复记录',list(range(used_cols)),False)]
                    if c.get('key_fields'): groups.append(('关键字段重复',[names.index(x) for x in c['key_fields']],False))
                    groups.extend(('唯一约束重复',[names.index(x) for x in g],True) for g in c.get('unique_keys',[]))
                    for label,indices,unique in groups:
                        seen=defaultdict(list)
                        for row,r in nonblank:
                            excluded=('公式','错误值') if label=='完全重复记录' else ('空值','公式','错误值')
                            if any(kind(r[i]) in excluded for i in indices): continue
                            seen[tuple(exact(r[i]) for i in indices)].append(row)
                        for matches in seen.values():
                            if len(matches)<2: continue
                            # Only second and later occurrence are issue records; refer to first.
                            for row in matches[1:]:
                                coords=','.join(f'{get_column_letter(i+1)}{row}' for i in indices)
                                add(name,row,coords,','.join(names[i] for i in indices),label,
                                    '确定问题' if unique else '疑似异常',
                                    [raw(source_value(data[row-1][i])) for i in indices],
                                    f'与第{matches[0]}行按字段原值及类型相同；'+('可选空值参与整行比较，完全空白行已排除；公式/错误格未比较。' if label=='完全重复记录' else '空键/公式/错误格未比较。')+('用户要求该组合唯一。' if unique else '相同不等于业务重复。'),
                                    '核对是否应保留；未删除任何记录。')
                if not records: note(name,'仅有表头，无数据记录。')
            # Formula/error scan uses raw sheet even when structural interpretation is blocked.
            cache_ws=cached[name];cache_ws.reset_dimensions()
            cache_rows=cache_ws.iter_rows(max_row=rows,max_col=cols)
            absent=0
            for row,r in enumerate(data,1):
                cr=next(cache_rows)
                for j,x in enumerate(r):
                    if x.data_type=='f':
                        cache=cr[j]
                        if cache.value is None: absent+=1
                        if enabled['formula_errors'] and cache.data_type=='e':
                                add(name,row,x.coordinate,raw(headers[j]) if not ambiguous and row>header_row and j<len(headers) else '', '公式缓存错误','确定问题',x.value,
                                '文件已有缓存错误：'+raw(cache.value)+'；未计算公式，缓存可能过期。','在本地Excel重新计算并核对公式引用；本工具不运行公式。')
                    elif enabled['formula_errors'] and x.data_type=='e':
                        add(name,row,x.coordinate,raw(headers[j]) if not ambiguous and row>header_row and j<len(headers) else '', 'Excel已有错误值','确定问题',x.value,
                            '源文件单元格类型为Excel错误值，不是同名字面文本。','检查来源；本格未必仍保存有公式。')
            if absent: note(name,f'{absent}个公式无可用缓存结果；可能未计算或本来返回空，未认定为公式错误，也未把它们当空值。')
        for ov in result['overview']:
            issues=[x for x in result['issues'] if x['sheet']==ov['sheet']]
            ov['certain']=sum(x['certainty']=='确定问题' for x in issues)
            ov['suspected']=sum(x['certainty']=='疑似异常' for x in issues)
            ov['info']=sum(x['certainty']=='检查提示' for x in issues)
            ov['counts']=dict(Counter(x['type'] for x in issues))
        # Field totals include duplicate and formula issues too, only for cells/fields implicated.
        hits=Counter()
        for x in result['issues']:
            columns={m[1] for coord in x['cell'].split(',') if (m:=re.fullmatch(r'([A-Z]+)\d+',coord))}
            for column in columns:hits[x['sheet'],column]+=1
        for f in result['fields']:f['anomalies']=hits[f['sheet'],f['column']]
        if digest(path)!=before: raise AuditError('检查期间源文件发生变化，报告已停止。请关闭编辑后重试。')
        return result
    finally:
        for book in books: book.close()


