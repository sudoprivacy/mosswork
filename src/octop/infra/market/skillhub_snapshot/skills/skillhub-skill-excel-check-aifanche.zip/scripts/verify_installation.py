"""Portable installation smoke test. Synthetic data only; no network calls."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import traceback
import zipfile


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description='用合成样表验证安装及三种模式，不处理你的业务文件。')
    parser.add_argument('--output-dir', default='installation-check', help='验证结果父目录，每次新建子目录')
    parser.add_argument('--run-regressions', action='store_true', help='同时运行随包回归测试')
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        print('无法验证：需要 Python 3.11 或更高版本。', file=sys.stderr)
        return 2
    try:
        from openpyxl import Workbook, load_workbook
    except ImportError:
        print('无法验证：尚未安装依赖。请使用本环境的 python -m pip install -r requirements.txt。', file=sys.stderr)
        return 2
    root = Path(__file__).resolve().parents[1]
    parent = Path(args.output_dir).resolve()
    parent.mkdir(parents=True, exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='verify-', dir=parent))
    result = {'status': 'FAIL', 'system': platform.system(), 'release': platform.release(),
              'machine': platform.machine(), 'python': platform.python_version(),
              'executable': sys.executable, 'openpyxl': importlib.metadata.version('openpyxl'),
              'isolated_environment': sys.prefix != sys.base_prefix, 'cases': [],
              'scope': '本地脚本及报告验证；不是宿主平台自动发现、附件上传或原生Excel视觉验收。'}
    env = dict(os.environ)
    env.pop('PYTHONPATH', None)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONIOENCODING'] = 'utf-8'

    def run(name, command, expected=0):
        done = subprocess.run([sys.executable, *command], cwd=root, env=env,
                              capture_output=True, encoding='utf-8', errors='replace', timeout=300)
        (out / (name + '.log')).write_text(done.stdout + '\n' + done.stderr, encoding='utf-8')
        if done.returncode != expected:
            raise AssertionError(name + ' 未按预期完成，详情见对应日志。')
        result['cases'].append({'name': name, 'result': 'PASS', 'exit_code': done.returncode})
        return done

    def make(name, rows):
        path = out / name
        wb = Workbook()
        ws = wb.active
        ws.title = '员工信息'
        ws.append(['员工编号', '姓名', '年龄'])
        for row in rows:
            ws.append(row)
        wb.save(path)
        wb.close()
        return path

    def read_report(path, expected_sheets):
        with zipfile.ZipFile(path) as archive:
            assert not any(b'TargetMode="External"' in archive.read(name)
                           for name in archive.namelist() if name.endswith('.rels')), '报告出现外部链接'
        wb = load_workbook(path, read_only=True, data_only=False, keep_links=False)
        try:
            assert wb.sheetnames == expected_sheets, '报告页签不完整'
            tables = {}
            for ws in wb:
                rows = []
                for row in ws:
                    assert all(c.data_type != 'f' for c in row), '报告出现可执行公式'
                    rows.append(tuple(c.value for c in row))
                tables[ws.title] = rows
            return tables
        finally:
            wb.close()

    audit_tabs = ['检查总览', '问题明细', '字段质量概况', '检查规则与限制说明']
    compare_tabs = ['对比总览', '数据质量指标变化', '新增与删除记录', '已匹配记录的字段变化',
                    'Sheet和字段结构变化', '无法匹配及待确认事项', '比较规则与限制说明']
    try:
        sample = make('合成员工信息.xlsx', [('N001', '合成甲', 32), ('N002', None, 35),
                                         ('N002', None, 35), ('N004', '合成丁', None)])
        before = make('合成修改前.xlsx', [('N001', '合成甲', 32), ('N002', None, 35), ('N003', '合成丙', 40)])
        after = make('合成修改后.xlsx', [('N002', '合成乙', 35), ('N001', '合成甲', 32), ('N004', '合成丁', 45)])
        hashes = {str(p): sha256(p) for p in (sample, before, after)}
        config = out / '合成检查规则.json'
        config.write_text(json.dumps({'sheets': {'员工信息': {'required_fields': ['姓名'],
                         'unique_keys': [['员工编号']]}}}, ensure_ascii=False), encoding='utf-8')
        mapping = out / '合成匹配规则.json'
        mapping.write_text(json.dumps({'sheets': [{'before': '员工信息', 'after': '员工信息',
                           'keys': ['员工编号']}]}, ensure_ascii=False), encoding='utf-8')
        common = ['--output-dir', str(out / 'reports')]
        a = json.loads(run('A标准检查', ['scripts/audit_excel.py', str(sample), *common]).stdout)
        ta = read_report(a['report'], audit_tabs)
        overview = dict(zip(ta['检查总览'][0], ta['检查总览'][1]))
        assert overview['数据行数'] == 4 and overview['字段数'] == 3
        assert overview['缺失单元格'] == 3 and overview['规则违规数量'] == 0
        problems = [dict(zip(ta['问题明细'][0], row)) for row in ta['问题明细'][1:]]
        duplicate = [x for x in problems if x['问题类型'] == '完全重复记录']
        assert len(duplicate) == 1 and duplicate[0]['行号'] == 4
        b = json.loads(run('B自定义规则', ['scripts/audit_excel.py', str(sample), *common,
                                          '--config', str(config), '--save-rules']).stdout)
        tb = read_report(b['report'], audit_tabs)
        problems = [dict(zip(tb['问题明细'][0], row)) for row in tb['问题明细'][1:]]
        assert {x['单元格位置'] for x in problems if x['问题类型'] == '必填字段缺失'} == {'B3', 'B4'}
        assert [x['行号'] for x in problems if x['问题类型'] == '唯一约束重复'] == [4]
        saved = Path(b['rules'])
        b2 = json.loads(run('B规则复用', ['scripts/audit_excel.py', str(sample), *common,
                                        '--config', str(saved)]).stdout)
        assert read_report(b2['report'], audit_tabs)['问题明细'] == tb['问题明细']
        c = json.loads(run('C前后对比', ['scripts/compare_excel.py', str(before), str(after),
                                      *common, '--config', str(config), '--mapping', str(mapping)]).stdout)
        tc = read_report(c['report'], compare_tabs)
        changes = tc['已匹配记录的字段变化'][1:]
        assert len(tc['新增与删除记录'][1:]) == 2 and len(changes) == 1
        assert changes[0][3] == 'B3' and changes[0][8] == 'B2'
        assert changes[0][5] is None and changes[0][10] == '合成乙'
        cn = json.loads(run('C无主键降级', ['scripts/compare_excel.py', str(before), str(after), *common]).stdout)
        tn = read_report(cn['report'], compare_tabs)
        assert len(tn['新增与删除记录']) == 1 and len(tn['已匹配记录的字段变化']) == 1
        assert len(tn['无法匹配及待确认事项']) > 1
        unsupported = out / '旧格式.xls'
        unsupported.write_bytes(b'Synthetic unsupported-format fixture; not a workbook.')
        run('不支持xls提示', ['scripts/audit_excel.py', str(unsupported), *common], expected=2)
        unsupported_message = (out / '不支持xls提示.log').read_text(encoding='utf-8')
        assert '仅支持.xlsx和.xlsm' in unsupported_message and '另存' in unsupported_message, '缺少旧格式转换提示'
        assert hashes == {str(p): sha256(p) for p in (sample, before, after)}
        result['source_sha256'] = hashes
        # Reopen every generated report, not only top-level comparison reports.
        reports = sorted((out / 'reports').rglob('*.xlsx'))
        for report in reports:
            read_report(report, compare_tabs if report.name == 'Excel数据差异对比报告.xlsx' else audit_tabs)
        result['reports_reopened'] = len(reports)
        result['cases'].append({'name': '结果计数、来源位置、原件不变、报告安全重开', 'result': 'PASS'})
        if args.run_regressions:
            done = run('全部回归测试', ['-m', 'unittest', 'discover', '-s', 'tests', '-v'])
            result['regression_summary'] = done.stderr.splitlines()[-4:]
        result['status'] = 'PASS'
    except (AssertionError, OSError, ValueError, subprocess.SubprocessError, KeyError) as exc:
        result['error'] = str(exc) or type(exc).__name__
        (out / '验证失败详情.log').write_text(traceback.format_exc(), encoding='utf-8')
        print('安装验证未通过：' + result['error'] + '。请保留结果目录供排查。', file=sys.stderr)
    finally:
        receipt = out / '安装验证结果.json'
        receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print('验证结果：' + result['status'] + '\n结果文件：' + str(receipt))
    return 0 if result['status'] == 'PASS' else 2


if __name__ == '__main__':
    sys.exit(main())
