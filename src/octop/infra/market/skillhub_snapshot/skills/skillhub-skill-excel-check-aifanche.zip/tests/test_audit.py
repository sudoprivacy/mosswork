from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile

from openpyxl import load_workbook, Workbook

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from audit_excel import audit, run, digest, AuditError, load_config, LIMITS, safe_cell
from make_fixtures import make, rewrite


class AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.root=make(cls.temp.name)
    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()
    def check(self,name,c=None):
        p=self.root/(name+'.xlsx');before=p.read_bytes();r=audit(p,c)
        self.assertEqual(before,p.read_bytes());return r
    def test_normal_no_forced_errors(self):
        r=self.check('normal');self.assertEqual([],r['issues']);self.assertEqual(12,r['overview'][0]['rows'])
    def test_missing_is_only_statistic_by_default(self):
        r=self.check('missing');self.assertFalse(any(x['certainty']=='确定问题' for x in r['issues']))
        self.assertEqual(4,r['overview'][0]['missing']);self.assertEqual(1,r['overview'][0]['blanks'])
    def test_required_and_positions(self):
        r=self.check('missing',{'sheets':{'业务数据':{'required_fields':['编号']}}})
        cells={x['cell'] for x in r['issues'] if x['type']=='必填字段缺失'}
        self.assertEqual({'A3','A4'},cells)
    def test_full_duplicate_is_suspected(self):
        r=self.check('duplicates');x=[x for x in r['issues'] if x['type']=='完全重复记录']
        self.assertEqual(1,len(x));self.assertEqual(3,x[0]['row']);self.assertIn('第2行',x[0]['basis']);self.assertEqual('疑似异常',x[0]['certainty'])
    def test_key_duplicates_not_implied_unique(self):
        r=self.check('duplicates',{'sheets':{'业务数据':{'key_fields':['编号']}}})
        self.assertEqual([3,4],[x['row'] for x in r['issues'] if x['type']=='关键字段重复'])
        self.assertFalse(any(x['certainty']=='确定问题' for x in r['issues']))
    def test_explicit_unique_constraint(self):
        r=self.check('duplicates',{'sheets':{'业务数据':{'unique_keys':[['编号']]}}})
        self.assertEqual(2,sum(x['type']=='唯一约束重复' and x['certainty']=='确定问题' for x in r['issues']))
    def test_composite_key(self):
        r=self.check('duplicates',{'sheets':{'业务数据':{'key_fields':['编号','值']}}})
        self.assertEqual([3],[x['row'] for x in r['issues'] if x['type']=='关键字段重复'])
    def test_date_and_type_mixed(self):
        r=self.check('mixed');self.assertTrue(any(x['cell']=='A2' and x['type']=='日期无法解析' for x in r['issues']))
        self.assertTrue(any(x['cell']=='B3' and x['type']=='混合数据类型' for x in r['issues']))
        self.assertFalse(any(x['certainty']=='确定问题' for x in r['issues']))
    def test_explicit_types(self):
        r=self.check('mixed',{'sheets':{'业务数据':{'field_types':{'数值':'number','日期':'date'}}}})
        self.assertTrue(any(x['cell']=='B3' and x['certainty']=='确定问题' for x in r['issues']))
    def test_outlier_iqr(self):
        r=self.check('outliers');out=[x for x in r['issues'] if x['type']=='统计离群值']
        self.assertEqual(['B11'],[x['cell'] for x in out]);self.assertIn('Q1=',out[0]['basis']);self.assertEqual('疑似异常',out[0]['certainty'])
    def test_zero_negative_are_not_errors(self): self.assertEqual([],self.check('zeros')['issues'])
    def test_formula_error_and_literal_text(self):
        r=self.check('errors');error=[x for x in r['issues'] if '错误' in x['type']]
        self.assertEqual({'A2','A4'},{x['cell'] for x in error})
        self.assertTrue(any('无可用缓存' in n for _,n in r['notes']))
        self.assertFalse(any(x['cell'] in ('A3','A5') for x in error))
    def test_multiple_sheets_hidden_and_empty(self):
        r=self.check('multi');self.assertEqual(3,len(r['overview']));self.assertTrue(any(x['sheet']=='隐藏表' for x in r['issues']))
        self.assertEqual('空工作表',r['overview'][2]['status'])
    def test_empty(self): self.assertEqual('空工作表',self.check('empty')['overview'][0]['status'])
    def test_no_sheet_is_not_clean(self):
        p=self.root/'no-sheet.xlsx';p.write_bytes((self.root/'empty.xlsx').read_bytes())
        rewrite(p,lambda f:{n:(__import__('re').sub(b'<sheets>.*?</sheets>',b'<sheets/>',v) if n=='xl/workbook.xml' else v) for n,v in f.items()})
        with self.assertRaises(AuditError):audit(p)
    def test_ambiguous_headers(self):
        for n in ('merged','bad_header','repeated_header'):
            with self.subTest(n=n): self.assertEqual('需要人工确认表结构',self.check(n)['overview'][0]['status'])
    def test_header_offset(self):
        r=self.check('offset_header',{'sheets':{'业务数据':{'header_row':2}}});self.assertEqual([],r['issues']);self.assertEqual(1,r['overview'][0]['rows'])
    def test_missing_field_fails(self):
        with self.assertRaises(AuditError): self.check('normal',{'sheets':{'业务数据':{'required_fields':['不存在']}}})
    def test_missing_sheet_fails(self):
        with self.assertRaises(AuditError): self.check('normal',{'sheets':{'不存在':{}}})
    def test_specials_and_leading_zeros(self):
        r=self.check('special');self.assertEqual([],r['issues']);self.assertEqual('文本:5',r['fields'][0]['types'])
    def test_native_date_formats_explained(self):
        r=self.check('date_native');self.assertTrue(any('显示格式' in n for _,n in r['notes']))
    def test_xlsm_never_executed(self):
        p=self.root/'macro.xlsm';before=digest(p);r=audit(p)
        self.assertEqual(before,digest(p));self.assertEqual([],r['issues'])
    def test_disabled_rules(self):
        r=self.check('mixed',{'checks':{'types':False,'dates':False,'duplicates':False,'outliers':False}})
        self.assertEqual([],r['issues'])
    def test_report_opens_and_no_formulas(self):
        with tempfile.TemporaryDirectory() as out:
            r,d=run(self.root/'errors.xlsx',out)
            wb=load_workbook(d/'Excel数据体检报告.xlsx',data_only=False)
            self.assertEqual(['检查总览','问题明细','字段质量概况','检查规则与限制说明'],wb.sheetnames)
            self.assertFalse(any(c.data_type=='f' for ws in wb for row in ws for c in row))
            self.assertTrue(any(c.value=='=1/0' and c.data_type=='s' for row in wb['问题明细'] for c in row));wb.close()
            self.assertTrue((d/'数据质量摘要.md').is_file())
    def test_direct_injection_report_text(self):
        with tempfile.TemporaryDirectory() as tmp:
            wb=Workbook(write_only=True);ws=wb.create_sheet()
            values=['=1+1','+SUM(1,2)','-2+3','@SUM(1,2)','\t=1+1','00123','#REF!','<script>','a\x01b']
            ws.append([safe_cell(ws,v) for v in values]);p=Path(tmp)/'literal.xlsx';wb.save(p)
            read=load_workbook(p);cells=list(read.active[1]);self.assertTrue(all(c.data_type=='s' for c in cells))
            self.assertEqual('00123',cells[5].value);self.assertEqual('a\\u0001b',cells[-1].value);read.close()
    def test_no_overwrite_repeat_run(self):
        with tempfile.TemporaryDirectory() as out:
            _,a=run(self.root/'normal.xlsx',out);h=digest(a/'Excel数据体检报告.xlsx')
            _,b=run(self.root/'normal.xlsx',out);self.assertNotEqual(a,b);self.assertEqual(h,digest(a/'Excel数据体检报告.xlsx'))
    def test_unsupported_formats_and_corrupt_zip(self):
        for ext in ('.xls','.xlsb','.xlsx'):
            p=self.root/('broken'+ext);p.write_bytes(b'not an OOXML file')
            with self.assertRaises((AuditError,zipfile.BadZipFile)): audit(p)
    def test_config_validation(self):
        p=self.root/'config.json'
        for bad in ({'check':True},{'checks':{'types':'yes'}},{'iqr_min_samples':3},{'sheets':{'业务数据':{'field_types':{'编号':'float'}}}}):
            p.write_text(json.dumps(bad))
            with self.assertRaises(AuditError): load_config(p)
    def test_safety_dimension_bounds(self):
        p=self.root/'sparse.xlsx';wb=Workbook();wb.active['A100001']='beyond';wb.save(p);wb.close()
        with self.assertRaises(AuditError): audit(p)
    def test_untrusted_dimension_not_used(self):
        p=self.root/'forged.xlsx';p.write_bytes((self.root/'errors.xlsx').read_bytes())
        rewrite(p,lambda f:{n:(__import__('re').sub(b'<dimension[^>]*/>',b'<dimension ref="A1:A1"/>',v) if n=='xl/worksheets/sheet1.xml' else v) for n,v in f.items()})
        self.assertTrue(any(x['cell']=='A4' for x in audit(p)['issues']))
    def test_doctype_rejected(self):
        p=self.root/'entity.xlsx';p.write_bytes((self.root/'normal.xlsx').read_bytes())
        rewrite(p,lambda f:{n:(b'<!DOCTYPE test>'+v if n=='xl/worksheets/sheet1.xml' else v) for n,v in f.items()})
        with self.assertRaises(AuditError): audit(p)
    def test_utf16_doctype_rejected(self):
        p=self.root/'utf16-entity.xlsx';p.write_bytes((self.root/'normal.xlsx').read_bytes())
        def convert(files):
            name='xl/worksheets/sheet1.xml'
            files[name]=('<!DOCTYPE test>'+files[name].decode()).encode('utf-16')
            return files
        rewrite(p,convert)
        with self.assertRaises(AuditError): audit(p)
    def test_numeric_identifier_display_preserved(self):
        p=self.root/'numeric-id.xlsx';wb=Workbook();ws=wb.active;ws.title='业务数据'
        ws.append(['编号']);ws.append([1]);ws['A2'].number_format='00000';wb.save(p);wb.close()
        r=audit(p,{'sheets':{'业务数据':{'field_types':{'编号':'identifier'}}}})
        self.assertIn('显示值=00001',r['issues'][0]['value'])
        self.assertEqual(1,load_workbook(p).active['A2'].value)
    def test_header_only_and_empty_key_skip(self):
        p=self.root/'only-header.xlsx';wb=Workbook();ws=wb.active;ws.append(['编号','值']);wb.save(p);wb.close()
        r=audit(p);self.assertEqual([],r['issues']);self.assertEqual(0,r['overview'][0]['rows'])
        r=self.check('missing',{'sheets':{'业务数据':{'key_fields':['编号']}}})
        self.assertFalse(any(x['type']=='关键字段重复' for x in r['issues']))
    def test_zero_iqr_and_small_sample_skip(self):
        p=self.root/'iqr-zero.xlsx';wb=Workbook();ws=wb.active;ws.append(['金额'])
        for i in range(10):ws.append([10 if i<9 else 900])
        wb.save(p);wb.close();r=audit(p)
        self.assertFalse(any(x['type']=='统计离群值' for x in r['issues']))
        self.assertTrue(any('四分位距为0' in n for _,n in r['notes']))
        self.assertTrue(any('样本不足' in n for _,n in self.check('missing')['notes']))
    def test_issue_limit_is_not_silent(self):
        old=LIMITS['issues'];LIMITS['issues']=1
        try:
            with self.assertRaises(AuditError):self.check('mixed')
        finally:LIMITS['issues']=old
    def test_cli(self):
        script=Path(__file__).resolve().parents[1]/'scripts/audit_excel.py'
        with tempfile.TemporaryDirectory() as out:
            done=subprocess.run([sys.executable,str(script),str(self.root/'normal.xlsx'),'--output-dir',out],capture_output=True,text=True)
            self.assertEqual(0,done.returncode,done.stderr);self.assertTrue(Path(json.loads(done.stdout)['report']).exists())
            bad=subprocess.run([sys.executable,str(script),'unsupported.xls','--output-dir',out],capture_output=True,text=True)
            self.assertEqual(2,bad.returncode);self.assertIn('仅支持',bad.stderr)


if __name__=='__main__': unittest.main()
