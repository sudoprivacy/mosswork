"""Behavioral tests for declarative rules and reliable before/after comparison."""
from copy import deepcopy
from datetime import date
from pathlib import Path
import json,sys,tempfile,unittest
from openpyxl import Workbook,load_workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from excel_parser import AuditError,digest
from rules_engine import audit,validate_config,load_config
from audit_excel import run as audit_run
from compare_excel import compare,run as compare_run,validate_mapping

class FullTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def book(self,name,rows,sheet='员工',others=None):
        p=self.root/(name+'.xlsx');w=Workbook();s=w.active;s.title=sheet
        for r in rows:s.append(r)
        for n,data in (others or {}).items():
            ws=w.create_sheet(n)
            for r in data:ws.append(r)
        w.save(p);w.close();return p
    def basic(self):return [['工号','姓名','年龄','日期','状态'],['001','甲',18,'2026-01-01','在职'],['002','乙',65,'2026-12-31','离职']]
    def policy(self,**rules):return {'sheets':{'员工':rules}}
    def issues(self,path,c):return audit(path,c)['issues']
    def map(self,keys=['工号']):return {'sheets':[{'before':'员工','after':'员工','keys':keys}]}
    def test_required_and_unique_combination(self):
        p=self.book('r',[['工号','姓名'],['001','甲'],['001',None],['002','乙']])
        r=audit(p,self.policy(required_fields=['姓名'],unique_keys=[['工号']]))
        self.assertEqual({'B3','A3'},{x['cell'] for x in r['issues'] if x['level']=='规则违规'})
        r=audit(p,self.policy(unique_keys=[['工号','姓名']]))
        self.assertFalse(any(x['type']=='唯一约束重复' for x in r['issues']))
    def test_integer_decimal_and_no_conversion(self):
        p=self.book('type',[['年龄','费用'],[18,18.5],[18.5,0],['18','18.5']])
        r=self.issues(p,self.policy(field_types={'年龄':'integer','费用':'decimal'}))
        certain={x['cell'] for x in r if x['level']=='规则违规'}
        self.assertEqual({'A3','A4','B4'},certain)
        self.assertTrue(any(x['cell']=='A4' and '类型为integer' in x['basis'] for x in r))
    def test_numeric_closed_boundaries(self):
        p=self.book('closed',[['年龄'],[17],[18],[65],[66],[None],['18']])
        r=self.issues(p,self.policy(numeric_ranges={'年龄':{'min':18,'max':65}}))
        self.assertEqual({'A2','A5','A7'},{x['cell'] for x in r if x['type']=='不满足数值范围'})
    def test_numeric_open_boundaries(self):
        p=self.book('open',[['年龄'],[18],[19],[64],[65]])
        r=self.issues(p,self.policy(numeric_ranges={'年龄':{'min':18,'max':65,'include_min':False,'include_max':False}}))
        self.assertEqual({'A2','A5'},{x['cell'] for x in r if x['type']=='不满足数值范围'})
    def test_date_boundaries_and_invalid(self):
        p=self.book('date',[['日期'],['2026-01-01'],[date(2026,12,31)],['2027-01-01'],['2026-02-30']])
        r=self.issues(p,self.policy(date_ranges={'日期':{'min':'2026-01-01','max':'2026-12-31'}}))
        self.assertEqual({'A4','A5'},{x['cell'] for x in r if x['type']=='不满足日期范围'})
        r=self.issues(p,self.policy(date_ranges={'日期':{'min':'2026-01-01','include_min':False}}))
        self.assertIn('A2',{x['cell'] for x in r if x['type']=='不满足日期范围'})
    def test_allow_empty_strategy(self):
        p=self.book('empty',[['工号','年龄'],['001',None],[None,None],['003',18]])
        r=self.issues(p,self.policy(numeric_ranges={'年龄':{'min':18,'allow_empty':False}}))
        self.assertEqual({'B2','B3'},{x['cell'] for x in r if x['type']=='自定义规则不允许空值'})
        r=self.issues(p,self.policy(numeric_ranges={'年龄':{'min':18}}))
        self.assertFalse(any(x['level']=='规则违规' for x in r))
    def test_allowed_values_type_sensitive(self):
        p=self.book('set',[['工号','状态'],['001',1],['002',True],['003','1'],['004',None]])
        r=self.issues(p,self.policy(allowed_values={'状态':{'values':[1]}}))
        self.assertEqual({'B3','B4'},{x['cell'] for x in r if x['type']=='不在允许值集合'})
    def test_required_column_violation_not_silent(self):
        p=self.book('fields',[['工号'],['001']])
        result=audit(p,self.policy(required_columns=['姓名'],required_fields=['姓名']))
        r=result['issues'];self.assertEqual(0,result['fields'][0]['anomalies'])
        self.assertEqual(1,sum(x['type']=='要求字段不存在' and x['level']=='规则违规' for x in r))
        with self.assertRaises(AuditError):audit(p,self.policy(numeric_ranges={'错字段':{'min':1}}))
    def test_invalid_and_conflicting_rules(self):
        cases=[{'field_types':{'年龄':['integer']}},{'field_types':{'年龄':'integer'},'numeric_ranges':{'年龄':{'min':18.2,'max':18.8}}},
               {'allowed_values':{'状态':{'values':[''],'allow_empty':False}}},{'numeric_ranges':{'年龄':{'min':65,'max':18}}},
               {'numeric_ranges':{'年龄':{'min':18,'max':18,'include_min':False}}},
               {'date_ranges':{'日期':{'min':'2026-02-30'}}},
               {'numeric_ranges':{'年龄':{'min':'18'}}},
               {'numeric_ranges':{'年龄':{'min':True}}},
               {'allowed_values':{'年龄':{'values':[]}}},
               {'field_types':{'年龄':'integer'},'allowed_values':{'年龄':{'values':['18']}}},
               {'numeric_ranges':{'年龄':{'min':18}},'date_ranges':{'年龄':{'min':'2026-01-01'}}},
               {'numeric_ranges':{'年龄':{'min':18}},'allowed_values':{'年龄':{'values':[17]}}}]
        for r in cases:
            with self.subTest(r=r),self.assertRaises(AuditError):validate_config(self.policy(**r))
        with self.assertRaises(AuditError):validate_config({'checks':{'missing':False},'sheets':{'员工':{'required_fields':['姓名']}}})
    def test_config_json_duplicate_and_code_not_executed(self):
        p=self.root/'r.json';p.write_text('{"checks":{},"checks":{}}')
        with self.assertRaises(AuditError):load_config(p)
        text='__import__("os").system("touch NEVER")'
        p.write_text(json.dumps(self.policy(allowed_values={'状态':{'values':[text]}})))
        file=self.book('literal',[['状态'],[text]])
        self.assertFalse(any(x['level']=='规则违规' for x in audit(file,load_config(p))['issues']))
        self.assertFalse((self.root/'NEVER').exists())
    def test_rules_saved_and_reused(self):
        p=self.book('reuse',self.basic());c=self.root/'rules.json';c.write_text(json.dumps(self.policy(required_fields=['姓名'])))
        r,d=audit_run(p,self.root/'out',c,True)
        again,other=audit_run(p,self.root/'out',d/'本次规则.json')
        self.assertEqual(r['issues'],again['issues']);self.assertEqual(r['rule_fingerprint'],again['rule_fingerprint'])
        another=self.book('another',self.basic()+[['003','丙',22,'2026-01-02','在职']])
        third,_=audit_run(another,self.root/'out',d/'本次规则.json')
        self.assertEqual(r['rule_fingerprint'],third['rule_fingerprint']);self.assertFalse(any(x['level']=='规则违规' for x in third['issues']))
    def test_combination_unique_actual_violation(self):
        p=self.book('combo',[['工号','批次'],['001','A'],['001','B'],['001','A']])
        r=audit(p,self.policy(unique_keys=[['工号','批次']]))
        issues=[x for x in r['issues'] if x['type']=='唯一约束重复']
        self.assertEqual(1,len(issues));self.assertEqual('A4,B4',issues[0]['cell']);self.assertEqual('规则违规',issues[0]['level'])
    def test_statistical_toggle_and_formula_skip(self):
        p=self.book('stats',[['工号','金额']]+[[str(i),v] for i,v in enumerate([1,2,3,4,5,6,7,8,9,999])])
        r=audit(p,{'checks':{'outliers':False}});self.assertFalse(any(x['type']=='统计离群值' for x in r['issues']))
        p=self.book('form',[['年龄'],['=18+1'],['#REF!']])
        r=audit(p,self.policy(numeric_ranges={'年龄':{'min':18,'max':65}}))
        self.assertFalse(any(x['type']=='不满足数值范围' for x in r['issues']))
        self.assertTrue(any('未执行' in msg for _,msg in r['notes']))
    def test_same_file_comparison_and_no_edit(self):
        p=self.book('same',self.basic());h=digest(p);r=compare(p,p,mapping=self.map())
        self.assertEqual([],r['records']);self.assertEqual([],r['changes']);self.assertEqual([],r['unmatched'])
        self.assertTrue(all(x[5] in (0,None) for x in r['metrics']));self.assertEqual(h,digest(p))
    def test_add_delete_change_and_positions(self):
        b=self.book('before',self.basic())
        rows=self.basic();rows[1][2]=20;rows[2]=['003','丙',22,'2026-06-01','在职'];a=self.book('after',rows)
        old=[digest(b),digest(a)];r=compare(b,a,mapping=self.map())
        self.assertEqual({'新增记录','删除记录'},{x[0] for x in r['records']})
        self.assertEqual(1,len(r['changes']));self.assertEqual('C2',r['changes'][0][3]);self.assertEqual('C2',r['changes'][0][8])
        self.assertEqual('18',r['changes'][0][5]);self.assertEqual('20',r['changes'][0][10]);self.assertEqual(old,[digest(b),digest(a)])
    def test_record_order_not_identity(self):
        rows=self.basic();b=self.book('b',rows);a=self.book('a',[rows[0],rows[2],rows[1]])
        r=compare(b,a,mapping=self.map());self.assertEqual([],r['changes']);self.assertEqual([],r['records'])
    def test_no_key_no_row_fallback(self):
        p=self.book('nokey',self.basic());r=compare(p,p)
        self.assertEqual([],r['records']);self.assertEqual([],r['changes']);self.assertTrue(r['unmatched']);self.assertTrue(r['metrics'])
    def test_duplicate_key_blocks_all(self):
        b=self.book('b',self.basic());rows=self.basic()+[['001','丙',22,'2026-01-01','在职']];a=self.book('dup',rows)
        r=compare(b,a,mapping=self.map());self.assertTrue(any('重复' in str(x) for x in r['unmatched']));self.assertEqual([],r['records']);self.assertEqual([],r['changes'])
        swapped=compare(a,b,mapping=self.map());self.assertTrue(swapped['unmatched']);self.assertFalse(swapped['records'])
    def test_field_reorder_uses_names(self):
        b=self.book('b',[['工号','值'],['001',2]])
        a=self.book('a',[['值','工号'],[2,'001']])
        r=compare(b,a,mapping=self.map());self.assertEqual([],r['changes']);self.assertEqual([],r['records'])
        self.assertTrue(any(x[2]=='字段顺序变化' for x in r['structure']))
    def test_empty_formula_or_missing_key_blocks(self):
        b=self.book('b',self.basic())
        for key in (None,'=1+1','#REF!'):
            rows=self.basic();rows[1][0]=key;a=self.book('a',rows)
            r=compare(b,a,mapping=self.map());self.assertTrue(r['unmatched']);self.assertFalse(r['records'])
        r=compare(b,b,mapping=self.map(['不存在']));self.assertTrue(r['unmatched'])
    def test_composite_key_match(self):
        rows=[['工号','批次','值'],['001','A',1],['001','B',2]];b=self.book('b',rows)
        rows[2][2]=3;a=self.book('a',rows);r=compare(b,a,mapping=self.map(['工号','批次']))
        self.assertEqual(1,len(r['changes']));self.assertFalse(r['unmatched'])
    def test_sheet_and_field_addition_deletion(self):
        b=self.book('b',[['工号','旧字段'],['001','旧']],others={'删除表':[['ID'],['x']]})
        a=self.book('a',[['工号','新字段'],['001','新']],others={'新增表':[['ID'],['y']]})
        r=compare(b,a,mapping=self.map());types={x[2] for x in r['structure']}
        self.assertTrue({'新增字段','删除字段','新增Sheet','删除Sheet'}<=types)
    def test_explicit_sheet_and_field_mapping(self):
        b=self.book('b',[['工号','值'],['001',1]])
        a=self.book('a',[['员工编号','费用'],['001',2]],sheet='人员')
        mapping={'sheets':[{'before':'员工','after':'人员','keys':['工号'],'fields':{'工号':'员工编号','值':'费用'}}]}
        policy=self.policy(required_fields=['工号'],field_types={'工号':'identifier','值':'number'})
        r=compare(b,a,policy,mapping);self.assertEqual(1,len(r['changes']));self.assertFalse(r['unmatched'])
        self.assertEqual(0,sum(o['violations'] for o in r['after_audit']['overview']))
    def test_invalid_mapping(self):
        for m in ({'sheets':[{'before':'员工','after':'员工','fields':{'A':'X','B':'X'}}]},
                  {'sheets':[{'before':'员工','after':'员工'},{'before':'员工','after':'新'}]}):
            with self.assertRaises(AuditError):validate_mapping(m)
        p=self.book('data',self.basic())
        with self.assertRaises(AuditError):compare(p,p,mapping={'sheets':[{'before':'员工','after':'员工','fields':{'不存在':'年龄'}}]})
    def test_different_rules_refused(self):
        p=self.book('same',self.basic())
        with self.assertRaises(AuditError):compare(p,p,self.policy(required_fields=['姓名']),after_config={})
    def test_scale_change_preserves_denominators(self):
        b=self.book('b',[['工号','值'],['001',None],['002',2]])
        a=self.book('a',[['工号','值']]+[[str(i),None if i<2 else 1] for i in range(100)])
        r=compare(b,a,mapping=self.map())
        m=next(x for x in r['metrics'] if x[2]=='缺失值')
        self.assertEqual([1,2,1,4,200],m[3:8]);self.assertEqual(.25,m[8]);self.assertEqual(.01,m[9])
    def test_deleted_required_field_reported(self):
        b=self.book('b',self.basic());a=self.book('a',[['工号','年龄'],['001',18]])
        r=compare(b,a,self.policy(required_fields=['姓名']),self.map())
        self.assertTrue(any(x['type']=='要求字段不存在' for x in r['after_audit']['issues']))
    def test_primary_key_text_and_number_distinct(self):
        b=self.book('b',[['工号'],['001']]);a=self.book('a',[['工号'],[1]])
        r=compare(b,a,mapping=self.map());self.assertEqual(2,len(r['records']))
    def test_unusable_structure_not_zero_improvement(self):
        b=self.book('b',self.basic());a=self.book('a',[['工号',None],['001',2]])
        r=compare(b,a,mapping=self.map());m=next(x for x in r['metrics'] if x[2]=='缺失值')
        self.assertIsNone(m[4]);self.assertIsNone(m[5]);self.assertTrue(r['unmatched'])
    def test_error_rate_uses_scanned_cells(self):
        p=self.book('err',[['结果'],['#REF!']])
        r=compare(p,p);m=next(x for x in r['metrics'] if x[2]=='公式或已有错误')
        self.assertEqual(1,m[3]);self.assertEqual(2,m[6]);self.assertEqual(.5,m[8])
    def test_compare_report_reopen_safe_and_complete(self):
        b=self.book('b',[['工号','备注'],['001','普通']]);a=self.book('a',[['工号','备注'],['001','=1+1']])
        m=self.root/'mapping.json';m.write_text(json.dumps(self.map()))
        r,d=compare_run(b,a,self.root/'out',mapping_path=m)
        w=load_workbook(d/'Excel数据差异对比报告.xlsx',read_only=True)
        self.assertEqual(7,len(w.sheetnames));self.assertFalse(any(c.data_type=='f' for s in w for row in s for c in row));w.close()
        self.assertTrue((d/'处理前/Excel数据体检报告.xlsx').exists());self.assertTrue((d/'处理后/数据质量摘要.md').exists())

if __name__=='__main__':unittest.main()
