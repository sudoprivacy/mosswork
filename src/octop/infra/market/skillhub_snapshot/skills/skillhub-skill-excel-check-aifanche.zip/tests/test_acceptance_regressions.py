"""Regressions found by independent acceptance, separate from original design cases."""
import sys,tempfile,unittest
from pathlib import Path
from openpyxl import Workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from rules_engine import audit
from compare_excel import compare
from excel_parser import AuditError

class AcceptanceRegressions(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def book(self,name,rows):
        w=Workbook();s=w.active;s.title='验收'
        for r in rows:s.append(r)
        p=self.root/(name+'.xlsx');w.save(p);w.close();return p
    def test_complete_duplicates_include_optional_empty_cells(self):
        p=self.book('重复',[['编号','姓名','可选年龄'],['X001','合成甲',None],['X001','合成甲',None]])
        r=audit(p);d=[x for x in r['issues'] if x['type']=='完全重复记录']
        self.assertEqual(['A3,B3,C3'],[x['cell'] for x in d])
        c={'sheets':{'验收':{'key_fields':['可选年龄']}}}
        self.assertFalse(any(x['type']=='关键字段重复' for x in audit(p,c)['issues']))
    def test_declared_fields_missing_even_if_sheet_empty(self):
        p=self.book('空表',[])
        r=audit(p,{'sheets':{'验收':{'required_columns':['编号','年龄'],'numeric_ranges':{'年龄':{'min':18}}}}})
        self.assertEqual({'编号','年龄'},{x['field'] for x in r['issues'] if x['type']=='要求字段不存在'})
        self.assertEqual(2,r['overview'][0]['violations'])
    def test_mapped_rules_cannot_overwrite_implicit_rule_targets(self):
        b=self.book('前',[['编号','年龄','金额'],['X001',17,200]])
        a=self.book('后',[['编号','金额'],['X001',17]])
        rules={'sheets':{'验收':{'numeric_ranges':{'年龄':{'min':18},'金额':{'min':0,'max':10000}}}}}
        mapping={'sheets':[{'before':'验收','after':'验收','keys':['编号'],'fields':{'年龄':'金额'}}]}
        with self.assertRaises(AuditError):compare(b,a,rules,mapping)

if __name__=='__main__':unittest.main()
