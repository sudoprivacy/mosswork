"""Explicit synthetic data construction, NOT an automated repair implementation."""
from pathlib import Path
from openpyxl import Workbook

def make(directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    def write(path,title,rows):
        path.parent.mkdir(parents=True,exist_ok=True)
        w=Workbook();s=w.active;s.title=title
        for r in rows:s.append(r)
        w.save(path);w.close()
    staff=[['工号','姓名','年龄','状态','入职日期'],
           ['0001','合成甲',18,'在职','2026-01-01'],['0002',None,17,'待定','2026-02-30'],
           ['0002','合成丙',66,'在职','2019-12-31'],['0004','合成丁','35','在职','2026/03/01']]
    sales=[['订单号','行号','金额'],['D001',1,100],['D001',1,100],['D001',2,-10],['D002','1',150000]]
    expenses=[['单据号','项目','费用','日期'],['E001','差旅',88.50,'2026-01-01'],['E002','其他',-1,'2025-12-31'],['E002','培训','300','2026-02-30'],['E004','办公',None,'2026-03-01']]
    write(directory/'员工信息表.xlsx','员工信息',staff)
    write(directory/'销售订单表.xlsx','销售订单',sales)
    write(directory/'费用明细表.xlsx','费用明细',expenses)
    before=[['工号','姓名','年龄','状态','入职日期'],
            ['0001','合成甲',18,'在职','2026-01-01'],['0002',None,17,'在职','2026-02-01'],['0003','合成丙',66,'待定','2026-03-01']]
    after=[['工号','姓名','年龄','状态','入职日期','备注'],
           ['0002','合成乙',20,'在职','2026-02-01','示例核对'],['0001','合成甲',18,'在职','2026-01-01','顺序变化'],['0004','合成丁',40,'在职','2026-04-01','新增示例']]
    write(directory/'对比/处理前.xlsx','员工信息',before)
    write(directory/'对比/处理后.xlsx','员工信息',after)
    return directory
