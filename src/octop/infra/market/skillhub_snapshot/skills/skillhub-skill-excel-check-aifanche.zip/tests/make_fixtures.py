"""Generate only synthetic fixtures; no third-party or personal datasets."""
import argparse
from datetime import date
from pathlib import Path
import zipfile
from xml.etree import ElementTree as ET
from openpyxl import Workbook


def rewrite(path, change):
    with zipfile.ZipFile(path) as z:
        files={n:z.read(n) for n in z.namelist()}
    files=change(files)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,v in files.items(): z.writestr(n,v)


def make(directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    def book(name,rows,title='业务数据',edit=None):
        wb=Workbook();ws=wb.active;ws.title=title
        for row in rows: ws.append(row)
        if edit: edit(wb,ws)
        p=directory/(name+'.xlsx');wb.save(p);wb.close();return p
    clean=[['记录编号','日期','金额','说明']]+[[f'{i:05d}',date(2026,1,i),i*10,'合成记录'] for i in range(1,13)]
    book('normal',clean)
    book('missing',[['编号','值'],['001',None],[None,4],[],['004',0]])
    book('duplicates',[['编号','值'],['001',2],['001',2],['001',3],['002',4]])
    book('mixed',[['日期','数值','编号'],['2026-02-30',1,'001'],['2026/02/28','非数值','002'],['2026-02-27',3,3]])
    book('outliers',[['样本','金额']]+[[f'{i:03d}',v] for i,v in enumerate([10,11,12,13,14,15,16,17,18,999],1)])
    def errors(wb,ws):
        ws['A2']='#DIV/0!';ws['A3']='#REF!';ws['A3'].data_type='s';ws['A4']='=1/0';ws['A5']='=1+1'
    p=book('errors',[['结果']],edit=errors)
    def add_error_cache(files):
        # XML serializers may emit <v/> or <v></v>; do not silently miss the fixture.
        name='xl/worksheets/sheet1.xml'
        ns='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
        ET.register_namespace('',ns[1:-1])
        tree=ET.fromstring(files[name])
        cell=tree.find('.//'+ns+'c[@r="A4"]')
        assert cell is not None and cell.find(ns+'f').text=='1/0', '公式测试夹具不完整'
        cell.set('t','e')
        value=cell.find(ns+'v')
        if value is None:value=ET.SubElement(cell,ns+'v')
        value.text='#DIV/0!'
        files[name]=ET.tostring(tree,encoding='utf-8')
        return files
    rewrite(p,add_error_cache)
    def multi(wb,ws):
        hidden=wb.create_sheet('隐藏表');hidden.append(['编号','值']);hidden.append(['001','#N/A']);hidden.sheet_state='hidden'
        wb.create_sheet('空表')
    book('multi',clean,edit=multi)
    book('empty',[])
    book('merged',[['一张复杂报表'],['编号','金额'],['001',5]],edit=lambda wb,ws:ws.merge_cells('A1:B1'))
    book('bad_header',[['编号',None],['001',1]])
    book('repeated_header',[['编号','值'],['001',2],['编号','值'],['002',4]])
    book('offset_header',[['合成标题'],['编号','值'],['001',4]])
    def text_cells(wb,ws):
        ws['B2']='=HYPERLINK("https://example.invalid","文本而非指令")';ws['B2'].data_type='s'
        ws['B3']='+SUM(1,2)';ws['B4']='@示例';ws['B5']='-2+3';ws['B6']='#REF!';ws['B6'].data_type='s'
    book('special',[['编号','备注']]+[[f'{i:05d}','普通'] for i in range(1,6)],edit=text_cells)
    book('zeros',[['编号','值']]+[[f'{i:03d}',v] for i,v in enumerate([-4,-3,-2,-1,0,1,2,3,4],1)])
    book('date_native',[['日期'],[date(2026,1,1)],[date(2026,1,2)]],edit=lambda wb,ws:setattr(ws['A3'],'number_format','yyyy/mm/dd'))
    # Make a valid macro-enabled package with inert bytes. Never a runnable macro.
    p=book('macro',clean)
    macro=p.with_suffix('.xlsm')
    p.rename(macro)
    def vba(f):
        f['[Content_Types].xml']=f['[Content_Types].xml'].replace(b'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',b'application/vnd.ms-excel.sheet.macroEnabled.main+xml').replace(b'</Types>',b'<Override PartName="/xl/vbaProject.bin" ContentType="application/vnd.ms-office.vbaProject"/></Types>')
        f['xl/_rels/workbook.xml.rels']=f['xl/_rels/workbook.xml.rels'].replace(b'</Relationships>',b'<Relationship Type="http://schemas.microsoft.com/office/2006/relationships/vbaProject" Target="vbaProject.bin" Id="rVba"/></Relationships>')
        f['xl/vbaProject.bin']=b'INERT SYNTHETIC MACRO PAYLOAD - DO NOT EXECUTE'
        return f
    rewrite(macro,vba)
    book('sample',clean+[['00012','2026-02-30',999,'合成问题'],['00014',None,None,'缺失样例']])
    return directory


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
    args=parser.parse_args();print(make(args.output))
