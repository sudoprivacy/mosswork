---
name: skillhub-skill-vtrip-flight-manual-change
description: "# Vtrip 商旅 · 机票人工改签（flight-manual-change）"
---

# Vtrip 商旅 · 机票人工改签（flight-manual-change）

本 Skill 由湖南视旅科技有限公司提供。面向 **TMC 运营 Agent**，在**分销改签单**上办理回填费用、引导支付、人工出票、拒办。

**只调 MCP**；须已连接「视旅 TMC」。写操作须 `clientConfirm=true`。

## 硬边界（最重要）

- **回填费用 / 人工出票 / 拒办**：只操作**分销订单**——`supply_flight_order_list` / `supply_flight_order_detail` / `supply_flight_order_fulfill`（`orderType=CHANGE`）。
- **企业客户订单**（`tmc_flight_order_*`）**只用于**：看企业支付短链、确认企业侧是否已到待支付；**禁止**用企业 detail 当回填主单、禁止只回企业单信息却声称在回填。
- 对人说明时：回填阶段说「分销改签单 … 待费用回填」；支付阶段再说企业支付短链。不要全程只报企业客户单。

## 何时使用（触发）

- 「我要回填费用」「改签单待回填」「帮我填改签费」
- 「改签费用回填一下」「非自愿改签已经提交了，接下来回填」
- 「支付完了，帮我出票填票号」
- 「这笔改签拒掉」

不适用：还没提交的改签申请（用 `flight-change`）、退票人工履约（用 `flight-manual-refund`）、出票域人工出票（用 `flight-ops`）。

## 能力一句话

本 Skill **在分销改签单上**调 `supply_flight_order_fulfill` + `CHANGE_FEE_BACKFILL` 回填费用；不是只查企业单、也不是只给网页。

## 办理顺序

1. **分销待费用回填**：定位**分销**改签单 → 收齐金额 → `CHANGE_FEE_BACKFILL`  
2. **企业待支付**：再用 `tmc_flight_order_detail` 取**企业**支付短链引导付款  
3. **分销待出票**：`CHANGE_MANUAL_ISSUE`  
4. **拒办**：`CHANGE_REFUSE_APPLY`（待回填）/ `CHANGE_REFUSE_ORDER`（待出票）

## 如何执行

> 缺金额/票号先问；**禁止编造**。回填前先说「我先查分销改签单，再帮你回填」。

**1. 定位分销改签单（回填/出票/拒办的主路径）**
- 用 `supply_flight_order_list` / `supply_flight_order_detail`，`orderType=CHANGE`。
- 用户给的改签单号（如 `813…`）先当**分销** `orderId` 查；若 list 支持企业采购单号，也可用企业改签单号去筛分销单。
- 核对分销状态：待回填≈status=0；待出票≈status=2。
- 对人回复优先报：**分销改签单号、分销状态、乘机人、航段**；不要只贴企业客户订单字段。

**2. 回填费用（分销 status=0）** — `supply_flight_order_fulfill`
- `orderId` = **分销**改签单号；`action=CHANGE_FEE_BACKFILL`；`clientConfirm=true`；`changeFee` 按 schema。
- 对话：列出差价/手续费/税差/PNR（若要）→ 用户给数 → 复述 → 确认后提交。
- 分销 detail 无费用属正常，费用由运营录入。

**3. 支付引导（企业待支付）** — `tmc_flight_order_detail`（`orderType=CHANGE`）
- **仅此步**以企业单为主：取企业支付/页面短链；不代付。
- 回填刚成功可先轮询分销 detail，再查企业 detail 是否待支付。

**4. 人工出票（分销 status=2）** — `supply_flight_order_fulfill`
- 仍用**分销** `orderId`；`CHANGE_MANUAL_ISSUE`；票证账号先问。

**5. 拒绝** — 分销单上 `CHANGE_REFUSE_APPLY` / `CHANGE_REFUSE_ORDER`

## 硬性规则

1. 回填/出票/拒办的 `orderId` 必须是分销单号；禁止对企业单调 `supply_flight_order_fulfill`。
2. 写操作前对话确认 + `clientConfirm=true`。办理 action：`CHANGE_FEE_BACKFILL` / `CHANGE_MANUAL_ISSUE`；拒绝：`CHANGE_REFUSE_APPLY`（待回填）/ `CHANGE_REFUSE_ORDER`（待出票，≠ APPLY）。禁止把拒绝与完成出票混用。
3. 未到分销 status=2 禁止 `CHANGE_MANUAL_ISSUE`；票证账号先对话追问，未提供再从详情带出。
4. 支付只用企业改签单短链。
5. 工具不在 `tools/list`：说明 MCP 未开通并停止。
6. 对人**全程中文**；优先朗读自然语言出参；**禁止**念英文字段名与数字码。

## 典型话术 → 动作

| 用户说 | 你做 |
|--------|------|
| 「我要回填费用」 | **分销** list/detail → 要金额 → `CHANGE_FEE_BACKFILL` |
| 「改签单待回填」 | 同上 |
| 「这笔改签拒掉」 | **分销** status=0/2 → 对应拒绝 action |
| 「支付完了帮我出票」 | **分销** status=2 → `CHANGE_MANUAL_ISSUE` |

## 相关工具

| 工具 | 用途 |
|------|------|
| `supply_flight_order_list` / `detail` | **主路径**：定位分销改签单、核对状态 |
| `supply_flight_order_fulfill` | 分销上回填/出票/拒绝 |
| `tmc_flight_order_detail` | **仅**企业支付短链 / 企业态确认 |
