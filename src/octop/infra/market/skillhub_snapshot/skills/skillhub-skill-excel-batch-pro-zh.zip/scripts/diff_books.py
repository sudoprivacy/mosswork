#!/usr/bin/env python3
"""diff_books.py —— 两份表格对账找差异（Excel 批量处理进阶版）

按关键列（如单号、姓名、编号）比对两份表，输出三类差异：
  仅A有 / 仅B有 / 两边都有但数值不一致。
适合：进销存对账、银行流水核对、两个系统导出数据核对。

用法:
  python3 diff_books.py 系统导出.xlsx 手工台账.xlsx --key 单号 --output 对账报告.xlsx
  python3 diff_books.py a.csv b.csv --key 工号 --compare 金额 实发 --output 差异.xlsx
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from merge_sheets import read_table
except ImportError as e:
    raise SystemExit(f"[X] 缺少同目录基础模块 merge_sheets.py：{e}")

try:
    from openpyxl import Workbook
except ImportError:
    raise SystemExit("[X] 未安装 openpyxl。请先执行：pip install openpyxl")

from xlsx_style import (BAND_BG, HEADER_BG, HEADER_FG, auto_width, band_rows,
                        f_cell, f_header, freeze, header_row, numfmt_for,
                        safe_value, sheet_defaults)


def norm_key(v) -> str:
    """键值标准化：去首尾空格、数字去尾零，尽量让 '001' 和 '1' 能对上。"""
    if v is None:
        return ""
    s = str(v).strip()
    if s.replace(".", "", 1).replace("-", "", 1).isdigit():
        try:
            f = float(s)
            if f == int(f):
                return str(int(f))
            return str(f)
        except ValueError:
            pass
    return s


def to_num(v):
    if v is None or str(v).strip() == "":
        return None
    try:
        return float(str(v).replace(",", "").replace("¥", "").replace("￥", "").strip())
    except ValueError:
        return None


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="两份表格对账找差异")
    ap.add_argument("file_a", help="A 表（如系统导出）")
    ap.add_argument("file_b", help="B 表（如手工台账）")
    ap.add_argument("--key", required=True, help="关键列名（两边都要有）")
    ap.add_argument("--compare", nargs="*", help="要比值的列名（默认：两边共有的数值列全比）")
    ap.add_argument("--header-row", type=int, help="表头所在行号（默认自动识别）")
    ap.add_argument("--output", default="对账报告.xlsx", help="差异报告输出文件")
    args = ap.parse_args()

    pa, pb = Path(args.file_a), Path(args.file_b)
    for p in (pa, pb):
        if not p.exists():
            raise SystemExit(f"[X] 找不到文件：{p}")

    ta = [t for t in read_table(pa, None, args.header_row) if t[2]]
    tb = [t for t in read_table(pb, None, args.header_row) if t[2]]
    if not ta or not tb:
        raise SystemExit("[X] 至少一份文件没有读到数据行")
    name_a, heads_a, rows_a = ta[0]
    name_b, heads_b, rows_b = tb[0]
    if args.key not in heads_a:
        raise SystemExit(f"[X] A 表（{name_a}）没有列「{args.key}」，现有：{'、'.join(heads_a)}")
    if args.key not in heads_b:
        raise SystemExit(f"[X] B 表（{name_b}）没有列「{args.key}」，现有：{'、'.join(heads_b)}")

    ka_i, kb_i = heads_a.index(args.key), heads_b.index(args.key)
    dict_a = {norm_key(r[ka_i] if ka_i < len(r) else None): r for r in rows_a}
    dict_b = {norm_key(r[kb_i] if kb_i < len(r) else None): r for r in rows_b}

    # 确定要比值的列
    if args.compare:
        cmp_cols = [c for c in args.compare if c in heads_a and c in heads_b]
        missing = [c for c in args.compare if c not in cmp_cols]
        if missing:
            print(f"[!] 这些列在两边不同时存在，跳过：{'、'.join(missing)}")
    else:
        cmp_cols = [h for h in heads_a if h in heads_b and h != args.key
                    and any(isinstance(to_num(r[heads_a.index(h)]), float) for r in rows_a[:50])]
        if cmp_cols:
            print(f"[i] 自动选中数值比对列：{'、'.join(cmp_cols)}")

    only_a = [k for k in dict_a if k and k not in dict_b]
    only_b = [k for k in dict_b if k and k not in dict_a]
    both = [k for k in dict_a if k in dict_b and k]

    diffs = []  # (键, 列, A值, B值, 差额)
    for k in both:
        ra, rb = dict_a[k], dict_b[k]
        for col in cmp_cols:
            va = ra[heads_a.index(col)] if heads_a.index(col) < len(ra) else None
            vb = rb[heads_b.index(col)] if heads_b.index(col) < len(rb) else None
            na, nb = to_num(va), to_num(vb)
            if na is None and nb is None:
                continue
            if na != nb:
                diffs.append((k, col, va, vb,
                              None if (na is None or nb is None) else round(na - nb, 6)))

    print(f"\n对账结果（A={pa.name}/{name_a}，B={pb.name}/{name_b}，键列「{args.key}」）：")
    print(f"  两边匹配：{len(both)} 行")
    print(f"  仅 A 有：{len(only_a)} 行")
    print(f"  仅 B 有：{len(only_b)} 行")
    print(f"  数值不一致：{len(diffs)} 处（涉及 {len({d[0] for d in diffs})} 行）")
    if not cmp_cols:
        print("  [!] 没有可比值的列，只做了存在性核对")

    # 写报告
    wb = Workbook()
    ws = wb.active
    ws.title = "对账汇总"
    sheet_defaults(ws)
    from xlsx_style import title as st_title, legend
    st_title(ws, "对账汇总", span=4)
    summary = [
        ("A 表", f"{pa.name} / {name_a}（{len(rows_a)} 行）"),
        ("B 表", f"{pb.name} / {name_b}（{len(rows_b)} 行）"),
        ("键列", args.key),
        ("两边匹配", f"{len(both)} 行"),
        ("仅 A 有", f"{len(only_a)} 行"),
        ("仅 B 有", f"{len(only_b)} 行"),
        ("数值不一致", f"{len(diffs)} 处"),
    ]
    for i, (k, v) in enumerate(summary, start=3):
        ws.cell(row=i, column=1, value=k).font = f_header()
        ws.cell(row=i, column=2, value=v).font = f_cell()
    ws.column_dimensions["A"].width = 16
    ws.column_dimensions["B"].width = 52

    def write_sheet(ws_, headers_, rows_, nfmt=None):
        sheet_defaults(ws_)
        header_row(ws_, 1, headers_)
        for ri, r in enumerate(rows_, start=2):
            for ci, v in enumerate(r, start=1):
                c = ws_.cell(row=ri, column=ci, value=safe_value(v))
                c.font = f_cell()
                if nfmt and nfmt[ci - 1]:
                    c.number_format = nfmt[ci - 1]
        if rows_:
            band_rows(ws_, 2, len(rows_) + 1)
        freeze(ws_, 1, len(headers_), last_row=len(rows_) + 1)
        auto_width(ws_, header_row=1)

    if only_a:
        cols_a = [args.key] + [h for h in heads_a if h != args.key]
        ws2 = wb.create_sheet("仅A有")
        rows2 = [[dict_a[k][heads_a.index(h)] if heads_a.index(h) < len(dict_a[k]) else None
                  for h in cols_a] for k in only_a]
        write_sheet(ws2, cols_a, rows2)
    if only_b:
        cols_b = [args.key] + [h for h in heads_b if h != args.key]
        ws3 = wb.create_sheet("仅B有")
        rows3 = [[dict_b[k][heads_b.index(h)] if heads_b.index(h) < len(dict_b[k]) else None
                  for h in cols_b] for k in only_b]
        write_sheet(ws3, cols_b, rows3)
    if diffs:
        ws4 = wb.create_sheet("数值差异")
        heads4 = [args.key, "列名", "A表值", "B表值", "差额(A-B)"]
        write_sheet(ws4, heads4, diffs)

    out = Path(args.output)
    wb.save(out)
    print(f"\n[OK] 差异报告已输出 → {out.resolve()}"
          f"（{wb.sheetnames}）" if (only_a or only_b or diffs) else f"\n[OK] 完全一致，仍输出汇总 → {out.resolve()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
