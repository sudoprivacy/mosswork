#!/usr/bin/env node
// call-pro.mjs — Excel 批量处理进阶版的付费门禁客户端
// 流程：POST /api/excel/pro → 402(账单) → 引导支付 → Payment-Proof 重试 → task_token
// 用法：
//   node call-pro.mjs --op split --resource "销售明细.xlsx"          # 发起(返回账单)
//   node call-pro.mjs --op split --resource "..." --proof <bill文件> # 已付重试
import { writeFileSync, readFileSync, existsSync, mkdirSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { homedir } from 'node:os'
import { join } from 'node:path'

const BASE = process.env.EXCEL_PRO_BASE || 'https://excel-pro.app.workbuddy.host'
const SHARE = process.env.EXCEL_PRO_SHARE || '7AFCP6BE2W'   // 平台访问门禁参数
const PROOF_DIR = join(homedir(), '.excel-pro-skill')

function parseArgs(argv) {
  const out = {}
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--op' || a === '--resource' || a === '--proof') out[a.slice(2)] = argv[++i]
  }
  return out
}

function curlJson(args) {
  return execFileSync('curl', ['-s', '-m', '20', ...args], { encoding: 'utf8', maxBuffer: 8e6 })
}

const args = parseArgs(process.argv)
const op = args.op || 'task'
const resource = args.resource || ''
const url = `${BASE}/api/excel/pro?sharecode=${encodeURIComponent(SHARE)}&op=${encodeURIComponent(op)}&resource=${encodeURIComponent(resource)}`

const curlArgs = ['-X', 'POST', '-H', 'Content-Type: application/json']
let proofRaw = null
if (args.proof) {
  const pf = args.proof.startsWith('/') ? args.proof : join(PROOF_DIR, args.proof)
  if (!existsSync(pf)) { console.error(`[X] 找不到账单文件：${pf}`); process.exit(1) }
  proofRaw = readFileSync(pf, 'utf8').trim()
  curlArgs.push('-H', `Payment-Proof: ${proofRaw}`)
}
curlArgs.push(url)

const raw = curlJson(curlArgs)
let j
try { j = JSON.parse(raw) } catch {
  console.error('[X] 服务端返回异常：', raw.slice(0, 300)); process.exit(1)
}

if (j.code === 'OK' && j.task_token) {
  mkdirSync(PROOF_DIR, { recursive: true })
  const tf = join(PROOF_DIR, `token-${Date.now()}.json`)
  writeFileSync(tf, JSON.stringify(j, null, 2), { mode: 0o600 })
  console.log(`[OK] 已授权（本次已扣费 ¥${j.paid}）`)
  console.log(`凭证文件: ${tf}`)
  console.log(`可用操作: ${(j.ops || []).join(' / ')}`)
  process.exit(0)
}

if (j.code === 'PAYMENT_REQUIRED' || j.reason) {
  console.error(`[!] 需要支付：${j.reason || '未付款'}`)
  if (j.hint) console.error(`    ${j.hint}`)
  process.exit(2)
}

// 402 账单：curl 不带 -f 时 HTTP 状态不影响输出，Payment-Needed 头需单独拿
// 这里通过两次调用拿头（第一次 body 已是 PAYMENT_REQUIRED 提示，重取头）
const hdrOut = execFileSync('curl', ['-s', '-m', '20', '-D', '-', '-o', '/dev/null',
  ...curlArgs.filter(a => a !== '-D' && a !== '-')], { encoding: 'utf8', maxBuffer: 8e6 })
const pn = hdrOut.split('\r\n').find(l => /^Payment-Needed:/i.test(l))?.split(':').slice(1).join(':').trim()
const amt = hdrOut.split('\r\n').find(l => /^amtPaymentLink:/i.test(l))?.split(':').slice(1).join(':').trim()

if (!pn) {
  console.error('[X] 未拿到账单（服务可能不可用）')
  process.exit(1)
}
mkdirSync(PROOF_DIR, { recursive: true })
const billFile = join(PROOF_DIR, `bill-${Date.now()}.txt`)
writeFileSync(billFile, pn, { mode: 0o600 })
let bill = {}
try { bill = JSON.parse(Buffer.from(pn, 'base64url').toString('utf8')) } catch {}
console.log('=== 需要支付（支付宝 AI 按量付费） ===')
console.log(`金额: ¥${bill.amount || '?'}  订单号: ${bill.out_trade_no || '?'}`)
console.log(`服务: ${bill.service || 'Excel批量处理进阶版'}`)
console.log(`账单文件: ${billFile}`)
console.log(`amtPaymentLink: ${amt || '(见账单)'}`)
console.log('--- 给调用方的说明 ---')
console.log('请用支付宝 AI 付流程完成支付（解析 Payment-Needed 账单 → 引导用户付款 →')
console.log('拿 Payment-Proof → 重新执行: node call-pro.mjs --op ' + op + ' --resource "' + resource + '" --proof "' + billFile + '"）')
process.exit(2)
