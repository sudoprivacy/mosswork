#!/usr/bin/env python3
"""convert_batch.py —— 批量格式转换（Excel 批量处理进阶版）

xlsx/xlsm ↔ csv ↔ json 批量互转。多工作表导出 CSV/JSON 时，
每张表一个文件，文件名带表名；CSV 转 xlsx 自动套专业版式。

用法:
  python3 convert_batch.py "报表/*.xlsx" --to csv --outdir 导出/
  python3 convert_batch.py "数据/*.csv" --to xlsx --outdir 汇总/
  python3 convert_batch.py 明细.xlsx --to json --outdir 导出/
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from merge_sheets import expand_inputs, read_table
except ImportError as e:
    raise SystemExit(f"[X] 缺少同目录基础模块 merge_sheets.py：{e}")

try:
    from openpyxl import Workbook
except ImportError:
    raise SystemExit("[X] 未安装 openpyxl。请先执行：pip install openpyxl")

from xlsx_style import (auto_width, band_rows, f_cell, f_header, freeze,
                        header_row, numfmt_for, safe_value, sheet_defaults)


def json_default(o):
    if isinstance(o, (datetime, date)):
        return o.isoformat(sep=" " if isinstance(o, datetime) else "T")[:19]
    return str(o)


def write_csv(rows, headers, out: Path):
    import csv
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(headers)
        for r in rows:
            w.writerow([json_default(v) if isinstance(v, (datetime, date)) else ("" if v is None else v) for v in r])


def write_json(rows, headers, out: Path):
    out.parent.mkdir(parents=True, exist_ok=True)
    records = []
    for r in rows:
        rec = {}
        for i, h in enumerate(headers):
            v = r[i] if i < len(r) else None
            if isinstance(v, (datetime, date)):
                v = json_default(v)
            rec[h] = v
        records.append(rec)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"sheet_rows": len(records), "headers": headers, "data": records},
                  fh, ensure_ascii=False, indent=1, default=json_default)


def write_xlsx(rows, headers, out: Path):
    out.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    sheet_defaults(ws)
    header_row(ws, 1, headers)
    for ri, r in enumerate(rows, start=2):
        for ci, v in enumerate(r, start=1):
            c = ws.cell(row=ri, column=ci, value=safe_value(v))
            c.font = f_cell()
            nf = numfmt_for("float" if isinstance(v, float) else "int" if isinstance(v, int) else None)
            if nf:
                c.number_format = nf
    if rows:
        band_rows(ws, 2, len(rows) + 1)
    freeze(ws, 1, len(headers), last_row=len(rows) + 1)
    auto_width(ws, header_row=1)
    wb.save(out)


def safe_name(s: str) -> str:
    return "".join(c if c not in '\\/:*?"<>|' else "_" for c in str(s))[:60] or "sheet"


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="批量格式转换 xlsx/csv/json")
    ap.add_argument("inputs", nargs="+", help="输入文件或通配符")
    ap.add_argument("--to", required=True, choices=["csv", "json", "xlsx"], help="目标格式")
    ap.add_argument("--outdir", required=True, help="输出目录")
    ap.add_argument("--sheets", nargs="*", help="只转换指定名称的工作表")
    ap.add_argument("--header-row", type=int, help="表头所在行号（默认自动识别）")
    args = ap.parse_args()

    files = expand_inputs(args.inputs)
    if not files:
        raise SystemExit("[X] 没有匹配到任何输入文件")
    only = set(args.sheets) if args.sheets else None
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    n_files = 0
    for f in files:
        for sheet_name, headers, rows in read_table(f, only, args.header_row):
            if not rows:
                continue
            stem = safe_name(f.stem if len(files) > 1 else f.stem)
            name = f"{stem}__{safe_name(sheet_name)}" if len(files) > 1 or args.sheets is None else safe_name(sheet_name)
            # xlsx 单表时名字保持简洁；同前缀多表用 __ 连接
            if args.to == "csv":
                out = outdir / f"{name}.csv"
                write_csv(rows, headers, out)
            elif args.to == "json":
                out = outdir / f"{name}.json"
                write_json(rows, headers, out)
            else:
                out = outdir / f"{safe_name(sheet_name)}.xlsx" if f.suffix.lower() == ".csv" else outdir / f"{name}.xlsx"
                write_xlsx(rows, headers, out)
            n_files += 1
            print(f"  · {f.name}/{sheet_name}（{len(rows)} 行）→ {out.name}")

    if not n_files:
        raise SystemExit("[X] 没有读到任何数据行，未生成文件")
    print(f"[OK] 转换完成：{n_files} 个文件 → {outdir.resolve()}/")
    if args.to == "csv":
        print("     CSV 为 UTF-8 BOM 编码，Excel/WPS 双击打开不乱码")
    return 0


if __name__ == "__main__":
    sys.exit(main())
