#!/usr/bin/env python3
"""split_workbook.py —— 按列值拆分工作表（Excel 批量处理进阶版）

把一张表按指定列的值拆成多个文件或多个工作表，常用于：
按部门拆考勤、按业务员拆销售明细、按地区拆订单。

用法:
  python3 split_workbook.py 销售明细.xlsx --column 业务员 --outdir 拆分/
  python3 split_workbook.py 考勤.xlsx --column 部门 --mode sheet --output 按部门.xlsx
  python3 split_workbook.py 订单.csv --column 城市 --outdir 城市/ --header-row 1
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from merge_sheets import read_table
except ImportError as e:
    raise SystemExit(f"[X] 缺少同目录基础模块 merge_sheets.py：{e}")

try:
    from openpyxl import Workbook
    from openpyxl.utils import get_column_letter
except ImportError:
    raise SystemExit("[X] 未安装 openpyxl。请先执行：pip install openpyxl")

from xlsx_style import (BAND_BG, HEADER_BG, HEADER_FG, LEGEND_GRAY, auto_width,
                        band_rows, f_cell, f_header, freeze, header_row,
                        numfmt_for, safe_value, sheet_defaults)


def sanitize(name: str) -> str:
    """把列值变成安全的文件名/sheet 名。"""
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", str(name).strip())
    return (s[:40] or "空值") or "空值"


def style_out(ws, headers, rows):
    """套用与 excel-auto-zh 一致的专业版式。"""
    sheet_defaults(ws)
    header_row(ws, 1, headers)
    numfmts = [numfmt_for(_guess_type(rows, i)) for i in range(len(headers))]
    for ri, row in enumerate(rows, start=2):
        for ci, val in enumerate(row, start=1):
            c = ws.cell(row=ri, column=ci, value=safe_value(val))
            c.font = f_cell()
            if numfmts[ci - 1]:
                c.number_format = numfmts[ci - 1]
    if rows:
        band_rows(ws, 2, len(rows) + 1)
    freeze(ws, 1, len(headers), last_row=len(rows) + 1)
    auto_width(ws, header_row=1)


def _guess_type(rows, col_idx):
    """粗判列类型给数字格式用。"""
    for r in rows[:30]:
        v = r[col_idx] if col_idx < len(r) else None
        if v is None or str(v).strip() == "":
            continue
        if isinstance(v, (int, float)):
            return "float" if isinstance(v, float) else "int"
        return "text"
    return "text"


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="按列值拆分工作表")
    ap.add_argument("input", help="输入文件（xlsx/xlsm/csv）")
    ap.add_argument("--column", required=True, help="拆分依据的列名（表头文字）")
    ap.add_argument("--sheet", help="只拆指定名称的工作表（默认取第一张有数据的表）")
    ap.add_argument("--header-row", type=int, help="表头所在行号（默认自动识别）")
    ap.add_argument("--mode", choices=["file", "sheet"], default="file",
                    help="file=每个值一个文件（默认）；sheet=每个值一张工作表")
    ap.add_argument("--outdir", help="输出目录（mode=file 时用，默认 <输入名>_拆分/）")
    ap.add_argument("--output", help="输出文件（mode=sheet 时用）")
    args = ap.parse_args()

    src = Path(args.input)
    if not src.exists():
        raise SystemExit(f"[X] 找不到输入文件：{src}")
    only = {args.sheet} if args.sheet else None
    tables = read_table(src, only, args.header_row)
    tables = [t for t in tables if t[2]]
    if not tables:
        raise SystemExit("[X] 输入文件里没有读到数据行")
    if len(tables) > 1 and not args.sheet:
        names = "、".join(t[0] for t in tables)
        print(f"[!] 文件含多张工作表（{names}），默认只拆第一张；"
              f"如需指定请加 --sheet 表名")

    sheet_name, headers, rows = tables[0]
    if args.column not in headers:
        raise SystemExit(f"[X] 表 {sheet_name} 中没有列「{args.column}」。"
                         f"现有列：{'、'.join(headers)}")
    col_idx = headers.index(args.column)

    groups: dict[str, list] = {}
    for r in rows:
        v = r[col_idx] if col_idx < len(r) else None
        key = str(v).strip() if v is not None and str(v).strip() else "（空值）"
        groups.setdefault(key, []).append(r)

    print(f"读取 {src.name} / {sheet_name}：{len(headers)} 列，{len(rows)} 行，"
          f"「{args.column}」共 {len(groups)} 个不同值")

    if args.mode == "file":
        outdir = Path(args.outdir) if args.outdir else src.parent / f"{src.stem}_拆分"
        outdir.mkdir(parents=True, exist_ok=True)
        for key, grp in groups.items():
            wb = Workbook()
            ws = wb.active
            ws.title = sanitize(key)[:31]
            style_out(ws, headers, grp)
            out = outdir / f"{sanitize(key)}.xlsx"
            wb.save(out)
            print(f"  · {out.name}：{len(grp)} 行")
        print(f"[OK] 已拆分为 {len(groups)} 个文件 → {outdir}/")
    else:
        out = Path(args.output) if args.output else src.parent / f"{src.stem}_按{args.column}.xlsx"
        wb = Workbook()
        wb.remove(wb.active)
        used = set()
        for key, grp in groups.items():
            title = sanitize(key)[:28]
            base, k = title, 2
            while title in used:
                title = f"{base[:26]}_{k}"
                k += 1
            used.add(title)
            ws = wb.create_sheet(title)
            style_out(ws, headers, grp)
            print(f"  · 工作表「{title}」：{len(grp)} 行")
        wb.save(out)
        print(f"[OK] 已拆分为 {len(groups)} 张工作表 → {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
