#!/usr/bin/env python3
"""clean_data.py —— 批量数据清洗（Excel 批量处理进阶版）

批量清洗多个 xlsx/csv：去首尾空格、去全空行、按关键列去重、
空值填充、表头标准化。每张表输出清洗统计，方便交付前交代。

用法:
  python3 clean_data.py "考勤/*.xlsx" --output 清洗结果.xlsx --dedup --trim
  python3 clean_data.py 名单.csv 客户.xlsx --key 手机号 --fillna "未填" --output 干净.xlsx
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    from merge_sheets import expand_inputs, read_table
except ImportError as e:
    raise SystemExit(f"[X] 缺少同目录基础模块 merge_sheets.py：{e}")

try:
    from openpyxl import Workbook
except ImportError:
    raise SystemExit("[X] 未安装 openpyxl。请先执行：pip install openpyxl")

from xlsx_style import (auto_width, band_rows, f_cell, f_header, freeze,
                        header_row, numfmt_for, safe_value, sheet_defaults)


def clean_table(headers, rows, opts):
    """返回 (新表头, 新行, 统计dict)。"""
    stats = {"原行数": len(rows), "去空行": 0, "去重": 0, "修剪空格": 0, "填充空值": 0}

    # 表头标准化：去空格
    headers = [str(h).strip() if h is not None else h for h in headers]

    # 修剪单元格空格
    new_rows = []
    if opts.trim:
        for r in rows:
            nr = []
            for v in r:
                if isinstance(v, str) and v != v.strip():
                    stats["修剪空格"] += 1
                    v = v.strip()
                nr.append(v)
            new_rows.append(nr)
    else:
        new_rows = [list(r) for r in rows]

    # 去全空行（清理后可能产生新的空行）
    before = len(new_rows)
    new_rows = [r for r in new_rows if any(v is not None and str(v).strip() != "" for v in r)]
    stats["去空行"] = before - len(new_rows)

    # 填充空值
    if opts.fillna is not None:
        for r in new_rows:
            for i, v in enumerate(r):
                if v is None or str(v).strip() == "":
                    r[i] = opts.fillna
                    stats["填充空值"] += 1

    # 去重
    if opts.key:
        if opts.key not in headers:
            raise SystemExit(f"[X] 没有列「{opts.key}」，现有列：{'、'.join(headers)}")
        ki = headers.index(opts.key)
        seen, out = set(), []
        for r in new_rows:
            k = str(r[ki]).strip() if ki < len(r) and r[ki] is not None else ""
            if k and k in seen:
                stats["去重"] += 1
                continue
            if k:
                seen.add(k)
            out.append(r)
        new_rows = out
    elif opts.dedup:
        seen, out = set(), []
        for r in new_rows:
            sig = tuple(str(v).strip() if v is not None else "" for v in r)
            if sig in seen:
                stats["去重"] += 1
                continue
            seen.add(sig)
            out.append(r)
        new_rows = out

    stats["清洗后行数"] = len(new_rows)
    return headers, new_rows, stats


def _col_numfmt(rows, i):
    """按前 20 行粗判该列数字格式。"""
    vals = [r[i] for r in rows[:20] if i < len(r) and r[i] is not None]
    if vals and all(isinstance(v, int) for v in vals):
        return numfmt_for("int")
    if vals and all(isinstance(v, (int, float)) for v in vals):
        return numfmt_for("float")
    return None


def write_ws(ws, headers, rows):
    sheet_defaults(ws)
    header_row(ws, 1, headers)
    nfmt = [_col_numfmt(rows, i) for i in range(len(headers))] if rows else None
    for ri, r in enumerate(rows, start=2):
        for ci, v in enumerate(r, start=1):
            c = ws.cell(row=ri, column=ci, value=safe_value(v))
            c.font = f_cell()
            if nfmt and nfmt[ci - 1]:
                c.number_format = nfmt[ci - 1]
    if rows:
        band_rows(ws, 2, len(rows) + 1)
    freeze(ws, 1, len(headers), last_row=len(rows) + 1)
    auto_width(ws, header_row=1)


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="批量数据清洗")
    ap.add_argument("inputs", nargs="+", help="输入文件或通配符（如 data/*.xlsx）")
    ap.add_argument("--output", required=True, help="输出文件（xlsx）")
    ap.add_argument("--key", help="按指定关键列去重（保留首次出现）")
    ap.add_argument("--dedup", action="store_true", help="整行完全相同才去重")
    ap.add_argument("--trim", action="store_true", default=True, help="修剪首尾空格（默认开启）")
    ap.add_argument("--no-trim", dest="trim", action="store_false", help="关闭空格修剪")
    ap.add_argument("--fillna", help="空值填充内容（如 --fillna 0）")
    ap.add_argument("--sheets", nargs="*", help="只处理指定名称的工作表")
    ap.add_argument("--header-row", type=int, help="表头所在行号（默认自动识别）")
    args = ap.parse_args()

    files = expand_inputs(args.inputs)
    if not files:
        raise SystemExit("[X] 没有匹配到任何输入文件")
    only = set(args.sheets) if args.sheets else None

    wb = Workbook()
    wb.remove(wb.active)
    total_stats = {"原行数": 0, "去空行": 0, "去重": 0, "修剪空格": 0,
                   "填充空值": 0, "清洗后行数": 0}
    report_rows = []
    used = set()

    for f in files:
        for sheet_name, headers, rows in read_table(f, only, args.header_row):
            if not rows:
                continue
            h2, r2, st = clean_table(headers, rows, args)
            for k in total_stats:
                total_stats[k] += st.get(k, 0)
            label = f"{f.stem}·{sheet_name}"[:28]
            base, k2 = label, 2
            while label in used:
                label = f"{base[:25]}_{k2}"
                k2 += 1
            used.add(label)
            ws = wb.create_sheet(label[:31])
            write_ws(ws, h2, r2)
            report_rows.append([label, st["原行数"], st["去空行"], st["去重"],
                                st["修剪空格"], st["填充空值"], st["清洗后行数"]])
            print(f"  · {label}：{st['原行数']} → {st['清洗后行数']} 行"
                  f"（去空 {st['去空行']}，去重 {st['去重']}，修剪 {st['修剪空格']}，填充 {st['填充空值']}）")

    if not report_rows:
        raise SystemExit("[X] 所有文件都没有读到数据行")

    # 清洗报告页
    ws = wb.create_sheet("清洗报告", 0)
    sheet_defaults(ws)
    heads = ["来源", "原行数", "去空行", "去重", "修剪空格", "填充空值", "清洗后行数"]
    header_row(ws, 1, heads)
    for ri, r in enumerate(report_rows, start=2):
        for ci, v in enumerate(r, start=1):
            ws.cell(row=ri, column=ci, value=safe_value(v)).font = f_cell()
    total_r = ["合计"] + [total_stats[h] for h in heads[1:]]
    for ci, v in enumerate(total_r, start=1):
        ws.cell(row=len(report_rows) + 2, column=ci, value=v).font = f_header()
    band_rows(ws, 2, len(report_rows) + 1)
    auto_width(ws, header_row=1)

    out = Path(args.output)
    wb.save(out)
    print(f"\n[OK] 清洗完成：{total_stats['原行数']} → {total_stats['清洗后行数']} 行，"
          f"共 {len(report_rows)} 张表 → {out.resolve()}")
    print("     第一张工作表是「清洗报告」，每张源表的清洗明细都在里面")
    return 0


if __name__ == "__main__":
    sys.exit(main())
