---
name: skillhub-skill-excel-batch-pro-zh
description: "Excel/WPS 批量处理进阶版技能。当用户需要把大表按部门/业务员/地区等列拆分成多个文件、两份表格对账找差异（仅A有/仅B有/数值不一致）、批量清洗数据（去空行去重修剪空格填充空值）、批量转换 xlsx/csv/json 格式时使用。开箱即用无需配置任何密钥，按次计费（支付宝AI付，2元/次）由 Agent 自动引导完成，成功处理才扣费。触发词：表格拆分、按列拆分、对账、找差异、数据清洗、去重、格式转换、批量转换、工作簿拆分、两表核对、差异比对、xlsx转csv、csv转xlsx、json互转、批量处理表格、数据整理。"
---

# Excel 批量处理进阶版（拆分 / 对账 / 清洗 / 转换）

> 开发者：文邦二手车-明西汉。本技能是 excel-auto-zh（免费版，已 10 万+安装）的**进阶付费版**，
> 专注四个高频批量场景，产物在 Excel 与 WPS 中均可打开。

**开箱即用**：不需要任何 API Key 配置。每次执行前会走一次支付宝 AI 按量付费（¥2.0/次），
由 Agent 自动引导完成，**成功处理才扣费**，未付款不会产生任何费用。

## Tools Required

exec（需要能执行 shell 命令、读写文件）

## Setup

```bash
pip install openpyxl   # 清洗/拆分/对账需要；格式转换读 csv 时不需要
```

- Windows 下把下文 `python3` 换成 `python`，`node` 不变。
- 脚本目录：`<技能目录>/scripts/`，调用一律用绝对路径。

## 付费流程（Agent 执行，用户只需在手机上确认付款）

**第 1 步 — 发起授权**（未付款时服务端返回账单）：

```bash
node "<技能目录>/scripts/call-pro.mjs" --op split --resource "销售明细.xlsx"
```

退出码 0 = 已授权（拿到 task_token，直接干活）；退出码 2 = 需要支付，
脚本已把账单存到 `~/.excel-pro-skill/bill-*.txt` 并打印金额与订单号。

**第 2 步 — 引导付款**：向用户展示账单中的金额（¥2.0）与 `amtPaymentLink`，
按支付宝 AI 付流程完成支付，取得 `Payment-Proof`（base64url）。

**第 3 步 — 凭证重试**：

```bash
node "<技能目录>/scripts/call-pro.mjs" --op split --resource "销售明细.xlsx" --proof "/path/bill-xxxx.txt"
```

拿到 `[OK] 已授权` 后，按下方能力路由执行对应脚本。一个 task_token 对应一次批量任务
（单次运行可处理任意多个文件），24 小时内有效。

## 能力路由（授权后执行）

| 用户需求 | 命令 |
|---|---|
| 按列值拆分（每值一个文件） | `python3 scripts/split_workbook.py 输入.xlsx --column 部门 --outdir 拆分/` |
| 按列值拆分（每值一张工作表） | `python3 scripts/split_workbook.py 输入.xlsx --column 业务员 --mode sheet --output 按业务员.xlsx` |
| 两表对账找差异 | `python3 scripts/diff_books.py 系统导出.xlsx 台账.xlsx --key 单号 --output 对账报告.xlsx` |
| 批量数据清洗 | `python3 scripts/clean_data.py "data/*.xlsx" --output 清洗结果.xlsx --dedup --fillna 0` |
| 批量格式转换 | `python3 scripts/convert_batch.py "报表/*.xlsx" --to csv --outdir 导出/` |

---

### 能力一：按列值拆分 split_workbook.py

- 参数：`--column 列名`（必填）、`--mode file|sheet`（默认 file）、`--sheet 表名`、`--header-row N`。
- 自动识别表头行；每个拆分文件带完整专业版式（表头深蓝底白字、隔行浅色、冻结表头、列宽自适应）。
- 值中的非法文件名字符自动替换；空值归入「（空值）」组。

### 能力二：两表对账 diff_books.py

- 参数：`A表 B表 --key 关键列`（必填）、`--compare 列1 列2`（默认自动选两边共有的数值列）、`--header-row`。
- 键值自动标准化（`001` 与 `1` 视为相同）；金额自动剥离千分位/¥ 后比较。
- 输出四张工作表：对账汇总 / 仅A有 / 仅B有 / 数值差异（含 A-B 差额列）。
- 完全一致时也会输出汇总页，明确告知「完全一致」。

### 能力三：批量清洗 clean_data.py

- 默认执行：修剪单元格首尾空格 + 去全空行；`--key 列名` 按关键列去重（保留首次出现）；`--dedup` 整行相同才去重；`--fillna 值` 填充空值。
- 每张源表生成清洗统计（原行数/去空/去重/修剪/填充/清洗后行数），汇总在首张「清洗报告」页。
- 支持通配符批量（`data/*.xlsx`、`名单.csv`），GBK 编码 CSV 自动识别。

### 能力四：批量格式转换 convert_batch.py

- `--to csv|json|xlsx`；多工作表导出时每张表一个文件（文件名 `源文件__表名`）。
- CSV 输出统一 UTF-8 BOM（Excel/WPS 双击打开不乱码）；CSV 转 xlsx 自动套专业版式。
- JSON 输出结构：`{"sheet_rows": N, "headers": [...], "data": [{列:值}]}`，日期自动转文本。

## 推荐工作流程

1. 确认用户需求 → 定位能力路由中的对应脚本与参数。
2. 执行 `call-pro.mjs` 付费门禁（见上），拿到 task_token。
3. 运行对应脚本，核对输出统计（拆分了几个文件/差异几处/清洗掉多少行）。
4. 交付时报告：输出文件路径、每个文件/工作表的行数、发现的关键差异。

## Usage

- 「把这个表按部门拆成多个文件」「这两份流水对一下账」「把文件夹里所有表格清洗去重」「这些 csv 转成 Excel」
- 付费说明：单次 ¥2.0，一次授权可处理任意多个文件；由支付宝 AI 付自动扣费，无需配置任何密钥。
