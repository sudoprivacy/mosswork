/**
 * T+0 ETF 盘前选标分析脚本 (同花顺 iFinD 数据源)
 * 每日 9:25 自动运行，采集集合竞价数据，分析当日 T+0 ETF 机会
 *
 * 用法: node t0-etf-ifind.js
 * 输出: t0-etf-pre-YYYYMMDD.html
 */

const fs = require('fs');
const path = require('path');

// ============================================================
// 配置区
// ============================================================

const IFIND_PATH = 'C:\\Users\\zmszm\\.workbuddy\\skills\\ifind-finance-data\\call-node.js';
const OUTPUT_DIR = 'C:\\Users\\zmszm\\WorkBuddy\\2026-08-03-20-19-00';
const HISTORY_FILE = path.join(OUTPUT_DIR, 't0-etf-history.json');
const DELAY_MS = 2000; // 免费版限频，每次调用间隔2秒

// T+0 ETF 标的池（跨境ETF + 黄金ETF + 部分债券/货币ETF）
// 跨境ETF支持T+0，是T+0交易的主力标的
const T0_ETF_POOL = [
    // === 港股互联网/科技 ===
    { code: '513050', name: '中概互联ETF易方达', sector: '港股互联网' },
    { code: '513330', name: '恒生互联网ETF华夏', sector: '港股互联网' },
    { code: '159792', name: '港股通互联网ETF富国', sector: '港股互联网' },
    { code: '513040', name: '港股通互联网ETF易方达', sector: '港股互联网' },
    { code: '159688', name: '互联网ETF华安', sector: '港股互联网' },
    { code: '159202', name: '互联网ETF万家', sector: '港股互联网' },
    { code: '513770', name: '港股互联网ETF华宝', sector: '港股互联网' },
    { code: '159607', name: '中概互联ETF嘉实', sector: '港股互联网' },
    { code: '513220', name: '港股通科技ETF华泰', sector: '港股科技' },
    { code: '513130', name: '恒生科技ETF华夏', sector: '港股科技' },
    { code: '513180', name: '恒生科技指数ETF', sector: '港股科技' },
    { code: '159740', name: '恒生科技ETF华泰', sector: '港股科技' },
    { code: '159712', name: '恒生科技ETF创金', sector: '港股科技' },
    // === 港股宽基/医疗 ===
    { code: '513100', name: '恒生ETF华夏', sector: '港股宽基' },
    { code: '159920', name: '恒生ETF广发', sector: '港股宽基' },
    { code: '513010', name: '恒生ETF易方达', sector: '港股宽基' },
    { code: '513060', name: '恒生医疗ETF', sector: '港股医疗' },
    { code: '513070', name: '港股通ETF华夏', sector: '港股宽基' },
    // === 日经/亚太 ===
    { code: '513520', name: '日经225ETF', sector: '日本' },
    { code: '513880', name: '日经ETF', sector: '日本' },
    { code: '513980', name: '日经225ETF华夏', sector: '日本' },
    // === 美国/纳斯达克 ===
    { code: '159323', name: '纳斯达克ETF富国', sector: '美股' },
    { code: '159509', name: '纳指ETF', sector: '美股' },
    { code: '513870', name: '纳斯达克ETF华夏', sector: '美股' },
    { code: '513100', name: '纳斯达克100ETF', sector: '美股' },
    // === 欧洲/其他 ===
    { code: '159632', name: '法国CAC40ETF', sector: '欧洲' },
    { code: '513030', name: '德国ETF', sector: '欧洲' },
    { code: '159691', name: '沙特ETF', sector: '中东' },
    // === 黄金 ===
    { code: '518880', name: '黄金ETF华安', sector: '黄金' },
    { code: '159934', name: '黄金ETF易方达', sector: '黄金' },
    { code: '518800', name: '黄金ETF国泰', sector: '黄金' },
    { code: '159561', name: '黄金股ETF', sector: '黄金' },
    // === 商品/原油 ===
    { code: '162411', name: '石油基金LOF', sector: '原油' },
    { code: '501018', name: '南方原油LOF', sector: '原油' },
];

// 去重
const seen = new Set();
const ETF_POOL = T0_ETF_POOL.filter(function(e) {
    if (seen.has(e.code)) return false;
    seen.add(e.code);
    return true;
});

// ============================================================
// 板块代理映射（A股行业板块 → T+0 ETF主题）
// 集合竞价阶段，用A股相关行业板块的开盘涨跌幅作为资金方向信号
// ============================================================

// A股行业板块名称（用于index_data查询）
// 每个T+0 ETF主题对应1-3个A股代理板块
const SECTOR_PROXY = [
    { theme: '港股互联网', proxies: ['互联网媒体', '计算机', '软件开发'] },
    { theme: '港股科技',    proxies: ['半导体', '消费电子', '通信设备'] },
    { theme: '港股医疗',    proxies: ['医疗器械', '生物医药'] },
    { theme: '黄金',        proxies: ['黄金'] },
    { theme: '原油',        proxies: ['石油开采', '油气开采'] },
    { theme: '港股宽基',    proxies: ['证券', '保险', '房地产'] },
    { theme: '美股',        proxies: ['半导体', '消费电子'] }, // 美股科技与A股科技联动
    { theme: '日本',        proxies: ['半导体', '汽车整车'] }, // 日经与半导体/汽车联动
    { theme: '欧洲',        proxies: ['电力设备', '服装家纺'] }, // 欧洲以工业/消费为主
    { theme: '中东',        proxies: ['石油开采'] },
    { theme: '港股科技',    proxies: ['半导体'] },
];

// ============================================================
// 工具函数
// ============================================================

function sleep(ms) { return new Promise(function(r) { setTimeout(r, ms); }); }

function formatDate(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    return y + m + day;
}

function formatDateDisplay(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
}

function fmtPct(v) {
    if (v === null || v === undefined || isNaN(v)) return '--';
    var n = parseFloat(v);
    return (n >= 0 ? '+' : '') + n.toFixed(2) + '%';
}

function fmtAmt(v) {
    if (v === null || v === undefined || isNaN(v)) return '--';
    var n = parseFloat(v);
    if (n >= 100000000) return (n / 100000000).toFixed(2) + '亿';
    if (n >= 10000) return (n / 10000).toFixed(2) + '万';
    return n.toFixed(0);
}

function fmtPrice(v) {
    if (v === null || v === undefined || isNaN(v)) return '--';
    return parseFloat(v).toFixed(3);
}

// 判断是否交易日
function isTradingDay(d) {
    var day = d.getDay();
    return day !== 0 && day !== 6; // 周六周日不交易
}

// ============================================================
// 历史胜率追踪
// ============================================================

function loadHistory() {
    try {
        if (fs.existsSync(HISTORY_FILE)) {
            return JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf-8'));
        }
    } catch (e) { /* ignore */ }
    return { picks: [] };
}

function saveHistory(history) {
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2), 'utf-8');
}

// 回查前日推荐：用当日实时high/low判断是否命中目标或止损
function evaluatePicks(history, currentEtfs, todayStr) {
    var evaluated = 0;
    history.picks.forEach(function(pick) {
        if (pick.status !== 'pending') return;
        if (pick.date === todayStr) return; // 同一天的不能评估

        var etf = currentEtfs.find(function(e) { return e.code === pick.code; });
        if (!etf || !etf.high || etf.high <= 0 || !etf.low || etf.low <= 0) return;

        // 行情日期校验：etf.time 格式如 "2026-08-05 12:02:00"
        // 9:25运行时行情应来自前一交易日（市场未开盘），可用于评估
        // 盘中运行时行情来自今日，不能用于评估前日推荐
        var quoteDate = '';
        if (etf.time && etf.time.length >= 10) {
            quoteDate = etf.time.substring(0, 10).replace(/-/g, '');
        }
        if (quoteDate === todayStr) return; // 行情是今天的，跳过（数据不是前日的）

        // 行情数据来自前一交易日，可以评估
        pick.actualHigh = etf.high;
        pick.actualLow = etf.low;
        pick.actualClose = etf.latest;
        pick.evalDate = todayStr;
        pick.status = 'resolved';

        // 评估逻辑：
        // 1. high >= target1 → win（目标可达）
        // 2. low <= stopLoss 且 high < target1 → loss（止损先触发）
        // 3. low > entryHigh → no_trigger（未进入入场区间）
        // 4. 其他 → no_exit（入场但未到目标也未止损）
        if (etf.high >= pick.target1) {
            pick.result = 'win';
        } else if (etf.low <= pick.stopLoss) {
            pick.result = 'loss';
        } else if (etf.low > pick.entryHigh) {
            pick.result = 'no_trigger';
        } else {
            pick.result = 'no_exit';
        }
        evaluated++;
    });

    if (evaluated > 0) console.log('  -> 回查评估了 ' + evaluated + ' 条历史推荐');
    return history;
}

// 计算胜率统计
function calcWinRate(history) {
    var resolved = history.picks.filter(function(p) { return p.status === 'resolved'; });
    var wins = resolved.filter(function(p) { return p.result === 'win'; });
    var losses = resolved.filter(function(p) { return p.result === 'loss'; });
    var noTrigger = resolved.filter(function(p) { return p.result === 'no_trigger'; });
    var noExit = resolved.filter(function(p) { return p.result === 'no_exit'; });
    var pending = history.picks.filter(function(p) { return p.status === 'pending'; });

    // 胜率 = 命中目标 / (命中目标 + 触发止损)
    var decisive = wins.length + losses.length;
    var winRate = decisive > 0 ? (wins.length / decisive * 100) : 0;

    // 按ETF统计
    var perEtf = {};
    resolved.forEach(function(p) {
        if (!perEtf[p.code]) perEtf[p.code] = { code: p.code, name: p.name, wins: 0, losses: 0, total: 0 };
        perEtf[p.code].total++;
        if (p.result === 'win') perEtf[p.code].wins++;
        else if (p.result === 'loss') perEtf[p.code].losses++;
    });

    return {
        total: resolved.length,
        wins: wins.length,
        losses: losses.length,
        noTrigger: noTrigger.length,
        noExit: noExit.length,
        pending: pending.length,
        winRate: winRate,
        perEtf: Object.keys(perEtf).map(function(k) {
            var e = perEtf[k];
            e.winRate = (e.wins + e.losses) > 0 ? (e.wins / (e.wins + e.losses) * 100) : 0;
            return e;
        }).sort(function(a, b) { return b.winRate - a.winRate; })
    };
}

// 保存当日Top 3推荐到历史
function savePicksToHistory(history, top3, dateStr) {
    top3.forEach(function(e) {
        var levels = calcTradeLevels(e);
        history.picks.push({
            date: dateStr,
            code: e.code,
            name: e.name,
            sector: e.sector,
            score: e.totalScore,
            price: e.latest,
            entryLow: levels.entryLow,
            entryHigh: levels.entryHigh,
            stopLoss: levels.stopLoss,
            target1: levels.target1,
            status: 'pending',
            result: null
        });
    });
    return history;
}

// ============================================================
// 数据采集
// ============================================================

async function collectData() {
    var ifind = require(IFIND_PATH);
    var call = ifind.call;
    var data = {
        indices: [],
        etfs: [],
        perf5d: {},
        perf20d: {},
        sectors: {},      // 板块涨跌幅 { '半导体': {pctChg: 5.6, amount: 3088e8}, ... }
        sectorThemes: {}, // 主题方向评分 { '港股互联网': 85, '黄金': 30, ... }
        errors: []
    };

    // 1. 查询三大指数
    console.log('[1/5] 查询三大指数实时行情...');
    try {
        var idxResult = await call('index', 'index_highfreq_quotes', {
            symbols: '000001.SH,000300.SH,000688.SH',
            indicators: '最新价,开盘价,最高价,最低价,涨跌幅,成交额,成交量',
            data_mode: 'real_time'
        });
        if (idxResult.ok) {
            var raw = JSON.parse(idxResult.data.result.content[0].text);
            if (raw.code === 1 && typeof raw.data === 'string') {
                var parsed = JSON.parse(raw.data);
                for (var i = 1; i < parsed.tables.length; i++) {
                    var row = parsed.tables[i];
                    data.indices.push({
                        code: row[0],
                        name: row[1],
                        time: row[2],
                        latest: parseFloat(row[3]),
                        open: parseFloat(row[4]),
                        high: parseFloat(row[5]),
                        low: parseFloat(row[6]),
                        pctChg: parseFloat(row[7]),
                        amount: parseFloat(row[8]),
                        volume: parseFloat(row[9])
                    });
                }
                console.log('  -> 获取 ' + data.indices.length + ' 个指数');
            }
        }
    } catch (e) {
        data.errors.push('指数查询失败: ' + e.message);
        console.error('  -> 指数查询失败: ' + e.message);
    }

    await sleep(DELAY_MS);

    // 2. 查询关键A股行业板块涨跌幅（集合竞价方向信号）
    console.log('[2/5] 查询A股行业板块涨跌幅（集合竞价方向）...');
    // 收集所有去重的代理板块名称
    var allProxyNames = [];
    var seenProxy = {};
    SECTOR_PROXY.forEach(function(s) {
        s.proxies.forEach(function(p) {
            if (!seenProxy[p]) { seenProxy[p] = true; allProxyNames.push(p); }
        });
    });
    var proxyQueryStr = allProxyNames.join('、') + '今日涨跌幅和成交额';
    try {
        var sectorResult = await call('index', 'index_data', {
            query: proxyQueryStr
        });
        if (sectorResult.ok) {
            var sraw = JSON.parse(sectorResult.data.result.content[0].text);
            if (sraw.code === 1) {
                var sdata = typeof sraw.data === 'string' ? JSON.parse(sraw.data) : sraw.data;
                if (sdata.answer) {
                    // 解析markdown表格，兼容不同列顺序
                    var slines = sdata.answer.split('\n');
                    for (var si = 0; si < slines.length; si++) {
                        var scols = slines[si].split('|');
                        // 过滤空元素
                        var cleanCols = scols.filter(function(c) { return c.trim() !== ''; });
                        // 数据行至少有4列：代码、名称、涨跌幅、成交额
                        if (cleanCols.length >= 3 && !slines[si].includes('---') && !slines[si].includes('证券代码') && !slines[si].includes('证券简称')) {
                            var sname = cleanCols[1].trim();
                            var spct = 0;
                            var samtStr = '';
                            // 从第3列开始，区分涨跌幅(纯数字或含%)和成交额(含亿/万)
                            for (var ci = 2; ci < cleanCols.length; ci++) {
                                var val = cleanCols[ci].trim();
                                if (val.includes('亿') || val.includes('万')) {
                                    samtStr = val;
                                } else if (!isNaN(parseFloat(val))) {
                                    var numVal = parseFloat(val);
                                    // 合理性检查：板块涨跌幅应在 -30% ~ +30% 范围内
                                    // 排除指数点位（如半导体4133.90）被误判为涨跌幅
                                    if (Math.abs(numVal) <= 30) {
                                        spct = numVal;
                                    }
                                }
                            }
                            var samt = 0;
                            if (samtStr.includes('亿')) samt = parseFloat(samtStr) * 1e8;
                            else if (samtStr.includes('万')) samt = parseFloat(samtStr) * 1e4;
                            else samt = parseFloat(samtStr) || 0;
                            if (sname && !isNaN(spct)) {
                                data.sectors[sname] = { pctChg: spct, amount: samt };
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {
        data.errors.push('板块数据查询失败: ' + e.message);
        console.error('  -> 板块数据查询失败: ' + e.message);
    }
    console.log('  -> 获取 ' + Object.keys(data.sectors).length + ' 个板块数据');
    Object.keys(data.sectors).forEach(function(k) {
        var s = data.sectors[k];
        console.log('    ' + k + ': ' + s.pctChg.toFixed(2) + '% 成交额' + (s.amount / 1e8).toFixed(1) + '亿');
    });

    // 计算每个T+0 ETF主题的方向评分
    SECTOR_PROXY.forEach(function(sp) {
        var themePcts = [];
        var themeAmts = [];
        sp.proxies.forEach(function(p) {
            // 模糊匹配板块名
            var matched = null;
            Object.keys(data.sectors).forEach(function(k) {
                if (k.indexOf(p) >= 0 || p.indexOf(k) >= 0) matched = k;
            });
            if (matched) {
                themePcts.push(data.sectors[matched].pctChg);
                themeAmts.push(data.sectors[matched].amount);
            }
        });
        if (themePcts.length > 0) {
            // 加权平均（按成交额加权）
            var totalAmt = themeAmts.reduce(function(a, b) { return a + b; }, 0);
            var weightedPct = 0;
            for (var wi = 0; wi < themePcts.length; wi++) {
                weightedPct += themePcts[wi] * (totalAmt > 0 ? themeAmts[wi] / totalAmt : 1 / themePcts.length);
            }
            data.sectorThemes[sp.theme] = weightedPct;
        }
    });
    console.log('  -> 主题方向评分: ' + JSON.stringify(data.sectorThemes));

    await sleep(DELAY_MS);

    // 2. 批量查询ETF实时行情（每批10个）
    console.log('[3/5] 查询T+0 ETF实时行情 (共' + ETF_POOL.length + '只)...');
    var batchSize = 10;
    for (var b = 0; b < ETF_POOL.length; b += batchSize) {
        var batch = ETF_POOL.slice(b, b + batchSize);
        var codes = batch.map(function(e) { return e.code; }).join(',');
        try {
            var etfResult = await call('fund', 'fund_highfreq_quotes', {
                symbols: codes,
                indicators: '最新价,开盘价,最高价,最低价,涨跌幅,成交额,成交量,振幅',
                data_mode: 'real_time'
            });
            if (etfResult.ok) {
                var eraw = JSON.parse(etfResult.data.result.content[0].text);
                if (eraw.code === 1 && typeof eraw.data === 'string') {
                    var eparsed = JSON.parse(eraw.data);
                    for (var j = 1; j < eparsed.tables.length; j++) {
                        var erow = eparsed.tables[j];
                        var ecode = erow[0].replace('.SH', '').replace('.SZ', '');
                        var poolItem = ETF_POOL.find(function(e) { return e.code === ecode; });
                        // 集合竞价阶段open/high/low/amplitude可能为"null"字符串，需安全解析
                        function safeFloat(v) {
                            var n = parseFloat(v);
                            return isNaN(n) ? 0 : n;
                        }
                        function safeFloatOrNull(v) {
                            var n = parseFloat(v);
                            return isNaN(n) ? null : n;
                        }
                        data.etfs.push({
                            code: ecode,
                            name: poolItem ? poolItem.name : erow[1],
                            sector: poolItem ? poolItem.sector : '其他',
                            time: erow[2],
                            latest: safeFloat(erow[3]),
                            open: safeFloatOrNull(erow[4]),
                            high: safeFloatOrNull(erow[5]),
                            low: safeFloatOrNull(erow[6]),
                            pctChg: safeFloat(erow[7]),
                            amount: safeFloat(erow[8]),
                            volume: safeFloat(erow[9]),
                            amplitude: safeFloatOrNull(erow[10])
                        });
                    }
                }
            }
        } catch (e) {
            data.errors.push('ETF批次查询失败: ' + e.message);
            console.error('  -> 批次' + b + '查询失败: ' + e.message);
        }
        console.log('  -> 已获取 ' + data.etfs.length + '/' + ETF_POOL.length + ' 只ETF');
        await sleep(DELAY_MS);
    }

    // 3. 过滤有效数据（有最新价即可，集合竞价阶段成交额可能为0）
    data.etfs = data.etfs.filter(function(e) {
        return !isNaN(e.latest) && e.latest > 0;
    });

    // 按成交额排序
    data.etfs.sort(function(a, b) { return b.amount - a.amount; });

    // 4. 批量查询Top 10候选的周涨跌幅(5日趋势)和月涨跌幅(20日趋势)
    console.log('[4/5] 批量查询Top 10候选的周/月涨跌幅...');
    var top10 = data.etfs.slice(0, 10);
    var top10Codes = top10.map(function(e) { return e.code; }).join('、');

    // 解析markdown表格，兼容3列(无日期)和4列(有日期)格式
    function parsePerfTable(answer) {
        var result = {};
        var lines = answer.split('\n');
        // 检测列数：看第一个数据行有多少列
        var hasDate = false;
        for (var i = 0; i < lines.length; i++) {
            var cols = lines[i].split('|');
            if (cols.length >= 5 && cols[1].trim() && !lines[i].includes('---') && !lines[i].includes('证券代码')) {
                // 6 elements = 4 data cols (with date), 5 elements = 3 data cols (no date)
                if (cols.length >= 6) hasDate = true;
                break;
            }
        }

        if (hasDate) {
            // 4列格式: |code|name|date|value|
            var latestDate = '';
            for (var i2 = 0; i2 < lines.length; i2++) {
                var c2 = lines[i2].split('|');
                if (c2.length >= 6 && c2[1].trim() && !lines[i2].includes('---') && !lines[i2].includes('证券代码')) {
                    var d = c2[3].trim();
                    if (d > latestDate) latestDate = d;
                }
            }
            for (var j2 = 0; j2 < lines.length; j2++) {
                var cc = lines[j2].split('|');
                if (cc.length >= 6 && cc[3].trim() === latestDate) {
                    var code2 = cc[1].trim().replace('.SH', '').replace('.SZ', '').replace('.OF', '');
                    var val2 = parseFloat(cc[4].trim());
                    if (!isNaN(val2)) result[code2] = val2;
                }
            }
        } else {
            // 3列格式: |code|name|value| → 直接取每个code的第一条
            for (var i3 = 0; i3 < lines.length; i3++) {
                var c3 = lines[i3].split('|');
                if (c3.length >= 5 && c3[1].trim() && !lines[i3].includes('---') && !lines[i3].includes('证券代码')) {
                    var code3 = c3[1].trim().replace('.SH', '').replace('.SZ', '').replace('.OF', '');
                    var val3 = parseFloat(c3[3].trim());
                    if (!isNaN(val3) && result[code3] === undefined) {
                        result[code3] = val3;
                    }
                }
            }
        }
        return result;
    }

    // 批量查询周涨跌幅
    try {
        var weekResult = await call('fund', 'get_fund_market_performance', {
            query: top10Codes + '近1周涨跌幅'
        });
        if (weekResult.ok) {
            var wraw = JSON.parse(weekResult.data.result.content[0].text);
            if (wraw.code === 1) {
                var wdata = typeof wraw.data === 'string' ? JSON.parse(wraw.data) : wraw.data;
                if (wdata.answer) {
                    data.perf5d = parsePerfTable(wdata.answer);
                }
            }
        }
    } catch (e) { data.errors.push('周涨跌幅查询失败: ' + e.message); }
    await sleep(DELAY_MS);

    // 批量查询月涨跌幅
    try {
        var monthResult = await call('fund', 'get_fund_market_performance', {
            query: top10Codes + '近1月涨跌幅'
        });
        if (monthResult.ok) {
            var mraw = JSON.parse(monthResult.data.result.content[0].text);
            if (mraw.code === 1) {
                var mdata = typeof mraw.data === 'string' ? JSON.parse(mraw.data) : mraw.data;
                if (mdata.answer) {
                    // 月涨跌幅也是多日期表，取最新日期
                    data.perf20d = parsePerfTable(mdata.answer);
                }
            }
        }
    } catch (e) { data.errors.push('月涨跌幅查询失败: ' + e.message); }
    await sleep(DELAY_MS);

    console.log('  -> 周涨跌幅(5日趋势): ' + Object.keys(data.perf5d).length + ' 只');
    console.log('  -> 月涨跌幅(20日趋势): ' + Object.keys(data.perf20d).length + ' 只');

    // 5. 查询Top 5的分时数据
    console.log('[5/5] 查询Top 5候选分时数据...');
    var top5 = data.etfs.slice(0, 5);
    data.minuteData = {};
    for (var m = 0; m < top5.length; m++) {
        var etf5 = top5[m];
        try {
            var minResult = await call('fund', 'fund_highfreq_quotes', {
                symbols: etf5.code,
                indicators: '开盘价,最高价,最低价,收盘价,成交量,成交额',
                data_mode: 'highfreq',
                interval: 5
            });
            if (minResult.ok && !minResult.data.result.isError) {
                var mraw = JSON.parse(minResult.data.result.content[0].text);
                if (mraw.code === 1 && typeof mraw.data === 'string') {
                    var mparsed = JSON.parse(mraw.data);
                    if (mparsed.tables && mparsed.tables.length > 1) {
                        data.minuteData[etf5.code] = mparsed.tables.slice(1).map(function(r) {
                            return { time: r[2], price: parseFloat(r[5]) };
                        });
                    }
                }
            }
        } catch (e) { /* ignore */ }
        await sleep(DELAY_MS);
    }

    return data;
}

// ============================================================
// 多因子评分
// ============================================================

function scoreETFs(etfs, perf5d, perf20d, sectorThemes) {
    // 归一化辅助
    function normalize(values, reverse) {
        var min = Math.min.apply(null, values);
        var max = Math.max.apply(null, values);
        var range = max - min;
        if (range === 0) return values.map(function() { return 50; });
        return values.map(function(v) {
            var score = ((v - min) / range) * 100;
            return reverse ? 100 - score : score;
        });
    }

    var amounts = etfs.map(function(e) { return e.amount || 0; });
    var amplitudes = etfs.map(function(e) { return e.amplitude || 0; });
    var pctChgs = etfs.map(function(e) { return e.pctChg || 0; });
    var p5s = etfs.map(function(e) { return perf5d[e.code] || 0; });
    var p20s = etfs.map(function(e) { return perf20d[e.code] || 0; });

    // 板块方向评分：取ETF所属主题的A股代理板块加权涨跌幅
    var sectorPcts = etfs.map(function(e) {
        return sectorThemes[e.sector] !== undefined ? sectorThemes[e.sector] : 0;
    });

    var amtScores = normalize(amounts, false);
    var ampScores = normalize(amplitudes, false);
    var momScores = normalize(pctChgs, false);
    var p5Scores = normalize(p5s, false);
    var p20Scores = normalize(p20s, false);
    var sectorScores = normalize(sectorPcts, false);

    // 综合评分 = 板块方向25% + 动量20% + 流动性20% + 波动性15% + 5日趋势10% + 20日趋势10%
    for (var i = 0; i < etfs.length; i++) {
        etfs[i].scores = {
            sector: Math.round(sectorScores[i] * 0.25),
            momentum: Math.round(momScores[i] * 0.20),
            liquidity: Math.round(amtScores[i] * 0.20),
            volatility: Math.round(ampScores[i] * 0.15),
            trend5d: Math.round(p5Scores[i] * 0.10),
            trend20d: Math.round(p20Scores[i] * 0.10)
        };
        etfs[i].totalScore = etfs[i].scores.sector + etfs[i].scores.momentum +
            etfs[i].scores.liquidity + etfs[i].scores.volatility +
            etfs[i].scores.trend5d + etfs[i].scores.trend20d;
        etfs[i].perf5d = perf5d[etfs[i].code];
        etfs[i].perf20d = perf20d[etfs[i].code];
        etfs[i].sectorPct = sectorThemes[etfs[i].sector];
    }

    etfs.sort(function(a, b) { return b.totalScore - a.totalScore; });
    return etfs;
}

// ============================================================
// 买卖价位计算
// ============================================================

function calcTradeLevels(etf) {
    var price = etf.latest;
    var amp = etf.amplitude || 2.5; // 默认振幅2.5%
    var ampDec = amp / 100;

    // 入场区间：开盘价下方0.3%-0.8%处（回踩买入）
    var entryLow = price * (1 - ampDec * 0.3);
    var entryHigh = price * (1 - ampDec * 0.1);

    // 止损位：入场价下方0.5%-1%
    var stopLoss = entryLow * (1 - 0.008);

    // 目标一：当日振幅的50%上方
    var target1 = price * (1 + ampDec * 0.4);
    // 目标二：当日振幅的80%上方
    var target2 = price * (1 + ampDec * 0.7);

    return {
        entryLow: entryLow,
        entryHigh: entryHigh,
        stopLoss: stopLoss,
        target1: target1,
        target2: target2,
        riskReward: ((target1 - entryHigh) / (entryHigh - stopLoss)).toFixed(2)
    };
}

// ============================================================
// HTML 报告生成
// ============================================================

function generateHTML(data, scored, top8, dateStr, dateDisplay, isTrading, winRate) {
    var indices = data.indices;
    var minuteData = data.minuteData || {};
    var sectors = data.sectors || {};
    var sectorThemes = data.sectorThemes || {};

    // 构建Top 8表格行
    var tableRows = top8.map(function(e, i) {
        var levels = calcTradeLevels(e);
        var pctClass = e.pctChg >= 0 ? 'pct-up' : 'pct-down';
        var perf5Str = e.perf5d !== undefined ? fmtPct(e.perf5d) : '--';
        var perf20Str = e.perf20d !== undefined ? fmtPct(e.perf20d) : '--';
        var sectorStr = e.sectorPct !== undefined ? fmtPct(e.sectorPct) : '--';
        var sectorClass = (e.sectorPct || 0) >= 0 ? 'pct-up' : 'pct-down';
        var rowColor = i < 3 ? '#fff8e1' : (i % 2 === 0 ? '#f8f9fa' : '#ffffff');
        return '<tr style="background:' + rowColor + ';">' +
            '<td style="text-align:center;font-weight:bold;">' + (i + 1) + '</td>' +
            '<td style="font-weight:bold;">' + e.code + '</td>' +
            '<td>' + e.name + '</td>' +
            '<td>' + e.sector + '</td>' +
            '<td class="' + sectorClass + '">' + sectorStr + '</td>' +
            '<td class="' + pctClass + '" style="font-weight:bold;">' + fmtPct(e.pctChg) + '</td>' +
            '<td>' + fmtPrice(e.latest) + '</td>' +
            '<td>' + fmtAmt(e.amount) + '</td>' +
            '<td>' + (e.amplitude ? e.amplitude.toFixed(2) + '%' : '--') + '</td>' +
            '<td>' + perf5Str + '</td>' +
            '<td>' + perf20Str + '</td>' +
            '<td style="text-align:center;font-weight:bold;color:#1565c0;">' + e.totalScore + '</td>' +
            '<td>' + fmtPrice(levels.entryLow) + ' - ' + fmtPrice(levels.entryHigh) + '</td>' +
            '<td class="pct-down">' + fmtPrice(levels.stopLoss) + '</td>' +
            '<td class="pct-up">' + fmtPrice(levels.target1) + '</td>' +
            '</tr>';
    }).join('');

    // 指数卡片
    var indexCards = indices.map(function(idx) {
        var cls = idx.pctChg >= 0 ? 'pct-up' : 'pct-down';
        var arrow = idx.pctChg >= 0 ? '▲' : '▼';
        return '<div class="index-card">' +
            '<div class="index-name">' + idx.name + '</div>' +
            '<div class="index-value">' + idx.latest.toFixed(2) + '</div>' +
            '<div class="' + cls + '" style="font-size:18px;font-weight:bold;">' + arrow + ' ' + fmtPct(idx.pctChg) + '</div>' +
            '<div class="index-detail">成交额 ' + fmtAmt(idx.amount) + '</div>' +
            '</div>';
    }).join('');

    // Top 3 交易计划
    var top3Plans = top8.slice(0, 3).map(function(e, i) {
        var levels = calcTradeLevels(e);
        return '<div class="trade-plan-card">' +
            '<div class="plan-header">TOP ' + (i + 1) + ' | ' + e.code + ' ' + e.name + '</div>' +
            '<div class="plan-grid">' +
            '<div class="plan-item"><span class="plan-label">现价</span><span class="plan-value">' + fmtPrice(e.latest) + '</span></div>' +
            '<div class="plan-item"><span class="plan-label">买入区间</span><span class="plan-value pct-up">' + fmtPrice(levels.entryLow) + ' ~ ' + fmtPrice(levels.entryHigh) + '</span></div>' +
            '<div class="plan-item"><span class="plan-label">止损位</span><span class="plan-value pct-down">' + fmtPrice(levels.stopLoss) + '</span></div>' +
            '<div class="plan-item"><span class="plan-label">目标一</span><span class="plan-value pct-up">' + fmtPrice(levels.target1) + '</span></div>' +
            '<div class="plan-item"><span class="plan-label">目标二</span><span class="plan-value pct-up">' + fmtPrice(levels.target2) + '</span></div>' +
            '<div class="plan-item"><span class="plan-label">盈亏比</span><span class="plan-value">' + levels.riskReward + ':1</span></div>' +
            '</div></div>';
    }).join('');

    // ECharts 数据
    var chartNames = top8.map(function(e) { return e.code + '\\n' + e.name.substring(0, 6); }).map(function(s) { return '"' + s + '"'; }).join(',');
    var chartSec = top8.map(function(e) { return e.scores.sector; }).join(',');
    var chartMom = top8.map(function(e) { return e.scores.momentum; }).join(',');
    var chartLiq = top8.map(function(e) { return e.scores.liquidity; }).join(',');
    var chartVol = top8.map(function(e) { return e.scores.volatility; }).join(',');
    var chartTrend = top8.map(function(e) { return (e.scores.trend5d + e.scores.trend20d); }).join(',');

    // 分时图数据
    var minuteChartJS = '';
    var minuteCodes = Object.keys(minuteData);
    if (minuteCodes.length >= 2) {
        var timeLabels = [];
        var series = [];
        var maxLen = 0;
        minuteCodes.forEach(function(code) {
            var d = minuteData[code];
            if (d.length > maxLen) {
                maxLen = d.length;
                timeLabels = d.map(function(p) { return '"' + p.time.substring(11, 16) + '"'; });
            }
        });
        var colors = ['#e53935', '#1e88e5', '#43a047', '#fb8c00', '#8e24aa'];
        minuteCodes.slice(0, 3).forEach(function(code, idx) {
            var d = minuteData[code];
            var etfInfo = top8.find(function(e) { return e.code === code; });
            var name = etfInfo ? etfInfo.code + ' ' + etfInfo.name.substring(0, 6) : code;
            var prices = d.map(function(p) { return p.price; });
            series.push('{ name:"' + name + '", type:"line", data:[' + prices.join(',') + '], smooth:true, symbol:"circle", symbolSize:3, itemStyle:{color:"' + colors[idx] + '"} }');
        });
        minuteChartJS = 'var mc=echarts.init(document.getElementById("minuteChart"));' +
            'mc.setOption({tooltip:{trigger:"axis"},legend:{data:[' + minuteCodes.slice(0, 3).map(function(code) {
                var etfInfo = top8.find(function(e) { return e.code === code; });
                return '"' + (etfInfo ? etfInfo.code + ' ' + etfInfo.name.substring(0, 6) : code) + '"';
            }).join(',') + '],top:5},' +
            'grid:{left:"3%",right:"4%",bottom:"8%",containLabel:true},' +
            'xAxis:{type:"category",data:[' + timeLabels.join(',') + '],axisLabel:{fontSize:10}},' +
            'yAxis:{type:"value",name:"价格",scale:true},' +
            'series:[' + series.join(',') + ']});';
    }

    // 核心结论
    var top1 = top8[0];
    var top1Levels = calcTradeLevels(top1);
    var marketAssessment = '';
    var shIdx = indices.find(function(i) { return i.name.indexOf('上证') >= 0; });
    var hsIdx = indices.find(function(i) { return i.name.indexOf('沪深') >= 0; });
    var kcIdx = indices.find(function(i) { return i.name.indexOf('科创') >= 0; });

    if (shIdx && kcIdx) {
        if (kcIdx.pctChg > 2 && shIdx.pctChg > 0) {
            marketAssessment = '市场结构性偏多，成长股领涨。科创50 ' + fmtPct(kcIdx.pctChg) + ' 大幅走强，主板温和上行。';
        } else if (shIdx.pctChg > 0.5) {
            marketAssessment = '市场偏多震荡，权重股表现较好。上证 ' + fmtPct(shIdx.pctChg) + '。';
        } else if (shIdx.pctChg < -0.5) {
            marketAssessment = '市场偏弱，注意控制仓位。上证 ' + fmtPct(shIdx.pctChg) + '。T+0以防御为主。';
        } else {
            marketAssessment = '市场窄幅震荡，适合T+0网格操作。上证 ' + fmtPct(shIdx.pctChg) + '。';
        }
    }

    // 加入板块方向判断
    if (sortedThemes && sortedThemes.length > 0) {
        var bestTheme = sortedThemes[0];
        var worstTheme = sortedThemes[sortedThemes.length - 1];
        marketAssessment += ' 集合竞价板块信号：' + bestTheme.name + '方向' + fmtPct(bestTheme.score) + '最强';
        if (worstTheme.score < -1) {
            marketAssessment += '，' + worstTheme.name + '方向' + fmtPct(worstTheme.score) + '偏弱宜回避。';
        } else {
            marketAssessment += '。';
        }
    }

    // 板块统计
    var sectorMap = {};
    top8.forEach(function(e) {
        if (!sectorMap[e.sector]) sectorMap[e.sector] = [];
        sectorMap[e.sector].push(e.code + ' ' + e.name);
    });
    var sectorSummary = Object.keys(sectorMap).map(function(s) {
        return s + ' (' + sectorMap[s].length + '只): ' + sectorMap[s].join(', ');
    }).join('；');

    var html = '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n<meta charset="UTF-8">\n';
    html += '<meta name="viewport" content="width=device-width, initial-scale=1.0">\n';
    html += '<title>T+0 ETF盘前选标分析 ' + dateDisplay + '</title>\n';
    html += '<script src="https://cdn.jsdelivr.net/npm/echarts@5.4.3/dist/echarts.min.js"></script>\n';
    html += '<style>\n';
    html += '* { margin:0; padding:0; box-sizing:border-box; }\n';
    html += 'body { font-family:"Microsoft YaHei","Segoe UI",sans-serif; background:#f0f2f5; color:#333; line-height:1.6; }\n';
    html += '.container { max-width:1200px; margin:0 auto; padding:20px; }\n';
    html += '.header { background:linear-gradient(135deg,#1565c0,#0d47a1); color:#fff; padding:30px; border-radius:12px; margin-bottom:20px; }\n';
    html += '.header h1 { font-size:24px; margin-bottom:5px; }\n';
    html += '.header .subtitle { font-size:14px; opacity:0.85; }\n';
    html += '.header .date { font-size:13px; opacity:0.7; margin-top:5px; }\n';
    html += '.section { background:#fff; border-radius:10px; padding:20px; margin-bottom:20px; box-shadow:0 2px 8px rgba(0,0,0,0.06); }\n';
    html += '.section-title { font-size:18px; font-weight:bold; color:#1565c0; margin-bottom:15px; padding-bottom:8px; border-bottom:2px solid #e3f2fd; }\n';
    html += '.pct-up { color:#e53935; } .pct-down { color:#43a047; }\n';
    html += '.conclusion-box { background:linear-gradient(135deg,#e3f2fd,#f3e5f5); border-radius:10px; padding:20px; margin-bottom:15px; }\n';
    html += '.conclusion-box h3 { color:#1565c0; margin-bottom:10px; }\n';
    html += '.index-cards { display:flex; gap:15px; flex-wrap:wrap; margin-bottom:15px; }\n';
    html += '.index-card { flex:1; min-width:200px; background:#fff; border-radius:8px; padding:15px; text-align:center; border:1px solid #e0e0e0; }\n';
    html += '.index-name { font-size:13px; color:#666; margin-bottom:5px; }\n';
    html += '.index-value { font-size:24px; font-weight:bold; color:#333; }\n';
    html += '.index-detail { font-size:12px; color:#999; margin-top:5px; }\n';
    html += 'table { width:100%; border-collapse:collapse; font-size:13px; }\n';
    html += 'th { background:#1565c0; color:#fff; padding:10px 8px; text-align:center; font-weight:bold; }\n';
    html += 'td { padding:8px; border-bottom:1px solid #eee; text-align:center; }\n';
    html += '.trade-plan-card { background:#f8f9fa; border-radius:8px; padding:15px; margin-bottom:12px; border-left:4px solid #1565c0; }\n';
    html += '.plan-header { font-size:15px; font-weight:bold; color:#333; margin-bottom:10px; }\n';
    html += '.plan-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }\n';
    html += '.plan-item { display:flex; flex-direction:column; }\n';
    html += '.plan-label { font-size:11px; color:#999; }\n';
    html += '.plan-value { font-size:16px; font-weight:bold; }\n';
    html += '.chart-container { width:100%; height:400px; margin:10px 0; }\n';
    html += '.discipline { background:#fff3e0; border-radius:8px; padding:15px; margin-top:10px; }\n';
    html += '.discipline ul { margin-left:20px; }\n';
    html += '.discipline li { margin-bottom:6px; }\n';
    html += '.disclaimer { background:#fafafa; border-radius:8px; padding:15px; font-size:12px; color:#999; text-align:center; margin-top:15px; }\n';
    html += '.data-source { font-size:12px; color:#999; text-align:right; margin-top:5px; }\n';
    html += '</style>\n</head>\n<body>\n<div class="container">\n';

    // Header
    html += '<div class="header">\n';
    html += '<h1>T+0 ETF 盘前选标分析报告</h1>\n';
    html += '<div class="subtitle">基于同花顺 iFinD 实时数据 | 多因子量化评分模型</div>\n';
    html += '<div class="date">报告日期：' + dateDisplay + ' | 数据时间：' + (indices[0] ? indices[0].time : '盘前') + (isTrading ? '' : ' (非交易日，使用最近交易日数据)') + '</div>\n';
    html += '</div>\n';

    // 核心结论
    html += '<div class="section">\n';
    html += '<div class="section-title">核心结论</div>\n';
    html += '<div class="conclusion-box">\n';
    html += '<h3>市场环境判断</h3>\n';
    html += '<p>' + marketAssessment + '</p>\n';
    html += '<p style="margin-top:8px;"><strong>板块轮动：</strong>' + sectorSummary + '</p>\n';
    html += '</div>\n';
    html += '<div class="conclusion-box" style="background:linear-gradient(135deg,#e8f5e9,#fff3e0);">\n';
    html += '<h3>首选标的</h3>\n';
    html += '<p style="font-size:16px;"><strong style="color:#e53935;font-size:20px;">' + top1.code + ' ' + top1.name + '</strong></p>\n';
    html += '<p>综合评分 <strong style="color:#1565c0;font-size:18px;">' + top1.totalScore + '</strong>/100 | 当日涨幅 ' + fmtPct(top1.pctChg) + ' | 成交额 ' + fmtAmt(top1.amount) + '</p>\n';
    html += '<p style="margin-top:8px;">买入区间：<strong style="color:#e53935;">' + fmtPrice(top1Levels.entryLow) + ' ~ ' + fmtPrice(top1Levels.entryHigh) + '</strong> | 止损：<strong style="color:#43a047;">' + fmtPrice(top1Levels.stopLoss) + '</strong> | 目标：<strong style="color:#e53935;">' + fmtPrice(top1Levels.target1) + '</strong></p>\n';
    html += '</div>\n';
    html += '</div>\n';

    // 市场环境
    html += '<div class="section">\n';
    html += '<div class="section-title">市场环境评估</div>\n';
    html += '<div class="index-cards">' + indexCards + '</div>\n';
    html += '</div>\n';

    // 集合竞价板块资金流向
    var sectorKeys = Object.keys(sectors);
    var themeKeys = Object.keys(sectorThemes);
    // 按涨跌幅排序板块
    var sortedSectors = sectorKeys.map(function(k) {
        return { name: k, pctChg: sectors[k].pctChg, amount: sectors[k].amount };
    }).sort(function(a, b) { return b.pctChg - a.pctChg; });
    // 按方向评分排序主题
    var sortedThemes = themeKeys.map(function(k) {
        return { name: k, score: sectorThemes[k] };
    }).sort(function(a, b) { return b.score - a.score; });

    // 确定当日主流方向（排名前3的主题）
    var top3Themes = sortedThemes.slice(0, 3);
    var mainDirection = top3Themes.map(function(t) {
        var arrow = t.score >= 0 ? '▲' : '▼';
        return arrow + t.name + '(' + fmtPct(t.score) + ')';
    }).join('、');

    // 板块表格行
    var sectorTableRows = sortedSectors.map(function(s) {
        var cls = s.pctChg >= 0 ? 'pct-up' : 'pct-down';
        return '<tr>' +
            '<td>' + s.name + '</td>' +
            '<td class="' + cls + '" style="font-weight:bold;">' + fmtPct(s.pctChg) + '</td>' +
            '<td>' + fmtAmt(s.amount) + '</td>' +
            '</tr>';
    }).join('');

    // 主题方向行
    var themeRows = sortedThemes.map(function(t) {
        var cls = t.score >= 0 ? 'pct-up' : 'pct-down';
        var tag = t.score >= 2 ? '<span style="color:#e53935;font-weight:bold;">★强</span>' :
                  (t.score >= 0 ? '<span style="color:#fb8c00;">中性</span>' : '<span style="color:#43a047;">回避</span>');
        return '<tr>' +
            '<td>' + t.name + '</td>' +
            '<td class="' + cls + '" style="font-weight:bold;">' + fmtPct(t.score) + '</td>' +
            '<td style="text-align:center;">' + tag + '</td>' +
            '</tr>';
    }).join('');

    // ECharts 板块方向柱状图数据
    var sectorChartNames = sortedSectors.map(function(s) { return '"' + s.name + '"'; }).join(',');
    var sectorChartPcts = sortedSectors.map(function(s) { return s.pctChg.toFixed(2); }).join(',');
    var sectorChartColors = sortedSectors.map(function(s) {
        return s.pctChg >= 0 ? '"#e53935"' : '"#43a047"';
    }).join(',');

    html += '<div class="section">\n';
    html += '<div class="section-title">集合竞价板块资金流向</div>\n';
    html += '<div class="conclusion-box" style="background:linear-gradient(135deg,#e3f2fd,#fff3e0);margin-bottom:15px;">\n';
    html += '<h3>当日主流方向判断</h3>\n';
    html += '<p style="font-size:16px;">基于集合竞价阶段A股行业板块开盘涨跌幅（成交额加权），当日主流资金方向为：</p>\n';
    html += '<p style="font-size:18px;font-weight:bold;margin-top:8px;">' + mainDirection + '</p>\n';
    html += '<p style="font-size:12px;color:#999;margin-top:5px;">注：板块方向评分为对应A股代理板块的加权涨跌幅，正值代表资金流入，负值代表资金流出。</p>\n';
    html += '</div>\n';

    html += '<div style="display:flex;gap:20px;flex-wrap:wrap;">\n';
    // 左侧：A股板块涨跌幅表
    html += '<div style="flex:1;min-width:300px;">\n';
    html += '<h4 style="margin-bottom:8px;color:#333;">A股行业板块涨跌幅</h4>\n';
    html += '<table>\n<thead>\n<tr><th>板块</th><th>涨跌幅</th><th>成交额</th></tr>\n</thead>\n<tbody>\n' + sectorTableRows + '\n</tbody>\n</table>\n';
    html += '</div>\n';
    // 右侧：T+0 ETF主题方向
    html += '<div style="flex:1;min-width:300px;">\n';
    html += '<h4 style="margin-bottom:8px;color:#333;">T+0 ETF主题方向评分</h4>\n';
    html += '<table>\n<thead>\n<tr><th>ETF主题</th><th>方向评分</th><th>信号</th></tr>\n</thead>\n<tbody>\n' + themeRows + '\n</tbody>\n</table>\n';
    html += '</div>\n';
    html += '</div>\n';

    // 板块方向柱状图
    html += '<div id="sectorChart" class="chart-container" style="height:350px;margin-top:15px;"></div>\n';
    html += '</div>\n';

    // T+0候选排名表
    html += '<div class="section">\n';
    html += '<div class="section-title">T+0 候选标的排名（Top 8）</div>\n';
    html += '<table>\n<thead>\n<tr>\n';
    html += '<th>排名</th><th>代码</th><th>名称</th><th>板块</th><th>板块方向</th><th>当日涨幅</th><th>最新价</th><th>成交额</th><th>振幅</th><th>5日涨跌</th><th>20日涨跌</th><th>综合评分</th><th>买入区间</th><th>止损位</th><th>目标一</th>\n';
    html += '</tr>\n</thead>\n<tbody>\n' + tableRows + '\n</tbody>\n</table>\n';
    html += '</div>\n';

    // 多因子评分堆叠柱状图
    html += '<div class="section">\n';
    html += '<div class="section-title">多因子评分堆叠柱状图</div>\n';
    html += '<div id="factorChart" class="chart-container"></div>\n';
    html += '</div>\n';

    // 分时走势图
    if (minuteChartJS) {
        html += '<div class="section">\n';
        html += '<div class="section-title">Top 3 标的分时走势对比</div>\n';
        html += '<div id="minuteChart" class="chart-container"></div>\n';
        html += '</div>\n';
    }

    // Top 3 交易计划
    html += '<div class="section">\n';
    html += '<div class="section-title">Top 3 交易计划</div>\n';
    html += top3Plans;
    html += '</div>\n';

    // 历史胜率追踪
    if (winRate && winRate.total >= 0) {
        var wrColor = winRate.winRate >= 60 ? '#e53935' : (winRate.winRate >= 40 ? '#fb8c00' : '#43a047');
        html += '<div class="section">\n';
        html += '<div class="section-title">历史胜率追踪</div>\n';

        // 胜率概览卡片
        html += '<div style="display:flex;gap:15px;flex-wrap:wrap;margin-bottom:20px;">\n';
        html += '<div style="flex:1;min-width:120px;background:linear-gradient(135deg,#e3f2fd,#f3e5f5);border-radius:12px;padding:20px;text-align:center;">\n';
        html += '<div style="font-size:36px;font-weight:bold;color:' + wrColor + ';">' + winRate.winRate.toFixed(1) + '%</div>\n';
        html += '<div style="font-size:13px;color:#666;margin-top:5px;">综合胜率</div>\n';
        html += '</div>\n';
        html += '<div style="flex:1;min-width:80px;background:#fafafa;border-radius:12px;padding:20px;text-align:center;">\n';
        html += '<div style="font-size:28px;font-weight:bold;color:#1565c0;">' + winRate.total + '</div>\n';
        html += '<div style="font-size:13px;color:#666;margin-top:5px;">已评估</div>\n';
        html += '</div>\n';
        html += '<div style="flex:1;min-width:80px;background:#fff8e1;border-radius:12px;padding:20px;text-align:center;">\n';
        html += '<div style="font-size:28px;font-weight:bold;color:#e53935;">' + winRate.wins + '</div>\n';
        html += '<div style="font-size:13px;color:#666;margin-top:5px;">命中目标</div>\n';
        html += '</div>\n';
        html += '<div style="flex:1;min-width:80px;background:#e8f5e9;border-radius:12px;padding:20px;text-align:center;">\n';
        html += '<div style="font-size:28px;font-weight:bold;color:#43a047;">' + winRate.losses + '</div>\n';
        html += '<div style="font-size:13px;color:#666;margin-top:5px;">触发止损</div>\n';
        html += '</div>\n';
        html += '<div style="flex:1;min-width:80px;background:#f5f5f5;border-radius:12px;padding:20px;text-align:center;">\n';
        html += '<div style="font-size:28px;font-weight:bold;color:#999;">' + winRate.pending + '</div>\n';
        html += '<div style="font-size:13px;color:#666;margin-top:5px;">待评估</div>\n';
        html += '</div>\n';
        html += '</div>\n';

        // 历史推荐记录表
        if (winRate.recentPicks && winRate.recentPicks.length > 0) {
            html += '<table style="width:100%;border-collapse:collapse;font-size:13px;">\n';
            html += '<thead><tr style="background:#f5f5f5;">\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">日期</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">代码</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">名称</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">评分</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">买入价</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">目标</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">止损</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">当日最高</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">当日最低</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">结果</th>\n';
            html += '</tr></thead><tbody>\n';
            winRate.recentPicks.forEach(function(p) {
                var resultBadge = '';
                var rowBg = '#ffffff';
                if (p.status === 'pending') {
                    resultBadge = '<span style="color:#999;">待评估</span>';
                    rowBg = '#fafafa';
                } else if (p.result === 'win') {
                    resultBadge = '<span style="color:#e53935;font-weight:bold;">✓ 命中</span>';
                    rowBg = '#fff8e1';
                } else if (p.result === 'loss') {
                    resultBadge = '<span style="color:#43a047;font-weight:bold;">✗ 止损</span>';
                    rowBg = '#e8f5e9';
                } else if (p.result === 'no_trigger') {
                    resultBadge = '<span style="color:#999;">未触发</span>';
                } else if (p.result === 'no_exit') {
                    resultBadge = '<span style="color:#fb8c00;">未到目标</span>';
                }
                html += '<tr style="background:' + rowBg + ';">\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;">' + p.date + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;font-weight:bold;">' + p.code + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;">' + p.name + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;text-align:center;">' + (p.score || '--') + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;">' + fmtPrice(p.price) + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;color:#e53935;">' + fmtPrice(p.target1) + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;color:#43a047;">' + fmtPrice(p.stopLoss) + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;">' + (p.actualHigh ? fmtPrice(p.actualHigh) : '--') + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;">' + (p.actualLow ? fmtPrice(p.actualLow) : '--') + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;text-align:center;">' + resultBadge + '</td>\n';
                html += '</tr>\n';
            });
            html += '</tbody></table>\n';
        } else {
            html += '<p style="color:#999;text-align:center;padding:20px;">暂无历史推荐记录，从今日开始积累。</p>\n';
        }

        // 按ETF统计胜率
        if (winRate.perEtf && winRate.perEtf.length > 0) {
            html += '<h3 style="margin-top:20px;">单标的胜率统计</h3>\n';
            html += '<table style="width:100%;border-collapse:collapse;font-size:13px;">\n';
            html += '<thead><tr style="background:#f5f5f5;">\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">代码</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">名称</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">推荐次数</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">命中</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">止损</th>\n';
            html += '<th style="padding:8px;border:1px solid #ddd;">胜率</th>\n';
            html += '</tr></thead><tbody>\n';
            winRate.perEtf.forEach(function(e) {
                var eWrColor = e.winRate >= 60 ? '#e53935' : (e.winRate >= 40 ? '#fb8c00' : '#43a047');
                html += '<tr>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;font-weight:bold;">' + e.code + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;">' + e.name + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;text-align:center;">' + e.total + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;text-align:center;color:#e53935;">' + e.wins + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;text-align:center;color:#43a047;">' + e.losses + '</td>\n';
                html += '<td style="padding:6px 8px;border:1px solid #ddd;text-align:center;font-weight:bold;color:' + eWrColor + ';">' + (e.wins + e.losses > 0 ? e.winRate.toFixed(1) + '%' : '--') + '</td>\n';
                html += '</tr>\n';
            });
            html += '</tbody></table>\n';
        }

        html += '<p style="font-size:12px;color:#999;margin-top:10px;">注：胜率 = 命中目标次数 / (命中目标 + 触发止损)。"未触发"表示当日未进入买入区间，不计入胜率。"待评估"表示推荐次日数据尚未获取。</p>\n';
        html += '</div>\n';
    }

    // T+0操作纪律
    html += '<div class="section">\n';
    html += '<div class="section-title">T+0 操作纪律</div>\n';
    html += '<div class="discipline">\n<ul>\n';
    html += '<li><strong>仓位管理：</strong>单只标的仓位不超过总资金20%，同时持仓不超过3只</li>\n';
    html += '<li><strong>入场时机：</strong>9:30-10:00观察开盘走势，10:00-10:30回踩入场为佳，避免开盘追高</li>\n';
    html += '<li><strong>止损纪律：</strong>触及止损位立即卖出，不犹豫、不补仓、不扛单</li>\n';
    html += '<li><strong>止盈纪律：</strong>达到目标一先卖半仓，剩余仓位上移止损到成本价</li>\n';
    html += '<li><strong>环境过滤：</strong>上证跌幅>1%时暂停T+0操作；成交额<5000万的标的不参与</li>\n';
    html += '<li><strong>时间窗口：</strong>T+0最佳窗口为9:30-11:00和13:00-14:00，14:30后不开新仓</li>\n';
    html += '<li><strong>量能确认：</strong>买入时需确认分时量能放大，缩量下跌不追、放量上涨可跟</li>\n';
    html += '</ul>\n</div>\n';
    html += '</div>\n';

    // 风险免责
    html += '<div class="disclaimer">\n';
    html += '<p><strong>风险提示与免责声明</strong></p>\n';
    html += '<p>本报告由自动化系统基于同花顺 iFinD 数据生成，仅供学习研究参考，不构成任何投资建议。</p>\n';
    html += '<p>T+0 ETF交易风险较高，无法保证胜率，历史表现不代表未来收益。投资者应自行判断并承担交易风险。</p>\n';
    html += '<p>数据来源：同花顺 iFinD (ifind-finance-data) | 报告生成时间：' + new Date().toLocaleString('zh-CN') + '</p>\n';
    html += '</div>\n';

    html += '</div>\n';

    // ECharts JS
    html += '<script>\n';
    html += 'var fc=echarts.init(document.getElementById("factorChart"));\n';
    html += 'fc.setOption({tooltip:{trigger:"axis",axisPointer:{type:"shadow"}},';
    html += 'legend:{data:["板块方向","动量","流动性","波动性","趋势"],top:5},';
    html += 'grid:{left:"3%",right:"4%",bottom:"12%",containLabel:true},';
    html += 'xAxis:{type:"category",data:[' + chartNames + '],axisLabel:{fontSize:10,interval:0}},';
    html += 'yAxis:{type:"value",name:"评分",max:100},';
    html += 'series:[';
    html += '{name:"板块方向",type:"bar",stack:"total",data:[' + chartSec + '],itemStyle:{color:"#00897b"}},';
    html += '{name:"动量",type:"bar",stack:"total",data:[' + chartMom + '],itemStyle:{color:"#e53935"}},';
    html += '{name:"流动性",type:"bar",stack:"total",data:[' + chartLiq + '],itemStyle:{color:"#1e88e5"}},';
    html += '{name:"波动性",type:"bar",stack:"total",data:[' + chartVol + '],itemStyle:{color:"#8e24aa"}},';
    html += '{name:"趋势",type:"bar",stack:"total",data:[' + chartTrend + '],itemStyle:{color:"#fb8c00"}}';
    html += ']});\n';

    // 板块方向柱状图
    html += 'var sc=echarts.init(document.getElementById("sectorChart"));\n';
    html += 'sc.setOption({tooltip:{trigger:"axis",axisPointer:{type:"shadow"},formatter:function(params){var p=params[0];return p.name+": "+p.value+"%";}},';
    html += 'grid:{left:"3%",right:"4%",bottom:"15%",containLabel:true},';
    html += 'xAxis:{type:"category",data:[' + sectorChartNames + '],axisLabel:{fontSize:11,interval:0,rotate:30}},';
    html += 'yAxis:{type:"value",name:"涨跌幅(%)"},';
    html += 'series:[{type:"bar",data:[';
    // 带颜色的柱子
    var sectorBarData = sortedSectors.map(function(s) {
        return '{value:' + s.pctChg.toFixed(2) + ',itemStyle:{color:' + (s.pctChg >= 0 ? '"#e53935"' : '"#43a047"') + '}}';
    }).join(',');
    html += sectorBarData;
    html += '],barWidth:"60%"}]';
    html += '});\n';

    if (minuteChartJS) {
        html += minuteChartJS + '\n';
    }
    html += 'window.addEventListener("resize",function(){fc.resize();sc.resize();';
    if (minuteChartJS) html += 'mc.resize();';
    html += '});\n';
    html += '</script>\n';

    html += '</body>\n</html>\n';
    return html;
}

// ============================================================
// 主流程
// ============================================================

async function main() {
    var now = new Date();
    var dateStr = formatDate(now);
    var dateDisplay = formatDateDisplay(now);
    var trading = isTradingDay(now);

    console.log('=====================================');
    console.log('T+0 ETF 盘前选标分析');
    console.log('日期: ' + dateDisplay + (trading ? ' (交易日)' : ' (非交易日)'));
    console.log('数据源: 同花顺 iFinD');
    console.log('=====================================\n');

    // 1. 采集数据
    var data = await collectData();
    console.log('\n数据采集完成:');
    console.log('  指数: ' + data.indices.length);
    console.log('  A股板块: ' + Object.keys(data.sectors).length);
    console.log('  ETF主题方向: ' + Object.keys(data.sectorThemes).length);
    console.log('  ETF: ' + data.etfs.length);
    console.log('  5日涨跌幅: ' + Object.keys(data.perf5d).length);
    console.log('  20日涨跌幅: ' + Object.keys(data.perf20d).length);
    console.log('  分时数据: ' + Object.keys(data.minuteData || {}).length);
    if (data.errors.length > 0) {
        console.log('  错误: ' + data.errors.length + '条');
        data.errors.forEach(function(e) { console.log('    - ' + e); });
    }

    // 2. 多因子评分
    console.log('\n计算多因子评分...');
    var scored = scoreETFs(data.etfs, data.perf5d, data.perf20d, data.sectorThemes);
    var top8 = scored.slice(0, 8);

    console.log('\nTop 8 候选:');
    top8.forEach(function(e, i) {
        console.log('  ' + (i + 1) + '. ' + e.code + ' ' + e.name + ' | 评分' + e.totalScore + ' | 板块' + (e.sectorPct !== undefined ? fmtPct(e.sectorPct) : '--') + ' | ' + fmtPct(e.pctChg) + ' | ' + fmtAmt(e.amount));
    });

    // 3. 历史胜率追踪：加载历史 → 回查评估 → 保存今日推荐 → 计算胜率
    console.log('\n历史胜率追踪...');
    var history = loadHistory();
    history = evaluatePicks(history, data.etfs, dateStr);
    // 保存今日Top 3到历史（先保存，这样胜率统计包含今日pending推荐）
    var top3 = top8.slice(0, 3);
    history = savePicksToHistory(history, top3, dateStr);
    saveHistory(history);
    var winRate = calcWinRate(history);
    winRate.recentPicks = history.picks.slice(-10).reverse();
    if (winRate.total > 0 || winRate.pending > 0) {
        console.log('  总推荐: ' + (winRate.total + winRate.pending) + ' | 胜: ' + winRate.wins + ' | 负: ' + winRate.losses + ' | 胜率: ' + winRate.winRate.toFixed(1) + '% | 待评估: ' + winRate.pending);
    } else {
        console.log('  暂无历史记录，从今日开始积累');
    }

    // 4. 生成HTML
    console.log('\n生成HTML报告...');
    var html = generateHTML(data, scored, top8, dateStr, dateDisplay, trading, winRate);
    var outPath = path.join(OUTPUT_DIR, 't0-etf-pre-' + dateStr + '.html');
    fs.writeFileSync(outPath, html, 'utf-8');
    console.log('报告已保存: ' + outPath);

    // 5. 输出JSON摘要（供自动化记忆使用）
    var summary = {
        date: dateDisplay,
        trading: trading,
        indices: data.indices.map(function(i) { return { name: i.name, pct: i.pctChg }; }),
        sectorThemes: data.sectorThemes,
        mainDirection: Object.keys(data.sectorThemes || {}).map(function(k) {
            return { theme: k, score: data.sectorThemes[k] };
        }).sort(function(a, b) { return b.score - a.score; }).slice(0, 3),
        top8: top8.map(function(e, i) {
            var levels = calcTradeLevels(e);
            return {
                rank: i + 1,
                code: e.code,
                name: e.name,
                score: e.totalScore,
                pctChg: e.pctChg,
                amount: e.amount,
                entryLow: levels.entryLow,
                entryHigh: levels.entryHigh,
                stopLoss: levels.stopLoss,
                target1: levels.target1
            };
        }),
        winRate: {
            total: winRate.total,
            wins: winRate.wins,
            losses: winRate.losses,
            noTrigger: winRate.noTrigger,
            pending: winRate.pending,
            winRate: parseFloat(winRate.winRate.toFixed(1))
        }
    };
    var jsonPath = path.join(OUTPUT_DIR, 't0-etf-pre-' + dateStr + '.json');
    fs.writeFileSync(jsonPath, JSON.stringify(summary, null, 2), 'utf-8');
    console.log('摘要已保存: ' + jsonPath);

    // 清理临时文件
    var testFile = path.join(OUTPUT_DIR, '_test_ifind.js');
    if (fs.existsSync(testFile)) fs.unlinkSync(testFile);

    return { htmlPath: outPath, jsonPath: jsonPath, summary: summary };
}

main().then(function(r) {
    console.log('\n=====================================');
    console.log('完成!');
    console.log('HTML: ' + r.htmlPath);
    console.log('JSON: ' + r.jsonPath);
    process.exit(0);
}).catch(function(e) {
    console.error('执行失败:', e.message);
    console.error(e.stack);
    process.exit(1);
});
