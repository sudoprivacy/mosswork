---
name: skillhub-skill-t0etf
description: "T+0 ETF盘前选标分析。输入交易日，输出适合当天做T+0交易的ETF标的列表、多因子综合评分、买入区间、止损位、目标价和潜在盈亏比。使用场景：用户询问\"今天适合做T+0的ETF\"、\"T+0选基\"、\"跨境ETF盘前分析\"、\"哪些ETF适合当天做网格交易\"等。数据源为同花顺iFinD（需密钥）或东方财富公开行情API（浏览器直连，无需密钥）。Also used when user wants to deploy the web version of T+0 ETF selector or generate the daily pre-market report."
---

# T0 ETF 选标分析 (t0-etf-select)

## Overview

多因子量化评分选股系统，用于每个交易日盘前筛选适合 T+0 交易的 ETF 标的。核心输出：Top 8 候选标的名次、综合评分（0-100）、买入区间、止损位、两个目标价、潜在收益率、盈亏比。红涨绿跌（中国市场惯例）。

## 触发场景

- 用户问"今天适合 T+0 的 ETF 有哪些"、"T+0 选基"、"盘前选标"、"跨境 ETF 分析"
- 用户要求生成每日盘前 T+0 ETF 分析报告（HTML 或 Web 页面）
- 用户要求部署/更新 T+0 ETF 云端实时分析链接
- 自动化定时任务（工作日 09:25 盘前执行）

## 评分公式

综合评分 = 板块方向 25% + 动量 20% + 流动性 20% + 波动性 15% + 5日趋势 10% + 20日趋势 10%

各因子在候选池内做 min-max 归一化（0-100）后加权求和。

## 买卖点位计算

基于最新价 price 和当日振幅 amp（默认 2.5%）：

- 买入区间：`[price × (1 - amp×0.3%), price × (1 - amp×0.1%)]`
- 止损位：`entryLow × (1 - 0.8%)`
- 目标一：`price × (1 + amp×0.4%)`
- 目标二：`price × (1 + amp×0.7%)`
- 盈亏比：`(target1 - entryHigh) / (entryHigh - stopLoss)`

## 执行方式（二选一）

### 方式 A：iFinD 主脚本（完整版，推荐每日自动化）

运行 `scripts/analyze.js`（Node.js，无外部依赖）：

```bash
node "C:/Users/zmszm/.workbuddy/skills/t0-etf-select/scripts/analyze.js"
```

前置条件：
- Node.js 运行时（项目常用 `C:\Users\zmszm\.workbuddy\binaries\node\versions\22.22.2\node.exe`）
- iFinD MCP 密钥已配置于 `C:\Users\zmszm\.workbuddy\skills\ifind-finance-data\mcp_config.json`
- 脚本内 `CALL_NODE_PATH` 常量需指向 `ifind-finance-data/call-node.js`

脚本自动完成：
1. 判断交易日（非交易日自动用最近交易日）
2. 采集三大指数实时行情
3. 查询 17 个 A股代理板块涨跌幅（集合竞价方向信号）
4. 批量查询 33 只 T+0 ETF 实时行情
5. 查询 Top 10 候选的 5日/20日涨跌幅趋势
6. 多因子评分 → Top 8 排名
7. 生成 HTML 报告 `t0-etf-pre-YYYYMMDD.html` + JSON 摘要 + 更新历史追踪

输出文件（在工作目录）：
- `t0-etf-pre-YYYYMMDD.html` — 完整报告
- `t0-etf-pre-YYYYMMDD.json` — JSON 摘要
- `t0-etf-history.json` — 历史胜率追踪

### 方式 B：纯前端实时分析（任意人可用，无需密钥）

使用 `assets/live-view.html`（东方财富公开 API，浏览器直连，CORS 已支持）。

部署方式：将 HTML 文件（连同同目录 `style.css`、`data.js`）部署到任意静态托管（如 CloudStudio），任何人打开链接即可点击「T+0选基」实时分析。

技术要点（重要）：
- **数据源全部用 `push2delay.eastmoney.com`**：`push2.eastmoney.com` 在浏览器中 Failed to fetch（需要特定 UA，浏览器无法设置），但 `push2delay` 域名直接支持 CORS 且无需 UA
- 指数/ETF/板块统一走 `https://push2delay.eastmoney.com/api/qt/ulist.np/get`，板块代码用 `90.BKxxxx` 前缀
- K线（5日/20日趋势）：主源东财 `push2his`（不稳定），**备用腾讯** `https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=sh513050,day,,,25,qfq`（ACAO:* 稳定）
- 腾讯实时行情备用：`https://qt.gtimg.cn/q=sh513050,...`（ACAO:*；**成交额字段是手数需×100**）
- fetchJSON 校验必须放宽：腾讯K线返回 `data.secid.day`（无 klines 字段），只校验 `data !== undefined`
- 板块代码映射：半导体=BK1036、黄金=BK1617、油气开采=BK1574、证券=BK1366、保险=BK1358、乘用车=BK1262、电力设备=BK1200、传媒=BK0486、软件开发=BK0737、消费电子=BK1037、通信设备=BK0448、医疗器械=BK1041、生物制品=BK1044、计算机=BK1207、房地产开发=BK0451、服装家纺=BK1225

## ETF 池（33 只）

10 个主题：港股互联网（8只）、港股科技（5只）、港股宽基（4只）、港股医疗（1只）、日本（3只）、美股（3只）、欧洲（2只）、中东（1只）、黄金（4只）、原油（2只）

完整代码清单见 `scripts/analyze.js` 中的 `T0_ETF_POOL` 常量。

## A股代理板块映射（主题 → 代理板块）

- 港股互联网 → 传媒(BK0486)、计算机(BK1207)、软件开发(BK0737)
- 港股科技 → 半导体(BK1036)、消费电子(BK1037)、通信设备(BK0448)
- 港股医疗 → 医疗器械(BK1041)、生物制品(BK1044)
- 黄金 → 黄金(BK1617)
- 原油 → 油气开采(BK1574)
- 港股宽基 → 证券(BK1366)、保险(BK1358)、房地产开发(BK0451)
- 美股 → 半导体(BK1036)、消费电子(BK1037)
- 日本 → 半导体(BK1036)、乘用车(BK1262)
- 欧洲 → 电力设备(BK1200)、服装家纺(BK1225)
- 中东 → 油气开采(BK1574)

主题方向评分 = 代理板块涨跌幅的成交额加权平均。

## 报告内容结构

1. 核心结论（市场环境判断 + 首选标的卡片）
2. 市场环境评估（三大指数卡片）
3. 板块资金方向（主题方向评分表 + 候选标的归属表）
4. T+0 候选标的排名（Top 8 表格：排名/代码/名称/涨幅/成交额/评分/买入区间/止损/目标一/潜在收益/盈亏比）
5. Top 3 交易计划（卡片式，含现价/买入区间/止损/目标一二/盈亏比）
6. T+0 操作纪律（7条规则）
7. 免责声明（仅供参考，不构成投资建议）

## 已知坑与经验

- **集合竞价阶段（09:15-09:25）**：iFinD 返回 ETF 成交额=0、open/high/low/amplitude 为 `"null"` 字符串。过滤条件必须只用 `latest > 0`，不能要求 `amount > 0`；解析需 safeFloat 处理 null
- **iFinD 表格列顺序不固定**：板块涨跌幅/最新价位置会变，解析需按内容区分（涨跌幅绝对值 ≤30 为合理性检查），不能按列位置取
- **板块成交额可能为 0**（如黄金、保险），加权平均时需兼容
- **腾讯行情成交额是手数**（约 1/100 于元），换算需 ×100
- **浏览器 CORS**：iFinD API 无 CORS 头，浏览器不能直连，必须用东财 push2delay

## Resources

### scripts/analyze.js
Node.js 主分析脚本（iFinD 数据源，自包含）。复制到任意工作目录即可运行，运行时依赖 iFinD 密钥配置。

### assets/live-view.html
纯前端实时分析页面模板（东方财富数据源）。部署时需配套 `style.css` 和 `data.js`（历史报告数组 `window.REPORTS`），三者同目录。
