# 世舶招投标数据接口摘要（技术标编制用）

- 依据：`D:/信息/接口文档/接口文档_2026-11-03.md`，文档标注 v1.0、生成时间 2026/11/03 15:47:36。
- 用途：本文件只整理本 Skill 实际用到的接口、字段与约束；**文档已确认不等于接口已实测成功**。
- 未在本文件出现的接口视为未核实，不得在业务说明中引用其名称或字段。

## 1. 服务地址与鉴权

- 根地址：`https://gate.gov-bid.com`（文档「1.4 服务地址」与各接口 cURL 一致）。
- 路径：`/outer-gateway/bid/{接口名}`。
- 鉴权：查询串 `?key={API_KEY}`，不放 body 或 header。
- 组件读取 `BBIAO_API_KEY`、`BBIAO_SERVER_URL`（未配置用默认根地址），不回显密钥。

## 2. 本 Skill 用到的接口

| 用途 | 接口 | 路径 |
|---|---|---|
| 按关键词/地区/日期定位项目 | SearchProjectForAI | `/outer-gateway/bid/SearchProjectForAI` |
| 取正文（已去 HTML），提取技术条款表述 | getZTBProjectDetailForAI | `/outer-gateway/bid/getZTBProjectDetailForAI` |
| 取正文（保留表格结构），逐条摘录技术规格表 | getZTBProjectDetail | `/outer-gateway/bid/getZTBProjectDetail` |
| 取结构化字段，判断标段划分与时间节点 | getZTBStructreDetail | `/outer-gateway/bid/getZTBStructreDetail` |
| 取附件列表，确认技术规格书与图纸是否可得 | getZTBProjectFiles | `/outer-gateway/bid/getZTBProjectFiles` |
| 取原文采集地址，作条款佐证 | getCollectUrl | `/outer-gateway/bid/getCollectUrl` |

### 2.1 SearchProjectForAI

| 参数 | 必填 | 说明 |
|---|---|---|
| startDate / endDate | 是 | `yyyy-MM-dd` 或 `yyyy-MM-dd HH:mm:ss` |
| pageId | 是 | 当前页码 |
| pageNumber | 是 | 每页条数，**不得超过 20**；设为 0 只返回数量 |
| keyword | 否 | 同时出现用空格，或关系用竖线 |
| excludeKW / inCludeKW | 否 | 排除词 / 必含词，竖线分隔（保留文档原拼写 `inCludeKW`） |
| className | 否 | 全部信息、招标信息、中标信息、合同信息、采购意向、拍租信息；多类英文逗号分隔 |
| areaName | 否 | 地区名称（非编码） |
| companyName | 否 | 甲方/乙方/代理机构名称 |
| OrderByType | 否 | 相关性 / 发布时间（首字母大写） |

响应：`data.total`、`data.pageId`、`data.pageNumber`、`data.hasNext`、`data.data[]` 含 `id`、`title`、`content`、`publishTime`、`areaName`、`projectMoney`、`projectClass`、`collectUrl`、`sbkjBidUrl`、`siginUpStopDate`、`bidStartDate`、`bidStartAddress`、`partAInfo`、`partBInfo`、`agencyInfo`。

### 2.2 getZTBProjectDetailForAI / getZTBProjectDetail

- 参数：`id`（integer，项目 ID）、`publishTime`（`yyyy-MM-dd HH:mm:ss`）。
- ForAI 版 `data.content` 已清除 HTML 标签，适合通读；**但表格结构会丢失**，技术规格表、参数逐条表不能靠它摘录。
- 普通版的 `content` 带 HTML 标签并保留 `<table>` 行结构，**技术参数应答表要求逐条对应原文，必须用这一版逐行摘录**。
- 两者都**不含**结构化字段。

### 2.3 getZTBStructreDetail

参数：`id`、`publishTime`。响应 `data` 含：`projectID`、`projectName`、`projectNumber[]`、`projectSectionCode[]`（多标段）、`budgetMoney[]`（元）、`bidMoney[]`（元）、`siginUpStopDate`、`bidStartDate`、`bidStartAddress[]`、`collectUrl`、`partyAInfo[]`、`partyBInfo[]`、`agencyInfo[]`、`bidCompany[]`。

技术标用法：`projectSectionCode` 有多个值时，技术卷必须按标段分册或分章，不能一套方案套全部标段；`siginUpStopDate`、`bidStartDate` 用于倒排编制计划，字段为空时不得推定时间。

### 2.4 getZTBProjectFiles

参数：`projectId`（注意与详情的 `id` 不同）、`publishTime`。响应 `data[]`：`projectFileID`、`projectID`、`name`（可能含省略号）、`url`、`proviceCode`、`cityCode`、`suffix`、`size`（KB）、`publishTime`、`state`、`createTime`。

`state`：0 未下载 / 1 下载正常 / 2 下载失败 / 3 超过 20M 未下载 / 4 已损坏 / 5 url 已失效。

**技术标含义**：`state` 非 1 时技术规格书与图纸正文不可得，此时技术卷只能依据用户提供的招标文件编制；仅凭公告做参数应答表，须整表标注"基于公告正文，待技术规格书复核"。

### 2.5 getCollectUrl

参数同详情接口。取公告原始采集地址作为条款佐证；链接可能失效，引用时保留采集时间。

## 3. 分类码表（已核实）

14 类信息分类（`searchProjectApi.projectClassID`）：1 公开招标、2 成交结果、3 合同公告、4 意向公开/招标预告、5 答疑变更、6 候选人公示、7 开标公示、8 重新招标、11 流标废标、18 结果变更、26 拍租公告、28 竞争性谈判、29 竞争性磋商、30 单一来源采购、31 其它。

采购分类：0 其它类、1 服务类、2 工程类、3 货物类。

**技术标用法**：采购分类可作为形态判定的初判依据（1→服务类、2→工程类、3→货物类），但最终形态须以技术要求的写法为准——采购分类为"货物类"而含安装施工的混合项目很常见。

`SearchProjectForAI` 的 `className` 只接受 6 个大类名称，**不能传子分类名**。

## 4. 与技术标编制相关的口径边界

1. 公告正文常写"具体详见招标文件"，**公告不等于技术规格书**；仅凭公告生成的技术参数应答表必须整表标注来源与局限。
2. `projectMoney` 是展示口径字符串（如 "370万"），不得写入技术卷，也不得作为技术参数或配置的依据。
3. 附件 `name` 可能含省略号，实际文件名需以 `url` 打开确认；不得凭文件名推定文件内容。
4. 候选公示不等同中标；中标结果不构成本项目技术要求依据。

## 5. 已知歧义（如实记录，需维护方复核）

1. `getZTBProjectDetailForAI`、`getZTBProjectDetail`、`getZTBProjectFiles`、`getZTBStructreDetail` 的 cURL 示例标注 `Content-Type: multipart/form-data`，但请求示例为 JSON 对象。组件按 JSON 发送，首次调用若报错交维护方复核，不盲目重试。
2. 接口名 `getZTBStructreDetail` 保留文档原拼写（Structre，非 Structure）。
3. `SearchProjectForAI` 响应示例中 `pageNumber` 回显为 0（请求 10 条、返回 10 条）；请求参数 `pageNumber=0` 仍表示"只返回数量"，不能把下一页请求设为 0。
4. `getZTBStructreDetail` 的 `projectID` 为整数，`getZTBProjectFiles` 响应的 `projectID` 为字符串，比较前统一转字符串。
5. `ztbAiStructureInfo`（LLM 结构化）输出由模型生成，不能作为技术条款原文依据，本 Skill 不使用。
