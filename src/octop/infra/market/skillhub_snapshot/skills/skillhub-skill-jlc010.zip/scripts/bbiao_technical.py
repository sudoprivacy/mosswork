#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""bbiao_technical.py — 标书技术标书助手 · 本地编制工具与最小查询组件

本地命令（不需要密钥、不联网）：
    tree    按技术卷形态生成章节树骨架（works 工程施工 / goods 货物 / service 服务）
    spec    技术参数点对点应答表台账校验与统计（CSV）
    score   技术评分索引校验与自评合计核对（CSV）

查询命令（需要 BBIAO_API_KEY）：
    window  计算默认时间窗口（查询模式近30天 / 分析模式近6个月，Asia/Shanghai）
    search  按关键词、地区、日期定位项目（默认第1页）
    detail  取项目正文（--kind ai|html|struct）
    files   取附件列表，确认技术规格书与图纸是否可得

设计约束：
  * 本地校验只报告问题，不修改台账；有硬错误时退出码 1，禁止直接交付。
  * 星号（★/▲）条款未满足或待核验，一律按硬错误处理，提示实质风险。
  * 密钥只从环境变量读取，不回显、不写入命令行、不拼接进日志。
"""

import argparse
import csv
import json
import os
import re
import sys
from datetime import date, datetime, timedelta, timezone
from urllib import request as urlrequest
from urllib.error import HTTPError, URLError

DEFAULT_BASE = "https://gate.gov-bid.com"

VERDICTS = ["满足", "优于", "不满足", "待核验"]

# 应答值里出现即视为"空话应答"——除非同时带具体数值
EMPTY_ANSWERS = [
    "满足要求", "符合要求", "响应招标文件", "满足招标文件", "符合招标文件",
    "符合国家标准", "符合国标", "按国标执行", "响应要求", "完全满足",
    "基本满足", "原则满足", "基本符合", "大致满足", "基本响应",
]

# 模糊表述：技术参数应答中视为弱化响应
VAGUE = ["约", "左右", "大致", "大概", "不低于左右", "视情况", "原则上"]

BAD_EXCERPT = ["详见招标文件", "见招标文件", "详见附件", "见附件", "同上", "同上条", "略"]

STAR_TRUE = {"是", "★", "▲", "y", "yes", "1", "true", "t", "星号", "否决项"}

SPEC_COLS = ["编号", "条款来源", "招标要求原文", "星号条款", "我方应答值",
             "应答结论", "证明材料", "标书页码", "备注"]
SCORE_COLS = ["评分项编号", "评分项名称", "分值", "对应章节", "自评得分",
              "自评依据", "证据材料"]


# ---------------------------------------------------------------- 章节树数据

TREE = {
    "works": {
        "name": "工程施工类",
        "rows": [
            ("1", "编制说明与依据", "编制依据（图纸号、规范号）、适用范围、标段划分", "技术负责人", "图纸目录、规范清单"),
            ("2", "工程概况与特点", "建设规模、结构形式、现场条件、周边环境", "技术负责人", "现场踏勘记录、图纸"),
            ("3", "施工部署", "项目管理机构、施工段划分、总体流程、总平面布置", "项目经理", "组织机构图、平面布置图"),
            ("4", "施工进度计划", "总进度横道/网络图、关键线路、里程碑、赶工预案", "生产经理", "进度计划表（与工期承诺一致）"),
            ("5", "资源配置计划", "劳动力曲线、机械设备表、材料进场、试验检测计划", "生产经理", "设备清单、检测计划"),
            ("6", "主要分部分项施工方法", "逐工序：工艺流程、操作要点、技术参数、质量标准", "专业工程师", "工艺图示、计算书"),
            ("7", "重点难点与专项方案", "危大工程专项清单、季节性施工、交叉作业", "技术负责人", "专项方案目录、论证要求"),
            ("8", "质量保证体系与措施", "质量目标、三检制、隐蔽验收、通病防治", "质量员", "质量管理体系文件"),
            ("9", "安全文明施工", "安全目标、危险源清单、防护措施、应急预案", "安全员", "安全生产许可证、预案"),
            ("10", "环境保护与绿色施工", "扬尘噪声污水控制、节能措施", "安全员", "环保措施清单"),
            ("11", "成品保护与竣工资料", "保护措施、资料移交清单", "资料员", "资料目录"),
        ],
    },
    "goods": {
        "name": "货物类",
        "rows": [
            ("1", "技术规格响应总述", "响应原则、型号选型说明、总体技术路线", "技术负责人", "选型对照表"),
            ("2", "技术参数点对点应答表", "逐条：要求原文→我方值→结论→证据", "技术负责人", "检测报告/规格书"),
            ("3", "设备配置与清单", "主机、辅机、备件、专用工具、随机资料", "技术负责人", "配置清单"),
            ("4", "供货与交付方案", "生产周期、包装运输、到场验收、仓储", "生产经理", "供货计划"),
            ("5", "安装调试方案", "安装工艺、调试步骤、联调接口、试运行", "调试工程师", "安装方案、接口协议"),
            ("6", "检验与试验计划", "出厂检验、到货检验、安装检验、性能试验", "质量员", "检验计划、试验报告"),
            ("7", "验收方案", "验收标准、流程、判定准则、整改机制", "质量员", "验收大纲"),
            ("8", "质量保证与追溯", "质量控制点、不合格品处理、追溯编码", "质量员", "质量体系文件"),
            ("9", "售后服务与备件", "响应时限、到场时限、备件库、质保范围", "售后经理", "服务承诺、备件清单"),
            ("10", "培训方案", "培训对象、内容、课时、考核", "售后经理", "培训大纲"),
        ],
    },
    "service": {
        "name": "服务类",
        "rows": [
            ("1", "服务理解与总体思路", "服务范围理解、服务目标、总体架构", "技术负责人", "需求理解对照表"),
            ("2", "服务机构与人员配置", "组织架构、岗位职责、人员数量与资格", "项目经理", "人员表+证书"),
            ("3", "服务流程与作业标准", "主流程、子流程、作业规范、表单", "服务经理", "流程图、作业手册"),
            ("4", "服务响应机制", "分级响应、受理渠道、时限承诺、升级路径", "服务经理", "响应机制说明"),
            ("5", "服务质量保障与考核", "质量指标、检查频次、考核办法、奖惩", "质量员", "考核细则"),
            ("6", "信息化与数据管理", "系统支撑、数据安全、报表", "技术负责人", "系统说明"),
            ("7", "应急预案", "场景清单、处置流程、演练计划", "项目经理", "预案文本"),
            ("8", "服务改进与知识沉淀", "复盘机制、改进闭环", "项目经理", "改进案例"),
        ],
    },
}


# ---------------------------------------------------------------- 基础工具

def die(msg, code=1):
    print(msg)
    sys.exit(code)


def read_csv(path, cols, label):
    if not os.path.isfile(path):
        die("{0}不存在：{1}".format(label, path))
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            die("{0}没有表头：{1}".format(label, path))
        header = [h.strip() for h in reader.fieldnames]
        missing = [c for c in cols if c not in header]
        if missing:
            die("{0}缺少列：{1}\n应有列：{2}".format(label, "、".join(missing), "、".join(cols)))
        rows = []
        for i, r in enumerate(reader, 2):
            row = {(k or "").strip(): (v or "").strip() for k, v in r.items()}
            if not any(row.values()):
                continue
            row["_line"] = i
            rows.append(row)
    return rows


def num(s):
    try:
        return float(str(s).replace(",", "").replace("，", ""))
    except (TypeError, ValueError):
        return None


def has_number(s):
    return bool(re.search(r"\d", s or ""))


# ---------------------------------------------------------------- tree

def cmd_tree(args):
    form = TREE[args.form]
    out = ["# 技术卷章节树（{0}）".format(form["name"]), ""]
    out.append("说明：章节骨架按形态生成；「对应评分项」一列须由用户按本项目评标办法填写，未对齐评分点前不得当作已完成。")
    out.append("")
    out.append("| 章号 | 章节名称 | 内容要点 | 责任岗位 | 必备证据 | 对应评分项 | 分值 |")
    out.append("|---|---|---|---|---|---|---|")
    for no, title, points, owner, proof in form["rows"]:
        out.append("| {0} | {1} | {2} | {3} | {4} | [待填] | [待填] |".format(
            no, title, points, owner, proof))
    out.append("")
    out.append("## 使用要求")
    out.append("")
    out.append("1. 逐章填写「对应评分项」与「分值」；无评分项对应的章节标为支撑性章节，说明其完整性作用。")
    out.append("2. 技术分合计须与评标办法一致；差额（如现场答辩分）单列说明。")
    if args.form == "goods":
        out.append("3. 第 2 章为技术卷核心：必须逐条应答，星号条款单独标记，无证明材料不得判满足。")
    elif args.form == "works":
        out.append("3. 第 6 章须写到工艺参数与操作要点，只写管理要求不得分；第 7 章须列危大工程专项方案清单。")
    else:
        out.append("3. 第 2 章人员须给资格与证书，只给人数不得分；第 4 章响应时限须分级且可考核。")
    out.append("4. 混合形态：按评分权重定主形态，其余以专章并入，不要三套骨架拼接。")
    text = "\n".join(out)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        print("已生成章节树：{0}（{1} 章）".format(args.out, len(form["rows"])))
        print("提醒：「对应评分项」与「分值」为空，须按本项目评标办法填写后方可用于编制。")
    else:
        print(text)
    return 0


# ---------------------------------------------------------------- spec

def is_star(v):
    return (v or "").strip().lower() in STAR_TRUE


def cmd_spec(args):
    rows = read_csv(args.ledger, SPEC_COLS, "参数应答台账")
    if not rows:
        die("台账没有数据行：{0}".format(args.ledger))

    errors, warns = [], []
    seen = {}

    for r in rows:
        line = r["_line"]
        no = r.get("编号", "")
        tag = "第{0}行（{1}）".format(line, no or "无编号")

        if not no:
            errors.append("{0} 编号为空".format(tag))
        elif no in seen:
            errors.append("{0} 编号重复，与第{1}行重复".format(tag, seen[no]))
        else:
            seen[no] = line

        if not r.get("条款来源"):
            errors.append("{0} 缺少条款来源（须能定位到招标文件哪一条）".format(tag))

        excerpt = r.get("招标要求原文", "")
        if not excerpt:
            errors.append("{0} 招标要求原文为空".format(tag))
        elif any(b in excerpt for b in BAD_EXCERPT) and len(excerpt) <= 12:
            errors.append("{0} 招标要求原文为「{1}」，不构成原文摘录".format(tag, excerpt))

        verdict = r.get("应答结论", "")
        if verdict not in VERDICTS:
            errors.append("{0} 应答结论「{1}」不在枚举内（满足/优于/不满足/待核验）".format(tag, verdict))

        answer = r.get("我方应答值", "")
        if not answer:
            errors.append("{0} 我方应答值为空（未取得应写「待补充」，结论记待核验）".format(tag))
        else:
            hit = [w for w in EMPTY_ANSWERS if w in answer]
            if hit and not has_number(answer):
                errors.append("{0} 应答值「{1}」属空话应答，须给具体数值/型号/标准号".format(
                    tag, "/".join(hit)))
            vague = [w for w in VAGUE if w in answer]
            if vague:
                warns.append("{0} 应答值含模糊表述「{1}」，核验时易被认定响应不足".format(
                    tag, "/".join(vague)))
            if verdict == "优于" and not has_number(answer):
                warns.append("{0} 结论为「优于」但未给出量化幅度".format(tag))

        proof = r.get("证明材料", "")
        note = r.get("备注", "")
        exempt = ("定性" in note) or ("无需材料" in note) or ("方案章节" in note)

        if verdict in ("满足", "优于") and not proof and not exempt:
            errors.append("{0} 结论为「{1}」但无证明材料（定性条款须在备注注明「定性条款」并以方案章节为据）".format(
                tag, verdict))

        if verdict == "不满足" and not note:
            errors.append("{0} 结论为「不满足」但未写偏离说明与处理方案".format(tag))

        if verdict == "待核验" and not note:
            warns.append("{0} 结论为「待核验」但未写明待谁提供、何时到位".format(tag))

        if is_star(r.get("星号条款", "")) and verdict in ("不满足", "待核验"):
            errors.append("{0} 星号/不得偏离条款结论为「{1}」，构成实质风险，须有合规处理方案".format(
                tag, verdict))

        if not r.get("标书页码") and verdict in ("满足", "优于"):
            warns.append("{0} 未填标书页码，评委按页码查证时无法定位".format(tag))

    n = len(rows)
    cnt = {v: sum(1 for r in rows if r.get("应答结论") == v) for v in VERDICTS}
    star_rows = [r for r in rows if is_star(r.get("星号条款", ""))]
    star_bad = [r for r in star_rows if r.get("应答结论") in ("不满足", "待核验")]
    ok = cnt["满足"] + cnt["优于"]
    with_proof = sum(1 for r in rows
                     if r.get("应答结论") in ("满足", "优于") and r.get("证明材料"))

    print("== 技术参数应答台账 ==")
    print("条款总数：{0}　星号/不得偏离：{1} 条（其中未满足 {2} 条）".format(
        n, len(star_rows), len(star_bad)))
    print("四态：满足 {0}｜优于 {1}｜不满足 {2}｜待核验 {3}　合计 {4}".format(
        cnt["满足"], cnt["优于"], cnt["不满足"], cnt["待核验"],
        sum(cnt.values())))
    if sum(cnt.values()) != n:
        print("[FAIL] 四态合计（{0}）不等于条款总数（{1}），存在结论为空或非枚举行".format(
            sum(cnt.values()), n))
    print("名义合格率（满足+优于）：{0}%".format(round(ok * 100.0 / n, 1)))
    print("证据挂接：{0}/{1} 条合格结论有证明材料（{2}%）".format(
        with_proof, ok, round(with_proof * 100.0 / ok, 1) if ok else 0.0))

    if star_bad:
        print("\n-- 星号条款未满足（须优先处理）--")
        for r in star_bad:
            print("  {0}｜{1}｜结论：{2}".format(
                r.get("编号"), r.get("条款来源"), r.get("应答结论")))

    if warns:
        print("\n-- 提示（{0} 条）--".format(len(warns)))
        for w in warns[: args.limit]:
            print("  [WARN] " + w)
        if len(warns) > args.limit:
            print("  …… 其余 {0} 条略（--limit 可调）".format(len(warns) - args.limit))

    print("")
    if errors:
        print("-- 硬错误（{0} 条，必须修正）--".format(len(errors)))
        for e in errors:
            print("  [FAIL] " + e)
        print("\n[FAIL] 台账未通过校验，不得据此交付技术卷。")
        return 1

    if warns and args.strict:
        print("[FAIL] --strict 模式下提示项也计为失败。")
        return 1

    print("[PASS] 台账通过校验（本地规则；参数真实性与证据有效性仍需人工核对）。")
    return 0


# ---------------------------------------------------------------- score

def cmd_score(args):
    rows = read_csv(args.ledger, SCORE_COLS, "技术评分索引")
    if not rows:
        die("评分索引没有数据行：{0}".format(args.ledger))

    errors, warns = [], []
    seen = {}
    total = 0.0
    self_total = 0.0

    for r in rows:
        line = r["_line"]
        no = r.get("评分项编号", "")
        tag = "第{0}行（{1}）".format(line, no or "无编号")

        if not no:
            errors.append("{0} 评分项编号为空".format(tag))
        elif no in seen:
            errors.append("{0} 评分项编号重复，与第{1}行重复".format(tag, seen[no]))
        else:
            seen[no] = line

        v = num(r.get("分值"))
        if v is None or v <= 0:
            errors.append("{0} 分值「{1}」不是有效正数".format(tag, r.get("分值")))
            v = 0.0

        s = num(r.get("自评得分"))
        if s is None:
            errors.append("{0} 自评得分「{1}」不是数值（未自评可填 0）".format(tag, r.get("自评得分")))
            s = 0.0
        elif s > v and v > 0:
            errors.append("{0} 自评得分（{1}）超过该项分值（{2}）".format(tag, s, v))
        elif s < 0:
            errors.append("{0} 自评得分为负数".format(tag))

        if not r.get("对应章节"):
            errors.append("{0} 未指定对应章节（有评分项无章节＝必失分）".format(tag))
        if not r.get("自评依据"):
            warns.append("{0} 未写自评依据（客观分须写命中档次，主观分按最保守档自评）".format(tag))
        if s > 0 and not r.get("证据材料"):
            warns.append("{0} 有自评得分但未挂证据材料".format(tag))

        total += v
        self_total += s

    print("== 技术评分索引 ==")
    print("评分项：{0} 项　分值合计：{1}".format(len(rows), round(total, 2)))
    print("自评合计：{0}　得分率：{1}%".format(
        round(self_total, 2), round(self_total * 100.0 / total, 1) if total else 0.0))

    if args.total is not None:
        if abs(total - args.total) > 0.01:
            errors.append("分值合计（{0}）与评标办法技术分总分（{1}）不一致，差额 {2}".format(
                round(total, 2), args.total, round(total - args.total, 2)))
        else:
            print("与评标办法技术分总分核对：一致")

    uncovered = [r.get("评分项编号") or "无编号" for r in rows if not r.get("对应章节")]
    if uncovered:
        print("未指定章节的评分项：{0}".format("、".join(uncovered)))

    if warns:
        print("\n-- 提示（{0} 条）--".format(len(warns)))
        for w in warns[: args.limit]:
            print("  [WARN] " + w)
        if len(warns) > args.limit:
            print("  …… 其余 {0} 条略（--limit 可调）".format(len(warns) - args.limit))

    print("")
    if errors:
        print("-- 硬错误（{0} 条，必须修正）--".format(len(errors)))
        for e in errors:
            print("  [FAIL] " + e)
        print("\n[FAIL] 评分索引未通过校验。")
        return 1

    if warns and args.strict:
        print("[FAIL] --strict 模式下提示项也计为失败。")
        return 1

    print("[PASS] 评分索引通过校验。")
    print("提醒：本表只核对内部一致性（分值、越界、章节、证据），不判断自评是否合理，也不预测实际得分。")
    return 0


# ---------------------------------------------------------------- API

class ApiError(Exception):
    def __init__(self, kind, message):
        self.kind = kind
        self.message = message


def tz_now():
    return datetime.now(timezone(timedelta(hours=8)))


def days_in_month(y, m):
    if m == 12:
        return 31
    return (date(y, m + 1, 1) - date(y, m, 1)).days


def shift_months(d, months):
    y, m = d.year, d.month - months
    while m <= 0:
        m += 12
        y -= 1
    return date(y, m, min(d.day, days_in_month(y, m)))


def cmd_window(args):
    today = tz_now().date()
    if args.mode == "analysis":
        start, label = shift_months(today, 6), "近 6 个月（分析模式）"
    else:
        start, label = today - timedelta(days=29), "近 30 个自然日（查询模式）"
    print("== 默认时间窗口 ==")
    print("模式：{0}".format(label))
    print("起止：{0} ~ {1}（含执行日，Asia/Shanghai）".format(start.isoformat(), today.isoformat()))
    print("日期字段：发布时间（publishTime）")
    print("说明：本窗口为默认值；用户指定时间、数量、页数时以用户要求为准。")


def api_post(name, payload):
    key = os.environ.get("BBIAO_API_KEY", "").strip()
    if not key:
        raise ApiError("no_key", "未配置 BBIAO_API_KEY")
    base = os.environ.get("BBIAO_SERVER_URL", "").strip() or DEFAULT_BASE
    url = "{0}/outer-gateway/bid/{1}?key={2}".format(base.rstrip("/"), name, key)
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urlrequest.Request(url, data=data, method="POST",
                             headers={"Content-Type": "application/json"})
    try:
        with urlrequest.urlopen(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
    except HTTPError as e:
        raise ApiError("http", "HTTP {0}".format(e.code))
    except URLError as e:
        raise ApiError("network", "网络不可达：{0}".format(e.reason))
    except Exception as e:  # noqa: BLE001
        raise ApiError("network", "请求失败：{0}".format(type(e).__name__))
    try:
        obj = json.loads(body)
    except ValueError:
        raise ApiError("parse", "响应不是合法 JSON")
    return obj


def api_result(obj):
    if not isinstance(obj, dict):
        raise ApiError("parse", "响应结构异常")
    code = obj.get("code", obj.get("status"))
    if code not in (None, 0, 200, "0", "200", "success"):
        raise ApiError("biz", str(obj.get("message") or obj.get("msg") or "业务返回失败"))
    if "data" not in obj:
        raise ApiError("parse", "响应缺少 data 字段")
    return obj["data"]


def report_api_error(e):
    print("本次未能完成查询：[{0}] {1}".format(e.kind, e.message))
    if e.kind == "no_key":
        print("已停止，未发出任何业务请求。")
        print("请访问世舶科技 API Key 获取页（首次注册可免费获取300次调用）配置 BBIAO_API_KEY。")
    elif e.kind in ("auth", "biz"):
        print("请检查密钥有效性、权限或额度；额度不足可访问套餐购买页充值。")
    else:
        print("已保留本地编制能力：章节树、应答台账校验、评分索引校验均不需要联网，可继续使用。")


def cmd_search(args):
    try:
        payload = {"startDate": args.start, "endDate": args.end,
                   "pageId": args.page, "pageNumber": args.page_size}
        if args.keyword:
            payload["keyword"] = args.keyword
        if args.area:
            payload["areaName"] = args.area
        if args.class_name:
            payload["className"] = args.class_name
        if args.order_by:
            payload["OrderByType"] = args.order_by
        data = api_result(api_post("SearchProjectForAI", payload))
    except ApiError as e:
        report_api_error(e)
        return 1

    rows = data.get("data") or []
    print("== 项目检索（第 {0} 页，每页 {1} 条）==".format(args.page, args.page_size))
    print("条件：{0} ~ {1}｜地区 {2}｜分类 {3}".format(
        args.start, args.end, args.area or "全国", args.class_name or "全部信息"))
    print("本页返回 {0} 条{}".format(
        len(rows), "，hasNext={0}".format(data.get("hasNext")) if "hasNext" in data else ""))
    if args.page == 1:
        print("说明：本次默认展示第 1 页，并非全部数据。")
    for i, r in enumerate(rows, 1):
        print("\n{0}. {1}".format(i, r.get("title", "（无标题）")))
        print("   地区：{0}｜类型：{1}｜发布：{2}".format(
            r.get("areaName") or "未披露", r.get("projectClass") or "未披露",
            r.get("publishTime") or "未披露"))
        if r.get("collectUrl"):
            print("   原文：{0}".format(r.get("collectUrl")))
    print("\n提示：技术卷编制需要技术规格书与图纸，列表信息不足以建参数应答表。")
    return 0


def cmd_detail(args):
    name = {"ai": "getZTBProjectDetailForAI",
            "html": "getZTBProjectDetail",
            "struct": "getZTBStructreDetail"}[args.kind]
    try:
        data = api_result(api_post(name, {"id": args.id, "publishTime": args.publish_time}))
    except ApiError as e:
        report_api_error(e)
        return 1

    label = {"ai": "正文（去标签）", "html": "正文（保留表格）", "struct": "结构化字段"}[args.kind]
    print("== 项目{0} ==".format(label))
    if args.kind == "struct":
        for k in ("projectName", "projectNumber", "projectSectionCode", "budgetMoney",
                  "siginUpStopDate", "bidStartDate"):
            if k in data:
                print("  {0}: {1}".format(k, data.get(k)))
        sections = data.get("projectSectionCode") or []
        if isinstance(sections, list) and len(sections) > 1:
            print("  提示：本项目有 {0} 个标段，技术卷应分册或分章，不能一套方案套全部标段。".format(
                len(sections)))
        return 0

    content = data.get("content") or ""
    print("标题：{0}".format(data.get("title") or "未披露"))
    print("发布：{0}".format(data.get("publishTime") or "未披露"))
    print("正文字数：{0}".format(len(content)))
    if args.kind == "ai":
        print("注意：本版本已清除 HTML 标签，表格结构丢失；技术规格表逐条摘录请改用 --kind html。")
    else:
        print("本版本保留表格结构，适合逐行摘录技术规格表与参数表。")
    if args.show:
        print("\n" + content[: args.chars])
        if len(content) > args.chars:
            print("……（已截断，共 {0} 字）".format(len(content)))
    return 0


def cmd_files(args):
    try:
        data = api_result(api_post("getZTBProjectFiles",
                                   {"projectId": args.project_id,
                                    "publishTime": args.publish_time}))
    except ApiError as e:
        report_api_error(e)
        return 1

    rows = data if isinstance(data, list) else (data.get("data") or [])
    print("== 附件列表（{0} 个）==".format(len(rows)))
    state_map = {0: "未下载", 1: "下载正常", 2: "下载失败", 3: "超过20M未下载",
                 4: "已损坏", 5: "url已失效"}
    usable = 0
    for r in rows:
        st = r.get("state")
        label = state_map.get(st, str(st))
        if st == 1:
            usable += 1
        print("  {0}｜{1}KB｜{2}｜{3}".format(
            r.get("name") or "（无名）", r.get("size") or "?", r.get("suffix") or "?", label))
    print("\n可用于摘录的附件：{0}/{1}".format(usable, len(rows)))
    if usable < len(rows):
        print("提醒：state 非「下载正常」的附件正文不可得，相关技术条款只能标「待核验」。")
    return 0


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(description="标书技术标书助手 · 本地编制工具与查询组件")
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("tree", help="生成技术卷章节树骨架")
    p.add_argument("--form", required=True, choices=["works", "goods", "service"])
    p.add_argument("--out")
    p.set_defaults(func=cmd_tree)

    p = sub.add_parser("spec", help="参数应答台账校验与统计")
    p.add_argument("--ledger", required=True)
    p.add_argument("--strict", action="store_true")
    p.add_argument("--limit", type=int, default=30)
    p.set_defaults(func=cmd_spec)

    p = sub.add_parser("score", help="技术评分索引校验")
    p.add_argument("--ledger", required=True)
    p.add_argument("--total", type=float, help="评标办法技术分总分")
    p.add_argument("--strict", action="store_true")
    p.add_argument("--limit", type=int, default=30)
    p.set_defaults(func=cmd_score)

    p = sub.add_parser("window", help="默认时间窗口")
    p.add_argument("--mode", choices=["query", "analysis"], default="query")
    p.set_defaults(func=cmd_window)

    p = sub.add_parser("search", help="项目检索")
    p.add_argument("--start", required=True)
    p.add_argument("--end", required=True)
    p.add_argument("--keyword")
    p.add_argument("--area")
    p.add_argument("--class-name")
    p.add_argument("--order-by", choices=["相关性", "发布时间"])
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--page-size", type=int, default=10)
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("detail", help="项目正文或结构化字段")
    p.add_argument("--id", required=True, type=int)
    p.add_argument("--publish-time", required=True)
    p.add_argument("--kind", choices=["ai", "html", "struct"], default="ai")
    p.add_argument("--show", action="store_true")
    p.add_argument("--chars", type=int, default=2000)
    p.set_defaults(func=cmd_detail)

    p = sub.add_parser("files", help="附件列表")
    p.add_argument("--project-id", required=True)
    p.add_argument("--publish-time", required=True)
    p.set_defaults(func=cmd_files)

    args = ap.parse_args()
    if not getattr(args, "func", None):
        ap.print_help()
        return 2
    if getattr(args, "page_size", None) is not None and args.page_size > 20:
        die("每页条数不得超过 20（接口文档约束）；需要更多记录请用 --page 续页。", 2)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
