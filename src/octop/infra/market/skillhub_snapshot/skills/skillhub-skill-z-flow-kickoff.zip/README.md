# z-flow-kickoff（立项启动模式）

一句话：z-系列总入口——从模糊想法到项目文档基线的全流程编排。自己不生产内容，只管开场协议、产物契约、阶段横幅、站间交接与续跑。

## 何时使用

说"进入 kickoff / 立项模式 / 从想法到立项 / 走一遍 z-系列 / 从头梳理项目"，或不知道从哪开始（迷糊态触发词）时触发；已有半途产物想接着走也触发。单域请求（只要"需求澄清"或"可行性"）由对应技能直接承接，本 skill 不抢。

## 用法速览

- 整链：「我想做 X，但不知道从哪开始」；续跑：「接着上次的立项继续走」；二期：「X 要做二期了，重新论证一轮」
- 基线后（工程文档基线已存在）：不启动整链——按需**单站迷你编排**（如「上次评估的条件满足了，重新评一次」→ 只跑②评估·重评，契约只含该站、横幅沿用产物编号）或指路对应技能
- 用法卡：聊天说 `z-flow-kickoff help`，ZCode 下 `/z-flow-kickoff-help` 直达（全景问法表：整链/单站/组合编排/元命令）
- 元命令（会话中随时）：进度 / 跳过② / 到此为止 / 回退到① / 停车场里有什么

## 核心机制

- **开场协议（三件事）**：复述理解（含用户原话具体事实）→ 产物主线（必产物按序编号到文件名、先做哪批、总预算与用户任务）→ 当次边界；确认后输出一行契约。
- **产物契约与阶段横幅**：契约行产物化（①澄清报告+登记册 → ②评估报告 → ③文档基线）；每轮回复头部带横幅 `【z-flow-kickoff · ①澄清 2/4】`。
- **阶段感知续跑**：扫 `docs/00-立项/` 与工程文档基线推断位置——有报告无登记册→补登记册；有登记册无评估→评估；评估 Go→基线化；**基线已存在→单站迷你编排或指路**；有条件 Go→问"先验证条件 / 带条件进基线"。
- **站间交接与停车场**：每批产物收口小结并确认进下一批；"全自动到底"仅异常时停；轨道外问题统一登记停车场（唯一属主本 skill），收线随全程小结移交。

## 与 z-系列的关系

```
z-flow-kickoff（本 skill：编排：开场协议→契约→横幅→交接→续跑）
   └─ z-pyramid(拆解) → z-clarify(澄清→登记册) ⇄ z-chain(生态事实)
                              ↓
                       z-assess(四维+风险+假设 → Go/No-Go)
                              ↓ Go
                       z-init(工程文档基线化) → 下游 spec/开发（松耦合，AGENTS.md 契约）
```

五个生产技能单独触发时执行各自的分级开场协议与 help 用法卡（多轮技能完整级、单轮任务轻量级），不需要本 skill 在场；本 skill 为整链意图与基线后再入提供可点名的总入口。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`）；更新只需 `git -C ~/z-skill-series pull`，无需重装。GitHub HTTPS 不稳时可改用 SSH（`git@github.com:zimy0033/z-skill-series.git`）。

### 单独安装（任一 agent）

把 `skills/z-flow-kickoff` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装已实测可用：`npx skills add zimy0033/z-skill-series/skills/z-flow-kickoff`。

## License

MIT
