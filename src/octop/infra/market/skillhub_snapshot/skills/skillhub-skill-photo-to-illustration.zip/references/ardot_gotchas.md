# Ardot 属性格式坑位速查

`batch_edit` 的节点数据走 `.ardot` schema，以下是从实战里踩出来的反直觉点。照抄最稳。

## 1. 颜色：没有 `a` 字段

```javascript
// ✅ 正确：透明度写在 fill/stroke 顶层的 opacity
fills:  [{type:"SOLID", color:{r:0.98,g:0.97,b:0.94}, opacity:1,   visible:true, blendMode:"NORMAL"}]
strokes:[{type:"SOLID", color:{r:0.96,g:0.90,b:0.83}, opacity:1,   visible:true, blendMode:"NORMAL"}]

// ❌ 错误：color 里带 a 会报 "Unrecognized key(s): 'a'"
fills:  [{type:"SOLID", color:{r:1,g:1,b:1,a:1}, ...}]   // ← 报错
```
- `r,g,b` 取值 0–1（不是 0–255）。
- 半透明：把 `opacity` 设成 0.7~0.92。

## 2. effects：type 全大写下划线

```javascript
effects:[{
  type:"DROP_SHADOW",                              // ✅ 大写+下划线
  color:{r:0.71,g:0.55,b:0.39,a:0.15},      // ✅ 阴影 color 才带 a(alpha)
  offset:{x:0,y:8}, radius:24, spread:0,
  visible:true, blendMode:"NORMAL",
  showShadowBehindNode:false,                     // 节点不透明时设 false
  boundVariables:{}
}]
```
- 合法 type：`DROP_SHADOW` / `INNER_SHADOW` / `BACKGROUND_BLUR` / `TEXTURE` / `GLASS`。
- 节点有半透明 fill（opacity<1）时 `showShadowBehindNode` 设 `true`，否则阴影会透出来；不透明节点设 `false`，否则外发光不渲染。

## 3. 文本：地板 28px & 字体数 ≤2

- 任何文本 `fontSize` 不得低于 **28**（海报硬规则，含寄语/页脚/日期）。
- 全稿最多 2 种字体；中文衬线用 `Noto Serif SC`，圆体/黑体用 `Noto Sans SC`。
- `textAlign:"CENTER"` 控制水平居中；垂直居中靠手动算 y（卡片高 120 → 文字 y 取卡片上沿 + (120-字号)/2）。

## 4. 图片不是节点类型

- Ardot **没有 image 节点**；图是 frame/rect 的 **fill**。
- 流程：先 `I()` 建 frame/rect → 再 `upload_images({items:[{nodeId, filePath}]})` 把本地 png 设为该节点 fill。
- 同一 nodeId 重复 `upload_images` = 替换旧图。

## 5. batch_edit 语法

```javascript
frame=I(document, {type:"frame", name:"插画画框", x:200, y:100, width:800, height:1200, cornerRadius:24, ...})
card =I("2:1",     {type:"frame", name:"底卡", x:150, y:1020, width:500, height:120, cornerRadius:60, ...})  // 父用已存在的节点 id（字符串）
txt  =I("2:1",     {type:"text",  name:"寄语", x:150, y:1020, width:500, height:120, textAlign:"CENTER", content:"...", fontSize:30, ...})
U("2:1", {fills:[...]})          // 更新已存在节点
D("3:2")                        // 删除节点（用真实 id，勿用 binding 名）
```
- 每个 `I()/C()` 必须有 binding 名；`U()/D()` 的 path 用**真实节点 id 字符串**，不能用 binding。
- 一次 `batch_edit` 尽量 ≤25 个 op；出错会整体回滚。
- 子节点坐标相对父 frame 左上角（0,0）。
