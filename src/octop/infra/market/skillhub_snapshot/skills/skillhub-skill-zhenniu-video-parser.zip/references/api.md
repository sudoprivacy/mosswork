# 视频解析接口契约（内部文档 · 不对外展示）

> 本文件只供本 skill 内部排查使用。**不要把这里的地址、凭证、品牌名、额度信息复制到给用户的回复或任何对外输出里**，对外统一称「解析服务」。

实测时间：2026-11-11。以下内容均为实际请求验证结果，非文档抄录。

## 端点

```
POST https://4dj.net/api/v1/video/parse.php
```

⚠️ 主域名 `4dj.net` 有效。`www.4dj.net` 会把请求路由到另一个站点并返回 HTTP 405。

## 凭证获取

公众号：**tk 牛逼社** —— 回复 **api** 可得**永久免费 api key**（`sk_...`）。

拿到 key 后按 `SKILL.md`「解析凭证（首次使用必配）」一节的任一方式配置（`--key` / 环境变量 `VIDPARSE_API_KEY` / `~/.vidparse/key.txt`）。

## 请求头

| Header | 值 | 必填 |
|---|---|---|
| `X-API-Key` | `sk_...` | 是 |
| `Content-Type` | `application/json` | 是 |
| `User-Agent` | 任意浏览器 UA | 建议 |

## 请求体

```json
{ "url": "https://www.bilibili.com/video/BV1xx411c7mD" }
```

`url` 填用户分享的原始链接即可（短链也行，接口自己跟随跳转）。不需要预先展开短链。

## 成功响应

```json
{
  "code": 0,
  "message": "success",
  "data": {
    "video_url": "https://upos-sz-mirrorhw.bilivideo.com/upgcxcode/.../62131-1-48.mp4?e=...&deadline=...",
    "title": "字幕君交流场所 www",
    "cover_url": "https://i0.hdslb.com/bfs/archive/transparent.png",
    "author": "",
    "platform": "bilibili",
    "duration": 2055,
    "is_free": true,
    "watermark": {
      "text": "小K导航赞助",
      "link": "https://www.4dj.net",
      "logo": "https://4dj.net/assets/images/logo.png",
      "position": "top-left",
      "bg": "#4a6cf7"
    },
    "credits_cost": 0,
    "credits_balance": 55795,
    "notice": "本接口免费使用，条件是在播放器上展示「小K导航赞助」水印。请配合使用我们提供的水印组件：https://4dj.net/assets/js/video-watermark.js"
  }
}
```

### 字段说明

| 字段 | 类型 | 说明 |
|---|---|---|
| `video_url` | string | 无水印视频直链。带签名和 `deadline` 时效，十几分钟内有效 |
| `title` | string | 标题。**可能含换行符**，入库/做文件名前需归一空白 |
| `cover_url` | string | 封面图。B站占位图可能是一个 123 字节的透明 png |
| `author` | string | 作者名，可能为空串 |
| `platform` | string | `bilibili` / `douyin` / `xiaohongshu` / `kuaishou` … |
| `duration` | int | 秒。`0` 或缺失表示未取到 |
| `is_free` | bool | 是否走的免费模式 |
| `watermark` | object | 免费模式要求展示的角标，`text/link/logo/position/bg` |
| `credits_cost` | int | 本次消耗点数，免费模式为 0 |
| `credits_balance` | int | 剩余点数 |
| `notice` | string | 使用条款说明 |

`data` 里**没有**图片数组字段，这是图文笔记拿不到图集的根本原因。

## 失败响应

HTTP 状态码通常仍是 200，错误信息在 body 的 `code` 里。

| code | HTTP | 含义 |
|---|---|---|
| 401 | 401 | Key 无效或已失效 |
| 405 | 405 | 域名不对（带了 www），或用了非 POST 方法 |
| 429 | 429 | 限频 |
| 502 | 200 | 上游抓取失败：`{"code":502,"message":"解析服务异常：HTTP 400"}`。链接无效、需登录、平台拦截都会落到这里 |

## CORS（做浏览器端页面时用）

- `Access-Control-Allow-Origin: *`
- `Access-Control-Allow-Headers` 包含 `X-API-Key`
- `OPTIONS` 预检返回 204

即：直接 `file://` 打开本地 HTML 也能请求成功，无需自建代理。

## 直链下载注意事项

1. 必须带 `Referer`（对应平台首页）和浏览器 `UA`，否则部分 CDN 直接 403。
2. `Content-Type` 通常是 `video/mp4`，`Content-Length` 完整；用流式下载即可。
3. 文件头魔数 `00 00 00 xx 66 74 79 70` (`....ftyp`) 确认是 MP4。
4. 抖音/快手直链路径里常不含 `.mp4`，不要按 URL 猜后缀。
5. 直链有时效，解析完尽快下载；失败优先重新解析而不是重试旧链。
6. 部分直链绑定解析服务器出口 IP，换网络环境会 403，客户端无解。

## 最小可复现调用（curl）

```bash
curl -s -X POST "https://4dj.net/api/v1/video/parse.php" \
  -H "X-API-Key: $FOURDJ_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"url":"https://www.bilibili.com/video/BV1xx411c7mD"}'
```
