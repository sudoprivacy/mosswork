# 意图 → 搜索词映射 & 错误表

本文件供 `auto-skill-installer` 在「模糊意图」分支（SKILL.md Step 1 分支 B）派生搜索词时参考，
以及在安装失败时给出友好提示。属于按需加载的参考资料，不必常驻上下文。

## 一、常见意图 → 候选搜索词（派生示例）

派生原则：每个意图给 2–3 个词，覆盖「核心词 / 动作+对象 / 同义词」。优先保留用户原话实词。

| 用户原话（意图） | 派生 keyword 示例 |
|---|---|
| 我想管理邮件 / 收发信 | 邮件, email, 邮箱助手 |
| 帮我做 PPT / 演示文稿 | PPT, 演示文稿, 幻灯片 |
| 自动发邮件提醒 | 邮件提醒, mail notify, 定时邮件 |
| 读 / 处理 PDF | PDF, pdf 阅读, 文档解析 |
| 写 Word 文档 | Word, docx, 文档写作 |
| 画流程图 / 架构图 | 流程图, 绘图, diagram |
| 管理我的待办 / 任务 | 待办, todo, 任务管理 |
| 抓网页数据 / 爬虫 | 爬虫, 网页抓取, scraper |
| 自动回复客户 | 客服, 自动回复, customer support |
| 记账 / 管财务 | 记账, 财务, finance |
| 翻译文档 | 翻译, translate, 多语言 |
| 整理本地文件 | 文件整理, 文件管理, 去重 |
| 做数据分析 / 报表 | 数据分析, 报表, 可视化 |
| 连接数据库查数 | 数据库, SQL, database |
| 自动化浏览器操作 | 浏览器自动化, RPA, browser |
| 生成图片 / AI 绘图 | 画图, 文生图, image gen |
| 写代码辅助 | 编程助手, code, copilot |
| 管理 Git 仓库 | Git, 版本控制, 代码托管 |
| 定时任务 / 提醒 | 定时, 提醒, scheduler |
| 做思维导图 | 思维导图, 脑图, mindmap |

> 实际派生时不要死板照搬上表——以上下文真实意图为准，上面只是示范「多粒度派生」的写法。

## 二、安装失败错误表（来自 `workbuddy_marketplace_skill` 的 install 返回）

| `error` 前缀 | 含义 | 给用户的中文提示 |
|---|---|---|
| `[CONFIG_ERROR]` | 主进程未配置 endpoint | 「WorkBuddy 推荐市场暂未启用，可能需要更新到最新版客户端」 |
| `[BUILTIN_MARKET_ERROR]` | 后端业务错误 | 直接展示 `error` 内容 |
| `[UNKNOWN_SKILL_ID]` | install 阶段发现该 skillId 已不存在 | **不要**重试相同 id；回到 Step 2 重新 search 取新 id 再装 |
| `[DOWNLOAD_ERROR]` | 下载签名 URL 或 zip 失败 | 「下载失败，可能是网络问题或权限不足」 |
| `[EXTRACT_ERROR]` | 解压失败 | 「解压安装包失败，建议清理 `$WORKBUDDY_CONFIG_DIR/skills/`（默认 `~/.workbuddy/skills/`）后重试」 |
| `[INSTALL_ERROR]` | 其他未知 | 直接展示 `error` 内容 |

## 三、search 返回字段速查

- `success: false` → 透传 `error`，停止当前 keyword。
- `results: []` → 该 keyword 无命中，尝试下一个派生词。
- `results[i].installed` → 是否已安装（bool）。
- `results[i].updateAvailable` → 已装且有新版（bool，由 semver 算好）。
- `results[i].version` / `installedVersion` → 市场最新版 / 本地已装版。
- `results[i].skillId` → 安装用的内部 id（**不要**泄露给用户）。
