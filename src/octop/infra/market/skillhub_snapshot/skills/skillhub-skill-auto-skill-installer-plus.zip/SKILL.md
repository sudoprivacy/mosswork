---
name: skillhub-skill-auto-skill-installer-plus
description: "# Auto Skill Installer（意图驱动的自动查找与安装）"
---

# Auto Skill Installer（意图驱动的自动查找与安装）

把「我想要某个能力」这类模糊表达，自动转换为市场检索、选出最佳 Skill 并完成安装。

## When to Use

以下任一情况即触发本 Skill：

- 用户用**自然语言描述需求**而非具体技能名（例：「帮我找个能读 PDF 的 skill」「想自动化发邮件」）。
- 用户明确要求**自动 / 推荐**安装（例：「自动装个好用的笔记 skill」「推荐个能画图的」）。
- 用户在任务中暴露出 WorkBuddy 不具备的能力，且希望直接补齐（本 Skill 可作为「先找后装」的入口）。
- 用户只说了「装个 skill / 找下技能」但没给名字 → 礼貌追问想要什么能力，拿到意图后再继续。

不要用于：用户已经给了明确的技能技术名且只想安装它——那种情况用 `marketplace-skill-installer` 更直接；但本 Skill 也能处理（见 Step 1 分支 B）。

## 严格的工具调用约束

- **只**通过 `workbuddy_marketplace_skill` 完成全部 search / install 操作；鉴权、下载、解压均由宿主处理。
- **禁止**直接构造任何 HTTP 请求，禁止涉及 token / cookie / Authorization。
- **禁止**伪造或猜测 `skillId`——必须来自 search 返回结果。
- 除该工具外，本 Skill 不触发 Bash、文件写入或额外网络请求。

## 两种运行模式

根据用户的措辞自动判定：

- **安装模式**（默认）：含「安装 / 装 / install / 帮我装 / 自动装」等词 → 找到后执行安装。
- **查找模式**：含「推荐 / 找一下 / 有哪些 / 列出 / 看看 / 有没有」且**不含**安装词 → 只列出候选并给出建议，**不**安装，等用户确认后再装。

## Workflow

### Step 1：解析意图，生成搜索词

从用户输入中抽取搜索关键字，分两类处理：

- **分支 A — 显式技能名 / 技术名**（如「装 lark-unified」「安装飞书套件」）：
  直接用该名字作为 keyword（同 `marketplace-skill-installer` 逻辑）。
- **分支 B — 模糊意图 / 自然语言**（如「我想管理邮件」「帮我做 PPT」）：
  不要让用户再解释，自行派生 **2–3 个**候选 keyword，覆盖不同粒度：
  1. 领域核心词（中文 + 英文各一，如「邮件 / email」）；
  2. 动作 + 对象（如「邮件管理 / mail manage」）；
  3. 同义词 / 上位词（参考 `references/intent_keywords.md` 的映射表，如「邮件→邮箱、收发信」）。
  派生时优先保留用户原话里的实词，再补充行业同义词。

### Step 2：搜索（多词回退）

对每个派生 keyword 调用 search（limit 默认 5，候选多时升到 10）：

```json
{ "action": "search", "keyword": "邮件", "limit": 5 }
```

- `success: false` → 透传 `error` 并停止当前 keyword，继续下一个 keyword。
- 所有 keyword 都返回 `results: []` 或失败 → 进入 Step 6 的「无结果」处理。
- 合并所有 keyword 的结果，**按 `skillId` 去重**。

### Step 3：排序与选优

对去重后的候选做轻量排序（无需模型重排，按规则即可）：

1. 名称/技术名与任一 keyword **精确或前缀匹配** → 最高优先级；
2. description 与 keyword **关键词重叠数**多者优先；
3. 同分时 `installed` 为 false 的优先（已装的往后排，避免重复推荐）；
4. 仍同分，version 高者优先。

得到排序后的候选列表 `C`。

### Step 4：安装决策（核心「自动」逻辑）

按 `C` 与模式判定：

- **查找模式** → 跳到 Step 5 的「仅展示」分支。
- **安装模式**：
  - `C` 为空 → 见 Step 6。
  - `C.length === 1` → **直接安装**该唯一命中（无需再问）。
  - `C.length >= 2` 且用户说过「直接装最好的 / 全自动 / 别问直接装」→ 取 `C[0]` 安装。
  - `C.length >= 2` 且未声明全自动 → **展示 Top 3–5 让用户挑**（见 Step 5 展示格式），选定后取其 `skillId`。
  - 命中项若 `installed === true`：
    - 且 `updateAvailable === false` → 告知「已是最新 v\<version\>」，停止；
    - 且 `updateAvailable === true` → 询问「已装 v\<installedVersion\>，最新 v\<version\>，是否更新？」，同意后再 install。
  - ⚠️ 不要自行用字符串比较版本新旧——`updateAvailable` 已由 semver 算好。

### Step 5：执行 install / 展示结果

**安装（安装模式）：**

```json
{ "action": "install", "skillId": "<选中的 skillId>" }
```

返回处理：
- `success: true` → 用 `message` 字段告诉用户装到哪、版本多少，补一句「在【技能管理】面板可见」。**不要**手动拼路径，直接用 `message`。
- `success: false` → 透传 `error` 并按错误类型提示（见 `references/intent_keywords.md` 末尾错误表）。

**仅展示（查找模式 / 多命中待选）：** 展示 `name`、`version`、description 前 60 字、是否 `installed`。**不要**把 `skillId` 透给用户。示例：

```text
为你找到几个相关 Skill，挑一个我就装：
1. 邮件管家 v1.2.0 — 收发邮件/自动分类  ✅ 已安装 v1.1.0
2. 邮箱助手 v0.9.1 — 智能撰写与摘要
3. 邮件定时发送 v0.5.0 — 定时群发
```

### Step 6：边界与错误处理

- **无结果**：所有 keyword 都空 → 告诉用户「推荐市场没找到匹配『<原始意图>』的 skill」，并主动建议：换更通用的词、或确认是否拼写/领域差异；可基于 `references/intent_keywords.md` 给出 1–2 个替代关键词让其确认。
- **安装失败**：按错误前缀映射提示（见 reference 错误表）。`[UNKNOWN_SKILL_ID]` 时不要重试同一 id，回到 Step 2 重新 search 取新 id。
- 安装成功后**不要**自动启用该 Skill 或调用它的工具——交由用户启用。

## 重要规则

- 鉴权全由宿主处理，不要向用户索取 token / cookie / 任何 header。
- 用户未给任何名字或意图时，先追问「想安装哪类能力？」再继续，不要盲目搜索。
- 优先把模糊意图转成多个 keyword 再搜，比单一关键词命中率更高；但 keyword 数量控制在 3 个以内，避免噪音。
- 安装是「有副作用」操作：唯一命中或用户声明全自动时才自动装；多命中默认先让用户选。
