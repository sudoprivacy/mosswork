#!/usr/bin/env python3
"""知识资料聚类引擎 + 形态匹配器。

Phase 1: 按主题/工具/标签将资料自动分组。
Phase 2: 对每个 cluster 判断最佳合成形态。


用法:
    python3 cluster.py --input ITEMS_JSON --output CLUSTERS_JSON
        [--min-items N] [--focus KEYWORD] [--depth {L1,L2,L3}]

内嵌字段适配器：自动识别 processed_kb_items / digest 卡片 等格式。
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log


import json
import re
import sys
from collections import defaultdict, Counter


# ── 工具关键词（用于同工具分组）──
TOOL_KEYWORDS = [
    "Codex", "Seedance", "GPT-Image", "Image2", "Nano Banana",
    "Claude", "Gemini", "DeepSeek", "NotebookLM", "OpenClaw",
    "MCP", "Sora", "Midjourney", "ComfyUI", "Stable Diffusion",
    "Flux", "即梦", "可灵", "剪映", "CapCut", "Obsidian",
    "Playwright", "yt-dlp", "Whisk", "Grok",
]

# ── 形态判断关键词 ──
STEP_KEYWORDS = ["步骤", "流程", "如何做", "教程", "保姆级", "手把手",
                  "搭建", "实操", "工作流", "SOP", "全流程"]
CHOICE_KEYWORDS = ["选哪个", "vs", "对比", "还是", "推荐", "评测",
                    "还是用", "替代", "哪个好"]


def extract_tools(title):
    """从标题提取工具关键词。"""
    found = []
    for tk in TOOL_KEYWORDS:
        if tk in title:
            found.append(tk)
    return found


def match_form(items_titles, items_tags):
    """根据资料标题/标签判断最佳合成形态。
    
    返回 (form_type, reason)。
    form_type 之一: contrast/flow/map/decision/cheatsheet
    """
    all_text = " ".join(items_titles)
    
    # 规则1: 同工具+不同方法 → 对比分析
    tool_count = Counter()
    for title in items_titles:
        for tk in TOOL_KEYWORDS:
            if tk in title:
                tool_count[tk] += 1
    common_tools = [(t, c) for t, c in tool_count.most_common() if c >= 2]
    if common_tools and len(items_titles) >= 2:
        return ("contrast", f"同工具「{common_tools[0][0]}」在 {len(items_titles)} 篇中以不同方式出现")

    # 规则2: 步骤关键词 → 流程指南
    step_count = sum(1 for title in items_titles if any(kw in title for kw in STEP_KEYWORDS))
    if step_count >= len(items_titles) * 0.4:  # 40%以上含步骤关键词
        return ("flow", f"{step_count}/{len(items_titles)} 篇含操作步骤关键词")

    # 规则3: ≥3篇同主题无重复步骤 → 知识地图
    if len(items_titles) >= 3:
        return ("map", f"{len(items_titles)} 篇同主题，各覆盖不同侧面")

    # 规则4: 选择/取舍关键词 → 决策框架
    if any(kw in all_text for kw in CHOICE_KEYWORDS):
        return ("decision", "含选择/取舍类关键词")

    # 规则5: 默认 → 速查表
    return ("cheatsheet", "默认速查提取")


def adapt_fields(item):
    """内嵌字段适配器：将不同格式归一化。"""
    title = item.get("title", item.get("label", ""))
    theme = item.get("theme", "")
    grade = item.get("grade", "B")
    summary = (
        item.get("summary")
        or item.get("value")
        or item.get("description")
        or ""
    )
    tags = item.get("tags", [])
    if not tags:
        # 从三级标签字段反推
        p = item.get("primary_tag", "")
        s = item.get("secondary_tag", "")
        t = item.get("tertiary_tag", "")
        tags = [x for x in [p, s, t] if x]
    return {
        "title": title,
        "theme": theme,
        "grade": grade,
        "summary": summary,
        "tags": tags,
        "kb_name": item.get("kb_name", ""),
        "kb_id": item.get("kb_id", ""),
        "media_id": item.get("media_id", ""),
        "media_type": item.get("media_type", ""),
        "_tools": extract_tools(title),
    }


def main():
    args = sys.argv[1:]
    input_path = args[args.index("--input") + 1]
    output_path = args[args.index("--output") + 1]
    min_items = int(args[args.index("--min-items") + 1]) if "--min-items" in args else 2
    focus = args[args.index("--focus") + 1] if "--focus" in args else None
    depth = args[args.index("--depth") + 1] if "--depth" in args else "L2"

    with open(input_path, "r", encoding="utf-8") as f:
        raw_items = json.load(f)

    # 归一化
    items = [adapt_fields(i) for i in raw_items]

    # 过滤（仅 A/B 类参与合成，C 类不参与）
    items = [i for i in items if i["grade"] in ("A", "B")]

    # 用户聚焦过滤
    if focus:
        items = [i for i in items if focus in i["title"] or focus in i["theme"]]

    # ── 聚类 ──
    # 方式1: 按主题分组
    theme_groups = defaultdict(list)
    for item in items:
        theme = item["theme"] or "未分类"
        theme_groups[theme].append(item)

    # 方式2: 按工具共享分组（同一工具出现在多篇 → 独立 cluster）
    tool_groups = defaultdict(list)
    for item in items:
        for tool in item["_tools"]:
            tool_groups[tool].append(item)

    # 合并去重
    clusters = []

    for theme, members in theme_groups.items():
        if len(members) >= min_items:
            titles = [m["title"] for m in members]
            all_tags = list(set(t for m in members for t in m["tags"]))
            form_type, form_reason = match_form(titles, all_tags)

            depth_rec = depth
            if len(members) <= 2:
                depth_rec = "L1"
            elif len(members) >= 5 and depth == "L3":
                depth_rec = "L3"

            clusters.append({
                "id": f"theme_{theme.replace(' ', '_')}",
                "type": "theme",
                "label": theme,
                "item_count": len(members),
                "kb_count": len(set(m["kb_name"] for m in members)),
                "items": [
                    {
                        "title": m["title"],
                        "kb_name": m["kb_name"],
                        "kb_id": m.get("kb_id", ""),
                        "grade": m["grade"],
                        "summary": m["summary"][:200],
                        "media_id": m["media_id"],
                        "media_type": m["media_type"],
                        "tools": m["_tools"],
                    }
                    for m in members
                ],
                "form": form_type,
                "form_reason": form_reason,
                "depth": depth_rec,
            })

    for tool, members in tool_groups.items():
        if len(members) >= min_items:
            titles = [m["title"] for m in members]
            # 检查是否已被 theme cluster 覆盖
            member_titles = {m["title"] for m in members}
            covered = any(
                member_titles & {i["title"] for i in c["items"]}
                for c in clusters
            )
            if not covered:
                form_type, form_reason = match_form(titles, [])
                clusters.append({
                    "id": f"tool_{tool}",
                    "type": "tool",
                    "label": tool,
                    "item_count": len(members),
                    "kb_count": len(set(m["kb_name"] for m in members)),
                    "items": [
                        {
                            "title": m["title"],
                            "kb_name": m["kb_name"],
                            "kb_id": m.get("kb_id", ""),
                            "grade": m["grade"],
                            "summary": m["summary"][:200],
                            "media_id": m["media_id"],
                            "media_type": m["media_type"],
                            "tools": m["_tools"],
                        }
                        for m in members
                    ],
                    "form": form_type,
                    "form_reason": form_reason,
                    "depth": depth if len(members) >= 3 else "L1",
                })

    # 去重：同一组资料只保留一个 cluster
    seen_sets = []
    unique_clusters = []
    for c in clusters:
        titles_set = frozenset(i["title"] for i in c["items"])
        if titles_set not in seen_sets:
            seen_sets.append(titles_set)
            unique_clusters.append(c)
    clusters = unique_clusters

    # 排序：数量多的在前
    clusters.sort(key=lambda c: -c["item_count"])

    result = {
        "total_items": len(items),
        "total_clusters": len(clusters),
        "focus": focus,
        "clusters": clusters,
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # 摘要输出
    form_names = {
        "contrast": "对比分析", "flow": "流程指南", "map": "知识地图",
        "decision": "决策框架", "cheatsheet": "速查表",
    }
    log.info(f"聚类完成: {len(clusters)} 个可合成主题 (共 {len(items)} 条资料)")
    for c in clusters[:10]:
        form_cn = form_names.get(c["form"], c["form"])
        log.info(f"  [{form_cn}] {c['label']} — {c['item_count']}条 ({c['form_reason']})")
    if len(clusters) > 10:
        log.info(f"  ... 共 {len(clusters)} 个")


if __name__ == "__main__":
    main()
