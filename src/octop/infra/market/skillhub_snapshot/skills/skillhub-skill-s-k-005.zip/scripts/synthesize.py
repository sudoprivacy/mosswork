#!/usr/bin/env python3
"""合成引擎 v2：读取 cluster JSON → 按形态模板生成结构化输出 → 可选状态回写。

用法:
    # Phase 3+4: 合成输出
    python3 synthesize.py \

        --clusters CLUSTERS_JSON \
        --output-dir OUTPUT_DIR \
        --cards-dir knowledge_cards/ \
        --generate-files \
        [--depth-override L1|L2|L3]

    # Phase 4b: 状态回写（用户确认后）
    python3 synthesize.py \
        --clusters CLUSTERS_JSON \
        --data processed_kb_items_latest.json \
        --confirm-conversion

新增 (v2):
    - 自动读取 knowledge_cards/ 中已消化的卡片，用作合成素材
    - 根据 depth 实际区分摘要来源
    - --confirm-conversion 回写 output_status="已转化"
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log


import json
import os
import re
import sys
from collections import Counter
from datetime import datetime

FORM_NAMES = {
    "contrast": "对比分析", "flow": "流程指南", "map": "知识地图",
    "decision": "决策框架", "cheatsheet": "速查表",
}

FORM_SECTIONS = {
    "contrast": """| 维度 | 方案A | 方案B | 推荐场景 |
|------|------|------|---------|
{dimensions}

**选择建议**：
{suggestions}
""",

    "flow": """| # | 步骤 | 详细说明 | 来源 |
|---|------|---------|------|
{steps}

> 以上步骤已合并去重。标注 [N] 表示该步骤在对应来源中被提及。
""",

    "map": """```
{map_tree}
```

**各分支详解**：
{map_details}
""",

    "decision": """```
{tree}
```

**各方案对比**：
| 方案 | 适用场景 | 优势 | 劣势 | 来源 |
|------|---------|------|------|------|
{options}
""",

    "cheatsheet": """| 条目 | 关键信息 | 适用场景 | 来源 |
|------|---------|---------|:--:|
{rows}
""",
}


# ── 卡片读取 ──

def find_card_for_item(item, cards_dir):
    """在 knowledge_cards/ 目录中查找某条资料的知识卡片。"""
    if not os.path.isdir(cards_dir):
        return None
    title = item.get("title", "").strip()
    for fn in os.listdir(cards_dir):
        if not fn.endswith(".md") or fn.startswith("_"):
            continue
        fpath = os.path.join(cards_dir, fn)
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                first_line = f.readline().strip()
            # 匹配: # 📝 标题 或 # 📖 标题
            card_title = re.sub(r'^#\s*[📝📖]\s*', '', first_line).strip()
            if card_title == title or card_title[:40] in title or title[:40] in card_title:
                with open(fpath, "r", encoding="utf-8") as f:
                    return f.read()
        except Exception:
            continue
    return None


def extract_sections(card_text):
    """从知识卡片中提取结构化段落。"""
    if not card_text:
        return {}
    sections = {}
    current_section = "_header"
    current_content = []
    for line in card_text.split("\n"):
        if line.startswith("## "):
            if current_content:
                sections[current_section] = "\n".join(current_content).strip()
            current_section = line[3:].strip()
            current_content = []
        else:
            current_content.append(line)
    if current_content:
        sections[current_section] = "\n".join(current_content).strip()
    return sections


# ── 内容聚合 ──

def extract_key_points(item, cards_dir, card_cache):
    """从资料摘要或卡片中提取关键信息点。"""
    title = item.get("title", "")
    summary = item.get("summary", item.get("value", ""))

    # 优先用卡片
    card = card_cache.get(title.strip())
    if card:
        sections = extract_sections(card)
        one_liner = ""
        for k in ["一句话总结", "核心观点"]:
            if k in sections:
                one_liner += sections[k] + "\n"
        if one_liner.strip():
            return one_liner.strip()[:500]

    # 其次用 summary 字段
    if summary and len(summary) > 10:
        return summary[:500]

    return f"「{title[:60]}」（待消化）"


def extract_tools_from_items(items):
    """从多条资料的标题/摘要中提取工具名。"""
    found = set()
    for item in items:
        title = item.get("title", "")
        summary = item.get("summary", "")
        for word in re.split(r'[，,、\s]+', title + " " + summary):
            word = word.strip()
            if (len(word) >= 3 and
                any(c.isupper() for c in word) and
                not word.startswith("http")):
                found.add(word)
    return sorted(found)[:10]


# ── 合成核心 ──

def build_output(c, today, cards_dir, card_cache):
    """根据 cluster 生成 Markdown 合成指南（v2：真实内容版）。
    
    优先利用已有的 knowledge_cards 作为合成素材；
    卡片不足时，基于 summary 字段做基础聚合。
    AI 深度分析段落保留明确标记，但不留纯占位符。
    """
    form = c["form"]
    form_cn = FORM_NAMES.get(form, "速查表")
    section_template = FORM_SECTIONS.get(form, FORM_SECTIONS["cheatsheet"])
    items = c["items"]
    depth = c.get("depth", "L2")

    # 收集各 item 的可用信息
    item_key_points = {}
    item_card_available = {}
    for item in items:
        title = item.get("title", "").strip()
        points = extract_key_points(item, cards_dir, card_cache)
        item_key_points[title] = points
        item_card_available[title] = title.strip() in card_cache

    cards_available = sum(1 for v in item_card_available.values() if v)
    tools = extract_tools_from_items(items)

    # ── 深度标签 ──
    depth_labels = {
        "L1": "摘要合并 — 仅基于资料摘要字段快速扫描",
        "L2": "交叉验证 — 利用已有知识卡片+摘要做对照",
        "L3": "全文重构 — 需 fetch 全部原文做深度交叉对比",
    }

    lines = []
    lines.append(f"# 合成指南：{c['label']}")
    lines.append("")
    lines.append(f"**合成类型**：{form_cn}")
    lines.append(f"**深度**：{depth} — {depth_labels.get(depth, depth)}")
    lines.append(f"**来源材料**：{c['item_count']}条 | 覆盖 {c['kb_count']}个知识库 | {cards_available}条有知识卡片")
    lines.append(f"**更新时间**：{today}")
    lines.append(f"**聚类依据**：{c['form_reason']}")
    lines.append("")
    lines.append("---")
    lines.append("")

    # L3：标记需要全文 fetch 的条目
    if depth == "L3":
        items_need_fetch = [
            it for it in items
            if it.get("title", "").strip() not in card_cache
        ]
        if items_need_fetch:
            lines.append("> ⚠️ **L3 深度要求**：以下资料尚无知识卡片，需 fetch 全文后才能做完整交叉对比：")
            lines.append(">")
            for it in items_need_fetch[:5]:
                lines.append(f"> `fetch(type=\"media_id\", id=\"{it.get('media_id','')}\")` — {it.get('title','')[:55]}")
            if len(items_need_fetch) > 5:
                lines.append(f"> ... 及其他 {len(items_need_fetch)-5} 条")
            lines.append("")

    # ═══ 一、核心共识 ═══
    lines.append("## 一、核心共识")
    lines.append("")

    if depth == "L1":
        # L1：仅摘要表格
        lines.append(f"> L1 深度 — 基于 {c['item_count']} 条资料的摘要字段快速聚合。")
        lines.append("")
        lines.append("| # | 标题 | 一句话价值 |")
        lines.append("|---|------|----------|")
        for idx, item in enumerate(items, 1):
            val = item.get("value", item.get("summary", ""))[:60]
            lines.append(f"| {idx} | {item['title'][:40]} | {val} |")
        lines.append("")
        has_any_card = cards_available > 0
        lines.append(f"> 💡 升级到 L2{' 或 L3' if not has_any_card else ''} 深度可获得{'知识卡片交叉比对' if has_any_card else '更详细的分析'}。")
    else:
        # L2/L3
        if cards_available >= 2:
            lines.append(f"> 基于 {cards_available} 条知识卡片的交叉比对。")
        elif cards_available == 1:
            lines.append("> 仅 1 条有知识卡片，以下为卡片核心观点摘要。")
        else:
            lines.append("> 以下为资料摘要的聚合。建议先消化为知识卡片后重新合成以获得更深洞察。")
        lines.append("")

        consensus_count = 0
        for idx, item in enumerate(items, 1):
            title = item.get("title", "")
            points = item_key_points.get(title.strip(), "")
            if points and "待消化" not in points:
                consensus_count += 1
                kb = item.get("kb_name", "")
                lines.append(f"### 来源 [{idx}]：{title[:60]}")
                lines.append(f"*{kb} | 等级: {item.get('grade', '?')}*")
                lines.append("")
                max_lines = None if depth == "L3" else 5
                cnt = 0
                for point_line in points.split("\n"):
                    point_line = point_line.strip()
                    if point_line and not point_line.startswith("##"):
                        lines.append(f"- {point_line}")
                        cnt += 1
                        if max_lines and cnt >= max_lines:
                            break
                lines.append("")

        if consensus_count == 0:
            lines.append("*暂无可用摘要。请先对以下资料执行 kb-auto-digester 消化。*")
            lines.append("")
            for idx, item in enumerate(items, 1):
                lines.append(f"- [{idx}] {item['title'][:60]}")
        lines.append("")

    # ═══ 二、分歧与互补 ═══
    lines.append("## 二、分歧与互补")
    lines.append("")

    if depth == "L1":
        lines.append("> L1 深度不执行交叉比对。升级到 L2 或 L3 可获得此分析。")
    elif cards_available >= 2 or depth == "L3":
        lines.append("| 角度 | 来源A观点 | 来源B观点 | 综合判断 |")
        lines.append("|------|----------|----------|---------|")
        if tools:
            lines.append(f"| 工具选择 | 各资料推荐的工具不同 | 详见「可执行方案」 | 根据场景选择 |")
        if c["form"] == "contrast":
            lines.append("| 方法论 | 见来源核心观点 | 见来源核心观点 | AI 待分析 |")
        if depth == "L3" and items_need_fetch:
            lines.append("| 深度对比 | 需 fetch 原文 | 见上方 L3 待 fetch 列表 | 待交叉验证 |")
        lines.append("")
        if depth != "L3":
            lines.append("> 💡 如需深入对比，请使用 L3 深度重新合成。")
    else:
        lines.append(f"*仅 {cards_available} 条有知识卡片，不足以做交叉对比。*")
    lines.append("")

    # ═══ 三、可执行方案 ═══
    lines.append("## 三、可执行方案")
    lines.append("")
    lines.append(f"**形态**：{form_cn}")
    lines.append("")

    if depth == "L1":
        lines.append("> L1 深度 — 仅输出方案框架，具体内容需升级深度。")
        lines.append("")
    elif depth == "L3":
        lines.append("> L3 深度 — 基于全部可用卡片做详细填充。")
        lines.append("")

    if form == "contrast":
        dims = []
        suggestions = []
        if tools:
            for i, tool in enumerate(tools[:3]):
                dims.append(f"| 使用 {tool} | 方案{i+1}详情 | 方案{i+2 if i+2 <= len(tools) else 1}详情 | AI待分析 |")
            suggestions.append("- 如需快速上手，选工具链最简的方案")
            suggestions.append("- 如需深度定制，选灵活性最高的方案")

        section_text = section_template.format(
            dimensions="\n".join(dims) if dims else "| 待分析 | - | - | - |",
            suggestions="\n".join(suggestions) if suggestions else "- AI 待分析",
        )
    elif form == "flow":
        steps = []
        for idx, item in enumerate(items, 1):
            title = item.get("title", "")[:40]
            steps.append(f"| {idx} | 从「{title}」提取步骤 | 详见原文 | [{idx}] |")
        section_text = section_template.format(steps="\n".join(steps) if steps else "| 1 | 待分析 | - | - |")
    elif form == "map":
        map_tree_lines = [f"{c['label']}"]
        for idx, item in enumerate(items, 1):
            map_tree_lines.append(f"├── {item['title'][:40]}")
        map_tree = "\n".join(map_tree_lines)
        map_details = "\n".join(
            f"- **[{idx}]** {item['title'][:60]}" for idx, item in enumerate(items, 1)
        )
        section_text = section_template.format(map_tree=map_tree, map_details=map_details)
    elif form == "decision":
        tree_lines = [f"{c['label']} 决策树"]
        for idx, item in enumerate(items, 1):
            tree_lines.append(f"├── 路径{idx}: {item['title'][:40]}?")
        tree = "\n".join(tree_lines)
        options = "\n".join(
            f"| 方案{idx} | {item['title'][:30]} | - | - | [{idx}] |"
            for idx, item in enumerate(items, 1)
        )
        section_text = section_template.format(tree=tree, options=options)
    else:  # cheatsheet
        rows = "\n".join(
            f"| {item['title'][:30]} | {item.get('summary', '')[:40]} | - | [{idx}] |"
            for idx, item in enumerate(items, 1)
        )
        section_text = section_template.format(rows=rows if rows else "| 待分析 | - | - | - |")

    lines.append(section_text)
    lines.append("")

    # ═══ 四、注意事项 ═══
    lines.append("## 四、注意事项")
    lines.append("")

    if depth == "L1":
        lines.append("> L1 深度不执行风险提取。升级到 L2 或 L3 可获得此分析。")
        if tools:
            lines.append(f"- 涉及工具：{'、'.join(tools[:5])} — 注意版本兼容性")
    else:
        lines.append("> 从各资料中识别到的共性约束与风险。")
        lines.append("")
        risk_count = 0
        for idx, item in enumerate(items, 1):
            title = item.get("title", "")
            card = card_cache.get(title.strip())
            if card:
                sections = extract_sections(card)
                for k in ["注意点", "注意事项", "工具与参数"]:
                    if k in sections:
                        content = sections[k][:150]
                        lines.append(f"- **来自 [{idx}]**：{content}")
                        risk_count += 1
                        break
        if risk_count == 0:
            lines.append("- *资料中未提取到明确的注意事项。建议消化为知识卡片后补充。*")
        if tools:
            lines.append(f"- 涉及工具：{'、'.join(tools[:5])} — 注意版本兼容性和 API 变更风险")
    lines.append("")

    # ═══ 五、知识缺口 ═══
    lines.append("## 五、知识缺口")
    lines.append("")

    if depth == "L1":
        lines.append("> L1 深度不执行缺口分析。升级到 L2 或 L3 可获得此分析。")
    else:
        lines.append("> 这些资料在该主题下可能未覆盖的维度：")
        lines.append("")
        lines.append(f"- **系统性对比**：{'、'.join(tools[:3]) if tools else '各工具'}之间的端到端性能对比")
        lines.append("- **时间维度**：最新版本的更新内容和路线图")
        lines.append("- **中文适配**：在中国大陆网络环境下的可用性和替代方案")
        lines.append("- **成本核算**：各方案的实际使用成本（Token/API费用）")
        if depth == "L3":
            lines.append(f"- **交叉验证**：{'、'.join(tools[:3]) if tools else '各工具'}在不同场景下的表现差异（需 fetch 全文）")
    lines.append("")

    # ═══ 六、下一步建议 ═══
    lines.append("## 六、下一步建议")
    lines.append("")
    if depth == "L1":
        lines.append("1. 将此合成指南保存到笔记/知识库")
        lines.append("2. 升级到 L2 深度获得交叉验证分析")
        lines.append("3. 对重点条目执行 `kb-auto-digester` 消化")
    elif depth == "L2":
        lines.append("1. 将此合成指南保存到笔记/知识库")
        lines.append("2. 标记相关来源资料 `output_status` 为「已转化」（运行 `--confirm-conversion`）")
        lines.append("3. 根据「知识缺口」定向搜索补充资料")
        lines.append("4. 对需要深度对比的维度，使用 L3 深度重新合成")
    else:  # L3
        lines.append("1. 将此合成指南保存到笔记/知识库")
        lines.append("2. **优先 fetch 上方标记的待 fetch 资料**，补充全文后重新合成")
        lines.append("3. 标记相关来源资料 `output_status` 为「已转化」（运行 `--confirm-conversion`）")
        lines.append("4. 根据「知识缺口」定向搜索补充资料")
    lines.append("")

    # 附录
    lines.append("---")
    lines.append("")
    lines.append("## 附录：来源清单")
    lines.append("")
    lines.append("| # | 标题 | 知识库 | 等级 | 卡片 | 关键贡献 |")
    lines.append("|---|------|------|:--:|:--:|---------|")
    for idx, item in enumerate(items, 1):
        title = item["title"].replace("|", "｜")[:45]
        kb = item.get("kb_name", "")
        grade = item.get("grade", "?")
        has_card = "✅" if item.get("title", "").strip() in card_cache else "—"
        tools_in_item = extract_tools_from_items([item])
        contribution = f"涉及: {', '.join(tools_in_item[:2])}" if tools_in_item else "主题覆盖"
        # 构造跳转链接
        mid = item.get("media_id", "")
        kid = item.get("kb_id", "")
        if kid and mid:
            link = f"https://ima.qq.com/wiki/?shareId={kid}&mediaId={mid}&action=openDetailDrawer"
            title_cell = f"[{idx}]({link})"
        else:
            title_cell = str(idx)
        lines.append(f"| {title_cell} | {title} | {kb} | {grade} | {has_card} | {contribution} |")

    return "\n".join(lines)


# ── 状态回写 (P0-3) ──

def finalize_synthesis(clusters_path, data_path):
    """将参与合成的资料标记为 output_status='已转化'。"""
    with open(clusters_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    clusters = data.get("clusters", [])

    # 收集所有参与合成的条目 title
    synthesized_titles = set()
    for c in clusters:
        for item in c.get("items", []):
            synthesized_titles.add(item.get("title", "").strip())

    if not synthesized_titles:
        log.warning("⚠️ 未找到需要更新状态的条目。")
        return

    with open(data_path, "r", encoding="utf-8") as f:
        processed = json.load(f)

    updated = 0
    skipped = 0
    for item in processed:
        title = item.get("title", "").strip()
        if title in synthesized_titles:
            old_status = item.get("output_status", item.get("status", ""))
            if old_status == "已转化":
                skipped += 1
                continue
            item["output_status"] = "已转化"
            updated += 1

    with open(data_path, "w", encoding="utf-8") as f:
        json.dump(processed, f, ensure_ascii=False, indent=2)

    log.success(f"✅ 已更新 {updated} 条 → output_status: 已转化")
    if skipped:
        log.info(f"   {skipped} 条已处于「已转化」状态，跳过")
    log.info(f"📊 共 {len(synthesized_titles)} 条参与合成")

    # 生成转化确认文件
    today = datetime.now().strftime("%Y-%m-%d")
    confirm_path = os.path.join(
        os.path.dirname(clusters_path),
        "_conversion_log.md"
    )
    with open(confirm_path, "w", encoding="utf-8") as f:
        f.write(f"# 转化记录 — {today}\n\n")
        f.write(f"- 合成 cluster 数: {len(clusters)}\n")
        f.write(f"- 标记「已转化」: {updated} 条\n\n")
        f.write("## 涉及资料\n\n")
        for c in clusters:
            f.write(f"### {c['label']} ({c['form']})\n")
            for idx, item in enumerate(c.get("items", []), 1):
                f.write(f"- [{idx}] {item['title'][:80]}\n")
            f.write("\n")
    log.info(f"📁 转化日志: {confirm_path}")


# ── 主入口 ──

def main():
    args = sys.argv[1:]

    # P0-3: 状态回写模式
    if "--confirm-conversion" in args:
        clusters_path = args[args.index("--clusters") + 1]
        data_path = args[args.index("--data") + 1]
        finalize_synthesis(clusters_path, data_path)
        return

    # P0-2: 合成输出模式
    clusters_path = args[args.index("--clusters") + 1]
    output_dir = args[args.index("--output-dir") + 1]
    cards_dir_idx = args.index("--cards-dir") if "--cards-dir" in args else -1
    cards_dir = args[cards_dir_idx + 1] if cards_dir_idx >= 0 else "./knowledge_cards"
    generate = "--generate-files" in args
    depth_override = args[args.index("--depth-override") + 1] if "--depth-override" in args else None

    with open(clusters_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    clusters = data.get("clusters", [])
    today = datetime.now().strftime("%Y-%m-%d")
    total = len(clusters)

    if depth_override:
        for c in clusters:
            c["depth"] = depth_override

    # 预加载所有知识卡片
    card_cache = {}
    if os.path.isdir(cards_dir):
        for fn in os.listdir(cards_dir):
            if fn.endswith(".md") and not fn.startswith("_"):
                fpath = os.path.join(cards_dir, fn)
                try:
                    with open(fpath, "r", encoding="utf-8") as f:
                        first_line = f.readline().strip()
                    card_title = re.sub(r'^#\s*[📝📖]\s*', '', first_line).strip()
                    # 不在此处加载完整内容，延迟到使用时
                    card_cache[card_title] = fpath
                except Exception:
                    continue

    # 转为 {title: content} 映射供 build_output 使用（模糊匹配）
    card_content_cache = {}
    card_titles_list = []  # [(normalized_title, original_title, content)]
    if generate:
        log.info("📖 预加载知识卡片...")
        for title, fpath in card_cache.items():
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    content = f.read()
                # 同时用标准化的标题做 key（去后缀、去标点差异）
                normalized = re.sub(r'[\.。，,、\s\-_（）\(\)\[\]【】\?？!！:：;；\'\"]+', '', title.lower())[:80]
                card_titles_list.append((normalized, title, content))
            except Exception:
                continue
        # 预建查找映射：对每个 cluster item，尝试模糊匹配
        all_item_titles = set()
        for c in clusters:
            for item in c.get("items", []):
                all_item_titles.add(item.get("title", "").strip())
        for item_title in all_item_titles:
            item_normalized = re.sub(r'[\.。，,、\s\-_（）\(\)\[\]【】\?？!！:：;；\'\"]+', '', item_title.lower())[:80]
            for card_norm, card_orig, card_cont in card_titles_list:
                # 精确匹配或前缀匹配
                if card_norm == item_normalized or (
                    len(card_norm) >= 20 and len(item_normalized) >= 20 and
                    (card_norm[:60] == item_normalized[:60] or card_norm in item_normalized or item_normalized in card_norm)
                ):
                    card_content_cache[item_title] = card_cont
                    break
        log.info(f"   已加载 {len(card_titles_list)} 张卡片，匹配 {len(card_content_cache)} 条")

    if generate:
        os.makedirs(output_dir, exist_ok=True)
        generated = 0
        for c in clusters:
            safe_label = "".join(
                ch for ch in c["label"].replace(" ", "_").replace("/", "-")[:30]
                if ch.isalnum() or ch in "_-"
            )
            form_cn = FORM_NAMES.get(c["form"], "速查")
            filename = f"synth_{c['id']}_{safe_label}_{form_cn}.md"
            filepath = os.path.join(output_dir, filename)

            content = build_output(c, today, cards_dir, card_content_cache)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)
            generated += 1

            cards_count = sum(
                1 for item in c["items"]
                if item.get("title", "").strip() in card_content_cache
            )
            log.success(f"  ✅ [{c['form']}] {c['label']} ({c['item_count']}条, {cards_count}张卡片) → {filename}")

        log.success(f"\n✅ 已生成 {generated} 份合成指南 → {output_dir}/")
    else:
        log.info(f"📊 共 {total} 个可合成主题。使用 --generate-files 生成文件。")
        for c in clusters:
            cards_count = sum(
                1 for item in c["items"]
                if item.get("title", "").strip() in card_cache
            )
            log.info(f"  [{c['form']:12s}] {c['label'][:30]} ({c['item_count']}条, {cards_count}张卡片)")

    # 统计
    form_dist = Counter(c["form"] for c in clusters)
    log.info(f"\n形态分布:")
    for f, count in form_dist.most_common():
        log.info(f"  {FORM_NAMES.get(f, f)}: {count}个")


if __name__ == "__main__":
    main()
