---
name: skillhub-skill-s-k-005
description: "跨资料智能合成。当用户说\"合成资料\"、\"合并分析\"、\"对比这几篇\"、\"做一个主题指南\"、\"这个领域我收藏了哪些\"、\"帮我整合XX相关的内容\"时触发。基于知识卡片摘要进行聚类→形态匹配→逐层合成，输出方法论指南/对比分析/知识地图/决策框架/速查表等结构化内容。支持从 kb-reviewer 复盘报告中自动提取高频关键词触发合成。不适用于单篇精读、逐条制作卡片。"
---

# 跨资料智能合成 Skill

## 概述

将多条已消化的知识卡片（来自 kb-auto-digester）或原始 A 类资料，按主题/标签/工具自动聚类，智能判断合成形态，逐层合并为可执行的结构化指南。

**核心价值**：从离散的「收藏」到收敛的「决策」——把多篇资料中的共识、分歧、操作步骤整合成一份能直接使用的结果。

**设计原则**：输入不绑定字段名，聚类不依赖特定分级，输出结构通用化——可适配 IMA、Obsidian、Notion 等任意知识管理系统。

---

## 输入要求

任意 JSON 数组，每条至少包含：

| 字段 | 必填 | 说明 |
|------|:--:|------|
| `title` | ✅ | 资料标题 |
| `theme` | 推荐 | 主题分类（用于聚类） |
| `grade` | 推荐 | A/B/C 等级 |
| `tags` | 可选 | 标签列表 |
| `summary` | 可选 | 摘要/一句话价值 |
| `media_id` | 可选 | 用于 fetch 原文 |

**内置适配器**：默认读取 `processed_kb_items_latest.json`（kb-inventory-update 输出），自动提取 `value` 字段作为摘要。

---

## 工作流程

```
Phase 1: 聚类 → Phase 2: 形态匹配 → Phase 3: 逐层合成 → Phase 4: 输出
```

### Phase 1：聚类引擎

```bash
python3 scripts/cluster.py \
    --input processed_kb_items_latest.json \
    --output synthesis_clusters.json \
    [--min-items 2] \
    [--focus "Codex"] \
    [--depth L2]
```

**聚类规则**（按优先级）：

| 规则 | 触发条件 | 权重 |
|------|---------|:--:|
| 同主题分组 | `theme` 相同 | 基础 |
| 同工具分组 | 标题共享工具关键词（Codex/Seedance/GPT-Image 等） | +2 |
| 标签共现 | 相同二级标签 | +1 |
| 用户指定 | `--focus "关键词"` | 过滤 |

输出 `synthesis_clusters.json`，每个 cluster 包含：主题名、成员列表、摘要集合、推荐合成形态、推荐深度。

### Phase 2：形态匹配器

聚类引擎内置形态匹配，根据 cluster 特征自动决策：

```
if 同一工具名出现在 ≥2 条 
   AND 各自说的是不同方法:
    → "对比分析"
    → 输出: 工具X的N种用法对比

elif 资料中包含步骤关键词 (步骤/流程/如何做/教程/保姆级):
    → "流程指南"
    → 输出: 统一操作SOP

elif 同一主题 ≥3 条，各覆盖不同侧面:
    → "知识地图"
    → 输出: 主题X全景图

elif 资料中包含选择/取舍关键词 (选哪个/vs/对比/推荐):
    → "决策框架"
    → 输出: 如何选择X

else:
    → "速查表"
    → 输出: 关键信息速查
```

### Phase 3：逐层合成（AI 驱动）

根据推荐的合成形态和深度，AI 按以下逻辑处理：

#### L1（摘要合并，默认）

1. 读取 cluster 中每条资料的摘要（知识卡片优先，其次 value 字段）
2. 提取公共主题 + 去重
3. 按形态模板组织输出
4. 标记来源追溯

#### L2（交叉验证，`--depth L2`）

L1 的全部内容 +：
1. 对每条资料 fetch 关键段落（标题搜索 + 摘要相关段落）
2. 横向对比：标记分歧点（不同来源说不同的话）
3. 标记知识缺口（这些资料都没说清楚的地方）
4. 标注时效性（是否基于过时工具/版本）

#### L3（全本重构，`--depth L3`）

L2 全部内容 +：
1. fetch 每条资料的完整原文
2. 全文交叉对比
3. 引用原文关键段落
4. 需要 --top 限制（超过 5 条时强制降为 L2）

### Phase 4：输出

```bash
python3 scripts/synthesize.py \
    --clusters synthesis_clusters.json \
    --output-dir synthesis_outputs/ \
    --generate-files
```

生成 Markdown 文件，每 cluster 一份。自动执行 `mark_digested` 更新消化记录。

---

## 通用输出结构

```markdown
# 合成指南：{主题名}

**合成类型**：{对比分析/流程指南/知识地图/决策框架/速查表}
**深度**：L1/L2/L3
**来源材料**：{n}条 | 覆盖 {m}个知识库
**更新时间**：{YYYY-MM-DD}

## 一、核心共识
{n条来源一致的共同观点，每条标注来源编号}

## 二、分歧与互补
| 角度 | 来源A | 来源B | 综合判断 |
|------|------|------|---------|

## 三、可执行方案
{按形态展开 - 见下方各形态章节}

## 四、注意事项（跨来源共性风险）

## 五、知识缺口（未被覆盖的内容）

## 附录：来源清单
| # | 标题 | 知识库 | 关键贡献 |
|---|------|--------|---------|
```

### 输出形态详情

#### 对比分析
「三」结构：工具/方法对比表（维度 × 来源 × 推荐场景）+ 选择建议

#### 流程指南
「三」结构：统一操作步骤（Step 1→N），合并去重，标注每个步骤来自哪些来源

#### 知识地图
「三」结构：子话题树 `Topic → Sub-topic → 核心要点 → 参考来源编号`

#### 决策框架
「三」结构：决策树（`条件A? → Y:方案1 / N: ...`）

#### 速查表
「三」结构：提取型表格 `名称 | 参数 | 适用场景 | 来源编号`

---

## 触发方式

| 触发 | 用户说 | 执行 |
|------|-------|------|
| 自动检测 | 「合成资料」「看看有什么可合成的」 | 扫描所有 cluster，列出推荐 |
| 按主题 | 「合成 Codex 相关的」 | --focus "Codex" |
| 按标签 | 「合成 Seedance 教程」 | --focus "Seedance" --tag 教程 |

---

## 复盘信号触发合成（`--from-review`）

当 kb-reviewer 的 Q2 关键词趋势分析发现高频关键词（≥3 张卡片）时，可自动触发合成：

```bash
python3 scripts/cluster.py \
    --input processed_kb_items_latest.json \
    --output synthesis_clusters.json \
    --focus "{高频关键词}" \
    --depth L2
```

**触发流程**：
```
kb-reviewer → Q2报告"notebooklm 覆盖5张卡片" → 用户说"合成NotebookLM" → 自动执行
```

## 合成后回写

合成完成后，自动更新 `processed_kb_items_latest.json` 中涉及资料的产出状态：

```bash
python3 scripts/synthesize.py \
    --clusters synthesis_clusters.json \
    --output-dir synthesis_outputs/ \
    --confirm-conversion
```

`--confirm-conversion` 将已合成资料的 `output_status` 从「已提炼」升级为「已转化」。

## 技能链位置

```
kb-inventory-update（采集+分级）
    ↓ processed_kb_items_latest.json
kb-auto-digester（消化→卡片+模板）
    ↓ knowledge_cards/
kb-linker（自动关联）
    ↓ 关联后的卡片网络
kb-synthesizer（跨卡合成）  ← 当前技能
    ↓ synthesis_outputs/
kb-reviewer（复盘+健康检查）→ 发现高频词 → 反馈触发新一轮合成
```

不替代任何现有技能，吃前四者的产出做更高层合成，同时被 kb-reviewer 的发现反哺。

---

## 资源目录

### scripts/
- `cluster.py` — 聚类引擎 + 形态匹配器
- `synthesize.py` — 合成引擎（读取 cluster → 按模板输出）

### templates/
- `synthesis_output.md` — 通用输出结构模板
