---
name: skillhub-skill-bili-main-ad
description: "当用户想按 B 站「广告」分区定位子分区、核对 BV 号与播放数据时使用。本包只提供分区结构与结构化元数据，不提供视频口播内容，也不转载第三方视频标题与昵称。触发词：广告、B站分区、rid 165。"
---

# B 站分区 · 广告

- 一级分区 rid：`165`；网页路由：`/v/ad/`
- 采集时间：2026-11-08T00:35:38+08:00
- 状态：主排行榜接口返回 `code=-400`，最新投稿接口返回 0 条，二级榜接口亦返回 `code=-400`；本包如实标注该分区已无可用投稿，不推断、不补造分区内容。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 广告（已下线） | — | — | 166 |

「主榜条目」一列标记 `—`，因为本分区不参与主榜；实际条目数请查「二级榜条目」列与 `data/subzone_ranking.json`。

## 用法

1. 用户的问题落到某个子分区时，先在上表定位该子分区，再按 BV 号打开原视频核实。
2. 用户需要别的分区时，请转总控 skill `bili-full-map` 查全站路由。
3. 用户需要视频里的具体讲解、论证或方法时，本包给不了，请转 `video-distill` 取字幕或转写。

## 数据来源与提炼方式

1. 主榜 `/x/web-interface/ranking/v2?rid=165&type=all` 返回 `code=-400`，因此本包不使用主榜。
2. 现行子分区名称来自最新投稿接口 `/x/web-interface/newlist?rid=165&pn={pn}&ps=50` 返回的 `tname` 与 `tid`，最多采样 3 页。
3. 二级分区条目来自 `/x/web-interface/ranking/region?rid={tid}&day=7`，按社区分区表里的 tid 逐个请求。
4. 社区分区表只提供 tid 与历史条目对照；本包不把历史条目当作现行分区。
5. 完整对照见 `references/subzones.md`，结构化数据见 `data/ranking.json` 与 `data/subzone_ranking.json`。

## 数据边界

1. 公开接口只返回元数据，本包不含视频口播、字幕或章节大纲。
2. 最新投稿与 7 日榜都是采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 用户引用任何视频时须给出 BV 号链接与采集日期。
4. 回答须区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。
5. 本包不虚构 UP 主、不虚构视频标题、不虚构播放数据。

## 合规说明（v1.2.0 起）

`data/ranking.json` 与 `data/subzone_ranking.json` 只保留 BV 号、子分区、tid、播放量、时长与发布时间；`title`、`author`、`desc` 及 UP 主昵称已移除。原始完整快照保存在工作区 `bili_all_zones/data/`，不随本包发布。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 8 Nov. 2026.

Bilibili. "分区最新投稿接口 /x/web-interface/newlist." https://api.bilibili.com/x/web-interface/newlist?rid=165&pn=1&ps=50. Accessed 8 Nov. 2026.

Bilibili. "二级分区排行榜接口 /x/web-interface/ranking/region." https://api.bilibili.com/x/web-interface/ranking/region?rid=166&day=7. Accessed 8 Nov. 2026.
