#!/usr/bin/env python3
"""Build self-contained Chinese research slides from agent-prepared evidence."""

import argparse
import base64
import html
import json
from pathlib import Path
import sys

THEMES = ("clinical", "editorial", "dark")
MIMES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
TEMPLATE = Path(__file__).resolve().parent.parent / "assets" / "academic_deck.html"


def text(value):
    if not isinstance(value, str):
        raise ValueError("标题、说明、备注和来源必须是字符串")
    return html.escape(value, quote=True)


def figure_data(path_text, base):
    if not isinstance(path_text, str) or not path_text or "://" in path_text:
        raise ValueError("图表必须是可读取的本地文件路径")
    path = Path(path_text).expanduser()
    if not path.is_absolute():
        path = base / path
    mime = MIMES.get(path.suffix.lower())
    if mime is None:
        raise ValueError(f"不支持的图像类型：{path.suffix}")
    return f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode('ascii')}"


def render(data, base, theme=None, one_slide=False):
    if not isinstance(data, dict) or not isinstance(data.get("slides"), list) or not data["slides"]:
        raise ValueError("输入需要包含非空 slides 数组")
    title = data.get("title", "文献汇报")
    text(title)
    selected_theme = theme or data.get("theme", "clinical")
    if selected_theme not in THEMES:
        raise ValueError("theme 必须为 clinical、editorial 或 dark")
    slides = data["slides"]
    if one_slide:
        slides = [next((slide for slide in slides if isinstance(slide, dict) and slide.get("figure")), slides[0])]
    rendered = []
    for index, slide in enumerate(slides):
        if not isinstance(slide, dict) or not isinstance(slide.get("title"), str) or not slide["title"].strip():
            raise ValueError(f"第 {index + 1} 页缺少标题")
        bullets = slide.get("bullets", [])
        if not isinstance(bullets, list) or any(not isinstance(item, str) for item in bullets):
            raise ValueError(f"第 {index + 1} 页 bullets 必须是字符串数组")
        title_html = text(slide["title"])
        bullets_html = "".join(f"<li>{text(item)}</li>" for item in bullets)
        notes_html = text(slide.get("notes", ""))
        source_html = text(slide.get("source", ""))
        figure = slide.get("figure")
        if figure:
            fig_caption = text(slide.get("figure_caption", ""))
            src = figure_data(figure, base)
            fig_html = f'<figure><img src="{src}" alt="{fig_caption or title_html}"><figcaption>{fig_caption}</figcaption></figure>'
        else:
            fig_html = ""
        rendered.append(
            f'<section class="slide{" active" if index == 0 else ""}" aria-label="第 {index + 1} 页" '
            f'aria-hidden="{"false" if index == 0 else "true"}" data-notes="{notes_html}">'
            f'<header><h1>{title_html}</h1></header><div class="content {"with-figure" if figure else "text-only"}">'
            f'<div class="text"><ul>{bullets_html}</ul></div>{fig_html}</div>'
            f'<footer>{source_html}</footer></section>'
        )
    template = TEMPLATE.read_text(encoding="utf-8")
    return template.replace("{{DECK_TITLE}}", text(title)).replace("{{THEME}}", selected_theme).replace("{{SLIDES}}", "\n".join(rendered))


def main():
    parser = argparse.ArgumentParser(description="生成逐页播放的 HTML 文献汇报")
    parser.add_argument("--input", required=True, type=Path)
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--output", type=Path)
    target.add_argument("--previews", type=Path)
    parser.add_argument("--theme", choices=THEMES)
    parser.add_argument("--force", action="store_true", help="明确允许覆盖已存在的输出")
    args = parser.parse_args()
    try:
        input_path = args.input.expanduser().resolve()
        with input_path.open("r", encoding="utf-8") as stream:
            data = json.load(stream)
        if args.output:
            if args.output.expanduser().resolve() == input_path:
                raise ValueError("输出路径不能与输入 JSON 相同")
            content = render(data, input_path.parent, theme=args.theme)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            with args.output.open("w" if args.force else "x", encoding="utf-8") as stream:
                stream.write(content)
            print(f"已生成：{args.output}")
        else:
            args.previews.mkdir(parents=True, exist_ok=True)
            outputs = [args.previews / f"{theme}.html" for theme in THEMES]
            if input_path in [output.expanduser().resolve() for output in outputs]:
                raise ValueError("预览输出不能覆盖输入 JSON")
            if not args.force and any(output.exists() for output in outputs):
                raise ValueError("预览输出已存在；请选择新目录或明确使用 --force")
            for theme in THEMES:
                output = args.previews / f"{theme}.html"
                content = render(data, input_path.parent, theme=theme, one_slide=True)
                with output.open("w" if args.force else "x", encoding="utf-8") as stream:
                    stream.write(content)
                print(f"样页：{output}")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"无法生成 HTML：{exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
