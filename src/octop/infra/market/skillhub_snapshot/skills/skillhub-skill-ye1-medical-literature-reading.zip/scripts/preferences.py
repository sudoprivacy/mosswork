#!/usr/bin/env python3
"""Persist only explicitly chosen literature-reading presentation preferences."""

import argparse
import json
import math
import os
from pathlib import Path
import sys
import tempfile


def default_path():
    root = os.environ.get("APPDATA") if os.name == "nt" else os.environ.get("XDG_CONFIG_HOME")
    return Path(root).expanduser() / "ye1-medical-literature" / "preferences.json" if root else Path.home() / ".config" / "ye1-medical-literature" / "preferences.json"


def positive_minutes(value):
    try:
        value = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("时长须为正数") from exc
    if not math.isfinite(value) or value <= 0:
        raise argparse.ArgumentTypeError("时长须为有限的正数")
    return int(value) if value.is_integer() else value


def load(path):
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as stream:
        value = json.load(stream)
    if not isinstance(value, dict) or any(k not in {"reading_format", "presentation_format", "minutes", "style"} for k in value):
        raise ValueError("偏好文件格式不受支持；保留原文件，请先检查。")
    if value.get("reading_format") not in (None, "chat", "pdf") or value.get("presentation_format") not in (None, "pptx", "html") or value.get("style") not in (None, "ordinary", "polished"):
        raise ValueError("偏好值不受支持；保留原文件，请先检查。")
    minutes = value.get("minutes")
    if minutes is not None and (isinstance(minutes, bool) or not isinstance(minutes, (int, float)) or not math.isfinite(minutes) or minutes <= 0):
        raise ValueError("偏好时长无效；保留原文件，请先检查。")
    return value


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".preferences-", suffix=".json", dir=path.parent)
    try:
        if hasattr(os, "fchmod"):
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def main():
    parser = argparse.ArgumentParser(description="保存医生明确要求记住的阅读和汇报习惯")
    sub = parser.add_subparsers(dest="action", required=True)
    get = sub.add_parser("get")
    set_command = sub.add_parser("set")
    clear = sub.add_parser("clear")
    for command in (get, set_command, clear):
        command.add_argument("--path", type=Path, default=default_path(), help="隔离测试或宿主明确指定的偏好文件")
    set_command.add_argument("--reading-format", choices=("chat", "pdf"))
    set_command.add_argument("--presentation-format", choices=("pptx", "html"))
    set_command.add_argument("--minutes", type=positive_minutes)
    set_command.add_argument("--style", choices=("ordinary", "polished"))
    clear.add_argument("--field", choices=("reading_format", "presentation_format", "minutes", "style", "all"), required=True)
    args = parser.parse_args()
    try:
        value = load(args.path.expanduser())
        if args.action == "set":
            changes = {name: getattr(args, name) for name in ("reading_format", "presentation_format", "minutes", "style") if getattr(args, name) is not None}
            if not changes:
                parser.error("至少指定一项明确习惯")
            value.update(changes)
            save(args.path.expanduser(), value)
        elif args.action == "clear":
            if args.field == "all":
                value = {}
            else:
                value.pop(args.field, None)
            save(args.path.expanduser(), value)
        print(json.dumps(value, ensure_ascii=False, sort_keys=True))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"偏好不可用：{exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
