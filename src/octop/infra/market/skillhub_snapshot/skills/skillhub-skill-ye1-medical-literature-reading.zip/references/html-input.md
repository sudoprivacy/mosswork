# 网页幻灯片输入

`build_html.py` 读取 UTF-8 JSON，生成独立 HTML，不请求外部字体、脚本或图片。图必须是有权使用且事先核对的本地 PNG、JPEG 或 WebP；小文件以内嵌形式打包进 HTML。浏览器可离线打开，备注默认隐藏，按 `N` 或点击“讲者备注”切换；箭头键、空格及按钮翻页，`F` 尝试全屏，`Home`/`End` 跳页。打印时按页输出，备注默认不打印。

```json
{
  "title": "文献汇报标题",
  "theme": "clinical",
  "slides": [
    {"title": "文章研究了什么", "bullets": ["研究问题与对象", "主要发现"],
     "notes": "口头讲解要点。", "source": "作者，期刊，年份，DOI"},
    {"title": "关键结果", "bullets": ["真实结果及条件"],
     "figure": "figures/figure1.jpg", "figure_caption": "图 1：图表解释",
     "notes": "本页讲述和限制。", "source": "原论文 Fig. 1"}
  ]
}
```

`figure` 相对于 JSON 文件所在目录，或为绝对本地路径；不下载远端 URL。`--theme` 可覆盖 JSON 的 `theme`。`--previews DIR` 输出三种真实 HTML 样页，默认取首张含图的页面，用户选择后需另行生成完整作品。默认不覆盖已有输出，确实需要重做时指定新文件或明确使用 `--force`。构建器只负责排版和交互，不检查医学事实、报告时长、版权或图表是否准确；Agent 必须核查并实际浏览。
