# 阅读与汇报习惯

本会话里的明确要求立即生效；一次“这次用 PDF / 讲 20 分钟”不是永久偏好。用户说“以后默认”“我一般用”等明确长期习惯，可保存输出、汇报格式、常用时长和视觉风格；明确的本次要求总是覆盖保存值。未保存任何习惯时，不声称“已经记住”。

优先使用宿主已提供且可用的用户偏好能力。无此能力但有本地 Python 时：

```bash
python "<skill-dir>/scripts/preferences.py" get
python "<skill-dir>/scripts/preferences.py" set --reading-format pdf --presentation-format pptx --minutes 15 --style ordinary
python "<skill-dir>/scripts/preferences.py" clear --field minutes
```

只传用户确实要求保存的字段；其余字段原样保留。支持 `reading-format` 为 `chat` / `pdf`，`presentation-format` 为 `pptx` / `html`，`minutes` 为大于 0 的分钟数，`style` 为 `ordinary` / `polished`。`get` 在无偏好时返回空对象。默认用户配置目录下 `ye1-medical-literature/preferences.json`；测试用 `--path <隔离文件>`。不存文献、姓名、医院、账号、令牌或患者资料。

文件写不进去或用户所在环境不允许持久化时，仍完成本次任务，告诉用户下次可能需要重新说明；本机文件不代表跨电脑、跨应用自动同步。用户更改或清除习惯时按其要求更新。
