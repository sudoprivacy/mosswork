// B站「发图文」按需求写稿后的一键发布+核验编排（技能内部工具）
// 流程：前置检查(Chrome9222 + B站登录,含冻结标签唤醒) → 逐篇调 _bili_one.mjs 发布 → 回读核验 → 三段式汇总
// 用法: node bili_publish.mjs <base1> [<base2> ...]
//   base = TogetherIntoFamous/generated 下的源稿文件名（不含 .html），即 <学科>_<主题>
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const ROOT = 'C:/Users/chenl/WorkBuddy/Claw';
const NODE = process.execPath;
const LOG = path.join(ROOT, 'xhs_notes/published_log_bili.json');

const run = (cmd, args, timeout = 420000) => new Promise((res) => {
  const cp = spawn(cmd, args, { cwd: ROOT, windowsHide: true });
  let out = '';
  cp.stdout.on('data', d => { out += d; });
  cp.stderr.on('data', d => { out += d; });
  let killed = false;
  const to = setTimeout(() => { killed = true; try { cp.kill('SIGKILL'); } catch {} }, timeout);
  cp.on('error', e => { clearTimeout(to); res({ code: -1, out: out + 'SPAWN_ERR:' + (e.code || e) }); });
  cp.on('close', c => { clearTimeout(to); res({ code: killed ? -1 : c, out }); });
});
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function preChrome() {
  try {
    const r = await fetch('http://127.0.0.1:9222/json/version');
    const t = await r.text();
    return t.trim().startsWith('{');
  } catch { return false; }
}

async function getTabs() {
  try {
    const r = await fetch('http://127.0.0.1:9222/json');
    return await r.json();
  } catch { return []; }
}

async function ensureLogin() {
  // 第一次 nav 探测
  let nav = await run(NODE, [path.join(ROOT, '_bili_nav_check.mjs')], 25000);
  if (/isLogin["']?\s*:\s*true/.test(nav.out) && /"code"\s*:\s*0/.test(nav.out)) return nav.out.trim();

  const noTab = /NO_BILI_TAB/.test(nav.out);
  if (noTab) {
    // 无 bilibili 标签：新建一个再测
    try {
      await fetch('http://127.0.0.1:9222/json/new?' + encodeURIComponent('https://www.bilibili.com/'), { method: 'PUT' });
    } catch {}
    await sleep(3000);
    nav = await run(NODE, [path.join(ROOT, '_bili_nav_check.mjs')], 25000);
    if (/isLogin["']?\s*:\s*true/.test(nav.out) && /"code"\s*:\s*0/.test(nav.out)) return nav.out.trim();
    return null;
  }

  // timeout / 冻结：唤醒 bilibili 标签（bringToFront）后复测
  const tabs = await getTabs();
  const id = tabs.find(t => t.type === 'page' && t.url && t.url.includes('bilibili'))?.id;
  if (id) {
    await run(NODE, [path.join(ROOT, '_activate_tab.mjs'), id], 15000);
    await sleep(2500);
    nav = await run(NODE, [path.join(ROOT, '_bili_nav_check.mjs')], 25000);
    if (/isLogin["']?\s*:\s*true/.test(nav.out) && /"code"\s*:\s*0/.test(nav.out)) return nav.out.trim();
    // 再试一次
    await run(NODE, [path.join(ROOT, '_activate_tab.mjs'), id], 15000);
    await sleep(2500);
    nav = await run(NODE, [path.join(ROOT, '_bili_nav_check.mjs')], 25000);
    if (/isLogin["']?\s*:\s*true/.test(nav.out) && /"code"\s*:\s*0/.test(nav.out)) return nav.out.trim();
  }
  return null;
}

async function main() {
  const bases = process.argv.slice(2);
  if (!bases.length) { console.log('USAGE: node bili_publish.mjs <base1> [<base2> ...]'); process.exit(1); }

  console.log('=== 前置检查 ===');
  if (!await preChrome()) {
    console.log('❌ Chrome 未开启远程调试端口（127.0.0.1:9222）。请先以 --remote-debugging-port=9222 打开已登录 B站的 Chrome 再试。');
    process.exit(2);
  }
  console.log('✅ Chrome 9222 端口正常');
  const navOk = await ensureLogin();
  if (!navOk) {
    console.log('❌ B站未登录或登录态失效（nav 探测未返回 code:0,isLogin:true）。请确认 Chrome 已登录 B站。最近一次 nav 输出：', navOk === null ? '(见上)' : '');
    process.exit(3);
  }
  console.log('✅ B站登录态有效：', navOk);

  const results = [];
  for (const base of bases) {
    const html = path.join(ROOT, 'TogetherIntoFamous/generated', base + '.html');
    if (!fs.existsSync(html)) { results.push({ base, ok: false, why: 'SRC_NOT_FOUND ' + html }); continue; }
    console.log(`\n===== 发布 ${base} =====`);
    const p = await run(NODE, [path.join(ROOT, '_bili_one.mjs'), base], 420000);
    const m = p.out.match(/PUBLISH_OK dyn_id=(\d+)/);
    const tail = p.out.split('\n').filter(l => /PUBLISH_|PREP_FAIL|COVER_FAIL|PUBLISH_FAILED|SEGMENTS/.test(l)).join(' | ');
    console.log(tail.slice(0, 400));
    if (!m) { results.push({ base, ok: false, why: 'PUBLISH_FAIL:' + (tail || p.code) }); continue; }
    const dyn = m[1];

    const probe = await run(NODE, [path.join(ROOT, '_bili_dyn_probe.mjs'), dyn], 30000);
    const page = await run(NODE, [path.join(ROOT, '_bili_check_page.mjs'), dyn], 30000);
    const opusLen = (probe.out.match(/opusTxtLen["']?\s*:\s*(\d+)/) || [])[1];
    const pics = (probe.out.match(/pics["']?\s*:\s*(\d+)/) || [])[1];
    const hasSeg = /hasSeg["']?\s*:\s*true/.test(probe.out);
    const segs = (page.out.match(/segs=([^\n|]+)/) || [])[1] || '';
    const hasAns = /hasAns\s*=\s*true/.test(page.out);
    const pageOk = hasAns && /本节概括/.test(segs) && /知识点精讲/.test(segs) && /真题解析/.test(segs);
    const probeOk = opusLen && opusLen !== '4' && Number(pics) >= 1 && hasSeg;
    const verdict = pageOk && (probe.out.trim() ? probeOk : true);
    console.log(`VERIFY dyn=${dyn} opusTxtLen=${opusLen} pics=${pics} hasSeg=${hasSeg} segs=${segs.trim()} hasAns=${hasAns} => ${verdict ? 'PASS' : 'FAIL'}`);
    const rec = { base, ok: verdict, dyn, opusLen };
    if (!verdict) rec.fix = `node ${path.join(ROOT, '_bili_one.mjs')} ${base} --edit ${dyn}`;
    results.push(rec);
  }

  const ok = results.filter(r => r.ok);
  console.log('\n===== SUMMARY =====');
  for (const r of results) {
    if (r.ok) console.log(`✅ ${r.base} (dyn=${r.dyn}, opusTxtLen=${r.opusLen})`);
    else console.log(`❌ ${r.base} ${r.why}` + (r.fix ? `\n   修复: ${r.fix}` : ''));
  }
  console.log(`TOTAL ok=${ok.length}/${results.length}`);
  const log = fs.existsSync(LOG) ? JSON.parse(fs.readFileSync(LOG, 'utf8')) : [];
  console.log('published_log 累计条数:', log.length);
  process.exit(ok.length ? 0 : 2);
}
main();
