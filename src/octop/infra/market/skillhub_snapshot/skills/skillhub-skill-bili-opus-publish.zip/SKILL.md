---
name: skillhub-skill-bili-opus-publish
description: "按用户要求自动撰写高中学习类图文并发布到已登录的 B站（发图文动态），以及修复/补稿。触发场景：用户说\"写一篇关于XX的B站图文并发布\"\"按需求发B站\"\"B站发图文\"\"B站动态发布\"\"bilibili opus\"\"B站候选稿不足/补稿/扩容\"。核心能力：用户给要求（学科/主题/数量）→ AI 写 HTML 源稿（四段式结构）→ 调脚本发图文 → 回读线上核验 → 三段式汇报。已解决：编辑器受控组件必须用 CDP 真实输入（execCommand 会丢正文）、必须新开干净 tab、发布校验线约 1000 字、四段式同构模板、原地编辑修复正文丢失。"
---

# B站「发图文」按需求写稿并自动发布

## 一句话流程
用户给要求（学科 / 主题 / 篇数）→ 你写 HTML 源稿 → 一键发布脚本 → 回读线上核验 → 三段式汇报。

所有脚本都在项目 `Claw`（`C:/Users/chenl/WorkBuddy/Claw`）。Node 用
`C:/Users/chenl/.workbuddy/binaries/node/versions/22.22.2-6/node.exe`
（若目录名变了，先 `ls C:/Users/chenl/.workbuddy/binaries/node/versions/` 取实际版本替换）。

---

## 0. 前置检查（任一失败即停，不要反复重试）
1. **Chrome 9222 端口**：`curl http://127.0.0.1:9222/json/version` 须返回 JSON。否则报
   「Chrome 未开启远程调试端口」并停止。
2. **B站登录态**：`node _bili_nav_check.mjs` 输出须含 `"code":0,"isLogin":true`。
   否则报「B站未登录」并停止（提示用户：开带 `--remote-debugging-port=9222` 的 Chrome 并登录 B站）。

---

## 1. 按用户要求写稿
- **保存位置**：`C:/Users/chenl/WorkBuddy/Claw/TogetherIntoFamous/generated/<学科>_<主题>.html`
- **文件名 = 学科位 + 主题**：
  - 学科位（二选一）：
    - 高考学科：`语文 数学 英语 物理 化学 生物 政治 历史 地理`
    - 学习类：`学习方法 学习规划 学习工具 学习心态`
  - 主题 ≤10 字（否则话题标签会被截断）。
  - 学科位决定**配色、标题年级前缀、话题标签**；主题决定**封面标题与标签词**。
- **HTML 结构严格照 `article_template.html`**（技能同目录有完整范例），要点：
  - `<title>` + `<h1>` 主标题；紧跟一个 `<p>` 副标题（含「高考真题拆解 / 专题训练 / 含近年」等关键词，或 ≤60 字）。
  - `<h2>一、知识点精讲</h2>`：首段为「导语」（≥40字、不以数字序号开头）；其后每条
    `<p><strong>N. 小标题：</strong>讲解…</p>`。
  - `<h2>二、高考真题分析</h2>`：每题一组 `<p>【真题1】题干+选项</p>` + `<p>解析：…</p>` + `<p>答案：…</p>`。
- **【真题解析】必须是完整一道题**（题干+选项+解析+答案）。若源稿本身没有真题，线上真题段会过薄 →
  发布后需在汇报里**点名提醒用户补稿**。
- **篇幅**：你写的源稿不必卡字数，`bili_opus_prep.py` 会自动压到 ≤985 字（含换行）。
- ⚠️ **学习类稿不要在标题/正文写 高一/高二/高三/必修/纲要**（会被误抓成标题年级前缀，变成「高三学习方法｜…」）。
  学科稿的 h1 写「高三数学」是正常的，会用作标题前缀。

---

## 2. 一键发布 + 核验
对每篇源稿的 `basename`（即文件名去掉 `.html`，形如 `数学_三角函数`）：

```bash
NODE=C:/Users/chenl/.workbuddy/binaries/node/versions/22.22.2-6/node.exe
$NODE bili_publish.mjs <base1> [<base2> ...]
```

`bili_publish.mjs`（技能同目录）会：前置检查 → 逐篇调 `_bili_one.mjs` 发布（prep→封面→发图文→写日志）
→ 对每篇 `dyn_id` 跑 `_bili_dyn_probe.mjs` + `_bili_check_page.mjs` 回读 → 打印 `VERIFY … => PASS/FAIL`
→ 末段 `SUMMARY` 汇总（✅标题+dyn_id+字数 / ❌原因+修复命令）+ `published_log 累计条数`。

**成功标志**：日志含 `PUBLISH_OK dyn_id=…`、`SEGMENTS 【本节概括】,【知识点精讲】,【真题解析】`、`LOG_WRITTEN total=N`。
**失败看**：`PREP_FAIL` / `COVER_FAIL` / `PUBLISH_FAILED` 及尾部日志。

> 想手动分步也行：`node _bili_one.mjs <base>` 发布单篇；
> `node _bili_dyn_probe.mjs <dyn_id>` 与 `node _bili_check_page.mjs <dyn_id>` 单独核验。

---

## 3. 回读核验判据（不可只看脚本返回码）
对每个 `dyn_id`：
- `opusTxtLen` 与稿件字数**同量级**，**不是 4**（4 = 只发了封面、正文丢失，线上只剩「分享图片」）。
- `pics ≥ 1`、`hasSeg: true`。
- `segs` 含完整三段 `【本节概括】,【知识点精讲】,【真题解析】`，且 `hasAns=true`（真题段有解析/答案）。

**若 `opusTxtLen:4` 正文丢失**：用原地编辑修复（**保留原发布时间与封面图**，不删重发）：
```bash
$NODE _bili_one.mjs <base> --edit <dyn_id>
```
⚠️ 每条动态**最多编辑 3 次**；提交后会弹「当前内容只能修改3次，确认要修改吗?」→ 点**「确认修改」**。

---

## 4. 汇报（三段式）
- **发生了什么**：本次接到的需求、选了哪些主题、前置检查结果。
- **结果**：逐篇 ✅ 标题 + dyn_id + 字数，或 ❌ 失败原因与关键日志行；`published_log` 累计条数、候选池剩余篇数。
- **下一步**：候选池剩余 < 6 篇 → 提醒「B站候选稿即将耗尽，需要补充稿件」；< 3 篇 → 按实际数量发布并提醒。

---

## 附 A：批量发候选池 / 补稿
- 批量发已存在但未发的候选：`node bili_opus_daily.mjs --count 3`（按 `published_log_bili.json` 去重，自动选前 N 篇）。
- 候选池会耗尽（每日 3 篇）。补稿不要手写 HTML：改 `TogetherIntoFamous/...` 源稿或 `_bili_new_articles.py` 的
  `ARTICLES` 列表后重跑生成器；改完跑一次 `node bili_opus_daily.mjs --count 3 --dry` 确认 `CANDIDATES total` 增长。

---

## 附 B：四个必踩的坑（已解决，勿回退）
1. **正文丢失（最致命）**：编辑器是**受控组件**，`execCommand('insertHTML')`/`innerHTML=` 改 DOM 会导致
   提交时按内部 state 序列化 → 正文整体丢失（`opusTxtLen:4`）。必须用 CDP 真实输入
   `Input.insertText` + `Input.dispatchKeyEvent(Enter)`，并先 `Emulation.setFocusEmulationEnabled` + `Page.bringToFront`。
2. **必须新开干净 tab**：复用旧 tab 会打乱正文首个 IME 提交（首行错位）。用 `fetch('http://127.0.0.1:9222/json/new?'+url)`。
3. **逐行插入 + 行间 sleep(150~160ms)**：一次性 insertText 整篇只留首行；insertText 后立刻按 Enter 会打断首个 IME 提交。
4. **先填正文再填标题**：先填标题会打断正文首个 IME 提交。

自检日志：需有 `BODY_CHECK {"expect":N,"got":N+~1}`、无 `WARN_BODY_ORDER`（首行须以 note 首行开头）、无 `WARN_TEXT_TOO_LONG`。
编辑器开头会插一个零宽空格，`got` 比 `expect` 大 1~2 属正常。

## 附 C：配色 / 标签分流（改稿时注意同步）
- 配色：`bili_opus_prep.py` 的 `PALETTE` 与 `xhs_notes/make_bili_cover.py` 的 `SUBJECT_PALETTE` 两处
  （封面副标题按 `SUBJECT_PALETTE` 判定：学科→「高中知识点 · 一起考进名校」，非学科→「<分类> · 一起考进名校」）。
- 话题标签：`bili_opus_prep.py` 的 `EXAM_SUBJECTS` + `CAT_TAGS` 决定
  （学科 `#高中X #高考X #主题 #学习笔记`；学习类 `#高中学习 <分类标签> #主题 #学习笔记`）。
- 日志口径坑：同一 `published_log_bili.json` 混了 `bilibili_opus`（有 dyn_id，可核验）与更早的 `bilibili`（draft_saved，无 dyn_id）。
  统计剩余候选要按**去重集**算，别只按 `platform=='bilibili_opus'` 过滤（会高估余量）。
