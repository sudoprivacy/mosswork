# -*- coding: utf-8 -*-
"""搜索下拉词选题采集指令模板（wb-sel-15）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：搜索下拉词选题采集指令采集指令包（可粘贴任务指令，含字段定义）；评分入库表（热度/匹配度/可产性三维）；去重与时效过滤规则
建议输入（专业字段）：主题/产品；目标人群；平台；核心卖点
"""
import json, os, re, sys, time

SLUG = "wb-sel-15"
TITLE = "搜索下拉词选题采集指令模板"
PRICE_FEN = 990
CATEGORY = "自媒体运营"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['主题/产品', True, ['主题', '产品', '选题', '内容对象'], '决定选题与内容边界'], ['目标人群', True, ['人群', '受众', '目标用户'], '人群不明会导致选题与话术失焦'], ['平台', True, ['发布平台', '渠道', '平台类型'], '决定时长、字数与合规边界'], ['时长或字数', False, ['篇幅', '时长', '字数'], '按平台惯例约束篇幅'], ['核心卖点', True, ['卖点', '产品优势', '价值点'], '至少 1 个可验证的具体卖点'], ['语气', False, ['风格', '语调', '语气风格'], '统一表达风格'], ['禁忌', False, ['禁用表述', '禁忌', '红线'], '需逐句规避的表述']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['广告法对绝对化用语与虚假宣传的禁止性规定', '平台内容规则：引流表述、外链、诱导互动的限制', '素材授权要求（音乐、图片、字体、肖像）', '标题与正文一致性要求（避免标题党）', '数据引用需可溯源并标注口径与年份', '个人信息与声誉保护：不得披露他人隐私或未经同意的信息']
# 自检项（输入完备度）
CHECKS = [['搜索下拉词选题采集指令·选题与钩子', ['搜索下拉词选题采集指令', '可粘贴的任务指令'], '先核选题依据与0-3秒钩子是否成立'], ['搜索下拉词选题采集指令·内容结构', ['可粘贴的任务指令', '字段定义'], '按钩子-论证-转发结尾结构成稿并标注节奏'], ['搜索下拉词选题采集指令·平台适配', ['搜索下拉词选题采集指令', '评分维度'], '按平台参数（封面/时长/标签）逐项适配'], ['搜索下拉词选题采集指令·数据与复盘', ['字段定义', '热度/匹配度/可产性'], '定义完播/互动口径并给出诊断与修复动作'], ['搜索下拉词选题采集指令·诚信红线', ['数据造假', '搬运抄袭'], '不得买量造假或搬运抄袭，命中即终止']]
# 交付物构成
DELIVERABLES = ['搜索下拉词选题采集指令采集指令包（可粘贴任务指令，含字段定义）', '评分入库表（热度/匹配度/可产性三维）', '去重与时效过滤规则']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """内容创作交付物：人群与主张 → 标题方案 → 正文初稿 → 平台要素 → 合规审查 → 发布清单"""
    P = ctx["spec"]["params"]; L = []
    topic = ctx["fv"]("主题/产品") or ctx["spec"]["title"]
    aud = ctx["fv"]("目标人群")
    plat = ctx["fv"]("平台")
    length = ctx["fv"]("时长或字数")
    sell = ctx["fv"]("核心卖点")
    tone = ctx["fv"]("语气")
    avoid = ctx["fv"]("禁忌")
    sell_list = [x.strip() for x in re.split(r"[；;，,、/]", _s(sell)) if len(x.strip()) >= 2][:4]
    s1 = sell_list[0] if sell_list else ""
    s2 = sell_list[1] if len(sell_list) > 1 else ""
    prod = re.sub(r"[（(][^）)]*[）)]", "", _s(topic)).strip() or brief(topic, 16)
    aud_full = brief(aud, 44) or "目标用户"
    prob = "、".join(sell_list[1:3]) if len(sell_list) > 1 else (s1 or "实际问题")

    L.append(("一、目标与人群", [
        "| 项 | 内容 |", "|---|---|",
        "| 主题/产品 | %s |" % brief(topic, 50),
        "| 目标人群 | %s |" % (brief(aud, 60) or "（未提供，人群不明将导致选题与话术失焦）"),
        "| 发布平台 | %s |" % (brief(plat, 30) or "（未提供，平台决定时长、字数与合规边界）"),
        "| 篇幅要求 | %s |" % (brief(length, 30) or "（未提供，按平台惯例）"),
        "| 语气风格 | %s |" % (brief(tone, 30) or "（未提供，默认平实直给）"),
        "",
        "**人群画像三问**（回答清楚再动笔）：他们当前的状态是什么？他们最想解决的问题是什么？他们为什么不相信现有方案？",
    ]))

    L.append(("二、选题与核心主张", [
        "- 核心主张（一句话）：把「%s」讲清楚、给出可验证的依据——这是本条内容的核心支撑点" % (prob or "关键做法"),
        "- 选题角度：面向「%s」，围绕「%s」展开，落点在可验证的结果" % (aud_full, s2 or prod),
        "",
        "| 主张支撑 | 内容形态 | 说明 |", "|---|---|---|",
        "| 主张有据 | 数据/对比/过程记录 | 无证据的主张不写 |",
        "| 主张具体 | 可执行步骤 | 抽象表述改为动作 |",
        "| 主张有限定 | 适用条件 | 避免绝对化承诺 |",
    ]))

    n_pt = min(3, max(2, len(sell_list))) if sell_list else 3
    titles = [
        "做%s前，先避开这 %d 个常见坑" % (prod, n_pt),
        "关于%s，多数人第一步就想错了" % prod,
        "%s怎么做才有效？一份可复现的复盘" % prod,
    ]
    L.append(("三、标题方案（3 版备选）", [
        "| 版本 | 标题 | 适用场景 |", "|---|---|---|",
        "| A 悬念+清单 | %s | 泛人群，利于点击 |" % titles[0],
        "| B 反常识 | %s | 已有认知的人群，利于互动 |" % titles[1],
        "| C 结果导向 | %s | 强需求人群，利于转化 |" % titles[2],
        "",
        "标题自检：是否含可验证信息（数字/结果）？是否与正文承诺一致（防标题党）？是否 20 字内可读完？",
    ]))

    body = [
        "**① 钩子（前 3 秒 / 首句）**",
        "如果你也是%s，这篇可以帮你少走点弯路——我把实际做下来最有用的几点整理出来了。" % aud_full,
        "",
        "**② 痛点共鸣**",
        "先说结论：多数人一上手容易堆形容词和参数，结果读者记不住重点。真正值得先确认的是「%s」这类能被验证的点。" % (prob or "实际效果"),
        "",
        "**③ 方案（可执行）**",
        "1. 先明确第一需求：是「%s」，还是「%s」——两者取舍不同，别同时要。" % (s1 or "核心诉求", s2 or "次要诉求"),
        "2. 再按这个需求去核对素材与真实使用场景，优先保留能自己验证的部分，而不是形容词。",
        "3. 把每次发布后的数据记下来（阅读/完播/互动），别只凭第一印象下结论。",
        "",
        "**④ 证据**",
        "把过程数据记录下来（前后对比、样本量、统计口径），比形容词更有说服力；引用他人数据时标明来源与年份。",
        "",
        "**⑤ 收尾与行动**",
        "以上几点都可以自己复现验证，不必采信任何单方面说法。你更在意哪一点？评论区聊聊，我按大家的问题再补一篇。",
    ]
    L.append(("四、正文初稿（%s）" % (brief(plat, 12) or "通用"), body))

    L.append(("五、平台要素", [
        "| 要素 | 建议 |", "|---|---|",
        "| 封面/首图文案 | %s（含数字或可验证结果） |" % prod,
        "| 话题标签 | 主题标签 1~2 个 + 场景标签 2~3 个 + 人群标签 1 个 |",
        "| 时长/字数 | %s |" % (brief(length, 24) or "按平台惯例（短视频 30~60 秒 / 图文 600~900 字）"),
        "| 发布时间 | 按目标人群活跃时段投放，同一内容避免密集重复发布 |",
        "| 引导动作 | 关注/收藏/私信/评论，只设一个主要引导 |",
    ]))

    L.append(("六、合规审查", [
        "| 审查项 | 要求 | 本次检查 |", "|---|---|---|",
        "| 绝对化用语 | 不使用「最」「第一」「唯一」「100%」等无法举证的表述 | 需逐句复核 |",
        "| 功效承诺 | 不承诺疗效、收益、绝对结果 | 需逐句复核 |",
        "| 数据引用 | 引用需可溯源并注明年份口径 | 需标注来源 |",
        "| 版权 | 音乐、图片、素材需有授权或用自有素材 | 需核对 |",
        "| 平台规则 | 符合各平台对引流、外链、敏感词的规则 | 需按平台核对 |",
        "",
        "禁忌项（来自输入）：%s" % (brief(avoid, 50) or "未指定"),
    ]))

    L.append(("七、发布清单", [
        "- [ ] 标题与正文承诺一致，无标题党",
        "- [ ] 涉及的品牌、价格、活动信息已核对无误",
        "- [ ] 素材（图片/音乐/字体）授权状态已确认",
        "- [ ] 极限词与敏感表述已逐句清除",
        "- [ ] 标签与话题已按平台规则设置",
        "- [ ] 发布后 24 小时数据回看口径已确定（完播/互动/转化）",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
