# -*- coding: utf-8 -*-
"""新品技术分析 PPT 生成模板 —— 极简报告风（方案A，skill 默认版式）。

用法：
1. 将 DATA 字典中各字段替换为目标产品分析结果（数据来自 skill 四维分析）。
2. 运行：python gen_report_ppt.py [输出路径.pptx]
3. 生成 6 页 16:9 PPT：封面 / 产品档案 / 卖点&创新 / 技术路径 / 动因&合规 / 信息来源。

版式纪律（不得违反）：
- 无 emoji、无图标、无装饰性图示；层级靠左色条卡片 + 大号浅灰编号 + 字重 + 留白。
- 警示信息（短板/质控发现/合规提示）统一红色系；正常内容 teal 色条。
- 不渲染逐条"宣称 ↔ 脚注对账"明细，卖点卡只到"证据等级"行；
  宣称依据的核验结论并入证据等级文字与产品档案/质控发现的汇总短板。
- 单页正文 ≤ 600 字符，超限先删内容再调字号。
"""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
from lxml import etree
import sys

# ---------------- 设计 Token ----------------
SLIDE_W, SLIDE_H = Inches(13.333), Inches(7.5)
PRIMARY = RGBColor(0x1F, 0x3A, 0x5F)   # 深蓝：标题栏/封面块/重要文字
ACCENT = RGBColor(0x2E, 0x75, 0xB6)    # 蓝：证据等级、四维索引、创新卡片
TEAL = RGBColor(0x17, 0x8F, 0x8F)     # teal：正常卡片左色条/顶条
TEALBG = RGBColor(0xE6, 0xF3, 0xF2)
BG = RGBColor(0xF7, 0xF8, 0xFA)        # 页面底色
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
DARK = RGBColor(0x2B, 0x2B, 0x2B)      # 正文
GRAY = RGBColor(0x7A, 0x82, 0x8C)      # 辅助小字
MIDGRAY = RGBColor(0xB4, 0xBB, 0xC4)   # 大编号
LIGHTBLUE = RGBColor(0xBF, 0xCF, 0xE4) # 深底上的浅蓝文字
RED = RGBColor(0xC0, 0x00, 0x00)       # 警示
REDBG = RGBColor(0xFB, 0xEE, 0xEE)
ORANGE = RGBColor(0xE3, 0x6C, 0x0A)    # 待核实
ORANGEBG = RGBColor(0xFD, 0xF3, 0xE3)
CARDLINE = RGBColor(0xDD, 0xE3, 0xEB)  # 卡片描边
FONT = 'Microsoft YaHei'
TOTAL = 6

# ---------------- 分析数据（替换此处） ----------------
DATA = {
    'kicker': '新品技术分析 · 晒后修护喷雾赛道',
    'product_name': '蜜丝婷泛醇修护清凉果冻精华喷雾',
    'concept': '一喷成膜的"果冻水膜" + 清凉双通道，主打晒后舒缓修护',
    # 封面四栏信息：(标题, 两行内容)
    'cover_info': [
        ('备案 / 注册号', '沪G妆网备字2026009503\n国产 · 非特殊化妆品'),
        ('价格 / 规格', '¥59.9 / 150ml\n京东自营（海外 $14.99）'),
        ('上市时机', '2026-08\n防晒旺季尾部 · 军训/户外'),
        ('产品定位', '防晒线 → 晒后修护\n"防—护"闭环卡位'),
    ],
    'footer': '蜜丝婷泛醇修护清凉果冻精华喷雾（沪G妆网备字2026009503）｜ 新品技术分析 2026-08',
    # P2 产品档案：8 张卡 (编号, 标题, 两行内容, 是否警示)
    'profile_cards': [
        ('01', '备案 / 注册号', '沪G妆网备字2026009503\n国产普通化妆品（非特）', False),
        ('02', '备案功效（推断）', '08 修护 · 11 保湿 · 17 舒缓\n以 NMPA 备案公示为准', False),
        ('03', '价格 / 规格', '¥59.9 / 150ml（京东自营）\n历史最低 ¥57.9 ｜ 海外 $14.99', False),
        ('04', '品牌 / 产地', 'Mistine（泰国 Better Way 集团）\nMade in China · 供应链本地化', False),
        ('05', '产品形态', '果冻凝胶喷雾 · SKU MST026\n保质期 3 年 · INCI 全成分 42 项', False),
        ('06', '入选理由', '防晒矩阵向"晒后修护"延伸的代表新品\n补水喷雾赛道的肤感差异化', False),
        ('07', '上市时机', '2026-08 · 军训/户外/晒后急救场景\nB5 修护热度延续期', False),
        ('08', '关键短板', '无公开功效评价报告\n"晒后舒缓修护"宣称依据缺位', True),
    ],
    'profile_note': '备案来源：京东自营详情页参数区 · 以国家药监局备案公示为准（hzpba.nmpa.gov.cn/gccx）',
    # P3 卖点：(编号, 卖点名, 支撑成分一行, 证据等级一行)
    # 宣称依据核验结论并入证据等级文字；不输出逐条对账明细。
    'selling_points': [
        ('01', '晒后急救舒缓', 'B5 + 神经酰胺NP + 胆甾醇 + 积雪草 + 依克多因 + 红没药醇',
         '证据 中偏弱 · 无公开人体数据'),
        ('02', '物理级清凉', '凉感剂甲基二异丙基丙酰胺 + 4-叔丁基环己醇（TRPV1 拮抗）+ 赤藓糖醇',
         '证据 中 · 感官降温，非实测温降'),
        ('03', '果冻水膜质地', '结冷胶 + 黄原胶凝胶体系 + 三重玻尿酸，成膜不黏腻',
         '证据 中 · 肤感设计清晰，浓度未披露'),
        ('04', '温和无传统防腐', '对羟基苯乙酮 + 1,2-己二醇 + 乙基己基甘油 + 1,2-戊二醇',
         '证据 中 · 敏感肌产品常见组合'),
    ],
    # P3 创新点：(编号, 名称, 两行：内容\nvs 对比基准)
    'innovations': [
        ('01', '清凉"双通道"', '即时凉感 + TRPV1 阻断灼热感知\nvs 市面单一薄荷醇凉感喷雾'),
        ('02', '果冻凝胶剂型', '喷雾落地成"果冻水膜"，微乳保湿膜感\nvs 雅漾/理肤泉水状喷雾'),
        ('03', '晒后场景卡位', '非特普通化妆品，与防晒线"防—护"闭环\nvs 自家小凉喷防晒喷雾（SPF50+）'),
    ],
    # P4 技术路径 6 卡：(编号, 路径名, ≤3行内容, 是否警示)
    'tech_paths': [
        ('01', '成分', '修护：B5 · 神经酰胺NP · 积雪草 · 依克多因 · 红没药醇\n清凉：甲基二异丙基丙酰胺 · 4-叔丁基环己醇 · 赤藓糖醇\n保湿：五元醇 · 三重玻尿酸 · 糖类同分异构体 · 生物糖胶-1', False),
        ('02', '原料', '4-叔丁基环己醇 = 德之馨 SymSitive® 1609（TRPV1 拮抗）\n糖类同分异构体 ≈ DSM Pentavitin ｜ 生物糖胶-1 ≈ Fucogel\n波缘多孔菌提取物：国内少用，供应商待核实', False),
        ('03', '工艺', '环糊精包裹（稳定/缓释，对象未披露）\n凝胶喷雾低温配制，结冷胶体系已定型\n氯化钠作粘度调节（电解质敏感体系）', False),
        ('04', '专利', '公开渠道未见专利宣称 / 加标\n无专利证据（待实物核验）\n→ 走"配方 + 肤感"路线，非专利叙事', False),
        ('05', '制剂 / 剂型', '果冻凝胶喷雾：结冷胶骨架 + 黄原胶 + 糊精成膜\n微乳体系：微量油脂 + 聚甘油-10 月桂酸酯\n蓝色视觉：甘菊蓝 + 栀子果调色（非功效活性）', False),
        ('06', '功效评价', '无第三方人体功效报告\n"晒后舒缓修护"宣称依据未披露\n→ 本品最大证据短板', True),
    ],
    'qc_finding': '质控发现：乙酰化/水解玻尿酸疑为微量概念添加，"果冻精华"浓度无法对应；"晒后修护"宣称证据缺位',
    # P5 动因三栏：(栏名, [3条短句])
    'motives': [
        ('品牌定位', ['防晒+彩妆"泰式平价"心智（小黄帽/小凉喷）',
                      '"防晒"延伸至"晒后修护"，补夏季护肤闭环',
                      '¥59.9/150ml 卡大众价格带，与海外定价一致']),
        ('技术发展', ['泰国集团技术 + 国产备案供应链本地化',
                      '清凉双通道 + 凝胶喷雾为配方层新组合',
                      '无专利 / 新原料 / 产学研叙事，壁垒在肤感配方']),
        ('市场趋势', ['8月上市踩军训/户外/晒后急救场景',
                      'B5 修护热度延续，理肤泉B5教育后的平价需求溢出',
                      '补水喷雾同质化，"清凉降温"细分起量']),
    ],
    'inference': '推断：用已验证的"凉感"心智 + B5 修护热点，在防晒旺季尾部卡位晒后市场，低成本复用防晒线用户',
    # P5 合规提示 4 卡：(标题, ≤3行内容)
    'compliance': [
        ('凉感剂限量', '甲基二异丙基丙酰胺（目录03301）\n驻留类最高历史使用量 0.3%\n需确认添加量 ≤ 限量（CIR 2023）'),
        ('宣称边界', '"清凉"作感官描述可接受\n"物理降温 X℃"为量级承诺\n需温降功效数据支撑'),
        ('功效依据', '"晒后修护"属功效宣称（08）\n需补评价依据\n"晒后"勿暗示防晒功效'),
        ('吸入暴露', '驻留类喷雾需做吸入暴露评估\n（SED / 吸入 MoS）\n"倒喷"场景说明需配合'),
    ],
    'summary': '总结：凉感双通道 + 果冻凝胶喷雾是真差异，但无专利、无功效数据 —— 肤感创新 + 晒后卡位的大众平价品',
    # P6 信息来源：(条目, 说明, 状态, 是否待核实)
    'sources': [
        ('备案号', '京东自营详情页参数区 → 沪G妆网备字2026009503（NMPA 公示为准）', '已确认', False),
        ('全成分表', '跨境销售页完整 INCI 42 项 · SKU MST026（chicdecent.com）', '已获取', False),
        ('价格', '京东 ¥59.9（历史最低 ¥57.9）｜ 天猫海外 ¥56.91–69 ｜ 海外 $14.99–17.48', '已确认', False),
        ('凉感剂合规', '已使用目录 03301 · 驻留 0.3% / 已上市 0.4% · CIR 2023', '已核验', False),
        ('备案功效', '08 修护 / 11 保湿 / 17 舒缓 为推断，NMPA 公示待核', '待核实', True),
        ('特色原料', '波缘多孔菌提取物（Albatrellus confluens）供应商未披露', '待核实', True),
        ('功效数据', '清凉 / 舒缓实测数据，公开渠道未见第三方报告', '待核实', True),
    ],
    'sources_note': '按 skill「cosmetic-new-product-analysis」四维模板输出 ｜ 未披露项一律标注"待核实"，不臆造数据、不编造专利号',
    'cover_credit': '出品：WorkBuddy 化妆品新品技术分析 ｜ 2026-08-28',
}


# ---------------- 基础绘制 ----------------
def set_run(run, text, size=14, bold=False, color=DARK, name=FONT):
    run.text = text
    f = run.font
    f.size = Pt(size)
    f.bold = bold
    f.color.rgb = color
    f.name = name
    rPr = run._r.get_or_add_rPr()
    ea = rPr.find(qn('a:ea'))
    if ea is None:
        ea = etree.SubElement(rPr, qn('a:ea'))
    ea.set('typeface', name)


def add_text(slide, x, y, w, h, text, size=14, bold=False, color=DARK,
             align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, spacing=2):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    for i, ln in enumerate(text.split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(spacing)
        r = p.add_run()
        set_run(r, ln, size, bold, color)
    return tb


def add_box(slide, x, y, w, h, fill=None, line=None, radius=None, line_w=0.75):
    shape = MSO_SHAPE.ROUNDED_RECTANGLE if radius is not None else MSO_SHAPE.RECTANGLE
    shp = slide.shapes.add_shape(shape, x, y, w, h)
    if radius is not None:
        try:
            shp.adjustments[0] = radius
        except Exception:
            pass
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line
        shp.line.width = Pt(line_w)
    shp.shadow.inherit = False
    return shp


def a_card(slide, x, y, w, h, num, title, body, accent=TEAL):
    """左色条卡片：大编号 + 标题 + 正文（极简报告风核心组件）"""
    add_box(slide, x, y, w, h, fill=WHITE, line=CARDLINE)
    add_box(slide, x, y, Inches(0.07), h, fill=accent)
    add_text(slide, x + Inches(0.28), y + Inches(0.16), Inches(0.9), Inches(0.6),
             num, size=26, bold=True, color=MIDGRAY)
    add_text(slide, x + Inches(1.1), y + Inches(0.2), w - Inches(1.35), Inches(0.45),
             title, size=14.5, bold=True, color=PRIMARY)
    add_text(slide, x + Inches(1.1), y + Inches(0.68), w - Inches(1.35), h - Inches(0.85),
             body, size=10.5, color=DARK)


def add_header(slide, title, page_no, footer):
    add_box(slide, 0, 0, SLIDE_W, Inches(0.9), fill=PRIMARY)
    add_box(slide, 0, 0, Inches(0.14), Inches(0.9), fill=TEAL)
    add_text(slide, Inches(0.5), Inches(0.1), Inches(11.3), Inches(0.7), title,
             size=23, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    add_text(slide, Inches(12.15), Inches(0.25), Inches(1.0), Inches(0.4),
             f'{page_no} / {TOTAL}', size=12, color=LIGHTBLUE, align=PP_ALIGN.RIGHT)
    add_text(slide, Inches(0.5), Inches(7.18), Inches(12.3), Inches(0.26),
             footer, size=9, color=GRAY)


def add_page_bg(slide):
    add_box(slide, 0, 0, SLIDE_W, SLIDE_H, fill=BG)


# ---------------- 六页构建 ----------------
def build():
    D = DATA
    prs = Presentation()
    prs.slide_width, prs.slide_height = SLIDE_W, SLIDE_H
    blank = prs.slide_layouts[6]

    # P1 封面
    s = prs.slides.add_slide(blank)
    add_page_bg(s)
    add_box(s, 0, 0, SLIDE_W, Inches(3.1), fill=PRIMARY)
    add_box(s, Inches(0.9), Inches(0.55), Inches(0.12), Inches(2.1), fill=TEAL)
    add_text(s, Inches(1.3), Inches(0.6), Inches(11.2), Inches(0.5),
             D['kicker'], size=14, color=LIGHTBLUE)
    add_text(s, Inches(1.3), Inches(1.1), Inches(11.2), Inches(1.2),
             D['product_name'], size=34, bold=True, color=WHITE,
             anchor=MSO_ANCHOR.MIDDLE)
    add_text(s, Inches(1.3), Inches(2.4), Inches(11.2), Inches(0.5),
             D['concept'], size=15, color=LIGHTBLUE)
    cw, x = Inches(2.9), Inches(0.9)
    for i, (t, d) in enumerate(D['cover_info']):
        add_box(s, x, Inches(3.9), Inches(0.05), Inches(1.5),
                fill=TEAL if i == 0 else MIDGRAY)
        add_text(s, x + Inches(0.25), Inches(3.95), cw - Inches(0.3), Inches(0.35),
                 t, size=13, bold=True, color=PRIMARY)
        add_text(s, x + Inches(0.25), Inches(4.4), cw - Inches(0.3), Inches(1.0),
                 d, size=11, color=DARK)
        x += cw + Inches(0.32)
    add_text(s, Inches(0.9), Inches(5.75), Inches(11.5), Inches(0.4),
             '四维分析', size=13, bold=True, color=GRAY)
    dims = ['01  主要卖点', '02  创新点 / 差异点', '03  技术路径', '04  品牌推新动因']
    x = Inches(0.9)
    for d in dims:
        add_text(s, x, Inches(6.15), Inches(2.9), Inches(0.4), d,
                 size=12.5, bold=True, color=ACCENT)
        x += Inches(2.95)
    add_text(s, Inches(0.9), Inches(6.95), Inches(11.5), Inches(0.35),
             D['cover_credit'], size=10, color=GRAY)

    # P2 产品档案
    s = prs.slides.add_slide(blank)
    add_page_bg(s)
    add_header(s, '产品档案', 2, D['footer'])
    cw, ch = Inches(3.02), Inches(1.95)
    x0, y0 = Inches(0.5), Inches(1.25)
    for i, (num, t, d, warn) in enumerate(D['profile_cards']):
        r, c = divmod(i, 4)
        a_card(s, x0 + c * (cw + Inches(0.08)), y0 + r * (ch + Inches(0.18)),
               cw, ch, num, t, d, accent=RED if warn else TEAL)
    add_text(s, Inches(0.5), Inches(5.7), Inches(12.3), Inches(0.35),
             D['profile_note'], size=10, color=GRAY)

    # P3 卖点 + 创新
    s = prs.slides.add_slide(blank)
    add_page_bg(s)
    add_header(s, '主要卖点 & 创新点', 3, D['footer'])
    cw, ch = Inches(6.0), Inches(1.62)
    x0, y0 = Inches(0.5), Inches(1.15)
    for i, sp in enumerate(D['selling_points']):
        num, t, supp, evid = sp[:4]
        r, c = divmod(i, 2)
        bx = x0 + c * (cw + Inches(0.33))
        by = y0 + r * (ch + Inches(0.14))
        add_box(s, bx, by, cw, ch, fill=WHITE, line=CARDLINE)
        add_box(s, bx, by, Inches(0.07), ch, fill=TEAL)
        add_text(s, bx + Inches(0.26), by + Inches(0.11), Inches(0.85), Inches(0.55),
                 num, size=24, bold=True, color=MIDGRAY)
        add_text(s, bx + Inches(1.05), by + Inches(0.12), cw - Inches(1.25), Inches(0.4),
                 t, size=14.5, bold=True, color=PRIMARY)
        add_text(s, bx + Inches(1.05), by + Inches(0.52), cw - Inches(1.25), Inches(0.5),
                 supp, size=10.5, color=DARK)
        add_text(s, bx + Inches(1.05), by + Inches(0.98), cw - Inches(1.25), Inches(0.3),
                 evid, size=9.5, bold=True, color=ACCENT)
    add_text(s, Inches(0.5), Inches(4.72), Inches(8.0), Inches(0.38),
             '创新点 / 差异点（含对比基准）', size=15, bold=True, color=PRIMARY)
    cw2, x = Inches(3.95), Inches(0.5)
    for num, t, d in D['innovations']:
        a_card(s, x, Inches(5.18), cw2, Inches(1.62), num, t, d, accent=ACCENT)
        x += cw2 + Inches(0.24)

    # P4 技术路径
    s = prs.slides.add_slide(blank)
    add_page_bg(s)
    add_header(s, '技术路径拆解', 4, D['footer'])
    cw, ch = Inches(3.98), Inches(2.42)
    x0, y0 = Inches(0.5), Inches(1.15)
    for i, (num, t, body, warn) in enumerate(D['tech_paths']):
        r, c = divmod(i, 3)
        a_card(s, x0 + c * (cw + Inches(0.2)), y0 + r * (ch + Inches(0.2)),
               cw, ch, num, t, body, accent=RED if warn else TEAL)
    add_box(s, Inches(0.5), Inches(6.52), Inches(12.33), Inches(0.48), fill=REDBG)
    add_text(s, Inches(0.8), Inches(6.58), Inches(11.8), Inches(0.4),
             D['qc_finding'], size=11, bold=True, color=RED, anchor=MSO_ANCHOR.MIDDLE)

    # P5 动因 + 合规
    s = prs.slides.add_slide(blank)
    add_page_bg(s)
    add_header(s, '推新动因 & 合规提示', 5, D['footer'])
    cw, x = Inches(3.98), Inches(0.5)
    for t, items in D['motives']:
        add_box(s, x, Inches(1.1), cw, Inches(2.05), fill=WHITE, line=CARDLINE)
        add_box(s, x, Inches(1.1), cw, Inches(0.06), fill=TEAL)
        add_text(s, x + Inches(0.24), Inches(1.28), cw - Inches(0.5), Inches(0.4),
                 t, size=14, bold=True, color=PRIMARY)
        add_text(s, x + Inches(0.24), Inches(1.75), cw - Inches(0.48), Inches(1.3),
                 '\n'.join('· ' + it for it in items), size=10, color=DARK)
        x += cw + Inches(0.2)
    add_box(s, Inches(0.5), Inches(3.32), Inches(12.33), Inches(0.5),
            fill=RGBColor(0xE8, 0xEF, 0xF7))
    add_text(s, Inches(0.8), Inches(3.38), Inches(11.8), Inches(0.4),
             D['inference'], size=11.5, bold=True, color=PRIMARY, anchor=MSO_ANCHOR.MIDDLE)
    add_text(s, Inches(0.5), Inches(3.98), Inches(6.0), Inches(0.36),
             '合规与安全提示', size=14, bold=True, color=RED)
    cw, x = Inches(2.98), Inches(0.5)
    for t, d in D['compliance']:
        add_box(s, x, Inches(4.4), cw, Inches(1.68), fill=REDBG,
                line=RGBColor(0xE5, 0xB8, 0xB8))
        add_box(s, x, Inches(4.4), cw, Inches(0.06), fill=RED)
        add_text(s, x + Inches(0.2), Inches(4.56), cw - Inches(0.4), Inches(0.38),
                 t, size=12.5, bold=True, color=RED)
        add_text(s, x + Inches(0.2), Inches(5.0), cw - Inches(0.4), Inches(1.0),
                 d, size=9.5, color=DARK)
        x += cw + Inches(0.13)
    add_box(s, Inches(0.5), Inches(6.3), Inches(12.33), Inches(0.7), fill=PRIMARY)
    add_text(s, Inches(0.8), Inches(6.36), Inches(11.8), Inches(0.58),
             D['summary'], size=12, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)

    # P6 信息来源
    s = prs.slides.add_slide(blank)
    add_page_bg(s)
    add_header(s, '信息来源与待核实项', 6, D['footer'])
    y = Inches(1.25)
    for t, d, st, pending in D['sources']:
        ac = ORANGE if pending else TEAL
        add_box(s, Inches(0.5), y, Inches(12.33), Inches(0.6), fill=WHITE, line=CARDLINE)
        add_box(s, Inches(0.5), y, Inches(0.06), Inches(0.6), fill=ac)
        add_text(s, Inches(0.78), y + Inches(0.09), Inches(2.0), Inches(0.42),
                 t, size=12.5, bold=True, color=PRIMARY, anchor=MSO_ANCHOR.MIDDLE)
        add_text(s, Inches(2.9), y + Inches(0.09), Inches(8.0), Inches(0.42),
                 d, size=10.5, color=DARK, anchor=MSO_ANCHOR.MIDDLE)
        stw = Inches(0.95)
        add_box(s, Inches(11.55), y + Inches(0.14), stw, Inches(0.32),
                fill=TEALBG if ac == TEAL else ORANGEBG, radius=0.5)
        add_text(s, Inches(11.55), y + Inches(0.16), stw, Inches(0.3), st, size=9.5,
                 bold=True, color=ac, align=PP_ALIGN.CENTER)
        y += Inches(0.73)
    add_text(s, Inches(0.5), y + Inches(0.08), Inches(12.3), Inches(0.55),
             D['sources_note'], size=10, color=GRAY)
    return prs


if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else '新品技术分析-极简报告风.pptx'
    build().save(out)
    print('saved:', out)
