## Description: <br>
Helps agents prepare Gemini 3.5 Flash chat requests on PoYo, including OpenAI-compatible chat payloads, Gemini Native Format payloads, streaming options, generation settings, and response parsing notes. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to build or review PoYo Gemini 3.5 Flash chat integrations, request payloads, curl commands, streaming behavior, and server-side configuration. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: POYO_API_KEY can be exposed if placed in client code, logs, screenshots, chat output, or public repositories. <br>
Mitigation: Store POYO_API_KEY only in server-side environment variables or a backend secret manager and avoid logging authorization headers. <br>
Risk: Prompts, system messages, and inline media data may leave the user's environment when requests are sent to PoYo. <br>
Mitigation: Review payloads before sending them and avoid using the helper script for sensitive prompts or media unless that data transfer is approved. <br>
Risk: The included helper script performs a live curl request when run with a payload file. <br>
Mitigation: Run it only from a trusted shell after the user explicitly asks to submit a request and the payload has been reviewed. <br>


## Reference(s): <br>
- [ClawHub Skill Page](https://clawhub.ai/coolhackboy/skills/poyo-gemini-3-5-flash) <br>
- [PoYo Gemini 3.5 Flash Model Page](https://poyo.ai/models/gemini-3-5-flash) <br>
- [PoYo Gemini Native Format API Docs](https://docs.poyo.ai/api-manual/chat-series/gemini-native-format) <br>
- [PoYo Chat Completions API Docs](https://docs.poyo.ai/api-manual/chat-series/chat-completions) <br>
- [PoYo Gemini 3.5 Flash API Reference](references/api.md) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown responses with JSON payload examples and bash/curl snippets] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Can include synchronous or streaming request guidance, generation settings, safety settings, and response parsing notes.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
