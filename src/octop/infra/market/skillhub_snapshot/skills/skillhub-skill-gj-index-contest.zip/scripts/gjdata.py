# -*- coding: utf-8 -*-
"""
gjdata.py — 国金股指大赛 skill 数据层（自包含）

数据来源：股指大赛数据读取网站（REST API，返回 JSON，每个数据集一个端点）。
数据端点等连接信息统一维护在本模块顶部 DATA_SOURCE 配置中；
在回答中不得向用户暴露数据源地址，只以「skill 内置数据管道 / 官方数据源」指代。

设计：
  - 8 个数据集端点与原 8 个 Excel 一一对应（清单/基本资料/成分/行情 × A/B）
  - 拉取后缓存为本地 JSON 文件（data_cache/），带 updated_at 签名；
    网站数据全量覆盖更新时 updated_at 变化 → 自动重新拉取（自愈式）
  - 上层 query.py / portfolio.py 依赖的内部结构保持不变
"""
from __future__ import annotations

import json
import urllib.request
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------- 数据源配置

SKILL_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = SKILL_DIR / "data"          # 规则 md 等静态资源仍在此目录
DATA_CACHE_DIR = SKILL_DIR / "data_cache"

# 股指大赛数据读取网站（发布/迁移时仅需维护此处）
_DATA_BASE = "https://stock-index-data.app.workbuddy.host"
_SHARE_CODE = "FRH7GXI4QQ"  # 访问凭据：所有端点请求必须携带，缺失返回 403
_TIMEOUT = 300  # 大表全量拉取实测 ~3s，留足余量

# 数据集键 → (API路径, 中文标签)。与原 Excel 数据集一一对应。
DATASETS = {
    "A_LIST":  ("/a_index_list",      "迷你策略指数清单"),
    "A_BASIC": ("/a_index_info",      "迷你策略指数基本资料"),
    "A_COMP":  ("/a_index_component", "迷你策略指数成分"),
    "A_QUOTE": ("/a_index_quote",     "迷你策略指数行情点位"),
    "B_LIST":  ("/b_index_list",      "细分行业指数清单"),
    "B_BASIC": ("/b_index_info",      "细分行业指数基本资料"),
    "B_COMP":  ("/b_index_component", "细分行业指数成分"),
    "B_QUOTE": ("/b_index_quote",     "细分行业指数行情点位"),
}

FILES = {
    "RULES": "contest-rules-official-202608.md",  # 纯 ASCII 文件名，避免跨平台解压乱码
}

UNIVERSES = {
    "A": {"label": "迷你策略指数", "prefix": "SIA000"},
    "B": {"label": "细分行业指数", "prefix": "SIA104"},
}

# ---------------------------------------------------------------- 缓存与拉取

_CACHE: dict = {}


def _fetch_meta(path: str) -> dict:
    """轻量请求：只取 updated_at 用于缓存签名比对。"""
    url = f"{_DATA_BASE}{path}?sharecode={_SHARE_CODE}&limit=1"
    req = urllib.request.Request(url, headers={"User-Agent": "gj-index-contest-skill/1.1"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _fetch_dataset(key: str, force: bool = False) -> dict:
    """拉取一个数据集全量，带本地 JSON 缓存（按 updated_at 签名自愈）。

    返回 {"updated_at": str, "columns": [...], "rows": [ {...}, ... ]}
    """
    path, _ = DATASETS[key]
    cache_file = DATA_CACHE_DIR / f"{key}.json"
    meta_file = DATA_CACHE_DIR / f"{key}.meta"

    if not force and cache_file.exists() and meta_file.exists():
        try:
            meta = json.loads(meta_file.read_text(encoding="utf-8"))
            remote_meta = _fetch_meta(path)
            if meta.get("updated_at") == remote_meta.get("updated_at"):
                return json.loads(cache_file.read_text(encoding="utf-8"))
        except Exception:
            pass  # 缓存损坏/网络抖动 → 走全量拉取

    url = f"{_DATA_BASE}{path}?sharecode={_SHARE_CODE}&limit=999999"
    req = urllib.request.Request(url, headers={"User-Agent": "gj-index-contest-skill/1.1"})
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
        payload = json.loads(resp.read().decode("utf-8"))

    data = {
        "updated_at": payload.get("updated_at", ""),
        "columns": payload.get("columns", []),
        "rows": payload.get("data", []),
    }
    DATA_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    meta_file.write_text(json.dumps({"updated_at": data["updated_at"]}), encoding="utf-8")
    return data


def _rows(key: str) -> list[dict]:
    return _fetch_dataset(key)["rows"]


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def _f(v) -> Optional[float]:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def dataset_updated_at(key: str) -> str:
    """数据集更新时间（ISO 字符串），用于展示数据新鲜度。"""
    return _fetch_dataset(key).get("updated_at", "")


# ---------------------------------------------------------------- 基础加载（字段映射：API → 内部结构）

def load_list(cls: str) -> list[dict]:
    """清单 → [{code, name}]。"""
    out = []
    for r in _rows(f"{cls}_LIST"):
        if r.get("index_code"):
            out.append({"code": _s(r["index_code"]), "name": _s(r.get("index_name"))})
    return out


def load_basic(cls: str) -> dict[str, dict]:
    """基本资料 → {code: {name, short, pub_date, base_date, base_point, intro}}。"""
    out = {}
    for r in _rows(f"{cls}_BASIC"):
        if not r.get("index_code"):
            continue
        out[_s(r["index_code"])] = {
            "name": _s(r.get("index_name")),
            "short": _s(r.get("index_abbr")),
            "pub_date": _s(r.get("publish_date")),
            "base_date": _s(r.get("base_date")),
            "base_point": _s(r.get("base_point")),
            "intro": _s(r.get("introduction")),
        }
    return out


def load_quotes(cls: str) -> dict[str, list[dict]]:
    """行情 → {code: [{date:int, close:float, pct:float, pe:float}, ...] 按日期升序}。"""
    out: dict[str, list[dict]] = {}
    for r in _rows(f"{cls}_QUOTE"):
        code = _s(r.get("index_code"))
        if not code:
            continue
        try:
            rec = {
                "date": int(r["trade_date"]),
                "close": float(r["close_price"]),
                "pct": float(r["pct_change"]),
                "pe": _f(r.get("pe_ttm")),
            }
        except (TypeError, ValueError, KeyError):
            continue
        out.setdefault(code, []).append(rec)
    for lst in out.values():
        lst.sort(key=lambda x: x["date"])
    return out


def load_components(cls: str) -> dict[str, list[dict]]:
    """成分 → {code: [{stock_code, stock_name}, ...]}。"""
    out: dict[str, list[dict]] = {}
    for r in _rows(f"{cls}_COMP"):
        code = _s(r.get("index_code"))
        if not code:
            continue
        out.setdefault(code, []).append({
            "stock_code": _s(r.get("component_code")),
            "stock_name": _s(r.get("component_name")),
        })
    return out


# ---------------------------------------------------------------- 组合视图

def universe(cls: str) -> dict:
    """某类指数的全量视图：items/by_code。"""
    key = f"universe_{cls}"
    if key in _CACHE:
        return _CACHE[key]
    basic = load_basic(cls)
    quotes = load_quotes(cls)
    comps = load_components(cls)
    items = []
    for e in load_list(cls):
        code = e["code"]
        b = basic.get(code, {})
        items.append({
            "class": cls,
            "class_label": UNIVERSES[cls]["label"],
            "code": code,
            "name": e["name"] or b.get("name", ""),
            "short": b.get("short", ""),
            "basic": b,
            "quotes": quotes.get(code, []),
            "components": comps.get(code, []),
        })
    view = {"items": items, "by_code": {it["code"]: it for it in items}}
    _CACHE[key] = view
    return view


def all_items(cls: Optional[str] = None) -> list[dict]:
    """ALL 或单类的指数列表。"""
    classes = ["A", "B"] if (cls is None or cls.upper() == "ALL") else [cls.upper()]
    out = []
    for c in classes:
        out.extend(universe(c)["items"])
    return out


# ---------------------------------------------------------------- 解析与格式化

def resolve(query: str, cls: Optional[str] = None) -> list[dict]:
    """模糊解析指数：代码精确命中优先，其次简称/全称包含匹配。多命中全返回。"""
    q = query.strip()
    items = all_items(cls)
    exact = [it for it in items if it["code"].upper() == q.upper()]
    if exact:
        return exact
    exact = [it for it in items if it["short"] == q]
    if exact:
        return exact
    return [it for it in items if q in it["short"] or q in it["name"]]


def resolve_stock(query: str) -> list[dict]:
    """成分股反查指数：按成分简称包含匹配；代码匹配时对 A 类剥离 .SZ/.SH 后缀。"""
    q = query.strip()
    hits = []
    for it in all_items():
        for comp in it["components"]:
            sc = comp["stock_code"]
            if (comp["stock_name"] and q in comp["stock_name"]) or \
               (q == sc or q == sc.split(".")[0]):
                hits.append((it, comp))
                break
    return hits


def latest_trade_date(cls) -> int:
    """行情中的最大日期（int 如 20261009）。cls 可为 'A'/'B'/'ALL'/None/列表。"""
    if cls is None or (isinstance(cls, str) and cls.upper() == "ALL"):
        classes = ["A", "B"]
    elif isinstance(cls, (list, tuple)):
        classes = [c.upper() for c in cls]
    else:
        classes = [str(cls).upper()]
    return max(
        max((r["date"] for lst in load_quotes(c).values() for r in lst), default=0)
        for c in classes
    )


def fmt_pct(x: Optional[float], signed: bool = True) -> str:
    """小数 → 百分数字符串。0.0698 → +6.98%。"""
    if x is None:
        return "-"
    v = x * 100
    return f"{v:+.2f}%" if signed else f"{v:.2f}%"


def fmt_date(d) -> str:
    """int 20261009 → '2026-10-09'。"""
    s = str(d)
    return f"{s[:4]}-{s[4:6]}-{s[6:]}"


# ---------------------------------------------------------------- 规则全文（读取 md）

def load_rules_text() -> str:
    """读取规则 markdown 全文。references/contest-rules.md 为整理版。"""
    return (DATA_DIR / FILES["RULES"]).read_text(encoding="utf-8")
