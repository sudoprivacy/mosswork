# -*- coding: utf-8 -*-
"""
query.py — 国金股指大赛 skill 数据查询 CLI（自包含，只读 skill 内 data/）

子命令：
  list        列出指数（--class A/B/ALL --keyword 关键词 --limit N）
  info        指数档案（基本信息 + 近N日行情 + 成分股概览）
  quote       近N日行情
  rank        近N交易日区间涨幅榜
  components  成分股列表
  stock       成分股反查指数

输出为 Markdown 表格 + 数据来源脚注，可直接引用。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gjdata as G  # noqa: E402


def _footer(classes) -> str:
    d = G.fmt_date(G.latest_trade_date(classes))
    labels = {"A": "迷你策略指数行情", "B": "细分行业指数行情"}
    names = "、".join(labels.get(c, c) for c in classes)
    return f"\n> 数据来源：skill 内置数据管道（{names}），行情截至 {d}。"


def _classes(v: str) -> list[str]:
    return ["A", "B"] if v.upper() == "ALL" else [v.upper()]


def _latest(rec: dict) -> dict:
    return rec["quotes"][-1] if rec["quotes"] else {}


# ---------------------------------------------------------------- list

def cmd_list(args):
    cls_l = _classes(args.cls)
    items = G.all_items(args.cls)
    kw = (args.keyword or "").strip()
    if kw:
        items = [it for it in items if kw in it["short"] or kw in it["name"]]
    total = len(items)
    items = items[: args.limit]
    print(f"共 {total} 只指数" + (f"（关键词「{kw}」）" if kw else "") + f"｜显示 {len(items)} 只")
    print("| 类别 | 指数代码 | 指数名称 | 最新涨跌幅 | 市盈率_TTM |")
    print("|---|---|---|---|---|")
    for it in items:
        q = _latest(it)
        pe = f"{q['pe']:.2f}" if q.get("pe") is not None else "-"
        # B类不使用简称，统一用指数名称；A类用简称
        label = it["name"] if it["class"] == "B" else it["short"]
        print(f"| {it['class']} | {it['code']} | {label} | "
              f"{G.fmt_pct(q.get('pct'))} | {pe} |")
    print(_footer(cls_l))


# ---------------------------------------------------------------- 通用

def _disp(it: dict) -> str:
    """指数展示名：B类用指数名称（不用简称），A类用简称。"""
    return it["name"] if it["class"] == "B" else it["short"]


def _multi_hit_notice(query: str, hits: list[dict]):
    print(f"「{query}」命中 {len(hits)} 只指数，请指定：")
    for it in hits:
        print(f"  - {_disp(it)}（{it['code']}，{it['class_label']}）")


# ---------------------------------------------------------------- info

def cmd_info(args):
    hits = G.resolve(args.index, args.cls if args.cls != "ALL" else None)
    if not hits:
        print(f"未找到指数「{args.index}」。可用 list --keyword 浏览全部指数。")
        return
    if len(hits) > 1:
        _multi_hit_notice(args.index, hits)
        return
    it = hits[0]
    b = it["basic"]
    print(f"\n### {_disp(it)}（{it['code']}）[{it['class_label']}]")
    print(f"- 全称：{it['name']}")
    print(f"- 发布日期 {G.fmt_date(b.get('pub_date'))}，基日 {G.fmt_date(b.get('base_date'))}，"
          f"基点 {b.get('base_point')}")
    if b.get("intro"):
        print(f"- 简介：{b['intro']}")
    quotes = it["quotes"]
    if quotes:
        last = quotes[-1]
        print(f"- 最新交易日 {G.fmt_date(last['date'])}：收盘 {last['close']:.2f}，"
              f"涨跌幅 {G.fmt_pct(last['pct'])}，市盈率_TTM {last['pe']:.2f}"
              if last.get("pe") is not None else
              f"- 最新交易日 {G.fmt_date(last['date'])}：收盘 {last['close']:.2f}，"
              f"涨跌幅 {G.fmt_pct(last['pct'])}")
        n = min(args.days, len(quotes) - 1)  # N 次变化需 N+1 个收盘价
        if n >= 1:
            base = quotes[-n - 1]
            span = (last["close"] / base["close"] - 1) if base["close"] else 0
            print(f"- 近 {n} 个交易日区间涨跌：{G.fmt_pct(span)}"
                  f"（{G.fmt_date(base['date'])} → {G.fmt_date(last['date'])}）")
    comps = it["components"]
    if comps:
        if it["class"] == "A":
            # A类成分股仅限内部推理，不对外展示名单
            print(f"- 成分股：{len(comps)} 只（迷你策略指数成分名单不展示）")
        else:
            names = "、".join(c["stock_name"] for c in comps[:10])
            more = f" 等共 {len(comps)} 只" if len(comps) > 10 else ""
            print(f"- 成分股（{len(comps)}只）：{names}{more}")
    print(_footer([it["class"]]))


# ---------------------------------------------------------------- quote

def cmd_quote(args):
    hits = G.resolve(args.index, args.cls if args.cls != "ALL" else None)
    if not hits:
        print(f"未找到指数「{args.index}」。")
        return
    if len(hits) > 1:
        _multi_hit_notice(args.index, hits)
        return
    it = hits[0]
    quotes = it["quotes"][-args.days:]
    print(f"\n### {_disp(it)}（{it['code']}）[{it['class_label']}]"
          f"  最近 {len(quotes)} 个交易日")
    print("| 日期 | 收盘价 | 涨跌幅 | 市盈率_TTM |")
    print("|---|---|---|---|")
    for q in reversed(quotes):  # 最新在首行
        pe = f"{q['pe']:.2f}" if q.get("pe") is not None else "-"
        print(f"| {G.fmt_date(q['date'])} | {q['close']:.2f} | "
              f"{G.fmt_pct(q['pct'])} | {pe} |")
    print(_footer([it["class"]]))


# ---------------------------------------------------------------- rank

def cmd_rank(args):
    cls_l = _classes(args.cls)
    need = args.days + 1  # N 个交易日变化 = N+1 个收盘价
    rows = []
    for it in G.all_items(args.cls):
        quotes = it["quotes"]
        if len(quotes) < need:
            continue
        window = quotes[-need:]
        base = window[0]["close"]
        if not base:
            continue
        rows.append((it, window[-1]["close"] / base - 1))
    rows.sort(key=lambda x: x[1], reverse=not args.asc)
    total = len(rows)
    rows = rows[: args.top]
    if not rows:
        print(f"样本不足：需要至少 {need} 个交易日行情。")
        return
    # 区间起点日期：取第一只样本指数窗口首日
    first_item = rows[0][0]
    d0 = G.fmt_date(first_item["quotes"][-need]["date"])
    d1 = G.fmt_date(G.latest_trade_date(args.cls))
    direction = "涨幅榜" if not args.asc else "跌幅榜"
    print(f"{direction}｜区间 {d0} → {d1}（{args.days} 个交易日变化）｜样本 {total} 只｜显示前 {len(rows)}")
    print("| 指数名称 | 指数代码 | 类别 | 区间涨跌幅 | 市盈率_TTM |")
    print("|---|---|---|---|---|")
    for it, chg in rows:
        q = _latest(it)
        pe = f"{q['pe']:.2f}" if q.get("pe") is not None else "-"
        print(f"| {_disp(it)} | {it['code']} | {it['class_label']} | "
              f"{G.fmt_pct(chg)} | {pe} |")
    print(f"\n> 区间涨跌幅 = 期末收盘 / 期初收盘 - 1；{args.days} 个交易日变化基于 {need} 个收盘价"
          "（非单日涨跌幅相加）。")
    print(_footer(cls_l))


# ---------------------------------------------------------------- components

def cmd_components(args):
    hits = G.resolve(args.index, args.cls if args.cls != "ALL" else None)
    if not hits:
        print(f"未找到指数「{args.index}」。")
        return
    if len(hits) > 1:
        _multi_hit_notice(args.index, hits)
        return
    it = hits[0]
    if it["class"] == "A":
        print(f"\n「{_disp(it)}（{it['code']}）」为迷你策略指数，成分股名单不对外展示。")
        print("仅支持细分行业指数的成分查询，可用 list --class B 查看细分行业指数。")
        return
    comps = it["components"]
    print(f"\n### {_disp(it)}（{it['code']}）[{it['class_label']}] 成分股 {len(comps)} 只")
    print("| 成分代码 | 成分简称 |")
    print("|---|---|")
    for c in comps:
        print(f"| {c['stock_code']} | {c['stock_name']} |")
    print(_footer([it["class"]]))


# ---------------------------------------------------------------- stock

def cmd_stock(args):
    hits = G.resolve_stock(args.stock)
    if not hits:
        print(f"成分股中未找到「{args.stock}」。")
        return
    print(f"\n### 成分股「{args.stock}」相关指数共 {len(hits)} 只")
    print("| 指数名称 | 指数代码 | 类别 | 该成分股 | 成分代码 | 最新涨跌幅 | 市盈率_TTM |")
    print("|---|---|---|---|---|---|---|")
    for it, comp in hits:
        q = _latest(it)
        pe = f"{q['pe']:.2f}" if q.get("pe") is not None else "-"
        if it["class"] == "A":
            # A类命中：保留推理价值，但脱敏股名与代码（禁止写入回答）
            stock_cell = "（内部依据·禁止写入回答）"
            code_cell = "—"
        else:
            stock_cell = comp["stock_name"]
            code_cell = comp["stock_code"]
        print(f"| {_disp(it)} | {it['code']} | {it['class_label']} | "
              f"{stock_cell} | {code_cell} | "
              f"{G.fmt_pct(q.get('pct'))} | {pe} |")
    print(_footer(["A", "B"]))


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(description="国金股指大赛指数查询")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("list", help="列出指数")
    p.add_argument("--class", dest="cls", default="ALL", choices=["A", "B", "ALL"])
    p.add_argument("--keyword", default="", help="简称/全称包含匹配")
    p.add_argument("--limit", type=int, default=30)
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("info", help="指数档案")
    p.add_argument("index", help="指数名称/简称/代码（模糊）")
    p.add_argument("--class", dest="cls", default="ALL", choices=["A", "B", "ALL"])
    p.add_argument("--days", type=int, default=20)
    p.set_defaults(func=cmd_info)

    p = sub.add_parser("quote", help="近N日行情")
    p.add_argument("index")
    p.add_argument("--class", dest="cls", default="ALL", choices=["A", "B", "ALL"])
    p.add_argument("--days", type=int, default=10)
    p.set_defaults(func=cmd_quote)

    p = sub.add_parser("rank", help="区间涨幅榜")
    p.add_argument("--days", type=int, default=5, help="交易日数")
    p.add_argument("--top", type=int, default=10)
    p.add_argument("--asc", action="store_true", help="升序（跌幅榜）")
    p.add_argument("--class", dest="cls", default="ALL", choices=["A", "B", "ALL"])
    p.set_defaults(func=cmd_rank)

    p = sub.add_parser("components", help="成分股列表")
    p.add_argument("index")
    p.add_argument("--class", dest="cls", default="ALL", choices=["A", "B", "ALL"])
    p.set_defaults(func=cmd_components)

    p = sub.add_parser("stock", help="成分股反查指数")
    p.add_argument("stock", help="股票简称或代码")
    p.set_defaults(func=cmd_stock)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
