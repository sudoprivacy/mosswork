# -*- coding: utf-8 -*-
"""
portfolio.py — 国金股指大赛组合规则校验 CLI（自包含）

子命令：
  validate CODE:WEIGHT ...   校验组合是否符合大赛规则

大赛规则（详见 references/contest-rules.md）：
  - 组合含 1~10 只指数
  - 单只指数仓位 10%~30%（含边界）
  - 指数仓位合计 ≤ 100%，差额即为现金
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gjdata as G  # noqa: E402

RULE = {
    "min_n": 1, "max_n": 10,
    "min_w": 10.0, "max_w": 30.0,
    "max_total": 100.0,
}


def cmd_validate(args):
    holdings: list[tuple[str, float]] = []
    errors: list[str] = []
    for tok in args.holdings:
        try:
            code, w = tok.rsplit(":", 1)
            holdings.append((code.strip(), float(w)))
        except ValueError:
            errors.append(f"参数格式错误：{tok}（应为 代码:权重，如 SIA000254:25）")
    if errors:
        for e in errors:
            print(f"❌ {e}")
        sys.exit(1)

    print("### 组合规则校验\n")
    print("| 指数简称 | 指数代码 | 类别 | 权重 | 单只10%~30% |")
    print("|---|---|---|---|---|")
    rows = []
    for code, w in holdings:
        hits = G.resolve(code)
        if not hits:
            rows.append((code, "未找到", "-", w, "—"))
        elif len(hits) > 1:
            label = "；".join(f"{h['short']}({h['code']},{h['class']})" for h in hits)
            rows.append((code, label[:40] + "…", "多命中", w, "—"))
        else:
            it = hits[0]
            rows.append((it["short"], it["code"], it["class_label"], w, ""))
    total = 0.0
    ok_all = True
    for (short, code, cls, w, _) in rows:
        if cls in ("未找到", "多命中"):
            ok = False
            mark = "❌ 代码无效"
        else:
            ok = RULE["min_w"] <= w <= RULE["max_w"]
            mark = "✅" if ok else f"❌ 超出 [{RULE['min_w']:.0f}%, {RULE['max_w']:.0f}%]"
        if not ok:
            ok_all = False
        total += w if cls not in ("未找到", "多命中") else 0
        print(f"| {short} | {code} | {cls} | {w:.2f}% | {mark} |")

    # 只数检查
    n = len([r for r in rows if r[2] not in ("未找到", "多命中")])
    n_ok = RULE["min_n"] <= n <= RULE["max_n"]
    print(f"| 指数仓位合计 | {n} 只 | | {total:.2f}% | "
          f"{'✅' if total <= RULE['max_total'] else f'❌ 超出上限 {RULE["max_total"]:.0f}%'} |")
    cash = RULE["max_total"] - total
    print(f"| 现金 | — | — | {cash:.2f}% | 现金 = 100% - 指数仓位合计 |")

    print(f"\n检查项：")
    print(f"- 只数 {n} 只：{'✅' if n_ok else '❌'}（规则 1~10 只）")
    print(f"- 单只仓位：{'全部 ✅' if all(RULE['min_w'] <= r[3] <= RULE['max_w'] for r in rows if r[2] not in ('未找到','多命中')) and n else '存在 ❌'}（每只 10%~30%）")
    print(f"- 仓位合计 {total:.2f}% ≤ 100%：{'✅' if total <= RULE['max_total'] else '❌'}"
          f"（现金 {cash:.2f}%）")
    verdict = n_ok and ok_all and total <= RULE["max_total"] and n > 0
    print(f"\n{'✅ 规则校验：通过' if verdict else '❌ 规则校验：未通过，请调整后重试'}")
    print("\n> 提示：正式比赛期间每日仅 1 次调仓机会，调仓后组合须保留至少 1 只指数。")
    sys.exit(0 if verdict else 2)


def main():
    ap = argparse.ArgumentParser(description="国金股指大赛组合规则校验")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("validate", help="校验组合")
    p.add_argument("holdings", nargs="+", help="指数代码:权重，如 SIA000254:25 SIA104037:25")
    p.set_defaults(func=cmd_validate)
    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
