# -*- coding: utf-8 -*-
"""
korea_copyright_timestamp —— 版权取证·韩国截图时间戳提取工具
================================================================
功能：从截图中识别 UTCk3 世界时钟(KRISS)的韩国标准时间，转换为中国时间(UTC+8)，
      输出到 Excel 表格，带文件名与取证顺序号。
版本：2.4.5 —— 修复三处可用性缺陷：①中文 Windows 重定向/管道下输出 ✗ 触发 UnicodeEncodeError，导致整批不产出 xlsx（现强制 UTF-8 兜底）；②不再把 --help 当未知参数（此前 rc=1）；③无参时返回 2 而非 0，避免失败被当成功。此前 2.4.4 —— 文档与依赖声明修正（SKILL.md 去掉本机绝对路径，依赖清单补齐可选引擎注释），功能无改动。此前 2.4.1 —— 绿色检测加 X 坐标约束（x>65%宽度），排除左侧站点绿 UI 干扰，修复 aidehui/xinhuatzym 等带绿色元素站点被误检导致坐标回退的问题。此前 2.4.0：跨午夜日期修正：24/7 分割回退(分割区读不出时间则退回未分割框重试) + 批次坐标回退(用批次众数裁剪框重试失败图)。此前 2.3.8： 自查加固：CLI 开关(--engine/--mode/--date)支持任意顺序；Excel 新增「识别模式」列(每张图标注 正常/24-7)；小图支持强制 --mode 247 分割(全高搜索)；清理死代码与注释。此前 2.3.7：24/7 工作模式(--mode 247/auto)自动垂直分割排除中国时间黑框 + 多数投票 + 日期片段排除 + RapidOCR 第三引擎 + K时中文简称

用法：
  # 批量处理（支持全屏截图和已裁剪表盘图片）
  python korea_copyright_timestamp.py [--date YYYY-MM-DD] <输入文件夹> [输出Excel路径]

  # 校准时钟位置（首次使用或挪动时钟后）
  python korea_copyright_timestamp.py --calibrate <样例截图路径>

  # 查看当前配置
  python korea_copyright_timestamp.py --show-config

  # 手动设定坐标
  python korea_copyright_timestamp.py --set-config <x0> <x1> <y0> <y1>

策略（三层回退）：
  1) 绿色LED表盘自动检测（颜色过滤 + 连通域聚类）
  2) 用户校准配置（~/.workbuddy/skills/korea-copyright-timestamp/config.json）
  3) 内置默认坐标（按 1703×1035 屏幕比例调校，自动适配任意分辨率）
  注：若输入图片本身已是裁剪好的表盘区域（< 800×300），跳过自动检测直接全图 OCR。

OCR 引擎（三引擎，主引擎 + 两个可选引擎）：
  1) Tesseract（主引擎，默认启用）—— 四种预处理（raw/green_bw/gray_bin/green_enhanced）互补，实测 100% 精度
  2) EasyOCR（可选，默认不启用）—— 需 torch，可识别韩文日期；仅在显式 --engine easyocr 或 Tesseract 不可用时启用
  3) RapidOCR（可选，默认不启用）—— 基于 rapidocr-onnxruntime 的 ONNX 推理，轻量无需 torch；
                                    仅在显式 --engine rapidocr 时启用（不适配 torch 环境时的最佳备选）

引擎选择：默认 auto（Tesseract → 回退 EasyOCR）；可用 --engine 显式指定。

依赖：pytesseract, Pillow, numpy, openpyxl, scipy
可选：easyocr, torch（EasyOCR）；rapidocr-onnxruntime, opencv-python, onnxruntime（RapidOCR）
安装：pip install pytesseract Pillow numpy openpyxl scipy
      + winget install UB-Mannheim.TesseractOCR  (Windows)
"""

from __future__ import annotations

import os
import re
import sys
import json
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
from PIL import Image
import openpyxl

# ---------------------------------------------------------------------------
# 控制台编码兜底
# ---------------------------------------------------------------------------
# 中文 Windows 下若 stdout 被重定向或经管道捕获（Agent / CI 的常规调用方式），
# Python 按 cp936 编码输出，本脚本的 ✗ / ✓ 等符号会抛 UnicodeEncodeError，
# 且在「逐图打印」阶段崩溃会导致整批结果 xlsx 完全不落盘。
# 这里统一强制 UTF-8 + replace，保证任何调用方式都不会因打印而中断。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# ---------------------------------------------------------------------------
# 路径与常量
# ---------------------------------------------------------------------------

# 技能根目录（无论脚本位于根目录还是 scripts/ 子目录，均解析到技能根，
# 以保证个人配置 config.json 始终落在技能根目录，便于 .gitignore 排除）
_SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = _SCRIPT_DIR.parent if _SCRIPT_DIR.name == "scripts" else _SCRIPT_DIR
CONFIG_FILE = SKILL_DIR / "config.json"

# 内置默认裁剪坐标（归一化比例 0~1，按 1703×1035 屏幕调校 —— 缩放时自动适配）
DEFAULT_CROP = {"x0": 0.755, "x1": 0.93, "y0": 0.15, "y1": 0.23}

# 模块级日期覆盖（由 --date CLI 参数设置）
_override_date = None  # type: datetime | None

# ---------------------------------------------------------------------------
# 配置管理
# ---------------------------------------------------------------------------

def load_user_config() -> dict | None:
    """读取用户的裁剪配置，不存在返回 None"""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8")).get("crop_box")
        except Exception:
            return None
    return None


def save_user_config(crop_box: dict) -> None:
    """保存用户裁剪配置"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(
        json.dumps({"crop_box": crop_box, "comment": "UTCk3 时钟表盘裁剪框，归一化比例 0~1"}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"✓ 配置已保存至: {CONFIG_FILE}")


def show_config():
    """显示当前配置状态"""
    cfg = load_user_config()
    if cfg:
        print(f"当前用户配置: {cfg}")
    else:
        print("无用户自定义配置，处理时将使用自动检测。")
    print(f"配置文件路径: {CONFIG_FILE}")


# ---------------------------------------------------------------------------
# 绿色LED表盘自动检测
# ---------------------------------------------------------------------------

def detect_clock_bbox(img: Image.Image, mode: str = "auto",
                      full_height: bool = False) -> dict | None:
    """
    用颜色过滤 + 连通域 + 空间聚类自动定位 UTCk3 时钟的绿色LED表盘区域。

    原理：
    - UTCk3 时钟的黑底绿色 LED 数字极其独特：G 通道远高于 R/B
    - 过滤 → 连通域标注 → 剔除小噪点 → 空间聚类合并相邻字符
    - 取像素面积最大的聚类作为表盘

    v2.3.7 新增 mode 参数：
      "normal"  — 兼容旧版正常白天工作截图，不做垂直分割
      "247"     — 24/7 工作模式：UTCK3 上方有中国时间黑框（也含绿字），
                  自动垂直分割，只裁剪下方 UTCK3 表盘区域，避免 OCR 读到
                  两个时间而触发误报复核。
      "auto"    — 自动检测：若发现两个垂直分离的大绿簇则启用 24/7 逻辑

    v2.3.8 新增 full_height 参数：
      已裁剪小图在强制 247 模式下需要全高搜索（时间行可能位于下半部）。

    返回: {'x0','x1','y0','y1', 'split_247': bool} 或 None
    split_247=True 表示触发了 24/7 垂直分割（上方区域已被排除）。
    """
    try:
        arr = np.array(img.convert("RGB"), dtype=np.int16)
    except Exception:
        return None
    h, w = arr.shape[:2]

    # 颜色过滤：亮绿色，G > 130 且 G 显著大于 R 和 B
    r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
    green_mask = (g > 130) & (g > r + 60) & (g > b + 60)

    # 只搜索右上角区域（UTCK3 时钟永远在屏幕右侧，x > 65% 宽度）；
    # 此约束排除左侧站点绿 UI（logo/按钮/导航）干扰，修复 aidehui/xinhuatzym
    # 等带绿色元素的站点被误检的问题。（v2.4.1）
    right_edge = int(w * 0.65)
    green_mask[:, :right_edge] = False

    # 只搜索上半屏（时钟在右上角，不需要扫描全屏）；
    # 小图强制 247 时全高搜索（v2.3.8）
    if not full_height:
        half = int(h * 0.5)
        green_mask[half:, :] = False

    if not green_mask.any():
        return None

    # 连通域标注
    try:
        from scipy import ndimage
    except ImportError:
        # 无 scipy 时回退配置或默认值
        return None

    labeled, num_features = ndimage.label(green_mask)

    # 收集每个连通域的包围盒与重心（忽略面积<5 的噪点）
    components = []
    for i in range(1, num_features + 1):
        ys, xs = np.where(labeled == i)
        area = len(xs)
        if area < 5:
            continue
        components.append({
            "x0": xs.min(), "x1": xs.max(),
            "y0": ys.min(), "y1": ys.max(),
            "cx": xs.mean(), "cy": ys.mean(),
            "area": area,
        })

    if not components:
        return None

    # 空间聚类：水平距离<80px 且 垂直<30px 的连通域合并（连接同一行数字字符）
    clusters = []
    for c in components:
        merged = False
        for cl in clusters:
            if abs(c["cx"] - cl["cx"]) < 80 and abs(c["cy"] - cl["cy"]) < 30:
                cl["x0"] = min(cl["x0"], c["x0"])
                cl["x1"] = max(cl["x1"], c["x1"])
                cl["y0"] = min(cl["y0"], c["y0"])
                cl["y1"] = max(cl["y1"], c["y1"])
                cl["area"] += c["area"]
                # 加权更新重心
                old_w = cl.get("n", cl["area"])
                cl["cx"] = (cl["cx"] * old_w + c["cx"] * c["area"]) / (old_w + c["area"])
                cl["cy"] = (cl["cy"] * old_w + c["cy"] * c["area"]) / (old_w + c["area"])
                cl["n"] = old_w + c["area"]
                merged = True
                break
        if not merged:
            cl = c.copy()
            cl["n"] = c["area"]
            clusters.append(cl)

    if not clusters:
        return None

    # 选种子 = 像素面积最大的聚类（通常是时钟的某一行/某一片绿字）
    seed = max(clusters, key=lambda x: x["area"])

    # 单遍吸收：以种子为起点，吸收所有与之间隙较小（水平<250px、垂直<160px）的
    # 聚类，将同属一块表盘的碎片（如被间距拆散的时间行各位数字）合并为一个整体，
    # 避免只裁到单个数字/冒号导致 OCR 漏识。（修复 v2.3.2 已知缺陷：268 号图因
    # 时间行数字间距>80px 而被拆成多个小聚类，max(area) 只取到其中一片，OCR 仅得 ':'）
    box = {"x0": seed["x0"], "x1": seed["x1"],
           "y0": seed["y0"], "y1": seed["y1"]}
    absorbed = []  # v2.3.8: 记录被吸收进表盘框的聚类，供 24/7 分割只在框内进行
    for cl in clusters:
        gap_x = max(box["x0"] - cl["x1"], cl["x0"] - box["x1"], 0)
        gap_y = max(box["y0"] - cl["y1"], cl["y0"] - box["y1"], 0)
        if gap_x < 250 and gap_y < 160:
            box["x0"] = min(box["x0"], cl["x0"])
            box["x1"] = max(box["x1"], cl["x1"])
            box["y0"] = min(box["y0"], cl["y0"])
            box["y1"] = max(box["y1"], cl["y1"])
            absorbed.append(cl)

    # ── v2.3.7: 24/7 模式垂直分割 ──────────────────────────────────────
    # 24/7 工作模式下，UTCK3 上方会增加一个黑色小方框显示中国时间（绿字）。
    # 这导致上方多出一块独立绿色区域，若被合并进裁剪框，OCR 会同时读到
    # 中国时间 + KST 时间，触发一致性误报复核。
    # 策略：将聚类按垂直位置排序，寻找显著间隙（>40px 无绿像素），
    # 若存在则只保留下方聚类组（UTCK3 表盘），丢弃上方（中国时间黑框）。
    # v2.3.8 修正：分割只在「已吸收进表盘框的聚类」内进行（旧版误用全屏所有
    # 聚类，可能把屏幕远处的杂散绿色 UI 一并纳入排序，布局变化时有误分割风险）。
    # split_247 仅当分割真正收窄了裁剪框时才置位（用于「识别模式」列审计）。
    split_247 = False
    if mode in ("247", "auto") and len(absorbed) >= 2:
        sorted_cl = sorted(absorbed, key=lambda c: c["cy"])
        best_gap = 0
        split_idx = -1  # 在 sorted_cl[split_idx] 之后分割（下方从 split_idx+1 开始）
        for i in range(len(sorted_cl) - 1):
            gap = sorted_cl[i + 1]["y0"] - sorted_cl[i]["y1"]
            if gap > best_gap:
                best_gap = gap
                split_idx = i
        # 间隙阈值：40px 以上才算两个独立区域（正常表盘内行间距<30px）
        if best_gap > 40:
            lower_clusters = sorted_cl[split_idx + 1:]
            upper_clusters = sorted_cl[:split_idx + 1]
            lower_area = sum(c["area"] for c in lower_clusters)
            upper_area = sum(c["area"] for c in upper_clusters)
            # v2.4.6：上方区域必须达到绝对体量下限，否则判为噪点，而非中国时间黑框。
            # 依据：24/7 黑框内是 6 位以上绿色数字，实测面积数百至上千、字高≥8px；
            # 而浏览器标签栏/窗口边缘的绿色小图标面积仅数十、高 2~3px。
            # 修复 20261111 批次（109 张）：一个 37px、高 3px 的标签栏绿点与真表盘
            # 相隔 130px，仅凭「面积比 27:1 > 0.5」即触发分割，导致裁剪框被标注为
            # 24/7（实测裁剪框与读数均正确，仅「识别模式」列失真）。
            upper_h = max((c["y1"] - c["y0"]) for c in upper_clusters)
            looks_like_clock_box = (upper_area >= 100 or upper_h >= 8)
            # 下方区域面积需至少达到上方的一半才视为 UTCK3 表盘
            # （防止把 UTCK3 主体误当上方、把零星噪点误当下方保留）
            # 实测阈值 0.5：247 批次 180/180 正确分割，正常批次 41/41 零误触发
            if looks_like_clock_box and lower_area > upper_area * 0.5:
                new_box = {"x0": min(c["x0"] for c in lower_clusters),
                           "x1": max(c["x1"] for c in lower_clusters),
                           "y0": min(c["y0"] for c in lower_clusters),
                           "y1": max(c["y1"] for c in lower_clusters)}
                # 仅当分割真正改变裁剪框时才标记 24/7（避免正常图被误标）
                if new_box != box:
                    split_247 = True
                box = new_box

    # 加边距（15%~20%），确保包含完整的日期行+时间行
    bw, bh = box["x1"] - box["x0"], box["y1"] - box["y0"]
    pad_x = max(15, int(bw * 0.15))
    pad_y = max(10, int(bh * 0.20))
    x0 = max(0, box["x0"] - pad_x)
    x1 = min(w, box["x1"] + pad_x)
    y0 = max(0, box["y0"] - pad_y)
    y1 = min(h, box["y1"] + pad_y)

    return {"x0": x0, "x1": x1, "y0": y0, "y1": y1, "split_247": split_247}


# ---------------------------------------------------------------------------
# 校准模式
# ---------------------------------------------------------------------------

def calibrate(image_path: str, save: bool = True):
    """
    用一张样例截图自动检测时钟位置，裁剪后供用户确认，无误则保存配置。
    """
    if not os.path.isfile(image_path):
        print(f"错误：文件不存在 —— {image_path}")
        return

    img = Image.open(image_path).convert("RGB")
    w_, h_ = img.size
    print(f"图片尺寸: {w_}×{h_}")

    bbox = detect_clock_bbox(img)
    if bbox is None:
        print("✗ 自动检测失败：未在截图中找到绿色的 UTCk3 时钟数字。")
        print("  请确认截图包含右上角的 UTCk3 世界时钟窗口（绿色 LED 数字）。")
        print("  若始终无法自动检测，可使用 --set-config 手动设置坐标。")
        return

    x0, x1, y0, y1 = bbox["x0"], bbox["x1"], bbox["y0"], bbox["y1"]

    # 转为归一化坐标（0~1），适配不同分辨率
    norm_box = {
        "x0": round(x0 / w_, 4),
        "x1": round(x1 / w_, 4),
        "y0": round(y0 / h_, 4),
        "y1": round(y1 / h_, 4),
    }

    print(f"检测到时钟表盘区域:")
    print(f"  像素坐标: ({x0},{y0}) → ({x1},{y1})  [{x1-x0}×{y1-y0}]")
    print(f"  归一化:   x=[{norm_box['x0']:.3f}, {norm_box['x1']:.3f}]  y=[{norm_box['y0']:.3f}, {norm_box['y1']:.3f}]")

    # 裁剪预览图（保存到用户临时目录，避免技能目录只读时失败）
    preview = img.crop((x0, y0, x1, y1))
    preview = preview.resize((preview.width * 2, preview.height * 2), Image.LANCZOS)
    import tempfile
    preview_path = os.path.join(tempfile.gettempdir(), "korea_clock_calibrate_preview.png")
    preview.save(preview_path)
    print(f"\n裁剪预览已保存至: {preview_path}")
    print("请打开此文件，确认裁剪区域是否完整地包含了日期行和时间行。")

    if save:
        save_user_config(norm_box)
        print("✓ 下次处理时将优先使用此坐标。")
        print("  如需重新校准，请再次运行 --calibrate。")
        print("  如需清除配置恢复自动检测，请删除配置文件。")
    else:
        print("(预览模式，未保存配置)")


# ---------------------------------------------------------------------------
# 裁剪策略：自动检测 → 用户配置 → 默认值
# ---------------------------------------------------------------------------

def get_crop_box(img: Image.Image, mode: str = "auto") -> tuple[int, int, int, int, bool]:
    """
    三层策略获取裁剪框：
    1) 自动检测绿色LED表盘
    2) 用户校准配置文件
    3) 内置默认坐标（归一化比例，按实际尺寸缩放）

    v2.3.7: mode 参数透传给 detect_clock_bbox（支持 24/7 垂直分割）
    v2.3.8: 返回值追加 split_247 标记；已裁剪小图在强制 --mode 247 下
            也运行分割检测（全高搜索），auto/normal 下保持原行为不变。

    返回: (x0, x1, y0, y1, split_247) 绝对像素坐标 + 是否触发 24/7 分割
    """
    w, h = img.size

    # 如果图片本身就是已裁剪的表盘区域（小图），直接使用全图，不再二次裁剪
    # 全屏截图通常 ≥ 1280×720，已裁剪表盘通常 < 800×300
    # 必须两个维度同时小于阈值才判定为小图（避免竖屏截图被误判）
    if w < 800 and h < 300:
        # v2.3.8: 仅在用户显式 --mode 247 时才对小图做分割检测
        # （auto 不做，避免改变既有小图全图 OCR 行为，保证零回归）
        if mode == "247":
            bbox = detect_clock_bbox(img, mode="247", full_height=True)
            if bbox is not None and bbox.get("split_247"):
                return bbox["x0"], bbox["x1"], bbox["y0"], bbox["y1"], True
        return 0, w, 0, h, False

    # 1) 自动检测
    bbox = detect_clock_bbox(img, mode=mode)
    if bbox is not None:
        return (bbox["x0"], bbox["x1"], bbox["y0"], bbox["y1"],
                bool(bbox.get("split_247")))

    # 2) 用户配置
    cfg = load_user_config()
    if cfg:
        x0 = int(cfg["x0"] * w)
        x1 = int(cfg["x1"] * w)
        y0 = int(cfg["y0"] * h)
        y1 = int(cfg["y1"] * h)
        return x0, x1, y0, y1, False

    # 3) 默认值
    x0 = int(DEFAULT_CROP["x0"] * w)
    x1 = int(DEFAULT_CROP["x1"] * w)
    y0 = int(DEFAULT_CROP["y0"] * h)
    y1 = int(DEFAULT_CROP["y1"] * h)
    return x0, x1, y0, y1, False


# ---------------------------------------------------------------------------
# OCR 引擎（双引擎：Tesseract 主引擎 + EasyOCR 可选引擎）
# ---------------------------------------------------------------------------

def _find_tesseract_exe() -> str | None:
    """查找系统中的 Tesseract OCR 可执行文件"""
    import subprocess
    # 常见安装路径（Windows + Unix）
    candidates = [
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        os.path.join(os.path.expanduser("~"), "AppData", "Local",
                     "Programs", "Tesseract-OCR", "tesseract.exe"),
        "/usr/bin/tesseract",
        "/usr/local/bin/tesseract",
        "/opt/homebrew/bin/tesseract",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    # 尝试 PATH 查找（跨平台）
    try:
        cmd = "where" if sys.platform == "win32" else "which"
        result = subprocess.run([cmd, "tesseract"], capture_output=True, text=True)
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().split("\n")[0]
    except Exception:
        pass
    return None


def _extract_green_enhanced(arr: np.ndarray) -> np.ndarray:
    """
    增强版绿色像素提取（v2.3 新增）。

    原理：既然所有目标信息都是黑底绿字，用归一化通道比例取代固定 RGB 差值，
    配合形态学闭运算连接 LED 断点、自适应亮度阈值、小噪点过滤。

    相比旧版 green_bw（固定 g>80 & g>r+30 & g>b+30）：
    - 用 g/total 比例替代绝对差值，对亮度变化鲁棒
    - 用 g/max(r,b) 比值确保绿色真正占主导
    - 自适应亮度下限（基于图像统计）替代固定阈值
    - 形态学闭运算填充 LED 数字段间缝隙
    - 过滤 < 10 像素的噪点

    返回: 黑字白底的 RGB uint8 数组
    """
    r = arr[:, :, 0].astype(float)
    g = arr[:, :, 1].astype(float)
    b = arr[:, :, 2].astype(float)

    total = r + g + b + 1.0  # 防除零
    g_ratio = g / total                # 绿色占亮度比例
    max_rb = np.maximum(r, b)
    g_dominance = g / (max_rb + 1.0)   # 绿色对红/蓝的优势倍数

    # 自适应亮度下限：取绿色通道中 >10 的像素的 15 分位数，至少 25
    green_pixels = g[g > 10]
    brightness_floor = float(np.percentile(green_pixels, 15)) if len(green_pixels) > 100 else 25.0
    brightness_floor = max(25.0, min(brightness_floor, 100.0))

    # 综合掩码：绿色占比高 + 绿色显著强于红蓝 + 足够亮
    mask = (g_ratio > 0.38) & (g_dominance > 1.3) & (g > brightness_floor)

    if not mask.any():
        # 回退到旧版固定阈值
        mask = (g > 80) & (g > r + 30) & (g > b + 30)

    # 形态学闭运算：先膨胀后腐蚀，连接 LED 段落间的缝隙
    try:
        from scipy import ndimage
        struct = np.ones((2, 2))
        mask = ndimage.binary_closing(mask, structure=struct, iterations=1)
        # 去除 < 10 像素的小噪点
        labeled, n_features = ndimage.label(mask)
        if n_features > 0:
            sizes = np.bincount(labeled.ravel())
            keep = sizes >= 10
            keep[0] = 0
            mask = keep[labeled]
    except ImportError:
        pass

    # 输出黑字白底
    bw = np.full_like(arr, 255, dtype=np.uint8)
    bw[mask] = [0, 0, 0]
    return bw


class _TesseractEngine:
    """Tesseract OCR 包装器，提供与 EasyOCR 兼容的接口（无 torch 依赖）"""

    def __init__(self):
        import pytesseract
        exe = _find_tesseract_exe()
        if not exe:
            raise RuntimeError(
                "未找到 Tesseract OCR。请安装: winget install UB-Mannheim.TesseractOCR\n"
                "或从 https://github.com/UB-Mannheim/tesseract/wiki 下载。"
            )
        pytesseract.pytesseract.tesseract_cmd = exe
        # 记录每个策略的独立文本，用于一致性警告时展示各策略读数（v2.3.1）
        self.last_strategy_texts: dict[str, str] = {}

    def readtext(self, image_np: np.ndarray, detail=1, paragraph=False, allowlist="") -> list:
        """
        多策略 OCR 读取，返回与 EasyOCR 兼容的格式。

        对同一张图片应用四种预处理，各自 OCR 后合并结果：
        1. raw            — 原图直接识别（保留作为回退，精度 38%）
        2. green_bw       — RGB 固定阈值绿色提取（保留，精度 98.5%）
        3. gray_bin       — 灰度阈值二值化（保留，精度 98.5%）
        4. green_enhanced — v2.3 新增：归一化绿色比例 + 形态学 + 自适应阈值

        四策略文本合并后由 _find_last_time 取最后去重有效时间。
        每个策略的独立 OCR 文本记录在 last_strategy_texts 中，
        一致性警告时会展示各策略读数供人工核对。
        """
        import pytesseract
        img = Image.fromarray(image_np)
        arr = np.array(img)
        config = "--psm 6 -c tessedit_char_whitelist=0123456789:"
        all_lines = []
        self.last_strategy_texts = {}  # 清空上次结果

        # 策略1: raw 原图
        try:
            t = pytesseract.image_to_string(img, lang="eng", config=config).strip()
            self.last_strategy_texts["raw"] = t
            for line in t.split("\n"):
                if line.strip():
                    all_lines.append((None, line.strip(), 1.0))
        except Exception:
            pass

        # 策略2: green_bw — 绿色像素提取 → 黑字白底
        try:
            r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
            gmask = (g > 80) & (g > r + 30) & (g > b + 30)
            bw = np.full_like(arr, 255)
            bw[gmask] = [0, 0, 0]
            t = pytesseract.image_to_string(Image.fromarray(bw), lang="eng", config=config).strip()
            self.last_strategy_texts["green_bw"] = t
            for line in t.split("\n"):
                if line.strip():
                    all_lines.append((None, line.strip(), 1.0))
        except Exception:
            pass

        # 策略3: gray_bin — 灰度阈值二值化
        try:
            gray_arr = np.array(img.convert("L"))
            gray_bin = np.where(gray_arr > 80, 0, 255).astype(np.uint8)
            t = pytesseract.image_to_string(Image.fromarray(gray_bin), lang="eng", config=config).strip()
            self.last_strategy_texts["gray_bin"] = t
            for line in t.split("\n"):
                if line.strip():
                    all_lines.append((None, line.strip(), 1.0))
        except Exception:
            pass

        # 策略4: green_enhanced（v2.3 新增）—— HSV 归一化比例 + 形态学 + 自适应阈值
        # 放在最后 → _find_last_time 取最后一个有效时间 → 此策略精度最高，优先级最高
        try:
            enhanced_bw = _extract_green_enhanced(arr)
            t = pytesseract.image_to_string(Image.fromarray(enhanced_bw), lang="eng", config=config).strip()
            self.last_strategy_texts["green_enhanced"] = t
            for line in t.split("\n"):
                if line.strip():
                    all_lines.append((None, line.strip(), 1.0))
        except Exception:
            pass

        return all_lines


def _init_easyocr():
    """尝试初始化 EasyOCR（需要 torch 环境正常）"""
    import easyocr
    return easyocr.Reader(["ko", "en"], gpu=False)


class _RapidOCREngine:
    """RapidOCR 引擎包装器（可选第三引擎，需 rapidocr-onnxruntime + opencv-python + onnxruntime）。

    与 _TesseractEngine / EasyOCR 保持兼容接口：提供 readtext(...) 方法，
    返回 [(bbox, text, score), ...] 形式的列表，供 extract_timestamp_from_image 统一消费。

    RapidOCR 基于 ONNX 推理，无需 torch，是 torch 环境不可用时的轻量备选；
    但默认不启用，仅在显式 --engine rapidocr 时才会初始化。
    """

    def __init__(self):
        from rapidocr_onnxruntime import RapidOCR
        import logging
        # RapidOCR 默认会打印较多初始化日志，调低 verbosity 避免刷屏
        logging.getLogger("rapidocr").setLevel(logging.WARNING)
        self._engine = RapidOCR()
        # 与 Tesseract 引擎一致，记录最后一次 OCR 文本用于一致性复核提示
        self.last_strategy_texts: dict[str, str] = {}

    def readtext(self, image_np: np.ndarray, detail=1, paragraph=False, allowlist="") -> list:
        """与 EasyOCR / Tesseract 兼容的接口。

        RapidOCR 不支持字符白名单参数，直接对整图做 OCR，
        由 _find_last_time 的合法时间正则负责过滤有效时间。
        注意：RapidOCR 内部期望 BGR 通道顺序（与 cv2.imread 一致），需将 RGB 转为 BGR。
        """
        try:
            import cv2
            bgr = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)
        except Exception:
            # 没有 cv2 时尽力而为（颜色可能略有偏差，但通常仍可识别）
            bgr = image_np

        result, _ = self._engine(bgr)
        out = []
        texts = []
        if result:
            for box, text, score in result:
                out.append((box, text, score))
                if text and text.strip():
                    texts.append(text.strip())

        full = " ".join(texts)
        self.last_strategy_texts = {"rapidocr": full}
        return out


_ocr_engine = None
_ocr_engine_type = None  # "tesseract" | "easyocr" | "rapidocr"


def get_ocr_engine(engine: str = "auto"):
    """
    获取 OCR 引擎实例。

    引擎参数：
      "auto"       —— 默认：Tesseract 优先，未安装则回退 EasyOCR（保持向后兼容）
      "tesseract"  —— 主引擎（默认启用，无需 torch，数字白名单模式）
      "easyocr"    —— 可选引擎（需 torch，支持韩文日期），默认不启用
      "rapidocr"   —— 可选第三引擎（需 rapidocr-onnxruntime），默认不启用，需显式选择

    EasyOCR / RapidOCR 均为「默认不启用」的可选引擎，只有显式 --engine 指定
    或 Tesseract 不可用（auto 模式）时才会启用，不会替换主引擎。
    """
    global _ocr_engine, _ocr_engine_type

    # 显式指定引擎：首次构建并缓存（同类型直接复用）
    if engine != "auto":
        if _ocr_engine is not None and _ocr_engine_type == engine:
            return _ocr_engine
        if engine == "tesseract":
            _ocr_engine = _TesseractEngine()
            _ocr_engine_type = "tesseract"
            print("[OCR] 使用 Tesseract 引擎（数字白名单模式）")
        elif engine == "easyocr":
            _ocr_engine = _init_easyocr()
            _ocr_engine_type = "easyocr"
            print("[OCR] 使用 EasyOCR 引擎（韩文+英文模型）")
        elif engine == "rapidocr":
            _ocr_engine = _RapidOCREngine()
            _ocr_engine_type = "rapidocr"
            print("[OCR] 使用 RapidOCR 引擎（ONNX 推理，可选第三引擎）")
        else:
            raise ValueError(f"未知 OCR 引擎: {engine}（可选 tesseract / easyocr / rapidocr）")
        return _ocr_engine

    # auto 模式：Tesseract 优先，回退 EasyOCR（保持向后兼容）
    if _ocr_engine is not None:
        return _ocr_engine
    try:
        _ocr_engine = _TesseractEngine()
        _ocr_engine_type = "tesseract"
        print("[OCR] 使用 Tesseract 引擎（数字白名单模式）")
        return _ocr_engine
    except RuntimeError:
        pass  # Tesseract 未安装

    # 回退到 EasyOCR
    try:
        _ocr_engine = _init_easyocr()
        _ocr_engine_type = "easyocr"
        print("[OCR] 使用 EasyOCR 引擎（韩文+英文模型）")
        return _ocr_engine
    except Exception as e:
        raise RuntimeError(
            f"无可用的 OCR 引擎。\n"
            f"  Tesseract: {_find_tesseract_exe() or '未安装'}\n"
            f"  EasyOCR: {e}\n"
            f"请安装 Tesseract: winget install UB-Mannheim.TesseractOCR\n"
            f"或修复 torch 环境后安装 EasyOCR: pip install easyocr"
        )


def _ocr_crop(img: Image.Image, box, reader) -> dict:
    """对指定裁剪框执行 OCR（放大 3 倍提升小字识别率）。

    返回: {'text': str, 'consistency': 'ok'|'warn'}
    """
    x0, x1, y0, y1 = box
    dial = img.crop((x0, y0, x1, y1))
    dial = dial.resize((max(1, dial.width * 3), max(1, dial.height * 3)), Image.LANCZOS)
    ocr_results = reader.readtext(
        np.array(dial), detail=1, paragraph=False,
        allowlist="0123456789:년월일 ",
    )
    text = " ".join(item[1] for item in ocr_results)
    return {"text": text, "consistency": _check_time_consistency(text)}


def extract_timestamp_from_image(image_path: str, reader, mode: str = "auto",
                                 force_box=None) -> dict:
    """
    从截图中提取时间戳。

    force_box: (x0, x1, y0, y1) —— 显式指定裁剪框、跳过自动检测。
               供批次坐标回退（process_images 第二遍）使用。

    v2.3.9 新增「24/7 分割回退」：auto 模式下若垂直分割后的区域读不出时间，
    自动退回未分割的裁剪框重试一次。修复正常截图中时钟下方存在杂散绿色元素
    时，分割误把真表盘当作「上方中国时间黑框」丢弃而导致识别失败的缺陷。

    返回: {
        'korea_time': datetime | None,
        'china_time': datetime | None,
        'raw_text': str,
        'success': bool,
        'layout': str,
        'crop_box': tuple | None,
    }
    """
    result = {"korea_time": None, "china_time": None, "raw_text": "", "success": False,
              "consistency": "ok", "warning": "", "layout": "正常", "crop_box": None}

    try:
        img = Image.open(image_path).convert("RGB")
        fallback_date = _fallback_date_from_path(image_path)

        # 组织裁剪尝试序列（依次尝试，命中即止）
        if force_box is not None:
            attempts = [(tuple(int(v) for v in force_box), "正常(坐标回退)")]
        else:
            # 三层裁剪策略（v2.3.8: 返回值带 split_247 标记）
            x0, x1, y0, y1, split_247 = get_crop_box(img, mode=mode)
            attempts = [((x0, x1, y0, y1), "24/7" if split_247 else "正常")]
            if split_247 and mode == "auto":
                nx0, nx1, ny0, ny1, _ = get_crop_box(img, mode="normal")
                if (nx0, nx1, ny0, ny1) != (x0, x1, y0, y1):
                    attempts.append(((nx0, nx1, ny0, ny1), "正常(分割回退)"))

        # 时间提取：使用合并文本 + 去重模式（经 68 张实测验证最可靠）
        # 策略优先级提取在 199.png 上反而引入回归（green_enhanced 与 green_bw 共享
        # 绿色通道偏差，3:1 多数票反而压倒 gray_bin 的正确结果）
        korea_time = None
        for box, layout in attempts:
            info = _ocr_crop(img, box, reader)
            full_text = info["text"]
            result["raw_text"] = full_text
            result["consistency"] = info["consistency"]
            result["layout"] = layout
            result["crop_box"] = tuple(int(v) for v in box)
            korea_time = _parse_korean_timestamp(full_text, fallback_date)
            if korea_time:
                break

        if korea_time:
            result["korea_time"] = korea_time
            result["china_time"] = korea_time - timedelta(hours=1)
            result["success"] = True

            # 收集警告
            warnings = []
            if result["consistency"] == "warn":
                warn_msg = "多策略结果不一致，建议人工复核"
                # v2.3.1：附加每个策略的独立读数，方便人工核对
                if hasattr(reader, "last_strategy_texts") and reader.last_strategy_texts:
                    details = []
                    for sname, stext in reader.last_strategy_texts.items():
                        st = _find_last_time(stext) if stext else None
                        details.append(f"{sname}={'%02d:%02d:%02d' % st if st else '无'}")
                    warn_msg += f"（{' | '.join(details)}）"
                warnings.append(warn_msg)
            result["warning"] = "; ".join(warnings)
        else:
            # 区分失败原因（以最后一次尝试的 OCR 文本为准）
            if _find_last_time(result["raw_text"]) is None:
                result["warning"] = "未识别到有效时间"
            else:
                result["warning"] = "日期缺失，请使用 --date YYYY-MM-DD 指定日期"

    except Exception as e:
        result["raw_text"] = f"[异常] {e}"

    return result


def _date_fragment_windows(text: str) -> set:
    """返回文本中伪日期(年月日)的 6 位窗口集合，用于排除被 HHMMSS 正则误判的时间。

    RapidOCR 等引擎会把韩文日期行「2026년 07월 25일」读成「202607号25」，
    其前 6 位「202607」会被 HHMMSS 正则误当成时间 20:26:07，与真时间冲突、
    导致一致性检查误报「需人工复核」。这里把日期规范成 8 位 YYYYMMDD 后，
    取其所有连续 6 位窗口作为「日期片段」集合，供 _find_all_valid_times 跳过。
    """
    wins: set = set()
    for m in re.finditer(r"(20\d{2}|19\d{2})\D*(\d{2})\D*(\d{2})", text):
        y, mo, d = m.group(1), m.group(2), m.group(3)
        if 1 <= int(mo) <= 12 and 1 <= int(d) <= 31:
            canon = y + mo + d  # 8 位规范日期
            for i in range(len(canon) - 5):
                wins.add(canon[i:i + 6])
    return wins


def _iter_time_candidates(text: str):
    """逐个产出文本中所有合法时间 (start_pos, (h, mi, s))，保留出现次数（用于多数投票）。

    v2.3.5：排除被 HHMMSS 正则误判的 8 位日期片段（如 202607 → 20:26:07），
    避免 RapidOCR 等引擎读取的日期「20260725 / 202607号25」触发误报。
    """
    date_windows = _date_fragment_windows(text)
    patterns = [
        r"(?<![\d:])(\d{1,2}):(\d{2}):(\d{2})(?![\d:])",   # HH:MM:SS
        r"(?<![\d:])(\d{2})(\d{2}):(\d{2})(?![\d:])",      # HHMM:SS
        r"(?<![\d:])(\d{1,2}):(\d{2})(\d{2})(?![\d:])",    # HH:MMSS
        r"(?<!\d)(\d{2})(\d{2})(\d{2})(?!\d)",              # HHMMSS
    ]
    for pat in patterns:
        for m in re.finditer(pat, text):
            h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if 0 <= h <= 23 and 0 <= mi <= 59 and 0 <= s <= 59:
                # v2.3.5：跳过作为 8 位日期片段的 6 位数字（如 202607）
                if f"{h:02d}{mi:02d}{s:02d}" in date_windows:
                    continue
                yield (m.start(), (h, mi, s))


def _find_all_valid_times(text: str) -> list[tuple[int, int, int]]:
    """返回 OCR 文本中所有合法时间 (h, m, s)，去重后按出现顺序排列。"""
    seen = set()
    result = []
    for _, t in sorted(_iter_time_candidates(text)):
        if t not in seen:
            seen.add(t)
            result.append(t)
    return result


def _majority_time(text: str):
    """在 OCR 文本中对所有合法时间做多数投票，返回 (h, mi, s) 或 None。

    v2.3.5 新增：替代「取最后一个不同时间」(易采纳少数派错读)。
    多策略引擎(如 Tesseract)会把各策略读数拼进同一文本，对全部合法时间按出现次数
    投票即可得到多数策略支持的结果；单引擎(RapidOCR/EasyOCR)文本通常只含一个时间，
    退化为取该时间。平票时返回首次出现的时间。
    """
    from collections import Counter
    occ = list(_iter_time_candidates(text))
    if not occ:
        return None
    cnt = Counter(t for _, t in occ)
    maxc = max(cnt.values())
    winners = [t for t, c in cnt.items() if c == maxc]
    if len(winners) == 1:
        return winners[0]
    # 平票：返回首次出现者（位置最靠前）
    for _, t in sorted(occ):
        if t in winners:
            return t
    return winners[0]


def _find_last_time(text: str):
    """在 OCR 文本中取最后出现的合法时间（时, 分, 秒）"""
    candidates = _find_all_valid_times(text)
    if not candidates:
        return None
    return candidates[-1]


def _check_time_consistency(text: str) -> str:
    """
    检查 OCR 多策略结果的时间一致性。
    返回: "ok"（一致或无结果） | "warn"（多策略读出不同时间，需人工复核）
    """
    candidates = _find_all_valid_times(text)
    if len(candidates) <= 1:
        return "ok"
    # 检查是否所有候选时间完全一致
    if len(set(candidates)) == 1:
        return "ok"
    return "warn"


def _fallback_date_from_path(image_path: str):
    """从路径推断日期，多级回退：文件名 → 文件夹名 → CLI 覆�� → None
    仅支持 YYYYMMDD 格式（含 20 前缀年份），如 20260723 或 2026_07_23。
    不支持 4 位 MMDD 格式（如 0723），需用 --date 参数指定。"""
    # CLI --date 覆盖优先级最高
    if _override_date:
        return _override_date.year, _override_date.month, _override_date.day

    name = os.path.basename(image_path)
    m = re.search(r"(20\d{2})[_\s-]*(\d{2})[_\s-]*(\d{2})", name)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return y, mo, d
    # 从文件夹名推断（如 20260723 → 2026 年 7 月 23 日）
    parent = os.path.basename(os.path.dirname(image_path))
    m = re.search(r"20(\d{2})[_\s-]*(\d{2})[_\s-]*(\d{2})", parent)
    if m:
        y, mo, d = 2000 + int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return y, mo, d
    return None


def _parse_korean_timestamp(text: str, fallback_date=None) -> datetime | None:
    """解析 OCR 文本中的韩国时间戳"""
    text = text.strip()

    # 日期
    date = None
    m = re.search(r"(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일", text)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            date = (y, mo, d)
    if date is None and fallback_date:
        date = fallback_date
    if date is None:
        return None  # 日期无法确定，强制失败（不再静默使用当天日期）

    # 时间（v2.3.5：多数投票，替代「取最后一个不同时间」以修少数派错读）
    tp = _majority_time(text)
    if tp is None:
        return None
    h, mi, s = tp
    return datetime(date[0], date[1], date[2], h, mi, s)


# ---------------------------------------------------------------------------
# 文件名顺序号提取
# ---------------------------------------------------------------------------

def extract_sequence_number(filename: str) -> int:
    """
    从截图文件名中提取数字顺序号，用于表格排序。
    规则: cn{数字}-ZX → {数字}-ZX → 最后一组连续数字 → 极大值(排末尾)
    """
    m = re.search(r"cn(\d+)-ZX", filename)
    if m:
        return int(m.group(1))
    m = re.search(r"(\d+)-ZX", filename)
    if m:
        return int(m.group(1))
    nums = re.findall(r"\d+", filename)
    if nums:
        return int(nums[-1])
    return 10 ** 9


# ---------------------------------------------------------------------------
# 批量处理
# ---------------------------------------------------------------------------

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp"}


def process_images(input_dir: str, output_file: str, engine: str = "auto", mode: str = "auto"):
    """批量处理文件夹下的所有图片，提取时间戳并输出到 Excel

    engine: "auto"(默认) | "tesseract" | "easyocr" | "rapidocr"
    mode:   "auto"(默认) | "normal" | "247"
            auto  — 自动检测是否为 24/7 模式（若发现上下两个分离绿簇则启用）
            normal — 强制正常模式（兼容旧版白天工作截图，不做垂直分割）
            247   — 强制 24/7 模式（UTCK3 上方有中国时间黑框，自动排除）
    """

    input_path = Path(input_dir)

    if input_path.is_file():
        image_files = [input_path] if input_path.suffix.lower() in IMAGE_EXTS else []
    elif input_path.is_dir():
        # 大小写不敏感去重
        seen = {}
        for ext in IMAGE_EXTS:
            for p in input_path.glob(f"*{ext}"):
                seen[p.resolve()] = p
            for p in input_path.glob(f"*{ext.upper()}"):
                seen[p.resolve()] = p
        image_files = list(seen.values())
        image_files.sort(key=lambda x: (extract_sequence_number(x.name), x.name.lower()))
    else:
        print(f"[错误] 路径不存在: {input_dir}")
        return

    if not image_files:
        print(f"[警告] 在 {input_dir} 中未找到任何图片文件")
        return

    print(f"找到 {len(image_files)} 张图片，开始处理...")
    print("=" * 60)

    print("正在初始化 OCR 引擎...")
    reader = get_ocr_engine(engine)
    print("OCR 引擎就绪\n")

    results = []
    success_count = 0
    warn_count = 0
    success_boxes = []  # v2.3.9: 记录成功样本的裁剪框，供批次坐标回退取众数

    for idx, img_path in enumerate(image_files, 1):
        filename = img_path.name
        print(f"[{idx}/{len(image_files)}] {filename}")

        r = extract_timestamp_from_image(str(img_path), reader, mode=mode)

        cn_str = ""
        layout_tag = f"[{r.get('layout', '正常')}]"
        if r["success"]:
            cn_dt = r["china_time"]
            kr_dt = r["korea_time"]
            cn_str = cn_dt.strftime("%Y-%m-%d %H:%M:%S")
            success_count += 1
            if r.get("crop_box"):
                success_boxes.append(r["crop_box"])
            status_mark = "⚠" if r.get("warning") else "✓"
            print(f"  {status_mark} {layout_tag} KST: {kr_dt.strftime('%Y-%m-%d %H:%M:%S')}  →  CST: {cn_str}")
            if r.get("warning"):
                warn_count += 1
                print(f"     ⚠ {r['warning']}")
        else:
            cn_dt = None
            kr_dt = None
            print(f"  ✗ 失败  OCR: {r['raw_text'][:100]}")
            if r.get("warning"):
                print(f"     → {r['warning']}")

        results.append({
            "序号": idx,
            "顺序号": extract_sequence_number(filename),
            "文件名": filename,
            # 时间列写入真实 datetime（纯数据输出，便于用户在 Excel 中自由改格式）
            "中国时间": cn_dt if cn_dt else "[识别失败]",
            "中国时间_斜线": cn_dt if cn_dt else "[识别失败]",
            "韩国时间": kr_dt if kr_dt else "[识别失败]",
            "OCR原文": r["raw_text"],
            "备注": r.get("warning", ""),
            # v2.4.2: 失败行明确标「失败」，不再沿用 layout 标签（修复误标正常/24-7 的瑕疵）
            "识别模式": "失败" if not r["success"] else r.get("layout", "正常"),
        })
        print()

    # ── v2.3.9: 批次坐标回退 ────────────────────────────────────────────
    # 个别截图的页面内容含大片绿色元素，绿簇检测会跑偏到非时钟区域导致失败。
    # 同一批次截图分辨率与时钟位置固定，故取成功样本裁剪框的众数坐标，
    # 对失败样本用该坐标强制重试一次。仅作用于已失败的图，对成功图零影响。
    failed_pos = [i for i, d in enumerate(results) if d["中国时间"] == "[识别失败]"]
    if failed_pos and success_boxes:
        from collections import Counter as _Counter
        modal_box, hits = _Counter(success_boxes).most_common(1)[0]
        if hits >= 2:
            print("=" * 60)
            print(f"批次坐标回退：{len(failed_pos)} 张失败图用众数框 {modal_box}"
                  f"（批次内命中 {hits} 次）重试")
            for i in failed_pos:
                p = image_files[i]
                r2 = extract_timestamp_from_image(str(p), reader, mode=mode,
                                                  force_box=modal_box)
                tag = f"[{results[i]['序号']}] {results[i]['文件名']}"
                if r2["success"]:
                    cn_dt, kr_dt = r2["china_time"], r2["korea_time"]
                    results[i]["中国时间"] = cn_dt
                    results[i]["中国时间_斜线"] = cn_dt
                    results[i]["韩国时间"] = kr_dt
                    results[i]["OCR原文"] = r2["raw_text"]
                    note = "批次坐标回退识别，建议人工复核"
                    if r2.get("warning"):
                        note += "；" + r2["warning"]
                    results[i]["备注"] = note
                    results[i]["识别模式"] = "正常(坐标回退)"
                    success_count += 1
                    warn_count += 1
                    print(f"  ✓ 已恢复 {tag}  →  CST: {cn_dt.strftime('%Y-%m-%d %H:%M:%S')}")
                else:
                    print(f"  ✗ 仍失败 {tag}")
            print()

    # ── v2.4.0: 跨午夜日期修正 ──────────────────────────────────────────
    # 夜班（-PM）批次会跨过 KST 午夜：如 KST 23:56 的下一张是 KST 00:06。
    # UTCK3 日期行在 24/7 模式下常为乱码，解析失败时回退用文件名日期，
    # 而文件名日期是"工作日"（CST 日期），跨午夜后 KST 日期已是次日，
    # 若不修正会导致整段日期少一天。
    # 判据：按顺序号有序遍历，若当前 KST 早于前一张，且构成 21:00+ → 03:00-
    # 的午夜回绕，则该张及其后所有图的 KST 日期累加一天。
    midnight_fixed = 0
    day_offset = 0
    prev_kst = None
    for d in results:
        kst = d["韩国时间"]
        if not isinstance(kst, datetime):
            continue
        kst_adj = kst + timedelta(days=day_offset)
        if prev_kst is not None and kst_adj < prev_kst:
            if prev_kst.hour >= 21 and kst_adj.hour <= 3:
                day_offset += 1
                kst_adj = kst + timedelta(days=day_offset)
        if day_offset:
            cn_adj = kst_adj - timedelta(hours=1)
            d["韩国时间"] = kst_adj
            d["中国时间"] = cn_adj
            d["中国时间_斜线"] = cn_adj
            midnight_fixed += 1
        prev_kst = kst_adj

    if midnight_fixed:
        print("=" * 60)
        print(f"跨午夜修正：检测到 KST 跨过午夜，已为其后 {midnight_fixed} 张"
              f"图的日期补加 {day_offset} 天")
        print()

    _write_excel(results, output_file)

    print("=" * 60)
    print(f"处理完成！成功: {success_count}/{len(image_files)}")
    if midnight_fixed:
        print(f"🌙 跨午夜日期修正: {midnight_fixed} 张")
    if warn_count > 0:
        print(f"⚠ 需人工复核: {warn_count} 张（详见 Excel 「备注」列）")
    print(f"结果已保存至: {output_file}")


def _write_excel(results: list, output_file: str):
    """将结果写入纯数据 Excel（无单元格样式，时间列为真实 datetime）。

    设计要点：
    - 不设置任何填充/字体/边框/对齐，避免用户粘贴到其他表格后格式顽固改不动。
    - 时间列(D/E/F)写入真实 datetime 并设置 number_format，便于用户自由改显示格式。
    - 失败行时间列用文本 \"[识别失败]\" 标记，不依赖颜色；需复核信息见「备注」列。
    """

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "时间戳统计"

    headers = ["序号", "顺序号", "文件名", "中国时间(北京时间)", "中国时间(斜线格式)", "韩国时间(原始)", "OCR识别原文", "备注", "识别模式"]
    for c, h in enumerate(headers, 1):
        ws.cell(row=1, column=c, value=h)

    # 列 -> 时间列的数字格式（真实日期，用户可在 Excel 中自由改）
    time_fmt = {4: "yyyy-mm-dd hh:mm:ss", 5: "yyyy/mm/dd hh:mm:ss", 6: "yyyy-mm-dd hh:mm:ss"}

    key_order = ["序号", "顺序号", "文件名", "中国时间", "中国时间_斜线", "韩国时间", "OCR原文", "备注", "识别模式"]
    for ri, rec in enumerate(results, 2):
        for c, key in enumerate(key_order, 1):
            val = rec[key]
            cell = ws.cell(row=ri, column=c, value=val)
            if c in time_fmt and isinstance(val, datetime):
                cell.number_format = time_fmt[c]

    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 55
    ws.column_dimensions["D"].width = 22
    ws.column_dimensions["E"].width = 22
    ws.column_dimensions["F"].width = 22
    ws.column_dimensions["G"].width = 40
    ws.column_dimensions["H"].width = 30
    ws.column_dimensions["I"].width = 10

    ws.freeze_panes = "A2"
    wb.save(output_file)


# ---------------------------------------------------------------------------
# 命令行入口
# ---------------------------------------------------------------------------

def _print_usage(stream=None):
    """打印用法。（v2.4.5：抽成函数，供 --help 与无参两种情况复用）"""
    out = stream or sys.stdout
    lines = [
        "用法:",
        "  批量处理: python korea_copyright_timestamp.py [--engine {tesseract|easyocr|rapidocr|auto}] [--mode {normal|247|auto}] [--date YYYY-MM-DD] <输入文件夹> [输出Excel路径]",
        "            （以上开关可任意顺序书写）",
        "  校准:     python korea_copyright_timestamp.py --calibrate <样例截图>",
        "  查看配置: python korea_copyright_timestamp.py --show-config",
        "  手动设:   python korea_copyright_timestamp.py --set-config <x0> <x1> <y0> <y1>",
        "  引擎说明: 默认 auto（Tesseract 优先，回退 EasyOCR）；rapidocr 需先 pip install rapidocr-onnxruntime opencv-python onnxruntime",
        "  模式说明: 默认 auto（自动检测 24/7 布局）；247 强制排除中国时间黑框；normal 强制正常模式",
    ]
    for ln in lines:
        print(ln, file=out)


if __name__ == "__main__":
    # v2.4.5：支持标准 -h/--help（此前会被当成「未知参数」并 rc=1）
    if len(sys.argv) >= 2 and sys.argv[1] in ("-h", "--help", "-help", "/?"):
        _print_usage()
        sys.exit(0)

    if len(sys.argv) >= 2 and sys.argv[1] == "--calibrate":
        if len(sys.argv) < 3:
            print("用法: python korea_copyright_timestamp.py --calibrate <样例截图路径>")
            sys.exit(1)
        calibrate(sys.argv[2])
        sys.exit(0)

    if len(sys.argv) >= 2 and sys.argv[1] == "--show-config":
        show_config()
        sys.exit(0)

    if len(sys.argv) >= 2 and sys.argv[1] == "--set-config":
        if len(sys.argv) < 6:
            print("用法: python korea_copyright_timestamp.py --set-config <x0> <x1> <y0> <y1>")
            print("  例:  --set-config 0.755 0.93 0.15 0.23")
            sys.exit(1)
        save_user_config({
            "x0": float(sys.argv[2]), "x1": float(sys.argv[3]),
            "y0": float(sys.argv[4]), "y1": float(sys.argv[5]),
        })
        sys.exit(0)

    # ── 批量处理参数解析（v2.3.8: 循环解析，--engine/--mode/--date 任意顺序）──
    _selected_engine = "auto"
    _selected_mode = "auto"
    _override_date = None
    _positional = []

    _args = sys.argv[1:]
    _i = 0
    while _i < len(_args):
        a = _args[_i]
        if a == "--engine":
            if _i + 1 >= len(_args):
                print("用法: --engine {tesseract|easyocr|rapidocr|auto}")
                sys.exit(1)
            _selected_engine = _args[_i + 1].lower()
            if _selected_engine not in ("tesseract", "easyocr", "rapidocr", "auto"):
                print(f"错误: 未知引擎 '{_selected_engine}'，可选 tesseract / easyocr / rapidocr / auto")
                sys.exit(1)
            _i += 2
        elif a == "--mode":
            if _i + 1 >= len(_args):
                print("用法: --mode {normal|247|auto}")
                sys.exit(1)
            _selected_mode = _args[_i + 1].lower()
            if _selected_mode not in ("normal", "247", "auto"):
                print(f"错误: 未知模式 '{_selected_mode}'，可选 normal / 247 / auto")
                sys.exit(1)
            _i += 2
        elif a == "--date":
            if _i + 1 >= len(_args):
                print("用法: --date YYYY-MM-DD")
                print("  例:  --date 2026-07-23 C:\\screenshots")
                sys.exit(1)
            _date_str = _args[_i + 1]
            try:
                _override_date = datetime.strptime(_date_str, "%Y-%m-%d")
            except ValueError:
                print(f"错误: 日期格式无效 '{_date_str}'，请使用 YYYY-MM-DD 格式")
                sys.exit(1)
            _i += 2
        elif a.startswith("--"):
            print(f"错误: 未知参数 '{a}'（可选 --engine / --mode / --date，帮助见 --help）")
            sys.exit(1)
        else:
            _positional.append(a)
            _i += 1

    # 批量处理模式
    if not _positional:
        # v2.4.5：无参数属「用法错误」，返回 2（此前返回 0，会把失败当成功）
        _print_usage(stream=sys.stderr)
        sys.exit(2)

    input_dir = _positional[0]
    output_file = _positional[1] if len(_positional) > 1 else os.path.join(os.path.dirname(input_dir), "时间戳统计.xlsx")

    print("=" * 60)
    print("版权取证 · 韩国截图时间戳提取工具  v2.4.6")
    print(f"输入: {input_dir}")
    print(f"输出: {output_file}")
    print(f"引擎: {_selected_engine}  模式: {_selected_mode}")
    print("=" * 60)
    print()

    process_images(input_dir, output_file, _selected_engine, _selected_mode)
