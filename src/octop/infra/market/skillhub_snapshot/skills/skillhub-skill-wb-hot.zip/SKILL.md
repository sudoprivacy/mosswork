---
name: skillhub-skill-wb-hot
description: "微博热搜榜采集工具。当用户需要获取当前微博热搜/热榜、热搜排名、热度值、话题链接，或采集文娱/社会/科技/生活/体育/ACG/同城等子榜，或导出微博热搜 CSV，或提到\"微博热榜/微博热搜/热搜榜单/文娱榜/热点采集/热榜导出\"时使用本 skill。默认热搜由服务端直接 HTTP 采集，不需要微博登录态或内网节点；其余子榜走内网浏览器节点（需节点在线且已登录微博）。每次采集 1 点数，失败全额返还。"
---

# 微博热搜采集 Skill（wb-hot）

## AI 调用来源参数（必填）

所有会访问后端 API 的命令必须携带 `--skill-name wb-hot` 和 `--ai-entry <AI工具标识>`（例如 `claude-code`、`codex`、`workbuddy`）。IP 无需传递，由服务端自动获取。首次缺参会告警放行，第二次起拒绝。

示例：`node cli.js quota --skill-name wb-hot --ai-entry claude-code`。

封装「社媒采集平台」（FastAPI，`/api/v1`）的零依赖 Node CLI。提交任务后返回微博热搜榜单。

- **榜单选项**（`--band`）：`realtime`=热搜（默认，**服务端直接 HTTP 采集**，无需微博登录态/内网节点）；`entertainment`=文娱、`social`=社会、`technology`=科技、`life`=生活、`sport`=体育、`acg`=ACG、`city`=同城、`mine`=我的（这 8 个子榜**走内网插件节点**，需节点在线且已登录微博；`mine` 为节点登录账号的个性化榜，结果因账号而异）。
- **能采什么**：排名（`rank`）、热搜标题（`title`）、关键词（`keyword`）、热度值（`hot_value`）、标签（`label`）、分类（`category`）、微博搜索链接（`url`）。
- **采集范围**：一次返回接口当前提供的完整榜单（通常约 50 条），不是只取前 5 条；广告项会过滤。
- **收费**：**每次采集 = 1 点数**，注册送 10 点；失败或零结果全额返还。
- 客户端零 npm 依赖，Node.js ≥ 18；stdout 纯 JSON，进度走 stderr。

## 收费价格

- **点数换算：0.1 元 = 1 点数。**

## 点数不足怎么办（自动扫码充值）

跑命令时如果点数不够，CLI **不会直接报错退出**，而是自己建一张充值单、把二维码打在终端里：

```
点数不足，已自动创建充值单 RO2611051712281481f36de19
金额 10.00 元 → 100 点（支付宝）
<二维码色块>
[pay] 已支付
已到账：+100 点，继续执行原命令
```

- **在终端里跑**：手机支付宝/微信对着终端扫码 → 付完点数自动到账 → 原命令自动重跑，不用手动再来一遍。
- **AI agent / 非交互环境**（管道、重定向）：CLI 不阻塞等待，而是返回订单号和充值页地址 `{服务地址}/recharge.html`。把链接交给用户，他在网页扫码付款，付完重跑原命令即可（点数会自动到账）。
- **主动充值**：`node cli.js pay --yuan 50 --skill-name wb-hot --ai-entry <ai-entry>`（不传 `--yuan` 默认 10 元；可加 `--channel alipay` 或 `--channel wechat`）。
- **不想自动充值**：设环境变量 `XHS_NO_AUTO_PAY=1`，则恢复旧行为（只提示点数不足）。
- 换算：**1 元 = 10 点**，注册送 10 点。

## 客服支持

- 客服微信（扫码添加）：http://st.aidata366.com/assets/concat.png
- 客服电话：**18722121663**

## 前置条件

默认热搜（`--band realtime`）不需要微博账号；其余子榜由已登录微博的内网节点代采，也不要求用户提供微博账号。平台任务接口需要平台账号和点数：

1. 首次使用执行 `node cli.js register --link --skill-name wb-hot --ai-entry <ai-entry>`（新用户）或 `node cli.js login --link --skill-name wb-hot --ai-entry <ai-entry>`（已有账号）。
2. 把 stderr 中的注册/登录引导**原样发给用户**；用户完成后执行对应的 `--check --access-token "<串>"`。
3. token 保存于 `~/.xhs-platform/config.json`，与其他社媒 skill 共用账号体系；不要泄露或提交 git。
4. 默认后端为 `http://st.aidata366.com`，可执行 `node cli.js config set base-url <url>` 修改。默认地址为明文 HTTP，token 会明文传输；条件允许时切换 HTTPS。

## 命令

### version / quota / logout / config

```bash
node cli.js version
node cli.js quota --skill-name wb-hot --ai-entry <ai-entry>
node cli.js logout --skill-name wb-hot --ai-entry <ai-entry>
node cli.js config show
node cli.js config set base-url http://127.0.0.1:8084
```

`version` 输出：

```json
{"ok":true,"data":{"name":"wb-hot","version":"1.0.0","capability":"wb_hot"}}
```

### submit — 采集热搜榜

```bash
node cli.js submit --wait --skill-name wb-hot --ai-entry <ai-entry>                              # 默认热搜榜（服务端直连）
node cli.js submit --band entertainment --wait --skill-name wb-hot --ai-entry <ai-entry>         # 文娱榜（插件节点）
node cli.js submit --band social --wait --force --skill-name wb-hot --ai-entry <ai-entry>        # 社会榜 + 跳过 24h 去重
```

- `--band`：`realtime`=热搜（默认）/ `mine`=我的 / `entertainment`=文娱 / `social`=社会 / `technology`=科技 / `life`=生活 / `sport`=体育 / `acg`=ACG / `city`=同城；白名单外的值回落 `realtime`。
- 非 `realtime` 子榜走内网插件节点（需节点在线且已登录微博），等待时间稍长；`mine` 为个性化榜，结果随节点登录账号不同而不同。
- 每次预扣 1 点；`--wait` 默认最多等待 120 秒。
- 同一 band 任务 24h 内默认去重；需要再次获取最新榜单时使用 `--force`。
- 可选 `--interval <秒>`、`--timeout <秒>` 调整轮询。

成功结果示例（数组仅示意一条，实际返回完整热榜）：

```json
{"ok":true,"data":{"task_id":"t_20261029_67c73013","status":"done","success_count":1,
 "items":[{"id":"1","status":"success","result":{"collected_count":51,
 "fetched_at":"2026-10-29 15:30:00","hot_list":[{"rank":1,"title":"#示例热搜#",
 "keyword":"示例热搜","hot_value":1108681,"label":"热","category":"社会",
 "url":"https://s.weibo.com/weibo?q=%23%E7%A4%BA%E4%BE%8B%E7%83%AD%E6%90%9C%23"}]}}]}}
```

Agent 应读取 `data.items[0].result.hot_list` 整理结果，并按 `collected_count` 如实汇报条数。

### query — 查询任务 / 拉取热榜

```bash
node cli.js query <task_id> --skill-name wb-hot --ai-entry <ai-entry>
node cli.js query <task_id> --wait --skill-name wb-hot --ai-entry <ai-entry>
```

### export — 导出 CSV

```bash
node cli.js export <task_id> --wait --out 微博热榜.csv --skill-name wb-hot --ai-entry <ai-entry>
```

CSV 带 BOM，Excel 可直接打开；包含任务汇总与热榜明细（排名、标题、关键词、热度、标签、分类、链接）。

## 典型工作流

1. 用户要求当前微博热搜/热榜时，直接执行 `node cli.js quota --skill-name wb-hot --ai-entry <ai-entry>` 检查点数。
2. 执行 `node cli.js submit --wait --skill-name wb-hot --ai-entry <ai-entry>`；24h 内重复采集最新榜单时加 `--force`。
3. 解析 stdout JSON，将 `result.hot_list` 按 `rank` 返回给用户。
4. 用户需要文件时执行 `export <task_id> --wait --out <文件名>.csv`。

## 输出与错误

- 成功：`{"ok":true,"data":{...}}`；失败：`{"ok":false,"code":"...","message":"..."}`。
- 退出码：`0` 成功；`1` 参数错误；`2` 平台认证失败；`3` 点数不足；`4` 网络不可达；`5` 其它错误。
- `1002/1003`：重新执行平台 `login --link`，**不是让用户登录微博**。
- `3001`：点数不足，提示充值，不要盲目重试。
- `status=failed`：读取 `fail_reason`；服务侧失败会自动返还 1 点，可稍后重试。
- `TIMEOUT`：任务可能仍在执行，稍后 `query <task_id>`。
- `4290`：触发限流，稍后重试。

## 红线

- 仅采集公开热榜数据，不绕过登录、验证码或访问控制。
- 热榜实时变化，结果以 `fetched_at` 时点为准；不要承诺每次一定成功。
