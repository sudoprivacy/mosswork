#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""剧本格式校验器（Axu剧本清洗格式化 技能专用）

只做确定性检查：格式骨架、禁用词、负面描述、主语重复、台词与翻译配对。
动机是否成立、动作取舍是否合理，仍需按 SKILL.md 的 Pass 4 三问人工判断。

用法:
    python validate_script.py 剧本.md
    python validate_script.py 剧本.md --json
    python validate_script.py 剧本.md --strict     # WARN 也算失败

退出码:
    0 = 没有 ERROR（可交付）
    1 = 存在 ERROR（必须修）
    2 = 文件无法读取
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field

# ---------------------------------------------------------------- 结构正则

EP_TITLE = re.compile(r"^第\s*(?P<ep>[0-9一二三四五六七八九十百]+)\s*集\s*《(?P<table>.+)》\s*$")
SCENE = re.compile(
    r"^场\s*(?P<ep>\d+)\s*[-－—]\s*(?P<n>\d+)\s*[：:]\s*(?P<place>[^（(]+?)\s*[（(](?P<time>[^）)]*)[）)]\s*$"
)
CAST = re.compile(r"^出场人物\s*[：:]\s*(?P<cast>.+?)\s*$")
ACTION = re.compile(r"^▲(?P<gap>\s*)(?P<body>.+)$")
DIALOGUE = re.compile(
    r"^(?P<who>[^\s（(：:▲]{1,12})\s*[（(](?P<meta>[^）)]+)[）)]\s*[：:]\s*(?P<quote>[\"“](?P<line>.+)[\"”])\s*$"
)
TRANS = re.compile(r"^[（(]翻译\s*[：:].+[）)]\s*$")
END = re.compile(r"^【第\s*(?P<ep>\d+)\s*集\s*·?\s*完】\s*$")
CJK = re.compile(r"[\u4e00-\u9fff]")

# ---------------------------------------------------------------- 禁用词库

SHOT_WORDS = [
    "镜头", "分镜", "近景", "中景", "远景", "全景", "特写", "大特写", "空镜",
    "反打", "跟拍", "跟随镜头", "摇镜", "推镜", "拉镜", "俯拍", "仰拍", "越轴",
]
TIMECODE = re.compile(r"\d+\s*[-–—~]+\s*\d+\s*秒|\d+\s*秒处|第\s*\d+\s*秒|[（(]\s*\d+\s*[-–—]\s*\d+\s*[）)]")
EP_MARK = re.compile(r"\bEP\s*\d+|\bEP\d+", re.I)

# 台词括号内禁止出现的技术性表演提示（描述"怎么说"）
TECH_WORDS = [
    "尾音", "语速", "咬字", "重音", "重读", "音量", "压低", "气息", "呼吸",
    "奶声", "停顿", "拖长", "拔高", "发紧", "句尾", "腔调", "声音", "语气",
]

# 动作行禁止的微表情 / 表演性修饰 / 心理活动
CRAFT_WORDS = [
    "眼底", "指尖", "嘴角", "脸色", "绷紧", "缓缓", "轻轻", "悄悄", "慢条斯理",
    "居高临下", "冷冷", "不动声色", "小心翼翼", "亮晶晶", "微微", "默默",
    "深深", "连连", "淡然", "故作", "若有若无",
]
INNER_WORDS = ["意识到", "心里", "暗自", "忍不住", "不由得", "犹豫", "决定", "想起", "明白"]

# 负面描述（改变剧情结果的除外，如"没接信"需改写而非删除）
NEGATIVE = re.compile(r"没有(?!松手)|没看|没碰|没接|没拿|不肯|不愿|并未")
NEGATIVE_OK = ["没松手", "没让", "没动", "站着没动"]

LONG_ACTION = 60      # 动作行长度上限（字），超出提示可能堆叠
MAX_COMMAS = 4        # 单条动作行逗号上限


@dataclass
class Issue:
    level: str
    code: str
    line: int
    msg: str
    text: str = ""


@dataclass
class Stats:
    episodes: list = field(default_factory=list)
    scenes: int = 0
    dialogues: int = 0
    actions: int = 0
    characters: set = field(default_factory=set)


def classify(raw: str):
    """返回 (kind, match)。顺序不可调整：场次/出场人物先于台词。"""
    s = raw.strip()
    if not s:
        return "blank", None
    if s.startswith("---"):
        return "rule", None
    if END.match(s):
        return "end", END.match(s)
    if s.startswith("场"):
        m = SCENE.match(s)
        return ("scene", m) if m else ("bad_scene", None)
    if s.startswith("出场人物"):
        m = CAST.match(s)
        return ("cast", m) if m else ("bad_cast", None)
    if s.startswith("▲"):
        return "action", ACTION.match(s)
    if s.startswith("镜头") or re.match(r"^(EP|ep)\s*\d", s):
        return "shotline", None
    if TRANS.match(s):
        return "trans", TRANS.match(s)
    m = DIALOGUE.match(s)
    if m:
        return "dialogue", m
    m = EP_TITLE.match(s)
    if m:
        return "title", m
    return "unknown", None


def validate(path: str) -> tuple[list[Issue], Stats]:
    with open(path, "r", encoding="utf-8-sig") as fh:
        lines = fh.read().splitlines()

    issues: list[Issue] = []
    stats = Stats()

    def add(level: str, code: str, i: int, msg: str, text: str = ""):
        issues.append(Issue(level, code, i + 1, msg, text.strip()))

    rows = [(i, ln) for i, ln in enumerate(lines)]
    body = [(i, ln) for i, ln in rows if ln.strip() and not ln.strip().startswith("---")]

    if not body:
        add("ERROR", "F000", 0, "文件为空或无有效内容")
        return issues, stats

    # ---- 首行必须是集标题
    if not EP_TITLE.match(body[0][1].strip()):
        add("ERROR", "F001", body[0][0],
            "首行应为「第X集《中文标题 / 英文标题》」", body[0][1])

    # ---- 末行必须是集尾
    if not END.match(body[-1][1].strip()):
        add("ERROR", "F002", body[-1][0],
            "结尾缺少「【第X集 · 完】」", body[-1][1])

    cur_ep = None
    cur_scene = None
    scene_no = 0
    known_names: list[str] = []
    scene_cast: list[str] = []
    first_speaker_seen: set[str] = set()
    scene_has_content = False
    scene_open = False
    cast_missing = False        # 场次标题后未跟「出场人物」
    expected_next_line = None   # "dialogue" -> 需要翻译行
    pending_dialogue = None     # (idx, who, meta)

    for idx, raw in body:
        kind, m = classify(raw)
        s = raw.strip()

        # 台词后必须紧跟翻译行
        if expected_next_line == "trans" and kind != "trans":
            di, dwho = pending_dialogue  # type: ignore[misc]
            add("ERROR", "F020", di, f"台词后缺「（翻译：……）」行（说话人 {dwho}）", lines[di])
            expected_next_line = None

        if kind == "blank":
            continue

        if cast_missing and kind not in ("cast", "title", "end", "scene"):
            add("ERROR", "F013", idx, "场次标题后应先写「出场人物：……」，再写动作或台词", s)
            cast_missing = False

        if kind == "title":
            cur_ep = m.group("ep")
            stats.episodes.append(s)
            scene_no = 0
            if not re.fullmatch(r"\d+", cur_ep):
                add("WARN", "F003", idx, "集号建议用阿拉伯数字（如「第2集」）", s)
            continue

        if kind == "bad_scene":
            add("ERROR", "F004", idx, "场次标题格式应为「场 X-1：地点（时间）」", s)
            continue

        if kind == "scene":
            if cast_missing:
                add("ERROR", "F013", idx, "上一场缺少「出场人物：……」行", s)
            scene_no += 1
            stats.scenes += 1
            cur_scene = (m.group("ep"), m.group("n"), m.group("place"), m.group("time"))
            scene_cast = []
            first_speaker_seen = set()
            scene_has_content = False
            scene_open = True
            cast_missing = True
            # 场号连续性：X-1、X-2 ……
            if m.group("n") != str(scene_no):
                add("WARN", "F010", idx,
                    f"本场序号为 {m.group('n')}，按顺序应为 {scene_no}", s)
            if cur_ep and re.fullmatch(r"\d+", cur_ep) and m.group("ep") != cur_ep:
                add("WARN", "F011", idx,
                    f"场次主号「{m.group('ep')}」与集号「{cur_ep}」不一致", s)
            if not m.group("time").strip():
                add("WARN", "F012", idx, "场次标题缺少时间标注", s)
            continue

        if kind == "cast":
            if not scene_open:
                add("ERROR", "F005", idx, "「出场人物」必须紧跟在场次标题之后", s)
            scene_cast = [n.strip() for n in re.split(r"[、,，/]", m.group("cast")) if n.strip()]
            for n in scene_cast:
                stats.characters.add(n)
                if n not in known_names:
                    known_names.append(n)
            cast_missing = False
            continue

        if kind == "action":
            if not scene_open:
                add("ERROR", "F006", idx, "动作行出现在场次标题之外", s)
            stats.actions += 1
            scene_has_content = True
            body_txt = m.group("body").strip()
            if not m.group("gap"):
                add("WARN", "F007", idx, "「▲」后应有空格再写动作", s)

            # 禁用：镜头语言 / 时间码 / 集场标记
            hits = [w for w in SHOT_WORDS if w in body_txt]
            if hits:
                add("ERROR", "B010", idx, f"动作行含镜头语言：{'、'.join(hits)}", s)
            if TIMECODE.search(body_txt):
                add("ERROR", "B011", idx, "动作行含时间码", s)
            if EP_MARK.search(body_txt):
                add("ERROR", "B012", idx, "动作行含 EP/分镜编号", s)

            craft = [w for w in CRAFT_WORDS if w in body_txt]
            if craft:
                add("WARN", "B020", idx, f"动作行含表演性修饰/微表情：{'、'.join(craft)}，建议删", s)
            inner = [w for w in INNER_WORDS if w in body_txt]
            if inner:
                add("ERROR", "B021", idx, f"动作行含心理活动：{'、'.join(inner)}，不可见", s)

            neg = NEGATIVE.search(body_txt)
            if neg and not any(ok in body_txt for ok in NEGATIVE_OK):
                add("WARN", "B030", idx,
                    f"动作行含负面描述「{neg.group(0)}」，能删就删，否则换成正面可见动作", s)

            # 一句一主语：按句号切句，同一句首主语不应在同一条动作行里出现两次
            clauses = [c.strip() for c in re.split(r"[。；]", body_txt) if c.strip()]
            for n in (scene_cast or known_names):
                head_hits = sum(1 for c in clauses if c.startswith(n))
                if head_hits >= 2:
                    add("WARN", "B040", idx,
                        f"同一条动作行内主语「{n}」出现 {head_hits} 次，连续动作请用逗号连接", s)

            if len(body_txt) > LONG_ACTION or body_txt.count("，") > MAX_COMMAS:
                add("WARN", "B050", idx,
                    f"动作行偏长（{len(body_txt)} 字，{body_txt.count('，')} 个逗号），检查是否堆叠了纯过渡动作", s)
            continue

        if kind == "dialogue":
            if not scene_open:
                add("ERROR", "F008", idx, "台词出现在场次标题之外", s)
            stats.dialogues += 1
            scene_has_content = True
            who = m.group("who").strip()
            meta = m.group("meta").strip()
            quote_line = m.group("line")

            if scene_cast and who not in scene_cast and not who.endswith("OS"):
                add("ERROR", "F030", idx,
                    f"说话人「{who}」不在本场「出场人物」中", s)

            # 情绪+意图 至少两项
            if "、" not in meta:
                add("WARN", "F031", idx, "台词标注应为「情绪、意图，对X说」，目前缺少一项", s)
            # 技术性表演提示
            tech = [w for w in TECH_WORDS if w in meta]
            if tech:
                add("ERROR", "B060", idx,
                    f"台词标注含技术性表演提示：{'、'.join(tech)}，必须改写为情绪+意图", s)
            # 首次出现需写清对象
            if who not in first_speaker_seen:
                first_speaker_seen.add(who)
                if "对" not in meta and "自言自语" not in meta:
                    add("WARN", "F032", idx,
                        f"「{who}」在本场首次开口，应写清说话对象（如「对X说」）", s)
            elif "对" not in meta and "自言自语" not in meta:
                add("WARN", "F033", idx, "台词未标注说话对象", s)
            # 引号内不应出现中文
            if CJK.search(quote_line):
                add("WARN", "F034", idx,
                    "英文台词引号内出现中文，原文应原样保留、中文放翻译行", s)

            pending_dialogue = (idx, who)
            expected_next_line = "trans"
            continue

        if kind == "trans":
            if expected_next_line != "trans":
                add("WARN", "F021", idx, "翻译行前面没有对应的台词行", s)
            expected_next_line = None
            continue

        if kind == "end":
            expected_next_line = None
            if cur_ep and m.group("ep") != cur_ep and re.fullmatch(r"\d+", cur_ep):
                add("WARN", "F040", idx, f"集尾集号「{m.group('ep')}」与标题集号「{cur_ep}」不一致", s)
            if scene_open and not scene_has_content:
                add("WARN", "F041", idx, "最后一场上场后没有任何台词或动作", s)
            continue

        if kind in ("bad_cast",):
            add("ERROR", "F009", idx, "「出场人物：」格式异常", s)
            continue

        if kind == "shotline":
            add("ERROR", "B001", idx,
                "这是分镜行：删掉镜头号/景别/时间码，把内容改写成「▲ 谁+可见动作+对象」", s)
            continue

        if kind == "unknown":
            add("ERROR", "F099", idx, "无法归类的行（应为集标题/场次/出场人物/▲动作/台词/翻译/集尾）", s)
            continue

    if expected_next_line == "trans" and pending_dialogue:
        di, dwho = pending_dialogue
        add("ERROR", "F020", di, f"文件结尾台词缺「（翻译：……）」（说话人 {dwho}）", lines[di])

    if stats.dialogues == 0 and stats.scenes:
        add("ERROR", "F050", 0, "全文没有任何台词行，检查格式是否走错")

    return issues, stats


def main() -> int:
    ap = argparse.ArgumentParser(description="剧本格式校验器")
    ap.add_argument("path", help="待校验的剧本 .md / .txt")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出")
    ap.add_argument("--strict", action="store_true", help="WARN 也视为失败")
    args = ap.parse_args()

    try:
        issues, stats = validate(args.path)
    except OSError as exc:
        print(f"[无法读取] {exc}", file=sys.stderr)
        return 2

    errors = [i for i in issues if i.level == "ERROR"]
    warns = [i for i in issues if i.level == "WARN"]

    if args.json:
        print(json.dumps({
            "file": args.path,
            "scenes": stats.scenes,
            "dialogues": stats.dialogues,
            "actions": stats.actions,
            "characters": sorted(stats.characters),
            "errors": [i.__dict__ for i in errors],
            "warnings": [i.__dict__ for i in warns],
        }, ensure_ascii=False, indent=2))
    else:
        print(f"校验文件：{args.path}")
        print(f"场次 {stats.scenes} · 台词 {stats.dialogues} 句 · 动作 {stats.actions} 行 · 角色 {len(stats.characters)} 个")
        print("-" * 60)
        if not issues:
            print("✅ 无问题")
        for group, title in ((errors, "ERROR（必须修）"), (warns, "WARN（逐条判断）")):
            if group:
                print(f"\n{title}：{len(group)} 条")
                for it in group:
                    print(f"  行{it.line:>4} [{it.code}] {it.msg}")
                    if it.text:
                        print(f"          {it.text[:70]}")
        print("-" * 60)
        print(f"结果：ERROR {len(errors)} / WARN {len(warns)}")

    bad = bool(errors) or (args.strict and bool(warns))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
