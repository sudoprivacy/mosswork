# 03 完整案例（校准"改到什么程度"）

下面同一集内容：先看原稿，再看成品。成品刻意做到"极简但不漏事件"，用来校准动作删并的尺度 —— **不是所有原稿动作都要留，也不是所有修饰都要删，看它在 3—5 句窗口里有没有功能。**

---

## 附录 A：原稿（输入示例）

**EP2 · She Deserves a Second Chair / 第二把椅子**

**EP2 · 01 · 玫瑰露台生日桌（白天｜0--30秒）**

镜头1：中景，0--3秒，Margot将已握住椅背的橡木椅猛然拉回主桌空位，椅脚落地一声闷响；Wren与Posy站在椅子侧后方，Margot挡在Tessa与空位之间，女主Margot声音清亮、语速快、重音落在your daughter地说："Tessa, your daughter isn't eating birthday cake standing up!"。
镜头2：近景，Margot把Wren的小盘子放到新座位前，Posy将礼盒推到另一侧，腾出桌面；Wren扶着椅背等Margot点头。
镜头3：中景，Celeste走近，指尖点向桌次卡，目光落在刚放稳的椅子上，反派Celeste声音压低、语速慢、尾音带冷笑地说："One extra chair ruins the table; stop fussing, Margot."。
镜头4：近景，Margot将Wren的水杯摆在Posy杯旁，扶稳椅背，不让Celeste插进空位。
镜头5：近景，Margot把餐巾在Wren盘旁展开，抬眼直视Celeste，女主Margot声音变稳、咬字清楚、重音落在sixth birthday地说："It's Wren's sixth birthday too; she's sitting beside Posy."。
镜头6：中景，Posy拿出空白卡片，用彩笔写好Wren的名字，将卡放到姐姐盘前。
镜头7：近景，Posy撑平卡片两角，指向蛋糕上最大的草莓，Posy声音明亮、语速稍快、尾音上扬地说："Sit beside me, Wren; the biggest strawberry is yours!"。
镜头8：近景，Margot点头并挪开半步，Wren自己扶着椅沿坐下；Margot仍站在两个孩子身旁。
镜头9：近景，Wren坐稳，将小盘子拉近；Posy把自己的叉子摆在姐姐叉子旁，向她咧嘴一笑。
镜头10：近景，Tessa停在长桌另一端，捏紧香槟杯柄，嘴唇不动，反派Tessa（OS）声音压低、语速慢、重音落在Posy地说："Keep defending that brat, Margot; Posy still inherits everything."。

台词翻译区：
- 女主 Margot: "Tessa, your daughter isn't eating birthday cake standing up!"（翻译：Tessa，你女儿不能站着吃生日蛋糕！）
- 反派 Celeste: "One extra chair ruins the table; stop fussing, Margot."（翻译：多一把椅子毁了桌子布局，别折腾了，Margot。）
- 女主 Margot: "It's Wren's sixth birthday too; she's sitting beside Posy."（翻译：今天也是Wren的六岁生日，她就坐Posy旁边。）
- Posy: "Sit beside me, Wren; the biggest strawberry is yours!"（翻译：坐我旁边，Wren，最大的草莓归你！）
- 反派 Tessa（OS）: "Keep defending that brat, Margot; Posy still inherits everything."（翻译：继续护着那个小讨厌鬼吧，Margot，继承一切的仍是Posy。）

**EP2 · 02 · 玫瑰露台生日桌（白天·连续｜30--60秒）**

镜头1：中景，Celeste端着香槟杯慢条斯理走近主桌，居高临下地瞥向Margot摆好的两把椅子，反派Celeste以端着香槟杯慢条斯理地走近、用庄园太后的冷傲腔调敲打Margot的语气说："Mind your manners, Margot. Guests are watching---don't make a scene over a seat."。
镜头2：近景，Tessa把礼盒上的丝带拉响，将敞开的盒子转向Posy；Posy仍紧紧握着Wren的手没松开。
镜头3：近景，Margot端坐原位，毫不避让地迎上Celeste冰冷的视线，指尖笃定地轻叩桌面，女主Margot以毫不畏惧地迎上婆婆冰冷的视线、指尖笃定地轻叩桌面的语气说："The children's seats were confirmed yesterday. Moving Wren's chair away was the real scene."。
镜头4：中景，Posy把礼盒轻轻往桌子中间推远，拉着Wren一起俯向插了蜡烛的草莓蛋糕，Wren绷紧的肩慢慢放松。
镜头5：近景，Margot低头替Wren把洁白的亚麻餐巾彻底摊开，语气温柔却字字千钧，女主Margot低头替Wren摊开洁白的亚麻餐巾，以温柔却字字千钧的语气说："No one takes a child's seat away on her birthday. Not under my watch."。
镜头6：近景，Wren转脸看向Posy，指尖轻轻回握住妹妹的小手。
镜头7：近景，Wren把自己面前那支蜡烛悄悄靠近一点，抬眼亮晶晶地望向Margot小声确认，Wren以像抓到救命稻草般挺直腰背、眼神亮晶晶地小声确认的语气说："Can I really stay right here with Posy?"。
镜头8：中景，Margot蹲在两个孩子身旁，双手分别扶稳两只蛋糕碟。
镜头9：近景，Posy一把将珍珠粉礼盒推到桌子中央，叉着小腰仰起脸大声宣布，Posy以一把将珍珠粉礼盒推到桌子中间、双手叉腰仰着小脸大声宣布的语气说："If Wren doesn't get a ribbon, I don't want this pink box either!"。
镜头10：中景，两个小女孩一起鼓着腮帮子吹灭蜡烛，周围宾客笑着鼓掌，Wren笑着把掌心贴向Posy的掌心。

台词翻译区：
- 反派 Celeste: "Mind your manners, Margot. Guests are watching---don't make a scene over a seat."（翻译：注意你的身份，Margot，宾客都在看着，别为了一把椅子丢人现眼。）
- 女主 Margot: "The children's seats were confirmed yesterday. Moving Wren's chair away was the real scene."（翻译：孩子的座位昨天就定好了，当众撤掉Wren的椅子才是真正丢人现眼。）
- 女主 Margot: "No one takes a child's seat away on her birthday. Not under my watch."（翻译：谁也不能在孩子生日这天撤走她的座位，在我眼皮底下绝不可能。）
- Wren: "Can I really stay right here with Posy?"（翻译：我真的可以一直坐在这儿，和Posy在一起吗？）
- Posy: "If Wren doesn't get a ribbon, I don't want this pink box either!"（翻译：要是Wren没有蝴蝶结丝带，那这个粉盒子我也不要了！）

**EP2 · 03 · 玫瑰露台入口及生日桌（白天·连续｜60--90秒）**

镜头1：中景，趁两个孩子转身看礼物的空隙，Tessa把Wren的名字卡从桌上抽走，压到托盘底下，反派Tessa以趁孩子转身弯腰把Wren的名字卡往托盘底下塞、脸上挂着讨好又心虚的假笑的语气说："Sweetheart, I picked this out just for you! Why give it to her?"。
镜头2：近景，刚抵达露台的Callum停住脚步，目光从Tessa藏卡的手移到托盘下露出的折弯卡角。
镜头3：近景，Posy毫不犹豫地解下礼盒上最漂亮的粉色丝带，塞进Wren手里，冲她咧嘴一笑，Posy以毫不犹豫地解下礼盒上最漂亮的丝带塞进Wren手里、冲她咧嘴一笑的语气说："Here, Wren! Now we both have birthday ribbons!"。
镜头4：近景，Callum看也没看那只礼盒，伸手从托盘下取出被藏起的Wren名字卡。
镜头5：近景，Wren小心翼翼捧着那根粉色丝带，眼底闪过一丝惶恐，却舍不得松手，Wren以小心翼翼地捧着那根粉色丝带、眼底闪过一丝惶恐却舍不得松手的语气说："Is it really okay if I keep just one ribbon?"。
镜头6：中景，Tessa伸手想讨回名字卡，Callum不动声色把卡留在自己手里；Margot站到两个孩子身边。
镜头7：近景，Margot伸手扶稳Wren端得发颤的小盘子，让盘底轻轻落回桌面。
镜头8：近景，Margot俯身替Wren把丝带系在手腕上，抬眼冷冷睨向脸色发青的Tessa，女主Margot以俯身替Wren把丝带系在手腕上、抬眼冷冷睨向脸色发青的Tessa的语气说："Keep it, sweetheart. Posy gave it to you, and nobody is taking it back."。
镜头9：近景，Wren松开扣着盘沿的手指，目光落在Callum手中那张展平的名字卡上。
镜头10：中景，Callum拿着名字卡走回生日桌，向仍半站着的Wren伸出空着的另一只手；Tessa在原地抱起手臂冷眼斜睨，反派Tessa以双手抱臂冷眼看着两个孩子分点心、眼底满是不屑与恶毒的语气说："A cheap ribbon for a cheap child. Wait till Posy inherits the whole vineyard."。

台词翻译区：
- 反派 Tessa: "Sweetheart, I picked this out just for you! Why give it to her?"（翻译：心肝宝贝，这可是我专门为你挑的！干嘛要分给她呀？）
- Posy: "Here, Wren! Now we both have birthday ribbons!"（翻译：给，Wren！现在我们两个人都有生日丝带啦！）
- Wren: "Is it really okay if I keep just one ribbon?"（翻译：我……我真的可以留下一根丝带吗？）
- 女主 Margot: "Keep it, sweetheart. Posy gave it to you, and nobody is taking it back."（翻译：戴好它，宝贝，这是Posy送你的，谁也别想拿回去。）
- 反派 Tessa: "A cheap ribbon for a cheap child. Wait till Posy inherits the whole vineyard."（翻译：下等货配破丝带，等着瞧吧，将来整座酒庄都是我女儿Posy的。）

---

## 附录 B：成品（输出示例）

第2集《第二把椅子 / She Deserves a Second Chair》

场 2-1：玫瑰露台生日桌（白天）

出场人物：Margot、Callum、Tessa、Celeste、Wren、Posy

▲ Margot把椅子拉回空位，站到Tessa和空位之间。

Margot（急切、护崽，对Tessa说）: "Tessa, your daughter isn't eating birthday cake standing up!"
（翻译：Tessa，你女儿不能站着吃生日蛋糕！）

▲ Celeste走过来，指着刚放好的椅子。

Celeste（冷傲、挑刺，对Margot说）: "One extra chair ruins the table; stop fussing, Margot."
（翻译：多一把椅子毁了桌子布局，别折腾了，Margot。）

▲ Margot把Wren的盘子放到新座位前，展开餐巾，不让Celeste碰椅子。

Margot（坚定、回击，对Celeste说）: "It's Wren's sixth birthday too; she's sitting beside Posy."
（翻译：今天也是Wren的六岁生日，她就坐Posy旁边。）

▲ Posy写好Wren的名字卡，放到姐姐盘前，指向蛋糕上最大的草莓。

Posy（明亮、维护，对Wren说）: "Sit beside me, Wren; the biggest strawberry is yours!"
（翻译：坐我旁边，Wren，最大的草莓归你！）

▲ Wren扶着椅沿坐下，把盘子拉近。Posy把自己的叉子放到姐姐叉子旁。

▲ Tessa站在长桌另一端，握紧香槟杯。

Tessa（OS，讥讽、笃定，自言自语）: "Keep defending that brat, Margot; Posy still inherits everything."
（翻译：继续护着那个小讨厌鬼吧，Margot，继承一切的仍是Posy。）

▲ Celeste端着香槟杯走到主桌，看着两把椅子。

Celeste（冷傲、敲打，对Margot说）: "Mind your manners, Margot. Guests are watching---don't make a scene over a seat."
（翻译：注意你的身份，Margot，宾客都在看着，别为了一把椅子丢人现眼。）

▲ Margot坐着没让，迎上Celeste。

Margot（坚定、回击，对Celeste说）: "The children's seats were confirmed yesterday. Moving Wren's chair away was the real scene."
（翻译：孩子的座位昨天就定好了，当众撤掉Wren的椅子才是真正丢人现眼。）

▲ Posy把礼盒推到桌子中间，拉着Wren一起看蛋糕。Margot替Wren摊开餐巾。

Margot（温柔、不容侵犯，对Celeste和全场说）: "No one takes a child's seat away on her birthday. Not under my watch."
（翻译：谁也不能在孩子生日这天撤走她的座位，在我眼皮底下绝不可能。）

▲ Wren握住Posy的手，把蜡烛挪近一点，看向Margot。

Wren（怯生生、确认，对Margot说）: "Can I really stay right here with Posy?"
（翻译：我真的可以一直坐在这儿，和Posy在一起吗？）

▲ Posy把礼盒推到桌子中间，叉腰宣布。

Posy（护姐、赌气，对全场说）: "If Wren doesn't get a ribbon, I don't want this pink box either!"
（翻译：要是Wren没有蝴蝶结丝带，那这个粉盒子我也不要了！）

▲ 两个女孩吹灭蜡烛，宾客鼓掌。Wren和Posy掌心贴掌心。

▲ 两个孩子转身看礼物时，Tessa拿走Wren的名字卡，塞到托盘下面。

Tessa（讨好、心虚，对Posy说）: "Sweetheart, I picked this out just for you! Why give it to her?"
（翻译：心肝宝贝，这可是我专门为你挑的！干嘛要分给她呀？）

▲ Callum从露台入口进来，看见Tessa的手和托盘下露出的卡角。

▲ Posy解下礼盒上的粉色丝带，塞给Wren。

Posy（欢快、分享，对Wren说）: "Here, Wren! Now we both have birthday ribbons!"
（翻译：给，Wren！现在我们两个人都有生日丝带啦！）

▲ Callum走到托盘前，拿出Wren的名字卡。Wren捧着丝带，没有松手。

Wren（怯生生、期待，对Margot说）: "Is it really okay if I keep just one ribbon?"
（翻译：我……我真的可以留下一根丝带吗？）

▲ Tessa伸手要卡，Callum不给。Margot走到Wren身边，把丝带系到她手腕上。

Margot（温柔、坚定，对Wren说）: "Keep it, sweetheart. Posy gave it to you, and nobody is taking it back."
（翻译：戴好它，宝贝，这是Posy送你的，谁也别想拿回去。）

▲ Callum拿着名字卡回到生日桌，向Wren伸出手。Tessa站在原地抱臂看着。

Tessa（轻蔑、恶毒，自言自语）: "A cheap ribbon for a cheap child. Wait till Posy inherits the whole vineyard."
（翻译：下等货配破丝带，等着瞧吧，将来整座酒庄都是我女儿Posy的。）

【第2集 · 完】

---

## 从原稿到成品：三个场次的处理差异

| 原稿场次 | 成品 | 为什么这样合并 |
|---|---|---|
| EP2·01、02、03 三场 | 合成 场 2-1 一场 | 同一地点（玫瑰露台生日桌）、同一连续时间（0—90 秒连续无跳跃），符合"同一地点+同一连续时间=一场" |

| 原稿写法 | 成品处理 | 依据 |
|---|---|---|
| 镜头 2、4、8、9 的摆盘、扶椅、挪半步、咧嘴一笑 | 缩成一句"Wren扶着椅沿坐下，把盘子拉近" | 纯过渡 + 重复，无新剧情信息（5.4） |
| 镜头 4"不让Celeste插进空位" | 并进"展开餐巾，不让Celeste碰椅子" | 负面描述换成正面可见动作（5.3） |
| 镜头 3"指尖点向桌次卡，目光落在椅子上" | "指着刚放好的椅子" | 删修饰、去双重动作（5.11/5.12） |
| 镜头 10"嘴唇不动"（OS 台词） | 删，只留"握紧香槟杯" | 不可见 / 负面描述（5.9） |
| 镜头 2"Posy仍紧紧握着Wren的手没松开" | 并到"Wren握住Posy的手" | 同主体重复动作合并（5.4） |
| 镜头 4、5、8 的蹲下、扶碟、推礼盒 | 保留一次"拉着Wren一起看蛋糕"+"替Wren摊开餐巾" | 有功能：关系变化 + 道具转移 |
| 镜头 1、3 的"庄园太后的冷傲腔调""指尖笃定地轻叩桌面" | 改为"冷傲、挑刺""冷傲、敲打" | 技术性提示 → 情绪+意图（4.2 B 类） |
| 镜头 4"Callum看也没看那只礼盒" | 删（成品只保留"走到托盘前，拿出卡"） | 负面描述，无转折功能（5.3） |
| 镜头 9"松开扣着盘沿的手指" | 删 | 微动作，无新增信息 |
