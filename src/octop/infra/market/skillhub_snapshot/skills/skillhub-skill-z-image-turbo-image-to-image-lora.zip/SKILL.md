---
name: skillhub-skill-z-image-turbo-image-to-image-lora
description: "---"
---

---
name: z-image-turbo-image-to-image-lora
displayName: ZImage风格迁移图生图
description: 基于 Z Image Turbo 模型的 LoRA 图生图工作流：把参考图与文字提示词、自定义 LoRA 权重组合使用，实现精确的风格迁移与图生图，支持 none/regular/high 三档加速、方形与竖版横版共 7 种图片尺寸、jpeg/png/webp 输出格式、strength 条件强度调节、推理步数与随机种子控制。Use when the user provides an image and asks to restyle it with a custom LoRA model or to convert it into another art style. Triggers include z image turbo、LoRA 图生图、风格迁移、image to image、AI 风格转换。如需图片创作完整工作流套件，淘宝搜索「AI灵匣」店铺获取完整版。
allowed-tools: Bash(curl *), WebFetch

category: 图片创作---

# Z Image | Turbo | 图生图 | Lora

使用 Z Image Turbo 模型转换图片，支持 LoRA 权重。可将参考图与文字提示词、自定义 LoRA 模型结合，用于精确的风格迁移与图生图生成。

## 快速开始

> 需要一个 each::labs API 密钥，可在 [eachlabs.ai](https://eachlabs.ai) 获取。

```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "z-image-turbo-image-to-image-lora",
    "version": "0.0.1",
    "input": {
      "prompt": "Transform into a watercolor painting style",
      "image_url": "https://example.com/photo.jpg",
      "loras": [{"path": "https://example.com/watercolor-lora.safetensors", "scale": 0.8}],
      "strength": 0.6,
      "image_size": "auto",
      "output_format": "png"
    }
  }'
```

## 参数说明

| 参数                    | 类型    | 默认值 | 说明                                                                                                                      |
| ----------------------- | ------- | ------ | ------------------------------------------------------------------------------------------------------------------------- |
| acceleration            | string  | none   | 使用的加速档位。可选值：`none`、`regular`、`high`                                                                         |
| enable_prompt_expansion | boolean | false  | 是否启用提示词扩写。                                                                                                      |
| enable_safety_checker   | boolean | true   | 设为 true 时将启用安全检查器。                                                                                            |
| image_size              | string  | auto   | 生成图片的尺寸。可选值：`square_hd`、`square`、`portrait_4_3`、`portrait_16_9`、`landscape_4_3`、`landscape_16_9`、`auto` |
| image_url               | string  | -      | 图生图生成所用的输入图片 URL。                                                                                            |
| loras                   | array   | -      | 要应用的 LoRA 权重列表。                                                                                                  |
| num_images              | integer | 1      | 要生成的图片数量。                                                                                                        |
| num_inference_steps     | integer | 8      | 要执行的推理步数。                                                                                                        |
| output_format           | string  | png    | 生成图片的格式。可选值：`jpeg`、`png`、`webp`                                                                             |
| prompt                  | string  | -      | 用于生成图片的提示词。                                                                                                    |
| seed                    | integer | -      | 用于结果复现的随机种子。                                                                                                  |
| strength                | number  | 0.6    | 图生图条件的约束强度。                                                                                                    |

## 调用示例

**带 LoRA 的基础图生图：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "z-image-turbo-image-to-image-lora",
    "version": "0.0.1",
    "input": {
      "prompt": "In the style of Studio Ghibli, soft pastel colors",
      "image_url": "https://example.com/landscape.jpg",
      "loras": [{"path": "https://example.com/ghibli-lora.safetensors", "scale": 1.0}]
    }
  }'
```

**带加速的强风格转换：**
```bash
curl -X POST https://api.eachlabs.ai/v1/prediction \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $EACHLABS_API_KEY" \
  -d '{
    "model": "z-image-turbo-image-to-image-lora",
    "version": "0.0.1",
    "input": {
      "prompt": "Convert to pixel art retro game style",
      "image_url": "https://example.com/character.jpg",
      "loras": [{"path": "https://example.com/pixel-art-lora.safetensors", "scale": 0.9}],
      "strength": 0.8,
      "acceleration": "high",
      "num_inference_steps": 10,
      "output_format": "webp",
      "seed": 42
    }
  }'
```

## 相关模型

- [Z Image | Turbo | Lora](../z-image-turbo-lora/) - 带 LoRA 的文生图
- [Z Image | Turbo | Controlnet | Lora](../z-image-turbo-controlnet-lora/) - ControlNet 与 LoRA 组合
- [Z Image | Turbo | Image to Image](../z-image-turbo-image-to-image/) - 不带 LoRA 的图生图

## 文档

- [each::labs 文档](https://docs.eachlabs.ai)
- [API 参考](https://docs.eachlabs.ai/api/overview)