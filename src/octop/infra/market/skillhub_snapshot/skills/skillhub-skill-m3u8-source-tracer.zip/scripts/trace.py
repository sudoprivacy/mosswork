#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
m3u8-source-tracer 辅助脚本

子命令:
  extract  --in <file> --out <json>
      从 xlsx / csv / txt 提取全部 http(s) URL，并解析出 注册域名 / 子域名。
  ssl <domain> [--port 443]
      抓取目标域名的 SSL 证书主题备用名(SAN)，用于关联分析（如同主体多域名）。
  report   --in <results.json> --out <xlsx>
      根据溯源结果 JSON 生成格式化 Excel 取证报告（3 个 Sheet）。

results.json 结构示例:
{
  "cases": [
    {
      "row": 1,
      "url": "http://vv.jisuzyv.com/play/xxx/index.m3u8",
      "domain": "jisuzyv.com",
      "station": "极速资源",
      "api": "https://jszyapi.com/api.php/provide/vod/from/jsvm3u8/",
      "backup": "jszyapi.com",
      "other_cdn": "jisuzyv.com, jsvm3u8.com",
      "evidence": "CDN域名'jisuzyv'为极速资源拼音缩写...",
      "status": "traced"          # traced | untraced
    }
  ]
}
"""

import argparse
import json
import re
import sys

# ── 控制台编码兜底 ──────────────────────────────────────────────────────
# 中文 Windows 下 stdout 被重定向/管道捕获时按 cp936 编码，本脚本输出的
# emoji / ✓✗ 等符号会抛 UnicodeEncodeError 并中断流程（Agent 调用即此场景）。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# ---------------- 注册域名解析 ----------------
MULTI_TLD = {
    "com.cn", "net.cn", "org.cn", "gov.cn", "edu.cn", "ac.cn",
    "com.tw", "net.tw", "org.tw", "com.hk", "com.br", "co.uk",
    "com.au", "co.jp", "com.sg",
}


def registered_domain(host: str) -> str:
    """剥离子域名，返回注册域名（最后 2 段，多段后缀取 3 段）。"""
    if not host:
        return ""
    host = host.strip().lower()
    # 去掉端口
    if ":" in host:
        host = host.split(":", 1)[0]
    # IP 地址直接返回
    if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", host):
        return host
    parts = host.split(".")
    if len(parts) <= 2:
        return host
    last2 = ".".join(parts[-2:])
    if last2 in MULTI_TLD and len(parts) >= 3:
        return ".".join(parts[-3:])
    return last2


def subdomain_of(host: str) -> str:
    reg = registered_domain(host)
    host = host.lower().split(":")[0]
    if host == reg:
        return ""
    return host[: -(len(reg) + 1)] if host.endswith(reg) else ""


URL_RE = re.compile(r"https?://[^\s\"'\]<>]+")


def url_type(url: str) -> str:
    """粗略分类: 直接 m3u8 CDN 源 / 下游播放页(影视站) / 其他。"""
    u = url.lower()
    if u.endswith(".m3u8") or "/hls/" in u or "m3u8" in u.split("?")[0]:
        return "m3u8"
    if u.endswith(".html") or "/play/" in u or "/v/" in u or "/detail/" in u:
        return "playpage"
    return "other"


# ---------------- extract ----------------
def extract_urls_from_text(text: str):
    return URL_RE.findall(text)


def extract_from_xlsx(path: str):
    try:
        import openpyxl
    except ImportError:
        print("错误: 需要 openpyxl 才能读取 xlsx。请运行: pip install openpyxl", file=sys.stderr)
        sys.exit(2)
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    urls = []
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            for cell in row:
                if isinstance(cell, str):
                    urls.extend(extract_urls_from_text(cell))
                elif cell is not None:
                    urls.extend(extract_urls_from_text(str(cell)))
    return urls


def cmd_extract(args):
    path = args.infile
    text = None
    if path.lower().endswith(".xlsx"):
        urls = extract_from_xlsx(path)
    else:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        urls = extract_urls_from_text(text)

    # 去重但保留顺序
    seen = set()
    results = []
    for i, u in enumerate(urls, 1):
        if u in seen:
            continue
        seen.add(u)
        m = re.match(r"https?://([^/]+)", u)
        host = m.group(1) if m else u
        results.append({
            "seq": len(results) + 1,
            "url": u,
            "host": host,
            "url_type": url_type(u),
            "registered_domain": registered_domain(host),
            "subdomain": subdomain_of(host),
        })

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({"count": len(results), "items": results}, f, ensure_ascii=False, indent=2)
    print(f"已提取 {len(results)} 条唯一 URL -> {args.out}")
    # 同时打印注册域名清单，方便直接对照已知库
    for it in results:
        tag = {"m3u8": "[m3u8]", "playpage": "[播放页]", "other": "[其它]"}.get(it["url_type"], "")
        print(f"  [{it['seq']}] {it['registered_domain']:24s} {tag:8s} <- {it['url'][:64]}")


# ---------------- ssl ----------------
def cmd_ssl(args):
    import ssl
    import base64
    import re

    domain = args.domain
    port = args.port
    try:
        pem = ssl.get_server_certificate((domain, port), timeout=15)
    except Exception as e:
        print(f"无法获取证书: {e}", file=sys.stderr)
        sys.exit(1)
    if not pem:
        print("未返回证书", file=sys.stderr)
        sys.exit(1)

    der = base64.b64decode("".join(pem.splitlines()[1:-1]))

    # 优先用 cryptography 精确解析 SAN
    sans = []
    issuer = None
    not_after = None
    method = "cryptography"
    try:
        from cryptography import x509
        cert = x509.load_pem_x509_certificate(pem.encode())
        try:
            ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
            sans = [n.value for n in ext.value]
        except Exception:
            pass
        try:
            issuer = cert.issuer.rfc4514_string()
        except Exception:
            pass
        try:
            not_after = cert.not_valid_after_utc.isoformat()
        except Exception:
            pass
    except Exception:
        # 回退：从 DER 字节中用正则提取域名样字符串（含 SAN 中的 DNS 名）
        method = "regex-heuristic"
        candidates = set()
        for s in re.findall(rb"[ -~]{4,}", der):
            s = s.decode("latin1", "ignore")
            for m in re.findall(r"\*?[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9_-]+)*\.[a-zA-Z]{2,}", s):
                if len(m) > 4:
                    candidates.add(m.lower())
        sans = sorted(candidates)

    print(f"域名: {domain}:{port}  (解析方式: {method})")
    print(f"证书到期: {not_after}")
    print(f"签发者: {issuer}")

    reg = registered_domain(domain)
    ca_noise = ("pki.", "letsencrypt", "digicert", "sectigo", "globalsign",
                "godaddy", "trust-provider", "ocsp", ".crl", ".crt", "usertrust",
                "comodoca", "alphassl", "geotrust", "symantec", "amazonaws", "azure")
    sans = [s for s in sans if not any(n in s for n in ca_noise)]
    print(f"证书内域名/名称 ({len(sans)}):")
    for s in sans:
        print(f"  - {s}")
    related = [s for s in sans if registered_domain(s) != reg and s != domain]
    if related:
        print("关联域名(不同注册域):")
        for s in related:
            print(f"  * {s}")
    else:
        print("（未检出明显跨注册域关联，或证书仅含本域）")


# ---------------- report ----------------
def cmd_report(args):
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        print("错误: 需要 openpyxl 才能生成报告。请运行: pip install openpyxl", file=sys.stderr)
        sys.exit(2)

    with open(args.infile, "r", encoding="utf-8") as f:
        data = json.load(f)
    cases = data.get("cases", [])

    wb = openpyxl.Workbook()

    header_font = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell_font = Font(name="微软雅黑", size=10)
    cell_align = Alignment(horizontal="left", vertical="center", wrap_text=True)
    center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    green_fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
    red_fill = PatternFill(start_color="FCE4EC", end_color="FCE4EC", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
    thin = Border(left=Side(style="thin"), right=Side(style="thin"),
                  top=Side(style="thin"), bottom=Side(style="thin"))

    # ---- Sheet1 视频源host溯源 ----
    ws1 = wb.active
    ws1.title = "视频源host溯源"
    headers = ["文档行号", "视频源URL", "CDN播放域名", "关联资源采集站名称",
               "采集API接口", "官网/备用域名", "其他CDN域名", "溯源依据"]
    for c, h in enumerate(headers, 1):
        cell = ws1.cell(1, c, h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin

    for i, it in enumerate(cases, 1):
        status = it.get("status", "untraced")
        fill = green_fill if status == "traced" else red_fill
        row = [
            it.get("row", i),
            it.get("url", ""),
            it.get("domain", ""),
            it.get("station", ""),
            it.get("api", ""),
            it.get("backup", ""),
            it.get("other_cdn", ""),
            it.get("evidence", ""),
        ]
        for c, v in enumerate(row, 1):
            cell = ws1.cell(i + 1, c, v)
            cell.font = cell_font
            cell.alignment = center_align if c in (1, 3) else cell_align
            cell.fill = fill
            cell.border = thin

    widths = [8, 62, 20, 22, 50, 22, 35, 58]
    for c, w in enumerate(widths, 1):
        ws1.column_dimensions[get_column_letter(c)].width = w
    ws1.row_dimensions[1].height = 30
    for r in range(2, len(cases) + 2):
        ws1.row_dimensions[r].height = 55
    ws1.freeze_panes = "A2"

    # ---- Sheet2 汇总统计 ----
    ws2 = wb.create_sheet("汇总统计")
    total = len(cases)
    uniq = len({c.get("domain", "") for c in cases})
    traced = sum(1 for c in cases if c.get("status") == "traced")
    untraced = total - traced
    traced_dom = len({c.get("domain", "") for c in cases if c.get("status") == "traced"})
    untraced_dom = uniq - traced_dom
    stats = [
        ("视频源URL总数（host条数）", total, "100%", "输入文件提供的 m3u8 视频源 URL 总数"),
        ("CDN播放域名总数", uniq, "100%", "从所有 URL 提取的唯一注册域名数量"),
        ("已溯源域名数", traced_dom, f"{round(traced_dom/uniq*100)}%" if uniq else "-", "成功关联到公开资源采集站的域名"),
        ("未溯源域名数", untraced_dom, f"{round(untraced_dom/uniq*100)}%" if uniq else "-", "未找到对应公开资源采集站的域名"),
        ("已溯源host覆盖数", traced, f"{round(traced/total*100)}%" if total else "-", "使用已溯源域名播放的 host 条数"),
        ("未溯源host条数", untraced, f"{round(untraced/total*100)}%" if total else "-", "未能溯源到公开资源站的 host 条数"),
    ]
    for c, h in enumerate(["统计项", "数量", "占比", "说明"], 1):
        cell = ws2.cell(1, c, h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin
    for i, (name, cnt, ratio, desc) in enumerate(stats, 2):
        if "已溯源" in name and "未" not in name:
            fill = green_fill
        elif "未溯源" in name:
            fill = red_fill
        else:
            fill = yellow_fill
        vals = [name, cnt, ratio, desc]
        for c, v in enumerate(vals, 1):
            cell = ws2.cell(i, c, v)
            cell.font = cell_font
            cell.alignment = center_align if c <= 3 else cell_align
            cell.fill = fill
            cell.border = thin
    for c, w in enumerate([26, 10, 10, 60], 1):
        ws2.column_dimensions[get_column_letter(c)].width = w
    ws2.row_dimensions[1].height = 30
    for r in range(2, len(stats) + 2):
        ws2.row_dimensions[r].height = 35

    # ---- Sheet3 溯源方法说明 ----
    ws3 = wb.create_sheet("溯源方法说明")
    methods = [
        ("CDN域名语义分析", "资源站CDN播放域名通常含站名拼音缩写（jisuzyv=极速、zuidazy=最大、modujx=魔都）", "名称特征明显的域名", "结合 known_stations.md 缩写字典假设"),
        ("苹果CMS接口探测", "资源站以 api.php/provide/vod/from/<标识>m3u8/ 向下游分发，返回结构化JSON", "验证资源站归属", "返回{code:1,...}即确认，最强证据"),
        ("SSL证书关联分析", "查询CDN域名证书SAN，发现同主体关联域名（如xluuss→subokk）", "语义不明显的私有CDN", "用 trace.py ssl <domain> 抓取"),
        ("URL路径结构比对", "不同站切片路径有特征（mixed.m3u8 / index.m3u8、清晰度标记）", "路径有特征但域名陌生", "仅作弱证据，需接口/搜索佐证"),
        ("多域名轮换追踪", "资源站编号递增换域（modujx10→modujx11），同族回溯主站", "已溯源站的其他播放域", "枚举相邻编号/前缀并探测"),
        ("搜索引擎关联", "搜索 <域名> 资源 采集 m3u8，找下游站/资源站列表/技术帖", "所有域名的辅助验证", "辅助验证关联关系"),
    ]
    for c, h in enumerate(["溯源方法", "技术原理", "适用场景", "本次应用"], 1):
        cell = ws3.cell(1, c, h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin
    for i, row in enumerate(methods, 2):
        for c, v in enumerate(row, 1):
            cell = ws3.cell(i, c, v)
            cell.font = cell_font
            cell.alignment = cell_align
            cell.fill = yellow_fill
            cell.border = thin
    for c, w in enumerate([20, 55, 30, 50], 1):
        ws3.column_dimensions[get_column_letter(c)].width = w
    ws3.row_dimensions[1].height = 30
    for r in range(2, len(methods) + 2):
        ws3.row_dimensions[r].height = 55

    out = args.out
    wb.save(out)
    print(f"报告已生成: {out}")
    print(f"  共 {total} 条 host | 已溯源 {traced} 条 / 未溯源 {untraced} 条 | 唯一域名 {uniq} 个")


# ---------------- CLI ----------------
def main():
    p = argparse.ArgumentParser(description="m3u8-source-tracer helper")
    sub = p.add_subparsers(dest="cmd", required=True)

    pe = sub.add_parser("extract", help="从文件提取 URL 与注册域名")
    pe.add_argument("--in", dest="infile", required=True)
    pe.add_argument("--out", default="domains.json")
    pe.set_defaults(func=cmd_extract)

    ps = sub.add_parser("ssl", help="抓取域名 SSL 证书 SAN")
    ps.add_argument("domain")
    ps.add_argument("--port", type=int, default=443)
    ps.set_defaults(func=cmd_ssl)

    pr = sub.add_parser("report", help="生成 Excel 取证报告")
    pr.add_argument("--in", dest="infile", required=True)
    pr.add_argument("--out", default="视频源溯源分析报告.xlsx")
    pr.set_defaults(func=cmd_report)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
