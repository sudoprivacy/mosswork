---
name: skillhub-skill-m3u8-source-tracer
description: "启动名「查源」。Reverse-trace M3U8/HLS video source URLs to their upstream resource collection and distribution sites (资源采集站/资源分发站) for copyright forensics. Use when a user provides one or more m3u8 links or a file of links and wants to identify the collection source: station name, appleCMS collection API, backup domains, other CDN domains, and evidence. Triggers: 查源, m3u8溯源, 视频源溯源, 找资源采集站, 侵权视频源源头, 视频源是哪"
---

# M3U8 视频源采集源头溯源（启动名：查源）

> **依赖**：`python -m pip install -r <本技能目录>/requirements.txt`（openpyxl；`cryptography` 可选，用于证书 SAN 精确解析）。

> **启动名：查源** — 一句话用法：「用查源处理 `<M3U8链接或文件>`」。给一条 M3U8 链接，反查其背后的资源采集站/分发站。

## 用途

给定一条或多条 M3U8 / HLS 视频源 URL（侵权取证场景中的播放链接），反向溯源其背后的**资源采集站 / 资源分发站**（影视资源收集、聚合、向下游影视站分发的网站）。产出结构化的取证报告，逐条把视频源 host 对应到采集源头。

适用场景：

- 用户提供单个 M3U8 链接，问"这个视频源是哪个资源站/采集站的"
- 用户提供一批 M3U8 链接（如 Excel 中的 host 列），要求批量溯源
- 版权取证、侵权资源链路分析、资源站生态调研

不适用：单纯播放/下载 M3U8、转码、或帮助用户搭建/运营资源站（不在本技能范围）。

## 功能一览

- **多格式输入**：单条/多条 M3U8 链接、Excel（`.xlsx`）、CSV、TXT，自动提取注册域名并区分 URL 类型（`m3u8` 直接源 / `playpage` 下游播放页 / `other`）。
- **混合数据兼容**：取证文件常同时含"CDN 源列 + 播放页列"（如 A 列 m3u8、B 列 `gimyai.tw` 播放页），两者都处理——m3u8 溯源采集站，播放页域名本身即"资源发布网站"。
- **六法联动溯源**：① CDN 域名语义（拼音缩写识别）② 苹果 CMS 采集 API 探测（最强证据，返回 `{code:1}` 即确认）③ SSL 证书 SAN 关联 ④ URL 路径结构比对 ⑤ 多域名轮换追踪 ⑥ 搜索引擎关联。
- **已知库直查**：内置 7+ 已核验资源站数据库（极速/如意/最大/优质/魔都/无水印/电影天堂等）、拼音缩写字典、检测特征，命中即出结果。
- **取证报告生成**：自动产出 3-Sheet Excel（逐条对应 / 汇总统计 / 方法说明），绿底=已溯源、红底=未溯源、冻结首行，便于回查与归档。

## 快速用法

```bash
# 1) 提取输入文件中的 URL 与注册域名（标注 url_type）
python scripts/trace.py extract --in 输入.xlsx --out domains.json

# 2) 对可疑域名做 SSL 证书关联分析（发现同证域名）
python scripts/trace.py ssl 域名

# 3) 把人工/自动溯源结果写成 results.json 后生成报告
python scripts/trace.py report --in results.json --out 视频源溯源分析报告.xlsx
```

> 最简用法：直接把 M3U8 链接或含链接的 Excel 丢给本技能，按工作流自动跑完并给出"视频源 → 采集站"对应表与取证报告。

## 核心概念

- **CDN 播放域名**：M3U8 URL 中的注册域名（如 `vv.jisuzyv.com` → 注册域名 `jisuzyv.com`）。资源站通过 CDN 域名直接对外提供切片播放。
- **资源采集站（源站）**：运营这些播放域名的影视资源聚合网站，通过标准化的**苹果 CMS 采集 API**（`api.php/provide/vod/from/标识m3u8/`）向下游影视站分发资源。
- **多域名轮换**：资源站常同时/轮换使用多个 CDN 播放域名（`modujx.com` → `modujx10.com` → `modujx11.com`；`yzzy-play` 系列编号轮换）。
- **首页跳转陷阱**：多数采集站的 API 域名首页会被设为 `meta refresh` 0.1 秒跳转到百度（`api.zuidapi.com` 即如此），直接浏览器打开会"自动关闭/跳走"，但 `api.php` 接口路径正常工作。溯源时**不要**依赖首页，直接探测接口。

## 工作流

### 步骤 1 — 归一化输入并提取注册域名

支持三类输入：

1. 单条/多条 M3U8 URL（用户直接粘贴）
2. 含 URL 列的 Excel（`.xlsx`，可多列）
3. CSV / TXT（每行一个 URL）

使用 `scripts/trace.py` 的 `extract` 子命令提取每条 URL 的 **注册域名**（剥离子域名 `vv.`/`play.`/`v6.`/`svip.`/`cdn.`/`v14.` 等，仅保留最后两段；对 `.com.cn`/`.net.cn` 等多段后缀保留三段），并标注 **URL 类型**：

```bash
python scripts/trace.py extract --in 输入文件 --out domains.json
```

`url_type` 取值：

- `m3u8`：以 `.m3u8` 结尾或含 `/hls/` → **直接 CDN 源**，直接进入步骤 2/3 溯源采集站。
- `playpage`：以 `.html` 结尾或含 `/play/`、`/v/`、`/detail/` → **下游影视站播放页**。这类 URL 本身是"资源发布网站"页面，需先用 `WebFetch` 抓取页面、提取其中内嵌的 m3u8 链接，再对 m3u8 溯源；同时把播放页域名（如 `gimyai.tw`）作为"发布站点"单独记录。
- `other`：其它，按内容判断。

> 关键：真实取证数据中 m3u8 与播放页常混在同一文件的不同列（如 A 列是 CDN 源、B 列是播放页）。两者都要处理——m3u8 用于溯源采集站，播放页域名本身就是要找的"资源发布网站"。

也可在内存中直接用正则 `https?://([^/:]+)` 取 host 后按上述规则取注册域名。

### 步骤 2 — 查已知库直接命中

加载 `references/known_stations.md`，将提取出的注册域名与库内条目比对：

- 直接命中 → 标记为 `traced`，填入站名、采集 API、备用域名、其他 CDN、证据。
- 未命中 → 进入步骤 3 做联网调查。

### 步骤 3 — 未命中域名的联网溯源（核心）

对未知域名，综合运用 `references/methodology.md` 中的方法，至少覆盖：

1. **CDN 域名语义分析**：域名是否包含资源站名拼音缩写（如 `jisuzyv`=极速资源、`zuidazy`=最大资源、`modujx`=魔都解析）。用缩写字典辅助假设。
2. **苹果 CMS 接口探测**：直接请求 `http(s)://域名/api.php/provide/vod/from/猜测标识m3u8/at/json/`，若返回 `{code:1,...}` 结构化 JSON 即确认其为采集 API 源站。这是最强证据。
3. **SSL 证书关联**：用 `scripts/trace.py ssl 域名` 抓取证书 SAN，发现关联域名（如 `xluuss.com` 证书签发给 `subokk.com`）推断归属。
4. **URL 路径结构比对**：不同资源站切片路径有特征（如 `mixed.m3u8` vs `index.m3u8`、日期目录格式），比对已知站结构。
5. **搜索引擎关联**：`WebSearch` 查询 域名 资源 采集 m3u8 / 域名 影视站，找调用该域名的下游站或资源站列表。
6. **多域名轮换追踪**：发现同族编号域名（如 `modujx10`/`modujx11`），回溯到主站。

优先用 `WebSearch` + `WebFetch` 验证假设，**不要凭缩写臆断**，每条结论需有可复核证据（API 响应、证书、搜索结果）。

### 步骤 4 — 组装溯源档案

对每条视频源，整理字段：

| 字段 | 说明 |
|---|---|
| 文档行号 | 原文件中的行号（便于回查） |
| 视频源 URL | 原始 M3U8 链接 |
| CDN 播放域名 | 提取的注册域名 |
| 关联资源采集站 | 站名（未溯源标注"未溯源 + 推测"） |
| 采集 API 接口 | 苹果 CMS 采集接口 URL |
| 官网/备用域名 | 源站主域 / API 域 |
| 其他 CDN 域名 | 同站轮换的其他播放域名 |
| 溯源依据 | 证据链（接口响应 / 证书 / 路径 / 搜索） |

### 步骤 5 — 生成取证报告

将溯源结果写入 `results.json`（结构见 `scripts/trace.py` 注释），用 `report` 子命令生成 Excel：

```bash
python scripts/trace.py report --in results.json --out 视频源溯源分析报告.xlsx
```

报告含 3 个 Sheet：**视频源host溯源**（13 条逐条对应，绿底=已溯源/红底=未溯源，冻结首行）、**汇总统计**、**溯源方法说明**。颜色编码：绿色=已溯源，红色=未溯源，黄色=方法/说明。

> 若用户直接要结果而不需要 Excel，也可在对话中以表格形式输出步骤 4 的字段。

## 脚本说明

`scripts/trace.py` 提供三个子命令：

- `extract --in 文件 --out json`：从 xlsx/csv/txt 提取 URL 与注册域名。
- `ssl 域名`：抓取该域名 SSL 证书的主题备用名（SAN），用于关联分析。
- `report --in results.json --out xlsx`：根据溯源结果 JSON 生成格式化 Excel 取证报告。

## 注意事项与局限

- 资源站域名**频繁更换**，已知库可能过期；联网溯源结果以当下查询为准，并在报告中标注查询时间。
- 部分域名属**私有 CDN**（被多个小型影视站调用、无公开采集 API），只能推测归属，须如实标注"未溯源"。
- 本报告为**技术层面反向溯源**（CDN 域名 → 采集站），不等同于法律上的运营主体认定；如需追责主体，需结合 ICP 备案、WHOIS 注册人等进一步取证。
- 遵守本国法律法规，仅用于合法版权取证与维权，不得用于协助侵权资源的分发或运营。

## 版本说明

- **1.1.2（2026-10-20）**：输出增加 UTF-8 编码兜底（中文 Windows 重定向场景）；随包补 `LICENSE.txt`。功能与 1.1.1 一致。
