# 溯源方法论（详细）

本文件展开 `SKILL.md` 步骤 3 的联网溯源方法，供未知域名调查时逐条执行。每条结论须有可复核证据。

## 方法 0：输入分类与播放页处理（前置）

取证文件常混合两类 URL：

- **直接 m3u8 CDN 源**（A 列典型）：`http://vv.jisuzyv.com/play/xxx/index.m3u8` → 直接走方法 1–6 溯源采集站。
- **下游播放页**（B 列典型）：`http://gimyai.tw/play/464807-8-1.html` → 这是影视站的内容页，**本身即"资源发布网站"**。

播放页处理流程：

1. 用 `WebFetch` 抓取播放页 HTML，定位其中的 m3u8 链接（通常在 `<source>`、`<video>`、或 JS 变量 / JSON 配置里，形如 `https://<cdn>/.../index.m3u8`）。
2. 提取出的 m3u8 进入方法 1–6 溯源其 CDN 采集站。
3. 播放页域名（如 `gimyai.tw`）单独作为"发布站点"记录——它通常是聚合了多个采集站资源的下游影视站，可能调用多家采集 API。
4. 进一步可 `WebSearch "<播放页域名>" 资源 采集` 看它挂载了哪些采集源、是否有官方/备用域名。

> 注意：`extract` 已按 `url_type` 标注类型，处理时据此分流，避免把播放页域名误当 CDN 采集站。



资源站的 CDN 播放域名通常含有站名拼音缩写或关键词。流程：

1. 取注册域名（剥离子域），拆词看是否命中 `known_stations.md` 的 C 字典。
2. 例：`jisuzyv` → ji-su-zy-v → 极速资源；`zuidazym3u8` → 直接含"最大资源"。
3. 仅凭语义只能形成**假设**，须用方法 2/5 验证。

## 方法 2：苹果 CMS 接口探测（最强证据）

资源站向下游分发资源普遍采用苹果 CMS / 海洋 CMS 采集接口，格式固定：

```
http(s)://<domain>/api.php/provide/vod/from/<标识>m3u8/at/json/
http(s)://<domain>/api.php/provide/vod/from/<标识>m3u8/at/xml/
```

操作步骤：

1. 用 `WebFetch` 或 `curl` 请求 `<domain>/api.php/provide/vod/from/<guess>m3u8/at/json/`。
   - 标识常用站名拼音：`js`/`jsv`（极速）、`zuidam`/`zuidazy`（最大）、`md`/`mdm`（魔都）、`yz`/`yzzy`（优质）、`ry`/`rym`（如意）、`ws`/`wsy`（无水印）、`dyt`/`dytt`（电影天堂）。
2. 若返回 `{"code":1,"msg":"数据列表","page":1,"pagecount":N,"total":M,"list":[...]}` → **确认为采集源站**，记录 `total`/`pagecount` 作为规模证据。
3. 常见返回键：`vod_id`, `vod_name`, `type_name`, `vod_time`, `vod_play_from`（即播放标识，应等于探测用的 `<标识>m3u8`），`vod_remarks`。
4. 若根域无接口，尝试常见 API 子域：`api.<domain>`、`cj.<domain>`、`api.<站名拼音>api.com`、`caiji.<站名>api.com`。

> 经验：最大资源用 `api.zuidapi.com`，魔都资源用 `mdzyapi.com`，无水印用 `api.wsyzy.net`，电影天堂用 `caiji.dyttzyapi.com` —— API 域常与播放域不同。

## 方法 3：SSL 证书关联分析

许多私有 CDN / 同主体多域名会在同一张证书中列 SAN。操作：

```bash
python scripts/trace.py ssl <domain>
```

- 提取证书 `subjectAltName`（SAN）与签发者。
- 例：`xluuss.com` 的证书 SAN 含 `subokk.com` → 推断两者同主体，进一步 `WebSearch subokk.com 资源` 找主站。
- 若证书由公共 CA 签发且 SAN 仅自身，则关联价值低。

补充：`crt.sh`（crt.sh 查询 `<domain>`）可查历史证书，发现已弃用但仍被引用的旧播放域名，有助于"多域名轮换追踪"。

## 方法 4：URL 路径结构比对

不同资源站的切片 URL 模板有差异，可作为同源指纹：

- 优质资源 / 电影天堂：`.../3000k/hls/mixed.m3u8`
- 最大资源 / 无水印：`.../2000k_1080/hls/index.m3u8`，日期目录 `YYYY/MM/DD/`
- 魔都资源：`.../5153kb/hls/index.m3u8`（清晰度用 `kb` 而非 `k`）
- 如意资源：`.../2000k/hls/index.m3u8`

操作：将未知域名的 M3U8 路径与已知站模板比对；模板高度相似 → 推测同源或同 CMS 模板。注意：**路径相似 ≠ 同站**，仅作弱证据，需方法 2/5 佐证。

## 方法 5：搜索引擎关联

用 `WebSearch` 以域名为主锚点：

- 查询模板：`<域名> 资源 采集 m3u8`、`"<域名>" 影视站`、`<域名> api.php provide vod`
- 目标：找到（a）提及该播放域名的下游影视站；（b）资源站排行榜/导航站中列出的源站；（c）技术讨论帖。
- 对私有 CDN（如 `xluuss.com`），搜索常指向"多个小站都在用这个播放域" → 判定为共享私有 CDN。

## 方法 6：多域名轮换追踪

资源站为抗封锁频繁换域：

- 规律：主标识 + 递增编号（`modujx`→`modujx10`→`modujx11`；`yzzy-play`→`yzzy27-play`）。
- 操作：对命中域名，枚举相邻编号/前缀变体并探测（方法 2），回溯到稳定主站及其采集 API。
- 例：已知 `modujx11.com` → 探测 `modujx.com`/`mdzyapi.com` → 锁定"魔都资源"。

## 方法 7：自建云点播平台（阿里云 VOD 等）——无上游采集站

近年出现一类"不像盗版生态"的影视站：它**不调用任何苹果 CMS 采集 API**，而是把片源托管在商业云点播（阿里云 VOD / 腾讯云 VOD / 又拍云等）并自研前端分发。此时"视频源 host"就是该站自己的云账户播放域名，**不存在可溯源的第三方资源采集/分发站**。判定与取证要点：

1. **播放器线索**：页面引入商业播放器 SDK（如阿里云 `g.alicdn.com/de/prismplayer/.../aliplayer-min.js`、腾讯云 TCPlayer），且 JS 中出现 `PlayAuth` / `vid` / `getPlayInfo` → 说明走云厂商 VOD 播放授权（播放域名由云厂商分配，或客户自有播放域名）。
2. **后端 API 为自有域名**：前端 axios/fetch 的 `baseURL` 是站点自己的 API 域（如 `open-web-api-v2.<brand>.cn`、`api.<brand>.com`），播放地址来自 `POST /media/get_play_movie_urls_v3` 之类**自有**接口，而非 `api.php/provide/vod/...`。
3. **接口强签名**：此类站点普遍用 HmacSHA1（密钥=会话 token）对请求签名，token 来自自有 OAuth（`oauth-api.<brand>.cn/apply_api_token`），常叠加 AES 设备指纹 + 动态 `signature_nonce`。**纯脚本难以复现签名**，直接 curl 会返回"安全校验失败"。取证时改为在真实登录会话内用 DevTools 抓包截取该接口响应，即可拿到 `vid`+`PlayAuth` 与真实播放域名。
4. **P2P 加速层**：自研"种子/P2P"播放组件常基于云厂商 RTC（如阿里云 RTC 域名 `rgslb-gtm.rtc.aliyuncs.com`、WebRTC `peerConnectionConfig`/`iceServers`/`turn.urls`）做 P2P 提速——这进一步说明带宽是站点自建 + P2P，并非外部采集站供给。
5. **结论写法**：报告"关联资源采集站"字段填"无（自建云点播分发，源头为站点自身 + 其云厂商账户）"，并在取证建议中改为：WHOIS/ICP 备案锁定运营主体 → 向云厂商 VOD 发起侵权下线与对运营主体发权利警告函，路径与"投诉上游采集站"不同。

> 经验：v.vcinema.cn（南瓜电影/Pumpkin Movie）即此模式——阿里云 PrismPlayer + `PlayAuth` + 自有 `open-web-api-v2.vcinema.cn` + 阿里云 RTC P2P（"南瓜种子"）。
> 注意：方法 7 是"技术溯源结论"，不构成法律上的侵权认定；是否盗版需另核片源授权。

## 证据强度分级（写入报告"溯源依据"）

| 等级 | 依据 | 报告标注 |
|---|---|---|
| 强 | 苹果 CMS 接口返回结构化数据 / 首页 meta-refresh 跳百度 | 已溯源 |
| 中 | 域名语义 + 搜索结果/证书双证 | 已溯源（标"推测性较强"） |
| 弱 | 仅证书关联 / 仅路径相似 / 仅语义 | 未溯源 + 推测说明 |

> 弱证据一律归"未溯源"，避免误导取证结论。
