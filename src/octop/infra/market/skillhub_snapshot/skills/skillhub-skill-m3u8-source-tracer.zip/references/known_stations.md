# 已知资源采集站数据库（已知库）

本库用于 `m3u8-source-tracer` 步骤 2 的直接命中比对。域名会频繁轮换，**以当下联网核验为准**。标注 `已核验` 的条目来自实际取证溯源（含接口响应/证书/路径证据）；其余为常见生态站，仅作假设引导，落地前必须 `WebSearch` 复核。

## A. 已核验资源站（可直接命中）

| 资源采集站 | CDN 播放域名（注册域名） | 采集 API 接口 | 官网/备用域名 | 其他 CDN 域名 | 备注 |
|---|---|---|---|---|---|
| 极速资源 | `jisuzyv.com` | `https://jszyapi.com/api.php/provide/vod/from/jsvm3u8/` | `jszyapi.com` | `jisuzyv.com`, `jsvm3u8.com` | 域名 `jisuzyv`=极速资源拼音缩写(ji-su-zy-v) |
| 如意资源 | `ryiplay18.com` | `https://cj.rycjapi.com/api.php/provide/vod/from/rym3u8/` | `cj.rycjapi.com` | `ryiplay` 系列（ryiplay18.com 等） | `ryiplay`=如意播放(ru-yi-play) |
| 最大资源 | `zuidazym3u8.com` | `https://api.zuidapi.com/api.php/provide/vod/from/zuidam3u8/` | `api.zuidapi.com` | `zuidazym3u8.com` | 域名直接含"最大资源"拼音；**首页 meta refresh 0.1s 跳百度**，接口正常 |
| 优质资源 / 高清资源库 | `yzzy27-play.com` | `https://api.yzzy-api.com/api.php/provide/vod/from/yzm3u8/` | `api.yzzy-api.com` | `yzzy27-play.com`, `yzzy-play` 系列编号轮换 | `yzzy`=优质资源(you-zhi-zi-yuan) |
| 魔都资源 | `modujx11.com` | `https://mdzyapi.com/api.php/provide/vod/from/mdm3u8/` | `mdzyapi.com` | `modujx.com`, `modujx10.com`, `modujx11.com`（编号轮换） | `modujx`=魔都解析(mo-du-jx) |
| 无水印资源 | `wsyzym3u8.com` | `https://api.wsyzy.net/api.php/provide/vod/from/wsym3u8/` | `api.wsyzy.net` | `wsyzym3u8.com` | `wsyzy`=无水印资源(wu-shui-yin-zi-yuan) |
| 电影天堂资源 | `phimgood.com` | `https://caiji.dyttzyapi.com/api.php/provide/vod/from/dytm3u8/` | `caiji.dyttzyapi.com` | `phimgood.com`, `dytt` 播放系列 | `phimgood` 为电影天堂资源播放域 |

## B. 未溯源域名样例（假设引导，需核验）

以下域名在取证中曾出现但**未找到公开采集站**，列此供同类判断：

| CDN 域名 | 观测现象 | 推测 | 证据强度 |
|---|---|---|---|
| `xluuss.com` | SSL 证书签发给 `subokk.com`；被多个小型影视站调用 | 某站私有 CDN | 弱（仅证书关联） |
| `jimxtc.com` | URL 路径 `mixed.m3u8` 与优质资源相似 | 疑似优质资源备用域/私有站 | 弱 |
| `ppqrrs.com` | URL 路径结构与最大资源相似 | 疑似最大资源备用 CDN | 弱 |

> 规则：证据弱时一律标注"未溯源 + 推测"，不臆断站名。

## C. 资源站名 → 拼音缩写假设字典

用于步骤 3「CDN 域名语义分析」生成搜索假设（**仅作线索，须联网复核**）：

| 关键词 | 常见缩写片段 | 示例 |
|---|---|---|
| 极速 | js / jisuzy / jsv | jisuzyv, jsvm3u8 |
| 最大 | zuidazy / zuid / zd | zuidazym3u8, zuidapi |
| 魔都 | modu / mo / md | modujx, mdzyapi |
| 优质 | yzzy / yz | yzzy27-play, yzzy-api |
| 如意 | ry / ruiyi | ryiplay, rycjapi |
| 无水印 | wsyzy / wushuiyin | wsyzym3u8, wsyzy |
| 电影天堂 | dytt / dyt | phimgood, dyttzyapi |
| 旭日 | xr / xuri | xrzy |
| 暴风 | bf / baofeng | bfzy |
| 七七 | qq / 77 | qqzy |
| 哆咪 | dm / duomi | dmzy |
| 肥猫 | fm / feimao | fmzy |
| 夜间 | yj / yejian | yjzy |
| 米饭 | mf / mifan | mfanzy |
| 火柴 | hc / huochai | hczy |
| 皮皮 | pp / pipi | ppzy |
| 天空 | tk / tiankong | tkzy |
| 草民 | cm / caomin | cmzy |
| 抢先看 | qxk | qxkzy |
| 天天 | tt / tiantian | ttzy |
| 酷播 | kb / kubo | kbzy |
| 资源(通用) | zy | 各类 `*zy*` 域名 |

## D. 检测特征（signature）

识别一个域名是否为资源采集站的依据：

1. **苹果 CMS 采集 API**：存在 `api.php/provide/vod/from/<标识>m3u8/at/json|xml/` 路径且返回结构化数据（`{code:1,"msg":"数据列表",...}`）。
2. **首页跳转陷阱**：根路径返回 `<meta http-equiv="refresh" content="0.1;url=https://www.baidu.com">`，这是采集 API 域的典型特征（挡人留机）。
3. **播放路径特征**：切片路径常含 `hls/index.m3u8` 或 `hls/mixed.m3u8`，前缀为日期目录 `YYYYMMDD/` 或 `YYYY/MM/DD/`，并带清晰度标记 `2000k`/`3000k`/`1000k_720` 等。
4. **多域名同构**：同一资源站旗下 CDN 域名常共享路径结构、仅域名前缀/编号不同。

> 命中特征 1 或 2 即可高置信判定为资源采集站体系，无需其余证据。
