# License

SPDX-License-Identifier: MIT

This identifier was preserved from the previously published Skill package.
