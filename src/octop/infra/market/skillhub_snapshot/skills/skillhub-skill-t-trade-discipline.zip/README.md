# 双仓做T纪律

底仓 + 机动仓双仓结构的做T纪律引擎。

```bash
python3 scripts/position.py --init 我的账户 600000   # 首次：生成配置模板
vim scripts/accounts.json                          # 改成真实持仓
python3 scripts/position.py                        # 查看纪律档位
python3 scripts/position.py --json                 # JSON 输出
```

- 配置示例：`assets/accounts.example.json`
- 四档纪律：止损 / 减仓 / 持有 / 观察
- 六条铁律 + 底仓逻辑断裂三条，见 SKILL.md

零第三方依赖，行情走腾讯公开接口。
