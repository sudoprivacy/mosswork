#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
position.py — 双仓结构持仓计算 + 纪律触发判定

零第三方依赖（Python 3.7+ 标准库）。行情走腾讯公开接口 qt.gtimg.cn。

配置从 accounts.json 读取（同目录或 --config 指定），结构见 accounts.example.json。

用法：
  python3 position.py                          # 列出全部账户简报
  python3 position.py --account tianfu          # 指定账户详情
  python3 position.py --account tianfu --json   # JSON 输出（供上层程序消费）
  python3 position.py --init demo 600000        # 生成一个账户配置模板
"""
import argparse
import json
import os
import sys
import urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(HERE, "accounts.json")

UA = {"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)"}


# ---------------------------------------------------------------- 行情
def fetch_quote(code):
    """腾讯行情。code 支持裸代码（600000）或带市场前缀（sh600000 / sz000001）"""
    code = str(code).strip().lower()
    if code[:2] not in ("sh", "sz", "bj"):
        code = ("sz" if code[0] in "0123" else "sh") + code
    raw = urllib.request.urlopen(
        urllib.request.Request(f"http://qt.gtimg.cn/q={code}", headers=UA), timeout=12
    ).read().decode("gbk", "ignore")
    f = raw.split('="', 1)[1].rsplit('"', 1)[0].split("~")

    vol_lot = float(f[36] or 0)          # 成交量（手）
    amt_wan = float(f[37] or 0)          # 成交额（万元）
    price = float(f[3])                  # 现价
    avg = (amt_wan * 10000 / (vol_lot * 100)) if vol_lot else price
    return {
        "name": f[1], "code": f[2],
        "price": price, "prev": float(f[4] or 0), "open": float(f[5] or 0),
        "high": float(f[33] or 0), "low": float(f[34] or 0),
        "pct": float(f[32] or 0),
        "vol_lot": vol_lot, "amt_yi": amt_wan / 10000,
        "avg": avg,                      # 分时均价线（黄线）
        "time": f[30],
    }


# ---------------------------------------------------------------- 配置
def load_config(path=CONFIG):
    if not os.path.isfile(path):
        print(f"❌ 找不到配置 {path}\n   先跑: python3 position.py --init <账户名> <股票代码>", file=sys.stderr)
        sys.exit(1)
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def init_account(name, code):
    tmpl = {
        "name": name,
        "code": code,
        "lots": [{"shares": 1000, "cost": 10.0}],
        "cash": 0.0,
        "strategy": {
            "bottom_shares": 400,
            "mobile_shares": 600,
            "mobile_cost": 10.0,
        },
        "rules": {
            "stop": 9.0,
            "trim_low": 12.0,
            "trim_high": 13.0,
            "hold_above": 12.0,
            "target": 15.0,
        },
        "levels": {
            "分水岭": None,
            "结构支撑": [],
            "三重底": [],
            "破位": None,
            "阻力": [],
        },
        "logic_break": [
            "① 核心客户砍单或订单份额大幅流失",
            "② 连续两季主营营收增速断崖下滑",
            "③ 核心技术路线被替代且公司无对应布局",
        ],
    }
    cfg = load_config() if os.path.isfile(CONFIG) else {"accounts": {}}
    cfg.setdefault("accounts", {})[name] = tmpl
    with open(CONFIG, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    print(f"✓ 已生成账户模板 {name}（{code}）→ {CONFIG}\n  请打开文件改成真实持仓后再跑。")


# ---------------------------------------------------------------- 计算
def evaluate(acc, q):
    """返回一个账户的完整评估结果"""
    shares = sum(int(l["shares"]) for l in acc.get("lots", []))
    mv = shares * q["price"]
    cash = float(acc.get("cash") or 0)
    st = acc.get("strategy") or {}
    rl = acc.get("rules") or {}

    bots = int(st.get("bottom_shares") or 0)
    mobs = int(st.get("mobile_shares") or 0)
    mcost = float(st.get("mobile_cost") or 0)
    stop = rl.get("stop")
    tlo, thi = rl.get("trim_low"), rl.get("trim_high")
    hold = rl.get("hold_above")
    target = rl.get("target")

    out = {
        "account": acc.get("name"),
        "code": acc.get("code"),
        "stock": q["name"],
        "price": q["price"],
        "pct": q["pct"],
        "avg": round(q["avg"], 2),
        "above_avg": q["price"] >= q["avg"],
        "shares": shares,
        "market_value": round(mv, 2),
        "cash": cash,
        "total_assets": round(mv + cash, 2),
        "bottom_shares": bots,
        "mobile_shares": mobs,
        "mobile_cost": mcost,
        "signals": [],
    }

    if mobs > 0 and mcost > 0:
        pnl = (q["price"] - mcost) * mobs
        out["mobile_pnl"] = round(pnl, 2)
        out["mobile_pnl_pct"] = round((q["price"] / mcost - 1) * 100, 2)

        if stop is not None and q["price"] <= float(stop):
            out["signals"].append(
                {"level": "stop", "icon": "🛑",
                 "text": f"已跌破止损线 {float(stop):.2f}，按纪律应执行止损"}
            )
        elif tlo is not None and thi is not None and float(tlo) <= q["price"] <= float(thi):
            out["signals"].append(
                {"level": "trim", "icon": "🎯",
                 "text": f"进入减仓区 {float(tlo):.2f}-{float(thi):.2f}，可分批做T锁利"}
            )
        elif hold is not None and q["price"] >= float(hold):
            out["signals"].append(
                {"level": "hold", "icon": "🚀",
                 "text": f"站上 {float(hold):.2f}，持有看目标 {target if target else '—'}"}
            )
        else:
            out["signals"].append(
                {"level": "wait", "icon": "⏸",
                 "text": f"处在 {stop}~{tlo} 之间，按纪律持有观察"}
            )

        if q["price"] < q["avg"]:
            out["signals"].append(
                {"level": "weak", "icon": "⚠️",
                 "text": f"分时白线 {q['price']:.2f} 在黄线 {q['avg']:.2f} 下方，偏弱不追买"}
            )
        else:
            out["signals"].append(
                {"level": "strong", "icon": "✅",
                 "text": f"白线在黄线上方（{q['avg']:.2f}），短线偏强"}
            )

    for lv in acc.get("levels", {}).get("阻力") or []:
        if q["price"] < lv <= q["high"]:
            out["signals"].append(
                {"level": "resist", "icon": "🔺",
                 "text": f"盘中触及阻力 {lv} 后回落，注意假突破"}
            )
    return out


def render(e):
    L = []
    L.append(f"===== {e['stock']}({e['code']}) {datetime.now():%Y-%m-%d %H:%M} =====")
    L.append(f"现价 {e['price']} ({e['pct']:+.2f}%) | 均价黄线 {e['avg']:.2f} "
             f"| {'上方偏强' if e['above_avg'] else '下方偏弱'}")
    L.append(f"持仓 {e['shares']}股 | 市值 {e['market_value']:,.0f}元 | "
             f"可用 {e['cash']:,.0f}元 | 总资产 ≈ {e['total_assets']:,.0f}元")
    if e["mobile_shares"]:
        L.append(f"├ 底仓 {e['bottom_shares']}股（长持，只看逻辑断裂）")
        L.append(f"└ 机动仓 {e['mobile_shares']}股@{e['mobile_cost']:.2f} | "
                 f"盈亏 {e.get('mobile_pnl', 0):+,.0f}元 ({e.get('mobile_pnl_pct', 0):+.2f}%)")
    for s in e["signals"]:
        L.append(f"  {s['icon']} {s['text']}")
    return "\n".join(L)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="双仓结构持仓计算 + 纪律触发判定")
    ap.add_argument("--account", "-a", help="账户名（不传则汇总全部）")
    ap.add_argument("--config", default=CONFIG, help="配置路径")
    ap.add_argument("--json", action="store_true", help="JSON 输出")
    ap.add_argument("--init", nargs=2, metavar=("NAME", "CODE"), help="生成账户模板")
    a = ap.parse_args()

    if a.init:
        init_account(*a.init)
        return

    cfg = load_config(a.config)
    accs = cfg.get("accounts") or {}
    if not accs:
        print("❌ 配置里没有账户", file=sys.stderr)
        sys.exit(1)

    targets = [a.account] if a.account else list(accs)
    results, errs = [], []
    for n in targets:
        acc = accs.get(n)
        if not acc:
            errs.append(f"未知账户 {n}")
            continue
        try:
            q = fetch_quote(acc["code"])
            results.append(evaluate(acc, q))
        except Exception as ex:
            errs.append(f"{n} 行情获取失败：{ex}")

    if a.json:
        print(json.dumps({"ok": not errs, "results": results, "errors": errs},
                         ensure_ascii=False, indent=2))
        return

    for e in results:
        print(render(e))
        print()
    for m in errs:
        print(f"⚠️ {m}")


if __name__ == "__main__":
    main()
