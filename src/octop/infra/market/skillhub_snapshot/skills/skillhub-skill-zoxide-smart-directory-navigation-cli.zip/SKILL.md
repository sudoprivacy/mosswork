---
name: skillhub-skill-zoxide-smart-directory-navigation-cli
description: "一个用 Rust 编写的更智能的 cd 命令，灵感来源于 z 和 autojump。zoxide 会学习您最常用的目录，并让您能够通过最少的按键在所有主要 shell 中跳转到这些目录。"
---

# zoxide 智能目录导航 CLI

A smarter cd command written in Rust, inspired by z and autojump. zoxide learns your most-used directories and lets you jump to them with minimal keystrokes across all major shells.

## Installation

Requirements and caveats from upstream:
- python

Basic usage or getting-started notes:
- [Getting started](#getting-started) •
- ![Tutorial][tutorial]
- sh

- Source: https://github.com/1991513ccie-png/skills
- Extracted from upstream docs: https://raw.githubusercontent.com/ajeetdsouza/zoxide/HEAD/README.md
