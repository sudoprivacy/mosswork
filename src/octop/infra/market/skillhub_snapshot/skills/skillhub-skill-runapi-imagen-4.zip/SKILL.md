---
name: skillhub-skill-runapi-imagen-4
description: "Optional RunAPI API key; runapi login or saved CLI config can also authenticate the runapi binary."
---

# Imagen 4 on RunAPI

Generate and edit images with Imagen 4 through RunAPI. The default path for one-off agent tasks is the `runapi` CLI; SDKs are for application integration.

## Routing decision

- One-off generation, editing, or transformation for the user → use the **CLI path** with the `runapi` binary.
- Building an app, backend, worker, library, or production codebase → use the **SDK integration path**.

## CLI path

The `runapi` binary is the runtime dependency. Authenticate with `runapi login` (browser) or set `RUNAPI_API_KEY`; a saved CLI config also works — no required environment variable.

Inspect the available actions and request fields with CLI help:

```shell
runapi imagen-4 --help
runapi imagen-4 text-to-image --help
```

Run a one-off task (synchronous — polls until the task completes):

```shell
runapi imagen-4 text-to-image --input-file request.json
```

Submit asynchronously and poll separately:

```shell
runapi imagen-4 text-to-image --async --input-file request.json
runapi wait <task-id> --service imagen-4 --action text-to-image
```

Available actions: `text-to-image`.

## SDK integration path

When integrating Imagen 4 into an app, backend, worker, or library — not for one-off tasks — use a RunAPI SDK package:

- JavaScript / TypeScript: `@runapi.ai/imagen-4`
- Ruby: `runapi-imagen_4`
- Go: `github.com/runapi-ai/imagen-4-sdk/go`

## References

- Model overview, pricing, and rate limits: https://runapi.ai/models/imagen-4.md
- Provider comparison: https://runapi.ai/providers/google.md
- Full model catalog: https://runapi.ai/models.md

## Variants

- [Imagen 4](https://runapi.ai/models/imagen-4/imagen-4.md)
- [Fast](https://runapi.ai/models/imagen-4/fast.md)
- [Ultra](https://runapi.ai/models/imagen-4/ultra.md)
- [Pro image to image](https://runapi.ai/models/imagen-4/pro-image-to-image.md)

