---
name: skillhub-skill-sbkj-usersearch14
description: "基于世舶科技全行业招投标数据，日更新30万+项目信息，支持招标、中标、采购意向、合同公告查询。查询核辐射监测、辐射防护、核应急及洗消设备采购项目，提取设备类型、检测指标、技术要求、采购数量和中标供应商。"
---

# 核辐射监测与应急洗消招标中标查询

查询核辐射监测、辐射防护、核应急及洗消设备采购项目，提取设备类型、检测指标、技术要求、采购数量和中标供应商。

## 适用范围与场景

先读 @references/domain-rules.md，按用户选择的子方向组织关键词，核实采购内容及主体角色。默认词库：核辐射|核应急|辐射防护|洗消帐篷|洗消舱|洗消设备|高纯锗|伽马能谱|剂量率。这只是候选词库，实际请求须按本次需求取舍，不直接用全部宽泛词扩张范围。

## 执行流程

1. **检查凭据。** 从环境变量BBIAO_API_KEY读取Key，再从BBIAO_SERVER_URL读取服务地址，未配置时使用https://gate.gov-bid.com。先运行python scripts/query_api.py check。没有Key立即停止调用，不读取业务请求、不联网、不搜索凭据；提示用户访问https://apiyx.gov-bid.com/?share=eyJjb2RlIjoic2Jrai0wMG1ibGJlZyJ9获取密钥，或直接提供已有密钥。不得自动注册、猜测或编造密钥；不得在回答、日志、报错或完整请求URL中显示真实Key。用户提供密钥后默认长期安全保存并直接复用，无需重复询问；优先存入运行平台安全凭据库并同步用户级环境变量BBIAO_API_KEY，无法配置环境变量时才存入访问权限受限的本地凭据文件。额度不足时提示充值https://console.api.gov-bid.com/bbiao-gateway/package。执行细节见 @references/auth.md。
2. **确定条件。** 按 @references/query-options.md 复用用户已明确的时间、地区、类型及关键词，只补问缺项，不擅自默认全国/近30天；相对日期按用户时区动态计算。
3. **选择字段。** 展示 @references/output-fields.md 的通用字段和本技能专属字段供用户选择。已有明确字段或默认列表授权可复用；没有选择时等待回复，再发业务请求。
4. **查询首页。** 按 @references/runtime-guide.md 使用scripts/query_api.py，默认第1页20条。只问数量用pageNumber=0。先交付本页，不自动全量。高级筛选不得静默丢弃不支持的条件。
5. **核验及补全。** 按所选字段复用列表和缓存，仅对最终保留公告补查。中标/候选/投标主体、预算/成交金额分别核实；专属字段需有真实正文证据。电话必须保留归属及来源，不把采购方/代理电话当成中标企业电话。
6. **交付与继续。** 参考templates/result.md只列所选业务字段，附真实证据。标清候选总数、已取条数、核验数及完整性；下一页只取下一页，用户明确要全部后才从第1页连续取到hasNext=false。导出CSV/JSON用固定脚本，不跳过失败页。

## 场景判断

核实核辐射监测、防护或应急洗消场景；医院普通清洗消毒不自动相关；原关键词采血管分拣机属跨领域词，不纳入默认核辐射词库。

专属输出：应用场景、设备类型、检测指标、量程与单位、防护要求、采购数量、验收要求。未在正文或已读附件中披露的字段标未披露/待核实，不用行业常识补值。

## 接口按需路由

| 任务 | 接口文档 |
| --- | --- |
| 自然语言地区及公告大类候选搜索 | @references/SearchProjectForAI.md |
| 金额、标的物、角色、采购类别、标题或细分类筛选 | @references/searchProjectApi.md |
| 项目编号、预算、中标金额、主体与来源 | @references/getZTBStructreDetail.md |
| 完整公告及专属字段原文依据 | @references/getZTBProjectDetail.md |
| 标的物、资质、评标方法及投标记录（2026-09-18及以后，可能无数据） | @references/getZTBStructreStep2DetailForCommon.md |
| 所选附件与下载地址 | @references/getZTBProjectFiles.md |
| 现有响应缺失采集源网址时补查 | @references/getCollectUrl.md |

枚举与码表：@references/common-parameters.md。采购分类、公告子类及字段大小写严格按附件。只读本任务需要的接口，不调用未收录的企业画像、电话或账户余额接口。
详情4个接口的multipart/form-data头配JSON体是源文档疑点，详见运行指南；400/415停止，不自动换格式。接口样例不能作为真实项目，未联调不声称查询成功。
