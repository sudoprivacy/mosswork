"""Export prepared records to a chosen-column CSV. Python standard library only."""
import argparse
import csv
import json
from pathlib import Path

def lookup(row, field):
    value = row
    for part in field.split("."):
        if not isinstance(value, dict) or part not in value:
            return "未返回"
        value = value[part]
    return "未返回" if value is None else value

def export_records(source, destination, columns):
    if not columns or len(set(columns)) != len(columns) or any(not c.strip() for c in columns):
        raise ValueError("必须提供不重复的所选字段")
    if Path(source).resolve() == Path(destination).resolve():
        raise ValueError("输入和输出路径必须不同")
    data = json.loads(Path(source).read_text(encoding="utf-8-sig"))
    rows = data.get("records") if isinstance(data, dict) else data
    if not isinstance(rows, list) or any(not isinstance(x, dict) for x in rows):
        raise ValueError("输入必须是记录数组或带records数组的JSON对象")
    result = []
    for row in rows:
        out = []
        for field in columns:
            v = lookup(row, field)
            if isinstance(v, (list, dict)):
                v = json.dumps(v, ensure_ascii=False)
            if isinstance(v, str) and v.lstrip().startswith(("=", "+", "-", "@")):
                v = "'" + v
            out.append(v)
        result.append(out)
    p = Path(destination)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(columns)
        writer.writerows(result)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", required=True)
    p.add_argument("--csv", required=True)
    p.add_argument("--columns", required=True)
    args = p.parse_args()
    try:
        export_records(args.input, args.csv, args.columns.split(","))
        print("EXPORTED")
    except (OSError, ValueError, TypeError):
        p.exit(2, "EXPORT_ERROR: 请核对JSON、字段选择及输出路径\n")

if __name__ == "__main__":
    main()
