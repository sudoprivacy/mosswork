#!/usr/bin/env python3
"""Shibo read-only API runner. Python 3.9+, standard library only."""
import argparse
import csv
import html
import hashlib
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from http.client import HTTPException
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, quote_plus, urlencode, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

AI = "SearchProjectForAI"
STEP2 = "getZTBStructreStep2DetailForCommon"
KEY_URL = "https://apiyx.gov-bid.com/?share=eyJjb2RlIjoic2Jrai0wMG1ibGJlZyJ9"
RECHARGE_URL = "https://console.api.gov-bid.com/bbiao-gateway/package"
SEARCH = {AI, "searchProjectApi"}
ENDPOINTS = SEARCH | {"getZTBStructreDetail", "getZTBProjectDetail",
                      "getZTBProjectFiles", "getCollectUrl", STEP2}
AI_FIELDS = set("startDate endDate pageId pageNumber keyword excludeKW inCludeKW className areaName companyName OrderByType".split())
ADV_FIELDS = set("startDate endDate pageId pageNumber searchType keyword subjectMatter excludeKW inCludeKW projectClassID searchMode areaCode industryCode subMatterIndustryCode contractEndMin contractEndMax purchaseTypeID partAName partBName agentName projectMoneyMin projectMoneyMax fileFlag companyName orderByType".split())


class ApiError(Exception):
    pass


def clean(value, key=""):
    """Remove credentials, including an unexpected server echo, before saving."""
    if isinstance(value, dict):
        return {clean(k, key): ("[REDACTED]" if k.lower() in {"key", "api_key", "bbiao_api_key", "token", "authorization"}
                    else clean(v, key)) for k, v in value.items()}
    if isinstance(value, list):
        return [clean(v, key) for v in value]
    if isinstance(value, str):
        if key:
            for representation in {key, quote(key, safe=""), quote_plus(key)}:
                value = value.replace(representation, "[REDACTED]")
        return re.sub(r"([?&](?:key|token|api_key)=)[^&\s\"<>]+", r"\1[REDACTED]", value, flags=re.I)
    return value


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def validate(endpoint, body, fetch_all=False):
    if endpoint not in ENDPOINTS or not isinstance(body, dict):
        raise ApiError("INVALID_REQUEST: 接口或请求对象无效")
    if endpoint in SEARCH:
        allowed = AI_FIELDS if endpoint == AI else ADV_FIELDS
        required = {"startDate", "endDate", "pageId", "pageNumber"}
        if endpoint != AI:
            required.add("searchType")
        if set(body) - allowed or required - set(body):
            raise ApiError("INVALID_PARAMETERS: 参数缺失或使用了该接口不支持的字段，请核对 reference")
        try:
            start = datetime.fromisoformat(body["startDate"])
            end = datetime.fromisoformat(body["endDate"])
            if start > end:
                raise ValueError()
        except (ValueError, TypeError):
            raise ApiError("INVALID_DATE: 日期须为 ISO 日期/时间且起始不晚于结束") from None
        for field in ("startDate", "endDate"):
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?", body[field]):
                raise ApiError("INVALID_DATE: 仅接受yyyy-MM-dd或yyyy-MM-dd HH:mm:ss")
        cap = 20 if endpoint == AI else 50
        if (type(body["pageId"]) is not int or body["pageId"] < 1 or
                type(body["pageNumber"]) is not int or not 0 <= body["pageNumber"] <= cap):
            raise ApiError("INVALID_PAGE: 页码或每页条数超出接口范围")
        if fetch_all and (body["pageId"] != 1 or body["pageNumber"] == 0):
            raise ApiError("INVALID_ALL: 全量采集须从第1页开始，且每页条数大于0")
        if endpoint != AI and (type(body["searchType"]) is not int or body["searchType"] not in (1, 2, 3)):
            raise ApiError("INVALID_SEARCH_TYPE: searchType须为1、2或3")
        for field in ("keyword", "excludeKW", "inCludeKW", "subjectMatter", "companyName"):
            if field in body and not isinstance(body[field], str):
                raise ApiError("INVALID_PARAMETERS: 关键词和名称必须为字符串")
        if endpoint == AI:
            if "OrderByType" in body and body["OrderByType"] not in {"发布时间", "相关性"}:
                raise ApiError("INVALID_PARAMETERS: OrderByType值无效")
            if "className" in body and (not isinstance(body["className"], str) or
                    set(body["className"].split(",")) - {"全部信息", "招标信息", "中标信息", "合同信息", "采购意向", "拍租信息"}):
                raise ApiError("INVALID_PARAMETERS: className值无效")
        else:
            validate_advanced(body)
    else:
        if fetch_all:
            raise ApiError("INVALID_ALL: 只有列表接口支持全量分页")
        id_field = "projectId" if endpoint == "getZTBProjectFiles" else "id"
        fields = {id_field, "publishTime"}
        if set(body) != fields or any(body[k] is None or body[k] == "" for k in fields):
            raise ApiError("INVALID_PARAMETERS: 请核对该接口的必填字段")
        if type(body[id_field]) is not int or body[id_field] < 1:
            raise ApiError("INVALID_ID: 必须使用真实正整数公告ID，不是项目编号")
        try:
            stamp = body["publishTime"]
            if not isinstance(stamp, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?", stamp):
                raise ValueError()
            datetime.fromisoformat(stamp)
        except ValueError:
            raise ApiError("INVALID_DATE: publishTime格式无效") from None
        if endpoint == STEP2 and datetime.fromisoformat(stamp).date().isoformat() < "2026-09-18":
            raise ApiError("STEP2_UNAVAILABLE: 该公告早于第二期详情覆盖日期，请按所选字段读取正文")


def validate_advanced(body):
    for field, choices in {"searchMode": {1, 2, 3}, "fileFlag": {-1, 0, 1}, "orderByType": {1, 2}}.items():
        if field in body and (type(body[field]) is not int or body[field] not in choices):
            raise ApiError("INVALID_PARAMETERS: 高级检索枚举值无效")
    for field, limit in {"keyword": 300, "excludeKW": 150, "inCludeKW": 150}.items():
        if len(body.get(field, "")) > limit:
            raise ApiError("INVALID_PARAMETERS: 关键词超过文档长度限制")
    for field in ("projectClassID", "purchaseTypeID", "partAName", "partBName", "agentName"):
        if field in body and not isinstance(body[field], str):
            raise ApiError("INVALID_PARAMETERS: 分类和主体名称须为字符串")
    nested = {"areaCode": {"proviceCodeList", "cityCodeList", "countyCodeList"},
              "industryCode": {"firstCodeList", "secondCodeList", "thirdCodeList"},
              "subMatterIndustryCode": {"firstCodeList", "secondCodeList", "thirdCodeList"}}
    for field, keys in nested.items():
        if field not in body:
            continue
        value = body[field]
        if not isinstance(value, dict) or set(value) - keys:
            raise ApiError("INVALID_PARAMETERS: 地区或行业嵌套参数无效")
        for values in value.values():
            if field == "subMatterIndustryCode" and isinstance(values, str):
                continue  # The supplied document types these values as strings.
            if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
                raise ApiError("INVALID_PARAMETERS: 编码列表须为字符串数组")
            if field == "areaCode" and any(v != "0" and not re.fullmatch(r"\d{6}", v) for v in values):
                raise ApiError("INVALID_PARAMETERS: 地区编码须为6位字符串")
    amounts = []
    for field in ("projectMoneyMin", "projectMoneyMax"):
        value = body.get(field)
        if value in (None, ""):
            amounts.append(None)
            continue
        try:
            if not isinstance(value, str):
                raise InvalidOperation()
            amount = Decimal(value)
            if not amount.is_finite() or amount < 0:
                raise InvalidOperation()
            amounts.append(amount)
        except InvalidOperation:
            raise ApiError("INVALID_AMOUNT: 金额须为非负有限数字字符串，单位元") from None
    if all(v is not None for v in amounts) and amounts[0] > amounts[1]:
        raise ApiError("INVALID_AMOUNT: 金额下限不得超过上限")
    dates = []
    for field in ("contractEndMin", "contractEndMax"):
        value = body.get(field)
        try:
            if value:
                if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
                    raise ValueError()
                datetime.fromisoformat(value)
            dates.append(value or None)
        except ValueError:
            raise ApiError("INVALID_DATE: 合同截止日期格式无效") from None
    if all(dates) and dates[0] > dates[1]:
        raise ApiError("INVALID_DATE: 合同截止日期区间倒置")


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Client:
    def __init__(self, key=None, base=None, interval=1.0, detail_json=False):
        self.key = (os.environ.get("BBIAO_API_KEY", "") if key is None else key).strip()
        if not self.key:
            raise ApiError("MISSING_API_KEY: 未配置BBIAO_API_KEY，已停止调用且未发起网络请求；请访问 "
                           + KEY_URL + " 获取密钥，或直接提供已有密钥；按技能凭据规则安全保存后复用")
        base = (base or os.environ.get("BBIAO_SERVER_URL") or "https://gate.gov-bid.com").rstrip("/")
        u = urlsplit(base)
        local_http = u.scheme == "http" and u.hostname in {"localhost", "127.0.0.1", "::1"}
        if (not u.hostname or (u.scheme != "https" and not local_http) or u.username or u.password
                or u.query or u.fragment or u.path not in {"", "/outer-gateway"}):
            raise ApiError("INVALID_SERVER_URL: 服务地址须为HTTPS主机，可带/outer-gateway；仅本机测试允许HTTP")
        self.base = base if u.path else base + "/outer-gateway"
        self.interval = interval
        self.detail_json = detail_json
        self.last = 0.0
        self.opener = build_opener(NoRedirect())

    def post(self, endpoint, body):
        validate(endpoint, body)
        # Never print Request/full URL/HTTPError; each can contain the API key.
        url = self.base + "/bid/" + endpoint + "?" + urlencode({"key": self.key})
        for attempt in range(3):
            time.sleep(max(0, self.interval - (time.monotonic() - self.last)))
            self.last = time.monotonic()
            content_type = "application/json; charset=utf-8" if endpoint in SEARCH or endpoint == STEP2 or self.detail_json else "multipart/form-data"
            req = Request(url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                          headers={"Content-Type": content_type}, method="POST")
            try:
                with self.opener.open(req, timeout=30) as res:
                    raw = res.read(16 * 1024 * 1024 + 1)
                if len(raw) > 16 * 1024 * 1024:
                    raise ApiError("RESPONSE_TOO_LARGE: 响应过大，未解析")
                payload = json.loads(raw.decode("utf-8-sig"))
                if not isinstance(payload, dict):
                    raise ApiError("INVALID_RESPONSE: 响应必须为JSON对象")
                statuses = []
                if "code" in payload:
                    statuses.append(str(payload["code"]) == "200")
                if "state" in payload:
                    statuses.append(str(payload["state"]) == "1")
                if not statuses or not all(statuses) or str(payload.get("subCode", "0000000000")) not in {"0000000000", "", "None"}:
                    # Raw business messages can echo credentials; classify without printing them.
                    msg = str(payload.get("subMsg", "")) + str(payload.get("msg", ""))
                    kind = "QUOTA_EXHAUSTED" if any(s in msg for s in ("余额", "额度", "配额", "充值")) else "BUSINESS_ERROR"
                    guidance = "；额度不足请充值 " + RECHARGE_URL if kind == "QUOTA_EXHAUSTED" else ""
                    raise ApiError(kind + ": 服务端业务失败，停止请求；检查凭据、额度及参数，不当作零结果" + guidance)
                return clean(payload, self.key)
            except HTTPError as exc:
                status = exc.code
                retry_after = exc.headers.get("Retry-After", "")
                exc.close()
                if status == 429:
                    try:
                        delay = max(1.0, float(retry_after))
                    except ValueError:
                        from email.utils import parsedate_to_datetime
                        try:
                            delay = max(1.0, (parsedate_to_datetime(retry_after) - datetime.now(timezone.utc)).total_seconds())
                        except (ValueError, TypeError, OverflowError):
                            delay = 2 ** attempt
                    if delay > 60:
                        raise ApiError("RATE_LIMITED: Retry-After超过60秒，请稍后重试当前页") from None
                elif status in {500, 502, 503, 504}:
                    delay = 2 ** attempt
                else:
                    raise ApiError("HTTP_" + str(status) + ": 请求失败并停止，未将错误页作为查询结果") from None
            except (URLError, TimeoutError, ConnectionError, HTTPException):
                delay = 2 ** attempt
            except (ValueError, UnicodeError):
                raise ApiError("INVALID_JSON: 响应不是有效JSON，未作为零结果") from None
            if attempt == 2:
                raise ApiError("RETRY_EXHAUSTED: 当前请求初次及2次重试仍失败")
            time.sleep(delay)


class CachedClient(Client):
    """Credential-scoped, optional local response cache; no secret is persisted."""
    def __init__(self, *args, cache_dir=None, cache_ttl=3600, refresh_cache=False, **kwargs):
        super().__init__(*args, **kwargs)
        if cache_ttl < 0:
            raise ApiError("INVALID_CACHE_TTL: 缓存有效期不得为负数")
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.cache_ttl = cache_ttl
        self.refresh_cache = refresh_cache
        self.last_from_cache = False
        self.last_fetched_at = None

    def post(self, endpoint, body):
        validate(endpoint, body)
        identity = [self.base, endpoint, body, hashlib.sha256(self.key.encode()).hexdigest()]
        digest = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        path = self.cache_dir / (digest + ".json") if self.cache_dir else None
        if path and path.exists() and not self.refresh_cache:
            try:
                cached = json.loads(path.read_text(encoding="utf-8"))
                age = time.time() - cached["created_at"]
                if 0 <= age <= self.cache_ttl:
                    self.last_from_cache = True
                    self.last_fetched_at = cached["fetched_at"]
                    return clean(cached["response"], self.key)
            except (OSError, ValueError, KeyError, TypeError):
                pass
        payload = super().post(endpoint, body)
        self.last_from_cache = False
        self.last_fetched_at = datetime.now(timezone.utc).isoformat()
        if path:
            write_json(path, {"created_at": time.time(), "fetched_at": self.last_fetched_at,
                              "response": clean(payload, self.key)})
        return payload


def notice_key(row):
    if not isinstance(row, dict):
        raise ApiError("INVALID_RECORD: 列表记录不是对象")
    identity = row.get("id")
    valid = (type(identity) is int and identity > 0) or (
        isinstance(identity, str) and bool(re.fullmatch(r"[0-9]+", identity)) and int(identity) > 0)
    if not valid or not row.get("publishTime"):
        raise ApiError("INVALID_RECORD: 列表记录缺少id或publishTime，无法可靠去重")
    return (str(int(identity)), str(row["publishTime"]))


def collect(client, endpoint, body, output, fetch_all=False):
    validate(endpoint, body, fetch_all)
    result = {"endpoint": "/bid/" + endpoint, "query": body.copy(),
              "queried_at": datetime.now(timezone.utc).isoformat(), "complete": False,
              "scope": "候选公告，未经场景相关性、主体角色及金额口径核验", "pages": [], "records": [],
              "candidate_total": None, "has_next": None, "failed_page": None}
    seen = set()
    fingerprints = set()
    page = body.get("pageId", 1)
    total = None
    try:
        while True:
            current = body.copy()
            if endpoint in SEARCH:
                current["pageId"] = page
            payload = clean(client.post(endpoint, current), getattr(client, "key", ""))
            if endpoint not in SEARCH:
                if endpoint == "getCollectUrl":
                    source = payload.get("returnValue") or payload.get("returnvalue")
                    if source is not None and not isinstance(source, str):
                        raise ApiError("INVALID_RESPONSE: 来源链接应为字符串或空值")
                    if source:
                        parsed = urlsplit(source)
                        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
                            raise ApiError("INVALID_SOURCE_URL: 未返回可用的HTTP/HTTPS采集源地址")
                    result["source_url"] = source or None
                elif endpoint == "getZTBProjectFiles":
                    if not isinstance(payload.get("data"), list):
                        raise ApiError("INVALID_RESPONSE: 附件响应缺少data数组")
                elif endpoint == STEP2 and payload.get("data") is None:
                    result["data_available"] = False
                elif not isinstance(payload.get("data"), dict):
                    raise ApiError("INVALID_RESPONSE: 详情响应缺少data对象")
                result["response"] = payload
                result["fetched_at"] = getattr(client, "last_fetched_at", None)
                result["from_cache"] = getattr(client, "last_from_cache", False)
                result["complete"] = True  # Only this single API call; not a verified business conclusion.
                break
            data = payload.get("data")
            if not isinstance(data, dict) or type(data.get("total")) is not int or data["total"] < 0:
                raise ApiError("INVALID_PAGINATION: 缺少有效的data.total")
            if total is None:
                total = data["total"]
                result["candidate_total"] = total
            if total != data["total"]:
                raise ApiError("TOTAL_CHANGED: 翻页期间总数变化，请重新查询，当前结果不完整")
            if body["pageNumber"] == 0:
                result["count_only"] = True
                result["count_request_succeeded"] = True
                break
            rows = data.get("data")
            has_next = data.get("hasNext")
            if not isinstance(rows, list) or type(has_next) is not bool or type(data.get("pageId")) is not int or data["pageId"] != page:
                raise ApiError("INVALID_PAGINATION: 记录、hasNext或返回页码异常")
            if len(rows) > body["pageNumber"] or (not rows and has_next):
                raise ApiError("INVALID_PAGINATION: 超出每页条数或出现异常空页")
            keys = [notice_key(row) for row in rows]
            fingerprint = tuple(keys)
            if rows and (fingerprint in fingerprints or all(k in seen for k in keys)):
                raise ApiError("REPEATED_PAGE: 服务端重复返回已获取记录，停止异常循环")
            if not has_next and not rows and total > 0:
                raise ApiError("COUNT_MISMATCH: 非零总数却返回空末页")
            fingerprints.add(fingerprint)
            for row, key in zip(rows, keys):
                if key not in seen:
                    seen.add(key)
                    result["records"].append(row)
            result["pages"].append({"page": page, "raw_count": len(rows), "response": payload,
                                    "from_cache": getattr(client, "last_from_cache", False),
                                    "fetched_at": getattr(client, "last_fetched_at", None)})
            result["has_next"] = has_next
            if not has_next:
                if body["pageId"] == 1 and len(seen) != total:
                    raise ApiError("COUNT_MISMATCH: 已到末页但去重公告数与total不符")
                result["complete"] = body["pageId"] == 1 and len(seen) == total
                break
            if len(seen) >= total:
                raise ApiError("COUNT_MISMATCH: hasNext与候选总数矛盾")
            write_json(output, clean(result, getattr(client, "key", "")))
            if not fetch_all:
                break
            page += 1
    except ApiError as exc:
        result["complete"] = False
        result["failed_page"] = page
        result["error"] = clean(str(exc), getattr(client, "key", ""))
        result["fetched_unique"] = len(result["records"])
        write_json(output, clean(result, getattr(client, "key", "")))
        raise
    result["fetched_unique"] = len(result["records"])
    write_json(output, clean(result, getattr(client, "key", "")))
    return result


def export_csv(result, path, fields):
    if not fields or len(fields) != len(set(fields)) or any(not f.strip() for f in fields):
        raise ApiError("INVALID_COLUMNS: 必须提供用户所选原生字段，编号F/X先由执行者按字段文档映射")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for row in result["records"]:
            out = {k: row.get(k) if row.get(k) is not None else "未返回" for k in fields}
            for key, value in out.items():
                if isinstance(value, (list, dict)):
                    out[key] = json.dumps(value, ensure_ascii=False)
            if "title" in out:
                out["title"] = html.unescape(re.sub(r"<[^>]+>", "", str(out["title"])))
            # CSV cells must remain data when opened in spreadsheet software.
            for key, value in out.items():
                if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
                    out[key] = "'" + value
            writer.writerow(out)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    subs.add_parser("check", help="仅检查Key配置，不读取业务请求、不联网")
    call = subs.add_parser("call", help="调用已授权的只读API；密钥仅从环境变量读取")
    call.add_argument("--endpoint", required=True, choices=sorted(ENDPOINTS))
    call.add_argument("--body", required=True, help="请求JSON文件路径")
    call.add_argument("--output", required=True)
    call.add_argument("--all", action="store_true", help="用户明确要求全量后使用")
    call.add_argument("--csv", help="额外导出候选CSV；同时检查JSON中的complete及error")
    call.add_argument("--columns", help="CSV原生字段名，英文逗号分隔；按用户所选顺序")
    call.add_argument("--detail-json", action="store_true", help="仅在服务端已确认详情接受JSON时启用，不自动切换格式")
    call.add_argument("--cache-dir", help="可选本地响应缓存目录；缓存按服务、凭据指纹、接口及请求隔离")
    call.add_argument("--cache-ttl", type=int, default=3600, help="缓存有效期秒数，默认3600")
    call.add_argument("--refresh-cache", action="store_true", help="跳过缓存发起新请求")
    args = parser.parse_args(argv)
    try:
        client = CachedClient(detail_json=getattr(args, "detail_json", False),
                              cache_dir=getattr(args, "cache_dir", None),
                              cache_ttl=getattr(args, "cache_ttl", 3600),
                              refresh_cache=getattr(args, "refresh_cache", False))
        if args.command == "check":
            print("KEY_CONFIGURED: 已配置；未发起网络请求")
            return 0
        if args.csv and not args.columns:
            raise ApiError("INVALID_COLUMNS: CSV需要--columns，不得默认展开未选字段")
        if args.columns and not args.csv:
            raise ApiError("INVALID_COLUMNS: --columns需与--csv一起使用")
        columns = args.columns.split(",") if args.columns else None
        if columns and (len(columns) != len(set(columns)) or any(not f.strip() for f in columns)):
            raise ApiError("INVALID_COLUMNS: 字段不能重复或为空")
        if args.csv and args.endpoint not in SEARCH:
            raise ApiError("INVALID_COLUMNS: 单接口详情请按response和所选字段整理，不导出空列表")
        outputs = [Path(args.output).resolve()] + ([Path(args.csv).resolve()] if args.csv else [])
        if Path(args.body).resolve() in outputs or len(set(outputs)) != len(outputs):
            raise ApiError("INVALID_PATH: 输入、结果JSON和CSV必须使用不同路径")
        body = json.loads(Path(args.body).read_text(encoding="utf-8-sig"))
        validate(args.endpoint, body, args.all)
        result = collect(client, args.endpoint, body, args.output, args.all)
        if args.csv:
            export_csv(result, args.csv, columns)
        print(json.dumps({"status": "OK", "candidate_total": result["candidate_total"],
                          "fetched_unique": result.get("fetched_unique", 0),
                          "complete": result["complete"], "has_next": result["has_next"]}, ensure_ascii=False))
        return 0
    except ApiError as exc:
        print(str(exc), file=sys.stderr)
    except (OSError, ValueError, TypeError):
        print("LOCAL_INPUT_ERROR: 请检查文件、JSON和日期格式；未输出原始异常以避免泄漏凭据", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
