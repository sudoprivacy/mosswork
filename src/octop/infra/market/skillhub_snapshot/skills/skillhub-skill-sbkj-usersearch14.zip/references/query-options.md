# 查询条件与路由

先复述已给条件，仅补问缺失的必需条件；已有明确条件和字段选择可直接复用，不重复确认。必需项：细分方向/关键词、发布日期范围、公告类型；地区由用户选，不擅自设为全国或最近30天。相对日期按用户时区 Asia/Shanghai 和执行当天动态计算；近7天含当天共7个自然日。不得沿用接口文档示例日期。

| 可选条件 | Agent接口 | 高级接口/处理 |
| --- | --- | --- |
| 发布开始/结束日期 | startDate / endDate | 同名 |
| 主关键词 | keyword，空格为同时出现、竖线为或 | keyword；上限300字符，searchType=3表示高级语法 |
| 排除词 | excludeKW | 同名，上限150字符 |
| 必含词 | inCludeKW | 同名，上限150字符，不与主关键词重复 |
| 标的物 | 不支持 | subjectMatter |
| 地区 | areaName | areaCode（proviceCodeList保留文档拼写） |
| 公告类型 | className | projectClassID；候选人公示6与成交结果2区分 |
| 采购类别 | 不支持 | purchaseTypeID：1服务、2工程、3货物、0其他 |
| 甲方行业 | 不支持 | industryCode，行业码须核实 |
| 标的物行业 | 不支持 | subMatterIndustryCode，原文类型与示例不一致，确认前避免发送 |
| 指定参与企业、角色不明 | companyName | companyName |
| 指定采购方/中标方/代理 | 不支持角色限定 | partAName / partBName / agentName；之后核验实际角色 |
| 项目金额上下限（元） | 不支持 | projectMoneyMin / projectMoneyMax |
| 合同截止日期区间 | 不支持 | contractEndMin / contractEndMax |
| 是否有附件 | 不支持 | fileFlag：-1不限、0无、1有 |
| 搜索标题或正文 | 不支持 | searchMode：1全部、2标题、3正文 |
| 搜索方式 | 无此参数 | searchType：1智能模糊、2精准、3高级；由任务语义选择并说明 |
| 排序 | OrderByType：发布时间/相关性 | orderByType：2发布时间/1得分 |
| 页码与条数 | pageId / pageNumber，最多20 | 同名，文档最多50，本技能默认20 |
| 只查数量 | pageNumber=0 | 同名 |
| 输出字段与格式 | 不作为接口筛选参数 | 按output-fields.md选择，Markdown/CSV/JSON |

优先使用 SearchProjectForAI 承接自然语言地区及公告大类查询。需要原生金额、采购类别、主体角色、标题检索、标的物或细分类时用 searchProjectApi；不把不支持的条件丢掉或塞进Agent接口。金额字段是接口项目金额筛选，不等于已核实的预算或成交金额。高级检索地区/行业编码仅用附件码表或已核实代码；没有代码时请求提供代码，或说明改用Agent候选检索后核验，不编造编码。
机构型技能的银行、医院、协会等词只能形成候选，实际采购方须从partyAInfo/partAInfo/正文采购人核实。泛词不能直接写为公司全称条件；用户给出明确全称时才按角色映射。
默认词库只提供候选，不把所有子方向强制并查。先按用户范围挑选相关词组，长词串按完整或分支拆分，保留批次映射；不能截断到长度限制。每批首页最多20条，再按id+publishTime去重；多批候选total不能相加当作去重总数。用户要求总共20条时合并后只展示20条。
零结果时说明当前条件，提出可放宽的具体项，待用户选择；不得静默改时间、地区、金额或业务对象。只问数量时不补详情。
