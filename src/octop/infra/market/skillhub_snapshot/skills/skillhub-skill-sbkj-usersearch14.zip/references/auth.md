# 密钥APIkey获取使用与API服务地址

按以下顺序处理：

1. 从环境变量 BBIAO_API_KEY 读取密钥。
2. 从环境变量 BBIAO_SERVER_URL 读取服务地址；未配置时使用 https://gate.gov-bid.com。
3. 如未找到密钥，立即停止调用，并提示用户访问 [https://apiyx.gov-bid.com/?share=eyJjb2RlIjoic2Jrai0wMG1ibGJlZyJ9](https://apiyx.gov-bid.com/?share=eyJjb2RlIjoic2Jrai0wMG1ibGJlZyJ9) 获取密钥，或直接提供已有密钥。
4. 不得自动注册、猜测或编造密钥；不得在回答、日志、报错或完整请求 URL 中显示真实密钥。
5. 用户提供密钥后，默认长期安全保存，后续任务直接复用，无需重复询问。
6. 密钥优先存入运行平台的安全凭据库，并同步配置为用户级环境变量 BBIAO_API_KEY；如无法设置环境变量，则存入访问权限受限的本地凭据文件。
7. 用户使用额度不足时，提示用户充值[https://console.api.gov-bid.com/bbiao-gateway/package](https://console.api.gov-bid.com/bbiao-gateway/package)。

## 执行说明

缺Key先停止，不读取业务请求、不发业务或余额探测请求，不搜索磁盘或猜测凭据。用户随后提供密钥时，按上述第5、6条保存并复用；不得把密钥放进技能目录、请求JSON、命令行参数、报告、缓存或版本库。使用平台受保护的输入渠道；受限本地文件仅作为无法配置环境变量时的替代，不以普通明文文件冒充安全存储。
运行脚本读取进程环境变量；保存到用户级环境后需同步注入当前运行进程，或重启运行会话再使用。受限凭据文件采用已明确的固定路径，执行者从该文件恢复到当前进程环境后再运行，不进行全盘扫描；保存渠道不可用时如实说明，不能声称已长期保存。
服务主机默认https://gate.gov-bid.com；脚本拼接/outer-gateway/bid/及接口名。BBIAO_SERVER_URL已带/outer-gateway时不重复拼接。接口参考中的完整请求地址保持原文，不作获取Key入口使用。
配置检查成功只说明环境变量存在，不证明鉴权、套餐、额度或网络可用。不得回显真实Key、带Key的请求URL或原始HTTP错误。缓存与证据文件须存于用户授权的项目输出目录，可能含公开联系人信息，按用户项目权限管理。
附录接口中的示例日期、企业、ID、电话、金额均为文档样例，绝不能作为当前查询结果或默认条件。
