## POST 招中标信息搜索列表

**请求地址：** `https://gate.gov-bid.com/outer-gateway/bid/searchProjectApi?key=***`

**说明：** 按关键词、地区、行业、时间和金额、企业名字等条件搜索招标采购信息列表。

### 请求参数

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| startDate | string | 是 | 2025-07-20 23:00:00 | 招中标信息发布开始日期，精确到天，格式 yyyy-MM-dd或yyyy-MM-dd HH:mm:ss  |
| endDate | string | 是 | 2025-07-25 23:59:59 | 招中标信息发布结束日期，精确到天，格式yyyy-MM-dd或yyyy-MM-dd HH:mm:ss |
| pageId | integer | 是 | 1 | 当前页码  |
| pageNumber | integer | 是 | 20 | 每页记录数，此值不要超过50,设为0时仅返回结果数量，即total值 |
| searchType | integer | 是 | 3 | 搜索类型：1=智能模糊，2=精准，3=高级 |
| keyword | string | 否 | 工程\|空调 | 搜索关键词： - 多个关键词”同时出现”用空格或逗号分隔 - 多个关键词”或关系”用竖线分隔。 -包含竖线，总长度不得超过300个字符 |
| excludeKW | string | 否 | - | 排除关键词，多个用竖线分隔。包含竖线，总长度不得超过150个字符 |
| inCludeKW | string | 否 | - | 结果必含关键词，多个用竖线分隔。 注意inCludeKW不要和keyword有相同的关键词，inCludeKW，长度较短。 -包含竖线，总长度不得超过150个字符 |
| subjectMatter | string | 否 | 中央空调\|椅子 | 标的物关键词，多个关键词”或关系”用竖线分隔 |
| projectClassID | string | 否 | -100 | 招中标信息分类ID，参考枚举值-码表 (招中标信息14个信息分类)；多个以英文逗号分隔； |
| searchMode | integer | 否 | 1 | 搜索字段模式，1：全部（标题+内容），2：搜索标题，3：搜索内容；默认值：1 |
| areaCode | object | 否 | - | 地区筛选条件，区域编码均为6位数字字符串；传递哪些编码，就查询哪些编码对应的数据；proviceCodeList 传 ["0"] 时表示查询全国 |
| areaCode.proviceCodeList | array | 否 | 0 | 省级地区编码列表，均为6位数字字符串；传入哪些省编码就查询哪些省；传 0 表示全国；多个使用 “，”拼接； |
| areaCode.cityCodeList | array | 否 | - | 市级地区编码列表，均为6位数字字符串；传入哪些市编码就查询哪些市；多个使用 “，”拼接； |
| areaCode.countyCodeList | array | 否 | - | 区县地区编码列表，均为6位数字字符串；传入哪些区县编码就查询哪些区县；多个使用 “，”拼接； |
| industryCode | object | 否 | - | 甲方行业分类筛选条件 |
| industryCode.firstCodeList | array | 否 | 0 | 一级行业编码列表；示例：{"firstCodeList":["Q"]} |
| industryCode.secondCodeList | array | 否 | - | 二级行业编码列表；示例：{"secondCodeList":["Q83"]} |
| industryCode.thirdCodeList | array | 否 | - | 三级行业编码列表；示例：{"thirdCodeList":["Q831"]} |
| subMatterIndustryCode | object | 否 | - | 标的物行业分类筛选条件 |
| subMatterIndustryCode.firstCodeList | string | 否 | 0 | 一级行业编码列表；示例：{"firstCodeList":["E"]} |
| subMatterIndustryCode.secondCodeList | string | 否 | - | 二级行业编码列表；示例：{"firstCodeList":["E48"]} |
| subMatterIndustryCode.thirdCodeList | string | 否 | - | 三级行业编码列表；示例：{"firstCodeList":["A015"]} |
| contractEndMin | string | 否 | 2025-07-20 | 合同截至日期查询极小值，精确到天，格式 yyyy-MM-dd |
| contractEndMax | string | 否 | 2025-12-25 | 合同截至日期查询极大值，精确到天，格式 yyyy-MM-dd |
| purchaseTypeID | string | 否 | -100 | 采购分类ID，参考枚举值-码表 (招中标信息采购分类)；默认值：“-100”，表示查询全部分类；多个以英文逗号分隔; |
| partAName | string | 否 | - | 甲方（公司）名字集合，支持模搜索，多个以英文逗号分隔 |
| partBName | string | 否 | - | 乙方（公司）名字集合，支持模搜索，多个以英文逗号分隔 |
| agentName | string | 否 | - | 代理机构（公司）名字集合，支持模搜索，多个以英文逗号分隔  |
| projectMoneyMin | string | 否 | 100000 | 项目金额最小值；单位人民币：元；为空则表示不限 |
| projectMoneyMax | string | 否 | 1000000 | 项目金额最大值；单位人民币：元；为空则表示不限 |
| fileFlag | integer | 否 | -1 | 附件标识：-1=无要求，0=无附件，1=有附件 |
| companyName | string | 否 | 湖北会计师事务所 | 公司名字，支持模糊搜索，多个以英文逗号分隔,适用于不确定公司的角色（甲方、乙方、代理机构） |
| orderByType | integer | 否 | 2 | 结果排序方式，1：按得分降序排序，2：按发布时间降序排序 |

### 请求示例

```json
{
  "startDate": "2025-07-20 23:00:00",
  "endDate": "2025-07-25 23:59:59",
  "pageId": 1,
  "pageNumber": 20,
  "searchType": 3,
  "keyword": "工程|空调",
  "subjectMatter": "中央空调|椅子",
  "excludeKW": "",
  "inCludeKW": "",
  "projectClassID": "-100",
  "searchMode": 1,
  "areaCode": {
    "proviceCodeList": [
      "0"
    ],
    "cityCodeList": [],
    "countyCodeList": []
  },
  "industryCode": {
    "firstCodeList": [],
    "secondCodeList": [],
    "thirdCodeList": []
  },
  "contractEndMin": "2025-07-20",
  "contractEndMax": "2025-12-25",
  "purchaseTypeID": "-100",
  "partAName": "",
  "partBName": "",
  "agentName": "",
  "projectMoneyMin": "100000",
  "projectMoneyMax": "1000000",
  "fileFlag": -1,
  "companyName": "湖北会计师事务所",
  "orderByType": 2
}
```

### cURL 示例

```bash
curl --request POST 'https://gate.gov-bid.com/outer-gateway/bid/searchProjectApi?key=YOUR_API_KEY' \
  --header 'Content-Type: application/json' \
  --data-raw '{
  "startDate": "2025-07-20 23:00:00",
  "endDate": "2025-07-25 23:59:59",
  "pageId": 1,
  "pageNumber": 20,
  "searchType": 3,
  "keyword": "工程|空调",
  "subjectMatter": "中央空调|椅子",
  "excludeKW": "",
  "inCludeKW": "",
  "projectClassID": "-100",
  "searchMode": 1,
  "areaCode": {
    "proviceCodeList": [
      "0"
    ],
    "cityCodeList": [],
    "countyCodeList": []
  },
  "industryCode": {
    "firstCodeList": [],
    "secondCodeList": [],
    "thirdCodeList": []
  },
  "contractEndMin": "2025-07-20",
  "contractEndMax": "2025-12-25",
  "purchaseTypeID": "-100",
  "partAName": "",
  "partBName": "",
  "agentName": "",
  "projectMoneyMin": "100000",
  "projectMoneyMax": "1000000",
  "fileFlag": -1,
  "companyName": "湖北会计师事务所",
  "orderByType": 2
}'
```

### 响应参数

| 参数名 | 类型 | 说明 |
| --- | --- | --- |
| code | integer | 接口响应状态码（200=成功） |
| msg | string | 解析响应信息 |
| subCode | string | 业务侧 code（0000000000=成功） |
| subMsg | string | 业务侧 msg |
| data | object | 业务数据结果（分页配置+搜索结果数据） |
| data.costTime | string | 搜索耗费时长（单位：毫秒），null表示未统计 |
| data.total | integer | 搜索结果总数 |
| data.pageId | integer | 当前页码 |
| data.pageNumber | integer | 每页记录数 |
| data.startDate | string | 实际搜索开始时间（格式：yyyy-MM-dd HH:mm:ss） |
| data.endDate | string | 实际搜索结束时间（格式：yyyy-MM-dd HH:mm:ss） |
| data.hasNext | boolean | 是否还有下一页：true=有，false=无 |
| data.seKeyWords | string | UI标红用的关键词（匹配搜索关键词） |
| data.data | array | 搜索结果数据集合（数组形式，按dataSetType返回对应结构） |
| data.data[].id | integer | 项目ID |
| data.data[].newsTypeID | integer | 已弃用，老版本分类ID，信息类别(1招标，2中标，3:合同，6：意向公开，5：拍租公告) |
| data.data[].title | string | 信息标题（含HTML高亮标签，用于关键词标红） |
| data.data[].publishTime | string | 项目发布时间（格式：yyyy-MM-dd HH:mm:ss） |
| data.data[].content | string | 命中高亮内容（含HTML高亮标签，非完整内容） |
| data.data[].proviceCode | string | 省代码 |
| data.data[].cityCode | string | 市代码 |
| data.data[].countyCode | string | 区/县代码（null表示无） |
| data.data[].hasFile | integer | 是否有附件：0=无，1=有 |
| data.data[].score | number | 文档得分 |
| data.data[].projectMoney | string | 项目金额（带单位，如”16.8万”） |
| data.data[].projectClassID | string | 2025版项目子分类ID |
| data.data[].purchaseTypeID | string | 采购类别ID |
| data.data[].industryCodeList | array | 行业分类code数组 |
| data.data[].partANameList | array | 甲方名称列表（多个用数组存储） |
| data.data[].partBNameList | array | 乙方名称列表（多个用数组存储） |

### 响应示例

```json
{
  "data": {
    "costTime": null,
    "total": 350320,
    "pageId": 1,
    "pageNumber": 10,
    "startDate": "2026-08-27 00:00:00",
    "endDate": "2026-09-28 23:59:59",
    "hasNext": true,
    "data": [
      {
        "id": 349969213,
        "newsTypeID": 2,
        "title": "武威一中建校120周年纪念画册设计印刷制作项目成交公示",
        "publishTime": "2026-09-08 20:38:04",
        "content": null,
        "proviceCode": "620000",
        "cityCode": "620600",
        "countyCode": null,
        "hasFile": 0,
        "score": 0,
        "projectMoney": "4.32万",
        "projectClassID": "2",
        "purchaseTypeID": "1",
        "industryCodeList": [
          "P823",
          "P822"
        ],
        "subMatCodeList": [
          "M5214",
          "R662"
        ],
        "partANameList": [
          "甘肃省武威第一中学"
        ],
        "partBNameList": [
          "甘肃星昇文化产业发展有限责任公司"
        ],
        "contractEndDate": null
      },
      {
        "id": 349969180,
        "newsTypeID": 1,
        "title": "[政采云]2026年疏附县教育系统试卷印刷服务外包项目服务项目竞争性磋商公告",
        "publishTime": "2026-09-08 20:37:51",
        "content": null,
        "proviceCode": "650000",
        "cityCode": "653100",
        "countyCode": "653121000000",
        "hasFile": 1,
        "score": 0,
        "projectMoney": "69.96万",
        "projectClassID": "29",
        "purchaseTypeID": "1",
        "industryCodeList": [
          "P823",
          "S912"
        ],
        "subMatCodeList": [
          "M5214"
        ],
        "partANameList": [
          "疏附县教育局"
        ],
        "partBNameList": [],
        "contractEndDate": "2027-08-30 00:00:00"
      },
      {
        "id": 349969171,
        "newsTypeID": 1,
        "title": "[政采云]塔什库尔干县教育事业赋能综合项目（教育科技馆综合服务能力提升）公开招标公告",
        "publishTime": "2026-09-08 20:37:47",
        "content": null,
        "proviceCode": "650000",
        "cityCode": "653100",
        "countyCode": "653131000000",
        "hasFile": 1,
        "score": 0,
        "projectMoney": "430万",
        "projectClassID": "1",
        "purchaseTypeID": "2",
        "industryCodeList": [
          "P823",
          "S912"
        ],
        "subMatCodeList": [
          "A0240",
          "C284",
          "A0237"
        ],
        "partANameList": [
          "塔什库尔干塔吉克自治县教育和科学技术局"
        ],
        "partBNameList": [],
        "contractEndDate": null
      },
      {
        "id": 349969154,
        "newsTypeID": 2,
        "title": "疏附县铁日木乡小学2026年9月灭火器审验服务竞价成交公告",
        "publishTime": "2026-09-08 20:37:28",
        "content": null,
        "proviceCode": "650000",
        "cityCode": "653100",
        "countyCode": "653121000000",
        "hasFile": 0,
        "score": 0,
        "projectMoney": "0.08万",
        "projectClassID": "2",
        "purchaseTypeID": "1",
        "industryCodeList": [
          "P822"
        ],
        "subMatCodeList": [
          "A0238"
        ],
        "partANameList": [
          "疏附县铁日木乡小学"
        ],
        "partBNameList": [
          "喀什鼎森消防设备有限公司"
        ],
        "contractEndDate": null
      },
      {
        "id": 349969152,
        "newsTypeID": 1,
        "title": "江西省机电设备招标有限公司关于江西工业职业技术学院机电设备故障诊断与维修实训室项目（第三次）（项目编号：JXTC2026070242C2）竞争性谈判公告",
        "publishTime": "2026-09-08 20:37:26",
        "content": null,
        "proviceCode": "360000",
        "cityCode": "360100",
        "countyCode": null,
        "hasFile": 1,
        "score": 0,
        "projectMoney": "128.56万",
        "projectClassID": "28",
        "purchaseTypeID": "3",
        "industryCodeList": [
          "P824"
        ],
        "subMatCodeList": [
          "A0240"
        ],
        "partANameList": [
          "江西工业职业技术学院"
        ],
        "partBNameList": [],
        "contractEndDate": null
      },
      {
        "id": 349969145,
        "newsTypeID": 2,
        "title": "陇南市武都区莲湖小学新修楼顶厕所项目成交公告",
        "publishTime": "2026-09-08 20:37:20",
        "content": null,
        "proviceCode": "620000",
        "cityCode": "621200",
        "countyCode": "621202000000",
        "hasFile": 0,
        "score": 0,
        "projectMoney": "13.93万",
        "projectClassID": "2",
        "purchaseTypeID": "2",
        "industryCodeList": [
          "P822"
        ],
        "subMatCodeList": [
          "C241",
          "B221",
          "A097"
        ],
        "partANameList": [
          "陇南市武都区莲湖小学"
        ],
        "partBNameList": [
          "陇南李喜平劳务有限公司"
        ],
        "contractEndDate": null
      },
      {
        "id": 349969140,
        "newsTypeID": 1,
        "title": "莆田第二十八中学食堂委托用工服务采购项目招标公告",
        "publishTime": "2026-09-08 20:37:15",
        "content": null,
        "proviceCode": "350000",
        "cityCode": "350300",
        "countyCode": "350305000000",
        "hasFile": 0,
        "score": 0,
        "projectMoney": "498万",
        "projectClassID": "1",
        "purchaseTypeID": "1",
        "industryCodeList": [
          "P823",
          "P822"
        ],
        "subMatCodeList": [
          "I421"
        ],
        "partANameList": [
          "莆田第二十八中学"
        ],
        "partBNameList": [],
        "contractEndDate": null
      },
      {
        "id": 349969119,
        "newsTypeID": 3,
        "title": "关于咖啡机的网上商城合同公告",
        "publishTime": "2026-09-08 20:37:01",
        "content": null,
        "proviceCode": "320000",
        "cityCode": "320200",
        "countyCode": "320282000000",
        "hasFile": 1,
        "score": 0,
        "projectMoney": "0.56万",
        "projectClassID": "3",
        "purchaseTypeID": "3",
        "industryCodeList": [
          "P822",
          "P823"
        ],
        "subMatCodeList": [
          "A0213",
          "A0212"
        ],
        "partANameList": [
          "江苏省宜兴中学"
        ],
        "partBNameList": [
          "江苏理想云商贸有限公司"
        ],
        "contractEndDate": null
      },
      {
        "id": 349969111,
        "newsTypeID": 4,
        "title": "感恩教育活动手工图卡招生简章等印刷服务",
        "publishTime": "2026-09-08 20:36:51",
        "content": null,
        "proviceCode": "230000",
        "cityCode": "230700",
        "countyCode": "230781000000",
        "hasFile": 0,
        "score": 0,
        "projectMoney": "0.21万",
        "projectClassID": "4",
        "purchaseTypeID": "1",
        "industryCodeList": [
          "P825",
          "P829"
        ],
        "subMatCodeList": [
          "M5214",
          "M528",
          "R662"
        ],
        "partANameList": [
          "铁力市特殊教育学校"
        ],
        "partBNameList": [],
        "contractEndDate": null
      },
      {
        "id": 349969103,
        "newsTypeID": 3,
        "title": "河南牧业经济学院图书馆2026年电子资源采购项目",
        "publishTime": "2026-09-08 20:36:47",
        "content": null,
        "proviceCode": "410000",
        "cityCode": "410100",
        "countyCode": null,
        "hasFile": 0,
        "score": 0,
        "projectMoney": "8万",
        "projectClassID": "3",
        "purchaseTypeID": "3",
        "industryCodeList": [
          "P824"
        ],
        "subMatCodeList": [
          "J461"
        ],
        "partANameList": [
          "河南牧业经济学院"
        ],
        "partBNameList": [
          "河南信优研电子科技有限公司"
        ],
        "contractEndDate": "2027-09-04 00:00:00"
      }
    ],
    "seKeyWords": null
  },
  "state": 1,
  "msg": "ok",
  "count": 0,
  "returnValue": null,
  "returnvalue": null,
  "subCode": "0000000000",
  "subMsg": "成功"
}
```
