# 运行、分页、缓存与导出

运行环境：Python 3.9+，仅标准库，无需pip安装。命令在当前技能源目录执行。先执行：

~~~bash
python scripts/query_api.py check
~~~

退出码2且MISSING_API_KEY时停止，按auth.md给出获取入口或接收用户已有密钥；用户提供后按该文件长期安全保存、同步用户级环境并复用，不重复索要。不能打印环境变量的值，额度不足按auth.md给出充值入口。条件和字段均明确后，创建query.json，仅含所选接口支持的参数。下列文件名为执行约定，不随包附带可误执行的示例业务数据。

~~~bash
python scripts/query_api.py call --endpoint SearchProjectForAI --body query.json --output outputs/page1.json --cache-dir outputs/.api-cache
~~~

高级检索将endpoint替换成searchProjectApi并使用其参数。单页默认pageId=1、pageNumber=20，脚本不会自动全取。只计数pageNumber=0，计数成功不代表完整采集。下一页读取原请求并仅增加pageId，保留其余条件；用户说下一页不等于全量。
明确要求全部后，从pageId=1、pageNumber=20开始：

~~~bash
python scripts/query_api.py call --endpoint SearchProjectForAI --body query.json --output outputs/all.json --all --cache-dir outputs/.api-cache
~~~

--all仅递增页码直到真实hasNext=false，没有固定页数截断。按id+publishTime去重、保持过滤条件不变；页码错位、重复页、total变化、异常空页、计数矛盾或失败均保留已取得记录与failed_page，complete=false。不得跳过失败页或把不完整结果称全量。失败后重新从第1页采集，可复用有效缓存，若total变化则刷新缓存重取。
临时网络和HTTP500/502/503/504最多重试2次；429遵守Retry-After，超过60秒停止并提示稍后重试。400/401/403/415、业务失败、额度不足立即停止，不当作0条。业务层无法判定重试策略的错误停止，不猜服务规则。

## 按需补查

列表有值直接复用。只对最终保留且用户需要详情的公告补查：编号/金额/主体等用getZTBStructreDetail；完整采购需求与专属字段用getZTBProjectDetail；标的物/资质/评分优先getZTBStructreStep2DetailForCommon（只对2026-09-18及以后公告，空值不等于不存在）；附件仅在用户选择后查getZTBProjectFiles；来源在已有列表及结构化均缺失时查getCollectUrl。结构化为空时可按已选字段读正文，不能从文档示例补值。
详情、正文、来源、第二期详情使用id；附件使用projectId。均携带列表真实publishTime。项目编号不是公告ID；列表若返回纯数字字符串ID，可在写详情请求前转正整数，不能转换任意文本编号。

~~~bash
python scripts/query_api.py call --endpoint getZTBStructreDetail --body notice.json --output outputs/detail.json --cache-dir outputs/.api-cache
~~~

相同服务、凭据、接口和请求参数使用同一缓存目录可复用；默认有效期3600秒，--cache-ttl调整、--refresh-cache强制重取。缓存键隔离凭据指纹但不保存凭据；报告标注from_cache及fetched_at，不能把缓存旧时间说成本次实时查询。默认不启用缓存，只有传--cache-dir才保存；同一次执行已取得的响应优先直接复用。

## 文档中的请求格式疑点

附件、结构化、正文、来源4个接口的原文cURL为multipart/form-data头配JSON原始体，缺标准multipart边界。本脚本保留该文档写法，尚未证明服务端接受。遇400/415停止并报告；不能自动尝试多种格式。只有服务端说明或成功调用已经确认对应详情接口支持application/json时才传--detail-json。第二期详情与两个列表接口本来就是application/json，无需该开关。响应同时支持code=200或state=1；存在两种状态时均须成功，subCode失败仍停止。

## 交付与导出

JSON输出包含原始页、请求条件、候选总数、已取去重数、完整性与错误状态。candidate_total为候选公告数，不能当作已核实业务项目数。业务报告按所选字段整理，参考templates/result.md。
仅导出原生列表列时，用用户选择的真实字段名及顺序：

~~~bash
python scripts/query_api.py call --endpoint SearchProjectForAI --body query.json --output outputs/selected.json --csv outputs/selected.csv --columns title,publishTime --cache-dir outputs/.api-cache
~~~

此命令中的两列只是格式示例，不替代用户选择。CSV为UTF-8 BOM，防公式执行，嵌套主体保留JSON关联。需详情、专属字段或多批合并时，先整理带证据的标准化记录JSON，再离线导出：

~~~bash
python scripts/export_records.py --input outputs/verified.json --csv outputs/verified.csv --columns title,publishTime
~~~

离线导出支持JSON数组或带records数组的对象及点分字段路径；不联网、不推断、不新增字段值，缺失标未返回。原始JSON应保留每条证据的接口、字段路径、查询时间及核验状态。文件写入用户指定位置；不要改动技能源文件或外部原始材料。
