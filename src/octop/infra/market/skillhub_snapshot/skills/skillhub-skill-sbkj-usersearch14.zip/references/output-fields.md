# 字段选择、来源与证据

条件明确后，展示本页通用字段与domain-rules.md中的专属字段，让用户选编号、字段名或组合；没有字段选择时等待回复，不能先发业务请求。用户已明确列出字段或说默认列表时视为已选：默认列表为F01、F02、F03、F04、F05、F07、F08、F09、F10、F15。未选择的字段不写入最终业务表格；原始证据JSON保留原生返回以支持复核。

| 编号 | 字段 | 优先来源/补查 |
| --- | --- | --- |
| F01 | 公告ID | 列表data.data[].id |
| F02 | 公告标题 | 列表data.data[].title，去HTML高亮 |
| F03 | 发布时间 | 列表data.data[].publishTime |
| F04 | 地区 | Agent列表areaName；高级列表proviceCode/cityCode/countyCode，无名称时保留代码不猜 |
| F05 | 公告类型 | 列表projectClass/projectClassID；正文projectClassName |
| F06 | 采购类别 | 列表purchaseType/purchaseTypeID |
| F07 | 采购单位 | Agent列表partAInfo；结构化data.partyAInfo |
| F08 | 中标/成交单位及角色 | Agent列表partBInfo；高级partBNameList；结构化partyBInfo，结合公告类型与结果正文核验 |
| F09 | 项目展示金额及原单位 | 列表projectMoney，不直接当预算或成交额 |
| F10 | 采购内容摘要 | 列表content仅为命中片段；完整结论取正文content |
| F11 | 项目编号/标段 | 结构化projectNumber/projectSectionCode |
| F12 | 预算金额（元） | 结构化budgetMoney；与原文标段对应核实 |
| F13 | 中标金额（元） | 结构化bidMoney；与中标单位及标段对应核实 |
| F14 | 报名截止/开标时间与地点 | 列表siginUpStopDate/bidStartDate/bidStartAddress，不以发布日期代替 |
| F15 | 公告原始来源 | 列表collectUrl；结构化collectUrl；最后才补getCollectUrl.returnValue |
| F16 | 代理机构 | Agent列表agencyInfo；结构化agencyInfo；正文agentName |
| F17 | 联系人、电话及电话归属 | 结构化partyAInfo/partyBInfo/agencyInfo，各对象逐个保留关联 |
| F18 | 企业邮箱和地址 | 同一主体的email/address，不跨主体拼接 |
| F19 | 附件名称和下载地址 | getZTBProjectFiles.data[]，或正文已返回的projectFiles |
| F20 | 资金来源 | 第二期结构化fundSources；无则正文 |
| F21 | 标的物 | 第二期结构化subjectMatters；无则正文 |
| F22 | 资质要求 | 第二期结构化qualifications；无则正文 |
| F23 | 评标方法 | 第二期结构化bidEvaluationMethods；无则正文 |
| F24 | 投标记录与评分 | 第二期结构化bidRecords[]；报价、得分、公司按同一对象关联 |
| F25 | 履约/交付/服务期限 | 公告正文或已阅读附件，附原文证据 |
| F26 | 相关性及核验说明 | 引用采购内容与主体证据；候选/已核实/待核实 |
| F27 | 查询时间及数据来源 | 接口名+真实字段路径+原始请求时间；缓存标实际获取时间 |

专属字段X01起见domain-rules.md；属于原文抽取能力，不能假装所有字段都有接口原生结构化列。先读真实正文，附最小原文摘录及章节/表格/条款定位；附件只返回链接不等于下载阅读。未读附件不得填技术指标。
名称列表partANameList/partBNameList不是电话对象。采购方、代理机构、平台热线不能当作中标企业电话。用户选择电话时同时交付所属主体/角色、电话来源（接口、字段路径、查询时间），缺失或掩码标待补全；不调用本技能未收录的企业电话接口。
预算、成交额、投标报价、框架估算额保留不同口径；0/空值/未披露分别处理，项目展示金额为0且正文未披露时不称预算0元。多金额无标段映射时不与多个中标单位按位置硬配，更不能重复累计。
候选人、公示投标人和实际成交单位分开。合同、变更、招标及中标公告可关联展示，但不是同一公告；统计项目数须有真实编号/标段依据并说明去重口径。
