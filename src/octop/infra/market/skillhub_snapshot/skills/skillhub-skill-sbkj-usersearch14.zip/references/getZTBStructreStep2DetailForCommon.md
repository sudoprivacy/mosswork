## POST 获取项目【标的物 资质】等信息

**请求地址：** `https://gate.gov-bid.com/outer-gateway/bid/getZTBStructreStep2DetailForCommon?key=***`

**说明：** 按项目ID及实际发布时间查询第二期结构化详情。仅 2026-09-18 及以后发布的数据可能有返回；此前数据不保证返回。投标记录以对象列表返回，保留每条记录内字段对应关系。

### 请求参数

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| id | integer | 是 | 354685792 | 项目信息ID，必须大于0 |
| publishTime | string | 是 | 2026-10-03 23:27:38 | 该条信息的实际发布时间，可解析为日期时间，例如2026-10-09 17:47:58或2026-10-09T17:47。仅2026-09-18及以后发布的数据可能有第二期详情 |

### 请求示例

```json
{
  "id": 354685792,
  "publishTime": "2026-10-03 23:27:38"
}
```

### cURL 示例

```bash
curl --request POST 'https://gate.gov-bid.com/outer-gateway/bid/getZTBStructreStep2DetailForCommon?key=YOUR_API_KEY' \
  --header 'Content-Type: application/json' \
  --data-raw '{
  "id": 354685792,
  "publishTime": "2026-10-03 23:27:38"
}'
```

### 响应参数

| 参数名 | 类型 | 说明 |
| --- | --- | --- |
| state | integer | 响应状态：1成功、0失败；维护期间返回0 |
| msg | string | 响应信息，成功为ok，失败为具体原因 |
| count | integer | 废弃字段，本接口恒为0 |
| returnValue | string | 本接口恒为null |
| returnvalue | string | 废弃字段，本接口恒为null |
| subCode | string | 业务码：成功0000000000，失败0100000001 |
| subMsg | string | 成功为成功，失败时同msg |
| data | object | 第二期结构化详情；无数据时按上游响应返回 |
| data.projectID | integer | 项目信息ID |
| data.publishTime | string | 信息发布时间，yyyy-MM-dd HH:mm:ss |
| data.fundSources | array | 资金来源，无则空数组 |
| data.subjectMatters | array | 标的物，无则空数组 |
| data.qualifications | array | 资质，无则空数组 |
| data.bidEvaluationMethods | array | 评标方法，无则空数组 |
| data.bidRecords | array | 投标记录对象列表；每条记录内字段对应关系保留，无则空数组 |
| data.bidRecords[].projectSectionCode | string | 标段编号或名称 |
| data.bidRecords[].bidCompanyName | array | 投标单位名称，可能多个 |
| data.bidRecords[].bidderQualifications | array | 投标单位资质，可能多个 |
| data.bidRecords[].totalQuote | string | 投标单位总报价，保留原文及单位 |
| data.bidRecords[].technicalScore | string | 技术得分，未提取到时为空字符串 |
| data.bidRecords[].businessScore | string | 商务得分，未提取到时为空字符串 |
| data.bidRecords[].businessTechnicalScore | string | 商务技术得分，未提取到时为空字符串 |
| data.bidRecords[].quoteScore | string | 报价得分，未提取到时为空字符串 |
| data.bidRecords[].totalScore | string | 总得分，未提取到时为空字符串 |
| data.bidRecords[].quoteCoefficient | string | 报价系数，未提取到时为空字符串 |
| data.bidRecords[].rate | string | 费率，未提取到时为空字符串 |

### 响应示例

```json
{
  "data": {
    "projectID": 354685792,
    "publishTime": "2026-10-03 23:27:38",
    "fundSources": [],
    "subjectMatters": [
      "美的空调1.5匹变频壁挂机KFR-35GW/G3-1A"
    ],
    "qualifications": [],
    "bidEvaluationMethods": [],
    "bidRecords": [
      {
        "projectSectionCode": "",
        "bidCompanyName": [
          "横州市联盈商贸有限责任公司"
        ],
        "bidderQualifications": [],
        "totalQuote": "14760元",
        "technicalScore": "",
        "businessScore": "",
        "businessTechnicalScore": "",
        "quoteScore": "",
        "totalScore": "",
        "quoteCoefficient": "",
        "rate": ""
      }
    ]
  },
  "state": 1,
  "msg": "ok",
  "count": 0,
  "returnValue": null,
  "returnvalue": null,
  "subCode": "0000000000",
  "subMsg": "成功"
}
```
