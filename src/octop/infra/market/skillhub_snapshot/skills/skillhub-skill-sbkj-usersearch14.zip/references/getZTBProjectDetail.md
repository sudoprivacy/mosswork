## POST 招中标信息详情【不含结构化数据】

**请求地址：** `https://gate.gov-bid.com/outer-gateway/bid/getZTBProjectDetail?key=***`

**说明：** 根据项目 ID 和发布时间获取招中标项目信息正文详情，不包含结构化字段。

### 请求参数

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| --- | --- | --- | --- | --- |
| id | integer | 是 | 337580128 | 项目ID |
| publishTime | string | 是 | 2026-07-06 18:11:40 | 项目发布时间，格式： yyyy-MM-dd 或 yyyy-MM-dd HH:mm:ss； |

### 请求示例

```json
{
  "id": 348824249,
  "publishTime": "2026-09-02 22:40:04"
}
```

### cURL 示例

```bash
curl --request POST 'https://gate.gov-bid.com/outer-gateway/bid/getZTBProjectDetail?key=YOUR_API_KEY' \
  --header 'Content-Type: multipart/form-data' \
  --data-raw '{
  "id": 348824249,
  "publishTime": "2026-09-02 22:40:04"
}'
```

### 响应参数

| 参数名 | 类型 | 说明 |
| --- | --- | --- |
| code | integer | 接口响应状态码 |
| msg | string | 解析响应信息 |
| subCode | string | 业务侧 code |
| subMsg | string | 业务侧 msg |
| data | object | 业务数据结果 |
| data.id | integer | 项目ID |
| data.newsTypeID | integer | 项目信息类别ID（老版分类）：1=招标信息，2=中标信息，3=采购合同，4=采购意向，5=拍卖信息 |
| data.title | string | 项目信息标题 |
| data.content | string | 项目信息内容，带html标签（标讯信息正文内容） |
| data.publishTime | string | 项目发布时间 格式：yyyy-MM-dd HH:mm:ss |
| data.proviceCode | string | 项目归属地code-省code |
| data.cityCode | string | 项目归属地code-市code |
| data.countyCode | string | 项目归属地code-区/县code |
| data.projectMoney | string | 项目金额（展示用，如”32.32万”），优先级：合同金额>中标金额>预算金额，默认0 |
| data.projectClassID | string | 2025版14个项目子分类ID ，详见码表 |
| data.projectClassName | string | 2025版14个项目子分类名称（可能为null） |
| data.purchaseType | string | 采购类别ID：0=其它，1=服务类，2=工程类，3=货物类 |
| data.industryName | string | 信息行业分类名称，多个以英文逗号分隔（已废弃） |
| data.partAName | string | 甲方名称，多个以英文逗号分隔 |
| data.partBName | string | 乙方名称，多个以英文逗号分隔 |
| data.agentName | string | 代理机构名称，多个以英文逗号分隔 |
| data.projectFiles | array | 项目附件列表 |
| data.projectFiles[].projectFileID | integer | 项目信息附件ID |
| data.projectFiles[].name | string | 信息附件名称 |
| data.projectFiles[].publishTime | string | 项目信息发布时间 格式：yyyy-MM-dd HH:mm:ss |
| data.partAIndustryName | array | 甲方行业 |
| data.subMatIndustryName | array | 标的物行业 |
| returnValue | string | 单个值响应结果 |

### 响应示例

```json
{
  "data": {
    "id": 348824249,
    "newsTypeID": 1,
    "newsTypeName": "招标信息",
    "title": "2026世界青年科学家峰会会务服务",
    "content": "<div>2026世界青年科学家峰会会务服务<div><div><span></span><span>信息发布时间：2026-09-02 21:47:38</span><span>来源：<label>温州市</label></span></div><div><div> 【字号 ⼤中⼩】</div><div><span></span><span></span><span></span></div></div></div><hr><div><title><span>竞争性磋商公告</span></title><table border='1' cellpadding='0' cellspacing='0' width='970px'><tr><td width='20%'><div><b>采购项目:</b></div></td><td colspan='3'><div><b>2026世界青年科学家峰会会务服务</b></div></td></tr><tr><td width='20%'><div><b>公示编号:</b></div></td><td colspan='3'><div><b>330300261530010000005-GTWZ[2026]004</b></div></td></tr><tr><td width='20%'><div><b>采购人:</b></div></td><td colspan='3'><div><b>名称：温州市科学技术协会<br>地址：温州市鹿城区市府路481号<br>联系人：陈雄<br>电话：0577-88962211</b></div></td></tr><tr><td width='20%'><div><b>采购代理机构:</b></div></td><td colspan='3'><div><b>名称：宁波国际投资咨询有限公司<br>地址：温州市鹿城区市府路592号新益大厦13楼1302-B室<br>联系人：卢旭<br>电话：0577-8997588</b></div></td></tr><tr><td width='20%'><div><b>采购组织类型:</b></div></td><td colspan='3'><div><b>分散采购</b></div></td></tr><tr><td width='20%'><div><b>采购项目概况:</b></div></td><td colspan='3'><div><b>标段：1 标段名称：2026世界青年科学家峰会会务服务 数量：1 单位：项 预算金额：3700000 简要规格描述：具体详见磋商文件</b></div></td></tr><tr><td width='20%'><div><b>供应商资格要求:</b></div></td><td colspan='3'><div><b></b></div></td></tr><tr><td width='20%'><div><b>磋商文件的领取:</b></div></td><td colspan='3'><div><b>时间：2026-09-02 21:36<br>地址：浙江政府采购网（www.zcygov.cn）<br>方式：供应商登录政采云平台https://www.zcygov.cn/在线申请获取采购文件（进入'项目采购</b></div></td></tr><tr><td width='20%'><div><b>响应文件的提交:</b></div></td><td colspan='3'><div><b>截止时间：2026-09-14 09:30<br>地址：浙江政府采购网（www.zcygov.cn）</b></div></td></tr><tr><td width='20%'><div><b>同级政府采购监督管理部门:</b></div></td><td colspan='3'><div><b>名称：温州市财政局（浙江省政府采购行政裁决服务中心（温州））<br>电话：0577-85501562</b></div></td></tr><tr><td width='20%'><div><b>信息来源:</b></div></td><td width='35%'><div><b>温州市</b></div></td><td width='15%'><div><b>服务平台接收时间:</b></div></td><td width='30%'><div><b>2026-09-02 21:47:38</b></div></td></tr></table></div></div><div></div>",
    "publishTime": "2026-09-02 22:40:04",
    "proviceCode": "330000",
    "proviceName": "浙江省",
    "cityCode": "330300",
    "cityName": "温州市",
    "countyCode": null,
    "countyName": null,
    "projectMoney": "370万",
    "projectClassID": "29",
    "projectClassName": "竞争性磋商",
    "purchaseType": "服务类",
    "industryName": "技术推广服务,高等教育,国家行政机构",
    "partAIndustryName": [
      "技术推广服务",
      "高等教育",
      "国家行政机构"
    ],
    "subMatIndustryName": [
      "会议、展览及相关服务"
    ],
    "partAName": "温州市科学技术协会",
    "partBName": "",
    "agentName": "宁波国际投资咨询有限公司",
    "projectFiles": []
  },
  "state": 1,
  "msg": "ok",
  "count": 0,
  "returnValue": null,
  "returnvalue": null,
  "subCode": "0000000000",
  "subMsg": "成功"
}
```
