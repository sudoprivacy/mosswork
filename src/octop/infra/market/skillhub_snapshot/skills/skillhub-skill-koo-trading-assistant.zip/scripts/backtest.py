#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
backtest.py — 信号有效性的统计验证（事件研究法）

回答一个此前无法回答的问题：**这套体系里的形态与信号，到底有没有预测力？**

方法（避免前视偏差）：
  1. 在 t 日收盘识别信号（只用 t 及之前的数据）
  2. t+1 日**开盘价**入场（不用 t 日收盘价，避免乐观偏差）
  3. 持有 H 根后以收盘价离场，计算收益率
  4. 看跌信号收益取负（对称处理）
  5. 与「同一标的、同一持有期的无条件平均收益（基准）」对比
  6. 用 Welch t 检验判断超额收益是否统计显著

⚠️ 边界：这是**历史统计**，不是未来预测。显著 ≠ 以后还能用；
   无效 ≠ 以后一定无效（可能是样本期特性）。参数调多了必然过拟合。

用法：
    python backtest.py --pool default --years 3 --out backtest_report.md
    python backtest.py --symbols sh600519,sz000858,hk00700 --limit 750 --out r.md
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import tempfile
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import indicators as I          # noqa: E402
import patterns as P            # noqa: E402
import fetch_data as F          # noqa: E402

# 默认样本池：跨市场、跨行业，降低单一标的特性带来的偏差
DEFAULT_POOL = [
    # A股（大盘蓝筹 + 成长 + 金融 + 周期）
    "sh600519",  # 贵州茅台
    "sz000858",  # 五粮液
    "sz300750",  # 宁德时代
    "sz002594",  # 比亚迪
    "sh601318",  # 中国平安
    "sh600036",  # 招商银行
    "sh601899",  # 紫金矿业
    "sh600030",  # 中信证券
    # 港股
    "hk00700",   # 腾讯控股
    "hk00941",   # 中国移动
    "hk01810",   # 小米集团
    # 美股
    "usAAPL",
    "usMSFT",
    "usNVDA",
    "usTSLA",
]

HORIZONS = (5, 10, 20)          # 持有期（根）
MIN_SAMPLES = 30                # 低于此样本数不纳入结论


# ---------------------------------------------------------------- 数据
def cache_path(cache_dir, symbol, period, limit):
    return os.path.join(cache_dir, f"{symbol}_{period}_{limit}.json")


def load_or_fetch(cli, symbol, period, limit, cache_dir, use_cache=True):
    cp = cache_path(cache_dir, symbol, period, limit)
    if use_cache and os.path.isfile(cp):
        try:
            with open(cp, encoding="utf-8") as f:
                d = json.load(f)
            if d.get("bars"):
                return d["bars"], "cache"
        except Exception:
            pass
    bars = F.fetch_kline(cli, symbol, period, limit)
    if bars:
        os.makedirs(cache_dir, exist_ok=True)
        with open(cp, "w", encoding="utf-8") as f:
            json.dump({"symbol": symbol, "period": period, "bars": bars},
                      f, ensure_ascii=False)
    return bars, "fetch"


# ---------------------------------------------------------------- 统计
def _welch_p(a, b):
    """Welch t 检验，返回双侧 p 值。无 scipy 时退化为正态近似。"""
    na, nb = len(a), len(b)
    if na < 3 or nb < 3:
        return None
    ma, mb = statistics.mean(a), statistics.mean(b)
    va = statistics.variance(a)
    vb = statistics.variance(b)
    se = (va / na + vb / nb) ** 0.5
    if se == 0:
        return None
    t = (ma - mb) / se
    try:
        from scipy import stats as st
        df = (va / na + vb / nb) ** 2 / (
            (va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
        return float(2 * st.t.sf(abs(t), df))
    except Exception:
        import math
        return float(2 * (1 - 0.5 * (1 + math.erf(abs(t) / (2 ** 0.5)))))


def describe(rets):
    n = len(rets)
    if n == 0:
        return {"n": 0}
    gains = [r for r in rets if r > 0]
    losses = [r for r in rets if r <= 0]
    avg_win = statistics.mean(gains) if gains else 0.0
    avg_loss = statistics.mean(losses) if losses else 0.0
    return {
        "n": n,
        "mean": statistics.mean(rets),
        "median": statistics.median(rets),
        "win": len(gains) / n,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "pl": (abs(avg_win / avg_loss) if avg_loss else float("inf")),
        "sd": statistics.stdev(rets) if n > 1 else 0.0,
    }


# ---------------------------------------------------------------- 核心
def _trend_state(close, ma, i, back=5):
    """i 日的趋势状态：up（价格在 MA 上方且 MA 上行）/ down / range"""
    if i < back + 1 or ma[i] is None or ma[i - back] is None:
        return "range"
    if ma[i] > ma[i - back] and close[i] > ma[i]:
        return "up"
    if ma[i] < ma[i - back] and close[i] < ma[i]:
        return "down"
    return "range"


def event_study(bars, horizons=HORIZONS):
    """
    对单个标的做事件研究，并按趋势位置分层。
    返回 (signals_by_name, baseline_by_h)
      signals_by_name: {形态名: {方向: {h: {"all"/"up"/"down"/"range": [收益...]}}}}
      baseline_by_h:   {h: [该标的无条件 N 日收益...]}
    """
    o = [b["o"] for b in bars]
    h_ = [b["h"] for b in bars]
    l = [b["l"] for b in bars]
    c = [b["c"] for b in bars]
    n = len(c)

    # 无条件基准：任意一天入场、持有 H 根的平均收益
    baseline = {}
    for H in horizons:
        base = []
        for i in range(n - H - 1):
            if o[i + 1] > 0:
                base.append((c[i + H] - o[i + 1]) / o[i + 1])
        baseline[H] = base

    ma20 = I.sma(c, 20)
    sigs = P.scan_all(o, h_, l, c, lookback=max(60, n - 1))
    out = defaultdict(lambda: defaultdict(lambda: defaultdict(
        lambda: defaultdict(list))))
    for s in sigs:
        i = s["idx"]
        name = s["name"]
        d = s["direction"]
        if d not in ("看涨", "看跌"):
            continue          # 中性形态不纳入方向性统计
        tr = _trend_state(c, ma20, i)
        for H in horizons:
            j = i + H
            if i + 1 >= n or j >= n:
                continue
            entry = o[i + 1]
            if entry <= 0:
                continue
            ret = (c[j] - entry) / entry
            if d == "看跌":
                ret = -ret    # 看跌信号：下跌算赚
            out[name][d][H]["all"].append(ret)
            out[name][d][H][tr].append(ret)
    return out, baseline


def _days_since(date_str):
    """距今多少天（无法解析返回 None）。"""
    import datetime
    try:
        d = datetime.date.fromisoformat(str(date_str)[:10])
        return (datetime.date.today() - d).days
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser(description="信号有效性统计验证（事件研究法）")
    ap.add_argument("--symbols", default="", help="逗号分隔的代码")
    ap.add_argument("--pool", default="default", help="预设池：default")
    ap.add_argument("--limit", type=int, default=750, help="每只取多少根（750≈3年）")
    ap.add_argument("--period", default="day")
    ap.add_argument("--out", default="backtest_report.md")
    ap.add_argument("--csv", default="", help="同时导出明细 CSV")
    ap.add_argument("--horizon", type=int, default=10, help="结论采用的主持有期")
    ap.add_argument("--no-cache", action="store_true")
    args = ap.parse_args()

    symbols = ([s.strip() for s in args.symbols.split(",") if s.strip()]
               if args.symbols else DEFAULT_POOL)

    try:
        cli = F.find_westock()
    except FileNotFoundError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

    # 缓存目录：默认放系统临时目录，避免污染技能目录（可用环境变量 KTA_CACHE_DIR 覆盖）
    cache_dir = os.environ.get("KTA_CACHE_DIR") or os.path.join(
        tempfile.gettempdir(), "koo-trading-assistant-cache")

    print(f"样本池 {len(symbols)} 只，每只 {args.limit} 根，周期 {args.period}")
    print("-" * 62)

    pool_sig = defaultdict(lambda: defaultdict(lambda: defaultdict(
        lambda: defaultdict(list))))
    pool_base = defaultdict(list)
    ok, failed = [], []

    for sym in symbols:
        try:
            bars, src = load_or_fetch(cli, sym, args.period, args.limit,
                                      cache_dir, not args.no_cache)
        except Exception as e:
            failed.append((sym, str(e)[:60]))
            print(f"  [skip] {sym}: {str(e)[:60]}")
            continue
        if len(bars) < 120:
            failed.append((sym, f"仅 {len(bars)} 根"))
            print(f"  [skip] {sym}: 数据不足（{len(bars)} 根）")
            continue
        gap = _days_since(bars[-1]["t"])
        if gap is not None and gap > 60:
            failed.append((sym, f"数据陈旧（最新 {bars[-1]['t']}）"))
            print(f"  [skip] {sym}: 数据陈旧，最新仅到 {bars[-1]['t']}（{gap} 天前）")
            continue
        s, b = event_study(bars)
        for name, per_dir in s.items():
            for d, per_h in per_dir.items():
                for H, per_tr in per_h.items():
                    for tr, rets in per_tr.items():
                        pool_sig[name][d][H][tr].extend(rets)
        for H, rets in b.items():
            pool_base[H].extend(rets)
        ok.append(sym)
        print(f"  [ok]   {sym:<10} {len(bars):>4} 根 ({src})  "
              f"{bars[0]['t']} → {bars[-1]['t']}")

    if not ok:
        print("\n[中断] 没有任何标的取数成功", file=sys.stderr)
        sys.exit(1)

    # ---- 生成报告 ----
    H0 = args.horizon
    base = pool_base.get(H0, [])
    bstat = describe(base)
    lines = []
    A = lines.append

    A(f"# 信号有效性回测报告\n")
    A(f"- **样本池**：{len(ok)} 只（A股 / 港股 / 美股）")
    A(f"- **每只 K 线**：{args.limit} 根，周期 {args.period}")
    A(f"- **总 K 线数**：约 {sum(1 for _ in ok) * args.limit} 根（含重叠窗口）")
    A(f"- **方法**：t 日识别信号 → t+1 开盘入场 → 持有 H 根后收盘离场；看跌信号收益取负")
    A(f"- **基准**：同标的、同持有期的无条件平均收益")
    A(f"- **主持有期**：{H0} 根")
    if failed:
        A(f"- **未纳入**：{len(failed)} 只（{', '.join(s for s, _ in failed[:5])}…）")
    A("")

    A(f"## 基准收益（无条件，{H0} 根持有）\n")
    A(f"| 指标 | 数值 |")
    A(f"|---|---|")
    A(f"| 样本数 | {bstat['n']} |")
    A(f"| 平均收益（做多视角） | {bstat['mean']*100:+.3f}% |")
    A(f"| 做空基准（= 做多取负） | {-bstat['mean']*100:+.3f}% |")
    A(f"| 胜率 | {bstat['win']*100:.1f}% |")
    A(f"| 盈亏比 | {bstat['pl']:.2f} |")
    A("")
    A("> 这是「随便哪天入场、持有同样时间」的结果。")
    A("> **看涨信号与做多基准比，看跌信号与做空基准比** —— 样本期若整体上涨，")
    A("> 做空天然吃亏，分方向设基准才不会系统性偏袒某一方向。")
    A("> 信号必须显著跑赢**自己方向的基准**，才算有预测力。\n")

    # 汇总表
    # 分方向基准：
    #   看涨信号 → 与「无条件做多」对比   （基准 = base_mean）
    #   看跌信号 → 与「无条件做空」对比   （基准 = -base_mean）
    # 样本期若整体上涨，做空天然吃亏；分方向设基准才不会系统性偏袒某一方向。
    DIR_BASE = {"看涨": bstat["mean"], "看跌": -bstat["mean"]}

    rows = []
    for name, per_dir in pool_sig.items():
        for d, per_h in per_dir.items():
            rets = per_h.get(H0, {}).get("all", [])
            if len(rets) < MIN_SAMPLES:
                continue
            st = describe(rets)
            cmp_base = base if d == "看涨" else [-x for x in base]
            p = _welch_p(rets, cmp_base)
            excess = st["mean"] - DIR_BASE.get(d, bstat["mean"])
            rows.append({
                "name": name, "dir": d, "h": H0, **st,
                "excess": excess, "p": p,
            })

    rows.sort(key=lambda r: -r["excess"])

    A(f"## 各形态表现（持有 {H0} 根，样本数 ≥ {MIN_SAMPLES}）\n")
    A("> 「平均收益」为**方向调整后**收益：看涨信号记实际涨跌，看跌信号取负（下跌记为赚钱）。")
    A("> 「超额」= 平均收益 − **同方向**基准。超额为正且显著，才算该形态有预测力。\n")
    if not rows:
        A("_样本量不足，无法给出可靠结论。可增大 --limit 或扩充样本池。_\n")
    else:
        A("| 形态 | 方向 | 样本 | 平均收益 | 胜率 | 盈亏比 | 超额(vs基准) | p值 | 结论 |")
        A("|---|---|---:|---:|---:|---:|---:|---:|---|")
        for r in rows:
            if r["p"] is None:
                verdict = "样本不足"
            elif r["p"] < 0.01 and r["excess"] > 0:
                verdict = "**显著有效**"
            elif r["p"] < 0.05 and r["excess"] > 0:
                verdict = "有效"
            elif r["p"] < 0.05 and r["excess"] < 0:
                verdict = "⚠️ 显著反向"
            else:
                verdict = "不显著"
            pl = "∞" if r["pl"] == float("inf") else f"{r['pl']:.2f}"
            pv = "—" if r["p"] is None else f"{r['p']:.4f}"
            A(f"| {r['name']} | {r['dir']} | {r['n']} | {r['mean']*100:+.2f}% | "
              f"{r['win']*100:.0f}% | {pl} | {r['excess']*100:+.2f}% | {pv} | {verdict} |")
        A("")

        eff = [r for r in rows if r["p"] is not None and r["p"] < 0.05 and r["excess"] > 0]
        rev = [r for r in rows if r["p"] is not None and r["p"] < 0.05 and r["excess"] < 0]
        ns = [r for r in rows if r["p"] is None or r["p"] >= 0.05]

        A("## 结论\n")
        A(f"- **统计有效**（超额为正且 p<0.05）：{len(eff)} 个"
          + (f" → {', '.join(r['name'] for r in eff[:8])}" if eff else ""))
        A(f"- **显著反向**（超额为负且 p<0.05，即信号反着做更好）：{len(rev)} 个"
          + (f" → {', '.join(r['name'] for r in rev[:8])}" if rev else ""))
        A(f"- **不显著**：{len(ns)} 个 —— 样本期内未见预测力，属噪音或需叠加其它条件")
        A("")

    # ---- 趋势分层：验证「趋势优先于形态」 ----
    A(f"## 趋势位置的影响（持有 {H0} 根）\n")
    A("把每个信号按出现时的趋势环境分层。**顺势** = 看涨形态出现在上升趋势 / 看跌形态出现在下降趋势；")
    A("**逆势** = 相反。若铁律成立，顺势组应明显优于逆势组。\n")
    layered = []
    for name, per_dir in pool_sig.items():
        for d, per_h in per_dir.items():
            cell = per_h.get(H0, {})
            allr = cell.get("all", [])
            if len(allr) < MIN_SAMPLES:
                continue
            up, down, rng = cell.get("up", []), cell.get("down", []), cell.get("range", [])
            if d == "看涨":
                w, a, wl, al = up, down, "上升趋势", "下降趋势"
            else:
                w, a, wl, al = down, up, "下降趋势", "上升趋势"
            layered.append({
                "name": name, "dir": d, "wl": wl, "al": al,
                "w": describe(w) if len(w) >= 15 else None,
                "a": describe(a) if len(a) >= 15 else None,
                "r": describe(rng) if len(rng) >= 15 else None,
            })
    if layered:
        A("| 形态 | 方向 | 顺势环境 | 顺势样本 | 顺势平均 | 逆势环境 | 逆势样本 | 逆势平均 | 差 |")
        A("|---|---|---|---:|---:|---|---:|---:|---:|")
        def _key(z):
            return -((z["w"]["mean"] - z["a"]["mean"]) if (z["w"] and z["a"]) else -9)
        for L in sorted(layered, key=_key):
            wm = f"{L['w']['mean']*100:+.2f}%" if L["w"] else "样本不足"
            am = f"{L['a']['mean']*100:+.2f}%" if L["a"] else "样本不足"
            wn = L["w"]["n"] if L["w"] else 0
            an = L["a"]["n"] if L["a"] else 0
            diff = (f"{(L['w']['mean']-L['a']['mean'])*100:+.2f}%"
                    if (L["w"] and L["a"]) else "—")
            A(f"| {L['name']} | {L['dir']} | {L['wl']} | {wn} | {wm} | "
              f"{L['al']} | {an} | {am} | {diff} |")
        A("")
        both = [L for L in layered if L["w"] and L["a"]]
        if both:
            better = sum(1 for L in both if L["w"]["mean"] > L["a"]["mean"])
            A(f"- 在 {len(both)} 个可比较的形态中，**{better} 个**"
              f"（{better/len(both)*100:.0f}%）顺势环境优于逆势环境。")
            if better / len(both) >= 0.6:
                A("- 结论：**趋势位置确实显著影响形态有效性**，印证「趋势优先于形态」的铁律 ——")
                A("  形态不能脱离趋势环境单独使用。")
            else:
                A("- 结论：本样本期内趋势分层区分度不明显，可能该批形态对趋势位置不敏感，")
                A("  或分层口径（MA20 方向 + 价格位置）需调整。")
            A("")

    # 多持有期对比
    A(f"## 持有期敏感性（平均收益）\n")
    multi = []
    for name, per_dir in pool_sig.items():
        for d, per_h in per_dir.items():
            cells = {}
            for H in HORIZONS:
                rets = per_h.get(H, {}).get("all", [])
                cells[H] = (describe(rets)["mean"] if len(rets) >= MIN_SAMPLES else None)
            if any(v is not None for v in cells.values()):
                multi.append((name, d, cells))
    if multi:
        A("| 形态 | 方向 | " + " | ".join(f"{H}根" for H in HORIZONS) + " |")
        A("|---|---|" + "---:|" * len(HORIZONS))
        for name, d, cells in sorted(multi, key=lambda x: -(x[2].get(H0) or -9)):
            cs = []
            for H in HORIZONS:
                v = cells[H]
                cs.append("—" if v is None else f"{v*100:+.2f}%")
            A(f"| {name} | {d} | " + " | ".join(cs) + " |")
        A("")

    A("## 怎么用这份报告\n")
    A("1. **显著有效的形态**：可作为信号的加分项，但仍需位置、量能、关键位确认。")
    A("2. **显著反向的形态**：这是最有价值的发现 —— 说明市场结构可能已变化，")
    A("   或该形态在原著语境（不同市场/年代）下才成立。**不要照搬。**")
    A("3. **不显著的形态**：不代表无效，只说明「单独使用」没有优势；")
    A("   通常需要与趋势位置、量能共振才能发挥作用。")
    A("")
    A("> ⚠️ **重要边界**：这是历史统计，不是未来保证。样本期（约 3 年）无法覆盖所有市场状态；")
    A("> 窗口重叠会高估样本独立性；参数选择存在过拟合风险。**结论只能用于剔除明显无效项，")
    A("> 不能作为盈利依据。**")

    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("-" * 62)
    print(f"✅ 报告已写入 {args.out}（{len(ok)} 只标的，{len(rows)} 个形态纳入统计）")

    if args.csv:
        import csv as _csv
        with open(args.csv, "w", encoding="utf-8-sig", newline="") as f:
            w = _csv.writer(f)
            w.writerow(["pattern", "direction", "n", "mean_ret", "win_rate",
                        "profit_loss_ratio", "excess_vs_base", "p_value"])
            for r in rows:
                w.writerow([r["name"], r["dir"], r["n"], round(r["mean"], 6),
                            round(r["win"], 4), round(r["pl"], 4) if r["pl"] != float("inf") else "",
                            round(r["excess"], 6),
                            "" if r["p"] is None else round(r["p"], 6)])
        print(f"   明细 CSV → {args.csv}")


if __name__ == "__main__":
    main()
