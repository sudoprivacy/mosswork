#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pipeline.py — 一键分析流水线

    [数据]  →  结构化分析报告  →  可视化图表  →  多周期共振

用法：
    # 路径 A（零依赖，推荐）：用你自己的 OHLCV 数据
    python pipeline.py --csv mydata.csv --symbol 600519 --name 贵州茅台 --market A股

    # 路径 B（需已安装可选的 westock 数据源）：自动取数
    python pipeline.py --symbol sh600519 --name 贵州茅台
    python pipeline.py --symbol hk00700 --name 腾讯控股 --period week --limit 200

产出（默认写入 ./output/）：
    <symbol>_report.md       分析报告（趋势/价位/形态/量价/背离/天平/风险）
    <symbol>_chart.png       K线+均线+成交量+MACD 图
    <symbol>_multiframe.md   多周期共振分析（日/周/月，仅路径 B 可用）
    <symbol>_data.csv        标准 OHLCV 数据（仅路径 B 产出）

CSV 需含列：date,open,high,low,close,volume（列名支持中英文）。
"""
import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def run_step(title, script, args) -> bool:
    print(f"\n{'='*64}\n▶ {title}\n{'='*64}")
    cmd = [sys.executable, os.path.join(HERE, script)] + args
    r = subprocess.run(cmd, capture_output=True)
    out = r.stdout.decode("utf-8", errors="replace").strip()
    err = r.stderr.decode("utf-8", errors="replace").strip()
    if out:
        print(out)
    if r.returncode != 0:
        print(f"[FAIL] {title}: {err or '未知错误'}", file=sys.stderr)
        return False
    return True


def main():
    ap = argparse.ArgumentParser(description="一键分析流水线：取数 → 报告 → 图表")
    ap.add_argument("--symbol", required=True, help="代码，如 sh600519 / hk00700 / usAAPL / 600519")
    ap.add_argument("--csv", default="", help="自带 OHLCV 文件路径（给了就走零依赖路径，跳过取数）")
    ap.add_argument("--name", default="", help="标的名称（用于标题）")
    ap.add_argument("--market", default="", help="市场类型，留空自动推断")
    ap.add_argument("--period", default="day", choices=["day", "week", "month", "season", "year"])
    ap.add_argument("--limit", type=int, default=250, help="报告使用的 K 线根数")
    ap.add_argument("--chart-limit", type=int, default=120, help="图表显示的根数")
    ap.add_argument("--outdir", default="output")
    ap.add_argument("--no-chart", action="store_true", help="跳过绘图")
    ap.add_argument("--no-multi", action="store_true", help="跳过多周期共振分析")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    slug = args.symbol.replace(".", "_")
    csv_path = os.path.join(args.outdir, f"{slug}_data.csv")
    md_path = os.path.join(args.outdir, f"{slug}_report.md")
    png_path = os.path.join(args.outdir, f"{slug}_chart.png")
    mf_path = os.path.join(args.outdir, f"{slug}_multiframe.md")

    # 1) 数据
    if args.csv:
        src = os.path.abspath(args.csv)
        if not os.path.isfile(src):
            print(f"[中断] 找不到数据文件：{src}", file=sys.stderr)
            sys.exit(1)
        print(f"\n{'='*64}\n▶ Step 1/4 · 使用自带数据（跳过取数）\n{'='*64}")
        print(f"  数据源: {src}")
        csv_path = src
        if not args.no_multi:
            print("  [提示] 自带数据为单周期，无法做多周期共振 → 自动跳过 Step 4")
            args.no_multi = True
    else:
        ok = run_step("Step 1/4 · 获取真实行情（需已安装可选数据源 westock）", "fetch_data.py",
                      ["--symbol", args.symbol, "--period", args.period,
                       "--limit", str(args.limit), "--out", csv_path])
        if not ok:
            print("\n[中断] 自动取数失败。两条出路：", file=sys.stderr)
            print("  1) 确认代码格式 —— python scripts/fetch_data.py --search <名称>", file=sys.stderr)
            print("  2) 或改用自带数据（零依赖）：", file=sys.stderr)
            print(f"     python pipeline.py --csv 你的数据.csv --symbol {args.symbol} --market A股",
                  file=sys.stderr)
            sys.exit(1)
        if not os.path.isfile(csv_path):
            print(f"\n[中断] 未生成数据文件 {csv_path}", file=sys.stderr)
            sys.exit(1)

    # 市场推断
    market = args.market
    if not market:
        try:
            sys.path.insert(0, HERE)
            import fetch_data as F
            market = F.infer_market(args.symbol)
            tf = F.PERIOD_ZH.get(args.period, args.period)
        except Exception:
            market, tf = "未知", args.period
    else:
        sys.path.insert(0, HERE)
        try:
            import fetch_data as F
            tf = F.PERIOD_ZH.get(args.period, args.period)
        except Exception:
            tf = args.period

    # 2) 报告
    ok = run_step("Step 2/4 · 生成分析报告", "analyze.py",
                  ["--csv", csv_path, "--symbol", args.symbol,
                   "--name", args.name or args.symbol, "--market", market,
                   "--timeframe", tf, "-o", md_path])

    # 3) 图表
    chart_ok = False
    if not args.no_chart:
        chart_ok = run_step("Step 3/4 · 生成可视化图表", "chart.py",
                            ["--csv", csv_path, "--symbol", args.symbol,
                             "--name", args.name or args.symbol,
                             "--limit", str(args.chart_limit), "--out", png_path])

    # 4) 多周期共振
    mf_ok = False
    if not args.no_multi:
        mf_ok = run_step("Step 4/4 · 多周期共振分析", "multiframe.py",
                         ["--symbol", args.symbol, "--name", args.name or args.symbol,
                          "--out", mf_path])

    print(f"\n{'='*64}\n✅ 流水线完成  {args.symbol}  （{market} · {tf}）\n{'='*64}")
    print(f"  数据    : {csv_path}")
    print(f"  报告    : {md_path}")
    if not args.no_chart:
        print(f"  图表    : {png_path}" + ("" if chart_ok else "  [未生成]"))
    if not args.no_multi:
        print(f"  多周期  : {mf_path}" + ("" if mf_ok else "  [未生成]"))


if __name__ == "__main__":
    main()
