# -*- coding: utf-8 -*-
"""
analyze.py —— 交易助手主入口

用法：
  # 1) 用 JSON 数据
  python analyze.py --json bars.json --symbol 600519 --name 贵州茅台 --market A股

  # 2) 用 CSV 数据（列名: date,open,high,low,close,volume）
  python analyze.py --csv 600519.csv --symbol 600519 --market A股

  # 3) 自检（合成数据）
  python analyze.py --selftest

  # 4) 输出到文件
  python analyze.py --json bars.json -o report.md

数据要求：至少 60 根 K 线（建议 120 根以上）；日线/周线/分钟线均可，
脚本不关心周期，但报告中会提示"周期越短信号越易受噪音干扰"。

输出：Markdown 报告，含趋势结构、关键价位、指标状态、形态识别、
背离检测、多空证据天平、风险与操作框架、免责声明。
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from typing import Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import indicators as I
import patterns as P


# ----------------------------------------------------------------------------
# 数据载入
# ----------------------------------------------------------------------------
def load_json(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    if isinstance(raw, list):
        return {"bars": raw}
    return raw


def load_csv(path: str) -> dict:
    bars = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        cols = {c.lower().strip(): c for c in (rd.fieldnames or [])}

        def pick(*names):
            for n in names:
                if n in cols:
                    return cols[n]
            return None

        dcol = pick("date", "time", "datetime", "日期", "时间")
        ocol = pick("open", "o", "开盘", "开盘价")
        hcol = pick("high", "h", "最高", "最高价")
        lcol = pick("low", "l", "最低", "最低价")
        ccol = pick("close", "c", "收盘", "收盘价")
        vcol = pick("volume", "v", "vol", "成交量")
        if not all([ocol, hcol, lcol, ccol]):
            raise ValueError("CSV 缺少必要列（open/high/low/close）")
        for row in rd:
            try:
                bars.append({
                    "t": row.get(dcol, "") if dcol else "",
                    "o": float(row[ocol]), "h": float(row[hcol]),
                    "l": float(row[lcol]), "c": float(row[ccol]),
                    "v": float(row[vcol]) if vcol and row.get(vcol) not in (None, "") else 0.0,
                })
            except (TypeError, ValueError):
                continue
    return {"bars": bars}


def normalize(bars: List[dict]) -> Dict[str, list]:
    bars = sorted(bars, key=lambda b: b.get("t", "")) if bars and "t" in bars[0] else bars
    return {
        "o": [float(b.get("o", b.get("open"))) for b in bars],
        "h": [float(b.get("h", b.get("high"))) for b in bars],
        "l": [float(b.get("l", b.get("low"))) for b in bars],
        "c": [float(b.get("c", b.get("close"))) for b in bars],
        "v": [float(b.get("v", b.get("volume", 0)) or 0) for b in bars],
        "t": [str(b.get("t", "")) for b in bars],
    }


# ----------------------------------------------------------------------------
# 证据天平
# ----------------------------------------------------------------------------
class Evidence:
    def __init__(self):
        self.bull: List[tuple] = []
        self.bear: List[tuple] = []
        self.neutral: List[tuple] = []

    def add(self, side: str, item: str, weight: int = 1):
        if side == "bull":
            self.bull.append((item, weight))
        elif side == "bear":
            self.bear.append((item, weight))
        else:
            self.neutral.append((item, weight))

    @property
    def bull_score(self):
        return sum(w for _, w in self.bull)

    @property
    def bear_score(self):
        return sum(w for _, w in self.bear)

    def verdict(self) -> tuple:
        b, s = self.bull_score, self.bear_score
        tot = b + s
        if tot == 0:
            return "中性/信息不足", 0.0
        ratio = b / tot
        if ratio >= 0.70:
            return "偏多（多头证据占优）", ratio
        if ratio >= 0.58:
            return "偏多（弱）", ratio
        if ratio <= 0.30:
            return "偏空（空头证据占优）", ratio
        if ratio <= 0.42:
            return "偏空（弱）", ratio
        return "多空分歧（证据接近，宜观望或等确认）", ratio


# ----------------------------------------------------------------------------
# 主分析
# ----------------------------------------------------------------------------
def analyze(data: Dict[str, list], meta: dict) -> str:
    o, h, l, c, v = data["o"], data["h"], data["l"], data["c"], data["v"]
    n = len(c)
    sym = meta.get("symbol", "未指定")
    name = meta.get("name", "")
    market = meta.get("market", "未指定")
    tf = meta.get("timeframe", "未指定")

    ev = Evidence()
    L: List[str] = []
    A = L.append

    A(f"# 交易分析报告 · {name} {sym}".rstrip())
    A("")
    A(f"- **市场类型**：{market}")
    A(f"- **K线周期**：{tf}")
    A(f"- **数据根数**：{n} 根" + (f"（{data['t'][0]} → {data['t'][-1]}）" if data["t"][0] else ""))
    A(f"- **最新收盘**：{c[-1]:.4f}")
    A("")
    if n < 60:
        A("> ⚠️ 数据不足 60 根，以下结论可靠性显著下降，请补足历史数据后重新分析。")
        A("")

    # ---- 1. 趋势与结构 ----
    A("## 一、趋势与结构")
    A("")
    ms = P.market_structure(h, l, c)
    A(f"- **道氏结构**：{ms['structure']}")
    if ms.get("last_highs"):
        A(f"  - 最近三个摆动高点：{ms['last_highs']}")
        A(f"  - 最近三个摆动低点：{ms['last_lows']}")
    ma_align = I.ma_alignment(c)
    A(f"- **均线排列**：{ma_align['state']}" +
      (f"（均线离散度 {ma_align.get('spread', 0):.2%}）" if "spread" in ma_align else ""))
    if ma_align.get("values"):
        A("  - " + " / ".join(f"{k} {val:.4f}" for k, val in ma_align["values"].items()))
    ts = I.trend_strength(h, l, c)
    if ts.get("state") != "数据不足":
        A(f"- **趋势强度(ADX)**：{ts['ADX']}（{ts['state']}，{ts['direction']}；+DI {ts['PDI']} / -DI {ts['MDI']}）")
    A("")

    # 结构计入证据
    if "上升结构" in ms["structure"]:
        ev.add("bull", "道氏结构为上升（高点低点双双抬高）", 3)
    elif "下降结构" in ms["structure"]:
        ev.add("bear", "道氏结构为下降（高点低点双双降低）", 3)
    else:
        ev.add("neutral", f"道氏结构：{ms['structure']}", 1)
    if ma_align["state"] == "多头排列":
        ev.add("bull", "均线多头排列", 2)
    elif ma_align["state"] == "空头排列":
        ev.add("bear", "均线空头排列", 2)
    if ts.get("state") == "趋势明确":
        ev.add("bull" if ts["direction"] == "多头主导" else "bear",
               f"ADX {ts['ADX']} 趋势明确，{ts['direction']}", 2)
    elif ts.get("state") == "无趋势/震荡":
        ev.add("neutral", "ADX 偏低，处于震荡区间（趋势策略易被打脸）", 1)

    # ---- 2. 关键价位 ----
    A("## 二、关键价位")
    A("")
    sr = P.support_resistance(h, l, c)
    if sr["resistance"]:
        A("**阻力位（由近及远）**")
        for x in sorted(sr["resistance"], key=lambda z: z["price"]):
            A(f"- {x['price']:.4f}（被触及 {x['touches']} 次）")
    else:
        A("**阻力位**")
        A("- 上方暂无明确阻力（可能处于新高区）")
    if sr["support"]:
        A("")
        A("**支撑位（由近及远）**")
        for x in sorted(sr["support"], key=lambda z: -z["price"]):
            A(f"- {x['price']:.4f}（被触及 {x['touches']} 次）")
    else:
        A("")
        A("**支撑位**")
        A("- 下方暂无明确支撑（可能处于新低区）")
    gs = P.gaps(h, l, c)
    if gs:
        A("")
        A("**跳空缺口**")
        for g in gs:
            cls = P.gap_classify(g, c, g["idx"])
            A(f"- {g['type']} {g['lower']:.4f}~{g['upper']:.4f}（{g['pct']}%，"
              f"{'已回补' if g['filled'] else '未回补'}，{cls}）")
    A("")

    # ---- 3. 指标状态 ----
    A("## 三、指标状态")
    A("")
    m = I.macd(c)
    mc = I.macd_cross(m)
    if mc.get("cross") != "数据不足":
        if mc["cross"] == "无":
            A(f"- **MACD**：DIF {mc['DIF']} / DEA {mc['DEA']}，柱 {mc['hist']}，"
              f"{mc['zero_axis']}，当前无交叉"
              + ("（DIF 在 DEA 上方，多头占优）" if mc["DIF"] > mc["DEA"] else "（DIF 在 DEA 下方，空头占优）"))
        else:
            A(f"- **MACD**：DIF {mc['DIF']} / DEA {mc['DEA']}，柱 {mc['hist']}，"
              f"{mc['zero_axis']}**{mc['cross']}**。{mc['meaning']}")
        if mc["cross"] == "金叉":
            ev.add("bull", f"MACD {mc['zero_axis']}金叉", 2 if mc["zero_axis"] == "零轴上" else 1)
        elif mc["cross"] == "死叉":
            ev.add("bear", f"MACD {mc['zero_axis']}死叉", 2 if mc["zero_axis"] == "零轴下" else 1)
    r = I.rsi(c, 14)
    if r[-1] is not None:
        rv = r[-1]
        tag = "超买区(>70)" if rv > 70 else ("超卖区(<30)" if rv < 30 else "中性区")
        A(f"- **RSI(14)**：{rv:.2f}（{tag}）")
        if rv > 75:
            ev.add("bear", f"RSI {rv:.1f} 进入超买区，短线过热", 1)
        elif rv < 25:
            ev.add("bull", f"RSI {rv:.1f} 进入超卖区，短线超跌", 1)
    k = I.kdj(h, l, c)
    if k["J"][-1] is not None:
        kv, dv, jv = k["K"][-1], k["D"][-1], k["J"][-1]
        cross = ""
        if len(k["K"]) > 1 and k["K"][-2] is not None and k["D"][-2] is not None:
            if k["K"][-2] <= k["D"][-2] and kv > dv:
                cross = "（金叉）"
                ev.add("bull", f"KDJ 金叉（K={kv:.1f}, D={dv:.1f}）", 1)
            elif k["K"][-2] >= k["D"][-2] and kv < dv:
                cross = "（死叉）"
                ev.add("bear", f"KDJ 死叉（K={kv:.1f}, D={dv:.1f}）", 1)
        A(f"- **KDJ**：K {kv:.2f} / D {dv:.2f} / J {jv:.2f}{cross}")
    b = I.boll(c)
    bs = I.boll_state(c, b)
    if bs.get("state") != "数据不足":
        A(f"- **BOLL(20,2)**：上轨 {bs['UP']} / 中轨 {bs['MID']} / 下轨 {bs['DN']}，"
          f"当前{bs['state']}，带宽 {bs['bandwidth']:.2%}"
          + ("，**带宽收窄（变盘临近）**" if bs.get("squeeze") else ""))
        if bs.get("squeeze"):
            ev.add("neutral", "BOLL 带宽收窄，波动收敛，方向选择临近", 1)
    vr = I.volume_ratio(v, 5)
    if vr[-1] is not None:
        A(f"- **量比（对比前5日均量）**：{vr[-1]:.2f}"
          + ("，明显放量" if vr[-1] > 1.5 else ("，明显缩量" if vr[-1] < 0.7 else "，量能平稳")))
        if vr[-1] > 2.0:
            ev.add("neutral", f"显著放量（量比 {vr[-1]:.2f}），方向性信号增强", 0)
    mf = I.mfi(h, l, c, v)
    if mf[-1] is not None:
        A(f"- **MFI(14) 资金流量**：{mf[-1]:.1f}（"
          + ("资金强势流入" if mf[-1] > 80 else ("资金流出明显" if mf[-1] < 20 else "资金中性")) + "）")
    fatr = I.atr_stop(c, h, l, "long")
    if "ATR" in fatr:
        A(f"- **ATR(14)**：{fatr['ATR']:.4f}（占价 {fatr['ATR%']}%），"
          f"2×ATR 多头止损参考 {fatr['stop']:.4f}（风险 {fatr['risk_pct']}%）")
    A("")

    # ---- 4. 形态识别 ----
    A("## 四、K线形态识别")
    A("")
    pats = P.scan_all(o, h, l, c, lookback=30)
    recent = [p for p in pats if p["idx"] >= n - 5]

    # 实证权标尺（见 references/10-信号有效性实证结论.md）：
    #   形态单独出现 = +0.5（实测 19 个形态中 0 个单独显著跑赢基准）
    #   形态 + 趋势环境顺势 = +1.5；顺势且强形态 = +2
    _tr = ("up" if ms.get("structure") == "上升结构"
           else "down" if ms.get("structure") == "下降结构" else "range")

    def _pat_weight(direction: str, strength: str = "中") -> float:
        if _tr == "range":
            return 0.5                     # 无趋势可顺 → 最保守
        aligned = ((direction == "看涨" and _tr == "up")
                   or (direction == "看跌" and _tr == "down"))
        if not aligned:
            return 0.5                     # 逆势形态不给权重
        return 2.0 if strength == "强" else 1.5

    if recent:
        A("**最近 5 根内出现的形态**")
        for p in recent:
            A(f"- [{p['idx']}/{n}] **{p['name']}**（{p['direction']}，强度{p['strength']}）：{p['note']}")
            if p["direction"] == "看涨":
                ev.add("bull", f"形态：{p['name']}", _pat_weight("看涨", p["strength"]))
            elif p["direction"] == "看跌":
                ev.add("bear", f"形态：{p['name']}", _pat_weight("看跌", p["strength"]))
    else:
        A("- 最近 5 根内未检出明确经典形态。")
    older = [p for p in pats if p["idx"] < n - 5][:8]
    if older:
        A("")
        A("**稍早期形态（供参考）**")
        for p in older:
            A(f"- [{p['idx']}/{n}] {p['name']}（{p['direction']}）")
    A("")
    A("### 逃顶形态专项扫描")
    top = P.topping_scan(o, h, l, c, recent=6)
    if top:
        for p in top:
            A(f"- ⚠️ **{p['name']}**（{p['direction']}）：{p['note']}")
            ev.add("bear", f"逃顶形态：{p['name']}", _pat_weight("看跌", "强"))
    else:
        A("- 最近 6 根内未命中典型逃顶形态。")
    A("")

    # ---- 5. 背离检测 ----
    A("## 五、背离检测")
    A("")
    divs = P.detect_divergence(h, l, c, m["DIF"], "MACD", lookback=120)
    divs += P.detect_divergence(h, l, c, r, "RSI", lookback=120)
    if divs:
        for d in divs:
            A(f"- **{d['name']}**（{d['direction']}，强度{d['strength']}）：{d['note']}")
            ev.add("bear" if d["direction"] == "看跌" else "bull",
                   f"背离：{d['name']}", 2 if d["strength"] == "强" else 1)
        A("")
        A("> 背离只说明**动能衰竭**，不等于立即反转。按本套战法，必须等能量柱变色且当根 K 线收盘后才考虑进场。")
    else:
        A("- 最近区间内未检出明显背离。")
    A("")

    # ---- 6. 证据天平 ----
    A("## 六、多空证据天平")
    A("")
    verdict, ratio = ev.verdict()
    A(f"**综合倾向：{verdict}**（多头证据 {ev.bull_score} 分 / 空头证据 {ev.bear_score} 分，"
      f"多头占比 {ratio:.0%}）")
    A("")
    if ev.bull:
        A("**看多证据**")
        for item, w in ev.bull:
            A(f"- (+{w}) {item}")
    if ev.bear:
        A("")
        A("**看空证据**")
        for item, w in ev.bear:
            A(f"- (-{w}) {item}")
    if ev.neutral:
        A("")
        A("**中性/待观察**")
        for item, w in ev.neutral:
            A(f"- (0) {item}")
    A("")
    A("> 证据天平是**已知信息的加权汇总**，不是对未来价格的预测。")
    A("> 权重已按实测标尺校准（见 `references/10-信号有效性实证结论.md`）：")
    A("> **形态单独出现仅计 +0.5** —— 11250 根真实 K 线实测，19 个形态中 0 个单独显著有效。")
    A("> 形态与趋势环境顺势时提权至 +1.5~+2，逆势形态不给权重。")
    A("> **单靠形态不足以构成操作理由。**")
    A("")

    # ---- 7. 风险与操作框架 ----
    A("## 七、风险与操作框架")
    A("")
    A("### 7.1 关键防守位与风险计量")
    if "ATR" in fatr:
        A(f"- 当前价 {c[-1]:.4f}，ATR {fatr['ATR']:.4f}（波动率 {fatr['ATR%']}%）")
        A(f"- 2×ATR 止损参考：做多 {c[-1] - 2*fatr['ATR']:.4f} / 做空 {c[-1] + 2*fatr['ATR']:.4f}")
        A(f"- 单笔风险若控制在总资金 1%，则仓位 = 总资金 × 1% ÷ (入场价 − 止损价)")
        if sr["support"]:
            ns = max([x["price"] for x in sr["support"] if x["price"] < c[-1]], default=None)
            if ns:
                A(f"- 最近的实体支撑 {ns:.4f}，跌破且收盘不收回则结构转弱")
        if sr["resistance"]:
            nr = min([x["price"] for x in sr["resistance"] if x["price"] > c[-1]], default=None)
            if nr:
                A(f"- 最近的实体阻力 {nr:.4f}，有效突破（放量+收盘站稳）才打开上行空间")
    A("")
    A("### 7.2 场景推演（条件式，非预测）")
    A("")
    A("| 场景 | 触发条件 | 对应动作 |")
    A("|---|---|---|")
    A("| 多头延续 | 站稳最近阻力上方并放量，回踩不破该位 | 顺势持有/分批建立，止损放支撑下方 |")
    A("| 区间震荡 | 在最近支撑与阻力之间反复，ADX 低位 | 高抛低吸或直接观望，避免追涨杀跌 |")
    A("| 破位转弱 | 收盘有效跌破最近支撑，且量能放大 | 减仓/离场，等待结构重建 |")
    A("| 反转尝试 | 出现底/顶背离 + 形态确认 + 能量柱变色收盘 | 小仓位试单，严格止损，按 1:1.2~1:1.5 盈亏比管理 |")
    A("")
    A("### 7.3 仓位管理参考")
    A("")
    A("- 单笔风险上限建议 1%~2% 总资金；连续 3 笔亏损后降低单笔风险至 0.5%。")
    A("- 分批建仓（1/3 试仓 → 走对加至 1/2 → 突破确认补足），避免一次性满仓。")
    A("- 组合同时持有的标的不宜超过 8~10 只，单只最高仓位建议 ≤20%。")
    A("- 止损一旦设定，不因情绪下移；只在盈利后上移（跟踪止盈）。")
    A("")

    # ---- 8. 免责声明 ----
    A("## 八、免责声明")
    A("")
    A("本报告由**规则化程序**基于输入的行情数据计算生成，所有结论均为**客观指标的机械汇总**，"
      "不构成任何证券、期货、衍生品或虚拟货币的买卖建议、投资咨询或收益承诺。")
    A("")
    A("- 技术分析仅描述历史价格行为，**不预测未来**，任何形态与指标都可能失效。")
    A("- 期货、期权、杠杆与虚拟货币交易具有高波动与强平风险，可能导致本金全部损失。")
    A("- 行情数据由使用者提供或经公开接口获取，可能存在延迟、缺失或错误；关键数字请以交易所与持牌行情商数据为准。")
    A("- 虚拟货币相关业务活动在中国内地属于非法金融活动，不受法律保护；请遵守所在地法律法规。")
    A("- 投资决策与后果由使用者自行承担。")
    A("")
    return "\n".join(L)


# ----------------------------------------------------------------------------
# 自检数据（合成）
# ----------------------------------------------------------------------------
def selftest_bars(n: int = 240) -> dict:
    """
    合成一段贴近真实行情的序列（固定随机种子，结果可复现）：
    上涨趋势 -> 高位震荡做顶 -> 下跌趋势 -> 底部反弹，
    并叠加随机噪声，使 ADX/RSI 等指标落在合理区间。
    """
    import math
    import random
    rng = random.Random(20261003)
    bars = []
    price = 100.0
    for i in range(n):
        if i < 0.4 * n:
            drift = 0.0040      # 上涨
        elif i < 0.5 * n:
            drift = 0.0002      # 高位滞涨
        elif i < 0.8 * n:
            drift = -0.0045     # 下跌
        else:
            drift = 0.0035      # 反弹
        wave = math.sin(i / 7.0) * 0.006
        noise = rng.gauss(0, 0.011)          # 关键：随机噪声
        ret = drift + wave * 0.4 + noise
        o = price
        price = price * (1 + ret)
        c_ = price
        amp = abs(rng.gauss(0, 0.010)) + 0.002
        hh = max(o, c_) * (1 + amp)
        ll = min(o, c_) * (1 - amp)
        vol = 1_000_000 * (1 + abs(ret) * 40 + rng.random() * 0.5)
        bars.append({"t": f"D{i+1:03d}", "o": round(o, 4), "h": round(hh, 4),
                     "l": round(ll, 4), "c": round(c_, 4), "v": round(vol, 0)})
    return {"bars": bars}


def main():
    ap = argparse.ArgumentParser(description="交易助手 · 结构化分析报告生成器")
    ap.add_argument("--json", help="JSON 数据文件")
    ap.add_argument("--csv", help="CSV 数据文件")
    ap.add_argument("--symbol", default="未指定")
    ap.add_argument("--name", default="")
    ap.add_argument("--market", default="未指定", help="A股/港股/美股/期货/期权/虚拟货币")
    ap.add_argument("--timeframe", default="未指定", help="日线/周线/60分钟/15分钟/5分钟")
    ap.add_argument("--selftest", action="store_true", help="用合成数据自检")
    ap.add_argument("-o", "--out", help="输出 Markdown 文件路径")
    args = ap.parse_args()

    if args.selftest:
        data = normalize(selftest_bars()["bars"])
        meta = {"symbol": "SELFTEST", "name": "自检合成数据",
                "market": "合成", "timeframe": "日线"}
        md = analyze(data, meta)
    elif args.json:
        raw = load_json(args.json)
        meta = {"symbol": args.symbol, "name": args.name,
                "market": args.market, "timeframe": args.timeframe}
        meta.update({k: v for k, v in raw.items() if k in ("symbol", "name", "market", "timeframe")})
        data = normalize(raw["bars"])
        md = analyze(data, meta)
    elif args.csv:
        raw = load_csv(args.csv)
        data = normalize(raw["bars"])
        md = analyze(data, {"symbol": args.symbol, "name": args.name,
                            "market": args.market, "timeframe": args.timeframe})
    else:
        ap.print_help()
        return 1

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"报告已写入 {args.out}（{len(md)} 字符）")
    else:
        sys.stdout.reconfigure(encoding="utf-8")
        print(md)
    return 0


if __name__ == "__main__":
    sys.exit(main())
