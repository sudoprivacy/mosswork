#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_data.py — 真实行情数据适配器【可选组件】

⚠️ 本脚本是**可选的数据获取通道，不是本技能的必需组件**。
   没有它，技能依然完整可用 —— 直接用你自己的 OHLCV 数据即可：
       python analyze.py  --csv 你的数据.csv --symbol 600519 --market A股 -o 报告.md
       python pipeline.py --csv 你的数据.csv --symbol 600519 --name 贵州茅台

   若你已安装 WeStock CLI（腾讯自选股数据源），本脚本可自动抓取行情并转成分析引擎的
   标准 CSV/JSON，打通「实时取数 → 指标计算 → 形态识别 → 报告」的闭环。

用法：
    # A股 / 港股 / 美股 / ETF / 指数 / 可转债 / 外汇
    python fetch_data.py --symbol sh600519 --period day --limit 250 --out data.csv
    python fetch_data.py --symbol hk00700 --period day --limit 120 --out hk.csv
    python fetch_data.py --symbol usAAPL  --period week --limit 100 --out aapl.csv

    # 先搜代码（用户只给名称时）
    python fetch_data.py --search 宁德时代

    # 不落盘，只打印 JSON
    python fetch_data.py --symbol sh600519 --limit 60 --json

    # 环境自检：确认可选数据源是否可用
    python fetch_data.py --check

依赖：westock CLI（可选）。本模块自身无第三方 Python 依赖。
"""
import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys

WESTOCK_CANDIDATES = [
    os.path.expanduser("~/.local/bin/westock.exe"),
    os.path.expanduser("~/.local/bin/westock"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "westock.exe"),
]

# westock 的 --period 取值
PERIODS = {"day", "week", "month", "season", "year"}
PERIOD_ZH = {"day": "日线", "week": "周线", "month": "月线",
             "season": "季线", "year": "年线"}


def find_westock() -> str:
    for p in WESTOCK_CANDIDATES:
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    w = shutil.which("westock")
    if w:
        return w
    raise FileNotFoundError(
        "未找到 westock CLI。\n"
        "  ⚠️ 它是本技能的【可选】自动取数通道，不是必需依赖 —— 不装也完全能用。\n"
        "\n"
        "  ── 方案 A（推荐，零依赖）：用自己的数据 ──\n"
        "     CSV 列：date,open,high,low,close,volume\n"
        "     python analyze.py  --csv 你的数据.csv --symbol 600519 --market A股 -o 报告.md\n"
        "     python pipeline.py --csv 你的数据.csv --symbol 600519 --name 贵州茅台\n"
        "\n"
        "  ── 方案 B：安装 westock 以启用自动取数 ──\n"
        "     把 westock 可执行文件放到 ~/.local/bin/ 或本 scripts/ 目录下即可被自动识别\n"
        "     （数据源与获取方式见项目 README 的「可选：接入实时行情」一节）"
    )


def run_westock(cli: str, args: list, retries: int = 2, timeout: int = 90) -> str:
    """调用 westock，返回 stdout 文本。失败自动退避重试（长历史请求偶发超时）。"""
    import time
    env = os.environ.copy()
    parts = [os.path.dirname(cli)]
    if os.name == "nt":                      # 仅 Windows 需补 System32（部分机器 PATH 被裁剪过）
        parts.append(os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32"))
    parts.append(env.get("PATH", ""))
    env["PATH"] = os.pathsep.join(parts)
    last = "未知错误"
    for attempt in range(retries + 1):
        try:
            r = subprocess.run([cli] + args, capture_output=True,
                               timeout=timeout, env=env)
            out = r.stdout.decode("utf-8", errors="replace")
            if r.returncode == 0 and out.strip():
                return out
            last = (r.stderr.decode("utf-8", errors="replace").strip()
                    or out.strip()[:200] or f"exit={r.returncode}")
        except subprocess.TimeoutExpired:
            last = f"超时（{timeout}s）"
        if attempt < retries:
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"westock 调用失败（已重试 {retries} 次）：{last}")


def parse_md_table(text: str) -> list:
    """解析 Markdown 表格，返回 list[dict]（表头为 key）。"""
    lines = [l.strip() for l in text.splitlines() if l.strip().startswith("|")]
    if len(lines) < 2:
        return []
    def cells(line):
        return [c.strip() for c in line.strip("|").split("|")]
    header = cells(lines[0])
    rows = []
    for ln in lines[1:]:
        cs = cells(ln)
        # 跳过分隔行（---）
        if all(re.fullmatch(r":?-{2,}:?", c or "-") for c in cs):
            continue
        if len(cs) < len(header):
            cs += [""] * (len(header) - len(cs))
        rows.append(dict(zip(header, cs[: len(header)])))
    return rows


def _num(s: str):
    """把 '--' / '未开盘' / 空 转 None，其余转 float。"""
    s = (s or "").strip().replace(",", "")
    if s in ("", "--", "-", "未开盘", "None"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def fetch_kline(cli: str, symbol: str, period: str, limit: int) -> list:
    """取 K 线，返回按时间正序（旧→新）的标准 bar 列表。"""
    if period not in PERIODS:
        raise ValueError(f"--period 只能是 {sorted(PERIODS)}")
    text = run_westock(cli, ["kline", symbol, "--period", period, "--limit", str(limit)])
    rows = parse_md_table(text)
    if not rows:
        raise RuntimeError(f"未取到 K 线数据（symbol={symbol}）。先 `--search` 确认代码与市场前缀。")

    bars = []
    for r in rows:
        d = r.get("date") or r.get("日期") or ""
        o = _num(r.get("open") or r.get("开盘"))
        h = _num(r.get("high") or r.get("最高"))
        lo = _num(r.get("low") or r.get("最低"))
        c = _num(r.get("last") or r.get("close") or r.get("收盘") or r.get("收盘/最新"))
        v = _num(r.get("volume") or r.get("成交量"))
        if None in (o, h, lo, c) or not d:
            continue
        bars.append({
            "t": d, "o": o, "h": h, "l": lo, "c": c,
            "v": v if v is not None else 0.0,
        })

    # westock 默认最新在前 → 反转为时间正序，技术指标计算必须正序
    bars.reverse()
    return bars


# ---------- 市场推断 ----------
_PREFIX_MARKET = [
    (("sh", "sz", "bj"), "A股"),
    (("hk",), "港股"),
    (("us",), "美股"),
    (("fu",), "期货"),
    (("fx",), "外汇"),
    (("pt",), "板块/指数"),
    (("t", "ks", "kq"), "海外指数"),
]


def infer_market(symbol: str) -> str:
    s = symbol.lower()
    for prefixes, mkt in _PREFIX_MARKET:
        for p in prefixes:
            if s.startswith(p):
                return mkt
    return "未知"


def write_csv(bars: list, path: str):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["date", "open", "high", "low", "close", "volume"])
        for b in bars:
            w.writerow([b["t"], b["o"], b["h"], b["l"], b["c"], int(b["v"])])


def main():
    ap = argparse.ArgumentParser(description="真实行情数据适配器（WeStock/腾讯自选股源）")
    ap.add_argument("--symbol", help="带市场前缀的代码，如 sh600519 / hk00700 / usAAPL")
    ap.add_argument("--period", default="day", choices=sorted(PERIODS), help="周期，默认 day")
    ap.add_argument("--limit", type=int, default=250, help="取多少根 K 线，默认 250")
    ap.add_argument("--out", default="", help="输出 CSV 路径")
    ap.add_argument("--json", action="store_true", help="输出 JSON 而非 CSV")
    ap.add_argument("--search", default="", help="搜索代码，如 --search 宁德时代")
    ap.add_argument("--type", default="", help="search 类型: stock/etf/index/sector/bond/futures/forex")
    ap.add_argument("--check", action="store_true", help="环境自检：检测可选数据源是否可用")
    args = ap.parse_args()

    if args.check:
        try:
            cli = find_westock()
            print(f"[OK] 检测到可选数据源 westock: {cli}")
            print("     自动取数已启用。示例：")
            print("       python fetch_data.py --symbol sh600519 --limit 250 --out data.csv")
        except FileNotFoundError:
            print("[--] 未检测到 westock CLI —— 自动取数不可用。")
            print("     这是【可选】通道，不影响技能正常使用。改用自带数据即可：")
            print("       python analyze.py --csv 你的数据.csv --symbol 600519 --market A股 -o 报告.md")
        return

    try:
        cli = find_westock()
    except FileNotFoundError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

    # 搜索模式
    if args.search:
        cmd = ["search", args.search]
        if args.type:
            cmd += ["--type", args.type]
        try:
            print(run_westock(cli, cmd), end="")
        except RuntimeError as e:
            print(f"搜索失败: {e}", file=sys.stderr)
            sys.exit(1)
        return

    if not args.symbol:
        ap.error("需要 --symbol 或 --search")

    try:
        bars = fetch_kline(cli, args.symbol, args.period, args.limit)
    except (RuntimeError, ValueError) as e:
        print(f"取数失败: {e}", file=sys.stderr)
        sys.exit(1)

    market = infer_market(args.symbol)
    payload = {
        "symbol": args.symbol,
        "market": market,
        "timeframe": PERIOD_ZH.get(args.period, args.period),
        "source": "WeStock CLI (腾讯自选股数据源)",
        "bars": bars,
    }

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    out = args.out or f"{args.symbol.replace('.', '_')}_{args.period}.csv"
    write_csv(bars, out)
    rng = f"{bars[0]['t']} → {bars[-1]['t']}" if bars else "空"
    print(f"[OK] {args.symbol} ({market}) {PERIOD_ZH.get(args.period, args.period)} "
          f"{len(bars)} 根  {rng}")
    print(f"     → {out}")
    if len(bars) < 60:
        print(f"[warn] 仅 {len(bars)} 根 K 线，指标/形态可靠性下降（建议 ≥ 120 根）")


if __name__ == "__main__":
    main()
