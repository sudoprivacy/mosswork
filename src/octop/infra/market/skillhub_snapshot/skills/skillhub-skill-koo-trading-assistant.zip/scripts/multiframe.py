#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
multiframe.py — 多周期共振分析

单周期看盘最大的问题是「日线看多、周线看空」时无所适从。本模块把
日线 / 周线 / 月线（可配）放在一起比对，回答三个问题：

    1. 各周期分别是什么方向？
    2. 是否共振？共振强度多大？
    3. 冲突时以哪个为准、具体怎么操作？

核心原则：**大周期定方向，小周期找入场；冲突时以大周期为准。**

用法：
    python multiframe.py --symbol sh600519 --name 贵州茅台 --outdir output
    python multiframe.py --symbol hk00700 --periods day,week --out mf.md
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import indicators as I      # noqa: E402
import patterns as P        # noqa: E402
import fetch_data as F      # noqa: E402

TF_ZH = {"day": "日线", "week": "周线", "month": "月线"}
TF_LIMIT = {"day": 250, "week": 250, "month": 120}


def tf_state(bars):
    """算出某周期的方向与状态。返回 None 表示数据不足。"""
    if len(bars) < 30:
        return None
    o = [b["o"] for b in bars]
    h = [b["h"] for b in bars]
    l = [b["l"] for b in bars]
    c = [b["c"] for b in bars]

    ms = P.market_structure(h, l, c)
    ma = I.ma_alignment(c)
    ts = I.trend_strength(h, l, c)
    m = I.macd(c)

    score = 0
    reasons = []
    if "上升" in ms.get("structure", ""):
        score += 1
        reasons.append("结构上升")
    elif "下降" in ms.get("structure", ""):
        score -= 1
        reasons.append("结构下降")
    else:
        reasons.append("结构震荡")

    if ma.get("state") == "多头排列":
        score += 1
        reasons.append("均线多头")
    elif ma.get("state") == "空头排列":
        score -= 1
        reasons.append("均线空头")

    if ts.get("state") == "趋势明确":
        if ts.get("direction") == "多头主导":
            score += 1
            reasons.append(f"ADX{ts['ADX']}多头主导")
        else:
            score -= 1
            reasons.append(f"ADX{ts['ADX']}空头主导")
    else:
        reasons.append("ADX弱/震荡")

    dif, dea = m["DIF"][-1], m["DEA"][-1]
    if dif is not None and dea is not None:
        if dif > dea:
            score += 1
            reasons.append("MACD多头")
        else:
            score -= 1
            reasons.append("MACD空头")

    if score >= 2:
        direction = "偏多"
    elif score <= -2:
        direction = "偏空"
    else:
        direction = "中性/震荡"

    return {
        "bars": len(bars),
        "range": f"{bars[0]['t']} → {bars[-1]['t']}",
        "last": c[-1],
        "structure": ms.get("structure", "—"),
        "ma_state": ma.get("state", "—"),
        "adx": ts.get("ADX", "—"),
        "adx_state": ts.get("state", "—"),
        "score": score,
        "direction": direction,
        "reasons": reasons,
    }


def fetch(cli, sym, period, limit, cache_dir):
    cp = os.path.join(cache_dir, f"mf_{sym}_{period}_{limit}.json")
    if os.path.isfile(cp):
        try:
            d = json.load(open(cp, encoding="utf-8"))
            if d.get("bars"):
                return d["bars"]
        except Exception:
            pass
    bars = F.fetch_kline(cli, sym, period, limit)
    os.makedirs(cache_dir, exist_ok=True)
    with open(cp, "w", encoding="utf-8") as f:
        json.dump({"bars": bars}, f, ensure_ascii=False)
    return bars


def main():
    ap = argparse.ArgumentParser(description="多周期共振分析")
    ap.add_argument("--symbol", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--periods", default="day,week,month", help="逗号分隔，默认 day,week,month")
    ap.add_argument("--out", default="multiframe.md")
    args = ap.parse_args()

    try:
        cli = F.find_westock()
    except FileNotFoundError as e:
        print(str(e), file=sys.stderr)
        sys.exit(2)

    periods = [p.strip() for p in args.periods.split(",") if p.strip()]
    # 缓存目录：默认放系统临时目录，避免污染技能目录（可用环境变量 KTA_CACHE_DIR 覆盖）
    cache_dir = os.environ.get("KTA_CACHE_DIR") or os.path.join(
        tempfile.gettempdir(), "koo-trading-assistant-cache")

    states = {}
    for p in periods:
        try:
            bars = fetch(cli, args.symbol, p, TF_LIMIT.get(p, 250), cache_dir)
        except Exception as e:
            print(f"  [skip] {TF_ZH.get(p, p)}: {str(e)[:70]}")
            continue
        st = tf_state(bars)
        if st:
            states[p] = st

    if not states:
        print("[中断] 没有可用的周期数据", file=sys.stderr)
        sys.exit(1)

    title = f"{args.name} {args.symbol}".strip()
    L = []
    A = L.append
    A(f"# 多周期共振分析 · {title}\n")
    A(f"数据来源：WeStock CLI ｜ 周期：{' / '.join(TF_ZH.get(p, p) for p in states)}\n")

    A("## 一、各周期状态\n")
    A("| 周期 | 方向 | 结构 | 均线 | ADX | 样本区间 |")
    A("|---|---|---|---|---|---|")
    for p, st in states.items():
        A(f"| **{TF_ZH.get(p, p)}** | **{st['direction']}**（{st['score']:+d}） | "
          f"{st['structure']} | {st['ma_state']} | {st['adx']}（{st['adx_state']}） | {st['range']} |")
    A("")

    A("## 二、判断依据\n")
    for p, st in states.items():
        A(f"- **{TF_ZH.get(p, p)}**：{' / '.join(st['reasons'])}")
    A("")

    # ---- 共振分析 ----
    # 按周期从大到小排序（month > week > day），大周期才是定方向的那个
    TF_ORDER = {"month": 0, "week": 1, "day": 2}
    ranked = sorted(states.items(), key=lambda kv: TF_ORDER.get(kv[0], 9))
    dirs = [st["direction"] for _, st in ranked]
    big_name, big = TF_ZH.get(ranked[0][0], ranked[0][0]), ranked[0][1]["direction"]
    small_name, small = TF_ZH.get(ranked[-1][0], ranked[-1][0]), ranked[-1][1]["direction"]
    uniq = set(dirs)

    A("## 三、共振结论\n")
    if len(uniq) == 1 and dirs[0] != "中性/震荡":
        A(f"✅ **强共振**：{'、'.join(TF_ZH.get(p, p) for p in states)} 方向一致"
          f"（全部 **{dirs[0]}**）。")
        A("")
        A(f"- 这是最清晰的格局：**顺 {dirs[0]} 方向操作**，回调/反弹即为机会。")
        if "偏多" in dirs[0]:
            A("- 具体：等小周期回踩关键支撑不破再进，止损放支撑下方，让利润奔跑。")
        else:
            A("- 具体：反弹到阻力位受阻可考虑减仓/做空，不接飞刀。")
    elif len(uniq) == 1:
        A("➖ **全周期震荡**：各周期均无明确方向。")
        A("")
        A("- **降低仓位或直接观望** —— 趋势策略在这种环境下最容易被打脸。")
        A("- 等某个周期先走出结构（高点低点链条形成）再介入。")
    elif len(uniq) <= 2:
        A(f"⚠️ **部分共振**：大周期（{big_name}）**{big}**，小周期（{small_name}）**{small}**。")
        A("")
        if big == "中性/震荡":
            A(f"- 大周期 {big_name} 无方向，**以 {small_name} 的 {small} 为参考但降低仓位**。")
            A("- 大周期未定，任何方向的持仓都只能算试探，止损必须严格。")
        else:
            A(f"- 以**大周期 {big_name} 的 {big}** 为主方向，小周期只做同向机会。")
            A(f"- 若小周期与 {big_name} 相悖，**不逆大周期操作**，最多短线快进快出。")
    else:
        A(f"❌ **周期冲突**：{' / '.join(f'{TF_ZH.get(p,p)}={d}' for p, d in ranked)}。")
        A("")
        A(f"- **以大周期为准**：{big_name} 为 **{big}**。")
        A("- 冲突时波动通常放大、假突破增多，**建议观望或只做极小仓位**，等周期重新统一。")
    A("")

    # ---- 操作框架 ----
    A("## 四、操作含义\n")
    A("| 场景 | 触发 | 动作 |")
    A("|---|---|---|")
    A(f"| 顺势延续 | 小周期（{small_name}）回踩后重新转 {small}，且大周期未破坏 | "
      f"顺 {big} 方向建立/加仓，止损放最近结构点外 |")
    A(f"| 周期转向 | 大周期（{big_name}）状态改变（结构/均线/ADX 同步变化） | "
      f"重新评估，可提前减仓 |")
    A("| 逆势诱惑 | 小周期出现与大周期相反的强信号 | 只做短线，不重仓，严格止损 |")
    A("")

    A("---\n")
    A("> **方法说明**：方向由四项打分（道氏结构 / 均线排列 / ADX 趋势强度 / MACD 多空），"
      "≥+2 偏多、≤−2 偏空、其余中性。")
    A("> **大周期定方向、小周期找入场**是本框架的核心；周期冲突时小周期信号一律降权。")
    A("> 本分析仅描述已发生的价格结构，**不预测未来**。")

    with open(args.out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"✅ 多周期共振报告已写入 {args.out}")
    for p, st in states.items():
        print(f"   {TF_ZH.get(p, p):<4} {st['direction']}（{st['score']:+d}）")


if __name__ == "__main__":
    main()
