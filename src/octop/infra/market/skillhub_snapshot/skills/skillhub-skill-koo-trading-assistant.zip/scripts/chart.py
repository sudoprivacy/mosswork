#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
chart.py — 行情可视化

输入标准 CSV / JSON，输出 K 线图（含均线、成交量、MACD 副图、形态标注）。
遵循中国市场习惯：**涨红跌绿**。

用法：
    python chart.py --csv data.csv --symbol 600519 --name 贵州茅台 --out chart.png
    python chart.py --json bars.json --limit 120 --out chart.png

依赖：matplotlib（可选）。未安装时给出提示并优雅退出，不影响主分析流程。
"""
import argparse
import csv
import json
import os
import sys

# ---- 中文字体 ----
def _setup_font():
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import font_manager
    prefer = ["Microsoft YaHei", "SimHei", "Microsoft JhengHei", "SimSun",
              "Noto Sans CJK SC", "Source Han Sans SC"]
    avail = {f.name for f in font_manager.fontManager.ttflist}
    chosen = [f for f in prefer if f in avail]
    if chosen:
        matplotlib.rcParams["font.sans-serif"] = chosen + ["DejaVu Sans"]
    matplotlib.rcParams["axes.unicode_minus"] = False
    return chosen


# ---- 数据结构 ----
class Bars:
    def __init__(self, rows):
        self.t = [r["t"] for r in rows]
        self.o = [r["o"] for r in rows]
        self.h = [r["h"] for r in rows]
        self.l = [r["l"] for r in rows]
        self.c = [r["c"] for r in rows]
        self.v = [r["v"] for r in rows]
        self.n = len(rows)

    def tail(self, k):
        return Bars([{"t": self.t[i], "o": self.o[i], "h": self.h[i],
                      "l": self.l[i], "c": self.c[i], "v": self.v[i]}
                     for i in range(max(0, self.n - k), self.n)])


def load_csv(path):
    rows = []
    with open(path, encoding="utf-8-sig") as f:
        rd = csv.DictReader(f)
        for r in rd:
            k = {kk.strip().lower(): (vv or "").strip() for kk, vv in r.items()}
            d = k.get("date") or k.get("时间") or k.get("日期") or ""
            try:
                rows.append({"t": d, "o": float(k.get("open") or k.get("开盘")),
                             "h": float(k.get("high") or k.get("最高")),
                             "l": float(k.get("low") or k.get("最低")),
                             "c": float(k.get("close") or k.get("收盘")),
                             "v": float(k.get("volume") or k.get("成交量") or 0)})
            except (TypeError, ValueError):
                continue
    return rows


def load_json(path):
    d = json.load(open(path, encoding="utf-8"))
    return d.get("bars", d if isinstance(d, list) else [])


def main():
    ap = argparse.ArgumentParser(description="生成 K 线分析图（涨红跌绿）")
    ap.add_argument("--csv", default="")
    ap.add_argument("--json", default="")
    ap.add_argument("--symbol", default="")
    ap.add_argument("--name", default="")
    ap.add_argument("--limit", type=int, default=120, help="只画最近 N 根")
    ap.add_argument("--out", default="chart.png")
    args = ap.parse_args()

    try:
        chosen = _setup_font()
    except ImportError:
        print("[skip] 未安装 matplotlib，无法绘图。安装：pip install matplotlib",
              file=sys.stderr)
        return
    import matplotlib.pyplot as plt

    if args.csv:
        rows = load_csv(args.csv)
    elif args.json:
        rows = load_json(args.json)
    else:
        ap.error("需要 --csv 或 --json")

    if not rows:
        print("[error] 无有效数据", file=sys.stderr)
        sys.exit(1)

    b = Bars(rows[-args.limit:])

    # ---- 指标 ----
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import indicators as I
    ma5, ma10, ma20, ma60 = (I.sma(b.c, k) for k in (5, 10, 20, 60))
    macd = I.macd(b.c)
    dif = macd.get("DIF")
    dea = macd.get("DEA")
    hist = macd.get("HIST") if macd.get("HIST") is not None else macd.get("hist")
    vma5 = I.sma(b.v, 5)

    # ---- 形态 ----
    try:
        import patterns as P
        pats = P.scan_all(b.o, b.h, b.l, b.c, lookback=min(30, b.n))
        pats = [p for p in pats if p["idx"] >= b.n - args.limit]
    except Exception:
        pats = []

    x = list(range(b.n))

    fig = plt.figure(figsize=(14, 9.5), dpi=110)
    gs = fig.add_gridspec(3, 1, height_ratios=[3, 1, 1.1], hspace=0.10)
    ax = fig.add_subplot(gs[0])
    axv = fig.add_subplot(gs[1], sharex=ax)
    axm = fig.add_subplot(gs[2], sharex=ax)

    # ---- 主图：K 线 ----
    UP, DN = "#E4393C", "#00A843"      # 涨红跌绿
    for i in x:
        up = b.c[i] >= b.o[i]
        col = UP if up else DN
        ax.vlines(i, b.l[i], b.h[i], color=col, linewidth=0.75, zorder=2)
        lo, hi = min(b.o[i], b.c[i]), max(b.o[i], b.c[i])
        ax.bar(i, max(hi - lo, (max(b.h) - min(b.l)) * 0.0008), bottom=lo,
               width=0.62, color=col, edgecolor=col, linewidth=0.4, zorder=3)

    for arr, lab, col, w in [(ma5, "MA5", "#FF9800", 1.0), (ma10, "MA10", "#2196F3", 1.0),
                             (ma20, "MA20", "#9C27B0", 1.2), (ma60, "MA60", "#607D8B", 1.4)]:
        ax.plot(x, arr, label=lab, color=col, linewidth=w, zorder=4)

    # 形态标注（去重叠：同位置留最强，且相邻标注至少间隔 4 根）
    rank = {"强": 3, "中": 2, "弱": 1}
    best = {}
    for p in pats:
        i = p["idx"]
        if i not in best or rank.get(p.get("strength", "中"), 1) > rank.get(best[i].get("strength", "中"), 1):
            best[i] = p
    picked, used = [], []
    for p in sorted(best.values(), key=lambda z: -z["idx"]):
        if all(abs(p["idx"] - u) >= 4 for u in used):
            picked.append(p)
            used.append(p["idx"])
        if len(picked) >= 5:
            break
    for k, p in enumerate(picked):
        i = p["idx"]
        if i < 0 or i >= b.n:
            continue
        bull = p["direction"] == "看涨"
        col = UP if bull else DN
        span = max(b.h) - min(b.l)
        off = span * (0.05 + 0.055 * (k % 3))          # 错开高度，避免叠字
        yy = (b.l[i] - off) if bull else (b.h[i] + off)
        ax.annotate(p["name"], xy=(i, b.l[i] if bull else b.h[i]),
                    xytext=(i, yy), fontsize=8, color=col, ha="center",
                    arrowprops=dict(arrowstyle="->", color=col, lw=0.9, alpha=0.85),
                    bbox=dict(boxstyle="round,pad=0.2", fc="white", ec=col,
                              lw=0.5, alpha=0.85),
                    zorder=6)

    title = f"{args.name} {args.symbol}".strip() or "行情分析"
    ax.set_title(f"{title}   |   最近 {b.n} 根   |   区间 {b.t[0]} → {b.t[-1]}",
                 fontsize=13, fontweight="bold", pad=10)
    ax.legend(loc="upper left", fontsize=8.5, ncol=4, framealpha=0.85)
    ax.grid(alpha=0.18, linestyle="--", linewidth=0.6)
    ax.set_ylabel("价格", fontsize=10)
    plt.setp(ax.get_xticklabels(), visible=False)

    # ---- 成交量 ----
    for i in x:
        col = UP if b.c[i] >= b.o[i] else DN
        axv.bar(i, b.v[i], width=0.62, color=col, alpha=0.72, linewidth=0)
    axv.plot(x, vma5, color="#FF9800", linewidth=1.0, label="VMA5")
    axv.set_ylabel("成交量", fontsize=10)
    axv.legend(loc="upper left", fontsize=8)
    axv.grid(alpha=0.18, linestyle="--", linewidth=0.6)
    plt.setp(axv.get_xticklabels(), visible=False)

    # ---- MACD ----
    hcol = [UP if (v is not None and v >= 0) else DN for v in hist]
    axm.bar(x, [v if v is not None else 0 for v in hist], width=0.62,
            color=hcol, alpha=0.75, linewidth=0)
    axm.plot(x, [v if v is not None else float("nan") for v in dif],
             color="#2196F3", linewidth=1.1, label="DIF")
    axm.plot(x, [v if v is not None else float("nan") for v in dea],
             color="#FF9800", linewidth=1.1, label="DEA")
    axm.axhline(0, color="#888", linewidth=0.7, alpha=0.6)
    axm.set_ylabel("MACD", fontsize=10)
    axm.legend(loc="upper left", fontsize=8, ncol=2)
    axm.grid(alpha=0.18, linestyle="--", linewidth=0.6)

    # x 轴标签：稀疏
    step = max(1, b.n // 10)
    ticks = list(range(0, b.n, step))
    axm.set_xticks(ticks)
    axm.set_xticklabels([b.t[i] for i in ticks], rotation=40, ha="right", fontsize=8)

    foot = "涨=红 / 跌=绿（中国市场习惯）"
    if chosen:
        foot += f"   |   字体：{chosen[0]}"
    fig.text(0.99, 0.005, foot, ha="right", fontsize=7.5, color="#888")

    fig.savefig(args.out, bbox_inches="tight", facecolor="white")
    print(f"[OK] 图表已生成 → {args.out}（{b.n} 根，标注形态 {len(pats[:6])} 个）")


if __name__ == "__main__":
    main()
