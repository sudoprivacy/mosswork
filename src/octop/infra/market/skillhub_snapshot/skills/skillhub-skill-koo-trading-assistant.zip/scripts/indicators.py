# -*- coding: utf-8 -*-
"""
indicators.py —— 技术指标计算库（纯 numpy 实现，无 TA-Lib 依赖）

统一约定：
- 输入均为 list[float]，按时间正序（旧 -> 新）
- 输出 list[float]，长度与输入一致，前置无效值用 None
- high/low/close/open 分开传入

所有指标口径采用国内行情软件（通达信/同花顺）的常见默认参数，
确保与用户看盘软件的结果可比。
"""
from __future__ import annotations

from typing import List, Optional, Sequence

Num = Optional[float]


# ----------------------------------------------------------------------------
# 基础工具
# ----------------------------------------------------------------------------
def _none_list(n: int) -> List[Num]:
    return [None] * n


def sma(values: Sequence[float], period: int) -> List[Num]:
    """简单移动平均"""
    n = len(values)
    out: List[Num] = _none_list(n)
    if period <= 0 or n < period:
        return out
    s = 0.0
    for i, v in enumerate(values):
        s += v
        if i >= period:
            s -= values[i - period]
        if i >= period - 1:
            out[i] = s / period
    return out


def ema(values: Sequence[float], period: int) -> List[Num]:
    """指数移动平均。用前 period 个值的 SMA 作为种子。"""
    n = len(values)
    out: List[Num] = _none_list(n)
    if period <= 0 or n < period:
        return out
    k = 2.0 / (period + 1)
    seed = sum(values[:period]) / period
    out[period - 1] = seed
    prev = seed
    for i in range(period, n):
        prev = values[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def wilder_ema(values: Sequence[float], period: int) -> List[Num]:
    """Wilder 平滑（RSI/ATR/ADX 使用）。alpha = 1/period"""
    n = len(values)
    out: List[Num] = _none_list(n)
    if period <= 0 or n < period:
        return out
    seed = sum(values[:period]) / period
    out[period - 1] = seed
    prev = seed
    for i in range(period, n):
        prev = (prev * (period - 1) + values[i]) / period
        out[i] = prev
    return out


def stdev(values: Sequence[float], period: int) -> List[Num]:
    """滚动总体标准差"""
    n = len(values)
    out: List[Num] = _none_list(n)
    if period <= 0 or n < period:
        return out
    for i in range(period - 1, n):
        win = values[i - period + 1: i + 1]
        m = sum(win) / period
        var = sum((x - m) ** 2 for x in win) / period
        out[i] = var ** 0.5
    return out


def highest(values: Sequence[float], period: int) -> List[Num]:
    n = len(values)
    out: List[Num] = _none_list(n)
    for i in range(n):
        if i >= period - 1:
            out[i] = max(values[i - period + 1: i + 1])
    return out


def lowest(values: Sequence[float], period: int) -> List[Num]:
    n = len(values)
    out: List[Num] = _none_list(n)
    for i in range(n):
        if i >= period - 1:
            out[i] = min(values[i - period + 1: i + 1])
    return out


# ----------------------------------------------------------------------------
# 均线体系
# ----------------------------------------------------------------------------
def ma_system(close: Sequence[float], periods=(5, 10, 20, 30, 60, 120, 250)) -> dict:
    return {f"MA{p}": sma(close, p) for p in periods}


def ma_alignment(close: Sequence[float], periods=(5, 10, 20, 60)) -> dict:
    """
    判断均线排列状态（多头/空头/纠缠）。
    只看最后一根，返回状态字符串与说明。
    """
    vals = {}
    for p in periods:
        v = sma(close, p)[-1]
        if v is not None:
            vals[f"MA{p}"] = v
    keys = sorted(vals.keys(), key=lambda x: int(x[2:]))
    if len(keys) < 3:
        return {"state": "数据不足", "ordered": False, "values": vals}
    seq = [vals[k] for k in keys]
    bull = all(seq[i] > seq[i + 1] for i in range(len(seq) - 1))
    bear = all(seq[i] < seq[i + 1] for i in range(len(seq) - 1))
    spread = (max(seq) - min(seq)) / (sum(seq) / len(seq))
    if bull:
        state = "多头排列"
    elif bear:
        state = "空头排列"
    elif spread < 0.02:
        state = "均线纠缠（趋势不明）"
    else:
        state = "均线交错（趋势转换中）"
    return {"state": state, "ordered": bull or bear, "spread": round(spread, 4), "values": {k: round(v, 4) for k, v in vals.items()}}


# ----------------------------------------------------------------------------
# MACD
# ----------------------------------------------------------------------------
def macd(close: Sequence[float], fast=12, slow=26, signal=9) -> dict:
    """返回 DIF / DEA / MACD柱（柱 = 2*(DIF-DEA)，国内软件口径）"""
    ef = ema(close, fast)
    es = ema(close, slow)
    n = len(close)
    dif: List[Num] = _none_list(n)
    for i in range(n):
        if ef[i] is not None and es[i] is not None:
            dif[i] = ef[i] - es[i]
    valid = [x for x in dif if x is not None]
    start = dif.index(valid[0]) if valid else 0
    dea: List[Num] = _none_list(n)
    if valid:
        dea_part = ema(valid, signal)
        for j, v in enumerate(dea_part):
            dea[start + j] = v
    hist: List[Num] = _none_list(n)
    for i in range(n):
        if dif[i] is not None and dea[i] is not None:
            hist[i] = 2 * (dif[i] - dea[i])
    return {"DIF": dif, "DEA": dea, "HIST": hist}


def macd_cross(m: dict) -> dict:
    """判断最后一根是否发生金叉/死叉，并区分零轴上/下"""
    dif, dea = m["DIF"], m["DEA"]
    n = len(dif)
    if n < 2 or dif[-1] is None or dea[-1] is None or dif[-2] is None or dea[-2] is None:
        return {"cross": "数据不足"}
    prev = dif[-2] - dea[-2]
    cur = dif[-1] - dea[-1]
    zero_above = dif[-1] > 0
    res = {"DIF": round(dif[-1], 4), "DEA": round(dea[-1], 4),
           "zero_axis": "零轴上" if zero_above else "零轴下",
           "hist": round(m["HIST"][-1], 4) if m["HIST"][-1] is not None else None}
    if prev <= 0 < cur:
        res["cross"] = "金叉"
        res["meaning"] = ("零轴上金叉：强势中继，趋势延续信号，可靠性高于零轴下金叉"
                          if zero_above else
                          "零轴下金叉：弱势反弹信号，需成交量与均线配合，易反复")
    elif prev >= 0 > cur:
        res["cross"] = "死叉"
        res["meaning"] = ("零轴上死叉：强势中回调，多为洗盘，观察是否守住关键均线"
                          if zero_above else
                          "零轴下死叉：弱势续跌信号，反弹结束概率大")
    else:
        res["cross"] = "无"
        res["meaning"] = "当前无交叉"
    return res


# ----------------------------------------------------------------------------
# RSI
# ----------------------------------------------------------------------------
def rsi(close: Sequence[float], period=14) -> List[Num]:
    n = len(close)
    out: List[Num] = _none_list(n)
    if n < period + 1:
        return out
    gains, losses = [], []
    for i in range(1, n):
        ch = close[i] - close[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    ag = wilder_ema(gains, period)
    al = wilder_ema(losses, period)
    for j in range(len(ag)):
        if ag[j] is None or al[j] is None:
            continue
        idx = j + 1
        if al[j] == 0:
            out[idx] = 100.0
        else:
            rs = ag[j] / al[j]
            out[idx] = 100 - 100 / (1 + rs)
    return out


# ----------------------------------------------------------------------------
# KDJ
# ----------------------------------------------------------------------------
def kdj(high, low, close, n=9, m1=3, m2=3) -> dict:
    length = len(close)
    rsv: List[Num] = _none_list(length)
    for i in range(length):
        if i >= n - 1:
            hh = max(high[i - n + 1: i + 1])
            ll = min(low[i - n + 1: i + 1])
            rsv[i] = 50.0 if hh == ll else (close[i] - ll) / (hh - ll) * 100
    k: List[Num] = _none_list(length)
    d: List[Num] = _none_list(length)
    j: List[Num] = _none_list(length)
    pk, pd = 50.0, 50.0
    for i in range(length):
        if rsv[i] is None:
            continue
        pk = (m1 - 1) / m1 * pk + 1 / m1 * rsv[i]
        pd = (m2 - 1) / m2 * pd + 1 / m2 * pk
        k[i], d[i], j[i] = pk, pd, 3 * pk - 2 * pd
    return {"K": k, "D": d, "J": j}


# ----------------------------------------------------------------------------
# 布林带
# ----------------------------------------------------------------------------
def boll(close: Sequence[float], period=20, k=2.0) -> dict:
    mid = sma(close, period)
    sd = stdev(close, period)
    up: List[Num] = _none_list(len(close))
    dn: List[Num] = _none_list(len(close))
    for i in range(len(close)):
        if mid[i] is not None and sd[i] is not None:
            up[i] = mid[i] + k * sd[i]
            dn[i] = mid[i] - k * sd[i]
    return {"MID": mid, "UP": up, "DN": dn}


def boll_state(close, b: dict) -> dict:
    if b["UP"][-1] is None:
        return {"state": "数据不足"}
    up, mid, dn = b["UP"][-1], b["MID"][-1], b["DN"][-1]
    c = close[-1]
    width = (up - dn) / mid
    if c > up:
        pos, desc = "突破上轨", "强势/超买，趋势加速或短期过热"
    elif c < dn:
        pos, desc = "跌破下轨", "弱势/超卖，趋势加速下跌或短期超跌"
    else:
        pct = (c - dn) / (up - dn) if up != dn else 0.5
        pos = f"通道内({pct:.0%})"
        desc = "运行于通道内"
    return {"state": pos, "desc": desc, "UP": round(up, 4), "MID": round(mid, 4),
            "DN": round(dn, 4), "bandwidth": round(width, 4),
            "squeeze": width < 0.10}


# ----------------------------------------------------------------------------
# ATR / 波动
# ----------------------------------------------------------------------------
def true_range(high, low, close) -> List[float]:
    n = len(close)
    tr = []
    for i in range(n):
        if i == 0:
            tr.append(high[i] - low[i])
        else:
            tr.append(max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1])))
    return tr


def atr(high, low, close, period=14) -> List[Num]:
    return wilder_ema(true_range(high, low, close), period)


def atr_stop(close, high, low, direction="long", period=14, mult=2.0) -> dict:
    """
    按 ATR 计算止损位（书中"最保险的是根据 ATR 止损"）
    """
    a = atr(high, low, close, period)[-1]
    if a is None:
        return {"error": "数据不足"}
    c = close[-1]
    if direction == "long":
        stop = c - mult * a
    else:
        stop = c + mult * a
    return {"ATR": round(a, 4), "ATR%": round(a / c * 100, 2),
            "mult": mult, "current": round(c, 4), "stop": round(stop, 4),
            "risk_pct": round(abs(c - stop) / c * 100, 2)}


# ----------------------------------------------------------------------------
# 成交量
# ----------------------------------------------------------------------------
def volume_ma(volume: Sequence[float], period=5) -> List[Num]:
    return sma(volume, period)


def volume_ratio(volume: Sequence[float], period=5) -> List[Num]:
    """量比：当日量 / 前 period 日均量"""
    n = len(volume)
    out: List[Num] = _none_list(n)
    for i in range(n):
        if i >= period:
            base = sum(volume[i - period:i]) / period
            out[i] = volume[i] / base if base > 0 else None
    return out


def obv(close, volume) -> List[float]:
    n = len(close)
    out = [0.0] * n
    for i in range(1, n):
        if close[i] > close[i - 1]:
            out[i] = out[i - 1] + volume[i]
        elif close[i] < close[i - 1]:
            out[i] = out[i - 1] - volume[i]
        else:
            out[i] = out[i - 1]
    return out


def mfi(high, low, close, volume, period=14) -> List[Num]:
    """资金流量指标（量价结合的 RSI 变体）"""
    n = len(close)
    out: List[Num] = _none_list(n)
    tp = [(high[i] + low[i] + close[i]) / 3 for i in range(n)]
    pos, neg = [], []
    for i in range(n):
        if i == 0:
            pos.append(0.0); neg.append(0.0); continue
        mf = tp[i] * volume[i]
        if tp[i] > tp[i - 1]:
            pos.append(mf); neg.append(0.0)
        elif tp[i] < tp[i - 1]:
            pos.append(0.0); neg.append(mf)
        else:
            pos.append(0.0); neg.append(0.0)
    for i in range(period, n):
        p = sum(pos[i - period + 1:i + 1])
        ng = sum(neg[i - period + 1:i + 1])
        if ng == 0:
            out[i] = 100.0
        else:
            out[i] = 100 - 100 / (1 + p / ng)
    return out


# ----------------------------------------------------------------------------
# 趋势强度
# ----------------------------------------------------------------------------
def adx(high, low, close, period=14) -> dict:
    n = len(close)
    plus_dm, minus_dm, tr = [], [], []
    for i in range(n):
        if i == 0:
            plus_dm.append(0.0); minus_dm.append(0.0)
            tr.append(high[i] - low[i]); continue
        up = high[i] - high[i - 1]
        dn = low[i - 1] - low[i]
        plus_dm.append(up if (up > dn and up > 0) else 0.0)
        minus_dm.append(dn if (dn > up and dn > 0) else 0.0)
        tr.append(max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1])))
    atr_s = wilder_ema(tr, period)
    p_s = wilder_ema(plus_dm, period)
    m_s = wilder_ema(minus_dm, period)
    pdi: List[Num] = _none_list(n)
    mdi: List[Num] = _none_list(n)
    dx: List[Num] = _none_list(n)
    for i in range(n):
        if atr_s[i] and p_s[i] is not None and m_s[i] is not None:
            pdi[i] = 100 * p_s[i] / atr_s[i] if atr_s[i] else 0
            mdi[i] = 100 * m_s[i] / atr_s[i] if atr_s[i] else 0
            s = pdi[i] + mdi[i]
            dx[i] = 100 * abs(pdi[i] - mdi[i]) / s if s else 0
    valid = [x for x in dx if x is not None]
    adx_line: List[Num] = _none_list(n)
    if valid:
        start = dx.index(valid[0])
        part = wilder_ema(valid, period)
        for j, v in enumerate(part):
            adx_line[start + j] = v
    return {"ADX": adx_line, "PDI": pdi, "MDI": mdi}


def trend_strength(high, low, close) -> dict:
    a = adx(high, low, close)
    if a["ADX"][-1] is None:
        return {"state": "数据不足"}
    adx_v = a["ADX"][-1]
    pdi, mdi = a["PDI"][-1], a["MDI"][-1]
    if adx_v >= 25:
        state = "趋势明确"
    elif adx_v >= 20:
        state = "趋势初成"
    else:
        state = "无趋势/震荡"
    direction = "多头主导" if pdi > mdi else "空头主导"
    return {"ADX": round(adx_v, 2), "PDI": round(pdi, 2), "MDI": round(mdi, 2),
            "state": state, "direction": direction}


def cci(high, low, close, period=14) -> List[Num]:
    n = len(close)
    tp = [(high[i] + low[i] + close[i]) / 3 for i in range(n)]
    ma = sma(tp, period)
    out: List[Num] = _none_list(n)
    for i in range(n):
        if ma[i] is None:
            continue
        win = tp[i - period + 1: i + 1]
        md = sum(abs(x - ma[i]) for x in win) / period
        out[i] = 0.0 if md == 0 else (tp[i] - ma[i]) / (0.015 * md)
    return out


__all__ = [
    "sma", "ema", "wilder_ema", "stdev", "highest", "lowest",
    "ma_system", "ma_alignment", "macd", "macd_cross", "rsi", "kdj", "boll",
    "boll_state", "true_range", "atr", "atr_stop", "volume_ma", "volume_ratio",
    "obv", "mfi", "adx", "trend_strength", "cci",
]
