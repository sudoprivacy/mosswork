# -*- coding: utf-8 -*-
"""
patterns.py —— K 线形态 / 结构 / 背离 识别

设计原则：
1. 只做"可量化、可复现"的判定，主观形态（如圆弧顶）用近似算法并明确标注。
2. 判定必须结合**趋势位置**（同一个蜡烛图形在涨势与跌势中含义相反）。
3. 输出统一的 Detection 结构，便于上层聚合成报告。

依赖：仅标准库 + indicators（可选）
"""
from __future__ import annotations

from typing import List, Dict, Optional, Sequence

O = Sequence[float]  # open
H = Sequence[float]  # high
L = Sequence[float]  # low
C = Sequence[float]  # close


# ----------------------------------------------------------------------------
# 蜡烛解剖
# ----------------------------------------------------------------------------
class Candles:
    """把 OHLC 序列预先算成解剖特征，避免重复计算"""

    def __init__(self, o: O, h: H, l: L, c: C):
        self.o, self.h, self.l, self.c = list(o), list(h), list(l), list(c)
        self.n = len(c)
        rng = [max(self.h[i] - self.l[i], 1e-9) for i in range(self.n)]
        self.range = rng
        self.body = [abs(self.c[i] - self.o[i]) for i in range(self.n)]
        self.body_r = [self.body[i] / rng[i] for i in range(self.n)]        # 实体占全幅比
        self.up_sh = [self.h[i] - max(self.o[i], self.c[i]) for i in range(self.n)]
        self.dn_sh = [min(self.o[i], self.c[i]) - self.l[i] for i in range(self.n)]
        self.up_r = [self.up_sh[i] / rng[i] for i in range(self.n)]
        self.dn_r = [self.dn_sh[i] / rng[i] for i in range(self.n)]
        self.bull = [self.c[i] > self.o[i] for i in range(self.n)]
        self.bear = [self.c[i] < self.o[i] for i in range(self.n)]
        # 平均实体（用于判断"大实体"）
        self.avg_body = sum(self.body) / self.n if self.n else 0.0

    def is_long(self, i: int, mult: float = 1.6) -> bool:
        return self.body[i] >= self.avg_body * mult

    def is_doji(self, i: int, thr: float = 0.1) -> bool:
        return self.body_r[i] <= thr

    def is_marubozu(self, i: int, thr: float = 0.06) -> bool:
        return self.body_r[i] >= (1 - thr * 2)


# ----------------------------------------------------------------------------
# 趋势位置（判定形态含义的前提）
# ----------------------------------------------------------------------------
def trend_at(close: Sequence[float], i: int, lookback: int = 10) -> str:
    """返回 i 位置之前的短期趋势：up / down / flat"""
    if i < lookback:
        return "flat"
    seg = close[i - lookback: i + 1]
    first, last = seg[0], seg[-1]
    hi, lo = max(seg), min(seg)
    if hi == lo:
        return "flat"
    pos = (last - lo) / (hi - lo)
    if pos > 0.65:
        return "up"
    if pos < 0.35:
        return "down"
    return "flat"


def swing_points(high: Sequence[float], low: Sequence[float], left: int = 3, right: int = 3):
    """分型法找摆动高低点（缠论/道氏通用做法）"""
    sh, sl = [], []
    n = len(high)
    for i in range(left, n - right):
        if high[i] == max(high[i - left: i + right + 1]):
            sh.append(i)
        if low[i] == min(low[i - left: i + right + 1]):
            sl.append(i)
    return sh, sl


def market_structure(high, low, close, left=3, right=3) -> dict:
    """
    用最近 3 个摆动高点 + 3 个摆动低点判断结构：
    HH/HL = 上升结构；LH/LL = 下降结构；其余为震荡
    """
    sh, sl = swing_points(high, low, left, right)
    if len(sh) < 3 or len(sl) < 3:
        return {"structure": "数据不足", "highs": sh, "lows": sl}
    H3 = [high[i] for i in sh[-3:]]
    L3 = [low[i] for i in sl[-3:]]
    hh = H3[2] > H3[1] > H3[0]
    lh = H3[2] < H3[1] < H3[0]
    hl = L3[2] > L3[1] > L3[0]
    ll = L3[2] < L3[1] < L3[0]
    if hh and hl:
        s = "上升结构（高点抬高 + 低点抬高）"
    elif lh and ll:
        s = "下降结构（高点降低 + 低点降低）"
    elif hh and ll:
        s = "扩张结构（高点抬高、低点降低，波动放大）"
    elif lh and hl:
        s = "收敛结构（高点降低、低点抬高，三角形整理）"
    else:
        s = "震荡结构（方向不明）"
    return {"structure": s,
            "last_highs": [round(H3[i], 4) for i in range(3)],
            "last_lows": [round(L3[i], 4) for i in range(3)],
            "swing_high_idx": sh[-3:], "swing_low_idx": sl[-3:]}


# ----------------------------------------------------------------------------
# 支撑阻力（摆动点聚类）
# ----------------------------------------------------------------------------
def support_resistance(high, low, close, left=3, right=3, tol=0.015, top=6) -> dict:
    """
    把摆动高低点按价格接近度聚类成支撑/阻力带
    tol: 相对价格容差（默认 1.5%）
    """
    sh, sl = swing_points(high, low, left, right)
    pts = [(high[i], "R") for i in sh] + [(low[i], "S") for i in sl]
    if not pts:
        return {"resistance": [], "support": []}
    pts.sort(key=lambda x: x[0])
    clusters, cur = [], [pts[0]]
    for p in pts[1:]:
        if abs(p[0] - cur[-1][0]) / max(cur[-1][0], 1e-9) <= tol:
            cur.append(p)
        else:
            clusters.append(cur); cur = [p]
    clusters.append(cur)
    c_now = close[-1]
    levels = []
    for cl in clusters:
        price = sum(p[0] for p in cl) / len(cl)
        levels.append({"price": round(price, 4), "touches": len(cl),
                       "kind": "阻力" if price > c_now else "支撑"})
    levels.sort(key=lambda x: -x["touches"])
    levels = levels[:top]
    levels.sort(key=lambda x: x["price"])
    return {"resistance": [x for x in levels if x["kind"] == "阻力"],
            "support": [x for x in levels if x["kind"] == "支撑"],
            "current": round(c_now, 4)}


# ----------------------------------------------------------------------------
# 跳空缺口
# ----------------------------------------------------------------------------
def gaps(high, low, close, min_pct=0.005) -> List[dict]:
    """识别向上/向下跳空缺口（未回补）"""
    out = []
    n = len(close)
    for i in range(1, n):
        # 向上跳空：今日 low > 昨日 high
        if low[i] > high[i - 1]:
            pct = (low[i] - high[i - 1]) / high[i - 1]
            if pct >= min_pct:
                filled = any(low[j] <= high[i - 1] for j in range(i + 1, n))
                out.append({"idx": i, "type": "向上跳空", "lower": round(high[i - 1], 4),
                            "upper": round(low[i], 4), "pct": round(pct * 100, 2),
                            "filled": filled})
        # 向下跳空：今日 high < 昨日 low
        elif high[i] < low[i - 1]:
            pct = (low[i - 1] - high[i]) / low[i - 1]
            if pct >= min_pct:
                filled = any(high[j] >= low[i - 1] for j in range(i + 1, n))
                out.append({"idx": i, "type": "向下跳空", "lower": round(high[i], 4),
                            "upper": round(low[i - 1], 4), "pct": round(pct * 100, 2),
                            "filled": filled})
    return out[-6:]


def gap_classify(gap: dict, close: Sequence[float], i: int) -> str:
    """按位置给缺口定性（普通/突破/中继/衰竭）——近似判定"""
    n = len(close)
    if n < 60:
        return "缺口"
    seg = close[max(0, i - 60):i + 1]
    hi, lo = max(seg), min(seg)
    pos = (close[i] - lo) / (hi - lo) if hi > lo else 0.5
    if pos < 0.15 or pos > 0.85:
        return "衰竭缺口（趋势末端，易回补）"
    if pos < 0.35 or pos > 0.65:
        return "中继缺口（趋势中段，量度升幅参考）"
    return "普通缺口（震荡区间内，多数会回补）"


# ----------------------------------------------------------------------------
# 单根蜡烛形态
# ----------------------------------------------------------------------------
def _pat(i, name, direction, note, strength="中") -> dict:
    return {"idx": i, "name": name, "direction": direction,
            "note": note, "strength": strength}


def detect_single(cd: Candles, lookback: int = 60) -> List[dict]:
    out = []
    start = max(1, cd.n - lookback)
    for i in range(start, cd.n):
        t = trend_at(cd.c, i)
        # --- 锤子线 / 上吊线 ---
        long_dn = cd.dn_sh[i] >= 2 * cd.body[i] and cd.up_r[i] <= 0.15 and cd.body_r[i] < 0.4
        if long_dn:
            if t == "down":
                out.append(_pat(i, "锤子线", "看涨",
                                "下跌后出现长下影小实体，抛压被承接，需次日阳线确认", "中"))
            elif t == "up":
                out.append(_pat(i, "上吊线", "看跌",
                                "上涨后出现长下影小实体，高位买盘衰竭（即'吊颈线'），需次日收盘低于实体确认", "中"))
        # --- 流星线 / 倒锤子 ---
        long_up = cd.up_sh[i] >= 2 * cd.body[i] and cd.dn_r[i] <= 0.15 and cd.body_r[i] < 0.4
        if long_up:
            if t == "up":
                out.append(_pat(i, "流星线", "看跌",
                                "上涨后出现长上影小实体，上方抛压沉重", "中"))
            elif t == "down":
                out.append(_pat(i, "倒锤子线", "看涨",
                                "下跌后出现长上影小实体，下方开始有承接，需次日确认", "弱"))
        # --- 十字线族 ---
        if cd.is_doji(i):
            if cd.up_r[i] <= 0.12 and cd.dn_r[i] >= 0.6:
                out.append(_pat(i, "蜻蜓十字（T字线）", "看涨" if t == "down" else "中性",
                                "下影极长、几无实体，下方支撑强；高位出现则警惕"))
            elif cd.dn_r[i] <= 0.12 and cd.up_r[i] >= 0.6:
                out.append(_pat(i, "墓碑十字", "看跌",
                                "上影极长、几无实体，冲高被砸回，顶部警示"))
            else:
                out.append(_pat(i, "十字线", "中性",
                                "多空力量均衡，趋势可能停顿或反转，需下一根K线定向", "弱"))
        # --- 大实体 / 光头光脚 ---
        if cd.is_long(i, 1.8) and cd.is_marubozu(i):
            if cd.bull[i]:
                out.append(_pat(i, "光头光脚大阳线", "看涨",
                                "多方完全掌控，趋势延续信号", "强"))
            else:
                out.append(_pat(i, "光头光脚大阴线", "看跌",
                                "空方完全掌控，趋势延续信号", "强"))
    return out


# ----------------------------------------------------------------------------
# 双根蜡烛形态
# ----------------------------------------------------------------------------
def detect_double(cd: Candles, lookback: int = 60) -> List[dict]:
    out = []
    start = max(2, cd.n - lookback)
    for i in range(start, cd.n):
        p, c = i - 1, i
        t = trend_at(cd.c, p)
        pb, cb = cd.body[p], cd.body[c]
        if pb < 1e-9:
            continue
        mid_p = (cd.o[p] + cd.c[p]) / 2
        # 吞没
        if cd.bear[p] and cd.bull[c] and cd.c[c] >= cd.o[p] and cd.o[c] <= cd.c[p] and cb > pb:
            out.append(_pat(i, "看涨吞没", "看涨",
                            f"阳线实体完全包住前阴线（{'跌势后' if t=='down' else '趋势中'}），反转力度{'强' if t=='down' else '中'}", "强"))
        if cd.bull[p] and cd.bear[c] and cd.o[c] >= cd.c[p] and cd.c[c] <= cd.o[p] and cb > pb:
            out.append(_pat(i, "看跌吞没", "看跌",
                            f"阴线实体完全包住前阳线（{'涨势后' if t=='up' else '趋势中'}），反转力度{'强' if t=='up' else '中'}", "强"))
        # 乌云盖顶
        if cd.bull[p] and cd.bear[c] and cd.h[c] > cd.h[p] and cd.c[c] < mid_p and cd.c[c] > cd.o[p]:
            out.append(_pat(i, "乌云盖顶", "看跌",
                            "高开阴线深入前阳线实体中点以下（越深越弱），顶部反转信号", "强"))
        # 刺透
        if cd.bear[p] and cd.bull[c] and cd.l[c] < cd.l[p] and cd.c[c] > mid_p and cd.c[c] < cd.o[p]:
            out.append(_pat(i, "刺透形态", "看涨",
                            "低开阳线刺入前阴线实体中点以上，底部反转信号", "强"))
        # 孕线
        if pb > 0 and cd.body[c] < pb * 0.6 and cd.h[c] < cd.h[p] and cd.l[c] > cd.l[p]:
            d = "看涨孕线（涨势中为'高位孕线'，警惕滞涨）" if cd.bear[p] else "看跌孕线（跌势中为'低位孕线'，跌势趋缓）"
            out.append(_pat(i, "孕线", "中性偏反转",
                            f"小实体被前大实体包含，动量衰减；{d}", "中"))
        # 平头顶 / 平头底（要求近乎精确相等，否则会在高波动K线上误报）
        if abs(cd.h[c] - cd.h[p]) / max(cd.h[p], 1e-9) <= 0.001 and cd.body_r[c] > 0.2:
            out.append(_pat(i, "平头顶部", "看跌",
                            "两根K线最高价几乎一致，同一位置两次受阻", "中"))
        if abs(cd.l[c] - cd.l[p]) / max(cd.l[p], 1e-9) <= 0.001 and cd.body_r[c] > 0.2:
            out.append(_pat(i, "平头底部", "看涨",
                            "两根K线最低价几乎一致，同一位置两次获得支撑", "中"))
        # 双飞乌鸦（图中形态）：上涨中，第一根阳线后连续两根阴线，第二根阴线包裹第一根
        if i >= 2:
            if (cd.bull[i - 2] and cd.bear[i - 1] and cd.bear[i]
                    and cd.c[i] < cd.o[i - 1] and cd.o[i] > cd.c[i - 1]
                    and trend_at(cd.c, i - 2) == "up"):
                out.append(_pat(i, "双飞乌鸦", "看跌",
                                "上涨中阳线后连出两根阴线，第二根包裹第一根，顶部反转", "强"))
    return out


# ----------------------------------------------------------------------------
# 三根及以上形态
# ----------------------------------------------------------------------------
def detect_triple(cd: Candles, lookback: int = 60) -> List[dict]:
    out = []
    start = max(3, cd.n - lookback)
    for i in range(start, cd.n):
        a, b, c = i - 2, i - 1, i
        t = trend_at(cd.c, a)
        b1, b2, b3 = cd.body[a], cd.body[b], cd.body[c]
        # 启明星 / 黄昏星
        if (cd.bear[a] and b1 > cd.avg_body * 1.0 and b2 <= b1 * 0.5
                and cd.bull[c] and b3 > b1 * 0.6 and cd.c[c] > (cd.o[a] + cd.c[a]) / 2):
            out.append(_pat(i, "启明星（晨星）", "看涨",
                            "下跌→小实体星线→放量阳线收复首根阴线过半，底部反转", "强"))
        if (cd.bull[a] and b1 > cd.avg_body * 1.0 and b2 <= b1 * 0.5
                and cd.bear[c] and b3 > b1 * 0.6 and cd.c[c] < (cd.o[a] + cd.c[a]) / 2):
            out.append(_pat(i, "黄昏之星（晚星）", "看跌",
                            "上涨→小实体星线→阴线跌破首根阳线过半，顶部反转（图'黄昏之星'）", "强"))
        # 红三兵 / 三只乌鸦
        if cd.bull[a] and cd.bull[b] and cd.bull[c]:
            if cd.c[a] < cd.c[b] < cd.c[c] and cd.o[a] < cd.o[b] < cd.o[c]:
                out.append(_pat(i, "红三兵（前进三兵）", "看涨",
                                "连续三根阳线、收盘逐级抬高，稳步上攻", "强"))
        if cd.bear[a] and cd.bear[b] and cd.bear[c]:
            if cd.c[a] > cd.c[b] > cd.c[c] and cd.o[a] > cd.o[b] > cd.o[c]:
                out.append(_pat(i, "三只乌鸦", "看跌",
                                "连续三根阴线、收盘逐级走低，空头持续压制（图'三只乌鸦'）", "强"))
        # 高档五阴线
        if t == "up" and all(cd.bear[j] for j in [b, c]) and cd.bull[a]:
            if cd.body[c] < cd.body[a] and cd.c[c] < cd.o[a]:
                out.append(_pat(i, "高档五阴线（雏形）", "看跌",
                                "上涨后出现小阴线并排、跌破前期阳线，高位滞涨（图中形态，完整需5根左右小阴线）", "中"))
    return out


# ----------------------------------------------------------------------------
# 塔形顶 / 圆顶（近似算法，明确标注为近似）
# ----------------------------------------------------------------------------
def detect_rounded_top(high, low, close, window: int = 20) -> List[dict]:
    """
    近似识别圆顶/圆弧顶：在 window 内价格先上后下、顶点居中、且波动逐步收敛
    """
    out = []
    n = len(close)
    if n < window:
        return out
    seg = list(range(n - window, n))
    h = [high[i] for i in seg]
    peak = h.index(max(h))
    if 0.25 * window <= peak <= 0.75 * window:
        left_up = h[0] < h[peak]
        right_dn = h[-1] < h[peak]
        mid = sum(h[peak - 3:peak + 4]) / 7 if 3 < peak < window - 3 else h[peak]
        if left_up and right_dn and mid >= max(h) * 0.995 and close[-1] < mid * 0.98:
            out.append(_pat(n - 1, "圆顶（圆弧顶，近似识别）", "看跌",
                            f"最近{window}根内价格形成顶部圆弧并跌破颈线，属于缓慢派发结构", "中"))
    # 塔形顶：快速上涨后高位横盘再快速下跌
    if n >= 3 * window // 2:
        up_seg = close[-window:]
        if (max(up_seg) > min(up_seg) * 1.05
                and close[-1] < max(up_seg) * 0.97
                and max(close[-window // 2:]) < max(close[-window:-window // 2])):
            out.append(_pat(n - 1, "塔形顶（近似识别）", "看跌",
                            "先长阳快涨、随后高位滞涨、再连续阴线回落，形成塔形结构", "中"))
    return out


# ----------------------------------------------------------------------------
# 背离（MACD / RSI）—— 对应"背离短线交易"战法
# ----------------------------------------------------------------------------
def detect_divergence(high, low, close, indicator: Sequence[Optional[float]],
                      kind: str = "MACD", left=3, right=3, lookback=120,
                      min_rsi_gap: float = 2.0, min_rel_gap: float = 0.05) -> List[dict]:
    """
    顶背离：价格创更高高点，指标未创更高高点
    底背离：价格创更低低点，指标未创更低低点

    过滤器（避免"假背离"）：
    - 指标处于饱和区（RSI>95 / RSI<5）时不判背离，因为数字已被"顶死"
    - 指标两次读数差必须达到最小幅度（RSI 默认 2 点；MACD 默认相对 5%）
    """
    out = []
    n = len(close)

    def _meaningful(v1, v2) -> bool:
        if v1 is None or v2 is None:
            return False
        # 饱和区过滤
        if kind.upper().startswith("RSI") and (v1 > 95 or v1 < 5 or v2 > 95 or v2 < 5):
            return False
        diff = abs(v2 - v1)
        if kind.upper().startswith("RSI"):
            return diff >= min_rsi_gap
        base = max(abs(v1), abs(v2), 1e-9)
        return diff / base >= min_rel_gap

    sh, sl = swing_points(high, low, left, right)
    hi_idx = [i for i in sh if indicator[i] is not None and i >= n - lookback]
    lo_idx = [i for i in sl if indicator[i] is not None and i >= n - lookback]

    # 顶背离
    for k in range(1, len(hi_idx)):
        i1, i2 = hi_idx[k - 1], hi_idx[k]
        if (high[i2] > high[i1] and indicator[i2] < indicator[i1]
                and _meaningful(indicator[i1], indicator[i2])):
            out.append({"idx": i2, "name": f"{kind}顶背离", "direction": "看跌",
                        "note": f"价格高点抬高（{high[i1]:.4f}→{high[i2]:.4f}）但{kind}走低"
                                f"（{indicator[i1]:.4f}→{indicator[i2]:.4f}），上涨动能衰竭",
                        "strength": "强" if i2 == n - 1 else "中",
                        "from": i1, "to": i2})
    # 底背离
    for k in range(1, len(lo_idx)):
        i1, i2 = lo_idx[k - 1], lo_idx[k]
        if (low[i2] < low[i1] and indicator[i2] > indicator[i1]
                and _meaningful(indicator[i1], indicator[i2])):
            out.append({"idx": i2, "name": f"{kind}底背离", "direction": "看涨",
                        "note": f"价格低点降低（{low[i1]:.4f}→{low[i2]:.4f}）但{kind}抬高"
                                f"（{indicator[i1]:.4f}→{indicator[i2]:.4f}），下跌动能衰竭",
                        "strength": "强" if i2 == n - 1 else "中",
                        "from": i1, "to": i2})
    # 同类型的连续背离本质上是"同一个背离在延续"，
    # 因此每类只保留最近一次，避免证据天平被重复计数。
    best = {}
    for d in out:
        best[d["name"]] = d          # 后写入的 idx 更大 = 更近
    return sorted(best.values(), key=lambda x: x["idx"])


# ----------------------------------------------------------------------------
# 逃顶形态汇总（对应资产图的 9 大逃顶形态）
# ----------------------------------------------------------------------------
TOPPING_PATTERNS = [
    ("黄昏之星", "高位出现'阳线→小实体星线→阴线'三根组合，第三根跌破第一根阳线实体半分位", "★★★"),
    ("吊颈线（上吊线）", "上涨后出现长下影小实体；下影越长、实体越小越危险，需次日收盘低于实体确认", "★★☆"),
    ("乌云盖顶", "高开阴线，收盘深入前一根阳线实体中点以下；插入越深越弱", "★★☆"),
    ("平顶/钳子顶", "两根或多根K线最高价处于同一水平位，同一位置反复受阻", "★★☆"),
    ("塔形顶", "先一根长阳或中阳，随后连续小阳小阴滞涨，最后向下跳空/连续阴线", "★★☆"),
    ("圆顶（圆弧顶）", "多根小阳小阴构成圆弧顶部，最后以下跌缺口确认", "★★☆"),
    ("双飞乌鸦", "上涨中首根阳线，随后两根阴线，第二根阴线完全包含第一根阴线", "★★☆"),
    ("三只乌鸦", "上涨中连续三根阴线，逐级走低，跳空下跌更弱", "★★★"),
    ("高档五阴线", "上涨后出现 5 根（也可能 6-8 根）并排小阴线，跌破前期阳线实体", "★★☆"),
]


def topping_scan(open_, high, low, close, recent: int = 5) -> List[dict]:
    """汇总最近 recent 根内命中的逃顶类形态"""
    cd = Candles(open_, high, low, close)
    allp = detect_single(cd, lookback=recent + 20) + detect_double(cd, lookback=recent + 20) \
        + detect_triple(cd, lookback=recent + 20) + detect_rounded_top(high, low, close)
    names = {p[0].split("（")[0] for p in TOPPING_PATTERNS}
    hits = {}
    for p in allp:
        base = p["name"].split("（")[0]
        for nm in names:
            if base.startswith(nm.split("（")[0]) and p["idx"] >= cd.n - recent:
                hits[nm] = p
    return list(hits.values())


def scan_all(open_, high, low, close, lookback: int = 40, cooldown: int = 3) -> List[dict]:
    """
    完整扫描：单根 + 双根 + 三根 + 圆顶/塔形顶
    cooldown: 同名形态在 N 根内重复出现时只保留最强的一条，避免刷屏
    """
    cd = Candles(open_, high, low, close)
    res = (detect_single(cd, lookback) + detect_double(cd, lookback)
           + detect_triple(cd, lookback) + detect_rounded_top(high, low, close))
    order = {"强": 3, "中": 2, "弱": 1}
    # 1) 精确去重（同位置同名同向，保留最强）
    seen = {}
    for p in res:
        key = (p["idx"], p["name"], p["direction"])
        if key not in seen or order.get(p["strength"], 0) > order.get(seen[key]["strength"], 0):
            seen[key] = p
    # 2) 冷却期去重（同名同向在 cooldown 根内只留最强）
    kept: List[dict] = []
    for p in sorted(seen.values(), key=lambda x: (-order.get(x["strength"], 0), x["idx"])):
        dup = False
        for q in kept:
            if q["name"] == p["name"] and q["direction"] == p["direction"] and abs(q["idx"] - p["idx"]) <= cooldown:
                dup = True
                break
        if not dup:
            kept.append(p)
    return sorted(kept, key=lambda x: (-x["idx"], x["name"]))


__all__ = [
    "Candles", "trend_at", "swing_points", "market_structure", "support_resistance",
    "gaps", "gap_classify", "detect_single", "detect_double", "detect_triple",
    "detect_rounded_top", "detect_divergence", "TOPPING_PATTERNS", "topping_scan",
    "scan_all",
]
