---
name: skillhub-skill-cn-geo-audit
description: "# GEO网站诊断（cn-geo-audit v2.1）"
---

# GEO网站诊断（cn-geo-audit v2.1）

中国版 GEO 网站就绪度审计。面向国内 AI 搜索引擎生态（百度文心一言、字节豆包、Kimi、DeepSeek、通义千问、智谱清言、腾讯混元），融合 7 套主流 GEO 标准制定 45 项检查 / 100 分加权制评分。

## 方法论来源

- 盘古 GEO 32 项检查清单（大数跨境）
- China SEO Checklist 2026（SEOforChina）
- 光合道 GEO 诊断评估六维度
- 于磊老师「两大核心+四轮驱动」12 指标
- Bluejar 25 项 GEO Audit Checklist
- Ranktracker GEO Audit 五层框架
- geo-url-audit 三支柱评分模型

## 四大维度 45 项（100 分制）

| 维度 | 检查项 | 权重 | 核心关注 |
|------|:---:|:---:|------|
| AI可访问性 | 11 | 24 分 | AI爬虫能访问吗？ |
| 技术配置 | 10 | 22 分 | 基础设施安全规范吗？ |
| 结构化数据 | 10 | 22 分 | AI能机器读取吗？ |
| 内容可引用性 | 14 | 32 分 | AI会引用吗？ |
| **总计** | **45** | **100** | |

## 执行环境

**技能根目录**: `~/.workbuddy/skills/cn-geo-audit/`
**审计脚本**: `~/.workbuddy/skills/cn-geo-audit/scripts/cn_geo_audit.py`
**检查清单**: `~/.workbuddy/skills/cn-geo-audit/references/checklist.md`

在 Windows 下，`~` 展开为 `C:\Users\<用户名>`。脚本使用 Python 3，依赖 `requests` 和 `beautifulsoup4`。

## 评分体系

| 分数 | 等级 | 说明 |
|------|------|------|
| 90-100 | A+ | 优秀的国内 GEO 就绪度，AI 引用概率极高 |
| 80-89 | A | 较强，核心维度覆盖良好，少数细节需优化 |
| 70-79 | B | 良好，存在可识别的差距需系统修复 |
| 60-69 | C | 一般，多个关键维度有缺陷，需要显著投入 |
| 50-59 | D | 较差，基础能力薄弱，需大幅整改 |
| 0-49 | F | 严重缺陷，基本不具备 AI 就绪条件 |

计分方式：每项 ✅ pass=1 / ❌ fail=0 / ⚠️ partial=0.5。各维度原始得分按权重 24/22/22/32 加权映射到 100 分。

---

## Phase 0 — 立即开始

**收到 GEO 诊断请求后，直接执行审计。不要先问问题。**

1. 从用户消息中提取 URL。如果用户没给 URL，问一次获取 —— 这是唯一的必填输入。
2. 确认 URL 格式：补充 `https://` 前缀（如需要），去除尾部斜杠。
3. 直接运行 Phase 1 审计脚本。不要问用户"选哪个维度""要不要全量"，不要提前讨论。

---

## Phase 1 — 自动审计

运行审计脚本，传入目标 URL：

```bash
cd ~/.workbuddy/skills/cn-geo-audit && python scripts/cn_geo_audit.py "<URL>" --output json
```

脚本将：
- 依次执行 45 项检查，每项输出状态图标（✅/❌/⚠️）
- 按四大维度分组，计算加权得分
- 输出 JSON 格式的完整结果（含每项检查的 status、notes 和维度得分）

**输出结构（JSON）**:
```json
{
  "site": "example.com",
  "timestamp": "2025-01-01T00:00:00Z",
  "score": 68.5,
  "total": 100,
  "grade": "C",
  "dimensions": [
    {
      "name": "AI可访问性",
      "score": 8.5,
      "total": 11,
      "weighted_score": 18.5,
      "weight": 24,
      "percentage": 77,
      "checks": [
        {"check": "robots.txt允许国内AI爬虫", "status": "pass", "notes": "国内AI爬虫未被屏蔽"},
        ...
      ]
    },
    ...
  ]
}
```

**可选参数**:
- `--output md`：输出 Markdown 格式报告
- `--dimension accessibility|technical|schema|content`：仅审计指定维度
- `--timeout 30`：自定义超时（秒）
- `--delay 1.0`：自定义请求间隔（秒）

---

## Phase 2 — 结果分析

拿到 JSON 结果后，按四个维度逐项分析。

### 2.1 AI可访问性分析（24分 / 11项）

逐项读取检查结果，重点关注：

| # | 检查项 | 关键判断 |
|---|--------|---------|
| 1 | robots.txt允许国内AI爬虫 | 百度/字节/Kimi/DeepSeek/通义/智谱/360/搜狗是否被屏蔽 |
| 2 | robots.txt允许国际AI爬虫 | GPTBot/ClaudeBot/PerplexityBot/Google-Extended/CCBot 是否被屏蔽 |
| 3 | 百度站长平台验证 | baidu-site-verification 标签是否存在 |
| 4 | 页面3秒内加载 | TTFB<800ms，完整加载<3s |
| 5 | 无JS渲染阻塞 | curl抓取含≥5个段落 |
| 6 | 无需登录可访问 | 无登录门控 |
| 7 | 移动端适配 | viewport标签+响应式 |
| 8 | 原始HTML含语义元素 | ≥2种语义元素 |
| 9 | XML Sitemap存在 | sitemap.xml可访问或在robots.txt引用 |
| 10 | 百度主动推送API | 检测到百度JS或推送代码 |
| 11 | llms.txt存在且有效 | 标准Markdown格式，≥3个有效链接 |

**分析重点**: 记录具体屏蔽了哪些爬虫 → 将在 Phase 4 "逐AI爬虫分解" 中展开。

### 2.2 技术配置分析（22分 / 10项）

| # | 检查项 | 关键判断 |
|---|--------|---------|
| 12 | HTTPS强制(含国内CA) | HTTP→HTTPS跳转正常 |
| 13 | Canonical URL一致性 | canonical标签存在且指向正确 |
| 14 | Canonical标签正确解析 | 目标URL返回200 |
| 15 | 关键页面无noindex | 首页/关于/服务页均无noindex |
| 16 | 404状态码正确 | 不存在URL返回HTTP 404 |
| 17 | 国内CDN/本土托管 | 检测CDN特征 |
| 18 | URL结构语义化 | 无冗余参数，路径含关键词 |
| 19 | 无恶意跳转/过度弹窗 | 无全屏弹窗或强制广告 |
| 20 | ICP备案号合规展示 | 备案号存在且格式正确 |
| 21 | Open Graph标签完整 | og:title/description/image/url 4/4 |

### 2.3 结构化数据分析（22分 / 10项）

| # | 检查项 | 关键判断 |
|---|--------|---------|
| 22 | JSON-LD存在 | 首页≥1个有效JSON-LD块 |
| 23 | Organization Schema | name/url/logo/description |
| 24 | WebSite Schema(含SearchAction) | url+potentialAction |
| 25 | Article/BlogPosting Schema | headline/author/datePublished |
| 26 | BreadcrumbList Schema | itemListElement含position和name |
| 27 | FAQPage Schema | mainEntity含Question/Answer对 |
| 28 | LocalBusiness Schema | name/address/telephone |
| 29 | HowTo Schema | step数组每步含name和text |
| 30 | Schema有效性验证 | Schema Validator 无严重错误 |
| 31 | 微信分享兼容 | description meta+JS-SDK |

**分析重点**: 这是生成 "Schema缺项详细" 的源数据。标注每项 ✅/✗/△，列出缺失属性和类型。

### 2.4 内容可引用性分析（32分 / 14项）

| # | 检查项 | 关键判断 |
|---|--------|---------|
| 32 | 首段含核心主张 | 开篇100字内直接陈述核心观点 |
| 33 | 品牌名在首段 | 品牌全称出现在前150字 |
| 34 | 结构化内容格式 | 定义→解释→案例层次清晰 |
| 35 | FAQ以Q&A格式呈现 | ≥3组Q&A，问题自然口语 |
| 36 | 标题层级清晰 | H1唯一+H2≥1+H3，无跳级 |
| 37 | 数据引用标注来源 | "据[来源]数据显示……"格式 |
| 38 | 作者/机构权威信息 | 作者简介含姓名/头衔/背景≥2项 |
| 39 | 行业关键词自然分布 | 核心关键词密度2%-8% |
| 40 | 内容时效性标记 | datePublished或可见日期 |
| 41 | 关于我们品牌身份完整 | 成立时间/业务范围/资质/联系方式≥4项 |
| 42 | 多模态内容补充 | 图片/视频含alt或文字说明 |
| 43 | 跨平台品牌信息一致性 | 核心信息≥2个外部平台一致 |
| 44 | 结构化表格与列表使用 | 首页≥1表格或≥3组列表 |
| 45 | 外部引用域名数量 | ≥10唯一外部域名=满分 |

**分析重点**: 这里的 pass 项即为 "可引用片段"（definition/FAQ/table/citation/authority 等类型的文本块），在 Phase 4 中需要摘取展示。

---

## Phase 3 — 综合评分

从 JSON 结果中提取核心指标：

1. **总分** (`results.score`) 和 **等级** (`results.grade`)
2. **四维度加权得分**：遍历 `results.dimensions[*].weighted_score`
3. **各维度通过率**：`dimension.score / dimension.total * 100`
4. **判定色阶**：
   - 🟢 ≥70%（绿色）
   - 🟡 40-69%（黄色）
   - 🔴 <40%（红色）

---

## Phase 4 — 生成报告

**HTML/PDF 报告使用模板生成**。模板文件位于 `references/report-template.html`，包含完整的 CSS 设计系统（720px 卡片、蓝条头部、环形计分器、colgroup 表格、打印样式）。生成时读取模板，替换动态数据占位符后输出。

报告也可在对话中直接输出。**严禁**照搬脚本 stdout 原始输出。

### 报告结构（8 大模块）

**模板中的关键设计要素：**
- 卡片宽度 720px，适配 A4 打印
- 蓝条 masthead + 浅灰信息区 + 环形计分器同行布局
- `table-layout: fixed` + `<colgroup>` 精确列宽
- `@page { margin: 16mm }` + `@media print` 白底无阴影
- 色阶：绿≥70% / 黄 40-69% / 红<40%

```
## GEO 网站诊断报告 — {域名}（{日期}）

**诊断标准**: cn-geo-audit v2.1（45项/100分）
**目标网站**: {URL}

### 总体结论

[2-3句话：当前 GEO 状态 + 最大短板 + 优先方向]

---

### ① 总分仪表盘

[SVG 环形仪表盘，展示总分和等级]
- 环形进度条，色阶：绿(≥70)/黄(40-69)/红(<40)
- 中心显示 {score}/100 和 {grade}

---

### ② 四维度得分卡片

| 维度 | 加权得分 | 满分 | 通过率 | 色阶 |
|------|:----:|:----:|:----:|:----:|
| AI可访问性 | XX.X | 24 | XX% | 🟢/🟡/🔴 |
| 技术配置 | XX.X | 22 | XX% | 🟢/🟡/🔴 |
| 结构化数据 | XX.X | 22 | XX% | 🟢/🟡/🔴 |
| 内容可引用性 | XX.X | 32 | XX% | 🟢/🟡/🔴 |
| **总分** | **XX.X** | **100** | — | —

每个维度附一行诊断摘要。

---

### ③ 逐AI爬虫分解（平台关联）

将 AI可访问性 维度 #1-2 的检查结果展开，按 AI 平台对应：

| 爬虫 | 平台 | 状态 | 说明 |
|------|------|:---:|------|
| Baiduspider | 文心一言 | ✅/❌ | ... |
| Bytespider | 豆包 | ✅/❌ | ... |
| KimiBot | Kimi | ✅/❌ | ... |
| DeepSeekCrawler | DeepSeek | ✅/❌ | ... |
| TongyiBot | 通义千问 | ✅/❌ | ... |
| 360Spider | 360智脑 | ✅/❌ | ... |
| Sogou Spider | 混元 | ✅/❌ | ... |
| ZhihuBot | 智谱清言 | ✅/❌ | ... |
| GPTBot | ChatGPT | ✅/❌ | ... |
| ClaudeBot | Claude | ✅/❌ | ... |
| PerplexityBot | Perplexity | ✅/❌ | ... |
| Google-Extended | Gemini | ✅/❌ | ... |

---

### ④ 失败分类码

按失败类型归类，标注代码、原因和修复方向：

| 代码 | 含义 | 涉及检查项 | 修复说明 |
|------|------|-----------|---------|
| T-INDEX | 索引阻断 | robots.txt屏蔽、noindex误用 | 修改robots.txt、删除noindex |
| C-MATCH | 内容不匹配 | 无结构化标记、关键词覆盖不足 | 添加Schema、优化内容 |
| A-AUTH | 权威信号缺失 | 无作者信息、无品牌身份页 | 添加作者简介、完善关于页 |
| P-CANON | 规范化问题 | canonical缺失/错误、URL参数冗余 | 添加canonical、优化URL |
| P-ABSENCE | 关键资产缺失 | 无llms.txt、无Sitemap、无JSON-LD | 创建对应文件 |

---

### ⑤ 可引用片段

列出 AI 高概率截取的文本块（基于内容可引用性维度的 pass 项）：

- **定义型片段**: 从首段提取的核心主张文本（100字内）
- **FAQ片段**: 从 FAQ 板块提取的 Q&A 对（如有）
- **表格/列表数据**: 首页表格或列表中的结构化信息
- **权威声明**: 关于页面的品牌身份信息
- **引证片段**: 数据引用的完整句式（如有）

---

### ⑥ Schema 缺项详细

逐类型标注状态和缺失属性：

| Schema类型 | 状态 | 缺失属性/说明 |
|-----------|:---:|------|
| Organization | ✅/✗/△ | name/url/logo/description... |
| WebSite + SearchAction | ✅/✗/△ | SearchAction定义... |
| Article/BlogPosting | ✅/✗/△ | headline/author/datePublished... |
| BreadcrumbList | ✅/✗/△ | itemListElement... |
| FAQPage | ✅/✗/△ | mainEntity Q&A对... |
| LocalBusiness | ✅/✗/△ | address/telephone/geo... |
| HowTo | ✅/✗/△ | step name+text... |
| 微信分享兼容 | ✅/✗/△ | description meta/JS-SDK |

其中：✅=已标记 / ✗=缺失 / △=存在但不完整

---

### ⑦ P0 代码示例

针对最关键的缺失项，提供完整可复制的代码段（用实际域名和品牌名填充占位符）。

**必须包含的示例（至少提供前3项中缺失的）**:

**1. llms.txt**（如检查项 #11 为 fail/partial）

```markdown
# {品牌名/域名}

> {一句话站点定位}

## 核心页面
- 首页: {URL}/
- 关于我们: {URL}/about
- 服务介绍: {URL}/services
- 案例/博客: {URL}/blog

## 核心主题
- {主题1描述}
- {主题2描述}
- {主题3描述}

## 联系方式
- 电话: {电话}
- 邮箱: {邮箱}
- 地址: {地址}
```

**2. Organization JSON-LD**（如检查项 #23 为 fail/partial）

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "{品牌全称}",
  "url": "{URL}",
  "logo": "{URL}/logo.png",
  "description": "{品牌核心描述，80-150字}",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "{城市}",
    "addressRegion": "{省份}",
    "addressCountry": "CN"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "{电话}",
    "contactType": "customer service"
  }
}
</script>
```

**3. FAQPage JSON-LD**（如检查项 #27 为 fail/partial）

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "{常见问题1}",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "{简洁直接的答案}"
    }
  }, {
    "@type": "Question",
    "name": "{常见问题2}",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "{简洁直接的答案}"
    }
  }]
}
</script>
```

**4. Canonical 标签**（如检查项 #13 为 fail）

```html
<link rel="canonical" href="{规范化URL}" />
```

---

### ⑧ 修复得分预估

| 修复项 | 当前状态 | 修复后状态 | 预计提升 | 优先级 |
|--------|:---:|:---:|:----:|:---:|
| 创建 llms.txt | ❌/⚠️ | ✅ | +2.2 | P0 |
| 添加 Organization Schema | ❌/△ | ✅ | +2.2 | P0 |
| 完善 FAQPage Schema | ❌/△ | ✅ | +2.2 | P0 |
| 修复 canonical | ❌ | ✅ | +2.2 | P0 |
| 百度主动推送接入 | ⚠️ | ✅ | +1.1 | P1 |
| 增加作者权威信息 | ⚠️ | ✅ | +2.3 | P1 |
| ... | ... | ... | ... | ... |

【仅列出当前 fail/partial 的检查项，每项标注预计可提升的加权分数（按维度权重 ÷ 检查项数量计算）】

---

### 推荐查询监控

每月测试以下查询，跟踪品牌在 AI 平台回答中的出现情况：

- {根据网站主题生成 7-10 个具体的长尾查询问题}
```

---

## Phase 5 — 优化建议

基于分析结果，输出 P0/P1/P2 三级优化建议。

### P0：本周做（最高优先级，1-4项）

聚焦 AI可访问性 和 结构化数据 维度的 fail 项。每项包含：
- 具体问题描述
- 完整的代码示例（见 Phase 4 ⑦）
- 预期效果说明

### P1：本月做（中优先级，3-6项）

聚焦 技术配置 和 内容可引用性 维度的 fail/partial 项。可只给指导方向。

### P2：持续做

- 建立第三方存在感（知乎、百度百科、公众号、GitHub）
- 内容定期更新（保持时效性信号）
- 每月监控 AI 平台引用情况

---

## 完整检查清单速查

详见 [references/checklist.md](references/checklist.md)，含每项检查的通过标准、来源依据和国内适用性说明。

## CLI 工具参考

```bash
# 全量审计，JSON输出
python scripts/cn_geo_audit.py <域名或URL> --output json

# Markdown输出
python scripts/cn_geo_audit.py <域名或URL> --output md

# 仅审计指定维度
python scripts/cn_geo_audit.py <域名或URL> --dimension accessibility
python scripts/cn_geo_audit.py <域名或URL> --dimension schema
python scripts/cn_geo_audit.py <域名或URL> --dimension content

# 自定义超时和间隔（慢速站点用）
python scripts/cn_geo_audit.py <域名或URL> --timeout 30 --delay 1.0
```

## 国内 AI 爬虫对照表

| 爬虫 User-Agent 关键词 | 所属 AI 平台 | 平台类型 |
|------------------------|-------------|---------|
| Baiduspider | 百度文心一言 | 大语言模型 |
| Bytespider | 字节豆包 | 大语言模型 |
| KimiBot / Kimi | 月之暗面 Kimi | 大语言模型 |
| DeepSeekCrawler | 深度求索 DeepSeek | 大语言模型 |
| TongyiBot | 阿里通义千问 | 大语言模型 |
| 360Spider | 360 智脑 | 大语言模型 |
| Sogou Spider | 腾讯混元 | 大语言模型 |
| ZhihuBot | 智谱清言 | 大语言模型 |

## v2.1 vs v2.0 变更

- 补回 llms.txt 检查（AI可访问性 1.11）
- 新增结构化表格与列表检查（内容可引用性 4.13）
- 新增外部引用域名计数（内容可引用性 4.14）
- 总项数 42 → 45，评分档位同步调整
