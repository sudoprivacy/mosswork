# 中国版 GEO 就绪度审计清单（v2.0）

面向国内 AI 搜索引擎生态（百度文心一言、字节豆包、Kimi、DeepSeek、通义千问、智谱清言、腾讯混元），融合以下标准制定：

- 盘古 GEO 32 项检查清单（大数跨境）
- China SEO Checklist 2026（SEOforChina）
- 光合道 GEO 诊断评估六维度框架
- 于磊老师"两大核心+四轮驱动"12 指标
- Bluejar 25 项 GEO Audit Checklist
- Ranktracker GEO Audit 五层框架
- Onely 10 步 GEO Audit 方法论

---

## 维度一：AI 可访问性（11 项）

> 核心问题：AI 爬虫能访问、能抓取、能解析你的网站吗？

### 1.1 robots.txt 允许国内 AI 爬虫

检测是否屏蔽了以下国内主流 AI 爬虫：
- Baiduspider（百度文心一言）
- Bytespider（字节跳动/豆包）
- Kimi Bot（月之暗面）
- DeepSeek Crawler（深度求索）
- Tongyi Bot（阿里通义千问）
- 360Spider（360 智脑）
- Sogou Spider（搜狗/腾讯混元）
- ZhihuBot（智谱清言）

通过标准：未设置 `Disallow: /` 针对上述爬虫；或显式 `Allow:` 关键路径。

来源依据：盘古 GEO 3.2.1「网站抓取友好性」；China SEO Checklist Phase 1。

### 1.2 robots.txt 允许国际主流 AI 爬虫

检测是否屏蔽：GPTBot（OpenAI）、ClaudeBot（Anthropic）、PerplexityBot、Google-Extended、CCBot。

通过标准：未全局阻断以上爬虫。

来源依据：Bluejar Factor 1；Onely Step 3。

### 1.3 百度搜索资源平台验证

检测 `<meta name="baidu-site-verification">` 或 HTML 验证文件是否存在。

通过标准：验证标签或文件存在。

来源依据：China SEO Checklist Phase 1「Baidu Webmaster Tools verified」。

### 1.4 页面加载速度达标

检测 TTFB（首字节）和完整加载时间。

通过标准：
- TTFB < 800ms
- 首屏加载 ≤ 1.2秒（参考 China SEO Checklist）
- 完整加载 < 3秒

来源依据：盘古 GEO 3.2.2；China SEO Checklist Phase 1「First Screen Load ≤1.2s」。

### 1.5 核心内容非 JS 渲染依赖

检测原始 HTML（View Source）中是否包含正文内容，而非完全依赖 JS 动态加载。

通过标准：`curl` 抓取到的 HTML 中包含 ≥5 个 `<p>` 段落。

来源依据：盘古 GEO 3.2.1；China SEO Checklist Phase 1「Critical content in HTML」。

### 1.6 无需登录 / 付费墙可访问核心内容

检测首页和核心服务页是否无需 Cookie 或登录即可访问。

通过标准：无 "注册后查看""请先登录"类门控；HTTP 直接返回 200。

来源依据：Bluejar Factor 1；GEO 诊断评估 3.3。

### 1.7 移动端适配

检测 viewport 标签、响应式布局、触控友好度。

通过标准：
- `<meta name="viewport">` 存在
- 响应式布局（375px 宽度下无横向滚动）
- 文字字号 ≥ 14px，按钮触控区 ≥ 44×44px（参考盘古 GEO 3.2.3）

来源依据：盘古 GEO 3.2.3；China SEO Checklist Phase 1「Responsive web design」。

### 1.8 原始 HTML 含语义元素

检测 View Source 中 HTML5 语义标签的使用。

通过标准：至少含 2 种语义元素（`<h1>`、`<article>`、`<main>`、`<section>`、`<header>`、`<footer>`、`<nav>`）。

来源依据：Ranktracker Audit Item 11-13「HTML Cleanliness」。

### 1.9 XML Sitemap 存在并已提交

检测 `/sitemap.xml` 是否存在、是否在 robots.txt 中引用、是否已提交百度站长平台。

通过标准：sitemap 文件可访问且含 URL 列表；robots.txt 中引用。

来源依据：盘古 GEO 3.2.1；China SEO Checklist Phase 1「Sitemap submitted」。

### 1.10 百度主动推送（URL Push）API 接入

检测是否部署了百度 URL 主动推送 JS 或 API。

通过标准：检测到 `baidu_js_push` 或类似推送代码；或在百度站长平台有推送记录。

来源依据：China SEO Checklist Phase 1「URL push implemented」。

### 1.11 llms.txt 存在且有效

检测根目录 `/llms.txt` 是否存在，内容是否遵循标准格式。

通过标准：
- `/llms.txt` 返回 HTTP 200
- 采用 `# 站点名` + `## 板块` + `- [链接](URL)` 标准 Markdown 格式
- 至少含 3 个以上有效内链

> **国内适用性说明：** llms.txt 在国外已是主流 AI 站点入口标准，国内 DeepSeek 已开始支持，随着 Kimi、通义千问等跟进，llms.txt 在国内 GEO 中的价值正在上升。

来源依据：Onely Step 3；Bluejar Factor 6；原版 GEO Audit 1.2。

---

## 维度二：技术配置（10 项）

> 核心问题：网站的技术基础设施是否安全、规范、对 AI 友好？

### 2.1 HTTPS 强制启用（含国内 CA 兼容）

检测 HTTP 是否自动跳转 HTTPS，SSL 证书是否兼容国内根证书机构（CFCA、CNNIC 等）。

通过标准：HTTP → HTTPS 重定向正常；证书无警告。

来源依据：盘古 GEO 3.2；China SEO Checklist Phase 1「SSL certificate installed—ensure compatibility with China's root CAs」。

### 2.2 Canonical URL 一致性

检测 `<link rel="canonical">` 是否存在，www/非 www 版本是否统一。

通过标准：canonical 标签存在且指向正确的规范化 URL。

来源依据：Bluejar Factor 3；原版 GEO Audit 1.7。

### 2.3 Canonical 标签正确解析

检测 canonical 指向的 URL 是否返回 200；是否存在 canonical 链式跳转。

通过标准：canonical 目标 URL 返回 200，无链式跳转。

来源依据：原版 GEO Audit 4.6。

### 2.4 关键页面无 noindex / nofollow 误用

检测首页、关于页、核心服务页是否误设了 `noindex` 或全局 `nofollow`。

通过标准：以上页面均无 `noindex` 标签。

来源依据：Bluejar Factor 5；原版 GEO Audit 1.8。

### 2.5 404 状态码正确返回

检测不存在的页面是否返回 HTTP 404，而非 200"软 404"或跳转首页。

通过标准：随机不存在的 URL 返回 HTTP 404。

来源依据：China SEO Checklist Phase 1「Dead links submitted」；原版 GEO Audit 4.7。

### 2.6 国内 CDN 或本土服务器托管

检测网站是否使用了国内 CDN（阿里云 CDN、腾讯云 CDN、七牛等）或本土服务器。

通过标准：可通过 DNS 解析和 IP 归属确认。国际访问者建议速度差异不超过 2 倍。

来源依据：China SEO Checklist Phase 1「Mainland China hosting or China CDN」。

### 2.7 URL 结构语义化

检测 URL 是否使用语义化路径（如 `/services/criminal-defense`）而非参数化（如 `/?p=123`）。

通过标准：无冗余参数；路径含可读关键词。

来源依据：China SEO Checklist Phase 1；Ranktracker「Cluster Architecture」。

### 2.8 无恶意跳转 / 过度广告弹窗干扰

检测页面是否有强制性弹窗、悬浮广告、诱导跳转等影响 AI 爬虫抓取的元素。

通过标准：无全屏弹窗或需要用户交互才能关闭的广告。

来源依据：盘古 GEO 3.2.1「无过度弹窗/广告干扰」。

### 2.9 ICP 备案号合规展示

检测页脚是否展示 ICP 备案号（格式如"粤ICP备XXXXXXXX号"），并链接到工信部备案查询。

通过标准：备案号存在且格式正确，链接可访问。

来源依据：China SEO Checklist Phase 0「ICP License obtained」。

### 2.10 Open Graph 标签完整

检测 og:title、og:description、og:image、og:url 四个标签是否全部存在。

通过标准：4/4 标签存在且内容非空。

来源依据：GEO 诊断评估 3.4；原版 GEO Audit 4.4。

---

## 维度三：结构化数据（10 项）

> 核心问题：AI 模型能否通过机器可读的标记准确理解你的网站内容？

### 3.1 JSON-LD 存在

检测首页 HTML 中是否包含 `<script type="application/ld+json">` 块。

通过标准：首页至少含 1 个有效 JSON-LD 块。

来源依据：Bluejar Factor 9；原版 GEO Audit 2.1。

### 3.2 Organization Schema

检测是否包含组织/机构的结构化标记。

必需字段：`@type: "Organization"`、`name`、`url`、`logo`、`description`、`address`、`contactPoint`。

来源依据：GEO 诊断评估 3.4「组织信息结构化状态」；Bluejar Factor 10。

### 3.3 WebSite Schema（含 SearchAction）

检测是否包含站点级 Schema，且含站内搜索功能标记。

必需字段：`@type: "WebSite"`、`url`、`potentialAction.SearchAction`。

来源依据：原版 GEO Audit 2.3。

### 3.4 Article / BlogPosting Schema

检测文章/案例页面是否标记了 Article 或 BlogPosting Schema。

必需字段：`headline`、`author`、`datePublished`。推荐：`image`、`publisher`、`dateModified`。

来源依据：Bluejar Factor 11；原版 GEO Audit 2.5。

### 3.5 BreadcrumbList Schema

检测是否包含面包屑导航的结构化标记。

必需字段：`@type: "BreadcrumbList"`、`itemListElement`（含 position 和 name）。

来源依据：Bluejar Factor 12。

### 3.6 FAQPage Schema

检测 FAQ 页面是否标记了 FAQPage Schema。

必需字段：`@type: "FAQPage"`、`mainEntity` 数组含 Question/Answer 对。

来源依据：China SEO Checklist Phase 3「FAQ section with schema」；盘古 GEO 2.2.1「AI友好型FAQ模板」。

### 3.7 LocalBusiness Schema（国内重点）

检测服务型机构（律所、诊所、咨询公司等）是否标记了 LocalBusiness Schema。

必需字段：`name`、`address`、`telephone`。推荐：`openingHours`、`geo`（经纬度坐标）。

来源依据：盘古 GEO 1.2「平台定位」；Bluejar Factor 14。

### 3.8 HowTo Schema

检测教程/指南类内容是否标记了 HowTo Schema。

必需字段：`@type: "HowTo"`、`step` 数组（每个步骤含 `name` 和 `text`）。

来源依据：Bluejar Factor 13；China SEO Checklist Phase 5。

### 3.9 Schema 有效性验证通过

用百度结构化数据测试工具或 Schema Markup Validator 验证 JSON-LD 无错误。

通过标准：无严重错误；警告可接受。

来源依据：盘古 GEO 2.2；GEO 诊断评估 3.4。

### 3.10 微信分享兼容

检测 description meta 标签是否完整（微信分享默认读取）、是否接入微信 JS-SDK。

通过标准：description 标签存在且非空；或检测到 `jweixin-1` 脚本。

来源依据：China SEO Checklist Phase 4「WeChat Official Account」；盘古 GEO 3.1.4「微信生态运营」。

---

## 维度四：内容可引用性（14 项）

> 核心问题：AI 模型在生成回答时，会不会引用你的内容？

### 4.1 首段 100 字内含核心主张 / 直接回答句

检测页面开篇是否直接陈述核心观点或服务定位，可被 AI 脱上下文引用。

良好示例："尊而光律师事务所成立于 20XX 年，专注婚姻家事与刑事辩护，已服务超 5000 位委托人。"

不佳示例："法律是社会公平正义的基石……"（泛化开场，AI 无法提取有用信息）

来源依据：Ranktracker Audit Item 6「Definition Positioning」；Bluejar Factor 15。

### 4.2 品牌 / 机构名在首段自然出现

检测品牌全称是否出现在前 150 字中，帮助 AI 建立品牌实体关联。

通过标准：品牌名自然出现在首段（非机械堆砌）。

来源依据：于磊老师「品牌实体关联」；原版 GEO Audit 3.4。

### 4.3 内容含「定义→解释→案例」结构化格式

检测复杂概念是否遵循清晰的信息层次：先定义，再展开解释，最后用案例佐证。

通过标准：内容层次清晰，信息密度高，AI 可逐层提取。

来源依据：Ranktracker Audit Item 7「Extractable Blocks」；盘古 GEO 2.2.1。

### 4.4 FAQ 以 Q&A 格式呈现

检测是否有独立的 FAQ 板块，使用明确的"问题 + 答案"结构。

通过标准：至少含 3 组 Q&A；问题用自然口语，答案简洁直接。

来源依据：盘古 GEO 2.2.1「AI友好型FAQ模板」；于磊老师「FAQ/列表覆盖率」。

### 4.5 标题层级清晰（H1 唯一 + H2 板块 + H3 子主题）

检测标题标签是否语义化使用，能否作为 AI 的内容大纲。

通过标准：H1 存在且唯一；至少 1 个 H2；标题层级无跳级（如 H1 直跳 H4）。

来源依据：Ranktracker Audit Item 11「Heading Hierarchy」；于磊老师「H标签层级清晰度」。

### 4.6 数据引用标注可验证来源

检测行业数据和统计是否标注出处。

通过标准：引用格式为"据 [来源] 数据显示……"，附内链或外链。

来源依据：盘古 GEO 2.2.2「信息标注完整性」；于磊老师「数据可追溯性」。

### 4.7 作者 / 机构权威信息可见

检测文章是否展示作者背景、专业资质、行业经验等权威信号。

通过标准：作者简介含姓名、头衔、专业背景（至少 2 项）。

来源依据：于磊老师「作者权威度得分」；Bluejar Factor 21「Author bios」。

### 4.8 行业关键词自然分布（覆盖率 2%-8%）

检测核心业务关键词是否自然散布在正文中，不过度堆砌。

通过标准：核心关键词密度在 2%-8% 区间（于磊老师推荐区间）。

来源依据：于磊老师「关键词优化区间」；China SEO Checklist Phase 3「Keyword density ~1%」(传统 SEO，GEO 可稍高)。

### 4.9 内容时效性标记

检测文章/案例是否标注发布日期，以及是否展示最近更新时间。

通过标准：页面含 `datePublished` 或可见日期标记。

来源依据：盘古 GEO 4.4「内容迭代机制」；China SEO Checklist Phase 5「Content freshness maintained」。

### 4.10 "关于我们"页品牌身份完整

检测 /about 或 /gywm 页面是否完整定义品牌。

通过标准：含成立时间、业务范围、资质荣誉、联系方式、地址（至少 4 项）。

来源依据：GEO 诊断评估 3.1「AI品牌认知检测」；原版 GEO Audit 3.7。

### 4.11 多模态内容补充（图文 + 视频 + 文字说明）

检测关键内容是否搭配了图片、视频等多模态元素，且附文字说明供 AI 解析。

通过标准：核心内容页含至少 1 类非纯文本补充（图表/截图/视频），且含 alt 或文字描述。

来源依据：盘古 GEO 2.2.3「多模态内容补充」。

### 4.12 跨平台品牌信息一致性

检测品牌名称、产品参数、服务范围在官网、百度百科、知乎、百家号等多个平台是否保持一致。

通过标准：核心信息（品牌名、业务描述、联系方式）在 ≥2 个外部平台一致。

来源依据：盘古 GEO 2.1.3「跨平台内容同步」；于磊老师「多源数据一致性」。

### 4.13 结构化表格与列表使用

检测页面是否使用 HTML 表格（`<table>`）和有序列/无序列表（`<ol>`/`<ul>`）呈现结构化信息。

通过标准：首页至少含 1 个表格或 3 组列表元素。AI 系统能直接提取表格和列表中的离散数据作为可引用事实。

> 为何重要：表格和列表是 AI 提取结构化事实的最佳载体。geo-url-audit 技能将此列为内容可摘取性的核心子信号（满分 40 中占 6 分）。数据表格比段落文本的引用率高 3 倍以上。

来源依据：geo-url-audit Structure Extractability「Tables and lists」；Ranktracker Audit Item 7。

### 4.14 外部引用域名数量

检测首页外链指向的唯一域名数，评估内容的引用广度。

通过标准：
- ≥10 个唯一外部域名 → 满分
- 5-9 个 → 7 分
- 2-4 个 → 4 分
- <2 个 → 建议增加

> 适用范围：B2B、内容型、媒体型站点权重高；纯工具/SaaS 站点权重低（工具站点外链少是正常的）。

来源依据：geo-url-audit Authority「External citations」；于磊老师「外部权威引用数」。

---

## 评分标准（100 分制，维度加权）

| 分数 | 等级 | 说明 |
|------|------|------|
| 90-100 | A+ | 优秀的国内 GEO 就绪度，AI 引用概率极高 |
| 80-89 | A | 较强，核心维度覆盖良好，少数细节需优化 |
| 70-79 | B | 良好，存在可识别的差距需系统修复 |
| 60-69 | C | 一般，多个关键维度有缺陷，需要显著投入 |
| 50-59 | D | 较差，基础能力薄弱，需大幅整改 |
| 0-49 | F | 严重缺陷，基本不具备 AI 就绪条件 |

**计分规则：** 每项 ✅ 通过=1分 / ❌ 未通过=0分 / ⚠️ 部分通过=0.5分。各维度原始得分按权重映射到 100 分：

| 维度 | 检查项 | 权重 | 单项分值 |
|------|:---:|:---:|:---:|
| AI可访问性 | 11 | 24 分 | ~2.18 分/项 |
| 技术配置 | 10 | 22 分 | 2.20 分/项 |
| 结构化数据 | 10 | 22 分 | 2.20 分/项 |
| 内容可引用性 | 14 | 32 分 | ~2.29 分/项 |
| **总计** | **45** | **100** | |

---

## 维度权重参考

| 维度 | 权重 | 说明 |
|------|:---:|------|
| AI可访问性 | 24 分 (24%) | 基础门槛——如果AI爬不到，其他都白费 |
| 技术配置 | 22 分 (22%) | 保障性配置——达标即可，不求极致 |
| 结构化数据 | 22 分 (22%) | 高杠杆——直接决定AI"理解"深度 |
| 内容可引用性 | 32 分 (32%) | 最高杠杆——最终决定AI是否引用你的内容 |

---

## 版本对照：v1.0 → v2.0 变更

| 变更 | 数量 | 详情 |
|------|:---:|------|
| 新增 | +11 | 国际AI爬虫、llms.txt、百度主动推送、国内CDN、URL语义化、无恶意弹窗、作者权威、多模态、跨平台一致性、表格列表、外部引用计数 |
| 总项数 | 35→45 | AI可访问性11 + 技术配置10 + 结构化数据10 + 内容可引用性14 |

### v2.0 → v2.1 变更

- 补回 llms.txt 检查（国内 DeepSeek 已支持，生态价值上升）
- 新增 4.13 结构化表格与列表使用（来自 geo-url-audit 的核心信号）
- 新增 4.14 外部引用域名计数（来自 geo-url-audit Authority 维度）
- 评分档位从 42 分制调整为 45 分制
