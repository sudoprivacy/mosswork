#!/usr/bin/env python3
"""
中国版 GEO 就绪度审计工具
面向国内 AI 搜索引擎生态（百度文心一言、字节豆包、Kimi、DeepSeek、通义千问、智谱清言、腾讯混元）
45 项检查点，覆盖 AI可访问性、技术配置、结构化数据、内容可引用性四大维度
"""

import argparse
import json
import re
import sys
import time
from datetime import datetime
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

# 抑制SSL警告
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class CNGEOAuditor:
    def __init__(self, domain, timeout=15, delay=0.5, user_agent=None):
        self.domain = domain.replace('https://', '').replace('http://', '').rstrip('/')
        self.base_url = f"https://{self.domain}"
        self.timeout = timeout
        self.delay = delay
        self.results = {
            "site": self.domain,
            "timestamp": datetime.now().isoformat() + "Z",
            "score": 0,
            "total": 100,
            "grade": "F",
            "dimensions": []
        }
        self.headers = {
            'User-Agent': user_agent or 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,*/*',
            'Accept-Language': 'zh-CN,zh;q=0.9',
        }
        self.verify_ssl = True  # 默认验证SSL
        self._html_cache = {}
        self._parsed_cache = {}

    def fetch(self, path='/', timeout=None):
        url = self.base_url + path if path.startswith('/') else path
        if url in self._html_cache:
            return self._html_cache[url]
        try:
            time.sleep(self.delay)
            resp = requests.get(url, headers=self.headers, timeout=timeout or self.timeout,
                              allow_redirects=True, verify=False)
            self._html_cache[url] = resp
            return resp
        except Exception:
            self._html_cache[url] = None
            return None

    def parse(self, resp):
        if resp is None:
            return None
        if resp.url not in self._parsed_cache:
            self._parsed_cache[resp.url] = BeautifulSoup(resp.text, 'html.parser')
        return self._parsed_cache[resp.url]

    # =============================================
    # 维度一：AI平台可发现性 (10项)
    # =============================================

    def check_robots_txt(self):
        """1.1 检查 robots.txt 是否允许国内 AI 爬虫"""
        resp = self.fetch('/robots.txt')
        if not resp or resp.status_code != 200:
            return {"check": "robots.txt允许国内AI爬虫", "status": "fail", "notes": "robots.txt不可访问"}

        cn_bots = [
            'baiduspider', 'bytespider', 'kimi', 'deepseek',
            'tongyi', 'zhihu', '360spider', 'sogou'
        ]
        text = resp.text.lower()
        blocked = []
        for bot in cn_bots:
            # Check if specifically disallowed
            pattern = rf'user-agent:\s*{bot}.*?disallow:\s*/'
            if re.search(pattern, text, re.DOTALL | re.IGNORECASE):
                blocked.append(bot)

        if blocked:
            return {
                "check": "robots.txt允许国内AI爬虫",
                "status": "fail",
                "notes": f"已屏蔽: {', '.join(blocked)}"
            }

        # Check if robots.txt allows everything
        if 'disallow: /' in text and 'user-agent: *' in text:
            return {
                "check": "robots.txt允许国内AI爬虫",
                "status": "fail",
                "notes": "robots.txt禁止所有爬虫"
            }

        return {"check": "robots.txt允许国内AI爬虫", "status": "pass", "notes": "国内AI爬虫未被屏蔽"}

    def check_intl_robots(self):
        """1.2 robots.txt允许国际主流AI爬虫"""
        resp = self.fetch('/robots.txt')
        if not resp or resp.status_code != 200:
            return {"check": "robots.txt允许国际AI爬虫", "status": "partial", "notes": "robots.txt不可访问"}

        intl_bots = ['gptbot', 'claudebot', 'perplexitybot', 'google-extended', 'ccbot']
        text = resp.text.lower()
        blocked = []
        for bot in intl_bots:
            pattern = rf'user-agent:\s*{bot}.*?disallow:\s*/'
            if re.search(pattern, text, re.DOTALL | re.IGNORECASE):
                blocked.append(bot)

        if blocked:
            return {"check": "robots.txt允许国际AI爬虫", "status": "fail",
                   "notes": f"已屏蔽: {', '.join(blocked)}"}
        if 'disallow: /' in text and 'user-agent: *' in text:
            return {"check": "robots.txt允许国际AI爬虫", "status": "fail",
                   "notes": "robots.txt禁止所有爬虫"}
        return {"check": "robots.txt允许国际AI爬虫", "status": "pass",
               "notes": "国际AI爬虫未被屏蔽"}

    def check_baidu_verification(self):
        """1.3 百度搜索资源平台验证"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "百度站长平台验证", "status": "fail", "notes": "网站不可达"}
        if 'baidu-site-verification' in resp.text:
            return {"check": "百度站长平台验证", "status": "pass", "notes": "验证标签存在"}
        return {"check": "百度站长平台验证", "status": "fail", "notes": "未检测到百度验证标签"}

    def check_performance(self):
        """1.3 页面加载速度"""
        try:
            t0 = time.time()
            resp = requests.get(self.base_url, headers=self.headers,
                              timeout=self.timeout, allow_redirects=True, verify=False)
            elapsed = time.time() - t0
            if resp and resp.status_code == 200:
                if elapsed < 3:
                    return {"check": "页面3秒内加载", "status": "pass", "notes": f"{elapsed:.2f}s"}
                return {"check": "页面3秒内加载", "status": "fail", "notes": f"{elapsed:.2f}s（超时）"}
        except Exception:
            pass
        return {"check": "页面3秒内加载", "status": "fail", "notes": "加载失败"}

    def check_js_rendering(self):
        """1.4 无JS渲染阻塞"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "无JS渲染阻塞", "status": "fail", "notes": "网站不可达"}
        paras = len(re.findall(r'<p[>\s]', resp.text, re.IGNORECASE))
        if paras >= 5:
            return {"check": "无JS渲染阻塞", "status": "pass", "notes": f"HTML中含{paras}个段落"}
        return {"check": "无JS渲染阻塞", "status": "partial", "notes": f"仅{paras}个段落，可能存在JS渲染依赖"}

    def check_accessibility(self):
        """1.5 无需登录可访问"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "无需登录可访问", "status": "fail", "notes": "网站不可达"}
        login_signals = ['login', '登录', '请先登录', 'register', '注册后查看']
        if any(s in resp.text.lower() for s in login_signals):
            return {"check": "无需登录可访问", "status": "fail", "notes": "检测到登录门控"}
        return {"check": "无需登录可访问", "status": "pass", "notes": "无登录门控"}

    def check_canonical_consistency(self):
        """1.6 Canonical URL一致性"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "Canonical URL一致性", "status": "fail", "notes": "网站不可达"}
        canonical = re.search(
            r'<link[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']*)',
            resp.text, re.IGNORECASE
        )
        if canonical:
            href = canonical.group(1)
            if self.domain in href:
                return {"check": "Canonical URL一致性", "status": "pass", "notes": f"指向 {href}"}
            return {"check": "Canonical URL一致性", "status": "fail", "notes": f"指向外部域名 {href}"}
        return {"check": "Canonical URL一致性", "status": "fail", "notes": "无canonical标签"}

    def check_noindex(self):
        """1.7 关键页面无noindex"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "关键页面无noindex", "status": "fail", "notes": "网站不可达"}
        if 'noindex' in resp.text.lower():
            return {"check": "关键页面无noindex", "status": "fail", "notes": "检测到noindex"}
        return {"check": "关键页面无noindex", "status": "pass", "notes": "无noindex"}

    def check_sitemap(self):
        """1.8 XML Sitemap存在"""
        resp = self.fetch('/sitemap.xml')
        if resp and resp.status_code == 200 and '<url' in resp.text:
            return {"check": "XML Sitemap存在", "status": "pass", "notes": "sitemap.xml可访问"}

        robots = self.fetch('/robots.txt')
        if robots and 'sitemap' in robots.text.lower():
            return {"check": "XML Sitemap存在", "status": "pass", "notes": "robots.txt中引用"}

        # 尝试 sitemap_index.xml
        resp2 = self.fetch('/sitemap_index.xml')
        if resp2 and resp2.status_code == 200:
            return {"check": "XML Sitemap存在", "status": "pass", "notes": "sitemap_index.xml可访问"}

        return {"check": "XML Sitemap存在", "status": "fail", "notes": "未找到任何sitemap"}

    def check_mobile_viewport(self):
        """1.9 移动端适配"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "移动端适配", "status": "fail", "notes": "网站不可达"}
        if 'viewport' in resp.text.lower():
            return {"check": "移动端适配", "status": "pass", "notes": "viewport标签存在"}
        return {"check": "移动端适配", "status": "fail", "notes": "缺少viewport标签"}

    def check_raw_html_content(self):
        """1.10 原始HTML含核心内容"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "原始HTML含核心内容", "status": "fail", "notes": "网站不可达"}
        indicators = ['<h1', '<article', '<main', '<section', '<header', '<footer', '<nav']
        found = sum(1 for ind in indicators if ind in resp.text.lower())
        if found >= 3:
            return {"check": "原始HTML含核心内容", "status": "pass", "notes": f"{found}种语义元素"}
        if found >= 1:
            return {"check": "原始HTML含核心内容", "status": "partial", "notes": f"仅{found}种语义元素"}
        return {"check": "原始HTML含核心内容", "status": "fail", "notes": "缺少语义标记"}

    def check_baidu_push(self):
        """1.10 百度主动推送API接入"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "百度主动推送API", "status": "fail", "notes": "网站不可达"}
        push_signals = ['baidu_js_push', 'baidu_autopush', 'url_push', 'bdshare',
                       'hm.baidu.com', 'tongji.baidu.com']
        found = [s for s in push_signals if s in resp.text.lower()]
        if found:
            return {"check": "百度主动推送API", "status": "pass",
                   "notes": f"检测到百度JS: {found[0]}"}
        return {"check": "百度主动推送API", "status": "partial", "notes": "未检测到推送代码（推荐接入）"}

    def check_llms_txt(self):
        """1.11 llms.txt存在且有效"""
        resp = self.fetch('/llms.txt')
        if resp and resp.status_code == 200:
            text = resp.text.strip()
            if len(text) < 50:
                return {"check": "llms.txt", "status": "partial", "notes": "存在但内容过短"}
            # 检查标准格式: # 标题, ## 板块, - [链接]
            has_title = bool(re.search(r'^#\s+', text, re.MULTILINE))
            has_links = bool(re.search(r'\[.+?\]\(https?://', text))
            if has_title and has_links:
                link_count = len(re.findall(r'\[.+?\]\(https?://', text))
                return {"check": "llms.txt", "status": "pass",
                       "notes": f"格式规范，含{link_count}个链接"}
            return {"check": "llms.txt", "status": "partial",
                   "notes": "存在但格式不标准"}
        return {"check": "llms.txt", "status": "fail", "notes": "未找到llms.txt（国内DeepSeek已支持，推荐创建）"}

    # =============================================
    # 维度二：结构化数据与语义标记 (10项)
    # =============================================

    def check_jsonld_present(self):
        """2.1 JSON-LD存在"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "JSON-LD存在", "status": "fail", "notes": "网站不可达"}
        if 'application/ld+json' in resp.text:
            blocks = len(re.findall(r'<script[^>]*type=["\']application/ld\+json["\']', resp.text))
            return {"check": "JSON-LD存在", "status": "pass", "notes": f"发现{blocks}个JSON-LD块"}
        return {"check": "JSON-LD存在", "status": "fail", "notes": "无JSON-LD"}

    def check_organization_schema(self):
        """2.2 Organization Schema"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "Organization Schema", "status": "fail", "notes": "网站不可达"}
        if '"@type"' in resp.text and '"organization"' in resp.text.lower():
            # 检查关键字段
            has_name = '"name"' in resp.text
            has_url = '"url"' in resp.text
            return {
                "check": "Organization Schema",
                "status": "pass" if (has_name and has_url) else "partial",
                "notes": f"name={'✓' if has_name else '✗'} url={'✓' if has_url else '✗'}"
            }
        return {"check": "Organization Schema", "status": "fail", "notes": "未找到Organization"}

    def check_website_schema(self):
        """2.3 WebSite Schema (含SearchAction)"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "WebSite Schema", "status": "fail", "notes": "网站不可达"}
        text_lower = resp.text.lower()
        if '"@type"' in text_lower and '"website"' in text_lower:
            if 'searchaction' in text_lower:
                return {"check": "WebSite Schema", "status": "pass", "notes": "含SearchAction"}
            return {"check": "WebSite Schema", "status": "partial", "notes": "缺少SearchAction"}
        return {"check": "WebSite Schema", "status": "fail", "notes": "未找到WebSite"}

    def check_article_schema(self):
        """2.4 Article/BlogPosting Schema"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "Article Schema", "status": "fail", "notes": "网站不可达"}
        text_lower = resp.text.lower()
        if '"@type"' in text_lower and ('"article"' in text_lower or '"blogposting"' in text_lower):
            return {"check": "Article Schema", "status": "pass", "notes": "首页已标记"}

        # 尝试扫几个常见子路径
        for path in ['/news', '/article', '/cases', '/blog', '/案例', '/文章']:
            r = self.fetch(path)
            if r and r.status_code == 200:
                rl = r.text.lower()
                if '"@type"' in rl and ('"article"' in rl or '"blogposting"' in rl):
                    return {"check": "Article Schema", "status": "pass", "notes": f"在{path}发现"}
        return {"check": "Article Schema", "status": "partial", "notes": "未检测到Article Schema"}

    def check_breadcrumb_schema(self):
        """2.5 BreadcrumbList Schema"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "BreadcrumbList Schema", "status": "fail", "notes": "网站不可达"}
        if '"breadcrumblist"' in resp.text.lower():
            return {"check": "BreadcrumbList Schema", "status": "pass", "notes": "已标记"}
        return {"check": "BreadcrumbList Schema", "status": "partial", "notes": "未检测到"}

    def check_faq_schema(self):
        """2.6 FAQPage Schema"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "FAQPage Schema", "status": "fail", "notes": "网站不可达"}
        if '"faqpage"' in resp.text.lower():
            return {"check": "FAQPage Schema", "status": "pass", "notes": "首页已标记"}
        for path in ['/faq', '/FAQ', '/常见问题', '/question']:
            r = self.fetch(path)
            if r and r.status_code == 200 and '"faqpage"' in r.text.lower():
                return {"check": "FAQPage Schema", "status": "pass", "notes": f"在{path}发现"}
        return {"check": "FAQPage Schema", "status": "partial", "notes": "未检测到"}

    def check_localbusiness_schema(self):
        """2.7 LocalBusiness Schema"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "LocalBusiness Schema", "status": "fail", "notes": "网站不可达"}
        text_lower = resp.text.lower()
        if '"localbusiness"' in text_lower:
            return {"check": "LocalBusiness Schema", "status": "pass", "notes": "已标记"}
        # 子类型
        subtypes = ['legalService', 'attorney', 'lawyer', 'notary', 'accountantsoffice']
        if any(t.lower() in text_lower for t in subtypes):
            return {"check": "LocalBusiness Schema", "status": "pass", "notes": "子类型已标记"}
        return {"check": "LocalBusiness Schema", "status": "partial", "notes": "未检测到（对本地服务型机构重要）"}

    def check_html5_semantics(self):
        """2.8 语义化HTML5标签"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "语义化HTML5标签", "status": "fail", "notes": "网站不可达"}
        tags = ['<header', '<nav', '<main', '<article', '<section', '<footer', '<aside']
        found = [t.strip('<') for t in tags if t in resp.text.lower()]
        if len(found) >= 4:
            return {"check": "语义化HTML5标签", "status": "pass", "notes": f"使用{len(found)}种: {', '.join(found)}"}
        if len(found) >= 2:
            return {"check": "语义化HTML5标签", "status": "partial", "notes": f"仅{len(found)}种: {', '.join(found)}"}
        return {"check": "语义化HTML5标签", "status": "fail", "notes": "缺少HTML5语义标签"}

    def check_schema_validates(self):
        """2.9 Schema验证"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "Schema验证", "status": "fail", "notes": "网站不可达"}
        blocks = re.findall(
            r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
            resp.text, re.DOTALL
        )
        if not blocks:
            return {"check": "Schema验证", "status": "fail", "notes": "无JSON-LD可验证"}
        valid = 0
        invalid = 0
        for block in blocks:
            try:
                json.loads(block)
                valid += 1
            except json.JSONDecodeError:
                invalid += 1
        if invalid == 0:
            return {"check": "Schema验证", "status": "pass", "notes": f"{valid}个全部有效"}
        return {"check": "Schema验证", "status": "partial", "notes": f"{valid}有效 {invalid}无效"}

    # =============================================
    # 维度三：内容可引用性 (14项)
    # =============================================

    def check_opening_sentence(self):
        """3.1 首段含直接回答句/核心主张"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "首段含核心主张", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "首段含核心主张", "status": "fail", "notes": "解析失败"}

        # 提取正文前100个中文字符
        for tag in soup.find_all(['script', 'style', 'nav', 'header', 'footer', 'meta']):
            tag.decompose()
        text = soup.get_text(separator='')
        text = re.sub(r'\s+', '', text)
        first_100 = text[:100]

        if len(first_100) < 20:
            return {"check": "首段含核心主张", "status": "partial", "notes": "首页正文量不足"}

        # 检查是否含品牌名、核心业务词
        biz_keywords = ['律师', '律所', '法律', '服务', '咨询', '代理', '诉讼', '辩护',
                       '专注', '专业', '团队', '机构', '中心', '平台', '公司', '集团',
                       '提供', '致力于', '成立于', '位于', '地址']
        has_biz = any(kw in first_100 for kw in biz_keywords)
        if has_biz:
            return {"check": "首段含核心主张", "status": "pass", "notes": "首段含业务关键词"}
        return {"check": "首段含核心主张", "status": "partial", "notes": "建议在开篇明确核心定位"}

    def check_content_structure(self):
        """3.2 结构化内容格式"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "结构化内容格式", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "结构化内容格式", "status": "fail", "notes": "解析失败"}

        has_h2 = bool(soup.find_all('h2'))
        has_p = bool(soup.find_all('p'))
        has_ul = bool(soup.find_all(['ul', 'ol']))

        score = sum([has_h2, has_p, has_ul])
        if score >= 3:
            return {"check": "结构化内容格式", "status": "pass", "notes": "内容结构完整"}
        if score >= 1:
            return {"check": "结构化内容格式", "status": "partial", "notes": "内容结构有待完善"}
        return {"check": "结构化内容格式", "status": "fail", "notes": "内容结构严重不足"}

    def check_faq_format(self):
        """3.3 FAQ以Q&A格式呈现"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "FAQ以Q&A格式呈现", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "FAQ以Q&A格式呈现", "status": "fail", "notes": "解析失败"}

        # 查找FAQ相关标签或Q&A模式
        text = resp.text.lower()
        faq_signals = ['常见问题', 'faq', '问答', 'q&a', 'q：', 'a：', 'q:', 'a:',
                       '<dt>', '<dd>', 'question', 'answer']
        found = [s for s in faq_signals if s in text]
        if found:
            return {"check": "FAQ以Q&A格式呈现", "status": "pass", "notes": f"检测到FAQ元素"}
        return {"check": "FAQ以Q&A格式呈现", "status": "partial", "notes": "建议添加FAQ板块"}

    def check_brand_in_opening(self):
        """3.4 品牌名在首段"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "品牌名在首段", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "品牌名在首段", "status": "fail", "notes": "解析失败"}

        for tag in soup.find_all(['script', 'style', 'nav', 'meta']):
            tag.decompose()
        text = soup.get_text(separator='')
        text = re.sub(r'\s+', '', text)
        first_150 = text[:150]

        # 从title提取品牌名
        title = soup.title.string if soup.title else ''
        brand_candidates = []
        for delimiter in ['-', '|', '—', '–', '_']:
            if delimiter in title:
                brand_candidates.append(title.split(delimiter)[0].strip())

        # 检查品牌名是否在首段
        domain_name = self.domain.split('.')[0]
        if domain_name in first_150:
            return {"check": "品牌名在首段", "status": "pass", "notes": f"品牌名'{domain_name}'在首段"}

        for bc in brand_candidates:
            if bc and len(bc) >= 2 and bc in first_150:
                return {"check": "品牌名在首段", "status": "pass", "notes": f"品牌名在首段"}

        return {"check": "品牌名在首段", "status": "partial", "notes": "建议首段明确品牌名称"}

    def check_data_citations(self):
        """3.5 数据有引用来源"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "数据有引用来源", "status": "fail", "notes": "网站不可达"}

        text_lower = resp.text.lower()
        citation_patterns = ['据.*?显示', '根据.*?统计', '来源', '数据来源', '参考',
                            'according to', 'source:', 'ref']
        has_data = bool(re.search(r'\d+%|\d+万|\d+亿|\d+人', text_lower))
        has_citation = any(re.search(p, text_lower) for p in citation_patterns)

        if not has_data:
            return {"check": "数据有引用来源", "status": "pass", "notes": "首页未引用数据（通过）"}

        if has_citation:
            return {"check": "数据有引用来源", "status": "pass", "notes": "数据含引用来源"}
        return {"check": "数据有引用来源", "status": "partial", "notes": "引用了数据但未标注来源"}

    def check_header_hierarchy(self):
        """3.6 标题层级清晰"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "标题层级清晰", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "标题层级清晰", "status": "fail", "notes": "解析失败"}

        h1_count = len(soup.find_all('h1'))
        h2_count = len(soup.find_all('h2'))
        h3_count = len(soup.find_all('h3'))

        if h1_count == 0:
            return {"check": "标题层级清晰", "status": "fail", "notes": "缺少H1标签"}

        if h1_count >= 1 and h2_count >= 1:
            return {"check": "标题层级清晰", "status": "pass",
                   "notes": f"H1:{h1_count} H2:{h2_count} H3:{h3_count}"}
        return {"check": "标题层级清晰", "status": "partial",
               "notes": f"H1:{h1_count} H2:{h2_count} H3:{h3_count}（建议增加H2）"}

    def check_about_page(self):
        """3.7 关于我们定义品牌身份"""
        for path in ['/about', '/About', '/gywm', '/关于我们', '/about-us', '/aboutus']:
            resp = self.fetch(path)
            if resp and resp.status_code == 200:
                text_len = len(resp.text)
                if text_len > 500:
                    return {"check": "关于我们定义品牌身份", "status": "pass",
                           "notes": f"{path}存在（{text_len}字符）"}
        return {"check": "关于我们定义品牌身份", "status": "partial", "notes": "未找到关于我们页面"}

    def check_keyword_coverage(self):
        """3.8 行业关键词自然分布"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "行业关键词自然分布", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "行业关键词自然分布", "status": "fail", "notes": "解析失败"}

        for tag in soup.find_all(['script', 'style', 'nav', 'meta']):
            tag.decompose()
        text = soup.get_text(separator='')
        text = re.sub(r'\s+', ' ', text).lower()

        # 通用的业务关键词检测（不限于特定行业）
        biz_terms = [
            '服务', '专业', '团队', '咨询', '客户', '案例', '解决', '方案',
            '行业', '优势', '经验', '资质', '认证', '品牌', '承诺', '保障',
            '热线', '地址', '联系', '电话', '邮箱', '预约', '免费'
        ]
        found = [t for t in biz_terms if t in text]

        if len(found) >= 10:
            return {"check": "行业关键词自然分布", "status": "pass", "notes": f"覆盖{len(found)}个业务关键词"}
        if len(found) >= 5:
            return {"check": "行业关键词自然分布", "status": "partial", "notes": f"仅{len(found)}个关键词"}
        return {"check": "行业关键词自然分布", "status": "partial", "notes": "关键词覆盖不足"}

    def check_content_freshness(self):
        """3.9 内容时效性"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "内容时效性", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "内容时效性", "status": "fail", "notes": "解析失败"}

        # 查找日期相关标记
        date_patterns = [
            r'20\d{2}[-/年]\d{1,2}[-/月]\d{1,2}',
            r'\d{4}-\d{2}-\d{2}',
            r'发布于|更新时间|发布时间|date',
        ]
        has_date = any(re.search(p, resp.text, re.IGNORECASE) for p in date_patterns)

        if has_date:
            return {"check": "内容时效性", "status": "pass", "notes": "日期标记可见"}
        return {"check": "内容时效性", "status": "partial", "notes": "缺少内容日期标记"}

    def check_author_authority(self):
        """4.7 作者/机构权威信息可见"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "作者权威信息", "status": "fail", "notes": "网站不可达"}
        soup = self.parse(resp)
        if not soup:
            return {"check": "作者权威信息", "status": "fail", "notes": "解析失败"}
        # 检测作者/机构权威信号
        author_signals = [
            'author', '作者', '专家', '资质', '认证',
            '证书', '荣誉', '协会', '职称', '从业',
            '经验', '年限', '团队', '创始人', '合伙人'
        ]
        text = soup.get_text().lower()
        found = [s for s in author_signals if s in text]
        # 也检测结构化作者信息
        meta_author = soup.find('meta', attrs={'name': 'author'})
        has_structured_author = bool(meta_author and meta_author.get('content', '').strip())
        if has_structured_author and len(found) >= 3:
            return {"check": "作者权威信息", "status": "pass",
                   "notes": f"author meta + {len(found)}个权威信号"}
        if len(found) >= 5:
            return {"check": "作者权威信息", "status": "pass",
                   "notes": f"检测到{len(found)}个权威信号"}
        if len(found) >= 2:
            return {"check": "作者权威信息", "status": "partial",
                   "notes": f"仅{len(found)}个权威信号，建议增加作者介绍"}
        return {"check": "作者权威信息", "status": "partial",
                "notes": "缺少作者/机构权威信息"}

    def check_multimodal_content(self):
        """4.11 多模态内容补充"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "多模态内容", "status": "fail", "notes": "网站不可达"}
        soup = self.parse(resp)
        if not soup:
            return {"check": "多模态内容", "status": "fail", "notes": "解析失败"}
        # 检测图片
        images = soup.find_all('img')
        images_with_alt = [img for img in images if img.get('alt', '').strip()]
        # 检测视频
        videos = soup.find_all('video') + soup.find_all('iframe')
        has_images = len(images) > 0
        has_alt = len(images_with_alt) > 0
        has_video = len(videos) > 0
        if has_video:
            return {"check": "多模态内容", "status": "pass",
                   "notes": f"图片{len(images)}张+视频{len(videos)}个"}
        if has_alt and len(images_with_alt) >= 3:
            return {"check": "多模态内容", "status": "pass",
                   "notes": f"{len(images)}张图片(含alt)"}
        if has_images:
            alt_ratio = len(images_with_alt) / len(images) if images else 0
            if alt_ratio >= 0.5:
                return {"check": "多模态内容", "status": "pass", "notes": f"图片alt覆盖{alt_ratio:.0%}"}
            return {"check": "多模态内容", "status": "partial",
                   "notes": f"图片{len(images)}张，alt覆盖仅{alt_ratio:.0%}"}
        return {"check": "多模态内容", "status": "partial", "notes": "缺少多媒体内容补充"}

    def check_cross_platform_consistency(self):
        """4.12 跨平台品牌信息一致性"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "跨平台信息一致性", "status": "fail", "notes": "网站不可达"}
        soup = self.parse(resp)
        if not soup:
            return {"check": "跨平台信息一致性", "status": "fail", "notes": "解析失败"}
        # 检测是否有指向外部平台的链接
        external_platforms = [
            'zhihu.com', 'baike.baidu.com', 'baijiahao.baidu.com',
            'weibo.com', 'douyin.com', 'mp.weixin.qq.com',
            'xiaohongshu.com', 'bilibili.com', 'toutiao.com'
        ]
        links = soup.find_all('a', href=True)
        found_platforms = set()
        for link in links:
            href = link['href']
            for plat in external_platforms:
                if plat in href:
                    found_platforms.add(plat)
        if len(found_platforms) >= 2:
            return {"check": "跨平台信息一致性", "status": "pass",
                   "notes": f"链接到{len(found_platforms)}个外部平台"}
        if len(found_platforms) >= 1:
            return {"check": "跨平台信息一致性", "status": "partial",
                   "notes": f"仅链接到{len(found_platforms)}个外部平台"}
        return {"check": "跨平台信息一致性", "status": "partial",
                "notes": "未检测到外部平台链接（建议建立多平台矩阵）"}

    def check_tables_lists(self):
        """4.13 结构化表格与列表使用"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "表格列表使用", "status": "fail", "notes": "网站不可达"}
        soup = self.parse(resp)
        if not soup:
            return {"check": "表格列表使用", "status": "fail", "notes": "解析失败"}
        tables = len(soup.find_all('table'))
        ol = len(soup.find_all('ol'))
        ul = len(soup.find_all('ul'))
        total_lists = ol + ul
        if tables >= 1 and total_lists >= 3:
            return {"check": "表格列表使用", "status": "pass",
                   "notes": f"表{tables}个 列表{total_lists}组"}
        if tables >= 1 or total_lists >= 3:
            return {"check": "表格列表使用", "status": "partial",
                   "notes": f"表{tables}个 列表{total_lists}组（建议两者都有）"}
        if total_lists >= 1:
            return {"check": "表格列表使用", "status": "partial",
                   "notes": f"仅{total_lists}组列表，缺少表格"}
        return {"check": "表格列表使用", "status": "partial",
                "notes": "缺少表格和列表（AI偏好结构化数据呈现）"}

    def check_external_citations(self):
        """4.14 外部引用域名数量"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "外部引用域名", "status": "fail", "notes": "网站不可达"}
        soup = self.parse(resp)
        if not soup:
            return {"check": "外部引用域名", "status": "fail", "notes": "解析失败"}
        # 提取所有外部链接的唯一域名
        links = soup.find_all('a', href=True)
        external_domains = set()
        for link in links:
            href = link['href'].strip()
            if not href or href.startswith('#') or href.startswith('javascript'):
                continue
            if '://' not in href and not href.startswith('//'):
                continue
            parsed = urlparse(href)
            domain = parsed.netloc.lower()
            if domain and domain != self.domain and 'www.' + domain != self.domain:
                external_domains.add(domain)
        count = len(external_domains)
        if count >= 10:
            return {"check": "外部引用域名", "status": "pass",
                   "notes": f"{count}个唯一外部域名"}
        if count >= 5:
            return {"check": "外部引用域名", "status": "pass",
                   "notes": f"{count}个外部域名（良好）"}
        if count >= 2:
            return {"check": "外部引用域名", "status": "partial",
                   "notes": f"仅{count}个外部域名（建议丰富引用来源）"}
        return {"check": "外部引用域名", "status": "partial",
                "notes": f"仅{count}个外部域名（建议增加权威引用）"}

    # =============================================
    # 维度四：合规与生态集成 (10项)
    # =============================================

    def check_icp(self):
        """4.1 ICP备案号"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "ICP备案号", "status": "fail", "notes": "网站不可达"}

        # ICP备案号格式：XICP备XXXXXXXX号
        icp_pattern = r'[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤川青藏琼宁]ICP[备证]\d{6,10}号?(-\d+)?'
        if re.search(icp_pattern, resp.text):
            return {"check": "ICP备案号", "status": "pass", "notes": "备案号存在"}

        # 宽松匹配
        if 'ICP' in resp.text and '备' in resp.text:
            return {"check": "ICP备案号", "status": "pass", "notes": "检测到备案信息"}
        return {"check": "ICP备案号", "status": "fail", "notes": "缺少ICP备案号（国内网站强制要求）"}

    def check_https(self):
        """4.2 HTTPS强制"""
        try:
            resp = requests.get(f"http://{self.domain}",
                              headers=self.headers,
                              timeout=self.timeout,
                              allow_redirects=True, verify=False)
            if resp.url.startswith('https://'):
                return {"check": "HTTPS强制", "status": "pass", "notes": "HTTP自动跳转HTTPS"}
            return {"check": "HTTPS强制", "status": "fail", "notes": "HTTP未跳转HTTPS"}
        except Exception:
            # 尝试直接HTTPS
            resp2 = self.fetch('/')
            if resp2 and resp2.url.startswith('https://'):
                return {"check": "HTTPS强制", "status": "pass", "notes": "HTTPS可用"}
            return {"check": "HTTPS强制", "status": "fail", "notes": "HTTPS不可用"}

    def check_cdn_hosting(self):
        """2.6 国内CDN/本土托管"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "国内CDN托管", "status": "fail", "notes": "网站不可达"}
        # 检测国内CDN特征
        cdn_signals = ['aliyun', 'alicdn', 'qcloud', 'tencent', 'myqcloud',
                      'qiniu', 'upyun', 'bdstatic', 'cloudflare',
                      'x-cache', 'via', 'cdn', 'chinanet']
        headers_found = []
        for header, value in resp.headers.items():
            h_lower = f"{header}: {value}".lower()
            for sig in cdn_signals:
                if sig in h_lower:
                    headers_found.append(sig)
                    break
        if headers_found:
            return {"check": "国内CDN托管", "status": "pass",
                   "notes": f"CDN特征: {', '.join(headers_found[:3])}"}
        # 如果没检测到CDN，标记partial（不在国内托管不一定失败）
        return {"check": "国内CDN托管", "status": "partial",
               "notes": "未检测到CDN特征（海外用户建议使用国内CDN）"}

    def check_url_semantics(self):
        """2.7 URL结构语义化"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "URL结构语义化", "status": "fail", "notes": "网站不可达"}
        # 检查首页URL是否含参数
        parsed = urlparse(resp.url)
        if parsed.query:
            return {"check": "URL结构语义化", "status": "partial",
                   "notes": "首页URL含查询参数"}
        # 检查HTML中的链接是否语义化
        soup = self.parse(resp)
        if not soup:
            return {"check": "URL结构语义化", "status": "fail", "notes": "解析失败"}
        links = soup.find_all('a', href=True)[:20]
        param_links = 0
        for link in links:
            href = link['href']
            if '?' in href and 'javascript' not in href and '#' not in href:
                param_links += 1
        if param_links == 0:
            return {"check": "URL结构语义化", "status": "pass", "notes": "URL结构清晰"}
        if param_links <= 3:
            return {"check": "URL结构语义化", "status": "partial",
                   "notes": f"部分链接含参数({param_links}/20)"}
        return {"check": "URL结构语义化", "status": "partial",
               "notes": f"较多链接含参数({param_links}/20)"}

    def check_no_malicious_popup(self):
        """2.8 无恶意跳转/过度广告弹窗"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "无恶意弹窗", "status": "fail", "notes": "网站不可达"}
        # 检测常见弹窗/广告特征
        popup_signals = [
            'window.open', 'confirm(', 'alert(',
            'popup', 'modal', 'overlay',
            '广告', 'ad-block', 'advertisement',
            '疯狂', '限时', '抢购'
        ]
        text_lower = resp.text.lower()
        found = [s for s in popup_signals if s.lower() in text_lower]
        if len(found) <= 1:
            return {"check": "无恶意弹窗", "status": "pass", "notes": "无明显弹窗特征"}
        if len(found) <= 3:
            return {"check": "无恶意弹窗", "status": "partial",
                   "notes": f"检测到弹窗信号: {', '.join(found)}"}
        return {"check": "无恶意弹窗", "status": "partial",
               "notes": f"较多弹窗信号: {', '.join(found[:4])}..."}

    def check_baidu_integration(self):
        """4.3 百度站长平台接入"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "百度站长平台接入", "status": "fail", "notes": "网站不可达"}
        if 'baidu-site-verification' in resp.text:
            code = re.search(r'baidu-site-verification["\']?\s*content=["\']([^"\']+)', resp.text)
            return {"check": "百度站长平台接入", "status": "pass",
                   "notes": f"验证码存在 ({code.group(1)[:8]}...)" if code else "验证标签存在"}
        return {"check": "百度站长平台接入", "status": "partial", "notes": "未检测到百度验证（非强制但推荐）"}

    def check_og_tags(self):
        """4.4 Open Graph标签"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "Open Graph标签", "status": "fail", "notes": "网站不可达"}

        og_tags = ['og:title', 'og:description', 'og:image', 'og:url']
        found = 0
        for tag in og_tags:
            if f'property="{tag}"' in resp.text or f"property='{tag}'" in resp.text:
                found += 1

        if found == 4:
            return {"check": "Open Graph标签", "status": "pass", "notes": "4/4完整"}
        if found >= 2:
            return {"check": "Open Graph标签", "status": "partial", "notes": f"{found}/4个标签"}
        return {"check": "Open Graph标签", "status": "fail", "notes": f"仅{found}/4个标签"}

    def check_wechat_share(self):
        """4.5 微信分享兼容"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "微信分享兼容", "status": "fail", "notes": "网站不可达"}

        soup = self.parse(resp)
        if not soup:
            return {"check": "微信分享兼容", "status": "fail", "notes": "解析失败"}

        # 微信分享优先读取 description meta
        desc = soup.find('meta', attrs={'name': 'description'})
        # 也检查微信JS-SDK
        has_wx_sdk = 'jweixin-1' in resp.text or 'wx.config' in resp.text

        if desc and desc.get('content', '').strip():
            if has_wx_sdk:
                return {"check": "微信分享兼容", "status": "pass", "notes": "description+JS-SDK"}
            return {"check": "微信分享兼容", "status": "pass", "notes": "description标签存在"}
        if has_wx_sdk:
            return {"check": "微信分享兼容", "status": "partial", "notes": "有JS-SDK但缺少description"}
        return {"check": "微信分享兼容", "status": "fail", "notes": "缺少description和微信JS-SDK"}

    def check_canonical_resolve(self):
        """4.6 Canonical标签正确解析"""
        resp = self.fetch('/')
        if not resp:
            return {"check": "Canonical标签正确解析", "status": "fail", "notes": "网站不可达"}

        canonical = re.search(
            r'<link[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']*)',
            resp.text, re.IGNORECASE
        )
        if not canonical:
            return {"check": "Canonical标签正确解析", "status": "fail", "notes": "无canonical标签"}

        href = canonical.group(1)
        try:
            canon_resp = self.fetch(href)
            if canon_resp and canon_resp.status_code == 200:
                return {"check": "Canonical标签正确解析", "status": "pass", "notes": f"canonical返回200"}
            return {"check": "Canonical标签正确解析", "status": "fail", "notes": f"canonical返回{canon_resp.status_code if canon_resp else '不可达'}"}
        except Exception:
            return {"check": "Canonical标签正确解析", "status": "fail", "notes": "canonical URL不可达"}

    def check_404(self):
        """4.7 404状态码正确"""
        resp = self.fetch('/nonexistent-page-gco-404-test-2024')
        if not resp:
            return {"check": "404状态码正确", "status": "fail", "notes": "测试失败"}
        if resp.status_code == 404:
            return {"check": "404状态码正确", "status": "pass", "notes": "返回404"}
        if resp.status_code == 200:
            return {"check": "404状态码正确", "status": "fail", "notes": "返回200（软404）"}
        return {"check": "404状态码正确", "status": "partial", "notes": f"返回{resp.status_code}"}

    # =============================================
    # 审计引擎
    # =============================================

    def calculate_grade(self, score):
        if score >= 90: return "A+"
        if score >= 80: return "A"
        if score >= 70: return "B"
        if score >= 60: return "C"
        if score >= 50: return "D"
        return "F"

    def run_full_audit(self, dimension=None):
        all_checks = {
            "AI可访问性": [
                self.check_robots_txt,
                self.check_intl_robots,
                self.check_baidu_verification,
                self.check_performance,
                self.check_js_rendering,
                self.check_accessibility,
                self.check_mobile_viewport,
                self.check_raw_html_content,
                self.check_sitemap,
                self.check_baidu_push,
                self.check_llms_txt,
            ],
            "技术配置": [
                self.check_https,
                self.check_canonical_consistency,
                self.check_canonical_resolve,
                self.check_noindex,
                self.check_404,
                self.check_cdn_hosting,
                self.check_url_semantics,
                self.check_no_malicious_popup,
                self.check_icp,
                self.check_og_tags,
            ],
            "结构化数据": [
                self.check_jsonld_present,
                self.check_organization_schema,
                self.check_website_schema,
                self.check_article_schema,
                self.check_breadcrumb_schema,
                self.check_faq_schema,
                self.check_localbusiness_schema,
                self.check_html5_semantics,
                self.check_schema_validates,
                self.check_wechat_share,
            ],
            "内容可引用性": [
                self.check_opening_sentence,
                self.check_brand_in_opening,
                self.check_content_structure,
                self.check_faq_format,
                self.check_header_hierarchy,
                self.check_data_citations,
                self.check_author_authority,
                self.check_keyword_coverage,
                self.check_content_freshness,
                self.check_about_page,
                self.check_multimodal_content,
                self.check_cross_platform_consistency,
                self.check_tables_lists,
                self.check_external_citations,
            ],
        }

        dim_map = {
            "accessibility": "AI可访问性",
            "technical": "技术配置",
            "schema": "结构化数据",
            "content": "内容可引用性",
        }

        # 维度权重：按45项比例映射到100分
        dimension_weights = {
            "AI可访问性": 24,    # 11/45 ≈ 24%
            "技术配置": 22,      # 10/45 ≈ 22%
            "结构化数据": 22,    # 10/45 ≈ 22%
            "内容可引用性": 32,  # 14/45 ≈ 32%
        }

        if dimension:
            dim_name = dim_map.get(dimension, dimension)
            checks_to_run = {dim_name: all_checks.get(dim_name, [])}
        else:
            checks_to_run = all_checks

        total_score = 0
        for dim_name, checks in checks_to_run.items():
            print(f"\n📊 审计中: {dim_name}", file=sys.stderr)
            dim_raw = 0
            dim_results = []
            for check_fn in checks:
                result = check_fn()
                points = {"pass": 1, "fail": 0, "partial": 0.5}.get(result["status"], 0)
                dim_raw += points
                icon = {"pass": "✅", "fail": "❌", "partial": "⚠️"}.get(result["status"], "?")
                print(f"  {icon} {result['check']}", file=sys.stderr)
                dim_results.append(result)
            # 加权到100分制
            dim_total = len(checks)
            dim_weight = dimension_weights.get(dim_name, dim_total)
            weighted_score = dim_raw / dim_total * dim_weight
            total_score += weighted_score
            self.results["dimensions"].append({
                "name": dim_name,
                "score": round(dim_raw, 1),
                "total": dim_total,
                "weighted_score": round(weighted_score, 1),
                "weight": dim_weight,
                "percentage": round(dim_raw / dim_total * 100),
                "checks": dim_results,
            })

        self.results["score"] = round(total_score, 1)
        self.results["grade"] = self.calculate_grade(total_score)
        return self.results

    def format_markdown(self, results):
        lines = [
            f"# 中国版 GEO 就绪度审计报告",
            "",
            f"**网站:** {results['site']}",
            f"**审计时间:** {results['timestamp']}",
            f"**得分:** {results['score']}/{results['total']} (**{results['grade']}**)",
            "",
            "## 维度总览",
            "",
        ]

        for dim in results["dimensions"]:
            bar_len = 10
            filled = int(dim["score"] / dim["total"] * bar_len)
            bar = "█" * filled + "░" * (bar_len - filled)
            lines.append(f"### {dim['name']}: {dim['weighted_score']}/{dim['weight']} ({dim['percentage']}%)")
            lines.append("")
            lines.append(f"`{bar}`")
            lines.append("")
            for check in dim["checks"]:
                icon = {"pass": "✅", "fail": "❌", "partial": "⚠️"}.get(check["status"], "?")
                lines.append(f"- {icon} **{check['check']}**: {check['notes']}")
            lines.append("")

        return "\n".join(lines)

    def format_json(self, results):
        return json.dumps(results, ensure_ascii=False, indent=2)


def main():
    parser = argparse.ArgumentParser(description="中国版 GEO 就绪度审计工具")
    parser.add_argument("domain", help="目标域名或URL")
    parser.add_argument("--output", choices=["json", "md", "markdown"], default="md",
                       help="输出格式")
    parser.add_argument("--dimension", choices=["accessibility", "schema", "content", "compliance"],
                       help="仅审计特定维度")
    parser.add_argument("--timeout", type=int, default=15, help="请求超时（秒）")
    parser.add_argument("--delay", type=float, default=0.5, help="请求间隔（秒）")
    parser.add_argument("--user-agent", help="自定义User-Agent")
    args = parser.parse_args()

    auditor = CNGEOAuditor(
        args.domain,
        timeout=args.timeout,
        delay=args.delay,
        user_agent=args.user_agent,
    )

    results = auditor.run_full_audit(dimension=args.dimension)

    if args.output == "json":
        print(auditor.format_json(results))
    else:
        print(auditor.format_markdown(results))


if __name__ == "__main__":
    main()
