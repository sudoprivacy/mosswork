---
name: skillhub-skill-cn-aiq-research
description: "# AIQ 研究技能"
---

# AIQ 研究技能

## 目的

使用此技能通过 `scripts/aiq.py` 辅助脚本调用本地运行的 NVIDIA AI-Q Blueprint 服务器。

此技能适用于研究类型的请求，包括：

- "深度研究关于..."
- "AIQ 研究..."
- "研究..."
- "使用 AI-Q 回答..."
- "向 AI-Q 询问..."

不要将此技能用于安装、部署、启动、停止、UI、CLI、Docker、Helm 或故障排查请求。这些属于 `aiq-deploy`。

## 前置条件

用户需要：

- Python 3.11+ 可作为 `python3` 使用。
- 可访问的本地或自托管 AI-Q Blueprint 后端。
- 当后端不在 `http://localhost:8000` 上运行时需要设置 `AIQ_SERVER_URL`；非本地值必须在发送任何查询前由用户确认可信。
- 后端已配置为对此公共辅助脚本禁用认证，或为需要认证的环境使用单独的已认证 AI-Q 技能。
- 本地机器到 AI-Q 后端 URL 的网络访问。
- 凭据配置在后端环境中，而非此技能中。此公共辅助脚本不收集或管理 API 密钥。

辅助脚本无第三方 Python 包依赖；它使用 Python 标准库的 HTTP 模块。

## 操作步骤

1. 确定目标后端 URL。
2. 在发送研究请求前运行 `health`。
3. 如果后端不可访问，询问后端 URL 或移交给 `aiq-deploy`。
4. 在发送任何用户查询前，声明将接收该查询的确切 AI-Q 后端 URL。对于非本地 URL，仅在用户明确确认该 URL 在当前对话中可信后方可继续。
5. 当 AI-Q 返回作业 ID 时，轮询异步深度研究作业。
6. 呈现返回的报告，保留引用和来源 URL 完整。
7. 作业失败时停止并显示返回的错误；不要自动重试。
8. 呈现报告后，支持后续操作：回答问题（`ask`）或使用相同命令重新运行精细化研究（`redo`）。

### 步骤 1 - 确定后端

已设置时使用 `AIQ_SERVER_URL`。否则尝试默认的本地后端：

```bash
python3 $SKILL_DIR/scripts/aiq.py health
```

预期输出：来自可访问的 AI-Q 健康端点的 JSON。

如果 `health` 失败且未设置显式的 `AIQ_SERVER_URL`，请询问：

```text
I do not see a reachable local AI-Q backend. Do you already have an AI-Q backend URL you want to use, or should I deploy a local Skill backend?
```

- 如果用户提供 URL，设置 `AIQ_SERVER_URL` 用于后续辅助脚本调用并重新运行 `health`。
- 如果用户想要本地部署，移交给 `aiq-deploy` 并保留原始研究请求。
- 如果可访问的后端返回 `401` 或 `403`，停止并解释此公共技能不管理认证。请用户使用已认证的 AI-Q 技能或为其环境配置认证。
- 如果 `health` 成功但 `/chat` 或 `/v1/jobs/async/agents` 失败，报告后端可访问但不兼容此公共研究工作流，然后提供运行 `aiq-deploy` 验证。

### 步骤 2 - 发送路由的研究请求

在发送请求前，声明已确定的端点：

```text
I will send this query to <AIQ_SERVER_URL>. Make sure this endpoint is trusted before sending sensitive information.
```

不要通过查询文本发送凭据、cookies、承载令牌或密钥值。

运行：

```bash
python3 $SKILL_DIR/scripts/aiq.py chat "<USER_QUESTION>"
```

预期输出：

- 用于浅层或直接回答的普通 JSON 响应。
- 或包含 `{"status": "deep_research_running", "job_id": "<JOB_ID>"}` 的结构化 JSON，用于异步深度研究。

如果响应是普通 JSON，立即呈现结果。在没有 `job_id` 时不要强制轮询。

### 步骤 3 - 轮询异步作业

如果响应包含 `deep_research_running`，提取 `job_id` 并使用相同绝对脚本路径进行轮询：

```bash
python3 $SKILL_DIR/scripts/aiq.py research_poll <JOB_ID>
```

预期输出：作业成功完成时的最终报告 JSON。

在可用时使用运行时的非阻塞或后台执行机制。如果所选执行方法需要升级权限，请先请求用户明确批准并解释原因。告知用户深度研究正在后台运行。

### 步骤 4 - 中断后恢复

如果轮询被中断，作业会在服务器端继续运行。使用以下命令恢复：

```bash
python3 $SKILL_DIR/scripts/aiq.py status <JOB_ID>
python3 $SKILL_DIR/scripts/aiq.py report <JOB_ID>
python3 $SKILL_DIR/scripts/aiq.py research_poll <JOB_ID>
```

使用 `status` 检查作业状态和已保存的制品。当作业已完成且只需要最终输出时使用 `report`。使用 `research_poll` 继续等待完成。

最终报告可能以 `artifact://<id>` 链接引用生成的制品（图表、CSV）。要将其物化为本地文件，运行 `python3 $SKILL_DIR/scripts/aiq.py artifacts <JOB_ID> --download-dir ./aiq-artifacts`；它会下载每个制品并打印本地路径。不要期望报告本身包含 base64 图像数据。

对于自包含、可分享的报告，运行 `python3 $SKILL_DIR/scripts/aiq.py report <JOB_ID> --out-dir ./my-report`。它会写入 `report.md` 和一个 `artifacts/` 文件夹，并将每个 `artifact://<id>` 链接重写为匹配的本地文件，使报告（包括图表等）在任何 markdown 查看器中无需运行后端即可渲染。

### 步骤 5 - 呈现报告

当 `research_poll` 成功完成时，获取并呈现完整报告。保持引用和来源 URL 完整。如果作业状态为 `failed`、`failure` 或 `cancelled`，显示状态响应中的错误并询问用户是否希望使用更窄的查询或不同的方法重试。

### 步骤 6 - 后续操作：询问、编辑或重做报告

呈现报告后，用户通常希望深入探讨或调整范围。重用现有的后端流程——相同的认证边界、轮询和报告获取（步骤 1-5）均适用；没有独立的后续端点。

**询问**——针对已有的报告提出问题：

- 如果问题可以从已有报告中直接回答，直接根据其内容和引用回答；不要再次调用后端。
- 如果问题需要新的调查，发送一个携带先前问题和报告的必要上下文的新请求，然后呈现新结果：

  ```bash
  python3 $SKILL_DIR/scripts/aiq.py chat "<FOLLOW_UP_QUESTION> (context: <PRIOR_TOPIC>)"
  ```

  如果返回了 `deep_research_running` 作业 ID，像步骤 3 一样使用 `research_poll` 轮询。

**编辑**——对报告进行外观性修改。此技能只能访问用于生成初始报告的数据。没有可用工具：

```bash
python3 $SKILL_DIR/scripts/aiq.py report_edit <JOB_ID> "<EDIT_INSTRUCTIONS>"
```

**重做**——使用调整后的范围重新运行研究（更窄的查询、修正的问题或不同的深度）：

```bash
python3 $SKILL_DIR/scripts/aiq.py research "<REFINED_QUERY>" [agent_type]
```

- 选择 `agent_type` 以匹配所需深度（例如，使用 `deep` agent 进行深入分析，或使用 `shallow_researcher` 进行快速调查）；如果不确定，使用 `agents` 列出选项。
- 将重做视为新作业：在发送前再次声明目标端点（步骤 2），然后按照步骤 3-5 进行轮询和呈现。

不要在后续查询文本中发送凭据或密钥值，并在每个后续回答中保持引用和来源 URL 完整。

## 版本兼容性

**重要提示：** 此技能专为 NVIDIA AI-Q Blueprint 2.1.0 版本设计。

语义化版本兼容性规则：

```text
Skill version: X.Y.Z
Blueprint or endpoint version: A.B.C

Compatible IF:
1. A == X (Major versions MUST match)
2. B >= Y (Minor version must be equal or greater)
3. C can be anything (Patch version does not affect compatibility)
```

示例：

- Skill 2.1.0 版与 Blueprint 2.1.0 版兼容。
- Skill 2.1.0 版与 Blueprint 2.2.0 版兼容。
- Skill 2.1.0 版与 Blueprint 2.1.5 版兼容。
- Skill 2.1.0 版与 Blueprint 3.0.0 版不兼容。
- Skill 2.1.0 版与 Blueprint 2.0.0 版不兼容。

如果您的 Blueprint 版本不兼容：

1. 检查是否有与您的 Blueprint 版本匹配的更新版本技能。
2. 使用与此技能兼容的 Blueprint 版本。
3. 仅在用户接受兼容性风险时谨慎继续；API 路由或响应格式可能已更改。

## 可用脚本

| 脚本 | 用途 | 参数 |
|---|---|---|
| `scripts/aiq.py health` | 检查配置的服务器是否响应 | 无 |
| `scripts/aiq.py chat` | POST `/chat`；可能返回内联输出或深度研究作业 ID | `<query>` |
| `scripts/aiq.py agents` | 列出可用的异步 agent 类型 | 无 |
| `scripts/aiq.py submit` | 提交显式的异步作业 | `<query> [agent_type]` |
| `scripts/aiq.py research` | 提交异步作业、轮询并打印最终报告 JSON | `<query> [agent_type]` |
| `scripts/aiq.py research_poll` | 恢复轮询现有异步作业 | `<job_id>` |
| `scripts/aiq.py status` | 获取作业状态及 `/state` 制品 | `<job_id>` |
| `scripts/aiq.py state` | 仅获取事件存储制品 | `<job_id>` |
| `scripts/aiq.py report` | 获取最终报告；使用 `--out-dir DIR` 导出可移植的 `report.md` + `artifacts/` 文件夹，链接已重写为本地文件 | `<job_id> [--out-dir DIR]` |
| `scripts/aiq.py report_edit` | 对已完成的报告进行外观性编辑 | `<job_id> <edit_instructions>` |
| `scripts/aiq.py artifacts` | 列出持久化制品；使用 `--download-dir DIR` 下载并打印本地路径 | `<job_id> [--download-dir DIR]` |
| `scripts/aiq.py stream` | 从作业流式传输 SSE 事件 | `<job_id>` |
| `scripts/aiq.py cancel` | 取消运行中的作业 | `<job_id>` |

当宿主工具支持 `run_script()` 辅助函数时，使用 `scripts/aiq.py` 和上述参数调用。否则，运行等效的 shell 命令，例如 `python3 $SKILL_DIR/scripts/aiq.py health`。

## 环境变量

| 变量 | 必需 | 默认值 | 描述 |
|---|---|---|---|
| `AIQ_SERVER_URL` | 否 | `http://localhost:8000` | 本地或自托管 AI-Q 服务器基础 URL |

## 安全最佳实践

- 不要在 `AIQ_SERVER_URL` 中包含 API 密钥、承载令牌、cookies 或基本认证凭据。
- 将后端凭据存储在 AI-Q 部署环境中，而非此技能或命令示例中。
- 用户查询文本会发送到配置的 `AIQ_SERVER_URL`。在发送敏感或机密信息前确认端点可信。
- 如果后端使用私有数据源，将返回的报告视为可能敏感。
- 不要截断返回报告中的引用或来源 URL。

## 限制

- 此技能需要运行中的 AI-Q 后端；它不负责部署。
- 公共辅助脚本不管理认证令牌或 cookies。
- 远程 `AIQ_SERVER_URL` 端点可能会记录提示、响应和元数据。
- 如果后端返回 HTTP 500 或缺少异步 agent，报告失败而不是编造研究答案。

## 示例

### 示例 1：运行路由的聊天或研究请求

```bash
python3 $SKILL_DIR/scripts/aiq.py health
python3 $SKILL_DIR/scripts/aiq.py chat "Compare local AIQ deep research with a standard web search workflow"
```

预期输出：

```text
<health JSON from AI-Q>
<JSON chat response or {"status": "deep_research_running", "job_id": "<JOB_ID>"}>
```

如果 AI-Q 返回作业 ID，继续使用 `research_poll`。

### 示例 2：恢复现有作业

```bash
python3 $SKILL_DIR/scripts/aiq.py status <JOB_ID>
python3 $SKILL_DIR/scripts/aiq.py research_poll <JOB_ID>
```

将 `<JOB_ID>` 替换为 AI-Q 返回的 UUID。预期输出：作业完成时依次呈现状态 JSON 和报告 JSON。如果作业失败，显示返回的状态且不自动重试。

### 示例 3：提出后续问题或使用细化查询重做

```bash
# Ask: 需要新调查的后续问题，携带先前上下文。
python3 $SKILL_DIR/scripts/aiq.py chat "How does that compare on cost? (context: local AIQ deep research vs web search)"

# Redo: 使用更窄的查询和显式深度重新运行研究。
python3 $SKILL_DIR/scripts/aiq.py research "AIQ deep research cost on a single workstation" shallow_researcher
```

预期输出：路由的聊天响应或需要 `research_poll` 轮询的新 `deep_research_running` 作业 ID。呈现后续回答时保持引用和来源 URL 完整。

## 参考文件

| 主题 | 文档 |
|---|---|
| 辅助脚本 | `scripts/aiq.py` |
| 部署和后端验证 | `../aiq-deploy/SKILL.md` |

## 常见问题

### 问题：无法访问后端

**症状：**

- `health` 因连接被拒绝而失败。
- 默认的 `http://localhost:8000` URL 无响应。

**原因：**

- AI-Q 未运行。
- AI-Q 在不同的主机或端口上运行。
- 本地防火墙或网络设置阻止了连接。

**解决方案：**

1. 询问用户是否已有 AI-Q 后端 URL。
2. 如果用户提供 URL，设置并重新运行 health：
   ```bash
   export AIQ_SERVER_URL="http://localhost:<PORT>"
   python3 $SKILL_DIR/scripts/aiq.py health
   ```
3. 如果用户需要本地后端，移交给 `aiq-deploy` 并保留原始研究请求。

### 问题：后端需要认证

**症状：**

- 请求返回 HTTP 401 或 HTTP 403。
- 后端可访问但拒绝 `/chat` 或异步作业调用。

**原因：**

- 后端部署时启用了认证。
- 公共辅助脚本未附加用户令牌或 cookies。

**解决方案：**

1. 停止并解释此公共技能不管理认证。
2. 请用户使用已认证的 AI-Q 技能或为其后端配置此公共本地工作流。
3. 仅在认证边界解决后重新运行 `health` 和原始查询。

### 问题：Health 成功但研究路由失败

**症状：**

- `health` 成功返回。
- `/chat`、`/v1/jobs/async/agents` 或轮询命令失败。

**原因：**

- 后端未使用启用 API 的 AI-Q 配置。
- 所选后端中异步作业注册表不可用。
- 后端版本与此技能不兼容。

**解决方案：**

1. 运行：
   ```bash
   python3 $SKILL_DIR/scripts/aiq.py agents
   ```
2. 如果 agent 不可用，报告兼容性失败并提供运行 `aiq-deploy` 验证。
3. 确认部署的 Blueprint 版本与技能 2.1.0 版兼容。

### 问题：作业被中断或似乎卡住

**症状：**

- 本地轮询被中断。
- 作业一直显示 `running`。
- 轮询输出显示 `running`，但返回了报告或 cancel 提示作业已 `success`。

**原因：**

- 深度研究是异步的，在服务器端持续运行。
- 本地轮询输出可能滞后于终端服务器状态。

**解决方案：**

1. 检查当前状态：
   ```bash
   python3 $SKILL_DIR/scripts/aiq.py status <JOB_ID>
   ```
2. 如果 `has_report: true` 或 `job_status.status: success`，获取报告：
   ```bash
   python3 $SKILL_DIR/scripts/aiq.py report <JOB_ID>
   ```
3. 如果作业仍在运行，继续轮询：
   ```bash
   python3 $SKILL_DIR/scripts/aiq.py research_poll <JOB_ID>
   ```
