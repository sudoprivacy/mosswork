"""
B站视频下载脚本
================
用法: python download_bili.py <bvid_or_url>
输出: 视频流(m4s) + 音频流(m4s) + WAV(16kHz mono) + 关键帧JPG序列

支持输入:
  - 纯BVID: BV1xxxxx
  - 短链:   https://b23.tv/xxxxx
  - 长链:   https://www.bilibili.com/video/BV1xxxxx

输出路径: ~/.qclaw/workspace/bili_downloads/
文件命名: 全部用BVID（避免标题特殊字符问题）

缓存: 已存在的文件自动跳过下载/转换

依赖:
  - bilibili-api-python (>=17.4)
  - aiohttp
  - ffmpeg (自动检测: PATH > 默认安装路径)

环境变量:
  FFMPEG_PATH  可选，手动指定 ffmpeg 可执行文件路径
"""
import asyncio
import os
import re
import sys
import time
import shutil
import aiohttp
import subprocess
import urllib.request
from bilibili_api.video import Video

# ffmpeg 路径自动检测
_DEFAULT_FFMPEG_PATHS = [
    os.environ.get("FFMPEG_PATH", ""),
    shutil.which("ffmpeg") or "",
    r"C:\ProgramData\openssl\ffmpeg\bin\ffmpeg.exe",
    r"C:\ffmpeg\bin\ffmpeg.exe",
    "/usr/bin/ffmpeg",
    "/usr/local/bin/ffmpeg",
]
FFMPEG = next((p for p in _DEFAULT_FFMPEG_PATHS if p and os.path.exists(p)), None)
if not FFMPEG:
    print("❌ 未找到 ffmpeg，请安装或设置 FFMPEG_PATH 环境变量")
    sys.exit(1)

OUT_DIR = os.path.join(os.path.expanduser("~"), ".qclaw", "workspace", "bili_downloads")


def log(msg):
    """带时间戳的日志输出"""
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")


def parse_bvid(text):
    """
    从用户输入解析BVID。
    支持纯BVID、b23.tv短链、bilibili.com长链。
    """
    text = text.strip()
    if re.match(r'^BV\w+$', text):
        return text
    if not text.startswith('http'):
        text = 'https://' + text
    log(f"解析短链: {text}")
    req = urllib.request.Request(text)
    req.add_header("User-Agent", "Mozilla/5.0")
    resp = urllib.request.urlopen(req)
    m = re.search(r'BV\w+', resp.url)
    if not m:
        raise ValueError(f"无法从URL提取BVID: {resp.url}")
    bvid = m.group(0)
    log(f"解析结果: {bvid}")
    return bvid


async def download_av(bvid_or_url):
    """
    主函数：下载B站视频+音频，转WAV，提取关键帧。
    返回 dict: title, up, duration, wav_path, frames_dir, frame_count
    """
    bvid = parse_bvid(bvid_or_url)
    log(f"=== 开始处理 {bvid} ===")
    log(f"ffmpeg: {FFMPEG}")

    # 1. 获取视频信息
    log("获取视频信息...")
    v = Video(bvid=bvid)
    info = await v.get_info()
    title = info['title']
    up = info['owner']['name']
    duration = info['duration']
    log(f"标题: {title}")
    log(f"UP主: {up}")
    log(f"时长: {duration}秒")

    # 2. 获取下载URL
    log("获取下载URL...")
    page = await v.get_download_url(0)

    video_url = None
    for d in page.get("dash", {}).get("video", []):
        video_url = d["baseUrl"]
        break
    audio_url = None
    for d in page.get("dash", {}).get("audio", []):
        audio_url = d["baseUrl"]
        break

    if not video_url and not audio_url:
        log("❌ 错误: 未找到视频/音频URL（可能需要大会员）")
        return None

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": "https://www.bilibili.com"
    }

    os.makedirs(OUT_DIR, exist_ok=True)
    video_path = os.path.join(OUT_DIR, f"{bvid}_video.m4s")
    audio_path = os.path.join(OUT_DIR, f"{bvid}_audio.m4s")
    wav_path = os.path.join(OUT_DIR, f"{bvid}.wav")
    frames_dir = os.path.join(OUT_DIR, f"frames_{bvid}")
    os.makedirs(frames_dir, exist_ok=True)

    # 3. 下载视频流
    if not os.path.exists(video_path) and video_url:
        log("下载视频流...")
        t0 = time.time()
        async with aiohttp.ClientSession() as session:
            async with session.get(video_url, headers=headers) as resp:
                if resp.status == 200:
                    with open(video_path, "wb") as f:
                        async for chunk in resp.content.iter_chunked(1024 * 1024):
                            f.write(chunk)
                    elapsed = time.time() - t0
                    size_mb = os.path.getsize(video_path) / 1024 / 1024
                    log(f"✅ 视频流: {size_mb:.1f}MB, 耗时{elapsed:.1f}秒")
                else:
                    log(f"❌ 视频下载失败: HTTP {resp.status}")
    elif os.path.exists(video_path):
        log(f"⏭ 视频流已缓存: {os.path.getsize(video_path)/1024/1024:.1f}MB")

    # 4. 下载音频流
    if not os.path.exists(audio_path) and audio_url:
        log("下载音频流...")
        t0 = time.time()
        async with aiohttp.ClientSession() as session:
            async with session.get(audio_url, headers=headers) as resp:
                if resp.status == 200:
                    with open(audio_path, "wb") as f:
                        async for chunk in resp.content.iter_chunked(1024 * 1024):
                            f.write(chunk)
                    elapsed = time.time() - t0
                    size_mb = os.path.getsize(audio_path) / 1024 / 1024
                    log(f"✅ 音频流: {size_mb:.1f}MB, 耗时{elapsed:.1f}秒")
                else:
                    log(f"❌ 音频下载失败: HTTP {resp.status}")
    elif os.path.exists(audio_path):
        log(f"⏭ 音频流已缓存: {os.path.getsize(audio_path)/1024/1024:.1f}MB")

    # 5. 转WAV (16kHz mono)
    if not os.path.exists(wav_path) and os.path.exists(audio_path):
        log("转WAV (16kHz mono)...")
        result = subprocess.run(
            [FFMPEG, '-y', '-i', audio_path, '-ar', '16000', '-ac', '1', wav_path],
            capture_output=True
        )
        if os.path.exists(wav_path):
            log(f"✅ WAV: {os.path.getsize(wav_path)/1024:.0f}KB")
        else:
            stderr = result.stderr.decode('utf-8', errors='replace')[:200]
            log(f"❌ WAV转换失败: {stderr}")
    elif os.path.exists(wav_path):
        log(f"⏭ WAV已缓存: {os.path.getsize(wav_path)/1024:.0f}KB")

    # 6. 提取关键帧（每2秒1帧）
    if os.path.exists(video_path):
        existing_frames = [f for f in os.listdir(frames_dir) if f.endswith('.jpg')]
        if not existing_frames:
            log("提取关键帧 (每2秒1帧)...")
            subprocess.run(
                [FFMPEG, '-y', '-i', video_path, '-vf', 'fps=0.5',
                 os.path.join(frames_dir, 'frame_%03d.jpg')],
                capture_output=True
            )
        else:
            log(f"⏭ 关键帧已缓存: {len(existing_frames)}帧")

    frame_count = len([f for f in os.listdir(frames_dir) if f.endswith('.jpg')])
    log(f"帧数: {frame_count}")

    # 7. 输出结构化结果
    log(f"=== 完成 {bvid} ===")
    print(f"\n=== RESULT ===")
    print(f"TITLE={title}")
    print(f"UP={up}")
    print(f"DURATION={duration}")
    print(f"WAV={wav_path}")
    print(f"FRAMES_DIR={frames_dir}")
    print(f"FRAME_COUNT={frame_count}")

    return {
        'title': title,
        'up': up,
        'duration': duration,
        'wav_path': wav_path,
        'frames_dir': frames_dir,
        'frame_count': frame_count
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python download_bili.py <bvid_or_url>")
        print("  bvid_or_url: BV号、b23.tv短链、bilibili.com长链均可")
        sys.exit(1)
    try:
        asyncio.run(download_av(sys.argv[1]))
    except Exception as e:
        log(f"❌ 致命错误: {e}")
        sys.exit(1)
