"""
Whisper 时间轴字幕识别脚本
==========================
用法: python transcribe.py <wav_path>
输出: 带时间轴的中文字幕文本（stdout）

模型: medium (1.46GB, 本地缓存 ~/.cache/whisper/medium.pt)
语言: 强制中文 (zh)

依赖:
  - openai-whisper
  - ffmpeg (自动检测: PATH > FFMPEG_PATH环境变量 > 默认安装路径)
"""
import whisper
import os
import sys
import time
import shutil

# ffmpeg 路径自动检测
_DEFAULT_FFMPEG_PATHS = [
    os.environ.get("FFMPEG_PATH", ""),
    shutil.which("ffmpeg") or "",
    r"C:\ProgramData\openssl\ffmpeg\bin\ffmpeg.exe",
    r"C:\ffmpeg\bin\ffmpeg.exe",
    "/usr/bin/ffmpeg",
    "/usr/local/bin/ffmpeg",
]
FFMPEG_DIR = os.path.dirname(next((p for p in _DEFAULT_FFMPEG_PATHS if p and os.path.exists(p)), ""))
if FFMPEG_DIR:
    os.environ["PATH"] = FFMPEG_DIR + os.pathsep + os.environ.get("PATH", "")


def log(msg):
    """带时间戳的日志输出"""
    ts = time.strftime("%H:%M:%S")
    print(f"[{ts}] {msg}")


def fmt_time(seconds):
    """
    将秒数格式化为 MM:SS.ss 时间戳。
    例: 83.5 -> "01:23.50"
    """
    m = int(seconds // 60)
    sec = seconds % 60
    return f"{m:02d}:{sec:05.2f}"


def transcribe(wav_path):
    """
    用 Whisper medium 模型识别音频，输出带时间轴的字幕。
    
    参数:
        wav_path: WAV 文件路径（建议 16kHz mono）
    
    返回:
        Whisper 识别结果 dict，含 segments 和 text
    """
    # 检查文件
    if not os.path.exists(wav_path):
        log(f"❌ 文件不存在: {wav_path}")
        sys.exit(1)
    
    # 检查 ffmpeg
    if not FFMPEG_DIR:
        log("❌ 未找到 ffmpeg，请安装或设置 FFMPEG_PATH 环境变量")
        sys.exit(1)

    # 加载模型
    log("加载 Whisper medium 模型...")
    t0 = time.time()
    model = whisper.load_model("medium")
    log(f"模型加载完成, 耗时{time.time()-t0:.1f}秒")

    # 识别
    log(f"开始识别: {wav_path}")
    log(f"文件大小: {os.path.getsize(wav_path)/1024:.0f}KB")
    t0 = time.time()
    result = model.transcribe(wav_path, language="zh", verbose=False)
    elapsed = time.time() - t0
    log(f"识别完成, 耗时{elapsed:.1f}秒, 共{len(result['segments'])}段")

    # 输出带时间轴的字幕
    print(f"\n=== 时间轴字幕 ===\n")
    for i, seg in enumerate(result["segments"], 1):
        start = fmt_time(seg["start"])
        end = fmt_time(seg["end"])
        text = seg["text"].strip()
        print(f"{i:02d}. {start} --> {end}")
        print(f"    {text}")
        print()

    print(f"总段数: {len(result['segments'])}")
    return result


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python transcribe.py <wav_path>")
        sys.exit(1)
    try:
        transcribe(sys.argv[1])
    except Exception as e:
        log(f"❌ 致命错误: {e}")
        sys.exit(1)
