# bili-video-analyzer

> B站视频全自动分析技能 · [SkillHub](https://skillhub.cn) slug: `bilibili-browse-videos`

## 这是什么

给 Agent 用的 B站视频分析技能。用户发一个 B站链接，Agent 自动完成：

1. **下载**视频和音频流
2. **转写**音频为带时间轴的中文字幕（Whisper medium）
3. **提取**关键帧并逐帧分析画面内容
4. **总结**视频要点，通过消息发送给用户

## 快速使用

```
用户：帮我看看这个视频 https://b23.tv/xxxxx
Agent：（自动执行全流程，约2-4分钟）
       📺 视频信息 + 📝 字幕 + 🖼 画面描述 + 💡 要点总结
```

## 安装

```bash
skillhub install bilibili-browse-videos
```

## 环境要求

- Python 3.10+
- ffmpeg（在 PATH 中或修改脚本中的完整路径）
- GPU（可选，Whisper medium 在 CPU 上也能跑但较慢）

### Python 依赖

```bash
pip install bilibili-api-python openai-whisper aiohttp
```

### Whisper 模型

首次运行会自动下载 medium 模型（约 1.46GB）到 `~/.cache/whisper/`。

## 文件结构

```
bili-video-analyzer/
├── SKILL.md              # 技能指引（Agent 读取）
├── CHANGELOG.md          # 变更日志
├── README.md             # 本文件
└── scripts/
    ├── download_bili.py   # 下载+转WAV+提帧
    └── transcribe.py      # Whisper字幕识别
```

## 技术细节

### 下载原理

B站视频采用 DASH 格式，视频和音频是分离的 m4s 流：
1. `bilibili-api-python` 获取 DASH 流的 baseUrl
2. `aiohttp` 带 `Referer: https://www.bilibili.com` 头下载（不带会 403）
3. `ffmpeg` 将音频 m4s 转为 16kHz mono WAV
4. `ffmpeg` 从视频 m4s 中每 2 秒提取 1 帧 JPG

### Whisper 配置

- 模型：medium（1.46GB，本地缓存）
- 语言：强制 `zh`
- 输出：带 `start`/`end` 时间戳的分段文本

### 帧数选择

| 视频时长 | 选取帧数 |
|----------|---------|
| <15秒    | 全部    |
| 15-60秒  | 8-11帧  |
| >60秒    | 6-8帧   |

## 已知限制

- 不支持需要大会员的视频（无 cookie 认证）
- Whisper medium 可能输出繁体字
- 长视频（>5分钟）处理时间较长
- 无法获取 B站 CC 字幕（仅靠 Whisper 识别）

## 维护

- **维护者**: kilb / QClaw Agent
- **SkillHub**: `bilibili-browse-videos`
- **问题反馈**: 通过飞书联系
