---
name: skillhub-skill-bilibili-browse-videos
description: "B站视频全自动分析：下载视频+音频 → Whisper时间轴字幕 → 关键帧画面分析 → 内容总结。当用户发送B站视频链接（bilibili.com或b23.tv短链）并想了解视频内容时触发。包括\"帮我看看这个视频\"、\"这个视频讲了啥\"、\"分析一下这个视频\"等场景。"
---

# B站视频分析技能 (bilibili-browse-videos)

> **SkillHub slug**: `bilibili-browse-videos`
> **维护者**: kilb / QClaw Agent
> **变更日志**: 见 `CHANGELOG.md`

## 全流程概述

```
用户发送B站链接
      │
      ▼
┌─────────────────┐
│ 1. 解析短链→BVID │  支持 b23.tv 短链 / bilibili.com 长链 / 纯 BV号
└───────┬─────────┘
        ▼
┌─────────────────┐
│ 2. 下载视频+音频 │  bilibili-api-python 获取URL → aiohttp+Referer 下载
│    + 转WAV       │  ffmpeg 转 16kHz mono WAV
│    + 提取关键帧   │  ffmpeg fps=0.5 每2秒1帧
└───────┬─────────┘
        ▼
┌─────────────────┐
│ 3. Whisper字幕   │  medium 模型，中文识别，带时间戳分段
└───────┬─────────┘
        ▼
┌─────────────────┐
│ 4. 画面分析      │  选取6-11帧，image工具逐帧分析
└───────┬─────────┘
        ▼
┌─────────────────┐
│ 5. 综合总结      │  字幕+画面 → 视频信息+完整字幕+画面描述+要点总结
│    → 飞书发送    │
└─────────────────┘
```

## 环境依赖

| 依赖 | 说明 |
|------|------|
| Python venv | `~/.qclaw/workspace/venv`（优先）或 Conda base |
| bilibili-api-python | `pip install bilibili-api-python` (≥17.4) |
| openai-whisper | `pip install openai-whisper`，medium 模型已缓存本地 |
| ffmpeg | 自动检测：PATH > FFMPEG_PATH 环境变量 > 默认安装路径 |
| aiohttp | `pip install aiohttp` |

## 执行步骤

### 1. 解析短链接获取BVID

支持三种输入格式：
- 短链：`https://b23.tv/xxxxx`
- 长链：`https://www.bilibili.com/video/BV1xxxxx`
- 纯BVID：`BV1xxxxx`

```python
import urllib.request, re

def parse_bvid(text):
    text = text.strip()
    if re.match(r'^BV\w+$', text):
        return text
    req = urllib.request.Request(text)
    req.add_header("User-Agent", "Mozilla/5.0")
    resp = urllib.request.urlopen(req)
    m = re.search(r'BV\w+', resp.url)
    return m.group(0) if m else None
```

### 2. 下载视频+音频+转WAV+提取帧

运行脚本：
```bash
python scripts/download_bili.py <bvid_or_url>
```

脚本完成以下工作：
- **获取下载URL**：bilibili-api-python 的 `Video.get_download_url(0)`
- **下载视频和音频**：aiohttp + Referer 头下载 m4s 流（必须带 `Referer: https://www.bilibili.com`，否则 403）
- **转WAV**：ffmpeg 转 16kHz mono WAV（Whisper 要求）
- **提取关键帧**：ffmpeg `fps=0.5` 每2秒提取1帧 JPG

**文件命名规则**：全部用 BVID，不用视频标题（标题含特殊字符会导致 ffmpeg 失败）

**输出路径**：`~/.qclaw/workspace/bili_downloads/`

| 文件 | 说明 |
|------|------|
| `{bvid}_video.m4s` | 原始视频流 |
| `{bvid}_audio.m4s` | 原始音频流 |
| `{bvid}.wav` | 16kHz mono WAV |
| `frames_{bvid}/frame_001.jpg` ... | 关键帧序列 |

**缓存**：已下载的文件不会重复下载（脚本检查文件是否存在）

### 3. Whisper识别时间轴字幕

运行脚本：
```bash
python scripts/transcribe.py <wav_path>
```

- 模型：`medium`（精度与速度平衡，本地已缓存）
- 语言：`zh`（强制中文识别）
- 输出格式：

```
01. 00:00.00 --> 00:02.80  字幕内容
02. 00:02.80 --> 00:04.48  字幕内容
...
总段数: N
```

> **注意**：medium 模型可能输出繁体字。如需简体可安装 opencc 转换。

### 4. 画面分析

用 `image` 工具分析关键帧。**帧数选择策略**：

| 视频时长 | 选取帧数 | 策略 |
|----------|---------|------|
| <15秒    | 全部    | 短视频帧少，全发 |
| 15-60秒  | 8-11帧  | 均匀间隔选取 |
| >60秒    | 6-8帧   | 选取关键时间点 |

```python
# 帧选取示例：从N帧中均匀选8帧
import os
frames = sorted([f for f in os.listdir(frames_dir) if f.endswith('.jpg')])
step = max(1, len(frames) // 8)
selected = frames[::step][:8]
```

然后用 image 工具：
```
image(images=[frame1, frame3, ...], prompt="按顺序描述每帧画面内容，包括人物、场景、文字、UI元素等")
```

### 5. 综合总结

整合字幕和画面分析结果，输出结构化总结：

```
📺 视频信息
  标题：xxx | UP主：xxx | 时长：xx秒

📝 完整字幕（时间轴）
  01. 00:00.00 --> 00:02.80  xxx
  ...

🖼 画面内容
  - 00:02 女性客服讲解王者荣耀亲密度恢复功能
  - 00:08 游戏UI演示界面
  ...

💡 内容要点
  1. 要点一
  2. 要点二
  3. 要点三
```

通过 `message` 工具发送到飞书。

## 注意事项

1. **Referer 头必须**：下载 m4s 流必须带 `Referer: https://www.bilibili.com`，否则返回 403
2. **文件名用 BVID**：视频标题含特殊字符（如 `/`、`:`、`？`）会导致 ffmpeg 和文件系统错误
3. **ffmpeg 调用用 subprocess**：不用 os.system（避免 GBK 编码问题和命令注入）
4. **ffmpeg 自动检测**：脚本自动查找 ffmpeg（PATH > FFMPEG_PATH 环境变量 > 默认路径），无需硬编码
5. **Whisper 繁体输出**：medium 模型可能输出繁体字，如需简体可加 opencc-python
6. **耗时参考**：短视频（<30秒）约2分钟完成全流程；60秒视频约3-4分钟
7. **帧数控制**：image 工具一次最多20张图，选取6-11帧即可，不需要全部发送
8. **Python 环境**：优先使用 `~/.qclaw/workspace/venv`，其次 Conda base

## 故障排除

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 下载 403 | 未带 Referer 头 | 确认 headers 含 `Referer: https://www.bilibili.com` |
| ffmpeg 找不到 | 未安装或不在 PATH | 安装 ffmpeg 或设置 FFMPEG_PATH 环境变量 |
| Whisper 报错找不到 ffmpeg | 同上 | 脚本已自动检测并设置 PATH |
| 文件名乱码 | 视频标题含特殊字符 | 文件名统一用 BVID，不用标题 |
| GBK 编码错误 | Windows 控制台编码 | 设置 `PYTHONIOENCODING=utf-8` |
| 下载速度慢 | B站限速 | 可尝试切换 CDN baseUrl |
