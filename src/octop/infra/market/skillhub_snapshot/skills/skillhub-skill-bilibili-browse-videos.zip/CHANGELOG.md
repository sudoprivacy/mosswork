# Changelog

所有重要变更记录在此文件中。
格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/)。

## [1.0.1] - 2026-07-06

### 新增
- 完善 SKILL.md：补充完整流程图、环境依赖表、帧数选择策略、故障排除表
- 新增 CHANGELOG.md 变更日志
- 新增 README.md 技能说明文档
- download_bili.py 增加详细日志输出（文件大小、耗时、状态）
- download_bili.py 增加短链解析功能（支持 b23.tv）
- download_bili.py 增加缓存机制（已下载文件跳过）
- transcribe.py 增加模型加载和识别阶段日志
- transcribe.py 增加错误处理（文件不存在、ffmpeg 缺失）

### 优化
- 脚本注释补全，每个函数添加 docstring
- 输出格式标准化，方便 Agent 解析

### 修复
- 无（首版）

## [1.0.2] - 2026-07-06

### 优化
- ffmpeg 路径从硬编码改为自动检测（PATH > FFMPEG_PATH 环境变量 > 默认安装路径）
- 跨平台支持：Windows / Linux / macOS 均可自动找到 ffmpeg
- 用户可通过 FFMPEG_PATH 环境变量手动指定 ffmpeg 路径

## [1.0.0] - 2026-07-05

### 初始发布
- B站视频下载脚本 download_bili.py
- Whisper 时间轴字幕识别脚本 transcribe.py
- 全流程：下载→转WAV→提帧→字幕→画面分析→总结
- 已跑通多个视频测试（天气预报、亲密度工具、加分项、怀念小时候等）
- 发布到 SkillHub，slug: bilibili-browse-videos
