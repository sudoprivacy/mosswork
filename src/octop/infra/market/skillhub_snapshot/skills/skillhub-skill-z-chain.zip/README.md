# z-chain（产业/项目生态链角色图谱）

一句话：把"谁扮演什么角色"画成分层图谱——结构先行，人名和事实宁空勿编。产出的生态事实是全系列判断与评估的底座。

## 何时使用

说"产业链、产业生态、链长、链主、强链补链、建圈强链、生态图谱、干系人盘点、角色盘点、上下游、卡位点"，或意图是画角色地图时触发。生态定位问答由 z-clarify 主导，完整图谱用本 skill。

## 用法速览

- 问法：「把 X 产业链/项目的干系人画成角色图谱」；基线后重绘：「干系人变了不少，重新画一次生态图」
- 用法卡：聊天说 `z-chain help`，ZCode 下 `/z-chain-help` 直达
- 动手前先确认尺度：产业（地区×链条）还是项目（一个事项）

## 核心机制

- **三条铁律**：宁空勿编（已确认/待核/空缺三态，空缺是诚实）；每填必据（无据自动降级待核）；空缺是常态（好坏看"已填项都有据"，不看填没填满）。
- **两个尺度一套框架**：治理层/核心层/链上层/支撑层四层互斥；项目尺度先落位产业生态、再画组织生态，且空缺即风险信号（链长空缺=无人拍板等四类）。
- **链主判定**：技术引领/资源整合/生态构建三力 + 认定来源，无来源不填链主。
- **三问收口**：我是谁、依靠谁、为了谁——答不上来的位置默认红色高影响警示。
- **输出**：单文件 HTML 图谱（三问卡+分层布局+角色表+图例，Gen UI 内联展示配方内置）；mermaid 兜底。项目语境落 `docs/00-立项/生态角色表.md`，基线后落 `05-管理/变更/`。

## 与 z-系列的关系

```
z-flow-kickoff（编排：开场协议→契约→横幅→交接→续跑）
   └─ z-pyramid(拆解) → z-clarify(澄清→登记册) ⇄ z-chain(本 skill：生态/干系人事实)
                              ↓
                       z-assess(四维+风险+假设 → Go/No-Go)
                              ↓ Go
                       z-init(工程文档基线化) → 下游 spec/开发（松耦合，AGENTS.md 契约）
```

上游供给 z-clarify 维度 4/6（先建图再定位，已建图不重复追问）；下游供 z-assess 风险登记（空位=风险证据）。本 skill 只画结构事实，不做判断——判断归 z-assess，表达结构归 z-pyramid。整链编排见 z-flow-kickoff；六技能相互独立、按需组合。

## 安装

### ZCode（推荐：随系列整装，symlink 安装）

```bash
git clone https://github.com/zimy0033/z-skill-series.git ~/z-skill-series
bash ~/z-skill-series/install.sh
```

install.sh 把 `skills/*` 以 symlink 装入 `~/.zcode/skills/`（help 命令装入 `~/.zcode/commands/`）；更新只需 `git -C ~/z-skill-series pull`，无需重装。GitHub HTTPS 不稳时可改用 SSH。

### 单独安装（任一 agent）

把 `skills/z-chain` 目录复制到目标 agent 的 skills 目录（ZCode 用户级 `~/.zcode/skills/`，项目级 `<项目>/.zcode/skills/`）。安装后重启会话生效。skills CLI 子路径安装已实测可用：`npx skills add zimy0033/z-skill-series/skills/z-chain`。

## License

MIT
