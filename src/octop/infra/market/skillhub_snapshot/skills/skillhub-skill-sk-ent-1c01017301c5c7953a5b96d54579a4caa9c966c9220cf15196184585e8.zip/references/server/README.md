# 新媒体IP打造 · 付费履约服务

按 [SkillHub 企业最佳实践](https://skillhub.cn/tutorials#enterprise-best-practice) 实现「后端服务改造」部分：
**402 → 查单 → 履约**，配合 SKILL.md 里的「Skill Prompt 改造」四步，两者缺一不可。

## 协议时序

```
① Agent    → 商户服务   POST /skill/invoke {"query":"..."}
② 商户服务 → 微信支付   Native 下单（微信支付 API 证书签名）→ code_url
③ 商户服务 → 微信支付   AI 预下单（SkillHub 开发者密钥签名）→ payment_code
④ 商户服务 → Agent      402 + WeixinPay-Required + X-Out-Trade-No
⑤ Agent    → 微信支付   weixinpay_pay(paymentCode)
⑥ 用户     → 微信支付   确认支付
⑦ Agent    → 商户服务   POST /skill/invoke + X-Out-Trade-No（body 与 ① 一致）
⑧ 商户服务 → 微信支付   查单 → trade_state=SUCCESS
⑨ 商户服务 → Agent      200 + 付费内容
```

## 两套密钥（最易踩坑）

| 密钥 | 用途 | 签名算法 | 获取 |
|---|---|---|---|
| 微信支付 API 证书私钥 | Native 下单、查单 | `WECHATPAY2-SHA256-RSA2048` | 微信支付商户平台 |
| SkillHub 开发者密钥 | X402 AI 预下单 | `SKILLHUB-SHA256-RSA2048` | SkillHub 商户中心「开发者密钥」 |

AI 预下单**不使用**微信支付 API 证书签名，用 SkillHub 颁发的密钥。

## 运行

```bash
cp .env.example .env   # 填入商户号、两套密钥、Skill ID
node selftest.js       # 离线自检（13 项，验证签名串/L2/订单号/验签）
node server.js         # 启动，默认 8080
```

> ⚠️ `.env` 含私钥，**不会**打包进发布包（打包时已排除），也不要提交到任何公开仓库。本目录不放 `.gitignore`，是因 SkillHub 发布校验不允许包内含 dotfile。

本地验证两种场景：

```bash
# 首次请求 → 402
curl -i -X POST http://localhost:8080/skill/invoke \
  -H "Content-Type: application/json" \
  -d '{"query":"帮我做账号定位，我做AI工具科普，受众是职场新人"}'

# 支付后重试 → 200（Header 携带订单号，body 与首次一致）
curl -i -X POST http://localhost:8080/skill/invoke \
  -H "Content-Type: application/json" \
  -H "X-Out-Trade-No: WF_20260907120000A1B2C3D4E5F6" \
  -d '{"query":"帮我做账号定位，我做AI工具科普，受众是职场新人"}'
```

## 计费

`PRICE_FEN=100` 即 **¥1.00 / 次**，与 `SKILL.md` 的 `pricing.amount_fen: 100` 保持一致。

## 部署与探活

这是一个**必须公网可访问**的服务（平台审核会校验支付服务是否具备）：

```bash
GET  /healthz                 → {"ok":true,"configComplete":true,"missing":[]}
POST /skill/invoke            → 402 + WeixinPay-Required + X-Out-Trade-No
POST /skill/invoke + Header   → 200 + 付费内容
```

未配置完整时：调用返回 `503 SERVICE_NOT_CONFIGURED` 并列出缺失项（不会静默 502）。
部署方式（Docker / 直接运行 / 云函数 / Nginx 反代）见 [`deploy.md`](./deploy.md)。部署后把 HTTPS 地址回填到 `skillpay.json → api.base`。

## 从 Demo 到生产

| 项 | Demo 状态 | 生产要求 |
|---|---|---|
| 微信支付 V3 签名 | 内置 crypto 实现 | 建议改用官方 SDK（Go: wechatpay-go / Java: wechatpay-java / Node: wechatpay-axios-plugin） |
| 订单存储 | 内存 Map | 数据库 + 事务保证幂等 |
| X402 预下单签名 | 完整实现，可直接复用 | 私钥放密钥管理服务，禁止入库/入仓 |
| 支付回调 | 未实现 | 实现 `notify_url` 处理支付结果通知 |
| 付费内容 | 返回解锁的模块资产 | 替换为自有模型/服务生成结果 |

## 文件

```
server.js              统一入口（402 / 200 分支、幂等）
lib/wechatpay.js       Native 下单 + 查单（WECHATPAY2 签名）
lib/x402.js            AI 预下单（L1/L2 + SKILLHUB 签名，5 行签名串）
lib/orders.js          订单号生成（≤32 位）+ 订单存储
selftest.js            离线自检
```
