# 部署支付服务（产出 `SKILL_API_BASE`）

平台审核要求 Skill 具备**可访问的支付服务**。本目录的服务部署到公网后，把 HTTPS 地址填入 `skillpay.json → api.base`，Agent 才能走通 402 流程。

## 方式一：Docker（推荐）

> 技能包内不放 `Dockerfile`（SkillHub 发布校验拒绝无扩展名文件），请在技能根目录手动创建：

```dockerfile
FROM node:22-alpine
WORKDIR /app
COPY server/package.json ./
COPY server/server.js ./
COPY server/lib ./lib
COPY server/selftest.js ./
COPY modules ./modules
COPY references ./references
ENV PORT=8080
ENV SKILL_ROOT=/app
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=5s CMD wget -qO- http://localhost:8080/healthz || exit 1
CMD ["node", "server.js"]
```

```bash
docker build -t newmedia-ip-pay:1.1.2 .
docker run -d --name newmedia-ip-pay -p 8080:8080 --env-file server/.env newmedia-ip-pay:1.1.2
curl https://your-domain.com/healthz
# {"ok":true,"configComplete":true,"missing":[]}
```

## 方式二：直接运行

```bash
cd server && cp .env.example .env   # 填入凭据
node selftest.js                    # 离线自检 13 项
node server.js                      # 监听 8080
```

## 方式三：Cloud Studio / 任意云函数

把 `server/` 整体上传，入口 `node server.js`，开放 8080 端口，绑定 HTTPS 域名即可。

## 反向代理（HTTPS）

以 Nginx 为例，关键是**透传两个 Header**，否则第四步拿不到订单号：

```nginx
location / {
  proxy_pass http://127.0.0.1:8080;
  proxy_set_header Host $host;
  proxy_set_header X-Out-Trade-No $http_x_out_trade_no;
  proxy_set_header WeixinPay-Required $http_weixinpay_required;
  proxy_pass_request_headers on;
}
```

## 部署后自查

| 检查 | 期望 |
|---|---|
| `GET /healthz` | `{"ok":true,"configComplete":true}` |
| `POST /skill/invoke`（无 Header） | `402` + `WeixinPay-Required` + `X-Out-Trade-No` |
| `POST /skill/invoke`（带 `X-Out-Trade-No`） | 查单通过后 `200` + 付费内容 |
| 幂等 | 同一订单号重复请求返回 `already_fulfilled: true`，不二次扣费 |

## 当前缺口

`configComplete: false` 时 `/healthz` 会列出缺失项。X402 签名必需的 **SkillHub 开发者私钥**在生成时只展示一次，若遗失需在 SkillHub 商户中心重新生成一组密钥并同步 `PUB_KEY_ID` 与 `SKILLHUB_PRIVATE_KEY`。
