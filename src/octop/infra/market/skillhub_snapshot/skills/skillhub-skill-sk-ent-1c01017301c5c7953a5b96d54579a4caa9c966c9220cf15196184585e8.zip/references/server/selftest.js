/**
 * 离线自检：不依赖网络与真实商户号，验证付费改造中最容易出错的三处
 *   1) out_trade_no 长度与唯一性
 *   2) X402 签名串格式（5 行，末行也带 \n）与 L2 结构
 *   3) 签名算法 SHA256withRSA（PKCS#1 v1.5）可被公钥验签
 * 运行：node selftest.js
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const x402 = require('./lib/x402');
const wechatpay = require('./lib/wechatpay');
const { newOutTradeNo } = require('./lib/orders');

let failed = 0;
function check(name, cond, extra = '') {
  console.log(`${cond ? '✓' : '✗'} ${name}${cond ? '' : ` — ${extra}`}`);
  if (!cond) failed += 1;
}

// 1) 订单号
const ids = new Set(Array.from({ length: 1000 }, newOutTradeNo));
check('out_trade_no ≤ 32 位', newOutTradeNo().length <= 32, newOutTradeNo());
check('out_trade_no 唯一（1000 次无重复）', ids.size === 1000, `unique=${ids.size}`);

// 2) X402 签名串与 L2
const ts = '1750924200';
const nonce = 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6';
const { paymentRequired, l2 } = x402.buildPaymentRequired({
  skillId: 'sk-ent-demo',
  skillVersion: '1.1.0',
  codeUrl: 'weixin://wxpay/bizpayurl?pr=demo',
  expiresAt: 1750925100,
});
const signString = x402.buildSignString(ts, nonce, paymentRequired);
const lines = signString.split('\n');
check('签名串为 5 行且末行带换行', lines.length === 6 && lines[5] === '', JSON.stringify(signString.slice(-40)));
check('第 2 行为预下单路径', lines[1] === '/palmpayminiapp/clawagentpay/preorder', lines[1]);
check('L2 pay_type = SKILL_PAY', l2.pay_type === 'SKILL_PAY');
check('L2 pay_mode = AUTH_AND_PAY', l2.pay_mode === 'AUTH_AND_PAY');
check('L2 pay_data.type = code_url', l2.pay_items[0].pay_data.type === 'code_url');
const decoded = JSON.parse(Buffer.from(paymentRequired, 'base64').toString('utf8'));
check('payment_required 为标准 Base64 可解回 L2', decoded.pay_items[0].pay_data.value === 'weixin://wxpay/bizpayurl?pr=demo');
check('expires_at ≤ 15 分钟', Number(decoded.expires_at) - Number(ts) <= 900);

// 3) 签名 / 验签
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const sig = x402.sign(signString, privateKey.export({ type: 'pkcs8', format: 'pem' }));
const ok = crypto
  .createVerify('RSA-SHA256')
  .update(signString)
  .verify(publicKey, Buffer.from(sig, 'base64'));
check('SHA256withRSA 签名可被公钥验签', ok);

// 4) 微信支付 Authorization 头格式
const auth = wechatpay.authHeader(
  'POST',
  '/v3/pay/transactions/native',
  '{}',
  {
    mchId: '1900000001',
    serialNo: 'SERIAL',
    privateKey: privateKey.export({ type: 'pkcs8', format: 'pem' }),
  },
);
check('Authorization 使用 WECHATPAY2-SHA256-RSA2048', auth.startsWith('WECHATPAY2-SHA256-RSA2048 '));
check('Authorization 含 mchid/serial_no/signature/timestamp', ['mchid', 'serial_no', 'signature', 'timestamp'].every((k) => auth.includes(k)));

// 5) 付费内容资产可读
const skillRoot = path.resolve(process.env.SKILL_ROOT || path.join(__dirname, '..'));
const moduleFiles = fs.readdirSync(path.join(skillRoot, 'modules'));
check('可读取 7 个模块资产', moduleFiles.filter((f) => f.endsWith('.md')).length === 7, moduleFiles.join(','));

console.log(failed ? `\n${failed} 项未通过` : '\n全部通过');
process.exit(failed ? 1 : 0);
