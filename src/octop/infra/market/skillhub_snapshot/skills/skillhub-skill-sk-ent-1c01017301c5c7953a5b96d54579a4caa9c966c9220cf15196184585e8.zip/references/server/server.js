/**
 * 新媒体IP打造 —— 付费履约服务（X402 / 微信支付 Agent Pay）
 *
 * 统一入口 POST /skill/invoke，用 Header X-Out-Trade-No 是否存在区分两种场景：
 *   ① 无 Header  → 微信 Native 下单 + X402 预下单 → HTTP 402 + WeixinPay-Required + X-Out-Trade-No
 *   ② 有 Header  → 查单验证 → 通过后 HTTP 200 + 付费内容（同一订单只履约一次）
 *
 * 零第三方依赖：node server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const wechatpay = require('./lib/wechatpay');
const x402 = require('./lib/x402');
const { newOutTradeNo, createStore } = require('./lib/orders');

const PORT = Number(process.env.PORT || 8080);
const PRICE_FEN = Number(process.env.PRICE_FEN || 100); // ¥1.00
const SKILL_ROOT = path.resolve(process.env.SKILL_ROOT || path.join(__dirname, '..'));

const wxCfg = {
  mchId: process.env.WECHATPAY_MCH_ID,
  appId: process.env.WECHATPAY_APP_ID,
  serialNo: process.env.WECHATPAY_SERIAL_NO,
  privateKey: process.env.WECHATPAY_PRIVATE_KEY,
  notifyUrl: process.env.WECHATPAY_NOTIFY_URL,
};
const shCfg = {
  developerId: process.env.SKILLHUB_DEVELOPER_ID,
  pubKeyId: process.env.SKILLHUB_PUB_KEY_ID,
  privateKey: process.env.SKILLHUB_PRIVATE_KEY,
  skillId: process.env.SKILL_ID,
  skillVersion: process.env.SKILL_VERSION || '1.1.2',
};

/** 启动期配置自检：缺项时明确报错，而不是在下单时抛 502 */
const REQUIRED_ENV = [
  ['WECHATPAY_MCH_ID', wxCfg.mchId],
  ['WECHATPAY_APP_ID', wxCfg.appId],
  ['WECHATPAY_SERIAL_NO', wxCfg.serialNo],
  ['WECHATPAY_PRIVATE_KEY', wxCfg.privateKey],
  ['SKILLHUB_DEVELOPER_ID', shCfg.developerId],
  ['SKILLHUB_PUB_KEY_ID', shCfg.pubKeyId],
  ['SKILLHUB_PRIVATE_KEY', shCfg.privateKey],
];
function missingConfig() {
  return REQUIRED_ENV.filter(([, v]) => !v || !String(v).trim()).map(([k]) => k);
}

/** 订单表（Demo 用内存；生产请换数据库 + 事务保证幂等） */
const orders = createStore();

/** 模块识别：query 中的 01-07、代号或中文名 */
const MODULE_MAP = [
  { id: '01', file: '01-ip-positioning.md', keys: ['定位', '人设', '定位罗盘', 'ip-compass'] },
  { id: '02', file: '02-topic-engine.md', keys: ['选题', '选题引擎', 'topicforge'] },
  { id: '03', file: '03-platform-adapter.md', keys: ['多平台', '一稿多投', '小红书', '抖音', '公众号', 'omncast'] },
  { id: '04', file: '04-visual-system.md', keys: ['视觉', '配色', '封面', 'visualdna'] },
  { id: '05', file: '05-engagement-scripts.md', keys: ['互动', '话术', '评论', '社群', 'fanloop'] },
  { id: '06', file: '06-data-analysis.md', keys: ['数据', '复盘', '播放量', 'datascope'] },
  { id: '07', file: '07-monetization.md', keys: ['变现', '商业化', '报价', 'moneymap'] },
];

function resolveModules(query) {
  const q = String(query || '').toLowerCase();
  const hit = MODULE_MAP.filter((m) => m.keys.some((k) => q.includes(k.toLowerCase())));
  return hit.length ? hit : MODULE_MAP; // 未识别则返回全部
}

/**
 * 付费内容：解锁命中的模块资产（模块文档 + 引用知识库摘要）
 * 生产环境可替换为自有模型/服务生成结果
 */
function generatePaidContent(query) {
  const modules = resolveModules(query);
  const parts = modules.map((m) => {
    const p = path.join(SKILL_ROOT, 'modules', m.file);
    return fs.existsSync(p) ? `<!-- ${m.file} -->\n${fs.readFileSync(p, 'utf8')}` : `<!-- missing ${m.file} -->`;
  });
  return [
    '# 新媒体IP打造 · 已解锁内容',
    `> 本次解锁模块：${modules.map((m) => m.id).join(', ')}｜计费 ¥${(PRICE_FEN / 100).toFixed(2)}`,
    `> 用户诉求：${query}`,
    '',
    parts.join('\n\n'),
  ].join('\n');
}

function json(res, status, body, headers = {}) {
  const buf = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': buf.length,
    ...headers,
  });
  res.end(buf);
}

const server = http.createServer(async (req, res) => {
  // 探活：供平台/监控确认支付服务是否就绪
  if (req.method === 'GET' && req.url.startsWith('/healthz')) {
    const missing = missingConfig();
    return json(res, 200, {
      ok: missing.length === 0,
      service: 'newmedia-ip-pay',
      version: shCfg.skillVersion,
      skill_id: shCfg.skillId,
      price_fen: PRICE_FEN,
      configComplete: missing.length === 0,
      missing,
    });
  }

  if (req.method !== 'POST' || !req.url.startsWith('/skill/invoke')) {
    return json(res, 404, { code: 'NOT_FOUND' });
  }

  const missing = missingConfig();
  if (missing.length) {
    return json(res, 503, {
      code: 'SERVICE_NOT_CONFIGURED',
      message: '支付服务未配置完成，请在 server/.env 补齐以下环境变量',
      missing,
    });
  }

  let raw = '';
  for await (const chunk of req) raw += chunk;
  let query = '';
  try { query = (JSON.parse(raw || '{}').query || '').toString(); } catch { /* ignore */ }

  const outTradeNo = req.headers['x-out-trade-no'];

  // 场景二：支付后重试 —— 查单 + 履约
  if (outTradeNo) {
    const order = orders.get(outTradeNo);
    if (order && order.fulfilled) {
      return json(res, 200, {
        code: 'SUCCESS',
        out_trade_no: outTradeNo,
        content: order.content,
        already_fulfilled: true,
      });
    }
    try {
      const trade = await wechatpay.queryOrder(outTradeNo, wxCfg);
      if (trade.trade_state !== 'SUCCESS') {
        return json(res, 402, {
          code: 'PAYMENT_PENDING',
          message: '支付未完成，请使用同一订单号稍后重试',
          out_trade_no: outTradeNo,
          trade_state: trade.trade_state,
        });
      }
      const content = order ? order.content : generatePaidContent(query);
      orders.set(outTradeNo, { ...(order || {}), fulfilled: true, content, transactionId: trade.transaction_id });
      return json(res, 200, {
        code: 'SUCCESS',
        out_trade_no: outTradeNo,
        transaction_id: trade.transaction_id,
        content,
        already_fulfilled: false,
      });
    } catch (e) {
      return json(res, 502, { code: 'QUERY_FAILED', message: e.message });
    }
  }

  // 场景一：首次请求 —— 下单 + 预下单 + 返回 402
  try {
    const outTradeNo = newOutTradeNo();
    const codeUrl = await wechatpay.nativePrepay(
      { outTradeNo, description: '新媒体IP打造 单次调用', amountFen: PRICE_FEN },
      wxCfg,
    );
    const paymentCode = await x402.preorder(
      { codeUrl, expiresAt: Math.floor(Date.now() / 1000) + 900 }, // 15 分钟
      shCfg,
    );
    orders.set(outTradeNo, { fulfilled: false, content: generatePaidContent(query), paymentCode });

    return json(
      res,
      402,
      {
        code: 'PAYMENT_REQUIRED',
        message: '需要支付后才能获取内容',
        WeixinPay: {
          'WeixinPay-Required': paymentCode,
          prompt: '本次使用微信支付，请将 WeixinPay-Required 的值作为 paymentCode 交给 weixinpay_pay，以向用户申请支付授权。',
        },
        out_trade_no: outTradeNo,
        amount: (PRICE_FEN / 100).toFixed(2),
        currency: 'CNY',
      },
      { 'WeixinPay-Required': paymentCode, 'X-Out-Trade-No': outTradeNo },
    );
  } catch (e) {
    return json(res, 502, { code: 'PREORDER_FAILED', message: e.message });
  }
});

server.listen(PORT, () => {
  console.log(`新媒体IP打造 listening on http://localhost:${PORT}/skill/invoke`);
});
