# 新媒体IP打造 · 全链路付费工具集 v1.1.2（PaySkill / X402）

**新媒体IP打造**：一台七器。覆盖「定位 → 选题 → 内容 → 视觉 → 互动 → 数据 → 变现」全链路的新媒体 IP 运营 Skill。
**付费技能，按调用量计费 ¥1.00 / 次（`amount_fen: 100`）**，按 SkillHub 企业最佳实践完成付费改造：后端 402 履约服务 + Skill Prompt 四步流程，基于微信支付 Agent Pay（X402）。

- Slug：`sk-ent-1c01017301c5c7953a5b96d54579a4caa9c966c9220cf15196184585e8705ed8`
- 计费说明：[`PRICING.md`](./PRICING.md) ｜ 配置：[`skillpay.json`](./skillpay.json) ｜ 案例：[`CASES.md`](./CASES.md) ｜ 履约服务：[`server/`](./server/README.md)

## 付费调用流程（X402）

```
Agent → 商户服务 POST /skill/invoke          → 402 + WeixinPay-Required + X-Out-Trade-No
Agent → weixinpay_pay(paymentCode)           → 用户对话内确认支付
Agent → 商户服务 POST /skill/invoke + X-Out-Trade-No（body 与首次一致）→ 200 + 付费内容
```

⚠️ 第三步必须携带 `X-Out-Trade-No` 重试，否则拿不到付费内容（SKILL.md 已用醒目措辞约束 Agent）。

## 7 大模块（已命名）

| # | 模块命名 | 代号 | 解决什么 | 典型输入 → 输出 |
|---|---|---|---|---|
| 01 | **定位罗盘** | IP-Compass | 我是谁、为谁做、为什么是我 | 受众+领域+特色 → 差异化定位、人设 3×3 关键词、核心价值主张、内容边界 |
| 02 | **选题引擎** | TopicForge | 接下来发什么 | 定位+平台 → 30 条选题库（角度/标题×3/钩子/骨架）+ 系列栏目 + 排期表 |
| 03 | **一稿多投** | OmniCast | 一份内容怎么多平台发 | 内容内核 → 小红书图文 / 抖音分镜脚本 / 公众号长文 / 微博 / 视频号 / B站 |
| 04 | **视觉基因** | VisualDNA | 怎么让人一眼认出我 | 定位调性 → 5 色板(HEX)、字体排版、3 套封面模板、品牌元素规范 |
| 05 | **黏粉话术** | FanLoop | 评论私信社群怎么答 | 场景 → 6 类评论话术、5 类私信话术、社群周节奏、L1–L4 危机预案 |
| 06 | **数据听诊器** | DataScope | 数据说明该改什么 | 后台数据 → 漏斗瓶颈定位、分组洞察、7 天执行表、A/B 实验设计 |
| 07 | **变现地图** | MoneyMap | 怎么赚钱且不伤粉 | 阶段+资源 → 路径评估矩阵、报价区间、定价三档、90 天路线图 |

## 核心机制

1. **IP 档案卡**（`.ip/ip-profile.md`）：一份文件贯穿全流程，保证跨模块一致性，并持续沉淀有效弹药与已否决清单。
2. **迭代引擎 / 反馈码**：F1 太泛、F2 太窄、F3 语气不对、F4 长度不合、F5 AI 味、F6 缺证据、F7 不落地、F8 偏离定位。用户一句短反馈即可触发定向修订。
3. **质量自检**（`assets/review-rubric.md`）：6 维度评分，<75 分不交付。
4. **硬约束**：不编造数据、不承诺结果、不伪造人设、合规自查。

## 使用示例

```
帮我做个账号定位：我做 AI 工具科普，想面向职场新人，我本人是产品经理，说话比较直接
```
→ 模块 01 产出定位方案，并建议建档 `.ip/ip-profile.md`

```
基于我的定位，给我 30 个小红书选题
```
→ 模块 02 读档案卡，产出选题库 + 系列栏目 + 排期

```
把第 3 条选题改成抖音脚本和小红书图文
```
→ 模块 03 提炼内核后分别重写

```
播放量掉了，帮我看看近 10 条数据
```
→ 模块 06 定位瓶颈，输出 7 天执行表并回灌档案卡

反馈示例：`太泛了` / `F5` / `不像我说话，我平时更口语` → 定向修订 + 写回档案卡

## 目录结构

```
SKILL.md                   总入口（路由 / X402 付费流程 / 迭代引擎 / 硬约束）
PRICING.md                 服务说明与计费口径（¥1.00 / 次，amount_fen=100）
CASES.md                   3 个效果案例（发布后补充，影响审核通过率）
skillpay.json              X402 计费与履约的机器可读配置
server/                    付费履约服务：server.js + lib/{wechatpay,x402,orders} + selftest.js
modules/01..07             7 个已命名模块工作流
references/                平台规格、文案公式、人设原型、视觉 Token、互动手册、指标基准、变现模型
assets/ip-profile-template.md   IP 档案卡模板
assets/review-rubric.md         质量自检评分表
```

## 发布

```bash
skillhub publish <本目录> --dry-run --host https://api.skillhub.cn
skillhub publish <本目录> --changelog "变更说明" --host https://api.skillhub.cn
```

发布后需在 SkillHub 商家后台完成企业/个人认证、绑定收款渠道，并在「价格与计费」中设置 **¥1.00 / 次**，审核通过后即为 PaySkill。
