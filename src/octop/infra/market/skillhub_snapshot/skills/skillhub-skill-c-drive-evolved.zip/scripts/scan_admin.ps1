﻿<#
提权扫描：查出 C 盘"真实"占用，并剔除 junction 假占用
用法（需管理员）：& scan_admin.ps1
报告写到 F:\CDriveMoved\_admin_scan.txt（可改 -OutFile）
#>
param([string]$OutFile = 'C:\_cdrive_scan.txt')

# --- admin guard (SkillHub does not allow .bat, so check is inside the .ps1) ---
$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $caller = $MyInvocation.MyCommand.Path
  Write-Host ''
  Write-Host '  [ERROR] This script requires administrator privileges.' -ForegroundColor Red
  Write-Host '  Open PowerShell as administrator (right-click "Run as administrator"), then:' -ForegroundColor Yellow
  Write-Host "    powershell -ExecutionPolicy Bypass -File `"$caller`"" -ForegroundColor Cyan
  Write-Host '  Or from any shell:' -ForegroundColor Yellow
  Write-Host "    Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','`"$caller`"'" -ForegroundColor Cyan
  Write-Host ''
  exit 1
}
$ErrorActionPreference = 'SilentlyContinue'
$out = New-Object System.Collections.ArrayList

function Get-Size($p) {
  $m = Get-ChildItem -LiteralPath $p -Recurse -File -Force | Measure-Object Length -Sum
  if ($m.Sum) { return [int64]$m.Sum } else { return [int64]0 }
}
function GB($b) { return [math]::Round($b / 1GB, 2) }
function IsLink($p) {
  $i = Get-Item -LiteralPath $p -Force
  return [bool]($i.Attributes -band [IO.FileAttributes]::ReparsePoint)
}

$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
  ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
[void]$out.Add("admin rights: $admin")
if (-not $admin) { [void]$out.Add('WARNING: not elevated - numbers will be UNDERSTATED') }
[void]$out.Add('')

[void]$out.Add('===== C:\ top level =====')
foreach ($d in (Get-ChildItem C:\ -Force)) {
  if ($d.PSIsContainer) {
    $link = IsLink $d.FullName
    $tgt = ''
    if ($link) { $tgt = ((Get-Item -LiteralPath $d.FullName -Force).Target -join ' | ') }
    $s = Get-Size $d.FullName
    $flag = if ($link) { ' <JUNCTION - NOT on C:>' } else { '' }
    [void]$out.Add(('  {0,8} GB  {1}{2}  {3}' -f (GB $s), $d.Name, $flag, $tgt))
  } else {
    if ($d.Length -gt 100MB) {
      [void]$out.Add(('  {0,8} GB  {1}   <file>' -f (GB $d.Length), $d.Name))
    }
  }
}

[void]$out.Add('')
[void]$out.Add('===== Windows subdirs =====')
foreach ($n in @('WinSxS', 'Installer', 'SoftwareDistribution', 'Logs', 'assembly', 'Panther', 'Temp')) {
  $p = "C:\Windows\$n"
  if (Test-Path -LiteralPath $p) { [void]$out.Add(('  {0,8} GB  Windows\{1}' -f (GB (Get-Size $p)), $n)) }
}

[void]$out.Add('')
[void]$out.Add('===== reclaimable leftovers =====')
foreach ($p in @('C:\$WinREAgent', 'C:\Windows\Panther', 'C:\$Recycle.Bin', 'C:\Windows\Installer', 'C:\Recovery')) {
  if (Test-Path -LiteralPath $p) { [void]$out.Add(('  {0,8} GB  {1}' -f (GB (Get-Size $p)), $p)) }
}

[void]$out.Add('')
[void]$out.Add('===== volume / shadow (restore points) =====')
$v = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
[void]$out.Add(('  C: size={0} GB  free={1} GB  used={2} GB' -f (GB $v.Size), (GB $v.FreeSpace), (GB ($v.Size - $v.FreeSpace))))
foreach ($s in (Get-CimInstance Win32_ShadowStorage)) {
  [void]$out.Add(('  shadow: used={0} GB allocated={1} GB max={2} GB' -f (GB $s.UsedSpace), (GB $s.AllocatedSpace), (GB $s.MaxSpace)))
}
$rp = @(Get-CimInstance Win32_ShadowCopy)
[void]$out.Add(('  restore points: {0}' -f $rp.Count))
foreach ($r in $rp) { [void]$out.Add(('     {0}' -f $r.InstallDate)) }

[void]$out.Add('')
[void]$out.Add('===== all junctions (already moved off C:) =====')
foreach ($root in @('C:\ProgramData', $env:USERPROFILE)) {
  Get-ChildItem -LiteralPath $root -Directory -Force | ForEach-Object {
    if ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) {
      $t = ($_.Target -join ' | ')
      if ($t) { [void]$out.Add(('  {0}  ->  {1}' -f $_.FullName, $t)) }
    }
  }
}

try { [IO.File]::WriteAllLines($OutFile, $out, [Text.Encoding]::UTF8) } catch {}
$out | ForEach-Object { $_ }
