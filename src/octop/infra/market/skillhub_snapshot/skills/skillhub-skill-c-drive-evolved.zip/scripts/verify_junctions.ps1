﻿<#
验证所有 junction 是否真的把数据引到了目标盘，并查找孤儿副本
用法：
  & verify_junctions.ps1                         # 自动枚举常见位置
  & verify_junctions.ps1 -Pairs @(@('C:\A','F:\B'))
验证方式：向源路径写测试文件，确认它出现在目标盘（只看"链接存在"不算数）
#>
param([object[]]$Pairs = @(), [string]$OutFile = '')

# --- admin guard (some junction paths under C:\ProgramData need admin to read) ---
$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $caller = $MyInvocation.MyCommand.Path
  Write-Host ''
  Write-Host '  [ERROR] This script requires administrator privileges.' -ForegroundColor Red
  Write-Host '  Open PowerShell as administrator (right-click "Run as administrator"), then:' -ForegroundColor Yellow
  Write-Host "    powershell -ExecutionPolicy Bypass -File `"$caller`"" -ForegroundColor Cyan
  Write-Host '  Or from any shell:' -ForegroundColor Yellow
  Write-Host "    Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','`"$caller`"'" -ForegroundColor Cyan
  Write-Host ''
  exit 1
}
$ErrorActionPreference = 'SilentlyContinue'
$out = New-Object System.Collections.ArrayList

if ($Pairs.Count -eq 0) {
  $u = $env:USERPROFILE
  $Pairs = @(
    @("$u\.cache", 'F:\CDriveMoved\UserProfile\.cache'),
    @("$u\AppData\Local\pip", 'F:\CDriveMoved\AppData\Local\pip'),
    @("$u\AppData\Local\npm-cache", 'F:\CDriveMoved\AppData\Local\npm-cache'),
    @("$u\AppData\Roaming\uv", 'F:\CDriveMoved\AppData\Roaming\uv'),
    @("$u\WorkBuddy", 'F:\CDriveMoved\WorkBuddyArchive'),
    @('C:\ProgramData\WorkBuddy', 'F:\CDriveMoved\ProgramData\WorkBuddy')
  )
  # 额外枚举 C:\ProgramData 与用户目录下所有自建 junction
  foreach ($root in @('C:\ProgramData', $u)) {
    Get-ChildItem -LiteralPath $root -Directory -Force | ForEach-Object {
      if ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        $t = ($_.Target -join ' | ')
        if ($t) { $Pairs += , @($_.FullName, ($t -split ' \| ')[0]) }
      }
    }
  }
}

[void]$out.Add('===== junction verification (real write test) =====')
foreach ($pair in $Pairs) {
  $src = $pair[0]
  $dst = $pair[1]
  $isJ = $false
  if (Test-Path -LiteralPath $src) {
    $a = (Get-Item -LiteralPath $src -Force).Attributes
    $isJ = [bool]($a -band [IO.FileAttributes]::ReparsePoint)
  }
  $ok = $false
  if ($isJ -and (Test-Path -LiteralPath $dst)) {
    $probe = Join-Path $src '_vfy.txt'
    Set-Content -LiteralPath $probe -Value 'v'
    Start-Sleep -Milliseconds 200
    $ok = Test-Path (Join-Path $dst '_vfy.txt')
    Remove-Item (Join-Path $dst '_vfy.txt') -Force
    Remove-Item -LiteralPath $probe -Force
  }
  $st = 'BROKEN'
  if ($isJ -and $ok) { $st = 'OK - writes land on target' }
  elseif ($isJ) { $st = 'LINK ONLY - redirect FAILED' }
  else { $st = 'not a junction' }
  [void]$out.Add(('  {0,-50} {1}' -f $src, $st))
}

[void]$out.Add('')
[void]$out.Add('===== orphan copies (old target no longer referenced) =====')
$targets = @()
foreach ($pair in $Pairs) { if ($pair[1]) { $targets += $pair[1] } }
$byParent = $targets | ForEach-Object { Split-Path $_ -Parent } | Sort-Object -Unique
foreach ($parent in $byParent) {
  if (-not (Test-Path -LiteralPath $parent)) { continue }
  Get-ChildItem -LiteralPath $parent -Directory -Force | ForEach-Object {
    $used = $false
    foreach ($t in $targets) { if ($t -like ($_.FullName + '*')) { $used = $true; break } }
    if (-not $used) {
      $m = Get-ChildItem -LiteralPath $_.FullName -Recurse -File -Force | Measure-Object Length -Sum
      [void]$out.Add(('  ORPHAN? {0}  {1} MB  {2} files' -f $_.FullName, [math]::Round($m.Sum / 1MB, 0), $m.Count))
    }
  }
}

[void]$out.Add('')
foreach ($d in @('C:', 'F:')) {
  $v = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$d'"
  if ($v) { [void]$out.Add(('  {0} free = {1} GB' -f $d, [math]::Round($v.FreeSpace / 1GB, 2))) }
}

if ($OutFile) { try { [IO.File]::WriteAllLines($OutFile, $out, [Text.Encoding]::UTF8) } catch {} }
$out | ForEach-Object { $_ }
