﻿<#
WindowsApps / Store 应用：扫描明细 + 识别新旧重复版本 + 安全卸载
用法（需管理员）：
  & uninstall_store_apps.ps1 -Scan                       # 只扫描，输出每包大小
  & uninstall_store_apps.ps1 -Remove -Names 'Xbox','ZuneMusic'
  & uninstall_store_apps.ps1 -Remove -Names (Get-Content list.txt)
框架组件（WindowsAppRuntime / VCLibs / .NET Native / Xaml）永远不会被卸载
#>
param(
  [switch]$Scan,
  [switch]$Remove,
  [string[]]$Names = @(),
  [string]$LogFile = 'C:\_cdrive_store.log'
)

# --- admin guard ---
$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $caller = $MyInvocation.MyCommand.Path
  Write-Host ''
  Write-Host '  [ERROR] This script requires administrator privileges.' -ForegroundColor Red
  Write-Host '  Open PowerShell as administrator (right-click "Run as administrator"), then:' -ForegroundColor Yellow
  Write-Host "    powershell -ExecutionPolicy Bypass -File `"$caller`" -Scan" -ForegroundColor Cyan
  Write-Host '  Or from any shell:' -ForegroundColor Yellow
  Write-Host "    Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','`"$caller`"','-Scan'" -ForegroundColor Cyan
  Write-Host ''
  exit 1
}
$ErrorActionPreference = 'Continue'
$out = New-Object System.Collections.ArrayList
function Log($m) { [void]$out.Add($m); Write-Host $m }
function Get-Size($p) {
  if (-not (Test-Path -LiteralPath $p)) { return [int64]0 }
  $m = Get-ChildItem -LiteralPath $p -Recurse -File -Force | Measure-Object Length -Sum
  if ($m.Sum) { return [int64]$m.Sum } else { return [int64]0 }
}

$frameworks = 'WindowsAppRuntime|VCLibs|NET\.Native|Xaml|Microsoft\.NET\.CoreRuntime|Windows\.AppRuntime'

if ($Scan -or (-not $Remove)) {
  Log '===== Store packages by size ====='
  $pkgs = Get-AppxPackage -AllUsers
  $rows = foreach ($p in $pkgs) {
    [PSCustomObject]@{
      Name = $p.Name
      MB   = [math]::Round((Get-Size $p.InstallLocation) / 1MB, 0)
      Ver  = $p.Version
      Loc  = $p.InstallLocation
    }
  }
  foreach ($r in ($rows | Sort-Object MB -Descending | Select-Object -First 40)) {
    Log ('{0,7} MB  {1}  ({2})' -f $r.MB, $r.Name, $r.Ver)
  }

  Log ''
  Log '===== duplicate version residue (same app, 2 copies) ====='
  Get-ChildItem 'C:\Program Files\WindowsApps' -Directory -Force |
    Group-Object { ($_.Name -replace '_\d+\.\d+\..*', '') } |
    Where-Object { $_.Count -gt 1 } |
    Sort-Object { ($_.Group | ForEach-Object { (Get-Size $_.FullName) } | Measure-Object -Sum).Sum } -Descending |
    Select-Object -First 15 | ForEach-Object {
      $tot = [math]::Round((($_.Group | ForEach-Object { Get-Size $_.FullName } | Measure-Object -Sum).Sum) / 1MB, 0)
      Log ('{0,7} MB  {1}  ({2} versions)' -f $tot, $_.Name, $_.Count)
    }
}

if ($Remove) {
  if ($Names.Count -eq 0) { Log 'nothing to remove: pass -Names'; exit }
  Log ''
  Log '===== removing ====='
  $freed = [int64]0
  foreach ($n in $Names) {
    $p = Get-AppxPackage -AllUsers | Where-Object { $_.Name -like "*$n*" } | Select-Object -First 1
    if (-not $p) { Log ('  SKIP (not found): ' + $n); continue }
    if ($p.Name -match $frameworks) { Log ('  SKIP (framework): ' + $p.Name); continue }
    $mb = [math]::Round((Get-Size $p.InstallLocation) / 1MB, 0)
    try {
      $p | Remove-AppxPackage -AllUsers -ErrorAction Stop
      $freed += $mb * 1MB
      Log ('  REMOVED  {0} MB  {1}' -f $mb, $p.Name)
    } catch {
      Log ('  FAILED   {0}  ({1})' -f $p.Name, $_.Exception.Message)
    }
  }
  Log ('  total removed (approx): {0} MB' -f [math]::Round($freed / 1MB, 0))
}

$v = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
Log ''
Log ('C: free = ' + [math]::Round($v.FreeSpace / 1GB, 2) + ' GB')
try { [IO.File]::WriteAllLines($LogFile, $out, [Text.Encoding]::UTF8) } catch {}
