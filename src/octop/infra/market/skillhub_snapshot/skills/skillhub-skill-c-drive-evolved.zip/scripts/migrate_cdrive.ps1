﻿# C盘清理转移进化版 - 参数化迁移引擎
# 用法：
#   & migrate_cdrive.ps1                    # 自动选盘 + 最大程度清理
#   & migrate_cdrive.ps1 -Drive F           # 迁到 F 盘 + 最大程度
#   & migrate_cdrive.ps1 -Drive F -Target 30 # 迁到 F 盘，温和清理约 30G
#   & migrate_cdrive.ps1 -Target 50          # 自动选盘，标准清理约 50G
param(
  [string]$Drive = "",      # 目标盘符，空则自动选剩余空间最大的非系统盘
  [string]$Target = "max"   # 清理目标：30 / 50 / max（或"最大"）
)

$ErrorActionPreference = 'Continue'
$script:log = "$PSScriptRoot\_migrate.log"

function Log($msg) {
  $ts = Get-Date -Format 'HH:mm:ss'
  $line = "$ts  $msg"
  $line | Tee-Object -FilePath $script:log -Append
}

function Remove-DirNet($path) {
  if (-not (Test-Path -LiteralPath $path)) { return }
  foreach ($f in @(Get-ChildItem $path -Recurse -File -Force -ErrorAction SilentlyContinue)) {
    try { [System.IO.File]::Delete($f.FullName) } catch {}
  }
  for ($i=0; $i -lt 3000; $i++) {
    $dirs = @(Get-ChildItem $path -Recurse -Directory -Force -ErrorAction SilentlyContinue |
              Sort-Object { $_.FullName.Length } -Descending)
    if ($dirs.Count -eq 0) { break }
    $r = 0
    foreach ($d in $dirs) { try { [System.IO.Directory]::Delete($d.FullName, $false); $r++ } catch {} }
    if ($r -eq 0) { break }
  }
  try { [System.IO.Directory]::Delete($path, $false) } catch {}
}

# 单目录迁移：robocopy -> 校验 -> 改名备份 -> 建 junction -> 读写测试 -> 删备份
function Migrate-Dir($src, $dst) {
  if (-not (Test-Path -LiteralPath $src)) { Log "  跳过：源不存在"; return $false }
  $item = Get-Item -LiteralPath $src -Force
  if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Log "  已是软链接，跳过"; return $false }
  if (-not (Test-Path -LiteralPath $dst)) { Log "  跳过：目标副本不存在（需先复制）"; return $false }

  robocopy "$src" "$dst" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /MT:16 /NFL /NDL /NP /NJS /NJH /XJ | Out-Null
  $rc = $LASTEXITCODE
  if ($rc -ge 8) { Log "  复制失败 (robocopy exit=$rc)，跳过"; return $false }

  $sc = (Get-ChildItem $src -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object).Count
  $dc = (Get-ChildItem $dst -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object).Count
  if ($dc -lt $sc) { Log "  副本文件数不足（源 $sc / 副本 $dc），跳过"; return $false }

  $bk = "$src.old"
  if (Test-Path -LiteralPath $bk) { Remove-DirNet $bk }
  try { Rename-Item -LiteralPath $src -NewName $bk -ErrorAction Stop }
  catch { Log "  改名失败（可能被占用）：$($_.Exception.Message)"; return $false }

  try { New-Item -ItemType Junction -Path $src -Target $dst -ErrorAction Stop | Out-Null }
  catch { Rename-Item -LiteralPath $bk -NewName $src -ErrorAction SilentlyContinue; Log "  建软链接失败已回滚"; return $false }

  # 读写测试
  try { "x" | Out-File (Join-Path $src '_wbtest.txt') -Encoding ascii -ErrorAction Stop; Start-Sleep -Milliseconds 300 } catch {}
  $ok = Test-Path (Join-Path $dst '_wbtest.txt')
  Remove-Item (Join-Path $dst '_wbtest.txt') -Force -ErrorAction SilentlyContinue
  if (-not $ok) { Log "  ⚠ 读写测试未通过，保留备份"; return $false }

  Remove-DirNet $bk
  $freed = [math]::Round($sc * 1MB / 1MB, 0)  # 占位（实际按大小统计）
  Log "  成功！软链接已建立，备份已删除"
  return $true
}

# 1. 确定目标盘符
if ($Drive -eq "") {
  $cand = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -notin @('C','I','Z') -and $_.Free -gt 30GB } | Sort-Object Free -Descending | Select-Object -First 1
  if ($cand) { $Drive = $cand.Name; Log "自动选定目标盘：$Drive（剩余 $([math]::Round($cand.Free/1GB,2)) GB）" }
  else { Log "未找到合适的非系统盘，请用 -Drive 指定"; exit 1 }
} else {
  $Drive = $Drive.Trim().TrimEnd(':').ToUpper()
  $t = Get-PSDrive -Name $Drive -ErrorAction SilentlyContinue
  if (-not $t) { Log "盘符 $Drive 不存在"; exit 1 }
  Log "目标盘：$Drive（剩余 $([math]::Round($t.Free/1GB,2)) GB）"
}

# 2. 确定清理目标分级
$tn = switch -Regex ($Target) {
  '^30$|温和|L1|清一点' { 1 }
  '^50$|标准|L2|尽量'   { 2 }
  'max|最大|全部|L3|激进' { 3 }
  default {
    if ($Target -match '^\d+$' -and [int]$Target -gt 0) { if ([int]$Target -le 30) { 1 } elseif ([int]$Target -le 50) { 2 } else { 3 } }
    else { 3 }
  }
}
$levelName = @('','L1 温和(约30G)','L2 标准(约50G)','L3 激进(最大程度)')[$tn]
Log "清理目标：$levelName"

# 3. 扫描用户目录候选（无需管理员，可直接迁移）
$appRoam = "$env:APPDATA"
$appLocal = "$env:LOCALAPPDATA"
$profile = "$env:USERPROFILE"
$scanRoots = @($appRoam, $appLocal, $profile)

$candidates = @()
foreach ($root in $scanRoots) {
  Get-ChildItem $root -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $it = Get-Item $_.FullName -Force
    $isLink = ($it.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
    if ($isLink) { return }
    $s = (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    if ($s -gt 500MB) {
      $candidates += [PSCustomObject]@{ Src=$_.FullName; GB=[math]::Round($s/1GB,2); Raw=$s }
    }
  }
}
$candidates = $candidates | Sort-Object Raw -Descending

Log "`n扫描到 $($candidates.Count) 个 >500MB 候选目录："
$candidates | ForEach-Object { Log ("  {0,-50} {1,6} GB" -f $_.Src, $_.GB) }

# 4. 按分级决定迁移多少
$limitGB = switch ($tn) { 1 { 25 } 2 { 45 } 3 { 9999 } }
$picked = @()
$sum = 0.0
foreach ($c in $candidates) {
  if ($sum -ge $limitGB -and $tn -ne 3) { break }
  $picked += $c
  $sum += $c.GB
}
Log "`n本次迁移 $($picked.Count) 项，预计释放约 $([math]::Round($sum,1)) GB"

# 5. 执行迁移
$base = "${Drive}:\C盘迁移"
Log "`n开始迁移（目标根目录 $base）..."
$okCount = 0
foreach ($c in $picked) {
  # 目标路径：保留原盘符后的相对路径结构
  $rel = ""
  if ($c.Src -like "$appRoam*")   { $rel = "Roaming" + $c.Src.Substring($appRoam.Length) }
  elseif ($c.Src -like "$appLocal*") { $rel = "Local" + $c.Src.Substring($appLocal.Length) }
  else { $rel = "Profile" + $c.Src.Substring($profile.Length) }
  $dst = Join-Path $base ($rel.Replace(':',''))

  Log "----------------------------------------"
  Log "[$($c.Src)] -> $dst"
  # 先复制（目标不存在才复制）
  if (-not (Test-Path -LiteralPath $dst)) {
    robocopy $c.Src $dst /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /MT:16 /NFL /NDL /NP /NJS /NJH /XJ | Out-Null
    $rc = $LASTEXITCODE
    if ($rc -ge 8) { Log "  复制失败 exit=$rc，跳过"; continue }
  }
  if (Migrate-Dir $c.Src $dst) { $okCount++ }
}

# 6. 系统级清理（按分级）
# 注意：绝不生成 .bat（SkillHub 禁止，且运行时生成脚本属高危行为）。
# 管理员会话直接执行；非管理员只输出命令清单，交给用户自行提权执行。
$cmds = New-Object System.Collections.ArrayList
if ($tn -ge 1) {
  [void]$cmds.Add('powercfg /h off')
  [void]$cmds.Add('reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 0 /f')
}
if ($tn -ge 2) {
  [void]$cmds.Add('Dism.exe /Online /Cleanup-Image /StartComponentCleanup')
}
if ($tn -ge 3) {
  # 只限容，绝不 delete shadows（保留系统还原能力）
  [void]$cmds.Add('vssadmin resize shadowstorage /for=C: /on=C: /maxsize=5GB')
  [void]$cmds.Add('net stop wuauserv')
  [void]$cmds.Add('del /q /s /f "C:\Windows\SoftwareDistribution\Download\*"')
  [void]$cmds.Add('net start wuauserv')
}

Log ""
Log "===== 系统级清理命令 (Level $tn) ====="
foreach ($cmd in $cmds) { Log "  $cmd" }

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($isAdmin -and $cmds.Count -gt 0) {
  Log ""
  Log "当前为管理员会话，开始执行 ..."
  foreach ($cmd in $cmds) {
    Log "  > $cmd"
    try {
      $o = & cmd.exe /c $cmd 2>&1 | Out-String
      if ($o.Trim()) { Log ('    ' + $o.Trim()) }
    } catch { Log "    FAILED: $($_.Exception.Message)" }
  }
} else {
  Log ""
  Log "非管理员会话，未自动执行。请在【管理员 PowerShell】中逐条运行上面的命令。"
}

# 7. 报告
$d = Get-PSDrive C
Log "`n========================================"
Log "迁移成功 $okCount / $($picked.Count) 项"
Log "C 盘可用空间：$([math]::Round($d.Free/1GB,2)) GB"
Log "===== 迁移引擎结束 ====="
