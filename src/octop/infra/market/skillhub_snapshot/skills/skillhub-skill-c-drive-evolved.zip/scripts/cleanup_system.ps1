﻿<#
系统级清理：按实测收益优先级执行，只做安全项
用法（需管理员）：
  & cleanup_system.ps1 -Level 1      # 关休眠 + 清回收站
  & cleanup_system.ps1 -Level 2      # + DISM
  & cleanup_system.ps1 -Level 3      # + 还原点限容 + WinREAgent 强删
#>
param([int]$Level = 2, [string]$LogFile = 'C:\_cdrive_cleanup.log')

# --- admin guard ---
$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  $caller = $MyInvocation.MyCommand.Path
  Write-Host ''
  Write-Host '  [ERROR] This script requires administrator privileges.' -ForegroundColor Red
  Write-Host '  Open PowerShell as administrator (right-click "Run as administrator"), then:' -ForegroundColor Yellow
  Write-Host "    powershell -ExecutionPolicy Bypass -File `"$caller`" -Level $Level" -ForegroundColor Cyan
  Write-Host '  Or from any shell:' -ForegroundColor Yellow
  Write-Host "    Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','`"$caller`"','-Level','$Level'" -ForegroundColor Cyan
  Write-Host ''
  exit 1
}
$ErrorActionPreference = 'Continue'
$out = New-Object System.Collections.ArrayList

function Log($m) {
  $ts = Get-Date -Format 'HH:mm:ss'
  $line = "[$ts] $m"
  [void]$out.Add($line)
  Write-Host $line
}
function FreeC {
  $v = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
  return [math]::Round($v.FreeSpace / 1GB, 2)
}

$before = FreeC
Log "C: free BEFORE = $before GB"

# ---- L1: hibernate ----
Log '--- [1] disable hibernate (also kills fast startup) ---'
powercfg /h off 2>&1 | Out-Null
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 0 /f | Out-Null
Log ('  hibernate off: ' + (-not (Test-Path 'C:\hiberfil.sys')))
Log ('  HiberbootEnabled set to 0 (prevents hiberfil from coming back after Windows Update)')

# ---- L1: recycle bin ----
Log '--- [2] empty recycle bin ---'
try { Clear-RecycleBin -DriveLetter C -Force -ErrorAction Stop; Log '  emptied' }
catch { Log ('  skipped: ' + $_.Exception.Message) }

if ($Level -ge 2) {
  Log '--- [3] DISM component cleanup (10-20 min) ---'
  Dism.exe /Online /Cleanup-Image /StartComponentCleanup
  Log '  DISM done'
}

if ($Level -ge 3) {
  Log '--- [4] cap restore point storage at 5 GB (keeps existing points) ---'
  vssadmin resize shadowstorage /for=C: /on=C: /maxsize=5GB
  Log '  resized'

  Log '--- [5] force-delete C:\$WinREAgent ---'
  $p = 'C:\$WinREAgent'
  if (Test-Path -LiteralPath $p) {
    takeown /F $p /R /A /D Y 2>&1 | Out-Null
    icacls $p /grant '*S-1-5-32-544:(OI)(CI)F' /T /C /Q 2>&1 | Out-Null
    cmd /c "rd /s /q `"$p`"" 2>&1 | Out-Null
    if (Test-Path -LiteralPath $p) { Log '  FAILED - still there (TrustedInstaller)' }
    else { Log '  removed' }
  } else { Log '  not present' }

  Log '--- [6] clear Windows Update download cache ---'
  Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
  Get-ChildItem 'C:\Windows\SoftwareDistribution\Download' -Recurse -Force -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  Start-Service wuauserv -ErrorAction SilentlyContinue
  Log '  done'
}

$after = FreeC
Log "C: free AFTER = $after GB"
Log "TOTAL RECLAIMED = $([math]::Round($after - $before, 2)) GB"

try { [IO.File]::WriteAllLines($LogFile, $out, [Text.Encoding]::UTF8) } catch {}
