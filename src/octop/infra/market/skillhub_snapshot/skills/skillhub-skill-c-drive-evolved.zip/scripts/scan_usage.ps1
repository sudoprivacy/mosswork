﻿# 扫描 C 盘所有大户（含隐形大户），输出按大小排序清单
# 用法：& scan_usage.ps1 [-Top 30]
param([int]$Top = 30)

$ErrorActionPreference = 'SilentlyContinue'

Write-Host "===== C 盘大户扫描 =====" -ForegroundColor Cyan
$d = Get-PSDrive C
Write-Host ("C 盘：总 {0} GB | 已用 {1} GB | 可用 {2} GB" -f [math]::Round(($d.Used+$d.Free)/1GB,2), [math]::Round($d.Used/1GB,2), [math]::Round($d.Free/1GB,2))

# 1. 常规目录
$roots = @('C:\Program Files','C:\Program Files (x86)','C:\ProgramData',
           "$env:USERPROFILE\AppData\Local","$env:USERPROFILE\AppData\Roaming","$env:USERPROFILE")
$results = @()
foreach ($root in $roots) {
  Get-ChildItem $root -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $item = Get-Item $_.FullName -Force
    $isLink = ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
    if ($isLink) { return }  # 跳过已是 junction 的
    $s = (Get-ChildItem $_.FullName -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
    $results += [PSCustomObject]@{ Path=$_.FullName; GB=[math]::Round($s/1GB,2); Raw=$s }
  }
}

Write-Host "`n--- 目录类（已排除 junction）---" -ForegroundColor Yellow
$table = $results | Sort-Object Raw -Descending | Select-Object -First $Top | Format-Table Path, GB -AutoSize | Out-String
Write-Host $table

# 2. 根目录隐形文件
Write-Host "--- C 盘根目录系统文件 ---" -ForegroundColor Yellow
Get-ChildItem C:\ -Force -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 100MB } | ForEach-Object {
  Write-Host ("{0,-25} {1,8} GB" -f $_.Name, [math]::Round($_.Length/1GB,2))
}

# 3. Windows 系统可清理项（WinSxS 几十万文件，递归扫描极慢，跳过——它只能用 DISM 清理）
Write-Host "`n--- Windows 系统级可清理项 ---" -ForegroundColor Yellow
Write-Host "WinSxS                      (只能用 DISM 清理，无需扫大小)"
foreach ($wd in @('C:\Windows\Installer','C:\Windows\Logs','C:\Windows\Temp','C:\Windows\SoftwareDistribution\Download')) {
  $s = (Get-ChildItem $wd -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
  Write-Host ("{0,-45} {1,8} GB" -f $wd, [math]::Round($s/1GB,2))
}

Write-Host "`n===== 扫描完成 =====" -ForegroundColor Cyan
