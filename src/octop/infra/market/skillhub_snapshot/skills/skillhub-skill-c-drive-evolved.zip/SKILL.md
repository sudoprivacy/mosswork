---
name: skillhub-skill-c-drive-evolved
description: "# C盘清理转移进化版 v2.1.2"
---

# C盘清理转移进化版 v2.1.2

> **面向用户的图文说明见 `README.md`**（含增长来源图、收益优先级表、junction 原理图、常见 Q&A）。
> 需要向用户解释"为什么 C 盘会变小 / 该先做哪一步"时，直接引用或复述 README 的内容。

## 安全边界（对外承诺，务必遵守）

本技能只做**用户主动发起的本机磁盘维护**，并严格守住以下红线：

- **无网络行为** —— 不请求任何外部地址，不上传任何数据
- **无持久化** —— 不写开机启动、不建计划任务、不装服务
- **无凭据/隐私采集** —— 不读密码、Cookie、浏览器数据
- **不自动修改安全软件设置** —— 删除慢时可口头建议用户自行临时关闭实时防护，但不得代劳
- **不动用户个人文件** —— 桌面 / 文档 / 下载 / 图片一律不碰
- **还原点只限容不删除** —— 保留系统回退能力

用「目录联接（junction）」把软件目录搬到用户指定的盘，软件无感知继续用；并按实测收益优先级分级清理。

## 相比 v1 的关键进化

v1 只讲了"怎么迁"，v2 补上了三个更致命的问题：**扫描数字是假的**、**删不动的真正原因**、
**Windows 更新才是增长主因**。这三点不知道，会白干一整天。

## 核心原理

junction 是 NTFS 目录联接，创建后：
- 软件仍访问 `C:\原路径`，系统透明重定向到 `<盘符>:\新路径`
- **后续新数据也落新盘** —— 优于「复制+改快捷方式」
- 对注册表、环境变量、快捷方式零影响

流程：**定参数 → 提权扫描 → 剔除假占用 → 按收益排序 → 迁移/清理 → 写入测试 → 删备份 → 建长期维护**

---

## 阶段一：提权扫描（不可跳过，否则数字全是错的）

### 坑 1：非管理员扫描会严重低估

非管理员的 `du` / `Get-ChildItem` 遇到无权限目录会**静默跳过**——不报错、不计数。
实测：Program Files 真实 30.8G 却只测出 9.1G，Windows 真实 34.7G 测出 16G，WinSxS 14.4G 测出 8.5G。

**必须先提权**：让用户以管理员身份打开 PowerShell 再运行扫描脚本，报告写文件再读。
（不要生成 `.bat` —— 市场分发禁止，且运行时生成脚本属高危模式。）

### 坑 2：目录大小之和 ≠ 磁盘实际用量

WinSxS 与 System32 之间有大量硬链接，目录求和必然**远大于**实际 used。
曾因此误判"有 19G 查不到归属"，实际是重复计数。
**永远不要拿目录求和去和 `df` / `Get-PSDrive` 的 used 对账。**

### 坑 3：先判虚实——它到底占不占 C 盘

管理员扫描会**跟随重解析点**，把别的盘的数据算进 C 盘账。
判据只有一条：

```powershell
$i = Get-Item -LiteralPath $path -Force
[bool]($i.Attributes -band [IO.FileAttributes]::ReparsePoint)   # True = 不占 C 盘
$i.Target                                                        # 真正占用在哪
```

实测一台机器上，`ProgramData\WorkBuddy`(1.64G)、`Autodesk`(2.1G)、`LogiOptionsPlus`(2.03G)
**三个全是 junction 指向 F 盘，合计约 5.8G 全是"假占用"**。
**只有在确认不是链接之后，才值得为它的体积想办法。**

### 扫描命令

```powershell
# 一级目录 + Windows 子目录 + 影子存储，一起查
Get-ChildItem C:\ -Directory -Force | ForEach-Object { ... }        # 需提权
Get-CimInstance Win32_ShadowStorage                                  # 还原点占了多少
Get-CimInstance Win32_ShadowCopy                                     # 有几个还原点
```

---

## 阶段二：按实测收益优先级回收

一次完整实战的实测数据（139G 的 C 盘，一天回血 14G），**按单位时间收益排序**：

| 优先级 | 项目 | 实测释放 | 耗时 | 风险 |
|---|---|---|---|---|
| 1 | **关休眠** `powercfg /h off` | 6.4G | 秒 | 低（失去休眠+快速启动） |
| 2 | **缓存目录 junction 迁走** | 3G | 中 | 低 |
| 3 | **卸载不用的 Store 应用** | 2.8G | 分 | 低 |
| 4 | **`$WinREAgent` 残留** | 1.9G | 分 | 中（需 takeown） |
| 5 | **还原点限容**（只限容不删） | 1.9G | 秒 | 低 |
| 6 | Panther 日志 + 回收站 | 1.2G | 秒 | 低 |

```powershell
# 1. 关休眠 —— 必须同时关快速启动，否则 Windows 更新后会重新生成 hiberfil.sys，前功尽弃
powercfg /h off
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 0 /f

# 5. 还原点：只限容，不删还原点（保留系统回退能力）
vssadmin resize shadowstorage /for=C: /on=C: /maxsize=5GB
```

⚠ **不要使用 `vssadmin delete shadows /all`** —— 那会删光所有还原点、丢掉系统回退能力。
限容（resize）已能回收空间，且系统会自动裁掉最老的还原点，保留最近的可用。

### 关休眠那条命令的隐藏坑

`powercfg /h off` 之后如果**只**做这一步，下次 Windows 大更新会把 hiberfil.sys 又建回来。
必须配 `HiberbootEnabled=0`。很多人"关了又复胖"就是漏了这行。

---

## 阶段三：Windows 更新才是增长主因

一次诊断：3 天新增 5.5G，其中 **4.5G 属于 Windows 更新**（WinSxS +2.37G、System32 +0.79G、
servicing +0.26G、CBS 日志 +0.44G），应用侧只占 0.95G。

**用户问"以后还会被大量占用吗"，答案：会，但凶猛程度大幅下降。** 半年预估增量：

| 来源 | 半年预估 | 能否根治 |
|---|---|---|
| Windows 更新（WinSxS） | +8G | ❌ 只能定期 DISM 削 |
| 临时文件 | +6G | ✅ 周清理自动化 |
| 软件更新残留（如 Edge 双版本并存） | +3G | ⚠️ 部分可卸载 |
| Everything 等索引 | +0.5G | ❌ 进程常驻 |

```powershell
Dism.exe /Online /Cleanup-Image /StartComponentCleanup      # 10~20 分钟，唯一官方手段
# /ResetBase 释放更多，但已装更新将无法卸载，谨慎
```

---

## 阶段四：Store 应用（WindowsApps，常是最大的隐藏肥肉）

`C:\Program Files\WindowsApps` 实测可达 **16G**，特点是：

- **几乎每个应用都留着新旧两个版本**，更新完旧的没清，重复占用可达一半
- **目录不可手动删**（TrustedInstaller 保护 + 会破坏应用注册）
- 唯一正确做法：`Get-AppxPackage | Remove-AppxPackage`

```powershell
# 扫描：列出每个包的大小，识别重复版本
Get-AppxPackage -AllUsers | ForEach-Object { ... $_.InstallLocation ... }

# 卸载（必须排除框架组件，否则其他应用会打不开）
$frameworks = 'WindowsAppRuntime|VCLibs|NET.Native|Xaml|UI.Xaml|Microsoft.NET.CoreRuntime'
Get-AppxPackage | Where-Object { $_.Name -notmatch $frameworks -and $_.Name -in $toRemove } |
  Remove-AppxPackage
```

**卸载后会回来**：Windows 大版本更新时预置应用会自行恢复，脚本要设计成**可重复运行**。

---

## 阶段五：删除慢 / 删不动的真相

### 决定性因素：Defender 实时防护

实测同一批文件：

| 实时防护 | 速度 | 26799 个文件 |
|---|---|---|
| 开启 | 约 2.7 秒/个 | 58 分钟未完成 |
| 关闭 | — | **10 秒**（约 2700 倍） |

> **本技能不自动修改安全软件设置。**
> 若用户抱怨删除极慢，只做**口头建议**：由用户自己在「Windows 安全中心 → 病毒和威胁防护」
> 临时关闭实时保护，删完**务必手动开回来**。
> AI 侧不要代劳、不要生成关闭防护的命令；若用户已自行关闭且忘记恢复，提醒其开启即可。

### TrustedInstaller 保护的目录（如 `C:\$WinREAgent`）

直接 `rd` 会静默失败并卡死整整批操作，表现为"脚本卡住"。正确顺序：

```text
takeown /F "C:\$WinREAgent" /R /A /D Y
icacls "C:\$WinREAgent" /grant *S-1-5-32-544:(OI)(CI)F /T /C /Q
rd /s /q "C:\$WinREAgent"
```

### 枚举目录时的容错陷阱

`[IO.Directory]::GetFiles(..., 'AllDirectories')` 遇到受限子目录会**抛异常**，
若外层有 `SilentlyContinue`，异常被吞 → 误报"0 个文件" → 整个删除被跳过，
只剩空壳留在盘上。要用逐层容错递归，并**核对删除前后的文件数**。

---

## 哪些能迁、哪些绝对别动

| 类型 | 可迁? | 说明 |
|---|---|---|
| `AppData\Local\X` / `AppData\Roaming\X` | ✅ 首选 | 软件缓存与用户数据，junction 效果最好 |
| 用户级程序 `AppData\Local\Programs` | ✅ | 免安装程序（排除正在运行的本体） |
| 用户主目录 `WPS Cloud Files` / `.android` / `.nuget` | ✅ | 真实占盘大户 |
| `ProgramData\X` | ⚠️ 需管理员 | 软件共享数据 |
| `Program Files\X` 独立软件 | ⚠️ 需管理员 | 移动后不能「修复安装」，需卸载重装 |
| **Microsoft Office** | ❌ | ClickToRun 模式，移动即损坏 |
| **Microsoft Edge / Windows 组件** | ❌ | 破坏 Windows Update |
| **Common Files** | ❌ | 多软件共享，移动致大面积失效 |
| **Autodesk AdODIS / Adobe 安装基础设施** | ❌ | 移动后无法在线更新 |
| **NVIDIA 显卡驱动** | ❌ | 停服务会屏闪/驱动重载 |
| **WinSxS** | ❌ 手动删 | 只用 DISM |
| **`C:\Recovery`** | ❌ | 系统重置依赖 |
| **`C:\Windows\Installer`** | ❌ | 删了软件卸不掉 |
| **`C:\Windows\assembly`** | ❌ | .NET GAC |

**Program Files 的性价比陷阱**：实测 30.8G 里真正能安全迁走的只有 2~3G
（Office 5.7G + Common Files 5.1G + NVIDIA + WindowsApps 16G 全动不了）。
**先扫清楚再决定，别一上来就啃这块。**

---

## 迁移核心操作

```powershell
$src='C:\...'; $dst='<盘>:\...'; $bk="$src.old"
robocopy $src $dst /E /COPY:DAT /R:1 /W:1 /MT:16 /NFL /NDL /NP /XJ   # 不要 /COPYALL /MIR
# 校验文件数：副本数必须 >= 源数
Rename-Item -Path $src -NewName ((Split-Path $src -Leaf)+'.old') -ErrorAction Stop
New-Item -ItemType Junction -Path $src -Target $dst        # 纯 PowerShell，别用 cmd /c mklink
# 读写测试：写测试文件到 $src，确认 $dst 里出现 —— 这是唯一可信的验证
# 确认无误后删 .old 备份
```

⚠ **robocopy 在某些受限执行环境里根本不执行**（退出码为 null，目标目录仍空）。
遇此情况改用 `cp -a`（Git Bash）或 PowerShell `Copy-Item`，大目录用 `-n` 续传 + 后台跑。

## 孤儿数据检查（改指链接后必做）

把 C 盘链接从旧位置改指新位置后，**旧位置会变成没人引用的孤儿**。判定方法：
比对两边文件数 + 最后修改时间（新的那份时间在更新 = 正在被用，旧的 = 孤儿）。

```powershell
$a = (Get-ChildItem $oldPath -Recurse -File -Force | Measure-Object).Count
$b = (Get-ChildItem $newPath -Recurse -File -Force | Measure-Object).Count
(Get-ChildItem $oldPath -Recurse -File | Sort-Object LastWriteTime -Descending)[0].LastWriteTime
```

实测回收过一个 1.64G 的孤儿副本。删除前加**安全闸**：确认 C 盘链接确实指向新位置、且新副本完整，否则中止。

---

## 编码与脚本工程规范（血泪坑）

| 文件 | 编码 | 原因 |
|---|---|---|
| `.ps1` | **UTF-8 with BOM** | PS 5.1 读无 BOM UTF-8 按 GBK 解析 → 中文乱码崩溃 |
| 控制台输出 | **英文优先** | 非 UTF-8 终端下中文易乱码，重要结论同时写入日志文件 |

```powershell
# ps1 写完后必做：转 BOM + 校验首字节 + 语法检查
$c = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText($p, $c, (New-Object Text.UTF8Encoding($true)))
([IO.File]::ReadAllBytes($p)[0..2]) -join ','      # 必须 239,187,191
$tokens=$null; $errors=$null
[Management.Automation.Language.Parser]::ParseFile($p, [ref]$tokens, [ref]$errors)
$errors.Count                                        # 必须 0
```

### 脚本交付与运行的铁律

1. **逻辑一律写在 .ps1 里**，用 `-File` 调用；不要拼多行 `-Command`
   （多段双引号在命令行下不可靠，实测出现过命令被截断）
2. **不要生成 `.bat` / `.cmd`** —— 市场分发禁止，且"运行时生成脚本再执行"是高危模式
3. **结果必须写日志文件**。用户曾报告"脚本一闪而过"，实际执行完毕但没看到结果——
   只能靠磁盘实测判断成败。**效果要以实测为准，不能凭窗口是否停住**
4. 需要管理员的脚本在头部做 admin guard，非管理员时报错退出并打印提权命令，不要静默失败

提权运行方式（交给用户或助手执行）：

```powershell
Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','<脚本绝对路径>.ps1'
```

### ps1 语法坑

- `-Filter "DeviceID='$d:'"` 中的 `$d:` 会被当作作用域解析而报错。
  把冒号放进变量：`@('C:','F:')` 再 `-Filter "DeviceID='$d'"`
- `($list | Measure-Object Length -Sum).Sum` 可能为 `$null`，做加法前先 `if ($m) { $s=[int64]$m }`
- `Get-ChildItem -Include *.log -Recurse` 不可靠，改用
  `| Where-Object { @('.log','.txt') -contains $_.Extension.ToLower() }`

---

## 权限边界

- **非管理员会话能做**：读、复制、迁移用户目录下的内容
- **必须用户提权执行**：Program Files / ProgramData 下改名、建 junction、删除；DISM / 休眠 / 还原点
- 助手侧 `Start-Process -Verb RunAs` 通常被安全策略拦，**只能让用户在管理员 PowerShell 里运行 .ps1**
- 优化体验：**助手侧先把复制做完**，用户提权后只跑改名+建链，秒过

## 常见误判（高频）

- robocopy 退出码 1/2/3 都是**正常成功**，后台显示 "failed" 是误标，务必另行校验文件数
- **"目录很大" ≠ "占 C 盘"**：先查 ReparsePoint，见阶段一坑 3
- 同大小同时间戳的两个文件**不一定**是硬链接，用 `fsutil hardlink list <file>` 确认
  （返回 1 行 = 独立副本）。NTFS 压缩也会让逻辑大小 ≠ 实际占盘
- `Get-Process` 用短关键词会误匹配（`et`→Widgets、`Tim`→RuntimeBroker），
  检测进程必须用 `-eq` 精确匹配或完整进程名
- `Test-Path C:\hiberfil.sys` 普通权限会误报不存在，用 `Get-ChildItem C:\ -Force -File` 确认
- 后台复制超大目录会被超时中断，需 `cp -a -n` 续传或后台跑

## 长期维护（建议建自动化）

C 盘清理不是一次性的。建两个互补的定时任务：

- **每周**：清临时文件 / 浏览器缓存 / 回收站
- **每月**：`DISM /StartComponentCleanup` + **逐个验证 junction 是否仍有效** + 列出前 5 大户

验证 junction 必须**写入测试文件**再确认它出现在目标盘，只看"链接存在"不算数：

```powershell
Set-Content (Join-Path $src '_vfy.txt') 'v'
Start-Sleep -Milliseconds 200
$ok = Test-Path (Join-Path $dst '_vfy.txt')     # True 才算真的通
Remove-Item (Join-Path $dst '_vfy.txt') -Force
Remove-Item (Join-Path $src '_vfy.txt') -Force
```

## 脚本清单

> **SkillHub 不允许 `.bat` 文件**（防止用户误双击运行任意脚本），
> 所以自提权逻辑全部内联到对应 `.ps1` 头部，调用时需在管理员 PowerShell 里执行。
> AI agent 调用前自行 `Start-Process powershell -Verb RunAs` 提权即可。

| 脚本 | 作用 | 需提权 |
|---|---|---|
| `scripts/scan_usage.ps1` | 扫描 C 盘大户（已排除 junction），输出排序清单 | ❌ |
| `scripts/scan_admin.ps1` | **提权扫描**：真实大小 + 标注 junction 假占用 + 还原点/影子存储 | ✅ |
| `scripts/migrate_cdrive.ps1` | 参数化迁移引擎：`-Drive <盘符>`、`-Target <30\|50\|max>` | 部分 |
| `scripts/cleanup_system.ps1` | 系统级清理：关休眠(含快速启动) / DISM / 还原点限容 / 回收站 / WinREAgent 强删 | ✅ |
| `scripts/uninstall_store_apps.ps1` | WindowsApps 明细扫描 + 识别重复版本 + 安全卸载（排除框架组件） | ✅ |
| `scripts/verify_junctions.ps1` | 验证所有 junction（真写入测试）+ 检查孤儿副本 | ✅ |

## 脚本调用方式（用户面）

需要提权的脚本自带 admin guard：非管理员运行时不会静默失败，
会打印红色 `[ERROR]` 并给出可直接复制粘贴的"管理员运行"命令。

```powershell
# 推荐流程：让任意 shell 一键提权运行
Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','<脚本绝对路径>.ps1'

# 或者：右键 PowerShell 图标 → "以管理员身份运行"，再：
powershell -ExecutionPolicy Bypass -File '<脚本绝对路径>.ps1'
```
