# ch03 — 判别评分器（Discriminative Scorer）

## 为什么会需要判别评分器

投票制只数人头（"出现最多的答案胜出"）但不看推理路径的逻辑质量。一条蒙对的低质量推理路径可能和一条高质量路径获得相同票数。判别评分器给每条路径**独立打分**，解决这个问题。

## 混合损失（Hybrid Loss）

**公式**：L_hybrid = (1−α) × Huber_loss + α × Hinge_loss，默认 α = 0.3

### Huber 回归分量（70% 权重）

让预测分数接近真实奖励值。

- 当误差小（|x| ≤ δ）：L2 损失（平方），梯度平滑
- 当误差大（|x| > δ）：L1 损失（绝对值），对离群值更鲁棒
- 优势：结合了 L2 的精度和 L1 的离群值鲁棒性

### Hinge 排序分量（30% 权重）

让"好路径"的分数 > "坏路径"的分数。

**公式**：max(0, margin - (score_best - score_worst))

- margin：最小可接受的分数差距
- 当最佳路径比最差路径高出至少 margin → 损失为 0
- 当差距不足 → 产生损失，推动模型加大差距
- 优势：显式鼓励好路径胜出

### 为什么缺一不可

- **只有 Huber**：分数回归很准，但不同路径之间的排序关系可能被忽略（两条路径分数都回归到接近 5/10，但实际一条 9/10 一条 1/10）
- **只有 Hinge**：排序关系对了，但绝对分数可能漂移（都往高了打或都往低了打）
- **混合**：Huber 校准绝对量级 + Hinge 约束相对顺序

## 评分流程

```
N 条 CoT 路径
    ↓
特征提取：每条路径的（长度 / 推理步数 / 关键性词汇出现频次 / 逻辑连贯性）
    ↓
轻量 FFN（2层 MLP）
    ↓
输出 [0, 1] 标量分数
    ↓
取最高分路径作为最终输出
```

## 使用方式

```python
# 伪代码示意
def score_cot_paths(paths, model, alpha=0.3):
    scores = []
    for path in paths:
        features = extract_features(path)  # 长度/步数/关键性词汇
        score = model.ffn(features)        # 轻量2层MLP
        scores.append(score)
    return max(scores)  # 取最优路径
```
