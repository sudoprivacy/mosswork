# 术语表

## A-C
- **Consensus（一致性）** — M 次并行解码中出现最频繁的答案的占比。公式：max(y) Count(y) / M。取值 [0.2, 1.0]，是 CoT 是否触发的判断依据。
- **CoT（Chain-of-Thought，思维链）** — 让模型在给出最终答案前先输出推理步骤的方法。E-GRM 中 CoT 是按需触发而非全程标配。

## D-G
- **Direct Answer（直接回答）** — 不经过推理链的简短答案。E-GRM SFT 中占 50% 训练样本。
- **Discriminative Scorer（判别评分器）** — 用混合损失为每条推理路径独立评分的模块，替代传统的投票制。
- **Dynamic CoT Triggering（动态 CoT 触发）** — 用并行解码的答案一致性决定是否触发推理链的核心机制。

## H-M
- **Hinge Loss（铰链损失）** — 排序损失，让好路径分数 > 坏路径分数至少 margin。公式：max(0, margin - (score_best - score_worst))
- **Huber Loss（Huber 损失）** — 结合 L1 和 L2 的鲁棒回归损失。小误差用 L2（平滑），大误差用 L1（抗离群值）。
- **Hybrid Loss（混合损失）** — E-GRM 核心损失函数：L_hybrid = (1−α)×Huber + α×Hinge，α=0.3。Huber 保绝对精度，Hinge 保相对排序。
- **GRM（Generative Reward Model，生成式奖励模型）** — 通过生成文本（CoT + 评分）来评估回答质量的模型家族。
- **GRPO（Group Relative Policy Optimization）** — 用成对偏好数据微调模型，E-GRM 第二阶段可选优化方法。

## O-Z
- **Over-reasoning（过推理）** — 对简单问题强行走 CoT 导致的精度下降现象。τ=0.9 精度反低于 τ=0.8 即为铁证。
- **Parallel Decoding（并行解码）** — 同一输入用不同温度/配置多次解码，M=5 次，作为复杂度探针。
- **Reward Model（奖励模型）** — 用于评判文本质量的模型。GRM 是奖励模型的一个子类（通过生成方式打分）。
- **SFT（Supervised Fine-Tuning，监督微调）** — 用标注数据微调预训练模型。E-GRM 第一阶段用 50/50 混合 SFT。
- **τ（阈值 Tau）** — Consensus 判断阈值，默认 0.8。≥τ 直接答，<τ 触发 CoT。
- **Voting（投票制）** — 传统 GRM 的评分方式：多次采样 → 选答案最多的那个。不评价推理路径质量。
