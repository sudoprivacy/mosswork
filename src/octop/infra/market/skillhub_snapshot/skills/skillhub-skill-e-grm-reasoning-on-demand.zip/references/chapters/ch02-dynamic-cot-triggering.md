# ch02 — 动态 CoT 触发（Dynamic CoT Triggering）

## 核心思路

用 M 次并行解码的**答案一致性**作为"复杂度探针"——答案高度一致说明问题简单，五花八门说明问题复杂。不需要额外分类器、reward model 或手工规则。

## 完整流程

```
输入 Prompt → M=5次并行解码（变温/变Top-p） → 计算Consensus
┌── Consensus ≥ τ（默认 0.8）──→ 直接输出答案（~58% 样本）
└── Consensus < τ ──→ CoT生成 → 判别评分 → 取最优 → 输出
```

## 并行解码配置（M=5）

使用 4 个温度 + 1 个确定性解码：

| 温度 T | 作用 |
|---------|------|
| 0（贪婪） | 最高确定性，baseline |
| 0.3 | 轻度随机，局部探索 |
| 0.7 | 中度随机 |
| 1.0 | 高随机性，探索多样路径 |

5 次答案一致 → 简单问题；5 次答案各不同 → 复杂问题。

## Consensus 计算公式

**Consensus(x) = max(y) Count(y) / M**

- y 为解码输出答案
- Count(y) 为出现最多次的答案的计数
- M = 5
- 取值范围：[0.2, 1.0]
- Consensus=1.0：5次完全一致
- Consensus=0.2：5次全不同（最分散）

## 阈值 τ 调参

| τ | 跳过 CoT 比例 | 效果 |
|---|-------------|------|
| 0.6 | ~72% | 最激进，效率最高但可能遗漏需 CoT 的输入 |
| 0.7 | ~64% | 较激进 |
| **0.8** | **~58%** | **论文默认，效率与精度的最佳平衡点** |
| 0.9 | ~40% | 最保守，接近全 CoT |

**发现**：τ=0.9 精度反低于 τ=0.8（见 ch05），说明存在"过推理"现象。

## 使用方式

```python
# 伪代码示意
def should_trigger_cot(responses, threshold=0.8):
    """判断是否需要触发 CoT"""
    from collections import Counter
    consensus = max(Counter(responses).values()) / len(responses)
    return consensus < threshold  # True → 走 CoT
```
