---
name: skillhub-skill-ppt-palette
description: "基于 Adobe 色轮和谐理论，为 PPT 快速生成配色方案。当用户给出 1–2 个 HEX 色值，或上传/提供一张图片（KV、Logo、参考图）时触发；输出可直接套进 PPT 母版的「着色1–着色6」六色卡。规则：仅 1 个 HEX 输出单色阶方案；有 2 个 HEX 或导入图片则输出 6 套和谐方案（互补/类似/三分/分裂互补/矩形/单色阶），且第二个色值或图片次主色会原样保留为着色3（不加深不漂移，单色阶同样保留）。"
---

# PPT 配色生成（ppt-palette-gen）

## Overview

把「设计色彩色轮空间」工作台的核心算法沉淀为可复用的命令行引擎，让 WorkBuddy 在任意对话中都能：

- **思路 A（写色值）**：用户提供 1–2 个 HEX → 生成配色。
- **思路 B（导图片）**：用户提供一张图片 → 自动提取主色作为基准色①② → 再生成配色。

生成的每套方案都是 6 个协调色（着色1 主色 / 着色2 和谐伴色 / 着色3 强调色 / 着色4 浅主色 / 着色5 深锚点 / 着色6 淡底），可直接填进 PPT 母版的主题色（accent1–6）。

## 触发时机

- 用户说「给我配一套 PPT 配色」「这个蓝色帮我配色」「根据这张 KV 出套配色」等。
- 用户给出 1–2 个 HEX，或贴/传一张图片（品牌 Logo、KV、参考图、海报）。
- 需要为提案/模板快速产出多套协调色卡，且希望品牌色对（②）出现在每套方案里。

## 输出规则（务必遵循）

| 输入 | 输出 |
|------|------|
| 仅 1 个 HEX | **单色阶**方案（同一色相深浅变化的 6 色卡，仅 1 套） |
| 2 个 HEX | 6 套和谐方案；第 2 个 HEX **原样保留为着色3**（不加深、不做近似排斥微调） |
| 导入图片 | 自动提取 ①（主色）+ ②（色相距离≥35° 的次主色）→ 等同「2 个 HEX」的 6 套方案 |

六套非单色方案中，着色2 取不同的「和谐关系色相」（互补+180 / 类似−30 / 三分+120 / 分裂+240 / 矩形+60），在色轮上均匀铺开，彼此明显不同；着色1 与着色3（=②）均原样保留用户输入，保证品牌色对一字不差出现在每套方案（含单色阶）里。

## 工作流程

### 思路 A：写色值生成

1. 解析用户输入的 HEX（1 或 2 个）。
2. 运行引擎脚本（纯 Node，无第三方依赖）：

```bash
node SKILL_DIR/scripts/palette_gen.js --hex1 "#0C4B81"                      # 仅单色阶
node SKILL_DIR/scripts/palette_gen.js --hex1 "#0C4B81" --hex2 "#D8A862"     # 6 套和谐方案
node SKILL_DIR/scripts/palette_gen.js --hex1 "#0C4B81" --hex2 "#D8A862" --title "品牌发布会" --out report.html
```

   脚本会在终端打印每套方案的着色1–6 HEX；加 `--out report.html` 时再产出一份可离线打开的奶油色色卡（含「复制整套 HEX」按钮）。

### 思路 B：导入图片生成

1. 用图片取色脚本（Python + Pillow）提取主色，输出 JSON：

```bash
python SKILL_DIR/scripts/extract_image_colors.py 图片路径
```

   输出示例：`{"c1":{"hex":"#0C4B81",...},"c2":{"hex":"#D8A862",...},"palette":[{"hex":"#0C4B81","score":0.31},...]}`
   ——① 为代表性最高的彩色，② 为色相距离≥35° 的次主色（单一色系时 c2 为 null）。
2. 将得到的 `c1`/`c2` 喂给生成引擎（用 `--json` 透传，避免颜色被重新解析漂移）：

```bash
node SKILL_DIR/scripts/palette_gen.js --json '{"c1":{"hex":"#0C4B81"},"c2":{"hex":"#D8A862"}}' --out report.html
```

   Python 与 Node 的 HEX 包络完全一致，也可直接在终端里把 c1/c2 转成 `--hex1/--hex2` 等效调用。

### 运行环境说明

- `palette_gen.js`：用 Node.js（22.x 优先）直接跑，零依赖。
- `extract_image_colors.py`：需要 Pillow。本机系统 Python 3.12 已自带（`python ...` 即可）；若用托管 venv，请先 `pip install pillow`。
- SKILL_DIR 指本 skill 目录，绝对路径如 `C:/Users/Karting/.workbuddy/skills/ppt-palette-gen`。

## 交付建议

- 默认以文本表格/清单回复 6 套着色1–6 HEX 即可满足即时需求。
- 当用户需要留存、分享或贴进设计稿时，生成 `report.html` 并用 `present_files` 展示预览。
- 强调色（着色3）始终原样等于用户的②或图片次主色（不加深、不漂移），确保品牌色对在每套方案里都一字不差出现——这是该 skill 与通用配色工具的核心差异点。
