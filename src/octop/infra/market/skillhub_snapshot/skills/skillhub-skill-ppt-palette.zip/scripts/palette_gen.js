#!/usr/bin/env node
/* ppt-palette-gen · 配色生成引擎（纯 Node，无第三方依赖）
   端口自「设计色彩色轮空间」v5.4 算法：角色化明度体系 + 白字对比求解 + 近似色排斥
   用法：
     node palette_gen.js --hex1 "#0C4B81"                      → 仅单色阶（1 个 HEX）
     node palette_gen.js --hex1 "#0C4B81" --hex2 "#D8A862"      → 6 套和谐方案（② 锁定强调色）
     node palette_gen.js --json '{"c1":"#0C4B81","c2":"#D8A862"}'  → 同上，从图片取色结果喂入
     [--title "我的项目"] [--out report.html]                  → 同时产出可离线打开的 HTML 色卡
*/
'use strict';

/* ---------------- 色彩工具 ---------------- */
function hexToRgb(hex){
  hex=(hex||'').replace('#','').trim();
  if(hex.length===3) hex=hex.split('').map(c=>c+c).join('');
  if(!/^[0-9a-fA-F]{6}$/.test(hex)) return null;
  const n=parseInt(hex,16);
  return {r:(n>>16)&255,g:(n>>8)&255,b:n&255};
}
function rgbToHex(r,g,b){
  const h=x=>x.toString(16).padStart(2,'0');
  return '#'+h(r)+h(g)+h(b);
}
function rgbToHsl(r,g,b){
  r/=255;g/=255;b/=255;
  const mx=Math.max(r,g,b),mn=Math.min(r,g,b);
  let h=0,s=0,l=(mx+mn)/2;
  if(mx!==mn){
    const d=mx-mn;
    s=l>0.5?d/(2-mx-mn):d/(mx+mn);
    if(mx===r)h=(g-b)/d+(g<b?6:0);
    else if(mx===g)h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h*=60;
  }
  return {h,s:s*100,l:l*100};
}
function hslToRgb(h,s,l){
  h=(h%360+360)%360;s/=100;l/=100;
  const c=(1-Math.abs(2*l-1))*s;
  const x=c*(1-Math.abs((h/60)%2-1));
  const m=l-c/2;
  let r=0,g=0,b=0;
  if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}
  else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}
  return {r:Math.round((r+m)*255),g:Math.round((g+m)*255),b:Math.round((b+m)*255)};
}
function hslToHex(h,s,l){const {r,g,b}=hslToRgb(h,s,l);return rgbToHex(r,g,b);}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function parseColor(hex){
  const rgb=hexToRgb(hex);
  if(!rgb) return null;
  return {hex:rgbToHex(rgb.r,rgb.g,rgb.b),rgb,hsl:rgbToHsl(rgb.r,rgb.g,rgb.b)};
}
function lumOf(hex){
  const {r,g,b}=hexToRgb(hex);
  const f=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);};
  return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b);
}
function contrast(a,b){
  const l1=lumOf(a),l2=lumOf(b);
  const hi=Math.max(l1,l2),lo=Math.min(l1,l2);
  return (hi+0.05)/(lo+0.05);
}
function rgbDist(a,b){
  const x=hexToRgb(a),y=hexToRgb(b);
  return Math.hypot(x.r-y.r,x.g-y.g,x.b-y.b);
}

/* ---------------- 方案定义 ---------------- */
const SCHEMES=[
  {key:'complementary',name:'互补配色',style:'科技·发布会',desc:'主色与对角色强烈对撞，视觉冲击力强，适合强调型 PPT。'},
  {key:'analogous',name:'类似配色',style:'商务·品牌',desc:'相邻色系自然过渡，安全和谐，适合简约与品牌 PPT。'},
  {key:'triadic',name:'三分色',style:'教育·创意',desc:'三主色均衡分布，活泼不杂乱，适合复盘与创意 PPT。'},
  {key:'split',name:'分裂互补',style:'人文·生活',desc:'主色配两枚邻近对撞色，柔和中带张力，适合美食生活类。'},
  {key:'tetradic',name:'矩形四色',style:'活动·营销',desc:'四色饱满，层次与对比兼得，适合招商与活动 PPT。'},
  {key:'mono',name:'单色阶',style:'高端·金融',desc:'同色相深浅变化，克制而高级，适合年报与金融 PPT。'}
];

/* ---------------- 核心生成 ---------------- */
function buildScheme(spec, c1, c2){
  const h1=c1.hsl.h, S1=c1.hsl.s, L1=c1.hsl.l;
  const neutral=S1<12;
  const hp=neutral?215:h1;                    // 灰黑基准派生用蓝色相，避免默认红
  let hs=hp, ha=hp;
  // 关系色相五点均匀铺开（60/120/180/240/330），确保任意两套方案的着色2 至少相隔 60°
  switch(spec.key){
    case 'complementary': hs=hp+180; ha=hp+180; break;
    case 'analogous':     hs=hp-30;  ha=hp+30;  break;
    case 'triadic':       hs=hp+120; ha=hp+240; break;
    case 'split':         hs=hp+240; ha=hp+210; break;
    case 'tetradic':      hs=hp+60;  ha=hp+240; break;
    case 'mono':          hs=hp;     ha=hp;     break;
  }
  if(c2) ha=c2.hsl.h;                         // ② 存在时强调色相取②（含单色阶，仅影响缺席推导）
  const hsN=((hs%360)+360)%360, haN=((ha%360)+360)%360, hpN=((hp%360)+360)%360;
  const yzS=hsN>=40&&hsN<170;                 // 和谐色落黄绿区（白字对比天然差）
  const yzA=haN>=40&&haN<170;
  let S2=clamp(S1*0.85,42,80), L2=L1>60?clamp(L1-14,42,56):clamp(L1+14,48,66);
  let S3=clamp(S1*1.05,60,88), L3=yzA?44:52;
  let S4=clamp(S1*0.5,30,62),  L4=clamp(Math.max(72,L1+20),72,88);
  if(L1>78){L4=clamp(L1-26,58,70);S4=clamp(S1*0.75,45,80);}
  let S5=clamp(S1*0.95,50,88), L5=clamp(L1-22,8,32);
  if(hpN>=45&&hpN<190) L5=Math.min(L5,24);           // 黄绿/青区深锚点额外压深
  let S6=40, L6=93;
  if(spec.key==='mono'){
    L2=clamp(L1+18,58,74); L3=clamp(L1-16,30,42);
    S5=clamp(S1,55,88);    L5=clamp(L1-26,6,26);
    S6=18; L6=95;
  }
  if(spec.key==='complementary'){
    L2=clamp(L1+20,62,76); S2=clamp(S1*0.8,45,78);
  }
  if(yzS) L2=Math.min(L2,56);
  const cols=[
    c1,
    parseColor(hslToHex(hs,S2,L2)),
    parseColor(hslToHex(ha,S3,L3)),
    parseColor(hslToHex(hp,S4,L4)),
    parseColor(hslToHex(hp,S5,L5)),
    parseColor(hslToHex(hs,S6,L6))
  ];
  cols[1]=solveWhite(cols[1],2.4);
  if(c2){
    cols[2]=c2;                 // ② 原样保留为着色3——不加深、不漂移，单色阶同样保留（v5.5）
  }else{
    cols[2]=solveWhite(cols[2],2.4);
  }
  dedupe(cols);
  if(c2) cols[2]=c2;            // 近似排斥后恢复②原值（神圣级别等同着色1）
  return cols;
}
function solveWhite(c,target){
  let L=c.hsl.l;
  for(let i=0;i<26&&L>26;i++){
    if(contrast('#FFFFFF',hslToHex(c.hsl.h,c.hsl.s,L))>=target) break;
    L-=2;
  }
  return parseColor(hslToHex(c.hsl.h,c.hsl.s,L));
}
function dedupe(cols){
  for(let pass=0;pass<2;pass++){
    for(const idx of [1,2,3,5]){
      const c=cols[idx]; if(!c) continue;
      const minD=nc=>{
        let m=Infinity;
        cols.forEach((o,j)=>{ if(j!==idx&&o){const d=rgbDist(nc.hex,o.hex); if(d<m)m=d;} });
        return m;
      };
      if(minD(c)>=48) continue;
      let best=c, bestMin=minD(c);
      const cands=[];
      if(idx===5){
        for(const dl of [2,4]) cands.push(parseColor(hslToHex(c.hsl.h,c.hsl.s,clamp(c.hsl.l+dl,4,97))));
        for(const sm of [0.7,0.5]) cands.push(parseColor(hslToHex(c.hsl.h,clamp(c.hsl.s*sm,8,96),c.hsl.l)));
      }else{
        for(const dl of [8,-8,16,-16,24,-24]) cands.push(parseColor(hslToHex(c.hsl.h,c.hsl.s,clamp(c.hsl.l+dl,4,95))));
        for(const sm of [0.8,1.2,0.65,1.35]) cands.push(parseColor(hslToHex(c.hsl.h,clamp(c.hsl.s*sm,20,96),c.hsl.l)));
      }
      const ok=cands.filter(x=>idx>2||contrast('#FFFFFF',x.hex)>=2.2);
      for(const nc of (ok.length?ok:cands)){
        const m=minD(nc);
        if(m>bestMin){bestMin=m;best=nc;}
      }
      cols[idx]=best;
    }
  }
  return cols;
}

/* ---------------- 解析入参 ---------------- */
function parseArgs(argv){
  const o={hex1:null,hex2:null,json:null,title:null,out:null};
  for(let i=0;i<argv.length;i++){
    const a=argv[i];
    if(a==='--hex1') o.hex1=argv[++i];
    else if(a==='--hex2') o.hex2=argv[++i];
    else if(a==='--json') o.json=argv[++i];
    else if(a==='--title') o.title=argv[++i];
    else if(a==='--out') o.out=argv[++i];
  }
  return o;
}
function resolveInputs(o){
  if(o.json){
    const j=JSON.parse(o.json);
    let c2=null;
    if(j.c1){
      const c1=parseColor(j.c1.hex);
      c2=j.c2?parseColor(j.c2.hex):null;
      return {c1,c2};
    }
    if(j.hex1){ const c1=parseColor(j.hex1); return {c1,c2:j.hex2?parseColor(j.hex2):null}; }
    throw new Error('JSON 需含 c1/c2 或 hex1/hex2');
  }
  if(!o.hex1) return null;
  const c1=parseColor(o.hex1);
  if(!c1) throw new Error('hex1 无效：'+o.hex1);
  return {c1,c2:o.hex2?parseColor(o.hex2):null};
}

/* ---------------- 生成 ---------------- */
function generate(o){
  const {c1,c2}=resolveInputs(o);
  const monoOnly = !c2;
  const specs = monoOnly ? [SCHEMES.find(s=>s.key==='mono')] : SCHEMES;
  const results = specs.map(sp=>{
    const cols=buildScheme(sp,c1,c2);
    return {key:sp.key,name:sp.name,style:sp.style,desc:sp.desc,
            colors:cols.map((c,i)=>({role:'着色'+(i+1),hex:c.hex.toUpperCase(),rgb:c.rgb}))};
  });
  return {c1:c1.hex.toUpperCase(), c2:c2?c2.hex.toUpperCase():null, monoOnly, results};
}

/* ---------------- HTML 报告 ---------------- */
function renderHTML(data, title){
  const swatches=scheme=>scheme.colors.map(c=>{
    const fg = (0.299*c.rgb.r+0.587*c.rgb.g+0.114*c.rgb.b)/255>0.62 ? '#222':'#fff';
    return `<div class="sw" style="background:${c.hex}">
      <div class="role" style="color:${fg}">${c.role}</div>
      <div class="hex" style="color:${fg}">${c.hex}</div>
      <div class="rgb" style="color:${fg}">RGB(${c.rgb.r}, ${c.rgb.g}, ${c.rgb.b})</div>
    </div>`;
  }).join('');
  const cards=data.results.map((s,i)=>`<div class="card">
      <div class="hd"><span class="nm">${s.name}</span><span class="tag">${s.style}</span></div>
      <p class="desc">${s.desc}</p>
      <div class="grid">${swatches(s)}</div>
      <button class="cp" data-i="${i}">复制整套 HEX</button>
    </div>`).join('');
  const base = `<p class="base">基准色 ① <b>${data.c1}</b>${data.c2?` · ② <b>${data.c2}</b>`:'（单色阶）'}</p>`;
  const json = JSON.stringify(data);
  return `<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title||'PPT 配色方案'}</title>
<style>
  :root{--cream:#FFFDF8;--line:#E8Dcc4;--ink:#3B342A;--purple:#6C5CE7;--pink:#d6336c}
  *{box-sizing:border-box}
  body{margin:0;background:#FBF6EC;color:var(--ink);font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;padding:28px}
  h1{font-size:22px;margin:0 0 4px}
  .base{margin:6px 0 20px;color:#6b6253}
  .base b{font-family:"Consolas","Microsoft YaHei",monospace}
  .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:16px}
  .card{background:var(--cream);border:1px solid var(--line);border-radius:12px;padding:14px;box-shadow:0 2px 8px rgba(80,60,20,.06)}
  .hd{display:flex;align-items:center;gap:8px}
  .nm{font-weight:700;font-size:16px}
  .tag{margin-left:auto;font-size:11px;color:var(--pink);background:#fdeef5;padding:2px 8px;border-radius:999px}
  .desc{font-size:12px;color:#7a7163;margin:6px 0 10px;min-height:32px}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
  .sw{border-radius:8px;padding:10px 6px;height:62px;display:flex;flex-direction:column;justify-content:center;align-items:center}
  .sw .role{font-size:10px;opacity:.85}
  .sw .hex{font-family:"Consolas",monospace;font-size:12px;font-weight:700;margin-top:2px}
  .sw .rgb{font-size:9px;opacity:.8;margin-top:1px}
  .cp{margin-top:10px;width:100%;border:1px solid var(--line);background:#fff;border-radius:8px;padding:7px;cursor:pointer;color:var(--ink);font-size:12px}
  .cp:hover{background:#fff7e9}
</style></head><body>
  <h1>${title||'PPT 配色方案'}</h1>
  ${base}
  <div class="cards">${cards}</div>
  <script>
    const DATA = ${json};
    document.querySelectorAll('.cp').forEach(b=>b.addEventListener('click',()=>{
      const s=DATA.results[+b.dataset.i];
      const txt=s.colors.map(c=>c.role+' '+c.hex).join(' / ');
      navigator.clipboard.writeText(txt).then(()=>{const t=b.textContent;b.textContent='已复制';setTimeout(()=>b.textContent=t,1200);});
    }));
  </script>
</body></html>`;
}

/* ---------------- 入口 ---------------- */
function main(){
  const o=parseArgs(process.argv.slice(2));
  let data;
  try{ data=generate(o); }
  catch(e){ console.error('错误：'+e.message); process.exit(1); }
  // 终端摘要
  console.log('基准色 ① '+data.c1+(data.c2?' · ② '+data.c2:'（单色阶）'));
  data.results.forEach(s=>{
    console.log('▶ '+s.name+'（'+s.style+'）：'+s.colors.map(c=>c.role+' '+c.hex).join(' / '));
  });
  if(o.out){
    const html=renderHTML(data,o.title);
    require('fs').writeFileSync(o.out,html,'utf8');
    console.log('\n已生成 HTML 色卡：'+o.out);
  }
}
main();
