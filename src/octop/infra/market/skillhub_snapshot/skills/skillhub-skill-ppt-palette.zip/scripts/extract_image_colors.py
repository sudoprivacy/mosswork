#!/usr/bin/env python3
# ppt-palette-gen · 图片取色（端口自「设计色彩色轮空间」v5）
# 降采样 + 色相分桶量化 + 代表度评分（中性色降权，防白底/黑底抢主色）
# 主色判定：① = 代表度最高的彩色；② = 色相距离 ≥35° 的次主色（单一色系则留空）
# 依赖：Pillow（系统 Python3.12 自带；或托管 venv 已 pip install pillow）
# 用法：python extract_image_colors.py <图片路径>  →  stdout 输出 JSON {c1,c2,palette[]}
import sys, json
from collections import defaultdict
from PIL import Image


def rgb_to_hsl(r, g, b):
    r /= 255.0; g /= 255.0; b /= 255.0
    mx, mn = max(r, g, b), min(r, g, b)
    h = 0.0; s = 0.0; l = (mx + mn) / 2
    if mx != mn:
        d = mx - mn
        s = d / (2 - mx - mn) if l > 0.5 else d / (mx + mn)
        if mx == r:
            h = (g - b) / d + (6 if g < b else 0)
        elif mx == g:
            h = (b - r) / d + 2
        else:
            h = (r - g) / d + 4
        h *= 60
    return h, s * 100, l * 100


def rgb_to_hex(r, g, b):
    return '#%02x%02x%02x' % (r, g, b)


def extract_palette(img):
    w0, h0 = img.size
    scale = min(1.0, 110.0 / max(w0, h0))
    w = max(1, round(w0 * scale))
    h = max(1, round(h0 * scale))
    img = img.convert('RGB').resize((w, h))
    px = img.load()
    buckets = defaultdict(lambda: {'n': 0, 'r': 0, 'g': 0, 'b': 0, 'sat': 0, 'neutral': False})
    total = 0
    for y in range(h):
        for x in range(w):
            r, g, b = px[x, y]
            hh, ss, ll = rgb_to_hsl(r, g, b)
            if ll < 8 or ll > 96:
                continue
            total += 1
            neutral = ss < 14
            key = ('n' + str(round(ll / 12))) if neutral else ('h' + str(int(hh // 12)))
            bk = buckets[key]
            bk['n'] += 1; bk['r'] += r; bk['g'] += g; bk['b'] += b
            bk['sat'] += ss; bk['neutral'] = neutral
    if not total:
        return []
    out = []
    for v in buckets.values():
        r = round(v['r'] / v['n']); g = round(v['g'] / v['n']); b = round(v['b'] / v['n'])
        hx = rgb_to_hex(r, g, b)
        hh, ss, ll = rgb_to_hsl(r, g, b)
        weight = v['n'] / total
        savg = v['sat'] / v['n']
        score = weight * (0.22 if v['neutral'] else (0.38 + savg / 100 * 0.95))
        out.append({'hex': hx, 'h': hh, 's': ss, 'l': ll, 'weight': weight, 'sat': savg, 'neutral': v['neutral'], 'score': score})
    out.sort(key=lambda c: c['score'], reverse=True)
    return out[:8]


def pick_base(lst):
    pool = [c for c in lst if not c['neutral'] and c['s'] >= 18 and c['l'] >= 12 and c['l'] <= 92]
    if not pool:
        pool = lst
    c1 = pool[0] if pool else None
    c2 = None
    if c1:
        for c in pool:
            if c is c1:
                continue
            dh = abs(c['h'] - c1['h'])
            dh = 360 - dh if dh > 180 else dh
            if dh >= 35:
                c2 = c
                break
    return c1, c2


def ser(c):
    if not c:
        return None
    return {'hex': c['hex'], 'h': round(c['h'], 1), 's': round(c['s'], 1), 'l': round(c['l'], 1)}


def main():
    if len(sys.argv) < 2:
        sys.stderr.write('用法：python extract_image_colors.py <图片路径>\n')
        sys.exit(2)
    im = Image.open(sys.argv[1])
    pal = extract_palette(im)
    c1, c2 = pick_base(pal)
    print(json.dumps({
        'c1': ser(c1),
        'c2': ser(c2),
        'palette': [{'hex': c['hex'], 'score': round(c['score'], 4)} for c in pal]
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
