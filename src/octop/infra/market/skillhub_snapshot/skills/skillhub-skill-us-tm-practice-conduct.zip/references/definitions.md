 -261- January 1, 2026 
the remedies provided herein for infringement of marks shall be available so far as they may be 
appropriate in repressing acts of unfair competition.  
(i) Citizens or residents of the United States shall have the same benefits as are granted by this 
section to persons described in subsection (b) of this section.  
(Amended Oct. 3, 1961, 75 Stat. 748; Oct. 9, 1962, 76 Stat. 774; Nov. 16, 1988, 102 Stat. 3946; Oct. 30, 
1998, 112 Stat. 3068; Nov. 29, 1999, 113 Stat. 1501A -583; Nov. 2, 2002, 116 Stat. 1908.)  
TITLE X - CONSTRUCTION AND DEFINITIONS 
§ 45 (15 U.S.C. § 1127).   
In the construction of this chapter, unless the contrary is plainly apparent from the context — 
United States.  The United States includes and embraces all territory which is under its jurisdiction 
and control. 
Commerce.  The word “commerce” means all commerce which may lawfully be regulated by 
Congress. 
Principal Register, Supplemental Register .  The term “principal register” refers to the register 
provided for by sections 1051 to 1072 of this title, and the term “supplemental register” refers to the 
register provided for by sections 1091 to 1096 of this title.  
Person, juristic person.  The term “person” and any other word or term used to designate the 
applicant or other entitled to a benefit or privilege or rendered liable under the provisions of this Act 
includes a juristic person as well as a natural person.  The term “juristic person” includes a firm, 
corporation, union, association, or other organization capable of suing and being sued in a court of 
law.   
The term “person” also includes the United States, any agency or instrumentality thereof, or any 
individual, firm, or corporation acting for the United States and with the authorization and consent 
of the United States.  The United States, any agency or instrumentality thereof, and any individual, 
firm, or corporation acting for the United States and with the authorization and consent of the United 
States, shall be subject to the provisions of this chapter in the same manner and to the same extent 
as any nongovernmental entity.   
The term “person” also includes any State, any instrumentality of a State, and any officer or 
employee of a State or instrumentality of a State acting in his or her official capacity.  Any State, 
and any such instrumentality, officer, or employee, shall be subject to the provisions of this chapter 
in the same manner and to the same extent as any non-governmental entity. 
Applicant, registrant.  The terms “applicant” and “registrant” embrace the legal representatives, 
predecessors, successors and assigns of such applicant or registrant.  
Director.  The term “Director” means the Under Secretary of Commerce for Intellectual Property and 
Director of the United States Patent and Trademark Office.  
Related company .  The term “related company” means any person whose use of a mark is 
controlled by the owner of the mark with respect to the nature and quality of the goods or services 
on or in connection with which the mark is used.  
Trade name, commercial name.  The terms “trade name” and “commercial name” mean any name 
used by a person to identify his or her business or vocation.  

 -262- January 1, 2026 
Trademark.  The term “trademark” includes any word, name, symbol, or device, or any combination 
thereof — 
(1) used by a person, or  
(2) which a person has a bona fide intention to use in commerce and applies to register on the 
principal register established by this chapter,  
to identify and distinguish his or her goods, including a unique product, from those manufactured or 
sold by others and to indicate the source of the goods, even if that source is unknown.  
Service mark .  The term “service mark” means any word, name, symbol, or device, or any 
combination thereof — 
(1) used by a person, or  
(2) which a person has a bona fide intention to use in commerce and applies to register on the 
principal register established by this chapter,  
to identify and distinguish the services of one person, including a unique service, from the services 
of others and to indicate the source of the services, even if that source is unknown.  Titles, character 
names, and other distinctive features of radio or television programs may be registered as service 
marks notwithstanding that they, or the programs, may advertise the goods of the sponsor.  
Certification mark.  The term “certification mark” means any word, name, symbol, or device, or any 
combination thereof — 
(1) used by a person other than its owner, or  
(2) which its owner has a bona fide intention to permit a person other than the owner to use in 
commerce and files an application to register on the principal register established by this 
chapter, 
to certify regional or other origin, material, mode of manufacture, quality, accuracy, or other 
characteristics of such person’s goods or services or that the work or labor on the goods or services 
was performed by members of a union or other organization.  
Collective mark.  The term “collective mark” means a trademark or service mark— 
(1) used by the members of a cooperative, an association, or other collective group or 
organization, or 
(2) which such cooperative, association, or other collective group or organization has a bona 
fide intention to use in commerce and applies to register on the principal register established by 
this chapter,  
and includes marks indicating membership in a union, an association, or other organization. 
Mark.  The term “mark” includes any trademark, service mark, collective mark, or certification mark. 
Use in commerce.  The term “use in commerce” means the bona fide use of a mark in the ordinary 
course of trade, and not made merely to reserve a right in a mark.  For purposes of this chapter, a 
mark shall be deemed to be in use in commerce— 
(1) on goods when — 
(A) it is placed in any manner on the goods or their containers or the displays associated 
therewith or on the tags or labels affixed thereto, or if the nature of the goods makes such 
placement impracticable, then on documents associated with the goods or their sale, and 

 -263- January 1, 2026 
(B) the goods are sold or transported in commerce, and  
(2) on services when it is used or displayed in the sale or advertising of services and the services 
are rendered in commerce, or the services are rendered in more than one State or in the United 
States and a foreign country and the person rendering the services is engaged in commerce in 
connection with the services.  
Abandonment of mark.  A mark shall be deemed to be “abandoned” if either of the following occurs: 
(1) When its use has been discontinued with intent not to resume such use.  Intent not to resume 
may be inferred from circumstances.  Nonuse for 3 consecutive years shall be prima facie 
evidence of abandonment.  “Use” of a mark means the bona fide use of such mark made in the 
ordinary course of trade, and not made merely to reserve a right in a mark.  
(2) When any course of conduct of the owner, including acts of omission as well as commission, 
causes the mark to become the generic name for the goods or services on or in connection with 
which it is used or otherwise to lose its significance as a mark.  Purchaser motivation shall not 
be a test for determining abandonment under this paragraph.  
Colorable imitation .  The term “colorable imitation” includes any mark which so resembles a 
registered mark as to be likely to cause confusion or mistake or to deceive.  
Registered mark.  The term “registered mark” means a mark registered in the United States Patent 
and Trademark Office under this chapter or under the Act of March 3, 1881, or the Act of February 
20, 1905, or the Act of March 19, 1920.  The phrase “marks registered in the Patent and Trademark 
Office” means registered marks.  
Prior acts.  The term “Act of March 3, 1881,” “Act of February 20, 1905,” or “Act of March 19, 1920,” 
means the respective Act as amended. 
Counterfeit.  A “counterfeit” is a spurious mark which is identical with, or substantially 
indistinguishable from, a registered mark.  
Domain name.  The term “domain name” means any alphanumeric designation which is registered 
with or assigned by any domain name registrar, domain name registry, or other domain name 
registration authority as part of an electronic address on the Internet.  
Internet.  The term “Internet” has the meaning given that term in section 230(f)(1) of the 
Communications Act of 1934 (47 U.S.C. 230(f)(1)).  
Singular and plural .  Words used in the singular include the plural and vice versa.  
Intent of Chapter.  The intent of this chapter is to regulate commerce within the control of Congress 
by making actionable the deceptive and misleading use of marks in such commerce; to protect 
registered marks used in such commerce from interference by State, or territori al legislation; to 
protect persons engaged in such commerce against unfair competition; to prevent fraud and 
deception in such commerce by the use of reproductions, copies, counterfeits, or colorable 
imitations of registered marks; and to provide rights and remedies stipulated by treaties and 
conventions respecting trademarks, trade names, and unfair competition entered into between the 
United States and foreign nations.  
(Amended Oct. 9, 1962, 76 Stat. 774; Jan. 2, 1975, 88 Stat. 1949; Nov. 8, 1984, 98 Stat. 3335, Nov. 16, 1988, 
102 Stat. 3946; Oct. 27, 1992, 106 Stat. 3568; Dec. 8, 1994, 108 Stat. 4981; Jan. 16, 1996, 109 Stat. 986; 
Aug. 5, 1999, 113 Stat. 219-220; Nov. 29, 1999, 113 Stat. 1501A-550, 1501A-583; Oct. 6, 2006, 120 Stat. 
1730.) 

 -264- January 1, 2026 
TITLE XI - REPEAL OF PREVIOUS ACTS 
§ 46(a) (15 U.S.C. §  1051 note).  Time of taking effect - Repeal of prior acts  
This Act shall be in force and take effect one year from its enactment, but except as otherwise 
herein specifically provided shall not affect any suit, proceeding, or appeal then pending.  All Acts 
and parts of Acts inconsistent herewith are hereby repealed effective one year from the enactment 
hereof, including the following Acts insofar as they are inconsistent herewith: The Act of Congress 
approved March 3, 1881, entitled “An Act to authorize the registration of trademarks and protect the 
same”; the Act approved August 5, 1882, entitled “An Act relating to the registration of trademarks”; 
the Act of February 20, 1905 (U.S.C., title 15, secs. 81 to 109, inclusive), entitled “An Act to authorize 
the registration of trademarks used in commerce with foreign nations or among the several States 
or with Indian tribes, and to protect the same”, and the amendments thereto by the Acts of May 4, 
1906 (U.S.C., title 15, secs. 131 and 132; 34 Stat. 169), March 2, 1907 (34 Stat. 1251, 1252), 
February 18, 1909 (35 Stat. 627, 628), February 18, 1911 (36 Stat. 918), January 8, 1913 (37 Stat. 
649), June 7, 1924 (43 Stat. 647), March 4, 1925 (43 Stat. 1268, 1269), April 11, 1930 (46 Stat. 
155), June 10, 1938 (Public, Numbered 586, Seventy-fifth Congress, ch. 332, third session); the 
Act of March 19, 1920 (U.S.C., title 15, secs. 121 to 128, inclusive), entitled “an Act to give effect to 
certain provisions of the convention for the protection of trademarks and commercial names made 
and signed in the city of Buenos Aires, in the Argentine Republic, August 20, 1910, and for other 
purposes”, and the amendments thereto, including the Act of June 10, 1938 (Public, Numbered 
586, Seventy-fifth Congress, ch. 332, third session):  Provided, That this repeal shall not affect the 
validity of registrations granted or applied for under any of said Acts prior to the effective date of this 
Act, or rights or remedies thereunder except as provided in sections 8, 12, 14, 15, and 47 of this 
Act; but nothing contained in this Act shall be construed as limiting, restricting, modifying, or 
repealing any statute in force on the effective date of this Act which does not relate to trademarks, 
or as restricting or increasing the authority of any Federal departments or regulatory agency except 
as may be specifically provided in this Act.  
§ 46(b) (15 U.S.C. §  1051 note).  Existing registrations under prior acts  
Acts of 1881 and 1905.  Registrations now existing under the Act of March 3, 1881, or the Act of 
February 20, 1905, shall continue in full force and effect for the unexpired terms thereof and may 
be renewed under the provisions of section 9 of this Act.  Such registrations and  the renewals 
thereof shall be subject to and shall be entitled to the benefits of the provisions of this Act to the 
same extent and with the same force and effect as though registered on the principal register 
established by this Act except as limited in sections 8, 12, 14, and 15 of this Act.  Marks registered 
under the “10-year proviso” of section 5 of the Act of February 20, 1905, as amended, shall be 
deemed to have become distinctive of the registrant’s goods in commerce under paragraph (f) of 
section 2 of this Act and may be renewed under section 9 hereof as marks coming within said 
paragraph. 
Act of 1920.  Registrations now existing under the Act of March 19, 1920, shall expire 6 months 
after the effective date of this Act, or twenty years from the dates of their registrations, whichever 
date is later.  Such registrations shall be subject to and entitled to the benefits of the provisions of 
this Act relating to marks registered on the supplemental register established by this Act, and may 
not be renewed unless renewal is required to support foreign registrations.  In that event renewal 
may be effected on the supplemental register under the provisions of section 9 of this Act.  
Subject to registration under this Act.  Marks registered under previous Acts may, if eligible, also be 
registered under this Act.  

 -265- January 1, 2026 
§ 47(a) (15 U.S.C. §  1051 note).  Applications pending on effective date of Act  
All applications for registration pending in the Patent and Trademark Office at the effective date of 
this Act may be amended, if practicable, to bring them under the provisions of this Act.  The 
prosecution of such applications so amended and the grant of  registrations thereon shall be 
proceeded with in accordance with the provisions of this Act.  If such amendments are not made, 
the prosecution of said applications shall be proceeded with and registrations thereon granted in 
accordance with the Acts under  which said applications were filed, and said Acts are hereby 
continued in force to this extent for this purpose only, notwithstanding the foregoing general repeal 
thereof.  
§ 47(b) (15 U.S.C. §  1051 note).  Appeals pending on effective date of Act  
In any case in which an appeal is pending before the United States Court of Customs and Patent 
Appeals or any United States Circuit Court of Appeals or the United States Court of Appeals for the 
District of Columbia or the United States Supreme Court at the effective date of this Act, the court, 
if it be of the opinion that the provisions of this Act are applicable to the subject matter of the appeal, 
may apply such provision or may remand the case to the Director or to the district court for the 
taking of additional evidence or a new trial or for reconsideration of the decision on the record as 
made, as the appellate court may deem proper. 
(Amended Nov. 29, 1999, 113 Stat. 1501A -583) 
§ 48 (15 U.S.C. § 1051 note).  Prior acts not repealed  
Section 4 of the Act of January 5, 1905 (U.S.C., title 36, section 4), as amended, entitled “An Act to 
incorporate the National Red Cross,” and section 7 of the Act of June 15, 1916 (U.S.C., title 36, 
section 27), entitled “An Act to incorporate the Boy Scouts of America, and for other purposes,” and 
the Act of June 20, 1936 (U.S.C., title 22, section 248), entitled “An Act to prohibit the commercial 
use of the coat of arms of the Swiss Confederation,” are not repealed or affected by this Act.  
Note:  The first and third of the laws referred to in this section have been repealed and replaced by 
§§ 706 and 708, respectively, of U.S.C., Title 18, Crimes and Criminal Procedure, enacted June 25, 
1948, effective September 1, 1948.  
§ 49 (15 U.S.C. § 1051 note).  Preservation of existing rights  
Nothing herein shall adversely affect the rights or the enforcement of rights in marks acquired in 
good faith prior to the effective date of this Act.  
§ 50 (15 U.S.C. § 1051 note).  Severability  
If any provision of this Act or the application of such provision to any person or circumstance is held 
invalid, the remainder of the Act shall not be affected thereby.  
§ 51 (15 U.S.C. § 1058 note).  Applications pending on effective date of the Trademark Law 
Revision Act of 1988  
All certificates of registration based upon applications for registration pending in the Patent and 
Trademark Office on the effective date of the Trademark Law Revision Act of 1988 shall remain in 
force for a period of 10 years.  