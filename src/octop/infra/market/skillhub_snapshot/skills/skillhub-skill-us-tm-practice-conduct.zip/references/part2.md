 -16- July 15, 2026 
37 C.F.R. PART 2-RULES OF PRACTICE IN TRADEMARK CASES 
AUTHORITY:  15 U.S.C. 1113, 1123; 35 U.S.C. 2; sec. 10, Pub. L. 112 -29, 125 Stat. 284; Pub. L. 
116-260, 134 Stat. 1182, unless otherwise noted. Sec. 2.99 also issued under secs. 16, 17, 60 Stat. 
434; 15 U.S.C. 1066, 1067.  
RULES APPLICABLE TO TRADEMARK CASES 
§ 2.1  [Reserved]  
§ 2.2  Definitions.  
(a) The Act as used in this part means the Trademark Act of 1946, 60 Stat. 427, as amended, 
codified in 15 U.S.C. 1051 et. seq. 
(b) Entity as used in this part includes both natural and juristic persons.  
(c) Director as used in this chapter, except for part 11, means the Under Secretary of Commerce 
for Intellectual Property and Director of the United States Patent and Trademark Office.  
(d) Federal holiday within the District of Columbia  means any day, except Saturdays and 
Sundays, when the United States Patent and Trademark Office is officially closed for business for 
the entire day. 
(e) The term Office or abbreviation USPTO means the United States Patent and Trademark 
Office.    
(f) The acronym TEAS means the Trademark Electronic Application System and, as used in this 
part, includes all related electronic systems required to complete an electronic submission through 
TEAS. 
(g) The acronym ESTTA means the Electronic System for Trademark Trials and Appeals and, 
as used in this part, includes all related electronic systems required to complete an electronic 
submission through ESTTA. 
(h) The term international application as used in this part means, in addition to the definition in 
section 60 of the Act, an application seeking an extension of protection of an international 
registration in an initial designation filed under the Protocol Relating to the Madrid Agreement 
Concerning the International Registration of Marks.  
(i) The term subsequent designation as used in this part means a request for extension of 
protection of an international registration made after the International Bureau registers the mark on 
the International Register. 
(j) The term holder as used in this part means, in addition to the definition of a “holder of an 
international registration” in section 60 of the Act, the natural or juristic person in whose name an 
international registration seeking an extension of protection to the United States is recorded on the 
International Register.   
(k) The term use in commerce or use of the mark in commerce as used in this part means, in 
addition to the definition of “use in commerce” in section 45 of the Act:  
(1) For a trademark or service mark, use of the mark in commerce by an applicant, owner, or 
holder on or in connection with the goods or services specified in a U.S. application, amendment to 
allege use, statement of use, or affidavit or declaration of use  or excusable nonuse;  
(2) For a collective trademark or collective service mark, use of the mark in commerce by 
members on or in connection with the goods or services specified in a U.S. application, amendment 
to allege use, statement of use, or affidavit or declaration of use or excusable nonuse;  
(3) For a collective membership mark, use of the mark in commerce by members to indicate 
membership in the collective organization as specified in a U.S. application, amendment to allege 
use, statement of use, or affidavit or declaration of use or excusabl e nonuse; and 

 -17- July 15, 2026 
(4) For a certification mark, use of the mark in commerce by authorized users on or in connection 
with the goods or services specified in a U.S. application, amendment to allege use, statement of 
use, or affidavit or declaration of use or excusable nonuse.  
(l) The term bona fide intention to use the mark in commerce as used in this part means, for a 
trademark or service mark, that an applicant or holder has a bona fide intention to use the mark in 
commerce on or in connection with the goods or services specified in a U.S. application or 
international application/subsequent designation.  
(m) The term bona fide intention, and is entitled, to exercise legitimate control over the use of 
the mark in commerce  as used in this part means:  
(1) For a collective trademark or collective service mark, that an applicant or holder has a bona 
fide intention, and is entitled, to exercise legitimate control over the use of the mark in commerce 
by members on or in connection with the goods or services  specified in a U.S. application or 
international application/subsequent designation;  
(2) For a collective membership mark, that an applicant or holder has a bona fide intention, and 
is entitled, to exercise legitimate control over the use of the mark in commerce by members to 
indicate membership in the collective organization as specified in a U.S. application or international 
application/subsequent designation; and 
(3) For a certification mark, that an applicant or holder has a bona fide intention, and is entitled, 
to exercise legitimate control over the use of the mark in commerce by authorized users on or in 
connection with the goods or services specified in a U.S.  application or international 
application/subsequent designation. 
(n) The term verified statement, and the terms verify, verified, or verification as used in this part 
refers to a statement that is sworn to, made under oath or in an affidavit, or supported by a 
declaration under § 2.20 or 28 U.S.C. 1746, and signed in accordance with the requirements of 
§ 2.193. 
(o) The term domicile as used in this part means the permanent legal place of residence of a 
natural person or the principal place of business of a juristic entity.  
(p) The term principal place of business as used in this part means the location of a juristic 
entity's headquarters where the entity's senior executives or officers ordinarily direct and control the 
entity's activities and is usually the center from where other locations are controlled.  
(q) The acronym ETAS means the Electronic Trademark Assignment System and, as used in 
this part, includes all related electronic systems required to complete an electronic submission 
through ETAS. 
(r) Eastern Time means Eastern Standard Time or Eastern Daylight Time, as appropriate. 
(s) The term electronic submission as used in this part refers to any submission made through 
an electronic filing system available on the Office's website, but not through email or facsimile 
transmission. 
(t) The abbreviation USPS as used in this part means the U.S. Postal Service. 
[54 FR 37588, Sept. 11, 1989; 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 68 FR 55748, Sept. 26, 
2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 78 FR 20180, April 3, 
2013, effective May 3, 2013; 80 FR 33170, June 11, 2015, effective July 11, 2015; 84 FR 31498, July 2, 2019, 
effective Aug. 3, 2019 ; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ]  
§ 2.6  Trademark fees.  
(a)  Trademark process fees.  
(1)  Application filing fees . 
(i)  For filing an application on paper, per class —$850.00  
(ii)  For filing an application under section 66(a) of the Act, per class : 
(A)  For an international application having a receipt date that is on or after 
February 18, 2025 —$600 
(B)  For an international application having a receipt date that is before 
February 18, 2025 —$500 

 -18- July 15, 2026 
(iii)  For filing an application electronically, per class—$350.00 
(iv)  Additional fee under § 2.22(b), per class —$100.00 
(v)  Additional fee under § 2.22(c), per class —$200.00 
(vi)  Additional fee under § 2.22(d) for each additional 1,000 characters in identifications of 
goods/services beyond the first 1,000 characters, per class —$200.00 
(2)  Amendment to allege use . 
(i)  For filing an amendment to allege use under section 1(c) of the Act on paper, per class—
$250.00 
(ii)  For filing an amendment to allege use under section 1(c) of the Act electronically, per 
class—$150.00 
(3)  Statement of use . 
(i)  For filing a statement of use under section 1(d)(1) of the Act on paper, per class—$250.00 
(ii)  For filing a statement of use under section 1(d)(1) of the Act electronically, per class —
$150.00 
(4)  Extension of time for filing statement of use.  
(i)  For filing a request under section 1(d)(2) of the Act for a six-month extension of time for 
filing a statement of use under section 1(d)(1) of the Act on paper, per class —$225.00 
(ii)  For filing a request under section 1(d)(2) of the Act for a six-month extension of time for 
filing a statement of use under section 1(d)(1) of the Act electronically, per class —$125.00 
(5)  Application for renewal of a registration fees . 
(i) For filing an application for renewal of a registration on paper, per class —$525.00 
(ii) For filing an application for renewal of a registration electronically, per class —$325.00 
(iii) For filing an application for renewal of a registration electronically, pursuant to § 7.41 of 
this chapter: 
(A) On or after February 18, 2025, per class —$325.00 
(B) Before February 18, 2025, per class —$300.00 
(6)  Renewal during grace period.  
(i)  Additional fee for filing a renewal application during the grace period on paper, per class—
$200.00 
(ii)  Additional fee for filing a renewal application during the grace period electronically, per 
class—$100.00 
(7)  Publishing mark under section 12(c) . 
(i)  For filing to publish a mark under section 12(c) on paper, per class —$200.00 
(ii)  For filing to publish a mark under section 12(c), per class electronically —$100.00 
(8)  New certificate of registration . 
(i)  For issuing a new certificate of registration upon request of registrant, request filed on 
paper—$200.00 
(ii)  For issuing a new certificate of registration upon request of registrant, request filed 
electronically—$100.00 
(9)  Certificate of correction of registrant’s error . 
(i)  For a certificate of correction of registrant’s error, request filed on paper —$200.00 
(ii)  For a certificate of correction of registrant’s error, request filed electronically —$100.00 
(10)  Disclaimer to a registration . 
(i)  For filing a disclaimer to a registration, on paper —$200.00 
(ii)  For filing a disclaimer to a registration electronically —$100.00 
(11)  Amendment of registration . 
(i)  For filing an amendment to a registration, on paper —$200.00 
(ii)  For filing an amendment to a registration electronically —$100.00 
(iii) For filing an amendment to a registration prior to submission of an affidavit under section 8 
or section 71 of the Act and consisting only of the deletion of goods, services, and/or classes—
$0.00 
(12)  Affidavit under section 8 . 
(i)  For filing an affidavit under section 8 of the Act on paper, per class —$425.00 

 -19- July 15, 2026 
(ii)  For filing an affidavit under section 8 of the Act electronically, per class —$325.00 
(iii) For deleting goods, services, and/or classes after submission and prior to acceptance of 
an affidavit under section 8 of the Act on paper, per class —$350.00 
(iv) For deleting goods, services, and/or classes after submission and prior to acceptance of 
an affidavit under section 8 of the Act electronically, per class —$250.00 
(13)  Affidavit under section 15 . 
(i)  For filing an affidavit under section 15 of the Act on paper, per class —$350.00 
(ii)  For filing an affidavit under section 15 of the Act electronically, per class —$250.00 
(14)  Filing section 8 affidavit during grace period . 
(i)  Additional fee for filing a section 8 affidavit during the grace period on paper, per class—
$200.00 
(ii)  Additional fee for filing a section 8 affidavit during the grace period electronically, per 
class—$100.00 
(15)  Petitions to the Director . 
(i)  For filing a petition under § 2.146 or § 2.147 on paper —$500.00 
(ii)  For filing a petition under § 2.146 or § 2.147 electronically —$400.00 
(iii) For filing a petition under § 2.66 on paper —$350.00 
(iv) For filing a petition under § 2.66 electronically —$250.00 
(16)  Petition to cancel to the Trademark Trial and Appeal Board . 
(i)  For filing a petition to cancel on paper, per class —$700.00 
(ii)  For filing a petition to cancel electronically, per class —$600.00 
(17)  Notice of opposition  to the Trademark Trial and Appeal Board . 
(i)  For filing a notice of opposition on paper, per class —$700.00 
(ii)  For filing a notice of opposition electronically, per class —$600.00 
(18)  Ex parte appeal  to the Trademark Trial and Appeal Board . 
(i)  For filing an ex parte appeal on paper, per class —$325.00 
(ii)  For filing an ex parte  appeal electronically, per class—$225.00 
(iii) For filing a first request for an extension of time to file an appeal brief, per application —
$0.00 
(iv) For filing a second or subsequent request for an extension of time to file an appeal brief on 
paper, per application—$200.00 
(v) For filing a second or subsequent request for an extension of time to file an appeal brief 
electronically, per application—$100.00 
(vi) For filing an appeal brief on paper, per class —$300.00 
(vii) For filing an appeal brief electronically, per class—$200.00 
(19)  Dividing an application . 
(i)  Request to divide an application filed on paper, per new application created —$200.00 
(ii)  Request to divide an application filed electronically, per new application created—$100.00 
(20)  Correcting deficiency in section 8 affidavit . 
(i)  For correcting a deficiency in a section 8 affidavit via paper filing —$200.00 
(ii)  For correcting a deficiency in a section 8 affidavit via electronic filing —$100.00 
(21)  Correcting deficiency in renewal application . 
(i)  For correcting a deficiency in a renewal application via paper filing —$200.00 
(ii)  For correcting a deficiency in a renewal application via electronic filing —$100.00 
(22)  Extension of time for filing notice of opposition under § 2.102(c)(1)(ii) or (c)(2) . 
(i)  For filing a request for an extension of time to file a notice of opposition under § 
2.102(c)(1)(ii) or (c)(2) on paper —$400.00 
(ii)  For filing a request for an extension of time to file a notice of opposition under § 
2.102(c)(1)(ii) or (c)(2) electronically —$200.00 
(23)  Extension of time for filing notice of opposition under § 2.102(c)(3) . 
(i)  For filing a request for an extension of time to file a notice of opposition under § 2.102(c)(3) 
on paper—$500.00 

 -20- July 15, 2026 
(ii)  For filing a request for an extension of time to file a notice of opposition under § 
2.102(c)(3) electronically —$400.00 
(24) Oral hearing . For filing a request for an oral hearing before the 
Trademark Trial and Appeal Board, per proceeding—$500.00 
(25) Letter of protest . For filing a letter of protest, per subject application —$150.00 
(26) Petition for expungement or reexamination . For filing a petition for expungement or 
reexamination under § 2.91 , per class—$400.00 
(27) Extension of time for filing a response to a non-final Office action under § 2.93(b)(1) . For 
filing a request for extension of time for filing a response to a non -final Office action under § 
2.93(b)(1) electronically —$125.00 
(28) Extension of time for filing a response to an Office action under § 2.62(a)(2) .  
(i) For filing a request for an extension of time for filing a response to an Office action under § 
2.62(a)(2) on paper —$225.00 
(ii) For filing a request for an extension of time for filing a response to an Office action under § 
2.62(a)(2) electronically—$125.00 
(b)  Trademark service fees.  
(1)  For printed copy of registered mark, copy only. Service includes preparation of copies by 
the Office within two to three business days and delivery by United States Postal Service; and 
preparation of copies by the Office within one business day of receipt and delivery to an Office 
Box or by electronic means (e.g., facsimile, electronic mail) —$3.00 
(2) Certified or uncertified copy of trademark application as filed processed within seven 
calendar days—$15.00 
(3)  Certified or uncertified copy of a trademark -related official record —$50.00 
(4)  Certified copy of a registered mark, showing title and/or status:  
(i)  Regular service—$15.00 
(ii)  Expedited local service—$30.00 
(5)  Certified or uncertified copy of trademark records, per document except as otherwise 
provided in this section —$25.00 
(6)  For recording each trademark assignment, agreement or other document relating to the 
property in a registration or application  
(i)  First property in a document —$40.00 
(ii)  For each additional property in the same document —$25.00 
(7)  For assignment records, abstract of title and certification, per registration —$25.00 
(8)  Additional Fee for Overnight Delivery —$40.00  
(9)  Additional Fee for Expedited Service —$160.00  
(10) For processing each payment refused (including a check returned “unpaid”) or charged 
back by a financial institution—$50.00 
(11)  Deposit account service charge for each month when the balance at the end of the 
month is below $1,000 —$25.00  
[56 FR 65155, Dec. 13, 1991; 56 FR 66670, Dec. 24, 1991, as amended at 57 FR 38196, Aug. 21, 1992; 59 
FR 256, Jan. 4, 1994;60 FR 41018, Aug. 11, 1995; 62 FR 40450, July 29, 1997; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 64 FR 67486, Dec. 2, 1999; 64 FR 67774, Dec. 10, 1999; 67 FR 79520, Dec. 30, 
2002; 67 FR 70847, November 27, 2002, effective January 1, 2003; 68 FR 14332, March 25, 2003, effective 
May 1, 2003; 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 70 FR 2952, Jan. 19, 2005, effective Jan. 
31, 2005; 70 FR 38768, July 6, 2005, effective July 18, 2005; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 
2009; 79 FR 74633, Dec. 16, 2014, effective Jan. 17, 2015; 81 FR 72694, Oct. 21, 2016, effective Jan. 14, 
2017; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020; 85 FR 73197, Nov. 17, 2020, effective Jan. 2, 
2021; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021; 87 FR 62032, Oct. 13, 2022, effective Dec. 3, 
2022; 89 FR 91062, Nov. 18, 2024, effective Jan. 18, 2025 ] 
§ 2.7  Fastener Recordal Fees.  
(a)  Application fee for recordal of insignia —$20.00 

 -21- July 15, 2026 
(b)  Renewal of insignia recordal —$20.00 
(c)  Surcharge for late renewal of insignia recordal —$20.00 
[61 FR 55223, Oct. 25, 1996] 
REPRESENTATION BY ATTORNEYS OR OTHER AUTHORIZED PERSONS 
§ 2.11  Requirement for representation . 
(a) An applicant, registrant, or party to a proceeding whose domicile is not located within the 
United States or its territories must be represented by an attorney, as defined in § 11.1 of this 
chapter, who is qualified to practice under § 11.14 of this ch apter. The Office cannot aid in the 
selection of an attorney.  
(b) The Office may require an applicant, registrant, or party to a proceeding to furnish such 
information or declarations as may be reasonably necessary to the proper determination of whether 
the applicant, registrant, or party is subject to the requiremen t in paragraph (a) of this section.  
(c) An applicant, registrant, or party to a proceeding may be required to state whether assistance 
within the scope of § 11.5(b)(2) of this chapter was received in a trademark matter before the Office 
and, if so, to disclose the name(s) of the person(s) pr oviding such assistance and whether any 
compensation was given or charged. 
(d) Failure to respond to requirements issued pursuant to paragraphs (a) through (c) of this 
section is governed by § § 2.65, 2.93, and 2.163 and 7.39 of this chapter , as appropriate. 
(e) Providing false, fictitious, or fraudulent information in connection with the requirements of 
paragraphs (a) through (c) of this section shall be deemed submitting a paper for an improper 
purpose, in violation of § 11.18(b) of this chapter, and subject to the sanctions and actions provided 
in § 11.18(c).  
(f) Notwithstanding § 2.63(b)(2)(ii) and 2.93(c)(1), if an Office action maintains only requirements 
under paragraphs (a), (b), and/or (c) of this section, or only requirements under paragraphs (a), (b), 
and/or (c) of this section and the requirement for a processing fee under § 2.22(c), the requirements 
may be reviewed only by filing a petition to the Director under § 2.146 . 
[50 FR 5171, Feb. 6, 1985; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, 
effective Sept. 15, 2008; 84 FR 31498, July 2, 2019, effective Aug. 3, 2019; 86 FR 64300, Nov. 17, 2021, 
effective Dec. 18, 2021 ] 
§ 2.17  Recognition for representation.  
(a) Authority to practice in trademark cases .  Only an individual qualified to practice under 
§ 11.14 of this chapter may represent an applicant, registrant, or party to a proceeding before the 
Office in a trademark case.   
(b)(1) Recognition of practitioner as representative.  To be recognized as a representative in a 
trademark case, a practitioner qualified under § 11.14 of this chapter may:  
(i) File a power of attorney that meets the requirements of paragraph (c) of this section;   
(ii) Sign a document on behalf of an applicant, registrant, or party to a proceeding who is not 
already represented by a practitioner qualified under § 11.14 of this chapter from a different firm; or 
(iii) Appear by being identified as the representative in a document submitted to the Office on 
behalf of an applicant, registrant, or party to a proceeding who is not already represented by a 
practitioner qualified under §  11.14 of this chapter from a different  firm.  
(2) Authorization to represent. When a practitioner qualified under § 11.14 of this chapter signs 
a document or appears pursuant to paragraph (b) of this section, his or her signature or 
appearance shall constitute a representation to the Office that he or she is authorized to represent 
the person or entity on whose behalf he or she acts. The Office may require further proof of 
authority to act in a representative capacity.  

 -22- July 15, 2026 
(3) Bar information required. A practitioner qualified under § 11.14(a) of this chapter will be 
required to provide the name of a State, as defined in § 11.1 of this chapter, in which he or she is 
an active member in good standing, the date of admission to the bar of the named State, and the 
bar license number, if one is issued by the named State. The practitioner may be required to provide 
evidence that he or she is an active member in good standing of the bar of the specified State.   
(4) False, fraudulent, or mistaken designation. Regardless of paragraph (b)(1) of this section, 
where a practitioner has been falsely, fraudulently, or mistakenly designated as a representative for 
an applicant, registrant, or party to a proceeding without the practitioner’s prior authorization or 
knowledge, such a designation shall have no effect and the practitioner is not recognized . 
(c) Requirements for power of attorney .  A power of attorney must:  
(1) Designate by name at least one practitioner meeting the requirements of §  11.14 of this 
chapter; and 
(2) Be signed by the individual applicant, registrant, or party to a proceeding pending before the 
Office, or by someone with legal authority to bind the applicant, registrant, or party (e.g., a corporate 
officer or general partner of a partnership).  In the case of joint applicants or joint registrants, all 
must sign.  Once the applicant, registrant, or party has designated a practitioner(s) qualified to 
practice under § 11.14 of this chapter, that practitioner may sign an associate power of attorney 
appointing another qualified practitioner(s) as an additional person(s) authorized to represent the 
applicant, registrant, or party.  If the applicant, registrant, or party revokes the original power of 
attorney (§ 2.19(a)), the revocation discharges any associate power signed by the practitioner 
whose power has been revoked.  If the practitioner who signed an associate power withdraws 
(§ 2.19(b)), the withdrawal discharges any associate power signed by the withdrawing practitioner 
upon acceptance of the request  for withdrawal by the Office.  
(d) Power of attorney relating to multiple applications or registrations .  The owner of an 
application or registration may appoint a practitioner(s) qualified to practice under §  11.14 of this 
chapter to represent the owner for all existing applications or registrations that have the identical 
owner name.    
(e) Foreign attorneys and agents . Recognition to practice before the Office in trademark 
matters is governed by § 11.14(c) of this chapter.  
(f) Non-lawyers. A non -lawyer may not act as a representative except in the limited 
circumstances set forth in §  11.14(b) of this chapter. Before any non -lawyer who meets the 
requirements of §  11.14(b) of this chapter may take action of any kind with respect to an 
application, registration or proceeding, a written authorization must be fi led, signed by the 
applicant, registrant, or party to the proceeding, or by someone with legal authority to bind the 
applicant, registrant, or party (e.g., a corporate officer or general partner of a partnership).  
(g) Duration of recognition.  
(1) The Office considers recognition as to a pending application to end when the mark 
registers, when ownership changes, or when the application is abandoned.  
(2) The Office considers recognition obtained after registration to end when the mark is 
cancelled or expired, or when ownership changes. If a practitioner was recognized as the 
representative in connection with an affidavit under section 8, 12(c), 15, or 71 of the Act, renewal 
application under section 9 of the Act, or request for amendment or correction under section 7 of 
the Act, recognition is deemed to end upon acceptance or final rejection of the filing .  
[30 FR 13193, Oct. 16, 1965, as amended at 50 FR 5171, Feb. 6, 1985; 64 FR 48900, Sept. 8, 1999, effective 
Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective 
Sept. 15, 2008; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 80 FR 2303, Jan. 16, 2015, effective 
Feb. 17, 2015; 84 FR 31498, July 2, 2019, effective Aug. 3, 2019; 84 FR 37081, July 31, 2019, effective Feb. 
15, 2020; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.18 Correspondence, with whom held.  
(a) Establishing the corresponden t.  The Office will send correspondence as follows:  

 -23- July 15, 2026 
(1) If an attorney is not recognized as a representative pursuant to § 2.17(b)(1), the Office will 
send correspondence to the applicant, registrant, or party to the proceeding.   
(2) If an attorney is recognized as a representative pursuant to § 2.17(b)(1), the Office will 
correspond only with that attorney, except as set forth in paragraphs (a)(2)(i) through (iv) of this 
section. A request to change the correspondence address does not revoke a power of attorney. 
The Office will not correspond with another attorney from a different firm and, except for service of 
a cancellation petition and notices of institution of expungement or reexamination proceedings, will 
not correspond direc tly with the applicant, registrant, or a party to a proceeding, unless:  
(i) The applicant or registrant files a revocation of the power of attorney under §  2.19(a) and/or 
a new power of attorney that meets the requirements of §   2.17(c); 
(ii) The attorney has been suspended or excluded from practicing in trademark matters before 
the USPTO; 
(iii) Recognition of the attorney has ended pursuant to §   2.17(g); or 
(iv) The attorney has been falsely, fraudulently, or mistakenly designated under  
§ 2.17(b)(4) . 
(b) Ex parte matters.  Only one correspondence address may be designated in an ex parte 
matter.   
(c) Maintaining and changing the correspondence addresses. The applicant, registrant, or party 
to a proceeding must maintain current and accurate correspondence addresses, as required by §  
2.23, for itself and its attorney, if one is designated. If any of these addresses change, a request to 
change the address, signed in accordance with §   2.193(e)(9), must be promptly filed.  
(d) Post registration filings under sections 7, 8, 9, 12(c), 15, and 71 of the Act. Even if there is 
no new power of attorney or written request to change the correspondence address, the Office will 
change the correspondence address upon the examination of an affidavit under section 8, 12(c), 
15, or 71 of the Act, renewal application under section 9 of the Act, or request for amendment or 
correction under section 7 of the Act, if a new address is provided, in accordance with paragraph 
(a) of this section.  
[41 FR 758, Jan. 5 1976, as amended at 54 FR 37588, Sept. 11, 1989; 67 FR 79520, Dec. 30, 2002; 68 FR 
55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 74 FR 
54898, Oct. 26, 2009, effective Dec. 28, 2009; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020; 86 FR 
64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.19  Revocation or withdrawal of attorney.  
(a) Revocation.  (1) Authority to represent an applicant, registrant or party to a proceeding before 
the Office may be revoked at any stage in the proceedings of a trademark case, upon written 
notification signed by the applicant, registrant, or party to the proceeding, or by someone with legal 
authority to bind the applicant, registrant, or party (e.g., a corporate officer or general partner of a 
partnership).  In the case of joint applicants or joint registrants, all must sign.   
(2) When a power of attorney is revoked, the Office will communicate directly with the applicant, 
registrant, or party to the proceeding, or with the new attorney or domestic representative if 
appropriate.   
(3) A request to change the correspondence address does not revoke a power of attorney.  
(4) A new power of attorney that meets the requirements of §  2.17(c) will be treated as a 
revocation of the previous power.   
(b) Withdrawal of attorney.  If the requirements of § 11.116 of this chapter are met, a practitioner 
authorized to represent an applicant, registrant, or party to a proceeding in a trademark case may 
withdraw upon application to and approval by the Director or, when applicable, upon motion granted 
by the Trademark Trial and Appeal Board.  The practitioner should file the request to withdraw soon 
after the practitioner notifies the client of his/her intent to withdraw.  The request must include the 
following: 
(1) The application serial number, registration number, or proceeding number;  
(2) A statement of the reason(s) for the request to withdraw; and  

 -24- July 15, 2026 
(3) Either  
(i) A statement that the practitioner has given notice to the client that the practitioner is 
withdrawing from employment and will be filing the necessary documents with the Office; that the 
client was given notice of the withdrawal at least two months before the expiration of the response 
period, if applicable; that the practitioner has delivered to the client all documents and property in 
the practitioner’s file concerning the application, registration or proceeding to which the client is 
entitled; and that the practitioner has notified the client of any responses that may be due, and of 
the deadline for response; or  
(ii) If more than one qualified practitioner is of record, a statement that representation by 
co-counsel is ongoing.  
(c) Recognition ineffective. If recognition is not effective under  § 2.17(b)(4), then revocation 
under paragraph (a) of this section or withdrawal under paragraph (b) of this section is not required. 
[50 FR 5171, Feb. 6, 1985; 68 FR 14332, March 25, 2003, effective May 1, 2003; 68 FR 55748, Sept. 26, 
2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 74 FR 54898, Oct. 26, 
2009, effective Dec. 28, 2009; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015; 86 FR 64300, Nov. 17, 
2021, effective Dec. 18, 2021 ] 
DECLARATIONS 
§ 2.20  Declarations in lieu of oaths.  
Instead of an oath, affidavit, or sworn statement, the language of 28 U.S.C. 1746, or the 
following declaration language, may be used: 
The signatory being warned that willful false statements and the like are punishable by fine or 
imprisonment, or both, under 18 U.S.C. 1001, and that such willful false statements and the like 
may jeopardize the validity of the application or submission or  any registration resulting 
therefrom, declares that all statements made of his/her own knowledge are true and all 
statements made on information and belief are believed to be true.  
[31 FR 5261, Apr. 1, 1966; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 80 FR 33170, June 11, 2015, 
effective July 11, 2015 ] 
APPLICATION FOR REGISTRATION 
§ 2.21  Requirements for receiving a filing date.  
(a) The Office will grant a filing date to an application under section 1 or section 44 of the Act 
that is filed through TEAS, is written in the English language, and contains all of the following:  
(1) The name, address, and email address of each applicant; 
(2) If the applicant is represented by a practitioner qualified under § 11.14 of this chapter, the 
practitioner's name, postal address, and email address; 
(3) A clear drawing of the mark;  
(4) A listing of the goods or services; and  
(5) The filing fee required under §  2.6 for at least one class of goods or services.    
(b) If the applicant does not satisfy all the elements required in paragraph (a) of this section, the 
Office will deny a filing date to the application unless the applicant meets the requirements of 
paragraph (c) of this section.  
(c) If the applicant is a national of a country that has acceded to the Trademark Law Treaty, but 
not to the Singapore Treaty on the Law of Trademarks, the requirements of paragraph (a) of this 
section to file through TEAS and provide an email address do not a pply. 
[47 FR 38695, Sept. 2, 1982, as amended at 51 FR 29921, Aug. 21 1986; 54 FR 37588, Sept. 11, 1989; 64 
FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 

 -25- July 15, 2026 
67759, Nov. 17, 2008, effective Jan. 16, 2009; 84 FR 37081, July 31, 2019, as amended at 84 FR 68045, 
Dec. 13, 2019, effective Feb. 15, 2020 ] 
§ 2.22  Requirements for a base application.  
(a) An application for registration under section 1 and/or section 44 of the Act that meets the 
requirements for a filing date under § 2.21 will be subject only to the filing fee under § 2.6(a)(1)(iii) if 
it includes: 
(1) The applicant’s name and domicile address; 
(2) The applicant’s legal entity; 
(3) The citizenship of each individual applicant, or the state or country of incorporation or 
organization of each juristic applicant; 
(4) If the applicant is a domestic partnership, the names and citizenship of the general partners, 
or if the applicant is a domestic joint venture, the names and citizenship of the active members of 
the joint venture;  
(5) If the applicant is a sole proprietorship, the state of organization of the sole proprietorship 
and the name and citizenship of the sole proprietor;  
(6) One or more bases for filing that satisfy all the requirements of §§ 2.34, 2.44, or 2.45, as 
applicable. If more than one basis is set forth, the applicant must comply with the requirements of 
§§ 2.34, 2.44, or 2.45 for each asserted basis, as applicable ; 
(7) If the application contains goods and/or services in more than one class, compliance with § 
2.86; 
(8) A filing fee for each class of goods and/or services, as required by § 2.6(a)(1)(iii) ; 
(9) A verified statement that meets the requirements of § 2.33, § 2.44, or § 2.45, as applicable, 
dated and signed by a person properly authorized to sign on behalf of the owner pursuant to § 
2.193(e)(1) ; 
(10) If the applicant does not claim standard characters, the applicant must attach a digitized 
image of the mark. If the mark includes color, the drawing must show the mark in color;  
(11) If the mark is in standard characters, a mark comprised only of characters in the Office's 
standard character set, typed in the appropriate field of the application;  
(12) If the mark includes color, a statement naming the color(s) and describing where the 
color(s) appears on the mark, and a claim that the color(s) is a feature of the mark;  
(13) If the mark is not in standard characters, a description of the mark;  
(14) If the mark includes non -English wording, an English translation of that wording;  
(15) If the mark includes non -Latin characters, a transliteration of those characters; 
(16) If the mark includes an individual’s name or likeness, either:   
(i) A statement that identifies the living individual whose name or likeness the mark comprises 
and written consent of the individual; or  
(ii) A statement that the name or likeness does not identify a living individual (see section 2(c) 
of the Act);  
(17) If the applicant owns one or more registrations for the same mark, and the owner(s) last 
listed in Office records of the prior registration(s) for the same mark differs from the owner(s) listed 
in the application, a claim of ownership of the registration(s) identified by the registration number(s), 
pursuant to § 2.36;  
(18) If the application is a concurrent use application, compliance with § 2.42;  
(19) An applicant whose domicile is not located within the United States or its territories must 
designate an attorney as the applicant’s representative, pursuant to § 2.11(a), and include the 
attorney’s name, postal address, email address, and bar information; and 
(20) Correctly classified goods and/or services, with an identification of goods and/or services 
from the Office's Acceptable Identification of Goods and Services Manual within the electronic form. 
(b) If an application fails to satisfy any of the requirements of paragraphs (a)(1) through (19) of 
this section, the applicant must pay the fee required by § 2.6(a)(1)(iv) . 

 -26- July 15, 2026 
(c) If an application fails to satisfy the requirements of paragraph (a)(20) of this section, the 
applicant must pay the fee required by § 2.6(a)(1)(v) .   
(d) If an application fails to satisfy the requirements of paragraph (a)(20) of this section, and the 
identification of goods and/or services in any class exceeds 1,000 characters, the applicant must 
pay the fee required by § 2.6(a)(1)(vi) for each affected class .  
[Added 70 FR 38768, July 6, 2005, effective July 18, 2005; amended 74 FR 54898, Oct. 26, 2009, effective 
Dec. 28, 2009; 79 FR 74633, Dec. 16, 2014, effective Jan. 17, 2015; 80 FR 2303, Jan. 16, 2015, effective 
Feb. 17, 2015; 80 FR 33170, June 11, 2015, effective July 11, 2015; 84 FR 31498, July 2, 2019, effective 
Aug. 3, 2019; 84 FR 37081, July 31, 2019, as amended at 84 FR 68045, Dec. 13, 2019, effective Feb. 15, 
2020; 89 FR 91062, Nov. 18, 2024, as amended at 90 FR 3037, Jan. 14. 2025, effective Jan. 18, 2025] 
§ 2.23  Requirement to correspond electronically with the Office and duty to monitor 
status.  
(a) Unless stated otherwise in this chapter, all trademark correspondence must be submitted 
through TEAS. 
(b) Applicants, registrants, and parties to a proceeding must provide and maintain a valid email 
address for correspondence.  
(c) Except for submissions under §§ 2.91, 2.93, and 2.149, if the applicant or registrant is a 
national of a country that has acceded to the Trademark Law Treaty, but not to the Singapore Treaty 
on the Law of Trademarks, the requirements of paragraphs (a) and (b) of this section do not apply.  
(d) Notices issued or actions taken by the USPTO are displayed in the USPTO's publicly 
available electronic systems. Applicants and registrants are responsible for monitoring the status of 
their applications and registrations in the USPTO's electronic systems during the following time 
periods: 
(1) At least every six months between the filing date of the application and issuance of a 
registration;  
(2) After filing an affidavit of use or excusable nonuse under section 8 or section 71 of the Act, 
or a renewal application under section 9 of the Act, at least every six months until the registrant 
receives notice that the affidavit or renewal application has  been accepted; and 
(3) After notice of the institution of an expungement or reexamination proceeding under § 2.92, 
at least every three months until the registrant receives a notice of termination under § 2.94 . 
[Added 70 FR 38768, July 6, 2005, effective July 18, 2005; amended 73 FR 67759, Nov. 17, 2008, effective 
Jan. 16, 2009; 79 FR 74633, Dec. 16, 2014, effective Jan. 17, 2015; 84 FR 37081, July 31, 2019, effective 
Feb. 15, 2020; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.24  Designation and revocation of domestic representative by foreign applicant.  
(a) An applicant or registrant that is not domiciled in the United States may designate a domestic 
representative (i.e., a person residing in the United States on whom notices or process in 
proceedings affecting the mark may be served).  
(b) The designation, or a request to change or revoke a designation, must set forth the name, 
email address, and postal address of the domestic representative and be signed pursuant to §  
2.193(e)(8).  
(c) The mere designation of a domestic representative does not authorize the person designated 
to represent the applicant or registrant.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37588 Sept. 11, 1989; 67 FR 79520, Dec. 30, 2002; 73 
FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 84 
FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 

 -27- July 15, 2026 
§ 2.25  Documents not returnable.  
Except as provided in §  2.27(e), documents filed in the Office by the applicant or registrant 
become part of the official record and will not be returned or removed.  
[Amended 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.26  [Removed]  
[Removed 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.27  Pending trademark application index; access to applications.  
(a) An index of pending applications including the name and address of the applicant, a 
reproduction or description of the mark, the goods or services with which the mark is used, the class 
number, the dates of use, and the serial number and filing date of the application will be available 
for public inspection as soon as practicable after filing.  
(b) Except as provided in paragraph (e) of this section, access to the file of a particular pending 
application will be permitted prior to publication under §  2.80 upon written request.  
(c) Decisions of the Director and the Trademark Trial and Appeal Board in applications and 
proceedings relating thereto are published or available for inspection or publication.  
(d) Except as provided in paragraph (e) of this section, the official records of applications and 
all proceedings relating thereto are available for public inspection and copies of the documents may 
be furnished upon payment of the fee required by §  2.6. 
(e) Anything ordered to be filed under seal pursuant to a protective order issued or made by any 
court or by the Trademark Trial and Appeal Board in any proceeding involving an application or 
registration shall be kept confidential and shall not be made av ailable for public inspection or 
copying unless otherwise ordered by the court or the Board, or unless the party protected by the 
order voluntarily discloses the matter subject thereto.  When possible, only confidential portions of 
filings with the Board s hall be filed under seal.  
[36 FR 25406, Dec. 31, 1971, as amended at 48 FR 23134, May 23, 1983; 48 FR 27225, June 14, 1983; 68 
FR 14332, March 25, 2003, effective May 1, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009] 
§ 2.32   Requirements for a complete trademark or service mark application . 
(a) The application must be in English and include the following:  
(1) A request for registration;  
(2) The name, domicile address, and email address of each applicant. If the applicant is a 
national of a country that has acceded to the Trademark Law Treaty, but not to the Singapore 
Treaty on the Law of Trademarks, the requirement to provide an email address does not apply; 
(3)(i) The legal entity type and citizenship of the applicant(s); and  
(ii) If the applicant is a corporation, association, partnership or other juristic person, the 
jurisdiction (usually state or nation) under the laws of which the applicant is organized;  
(iii) If the applicant is a domestic partnership, the names and citizenship of the general partners;  
(iv) If the applicant is a domestic joint venture, the names and citizenship of the active members 
of the joint venture;  or 
(v) If the applicant is a sole proprietorship, the state of organization of the sole proprietorship 
and the name and citizenship of the sole proprietor.  
(4) When the applicant is, or must be, represented by an attorney, as defined in § 11.1 of this 
chapter, who is qualified to practice under § 11.14 of this chapter, the  attorney’s name, postal 
address, email address, and bar information; 
(5) One or more bases, as required by §  2.34(a);  
(6) A list of the particular goods or services on or in connection with which the applicant uses or 
intends to use the mark.  In a U.S. application filed under section 44 of the Act, the scope of the 

 -28- July 15, 2026 
goods or services covered by the section 44 basis may not exceed the scope of the goods or 
services in the foreign application or registration;    
(7) The international class of goods or services, if known.  See § 6.1 of this chapter for a list of 
the international classes of goods and services;  
(8) If the mark is not in standard characters, a description of the mark;  
(9) If the mark includes non -English wording, an English translation of that wording; and  
(10) If the mark includes non-Latin characters, a transliteration of those characters, and either 
a translation of the transliterated term in English, or a statement that the transliterated term has no 
meaning in English. 
(b) The application must include a verified statement that meets the requirements of § 2.33. 
(c) The application must include a drawing that meets the requirements of § 2.51 and  
§ 2.52.  
(d) The application must include the fee required by § 2.6 for each class of goods or services. 
(e) For the requirements of a multiple -class application, see § 2.86.  
(f) For the requirements of all collective mark applications, see § 2.44.  
(g) For the requirements of a certification mark application, see § 2.45.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; amended 73 FR 13780, March 14, 2008, effective May 
13, 2008; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 80 FR 33170, June 11, 2015, effective July 
11, 2015; 84 FR 31498, July 2, 2019, effective Aug. 3, 2019; 84 FR 37081, July 31, 2019, effective Feb. 15, 
2020] 
§ 2.33  Verified statement  for a trademark or service mark . 
(a) The application must include a verified statement.  
(b)(1) In an application under section 1(a) of the Act, the verified statement must allege:   
That the applicant believes the applicant is the owner of the mark; that the mark is in 
use in commerce; that to the best of the signatory’s knowledge and belief, no other 
person has the right to use the mark in commerce, either in the identical form or in such 
near resemblance as to be likely, when applied to the goods or services of such other 
person, to cause confusion or mistake, or to deceive; that the specimen shows the mark 
as used on or in connection with the goods or services; and that the facts set forth in the 
application are true.  
(2) In an application under section 1(b) or 44 of the Act, the verified statement must allege:  
That the applicant has a bona fide intention to use the mark in commerce; that the 
applicant believes the applicant is entitled to use the mark in commerce on or in 
connection with the goods or services specified in the application; that to the best of the 
signatory’s knowledge and belief, no other person has the right to use the mark in 
commerce, either in the identical form or in such near resemblance as to be likely, when 
applied to the goods or services of such other person, to cause confusion or mistake, or 
to deceive; and that the facts set forth in the application are true.  
(c) If the verified statement in paragraph (b)(1) or (2) of this section is not filed within a 
reasonable time after it is signed, the Office may require the applicant to submit a substitute verified 
statement attesting that the mark was in use in commerce as of the application filing date, or the 
applicant had a bona fide intention to use the mark in commerce as of the application filing date.  
(d) [Reserved]  
(e) In an application under section 66(a) of the Act, the verified statement, which is part of the 
international registration on file with the International Bureau, must allege that:   
(1) The applicant/holder has a bona fide intention to use the mark in commerce that the U.S. 
Congress can regulate on or in connection with the goods or services specified in the international 
application/subsequent designation;  
(2) The signatory is properly authorized to execute the declaration on behalf of the 
applicant/holder;  

 -29- July 15, 2026 
(3) The signatory believes the applicant/holder to be entitled to use the mark in commerce that 
the U.S. Congress can regulate on or in connection with the goods or services specified in the 
international application/subsequent designation; and  
(4) To the best of his/her knowledge and belief, no other person, firm, corporation, association, 
or other legal entity has the right to use the mark in commerce that the U.S. Congress can regulate 
either in the identical form thereof or in such near resemblance thereto as to be likely, when used 
on or in connection with the goods or services of such other person, firm, corporation, association, 
or other legal entity, to cause confusion, or to cause mistake, or to deceive.  
(f) In an application for concurrent use under § 2.42, the verified statement in paragraph (b)(1) 
of this section must be modified to indicate that no other person except as specified in the 
application has the right to use the mark in commerce. 
 [30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37589, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 67 FR 79520, Dec. 30, 2002; 68 FR 14332, March 25, 2003, effective May 1, 2003; 
68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 
73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 
80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.34  Bases for filing a trademark or service mark application.  
(a) An application for a trademark or service mark must include one or more of the following five 
filing bases:  
(1) Use in commerce under section 1(a) of the Act.  The requirements for an application under 
section 1(a) of the Act are:  
(i) The applicant’s verified statement that the mark is in use in commerce.  If the verified 
statement is not filed with the initial application, the verified statement must also allege that the mark 
was in use in commerce as of the application filing date;  
(ii) The date of the applicant’s first use of the mark anywhere on or in connection with the goods 
or services;  
(iii) The date of the applicant’s first use of the mark in commerce;  
(iv) One specimen showing how the applicant uses the mark in commerce; and  
(v) If the application specifies more than one item of goods or services in a class, the dates of 
use in paragraphs (a)(1)(ii) and (iii) of this section are required for only one item of goods or services 
specified in that class. 
(2) Intent-to-use under section 1(b) of the Act.  In an application under section 1(b) of the Act, 
the applicant must verify that the applicant has a bona fide intention to use the mark in commerce.  
If the verified statement is not filed with the initial application, the verified statement must also allege 
that the applicant had a bona fide intention to use the mark in commerce as of the application filing 
date.  
(3) Registration of a mark in a foreign applicant’s country of origin under section 44(e) of the 
Act.  The requirements for an application under section 44(e) of the Act are:  
(i) The applicant’s verified statement that the applicant has a bona fide intention to use the mark 
in commerce.  If the verified statement is not filed with the initial application, the Office will require 
submission of the verified statement, which must also allege that the applicant had a bona fide 
intention to use the mark in commerce as of the application filing date.  
(ii) A true copy, a photocopy, a certification, or a certified copy of a registration in the applicant’s 
country of origin showing that the mark has been registered in that country, and that the registration 
is in full force and effect.  The certification or copy of the foreign registration must show the name 
of the owner, the mark, and the goods or services for which the mark is registered.  If the foreign 
registration is not in the English language, the applicant must submit a translation.  
(iii) If the record indicates that the foreign registration will expire before the U.S. registration will 
issue, the applicant must submit a true copy, a photocopy, a certification, or a certified copy of a 
proof of renewal from the applicant’s country of origin to establish that the foreign registration has 

 -30- July 15, 2026 
been renewed and will be in full force and effect at the time the U.S. registration will issue.  If the 
proof of renewal is not in the English language, the applicant must submit a translation.  
(4) Claim of priority, based upon an earlier-filed foreign application, under section 44(d) of the 
Act.  The requirements for an application under section 44(d) of the Act are:  
(i) A claim of priority, filed within six months of the filing date of the foreign application.  Before 
publication or registration on the Supplemental Register, the applicant must either:  
(A) Specify the filing date, serial number and country of the first regularly filed foreign application; 
or  
(B) State that the application is based upon a subsequent regularly filed application in the same 
foreign country, and that any prior-filed application has been withdrawn, abandoned, or otherwise 
disposed of, without having been laid open to public inspection and without having any rights 
outstanding, and has not served as a basis for claiming a right of priority.  
(ii) The applicant’s verified statement that the applicant has a bona fide intention to use the mark 
in commerce.  If the verified statement is not filed with the initial application, the Office will require 
submission of the verified statement, which must also allege that the applicant had a bona fide 
intention to use the mark in commerce as of the application filing date.  
(iii) Before the application can be approved for publication, or for registration on the 
Supplemental Register, the applicant must establish a basis under section 1 or 44 of the Act.  
(5) Extension of protection of an international registration under section 66(a) of the Act.  In an 
application under section 66(a) of the Act, the international application/subsequent designation must 
contain a signed declaration that meets the requirements of § 2.33(a), (e).   
(b) More than one basis.  In an application under section 1 or 44 of the Act, an applicant may 
claim more than one basis, provided the applicant satisfies all requirements for the bases claimed.  
In such case, the applicant must specify each basis and the goods or services to which that basis 
applies.  An applicant must specify the goods or services covered by more than one basis.  Section 
1(a) and 1(b) of the Act may not both be claimed for identical goods or services in the same 
application.  A basis under section 66(a) of the Act may not be combined with another basis.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 67 FR 79520, Dec. 30, 2002; 68 FR 55748, Sept. 26, 
2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 77 FR 30197, May 22, 
2012, effective June 21, 2012; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.35  Adding, deleting, or substituting bases.  
(a) In an application under section 66(a) of the Act, an applicant may not add, substitute or 
delete a basis, unless the applicant meets the requirements for transformation under section 70(c) 
of the Act and §  7.31 of this chapter.  
(b) In an application under section 1 or section 44 of the Act:  
(1) Before publication for opposition, an applicant may add or substitute a basis, if the applicant 
meets all requirements for the new basis, as stated in § 2.34, § 2.44, or § 2.45.  The applicant may 
delete a basis at any time. 
(2) After publication, an applicant may add or substitute a basis in an application that is not the 
subject of an inter partes proceeding before the Trademark Trial and Appeal Board, but only with 
the express permission of the Director, after consideration on petition.  Republication will be 
required.  The amendment of an application that is the subject of an inter partes proceeding before 
the Board is governed by §  2.133(a).  
(3) When an applicant substitutes one basis for another, the Office will presume that there was 
a continuing valid basis, unless there is contradictory evidence in the record, and the application 
will retain the original filing date, including a priority filing date under section 44(d), if appropriate.   
(4) If an applicant properly claims a section 44(d) basis in addition to another basis, the applicant 
will retain the priority filing date under section 44(d) no matter which basis the applicant perfects.   
(5) The applicant may add or substitute a section 44(d) basis only within the six-month priority 
period following the filing date of the foreign application.  

 -31- July 15, 2026 
(6) When the applicant adds or substitutes a basis, the applicant must list each basis and specify 
the goods, services, or collective membership organization to which that basis applies.   
(7) When the applicant deletes a basis, the applicant must also delete any goods, services, or 
collective membership organization covered solely by the deleted basis.   
(8) Once an applicant claims a section 1(b) basis as to any or all of the goods or services, or a 
collective membership organization, the applicant may not amend the application to seek 
registration under section 1(a) of the Act for identical goods or services  or the same collective 
membership organization, unless the applicant files an allegation of use under section 1(c) or 
section 1(d) of the Act.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 14332, March 25, 2003, effective May 1, 2003; 
68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 80 FR 33170, June 11, 2015, effective July 11, 2015] 
§ 2.36  Identification of prior registrations.  
Prior registrations of the same or similar marks owned by the applicant should be identified in 
the application if the owner(s) last listed in Office records of the prior registrations differs from the 
owner(s) listed in the application.  
[Amended at 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015]  
§ 2.37  Description of mark.  
A description of the mark must be included if the mark is not in standard characters.  In an 
application where the mark is in standard characters, a description may be included and must be 
included if required by the trademark examining attorney.  
[30 FR 13193, Oct. 16, 1965; Redesignated at 64 FR 48920, Sept. 8, 1999; 68 FR 55748, Sept. 26, 2003, 
effective Nov. 2, 2003; 73 FR 13780, March 14, 2008, effective May 13, 2008]  
§ 2.38  Use by predecessor or by related companies.  
(a) If the first use of the mark was by a predecessor in title or by a related company (sections 5 
and 45 of the Act), and the use inures to the benefit of the applicant, the dates of first use 
(§§ 2.34(a)(1)(ii) and (iii)) may be asserted with a statement that first use was by the predecessor 
in title or by the related company, as appropriate. 
(b) The Office may require such details concerning the nature of the relationship and such proofs 
as may be necessary and appropriate for the purpose of showing that the use by related companies 
inures to the benefit of the applicant and does not affect the va lidity of the mark. 
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37589, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999 ; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015  ] 
§ 2.41  Proof of distinctiveness under section 2(f).  
(a) For a trademark or service mark —(1) Ownership of prior registration(s).  In appropriate 
cases, ownership of one or more active prior registrations on the Principal Register or under the 
Trademark Act of 1905 of the same mark may be accepted as prima facie evidence of 
distinctiveness if the goods or services are sufficiently sim ilar to the goods or services in the 
application; however, further evidence may be required.   
(2) Five years substantially exclusive and continuous use in commerce.  In appropriate cases, 
if a trademark or service mark is said to have become distinctive of the applicant’s goods or services 
by reason of the applicant’s substantially exclusive and continuous use of the mark in commerce 
for the five years before the date on which the claim of distinctiveness is made, a showing by way 

 -32- July 15, 2026 
of verified statements in the application may be accepted as prima facie evidence of distinctiveness; 
however, further evidence may be required.  
(3) Other evidence.  In appropriate cases, where the applicant claims that a mark has become 
distinctive in commerce of the applicant’s goods or services, the applicant may, in support of 
registrability, submit with the application, or in response to a request for evidence or to a refusal to 
register, verified statements, depositions, or other appropriate evidence showing duration, extent, 
and nature of the use in commerce and advertising expenditures in connection therewith (identifying 
types of media and attaching typical advertisements), and verified statements, letters or statements 
from the trade or public, or both, or other appropriate evidence of distinctiveness.  
(b) For a collective trademark or collective service mark—(1) Ownership of prior registration(s).  
See the requirements of paragraph (a)(1) of this section.  
(2) Five years substantially exclusive and continuous use in commerce.  In appropriate cases, 
if a collective trademark or collective service mark is said to have become distinctive of the 
members’ goods or services by reason of the members’ substantially exclusive and continuous use 
of the mark in commerce for the five years before the date on which the claim of distinctiveness is 
made, a showing by way of verified statements in the application may be accepted as prima facie 
evidence of distinctiveness; ho wever, further evidence may be required.  
(3) Other evidence.  In appropriate cases, where the applicant claims that a mark has become 
distinctive in commerce of the members’ goods or services, the applicant may, in support of 
registrability, submit with the application, or in response to a request for evidence or to a refusal to 
register, verified statements, depositions, or other appropriate evidence showing duration, extent, 
and nature of the use in commerce, and advertising expenditures in connection therewith 
(identifying types of media and attaching typical advertisements), and verified statements, letters or 
statements from the trade or public, or both, or other appropriate evidence of distinctiveness.  
(c) For a collective membership mark—(1) Ownership of prior registration(s).  In appropriate 
cases, ownership of one or more active prior registrations on the Principal Register or under the Act 
of 1905 of the same mark may be accepted as prima facie evidence of distinctiveness if the goods, 
services, or nature of the collective membership organization are sufficiently similar to the collective 
membership organization in the application; however, further evidence may be required.   
(2) Five years substantially exclusive and continuous use in commerce.  In appropriate cases, 
if a collective membership mark is said to have become distinctive of indicating membership in the 
applicant’s collective membership organization by reason of the members’ substantially exclusive 
and continuous use of the mark in commerce for the five years before the date on which the claim 
of distinctiveness is made, a showing by way of verified statements in the application may be 
accepted as prima facie evidence of distinctiveness; however, further evidence may be required. 
(3) Other evidence.  In appropriate cases, where the applicant claims that a mark has become 
distinctive in commerce of indicating membership in the applicant’s collective membership 
organization, the applicant may, in support of registrability, submit with the application,  or in 
response to a request for evidence or to a refusal to register, verified statements, depositions, or 
other appropriate evidence showing duration, extent, and nature of the members’ use in commerce, 
and advertising expenditures in c onnection therewith (identifying types of media and attaching 
typical advertisements), and verified statements, letters or statements from the trade or public, or 
both, or other appropriate evidence of distinctiveness.  
(d) For a certification mark —(1) Ownership of prior certification mark registration(s) .  In 
appropriate cases, ownership of one or more active prior certification mark registrations on the 
Principal Register or under the Act of 1905 of the same mark may be accepted as prima facie 
evidence of distinctiveness if the authorized users’ goods or services are sufficiently similar to the 
goods or services certified in the application, subject to the limitations of the statement set forth in 
§ 2.45(a)(4)(i)(C); how ever, further evidence may be required.   
(2) Five years substantially exclusive and continuous use in commerce.  In appropriate cases, 
if a certification mark is said to have become distinctive of the certified goods or services by reason 
of the authorized users’ substantially exclusive and continuous use of the mark in commerce for the 
five years before the date on which the claim of distinctiveness is made, a showing by way of verified 

 -33- July 15, 2026 
statements in the application may be accepted as prima facie evidence of distinctiveness; however, 
further evidence may be required.  
(3) Other evidence.  In appropriate cases, where the applicant claims that a mark has become 
distinctive of the certified goods or services program, the applicant may, in support of registrability, 
submit with the application, or in response to a request for evidence or to a refusal to register, 
verified statements, depositions, or other appropriate evidence showing duration, extent, and nature 
of the authorized users’ use in commerce and advertising expenditures in connection therewith 
(identifying types of media and attaching typical advertisements), and verified statements, letters or 
statements from the trade or public, or both, or other appropriate evidence of distinctiveness.  
(e) Certification marks with geographical matter.  Paragraph (d) of this section does not apply 
to geographical matter in a certification mark certifying regional origin because section 2(e)(2) of 
the Act does not apply to certification marks that are indications of regional origin.  
 [30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37590, Sept. 11, 1989; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.42  Concurrent use.  
(a) Prior to seeking concurrent use, an application for registration on the Principal Register under 
the Act must assert use in commerce and include all the application elements required by the 
preceding sections, in addition to § 2.44 or § 2.45, if applicable.   
(b) The applicant must also include a verified statement that indicates the following, to the extent 
of the applicant’s knowledge:  
(1) For a trademark or service mark, the geographic area in which the applicant is using the 
mark in commerce; for a collective mark or certification mark, the geographic area in which the 
applicant’s members or authorized users are using the mark in commerce;  
(2) For a trademark or service mark, the applicant’s goods or services; for a collective trademark, 
collective service mark, or certification mark, the applicant’s members’ or authorized users’ goods 
or services; for a collective membership mark, the nature of the applicant’s collective membership 
organization;  
(3) The mode of use for which the applicant seeks registration;  
(4) The concurrent users’ names and addresses;  
(5) The registrations issued to or applications filed by such concurrent users, if any;  
(6) For a trademark or service mark, the geographic areas in which the concurrent user is using 
the mark in commerce; for a collective mark or certification mark, the geographic areas in which the 
concurrent user’s members or authorized users are using the  mark in commerce;  
(7) For a trademark or service mark, the concurrent user’s goods or services; for a collective 
trademark, collective service mark, or certification mark, the concurrent user’s members’ or 
authorized users’ goods or services; for a collective membership mark, the nature of the concurrent 
user’s collective membership organization;  
(8) The mode of use by the concurrent users or the concurrent users’ members or authorized 
users; and  
(9) The time periods of such use by the concurrent users or the concurrent users’ members or 
authorized users. 
(c) For the requirements to amend an application to concurrent use, see §  2.73. 
(d) For the requirements of a concurrent use proceeding, see §  2.99. 
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 34897, Aug. 22, 1989; 80 FR 33170, June 11, 2015, 
effective July 11, 2015 ] 

 -34- July 15, 2026 
§ 2.43  Service mark. 
In an application to register a service mark, the application shall specify and contain all the 
elements required by the preceding sections for trademarks, but shall be modified to relate to 
services instead of to goods wherever necessary.  
§ 2.44  Requirements for a complete collective mark application . 
(a) A complete application to register a collective trademark, collective service mark, or 
collective membership mark must include the following:  
(1) The requirements specified in § 2.32(a) introductory text through (a)(4), (a)(8) through (10), 
(c), and (d); 
(2)(i) For a collective trademark or collective service mark, a list of the particular goods or 
services on or in connection with which the applicant’s members use or intend to use the mark; or 
(ii) For a collective membership mark, a description of the nature of the membership 
organization such as by type, purpose, or area of activity of the members; and   
(iii) In a U.S. application filed under section 44 of the Act, the scope of the goods or services or 
the nature of the membership organization covered by the section 44 basis may not exceed the 
scope of the goods or services or nature of the membership organization in the foreign application 
or registration. 
(3)(i) For a collective trademark or collective service mark application, the international class of 
goods or services, if known.  See § 6.1 of this chapter for a list of the international classes of goods 
and services; or 
(ii) For a collective membership mark application filed under sections 1 or 44 of the Act, 
classification in U.S. Class 200; and for a collective membership mark application filed under section 
66(a) of the Act, the international class(es) assigned by the International Bureau in the 
corresponding international regist ration.  
(4) One or more of the following five filing bases:  
(i) Use in commerce under section 1(a) of the Act.  The requirements for an application under 
section 1(a) of the Act are:  
(A) A statement specifying the nature of the applicant’s control over the use of the mark by the 
members; 
(B) For a collective trademark or collective service mark, the date of the applicant’s member’s 
first use of the mark anywhere on or in connection with the goods or services and the date of the 
applicant’s member’s first use of the mark in commerce; or for a collective membership mark, the 
date of the applicant’s member’s first use anywhere to indicate membership in the collective 
organization and the date of the applicant’s member’s first use in commerce.  If the application 
specifies more than one item of goods or services in a class, the dates of use are required for only 
one item of goods or services specified in that class;  
(C) One specimen showing how a member uses the mark in commerce; and  
(D) A verified statement alleging:  
That the applicant believes the applicant is the owner of the mark; that the mark is in 
use in commerce; that the applicant is exercising legitimate control over the use of the 
mark in commerce; that to the best of the signatory’s knowledge and belief, no other 
persons except members have the right to use the mark in commerce, either in the 
identical form or in such near resemblance as to be likely, when used on or in connection 
with the goods, services, or collective membership organization of such other persons 
to cause confusion or mistake, or to deceive; that the specimen shows the mark as used 
in commerce by the applicant’s members; and that the facts set forth in the application 
are true. 
(ii) Intent-to-use under section 1(b) of the Act.  The requirement for an application based on 
section 1(b) of the Act is a verified statement alleging:  

 -35- July 15, 2026 
That the applicant has a bona fide intention, and is entitled, to exercise legitimate control 
over the use of the mark in commerce; that to the best of the signatory’s knowledge and 
belief, no other persons, except members, have the right to use the mark in commerce, 
either in the identical form or in such near resemblance as to be likely, when used on or 
in connection with the goods, services, or collective membership organization of such 
other persons, to cause confusion or mistake, or to deceive; and that the facts set forth 
in the application are true. 
(iii) Registration of a mark in a foreign applicant’s country of origin under section 44(e) of the 
Act.  The requirements for an application under section 44(e) of the Act are:  
(A) The requirements of § 2.34(a)(3)(ii) and (iii); and  
(B) A verified statement in accordance with paragraph (a)(4)(ii) of this section.  
(iv) Claim of priority, based upon an earlier-filed foreign application, under section 44(d) of the 
Act.  The requirements for an application under section 44(d) of the Act are:  
(A) The requirements of § 2.34(a)(4)(i) and (iii); and  
(B) A verified statement in accordance with paragraph (a)(4)(ii) of this section.   
(v) Extension of protection of an international registration under section 66(a) of the Act.  The 
requirement for an application under section 66(a) of the Act is a verified statement alleging that the 
applicant/holder has a bona fide intention, and is entitled, to exercise legitimate control over the use 
of the mark in commerce that the U.S. Congress can regulate on or in connection with the goods or 
services specified in the international application/subsequent designation; that the signatory is 
properly authorized to execute the declaration on behalf of the applicant/holder; and that to the best 
of his/her knowledge and belief, no other person, firm, corporation, association, or other legal entity, 
except members, has the right to use the mark in commerce that the U.S. Congress can regulate 
either in the identical form thereof or in such near resemblance thereto as to be likely, when used 
on or in connection with the goods, services, or collective membership organization of such other 
person, firm, corporation, association, or other legal entity, to cause confusion, or to cause mistake, 
or to deceive.  
(b) Verification not filed within reasonable time or omitted .  (1) If the verified statement in 
paragraph (a)(4)(i)(D), (a)(4)(ii), (a)(4)(iii)(B), or (a)(4)(iv)(B) of this section is not filed within a 
reasonable time after it is signed, the Office may require the applicant to submit a substitute verified 
statement attesting that, as of the application filing date, the mark was in use in commerce and the 
applicant was exercising legitimate control over the use of the mark in commerce; or, as of the 
application filing date, the applicant had a bona fide intention, and was entitled, to exercise 
legitimate control over the use of the mark in commerce; or  
(2) If the verified statement in paragraph (a)(4)(i)(D), (a)(4)(ii), (a)(4)(iii)(B), (a)(4)(iv)(B), or 
(a)(4)(v) of this section is not filed with the initial application, the verified statement must also allege 
that, as of the application filing date, the  mark was in use in commerce and the applicant was 
exercising legitimate control over the use of the mark in commerce; or, as of the application filing 
date, the applicant had a bona fide intention, and was entitled, to exercise legitimate control over 
the use of the mark in commerce. 
(c) More than one basis.  In an application under section 1 or 44 of the Act, an applicant may 
claim more than one basis, provided the applicant satisfies all requirements for the bases claimed.  
In such case, the applicant must specify each basis, followed by the goods, services, or collective 
membership organization to which that basis applies.  An applicant must specify the goods, 
services, or collective membership organization covered by more than one basis.  Section 1(a) and 
1(b) of the Act may not bot h be claimed for identical goods, or services, or the same collective 
membership organization in one application.  A basis under section 66(a) of the Act may not be 
combined with another basis. 
(d) In an application for concurrent use under § 2.42 , the verified statement in paragraph 
(a)(4)(i)(D) of this section must be modified to indicate that no other persons except members and 
the concurrent users as specified in the application have the right to use the mark in commerce.  
(e) Multiple-class applications.  For the requirements of a multiple -class application, see  
§ 2.86. 

 -36- July 15, 2026 
 [30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37590, Sept. 11, 1989; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.45  Requirements for a complete certification mark application; restriction on 
certification mark application.  
(a) A complete application to register a certification mark must include the following:  
(1) The requirements specified in § 2.32(a) introductory text through (a)(4), (a)(8) through (10), 
(c), and (d); 
(2) A list of the particular goods or services on or in connection with which the applicant’s 
authorized users use or intend to use the mark.  In an application filed under section 44 of the Act, 
the scope of the goods or services covered by the section 44 basis may not exceed the scope of 
the goods or services in the foreign application or registration ;  
(3) For applications filed under section 1 or 44 of the Act, classification in U.S. Class A for an 
application certifying goods and U.S. Class B for an application certifying services.  For applications 
filed under section 66(a) of the Act, the international class(es) of goods or services assigned by the 
International Bureau in the corresponding international registration;  
(4) One or more of the following five filing bases:  
(i) Use in commerce under section 1(a) of the Act.  The requirements for an application under 
section 1(a) of the Act are:    
(A) A statement specifying what the applicant is certifying about the goods or services in the 
application; 
(B) A copy of the certification standards governing use of the certification mark on or in 
connection with the goods or services specified in the application;  
(C) A statement that the applicant is not engaged in the production or marketing of the goods 
or services to which the mark is applied, except to advertise or promote recognition of the 
certification program or of the goods or services that meet the certif ication standards of the 
applicant; 
(D) The date of the applicant’s authorized user’s first use of the mark anywhere on or in 
connection with the goods or services and the date of the applicant’s authorized user’s first use of 
the mark in commerce.  If the application specifies more than one item of goods or services in a 
class, the dates of use are required for only one item of goods or services specified in that class; 
(E) One specimen showing how an authorized user uses the mark in commerce; and  
(F) A verified statement alleging:  
That the applicant believes the applicant is the owner of the mark; that the mark is in 
use in commerce; that the applicant is exercising legitimate control over the use of the 
mark in commerce; that to the best of the signatory’s knowledge and belief, no other 
persons except authorized users have the right to use the mark in commerce, either in 
the identical form or in such near resemblance as to be likely, when used on or in 
connection with the goods or services of such other persons, to cause confusion o r 
mistake, or to deceive; that the specimen shows the mark as used in commerce by the 
applicant’s authorized users; and that the facts set forth in the application are true.  
(ii) Intent-to-use under section 1(b) of the Act.  The requirements for an application based on 
section 1(b) of the Act are:  
(A) A statement specifying what the applicant will be certifying about the goods or services in 
the application; 
(B) A statement that the applicant will not engage in the production or marketing of the goods 
or services to which the mark is applied, except to advertise or promote recognition of the 
certification program or of the goods or services that meet the certi fication standards of the 
applicant; and  
(C) A verified statement alleging:  
That the applicant has a bona fide intention, and is entitled, to exercise legitimate control 
over the use of the mark in commerce; that to the best of the signatory’s knowledge and 

 -37- July 15, 2026 
belief, no other persons, except authorized users, have the right to use the mark in 
commerce, either in the identical form or in such near resemblance as to be likely, when 
used on or in connection with the goods or services of such other persons, to cause 
confusion or mistake, or to deceive; and that the facts set forth in the application are 
true. 
(iii) Registration of a mark in a foreign applicant’s country of origin under section 44(e) of the 
Act.  The requirements for an application under section 44(e) of the Act are:  
(A) The requirements of § 2.34(a)(3)(ii) and (iii);  
(B) The requirements in paragraphs (a)(4)(ii)(A) and (B) of this section; and  
(C) A verified statement in accordance with paragraph (a)(4)(ii)(C) of this section.  
(iv) Claim of priority, based upon an earlier-filed foreign application, under section 44(d) of the 
Act.  The requirements for an application under section 44(d) of the Act are:  
(A) The requirements of § 2.34(a)(4)(i) and (iii);  
(B) The requirements in paragraphs (a)(4)(ii)(A) and (B) of this section; and  
(C) A verified statement in accordance with paragraph (a)(4)(ii)(C) of this section.   
(v) Extension of protection of an international registration under section 66(a) of the Act.  The 
requirements for an application under section 66(a) of the Act are:  
(A) The requirements of paragraphs (a)(4)(ii)(A) and (B) of this section; and  
(B) A verified statement alleging that the applicant/holder has a bona fide intention, and is 
entitled, to exercise legitimate control over the use of the mark in commerce that the U.S. Congress 
can regulate on or in connection with the goods or services s pecified in the international 
application/subsequent designation; that the signatory is properly authorized to execute the 
declaration on behalf of the applicant/holder; and that to the best of his/her knowledge and belief, 
no other person, firm, corporation, association, or other legal entity, except authorized users, has 
the right to use the mark in commerce that the U.S. Congress can regulate either in the identical 
form thereof or in such near resemblance thereto as to be likely, when used on or in connection 
with the goods or services of such other person, firm, corporation, association, or other legal entity, 
to cause confusion, or to cause mistake, or to deceive.  
(b) Verification not filed within reasonable time or omitted .  (1) If the verified statement in 
paragraph (a)(4)(i)(F), (a)(4)(ii)(C), (a)(4)(iii)(C), or (a)(4)(iv)(C) of this section is not filed within a 
reasonable time after it is signed, the Office may require the applicant to submit a substitute verified 
statement attesting that, as of the application filing date, the mark was in use in commerce and the 
applicant was exercising legitimate control over the use of the mark in commerce; or, as of the 
application filing date, the applicant had a bona fide intention, and was entitled, to exercise 
legitimate control over the use of the mark in commerce; or  
(2) If the verified statement in paragraph (a)(4)(i)(F), (a)(4)(ii)(C), (a)(4)(iii)(C), (a)(4)(iv)(C), or 
(a)(4)(v)(B) of this section is not filed with the initial application, the verified statement must also 
allege that, as of the application filing date, the mark was in use in commerce and the applicant was 
exercising legitimate control over the use of the mark in commerce; or, as of the application filing 
date, the applicant had a bona fide intention, and was entitled, to exercise legitimate control over 
the use of the mark in commerce.  
(c) More than one basis.  In an application under section 1 or 44 of the Act, an applicant may 
claim more than one basis, provided the applicant satisfies all requirements for the bases claimed.  
In such case, the applicant must specify each basis, followed by the goods or services to which that 
basis applies.  An applicant must specify the goods or services covered by more than one basis.  
Section 1(a) and 1(b) of the Act may not both be claimed for identical goods or services in the same 
application.  A basis under section 66(a) of the Act may not be combined with another basis.  
(d) Concurrent use.  In an application for concurrent use under § 2.42, the verified statement in 
paragraph (a)(4)(i)(F) of this section must be modified to indicate that no other persons except 
authorized users and concurrent users as specified in the application have the right to use the mark 
in commerce. 
(e) Multiple-class applications.  For the requirements of a multiple -class application, see  
§ 2.86. 

 -38- July 15, 2026 
(f) Restriction on certification mark application .  A single application may not include a 
certification mark and another type of mark.  The same mark for the same goods or services is not 
registrable as both a certification mark and another type of mark.  See sections 4 and 14(5)(B) of 
the Act.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37590, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 80 FR 33170, June 11, 2015, 
effective July 11, 2015 ] 
§ 2.46  Principal Register.  
All applications will be treated as seeking registration on the Principal Register unless otherwise 
stated in the application.  Service marks, collective marks, and certification marks, registrable in 
accordance with the applicable provisions of section 2 of the Act, are registered on the Principal 
Register. 
§ 2.47  Supplemental Register.  
(a) In an application to register on the Supplemental Register under section 23 of the Act, the 
application shall so indicate and shall specify that the mark has been in use in commerce.   
(b) In an application to register on the Supplemental Register under section 44 of the Act, the 
application shall so indicate.  The statement of lawful use in commerce may be omitted.  
(c) An application under section 66(a) of the Act is not eligible for registration on the 
Supplemental Register. 
(d) A mark in an application to register on the Principal Register under section 1(b) of the Act is 
eligible for registration on the Supplemental Register only after an acceptable amendment to allege 
use under §  2.76 or statement of use under §  2.88 has been timely filed.  
(e) An application for registration on the Supplemental Register must conform to the 
requirements for registration on the Principal Register under section 1(a) of the Act, so far as 
applicable.  
[38 FR 18876, July 16, 1973, as amended at 54 FR 37590, Sept. 11, 1989; 68 FR 55748, Sept. 26, 2003, 
effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.48  Office does not issue duplicate registrations.  
If two applications on the same register would result in registrations that are exact duplicates, 
the Office will permit only one application to mature into registration, and will refuse registration in 
the other application.   
 [Added 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
DRAWING 
§ 2.51  Drawing required.  
(a) In an application under section 1(a) of the Act, the drawing of the mark must be a 
substantially exact representation of the mark as used on or in connection with the goods and/or 
services. 
(b) In an application under section 1(b) of the Act, the drawing of the mark must be a 
substantially exact representation of the mark as intended to be used on or in connection with the 
goods and/or services specified in the application, and once an amendment to allege use under 
§ 2.76 or a statement of use under §  2.88 has been filed, the drawing of the mark must be a 
substantially exact representation of the mark as used on or in connection with the goods and/or 
services.  

 -39- July 15, 2026 
(c) In an application under section 44 of the Act, the drawing of the mark must be a substantially 
exact representation of the mark as it appears in the drawing in the registration certificate of a mark 
duly registered in the applicant’s country of origin.   
(d) In an application under section 66(a) of the Act, the drawing of the mark must be a 
substantially exact representation of the mark as it appears in the international registration.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37590, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003]  
§ 2.52  Types of drawings and format for drawings.  
A drawing depicts the mark sought to be registered.  The drawing must show only one mark.  
The applicant must include a clear drawing of the mark when the application is filed.  There are two 
types of drawings:  
(a) Standard character (typed) drawing .  Applicants who seek to register words, letters, 
numbers, or any combination thereof without claim to any particular font style, size, or color must 
submit a standard character drawing that shows the mark in black on a white background.  An 
applicant may submit a standard character drawing if: 
(1) The application includes a statement that the mark is in standard characters and no claim is 
made to any particular font style, size, or color;  
(2) The mark does not include a design element;  
(3) All letters and words in the mark are depicted in Latin characters;  
(4) All numerals in the mark are depicted in Roman or Arabic numerals; and 
(5) The mark includes only common punctuation or diacritical marks.  
(b) Special form drawing.  Applicants who seek to register a mark that includes a two or three-
dimensional design; color; and/or words, letters, or numbers or the combination thereof in a 
particular font style or size must submit a special form drawing.  The drawing should show the mark 
in black on a white background, unless the mark includes color.  
(1) Marks that include color.  If the mark includes color, the drawing must show the mark in 
color, and the applicant must name the color(s), describe where the color(s) appear on the mark, 
and submit a claim that the color(s) is a feature of the mark.   
(2) Three dimensional marks.  If the mark has three -dimensional features, the drawing must 
depict a single rendition of the mark, and the applicant must indicate that the mark is three -
dimensional.  
(3) Motion marks.   If the mark has motion, the drawing may depict a single point in the 
movement, or the drawing may depict up to five freeze frames showing various points in the 
movement, whichever best depicts the commercial impression of the mark.  The applicant must 
also describe the mark.  
(4) Broken lines to show placement .  If necessary to adequately depict the commercial 
impression of the mark, the applicant may be required to submit a drawing that shows the placement 
of the mark by surrounding the mark with a proportionately accurate broken-line representation of 
the particular goods, packaging, or advertising on which the mark appears.  The applicant must also 
use broken lines to show any other matter not claimed as part of the mark.  For any drawing using 
broken lines to indicate placement of the mark, or matter not claimed as part of the mark, the 
applicant must describe the mark and explain the purpose of the broken lines.  
(5) Description of mark.  A description of the mark must be included.  
(c) TEAS drawings.  A drawing filed through TEAS must meet the requirements of §  2.53. 
(d) Paper drawings.   A paper drawing must meet the requirements of §  2.54.  
(e) Sound, scent, and non-visual marks.  An applicant is not required to submit a drawing if the 
mark consists only of a sound, a scent, or other completely non-visual matter.  For these types of 
marks, the applicant must submit a detailed description of the mark. 

 -40- July 15, 2026 
[51 FR 29921, Aug. 21, 1986, as amended at 54 FR 37591, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 13780, March 14, 2008, 
effective May 13, 2008; 73 FR 67759, Nov. 17, 200 8, effective Jan. 16, 2009]  
§ 2.53  Requirements for drawings filed through the TEAS.  
The drawing must meet the requirements of § 2.52.  In addition, in a TEAS submission, the 
drawing must meet the following requirements:  
(a) Standard character drawings.  If an applicant seeks registration of a standard character 
mark, the applicant must enter the mark in the appropriate field on the TEAS form, and check the 
box to claim that the mark consists of standard characters. 
(b) Special form drawings:  If an applicant is filing a special form drawing, the applicant must 
attach a digitized image of the mark to the TEAS submission that meets the requirements of 
paragraph (c) of this section.   
(c) Requirements for digitized image:  The image must be in .jpg format and scanned at no less 
than 300 dots per inch and no more than 350 dots per inch with a length and width of no less than 
250 pixels and no more than 944 pixels.  All lines must be clean, sharp and solid, not fine or 
crowded, and produce a high quality image when copied.   
[Added 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; amended 70 FR 38768, July 6, 2005, effective 
July 18, 2005; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.54  Requirements for drawings submitted on paper.  
The drawing must meet the requirements of §  2.52.  In addition, in a paper submission, the 
drawing should:  
(a) Be on non-shiny white paper that is separate from the application;  
(b) Be on paper that is 8 to 8.5 inches (20.3 to 21.6 cm.) wide and 11 to 11.69 inches (27.9 to 
29.7 cm.) long.  One of the shorter sides of the sheet should be regarded as its top edge.  The 
image must be no larger than 3.15 inches (8 cm) high by 3.15 inc hes (8 cm) wide; 
(c) Include the caption “DRAWING PAGE” at the top of the drawing beginning one inch (2.5 
cm.) from the top edge; and  
(d) Depict the mark in black ink, or in color if color is claimed as a feature of the mark.   
(e) Drawings must be typed or made with a pen or by a process that will provide high definition 
when copied.  A photolithographic, printer’s proof copy, or other high quality reproduction of the 
mark may be used.  All lines must be clean, sharp and solid, and must not be fine or crowded.  
[Added 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003]  
SPECIMENS 
§ 2.56  Specimens.  
(a) An application under section 1(a) of the Act, an amendment to allege use under § 2.76, a 
statement of use under § 2.88, an affidavit or declaration of continued use or excusable nonuse 
under §  2.160, or an affidavit or declaration of use or excusable nonuse under §  7.36 must include 
one specimen per class showing the mark as actually used in commerce on or in connection with 
the goods or services identified. When requested by the Office as reasonably necessary to proper 
examination, additional specimens must be provided.  
(b)(1) A trademark specimen must show use of the mark on the goods, on containers or 
packaging for the goods, on labels or tags affixed to the goods, or on a display associated with the 
goods. To constitute a display associated with the goods, a specimen must show use of the mark 
directly associated with the goods and such use must be of a point-of-sale nature. The Office may 
accept another document related to the goods or the sale of the goods when it is impracticable to 
place the mark on the goods, packaging for the goods, or displays associated with the goods.  

 -41- July 15, 2026 
(2) A service mark specimen must show the mark as used in the sale of the services, including 
use in the performance or rendering of the services, or in the advertising of the services. The 
specimen must show a direct association between the mark and the servi ces.  
(3) A collective trademark or collective service mark specimen must show how a member uses 
the mark on the member's goods or in the sale of the services, including use in the performance or 
rendering of the services, or advertising of the member's services.  
(4) A collective membership mark specimen must show use by members to indicate 
membership in the collective organization.   
(5) A certification mark specimen must show how a person other than the owner uses the mark 
to reflect certification of regional or other origin, material, mode of manufacture, quality, accuracy, 
or other characteristics of that person’s goods or services; or that members of a union or other 
organization performed the work or labor on the goods or services.   
(c) A clear and legible photocopy, photograph, web page printout, or other similar type of 
reproduction of an actual specimen that meets the requirements of paragraphs (a) and (b) of this 
section is acceptable. The reproduction must show the entire specimen or enough of the specimen 
that the nature of the specimen, the mark, and the good or service with which the mark is used are 
identifiable. A web page must include the URL and access or print date. An artist's rendering, a 
printer's proof, a computer illustration, digital image, or similar mockup of how the mark may be 
displayed, or a photocopy of the drawing required by §  2.51, are not proper specimens.  
(d) The specimen must be submitted through TEAS in a file format designated as acceptable 
by the Office, unless:  
(1) The mark consists of a scent, flavor, or similar non-traditional mark type, in which case the 
specimen may be mailed to the Office, pursuant to § 2.190(a), without resort to the procedures set 
forth in §   2.147; or  
(2) Submission on paper is permitted under § 2.23(c) or is accepted on petition pursuant to §  
2.147. 
[39 FR 12248, Apr. 4, 1974, as amended at 54 FR 37591, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009; 77 FR 30197, May 22, 2012, effective June 21, 2012; 80 FR 33170, June 11, 2015, 
effective July 11, 2015 ; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 
§ 2.59  Filing substitute specimen(s).  
(a) In an application under section 1(a) of the Act, the applicant may submit substitute 
specimens of the mark as used on or in connection with the goods or in the sale or advertising of 
the services, or as used to indicate membership in the collective organization.  The applicant must 
submit a verified statement that the substitute specimen was in use in commerce at least as early 
as the filing date of the application.  The verified statement is not required if the specimen is a 
duplicate or facsimile of a specimen already of record in the application.  
(b) In an application under section 1(b) of the Act, after filing either an amendment to allege use 
under § 2.76 or a statement of use under § 2.88, the applicant may submit substitute specimens of 
the mark as used on or in connection with the goods or in the sale or advertising of the services, or 
as used to indicate membership in the collective organization.  If the applicant submits substitute 
specimen(s), the applicant must:   
(1) For an amendment to allege use under § 2.76, submit a verified statement that the substitute 
specimen(s) was in use in commerce prior to filing the amendment to allege use.  
(2) For a statement of use under § 2.88, submit a verified statement that the substitute 
specimen(s) was in use in commerce either prior to filing the statement of use or prior to the 
expiration of the deadline for filing the statement of use.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37591, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 

 -42- July 15, 2026 
EXAMINATION OF APPLICATION AND ACTION BY APPLICANTS 
§ 2.61  Action by examiner.  
(a) Applications for registration, including amendments to allege use under section 1(c) of the 
Act, and statements of use under section 1(d) of the Act, will be examined and, if the applicant is 
found not entitled to registration for any reason, applicant will be notified and advised of the reasons 
therefor and of any formal requirements or objections.  
(b) The Office  may require the applicant to furnish such information , exhibits, affidavits or 
declarations, and such additional specimens  as may be reasonably necessary to the proper 
examination of the application. 
[30 FR 13193, Oct. 16, 1965, as amended at 37 FR 2880, Feb. 9, 1972; 54 FR 37592, Sept. 11, 1989; 77 FR 
30197, May 22, 2012, effective June 21, 2012; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.62  Procedure for submitting response.  
(a) Deadline.   Each Office action shall set forth the deadline for response .  
(1) Response periods . Unless the applicant is notified otherwise in an Office action, the 
response periods for an Office action are as follows:  
(i) Three months from the issue date, for an Office action in an application under section 1 and/or 
section 44 of the Act; and  
(ii) Six months from the issue date, for an Office action in an application under section 66(a) of 
the Act. 
(2) Extensions of time. Unless the applicant is notified otherwise in an Office action, the time for 
response designated in paragraph (a)(1)(i) of this section may be extended by three months up to 
a maximum of six months from the Office action issue date, upon timely request and payment of 
the fee set forth in § 2.6(a)(28). To be considered timely, a request for extension of time must be 
received by the Office on or before the deadline for response set forth in the Office action . 
(b) Signature.  The response must be signed by the applicant, someone with legal authority to 
bind the applicant (e.g., a corporate officer or general partner of a partnership), or a practitioner 
qualified to practice under §  11.14 of this chapter, in accordance with the requirements of 
§ 2.193(e)(2).     
(c) Form.  Responses and requests for extensions of time to respond must be submitted through 
TEAS pursuant to § 2.23(a). Responses and requests for extensions of time to respond sent via 
email or facsimile will not be accorded a date of receipt.  
[Amended 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 
28, 2009; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015; 84 FR 37081, July 31, 2019, effective Feb. 15, 
2020; 86 FR 64300, Nov. 17, 2021, effective Dec. 1, 2022; 87 FR 62032, Oct. 13, 2022, effective Dec. 3, 
2022] 
§ 2.63  Action after response . 
(a) Repeated non-final refusal or requirement.  After response by the applicant, the examining 
attorney will review all statutory refusals and/or requirement(s) in light of the response.   
(1) If, after review of the applicant’s response, the examining attorney issues a non-final action 
that maintains any previously issued substantive refusal(s) to register or repeats any 
requirement(s), the applicant may submit a timely response to the action under § 2.62(a).  
(2) If, after review of the applicant’s response, the examining attorney issues a non-final action 
that contains no substantive refusals to register, but maintains any requirement(s), the applicant 
may respond to such repeated requirement(s) by filing a timely petition to the Director for relief from 
the repeated requirement(s) if the subject matter of the repeated requirement(s) is appropriate for 
petition to the Director ( see § 2.146(b)).   

 -43- July 15, 2026 
(b) Final refusal or requirement.  Upon review of a response, the examining attorney may state 
that any refusal to register or requirement is final.   
(1) If the examining attorney issues a final action that maintains any substantive refusal to 
register, the applicant may respond by timely filing:  
(i) A request for reconsideration under paragraph (b)(3) of this section that seeks to overcome 
any substantive refusal to register, and comply with any outstanding requirement, maintained in the 
final action;  
(ii) An appeal to the Trademark Trial and Appeal Board under §§ 2.141 and 2.142 ; or 
(iii) A request for extension of time to respond or appeal under § 2.62(a)(2).  
(2) If the examining attorney issues a final action that contains no substantive refusals to 
register, but maintains any requirement, the applicant may respond by timely filing:   
(i) A request for reconsideration under paragraph (b)(3) of this section that seeks to comply with 
any outstanding requirement maintained in the final action;  
(ii) An appeal of any requirement to the Trademark Trial and Appeal Board under §§ 2.141 and 
2.142;  
(iii) A petition to the Director under § 2.146 to review any requirement, if the subject matter of 
the requirement is procedural, and therefore appropriate for petition ; or  
(iv) A request for extension of time to respond or appeal under § 2.62(a)(2).  
(3) Prior to the expiration of the time for filing an appeal or a petition, the applicant may file a 
request for reconsideration of the final action that seeks to overcome any substantive refusal(s) 
and/or comply with any outstanding requirement(s).  Filing a request for reconsideration does not 
stay or extend the time for filing an appeal or petition.  The Office will enter amendments 
accompanying requests for reconsideration after final action if the amendments comply with the 
rules of practice in tr ademark cases and the Act.  
(4)  Filing a request for reconsideration that does not result in the withdrawal of all refusals and 
requirements, without the filing of a timely appeal or petition, will result in abandonment of the 
application for incomplete response, pursuant to § 2.65( a).  
(c) Denial of petition. A requirement that is the subject of a petition decided by the Director may 
not subsequently be the subject of an appeal to the Trademark Trial and Appeal Board. If a petition 
to the Director under § 2.146 is denied, the applicant will have the later of the following periods to 
comply with the requirement:  
(1) The time remaining in the period for response to the Office action that repeated the 
requirement or made it final; 
(2) The time remaining after the filing of a timely request for extension of time to respond or 
appeal under § 2.62(a)(2); or  
(3) Thirty days from the date of the decision on the petition.  
(d) Amendment to allege use. If an applicant in an application under section 1(b) of the Act files 
an amendment to allege use under § 2.76 during the response period after issuance of a final action, 
the examining attorney will examine the amendment. The filing of such an amendment does not 
stay or extend the time for filing an appeal or petition.  
[48 FR 23214, May 23, 1983; 68 FR 14332, March 25, 2003, effective May 1, 2003; 80 FR 2303, Jan. 16, 
2015, effective Feb. 17, 2015; 86 FR 64300, Nov. 17, 2021, effective Dec. 1, 2022; 87 FR 62032, Oct. 13, 
2022, effective Dec. 3, 2022 ] 
§ 2.64  Reinstatement of applications and registrations abandoned, cancelled, or expired 
due to Office error.  
(a) Request for Reinstatement of an Abandoned Application.  The applicant may file a written 
request to reinstate an application abandoned due to Office error.  There is no fee for a request for 
reinstatement.   
(1) Deadline.  The applicant must file the request by not later than:   
(i) Two months after the issue date of the notice of abandonment; or  

 -44- July 15, 2026 
(ii) Two months after the date of actual knowledge of the abandonment and not later than six 
months after the date the trademark electronic records system indicates that the application is 
abandoned, where the applicant declares under § 2.20 or 28 U.S.C. 1746 that it did not receive the 
notice of abandonment. 
(2) Requirements.  A request to reinstate an application abandoned due to Office error must 
include:  
(i) Proof that a response to an Office action, a statement of use, or a request for extension of 
time to file a statement of use was timely filed and a copy of the relevant document;  
(ii) Proof of actual receipt by the Office of a response to an Office action, a statement of use, or 
a request for extension of time to file a statement of use and a copy of the relevant document;  
(iii) Proof that the Office processed a fee in connection with the filing at issue and a copy of the 
relevant document;  
(iv) Proof that the Office sent the Office action or notice of allowance to an address that is not 
the designated correspondence address; or  
(v) Other evidence, or factual information supported by a declaration under § 2.20 or 28 U.S.C. 
1746, demonstrating Office error in abandoning the application.  
(b) Request for Reinstatement of Cancelled or Expired Registration.  The registrant may file a 
written request to reinstate a registration cancelled or expired due to Office error.  There is no fee 
for the request for reinstatement.   
(1) Deadline.  The registrant must file the request by not later than:  
(i) Two months after the issue date of the notice of cancellation/expiration; or  
(ii) Where the registrant has timely filed an affidavit of use or excusable non-use under section 
8 or 71 of the Act, or a renewal application under section 9 of the Act, two months after the date of 
actual knowledge of the cancellation/expiration and not later than six months after the date the 
trademark electronic records system indicates that the registration is cancelled/expired, where the 
registrant declares under § 2.20 or 28 U.S.C. 1746 that it did not receive the notice of 
cancellation/expiration or where the Office did not issue a notice.   
(2) Requirements.  A request to reinstate a registration cancelled/expired due to Office error 
must include:  
(i) Proof that an affidavit or declaration of use or excusable nonuse, a renewal application, or a 
response to an Office action was timely filed and a copy of the relevant document;  
(ii) Proof of actual receipt by the Office of an affidavit or declaration of use or excusable nonuse, 
a renewal application, or a response to an Office action and a copy of the relevant document;  
(iii) Proof that the Office processed a fee in connection with the filing at issue and a copy of the 
relevant document;  
(iv) Proof that the Office sent the Office action to an address that is not the designated 
correspondence address; or  
(v) Other evidence, or factual information supported by a declaration under § 2.20 or 28 U.S.C. 
1746, demonstrating Office error in cancelling/expiring the registration.  
(c) Request for Reinstatement May be Construed as Petition.  If an applicant or registrant is not 
entitled to reinstatement, a request for reinstatement may be construed as a petition to the Director 
under § 2.146 or a petition to revive under § 2.66, if appropriate.  If the applicant or registrant is 
unable to meet the timeliness requirement under paragraphs (a)(1) or (b)(1) of this section for filing 
the request, the applicant or registrant may submit a petition to the Director under § 2.146(a)(5) to 
request a waiver of the rule.   
[82 FR 29401, June 29, 2017, effective July 8, 2017]  
§ 2.65  Abandonment.  
(a) An application will be abandoned if an applicant fails to respond to an Office action, or to 
respond completely, within the relevant time period for response under § 2.62(a)(1), including any 
granted extension of time to respond under § 2.62(a)(2). A timely petition to the Director pursuant 

 -45- July 15, 2026 
to §§ 2.63(a) and (b) and 2.146 or notice of appeal to the Trademark Trial and Appeal Board 
pursuant to § 2.142, if appropriate, is a response that avoids abandonment (see § 2.63(b)(4)).  
(1) If all refusals and/or requirements are expressly limited to certain goods and/or services, the 
application will be abandoned only as to those goods and/or services.   
(2) When a timely response by the applicant is a bona fide attempt to advance the examination 
of the application and is a substantially complete response to the examining attorney's action, but 
consideration of some matter or compliance with a requirement has been omitted, the examining 
attorney may grant the applicant 30 days, or to the end of the time period for response to the action 
to which the substantially complete response was submitted, whichever is longer, to explain and 
supply the omission before  the examining attorney considers the question of abandonment.  
(b) An application will be abandoned if an applicant expressly abandons the application pursuant 
to § 2.68. 
(c) An application will be abandoned if an applicant in an application under section 1(b) of the 
Act fails to timely file either a statement of use under § 2.88 or a request for an extension of time for 
filing a statement of use under § 2.89.   
[48 FR 23134, May 23, 1983, as amended at 54 FR 37592, Sept. 11, 1989; 68 FR 14332, March 25, 2003, 
effective May 1, 2003; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015; 86 FR 64300, Nov. 17, 2021, 
effective Dec. 1, 2022; 87 FR 62032, Oct. 13, 2022, effective Dec. 3, 2022 ] 
§ 2.66  Revival of applications abandoned in full or in part due to unintentional delay . 
(a) Deadline.  The applicant may file a petition to revive an application abandoned in full or in 
part because the applicant did not timely respond to an Office action or notice of allowance, if the 
delay was unintentional.  The applicant must file the petition by not  later than:  
(1) Two months after the issue date of the notice of abandonment in full or in part; or  
(2) Two months after the date of actual knowledge of the abandonment and not later than six 
months after the date the trademark electronic records system indicates that the application is 
abandoned in full or in part, where the applicant declares under § 2.20 or 28 U.S.C. 1746 that it did 
not receive the notice of abandonment.  
(b) Petition to Revive Application Abandoned in Full or in Part for Failure to Respond to an Office 
Action.  A petition to revive an application abandoned in full or in part because the applicant did not 
timely respond to an Office action must include:  
(1) The petition fee required by § 2.6 (a)(15);  
(2) A statement, signed by someone with firsthand knowledge of the facts, that the delay in filing 
the response on or before the due date was unintentional; and  
(3) A response to the Office action, signed pursuant to § 2.193(e)(2), or a statement that the 
applicant did not receive the Office action or the notification that an Office action issued.  If the 
applicant asserts that the unintentional delay is based on non-receipt of an Office action or 
notification, the applicant may not assert non-receipt of the same Office action or notification in a 
subsequent petition.   
(4) If the Office action was subject to a three-month response period under § 2.62(a)(1), and the 
applicant does not assert non -receipt of the Office action or notification, the petition must also 
include the fee under § 2.6(a)(28) for a request for extension of time to respond under § 2.62(a)(2). 
(5) If the abandonment was after a final Office action, the response is treated as a request for 
reconsideration under § 2.63(b)(3) and the applicant must also file:  
(i) A notice of appeal to the Trademark Trial and Appeal Board under § 2.141 or a petition to the 
Director under § 2.146, if permitted by § 2.63(b)(2)(iii); or  
(ii) A statement that no appeal or petition is being filed from any final refusal or requirement.  
(c) Petition to Revive Application Abandoned for Failure to Respond to a Notice of Allowance.  
A petition to revive an application abandoned because the applicant did not timely respond to a 
notice of allowance must include:  
(1) The petition fee required by § 2.6;  

 -46- July 15, 2026 
(2) A statement, signed by someone with firsthand knowledge of the facts, that the delay in filing 
the statement of use (or request for extension of time to file a statement of use) on or before the 
due date was unintentional; and one of the following:  
(i) A statement of use under § 2.88, signed pursuant to § 2.193(e)(1), and the required fees for 
the number of requests for extensions of time to file a statement of use that the applicant should 
have filed under § 2.89 if the application had never been ab andoned;  
(ii) A request for an extension of time to file a statement of use under § 2.89, signed pursuant 
to § 2.193(e)(1), and the required fees for the number of requests for extensions of time to file a 
statement of use that the applicant should have filed under § 2.89 if the application had never been 
abandoned;  
(iii) A statement that the applicant did not receive the notice of allowance and a request to cancel 
said notice and issue a new notice.  If the applicant asserts that the unintentional delay in responding 
is based on non-receipt of the notice of allowance, the applicant may not assert non-receipt of the 
notice of allowance in a subsequent petition; or  
(iv) In a multiple-basis application, an amendment, signed pursuant to § 2.193(e)(2), deleting 
the section 1(b) basis and seeking registration based on section 1(a) and/or section 44(e) of the 
Act.   
(3) The applicant must file any further requests for extensions of time to file a statement of use 
under § 2.89 that become due while the petition is pending, or file a statement of use under § 2.88. 
(d) Statement of Use or Petition to Substitute a Basis May Not Be Filed More Than 36 Months 
After Issuance of the Notice of Allowance .  In an application under section 1(b) of the Act, the 
Director will not grant a petition under this section if doing so would permit an applicant to file a 
statement of use, or a petition under § 2.35(b) to substitute a basis, more than 36 months after the 
issue date of the notice of allowance under section 13(b)(2) of the Act.  
(e) Request for Reconsideration.  If the Director denies a petition to revive under this section, 
the applicant may request reconsideration, if:   
(1) The applicant files the request by not later than:  
(i) Two months after the issue date of the decision denying the petition; or  
(ii) Two months after the date of actual knowledge of the decision denying the petition and not 
later than six months after the issue date of the decision where the applicant declares under § 2.20 
or 28 U.S.C. 1746 that it did not receive the decision; and    
(2) The applicant pays a second petition fee under § 2.6.  
[31 FR 5261, Apr. 1, 1966, as amended at 54 FR 37592, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, effective 
Oct. 30, 1999; 68 FR 14332, March 25, 2003, effective May 1, 2003; 68 FR 55748, Sept. 26, 2003, effective 
Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 82 FR 29401, June 29, 2017, effective 
July 8, 2017; 86 FR 64300, Nov. 17, 2021, effective Dec. 1, 2022; 87 FR 62032, Oct. 13, 2022, effective Dec. 
3, 2022] 
§ 2.67  Suspension of action by the Patent and Trademark Office.  
Action by the Office may be suspended for a reasonable time for good and sufficient cause. The 
fact that a proceeding is pending before the Office or a court that is relevant to the issue of initial or 
continued registrability of a mark and that proceeding has not been finally determined, or the fact 
that the basis for registration is, under the provisions of section 44(e) of the Act, registration of the 
mark in a foreign country and the foreign application is still pending, will be considered prima facie 
good and sufficient cause. An Office or court proceeding is not considered finally determined until 
an order or ruling that ends the proceeding or litigation has been rendered and noticed, and the time 
for any appeal or other further review has expired with  no further review sought. An applicant's 
request for a suspension of action under this section, filed within the response period set forth in 
§ 2.62(a), may be considered responsive to the previous Office action. The Office may require the 
applicant, registrant, or party to a proceeding to provide status updates and information relevant to 
the ground(s) for suspension, upon request.  

 -47- July 15, 2026 
[37 FR 3998, Feb. 24, 1972; 68 FR 14332, March 25, 2003, effective May 1, 2003; 86 FR 64300, Nov. 17, 
2021, effective Dec. 18, 2021 ] 
§ 2.68  Express abandonment (withdrawal) of application.  
(a) Written document required.  An applicant may expressly abandon an application by filing a 
written request for abandonment or withdrawal of the application, signed by the applicant, someone 
with legal authority to bind the applicant (e.g., a corporate officer or general partner of a partnership), 
or a practitioner qualified to practice under § 11.14 of this chapter, in accordance with the 
requirements of § 2.193(e)(2).  A request for abandonment or withdrawal may not subsequently be 
withdrawn. 
(b) Rights in the mark not affected.  Except as provided in § 2.135, the fact that an application 
has been expressly abandoned shall not affect any rights that the applicant may have in the mark 
set forth in the abandoned application in any proceeding before the Office.  
[38 FR 7958, Mar. 27, 1973, as amended at 54 FR 34897, Aug. 22, 1989; 74 FR 54898, Oct. 26, 2009, 
effective Dec. 28, 2009 ; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015 ] 
§ 2.69  Compliance with other laws.  
When the sale or transportation of any product for which registration of a trademark is sought is 
regulated under an Act of Congress, the Patent and Trademark Office may make appropriate inquiry 
as to compliance with such Act for the sole purpose of determ ining lawfulness of the commerce 
recited in the application. 
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37592, Sept. 11, 1989]  
AMENDMENT OF APPLICATION 
§ 2.71  Amendments to correct informalities.   
The applicant may amend the application during the course of examination, when required by 
the Office or for other reasons.  
(a) The applicant may amend the application to clarify or limit, but not to broaden, the 
identification of goods and/or services or the description of the nature of the collective membership 
organization. 
(b)(1) If the verified statement in an application under § 2.33 is unsigned or signed by the wrong 
party, the applicant may submit a substitute verification.  
(2) If the verified statement in a statement of use under § 2.88, or a request for extension of time 
to file a statement of use under § 2.89, is unsigned or signed by the wrong party, the applicant must 
submit a substitute verification before the expiration of the statutory deadline for filing the statement 
of use.   
(c) The applicant may amend the dates of use, provided that the amendment is verified, except 
that the following amendments are not permitted:  
(1) In an application under section 1(a) of the Act, the applicant may not amend the application 
to specify a date of use that is subsequent to the filing date of the application;  
(2) In an application under section 1(b) of the Act, after filing a statement of use under § 2.88, 
the applicant may not amend the statement of use to specify a date of use that is subsequent to the 
expiration of the deadline for filing the statement of us e.  
(d) The applicant may amend the application to correct the name of the applicant, if there is a 
mistake in the manner in which the name of the applicant is set out in the application.  The 
amendment must be verified.  However, the application cannot be amended to set forth a different 
entity as the applicant.  An application filed in the name of an entity that did not own the mark as of 
the filing date of the application is void.   

 -48- July 15, 2026 
(e) An amendment that would materially alter the certification statement specified in 
§ 2.45(a)(4)(i)(A) or (a)(4)(ii)(A) will not be permitted.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37592, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.72  Amendments to description or drawing of the mark.  
(a) In an application based on use in commerce under section 1(a) of the Act, the applicant may 
amend the description or drawing of the mark only if:  
(1) The specimens originally filed, or substitute specimens filed under § 2.59(a), support the 
proposed amendment; and 
(2) The proposed amendment does not materially alter the mark.  The Office will determine 
whether a proposed amendment materially alters a mark by comparing the proposed amendment 
with the description or drawing of the mark filed with the original applicat ion.   
(b) In an application based on a bona fide intention to use a mark in commerce under section 
1(b) of the Act, the applicant may amend the description or drawing of the mark only if:  
(1) The specimens filed with an amendment to allege use or statement of use, or substitute 
specimens filed under §  2.59(b), support the proposed amendment; and  
(2) The proposed amendment does not materially alter the mark.  The Office will determine 
whether a proposed amendment materially alters a mark by comparing the proposed amendment 
with the description or drawing of the mark filed with the original applicat ion.    
(c) In an application based on a claim of priority under section 44(d) of the Act, or on a mark 
duly registered in the country of origin of the foreign applicant under section 44(e) of the Act, the 
applicant may amend the description or drawing of the mark only if: 
(1) The description or drawing of the mark in the foreign registration certificate supports the 
amendment; and 
(2) The proposed amendment does not materially alter the mark.  The Office will determine 
whether a proposed amendment materially alters a mark by comparing the proposed amendment 
with the description or drawing of the mark filed with the original applicat ion.   
[48 FR 23134, May 23, 1983, as amended at 54 FR 37593, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999]  
§ 2.73  Amendment to recite concurrent use.  
An application that includes section 1(a) of the Trademark Act as a filing basis, or for which an 
acceptable allegation of use under §  2.76 or §  2.88 has been filed,  may be amended to an 
application for concurrent use registration, provided that the application as amended meets the 
requirements of § 2.42.  The trademark examining attorney will determine whether the application, 
as amended, is acceptable. 
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37593, Sept. 11, 1989; 68 FR 55748, Sept. 26, 2003, 
effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.74  Form and signature of amendment.  
(a) Form of Amendment.  Amendments should be set forth clearly and completely.  Applicant 
should either set forth the entire wording, including the proposed changes, or, if it would be more 
efficient, indicate which words should be added and which words should be deleted.  The examining 
attorney may require the applicant to rewrite the entire amendment, if necessary for clarification of 
the record.  
(b) Signature.  A request for amendment of an application must be signed by the applicant, 
someone with legal authority to bind the applicant (e.g., a corporate officer or general partner of a 

 -49- July 15, 2026 
partnership), or a practitioner qualified to practice under § 11.14 of this chapter, in accordance with 
the requirements of § 2.193(e)(2).  If the amendment requires verification, see §  2.2(n).  
[Amended 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 
28, 2009; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.75  Amendment to change application to different register.  
(a) An application for registration on the Principal Register under section 1(a) or 44 of the Act 
may be changed to an application for registration on the Supplemental Register and vice versa by 
amending the application to comply with the rules relating to the appropriate register, as the case 
may be.   
(b) An application under section 1(b) of the Act may be amended to change the application to a 
different register only after submission of an acceptable amendment to allege use under § 2.76 or 
statement of use under § 2.88.  When such an application is changed from the Principal Register 
to the Supplemental Register, the effective filing date of the application is the date of the filing of the 
allegation of use under section 1(c) or 1(d) of the Act.  
(c) In an application under section 66(a) of the Act, the applicant may not amend the application 
to the Supplemental Register. 
[41 FR 758, Jan. 5, 1976, as amended at 54 FR 37593, Sept. 11, 1989; 68 FR 55748, Sept. 26, 2003, effective 
Nov. 2, 2003] 
§ 2.76  Amendment to allege use.  
(a) When to file an amendment to allege use.  (1) An application under section 1(b) of the Act 
may be amended to allege use of the mark in commerce under section 1(c) of the Act at any time 
between the filing of the application and the date the examiner approves the mark for publication.  
Thereafter, an allegation of use may be submitted only as a statement of use under § 2.88 after the 
issuance of a notice of allowance under section 13(b)(2) of the Act.  An amendment to allege use 
filed outside the time pe riod specified in this paragraph will not be reviewed.  
(2)(i) For a trademark, service mark, collective trademark, collective service mark, and 
certification mark, an amendment to allege use may be filed only when the mark has been in use in 
commerce on or in connection with all the goods or services specified in the application for which 
the applicant will seek registration.  For a collective membership mark, an amendment to allege use 
may be filed only when the mark has been in use in commerce to indicate membership in the 
collective organization specified in the application for which the applicant will seek registration.   
(ii) An amendment to allege use may be accompanied by a request in accordance with § 2.87 
to divide out from the application the goods, services, or classes not yet in use in commerce.  
(b) A complete amendment to allege use.  A complete amendment to allege use must include 
the following:  
(1) A verified statement alleging:  
(i) The applicant believes the applicant is the owner of the mark;  
(ii) The mark is in use in commerce;   
(iii) The date of first use of the mark anywhere on or in connection with the goods or services, 
and/or to indicate membership in the collective organization specified in the application, and the 
date of first use of the mark in commerce.  If the amendment to allege use specifies more than one 
item of goods or services in a class, the dates of use are required for only one item of goods or 
services specified in that class;  
(iv) The goods, services, and/or nature of the collective membership organization specified in 
the application; and  
(v) For a collective mark and certification mark, the applicant is exercising legitimate control over 
the use in commerce of the mark.  

 -50- July 15, 2026 
(2) One specimen showing how the applicant, member, or authorized user uses the mark in 
commerce.  See § 2.56 for the requirements for specimens;  
(3) The fee per class required by § 2.6;  
(4) For a collective mark, the requirements of § 2.44(a)(4)(i)(A);  
(5) For a certification mark, the requirements of § 2.45(a)(4)(i)(A) -(C); and 
(6) The title “Amendment to Allege Use” should appear at the top of the first page of the 
document, if not filed through TEAS.  
(c) Minimum filing requirements for a timely filed amendment to allege use .  The Office will 
review a timely filed amendment to allege use to determine whether it meets the following minimum 
requirements: 
(1) The fee required by § 2.6 for at least one class;  
(2) One specimen of the mark as used in commerce; and  
(3) The verified statement in paragraph (b)(1)(ii) of this section.  
(d) Deficiency notification.  If the amendment to allege use is filed within the permitted time 
period but does not meet the minimum requirements specified in paragraph (c) of this section, the 
Office will notify the applicant of the deficiency.  The deficiency may be corrected provided the mark 
has not been approved for publication.  If an acceptable amendment to correct the deficiency is not 
filed prior to approval of the mark for publication, the amendment will not be examined, and the 
applicant must instead file a statement of use after the notice of allowance issues.  
(e) Notification of refusals and requirements.  A timely filed amendment to allege use that meets 
the minimum requirements specified in paragraph (c) of this section will be examined in accordance 
with §§ 2.61 through 2.69.  If, as a result of the examination of the amendment to allege use, the 
applicant is found not entitled to registration for any reason not previously stated, the applicant will 
be notified and advised of the reasons and of any formal requirements or refusals.  The notification 
shall restate or incorporate by reference all unresolved refusals or requirements previously stated.  
The amendment to allege use may be amended in accordance with §§ 2.59 and 2.71 through 2.75.  
(f) Withdrawal.  An amendment to allege use may be withdrawn for any reason prior to approval 
of a mark for publication.  
(g) Verification not filed within reasonable time.  If the verified statements in paragraphs (b)(1)(ii) 
and, if applicable, (b)(1)(v) of this section are not filed within a reasonable time after they are signed, 
the Office may require the applicant to submit substitute verified statements attesting that the mark 
is in use in commerce, and, if applicable, the applicant is exercising legitimate control over the use 
of the mark in commerce.   
(h) An amendment to allege use is not a response but may include amendments.  The filing of 
an amendment to allege use does not constitute a response to any outstanding action by the 
examiner.  See § 2.62.  The amendment to allege use may include amendments in accordance with 
§§ 2.59 and 2.71 through 2.75.  
(i) If the application is amended to concurrent use under § 2.73, the amendment to allege use 
must include a verified statement modified in accordance with § 2.33(f), § 2.44(d), or § 2.45(d). 
(j) Multiple-class application.  For the requirements of a multiple-class application, see § 2.86. 
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37593, Sept. 11, 1989; 63 FR 48081, Sept. 9, 1998, 
effective Oct. 9, 1998; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 64 FR 51244, Sept. 22, 1999; 73 
FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 77 
FR 30197, May 22, 2012, effective June 21, 2012; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.77  Amendments between notice of allowance and statement of use.  
(a) The only amendments that may be entered in an application between the issuance of the 
notice of allowance and the submission of a statement of use are:   
(1) The deletion of specified goods or services, or the entire description of the nature of the 
collective membership organization, from the identification;   
(2) The deletion of a basis in a multiple -basis application; and  
(3) A change of attorney or change of address.  

 -51- July 15, 2026 
(b) Other amendments may be entered during this period only with the express permission of 
the Director, after consideration on petition under § 2.146.  If the Director determines that the 
amendment requires review by the examining attorney, the petition will be denied and the 
amendment may be resubmitted with the statement of use in order for the applicant to preserve its 
right to review.  
[54 FR 37594, Sept. 11, 1989; as amended 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 80 FR 2303, 
Jan. 16, 2015, effective Feb. 17, 2015 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
PUBLICATION AND POST PUBLICATION  
§ 2.80  Publication for opposition.  
If, on examination or reexamination of an application for registration on the Principal Register, it 
appears that the applicant is entitled to have his mark registered, the mark will be published in the 
Official Gazette for opposition.  The mark will also be published in the case of an application to be 
placed in interference or concurrent use proceedings, if otherwise registrable.  
[41 FR 758, Jan. 5, 1976] 
§ 2.81  Post publication.  
(a) Except in an application under section 1(b) of the Act for which no amendment to allege use 
under § 2.76 has been submitted and accepted, if no opposition is filed within the time permitted or 
all oppositions filed are dismissed, and if no interference  is declared and no concurrent use 
proceeding is instituted, the application will be prepared for issuance of the certificate of registration 
as provided in § 2.151. 
(b) In an application under section 1(b) of the Act for which no amendment to allege use under 
§ 2.76 has been submitted and accepted, if no opposition is filed within the time permitted or all 
oppositions filed are dismissed, and if no interference is declared, a notice of allowance will issue.  
Thereafter, the applicant must submit a statement of use as provided in § 2.88.   
[48 FR 23135, May 23, 1983, as amended at 54 FR 37594, Sept. 11, 1989; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009 ; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015 ] 
§ 2.82  Marks on Supplemental Register published only upon registration.  
In the case of an application for registration on the Supplemental Register the mark will not be 
published for opposition but if it appears, after examination or reexamination, that the applicant is 
entitled to have the mark registered, a  certificate of registration will issue as provided in § 2.151.  
The mark will be published in the  Official Gazette when registered.  
[30 FR 13193, Oct. 16, 1965.  Redesignated at 37 FR 2880, Feb. 9, 1972, as amended at 54 FR 37594, Sept. 
11, 1989] 
§ 2.83  Conflicting marks.  
(a) Whenever an application is made for registration of a mark which so resembles another 
mark or marks pending registration as to be likely to cause confusion or mistake or to deceive, the 
mark with the earliest effective filing date will be published in the Official Gazette for opposition if 
eligible for the Principal Register, or issued a certificate of registration if eligible for the Supplemental 
Register.   
(b) In situations in which conflicting applications have the same effective filing date, the 
application with the earliest date of execution will be published in the Official Gazette for opposition 
or issued on the Supplemental Register.   

 -52- July 15, 2026 
(c) Action on the conflicting application which is not published in the  Official Gazette  for 
opposition or not issued on the Supplemental Register will be suspended by the Examiner of 
Trademarks until the published or issued application is registered or abandoned.  
[37 FR 2880, Feb. 9, 1972, as amended at 54 FR 37594, Sept. 11, 1989]  
§ 2.84  Jurisdiction over published applications.  
(a) The trademark examining attorney may exercise jurisdiction over an application up to the 
date the mark is published in the Official Gazette.  After publication of an application under section 
1(a), 44 or 66(a) of the Act, the trademark examining attorney may, with the permission of the 
Director, exercise jurisdiction over the application.  After publication of an application under section 
1(b) of the Act, the trademark examining attorney may exercise jurisdiction over the application after 
the issuance of the notice of allowance under section 13(b)(2) of the Act.  After publication, and 
prior to issuance of a notice of allowance in an application under section 1(b), the trademark 
examining attorney may, with the permission of the Director, exercise juris diction over the 
application.  
(b) After publication, but before the certificate of registration is issued in an application under 
section 1(a), 44, or 66(a) of the Act, or before the notice of allowance is issued in an application 
under section 1(b) of the Act, an application that is not the subject of an inter partes proceeding 
before the Trademark Trial and Appeal Board may be amended if the amendment meets the 
requirements of §§ 2.71, 2.72, and 2.74.  Otherwise, an amendment to such an application may be 
submitted only upon petition to the Director to restore jurisdiction over the application to the 
examining attorney for consideration of the amendment and further examination.  The amendment 
of an application that is the subject of an inter partes proceeding before the Trademark Trial and 
Appeal Board is governed by § 2.133.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37595, Sept. 11, 1989; 68 FR 14332, March 25, 2003, 
effective May 1, 2003; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009 ; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015 ] 
CLASSIFICATION 
§ 2.85  Classification schedules.  
(a) International classification system.  Section 6.1 of this chapter sets forth the international 
system of classification for goods and services, which applies for all statutory purposes to:   
(1) Applications filed in the Office on or after September 1, 1973, and resulting registrations; and  
(2) Registrations resulting from applications filed on or before August 31, 1973, that have been 
amended to adopt international classification pursuant to § 2.85(e)(3).   
(b) Prior United States classification system.  Section 6.2 of this chapter sets forth the prior 
United States system of classification for goods and services, which applies for all statutory 
purposes to registrations resulting from applications filed on or before August 31, 1973, unless:   
(1) The registration has been amended to adopt international classification pursuant to 
§ 2.85(e)(3); or  
(2) The registration was issued under a classification system prior to that set forth in §  6.2.   
(c) Certification marks and collective membership marks.  Sections 6.3 and 6.4 specify the 
system of classification which applies to certification marks and collective membership marks in 
applications based on sections 1 and 44 of the Act, and to registrations resulting from applications 
based on sections 1 and 44.  These sections do not apply to applications under section 66(a) or to 
registered extensions of protection.   
(d) Section 66(a) applications and registered extensions of protection.  In an application under 
section 66(a) of the Act or registered extension of protection, the classification cannot be changed 
from the classification assigned by the International Bureau of the World Intellectual Property 

 -53- July 15, 2026 
Organization, unless the International Bureau corrects the classification.  Classes cannot be added, 
and goods or services cannot be transferred from one class to another in a multiple -class 
application. 
(e) Changes to Nice Agreement.  The international classification system changes periodically, 
pursuant to the Nice Agreement Concerning the International Classification of Goods and Services 
for the Purposes of the Registration of Marks.  These changes are listed in the International 
Classification of Goods and Services for the Purposes of the Registration of Marks , which is 
published by the World Intellectual Property Organization.   
(1) If international classification changes pursuant to the Nice Agreement, the new classification 
applies only to applications filed on or after the effective date of the change.  
(2) In a section 1 or section 44 application filed before the effective date of a change to the Nice 
Agreement, the applicant may amend the application to comply with the requirements of the current 
edition.  The applicant must comply with the current edition for all goods or services identified in the 
application.  The applicant must pay the fees for any added class(es).  
(3) In a registration resulting from a section 1 or section 44 application that was filed before the 
effective date of a change to the Nice Agreement, the owner may amend the registration to comply 
with the requirements of the current edition.  The owner m ust reclassify all goods or services 
identified in the registration to the current edition.  The owner must pay the fee required by § 2.6 for 
amendments under section 7 of the Act.  The owner may reclassify registrations from multiple 
United States classes (§ 2.85(b)) into a single international classification, where appropriate.   
(f) Classification schedules shall not limit or extend the applicant’s rights, except that in a section 
66(a) application, the scope of the identification of goods or services for purposes of permissible 
amendments (see § 2.71(a)) is limited by the class, pursuant to § 2.85(d). 
[38 FR 14681, June 4, 1973, as amended at 39 FR 16885, May 1 1974; 47 FR 41282, Sept. 17, 1982; 63 FR 
48081, Sept. 9, 1998, effective Oct. 9, 1998; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.86  Multiple -class applications.  
(a) In a single application for a trademark, service mark, and/or collective mark, an applicant 
may apply to register the same mark for goods, services, and/or a collective membership 
organization in multiple classes.  In a multiple -class application, the applicant must satisfy the 
following, in addition to the application requirements of § 2.32 for a trademark or service mark, and 
§ 2.44 for collective marks:  
(1) For an application filed under section 1 or 44 of the Act, identify the goods or services in 
each international class and/or the nature of the collective membership organization in U.S. Class 
200; for applications filed under section 66(a) of the Act, identify the goods, services, and/or the 
nature of the collective membership organization in each international class assigned by the 
International Bureau in the corresponding international registration ;  
(2) Submit the application filing fee required by § 2.6 for each class; and  
(3) Include either dates of use and one specimen for each class based on section 1(a) of the 
Act; or a statement that the applicant has a bona fide intention to use the mark in commerce, for a 
trademark or service mark, or a statement that the applicant ha s a bona fide intention, and is 
entitled, to exercise legitimate control over the use of the mark in commerce, for collective marks, 
for each class based on section 1(b), 44, or 66(a) of the Act.  When requested by the Office, 
additional specimens must be provided. 
(b) In a single application for a certification mark, an applicant may apply to register the same 
certification mark for goods and services.  In such case, the applicant must satisfy the following, in 
addition to the application requirements of § 2.45:  
(1) For an application filed under section 1 or 44 of the Act, identify the goods in U.S. Class A 
and the services in U.S. Class B; for applications filed under section 66(a) of the Act, identify the 
goods and services in each international class assigned by the International Bureau in the 
corresponding international registration ;  
(2) Submit the application filing fee required by § 2.6 for both classes; and  

 -54- July 15, 2026 
(3) Include either dates of use and one specimen for each class based on section 1(a) of the 
Act; or a statement that the applicant has a bona fide intention, and is entitled, to exercise legitimate 
control over the use of the mark in commerce for each class based on section 1(b), 44, or 66(a) of 
the Act.  When requested by the Office, additional specimens must be provided.  
(c) In a single application, both section 1(a) and 1(b) of the Act may not be claimed for identical 
goods or services.  
(d) In a single application based on section 1 or 44 of the Act, goods or services in U.S. Classes 
A and/or B may not be combined with either goods or services in any international class or with a 
collective membership organization in U.S. Class 200; and in a single application based on section 
66(a) of the Act, a certification mark application may not be combined with goods, services, or a 
collective membership organization in any international class.  See § 2.45(f).  
(e) An amendment to allege use under § 2.76 or a statement of use under § 2.88 for multiple 
classes must include, for each class, the required fee, dates of use, and one specimen.  When 
requested by the Office, additional specimens must be provided.  The applicant may not file an 
amendment to allege use or a statement of use until the applicant has used the mark on or in 
connection with all the goods, services, or classes, unless the applicant also files a request to divide 
under § 2.87.  
(f) The Office will issue a single certificate of registration for the mark, unless the applicant files 
a request to divide under § 2.87.  
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37954, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 70 FR 2952, Jan. 19, 2005, effective Jan. 31, 2005; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009; 77 FR 30197, May 22, 2012, effective June 21, 2012; 80 FR 33170, June 11, 2015, 
effective July 11, 2015 ] 
§ 2.87  Dividing an application.   
(a) Application may be divided .  An application may be divided into two or more separate 
applications upon the payment of a fee for each new application created and submission by the 
applicant of a request in accordance with paragraph (d)  of this section.   
(b) Fee.  In the case of a request to divide out one or more entire classes from an application, 
only the fee for dividing an application as set forth in § 2.6(a)(19) will be required.  However, in the 
case of a request to divide out some, but not all, of the goods or services in a class, the applicant 
must submit the application filing fee as set forth in § 2.6(a)(1) for each new separate application to 
be created by the division, in addition to the fee for dividing an application.  
(c) Time for filing.  (1) A request to divide an application may be filed at any time between the 
application filing date and the date on which the trademark examining attorney approves the mark 
for publication; or during an opposition, concurrent use, or interference proceeding, upon motion 
granted by the Trademark Trial and Appeal Board.   
(2) In an application under section 1(b) of the Act, a request to divide may also be filed with a 
statement of use under § 2.88 or at any time between the filing of a statement of use and the date 
on which the trademark examining attorney approves the mark for registration.  
(3) In a multiple-basis application, a request to divide out goods or services having a particular 
basis may also be filed during the period between the issuance of the notice of allowance under 
section 13(b)(2) of the Act and the filing of a statement of use under §  2.88.   
(d) Form.  A request to divide an application should be made in a separate document from any 
other amendment or response in the application.  The title “Request to Divide Application” should 
appear at the top of the first page of the document.  
(e) Outstanding time periods apply to newly created applications.  Any time period for action by 
the applicant which is outstanding in the original application at the time of the division will apply to 
each separate new application created by the division, except as follows:  
(1) If an Office action pertaining to less than all the classes in a multiple -class application is 
outstanding, and the applicant files a request to divide out the goods, services, and/or class(es) to 

 -55- July 15, 2026 
which the Office action does not pertain before the response deadline, a response to the Office 
action is not due in the new (child) application(s) created by the division of the application;   
(2) If an Office action pertaining to less than all the bases in a multiple -basis application is 
outstanding, and the applicant files a request to divide out the goods/services having the basis or 
bases to which the Office action does not pertain before the response deadline, a response to the 
Office action is not due in the new (child) application(s) created by the division of the application; or 
(3) In a multiple-basis application in which a notice of allowance has issued, if the applicant files 
a request to divide out the goods/services having the basis or bases to which the notice of allowance 
does not pertain before the deadline for filing the statement of use, the new (child) applications 
created by the division are not affected by the notice of allowance.   
(f) Signature.  The request to divide must be signed by the applicant, someone with legal 
authority to bind the applicant (e.g., a corporate officer or general partner of a partnership), or a 
practitioner who meets the requirements of §  11.14, in accordance with the requirements of 
§ 2.193(e)(2).  
(g) Section 66(a) applications - change of ownership with respect to some but not all of the 
goods or services .  (1) When the International Bureau of the World Intellectual Property 
Organization notifies the Office that an international registration has been divided as the result of a 
change of ownership with respect to some but not all of the goods or services, t he Office will 
construe the International Bureau’s notice as a request to divide.  The Office will record the partial 
change of ownership in the A ssignment Services Branch, and divide out the assigned 
goods/services from the original (parent) application.  The Office will create a new (child) application 
serial number, and enter the information about the new application in its automated records.   
(2) To obtain a certificate of registration in the name of the new owner for the goods/services 
that have been divided out, the new owner must pay the fee(s) for the request to divide, as required 
by § 2.6 and paragraph (b) of this section.  The examining attorney will issue an Office action in the 
child application requiring the new owner to pay the required fee(s).  If the owner of the child 
application fails to respond, the child application will be abandoned.  It is not necessary for the new 
owner to fi le a separate request to divide.   
(3) The Office will not divide a section 66(a) application based upon a change of ownership 
unless the International Bureau notifies the Office that the international registration has been 
divided.   
[37 FR 3898, Feb. 24, 1972, as amended at 54 FR 37595, Sept. 11, 1989; 57 FR 38190, Aug. 21, 1992; 63 
FR 48081, Sept. 9, 1998, effective Oct. 9, 1998; 70 FR 2952, Jan. 19, 2005, effective Jan. 31, 2005; 73 FR 
67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009]  
POST NOTICE OF ALLOWANCE 
§ 2.88  Statement of use after notice of allowance.  
(a) When to file a statement of use .  (1) In an application under section 1(b) of the Act, a 
statement of use, required under section 1(d) of the Act, must be filed within six months after 
issuance of a notice of allowance under section 13(b)(2) of the Act, or within an extension of time 
granted under §  2.89.  A statement of use filed prior to issuance of a notice of allowance is 
premature and will not be reviewed.  
(2)(i) For a trademark, service mark, collective trademark, collective service mark, and 
certification mark, a statement of use may be filed only when the mark has been in use in commerce 
on or in connection with all the goods or services specified in the notice of allowance for which the 
applicant will seek registration in that application.  For a collective membership mark, a statement 
of use may be filed only when the mark has been in use in commerce to indicate membership in 
the collective membership organization specified in the notice of allowance for which the applicant 
will seek registration in that application. 
(ii) A statement of use may be accompanied by a request in accordance with § 2.87 to divide 
out from the application the goods, services, or classes not yet in use in commerce.  

 -56- July 15, 2026 
(b) A complete statement of use .  A complete statement of use must include the following:  
(1) A verified statement alleging:  
(i) The applicant believes the applicant is the owner of the mark;  
(ii) The mark is in use in commerce;  
(iii) The date of first use of the mark anywhere on or in connection with the goods, services, 
and/or to indicate membership in the collective organization specified in the application, and the 
date of first use of the mark in commerce.  If the statement of use specifies more than one item of 
goods or services in a class, the dates of use are required for only one item of goods or services 
specified in that class; 
(iv) The goods, services, and/or nature of the collective membership organization specified in 
the notice of allowance.  The goods or services specified in a statement of use must conform to 
those goods or services specified in the notice of allowance for trademark, service mark, collective 
trademark, collective service mark, or certification mark applications.  Any goods or services 
specified in the notice of allowance that are omitted from the identification of goods or services in 
the statement of use will be presumed to be deleted and the deleted goods or services may not be 
reinserted in the application.  For collective membership mark applications, the description of the 
nature of the collective membership organization in the statement of use must conf orm to that 
specified in the notice of allowance; and  
(v) For a collective mark and certification mark, the applicant is exercising legitimate control over 
the use in commerce of the mark;  
(2) One specimen showing how the applicant, member, or authorized user uses the mark in 
commerce.  See § 2.56 for the requirements for specimens;  
(3) Fee(s).  The fee required by § 2.6 per class.  The applicant must pay a filing fee sufficient to 
cover at least one class within the statutory time for filing the statement of use, or the application 
will be abandoned.  If the applicant submits a fee insufficient to cover all the classes in a multiple-
class application, the applicant should specify the classes to be abandoned.  If the applicant timely 
submits a fee sufficient to pay for at least one class, but insufficient to cover all the classes, and the 
applicant has not specified the class(es) to be abandoned, the Office will issue a notice granting the 
applicant additional time to submit the fee(s) for the remaining class(es) or to specify the class(es) 
to be abandoned.  If the applicant does not submit the required fee(s) or specify the class(es) to be 
abandoned within the set time period, the Office will apply the fees paid, beginning with the lowest 
numbered class, in ascending order.  The Office will delete the class(es) not covered by the fees 
submitted;  
(4) For a collective mark, the requirements of § 2.44(a)(4)(i)(A);   
(5) For a certification mark, the requirements of § 2.45(a)(4)(i)(A) through (C);  and 
(6) The title “Statement of Use” should appear at the top of the first page of the document, if not 
filed through TEAS.  
(c) Minimum filing requirements for a timely filed statement of use .  The Office will review a 
timely filed statement of use to determine whether it meets the following minimum requirements:  
(1) The fee required by § 2.6 for at least one class;  
(2) One specimen of the mark as used in commerce; and  
(3) The verified statement in paragraph (b)(1)(ii) of this section.  If this verified statement is 
unsigned or signed by the wrong party, the applicant must submit a substitute verified statement on 
or before the statutory deadline for filing the statement  of use.  
(d) Deficiency notification.  If the statement of use is filed within the permitted time period but 
does not meet the minimum requirements specified in paragraph (c) of this section, the Office will 
notify the applicant of the deficiency.  If the time permitted for the applicant to file a statement of use 
has not expired, the applicant may correct the deficiency.  
(e) Notification of refusals and requirements.  A timely filed statement of use that meets the 
minimum requirements specified in paragraph (c) of this section will be examined in accordance 
with §§ 2.61 through 2.69.  If, as a result of the examination of the statement of use, the applicant 
is found not entitled to registration, the applicant will be notified and advised of the reasons and of 

 -57- July 15, 2026 
any formal requirements or refusals.  The statement of use may be amended in accordance with 
§§ 2.59 and 2.71 through 2.75.  
(f) Statement of use may not be withdrawn .  The applicant may not withdraw a timely filed 
statement of use to return to the previous status of awaiting submission of a statement of use, 
regardless of whether it is in compliance with paragraph (c) of this section.  
(g) Verification not filed within reasonable time.  If the verified statements in paragraphs (b)(1)(ii) 
and, if applicable, (b)(1)(v) of this section are not filed within a reasonable time after they are signed, 
the Office may require the applicant to submit substitute verified statements attesting that the mark 
is in use in commerce, and, if applicable, the applicant is exercising legitimate control over the use 
of the mark in commerce.  
(h) Amending the application.  The statement of use may include amendments in accordance 
with §§ 2.51, 2.59, and 2.71 through 2.75.  
(i) Concurrent use. If the application is amended to concurrent use under § 2.73, the statement 
of use must include a verified statement modified in accordance with § 2.33(f),  
§ 2.44(d), or §  2.45(d). 
(j) Multiple-class application.  For the requirements of a multiple-class application, see § 2.86.  
(k) Abandonment.  The failure to timely file a statement of use which meets the minimum 
requirements specified in paragraph (c) of this section shall result in the abandonment of the 
application. 
[54 FR 37595, Sept. 11, 1989; as amended 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 64 FR 51244, 
Sept. 22, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, effective 
Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 77 FR 30197, May 22, 2012, effective 
June 21, 2012; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.89  Extensions of time for filing a statement of use.  
(a) First extension request after issuance of notice of allowance.  The applicant may request a 
six-month extension of time to file the statement of use required by § 2.88.  The extension request 
must be filed within six months of the date of issuance of the notice of allowance under section 
13(b)(2) of the Act and must  include the following:  
(1) A written request for an extension of time to file the statement of use;  
(2) The fee required by § 2.6 per class.  The applicant must pay a filing fee sufficient to cover at 
least one class within the statutory time for filing the extension request, or the request will be denied.  
If the applicant submits a fee insufficient to cover all the classes in a multiple-class application, the 
applicant should specify the classes to be abandoned.  If the applicant timely submits a fee sufficient 
to pay for at least one class, but insufficient to cover all the classes, and the applicant h as not 
specified the class(es) to be abandoned, the Office will issue a notice granting the applicant 
additional time to submit the fee(s) for the remaining classes, or specify the class(es) to be 
abandoned.  If the applicant does not submit the required f ee(s) or specify the class(es) to be 
abandoned within the set time period, the Office will apply the fees paid, beginning with the lowest 
numbered class, in ascending order.  The Office will delete the class(es) not covered by the fees 
submitted; and  
(3) A verified statement that the applicant has a continued bona fide intention to use the mark 
in commerce, specifying the relevant goods or services, for trademarks or service marks; or that the 
applicant has a continued bona fide intention, and is entitled, to exercise legitimate control over the 
use of the mark in commerce, specifying the relevant goods, services, or collective membership 
organization, for collective marks or certification marks.  If this verified statement is unsigned or 
signed by the wrong party, the applicant must submit a substitute verified statement within six 
months of the date of issuance of the notice of allowance.  
(b) Subsequent extension requests.  Before the expiration of the previously granted extension 
of time, the applicant may request further six-month extensions of time to file the statement of use 
by submitting the following:  
(1) A written request for an extension of time to file the statement of use;  

 -58- July 15, 2026 
(2) The requirements of paragraph (a)(2) of this section for a fee;  
(3) A verified statement that the applicant has a continued bona fide intention to use the mark 
in commerce, specifying the relevant goods or services, for trademarks or service marks; or that the 
applicant has a continued bona fide intention, and is entitled, to exercise legitimate control over the 
use of the mark in commerce, specifying the relevant goods, services, or collective membership 
organization, for collective marks or certification marks.  If this verified statement is unsigned or 
signed by the wrong party, the applicant must submit a substitute verified statement before the 
expiration of the previously granted extension; and  
(4) A showing of good cause, as specified in paragraph (d) of this section.  
(c) Four subsequent extension requests permitted.  Extension requests specified in paragraph 
(b) of this section will be granted only in six-month increments and may not aggregate more than 
24 months total.  
(d) Good cause.  A showing of good cause must include:  
(1) For a trademark or service mark, a statement of the applicant’s ongoing efforts to make use 
of the mark in commerce on or in connection with each of the relevant goods or services.  Those 
efforts may include product or service research or development, market research, manufacturing 
activities, promotional activities, steps to acquire distributors, steps to obtain governmental 
approval, or other similar activities.  In the alternative, the applicant must submit a satisfactory 
explanation for the failure to make efforts to use the mark in commerce.  
(2) For a collective mark, a statement of ongoing efforts to make use of the mark in commerce 
by members on or in connection with each of the relevant goods or services or in connection with 
the applicant’s collective membership organization.  Those efforts may include the development of 
standards, the steps taken to acquire members such as marketing and promotional activities 
targeted to potential members, training members regarding the standards, or other similar activities.  
In the alternative, the applicant must submit a satisfactory explanation for the failure to make efforts 
for applicant’s members to use the mark in commerce. 
(3) For a certification mark, a statement of ongoing efforts to make use of the mark in commerce 
by authorized users on or in connection with each of the relevant goods or services.  Those efforts 
may include the development of certification standards, steps taken to obtain governmental 
approval or acquire authorized users, marketing and promoting the recognition of the certification 
program or of the goods or services that meet the certification standards of the applicant, training 
authorized users regarding the standards, or other similar activities.  In the alternative, the applicant 
must submit a satisfactory explanation for the failure to make efforts for applicant’s authorized users 
to use the mark in commerce. 
(e) Extension request filed in conjunction with or after a statement of use.  (1) An applicant may 
file one request for a six-month extension of time for filing a statement of use when filing a statement 
of use or after filing a statement of use if time remains in the existing six-month period in which the 
statement of use was filed, provided that the time requested would not extend beyond 36 months 
from the date of issuance of the notice of allowance.  Thereafter, applicant may not request any 
further exte nsions of time.  
(2) A request for an extension of time that is filed under paragraph (e)(1) of this section, must 
comply with all the requirements of paragraph (a) of this section, if it is an applicant’s first extension 
request, or paragraph (b) of this section, if it is a second or subsequent extension request.  However, 
in a request under paragraph (b) of this section, an applicant may satisfy the requirement for a 
showing of good cause by asserting the applicant believes the applicant has made valid use of the 
mark in commerce, as evidenced by the submitted statement of use, but that if the statement of use 
is found by the Office to be fatally defective, the applicant will need additional time in which to file a 
new statement of use.   
(f) Goods or services.  For trademark, service mark, collective trademark, collective service 
mark, or certification mark applications, the goods or services specified in a request for an extension 
of time for filing a statement of use must conform to those goods or services specified in the notice 
of allowance.  Any goods or services specified in the notice of allowance that are omitted from the 
identification of goods or services in the request for extension of time will be presumed to be deleted 

 -59- July 15, 2026 
and the deleted goods or services may not thereafter be reinserted in the application.  For collective 
membership mark applications, the description of the nature of the collective membership 
organization in the request for extension of time must conform t o that set forth in the notice of 
allowance.  
(g) Notice of grant or denial.  The applicant will be notified of the grant or denial of a request for 
an extension of time, and of the reasons for a denial.  Failure to notify the applicant of the grant or 
denial of the request prior to the expiration of the existing period or requested extension does not 
relieve the applicant of the responsibility of timely filing a statement of use under § 2.88.  If, after 
denial of an extension request, there is time remaining in the existing six-month period for filing a 
statement of use, applicant may submit a substitute request for extension of time to correct the 
defects of the prior request.  Otherwise, the only recourse available after denial of a request for an 
extension of time is to file a petition to the Director in accordance with § 2.66 or § 2.146.  A petition 
from the denial of an extension request must be filed within two months of the date of issuance of 
the denial of the request.  If the petition is granted, the term of the requested six-month extension 
that was the subject of the petition will run from the date of expiration of the previously existing six-
month period for filing a statement of use.  
(h) Verification not filed within reasonable time.  If the verified statement in paragraph (a)(3) or 
(b)(3) of this section is not filed within a reasonable time after it is signed, the Office may require the 
applicant to submit a substitute verified statement attesting that the applicant has a continued bona 
fide intention to use the mark in commerce, for trademarks or service marks; or that the applicant 
has a continued bona fide intention, and is entitled, to exercise legitimate control over the use of the 
mark in commerce, for collective marks or certification marks.   
[54 FR 37595, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 64 FR 51244, Sept. 22, 
1999; 65 FR 36633, June 9, 2000; 68 FR 14332, March 25, 2003, effective May 1, 2003; 73 FR 67759, Nov. 
17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 80 FR 33170, June 
11, 2015, effective July 11, 2015 ] 
EX PARTE EXPUNGEMENT AND REEXAMINATION 
§ 2.91  Petition for expungement or reexamination.  
(a) Petition basis. Any person may file a petition requesting institution of an ex parte proceeding 
to cancel a registration of a mark, in whole or in part, on one of the following bases:  
(1) Expungement, if the mark is registered under sections 1, 44, or 66 of the Act and has never 
been used in commerce on or in connection with some or all of the goods and/or services recited 
in the registration; or  
(2) Reexamination, if the mark is registered under section 1 of the Act and was not in use in 
commerce on or in connection with some or all of the goods and/or services recited in the 
registration on or before the relevant date, which for any particular go ods and/or services is 
determined as follows: 
(i) In an application for registration of a mark with an initial filing basis of section 1(a) of the Act 
for the goods and/or services listed in the petition, and not amended at any point to be filed pursuant 
to section 1(b) of the Act, the relevant date i s the filing date of the application; or  
(ii) In an application for registration of a mark with an initial filing basis or amended basis of 
section 1(b) of the Act for the goods and/or services listed in the petition, the relevant date is the 
later of the filing date of an amendment to allege use identifying the goods and/or services listed in 
the petition, pursuant to section 1(c) of the Act, or the expiration of the deadline for filing a statement 
of use for the goods and/or services listed in the petition, pursuant to section 1(d), including al l 
approved extensions thereof.  
(b) Time for filing.  The petition must be filed while the registration is in force and:  
(1) Where the petition requests institution of an expungement proceeding under paragraph 
(a)(1) of this section, at any time following the expiration of 3 years after the date of registration and, 

 -60- July 15, 2026 
for petitions made after December 27, 2023, before the expiration of 10 years following the date of 
registration; or 
(2) Where the petition requests institution of a reexamination proceeding under paragraph (a)(2) 
of this section, at any time not later than 5 years after the date of registration.  
(c) Requirements for complete submission. Petitions under this section must be timely filed 
through TEAS. Only complete petitions under this section will be considered by the Director under 
§ 2.92, and, once complete, may not be amended by the petitioner. A complete petition must be 
made in writing and must include the following:  
(1) The fee required by § 2.6(a)(26);  
(2) The U.S. trademark registration number of the registration subject to the petition;  
(3) The basis for petition under paragraph (a) of this section;  
(4) The name, domicile address, and email address of the petitioner;  
(5) If the domicile of the petitioner is not located within the United States or its territories, a 
designation of an attorney, as defined in §  11.1 of this chapter, who is qualified to practice under 
§  11.14 of this chapter;  
(6) If the petitioner is, or must be, represented by an attorney, as defined in § 11.1 of this chapter, 
who is qualified to practice under § 11.14 of this chapter, the attorney's name, postal address, email 
address, and bar information under § 2.17(b)(3);  
(7) Identification of each good and/or service recited in the registration for which the petitioner 
requests that the proceeding be instituted on the basis identified in the petition;  
(8) A verified statement signed by someone with firsthand knowledge of the facts to be proved 
that sets forth in numbered paragraphs:  
(i) The elements of the reasonable investigation of nonuse conducted, as defined under 
paragraph (d) of this section, where for each source of information relied upon, the statement 
includes a description of how and when the searches were conducted and what the searches 
disclosed; and 
(ii) A concise factual statement of the relevant basis for the petition, including any additional 
facts that support the allegation of nonuse of the mark in commerce on or in connection with the 
goods and services as specified in paragraph (a) of this section; and  
(9) A clear and legible copy of all documentary evidence supporting a prima facie case of 
nonuse of the mark in commerce and an itemized index of such evidence. Evidence that supports 
a prima facie case of nonuse may include, but is not limited to:  
(i) Verified statements;  
(ii) Excerpts from USPTO electronic records in applications or registrations;  
(iii) Screenshots from relevant web pages, including the uniform resource locator (URL) and 
access or print date; 
(iv) Excerpts from press releases, news articles, journals, magazines, or other publications, 
identifying the publication name and date of publication; and  
(v) Evidence suggesting that the verification accompanying a relevant allegation of use was 
improperly signed. 
(d) Reasonable investigation of nonuse.  A petitioner must make a bona fide attempt to 
determine if the registered mark was not in use in commerce or never in use in commerce on or in 
connection with the goods and/or services specified in paragraph (c)(7) of this section by conducting 
a reasonable investigation. 
(1) A reasonable investigation is an appropriately comprehensive search, which may vary 
depending on the circumstances but is calculated to return information about the underlying inquiry 
from reasonably accessible sources where evidence concerning use of the mark during the relevant 
time period on or in connection with the relevant goods and/or services would normally be found. 
(2) Sources for a reasonable investigation may include, but are not limited to:  
(i) State and Federal trademark records; 
(ii) internet websites and other media likely to or believed to be owned or controlled by the 
registrant; 

 -61- July 15, 2026 
(iii) internet websites, other online media, and publications where the relevant goods and/or 
services likely would be advertised or offered for sale;  
(iv) Print sources and web pages likely to contain reviews or discussion of the relevant goods 
and/or services; 
(v) Records of filings made with or of actions taken by any State or Federal business registration 
or regulatory agency; 
(vi) The registrant's marketplace activities, including, for example, any attempts to contact the 
registrant or purchase the relevant goods and/or services;  
(vii) Records of litigation or administrative proceedings reasonably likely to contain evidence 
bearing on the registrant's use or nonuse of the registered mark; and  
(viii) Any other reasonably accessible source with information establishing nonuse of the mark 
as specified in paragraph (a) of this section.  
(3) A petitioner need not check all possible appropriate sources for its investigation to be 
considered reasonable. 
(e) Director's authority. The authority to act on petitions made under this section is reserved to 
the Director, and may be delegated. 
(f) Oral hearings.  An oral hearing will not be held on a petition except when considered 
necessary by the Director.  
(g) No stay. The mere filing of a petition for expungement or reexamination by itself will not act 
as a stay in any appeal or inter partes proceeding that is pending before the Trademark Trial and 
Appeal Board, nor will it stay the period for replying to an Office action in any pending application 
or registration. 
(h) Real party in interest. The Director may require that the real party or parties in interest be 
identified in connection with any petition filed under this section.  
[86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.92   Institution of ex parte expungement and reexamination proceedings.  
Notwithstanding section 7(b) of the Act, the Director may institute a proceeding for expungement 
or reexamination of a registration of a mark, either upon petition or upon the Director's initiative, 
upon determining that information and evidence supports a prima facie case of nonuse of the mark 
for some or all of the goods or services identified in the registration. The electronic record of the 
registration for which a proceeding has been instituted forms part of the record of the proceeding 
without any action by the Office, a petitioner, or a registrant.   
(a) Institution upon petition. For each good and/or service identified in a complete petition under 
§ 2.91, the Director will determine if the petition sets forth a prima facie case of nonuse to support 
the petition basis and, if so, will institute an ex parte expungement or reexamination proceeding.  
(b) Institution upon the Director's initiative. The Director may institute an ex parte expungement 
or reexamination proceeding on the Director's own initiative, within the time periods set forth in 
§ 2.91(b), and for the reasons set forth in § 2.91(a), based on information that supports a prima facie 
case for expungement or reexamination of a registration for some or all of the goods or services 
identified in the registration.  
(c) Director's authority.  (1) Any determination by the Director whether to institute an 
expungement or reexamination proceeding shall be final and non -reviewable. 
(2) The Director may institute an expungement and/or reexamination proceeding for fewer than 
all of the goods and/or services identified in a petition under § 2.91. The identification of particular 
goods and/or services in a petition does not limit the Dir ector from instituting a proceeding that 
includes additional goods and/or services identified in the subject registration on the Director's own 
initiative, under paragraph (b) of this section.  
(d) Estoppel. (1) Upon termination of an expungement proceeding under § 2.93(c)(3), including 
after any appeal, where it has been determined that the registered mark was used in commerce on 
or in connection with any of the goods and/or services at issue in the proceedings prior to the date 

 -62- July 15, 2026 
a petition to expunge was filed under § 2.91 or the Director-initiated proceedings under this section, 
no further expungement proceedings may be instituted as to those particular goods and/or services. 
(2) Upon termination of a reexamination proceeding under § 2.93(c)(3), including after any 
appeal, where it is has been determined that the registered mark was used in commerce on or in 
connection with any of the goods and/or services at issue, on or before the relevant date established 
in the proceedings, no further expungement or reexamination proceedings may be instituted as to 
those particular goods and/or services.  
(3) With respect to a particular registration, once an expungement proceeding has been 
instituted and is pending, no later expungement proceeding may be instituted with respect to the 
same goods and/or services at issue in the pending proceeding.  
(4) With respect to a particular registration, while a reexamination proceeding is pending, no 
later expungement or reexamination proceeding may be instituted with respect to the same goods 
and/or services at issue in the pending proceeding.  
(e) Consolidated proceedings.  (1) The Director may consolidate expungement and 
reexamination proceedings involving the same registration. Consolidated proceedings will be 
considered related parallel proceedings.  
(2) If two or more petitions under § 2.91 are directed to the same registration and are pending 
concurrently, or the Director wishes to institute an ex parte expungement or reexamination 
proceeding on the Director's own initiative under paragraph (b) of this section concerning a 
registration for which one or more petitions under § 2.91 are pending, t he Director may elect to 
institute a single proceeding.  
(3) Unless barred under paragraph (d) of this section, if any expungement or reexamination 
proceeding is instituted while a prior expungement or reexamination proceeding directed to the 
same registration is pending, the Director may consolidate the proceed ings. 
(f) Notice of Director's determination whether to institute proceedings. (1) In a determination 
based on a petition under § 2.91, if the Director determines that no prima facie case of nonuse has 
been made and thus no proceeding will be instituted, notice of this determination will be provided 
to the registrant and petitioner,  including information to access the petition and supporting 
documents and evidence. 
(2) If the Director determines that a proceeding should be instituted based on a prima facie case 
of nonuse of a registered mark as to any goods and/or services recited in the registration, or 
consolidates proceedings under paragraph (e) of this section, t he Director's determination and 
notice of the institution of the proceeding will be set forth in an Office action under § 2.93(a). If a 
proceeding is instituted based in whole or in part on a petition under § 2.91, the Office action will 
include information to access any petition and the supporting documents and evidence that formed 
the basis for the Director's determination to institute. Notice of the Director's determination will also 
be provided to the petitioner.  
(g) Other mark types. (1) Registrations subject to expungement and reexamination proceedings 
include collective trademarks, collective service marks, and certification marks. 
(2) The use that is the subject of the inquiry in expungement and reexamination proceedings for 
these mark types is defined in § 2.2(k)(2) for collective trademarks and collective service marks, 
and § 2.2(k)(4) for certification marks.  
[86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.93  Expungement and reexamination procedures . 
(a) Office action. An Office action issued to a registrant pursuant to § 2.92(f)(2) will require the 
registrant to provide such evidence of use, information, exhibits, affidavits, or declarations as may 
be reasonably necessary to rebut the prima facie case of nonuse by establishing that the required 
use in commerce has been made on or in connection with the goods and/or services at issue as 
of the date relevant to the proceeding. The Office action may also include requirements under 
§§ 2.11, 2.23, and 2.189, as appropriate.  

 -63- July 15, 2026 
(b) Response— (1) Deadline. Unless the registrant is notified otherwise in an Office action, 
the registrant's response to an Office action must be received by the Office within three months 
from the issue date. The time for response to a non-final Office action may be extended by one 
month upon timely request and payment of the fee set forth in § 2.6(a)(27). To be considered 
timely, a request for extension of time must be received by the Office on or before the deadline 
for response set forth in the non -final Office action. If the registrant fails to timely respond to a 
non-final Office action or timely submit a request for extension of time, the proceeding will 
terminate, and the registration will be cancelled as to the relevant goods and/or services.  
(2) Substantially complete response.  When a timely response is a bona fide attempt to 
advance the proceeding and is a substantially complete response to the outstanding Office action, 
but consideration of some matter or compliance with a requirement has been omitted, the 
registrant may be granted 30 days, or to the end of the time period for response to the action to 
which the substantially complete response was submitted, whichever is longer, to explain and 
supply the omission. 
(3) Signature. The response must be signed by the registrant, someone with legal authority 
to bind the registrant ( e.g., a corporate officer or general partner of a partnership), or a practitioner 
qualified to practice under § 11.14 of this chapter, in accordance with the requirements of 
§ 2.193(e)(2).  
(4) Form. Responses and requests for extensions of time must be submitted through TEAS. 
Responses sent via email or facsimile will not be accorded a date of receipt.  
(5) Response in an expungement proceeding. In an expungement proceeding, an acceptable 
response consists of one or more of the following:  
(i) Evidence of use, in accordance with paragraph (b)(7) of this section, establishing that use 
of the mark in commerce occurred on or in connection with the goods and/or services at issue 
either before the filing date of the relevant petition to expunge u nder § 2.91(a)(1) or before the 
date the Director -initiated proceeding was instituted by the Director under § 2.92(b), as 
appropriate; 
(ii) Verified statements signed by someone with firsthand knowledge of the facts to be proved 
and supporting evidence to establish that any nonuse as to particular goods and/or services with 
a sole basis under section 44(e) or section 66(a) of the Act is due to special circumstances that 
excuse such nonuse; and/or  
(iii) Deletion of some or all of the goods and/or services at issue in the proceeding, if 
appropriate, subject to the provisions of paragraph (d) of this section.  
(6) Response in a reexamination proceeding. In a reexamination proceeding, an acceptable 
response consists of one or more of the following:  
(i) Evidence of use, in accordance with paragraph (b)(7) of this section, establishing that use 
of the mark in commerce occurred on or in connection with each particular good and/or service 
at issue, on or before the relevant date set forth in § 2.91(a)(2) ; and/or 
(ii) Deletion of some or all of the goods and/or services at issue in the proceeding, if 
appropriate, subject to the provisions of paragraph (d) of this section.  
(7) Evidence of use. Evidence of use of the mark in commerce on or in connection with any 
particular good and/or service must be consistent with the definition of “use in commerce” set 
forth in section 45 of the Act and is not limited in form to that of specimens under § 2.56 . Any 
evidence of use must be accompanied by a verified statement signed by someone with firsthand 
knowledge of the facts to be proved, setting forth in numbered paragraphs factual information 
about the use of the mark in commerce, including a description of the supporting evidence and 
how the evidence demonstrates use of the mark in commerce as of any relevant date for the 
goods and/or services at issue. Evidence must be labeled, and an itemized index of the evidence 
must be provided such that the particular goods and/or services supported by each item submitted 
as evidence of use are clear.  
(c) Action after response.  After response by the registrant, the Office will review the 
registrant's evidence of use or showing of applicable excusable nonuse, and/or arguments, and 
determine compliance with any requirement. 

 -64- July 15, 2026 
(1) Final Office action. If the registrant's timely response fails to rebut the prima facie case of 
nonuse or fully comply with all outstanding requirements, a final Office action will issue that 
addresses the evidence,  includes the examiner's decision, and maintains any outstanding 
requirement. After issuance of a final Office action, the registrant may respond by filing within 
three months from the issue date of the final Office action:  
(i) A request for reconsideration of the final Office action that seeks to further address the 
issue of use of the mark in commerce and/or comply with any outstanding requirement maintained 
in the final action; or 
(ii) An appeal to the Trademark Trial and Appeal Board under § 2.141.  
(2) Time for filing a request for reconsideration or petition to the Director.  (i) A request for 
reconsideration must be filed prior to the expiration of time provided for an appeal in § 2.142(a)(2). 
Filing a request for reconsideration does not stay or extend the time for filing an appeal or a 
petition under paragraph (c)(2)(ii) of  this section. 
(ii) Prior to the expiration of time for filing an appeal to the Trademark Trial and Appeal Board 
under § 2.142(a)(2), a registrant may file a petition to the Director under § 2.146 for relief from any 
outstanding requirement under §§ 2.11, 2.23, and 2.189 made final. If the petition is denied, the 
registrant will have 3 months from the date of issuance of the final action that contained the final 
requirement, or 30 days from the date of the decision on the petition, whichever date is later, to 
comply with the requirement. A requirement that is the subject of a petition decided by the Director 
may not subsequently be the subject of an appeal to the Trademark Trial and Appeal Board.  
(3) Termination of proceeding. (i) If, upon review of any timely response, the Office finds that 
the registrant has rebutted the prima facie case of nonuse and complied with all outstanding 
requirements, the proceeding will terminate and a notice of termination shall be issued under 
§ 2.94. 
(ii) If, after issuance of the final action, the registrant fails to timely comply with any outstanding 
requirement, or the Office finds that the registrant has failed to rebut the prima facie case of 
nonuse of the mark on or in connection with any of the goods and/or services at issue in the 
proceeding, the proceeding will terminate, and a notice of termination shall be issued under § 2.94 
after the time for appeal has expired or any appeal proceeding has terminated, pursuant to 
§§ 2.142 through 2.145.  
(d) Deletion of goods and/or services. The registrant may respond to an Office action under 
this section by requesting that some or all of the goods and/or services at issue in the proceeding 
be deleted from the registration. No other amendment to the identification of goods or services in 
a registration will be permitted in a response.  
(1) An acceptable deletion requested in a response under this section shall be immediate in 
effect, and reinsertion of goods and/or services or further amendments that would add to or 
expand the scope of the goods and/or services shall not be permitted. Deletion of goods and/or 
services in an expungement or reexamination proceeding after the submission and prior to the 
acceptance of an affidavit or declaration under section 8 or 71 of the Act will result in a fee under 
§ 2.161(c) or § 7.37(c) of this chapte r. 
(2) A submission other than one made under this section, including a request to surrender the 
subject registration for cancellation under § 2.172 or a request to amend the registration under 
§ 2.173, filed after the issuance of an Office action under this section, does not constitute a 
sufficient response to an Office action under this section. The registrant must notify the Office of 
such submission in a timely response. 
(3) Deletion of goods and/or services at issue in a pending proceeding in a response, a 
surrender for cancellation under § 2.172, an amendment of the registration under § 2.173, or any 
other accepted submission, shall render the proceeding moot as to those goods and/or services, 
and no further determination will be made regarding the registrant's use of the mark in commerce 
as to those goods and/or services.  
[86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 

 -65- July 15, 2026 
§ 2.94  Action after expungement or reexamination . 
Upon termination of an expungement or reexamination proceeding,  the Office shall issue a 
notice of termination that memorializes the final disposition of the proceeding as to each of the 
goods and/or services at issue in the proceeding.  Where appropriate, the registration will be 
cancelled, in whole or in part. 
[86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.96  [Reserved] 
§ 2.98  [Reserved] 
CONCURRENT USE PROCEEDINGS 
§ 2.99  Application to register as concurrent user.  
(a) An application for registration as a lawful concurrent user will be examined in the same 
manner as other applications for registration.  
(b) If it appears that the applicant is entitled to have the mark registered, subject to a concurrent 
use proceeding, the mark will be published in the Official Gazette as provided by §  2.80. 
(c) If no opposition is filed, or if all oppositions that are filed are dismissed or withdrawn, the 
Trademark Trial and Appeal Board will send a notice of institution to the applicant for concurrent 
use registration (plaintiff) and to each applicant, registrant or user specified as a concurrent user in 
the application (defendants). The notice for each defendant shall state the name and address of 
the plaintiff and of the plaintiff’s attorney or other authorized representative, if any, together with 
the serial number and filing date of the application. If a party has provided the Office with an email 
address, the notice may be transmitted via email. 
(d)(1) The Board’s notice of institution will include a web link or web address to access the 
concurrent use application proceeding contained in Office records . 
(2) An answer to the notice is not required in the case of an applicant or registrant whose 
application or registration is acknowledged by the concurrent use applicant in the concurrent use 
application, but a statement, if desired, may be filed within forty days after the issuance of the notice; 
in the case of any other party specified as a concurrent user in the application, an answer must be 
filed within forty days after the issuance of the notice . 
(3) If an answer, when required, is not filed, judgment will be entered precluding the defaulting 
user from claiming any right more extensive than that acknowledged in the application(s) for 
concurrent use registration, but the burden of proving entitlement to registration(s) will remain with 
the concurrent use applicant(s) . 
(e) The applicant for a concurrent use registration has the burden of proving entitlement thereto.  
If there are two or more applications for concurrent use registration involved in a proceeding, the 
party whose application has the latest filing date is the junior party.  A party whose application has 
a filing date between the filing dates of the earliest involved application and the latest involved 
application is a junior party to every party whose involved application has an earlier filing date.  If 
any applications have the same filing date, the application with the latest date of execution will be 
deemed to have the latest filing date and that applicant will be the junior party.  A person specified 
as an excepted user in a concurrent use application but who has not filed an application shall be 
considered a party senior to every party that has an application involved in the proceeding.  
(f) When a concurrent use registration is sought on the basis that a court of competent 
jurisdiction has finally determined that the parties are entitled to use the same or similar marks in 
commerce, a concurrent use registration proceeding will not be ins tituted if all of the following 
conditions are fulfilled:  
(1) The applicant is entitled to registration subject only to the concurrent lawful use of a party to 
the court proceeding; and  

 -66- July 15, 2026 
(2) The court decree specifies the rights of the parties; and  
(3) A true copy of the court decree is submitted to the examining attorney ; and 
(4) The concurrent use application complies fully and exactly with the court decree; and  
(5) The excepted use specified in the concurrent use application does not involve a registration, 
or any involved registration has been restricted by the Director in accordance with the court decree.   
If any of the conditions specified in this paragraph is not satisfied, a concurrent use registration 
proceeding shall be prepared and instituted as provided in paragraphs (a) through (e) of this section. 
(g) Registrations and applications to register on the Supplemental Register and registrations 
under the Act of 1920 are not subject to concurrent use registration proceedings.  Applications under 
section 1(b) of the Act of 1946 are subject to concurrent use registration proceedings only after the 
applicant files an acceptable allegation of use under § 2.76 or § 2.88.  Applications based solely on 
section 44 or section 66(a) of the Act are not subject to concurrent use registration proceedings.  
(h) The Trademark Trial and Appeal Board will consider and determine concurrent use rights 
only in the context of a concurrent use registration proceeding.   
[48 FR 23135, May 23, 1983; 48 FR 27225, June 14, 1983, as amended at 54 FR 37596, Sept. 11, 1989; 68 
FR 14332, March 25, 2003, effective May 1, 2003; 72 FR 42242, Aug. 1, 2007, effective Nov. 1, 2007; 73 FR 
67759, Nov. 17, 2008, effective Jan. 16, 2009; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
OPPOSITION 
§ 2.101  Filing an opposition.  
(a) An opposition proceeding is commenced by filing in the Office a timely notice of opposition 
with the required fee.  
(b) Any person who believes that he, she or it would be damaged by the registration of a mark 
on the Principal Register may file an opposition addressed to the Trademark Trial and Appeal 
Board. The opposition need not be verified, but must be signed by the opposer or the opposer’s 
attorney, as specified in § 11.1 of this chapter, or other authorized representative, as specified in § 
11.14(b) of this chapter. Electronic signatures pursuant to § 2.193(c) are required for oppositions 
filed through ESTTA under paragraph (b)(1) or (2) of this section . 
(1) An opposition to an application must be filed by the due date set forth in paragraph (c) of this 
section through ESTTA . 
(2) In the event that ESTTA is unavailable due to technical problems, or when extraordinary 
circumstances are present, an opposition against an application based on Section 1 or 44 of the 
Act may be filed in paper form. A paper opposition to an application based on Section 1 or 44 of the 
Act must be filed by the due date set forth in paragraph (c) of this section and be accompanied by 
a Petition to the Director under § 2.146, with the fees therefor and the showing required under this 
paragraph. Timeliness of the paper submission will be determined in accordance with §§ 2.195 
through 2.198.  
(3) An opposition to an application based on Section 66(a) of the Act must be filed through 
ESTTA and may not under any circumstances be filed in paper form.  
(c) The opposition must be filed within thirty days after publication (§ 2.80) of the application 
being opposed or within an extension of time (§ 2.102) for filing an opposition. The opposition must 
be accompanied by the required fee for each party joined as opposer for each class in the 
application for which registration is opposed (see §  2.6). 
(d) An otherwise timely opposition cannot be filed via ESTTA unless the opposition is 
accompanied by a fee that is sufficient to pay in full for each named party opposer to oppose the 
registration of a mark in each class specified in the opposition. A paper op position that is not 
accompanied by the required fee sufficient to pay in full for each named party opposer for each 
class in the application for which registration is opposed may not be instituted. If time remains in the 
opposition period as originally set or as extended by the Board, the potential opposer may resubmit 
the opposition with the required fee . 

 -67- July 15, 2026 
(e) The filing date of an opposition is the date of electronic receipt in the Office of the notice of 
opposition and required fee. In the rare instances that filing by paper is permitted under these rules, 
the filing date will be determined in accordance with §§ 2.195 through  2.198. 
[48 FR 3976, Jan. 28, 1983, as amended at 51 FR 28709, Aug. 11, 1986; 54 FR 37596, Sept. 11, 1989; 63 
FR 48081, Sept. 9, 1998, effective Oct. 9, 1998; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 
55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 42242, Aug. 1, 2007, effective Nov. 1, 2007; 73 FR 
47650, Aug 14. 2008, effective Sept. 15, 2008; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 81 FR 
69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.102  Extension of time for filing an opposition.  
(a) Any person who believes that he, she or it would be damaged by the registration of a mark 
on the Principal Register may file a request with the Trademark Trial and Appeal Board to extend 
the time for filing an opposition. The request need not be verified, but must be signed by the potential 
opposer or by the potential opposer's attorney, as specified in § 11.1 of this chapter, or authorized 
representative, as specified in §  11.14(b) of this chapter. Electronic signatures pursuant to § 
2.193(c) are requi red for electronically filed extension requests . 
(1) A request to extend the time for filing an opposition to an application must be filed through 
ESTTA by the opposition due date set forth in § 2.101(c). In the event that ESTTA is unavailable 
due to technical problems, or when extraordinary circumstances are present, a request to extend 
the opposition period for an application based on Section 1 or 44 of the Act may be filed in paper 
form by the opposition due date set forth in § 2.101(c). A request to extend the opposition period 
for an application based on Section 66(a) of the Act must be filed through ESTTA and may not 
under any circumstances be filed in paper form . 
(2) A paper request to extend the opposition period for an application based on Section 1 or 44 
of the Act must be filed by the due date set forth in § 2.101(c) and be accompanied by a Petition to 
the Director under § 2.146, with the fees therefor and the showing required under paragraph (a)(1) 
of this section. Timeliness of the paper submission will be determined in accordance with §§ 2.195 
through 2.198.  
(b) A request to extend the time for filing an opposition must identify the potential opposer with 
reasonable certainty. Any opposition filed during an extension of time must be in the name of the 
person to whom the extension was granted, except that an opposition may be accepted if the person 
in whose name the extension was requested was misidentified through mistake or if the opposition 
is filed in the name of a person in privity with the person who requested and was granted the 
extension of time . 
(c) The time for filing an opposition shall not be extended beyond 180 days from the date of 
publication.  Any request to extend the time for filing an opposition must be filed before thirty days 
have expired from the date of publication or before the expiration of a previously granted extension 
of time, as appropriate.  Requests to extend the time for filing an opposition must be filed as follows: 
(1) A person may file a first request for:  
(i) Either a thirty-day extension of time, which will be granted upon request; or  
(ii) A ninety-day extension of time, which will be granted only for good cause shown. A sixty-day 
extension is not available as a first extension of time to oppose . 
(2) If a person was granted an initial thirty-day extension of time, that person may file a request 
for an additional sixty-day extension of time, which will be granted only for good cause shown .  
(3) After receiving one or two extensions of time totaling ninety days, a person may file one final 
request for an extension of time for an additional sixty days. No other time period will be allowed for 
a final extension of the opposition period. The Board will grant this request only upon written consent 
or stipulation signed by the applicant or its authorized representative, or a written request by the 
potential opposer or its authorized representative stating that the applicant or its authorized 
representative has consented to the request, or a showing of extraordinary circumstances. No 
further extensions of time to file an opposition will be granted under any circumstances . 

 -68- July 15, 2026 
(d) The filing date of a request to extend the time for filing an opposition is the date of electronic 
receipt in the Office of the request. In the rare instance that filing by paper is permitted under these 
rules, the filing date will be determined in accordance with §§ 2.195 through 2.198.  
(e) [Reserved]  
[48 FR 3976, Jan. 28, 1983, as amended at 61 FR 36825, July 15, 1996; 63 FR 48081, Sept. 9, 1998, effective 
Oct. 9, 1998; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective 
Sept. 15, 2008; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 81 FR 69950, Oct. 7, 2016, effective 
January 14, 2017] 
§ 2.103 [Added and Reserved]  
[81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.104  Contents of opposition.  
(a) The opposition must set forth a short and plain statement showing why the opposer believes 
he, she or it would be damaged by the registration of the opposed mark and state the grounds for 
opposition. ESTTA requires the opposer to select relevant grounds for opposition. The required 
accompanying statement supports and explains the grounds.  
(b) Oppositions to different applications owned by the same party may be joined in a 
consolidated opposition when appropriate, but the required fee must be included for each party 
joined as opposer for each class in which registration is opposed in each application against which 
the opposition is filed.  
(c) Oppositions to applications filed under Section 66(a) of the Act are limited to the goods, 
services and grounds set forth in the ESTTA cover sheet.  
[51 FR 28709, Aug. 11, 1986, as amended at 54 FR 34897, Aug. 22, 1989; 68 FR 55748, Sept. 26, 2003, 
effective Nov. 2, 2003 ; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.105  Notification to parties of opposition proceeding(s).  
(a) When an opposition in proper form (see §§ 2.101 and 2.104) has been filed with the correct 
fee(s), and the opposition has been determined to be timely and complete, the Trademark Trial 
and Appeal Board shall prepare a notice of institution, which shall identify the proceeding as an 
opposition, number of the proceeding, and the application(s) involved; and the notice shall 
designate a time, not less than thirty days from the mailing date of the notice, within which an 
answer must be filed. The notice, wh ich will include a web link or web address to access the 
electronic proceeding record, constitutes service of the notice of opposition  to the applicant.  
(b) The Board shall forward a copy of the notice to opposer, as follows : 
(1) If the opposition is transmitted by an attorney, or a written power of attorney is filed, the 
Board will send the notice to the attorney transmitting the opposition or to the attorney designated 
in the power of attorney, provided that the person is an “att orney” as defined in § 11.1 of this 
chapter, at the email or correspondence address for the attorney . 
(2) If opposer is not represented by an attorney in the opposition, but opposer has appointed 
a domestic representative, the Board will send the notice to the domestic representative, at the 
email or correspondence address of record for the domestic representa tive, unless opposer 
designates in writing another correspondence address . 
(3) If opposer is not represented by an attorney in the opposition, and no domestic 
representative has been appointed, the Board will send the notice directly to opposer at the email 
or correspondence address of record for opposer, unless opposer designates in writing another 
correspondence address . 
(c) The Board shall forward a copy of the notice to applicant, as follows : 
(1) If the opposed application contains a clear indication that the application is being 
prosecuted by an attorney, as defined in § 11.1 of this chapter, the Board shall send the notice 

 -69- July 15, 2026 
described in this section to applicant’s attorney at the email or correspondence address of record 
for the attorney .   
(2) If the opposed application is not being prosecuted by an attorney but a domestic 
representative has been appointed, the Board will send the notice described in this section to the 
domestic representative, at the email or correspondence address of record fo r the domestic 
representative, unless applicant designates in writing another correspondence address . 
(3) If the opposed application is not being prosecuted by an attorney, and no domestic 
representative has been appointed, the Board will send the notice described in this section directly 
to applicant, at the email or correspondence address of record for the applicant, unless applicant 
designates in writing another correspondence address .   
[48 FR 23136, May 23, 1983; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 42242, Aug. 1, 
2007, effective Nov. 1, 2007; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 81 FR 69950, Oct. 7, 
2016, effective January 14, 2017 ] 
§ 2.106  Answer. 
(a) If no answer is filed within the time initially set, or as may later be reset by the Board, the 
opposition may be decided as in case of default. The failure to file a timely answer tolls all 
deadlines, including the discovery conference, until the issue of  default is resolved.  
(b)(1) An answer must be filed through ESTTA. In the event that ESTTA is unavailable due to 
technical problems, or when extraordinary circumstances are present, an answer may be filed in 
paper form. An answer filed in paper form must be accompanied by a Petition to the Director under 
§ 2.146, with the fees therefor and the showing required under this paragraph (b).  
(2) An answer shall state in short and plain terms the applicant’s defenses to each claim 
asserted and shall admit or deny the averments upon which the opposer relies. If the applicant is 
without knowledge or information sufficient to form a belief as to the truth of an averment, applicant 
shall so state and this will have the effect of a denial. Denials may take any of the forms specified 
in Rule 8(b) of the Federal Rules of Civil Procedure. An answer may contain any defense, 
including the affirmative defe nses of unclean hands, laches, estoppel, acquiescence, fraud, 
mistake, prior judgment, or any other matter constituting an avoidance or affirmative defense. 
When pleading special matters, the Federal Rules of Civil Procedure shall be followed. A reply to 
an affirmative defense shall not be filed. When a defense attacks the validity of a registration 
pleaded in the opposition, paragraph (b)(3) of this section shall govern. A pleaded registration is 
a registration identified by number by the party in the posi tion of plaintiff in an original notice of 
opposition or in any amendment thereto made under Rule 15 of the Federal Rules of Civil 
Procedure. 
(3)(i) A defense attacking the validity of any one or more of the registrations pleaded in the 
opposition shall be a compulsory counterclaim if grounds for such counterclaim exist at the time 
when the answer is filed. If grounds for a counterclaim are known to the applicant when the answer 
to the opposition is filed, the counterclaim shall be pleaded with or as part of the answer. If grounds 
for a counterclaim are learned during the course of the opposition proceeding, the counterclaim 
shall be pleaded promptly after the grounds therefor are learned. A counterclaim need not be filed 
if the claim is the subject of another proceeding between the same parties or anyone in privity 
therewith; but the applicant must promptly inform the Board, in the context of the  opposition 
proceeding, of the filing of the other proceeding . 
(ii) An attack on the validity of a registration pleaded by an opposer will not be heard unless a 
counterclaim or separate petition is filed to seek the cancellation of such registration.  
(iii) The provisions of §§ 2.111 through 2.115, inclusive, shall be applicable to counterclaims. A 
time, not less than thirty days, will be designated by the Board within which an answer to the 
counterclaim must be filed. 
(iv) The times for pleading, discovery, testimony, briefs or oral argument may be reset or 
extended when necessary, upon motion by a party, or as the Board may deem necessary, to enable 
a party fully to present or meet a counterclaim or separate petition for cancellation of a registration. 

 -70- July 15, 2026 
(c) The opposition may be withdrawn without prejudice before the answer is filed.  After the 
answer is filed, the opposition may not be withdrawn without prejudice except with the written 
consent of the applicant or the applicant’s attorney or other author ized representative.  
[30 FR 13193, Oct. 16, 1965, as amended at 46 FR 6940, Jan. 22, 1981; 48 FR 23136, May 23, 1983; 54 FR 
34897, Aug. 22, 1989; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.107  Amendment of pleadings in an opposition proceeding.  
(a) Pleadings in an opposition proceeding against an application filed under section 1 or 44 of 
the Act may be amended in the same manner and to the same extent as in a civil action in a United 
States district court, except that, after the close of the time period for filing an opposition including 
any extension of time for filing an opposition, an opposition may not be amended to add to the goods 
or services opposed, or to add a joint opposer . 
(b) Pleadings in an opposition proceeding against an application filed under section 66(a) of the 
Act may be amended in the same manner and to the same extent as in a civil action in a United 
States district court, except that, once filed, the opposition may not be amended to add grounds for 
opposition or goods or services beyond those identified in the notice of opposition, or to add a joint 
opposer. The grounds for opposition, the goods or services opposed, and the named opposers are 
limited to those identified in the ESTTA cover sheet regardless of what is contained in any attached 
statement. 
[48 FR 23136, May 1983; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ] 
CANCELLATION PROCEEDINGS BEFORE THE TRADEMARK TRIAL AND APPEAL BOARD 
§ 2.111  Filing petition for cancellation.  
(a) A cancellation proceeding is commenced by filing in the Office a timely petition for 
cancellation with the required fee.   
(b) Any person who believes that he, she, or it is or will be damaged by a registration may file a 
petition, addressed to the Trademark Trial and Appeal Board, for cancellation of the registration in 
whole or in part. The petition for cancellation need not be verified, but must be signed by the 
petitioner or the petitioner's attorney, as specified in § 11.1 of this chapter, or other authorized 
representative, as specified in § 11.14(b) of this chapter. Electronic signatures pursuant to 
§ 2.193(c) are required for petitions submitted electronically via ESTTA. The petition for cancellation 
may be filed at any time in the case of registrations on the Supplemental Register or under the Act 
of 1920, or registrations under the Act of 1881 or the Act of 1905, which have not been published 
under section 12(c) of the Act, on any ground specified in section 14(3) or section 14(5) of the Act, 
or at any time after the three-year period following the date of registration on the ground specified 
in section 14(6) of the Act. In all other cases, including nonuse claims not specified in section 14(6), 
the petition for cancellation and the required fee must be filed within five years from the date of 
registration of the mark under the Act or from the date of publication under section 12(c) of the Act. 
(c)(1) A petition to cancel a registration must be filed through ESTTA . 
(2)(i) In the event that ESTTA is unavailable due to technical problems, or when extraordinary 
circumstances are present, a petition to cancel may be filed in paper form. A paper petition to cancel 
a registration must be accompanied by a Petition to the Director under § 2.146, with the fees therefor 
and the showing required under this paragraph (c). Timeliness of the paper submission, if relevant 
to a ground asserted in the petition to cancel, will be determined in accordance with §§ 2.195 
through 2.198 . 
(ii) For a petition to cancel a registration on the fifth year anniversary of the date of registration 
of the mark, a petitioner for cancellation who meets the requirements of §  2.147(b) may submit a 
petition to the Director to accept a timely filed paper petition to cancel.  

 -71- July 15, 2026 
(d) The petition for cancellation must be accompanied by the required fee for each party joined 
as petitioner for each class in the registration(s) for which cancellation is sought (see § 2.6). A 
petition cannot be filed via ESTTA unless the petition is accompanied by a fee that is sufficient to 
pay in full for each named petitioner to seek cancellation of the registration(s) in each class specified 
in the petition. A petition filed in paper form that is not accompanied by a fee sufficient to pay in full 
for each named petitioner for each class in the registration(s) for which cancellation is sought may 
not be instituted. (e) The filing date of a petition for cancellation is the date of electronic receipt in 
the Office of the petition and required fee. In the rare instances that filing by paper is permitted under 
these rules, the filing date of a petition for cancellation will be determined in accordance with §§ 
2.195 through 2.198.  
[48 FR 3976, Jan. 28, 1983; 54 FR 37596, Sept. 11, 1989; 63 FR 48081, Sept. 9, 1998, effective Oct. 9, 1998; 
64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 
FR 42242, Aug. 1, 2007, effective Nov. 1, 2007; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 74 FR 
54898, Oct. 26, 2009, effective Dec. 28, 2009; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017; 84 FR 
37081, July 31, 2019, effective Feb. 15, 2020 ; 86 FR 64300, Nov. 17, 2021, effe ctive Dec. 18, 2021 ] 
§ 2.112  Contents of petition for cancellation.  
(a) The petition for cancellation must set forth a short and plain statement showing why the 
petitioner believes he, she or it is or will be damaged by the registration, state the ground for 
cancellation, and indicate, to the best of petitioner's knowledge, th e name and address, and a 
current email address(es), of the current owner of the registration. ESTTA requires the petitioner to 
select relevant grounds for petition to cancel. The required accompanying statement supports and 
explains the grounds . 
(b) When appropriate, petitions for cancellation of different registrations owned by the same 
party may be joined in a consolidated petition for cancellation.  The required fee must be included 
for each party joined as a petitioner for each class sought to be cancelled in each registration against 
which the petition for cancellation has been filed. 
[48 FR 3997, Jan. 28, 1983, as amended at 51 FR 28710, Aug. 11, 1986; 54 FR 34897, Aug. 22, 1989; 68 
FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017] 
§ 2.113  Notification of cancellation proceeding.  
(a) When a petition for cancellation in proper form (see §§ 2.111 and 2.112) has been filed and 
the correct fee has been submitted, the Trademark Trial and Appeal Board shall prepare a notice 
of institution which shall identify the proceeding as a cancellation, number of the proceeding and 
the registration(s) involved; and shall designate a time, not less than thirty days from the mailing 
date of the notice, within which an answer must be filed. The notice, which will include a web link or 
web address to access the electronic proceeding record, constitutes service to the registrant of the 
petition to cancel. 
(b) The Board shall forward a copy of the notice to petitioner, as follows:  
(1) If the petition for cancellation is transmitted by an attorney, or a written power of attorney is 
filed, the Board will send the notice to the attorney transmitting the petition for cancellation or to the 
attorney designated in the power of attorney, provided that person is an “attorney” as defined in § 
11.1 of this chapter, to the attorney’s email or correspondence address of record for the attorney. 
(2) If petitioner is not represented by an attorney in the cancellation proceeding, but petitioner 
has appointed a domestic representative, the Board will send the notice to the domestic 
representative, at the email or correspondence address of record for the domestic representative, 
unless petitioner designates in writing another correspondence address . 
(3) If petitioner is not represented by an attorney in the cancellation proceeding, and no domestic 
representative has been appointed, the Board will send the notice directly to petitioner, at the email 
or correspondence address of record for petitioner, unless petitioner designates in writing another 
correspondence address . 

 -72- July 15, 2026 
(c)(1) The Board shall forward a copy of the notice to the party shown by the records of the 
Office to be the current owner of the registration(s) sought to be cancelled at the email or address 
of record for the current owner , except that the Board, in its discretion, may join or substitute as 
respondent a party who makes a showing of a current ownership interest in such registration(s).  
(2) If the respondent has appointed a domestic representative, and such appointment is 
reflected in the Office’s records, the Board will send the notice only to the domestic representative 
at the email or correspondence address of record for the domestic repre sentative.  
(d) When the party alleged by the petitioner, pursuant to § 2.112(a), as the current owner of the 
registration(s) is not the record owner, a courtesy copy of the notice with a web link or web address 
to access the electronic proceeding record shall be forwarded to the alleged current owner. The 
alleged current owner may file a motion to be joined or substituted as respondent . 
[48 FR 23136, May 23, 1983; 48 FR 27225, June 14, 1983, as amended at 54 FR 34897, Aug. 22, 1989; 68 
FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 42242, Aug. 1, 2007, effective Nov. 1, 2007; 73 FR 
47650, Aug 14. 2008, effective Sept. 15, 2008; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.114  Answer. 
(a)(1) If no answer is filed within the time initially set, or as later may be reset by the Board, the 
petition may be decided as in the case of default. The failure to file a timely answer tolls all deadlines, 
including the discovery conference, until the issue of default is resolved.  
(2) If the cancellation proceeding is based solely on abandonment or nonuse and default 
judgment is entered with no appearance by the defendant, and no filings are made other than the 
petition to cancel, $200 per class of the petition to cancel fee may be refu nded. 
(b)(1) An answer must be filed through ESTTA. In the event that ESTTA is unavailable due to 
technical problems, or when extraordinary circumstances are present, an answer may be filed in 
paper form. An answer filed in paper form must be accompanied by a Petition to the Director under 
§ 2.146, with the fees therefor and the showing required under this paragraph (b).  
(2) An answer shall state in short and plain terms the respondent’s defenses to each claim 
asserted and shall admit or deny the averments upon which the petitioner relies. If the respondent 
is without knowledge or information sufficient to form a belief as to the truth of an averment, 
respondent shall so state and this will have the effect of a denial. Denials may take any of the forms 
specified in Rule 8(b) of the Federal Rules of Civil Procedure. An answer may contain any defense, 
including the affirmativ e defenses of unclean hands, laches, estoppel, acquiescence, fraud, 
mistake, prior judgment, or any other matter constituting an avoidance or affirmative defense. When 
pleading special matters, the Federal Rules of Civil Procedure shall be followed. A repl y to an 
affirmative defense shall not be filed. When a defense attacks the validity of a registration pleaded 
in the petition, paragraph (b)(3) of this section shall govern. A pleaded registration is a registration 
identified by number by the party in position of plaintiff in an original petition for cancellation, or a 
counterclaim petition for cancellation, or in any amendment thereto made under Rule 15 of the 
Federal Rules of Civil Procedure . 
(3)(i) A defense attacking the validity of any one or more of the registrations pleaded in the 
petition shall be a compulsory counterclaim if grounds for such counterclaim exist at the time when 
the answer is filed. If grounds for a counterclaim are known to respondent when the answer to the 
petition is filed, the counterclaim shall be pleaded with or as part of the answer. If grounds for a 
counterclaim are learned during the course of the cancellation proceeding, the counterclaim shall 
be pleaded promptly after the grounds therefor are learned. A counterclaim need not be filed if the 
claim is the subject of another proceeding between the same parties or anyone in privity therewith; 
but the party in position of respondent and counterclaim plaintiff must promptly inform the Board, in 
the context of the primary cancellation proceeding, of the filing of the other proceeding . 
(ii) An attack on the validity of a registration pleaded by a petitioner for cancellation will not be 
heard unless a counterclaim or separate petition is filed to seek the cancellation of such registration. 
(iii) The provisions of §§ 2.111 through 2.115, inclusive, shall be applicable to counterclaims. A 
time, not less than thirty days, will be designated by the Board within which an answer to the 

 -73- July 15, 2026 
counterclaim must be filed. Such response period may be reset as necessary by the Board, for a 
time period to be determined by the Board . 
(iv) The times for pleading, discovery, testimony, briefs, or oral argument may be reset or 
extended when necessary, upon motion by a party, or as the Board may deem necessary, to enable 
a party fully to present or meet a counterclaim or separate petition for cancellation of a registration. 
(c) The petition for cancellation or counterclaim petition for cancellation may be withdrawn 
without prejudice before the answer is filed. After the answer is filed, such petition or counterclaim 
petition may not be withdrawn without prejudice except with the written consent of the registrant or 
the registrant’s attorney or other authorized representative . 
[30 FR 13193, Oct. 16, 1965, as amended at 46 FR 6940, Jan. 22, 1981; 46 FR 11548, Feb. 9, 1981; 51 FR 
28710, Aug. 11, 1986; 54 FR 34898, Aug. 22, 1989; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017; 
85 FR 73197, Nov. 17, 2020, effective Jan. 2, 2021 ] 
§ 2.115  Amendment of pleadings in a cancellation proceeding.  
Pleadings in a cancellation proceeding may be amended in the same manner and to the same 
extent as in a civil action in a United States district court. 
[48 FR 23136, May 23, 1983] 
PROCEDURE IN INTER PARTES PROCEEDINGS 
§ 2.116  Federal Rules of Civil Procedure.  
(a) Except as otherwise provided, and wherever applicable and appropriate, procedure and 
practice in inter partes proceedings shall be governed by the Federal Rules of Civil Procedure.  
(b) The opposer in an opposition proceeding or the petitioner in a cancellation proceeding shall 
be in the position of plaintiff, and the applicant in an opposition proceeding or the respondent in a 
cancellation proceeding shall be in the position of defendant.  A party that is a junior party in an 
interference proceeding or in a concurrent use registration proceeding shall be in the position of 
plaintiff against every party that is senior, and the party that is a senior party in an interference 
proceeding or in a concurrent use registration proceeding shall be a defendant against every party 
that is junior. 
(c) The notice of opposition or the petition for cancellation and the answer correspond to the 
complaint and answer in a court proceeding. 
(d) The assignment of testimony periods corresponds to setting a case for trial in court 
proceedings. 
(e) The submission of notices of reliance, declarations and affidavits, as well as the taking of 
depositions, during the assigned testimony periods correspond to the trial in court proceedings. 
(f) Oral hearing, if requested, of arguments on the record and merits corresponds to oral 
summation in court proceedings. 
(g) The Trademark Trial and Appeal Board’s standard protective order is automatically imposed 
in all inter partes proceedings unless the parties, by stipulation approved by the Board, agree to an 
alternative order, or a motion by a party to use an alternative order is granted by the Board. The 
standard protective order is available at the Office’s web site. No material disclosed or produced by 
a party, presented at trial, or filed with the Board, including motions or briefs which discuss such 
material, shall be treated as confidential or shielded from public view unless designated as protected 
under the Board’s standard protective order, or under an alternative order stipulated to by the parties 
and approved by the Board, or under an order submitted by motion of a party granted by the Board. 
The Board may treat as not confidential that material which cannot reasonably be considered 
confidential, notwithstanding a designation as such by a party . 

 -74- July 15, 2026 
[30 FR 13193, Oct. 16, 1965. Redesignated and amended at 37 FR 7606, Apr. 18, 1972, as amended at 48 
FR 23136, May 23, 1983; 72 FR 42242, Aug. 1, 2007, effective Aug. 31, 2007; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ] 
§ 2.117  Suspension of proceedings.  
(a) Whenever it shall come to the attention of the Trademark Trial and Appeal Board that a civil 
action, another Board proceeding, or an expungement or reexamination proceeding may have a 
bearing on a pending case, proceedings before the Board may be suspended until termination of 
the civil action, the other Board proceeding, or the expungement or reexamination proceeding. A 
civil action or proceeding is not considered to have been terminated until an order or ruling that ends 
litigation has been rendered and noticed and the time for any appeal or other further review has 
expired with no further review sought.   
(b) Whenever there is pending before the Board both a motion to suspend and a motion which 
is potentially dispositive of the case, the potentially dispositive motion may be decided before the 
question of suspension is considered regardless of the order in which the motions were filed.  
(c) Proceedings may also be suspended sua sponte by the Board, or, for good cause, upon 
motion or a stipulation of the parties approved by the Board. Many consented or stipulated motions 
to suspend are suitable for automatic approval by ESTTA, but the Board re tains discretion to 
condition approval on the party or parties providing necessary information about the status of 
settlement talks, discovery activities, or trial activities, as may be appropriate. 
[48 FR 23136, May 23, 1983; 63 FR 48081, Sept. 9, 1998, effective Oct. 9, 1998; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.118  Undelivered Office notices.  
When a notice sent by the Office to any registrant or applicant is returned to the Office 
undelivered, including notification to the Office of non-delivery in paper or electronic form, additional 
notice may be given by publication in the Official Gazette . 
[68 FR 14332, March 25, 2003, effective May 1, 2003; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 
72 FR 42242, Aug. 1, 2007, effective Aug. 31, 2007; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017] 
§ 2.119  Service and signing.  
(a) Except for the notice of opposition or the petition to cancel, every submission filed in the 
Office in inter partes cases, including notices of appeal to the courts, must be served upon the other 
party or parties. Proof of such service must be made before the submission will be considered by 
the Office. A statement signed by the attorney or other authorized representative, attached to or 
appearing on the original submission when filed, clearly stating the date and manner in which 
service was made will be accepted as prima facie proof of service . 
(b) Service of submissions filed with the Board and any other papers served on a party not 
required to be filed with the Board, must be on the attorney or other authorized representative of 
the party if there be such or on the party if there is no attorney or other authorized representative, 
and must be made by email, unless otherwise stipulated, or if the serving party can show by written 
explanation accompanying the submission or paper, or in a subsequent amended certificate of 
service, that service by email was attempted but could not be made due to technical problems or 
extraordinary circumstances, then service may be made in any of the following ways :   
(1) By delivering a copy of the submission or paper to the person served ;  
(2) By leaving a copy at the usual place of business of the person served, with someone in the 
person’s employment;  
(3) When the person served has no usual place of business, by leaving a copy at the person’s 
residence, with some person of suitable age and discretion who resides there ;  

 -75- July 15, 2026 
(4) Transmission by the Priority Mail Express® Post Office to Addressee service of the United 
States Postal Service or by first-class mail, which may also be certified or registered;  
(5) Transmission by overnight courier ; or   
(6) Other forms of electronic transmission.  
(c) When service is made by first-class mail, Priority Mail Express®, or overnight courier, the 
date of mailing or of delivery to the overnight courier will be considered the date of service.  
(d) If a party to an inter partes proceeding is not domiciled in the United States and is not 
represented by an attorney or other authorized representative located in the United States, none of 
the parties to the proceeding is eligible to use the service optio n under paragraph (b)(4) of this 
section. The party not domiciled in the United States may designate by submission filed in the Office 
the name and address of a person residing in the United States on whom may be served notices or 
process in the procee ding. If the party has appointed a domestic representative, official 
communications of the Office will be addressed to the domestic representative unless the 
proceeding is being prosecuted by an attorney at law or other qualified person duly authorized under 
§ 11.14(c) of this chapter. If the party has not appointed a domestic representative and the 
proceeding is not being prosecuted by an attorney at law or other qualified person, the Office will 
send correspondence directly to the party, unless the party designates in writing another address 
to which correspondence is to be sent. The mere designation of a domestic representative does not 
authorize the person designated to prosecute the proceeding unless qualified under § 11.14(a) of 
this chapter, or qualif ied under § 11.14(b) of this chapter and authorized under § 2.17(f).  
(e) Every submission filed in an inter partes proceeding, and every request for an extension of 
time to file an opposition, must be signed by the party filing it, or by the party’s attorney or other 
authorized representative, but an unsigned submission will not be refused consideration if a signed 
copy is submitted to the Office within the time limit set in the notification of this defect by the Office. 
[37 FR 7606, Apr. 18, 1972, as amended at 41 FR 760, Jan. 5, 1976; 54 FR 34898, Aug. 22, 1989; 63 FR 
48081, Sept. 9, 1998, effective Oct. 9, 1998; 67 FR 79520, Dec. 30, 2002; 68 FR 14332, March 25, 2003, 
effective May 1, 2003; 72 FR 42242, Aug. 1, 2007, effective Nov. 1, 2007; 73 FR 47650, Aug. 14. 2008, 
effective Sept. 15, 2008; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 79 FR 63036, Oct. 22, 2014; 
81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.120  Discovery. 
(a) In general.  (1) Except as otherwise provided in this section, and wherever appropriate, the 
provisions of the Federal Rules of Civil Procedure relating to disclosure and discovery shall apply 
in opposition, cancellation, interference and concurrent use registration procee dings. The 
provisions of Rule 26 of the Federal Rules of Civil Procedure relating to required disclosures, the 
conference of the parties to discuss settlement and to develop a disclosure and discovery plan, the 
scope, proportionality, timing and sequence of discovery, protective orders, signing of disclosures 
and discovery responses, and supplementation of disclosures and discovery responses, are 
applicable to Board proceedings in modified form, as noted in these rules and as may be detailed 
in any order instituting an inter partes proceeding or subsequent scheduling order. The Board will 
specify the deadline for a discovery conference, the opening and closing dates for the taking of 
discovery, and the deadlines within the discovery period for making initial disclosures and expert 
disclosure. The trial order setting these deadlines and dates will be included within the notice of 
institution of the proceeding . 
(2)(i) The discovery conference shall occur no later than the opening of the discovery period, 
and the parties must discuss the subjects set forth in Rule 26(f) of the Federal Rules of Civil 
Procedure and any subjects set forth in the Board’s institution order. A Board Interlocutory Attorney 
or Administrative Trademark Judge will participate in the conference upon request of any party 
made after answer but no later than ten days prior to the deadline for the conference, or when the 
Board deems it useful for the parties to have Board involvement. The participating attorney or judge 
may expand or reduce the number or nature of subjects to be discussed in the conference as may 
be deemed appropriate. The discovery period will be set for a period of 180 days.  

 -76- July 15, 2026 
(ii) Initial disclosures must be made no later than thirty days after the opening of the discovery 
period.   
(iii) Disclosure of expert testimony must occur in the manner and sequence provided in Rule 
26(a)(2) of the Federal Rules of Civil Procedure, unless alternate directions have been provided by 
the Board in an institution order or any subsequent order resetting di sclosure, discovery or trial 
dates. If the expert is retained after the deadline for disclosure of expert testimony, the party must 
promptly file a motion for leave to use expert testimony. Upon disclosure by any party of plans to 
use expert testimon y, whether before or after the deadline for disclosing expert testimony, the 
Board, either on its own initiative or on notice from either party of the disclosure of expert testimony, 
may issue an order regarding expert discovery and/or set a deadline for any other party to disclose 
plans to use a rebuttal expert.   
(iv) The parties may stipulate to a shortening of the discovery period, that there will be no 
discovery, that the number of discovery requests or depositions be limited, or that reciprocal 
disclosures be used in place of discovery. Limited extensions of the discovery period may be 
granted upon stipulation of the parties approved by the Board, or upon motion granted by the Board, 
or by order of the Board. If a motion for an extension is denied, the discovery period may remain as 
originally set or as reset. Disclosure deadlines and obligations may be modified upon written 
stipulation of the parties approved by the Board, or upon motion granted by the Board, or by order 
of the Board, but the expert disclosure deadline must always be scheduled prior to the close of 
discovery. If a stipulation or motion for modification is denied, discovery disclosure deadlines may 
remain as originally set or reset and obligations may remain unaltered.   
(v) The parties are not required to prepare or transmit to the Board a written report outlining their 
discovery conference discussions, unless the parties have agreed to alter disclosure or discovery 
obligations set forth by these rules or applicable Federal Rules of Civil Procedure, or unless directed 
to file such a report by a participating Board Interlocutory Attorney or Administrative Trademark 
Judge. 
(3) A party must make its initial disclosures prior to seeking discovery, absent modification of 
this requirement by a stipulation of the parties approved by the Board, or a motion granted by the 
Board, or by order of the Board. Discovery depositions must be properly noticed and taken during 
the discovery period. Interrogatories, requests for production of documents and things, and requests 
for admission must be served early enough in the discovery period, as originally set or as may have 
been reset by the Board, so that responses will be due no later than the close of discovery. 
Responses to interrogatories, requests for production of documents and things, and requests for 
admission must be served within thirty days from the date of service of such discovery requests. 
The time to respond may be extended upon stipulation of the parties, or upon motion granted by 
the Board, or by order of the Board, but the response may not be due later than the close of 
discovery. The resetting of a party’s time to respond to an outstanding request for discovery will not 
result in the automatic rescheduling of the discovery and/or testimony periods; such dates will be 
rescheduled only upon stipulation of the parties approved by the Board, or upon motion granted by 
the Board, or by order of the Board.  
(b) Discovery deposition within the United States.  The deposition of a natural person shall be 
taken in the Federal judicial district where the person resides or is regularly employed or at any 
place on which the parties agree in writing. The responsibility rests wholly with the party taking 
discovery to secure the attendance of a proposed deponent other than a party or anyone who, at 
the time set for the taking of the deposition, is an officer, director, or managing agent of a party, or 
a person designated under Rule 30(b)(6) or Rule 31(a) of the Federal Rules of Civil Procedure. 
(See 35 U.S.C. 24.)  
(c) Discovery deposition in foreign countries; or of foreign party within jurisdiction of the United 
States. (1) The discovery deposition of a natural person residing in a foreign country who is a 
party or who, at the time set for the taking of the deposition, is an officer, director, or managing 
agent of a party, or a person designated under Rule 30(b)(6) or Rule 31(a) of the Federal Rules 
of Civil Procedure, shall, if taken in a foreign country, be taken in the manner prescribed by § 

 -77- July 15, 2026 
2.124 unless the Trademark Trial and Appeal Board, upon motion for good cause, orders that the 
deposition be taken by oral examination, or the parties so stipulate . 
(2) Whenever a foreign party is or will be, during a time set for discovery, present within the 
United States or any territory which is under the control and jurisdiction of the United States, such 
party may be deposed by oral examination upon notice by the party seeking discovery.  Whenever 
a foreign party has or will have, during a time set for discovery, an officer, director, managing agent, 
or other person who consents to testify on its behalf, present within the United States or any territory 
which is under the control and jurisdiction of the United States, such officer, director, managing 
agent, or other person who consents to testify in its behalf may be deposed by oral examination 
upon notice by the party seeking discovery.  The party seeking discovery may have one or more 
officers, directors, managing agents, or other persons who consent to testify on behalf of the 
adverse party, designated under Rule 30(b)(6) of the Federal Rules of Civil Procedure.  The 
deposition of a person under this paragraph shall be taken in the Federal judicial district where the 
witness resides or is regularly employed, or, if the witness neither resides nor is regularly employed 
in a Federal judicial district, where the witness is at the time of the deposition.  This paragraph (c)(2) 
does not preclude the taking of a discovery deposition of a foreign party by any other procedure 
provided by paragraph (c)(1) of this section.  
(d) Interrogatories. The total number of written interrogatories which a party may serve upon 
another party pursuant to Rule 33 of the Federal Rules of Civil Procedure, in a proceeding, shall not 
exceed seventy-five, counting subparts, except that the Trademark Trial and Appeal Board, in its 
discretion, may allow additional interrogatories upon motion therefor showing good cause, or upon 
stipulation of the parties, approved by the Board. A motion for leave to serve additional 
interrogatories must be filed a nd granted prior to the service of the proposed additional 
interrogatories and must be accompanied by a copy of the interrogatories, if any, which have 
already been served by the moving party, and by a copy of the interrogatories proposed to be 
served. If a party upon which interrogatories have been served believes that the number of 
interrogatories exceeds the limitation specified in this paragraph (d), and is not willing to waive this 
basis for objection, the party shall, within the time for (and instead of) serving answers and specific 
objections to the interrogatories, serve a general objection on the ground of their excessive number. 
If the inquiring party, in turn, files a motion to compel discovery, the motion must be accompanied 
by a copy of the set(s) of the interrogatories which together are said to exceed the limitation, and 
must otherwise comply with the requirements of paragraph (f) of this section.  
(e) Requests for production. The total number of requests for production which a party may 
serve upon another party pursuant to Rule 34 of the Federal Rules of Civil Procedure, in a 
proceeding, shall not exceed seventy-five, counting subparts, except that the Trademark Trial and 
Appeal Board, in its discretion, may allow additional requests upon motion therefor showing good 
cause, or upon stipulation of the parties, approved by the Board. A motion for leave to serve 
additional requests must be filed and granted prior to the service of the proposed additional requests 
and must be accompanied by a copy of the requests, if any, which have already been served by 
the moving party, and by a copy of the requests proposed to be served. If a party upon which 
requests have been served believes that the number of requests exceeds the limitation specified in 
this paragraph, and is not willing to waive this basis for objection, the party shall, within the time for 
(and instead of) serving responses and specific objections to the requests, serve a general objection 
on the ground of their excessive number. If the inquiring party, in turn, files a motion to compel 
discovery, the motion must be accompanied by a copy of the set(s) of the requests which together 
are said to exceed the limitation, and must otherwise comply with the requirements of paragraph (f) 
of this section. The time, place, and manner for production of documents, electronically stored 
information, and tangible things shall comport with the provisions of Rule 34 of the Federal Rules 
of Civil Procedure, or be made pursuant to agreement of the parties, or where and in the manner 
which the Trademark Trial and Appeal Board, upon motion, orders.  
(f) Motion for an order to compel disclosure or discovery.  (1) If a party fails to make required 
initial disclosures or expert testimony disclosure, or fails to designate a person pursuant to Rule 
30(b)(6) or Rule 31(a) of the Federal Rules of Civil Procedure, or if a party, or such designated 

 -78- July 15, 2026 
person, or an officer, director or managing agent of a party fails to attend a deposition or fails to 
answer any question propounded in a discovery deposition, or any interrogatory, or fails to produce 
and permit the inspection and copying of any document,  electronically stored information, or 
tangible thing, the party entitled to disclosure or seeking discovery may file a motion to compel 
disclosure, a designation, or attendance at a deposition, or an answer, or production and an 
opportunity to inspect and copy. A motion to compel initial disclosures must be filed within thirty 
days after the deadline therefor and include a copy of the disclosure(s), if any, and a motion to 
compel an expert testimony disclosure must be filed prior to the close of the discovery period. A 
motion to compel discovery must be filed before the day of the deadline for pretrial disclosures for 
the first testimony period as originally set or as reset. A motion to compel discovery shall include a 
copy of the request for designation of a witness or of the relevant portion of the discovery deposition; 
or a copy of the interrogatory with any answer or objection that was made; or a copy of the request 
for production, any proffer of production or objection to production in response to the request, and 
a list and brief description of the documents, electronically stored information, or tangible things that 
were not produced for inspection and copying. A motion to compel initial disclosures, expert 
testimony disclosure, or discovery must be supported by a showing from the moving party that such 
party or the attorney therefor has made a good faith effort, by conference or correspondence, to 
resolve with the other party or the attorney therefor the issues presented in the motion but the parties 
were unable to resolve their differences. If issues raised in the motion are subsequently resolved 
by agreement of the parties, the moving party should inform the Board in writing of the issues in the 
motion which no longer require adjudication.  
(2) When a party files a motion for an order to compel initial disclosures, expert testimony 
disclosure, or discovery, the case will be suspended by the Board with respect to all matters not 
germane to the motion. After the motion to compel is filed and served, no party should file any paper 
that is not germane to the motion, except as otherwise specified in the Board’s suspension order. 
Nor may any party serve any additional discovery until the period of suspension is lifted or expires 
by or under order of the Board. The filing of a motion to compel any disclosure or discovery shall 
not toll the time for a party to comply with any disclosure requirement or to respond to any 
outstanding discovery requests or to appear for any noticed discovery deposition. If discovery has 
closed, however, the parties need not make pretrial disclosures until directed to do so by the Board. 
(g) Motion for a protective order.  Upon motion by a party obligated to make initial disclosures 
or expert testimony disclosure or from whom discovery is sought, and for good cause, the 
Trademark Trial and Appeal Board may make any order which justice requires to protect a party 
from annoyance, embarrassment, oppression, or undue burden or expense, including one or more 
of the types of orders provided by clauses (A) through (H), inclusive, of Rule 26(c)(1) of the Federal 
Rules of Civil Procedure. If the motion for a protective order is denied in whole or in part, the Board 
may, on such conditions (other than an award of expenses to the party prevailing on the motion) as 
are just, order that any party comply with disclosure obligations or provide or permit discovery . 
(h) Sanctions.  (1) If a party fails to participate in the required discovery conference, or if a party 
fails to comply with an order of the Trademark Trial and Appeal Board relating to disclosure or 
discovery, including a protective order, the Board may make any appropriate order, including those 
provided in Rule 37(b)(2) of the Federal Rules of Civil Procedure, except that the Board will not hold 
any person in contempt or award expenses to any party.  The Board may impose against a party 
any of the sanctions provided in Rule 37(b)(2) in the event that said party or any attorney, agent, or 
designated witness of that party fails to comply with a protective order made pursuant to Rule 26(c) 
of the Federal Rules of Civil Procedure.  A motion for sanctions against a party for its failure to 
participate in the required discovery conference must be filed prior to the deadline for any party to 
make initial disclosures. 
(2) If a party fails to make required initial disclosures or expert testimony disclosure, and such 
party or the party’s attorney or other authorized representative informs the party or parties entitled 
to receive disclosures that required disclosures will not be made, the Board may make any 
appropriate order, as specified in paragraph (h) of this section.  If a party, or an officer, director, or 
managing agent of a party, or a person designated under Rule 30(b)(6) or 31(a) of the Federal 

 -79- July 15, 2026 
Rules of Civil Procedure to testify on behalf of a party, fails to attend the party’s or person’s discovery 
deposition, after being served with proper notice, or fails to provide any response to a set of 
interrogatories or to a set of requests for production of documents and things, and such party or the 
party’s attorney or other authorized representative informs the party seeking discovery that no 
response will be made thereto, the Board may make any appropriate order, as specified in 
paragraph (h)(1) of this section. 
(i) Requests for admission. The total number of requests for admission which a party may serve 
upon another party pursuant to Rule 36 of the Federal Rules of Civil Procedure, in a proceeding, 
shall not exceed seventy-five, counting subparts, except that the Trademark Trial and Appeal Board, 
in its discretion, may allow additional requests upon motion therefor showing good cause, or upon 
stipulation of the parties, approved by the Board. A motion for leave to serve additional requests 
must be filed and granted prior to the service of the proposed additional requests and must be 
accompanied by a copy of the requests, if any, which have already been served by the moving 
party, and by a copy of the requests proposed to be served . If a party upon which requests for 
admission have been served believes that the number of requests for admission exceeds the 
limitation specified in this paragraph, and is not willing to waive this basis for objection, the party 
shall, within the time for (and instead of) serving answers and specific objections to the requests for 
admission, serve a general objection on the ground of their excessive number. However, 
independent of this limit, a party may make one comprehensive request for admission of any 
adverse party that has produced documents for an admission authenticating specific documents, 
or specifying which of those documents cannot be authenticated . 
(1) Any motion by a party to determine the sufficiency of an answer or objection, including testing 
the sufficiency of a general objection on the ground of excessive number, to a request made by that 
party for an admission must be filed before the day of the deadline for pretrial disclosures for the 
first testimony period, as originally set or as reset. The motion shall include a copy of the request 
for admission and any exhibits thereto and of the answer or objection. The motion must be 
supported by a written statement from the moving party showing that such party or the attorney 
therefor has made a good faith effort, by conference or correspondence, to resolve with the other 
party or the attorney therefor the issues presented in the motion and has been una ble to reach 
agreement. If issues raised in the motion are subsequently resolved by agreement of the parties, 
the moving party should inform the Board in writing of the issues in the motion which no longer 
require adjudication. 
(2) When a party files a motion to determine the sufficiency of an answer or objection to a 
request for an admission, the case will be suspended by the Board with respect to all matters not 
germane to the motion. After the motion is filed and served, no party should file any paper that is 
not germane to the motion, except as otherwise specified in the Board’s suspension order. Nor may 
any party serve any additional discovery until the period of suspension is lifted or expires by or 
under order of the Board. The filing of a motion to determine the sufficiency of an answer or objection 
to a request for admission shall not toll the time for a party to comply with any disclosure requirement 
or to respond to any outstanding discovery requests or to appear for any noticed discovery 
deposition. If discovery has closed, however, the parties need not make pretrial disclosures until 
directed to do so by the Board.  
(j) Telephone and pretrial conferences.  (1) Whenever it appears to the Trademark Trial and 
Appeal Board that a stipulation or motion filed in an inter partes proceeding is of such nature that  a 
telephone conference would be beneficial, the Board may, upon its own initiative or upon request 
made by one or both of the parties, schedule a telephone conference . 
(2) Whenever it appears to the Trademark Trial and Appeal Board that questions or issues 
arising during the interlocutory phase of an inter partes proceeding have become so complex that 
their resolution by correspondence or telephone conference is not practica l and that resolution 
would likely be facilitated by a conference in person of the parties or their attorneys with an 
Administrative Trademark Judge or an Interlocutory Attorney of the Board, the Board may, upon its 
own initiative, direct that the parties and/or their attorneys meet with the Board for a disclosure, 
discovery or pretrial conference on such terms as the Board may order.  

 -80- July 15, 2026 
(3) Parties may not make a recording of the conferences referenced in paragraphs (j)(1) and (2) 
of this section.  
(k) Use of discovery deposition, answer to interrogatory, admission or written disclosure .  
(1) The discovery deposition of a party or of anyone who at the time of taking the deposition was an 
officer, director or managing agent of a party, or a person designated by a party pursuant to Rule 
30(b)(6) or Rule 31(a) of the Federal Rules of Civil Procedure, may be offered in evidence by an 
adverse party. 
(2) Except as provided in paragraph (k)(1) of this section, the discovery deposition of a witness, 
whether or not a party, shall not be offered in evidence unless the person whose deposition was 
taken is, during the testimony period of the party offering the deposition, dead; or out of the United 
States (unless it appears that the absence of the witness was procured by the party offering the 
deposition); or unable to testify because of age, illness, infirmity, or imprisonment; or cannot be 
served with a subpoena to compel attendance at a testimonial deposition; or there is a stipulation 
by the parties; or upon a showing that such exceptional circumstances exist as to make it desirable, 
in the interest of justice, to allow the deposition to be used.  The use of a discovery deposition by 
any party under this paragraph will be allowed only by stipulation of the parties approved by the 
Trademark Trial and Appeal Board, or by order of the Board on motion, which shall be filed when 
the party makes its pretrial disc losures, unless the motion is based upon a claim that such 
exceptional circumstances exist as to make it desirable, in the interest of justice, to allow the 
deposition to be used, even though such deadline has passed, in which case the motion shall be 
filed promptly after the circumstances claimed to justify use of the deposition became known . 
(3)(i) A discovery deposition, an answer to an interrogatory, an admission to a request for 
admission, or a written initial disclosure, which may be offered in evidence under the provisions of 
paragraph (k) of this section, may be made of record in the case by filing the deposition or any part 
thereof with any exhibit to the part that is filed, or a copy of the interrogatory and answer thereto 
with any exhibit made part of the answer, or a copy of the request for admission and any exhibit 
thereto and the admission (or a statement that the party from which an admission was requested 
failed to respond thereto), or a copy of the written initial disclosure, together with a notice of reliance 
in accordance with § 2.122(g). The notice of reliance and the material submitted thereunder should 
be filed during the testimony period of the party that files the notice of reliance. An objection made 
at a discovery deposition by a party answering a question subject to the objection will be considered 
at final hearing. 
(ii) A party that has obtained documents from another party through disclosure or under Rule 
34 of the Federal Rules of Civil Procedure may not make the documents of record by notice of 
reliance alone, except to the extent that they are admissible by notice of reliance under the 
provisions of § 2.122(e), or the party has obtained an admission or stipulation from the producing 
party that authenticates the documents. 
(4) If only part of a discovery deposition is submitted and made part of the record by a party, an 
adverse party may introduce under a notice of reliance any other part of the deposition which should 
in fairness be considered so as to make not misleading what was offered by the submitting party.  
A notice of reliance filed by an adverse party must be supported by a written statement explaining 
why the adverse party needs to rely upon each additional part listed in the adverse party’s notice, 
failing which the Board, in its discretion, may refuse to consider the additional parts.  
(5) Written disclosures, an answer to an interrogatory, or an admission to a request for 
admission, may be submitted and made part of the record only by the receiving or inquiring party 
except that, if fewer than all of the written disclosures, answers to interrogatories, or fewer than all 
of the admissions, are offered in evidence by the receiving or inquiring party, the disclosing or 
responding party may introduce under a notice of reliance any other written disclosures, answers 
to interrogatories, or any other admissions, which should in fairness be considered so as to make 
not misleading what was offered by the receiving or inquiring party.  The notice of reliance filed by 
the disclosing or responding party must be supported by a written statement explaining why the 
disclosing or responding party needs to rely upon each of the additional written disclosures or 

 -81- July 15, 2026 
discovery responses listed in the disclosing or responding party’s notice, and absent such statement 
the Board, in its discretion, may refuse to consider the additional written disclosures or responses. 
(6) Paragraph (k) of this section will not be interpreted to preclude reading or use of written 
disclosures or documents, a discovery deposition, or answer to an interrogatory, or admission as 
part of the examination or cross -examination of any witness during the testimony period of any 
party. 
(7) When a written disclosure, a discovery deposition, or a part thereof, or an answer to an 
interrogatory, or an admission, or an authenticated produced document has been made of record 
by one party in accordance with the provisions of paragraph (k)(3) of this section, it may be referred 
to by any party for any purpose permitted by the Federal Rules of Evidence .     
(8) Written disclosures or disclosed documents, requests for discovery, responses thereto, and 
materials or depositions obtained through the disclosure or discovery process should not be filed 
with the Board, except when submitted with a motion relating to  disclosure or discovery, or in 
support of or in response to a motion for summary judgment, or under a notice of reliance, when 
permitted, during a party’s testimony period.  
[48 FR 23136, May 23, 1983, as amended at 54 FR 34899, Aug. 22, 1989; 54 FR 38041, Sept. 14, 1989; 56 
FR 46376, Sept. 12, 1991; 63 FR 48081, Sept. 9, 1998; 63 FR 52158, Sept. 30, 1998; 72 FR 42242, Aug. 1, 
2007, effective Nov. 1, 2007; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017; 82 FR 33806, July 21, 
2017, effective July 21, 2017 ] 
§ 2.121  Assignment of times for taking testimony and presenting evidence . 
(a) The Trademark Trial and Appeal Board will issue a trial order setting a deadline for each 
party’s required pretrial disclosures and assigning to each party its time for taking testimony and 
presenting evidence (“testimony period”). No testimony shall be taken or evidence presented except 
during the times assigned, unless by stipulation of the parties approved by the Board, or upon 
motion granted by the Board, or by order of the Board. The deadlines for pretrial disclosures and 
the testimony periods may be rescheduled by stipulation of the parties approved by the Board, or 
upon motion granted by the Board, or by order of the Board. If a motion to reschedule any pretrial 
disclosure deadline and/or testimony period is denied, the pretrial disclosure deadline or testimony 
period and any subsequent remaining periods may remain as set. The resetting of the closing date 
for discovery will result in the rescheduling of pretrial disclosure deadlines and testimony periods 
without action by any party. The resetting of a party’s testimony period will result in the rescheduling 
of the remaining pretrial disclosure deadlines without action by any party . 
(b)(1) The Trademark Trial and Appeal Board will schedule a testimony period for the plaintiff to 
present its case in chief, a testimony period for the defendant to present its case and to meet the 
case of the plaintiff, and a testimony period for the plai ntiff to present evidence in rebuttal.  
(2) When there is a counterclaim, or when proceedings have been consolidated and one party 
is in the position of plaintiff in one of the involved proceedings and in the position of defendant in 
another of the involved proceedings, or when there is an inter ference or a concurrent use 
registration proceeding involving more than two parties, the Board will schedule testimony periods 
so that each party in the position of plaintiff will have a period for presenting its case in chief against 
each party in the position of defendant, each party in the position of defendant will have a period for 
presenting its case and meeting the case of each plaintiff, and each party in the position of plaintiff 
will have a period for presenting evidence in rebuttal.  
(c) A testimony period which is solely for rebuttal will be set for fifteen days. All other testimony 
periods will be set for thirty days. The periods may be shortened or extended by stipulation of the 
parties approved by the Trademark Trial and Appeal Board, or may be extended upon motion 
granted by the Board, or by order of the Board. If a motion for an extension is denied, the testimony 
periods and their associated pretrial disclosure deadlines may remain as set. 
(d) When parties stipulate to the rescheduling of a deadline for pretrial disclosures and 
subsequent testimony periods or to the rescheduling of the closing date for discovery and the 
rescheduling of subsequent deadlines for pretrial disclosures and testimony periods, a stipulation 

 -82- July 15, 2026 
presented in the form used in a trial order, signed by the parties, or a motion in said form signed by 
one party and including a statement that every other party has agreed thereto, shall be submitted 
to the Board through ESTTA, with the relevant dates set forth and an express statement that all 
parties agree to the new dates. 
(e) A party need not disclose, prior to its testimony period, any notices of reliance it intends to 
file during its testimony period.  However, no later than fifteen days prior to the opening of each 
testimony period, or on such alternate schedule as may be provided by order of the Board, the party 
scheduled to present evidence must disclose the name and, if not previously provided, the 
telephone number and address of each witness from whom it intends to take testimony, or may take 
testimony if the need arises, general identifying information about the witness, such as relationship 
to any party, including job title if employed by a party, or, if neither a party nor related to a party, 
occupation and job title, a general summary or list of subjects on which the witness is expected to 
testify, and a general summary or list of the types of documents and things which may be introduced 
as exhibits during the testimony of the witness.  The testimony of a witness may be taken upon oral 
examination and transcribed, or presented in the form of an affidavit or declaration, as provided in 
§ 2.123. Pretrial disclosure of a witness under this paragraph (e) does not substitute for issuance 
of a proper notice of examination under § 2.123(c) or § 2.124(b). If a party does not plan to take 
testimony from any witnesses, it must so state in its pretrial disclosure. When a party fails to make 
required pretrial disclosures, any adverse party or parties may have remedy by way of a motion to 
the Board to delay or reset any subsequent pretrial disclosure deadlines and/or testimony periods. 
A party may move to quash a noticed testimony deposition of a witness not identified or improperly 
identified in pretrial disclosures before the deposition.  When testimony has been presented by 
affidavit or declaration, but was not covered by an earlier pretrial disclosure, the remedy for any 
adverse party is the prompt filing of a motion to strike, as provided in §§ 2.123 and 2.124 . 
[48 FR 23138, May 23, 1983; 48 FR 27225, June 14, 1983, as amended at 54 FR 34899, Aug. 22, 1989; 63 
FR 48081, Sept. 9, 1998, effective Oct. 9, 1998; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 
42242, Aug. 1, 2007, effective Nov. 1, 2007 ; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.122  Matters in evidence.  
(a) Applicable rules. Unless the parties otherwise stipulate, the rules of evidence for proceedings 
before the Trademark Trial and Appeal Board are  the Federal Rules of Evidence, the relevant 
provisions of the Federal Rules of Civil Procedure, the relevant provisions of Title 28 of the United 
States Code, and the provisions of this part. When evidence has been made of record by one party 
in accordance with these rules, it may be referred to by any party for any purpose permitted by the 
Federal Rules of Evid ence. 
(b) Application and registration files. (1) The file of each application or registration specified in a 
notice of interference, of each application or registration specified in the notice of a concurrent use 
registration proceeding, of the application against which a notice of opposition is filed, or of each 
registration against which a petition or counterclaim for cancellation is filed forms part of the record 
of the proceeding without any action by the parties and reference may be made to the file for any 
relevant and competent purpose  in accordance with paragraph (b)(2) of this section . 
(2) The allegation in an application for registration, or in a registration, of a date of use is not 
evidence on behalf of the applicant or registrant; a date of use of a mark must be established by 
competent evidence. Specimens in the file of an application f or registration, or in the file of a 
registration, are not evidence on behalf of the applicant or registrant unless identified and introduced 
in evidence as exhibits during the period for the taking of testimony. Statements made in an affidavit 
or declaration in the file of an application for registration, or in the file of a registration, are not 
testimony on behalf of the applicant or registrant. Establishing the truth of these or any other matters 
asserted in the files of these applications and registrations shall be governed by the Federal Rules 
of Evidence, the relevant provisions of the Federal Rules of Civil Procedure, the relevant provisions 
of Title 28 of the United States Code, and the provisions of this part.  

 -83- July 15, 2026 
(c) Exhibits to pleadings.  Except as provided in paragraph (d)(1) of this section, an exhibit 
attached to a pleading is not evidence on behalf of the party to whose pleading the exhibit is 
attached, and must be identified and introduced in evidence as an exhibit during the period for the 
taking of testimony. 
(d) Registrations.  (1) A registration of the opposer or petitioner pleaded in an opposition or 
petition to cancel will be received in evidence and made part of the record if the opposition or petition 
is accompanied by an original or photocopy of the registration prepared and issued by the Office 
showing both the current status of and current title to the registration, or by a current copy of 
information from the electronic database records of the Office showing the current status and title 
of the registration. For the cost of a copy of a registration showing status and title, see § 2.6(b)(4). 
(2) A registration owned by any party to a proceeding may be made of record in the proceeding 
by that party by appropriate identification and introduction during the taking of testimony or by filing 
a notice of reliance in accordance with paragraph (g) of this section, which shall be accompanied 
by a copy (original or photocopy) of the registration prepared and issued by the Office showing both 
the current status of and current title to the registration, or by a current copy of information from the 
electronic database records of the Office showing the current status and title of the registration. The 
notice of reliance shall be filed during the testimony period of the party that files the notice . 
(e) Printed publications and official records .  (1) Printed publications, such as books and 
periodicals, available to the general public in libraries or of general circulation among members of 
the public or that segment of the public which is relevant in a particular proceeding, and official 
records, if the publication or official record is competent evidence and relevant to an issue, may be 
introduced in evidence by filing a notice of reliance on the material being offered in accordance with 
paragraph (g) of this section. The notice of reliance shall specify the printed publication (including 
information sufficient to identify the source and the date of the publication) or the official record and 
the pages to be read; and be accompanied by the official record or a copy thereof whose authenticity 
is established under the Federal Rules of Evidence, or by the printed publication or a copy of the 
relevant portion thereof. A copy of an official record of the Office need not be certified to be offered 
in evidence.   
(2) Internet materials may be admitted into evidence under a notice of reliance in accordance 
with paragraph (g) of this section, in the same manner as a printed publication in general circulation, 
so long as the date the internet materials were accessed and their source (e.g., URL) are provided. 
(f) Testimony from other proceedings.  By order of the Trademark Trial and Appeal Board, on 
motion, testimony taken in another proceeding, or testimony taken in a suit or action in a court, 
between the same parties or those in privity may be used in a proceeding, so far as relevant and 
material, subject, however, to the right of any adverse party to recall or demand the recall for 
examination or cross-examination of any witness whose prior testimony has been offered and to 
rebut the testimony.  
(g) Notices of reliance. The types of evidence admissible by notice of reliance are identified in 
paragraphs (d)(2) and (e)(1) and (2) of this section and § 2.120(k). A notice of reliance shall be filed 
during the testimony period of the party that files the notice. For all evidence offered by notice of 
reliance, the notice must indicate generally the relevance of the evidence and associate it with one 
or more issues in the proceeding. Failure to identify the relevance of the evidence, or associate it 
with issues in the proceeding, with sufficient specificity is a procedural defect that can be cured by 
the offering party within the time set by Board order . 
[48 FR 23138, May 23, 1983, as amended at 54 FR 34899, Aug. 22, 1989; 63 FR 48081, Sept. 9, 1998, 
effective Oct. 9, 1998; 72 FR 42242, Aug. 1, 2007, effective Aug. 31, 2007; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ] 
§ 2.123  Trial testimony in inter partes cases.  
(a)(1) The testimony of witnesses in inter partes cases may be submitted in the form of an 
affidavit or a declaration pursuant to § 2.20 and in conformance with the Federal Rules of Evidence, 
filed during the proffering party’s testimony period, subject to the right of any adverse party to elect 

 -84- July 15, 2026 
to take and bear the expense of oral cross-examination of that witness as provided under paragraph 
(c) of this section if such witness is within the jurisdiction of the United States, or conduct cross-
examination by written questions as provided in § 2.124 if such witness is outside the jurisdiction of 
the United States, and the offering party must make that witness available; or taken by deposition 
upon oral examination as provided by this section ; or by deposition upon written questions as 
provided by § 2.124. . 
(2) Testimony taken in a foreign country shall be taken: by deposition upon written questions as 
provided by § 2.124, unless the Board, upon motion for good cause, orders that the deposition be 
taken by oral examination, or the parties so stipulate; or by affidavit or declaration, subject to the 
right of any adverse party to elect to take and bear the expense of cross -examination by written 
questions of that witness. If a party serves notice of the taking of a testimonial deposition upon 
written questions of a witness who is, or will be at the time of the deposition, present within the 
United States or any territory which is under the control and jurisdiction of the United States, any 
adverse party may, within twenty days from the date of service of the notice, file a motion with the 
Trademark Trial and Appeal Board, for good cause, for an order that the deposition be taken by oral 
examination. 
(b) Stipulations.  If the parties so stipulate in writing, depositions may be taken before any person 
authorized to administer oaths, at any place, upon any notice, and in any manner, and when so 
taken may be used like other depositions.  The parties may stipulate in writing what a particular 
witness would testify to if called ; or any relevant facts in the case may be stipulated in writing. 
(c) Notice of examination of witnesses.  Before the oral depositions of witnesses shall be taken 
by a party, due notice in writing shall be given to the adverse party or parties, as provided in § 
2.119(b), of the time when and place where the depositions will be taken, of the cause or matter in 
which they are to be used, and the name and address of each witness to be examined. Depositions 
may be noticed for any reasonable time and place in the United States. A deposition may not be 
noticed for a place in a foreign country except as provided in paragraph (a)(2) of this section. No 
party shall take depositions in more than one place at the same time, nor so nearly at the same 
time that reasonable opportunity for travel from one place of examination to the other is not 
available. When a party elects to take oral cross-examination of an affiant or declarant, the notice 
of such election must be served on the adverse party and a copy filed with the Board within 20 days 
from the date of service of the affidavit or declaration and completed within 30 days from the date 
of service of the notice of election. Upon motion for good cause by any party, or upon its own 
initiative, the Board may extend the periods for electing and taking oral cross-examination. When 
such election has been made but cannot be completed within that testimony period, the Board, after 
the close of that testimony period, shall suspend or reschedule other proceedings in the matter to 
allow for the orderly completion of the oral cross -examination(s). 
(d) Persons before whom depositions may be taken.  Depositions may be taken before persons 
designated by Rule 28 of the Federal Rules of Civil Procedure.  
(e) Examination of witnesses.  (1) Each witness before providing oral testimony shall be duly 
sworn according to law by the officer before whom the deposition is to be taken . Where oral 
depositions are taken, every adverse party shall have a full opportunity to cross -examine each 
witness. When testimony is proffered by affidavit or declaration, every adverse party will have the 
right to elect oral cross-examination of any witness within the jurisdiction of the United States. For 
examination of witnesses outside the jurisdiction of the United States, see § 2.124 . 
(2) The deposition shall be taken in answer to questions, with the questions and answers 
recorded in their regular order by the officer, or by some other person (who shall be subject to the 
provisions of Rule 28 of the Federal Rules of Civil Procedure) in the presence of the officer except 
when the officer’s presence is waived on the record by agreement of the parties. The testimony 
shall be recorded and transcribed, unless the parties present agree otherwise. Exhibits which are 
marked and identified at the deposition will be deemed to have been offered into evidence, without 
any formal offer thereof, unless the intention of the party marking the exhibits is clearly expressed 
to the contrary. 

 -85- July 15, 2026 
(3)  If pretrial disclosures or the notice of examination of witnesses served pursuant to paragraph 
(c) of this section are improper or inadequate with respect to any witness, an adverse party may 
cross-examine that witness under protest while reserving the right to object to the receipt of the 
testimony in evidence. Promptly after the testimony is completed, the adverse party, to preserve the 
objection, shall move to strike the testimony from the record, which motion will be decided on the 
basis of all the relevant circumstances.  
(i) A motion to strike the testimony of a witness for lack of proper or adequate pretrial disclosure 
may seek exclusion of the entire testimony, when there was no pretrial disclosure, or may seek 
exclusion of that portion of the testimony that was not adeq uately disclosed in accordance with  
§ 2.121(e).  
(ii) A motion to strike the testimony of a witness for lack of proper or adequate notice of 
examination must request the exclusion of the entire testimony of that witness and not only a part 
of that testimony. 
(4) All objections made at the time of an oral examination to the qualifications of the officer taking 
the deposition, or to the manner of taking it, or to the evidence presented, or to the conduct of any 
party, and any other objection to the proceedings, shall be noted by the officer upon the deposition.  
Evidence objected to shall be taken subject to the objections.  
(5) When the oral deposition has been transcribed, the deposition transcript shall be carefully 
read over by the witness or by the officer to the witness, and shall then be signed by the witness in 
the presence of any officer authorized to administer oaths unless the reading and the signature be 
waived on the record by agreement of all parties . 
(f) Certification and filing of deposition.   
(1) The officer shall annex to the deposition his or her certificate showing:  
(i) Due administration of the oath by the officer to the witness before the commencement of his 
or her deposition; 
(ii) The name of the person by whom the deposition was taken down, and whether, if not taken 
down by the officer, it was taken down in his presence;  
(iii) The presence or absence of the adverse party;  
(iv) The place, day, and hour of commencing and taking the deposition;  
(v) The fact that the officer was not disqualified as specified in Rule 28 of the Federal Rules of 
Civil Procedure. 
(2) If any of the foregoing requirements in paragraph (f)(1) of this section are waived, the 
certificate shall so state. The officer shall sign the certificate and affix thereto his or her seal of office, 
if he or she has such a seal. The party taking the deposition, or its attorney or other authorized 
representative, shall then promptly file the transcript and exhibits in electronic form using ESTTA. If 
the nature of an exhibit precludes electronic transmission via ESTTA, it shall be submitted by mail 
by the party taking the deposition, or its attorney or other authorized representative . 
(g) Form of deposition.  (1) The pages of each deposition must be numbered consecutively, and 
the name of the witness plainly and conspicuously written at the top of each page.  A deposition 
must be in written form.  The questions propounded to each witness must be consecutivel y 
numbered unless the pages have numbered lines.  Each question must be followed by its answer. 
The deposition transcript must be submitted in full-sized format (one page per sheet), not condensed 
(multiple pages per sheet).   
(2) Exhibits must be numbered or lettered consecutively and each must be marked with the 
number and title of the case and the name of the party offering the exhibit.  Entry and consideration 
may be refused to improperly marked exhibits.  
(3) Each deposition must contain a word index and an index of the names of the witnesses, 
giving the pages where the words appear in the deposition and where witness examination and 
cross-examination begin, and an index of the exhibits, briefly describing their nature and giving the 
pages at which they are introduced and offered in evidence . 
(h) Depositions must be filed.  All depositions which are taken must be duly filed in the Office. 
On refusal to file, the Office at its discretion will not further hear or consider the contestant with 

 -86- July 15, 2026 
whom the refusal lies; and the Office may, at its discretion, receive and consider a copy of the 
withheld deposition, attested by such evidence as is procurable.  
(i) Effect of errors and irregularities in depositions. Rule 32(d)(1), (2), and (3)(A) and (B) of the 
Federal Rules of Civil Procedure shall apply to errors and irregularities in depositions.  Notice will 
not be taken of merely formal or technical objections which shall not appear to have wrought a 
substantial injury to the party raising them; and in case of such injury it must be made to appear that 
the objection was raised at the time specified in said rule.  
(j) Objections to admissibility. Subject to the provisions of paragraph (i) of this section, objection 
may be made to receiving in evidence any declaration, affidavit,  or deposition, or part thereof, or 
any other evidence, for any reason which would require the exclusion of the evidence from 
consideration. Objections to the competency of a witness or to the competency, relevancy, or 
materiality of testimony must be raised at the time specified in Rule 32(d)(3)(A) of the Federal Rules 
of Civil Procedure.  Such objections may not be considered until final hearing . 
(k) Evidence not considered.  Evidence not obtained and filed in compliance with these sections 
will not be considered.  
[27 FR 7606, Apr. 18, 1972, as amended at 41 FR 760, Jan. 5 1976; 48 FR 23139, May 23, 1983; 54 FR 
34899, Aug. 22, 1989; 63 FR 48081, Sept. 9, 1998, effective Oct. 9, 1998; 68 FR 14332, March 25, 2003, 
effective May 1, 2003; 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 68 FR 55748, Sept. 26, 2003, 
effective Nov. 2, 2003; 72 FR 42242, Aug. 1, 2007, effective Nov. 1, 2007; 81 FR 69950, Oct. 7, 2016, effective 
January 14, 2017] 
§ 2.124  Depositions upon written questions.  
(a) A deposition upon written questions may be taken before any person before whom 
depositions may be taken as provided by Rule 28 of the Federal Rules of Civil Procedure.  
(b)(1) A party desiring to take a testimonial deposition upon written questions shall serve notice 
thereof upon each adverse party within ten days from the opening date of the testimony period of 
the party who serves the notice.  The notice shall state the name and address of the witness.  A 
copy of the notice, but not copies of the questions, shall be filed with the Trademark Trial and Appeal 
Board. 
(2) A party desiring to take a discovery deposition upon written questions shall serve notice 
thereof upon each adverse party and shall file a copy of the notice, but not copies of the questions, 
with the Board.  The notice shall state the name and address , if known, of the person whose 
deposition is to be taken.  If the name of the person is not known, a general description sufficient to 
identify the witness or the particular class or group to which he or she belongs shall be stated in the 
notice, and the party from whom the discovery deposition is to be taken shall designate one or more 
persons to be deposed in the same manner as is provided by Rule 30(b)(6) of the Federal Rules of 
Civil Procedure. 
(3) A party desiring to take cross -examination, by written questions, of a witness who has 
provided testimony by affidavit or declaration shall serve notice thereof upon each adverse party 
and shall file a copy of the notice, but not copies of the question s, with the Board. 
(c) Every notice given under the provisions of paragraph (b) of this section shall be accompanied 
by the name or descriptive title of the officer before whom the deposition is to be taken.  
(d)(1) Every notice served on any adverse party under the provisions of paragraphs (b)(1) and 
(2) of this section, for the taking of direct examination, shall be accompanied by the written questions 
to be propounded on behalf of the party who proposes to take the deposition. Every notice served 
on any adverse party under the provisions of paragraph (b)(3) of this section, for the taking of cross-
examination, shall be accompanied by the written questions to be propounded on behalf of the party 
who proposes to take the cross-examination. Within twenty days from the date of service of the 
notice of taking direct examination or service of a testimony affidavit or declaration, any adverse 
party may serve cross questions upon the party who proposes to take the deposition. Any party 
who serves cross questions , whether in response to direct examination questions or under 
paragraph (b)(3) of this section, shall also serve every other adverse party. Within ten days from 

 -87- July 15, 2026 
the date of service of the cross questions, the party who proposes to take the deposition, or who 
earlier offered testimony of the witness by affidavit or declaration, may serve redirect questions on 
every adverse party. Within ten days from the date of service of the redirect questions, any party 
who served cross questions may serve recross questions upon the party who proposes to take the 
deposition or who earlier offered testimony of the witness by affidavit or declaration; any party who 
serves recross questions shall also serve every other adverse party. Written objections to questions 
may be served on a party propounding questions; any party who objects shall serve a copy of the 
objections on every other adverse party. In response to objections, substitute questions may be 
served on the objecting party within ten days of the date of service of the objections; substitute 
questions shall be served on every other adverse party . 
(2) Upon motion for good cause by any party, or upon its own initiative, the Trademark Trial and 
Appeal Board may extend any of the time periods provided by paragraph (d)(1) of this section.  
Upon receipt of written notice that one or more testimonial depositions are to be taken upon written 
questions, the Trademark Trial and Appeal Board shall suspend or reschedule other proceedings 
in the matter to allow for the orderly completion of the depositions upon written questions.  
(3) Service of written questions, responses, and cross -examination questions shall be in 
accordance with § 2.119(b).  
(e) Within ten days after the last date when questions, objections, or substitute questions may 
be served, the party who proposes to take the deposition shall mail a copy of the notice and copies 
of all the questions to the officer designated in the notice; a copy of the notice and of all the questions 
mailed to the officer shall be served on every adverse party.  The officer designated in the notice 
shall take the testimony of the witness in response to the questions and shall record each answer 
immediately after the corresponding question.  The officer shall then certify the transcript and mail 
the transcript and exhibits to the party who took the deposition.  
(f) The party who took the deposition shall promptly serve a copy of the transcript, copies of 
documentary exhibits, and duplicates or photographs of physical exhibits on every adverse party.  
It is the responsibility of the party who takes the deposition to assure that the transcript is correct 
(see § 2.125(c)).  If the deposition is a discovery deposition, it may be made of record as provided 
by § 2.120(k).  If the deposition is a testimonial deposition, the original, together with copies of 
documentary exhibits and duplicates or photographs of physical exhibits, shall be filed promptly with 
the Trademark Trial and Appeal Board. 
(g) Objections to questions and answers in depositions upon written questions may be 
considered at final hearing.  
[48 FR 23139, May 23, 1983; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.125  Filing and service of testimony.  
(a) One copy of the declaration or affidavit prepared in accordance with § 2.123, together with 
copies of documentary exhibits and duplicates or photographs of physical exhibits, shall be served 
on each adverse party at the time the declaration or affidavit is submitted to the Trademark Trial 
and Appeal Board during the assigned testimony period.  
(b) One copy of the transcript of each testimony deposition taken in accordance with § 2.123 or 
§ 2.124, together with copies of documentary exhibits and duplicates or photographs of physical 
exhibits, shall be served on each adverse party within thirty days after completion of the taking of 
that testimony.  If the transcript with exhibits is not served on each adverse party within thirty days 
or within an extension of time for the purpose, any adverse party which was not served may have 
remedy by way of a motion to the Trademark Trial and Appeal Board to reset such adverse party’s 
testimony and/or briefing periods, as may be appropriate.  If the deposing party fails to serve a copy 
of the transcript with exhibits on an adverse party after having been ordered to do so by the Board, 
the Board, in its discretion, may strike the deposition, or enter judgment as by default against the 
deposing party, or take any such other action as may be deemed appropriate.  
(c) The party who takes testimony is responsible for having all typographical errors in the 
transcript and all errors of arrangement, indexing and form of the transcript corrected, on notice to 

 -88- July 15, 2026 
each adverse party, prior to the filing of one certified transcript with the Trademark Trial and Appeal 
Board.  The party who takes testimony is responsible for serving on each adverse party one copy 
of the corrected transcript or, if reasonably feasible, corrected pages to be inserted into the transcript 
previously served.  
(d) One certified transcript and exhibits shall be filed with the Trademark Trial and Appeal Board. 
Notice of such filing shall be served on each adverse party and a copy of each notice shall be filed 
with the Board. 
(e) Each transcript shall comply with § 2.123(g) with respect to arrangement, indexing and form. 
(f) Upon motion by any party, for good cause, the Trademark Trial and Appeal Board may order 
that any part of an affidavit or declaration or a deposition transcript or any exhibits that directly 
disclose any trade secret or other confidential research, development, or commercial information 
may be filed under seal and kept confidential under the provisions of § 2.27(e). If any party or any 
attorney or agent of a party fails to comply with an order made under this paragraph, the Board may 
impose any of the sanctions authorized by § 2.120(h ). 
[48 FR 23410, May 23, 1983, as amended at 54 FR 34900, Aug. 22, 1989; 63 FR 48081, Sept. 9, 1998, 
effective Oct. 9, 1998 ; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.126  Form of submissions to the Trademark Trial and Appeal Board.  
(a) Submissions must be made to the Trademark Trial and Appeal Board via ESTTA.  
(1) Text in an electronic submission must be filed in at least 11-point type and double-spaced. 
(2) Exhibits pertaining to an electronic submission must be made electronically as an attachment 
to the submission and must be clear and legible.    
(b) In the event that ESTTA is unavailable due to technical problems, or when extraordinary 
circumstances are present, submissions may be filed in paper form. All submissions in paper form, 
except the extensions of time to file a notice of opposition, the notice of opposition, the petition to 
cancel, or answers thereto ( see §§ 2.101(b)(2), 2.102(a)(2), 2.106(b)(1), 2.111(c)(2), and 
2.114(b)(1)), must include a written explanation of such technical problems or extraordinary 
circumstances. Paper submissions that do not meet the showing required under this paragraph (b) 
will not be considered. A paper submission, including exhibits and depositions, must meet the 
following requirements : 
(1) A paper submission must be printed in at least 11-point type and double-spaced, with text 
on one side only of each sheet;  
(2) A paper submission must be 8 to 8.5 inches (20.3 to 21.6 cm.) wide and 11 to 11.69 inches 
(27.9 to 29.7 cm.) long, and contain no tabs or other such devices extending beyond the edges of 
the paper; 
(3) If a paper submission contains dividers, the dividers must not have any extruding tabs or 
other devices, and must be on the same size and weight paper as the submission;  
(4) A paper submission must not be stapled or bound;  
(5) All pages of a paper submission must be numbered and exhibits shall be identified in the 
manner prescribed in §  2.123(g)(2);  
(6) Exhibits pertaining to a paper submission must be filed on paper and comply with the 
requirements for a paper submission.  
(c) To be handled as confidential, submissions to the Trademark Trial and Appeal Board that 
are confidential in whole or part pursuant to § 2.125(f) must be submitted using the “Confidential” 
selection available in ESTTA or, where appropriate, under a separate paper cover.  Both the 
submission and its cover must be marked confidential and must identify the case number and the 
parties. A copy of the submission for public viewing with the confidential portions redacted must be 
submitted concurrently. 
[Added 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 42242, effective Aug. 31, 2007; 81 FR 
69950, Oct. 7, 2016, effective January 14, 2017] 

 -89- July 15, 2026 
§ 2.127  Motions.  
(a) Every motion must be submitted in written form and must meet the requirements prescribed 
in § 2.126.  It shall contain a full statement of the grounds, and shall embody or be accompanied by 
a brief.  Except as provided in paragraph (e)(1) of this section, a brief in response to a motion shall 
be filed within twenty days from the date of service of the motion unless another time is specified 
by the Trademark Trial and Appeal Board, or the time is extended by stipulation of the parties 
approved by the Board, or upon motion granted by the Board, or upon order of the Board. If a motion 
for an extension is denied, the time for responding to the motion remains as specified under this 
section, unless otherwise ordered. Except as provided in paragraph (e)(1) of this section, a reply 
brief, if filed, shall be filed within twenty days from the date of service of the brief in response to the 
motion. The time for filing a reply brief will not be extended or reopened.  The Board will consider 
no further papers in support of or in opposition to a motion.  Neither the brief in support of a motion 
nor the brief in response to a motion shall exceed twenty-five pages in length in its entirety, including 
table of contents, index of cases, description of the record, statement of the issues, recitation of the 
facts, argument, and summary.  A reply brief shall not exceed ten pages in length in its entirety.  
Exhibits submitted in support of or in opposition to a motion are not considered part of the brief for 
purposes of determining the length of the brief.  When a party fails to file a brief in response to a 
motion, the Board may treat the motion as conceded.  An oral hearing will not be held on a motion 
except on order by the Board.  
(b) Any request for reconsideration or modification of an order or decision issued on a motion 
must be filed within one month from the date thereof. A brief in response must be filed within twenty 
days from the date of service of the request . 
(c) Interlocutory motions, requests, conceded matters, and other matters not actually or 
potentially dispositive of a proceeding may be acted upon by a single Administrative Trademark 
Judge of the Trademark Trial and Appeal Board, or by an Interlocutory Attorney or Paralegal of the 
Board to whom authority to act has been delegated, or by ESTTA. Motions disposed of by orders 
entitled “By the Trademark Trial and Appeal Board” have the same legal effect as orders by a panel 
of three Administrative Trademark Judges of the Board . 
(d) When any party timely files a potentially dispositive motion, including, but not limited to, a 
motion to dismiss, a motion for judgment on the pleadings, or a motion for summary judgment, the 
case is suspended by the Trademark Trial and Appeal Board with respect to all matters not germane 
to the motion and no party should file any paper which is not germane to the  motion except as 
otherwise may be specified in a Board order. If the case is not disposed of as a result of the motion, 
proceedings will be resumed pursuant to an order of the Board when the motion is decided . 
(e)(1) A party may not file a motion for summary judgment until the party has made its initial 
disclosures, except for a motion asserting claim or issue preclusion or lack of jurisdiction by the 
Trademark Trial and Appeal Board. A motion for summary judgment must be filed before the day 
of the deadline for pretrial disclosures for the first testimony period, as originally set or as reset. A 
motion under Rule 56(d) of the Federal Rules of Civil Procedure, if filed in response to a motion for 
summary judgment, shall be filed within thirty days from the date of service of the summary 
judgment motion. The time for filing a motion under Rule 56(d) will not be extended or reopened. If 
no motion under Rule 56(d) is filed, a brief in response to the motion for summary judgment shall 
be filed within thirty days from the date of service of the motion unless the time is extended by 
stipulation of the parties approved by the Board, or upon motion granted by the Board, or upon 
order of the Board. If a motion for an extension is denied, the time for responding to the motion for 
summary judgment may remain as specified under this section. A reply brief, if filed, shall be filed 
within twenty days from the date of service of the brief in response to the motion. The time for filing 
a reply brief will not be extended or reopened. The Board will consider no further papers in support 
of or in opposition to a motion for summary judgment.  
(2) For purposes of summary judgment only, the Board will consider any of the following, if a 
copy is provided with the party’s brief on the summary judgment motion: written disclosures or 
disclosed documents, a discovery deposition or any part thereof with any exhibit to the part that is 

 -90- July 15, 2026 
filed, an interrogatory and answer thereto with any exhibit made part of the answer, a request for 
production and the documents or things produced in response thereto, or a request for admission 
and any exhibit thereto and the admission (or a statement that the party from which an admission 
was requested failed to respond thereto). If any motion for summary judgment is denied, the parties 
may stipulate that the materials submitted with briefs on the motion be considered at trial as trial 
evidence, which may be supplemented by additional evidence during trial.  
(f) The Board will not hold any person in contempt, or award attorneys’ fees or other expenses 
to any party. 
[48 FR 23140, May 23, 1983, as amended at 54 FR 34900, Aug. 22, 1989; 63 FR 48081, Sept. 9, 1998; 63 
FR 52158, Sept. 30, 1998; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 42242, Aug. 1, 2007, 
effective Nov. 1, 2007; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017; 82 FR 33806, July 21, 2017, 
effective July 21, 2017 ] 
§ 2.128  Briefs at final hearing.  
(a)(1) The brief of the party in the position of plaintiff shall be due not later than sixty days after 
the date set for the close of rebuttal testimony.  The brief of the party in the position of defendant, if 
filed, shall be due not later than thirty days after the due date of the first brief.  A reply brief by the 
party in the position of plaintiff, if filed, shall be due not later than fifteen days after the due date of 
the defendant’s brief.  
(2) When there is a counterclaim, or when proceedings have been consolidated and one party 
is in the position of plaintiff in one of the involved proceedings and in the position of defendant in 
another of the involved proceedings, or when there is an inter ference or a concurrent use 
registration proceeding involving more than two parties, the Trademark Trial and Appeal Board will 
set the due dates for the filing of the main brief, and the answering brief, and the rebuttal brief by 
the parties. 
(3) When a party in the position of plaintiff fails to file a main brief, an order may be issued 
allowing plaintiff until a set time, not less than fifteen days, in which to show cause why the Board 
should not treat such failure as a concession of the case. If plaintiff fails to file a response to the 
order, or files a response indicating that plaintiff has lost interest in the case, judgment may be 
entered against plaintiff. If a plaintiff files a response to the order showing good cause, but does not 
have any evidence of record and does not move to reopen its testimony period and make a showing 
of excusable neglect sufficient to support such reopening, judgment may be entered against plaintiff 
for failure to take testimony or submit any  other evidence. 
(b) Briefs must be submitted in written form and must meet the requirements prescribed in 
§ 2.126.  Each brief shall contain an alphabetical index of cited cases.  Without prior leave of the 
Trademark Trial and Appeal Board, a main brief on the case shall not exceed fifty -five pages in 
length in its entirety, including the table of contents, index of cases, description of the record, 
statement of the issues, recitation of the facts, argument, and summary; and a reply brief shall not 
exceed twenty-five pages in its entirety. Evidentiary objections that may properly be raised in a 
party’s brief on the case may instead be raised in an appendix or by way of a separate statement of 
objections. The appendix or separate statement is not included within the page limit. Any brief 
beyond the page limits and any brief with attachments outside the stated requirements may not be 
considered by the Board.   
[48 FR 23140, May 23, 1983; 48 FR 27225, June 14, 1983, as amended at 54 34900, Aug. 22, 1989; 68 FR 
55748, Sept. 26, 2003, effective Nov. 2, 2003; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.129  Oral argument; reconsideration.  
(a) If a party desires to have an oral argument at final hearing, the party shall request such 
argument by a separate notice filed not later than ten days after the due date for the filing of the last 
reply brief in the proceeding.  Oral arguments will be heard by at least three Administrative 

 -91- July 15, 2026 
Trademark Judges or other statutory members of the Trademark Trial and Appeal Board at the time 
specified in the notice of hearing. If any party appears at the specified time, that party will be heard. 
Parties and members of the Board may attend in person or, at the discretion of the Board, remotely. 
If the Board is prevented from hearing the case at the specified time, a new hearing date will be set. 
Unless otherwise permitted, oral arguments in an inter partes case will be limited to thirty minutes 
for each party. A party in the position of plaintiff may reserve part of the time allowed for oral 
argument to present a rebuttal argument. 
(b) The date or time of a hearing may be reset, so far as is convenient and proper, to meet the 
wishes of the parties and their attorneys or other authorized representatives.  The Board may, 
however, deny a request to reset a hearing date for lack of good cause or if multiple requests for 
rescheduling have been filed.  
(c) Any request for rehearing or reconsideration or modification of a decision issued after final 
hearing must be filed within one month from the date of the decision.  A brief in response must be 
filed within twenty days from the date of service of the request.  The times specified may be 
extended by order of the Trademark Trial and Appeal Board on motion for good cause.  
(d) When a party to an inter partes proceeding before the Trademark Trial and Appeal Board 
cannot prevail without establishing constructive use pursuant to section 7(c) of the Act in an 
application under section 1(b) of the Act, the Trademark Trial and App eal Board will enter a 
judgment in favor of that party, subject to the party’s establishment of constructive use.  The time 
for filing an appeal or for commencing a civil action under section 21 of the Act shall run from the 
date of the entry of the judgme nt. 
[48 FR 23141, May 23, 1983, as amended at 54 FR 29554, July 13, 1989; 54 FR 34900, Aug. 22, 1989; 54 
FR 37597, Sept. 11, 1989; 72 FR 42242, Aug. 1, 2007, effective Aug. 31, 2007; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ] 
§ 2.130  New matter suggested by the trademark examining attorney.  
If, while an inter partes proceeding involving an application under section 1 or 44 of the Act is 
pending, facts appear which, in the opinion of the examining attorney, render the mark in the 
application unregistrable, the examining attorney should request that the Board remand the 
application. The Board may suspend the proceeding and remand the application to the trademark 
examining attorney for an ex parte determination of the question of registrability. A copy of the 
trademark examining attorney’s final action will be furnished to the parties to the inter partes 
proceeding following the final determination of registrability by the trademark examining attorney or 
the Board on appeal. The Board will consider the application for such further inter partes action as 
may be appropriate. 
[Amended 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 81 FR 69950, Oct. 7, 2016, effective January 
14, 2017]] 
§ 2.131  Remand after decision in inter partes proceeding.  
If, during an inter partes proceeding involving an application under section 1 or 44 of the Act, 
facts are disclosed which appear to render the mark unregistrable, but such matter has not been 
tried under the pleadings as filed by the parties or as they might be deemed to be amended under 
Rule 15(b) of the Federal Rules of Civil Procedure to conform to the evidence, the Trademark Trial 
and Appeal Board, in lieu of determining the matter in the decision on the proceeding, may remand 
the application to the trademark examining attorney for reexamination in the event the applicant 
ultimately prevails in the inter partes proceeding.  Upon remand, the trademark examining attorney 
shall reexamine the application in light of the matter referenced by the Board.  If, upon 
reexamination, the trademark examining attorney finally refuses registration to the applicant, an 
appeal may be taken as provided by §§ 2.141 and 2.142.  

 -92- July 15, 2026 
[48 FR 23141, May 23, 1983; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 81 FR 69950, Oct. 7, 
2016, effective January 14, 2017 ] 
§ 2.132  Involuntary dismissal for failure to take testimony.  
(a) If the time for taking testimony by any party in the position of plaintiff has expired and it is 
clear to the Board from the proceeding record that such party has not taken testimony or offered 
any other evidence, the Board may grant judgment for the defendant. Also, any party in the position 
of defendant may, without waiving the right to offer evidence in the event the motion is denied, move 
for dismissal on the ground of the failure of the plaintiff to prosecute. The party in the position of 
plaintiff shall have twenty days from the date of service of the motion to show cause why judgment 
should not be rendered dismissing the case. In the absence of a showing of excusable neglect, 
judgment may be rendered against the party in the position of plaintiff.  If the motion is denied, 
testimony periods will be reset for the party in the position of defendant and for rebuttal . 
(b) If no evidence other than Office records showing the current status and title of plaintiff’s 
pleaded registration(s) is offered by any party in the position of plaintiff, any party in the position of 
defendant may, without waiving the right to offer evidence in the event the motion is denied, move 
for dismissal on the ground that upon the law and the facts the party in the position of plaintiff has 
shown no right to relief. The party in the position of plaintiff shall have twenty days from the date of 
service of the motion to file a brief in response to the motion. The Trademark Trial and Appeal Board 
may render judgment against the party in the position of plaintiff, or the Board may decline to render 
judgment until all testimony periods have passed. If judgment is not rendered  on the motion to 
dismiss, testimony periods will be reset for the party in the position of defendant and for rebuttal. 
(c) A motion filed under paragraph (a) or (b) of this section must be filed before the opening of 
the testimony period of the moving party, except that the Trademark Trial and Appeal Board may in 
its discretion grant a motion under paragraph (a) even if the motion was filed after the opening of 
the testimony period of the moving party.  
[48 FR 23141, May 23, 1983, as amended at 51 FR 28710, Aug. 11, 1986; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ] 
§ 2.133  Amendment of application or registration during proceedings.  
(a) An application subject to an opposition may not be amended in substance nor may a 
registration subject to a cancellation be amended or disclaimed in part, except with the consent of 
the other party or parties and the approval of the Trademark Trial and Appeal Board, or upon motion 
granted by the Board. 
(b) If, in an inter partes proceeding, the Trademark Trial and Appeal Board finds that a party 
whose application or registration is the subject of the proceeding is not entitled to registration in the 
absence of a specified restriction to the application or registration, the Board will allow the party time 
in which to file a motion that the application or registration be amended to conform to the findings 
of the Board, failing which judgment will be entered against the party.  
(c) Geographic limitations will be considered and determined by the Trademark Trial and Appeal 
Board only in the context of a concurrent use registration proceeding.   
(d) A plaintiff’s pleaded registration will not be restricted in the absence of a counterclaim to 
cancel the registration in whole or in part, except that a counterclaim need not be filed if the 
registration is the subject of another proceeding between the  same parties or anyone in privity 
therewith.   
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37597, Sept. 11, 1989; 72 FR 42242, Aug. 1, 2007, 
effective Aug. 31, 2007]  

 -93- July 15, 2026 
§ 2.134  Surrender or voluntary cancellation of registration.  
(a) After the commencement of a cancellation proceeding, if the respondent applies for 
cancellation of the involved registration under section 7(e) of the Act of 1946 without the written 
consent of every adverse party to the proceeding, judgment shall be e ntered against the 
respondent. The written consent of an adverse party may be signed by the adverse party or by the 
adverse party’s attorney or other authorized representative.  
(b) After the commencement of a cancellation proceeding, if it comes to the attention of the 
Trademark Trial and Appeal Board that the respondent has permitted its involved registration to be 
cancelled under section 8 or section 71 of the Act of 1946 , or has failed to renew its involved 
registration under section 9 of the Act of 1946, or has allowed its registered extension of protection 
to expire under section 70(b) of the Act of 1946, an order may be issued allowing respondent until 
a set time, not less than fifteen days, in which to show cause why such cancellation, failure to renew, 
or expiration should not be deemed to be the equivalent of a cancellation by request of respondent 
without the consent of the  adverse party and should  not result in  entry of judgment against 
respondent as provided by paragraph (a) of this section. In the absence of a showing of good and 
sufficient cause, judgment may be entered against respondent as provided by paragraph (a) of this 
section. 
[48 FR 23141, May 23, 1983, as amended at 54 FR 34900, Aug. 22, 1989; 63 FR 48081, Sept. 9, 1998, 
effective Oct. 9, 1998 ; 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
§ 2.135  Abandonment of application or mark.  
After the commencement of an opposition, concurrent use, or interference proceeding, if the 
applicant files a written abandonment of the application or of the mark without the written consent 
of every adverse party to the proceeding, judgment shall be entered against the applicant.  The 
written consent of an adverse party may be signed by the adverse party or by the adverse party’s 
attorney or other authorized representative.  
[48 FR 23141, May 23, 1983, as amended at 54 FR 34900, Aug. 22, 1989]  
§ 2.136  Status of application or registration on termination of proceeding.  
After the Board has issued its decision in an opposition, cancellation or concurrent use 
proceeding, and after the time for filing any appeal of the decision has expired, or any appeal that 
was filed has been decided and the Board’s decision affirmed, the proceeding will be terminated by 
the Board. On termination of an opposition, cancellation or concurrent use proceeding, if the 
judgment is not adverse to the applicant or registrant, the subject application returns to the status it 
had before the instituti on of the proceeding and the otherwise appropriate status of the subject 
registration is unaffected by the proceeding. If the judgment is adverse to the applicant or registrant, 
the application stands refused or the registration will be cancelled in whole or in part without further 
action and all proceedings thereon are considered terminated . 
[As amended at 81 FR 69950, Oct. 7, 2016, effective January 14, 2017 ] 
APPEALS 
§ 2.141  Ex parte appeals.  
(a) Appeal from final refusal of application . After final refusal by the trademark examining 
attorney, an applicant may appeal to the Trademark Trial and Appeal Board, upon payment of the 
prescribed fee for each class in the application for which an appeal is taken, within the time provided 
in § 2.142(a)(1). A second refusal on the same grounds may be considered as final by the applicant 
for purpose of appeal.  

 -94- July 15, 2026 
(b) Appeal from expungement or reexamination proceeding. After issuance of a final Office 
action in an expungement or reexamination proceeding under § 2.93, a registrant may appeal to 
the Trademark Trial and Appeal Board, upon payment of the prescribed fee for each class in the 
registration for which the appeal is taken, within the time provided in § 2.142(a)(2).    
(c) Appeal fee required. The applicant or registrant must pay an appeal fee for each class for 
which the appeal is taken. If an appeal fee is not paid for at least one class of goods or services 
before the expiration of the time for appeal, when the appeal is from a final refusal of an application, 
the application will be abandoned or, when the appeal is from an expungement or reexamination 
proceeding, the Office will terminate the proceeding. When a multiple -class application or 
registration is involved, if an appeal fee is submit ted for fewer than all classes, the applicant or 
registrant must specify the class(es) for which the appeal is taken. If the applicant or registrant timely 
submits a fee sufficient to pay for an appeal in at least one class, but insufficient to cover all the 
classes, and the applicant or registrant has not specified the class(es) to which the fee applies, the 
Board will issue a written notice setting a time limit in which the applicant or registrant may either 
pay the additional fees or specify the class(es) being appealed. If the applicant or registrant does 
not submit the required fee or specify the class(es) being appealed within the set time period, the 
Board will apply the fee(s) to the class(es) in ascending order, beginning with the lowest numbered 
class. 
[41 FR 760, Jan. 5, 1976; amended 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 86 FR 64300, Nov. 
17, 2021, effective Dec. 18, 2021 ] 
§ 2.142  Time and manner of ex parte appeals.  
(a)(1) An appeal filed under the provisions of § 2.141(a) from the final refusal of an application 
must be filed within the time provided in § 2.62(a).   
(2) An appeal filed under the provisions of § 2.141(b) from an expungement or reexamination 
proceeding must be filed within three months from the issue date of the final Office action.   
(3) An appeal is taken by filing a notice of appeal, as prescribed in § 2.126, and paying the 
appeal fee. 
(b)(1) The brief of appellant shall be filed within sixty days from the date of appeal. If the brief is 
not filed within the time allowed, the appeal may be dismissed. The examining attorney shall, within 
sixty days after the brief of appellant is sent to the examining attorney, file with the Trademark 
Trial and Appeal Board a written brief answering the brief of appellant and shall e mai l  o r  mail 
a copy of the brief to the appellant. The appellant may file a reply brief within twenty days from 
the date of mailing of the brief of the examining attorney. 
(2) Briefs must meet the requirements prescribed in § 2.126, except examining attorney 
submissions need not be filed through ESTTA. Without prior leave of the Trademark Trial and 
Appeal Board, a brief shall not exceed twenty-five pages in length in its entirety, including the table 
of contents, index of cases, description of the record, statement of the issues, recitation of the facts, 
argument, and summary. A reply brief from the appellant, if any, shall not exceed ten pages in length 
in its entirety. Unless authorized by the Board, no further briefs are pe rmitted. 
(3) Citation to evidence in briefs should be to the documents in the electronic record for the 
subject application or registration by date, the name of the paper under which the evidence was 
submitted, and the page number in the electronic record.    
(c) All requirements made by the examining attorney and not the subject of appeal shall be 
complied with prior to the filing of an appeal, and the statement of issues in the brief should note 
such compliance. 
(d) The record should be complete prior to the filing of an appeal. Evidence should not be filed 
with the Board after the filing of a notice of appeal.  
(1) In an appeal from a refusal to register, if the appellant or the examining attorney desires to 
introduce additional evidence after an appeal is filed, the appellant or the examining attorney should 
submit a request to the Board to suspend the appeal and to  remand the application for further 
examination. 

 -95- July 15, 2026 
(2) In an appeal from an expungement or reexamination proceeding, no additional evidence 
may be included once an appeal is filed, and the Board may not remand for further examination. 
(e)(1) If the appellant desires an oral hearing, a request should be made by a separate notice 
filed not later than ten days after the due date for a reply brief.  Oral argument will be heard by at 
least three Administrative Trademark Judges or other statutory members of the Trademark Trial and 
Appeal Board at the time specified in the notice of hearing, which may be reset if the Board is 
prevented from hearing the argument at the specified time or, so far as is convenient and 
proper, to meet the wish of the appellant or the appellant’s attorney or other authorized 
representative. Appellants, examining attorneys, and members of the Board may attend in person 
or, at the discretion of the Board, remotely . 
(2) If the appellant requests an oral argument, the examining attorney who issued the 
refusal of registration or the requirement from which the appeal is taken, or in lieu thereof another 
examining attorney as designated by a supervisory or managing attorney, shall present an oral 
argument. If no request for an oral hearing is made by the appellant, the appeal will be decided 
on the record and briefs. 
(3) Oral argument will be limited to twenty minutes by the appellant and ten minutes by the 
examiner.  The appellant may reserve part of the time allowed for oral argument to present a rebuttal 
argument. 
(f)(1) If, during an appeal from a refusal of registration, it appears to the Trademark Trial and 
Appeal Board that an issue not previously raised may render the mark of the appellant unregistrable, 
the Board may suspend the appeal and remand the application to the examining attorney for further 
examination to be completed within the time set by the Board. 
(2) If the further examination does not result in an additional ground for refusal of registration, 
the examining attorney shall promptly return the application to the Board, for resumption of the 
appeal, with a written statement that further examination did not result in an additional ground 
for refusal of registration. 
(3) If the further examination does result in an additional ground for refusal of registration, the 
examining attorney and appellant shall proceed as provided by §§ 2.61, 2.62, and 2.63. If the 
ground for refusal is made final, the examining attorney shall return the application to the Board, 
which shall thereupon issue an order allowing the appellant sixty days from the date of the order to 
file a supplemental brief limited to the additional ground for the refusal of registration.  If the 
supplemental brief is not filed by the appellant within the time allowed, the appeal may be dismissed. 
(4) If the supplemental brief of the appellant is filed, the examining attorney shall, within sixty 
days after the supplemental brief of the appellant is sent to the examining attorney, file with the 
Board a written brief answering the supplemental brief of appellant and shall email or mail a copy 
of the brief to the appellant. The appellant may file a reply brief within twenty days from the date 
of mailing of the brief of the examining attorney. 
(5) If an oral hearing on the appeal had been requested prior to the remand of the application 
but not yet held, an oral hearing will be set and heard as provided in paragraph (e) of this section.  
If an oral hearing had been held prior to the remand or had not been previously requested by the 
appellant, an oral hearing may be requested by the appellant by a separate notice filed not later 
than ten days after the due date for a reply brief on the additional ground for refusal of registration.  
If the appellant files a request for an oral hearing, one will be set and heard as provided in paragraph 
(e) of this section.   
(6) If, during an appeal from a refusal of registration, it appears to the examining attorney that 
an issue not involved in the appeal may render the mark of the appellant unregistrable, the 
examining attorney may, by written request, ask the Board to suspend the appeal and to remand 
the application to the examining attorney for further examination. If the request is granted, the 
examining attorney and appellant shall proceed as provided by §§ 2.61, 2.62, and 2.63. After 
the additional ground for refusal of registration has been withdrawn or made final, the examining 
attorney shall return the application to the Board, which shall resume proceedings in the appeal 
and take further  appropriate action with respect thereto . 

 -96- July 15, 2026 
(g) An application which has been considered and decided on appeal will not be reopened 
except for the entry of a disclaimer under section 6 of the Act of 1946 or upon order of the Director, 
but a petition to the Director to reopen an application will be considered only upon a showing of 
sufficient cause for consideration of any matter not already adjudicated.  
[48 FR 23141, May 23, 1983, as amended at 54 FR 34901, Aug. 22, 1989; 68 FR 14332, March 25, 2003, 
effective May 1, 2003; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 72 FR 42242, Aug. 1, 2007, 
effective Aug. 31, 2007; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
§ 2.143 [Added and Reserved]  
§ 2.144  Reconsideration of decision on ex parte appeal.  
Any request for rehearing or reconsideration, or modification of the decision, must be filed within 
one month from the date of the decision.  Such time may be extended by the Trademark Trial and 
Appeal Board upon a showing of sufficient cause.  
[41 FR 760, Jan. 5. 1976, as amended at 54 FR 29554, July 13, 1989]  
§ 2.145  Appeal to court and civil action.  
(a) For an Appeal to the United States Court of Appeals for the Federal Circuit under section 
21(a) of the Act.  (1) An applicant for registration, a registrant in an ex parte expungement or 
reexamination proceeding, any party to an interference, opposition, or cancellation, or any party to 
an application to register as a concurrent user, hereinafter referred to as inter partes proceedings, 
who is dissatisfied with the decision of the Trademark Trial and Appeal Board, and any registrant 
who has filed an affi davit or declaration under section 8 or section 71 of the Act, or filed an 
application for renewal under section 9 of the Act, and is dissatisfied with the decision of the Director 
(§§ 2.165 and 2.184 and § 7.40 of this chapter), may appeal to the United States Court of Appeals 
for the Federal Circuit. It is unnecessary to request reconsideration before filing any such appeal; 
however, any request to reconsider the decision must be made before filing a notice of appeal.  
(2) In all appeals under section 21(a), the appellant must take the following steps:  
(i) File the notice of appeal with the Director, addressed to the Office of the General Counsel, 
as provided in § 104.2 of this chapter;  
(ii) File a copy of the notice of appeal with the Trademark Trial and Appeal Board via ESTTA; 
and 
(iii) Comply with the requirements of the Federal Rules of Appellate Procedure and Rules for 
the United States Court of Appeals for the Federal Circuit, including serving the requisite number of 
copies on the Court and paying the requisite fee for the appe al. 
(3) The following requirements must also be satisfied:  
(i) The notice of appeal shall specify the party or parties taking the appeal and shall designate 
the decision or part thereof appealed from.  
(ii) In inter partes proceedings, the notice of appeal must be served as provided in § 2.119.  
(b) For a notice of election under section 21(a)(1) to proceed under section 21(b) of the Act. (1) 
Any applicant or registrant in an ex parte case who takes an appeal to the United States Court of 
Appeals for the Federal Circuit waives any right to proceed under section 21(b) of the Act.  
(2) If an adverse party to an appeal taken to the United States Court of Appeals for the Federal 
Circuit by a defeated party in an inter partes proceeding elects to have all further review proceedings 
conducted under section 21(b) of the Act, that party mu st take the following steps:  
(i) File a notice of election with the Director, addressed to the Office of the General Counsel, as 
provided in § 104.2 of this chapter;  
(ii) File a copy of the notice of election with the Trademark Trial and Appeal Board via ESTTA; 
and  

 -97- July 15, 2026 
(iii) Serve the notice of election as provided in § 2.119.  
(c) For a civil action under section 21(b) of the Act. (1) Any person who may appeal to the United 
States Court of Appeals for the Federal Circuit (paragraph (a) of this section), except for a registrant 
subject to an ex parte expungement or reexamination proceeding, may have remedy by civil action 
under section 21(b) of the Act. It is unnecessary to request reconsideration before filing any such 
civil action; however, any request to reconsider the decision must be made before filing a civil action.  
(2) Any applicant or registrant in an ex parte case who seeks remedy by civil action under 
section 21(b) of the Act must serve the summons and complaint pursuant to Rule 4(i) of the Federal 
Rules of Civil Procedure with the copy to the Director addressed to the Office of the General Counsel 
as provided in §104.2 of this chapter. A copy of the complaint must also be filed with the Trademark 
Trial and Appeal Board via ESTTA. 
(3) The party initiating an action for review of a Board decision in an inter partes case under 
section 21(b) of the Act must file notice thereof with the Trademark Trial and Appeal Board via 
ESTTA no later than five business days after filing the complaint in the district court. The notice 
must identify the civil action with particularity by providing the case name, case number, and court 
in which it was filed. A copy of the complaint may be filed with the notice. Failure to file the required 
notice can result in termination of the Board proceeding and further action within the United States 
Patent and Trademark Office consistent with the final Board decision.  
(d) Time for appeal or civil action - (1) For an appeal under section 21(a). The notice of appeal 
filed pursuant to section 21(a) of the Act must be filed with the Director no later than sixty-three (63) 
days from the date of the final decision of the Trademark Trial and Appeal Board or the Director. In 
inter partes cases, the time for filing a notice of cross-appeal expires 14 days after service of the 
notice of appeal or 63 days from the date of the decision of the Trademark Trial and Appeal Board 
or the Director, whichever is later.  
(2) For a notice of election under 21(a)(1) and a civil action pursuant to such notice of election.  
The times for filing a notice of election under section 21(a)(1) and for commencing a civil action 
pursuant to a notice of election are governed by section 21(a)(1) of the Act.  
(3) For a civil action under section 21(b). A civil action must be commenced no later than sixty-
three (63) days after the date of the final decision of the Trademark Trial and Appeal Board or 
Director. In inter partes cases, the time for filing a cross-action expires 14 days after service of the 
summons and complaint or 63 days from the date of the decision of the Trademark Trial and Appeal 
Board or the Director, whichever is later.  
(4) Time computation. (i) If a request for rehearing or reconsideration or modification of the 
Board decision is filed within the time specified in § 2.127(b), § 2.129(c), or § 2.144, or within any 
extension of time granted thereunder, the time for filing an appeal or commencing a civil action shall 
expire no later than sixty-three (63) days after action on the request.  
(ii) Holidays. The times specified in this section in days are calendar days. If the last day of time 
specified for an appeal, notice of election, or commencing a civil action falls on a Saturday, Sunday 
or Federal holiday in the District of Columbia, the time is extended to the next day which is neither 
a Saturday, Sunday nor a Federal holiday in the District of Columbia pursuant to § 2.196.  
(e) Extension of time. (1) The Director, or the Director’s designee, may extend the time for filing 
an appeal, or commencing a civil action, upon written request if:  
(i) Requested before the expiration of the period for filing an appeal or commencing a civil action, 
and upon a showing of good cause; or  
(ii) Requested after the expiration of the period for filing an appeal or commencing a civil action, 
and upon a showing that the failure to act was the result of excusable neglect.  
(2) The request must be filed as provided in § 104.2 of this chapter and addressed to the 
attention of the Office of the Solicitor. A copy of the request should also be filed with the Trademark 
Trial and Appeal Board via ESTTA. 
[47 FR 47382, Oct. 26, 1982, as amended at 53 FR 16414, May 9, 1988; 54 FR 29554, July 13, 1989; 54 FR 
34901, Aug. 22, 1989; 58 FR 54503, Oct. 22, 1993; 68 FR 14332, March 25, 2003, effective May 1, 2003; 68 
FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015; 81 FR 
69950, Oct. 7, 2016, effective January 14, 2017; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 

 -98- July 15, 2026 
PETITIONS AND ACTION BY THE DIRECTOR 
§ 2.146  Petitions to the Director.  
(a) Petition may be taken to the Director in a trademark case:   
(1) From any repeated or final formal requirement of the examiner in the ex parte prosecution 
of an application if permitted by § 2.63(a) and (b);  
(2) In any case for which the Act of 1946, Title 35 of the United States Code, or parts 2, 3, 6, 
and 7 of Title 37 of the Code of Federal Regulations specifies that the matter is to be determined 
directly or reviewed by the Director;   
(3) To invoke the supervisory authority of the Director in appropriate circumstances;  
(4) In any case not specifically defined and provided for by parts 2, 3, 6, and 7 of Title 37 of the 
Code of Federal Regulations; or  
(5) In an extraordinary situation, when justice requires and no other party is injured thereby, to 
request a suspension or waiver of any requirement of the rules not being a requirement of the Act 
of 1946.  
(b) Questions of substance arising during the ex parte prosecution of applications, or 
expungement or reexamination of registrations, including, but not limited to, questions arising under 
sections 2, 3, 4, 5, 6, 16A, 16B, and 23 of the Act of 1946, are not appropriate subject matter for 
petitions to the Director.   
(c)(1) Every petition to the Director shall include a statement of the facts relevant to the petition, 
the points to be reviewed, the action or relief requested, and the fee required by § 2.6. Any brief in 
support of the petition shall be embodied in or accompany the petition. The petition must be signed 
by the petitioner, someone with legal authority to bind the petitioner ( e.g., a corporate officer or 
general partner of a partnership), or a practitioner qualified to practice under § 11.14 of this chapter, 
in accordance with the requirements of § 2.193(e)(5). When facts are to be proved on petition, the 
petitioner must submit proof in the form of verified statements signed by someone with firsthand 
knowledge of the facts to be proved, and any exhibits.  
(2) A petition requesting reinstatement of a registration cancelled in whole or in part for failure 
to timely respond to an Office action issued in an expungement and/or reexamination proceeding 
must include a response to the Office action, signed in accordanc e with § 2.193, or an appeal. 
(d) Unless a different deadline is specified elsewhere in this chapter, a petition under this section 
must be filed by not later than:  
(1) Two months after the issue date of the action, or date of receipt of the filing, from which relief 
is requested; or  
(2) Where the applicant or registrant declares under § 2.20 or 28 U.S.C. 1746 that it did not 
receive the action, or where no action was issued, the petition must be filed by not later than:  
(i) Two months of actual knowledge of the abandonment of an application and not later than six 
months after the date the trademark electronic records system indicates that the application is 
abandoned in full or in part;  
(ii) Where the registrant has timely filed an affidavit of use or excusable non-use under Section 
8 or 71 of the Act, or a renewal application under Section 9 of the Act, two months after the date of 
actual knowledge of the cancellation/expiration of a registration and not later than six months after 
the date the trademark electronic records system indicates that the registration is cancelled/expired; 
or 
(iii) Two months after the date of actual knowledge of the denial of certification of an international 
application under § 7.13(b) and not later than six months after the trademark electronic records 
system indicates that certification is denied.  
(iv) Where an expungement or reexamination proceeding has been instituted under § 2.92, two 
months after the date of actual knowledge of the cancellation of goods and/or services in a 
registration and not later than six months after the date the trademark elect ronic record system 
indicates that the goods and/or services are cancelled.  

 -99- July 15, 2026 
(e)(1) A petition from the grant or denial of a request for an extension of time to file a notice of 
opposition must be filed by not later than fifteen days after the issue date of the grant or denial of 
the request.  A petition from the grant of a request  must be served on the attorney or other 
authorized representative of the potential opposer, if any, or on the potential opposer.  A petition 
from the denial of a request must be served on the attorney or other authorized representative of 
the applicant, if any, or on the applicant.  Proof of service of the petition must be made as provided 
by § 2.119.  The potential opposer or the applicant, as the case may be, may file a response by not 
later than fifteen days after the date of service of the petition and must serve a copy of the response 
on the petitioner, with proof of service as provided by § 2.119.  No further document relating to the 
petition may be filed. 
(2) A petition from an interlocutory order of the Trademark Trial and Appeal Board must be filed 
by not later than thirty days after the issue date of the order from which relief is requested.  Any brief 
in response to the petition must be filed, with any supporting exhibits, by not later than fifteen days 
after the date of service of the petition.  Petitions and responses to petitions, and any documents 
accompanying a petition or response under this subsection, must be served on every adverse party 
pursuant to § 2.119.  
(f) An oral hearing will not be held on a petition except when considered necessary by the 
Director. 
(g) The mere filing of a petition to the Director will not act as a stay in any appeal or inter partes 
proceeding that is pending before the Trademark Trial and Appeal Board, nor stay the period for 
replying to an Office action in an application, except when a stay is specifically requested and is 
granted or when §§ 2.63(a) and (b) and 2.65(a) are applicable to an ex parte application.  
(h) Authority to act on petitions, or on any petition, may be delegated by the Director.  
(i) If the Director denies a petition, the petitioner may request reconsideration, if:  
(1) The petitioner files the request by not later than:  
(i) Two months after the issue date of the decision denying the petition; or  
(ii) Two months after the date of actual knowledge of the decision denying the petition and not 
later than six months after the issue date of the decision where the petitioner declares under § 2.20 
or 28 U.S.C. 1746 that it did not receive the decision; an d 
(2) The petitioner pays a second petition fee under § 2.6.  
[48 FR 23142, May 23, 1983; 48 FR 27225, June 14, 1983; 63 FR 48081, Sept. 9, 1998, effective Oct. 9, 
1998; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 14332, March 25, 2003, effective May 1, 
2003; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 
2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 
2015; 80 FR 33170, June 11, 2015, effective July 11, 2015; 82 FR 29401, June 29, 2017, effective July 8, 
2017; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 
2021] 
§ 2.147  Petition to the Director to a ccept a paper submission.  
(a) Paper submission when TEAS is unavailable on the date of a filing deadline. (1) An applicant 
or registrant may file a petition to the Director under this section requesting acceptance of a 
submission filed on paper if:  
(i) TEAS is unavailable on the date of the deadline for the submission specified in a regulation 
in part 2 or 7 of this chapter or in a section of the Act; and  
(ii) The petition is timely filed, pursuant to §  2.197 or §   2.198, on the date of the deadline.  
(2) The petition must include:  
(i) The paper submission;  
(ii) Proof that TEAS was unavailable on the date of the deadline;  
(iii) A statement of the facts relevant to the petition, supported by a declaration under § 2.20 or 
28 U.S.C. 1746 that is signed by the petitioner, someone with legal authority to bind the petitioner 
(e.g., a corporate officer or general partner of a partnership), or a practitioner qualified to practice 
under § 11.14 of this chapter;  

 -100- July 15, 2026 
(iv) The fee for a petition filed on paper under §  2.6(a)(15)(i); and  
(v) Any other required fee(s) under §  2.6 for the paper submission.  
(b) Certain paper submissions timely filed before the date of a filing deadline. (1) An applicant, 
registrant, or petitioner for cancellation may file a petition to the Director under this section, 
requesting acceptance of any of the following submissions that was timely submitted on paper and 
otherwise met the minimum filing requirements, bu t not processed or examined by the Office 
because it was not submitted electronically pursuant to §  2.21(a), §  2.23(a), or §  2.111(c)(1), and 
the applicant, registrant, or petitioner for cancellation is unable to timely resubmit the document 
electronically by the deadline: 
(i) An application seeking a priority filing date with a deadline under section 44(d)(1) of the Act; 
(ii) A statement of use filed within the last six months of the period specified in section 1(d)(2) of 
the Act; 
(iii) An affidavit or declaration of continued use or excusable nonuse with a deadline under 
section 8(a)(3) or section 71(a)(3) of the Act;  
(iv) A request for renewal of a registration with a deadline under section 9(a) of the Act;  
(v) An application for transformation of an extension of protection into a United States application 
with a deadline under section 70(c) of the Act; or  
(vi) A petition to cancel a registration under section 14 of the Act on the fifth year anniversary of 
the date of the registration of the mark.  
(2) The petition must be filed by not later than two months after the issue date of the notice 
denying acceptance of the paper filing and must include:  
(i) A statement of the facts relevant to the petition, supported by a declaration under § 2.20 or 
28 U.S.C. 1746 that is signed by the petitioner, someone with legal authority to bind the petitioner 
(e.g., a corporate officer or general partner of a partnership), or a practitioner qualified to practice 
under § 11.14 of this chapter;  
(ii) A copy of the relevant paper submission and proof that it was timely filed;  
(iii) Proof that a sufficient fee accompanied the original paper submission;  
(iv) The required fee(s) under § 2.6 for the paper submission; and  
(v) The relevant petition fee under §  2.6(a)(15). 
(c) Petition under § 2.146. If the applicant or registrant is unable to meet the requirements under 
paragraphs (a) or (b) of this section for filing the petition, the applicant or registrant may submit a 
petition to the Director under §   2.146(a)(5) to request a waiver of §   2.21(a) or §   2.23(a). 
(d) This section does not apply to requirements for paper submissions to the Trademark Trial and 
Appeal Board except as specified in paragraph (b)(vi).  
[84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 
§ 2.148  Director may suspend certain rules.  
In an extraordinary situation, when justice requires and no other party is injured thereby, any 
requirement of the rules in parts 2, 3, 6, and 7 of this chapter that is not a requirement of the Act 
may be suspended or waived by the Director.  
[68 FR 14332, March 25, 2003, effective May 1, 2003; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020] 
§ 2.149  Letters of prote st against pending applications.  
(a) A third party may submit, for consideration and inclusion in the record of a trademark 
application, objective evidence relevant to the examination of the application for a ground for refusal 
of registration if the submission is made in accordance with this  section.  
(b) A party protesting multiple applications must file a separate submission under this section 
for each application. 

 -101- July 15, 2026 
(c) Any submission under this section must be filed no later than 30 days after the date the 
application is published for opposition under section 12(a) of the Act and § 2.80 of this part. If the 
subject application cannot be withdrawn from issuance of a registration while consideration of the 
protest is pending, the protest may be considered untimely.  
(d)(1) If the letter of protest is filed before publication of the subject application, the evidence 
must be relevant to the identified ground(s) for refusal, such that it is appropriate for the examining 
attorney to consider whether to issue a refusal or make a requirement under the Act or this part.  
(2) If the letter of protest is filed on or within 30 days after the date of publication of the subject 
application, the evidence must establish a prima facie case for refusal on the identified ground(s), 
such that failure to issue a refusal or to make a r equirement would likely result in issuance of a 
registration in violation of the Act or parts 2 or 7 of this section.  
(e) Filing a submission under this section does not stay or extend the time for filing a notice of 
opposition. 
(f) Any submission under this section must be made in writing, filed through TEAS, and include: 
(1) The fee required by § 2.6(a)(25);  
(2) The serial number of the pending application that is the subject of the protest;  
(3) An itemized evidence index that does not identify the protestor or its representatives, does 
not contain legal argument, and includes: 
(i) An identification of the documents, or portions of documents, being submitted as evidence. 
The submission may not total more than 10 items of evidence in support of a specified ground of 
refusal and more than 75 total pages of evidence without a detailed and sufficient explanation that 
establishes the special circumstances that necessitate providing more than 10 items of evidence 
per refusal ground or more than 75 total pages of evidence; and  
(ii) A concise factual statement of the relevant ground(s) for refusal of registration appropriate 
in ex parte examination that each item identified supports; and  
(4) A clear and legible copy of each item identified in the evidence index where:  
(i) Copies of third-party registrations come from the electronic records of the Office and show 
the current status and title of the registration;  
(ii) Evidence from the internet includes the date the evidence was published or accessed and 
the complete URL address of the website; and  
(iii) Copies of printed publications identify the publication name and date of publication.  
(g) Any submission under this section may not be entered or considered by the Office if:  
(1) Any part of the submission is not in compliance with this section;  
(2) The application record shows that the examining attorney already considered the refusal 
ground(s) specified in the submission; or  
(3) A provision of the Act or parts 2 or 7 of this chapter precludes acceptance of the submission. 
(h) If a submission is determined to be in compliance with this section, only the specified 
ground(s) for refusal and the provided evidence relevant to the ground(s) for refusal will be included 
in the application record for consideration by the examining attorney. An applicant should not reply 
to the entry into the application record of evidence entered under this section.  
(i) Any determination whether to include evidence submitted under this section in the record of 
an application is final and non-reviewable, and a determination to include or not include evidence 
in the application record shall not prejudice any party's right to ra ise any issue and rely on any 
evidence in any other proceeding.   
(j) A third party filing a submission under this section will not receive any communication from 
the Office relating to the submission other than acknowledgement that it has been received by the 
Office and notification of whether the submission is found to be compliant or non-compliant with this 
section. Communications with the third party will not be made of record in the application. The Office 
will not accept amendments to a non-compliant submission that was previously filed. Instead, a third 
party who previously filed a non-compliant submission may file another submission that meets the 
requirements of paragraph (f) of this section, provided the time period for filing a submission in 
paragraph (c) of this section has not closed.  

 -102- July 15, 2026 
(k) The limited involvement of the third party ends with the filing of the submission under this 
section. The third party may not directly contact the examining attorney assigned to the application. 
[85 FR 73197, Nov. 17, 2020, effective Jan. 2, 2021; 86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021] 
CERTIFICATE 
§ 2.151  Certificate.  
When the Office determines that a mark is registrable, the Office will issue to the owner a 
certificate of registration on the Principal Register or the Supplemental Register. The certificate will 
state the application filing date, the act under which the mark is registered, the date of issue, and 
the number of the registration and will include a reproduction of the mark and pertinent data from 
the application. A notice of the requirements of sections 8 and 71 of the Act will issue with the 
certificate. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 
84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 
PUBLICATION OF MARKS REGISTERED UNDER 1905 ACT 
§ 2.153  Publication requirements.  
The owner of a mark registered under the provisions of the Trademark Act of 1881 or 1905 may 
at any time prior to the expiration of the period for which the registration was issued or renewed, 
upon the payment of the prescribed fee, file an affidavit or declaration in accordance with § 2.20 
setting forth those goods or services in the registration on or in connection with which said mark is 
in use in commerce, and stating that the owner claims the benefits of the Act of 1946.  The affidavit 
or declaration must be signed by a person properly authorized to sign on behalf of the owner under 
§ 2.193(e)(1).  
[31 FR 5262, Apr. 1, 1966; amended 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 
26, 2009, effective Dec. 28, 2009]  
§ 2.154  Publication in Official Gazette.  
A notice of the claim of benefits under the Act of 1946 and a reproduction of the mark will then 
be published in the Official Gazette as soon as practicable.  The published mark will retain its original 
registration number. 
§ 2.155  Notice of publication.  
The Office will send the registrant a notice of publication of the mark and of the requirement for 
filing the affidavit or declaration required by section 8 of the Act.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999]  
§ 2.156  Not subject to opposition; subject to cancellation.  
The published mark is not subject to opposition, but is subject to petitions to cancel as specified 
in § 2.111 and to cancellation for failure to file the affidavit or declaration required by section 8 of 
the Act. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999]  

 -103- July 15, 2026 
REREGISTRATION OF MARKS REGISTERED UNDER PRIOR ACTS 
§ 2.158  Reregistration of marks registered under Acts of 1881, 1905, and 1920.  
Trademarks registered under the Act of 1881, the Act of 1905 or the Act of 1920 may be 
reregistered under the Act of 1946, either on the Principal Register, if eligible, or on the 
Supplemental Register, but a new complete application for registration must be filed complying with 
the rules relating thereto, and such application will be subject to examination and other proceedings 
in the same manner as other applications filed under the Act of 1946.  See § 2.26 for use of old 
drawing. 
CANCELLATION FOR FAILURE TO FILE AFFIDAVIT OR DECLARATION  
§ 2.160  Affidavit or declaration of continued use or excusable nonuse required to avoid 
cancellation of registration.  
(a) During the following time periods, the owner of the registration must file an affidavit or 
declaration of continued use or excusable nonuse, or the registration will be cancelled:  
(1)(i) For registrations issued under the Trademark Act of 1946, on or after the fifth anniversary 
and no later than the sixth anniversary after the date of registration; or  
(ii) For registrations issued under prior Acts, on or after the fifth anniversary and no later than 
the sixth anniversary after the date of publication under section 12(c) of the Act; and  
(2) For all registrations, within the year before the end of every ten-year period after the date of 
registration. 
(3) The affidavit or declaration may be filed within a grace period of six months after the end of 
the deadline set forth in paragraphs (a)(1) and (a)(2) of this section, with payment of the grace 
period surcharge per class required by section 8( a)(3) of the Act and §  2.6.  
(b) For the requirements for the affidavit or declaration, see §  2.161. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; amended 75 FR 35973, June 24, 2010, effective June 
24, 2010] 
§ 2.161  Requirements for a complete affidavit or declaration of use in commerce or 
excusable nonuse; requirement for the submission of additional information, exhibits, 
affidavits or declarations, and specimens; and fee for deletions of goods, services, and/or 
classes from a registration.  
(a) Requirements for a complete affidavit or declaration.  A complete affidavit or declaration 
under section 8 of the Act must:  
(1) Be filed by the owner within the period set forth in § 2.160(a);  
(2) Include a verified statement attesting to the use in commerce or excusable nonuse of the 
mark within the period set forth in section 8 of the Act. This verified statement must be executed on 
or after the beginning of the filing period specified in § 2. 160(a); 
(3) Include the U.S. registration number;  
(4)(i) Include the fee required by § 2.6 for each class that the affidavit or declaration covers; 
(ii) If the affidavit or declaration is filed during the grace period under section 8(a)(3) of the Act, 
include the grace period surcharge per class required by § 2.6; and  
(iii) If at least one fee is submitted for a multiple-class registration, but the fee is insufficient to 
cover all the classes, and the class(es) to which the fee(s) should be applied is not specified, the 
Office will issue a notice requiring either submission of the additional fee(s) or specification of the 
class(es) to which the initial fee(s) should be applied. Additional fees may be submitted if the 
requirements of § 2.164 are met. If the additional fee(s) is not submitted within the time period set 
out in the Office action, and the class(es) to which the original fee(s) should be applied is not 

 -104- July 15, 2026 
specified, the Office will presume that the fee(s) covers the classes in ascending order, beginning 
with the lowest numbered class; 
(5)(i) Specify the goods, services, or nature of the collective membership organization for which 
the mark is in use in commerce, and/or the goods, services, or nature of the collective membership 
organization for which excusable nonuse is claimed under paragraph (a)(6)(ii) of this section; and 
(ii) Specify the goods, services, or classes being deleted from the registration, if the affidavit or 
declaration covers fewer than all the goods, services, or classes in the registration;  
(6)(i) State that the registered mark is in use in commerce; or  
(ii) If the registered mark is not in use in commerce on or in connection with all the goods, 
services, or classes specified in the registration, set forth the date when such use of the mark in 
commerce stopped and the approximate date when such use is expected to resume, and recite 
facts to show that nonuse as to those goods, services, or classes is due to special circumstances 
that excuse the nonuse and is not due to an intention to abandon the mark; and  
(7) Include one specimen showing how the mark is in use in commerce for each class in the 
registration, unless excusable nonuse is claimed under paragraph (a)(6)(ii) of this section. When 
requested by the Office, additional specimens must be provided. The specimen must meet the 
requirements of § 2.56.  
(8) Additional requirements for a collective mark: In addition to the above requirements, a 
complete affidavit or declaration pertaining to a collective mark must: 
(i) State that the owner is exercising legitimate control over the use of the mark in commerce; 
and 
(ii) If the registration issued from an application based solely on section 44 of the Act, state the 
nature of the owner's control over the use of the mark by the members in the first affidavit or 
declaration filed under paragraph (a)(1) of this section.  
(9) Additional requirements for a certification mark: In addition to the above requirements, a 
complete affidavit or declaration pertaining to a certification mark must:  
(i) Include a copy of the certification standards specified in § 2.45(a)(4)(i)(B);  
(A) Submitting certification standards for the first time.  If the registration issued from an 
application based solely on section 44 of the Act, include a copy of the certification standards in the 
first affidavit or declaration filed under paragraph (a)(1) of this section; or  
(B) Certification standards submitted in prior filing. If the certification standards in use at the time 
of filing the affidavit or declaration have not changed since the date they were previously submitted 
to the Office, include a statement to that effect. If the certification standards in use at the time of 
filing the affidavit or declaration have changed since the date they were previously submitted to the 
Office, include a copy of the revised certification standards;  
(ii) State that the owner is exercising legitimate control over the use of the mark in commerce; 
and 
(iii) Satisfy the requirements of § 2.45(a)(4)(i)(A) and (C).  
(10) For requirements of a complete affidavit or declaration of use in commerce or excusable 
nonuse for a registration that issued from a section 66(a) basis application, see § 7.37.  
(b) Requirement for the submission of additional information, exhibits, affidavits or declarations, 
and specimens. The Office may require the owner to furnish such information, exhibits, affidavits or 
declarations, and such additional specimens as may be reasonably necessary to the proper 
examination of the affidavit or declaration under section 8 of the Act or for the Office to assess and 
promote the accuracy and integrity of the register.  
(c) Fee for deletions of goods, services, and/or classes from a registration.  Deletions by the 
owner of goods, services, and/or classes from a registration after submission and prior to 
acceptance of the affidavit or declaration must be accompanied by the relevant fee in § 2.6(a)(12)(iii) 
or (iv). 
[41 FR 761, Jan. 5, 1976, as amended at 47 FR 41282, Sept. 17, 1982; 48 FR 3977, Jan. 28, 1983; 54 FR 
37597, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 67 FR 79520, Dec. 30, 2002; 68 
FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 47650, Aug 14. 2008, effective Sept. 15, 2008; 73 
FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 75 

 -105- July 15, 2026 
FR 35973, June 24, 2010, effective June 24, 2010; 77 FR 30197, May 22, 2012, effective June 21, 2012; 80 
FR 33170, June 11, 2015, effective July 11, 2015; 82 FR 6259, Jan. 19, 2017, effective Mar. 21, 2017; 85 FR 
73197, Nov. 17, 2020, effective Jan. 2, 2021 ] 
§ 2.162  Notice to registrant.  
When a certificate of registration is originally issued, the Office issues with the certificate a notice 
of the requirement for filing the affidavit or declaration of use or excusable nonuse under section 8 
or section 71 of the Act. However, the affidavit or declaration must be filed within the time period 
required by section 8 or section 71 of the Act even if this notice is not received.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020] 
§ 2.163  Acknowledgment of receipt of affidavit or declaration.  
The Office will issue a notice as to whether an affidavit or declaration is acceptable, or the 
reasons for refusal.   
(a) If the affidavit or declaration is filed within the time periods set forth in section 8 of the Act, 
deficiencies may be corrected after notification from the Office if the requirements of § 2.164 are 
met. 
(b) A response to the refusal must be filed within six months of the date of issuance of the Office 
action, or before the end of the filing period set forth in section 8(a) of the Act, whichever is later.  
The response must be signed by the owner, someone with legal authority to bind the owner (e.g., 
a corporate officer or general partner of a partnership), or a practitioner qualified to practice under 
§ 11.14 of this chapter, in accordance with the requirements of §  2.193(e)(2).  
(c) If no response is filed within this time period, the registration will be cancelled, unless time 
remains in the grace period under section 8(a)(3) of the Act.  If time remains in the grace period, 
the owner may file a complete new affidavit.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; amended 73 FR 67759, Nov. 17, 2008, effective Jan. 
16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 75 FR 35973, June 24, 2010, effective June 
24, 2010; 76 FR 69132, Nov. 8, 2011, effective Nov. 8, 2011 ] 
§ 2.164  Correcting deficiencies in affidavit or declaration.  
(a) If the affidavit or declaration is filed within the time periods set forth in section 8 of the Act, 
deficiencies may be corrected after notification from the Office, as follows:  
(1) Correcting deficiencies in affidavits or declarations timely filed within the periods set forth in 
sections 8(a)(1) and 8(a)(2) of the Act.  If the affidavit or declaration is timely filed within the relevant 
filing period set forth in section 8(a)(1) or section 8(a)(2) of the Act, deficiencies may be corrected 
before the end of this filing period without paying a deficiency surcharge.  Deficiencies may be 
corrected after the end of this filing period with payment of the deficiency surcharge required by 
section 8(c) of t he Act and § 2.6.   
(2) Correcting deficiencies in affidavits or declarations filed during the grace period .  If the 
affidavit or declaration is filed during the six-month grace period provided by section 8(a)(3) of the 
Act, deficiencies may be corrected before the expiration of the grace period without paying a 
deficiency surcharge.  Deficiencies may be corrected after the expiration of the grace period with 
payment of the deficiency surcharge required by sectio n 8(c) of the Act and §  2.6.   
(b) If the affidavit or declaration is not filed within the time periods set forth in section 8 of the 
Act, the registration will be cancelled.   
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; amended 75 FR 35973, June 24, 2010, effective June 
24, 2010; 76 FR 69132, Nov. 8, 2011, effective Nov. 8, 2011 ] 

 -106- July 15, 2026 
§ 2.165  Petition to Director to review refusal.  
(a) A response to the examiner’s initial refusal to accept an affidavit or declaration is required 
before filing a petition to the Director, unless the examiner directs otherwise.  See § 2.163(b) for the 
deadline for responding to an examiner’s Office acti on. 
(b) If the examiner maintains the refusal of the affidavit or declaration, the owner may file a 
petition to the Director to review the action.  The petition must be filed within six months of the date 
of issuance of the action maintaining the refusal, or the Office will cancel the registration and issue 
a notice of the cancellation. 
(c) A decision by the Director is necessary before filing an appeal or commencing a civil action 
in any court. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; amended 68 FR 14332, March 25, 2003, effective May 
1, 2003; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.166  Affidavit of continued use or excusable nonuse combined with renewal 
application.  
An affidavit or declaration under section 8 of the Act and a renewal application under section 9 
of the Act may be combined into a single document, provided that the document meets the 
requirements of both sections 8 and 9 of the Act.   
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999]  
AFFIDAVIT OR DECLARATION UNDER SECTION 15 
§ 2.167  Affidavit or declaration under section 15.  
The affidavit or declaration in accordance with § 2.20 provided by section 15 of the Act for 
acquiring incontestability for a mark registered on the Principal Register or a mark registered under 
the Trademark Act of 1881 or 1905 and published under section 12(c) of the Act (see § 2.153) must: 
(a) Be verified;   
(b) Identify the certificate of registration by the certificate number and date of registration;  
(c) For a trademark, service mark, collective trademark, collective service mark, and certification 
mark, recite the goods or services stated in the registration on or in connection with which the mark 
has been in continuous use in commerce for a period of five years after the date of registration or 
date of publication under section 12(c) of the Act, and is still in use in commerce; for a collective 
membership mark, describe the nature of the owner’s collective membership organization specified 
in the registration in connection with which the mark has been in continuous use in commerce for a 
period of five years after the date of registration or date of publication under section 12(c) of the Act, 
and is still in use in commerce;  
(d) Specify that there has been no final decision adverse to the owner’s claim of ownership of 
such mark for such goods, services, or collective membership organization, or to the owner’s right 
to register the same or to keep the same on the register;  
(e) Specify that there is no proceeding involving said rights pending in the Office or in a court 
and not finally disposed of;  
(f) Be filed within one year after the expiration of any five-year period of continuous use following 
registration or publication under section 12(c) of the Act; and  
(g) Include the fee required by § 2.6 for each class to which the affidavit or declaration pertains 
in the registration.  If no fee, or a fee insufficient to cover at least one class, is filed at an appropriate 
time, the affidavit or declaration will not be refused if the required fee(s) (see § 2.6) is filed in the 
Office within the time limit set forth in the notification of this defect by the Office.  If the submitted 
fees are insufficient to cover all classes in the registration, the particular class or classes to which 
the affidavit or declaration pertains should be specified.  

 -107- July 15, 2026 
(h) If the affidavit or declaration fails to satisfy any of the requirements in paragraphs (a) through 
(g) of this section, the owner will be notified in an Office action that the affidavit or declaration cannot 
be acknowledged.  If a response is not received within the time period provided or does not satisfy 
the requirements of the Office action, the affidavit or declaration will be abandoned.   
(i) If the affidavit or declaration satisfies paragraphs (a) through (g) of this section, the Office will 
issue a notice of acknowledgement.  
(j) An affidavit or declaration may be abandoned by the owner upon petition to the Director under 
§ 2.146 either before or after the notice of acknowledgement has issued.   
(k) If an affidavit or declaration is abandoned, the owner may file a new affidavit or declaration 
with a new filing fee.  
[30 FR 13193, Oct. 16, 1965, as amended at 47 FR 41282, Sept. 17, 1982; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, 
effective Dec. 28, 2009 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.168  Affidavit or declaration under section 15 combined with affidavit or declaration 
under section s 8 or 71, or with renewal application.  
(a) The affidavit or declaration filed under section 15 of the Act may also be used as the affidavit 
or declaration required by section 8, if the affidavit or declaration meets the requirements of both 
sections 8 and 15.  The affidavit or declaration filed under section 15 of the Act may also be used 
as the affidavit or declaration required by section 71, if the affidavit or declaration meets the 
requirements of both sections 71 and 15.  
(b) The affidavit or declaration filed under section 15 of the Act may be combined with an 
application for renewal of a registration under section 9 of the Act, if the requirements of both 
sections 9 and 15 are met. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; amended 75 FR 35973, June 24, 2010, effective June 
24, 2010] 
CORRECTION, DISCLAIMER, SURRENDER, ETC. 
§ 2.171  New certificate on change of ownership.  
(a) Full change of ownership.  If the ownership of a registered mark changes, the new owner 
may request that a new certificate of registration be issued in the name of the new owner.  The 
assignment or other document changing title must be recorded in the Office.  The request for the 
new certificate must include the fee required by §  2.6(a)(8) and be signed by the owner of the 
registration, someone with legal authority to bind the owner ( e.g., a corporate officer or general 
partner of a partnership), or a practitioner qualified to practice under § 11.14 of this chapter.  In a 
registered extension of protection, the assignment must be recorded with the International Bureau 
of the World Intellectual Property Organization before it can be recorded in the Office (see § 7.22).   
(b) Partial change of ownership .   
(1) In a registration resulting from an application based on section 1 or section 44 of the Act, if 
ownership of a registration has changed with respect to some but not all of the goods and/or 
services, the owner(s) may file a request that the registration be divided into two or more separate 
registrations.  The assignment or other document changing title must be recorded in the Office.  The 
request to divide must include the fee required by § 2.6(a)(8) for each new registration created by 
the division, and be signed by the owner of the registration, someone with legal authority to bind the 
owner (e.g., a corporate officer or general partner of a partnership), or a practitioner qualified to 
practice under § 11.14 of this chapter, in accordance with §  2.193(e)(2) of this chapter.  
(2)(i) When the International Bureau of the World Intellectual Property Organization notifies the 
Office that an international registration has been divided as the result of a change of ownership with 
respect to some but not all of the goods and/or services, the Office will construe the International 

 -108- July 15, 2026 
Bureau’s notice as a request to divide. The Office will update Office records to reflect the change in 
ownership, divide out the assigned goods and/or services from the registered extension of 
protection (parent registration), and publish notice of the parent registration in the Official Gazette.  
(ii) The Office will create a new registration number for the child registration, and enter the 
information about the new registration in its automated records.  The Office will notify the new owner 
that the new owner must pay the fee required by § 2.6 to obtain a new registration certificate for the 
child registration.  It is not necessary for the new owner to file a separate request to divide.   
(iii) The Office will not divide a registered extension of protection unless the International Bureau 
notifies the Office that the international registration has been divided.   
[31 FR 5262, Apr. 1, 1966; 68 FR 55748, Sept. 26, 2003, effective Nov. 2, 2003; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 80 FR 2303, Jan. 16, 2015, 
effective Feb. 17, 2015 ] 
§ 2.172  Surrender for cancellation.  
Upon application by the owner, the Director may permit any registration to be surrendered for 
cancellation.  The application for surrender must be signed by the owner of the registration, 
someone with legal authority to bind the owner (e.g., a corporate of ficer or general partner of a 
partnership), or a practitioner qualified to practice under § 11.14 of this chapter.  When a registration 
has more than one class, one or more entire class(es) but fewer than the total number of classes 
may be surrendered.  Deletion of fewer than all the goods or services in a single class constitutes 
amendment of the registration as to that class (see § 2.173), rather than surrender.  A surrender for 
cancellation may not subsequently be withdrawn.  
[41 FR 761, Jan. 5, 1976; 68 FR 14332, March 25, 2003, effective May 1, 2003; 69 FR 51362, Aug. 19, 2004, 
effective Sept. 20, 2004; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 80 FR 2303, Jan. 16, 2015, 
effective Feb. 17, 2015 ] 
§ 2.173  Amendment of registration  
(a) Form of amendment.  The owner of a registration may apply to amend a registration or to 
disclaim part of the mark in the registration.  The owner must submit a written request specifying 
the amendment or disclaimer.  If the registration is involved in an inter partes proceeding before the 
Trademark Trial and Appeal Board, the request must be filed by appropriate motion to the Board.   
(b) Requirements for request .  A request for amendment or disclaimer must:  
(1) Include the fee required by §  2.6; 
(2) Be verified and signed in accordance with § 2.193(e)(6); and  
(3) If the amendment involves a change in the mark:  one new specimen per class showing the 
mark as used on or in connection with the goods, services, or collective membership organization; 
a verified statement that the specimen was in use in commerce at least as early as the filing date 
of the amendment; and a new drawing of the amended mark.  When requested by the Office, 
additional specimens must be provided. 
(4) The Office may require the owner to furnish such specimens, information, exhibits, and 
affidavits or declarations as may be reasonably necessary to the proper examination of the 
amendment. 
(c) Registration must still contain registrable matter.  The registration as amended must still 
contain registrable matter, and the mark as amended must be registrable as a whole.   
(d) Amendment may not materially alter the mark.  An amendment or disclaimer that materially 
alters the character of the mark will not be permitted, in accordance with section 7(e) of the Act.   
(e) Amendment of identification of goods, services, or collective membership organization.  No 
amendment in the identification of goods or services, or description of the nature of the collective 
membership organization, in a registration will be permitted except to restrict the identification or to 
change it in ways that would not require rep ublication of the mark.   

 -109- July 15, 2026 
(f) Amendment of certification statement for certification marks .  An amendment of the 
certification statement specified in § 2.45(a)(4)(i)(A) or (a)(4)(ii)(A) that would materially alter the 
certification statement will not be permitted, in accordance with section 7(e) of the Act.  
(g) Conforming amendments may be required .  If the registration includes a disclaimer, 
description of the mark, or other miscellaneous statement, any request to amend the registration 
must include a request to make any necessary conforming amendments to the disclaimer, 
description, or other state ment.   
(h) Elimination of disclaimer.  No amendment seeking the elimination of a disclaimer will be 
permitted, unless deletion of the disclaimed portion of the mark is also sought.  
(i) No amendment to add or delete section 2(f) claim of acquired distinctiveness.  An amendment 
seeking the addition or deletion of a claim of acquired distinctiveness will not be permitted.  
[30 FR 13193, Oct. 16, 1965, as amended at 31 FR 5262, Apr. 1, 1966; 48 FR 23141, May 23, 1983; 64 FR 
48900, Sept. 8, 1999, effective Oct. 30, 1999; 69 FR 51362, Aug. 19, 2004, effective Sept. 20, 2004; 72 FR 
42242, Aug. 1, 2007, effective Aug. 31, 2007; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 77 FR 
30197, May 22, 2012, effective June 21, 2012; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.174  Correction of Office mistake.  
Whenever Office records clearly disclose a material mistake in a registration, incurred through 
the fault of the Office, the Office will issue a certificate of correction stating the fact and nature of 
the mistake, signed by the Director or by an employee designated by the Director, without charge.  
Thereafter, the corrected certificate shall have the same effect as if it had been originally issued in 
the corrected form.  In the discretion of the Director, the Office may issue a new certificate of 
registration without charge. 
[68 FR 14332, March 25, 2003, effective May 1, 2003; 69 FR 51362, Aug. 19, 2004, effective Sept. 20, 2004; 
73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
§ 2.175  Correction of mistake by owner.  
(a) Whenever a mistake has been made in a registration and a showing has been made that 
the mistake occurred in good faith through the fault of the owner, the Director may issue a certificate 
of correction.  In the discretion of the Director, the Office may issue a new certificate upon payment 
of the required fee, provided that the correction does not involve such changes in the registration 
as to require republication of the mark.  
(b) An application for such action must:  
(1) Include the following:  
(i) Specification of the mistake for which correction is sought;  
(ii) Description of the manner in which it arose; and  
(iii) A showing that it occurred in good faith;  
(2) Be verified; and  
(3) Be accompanied by the required fee.   
[30 FR 13193, Oct. 16, 1965, as amended at 31 FR 5262, Apr. 1, 1966; 68 FR 14332, March 25, 2003, 
effective May 1, 2003; 69 FR 51362, Aug. 19, 2004, effective Sept. 20, 2004; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.176  Consideration of above matters.  
The matters in §§ 2.171 to 2.175 will be considered in the first instance by the Post Registration 
examiners, except for requests to amend registrations involved in inter partes proceedings before 
the Trademark Trial and Appeal Board, as specified in § 2.173(a), which shall be considered by the 
Board.  If an action of the examiner is adverse, the owner of the registration may petition the Director 

 -110- July 15, 2026 
to review the action under §  2.146.  If the owner does not respond to an adverse action of the 
examiner within six months of the date of issuance, the matter will be considered abandoned.  
[68 FR 14332, March 25, 2003, effective May 1, 2003; 69 FR 51362, Aug. 19, 2004, effective Sept. 20, 2004; 
72 FR 42242, Aug. 1, 2007, effective Aug. 31, 2007]  
COURT ORDERS UNDER SECTION 37 
§ 2.177  Action on court order under section 37 . 
(a) Requesting USPTO action on an order. If a Federal court has issued an order concerning a 
registration under section 37 of the Act, a party to the court action who is requesting that the USPTO 
take action on the order must make the request in writing and include the following:  
(1) Submit a certified copy of the order to the Director, addressed to the Office of the General 
Counsel, as provided in § 104.2 of this chapter; and  
(2) If the party is aware of proceedings concerning the involved registration that are pending or 
suspended before the Trademark Trial and Appeal Board, file a copy of such order with the 
Trademark Trial and Appeal Board via ESTTA. 
(b) Time for submission. A submission under paragraph (a) of this section should not be made 
until after the court proceeding has been finally determined. A court proceeding is not considered 
finally determined until an order or ruling that ends the litigation has been rendered and noticed, 
and the time for any appeal or other further review has expired with no further review sought.  
(c) Action after submission. After the court proceeding has been finally determined, appropriate 
action on a court order submitted under this section will normally be taken by the Office without the 
necessity of any further submission by an interested party. In circumstances where the Director or 
the Trademark Trial and Appeal Board, if the order under section 37 involves a registration over 
which the Board has jurisdiction, determines that it would be helpful to aid in understanding the 
scope or effect of the court's order, a show cause or other order may issue directing the registrant, 
and if appropriate, the opposing parties to the action from which the order arose, to respond and 
provide information or arguments regarding the order. The Director may also request clarification of 
the order from the court that issued the order.  
[86 FR 64300, Nov. 17, 2021, effective Dec. 18, 2021 ] 
TERM AND RENEWAL 
§ 2.181  Term of original registrations and renewals.  
(a)(1) Subject to the provisions of section 8 of the Act requiring an affidavit or declaration of 
continued use or excusable nonuse, registrations issued or renewed prior to November 16, 1989, 
whether on the Principal Register or on the Supplemental Register, remain in force for twenty years 
from their date of issue or the date of renewal, and may be further renewed for periods of ten years, 
unless previously cancelled or surrendered.  
(2) Subject to the provisions of section 8 of the Act requiring an affidavit or declaration of 
continued use or excusable nonuse, registrations issued or renewed on or after November 16, 1989, 
whether on the Principal Register or on the Supplemental Register, remain in force for ten years 
from their date of issue or the date of renewal, and may be further renewed for periods of ten years, 
unless previously cancelled or surrendered.  
(b) Registrations issued under the Acts of 1905 and 1881 remain in force for their unexpired 
terms and may be renewed in the same manner as registrations under the Act of 1946.  
(c) Registrations issued under the Act of 1920 cannot be renewed unless renewal is required to 
support foreign registrations and in such case may be renewed on the Supplemental Register in 
the same manner as registrations under the Act of 1946.  

 -111- July 15, 2026 
[30 FR 13193, Oct. 16, 1965, as amended at 54 FR 37597, Sept. 11, 1989; 64 FR 48900, Sept. 8, 1999, 
effective Oct. 30, 1999]  
§ 2.182  Time for filing renewal application.  
An application for renewal must be filed within one year before the expiration date of the 
registration, or within the six-month grace period after the expiration date of the registration.  If no 
renewal application is filed within this period, the registr ation will expire. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999]  
§ 2.183  Requirements for a complete renewal application.  
A complete renewal application must include: 
(a) A request for renewal of the registration, signed by the registrant or the registrant’s 
representative; 
(b) The fee required by §  2.6 for each class; 
(c) The additional fee required by § 2.6 for each class if the renewal application is filed during 
the six-month grace period set forth in section 9(a) of the Act;  
(d) If the renewal application covers less than all the goods, services, or classes in the 
registration, then a list specifying the particular goods, services, or classes to be renewed.   
(e) If at least one fee is submitted for a multiple-class registration, but the fee is insufficient to 
cover all the classes and the class(es) to which the fee(s) should be applied are not specified, the 
Office will issue a notice requiring either the submission of additional fee(s) or an indication of the 
class(es) to which the original fee(s) should be applied.  Additional fee(s) may be submitted if the 
requirements of § 2.185 are met.  If the required fee(s) are not submitted and the class(es) to which 
the original fee(s) should be applied are not specified, the Office will presume that the fee(s) cover 
the classes in ascending order, beginning with the lowest numbered class.  
(f) Renewals of registrations issued under a prior classification system will be processed on the 
basis of that system, unless the registration has been amended to adopt international classification 
pursuant to § 2.85(e)(3).  
[30 FR 13193, Oct. 16, 1965, as amended at 31 FR 5262, Apr. 1, 1966; 41 FR 761, Jan. 5, 1976; 64 FR 
48900, Sept. 8, 1999, effective Oct. 30, 1999; 67 FR 79520, Dec. 30, 2002; 73 FR 67759, Nov. 17, 2008, 
effective Jan. 16, 2009 ; 80 FR 33170, June 11, 2015, effective July 11, 2015 ] 
§ 2.184  Refusal of renewal.  
(a) If the renewal application is not acceptable, the Office will issue a notice stating the reason(s) 
for refusal.   
(b)(1) The registrant must file a response to the refusal of renewal within six months of the date 
of issuance of the Office action, or before the expiration date of the registration, whichever is later.  
If no response is filed within this time period, the registration will expire, unless time remains in the 
grace period under section 9(a) of the Act.  If time remains in the grace period, the registrant may 
file a complete new renewal application. 
(2) The response must be signed by the registrant, someone with legal authority to bind the 
registrant (e.g., a corporate officer or general partner of a partnership), or a practitioner who meets 
the requirements of § 11.14 of this chapter, in accordance with the requirements of § 2.193(e)(2).   
(c) If the renewal application is not filed within the time periods set forth in section 9(a) of the 
Act, the registration will expire.  
[48 FR 23143, May 23, 1983; 64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 73 FR 67759, Nov. 17, 
2008, effective Jan. 16, 2009; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009]  

 -112- July 15, 2026 
§ 2.185  Correcting deficiencies in renewal application.  
(a) If the renewal application is filed within the time periods set forth in section 9(a) of the Act, 
deficiencies may be corrected after notification from the Office, as follows:  
(1) Correcting deficiencies in renewal applications filed within one year before the expiration 
date of the registration.  If the renewal application is filed within one year before the expiration date 
of the registration, deficiencies may be corrected before the expiration date of the registration 
without paying a deficiency surcharge.  Deficiencies may be corrected after the expiration date of 
the registration with payment of the deficiency surcharge required by section 9(a) of the Act and 
§ 2.6.   
(2) Correcting deficiencies in renewal applications filed during the grace period.  If the renewal 
application is filed during the six -month grace period, deficiencies may be corrected before the 
expiration of the grace period without paying a deficiency surcharge.  Deficiencies may be corrected 
after the expiration of the grace period with payment of the deficiency surcharge required by section 
9(a) of the Act and §  2.6.   
(b) If the renewal application is not filed within the time periods set forth in section 9(a) of the 
Act, the registration will expire.  This deficiency cannot be cured.  
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015] 
§ 2.186  Petition to Director to review refusal of renewal.  
(a) A response to the examiner’s initial refusal of the renewal application is required before filing 
a petition to the Director, unless the examiner directs otherwise.  See § 2.184(b) for the deadline for 
responding to an examiner’s Office action.  
(b) If the examiner maintains the refusal of the renewal application, a petition to the Director to 
review the refusal may be filed.  The petition must be filed within six months of the date of issuance 
of the Office action maintaining the refusal, or the renewal application will be abandoned and the 
registration will expire.    
(c) A decision by the Director is necessary before filing an appeal or commencing a civil action 
in any court. 
[64 FR 48900, Sept. 8, 1999, effective Oct. 30, 1999; 68 FR 14332, March 25, 2003, effective May 1, 2003; 
73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009]  
GENERAL INFORMATION AND CORRESPONDENCE IN TRADEMARK CASES 
§ 2.188  [Reserved]  
§ 2.189  Requirement to provide domicile address.  
An applicant or registrant must provide and keep current the address of its domicile, as defined 
in § 2.2(o).  
[84 FR 31498, July 2, 2019, effective Aug. 3, 2019]  
§ 2.190  Addresses for trademark correspondence with the United States Patent and 
Trademark Office.   
(a) Paper trademark documents. In general, trademark documents to be delivered by the USPS 
must be addressed to: Commissioner for Trademarks, P.O. Box 1451, Alexandria, VA 22313-1451. 
Trademark-related documents to be delivered by hand, private courier, or other delivery service 
may be delivered during the hours the Office is open to receive correspondence to the Trademark 
Assistance Center, James Madison Building—East Wing, Concourse Level, 600 Dulany Street, 
Alexandria, Virginia 22314. 

 -113- July 15, 2026 
(b) Electronic trademark documents .  Trademark documents filed electronically must be 
submitted through TEAS. Documents that relate to proceedings before the Trademark Trial and 
Appeal Board must be filed electronically with the Board through ESTTA.  
(c) Trademark assignment documents.  Requests to record documents in the Assignment 
Recordation Branch may be filed electronically through ETAS. Paper documents and cover sheets 
to be recorded in the Assignment Recordation Branch should be addressed as designated in §  3.27 
of this chapter.  
(d) Requests for certified copies of trademark documents. Paper requests for certified copies of 
trademark documents must be addressed to: Mail Stop Document Services, Director of the United 
States Patent and Trademark Office, P.O. Box 1450, Alexandria, Virginia 22313 -1450. 
(e) Certain documents relating to international applications and registrations.  International 
applications under § 7.11, subsequent designations under § 7.21, responses to notices of 
irregularity under §  7.14, requests to record changes in the International Register under §  7.23 and 
§  7.24, requests to note replacements under §  7.28, requests for transformation under §  7.31 of 
this chapter, and petitions to the Director to review an action of the Office's Madrid Processing Unit 
must be addressed to: Madrid Processing Unit, 600 Dulany Street, Alexandria, VA 22314-5796. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; amended 69 FR 57181, Sept. 24, 2004, 
effective Oct. 4, 2004; 69 FR 63320, Nov. 1, 2004; 72 FR 18907, April 16, 2007; 81 FR 69950, Oct. 7, 2016, 
effective January 14, 2017 ; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 
§ 2.191  Action of the Office based on the written record.    
All business with the Office must be transacted in writing. The action of the Office will be based 
exclusively on the written record. No consideration will be given to any alleged oral promise, 
stipulation, or understanding when there is disagreement or do ubt. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 81 FR 69950, Oct. 7, 2016, effective January 
14, 2017; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 
§ 2.192  Business to be conducted with decorum and courtesy.   
Trademark applicants, registrants, and parties to proceedings before the Trademark Trial and 
Appeal Board and their attorneys or agents are required to conduct their business with decorum 
and courtesy.  Documents presented in violation of this requirement will be submitted to the Director 
and will be returned by the Director’s direct order.  Complaints against trademark examining 
attorneys and other employees must be made in correspondence separate from other documents. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003]  
§ 2.193  Trademark correspondence and signature requirements.   
(a) Signature required.  Each piece of correspondence that requires a signature must bear:   
(1) A handwritten signature personally signed in permanent ink by the person named as the 
signatory, or a true copy thereof; or  
(2) An electronic signature that meets the requirements of paragraph (c) of this section, 
personally entered by the person named as the signatory.  The Office will accept an electronic 
signature that meets the requirements of paragraph (c) of this section on correspondence filed on 
paper or through TEAS or ESTTA.   
(b) Copy of original signature.  If a copy of an original signature is filed, the filer should retain 
the original as evidence of authenticity.  If a question of authenticity arises, the Office may require 
submission of the original.   
(c) Requirements for electronic signature.  A person signing a document electronically must:    

 -114- July 15, 2026 
(1) Personally enter any combination of letters, numbers, spaces and/or punctuation marks that 
the signer has adopted as a signature, placed between two forward slash (“/”) symbols in the 
signature block on the electronic submission; or  
(2) Sign the document using some other form of electronic signature specified by the Director.  
(d) Signatory must be identified.  The first and last name, and the title or position, of the person 
who signs a document in connection with a trademark application, registration, or proceeding before 
the Trademark Trial and Appeal Board must be set forth immediately below or adjacent to th e 
signature.   
(e) Proper person to sign .  Documents filed in connection with a trademark application or 
registration must be signed as specified in paragraphs (e)(1) through (9) of this section:    
(1) Verified statement of facts.  A verified statement in support of an application for registration, 
amendment to an application for registration, allegation of use under § 2.76 or § 2.88, request for 
extension of time to file a statement of use under § 2.89, or an affidavit under section 8, 12(c), 15, 
or 71 of the Act must satisfy the requirements of § 2.2(n), and be signed by the owner or a person 
properly authorized to sign on behalf of the owner.  A person who is properly authorized to verify 
facts on behalf of an owner is:  
(i) A person with legal authority to bind the owner (e.g., a corporate officer or general partner of 
a partnership);  
(ii) A person with firsthand knowledge of the facts and actual or implied authority to act on behalf 
of the owner; or  
(iii) An attorney as defined in § 11.1 of this chapter who has an actual written or verbal power of 
attorney or an implied power of attorney from the owner.   
(2) Responses, amendments to applications, requests for express abandonment, requests for 
reconsideration of final actions, and requests to divide.  Responses to Office actions, amendments 
to applications, requests for express abandonment, requests for reconsideration of final actions, 
and requests to divide must be signed by the owner of the application or registration, someone with 
legal authority to bind the owner (e.g. a corporate officer or general partner of a partnership), or a 
practitioner qualified to practice under § 11.14 of this chapter, in accordance with the following 
guidelines: 
(i) If the owner is represented by a practitioner qualified to practice before the Office under § 
11.14 of this chapter, the practitioner must sign, except where the owner is required to sign the 
correspondence; or  
(ii) If the owner is not represented by a practitioner qualified to practice under § 11.14 of this 
chapter, the individual owner or someone with legal authority to bind the owner (e.g., a corporate 
officer or general partner of a partnership) must sign.  In the case of joint owners who are not 
represented by a qualified practitioner, all must sign.   
(3) Powers of attorney and revocations of powers of attorney .  Powers of attorney and 
revocations of powers of attorney must be signed by the individual applicant, registrant or party to 
a proceeding pending before the Office, or by someone with legal authority to bind the applicant, 
registrant, or party (e.g., a corporate officer or general partner of a partnership).  In the case of joint 
applicants, registrants, or parties, all must sign.  Once the applicant, registrant or party has 
designated a qualified  practitioner(s), the named practitioner may sign an associate power of 
attorney appointing another qualified practitioner(s) as an additional person(s) authorized to 
prosecute the application or registration.  If the applicant, registrant, or party revokes the original 
power of attorney, the revocation discharges any associate power signed by the practitioner whose 
power has been revoked.  If the practitioner who signed an associate power withdraws, the 
withdrawal discharges any associate power signed by the withdrawing practitioner upon acceptance 
of the request for withdrawal by the Office.  
(4) Petitions to revive under §  2.66.  A petition to revive under §  2.66 must be signed by 
someone with firsthand knowledge of the facts regarding unintentional delay.  
(5) Petitions to Director under § 2.146 or § 2.147 or for expungement or reexamination under  
§ 2.91.  A petition to the Director under § 2.146 or § 2.147 or for expungement or reexamination 
under § 2.91 must be signed by the petitioner, someone with legal authority to bind the petitioner 

 -115- July 15, 2026 
(e.g., a corporate officer or general partner of a partnership), or a practitioner qualified to practice 
under § 11.14 of this chapter, in accordance with the following guidelines:  
(i) If the petitioner is represented by a practitioner qualified to practice before the Office under § 
11.14 of this chapter, the practitioner must sign; or  
(ii) If the petitioner is not represented by a practitioner authorized to practice before the Office 
under § 11.14 of this chapter, the individual petitioner or someone with legal authority to bind the 
petitioner (e.g., a corporate officer or general partner of a partnership) must sign.  In the case of 
joint petitioners, all must sign.  
(6) Requests for correction, amendment or surrender of registrations.  A request for correction, 
amendment or surrender of a registration must be signed by the owner of the registration, someone 
with legal authority to bind the owner (e.g., a corporate officer or general partner of a partnership), 
or a practitioner qualified to practice before the Office under § 11.14 of this chapter.  In the case of 
joint owners who are not represented by a qualified practitioner, all must sign.   
(7) Renewal applications.  A renewal application must be signed by the registrant or the 
registrant’s representative.   
(8) Designations and revocations of domestic representative.  A designation or revocation of a 
domestic representative must be signed by the applicant or registrant, someone with legal authority 
to bind the applicant or registrant (e.g., a corporate officer or general partner of a partnership), or a 
practitioner qualified to practice under § 11.14 of this chapter.  In the case of joint applicants or 
registrants, all must sign.   
(9) Requests to change correspondence address in an application or registration.  A notice of 
change of correspondence address in an application or registration must be signed by the applicant 
or registrant, someone with legal authority to bind the applicant or registrant (e.g., a corporate officer 
or general partner of a partnership), or a practitioner qualified to practice under §  11.14 of this 
chapter, in accordance with the following guidelines:  
(i) If the applicant or registrant is represented by a practitioner qualified to practice before the 
Office under § 11.14 of this chapter, the practitioner must sign; or  
(ii) If the applicant or registrant is not represented by a practitioner qualified to practice before 
the Office under § 11.14, the individual applicant or registrant or someone with legal authority to 
bind the applicant or registrant (e.g., a corporate officer or general partner of a partnership) must 
sign.  In the case of joint applicants or joint registrants, all must sign.  
(f) Signature as certification .  The presentation to the Office (whether by signing, filing, 
submitting, or later advocating) of any document by any person, whether a practitioner or non -
practitioner, constitutes a certification under § 11.18(b) of this chapter.  Violations of § 11.18(b) of 
this chapter may jeopardize the validity of the application or registration, and may result in the 
imposition of sanctions under § 11.18(c) of this chapter.  Any practitioner violating § 11.18(b) of this 
chapter may also be subject to disciplinary action.  See § 11.18(d) and § 11.804 of this chapter. 
(g) Separate copies for separate files.  (1) Since each file must be complete in itself, a separate 
copy of every document filed in connection with a trademark application, registration, or inter partes 
proceeding must be furnished for each file to which the document pertains, even though the 
documents filed in multiple files may be identical.   
(2) Parties should not file duplicate copies of documents in a single application, registration, or 
proceeding file, unless the Office requires the filing of duplicate copies.   
(h) Separate documents for separate branches of the Office .  Since different branches or 
sections of the Office may consider different matters, each distinct subject, inquiry or order must be 
contained in a separate document to avoid confusion and delay in answering correspondence.  
(i) Certified documents required by statute .  When a statute requires that a document be 
certified, a copy or facsimile transmission of the certification is not acceptable.  
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 73 FR 47650, Aug 14. 2008, effective Sept. 
15, 2008; 74 FR 54898, Oct. 26, 2009, effective Dec. 28, 2009; 80 FR 33170, June 11, 2015, effective July 
11, 2015; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020; 86 FR 64300, Nov. 17, 2021, effective Dec. 
18, 2021] 

 -116- July 15, 2026 
§ 2.194  Identification of trademark application or registration.   
(a) No correspondence relating to a trademark application should be filed prior to receipt of the 
application serial number.   
(b) (1) A letter about a trademark application should identify the serial number, the name of the 
applicant, and the mark.    
(2) A letter about a registered trademark should identify the registration number, the name of 
the registrant, and the mark. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003]  
§ 2.195  Filing date of trademark correspondence.    
The filing date of trademark correspondence is determined as follows:  
(a) Electronic submissions.  The filing date of an electronic submission is the date the Office 
receives the submission, based on Eastern Time, regardless of whether that date is a Saturday, 
Sunday, or Federal holiday within the District of Columbia.   
(b) Paper correspondence.  The filing date of a submission submitted on paper is the date the 
Office receives the submission, except as follows:  
(1) Priority Mail Express®.  The filing date of the submission is the date of deposit with the USPS, 
if filed pu rsuant to the requirements of §  2.198. 
(2) Certificate of mailing.  The filing date of the submission is the date of deposit with the USPS, 
if filed pu rsuant to the requirements of §  2.197. 
(3) Office closed.  The Office is not open to receive paper correspondence on any day that is a 
Saturday, Sunday, or Federal holiday within the District of Columbia.  
(c) Email and facsimile submissions.  Email and facsimile submissions are not permitted and, if 
submitted, will not be accorded a date of receipt.   
(d) Interruptions in USPS.  If the Director designates a postal service interruption or emergency 
within the meaning of 35 U.S.C. 21(a), any person attempting to file correspondence by Priority Mail 
Express® Post Office to Addressee service who was unable to deposit the correspondence with the 
USPS due to the interruption or emergency may petition the Director to consider such 
correspondence as filed on a particular date in the Office. The petition must:  
(1) Be filed promptly after the ending of the designated interruption or emergency;  
(2) Include the original correspondence or a copy of the original correspondence; and  
(3) Include a statement that the correspondence would have been deposited with the USPS on 
the requested filing date but for the designated interruption or emergency in Priority Mail Express® 
service; and that the correspondence attached to the petition is the original correspondence or a 
true copy of the correspondence originally attempted to be deposited as Priority Mail Express® on 
the requested filing date.   
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; amended 69 FR 57181, Sept. 24, 2004, 
effective Oct. 4, 2004; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 79 FR 63036, Oct. 22, 2014; 81 
FR 69950, Oct. 7, 2016, effective January 14, 2017; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020] 
§ 2.196  Times for taking action:  Expiration on Saturday, Sunday or Federal holiday.   
Whenever periods of time are specified in this part in days, calendar days are intended.  When 
the day, or the last day fixed by statute or by regulation under this part for taking any action or paying 
any fee in the Office falls on a Saturday, Sunday, or Federal holiday within the District of Columbia, 
the action may be taken, or the fee paid, on the next succeeding day that is not a Saturday, Sunday, 
or a Federal holiday.   
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003]  

 -117- July 15, 2026 
§ 2.197  Certificate of mailing.     
(a) The filing date of correspondence submitted under this section is the date of deposit with the 
USPS if the correspondence:  
(1) Is addressed as set out in § 2.190 and deposited with the USPS with sufficient postage as 
first-class mail; and 
(2) Includes a certificate of mailing for each piece of correspondence that:  
(i) Attests to the mailing and the address used;  
(ii) Includes the name of the document and the application serial number or USPTO reference 
number, if assigned, or registration number to which the document pertains;  
(iii) Is signed separately from any signature for the correspondence by a person who has a 
reasonable basis to expect that the correspondence would be mailed on the date indicated; and 
(iv) Sets forth the date of deposit with the USPS.  
(b) If correspondence is mailed in accordance with paragraph (a) of this section, but not received 
by the Office, the party who mailed such correspondence may file a petition to the Director under §  
2.146(a)(2) to consider such correspondence filed in the Office on the date of deposit with the 
USPS. The petition must: 
(1) Be filed within two months after the date of mailing;  
(2) Include a copy of the previously mailed correspondence and certificate; and  
(3) Include a verified statement attesting to the facts of the original mailing.   
(c) If the certificate of mailing does not meet the requirements of paragraph (a)(2) of this section, 
the filing date is the date the Office receives the submission.  
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; amended 69 FR 57181, Sept. 24, 2004, 
effective Oct. 4, 2004 ; 84 FR 37081, July 31, 2019, effective Feb. 15, 2020 ] 
§ 2.198  Filing of correspondence by Priority Mail Express®.   
(a) The filing date of correspondence submitted under this section is the date of deposit with the 
USPS, as shown by the “date accepted” on the Priority Mail Express® label or other official USPS 
notation.  
(b) If the USPS deposit date cannot be determined, the filing date is the date the Office receives 
the submission.  
(c) If there is a discrepancy between the filing date accorded by the Office to the correspondence 
and the “date accepted,” the party who submitted the correspondence may file a petition to the 
Director under §  2.146(a)(2) to accord the correspondence a filing date as of the “date accepted.” 
The petition must:  
(1) Be filed within two months after the date of deposit;  
(2) Include a true copy of the Priority Mail Express® mailing label showing the “date accepted,” 
and any other official notation by the USPS relied upon to show the date of deposit; and  
(3) Include a verified statement attesting to the facts of the original mailing.  
(d) If the party who submitted the correspondence can show that the “date accepted” was 
incorrectly entered or omitted by the USPS, the party may file a petition to the Director under §  
 2.146(a)(2) to accord the correspondence a filing date as of the date the correspondence is shown 
to have been deposited with the USPS. The petition must:  
(1) Be filed within two months after the date of deposit;  
(2) Include proof that the correspondence was deposited in the Priority Mail Express® Post 
Office to Addressee service prior to the last scheduled pickup on the requested filing date. Such 
proof must be corroborated by evidence from the USPS or evidence that came into being within 
one business day after the date of deposit; and  
(3) Include a verified statement attesting to the facts of the original mailing.  
(e) If correspondence is properly addressed to the Office pursuant to §  2.190 and deposited 
with sufficient postage in the Priority Mail Express® Post Office to Addressee service of the USPS, 
but not received by the Office, the party who submitted the correspondence may file a petition to 

 -118- July 15, 2026 
the Director under §  2.146(a)(2) to consider such correspondence filed in the Office on the USPS 
deposit date. The petition must:  
(1) Be filed within two months after the date of deposit;  
(2) Include a copy of the previously mailed correspondence showing the number of the Priority 
Mail Express® mailing label thereon; and 
(3) Include a verified statement attesting to the facts of the original mailing.  
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 68 FR 56556, Oct. 1, 2003; 79 FR 63036, Oct. 
22, 2014; 80 FR 2303, Jan. 16, 2015, effective Feb. 17, 2015; 84 FR 37081, July 31, 2019, effective Feb. 15, 
2020] 
§ 2.199  [Reserved]  
TRADEMARK RECORDS AND FILES OF THE PATENT AND TRADEMARK OFFICE 
§ 2.200  Assignment records open to public inspection.   
(a)(1) Separate assignment records are maintained in the Office for patents and trademarks.  
The assignment records relating to trademark applications and registrations (for assignments 
recorded on or after January 1, 1955) are open to public inspection at the Office, and copies of 
those assignment records may be obtained upon request and payment of the fee set forth in § 2.6 
of this chapter.  
(2) All records of trademark assignments recorded before January 1, 1955, are maintained by 
the National Archives and Records Administration (NARA).  The records are open to public 
inspection.  Certified and uncertified copies of those assignment records are provided by NARA 
upon request and payment of the fees required by NARA.  
(b) An order for a copy of an assignment or other document should identify the reel and frame 
number where the assignment or document is recorded.   
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; 81 FR 72694, Oct. 21, 2016, effective Jan. 14, 
2017] 
§ 2.201  Copies and certified copies.   
(a) Non-certified copies of trademark registrations and of any trademark records or trademark 
documents within the jurisdiction of the Office and open to the public, will be furnished by the Office 
to any person entitled thereto, upon payment of the appropriate fee required by §  2.6. 
(b) Certified copies of trademark registrations and of any trademark records or trademark 
documents within the jurisdiction of the Office and open to the public will be authenticated by the 
seal of the Office and certified by the Director, or in his or her name attested by an officer of the 
Office authorized by the Director, upon payment of the fee required by §  2.6. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003]  

 -119- July 15, 2026 
§ 2.202  [Reserved]  
§ 2.203  [Reserved]  
§ 2.204  [Reserved]  
§ 2.205  [Reserved]  
FEES AND PAYMENT OF MONEY IN TRADEMARK CASES 
§ 2.206  Trademark fees payable in advance.   
(a) Trademark fees and charges payable to the Office are required to be paid in advance; that 
is, at the time of requesting any action by the Office for which a fee or charge is payable.  
(b) All fees paid to the Office must be itemized in each individual trademark application or 
registration file, or trademark proceeding, so that the purpose for which the fees are paid is clear.  
The Office may return fees that are not itemized as required  by this paragraph.   
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003]  
§ 2.207  Methods of payment.   
(a) All payments of money required in trademark cases, including fees for the processing of 
international trademark applications and registrations that are paid through the Office, shall be made 
in U.S. dollars and in the form of a cashier’s or certified check, Treasury note, national bank note, 
or United States Postal Service money order.  If sent in any other form, the Office may delay or 
cancel the credit until collection is made.  Checks and money orders must be made payable to the 
Director of the Unite d States Patent and Trademark Office.  (Checks made payable to the 
Commissioner of Patents and Trademarks will continue to be accepted.)  Payments from foreign 
countries must be payable and immediately negotiable in the United States for the full amount of 
the fee required.  Money sent to the Office by mail will be at the risk of the sender, and letters 
containing money should be registered with the United States Postal Service.  
(b) Payments of money required for trademark fees may also be made by credit card, except 
for replenishing a deposit account. Payment of a fee by credit card must specify the amount to be 
charged to the credit card and such other information as is necessary to process the charge, and is 
subject to collection of the fee. The Office will not accept a general authorization to charge fees to 
a credit card. If credit card information is provided on a form or document other than a form provided 
by the Office for the payment of fees by credit card, the Office will not be liable if the credit card 
number becomes public knowledge.  
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; amended 69 FR 43751, July 22, 2004]  
§ 2.208  Deposit accounts.   
(a) For the convenience of attorneys, and the general public in paying any fees due, in ordering 
copies of records, or services offered by the Office, deposit accounts may be established in the 
Office.  A minimum deposit of $1,000 is required for paying any fees due or in ordering any services 
offered by the Office.  The Office will issue a deposit account statement at the end of each month.  
A remittance must be made promptly upon receipt of the statement to cover the value of items or 
services charged to the account and thus restore the account to its established normal deposit.  An 
amount sufficient to cover all fees, copies, or services requested must always be on deposit.  
Charges to accounts with insufficient funds will not be accepted.  A service charge (§ 2.6(b)(11)) 
will be assessed for each month that the balance at the end of the month is below $1,000.   

 -120- July 15, 2026 
(b) A general authorization to charge all fees, or only certain fees to a deposit account containing 
sufficient funds may be filed in an individual application, either for the entire pendency of the 
application or with respect to a particular document filed.  An authorization to charge a fee to a 
deposit account will not be considered payment of the fee on the date the authorization to charge 
the fee is effective as to the particular fee to be charged unless sufficient funds are present in the 
account to cover the fee.    
(c) A deposit account holder may replenish the deposit account by submitting a payment to the 
Office.  A payment to replenish a deposit account must be submitted by one of the methods set 
forth in paragraphs (c)(1), (c)(2), (c)(3), or (c)(4) of this sectio n. 
(1) A payment to replenish a deposit account may be submitted by electronic funds transfer 
through the Federal Reserve Fedwire System, which requires that the following information be 
provided to the deposit account holder’s bank or financial institution:  
(i) Name of the Bank, which is Treas NYC (Treasury New York City);  
(ii) Bank Routing Code, which is 021030004;  
(iii) United States Patent and Trademark Office account number with the Department of the 
Treasury, which is 13100001; and  
(iv) The deposit account holder’s company name and deposit account number.  
(2) A payment to replenish a deposit account may be submitted by electronic funds transfer over 
the Office’s Internet Web site ( http://www.uspto.gov ).  
(3) A payment to replenish a deposit account may be addressed to:  Mail Stop Deposit Accounts, 
Director of the United States Patent and Trademark Office, P.O. Box 1450, Alexandria, Virginia 
22313-1450. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003; amended 69 FR 43751, July 22, 2004; 70 FR 
56119, Sept. 26, 2005, effective Nov. 25, 2005; 73 FR 67759, Nov. 17, 2008, effective Jan. 16, 2009; 81 FR 
72694, Oct. 21, 2016, effective Jan. 14, 2017 ; 86 FR 35229, July 2, 2021; effective July 2, 2021 ] 
§ 2.209  Refunds.   
(a) The Director may refund any fee paid by mistake or in excess of that required.  A change of 
purpose after the payment of a fee, such as when a party desires to withdraw a trademark 
application, appeal or other trademark filing for which a fee was paid, will not entitle a party to a 
refund of such fee.  The Office will not refund amounts of twenty-five dollars or less unless a refund 
is specifically requested, and will not notify the payor of such amounts.  If a party paying a fee or 
requesting a refund does not provide the banking information necessary for making refunds by 
electronic funds transfer (31 U.S.C. 3332 and 31 CFR part 208), or instruct the Office that refunds 
are to be credited to a deposit account, the Director may require such information,  or use the 
banking information on the payment instrument to make a refund.  Any refund of a fee paid by credit 
card will be by a credit to the credit card account to which the fee was charged.  
(b) Any request for refund must be filed within two years from the date the fee was paid, except 
as otherwise provided in this paragraph.  If the Office charges a deposit account by an amount other 
than an amount specifically indicated in an authorization (§ 2.208(b)), any request for refund based 
upon such charge must be filed within two years from the date of the deposit account statement 
indicating such charge, and include a copy of that deposit account statement.  The time periods set 
forth in this paragraph are not extendable. 
[Added 68 FR 48286, Aug. 13, 2003, effective Sept. 12, 2003]  