 -275- January 1, 2026 
 
UNITED STATES CODE, TITLE 35, PATENTS  
PART 1-UNITED STATES PATENT AND TRADEMARK OFFICE 
CHAPTER 1-ESTABLISHMENT, OFFICERS AND EMPLOYEES, FUNCTIONS 
35 U.S.C. § 1.  Establishment.  
(a) ESTABLISHMENT—The United States Patent and Trademark Office is established as an 
agency of the United States, within the Department of Commerce.  In carrying out its functions, the 
United States Patent and Trademark Office shall be subject to the policy direction of the Secretary 
of Commerce, but otherwise shall retain responsibility for decisions regarding the management and 
administration of its operations and shall exercise independent control of its budget allocations and 
expenditures, personnel decisions and processes, procurements, and other administrative and 
management functions in accordance with this title and applicable provisions of law.  Those 
operations designed to grant and issue patents and those operations which are designed to facilitate 
the registration of trademarks shall be treated as separate operating units within the Office.  
(b) OFFICES—The United States Patent and Trademark Office shall maintain its principal office in 
the metropolitan Washington, D.C., area, for the service of process and papers and for the purpose 
of carrying out its functions.  The United States Patent and Trademark Office shall be deemed, for 
purposes of venue in civil actions, to be a resident of the district in which its principal office is located, 
except where jurisdiction is otherwise provided by law.  The United States Patent and Trademark 
Office may establish satellite offices in such other places in the United States as it considers 
necessary and appropriate in the conduct of its business.  
(c) REFERENCE—For purposes of this title, the United States Patent and Trademark Office shall 
also be referred to as the “Office” and the “Patent and Trademark Office.”  
(July 19, 1952, ch. 950, § 1, 66 Stat. 792; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-572.) 
35 U.S.C. § 2.  Powers and duties.  
(a) IN GENERAL—The United States Patent and Trademark Office, subject to the policy direction 
of the Secretary of Commerce — 
(1) shall be responsible for the granting and issuing of patents and the registration of 
trademarks; and 
(2) shall be responsible for disseminating to the public information with respect to patents and 
trademarks. 
(b) SPECIFIC POWERS—The Office — 
(1) shall adopt and use a seal of the Office, which shall be judicially noticed and with which 
letters patent, certificates of trademark registrations, and papers issued by the Office shall be 
authenticated; 
(2) may establish regulations, not inconsistent with law, which — 
(A) shall govern the conduct of proceedings in the Office;  
(B) shall be made in accordance with section 553 of title 5;  

 -276- January 1, 2026 
(C) shall facilitate and expedite the processing of patent applications, particularly those 
which can be filed, stored, processed, searched, and retrieved electronically, subject to the 
provisions of section 122 relating to the confidential status of appli cations; 
(D) may govern the recognition and conduct of agents, attorneys, or other persons 
representing applicants or other parties before the Office, and may require them, before 
being recognized as representatives of applicants or other persons, to show that they are of 
good moral character and reputation and are possessed of the necessary qualifications to 
render to applicants or other persons valuable service, advice, and assistance in the 
presentation or prosecution of their applications or other business befor e the Office;  
(E) shall recognize the public interest in continuing to safeguard broad access to the United 
States patent system through the reduced fee structure for small entities under section 
41(h)(1);  
(F) provide for the development of a performance-based process that includes quantitative 
and qualitative measures and standards for evaluating cost-effectiveness and is consistent 
with the principles of impartiality and competitiveness;  and 
(G) may, subject to any conditions prescribed by the Director and at the request of the patent 
applicant, provide for prioritization of examination of applications for products, processes, or 
technologies that are important to the national economy or national competitiveness without 
recovering the aggregate extra cost of providing such prioritization, notwithstanding section 
41 or any other  provision of law; 
(3) may acquire, construct, purchase, lease, hold, manage, operate, improve, alter, and 
renovate any real, personal, or mixed property, or any interest therein, as it considers necessary 
to carry out its functions;  
(4)(A) may make such purchases, contracts for the construction, maintenance, or management 
and operation of facilities, and contracts for supplies or services, without regard to the  
provisions of subtitle I and chapter 33 of title 40, title III of the Fed eral Property and 
Administrative Services Act of 1949 (41 U.S.C. 251 et seq.), and the McKinney-Vento Homeless 
Assistance Act (42 U.S.C. 11301 et seq.); and 
(B) may enter into and perform such purchases and contracts for printing services, including 
the process of composition, platemaking, presswork, silk screen processes, binding, 
microform, and the products of such processes, as it considers necessary to carry out the 
functions of the Office, without regard to sections 501 through 517 and 1101 through 1123 
of title 44;  
(5) may use, with their consent, services, equipment, personnel, and facilities of other 
departments, agencies, and instrumentalities of the Federal Government, on a reimbursable 
basis, and cooperate with such other departments, agencies, and instrumentali ties in the 
establishment and use of services, equipment, and facilities of the Office;  
(6) may, when the Director determines that it is practicable, efficient, and cost-effective to do so, 
use, with the consent of the United States and the agency, instrumentality, Patent and 
Trademark Office, or international organization concerned, the services, records, facilities, or 
personnel of any State or local government agency or instrumentality or foreign patent and 
trademark office or international organization to perform functions on its behalf;  
(7) may retain and use all of its revenues and receipts, including revenues from the sale, lease, 
or disposal of any real, personal, or mixed property, or any interest therein, of the Office;  

 -277- January 1, 2026 
(8) shall advise the President, through the Secretary of Commerce, on national and certain 
international intellectual property policy issues;  
(9) shall advise Federal departments and agencies on matters of intellectual property policy in 
the United States and intellectual property protection in other countries;  
(10) shall provide guidance, as appropriate, with respect to proposals by agencies to assist 
foreign governments and international intergovernmental organizations on matters of 
intellectual property protection;  
(11) may conduct programs, studies, or exchanges of items or services regarding domestic and 
international intellectual property law and the effectiveness of intellectual property protection 
domestically and throughout the world, and the Office is authorized to expend funds to cover 
the subsistence expenses and travel-related expenses, including per diem, lodging costs, and 
transportation costs, of persons attending such programs who are not Federal employees ; 
(12)(A) shall advise the Secretary of Commerce on programs and studies relating to intellectual 
property policy that are conducted, or authorized to be conducted, cooperatively with foreign 
intellectual property offices and international intergovernmental organizations; and 
(B) may conduct programs and studies described in subparagraph (A); and  
(13)(A) in coordination with the Department of State, may conduct programs and studies 
cooperatively with foreign intellectual property offices and international intergovernmental 
organizations; and 
(B) with the concurrence of the Secretary of State, may authorize the transfer of not to 
exceed $100,000 in any year to the Department of State for the purpose of making special 
payments to international intergovernmental organizations for studies and prog rams for 
advancing international cooperation concerning patents, trademarks, and other matters. 
(c) CLARIFICATION OF SPECIFIC POWERS —(1) The special payments under subsection 
(b)(13)(B) shall be in addition to any other payments or contributions to international organizations 
described in subsection (b)(13)(B) and shall not be subject to any limitations imposed by law on the 
amounts of such other payments or contributions by the United States Government.  
(2) Nothing in subsection (b) shall derogate from the duties of the Secretary of State or from the 
duties of the United States Trade Representative as set forth in section 141 of the Trade Act of 
1974 (19 U.S.C. 2171).  
(3) Nothing in subsection (b) shall derogate from the duties and functions of the Register of 
Copyrights or otherwise alter current authorities relating to copyright matters.  
(4) In exercising the Director’s powers under paragraphs (3) and (4)(A) of subsection (b), the 
Director shall consult with the Administrator of General Services.  
(5) In exercising the Director’s powers and duties under this section, the Director shall consult 
with the Register of Copyrights on all copyright and related matters.  
(d) CONSTRUCTION—Nothing in this section shall be construed to nullify, void, cancel, or interrupt 
any pending request-for-proposal let or contract issued by the General Services Administration for 
the specific purpose of relocating or leasing space to the  United States Patent and Trademark 
Office.  
(July 19, 1952, ch. 950, § 1, 66 Stat. 792; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-573; 
Nov. 2, 2002, 116 Stat. 1758 ; Sept. 16, 2011, 125 Stat. 335 , 337-338.) 

 -278- January 1, 2026 
35 U.S.C. § 3. Officers and employees.  
(a) UNDER SECRETARY AND DIRECTOR —(1) IN GENERAL- The powers and duties of the 
United States Patent and Trademark Office shall be vested in an Under Secretary of Commerce for 
Intellectual Property and Director of the United States Patent and Trademark Offic e (in this title 
referred to as the “Director”), who shall be a citizen of the United States and who shall be appointed 
by the President, by and with the advice and consent of the Senate. The Director shall be a person 
who has a professional background and experience in patent or trademark law. 
(2) DUTIES— 
(A) IN GENERAL —The Director shall be responsible for providing policy direction and 
management supervision for the Office and for the issuance of patents and the registration 
of trademarks. The Director shall perform these duties in a fair, impartial, and equitable 
manner. 
(B) CONSULTING WITH THE PUBLIC ADVISORY COMMITTEES —The Director shall 
consult with the Patent Public Advisory Committee established in section 5 on a regular 
basis on matters relating to the patent operations of the Office, shall consult with the 
Trademark Public Advisory Committee established in section 5 on a regular basis on matters 
relating to the trademark operations of the Office, and shall consult with the respective Public 
Advisory Committee before submitting budgetary proposals to the Office of Management 
and Budget or changing or proposing to change patent or trademark user fees or patent or 
trademark regulations which are subject to the requirement to provide notice and opportunity 
for public comment under section 553 of title 5, as the case may b e. 
(3) OATH—The Director shall, before taking office, take an oath to discharge faithfully the duties 
of the Office.  
(4) REMOVAL—The Director may be removed from office by the President. The President shall 
provide notification of any such removal to both Houses of Congress.  
(b) OFFICERS AND EMPLOYEES OF THE OFFICE— 
(1) DEPUTY UNDER SECRETARY AND DEPUTY DIRECTOR—The Secretary of Commerce, 
upon nomination by the Director, shall appoint a Deputy Under Secretary of Commerce for 
Intellectual Property and Deputy Director of the United States Patent and Trademark Office who 
shall be vested with the authority to act in the capacity of the Director in the event of the absence 
or incapacity of the Director. The Deputy Director shall be a citizen of the United States who has 
a professional background and experience in patent or trademark law. 
(2) COMMISSIONERS— 
(A) APPOINTMENT AND DUTIES—The Secretary of Commerce shall appoint a Commissioner 
for Patents and a Commissioner for Trademarks, without regard to chapter 33, 51, or 53 of title 
5.  The Commissioner for Patents shall be a citizen of the United States with demonstrated 
management ability and professional background and experience in patent law and serve for a 
term of 5 years.  The Commissioner for Trademarks shall be a citizen of the United States with 
demonstrated management ability and professional background and experience in trademark 
law and serve for a term of 5 years.  The Commissioner for Patents and the Commissioner for 
Trademarks shall serve as the chief operating officers for the operations of the Office relating to 
patents and trademarks, respecti vely, and shall be responsible for the management and 
direction of all aspects of the activities of the Office that affect the administration of patent and 
trademark operations, respectively.  The Secretary may reappoint a Commissioner to 
subsequent terms of 5 years as long as the performance of the Commissioner as set forth in 
the performance agreement in subparagraph (B) is satisfactory.  

 -279- January 1, 2026 
(B) SALARY AND PERFORMANCE AGREEMENT—The Commissioners shall be paid an 
annual rate of basic pay not to exceed the maximum rate of basic pay for the Senior 
Executive Service established under section 5382 of title 5, including any applicable locality-
based comparability payment that may be authorized under section 5304(h)(2)(C) of title 5. 
The compensation of the Commissioners shall be considered, for purposes of section 
207(c)(2)(A) of title 18, to be the equivalent of that described under clause (ii) of section 
207(c)(2)(A) of title 18. In addition, the Commissioners may receive a bonus in an amount 
of up to, but not in excess of, 50 percent of the Commissioners’ annual rate of basic pay, 
based upon an evaluation by the Secretary of Commerce, acting through the Director, of 
the Commissioners’ performance as defined in an annual performance agreement between 
the Commissioners and the Secretary. The annual performance agreements shall 
incorporate measurable organization and individual goals in key operational  areas as 
delineated in an annual performance plan agreed to by the Commissioners and the 
Secretary. Payment of a bonus under this subparagraph may be made to the 
Commissioners only to the extent that such payment does not cause the Commissioners’ 
total aggregate compensation in a calendar year to equal or exceed the amount of the salary 
of the Vice President under section 104 of title 3.  
(C) REMOVAL- The Commissioners may be removed from office by the Secretary for 
misconduct or nonsatisfactory performance under the performance agreement described in 
subparagraph (B), without regard to the provisions of title 5. The Secretary shall provide 
notification of any such removal to both Houses of Congress.  
(3) OTHER OFFICERS AND EMPLOYEES—The Director shall— 
(A) appoint such officers, employees (including attorneys), and agents of the Office as the 
Director considers necessary to carry out the functions of the Office; and  
(B) define the title, authority, and duties of such officers and employees and delegate to 
them such of the powers vested in the Office as the Director may determine.  
The Office shall not be subject to any administratively or statutorily imposed limitation on 
positions or personnel, and no positions or personnel of the Office shall be taken into 
account for purposes of applying any such limitation.  
(4) TRAINING OF EXAMINERS—The Office shall submit to the Congress a proposal to provide 
an incentive program to retain as employees patent and trademark examiners of the primary 
examiner grade or higher who are eligible for retirement, for the sole purpose of training patent 
and trademark examiners. 
(5) NATIONAL SECURITY POSITIONS—The Director, in consultation with the Director of the 
Office of Personnel Management, shall maintain a program for identifying national security 
positions and providing for appropriate security clearances, in order to maintain the secrecy of 
certain inventions, as described in section 181, and to prevent disclosure of sensitive and 
strategic information in the interest of national security.  
(6) ADMINISTRATIVE PATENT JUDGES AND ADMINISTRATIVE TRADEMARK JUDGES—
The Director may fix the rate of basic pay for the administrative patent judges appointed 
pursuant to section 6 and the administrative trademark judges appointed pursuant to section 17 
of the Trademark Act of 1946 (15 U.S.C. 1067) at not greater than the rate of basic pay payable 
for level III of the Executive Schedule under section 5314 of title 5. The payment of a rate of 
basic pay under this paragraph shall not be subject to the pay limitation under section 5306(e) 
or 5373 of title 5.   
(c) CONTINUED APPLICABILITY OF TITLE 5 —Officers and employees of the Office shall be 
subject to the provisions of title 5, relating to Federal employees.  

 -280- January 1, 2026 
(d) ADOPTION OF EXISTING LABOR AGREEMENTS —The Office shall adopt all labor 
agreements which are in effect, as of the day before the effective date of the Patent and Trademark 
Office Efficiency Act, with respect to such Office (as then in effect).  
(e) CARRYOVER OF PERSONNEL— 
(1) FROM PTO- Effective as of the effective date of the Patent and Trademark Office Efficiency 
Act, all officers and employees of the Patent and Trademark Office on the day before such 
effective date shall become officers and employees of the Office, without a break in service. 
(2) OTHER PERSONNEL- Any individual who, on the day before the effective date of the Patent 
and Trademark Office Efficiency Act, is an officer or employee of the Department of Commerce 
(other than an officer or employee under paragraph (1)) shall be transferred to the Office, as 
necessary to carry out the purposes of th at Act, if— 
(A) such individual serves in a position for which a major function is the performance of work 
reimbursed by the Patent and Trademark Office, as determined by the Secretary of 
Commerce; 
(B) such individual serves in a position that performed work in support of the Patent and 
Trademark Office during at least half of the incumbent’s work time, as determined by the 
Secretary of Commerce; or  
(C) such transfer would be in the interest of the Office, as determined by the Secretary of 
Commerce in consultation with the Director.   
Any transfer under this paragraph shall be effective as of the same effective date as referred to 
in paragraph (1), and shall be made without a break in service. 
(f) TRANSITION PROVISIONS— 
(1) INTERIM APPOINTMENT OF DIRECTOR—On or after the effective date of the Patent and 
Trademark Office Efficiency Act, the President shall appoint an individual to serve as the 
Director until the date on which a Director qualifies under subsection (a). The President shall 
not make more than one such appointment under this subsection.  
(2) CONTINUATION IN OFFICE OF CERTAIN OFFICERS—(A) The individual serving as the 
Assistant Commissioner for Patents on the day before the effective date of the Patent and 
Trademark Office Efficiency Act may serve as the Commissioner for Patents until the date on 
which a Commissioner for Patents is appointed under subsection (b).  
(B) The individual serving as the Assistant Commissioner for Trademarks on the day before 
the effective date of the Patent and Trademark Office Efficiency Act may serve as the 
Commissioner for Trademarks until the date on which a Commissioner for Trademarks is 
appointed under subsection (b).  
(July 19, 1952, ch. 950, § 1, 66 Stat. 792; Sept. 6, 1958, 72 Stat. 1793; Sept. 23, 1959, 73 Stat. 650; Aug. 14, 
1964, 78 Stat. 425; Jan. 2, 1975, 88 Stat. 1949; Jan. 2, 1975, 88 Stat. 1956; Aug. 27, 1982, 96 Stat. 319; Oct. 
15, 1982, 96 Stat. 1760; Nov. 8, 1984, 98 Stat. 3392; Oct. 28, 1998, 112 Stat. 2860; Aug. 5, 1999, 113 Stat. 
221; Nov. 29, 1999, 113 Stat. 1501A-575; Nov. 2, 2002, 116 Stat. 1904; Sept. 16, 2011, 125 Stat. 334, 336.) 
35 U.S.C. § 4.  Restrictions on officers and employees as to interest in patents  
Officers and employees of the Patent and Trademark Office shall be incapable, during the period 
of their appointments and for one year thereafter, of applying for a patent and of acquiring, directly 
or indirectly, except by inheritance or bequest, any patent or any right or interest in a patent, issued 

 -281- January 1, 2026 
or to be issued by the Office.  In patents applied for thereafter they shall not be entitled to any priority 
date earlier than one year after the termination of their appointment.  
(July 19, 1952, ch. 950, §  1, 66 Stat. 793; Jan. 2, 1975, 88 Stat. 1949; Jan. 2, 1975, 88 Stat. 1949.)  
35 U.S.C. § 5.  Patent and Trademark Office Public Advisory Committees.  
(a) ESTABLISHMENT OF PUBLIC ADVISORY COMMITTEES— 
(1) APPOINTMENT —The United States Patent and Trademark Office shall have a Patent 
Public Advisory Committee and a Trademark Public Advisory Committee, each of which shall 
have nine voting members who shall be appointed by the Secretary of Commerce and serve at 
the pleasure of the Secretary of Commerce. In each year, 3 members shall be appointed to 
each Advisory Committee for 3-year terms that shall begin on December 1 of that year. Any 
vacancy on an Advisory Committee shall be filled within 90 days after it occurs. A new member 
who is appointed to fill a vacancy shall be appointed to serve for the remainder of the 
predecessor's term . 
(2) CHAIR—The Secretary of Commerce, in consultation with the Director, shall designate a 
Chair and Vice Chair of each Advisory Committee from among the members appointed under 
paragraph (1). If the Chair resigns before the completion of his or her term, or is other wise 
unable to exercise the functions of the Chair, the Vice Chair shall exercise the functions of the 
Chair. 
(b) BASIS FOR APPOINTMENTS- Members of each Advisory Committee — 
(1) shall be citizens of the United States who shall be chosen so as to represent the interests of 
diverse users of the United States Patent and Trademark Office with respect to patents, in the 
case of the Patent Public Advisory Committee, and with respect to trademarks, in the case of 
the Trademark Public Advisory Committee; 
(2) shall include members who represent small and large entity applicants located in the United 
States in proportion to the number of applications filed by such applicants, but in no case shall 
members who represent small entity patent applicants, includin g small business concerns, 
independent inventors, and nonprofit organizations, constitute less than 25 percent of the 
members of the Patent Public Advisory Committee, and such members shall include at least 
one independent inventor; and  
(3) shall include individuals with substantial background and achievement in finance, 
management, labor relations, science, technology, and office automation.  
In addition to the voting members, each Advisory Committee shall include a representative of each 
labor organization recognized by the United States Patent and Trademark Office. Such 
representatives shall be nonvoting members of the Advisory Committee to w hich they are 
appointed. 
(c) MEETINGS—Each Advisory Committee shall meet at the call of the chair to consider an agenda 
set by the chair. 
(d) DUTIES—Each Advisory Committee shall— 
(1) review the policies, goals, performance, budget, and user fees of the United States Patent 
and Trademark Office with respect to patents, in the case of the Patent Public Advisory 
Committee, and with respect to Trademarks, in the case of the Trademark P ublic Advisory 
Committee, and advise the Director on these matters;  
(2) within 60 days after the end of each fiscal year — 

 -282- January 1, 2026 
(A) prepare an annual report on the matters referred to in paragraph (1);  
(B) transmit the report to the Secretary of Commerce, the President, and the Committees 
on the Judiciary of the Senate and the House of Representatives; and  
(C) publish the report in the Official Gazette of the United States Patent and Trademark 
Office.  
(e) COMPENSATION—Each member of each Advisory Committee shall be compensated for each 
day (including travel time) during which such member is attending meetings or conferences of that 
Advisory Committee or otherwise engaged in the business of that Advisory Committee, at the rate 
which is the daily equivalent of the annual rate of basic pay in effect for level III of the Executive 
Schedule under section 5314 of title 5. While away from such member’s home or regular place of 
business such member shall be allowed travel expenses, including per diem in lieu of subsistence, 
as authorized by section 5703 of title 5.  
(f) ACCESS TO INFORMATION—Members of each Advisory Committee shall be provided access 
to records and information in the United States Patent and Trademark Office, except for personnel 
or other privileged information and information concerning patent applications required to be kept 
in confidence by section 122.  
(g) APPLICABILITY OF CERTAIN ETHICS LAWS—Members of each Advisory Committee shall 
be special Government employees within the meaning of section 202 of title 18.  
(h) INAPPLICABILITY OF FEDERAL ADVISORY COMMITTEE ACT —The Federal Advisory 
Committee Act (5 U.S.C. App.) shall not apply to each Advisory Committee. 
(i) OPEN MEETINGS —The meetings of each Advisory Committee shall be open to the public, 
except that each Advisory Committee may by majority vote meet in executive session when 
considering personnel, privileged, or other confidential information.  
(j) INAPPLICABILITY OF PATENT PROHIBITION—Section 4 shall not apply to voting members of 
the Advisory Committees. 
(Added Nov. 29, 1999, 113 Stat. 1501A-578; amended Nov. 2, 2002, 116 Stat. 1904; amended Jan. 14. 2013, 
126 Stat. 2458-549.) 
35 U.S.C. § 6.  Patent Trial and Appeal Board .  (35 U.S.C. § 6 pertains to patents.) 
35 U.S.C. § 7.  Library. 
The Director shall maintain a library of scientific and other works and periodicals, both foreign and 
domestic, in the Patent and Trademark Office to aid the officers in the discharge of their duties. 
(July 19, 1952, ch. 950, § 1, 66 Stat. 793; Jan. 2, 1975, 88 Stat. 1949; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 
1999, 113 Stat. 1501A-580.) 
35 U.S.C. § 8.  Classification of patents.  (35 U.S.C. § 8 pertains to patents.) 
35 U.S.C. § 9.  Certified copies of records.  
The Director may furnish certified copies of specifications and drawings of patents issued by the 
Patent and Trademark Office, and of other records available either to the public or to the person 
applying therefor.  
(July 19, 1952, ch. 950, 66 Stat. 794; Pub. L. 93-596, Sec. 1, Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 
Stat. 1501A-580.) 

 -283- January 1, 2026 
35 U.S.C. § 10.  Publications.  
(a) The Director may publish in printed, typewritten, or electronic form, the following:  
1.  Patents, including specifications and drawings, together with copies of the same.  The Patent 
and Trademark Office may print the headings of the drawings for patents for the purpose of 
photolithography. 
2.  Certificates of trademark registrations, including statements and drawings, together with 
copies of the same. 
3.  The Official Gazette of the United States Patent and Trademark Office.  
4.  Annual indexes of patents and patentees, and of trademarks and registrants.  
5.  Annual volumes of decisions in patent and trademark cases. 
6.  Pamphlet copies of the patent laws and rules of practice, laws and rules relating to 
trademarks, and circulars or other publications relating to the business of the Office.  
(b) The Director may exchange any of the publications specified in items 3, 4, 5, and 6 of subsection 
(a) of this section for publications desirable for use of the Patent and Trademark Office.  
(July 19, 1952, ch. 950, § 1, 66 Stat. 794; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-580.) 
35 U.S.C. § 11.  Exchange of copies of patents.  (35 U.S.C. § 11 pertains to patents.)  
35 U.S.C. § 12.  Copies of patents and applications for public libraries.  (35 U.S.C. § 12 
pertains to patents.) 
35 U.S.C. § 13.  Annual report to Congress.  
The Director shall report to the Congress, not later than 180 days after the end of each fiscal year, 
the moneys received and expended by the Office, the purposes for which the moneys were spent, 
the quality and quantity of the work of the Office, the nature of training provided to examiners, the 
evaluation of the Commissioner of Patents and the Commissioner of Trademarks by the Secretary 
of Commerce, the compensation of the Commissioners, and other information relating to the Office. 
(July 19, 1952, ch. 950, §  1, 66 Stat. 794; Nov. 29, 1999, 113 Stat. 1501A -581.) 
CHAPTER 2—PROCEEDINGS IN THE PATENT AND TRADEMARK OFFICE 
35 U.S.C. § 21.  Filing date and day for taking action.  
(a) The Director may by rule prescribe that any paper or fee required to be filed in the Patent and 
Trademark Office will be considered filed in the Office on the date on which it was deposited with 
the United States Postal Service or would have been depos ited with the United States Postal 
Service but for postal service interruptions or emergencies designated by the Director.  
(b) When the day, or the last day, for taking any action or paying any fee in the United States Patent 
and Trademark Office falls on Saturday, Sunday, or a federal holiday within the District of Columbia, 
the action may be taken, or the fee paid, on the ne xt succeeding secular or business day.  
(July 19, 1952, ch. 950, § 1, 66 Stat. 794; Jan. 2, 1975, 88 Stat. 1949; Aug. 27, 1982, 96 Stat. 321; Nov. 29, 
1999, 113 Stat. 1501A-582.) 
Note—For holidays, see 5 U.S.C. §  6103 and District of Columbia Code, sec. 28 -2701: 

 -284- January 1, 2026 
5 U.S.C. § 6103.  Holidays.  
(a) The following are legal public holidays:  
New Year’s Day, January 1. 
Birthday of Martin Luther King, Jr., the third Monday in January.  
Washington’s Birthday, the third Monday in February.  
Memorial Day, the last Monday in May. 
Juneteenth National Independence Day, June 19.  
Independence Day, July 4.  
Labor Day, the first Monday in September.  
Columbus Day, the second Monday in October.  
Veterans Day, November 11. 
Thanksgiving Day, the fourth Thursday in November.  
Christmas Day, December 25. 
(b) For the purpose of statutes relating to pay and leave of employees, with respect to a legal public 
holiday and any other day declared to be a holiday by Federal statute or Executive order, the 
following rules apply:  
(1) Instead of a holiday that occurs on a Saturday, the Friday immediately before is a legal public 
holiday for— 
(A)  employees whose basic workweek is Monday through Friday; and  
(B) the purpose of section 6309  of this title . 
(2)  Instead of a holiday that occurs on a regular weekly non-workday of an employee whose 
basic workweek is other than Monday through Friday, except the regular weekly non-workday 
administratively scheduled for the employee instead of Sunday, the workday immediately before 
that regular weekly nonworkday is a legal public holiday for the employee . 
(3) Instead of a holiday that is designated under subsection (a) to occur on a Monday, for an 
employee at a duty post outside the United States whose basic workweek is other than Monday 
through Friday, and for whom Monday is a regularly scheduled workday, the legal public holiday 
is the first workday of the workweek in which the Monday designated for the observance of such 
holiday under subsection (a) occurs.  
This subsection, except subparagraph (B) of paragraph (1), does not apply to an employee whose 
basic workweek is Monday through Saturday.  
(c) January 20 of each fourth year after 1965, Inauguration Day, is a legal public holiday for the 
purpose of statutes relating to pay and leave of employees as defined by  section 2105 of this 
title and individuals employed by the government of the District of Columbia employed in the District 
of Columbia, Montgomery and Prince Georges Counties in Maryland, Arlington and Fairfax 
Counties in Virginia, and the cities of Alexandria and Falls Church in Virginia. When January 20 of 
any fourth year after 1965 fal ls on Sunday, the next succeeding day selected for the public 
observance of the inauguration of the President is a legal public holiday for the purpose of this 
subsection. 
(d)(1) For purposes of this subsection - 
(A) the term "compressed schedule" has the meaning given such term by section 6121(5); and 
(B) the term "adverse agency impact" has the meaning given such term by section 6131(b).  

 -285- January 1, 2026 
 
 
(2) An agency may prescribe rules under which employees on a compressed schedule may, in the 
case of a holiday that occurs on a regularly scheduled non -workday for such employees, and 
notwithstanding any other provision of law or the terms of any collective bargaining agreement, be 
required to observe such holiday on a workday other than as pr ovided by subsection (b), if the 
agency head determines that it is necessary to do so in order to prevent an adverse agency impact. 
(Amended June 28, 1968, 82 Stat. 250; Sept. 18, 1975, 89 Stat. 479; Nov. 2, 1983, 97 Stat. 917; Sept. 23, 
1996, 110 Stat. 2739; Oct. 17, 1998, 112 Stat. 2142; June 17, 2021, 135 Stat. 287 ) 
District of Columbia Code —Section 28 -2701.   
Holidays designated—Time for performing acts extended.  The following days in each year, namely, 
New Year’s Day, January 1; Dr. Martin Luther King, Jr.’s Birthday, the third Monday in January; 
Washington’s Birthday, the third Monday in February; District of Columbia Emancipation Day, April 
16; Memorial Day, the  last Monday in May; Juneteenth National Independence Day, June 19; 
Independence Day, July 4; Labor Day, the first Monday in September; Indigenous Peoples' Day, 
the second Monday in October; Veteran’s  Day, November 11; Thanksgiving Day, the fourth 
Thursday in November; Christmas Day, December 25; every Saturday, after twelve o’clock noon; 
any day appointed by the President of the United States as a day of public feasting or thanksgiving; 
and the day of the inauguration of the President, in every fourth year, are holidays in the District for 
all purposes. When a day set apart as a legal holiday, other than the day of the inauguration of the 
President, falls on a Saturday, the next preceding day is a holiday. When a day set apart as a legal 
holiday falls on a Sunday, the next succeeding day is a holiday. In such cases, when a Sunday and 
a holiday or holidays fall on successive days, all commercial papers falling due on any of those days 
shall, for all purp oses of presenting for payment or acceptance, be deemed to mature and be 
presentable for payment or acceptance on the next secular business day succeeding. Every 
Saturday is a holiday in the District for (1) every bank or banking institution having an offi ce or 
banking house located within the District, (2) every Federal savings and loan association whose 
main office is in the District, and (3) every building association, building and loan association, or 
savings and loan association, incorporated or unincorporated, organized and operating under the 
laws of and having an office located within the District. An act which would otherwise be required, 
authorized, or permitted to be performed on Saturday in the District at the office or banking house 
of, or by, a ny such bank or bank institution, Federal savings and loan association, building 
association, building and loan association, or savings and loan association, if Saturday were not a 
holiday, shall or may be so performed on the next succeeding business day, and liability or loss of 
rights of any kind may not result from such delay . 
Note.—As to the observance of holidays which fall on Saturday, see 5 U.S.C. §  6103, which 
provides: 
“(b)(1) Instead of a holiday that occurs on a Saturday, the Friday immediately before is a legal public 
holiday....” 
35 U.S.C. § 22.  Printing of papers filed.   
The Director may require papers filed in the Patent and Trademark Office to be printed, typewritten, 
or on an electronic medium. 
(July 19, 1952, ch. 950, § 1, 66 Stat. 795; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-582.) 

 -286- January 1, 2026 
35 U.S.C. § 23.  Testimony in Patent and Trademark Office cases.   
The Director may establish rules for taking affidavits and depositions required in cases in the Patent 
and Trademark Office.  Any officer authorized by law to take depositions to be used in the courts of 
the United States, or of the State where he resides,  may take such affidavits and depositions. 
(July 19, 1952, ch. 950, § 1, 66 Stat. 795; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-582.) 
35 U.S.C. § 24.  Subpoenas, witnesses.   
The clerk of any United States court for the district wherein testimony is to be taken for use in any 
contested case in the Patent and Trademark Office, shall, upon the application of any party thereto, 
issue a subpoena for any witness residing or being within such district, commanding him to appear 
and testify before an officer in such district authorized to take depositions and affidavits, at the time 
and place stated in the subpoena.  The provisions of the Federal Rules of Civil Procedure relating 
to the  attendance of witnesses and to the production of documents and things shall apply to 
contested cases in the Patent and Trademark Office.  
Every witness subpoenaed and in attendance shall be allowed the fees and traveling expenses 
allowed to witnesses attending the United States district courts.  
A judge of a court whose clerk issued a subpoena may enforce obedience to the process or punish 
disobedience as in other like cases, on proof that a witness, served with such subpoena, neglected 
or refused to appear or to testify.  No witness shall be deemed guilty of contempt for disobeying 
such subpoena unless his fees and traveling expenses in going to, and returning from, and one 
day’s attendance at the place of examination, are paid or tendered him at the time of the service of 
the subpoena; nor for refusing to disclose any secret matter except upon appropriate order of the 
court which issued the subpoena.  
(July 19, 1952, ch. 950, §  1, 66 Stat. 795; Jan. 2, 1975, 88 Stat. 1949.)  
35 U.S.C. § 25.  Declaration in lieu of oath.  
(a) The Director may by rule prescribe that any document to be filed in the Patent and Trademark 
Office and which is required by any law, rule, or other regulation to be under oath may be subscribed 
to by a written declaration in such form as the Director may prescribe, such declaration to be in lieu 
of the oath otherwise required.  
(b) Whenever such written declaration is used, the document must warn the declarant that willful 
false statements and the like are punishable by fine or imprisonment, or both (18 U.S.C. section 
1001).  
(Added Mar. 26, 1964, 78 Stat. 171; amended Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-
582.) 
Note—18 U.S.C. § 1001 provides:  “Whoever in any matter within the jurisdiction of any department 
or agency of the United States knowingly and willfully falsifies, conceals or covers up by any trick, 
scheme, or device a material fact, or makes any false, f ictitious or fraudulent statements or 
representations, or makes or uses any false writing or document knowing the same to contain any 
false, fictitious or fraudulent statements or entry, shall be fined not more than $10,000 or imprisoned 
not more than five  years, or both.”  (June 25, 1948, 62 Stat. 749.)  
35 U.S.C. § 26.  Effect of defective execution.   
Any document to be filed in the Patent and Trademark Office and which is required by any law, rule, 
or other regulation to be executed in a specified manner may be provisionally accepted by the 

 -287- January 1, 2026 
Director despite a defective execution, provided a properly executed document is submitted within 
such time as may be prescribed.  
(Added Mar. 26, 1964, 78 Stat. 171; amended Jan. 2, 1975, 88 Stat. 1949.)  
CHAPTER 3—PRACTICE BEFORE PATENT AND TRADEMARK OFFICE 
35 U.S.C. § 31.  [Repealed]  
(Nov. 29, 1999, 113 Stat. 1501A -580.) 
35 U.S.C. § 32.  Suspension or exclusion from practice.   
The Director may, after notice and opportunity for a hearing, suspend or exclude, either generally 
or in any particular case, from further practice before the Patent and Trademark Office, any person, 
agent, or attorney shown to be incompetent or disreputable, or guilty of gross misconduct, or who 
does not comply with the regulations established under section 2(b)(2)(D), or who shall, by word, 
circular, letter, or advertising, with intent to defraud in any manner, deceive, mislead, or threaten 
any applicant or prospective applicant, or other person having immediate or prospective business 
before the Office.  The reasons for any such suspension or exclusion shall be duly recorded.  The 
Director shall have the discretion to designate any attorney who is an officer or employee of the 
United States Patent and Trademark Office to conduct the hearing required by this section.  A 
proceeding under this section shall be commenced not later than the earlier of either the date that 
is 10 years after the date on which the misconduct forming the basis for the proceeding occurred, 
or 1 year after the date on which the misconduct forming the basis for the proceeding is made known 
to an officer or employee of the Office as prescribed in the regulations established under section 
2(b)(2)(D).  The United States District Court for the Eastern District of Virginia, under such conditions 
and upon such proceedings as it by its rules determines, may review the action of the Director upon 
the petition of the person so refused recognition or so suspended or excluded.  
(July 19, 1952, ch. 950, § 1, 66 Stat. 795; Jan. 2, 1975, 88 Stat. 1949; Nov. 29, 1999, 113 Stat. 1501A-581; 
Sept. 16, 2011, 125 Stat. 291 , 316, 335.) 
35 U.S.C. § 33.  Unauthorized representation as practitioner.  
Whoever, not being recognized to practice before the Patent and Trademark Office, holds himself 
out or permits himself to be held out as so recognized, or as being qualified to prepare or prosecute 
applications for patent, shall be fined not more than $1,0 00 for each offense.  
(July 19, 1952, ch. 950, §  1, 66 Stat. 796; Jan. 2, 1975, 88 Stat. 1949.)  
CHAPTER 4—PATENT FEES, FUNDING, SEARCH SYSTEMS 
35 U.S.C. § 41(i).  Patent and trademark search systems.  
(i) ELECTRONIC PATENT AND TRADEMARK DATA.— 
(1) MAINTENANCE OF COLLECTIONS.—The Director shall maintain, for use by the public, paper, 
microform, or electronic collections of United States patents, foreign patent documents, and United 
States trademark registrations arranged to permit search for and retrieval of information.  The 
Director may not impose fees directly for the use of such collections, or for the use of the public 
patent or trademark search rooms or libraries. 
(2) AVAILABILITY OF AUTOMATED SEARCH SYSTEMS.—The Director shall provide for the full 
deployment of the automated search systems of the Patent and Trademark Office so that such 

 -288- January 1, 2026 
systems are available for use by the public, and shall assure full access by the public to, and 
dissemination of, patent and trademark information, using a variety of automated methods, including 
electronic bulletin boards and remote access by users to mas s storage and retrieval systems. 
(3) ACCESS FEES.—The Director may establish reasonable fees for access by the public to the 
automated search systems of the Patent and Trademark Office.  If such fees are established, a 
limited amount of free access shall be made available to users of the systems for purposes of 
education and training.  The Director may waive the payment by an individual of fees authorized by 
this subsection upon a showing of need or hardship, and if such a waiver is in the public interest. 
(4) ANNUAL REPORT TO CONGRESS.—The Director shall submit to the Congress an annual 
report on the automated search systems of the Patent and Trademark Office and the access by the 
public to such systems.  The Director shall also publish such report in the Federal Register.  The 
Director shall provide an opportunity for the submission of comments by interested persons on each 
such report.   
(Added Pub. L. 102-204, § 5(d)(1), 105 Stat. 1637, Dec. 10, 1991; Pub. L. 112-29, 125 Stat. 323, 324, Sept. 
16, 2011.) 
35 U.S.C. § 41 note.   Adjustment of trademark fees.  
(a) FEE FOR FILING APPLICATION.  Until such time as the Director sets or adjusts the fees 
otherwise, under such conditions as may be prescribed by the Director, the fee under section 31(a) 
of the Trademark Act of 1946 (15 U.S.C. 1113(a)) for: (1) the filing of a paper application for the 
registration of a trademark shall be $375; (2) the filing of an electronic application shall be $325; 
and (3) the filing of an electronic application meeting certain additional requirements prescribed by 
the Director shall be $275. The provisions of the second and third sentences of section 31(a) of the 
Trademark Act of 1946 shall apply to the fees established under this section.  
(b) REFERENCE TO TRADEMARK ACT OF 1946.  For purposes of this section, the “Trademark 
Act of 1946” refers to the Act entitled “An Act to provide for the registration and protection of 
trademarks used in commerce, to carry out the provisions of certain international conventions, and 
for other purposes.”  
(Pub. L. 108-447, Sec. 2, Div. B, Title VIII, Sec. 802, 118 Stat. 2809, 2929, Dec. 8, 2004; Pub. L. 112-29, 125 
Stat. 324, Sept. 16, 2011 .)   
35 U.S.C. § 42.  Patent and Trademark Office funding.  
(a) All fees for services performed by or materials furnished by the Patent and Trademark Office will 
be payable to the Director. 
(b) All fees paid to the Director and all appropriations for defraying the costs of the activities of the 
Patent and Trademark Office will be credited to the Patent and Trademark Office Appropriation 
Account in the Treasury of the United States.  
(c)(1) To the extent and in the amounts provided in advance in appropriations Acts, fees authorized 
in this title or any other Act to be charged or established by the Director shall be collected by and 
shall, subject to paragraph (3), be available to the Director to carry out the activities of the Patent 
and Trademark Office.   
(2) There is established in the Treasury a Patent and Trademark  Fee Reserve Fund. If fee 
collections by the Patent and Trademark Office for a fiscal year exceed the amount appropriated to 
the Office for that fiscal year, fees collected in excess of the appropriated amount shall be deposited 
in the Patent and Trademark Fee Reserve Fund. To the extent and in the amounts provided  in 

 -289- January 1, 2026 
appropriations Acts, amounts in the Fund shall be made available until expended only for obligation 
and expenditure by the Office  in accordance with paragraph (3). 
(3)(A) Any fees that are collected under this title, and any surcharges on such fees, may only be 
used for expenses  of the Office relating to the processing of patent applications and  for other 
activities, services, and materials relating to patents and  to cover a proportionate share of the 
administrative costs of the Office.  
(B) Any fees that are collected under section 31 of the Trademark Act of 1946, and any surcharges 
on such fees, may only be used for expenses of the Office relating to the processing of trademark 
registrations and for other activities, services, and materials relating to trademarks and to cover a 
proportionate share of the administrative costs of the Office . 
(d) The Director may refund any fee paid by mistake or any amount paid in excess of that required. 
(e) The Secretary of Commerce shall, on the day each year on which the President submits the 
annual budget to the Congress, provide to the Committees on the Judiciary of the Senate and the 
House of Representatives — 
(1) a list of patent and trademark fee collections by the Patent and Trademark Office during the 
preceding fiscal year; 
(2) a list of activities of the Patent and Trademark Office during the preceding fiscal year which were 
supported by patent fee expenditures, trademark fee expenditures, and appropriations;  
(3) budget plans for significant programs, projects, and activities of the Office, including out-year 
funding estimates; 
(4) any proposed disposition of surplus fees by the Office; and  
(5) such other information as the committees consider necessary.  
(July 19, 1952, c. 950, 66 Stat. 796; Nov. 14, 1975, Pub. L. 94-131, § 4, 89 Stat. 690; Dec. 12, 1980, Pub. L. 
96-517, § 3, 94 Stat. 3018; Aug. 27, 1982, Pub. L. 97-247, § 3(g), 96 Stat. 319; Sept. 13, 1982, Pub. L. 97-
258, § 3(i), 96 Stat. 1065; Nov. 10, 1998, Pub. L. 105-358, 112 Stat. 3272; Sept. 16, 2011, Pub. L. 112-29, 
125 Stat. 336; Jan 14, 2013, Pub. L. 112 -274, 126 Stat. 2457.) 

 -290- January 1, 2026 
NOTES OF OTHER STATUTES  
SOME U.S. CODE (AND C.F.R.) SECTIONS PROTECTING SPECIFIC NAMES, TERMS AND 
MARKS 
(This is a partial listing of some of the names, terms, initials and marks that are protected under the 
United States Code (and Code of Federal Regulations). Almost all of these sections protect 
symbols, emblems, seals, insignia, and badges, as well as the referenced name, term, initials, 
acronym, and mark. For information regarding other matter protected by statute, see the Index to 
the United States Code, especially under the terms "decorations, medals and badges," "coats of 
arms," "character," "insignia," "names," "seals" and "symbols." However, note that other sections 
also exist (e.g., District of Columbia Code) which are not indexed under these terms .) 
 
AmeriCorps, 42 U.S.C. § 5065; 45 C.F.R. 2540.500 Subpart E  
AMVETS [American Veterans], 36 U.S.C. § 22706 
America Espirito Sport Fraternite [see also United States Olympic Committee], 36 U.S.C. §  
220506 
American Ex-Prisoners of War, 36 U.S.C. §  20907 
American Legion, 36 U.S.C. § 21705 
The American National Theater and Academy, 36 U.S.C. §21904 
American Symphony Orchestra League, 36 U.S.C. § 22306 
American Veterans, 36 U.S.C. § 22706 
American War Mothers, 36 U.S.C. § 22505 
Big Brothers, 36 U.S.C. § 30106 
Big Brothers – Big Sisters of America, 36 U.S.C. § 30106 
The Big Brothers of America, Big Sisters International, Incorporated, 36 U.S.C.  § 30106 
Big Sisters, 36 U.S.C. § 30106 
Blinded Veterans Association, 36 U.S.C. § 30306 
Blue Star Mothers of America, Inc., 36 U.S.C.  § 30507 
Board for Fundamental Education, 36 U.S.C. § 30706 
Boy Scouts of America, 36 U.S.C. § 30905 
CIA [Central Intelligence Agency], 50 U.S.C.  § 3513 
CLF [Central Liquidity Facility], 18 U.S.C. § 709 
CMS [Centers for Medicare and Medicaid Services], 42 U.S.C.  § 1320b-10 
Centers for Medicare and Medicaid Services [CMS], 42 U.S.C.  § 1320b-10 
Central Intelligence Agency [CIA], 50 U.S.C.  § 3513 
Central Liquidity Facility, 18 U.S.C. § 709 
Citius Altius Fortius [see also United States Olympic Committee], 36 U.S.C. § 220506 
Civil Air Patrol, 36 U.S.C. § 40306 
Coast Guard [see United States Coast Guard], 14 U.S.C. § 934 
Coast Guard Auxiliary [see United States Coast Guard Auxiliary], 14 U.S.C. § 934 
Coast Guard Reserve [see United States Coast Guard Reserve], 14 U.S.C.  § 934 
Commodity Credit Corporation, 15 U.S.C. § 714m 
Corporation for National and Community Service, 42 U.S.C. §5065; 45 C.F.R. §  2540.520 
DEA [Drug Enforcement Administration], 18 U.S.C.  § 709 
DFC [United States International Development Finance Corporation], 18 U.S.C. §  709 
DHHS [Department of Health and Human Services], 42 U.S.C. § 1320b-10 
DIA [Defense Intelligence Agency], 10 U.S.C.  § 425 
DMA [Defense Mapping Agency], 10 U.S.C.  § 425 
DOT [Department of the Treasury], 31 U.S.C.  § 333 
Death Benefits Update, 42 U.S.C. § 1320b-10 
Defense Intelligence Agency [DIA], 10 U.S.C.  § 425 

 -291- January 1, 2026 
Defense Mapping Agency [DMA], 10 U.S.C.  § 425 
Department of Health and Human Services [DHHS], 42 U.S.C. § 1320b-10 
Department of Housing and Urban Development [HUD], 18 U.S.C.  § 709 
Department of the Treasury  [DOT], 31 U.S.C. § 333   
Deposit Insurance [when used "as part of the business or firm name of a person, corporation, 
partnership, business trust, association or other business entity engaged in the banking, 
loan, building and loan, brokerage, factorage, insurance, indemnity, savings or t rust 
business"], 18 U.S.C. § 709 
Disabled American Veterans, 36 U.S.C. § 50305 
Drug Enforcement Administration [DEA], 18 U.S.C. §  709 
F.B.I. [Federal Bureau of Investigation], 18 U.S.C. §  709 
FFA [Future Farmers of America], 36 U.S.C.  § 70907 
FHA [Federal Housing Administration], 18 U.S.C. § 709 
Federal [when used "as part of the business or firm name of a person, corporation, partnership, 
business trust, association or other business entity engaged in the banking, loan, building 
and loan, brokerage, factorage, insurance, indemnity, savings or trust business"], 18 U.S.C. 
§ 709 
Federal [when used "in the course of collecting or aiding in the collection of private debts or 
obligations, or being engaged in furnishing private police, investigation, or other private 
detective services"], 18 U.S.C.  § 712 
Federal Benefit Information, 42 U.S.C.  § 1320b-10 
Final Supplemental Plan, 42 U.S.C. § 1320b-10 
The Foundation of the Federal Bar Association, 36 U.S.C.  § 70506 
Funeral Expenses, 42 U.S.C. § 1320b-10 
Federal Bureau of Investigation [F.B.I.], 18 U.S.C.  § 709 
Federal Deposit, 18 U.S.C. § 709 
Federal Deposit Insurance, 18 U.S.C.  § 709 
Federal Deposit Insurance Corporation, 18 U.S.C.  § 709 
Federal Home Loan Bank, 18 U.S.C. § 709 
Federal Home Loan Mortgage Corporation, 12 U.S.C.  § 1457 
Federal Housing Administration [FHA], 18 U.S.C. § 709 
Federal intermediate credit bank, 18 U.S.C.  § 709 
Federal National Mortgage Association, 12 U.S.C. § 1723a 
Foster Grandparents, 42 U.S.C. § 5065; 45 C.F.R. § 2540.500 Subpart E 
Future Farmers of America [FFA], 36 U.S.C.  § 70907 
Geneva Cross [also specific reference to the emblem of the Greek red cross on a white ground], 
18 U.S.C. § 706 
Girl Scouts of the United States of America, 36 U.S.C.  § 80305 
Give a Hoot, Don’t Pollute, 16 U.S.C. §  580p-4; 36 C.F.R. § 261.22 
Government National Mortgage Association, 12 U.S.C. § 1723a; 18 U.S.C. § 709 
HHS [Health and Human Services], 42 U.S.C. § 1320b-10 
HUD [Department of Housing and Urban Development], 18 U.S.C.  § 709 
Department of Health and Human Services [DHHS], 42 U.S.C. § 1320b-10 
Health and Human Services [HHS], 42 U.S.C. § 1320b-10 
Housing and Home Finance Agency,18 U.S.C. § 709 
Ladies of the Grand Army of the Republic, 36 U.S.C.  § 130106 
Last Best Place, Omnibus Appropriations Act, Pub. L. No. 111 -8, §105, 123 Stat. 524 (2009)  
Learn and Serve America, 42 U.S.C. § 5065; 45 C.F.R. § 2540.500 Subpart E 
Life Saving Service [see Coast Guard or United States Coast Guard], 14 U.S.C.  § 934 
Lighthouse Service [see Coast Guard or United States Coast Guard], 14 U.S.C.  § 934 
Little League or Little Leaguer, 36 U.S.C.  § 130506 
Marine Corps, 10 U.S.C. § 8921 
Medicaid, 42 U.S.C. § 1320b-10 

 -292- January 1, 2026 
Medicare, 42 U.S.C. § 1320b-10 
The Military Chaplains Association of the United States of America, 36 U.S.C.  § 140304 
NASA [National Aeronautics and Space Administration; also flags, logo, seal], 51 U.S.C. § 
20141; 14 C.F.R. §  1221.101 
NCOA [Non Commissioned Officers Association of the United States of America], 36 U.S.C.  § 
154707 
NCUA [National Credit Union Administration], 18 U.S.C. § 709 
NCUSIF [National Credit Union Share Insurance Fund], 18 U.S.C.  § 709 
NGA [National Geospatial-Intelligence Agency], 10 U.S.C.  § 425 
NIMA [National Imagery and Mapping Agency], 10 U.S.C. § 425 
NRO [National Reconnaissance Office], 10 U.S.C.  § 425 
NSA [National Security Agency], 50 U.S.C. § 3613 
National [when used "as part of the business or firm name of a person, corporation, partnership, 
business trust, association or other business entity engaged in the banking, loan, building 
and loan, brokerage, factorage, . . . savings or trust business"], 18 U.S.C. § 709 
National [when used "in the course of collecting or aiding in the collection of private debts or 
obligations, or being engaged in furnishing private police, investigation, or other private 
detective services"], 18 U.S.C.  § 712 
National Aeronautics and Space Administration [NASA; also flags, logo, seal], 51 U.S.C. § 
20141; 14 C.F.R. §  1221.101 
National Civilian Community Corps, 42 U.S.C. § 5065; 45 C.F.R. § 2540.500 Subpart E 
National Conference of State Societies, Washington, District of Columbia, 36 U.S.C. § 150507 
National Conference on Citizenship, 36 U.S.C.  § 150707 
National Credit Union, 18 U.S.C. § 709 
National Credit Union Administration [NCUA], 18 U.S.C. § 709 
National Credit Union Board, 18 U.S.C. § 709 
National Credit Union Share Insurance Fund [NCUSIF], 18 U.S.C.  § 709 
National Geospatial-Intelligence Agency [NGA], 10 U.S.C.  § 425 
National Imagery and Mapping Agency [NIMA], 10 U.S.C. § 425 
National Music Council, 36 U.S.C. § 152306 
National Reconnaissance Office [NRO], 10 U.S.C.  § 425 
National Safety Council, 36 U.S.C. § 152506 
National Society, Daughters of the American Colonists, 36 U.S.C.  § 152907 
National Society of the Daughters of the American Revolution, 36 U.S.C.  § 153104 
National Security Agency [NSA], 50 U.S.C. § 3613 
National Senior Service Corps, 42 U.S.C. § 5065; 45 C.F.R. §  2540.520 
National Tropical Botanical Garden, 36 U.S.C. § 153506 
National Woman’s Relief Corps, Auxiliary to the Grand Army of the Republic, 36 U.S.C.  § 
153706 
Naval Sea Cadet Corps, 36 U.S.C. § 154106, 
Non Commissioned Officers Association, 36 U.S.C.  § 154707 
Non Commissioned Officers Association of the United States of America [NCOA], 36 U.S.C.  § 
154707 
ODNI [Office of the Director of National Intelligence], 50 U.S.C.  § 3233 
Office of the Director of National Intelligence [ODNI], 50 U.S.C.  § 3233 
Olympiad [see also United States Olympic Committee], 36 U.S.C. § 220506 
Olympic [and other names;also United States Olympic Committee and specific reference to (1) 
the symbol of the International Olympic Committee, consisting of five interlocking rings, and 
(2) the emblem consisting of an escutcheon having a blue chief and vertically extending red 
and white bars on the base with five interlocked rings displayed on the chief], 36 U.S.C.  § 
220506 
PHA [Public Housing Administration], 18 U.S.C. § 709 
Pan-American [see also United States Olympic Committee], 36 U.S.C. § 220506 

 -293- January 1, 2026 
Paralympic [see also United States Olympic Committee], 36 U.S.C. § 220506 
Paralympiad [see also United States Olympic Committee], 36 U.S.C. § 220506 
Paralyzed Veterans of America, 36 U.S.C. § 170105 
Pearl Harbor Survivors Association, 36 U.S.C. § 170307 
Peace Corps, 22 U.S.C. § 2518 
Post Office, 18 U.S.C.  § 1729 
Presidio Trust, 16 U.S.C.  § 460bb 
Public Housing Administration [PHA], 18 U.S.C. § 709 
Red Crescent [also Red Crescent emblem], 18 U.S.C.  § 706a 
Red Cross [also specific reference to the emblem of the Greek red cross on a white ground], 18 
U.S.C. § 706 
Reserve [when used "as part of the business or firm name of a person, corporation, partnership, 
business trust, association or other business entity engaged in the banking, loan, building 
and loan, brokerage, factorage, insurance, indemnity, savings or trust business"], 18 U.S.C. 
§ 709 
Reserve Officers Association of the United States, 36 U.S.C.  § 190106 
Retired and Senior Volunteer Program, 42 U.S.C. §  5065; 45 C.F.R. § 2540.500 Subpart E 
Retired Enlisted Association, 36 U.S.C. § 190307 
The Retired Enlisted Association, Incorporated [TREA], 36 U.S.C.  § 190307 
SSA [Social Security Administration], 42 U.S.C. § 1320b-10 
SSI [Supplemental Security Income Program], 42 U.S.C. § 1320b-10 
Secret Service, 18 U.S.C. § 709 
Secret Service Uniformed Division [U.D.], 18 U.S.C.  § 709 
Secretary of the Treasury [and title of any other officer or employee], 31 U.S.C.  § 333 
Senior Companion Program, 42 U.S.C. § 5065; 45 C.F.R. § 2540.500 Subpart E 
Senior Corps, 42 U.S.C. §5065; 45 C.F.R. § 2540.500 Subpart E 
Share Insurance, 18 U.S.C. § 709 
Smokey Bear, 16 U.S.C. §580p-4; 36 C.F.R. § 261.22 
Social Security [and symbols and emblems], 42 U.S.C. § 1320b-10 
Social Security Account, 42 U.S.C. § 1320b-10 
Social Security Administration [SSA], 42 U.S.C. § 1320b-10 
Social Security System, 42 U.S.C. § 1320b-10 
Sons of Union Veterans of the Civil War, 36 U.S.C.  § 200306 
Supplemental Security Income Program [SSI], 42 U.S.C. § 1320b-10 
TREA [The Retired Enlisted Association], 36 U.S.C.  § 190307 
Third Protocol Emblem, 18 U.S.C. § 706a 
Treasurer of the United States [and title of any other officer or employee], 31 U.S.C.  § 333 
U.D. [Secret Service Uniformed Division], 18 U.S.C.  § 709 
USCG [United States Coast Guard], 14 U.S.C. § 934 
USCGR [United States Coast Guard Reserve], 14 U.S.C. § 934 
USHA [United States Housing Authority], 18 U.S.C. § 709 
USMC or U.S.M.C. [United States Marine Corps; and seal, logo, emblem and others], 10 U.S.C. 
§ 8921 
U.S.M.S. [United States Marshals Service or U.S. Marshals Service; and logo or insignia], 18 
U.S.C. § 709 
USO [United Service Organizations, Incorporated], 36 U.S.C.  § 220106 
U.S.S.S. [United States Secret Service], 18 U.S.C. § 709 
United Service Organizations, Incorporated [USO], 36 U.S.C.  § 220106 
United States or U.S. [when used "as part of the business or firm name of a person, corporation, 
partnership, business trust, association or other business entity engaged in the banking, 
loan, building and loan, brokerage, factorage, insurance, indemnity, savings or trust 
business"], 18 U.S.C. § 709 

 -294- January 1, 2026 
United States or U.S. [when used "in the course of collecting or aiding in the collection of private 
debts or obligations, or being engaged in furnishing private police, investigation, or other 
private detective services"], 18 U.S.C.  § 712 
United States Capitol Historical Society, 36 U.S.C. § 220306 
United States Coast Guard [USCG], 14 U.S.C. § 934 
United States Coast Guard Auxiliary, 14 U.S.C. § 934 
United States Coast Guard Reserve [USCGR], 14 U.S.C. § 934 
United States Housing Authority [USHA], 18 U.S.C. § 709 
United States International Development Finance Corporation [DFC], 18 U.S.C. §  709 
United States Marshal or U.S. Marshal, 18 U.S.C. § 709 
United States Marshals Service or U.S. Marshals Service [U.S.M.S.; and logo or insignia], 18 
U.S.C. § 709 
United States Marine Corps [USMC; and seal, logo, emblem and others], 10 U.S.C.  § 8921 
United States Mint or U.S. Mint, 18 U.S.C.  § 709 
United States of America Vietnam War Commemoration, 10 U.S.C. § 113 
United States Olympic and Paralympic Committee [USOC], 36 U.S.C. § 220506 
United States Railway Association, 45 U.S.C. § 711 
United States Savings Bond, 31 U.S.C. § 333 
United States Secret Service [U.S.S.S.], 18 U.S.C. § 709 
369th Veterans' Association, 36 U.S.C. § 210307 
Veterans of Foreign Wars of the United States, 36 U.S.C.  § 230105 
Veterans of World War I of the United States of America, Incorporated, 36 U.S.C.  § 230306 
Vietnam Veterans of America, 36 U.S.C. § 230507 
Vietnam Veterans of America, Inc., 36 U.S.C. § 230507 
VISTA, 42 U.S.C. § 5065; 45 C.F.R. §  2540.520 
White House Commission on the National Moment of Remembrance, 36 U.S.C.  § 116 
Woodsy Owl, 16 U.S.C. § 580p-4; 36 C.F.R. § 261.22 

 -295- January 1, 2026 
SOME SECTIONS OF THE UNITED STATES CODE WHICH RELATE TO TRADEMARKS 
(This is a partial listing of sections relating to trademarks. ) 
7 U.S.C. § 136, The Federal Insecticide, Fungicide and Rodenticide Act, relating to the 
requirements for labeling of economic poisons.  
7 U.S.C. §§ 1551-1611, The Federal Seed Act, relating to requirements for labeling of seeds in 
interstate commerce. 
15 U.S.C. § 1, Sherman Act (Sec. 1), as amended by Miller-Tydings Act, relating to restraint of 
trade. 
15 U.S.C. § 45, relating to unfair methods of competition.  
15 U.S.C. § 52, relating to false advertisements. 
15 U.S.C. §§ 68-68j, The Wool Products Labeling Act, relating to the labeling of wool products. 
15 U.S.C. §§ 69-69j, The Fur Products Labeling Act, relating to the labeling of fur and fur 
products. 
15 U.S.C. §§ 70-70k, the Textile Fiber Products Identification Act, relating to the use of 
trademarks and names in the advertising or labeling of textile fiber products.  
15 U.S.C. § 297, relating to use of marks, trade names, words and labeling in connection with 
the importation, exportation or carriage in interstate commerce of merchandise made of gold 
or silver or their alloys.  
15 U.S.C. §§ 1261-1273, relating to the labeling of hazardous substances.  
15 U.S.C. § 1511, relating to jurisdiction of Department of Commerce over Patent and 
Trademark Office.  
15 U.S.C. §§ 5401 et seq., relating to the recordation of insignia of manufacturers and private 
label distributors to ensure the traceability of a fastener to its manufacturer or private label 
distributor. (See notice at 1192 TMOG 19 (Nov. 5, 1996)).  
18 U.S.C. § 701, relating to use of any badge, identification card, or other insignia, or any 
colorable imitation thereof, of departments, agencies, and independent offices of the United 
States. 
18 U.S.C. § 704, relating to the unauthorized use of any badge, decoration, or medal, or any 
colorable imitation thereof, of the armed forces of the United States.  
18 U.S.C. § 705, relating to the unauthorized use on merchandise of any badge, medal, 
emblem, or other insignia, or any colorable imitation thereof, of any veteran’s organization 
incorporated by enactment of Congress or of any organization formally recognized by any 
such veteran’s organization as an auxiliary thereof. 
18 U.S.C. § 709, relating to false advertising or misuse of names to indicate federal agency. 
Also, prohibitions against using certain terms and initials within the financial, insurance, 
housing, protection, investigatory and other fields.  
18 U.S.C. § 710, relating to use, manufacture, or sale of any cremation urn of a design 
approved by the Secretary of Defense for use to retain the cremated remains of deceased 
members of the armed forces or an urn which is a colorable imitation of the approved 
design, except when authorized under regulation made pursuant to law.  
18 U.S.C. § 712, relating to misuse by collecting agencies or private detective agencies of 
names, emblems, and insignia to indicate federal agency. 
18 U.S.C. § 713, relating to the use of likenesses of the great seal of the United States, and of 
the seals of the President and Vice President.  
18 U.S.C. § 1001, relating to statements, representations, writings or documents made to any 
department or agency of the United States.  
18 U.S.C. § 1158, relating to counterfeiting or imitating Government trademarks for Indian 
products. 
18 U.S.C. § 2320, relating to criminal penalties for trafficking in counterfeit goods and services. 
19 U.S.C. § 1337(a), Tariff Act of 1930, relating to unfair practices in import trade.  

 -296- January 1, 2026 
19 U.S.C. § 1526(a), Tariff Act of 1930, barring importation into the United States of 
merchandise of foreign manufacture bearing a trademark registered in the Patent and 
Trademark Office by a person domiciled in the United States if copy of the registration 
certificate has been filed with the Secretary of the Treasury unless written consent of the 
trademark owner has been secured.  
19 U.S.C. §§ 2111 et seq., providing authority for trade agreements and also annual reports to 
Congress on barriers to trade include the treatment of intellectual property rights among 
acts, policies, and practices that constitute barriers to trade.  
19 U.S.C. § 2411, relating to foreign countries’ provision for adequate and effective protection of 
the intellectual property rights of U.S. nationals.  
19 U.S.C. § 2462(c), relating to the consideration of intellectual property rights as a factor for 
foreign countries to receive benefits under the Generalized System of Preferences (GSP).  
21 U.S.C. §§ 601 et seq., Federal Meat Inspection Act, relating to the inspection and labeling of 
meat and products. 
21 U.S.C. §§ 301, 321-392, The Federal Food, Drug, and Cosmetic Act, relating to the 
requirements for labeling of food, drugs, and cosmetics; avoiding trademarks in establishing 
official names. 
21 U.S.C. § 457, Poultry Products Inspection Act, relating to requirements for labeling of poultry 
products in interstate commerce.  
27 U.S.C. §§ 201-219a, The Federal Alcohol Administration Act, relating to certificates of label 
approval of alcoholic beverages. 
28 U.S.C. § 1254, relating to review of cases by the Supreme Court.  
28 U.S.C. § 1295, relating to jurisdiction of United States Court of Appeals for the Federal 
Circuit. 
28 U.S.C. § 1338, relating to jurisdiction of District Courts in trademark suits.  
42 U.S.C. § 1320b-10, relating to misuse of Social Security or Medicare names, symbols, 
emblems. 
48 U.S.C. § 734, Puerto Rico, relating to statutes applicable to.  
48 U.S.C. §§ 1405(q), 1574(c) and 1643, Virgin Islands, relating to statutes applicable to, and to 
the non-applicability of certain provisions of the Trademark Act to the Virgin Islands.  
48 U.S.C. § 1421c, Guam, relating to statutes applicable to (see also Public Law 87-845, 
October 18, 1962, 4-CZC-471, Canal Zone Code, relating to the application of U.S. patent, 
trademark and copyright laws in the Canal Zone.) 
50 U.S.C. §§  4301, 4340 Trading with the Enemy Act, providing for disposition of vested 
trademarks. 
 
District of Columbia Code  
Section 22-3401, relating to use of District of Columbia and other related names and initials 
used in connection with investigatory or collection services. (Oct. 16, 1962, 76 Stat. 1071)  
  