---
name: skillhub-skill-qstar-marketing-content-suite
description: "# Q-Star 营销内容套件生成"
---

# Q-Star 营销内容套件生成

根据一份产品资料，一次生成小红书、抖音、公众号、朋友圈、详情页卖点、销售话术和 FAQ。

输入：`product`、`audience`、`selling_points`、`proof`、`channels`、`tone`。

输出：多平台内容套件、销售流程、异议处理和 FAQ。不虚构销量、认证、客户、收益或效果；缺失事实会标记为待补充。

收费接口：`POST https://skill-api.q-star.ink/v1/skills/qstar-marketing-content-suite/invoke`，每次 ¥8.90。首次调用返回 HTTP 402，支付确认后携原订单号重试。
