# SkillHub 平台适配

## 平台能力
- SkillHub 支持 X402 支付协议
- 技能按次付费（微信）

## 适配要点
- 网关 BASE_URL：https://phantom-ai.cn
- 技能注册：pay_gateway/skills_config.d/k8s-peizhi-jianchaqi.json
- 价格：¥1（100 分）

## 注意事项
- 升级包命名：pay_gateway_upgrade_vXX_K8s配置检查器_100_YYYYMMDD.zip
- 部署：wget 短链 → unzip → update_gateway_config_v4.sh k8s-peizhi-jianchaqi
- 预期：34 配置 → 47 技能 → 402 ✅
