# 扣子平台适配

## 平台能力
- 扣子支持 X402 支付协议（weixinpay_ 工具环境）
- 交付支持 HTML 文件

## 适配要点
- 支付链路：weixinpay_pay → 网关 phantom-ai.cn → 402 → 支付 → X-Out-Trade-No 履约
- 报告交付：麦肯锡风格 HTML 体检报告（单文件内联 CSS），可下载/预览
- 输入方式：用户对话框粘贴 YAML 配置

## 注意事项
- 未检测到 weixinpay_ 工具 → 提示安装 skillhub 运行时后停止
- 严格按 X402 协议处理支付状态，不跳过支付直接履约
