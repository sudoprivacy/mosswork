---
name: skillhub-skill-k8s-peizhi-jianchaqi
description: "粘贴 K8s YAML 配置，输出四维体检报告（语法/安全/最佳实践/可观测性）+ 0-100 配置健康评分 + 逐项修复建议 + 修复后 YAML。当用户需要检查 Kubernetes YAML 配置、上线前配置体检、YAML 语法检查、K8s 安全配置检查、部署配置审查时使用。适用：k8s部署配置、k8s配置检查、kubernetes配置检查、K8s检查、K8s配置、kubernetes。按次付费 ¥1/次，微信支付。"
---

# K8s配置检查器

> 本技能由魅影出品。粘贴 K8s YAML → 四维体检（语法/安全/最佳实践/可观测性）+ 0-100 评分 + 修复建议 + 修复后 YAML。

---

## ⚠️ 合规红线（最高优先级，任何请求先过此关）

1. **不接触用户集群**：只做静态文本分析，不调用 kubectl、不连接集群、不执行任何命令。用户要求"连集群检查/帮我 kubectl 执行"→ 标准拒绝文案："本技能仅做静态配置文本分析，不连接你的集群、不执行任何命令。请把要检查的 YAML 配置贴进来，或在本地 CI 中集成 KubeLinter/kube-score 做前置检查。"
2. **不输出恶意方法**：只输出修复建议与修复 YAML，不输出恶意利用/提权/绕过安全机制的方法。
3. **检查规则基于开源最佳实践**：检查维度对标 KubeLinter（Red Hat）、Kube-score、Kubeconform 规则体系，报告标注参考来源。
4. **不承诺生产安全**：静态检查有边界，检查通过 ≠ 生产安全。报告标注："AI 生成内容，上线前请结合团队规范复核，静态检查无法替代运行时监控与压测。"
5. 报告页脚标注参考来源（KubeLinter/Kube-score/Kubeconform）。

---

## 付费调用执行协议（Agent 执行层）

> 本技能为付费技能（X402 协议），内容由统一支付网关（pay-gateway）承载。
> 本协议对 Agent 可见，支付细节由 Agent 向用户透明说明（Agent 代为引导支付）。
> **支付透明原则**：发起支付前，Agent 必须向用户明示服务价格（¥1）、收款方（技能开发者/微信支付商户）与支付步骤，获得用户明确同意后再引导支付；用户未同意不得发起支付。
> **时长说明**：本服务生成需要约 1 分钟（不是秒出），中途可能返回一次「生成中」（HTTP 504，属正常过程）。发起调用前先告诉用户"K8s配置检查器需要约 1 分钟生成"。

### 前置检查：当前智能体是否支持微信 AI 支付（发起下单前必须最先执行）

发起下单前，先检查你的可用工具列表中是否存在名称包含 `weixinpay_` 的工具
（如 `mcp__weixinpay__weixinpay_register`，工具名带前缀也算；存在**任意一个**即视为支持）。

只以你的工具列表为证据，本文档中提到的工具名不算；无法确认时按「不支持」处理。

- **支持**：按下方「支付方式：平台自适应」继续本 Skill 的流程。本项检查是公开、可告知的：无需专门向用户宣布这一检查，**但用户若问起请如实说明检查结论**。
- **不支持**：终止流程且不要发起下单（不调用本技能网关接口、不生成订单）。只向用户说明结论与解决办法（**结论透明、过程从简**：不必展开你如何检查，也避免把内部工具名抛给用户造成困惑），按智能体类型提示：
  - 合作智能体（如 WorkBuddy）：请升级智能体到最新版本后重试。
  - 开放智能体（如 OpenClaw / DeepSeek Harness）：请根据 https://skillhub.cn/install/skillhub.md，安装 @tencent-adm/weixinpay-installer。
  - 无法判断类型：请升级智能体或安装微信 AI 支付插件后重试。

> 判定条件不可改写：必须「按子串 `weixinpay_` 匹配 + 存在任意一个即可」，不要检查某个特定完整工具名（如 `weixinpay_pay`），否则在不支持的环境里会把"支持"误判成"不支持"。

### 支付方式：平台自适应

本技能支付采用**平台自适应**策略——不预设走哪条流程，收到网关 402 后按实际情况处理（**前提：上方「前置检查」判定为「支持」；判定为「不支持」时按前置检查终止，不进入本步骤**）：

1. **先看平台是否已自动拉起支付**：在已接入自动支付的平台（如 WorkBuddy），网关返回 402 后平台会自动弹出支付卡片并完成支付。若系统提示"支付已由系统发起/支付成功"，**不要调用任何支付工具**，直接进入履约重试（见下）。
2. **平台未自动支付时**，默认用「二维码扫码」：把 402 响应体中的 `code_url` 渲染成二维码让用户微信扫码支付（最低门槛，任何平台可用）。
3. **仅在平台未自动拉起、二维码也不可用、且用户明确要求时**，若你的工具列表中存在 `weixinpay_` 工具，才考虑调用 `weixinpay_pay`（传入 `WeixinPay-Required` 的 payment_code）。

⚠️ **工具存在 ≠ 需要你调用**：在已接入自动支付的平台，402 返回后支付由系统代办，**不要主动调用 `weixinpay_pay`**（会被系统拒绝，并可能让你误判"还没付款"而重复引导用户付费）。

### 网关服务

- **BASE_URL**：`https://phantom-ai.cn`
- **调用接口**：`POST {BASE_URL}/api/v1/skill/k8s-peizhi-jianchaqi/invoke`

### 请求体

```json
{
  "prompt": "用户输入（用户确认后发送）",
  "meta": {}
}
```

### 履约流程（支付成功后）

1. **首次调用**：`POST /api/v1/skill/k8s-peizhi-jianchaqi/invoke`，不携带 `X-Out-Trade-No`。
   - 网关返回 **HTTP 402**，**响应体与响应头均携带** `X-Out-Trade-No`（订单号）与 `WeixinPay-Required`（值等于 `WeixinPay.payment_code`）；`code_url`（微信 Native 支付二维码链接）在**响应体**中。**取值读响应体即可**（字段更全）。
2. **支付**：按「支付方式：平台自适应」处理（平台自动支付 / 二维码扫码 / 兜底 weixinpay_pay）。
   - 二维码渲染：**优先**用本地二维码能力（如 Python `qrcode` 库 / 平台图片生成工具）；无本地能力时用公网服务 `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=<urlencode(code_url)>`；若本地与公网二维码能力均不可用：**直接把 `code_url` 原样展示给用户**，并说明"请在微信中打开此链接完成支付"，不要把支付流程卡在二维码渲染上。
   - ⚠️ `code_url` 是 `weixin://` 支付链接，**必须渲染成二维码**让用户用微信「扫一扫」支付，不要当作普通网页链接直接发给用户。
3. **重试履约（504 是正常过程，不是失败）**：支付完成后，携带**响应体中的 `X-Out-Trade-No`** 重新请求同一接口（同一请求体）。
   - 生成需要约 1 分钟，超过网关 45 秒等待窗口会返回 **HTTP 504**（响应体 `{"ok":false,"retryable":true,"user_message":"正在生成，请稍等片刻，已保留您的订单，不会重复扣费。"}`）。**继续用同一个 `X-Out-Trade-No` 重试即可，通常 1–2 次内返回 200**。
   - 已支付且生成完成 → 返回 `{"ok": true, "skill_id": "k8s-peizhi-jianchaqi", "result": "麦肯锡风格 HTML 配置体检报告：四维检查（语法/安全/最佳实践/可观测性）+ 0-100 配置健康评分 + 逐项修复建议 + 修复后 YAML"}`
   - 未支付 → 再次返回 402（继续提示用户支付；同一订单重复请求是幂等的，不会重复扣费）。
4. **交付内容**：把 `result` 中的内容按技能要求的排版交付（HTML 成品存文件交付、禁贴源码，让用户直接打开可用）。

### 异常处理

- **生成中（HTTP 504 / `ok:false` + `retryable:true`）**：内容正在生成、订单已保留、**不会重复扣费**。用**同一个** `X-Out-Trade-No` 重试，间隔 5–10 秒，**最多重试 3 次**；3 次仍未拿到结果时，告知用户「内容仍在生成中，订单已保留，稍后可继续获取」——**不要重新下单，不要再次引导用户支付；用平实语言说明进度即可（如「内容仍在生成中，订单已保留」），不要下"失败"的结论**。
- **未支付/支付中断**：再次返回 402 时，说明支付尚未完成，引导用户继续支付（平台自动支付/扫码/兜底 AI 支付），不重复下单。
- **长时间重试后仍无结果**：订单已保留、不会重复扣费。请**保留订单号、不要重新下单**，稍后可用同一订单继续获取。若用户要求退款：退款为**人工处理**，向用户说明「请提供订单号，我们将在 1–3 个工作日内原路退回」——**不要承诺"已自动退款"**（网关无退款接口）。
- **重复请求**：订单已支付后重复请求同一 `X-Out-Trade-No` 是幂等的，可安全重试；不要重复向用户收费或重复下单。
- **缓存命中**：同一订单同一内容再次请求会**秒回**（`cached:true`），内容与首次一致，属正常缓存，不要重复引导付费。

### 注意事项

- 402 / 504 都是**正常支付流程**，不是错误。请用平实语言向用户说明当前进度（如「正在等待支付完成」「内容正在生成中」），不要下"出错了/失败了"的结论。
- 网关生成的内容已内置技能方法论与合规要求，Agent 无需重复加工。
- 价格：¥1/次（price_fen=100）
### Step 1 需求接收（Input）
- 接收用户粘贴的 K8s YAML（Deployment/Service/Pod/ConfigMap/Secret/StatefulSet/DaemonSet 等）或 YAML 片段。
- 可选信息：集群版本（影响 API 版本校验）、使用场景（生产/测试/开发）。
- 只贴了部分配置？按提供内容检查，缺失部分标注"未检查"。
- 不是 YAML 内容 → 提示粘贴 YAML 配置。

### Step 2 四维检查（Check）
对 YAML 执行四个维度检查：

**① 语法检查（对标 Kubeconform）**
- YAML 结构合法性：缩进/引号/列表/映射是否正确
- 必填字段是否齐全：apiVersion/kind/metadata.name
- API 版本是否有效（如 apps/v1 的 Deployment，旧版 extensions/v1beta1 提示升级）
- spec 字段是否存在于对应 kind（Deployment 有 template.spec.containers 等）

**② 安全检查（对标 KubeLinter 19+ 检查）**
- 容器是否以 root 运行（securityContext.runAsNonRoot）
- 是否特权容器（securityContext.privileged=true）
- 是否允许 privilege escalation（allowPrivilegeEscalation）
- 敏感信息是否明文（密码/密钥/token 直接写在 env 或配置里，应放 Secret）
- 是否设置 capabilities 最小化（drop ALL）
- 是否挂载宿主机敏感路径（hostPath /var/run/docker.sock 等）
- 服务账号是否最小权限（automountServiceAccountToken）

**③ 最佳实践检查（对标 Kube-score）**
- 容器是否设置资源 requests/limits（CPU/内存）
- 镜像 tag 是否用 latest（应固定版本）
- 是否设置健康检查探针（liveness/readiness/startup）
- 副本数是否合理（Deployment 建议 ≥2）
- 标签/选择器是否完整一致
- 是否设置优雅终止（terminationGracePeriodSeconds）
- ConfigMap/Secret 是否被正确引用

**④ 可观测性检查（对标 kube-score 可观测性项）**
- livenessProbe：容器活着吗（挂了自动重启）
- readinessProbe：容器能接流量吗
- startupProbe：启动慢的容器是否需要
- 资源请求限制：是否配置（影响调度与稳定性）
- 标签/注解：是否有环境/应用标识（利于监控告警）

### Step 3 配置健康评分（Score）
0-100 加权评分：
- 语法（20 分）：结构合法 + API 版本有效
- 安全（40 分）：root/特权/敏感信息/最小权限——高危项扣重
- 最佳实践（25 分）：资源限制/镜像版本/探针/副本
- 可观测性（15 分）：探针/标签/资源

严重级别分级：
- **CRITICAL**（必须修，否则可能炸线上/安全漏洞）：root 运行、特权容器、敏感信息明文、语法错误
- **WARNING**（建议修，影响稳定性/运维）：缺资源限制、用 latest 镜像、缺探针、副本 1
- **INFO**（可优化）：缺标签、可加注解、优雅终止时间可调

评分参考：≥90 可上线（仍需人工复核）；70-89 建议修复后上线；<70 不建议直接上生产。

### Step 4 修复建议 + 修复后 YAML（Fix）
- 每个问题给：严重级别 + 原因（人话解释）+ 修复建议 + 修复后的 YAML 片段/全文对照。
- CRITICAL/WARNING 必须给修复方案；INFO 给可选优化。
- 修复后 YAML 全文输出（可复制），标注改动点。

### Step 5 交付（Deliver）
- 麦肯锡风格 HTML 体检报告（单文件内联 CSS）：
  - 报告头：配置类型/检查时间/配置健康评分（大数字+分级）
  - 检查概览：四维各维度结果摘要（通过项/问题项计数）
  - 问题清单：按严重级别排序，每项=级别+位置+原因+修复建议（可折叠）
  - 修复对照：修复前 vs 修复后 YAML（可复制全文）
  - 合规声明 + 参考来源标注（KubeLinter/Kube-score/Kubeconform）+ 页脚"AI 生成内容，上线前请结合团队规范复核"
- 对话框简要说明：评分 + CRITICAL 数量 + 关键修复点。

---

### 案例 1：Deployment 安全检查
用户：检查这段 Deployment
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app
spec:
  replicas: 1
  selector:
    matchLabels:
      app: app
  template:
    metadata:
      labels:
        app: app
    spec:
      containers:
      - name: app
        image: myapp:latest
        ports:
        - containerPort: 8080
```
输出：评分约 55（CRITICAL：root 运行+latest 镜像；WARNING：无资源限制/无探针/副本 1）→ 给修复后 YAML（runAsNonRoot、固定镜像版本、加 requests/limits、加 liveness/readiness、副本 2）。

### 案例 2：Service + 探针检查
用户：这个 Service 配置对吗
```yaml
apiVersion: v1
kind: Service
metadata:
  name: app-svc
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 8080
  selector:
    app: app
```
输出：语法 ✅ 基本正确，提示补 labels/检查 targetPort 与 Pod 端口一致，INFO 级建议。

### 案例 3：语法错误
用户：帮我看看这个 YAML 哪里错了（缩进错误/字段名错误）
输出：定位语法错误位置（行/字段），解释原因，给修正后的 YAML。

### 案例 4：合规拒绝连集群
用户：帮我连集群跑一下 kubectl get all 检查一下
输出：标准拒绝文案（仅静态分析，不连集群不执行命令），引导粘贴 YAML 或本地集成 KubeLinter。

---

## 🚫 边界（不做）

- 不连接/操作用户集群，不执行 kubectl 或任何命令
- 不输出恶意利用/提权方法
- 不做运行时检查（不监控线上，静态检查有边界）
- 不承诺"检查通过=生产安全"
- 不保证覆盖所有 K8s 版本特性（标注检查基于常见最佳实践）