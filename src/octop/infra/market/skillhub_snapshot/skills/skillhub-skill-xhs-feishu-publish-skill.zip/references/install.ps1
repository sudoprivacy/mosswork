# 飞书表格 → 小红书 半自动发布 · 安装脚本（Windows）
# 用法：在解压后的技能目录里右键「使用 PowerShell 运行」，或：
#   powershell -ExecutionPolicy Bypass -File install.ps1
$ErrorActionPreference = "Stop"

$SelfDir  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SkillName = Split-Path -Leaf $SelfDir.TrimEnd('\')
$Dest     = Join-Path $env:USERPROFILE ".workbuddy\skills\$SkillName"

Write-Host "== 安装技能：$SkillName =="
Write-Host "源目录  : $SelfDir"
Write-Host "目标目录: $Dest"

if (-not (Test-Path $Dest)) { New-Item -ItemType Directory -Path $Dest | Out-Null }

# 复制全部文件，排除本机运行时产物
$Excludes = @(".xhs_work", ".xhs_browser_profile", "__pycache__", ".pytest_cache", ".git", "dist")
$files = Get-ChildItem -Path $SelfDir -Recurse -File | Where-Object {
    $rel = $_.FullName.Substring($SelfDir.Length).TrimStart('\','/')
    -not ($Excludes | Where-Object { $rel -eq $_ -or $rel.StartsWith("$_") })
}
foreach ($f in $files) {
    $target = Join-Path $Dest $f.FullName.Substring($SelfDir.Length).TrimStart('\','/')
    $tDir = Split-Path -Parent $target
    if (-not (Test-Path $tDir)) { New-Item -ItemType Directory -Path $tDir | Out-Null }
    Copy-Item -Path $f.FullName -Destination $target -Force
}
Write-Host "[ok] 技能文件已就位"

# 安装 Python 依赖（WorkBuddy 自带 managed python 优先）
$Py = "python"
$wbPy = Join-Path $env:USERPROFILE ".workbuddy\binaries\python\versions\3.13.12\python.exe"
if (Test-Path $wbPy) { $Py = $wbPy }

Write-Host "== 安装依赖 =="
& $Py -m pip install requests PyYAML playwright 2>&1 | Select-Object -Last 3
& $Py -m playwright install chromium 2>&1 | Select-Object -Last 3
Write-Host "[ok] 依赖安装完成"

Write-Host ""
Write-Host "==================== 安装完成 ===================="
Write-Host "下一步（只需做一次）："
Write-Host "  1) 去飞书开放平台(open.feishu.cn)建一个企业自建应用，开通 bitable:app、drive:media 权限，发布并把它加为你的多维表格「可编辑」协作者"
Write-Host "  2) 在技能目录执行："
Write-Host "       python scripts/xhs_publish.py setup --url '<你的飞书多维表格链接>'"
Write-Host "  3) 体检："
Write-Host "       python scripts/xhs_publish.py check"
Write-Host "  4) 发第一篇："
Write-Host "       python scripts/xhs_publish.py publish"
Write-Host "==================================================="
