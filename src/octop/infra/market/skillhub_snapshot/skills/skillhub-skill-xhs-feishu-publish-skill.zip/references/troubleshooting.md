# 排错手册

出问题时按这个顺序排查：**check → fetch → prepare → publish**。前三步都不碰浏览器，能快速定位是飞书侧还是小红书侧的问题。

```bash
python scripts/xhs_publish.py check     # 先看这一条
python scripts/xhs_publish.py fetch     # 飞书能否取到数
python scripts/xhs_publish.py prepare   # 配图能否下载、内容是否超限
python scripts/xhs_publish.py publish   # 才是浏览器环节
```

---

## 一、飞书取数

### `code=91403 Forbidden` / 没配 app_id、app_secret（v1.5.0 起自动处理）

应用没被加为这个 base 的协作者，或者你压根没填自建应用凭证。
v1.5.0 起只要本机装了并登录过 `lark-cli`，技能会自动切到用户身份通道，
日志里出现 `[i] OpenAPI 权限不足，自动改用 lark-cli 登录身份重试` 属正常，不用手动改配置。

如果仍失败，按顺序查：

1. `lark-cli doctor` —— 看 `user_identity` 是否 ready；不是就 `lark-cli auth login`。
2. 确认登录的飞书账号本身能打开这张多维表格。
3. 不想用 `lark-cli` 的话，去表格「分享」里把自建应用加为协作者，
   或设 `feishu.auto_cli_fallback: false` 走纯 OpenAPI。

注意：`lark-cli api` 直连 `/open-apis/bitable/.../records/search` 常因缺
`base:record:retrieve` scope 报 `99991679`，所以技能用的是 `base +field-list` /
`+record-list` / `+record-upsert` 这些 typed 命令，别自己改成 raw api。

### `[x] 获取 tenant_access_token 失败：app secret is invalid`
App ID / App Secret 填错了。注意 App Secret 不含 `cli_` 前缀，别把两个值粘串了。

### `飞书接口 ... 失败：permission denied (code=91402)`
权限没开通，或**开了但没发布版本**。去 open.feishu.cn → 你的应用 → 权限管理勾上
`bitable:app`、`drive:media` → 创建版本 → 申请发布。不发布不生效，这是最高频的坑。

### `code=1254304 无权限`
应用没有被加为表格协作者。打开多维表格 → 右上角「分享」→ 搜索你的应用名 → 加为可编辑成员。

### `code=1254005 字段不存在`
`fields.*` 配置的字段名与表格实际列名不一致（多一个空格都不行）。
跑 `python scripts/xhs_publish.py setup --url '<链接>'` 重新识别，或直接在表格里复制列名。

### `飞书接口 .../records/search 失败：InvalidSort (code=1254016)`
飞书 search 接口**不支持按 formula（公式）字段排序**。本技能改成本地排序：
拉一批记录 → 在 Python 端按 `filter.sort_field_name` 的值降序排，再过滤、取第一条。
如果你的 `sort_field_name` 对应的字段恰好是 formula，把配置改成一个可在 API 排序的字段
（如 created_time、modified_time 或一个普通数字字段），或者把 scan_size 调大到能覆盖整个高潜力池。

### 取到的不是我想要的那条
- 确认 `feishu.view_id` 填了。不填就用表的默认顺序，通常跟你在界面上看到的不一样
- 想忽略视图默认顺序、按指定字段拿头条：用 `filter.sort_field_name` + `filter.sort_order`
- 想只看某类状态的记录：用 `filter.required_values: ["高潜力"]`
- 不想改视图也能精确取数：上面这两条就够了，视图只是参考

### `视图里没有可发布的记录了`
符合要求的行都被标记过了。去表格里补新选题，或把 `filter.exclude_values` 放宽。

---

## 二、配图

### `该记录的配图字段里没有附件`
`fields.images` 指向的字段不是**附件类型**（比如是文本或多选）。
在飞书里把该列改成附件类型并重新上传图片。

### `附件下载失败：HTTP 4xx`
附件下载走的是 `drive:media` 权限，确认已开通并发布。
另外 Base 附件必须用 `medias/{file_token}/download` 这个接口，用其他下载入口会失败。

### `图片 xxx 超过 32MB`
小红书单图上限。把原图压缩后再传，或在飞书里存压缩版。

### `配图 N 张，超过上限 18 张`
小红书图文笔记最多 18 张，删掉多余的。

### `不支持的图片格式`
只支持 jpg / png / webp / gif / bmp。HEIC、TIFF 之类先转格式。

---

## 三、浏览器环节

### `未安装 Playwright`
```bash
pip install playwright
playwright install chromium
```

### `找不到图片上传入口 / 找不到标题输入框`
小红书改版了。解法：

1. 浏览器打开发布页，F12 打开开发者工具
2. 用左上角元素选择器点一下目标元素
3. 右键 → Copy → Copy selector
4. 填进 `config/config.yaml` 的 `selectors` 对应项

可以填多个候选，逗号分隔，技能会依次尝试。

### 每次都要扫码
`paths.browser_profile` 指向的目录被清理了，或用了无痕模式。
确认该目录存在且有内容；别把它放在会被清理的临时目录里。

### `等待登录超时 ... 始终没检测到发布编辑器`（v1.5.0 起已大幅减少）

旧版靠「页面上有没有登录元素」判断，登录后若 URL 或弹窗没按预期变化会一直空等到超时，
**整篇内容一次都没填**。v1.5.0 改为检测发布编辑器（上传入口 / 标题框 / 正文框）是否出现，
识别成功即主动回到发布页，等待期间也不刷新页面打断扫码。

若仍报这个错：

1. 确认是在**脚本弹出的那个浏览器窗口**里扫码（不是自己平时的 Chrome）。
2. 看 `screenshots/error_login.png` 判断卡在哪一步。
3. 登录态通常已写进 profile，直接重跑一次即可，多数情况下不用再扫码。
4. 需要更久就调 `browser.login_wait_seconds`（默认 300 秒）。

### `内容没有完整填进小红书发布页` / `标题始终没写进去` / `正文始终没写进去`

v1.5.0 起标题和正文写入后都会**回读校验**，不符自动换输入方式重试最多 3 次，
最后还有一次整体验证；仍不通过就报错、截图并停在发布页。

排查顺序：

1. 看 `screenshots/error_prefill.png` / `error_title.png` / `error_body.png`，确认页面停在哪一步。
2. 多半是 `selectors.title` / `selectors.body` 指向了错误元素，按上一条的方法 F12 重新定位。
3. 正文只填了一部分时，检查是不是正文里的话题标签被编辑器转成了特殊节点（阈值是 70%，
   留了余量）；确认无误可先在浏览器手动补齐再发布。
4. **报错时不要直接点「发布」** —— 脚本停在发布页就是为了让你看到半空的编辑框。

### 浏览器一闪就关了
`browser.headless` 设成了 `true`。assist 模式必须 `false`（要你看见并点发布）。

### `等待发布超时`
默认等 15 分钟。在 `browser.wait_publish_seconds` 里调大。
超时不影响内容，图文仍在 `draft/` 目录，手动发即可。

---

## 四、回写

### `飞书字段「筛选状态」是单选字段，传入值「已发布」不在现有选项里：['备选', '淘汰', '高潜力']；请到飞书表格里手动加一个新选项，名字就叫「已发布」`
**这是预期的护栏错误**，比"含糊的飞书 1254045"友好。指明 `writeback.on_prefilled` / `writeback.on_published`
的值在该单选字段里不存在。

**修法（30 秒）**：去飞书表格 → 选中「筛选状态」列头 → 编辑字段 → 选项管理 → 加一个新选项，
名字就叫 `on_prefilled` / `on_published` 配置的值。不需要重启、不需要重跑 setup。

**别等到发布完才发现**：`python scripts/xhs_publish.py check` 会连飞书读出该字段的真实选项，
直接列出缺哪几个，改完再跑一次即可确认。

如果选项已有，写代码退出后仍报这个错，先去飞书看选项名有没有拼写差异（首尾空格、大小写）。

### 第二天又取到同一条
- `fields.status` 没填 → 技能无从回写
- `writeback.enabled` 是 `false`
- `filter.enabled` 是 `false`，导致跳过逻辑没启用

三者都要开，才形成「取第一条 → 发 → 标记 → 下次跳过」的闭环。

---

## 五、看日志和截图

- 截图：`工作目录/screenshots/`，按 `时间_标签.png` 命名，
  标签有 `filled`（填完）、`published`（发布成功）、`error_*`（各环节失败）
- 草稿包：`工作目录/draft/note.md` 与 `note.json`，任何时候都能拿去手动发
- 加 `--quiet` 减少输出；去掉它可以看到飞书取数的通道与细节
