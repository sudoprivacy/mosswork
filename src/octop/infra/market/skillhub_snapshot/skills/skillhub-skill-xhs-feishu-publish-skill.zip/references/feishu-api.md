# 飞书接口细节

技能默认走 OpenAPI 直连；`feishu.prefer_cli: true` 且本机装了 `lark-cli` 时优先走 CLI，失败自动回退。

## 1. 鉴权

```
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal
{"app_id": "cli_xxx", "app_secret": "xxx"}
→ {"code":0, "tenant_access_token": "t-xxx", "expire": 7200}
```

token 缓存在内存，过期前 60 秒自动续期。遇到 `99991663 / 99991661 / 99991664`（token 失效类）自动重试一次。

请求头：`Authorization: Bearer <token>`

## 2. 字段列表

```
GET /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/fields?page_size=200
→ data.items[] = {field_id, field_name, type, ui_type}
```

常见 `type`：1 文本、2 数字、3 单选、4 多选、5 日期、7 复选框、11 人员、13 电话、15 链接、17 附件、18 关联、20 公式、21 双向关联、22 地理位置、23 群聊。

## 3. 按视图取记录（决定「排序第一条」）

```
POST /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/search?view_id={view_id}&page_size=1
{"automatic_fields": false}
→ data.items[] = {record_id, fields}
```

**关键点**：`view_id` 是 query 参数。传了它，返回结果就带上该视图的筛选与排序，
返回数组的第一条即界面上排在最前面的那条。这正是「排序第一条」的实现方式。

不传 `view_id` 时用表默认顺序，通常不等于你在界面上看到的顺序——所以 `view_id` 建议一定要填。

CLI 等价命令（用于 prefer_cli 通道）：

```bash
lark-cli base +record-list \
  --base-token <app_token> \
  --table-id <table_id> \
  --view-id <view_id> \
  --page-size 1 \
  --as user
```

部分版本的 CLI 不认 `--view-id`，技能探测到命令失败会自动去掉该参数重试，并打印告警。

## 4. 附件下载

OpenAPI：

```
GET /open-apis/drive/v1/medias/{file_token}/download
```

返回二进制流。**注意**：出错时也返回 HTTP 200，只是 content-type 是 `application/json`，
技能据此判别失败，避免把错误 JSON 存成图片。

`file_token` 从附件字段值里拿，形如 `box_xxx`：

```json
{"图片": [{"file_token": "box_abc", "name": "封面.png", "size": 102400}]}
```

CLI 等价命令：

```bash
lark-cli base +record-download-attachment \
  --base-token <app_token> --table-id <table_id> \
  --record-id <record_id> --file-token <file_token> \
  --output <dir> --as user
```

CLI 按原文件名落盘，技能下载前后对比目录差集找到新文件，再重命名为 `01_xxx.png` 这类有序编号，
保证上传顺序与表格里的附件顺序一致。

## 5. 回写状态

```
PUT /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/{record_id}
{"fields": {"状态": "已发布", "发布时间": 1756700000000}}
```

日期字段用**毫秒时间戳**（整数）。单选字段用选项字符串，选项不存在会报错——
所以 `writeback.on_prefilled` / `on_published` 的值必须先在表格的单选选项里建好。

## 6. 常见错误码

| code | 含义 | 处理 |
|---|---|---|
| 0 | 成功 | — |
| 99991663 / 99991661 / 99991664 | token 失效 | 自动重试一次 |
| 1254005 | 字段不存在 | 字段名与表格不一致，跑 `setup` 重新识别 |
| 1254006 | 记录不存在 | record_id 过期，重新取数 |
| 1254304 | 无权限 / 不是协作者 | 把应用加为表格协作者 |
| 1254045 | 调用频率超限 | 稍后重试 |
| 91402 | 权限未开通或未发布 | 后台开通 `bitable:app`、`drive:media` 后**发布应用版本** |

> 最容易踩的坑：权限在后台勾了但没发布版本，接口照样 91402。
