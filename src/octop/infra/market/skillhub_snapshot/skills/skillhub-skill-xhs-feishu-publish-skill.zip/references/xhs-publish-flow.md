# 小红书创作者中心发布流程

## 目标页面

图文笔记发布页：

```
https://creator.xiaohongshu.com/publish/publish?target=image
```

`target=image` 是图文，`target=video` 是视频。本技能只做图文。

未登录时会自动跳到登录页（URL 含 `login`），技能检测到就提示扫码，最多等 300 秒。

## 自动化策略：为什么用持久化 profile

用 Playwright 的 `launch_persistent_context` 指定一个固定 `user_data_dir`：

- 扫码一次，之后长期复用，不必每次登录
- 用的是真实 Chrome 内核的profile，风控特征比临时 context 正常得多
- 加 `--disable-blink-features=AutomationControlled` 去掉最明显的自动化指纹

配置里的 `paths.browser_profile` 就是它，默认 `.xhs_browser_profile`。

## 填表顺序（顺序不能乱）

1. **上传图片**——必须最先做。图片没上传完就填文字，页面会重排导致文字丢失
2. **等缩略图出现**——轮询 `selectors.uploaded_thumb` 的数量达到预期，最多 120 秒
3. **填标题**
4. **填正文**
5. **填话题**（可选，失败只告警不中断）

## 选择器

小红书前端改版频繁，所有选择器都集中在 `config/config.yaml` 的 `selectors` 段，
**每项可填多个候选，用英文逗号分隔，按序尝试第一个可见的元素**。改版时改配置即可，不用动代码。

默认候选（2026-09 实测可用）：

| 元素 | 默认候选 |
|---|---|
| 上传入口 | `input[type="file"]` |
| 缩略图 | `.img-preview-item` |
| 标题 | `#post-title` |
| 正文 | `#post-textarea` |
| 话题 | `#post-topics` |
| 发布按钮 | `button:has-text("发布")` |

**改版后如何重新定位**：在浏览器里打开发布页 → F12 → 用元素选择器点目标 → 右键 Copy selector。
优先选带 `id` 的，其次带稳定 class 的，最后才用 `:has-text()`。

## 正文填写的坑

正文区是 `contenteditable` 的 div，`fill()` 有时不生效。技能的处理是：

1. 先 `click()` 聚焦
2. 尝试 `fill(text)`
3. 失败则 `keyboard.insert_text(text)`
4. 回填后读一次 `inner_text()`，发现写入量不足预期的 50% 就报错并截图

最后这步校验很重要——否则会出现「脚本说填好了，其实一个字没进去」。

## 等待真人发布的判定（assist 模式）

脚本停在这里轮询（每 2 秒一次，默认最长 15 分钟）：

- URL 变化且含 `success` / `result`
- 或页面文本出现「发布成功」

判定为已发布 → 回写飞书 `on_published`。

用户直接关掉浏览器窗口 → 捕获异常（Playwright 会抛错）→ 视为取消，回写 `on_prefilled`。
超时未发布 → 同样按未发布处理，图文仍保留在 `draft/` 目录。

## 关于 auto 模式

`auto` 模式会代点「发布」按钮。这与小红书 2026-07「薯管家」治理公告中
「利用技术手段模拟真人进行非真实内容创作」的条款冲突，属于明确红线，已处置违规账号 42 万个。

技能仍保留该模式，但：

- 默认关闭
- 运行时必须手动输入「我承担风险」四个字才会执行
- `--yes` 可跳过确认，仅供已充分知情的用户在无人值守场景下使用

**建议永远用 assist。** 它已经省掉了取数、下载图、上传、打字这些占 95% 时间的活，
只留最后一下点击给人，换来的是账号安全。
