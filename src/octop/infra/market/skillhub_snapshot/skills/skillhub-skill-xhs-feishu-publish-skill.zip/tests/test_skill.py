#!/usr/bin/env python3
"""技能自检 + 黄金用例。

跑法：  python tests/test_skill.py
不需要飞书凭证、不需要网络、不需要浏览器，全部用桩数据。
"""

from __future__ import annotations

import re
import sys
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = SKILL_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

REQUIRED_FILES = [
    "SKILL.md",
    "README.md",
    "config/config.example.yaml",
    "scripts/xhs_publish.py",
    "scripts/feishu_source.py",
    "scripts/image_store.py",
    "scripts/xhs_browser.py",
    "scripts/setup_wizard.py",
    "references/feishu-api.md",
    "references/xhs-publish-flow.md",
    "references/troubleshooting.md",
    "tests/test_skill.py",
]

BANNED_PATTERNS = [
    (r"\bTODO\b", "TODO 占位"),
    (r"\bFIXME\b", "FIXME 占位"),
    (r"if False", "永假分支"),
    (r"NotImplementedError", "未实现"),
    (r"your[-_]?api[-_]?key", "密钥占位"),
    (r"<your[- ]", "尖括号占位"),
]


class TestStructure(unittest.TestCase):
    def test_required_files_exist(self):
        missing = [f for f in REQUIRED_FILES if not (SKILL_ROOT / f).exists()]
        self.assertEqual(missing, [], f"缺少文件：{missing}")

    def test_skill_name_matches_dir(self):
        text = (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8")
        name = re.search(r"^name:\s*(\S+)", text, re.M)
        self.assertIsNotNone(name, "SKILL.md 缺少 name 字段")
        dir_name = SKILL_ROOT.name
        # SkillHub 安装副本会在目录名后追加 __skillhub 后缀，不算命名不一致
        if dir_name.endswith("__skillhub"):
            dir_name = dir_name[: -len("__skillhub")]
        self.assertEqual(name.group(1), dir_name, "技能名必须与父目录同名")
        self.assertTrue(name.group(1).endswith("-skill"), "技能名必须以 -skill 结尾")

    def test_description_length(self):
        import yaml

        text = (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8")
        front = text.split("---")[1]
        meta = yaml.safe_load(front)
        desc = str(meta.get("description", ""))
        self.assertTrue(desc, "description 不能为空")
        self.assertLessEqual(len(desc), 1024, f"description 超过 1024 字符（当前 {len(desc)}）")
        for kw in ("小红书", "飞书", "多维表格", "发布"):
            self.assertIn(kw, desc, f"description 缺少触发关键词「{kw}」")

    def test_no_placeholders_in_code(self):
        for py in SCRIPTS.rglob("*.py"):
            text = py.read_text(encoding="utf-8")
            for pattern, label in BANNED_PATTERNS:
                self.assertIsNone(
                    re.search(pattern, text),
                    f"{py.name} 含{label}：{pattern}",
                )

    def test_all_scripts_compile(self):
        import py_compile

        for py in SCRIPTS.rglob("*.py"):
            with self.subTest(script=py.name):
                py_compile.compile(str(py), doraise=True)

    def test_readme_documents_commands(self):
        text = (SKILL_ROOT / "README.md").read_text(encoding="utf-8")
        for cmd in ("setup", "check", "fetch", "prepare", "publish"):
            self.assertIn(cmd, text, f"README 未说明 {cmd} 命令")


class TestHelpers(unittest.TestCase):
    def test_extract_text_plain_and_rich(self):
        from feishu_source import extract_text

        self.assertEqual(extract_text("标题A"), "标题A")
        self.assertEqual(extract_text([{"type": "text", "text": "你好"}, {"type": "text", "text": "世界"}]), "你好世界")
        self.assertEqual(extract_text(None), "")

    def test_extract_attachments(self):
        from feishu_source import extract_attachments

        value = [{"file_token": "box_abc", "name": "a.png", "size": 1024}, {"file_token": "box_def", "name": "b.jpg"}]
        atts = extract_attachments(value)
        self.assertEqual([a["file_token"] for a in atts], ["box_abc", "box_def"])
        self.assertEqual(extract_attachments([]), [])
        self.assertEqual(extract_attachments("不是附件"), [])

    def test_parse_bitable_url(self):
        from setup_wizard import parse_bitable_url

        url = "https://example.feishu.cn/base/bascnAbc123?table=tblXyz789&view=vewUio456"
        got = parse_bitable_url(url)
        self.assertEqual(got["app_token"], "bascnAbc123")
        self.assertEqual(got["table_id"], "tblXyz789")
        self.assertEqual(got["view_id"], "vewUio456")

    def test_parse_bitable_url_rejects_wiki(self):
        from setup_wizard import parse_bitable_url

        with self.assertRaises(ValueError) as ctx:
            parse_bitable_url("https://example.feishu.cn/wiki/Wkxx123")
        self.assertIn("wiki", str(ctx.exception))

    def test_parse_url_without_table_param(self):
        """分享链接常常不带 table=/view=，此时后两项应为空串而非报错。"""
        from setup_wizard import parse_bitable_url

        got = parse_bitable_url("https://my.feishu.cn/base/bascnDemoAppTokenXyz123?from=from_copylink")
        self.assertEqual(got["app_token"], "bascnDemoAppTokenXyz123")
        self.assertEqual(got["table_id"], "")
        self.assertEqual(got["view_id"], "")

    def test_pick_table_single_auto_selects(self):
        from feishu_source import FeishuBitable
        from setup_wizard import pick_table

        source = FeishuBitable.__new__(FeishuBitable)
        source.list_tables = lambda: [{"table_id": "tblOnly", "name": "选题库"}]  # type: ignore[method-assign]
        self.assertEqual(pick_table(source), "tblOnly")

    def test_pick_table_multiple_chooses_by_index(self):
        import builtins
        from io import StringIO

        from feishu_source import FeishuBitable
        from setup_wizard import pick_table

        source = FeishuBitable.__new__(FeishuBitable)
        source.list_tables = lambda: [  # type: ignore[method-assign]
            {"table_id": "tblA", "name": "表A"},
            {"table_id": "tblB", "name": "表B"},
        ]
        real_input = builtins.input
        real_stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            builtins.input = lambda *_: "2"
            self.assertEqual(pick_table(source), "tblB")
        finally:
            sys.stdout = real_stdout
            builtins.input = real_input

    def test_pick_view_empty_returns_blank(self):
        from feishu_source import FeishuBitable
        from setup_wizard import pick_view

        source = FeishuBitable.__new__(FeishuBitable)
        source.list_views = lambda: []  # type: ignore[method-assign]
        self.assertEqual(pick_view(source), "")

    def test_detect_roles(self):
        from setup_wizard import detect_roles

        fields = [
            {"field_name": "笔记标题", "type": 1},
            {"field_name": "正文内容", "type": 1},
            {"field_name": "配图", "type": 17},
            {"field_name": "话题标签", "type": 1},
            {"field_name": "发布状态", "type": 3},
        ]
        roles = detect_roles(fields)
        self.assertEqual(roles["title"], "笔记标题")
        self.assertEqual(roles["body"], "正文内容")
        self.assertEqual(roles["images"], "配图")
        self.assertEqual(roles["topics"], "话题标签")
        self.assertEqual(roles["status"], "发布状态")

    def test_render_config_keeps_comments(self):
        from setup_wizard import render_config

        example = SKILL_ROOT / "config" / "config.example.yaml"
        out = render_config(example, {("feishu", "app_token"): "bascnTEST", ("fields", "title"): "标题"})
        self.assertIn("bascnTEST", out)
        self.assertIn("# 飞书多维表格", out, "渲染后注释丢了")
        self.assertNotIn('app_token: ""', out)

    def test_normalize_topics(self):
        from image_store import normalize_topics

        self.assertEqual(normalize_topics("#A #B"), ["A", "B"])
        self.assertEqual(normalize_topics("A，B、C"), ["A", "B", "C"])
        self.assertEqual(normalize_topics(""), [])


class TestCredentialFormat(unittest.TestCase):
    """凭证复制被截断是最常见的失败原因（飞书只回一个 10003），必须提前拦住。"""

    def test_truncated_app_id_is_flagged(self):
        from xhs_publish import credential_problems

        cfg = {"feishu": {"app_id": "cli_a8fd7faa2efb9", "app_secret": "mXq9os36Z0elnE1HqXHHRcfmWLcIY2hf"}}
        issues = credential_problems(cfg)
        self.assertTrue(any("app_id" in i for i in issues), "13 位的 app_id 应被判定为可疑")

    def test_valid_app_id_passes(self):
        from xhs_publish import credential_problems

        cfg = {"feishu": {"app_id": "cli_a5ca35a685b0x26e", "app_secret": "mXq9os36Z0elnE1HqXHHRcfmWLcIY2hf"}}
        self.assertEqual(credential_problems(cfg), [])

    def test_short_secret_is_flagged(self):
        from xhs_publish import credential_problems

        cfg = {"feishu": {"app_id": "cli_a5ca35a685b0x26e", "app_secret": "short"}}
        issues = credential_problems(cfg)
        self.assertTrue(any("app_secret" in i for i in issues), "过短的 secret 应被判定为可疑")

    def test_empty_values_not_flagged_as_format(self):
        """留空由「未填写」那条规则管，不该再报一次格式问题，避免重复提示。"""
        from xhs_publish import credential_problems

        self.assertEqual(credential_problems({"feishu": {"app_id": "", "app_secret": ""}}), [])

    def test_10003_error_gives_actionable_hint(self):
        from feishu_source import _token_error_hint

        hint = _token_error_hint(10003, "invalid param")
        self.assertIn("16 位", hint)
        self.assertIn("复制", hint)


class TestGoldenCases(unittest.TestCase):
    """三个黄金用例：一条能发、一条标题超长、一条没图。"""

    def setUp(self):
        from image_store import NotePackage

        self.tmp = SKILL_ROOT / "tests" / ".tmp_golden"
        self.tmp.mkdir(parents=True, exist_ok=True)
        self.img1 = self.tmp / "1.png"
        self.img2 = self.tmp / "2.png"
        self.img1.write_bytes(b"\x89PNG\r\n\x1a\n" + b"0" * 512)
        self.img2.write_bytes(b"\x89PNG\r\n\x1a\n" + b"1" * 512)
        self.limits = {"title_max": 20, "body_max": 1000, "image_max": 18, "image_size_mb": 32, "topic_max": 10}
        self.pkg = NotePackage(
            record_id="rec_golden_1",
            title="服务人如何写好质检标准",
            body="质检标准要写清楚，先定维度再定分值。\n第二条注意事项。",
            topics=["服务管理", "质检"],
            image_paths=[self.img1, self.img2],
        )
        self.pkg_type = NotePackage

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_golden_1_valid_note_passes(self):
        from image_store import validate_images, validate_text, write_draft

        validate_text(self.pkg, self.limits)
        kept = validate_images(self.pkg.image_paths, self.limits)
        self.assertEqual(len(kept), 2)
        draft = write_draft(self.pkg, self.tmp / "draft")
        self.assertTrue(draft.exists())
        self.assertIn("服务人如何写好质检标准", draft.read_text(encoding="utf-8"))

    def test_golden_2_overlong_title_rejected(self):
        from image_store import PackageError, validate_text

        self.pkg.title = "超长标题" * 10  # 40 字
        with self.assertRaises(PackageError) as ctx:
            validate_text(self.pkg, self.limits)
        self.assertIn("标题", str(ctx.exception))

    def test_golden_3_missing_image_rejected(self):
        from image_store import PackageError, validate_images

        with self.assertRaises(PackageError) as ctx:
            validate_images([], self.limits)
        self.assertIn("至少", str(ctx.exception))

    def test_duplicate_images_deduped(self):
        from image_store import validate_images

        same = self.tmp / "1_copy.png"
        same.write_bytes(self.img1.read_bytes())
        kept = validate_images([self.img1, self.img2, same], self.limits)
        self.assertEqual(len(kept), 2, "重复图片没有被去重")


class TestSkipPublished(unittest.TestCase):
    """开了状态过滤时，第一条「已发布」应被跳过，取到第二条。"""

    def test_skip_published_rows(self):
        from feishu_source import FeishuBitable

        source = FeishuBitable.__new__(FeishuBitable)
        records = [
            {"record_id": "rec1", "fields": {"状态": "已发布"}},
            {"record_id": "rec2", "fields": {"状态": ""}},
        ]

        def fake_fetch(page_size, sort_spec=None):
            return records

        source._fetch_records = fake_fetch  # type: ignore[attr-defined]
        source.require_coordinates = lambda: None  # type: ignore[method-assign]
        got = source.fetch_first_record(page_size=10, skip_field="状态", exclude_values=["已发布"])
        self.assertEqual(got["record_id"], "rec2")

    def test_all_published_returns_none(self):
        from feishu_source import FeishuBitable

        source = FeishuBitable.__new__(FeishuBitable)
        source._fetch_records = lambda page_size, sort_spec=None: [{"record_id": "rec1", "fields": {"状态": "已发布"}}]  # type: ignore[attr-defined]
        source.require_coordinates = lambda: None  # type: ignore[method-assign]
        self.assertIsNone(
            source.fetch_first_record(page_size=10, skip_field="状态", exclude_values=["已发布"])
        )


class TestLocalSort(unittest.TestCase):
    """飞书 search API 不支持按 formula 排序，脚本做本地排序。"""

    def _run(self, records):
        from feishu_source import FeishuBitable

        source = FeishuBitable.__new__(FeishuBitable)
        source._fetch_records = lambda page_size, sort_spec=None: records  # type: ignore[attr-defined]
        source.require_coordinates = lambda: None  # type: ignore[method-assign]
        source._validate_sort_field = lambda name: None  # type: ignore[method-assign]
        return source.fetch_first_record(
            page_size=10,
            include_field="筛选状态",
            required_values=("高潜力",),
            sort_field_name="综合得分",
            sort_order="desc",
        )

    def test_picks_highest_formula_value(self):
        records = [
            {"record_id": "a", "fields": {"筛选状态": "高潜力", "综合得分": {"type": 2, "value": [6.0]}}},
            {"record_id": "b", "fields": {"筛选状态": "高潜力", "综合得分": {"type": 2, "value": [9.0]}}},
            {"record_id": "c", "fields": {"筛选状态": "高潜力", "综合得分": {"type": 2, "value": [7.5]}}},
        ]
        got = self._run(records)
        self.assertEqual(got["record_id"], "b")

    def test_skips_wrong_status_before_sorting(self):
        records = [
            {"record_id": "x", "fields": {"筛选状态": "已发布", "综合得分": {"type": 2, "value": [99.0]}}},
            {"record_id": "y", "fields": {"筛选状态": "高潜力", "综合得分": {"type": 2, "value": [3.0]}}},
        ]
        got = self._run(records)
        self.assertEqual(got["record_id"], "y")


class TestSelectOptions(unittest.TestCase):
    """单选选项读取。list_fields 曾丢掉 property，导致回写护栏恒判「选项不存在」。"""

    FIELDS = [
        {"field_id": "fldA", "field_name": "筛选状态", "type": 3,
         "property": {"options": [{"name": "高潜力"}, {"name": "备选"}, {"name": "淘汰"}]}},
        {"field_id": "fldB", "field_name": "标题", "type": 1, "property": {}},
    ]

    def _source(self):
        from feishu_source import FeishuBitable

        source = FeishuBitable.__new__(FeishuBitable)
        source.list_fields = lambda: self.FIELDS  # type: ignore[method-assign]
        return source

    def test_reads_options(self):
        self.assertEqual(
            self._source().select_options("筛选状态"), ["高潜力", "备选", "淘汰"]
        )

    def test_non_select_returns_none(self):
        self.assertIsNone(self._source().select_options("标题"))

    def test_missing_field_returns_none(self):
        self.assertIsNone(self._source().select_options("不存在的列"))

    def test_guard_passes_when_option_exists(self):
        source = self._source()
        source._guard_select_options({"筛选状态": "高潜力"})  # 不应抛错

    def test_guard_rejects_unknown_option(self):
        from feishu_source import FeishuError

        with self.assertRaises(FeishuError) as ctx:
            self._source()._guard_select_options({"筛选状态": "待发布"})
        self.assertIn("待发布", str(ctx.exception))
        self.assertIn("高潜力", str(ctx.exception))  # 报错里要带上现有选项，方便照着加


class TestCliCompatV150(unittest.TestCase):
    """v1.5.0：新版 lark-cli 输出结构兼容 + OpenAPI 403 自动回退 + 预填回读自检。"""

    def test_new_cli_fields_normalized(self):
        from feishu_source import normalize_cli_fields

        items = [
            {"id": "fld1", "name": "标题", "type": "text", "options": None},
            {"id": "fld2", "name": "发布状态", "type": "select",
             "options": [{"name": "已发布"}, {"name": "待发布"}]},
            {"id": "fld3", "name": "图片", "type": "attachment", "options": None},
        ]
        out = normalize_cli_fields(items)
        self.assertEqual([x["field_name"] for x in out], ["标题", "发布状态", "图片"])
        self.assertEqual(out[1]["type"], 3)  # select -> 3，select_options 才认得
        self.assertEqual(
            [o["name"] for o in out[1]["property"]["options"]],
            ["已发布", "待发布"],
        )
        self.assertEqual(out[2]["type"], 17)  # attachment

    def test_old_cli_fields_unchanged(self):
        from feishu_source import normalize_cli_fields

        items = [{"field_id": "f1", "field_name": "标题", "type": 1,
                  "ui_type": "Text", "property": {}}]
        out = normalize_cli_fields(items)
        self.assertEqual(out[0]["field_id"], "f1")
        self.assertEqual(out[0]["type"], 1)

    def test_new_cli_records_matrix(self):
        from feishu_source import normalize_cli_records

        data = {
            "fields": ["标题", "正文", "图片"],
            "data": [
                ["香蕉横测", "正文内容", [{"file_token": "tok1", "name": "a.jpg", "size": 100}]],
                ["橘子横测", "正文2", None],
            ],
            "record_id_list": ["rec1", "rec2"],
            "has_more": True,
        }
        page, more = normalize_cli_records(data)
        self.assertTrue(more)
        self.assertEqual(len(page), 2)
        self.assertEqual(page[0]["record_id"], "rec1")
        self.assertEqual(page[0]["fields"]["标题"], "香蕉横测")
        self.assertEqual(page[0]["fields"]["图片"][0]["file_token"], "tok1")

    def test_old_cli_records_items(self):
        from feishu_source import normalize_cli_records

        data = {"items": [{"record_id": "rec9", "fields": {"标题": "旧版"}}],
                "has_more": False}
        page, more = normalize_cli_records(data)
        self.assertFalse(more)
        self.assertEqual(page[0]["fields"]["标题"], "旧版")

    def test_openapi_403_falls_back_to_cli(self):
        """91403 / 缺凭证时自动切 lark-cli，且只重试一次。"""
        import feishu_source as fs

        src = fs.FeishuBitable({
            "feishu": {
                "app_id": "cli_aaaaaaaaaaaaaaaa", "app_secret": "s" * 32,
                "app_token": "basX", "table_id": "tblX",
                "auto_cli_fallback": True,
            }
        }, verbose=False)
        src._cli_path = "lark-cli"  # 模拟本机已安装并登录
        calls = []

        def api_fn():
            calls.append("api")
            raise fs.FeishuPermissionFallback("Forbidden (code=91403)")

        def cli_fn():
            calls.append("cli")
            return ["ok"]

        self.assertEqual(src._via(cli_fn, api_fn), ["ok"])
        self.assertEqual(calls, ["api", "cli"])
        self.assertTrue(src._fallback_to_cli)
        # 后续动作应直接走 CLI，不再回头撞 403
        calls.clear()
        self.assertEqual(src._via(cli_fn, api_fn), ["ok"])
        self.assertEqual(calls, ["cli"])

    def test_missing_credentials_falls_back(self):
        import feishu_source as fs

        src = fs.FeishuBitable({"feishu": {
            "app_id": "", "app_secret": "", "app_token": "basX", "table_id": "tblX",
        }}, verbose=False)
        src._cli_path = "lark-cli"
        with self.assertRaises(fs.FeishuPermissionFallback):
            src._token_value()
        self.assertTrue(src._fallback_to_cli)

    def test_prefill_readback_check(self):
        from xhs_browser import XhsPublisher

        ok = XhsPublisher._text_ok
        title = "三种香蕉横测差距超大！"
        self.assertTrue(ok(title, title, 1.0))
        self.assertFalse(ok("三种香蕉", title, 1.0))  # 标题截断必须判失败
        body = "之前在超市、水果店、助农产地店各买了一串香蕉回来测，吃完差距真的惊到我！" * 4
        self.assertTrue(ok(body, body, 0.7))
        self.assertFalse(ok(body[:10], body, 0.7))  # 正文只填了个开头
        self.assertTrue(ok("", "", 1.0))  # 空内容不算问题


class TestBrowserLoginV150(unittest.TestCase):
    """登录检测不再靠「有没有登录元素」，而已登录/跳转首页都要能立刻放行。"""

    CREATOR = "https://creator.xiaohongshu.com/publish/publish?target=image"

    def _make(self, url: str, ready: bool, login_form: bool):
        from xhs_browser import XhsPublisher

        pub = XhsPublisher({
            "browser": {"creator_url": self.CREATOR, "login_wait_seconds": 2},
            "selectors": {}, "paths": {},
        }, Path("."), verbose=False)
        pub.page = type("Page", (), {"url": url})()
        pub._editor_ready = lambda: ready
        pub._login_form_visible = lambda: login_form
        pub._screenshot = lambda tag: None
        return pub

    def test_logged_in_returns_immediately(self):
        self._make(self.CREATOR, True, False).ensure_login()

    def test_redirected_to_home_is_sent_back(self):
        """登录后停在首页的死锁场景：必须主动回发布页。"""
        pub = self._make("https://creator.xiaohongshu.com/", True, False)
        calls = []
        pub.page.goto = lambda url, wait_until=None: calls.append(url)
        pub.ensure_login()
        self.assertEqual(calls, [self.CREATOR])

    def test_login_form_still_blocks(self):
        from xhs_browser import BrowserError

        pub = self._make(self.CREATOR, True, True)
        with self.assertRaises(BrowserError):
            pub.ensure_login()


class TestCliWritebackV150(unittest.TestCase):
    """CLI 回写时，单选字段必须转成数组，否则飞书会拒。"""

    def test_select_value_wrapped_as_array(self):
        import json
        import feishu_source as fs

        src = fs.FeishuBitable({"feishu": {
            "app_id": "", "app_secret": "", "app_token": "basX", "table_id": "tblX",
        }}, verbose=False)
        src._cli_path = "lark-cli"
        src._fallback_to_cli = True
        src.list_fields = lambda: [
            {"field_id": "f1", "field_name": "发布状态", "type": 3,
             "ui_type": "select", "property": {}},
            {"field_id": "f2", "field_name": "备注", "type": 1,
             "ui_type": "Text", "property": {}},
        ]
        captured = {}

        def fake_run(args):
            captured["args"] = args
            return {}

        src._run_cli_json = fake_run
        src._update_record_cli("rec1", {"发布状态": "已发布", "备注": "备注文本"})
        payload = json.loads(captured["args"][captured["args"].index("--json") + 1])
        self.assertEqual(payload["发布状态"], ["已发布"])
        self.assertEqual(payload["备注"], "备注文本")
        self.assertIn("+record-upsert", captured["args"])


if __name__ == "__main__":
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    try:
        import test_pipeline  # 核心管线端到端用例，一并跑

        suite.addTests(loader.loadTestsFromModule(test_pipeline))
    except ImportError as exc:
        print(f"[warn] 跳过管线测试：{exc}")
    unittest.TextTestRunner(verbosity=2).run(suite)
