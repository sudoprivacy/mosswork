#!/usr/bin/env python3
"""核心管线端到端测试（mock 飞书，不联网、不需要凭证）。

覆盖 fetch_package 与 write_back 这两条真实执行路径：
取数 → 字段提取 → 附件下载 → 校验 → 草稿包 → 回写
"""

from __future__ import annotations

import shutil
import sys
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from feishu_source import FeishuBitable  # noqa: E402
from image_store import PackageError  # noqa: E402
from xhs_publish import fetch_package, write_back  # noqa: E402

TITLE = "客服主管都在用的质检表"
BODY_PLAIN = "先定维度，再定分值，最后配案例。"


def make_cfg(workdir: Path, **overrides) -> dict:
    cfg = {
        "mode": "assist",
        "feishu": {
            "app_id": "cli_test",
            "app_secret": "secret_test",
            "app_token": "bas_test",
            "table_id": "tbl_test",
            "view_id": "vew_test",
            "prefer_cli": False,
        },
        "fields": {"title": "标题", "body": "正文", "images": "图片", "topics": "话题", "status": "状态"},
        "filter": {"enabled": False, "status_field": "状态", "skip_field": "状态", "exclude_values": ["已发布"]},
        "writeback": {
            "enabled": True,
            "on_prefilled": "待发布",
            "on_published": "已发布",
            "published_at_field": "",
        },
        "limits": {"title_max": 20, "body_max": 1000, "image_max": 18, "image_size_mb": 32, "topic_max": 10},
        "compliance": {"ai_declaration": False, "ai_declaration_text": "（本篇由 AI 辅助创作，经真人审核发布）"},
        "paths": {"workdir": str(workdir), "images_subdir": "images", "browser_profile": ".profile"},
        "browser": {},
        "selectors": {},
    }
    cfg.update(overrides)
    return cfg


def fake_download(self, record_id, attachments, out_dir):
    """假的附件下载：按名字造几个真字节的小 PNG，够验证后续校验逻辑。"""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    saved = []
    for idx, att in enumerate(attachments, 1):
        path = out_dir / f"{idx:02d}_{att['name']}"
        path.write_bytes(b"\x89PNG\r\n\x1a\n" + bytes([idx]) * 256)
        saved.append(path)
    return saved


class PipelineTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = SKILL_ROOT / "tests" / ".tmp_pipeline"
        shutil.rmtree(self.tmp, ignore_errors=True)
        self.tmp.mkdir(parents=True)
        self.real_download = FeishuBitable.download_attachments
        FeishuBitable.download_attachments = fake_download  # type: ignore[method-assign]

    def tearDown(self):
        FeishuBitable.download_attachments = self.real_download  # type: ignore[method-assign]
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _patch_record(self, fields: dict, record_id: str = "rec_1"):
        FeishuBitable.fetch_first_record = lambda self, page_size=1, include_field="", required_values=(), skip_field="", exclude_values=(), sort_field_name="", sort_order="desc", index=0: {  # type: ignore[method-assign]
            "record_id": record_id,
            "fields": fields,
        }


class TestFetchPackage(PipelineTestCase):
    def test_builds_package_from_rich_text_and_attachments(self):
        """正文是富文本数组、配图是附件数组，都要能正确提取。"""
        self._patch_record(
            {
                "标题": TITLE,
                "正文": [{"type": "text", "text": BODY_PLAIN}, {"type": "text", "text": "补充一句。"}],
                "图片": [
                    {"file_token": "box_1", "name": "封面.png", "size": 100},
                    {"file_token": "box_2", "name": "内页.png", "size": 100},
                ],
                "话题": "服务管理, 质检",
                "状态": "",
            }
        )
        pkg, _ = fetch_package(make_cfg(self.tmp), verbose=False)
        self.assertEqual(pkg.title, TITLE)
        self.assertEqual(pkg.body, BODY_PLAIN + "补充一句。")
        self.assertEqual(pkg.topics, ["服务管理", "质检"])
        self.assertEqual(len(pkg.image_paths), 2)
        self.assertEqual(pkg.record_id, "rec_1")

    def test_draft_package_written(self):
        from xhs_publish import workdir_of

        from image_store import write_draft

        self._patch_record(
            {
                "标题": TITLE,
                "正文": BODY_PLAIN,
                "图片": [{"file_token": "box_1", "name": "a.png", "size": 10}],
                "话题": "",
            }
        )
        cfg = make_cfg(self.tmp)
        pkg, _ = fetch_package(cfg, verbose=False)
        draft = write_draft(pkg, workdir_of(cfg) / "draft")
        text = draft.read_text(encoding="utf-8")
        self.assertIn(TITLE, text)
        self.assertIn(BODY_PLAIN, text)
        self.assertIn("a.png", text)

    def test_empty_attachment_rejected(self):
        self._patch_record({"标题": TITLE, "正文": BODY_PLAIN, "图片": [], "话题": ""})
        with self.assertRaises(PackageError) as ctx:
            fetch_package(make_cfg(self.tmp), verbose=False)
        self.assertIn("没有附件", str(ctx.exception))

    def test_ai_declaration_appended_once(self):
        self._patch_record(
            {
                "标题": TITLE,
                "正文": BODY_PLAIN,
                "图片": [{"file_token": "box_1", "name": "a.png", "size": 10}],
                "话题": "",
            }
        )
        cfg = make_cfg(self.tmp)
        cfg["compliance"]["ai_declaration"] = True
        pkg, _ = fetch_package(cfg, verbose=False)
        self.assertIn("（本篇由 AI 辅助创作，经真人审核发布）", pkg.body)
        # 再跑一次不应重复追加
        pkg2, _ = fetch_package(cfg, verbose=False)
        self.assertEqual(pkg2.body.count("AI 辅助创作"), 1)

    def test_filter_skips_published_row(self):
        """开了过滤时，第一条「已发布」应被跳过。"""
        records = [
            {"record_id": "rec_old", "fields": {"标题": "旧的", "正文": "x", "状态": "已发布"}},
            {"record_id": "rec_new", "fields": {"标题": TITLE, "正文": BODY_PLAIN, "状态": "",
                                                "图片": [{"file_token": "box_1", "name": "a.png", "size": 10}],
                                                "话题": ""}},
        ]

        def fake_fetch(self, page_size=1, include_field="", required_values=(),
                       skip_field="", exclude_values=(), sort_field_name="", sort_order="desc", index=0):
            candidates = []
            for rec in records:
                cur_inc = str(rec["fields"].get(include_field, "")).strip() if include_field else ""
                if required_values and cur_inc not in {str(v) for v in required_values}:
                    continue
                cur_skip = str(rec["fields"].get(skip_field, "")).strip() if skip_field else ""
                if exclude_values and cur_skip in {str(v) for v in exclude_values}:
                    continue
                candidates.append(rec)
            if not candidates:
                return None
            if index < 0 or index >= len(candidates):
                return None
            return candidates[index]

        FeishuBitable.fetch_first_record = fake_fetch  # type: ignore[method-assign]
        cfg = make_cfg(self.tmp)
        cfg["filter"]["enabled"] = True
        pkg, _ = fetch_package(cfg, verbose=False)
        self.assertEqual(pkg.record_id, "rec_new")


class TestWriteBack(PipelineTestCase):
    def test_write_prefilled_then_published(self):
        calls = []

        def fake_update(self, record_id, fields):
            calls.append((record_id, dict(fields)))

        FeishuBitable.update_record = fake_update  # type: ignore[method-assign]
        source = FeishuBitable.__new__(FeishuBitable)
        cfg = make_cfg(self.tmp)

        write_back(cfg, source, "rec_1", published=False)
        write_back(cfg, source, "rec_1", published=True)
        self.assertEqual(calls[0][1], {"状态": "待发布"})
        self.assertEqual(calls[1][1], {"状态": "已发布"})

    def test_writeback_disabled_writes_nothing(self):
        calls = []
        FeishuBitable.update_record = lambda self, rid, fields: calls.append(rid)  # type: ignore[method-assign]
        source = FeishuBitable.__new__(FeishuBitable)
        cfg = make_cfg(self.tmp)
        cfg["writeback"]["enabled"] = False
        write_back(cfg, source, "rec_1", published=True)
        self.assertEqual(calls, [])

    def test_writeback_includes_timestamp_when_published(self):
        calls = []
        FeishuBitable.update_record = lambda self, rid, fields: calls.append(dict(fields))  # type: ignore[method-assign]
        source = FeishuBitable.__new__(FeishuBitable)
        cfg = make_cfg(self.tmp)
        cfg["writeback"]["published_at_field"] = "发布时间"
        write_back(cfg, source, "rec_1", published=True)
        self.assertIn("发布时间", calls[0])
        self.assertIsInstance(calls[0]["发布时间"], int)


if __name__ == "__main__":
    unittest.main(verbosity=2)
