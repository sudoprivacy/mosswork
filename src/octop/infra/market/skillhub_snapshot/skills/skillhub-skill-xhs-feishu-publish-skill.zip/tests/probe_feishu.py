#!/usr/bin/env python3
"""用 App ID/Secret 探测飞书表的真实结构。"""
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

# 凭证从环境变量读取，避免把密钥写死进仓库/分享包。
# 用法：
#   export XHS_FEISHU_APP_ID=cli_xxxx
#   export XHS_FEISHU_APP_SECRET=xxxxxxxx
#   export XHS_FEISHU_APP_TOKEN=bascnxxxx
#   python tests/probe_feishu.py
import os

APP_ID = os.environ.get("XHS_FEISHU_APP_ID", "")
APP_SECRET = os.environ.get("XHS_FEISHU_APP_SECRET", "")
APP_TOKEN = os.environ.get("XHS_FEISHU_APP_TOKEN", "")
BASE = "https://open.feishu.cn/open-apis"

if not (APP_ID and APP_SECRET and APP_TOKEN):
    sys.exit(
        "[x] 请先设置环境变量：XHS_FEISHU_APP_ID / XHS_FEISHU_APP_SECRET / XHS_FEISHU_APP_TOKEN\n"
        "     例如：export XHS_FEISHU_APP_ID=cli_xxxx"
    )


def http(method: str, path: str, token: str | None = None, body: dict | None = None) -> dict:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        BASE + path,
        data=data,
        method=method,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            **({"Authorization": f"Bearer {token}"} if token else {}),
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        payload = json.loads(e.read().decode("utf-8") or "{}")
    return payload


def short(value, n=80):
    s = json.dumps(value, ensure_ascii=False)
    return s if len(s) <= n else s[: n - 1] + "…"


print("=== 1. 拿 tenant_access_token ===")
tok_resp = http("POST", "/auth/v3/tenant_access_token/internal", body={"app_id": APP_ID, "app_secret": APP_SECRET})
print(f"code={tok_resp.get('code')} msg={tok_resp.get('msg')}")
if tok_resp.get("code") != 0:
    print("⚠️  凭证问题：", short(tok_resp))
    sys.exit(1)
token = tok_resp["tenant_access_token"]
expire = tok_resp.get("expire")
print(f"token 已拿到（{expire}s 过期）")

print("\n=== 2. 列出 app_token 下的数据表 ===")
tbls = http(
    "GET",
    f"/bitable/v1/apps/{APP_TOKEN}/tables?page_size=20",
    token=token,
)
if tbls.get("code") != 0:
    print(f"⚠️  code={tbls.get('code')} msg={tbls.get('msg')}")
    print("常见原因：1)权限未发布  2)应用未加为表格协作者  3)权限范围不足")
    print("完整响应：", short(tbls, 500))
    sys.exit(1)
items = tbls.get("data", {}).get("items", [])
if not items:
    print("表为空")
    sys.exit(0)
for t in items:
    print(f"  table_id={t['table_id']}  名称={t['name']!r}  视图={len(t.get('view_ids', []))}")

table_id = items[0]["table_id"]
table_name = items[0]["name"]

print(f"\n使用第一个数据表：table_id={table_id} 名称={table_name!r}")

print("\n=== 3. 列出字段 ===")
flds = http(
    "GET",
    f"/bitable/v1/apps/{APP_TOKEN}/tables/{table_id}/fields?page_size=100",
    token=token,
)
if flds.get("code") != 0:
    print("⚠️", short(flds, 400))
    sys.exit(1)
fields = flds.get("data", {}).get("items", [])
for f in fields:
    type_ = f.get("type", "?")
    name = f.get("field_name", "")
    fid = f.get("field_id", "")
    print(f"  type={type_:<25} name={name!r:<20} id={fid}")

print("\n=== 4. 列出视图 ===")
vws = http(
    "GET",
    f"/bitable/v1/apps/{APP_TOKEN}/tables/{table_id}/views?page_size=100",
    token=token,
)
if vws.get("code") != 0:
    print("⚠️", short(vws, 400))
    sys.exit(1)
views = vws.get("data", {}).get("items", [])
for v in views:
    print(f"  view_id={v.get('view_id')}  名称={v.get('view_name')!r}  类型={v.get('view_type')}")

print("\n=== 5. 用第一个视图抓首条 ===")
target_view = views[0]["view_id"] if views else None
search_body = {"page_size": 3}
if target_view:
    search_body["view_id"] = target_view
recs = http(
    "POST",
    f"/bitable/v1/apps/{APP_TOKEN}/tables/{table_id}/records/search",
    token=token,
    body=search_body,
)
if recs.get("code") != 0:
    print("⚠️", short(recs, 400))
    sys.exit(1)
records = recs.get("data", {}).get("items", [])
print(f"共 {recs.get('data', {}).get('total')} 条，取前 {len(records)} 条")
for i, r in enumerate(records):
    print(f"\n  --- 第 {i + 1} 条 record_id={r['record_id']} ---")
    flds_dict = r.get("fields", {})
    for fid, val in flds_dict.items():
        # 找出字段名
        fname = next((f["field_name"] for f in fields if f["field_id"] == fid), fid)
        if isinstance(val, list) and val and isinstance(val[0], dict):
            type0 = val[0].get("type", "?")
            print(f"     {fname!r} [{type0}]: {short(val, 200)}")
        else:
            print(f"     {fname!r}: {short(val, 200)}")

print("\n=== 总结 ===")
print(f"app_token: {APP_TOKEN}")
print(f"table_id:  {table_id}  ({table_name})")
print(f"view_id:   {target_view}  ({views[0].get('view_name') if views else 'N/A'})")
