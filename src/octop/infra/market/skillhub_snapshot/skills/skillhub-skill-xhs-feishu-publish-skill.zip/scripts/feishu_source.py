#!/usr/bin/env python3
"""飞书多维表格取数层。

双通道 + 自动回退：
  1. OpenAPI 直连（默认）——只需 app_id/app_secret，不依赖任何本地 CLI
  2. lark-cli（feishu.prefer_cli=true，或 OpenAPI 权限不足时自动切换）——复用已登录的用户身份

v1.5.0 修复：
  - 当前 lark-cli（1.0.98+）的 +field-list / +record-list 输出结构已变（id/name、
    字符串类型、列式矩阵），旧适配器会静默拿到空数据，这里做了新旧双格式兼容。
  - OpenAPI 返回 91403（应用没被加为表格协作者）或缺少凭证时，若本机已登录
    lark-cli，自动切到用户身份通道重试，避免「链接一键发布」直接失败。

对外只暴露四个动作：list_fields / fetch_first_record / download_attachments / update_record
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

import requests

BASE_URL = "https://open.feishu.cn/open-apis"
TOKEN_PATH = "/auth/v3/tenant_access_token/internal"
TIMEOUT = 30


# OpenAPI 权限类错误码：命中且本机有 lark-cli 时，自动切换到用户身份通道
CLI_FALLBACK_CODES = {
    91403,       # Forbidden：应用没被加为多维表格协作者（最常见）
    99991679,    # missing_scope：原始 API 通道缺 scope
    99991661, 99991663, 99991664,  # token 失效类
    1254005,     # 无权限访问该资源
}

# 新版 lark-cli 的 +field-list 把字段类型写成字符串，映射回飞书 API 的数字类型
FIELD_TYPE_TEXT_TO_NUM = {
    "text": 1, "number": 2, "select": 3, "single_select": 3,
    "multi_select": 4, "datetime": 5, "checkbox": 7, "user": 11,
    "url": 15, "attachment": 17, "link": 18, "formula": 20,
    "lookup": 19, "button": 22, "auto_number": 1001,
}


class FeishuError(RuntimeError):
    """飞书侧的可预期错误，消息可直接呈现给用户。"""


class FeishuPermissionFallback(FeishuError):
    """OpenAPI 权限不足、已切换通道；调用方应改用 lark-cli 重试同一动作。"""


def _token_error_hint(code, msg) -> str:
    """10003 是最高频的坑：凭证复制不完整。给能直接照做的提示，而不是干巴巴的错误码。"""
    base = f"获取 tenant_access_token 失败：{msg} (code={code})"
    if code == 10003:
        base += (
            "\n\n多半是 App ID 或 App Secret 复制不完整，或首尾带了空格。\n"
            "  · App ID 形如 cli_a5ca35a685b0x26e —— cli_ 后面是 16 位字符\n"
            "  · App Secret 是 32 位字符串\n"
            "  · 请到 open.feishu.cn → 应用详情 → 凭证与基础信息，点字段右边的「复制」按钮重取\n"
            "  · 注意：Secret 默认是星号，要先点「查看」才会显示完整内容"
        )
    elif code == 10002:
        base += "\n\nApp ID 对应的应用不存在，或你登录的开发者后台与凭证不属于同一企业。"
    return base


def extract_text(value: Any) -> str:
    """把飞书单元格值规整成纯文本。

    文本字段可能是 str，也可能是 [{"type":"text","text":"..."}] 这种富文本数组。
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, dict):
        if "text" in value:
            return extract_text(value["text"])
        if "name" in value:
            return str(value["name"])
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, dict):
                # 富文本片段、人员、链接、选项都可能以 dict 出现
                if "text" in item:
                    parts.append(str(item["text"]))
                elif "name" in item:
                    parts.append(str(item["name"]))
                else:
                    parts.append(json.dumps(item, ensure_ascii=False))
            else:
                parts.append(str(item))
        return "".join(parts) if parts else ""
    return str(value)


def extract_attachments(value: Any) -> list[dict]:
    """附件字段值 → [{"file_token":..., "name":..., "size":...}]。"""
    if not value:
        return []
    if isinstance(value, dict):
        value = [value]
    out = []
    for item in value:
        if isinstance(item, dict) and item.get("file_token"):
            out.append(
                {
                    "file_token": item["file_token"],
                    "name": item.get("name") or item["file_token"],
                    "size": int(item.get("size") or 0),
                }
            )
    return out


class FeishuBitable:
    def __init__(self, cfg: dict, verbose: bool = True) -> None:
        f = cfg.get("feishu", {})
        self.app_id = (f.get("app_id") or "").strip()
        self.app_secret = (f.get("app_secret") or "").strip()
        self.app_token = (f.get("app_token") or "").strip()
        self.table_id = (f.get("table_id") or "").strip()
        self.view_id = (f.get("view_id") or "").strip()
        self.prefer_cli = bool(f.get("prefer_cli", False))
        self.auto_cli_fallback = bool(f.get("auto_cli_fallback", True))
        self.verbose = verbose
        self._token: str | None = None
        self._token_expire = 0.0
        self._cli_path: str | None = shutil.which("lark-cli")
        self._cli_broken = False
        self._fallback_to_cli = False  # OpenAPI 权限不足后置位，后续动作直接走 CLI
        self._last_channel = "unknown"

    # ---------- 基础 ----------

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg, flush=True)

    def require_coordinates(self, need_table: bool = True) -> None:
        """need_table=False 用于「只知道 app_token、要先列出数据表」的场景。"""
        pairs = [("app_token", self.app_token)]
        if need_table:
            pairs.append(("table_id", self.table_id))
        missing = [name for name, val in pairs if not val]
        if missing:
            raise FeishuError(
                f"配置缺少 {', '.join(missing)}，请先运行 "
                "`python scripts/xhs_publish.py setup --url '<飞书表格链接>'`"
            )

    @property
    def cli_available(self) -> bool:
        return bool(self._cli_path) and not self._cli_broken

    def _cli_first(self) -> bool:
        """是否优先走 lark-cli：显式配置，或 OpenAPI 已被判定权限不足。"""
        return self.cli_available and (self.prefer_cli or self._fallback_to_cli)

    def _via(self, cli_fn, api_fn):
        """按当前通道执行动作；OpenAPI 权限不足时自动切 lark-cli 重试一次。

        cli_fn / api_fn 都是无参闭包，且必须返回同一形状的结果。
        """
        if self._cli_first():
            try:
                return cli_fn()
            except Exception as exc:  # noqa: BLE001
                if self._fallback_to_cli:
                    raise  # 已经是兜底通道，别再回 OpenAPI 形成死循环
                self._log(f"[warn] lark-cli 通道失败（{exc}），改用 OpenAPI")
                self._cli_broken = True
                return api_fn()
        try:
            return api_fn()
        except FeishuPermissionFallback:
            if not (self.auto_cli_fallback and self.cli_available):
                raise
            # 置位后，后续所有动作直接走 CLI，不再逐个撞一次 403
            self._fallback_to_cli = True
            self._log("[i] OpenAPI 权限不足，自动改用 lark-cli 登录身份重试")
            return cli_fn()

    def _token_value(self) -> str:
        if self._token and time.time() < self._token_expire - 60:
            return self._token
        if not (self.app_id and self.app_secret):
            if self.auto_cli_fallback and self.cli_available and not self._fallback_to_cli:
                self._fallback_to_cli = True
                raise FeishuPermissionFallback(
                    "缺少飞书应用凭证（feishu.app_id / feishu.app_secret），尝试改用 lark-cli"
                )
            raise FeishuError(
                "缺少飞书应用凭证（feishu.app_id / feishu.app_secret）。"
                "在 open.feishu.cn 建自建应用，开通 bitable:app 与 drive:media 权限，"
                "并把应用加为多维表格协作者；或安装并登录 lark-cli 走用户身份通道。"
            )
        resp = requests.post(
            BASE_URL + TOKEN_PATH,
            json={"app_id": self.app_id, "app_secret": self.app_secret},
            timeout=TIMEOUT,
        )
        data = resp.json()
        if data.get("code") != 0:
            raise FeishuError(_token_error_hint(data.get("code"), data.get("msg")))
        self._token = data["tenant_access_token"]
        self._token_expire = time.time() + int(data.get("expire", 7200))
        return self._token

    def _headers(self) -> dict:
        return {"Authorization": "Bearer " + self._token_value(), "Content-Type": "application/json"}

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = BASE_URL + path
        resp = requests.request(method, url, headers=self._headers(), timeout=TIMEOUT, **kwargs)
        try:
            data = resp.json()
        except ValueError:
            raise FeishuError(f"{path} 返回非 JSON（HTTP {resp.status_code}），可能是权限或网关问题")
        code = data.get("code")
        if code in (99991663, 99991661, 99991664):  # token 失效类，重试一次
            self._token = None
            resp = requests.request(method, url, headers=self._headers(), timeout=TIMEOUT, **kwargs)
            data = resp.json()
            code = data.get("code")
        if code != 0:
            msg = f"飞书接口 {path} 失败：{data.get('msg')} (code={code})"
            if (
                code in CLI_FALLBACK_CODES
                and self.auto_cli_fallback
                and self.cli_available
                and not self._fallback_to_cli
            ):
                self._fallback_to_cli = True
                raise FeishuPermissionFallback(msg)
            raise FeishuError(msg)
        return data.get("data", {})

    def _run_cli(self, args: list[str]) -> subprocess.CompletedProcess:
        if not self._cli_path:
            raise FeishuError("lark-cli 不可用")
        env = os.environ.copy()
        # Windows Git Bash 会把 /open-apis/... 当 POSIX 路径转成 Windows 路径，
        # 导致 raw api 调用 404；这里禁用路径转换。
        env.setdefault("MSYS_NO_PATHCONV", "1")
        return subprocess.run(
            [self._cli_path, *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
            timeout=180,
        )

    def _run_cli_json(self, args: list[str]) -> dict:
        """执行 lark-cli 并解析 JSON，返回 data 段（兼容无 data 包装的旧版输出）。"""
        proc = self._run_cli(args)
        payload = _parse_cli_json(proc)
        if proc.returncode != 0 or (isinstance(payload, dict) and payload.get("ok") is False):
            err = ""
            if isinstance(payload, dict):
                err = str(payload.get("error") or "")
            err = err or (proc.stderr or proc.stdout or "").strip()
            raise FeishuError(f"lark-cli {' '.join(args[:2])} 失败：{err[:300]}")
        if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
            return payload["data"]
        return payload if isinstance(payload, dict) else {}

    # ---------- 数据表与视图 ----------

    def list_tables(self) -> list[dict]:
        """列出 Base 下所有数据表，供只有 app_token 的场景挑选。"""
        self.require_coordinates(need_table=False)

        def _api():
            self._last_channel = "openapi"
            data = self._request(
                "GET", f"/bitable/v1/apps/{self.app_token}/tables",
                params={"page_size": 100},
            )
            return [
                {"table_id": it.get("table_id", ""), "name": it.get("name", "")}
                for it in data.get("items", [])
            ]

        return self._via(self._list_tables_cli, _api)

    def _list_tables_cli(self) -> list[dict]:
        data = self._run_cli_json(["base", "+table-list", "--base-token", self.app_token, "--as", "user"])
        items = _dig_list(data)
        if not items:
            raise FeishuError("lark-cli 未返回数据表")
        self._last_channel = "lark-cli"
        return [
            {"table_id": it.get("table_id", "") or it.get("id", ""),
             "name": it.get("name", "") or it.get("table_name", "")}
            for it in items if isinstance(it, dict)
        ]

    def list_views(self) -> list[dict]:
        """列出指定数据表的所有视图，「排序第一条」取决于选哪个视图。"""
        self.require_coordinates()

        def _api():
            self._last_channel = "openapi"
            data = self._request(
                "GET",
                f"/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/views",
                params={"page_size": 100},
            )
            return [
                {
                    "view_id": it.get("view_id", ""),
                    "name": it.get("view_name", ""),
                    "view_type": it.get("view_type", ""),
                }
                for it in data.get("items", [])
            ]

        return self._via(self._list_views_cli, _api)

    def _list_views_cli(self) -> list[dict]:
        data = self._run_cli_json([
            "base", "+view-list",
            "--base-token", self.app_token,
            "--table-id", self.table_id,
            "--as", "user",
        ])
        items = _dig_list(data)
        if not items:
            raise FeishuError("lark-cli 未返回视图")
        self._last_channel = "lark-cli"
        return [
            {
                "view_id": it.get("view_id", "") or it.get("id", ""),
                "name": it.get("view_name", "") or it.get("name", ""),
                "view_type": it.get("view_type", ""),
            }
            for it in items if isinstance(it, dict)
        ]

    # ---------- 字段 ----------

    def list_fields(self) -> list[dict]:
        """返回 [{"field_id","field_name","type","ui_type","property"}]。

        property 必须保留 —— 单选字段的选项列表存在这里，
        丢掉它会让回写护栏把所有值都误判为「选项不存在」。
        """
        self.require_coordinates()

        def _api():
            self._last_channel = "openapi"
            data = self._request(
                "GET",
                f"/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/fields",
                params={"page_size": 200},
            )
            return [
                {
                    "field_id": it.get("field_id", ""),
                    "field_name": it.get("field_name", ""),
                    "type": it.get("type"),
                    "ui_type": it.get("ui_type", ""),
                    "property": it.get("property") or {},
                }
                for it in data.get("items", [])
            ]

        return self._via(self._list_fields_cli, _api)

    def _list_fields_cli(self) -> list[dict]:
        """兼容两代 lark-cli 输出。

        旧版：{"items":[{"field_id","field_name","type":3,"property":{"options":[...]}}]}
        新版：{"fields":[{"id","name","type":"select","options":[...]}]}
        统一成 OpenAPI 的形状，保证 detect_roles / select_options 都能用。
        """
        data = self._run_cli_json([
            "base", "+field-list",
            "--base-token", self.app_token,
            "--table-id", self.table_id,
            "--as", "user",
        ])
        items = _dig_list(data)
        if not items:
            raise FeishuError("lark-cli 未返回字段列表")
        self._last_channel = "lark-cli"
        return normalize_cli_fields(items)

    # ---------- 取记录 ----------

    def fetch_first_record(
        self,
        page_size: int = 5,
        include_field: str = "",
        required_values: list[str] | tuple[str, ...] = (),
        skip_field: str = "",
        exclude_values: list[str] | tuple[str, ...] = (),
        sort_field_name: str = "",
        sort_order: str = "desc",
        index: int = 0,
    ) -> dict | None:
        """取首条（或第 index 条，0-based）可用记录。

        include_field + required_values：该行「筛选字段」的值必须在白名单中（如「高潜力」）。
        skip_field + exclude_values：该行「发布状态字段」的值命中黑名单则跳过（如「待发布」「已发布」）。
            两者可以不同 —— 例如用「筛选状态」挑高潜力，用「发布状态」跳过已发布/待发布。
        sort_field_name：本地按此字段名排序（用页内结果集）；
                      飞书 search API 不支持按 formula 排序，所以排序逻辑在前端做。
                      sort_field_name 为空表示用表/视图默认顺序。
        index：在候选集（已过滤+已排序）里的位置，0-based。0 取第一条，28 取第 29 条。
              超出候选集范围时返回 None。
        """
        self.require_coordinates()
        if sort_field_name:
            self._validate_sort_field(sort_field_name)
        records = self._fetch_records(page_size)
        if not records:
            return None
        include = {str(v).strip() for v in required_values} if required_values else None
        exclude = {str(v).strip() for v in exclude_values} if exclude_values else None
        candidates: list[dict] = []
        for rec in records:
            fields = rec.get("fields", {})
            if include is not None:
                cur_include = (
                    extract_text(fields.get(include_field, "")).strip() if include_field else ""
                )
                if cur_include not in include:
                    continue
            if exclude is not None:
                cur_skip = (
                    extract_text(fields.get(skip_field, "")).strip() if skip_field else ""
                )
                if cur_skip in exclude:
                    continue
            candidates.append(rec)
        if not candidates:
            return None
        if sort_field_name:
            candidates.sort(
                key=lambda r: self._local_sort_key(r, sort_field_name),
                reverse=(sort_order == "desc"),
            )
        if index < 0 or index >= len(candidates):
            return None
        return candidates[index]

    def _validate_sort_field(self, field_name: str) -> None:
        fields = self.list_fields()
        if not any(str(f.get("field_name", "")) == field_name for f in fields):
            raise FeishuError(f"排序字段「{field_name}」在表里不存在")

    def _local_sort_key(self, record: dict, field_name: str) -> float:
        """把飞书单元格值归一为可比较的数字，公式字段 → value[0]，None → -inf。

        公式/数字字段返回 {"type": 2, "value": [9.0]} 或 [9.0]；其他形态取首项。
        """
        val = record.get("fields", {}).get(field_name)
        if val is None:
            return float("-inf")
        if isinstance(val, dict):
            arr = val.get("value") or []
            if arr and isinstance(arr, list):
                try:
                    return float(arr[0])
                except (TypeError, ValueError):
                    return float("-inf")
            return float("-inf")
        if isinstance(val, list):
            if not val:
                return float("-inf")
            first = val[0]
            if isinstance(first, dict):
                inner = first.get("value")
                if isinstance(inner, list) and inner:
                    try:
                        return float(inner[0])
                    except (TypeError, ValueError):
                        pass
                if "text" in first:
                    try:
                        return float(first["text"])
                    except (TypeError, ValueError):
                        return float("-inf")
            try:
                return float(first)
            except (TypeError, ValueError):
                return float("-inf")
        if isinstance(val, (int, float)):
            return float(val)
        try:
            return float(val)
        except (TypeError, ValueError):
            return float("-inf")

    def _fetch_records(self, page_size: int = 5) -> list[dict]:
        """按视图顺序取前 N 条，排序由调用方本地处理（飞书 search API 不支持 formula 字段排序）。"""
        def _api():
            self._last_channel = "openapi"
            params: dict[str, Any] = {"page_size": max(1, min(page_size, 500))}
            if self.view_id:
                params["view_id"] = self.view_id
            data = self._request(
                "POST",
                f"/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/records/search",
                params=params,
                json={"automatic_fields": False},
            )
            return [
                {"record_id": it.get("record_id", ""), "fields": it.get("fields", {})}
                for it in data.get("items", [])
            ]

        return self._via(lambda: self._fetch_records_cli(page_size), _api)

    def _fetch_records_cli(self, page_size: int) -> list[dict]:
        """新版 lark-cli 用 --limit/--offset/--format json，返回列式矩阵：
           data.fields（列名） + data.data（每行值的数组） + data.record_id_list。
        旧版返回 items:[{record_id, fields}]，这里两种都兼容，并按需自动翻页。
        """
        wanted = max(1, min(page_size, 500))
        records: list[dict] = []
        offset = 0
        use_view = bool(self.view_id)

        while len(records) < wanted and offset < 2000:
            limit = min(200, wanted - len(records))  # json 格式单页上限 200

            def _call(with_view: bool) -> dict:
                args = [
                    "base", "+record-list",
                    "--base-token", self.app_token,
                    "--table-id", self.table_id,
                    "--limit", str(limit),
                    "--offset", str(offset),
                    "--format", "json",
                    "--as", "user",
                ]
                if with_view and self.view_id:
                    args += ["--view-id", self.view_id]
                return self._run_cli_json(args)

            try:
                data = _call(use_view)
            except FeishuError:
                if not use_view:
                    raise
                self._log("[warn] lark-cli 不接受 --view-id，已忽略视图、改用表默认顺序")
                use_view = False
                data = _call(False)

            page, has_more = normalize_cli_records(data)
            if not page:
                break
            records.extend(page)
            offset += len(page)
            if not has_more:
                break

        if not records:
            raise FeishuError("lark-cli 未返回记录")
        self._last_channel = "lark-cli"
        return records[:wanted]

    # ---------- 附件 ----------

    def download_attachments(self, record_id: str, attachments: list[dict], out_dir: Path) -> list[Path]:
        """把附件逐个下载到 out_dir，返回本地路径列表。"""
        out_dir.mkdir(parents=True, exist_ok=True)
        saved: list[Path] = []
        for idx, att in enumerate(attachments, start=1):
            token = att["file_token"]
            name = _safe_filename(att.get("name") or f"image_{idx}")
            target = out_dir / f"{idx:02d}_{name}"
            if self._cli_first():
                try:
                    self._download_cli(record_id, token, out_dir, target)
                    saved.append(target)
                    continue
                except Exception as exc:  # noqa: BLE001
                    if self._fallback_to_cli:
                        raise FeishuError(f"lark-cli 下载附件失败（{exc}），且 OpenAPI 通道无权限")
                    self._log(f"[warn] lark-cli 下载附件失败（{exc}），改用 OpenAPI")
                    self._cli_broken = True
            try:
                self._download_openapi(token, target)
            except FeishuPermissionFallback:
                if not (self.auto_cli_fallback and self.cli_available):
                    raise
                self._log("[i] OpenAPI 权限不足，自动改用 lark-cli 下载附件")
                self._download_cli(record_id, token, out_dir, target)
            saved.append(target)
        return saved

    def _download_openapi(self, file_token: str, target: Path) -> None:
        url = f"{BASE_URL}/drive/v1/medias/{file_token}/download"
        with requests.get(url, headers=self._headers(), stream=True, timeout=120) as resp:
            if resp.status_code != 200:
                raise FeishuError(f"附件下载失败：HTTP {resp.status_code}（file_token={file_token}）")
            ctype = (resp.headers.get("Content-Type") or "").lower()
            if ctype.startswith("application/json"):
                # 错误响应也是 200，靠 content-type 与内容判别
                head = resp.content[:400]
                raise FeishuError(f"附件下载返回错误信息：{head[:200]!r}")
            with open(target, "wb") as fh:
                for chunk in resp.iter_content(chunk_size=65536):
                    if chunk:
                        fh.write(chunk)
        if target.stat().st_size == 0:
            target.unlink(missing_ok=True)
            raise FeishuError(f"附件下载为空：{file_token}")

    def _download_cli(self, record_id: str, token: str, out_dir: Path, target: Path) -> None:
        # 方案 1：raw api 直接落到指定文件名，最可控（不需要额外 scope，且顺序稳定）
        try:
            proc = self._run_cli([
                "api", "GET",
                f"/open-apis/drive/v1/medias/{token}/download",
                "--as", "user",
                "-o", str(target),
            ])
            if proc.returncode == 0 and target.exists() and target.stat().st_size > 0:
                self._last_channel = "lark-cli"
                return
            target.unlink(missing_ok=True)
        except Exception as exc:  # noqa: BLE001
            self._log(f"[warn] raw api 下载失败（{exc}），改用 +record-download-attachment")
            target.unlink(missing_ok=True)

        # 方案 2：typed 命令（CLI 按原文件名落盘，再重命名为有序编号）
        before = set(out_dir.glob("*"))
        proc = self._run_cli([
            "base", "+record-download-attachment",
            "--base-token", self.app_token,
            "--table-id", self.table_id,
            "--record-id", record_id,
            "--file-token", token,
            "--output", str(out_dir),
            "--as", "user",
        ])
        if proc.returncode != 0:
            raise FeishuError((proc.stderr or proc.stdout or "").strip()[:300])
        if not target.exists():
            after = set(out_dir.glob("*"))
            added = [p for p in after if p not in before and p.is_file()]
            if not added:
                raise FeishuError("lark-cli 下载后未找到新文件")
            newest = max(added, key=lambda p: p.stat().st_mtime)
            if newest.resolve() != target.resolve():
                newest.rename(target)
        if not target.exists() or target.stat().st_size == 0:
            raise FeishuError(f"附件下载结果为空：{token}")
        self._last_channel = "lark-cli"

    # ---------- 回写 ----------

    def update_record(self, record_id: str, fields: dict) -> None:
        if not fields:
            return
        self._guard_select_options(fields)

        def _api():
            self._request(
                "PUT",
                f"/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/records/{record_id}",
                json={"fields": fields},
            )

        self._via(lambda: self._update_record_cli(record_id, fields), _api)
        self._log(f"[ok] 已回写飞书记录 {record_id}：{list(fields)}")

    def _update_record_cli(self, record_id: str, fields: dict) -> None:
        """+record-upsert 的 select 字段要求数组值，这里按字段类型自动转换。"""
        type_by_name: dict[str, int] = {}
        for f in self.list_fields():
            try:
                type_by_name[str(f.get("field_name", ""))] = int(f.get("type") or 0)
            except (TypeError, ValueError):
                continue
        payload: dict[str, Any] = {}
        for name, value in fields.items():
            ftype = type_by_name.get(name, 0)
            payload[name] = [value] if ftype in (3, 4) and isinstance(value, str) else value
        self._run_cli_json([
            "base", "+record-upsert",
            "--base-token", self.app_token,
            "--table-id", self.table_id,
            "--record-id", record_id,
            "--json", json.dumps(payload, ensure_ascii=False),
            "--as", "user",
        ])
        self._last_channel = "lark-cli"

    def select_options(self, field_name: str) -> list[str] | None:
        """取单选字段的现有选项名列表。

        返回 None 表示「字段不存在」或「不是单选字段」，
        调用方据此决定是否要做选项校验。
        """
        if not field_name:
            return None
        meta = self.list_fields()
        target = next(
            (
                f
                for f in meta
                if str(f.get("field_name", "")) == field_name
                or str(f.get("field_id", "")) == field_name
            ),
            None,
        )
        if target is None or int(target.get("type", 0)) != 3:
            return None
        options = (target.get("property") or {}).get("options") or []
        return [str(o.get("name", "")) for o in options]

    def _guard_select_options(self, fields: dict) -> None:
        """single-select 回写时，值必须在表里已存在的选项里，否则报错。

        比"含糊的飞书错误"友好得多 —— 把定位信息直接给操作者。
        """
        try:
            meta = self.list_fields()
        except Exception:  # noqa: BLE001 - 拉不到元数据也别阻塞主流程，让飞书自己的校验去报错
            return
        for field_name, value in fields.items():
            target = next(
                (
                    f
                    for f in meta
                    if str(f.get("field_name", "")) == field_name
                    or str(f.get("field_id", "")) == field_name
                ),
                None,
            )
            if not target:
                continue  # 不在表里 —— 留给飞书报「字段不存在」
            if int(target.get("type", 0)) != 3:
                continue  # 不是单选，跳过
            options = (target.get("property") or {}).get("options") or []
            names = {str(o.get("name", "")) for o in options}
            if str(value) not in names:
                raise FeishuError(
                    f"飞书字段「{target.get('field_name')}」是单选字段，"
                    f"传入值「{value}」不在现有选项里：{sorted(names)}\n"
                    f"请到飞书表格里手动加一个新选项，名字就叫「{value}」"
                )


def _parse_cli_json(proc: subprocess.CompletedProcess) -> Any:
    """lark-cli 输出可能混有提示行，取最外层 JSON 片段解析。"""
    text = (proc.stdout or "").strip()
    if not text:
        raise FeishuError("lark-cli 无输出")
    try:
        return json.loads(text)
    except ValueError:
        pass
    start = min((i for i in (text.find("{"), text.find("[")) if i >= 0), default=-1)
    if start < 0:
        raise FeishuError(f"lark-cli 输出无法解析：{text[:200]}")
    # 从后往前找能成功解析的最长片段
    for end in range(len(text), start, -1):
        try:
            return json.loads(text[start:end])
        except ValueError:
            continue
    raise FeishuError(f"lark-cli 输出无法解析：{text[:200]}")


def _dig_list(payload: Any, depth: int = 0) -> list:
    """从 CLI 的嵌套响应里找出真正的记录/字段数组。"""
    if depth > 6:
        return []
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("items", "records", "fields", "tables", "views", "data"):
            val = payload.get(key)
            if isinstance(val, list):
                return val
            if isinstance(val, dict):
                found = _dig_list(val, depth + 1)
                if found:
                    return found
    return []


def normalize_cli_fields(items: list) -> list[dict]:
    """把 lark-cli 的字段列表统一成 OpenAPI 形状（纯函数，便于测试）。

    旧版 item：{"field_id","field_name","type":3,"property":{"options":[...]}}
    新版 item：{"id","name","type":"select","options":[...]}
    """
    out: list[dict] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        raw_type = it.get("type")
        if isinstance(raw_type, str):
            ftype = FIELD_TYPE_TEXT_TO_NUM.get(raw_type.strip().lower(), 0)
            ui_type = it.get("ui_type") or raw_type
        else:
            ftype = raw_type
            ui_type = it.get("ui_type", "")
        prop = dict(it.get("property") or {})
        if it.get("options") and not prop.get("options"):
            prop["options"] = it["options"]
        out.append({
            "field_id": it.get("field_id") or it.get("id") or "",
            "field_name": it.get("field_name") or it.get("name") or "",
            "type": ftype,
            "ui_type": ui_type,
            "property": prop,
        })
    return out


def normalize_cli_records(data: dict) -> tuple[list[dict], bool]:
    """把 lark-cli 的记录响应统一成 [{record_id, fields}]（纯函数，便于测试）。

    旧版：{"items":[{"record_id","fields":{...}}], "has_more":bool}
    新版：{"fields":[列名...], "data":[[值...],...], "record_id_list":[...], "has_more":bool}
    返回 (本页记录, has_more)。
    """
    if isinstance(data.get("items"), list):
        page = [
            {"record_id": it.get("record_id", ""), "fields": it.get("fields", {})}
            for it in data["items"] if isinstance(it, dict)
        ]
    else:
        names = data.get("fields") or []
        rows = data.get("data") or []
        rids = data.get("record_id_list") or []
        page = [
            {
                "record_id": rids[i] if i < len(rids) else "",
                "fields": {names[j]: row[j] for j in range(min(len(names), len(row)))},
            }
            for i, row in enumerate(rows) if isinstance(row, list)
        ]
    return page, bool(data.get("has_more"))


def _safe_filename(name: str) -> str:
    keep = []
    for ch in name:
        if ch in '\\/:*?"<>|':
            keep.append("_")
        else:
            keep.append(ch)
    out = "".join(keep).strip().strip(".")
    return out[:80] or "image"
