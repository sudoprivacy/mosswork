#!/usr/bin/env python3
"""飞书多维表格 → 小红书 半自动发布 · 主入口。

  setup    解析表格链接、探测字段、生成配置
  check    体检：凭证 / 依赖 / 连通性 / 字段映射 / 登录态
  fetch    只取视图第一条并打印，不动浏览器
  prepare  取数 + 下载配图 + 校验 + 产出草稿包
  publish  全流程：prepare → 预填创作者中心 → 等你点发布 → 回写飞书
"""

from __future__ import annotations

import argparse
import copy
import re
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))

try:
    import yaml
except ImportError:
    sys.exit("[x] 缺少 PyYAML，请先执行：pip install PyYAML requests playwright")

from feishu_source import FeishuBitable, FeishuError, extract_attachments, extract_text  # noqa: E402
from image_store import (  # noqa: E402
    NotePackage,
    PackageError,
    normalize_topics,
    prepare_image_dir,
    prune_stale_image_dirs,
    validate_images,
    validate_text,
    write_draft,
)
from setup_wizard import run_setup, parse_bitable_url, detect_roles  # noqa: E402

DEFAULT_CONFIG = SKILL_ROOT / "config" / "config.yaml"
EXAMPLE_CONFIG = SKILL_ROOT / "config" / "config.example.yaml"


# ---------- 配置 ----------

def load_config(path: Path) -> dict:
    if not path.exists():
        if EXAMPLE_CONFIG.exists():
            raise SystemExit(
                f"[x] 还没有配置文件 {path}\n"
                f"先跑：python {Path(__file__).name} setup --url '<飞书表格链接>'\n"
                f"或手动复制 {EXAMPLE_CONFIG} 为 config.yaml 后填写。"
            )
        raise SystemExit(f"[x] 配置文件不存在：{path}")
    with open(path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}
    return _with_defaults(cfg)


def build_runtime_config(cfg: dict, url: str, verbose: bool = True) -> tuple[dict, dict]:
    """从飞书链接生成「一次性运行配置」，**不落盘** config.yaml。

    流程：
      1. 解析链接得到 app_token / table_id / view_id
      2. 深拷贝当前 cfg，仅覆盖 feishu 坐标系，其余（字段映射/校验/选择器/浏览器/回写）沿用已存配置
      3. 探测目标表字段：
         - 已配置的 标题/正文/配图 若在该表不存在，则按字段名关键词自动适配（detect_roles）
         - 状态字段若不在该表，则尝试自动适配；实在没有就本趟关掉回写（不影响发布）
    返回 (runtime_cfg, coord)。
    """
    if not url or not str(url).strip():
        raise FeishuError("缺少飞书链接（--url）")
    coord = parse_bitable_url(url)
    rt = copy.deepcopy(cfg)
    feishu = rt.setdefault("feishu", {})
    feishu["app_token"] = coord["app_token"]
    if coord["table_id"]:
        feishu["table_id"] = coord["table_id"]
    if coord["view_id"]:
        feishu["view_id"] = coord["view_id"]

    source = FeishuBitable(rt, verbose=False)
    try:
        fields = source.list_fields()
    except FeishuError as exc:
        raise FeishuError(
            f"读取链接对应的表失败：{exc}\n\n"
            "常见原因：\n"
            "  1. 该 base 没有把飞书自建应用加为协作者（打开表格 → 分享 → 邀请应用）\n"
            "  2. 应用只有「可阅读」权限、读接口正常但部分表受限\n"
            "  3. 链接复制不完整（需 /base/ 开头、含 table= 的完整链接）"
        )
    names = {str(f.get("field_name", "")) for f in fields}
    if verbose:
        print(
            f"[i] 链接解析 → base={coord['app_token']}  table={coord['table_id'] or '(链接未带，用表默认)'}  "
            f"view={coord['view_id'] or '(未指定)'}"
        )
        print(f"[i] 目标表字段：{sorted(names)}")

    fcfg = rt.setdefault("fields", {})
    detected = detect_roles(fields)
    # 标题/正文/配图 必须保证存在
    for role, label in (("title", "标题"), ("body", "正文"), ("images", "配图")):
        cur = str(fcfg.get(role, "")).strip()
        if cur and cur in names:
            continue
        cand = (detected.get(role) or "").strip()
        if cand and cand in names:
            if verbose:
                print(f"[i] 自动适配：{label}字段 → 「{cand}」（原配置「{cur}」在该表不存在）")
            fcfg[role] = cand
        else:
            raise FeishuError(
                f"该表找不到可用的「{label}」列（原配置「{cur}」不存在，自动识别也未命中）。\n"
                f"请确认链接对应的表格确实含{label}字段；实际字段：{sorted(names)}"
            )
    # 状态字段：存在则校验/适配；不存在则本趟关回写
    wb = rt.setdefault("writeback", {})
    status = str(fcfg.get("status", "")).strip()
    if status and status not in names:
        cand = (detected.get("status") or "").strip()
        if cand and cand in names:
            if verbose:
                print(f"[i] 自动适配：状态字段 → 「{cand}」")
            fcfg["status"] = cand
            if "status_field" in rt.get("filter", {}):
                rt["filter"]["status_field"] = cand
        else:
            if verbose:
                print(f"[warn] 该表无「{status}」状态列，本次跳过飞书状态回写（不影响小红书发布）")
            wb["enabled"] = False
    return rt, coord


def credential_problems(cfg: dict) -> list[str]:
    """检查凭证格式是否像被截断。飞书 App ID 形如 cli_a5ca35a685b0x26e（cli_ + 16 位）。"""
    issues: list[str] = []
    f = cfg.get("feishu", {})
    app_id = str(f.get("app_id", "")).strip()
    if app_id and not re.fullmatch(r"cli_[0-9A-Za-z]{16,32}", app_id):
        issues.append(
            f"feishu.app_id 格式可疑：{app_id}（cli_ 后应为 16 位，当前 {len(app_id) - 4} 位）\n"
            "       很可能复制时被截断，去开放平台点「复制」按钮重取"
        )
    secret = str(f.get("app_secret", "")).strip()
    if secret and len(secret) < 20:
        issues.append(f"feishu.app_secret 只有 {len(secret)} 位（正常 32 位），没复制全")
    return issues


def _with_defaults(cfg: dict) -> dict:
    cfg.setdefault("mode", "assist")
    cfg.setdefault("feishu", {})
    cfg.setdefault("fields", {})
    cfg.setdefault("filter", {})
    cfg.setdefault("writeback", {})
    cfg.setdefault("limits", {})
    cfg.setdefault("compliance", {})
    cfg.setdefault("paths", {})
    cfg.setdefault("browser", {})
    cfg.setdefault("selectors", {})
    cfg["paths"].setdefault("workdir", ".xhs_work")
    cfg["paths"].setdefault("images_subdir", "images")
    cfg["paths"].setdefault("browser_profile", ".xhs_browser_profile")
    cfg["limits"].setdefault("title_max", 20)
    cfg["limits"].setdefault("body_max", 1000)
    cfg["limits"].setdefault("image_max", 18)
    cfg["limits"].setdefault("image_size_mb", 32)
    cfg["limits"].setdefault("topic_max", 10)
    cfg["browser"].setdefault("headless", False)
    cfg["browser"].setdefault("timeout_ms", 30000)
    cfg["browser"].setdefault("wait_publish_seconds", 900)
    cfg["browser"].setdefault("login_wait_seconds", 300)
    cfg["browser"].setdefault("upload_wait_seconds", 90)
    cfg["browser"].setdefault("creator_url", "https://creator.xiaohongshu.com/publish/publish?target=image")
    cfg["browser"].setdefault("login_url_contains", "login")
    return cfg


def workdir_of(cfg: dict) -> Path:
    wd = Path(cfg["paths"]["workdir"])
    if not wd.is_absolute():
        wd = SKILL_ROOT / wd
    wd.mkdir(parents=True, exist_ok=True)
    return wd


# ---------- 取数与组装 ----------

def resolve_fetch_params(cfg: dict, index: int = 0, no_filter: bool = False) -> dict:
    """统一计算取数参数：含/不含筛选、排序、分页大小。

    index      : 0-based，要取候选集里的第几条（0=第一条，28=第 29 条）
    no_filter  : True 时忽略「高潜力」白名单、「已发布/待发布」黑名单与综合得分排序，
                 直接按表/视图原始顺序取第 index+1 条（用于「表格第 N 行」语义）。
    """
    fields_cfg = cfg["fields"]
    filter_cfg = cfg["filter"]

    include_field = str(filter_cfg.get("status_field") or fields_cfg.get("status") or "").strip()
    skip_field = str(filter_cfg.get("skip_field") or "").strip()
    exclude = list(filter_cfg.get("exclude_values") or [])
    required = list(filter_cfg.get("required_values") or [])
    sort_field_name = str(filter_cfg.get("sort_field_name") or "").strip()
    sort_order = str(filter_cfg.get("sort_order") or "desc").strip().lower()

    if no_filter:
        include_field = ""
        required = []
        skip_field = ""
        exclude = []
        sort_field_name = ""

    active = bool(filter_cfg.get("enabled")) and (
        (include_field and required) or (skip_field and exclude)
    )

    # 分页至少要覆盖到第 index 条；过滤开启时候选会少于原始条数，给足余量
    min_needed = index + 1
    scan_size = max(1, int(filter_cfg.get("scan_size", 30)) if active else 1)
    scan_size = max(scan_size, min_needed)
    scan_size = min(scan_size, 500)  # 飞书 search API 单页上限

    return {
        "page_size": scan_size,
        "include_field": include_field if (active and required) else "",
        "required_values": tuple(required) if (active and required) else (),
        "skip_field": skip_field if (active and exclude) else "",
        "exclude_values": tuple(exclude) if (active and exclude) else (),
        "sort_field_name": sort_field_name,
        "sort_order": sort_order,
        "index": index,
        "active": active,
    }


def fetch_package(cfg: dict, verbose: bool = True, index: int = 0, no_filter: bool = False) -> tuple[NotePackage, FeishuBitable]:
    """取记录 → 下载配图 → 校验 → 组装笔记包。

    取数规则：filter.enabled 时按状态字段过滤；
              filter.sort_field_name 不为空时按该字段排序（desc/asc）。
    不直接走视图默认顺序——视图当前顺序可能与「高潜力第一条」不一致。
    index/no_filter 用于支持「取表格第 N 条（原始行序）」这类诉求。
    """
    fields_cfg = cfg["fields"]
    source = FeishuBitable(cfg, verbose=verbose)
    p = resolve_fetch_params(cfg, index=index, no_filter=no_filter)

    record = source.fetch_first_record(
        page_size=p["page_size"],
        include_field=p["include_field"],
        required_values=p["required_values"],
        skip_field=p["skip_field"],
        exclude_values=p["exclude_values"],
        sort_field_name=p["sort_field_name"],
        sort_order=p["sort_order"],
        index=p["index"],
    )
    if record is None:
        if no_filter:
            raise FeishuError(
                f"表格里没有第 {index + 1} 行（已抓取 {p['page_size']} 行，可能总数不足）。"
            )
        raise FeishuError(
            "视图里没有可发布的记录了"
            + ("（符合要求的行都已被标记，先去表格里补新选题）" if p["active"] else "")
        )

    values = record.get("fields", {})
    title = extract_text(values.get(fields_cfg.get("title", ""), "")).strip()
    body = extract_text(values.get(fields_cfg.get("body", ""), "")).strip()
    topics = normalize_topics(
        extract_text(values.get(fields_cfg.get("topics", ""), "")).strip(),
        int(cfg["limits"].get("topic_max", 10)),
    ) if fields_cfg.get("topics") else []

    if cfg.get("compliance", {}).get("ai_declaration"):
        decl = str(cfg["compliance"].get("ai_declaration_text", "")).strip()
        if decl and decl not in body:
            body = f"{body}\n{decl}"

    pkg = NotePackage(
        record_id=record.get("record_id", ""),
        title=title,
        body=body,
        topics=topics,
        raw_fields=values,
    )
    validate_text(pkg, cfg["limits"])

    images_dir = workdir_of(cfg) / cfg["paths"]["images_subdir"] / (pkg.record_id or "default")
    prepare_image_dir(images_dir)
    prune_stale_image_dirs(workdir_of(cfg) / cfg["paths"]["images_subdir"], keep=pkg.record_id)
    attachments = extract_attachments(values.get(fields_cfg.get("images", ""), ""))
    if not attachments:
        raise PackageError(
            f"记录「{title}」的配图字段「{fields_cfg.get('images')}」里没有附件，"
            "请确认该字段是附件类型且已上传图片"
        )
    pkg.image_paths = validate_images(
        source.download_attachments(pkg.record_id, attachments, images_dir),
        cfg["limits"],
    )
    return pkg, source


def write_back(cfg: dict, source: FeishuBitable, record_id: str, published: bool) -> bool:
    wb = cfg.get("writeback", {})
    status_field = str(cfg.get("fields", {}).get("status", "")).strip()
    if not wb.get("enabled") or not status_field or not record_id:
        return False
    value = wb.get("on_published") if published else wb.get("on_prefilled")
    if not value:
        return False
    payload = {status_field: str(value)}
    date_field = str(wb.get("published_at_field") or "").strip()
    if published and date_field:
        payload[date_field] = int(time.time() * 1000)
    try:
        source.update_record(record_id, payload)
        return True
    except FeishuError as exc:
        print(f"[warn] 回写飞书失败（不影响已发布内容）：{exc}", flush=True)
        return False


# ---------- 子命令 ----------

def cmd_setup(args) -> int:
    cfg = load_config(args.config) if args.config.exists() else {}
    run_setup(cfg, SKILL_ROOT, args.url, verbose=not args.quiet)
    return 0


def _check_status_options(
    cfg: dict, source: FeishuBitable, problems: list[str], warnings: list[str]
) -> None:
    """预检状态字段的单选选项。

    回写值（待发布/已发布）若不在选项里，发布成功后回写会被飞书拒，
    导致第二天又取到同一条 —— 这是全链路最容易漏的一步，所以放在 check 里提前报。
    """
    wb = cfg.get("writeback") or {}
    status_field = str(cfg.get("fields", {}).get("status", "")).strip()
    if not status_field or not wb.get("enabled"):
        return
    try:
        options = source.select_options(status_field)
    except Exception:  # noqa: BLE001 - 元数据读取失败不阻塞体检，发布时还有护栏兜底
        return
    if options is None:
        return  # 不是单选字段，无需预建选项

    write_values = [str(wb.get(k, "")).strip() for k in ("on_prefilled", "on_published")]
    write_values = [v for v in write_values if v]
    missing = [v for v in write_values if v not in options]
    if missing:
        problems.append(
            f"飞书字段「{status_field}」的选项里缺少 {missing}（现有：{options}）\n"
            f"       去表格里给该列加这些选项，否则发布后状态回写会被飞书拒绝，"
            f"下次运行还会取到同一条笔记"
        )
    else:
        print(f"  [ok] 回写选项齐全：{write_values}")

    # 过滤黑名单应检查「跳过字段」，它可能与回写字段不同
    filt = cfg.get("filter") or {}
    skip_field = str(filt.get("skip_field") or "").strip() or status_field
    if filt.get("enabled") and skip_field:
        skip_options = options if skip_field == status_field else None
        if skip_options is None:
            try:
                skip_options = source.select_options(skip_field)
            except Exception:  # noqa: BLE001 - 读不到选项不阻塞体检
                skip_options = None
        if skip_options is not None:
            absent = [
                str(v).strip()
                for v in (filt.get("exclude_values") or [])
                if str(v).strip() and str(v).strip() not in skip_options
            ]
            if absent:
                warnings.append(
                    f"filter.exclude_values 里的 {absent} 在「{skip_field}」选项中不存在，"
                    f"过滤不会生效（通常是还没建这个选项）"
                )


def cmd_check(args) -> int:
    cfg = load_config(args.config)
    print(f"配置文件: {args.config}")
    problems: list[str] = []
    warnings: list[str] = []

    # 1. 依赖
    for mod, pip_name, required in (
        ("requests", "requests", True),
        ("yaml", "PyYAML", True),
        ("playwright", "playwright", False),
    ):
        try:
            __import__(mod)
            print(f"  [ok] 依赖 {pip_name}")
        except ImportError:
            if required:
                problems.append(f"缺少依赖 {pip_name}：pip install {pip_name}")
            else:
                warnings.append(f"未安装 {pip_name}（只有开浏览器才需要）：pip install {pip_name} && playwright install chromium")

    # 2. 配置完整性 + 凭证格式（凭证复制被截断是最高频的失败原因）
    f = cfg["feishu"]
    for key in ("app_token", "table_id"):
        if not str(f.get(key, "")).strip():
            problems.append(f"feishu.{key} 未填写")
    # v1.5.0：没配自建应用凭证不再是硬错误——本机登过 lark-cli 就能自动回退到用户身份
    missing_creds = [k for k in ("app_id", "app_secret") if not str(f.get(k, "")).strip()]
    cli_ready = FeishuBitable(cfg, verbose=False).cli_available
    auto_fb = bool(f.get("auto_cli_fallback", True))
    if missing_creds:
        if cli_ready and auto_fb:
            warnings.append(
                "feishu." + " / feishu.".join(missing_creds)
                + " 未填写；检测到 lark-cli，将自动使用其登录身份读写飞书"
            )
        else:
            problems.extend(f"feishu.{k} 未填写" for k in missing_creds)
    problems += credential_problems(cfg)
    if not str(f.get("view_id", "")).strip():
        warnings.append("feishu.view_id 未填写，将用表的默认顺序而非视图排序")
    for role in ("title", "body", "images"):
        if not str(cfg["fields"].get(role, "")).strip():
            problems.append(f"fields.{role} 未填写")
    print(f"  [{'ok' if not problems else 'x'}] 配置字段完整性")

    if cli_ready:
        print(f"  [i] 已检测到 lark-cli；OpenAPI 权限不足时自动回退（auto_cli_fallback={auto_fb}）")

    mode = cfg.get("mode", "assist")
    print(f"  [i] 发布模式: {mode}")
    if mode == "auto":
        warnings.append("当前为 auto 模式（自动点发布），触碰小红书 AI 托管红线，建议改回 assist")

    # 3. 飞书连通性 + 字段校验
    if not any("feishu." in p for p in problems):
        source = FeishuBitable(cfg, verbose=False)
        try:
            fields = source.list_fields()
            names = {str(x.get("field_name", "")) for x in fields}
            print(f"  [ok] 飞书连通（通道 {source._last_channel}），读取到 {len(fields)} 个字段")
            for role, label in (("title", "标题"), ("body", "正文"), ("images", "配图"),
                                ("topics", "话题"), ("status", "状态")):
                name = str(cfg["fields"].get(role, "")).strip()
                if not name:
                    continue
                if name in names:
                    print(f"  [ok] {label}字段「{name}」存在")
                else:
                    problems.append(f"{label}字段「{name}」在表里不存在，实际字段：{sorted(names)}")
        except FeishuError as exc:
            problems.append(f"飞书连接失败：{exc}")
        else:
            _check_status_options(cfg, source, problems, warnings)

    # 4. 目录可写
    try:
        wd = workdir_of(cfg)
        (wd / ".write_test").touch()
        (wd / ".write_test").unlink()
        print(f"  [ok] 工作目录可写：{wd}")
    except OSError as exc:
        problems.append(f"工作目录不可写：{exc}")

    # 5. 登录态
    profile = SKILL_ROOT / str(cfg["paths"]["browser_profile"])
    if profile.exists() and any(profile.iterdir()):
        print(f"  [ok] 已存在浏览器登录态目录：{profile}")
    else:
        warnings.append("还没有小红书登录态，首次 publish 时会弹窗让你扫码")

    print()
    for w in warnings:
        print(f"[warn] {w}")
    if problems:
        print()
        for p in problems:
            print(f"[x] {p}")
        return 1
    print("[ok] 体检全部通过，可以跑 publish 了")
    return 0


def cmd_fetch(args) -> int:
    cfg = load_config(args.config)
    source = FeishuBitable(cfg, verbose=not args.quiet)
    index = max(0, (args.index or 1) - 1)
    p = resolve_fetch_params(cfg, index=index, no_filter=args.no_filter)
    record = source.fetch_first_record(
        page_size=p["page_size"],
        include_field=p["include_field"],
        required_values=p["required_values"],
        skip_field=p["skip_field"],
        exclude_values=p["exclude_values"],
        sort_field_name=p["sort_field_name"],
        sort_order=p["sort_order"],
        index=p["index"],
    )
    if record is None:
        print(f"[x] 没有取到第 {index + 1} 条记录（{'(忽略筛选/排序) ' if args.no_filter else ''}可能行数不足）")
        return 1
    values = record.get("fields", {})
    print(f"记录 ID : {record.get('record_id')}")
    print(f"取数通道 : {source._last_channel}")
    for role, label in (("title", "标题"), ("body", "正文"), ("images", "配图"),
                        ("topics", "话题"), ("status", "状态")):
        name = str(cfg["fields"].get(role, "")).strip()
        if not name:
            continue
        if role == "images":
            atts = extract_attachments(values.get(name, ""))
            print(f"{label}     : {len(atts)} 个附件 -> {[a['name'] for a in atts]}")
        else:
            text = extract_text(values.get(name, "")).strip()
            preview = text if len(text) <= 120 else text[:120] + "…"
            print(f"{label}     : {preview}")
    return 0


def cmd_prepare(args) -> int:
    cfg = load_config(args.config)
    pkg, _source = fetch_package(
        cfg, verbose=not args.quiet,
        index=max(0, (args.index or 1) - 1),
        no_filter=args.no_filter,
    )
    draft = write_draft(pkg, workdir_of(cfg) / "draft")
    print("\n========== 草稿包 ==========", flush=True)
    print(pkg.summary(), flush=True)
    print(f"\n草稿文件: {draft}", flush=True)
    return 0


def cmd_login(args) -> int:
    """独立登录：只开浏览器等扫码，不取数、不发内容。登录态存到 browser_profile。"""
    cfg = load_config(args.config)
    from xhs_browser import BrowserError, XhsPublisher

    publisher = XhsPublisher(cfg, workdir_of(cfg), verbose=True)
    try:
        publisher.launch()
        publisher.open_publish_page()
        publisher.ensure_login()  # 内部会检测未登录 → 等扫码 → 保存
        print(f"\n[ok] 登录态已保存到 {SKILL_ROOT / cfg['paths']['browser_profile']}", flush=True)
        print("下次运行 publish 时无需再扫码。\n", flush=True)
        return 0
    except (BrowserError, KeyboardInterrupt) as exc:
        print(f"\n[x] 登录失败：{exc}", flush=True)
        return 1
    finally:
        publisher.close()


def cmd_mark(args) -> int:
    """单独回写飞书记录状态（不触发发布流程）。用于权限修复后补填状态。"""
    cfg = load_config(args.config)
    source = FeishuBitable(cfg, verbose=True)
    wb = cfg.get("writeback", {})
    status_field = str(cfg.get("fields", {}).get("status", "")).strip()
    if not status_field:
        print("[x] fields.status 未配置，无法回写状态", flush=True)
        return 1
    value = str(args.value or (wb.get("on_published") if args.published else wb.get("on_prefilled") or "已出版")).strip()
    payload: dict[str, Any] = {status_field: value}
    date_field = str(wb.get("published_at_field") or "").strip()
    if args.published and date_field:
        payload[date_field] = int(time.time() * 1000)
    try:
        source.update_record(args.record_id, payload)
        print(f"[ok] 已回写飞书记录 {args.record_id}：{status_field} = {value}", flush=True)
        return 0
    except FeishuError as exc:
        print(f"[x] 回写失败：{exc}", flush=True)
        return 1


def cmd_publish(args) -> int:
    cfg = load_config(args.config)
    mode = args.mode or cfg.get("mode", "assist")
    if mode == "auto" and not args.yes:
        confirm = input(
            "你选择了 auto 模式：脚本会代替你点「发布」。\n"
            "这与小红书 2026-07 治理公告的 AI 托管条款冲突，可能限流或封号。\n"
            "确认继续请输入「我承担风险」："
        ).strip()
        if confirm != "我承担风险":
            print("[i] 已取消。建议改用默认 assist 模式：python scripts/xhs_publish.py publish --mode assist")
            return 1
    return run_publish_core(
        cfg,
        index=max(0, (args.index or 1) - 1),
        no_filter=args.no_filter,
        mode=mode,
        dry_run=args.dry_run,
        verbose=not args.quiet,
    )


def run_publish_core(
    cfg: dict,
    index: int,
    no_filter: bool,
    mode: str,
    dry_run: bool,
    verbose: bool,
) -> int:
    """发布核心：取数 → 下载图 → 校验 → 预填 → 等你点发布 → 回写。

    publish / publish-link 两条命令共用，便于链接模式直接复用同一套流程。
    """
    pkg, source = fetch_package(cfg, verbose=verbose, index=index, no_filter=no_filter)
    print("\n========== 本次发布内容 ==========")
    print(pkg.summary())
    write_draft(pkg, workdir_of(cfg) / "draft")

    if dry_run:
        print("\n[i] dry-run 模式：跳过浏览器与回写")
        return 0

    if mode == "draft":
        write_back(cfg, source, pkg.record_id, published=False)
        print("\n[i] draft 模式：不开浏览器，图文已落到 draft/ 目录，请手动发布")
        return 0

    from xhs_browser import BrowserError, XhsPublisher

    publisher = XhsPublisher(cfg, workdir_of(cfg), verbose=verbose)
    published = False
    try:
        publisher.launch()
        publisher.open_publish_page()
        publisher.ensure_login()
        publisher.fill(pkg)
        if mode == "assist":
            published = publisher.wait_user_publish()
        else:
            published = publisher.click_publish()
    except BrowserError as exc:
        print(f"\n[x] 浏览器环节失败：{exc}")
        print("[i] 图文已保存在 draft/ 目录，可手动发布")
        return 1
    except KeyboardInterrupt:
        print("\n[i] 已中断")
        return 1
    finally:
        publisher.close()

    writeback_ok = write_back(cfg, source, pkg.record_id, published=published)
    if published:
        if writeback_ok:
            print(f"\n[ok] 发布完成，飞书记录 {pkg.record_id} 已回写状态「已发布」", flush=True)
        else:
            print(f"\n[warn] 发布已完成，但飞书状态回写失败（权限不足？详见上方）。", flush=True)
            print("     请到飞书手动把该记录标记为「已发布」，或修复应用权限后重跑：", flush=True)
            print(f"     python scripts/xhs_publish.py mark --record-id {pkg.record_id}\n", flush=True)
    else:
        print(f"\n[i] 未检测到发布成功。图文仍在 draft/ 目录，飞书记录 {pkg.record_id} 已标记为待发布")
    return 0


def cmd_fetch_link(args) -> int:
    """链接模式取数：给链接 + 行号，只取数打印，不碰浏览器。"""
    cfg = load_config(args.config)
    try:
        rt, coord = build_runtime_config(cfg, args.url, verbose=not args.quiet)
    except FeishuError as exc:
        print(f"\n[x] {exc}")
        return 1
    source = FeishuBitable(rt, verbose=not args.quiet)
    index = max(0, (args.index or 1) - 1)
    p = resolve_fetch_params(rt, index=index, no_filter=True)
    record = source.fetch_first_record(
        page_size=p["page_size"],
        include_field=p["include_field"],
        required_values=p["required_values"],
        skip_field=p["skip_field"],
        exclude_values=p["exclude_values"],
        sort_field_name=p["sort_field_name"],
        sort_order=p["sort_order"],
        index=p["index"],
    )
    if record is None:
        print(f"[x] 该链接对应表没有第 {index + 1} 行（可能行数不足）")
        return 1
    values = record.get("fields", {})
    print(f"记录 ID : {record.get('record_id')}")
    for role, label in (("title", "标题"), ("body", "正文"), ("images", "配图"),
                        ("topics", "话题"), ("status", "状态")):
        name = str(rt["fields"].get(role, "")).strip()
        if not name:
            continue
        if role == "images":
            atts = extract_attachments(values.get(name, ""))
            print(f"{label}     : {len(atts)} 个附件 -> {[a['name'] for a in atts]}")
        else:
            text = extract_text(values.get(name, "")).strip()
            preview = text if len(text) <= 120 else text[:120] + "…"
            print(f"{label}     : {preview}")
    return 0


def cmd_publish_link(args) -> int:
    """链接一键发布：给飞书链接 + 第几行，直接跑预填→等你点发布。

    默认按「表格/视图原始行序」取第 N 行（no_filter=True），贴合「明确第几行」的字面语义。
    """
    cfg = load_config(args.config)
    try:
        rt, coord = build_runtime_config(cfg, args.url, verbose=not args.quiet)
    except FeishuError as exc:
        print(f"\n[x] 链接解析/校验失败：{exc}")
        return 1
    mode = args.mode or cfg.get("mode", "assist")
    if mode == "auto" and not args.yes:
        confirm = input(
            "你选择了 auto 模式：脚本会代替你点「发布」。\n"
            "这与小红书 2026-07 治理公告的 AI 托管条款冲突，可能限流或封号。\n"
            "确认继续请输入「我承担风险」："
        ).strip()
        if confirm != "我承担风险":
            print("[i] 已取消。建议改用默认 assist 模式（预填后真人点发布）。")
            return 1
    print(f"\n>>> 目标：第 {args.index or 1} 行（按原始行序，忽略筛选/排序）")
    return run_publish_core(
        rt,
        index=max(0, (args.index or 1) - 1),
        no_filter=True,
        mode=mode,
        dry_run=args.dry_run,
        verbose=not args.quiet,
    )


# ---------- CLI ----------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="xhs_publish",
        description="飞书多维表格 → 小红书 半自动发布",
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help="配置文件路径")
    parser.add_argument("--quiet", action="store_true", help="减少输出")
    sub = parser.add_subparsers(dest="command", required=True)

    p_setup = sub.add_parser("setup", help="解析表格链接并生成配置")
    p_setup.add_argument("--url", help="飞书多维表格链接")
    p_setup.set_defaults(func=cmd_setup)

    p_check = sub.add_parser("check", help="体检：凭证/依赖/连通性/字段/登录态")
    p_check.set_defaults(func=cmd_check)

    p_fetch = sub.add_parser("fetch", help="只取第一条记录并打印")
    p_fetch.add_argument("--index", type=int, default=1, help="取第几条（1-based，默认 1=第一条）")
    p_fetch.add_argument("--no-filter", action="store_true", help="忽略筛选/排序，按表/视图原始行序取")
    p_fetch.set_defaults(func=cmd_fetch)

    p_prep = sub.add_parser("prepare", help="取数+下载配图+产出草稿包")
    p_prep.add_argument("--index", type=int, default=1, help="取第几条（1-based，默认 1=第一条）")
    p_prep.add_argument("--no-filter", action="store_true", help="忽略筛选/排序，按表/视图原始行序取")
    p_prep.set_defaults(func=cmd_prepare)

    sub.add_parser("login", help="独立登录：只开浏览器等扫码，保存登录态").set_defaults(func=cmd_login)

    p_mark = sub.add_parser("mark", help="单独回写飞书记录状态（不触发发布）")
    p_mark.add_argument("--record-id", required=True, help="要回写的记录 ID")
    p_mark.add_argument("--value", default="", help="状态值（默认取 writeback.on_published 或「已发布」）")
    p_mark.add_argument("--published", action="store_true", default=True, help="标记为已发布（默认）")
    p_mark.set_defaults(func=cmd_mark)

    p_pub = sub.add_parser("publish", help="全流程：预填后等你点发布")
    p_pub.add_argument("--mode", choices=["assist", "draft", "auto"], help="覆盖配置里的模式")
    p_pub.add_argument("--dry-run", action="store_true", help="取数和校验照做，不开浏览器不回写")
    p_pub.add_argument("--yes", action="store_true", help="auto 模式跳过风险确认（不推荐）")
    p_pub.add_argument("--index", type=int, default=1, help="取第几条（1-based，默认 1=第一条）")
    p_pub.add_argument("--no-filter", action="store_true", help="忽略筛选/排序，按表/视图原始行序取第 N 行")
    p_pub.set_defaults(func=cmd_publish)

    p_fl = sub.add_parser("fetch-link", help="（免改配置）给飞书链接+行号，只预演取数")
    p_fl.add_argument("--url", required=True, help="飞书多维表格链接（/base/ 开头，含 table=）")
    p_fl.add_argument("--index", type=int, default=1, help="取第几行（1-based，按原始行序）")
    p_fl.set_defaults(func=cmd_fetch_link)

    p_pl = sub.add_parser("publish-link", help="（免改配置）给飞书链接+行号直接发布")
    p_pl.add_argument("--url", required=True, help="飞书多维表格链接（/base/ 开头，含 table=）")
    p_pl.add_argument("--index", type=int, default=1, help="取第几行（1-based，按原始行序）")
    p_pl.add_argument("--mode", choices=["assist", "draft", "auto"], help="覆盖配置里的模式（默认 assist）")
    p_pl.add_argument("--dry-run", action="store_true", help="取数和校验照做，不开浏览器不回写")
    p_pl.add_argument("--yes", action="store_true", help="auto 模式跳过风险确认（不推荐）")
    p_pl.set_defaults(func=cmd_publish_link)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        return int(args.func(args))
    except (FeishuError, PackageError) as exc:
        print(f"\n[x] {exc}")
        return 1
    except KeyboardInterrupt:
        print("\n[i] 已取消")
        return 1
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001 - 兜底，保证给出可排查的信息
        print("\n[x] 未预期的错误：")
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    print(f"[i] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} 技能根：{SKILL_ROOT}", flush=True)
    sys.exit(main())
