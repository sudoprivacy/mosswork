#!/usr/bin/env bash
# 飞书表格 → 小红书 半自动发布 · 安装脚本（macOS / Linux）
# 用法：在解压后的技能目录里执行  bash install.sh
set -euo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_NAME="$(basename "$SELF_DIR")"
DEST="$HOME/.workbuddy/skills/$SKILL_NAME"

echo "== 安装技能：$SKILL_NAME =="
echo "源目录 : $SELF_DIR"
echo "目标目录: $DEST"

mkdir -p "$DEST"

# 复制全部文件，排除本机运行时产物
EXCLUDES=( ".xhs_work" ".xhs_browser_profile" "__pycache__" ".pytest_cache" ".git" "dist" )
EXCL_ARGS=()
for e in "${EXCLUDES[@]}"; do
  EXCL_ARGS+=( --exclude="$e" )
done

if command -v rsync >/dev/null 2>&1; then
  rsync -a "${EXCL_ARGS[@]}" "$SELF_DIR/" "$DEST/"
else
  # 退而用 cp：先整目录复制，再删运行时产物
  cp -R "$SELF_DIR/." "$DEST/"
  for e in "${EXCLUDES[@]}"; do
    rm -rf "$DEST/$e"
  done
fi

echo "[ok] 技能文件已就位"

# 安装 Python 依赖
PY=$(command -v python3 || command -v python || true)
if [ -z "$PY" ]; then
  echo "[warn] 没找到 python3，请手动安装依赖：pip install requests PyYAML playwright && playwright install chromium"
else
  echo "== 安装依赖（可能需输入密码）=="
  "$PY" -m pip install --user requests PyYAML playwright 2>&1 | tail -3 || \
    "$PY" -m pip install requests PyYAML playwright 2>&1 | tail -3
  "$PY" -m playwright install chromium 2>&1 | tail -3 || echo "[warn] playwright 浏览器下载失败，稍后手动执行：python -m playwright install chromium"
  echo "[ok] 依赖安装完成"
fi

echo
echo "==================== 安装完成 ===================="
echo "下一步（只需做一次）："
echo "  1) 去飞书开放平台(open.feishu.cn)建一个企业自建应用，开通 bitable:app、drive:media 权限，发布并把它加为你的多维表格「可编辑」协作者"
echo "  2) 在技能目录执行："
echo "       python3 scripts/xhs_publish.py setup --url '<你的飞书多维表格链接>'"
echo "  3) 体检："
echo "       python3 scripts/xhs_publish.py check"
echo "  4) 发第一篇："
echo "       python3 scripts/xhs_publish.py publish"
echo "==================================================="
