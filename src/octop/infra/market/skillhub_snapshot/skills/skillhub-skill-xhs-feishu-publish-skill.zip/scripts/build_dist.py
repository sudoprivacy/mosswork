#!/usr/bin/env python3
"""把技能导出一个「可分享/可安装」的干净压缩包。

关键安全点：
- 不把真实的 config.yaml（含飞书 App Secret）打进包，改用 config.example.yaml 当占位。
- 排除运行时产物（.xhs_work、.xhs_browser_profile、__pycache__、.pytest_cache）。

用法：
    python scripts/build_dist.py
产物：  dist/xhs-feishu-publish-skill-<version>.zip
"""
from __future__ import annotations

import shutil
import sys
import zipfile
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent

# 这些目录/文件属于本机运行时产物，绝不进包
EXCLUDE_DIRS = {
    ".xhs_work",
    ".xhs_browser_profile",
    "__pycache__",
    ".pytest_cache",
    ".git",
    "dist",  # 打包产物本身，避免 zip 里再嵌套一份自己
    ".dist_stage",  # 打包临时组装目录，防止重复打包时被卷进包
}
# 额外要排除的散文件模式（按文件名后缀/名字）
EXCLUDE_FILES = {
    ".write_test",
    ".DS_Store",
    "Thumbs.db",
    # 开发期抓取诊断脚本（写死调试 URL，非用户功能），不进发版包
    "sync_explore_state.py",
}


def _load_version() -> str:
    md = SKILL_ROOT / "SKILL.md"
    if md.exists():
        for line in md.read_text(encoding="utf-8").splitlines():
            if line.lower().startswith("version:"):
                return line.split(":", 1)[1].strip()
    return "0.0.0"


def _should_skip(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    parts = set(rel.parts)
    if parts & EXCLUDE_DIRS:
        return True
    if path.name in EXCLUDE_FILES:
        return True
    if path.suffix in {".pyc"}:
        return True
    if path.name.endswith(".bak") or ".bak." in path.name:
        return True
    return False


def build() -> Path:
    version = _load_version()
    out_dir = SKILL_ROOT / "dist"
    out_dir.mkdir(exist_ok=True)
    # 包内顶层目录与技能目录同名，方便收包人直接解压进 skills/
    zip_name = f"xhs-feishu-publish-skill-{version}.zip"
    zip_path = out_dir / zip_name

    # 用临时目录组装：把 config.example.yaml 复制成 config.yaml 占位（无密钥）
    stage = SKILL_ROOT / ".dist_stage" / "xhs-feishu-publish-skill"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)

    copied = 0
    for src in sorted(SKILL_ROOT.rglob("*")):
        if src.is_dir():
            continue
        if _should_skip(src, SKILL_ROOT):
            continue
        rel = src.relative_to(SKILL_ROOT)
        dst = stage / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if rel == Path("config/config.yaml"):
            # 用空模板替代真实配置，杜绝密钥外泄
            shutil.copy(SKILL_ROOT / "config" / "config.example.yaml", dst)
        else:
            shutil.copy(src, dst)
        copied += 1

    if (stage / "config" / "config.yaml").exists() is False:
        # 兜底：连 example 都没有时复制一份空壳
        example = SKILL_ROOT / "config" / "config.example.yaml"
        if example.exists():
            (stage / "config").mkdir(parents=True, exist_ok=True)
            shutil.copy(example, stage / "config" / "config.yaml")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(stage.rglob("*")):
            if f.is_file():
                zf.write(f, f.relative_to(stage.parent))

    # 清理临时目录
    shutil.rmtree(SKILL_ROOT / ".dist_stage")
    print(f"[ok] 已打包 {copied} 个文件 -> {zip_path}")
    print(f"[i] 包内 config.yaml 为占位模板（无飞书密钥）；收包人首次运行需执行 setup。")
    return zip_path


if __name__ == "__main__":
    try:
        p = build()
    except Exception as exc:  # noqa: BLE001
        print(f"[x] 打包失败：{exc}")
        sys.exit(1)
    sys.exit(0)
