#!/usr/bin/env python3
"""图片落地与笔记包组装：下载去重、硬性校验、产出可人工复核的草稿包。"""

from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}


class PackageError(RuntimeError):
    """笔记内容不满足小红书硬性限制，消息可直接给用户看。"""


@dataclass
class NotePackage:
    record_id: str = ""
    title: str = ""
    body: str = ""
    topics: list[str] = field(default_factory=list)
    image_paths: list[Path] = field(default_factory=list)
    raw_fields: dict = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            f"记录 ID : {self.record_id or '-'}",
            f"标题    : {self.title}（{len(self.title)} 字）",
            f"正文    : {len(self.body)} 字",
            f"配图    : {len(self.image_paths)} 张",
            f"话题    : {'、'.join(self.topics) if self.topics else '（无）'}",
        ]
        if self.image_paths:
            lines.append("图片路径:")
            lines += [f"  - {p}" for p in self.image_paths]
        return "\n".join(lines)


def prepare_image_dir(images_dir: Path) -> Path:
    """确保图片目录存在（仅创建，绝不删除）。

    每个记录用独立子目录（调用方传入 record_id 子目录），天然隔离——
    既避免「上一轮的图片混进本次发布」，也不会触发沙箱的批量删除保护钩子
    （shutil.rmtree 整目录清空气在文件多时会被一次性拦截，导致后台任务直接挂掉）。
    """
    images_dir.mkdir(parents=True, exist_ok=True)
    return images_dir


def prune_stale_image_dirs(images_root: Path, keep: str) -> None:
    """删除非当前记录的历史图片子目录，给磁盘封顶。

    每个子目录只装一条记录的配图（≤ image_max 张），rmtree 单个目录远不到
    批量删除阈值，安全。清理只删「整目录」，不碰当前记录目录。
    """
    if not images_root.exists():
        return
    keep_name = keep or "default"
    for child in images_root.iterdir():
        if child.is_dir() and child.name != keep_name:
            try:
                shutil.rmtree(child)
            except OSError:
                pass


def validate_images(paths: list[Path], limits: dict) -> list[Path]:
    """校验图片数量、大小、格式，并去掉重复文件（同一张图被重复上传很显眼）。"""
    max_count = int(limits.get("image_max", 18))
    max_mb = float(limits.get("image_size_mb", 32))

    kept: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        if not path.exists():
            raise PackageError(f"图片不存在：{path}")
        if path.suffix.lower() not in ALLOWED_EXT:
            raise PackageError(f"不支持的图片格式 {path.suffix}：{path.name}（支持 jpg/png/webp/gif/bmp）")
        size_mb = path.stat().st_size / 1024 / 1024
        if size_mb > max_mb:
            raise PackageError(f"图片 {path.name} 超过 {max_mb}MB（实际 {size_mb:.1f}MB）")
        digest = _file_digest(path)
        if digest in seen:
            continue
        seen.add(digest)
        kept.append(path)

    if not kept:
        raise PackageError("该记录没有可用配图，小红书图文笔记至少需要 1 张")
    if len(kept) > max_count:
        raise PackageError(f"配图 {len(kept)} 张，超过上限 {max_count} 张")
    return kept


def validate_text(pkg: NotePackage, limits: dict) -> None:
    title_max = int(limits.get("title_max", 20))
    body_max = int(limits.get("body_max", 1000))
    topic_max = int(limits.get("topic_max", 10))
    if not pkg.title.strip():
        raise PackageError("标题为空，无法发布")
    if len(pkg.title) > title_max:
        raise PackageError(f"标题 {len(pkg.title)} 字，超过上限 {title_max} 字")
    if not pkg.body.strip():
        raise PackageError("正文为空，无法发布")
    if len(pkg.body) > body_max:
        raise PackageError(f"正文 {len(pkg.body)} 字，超过上限 {body_max} 字")
    if len(pkg.topics) > topic_max:
        raise PackageError(f"话题 {len(pkg.topics)} 个，超过上限 {topic_max} 个")


def normalize_topics(raw: str, topic_max: int = 10) -> list[str]:
    """把「#a #b」或「a,b」或「a b」统一成不带 # 的话题列表。"""
    if not raw:
        return []
    text = raw.replace("，", ",").replace("、", ",").replace("；", ",")
    parts: list[str] = []
    for chunk in text.replace("#", " ").split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        for word in chunk.split():
            word = word.strip().lstrip("#")
            if word and word not in parts:
                parts.append(word)
    return parts[:topic_max]


def write_draft(pkg: NotePackage, draft_dir: Path) -> Path:
    """把笔记落成人类可读的草稿包，draft 模式与失败排查都靠它。"""
    draft_dir.mkdir(parents=True, exist_ok=True)
    md_path = draft_dir / "note.md"
    body = [
        f"# {pkg.title}",
        "",
        pkg.body,
        "",
    ]
    if pkg.topics:
        body.append(" ".join(f"#{t}" for t in pkg.topics))
        body.append("")
    body.append("---")
    body.append(f"- 记录 ID: {pkg.record_id}")
    body.append(f"- 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    body.append(f"- 配图 {len(pkg.image_paths)} 张:")
    body += [f"  - {p.name}" for p in pkg.image_paths]
    md_path.write_text("\n".join(body), encoding="utf-8")

    meta_path = draft_dir / "note.json"
    meta_path.write_text(
        json.dumps(
            {
                "record_id": pkg.record_id,
                "title": pkg.title,
                "body": pkg.body,
                "topics": pkg.topics,
                "images": [str(p) for p in pkg.image_paths],
                "generated_at": datetime.now().isoformat(timespec="seconds"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return md_path


def _file_digest(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            block = fh.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()
