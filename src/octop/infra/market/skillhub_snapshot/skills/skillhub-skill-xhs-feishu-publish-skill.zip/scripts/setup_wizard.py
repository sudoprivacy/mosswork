#!/usr/bin/env python3
"""配置向导：解析飞书表格链接 → 探测字段角色 → 生成 config.yaml。

生成配置时保留 config.example.yaml 里的注释，方便后续手改。
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path

from feishu_source import FeishuBitable, FeishuError

# 字段角色 → 命中关键词（小写比较，越靠前优先级越高）
ROLE_KEYWORDS: dict[str, list[str]] = {
    "title": ["标题", "题目", "笔记标题", "title", "headline"],
    "body": ["正文", "笔记内容", "文案", "内容", "body", "content", "desc"],
    "images": ["图片", "配图", "封面", "素材图", "image", "images", "img", "photo", "picture"],
    "topics": ["话题", "标签", "关键词", "topic", "topics", "tag", "tags"],
    "status": ["发布状态", "状态", "status", "publish", "推送状态"],
}

def parse_bitable_url(url: str) -> dict[str, str]:
    """从飞书多维表格链接里抠出 app_token / table_id / view_id。

    支持形如：
      https://xxx.feishu.cn/base/bascnXXXX?table=tblYYYY&view=vewZZZZ
      https://xxx.feishu.cn/base/bascnXXXX?table=tblYYYY
    """
    url = (url or "").strip()
    if not url:
        raise ValueError("链接为空")
    if "/wiki/" in url:
        raise ValueError(
            "这是知识库 wiki 链接，wiki 节点的真实 app_token 需要接口换算。\n"
            "请在浏览器打开该表格，地址栏会跳转到 /base/ 开头的链接，复制那个链接再来。"
        )
    token_match = re.search(r"/base/([A-Za-z0-9_\-]+)", url)
    if not token_match:
        raise ValueError("没找到 /base/<app_token> 这段，请确认复制的是多维表格链接")
    result = {"app_token": token_match.group(1), "table_id": "", "view_id": ""}
    table = re.search(r"[?&]table=([A-Za-z0-9_\-]+)", url)
    if table:
        result["table_id"] = table.group(1)
    view = re.search(r"[?&]view=([A-Za-z0-9_\-]+)", url)
    if view:
        result["view_id"] = view.group(1)
    return result


def detect_roles(fields: list[dict]) -> dict[str, str]:
    """按字段名猜角色：先精确相等，再包含匹配，取优先级最高的关键词。"""
    found: dict[str, tuple[int, str]] = {}
    for field in fields:
        name = str(field.get("field_name", "")).strip()
        lowered = name.lower()
        if not name:
            continue
        for role, keywords in ROLE_KEYWORDS.items():
            if not keywords:
                continue
            for rank, kw in enumerate(keywords):
                hit = (lowered == kw.lower()) or (kw.lower() in lowered)
                if hit:
                    score = rank if lowered == kw.lower() else rank + 10
                    if role not in found or score < found[role][0]:
                        found[role] = (score, name)
                    break
    return {role: name for role, (_, name) in found.items()}


def _fmt_value(value) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value).replace("\\", "\\\\").replace('"', '\\"')
    return f'"{text}"'


def _set_value(lines: list[str], section: str, key: str, value) -> bool:
    """在指定 section 下替换 2 空格缩进的 key 值，保留注释。"""
    in_section = False
    pattern = re.compile(rf"^\s{{2}}{re.escape(key)}\s*:")
    for idx, line in enumerate(lines):
        stripped = line.rstrip("\n")
        if re.match(r"^[A-Za-z_][A-Za-z0-9_]*\s*:", stripped):
            in_section = stripped.split(":", 1)[0].strip() == section
            continue
        if in_section and pattern.match(stripped):
            lines[idx] = f"  {key}: {_fmt_value(value)}\n"
            return True
    return False


def render_config(example_path: Path, updates: dict[tuple[str, str], object]) -> str:
    lines = example_path.read_text(encoding="utf-8").splitlines(keepends=True)
    missed = []
    for (section, key), value in updates.items():
        if not _set_value(lines, section, key, value):
            missed.append(f"{section}.{key}")
    if missed:
        raise RuntimeError(f"配置模板中找不到这些键：{', '.join(missed)}（模板可能被改过）")
    return "".join(lines)


def run_setup(cfg: dict, skill_root: Path, url: str | None, verbose: bool = True) -> Path:
    coord = parse_bitable_url(url) if url else {"app_token": "", "table_id": "", "view_id": ""}
    if not url:
        print("把飞书多维表格链接贴进来（浏览器地址栏，/base/ 开头）：")
        url = input("> ").strip()
        coord = parse_bitable_url(url)

    merged = dict(cfg.get("feishu", {}))
    merged.update({k: v for k, v in coord.items() if v})
    if not merged.get("app_id"):
        print("飞书自建应用 App ID（cli_ 开头；没有就去 open.feishu.cn 创建）：")
        merged["app_id"] = input("> ").strip()
    if not merged.get("app_secret"):
        try:
            import getpass

            merged["app_secret"] = getpass.getpass("App Secret（输入不回显）：").strip()
        except Exception:  # noqa: BLE001 - 非交互环境退回明文输入
            merged["app_secret"] = input("App Secret：").strip()

    probe_cfg = {"feishu": merged}
    source = FeishuBitable(probe_cfg, verbose=verbose)

    # 链接里没带 table= 时，列出所有表让用户挑
    if not merged.get("table_id"):
        try:
            merged["table_id"] = pick_table(source)
            source.table_id = merged["table_id"]
        except FeishuError as exc:
            raise SystemExit(f"[x] 读取数据表列表失败：{exc}")
    # 同理，没带 view= 时列出视图让用户挑
    if not merged.get("view_id"):
        try:
            merged["view_id"] = pick_view(source)
        except FeishuError as exc:
            print(f"[warn] 读取视图列表失败（{exc}），将使用表默认顺序")
            merged["view_id"] = ""

    print(f"\n正在读取字段结构（通道：{'lark-cli' if source.cli_available and merged.get('prefer_cli') else 'OpenAPI'}）…")
    try:
        fields = source.list_fields()
    except FeishuError as exc:
        raise SystemExit(
            f"[x] 读取字段失败：{exc}\n\n"
            "常见原因：\n"
            "  1. 应用没被加为表格协作者（打开表格 → 分享 → 邀请该应用）\n"
            "  2. 应用没开通 bitable:app 权限，或权限未发布生效\n"
            "  3. app_id / app_secret 填错\n"
            "  4. table_id 填错（链接里 table= 参数）"
        )
    if not fields:
        raise SystemExit("[x] 该表没有任何字段，请确认 table_id 是否正确")

    print(f"\n发现 {len(fields)} 个字段：")
    for field in fields:
        print(f"  - {field['field_name']}  (type={field.get('type')})")

    roles = detect_roles(fields)
    print("\n字段角色自动识别结果：")
    for role, label in (("title", "标题"), ("body", "正文"), ("images", "配图"), ("topics", "话题"), ("status", "状态")):
        print(f"  {label}: {roles.get(role, '（未识别）')}")

    print("\n直接回车=采用以上结果；要改就输入正确的字段名（留空表示该角色不用）。")
    for role, label in (("title", "标题"), ("body", "正文"), ("images", "配图"), ("topics", "话题"), ("status", "状态")):
        current = roles.get(role, "")
        typed = input(f"{label}字段 [{current or '无'}] > ").strip()
        if typed == "-":
            roles.pop(role, None)
        elif typed:
            roles[role] = typed

    if not roles.get("title") or not roles.get("body") or not roles.get("images"):
        raise SystemExit("[x] 标题、正文、配图三个字段缺一不可，配置中止")

    status_field = roles.get("status", "")
    updates: dict[tuple[str, str], object] = {
        ("feishu", "app_id"): merged.get("app_id", ""),
        ("feishu", "app_secret"): merged.get("app_secret", ""),
        ("feishu", "app_token"): merged.get("app_token", ""),
        ("feishu", "table_id"): merged.get("table_id", ""),
        ("feishu", "view_id"): merged.get("view_id", ""),
        ("fields", "title"): roles.get("title", ""),
        ("fields", "body"): roles.get("body", ""),
        ("fields", "images"): roles.get("images", ""),
        ("fields", "topics"): roles.get("topics", ""),
        ("fields", "status"): status_field,
        ("filter", "status_field"): status_field or "状态",
        ("writeback", "enabled"): bool(status_field),
    }

    example = skill_root / "config" / "config.example.yaml"
    target = skill_root / "config" / "config.yaml"
    if target.exists():
        backup = target.with_suffix(f".bak.{_stamp()}")
        shutil.copy(target, backup)
        print(f"[i] 已备份旧配置到 {backup.name}")
    target.write_text(render_config(example, updates), encoding="utf-8")
    print(f"\n[ok] 配置已写入 {target}")
    print("下一步：python scripts/xhs_publish.py check")
    return target


def pick_table(source: FeishuBitable) -> str:
    """让用户从数据表列表里选一张，只有一张时自动选。"""
    tables = source.list_tables()
    if not tables:
        raise SystemExit("[x] 这个多维表格里没有任何数据表")
    if len(tables) == 1:
        print(f"\n只有一张数据表，自动选择：{tables[0]['name']}（{tables[0]['table_id']}）")
        return tables[0]["table_id"]
    print("\n这个多维表格里有这些数据：")
    for idx, table in enumerate(tables, 1):
        print(f"  {idx}. {table['name']}  ({table['table_id']})")
    while True:
        typed = input("用哪张表？输入序号 > ").strip()
        if typed.isdigit() and 1 <= int(typed) <= len(tables):
            return tables[int(typed) - 1]["table_id"]
        print(f"  请输入 1 到 {len(tables)} 之间的数字")


def pick_view(source: FeishuBitable) -> str:
    """让用户选视图——「排序第一条」取哪条，完全由这里的选择决定。"""
    views = source.list_views()
    if not views:
        print("\n[i] 该表没有视图，将使用表的默认顺序")
        return ""
    print("\n视图列表（决定「排序第一条」到底取哪一条）：")
    for idx, view in enumerate(views, 1):
        print(f"  {idx}. {view['name']}  ({view['view_id']})")
    typed = input("用哪个视图？输入序号，直接回车=用表默认顺序 > ").strip()
    if not typed:
        return ""
    if typed.isdigit() and 1 <= int(typed) <= len(views):
        return views[int(typed) - 1]["view_id"]
    print("[warn] 输入无效，改用表默认顺序")
    return ""


def _stamp() -> str:
    from datetime import datetime

    return datetime.now().strftime("%Y%m%d%H%M%S")
