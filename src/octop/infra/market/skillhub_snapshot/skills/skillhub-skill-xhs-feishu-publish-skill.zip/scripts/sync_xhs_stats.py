"""同步小红书笔记数据到飞书多维表格「数据库」表。
用法: python scripts/sync_xhs_stats.py [URL]
流程: 打开笔记页 → 未登录则等扫码 → 登录后提取标题/点赞/收藏/评论/阅读 → 写入飞书

安全约定（分享版）：
- 飞书凭证（app_id/secret/app_token）与目标表 ID 全部来自 config/config.yaml，**绝不写死在代码里**。
- 路径基于本脚本位置计算，可移植到任意机器。
- 阅读量仅本人可见、登录态可取到时才填；公开页取不到则留空。
- 抓取逻辑已修正：锁定主笔记容器，避免误抓页面底部推荐流里别的笔记的大数字。
"""
from __future__ import annotations

import sys
import time
import json
import re
import argparse
import urllib.request
from pathlib import Path

import yaml
from playwright.sync_api import sync_playwright

# ── 路径（相对本文件，便携式，不写死机器）────────────────────
SKILL = Path(__file__).resolve().parent.parent
CONFIG_PATH = SKILL / "config" / "config.yaml"

# 以下运行时由 apply_config() 从 config.yaml 填充（凭证绝不写死在代码里）
APP_ID = APP_SECRET = APP_TOKEN = TABLE_ID = ""
FIELD_NAMES = {"title": "标题", "reads": "阅读", "likes": "点赞", "collects": "收藏", "comments": "评论"}
PROFILE = SKILL / ".xhs_browser_profile"
SHOT_DIR = SKILL / ".xhs_work" / "screenshots"
LOGIN_WAIT = 600
DEFAULT_URL = ""  # 建议在 config.yaml 的 sync.default_note_url 里设你常用的笔记链接

# 飞书 Bitable 字段类型：type=1 文本, type=2 数字, type=3 单选, type=7 复选框
# ⚠️ type=7 是复选框不是数字！数字必须用 type=2


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        raise SystemExit(
            f"[x] 找不到配置 {CONFIG_PATH}\n"
            f"    请先运行: python scripts/xhs_publish.py setup --url '<你的飞书表格链接>'"
        )
    with CONFIG_PATH.open(encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def apply_config(url_override: str | None = None) -> str:
    """读取配置并填充模块级凭证/路径/字段名，返回最终要抓取的 URL。"""
    cfg = load_config()
    f = cfg.get("feishu", {}) or {}
    sync = cfg.get("sync", {}) or {}
    paths = cfg.get("paths", {}) or {}

    global APP_ID, APP_SECRET, APP_TOKEN, TABLE_ID, PROFILE, SHOT_DIR, FIELD_NAMES
    APP_ID = (f.get("app_id") or "").strip()
    APP_SECRET = (f.get("app_secret") or "").strip()
    APP_TOKEN = (f.get("app_token") or "").strip()
    # 同步目标表优先用 sync.table_id；未设则复用发布表 feishu.table_id
    TABLE_ID = (sync.get("table_id") or f.get("table_id") or "").strip()

    if url_override:
        target_url = url_override
    else:
        target_url = (sync.get("default_note_url") or "").strip() or DEFAULT_URL

    PROFILE = SKILL / paths.get("browser_profile", ".xhs_browser_profile")
    SHOT_DIR = SKILL / paths.get("workdir", ".xhs_work") / "screenshots"
    SHOT_DIR.mkdir(parents=True, exist_ok=True)

    fc = sync.get("fields", {}) or {}
    FIELD_NAMES = {
        "title": fc.get("title", "标题"),
        "reads": fc.get("reads", "阅读"),
        "likes": fc.get("likes", "点赞"),
        "collects": fc.get("collects", "收藏"),
        "comments": fc.get("comments", "评论"),
    }
    return target_url


def require_credentials() -> None:
    missing = [
        n for n, v in (
            ("feishu.app_id", APP_ID),
            ("feishu.app_secret", APP_SECRET),
            ("feishu.app_token", APP_TOKEN),
            ("sync.table_id / feishu.table_id", TABLE_ID),
        ) if not v
    ]
    if missing:
        raise SystemExit(
            f"[x] 配置缺少: {', '.join(missing)}\n"
            f"    请编辑 config/config.yaml 填写飞书凭证与同步目标表（sync.table_id）。"
        )


# ── 登录检测 ──────────────────────────────────────────────

def is_login_required(page) -> bool:
    for sel in (
        'text=手机号登录', 'text=扫码登录', 'text=可用小红书或微信扫码',
        'input[placeholder*="手机"]', '.login-container', '#login',
    ):
        try:
            loc = page.locator(sel)
            if loc.count() > 0 and loc.first.is_visible():
                return True
        except Exception:
            continue
    return False


def wait_for_login(page) -> None:
    print("\n========== 需要登录 ==========", flush=True)
    print("请在弹出的浏览器窗口中用小红书 App 扫码登录。", flush=True)
    print(f"登录后自动继续（最多 {LOGIN_WAIT // 60} 分钟）。\n", flush=True)
    deadline = time.time() + LOGIN_WAIT
    while time.time() < deadline:
        time.sleep(2)
        if not is_login_required(page):
            time.sleep(3)
            print("[ok] 登录成功\n", flush=True)
            return
    raise TimeoutError("等待扫码超时")


# ── 数据提取 ──────────────────────────────────────────────

def _extract_number(text: str) -> int | None:
    """'1.2万'→12000, '356'→356."""
    if not text:
        return None
    t = text.strip().replace(",", "").replace(" ", "")
    m = re.search(r"([\d.]+)\s*(万|w)?", t)
    if m:
        val = float(m.group(1))
        if m.group(2) in ("万", "w"):
            val *= 10000
        return int(val)
    try:
        return int(float(t))
    except (ValueError, TypeError):
        return None


def scrape_note_data(page) -> dict:
    """从已登录的笔记页提取标题与互动数据。

    关键修正（v1.2）：之前用「全页 span.count 盲抓」会误抓页面底部推荐流里
    别的笔记的大数字。主笔记互动量很低时，小红书把「1 个赞」显示成「赞」文字
    而非数字，于是回退逻辑抓到了推荐流。

    新逻辑：
      1. 优先从 window.__INITIAL_STATE__ 的主笔记对象读 counts（若有填充）
      2. 否则 DOM 兜底：先锁定「主笔记内容容器」（含标题 h1/.title 的 section），
         再在该容器内按「赞/收藏/评论」文字定位对应 wrapper 的数字
      3. 数字显示为文字（如「赞」）时，标记需人工核对，不臆造数值
    注意：阅读量仅当该笔记是本人发布、且登录态能看到时才可取；公开页取不到则留空。
    """
    js = r"""() => {
        const out = { likes:null, collects:null, comments:null, reads:null, _src:"none",
                     _dbg:{isi:null, wrappers:[], all_counts:[]} };

        // ---- 1) 试 __INITIAL_STATE__ 主笔记对象 ----
        try {
            const st = window.__INITIAL_STATE__;
            const noteMap = st?.note?.noteDetailMap || st?.note?.noteList || {};
            for (const v of Object.values(noteMap)) {
                const n = v?.note || v;
                if (n && (n.liked_count !== undefined || n.liked_count !== null)) {
                    out.likes = n.liked_count ?? null;
                    out.collects = n.collected_count ?? null;
                    out.comments = n.comment_count ?? null;
                    out.reads = n.view_count ?? n.read_count ?? null;
                    out._src = "initial_state";
                    out._dbg.isi = {liked:n.liked_count, collected:n.collected_count, comment:n.comment_count, view:n.view_count};
                    if (out.likes !== null || out.collects !== null) break;
                }
            }
        } catch(e) { out._dbg.isi_err = String(e); }

        if (out._src === "initial_state" && (out.likes !== null || out.collects !== null)) {
            return out;
        }

        // ---- 2) DOM 兜底：锁定主笔记容器 ----
        const titleEl = document.querySelector('.note-content .title') || document.querySelector('h1');
        const container = titleEl
            ? (titleEl.closest('section') || titleEl.closest('article') || titleEl.parentElement.parentElement)
            : document;

        // 互动栏容器：class 含 interact / action-bar / bottom
        const bar = container.querySelector('[class*="interact"]')
                 || container.querySelector('[class*="action-bar"]')
                 || container.querySelector('[class*="note-bottom"]')
                 || container.querySelector('[class*="toolbar"]');

        // 调试：收集主笔记容器内所有 span.count
        const allInContainer = Array.from(container.querySelectorAll('span.count')).map(s=>s.textContent.trim());
        out._dbg.all_counts = allInContainer.slice(0, 12);

        if (!bar) { out._src = "no_bar"; return out; }

        const wrappers = bar.querySelectorAll('div[class*="wrapper"], button[class*="wrapper"], [class*="like"], [class*="collect"], [class*="chat"]');
        const seen = {};
        for (const w of wrappers) {
            const txt = (w.textContent || "").trim();
            const countEl = w.querySelector('span.count');
            const numTxt = countEl ? countEl.textContent.trim() : null;
            out._dbg.wrappers.push(txt.slice(0, 12));
            const key = txt.includes("赞") ? "likes"
                      : txt.includes("收藏") ? "collects"
                      : txt.includes("评论") ? "comments"
                      : txt.includes("阅读") ? "reads" : null;
            if (!key || seen[key]) continue;
            seen[key] = true;
            // 数字显示为「赞」这类纯文字 -> 视为需人工核对，不写数值
            if (numTxt && /^[\d.,\s万wW]+$/.test(numTxt)) {
                out[key] = numTxt;
            } else {
                out[key] = "__NEED_CHECK__";  // 标记需人工核对
            }
        }
        out._src = "dom";
        return out;
    }"""

    raw = page.evaluate(js)

    title = re.sub(r"\s*[-–—]\s*小红书.*$", "", page.title()).strip()

    result = {"title": title, "reads": None, "likes": None, "collects": None, "comments": None}
    need_check = []
    for k in ("reads", "likes", "collects", "comments"):
        v = raw.get(k)
        if v == "__NEED_CHECK__":
            need_check.append(k)
        elif isinstance(v, str):
            result[k] = _extract_number(v)
        elif isinstance(v, (int, float)):
            result[k] = int(v)

    result["_debug"] = {
        "src": raw.get("_src"),
        "isi": raw.get("_dbg", {}).get("isi"),
        "wrappers": raw.get("_dbg", {}).get("wrappers"),
        "all_counts_in_container": raw.get("_dbg", {}).get("all_counts"),
        "need_check": need_check,
    }
    return result


# ── 飞书写入 ──────────────────────────────────────────────

def feishu_token():
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    req = urllib.request.Request(url, data=json.dumps({
        "app_id": APP_ID, "app_secret": APP_SECRET
    }).encode(), headers={"Content-Type": "application/json"})
    resp = json.loads(urllib.request.urlopen(req, timeout=20).read())
    if resp.get("code") != 0:
        raise RuntimeError(f"飞书 token 获取失败: {resp}")
    return resp["tenant_access_token"]


def feishu_create_record(token: str, fields: dict) -> str:
    """新增一条记录到「数据库」表，返回 record_id。
    注意：fields 的 key 必须是字段名（如"点赞"），不是 field_id。
    """
    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{APP_TOKEN}/tables/{TABLE_ID}/records"
    # 过滤掉 None 值（飞书数字字段不接受 null）
    payload = {"fields": {k: v for k, v in fields.items() if v is not None}}
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                                method="POST")
    resp = json.loads(urllib.request.urlopen(req, timeout=20).read())
    if resp.get("code") != 0:
        raise RuntimeError(f"飞书写入失败: code={resp.get('code')} msg={resp.get('msg')}")
    rec_id = resp["data"]["record"]["record_id"]
    print(f"[ok] 飞书记录已创建: {rec_id}", flush=True)
    return rec_id


def feishu_find_record_id_by_title(token: str, title: str):
    """按标题精确查找已存在记录，返回 record_id 或 None。"""
    url = (f"https://open.feishu.cn/open-apis/bitable/v1/apps/{APP_TOKEN}"
           f"/tables/{TABLE_ID}/records?page_size=50")
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    resp = json.loads(urllib.request.urlopen(req, timeout=20).read())
    for it in resp.get("data", {}).get("items", []):
        if it.get("fields", {}).get(FIELD_NAMES["title"]) == title:
            return it["record_id"]
    return None


def feishu_update_record(token: str, record_id: str, fields: dict) -> None:
    """更新已有记录（fields 为字段名->值，自动过滤 None）。"""
    url = (f"https://open.feishu.cn/open-apis/bitable/v1/apps/{APP_TOKEN}"
           f"/tables/{TABLE_ID}/records/{record_id}")
    payload = {"fields": {k: v for k, v in fields.items() if v is not None}}
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                                method="PUT")
    resp = json.loads(urllib.request.urlopen(req, timeout=20).read())
    if resp.get("code") != 0:
        raise RuntimeError(f"飞书更新失败: code={resp.get('code')} msg={resp.get('msg')}")
    print(f"[ok] 飞书记录已更新: {record_id}", flush=True)


# ── 主流程 ────────────────────────────────────────────────

def main(url: str) -> dict:
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            user_data_dir=str(PROFILE), headless=False,
            args=["--disable-blink-features=AutomationControlled", "--start-maximized"],
            no_viewport=True,
        )
        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        print("[i] 打开笔记页...", flush=True)
        page.goto(url, wait_until="domcontentloaded", timeout=60000)
        time.sleep(4)

        if is_login_required(page):
            wait_for_login(page)
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            time.sleep(5)

        # 滚动触发懒加载
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        time.sleep(3)
        page.evaluate("window.scrollTo(0, 0)")
        time.sleep(2)
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        time.sleep(5)

        # 截图
        shot = str(SHOT_DIR / "sync_result.png")
        page.screenshot(path=shot, full_page=False)
        print(f"[i] 截图: {shot}", flush=True)

        # 抓取
        data = scrape_note_data(page)
        debug = data.pop("_debug")

        print("\n========== 抓取结果 ==========", flush=True)
        print(json.dumps(data, ensure_ascii=False, indent=2), flush=True)
        if any(v is None for v in [data["likes"], data["collects"], data["comments"]]):
            print("\n[warn] 部分数据未获取到，debug:", json.dumps(debug, ensure_ascii=False), flush=True)

        ctx.close()
        return data


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="小红书笔记数据 → 飞书数据库表")
    ap.add_argument("url", nargs="?", default=None, help="笔记链接（留空则用 config.yaml 里的 sync.default_note_url）")
    ap.add_argument("--dry-run", action="store_true", help="只抓取打印，不写飞书（供人工核对）")
    ap.add_argument("--table-id", default=None, help="覆盖目标表（优先于 config.yaml 的 sync.table_id）")
    ap.add_argument("--update", default=None, help="直接更新指定 record_id（跳过抓取）")
    ap.add_argument("--reads", default=None, type=int, help="与 --update 配合：阅读量")
    ap.add_argument("--likes", default=None, type=int, help="与 --update 配合：点赞")
    ap.add_argument("--collects", default=None, type=int, help="与 --update 配合：收藏")
    ap.add_argument("--comments", default=None, type=int, help="与 --update 配合：评论")
    args = ap.parse_args()

    url = apply_config(args.url)
    require_credentials()
    if args.table_id:
        TABLE_ID = args.table_id.strip()

    # 直更模式：用已知准确值覆盖某条记录（用于人工核对后回填）
    if args.update:
        token = feishu_token()
        fields = {
            FIELD_NAMES["title"]: None,  # 不覆盖标题
            FIELD_NAMES["reads"]: args.reads,
            FIELD_NAMES["likes"]: args.likes,
            FIELD_NAMES["collects"]: args.collects,
            FIELD_NAMES["comments"]: args.comments,
        }
        fields = {k: v for k, v in fields.items() if v is not None}
        feishu_update_record(token, args.update, fields)
        print(f"\n✅ 已用提供的值更新记录 {args.update}", flush=True)
        raise SystemExit(0)

    if not url:
        raise SystemExit(
            "[x] 未提供笔记链接。\n"
            "    用法: python scripts/sync_xhs_stats.py '<笔记链接>'\n"
            "    或在 config.yaml 设 sync.default_note_url 后直接运行本脚本。"
        )

    data = main(url)

    # 抓取后人工核对提示
    dbg = data.get("_debug", {})
    if dbg.get("need_check"):
        print("\n⚠️ 以下字段在页面上显示为文字（如「赞」），无法自动提取数字，请人工核对：",
              dbg["need_check"], flush=True)

    enough = data.get("title") and any(
        v is not None for v in [data["likes"], data["collects"], data["comments"]]
    )

    if not enough:
        print("\n[x] 抓到的数据不足，未写入飞书。debug:", json.dumps(dbg, ensure_ascii=False), flush=True)
        raise SystemExit(0)

    print("\n========== 抓取摘要（请核对）==========", flush=True)
    print(f"  标题 : {data['title']}", flush=True)
    print(f"  阅读 : {data['reads']}", flush=True)
    print(f"  点赞 : {data['likes']}", flush=True)
    print(f"  收藏 : {data['collects']}", flush=True)
    print(f"  评论 : {data['comments']}", flush=True)

    if args.dry_run:
        print("\n[dry-run] 未写入飞书。确认无误后去掉 --dry-run 重新运行即可。", flush=True)
        raise SystemExit(0)

    # 写入/更新：按标题去重
    token = feishu_token()
    fields = {
        FIELD_NAMES["title"]: data["title"],
        FIELD_NAMES["reads"]: data.get("reads"),
        FIELD_NAMES["likes"]: data.get("likes"),
        FIELD_NAMES["collects"]: data.get("collects"),
        FIELD_NAMES["comments"]: data.get("comments"),
    }
    existing = feishu_find_record_id_by_title(token, data["title"])
    if existing:
        feishu_update_record(token, existing, fields)
        print(f"\n✅ 已更新已有记录（{existing}）", flush=True)
    else:
        rec_id = feishu_create_record(token, fields)
        print(f"\n✅ 已新建记录（{rec_id}）", flush=True)
