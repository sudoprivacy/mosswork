#!/usr/bin/env python3
"""小红书创作者中心浏览器自动化。

只做「预填」，assist 模式下绝不代点「发布」——最后一下交给真人，
这是绕开平台 AI 托管红线的关键设计。
"""

from __future__ import annotations

import time
from pathlib import Path

from image_store import NotePackage

SUCCESS_HINTS = ("发布成功", "笔记发布成功", "发布成功啦")
LOGIN_WAIT_SECONDS = 300
DEFAULT_CREATOR_URL = "https://creator.xiaohongshu.com/publish/publish?target=image"

# 已进入「可填表状态」的标志：上传入口（入口页）或编辑区（编辑页）任一出现
EDITOR_READY_PROBES = (
    'input[type="file"]',
    '#post-title',
    'input[placeholder*="标题"]',
    '#post-textarea',
    'div[contenteditable="true"]',
)
# 上传图片后，等这些「编辑器输入框」出现才算上传完成（file input 在入口页就有，不能当标志）
EDITOR_INPUT_PROBES = (
    '#post-title',
    'input[placeholder*="标题"]',
    '#post-textarea',
    'div[contenteditable="true"]',
)
LOGIN_FORM_PROBES = (
    'input[placeholder*="手机"]',
    'input[placeholder*="phone"]',
    'text=短信登录',
    'text=扫码登录',
    '.login-container',
    '#login',
)


class BrowserError(RuntimeError):
    pass


class XhsPublisher:
    def __init__(self, cfg: dict, workdir: Path, verbose: bool = True) -> None:
        self.cfg = cfg
        self.browser_cfg = cfg.get("browser", {})
        self.selectors = cfg.get("selectors", {})
        self.workdir = workdir
        self.verbose = verbose
        self._pw = None
        self._context = None
        self.page = None

    # ---------- 生命周期 ----------

    def _log(self, msg: str) -> None:
        if self.verbose:
            print(msg, flush=True)

    def launch(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise BrowserError(
                "未安装 Playwright。执行：\n"
                "  pip install playwright\n"
                "  playwright install chromium"
            ) from exc

        profile = self.workdir.parent / str(self.cfg.get("paths", {}).get("browser_profile", ".xhs_browser_profile"))
        profile.mkdir(parents=True, exist_ok=True)
        self._pw = sync_playwright().start()
        self._context = self._pw.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=bool(self.browser_cfg.get("headless", False)),
            args=["--disable-blink-features=AutomationControlled", "--start-maximized"],
            no_viewport=True,
        )
        self._context.set_default_timeout(int(self.browser_cfg.get("timeout_ms", 30000)))
        self.page = self._context.pages[0] if self._context.pages else self._context.new_page()
        self._log(f"[ok] 浏览器已启动（登录态目录 {profile}）")

    def close(self) -> None:
        try:
            if self._context:
                self._context.close()
        except Exception:  # noqa: BLE001 - 关浏览器时的异常不影响主流程
            pass
        try:
            if self._pw:
                self._pw.stop()
        except Exception:  # noqa: BLE001
            pass

    # ---------- 选择器 ----------

    def _candidates(self, key: str) -> list[str]:
        raw = self.selectors.get(key, "")
        return [s.strip() for s in str(raw).split(",") if s.strip()]

    def _find(self, key: str, timeout_ms: int | None = None, require_visible: bool = True):
        """按配置顺序找第一个存在的元素，全部落空返回 None。

        require_visible=False 用于文件上传入口等视觉上隐藏但 DOM 存在的控件。
        """
        timeout = timeout_ms or int(self.browser_cfg.get("timeout_ms", 30000))
        deadline = time.time() + timeout / 1000
        while time.time() < deadline:
            for sel in self._candidates(key):
                try:
                    loc = self.page.locator(sel).first
                    if loc.count() > 0 and (not require_visible or loc.is_visible()):
                        return loc
                except Exception:  # noqa: BLE001 - 单个选择器失效不应中断尝试
                    continue
            time.sleep(0.4)
        return None

    # ---------- 登录 ----------

    def open_publish_page(self) -> None:
        url = str(self.browser_cfg.get("creator_url", "https://creator.xiaohongshu.com/publish/publish?target=image"))
        self.page.goto(url, wait_until="domcontentloaded")
        self._log(f"[ok] 已打开发布页：{url}")

    def _is_on_login_page(self) -> bool:
        """判断当前页面是否停在登录/登录弹窗。

        小红书创作者中心 2026 年后的行为：URL 不变（仍是 publish 地址），
        但页面内容变成登录表单（短信登录 / 扫码）。所以不能只看 URL。
        """
        # 1. URL 含 login 关键字（旧版行为）
        url_marker = str(self.browser_cfg.get("login_url_contains", "login"))
        if url_marker and url_marker in self.page.url:
            return True
        # 2. URL 被重定向到非发布路径（如 /login 或 /passport）
        creator_url = str(self.browser_cfg.get("creator_url", ""))
        if creator_url and self.page.url != creator_url and not self.page.url.startswith(creator_url.split("?")[0]):
            return True
        # 3. DOM 上出现登录特征元素（新版行为）
        try:
            for sel in (
                'input[placeholder*="手机"]',
                'input[placeholder*="phone"]',
                'button:has-text("登录")',
                'text=短信登录',
                'text=扫码登录',
                '.login-container',
                '#login',
            ):
                loc = self.page.locator(sel)
                if loc.count() > 0 and loc.first.is_visible():
                    return True
        except Exception:  # noqa: BLE001 — DOM 查询失败不算登录页
            pass
        # 4. 页面标题含「登录」关键词（兜底）
        try:
            title = (self.page.title() or "").strip()
            if "登录" in title or "Login" in title.lower():
                return True
        except Exception:  # noqa: BLE001
            pass
        return False

    def _editor_ready(self) -> bool:
        """上传入口或编辑区任一出现，即认为已进入可填表状态。"""
        for sel in EDITOR_READY_PROBES:
            try:
                if self.page.locator(sel).count() > 0:
                    return True
            except Exception:  # noqa: BLE001
                continue
        return False

    def _login_form_visible(self) -> bool:
        for sel in LOGIN_FORM_PROBES:
            try:
                loc = self.page.locator(sel)
                if loc.count() > 0 and loc.first.is_visible():
                    return True
            except Exception:  # noqa: BLE001
                continue
        return False

    def ensure_login(self) -> None:
        """等登录态可用：以「发布编辑器是否出现」为准，而不是猜页面有没有登录元素。

        v1.5.0 修复：旧实现只在「判定为不在登录页」时才重新导航；登录后若 URL
        或弹窗没按预期变化，会一直等到超时，导致整篇内容一次都没填。
        现在判定成功即主动回到发布页，且等待期间不刷新页面（不打断扫码）。
        """
        creator = str(self.browser_cfg.get("creator_url", DEFAULT_CREATOR_URL))
        login_wait = int(self.browser_cfg.get("login_wait_seconds", LOGIN_WAIT_SECONDS))
        time.sleep(2)
        print("\n========== 检查小红书登录态 ==========", flush=True)
        print("若页面出现二维码，请用小红书 App 扫码登录；已登录会自动继续。", flush=True)
        print(f"（最多等待 {login_wait // 60} 分钟）\n", flush=True)
        deadline = time.time() + login_wait
        while time.time() < deadline:
            try:
                if self._editor_ready() and not self._login_form_visible():
                    if not self.page.url.startswith(creator.split("?")[0]):
                        # 登录后可能停在首页/成功页，主动回发布页，避免死锁
                        self.page.goto(creator, wait_until="domcontentloaded")
                        time.sleep(2)
                    self._log("[ok] 登录态有效，发布编辑器可用（登录态已持久化）")
                    return
            except Exception:  # noqa: BLE001 - 跳转瞬间 DOM 查询会抛错，不算失败
                pass
            time.sleep(2)
        self._screenshot("error_login")
        raise BrowserError(
            f"等待登录超时（{login_wait}s）：始终没检测到发布编辑器。\n"
            "请确认是在脚本打开的浏览器窗口里完成扫码；重跑一次即可（登录态已保存）。"
        )

    # ---------- 填表 ----------

    def fill(self, pkg: NotePackage) -> None:
        """预填并回读自检：填不全就明确失败，绝不把「假成功」留给真人去点发布。"""
        self._upload_images(pkg.image_paths)
        self._fill_title(pkg.title)
        self._fill_body(pkg.body)
        if pkg.topics:
            self._fill_topics(pkg.topics)
        problems = self._verify(pkg)
        if problems:
            self._log("[warn] 预填自检未通过，自动补填一次：" + "；".join(problems))
            self._screenshot("prefill_retry")
            try:
                self._fill_title(pkg.title)
                self._fill_body(pkg.body)
            except BrowserError as exc:
                problems = [str(exc)]
            else:
                problems = self._verify(pkg)
        if problems:
            self._screenshot("error_prefill")
            raise BrowserError(
                "内容没有完整填进小红书发布页：\n  - " + "\n  - ".join(problems)
                + "\n\n浏览器已停在发布页，请不要直接点「发布」。"
                "可手动补齐，或更新 config/config.yaml 的 selectors 后重跑。"
            )
        self._screenshot("filled")
        self._log("[ok] 内容已预填完成（标题/正文已回读核对）")

    def _upload_images(self, paths: list[Path]) -> None:
        loc = self._find("upload_input", require_visible=False)
        if loc is None:
            self._screenshot("error_upload")
            raise BrowserError(
                "找不到图片上传入口，多半是小红书改版了。\n"
                "请打开 config/config.yaml，更新 selectors.upload_input（可用英文逗号填多个候选）。"
            )
        loc.set_input_files([str(p) for p in paths])
        self._log(f"[ok] 已提交 {len(paths)} 张图片，等待进入编辑页…")
        # 旧实现死等「缩略图选择器」最多 120 秒，选择器一改版就白等且拿不到编辑器。
        # 改为等「标题/正文输入框出现」，它出现即代表上传完成并已进入编辑页。
        deadline = time.time() + int(self.browser_cfg.get("upload_wait_seconds", 90))
        while time.time() < deadline:
            for sel in EDITOR_INPUT_PROBES:
                try:
                    l = self.page.locator(sel)
                    if l.count() > 0 and l.first.is_visible():
                        self._log("[ok] 编辑器已就绪，配图上传完成")
                        time.sleep(1.5)
                        return
                except Exception:  # noqa: BLE001
                    continue
            time.sleep(1)
        self._log("[warn] 未等到编辑器输入框，继续尝试填表（请目视确认配图）")

    def _fill_title(self, title: str) -> None:
        self._write_text("title", "标题", title, min_ratio=1.0)

    def _fill_body(self, body: str) -> None:
        self._write_text("body", "正文", body, min_ratio=0.7)

    def _write_text(self, key: str, label: str, text: str, min_ratio: float) -> None:
        """写入 + 回读校验，失败自动换输入方式重试。"""
        loc = self._find(key)
        if loc is None:
            self._screenshot(f"error_{key}")
            raise BrowserError(f"找不到{label}输入框，请更新 config/config.yaml 的 selectors.{key}")
        last = ""
        for attempt in (1, 2, 3):
            try:
                loc.click()
                if attempt == 1:
                    loc.fill(text)
                else:
                    # contenteditable / 富文本编辑器常不支持 fill，改用键盘插入
                    loc.fill("")
                    self.page.keyboard.insert_text(text)
            except Exception:  # noqa: BLE001
                try:
                    loc.click()
                    self.page.keyboard.press("ControlOrMeta+A")
                    self.page.keyboard.insert_text(text)
                except Exception as exc:  # noqa: BLE001
                    raise BrowserError(f"{label}写入失败：{exc}") from exc
            time.sleep(0.6)
            last = self._read_back(loc).strip()
            if self._text_ok(last, text, min_ratio):
                self._log(f"[ok] {label}已写入（回读 {len(last)} 字）")
                return
            self._log(f"[warn] {label}第 {attempt} 次回读不符（{len(last)} 字），重试")
        self._screenshot(f"error_{key}")
        raise BrowserError(
            f"{label}始终没写进去（页面 {len(last)} 字 / 预期 {len(text)} 字）。"
            f"请检查 selectors.{key}，或在浏览器里手动粘贴后发布。"
        )

    @staticmethod
    def _text_ok(actual: str, expected: str, min_ratio: float) -> bool:
        actual = (actual or "").strip()
        expected = (expected or "").strip()
        if not expected:
            return True
        if len(actual) < max(1, len(expected) * min_ratio):
            return False
        return expected[:10] in actual

    def _read_back(self, loc) -> str:
        try:
            value = loc.input_value()
            if value:
                return value
        except Exception:  # noqa: BLE001 - contenteditable 没有 input_value
            pass
        try:
            return loc.inner_text() or ""
        except Exception:  # noqa: BLE001
            return ""

    def _verify(self, pkg: NotePackage) -> list[str]:
        """填完后回读页面，返回问题列表；空列表才算预填成功。"""
        problems: list[str] = []
        title_loc = self._find("title", timeout_ms=3000)
        if title_loc is None:
            problems.append("标题输入框不可见")
        else:
            actual = self._read_back(title_loc).strip()
            if not self._text_ok(actual, pkg.title, 1.0):
                problems.append(f"标题未完整写入（页面读到 {actual[:30]!r}）")
        body_loc = self._find("body", timeout_ms=3000)
        if body_loc is None:
            problems.append("正文编辑区不可见")
        else:
            actual = self._read_back(body_loc).strip()
            if not self._text_ok(actual, pkg.body, 0.7):
                problems.append(f"正文不完整（页面 {len(actual)} 字 / 预期 {len(pkg.body)} 字）")
        return problems

    def _fill_topics(self, topics: list[str]) -> None:
        loc = self._find("topic_input", timeout_ms=5000)
        if loc is None:
            self._log("[warn] 未找到话题输入框，已跳过话题（不影响发布）")
            return
        try:
            loc.click()
            for topic in topics:
                self.page.keyboard.type(topic)
                time.sleep(0.8)
                self.page.keyboard.press("Enter")
                time.sleep(0.4)
        except Exception as exc:  # noqa: BLE001 - 话题是增强项，失败不阻断
            self._log(f"[warn] 话题填写失败（{exc}），可手动补")

    # ---------- 发布 ----------

    def wait_user_publish(self) -> bool:
        """assist 模式：停在这里，等真人在浏览器里点「发布」。

        返回 True 表示检测到发布成功；超时或用户中断返回 False。
        """
        wait_seconds = int(self.browser_cfg.get("wait_publish_seconds", 900))
        print("\n========== 等你点最后一下 ==========", flush=True)
        print("浏览器已停在预览状态，请检查标题、正文、配图、话题。", flush=True)
        print("确认无误后，在浏览器里点「发布」。", flush=True)
        print(f"脚本会一直等（最多 {wait_seconds // 60} 分钟），检测到发布成功会自动回写飞书。", flush=True)
        print("不想发了：直接关闭浏览器窗口即可。\n", flush=True)

        start_url = ""
        try:
            start_url = self.page.url
        except Exception:  # noqa: BLE001
            pass
        deadline = time.time() + wait_seconds
        while time.time() < deadline:
            time.sleep(2)
            try:
                if self._context is None or not self._context.pages:
                    print("[i] 浏览器已关闭，视为取消发布")
                    return False
                url_now = self.page.url
                if url_now != start_url and ("success" in url_now.lower() or "result" in url_now.lower()):
                    self._screenshot("published")
                    return True
                content = self.page.inner_text("body")[:4000]
                if any(hint in content for hint in SUCCESS_HINTS):
                    self._screenshot("published")
                    return True
            except Exception:  # noqa: BLE001 - 用户关窗口时会抛异常
                print("[i] 浏览器已关闭，视为取消发布")
                return False
        print(f"[warn] 等待发布超时（{wait_seconds} 秒），未检测到发布成功")
        return False

    def click_publish(self) -> bool:
        """auto 模式：代点发布按钮。仅在用户明确要求全自动时使用。"""
        loc = self._find("publish_button", timeout_ms=15000)
        if loc is None:
            self._screenshot("error_publish")
            raise BrowserError("找不到「发布」按钮，请更新 config/config.yaml 的 selectors.publish_button")
        loc.click()
        self._log("[ok] 已点击发布")
        deadline = time.time() + 120
        while time.time() < deadline:
            time.sleep(2)
            try:
                content = self.page.inner_text("body")[:4000]
                if any(hint in content for hint in SUCCESS_HINTS):
                    self._screenshot("published")
                    return True
            except Exception:  # noqa: BLE001
                break
        self._log("[warn] 未检测到明确的发布成功提示，请人工确认")
        return False

    # ---------- 工具 ----------

    def _screenshot(self, tag: str) -> None:
        try:
            shots = self.workdir / "screenshots"
            shots.mkdir(parents=True, exist_ok=True)
            name = f"{time.strftime('%Y%m%d_%H%M%S')}_{tag}.png"
            self.page.screenshot(path=str(shots / name), full_page=False)
            self._log(f"[i] 截图已保存：{shots / name}")
        except Exception:  # noqa: BLE001 - 截图失败不影响主流程
            pass
