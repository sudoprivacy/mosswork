---
name: skillhub-skill-xhs-feishu-publish-skill
description: "双向同步技能：(1) 把飞书多维表格（Bitable）指定视图中排序第一条（或自选第 N 行）的记录，自动取出标题、正文、图片（附件列自动下载），并在小红书创作者中心预填为一篇图文笔记，停在预览状态等真人点最后一下「发布」，发布后回写飞书状态；(2) 反向把小红书笔记的标题/阅读/点赞/收藏/评论抓回飞书「数据库」表。触发词：飞书表格发小红书、多维表格自动发布、小红书自动发帖、bitable to xiaohongshu、高潜力选题发布、表格内容同步小红书、xhs publish、小红书半自动发布、把飞书笔记发到小红书、发表格第几条、选第 N 行发小红书、给飞书链接发小红书、飞书链接第几行发小红书、链接第 N 行发布、同步小红书数据到飞书、小红书笔记数据回写、笔记阅读点赞收藏、xhs sync、抓小红书数据。"
---

# 飞书表格 ⇄ 小红书 半自动双向同步

本技能包含两条独立链路，共用同一套飞书凭证：

- **发布链路（飞书 → 小红书）**：从飞书多维表格取「当前视图排序第一条」的记录（也可指定取第 N 行），下载其附件图片，自动登录小红书创作者中心把标题/正文/图片全部预填好，然后**停在预览页等你人工点「发布」**，确认发布后回写飞书状态列，保证同一条不会被重复取用。
- **数据同步链路（小红书 → 飞书）**：把某篇小红书笔记的标题 / 阅读 / 点赞 / 收藏 / 评论抓回飞书「数据库」表（字段为数字类型），按标题去重 upsert。

## 何时使用

- 用户维护了一张飞书多维表格做选题库/内容库，想把排在最前面的那条发到小红书
- 用户说「把表格里第一条发小红书」「同步飞书选题到小红书」「自动发帖」
- 用户说「把表格里第 29 条发了」「发表格第几行」「选第 N 行发小红书」——用 `--index N` + `--no-filter` 取原始行序的第 N 行
- **用户甩来一个飞书链接 + 第几行**（「把飞书链接里第 6 行发小红书」「链接第 3 行发布」）——直接用下面的 **链接一键发布**，不用改任何配置
- 定时批处理场景下按周期发布（此时用 `--mode assist` 仍需真人在场点发布）

## 链接一键发布（免改配置，最常用）⭐

用户只要给两样东西：**飞书多维表格链接** + **第几行**，其余全自动。脚本会从链接里解析出 base/table/view，**不修改** `config.yaml`，并自动嗅探目标表字段名（若和你平时用的表字段名不同也能适配）。

```bash
# 先看第 6 行取到什么（不碰浏览器、不回写，强烈建议先跑这步核对）
python scripts/xhs_publish.py fetch-link \
  --url 'https://xxx.feishu.cn/base/XXXX?table=tblYYYY&view=vewZZZZ' \
  --index 6

# 确认无误后正式发布：预填 → 浏览器停在发布页 → 你点「发布」→ 回写飞书
python scripts/xhs_publish.py publish-link \
  --url 'https://xxx.feishu.cn/base/XXXX?table=tblYYYY&view=vewZZZZ' \
  --index 6
```

要点：

- `--index` 是 **1-based**（第 1 行=1），且按**表格/视图原始行序**取（等同 `no_filter=True`），最贴合「第 N 行」字面意思。
- 链接必须含 `table=`（即 `https://.../base/xxx?table=tblxxx&view=vewxxx`），复制浏览器地址栏里那段即可；只有 `base` 没有 `table=` 时也能跑（会用表默认顺序）。
- 字段自动适配：若目标表的「标题/正文/配图」字段名和你默认配置不同，脚本按字段名关键词自动识别并本趟改用；状态字段不在目标表则本趟跳过回写（不影响发布）。
- 仍停在发布页等真人点「发布」（`assist` 模式）。想先 dry-run 验证取数+下载图不进浏览器，加 `--dry-run`。
- **飞书权限不用自己折腾**：自建应用没被加为表格协作者（OpenAPI 报 `91403`）或干脆没填凭证时，只要本机装了并登录过 `lark-cli`，会自动切到用户身份继续跑，日志里会打印「自动改用 lark-cli 登录身份重试」。可用 `feishu.auto_cli_fallback: false` 关掉。

## v1.5.0 一次跑通加固

针对「内容没能一次性填进小红书发布页」的两个根因：

1. **登录态误判死锁**：旧版靠「页面上有没有登录元素」判断，登录后若 URL/弹窗没按预期变化会一直空等到超时，整篇内容一次都没填。现在改为检测**发布编辑器是否出现**，识别成功即主动回到发布页；等待期间不刷新页面（不打断扫码），超时给出可照做的提示。
2. **预填「假成功」**：旧版填完只粗略比一下正文长度就宣布完成。现在标题/正文写入后都会**回读校验**，不符自动换输入方式重试（最多 3 次），全部填完再做一次整体验证；仍不通过就明确报错、截图并**停在发布页阻止误发**，不会让真人面对半空的编辑框。
3. 上传配图后改为等「编辑器输入框出现」（等价于上传完成），不再死等容易失效的缩略图选择器（旧版最长白等 120 秒）。
4. 兼容当前 `lark-cli`（1.0.98+）的字段/记录输出结构，并支持记录分页，取第 N 行不再受单页 200 条限制。

相关可调参数在 `config/config.yaml`：`browser.login_wait_seconds`（默认 300）、`browser.upload_wait_seconds`（默认 90）、`feishu.auto_cli_fallback`（默认 true）。

## 发布模式（合规边界，勿擅自升级）

| 模式 | 行为 | 风险 |
|---|---|---|
| `assist`（默认） | 预填全部内容后停住，等真人点「发布」 | 低，遵守平台「AI 辅助创作、真人发布」要求 |
| `draft` | 只落地图文到本地草稿包 + 回写「待发布」，不开浏览器 | 零 |
| `auto` | 连「发布」按钮一起自动点 | **触碰小红书 AI 托管红线，仅限用户明确书面要求时开启** |

**默认与推荐永远是 `assist`。** 用户要求全自动时，必须明确告知封号风险并让其确认，不可默认代开。

## 快速开始

```bash
# 1) 首次：交互式配置（解析表格链接、探测字段、生成映射）
python scripts/xhs_publish.py setup --url 'https://xxx.feishu.cn/base/XXX?table=tblYYY&view=vewZZZ'

# 2) 检查环境（凭证、依赖、小红书登录态）
python scripts/xhs_publish.py check

# 3) 预演：只取数不碰浏览器
python scripts/xhs_publish.py fetch

# 4) 正式跑：取数 → 下载图 → 预填 → 等你点发布 → 回写
python scripts/xhs_publish.py publish
```

单条命令跑完整流程：`python scripts/xhs_publish.py publish`。

## 选行发布（取第 N 条）

默认只取「排序后的第一条」。要发**表格里具体的第几行**，用 `--index`（1-based）配合 `--no-filter`（忽略「高潜力」筛选与「综合得分」排序，按表格原始行序取）：

```bash
# 发「表格从上往下数第 29 行」——忽略筛选/排序，直接按行号
python scripts/xhs_publish.py publish --index 29 --no-filter

# 预演看看第 29 行取到的是什么（不碰浏览器、不回写）
python scripts/xhs_publish.py fetch --index 29 --no-filter
```

> ⚠️ `--index N` 的「第 N 条」取决于语义：
> - **加 `--no-filter`**：按表格/视图**原始行序**取第 N 行（最贴近「表格第 N 条」的字面意思）。
> - **不加 `--no-filter`**：沿用筛选+排序规则，取「高潜力且未发布、按综合得分降序」列表里的第 N 篇。
> 两者可能取到完全不同的记录，发前建议先用 `fetch` 确认内容。

`fetch` / `prepare` / `publish` 三个子命令都支持 `--index` 与 `--no-filter`。

## 取数规则

默认取**目标视图排序后的第一条记录**（视图自己的筛选/排序规则说了算，skill 不另加过滤）。
若配置了 `filter.status_field`，会跳过状态字段值命中 `filter.exclude_values` 的行（如已发布），从第一条可用行开始取。
`--index N` 在上述候选集（已过滤、已排序）里取第 N 条；`--no-filter` 时跳过过滤与排序，直接按原始行序取第 N 行。

## 小红书 → 飞书 数据同步

把一篇小红书笔记的互动数据写回飞书（与发布链路共用同一飞书应用，但目标表可不同）。

```bash
# 抓指定笔记，先只打印不写飞书（核对用，强烈建议首次用）
python scripts/sync_xhs_stats.py '<笔记链接>' --dry-run

# 核对无误后正式写入（按标题去重：已存在则更新）
python scripts/sync_xhs_stats.py '<笔记链接>'

# 若 config.yaml 里配了 sync.default_note_url，可直接不带链接运行
python scripts/sync_xhs_stats.py

# 已知准确值、直接覆盖某条记录（人工核对后回填，跳过抓取）
python scripts/sync_xhs_stats.py --update recXXXX --reads 8 --likes 1 --collects 1 --comments 0
```

配置（都在 `config.yaml`，发版包不含真实值）：

```yaml
sync:
  target_table_id: "tblXXXXXXXX"   # 同步目标表；留空则复用 feishu.table_id
  default_note_url: ""             # 常用笔记链接，设了可免参数运行
  fields:                          # 目标表字段名，按你自己的表改
    title: "标题"  reads: "阅读"  likes: "点赞"  collects: "收藏"  comments: "评论"
```

抓取约定（重要，避免踩坑）：

- 优先读页面 `__INITIAL_STATE__` 主笔记对象；DOM 兜底时会**锁定主笔记容器**，不会误抓页面底部推荐流里别的笔记的大数字（这是 v1.2 修复的关键 bug）。
- 互动量很低时，小红书把「赞」显示成文字而非数字，脚本会标记 `need_check` 并提示人工核对，绝不臆造数值。
- **阅读量仅本人可见**：只有登录态能看到自己笔记的阅读数时才填写；公开页抓不到则留空。
- 目标表里的 阅读/点赞/收藏/评论 必须是**数字类型**（飞书 Bitable `type=2`）；单选/复选框字段写数字会报错。
- 写入前建议先用 `--dry-run` 核对一次。

## 文件结构

- `scripts/xhs_publish.py` — 发布链路编排入口（setup/check/fetch/prepare/publish/login/mark + 链接模式 fetch-link/publish-link）
- `scripts/sync_xhs_stats.py` — 数据同步链路（小红书笔记 → 飞书「数据库」表）
- `scripts/feishu_source.py` — 飞书取数，双通道：有 `lark-cli` 走 CLI，否则直连 OpenAPI
- `scripts/image_store.py` — 附件下载、去重、尺寸/数量校验
- `scripts/xhs_browser.py` — Playwright 预填创作者中心，选择器可配置且有回退
- `scripts/setup_wizard.py` — URL 解析 + 字段角色探测 + 生成配置
- `references/feishu-api.md` — 飞书接口真实细节与错误码
- `references/xhs-publish-flow.md` — 创作者中心页面结构、选择器、登录态维护
- `tests/test_skill.py` — 自检与黄金用例

## 前置

1. 飞书自建应用：`app_id` + `app_secret`，并开通 `bitable:app`、`drive:media` 权限，把应用加为表格协作者
2. Python 依赖：`pip install requests PyYAML playwright && playwright install chromium`
3. 小红书：首次运行会开浏览器让你扫码登录一次，之后登录态持久化复用

配置落在 `config/config.yaml`（由 `setup` 生成，模板见 `config/config.example.yaml`）。

## 硬性校验（超限直接报错，不硬发）

标题 ≤ 20 字 · 正文 ≤ 1000 字 · 图片 1–18 张 · 单张 ≤ 32MB · 话题 ≤ 10 个

## 排错

先跑 `python scripts/xhs_publish.py check`，再查 `references/troubleshooting.md`。
选择器失效（小红书改版）是最高频故障：更新 `config/config.yaml` 的 `selectors` 段即可，无需改代码。

两个高频场景（v1.5.0 起已自动处理，一般无需手动干预）：

- 飞书报 `91403 Forbidden` / 没配自建应用凭证 → 自动改用 `lark-cli` 登录身份；若 `lark-cli` 也没登录，跑 `lark-cli auth login`。
- 「等待登录超时」或「内容没有完整填进小红书发布页」→ 脚本会截图到 `.xhs_work/screenshots/`，按报错提示更新 `selectors` 或手动补齐后重跑；**此时不要直接点「发布」**。

## 分享与安装（给别人用）

本技能已做成可分享的技能包，**发版包里不含任何飞书密钥**（`config.yaml` 是占位模板，
真实凭证只存在于你自己机器上，发送前已自动剔除）。

打包：

```bash
python scripts/build_dist.py        # 产物在 dist/xhs-feishu-publish-skill-<version>.zip
```

收到包的人：

1. 解压到任意目录，进入该目录
2. 运行安装脚本（自动装到 WorkBuddy 的 skills 目录并装好依赖）：
   - Windows：`powershell -ExecutionPolicy Bypass -File install.ps1`
   - macOS/Linux：`bash install.sh`
3. 首次配置（填**自己的**飞书凭证与表格）：
   `python scripts/xhs_publish.py setup --url '<自己的飞书多维表格链接>'`
4. 体检 + 发第一篇：`check` → `publish`

> 各人用自己的飞书应用和自己的表，数据互不串。默认永远是 `assist`（预填后真人点发布）。
