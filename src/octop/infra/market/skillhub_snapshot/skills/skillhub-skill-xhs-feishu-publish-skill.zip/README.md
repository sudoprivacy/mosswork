# 飞书表格 → 小红书 半自动发布

把飞书多维表格某个视图里**排序第一条**（或自选**第 N 行**）的记录（标题 / 正文 / 附件配图）自动取出来，
下载配图，然后在小红书创作者中心把整篇笔记**预填好**，停在预览状态等你人工点最后一下「发布」，
发布成功后回写飞书状态字段，保证同一条不会被重复取用。

```
飞书多维表格 ──取第一条──> 下载附件配图 ──> 校验(字数/图数/大小)
                                              │
                                              ▼
                                 打开创作者中心并预填标题/正文/图片/话题
                                              │
                                   ===== 真人闸门：你点「发布」=====
                                              │
                                              ▼
                                     回写飞书状态 + 发布时间
```

## 一分钟上手

```bash
# 1. 装依赖（只做一次）
pip install requests PyYAML playwright
playwright install chromium

# 2. 生成配置：贴表格链接，自动识别字段
python scripts/xhs_publish.py setup --url 'https://xxx.feishu.cn/base/XXX?table=tblYYY&view=vewZZZ'

# 3. 体检
python scripts/xhs_publish.py check

# 4. 发一篇
python scripts/xhs_publish.py publish
```

`publish` 会在浏览器里把内容填好，然后停在页面上等你点「发布」。

## 五种命令

| 命令 | 作用 |
|---|---|
| `setup --url '<链接>'` | 解析链接、探测字段角色、生成 `config/config.yaml` |
| `check` | 体检：依赖、凭证、飞书连通性、字段是否存在、登录态 |
| `fetch` | 取一条记录打印出来看看（可 `--index N`），不下载、不开浏览器 |
| `prepare` | 取数 + 下载配图 + 校验 + 产出 `draft/` 草稿包 |
| `publish` | 全流程跑完，停在等你点发布 |

常用参数：`--config <路径>` 指定配置、`--mode assist|draft|auto`、`--dry-run` 只取数不碰浏览器、
`--index N`（取第几条，1-based）、`--no-filter`（忽略筛选/排序，按表格原始行序取）。

## 三种发布模式

| 模式 | 行为 | 什么时候用 |
|---|---|---|
| **assist**（默认） | 预填全部内容后停住，等真人点「发布」 | **日常就用这个** |
| draft | 只落地图文到 `draft/`，不开浏览器 | 想攒一批手动发、或机器没有浏览器 |
| auto | 连「发布」按钮一起自动点 | 触碰小红书 AI 托管红线，需输入「我承担风险」确认，风险自负 |

> 为什么默认是 assist：小红书不向个人号开放笔记发布 API，2026-07「薯管家」治理公告明确禁止
> 脚本代替真人自动发布，已处置违规账号 42 万个。本技能用浏览器模拟的是**填写**动作，
> 发布这一下始终由真人完成，这是当前唯一不会被判定为 AI 托管的自动化形态。

## 数据同步（小红书 → 飞书）

把某篇小红书笔记的标题 / 阅读 / 点赞 / 收藏 / 评论抓回飞书「数据库」表（与发布共用同一飞书应用，目标表在 `config.yaml` 的 `sync.target_table_id` 里配）。

```bash
# 先 --dry-run 核对，再正式写
python scripts/sync_xhs_stats.py '<笔记链接>' --dry-run
python scripts/sync_xhs_stats.py '<笔记链接>'

# 设了 sync.default_note_url 后可直接免参数运行
python scripts/sync_xhs_stats.py

# 已知准确值直接覆盖某条记录（人工核对后回填）
python scripts/sync_xhs_stats.py --update recXXXX --reads 8 --likes 1 --collects 1 --comments 0
```

要点：目标表互动字段必须是数字类型（`type=2`）；抓取会锁定主笔记容器，不会误抓推荐流；阅读量仅本人可见、公开页抓不到则留空；互动量过低显示成文字时标记需人工核对。详见 `SKILL.md`。

## 飞书准备（只做一次）

1. 打开 [open.feishu.cn](https://open.feishu.cn) 建一个**企业自建应用**
2. 权限管理里开通：`bitable:app`（多维表格）、`drive:media`（附件下载）
3. 创建版本并**发布应用**，让权限真正生效（很多人卡在这一步）
4. 打开目标多维表格 → 右上角「分享」→ 把这个应用加为**可编辑协作者**
5. 把 App ID / App Secret 填进配置（`setup` 会引导你填）

浏览器打开目标表格时，地址栏形如
`https://xxx.feishu.cn/base/bascnXXX?table=tblYYY&view=vewZZZ`
整条复制给 `setup` 即可，三个 ID 会自动抠出来。

## 小红书登录

首次 `publish` 会弹出浏览器并打开创作者中心，扫一次码即可；
登录态存在 `config/../.xhs_browser_profile/`，之后无需重复扫码。
换账号或登录失效时，删掉该目录重跑一次。

## 字段映射

`setup` 会按字段名自动猜角色，猜错也没关系，直接改 `config/config.yaml`：

```yaml
fields:
  title: "标题"      # 必填
  body:  "正文"      # 必填
  images:"图片"      # 必填，必须是「附件」类型字段
  topics:""          # 选填，话题
  status:""          # 选填，发布状态；填了才会回写
```

**取数规则**：取目标视图排序后的第一条。视图自己的筛选和排序说了算，技能不另加过滤。
若配置里开了 `filter.enabled`，会额外跳过状态命中 `filter.exclude_values` 的行，顺延取下一条。
加 `--index N` 可指定取候选集里的第 N 条（1-based）；加 `--no-filter` 则忽略筛选与排序，
直接按表格/视图**原始行序**取第 N 行（最贴近「发表格第 N 条」的字面意思）。
发前建议先 `fetch --index N --no-filter` 确认取到的内容，避免发错行。

**回写**：`writeback.enabled` 打开后，预填成功写 `on_prefilled`，检测到发布成功写 `on_published`。
这是防止明天又取到同一条的关键，建议开启。

## 硬性校验（超限直接报错，不硬发）

标题 ≤ 20 字 · 正文 ≤ 1000 字 · 配图 1–18 张 · 单张 ≤ 32MB · 话题 ≤ 10 个

## 目录

```
config/config.yaml            # 你的配置（setup 生成，不进版本库）
config/config.example.yaml    # 配置模板
scripts/xhs_publish.py        # 发布链路主入口
scripts/sync_xhs_stats.py      # 数据同步链路（小红书笔记 → 飞书「数据库」表）
scripts/feishu_source.py      # 飞书取数（CLI / OpenAPI 双通道）
scripts/image_store.py        # 配图下载、去重、校验、草稿包
scripts/xhs_browser.py        # 创作者中心预填
scripts/setup_wizard.py       # 配置向导
references/feishu-api.md      # 飞书接口细节
references/xhs-publish-flow.md# 发布页结构与选择器
references/troubleshooting.md # 排错手册
tests/test_skill.py           # 自检 + 黄金用例
```

## 自检

```bash
python tests/test_skill.py      # 一条命令跑完全部 31 项
```

不需要凭证、不需要网络、不需要浏览器，全部用桩数据。覆盖：

- **结构门禁**：文件齐备、技能名与目录同名、description ≤1024 字符且含触发词、
  无 TODO/占位符、全部脚本可编译
- **核心管线**（mock 飞书）：富文本正文提取、附件下载、草稿包产出、AI 声明只追加一次、
  过滤跳过已发布行、回写状态与时间戳
- **黄金用例**：正常笔记通过 / 标题超长被拒 / 无配图被拒 / 重复图片去重
- **辅助函数**：URL 解析（含不带 `table=` 的分享链接）、字段角色识别、
  配置渲染保留注释、话题归一化

改代码后务必跑一遍再发布，避免回归。

## 安全说明

- 凭证只存在本地 `config/config.yaml`，不上传、不外发
- 代码不收集任何数据，不外发表格内容，仅在你本机浏览器里操作
- 不实现任何自动点赞 / 评论 / 私信功能（这是平台明确红线）
- `auto` 模式需显式确认才会启用，默认永远是 `assist`

## 分享给同事

本技能可整体打包发给别人，对方装到自己的 WorkBuddy 即可用（各用各的飞书表，数据不串）。

```bash
# 在你机器上导出干净包（自动剔除你的真实 config.yaml 与运行时产物）
python scripts/build_dist.py
# 产物：dist/xhs-feishu-publish-skill-<version>.zip
```

对方拿到 zip 后：

1. 解压，进入目录
2. `powershell -ExecutionPolicy Bypass -File install.ps1`  （Windows）
   或 `bash install.sh`  （macOS / Linux）
3. `python scripts/xhs_publish.py setup --url '<对方自己的飞书表链接>'`
4. `python scripts/xhs_publish.py check` → `publish`

发版包里 `config.yaml` 是占位模板（无密钥）；收包人跑一次 `setup` 填自己的凭证即可。

## 版本记录

### v1.5.0 — 一次跑通加固

修复「内容没能一次性填进小红书发布页」的两类根因：

- **飞书侧**：兼容当前 `lark-cli`（1.0.98+）的字段/记录输出结构，记录支持分页；
  OpenAPI 报 `91403`（应用不是表格协作者）或没配凭证时，自动切到 `lark-cli` 登录身份，
  日志会打印「自动改用 lark-cli 登录身份重试」，不再需要手工改配置或加应用协作者。
- **小红书侧**：登录判定改为检测发布编辑器是否出现，避免登录后空等超时、内容一次都没填；
  上传配图后等编辑器输入框出现（旧版死等缩略图选择器最长 120 秒）；
  标题/正文写入后回读校验、失败自动换输入方式重试，最后做整体验证——
  **没填全就明确报错并停在发布页，不会让真人面对半空的编辑框**。

新增可调项：`feishu.auto_cli_fallback`、`browser.login_wait_seconds`、`browser.upload_wait_seconds`。
新增 7 个单元测试（共 50 个），覆盖新旧 CLI 输出格式、403 自动回退与预填回读判断。

### v1.4.0 及更早

链接一键发布（`fetch-link` / `publish-link --index N`）、字段自动适配、单选选项护栏、
附件下载去重、小红书笔记数据反向同步。

