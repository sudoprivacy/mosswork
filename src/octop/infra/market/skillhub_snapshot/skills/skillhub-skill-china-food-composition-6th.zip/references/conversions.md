<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 换算完整推导与系数表（原书表 6 / 表 7 / 附录口径）

> 主文件 `SKILL.md` 步骤 4–6 只保留**速查卡（公式本体）**。本文件是**完整推导、系数与注意事项**，做精确换算或解释「为什么」时才需要读。

## 1. 可食部换算（市品 → 可食部）

### 1.1 可食部百分比

```text
EP(%) = (食品重量 − 废弃部分重量) / 食品重量 × 100%
废弃率 = 100% − EP(%)
```

### 1.2 1000 g 市品中某营养素含量

```text
X = A × 10 × EP

X：1000 g 市售食物中某营养素的含量（单位与 A 一致）
A：表中每 100 g 可食部中该营养素的含量
EP：表中可食部比例（%）
10：由 1000 g 市品折合成 100 g 时的换算系数
```

### 1.3 用户实际吃了多少

```text
可食部重量(g) = 市品重量(g) × EP(%) / 100
摄入某营养素 = A × 可食部重量(g) / 100
```

**注意**：表中 EP 是参考样品的统计值；实际样品因运输、贮藏、加工处理不同而变化，必要时可用**实测 EP** 替换。

## 2. 能量

- 表中能量 = 蛋白质×17 + 脂肪×37 + 碳水化合物×17 + 膳食纤维×8 + 酒精×29（单位 **kJ**）。
- `1 kJ = 0.239 kcal`；`1 kcal = 4.184 kJ`。表中通常同时给出 kcal 与 kJ。
- 若能量值右上角带 `*`，表示某个供能营养素未给出确定值，能量值也为**近似值**。

## 3. 蛋白质

- 表中蛋白质 = 食物总氮 × 该食物的**蛋白质转换系数**。
- 通用系数 6.25 仅适用于「总氮占蛋白质 16%」的一般食物；不同食物系数不同（原书表 6）。

| 食物 | 转换系数 |
|---|---|
| 鸡蛋 | 6.25 |
| 乳类 | 6.38 |
| 小麦 | 5.83 |
| 大米 | 5.95 |
| 大豆 | 5.71 |
| 花生 | 5.46 |

## 4. 碳水化合物

- 书中碳水化合物 = `100 − (水分 + 蛋白质 + 脂肪 + 灰分)`，为**总碳水化合物**，包含可利用碳水化合物和膳食纤维。
- 能量系数：可利用碳水化合物 **4 kcal/g**；膳食纤维 **2 kcal/g**。

## 5. 维生素 A（新版用 RAE，不是 RE）

```text
维生素 A (μg RAE) = 视黄醇(μg) + β-胡萝卜素(μg)/12 + 其他类型胡萝卜素(μg)/24
```

- 植物性食物通常只有胡萝卜素；当**不是**蔬菜类食物时，按 β-胡萝卜素计算结果可能**偏高**（植物中可能有 α/β-胡萝卜素混合物）。
- 换算：`1 μg RAE = 1 μg 视黄醇 = 12 μg β-胡萝卜素 = 24 μg 其他类胡萝卜素`。
- **与第 5 版（RE）数据不可直接比较。**

## 6. 维生素 E（α-TE）

```text
α-TE(mg) = 1.0×α-生育酚 + 0.5×β-生育酚 + 0.1×γ-生育酚 + 0.3×三烯生育酚
```

- 维生素 E 总和 = α + β + γ + δ-生育酚之和。
- `1 mg α-TE = 1.49 IU` 维生素 E。

## 7. 叶酸（DFE）

```text
总膳食叶酸 DFE(μg) = 天然食物叶酸(μg) + 1.7 × 强化食品叶酸(μg)
```

- `1 μg DFE = 1 μg 天然叶酸 = 0.5 μg 叶酸补充剂 = 0.6 μg 强化食品叶酸`。

## 8. 脂肪酸

- 脂肪酸含量以**每 100 g 食物中脂肪酸克数**表示。
- SFA / MUFA / PUFA 按以下公式计算：

```text
某类脂肪酸(g/100g) = 脂肪(g) × 脂肪酸转换系数 × 该类脂肪酸占总脂肪酸百分比
```

| 食物 | 脂肪酸转换系数 |
|---|---|
| 植物油 | ≈0.90 |
| 牛肉（瘦） | 0.720 |
| 猪肉（瘦） | 0.910 |
| 蛋 | 0.830 |

（完整表见原书表 7。）

- 单体脂肪酸用 INFOODS Tagname：`F + 碳原子数 + D + 双键数 + F`，例如 `C8:0 = F8D0F`，`C15:1 = F15D1F`。

## 9. 嘌呤（仅第二册）

- 第二册表六给出常见食物嘌呤含量，可用于痛风 / 高尿酸血症膳食管理。
- **注意**：嘌呤数据多来自文献 / 借用数据库，部分为不同烹饪状态，**不是**同一实验室统一样品测定。

## 10. DHA / EPA（仅第二册）

- 第二册表七给出部分鱼贝类 DHA、EPA 含量，常用于孕妇、婴幼儿、心血管风险人群的海鲜选择。

## 11. 合计一日 / 一餐摄入

1. 列出所有食物及其可食部重量。
2. 对每种食物分别查表并换算出各营养素摄入量。
3. 按营养素类别求和：能量（kcal / kJ）、蛋白质（g）、脂肪（g）与 SFA/MUFA/PUFA（g）、碳水化合物（g）与膳食纤维（g）、维生素与矿物质（注意单位统一）。
4. 需要供能比时：

```text
蛋白质供能比(%) = 蛋白质(g)×4 / 总能量(kcal) × 100%
脂肪供能比(%)   = 脂肪(g)×9 / 总能量(kcal) × 100%
碳水供能比(%)   = 碳水化合物(g)×4 / 总能量(kcal) × 100%
```

## 12. 与 DRIs 对比

- 数值一律取自 `references/dris-quickref.md`（本书附录 5 即《中国居民膳食营养素参考摄入量》口径）——**不得凭记忆填写**。
- 将「实际摄入量」与对应人群的 EAR / RNI / AI / UL 比较，判断是否充足或过量。
- 给出可执行建议：不足 → 推荐补充哪些食物；过量 → 建议减少或替换为低该营养素的替代品；特殊人群（痛风、肾衰、糖尿病等）→ 结合嘌呤、磷、钾、钠、GI 等专项数据做风险提示。
