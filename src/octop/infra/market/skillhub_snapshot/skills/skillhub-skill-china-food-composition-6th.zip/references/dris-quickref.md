<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# DRIs 速查表 ·《中国居民膳食营养素参考摄入量（2023 版）》

> **用途**：本技能所有"营养目标值"的唯一取数处。**不得凭记忆填写 DRIs 数值。**
> **主来源**：中国营养学会《中国居民膳食营养素参考摄入量（2023 版）》，人民卫生出版社，2023。
> **缩写**：EAR 平均需要量｜RNI 推荐摄入量｜AI 适宜摄入量｜UL 可耐受最高摄入量｜PI 预防非传染性慢性病建议摄入量｜AMDR 宏量营养素可接受范围。
> **版本纪律**：输出时如引用具体数值，**必须注明"依据 DRIs 2023 版"**；若用户或临床资料给出不同数值，以临床资料为准并说明差异。

---

## 一、成人能量需要量 EER（kcal/d，2023 版）

| 性别 | 年龄 | 参考体重 | PAL=1.40（低/久坐） | PAL=1.70（中） | PAL=2.00（高） |
|---|---|---|---|---|---|
| 男 | 18–29 | 65.0 kg | **2150** | 2550 | 3000 |
| 男 | 30–49 | 63.0 kg | **2050** | 2500 | 2950 |
| 男 | 50–64 | 63.0 kg | **1950** | 2400 | 2800 |
| 女 | 18–29 | 56.0 kg | **1700** | 2100 | 2450 |
| 女 | 30–49 | 56.0 kg | **1700** | 2050 | 2400 |
| 女 | 50–64 | 55.0 kg | **1600** | 1950 | 2300 |

- 基础能量消耗（BEE）参考：男 18–29 = 1510 kcal/d（23.2 kcal/kg·d）｜男 30–49 = 1481（23.5）｜男 50–64 = 1407（22.3）｜女 18–29 = 1223（22.0）｜女 30–49 = 1209（21.6）｜女 50–64 = 1148（20.9）。
- 体力活动水平（PAL）调整：每周每增加 1 小时中等强度活动，PAL +0.025；每增加 1 小时高强度活动，PAL +0.05。
- **配餐时的用法**：先用 Mifflin-St Jeor 算 BMR（见 SKILL.md §0 GATE-3 与 5.2），乘活动系数得 TDEE；再与本表 EER 交叉核对——两者差异 >20% 时，说明假设或数据可能有误，应复核。

## 二、成人（18–29 岁）维生素与矿物质

| 营养素 | 男 EAR | 男 RNI/AI | 女 EAR | 女 RNI/AI | UL | 备注 |
|---|---|---|---|---|---|---|
| 蛋白质 (g/d) | 60 | **65** | 50 | **55** | — | AMDR 10~20%E |
| 钙 (mg/d) | 650 | **800** | 650 | **800** | 2000 | UL 适用 4 岁以上；**年龄分档见下** |
| 磷 (mg/d) | 600 | 720 | 600 | 720 | 3500 | |
| 钾 (mg/d) | — | AI 2000 | — | AI 2000 | — | PI 3600 |
| 钠 (mg/d) | — | AI 1500 | — | AI 1500 | — | **PI ≤2000**（≈盐 5 g） |
| 镁 (mg/d) | 270 | 330 | 270 | 330 | — | |
| 铁 (mg/d) | 9 | **12** | 15 | **20** | 42 | 女 50 岁后降至 RNI 10 |
| 碘 (μg/d) | 85 | **120** | 85 | **120** | 600 | |
| 锌 (mg/d) | 10.1 | **12.5** | 6.13 | **7.5** | 40 | |
| 硒 (μg/d) | 50 | 60 | 50 | 60 | 400 | |
| 铜 (mg/d) | 0.62 | 0.8 | 0.62 | 0.8 | 8 | |
| 氟 (mg/d) | — | AI 1.5 | — | AI 1.5 | 3.5 | |
| 铬 (μg/d) | — | AI 35 | — | AI 35 | — | |
| 锰 (mg/d) | — | AI 4.5 | — | AI 4.5 | 11 | |
| 钼 (μg/d) | 20 | 25 | 20 | 25 | 900 | |
| 维生素 A (μg RAE/d) | 550 | **770** | 470 | **660** | 3000 | 女 50 岁~ 660、65 岁~ 640、75 岁~ 600；男 50 岁~ 750、65 岁~ 730、75 岁~ 710 |
| 维生素 D (μg/d) | 8 | **10** | 8 | **10** | 50 | 65 岁以上 RNI 15 |
| 维生素 E (mg α-TE/d) | — | AI 14 | — | AI 14 | 700 | |
| 维生素 K (μg/d) | — | AI 80 | — | AI 80 | — | |
| 维生素 B1 (mg/d) | 1.2 | 1.4 | 1.2 | 1.4 | — | |
| 维生素 B2 (mg/d) | 1.2 | 1.4 | 1.2 | 1.4 | — | |
| 烟酸 (mg NE/d) | 12 | 15 | 12 | 15 | 35 | |
| 维生素 B6 (mg/d) | 1.2 | 1.4 | 1.2 | 1.4 | 60 | |
| 叶酸 (μg DFE/d) | 320 | **400** | 320 | **400** | 1000 | |
| 维生素 B12 (μg/d) | 2.0 | 2.4 | 2.0 | 2.4 | — | |
| 维生素 C (mg/d) | 85 | **100** | 85 | **100** | 2000 | PI 200 |
| 泛酸 (mg/d) | — | AI 5.0 | — | AI 5.0 | — | |
| 生物素 (μg/d) | — | AI 40 | — | AI 40 | — | |
| 胆碱 (mg/d) | — | AI 450 | — | AI 450 | 3000 | |
| 膳食纤维 (g/d) | — | AI 25~30 | — | AI 25~30 | — | |
| DHA+EPA (g/d) | — | — | — | — | — | AMDR 0.25~2.0 |
| 水 (mL/d) | — | 1700 | — | 1700 | — | 高活动量/高温环境 3000 |

**宏量营养素可接受范围（AMDR）**：蛋白质 10~20%E｜总脂肪 20~30%E（饱和脂肪酸 <10%E）｜总碳水化合物 50~65%E｜添加糖 <10%E｜n-6 多不饱和脂肪酸 2.5~9.0%E｜n-3 多不饱和脂肪酸 0.5~2.0%E。

### 2.1 钙的分年龄档（★ 与上表并用，别一律套 800）

上表钙 RNI 800 mg/d 只覆盖 **18–49 岁**。钙随年龄升高，套错档会让"缺不缺钙"的结论偏差 20% 以上：

| 人群 | 钙 RNI (mg/d) | 说明 |
|---|---|---|
| 18–49 岁 | **800** | 上表基准档 |
| 50–64 岁 | **1000** | 骨量流失加速 |
| 65–79 岁 | **1000** | |
| ≥80 岁 | **1000** | |
| 孕期（早/中/晚） | **800** | 2023 版对成人基线未上调（见 §三）；部分临床指南与科普引 1000–1200，涉及孕期一律以产科医嘱为准 |
| 乳母 | **800** | 同上（2023 版不再单列 1000） |
| UL（成人） | 2000 | 4 岁以上通用 |

> **两条硬要求**
> 1. **年龄未知不得默认 800**：先问年龄（或至少问"是否 50 岁以上"），再选档；确实无法获知时，按 800 与 1000 两档**同时**给出结论（如"若 50 岁以下约 34%，50 岁以上约 27%"），并说明差异来源。
> 2. **来源分歧如实标注**：50 岁以上 1000 mg/d 系多份权威科普与临床指南对 2023 版的引述；孕期/乳母的 1000–1200 属旧版或临床口径。若与原书附录逐字不符，**以原书为准**。

## 三、孕期与哺乳期（在"未孕女性"基础上加量，2023 版）

| 营养素 | 未孕女性 | 孕早期 | 孕中期 | 孕晚期 | 乳母 |
|---|---|---|---|---|---|
| 能量 EER (kcal/d) | 1700 | +0 | **+250** | **+400** | **+400** |
| 蛋白质 RNI (g/d) | 55 | +0 | **+15** | **+30** | **+25**（合计 80） |
| DHA AI (mg/d) | — | 200 | 200 | 200 | 200 |
| 钙 RNI (mg/d) | 800 | +0 | +0 | +0 | **+0**（仍 800） |
| 铁 RNI (mg/d) | 20 | +0 | **+7** | **+11** | **+6**（合计 26） |
| 锌 RNI (mg/d) | 7.5 | +2 | +2 | +2 | +4.5（合计 12） |
| 碘 RNI (μg/d) | 120 | **+110** | **+110** | **+110** | **+120**（合计 240） |
| 维生素 A RNI (μg RAE/d) | 660 | +0 | **+70** | **+70** | **+600**（合计 1260） |
| 维生素 D RNI (μg/d) | 10 | +0 | +0 | +0 | +0 |
| 维生素 C RNI (mg/d) | 100 | +0 | +15 | +15 | +50（合计 150） |
| 叶酸 RNI (μg DFE/d) | 400 | **+200** | **+200** | **+200** | **+150**（合计 550） |

**注意**：
- 孕期叶酸 600 μg DFE/d 是**全孕期**目标，**孕前 3 个月就应开始**；UL 1000 μg DFE/d。
- 乳母能量 +400 kcal/d 是低活动水平口径；若 PAL 更高，按上表 PAL 调整。
- 乳母钙**不再是 1000 mg/d**（旧版口径），2023 版仍为 800 mg/d。
- 维生素 A 乳母 +600 应**优先由食物提供**（动物肝脏每周 1–2 次、每次 20–50 g 即可），**补充剂不可叠加**，UL 3000 μg RAE/d，孕早期过量有致畸风险。

## 四、婴幼儿与儿童青少年

### 4.1 1–3 岁（2023 版）

| 营养素 | EAR | RNI/AI | UL |
|---|---|---|---|
| 蛋白质 (g/d) | 1 岁 20｜2 岁 20｜3 岁 25 | **25｜25｜30** | — |
| 钙 (mg/d) | 400 | **500** | 1500 |
| 磷 (mg/d) | 250 | 300 | — |
| 钾 (mg/d) | — | AI 900 | — |
| 钠 (mg/d) | — | AI 500~700 | — |
| 镁 (mg/d) | 110 | 140 | — |
| 铁 (mg/d) | 7 | **10** | 25 |
| 碘 (μg/d) | 65 | **90** | — |
| 锌 (mg/d) | 3.2 | **4** | 9 |
| 硒 (μg/d) | 20 | 25 | 80 |
| 铜 (mg/d) | 0.26 | 0.3 | 2 |
| 氟 (mg/d) | — | AI 0.6 | 0.8 |
| 铬 (μg/d) | — | AI 15 | — |
| 锰 (mg/d) | — | AI 2.0（男）/1.5（女） | — |
| 钼 (μg/d) | 8 | 10 | 200 |
| 维生素 A (μg RAE/d) | 男 250 / 女 240 | **男 340 / 女 330** | 700 |
| 维生素 D (μg/d) | 8 | **10** | 20 |
| 维生素 E (mg α-TE/d) | — | AI 6 | 150 |
| 维生素 K (μg/d) | — | AI 30 | — |
| 维生素 B1 (mg/d) | 0.5 | 0.6 | — |
| 维生素 B2 (mg/d) | 0.6 / 0.5 | 0.7 / 0.6 | — |
| 烟酸 (mg NE/d) | 5 / 4 | 6 / 5 | 11 |
| 维生素 B6 (mg/d) | 0.5 | 0.6 | 20 |
| 叶酸 (μg DFE/d) | 130 | **160** | 300 |
| 维生素 B12 (μg/d) | 0.8 | 1.0 | — |
| 泛酸 / 生物素 | — | AI 2.1 mg / 17 μg | — |
| 胆碱 (mg/d) | — | AI 170 | 1000 |
| 维生素 C (mg/d) | 35 | **40** | 400 |
| 膳食纤维 (g/d) | — | AI 5~10 | — |
| 水 (mL/d) | — | 1300 | — |

**AMDR（1–3 岁）**：总脂肪 35%E｜亚油酸 4%E｜α-亚麻酸 0.6%E｜总碳水 50~65%E｜EPA+DHA 0.1~0.2 g/d。

### 4.2 4–17 岁

> ⚠️ **取数纪律**：4–17 岁各年龄性别的完整 DRIs **请查阅《中国居民膳食营养素参考摄入量（2023 版）》原表**；本文件**不转录**，以免转录错误。
> - 若必须给出具体目标值：**先向用户说明所引用的版本（DRIs 2023 版）**，给出数值时标注"参考值，建议以原表核对"。
> - 结构校验可直接用《中国学龄儿童膳食指南（2022）》平衡膳食宝塔按年龄档位量化（6–10 岁 1400–1600 kcal/d｜11–13 岁 1800–2000｜14–17 岁 2000–2400），详见 `references/modules-children.md`。
> - 儿科临床口径另见《中国儿童钙营养指南（2023）》（钙：7–18 岁 1000–1200 mg/d；维生素 D 400–800 IU/d 促吸收）与《儿童铁缺乏和缺铁性贫血防治专家共识》——**临床诊断与补剂剂量一律遵医嘱**。

### 4.3 0–6 月龄

纯母乳喂养，营养素需要量只适用于以母乳为唯一来源的婴儿；**出生后尽早补充维生素 D 400–800 IU/d**（中国儿童 VA、VD 临床应用专家共识 2021）。

---

## 五、使用纪律（每次给目标值前过一遍）

1. **版本**：引用数值必须注明"《中国居民膳食营养素参考摄入量（2023 版）》"；不得凭记忆填写。
2. **人群匹配**：先定性别 + 年龄 + 生理状态（孕/乳/疾病），再取对应行；孕期还要分早/中/晚。
3. **单位**：维生素 A 用 **μg RAE**（不是 RE/IU）；维生素 D 用 **μg**（1 μg = 40 IU）；维生素 E 用 **mg α-TE**；叶酸用 **μg DFE**。换算见 `references/conversions.md`。
4. **UL 不是目标**：UL 是安全上限，不是推荐量；达标看 RNI/AI。
5. **能量另算**：配餐用 BMR×PAL 算 TDEE（§0 GATE-3），本表 EER 用于交叉核对；两者差 >20% 要复核。
6. **特殊人群**：肾病、肝病、吸收障碍、透析患者**不得**按本表直接给目标，须临床营养师个体化制定 → 只给食物含量数据 + 建议就医。
7. **本文件未收录的数值**：明示"需查阅原表"，不要用近似值冒充。
