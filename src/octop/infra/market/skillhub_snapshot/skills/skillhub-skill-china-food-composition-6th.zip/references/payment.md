<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients
   or when the host cannot render components at all).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 支付端点与编排细则（SkillPay · 402 协议）

> 主文件 `SKILL.md` 的「收费与计次」只保留**标准时序、红线、报价纪律与降级话术**。
> 本文件是**端点细节与脚本 argv**，实现支付或排查支付问题时才需要读。
> **任何情况下，"先付后交付"与"不编造支付状态"两条不变。**

## 1. 端点

- `POST https://diet-nutrition-form.app.workbuddy.host/v1/orders`（与在线问卷同源；SkillPay 后台登记同一服务地址）

**请求体**（JSON，字段缺一会 422 拒单）：

```json
{
  "sku": "plan-7d",
  "client_ref": "会话内唯一编号（同一次交付重试用同一值）",
  "consult": {
    "name": "姓名",
    "sex": "女",
    "age": 32,
    "height_cm": 163,
    "weight_kg": 58,
    "pop": "普通成人",
    "prov": "河北省",
    "activity": "moderate",
    "goal": "fat_loss"
  }
}
```

**字段纪律（1.8.1 起强制）**：

| 字段 | 必填 | 取值 | 说明 |
|---|---|---|---|
| `consult.goal` | 是 | `fat_loss` / `muscle_gain` / `balance` | 决定能量缺口：−500 / +300 / ±0 kcal。**缺了曾静默按 `balance` 出餐单**（v1.8.0 实测：承诺减脂 1800 kcal，实际交付 2280 kcal）。填**交付目标**，不是表单复选框原文。 |
| `consult.activity` | 是 | `sedentary` / `light` / `moderate` / `active` | 决定 TDEE 系数 1.2 / 1.375 / 1.55 / 1.725。缺了曾静默按久坐算（TDEE 偏低 15–30%）。也可传中文档位（「中度（每周运动3-5次）」会被归一为 `moderate`）。 |
| `consult.height_cm` / `weight_kg` | 是 | 纯数值，不带单位 | BMR 计算必需。 |
| `consult.pop` | 是 | 成人 / 孕期 / 产后哺乳期 / 儿童（0–6岁）/ 儿童（6–12岁）/ 青少年（12–18岁）/ 老年（65岁以上）/ 健身（成人） | 与询问表 B 区一致。 |
| `consult.name` / `sex` / `age` / `prov` | 是 | — | 身份与地区。 |

> 缺 `goal` 或 `activity` 时服务端返回 `422 consult_incomplete`（`missing` 会点名），**不建单、不扣费**。看到 422 就补齐重发，不要换一种说法绕过。

**四种 4xx 不用重试、也不用换措辞再发**（都不是"环境故障"）：

| 状态 | `error` | 含义与处置 |
|---|---|---|
| `400` | `unknown_sku` | 档位名不在 §2 表里。核对后重发，不要猜。 |
| `422` | `consult_incomplete`（`missing` 附字段名） | 咨询项没齐。回到信息收集，补齐再发——**不要假定**。 |
| `422` | `redline` | 命中红线（肾/产褥急症/儿童或孕期急症）。只给成分数据 + 建议就医，**不报价、不重试**。 |
| `422` | `not_generatable`（`code=NO_SUBSTITUTE`） | 忌口组合把某类食材全排空了（如蔬果全忌），**服务端不建单、不收费**。告知用户"按当前忌口无法生成均衡餐单"，请其放宽某类忌口；**不要自己凑一份**。 |

## 2. SKU 档位（与服务端 `/v1/skus` 一致，错一个就 400）

| sku | 交付物 |
|---|---|
| plan-1d / plan-3d / plan-7d | 1 日 / 3 日 / 7 日餐单 |
| yuezi-42d | 月子餐 42 天（全六周） |
| yuezi-2w | 月子餐 本周+下周（14 天） |
| kid-plan | 儿童营养餐方案 |
| checkup-plan | 体检报告营养干预方案 |
| cycle-plan | 孕期 / 老年慢病周期方案 |

（当前同一登记价 3.90 元；档位差价需拆服务。）

**纪律**：付费端点只由「支付检查点」触发；免费项一律不触碰该端点。

### 2.1 交付后 48h 免费微调（必须走服务端，不得自行改写）

换菜不是"改几个字"：**内容一变，原签名即失效**。所以微调必须回到服务端重签，否则交付物不再可验签。

`POST https://diet-nutrition-form.app.workbuddy.host/v1/orders/<order_id>/revise`

```json
{
  "plan_id": "当前交付物的 plan_id（必须是手中最新那版）",
  "changes": [
    { "day": 3, "slot": "午餐", "from": "鸭胸肉（去皮）", "to": "鸡胸肉" }
  ]
}
```

- **等份替换**：只能在**同类别**内换（肉换肉、鱼换鱼、谷换谷），份数不变 ⇒ 营养目标与核算表不变。跨类别换（如"把米饭换成鸡肉"）会被拒，需要重新出方案。
- 返回 `200`：`content.plan_id` 是**新**编号，`content.plan.revision_of` 指向原计划，`content.plan.revision_no` 为第几次微调，`charged=false`。
- **呈现方式**：新 payload 同样**原样呈现 + 保留新 plan_id**；不要自己改旧表、也不要把新旧两版混着发。
- 免费窗口：交付后 48 小时内，**最多 5 次**；超窗口 → `410 revision_expired`，超次数 → `429 revision_limit`。这两种情况按"整体重做"计 1 次，需重新走支付。
- 拒绝码：`TARGET_NOT_ALLOWED`（目标食材属于该用户过敏/忌口）、`DISH_NOT_FOUND`（原菜品名不符，先核对是哪一天哪一餐）、`plan_mismatch`（plan_id 不是最新版）。
- 未交付订单 → `409 not_fulfilled`；订单不存在 → `404`。
- 微调**不计次、不改订单金额、不新建订单**；但也不得用它绕开付费——每次都要基于已付款订单的 plan_id。

### 2.2 交付呈现契约（哪些能给用户看、哪些绝对不能）

payload 里的 `presentation` 字段就是这份契约，**以其为准**；下面是人读版。

**必须呈现（`presentation.show`）**

| 内容 | 呈现方式 |
|---|---|
| `plan.targets` | 营养目标表（能量/蛋白/脂肪/碳水，中文单位） |
| `plan.days` | 逐日餐单：餐次 + 菜品 + 市品克数；按第 1 天…第 N 天分节 |
| `plan.actuals` | 核算合计与达成率 |
| `plan.shopping_list.items` | 采购清单：逐项照抄 `food` + `grams`，**禁止自行累加** |
| `plan.method_note` | 方法说明（交换份法、BMR×活动系数、DRIs 2023） |
| `plan.disclaimers` | 免责声明（估算值、不替代诊疗） |
| `after_sale.hint` | 售后微调说明（48h / 5 次 / 怎么提） |
| `plan_id` | 方案编号，**必须可见**（用于微调与查证） |

**绝不能出现（`presentation.hide`）**

| 字段 | 为什么 |
|---|---|
| `signature`（顶层与 `plan.signature` **两处都有**） | 64 位十六进制签名，属内部验签材料 |
| `deliver_token` | 交付令牌，等同于取货凭证 |
| `sku`（`plan-7d` 等） | 内部档位代码，用户只认"7 日餐单" |
| `order_id` / `out_trade_no` / `trade_no` | 支付与订单标识，不应进入对话 |
| `exchanges_per_day` | 交换份代码（`veg` / `vegB` / `fat_loss`），对用户无意义 |
| `consult_snapshot` | 原始咨询字段（含 `activity: sedentary` 这类内部值） |
| `applied_exclusions` | 原始数组；应改写成「已按您的忌口排除：虾、羊肉」 |
| `generated_at` / `revised_at` / `note` / `type` | 机器字段 |
| 文件路径、`data/*.json`、常量名 | 实现细节，用户不需要 |
| 任何原始 JSON 片段 | 交付物是餐单，不是接口响应 |

**改写示例**

- ❌ `已执行的排除：["虾","羊肉"]`　✅ `已按您的忌口排除虾和羊肉`
- ❌ `每日交换份：谷类 6 份｜蔬菜（veg）1 份｜蔬菜B 0.5 份`　✅ `每日份量：主食 6 份、蔬菜 1.5 份、水果 1 份、蛋 1 个、鱼 1 份、奶 1.5 份、豆制品 1 份、肉 0.5 份、油 1 份`
- ❌ `签名：e5a66f65…`　✅ 不出现
- ❌ `data/exchange-foods.json`　✅ 不出现（方法说明里写"食品交换份法"即可）

**配餐类交付的两项补充**

- `采购清单`：**直接照抄 `plan.shopping_list.items`**（服务端已按 `food` 逐项合计好 `food` + `grams`，按类别排序）。**不要自己累加**——实测手工求和会漏行（6×35g 面包写成 175g），用户照单采购就缺料。不同 `food` 不得合并、也不得声称"已折算"：`米饭（熟）` 与 `大米（生）` 是两笔，用户两样都得有。
- `可食部换算表`：**不产出**——payload 的克数已经是市品当量，不含可食部比例（EP），由克数反推可食部就是编造。用户明确要可食部数值时，走查表流程（`references/examples.md`），不要从 payload 换算。

**边界**：`plan_id` 是唯一必须保留的技术标识——它是微调与查证的锚点；其余内部字段一律不出现在面向用户的回复里，**也不要"原样贴 JSON 再解释"**。

## 3. Skill 侧支付编排（probe → pay → complete）

支付能力封装在 `scripts/a2m-pay.js`。它只做「发起请求 / 把账单交给官方能力 / 复用原订单取回资源」，**不接触密钥、不自行实现签名、不自行拼装支付参数**。

**依赖**：Node.js ≥ 18（用内置 `fetch`，零第三方依赖）；官方买家支付能力 `alipay-bot`。
未安装时脚本以退出码 `4` 明确报错并给出安装命令（`npx -y @alipay/agent-payment@latest install`），**不静默降级**。

| 步骤 | 命令 | 作用 |
|---|---|---|
| 1 · probe | `node scripts/a2m-pay.js probe --url <业务端点> --method POST --data <原请求体> --header 'Content-Type: application/json' --state-dir <状态目录> --session-key <会话键>` | 发起原请求；未付款时取回 `402` 账单，并**原样保存原始请求**供后续复用 |
| 2 · pay | `node scripts/a2m-pay.js pay --state-dir <状态目录> [--intent-summary '<用途说明>']` | 把账单与原请求交给官方支付能力，展示支付入口、**等待用户授权** |
| 3 · complete | `node scripts/a2m-pay.js complete --state-dir <状态目录>` | 状态不明先**查单**：用原订单号复用同一请求取回资源，**不重新下单** |

脚本内部封装的就是官方 CLI 的两个子命令（`alipay-bot 402-buyer-pay` / `alipay-bot 402-query-payment-status`）；
分工与契约详见 `scripts/README.md`。**`--dry-run` 只打印将要执行的命令，用于联调留痕，不真正发起。**

## 4. 硬约束

1. **原请求参数保持一致**：`pay` / `complete` 只从 `probe` 落地的状态文件读取请求，**不重新拼装** `url` / `method` / `body` / 业务 Header。
2. **先付后交付**：只有 `complete` 取回资源（`200` + `deliver_token`）后才产出全量；`402` 阶段产出物**只到第 1 天样例**。
3. **全量 = 服务端 payload**（v1.7.0 起）：资源体含 `plan_id` + `signature` + 完整逐日餐单，由服务端生成。呈现时**原样输出 payload 内容并保留 `plan_id`**；工具返回里没有 `plan_id` ⇒ 没有全量，**不得自行编造、拼凑或"补全"**——无 `plan_id` 的逐日内容一律不得作为交付物呈现。
4. **微调只能走 `revise` 端点**：不得手改 payload 里的逐日内容再当交付物（会失去签名）。48h 内免费、最多 5 次；新 payload 有新 `plan_id`，照原样呈现。
5. **状态不明先查单**：不确定是否已付款 → 走 `complete`，**不重复调用 `pay`**；同一订单重试不重复扣费、不重复交付。
6. **凭据不外泄**：不得向用户展示或转述账单原文、`Payment-Needed` 等凭据，一律不进面向用户的话术；脚本只回传脱敏摘要。
7. **只传业务 Header**：`Authorization` / `Payment-Proof` / `Host` / `Content-Length` / `Sign` / `Timestamp` 等控制头**不转发**，身份与签名由官方能力管理。
8. **触发前先报价等确认**：用户未确认前不发起 `probe`。

## 5. 验证留痕

`probe` 对已登记的生产业务端点真实请求 → 拿到 `402` 与 `seller_sign_type=RSA2` 的签名账单 → 账单文件可被官方 `alipay-bot 402-buyer-pay` 正常解析 → 停在等待买家授权的付款确认前（**买卖家不能是同一支付宝账号**，后续真实付款需由买家账号完成）。离线分支回归：`node scripts/selftest.js`。

## 6. 降级路径

**若当前环境连 Node 都没有**（云端沙箱即如此：`node: command not found`），脚本**根本跑不起来**。
此时**照实告知**用户：「本会话未能拉起支付入口，请点开收银链接，扫码完成付款后回来。」

- **不得**因此免费交付全量；
- **不得**编造支付状态，**不得**声称「支付端返回 402」「支付失败」「当前环境无法付款」（**没有真实调用，就不能描述调用结果**）；
- 第 1 天样例已免费给出，可先让用户用着。
