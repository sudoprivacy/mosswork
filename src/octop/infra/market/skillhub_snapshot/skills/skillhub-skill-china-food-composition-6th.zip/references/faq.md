<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# FAQ：常见问题与错误输入处理

> 主文件 `SKILL.md` 第九章只留三条最常踩的坑与「输出前自检清单」。本文件是 9.1–9.5 全文。
> 输出前自检清单在 `SKILL.md` §9.6，**每次回答前都要过一遍，不在本文件**。

## 9.1 输入不规范怎么处理

| 用户说法 | 正确处理 |
|---|---|
| 「一碗米饭多少热量」（无重量） | 先给常见碗型的估算区间（如家庭小碗熟米饭约 150–200 g）并**请用户确认**，不要直接当精确值计算 |
| 「红烧肉」（复合菜名） | 拆解为原料（五花肉 + 糖 + 酱油 + 油），分别查表并**明示拆解假设**；不要按单一食材查表 |
| 「吃了点青菜」（口语名、无具体品种） | 先映射到代表条目（如「小白菜」或「油菜」）并**注明映射假设**，再换算 |
| 「100 克鸡腿」 | 追问是**带骨市品**还是**去骨可食部**；按可食部换算口径处理 |
| 「某某牌子的酸奶」 | 商业产品配方差异大 → 优先看包装营养标签，表中品牌旧数据仅作参考 |
| 用「一个」「一杯」「一盘」描述 | 先给估算值 + 常见重量区间，请用户确认后再核算 |
| **渲染不了询问表**（无组件宿主 / 组件报错） | 把必需项写成编号问题**一次性**问齐；可另给线下版页面 `https://diet-nutrition-form.app.workbuddy.host/form.html` 供用户自行填写。**环境不支持渲染不构成跳过信息收集的理由**，但**能渲染时不得用链接替代表单** |

## 9.2 查不到数据怎么办（数值来源三层纪律）

**先认清一件事**：本技能随包只带了 DRIs 速查表（`references/dris-quickref.md`），**没有随带原书几百页的成分表数据**。
所以「查不到表值」是常态，不是故障。此时不要卡住，按下面的三层来源走。

### 三层来源（自上而下，能用上层就不用下层）

| 层 | 来源 | 可否直接报数 | 标注要求 |
|---|---|---|---|
| **L1** | 服务端下发（付费餐单的 `plan.days[].meals[].dishes[]` / `plan.shopping_list`） | 可以，且**必须照抄** | 无需额外标注；这是唯一权威 |
| **L2** | 用户自己提供（原书条目截图/数值、包装营养标签、体检报告） | 可以，按用户给的值精确计算 | 注「按你提供的数值计算」 |
| **L3** | 通行参考值（你对常见食物的稳定认知） | 可以，但**只给区间/约数** | 三件套见下 |

### L3 的三件套（缺一即违规）

1. **给区间，不给单点**：写「约 110–120 kcal」「碳水约 25–26 g」，不写「116 kcal」「碳水 25.9 g」。
2. **标口径与出处路径**：注明「每 100 g 可食部」+ 该食物在原书的位置（第几册 → 哪个表 → 哪个食物类别）。
3. **给核对提示**：一句「精确值以原书该条目为准」。

### 两种绝对禁止的形态

- ❌ **伪精确**：三位有效数字的表值（如「蛋白质 7.94 g」「能量 116 kcal」）——没有数据源支撑的精确度就是编造。
- ❌ **伪造条目编码**：不得编「食物编码 01101」这类原书编号冒充查表结果。路径可以说，编码不许编。

### 其他情形

1. **本书未收录**（如进口食品、品牌产品、新式代餐）：明示「本书未收录」，再按 L3 给区间或建议看包装营养标签。
2. **同类近似**：必须标「**以 X 近似，非原食物数据**」（如「某进口浆果」→ 参照同科浆果）。
3. **营养素维度缺失**（如某食物无嘌呤数据）：如实说明「**仅第二册有嘌呤数据**」，不要用其他营养素的存在暗示嘌呤也有值。
4. **用户问「精确到小数点」**：直接说明本技能无原书表值源，请提供原书条目或营养标签，你按 L2 精确换算——**换算与核算是本技能的强项，报表值不是**。

## 9.3 表格符号与口径

| 符号 | 含义 |
|---|---|
| `x` | 代表值（多条数据的中位数或均数） |
| `Tr` | 未检出或微量，低于检测限 |
| `(0)` | 估计 0 值，理论上为 0 或测定后为 0 |
| `*` | 参考相似食物或原料数据计算而得 |
| `—` | 未检测 |
| `un` | 不能计算或未测定 |

**要点**：`Tr` ≠ 0，`—` / `un` ≠ 0。**不能把缺项当 0 参与求和**，遇到要明确告知数据缺失。

其他口径：

- 表中所有数值默认是 **每 100 g 可食部**；市品必须用「食部」栏换算。
- 能量单位注意 kJ 与 kcal 的区分与换算（`1 kcal = 4.184 kJ`）。
- 本书碳水为**总碳水化合物**（含膳食纤维），与「可利用碳水」口径不同。
- VA 新版用 **RAE**，与第 5 版的 RE **不可直接比较**。

## 9.4 收费相关

| 问题 | 回答 |
|---|---|
| 「查一下要钱吗？」 | 查询、可食部换算、摄入量评估与 DRIs 对比**全部免费**；只有产出完整餐单/方案按次收费 |
| 「填表要钱吗？」 | 信息收集全程免费，包括追问与确认 |
| 「多少钱？」 | 技能内**不报具体金额**，只说「需要 1 次配餐额度」；价格以 SkillPay 后台配置为准 |
| 「能先看看吗？」 | 付费配餐**先免费给第 1 天样例** + 该日核算表；**红线场景连样例也不出** |
| 「改一下菜要再付吗？」 | 已付费方案在当前会话内免费改；跨会话但交付后 48 小时内同类微调也免费；超 48 小时或整体重做 → 计 1 次 |
| 「支付没成功怎么办？」 | 照实说明当前环境能否拉起支付入口：优先官方支付能力（智能体内用支付宝付款）；确实拉不起时引导点开收银链接、扫码完成付款后回来。**不得**因此免费交付全量，**不得**编造支付状态 |
| 用户已回「确认」，但没弹出支付？ | 说明这是按次付费交付，需完成支付才能出全量；先真实调用 `probe → pay` 拉起入口，拉不起就照实说明并引导客户端付款，**不得**就近免费交付 |
| 支付还没完成，可以先给全量吗？ | **不可以。** 付费项在拿到 `200` + `deliver_token` 前，产出物永远停在「第 1 天样例」 |

## 9.25 方法适用边界（在什么场景下有效，什么场景下会翻车）

**有效场景**：查中国常见食物能量/宏量营养素/维生素/矿物质｜把"买菜重量"换算成"实际吃进肚子的可食部重量"｜膳食回顾、食谱编制、营养宣教｜评估供能比及与 DRIs 的差距｜痛风参考嘌呤（第二册）｜孕妇/婴幼儿参考 DHA、EPA（第二册）与叶酸、碘。

**会翻车的场景**：

- **数据年份**：第 6 版主要反映 2002–2016 年检测与合并值；近年新品种、新加工/强化/进口食品可能未收录或数值已变。
- **地区与品种差异**：多采样自北京、河北、广东等地，换地区换品种后实际含量可能不同。
- **烹饪损失/添加**：多数为"生、鲜"或标准烹饪状态；家庭烹饪的油盐糖水会改变最终摄入值。
- **含量 ≠ 生物利用率**：植物性铁吸收率低、植物烟酸多为结合型、钙受草酸影响。
- **符号缺项**：`— / un / * / Tr` 不能当 0；未检测不等于没有。
- **药物/疾病状态**：肾病、肝病、吸收障碍患者不能按成分表做医学处方，需临床营养师/医生个体化调整。
- **商业产品配方变化**：同一商品名配方差异大，优先看包装营养标签。
- **单位混淆**：VA（RAE vs RE vs IU）、VD（μg vs IU）、VE（mg vs α-TE vs IU）、叶酸（μg vs DFE）极易换算错误。

**最佳实践**：先看"食物样品描述"确认条目是否匹配用户手中食物状态｜带废弃部的食物优先用"食部"栏换算｜多日评估取 3–7 天平均值｜输出一律标注"估算值""参考值"。

## 9.5 边界与什么情况下不给方案

**命中以下情况 → 只给食物营养含量数据 + 建议就医，不出餐单、不报价、连免费样例也不出：**

| 红线场景 | 判定信号 | 处理 |
|---|---|---|
| 肾功能异常 | 肌酐↑ / eGFR↓ / 尿蛋白 / 透析 | 蛋白、钾、磷限量须临床营养师个体化制定 → **只给含量数据 + 建议就医** |
| 产后急症 | 发热 ≥38.5℃ / 寒战 / 恶露臭秽量突增 / 乳房红肿热痛+高热 / 中暑意识障碍 | 立即就医，食疗仅作恢复期辅助 |
| 儿童急症 / 重度异常 | 中重度贫血（Hb<90 g/L）/ 生长迟缓消瘦 / 肥胖伴黑棘皮病·打鼾憋气·血压高 | 就医评估，食疗仅辅助；**禁用成人减肥方案** |
| 孕产急症 | 妊娠并发症、出血、剧烈腹痛、胎动异常 | 优先产科，膳食建议仅辅助 |
| 情绪危机 | 持续低落 >2 周或有自伤念头 | 建议就医/心理支持，不做食疗方案 |

**其他不给方案的情形**：

- 糖尿病已用药 / 胰岛素：碳水分配须与用药匹配，否则低血糖风险 → 必须提示咨询医生。
- 指标严重异常或多项联动异常 → 优先就医。
- 不得由单项指标推导结论（如「胆固醇高就完全戒蛋」）。
- 所有输出必须带免责声明。
