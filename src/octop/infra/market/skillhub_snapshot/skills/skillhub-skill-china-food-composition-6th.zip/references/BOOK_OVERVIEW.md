<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 中国食物成分表（标准版·第6版）蒸馏总览

## 1. 书籍属性

| 项目 | 内容 |
|------|------|
| 书名 | 《中国食物成分表 标准版 第6版》（第一册 / 第二册） |
| 主编 | 杨月欣 |
| 出版社 | 北京大学医学出版社 |
| 第一册 | 2018年7月，植物性食物为主，3300余条食物、57000余个数据 |
| 第二册 | 2019年8月，动物性食物为主，3600余条食物、75600余个数据 |
| 定位 | 工具书 / 食物营养成分参考数据库 |
| 核心读者 | 营养师、临床营养工作者、科研人员、疾控人员、食品工业从业者 |

## 2. 工具书判定

本书不是叙事性著作，而是**可执行的营养数据工具书**，其价值体现在：

- 提供经过实验室检测/代表值计算的**食物营养成分数值**；
- 定义了统一的**食物分类、编码、计量、数据符号**；
- 给出了**可食部换算、能量换算、蛋白质换算、维生素A换算**等可执行公式；
- 包含**膳食计算、营养评估**所需的全套使用说明。

因此应提取：**可执行的查询步骤、换算公式、决策逻辑、适用边界**。

## 3. 核心方法论骨架

```
使用中国食物成分表的7步流水线：

明确问题 → 选定分册 → 查找食物 → 读取数值 → 可食部换算
         → 营养素换算/合计 → 与DRIs对比/输出方案
```

关键支持规则：

1. **分册规则**：
   - 第一册：谷类、薯类淀粉、干豆类、蔬菜、菌藻、水果、坚果种子、植物油；
   - 第二册：畜肉、禽肉、乳类、蛋类、鱼虾蟹贝、婴幼儿食品、动物油脂、其他；
   - 第二册特有：嘌呤含量、DHA/EPA 含量。

2. **编码规则**：6位数字，前2位=食物类别，第3位=亚类，后3位=序号。

3. **数值基础**：所有营养成分均以“**每100克可食部**”计。

4. **可食部换算**：
   - EP = (食品重量 − 废弃部分重量) / 食品重量 × 100%；
   - 1000g市品中某营养素含量 = A × 10 × EP（A 为表中每100g可食部含量）。

5. **能量换算**：能量(kcal/kJ) = 蛋白质×17kJ + 脂肪×37kJ + 碳水化合物×17kJ + 膳食纤维×8kJ + 酒精×29kJ（再换算 kcal）。

6. **关键营养素特殊表达**：
   - 维生素A：视黄醇活性当量 RAE，β-胡萝卜素/12、其他类胡萝卜素/24；
   - 维生素E：α-生育酚当量 α-TE；
   - 叶酸：膳食叶酸当量 DFE；
   - 蛋白质：总氮 × 食物特异性转换系数（6.25 只是通用系数，不同食物不同）。

7. **数据符号**：
   - `x`：代表值；`Tr`：未检出/微量；`(0)`：估计0；`*`：参考值或计算值；
   - `—`：未检测；`un`：不能计算或未测定。

## 4. 可蒸馏的技能单元

本次蒸馏为单一技能：**《中国食物成分表 标准版 第6版 使用法》**，把上述全部规则封装为可调用流程。

触发条件：用户遇到“食物营养成分怎么查、怎么换算、怎么评价”类问题。

## 5. 各表清单与定位（"要查什么 → 查哪张表"）

| 问题类型 | 表 / 数据 | 说明 |
|---|---|---|
| 一般营养成分（能量、水、蛋白质、脂肪、碳水、膳食纤维、灰分、维生素、矿物质） | 表一"能量和食物一般营养成分" | 两册均有，按食物类别查找 |
| 氨基酸含量 | 表二"食物氨基酸含量" | 两册均有 |
| 脂肪酸组成 | 表三"食物脂肪酸含量" | 两册均有 |
| 碘含量 | 表四"常见食物碘含量" | 两册均有 |
| 叶酸、胆碱、生物素、泛酸 | 表五"食物中维生素含量" | 两册均有 |
| 植物固醇、类胡萝卜素、黄酮等 | 表六"食物中植物化学物含量" | 仅第一册 |
| 嘌呤含量 | 表六"常见食物嘌呤含量" | 仅第二册 |
| DHA / EPA | 表七"部分食用鱼贝类中 DHA 和 EPA 含量" | 仅第二册 |

## 6. 两册食物类编码速查

```text
第一册：01 谷类及制品   02 薯类、淀粉及制品   03 干豆类及制品   04 蔬菜类及制品
        05 菌藻类       06 水果类及制品       07 坚果、种子类   08 植物油
第二册：08 畜肉类及制品 09 禽肉类及制品       10 乳类及制品     11 蛋类及制品
        12 鱼虾蟹贝类   13 婴幼儿食品         19 油脂类（动物） 21 其他
```

编码示例：`045401` = 第 04 类"蔬菜类及制品" → 第 5 亚类"嫩茎、叶、花菜类" → 第 401 号"竹笋"。

## 7. 来源索引

- 来源文件：
  - `E:/食物成分表/中国食物成分表 标准版 第一册 第6版.pdf`（第1–24页 使用说明/目录/样品描述）
  - `E:/食物成分表/中国食物成分表 标准版 第二册 第6版 .pdf`（第2–24页 版权/目录/使用说明，通过图片阅读）
- 蒸馏产物：
  - `SKILL.md`
  - `test-prompts.json`
  - `BOOK_OVERVIEW.md`（本文件）
