<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 第八章（全文）· 儿童营养餐（0–18 岁）

> 本文件是 SKILL.md「八、扩展模块：儿童营养餐（0–18 岁）」的完整版。SKILL.md 只保留分阶段要点与红线，细节在此。

> **分层来源声明**（输出时保留标注）：
> - **喂养/膳食指南层**：《中国婴幼儿喂养指南（2022）》（0–6 月龄、7–24 月龄、学龄前三册）与《中国学龄儿童膳食指南（2022）》及平衡膳食宝塔。
> - **专家共识层**：《中国儿童维生素 A、维生素 D 临床应用专家共识（2021）》《儿童铁缺乏和缺铁性贫血防治专家共识》《儿童过敏性疾病诊断及治疗专家共识（2019）》《中国儿童肥胖诊断评估与管理专家共识（2022）》。
> - **成分表核算层**：本技能第一~六章（儿童按年龄性别查 `dris-quickref.md`、可食部换算、餐单核算）。

## 8.1 输入判断

先确认四要素：① 月龄/年龄段（0–6 月 / 6–24 月 / 2–5 岁 / 6–12 岁 / 12–18 岁）；② 喂养/饮食现状（母乳/配方/混合；在校就餐等）；③ 体检或生长数据（身高体重曲线、Hb、VD 等，有则走 8.4 问题干预）；④ 特殊情况（过敏史、慢病、挑食）。问题类型：

1. "帮我排儿童一日/一周餐单" → 按年龄段走 8.2/8.3，输出前按 8.5 核算。
2. "孩子体检提示贫血/超重/VD 不足…怎么吃" → 8.4 映射表。
3. "怎么加辅食/一顿吃多少" → 8.2 辅食规则与宝塔量化。

## 8.2 分阶段喂养要点

**0–6 月龄**：纯母乳喂养，按需哺乳；无法母乳者选符合国标的配方奶。出生后尽早补充维生素 D 400–800 IU/d（共识 2021）。不喂水、不加任何食物。

**6–24 月龄（辅食期）**：
- 满 6 月龄起添加辅食，首先添加富含铁的泥糊状食物（强化铁米粉、红肉泥、肝泥）；
- 每次只引入一种新食物，观察 3–5 天再添下一种；由少到多、由稀到稠、由细到粗；
- 1 岁以内不加盐、糖和蜂蜜（蜂蜜有肉毒杆菌风险）；尽量少加糖盐、保持原味，油脂适当；
- 提倡回应式喂养（观察孩子饥饱信号，鼓励但不强迫进食）；注重进食安全（坐位进食、防呛噎，整粒坚果果冻禁给 5 岁以下）；
- 过敏高风险家庭：纯母乳至少 4–6 月龄，必要时在医生指导下用部分水解配方；辅食不刻意推迟致敏食物引入，常规引入、保持多样化摄入（过敏共识 2019）。

**2–5 岁（学龄前）**：家庭膳食为主、清淡少盐；每天 3 次正餐 + 2 次加餐；每天奶及奶制品 300–500 ml；足量饮水，不喝含糖饮料。

**6–17 岁（学龄儿童）**：核心推荐五条——主动参与食物选择和制作；吃好早餐（早餐含谷薯/蔬果/动物性食物/奶豆坚果四类中的三类及以上）、合理选零食；天天喝奶（≥300 ml）、足量饮水（800–1400 ml）、不喝含糖饮料、禁止饮酒；每天累计 ≥60 分钟中高强度身体活动、视屏 <2 小时；定期监测体格发育。

## 8.3 学龄儿童平衡膳食宝塔（2022，按年龄量化）

| 食物类别 | 6–10 岁（1400–1600 kcal/d） | 11–13 岁（1800–2000 kcal/d） | 14–17 岁（2000–2400 kcal/d） |
|---|---|---|---|
| 谷类（含全谷杂豆） | 150–200 g（全谷杂豆 30–70） | 225–250 g（30–70） | 250–300 g（50–100） |
| 薯类 | 25–50 g | 25–50 g | 50–100 g |
| 蔬菜 | ≥300 g | 400–450 g | 450–500 g |
| 水果 | 150–200 g | 200–300 g | 300–350 g |
| 畜禽肉 | 40 g | 50 g | 50–75 g |
| 水产品 | 40 g | 50 g | 50–75 g |
| 蛋类 | 25–40 g | 40–50 g | 50 g |
| 奶及奶制品 | ≥300 g | ≥300 g | ≥300 g |
| 大豆（周） | 105 g | 105 g（每日折算） | 105–175 g（周） |
| 坚果（周） | 50 g | 50–70 g | 50–70 g |
| 盐 | <4 g/d | <5 g/d | <5 g/d |
| 烹调油 | 20–25 g/d | 25–30 g/d | 25–30 g/d |
| 饮水 | 800–1000 ml/d | 男 1300/女 1100 ml/d | 男 1400/女 1200 ml/d |

2–5 岁参照 6–10 岁档下限并进一步软烂清淡。学龄前儿童餐单结构：每餐主食+优质蛋白+蔬菜，加餐选奶类、水果、少量坚果（安全处理）。

## 8.4 常见营养问题：体检/症状 → 膳食干预映射

| 问题 | 判断要点（供提示，非诊断） | 膳食干预方向 | 用到的数据/边界 |
|---|---|---|---|
| 铁缺乏（ID）/缺铁性贫血（IDA） | Hb：6 月龄–5 岁 <110、5–12 岁 <115、12–15 岁 <130、15 岁以上男 <130/女 <120 g/L；筛查时点：3、6、9、12 月龄，1.5、2、2.5、3 岁，之后每年 1 次 | 增加血红素铁（红肉、肝、血）+ 餐间维 C 促吸收，避浓茶同餐；每周动物肝脏 1–2 次（每次 20–50 g） | ⚠️ 确诊 IDA 属治疗问题：元素铁 3–6 mg/(kg·d) 遵医嘱、4 周复查 Hb 升 ≥10 g/L 确诊性治疗；南方小细胞贫血先排地贫（Mentzer 指数），本技能不替代诊断 |
| 维生素 D 不足/佝偻病风险 | 30(25)OH-D 下降；多汗、夜惊、方颅等仅作提示 | 食物（乳类、蛋黄、海鱼）+ 日照 1–2 h/d | 预防剂量 400–800 IU/d（出生后尽早开始至青春期）；早产/低体重/双胎 800 IU/d×3 月后转 400–800；补剂遵医嘱 |
| 维生素 A 缺乏风险 | 边缘型 VA 缺乏多见；夜盲、皮肤干燥为重度信号 | 深色蔬果（南瓜、胡萝卜、西兰花、芒果、橘子）、乳蛋肝 | 婴儿出生后可补 VA 1500–2000 IU/d 至 3 岁；早产/低体重/多胎前 3 个月按上限；反复呼吸道感染、腹泻、缺铁性贫血儿童可相应增量（共识表）；勿超量 |
| 超重/肥胖 | ≥2 岁 BMI 按性别年龄别界值；<2 岁用身长的体重 Z 评分（>2 超重、>3 肥胖）；腰围身高比男 >0.48、10 岁后女 >0.46 提示代谢风险 | **不节食、不快速减重、保证生长发育**：红绿灯食物管理（绿灯优选蔬果奶、黄灯限制精制糖糕点油炸、红灯不宜含糖饮料），每天 12 种以上食物；控总量调结构 | 减重速度上限：2–5 岁/6–11 岁轻中度 ≤0.5 kg/月，6–11 岁重度与 12–18 岁 ≤0.9 kg/月；每天 60 min 中高强度运动 + 睡眠干预；<16 岁超重不建议减肥药；餐单输出必须附"生长监测"提示 |
| 过敏性疾病（牛奶蛋白过敏、湿疹等） | 已确诊过敏原者严格回避；高风险婴儿预防见 8.2 | 回避过敏原的同时找替代蛋白（如牛奶过敏用深度水解/氨基酸配方遵医嘱），保证能量与蛋白达标 | ⚠️ 急性过敏发作（呼吸困难、全身荨麻疹）立即就医；回避方案需营养师/医生核对防营养不良；益生菌仅用于湿疹预防 |
| 挑食偏食/生长缓慢 | 生长曲线连续下滑超一条主百分位 | 回应式喂养、固定餐位、家长示范、孩子参与选购制作；不强迫进食、不拿零食当奖励 | 生长迟缓/消瘦（体重身高比异常）先就医排查疾病，再作膳食强化 |
| 青春期减重误区 | 盲目节食、催吐、"液断" | 按学龄指南均衡饮食 + 运动；女生注意铁丢失（月经）补铁 | ⚠️ 进食障碍信号（催吐、极度限食、体像障碍）转专科 |

## 8.5 与成分表核算层联动

1. 目标值：按儿童年龄、性别查 `dris-quickref.md`（DRIs 2023 版；1–3 岁已收录，4–17 岁需查原表并明示版本），青春期男女生差异大，分别取值。**不得凭记忆填写 DRIs 数值。**
2. 餐单核算：第一~六章流程（可食部换算→求和→供能比），儿童加算**添加糖（<50 g/d，最好 <25 g）与钠**；奶量单独核。
3. 结构校验：每天 12 种以上食物、每周 25 种以上（肥胖共识要求，常规餐单也应尽量满足）。

## 8.6 红旗与安全边界（儿童专属）

- 中重度贫血（Hb <90 g/L）、生长迟缓/消瘦、肥胖伴黑棘皮病/打鼾憋气/血压高 → 就医评估，食疗仅辅助；
- 5 岁以下禁整粒坚果、果冻、大块圆滑食物（窒息风险）；
- 1 岁内禁蜂蜜、鲜奶作主饮、加盐；
- 儿童禁用成人减肥方案（生酮自疗、代餐节食、减肥茶药）；儿童补剂（VA/VD/铁/钙）剂量遵医嘱，不叠加多种强化食品+补剂防过量；
- 输出必须声明：本方案为膳食参考，儿童生长与疾病问题请以儿科/儿童保健科随访为准。

> **命中上述红旗 → 不出餐单、不报价、连免费样例也不出**，只给食物营养含量数据 + 就医建议。

## 8.7 输出模板

```markdown
## 儿童营养餐方案
1. 基本情况：X 岁X 月｜性别｜喂养/就餐方式｜生长数据（有则列）
2. 阶段定位：喂养要点（8.2）或宝塔量化（8.3 对应列）
3. 一日/一周餐单：正餐+加餐，标注市品重量；零食与奶量安排
4. 核算：能量 XXXX kcal（vs 该年龄 DRIs 达成率 X%）、蛋白质、钙/铁/VA/VD 关键项；盐与添加糖
5. 问题干预（如适用）：8.4 对应行方向 + 就医/复查提示
6. 安全提示：窒息风险食物、补剂遵医嘱、生长监测建议
7. 免责声明
```
