<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 完整输出示例（三类）+ 路由示例

> 主文件 `SKILL.md` 第三章只保留**标准输出模板**与本文件的指针。
>
> ⚠️ 下面出现的具体数值是**演示算术流程的示例值**（标注「示例，以表为准」）。**实际回答时必须逐项查表取值，不得照抄本文件数字，也不得凭印象编造。**

## 路由示例（这样问会被命中）

| 想问什么 | 这样说 | 命中后技能会做什么 |
|---|---|---|
| 查单个食物 | "米饭每 100 克含多少热量？" | 定位第一册表一 → 读每 100g 可食部数值 → 给出来源 |
| 市品换算 | "买了 1000g 带鱼，去内脏后剩 650g，蛋白质吃了多少？" | 套换算公式 → 给出实际摄入 |
| 一日摄入评估 | "今天吃了 200g 米饭、100g 瘦肉、250g 牛奶，钙够吗？" | 逐项换算 → 合计 → 与 DRIs 对比 |
| 嘌呤（痛风） | "痛风能吃哪些荤菜？" | 第二册表六 → 按可食部与总量筛选 |
| DHA/EPA | "孕妇补 DHA 吃哪些鱼？" | 第二册表七 → 结合低汞鱼种推荐 |
| 体检指标 | "血糖 6.8、甘油三酯 2.4、BMI 27，怎么吃？" | 走第六章：指标 → 干预方向 → 选食物 → 餐单核算 |
| 月子餐 | "顺产第 12 天，奶水不够，排一份月子餐" | 走第七章：定位第 2 周 → 缺乳辨证 → 乳母 DRIs 核算 |
| 儿童餐 | "孩子 8 岁血红蛋白 108，一周怎么补铁？" | 走第八章：铁缺乏 → 血红素铁+维C → 儿童 DRIs 核算 |
| 要完整餐单 | "帮我排一份 7 日减脂餐" | 先收集信息（免费）→ 免费出第 1 天样例 → 报价确认 |

**不会命中（属于别的技能）**：书评/读后感、翻译书名、出版信息、无关闲聊。

## 示例 1 · 单食物计算（市品 → 可食部 → 蛋白质摄入）

> 用户问：「我买了 300 g 带骨猪排，实际可食部是多少？摄入了多少蛋白质？」

```markdown
1. 问题归类：单食物市品 → 可食部 + 蛋白质摄入计算。
2. 查表路径：第二册 → 表一「能量和食物一般营养成分」 → 08 畜肉类及制品 → 猪排。
3. 原始数值：猪排 每 100 g 可食部 蛋白质 ≈ 16.7 g（示例，以表为准），食部 53%。
4. 可食部换算：300 g × 53% = 159 g。
5. 实际摄入蛋白质：16.7 g × 159 / 100 ≈ 26.6 g。
6. 结论：300 g 市品猪排约提供 159 g 可食部、26.6 g 蛋白质。
7. 注意：不同部位 / 肥瘦猪排的食部与蛋白质有差异，应核对具体条目。
8. 以上为估算值，用于膳食参考，不构成诊疗。
```

## 示例 2 · 一日膳食评估（合计 + DRIs 对比）

> 用户问：「请帮我评估这份食谱的营养是否均衡。」

```markdown
1. 问题归类：一日膳食营养摄入评估。
2. 按主文件步骤 4–6 分别计算每种食物的可食部与各营养素。
3. 合计：能量 XX kcal、蛋白质 XX g、脂肪 XX g、碳水 XX g、膳食纤维 XX g、钙 XX mg、铁 XX mg …
4. 与 DRIs 比较（数值取自 references/dris-quickref.md）：能量达成率 X%、蛋白质 Y%、钙 Z% …
5. 结论与建议：如钙不足 → 增加乳制品 / 豆制品；饱和脂肪偏高 → 减少畜肉皮脂。
6. 以上为估算值，用于膳食参考，不构成诊疗。
```

## 示例 3 · 端到端（从一句话提问到最终交付）

这是本技能最典型的完整会话形态，含**免费段**与**付费段**。

### 第 1 轮 · 用户（模糊提问）

> 「帮我排一份一周减脂餐。」

### 第 1 轮 · 技能输出（**免费：先收信息**，不排餐、不报价、不出样例）

```markdown
明白。为了排得准，先请你填一下这份表（在当前对话内直接填写即可）；
不方便填表的话，也可以直接告诉我这几项：
性别、年龄、身高体重、活动量、改善目标、有无过敏忌口、有无体检异常或正在用药。

（此处渲染《膳食营养询问表格》；仅当宿主确实无法渲染时，才一次性逐项追问全部缺项）
```

### 第 2 轮 · 用户（给出信息）

> 「女，32 岁，170 cm，78 kg，久坐，一周能做饭 3 次，没有忌口，体检没大问题，在吃什么药没有。」

### 第 2 轮 · 技能输出（**免费：第 1 天样例 + 核算表**，不计次）

先算目标（性别与年龄已由用户确认，可进入计算）：

```text
BMR_female = 10×78 + 6.25×170 − 5×32 − 161 = 1,521.5 kcal
TDEE = 1,521.5 × 1.2（久坐）= 1,825.8 ≈ 1,826 kcal
减重目标 = 1,826 − 400 = 1,426 kcal（高于下限 1,200 ✅）
蛋白质目标 = 1.2~1.6 g/kg × 78 kg = 94~125 g
```

```markdown
先免费给你看第 1 天的样例和核算，你满意我们再出全量。

## 7 日减脂餐 · 第 1 天样例（示例值，以实际核算为准）

早餐：燕麦（生重）50 g + 无糖牛奶 250 g + 水煮蛋 1 个
午餐：杂粮饭（生重）75 g + 鸡胸肉 170 g + 西兰花 200 g + 橄榄油 8 g
加餐：苹果 200 g（市品）+ 无糖酸奶 150 g
晚餐：清蒸鲈鱼 150 g + 凉拌菠菜 150 g + 红薯 100 g

## 第 1 天可食部换算与核算（示例值）

| 食物 | 市品 | 食部 % | 可食部 | 能量 | 蛋白质 |
|---|---|---|---|---|---|
| 燕麦（生重） | 50 g | 100 | 50 g | ≈ 188 kcal | ≈ 7.5 g |
| 无糖牛奶 | 250 g | 100 | 250 g | ≈ 163 kcal | ≈ 8.3 g |
| 水煮蛋 | 1 个 | — | 50 g | ≈ 72 kcal | ≈ 6.7 g |
| 杂粮饭（生重） | 75 g | 100 | 75 g | ≈ 263 kcal | ≈ 6.6 g |
| 鸡胸肉 | 170 g | 100 | 170 g | ≈ 226 kcal | ≈ 33.0 g |
| 西兰花 | 200 g | 83 | 166 g | ≈ 60 kcal | ≈ 6.8 g |
| 橄榄油 | 8 g | 100 | 8 g | ≈ 72 kcal | 0 |
| 苹果 | 200 g | 76 | 152 g | ≈ 82 kcal | ≈ 0.3 g |
| 无糖酸奶 | 150 g | 100 | 150 g | ≈ 108 kcal | ≈ 4.8 g |
| 清蒸鲈鱼 | 150 g | 58 | 87 g | ≈ 91 kcal | ≈ 16.2 g |
| 凉拌菠菜 | 150 g | 89 | 134 g | ≈ 38 kcal | ≈ 3.5 g |
| 红薯 | 100 g | 90 | 90 g | ≈ 95 kcal | ≈ 1.0 g |
| **合计** | | | | **≈ 1,432 kcal** | **≈ 95 g** |

对照目标 1,426 kcal → 达成率 ≈ 100%；蛋白质 95 g（目标 94~125 g，达标）
供能比：蛋白 ≈ 27% / 脂肪 ≈ 24% / 碳水 ≈ 44%（另有膳食纤维少量供能）

*以上为估算值，用于膳食参考，不构成诊疗。*
```

### 第 3 轮 · 技能输出（**报价** —— 唯一报价位置）

```markdown
样例你看过了。生成完整的 7 日餐单需要 1 次配餐额度，确认后我开始。
```

### 第 4 轮 · 用户（确认）

> 「好的，出全量。」

### 第 5 轮 · 技能输出（**支付完成 → 输出全量**）

用户确认后才走 `probe → pay → complete`；**仅在拿到 `200` + `deliver_token` 之后**输出完整 7 日餐单（含每日可食部换算、食材采购清单、DRIs 核算）。

> **用户未确认前：不生成全量、不触发支付。** 未拿到 `deliver_token` 前，产出物**永远停在「第 1 天样例」**。

### 后续 · 用户微调（免费）

> 用户：「周三的牛肉换成鸡胸肉，其他不动。」
> 技能：「好的，这属于已付费方案的调整，直接给你改。」（不报价、不重复收费）
