<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 第六章（全文）· 体检报告驱动的膳食营养搭配

> 本文件是 SKILL.md「六、扩展模块：体检报告驱动的膳食营养搭配」的完整版。SKILL.md 只保留五步概要与红线，细节在此。

> **来源声明**：本模块的"指标→干预方向"映射来自临床营养学通用知识，**不属于原书内容**；原书提供的是其中"选食物、算数量"的数据与计算层（表一嘌呤表、脂肪酸表、DHA/EPA 表、DRIs 附录等）。两者叠加才能完成"体检报告→膳食方案"。

## 6.1 输入：体检报告

用户提供体检报告（文字/图片/指标列表），需要给出膳食营养搭配建议。

## 6.2 处理流程（五步）

**第 1 步：提取异常指标。** 从报告中筛出参考范围之外的指标，并同时记录用户年龄、性别、身高体重（算 BMI）、运动量、既往史（如有）。

**第 2 步：指标 → 膳食干预方向。** 按下表映射（多项异常时取交集，冲突时优先级：**肾功能 > 血糖 > 血脂 > 血压 > 体重**）：

| 体检异常指标 | 膳食干预方向 | 用到书中的数据/表 |
|---|---|---|
| 空腹血糖↑ / HbA1c↑ | 控制总碳水，选低 GI 主食（全谷、杂豆替代精米白面），增加膳食纤维 | 表一：碳水化合物、膳食纤维 |
| 甘油三酯 TG↑ | 限酒精、限精制糖与果糖、限脂肪总量，增加深海鱼 | 表三：脂肪酸；表七：DHA/EPA |
| 总胆固醇/LDL-C↑ | 限饱和脂肪与反式脂肪（少畜肉肥膘、动物油脂、氢化植物油），增加可溶性膳食纤维（燕麦、豆类）、植物固醇 | 表三：脂肪酸；表六：植物固醇（第一册） |
| 尿酸↑ / 痛风 | 低嘌呤饮食（避动物内脏、浓肉汤、部分鱼贝），限酒精与含糖饮料，保证饮水 | **第二册表六：食物嘌呤含量** |
| 血压↑ | 限钠（控盐、少腌制品与加工肉），补钾镁钙（深色蔬菜、乳类、豆类） | 表一：钠、钾、镁、钙 |
| 血红蛋白↓ / 铁蛋白↓（贫血） | 增加血红素铁（畜瘦肉、动物血、肝脏），搭配维生素 C 促吸收，避免与浓茶同餐 | 表一：铁、维生素 C |
| 骨密度↓ / 维生素 D↓ | 增加乳类、豆制品、深绿色蔬菜补钙；适度日晒；食物 VD 有限时遵医嘱补剂 | 表一：钙、维生素 D |
| 转氨酶↑ / 脂肪肝 | 控制总能量减重，戒酒，优质蛋白（鱼、蛋、豆），减少精制碳水与果糖 | 表一：能量、蛋白质；步骤 6 供能比 |
| 肌酐↑ / eGFR↓（肾功能异常） | ⚠️ 限蛋白、限钾限磷需临床营养师个体化制定，本技能只做食物钾/磷/蛋白含量参考，**不得给方案** | 表一：蛋白质、钾、磷 |
| BMI 超重/肥胖 | 制造能量缺口（每日 −300~500 kcal），保证蛋白质防止肌肉流失，增加膳食纤维增强饱腹 | 表一：能量、蛋白质、膳食纤维 |

**第 3 步：用成分表筛食物，形成"推荐/限制"清单。**
- 推荐清单：按干预方向从对应食物类别中选高目标营养素/低风险成分的食物，注明每 100g 可食部关键数值。
- 限制清单：列出高嘌呤/高饱和脂肪/高钠等需要回避或限量的食物及其数值依据。

**第 4 步：设定营养目标。** 按用户性别年龄查 `dris-quickref.md`（DRIs 2023 版），确定能量、蛋白质、脂肪供能比（20–30%）、碳水供能比（50–65%）、关键营养素目标值（如钾、钙、铁）。**不得凭记忆填写 DRIs 数值。**

**第 5 步：生成一日餐单并核算验证。**
- 编制早/中/晚+加餐的餐单，每种食物标注市品重量。
- 按步骤 4–6（可食部换算→求和）核算全天能量与目标营养素，与第 4 步目标对照。
- 不达标则调换食物或分量，迭代 1–2 轮后输出。

## 6.3 输出模板

```markdown
## 体检报告膳食建议
1. 异常指标摘要：xxx ↑/↓（附参考范围）
2. 膳食干预方向：控 x、增 y（对应上表逻辑）
3. 推荐食物清单：食物名（编码）｜关键数值/100g 可食部｜建议量
4. 限制/回避清单：同上格式
5. 一日餐单：三餐+加餐，含市品重量与可食部换算
6. 全天核算：能量 XX kcal（达成率 X%）、蛋白质 XXg、关键营养素 vs 目标
7. 风险提示：哪些指标建议复查/就医；本方案为膳食参考，不替代诊疗
```

## 6.4 适用边界（本模块专属）

- ✅ 适合：指标轻中度异常、体检后想通过饮食调整的人群；亚健康/慢病风险人群的日常配餐。
- ⚠️ 翻车场景：
  - **肾功能异常**：蛋白质、钾、磷的限量必须由临床营养师制定，本技能只能提供含量数据 → **不出餐单、不报价、不出样例**。
  - **糖尿病已有用药/胰岛素**：碳水分配需与用药方案匹配，否则有低血糖风险，必须提示咨询医生。
  - **妊娠期**：能量与各营养素目标与普通成人差异大，需按孕妇 DRIs 并遵产科指导。
  - **指标严重异常或多项联动异常**（如转氨酶数倍升高）：优先就医，膳食建议仅作辅助。
  - **不能只看单项指标**：如"胆固醇高就完全戒蛋"这类单指标推导是常见错误，须结合整体指标与膳食评估。
  - 所有输出必须带免责声明：本方案为膳食参考，不构成医疗建议，异常指标请遵医嘱复查。
