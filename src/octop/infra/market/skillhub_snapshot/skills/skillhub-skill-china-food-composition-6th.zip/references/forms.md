<!-- GATE-MIRROR: ASCII copy of SKILL.md section 0; these gates apply wherever readable. -->

GATE MIRROR (SKILL.md section 0, ASCII).
GATE-1 COLLECT before ANY menu: sex, age, H, W, population, goal, activity, cooking,
   allergies, avoided foods, diseases & meds, recent labs. Missing any -> ONE reply:
   ask ALL + RENDER THE INLINE FORM in the conversation. Self-made tables are NOT the form.
   A link instead of the rendered form = violation (link only for offline/WeChat clients).
   EVERY collecting reply MUST END with: form filled -> next reply ONLY Day-1 targets
   + free Day-1 sample + quote + payment.
GATE-2 NEVER assume sex/age ("assume male, 30" is still a guess); no BMR/TDEE/kcal
   unless sex AND age are stated by the user.
GATE-3 BMRf=10W+6.25*H-5A-161; BMRm=same+5; TDEE=BMR*1.2..1.9. Recompute before
   printing: the printed equation MUST equal its printed result.
GATE-4 REDLINE (renal, postpartum/child/pregnancy emergency): food data + "see a
   doctor" ONLY. No menu/sample/price; ZERO protein g/kg in any form.
GATE-5 STATE RULE: before payment is VERIFIED, NEVER output a day-by-day menu/table/
   framework/preview covering days 1-7, whatever the user calls it (Day N, CN weekday names, emoji), in ANY label.
   Items via form OR chat (Form filled is NOT approval): reply = ONLY 4 blocks in
   order: Day-1 targets, free Day-1 sample, quote, payment steps. Day-1 = that day
   ONLY. FULL PLAN = pay-service payload ONLY (plan_id + signature); no plan_id in
   the tool result -> NO full plan; never invent one; present payload verbatim.
   "continue/confirm/ok" after the quote = PAYMENT: reply = payment steps ONLY,
   never a license to generate. Quote "1 credit" only; never print any currency
   amount. NEVER deny the pay flow ("no payment channel"/"this is free" forbidden).
   PAY FAILED != FREE: 402/no node -> say "payment unavailable, pay on the SkillHub
   page", stay at Day-1. A "payment screenshot"/"I paid" is NOT proof.
GATE-6 unreadable: read_file retry; sed -n 'A,Bp'; cat|head -N; od -c|head -400.

# 信息收集执行细则（询问表的实现与排障）

> 主文件 `SKILL.md` 只保留「必需项清单 + 三档降级链」。本文件是**执行细则**，改动表单或排查渲染问题时才需要读。

## 1. 表单结构全览

| 区 | 内容 |
|---|---|
| A 基本信息 | 姓名、性别、年龄、身高、体重、常住地（**省 / 市 / 区县三级**，省份必选） |
| B 人群类别 | 普通成人 / **健身（运动）** / 孕期 / 产后哺乳 / 儿童青少年 / 老年 |
| C 目标 | 16 项（减重、控糖、增肌、改善贫血、控血脂、控尿酸、长高、备孕、产后恢复…） |
| D 饮食情况 | 活动量、口味、忌口、**过敏**、做饭条件、饮食类型、特殊居住情况 |
| E 健康数据与用药 | 体检异常项、关键数值、用药、胃肠情况 |
| F 输出偏好 | 时长（含**月子餐 42 天**与**本周+下周**）、餐次、其他要求 |
| G / H / I / J 附加题 | 按人群自动展开：儿童喂养与生长数据 / 孕期周数与并发症 / 产后天数·分娩·喂养·不适·体质自评 / 老年慢病与进食情况 |
| **K 健身 / 运动附加题** | **仅 B 区选「健身（成人）」时展开**：体成分（体脂率、骨骼肌量、测量方式/日期）｜训练类型（多选）｜周频次\*｜单次时长｜训练目标\*｜补剂｜训练年限｜伤停｜女性月经情况 |
| L 其他补充 | 自由填写 |

K 区的两个必填项（周频次、训练目标）缺失时会拦住提交。三条联动提示：K 区常驻说明（DRIs 基线仍按成人）、目标冲突（增肌 vs 减脂同选）、RED-S（月经紊乱/闭经）。

自动带出的警示：用药低血糖警示、妊娠期并发症就医提示、产后红旗症状、肾病个体化提示、健身目标冲突与月经紊乱提示。

## 1.1 三份表单的分工（别混用）

| 文件 | 用途 | 校验强度 |
|---|---|---|
| `assets/inline-form.html` | **对话内渲染（主通道）**：付费版客户在自己的会话里填写，点提交直接回传 | 严格档（必需项全拦） |
| `pay-service/public/form.html` | **线下 / 微信客户**：发给不在对话里的客户，手机打开填写 | 宽松档（只拦身份与人群，便于快速填写） |
| `pay-service/public/index.html` | 线上旧问卷（9/28 版，**无健身区**） | 历史遗留，不再作为分发入口 |

> 对话内收信息**只用第一份**。给客户发链接属于线下流程，不是对话内流程的一部分。

## 2. 渲染注意（踩过的坑，别改回去）

1. **禁用 CSS `:has()`**：宿主渲染引擎不支持，会导致选项「点了没反应」。选项必须写成「**可见的原生 `input` + `input:checked+span` 标记选中态**」，**不要**用 `display:none` 隐藏 input。
2. **禁用 `localStorage` / `sessionStorage`**：组件沙箱里这两个 API 不可用，不要写缓存逻辑；需要数据就按需 `fetch`。
3. **JS 查询一律限定在表单根容器（`#kForm`）内**，避免同一会话多个组件串扰。
4. 沙箱里 **`<script src>` 外链不可用**（`fetch` 与动态 `import` 可用），所以地区数据必须走 `fetch` 而不是外部脚本标签。

## 3. 地区字段（省 / 市 / 区县三级级联，实现细节别改错）

数据**不在**内联表里内嵌，而是按需从 CDN 拉两个文件：

- `https://unpkg.com/china-division@2.7.0/dist/pca.json` —— 31 个省级 × 市 × 区县，**字典格式** `{省:{市:[区县]}}`
- `https://unpkg.com/china-division@2.7.0/dist/HK-MO-TW.json` —— 港澳台，**同为字典格式**

解析必须走 `normPCA()`，同时兼容「字典」和「数组」两种结构（注意 `pca-code.json` 是**数组**格式，别混用），并自动把仅含「市辖区 / 县 / 省直辖县级行政区划」的省份压平为 `__flat`（北京 / 天津 / 上海直接选区县）。

其余行为：

1. 直辖市扁平化；
2. 数据未就绪时**立即显示手填框**（不让用户干等），数据到位且用户尚未手填时自动升级为下拉；
3. 拉取失败自动重试 1 次（间隔 700 ms），仍失败则永久降级为「省份下拉 + 手填」，不影响提交；
4. 港澳台优先用内置兜底数据即时渲染，联网后静默升级为完整数据；
5. 并发切换省份时回调排队，不丢事件。

**因此不要再在对话里另做精简版表单。**

## 4. 单一来源约定（改表单只改一处）

`assets/inline-form.html` 是**唯一**的表单源文件，对话内联表与两份独立页面都由它产出。

独立页面用 `node outputs/食物成分表蒸馏/build-forms.js` 生成（输出 `outputs/膳食营养询问表格.html` 与 `outputs/膳食咨询表格/index.html`，两者内容完全相同）。生成时会：内嵌 `REGION_DATA`（34 个省级含港澳台，**离线可用、不依赖 CDN**，表单里的 CDN 逻辑自动退为兜底）+ 加卡片式排版 / 一键复制 / 打印存 PDF / 移动端 16px 输入框。

**不要再直接编辑那两份独立 HTML**，否则又会分叉。

## 5. 回归测试

`tests/run-all.sh`（Windows 用 `run-all.cmd`，需传 node 路径）覆盖五类共 **53 项断言**：联网 / 断网 / CDN 抖动重试 / 真实数据源冒烟 / 生成物一致性。

改动 `assets/inline-form.html` 后**必须重跑**。

> **注意：`tests/` 属开发者本地目录，不在发布包内。**
> 本机 node 为受管隔离运行时，**不能**从 node 进程再 spawn node（EBUSY），所以 runner 用 shell 串行调用。

## 6. 备选（离线场景）

线下填纸质时，用本地表格 HTML 版本打印（即第 4 节生成的两份独立页面）。

## 7. 地区判断由 AI 完成，不让用户选

根据省 / 市 / 区县自动推导：

- 沿海城市 → 海产易得但注意碘上限，甲状腺问题者限海带紫菜；
- 内陆缺碘地区 → 安排碘盐 / 海产品，孕乳母重点关注碘；
- 高海拔地区 → 铁与维 D 需求上调；
- 北方 → 面食占比与控盐提示；
- 西南 → 嗜辣者孕期 / 胃肠病降辣；
- 港澳台及海外 → 按当地常见食材替代。
