# scripts/ —— Pay Skill 侧支付编排

> 本目录封装「发起请求 → 交给官方支付能力 → 复用原订单取回资源」三步，**不含密钥、不自行实现签名**。
> 支付身份、签名与收银台全部由官方买家能力 `alipay-bot` 管理；服务端（验付 / 交付 / 商家履约）独立部署，不放进 Skill 包。

## 依赖

| 依赖 | 用途 | 安装 |
|---|---|---|
| Node.js ≥ 18 | 运行本脚本（用内置 `fetch`，零第三方依赖） | 各平台官方安装包 |
| 官方买家支付能力 `alipay-bot` | 唤起收银台、验付、取回资源 | `npx -y @alipay/agent-payment@latest install` |

`alipay-bot` 的查找顺序：环境变量 `ALIPAY_BOT` → `PATH` → `~/.openclaw-autoclaw/alipay-bot-cli/bin/`。
找不到时脚本以退出码 `4` 明确报错并给出安装命令，不会静默降级。

## 三个子命令

### 1. probe —— 发起原请求，取下账单

```bash
node scripts/a2m-pay.js probe \
  --url 'https://<业务端点>/v1/orders' \
  --method POST \
  --data '{"sku":"plan-7d","client_ref":"<同一次交付唯一编号>","consult":{...}}' \
  --header 'Content-Type: application/json' \
  --state-dir '.state/<会话键>' \
  --session-key '<会话键>'
```

- 未付款 → 收到 `402`，从响应头取账单（`Payment-Needed`）→ 解码为 JSON → 写入 `<state-dir>/challenge.json`，
  并把**原请求原样**记入 `<state-dir>/a2m-state.json`（这是「支付后复用同一请求」的依据）。
- 已付款 / 免费端点 → `200`，直接回传资源，退出码 `3`（无需支付）。
- 账单原文只落状态目录；**脚本只回传脱敏摘要**（订单号、金额、状态文件路径），不面向用户展示凭据原文。

### 2. pay —— 交给官方支付能力，等用户授权

```bash
node scripts/a2m-pay.js pay --state-dir '.state/<会话键>' [--intent-summary '<用途说明>']
```

内部执行（原请求参数与 probe 完全一致）：

```text
alipay-bot 402-buyer-pay --file <state-dir>/challenge.json \
  --resource-url <原 URL> --method <原 method> [--data <原 body>] [--header 'K:V']... \
  --intent-summary '<用途说明>' --session-id '<会话键>' --json
```

- `--intent-summary` 为官方必填项，说明这笔钱买的是什么。
- **不转发** `Authorization` / `Payment-Proof` / `Payment-Needed` / `Host` / `Content-Length` / `externalId` / `Sign` / `Timestamp` / `Cookie`；身份与签名由官方 CLI 管理。
- `--dry-run` 只打印将要执行的命令（用于联调与审核留痕），不真正发起。

### 3. complete —— 状态不明先查单，复用原订单取回资源

```bash
node scripts/a2m-pay.js complete --state-dir '.state/<会话键>'
```

内部执行：

```text
alipay-bot 402-query-payment-status --resource-url <原 URL> --method <原 method> \
  [--data <原 body>] [--header 'K:V']... [--out-shake-no <订单号>] --json
```

官方 CLI 在取到非空资源后会自动发送履约回执；**成功路径不追加独立回执，更不重新下单**。

## 离线自测

```bash
node scripts/selftest.js
```

进程内起 mock HTTP 服务 + 直接调用模块函数，**不派生子进程、不联网、不发起真实付款**，覆盖 19 项断言：
402 取账并落地账单文件、原请求逐字段复用、控制头不转发、200 直接交付、
无账单头 / 账单结构不合法 / 非 402 非 200 / 缺状态文件 / URL 非法 / 官方 CLI 缺失等异常分支。

## 纪律

1. **原请求参数保持一致**：`pay` / `complete` 只从 `a2m-state.json` 读取 probe 时的请求，不重新拼装。
2. **状态不明先查单**：不确定是否已付款 → 走 `complete`，不重复调用 `pay`。
3. **不重复交付**：只有拿到资源（`200` + `deliver_token`）才产出全量交付物。
4. **凭据不外泄**：账单原文、凭证一律不进入面向用户的话术。
5. **状态目录不进包**：`.state/` 属运行期产物，不得打包进 Skill（包内不含密钥、`.env`、状态文件、`node_modules`）。

## 退出码

| 码 | 含义 |
|---|---|
| `0` | 成功（probe 拿到账单 / pay 或 complete 由 CLI 正常完成） |
| `3` | 业务端点直接返回 `200`，无需支付 |
| `4` | 未找到官方 `alipay-bot` |
| `1` | 其它错误（参数、网络、响应非预期、状态文件缺失等） |
