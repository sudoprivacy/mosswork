#!/usr/bin/env node
/*
 * a2m-pay —— Pay Skill 侧支付编排（probe / pay / complete）
 * ---------------------------------------------------------------------------
 * 本脚本只做三件事：**发起业务请求**、**把账单交给官方支付能力**、**复用原订单取回资源**。
 * 它不接触任何支付密钥，也不自行实现签名；支付身份与签名全部交给官方买家 CLI 管理。
 * 服务端（验付 / 交付资源 / 商家履约确认）独立部署，不在本包内。
 *
 * 官方契约（SkillHub「升级为 Pay Skill」预检查自查项）：
 *   账单      未付款时返回 402 与账单头（Payment-Needed）
 *   凭证重试  支付后携凭证重试，**原请求参数保持一致**
 *   服务端验付 由服务端完成（本脚本不参与）
 *   商家履约  由服务端完成（本脚本不参与）
 *   订单与幂等 状态不明先查单，不重复付款、不重复交付
 *
 * 用法：
 *   node scripts/a2m-pay.js probe    --url <URL> [--method POST] [--data <JSON>]
 *                                    [--header 'K: V']... --state-dir <DIR> [--session-key <KEY>]
 *   node scripts/a2m-pay.js pay      --state-dir <DIR> [--intent-summary <TEXT>] [--session-id <KEY>] [--dry-run]
 *   node scripts/a2m-pay.js complete --state-dir <DIR> [--out-shake-no <SN>] [--dry-run]
 *
 * 退出码：0 成功 / 3 业务端点直接返回 200（无需付款）/ 4 官方 CLI 不可用 / 1 其它错误
 * 依赖：Node >= 18（内置 fetch）；官方买家能力 alipay-bot（见 scripts/README.md）。
 */
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

/* ---------------------------------------------------------------- 常量 */

/** 只传原请求的业务 Header；这些控制头一律不转发（身份与签名由官方 CLI 管理）。 */
const CONTROL_HEADERS = new Set([
  'authorization', 'payment-proof', 'payment-needed', 'amtpaymentlink',
  'host', 'content-length', 'externalid', 'sign', 'timestamp', 'cookie'
]);

/** 官方 402 协议约定的账单响应头（大小写不敏感；Node 已归一化为小写）。 */
const CHALLENGE_HEADERS = ['payment-needed', 'amtpaymentlink'];

const EXIT = { OK: 0, ERR: 1, DIRECT: 3, NO_CLI: 4 };

const INSTALL_HINT = 'npx -y @alipay/agent-payment@latest install';
const DEFAULT_INTENT_SUMMARY = '营养配餐助手：生成一份经核算的餐单/膳食方案（按次付费）';

/* ------------------------------------------------------------ 错误类型 */

class A2MError extends Error {
  constructor(exitCode, message, extra) {
    super(message);
    this.name = 'A2MError';
    this.exitCode = exitCode;
    this.extra = extra || {};
  }
}

const fail = (exitCode, message, extra) => { throw new A2MError(exitCode, message, extra); };

/* ---------------------------------------------------------------- 工具 */

function parseArgs(argv) {
  const out = { _: [], header: [] };
  for (let i = 0; i < argv.length; i++) {
    const tok = argv[i];
    if (!tok.startsWith('--')) { out._.push(tok); continue; }
    const key = tok.slice(2);
    if (['json', 'dry-run', 'help'].includes(key)) { out[key] = true; continue; }
    const val = argv[++i];
    if (val === undefined) fail(EXIT.ERR, '缺少参数值: --' + key);
    if (key === 'header') out.header.push(val);
    else out[key] = val;
  }
  return out;
}

function splitHeader(raw) {
  const idx = raw.indexOf(':');
  if (idx <= 0) fail(EXIT.ERR, 'Header 需为 "Key: Value" 形式: ' + raw);
  return { name: raw.slice(0, idx).trim(), value: raw.slice(idx + 1).trim() };
}

function businessHeaders(rawList) {
  const kept = [];
  for (const raw of rawList || []) {
    const { name, value } = splitHeader(raw);
    if (CONTROL_HEADERS.has(name.toLowerCase())) continue; // 不转发控制头
    kept.push({ name, value });
  }
  return kept;
}

function b64urlDecode(str) {
  let s = String(str || '').replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Buffer.from(s, 'base64').toString('utf8');
}

/** 从 402 响应中取账单头；返回 { headerName, raw } 或 null。 */
function pickChallengeHeader(headers) {
  for (const name of CHALLENGE_HEADERS) {
    const raw = headers.get(name);
    if (raw && raw.trim()) return { headerName: name, raw: raw.trim() };
  }
  return null;
}

/* ---------------------------------------------------------- 状态文件
 * 单一事实来源：原始请求 + 账单，供 pay / complete 复用。
 * **与 probe 完全一致的原请求**是「原请求参数保持一致」的落地方式。
 * 运行期状态只落在调用方指定的 --state-dir，不进包、不进仓库。 */

const stateFileOf = dir => path.join(dir, 'a2m-state.json');

function saveState(dir, state) {
  fs.mkdirSync(dir, { recursive: true });
  const file = stateFileOf(dir);
  fs.writeFileSync(file, JSON.stringify(state, null, 2), { encoding: 'utf8', mode: 0o600 });
  return file;
}

function loadState(dir) {
  const file = stateFileOf(dir);
  if (!fs.existsSync(file)) fail(EXIT.ERR, '找不到状态文件，请先执行 probe：' + file);
  try {
    return { file, state: JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch (e) {
    return fail(EXIT.ERR, '状态文件不是合法 JSON：' + e.message);
  }
}

/* -------------------------------------------------- 官方买家 CLI 定位 */

function resolveAlipayBot() {
  const explicit = process.env.ALIPAY_BOT;
  if (explicit && fs.existsSync(explicit)) return explicit;

  const isWin = process.platform === 'win32';
  const names = isWin ? ['alipay-bot.exe', 'alipay-bot.cmd', 'alipay-bot'] : ['alipay-bot'];
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  const home = process.env.USERPROFILE || process.env.HOME || '';
  if (home) {
    dirs.push(path.join(home, '.openclaw-autoclaw', 'alipay-bot-cli', 'bin'));
    dirs.push(path.join(home, '.local', 'bin'));
  }
  for (const dir of dirs) {
    for (const name of names) {
      const full = path.join(dir, name);
      try { if (fs.statSync(full).isFile()) return full; } catch (_) { /* 继续找 */ }
    }
  }
  return null;
}

function runAlipayBot(args, dryRun) {
  const printable = ['alipay-bot'].concat(args.map(a => (/\s/.test(a) ? JSON.stringify(a) : a)));
  const bin = resolveAlipayBot();
  if (!bin) {
    return fail(EXIT.NO_CLI, '未找到官方买家支付能力 alipay-bot，请先安装：' + INSTALL_HINT,
      { installCommand: INSTALL_HINT, command: printable });
  }
  if (dryRun) {
    return { code: EXIT.OK, payload: { ok: true, dryRun: true, cli: bin, command: printable } };
  }
  const res = spawnSync(bin, args, { stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8' });
  if (res.error) fail(EXIT.ERR, '调用 alipay-bot 失败：' + res.error.message, { cli: bin });
  const stdout = (res.stdout || '').trim();
  const stderr = (res.stderr || '').trim();
  return {
    code: res.status === 0 ? EXIT.OK : EXIT.ERR,
    payload: {
      ok: res.status === 0,
      exitCode: res.status,
      cli: bin,
      command: printable,
      // 原样透传官方输出；技能话术层不得把凭据原文展示给用户
      stdout,
      stderr: stderr || undefined
    }
  };
}

/* ------------------------------------------------------------- probe
 * 发起原请求 → 未付款时取 402 账单 → 落地状态文件（账单 + 原请求），供 pay/complete 复用。 */

async function cmdProbe(args) {
  const url = args.url;
  if (!url) fail(EXIT.ERR, 'probe 需要 --url');
  let parsed;
  try { parsed = new URL(url); } catch (_) { fail(EXIT.ERR, '--url 不是合法 URL: ' + url); }
  if (!/^https?:$/.test(parsed.protocol)) fail(EXIT.ERR, '--url 必须是 http/https');
  if (parsed.username || parsed.password) fail(EXIT.ERR, '--url 不得包含凭据');

  const method = (args.method || 'GET').toUpperCase();
  const headers = businessHeaders(args.header);
  const body = args.data === undefined ? undefined : String(args.data);

  let res;
  try {
    res = await fetch(url, {
      method,
      headers: headers.reduce((acc, h) => (acc[h.name] = h.value, acc), {}),
      body: method === 'GET' || method === 'HEAD' ? undefined : body,
      redirect: 'manual'
    });
  } catch (e) {
    fail(EXIT.ERR, '业务端点请求失败：' + e.message, { url, method });
  }

  const stateKey = args['session-key'] || 'default';
  const stateDir = args['state-dir'] || path.join('.state', stateKey);
  const baseState = {
    version: 1,
    session_key: stateKey,
    created_at: new Date().toISOString(),
    request: { url, method, headers, body: body === undefined ? null : body },
    phase: 'requested'
  };

  /* 已付款 / 免费端点：直接拿到资源，无需支付。 */
  if (res.status === 200) {
    let payload = null;
    try { payload = await res.json(); } catch (_) { payload = null; }
    const file = saveState(stateDir, Object.assign({}, baseState, {
      phase: 'delivered', http_status: 200
    }));
    return {
      code: EXIT.DIRECT,
      payload: { ok: true, phase: 'delivered', httpStatus: 200, stateFile: file, resource: payload }
    };
  }

  if (res.status !== 402) {
    let text = '';
    try { text = (await res.text()).slice(0, 500); } catch (_) { /* 忽略 */ }
    fail(EXIT.ERR, '业务端点返回了非预期状态码（期望 200 或 402）',
      { httpStatus: res.status, body: text || undefined, url, method });
  }

  const challenge = pickChallengeHeader(res.headers);
  if (!challenge) {
    fail(EXIT.ERR,
      '收到 402，但响应头里没有账单（Payment-Needed / amtPaymentLink）——请核对服务地址是否为已登记的业务端点',
      { httpStatus: 402, url, method });
  }

  /* 账单头是 base64url 编码的 JSON（含 protocol / method 两个对象）。
   * 官方 CLI 要求 --file 恰好包含一个 JSON 值，因此这里解码后写入状态目录。 */
  let challengeJson = null;
  let decodeError = null;
  try { challengeJson = JSON.parse(b64urlDecode(challenge.raw)); }
  catch (e) { decodeError = e.message; }

  if (!challengeJson || typeof challengeJson !== 'object'
    || typeof challengeJson.protocol !== 'object' || typeof challengeJson.method !== 'object') {
    fail(EXIT.ERR,
      '账单头解码后不是含 protocol / method 的 JSON 对象（请确认为支付宝 A2M 账单）',
      { headerName: challenge.headerName, decodeError: decodeError || undefined });
  }

  const challengeFile = path.join(stateDir, 'challenge.json');
  const file = saveState(stateDir, Object.assign({}, baseState, {
    phase: 'challenged',
    http_status: 402,
    challenge: {
      header_name: challenge.headerName,
      file: challengeFile,
      out_trade_no: challengeJson.protocol.out_trade_no || null,
      amount: challengeJson.protocol.amount || null,
      currency: challengeJson.protocol.currency || null,
      resource_id: challengeJson.protocol.resource_id || null,
      pay_before: challengeJson.protocol.pay_before || null
    }
  }));
  fs.writeFileSync(challengeFile, JSON.stringify(challengeJson), { encoding: 'utf8', mode: 0o600 });

  /* 只回传脱敏摘要；账单原文留在状态目录，不面向用户展示。 */
  return {
    code: EXIT.OK,
    payload: {
      ok: true,
      phase: 'challenged',
      httpStatus: 402,
      stateFile: file,
      challengeFile,
      outTradeNo: challengeJson.protocol.out_trade_no || null,
      amount: challengeJson.protocol.amount || null,
      amountNote: '金额仅供与平台登记价核对；对用户话术仍只说「1 次配餐额度」，不报金额。',
      next: 'node scripts/a2m-pay.js pay --state-dir ' + JSON.stringify(stateDir)
    }
  };
}

/* --------------------------------------------------------------- pay
 * 把账单 + 原请求交给官方买家 CLI，由官方能力唤起支付入口并等待用户授权。
 * 本脚本不拼支付参数、不接触密钥、不自行实现签名。 */

function cmdPay(args) {
  const stateDir = args['state-dir'];
  if (!stateDir) fail(EXIT.ERR, 'pay 需要 --state-dir');
  const { state } = loadState(stateDir);
  const ch = state.challenge || {};
  if (!ch.file || !fs.existsSync(ch.file)) fail(EXIT.ERR, '状态里没有可用账单，请先执行 probe');
  const req = state.request || {};
  if (!req.url) fail(EXIT.ERR, '状态里缺少原始请求，请重新执行 probe');

  const cliArgs = ['402-buyer-pay', '--file', ch.file, '--resource-url', req.url, '--method', req.method || 'GET'];
  if (req.body !== null && req.body !== undefined) cliArgs.push('--data', String(req.body));
  for (const h of req.headers || []) cliArgs.push('--header', h.name + ':' + h.value);

  /* --intent-summary 为官方必填项：说明这笔钱买的是什么。 */
  cliArgs.push('--intent-summary', args['intent-summary'] || DEFAULT_INTENT_SUMMARY);

  const sessionId = args['session-id'] || state.session_key;
  if (sessionId) cliArgs.push('--session-id', String(sessionId));
  cliArgs.push('--json');

  return runAlipayBot(cliArgs, !!args['dry-run']);
}

/* ---------------------------------------------------------- complete
 * 状态不明先查单：用**原订单**查询支付状态、复用同一请求取回资源，官方 CLI 会自动回执。 */

function cmdComplete(args) {
  const stateDir = args['state-dir'];
  if (!stateDir) fail(EXIT.ERR, 'complete 需要 --state-dir');
  const { state } = loadState(stateDir);
  const req = state.request || {};
  if (!req.url) fail(EXIT.ERR, '状态里缺少原始请求，请重新执行 probe');

  const cliArgs = ['402-query-payment-status', '--resource-url', req.url, '--method', req.method || 'GET'];
  if (req.body !== null && req.body !== undefined) cliArgs.push('--data', String(req.body));
  for (const h of req.headers || []) cliArgs.push('--header', h.name + ':' + h.value);

  const sn = args['out-shake-no'] || (state.challenge && state.challenge.out_trade_no);
  if (sn) cliArgs.push('--out-shake-no', String(sn));
  cliArgs.push('--json');

  return runAlipayBot(cliArgs, !!args['dry-run']);
}

/* ---------------------------------------------------------------- main */

const USAGE = [
  'a2m-pay —— Pay Skill 侧支付编排（probe / pay / complete）',
  '',
  '  probe    --url <URL> [--method POST] [--data <JSON>] [--header "K: V"]...',
  '           --state-dir <DIR> [--session-key <KEY>]',
  '  pay      --state-dir <DIR> [--intent-summary <TEXT>] [--session-id <KEY>] [--dry-run]',
  '  complete --state-dir <DIR> [--out-shake-no <SN>] [--dry-run]',
  ''
].join('\n');

async function runCommand(cmd, args) {
  if (cmd === 'probe') return cmdProbe(args);
  if (cmd === 'pay') return cmdPay(args);
  if (cmd === 'complete') return cmdComplete(args);
  fail(EXIT.ERR, '未知子命令: ' + cmd, { usage: USAGE });
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0];
  if (!cmd || args.help) {
    process.stdout.write(USAGE);
    process.exit(args.help ? EXIT.OK : EXIT.ERR);
  }
  try {
    const { code, payload } = await runCommand(cmd, args);
    process.stdout.write(JSON.stringify(payload, null, 2) + '\n');
    process.exit(code);
  } catch (e) {
    if (e instanceof A2MError) {
      process.stdout.write(JSON.stringify(
        Object.assign({ ok: false, code: e.exitCode, error: e.message }, e.extra), null, 2) + '\n');
      process.exit(e.exitCode);
    }
    process.stdout.write(JSON.stringify(
      { ok: false, code: EXIT.ERR, error: '未捕获异常：' + (e && e.message ? e.message : String(e)) }, null, 2) + '\n');
    process.exit(EXIT.ERR);
  }
}

/* 既可作为 CLI 运行，也可被自测脚本 require（不自动执行 main）。 */
if (require.main === module) main();

module.exports = {
  cmdProbe, cmdPay, cmdComplete, runCommand, parseArgs,
  A2MError, EXIT, USAGE, CONTROL_HEADERS, resolveAlipayBot, b64urlDecode, DEFAULT_INTENT_SUMMARY
};
