#!/usr/bin/env node
/*
 * selftest —— a2m-pay 的离线自测（模拟响应，不发真实付款、不联网）
 * ---------------------------------------------------------------------------
 * 覆盖官方预检查自查项在 **Skill 侧** 可验证的部分：
 *   账单     402 + 账单头 → 落地状态文件
 *   凭证重试 支付后复用**原请求参数**（逐字段比对）
 *   幂等     状态不明走查单、用**原订单号**
 * 以及异常分支：无账单头 / 账单结构不合法 / 非 402 非 200 / 控制头不转发 /
 *              缺状态文件 / URL 非法 / 官方 CLI 不可用。
 *
 * 运行：node scripts/selftest.js
 * 说明：进程内起 mock HTTP 服务 + 直接调用模块函数，不派生子进程、不产生真实网络请求。
 */
'use strict';

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');

const a2m = require('./a2m-pay.js');

/* ------------------------------------------------------------ 断言框架 */

let pass = 0;
const failures = [];
function check(name, fn) {
  try { fn(); pass++; console.log('  \u2714 ' + name); }
  catch (e) { failures.push(name + ' —— ' + e.message); console.log('  \u2717 ' + name + ' —— ' + e.message); }
}
const eq = (a, b, msg) => {
  const A = JSON.stringify(a), B = JSON.stringify(b);
  if (A !== B) throw new Error((msg || '不相等') + ': 实际 ' + A + ' ≠ 期望 ' + B);
};
const ok = (v, msg) => { if (!v) throw new Error(msg || '断言失败'); };

const b64url = s => Buffer.from(s, 'utf8').toString('base64')
  .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');

/* ------------------------------------------------------------- mock 服务 */

const BILL = {
  protocol: {
    out_trade_no: 'ord_selftest_0001',
    amount: '3.90',
    currency: 'CNY',
    resource_id: 'mealplan:plan-7d',
    pay_before: '2026-10-08T12:00:00+08:00',
    seller_signature: 'SIGNATURE_PLACEHOLDER_FOR_SELFTEST_ONLY',
    seller_sign_type: 'RSA2',
    seller_unique_id: '2088202403070839'
  },
  method: {
    seller_name: '营养配餐服务（自测）',
    seller_id: '2088202403070839',
    seller_app_id: '2021007104680051',
    goods_name: '营养配餐 · 7日餐单',
    seller_unique_id_key: 'seller_id',
    service_id: 'API_SELFTEST_SERVICE'
  }
};

let lastSeenRequest = null;   // 记录 mock 服务端收到的请求，用于断言「控制头不转发」

function startMock() {
  return new Promise(resolve => {
    const server = http.createServer((req, res) => {
      const chunks = [];
      req.on('data', c => chunks.push(c));
      req.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf8');
        const url = new URL(req.url, 'http://127.0.0.1');
        lastSeenRequest = { path: url.pathname, method: req.method, headers: req.headers, body };

        if (url.pathname === '/v1/orders') {
          if (req.headers['x-test-state'] === 'paid') {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ content: { deliver_token: 'DT_SELFTEST', sku: 'plan-7d' } }));
            return;
          }
          res.writeHead(402, { 'Content-Type': 'application/json', 'Payment-Needed': b64url(JSON.stringify(BILL)) });
          res.end(JSON.stringify({ error: 'payment_required' }));
          return;
        }
        if (url.pathname === '/v1/no-challenge') {
          res.writeHead(402, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'payment_required' }));
          return;
        }
        if (url.pathname === '/v1/bad-challenge') {
          res.writeHead(402, { 'Payment-Needed': b64url(JSON.stringify({ hello: 'world' })) });
          res.end('{}');
          return;
        }
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('boom');
      });
    });
    server.listen(0, '127.0.0.1', () => resolve({ server, port: server.address().port }));
  });
}

/* 捕获 A2MError（命令函数用抛错而不是 process.exit，便于自测） */
async function expectError(fn) {
  try { await fn(); }
  catch (e) { if (e instanceof a2m.A2MError) return e; throw e; }
  throw new Error('预期抛错，但没有抛');
}

/* ------------------------------------------------------------------ 主流程 */

async function main() {
  const { server, port } = await startMock();
  const base = 'http://127.0.0.1:' + port;
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'a2m-selftest-'));
  const REQ_BODY = JSON.stringify({ sku: 'plan-7d', client_ref: 'sess-selftest', consult: { name: '测试', sex: '女', age: '34' } });
  /* 故意混入控制头：它必须被过滤，既不进状态文件，也不到达业务端点 */
  const REQ_HEADERS = ['Content-Type: application/json', 'Authorization: Bearer should-not-be-forwarded'];

  const probeArgs = extra => Object.assign({
    url: base + '/v1/orders',
    method: 'POST',
    data: REQ_BODY,
    header: REQ_HEADERS.slice(),
    'state-dir': path.join(tmpRoot, 's1'),
    'session-key': 'sess-selftest'
  }, extra || {});

  console.log('\n一 · probe：402 取账并落地状态');
  const r1 = await a2m.cmdProbe(probeArgs());
  check('probe 返回 402 分支（退出码 0 / phase=challenged）', () => {
    eq(r1.code, a2m.EXIT.OK, '退出码');
    eq(r1.payload.phase, 'challenged');
    eq(r1.payload.httpStatus, 402);
  });
  check('回传脱敏摘要：订单号与金额，且不含账单原文/签名', () => {
    eq(r1.payload.outTradeNo, 'ord_selftest_0001');
    eq(r1.payload.amount, '3.90');
    const dump = JSON.stringify(r1.payload);
    ok(!dump.includes(BILL.protocol.seller_signature), '回传里不应出现签名原文');
    ok(!dump.includes(b64url(JSON.stringify(BILL))), '回传里不应出现账单编码串');
  });
  const challengeFile = path.join(tmpRoot, 's1', 'challenge.json');
  const stateFile = path.join(tmpRoot, 's1', 'a2m-state.json');
  check('challenge.json 存在，且恰好一个 JSON 值、含 protocol 与 method 两个对象', () => {
    ok(fs.existsSync(challengeFile), 'challenge.json 未生成');
    const raw = fs.readFileSync(challengeFile, 'utf8');
    const parsed = JSON.parse(raw);                       // 单个 JSON 值才解析得过
    eq(parsed, BILL, '账单内容');
    eq(Object.keys(parsed).sort(), ['method', 'protocol']);
  });
  check('状态文件只记录业务头，控制头（Authorization）已被剔除', () => {
    const st = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    eq(st.request.url, base + '/v1/orders');
    eq(st.request.method, 'POST');
    eq(st.request.body, REQ_BODY);
    eq(st.request.headers, [{ name: 'Content-Type', value: 'application/json' }], '状态里的头');
    eq(st.challenge.out_trade_no, 'ord_selftest_0001');
  });
  check('控制头不转发：Authorization 未到达业务端点', () => {
    ok(lastSeenRequest, '未记录到请求');
    ok(!('authorization' in lastSeenRequest.headers), 'Authorization 被转发了');
    eq(lastSeenRequest.body, REQ_BODY, '业务请求体应原样送达');
  });

  console.log('\n二 · pay：交给官方能力，参数与原请求一致（dry-run，不真实付款）');
  const r2 = await a2m.cmdPay({ 'state-dir': path.join(tmpRoot, 's1'), 'dry-run': true });
  check('pay 组装的命令为官方 402-buyer-pay，且 --file 指向 probe 落地的账单文件', () => {
    const c = r2.payload.command;
    eq(c[0], 'alipay-bot');
    eq(c[1], '402-buyer-pay');
    eq(c[c.indexOf('--file') + 1], challengeFile);
  });
  check('pay 复用原请求参数（url / method / body / header 逐字段一致）', () => {
    const c = r2.payload.command;
    eq(c[c.indexOf('--resource-url') + 1], base + '/v1/orders');
    eq(c[c.indexOf('--method') + 1], 'POST');
    eq(c[c.indexOf('--data') + 1], REQ_BODY);
    eq(c[c.indexOf('--header') + 1], 'Content-Type:application/json');
  });
  check('pay 携带官方必填的 --intent-summary 与会话标识', () => {
    const c = r2.payload.command;
    ok(c.includes('--intent-summary'), '缺 --intent-summary');
    ok(c[c.indexOf('--intent-summary') + 1].length > 0, '--intent-summary 为空');
    eq(c[c.indexOf('--session-id') + 1], 'sess-selftest');
    ok(c.includes('--json'));
  });

  console.log('\n三 · complete：状态不明先查单，用原订单号');
  const r3 = await a2m.cmdComplete({ 'state-dir': path.join(tmpRoot, 's1'), 'dry-run': true });
  check('complete 走官方 402-query-payment-status，并带上原订单号（不重新下单）', () => {
    const c = r3.payload.command;
    eq(c[0], 'alipay-bot');
    eq(c[1], '402-query-payment-status');
    eq(c[c.indexOf('--out-shake-no') + 1], 'ord_selftest_0001');
    eq(c[c.indexOf('--resource-url') + 1], base + '/v1/orders');
    eq(c[c.indexOf('--data') + 1], REQ_BODY);
    ok(!c.includes('402-buyer-pay'), 'complete 不得重新发起下单');
  });

  console.log('\n四 · 200 分支：已付款/免费端点直接交付，不需支付');
  const r4 = await a2m.cmdProbe(probeArgs({
    'state-dir': path.join(tmpRoot, 's2'), header: ['Content-Type: application/json', 'X-Test-State: paid']
  }));
  check('probe 收到 200 → 退出码 3、phase=delivered、资源原样回传', () => {
    eq(r4.code, a2m.EXIT.DIRECT, '退出码应为 3');
    eq(r4.payload.phase, 'delivered');
    eq(r4.payload.resource.content.deliver_token, 'DT_SELFTEST');
  });

  console.log('\n五 · 异常分支必须显式报错（不得静默降级）');
  const e5 = await expectError(() => a2m.cmdProbe(probeArgs({ url: base + '/v1/no-challenge', 'state-dir': path.join(tmpRoot, 'e5') })));
  check('402 但无账单头 → 报错并提示核对已登记的业务端点', () => {
    eq(e5.exitCode, a2m.EXIT.ERR);
    ok(/没有账单/.test(e5.message), '错误信息未点明缺账单头');
  });
  const e6 = await expectError(() => a2m.cmdProbe(probeArgs({ url: base + '/v1/bad-challenge', 'state-dir': path.join(tmpRoot, 'e6') })));
  check('账单头不是含 protocol/method 的 JSON → 报错', () => {
    ok(/protocol \/ method/.test(e6.message), '错误信息未点明账单结构');
  });
  const e7 = await expectError(() => a2m.cmdProbe(probeArgs({ url: base + '/boom', 'state-dir': path.join(tmpRoot, 'e7') })));
  check('非 402 非 200（如 500）→ 报错并带状态码', () => {
    eq(e7.extra.httpStatus, 500);
  });
  const e8 = await expectError(() => a2m.cmdPay({ 'state-dir': path.join(tmpRoot, 'never-probed'), 'dry-run': true }));
  check('未 probe 就 pay → 明确报错，不静默继续', () => {
    ok(/找不到状态文件/.test(e8.message));
  });
  const e9 = await expectError(() => a2m.cmdComplete({ 'state-dir': path.join(tmpRoot, 'never-probed'), 'dry-run': true }));
  check('未 probe 就 complete → 明确报错', () => {
    ok(/找不到状态文件/.test(e9.message));
  });
  const e10 = await expectError(() => a2m.cmdProbe(probeArgs({ url: 'https://u:p@example.com/v1/orders', 'state-dir': path.join(tmpRoot, 'e10') })));
  check('URL 含凭据 → 拒绝', () => { ok(/不得包含凭据/.test(e10.message)); });
  const e11 = await expectError(() => a2m.cmdProbe(probeArgs({ url: 'ftp://example.com/x', 'state-dir': path.join(tmpRoot, 'e11') })));
  check('URL 非 http(s) → 拒绝', () => { ok(/http\/https/.test(e11.message)); });

  console.log('\n六 · 未安装官方买家能力时，明确报错并给出安装命令');
  const savedEnv = { PATH: process.env.PATH, ALIPAY_BOT: process.env.ALIPAY_BOT, USERPROFILE: process.env.USERPROFILE, HOME: process.env.HOME };
  process.env.PATH = '';
  process.env.USERPROFILE = tmpRoot;
  process.env.HOME = tmpRoot;
  delete process.env.ALIPAY_BOT;
  const e12 = await expectError(() => a2m.cmdPay({ 'state-dir': path.join(tmpRoot, 's1'), 'dry-run': true }));
  check('找不到 alipay-bot → 退出码 4 + 官方安装命令', () => {
    eq(e12.exitCode, a2m.EXIT.NO_CLI, '退出码应为 4');
    ok(/@alipay\/agent-payment/.test(e12.extra.installCommand || ''), '未给出安装命令');
  });
  Object.assign(process.env, savedEnv);
  if (savedEnv.ALIPAY_BOT === undefined) delete process.env.ALIPAY_BOT;

  console.log('\n七 · 参数解析');
  check('parseArgs 支持重复 --header 与布尔开关', () => {
    const pa = a2m.parseArgs(['probe', '--url', 'https://x/y', '--header', 'A: 1', '--header', 'B: 2', '--dry-run']);
    eq(pa._, ['probe']);
    eq(pa.header, ['A: 1', 'B: 2']);
    eq(pa['dry-run'], true);
    eq(pa.url, 'https://x/y');
  });

  server.close();
  fs.rmSync(tmpRoot, { recursive: true, force: true });

  console.log('\n' + '-'.repeat(60));
  if (failures.length === 0) {
    console.log('a2m-pay 离线自测：全部 ' + pass + ' 项断言通过 \u2714（未发起真实付款、未联网）\n');
    process.exit(0);
  }
  console.log('a2m-pay 离线自测：' + failures.length + ' 项失败 \u2717');
  failures.forEach(f => console.log('  · ' + f));
  console.log('');
  process.exit(1);
}

main().catch(e => {
  console.error('\n\u2717 自测异常中断：' + (e.stack || e.message));
  process.exit(1);
});
