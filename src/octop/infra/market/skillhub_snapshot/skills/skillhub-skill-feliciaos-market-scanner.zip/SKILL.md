---
name: skillhub-skill-feliciaos-market-scanner
description: "Groq API key for LLaMA 3.3 70B inference."
---

# FeliciaOS Market Scanner

Performs deep crypto market intelligence analysis powered by LLaMA 3.3 70B.

## What it does
- Reads current market sentiment and BTC dominance
- Identifies key technical levels and trend direction
- Scans for pre-pump on-chain signals
- Provides stop-loss and position sizing guidance
- Returns 3-5 token watchlist with reasoning

## Usage
Install this skill, set your GROQ_API_KEY, then ask your agent:
- "Run a market scan"
- "Scan the market for BTC"
- "Give me a crypto market report"

## Output
Structured market intelligence report. Always ends with NFA disclaimer.

## Built by
Pascal Chidera (@chipasleo) — Anambra, Nigeria
Powered by FeliciaOS autonomous intelligence engine.
