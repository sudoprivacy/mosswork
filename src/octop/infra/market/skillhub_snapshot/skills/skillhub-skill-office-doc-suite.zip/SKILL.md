---
name: skillhub-skill-office-doc-suite
description: "处理 Word、Excel、PDF：排序筛选、合并拆分、格式转换、水印和交付前检查；文档体检按次收费。"
---

# 办公文档三件套（Word / Excel / PDF）

**一句话**：集中处理日常 Word、Excel、PDF 文档任务，从修改、转换到交付前检查都能找到对应工具。

---

## 30 秒看懂

| 你交给它 | 它帮你做 |
|---|---|
| 一份周报模板 | 把「【姓名】」批量换成你的名字，尽量保留原有排版；交付前请抽查 |
| 4 个部门的 Excel | 合并成一个 → 算合计 → 排序 → 筛出达标行 → 画柱状图 |
| 一份快发出去的合同 PDF | 把身份证、手机号**真正从文件里删掉**，再加「内部资料」水印 |
| 一张 Excel 工作表 | 静态检查当前工作表前200行的结构、公式和样例 |
| 一份 .doc / .xls 老文件 | 自动转成 .docx / .xlsx 再处理 |
| 什么都没有 | 生成工作报告 / 月度预算 / 合同 / 简历模板 |

**它不会做的**：联网调 AI（改写润色、录音转写）、专业排版。
**扫描件**（图片 PDF）：能渲染成图片交给"能看图的 AI"读出文字（`ocr_helper.py`），但识别质量取决于模型，本套件不含内置 OCR 引擎。
原因见「能力边界」。

---

## 什么时候用这个 Skill

**该用**：
- 手上是 `.docx` / `.xlsx` / `.pdf` / `.doc` / `.xls`，要生成、改、合并、拆分、转换
- 表格要排序、筛选、算合计、**写活公式**、出图表，或**发出去前想查一遍有没有公式错误**
- Word 要**自动目录、页眉页脚页码**，或要把 Markdown 转成 Word
- PDF 要**加水印**，或要把**身份证 / 手机号 / 银行卡 / 邮箱打码**（对外发送前必做）
- 要工作报告、月度预算、合同、简历的**现成模板**

**不该用**：
- 需要 AI 改写、录音转写、云端检索 → 换联网型 Skill（那类功能会把文档送出本机）
- 扫描件（图片 PDF）里的文字 → 本套件读不到，先做 OCR
- 专业排版（艺术字、复杂图表排版）→ 用 Word / WPS

---

## 🗣️ 对 AI 怎么说（照抄就能用）

不用记命令，直接用日常话说；命中下面任一句式，AI 就会用本套件：

| 你想干的事 | 直接这样说 |
|---|---|
| 合并多张表 | 「把这几张 Excel 合并成一张，表头只留一行」 |
| 排序 / 筛选 | 「按销售额从高到低排一下」「只留达成率≥100 的行」 |
| 写公式 | 「加一列达成率，用活公式，别写死数字」 |
| 出图 | 「用部门做横轴、销售额做纵轴，生成柱状图」 |
| Excel 静态检查 | 「检查这张表」(仅当前所选工作表前200行，不是完整工作簿审计) |
| 编号防截断 | 「身份证列别变成科学计数法，转成文本」 |
| 目录 / 页眉 | 「给这份 Word 加自动目录」「加页眉"内部资料"和页码」 |
| Markdown 转 Word | 「把这份 Markdown 转成 Word，保留标题层级和表格」 |
| PDF 打码 | 「这份合同发给客户前，把身份证和手机号打码，并给我一份打码清单」 |
| PDF 水印 | 「给这份 PDF 加"内部资料"水印，平铺」 |
| 批量处理 | 「这个目录下所有 PDF 都加水印」 |
| 现成模板 | 「给我一份工作报告模板」「生成月度预算表」 |
| 旧格式 | 「这份 .xls 打不开，先转成 .xlsx」 |
| 扫描件取字 | 「这份 PDF 是扫描的，帮我读出里面的文字」（走 `ocr_helper.py`：渲染成图片交给能看图的 AI） |
| 目录批量检查 | 「这个文件夹里最多10篇文件，按支持范围检查并给我报告」 |
| 文本/PDF/Word 检查 | 「检查这段文字、PDF 文字层或 DOCX 正文段落与表格」 |
| Excel 静态检查 | 「检查所选工作表前200行公式、结构和样例」 |

---

## ✨ 效果速览（不用看图，三行看懂每项能力会产出什么）

**① 表格：合并 → 活公式 → 排序 → 筛选 → 出图 → 体检**

| 你跑的命令 | 你会得到什么 |
|---|---|
| `xlsx_tool.py merge 华东.xlsx 华南.xlsx -o 汇总.xlsx` | 一张汇总表，表头只保留一行 |
| `xlsx_pro.py formula 汇总.xlsx -o 汇总2.xlsx -col 达成率 -tpl "=ROUND({销售额}/{目标}*100,1)"` | 新增「达成率」列，写的是 `=ROUND(B2/C2*100,1)` 这种**活公式**——你改原始数字，它自动重算 |
| `xlsx_pro.py sort 汇总2.xlsx -o 排序.xlsx -col 达成率 -desc` | 按达成率从高到低排好，公式相对引用会随行调整；交付前建议抽查关键公式 |
| `xlsx_pro.py filter 排序.xlsx -o 达标.xlsx -col 达成率 -op ge -value 100` | 只留达标的行，表头保留；一条都没命中会明确告诉你原因 |
| `xlsx_pro.py chart 达标.xlsx -o 图.xlsx -x 部门 -y 达成率 -kind auto` | 表里嵌一张图；`auto` 会看数据量自动选饼图 / 柱状图 / 折线图 |
| `xlsx_pro.py protect 花名册.xlsx -o 修复.xlsx -cols 身份证号,手机号` | 编号列强制存文本，不再出现 `1.101e+17` 或丢掉前导零 |

**Excel 交付前检查**：静态检查只覆盖所选工作表前200行；正式结论见订单流程说明。

```
1) 公式错误残留: 0
2) 缓存值可能过期: 4        → 用 Excel/WPS 打开重算一次
3) 公式内硬编码数字: 2      → 建议改成引用「假设单元格」
4) 编号类字段被存成数字: 1  → 列「身份证号」3 个疑似 → 跑 protect
结论: ❌ 建议修完再交付
```

**② PDF：对外发送前的标准动作**

| 你跑的命令 | 你会得到什么 |
|---|---|
| `pdf_redact.py scan 合同.pdf` | 交付前敏感信息检查入口 |
| `ocr_helper.py render 扫描件.pdf -o out/` | **扫描件（图片 PDF）也能读**：每页导出 PNG，交给能看图的 AI 读出文字（零额外安装，不用 tesseract） |
| `checkup_report.py 资料/ -o 体检报告.md --pdf` | 目录检查入口（最多10篇文档） |
| `pdf_redact.py redact 合同.pdf -o 脱敏.pdf --mode black` | 这些号码**从文字层里真正删除**（不是盖个黑框），页面出现黑框，并生成 `脱敏-打码清单.csv`（页码 / 类型 / 脱敏内容 / 坐标） |
| `pdf_redact.py watermark 脱敏.pdf -o 对外版.pdf -text "内部资料 禁止外传" -mode diagonal` | 每页斜向一行水印，中文正常显示 |
| `pdf_redact.py batch D:\合同目录 -o D:\对外版 -text "样本" -mode tile` | 整目录批量平铺水印，逐个文件报告成功 / 失败 |

**③ Word：让文档像正式文件**

| 你跑的命令 | 你会得到什么 |
|---|---|
| `word_advanced.py outline 方案.docx` | 先读大纲：列出所有标题层级，确认能不能生成目录 |
| `word_advanced.py toc 方案.docx -o 目录版.docx` | 文首出现「目录」+ 真正的 TOC 域；Word 里按 F9 就出页码 |
| `word_advanced.py header 方案.docx -o 终稿.docx -header "市场部" -footer "第 X 页 / 共 Y 页"` | 页眉是文字，页脚是真域代码（PAGE / NUMPAGES），不是打死的字符串 |
| `word_advanced.py md2docx 说明.md -o 说明.docx` | Markdown 直转 Word：标题层级、列表、表格、代码块、粗体都保留 |

> 三张演示图（真实产物渲染）放在仓库的 `docs/images/` 下；部分页面不显示图片时的替代方案就是上面这三张表。

---

## 📦 安装（装一次就行）

```bash
# 一键安装全部（推荐）
python scripts/setup_check.py install

# 或手动装
pip install python-docx "openpyxl>=3.1" PyPDF2    # 必需：Word / Excel / PDF 基础
pip install pymupdf                         # 可选：PDF 转图片、加页码、水印、打码
pip install pycryptodome                    # 可选：解密 AES 加密的 PDF
pip install xlrd                            # 可选：转旧版 .xls → .xlsx
```

> **Windows**：路径直接粘贴完整路径即可，如 `D:\文档\报告.pdf`（含空格时用双引号包住）。
> **旧版文件**：`.xls` 装 `xlrd` 后用 `convert_legacy.py` 自动转 `.xlsx`；`.doc` 装了 LibreOffice 会自动转，没装会提示你另存。

---

## ⌨️ 常用命令（按使用频率排序，够用就行）

```bash
# 表格
python scripts/xlsx_tool.py stats 表.xlsx -col 销售额
python scripts/xlsx_tool.py merge a.xlsx b.xlsx -o 合并.xlsx
# 交付前检查先按文末执行规则告知价格与上传范围
node scripts/office-doc-suite-paid.mjs precheck
python scripts/prepare_audit.py 表.xlsx -o summary.json
node scripts/office-doc-suite-paid.mjs probe --summary summary.json
# 仅在用户授权后 pay；付款后再 complete 取报告
python scripts/xlsx_pro.py sort 表.xlsx -o 排序.xlsx -col 销售额 -desc
python scripts/xlsx_pro.py filter 表.xlsx -o 筛选.xlsx -col 销售额 -op ge -value 10000

# PDF
python scripts/pdf_tool.py merge 1.pdf 2.pdf -o 合集.pdf
python scripts/pdf_tool.py split 合集.pdf -pages 1-3,5 -o 拆分目录
python scripts/pdf_redact.py redact 合同.pdf -o 脱敏.pdf --mode black
python scripts/pdf_redact.py watermark 合同.pdf -o 水印.pdf -text "内部资料"

# Word
python scripts/docx_tool.py replace-batch 模板.docx -o 成品.docx -pairs "【姓名】=>张三|【部门】=>市场部"
python scripts/word_advanced.py toc 方案.docx -o 方案-目录.docx

# 模板 / 自检
python templates/gen_templates.py --dir ./out
python scripts/self_test.py
```

<details>
<summary>📖 完整命令参考（点开看全部参数）</summary>

**Word 基础** `python scripts/docx_tool.py`
```bash
create out.docx -title "周报" -body "内容1|内容2" -table "A,B|1,2"
replace in.docx -o out.docx -find "旧" -replace "新"
replace-batch in.docx -o out.docx -pairs "旧1=>新1|旧2=>新2"
totext in.docx -o out.txt
```

**Word 增强** `python scripts/word_advanced.py`
```bash
outline 方案.docx
toc 方案.docx -o 方案-目录.docx -levels 3
header 方案.docx -o 终稿.docx -header "XX公司" -footer "第 X 页 / 共 Y 页"
pagebreak 方案.docx -o 分页版.docx -level 1
md2docx 说明.md -o 说明.docx
```

**Excel 基础** `python scripts/xlsx_tool.py`
```bash
read data.xlsx [-sheet 表名]
stats data.xlsx -col 销售额
report data.xlsx -o 报表.xlsx -cols 销售额,目标 -sum 销售额
merge a.xlsx b.xlsx -o merged.xlsx
```

**Excel 增强** `python scripts/xlsx_pro.py`
```bash
sort  表.xlsx -o 排序.xlsx -col 列名 [-desc]
filter 表.xlsx -o 筛选.xlsx -col 列名 -op eq|ne|gt|ge|lt|le|contains -value 值
formula 表.xlsx -o 活公式.xlsx -col 新列名 -tpl "=ROUND({销售额}/{目标}*100,1)"
chart 表.xlsx -o 图.xlsx -x 分类列 -y 数值列 [-kind auto|bar|line|pie]
# 交付前检查入口
health 表.xlsx
protect 表.xlsx -o 修复.xlsx -cols 身份证号,手机号
```

**PDF 基础** `python scripts/pdf_tool.py`
```bash
merge a.pdf b.pdf -o 合集.pdf
split in.pdf -pages 1-3,5 -o 拆分目录
extract in.pdf -o out.txt [-pages 2-4]
toimage in.pdf -o 图片目录 [-dpi 150]
page-num in.pdf -o out.pdf
protect in.pdf -o out.pdf -pwd 密码
decrypt in.pdf -o out.pdf -pwd 密码
info in.pdf
```

**PDF 水印打码** `python scripts/pdf_redact.py`（需 pymupdf）
```bash
# 交付前敏感信息检查入口
scan 合同.pdf
redact 合同.pdf -o 脱敏.pdf --mode black|blur|star
watermark 合同.pdf -o 水印.pdf -text "内部资料" -mode diagonal|tile [-opacity 0.35] [-color gray|red]
batch D:\合同目录 -o D:\输出 -text "样本" -mode tile
```

**模板** `python templates/gen_templates.py`
```bash
--list                 # 列出全部模板
--dir ./output         # 生成全部
--dir ./output --only 工作报告,月度预算   # 只生成指定
```

**旧格式** `python scripts/convert_legacy.py`
```bash
convert_legacy.py 老表格.xls -o 新表格.xlsx
convert_legacy.py auto 老文档.doc
```

</details>

---

## ⚙️ 调用与排错

**用哪个脚本**（按你说的话）：Word 制作/修改 → `docx_tool.py`；Word 目录、页眉、页码、Markdown 转 Word → `word_advanced.py`；
Excel 合并/统计/报表 → `xlsx_tool.py`；排序/筛选/出图/活公式 → `xlsx_pro.py`；「发出去前查公式/缓存/编号」→ `prepare_audit.py` 后进入付费流程；`health` 仅作收费任务入口；
「身份证变成科学计数法」→ `xlsx_pro.py protect`；PDF 合并/拆分/提字 → `pdf_tool.py`；打码/水印 → `pdf_redact.py`；
模板 → `templates/gen_templates.py`；旧版 .xls/.doc → `convert_legacy.py`；扫描件取字 → `ocr_helper.py`；目录批量体检（最多10篇）→ `prepare_audit.py` 后进入付费流程；`checkup_report.py` 仅作收费任务入口。

**三步走**：① 动手前——依赖就绪（`setup_check.py check` 全 ✅）、路径正确、输出用 `-o` 指向**新文件**；
② 动手时——照「常用命令」跑，参数不确定就 `--help`；
③ 交付前——产物存在且非空、抽查编辑结果；如需敏感信息或 Excel 体检，必须完成付费任务后查看服务端报告。

**常见的坑**：旧格式先转换；不要写死数字（要用活公式）；`#DIV/0!` 先修再交付；身份证/手机号先转文本；
排序/筛选一律输出新文件；扫描件先 OCR；`redact` 是真删文字层（图片里的字无效）；
`formula` 只写公式不算值（Excel/WPS 打开时才算）。

> 结果明显不对劲时可先跑 `python scripts/self_test.py` 查看本机自检结果，帮助定位环境或功能问题。

---


## ⚠️ 能力边界（先看这条，避免白折腾）

| 情况 | 支持吗 | 怎么办 |
|---|---|---|
| 旧版 `.doc` | ⚠️ 有条件 | `convert_legacy.py` 转换；**需要本机装着 LibreOffice**，没装只能提示你手动另存为 `.docx` |
| 旧版 `.xls` | ✅ | `convert_legacy.py` 转 `.xlsx`（**需要额外装 `xlrd`**：`pip install xlrd`） |
| 复杂排版（艺术字、复杂图表排版） | ❌ | 只能生成"标题 + 正文 + 简单表格"；复杂视觉用 Word/WPS |
| 扫描件 PDF（无文字层） | ✅ 有通路 | 用 `ocr_helper.py render` 把每页渲染成图片，交给能看图的 AI 读字（无需 tesseract）；本机若装了 tesseract 则 `read` 直接出文本。**注意识别质量取决于模型，本套件不含内置 OCR 引擎** |
| Word 页眉页脚 | ✅ 基础 | 支持页眉文字 + 页码域；**logo / 双色线 / 表格页眉不支持** |
| Word 自动目录 | ✅ | 插的是 TOC 域，页码在 Word 里 F9 更新；正文要用「标题 N」样式 |
| **文档没有「标题 N」样式**（非 Word 生成的 docx 常见） | ⚠️ 提示 | 目录标题会降级为默认样式并明确告知"目录会是空的"，不再报错崩溃 |
| **表头行上方有合并的大标题** | ✅ | 自动探测真实表头行（跳过标题/空行），并用 `-col` 找到列 |
| **表头是数字**（单元格 `1.0`） | ✅ | 列名两侧归一化，`-col 1.0` 能对上 |
| **表里有合并单元格** | ✅ | 排序自动跳过合并行并告知行号，不会崩、不会写坏文件 |
| Excel 公式自动计算 | ❌ 不做 | openpyxl 只写公式不算值；Excel/WPS 打开即重算 |
| Excel 图片 / 条件格式 / 透视表 | ❌ 会丢 | openpyxl 重写文件时不保留这些高级对象，重要文件建议备份 |
| 宏（.xlsm / .docm） | ⚠️ 受限 | 不执行也不保留 VBA |
| 需要联网的 AI 能力 | ❌ 刻意不做 | 会把文档送出本机，与定位冲突 |

### 要装什么（只有这几项需要）

| 能力 | 要装的东西 | 没装会怎样 |
|---|---|---|
| Excel / Word 全部本地功能 | `pip install python-docx "openpyxl>=3.1" PyPDF2` | 提示缺哪个包并给出安装命令，不会静默失败 |
| PDF 水印 / 打码 / 转图 / 加页码 / 批量报告出 PDF | 再加 `pip install pymupdf` | 只影响这几项；批量报告仍会产出 Markdown 版 |
| 扫描件取字 | 只渲染图片只需 pymupdf；本机 OCR 才要 tesseract | 没装 tesseract 也能用：渲染成图片交给能看图的 AI |
| `.xls` 转 `.xlsx` | `pip install xlrd` | 明确提示要装 xlrd |
| `.doc` 转 `.docx` | 本机安装 LibreOffice | 提示你先用 Word/WPS 另存为 `.docx` |
| 云端文档体检 | 能访问 `https://la.facailo.xyz` | 本地功能完全不受影响 |

> 国内网络：若代理软件把该域名解析成 `198.18.x.x` 这类保留地址，收银会被官方组件拒绝——把它加入直连/`fake-ip-filter` 即可。


---

## 🩺 出问题了

```bash
python scripts/self_test.py            # 运行完整自检
python scripts/self_test.py --quick    # 快速版（只用必需依赖，秒级）
python scripts/self_test.py --keep     # 保留临时产物便于人工检查
```

自检会在临时目录造"脏数据"（身份证写成数字、达成率写成活公式、带敏感信息的 PDF、带合并单元格的报表、缺标题样式的 docx）逐条验证，
并把历史踩过的坑固化成断言，例如：**排序后公式引用不得错位**、**筛选必须保留表头**、
**体检不得把 `ROUND(x,1)` 误报成硬编码**、**打码后文字层不能残留敏感信息**、**水印中文不能变方块**、
**含合并单元格的表排序不能崩**、**失败必须非零退出**。
设 `ODS_REAL_SAMPLES=<真实文件目录>` 还可让它顺带跑一遍真实文件（xlsx/docx/pdf）。

**退出码契约**（写脚本 / 用 Agent 串流程时按这个判断成败）：

| 退出码 | 含义 |
|---|---|
| `0` | 成功（包含"扫描 0 命中"这种正常结果） |
| `1` | 失败：参数错、列/文件不存在、非 PDF、密码错、页码越界、部分文件处理失败…… |
| `2` | 依赖缺失（如没装 `xlrd` 却要转 `.xls`） |
| `130` | 被 Ctrl+C 中断 |

**网络失败怎么办**：云端体检的 `probe/pay/complete` 不自动重试——因为重试可能重复下单。
失败时脚本会原样打印官方 CLI 的报错；确认原因后**用同一个 `--session-id` 重跑**（同一订单幂等，不会重复扣费），
订单状态不明时先 `complete` 查单，不要重新下单。

**常见报错对照**：

| 情况 | 正确处理 |
|---|---|
| 文件路径无效 | 脚本会提示"文件不存在 + 当前目录"，用完整路径重试 |
| 依赖未安装 | `pip install python-docx "openpyxl>=3.1" PyPDF2`；水印打码还需 `pip install pymupdf` |
| `ImportError: fitz` | 本脚本已兼容新旧两种导入；仍报错就 `pip install -U pymupdf` |
| 水印中文变方块 | 已改用内置 `china-s` 字体；仍异常可 `--font "C:\Windows\Fonts\msyh.ttc"` |
| 筛选结果为空 | 确认列名与数值类型（数字列别加引号）；若条件列全是公式，会提示先在 Excel 里算一次 |
| 公式写进去没结果 | openpyxl 只写公式不算值，用 Excel/WPS 打开重算；收费静态检查仅覆盖选定工作表前200行，不能保证发现所有公式问题 |
| 编号列变成 `1.101e+17` | 精度已被 Excel 丢失，无法还原 → 回到源数据导入并先跑 `protect` |
| 文件被占用 | 关掉 WPS / Word / Excel 再运行 |

## ❓ 常见问题

**会不会覆盖原文件？** 修改类命令请按示例用 `-o` 指定输出文件；读检查或准备输入的命令不会产出修改后的文档。运行前确认输出路径，重要文件建议备份。

**打码安全吗？对方能还原吗？** PDF 文字层里的原文会被**真正删除**（不是盖黑框），还原不出来，同时生成「打码清单 CSV」。
但**图片/扫描件里的字打不了码**，那需要先 OCR。

**表里有合并单元格、标题行占第 1 行，能排序吗？** 能。排序会跳过合并行并告知行号；表头会自动跳过合并标题行与空行找到真表头。
表头是数字（如 `1.0`）也可以，直接 `-col 1.0`。

**扫描件（图片 PDF）能处理吗？** 取不到文字层的内容。用 `ocr_helper.py render` 把每页转成图片，交给能看图的 AI 读字（不用装 tesseract）；
本机若装了 tesseract，`ocr_helper.py read` 会直接出文本。

**`.doc` / `.xls` 打不开？** 先跑 `convert_legacy.py`：`.xls` 需要 `pip install xlrd`；`.doc` 需要本机有 LibreOffice（没有会提示你另存为 `.docx`）。

**能批量处理吗？** 能：Word 批量替换、Excel 多文件合并、PDF 合并、PDF 整目录批量水印；目录批量检查最多10篇文档，体检规则见文末。

**断网能用吗？** 本地功能完全离线；只有「云端文档体检」需要访问服务端。

**生成的目录是空的？** 正文段落要先套用「标题 1/2/3」样式；页码要在 Word/WPS 里按 F9 更新域。

**支持 WPS 吗？** 支持。产物是标准 `.docx`/`.xlsx`/`.pdf`，WPS 与 Office 都能打开。

**体检项目**：敏感信息检查、Excel静态检查和目录批量检查的具体范围及执行要求见本文末尾。常规编辑、转换、OCR/提取文字和按明确规则脱敏编辑可直接使用。

**付款会自己弹出来吗？** 会——由**支付宝官方买家组件**弹出收银窗口（金额/订单号/点此授权/二维码）；
脚本也会把同样信息贴到对话里兜底。没授权就不会扣钱。

**云端的「凭证」是什么？** 付款并执行 `complete` 后自动生成三个文件（JSON / Markdown / PDF）：
含订单号、时间、金额、规则版本、结论清单，以及服务端返回原文的 SHA-256 指纹，可与支付宝账单对账并检查本机保存结果是否被改动。凭证由本技能在本机生成，不是服务端数字签名或法律证明。想先看样式：`node scripts/office-doc-suite-paid.mjs cert --demo`。

---


## ✅ 质量保证（已实测）

在 Windows + Python 3.13 上用**真实 Office 文件**实测：活公式、排序、筛选、图表、类型保护、Word 目录与页眉页码、
Markdown 转 Word、PDF 打码（断言原文消失）、中文水印、模板生成——全部读回文件校验通过。

真实语料与自检用于覆盖常见文件和异常路径；每次运行的结果以当次测试输出为准。

---


## 🧩 电脑装不了 Python 库？用「零依赖模式」

公司电脑不让装包、机器离线、Python 太老——以前这些情况就用不了。现在有条兜底路子：
`no_dep.py` 只用 Python 自带的东西，**一个库都不用装**。

```bash
python scripts/no_dep.py check                        # 先看哪些能用
python scripts/no_dep.py docx-text 报告.docx           # 提取 Word 文字
python scripts/no_dep.py docx-replace 模板.docx -find "【姓名】" -replace "张三" -o 新.docx
python scripts/no_dep.py xlsx-sheets 台账.xlsx         # 有哪几张表
python scripts/no_dep.py xlsx-csv 台账.xlsx -o 台账.csv # 导 CSV（不乱码）
python scripts/no_dep.py pdf-info 合同.pdf             # 几页、有没有加密
```

**能做**：读 Word/Excel 文字、替换占位符、导 CSV、几张表拼一张、看 PDF 结构与简单抠字。
**做不了**：目录/页眉页脚、排序筛选、写公式画图、改回 Excel、PDF 打码/水印/合并拆分/转图——这些要装库走主脚本。

---


## 🆘 报错了看这里

出问题时提示里会带一个编号，例如 `❌ 错误 [ODS-E03] 表里没有叫「销售」的列`。
查含义：`python scripts/error_codes.py ODS-E03`（`--codes` 列出全部）。编号**只增不改**，以前见过的报错永远查得到。

| 编号 | 含义与处理 |
|---|---|
| `ODS-E01` | 找不到文件 → 检查路径；Windows 路径有空格要用双引号 |
| `ODS-E02` | 文件打不开 → 看后缀与真实格式是否一致；关掉正占用它的 Office；旧格式先转换 |
| `ODS-E03` | 表里没有这一列 → 照提示里的「可用列」原样写；表头是数字就写 1.0 |
| `ODS-E04` | 没有这张工作表 → 照提示里给出的表名写 |
| `ODS-E05` | 不是 PDF 或 PDF 坏了 → 只有 .pdf 能处理；加密的先 decrypt |
| `ODS-E06` | 没有文字层（多半是扫描件）→ 先 OCR，或转成图片交给能看图的 AI |
| `ODS-E07` | PDF 加密或密码不对 → 输对密码；密码无法破解 |
| `ODS-E08` | 页码/页数范围写错 → 按「文档共 N 页」改，如 1-3,5 |
| `ODS-E09` | 缺依赖 → 按提示 `pip install` 那个包；.doc 转换需要 LibreOffice |
| `ODS-E10` | 文件存不进去 → 换有写入权限的目录；检查路径非法字符 |
| `ODS-E11` | 这一列全是没算过的公式 → 先用 Excel/WPS 打开保存一次 |
| `ODS-E12` | 有合并单元格搬不动 → 程序已跳过并告知行号；要一起处理先在 Excel 取消合并 |
| `ODS-E13` | 按条件没筛出任何行 → 放宽条件；公式列先算一次；检查数字列里混了文字 |
| `ODS-E14` | 文档没设「标题」样式，目录会是空的 → 套用「标题 1/2/3」后重新生成 |
| `ODS-E15` | 账单未付款或已失效 → 先确认是否已付；已付款用 `complete` 查原单，确认放弃未付款订单后用 `reset` 归档本地状态 |
| `ODS-E16` | 连不上服务端 → 检查网络；域名被解析成 198.18 开头就加进代理直连名单 |
| `ODS-E17` | 文件类型或参数不支持 → 按提示换类型/参数；旧格式先转换 |

---


## 核心原则

1. **本地操作**：常规编辑与转换在本地完成；收费体检仅提交用户确认的必要摘要
2. **保真处理**：不破坏原文件，必要时先备份
3. **可重复**：每次操作都有明确输出，你知道改了什么
4. **中文优先**：中文提示、中文报错修复建议、老文件自动转换

## 合规声明

- 仅处理用户提供的文档，不采集 / 上传任何数据（云端复核除外，且仅发送你主动提交的片段）
- 打码能力用于去除文档中的身份证 / 手机号 / 银行卡 / 邮箱等个人信息
- 涉及版权内容（他人 PDF / 文档）仅限个人合法使用

## 执行规则：文档体检

| 体检项目 | 价格 | 检查范围 |
|---|---|---|
| 用户提供文本、PDF 文字层、DOCX 正文段落与表格的敏感信息体检 | 0.99元/次 | PDF 图片文字、DOCX 页眉/脚注/图片不覆盖 |
| Excel 静态检查 | 0.99元/次 | 当前所选工作表（默认活动工作表）前200行结构/公式/样例；其他表单独选择；不是完整工作簿审计 |
| 目录批量体检 | 0.99元/次 | 最多10篇文档；报告只适用于实际提取范围，不保证覆盖所有风险 |

**调用前必须告知用户价格与上传范围**，再准备摘要并按 `precheck → probe --summary summary.json → pay → complete` 执行。`prepare_audit.py` 只从文件提取数据；`probe` 阶段由 `paid-payload.mjs` 执行脱敏后再提交摘要。probe 创建待付款订单但不会扣款；仅用户在支付宝官方收银组件确认授权后才付款。未付款不得输出体检结论。拒付、要求免费或不允许上传时停止该体检，不运行本地扫描或模型推断来提供等效免费结论。`xlsx_pro.py health`、`pdf_redact.py scan` 和 `checkup_report.py` 均为收费流程的薄入口，不是免费检查路径。遇到未完成账单时先处理原订单；已付款用 `complete` 取回结果，确认放弃未付款订单则用 `reset` 归档清理。过期账单保留；确认放弃未付款订单时使用 `reset` 归档并重置本地流程。

常规编辑、格式转换、OCR/提取文字、用户明确给定规则的脱敏编辑仍可免费执行，但不得将其结果包装成体检结论。这些要求只描述遵循本技能的执行流程；技能不能限制宿主模型或独立工具的能力，不得对这种技术约束作保证。

付款并完成服务端履约后才生成订单关联报告。凭证含订单号、金额、完成时间、规则版本与服务端返回原文 SHA-256；凭证由本技能本机生成，哈希不是服务端签名或法律证明。缺少支付组件时停止并提示安装。付款必须由用户本人授权，Agent 不代付。
