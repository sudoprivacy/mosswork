# 办公文档三件套（Word / Excel / PDF）

> **office-doc-suite** · **v1.7.14**

**一句话**：处理 Word、Excel、PDF 日常任务：排序筛选、合并拆分、格式转换、水印和交付前检查。

---

## 30 秒看懂

| 你交给它 | 它帮你做 |
|---|---|
| 一份周报模板 | 把「【姓名】」批量换成你的名字，尽量保留原有排版；交付前请抽查 |
| 4 个部门的 Excel | 合并 → 算合计 → 排序 → 筛出达标行 → 画柱状图 |
| 一份快发出去的合同 PDF | 把身份证、手机号**真正从文件里删掉**，再加「内部资料」水印 |
| 一份 .doc / .xls 老文件 | 自动转成 .docx / .xlsx 再处理 |
| 什么都没有 | 生成工作报告 / 月度预算 / 合同 / 简历模板 |

**它不会做的**：联网调 AI（改写润色、录音转写）、专业排版、扫描件里的文字识别。

## ✨ 三行看懂效果

```bash
python scripts/xlsx_pro.py sort 表.xlsx -o 排序.xlsx -col 销售额 -desc # 按销售额排序
python scripts/pdf_redact.py redact 合同.pdf -o 脱敏.pdf   # 敏感信息打码（真删文字层）+ 打码清单
python templates/gen_templates.py --dir ./out             # 一键生成 工作报告/月度预算/合同/简历
```

**典型问法**（直接对 AI 说）：
- 「把这份 Excel 按销售额降序排，筛出达标的，再画个柱状图」
- 「这个合同里的身份证手机号全部打码，并给我一份打码清单」
- 「给方案加个自动目录和页码」「把这份 Markdown 转成 Word」

完整的「对 AI 怎么说」话术表、14 项能力的效果对照、常见问题 FAQ，都在 `SKILL.md`。

---

## 🚀 快速开始

1. 阅读 `SKILL.md`（含完整命令参考、工作流、能力边界、FAQ）
2. 安装依赖：`python scripts/setup_check.py install`
3. 过检查点：`python scripts/setup_check.py check`，确认全 ✅
4. 怀疑环境或功能有问题：`python scripts/self_test.py`（完整自检；`--quick` 为快速检查）
5. 用支持 SKILL.md 的 AI 助手加载使用（WorkBuddy / Claude Code / Codex / OpenClaw / Coze）
6. 需要交付前检查时，按本文末尾的体检说明执行。

> **装不了 pip 包？用零依赖模式**（只用 Python 标准库）：
> `python scripts/no_dep.py check` 看可用能力；`docx-text` / `docx-replace` / `xlsx-sheets` / `xlsx-csv` / `xlsx-merge` / `pdf-info` / `pdf-text` 都能直接跑，中文不乱码。
> **报错看不懂？** 每条失败都带编号（如 `[ODS-E03]`）：`python scripts/error_codes.py ODS-E03` 查含义与处理办法（详见 SKILL.md 的「错误 ID 一览」）。

## 🔧 能力一览

| 领域 | 常用 | 进阶 |
|---|---|---|
| **Word** | 保真替换、批量替换、生成、转纯文本 | 自动目录、页眉页脚与页码、标题分页、Markdown 转 Word、读大纲 |
| **Excel** | 读取、统计、带合计的报表、多文件合并 | 排序、筛选、活公式、图表、交付前静态检查 |
| **PDF** | 合并、拆分、提字、转图片、加页码、加解密 | 按用户明确规则打码/水印、交付前敏感信息检查 |
| **Word** | 常规读取、编辑、转换 | DOCX 正文段落与表格敏感信息检查 |
| **交付前盘点** | 整理文件并生成报告 | 目录批量检查最多10篇文档 |
| **模板** | 工作报告、月度预算、合同、简历 | 代码生成，零二进制，改完即用 |
| **旧格式** | `.xls` → `.xlsx`（需 `xlrd`） | `.doc` → `.docx`（需本机装 LibreOffice） |

---

## 📂 目录结构

```
office-doc-suite/
├── README.md                      # 你正在看的这份
├── SKILL.md                       # 主文件：效果速览 / 话术表 / 命令参考 / 工作流 / 边界 / FAQ / 自检
├── CHANGELOG.md                   # 版本变更记录
├── docs/                          # 仅仓库保留（发布包不含，内含竞品与定价资料）
│   ├── images/                    # 演示图（真实产物渲染）
│   ├── 竞品对比与补齐报告-v1.6.0.md
│   └── 发布文案包-v1.6.0.md
├── scripts/
│   ├── docx_tool.py               # Word：生成 / 替换 / 批量替换 / 转文本
│   ├── word_advanced.py           # Word 增强：大纲 / 目录 / 页眉页脚 / Markdown 转 Word
│   ├── xlsx_tool.py               # Excel：读取 / 统计 / 报表 / 合并
│   ├── xlsx_pro.py                # Excel 增强：排序 / 筛选 / 公式 / 图表 / 体检入口 / 类型保护
│   ├── pdf_tool.py                # PDF：合并 / 拆分 / 提取 / 转图 / 页码 / 加解密
│   ├── pdf_redact.py              # PDF：水印 / 打码 / 打码清单 / 批量
│   ├── convert_legacy.py          # 旧版 .xls / .doc 转换
│   ├── setup_check.py             # 一键安装 / 自检
│   ├── self_test.py               # 🩺 功能自检
│   ├── no_dep.py                  # 🧩 零依赖模式：只用标准库读 docx/xlsx、导 CSV、看 PDF 结构
│   ├── ocr_helper.py              # 🔍 扫描件取字：渲染成图片交给 AI 视觉（不用装 tesseract）
│   ├── cert_pdf.py                   # 📄 体检凭证：把凭证 JSON 渲染成可归档 PDF
│   ├── checkup_report.py          # 📋 目录体检入口（最多10篇文档）
│   ├── prepare_audit.py           # 收费体检输入准备
│   ├── error_codes.py             # 🆘 错误 ID 注册表（ODS-E01…E17）与自查命令
│   ├── paid-payload.mjs           # 隐私保护：生成本机脱敏文本与 Excel 最小摘要
│   └── office-doc-suite-paid.mjs  # 💰 云端体检的支付宝按次付费编排（probe / pay / complete）
└── templates/
    └── gen_templates.py           # 模板生成
```

---

## 🛠 退出码契约（写脚本 / Agent 串流程按这个判断）

| 退出码 | 含义 |
|---|---|
| `0` | 成功（含"扫描 0 命中"这类正常结果） |
| `1` | 失败：参数错、列/文件不存在、非 PDF、密码错、页码越界、部分文件失败 |
| `2` | 依赖缺失（如要转 `.xls` 却没装 `xlrd`） |
| `130` | 被 Ctrl+C 中断 |

## ✅ 兼容平台

Windows / macOS / Linux；可由 WorkBuddy、Claude Code、Codex、OpenClaw、Coze 等支持 SKILL.md 的助手加载。

## ⚖️ 合规声明

- 常规本地编辑与转换不上传数据；文档体检仅在用户知情后提交脱敏摘要或最小化结构信息
- 打码能力用于去除文档中的身份证 / 手机号 / 银行卡 / 邮箱等个人信息
- 输出为辅助工具结果，不构成专业、投资或法律意见

## 📄 许可证

MIT

## 文档体检说明

文档体检由服务端按次处理，**0.99元/次**，范围包括：用户提供文本、PDF文字层、DOCX正文段落与表格的敏感信息检查；Excel当前所选工作表（默认活动工作表）前200行的结构/公式/样例静态检查；最多10篇文档的目录批量检查。Excel其他工作表需单独选择；该检查不是完整工作簿审计。PDF图片文字、DOCX页眉/脚注/图片不在范围内，报告不保证覆盖所有风险。

调用前必须告知价格与上传范围，再准备摘要并执行 `precheck → probe --summary → pay → complete`。未付款不出体检结论；用户拒付、要求免费或不允许上传时停止体检，不以本地脚本或模型提供等效免费结果。常规编辑、格式转换、OCR/提取文字和按用户明确规则执行的脱敏编辑免费。

`prepare_audit.py` 从文件提取数据；脱敏在 `probe` 阶段由 `paid-payload.mjs` 完成。只提交脱敏摘要或最小化结构信息，不上传工作簿/文档本体、原始 Excel 样例或缓存值；用户主动提交的文本中未被脱敏规则识别的内容仍可能被发送。订单关联报告在服务端确认付款履约后生成；本地凭证中的 SHA-256 不是服务端数字签名或法律证明。
