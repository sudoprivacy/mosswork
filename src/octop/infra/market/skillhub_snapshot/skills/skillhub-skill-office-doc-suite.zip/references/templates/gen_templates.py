#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文档模板生成器（代码生成，零二进制依赖）

v1.6.0 新增（对标竞品「模板市场」）：不从网上下模板，全部用 python-docx / openpyxl
现场生成，版本可控、无版权风险、可二次修改。

  工作报告.docx   周报/月报/项目汇报骨架（含待办与风险栏）
  月度预算.xlsx   收入/支出/汇总三表 + 常用公式
  合同.docx       通用合同骨架（甲乙方/标的/价款/违约/争议解决）
  简历.docx       中文简历骨架

用法:
  python templates/gen_templates.py --dir ./output
  python templates/gen_templates.py --dir ./output --only 工作报告,月度预算
  python templates/gen_templates.py --list
"""
import argparse
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def need(mod, pipname):
    try:
        __import__(mod)
    except ImportError:
        print(f"❌ 缺少依赖 {pipname}")
        print(f"   提示: pip install {pipname}")
        sys.exit(1)


def tpl_report(path):
    need("docx", "python-docx")
    from docx import Document
    from docx.shared import Pt
    d = Document()
    d.add_heading("工作报告", 0)
    p = d.add_paragraph("周期：____年__月__日 — ____年__月__日    部门：________    撰写人：________")
    p.runs[0].font.size = Pt(9)
    d.add_heading("一、本期结论（先写结论，细节放后面）", 1)
    for _ in range(3):
        d.add_paragraph("· ", style="List Bullet")
    d.add_heading("二、关键进展", 1)
    for _ in range(4):
        d.add_paragraph("· ", style="List Bullet")
    d.add_heading("三、数据指标", 1)
    t = d.add_table(rows=3, cols=4)
    t.style = "Table Grid"
    for j, h in enumerate(["指标", "目标", "实际", "达成率"]):
        t.cell(0, j).text = h
    for i in range(1, 3):
        for j in range(4):
            t.cell(i, j).text = ""
    d.add_heading("四、问题与风险", 1)
    for _ in range(3):
        d.add_paragraph("· ", style="List Bullet")
    d.add_heading("五、下期计划（含负责人与时间）", 1)
    t2 = d.add_table(rows=4, cols=4)
    t2.style = "Table Grid"
    for j, h in enumerate(["事项", "负责人", "完成时间", "状态"]):
        t2.cell(0, j).text = h
    d.save(path)
    return path


def tpl_budget(path):
    need("openpyxl", "openpyxl")
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "收入"
    ws.append(["日期", "类别", "来源", "金额", "备注"])
    ws.append(["", "", "", "", ""])
    ws.append(["", "", "", "", ""])
    cost = wb.create_sheet("支出")
    cost.append(["日期", "类别", "项目", "金额", "备注"])
    for i in range(2, 8):
        cost.append(["", "", "", "", ""])
    total = wb.create_sheet("汇总")
    total.append(["项目", "金额", "备注"])
    total.append(["收入合计", "=SUM(收入!D2:D100)", "自动汇总"])
    total.append(["支出合计", "=SUM(支出!D2:D100)", "自动汇总"])
    total.append(["结余", "=B2-B3", "收入-支出"])
    for sh in wb.worksheets:
        for c in sh[1]:
            c.font = Font(bold=True)
            c.fill = PatternFill("solid", fgColor="D9E2F3")
        sh.column_dimensions["A"].width = 14
        sh.column_dimensions["D"].width = 14
    wb.save(path)
    return path


def tpl_contract(path):
    need("docx", "python-docx")
    from docx import Document
    d = Document()
    d.add_heading("合同（通用骨架）", 0)
    p = d.add_paragraph("合同编号：________    签订地点：________    签订日期：____年__月__日")
    parties = [
        ("甲方（委托方）", "名称：________\n统一社会信用代码：________\n地址：________\n联系人/电话：________"),
        ("乙方（服务方）", "名称：________\n统一社会信用代码：________\n地址：________\n联系人/电话：________"),
    ]
    for title, body in parties:
        d.add_heading(title, 1)
        d.add_paragraph(body)
    clauses = [
        ("第一条  合同标的", "乙方为甲方提供：________________________。具体范围、交付物清单见附件一。"),
        ("第二条  合同价款与支付方式", "总价款人民币（含税）￥________元；支付节点：① 签约后__日内付__%；② 交付验收后__日内付__%。"),
        ("第三条  交付与验收", "交付期限：____年__月__日前；甲方应在收到交付物后__个工作日内完成验收，逾期未提出书面异议视为验收通过。"),
        ("第四条  双方权利义务", "甲方：按约定提供资料与配合。乙方：按约定完成服务，并对甲方资料负有保密义务。"),
        ("第五条  保密条款", "双方对因履行本合同知悉的商业秘密互负保密义务，保密期限为本合同终止后__年。"),
        ("第六条  违约责任", "一方违约给对方造成损失的，应承担赔偿责任；违约金比例为合同总价的__%。"),
        ("第七条  知识产权", "交付成果的著作权归属：□归甲方  □归乙方  □共有；具体见附件二。"),
        ("第八条  争议解决", "因本合同发生的争议，双方应友好协商；协商不成，提交________仲裁委员会仲裁 / ________人民法院诉讼。"),
        ("第九条  合同生效", "本合同一式__份，甲乙双方各执__份，自双方签字盖章之日起生效。"),
    ]
    for title, body in clauses:
        d.add_heading(title, 1)
        d.add_paragraph(body)
    d.add_heading("附件", 1)
    d.add_paragraph("附件一：交付物清单    附件二：知识产权归属    附件三：其他约定")
    t = d.add_table(rows=4, cols=2)
    t.style = "Table Grid"
    for i, s in enumerate(["甲方（盖章）", "乙方（盖章）", "授权代表", "日期"]):
        t.cell(i, 0).text = s
        t.cell(i, 1).text = ""
    d.save(path)
    return path


def tpl_resume(path):
    need("docx", "python-docx")
    from docx import Document
    from docx.shared import Pt
    d = Document()
    d.add_heading("个人简历", 0)
    p = d.add_paragraph("姓名｜手机号｜邮箱｜所在城市｜（可选）GitHub / 个人主页")
    p.runs[0].font.size = Pt(10)
    sections = [
        ("求职意向", "目标岗位：________\n期望城市：________\n到岗时间：________"),
        ("教育背景", "学校｜专业｜学历｜起止时间\n主修课程/成绩亮点：________"),
        ("工作经历", "公司｜职位｜起止时间\n- 负责：________\n- 成果（带数字）：________"),
        ("项目经历", "项目名｜角色｜时间\n- 背景：________\n- 我的工作：________\n- 结果：________"),
        ("专业技能", "按类别罗列，每类 2-4 条，避免『精通/熟练』空话"),
        ("证书与荣誉", "证书名｜颁发方｜时间"),
    ]
    for title, body in sections:
        d.add_heading(title, 1)
        d.add_paragraph(body)
    d.save(path)
    return path


TEMPLATES = {
    "工作报告": tpl_report,
    "月度预算": tpl_budget,
    "合同": tpl_contract,
    "简历": tpl_resume,
}


def main():
    p = argparse.ArgumentParser(description="文档模板生成器（代码生成）")
    p.add_argument("--dir", dest="outdir", default="./output", help="输出目录")
    p.add_argument("--only", default="", help="只生成指定模板，逗号分隔")
    p.add_argument("--list", action="store_true", help="列出全部模板")
    a = p.parse_args()
    if a.list:
        print("可用模板：" + "、".join(TEMPLATES))
        for name in TEMPLATES:
            print(f"  - {name}")
        return
    names = [x.strip() for x in a.only.split(",") if x.strip()] or list(TEMPLATES)
    unknown = [n for n in names if n not in TEMPLATES]
    if unknown:
        print(f"❌ 未知模板: {unknown}；可用: {list(TEMPLATES)}")
        sys.exit(1)
    os.makedirs(a.outdir, exist_ok=True)
    ok, fail = [], []
    for n in names:
        ext = ".xlsx" if n == "月度预算" else ".docx"
        dst = os.path.join(a.outdir, n + ext)
        try:
            TEMPLATES[n](dst)
            ok.append(n)
            print(f"✅ {n} → {dst}")
        except Exception as e:
            fail.append(n)
            print(f"⚠️ {n} 生成失败: {e}")
    print(f"\n共生成 {len(ok)}/{len(names)} 个模板 → {os.path.abspath(a.outdir)}")
    if fail:
        sys.exit(1)


if __name__ == "__main__":
    main()