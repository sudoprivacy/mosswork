#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ocr_helper.py — 扫描件（无文字层 PDF）的处理通道

为什么需要它：本套件原先对扫描件只能说"读不到，请先 OCR"——用户等于被卡住。
竞品（pdf-image-text-extractor）赢在这一步：**把扫描页渲染成图片，交给能看图的 AI**，
不需要装 tesseract 也能拿到文字。这里把这条通道补上：

  通道 A（推荐，零额外安装）：render 把每页导出 PNG → 交给带视觉能力的模型读
  通道 B（本机装了 OCR 就自动用）：read 直接调 tesseract/pytesseract 出文本

用法:
  python scripts/ocr_helper.py check                      # 看这台机器能用哪条通道
  python scripts/ocr_helper.py render 扫描件.pdf -o out/   # 每页导出 PNG（给 AI 看图）
  python scripts/ocr_helper.py read   扫描件.pdf -o t.txt # 有 OCR 就直接出文本，没有就导出图片并给引导
  python scripts/ocr_helper.py read   扫描件.pdf -pages 1-3

错误编号：见 SKILL.md「错误 ID 一览」（E05 不是 PDF / E06 扫描件 / E09 缺依赖）
"""
import argparse
import os
import subprocess
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt
except Exception:
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")


def die(code, msg, hint=None):
    print(_fmt(code, msg, hint))
    sys.exit(1)


def _fitz():
    try:
        import pymupdf as fitz
        return fitz
    except ImportError:
        try:
            import fitz
            return fitz
        except ImportError:
            die("ODS-E09", "缺 pymupdf（渲染扫描页要用它）", "pip install pymupdf")
    return None


def open_pdf(path):
    fitz = _fitz()
    if not os.path.exists(path):
        die("ODS-E01", f"文件不存在 → {path}")
    try:
        doc = fitz.open(path)
    except Exception as e:
        die("ODS-E05", f"打不开这个 PDF：{e}", "确认是 .pdf；加密文件先用 pdf_tool.py decrypt 解密")
    if not getattr(doc, "is_pdf", True):
        die("ODS-E05", f"这不是 PDF 文件 → {path}", "本工具只处理 .pdf")
    return doc


def parse_pages(spec, total):
    if not spec:
        return list(range(total))
    out = []
    for part in str(spec).split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            try:
                a, b = int(a), int(b)
            except ValueError:
                die("ODS-E08", f"页码看不懂：{part}", "示例：1-3,5")
            if a < 1 or b > total or a > b:
                die("ODS-E08", f"页码超出范围：{part}（文档共 {total} 页）")
            out.extend(range(a - 1, b))
        else:
            try:
                n = int(part)
            except ValueError:
                die("ODS-E08", f"页码看不懂：{part}", "示例：1-3,5")
            if n < 1 or n > total:
                die("ODS-E08", f"页码超出范围：{n}（文档共 {total} 页）")
            out.append(n - 1)
    return out


def render(doc, pages, out_dir, dpi):
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(doc.name))[0] or "page"
    paths = []
    for i in pages:
        out = os.path.join(out_dir, f"{base}-p{i+1}.png")
        pix = doc[i].get_pixmap(dpi=dpi)
        pix.save(out)
        paths.append(out)
    return paths


def ocr_available():
    """返回 (可用通道, 说明)"""
    try:
        import pytesseract  # noqa: F401
        try:
            subprocess.run(["tesseract", "--version"], capture_output=True, timeout=10, check=True)
            return "pytesseract+tesseract", "本机 OCR 可直接出文本"
        except Exception:
            return "render-only", "装了 pytesseract 但找不到 tesseract 程序 → 只能渲染图片给 AI 看"
    except ImportError:
        pass
    if subprocess.run(["where", "tesseract"] if os.name == "nt" else ["which", "tesseract"],
                      capture_output=True).returncode == 0:
        return "tesseract-cli", "发现 tesseract 命令，可直接 OCR"
    return "render-only", "没有 OCR 程序 → 用渲染图片交给能看图的 AI（零额外安装）"


def cmd_check(a):
    ch, why = ocr_available()
    print("扫描件处理通道：")
    print(f"  · 通道 A（始终可用）：render 渲染页面为 PNG → 交给带视觉能力的模型识别")
    print(f"  · 通道 B（看本机）：{ch} —— {why}")
    if ch == "render-only":
        print("    想装通道 B：Windows 可装 tesseract-ocr（含 chi_sim 中文包）+ pip install pytesseract；")
        print("    不装也完全可用：通道 A 就是竞品 pdf-image-text-extractor 的做法。")
    return 0


def cmd_render(a):
    doc = open_pdf(a.file)
    pages = parse_pages(a.pages, doc.page_count)
    paths = render(doc, pages, a.out or "ocr_pages", a.dpi)
    doc.close()
    print(f"✅ 已导出 {len(paths)} 张页面图片（{a.dpi} dpi）→ {os.path.dirname(paths[0]) if paths else a.out}")
    for p in paths:
        print(f"   {p}")
    print("\n下一步：把这些图片交给带视觉能力的模型，让它逐页读出文字（图里的表格也能读）。")
    return 0


def cmd_read(a):
    doc = open_pdf(a.file)
    pages = parse_pages(a.pages, doc.page_count)
    ch, _ = ocr_available()
    texts = []
    if ch == "pytesseract+tesseract":
        import pytesseract
        from PIL import Image  # pytesseract 依赖
        for i in pages:
            pix = doc[i].get_pixmap(dpi=a.dpi)
            img = Image.open(io_bytes(pix))
            texts.append(pytesseract.image_to_string(img, lang="chi_sim+eng"))
        body = "\n\n".join(f"--- 第 {i+1} 页 ---\n{t}" for i, t in zip(pages, texts))
    elif ch == "tesseract-cli":
        import tempfile
        tmp = tempfile.mkdtemp(prefix="ods-ocr-")
        paths = render(doc, pages, tmp, a.dpi)
        for p, i in zip(paths, pages):
            try:
                r = subprocess.run(["tesseract", p, "stdout", "-l", "chi_sim+eng"],
                                   capture_output=True, timeout=300)
                texts.append(r.stdout.decode("utf-8", "replace"))
            except Exception as e:
                texts.append(f"[OCR 失败：{e}]")
        body = "\n\n".join(f"--- 第 {i+1} 页 ---\n{t}" for i, t in zip(pages, texts))
    else:
        # 通道 A：渲染 + 给 AI 看的引导（这才是"零依赖"的可用路径）
        paths = render(doc, pages, a.out and os.path.splitext(a.out)[0] + "_pages" or "ocr_pages", a.dpi)
        doc.close()
        print(_tag("ODS-E06", "本机没有 OCR 程序，改走「渲染图片 → 交给能看图的模型」这条路"))
        print(f"   已导出 {len(paths)} 张页面图片：")
        for p in paths:
            print(f"     {p}")
        print("\n   请把这些图片交给带视觉能力的模型，让它逐页读出文字（表格也能读），")
        print("   再把文字贴回来，我继续做敏感信息扫描 / 打码 / 提取。")
        print("   想本机直接 OCR：装 tesseract-ocr（含 chi_sim 中文包）+ pip install pytesseract。")
        return 0
    doc.close()
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(body)
        print(f"✅ OCR 完成（{len(pages)} 页）→ {a.out}")
    else:
        print(body)
    return 0


def io_bytes(pix):
    """pixmap → BytesIO（给 PIL 用）"""
    import io
    return io.BytesIO(pix.tobytes("png"))


def main(argv=None):
    p = argparse.ArgumentParser(description="扫描件处理：渲染成图片交给 AI 视觉，或本机 OCR")
    sub = p.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check"); c.set_defaults(fn=cmd_check)
    r = sub.add_parser("render"); r.add_argument("file"); r.add_argument("-o", dest="out", default="")
    r.add_argument("-pages", default=""); r.add_argument("-dpi", type=int, default=200)
    r.set_defaults(fn=cmd_render)
    rd = sub.add_parser("read"); rd.add_argument("file"); rd.add_argument("-o", dest="out", default="")
    rd.add_argument("-pages", default=""); rd.add_argument("-dpi", type=int, default=200)
    rd.set_defaults(fn=cmd_read)
    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
