#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Excel 增强工具（openpyxl）—— 对标竞品 excel-xlsx 的核心能力补齐

补齐的能力（v1.6.0 新增）：
  sort        数据排序（多列、可指定列类型、文本数字混合安全）
  filter      条件筛选（>= <= == != 包含，AND 组合）
  formula     写「活公式」而不是死值（{列名} 占位，引用而非硬编码）
  chart       图表生成（柱/折线/饼，自动推荐图表类型）
  health      公式体检：#REF!/#NAME?/#DIV/0! 等残留、缓存值失效、硬编码数字、ID 精度风险
  protect     数据类型保护（长编号/前导零强制存文本）

用法:
  python xlsx_pro.py sort 数据.xlsx -o 排序.xlsx -col 销售额 -desc
  python xlsx_pro.py filter 数据.xlsx -o 筛选.xlsx -col 销售额 -op ge -value 10000
  python xlsx_pro.py formula 数据.xlsx -o 活公式.xlsx -col 达成率 -tpl "=ROUND({销售额}/{目标}*100,1)"
  python xlsx_pro.py chart 数据.xlsx -o 图.xlsx -x 部门 -y 销售额 -kind bar
  python xlsx_pro.py health 数据.xlsx
  python xlsx_pro.py protect 数据.xlsx -o 保护.xlsx -cols 身份证,手机号
"""
import argparse
import os
import re
import sys

from xlsx_tool import save_workbook

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

def _ensure_parent(path):
    """-o 指向不存在的目录时自动创建（2026-10-09：曾直接抛 FileNotFoundError 英文堆栈）。"""
    import os as _os
    d = _os.path.dirname(_os.path.abspath(path))
    if d and not _os.path.isdir(d):
        _os.makedirs(d, exist_ok=True)
        print(f"ℹ️ 输出目录不存在，已创建: {d}")


# Excel 里必须当文本存的列名关键字（对标竞品第 4 条：数据类型保护）
ID_HINTS = ("身份证", "证件", "身份证号", "手机", "电话", "邮编", "邮编", "银行卡", "卡号",
            "订单号", "编号", "工号", "账号", "车牌", "sku", "SKU", "编码", "序列号")


def die(msg, hint=None, code=None):
    """失败出口。带 code 时带错误编号（见 scripts/error_codes.py），便于按编号排错。"""
    print(f"❌ 错误 {_tag(code, msg) if code else ': ' + msg}")
    if hint:
        print(f"   处理: {hint}")
    sys.exit(1)


def load(path, sheet=None, data_only=False):
    from openpyxl import load_workbook
    if not os.path.exists(path):
        die(f"文件不存在 → {path}", f"请检查路径（当前目录: {os.getcwd()}）；Windows 路径请用双引号包住", code="ODS-E01")
    if os.path.isdir(path):
        # 不把 Python 的英文 errno 甩给用户（2026-10-09 真机测得：传目录时报英文报错）
        die(f"这是一个目录，不是 Excel 文件 → {path}", "请传具体的 .xlsx 文件；要批量处理用 checkup_report.py 扫目录", code="ODS-E01")
    try:
        wb = load_workbook(path, data_only=data_only)
    except Exception as e:
        die(f"无法打开 Excel 文件: {e}",
            "可能是文件损坏、非 .xlsx（旧版 .xls 请先转），或文件正被 Excel/WPS 占用（先关闭）", code="ODS-E02")
    if sheet and sheet not in wb.sheetnames:
        die(f"找不到工作表 '{sheet}'", f"可用: {wb.sheetnames}", code="ODS-E04")
    ws = wb[sheet] if sheet else wb.active
    return wb, ws


def _norm(v):
    """表头名归一化（两侧都归一化：表头数字 1.0 ↔ 命令行 '1.0'）。

    踩坑记录（2026-10-09，真实文件复现）：pandas 官方语料 `ints_spelled_with_decimals.xlsx`
    的表头单元格原始值是 float 1.0，命令行传进来的是字符串 "1.0"，
    不归一化就会打印出「错误: 找不到列 '1.0'，可用列: [1.0]」这种自相矛盾的提示。
    """
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        f = float(v)
        return str(int(f)) if f.is_integer() else str(f)
    s = str(v).strip()
    try:
        f = float(s)
        if f.is_integer():
            return str(int(f))
    except ValueError:
        pass
    return s


def _find_col(hidx, name):
    """按归一化名字查列号；找不到返回 None。"""
    k = _norm(name)
    return k if k in hidx else None


def merged_rows(ws):
    """落在合并区内的行号集合。

    这些行不是普通数据行：合并区的非左上角单元格是 MergedCell，
    对其赋值会抛 `AttributeError: 'MergedCell' object attribute 'value' is read-only`
    （踩坑记录 2026-10-09：真实报表 pandas `multiindex_no_index_names.xlsx` 直接崩）。
    """
    out = set()
    for rng in ws.merged_cells.ranges:
        for r in range(rng.min_row, rng.max_row + 1):
            out.add(r)
    return out


def _is_title_row(ws, r):
    """该行是不是「合并的大标题」行。

    要同时满足两条，缺一不可（2026-10-09 两轮真实文件测试修正）：
      ① 落在跨 ≥2 列的合并区里；
      ② 这一行**只有一个**非空值（就是标题文字）。
    为什么不能只看「在合并区里」：真实文件的**多级表头**也常合并（pandas 语料
    multiindex_no_index_names 第 1 行有 'X'、'XX' 两个值且带合并），只看合并会把
    真表头当标题跳掉，反而报「找不到列」。
    为什么不能只看「非空单元格 ≥2」：单列标题（dimension_large.xlsx 第 1 行只有 'Title'）
    会被误跳，把数据行当表头。
    """
    vals = [c.value for c in ws[r] if c.value is not None]
    if len(vals) != 1:
        return False
    for rng in ws.merged_cells.ranges:
        if rng.min_row <= r <= rng.max_row and (rng.max_col - rng.min_col) >= 1:
            return True
    return False


def header_row(ws):
    """探测表头行：跳过跨列合并的大标题行与空行，取第一个有内容且不是标题行的行。"""
    for r in range(1, min(ws.max_row, 20) + 1):
        if not [c.value for c in ws[r] if c.value is not None]:
            continue
        if _is_title_row(ws, r):
            continue
        return r
    return 1


def header_index(ws, hrow=None):
    r = hrow or header_row(ws)
    return {_norm(c.value): c.column for c in ws[r] if c.value is not None}


def data_rows(ws, hrow=None):
    """返回 (表头行号, 数据行号列表)：数据行 = 表头之后且不在合并区内的行。"""
    hr = hrow or header_row(ws)
    m = merged_rows(ws)
    return hr, [r for r in range(hr + 1, ws.max_row + 1) if r not in m]



def _sort_key_factory(ws, idx, cached=None):
    """Excel 排序语义：数字按数值排，纯文本按文本排，空值永远最后。

    踩坑记录（2026-10-03，WorkBuddy 真机自检抓出）：被排序列里如果是**公式**，
    早期版本直接拿公式字符串排序，于是 "=ROUND(...)" 被按文本字典序排，
    结果与用户直觉完全无关（看起来"排序没生效"）。
    现在：公式单元格改用缓存值（data_only 读出来的上次计算结果）排；
    没有缓存值（文件从没被 Excel 算过）就当空值排最后，并给出明确提示。
    """
    def key(v):
        cell_v = ws.cell(row=v, column=idx).value
        if isinstance(cell_v, str) and cell_v.startswith("=") and cached is not None:
            cell_v = cached.get((v, idx))
        if cell_v is None or cell_v == "":
            return (2, 0, "")
        if isinstance(cell_v, bool):
            return (1, int(cell_v), "")
        if isinstance(cell_v, (int, float)):
            return (0, float(cell_v), "")
        return (1, 0, str(cell_v))
    return key


def _cached_values(path, sheet=None):
    """读一份 data_only 副本，拿到公式的「上次计算结果」（可能全是 None）"""
    from openpyxl import load_workbook
    try:
        wb = load_workbook(path, data_only=True)
    except Exception:
        return {}
    ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
    out = {}
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None:
                out[(c.row, c.column)] = c.value
    return out


def _rebase_formula(formula, src_coord, dst_coord):
    """整行搬动后，把公式里的相对引用重定位到新行。

    踩坑记录（2026-10-03，WorkBuddy 真机跑出来才发现）：早期版本只是把公式字符串
    原样搬到新行，于是第 3 行可能留着 `=ROUND(H9/I9*100,1)`——指向了别人的数据，
    数值静默错乱。用 openpyxl 的 Translator 按「从旧坐标搬到新坐标」平移引用，
    绝对引用（含 $）保持不变。
    注意：Translator 输出的前缀可能多一个 '='，这里统一规整成单个 '='。
    """
    if not (isinstance(formula, str) and formula.startswith("=")):
        return formula
    try:
        from openpyxl.formula.translate import Translator
        out = Translator(formula, origin=src_coord).translate_formula(dst_coord)
        return out if out.startswith("=") else "=" + out
    except Exception:
        return formula


def cmd_sort(args):
    from openpyxl import load_workbook
    from openpyxl.cell.cell import MergedCell
    from openpyxl.utils import get_column_letter
    wb, ws = load(args.file, args.sheet)
    hrow = header_row(ws)
    hidx = header_index(ws, hrow)
    key = _find_col(hidx, args.col)
    if key is None:
        die(f"表里没有叫「{args.col}」的列", f"可以改用这些列名：{'、'.join(str(h) for h in hidx)}", code="ODS-E03")
    if hrow != 1:
        print(f"ℹ️ 表头在第 {hrow} 行（第 1 行是标题或空行，已自动跳过）")
    hrow, rows = data_rows(ws, hrow)
    # 含合并单元格的行不参与排序，否则写回时会对 MergedCell 赋值而崩溃（2026-10-09 修）
    skipped = [r for r in range(hrow + 1, ws.max_row + 1) if r not in set(rows)]
    if skipped:
        print(f"ℹ️ 跳过 {len(skipped)} 个含合并单元格的行（行号 {skipped[:6]}"
              f"{' …' if len(skipped) > 6 else ''}）：合并区单元格不能搬动，保持原位")
    col = hidx[key]
    # 被排序列里有公式时，改用缓存值排，并在拿不到缓存值时明确告知
    formula_rows = [r for r in rows
                    if isinstance(ws.cell(row=r, column=col).value, str)
                    and str(ws.cell(row=r, column=col).value).startswith("=")]
    cached = _cached_values(args.file, args.sheet) if formula_rows else None
    if formula_rows:
        miss = [r for r in formula_rows if (r, col) not in (cached or {})]
        print(f"ℹ️ 排序列「{args.col}」有 {len(formula_rows)} 个公式，"
              f"按其**上次计算结果**排序"
              + (f"；其中 {len(miss)} 个没有缓存值（文件没被 Excel 算过），将排到最后"
                 if miss else ""))
        if len(miss) == len(formula_rows):
            print("   建议：先用 Excel/WPS 打开并保存一次，让公式出值，再排序；"
                  "或改按有真实数值的列排序")
    # 空值必须永远排在最后——包括降序。
    # 踩坑记录（2026-10-09）：`sort(key=..., reverse=True)` 会把"空值的高权重"一起反转，
    # 于是降序时空值跑到第一行（注释承诺的是"空值永远最后"）。现在先分离空值再排。
    keyf = _sort_key_factory(ws, col, cached)
    empties = [r for r in rows if keyf(r)[0] == 2]
    filled = [r for r in rows if keyf(r)[0] != 2]
    filled.sort(key=keyf, reverse=args.desc)
    rows = filled + empties
    ncol = ws.max_column
    moved_formulas = 0
    # 先取快照（按目标行号读旧值），再整体重写，避免边读边写把数据搅乱
    snapshot = {r: [ws.cell(row=r, column=c).value for c in range(1, ncol + 1)] for r in rows}
    for dst_i, src_r in zip(sorted(rows), rows):
        for j, v in enumerate(snapshot[src_r], start=1):
            cell = ws.cell(row=dst_i, column=j)
            if isinstance(cell, MergedCell):
                continue  # 合并区非左上角单元格只读，跳过（2026-10-09 修）
            new_v = v
            if isinstance(v, str) and v.startswith("="):
                # 源坐标（这行公式原来在哪）→ 目标坐标（现在搬到哪）
                src_coord = f"{get_column_letter(j)}{src_r}"
                new_v = _rebase_formula(v, src_coord, cell.coordinate)
                if new_v != v:
                    moved_formulas += 1
            cell.value = new_v
    save_workbook(wb, args.out)
    print(f"✅ 排序完成 → {args.out}")
    print(f"   列: {args.col} | 方向: {'降序' if args.desc else '升序'} | 数据 {len(rows)} 行")
    if moved_formulas:
        print(f"   已同步平移 {moved_formulas} 个公式的相对引用（行位置变了，引用跟着走）")
    print("   注意：排序结果是新文件，单元格颜色/字体/图片这类格式不会带过来（同类工具都是这样）")


OPS = {
    "eq": lambda a, b: _str(a) == _str(b),
    "ne": lambda a, b: _str(a) != _str(b),
    "gt": lambda a, b: _num(a) > _num(b),
    "ge": lambda a, b: _num(a) >= _num(b),
    "lt": lambda a, b: _num(a) < _num(b),
    "le": lambda a, b: _num(a) <= _num(b),
    "contains": lambda a, b: _str(b) in _str(a),
}


def _str(v):
    return "" if v is None else str(v).strip()


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("-inf")


def cmd_filter(args):
    wb, ws = load(args.file, args.sheet)
    hrow = header_row(ws)
    hidx = header_index(ws, hrow)
    key = _find_col(hidx, args.col)
    if key is None:
        die(f"表里没有叫「{args.col}」的列", f"可以改用这些列名：{'、'.join(str(h) for h in hidx)}", code="ODS-E03")
    idx = hidx[key]
    op = OPS[args.op]
    hrow, drows = data_rows(ws, hrow)
    # 公式列的筛选：公式本身是文本，拿它比大小必然「一条都不匹配」。
    # 这时要改用缓存值（data_only 的上次计算结果），并在没有缓存值时把原因说清楚，
    # 而不是只丢一句「没有任何行满足条件」让人以为是数据问题。
    # 踩坑记录（2026-10-03，WorkBuddy 真机自检抓出）。
    cached = _cached_values(args.file, args.sheet)
    formula_rows = [r for r in drows
                    if isinstance(ws.cell(row=r, column=idx).value, str)
                    and str(ws.cell(row=r, column=idx).value).startswith("=")]
    formula_no_cache = [r for r in formula_rows if (r, idx) not in cached]
    if formula_rows:
        print(f"ℹ️ 条件列「{args.col}」有 {len(formula_rows)} 个公式，改用其**上次计算结果**比较")
        if formula_no_cache:
            print(f"   其中 {len(formula_no_cache)} 个没有缓存值（文件没被 Excel 算过），"
                  "这些行按不匹配处理")
    header = [ws.cell(row=hrow, column=c).value for c in range(1, ws.max_column + 1)]
    keep, source_rows, dropped = [], [], 0
    for r in drows:
        raw = ws.cell(row=r, column=idx).value
        val = cached.get((r, idx)) if (isinstance(raw, str) and raw.startswith("=")) else raw
        if val is None and isinstance(raw, str) and raw.startswith("="):
            val = raw  # 没缓存值就退回公式文本，至少 eq/contains 还能用
        if op(val, args.value):
            keep.append([ws.cell(row=r, column=c).value for c in range(1, ws.max_column + 1)])
            source_rows.append(r)
        else:
            dropped += 1
    if not keep:
        hint = f"当前条件: {args.col} {args.op} {args.value}（原文件未改动）"
        if formula_no_cache and formula_no_cache == drows:
            hint = (f"条件列「{args.col}」全是**从未计算过的公式**（这类公式要用 Excel/WPS 打开一次才会出结果）。"
                    "先用 Excel/WPS 打开该文件并保存一次，让公式出值，再筛选；"
                    "或改按有真实数值的列筛选")
        die("没有任何行满足条件", hint)
    # The filtered output is a compact table; old merged ranges no longer apply.
    for merged in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(merged))
    ws.delete_rows(1, ws.max_row)
    # 表头必须一起写回，否则产物只剩数据、没有列名
    for j, v in enumerate(header, start=1):
        ws.cell(row=1, column=j, value=v)
    from openpyxl.utils import get_column_letter
    for i, (source_row, row) in enumerate(zip(source_rows, keep), start=2):
        for j, v in enumerate(row, start=1):
            cell = ws.cell(row=i, column=j)
            cell.value = _rebase_formula(v, f"{get_column_letter(j)}{source_row}", cell.coordinate)
    save_workbook(wb, args.out)
    print(f"✅ 筛选完成 → {args.out}")
    print(f"   条件: {args.col} {args.op} {args.value} | 命中 {len(keep)} 行 / 剔除 {dropped} 行")
    print("   注意：筛选结果是新文件，原表不会动；条件格式、筛选按钮这类设置不会带过去（同类工具都是这样）")


def cmd_formula(args):
    from openpyxl.utils import get_column_letter
    wb, ws = load(args.file, args.sheet)
    hrow = header_row(ws)
    hidx = header_index(ws, hrow)
    if _find_col(hidx, args.col) is not None:
        die(f"目标列 '{args.col}' 已存在，覆盖会破坏原公式", "请换一个还没用过的列名作为新公式列", code="ODS-E03")
    missing = [c for c in args.refs if _find_col(hidx, c) is None]
    if missing:
        die(f"模板要用到的这些列，这张表里没有：{'、'.join(str(m) for m in missing)}",
            f"可以改用这些列名：{'、'.join(str(h) for h in hidx)}", code="ODS-E03")
    tpl = args.tpl if args.tpl.startswith("=") else "=" + args.tpl
    # 新列固定写在最右侧（目标列名已存在时上面已报错，不会覆盖）
    col_idx = ws.max_column + 1
    from copy import copy as _copy
    ws.cell(row=hrow, column=col_idx, value=args.col).font = _copy(ws.cell(row=hrow, column=1).font)
    _, drows = data_rows(ws, hrow)
    n = 0
    for r in drows:
        if not all(ws.cell(row=r, column=hidx[_find_col(hidx, c)]).value is not None for c in args.refs):
            continue
        formula = tpl
        for c in args.refs:
            col = hidx[_find_col(hidx, c)]
            letter = get_column_letter(col)
            formula = formula.replace("{" + c + "}", f"{letter}{r}")
        ws.cell(row=r, column=col_idx, value=formula)
        n += 1
    save_workbook(wb, args.out)
    print(f"✅ 已写入 {n} 条活公式 → {args.out}（列: {args.col}）")
    print(f"   模板: {tpl}")
    print("   ⚠️ 程序只写公式、不计算结果：用 Excel/WPS 打开后公式才会显示数字；"
          "本工具 health 命令可检查缓存值是否过期")


def _best_kind(series):
    """按数据特征推荐图表类型（对标竞品 chart_recommender）

    修正记录（2026-10-03，WorkBuddy 真机实测后改）：早期版本只看「行数 ≤6 就用饼图」，
    于是 17 行明细被推荐成柱状图、而 5 个汇总点也可能被判成柱状图——与文档描述对不上。
    现在按「分类数 + 数据点数」一起判断：
      · 分类 ≤6 且总点数 ≤8（真正的汇总表）→ 饼图
      · 数据点 > 30（明细/时序）→ 折线
      · 其余 → 柱状图
    """
    n = len(series)
    cats = set(series)
    if n <= 8 and len(cats) <= 6:
        return "pie", f"汇总表（{n} 个数据点 / {len(cats)} 个分类），饼图看占比更直观"
    if n > 30:
        return "line", f"明细数据点较多（{n} 行），折线避免柱体拥挤"
    return "bar", f"{n} 行 / {len(cats)} 个分类，柱状图便于横向比较"


def cmd_chart(args):
    from openpyxl.chart import BarChart, LineChart, PieChart, Reference
    wb, ws = load(args.file, args.sheet)
    hrow = header_row(ws)
    hidx = header_index(ws, hrow)
    xk, yk = _find_col(hidx, args.x), _find_col(hidx, args.y)
    for name, k in ((args.x, xk), (args.y, yk)):
        if k is None:
            die(f"表里没有叫「{name}」的列", f"可以改用这些列名：{'、'.join(str(h) for h in hidx)}", code="ODS-E03")
    kind = args.kind
    note = "（按 -kind 指定）"
    if kind == "auto":
        kind, note = _best_kind([ws.cell(row=r, column=hidx[xk]).value for r in range(hrow + 1, ws.max_row + 1)])
    cls = {"bar": BarChart, "line": LineChart, "pie": PieChart}.get(kind)
    if cls is None:
        die("不支持的图表类型", "可选: bar / line / pie / auto")
    ch = cls()
    if kind != "pie":
        ch.title = f"{args.y} 分布"
        data = Reference(ws, min_col=hidx[yk], min_row=hrow, max_row=ws.max_row)
        cats = Reference(ws, min_col=hidx[xk], min_row=hrow + 1, max_row=ws.max_row)
        ch.add_data(data, titles_from_data=True)
        ch.set_categories(cats)
        ch.height, ch.width = 8, 16
    else:
        ch.title = f"{args.y} 占比"
        data = Reference(ws, min_col=hidx[yk], min_row=hrow + 1, max_row=ws.max_row)
        labels = Reference(ws, min_col=hidx[xk], min_row=hrow + 1, max_row=ws.max_row)
        ch.add_data(data, titles_from_data=False)
        ch.set_categories(labels)
        ch.height, ch.width = 9, 14
    ws.add_chart(ch, f"{chr(65 + min(ws.max_column, 20))}{ws.max_row + 3}")
    save_workbook(wb, args.out)
    print(f"✅ 图表已嵌入 → {args.out}")
    print(f"   类型: {kind}{note} | X={args.x} Y={args.y}")


def cmd_health(args):
    """将本地结构化输入交给付费云端体检流程。"""
    if os.path.isdir(args.file):
        print(f"错误 [ODS-E13] health 只接受单个 .xlsx 文件，不接受目录：{args.file}", file=sys.stderr)
        return 1
    if os.path.splitext(args.file)[1].lower() != ".xlsx":
        print(f"错误 [ODS-E13] health 只接受 .xlsx 文件：{args.file}", file=sys.stderr)
        return 1
    from paid_audit import run_paid_audit
    return run_paid_audit([args.file], sheet=args.sheet)


def cmd_protect(args):
    """把编号类列强制成文本，避免 Excel 把 0012 变成 12、把长号截断"""
    wb, ws = load(args.file, args.sheet)
    hrow = header_row(ws)
    hidx = header_index(ws, hrow)
    targets = [c.strip() for c in args.cols.split(",") if c.strip()] if args.cols else \
        [n for n in hidx if any(h in n for h in ID_HINTS)]
    fixed, cells = [], 0
    for name in targets:
        k = _find_col(hidx, name)
        if k is None:
            print(f"⚠️ 跳过不存在的列: {name}")
            continue
        col = hidx[k]
        ws.cell(row=hrow, column=col).number_format = "@"
        for r in range(hrow + 1, ws.max_row + 1):
            c = ws.cell(row=r, column=col)
            if c.value is None:
                continue
            # 公式单元格绝不能转文本——自检实测过：会把 =ROUND(...) 变成字符串，公式直接失效
            if isinstance(c.value, str) and c.value.startswith("="):
                continue
            s = str(int(c.value)) if isinstance(c.value, float) and c.value.is_integer() else str(c.value)
            c.value = s
            c.number_format = "@"
            cells += 1
        fixed.append(name)
    save_workbook(wb, args.out)
    print(f"✅ 数据类型保护完成 → {args.out}")
    print(f"   已转文本的列: {fixed or '（无匹配列）'} | 共 {cells} 个单元格")
    print("   ⚠️ 已被 Excel 截断的超过 15 位的数字无法还原，需要回到源数据重新导入")


def main():
    p = argparse.ArgumentParser(description="Excel 增强工具（排序/筛选/公式/图表/体检/类型保护）")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sort"); s.add_argument("file"); s.add_argument("-o", dest="out", required=True)
    s.add_argument("-col", required=True); s.add_argument("-desc", action="store_true"); s.add_argument("-sheet", default="")
    f = sub.add_parser("filter"); f.add_argument("file"); f.add_argument("-o", dest="out", required=True)
    f.add_argument("-col", required=True); f.add_argument("-op", default="ge",
                choices=list(OPS), help="eq/ne/gt/ge/lt/le/contains"); f.add_argument("-value", required=True); f.add_argument("-sheet", default="")
    fm = sub.add_parser("formula"); fm.add_argument("file"); fm.add_argument("-o", dest="out", required=True)
    fm.add_argument("-col", required=True, help="新公式列的列名"); fm.add_argument("-tpl", required=True,
                help='公式模板，{列名} 会被替换成单元格引用，例 "=ROUND({销售额}/{目标}*100,1)"')
    fm.add_argument("-refs", default="", help="模板引用了哪些列，逗号分隔"); fm.add_argument("-sheet", default="")
    c = sub.add_parser("chart"); c.add_argument("file"); c.add_argument("-o", dest="out", required=True)
    c.add_argument("-x", required=True); c.add_argument("-y", required=True)
    c.add_argument("-kind", default="auto", choices=["auto", "bar", "line", "pie"]); c.add_argument("-sheet", default="")
    h = sub.add_parser("health"); h.add_argument("file"); h.add_argument("-sheet", default="")
    pr = sub.add_parser("protect"); pr.add_argument("file"); pr.add_argument("-o", dest="out", required=True)
    pr.add_argument("-cols", default=""); pr.add_argument("-sheet", default="")
    args = p.parse_args()
    for _k in ("out", "o"):
        _p = getattr(args, _k, None)
        if _p:
            _ensure_parent(_p)
    try:
        if args.cmd == "sort":
            cmd_sort(args)
        elif args.cmd == "filter":
            cmd_filter(args)
        elif args.cmd == "formula":
            args.refs = [x.strip() for x in args.refs.split(",") if x.strip()] or \
                re.findall(r"\{(.+?)\}", args.tpl, flags=re.DOTALL)
            if not args.refs:
                die("没识别出公式引用的列", '用 -refs 显式指定，或在 -tpl 里用 {列名} 占位，例 "=ROUND({销售额}/{目标}*100,1)"')
            cmd_formula(args)
        elif args.cmd == "chart":
            cmd_chart(args)
        elif args.cmd == "health":
            return cmd_health(args)
        elif args.cmd == "protect":
            cmd_protect(args)
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    sys.exit(main())
