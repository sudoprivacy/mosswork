"""Extract local Office/PDF inputs into a small JSON-ready payload."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable


SUPPORTED = {".xlsx", ".pdf", ".docx"}
MAX_FILES = 10
MAX_ROWS = 200


def _cell_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def _xlsx(path: Path, sheet: str = "") -> dict[str, Any]:
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter

    try:
        wb_formula = load_workbook(path, data_only=False, read_only=True)
        wb_cached = load_workbook(path, data_only=True, read_only=True)
        if sheet:
            if sheet not in wb_formula.sheetnames:
                raise ValueError(f"工作表不存在: {sheet}")
            ws, cached_ws = wb_formula[sheet], wb_cached[sheet]
        else:
            ws, cached_ws = wb_formula.active, wb_cached[wb_formula.active.title]
        # Third-party exporters may omit dimensions or incorrectly declare A1.
        # Discover real bounds instead of trusting metadata that can truncate data.
        for selected_ws in (ws, cached_ws):
            selected_ws.reset_dimensions()
            selected_ws.calculate_dimension(force=True)
        sample_rows = [
            [_cell_value(value) for value in row]
            for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, MAX_ROWS), values_only=True)
        ]
        if not any(value is not None and (not isinstance(value, str) or value.strip()) for row in sample_rows for value in row):
            raise ValueError(f"Excel 文件 {path.name} 为空或没有可提取内容")
        headers: list[dict[str, Any]] = []
        if sample_rows:
            for index, name in enumerate(sample_rows[0], start=1):
                headers.append({
                    "name": str(name) if name is not None else "",
                    "column": get_column_letter(index),
                    "sample": [row[index - 1] for row in sample_rows[1:] if index - 1 < len(row) and row[index - 1] is not None][:200],
                })
        formulas: list[dict[str, Any]] = []
        for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, MAX_ROWS)):
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formulas.append({
                        "cell": cell.coordinate,
                        "formula": cell.value,
                        "cached": _cell_value(cached_ws[cell.coordinate].value),
                    })
        return {
            "kind": "xlsx",
            "sheet": ws.title,
            "rows": ws.max_row,
            "sampled_rows": min(ws.max_row, MAX_ROWS),
            "formulas": formulas,
            "headers": headers,
        }
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError(f"无法读取 Excel 文件 {path.name}: {exc}") from None
    finally:
        for book_name in ("wb_formula", "wb_cached"):
            book = locals().get(book_name)
            if book is not None:
                book.close()


def _pdf(path: Path) -> dict[str, Any]:
    import pymupdf

    try:
        with pymupdf.open(path) as document:
            text = "\n".join(page.get_text() for page in document).strip()
    except Exception as exc:
        raise ValueError(f"无法读取 PDF 文件 {path.name}: {exc}") from None
    if not text:
        raise ValueError(f"PDF 文件 {path.name} 没有可提取文字层，请先进行 OCR")
    return {"kind": "text", "text": text}


def _docx(path: Path) -> dict[str, Any]:
    from docx import Document

    try:
        document = Document(path)
        text = "\n".join(p.text for p in document.paragraphs if p.text).strip()
        headings = sum(1 for p in document.paragraphs if p.style and p.style.name.startswith("Heading "))
        # Include table text so extraction does not silently omit document content.
        from docx.table import _Cell
        table_text = ["\t".join(_Cell(tc, table).text for tc in tr.tc_lst)
                      for table in document.tables for tr in table._tbl.tr_lst]
        if table_text:
            text = "\n".join(part for part in (text, "\n".join(table_text)) if part)
    except Exception as exc:
        raise ValueError(f"无法读取 DOCX 文件 {path.name}: {exc}") from None
    if not text:
        raise ValueError(f"DOCX 文件 {path.name} 为空或没有可提取文字")
    return {"kind": "docx", "text": text, "heading_count": headings}


def _extract(path: Path, sheet: str = "") -> dict[str, Any]:
    suffix = path.suffix.lower()
    if suffix == ".xlsx":
        return _xlsx(path, sheet)
    if suffix == ".pdf":
        return _pdf(path)
    if suffix == ".docx":
        return _docx(path)
    raise ValueError(f"不支持的文件类型: {path.name}")


def _collect(paths: Iterable[str | Path]) -> list[Path]:
    collected: list[Path] = []
    for item in paths:
        path = Path(item).expanduser()
        if not path.exists():
            raise ValueError(f"路径不存在: {path}")
        if path.is_dir():
            files = sorted((p for p in path.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED), key=lambda p: str(p).casefold())
            if not files:
                raise ValueError(f"目录中没有受支持的文件: {path}")
            collected.extend(files)
        elif path.is_file() and path.suffix.lower() in SUPPORTED:
            collected.append(path)
        else:
            raise ValueError(f"不支持的文件类型: {path.name}")
    # Keep the order supplied by the caller while avoiding duplicate paths.
    unique: list[Path] = []
    seen: set[str] = set()
    for path in collected:
        key = str(path.resolve()).casefold()
        if key not in seen:
            unique.append(path)
            seen.add(key)
    if not unique:
        raise ValueError("没有找到受支持的输入文件")
    if len(unique) > MAX_FILES:
        raise ValueError(f"受支持文件最多 {MAX_FILES} 个，当前为 {len(unique)} 个")
    return unique


def build_payload(paths: str | Path | Iterable[str | Path], sheet: str = "") -> dict[str, Any]:
    """Extract one file or a batch. Any missing, empty, or invalid input fails the call."""
    if isinstance(paths, (str, Path)):
        inputs = [paths]
    else:
        inputs = list(paths)
    files = _collect(inputs)
    payloads = [_extract(path, sheet if path.suffix.lower() == ".xlsx" else "") for path in files]
    if len(payloads) == 1:
        return payloads[0]
    return {
        "kind": "batch",
        "documents": [
            {"label": path.name, **payload}
            for path, payload in zip(files, payloads)
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="提取本地 Office/PDF 文件内容")
    parser.add_argument("paths", nargs="+", help="文件或目录路径")
    parser.add_argument("-o", "--output", required=True, help="摘要 JSON 输出路径")
    parser.add_argument("-sheet", default="", help="Excel 工作表名称")
    args = parser.parse_args(argv)
    try:
        payload = build_payload(args.paths, sheet=args.sheet)
        output = Path(args.output).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        count = len(payload["documents"]) if payload["kind"] == "batch" else 1
        print(f"已提取 {count} 个文件；摘要路径：{output}")
        return 0
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
