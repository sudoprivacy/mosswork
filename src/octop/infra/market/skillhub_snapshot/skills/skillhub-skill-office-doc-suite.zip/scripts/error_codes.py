#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""error_codes.py — 错误 ID 注册表（唯一事实来源）

为什么要有它：同一类错误散落在 9 个脚本里，用户/AI 看到的中文提示措辞各不相同，
排错时不知道"这条错误是不是已知问题、该按哪条处理"。给每类失败一个稳定编号：

  ❌ 错误 [ODS-E03]: 找不到列 '销售'，可用列: [...]

于是：用户能按编号查文档；AI 能按编号给出确定的处理动作；自检能断言"这类失败必须带这个码"。

用法:
  python scripts/error_codes.py            # 列出全部（表格）
  python scripts/error_codes.py ODS-E05    # 解释单个
  python scripts/error_codes.py --md       # 输出 Markdown 表（贴进 SKILL.md）
  python scripts/error_codes.py --codes    # 只输出编号列表（供脚本/测试校验）

约定：
  · 编号一经发布不再复用、不改含义（只增不改），这样线上报错永远查得到。
  · 脚本用 tag(code, msg) 生成带编号的提示；缺少依赖、参数错误等"用户可自行修复"的才有编号。
"""
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# code: (类别, 含义, 处理办法)
CODES = {
    "ODS-E01": ("文件", "找不到这个文件", "路径可能写错了，或者文件被挪走、改了名字。Windows 路径里有空格，记得用双引号包起来"),
    "ODS-E02": ("文件", "这个文件打不开", "先看后缀和真实格式是不是一样；关掉正在打开它的 Excel / WPS / Word 再试；老格式 .xls / .doc 先用 convert_legacy.py 转成新格式"),
    "ODS-E03": ("参数", "表里没有这一列", "照着提示里「可用列」的名字原样写；表头是数字就直接写 1.0；第一行是大标题的表，程序会自动找到真正的表头"),
    "ODS-E04": ("参数", "没有这张工作表", "照提示里给出的工作表名字写；不写就用当前打开的那一张"),
    "ODS-E05": ("PDF", "这不是 PDF，或者 PDF 坏了", "本工具只认 .pdf。是图片或文字文件的话，先用办公软件导出成 PDF；PDF 打不开也可能是加了密，先用 pdf_tool.py decrypt 解密"),
    "ODS-E06": ("PDF", "这份 PDF 没有文字层（多半是扫描件）", "扫描件里的字其实是图片，程序读不出来，也不会替你猜。要么先做 OCR，要么把页面转成图片交给能看图的 AI"),
    "ODS-E07": ("PDF", "PDF 加密了，或密码不对", "输对密码再试。密码忘了没法破解，只能找给你文件的人要"),
    "ODS-E08": ("参数", "页码或页数范围写错了", "按提示里的「文档共 N 页」改，比如 1-3,5"),
    "ODS-E09": ("依赖", "电脑上缺东西（少装了库）", "照着提示装：pip install 后面那个包名。.doc 转 .docx 需要电脑上装了 LibreOffice"),
    "ODS-E10": ("环境", "文件存不进去", "换个有写入权限的目录；也检查一下路径里有没有非法字符"),
    "ODS-E11": ("数据", "这一列全是公式，而且还没算过", "用 Excel 或 WPS 打开文件、保存一次，让公式算出结果，再回来排序 / 筛选 / 统计"),
    "ODS-E12": ("数据", "有合并单元格，搬不动", "程序已经自动跳过这些行，并告诉你行号；一定要连它们一起处理，先在 Excel 里取消合并"),
    "ODS-E13": ("数据", "按这个条件一条都没筛出来", "把条件放宽一点；条件列要是公式，先去 Excel 里算一次；再确认数字列里没混进文字"),
    "ODS-E14": ("数据", "文档没设「标题」样式，目录会是空的", "在 Word / WPS 里给章节套上「标题 1 / 2 / 3」样式，再重新生成；目录页码按 F9 更新"),
    "ODS-E15": ("付费", "还没付款，或者账单没了 / 过期了", "先跑 probe 拿一张新账单，再跑 pay；不要跳过 probe；账单过期了重新 probe 就行"),
    "ODS-E16": ("付费", "连不上商家服务器", "检查网络。如果用了代理、而且域名被解析成 198.18 开头的奇怪地址，就把这个域名加进代理的直连名单（fake-ip-filter）"),
    "ODS-E17": ("参数", "这种文件类型或参数值不支持", "照提示换成支持的类型；老格式先用 convert_legacy.py 转；命令参数用 --help 看有哪些可选"),
}


def tag(code, msg):
    """生成带错误编号的提示文本：`[ODS-E03] 找不到列 'x'`"""
    return f"[{code}] {msg}"


def get(code):
    return CODES.get(code)


def fmt(code, msg, hint=None):
    """完整的一行错误：`❌ 错误 [ODS-E03]: ...`（hint 作为第二行）"""
    out = f"❌ 错误 {tag(code, msg)}"
    if hint:
        out += f"\n   处理: {hint}"
    elif CODES.get(code):
        out += f"\n   处理: {CODES[code][2]}"
    return out


def md_table():
    rows = ["| 错误 ID | 类别 | 含义 | 处理办法 |", "|---|---|---|---|"]
    for c, (cat, mean, fix) in CODES.items():
        rows.append(f"| `{c}` | {cat} | {mean} | {fix} |")
    return "\n".join(rows)


def main(argv):
    if not argv:
        print(f"共 {len(CODES)} 个错误 ID。用法: python scripts/error_codes.py <ODS-Exx> | --md | --codes\n")
        print(md_table())
        return 0
    arg = argv[0]
    if arg == "--md":
        print(md_table())
        return 0
    if arg == "--codes":
        print("\n".join(CODES))
        return 0
    hit = CODES.get(arg.upper())
    if not hit:
        print(f"❌ 未知错误 ID: {arg}（用 --codes 查看全部）")
        return 1
    cat, mean, fix = hit
    print(f"{arg.upper()}｜类别: {cat}")
    print(f"含义: {mean}")
    print(f"处理: {fix}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
