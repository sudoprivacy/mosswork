#!/usr/bin/env node
/**
 * office-doc-suite-paid.mjs — 办公文档三件套 · 云端文档体检（支付宝按次付费编排）
 *
 * 计费点（按次，金额以服务端 402 账单为准）：把「待检文本」或「表格结构摘要」交给商家服务端体检一次。
 *   ① Excel 公式体检：公式错误残留 / 缓存值过期 / 公式内硬编码数字 / 编号列精度风险
 *   ② 文本敏感信息扫描：身份证 / 手机号 / 银行卡 / 邮箱，并给脱敏处理建议
 *   **文档文件本体不上传**，只提交摘要或文本。
 *
 * 协议：支付宝 AI 按量付费（A2M / HTTP 402），流程与官方教程一致：
 *   probe    请求资源 → 未付款预期 402 → 把 Payment-Needed 账单落盘
 *   pay      把账单与原始请求交给官方 CLI alipay-bot 拉起收银（本脚本不接触密钥）
 *   complete 用订单号查询原订单 → 服务端验付后返回内容
 *
 * ── 数据流向声明 ─────────────────────────────────────────────
 *   发送方：本机（用户设备）
 *   接收方：https://la.facailo.xyz（本 Skill 商家服务端）
 *   发送内容：本机脱敏后的文本 + 脱敏命中摘要，或字段白名单的 Excel 结构摘要
 *   发送时机：仅在 probe / complete 两次请求时
 *   不发送：文档文件本体、本机其他文件、浏览器数据、系统凭据、环境变量
 *   发送前脱敏：身份证号 / 手机号 / 银行卡号 / 邮箱替换为占位符；Excel 样例值与缓存值不发送
 *   支付凭证：由支付宝官方 alipay-bot 处理，本脚本不接触任何支付密钥
 * ──────────────────────────────────────────────────────────
 *
 * 依赖：node >= 18（内置 fetch）；支付步骤需要官方 CLI `alipay-bot`
 * 安装：npx -y @alipay/agent-payment@latest install
 */
import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { buildSafePayload } from './paid-payload.mjs';
import { requireDelivery } from './paid-delivery.mjs';

const execFileAsync = promisify(execFile);

const BACKEND_URL = process.env.SARB_BACKEND_URL || 'https://la.facailo.xyz';
const CONTENT_TYPE = 'application/json';
const RESOURCE_URL = `${BACKEND_URL}/severance-arb/api/call/office-doc-suite`;
const TIMEOUT_MS = Number(process.env.PAY_TIMEOUT_MS || 120000);
const ALIPAY_BOT = process.env.ALIPAY_BOT_BIN || 'alipay-bot';

/* ── 参数解析与请求体构造 ─────────────────────────────────────── */
function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      // 布尔开关（如 --demo / --help）后面没有值、或紧跟下一个 --flag 时，记为 true；
      // 否则取下一个参数作为值。原先一律 `= argv[++i]`，会把 `--demo --out-dir X`
      // 里的 --out-dir 当成 --demo 的值吞掉（2026-10-09 实测踩到）。
      if (next === undefined || next.startsWith('--')) out[key] = true;
      else { out[key] = next; i++; }
    } else out._.push(a);
  }
  return out;
}

/** 本脚本所在目录（用 fileURLToPath：中文路径下 import.meta.url 是百分号编码的，直接取 pathname 会算错） */
const HERE = path.dirname(fileURLToPath(import.meta.url));

const stateDir = () => path.join(os.tmpdir(), 'ods_pay_state', 'office-doc-suite');

/* ── 前置自检：商家域名是否被解析成「保留地址」────────────────────
 * 背景（2026-10-09 实测）：代理软件（如 Clash 的 TUN + fake-ip）会把域名解析成
 * 198.18.0.0/15 这类保留段地址，官方收银 CLI alipay-bot 出于 SSRF 防护会直接拒付，
 * 报 `PROXY_TARGET_BLOCKED: resolved IP x.x.x.x is in blocked range`——
 * 普通用户（不挂代理）不会遇到；挂了代理的用户则完全看不懂这句英文。
 * 这里提前解析并给中文提示 + 两种可执行解法，避免用户卡在付费这一步。
 */
const RESERVED_RE = /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|198\.1[89]\.|100\.(6[4-9]|[7-9]\d|1[0-2]\d)\.)/;
function isReserved(ip) {
  if (ip.includes(':')) return /^(::1|f[cd][0-9a-f]{2}:|fe80:)/i.test(ip);
  return RESERVED_RE.test(ip);
}
async function preflightTarget() {
  const host = new URL(RESOURCE_URL).hostname;
  try {
    const dns = await import('node:dns/promises');
    const addrs = await dns.lookup(host, { all: true });
    const reserved = addrs.filter((a) => isReserved(a.address));
    if (reserved.length && reserved.length === addrs.length) {
      console.log(`⚠️ 警告 [ODS-E16]：商家域名 ${host} 被解析成保留地址（${reserved.map((a) => a.address).join(', ')}）。`);
      console.log('   原因：电脑上的代理软件把这个网址解析成了一个「假地址」，支付宝收款工具出于安全会拒绝付款。');
      console.log('   两个办法，任选一个：');
      console.log(`   ① 在代理软件里把 ${host} 设为「直连、不走代理」（Clash 里就是加到 fake-ip-filter 且走 DIRECT）；`);
      console.log('   ② 或者临时关掉代理的「增强模式 / TUN」再重试。不挂代理的电脑不会遇到这个问题。');
      return false;
    }
  } catch {
    /* 解析失败交给后续步骤报错，这里不拦 */
  }
  return true;
}

/** 网络类失败统一带错误编号，便于用户按编号查 SKILL.md 的「错误 ID 一览」 */
function payErr(code, err) {
  const msg = err && err.message ? err.message : String(err);
  return new Error(`[${code}] ${msg}`);
}

const paths = () => {
  const d = stateDir();
  return {
    dir: d,
    bill: path.join(d, 'payment-needed.txt'),
    request: path.join(d, 'request.json'),
    resource: path.join(d, 'resource.json'),
  };
};

async function buildBody(args) {
  const kind = String(args.kind || '').toLowerCase();
  // xlsx 模式：从 --summary 指向的 JSON 文件读结构化摘要
  if (args.summary) {
    if (!existsSync(args.summary)) throw new Error(`找不到摘要文件：${args.summary}`);
    const raw = JSON.parse(await readFile(args.summary, 'utf8'));
    return buildSafePayload(raw);
  }
  if (!kind) throw new Error('缺少 --kind（text 或 xlsx）；xlsx 模式请用 --summary <json 文件>');
  if (kind !== 'text') throw new Error('xlsx 模式请用 --summary <json 文件> 提供结构化摘要');
  if (!args.text || !String(args.text).trim()) throw new Error('缺少 --text（待检文本）');
  return buildSafePayload({ kind: 'text', text: args.text });
}

/* ── probe ──────────────────────────────────────────────────── */
async function cmdProbe(args) {
  const p = paths();
  await mkdir(p.dir, { recursive: true });
  if (existsSync(p.bill) || existsSync(p.request))
    throw new Error('已有体检订单，请先完成原订单；确定放弃后执行 reset，避免覆盖订单');
  await preflightTarget();
  const body = await buildBody(args);
  let res;
  // 会话标识：供商家服务端做"真实用户 vs 自测"归因（服务端只存哈希，详见其 /stats/pay）
  const sessionId = args['session-id'] || process.env.ODS_SESSION_ID || `ods-${os.hostname()}-${process.pid}`;
  const reqHeaders = [{ 'Content-Type': CONTENT_TYPE }, { 'X-ODS-Session': sessionId }];
  try {
    res = await fetch(RESOURCE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-ODS-Session': sessionId },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (e) {
    throw payErr('ODS-E16', e);   // 连不上商家服务端（网络/代理/DNS）
  }
  const text = await res.text();

  if (res.status === 200) {
    throw new Error('未携带支付凭证却返回资源，已拒绝交付，请联系服务方检查收费配置');
  }
  if (res.status !== 402) throw payErr('ODS-E16', new Error(`资源请求返回 HTTP ${res.status}：${text.slice(0, 200)}`));

  const bill = res.headers.get('payment-needed');
  if (!bill) throw payErr('ODS-E15', new Error('HTTP 402 缺少 Payment-Needed 响应头（账单不完整）'));
  let j = null; try { j = JSON.parse(text); } catch {}
  if (j?.input_ready !== true) throw new Error('付款前输入校验未通过：' + (j?.input_errors || ['服务未确认输入有效']).join('；'));
  let protocol; try { protocol = JSON.parse(Buffer.from(bill, 'base64url').toString('utf8')).protocol; } catch {}
  if (!protocol?.out_trade_no || !Number.isFinite(Number(protocol.amount)) || Number(protocol.amount) <= 0)
    throw new Error('账单订单号或金额无效，拒绝付款');
  await writeFile(p.bill, bill, { encoding: 'utf8', mode: 0o600 });
  await writeFile(p.request, JSON.stringify({
    url: RESOURCE_URL, method: 'POST', body,
    headers: reqHeaders,
    input_ready: true,
    at: Date.now(),
  }), 'utf8');

  console.log('402 已触发，账单已落盘。');
  if (j && j.input_ready === false) {
    console.log('⚠️ 付款前校验未通过，请先补齐后重试（避免白付）：');
    for (const e of j.input_errors || []) console.log('   - ' + e);
  } else {
    console.log('入参校验通过，可继续付款。');
  }
  console.log(`金额：${j?.amount ?? '见账单'} ${j?.currency ?? 'CNY'}｜商品：${j?.goods_name ?? ''}`);
  console.log('剩余步骤：node scripts/office-doc-suite-paid.mjs pay');
  return 0;
}

/* ── 定位 alipay-bot（Windows 上是 .cmd 包装器，execFile 需 shell 或真实路径）── */
function botCandidates() {
  const names = process.platform === 'win32'
    ? ['alipay-bot.cmd', 'alipay-bot.exe', 'alipay-bot.bat']
    : ['alipay-bot'];
  const dirs = String(process.env.PATH || '').split(path.delimiter).filter(Boolean);
  const home = os.homedir();
  // 除 PATH 外再探测已知安装位置：某些宿主（如 WorkBuddy 的 agent 进程）
  // 不继承用户级 PATH，会导致明明装了却判定「未安装」。实测 2026-10-04。
  const extra = process.platform === 'win32'
    ? [
      path.join(process.env.APPDATA || '', 'npm'),
      path.join(process.env.LOCALAPPDATA || '', 'Programs'),
      path.join(home, '.openclaw-autoclaw', 'alipay-bot-cli', 'bin'),
      path.join(home, '.agents', 'bin'),
    ]
    : [path.join(home, '.local', 'bin'), '/usr/local/bin'];
  const hits = [];
  for (const d of [...dirs, ...extra]) {
    if (!d) continue;
    for (const n of names) {
      const f = path.join(d, n);
      if (existsSync(f)) hits.push(f);
    }
  }
  return hits;
}

async function runBot(args) {
  // 优先级：环境变量 ALIPAY_BOT_BIN > PATH/常见安装位置自动探测 > 裸命令名
  // 踩坑记录（2026-10-09）：原先写成 `botCandidates()[0] || ALIPAY_BOT`，导致明明设了
  // ALIPAY_BOT_BIN 却仍被 PATH 里的另一个 alipay-bot 抢走（本地演练时踩到，且与文档承诺不符）。
  const bin = process.env.ALIPAY_BOT_BIN || botCandidates()[0] || ALIPAY_BOT;
  const opts = { timeout: TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024 };
  const stringArgs = args.map(a => typeof a === 'string' ? a : JSON.stringify(a));
  if (/\.(mjs|cjs|js)$/i.test(bin)) return execFileAsync(process.execPath, [bin, ...stringArgs], opts);
  // .cmd/.bat 必须走 shell，否则 Windows 下 execFile 报 ENOENT
  if (process.platform === 'win32' && /\.(cmd|bat)$/i.test(bin)) {
    const shim = readFileSync(bin, 'utf8');
    const match = shim.match(/%dp0%[\\/]([^"\r\n]+\.(?:js|mjs|cjs))/i);
    const entry = match && path.resolve(path.dirname(bin), match[1]);
    if (!entry || !existsSync(entry)) throw new Error('无法安全解析支付 CLI 启动器，请将 ALIPAY_BOT_BIN 指向官方 exe 或 JS 入口');
    return execFileAsync(process.execPath, [entry, ...stringArgs], opts);
  }
  return execFileAsync(bin, stringArgs, opts);
}

/* ── 付款卡片：把官方 CLI 的输出整理成「一张卡」────────────────────
 * 为什么（2026-10-09 用户提问）：「用户直接用 skill，会不会直接弹出收费？」
 * 现实是：支付宝按次付费没有客户端接管（客户端只对微信支付弹卡），
 * 所以"弹"的形态只能是**聊天里出现一张清楚的付款卡**。
 * 于是这里统一输出：金额 / 订单号 / 可点链接 / 二维码图片（Markdown 图片，客户端会渲染）
 * + 三句要紧的话（不付款不扣钱、订单会失效、付完跑 complete）。
 * 原始 CLI 输出仍然照抄在后面，便于排查与对账。
 */
function renderPayCard(stdout) {
  const s = String(stdout || '');
  // 金额一律从官方 CLI 输出里解析（不写死价格，联调 0.01 时也不会显示错）
  const amount = (s.match(/支付金额[^0-9¥]{0,8}¥?\s*([0-9.]+)/) || [])[1] || '';
  const orderNo = (s.match(/订单号[^0-9]{0,8}([0-9]{8,})/) || [])[1] || '';
  const link = (s.match(/\((?:<)?(https:\/\/u\.alipay\.cn\/[^)>]+)/) || [])[1] || '';
  const qrRaw = (s.match(/!\[[^\]]*\]\((file:\/\/\/[^)]+)\)/) || [])[1] || '';
  const qr = qrRaw.replace(/\\/g, '/');   // Windows 反斜杠要转正斜杠，Markdown 才认
  return { amount, orderNo, link, qr };
}

function printPayCard(card) {
  const L = [];
  L.push('');
  L.push('┌────────────────────────────────────────────┐');
  L.push('│        支付宝 AI 付 · 待你授权付款          │');
  L.push('└────────────────────────────────────────────┘');
  L.push(`  商品：办公文档三件套 · 云端文档体检`);
  L.push(card.amount ? `  金额：¥${card.amount}` : '  金额：见下方官方输出（未解析到金额）');
  if (card.orderNo) L.push(`  订单号：${card.orderNo}`);
  if (card.link) L.push(`  支付链接：${card.link}`);
  if (card.qr) {
    L.push('  扫码付款（用支付宝扫下面这张码）：');
    L.push(`  ![支付宝收款码${card.amount ? ` ¥${card.amount}` : ''}](${card.qr})`);
    L.push(`  （二维码文件：${card.qr.replace(/^file:\/\//, '')}）`);
  } else {
    L.push('  ⚠️ 没解析到二维码图片，请用上面的支付链接付款');
  }
  L.push('  ─────────────────────────────────────────');
  L.push(`  · 现在还没扣钱：只有你在支付宝里确认授权后才会扣${card.amount ? ` ¥${card.amount}` : '款'}`);
  L.push('  · 不打算付就直接关掉，订单会自己失效，不会产生费用');
  if (card.orderNo) {
    L.push(`  · 付完把支付宝查询号发回来，我执行 complete --out-shake-no ${card.orderNo} 取回体检报告`);
  }
  L.push('');
  return L.join('\n');
}

/* ── pay ────────────────────────────────────────────────────── */
async function cmdPay(args) {
  const p = paths();
  if (!existsSync(p.bill)) throw payErr('ODS-E15', new Error('尚未 probe（缺少账单文件），请先执行 probe'));
  await preflightTarget();
  const req = JSON.parse(await readFile(p.request, 'utf8'));
  if (req.input_ready !== true || req.url !== RESOURCE_URL || req.method !== 'POST') throw new Error('订单请求无效，请重新准备输入');
  const sessionId = args['session-id'] || 'ods-session';
  // 金额一律以账单为准（不写死价格）：账单里的 amount 是多少，付款意图摘要就写多少。
  // 踩坑记录（2026-10-09）：原先这里写死「0.99 元/次」，联调 0.01 时会显示错误金额。
  const billMeta = billInfo();
  if (!billMeta.orderNo || !billMeta.amount || billMeta.expired) throw new Error('账单损坏或已过期，不能拉起付款');
  const priceText = billMeta.amount ? `${billMeta.amount} 元` : '按次';
  // 官方要求：原始请求（方法/请求体/请求头）必须完整交给买家侧 CLI，
  // 否则 CLI 复现不出同一笔订单；订单参数只走 Header，不进 body。
  // ⚠️ 2026-10-09 实测修掉的真 bug：必须把官方 CLI 的输出原样转发给上层，
  //   否则 alipay-bot 打出的「支付链接 + 二维码（file:// 图片）+ 订单号」全部被吞掉，
  //   用户/Agent 只看到「支付流程已拉起」却没有任何可付的入口 —— 等于付不了款。
  //   （实测：WorkBuddy 里跑 pay 成功后用户界面无任何支付入口；直接跑 CLI 才有链接与二维码。）
  let r;
  try {
    r = await runBot([
      '402-buyer-pay',
      '--session-id', sessionId,
      '-f', p.bill,
      '-r', req.url,
      '-m', req.method,
      '-d', typeof req.body === 'string' ? req.body : JSON.stringify(req.body),
      ...(req.headers || []).flatMap(h => Object.entries(h).flatMap(([k,v]) => ['-H', `${k}: ${v}`])),
      '--intent-summary', `办公文档三件套 · 云端文档体检（${priceText}）`,
    ]);
  } catch (e) {
    // 失败时同样要把 CLI 的原始输出交出去，否则只剩 "Command failed" 看不到原因
    if (e && e.stdout) process.stdout.write(String(e.stdout));
    if (e && e.stderr) process.stderr.write(String(e.stderr));
    throw e;
  }
  const card = renderPayCard(r.stdout);
  if (card.orderNo) {
    req.payment_query_no = card.orderNo;
    await writeFile(p.request, JSON.stringify(req, null, 2), 'utf8');
  }
  process.stdout.write(printPayCard(card));           // ① 先给用户一张清楚的付款卡
  console.log('───── 以下是官方收银 CLI 的原始输出（对账用）─────');
  process.stdout.write(r.stdout || '');               // ② 再照抄原始输出，便于排查/对账
  process.stderr.write(r.stderr || '');
  return 0;
}

/* ── 云端体检凭证：把「一次 0.99」的结果固定成可归档、可对账的文件 ──────────
 * 为什么（2026-10-09 定价调研结论）：用户付了钱，只拿到对话里一段文字——没有凭证属性，
 * 没法归档、没法对账，也就不值这个价。这里的做法是把**服务端返回原文**整体做 SHA-256 指纹，
 * 连同订单号/金额/时间/技能版本一起落成 JSON + PDF：
 *   · 一眼能核对：订单号能在支付宝账单里对上金额与时间；
 *   · 能验未篡改：原文改一个字符，指纹就对不上（校验命令写在 PDF 末尾说明里）。
 * 注意（如实说明）：目前是**客户端归档 + 服务端原文指纹与规则版本**；凭证不是服务端数字签名或法律证明。
 */
const TOOL_VERSION = '1.7.14';

function certDir(argDir) {
  return path.resolve(argDir || process.env.ODS_CERT_DIR || path.join(process.cwd(), '体检凭证'));
}

function buildCertificate({ orderNo, amount, raw, resourceId }) {
  const text = String(raw || '');
  const sha256 = createHash('sha256').update(text, 'utf8').digest('hex');
  let parsed = null;
  try {
    const s = text.indexOf('{');
    const e = text.lastIndexOf('}');
    if (s >= 0 && e > s) parsed = JSON.parse(text.slice(s, e + 1));
  } catch { /* 解析失败不影响凭证：原文与指纹照样落盘 */ }
  const content = parsed?.content || parsed?.data?.content || parsed || {};
  const collectItems = c => [
    ...(Array.isArray(c.items) ? c.items : []),
    ...(Array.isArray(c.hits) ? c.hits.map(h => ({type:h.type,level:'high',where:h.where || String(h.index ?? ''),message:h.masked,fix:'对外发送前脱敏'})) : []),
    ...(Array.isArray(c.documents) ? c.documents.flatMap(d => collectItems(d.content || d)) : []),
  ];
  const items = collectItems(content);
  const counts = {};
  for (const it of items) {
    const k = `${it.type || '其他'}（${it.level || '-'}）`;
    counts[k] = (counts[k] || 0) + 1;
  }
  return {
    schema: 'ods-cert/1',
    orderNo: orderNo || '',
    amount: amount || '',
    serviceName: '办公文档三件套 · 云端文档体检',
    resourceId: resourceId || RESOURCE_URL,
    toolVersion: TOOL_VERSION,
    completedAt: new Date().toISOString(),
    ruleVersion: content.rule_version || '',
    verdict: content.verdict || '',
    summary: {
      verdict: content.verdict || '(未解析到判定)',
      kind: content.kind || '',
      sheet: content.sheet || '',
      rows: content.rows ?? null,
      formulaCount: content.formulaCount ?? null,
      sampledRows: content.sampled_rows ?? null,
      scope: '仅针对提交内容及文字层；Excel为所选工作表前200行静态检查；不代表完整文档审计。',
      counts,
    },
    items: items.map((it) => ({ type: it.type, level: it.level, where: it.where, message: it.message, fix: it.fix })),
    serverResponseSha256: sha256,
    serverResponseBytes: Buffer.byteLength(text, 'utf8'),
    serverResponseRaw: text,
    note: '凭证由本技能在本机生成；内容取自服务端对该次请求的返回原文，指纹为原文 SHA-256。',
  };
}

function certMarkdown(cert) {
  const L = [];
  L.push(`# 云端文档体检 · 凭证`);
  L.push('');
  L.push(`- 订单号：${cert.orderNo || '(未记录)'}`);
  L.push(`- 生成时间：${cert.completedAt}`);
  L.push(`- 金额：¥${cert.amount || '(以账单为准)'}（按次）`);
  L.push(`- 技能版本：${cert.toolVersion}`);
  if (cert.ruleVersion) L.push(`- 体检规则版本：${cert.ruleVersion}`);
  L.push(`- 服务端返回原文 SHA-256：\`${cert.serverResponseSha256}\``);
  L.push('');
  L.push('## 结论');
  L.push('');
  L.push(`- 判定：**${cert.summary.verdict}**`);
  if (cert.summary.kind) L.push(`- 体检类型：${cert.summary.kind}`);
  if (cert.summary.scope) L.push(`- 范围：${cert.summary.scope}`);
  for (const [k, v] of Object.entries(cert.summary.counts)) L.push(`- ${k}：${v} 处`);
  L.push('');
  L.push('## 问题清单');
  L.push('');
  if (!cert.items.length) L.push('未发现需要处理的问题。');
  for (const [i, it] of cert.items.entries()) {
    L.push(`${i + 1}. **[${it.level || '-'}] ${it.type || ''}** ${it.where || ''}`);
    if (it.message) L.push(`   - 说明：${it.message}`);
    if (it.fix) L.push(`   - 建议：${it.fix}`);
  }
  L.push('');
  L.push('## 说明');
  L.push('');
  L.push('- 凭证与订单号一一对应，可在支付宝账单中核对金额与时间。');
  L.push('- 指纹用于校验本机保存的服务端返回原文是否被改动；凭证由本技能在本机生成，不是服务端数字签名或法律证明。');
  L.push('- 服务端原文同时保存在同名 JSON 的 `serverResponseRaw` 字段。');
  L.push('- 凭证不含用户文档本体。');
  return L.join('\n');
}

function sha256File(p) {
  return createHash('sha256').update(readFileSync(p)).digest('hex').slice(0, 16);
}

async function writeCertificate({ orderNo, amount, raw, resourceId, outDir }) {
  const cert = buildCertificate({ orderNo, amount, raw, resourceId });
  const dir = certDir(outDir);
  await mkdir(dir, { recursive: true });
  const base = `云端体检凭证-${orderNo || Date.now()}`;
  const jsonPath = path.join(dir, `${base}.json`);
  const mdPath = path.join(dir, `${base}.md`);
  await writeFile(jsonPath, JSON.stringify(cert, null, 2), 'utf8');
  await writeFile(mdPath, certMarkdown(cert), 'utf8');

  // PDF（需要 pymupdf；没有就只给 JSON/Markdown，并说明原因）
  let pdfPath = '';
  const helper = path.join(HERE, 'cert_pdf.py');
  try {
    const py = process.platform === 'win32' ? 'python' : 'python3';
    const r = await execFileAsync(py, [helper, jsonPath], { timeout: 120000, maxBuffer: 4 * 1024 * 1024 });
    pdfPath = path.join(dir, `${base}.pdf`);
    if (!existsSync(pdfPath)) { pdfPath = ''; }
    process.stdout.write(String(r.stdout || ''));
  } catch (e) {
    console.log('（没能生成 PDF：这台电脑缺少 Python 或相关组件；凭证的 JSON 与 Markdown 版已经可以用）');
  }

  console.log('\n📄 云端体检凭证已生成（可归档、可对账）：');
  console.log(`   JSON：${jsonPath}`);
  console.log(`   Markdown：${mdPath}`);
  if (pdfPath) console.log(`   PDF：${pdfPath}`);
  console.log('   核对方式：订单号可在支付宝账单核对金额与时间；');
  console.log(`   校验方式：把凭证 JSON 里「服务端返回原文」整段算一次 SHA-256，应等于 ${cert.serverResponseSha256.slice(0, 16)}…（完整值在 JSON 里；不会算也不影响使用）`);
  return { cert, jsonPath, mdPath, pdfPath };
}

/** cert --demo：不付款也先看一眼凭证长什么样（用于了解交付物） */
async function cmdCert(args) {
  if (args.from) {
    const json = JSON.parse(readFileSync(args.from, 'utf8'));
    const helper = path.join(HERE, 'cert_pdf.py');
    const py = process.platform === 'win32' ? 'python' : 'python3';
    const out = args.out || path.join(certDir(args['out-dir']), path.basename(args.from).replace(/\.json$/i, '.pdf'));
    try {
      const r = await execFileAsync(py, [helper, args.from, '-o', out], { timeout: 120000, maxBuffer: 4 * 1024 * 1024 });
      process.stdout.write(String(r.stdout || ''));
    } catch (e) {
      console.log('没能生成 PDF（这台电脑缺少 Python 或相关组件）：' + String(e.message || e).slice(0, 120));
      return 1;
    }
    return 0;
  }
  const demoRaw = JSON.stringify({
    content: {
      kind: 'xlsx', rule_version: 'ods-doc-health/1.0.0', sheet: '汇总', rows: 120, formulaCount: 34, verdict: 'warn',
      items: [
        { type: '公式错误', level: 'high', where: 'D18', message: '公式含 #REF!，交付前必须修掉', fix: '检查被引用单元格是否被删除或改名。' },
        { type: '编号精度风险', level: 'high', where: '订单号', message: '编号列被当数字存，存在精度丢失风险', fix: '导入前把该列设为文本格式。' },
        { type: '缓存值过期', level: 'medium', where: 'E5,E9', message: '2 个公式没有计算结果', fix: '用 Excel 打开并保存一次。' },
      ],
    },
  });
  const r = await writeCertificate({
    orderNo: 'DEMO-2026100900000000000000',
    amount: '0.99',
    raw: demoRaw,
    outDir: args['out-dir'],
  });
  console.log('\n（这是示例凭证：正式凭证在付款并执行 complete 后自动生成。）');
  return r && r.jsonPath ? 0 : 1;
}

/* ── complete ───────────────────────────────────────────────── */
async function cmdComplete(args) {
  const shakeNo = args['out-shake-no'];
  if (!shakeNo) throw new Error('complete 需要 --out-shake-no <支付宝查询号>');
  let p = paths();
  let currentRequest = null;
  if (existsSync(p.request)) {
    try { currentRequest = JSON.parse(await readFile(p.request, 'utf8')); } catch {}
  }
  const currentHasBill = existsSync(p.bill);
  const currentQueryNo = currentRequest?.payment_query_no || '';
  // 官方查询号与账单里的商家订单号不是同一个值。旧请求没有映射时，
  // 仍从当前账单查询；新请求按 pay 保存的 payment_query_no 选择状态。
  if (!currentHasBill || (currentQueryNo && currentQueryNo !== shakeNo)) {
    const dir = archiveDir(shakeNo);
    p = { dir, bill: path.join(dir, 'payment-needed.txt'), request: path.join(dir, 'request.json'), resource: path.join(dir, 'resource.json') };
  }
  const req = JSON.parse(await readFile(p.request, 'utf8'));
  const bill = existsSync(p.bill) ? (await readFile(p.bill, 'utf8')).trim() : '';
  // 新订单须在 probe 阶段确认输入有效；迁移前的历史 request.json 没有该字段，
  // 仍允许凭原账单查询同一订单并取回已履约结果。显式 false（及其他无效值）继续拒绝。
  if (!bill || (req.input_ready !== undefined && req.input_ready !== true)
      || req.url !== RESOURCE_URL || req.method !== 'POST')
    throw new Error('缺少有效原订单请求，不能查询或生成凭证');
  if (req.payment_query_no && req.payment_query_no !== shakeNo)
    throw new Error(`--out-shake-no (${shakeNo}) 与本地官方查询号 (${req.payment_query_no}) 不一致，拒绝查询其他订单`);
  const merchantOrderNo = merchantOrderNoFromBill(bill);
  if (!merchantOrderNo) throw new Error('账单缺少商家订单号，拒绝查询');
  // ⚠️ 官方点名的「最容易遗漏的一步」：付款后必须携带订单号重试**同一笔原始请求**，
  // body 必须与首次 probe 完全一致，订单号只走 Header（由官方 CLI 签名注入 X-Out-Trade-No）。
  // 漏掉 -d 会导致服务端收到空 body，无法履约。
  const cli = [
    '402-query-payment-status',
    '--json',
    '--out-shake-no', shakeNo,
    '-r', req.url,
    '-m', req.method,
    '-d', typeof req.body === 'string' ? req.body : JSON.stringify(req.body),
  ];
  // 原样重放首次请求的 Header（若有），避免服务端按 Header 区分订单时对不上
  for (const h of req.headers || []) for (const [k,v] of Object.entries(h)) cli.push('-H', `${k}: ${v}`);
  let q;
  try {
    q = await runBot(cli);
  } catch (e) {
    const stdout = Buffer.isBuffer(e?.stdout) ? e.stdout.toString('utf8') : String(e?.stdout || '');
    let details = null;
    try { details = JSON.parse(stdout); } catch {}
    if (details && typeof details === 'object' && !Array.isArray(details)
        && (typeof details.errorCode === 'string' || typeof details.errorMessage === 'string')) {
      const privateText = typeof req.body === 'string' ? req.body : req.body?.text;
      let code = String(details.errorCode || 'QUERY_FAILED').replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 100);
      let message = String(details.errorMessage || '').replace(/[\r\n\t]/g, ' ').slice(0, 300);
      // Never echo the original document text if an upstream error happens to include it.
      if (typeof privateText === 'string' && privateText) {
        code = code.split(privateText).join('REDACTED');
        message = message.split(privateText).join('[请求内容已省略]');
      }
      throw new Error(`错误 [ODS-E15] 官方查询失败（${code}）${message ? `：${message}` : ''}`);
    }
    // Unknown CLI failures can contain the complete command and request body. Keep local
    // order files for retry, suppress raw stdout/stderr, and give only a safe next step.
    throw new Error('错误 [ODS-E15] 官方查询未成功，请核对官方查询凭据后重试；本地账单与请求已保留');
  }
  const delivery = requireDelivery(q.stdout, merchantOrderNo);
  if (!req.payment_query_no) {
    req.payment_query_no = shakeNo;
    await writeFile(p.request, JSON.stringify(req, null, 2), 'utf8');
  }
  await writeFile(p.resource, JSON.stringify(delivery), 'utf8');
  process.stdout.write(JSON.stringify(delivery, null, 2) + '\n');
  if (/already_fulfilled/i.test(q.stdout || '')) {
    console.log('\n该订单此前已履约（幂等命中，未重复扣费/交付）。');
  }
  // 履约成功后落凭证（服务端返回什么就固化什么；解析失败也不影响原文与指纹落盘）
  {
    try {
      await writeCertificate({
        orderNo: shakeNo,
        amount: JSON.parse(Buffer.from(bill, 'base64url').toString('utf8')).protocol.amount,
        raw: JSON.stringify(delivery),
        outDir: args['out-dir'],
      });
    } catch (e) {
      console.log('（凭证生成失败，不影响已取回的体检结果）：' + String(e.message || e).slice(0, 140));
    }
  }
  await archiveState(p);
  if (p.dir === paths().dir) clearState();
  return 0;
}

/* ── 遗留账单：判断「还在有效期」还是「已过期」，供 precheck / reset 使用 ──
 * 为什么（2026-10-09 真机踩到）：precheck 原先只判断账单文件在不在，
 * 于是**已过期的旧账单**也会把流程钉死，而用户不知道该删什么；反过来，
 * 真正还在有效期的账单（可能正在付款）必须拦住，避免串单。
 */
function billInfo() {
  const p = paths();
  const out = { exists: false, orderNo: '', queryNo: '', amount: '', payBefore: null, expired: false, minutes: 0 };
  if (!existsSync(p.bill)) return out;
  out.exists = true;
  try { out.queryNo = JSON.parse(readFileSync(p.request, 'utf8')).payment_query_no || ''; } catch {}
  try {
    const raw = readFileSync(p.bill, 'utf8').trim();
    const j = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
    out.orderNo = j?.protocol?.out_trade_no || '';
    out.amount = j?.protocol?.amount || '';
    const t = j?.protocol?.pay_before ? Date.parse(j.protocol.pay_before) : NaN;
    if (Number.isFinite(t)) {
      out.payBefore = new Date(t).toISOString();
      out.expired = Date.now() > t;
      out.minutes = Math.max(0, Math.round((t - Date.now()) / 60000));
    }
  } catch { /* 账单文件损坏：当作需要清理 */ }
  return out;
}

/** 清理本地账单状态（不触碰支付宝侧订单；未付款订单会自行失效） */
function clearState() {
  const p = paths();
  for (const f of [p.bill, p.request, p.resource]) {
    try { if (existsSync(f)) unlinkSync(f); } catch { /* 忽略 */ }
  }
}

function archiveDir(orderNo) {
  return path.join(paths().dir, 'archive', createHash('sha256').update(String(orderNo)).digest('hex'));
}
function merchantOrderNoFromBill(bill) {
  try { return JSON.parse(Buffer.from(String(bill || ''), 'base64url').toString('utf8')).protocol?.out_trade_no || ''; }
  catch { return ''; }
}
async function archiveState(source = paths()) {
  const billPath = source.bill;
  const bill = existsSync(billPath) ? (await readFile(billPath, 'utf8')).trim() : '';
  const merchantOrderNo = merchantOrderNoFromBill(bill);
  if (!merchantOrderNo) throw new Error('账单损坏，无法安全归档；请保留本地订单文件并联系支持');
  let request = {};
  if (existsSync(source.request)) request = JSON.parse(await readFile(source.request, 'utf8'));
  const orderNos = [...new Set([merchantOrderNo, request.payment_query_no].filter(Boolean))];
  for (const orderNo of orderNos) {
    const dir = archiveDir(orderNo);
    await mkdir(dir, { recursive: true });
    for (const f of [source.bill, source.request, source.resource]) if (existsSync(f))
      await writeFile(path.join(dir, path.basename(f)), await readFile(f), { mode: 0o600 });
  }
}

/* ── precheck：官方要求的第一条指令 ───────────────────────────── */
async function cmdPrecheck() {
  const rows = [];
  const ok = (b) => (b ? '✅' : '❌');

  // ① 官方支付 CLI
  const bin = botCandidates()[0];
  rows.push([ok(!!bin), '官方支付 CLI alipay-bot', bin || '未安装 → 执行 npx -y @alipay/agent-payment@latest install']);

  // ② Node 版本（脚本用内置 fetch）
  const major = Number(process.versions.node.split('.')[0]);
  rows.push([ok(major >= 18), `Node.js >= 18（当前 ${process.version}）`, '']);

  // ③ 商家服务端可达（只发 HEAD/OPTIONS，不带业务数据、不产生订单）
  let reach = false, detail = '';
  try {
    const res = await fetch(RESOURCE_URL, { method: 'OPTIONS', signal: AbortSignal.timeout(15000) });
    reach = res.status < 500;
    detail = `HTTP ${res.status}`;
  } catch (e) {
    detail = String(e.message || e).slice(0, 80);
  }
  rows.push([ok(reach), `商家服务端可达 ${RESOURCE_URL}`, detail]);

  // ④ 遗留账单：已过期 → 自动清理放行；仍在有效期 → 拦住并给出两条出路
  const info = billInfo();
  if (!info.exists) {
    rows.push(['✅', '无遗留账单（避免串单）', '']);
  } else if (info.expired) {
    rows.push(['❌', `本地账单已过付款期限（订单 ${info.orderNo || '未知'}）`,
      `已付款请执行 complete --out-shake-no ${info.queryNo || '<支付宝查询号>'} 取回原报告；确认放弃请执行 reset 归档后重新开始。`]);
  } else {
    rows.push(['❌', `有未完成的账单（订单 ${info.orderNo || '未知'}${info.amount ? `，${info.amount} 元` : ''}，还剩约 ${info.minutes} 分钟）`,
      '两条出路：\n'
      + '        ① 这笔还没付款 → 清理本地账单：node scripts/office-doc-suite-paid.mjs reset\n'
      + `        ② 这笔已经付过款 → 取回结果：node scripts/office-doc-suite-paid.mjs complete --out-shake-no ${info.queryNo || '<支付宝查询号>'}`]);
  }

  console.log('付费前置检查（SkillHub 官方要求的第一步）\n');
  for (const [mark, name, note] of rows) {
    console.log(`  ${mark} ${name}${note ? `\n      ${note}` : ''}`);
  }
  const blocked = rows.filter(r => r[0] === '❌').length;
  console.log(blocked
    ? `\n前置检查未通过（${blocked} 项）。请先按上面的提示处理，再执行 probe——不要在未通过时硬跑 probe（会产生新账单，导致串单与白付）。`
    : '\n前置检查通过，可以执行 probe。');
  return blocked ? 1 : 0;
}

/** reset：清理本地账单状态，便于重新开始（不触碰支付宝侧订单） */
async function cmdReset() {
  const info = billInfo();
  if (!info.exists) {
    console.log('本地没有遗留账单，无需清理。');
    return 0;
  }
  await archiveState();
  clearState();
  console.log(`✅ 已清理本地账单状态${info.orderNo ? `（原订单 ${info.orderNo}${info.amount ? `，${info.amount} 元` : ''}）` : ''}。`);
  console.log('   · 这笔订单若**未付款**：支付宝侧会自行失效，不会扣费；');
  console.log(`   · 若**已付款但还没取结果**：不要重新下单，请用 complete --out-shake-no ${info.queryNo || '<支付宝查询号>'} 查询原订单。`);
  return 0;
}

const HELP = `办公文档三件套 · 云端文档体检（支付宝按次付费）
用法：
  node scripts/office-doc-suite-paid.mjs precheck
  node scripts/office-doc-suite-paid.mjs probe --kind text --text "<待检文本>"
  node scripts/office-doc-suite-paid.mjs probe --kind xlsx --summary <结构化摘要.json>
  node scripts/office-doc-suite-paid.mjs pay [--session-id <id>]
  node scripts/office-doc-suite-paid.mjs complete --out-shake-no <支付宝查询号>
  node scripts/office-doc-suite-paid.mjs reset               # 清理遗留账单（串单防护卡住时用）
  node scripts/office-doc-suite-paid.mjs cert --demo         # 不付款先看「体检凭证」长什么样
  node scripts/office-doc-suite-paid.mjs cert --from <凭证.json>   # 把已有凭证重新渲染成 PDF
环境变量：SARB_BACKEND_URL（商家服务端）| ALIPAY_BOT_BIN（alipay-bot 路径，优先于 PATH）| ODS_CERT_DIR（凭证输出目录，默认 ./体检凭证）
价格：以服务端 402 账单为准（脚本不写死金额；SkillHub 页面展示价见详情页）
`;

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0] || (args.help !== undefined ? 'help' : '');
  try {
    switch (cmd) {
      case 'precheck': return await cmdPrecheck();
      case 'reset': return await cmdReset();
      case 'cert': return await cmdCert(args);
      case 'probe': return await cmdProbe(args);
      case 'pay': return await cmdPay(args);
      case 'complete': return await cmdComplete(args);
      default:
        process.stdout.write(HELP);
        return 0;
    }
  } catch (e) {
    process.stderr.write(`错误：${e && e.message ? e.message : e}\n`);
    return 1;
  }
}

// 不用立即 process.exit：可能在 HTTP 连接仍处于 closing 状态时强退，
// 触发 libuv 断言（Assertion failed: !(handle->flags & UV_HANDLE_CLOSING)）。
// 先设 exitCode 让事件循环自然排空，2 秒后仍未退出再兜底强退。
main().then((c) => {
  process.exitCode = c || 0;
  setTimeout(() => process.exit(c || 0), 2000).unref();
});
