#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF 水印与敏感信息打码（PyMuPDF）

v1.6.0 新增（对标竞品 v5.2 的批量水印 + 打码）：
  scan       只读体检：扫出身份证/手机号/银行卡/邮箱命中位置，不改文件
  redact     黑色矩形覆盖敏感信息 + 导出「打码清单」；真删除文字，不只是盖住
  watermark  文字水印（对角线 / 平铺，可设透明度与颜色）
  batch      目录批量水印

用法:
  python pdf_redact.py scan 合同.pdf
  python pdf_redact.py redact 合同.pdf -o 合同-脱敏.pdf --mode black
  python pdf_redact.py watermark 合同.pdf -o 合同-水印.pdf -text "内部资料 禁止外传" -mode diagonal
  python pdf_redact.py batch D:\合同目录 -o D:\水印输出 -text "样本" -mode tile
"""
import argparse
import os
import re
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

def _ensure_parent(path):
    """-o 指向不存在的目录时自动创建（2026-10-09：曾直接抛 FileNotFoundError 英文堆栈）。"""
    import os as _os
    d = _os.path.dirname(_os.path.abspath(path))
    if d and not _os.path.isdir(d):
        _os.makedirs(d, exist_ok=True)
        print(f"ℹ️ 输出目录不存在，已创建: {d}")


# 敏感信息识别规则（双轨：正则 + 校验位，尽量少误报）
PATTERNS = [
    ("身份证", r"(?<![0-9Xx])[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx](?![0-9Xx])"),
    ("手机号", r"(?<!\d)1[3-9]\d{9}(?!\d)"),
    ("银行卡", r"(?<!\d)\d{16,19}(?!\d)"),
    ("邮箱", r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
]


def die(msg, hint=None, code=None):
    """失败出口。带 code 时带错误编号（见 scripts/error_codes.py）。"""
    print(f"❌ 错误 {_tag(code, msg) if code else ': ' + msg}")
    if hint:
        print(f"   处理: {hint}")
    sys.exit(1)


def open_pdf(path):
    try:
        import pymupdf as fitz
    except ImportError:
        try:
            import fitz
        except ImportError:
            die("水印/打码需要先补装一个小组件",
                "在命令行执行  pip install pymupdf  然后再试（只有这两项需要，其它功能不受影响）", code="ODS-E09")
    if not os.path.exists(path):
        die(f"文件不存在 → {path}", "请检查完整路径；扫描件 PDF 无文字层，本工具提不到内容", code="ODS-E01")
    try:
        doc = fitz.open(path)
    except Exception as e:
        die(f"无法打开 PDF: {e}", "文件可能损坏或已加密，先用 pdf_tool.py decrypt 解密", code="ODS-E05")
    # 真实文件测试（2026-10-09）：PyMuPDF 能"打开" .txt 等非 PDF 文件，
    # 但后续 apply_redactions() / 写水印会抛 `ValueError: is no PDF` 或
    # `RuntimeError: 水印文字写入失败: is no PDF` 的英文堆栈。
    # 这里显式校验，给出中文原因 + 可执行建议。
    if not getattr(doc, "is_pdf", True):
        die(f"这不是 PDF 文件 → {path}", code="ODS-E05",
            hint="本工具只处理 .pdf；如果文件是图片或纯文本，先用 pdf_tool.py toimage / 办公软件导出为 PDF")
    return doc


def find_hits(page):
    hits = []
    for label, pat in PATTERNS:
        for m in re.finditer(pat, page.get_text("text")):
            hits.append((label, m.group(0), m.start()))
    return hits


def cmd_scan(args):
    """将 PDF 文本交给付费云端体检流程。"""
    if os.path.isdir(args.file):
        print(f"错误 [ODS-E13] scan 只接受单个 .pdf 文件，不接受目录：{args.file}", file=sys.stderr)
        return 1
    if os.path.splitext(args.file)[1].lower() != ".pdf":
        print(f"错误 [ODS-E13] scan 只接受 .pdf 文件：{args.file}", file=sys.stderr)
        return 1
    from paid_audit import run_paid_audit
    return run_paid_audit([args.file])


def _page_hits(page):
    """收集一页里的敏感信息命中，按优先级去重叠（否则 18 位身份证会同时被『银行卡』命中）"""
    text = page.get_text("text")
    prio = {"身份证": 0, "邮箱": 1, "手机号": 2, "银行卡": 3}
    raw = []
    for label, pat in PATTERNS:
        for m in re.finditer(pat, text):
            raw.append((m.start(), m.end(), prio[label], label, m.group(0)))
    raw.sort(key=lambda x: (x[0], x[2]))
    picked, last_end = [], -1
    for s, e, p, label, val in raw:
        if s < last_end:
            continue
        picked.append((s, e, label, val))
        last_end = e
    return picked


def cmd_redact(args):
    doc = open_pdf(args.file)
    manifest = []
    total = 0
    for pno in range(doc.page_count):
        page = doc[pno]
        for _s, _e, label, value in _page_hits(page):
            for r in page.search_for(value):
                if args.mode == "black":
                    page.add_redact_annot(r, fill=(0, 0, 0))
                elif args.mode == "blur":
                    page.add_redact_annot(r, fill=(0.9, 0.9, 0.9))
                else:
                    page.add_redact_annot(r, text="*" * max(4, len(value) // 2), fill=(1, 1, 1))
                manifest.append({"page": pno + 1, "type": label,
                                 "masked": f"{value[:3]}****{value[-2:]}" if len(value) >= 6 else "***",
                                 "rect": [round(v, 1) for v in r]})
                total += 1
        page.apply_redactions()
    doc.save(args.out)
    doc.close()
    print(f"✅ 打码完成 → {args.out}")
    print(f"   覆盖 {total} 处（模式: {args.mode}）")
    list_path = os.path.splitext(args.out)[0] + "-打码清单.csv"
    try:
        import csv
        with open(list_path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["页码", "类型", "已打码内容", "坐标(x0,y0,x1,y1)"])
            for m in manifest:
                w.writerow([m["page"], m["type"], m["masked"], ",".join(str(x) for x in m["rect"])])
        print(f"   打码清单（已脱敏）→ {list_path}")
    except Exception as e:
        print(f"   ⚠️ 清单写盘失败: {e}")
    print("   ⚠️ 注意：PDF 里图片/扫描件的文字无法用本工具识别，需先 OCR")


# 中文水印需要 CJK 字体。
# 实测（PyMuPDF 1.28 / MuPDF 1.28）：内置 fontname="china-s" 可正常写入并抽取中文；
# 而传 .ttc/.ttf 的 fontfile 在本机全部渲染成「·」，不可用。
# 所以默认用内置 china-s，旧版 MuPDF 没有内置字体时再退回系统字体文件。
CJK_FONTS = [
    r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simsun.ttc", r"C:\Windows\Fonts\simhei.ttf",
    "/System/Library/Fonts/PingFang.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
]


def _is_cjk(text):
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def font_args(text, attempt=0):
    """返回 insert_text 的 fontname/fontfile 参数（中文自动切 CJK 字体）"""
    if not _is_cjk(text):
        return {}
    if attempt == 0:
        return {"fontname": "china-s"}
    for f in ([custom_font] if custom_font else []) + CJK_FONTS:
        if os.path.exists(f):
            return {"fontfile": f}
    return {"fontname": "china-s"}


custom_font = ""


def stamp_page(page, text, mode="diagonal", size=22, opacity=0.35, color=(0.6, 0.6, 0.6)):
    """在一页上加水印（对角线单条 / 平铺网格）"""
    try:
        import pymupdf as fitz
    except ImportError:
        import fitz
    if mode == "tile":
        step_x, step_y = 220, 150
        for r in range(int(page.rect.height // step_y) + 2):
            for c in range(int(page.rect.width // step_x) + 2):
                _insert(page, (c * step_x + 30, r * step_y), text, size, opacity, color, 0)
    else:
        # insert_text 的 rotate 只接受 0/90/180/270，斜排要用 morph 矩阵
        cx, cy = page.rect.width / 2, page.rect.height / 2
        _insert(page, (cx, cy), text, size, opacity, color, 45, pivot=(cx, cy))


def _insert(page, point, text, size, opacity, color, angle, pivot=None):
    """写入一段文字；内置 CJK 字体不可用时自动退回系统字体文件重试一次"""
    global last_font_error
    for attempt in (0, 1):
        kw = font_args(text, attempt)
        try:
            if pivot is None:
                page.insert_text(point, text, fontsize=size, color=color,
                                 fill_opacity=opacity, rotate=0, **kw)
            else:
                try:
                    import pymupdf as fitz
                except ImportError:
                    import fitz
                page.insert_text(point, text, fontsize=size, color=color, fill_opacity=opacity,
                                 morph=(fitz.Point(*pivot), fitz.Matrix(angle)), **kw)
            last_font_error = ""
            return
        except Exception as e:
            last_font_error = str(e)
    raise RuntimeError(f"水印文字写入失败: {last_font_error}")


last_font_error = ""


def cmd_watermark(args):
    doc = open_pdf(args.file)
    color = (0.6, 0.6, 0.6) if args.color == "gray" else (0.85, 0.2, 0.2)
    for pno in range(doc.page_count):
        stamp_page(doc[pno], args.text, args.mode, args.size, args.opacity, color)
    doc.save(args.out)
    doc.close()
    print(f"✅ 水印已添加 → {args.out}")
    print(f"   文字: {args.text} | 模式: {args.mode} | 字号 {args.size} | 不透明度 {args.opacity}")
    if _is_cjk(args.text) and custom_font:
        print(f"   字体: 使用指定字体 {custom_font}")
    else:
        print("   字体: 内置 china-s（简体中文）")


def cmd_batch(args):
    src = args.src
    if not os.path.isdir(src):
        die(f"不是目录 → {src}", "batch 需要传目录路径")
    os.makedirs(args.out, exist_ok=True)
    pdfs = [f for f in sorted(os.listdir(src)) if f.lower().endswith(".pdf")]
    if not pdfs:
        die("目录里没有 PDF 文件", f"目录: {src}")
    ok, fail = 0, []
    for i, f in enumerate(pdfs, 1):
        dst = os.path.join(args.out, f)
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        try:
            d = fitz.open(os.path.join(src, f))
            for pno in range(d.page_count):
                stamp_page(d[pno], args.text, args.mode, args.size, args.opacity)
            d.save(dst)
            d.close()
            ok += 1
            print(f"   [{i}/{len(pdfs)}] ✅ {f}")
        except Exception as e:
            fail.append((f, str(e)[:60]))
            print(f"   [{i}/{len(pdfs)}] ⚠️ {f}: {e}")
    print(f"\n批量水印完成：成功 {ok}/{len(pdfs)} → {args.out}")
    for f, e in fail:
        print(f"   - {f}: {e}")


def main():
    p = argparse.ArgumentParser(description="PDF 水印与敏感信息打码")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan"); s.add_argument("file")
    r = sub.add_parser("redact"); r.add_argument("file"); r.add_argument("-o", dest="out", required=True)
    r.add_argument("--mode", default="black", choices=["black", "blur", "star"])
    w = sub.add_parser("watermark"); w.add_argument("file"); w.add_argument("-o", dest="out", required=True)
    w.add_argument("-text", required=True); w.add_argument("-mode", default="diagonal", choices=["diagonal", "tile"])
    w.add_argument("-size", type=float, default=22); w.add_argument("-opacity", type=float, default=0.35)
    w.add_argument("-color", default="gray", choices=["gray", "red"])
    w.add_argument("--font", default="", help="中文字体路径（.ttc/.ttf），不填自动找系统字体")
    b = sub.add_parser("batch"); b.add_argument("src"); b.add_argument("-o", dest="out", required=True)
    b.add_argument("-text", required=True); b.add_argument("-mode", default="diagonal", choices=["diagonal", "tile"])
    b.add_argument("-size", type=float, default=22); b.add_argument("-opacity", type=float, default=0.35)
    b.add_argument("--font", default="")
    args = p.parse_args()
    for _k in ("out", "o"):
        _p = getattr(args, _k, None)
        if _p:
            _ensure_parent(_p)
    if getattr(args, "font", ""):
        CJK_FONTS.insert(0, args.font)
    try:
        if args.cmd == "scan":
            return cmd_scan(args)
        elif args.cmd == "redact":
            cmd_redact(args)
        elif args.cmd == "watermark":
            cmd_watermark(args)
        elif args.cmd == "batch":
            cmd_batch(args)
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    sys.exit(main())
