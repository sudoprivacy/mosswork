#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF 处理工具（PyPDF2 + PyMuPDF）v1.3
功能: 合并 / 拆分 / 提取文字 / 转图片 / 加页码 / 加密 / 解密 / 元数据
用法:
  python pdf_tool.py merge 1.pdf 2.pdf 3.pdf -o out.pdf
  python pdf_tool.py split in.pdf -o out_dir -pages 1-3,5
  python pdf_tool.py extract in.pdf -o text.txt -pages 1-3
  python pdf_tool.py toimage in.pdf -o out_dir -dpi 150     # PDF 转图片
  python pdf_tool.py page-num in.pdf -o out.pdf             # 加页码
  python pdf_tool.py protect in.pdf -o out.pdf -pwd secret
  python pdf_tool.py decrypt in.pdf -o out.pdf -pwd secret
  python pdf_tool.py info in.pdf
"""
import argparse
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

def _ensure_parent(path):
    """-o 指向不存在的目录时自动创建（2026-10-09：曾直接抛 FileNotFoundError 英文堆栈）。"""
    import os as _os
    d = _os.path.dirname(_os.path.abspath(path))
    if d and not _os.path.isdir(d):
        _os.makedirs(d, exist_ok=True)
        print(f"ℹ️ 输出目录不存在，已创建: {d}")



def _norm_path(path):
    """Windows 路径规范化：处理反斜杠问题（用户粘贴路径时 \文 \t 等可能被误读）。
    示例: D:\文档\报告.pdf -> D:\文档\报告.pdf（保持原样，但统一分隔符）"""
    import os
    p = str(path).replace("/", os.sep)
    return os.path.normpath(p)


def fail(msg, code=1):
    """失败统一出口：先打印中文原因，再以非零码退出。

    踩坑记录（2026-10-09，退出码审计）：旧版失败路径只 print 不退出，
    脚本仍以 0 结束 —— Agent / CI 会据此误判"已完成"。
    """
    print(msg)
    sys.exit(code)

def _check_path(path):
    """路径校验：不存在/无权限时给出中文提示。"""
    if not os.path.exists(path):
        print(_fmt("ODS-E01", f"文件不存在 → {path}"))
        print(f"   请检查路径是否正确（当前目录: {os.getcwd()}）")
        print(f"   提示: 可用完整路径，如 D:\\文档\\report.pdf")
        sys.exit(1)
    if not os.access(path, os.R_OK):
        print(_fmt("ODS-E10", f"无读取权限 → {path}"))
        print(f"   请检查文件权限，或换一个可读的路径")
        sys.exit(1)


def merge(pdf_list, out):
    from PyPDF2 import PdfMerger
    ok_files = []
    errors = []
    for p in pdf_list:
        p = _norm_path(p)
        if not os.path.exists(p):
            errors.append(f"{p}: 文件不存在")
            print(f"  ⚠️ 跳过（不存在）: {p}")
            continue
        if not os.access(p, os.R_OK):
            errors.append(f"{p}: 无读取权限")
            print(f"  ⚠️ 跳过（无权限）: {p}")
            continue
        ok_files.append(p)
    if not ok_files:
        print("❌ 没有可合并的有效 PDF 文件")
        sys.exit(1)
    try:
        m = PdfMerger()
        total = len(ok_files)
        for i, p in enumerate(ok_files, 1):
            print(f"  合并 {i}/{total}: {os.path.basename(p)}")
            m.append(p)
        m.write(_norm_path(out))
        m.close()
        print(f"OK 合并 {len(ok_files)}/{len(pdf_list)} 个 PDF → {out}")
    except Exception as e:
        print(f"❌ 合并失败: {e}")
        print(f"   可能原因: 文件损坏或格式不兼容，请检查输入 PDF 是否完整")
        sys.exit(1)
    if errors:
        print(f"⚠️ {len(errors)} 个文件被跳过：")
        for e in errors:
            print(f"  - {e}")


def split(pdf, out_dir, pages):
    from PyPDF2 import PdfReader, PdfWriter
    _check_path(pdf)
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as e:
        print(f"❌ 无法创建输出目录 {out_dir}: {e}")
        print(f"   提示: 检查路径是否有效、是否有写入权限")
        sys.exit(1)
    reader = PdfReader(pdf)
    total = len(reader.pages)
    wanted = set()
    for part in pages.split(","):
        part = part.strip()
        try:
            if "-" in part:
                a, b = part.split("-")
                a, b = int(a), int(b)
                if a < 1 or b > total or a > b:
                    print(_fmt("ODS-E08", f"页面范围无效: {part}（文档共 {total} 页）"))
                    sys.exit(1)
                wanted.update(range(a - 1, b))
            else:
                n = int(part)
                if n < 1 or n > total:
                    print(_fmt("ODS-E08", f"页码无效: {n}（文档共 {total} 页）"))
                    sys.exit(1)
                wanted.add(n - 1)
        except ValueError:
            print(_fmt("ODS-E08", f"无法解析页码: {part}（示例: 1-3,5）"))
            sys.exit(1)
    for idx in sorted(wanted):
        w = PdfWriter()
        w.add_page(reader.pages[idx])
        name = f"{os.path.splitext(os.path.basename(pdf))[0]}_p{idx+1}.pdf"
        with open(os.path.join(out_dir, name), "wb") as f:
            w.write(f)
    print(f"OK 拆分 {len(wanted)} 页 → {out_dir}")


def extract(pdf, out, pages=""):
    _check_path(pdf)
    kind, reader, total = _open_lenient(pdf)
    if not kind:
        print(_fmt("ODS-E05", "这个 PDF 打不开（换了两种读取方式都读不了）"))
        print("   处理: 文件可能损坏严重或不是 PDF；可先用其它工具另存一份再试")
        sys.exit(1)
    # 解析页范围（默认全部）——两条通道共用同一套页码校验
    wanted = []
    if pages:
        try:
            for part in pages.split(","):
                part = part.strip()
                if "-" in part:
                    a, b = part.split("-")
                    a, b = int(a), int(b)
                    if a < 1 or b > total or a > b:
                        print(_fmt("ODS-E08", f"页面范围无效: {part}（文档共 {total} 页）"))
                        sys.exit(1)
                    wanted.extend(range(a - 1, b))
                else:
                    n = int(part)
                    if n < 1 or n > total:
                        print(_fmt("ODS-E08", f"页码无效: {n}（文档共 {total} 页）"))
                        sys.exit(1)
                    wanted.append(n - 1)
        except ValueError:
            print(_fmt("ODS-E08", f"无法解析页码: {pages}（示例: 1-3,5）"))
            sys.exit(1)
    else:
        wanted = list(range(total))

    text = []
    if kind == 'pymupdf':
        # pymupdf 的取字通常比 PyPDF2 完整（尤其 CID/CJK 字体），且能读轻微损坏的文件
        for i in wanted:
            try:
                text.append(f"--- 第 {i+1} 页 ---\n{reader[i].get_text() or ''}")
            except Exception:
                text.append(f"--- 第 {i+1} 页 ---\n[提取失败]")
    else:
        for i in wanted:
            try:
                t = reader.pages[i].extract_text() or ""
                text.append(f"--- 第 {i+1} 页 ---\n{t}")
            except Exception:
                text.append(f"--- 第 {i+1} 页 ---\n[提取失败]")
    if kind == 'pymupdf':
        reader.close()
    content = "\n\n".join(text)
    if out:
        try:
            with open(out, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"OK 提取 {len(wanted)} 页文字 → {out}")
        except Exception as e:
            print(f"❌ 写入失败: {e}")
            print(f"   提示: 检查输出路径是否有效、是否有写入权限")
    else:
        print(content)


def toimage(pdf, out_dir, dpi=150):
    """PDF 每页转成 PNG 图片。
    依赖: pip install pymupdf  （仅此功能需要）

    用法:
      python pdf_tool.py toimage in.pdf                # 输出到 ./pdf_images/，默认 150 DPI
      python pdf_tool.py toimage in.pdf -o 图片目录     # 指定输出目录
      python pdf_tool.py toimage in.pdf -dpi 300       # 高清 300 DPI（打印用）

    输出: out_dir/page_001.png, page_002.png ... （每页一张）
    """
    try:
        import pymupdf
    except ImportError:
        print("❌ 把 PDF 转成图片，需要先补装一个小组件。\n   处理: 在命令行执行  pip install pymupdf  然后再试一次（装一次，以后都能用）")
        print("   其他 PDF 功能（合并/拆分/提取/加密）不需要此依赖")
        sys.exit(1)
    _check_path(pdf)
    try:
        os.makedirs(out_dir, exist_ok=True)
    except Exception as e:
        print(f"❌ 无法创建输出目录 {out_dir}: {e}")
        print(f"   提示: 检查路径是否有效、是否有写入权限")
        sys.exit(1)
    try:
        doc = pymupdf.open(pdf)
    except Exception as e:
        print(_fmt("ODS-E05", f"无法打开 PDF: {e}"))
        print(f"   可能原因: 文件损坏、非 PDF 格式，或已加密（需先解密）")
        sys.exit(1)
    total = doc.page_count
    print(f"共 {total} 页，DPI={dpi}，输出到 {out_dir}/")
    ok = 0
    for i, page in enumerate(doc, 1):
        try:
            pix = page.get_pixmap(dpi=dpi)
            out_path = os.path.join(out_dir, f"page_{i:03d}.png")
            pix.save(out_path)
            ok += 1
            print(f"  第 {i}/{total} 页 → {os.path.basename(out_path)}")
        except Exception as e:
            print(f"  ⚠️ 第 {i} 页转换失败: {e}")
    doc.close()
    print(f"OK 转换完成：成功 {ok}/{total} 页 → {out_dir}/")


def add_page_numbers(pdf, out):
    """为每页添加页码（页脚居中）。用 PyMuPDF 真正叠加页码文本。
    依赖: pip install pymupdf  （仅此功能需要）"""
    try:
        import pymupdf  # PyMuPDF 新 API
    except ImportError:
        print("❌ 给 PDF 加页码，需要先补装一个小组件。\n   处理: 在命令行执行  pip install pymupdf  然后再试一次")
        print("   其他 PDF 功能（合并/拆分/提取/加密）不需要此依赖")
        sys.exit(1)
    _check_path(pdf)
    try:
        doc = pymupdf.open(pdf)
    except Exception as e:
        print(_fmt("ODS-E05", f"无法打开 PDF: {e}"))
        sys.exit(1)
    total = doc.page_count
    for i, page in enumerate(doc, 1):
        rect = page.rect
        text = f"{i} / {total}"
        try:
            tw = pymupdf.get_text_length(text, fontsize=10)
        except Exception:
            tw = len(text) * 5
        x = (rect.width - tw) / 2
        y = rect.height - 30
        page.insert_text((x, y), text, fontsize=10, color=(0.4, 0.4, 0.4))
    try:
        doc.save(out, garbage=4, deflate=True)
        print(f"OK 已为 {total} 页添加页码 → {out}")
    except Exception as e:
        print(f"❌ 保存失败: {e}")
        print(f"   提示: 检查输出路径是否有效、是否有写入权限")
    finally:
        doc.close()


def protect(pdf, out, pwd):
    from PyPDF2 import PdfWriter, PdfReader
    _check_path(pdf)
    reader = PdfReader(pdf)
    w = PdfWriter()
    for page in reader.pages:
        w.add_page(page)
    w.encrypt(pwd)
    with open(out, "wb") as f:
        w.write(f)
    print(f"OK 加密完成 → {out}")


def decrypt(pdf, out, pwd):
    from PyPDF2 import PdfReader, PdfWriter
    _check_path(pdf)
    try:
        reader = PdfReader(pdf)
        if not reader.is_encrypted:
            print(f"提示: 该 PDF 未加密，无需解密")
            return
        result = reader.decrypt(pwd)
        if result == 0:
            print(_fmt("ODS-E07", "解密失败: 密码错误"))
            print(f"   请确认密码（提示: 尝试常见密码，或联系文件提供者）")
            sys.exit(1)
        w = PdfWriter()
        for page in reader.pages:
            w.add_page(page)
        with open(out, "wb") as f:
            w.write(f)
        print(f"OK 解密完成 → {out}")
    except Exception as e:
        print(f"❌ 解密失败: {e}")
        print(f"   提示: 文件可能损坏或加密方式不兼容")
        sys.exit(1)


def _open_lenient(pdf):
    """优先用 PyPDF2；读不了就退回 pymupdf（能自动修复轻微损坏），返回 (kind, reader, total_pages)。

    为什么（2026-10-09 第三批真实文件测试）：pdf.js 语料的 711 字节截断 PDF
    （无 EOF 标记）PyPDF2 直接报 `EOF marker not found`，而 pymupdf 能打开并修复（is_repaired=True）。
    用户手里的"略破损 PDF"很常见，只读的信息/取字没必要因为 PyPDF2 读不了就整体失败。
    """
    from PyPDF2 import PdfReader
    try:
        reader = PdfReader(pdf)
        return 'pypdf2', reader, len(reader.pages)
    except Exception as e_pypdf:
        try:
            import pymupdf
            doc = pymupdf.open(pdf)
            print("⚠️ 这个文件末尾不完整（可能没下载完整，或保存时中断），已自动修复后读取；"
                  "内容可能不全，重要文件建议从原处重新导出一份")
            return 'pymupdf', doc, doc.page_count
        except Exception:
            return None, None, 0


def info(pdf):
    _check_path(pdf)
    kind, reader, total = _open_lenient(pdf)
    if not kind:
        print(_fmt("ODS-E05", "这个 PDF 打不开（换了两种读取方式都读不了）"))
        print("   处理: 文件可能损坏严重或不是 PDF；可先用其它工具另存一份再试")
        sys.exit(1)
    print(f"文件: {pdf}")
    print(f"页数: {total}")
    if kind == 'pypdf2':
        print(f"加密: {reader.is_encrypted}")
        for k, v in (reader.metadata or {}).items():
            print(f"  {k}: {v}")
    else:
        print(f"加密: {reader.is_encrypted}")
        print("读取方式: 已自动修复后读取（原文件略有破损）")
        meta = reader.metadata or {}
        for k, v in meta.items():
            print(f"  {k}: {v}")
        reader.close()


def main():
    p = argparse.ArgumentParser(description="PDF 处理工具")
    sub = p.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("merge")
    m.add_argument("files", nargs="+")
    m.add_argument("-o", "--out", default="merged.pdf")
    s = sub.add_parser("split")
    s.add_argument("pdf")
    s.add_argument("-o", "--out", default="split_out")
    s.add_argument("-pages", default="1-3")
    e = sub.add_parser("extract")
    e.add_argument("pdf")
    e.add_argument("-o", "--out", default="")
    e.add_argument("-pages", default="")
    ti = sub.add_parser("toimage")
    ti.add_argument("pdf")
    ti.add_argument("-o", "--out", default="pdf_images")
    ti.add_argument("-dpi", type=int, default=150)
    pn = sub.add_parser("page-num")
    pn.add_argument("pdf")
    pn.add_argument("-o", "--out", default="paged.pdf")
    pr = sub.add_parser("protect")
    pr.add_argument("pdf")
    pr.add_argument("-o", "--out", default="protected.pdf")
    pr.add_argument("-pwd", default="123456")
    de = sub.add_parser("decrypt")
    de.add_argument("pdf")
    de.add_argument("-o", "--out", default="decrypted.pdf")
    de.add_argument("-pwd", required=True)
    i = sub.add_parser("info")
    i.add_argument("pdf")
    args = p.parse_args()
    for _k in ("out", "o"):
        _p = getattr(args, _k, None)
        if _p:
            _ensure_parent(_p)

    if args.cmd == "merge":
        merge(args.files, args.out)
    elif args.cmd == "split":
        split(args.pdf, args.out, args.pages)
    elif args.cmd == "extract":
        extract(args.pdf, args.out, args.pages)
    elif args.cmd == "toimage":
        toimage(args.pdf, args.out, args.dpi)
    elif args.cmd == "page-num":
        add_page_numbers(args.pdf, args.out)
    elif args.cmd == "protect":
        protect(args.pdf, args.out, args.pwd)
    elif args.cmd == "decrypt":
        decrypt(args.pdf, args.out, args.pwd)
    elif args.cmd == "info":
        info(args.pdf)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
