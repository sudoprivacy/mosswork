#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一键安装/自检脚本（Office Doc Suite）
用法:
  python scripts/setup_check.py install   # 安装全部依赖
  python scripts/setup_check.py check     # 检查依赖是否就绪
  python scripts/setup_check.py demo      # 运行自检（生成示例文件验证）
"""
import shutil
import subprocess
import sys
import os

# Windows 控制台默认 GBK，遇到 ✅/❌ 这类符号会抛 UnicodeEncodeError 直接崩掉
# （self_test --quick 在没设 PYTHONIOENCODING 的环境里实测踩到过）。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

REQUIRED = {
    "python-docx": "docx",
    "openpyxl": "openpyxl",
    "PyPDF2": "PyPDF2",
}
OPTIONAL = {
    "pymupdf": "pymupdf",        # PDF 加页码 / 转图片
    "pycryptodome": "Crypto",    # PDF 解密 AES
    "xlrd": "xlrd",              # 旧版 .xls -> .xlsx 转换
}


def check_deps():
    print("=== 依赖检查 ===")
    all_ok = True
    for name, module in REQUIRED.items():
        try:
            __import__(module)
            print(f"  ✅ {name} 已安装")
        except ImportError:
            print(f"  ❌ {name} 未安装（必需）")
            all_ok = False
    for name, module in OPTIONAL.items():
        note = {"pymupdf": "PDF转图片/加页码", "pycryptodome": "PDF解密AES", "xlrd": "转旧版.xls"}.get(name, name)
        try:
            __import__(module)
            print(f"  ✅ {name} 已安装")
        except ImportError:
            print(f"  ⚠️ {name} 未安装（可选：{note}需要）")
    return all_ok


def install():
    print("=== 安装依赖 ===")
    pip = [sys.executable, "-m", "pip", "install"]
    print("安装必需包...")
    subprocess.run(pip + list(REQUIRED.keys()), check=False)
    print("安装可选包（PDF加页码/解密）...")
    subprocess.run(pip + list(OPTIONAL.keys()), check=False)
    print("完成！可运行 check 验证")


def demo():
    print("=== 自检：生成示例文件 ===")
    base = os.path.dirname(os.path.abspath(__file__))
    # docx
    r = subprocess.run([sys.executable, os.path.join(base, "docx_tool.py"), "demo", "-o", "demo.docx"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    print(f"  docx: {r.stdout.strip() or r.stderr.strip()}")
    # xlsx
    r = subprocess.run([sys.executable, os.path.join(base, "xlsx_tool.py"), "demo", "-o", "demo.xlsx"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    print(f"  xlsx: {r.stdout.strip() or r.stderr.strip()}")
    print("示例文件已生成：demo.docx / demo.xlsx（当前目录）")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cmd = sys.argv[1]
    if cmd == "install":
        install()
    elif cmd == "check":
        ok = check_deps()
        sys.exit(0 if ok else 1)
    elif cmd == "demo":
        demo()
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
