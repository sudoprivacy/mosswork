#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
self_test.py — 功能自检：一条命令验证整套件是否正常，避免带着 bug 去干活

为什么需要它：v1.6.0 补了 14 项能力，其中 4 个 bug（排序错位公式、筛选丢表头、
中文水印变方块、体检误报）都是**用**的时候才暴露的。与其每次踩坑，不如跑一次自检。

用法:
  python scripts/self_test.py            # 全量自检（需要 pymupdf）
  python scripts/self_test.py --quick    # 快速自检（只用必需依赖，秒级完成）
  python scripts/self_test.py --keep     # 保留临时产物，便于人工检查

退出码: 0 = 全过，1 = 有失败项
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PY = sys.executable

RESULTS = []


def rec(name, ok, detail=""):
    RESULTS.append((name, ok, detail))
    print(("  ✅ " if ok else "  ❌ ") + name + ((" | " + detail) if detail else ""))
    return ok


def run(script, *args, timeout=180):
    cmd = [PY, os.path.join(HERE, script)] + list(args)
    # 强制子进程用 UTF-8 输出：Windows 默认 GBK 会让带 ✅ 的脚本抛 UnicodeEncodeError
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=timeout, env=env)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def have(mod):
    try:
        __import__(mod)
        return True
    except Exception:
        return False


def section(title):
    print(f"\n=== {title} ===")


# ---------------------------------------------------------------- 素材
def make_materials(d):
    os.makedirs(d, exist_ok=True)
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active
    # 素材表刻意还原真实场景的"脏"状态：
    #   · 身份证号写成数字（Excel 会截断成 1.101e+17）→ 供 protect 测试
    #   · 达成率写成**活公式**且引用本行 → 供 sort 检测公式是否错位
    ws.append(["姓名", "销售额", "目标", "身份证号", "达成率"])
    for n, s, t in [("甲", 100000, 100000), ("乙", 30000, 100000), ("丙", 200000, 100000), ("丁", 50000, 100000)]:
        ws.append([n, s, t, 110101199003074512, f"=ROUND(B{ws.max_row + 1}/C{ws.max_row + 1}*100,1)"])
    wb.save(os.path.join(d, "表.xlsx"))

    from docx import Document
    doc = Document()
    doc.add_heading("测试方案", 0)
    doc.add_heading("一、背景", 1); doc.add_paragraph("正文。")
    doc.add_heading("二、方案", 1); doc.add_paragraph("正文。")
    doc.save(os.path.join(d, "方案.docx"))

    with open(os.path.join(d, "说明.md"), "w", encoding="utf-8") as f:
        f.write("# 标题\n\n正文**加粗**。\n\n## 二级\n\n- 列表项\n\n| 字段 | 说明 |\n|---|---|\n| A | 甲 |\n")

    if have("pymupdf"):
        import pymupdf as fitz
        p = fitz.open(); pg = p.new_page()
        pg.insert_text((60, 100), "身份证：110101199003074512", fontsize=12, fontname="china-s")
        pg.insert_text((60, 140), "手机：13812345678", fontsize=12, fontname="china-s")
        pg.insert_text((60, 180), "正文保留这一行。", fontsize=12, fontname="china-s")
        p.save(os.path.join(d, "样本.pdf")); p.close()
    return d


# ---------------------------------------------------------------- 各项自检
def check_basics(d):
    section("1. 依赖与基础工具")
    for mod, tip in [("docx", "python-docx"), ("openpyxl", "openpyxl"), ("PyPDF2", "PyPDF2")]:
        rec(f"依赖 {tip}", have(mod), "" if have(mod) else "pip install " + tip)
    rec("可选依赖 pymupdf（转图/页码/水印/打码）", have("pymupdf"), "" if have("pymupdf") else "pip install pymupdf")
    rc, out = run("setup_check.py", "check")
    rec("setup_check.py check 可执行", rc == 0, out.strip().splitlines()[-1] if out.strip() else "")


def check_xlsx(d):
    section("2. Excel 基础（xlsx_tool.py）")
    src = os.path.join(d, "表.xlsx")
    rc, out = run("xlsx_tool.py", "read", src)
    rec("read 读取", rc == 0 and "姓名" in out)
    rc, out = run("xlsx_tool.py", "stats", src, "-col", "销售额")
    rec("stats 统计", rc == 0 and "合计" in out)
    rc, out = run("xlsx_tool.py", "report", src, "-o", os.path.join(d, "报表.xlsx"), "-sum", "销售额")
    rec("report 报表", rc == 0 and os.path.exists(os.path.join(d, "报表.xlsx")))
    rc, out = run("xlsx_tool.py", "merge", src, src, "-o", os.path.join(d, "合并.xlsx"))
    rec("merge 合并", rc == 0 and os.path.exists(os.path.join(d, "合并.xlsx")))


def check_xlsx_pro(d):
    section("3. Excel 增强（xlsx_pro.py）—— v1.6.0 新增")
    from openpyxl import load_workbook
    src = os.path.join(d, "表.xlsx")

    # sort：降序 + 公式引用必须跟着行走（v1.6.0 修过的严重 bug）
    p = os.path.join(d, "排序.xlsx")
    rc, out = run("xlsx_pro.py", "sort", src, "-o", p, "-col", "销售额", "-desc")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        ws = load_workbook(p).active
        vals = [ws.cell(row=r, column=2).value for r in range(2, 6)]
        ok = vals == [200000, 100000, 50000, 30000]
        rec("sort 降序正确", ok, str(vals))
        bad = []
        for r in range(2, 6):
            f = ws.cell(row=r, column=5).value
            if f != f"=ROUND(B{r}/C{r}*100,1)":
                bad.append(f"{r}:{f}")
        rec("sort 后公式相对引用未错位", not bad, "；".join(bad) if bad else "")
    else:
        rec("sort 降序正确", False, out[-200:])
        rec("sort 后公式相对引用未错位", False, "未产出")

    # filter：表头必须保留（v1.6.0 修过的 bug）
    p = os.path.join(d, "筛选.xlsx")
    rc, out = run("xlsx_pro.py", "filter", src, "-o", p, "-col", "销售额", "-op", "ge", "-value", "60000")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        ws = load_workbook(p).active
        hdr = [c.value for c in ws[1]]
        rec("filter 表头保留", hdr[0] == "姓名", str(hdr[:3]))
        rec("filter 命中行数正确", ws.max_row == 3, f"max_row={ws.max_row}")
    else:
        rec("filter 表头保留", False, out[-200:]); rec("filter 命中行数正确", False)

    # filter：零命中必须报错且不动原文件
    p2 = os.path.join(d, "空结果.xlsx")
    rc, out = run("xlsx_pro.py", "filter", src, "-o", p2, "-col", "销售额", "-op", "gt", "-value", "999999999")
    rec("filter 零命中报错且不产出空文件", rc != 0 and not os.path.exists(p2))

    # 公式列的 sort / filter：不得静默按公式文本乱排、也不得只说"没有匹配行"
    # （WorkBuddy 真机自检抓出的两个问题）
    p = os.path.join(d, "公式列排序.xlsx")
    rc, out = run("xlsx_pro.py", "sort", src, "-o", p, "-col", "达成率", "-desc")
    rec("sort 遇到公式列会提示按缓存值排序", rc == 0 and "公式" in out and "缓存值" in out,
        out.strip().splitlines()[0][:70] if out.strip() else "")
    p = os.path.join(d, "公式列筛选.xlsx")
    rc, out = run("xlsx_pro.py", "filter", src, "-o", p, "-col", "达成率", "-op", "ge", "-value", "100")
    rec("filter 遇到全公式列会说明真实原因", rc != 0 and ("从未计算过" in out or "缓存值" in out),
        out.strip().splitlines()[-1][:70] if out.strip() else "")

    # formula：活公式写入
    p = os.path.join(d, "活公式.xlsx")
    rc, out = run("xlsx_pro.py", "formula", src, "-o", p, "-col", "达成率2", "-tpl", "=ROUND({销售额}/{目标}*100,1)")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        ws = load_workbook(p).active
        f = ws.cell(row=2, column=ws.max_column).value
        rec("formula 写入活公式", f == "=ROUND(B2/C2*100,1)", str(f))
    else:
        rec("formula 写入活公式", False, out[-200:])

    # chart：auto 选择 + 图表对象存在
    p = os.path.join(d, "图表.xlsx")
    rc, out = run("xlsx_pro.py", "chart", src, "-o", p, "-x", "姓名", "-y", "销售额", "-kind", "auto")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        ws = load_workbook(p).active
        rec("chart 图表已嵌入", len(ws._charts) == 1, f"charts={len(ws._charts)}")
        # 规则：≤8 个数据点且 ≤6 个分类 → 饼图；明细 >30 行 → 折线；其余柱状
        rec("chart auto 按规则选型（4 分类汇总 → 饼图）", "饼图" in out,
            out.strip().splitlines()[-1].strip()[:60] if out.strip() else "")
    else:
        rec("chart 图表已嵌入", False, out[-200:]); rec("chart auto 按规则选型（4 分类汇总 → 饼图）", False)

    # health 只验证本地提取并进入付费入口，不在发行端输出诊断结论。
    p = os.path.join(d, "健康.xlsx")
    run("xlsx_pro.py", "formula", src, "-o", p, "-col", "达成率3", "-tpl", "=ROUND({销售额}/{目标}*100,1)")
    from prepare_audit import build_payload
    payload = build_payload(p)
    rec("付费体检输入提取 Excel 行数、公式和列样例",
        payload.get("kind") == "xlsx" and payload.get("rows") == 5
        and payload.get("sampled_rows") == 5 and bool(payload.get("formulas"))
        and len(payload.get("headers", [])[3].get("sample", [])) == 4
        and all(isinstance(v, (int, float)) for v in payload.get("headers", [])[3].get("sample", [])),
        f"rows={payload.get('rows')} formulas={len(payload.get('formulas', []))}")
    rec("发行端提取 payload 不包含本地检查结论", not ({"verdict", "issues", "diagnosis"} & set(payload)))

    # protect：编号列转文本，且**不能破坏公式**（自检实测过的坑）
    p = os.path.join(d, "保护.xlsx")
    rc, out = run("xlsx_pro.py", "protect", src, "-o", p, "-cols", "身份证号")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        ws2 = load_workbook(p).active
        c = ws2.cell(row=2, column=4)
        rec("protect 编号列转文本", c.number_format == "@" and isinstance(c.value, str), f"{c.value!r}")
        f = ws2.cell(row=2, column=5).value
        rec("protect 不会把公式转成文本", isinstance(f, str) and f.startswith("="), str(f))
    else:
        rec("protect 编号列转文本", False, out[-200:]); rec("protect 不会把公式转成文本", False)


def check_word(d):
    section("4. Word（docx_tool.py / word_advanced.py）")
    from docx import Document
    src = os.path.join(d, "方案.docx")
    rc, out = run("docx_tool.py", "create", os.path.join(d, "生成.docx"), "-title", "T", "-body", "正文")
    rec("docx_tool create 生成", rc == 0 and os.path.exists(os.path.join(d, "生成.docx")))
    rc, out = run("docx_tool.py", "totext", src, "-o", os.path.join(d, "方案.txt"))
    rec("docx_tool totext 转文本", rc == 0 and os.path.exists(os.path.join(d, "方案.txt")))

    rc, out = run("word_advanced.py", "outline", src)
    rec("word_advanced outline 读大纲", rc == 0 and "一、背景" in out)

    p = os.path.join(d, "目录.docx")
    rc, out = run("word_advanced.py", "toc", src, "-o", p)
    ok = rc == 0 and os.path.exists(p)
    if ok:
        xml = Document(p).element.xml
        rec("toc 插入 TOC 域", "TOC" in xml)
    else:
        rec("toc 插入 TOC 域", False, out[-200:])

    p = os.path.join(d, "页眉.docx")
    rc, out = run("word_advanced.py", "header", src, "-o", p, "-header", "内部资料", "-footer", "第 X 页 / 共 Y 页")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        doc = Document(p)
        h = doc.sections[0].header.paragraphs[0].text
        fx = doc.sections[0].footer.paragraphs[0]._p.xml
        rec("header 页眉写入", "内部资料" in h, h)
        rec("header 页脚 PAGE/NUMPAGES 域", "PAGE" in fx and "NUMPAGES" in fx)
    else:
        rec("header 页眉写入", False, out[-200:]); rec("header 页脚 PAGE/NUMPAGES 域", False)

    p = os.path.join(d, "转出来的.docx")
    rc, out = run("word_advanced.py", "md2docx", os.path.join(d, "说明.md"), "-o", p)
    ok = rc == 0 and os.path.exists(p)
    if ok:
        doc = Document(p)
        heads = [q.text for q in doc.paragraphs if q.style.name.startswith("Heading")]
        rec("md2docx 标题层级", "标题" in heads, str(heads[:3]))
        rec("md2docx 表格", len(doc.tables) == 1, f"tables={len(doc.tables)}")
    else:
        rec("md2docx 标题层级", False, out[-200:]); rec("md2docx 表格", False)


def check_pdf_real(d):
    section("5. PDF（pdf_tool.py / pdf_redact.py）")
    from PyPDF2 import PdfWriter, PdfReader
    src = os.path.join(d, "样本.pdf")
    if not os.path.exists(src):
        rec("PDF 素材生成", False, "pymupdf 不可用，跳过 PDF 项")
        return
    rc, out = run("pdf_tool.py", "info", src)
    rec("pdf_tool info", rc == 0 and "页" in out)
    rc, out = run("pdf_tool.py", "extract", src, "-o", os.path.join(d, "样本.txt"))
    rec("pdf_tool extract 提取文字", rc == 0 and os.path.exists(os.path.join(d, "样本.txt")))

    import pymupdf as fitz
    from prepare_audit import build_payload
    payload = build_payload(src)
    rec("付费体检输入提取 PDF 文字层", payload.get("kind") == "text"
        and "身份证" in payload.get("text", "") and "13812345678" in payload.get("text", ""))
    p = os.path.join(d, "脱敏.pdf")
    rc, out = run("pdf_redact.py", "redact", src, "-o", p, "--mode", "black")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        t = "".join(pg.get_text() for pg in fitz.open(p))
        rec("redact 文字层已删除敏感信息", "110101199003074512" not in t and "13812345678" not in t)
        rec("redact 保留正常正文", "正文保留" in t)
        rec("redact 生成打码清单", os.path.exists(os.path.join(d, "脱敏-打码清单.csv")))
    else:
        rec("redact 文字层已删除敏感信息", False, out[-200:])
        rec("redact 保留正常正文", False); rec("redact 生成打码清单", False)

    p = os.path.join(d, "水印.pdf")
    rc, out = run("pdf_redact.py", "watermark", src, "-o", p, "-text", "内部资料", "-mode", "diagonal")
    ok = rc == 0 and os.path.exists(p)
    if ok:
        t = "".join(pg.get_text() for pg in fitz.open(p))
        rec("watermark 中文水印写入（曾渲染成方块）", "内部资料" in t)
    else:
        rec("watermark 中文水印写入（曾渲染成方块）", False, out[-200:])


def check_templates(d):
    section("6. 模板（templates/gen_templates.py）")
    outdir = os.path.join(d, "模板")
    rc, out = run(os.path.join("..", "templates", "gen_templates.py"), "--dir", outdir)
    files = ["工作报告.docx", "月度预算.xlsx", "合同.docx", "简历.docx"]
    missing = [f for f in files if not os.path.exists(os.path.join(outdir, f))]
    rec("四个模板全部生成", rc == 0 and not missing, "缺：" + ",".join(missing) if missing else "")
    xp = os.path.join(outdir, "月度预算.xlsx")
    if os.path.exists(xp):
        from openpyxl import load_workbook
        v = str(load_workbook(xp)["汇总"].cell(row=2, column=2).value or "")
        rec("月度预算自带汇总公式", v.startswith("=SUM"), v)


def check_error_paths(d):
    section("7. 异常路径（报错要友好、不能崩）")
    missing = os.path.join(d, "根本没有这个文件.xlsx")
    rc, out = run("xlsx_tool.py", "read", missing)
    rec("文件不存在时给出中文提示并退出", rc != 0 and "不存在" in out)
    rc, out = run("xlsx_pro.py", "sort", os.path.join(d, "表.xlsx"), "-o", os.path.join(d, "x.xlsx"), "-col", "不存在的列")
    rec("列名不存在时提示改用哪些列", rc != 0 and ("可以改用这些列名" in out or "可用列" in out))
    rc, out = run("xlsx_pro.py", "formula", os.path.join(d, "表.xlsx"), "-o", os.path.join(d, "y.xlsx"),
                  "-col", "新列", "-tpl", "=SUM({不存在的列})")
    rec("公式引用不存在的列时报错", rc != 0 and ("不存在" in out or "可以改用这些列名" in out or "可用列" in out))


def check_regressions(d):
    """回归断言：2026-10-09 用**真实文件**（pandas / python-docx / pdf.js 官方语料）跑出来的缺陷。

    每一条都对应一个曾经真实发生的崩溃或静默错误，防止改回去。
    """
    section("8. 回归断言（真实文件测试抓出的缺陷）")
    from openpyxl import Workbook
    from docx import Document

    # ① 合并单元格：真实报表常见（pandas multiindex_no_index_names.xlsx 直接崩过）
    mp = os.path.join(d, "合并单元格表.xlsx")
    wb = Workbook(); ws = wb.active
    ws.append(["姓名", "销售额", "目标"])
    for row in [("甲", 100, 80), ("乙", 50, 60), ("丙", 300, 20)]:
        ws.append(list(row))
    ws.append(["合计", 450, 160])
    ws.merge_cells("A6:C6"); ws["A6"] = "备注：本表由系统生成"
    wb.save(mp)
    o = os.path.join(d, "排序-合并.xlsx")
    rc, out = run("xlsx_pro.py", "sort", mp, "-col", "销售额", "-desc", "-o", o)
    rec("① sort 遇合并单元格不崩且有产物（曾 AttributeError: MergedCell）",
        rc == 0 and os.path.exists(o) and "Traceback" not in out, out[-160:])

    # ①b 降序时空值必须仍在最后（曾因 reverse=True 把空值权重一起反转→空行排第一）
    ep = os.path.join(d, "含空值表.xlsx")
    wb = Workbook(); ws = wb.active
    ws.append(["名称", "数量"])
    ws.append(["甲", 10]); ws.append(["乙", None]); ws.append(["丙", 5])
    wb.save(ep)
    o1b = os.path.join(d, "排序-空值.xlsx")
    rc, out = run("xlsx_pro.py", "sort", ep, "-col", "数量", "-desc", "-o", o1b)
    ok1b = False
    if rc == 0 and os.path.exists(o1b):
        from openpyxl import load_workbook as _lw
        ws2 = _lw(o1b).active
        vals = [ws2.cell(r, 2).value for r in range(2, ws2.max_row + 1)]
        ok1b = vals[0] == 10 and vals[-1] is None
    rec("①b 降序排序时空值仍排在最后（曾排到第一行）", ok1b, f"降序结果={vals if 'vals' in dir() else '?'}")

    # ② 表头行上方有合并标题行：应自动探测表头行
    hp = os.path.join(d, "合并标题表.xlsx")
    wb = Workbook(); ws = wb.active
    ws.merge_cells("A1:B1"); ws["A1"] = "季度销售汇总"
    ws.append([])
    ws.append(["姓名", "销售额"])
    ws.append(["甲", 100]); ws.append(["乙", 50])
    wb.save(hp)
    o2 = os.path.join(d, "排序-标题行.xlsx")
    rc, out = run("xlsx_pro.py", "sort", hp, "-col", "销售额", "-desc", "-o", o2)
    rec("② 表头在合并标题行下方时能自动识别（曾把标题当表头→找不到列）",
        rc == 0 and os.path.exists(o2), out[-160:])

    # ③ 数字表头：单元格是数字 1.0，命令行传 '1.0' 必须能对上
    np_ = os.path.join(d, "数字表头.xlsx")
    wb = Workbook(); ws = wb.active
    for v in (1.0, 2.0, 3.0):
        ws.append([v])
    wb.save(np_)
    rc, out = run("xlsx_tool.py", "stats", np_, "-col", "1.0")
    rec("③ 数字表头可用 -col 1.0 匹配（曾报『找不到列 1.0，可用列 [1.0]』）",
        rc == 0 and "数值" in out, out[-160:])

    # ④ 失败必须非零退出（曾 7/15 场景 rc=0，Agent 会误报成功）
    txt = os.path.join(d, "不是PDF.txt")
    with open(txt, "w", encoding="utf-8") as f:
        f.write("这不是 PDF\n")
    bad_rc = []
    for name, args in [
        ("stats 列不存在", ("xlsx_tool.py", "stats", os.path.join(d, "表.xlsx"), "-col", "没有这一列")),
        ("report 列不存在", ("xlsx_tool.py", "report", os.path.join(d, "表.xlsx"), "-o", os.path.join(d, "r.xlsx"), "-cols", "没有")),
        ("merge 含非 Excel", ("xlsx_tool.py", "merge", os.path.join(d, "表.xlsx"), txt, "-o", os.path.join(d, "m.xlsx"))),
        ("convert_legacy 不支持格式", ("convert_legacy.py", txt)),
        ("pdf_redact 非 PDF", ("pdf_redact.py", "scan", txt)),
    ]:
        rc, out = run(*args)
        if rc == 0:
            bad_rc.append(name)
    rec("④ 失败路径退出码非零（曾 stats/report/merge/convert_legacy 都返回 0）",
        not bad_rc, "仍返回 0：" + "、".join(bad_rc))

    # ⑤ 非 PDF 输入：中文提示且不抛英文堆栈（曾 ValueError: is no PDF）
    rc, out = run("pdf_redact.py", "redact", txt, "-o", os.path.join(d, "o.pdf"))
    rec("⑤ 非 PDF 输入给中文提示（曾抛 ValueError: is no PDF 堆栈）",
        rc != 0 and "不是 PDF" in out and "Traceback" not in out, out[-200:])

    # ⑥ 缺 Heading 样式的 docx：toc 不崩（python-docx 官方语料真实触发）
    dp = os.path.join(d, "无标题样式.docx")
    doc = Document(); doc.add_paragraph("只有正文，没有标题样式。")
    for st in list(doc.styles):
        if (st.name or "").startswith("Heading"):
            try:
                st.delete()
            except Exception:
                pass
    doc.save(dp)
    o6 = os.path.join(d, "目录-无样式.docx")
    rc, out = run("word_advanced.py", "toc", dp, "-o", o6)
    rec("⑥ 文档缺 Heading 样式时 toc 不崩（曾 KeyError: no style with name 'Heading 1'）",
        rc == 0 and os.path.exists(o6) and "Traceback" not in out, out[-200:])

    # ⑦ 付费脚本必须把官方 CLI 的收银台输出转发出来
    paid = os.path.join(ROOT, "scripts", "office-doc-suite-paid.mjs")
    src = open(paid, encoding="utf-8", errors="replace").read() if os.path.exists(paid) else ""
    rec("⑦ pay 转发官方 CLI 输出（否则支付链接/二维码到不了用户）",
        "process.stdout.write(r.stdout" in src and "e.stdout" in src)

    # ⑧ 默认 locale 下输出必须是 UTF-8（曾在中文 Windows 上按 GBK 输出→Agent 乱码）
    env_plain = {k: v for k, v in os.environ.items() if k not in ("PYTHONIOENCODING", "PYTHONUTF8")}
    r = subprocess.run([PY, os.path.join(HERE, "convert_legacy.py")], capture_output=True, env=env_plain)
    raw = (r.stdout or b"") + (r.stderr or b"")
    try:
        raw.decode("utf-8")
        enc_ok = True
    except UnicodeDecodeError:
        enc_ok = False
    rec("⑧ convert_legacy 默认输出为 UTF-8（曾用裸 print 绕过 _msg→GBK 乱码）", enc_ok)


def check_real_samples():
    """真实文件用例：语料库存在时，用真实文档跑一遍核心链路（不存在则跳过并说明）。"""
    section("9. 真实文件用例（可选）")
    root = os.environ.get("ODS_REAL_SAMPLES", r"D:\2\1\real-samples")
    if not os.path.isdir(root):
        print(f"  ⏭ 未找到真实文件语料库（{root}）——设 ODS_REAL_SAMPLES 指向语料目录即可启用")
        return
    xs = sorted(f for f in os.listdir(root) if f.endswith(".xlsx"))
    dx = sorted(f for f in os.listdir(root) if f.endswith(".docx"))
    pf = sorted(f for f in os.listdir(root) if f.endswith(".pdf"))
    if not (xs or dx or pf):
        print(f"  ⏭ 语料库里没有文件（{root}）")
        return
    outd = tempfile.mkdtemp(prefix="ods-real-")
    fails = []
    for f in xs:
        p = os.path.join(root, f)
        try:
            from prepare_audit import build_payload
            payload = build_payload(p)
            if payload.get("kind") != "xlsx":
                fails.append(f"extract:{f}")
        except Exception:
            fails.append(f"extract:{f}")
    for f in dx:
        p = os.path.join(root, f)
        rc, out = run("word_advanced.py", "outline", p)
        if "Traceback" in out:
            fails.append(f"outline:{f}")
    for f in pf:
        p = os.path.join(root, f)
        rc, out = run("pdf_tool.py", "info", p)
        if rc != 0 or "Traceback" in out:
            fails.append(f"info:{f}")
    rec(f"真实文件本地提取（xlsx {len(xs)} / docx {len(dx)} / pdf {len(pf)} 个）",
        not fails, "失败：" + "、".join(fails[:5]))
    shutil.rmtree(outd, ignore_errors=True)


def check_zero_dep_and_codes(d):
    """第 10 节：零依赖降级模式 + 错误 ID 一致性（2026-10-09 按竞品对比新增）。"""
    section("10. 零依赖模式与错误 ID")

    # ① 错误 ID 注册表可查询、编号齐全
    rc, out = run("error_codes.py", "--codes")
    codes = [c.strip() for c in out.splitlines() if c.strip().startswith("ODS-E")]
    rec(f"错误 ID 注册表可用（{len(codes)} 个编号）", rc == 0 and len(codes) >= 17, f"rc={rc} 数量={len(codes)}")
    bad = []
    for c in codes[:6]:                      # 抽样查解释（不用全查，省时间）
        rc2, out2 = run("error_codes.py", c)
        if rc2 != 0 or "含义:" not in out2:
            bad.append(c)
    rc3, _ = run("error_codes.py", "ODS-E99")
    rec("错误 ID 可单项查询、未知编号非零退出", not bad and rc3 != 0, f"失败项={bad}")

    # ② 文档与注册表同步：每个编号都要出现在 SKILL.md 里
    skill_md = os.path.join(ROOT, "SKILL.md")
    if os.path.exists(skill_md):
        text = open(skill_md, encoding="utf-8", errors="replace").read()
        missing = [c for c in codes if c not in text]
        rec("SKILL.md「错误 ID 一览」与注册表同步", not missing, "缺失: " + ",".join(missing))
    else:
        rec("SKILL.md 存在", False)

    # ③ 主脚本失败要带编号
    rc, out = run("xlsx_pro.py", "sort", os.path.join(d, "表.xlsx"), "-o", os.path.join(d, "e.xlsx"), "-col", "没有这列")
    rec("列名错误带编号 ODS-E03", "[ODS-E03]" in out, out.strip()[-80:])
    rc, out = run("xlsx_tool.py", "stats", os.path.join(d, "没有这个表.xlsx"), "-col", "x")
    rec("文件不存在带编号 ODS-E01", "[ODS-E01]" in out, out.strip()[-80:])

    # ④ 零依赖模式：不装任何第三方库也能读 docx/xlsx
    rc, out = run("no_dep.py", "check")
    rec("no_dep check 可用", rc == 0 and "零依赖可用" in out, out.strip()[-60:])
    rc, out = run("no_dep.py", "docx-text", os.path.join(d, "方案.docx"))
    rec("零依赖读 Word 正文", rc == 0 and "测试方案" in out, out.strip()[:60])
    csv_out = os.path.join(d, "nodep.csv")
    rc, out = run("no_dep.py", "xlsx-csv", os.path.join(d, "表.xlsx"), "-o", csv_out)
    ok = rc == 0 and os.path.exists(csv_out)
    if ok:
        content = open(csv_out, encoding="utf-8-sig", errors="replace").read()
        ok = "销售额" in content and "姓名" in content
    rec("零依赖导 Excel 为 CSV（中文不乱码）", ok, out.strip()[-60:])
    rc, out = run("no_dep.py", "xlsx-sheets", os.path.join(d, "表.xlsx"))
    rec("零依赖列出工作表", rc == 0 and "工作表" in out, out.strip()[:60])

    # ⑤ 零依赖模式的错误也要带编号
    txt = os.path.join(d, "不是pdf.txt")
    with open(txt, "w", encoding="utf-8") as f:
        f.write("x")
    rc, out = run("no_dep.py", "pdf-info", txt)
    rec("零依赖：非 PDF 带编号 ODS-E05", rc != 0 and "[ODS-E05]" in out, out.strip()[-80:])
    rc, out = run("no_dep.py", "docx-text", os.path.join(d, "根本没有.docx"))
    rec("零依赖：文件不存在带编号 ODS-E01", rc != 0 and "[ODS-E01]" in out, out.strip()[-80:])


def check_new_capabilities(d):
    """第 11 节：扫描件通道（ocr_helper）+ 本地体检输入提取。"""
    section("11. 扫描件通道与付费体检输入")

    rc, out = run("ocr_helper.py", "check")
    rec("ocr_helper check 可用（通道 A 始终可用）", rc == 0 and "通道 A" in out, out.strip()[:70])

    # 用自检素材里的 PDF 渲染页面（有 pymupdf 才做）
    if have("pymupdf"):
        pdf = os.path.join(d, "样本.pdf")
        outdir = os.path.join(d, "ocr_pages")
        rc, out = run("ocr_helper.py", "render", pdf, "-o", outdir, "-dpi", "90")
        pngs = [f for f in os.listdir(outdir)] if os.path.isdir(outdir) else []
        rec("扫描件渲染成图片（交给 AI 视觉读）", rc == 0 and any(f.endswith(".png") for f in pngs), f"产出={pngs[:3]}")
        rc, out = run("ocr_helper.py", "read", pdf, "-o", os.path.join(d, "ocr.txt"))
        rec("无 OCR 程序时给渲染引导 + 编号 ODS-E06", "[ODS-E06]" in out, out.strip()[:80])
    else:
        print("  ⏭ 缺 pymupdf，跳过渲染相关项")

    from prepare_audit import build_payload
    from docx import Document
    from openpyxl import Workbook
    import checkup_report
    import shutil as _shutil

    # 只用三个临时有效样本验证目录去重与批量提取，避免碰到 10 文件上限。
    batch_dir = os.path.join(d, "paid-inputs")
    os.makedirs(batch_dir, exist_ok=True)
    _shutil.copy2(os.path.join(d, "表.xlsx"), os.path.join(batch_dir, "表.xlsx"))
    _shutil.copy2(os.path.join(d, "方案.docx"), os.path.join(batch_dir, "方案.docx"))
    if os.path.exists(os.path.join(d, "样本.pdf")):
        _shutil.copy2(os.path.join(d, "样本.pdf"), os.path.join(batch_dir, "样本.pdf"))
    files_once = build_payload([batch_dir])
    files_twice = build_payload([batch_dir, batch_dir])
    count_once = len(files_once.get("documents", [])) if files_once.get("kind") == "batch" else 1
    count_twice = len(files_twice.get("documents", [])) if files_twice.get("kind") == "batch" else 1
    rec("输入目录重复传入时去重并成功提取", count_once == count_twice and count_once >= 2,
        f"一次={count_once} 重复={count_twice}")

    # 验证薄 CLI 保留旧参数并把收集后的文件/工作表交给 helper；mock 阻止 probe 联网。
    captured = {}
    old_runner = checkup_report.run_paid_audit
    def fake_runner(paths, sheet=""):
        captured["paths"] = paths
        captured["sheet"] = sheet
        return 0
    checkup_report.run_paid_audit = fake_runner
    try:
        marker = os.path.join(d, "must-not-be-created.md")
        rc = checkup_report.main([batch_dir, "-o", marker, "-pdf", "-json", os.path.join(d, "never.json"), "-sheet", "Data"])
    finally:
        checkup_report.run_paid_audit = old_runner
    rec("checkup_report 兼容旧参数并仅转交输入", rc == 0 and len(captured.get("paths", [])) == count_once
        and captured.get("sheet") == "Data" and not os.path.exists(marker))

    empty_dir = os.path.join(d, "empty-input")
    os.makedirs(empty_dir, exist_ok=True)
    try:
        build_payload(empty_dir)
        empty_fails = False
    except ValueError:
        empty_fails = True
    rec("空目录作为体检输入失败", empty_fails)

    too_many = os.path.join(d, "too-many-inputs")
    os.makedirs(too_many, exist_ok=True)
    for i in range(11):
        open(os.path.join(too_many, f"{i}.xlsx"), "wb").close()
    try:
        build_payload(too_many)
        limit_fails = False
    except ValueError as exc:
        limit_fails = "最多 10" in str(exc)
    rec("体检输入超过十个文件明确失败", limit_fails)

    fake_pdf = os.path.join(d, "invalid-input.pdf")
    with open(fake_pdf, "w", encoding="utf-8") as fh:
        fh.write("not a PDF")
    fake_report = os.path.join(d, "fake-report.md")
    rc, out = run("checkup_report.py", fake_pdf, "-o", fake_report)
    rec("伪 PDF 提取失败且不生成报告", rc != 0 and not os.path.exists(fake_report)
        and "ODS-E13" in out and "Traceback" not in out, out.strip()[-90:])

    rc, out = run("checkup_report.py", os.path.join(d, "根本没有这个目录"))
    rec("不存在路径带中文错误并非零退出", rc != 0 and "ODS-E13" in out and "Traceback" not in out)


def check_frontmatter(d):
    """第 12 节：SKILL.md 前置块（给平台/助手读的配置）不能写坏。

    背景：这段是机器读的——缩进错、值后面粘注释、缺 pricing，平台审核和助手识别都会出问题，
    而人在编辑器里看不出来（2026-10-09 加注释时踩过）。
    """
    section("12. SKILL.md 前置块（机器读的配置）")
    skill = os.path.join(ROOT, "SKILL.md")
    text = open(skill, encoding="utf-8").read()
    m = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n", text, re.S)
    rec("前置块格式正确（以 --- 开头/结束）", bool(m))
    if not m:
        return
    fm = m.group(1)

    # ① 顶层字段齐全
    need = ("name", "slug", "displayName", "version", "description", "triggers", "pricing", "metadata")
    got = set(re.findall(r"^([A-Za-z_]+):", fm, re.M))
    missing = [k for k in need if k not in got]
    rec("身份/触发词/计费/依赖 字段齐全", not missing, "缺：" + ",".join(missing))

    # ② 版本与 _meta.json 一致
    meta_p = os.path.join(ROOT, "_meta.json")
    ok_ver = True
    if os.path.exists(meta_p):
        import json as _json
        mv = _json.load(open(meta_p, encoding="utf-8")).get("version")
        vm = re.search(r"^version:\s*(\S+)\s*$", fm, re.M)
        ok_ver = bool(vm) and vm.group(1) == mv
        rec("SKILL.md 与 _meta.json 版本一致", ok_ver, f"SKILL={vm.group(1) if vm else '?'} meta={mv}")
    else:
        rec("_meta.json 存在", False)

    # ③ 机器字段的值后面不能挂注释（简易解析器会把注释当值）
    bad = [ln for ln in fm.splitlines()
           if re.match(r"^[A-Za-z_]+:", ln) and "#" in ln.split(":", 1)[1]
           and not ln.split(":", 1)[1].strip().startswith("[")]
    rec("机器字段的值后面没有粘注释", not bad, "；".join(b[:40] for b in bad))

    # ④ 计费三要素 + 买家侧依赖
    ok_money = bool(re.search(r"^\s+amount_fen:\s*99\s*$", fm, re.M)) and bool(re.search(r"^\s+currency:\s*CNY\s*$", fm, re.M))
    rec("计费声明完整（amount_fen=99 / currency=CNY）", ok_money)
    rec("买家侧依赖声明完整（alipay-bot + agent-payment）",
        "alipay-bot" in fm and "@alipay/agent-payment" in fm)

    # SKILL 的收费路由有独立门控测试；这里仅验证 frontmatter 结构。


def check_robustness_regressions(d):
    """第 13 节：真实文件"攻击性测试"抓到的健壮性缺陷（逐条锁住）。

    背景（2026-10-09）：对 28 项恶劣输入做探测，查出两个真 bug——
    ① 同一个目录传两次 → 文件未去重（64 个算成 128 个）；
    ② 根本不是 PDF 的伪装文件被标成"未发现敏感信息"（用户会以为可以交付）。
    """
    section("13. 健壮性回归（攻击性输入）")

    # ① 伪装成 .pdf 的非 PDF 必须失败，且不能产出本地报告。
    fake = os.path.join(d, "fake.pdf")
    with open(fake, "w", encoding="utf-8") as fh:
        fh.write("这不是 PDF")
    rep2 = os.path.join(d, "fake.md")
    rc_fake, out_fake = run("checkup_report.py", fake, "-o", rep2)
    rec("伪 PDF 输入提取失败且不生成报告", rc_fake != 0 and not os.path.exists(rep2)
        and "ODS-E13" in out_fake and "Traceback" not in out_fake, out_fake.strip()[-80:])

    # ③ 目录传给单文件脚本 → 中文提示，不甩英文 errno
    rc3, out3 = run("word_advanced.py", "outline", d)
    rec("目录传给 Word 脚本给中文提示", rc3 != 0 and "目录" in out3 and "Errno" not in out3, out3.strip()[:60])
    rc4, out4 = run("xlsx_pro.py", "health", d)
    rec("目录传给 Excel health 给中文提示", rc4 != 0 and "目录" in out4 and "Errno" not in out4, out4.strip()[:60])
    rc5, out5 = run("xlsx_pro.py", "health", os.path.join(d, "样本.pdf"))
    rec("非 XLSX 输入被 health 拒绝并带编号", rc5 != 0 and "ODS-E13" in out5)
    rc6, out6 = run("pdf_redact.py", "scan", d)
    rec("目录传给 PDF scan 被拒绝并带编号", rc6 != 0 and "ODS-E13" in out6)
    rc7, out7 = run("pdf_redact.py", "scan", os.path.join(d, "表.xlsx"))
    rec("非 PDF 输入被 scan 拒绝并带编号", rc7 != 0 and "ODS-E13" in out7)

    # ④ 文件不存在/格式不支持 → 必须带错误编号
    rc5, out5 = run("convert_legacy.py", os.path.join(d, "nope.abc"))
    rec("不存在/不支持的文件带 ODS 编号", rc5 != 0 and "ODS-E" in out5, out5.strip()[:60])


def check_third_batch_regressions(d):
    """第 14 节：第三批真实文件（pdf.js 截断 PDF、pandas 空表）抓到的两个问题。

    ① 711 字节的截断 PDF（无 %%EOF）：PyPDF2 报 `EOF marker not found` 直接失败，
       而 pymupdf 能打开并修复 → 只读的信息/取字应当兜底，不该整体失败。
    ② 空工作表：原来只会说「找不到列 'A'，可用列: []」，用户看不懂。
    """
    section("14. 第三批真实文件回归（截断 PDF / 空表）")

    # ① 截断 PDF（去掉 %%EOF 标记）
    if have("pymupdf"):
        import pymupdf
        src = os.path.join(d, "trunc-base.pdf")
        doc = pymupdf.open()
        page = doc.new_page()
        page.insert_text((72, 72), "test", fontname="china-s")
        doc.save(src)
        doc.close()
        raw = open(src, "rb").read()
        cut = raw.replace(b"%%EOF", b"", 1) if b"%%EOF" in raw else raw[:-20]
        trunc = os.path.join(d, "trunc-cut.pdf")
        with open(trunc, "wb") as fh:
            fh.write(cut)
        rc, out = run("pdf_tool.py", "info", trunc)
        rec("截断 PDF 仍能看信息（pymupdf 兜底）", rc == 0 and "页数" in out,
            " | ".join(out.strip().splitlines()[:2]))
        rc2, out2 = run("pdf_tool.py", "extract", trunc, "-o", os.path.join(d, "trunc.txt"))
        rec("截断 PDF 仍能取字", rc2 == 0 and os.path.exists(os.path.join(d, "trunc.txt")),
            " | ".join(out2.strip().splitlines()[:1]))
    else:
        print("  ⏭ 缺 pymupdf，跳过截断 PDF 项")

    # ② 空工作表提示
    if have("openpyxl"):
        import openpyxl
        empty = os.path.join(d, "empty-book.xlsx")
        wb = openpyxl.Workbook()
        wb.save(empty)
        rc, out = run("xlsx_tool.py", "stats", empty, "-col", "A")
        rec("空表提示为「没有任何表头」（不是「可用列: []」）",
            rc != 0 and "没有任何表头" in out and "可用列: []" not in out,
            " | ".join(out.strip().splitlines()[:1]))
        rc2, out2 = run("xlsx_tool.py", "report", empty, "-o", os.path.join(d, "empty-report.xlsx"), "-cols", "A")
        rec("空表出报表也给「没有任何表头」提示", rc2 != 0 and "没有任何表头" in out2,
            " | ".join(out2.strip().splitlines()[:1]))
    else:
        print("  ⏭ 缺 openpyxl，跳过空表项")


def main():
    ap = argparse.ArgumentParser(description="功能自检")
    ap.add_argument("--quick", action="store_true", help="跳过需要 pymupdf 的项")
    ap.add_argument("--keep", action="store_true", help="保留临时目录")
    a = ap.parse_args()

    print("=" * 64)
    print("office-doc-suite 功能自检" + ("（快速模式）" if a.quick else ""))
    print("=" * 64)

    d = tempfile.mkdtemp(prefix="ods-selftest-")
    try:
        make_materials(d)
        check_basics(d)
        check_xlsx(d)
        check_xlsx_pro(d)
        check_word(d)
        if a.quick or not have("pymupdf"):
            section("5. PDF")
            print("  ⏭ 已跳过（--quick 或缺 pymupdf）")
        else:
            check_pdf_real(d)
        check_templates(d)
        check_error_paths(d)
        check_regressions(d)
        check_zero_dep_and_codes(d)
        check_new_capabilities(d)
        check_robustness_regressions(d)
        check_third_batch_regressions(d)
        check_frontmatter(d)
        check_real_samples()
    finally:
        if not a.keep:
            shutil.rmtree(d, ignore_errors=True)
        else:
            print(f"\n临时产物保留在：{d}")

    total = len(RESULTS)
    bad = [r for r in RESULTS if not r[1]]
    print("\n" + "=" * 64)
    print(f"结果：{total - len(bad)}/{total} 通过")
    if bad:
        print("失败项：")
        for n, _, det in bad:
            print(f"  ❌ {n}" + (f" | {det}" if det else ""))
        print("\n先跑 python scripts/setup_check.py check 排除依赖问题，再对照 SKILL.md「异常处理」表排查。")
        sys.exit(1)
    print("全部通过 ✅ 可以放心使用")
    sys.exit(0)


if __name__ == "__main__":
    main()
