#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prepare local document input and hand it to the paid audit probe."""

import json
import subprocess
import sys
import tempfile
from pathlib import Path

from prepare_audit import build_payload


HERE = Path(__file__).resolve().parent
PAID_CLI = HERE / "office-doc-suite-paid.mjs"


def run_paid_audit(paths, sheet=""):
    """Extract locally, then invoke probe only; payment is always user initiated."""
    summary_path = None
    try:
        payload = build_payload(paths, sheet=sheet)
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".json", prefix="ods-paid-audit-", delete=False
        ) as summary:
            json.dump(payload, summary, ensure_ascii=False)
            summary_path = Path(summary.name)
        result = subprocess.run(
            ["node", str(PAID_CLI), "probe", "--summary", str(summary_path)],
            check=False,
        )
        return result.returncode
    except Exception as exc:
        print(f"错误 [ODS-E13] 付费体检输入准备失败：{exc}", file=sys.stderr)
        return 1
    finally:
        if summary_path is not None:
            try:
                summary_path.unlink(missing_ok=True)
            except OSError:
                print("清理临时摘要失败", file=sys.stderr)
