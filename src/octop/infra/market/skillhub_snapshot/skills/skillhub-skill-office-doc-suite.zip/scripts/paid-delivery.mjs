// Accept only the merchant's fulfilled resource envelope, never CLI progress text.
export function requireDelivery(raw, orderNo) {
  const text = String(raw || '');
  const candidates = [text.trim()];
  for (let i = text.indexOf('{'); i >= 0; i = text.indexOf('{', i + 1)) {
    let depth = 0, quoted = false, escaped = false;
    for (let j = i; j < text.length; j++) {
      const c = text[j];
      if (quoted) { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if (c === '"') quoted = false; continue; }
      if (c === '"') quoted = true;
      else if (c === '{') depth++;
      else if (c === '}' && --depth === 0) { candidates.push(text.slice(i, j + 1)); break; }
    }
  }
  const nested = (value, depth = 0) => {
    if (depth > 8 || value === null) return [];
    if (typeof value === 'string') {
      try { return nested(JSON.parse(value), depth + 1); } catch { return []; }
    }
    if (typeof value !== 'object') return [];
    return [value, ...Object.values(value).flatMap(v => nested(v, depth + 1))];
  };
  for (const candidate of candidates) {
    let value; try { value = JSON.parse(candidate); } catch { continue; }
    for (const envelope of nested(value)) {
      if (envelope?.resource_id === '/severance-arb/api/call/office-doc-suite' && envelope.out_trade_no === orderNo &&
          envelope.fulfillment_confirmed === true && envelope.content?.status === 'success' &&
          typeof envelope.content.report_markdown === 'string' && envelope.content.report_markdown.trim())
        return envelope;
    }
  }
  throw new Error('尚未收到本订单的已验付履约报告；不生成凭证，请核对支付状态后重试');
}
