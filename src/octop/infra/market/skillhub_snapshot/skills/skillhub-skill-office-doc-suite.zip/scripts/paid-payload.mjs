/* Privacy-preserving request payload builders for paid document checks. */

const REDACT_RULES = [
  ['身份证', /(?<![0-9Xx])[1-9][0-9]{5}(?:19|20)[0-9]{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12][0-9]|3[01])[0-9]{3}[0-9Xx](?![0-9Xx])/g, '[身份证号已脱敏]'],
  ['邮箱', /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[邮箱已脱敏]'],
  ['手机号', /(?<![0-9])1[3-9][0-9]{9}(?![0-9])/g, '[手机号已脱敏]'],
  ['银行卡', /(?<![0-9])[0-9]{16,19}(?![0-9])/g, '[银行卡号已脱敏]'],
];

/** Replace sensitive values locally and retain only masked type/location evidence. */
export function redact(text) {
  const src = String(text ?? '');
  const raw = [];
  for (const [type, re, replacement] of REDACT_RULES) {
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(src)) !== null) {
      raw.push({ start: m.index, end: m.index + m[0].length, type, replacement, value: m[0] });
      if (!m[0].length) re.lastIndex += 1;
    }
  }
  const priority = new Map(REDACT_RULES.map(([type], i) => [type, i]));
  raw.sort((a, b) => (a.start - b.start) || (priority.get(a.type) - priority.get(b.type)));
  const selected = [];
  let lastEnd = -1;
  for (const hit of raw) {
    if (hit.start < lastEnd) continue;
    selected.push(hit);
    lastEnd = hit.end;
  }
  let cursor = 0;
  let out = '';
  for (const hit of selected) {
    out += src.slice(cursor, hit.start) + hit.replacement;
    cursor = hit.end;
  }
  out += src.slice(cursor);
  const hits = selected.map((h) => ({
    type: h.type,
    masked: h.value.length >= 6 ? `${h.value.slice(0, 3)}****${h.value.slice(-2)}` : '***',
    index: h.start,
  }));
  return { text: out, count: hits.length, hits };
}

/** Whitelist the data the server needs; raw cell examples and cached values never leave the device. */
export function buildSafeXlsxSummary(input = {}) {
  const redactedHits = [];
  const redactField = (value, where) => {
    const r = redact(value);
    redactedHits.push(...r.hits.map((h) => ({ ...h, index: -1, where })));
    return r.text;
  };
  const safeSample = (value, where) => {
    if (typeof value === 'number' && Number.isFinite(value)) {
      redactField(String(value), where);
      return {
        kind: 'number',
        digitCount: String(Math.trunc(Math.abs(value))).length,
        startsWithZero: false,
      };
    }
    if (typeof value === 'string') {
      redactField(value, where);
      return { kind: 'string' };
    }
    if (value === null || value === undefined) return null;
    return { kind: typeof value };
  };

  const formulas = Array.isArray(input.formulas) ? input.formulas.map((f, i) => ({
    cell: /^[A-Z]{1,3}[1-9][0-9]{0,7}$/.test(String(f?.cell || '')) ? String(f.cell) : '',
    formula: typeof f?.formula === 'string' && f.formula.startsWith('=')
      ? redactField(f.formula, `公式${i + 1}`)
      : '',
    cached: f?.cached === null || f?.cached === undefined ? null : '[有缓存值]',
  })) : [];
  const headers = Array.isArray(input.headers) ? input.headers.map((h, i) => {
    const name = redactField(h?.name || '', `表头${i + 1}`);
    const sample = Array.isArray(h?.sample)
      ? h.sample.slice(0, 200).map((v, j) => safeSample(v, `表头${i + 1}样例${j + 1}`))
      : [];
    const column = /^[A-Z]{1,3}$/.test(String(h?.column || '')) ? String(h.column) : '';
    return { name, column, sample };
  }) : [];

  return {
    kind: 'xlsx',
    sheet: redactField(input.sheet || '', '工作表').slice(0, 80),
    rows: Number.isFinite(Number(input.rows)) ? Number(input.rows) : 0,
    sampled_rows: Number.isSafeInteger(input.sampled_rows) && input.sampled_rows >= 0 ? Math.min(input.sampled_rows, 200) : 200,
    formulas,
    headers,
    redacted_hits: redactedHits,
  };
}

export function buildSafePayload(input = {}) {
  if (input.kind === 'xlsx') {
    const safe = buildSafeXlsxSummary(input);
    if (safe.redacted_hits.length > 200) throw new Error('敏感命中超过单次 200 项上限，请拆分输入');
    return safe;
  }
  if (input.kind === 'batch') {
    if (!Array.isArray(input.documents) || input.documents.length < 1 || input.documents.length > 10)
      throw new Error('批量体检需要 1 至 10 个文档');
    return { kind: 'batch', documents: input.documents.map((doc, i) => {
      if (doc.kind === 'batch') throw new Error('不支持嵌套批量任务');
      return { ...buildSafePayload(doc), label: `文档${i + 1}` };
    }) };
  }
  if (!['text', 'docx'].includes(input.kind) || typeof input.text !== 'string' || !input.text.trim())
    throw new Error('需要有效的 text/docx/xlsx/batch 输入');
  const r = redact(input.text);
  if (r.hits.length > 200) throw new Error('敏感命中超过单次 200 项上限，请拆分输入');
  return { kind: input.kind, text: r.text, redacted_hits: r.hits,
    ...(input.kind === 'docx' ? { heading_count: Number(input.heading_count) || 0 } : {}) };
}
