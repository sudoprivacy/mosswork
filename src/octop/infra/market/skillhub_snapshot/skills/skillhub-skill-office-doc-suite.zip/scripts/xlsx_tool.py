#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Excel 处理工具（openpyxl）
功能: 读取分析 / 生成报表（公式/样式）/ 合并多文件 / 数据透视统计
用法:
  python xlsx_tool.py read data.xlsx -sheet Sheet1
  python xlsx_tool.py stats data.xlsx -col 销售额 -sheet Sheet1
  python xlsx_tool.py merge a.xlsx b.xlsx -o merged.xlsx
  python xlsx_tool.py report data.xlsx -o report.xlsx -cols 销售额 -sum 销售额
  python xlsx_tool.py demo -o demo.xlsx   # 生成示例报表
"""
import argparse
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

def save_workbook(workbook, out):
    """Keep explicit empty strings distinct from blank cells during serialization."""
    try:
        from openpyxl.cell.rich_text import CellRichText
    except ImportError:
        print('[ODS-E09] Excel 写入需要 openpyxl>=3.1，请执行: pip install -U "openpyxl>=3.1"', file=sys.stderr)
        raise SystemExit(2) from None
    empty_strings = [cell for sheet in workbook.worksheets
                     for cell in sheet._cells.values() if cell.value == ""]
    try:
        # openpyxl drops plain '' before writing <is>; an empty rich string keeps
        # a real string cell, preserving ISBLANK/COUNTA input semantics.
        for cell in empty_strings:
            cell.value = CellRichText([""])
        workbook.save(out)
    finally:
        for cell in empty_strings:
            cell.value = ""


def _ensure_parent(path):
    """-o 指向不存在的目录时自动创建（2026-10-09：曾直接抛 FileNotFoundError 英文堆栈）。"""
    import os as _os
    d = _os.path.dirname(_os.path.abspath(path))
    if d and not _os.path.isdir(d):
        _os.makedirs(d, exist_ok=True)
        print(f"ℹ️ 输出目录不存在，已创建: {d}")



def load(path, sheet=None):
    from openpyxl import load_workbook
    if not os.path.exists(path):
        print(_fmt("ODS-E01", f"文件不存在 → {path}"))
        print(f"   请检查路径是否正确（当前目录: {os.getcwd()}）")
        sys.exit(1)
    try:
        wb = load_workbook(path, data_only=False)
    except Exception as e:
        print(_fmt("ODS-E02", f"无法打开 Excel 文件: {e}"))
        print(f"   可能原因: 文件损坏、非 xlsx 格式（旧版 .xls 不支持），或文件被占用")
        print(f"   提示: 若是 .xls 请先另存为 .xlsx；若被 Excel/WPS 打开请先关闭")
        sys.exit(1)
    if sheet and sheet not in wb.sheetnames:
        print(_fmt("ODS-E04", f"找不到工作表 '{sheet}'，可用: {wb.sheetnames}"))
        sys.exit(1)
    ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb.active
    return wb, ws


def read(path, sheet):
    wb, ws = load(path, sheet)
    print(f"工作表: {ws.title} | 行数: {ws.max_row} | 列数: {ws.max_column}")
    for row in ws.iter_rows(values_only=True):
        print(" | ".join("" if c is None else str(c) for c in row))


def _norm(v):
    """表头名归一化：真实文件里表头常是数字（单元格值是 float 1.0，命令行传 '1.0'）。

    两侧都要归一化，否则会打印「找不到列 '1.0'，可用列: [1.0]」这种自相矛盾的提示
    （2026-10-09 真实文件 ints_spelled_with_decimals.xlsx 复现）。
    """
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        f = float(v)
        return str(int(f)) if f.is_integer() else str(f)
    s = str(v).strip()
    try:
        f = float(s)
        if f.is_integer():
            return str(int(f))
    except ValueError:
        pass
    return s


def _header_row(ws):
    """探测表头行：跳过「合并的大标题行」与空行。

    标题行的判据要同时满足：① 在跨 ≥2 列的合并区里；② 这一行只有一个非空值。
    （2026-10-09 两轮真实文件测试修正：只看"在合并区"会误跳**多级表头**——
    pandas 语料 multiindex_no_index_names 第 1 行有 X/XX 两个值且带合并；
    只看"非空 ≥2"又会误跳**单列标题**——dimension_large 第 1 行只有 'Title'。）
    """
    for r in range(1, min(ws.max_row, 20) + 1):
        vals = [c.value for c in ws[r] if c.value is not None]
        if not vals:
            continue
        if len(vals) == 1:
            for rng in ws.merged_cells.ranges:
                if rng.min_row <= r <= rng.max_row and (rng.max_col - rng.min_col) >= 1:
                    vals = []          # 是「合并 + 单值」的标题行 → 跳过
                    break
        if not vals:
            continue
        return r
    return 1


def _open_data_only(path, sheet):
    """统计/报表专用打开：文件不存在或打不开时给带编号的中文提示，而不是抛原始堆栈。

    （2026-10-09 自检抓出：stats/report 直接调 load_workbook，文件不存在时抛
     FileNotFoundError 英文堆栈，没有错误编号。）
    """
    from openpyxl import load_workbook
    if not os.path.exists(path):
        print(_fmt("ODS-E01", f"文件不存在 → {path}"))
        sys.exit(1)
    try:
        wb = load_workbook(path, data_only=True)
    except Exception as e:
        print(_fmt("ODS-E02", f"打不开这个 Excel：{e}"))
        sys.exit(1)
    if sheet and sheet not in wb.sheetnames:
        print(_fmt("ODS-E04", f"没有名为 '{sheet}' 的工作表，可用: {wb.sheetnames}"))
        sys.exit(1)
    return wb[sheet] if sheet else wb.active


def stats(path, col, sheet):
    ws = _open_data_only(path, sheet)
    hrow = _header_row(ws)
    header = [_norm(c.value) for c in ws[hrow]]
    want = _norm(col)
    if want not in header:
        avail = [h for h in header if h]
        if not avail:
            # 空表/空工作表：别再说"找不到列 X，可用列: []"（用户看不懂）
            # 2026-10-09 第三批真实文件测试：xlsx-blank.xlsx 就撞到这句
            print(_fmt("ODS-E03", f"这张表里没有任何表头，也就没有数据列 → 文件: {path}",
                       f"可能选错了工作表（当前: {ws.title}，可用: {ws.parent.sheetnames}），或这个文件本身就是空表")) 
            sys.exit(1)
        print(_fmt("ODS-E03", f"找不到列 '{col}'，可用列: {avail}"))
        sys.exit(1)
    idx = header.index(want)
    nums = []
    skipped = 0
    for row in ws.iter_rows(min_row=hrow + 1, values_only=True):
        v = row[idx] if idx < len(row) else None
        if isinstance(v, (int, float)):
            nums.append(v)
        elif v is None:
            skipped += 1  # 公式未计算/空单元格
    if not nums:
        print(_fmt("ODS-E11", f"该列没有可统计的数字（{skipped} 个空单元格或未计算的公式值）"))
        print("   提示: 公式列要用「上次计算结果」才统计得到；先在 Excel/WPS 里打开并保存一次，"
              "或先用 xlsx_pro.py health 检查缓存值")
        sys.exit(1)
    print(f"列: {col} | 数值 {len(nums)} 个")
    print(f"  合计: {sum(nums):,.2f}")
    print(f"  平均: {sum(nums)/len(nums):,.2f}")
    print(f"  最大: {max(nums):,.2f}")
    print(f"  最小: {min(nums):,.2f}")


def merge(files, out):
    """合并多文件：每个文件的首行作为表头，之后的数据行追加（自动去重表头）。"""
    from openpyxl import load_workbook
    from openpyxl import Workbook
    wb_out = Workbook()
    ws_out = wb_out.active
    ws_out.title = "合并"
    header_written = False
    errors = []
    total_files = len(files)
    for idx, f in enumerate(files, 1):
        print(f"  处理 {idx}/{total_files}: {f}")
        try:
            wb = load_workbook(f, data_only=True)
        except Exception as e:
            errors.append(f"{f}: {e}")
            print(f"  ⚠️ 跳过 {f}（{e}）")
            continue
        try:
            for ws in wb.worksheets:
                rows = list(ws.iter_rows(values_only=True))
                if not rows:
                    continue
                if not header_written:
                    ws_out.append(rows[0])
                    header_written = True
                for row in rows[1:]:
                    if row != tuple(None for _ in row) and row != rows[0]:
                        ws_out.append(row)
        except Exception as e:
            errors.append(f"{f}: {e}")
            print(f"  ⚠️ 处理 {f} 时出错，跳过该文件（{e}）")
    save_workbook(wb_out, out)
    ok_count = total_files - len(errors)
    print(f"OK 合并完成：成功 {ok_count}/{total_files} 个文件 → {out}")
    print(f"  表头 1 行 + 数据 {max(0, ws_out.max_row - 1)} 行")
    if ws_out.max_row <= 1 and errors:
        print("❌ 没有任何数据被合并（全部文件都失败）")
        sys.exit(1)
    if errors:
        # 部分失败也要让调用方（Agent/CI）能从退出码看出来，否则会误报"合并完成"
        print(f"❌ 有 {len(errors)} 个文件未能处理：")
        for e in errors[:5]:
            print(f"   - {e}")
        sys.exit(1)


def report(path, out, cols, sum_col):
    """读取数据 → 生成带合计/平均的报表"""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    ws_src = _open_data_only(path, "")
    wb = Workbook()
    ws = wb.active
    ws.title = "报表"
    hrow = _header_row(ws_src)
    raw_header = [c.value for c in ws_src[hrow]]
    header = [_norm(v) for v in raw_header]
    # cols 为空时默认取全部列
    if not cols:
        pick = [h for h in header if h]
    else:
        wanted = [_norm(c) for c in cols]
        pick = [h for h in header if h in wanted]
    if not pick:
        avail = [h for h in header if h]
        if not avail:
            print(_fmt("ODS-E03", f"这张表里没有任何表头，也就没有可统计的列 → 文件: {path}",
                       f"可能选错了工作表（当前: {ws.title}，可用: {ws.parent.sheetnames}），或这个文件本身就是空表"))
            sys.exit(1)
        print(_fmt("ODS-E03", f"未找到可用的列（-cols: {cols}），可用列: {avail}"))
        sys.exit(1)
    # 写表头
    for j, h in enumerate(pick, 1):
        cell = ws.cell(row=1, column=j, value=h)
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9E2F3")
    # 写数据 + 底部汇总
    data_rows = []
    for row in ws_src.iter_rows(min_row=hrow + 1, values_only=True):
        vals = [row[header.index(h)] if header.index(h) < len(row) else None for h in pick]
        data_rows.append(vals)
        ws.append(vals)
    if sum_col and sum_col in pick:
        s_idx = pick.index(sum_col) + 1
        total = sum(r[pick.index(sum_col)] for r in data_rows if isinstance(r[pick.index(sum_col)], (int, float)))
        r = ws.max_row + 1
        ws.cell(row=r, column=1, value="合计").font = Font(bold=True)
        ws.cell(row=r, column=s_idx, value=total).font = Font(bold=True)
    # 列宽自适应
    for j in range(1, len(pick) + 1):
        ws.column_dimensions[get_column_letter(j)].width = 18
    save_workbook(wb, out)
    print(f"OK 报表生成 → {out}（{len(data_rows)} 行数据）")


def demo(out):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "示例报表"
    headers = ["部门", "销售额", "目标", "达成率"]
    for j, h in enumerate(headers, 1):
        c = ws.cell(row=1, column=j, value=h)
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="D9E2F3")
    data = [("华东", 120000, 100000), ("华南", 95000, 100000), ("华北", 88000, 100000)]
    for i, (dep, sale, target) in enumerate(data, 2):
        ws.cell(row=i, column=1, value=dep)
        ws.cell(row=i, column=2, value=sale)
        ws.cell(row=i, column=3, value=target)
        ws.cell(row=i, column=4, value=f"=ROUND(B{i}/C{i}*100,1)")
    ws.cell(row=5, column=1, value="合计").font = Font(bold=True)
    ws.cell(row=5, column=2, value="=SUM(B2:B4)").font = Font(bold=True)
    save_workbook(wb, out)
    print(f"OK 示例报表 → {out}")


def main():
    p = argparse.ArgumentParser(description="Excel 处理工具")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("read"); r.add_argument("file"); r.add_argument("-sheet", default="")
    s = sub.add_parser("stats"); s.add_argument("file"); s.add_argument("-col", required=True); s.add_argument("-sheet", default="")
    m = sub.add_parser("merge"); m.add_argument("files", nargs="+"); m.add_argument("-o", dest="out", default="merged.xlsx")
    rp = sub.add_parser("report"); rp.add_argument("file"); rp.add_argument("-o", dest="out", default="report.xlsx"); rp.add_argument("-cols", default=""); rp.add_argument("-sum", default="")
    d = sub.add_parser("demo"); d.add_argument("-o", dest="out", default="demo.xlsx")
    args = p.parse_args()
    for _k in ("out", "o"):
        _p = getattr(args, _k, None)
        if _p:
            _ensure_parent(_p)
    if args.cmd == "read":
        read(args.file, args.sheet)
    elif args.cmd == "stats":
        stats(args.file, args.col, args.sheet)
    elif args.cmd == "merge":
        merge(args.files, args.out)
    elif args.cmd == "report":
        cols = args.cols.split(",") if args.cols else []
        report(args.file, args.out, cols, args.sum)
    elif args.cmd == "demo":
        demo(args.out)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
