#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Collect inputs for the paid document audit probe."""

import argparse
import os
import sys
from pathlib import Path

from paid_audit import run_paid_audit


SUPPORTED = {".xlsx", ".docx", ".pdf"}


def collect(paths):
    """Resolve files from paths/directories, preserving order and removing duplicates."""
    files = []
    seen = set()
    for item in paths:
        path = Path(item).expanduser()
        if not path.exists():
            raise ValueError(f"路径不存在：{path}")
        if path.is_dir():
            found = sorted(
                (p for p in path.rglob("*") if p.is_file() and p.suffix.lower() in SUPPORTED
                 and not p.name.startswith("~$")),
                key=lambda p: str(p).casefold(),
            )
            if not found:
                raise ValueError(f"目录中没有受支持的文件：{path}")
        elif path.is_file() and path.suffix.lower() in SUPPORTED:
            found = [path]
        else:
            raise ValueError(f"不支持的文件类型：{path.name}")
        for file_path in found:
            resolved = str(file_path.resolve())
            key = os.path.normcase(resolved)
            if key not in seen:
                seen.add(key)
                files.append(resolved)
    if not files:
        raise ValueError("没有找到受支持的输入文件")
    return files


def main(argv=None):
    parser = argparse.ArgumentParser(description="收集文件并触发云端付费体检")
    parser.add_argument("paths", nargs="+", help="文件或目录路径，可多个")
    parser.add_argument("-o", dest="out", default="", help="兼容旧参数；体检凭证由付费流程生成")
    parser.add_argument("-pdf", "--pdf", action="store_true", help="兼容旧参数；体检凭证格式由付费流程生成")
    parser.add_argument("-json", "--json", dest="json_out", default="", help="兼容旧参数；体检凭证由付费流程生成")
    parser.add_argument("-sheet", "--sheet", default="", help="Excel 工作表名称")
    args = parser.parse_args(argv)
    try:
        files = collect(args.paths)
        return run_paid_audit(files, sheet=args.sheet)
    except Exception as exc:
        print(f"错误 [ODS-E13] 输入处理失败：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
