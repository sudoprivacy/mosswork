#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""no_dep.py — 零依赖降级模式（只用 Python 标准库）

为什么需要它（2026-10-09 竞品对比结论）：头部竞品（excel-xlsx / word-docx / nano-pdf）
赢在**零依赖**——用户不用 pip 装任何东西。本套件功能更全，但缺库就什么都干不了。
公司电脑装不了包、离线环境、Python 太老……这些场景需要的不是"更多功能"，而是
**"一条命令先把文档读懂、把数据导出来"**的能力。

.docx / .xlsx 本质是 ZIP + XML，标准库就能读；PDF 没有标准库解析器，这里做"尽力而为"。

能力（全部不需要第三方库）：
  check                       看哪些能力可用（装了库的走主脚本，没装的走这里）
  docx-text   <file>          提取 Word 正文（含表格里的文字）
  docx-replace <file> -find X -replace Y -o out.docx      简单文本替换（模板占位符够用）
  xlsx-sheets <file>          列出工作表
  xlsx-text   <file> [-sheet S]                            打印单元格（制表符分隔）
  xlsx-csv    <file> [-sheet S] [-o out.csv]               导出 CSV
  xlsx-merge  a.xlsx b.xlsx -o out.csv                     多表拼成一个 CSV（同表头）
  pdf-info    <file>          页数/是否加密/有无文字流（结构级，不依赖库）
  pdf-text    <file>          尽力提取文字（仅未压缩或 Flate 压缩的简单 PDF 可靠）

明确边界（会写在输出里，不假装）：
  · 不保留任何格式/公式/图表/图片；写回 .docx 只替换文字
  · .xlsx 只读不写（写需要 openpyxl；要写请 pip 安装后走主脚本）
  · PDF 文字提取对“子集化/自定义编码字体（含多数中文 PDF）”不可靠 → 请用主脚本 or OCR
"""
import argparse
import csv
import io
import os
import re
import sys
import zipfile
import zlib

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import fmt as _fmt, tag as _tag
except Exception:  # 单文件拷贝出去也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"
    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")


def die(code, msg, hint=None):
    print(_fmt(code, msg, hint))
    sys.exit(1)


def _zip(path, code="ODS-E02"):
    if not os.path.exists(path):
        die("ODS-E01", f"文件不存在 → {path}")
    try:
        return zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        die(code, f"不是有效的 Office 文件（ZIP 结构读取失败）→ {path}",
            "确认扩展名与实际格式一致；旧版 .xls/.doc 请先用 convert_legacy.py 转换")


def _xml(z, name, required=True):
    from xml.etree import ElementTree as ET
    try:
        data = z.read(name)
    except KeyError:
        if required:
            die("ODS-E02", f"文件结构里缺少 {name}（可能不是标准 Office 文件，或被加密）")
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError as e:
        die("ODS-E02", f"文件内容读不出来（可能已损坏）：{name}")


# ───────────────────────── Word ─────────────────────────
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def docx_text(path):
    z = _zip(path)
    root = _xml(z, "word/document.xml")
    lines = []
    for p in root.iter(f"{W}p"):
        text = "".join(t.text or "" for t in p.iter(f"{W}t"))
        lines.append(text)
    z.close()
    return lines


def cmd_docx_text(a):
    lines = docx_text(a.file)
    body = "\n".join(lines).strip()
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(body)
        print(f"✅ 已提取 {len(lines)} 段 / {len(body)} 字符 → {a.out}（零依赖模式，不含格式）")
    else:
        print(body)
    return 0


def cmd_docx_replace(a):
    from xml.sax.saxutils import escape, unescape
    z = _zip(a.file)
    xml = z.read("word/document.xml").decode("utf-8")
    z.close()
    find, repl = a.find, a.replace
    hit = 0

    def _sub(m):
        nonlocal hit
        head, raw, tail = m.group(1), m.group(2), m.group(3)
        text = unescape(raw)
        if find and find in text:
            hit += 1
            return head + escape(text.replace(find, repl)) + tail
        return m.group(0)

    new_xml = re.sub(r"(<w:t[^>]*>)(.*?)(</w:t>)", _sub, xml, flags=re.S)
    # 跨 run 判断：整段文字拼起来能命中、但没有任何单个 <w:t> 命中 → Word 把占位符拆开了
    plain = "".join(unescape(t) for t in re.findall(r"<w:t[^>]*>(.*?)</w:t>", xml, flags=re.S))
    cross = bool(find) and (find in plain) and hit == 0
    if hit == 0:
        print(f"⚠️ 未替换：「{find}」" + ("被 Word 拆成了多个文本块（零依赖模式改不了）" if cross else "不在文档里"))
        print("   办法：补装组件（命令行执行 pip install python-docx）后，用 docx_tool.py replace 替换，格式不容易乱")
        return 1
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
        zin = zipfile.ZipFile(a.file)
        with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED) as zo:
            for item in zin.infolist():
                data = zin.read(item.filename)
                if item.filename == "word/document.xml":
                    data = new_xml.encode("utf-8")
                zo.writestr(item, data)
        zin.close()
        print(f"✅ 已替换 {hit} 处 → {a.out}（零依赖模式：只改文字，原包其余部分原样保留）")
    else:
        print(f"✅ 已替换 {hit} 处（未指定 -o，不写文件）")
    return 0


# ───────────────────────── Excel ─────────────────────────
S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def xlsx_sheets(z):
    """返回 [(表名, zip内路径)]，按 workbook 声明顺序"""
    wb = _xml(z, "xl/workbook.xml")
    rels = _xml(z, "xl/_rels/workbook.xml.rels")
    rid2target = {}
    for rel in rels.iter(f"{PKG_REL}Relationship"):
        t = rel.get("Target") or ""
        rid2target[rel.get("Id")] = t.lstrip("/") if t.startswith("/") else ("xl/" + t.lstrip("./"))
    out = []
    for sh in wb.iter(f"{S}sheet"):
        rid = sh.get(f"{R}id")
        out.append((sh.get("name"), rid2target.get(rid, "")))
    return out


def _shared_strings(z):
    root = _xml(z, "xl/sharedStrings.xml", required=False)
    if root is None:
        return []
    out = []
    for si in root.iter(f"{S}si"):
        out.append("".join(t.text or "" for t in si.iter(f"{S}t")))
    return out


def _col_idx(ref):
    m = re.match(r"([A-Z]+)", ref or "")
    n = 0
    for ch in (m.group(1) if m else "A"):
        n = n * 26 + (ord(ch) - 64)
    return max(n - 1, 0)


def xlsx_rows(path, sheet_name=None):
    z = _zip(path)
    sheets = xlsx_sheets(z)
    if not sheets:
        die("ODS-E02", "工作簿里没有工作表")
    target = None
    if sheet_name:
        for name, p in sheets:
            if name == sheet_name:
                target = p
                break
        if target is None:
            die("ODS-E04", f"找不到工作表 '{sheet_name}'", "可用: " + ", ".join(n for n, _ in sheets))
    else:
        target = sheets[0][1]
    shared = _shared_strings(z)
    root = _xml(z, target)
    rows = []
    for row in root.iter(f"{S}row"):
        cells = {}
        for c in row.iter(f"{S}c"):
            ref = c.get("r") or ""
            t = c.get("t")
            v = c.find(f"{S}v")
            is_ = c.find(f"{S}is")
            if t == "s" and v is not None:
                try:
                    val = shared[int(v.text)]
                except Exception:
                    val = ""
            elif t == "inlineStr" and is_ is not None:
                val = "".join(x.text or "" for x in is_.iter(f"{S}t"))
            elif t == "b" and v is not None:
                val = "TRUE" if v.text == "1" else "FALSE"
            elif v is not None:
                val = v.text
            else:
                val = ""
            cells[_col_idx(ref)] = val
        if cells:
            width = max(cells) + 1
            rows.append([cells.get(i, "") for i in range(width)])
    z.close()
    return sheets, rows


def cmd_xlsx_sheets(a):
    z = _zip(a.file)
    sheets = xlsx_sheets(z)
    z.close()
    print(f"{a.file} 共 {len(sheets)} 个工作表：")
    for i, (name, p) in enumerate(sheets, 1):
        print(f"  {i}. {name}   ({p})")
    return 0


def _dump_rows(rows):
    for r in rows:
        print("\t".join("" if c is None else str(c) for c in r))


def cmd_xlsx_text(a):
    sheets, rows = xlsx_rows(a.file, a.sheet)
    print(f"工作表: {a.sheet or sheets[0][0]} | {len(rows)} 行（零依赖模式，只读值）")
    _dump_rows(rows)
    return 0


def cmd_xlsx_csv(a):
    sheets, rows = xlsx_rows(a.file, a.sheet)
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
        with open(a.out, "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f).writerows(rows)
        print(f"✅ 已导出 {len(rows)} 行 → {a.out}（用 Excel 直接打开不会乱码）")
    else:
        buf = io.StringIO()
        csv.writer(buf).writerows(rows)
        sys.stdout.write(buf.getvalue())
    return 0


def cmd_xlsx_merge(a):
    all_rows, header_written = [], False
    for f in a.files:
        _sheets, rows = xlsx_rows(f, a.sheet or None)
        if not rows:
            print(f"  ⚠️ 跳过空表: {f}")
            continue
        if not header_written:
            all_rows.append(rows[0]); header_written = True
        for r in rows[1:]:
            if any(str(c).strip() for c in r):
                all_rows.append(r)
    if not all_rows:
        die("ODS-E13", "没有任何数据行可合并")
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
        with open(a.out, "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f).writerows(all_rows)
        print(f"✅ 已合并 {len(a.files)} 个文件 → {a.out}（{len(all_rows)} 行，只保留第一个文件的表头）")
    else:
        _dump_rows(all_rows)
    return 0


# ───────────────────────── PDF（尽力而为） ─────────────────────────
def _pdf_bytes(path):
    if not os.path.exists(path):
        die("ODS-E01", f"文件不存在 → {path}")
    with open(path, "rb") as f:
        data = f.read()
    if not data[:5].startswith(b"%PDF"):
        die("ODS-E05", f"不是 PDF 文件（文件头不是 %PDF）→ {path}")
    return data


def cmd_pdf_info(a):
    data = _pdf_bytes(a.file)
    pages = len(re.findall(rb"/Type\s*/Page(?![s])", data))
    streams = len(re.findall(rb"\bstream\r?\n", data))
    enc = b"/Encrypt" in data
    meta = {}
    for key in (b"Producer", b"Creator", b"Title"):
        m = re.search(rb"/" + key + rb"\s*\(([^)]{0,120})\)", data)
        if m:
            try:
                meta[key.decode()] = m.group(1).decode("utf-8", "replace")
            except Exception:
                pass
    print(f"文件: {a.file}（{len(data)/1024:.0f} KB）")
    print(f"页数: {pages}（按 /Type /Page 统计，结构复杂时可能不准）")
    print(f"加密: {'是' if enc else '否'}   内容块: {streams} 处")
    for k, v in meta.items():
        print(f"{k}: {v}")
    print("说明：零依赖模式只能看结构；要提取文字、打码、加水印，需要补装组件（命令行执行 pip install pymupdf）后用主脚本")
    return 0


def cmd_pdf_text(a):
    data = _pdf_bytes(a.file)
    if b"/Encrypt" in data:
        die("ODS-E07", "PDF 已加密，零依赖模式无法读取", "先用 pdf_tool.py decrypt 解密，或用密码打开另存")
    chunks = []
    n_ok = n_bad = 0
    for m in re.finditer(rb"stream\r?\n(.*?)endstream", data, flags=re.S):
        raw = m.group(1)
        try:
            dec = zlib.decompress(raw)
            n_ok += 1
        except Exception:
            dec = raw
            n_bad += 1
        for tm in re.finditer(rb"\((?:\\.|[^()\\])*\)", dec):
            s = tm.group(0)[1:-1]
            s = re.sub(rb"\\([()\\])", rb"\1", s)
            try:
                chunks.append(s.decode("latin1"))
            except Exception:
                pass
    text = " ".join(chunks)
    text = re.sub(r"\s{2,}", " ", text).strip()
    printable = sum(1 for ch in text if 32 <= ord(ch) < 127)
    print(f"提取到 {len(text)} 字符（可解压流 {n_ok} / 原样流 {n_bad}）")
    if text and printable / max(len(text), 1) > 0.8:
        print(text[:4000])
        print("\n⚠️ 零依赖模式只能读简单 PDF 的字面文本；中文/子集化字体请用主脚本或 OCR")
        return 0
    print("⚠️ 没提取到可读文本：该 PDF 可能使用子集化字体/对象流（多数中文 PDF 都是）")
    print("   办法：① 补装组件（命令行执行 pip install pymupdf）后，用 pdf_tool.py extract 提取；")
    print("         ② 或用 pdf_tool.py toimage 转图片交给带视觉能力的模型识别")
    return 0


# ───────────────────────── check ─────────────────────────
def cmd_check(a):
    mods = [("openpyxl", "Excel 读写"), ("docx", "Word 读写"), ("PyPDF2", "PDF 合并/拆分/加解密"),
            ("pymupdf", "PDF 水印/打码/转图/页码"), ("xlrd", "旧版 .xls 读取")]
    print("依赖检查（装了 → 走主脚本，功能全；没装 → 用下面的零依赖命令）")
    for mod, use in mods:
        try:
            __import__(mod)
            print(f"  ✅ {mod:<10} {use}")
        except Exception:
            print(f"  ⬜ {mod:<10} {use}    ← 缺，可用零依赖替代命令")
    print("\n零依赖可用（本脚本，只用标准库）：")
    print("  docx-text / docx-replace / xlsx-sheets / xlsx-text / xlsx-csv / xlsx-merge / pdf-info / pdf-text")
    print("零依赖不可用（必须装库）：")
    print("  Excel 写回与排序/筛选/图表、Word 目录/页眉、PDF 打码/水印/合并/拆分")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="零依赖降级模式（只用 Python 标准库）")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("check"); c.set_defaults(fn=cmd_check)

    d = sub.add_parser("docx-text"); d.add_argument("file"); d.add_argument("-o", dest="out", default="")
    d.set_defaults(fn=cmd_docx_text)

    dr = sub.add_parser("docx-replace"); dr.add_argument("file")
    dr.add_argument("-find", required=True); dr.add_argument("-replace", required=True)
    dr.add_argument("-o", dest="out", default="")
    dr.set_defaults(fn=cmd_docx_replace)

    xs = sub.add_parser("xlsx-sheets"); xs.add_argument("file"); xs.set_defaults(fn=cmd_xlsx_sheets)

    xt = sub.add_parser("xlsx-text"); xt.add_argument("file"); xt.add_argument("-sheet", default="")
    xt.set_defaults(fn=cmd_xlsx_text)

    xc = sub.add_parser("xlsx-csv"); xc.add_argument("file")
    xc.add_argument("-sheet", default=""); xc.add_argument("-o", dest="out", default="")
    xc.set_defaults(fn=cmd_xlsx_csv)

    xm = sub.add_parser("xlsx-merge"); xm.add_argument("files", nargs="+")
    xm.add_argument("-sheet", default=""); xm.add_argument("-o", dest="out", default="")
    xm.set_defaults(fn=cmd_xlsx_merge)

    pi = sub.add_parser("pdf-info"); pi.add_argument("file"); pi.set_defaults(fn=cmd_pdf_info)
    pt = sub.add_parser("pdf-text"); pt.add_argument("file"); pt.set_defaults(fn=cmd_pdf_text)

    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
