#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cert_pdf.py — 把「云端体检凭证」渲染成可归档 PDF

凭证来源：office-doc-suite-paid.mjs 在 complete 成功后写出 `<订单号>.json`，
本脚本只负责把它排成一份能直接发给同事/客户/归档的 PDF。

用法:
  python scripts/cert_pdf.py 云端体检凭证-<订单号>.json [-o 同名.pdf]
"""
import argparse
import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt
except Exception:
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")


def fitz_mod():
    try:
        import pymupdf as fitz
        return fitz
    except ImportError:
        try:
            import fitz
            return fitz
        except ImportError:
            return None


def render(cert, out_pdf):
    fitz = fitz_mod()
    if fitz is None:
        print(_fmt("ODS-E09", "生成 PDF 需要先补装一个小组件",
                   "在命令行执行  pip install pymupdf  然后再试；不装也能用凭证的 JSON 文件"))
        return False

    doc = fitz.open()
    page = doc.new_page()
    margin, y, lh = 56, 64, 17
    width = page.rect.width - margin * 2

    def line(text, size=10.5, gap=1.0, bold=False):
        nonlocal page, y
        text = "" if text is None else str(text)
        if y > page.rect.height - margin:
            page = doc.new_page()
            y = margin
        for chunk in [text[i:i + 44] for i in range(0, len(text), 44)] or [""]:
            if y > page.rect.height - margin:
                page = doc.new_page()
                y = margin
            page.insert_text((margin, y), chunk, fontsize=size, fontname="china-s")
            y += lh * gap

    line("云端文档体检 · 凭证", size=17, gap=1.5)
    line(f"订单号：{cert.get('orderNo') or '(未记录)'}", size=11)
    line(f"生成时间：{cert.get('completedAt') or cert.get('generatedAt') or ''}（ISO 时间）")
    line(f"服务：{cert.get('serviceName') or '办公文档三件套 · 云端文档体检'}")
    line(f"金额：¥{cert.get('amount') or '(以账单为准)'}   计价：按次")
    line(f"技能版本：{cert.get('toolVersion') or ''}")
    if cert.get("ruleVersion"):
        line(f"体检规则版本：{cert['ruleVersion']}")
    y += lh * 0.6

    line("一、结论", size=12, gap=1.3)
    summary = cert.get("summary") or {}
    line(f"结论判定：{summary.get('verdict') or '(未解析)'}")
    if summary.get("kind"):
        line(f"体检类型：{summary['kind']}")
    if summary.get("scope"):
        line(f"范围：{summary['scope']}")
    if summary.get("sheet"):
        line(f"工作表：{summary['sheet']}")
    if summary.get("counts"):
        for k, v in summary["counts"].items():
            line(f"· {k}：{v} 处")
    y += lh * 0.6

    items = cert.get("items") or []
    line("二、问题清单", size=12, gap=1.3)
    if not items:
        line("未发现需要处理的问题。")
    for i, it in enumerate(items, 1):
        line(f"{i}. [{it.get('level') or '-'}] {it.get('type') or ''} {it.get('where') or ''}")
        if it.get("message"):
            line(f"   说明：{it['message']}")
        if it.get("fix"):
            line(f"   处理建议：{it['fix']}")
    y += lh * 0.6

    line("三、可核对信息（用于对账与校验）", size=12, gap=1.3)
    line("以下指纹是对服务端返回原文整体做 SHA-256 计算所得；原文改动一个字符，指纹即变化。")
    line(f"服务端返回原文 SHA-256：{cert.get('serverResponseSha256') or '(未记录)'}")
    line(f"返回原文长度：{cert.get('serverResponseBytes') or 0} 字节")
    line(f"请求资源：{cert.get('resourceId') or ''}")
    y += lh * 0.6

    line("四、说明", size=12, gap=1.3)
    line("1) 本凭证由办公文档三件套在用户本机生成，内容取自商家服务端对该次请求的返回结果；")
    line("2) 凭证与订单号一一对应，可用订单号在支付宝账单中核对金额与时间；")
    line("3) 体检结论基于提交时的内容，内容修改后需重新体检；")
    line("4) SHA-256 用于检查保存的服务端返回原文是否被改动；本凭证不是服务端数字签名或法律证明；")
    line("5) 凭证不包含用户文档本体，仅包含体检结论与核对信息。")

    os.makedirs(os.path.dirname(os.path.abspath(out_pdf)) or ".", exist_ok=True)
    doc.save(out_pdf)
    doc.close()
    return True


def main():
    ap = argparse.ArgumentParser(description="把体检凭证 JSON 渲染成可归档 PDF")
    ap.add_argument("json_file")
    ap.add_argument("-o", dest="out", default="")
    a = ap.parse_args()

    if not os.path.exists(a.json_file):
        print(_fmt("ODS-E01", f"文件不存在 → {a.json_file}"))
        sys.exit(1)
    try:
        cert = json.load(open(a.json_file, encoding="utf-8"))
    except Exception as e:
        print(_fmt("ODS-E02", "凭证文件读不出来（文件可能损坏或被手工改过）",
                   "请用本技能新生成的凭证；确需查看请先备份原文件"))
        sys.exit(1)

    out = a.out or (os.path.splitext(a.json_file)[0] + ".pdf")
    if render(cert, out):
        print(f"✅ 凭证 PDF 已生成 → {out}")
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
