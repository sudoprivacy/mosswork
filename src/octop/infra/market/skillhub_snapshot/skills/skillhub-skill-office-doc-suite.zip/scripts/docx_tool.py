#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Word 处理工具（python-docx）v1.1
功能: 生成文档 / 保真替换（保留格式）/ 批量替换 / 转纯文本 / 信息查看
用法:
  python docx_tool.py create out.docx -title "周报" -body "内容1|内容2" -table "A,B,C|1,2,3"
  python docx_tool.py replace in.docx -o out.docx -find "旧" -replace "新"
  python docx_tool.py replace-batch in.docx -o out.docx -pairs "旧1=>新1|旧2=>新2"
  python docx_tool.py totext in.docx -o out.txt
  python docx_tool.py info in.docx
  python docx_tool.py demo -o demo.docx
"""
import argparse
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

def _ensure_parent(path):
    """-o 指向不存在的目录时自动创建（2026-10-09：曾直接抛 FileNotFoundError 英文堆栈）。"""
    import os as _os
    d = _os.path.dirname(_os.path.abspath(path))
    if d and not _os.path.isdir(d):
        _os.makedirs(d, exist_ok=True)
        print(f"ℹ️ 输出目录不存在，已创建: {d}")



def _check_path(path):
    """路径校验：不存在/无权限时给出中文提示。"""
    if not os.path.exists(path):
        print(_fmt("ODS-E01", f"文件不存在 → {path}"))
        print(f"   请检查路径是否正确（当前目录: {os.getcwd()}）")
        print(f"   提示: 可用完整路径，如 D:\\文档\\report.docx")
        sys.exit(1)
    if not os.access(path, os.R_OK):
        print(f"❌ 错误: 无读取权限 → {path}")
        print(f"   请检查文件权限，或换一个可读的路径")
        sys.exit(1)


def _load_docx(path):
    from docx import Document
    _check_path(path)
    try:
        return Document(path)
    except Exception as e:
        print(_fmt("ODS-E02", f"无法打开 Word 文档: {e}"))
        print(f"   可能原因: 文件损坏、非 docx 格式（旧版 .doc 不支持），或文件被占用")
        print(f"   提示: 若是 .doc 请先另存为 .docx；若被 WPS/Word 打开请先关闭")
        sys.exit(1)


def create(out, title, body, table):
    from docx import Document
    from docx.shared import RGBColor
    doc = Document()
    if title:
        h = doc.add_heading(title, level=1)
        for run in h.runs:
            run.font.color.rgb = RGBColor(0x2F, 0x54, 0x9C)
    if body:
        for para in body.split("|"):
            para = para.strip()
            if para:
                doc.add_paragraph(para)
    if table:
        rows = [r.split(",") for r in table.split(";")]
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                t.cell(i, j).text = val.strip()
    doc.save(out)
    print(f"OK 文档生成 → {out}")


def _replace_in_paragraph(para, find, repl):
    """Replace across any number of runs, retaining the first matched run's format."""
    if not find:
        return 0
    runs = para.runs
    offsets = []
    text = ""
    for run in runs:
        offsets.append(len(text))
        text += run.text
    matches = []
    start = 0
    while True:
        start = text.find(find, start)
        if start < 0:
            break
        matches.append(start)
        start += len(find)
    # Original offsets remain valid when edits are applied from right to left.
    for start in reversed(matches):
        end = start + len(find)
        first = next(i for i, run in enumerate(runs)
                     if offsets[i] <= start < offsets[i] + len(run.text))
        for i in range(first, len(runs)):
            run = runs[i]
            left = max(0, start - offsets[i])
            right = min(len(run.text), end - offsets[i])
            if right > left:
                run.text = run.text[:left] + (repl if i == first else "") + run.text[right:]
            if offsets[i] + right >= end:
                break
    return len(matches)


def _iter_unique_cells(table):
    """Visit physical cells once without resolving irregular merged grid aliases."""
    from docx.table import _Cell
    for tr in table._tbl.tr_lst:
        for tc in tr.tc_lst:
            yield _Cell(tc, table)


def replace_doc(docx_in, out, find, repl):
    """替换单个字符串（保留原格式，兼容合并单元格）。"""
    doc = _load_docx(docx_in)
    count = 0
    for para in doc.paragraphs:
        count += _replace_in_paragraph(para, find, repl)
    for table in doc.tables:
        for cell in _iter_unique_cells(table):
            for para in cell.paragraphs:
                count += _replace_in_paragraph(para, find, repl)
    doc.save(out)
    print(f"OK 替换 {count} 处 '{find}' → '{repl}'，输出 {out}")


def replace_batch(docx_in, out, pairs_text):
    """批量替换：pairs 格式 "旧1=>新1|旧2=>新2"。"""
    doc = _load_docx(docx_in)
    pairs = []
    for item in pairs_text.split("|"):
        item = item.strip()
        if "=>" in item:
            old, new = item.split("=>", 1)
            pairs.append((old.strip(), new.strip()))
    if not pairs:
        print("❌ 未解析到有效的替换对")
        print("   格式示例: 旧1=>新1|旧2=>新2")
        sys.exit(1)
    total = 0
    for para in doc.paragraphs:
        for old, new in pairs:
            total += _replace_in_paragraph(para, old, new)
    for table in doc.tables:
        for cell in _iter_unique_cells(table):
            for para in cell.paragraphs:
                for old, new in pairs:
                    total += _replace_in_paragraph(para, old, new)
    doc.save(out)
    print(f"OK 批量替换 {len(pairs)} 组，共 {total} 处 → {out}")


def totext(docx_in, out):
    """提取文档纯文本（含表格）。"""
    doc = _load_docx(docx_in)
    lines = []
    for para in doc.paragraphs:
        if para.text.strip():
            lines.append(para.text)
    for i, table in enumerate(doc.tables, 1):
        lines.append(f"[表格{i}]")
        for row in table.rows:
            from docx.table import _Cell
            cells = [_Cell(tc, table).text.strip() for tc in row._tr.tc_lst]
            lines.append(" | ".join(cells))
    content = "\n".join(lines)
    if out:
        with open(out, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"OK 已提取文本 → {out}（{len(lines)} 行）")
    else:
        print(content)


def info(docx_in):
    doc = _load_docx(docx_in)
    print(f"段落数: {len(doc.paragraphs)}")
    print(f"表格数: {len(doc.tables)}")
    print(f"标题: {[p.text for p in doc.paragraphs if p.style.name.startswith('Heading')][:5]}")
    print("前 5 段:")
    for p in doc.paragraphs[:5]:
        if p.text.strip():
            print(f"  {p.text.strip()[:60]}")


def demo(out):
    from docx import Document
    doc = Document()
    doc.add_heading("周报示例", level=1)
    doc.add_paragraph("本周完成：新功能开发、Bug 修复、需求评审。")
    doc.add_paragraph("下周计划：性能优化、文档完善。")
    t = doc.add_table(rows=3, cols=3)
    t.style = "Table Grid"
    data = [["任务", "状态", "进度"], ["功能开发", "完成", "100%"], ["性能优化", "进行中", "60%"]]
    for i, row in enumerate(data):
        for j, val in enumerate(row):
            t.cell(i, j).text = val
    doc.save(out)
    print(f"OK 示例文档 → {out}")


def main():
    p = argparse.ArgumentParser(description="Word 处理工具")
    sub = p.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("create"); c.add_argument("out"); c.add_argument("-title", default=""); c.add_argument("-body", default=""); c.add_argument("-table", default="")
    r = sub.add_parser("replace"); r.add_argument("file"); r.add_argument("-o", default="out.docx"); r.add_argument("-find", required=True); r.add_argument("-replace", required=True)
    rb = sub.add_parser("replace-batch"); rb.add_argument("file"); rb.add_argument("-o", default="out.docx"); rb.add_argument("-pairs", required=True)
    t = sub.add_parser("totext"); t.add_argument("file"); t.add_argument("-o", default="")
    i = sub.add_parser("info"); i.add_argument("file")
    d = sub.add_parser("demo"); d.add_argument("-o", default="demo.docx")
    args = p.parse_args()
    for _k in ("out", "o"):
        _p = getattr(args, _k, None)
        if _p:
            _ensure_parent(_p)
    if args.cmd == "create":
        create(args.out, args.title, args.body, args.table)
    elif args.cmd == "replace":
        replace_doc(args.file, args.o, args.find, args.replace)
    elif args.cmd == "replace-batch":
        replace_batch(args.file, args.o, args.pairs)
    elif args.cmd == "totext":
        totext(args.file, args.o)
    elif args.cmd == "info":
        info(args.file)
    elif args.cmd == "demo":
        demo(args.o)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
