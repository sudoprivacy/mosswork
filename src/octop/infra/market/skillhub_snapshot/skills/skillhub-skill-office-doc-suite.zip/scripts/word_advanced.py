#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Word 增强工具（python-docx）—— 补齐目录 / 页眉页脚 / Markdown 转 Word

v1.6.0 新增（对标竞品 v5.2 公文排版、v4.7 Markdown 转换、长文档排版）：
  outline    读取文档大纲（标题层级），先看清楚再动手
  toc        插入自动目录域（TOC field），Word/WPS 里按 F9 更新页码
  header     设置页眉 + 页脚（第 X 页 / 共 Y 页），带域代码
  pagebreak  按标题分页 / 插入分页符（长报告排版）
  md2docx    Markdown → Word（标题层级/列表/表格/代码块/粗体斜体）

用法:
  python word_advanced.py outline 方案.docx
  python word_advanced.py toc 方案.docx -o 方案-带目录.docx -levels 3
  python word_advanced.py header 方案.docx -o 方案-页眉.docx -header "XX公司" -footer "第 X 页 / 共 Y 页"
  python word_advanced.py md2docx 说明.md -o 说明.docx
"""
import argparse
import os
import re
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")

def _ensure_parent(path):
    """-o 指向不存在的目录时自动创建（2026-10-09：曾直接抛 FileNotFoundError 英文堆栈）。"""
    import os as _os
    d = _os.path.dirname(_os.path.abspath(path))
    if d and not _os.path.isdir(d):
        _os.makedirs(d, exist_ok=True)
        print(f"ℹ️ 输出目录不存在，已创建: {d}")



def die(msg, hint=None, code=None):
    """失败出口。带 code 时带错误编号（见 scripts/error_codes.py）。"""
    print(f"❌ 错误 {_tag(code, msg) if code else ': ' + msg}")
    if hint:
        print(f"   提示: {hint}")
    sys.exit(1)


def load_docx(path):
    import docx
    if not os.path.exists(path):
        die(f"文件不存在 → {path}", f"请检查路径（当前目录: {os.getcwd()}）；旧版 .doc 请先转 .docx", code="ODS-E01")
    if os.path.isdir(path):
        # 不把 Python 的英文 errno 甩给用户（2026-10-09 真机测得：传目录时报
        # "无法打开 Word 文档: [Errno 2] No such file or directory"）
        die(f"这是一个目录，不是 Word 文件 → {path}", "请传具体的 .docx 文件；要批量处理用 checkup_report.py 扫目录", code="ODS-E01")
    try:
        return docx.Document(path)
    except Exception as e:
        die(f"无法打开 Word 文档: {e}", "可能是文件损坏、非 .docx 旧格式，或文件正被 Word/WPS 占用（先关闭）", code="ODS-E02")


def _add_field(paragraph, instr, placeholder="1"):
    """插入 Word 域代码，例如 TOC \\o "1-3" 或 PAGE"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    r = paragraph.add_run()
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), instr)
    inner = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = placeholder
    inner.append(t)
    fld.append(inner)
    r._r.addnext(fld)
    return fld


def cmd_outline(args):
    doc = load_docx(args.file)
    rows = [(p.style.name, p.text.strip()) for p in doc.paragraphs
            if p.text.strip() and (p.style.name or "").startswith("Heading")]
    if not rows:
        rows = [(p.style.name, p.text.strip()[:60]) for p in doc.paragraphs if p.text.strip()][:20]
        print("⚠️ 文档里没有标题样式（Heading），下面按前 20 个非空段落列出")
    print(f"📑 文档大纲: {args.file}（共 {len(rows)} 项）")
    for style, text in rows:
        lvl = "".join(ch for ch in style if ch.isdigit()) or "0"
        print(f"   {'  ' * int(lvl or 0)}- [H{lvl}] {text[:70]}")
    print("\n提示: 有标题层级才能生成目录；没有标题请先用 Word 的「标题 1/2」样式标记")


def _heading_style(doc, level=1):
    """安全取「标题 N」样式。

    踩坑记录（2026-10-09，真实文件复现）：python-docx 官方语料 having-images.docx /
    blk-inner-content.docx 里没有名为 `Heading 1` 的样式，旧版直接
    `doc.styles["Heading 1"]` 抛 `KeyError: "no style with name 'Heading 1'"` 并输出英文堆栈。
    现在按 英文/小写/中文 多种名字找，找不到返回 None 由调用方降级处理。
    """
    names = [s.name for s in doc.styles]
    for cand in (f"Heading {level}", f"heading {level}", f"标题 {level}", f"标题{level}"):
        if cand in names:
            return doc.styles[cand]
    for s in doc.styles:
        n = (s.name or "").strip().lower()
        if n.startswith("heading") and n.endswith(str(level)):
            return s
    return None


def cmd_toc(args):
    doc = load_docx(args.file)
    # 目录插到正文最前面
    first = doc.paragraphs[0] if doc.paragraphs else None
    if first is not None:
        first._p.addprevious(first._p)
    title = doc.add_paragraph()
    doc.paragraphs[0]._p.addnext(title._p)
    from docx.oxml.ns import qn
    st = _heading_style(doc, 1)
    if st is not None:
        title.style = st
    else:
        print(_tag("ODS-E14", "文档里没有「标题 1 / Heading 1」样式：目录标题用默认样式写入（不影响 TOC 域）"))
    title.add_run("目录")
    p = doc.paragraphs[1] if len(doc.paragraphs) > 1 else doc.add_paragraph()
    _add_field(p, f'TOC \\o "1-{args.levels}" \\h \\z \\u', "（在 Word/WPS 里右键『更新域』或按 F9 生成目录）")
    doc.save(args.out)
    has_heading = any((p.style.name or "").startswith("Heading") or (p.style.name or "").startswith("标题")
                      for p in doc.paragraphs)
    print(f"✅ 已插入自动目录 → {args.out}（收录 1–{args.levels} 级标题）")
    print("   ⚠️ 目录内容与页码由 Word/WPS 计算：用 Office 打开 → 右键『更新域』→ 更新整个目录")
    if not has_heading:
        print("   ⚠️ 本文档没有任何标题样式（Heading/标题），生成的目录会是空的——"
              "先用 Word 的「标题 1/2/3」标记章节，或先跑 outline 检查")


def cmd_header(args):
    doc = load_docx(args.file)
    for section in doc.sections:
        hp = (section.header.paragraphs[0] if section.header.paragraphs
              else section.header.add_paragraph())
        hp.text = ""
        hp.alignment = 1
        hp.add_run(args.header)
        fp = (section.footer.paragraphs[0] if section.footer.paragraphs
              else section.footer.add_paragraph())
        fp.text = ""
        fp.alignment = 1
        text = args.footer
        # 把 "第 X 页 / 共 Y 页" 里的 X/Y 换成真正的域
        parts = re.split(r"(X|Y)", text)
        for part in parts:
            if part == "X":
                _add_field(fp, "PAGE", "1")
            elif part == "Y":
                _add_field(fp, "NUMPAGES", "1")
            elif part:
                fp.add_run(part)
        fp.add_run("  ")
        fp.add_run("· ").font.size = None
    doc.save(args.out)
    print(f"✅ 页眉页脚已设置 → {args.out}")
    print(f"   页眉: {args.header or '（空）'}")
    print(f"   页脚: {args.footer}（X/Y 会渲染成「第 X 页 / 共 Y 页」）")
    print("   ⚠️ 页码同样是域，用 Word/WPS 打开后更新域才显示最终数字")


def cmd_pagebreak(args):
    doc = load_docx(args.file)
    count = 0
    for p in doc.paragraphs:
        style = p.style.name or ""
        if style.startswith("Heading") and args.before_titles:
            level = int("".join(ch for ch in style if ch.isdigit()) or 9)
            if level <= args.level:
                p.runs[0].add_break(6) if p.runs else p.add_run().add_break(6)
                count += 1
    doc.save(args.out)
    print(f"✅ 已在 {count} 个标题前插入分页符 → {args.out}")
    if not count:
        print("   （没有匹配到标题，检查 -level 阈值或先给段落套 Heading 样式）")


# ---------------- Markdown → Word ----------------

INLINE = re.compile(r"(\*\*.+?\*\*|`.+?`|\*.+?\*|_.+?_)")


def _add_inline(paragraph, text):
    """把 **粗体** / `代码` / *斜体* 转成对应的 run"""
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            paragraph.add_run(part[2:-2]).bold = True
        elif part.startswith("`") and part.endswith("`") and len(part) > 2:
            r = paragraph.add_run(part[1:-1])
            r.font.name = "Consolas"
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            paragraph.add_run(part[1:-1]).italic = True
        else:
            paragraph.add_run(part)


def md2docx(md_path, out):
    import docx
    from docx.shared import Pt, RGBColor
    if not os.path.exists(md_path):
        die(f"文件不存在 → {md_path}", "请检查路径")
    text = open(md_path, encoding="utf-8", errors="replace").read()
    doc = docx.Document()
    lines = text.splitlines()
    i = 0
    in_code = False
    code_buf = []
    while i < len(lines):
        line = lines[i]
        if line.strip().startswith("```"):
            if in_code:
                p = doc.add_paragraph()
                r = p.add_run("\n".join(code_buf))
                r.font.name = "Consolas"
                r.font.size = Pt(9)
                r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
                code_buf, in_code = [], False
            else:
                in_code = True
            i += 1
            continue
        if in_code:
            code_buf.append(line)
            i += 1
            continue
        if not line.strip():
            i += 1
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            level = len(m.group(1))
            doc.add_heading(m.group(2).strip(), level=min(level, 6))
            i += 1
            continue
        if re.match(r"^\s*\|.*\|\s*$", line) and i + 1 < len(lines) and re.match(r"^\s*\|[\s:|-]+\|\s*$", lines[i + 1]):
            rows = []
            while i < len(lines) and re.match(r"^\s*\|.*\|\s*$", lines[i]):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r"[:\- ]*", c) for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                table = doc.add_table(rows=len(rows), cols=max(len(r) for r in rows))
                table.style = "Table Grid"
                for ri, row in enumerate(rows):
                    for ci, cell in enumerate(row):
                        _add_inline(table.cell(ri, ci).paragraphs[0], cell)
            continue
        m = re.match(r"^\s*[-*+]\s+(.*)$", line)
        if m:
            _add_inline(doc.add_paragraph(style="List Bullet"), m.group(1))
            i += 1
            continue
        m = re.match(r"^\s*(\d+)[.)]\s+(.*)$", line)
        if m:
            _add_inline(doc.add_paragraph(style="List Number"), m.group(2))
            i += 1
            continue
        if re.match(r"^\s*>\s?", line):
            p = doc.add_paragraph()
            _add_inline(p, line.strip().lstrip("> "))
            p.paragraph_format.left_indent = Pt(24)
            i += 1
            continue
        if re.match(r"^\s*(-{3,}|\*{3,})\s*$", line):
            doc.add_paragraph("─" * 40)
            i += 1
            continue
        _add_inline(doc.add_paragraph(), line.strip())
        i += 1
    doc.save(out)
    print(f"✅ Markdown 已转为 Word → {out}")
    print(f"   源文件: {md_path}（{len(lines)} 行）")


def main():
    p = argparse.ArgumentParser(description="Word 增强工具（大纲/目录/页眉页脚/Markdown 转换）")
    sub = p.add_subparsers(dest="cmd", required=True)
    o = sub.add_parser("outline"); o.add_argument("file")
    t = sub.add_parser("toc"); t.add_argument("file"); t.add_argument("-o", dest="out", required=True)
    t.add_argument("-levels", type=int, default=3)
    h = sub.add_parser("header"); h.add_argument("file"); h.add_argument("-o", dest="out", required=True)
    h.add_argument("-header", default=""); h.add_argument("-footer", default="第 X 页 / 共 Y 页")
    b = sub.add_parser("pagebreak"); b.add_argument("file"); b.add_argument("-o", dest="out", required=True)
    b.add_argument("-level", type=int, default=1); b.add_argument("-before-titles", action="store_true", default=True)
    m = sub.add_parser("md2docx"); m.add_argument("file"); m.add_argument("-o", dest="out", required=True)
    args = p.parse_args()
    for _k in ("out", "o"):
        _p = getattr(args, _k, None)
        if _p:
            _ensure_parent(_p)
    try:
        if args.cmd == "outline":
            cmd_outline(args)
        elif args.cmd == "toc":
            cmd_toc(args)
        elif args.cmd == "header":
            cmd_header(args)
        elif args.cmd == "pagebreak":
            cmd_pagebreak(args)
        elif args.cmd == "md2docx":
            md2docx(args.file, args.out)
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()