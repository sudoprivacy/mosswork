#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
旧版 Office 格式转换（Office Doc Suite）
把老格式转成新格式，交给主工具处理。

支持：
  .xls  -> .xlsx   （用 xlrd 读取旧 Excel，转成 openpyxl 可处理的 .xlsx；纯 pip，跨平台）
  .doc  -> .docx   （若电脑装了 LibreOffice 则自动转；没装则给一句明确转换引导）

用法：
  python convert_legacy.py in.xls -o out.xlsx
  python convert_legacy.py in.doc -o out.docx
  python convert_legacy.py auto in.xls          # 自动按扩展名转，输出到 in.xlsx / in.docx
"""
import sys
import os
import shutil
import subprocess

try:
    from error_codes import tag as _tag, fmt as _fmt   # 错误 ID 注册表（scripts/error_codes.py）
except Exception:  # 脚本被单独拷贝出去时也能跑
    def _tag(code, msg):
        return f"[{code}] {msg}"

    def _fmt(code, msg, hint=None):
        return f"❌ 错误 {_tag(code, msg)}" + (f"\n   处理: {hint}" if hint else "")


def _msg(text):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print(text)


# ---------------- .xls -> .xlsx ----------------
def convert_xls_to_xlsx(xls_path, out_path=None):
    try:
        import xlrd
    except ImportError:
        _msg(_fmt("ODS-E09", "读旧版 .xls 需要先补装一个小组件",
                  "在命令行执行  pip install xlrd  然后再试一次（.xlsx 文件不需要装）"))
        sys.exit(2)

    out_path = out_path or os.path.splitext(xls_path)[0] + ".xlsx"
    if os.path.abspath(out_path) == os.path.abspath(xls_path):
        _msg("❌ 输出路径不能和输入相同，请用 -o 指定新文件名（如 out.xlsx）")
        sys.exit(2)

    try:
        book = xlrd.open_workbook(xls_path, formatting_info=False)
    except Exception as e:
        _msg(f"❌ 读取 .xls 失败：{e}（可能不是有效的 .xls 文件，请确认扩展名）")
        sys.exit(2)

    try:
        import openpyxl
    except ImportError:
        _msg("❌ 还差一个小组件，才能写出 .xlsx 文件\n   处理: 在命令行执行  pip install 'openpyxl>=3.1'  然后再试一次")
        sys.exit(2)

    out_book = openpyxl.Workbook()
    out_book.remove(out_book.active)
    total_rows = 0
    for sheet in book.sheets():
        ws = out_book.create_sheet(title=sheet.name[:31])
        for r in range(sheet.nrows):
            row = []
            for c in range(sheet.ncols):
                row.append(_xlrd_to_py(sheet.cell_value(r, c)))
            # filter trailing empty cells
            while row and (row[-1] is None or row[-1] == ""):
                row.pop()
            for c, v in enumerate(row):
                ws.cell(row=r + 1, column=c + 1, value=v)
            total_rows += 1
    from xlsx_tool import save_workbook
    save_workbook(out_book, out_path)
    _msg(f"✅ 已转换：{os.path.basename(xls_path)} -> {os.path.basename(out_path)}（{len(book.sheets())} 个工作表，共 {total_rows} 行）")
    _msg("   现在可以用 xlsx_tool.py 处理这个 .xlsx 了。")
    return out_path


def _xlrd_to_py(v):
    # xlrd returns value already; normalize empty & boundaries
    if v is None:
        return None
    try:
        f = float(v)
        if f == int(f):
            return int(f)
        return f
    except (ValueError, TypeError):
        return v


# ---------------- .doc -> .docx ----------------
def _find_soffice():
    cands = [
        shutil.which("soffice"), shutil.which("libreoffice"),
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        "/usr/bin/soffice", "/usr/local/bin/soffice",
    ]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return None


def convert_doc_to_docx(doc_path, out_path=None):
    soffice = _find_soffice()
    if not soffice:
        _msg("❌ 这是旧版 .doc 文件，本套件不能直接转换，这台电脑也没装能转它的软件。")
        _msg("   请先用 Word 或 WPS 打开这个 .doc，点「另存为」选择 .docx，再重新处理。")
        _msg("   两个办法，任选一个：\n"
             "     ①（推荐，不用装东西）用 Word 或 WPS 打开它，「另存为」选 .docx，再把 .docx 给我；\n"
             "     ② 装一个免费软件 LibreOffice（https://www.libreoffice.org），装好后本套件会自动用它转换")
        sys.exit(2)

    out_dir = os.path.dirname(os.path.abspath(doc_path))
    try:
        r = subprocess.run(
            [soffice, "--headless", "--convert-to", "docx", "--outdir", out_dir, doc_path],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180,
        )
    except Exception as e:
        _msg("❌ 用 LibreOffice 转换失败。\n   处理: 先用 Word/WPS 打开这个文件确认没损坏；仍不行就用 Word/WPS 另存为 .docx")
        sys.exit(2)

    base = os.path.splitext(os.path.basename(doc_path))[0]
    produced = os.path.join(out_dir, base + ".docx")
    if os.path.isfile(produced):
        target = out_path or produced
        if os.path.abspath(target) != os.path.abspath(produced):
            shutil.copy(produced, target)
        _msg(f"✅ 已转换完成（用了 LibreOffice）：{os.path.basename(doc_path)} → {os.path.basename(target)}")
        _msg("   现在可以用 docx_tool.py 处理这个 .docx 了。")
        return target
    else:
        _msg("❌ LibreOffice 没有转出文件（常见原因：它被其它窗口占用，或原文件有损坏）\n"
             "   处理: 关掉所有 Word/WPS/LibreOffice 窗口后重试；仍不行就用 Word/WPS 另存为 .docx")
        sys.exit(2)


# ---------------- main ----------------
def main():
    if len(sys.argv) < 2:
        # 踩坑记录（2026-10-09）：这里原来是裸 print，绕过了 _msg() 里的 UTF-8 重设，
        # 默认 locale（中文 Windows=GBK）下输出非 UTF-8，Agent 侧解码即乱码。
        _msg(__doc__)
        return
    src = sys.argv[1]
    out = None
    if "-o" in sys.argv:
        i = sys.argv.index("-o")
        if i + 1 < len(sys.argv):
            out = sys.argv[i + 1]

    if not os.path.isfile(src):
        # 带错误编号（2026-10-09 真机测得：这里原来只打一句中文，缺 ODS 编号，
        # 与全项目"报错必带编号"的约定不一致）
        hint = "这是一个目录，不是文件" if os.path.isdir(src) else "确认路径拼写；Windows 路径含空格要用双引号包起来"
        _msg(f"❌ 错误 [ODS-E01] 文件不存在或不是文件 → {src}\n   处理: {hint}")
        sys.exit(1)

    ext = os.path.splitext(src)[1].lower()
    if ext == ".xls":
        convert_xls_to_xlsx(src, out)
    elif ext == ".doc":
        convert_doc_to_docx(src, out)
    elif ext in (".xlsx", ".docx"):
        _msg("ℹ️  这已经是新格式，无需转换，直接用主工具处理即可。")
    else:
        _msg(_fmt("ODS-E17", f"不支持的旧格式：{ext}。本套件可转 .xls -> .xlsx、.doc -> .docx。"))
        sys.exit(1)   # 失败必须非零退出，否则 Agent 会当成转换成功（2026-10-09 修）


if __name__ == "__main__":
    main()
