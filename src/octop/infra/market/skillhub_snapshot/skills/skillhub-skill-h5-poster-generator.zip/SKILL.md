---
name: skillhub-skill-h5-poster-generator
description: "根据一句话描述生成炫酷的动态 H5 海报 / 邀请函 / 宣传页 / 请柬 / 活动页 / 产品促销页 / 企业宣传页。当用户说\"生成海报\"\"做个动态海报\"\"做张请柬\"\"婚礼邀请函\"\"活动宣传页\"\"产品促销海报\"\"企业宣传H5\"\"生日邀请\"\"年会邀请\"\"课程招生海报\"\"开业海报\"等，或描述里出现\"炫酷/动态背景/倒计时/报名表单/二维码/分享/邀请\"等诉求，自动加载本技能。产出为自包含单文件 HTML（零依赖、离线可跑、可发给任何人），动态背景由 AI 实时生成。"
---

# H5 动态海报生成器（技能开放版 v1.0.2）

## Overview

把「一段文字描述」变成一张可直接打开/分享的炫酷动态 H5 页面。和原版 EXE 同源，但做成
**开放技能**：不绑定任何机器、不需要授权码、不内置素材。动态背景在你对话时由 AI 用
ImageGen / VideoGen 实时生成，再塞进海报。

产物是**单文件、自包含、零外部依赖**的 HTML：粒子流、动态背景、光影文字、倒计时、
背景音乐、报名表单、二维码、地图导航等全部在文件内原生实现，离线也能跑，小白双击即看。

## When to use

- 用户要「生成/做个 H5 海报、动态海报、邀请函、请柬、活动页、宣传页、促销页、企业宣传」。
- 用户描述里出现「炫酷 / 动态背景 / 倒计时 / 报名 / 扫码 / 邀请」等诉求。
- 用户想把活动、产品、品牌、企业、节日做成可传播的移动端页面。

## Workflow

不要跳过抽参；但用户描述已具体时不必反复追问。

### 1. 抽取结构化参数
从描述提炼（缺失关键项用 `AskUserQuestion` 补一轮，最多 1 轮）：
- `category`：从 `references/design-system.md` 的 49 分类选最贴合的 key（拿不准用 `wedding`/`meeting`）。
- 文案：`title`(≤12字) / `subtitle`(≤20字) / `kicker` / `date` / `location` / `content` / `footerNote`。
- `features[]`：勾选即加、不堆砌——`form`(报名) / `like`(点赞) / `comment`(留言墙) /
  `qr`(二维码,需`--qr-target`) / `share`(分享) / `music`(音乐,需`--music`) /
  `countdown`(倒计时,需`--countdown-target`) / `map`(地图导航)。
- **背景场景**：用户说的场景（婚礼/商务/旅游…）对应 `references/scenes.md` 的场景名。

### 2. 生成动态背景（关键，AI 实时产出）
- 按场景从 `references/scenes.md` 取 **ImageGen** 提示词 → 生成竖版静图（750×1334）。
- 用户要「动态 / 会动」背景 → 再取 **VideoGen** 提示词生成同场景短视频。
- 把生成的图/视频**保存为本地文件**，记住路径。
- ⚠️ 铁律：画面中**绝对不能出现文字、标志、数字、水印、字幕**，否则重生成。

### 3. 产出 HTML
**方式 A（推荐，零依赖主路径）**：调 `scripts/generate.py` 把参数 + 素材组装成 HTML：

```
python <技能目录>/scripts/generate.py \
  --category wedding --title "我们结婚啦" --subtitle "诚邀见证幸福时刻" \
  --bg-video "<VideoGen生成的mp4路径>" --bg-image "<ImageGen生成的jpg路径>" \
  --features form,comment,qr --qr-target "https://your-link" \
  --out "<工作区>/h5-posters/请柬.html"
```

参数明细见 `scripts/generate.py` 头部注释与 `references/design-system.md`。
产出后用 `present_files` 打开预览，确认渲染正常、按钮可点、视频会动。

**方式 B（可视化增强，需 Python）**：有 Python 环境的用户可
`python <技能目录>/scripts/serve.py [端口]` 起本地服务，打开和 EXE 同款的管理界面编辑。

### 4. 交付与分享
- 自包含 HTML 可双击打开、可发微信/邮件/网盘，任何人离线可看。
- 要公网分享：用「发布为应用」技能把 HTML 发布成网址（**本技能不内置隧道**，跨平台更稳）。

## Resources

- **`engine/`**：完整生成引擎（Python 标准库 + 可选 `qrcode`），`generator.build_poster(theme)`
  输出自包含 HTML。从原 EXE 提炼，**已去除授权门禁，开放使用**。
- **`scripts/generate.py`**：命令行生成器，自动把图片/视频转 base64 内联。
- **`scripts/serve.py`**：本地服务入口（可选增强模式）。
- **`assets/particle-engine.js`**：粒子引擎，生成时自动内联进产物。
- **`references/scenes.md`**：13 个场景的 ImageGen/VideoGen 提示词映射表（AI 生成背景用）。
- **`references/design-system.md`**：49 分类、10 配色家族、功能模块、产物形态。

## Notes

- **零依赖主路径**：方式 A 下 AI 直接产出 HTML，用户无需装任何东西。
- **前置（仅方式 B / 二维码）**：本地服务或真二维码需 `Python 3.8+`；二维码额外
  `pip install qrcode`（没装时二维码功能自动跳过，不报错）。
- **开放授权**：技能已去授权码，任何人安装即用，可上架分享。
- **铁律**：生成的背景图/视频不得含任何文字/水印，违者重生成。
- **一张海报一件事**：信息过载降低美感与转化，功能按需不多加。

## 更新说明（v1.0.2 · 相对上一版 v1.0.1）

### 🔒 安全修复（来自安全审查）
- **彻底移除授权模块 `engine/licensing.py`**：删除机器码采集（主机名/MAC 哈希）与对 `license.tsetch.com` 的联网激活逻辑，及 `/api/license/*` 路由——使实现与「不绑定机器、不采集机器码」的开放声明一致。
- **管理台与管理类 API 加固**：管理台（`manage.html`）、`/api/posts*`、`/api/tunnel*`、`/api/mch*`、`/api/generate` 等仅限本机回环地址访问；通过隧道映射到公网时一律 403，公网只放行海报页 `/p/<id>`、访客埋点 `/api/track` 与红包访客接口 `/api/rp/*`。持公开链接者无法再读取报名/留言数据或调用删除、重置等管理操作。
- **新增本地管理令牌**：每次启动随机生成，打印到控制台并写入 `data/local_token.txt`，管理台访问需回环地址或 `?token=` 令牌。
- **`SKILL.md` 如实披露**：新增「安全与发布行为说明」章节，说明本地服务监听范围、令牌机制与隧道公网暴露面。

### 📦 版本号
- **版本号升级**：`v1.0.1` → `v1.0.2`；`web.py` 服务标识同步改为 `H5Poster/1.0.2`。

## 历史更新记录

### v1.0.1 · 相对上一版 v1.0.0

### 🆕 架构重构：静态模板 → 动态生成引擎
- **新增 `engine/`**（7 个模块：生成器 / 二维码 / 配置 / 隧道 / 本地服务等），与 EXE 同源，`generator.build_poster()` 一键输出自包含 HTML；替代 v1.0.0「5 个静态模板 + 手工注入引擎」的拼装方式。
- **新增 `scripts/generate.py`**：命令行主路径，一条命令把参数 + 背景素材组装成 HTML，自动把图片/视频转 base64 内联。
- **新增 `scripts/serve.py` + `webroot/`**：与 EXE 同款的本地可视化管理界面（可选增强模式）。
- **移除** `assets/templates/`（5 个骨架）、`scripts/inject_engine.py`、`scripts/make_qr.py`——能力已并入引擎与 generate.py，不再需要。

### 🎬 新增：AI 实时动态背景（v1.0.0 完全没有此能力）
- 新增 `references/scenes.md`（13 场景 × ImageGen/VideoGen 提示词），背景图/视频由 AI 在对话中现场生成再内联进海报。
- 技能**零素材打包**：不内置任何图片/视频，包体更小、无版权负担，背景按需生成。

### 🐛 修复（源自 EXE 实测反馈）
- **动态背景不再溢出/变形**：背景层从窗口 `fixed` 改为手机框（520px）内 `absolute` + 负 z-index，粒子/遮罩/背景三层严格限制在手机框内。
- **视频背景加载不再全黑**：视频分支同步设置静态图 `poster` 兜底。

### 📈 扩容
- 分类从 **5 大类 → 49 个**场景分类；配色从简单色表升级为 **10 个配色家族**。
- 功能模块新增 `like` 点赞 / `comment` 留言墙 / `map` 地图导航（v1.0.0 仅倒计时 / 音乐 / 表单 / 分享 / 二维码）。

### 🔓 开放与合规
- **完全开放、无授权门禁**：不采集机器码、不联网激活，任何人安装即用，可上架分享。
- **二维码改用通用 `qrcode` 库**：删除写死的本地 venv 绝对路径，跨机器可用。
- **补齐开放平台必填 frontmatter**：`version` / `display_name` / `display_name_en` / `description_zh` / `description_en`。
- **版本号升级**：`1.0.0` → `v1.0.1`。

## 安全与发布行为说明

### 本地服务（方式 B，`serve.py`）
- 只监听 `127.0.0.1`，不对外网卡开放。
- 管理台（`manage.html` 及 `/api/*` 管理类接口）**仅限本机回环地址访问**。
- 启动时生成一次性管理令牌，打印到控制台并写入 `data/local_token.txt`；浏览器自动带 `?token=` 打开，也可手动在地址栏拼 `?token=<令牌>` 访问。未持令牌的非本机请求一律 403。

### 公网一键发布（cloudflared 隧道）
- 「一键发布」把海报通过 Cloudflare quick/named tunnel 映射为公网链接，**只对外暴露**：
  - 海报页本身：`/p/<id>`
  - 访客互动埋点接口：`/api/track`
  - 红包抽奖接口：`/api/rp/captcha`、`/api/rp/grab`（访客功能）
- 管理台、海报数据接口（`/api/posts*`）、隧道配置接口（`/api/tunnel*`）、商户配置（`/api/mch*`）、生成接口（`/api/generate`）等**管理类 API 一律拒绝公网访问**，即使拿到公开链接的人也无法读取报名/留言数据，或调用删除、重置等管理操作。
- 访客在海报里提交的报名、留言、点赞等互动数据，只保存在作者本机 SQLite 数据库，公网访客**无法反向读取**，只有作者在管理台查看。
