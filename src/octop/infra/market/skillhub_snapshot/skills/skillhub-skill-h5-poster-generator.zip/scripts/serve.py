# -*- coding: utf-8 -*-
"""H5 海报技能 · 本地服务入口（可选增强模式）。

起一个本地 Web 服务，打开和 EXE 同款的可视化管理界面。
适合想用界面可视化选素材/填内容的用户；纯对话生成请用 scripts/generate.py。

前置：Python 3.8+（标准库即可，二维码需 pip install qrcode）。
用法：python serve.py [端口]   （默认 8765）
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(HERE)
sys.path.insert(0, SKILL_ROOT)

from engine import web

if __name__ == "__main__":
    port = 8765
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    print("H5 海报技能 · 本地服务已启动")
    print("浏览器打开: http://127.0.0.1:%d/" % port)
    print("提示：背景素材由 AI 在对话中实时生成（界面'背景素材'区仅作示意）。")
    web.run(port=port, open_browser=False)
