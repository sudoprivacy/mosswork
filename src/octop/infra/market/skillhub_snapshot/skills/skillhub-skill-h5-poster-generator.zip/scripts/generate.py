# -*- coding: utf-8 -*-
"""H5 海报技能 · 命令行生成器（主路径）。

把抽好的参数 + AI 生成的背景素材（图片/视频文件）组装成自包含 HTML。
背景素材可以是 ImageGen / VideoGen 生成的本地文件，脚本自动转 base64 内联，
产出的 HTML 可独立发给任何人离线打开。

用法：
  python generate.py --category wedding --title "我们结婚啦" \
      --bg-video ./bg.mp4 --bg-image ./bg.jpg --out poster.html

参数说明：
  --category      分类 key（见 references/scenes.md 或 /api/meta），如 wedding/business/travel
  --title/--subtitle/--kicker/--date/--location/--content/--footer-note  文案
  --accent/--accent2  主色（如 #ff5e8a），不填用分类默认
  --bg-image      静态背景图路径（jpg/png），自动 base64 内联
  --bg-video      动态背景视频路径（mp4），自动 base64 内联（优先于 --bg-image）
  --features      功能逗号列表：form,like,comment,qr,share,music,countdown
  --qr-target     二维码指向的链接（features 含 qr 时填）
  --music         背景音乐链接/路径（features 含 music 时填）
  --countdown-target  倒计时目标时间（features 含 countdown 时填，如 2026-12-20 18:00）
  --out           输出 HTML 路径（默认 ./h5-posters/<标题>.html）
"""
import argparse
import base64
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(HERE)  # scripts/ 的上级 = 技能根
sys.path.insert(0, SKILL_ROOT)

from engine import generator


def file_data_url(path):
    if not path or not os.path.exists(path):
        return ""
    ext = os.path.splitext(path)[1].lower()
    mime = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
            "mp4": "video/mp4", "webm": "video/webm"}.get(ext, "application/octet-stream")
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return "data:%s;base64,%s" % (mime, b64)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--category", default="wedding")
    ap.add_argument("--title", default="")
    ap.add_argument("--subtitle", default="")
    ap.add_argument("--kicker", default="")
    ap.add_argument("--date", default="")
    ap.add_argument("--location", default="")
    ap.add_argument("--content", default="")
    ap.add_argument("--footer-note", default="")
    ap.add_argument("--accent", default="")
    ap.add_argument("--accent2", default="")
    ap.add_argument("--bg-image", default="")
    ap.add_argument("--bg-video", default="")
    ap.add_argument("--features", default="")
    ap.add_argument("--qr-target", default="")
    ap.add_argument("--music", default="")
    ap.add_argument("--countdown-target", default="")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    img = file_data_url(args.bg_image)
    vid = file_data_url(args.bg_video)

    if vid:
        bg = {"type": "video", "videoSrc": vid}
        if img:
            bg["image"] = img  # 静态图作视频未播时的兜底
    elif img:
        bg = {"type": "image", "image": img}
    else:
        bg = {"type": "gradient"}

    feats = [f.strip() for f in args.features.split(",") if f.strip()]

    theme = {
        "category": args.category,
        "title": args.title,
        "subtitle": args.subtitle,
        "kicker": args.kicker,
        "date": args.date,
        "location": args.location,
        "content": args.content,
        "footerNote": args.footer_note,
        "accent": args.accent,
        "accent2": args.accent2,
        "bg": bg,
        "features": feats,
    }
    if "qr" in feats and args.qr_target:
        theme["qrTarget"] = args.qr_target
    if "music" in feats and args.music:
        theme["musicUrl"] = args.music
    if "countdown" in feats and args.countdown_target:
        theme["countdown"] = {"enabled": True, "target": args.countdown_target}

    html = generator.build_poster(theme)
    out = args.out or os.path.join(os.getcwd(), "h5-posters",
                                   (args.title or "poster") + ".html")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)
    print("OK %s (%d bytes)" % (out, len(html)))


if __name__ == "__main__":
    main()
