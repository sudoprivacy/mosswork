# -*- coding: utf-8 -*-
"""海报生成器：把表单参数拼装成自包含 HTML（内联引擎 + 埋点）。"""
import io
import os
import sys
import json
from urllib.parse import quote as _quote

from . import paths
from . import copybank

ENGINE_PATH = os.path.join(paths.base_dir(), "assets", "particle-engine.js")

PARTICLE_PRESETS = [
    "flow", "constellation", "snow", "burst", "spark",
    "starfield", "fireworks", "petals", "bubbles", "bokeh", "nebula", "rain", "matrix",
]

def _hex_to_rgb(h):
    h = (h or "").strip().lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    if len(h) != 6:
        return (255, 255, 255)
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except Exception:
        return (255, 255, 255)


# ---------------- 配色家族（多个模板类型共用一套视觉基调） ----------------
FAMILIES = {
    "business-blue": dict(accent="#2f6bff", accent2="#7fd1ff", gc1="#0f2027", gc2="#1e3c72", gc3="#2a5298", angle=135,
        headC="#071634", headA=40, headT="#eaf2ff", bodyC="#ffffff", bodyA=7, bodyT="#e9f1fb", footC="#071634", footA=30, footT="#eaf2ff",
        pmode="flow", pc1="#ffffff", pc2="#9fd3ff", pspeed=0.6),
    "red-gold": dict(accent="#e63946", accent2="#ffd6a5", gc1="#4a0d0d", gc2="#9e1b1b", gc3="#c1121f", angle=160,
        headC="#5a0f0f", headA=34, headT="#ffe8d6", bodyC="#ffffff", bodyA=8, bodyT="#fff2e2", footC="#5a0f0f", footA=28, footT="#ffe8d6",
        pmode="fireworks", pc1="#ffd86b", pc2="#ff7eb3", pspeed=1.8),
    "gold-lux": dict(accent="#d4af37", accent2="#f7e9c6", gc1="#0d0d0d", gc2="#1c1c1c", gc3="#2b2b2b", angle=160,
        headC="#000000", headA=28, headT="#f7e9c6", bodyC="#d4af37", bodyA=8, bodyT="#f3ead6", footC="#000000", footA=20, footT="#f7e9c6",
        pmode="spark", pc1="#d4af37", pc2="#fff3c4", pspeed=0.7),
    "romance-pink": dict(accent="#ff5e8a", accent2="#ffd6e8", gc1="#2a0f1c", gc2="#6b2140", gc3="#b0526f", angle=150,
        headC="#3a1220", headA=34, headT="#ffe3ee", bodyC="#ffffff", bodyA=8, bodyT="#ffeaf3", footC="#3a1220", footA=26, footT="#ffe3ee",
        pmode="petals", pc1="#ffd1e8", pc2="#ffb3d9", pspeed=0.7),
    "tech-dark": dict(accent="#22d3ee", accent2="#5ea8ff", gc1="#05070f", gc2="#0b1220", gc3="#131c2e", angle=135,
        headC="#060a14", headA=42, headT="#dff3ff", bodyC="#ffffff", bodyA=6, bodyT="#e6f4ff", footC="#060a14", footA=32, footT="#dff3ff",
        pmode="matrix", pc1="#39ff14", pc2="#7dffb0", pspeed=1.0),
    "fresh-green": dict(accent="#16a34a", accent2="#86efac", gc1="#06281c", gc2="#0f5132", gc3="#148f5a", angle=140,
        headC="#07281c", headA=34, headT="#e7fff2", bodyC="#ffffff", bodyA=8, bodyT="#eafff3", footC="#07281c", footA=26, footT="#e7fff2",
        pmode="bubbles", pc1="#bfefff", pc2="#d9f7ff", pspeed=0.55),
    "orange-energy": dict(accent="#ff6b35", accent2="#ffd86b", gc1="#2a0d00", gc2="#7a1e00", gc3="#c2410c", angle=135,
        headC="#2a0d00", headA=34, headT="#ffe9d2", bodyC="#ffffff", bodyA=8, bodyT="#fff0e0", footC="#2a0d00", footA=26, footT="#ffe9d2",
        pmode="burst", pc1="#ffd86b", pc2="#ff7eb3", pspeed=1.4),
    "purple-dream": dict(accent="#a855f7", accent2="#e9d5ff", gc1="#16002b", gc2="#3b0764", gc3="#6b21a8", angle=150,
        headC="#1a0533", headA=38, headT="#f3e8ff", bodyC="#ffffff", bodyA=7, bodyT="#f5ecff", footC="#1a0533", footA=30, footT="#f3e8ff",
        pmode="nebula", pc1="#a18cd1", pc2="#ff7eb3", pspeed=0.1),
    "ink-cn": dict(accent="#b08968", accent2="#e6ccb2", gc1="#0b1410", gc2="#1f2d24", gc3="#33513f", angle=150,
        headC="#0b1410", headA=40, headT="#eae3d2", bodyC="#f5efe6", bodyA=12, bodyT="#2a2620", footC="#0b1410", footA=30, footT="#eae3d2",
        pmode="rain", pc1="#cdb9a3", pc2="#e6ccb2", pspeed=1.2),
    "minimal-light": dict(accent="#334155", accent2="#94a3b8", gc1="#e2e8f0", gc2="#f1f5f9", gc3="#ffffff", angle=135,
        headC="#ffffff", headA=70, headT="#1e293b", bodyC="#ffffff", bodyA=55, bodyT="#334155", footC="#ffffff", footA=70, footT="#475569",
        pmode="snow", pc1="#ffffff", pc2="#cbd5e1", pspeed=0.5),
}


def _rgba_str(hexc, alpha):
    r, g, b = _hex_to_rgb(hexc)
    return "rgba(%d,%d,%d,%.2f)" % (r, g, b, alpha / 100.0)


# ---------------- 模板类型（来源：易企秀/人人秀等主流平台场景分类） ----------------
CATEGORIES = [
    # group, key, label, family, kicker
    ("邀请函 / 会展", "expo", "展会邀请函", "business-blue", "展会邀请"),
    ("邀请函 / 会展", "meeting", "商务会议邀请", "business-blue", "会议邀请"),
    ("邀请函 / 会展", "opening", "开业邀请函", "red-gold", "开业大吉"),
    ("邀请函 / 会展", "anniversary", "周年庆邀请", "red-gold", "周年庆典"),
    ("邀请函 / 会展", "summit", "峰会论坛邀请", "business-blue", "峰会论坛"),
    ("邀请函 / 会展", "franchise", "招商加盟邀请", "orange-energy", "招商加盟"),
    ("邀请函 / 会展", "annual", "年会邀请函", "red-gold", "年度盛典"),
    ("邀请函 / 会展", "nonprofit", "公益活动邀请", "fresh-green", "公益同行"),
    ("邀请函 / 会展", "parent", "家长会邀请", "fresh-green", "家长会"),
    ("邀请函 / 会展", "housewarming", "乔迁喜宴", "red-gold", "乔迁之喜"),
    ("邀请函 / 会展", "reunion", "同学会 / 校友会", "minimal-light", "青春不散场"),
    ("婚礼 / 生活", "wedding", "婚礼邀请函", "romance-pink", "婚礼请柬"),
    ("婚礼 / 生活", "birthday", "生日会邀请", "romance-pink", "生日派对"),
    ("婚礼 / 生活", "baby100", "百日宴邀请", "romance-pink", "百日之喜"),
    ("婚礼 / 生活", "greeting", "祝福贺卡", "romance-pink", "祝福"),
    ("婚礼 / 生活", "album", "相册(毕业/旅行/宝宝)", "minimal-light", "时光相册"),
    ("婚礼 / 生活", "daily", "日签 / 语录", "minimal-light", "每日一签"),
    ("企业 / 品牌", "company", "公司简介 / 企业宣传", "business-blue", "关于我们"),
    ("企业 / 品牌", "brochure", "企业宣传册", "gold-lux", "品牌手册"),
    ("企业 / 品牌", "brandlaunch", "品牌发布", "purple-dream", "品牌发布"),
    ("企业 / 品牌", "productlaunch", "新品发布", "purple-dream", "新品发布"),
    ("企业 / 品牌", "microsite", "微官网", "minimal-light", "官方网站"),
    ("营销 / 电商", "promo", "产品促销", "orange-energy", "限时优惠"),
    ("营销 / 电商", "seckill", "秒杀 / 大促", "orange-energy", "限时秒杀"),
    ("营销 / 电商", "ecom", "电商带货", "orange-energy", "好物推荐"),
    ("营销 / 电商", "retail", "商超 / 零售", "orange-energy", "超级购物节"),
    ("招聘 / 教育", "recruit", "企业招聘", "business-blue", "诚聘英才"),
    ("招聘 / 教育", "campus", "校园招聘", "fresh-green", "校园招聘"),
    ("招聘 / 教育", "resume", "个人简历 / 名片", "minimal-light", "个人简介"),
    ("招聘 / 教育", "enroll", "招生简章", "fresh-green", "招生啦"),
    ("招聘 / 教育", "course", "课程培训报名", "fresh-green", "课程报名"),
    ("招聘 / 教育", "camp", "冬夏令营招募", "fresh-green", "营地招募"),
    ("金融 / 医疗", "finance", "理财宣传", "gold-lux", "理财课堂"),
    ("金融 / 医疗", "report", "业绩喜报 / 数据报告", "business-blue", "业绩报告"),
    ("金融 / 医疗", "survey", "调研问卷", "business-blue", "有奖调研"),
    ("金融 / 医疗", "health", "健康科普", "fresh-green", "健康科普"),
    ("金融 / 医疗", "medical", "医学会议 / 义诊", "business-blue", "学术会议"),
    ("行业专题", "realestate", "地产 / 楼盘", "gold-lux", "臻品楼盘"),
    ("行业专题", "auto", "汽车", "tech-dark", "新品车型"),
    ("行业专题", "food", "餐饮 / 美食", "orange-energy", "美食地图"),
    ("行业专题", "beauty", "美容 / 美妆", "purple-dream", "焕新之旅"),
    ("行业专题", "travel", "旅游 / 文旅", "fresh-green", "诗和远方"),
    ("行业专题", "digital", "数码 / 家电", "tech-dark", "数码新品"),
    ("行业专题", "pet", "宠物", "romance-pink", "毛孩子之家"),
    ("行业专题", "inkcn", "国风 / 中式 / 文旅", "ink-cn", "东方美学"),
    ("互动 / 游戏", "vote", "投票评选", "business-blue", "投票评选"),
    ("互动 / 游戏", "contest", "比赛 / 大赛", "orange-energy", "大赛报名"),
    ("互动 / 游戏", "lotterycat", "抽奖活动", "red-gold", "幸运抽奖"),
    ("互动 / 游戏", "game", "互动游戏", "tech-dark", "玩个游戏"),
]


def _mk_default(fam_key, kicker):
    f = FAMILIES[fam_key]
    return dict(
        kicker=kicker, accent=f["accent"], accent2=f["accent2"],
        gradient=[f["gc1"], f["gc2"], f["gc3"]], angle=f["angle"],
        head=(_rgba_str(f["headC"], f["headA"]), f["headT"]),
        body=(_rgba_str(f["bodyC"], f["bodyA"]), f["bodyT"]),
        foot=(_rgba_str(f["footC"], f["footA"]), f["footT"]),
        mode=f["pmode"], pcolors=[f["pc1"], f["pc2"]], pspeed=f["pspeed"],
    )


CATEGORY_DEFAULTS = {key: _mk_default(fam, kicker) for (_g, key, _l, fam, kicker) in CATEGORIES}


def meta():
    return {
        "categories": [{"key": k, "label": l, "group": g, "kicker": kk, "family": f} for (g, k, l, f, kk) in CATEGORIES],
        "defaults": {k: dict(accent=v["accent"], accent2=v["accent2"],
                             gradient=v["gradient"], angle=v["angle"],
                             pmode=v["mode"], pc1=v["pcolors"][0], pc2=v["pcolors"][1], pspeed=v["pspeed"],
                             headC=_first_hex(v["head"][0]), headA=_alpha_of(v["head"][0]), headT=v["head"][1],
                             bodyC=_first_hex(v["body"][0]), bodyA=_alpha_of(v["body"][0]), bodyT=v["body"][1],
                             footC=_first_hex(v["foot"][0]), footA=_alpha_of(v["foot"][0]), footT=v["foot"][1])
                     for k, v in CATEGORY_DEFAULTS.items()},
        # 文案素材库：每个分类的现成文案（key 与 categories 一一对应）
        "copy": copybank.COPY_BANK,
    }


def _first_hex(rgba_str):
    import re
    m = re.match(r"rgba\((\d+),(\d+),(\d+)", rgba_str or "")
    if not m:
        return "#000000"
    return "#%02x%02x%02x" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))


def _alpha_of(rgba_str):
    import re
    m = re.search(r",\s*([\d.]+)\)\s*$", rgba_str or "")
    return int(round(float(m.group(1)) * 100)) if m else 100


_GEO_CACHE_FILE = os.path.join(paths.data_dir(), "geocache.json")


def _geocode(addr):
    """地址 → (lat, lon)。用 Nominatim 免费接口（免 key），结果缓存本地；失败返回 None。"""
    addr = (addr or "").strip()
    if not addr:
        return None
    # 读缓存
    cache = {}
    try:
        with open(_GEO_CACHE_FILE, encoding="utf-8") as f:
            cache = json.load(f)
    except Exception:
        pass
    if addr in cache:
        v = cache[addr]
        return (v[0], v[1]) if v else None
    try:
        import urllib.request
        url = ("https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=zh&q="
               + _urlq(addr))
        req = urllib.request.Request(url, headers={"User-Agent": "H5PosterDesktop/0.5"})
        with urllib.request.urlopen(req, timeout=6) as r:
            data = json.loads(r.read().decode("utf-8"))
        if data:
            v = (float(data[0]["lat"]), float(data[0]["lon"]))
        else:
            v = None
    except Exception:
        v = None
    # 写缓存（解析失败也缓存，避免每次生成都被同一个地址拖慢）
    try:
        cache[addr] = v
        os.makedirs(os.path.dirname(_GEO_CACHE_FILE), exist_ok=True)
        with open(_GEO_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False)
    except Exception:
        pass
    return v


def qr_png(text):
    """生成二维码，返回 PNG 原始字节；失败返回 b\"\"。"""
    if not text:
        return b""
    try:
        import qrcode
        img = qrcode.make(text, box_size=8, border=2)
        pil = img.get_image() if hasattr(img, "get_image") else img
        buf = io.BytesIO()
        pil.convert("RGB").save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        return b""


def _qr_base64(text):
    if not text:
        return ""
    raw = qr_png(text)
    if not raw:
        return ""
    import base64
    return "data:image/png;base64," + base64.b64encode(raw).decode()


def _hex_to_rgb(h):
    h = (h or "").strip().lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    if len(h) != 6:
        return (255, 255, 255)
    try:
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except Exception:
        return (255, 255, 255)


def _auto_text(bg):
    """根据背景明暗自动挑一个可读文字色。"""
    r, g, b = _hex_to_rgb(bg)
    lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255
    return "#141414" if lum > 0.6 else "#ffffff"


def _esc(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


# ---------------------------------------------------------------- 表单字段
FORM_FIELDS = {
    "name":    '<input required placeholder="您的称呼" name="name">',
    "phone":   '<input placeholder="手机号" name="phone" inputmode="numeric" pattern="1[0-9]{10}">',
    "attend":  ('<div class="row">'
                '<label class="opt"><input type="radio" name="attend" value="参加" checked><i></i>参加</label>'
                '<label class="opt"><input type="radio" name="attend" value="待定"><i></i>待定</label>'
                '<label class="opt"><input type="radio" name="attend" value="不参加"><i></i>不参加</label></div>'),
    "count":   '<input placeholder="同行人数" name="count" inputmode="numeric">',
    "company": '<input placeholder="单位 / 公司" name="company">',
    "diet":    '<input placeholder="饮食忌口 / 备注" name="diet">',
    "custom":  '<input placeholder="自定义内容" name="custom">',
}


def build_form(theme):
    fields = theme.get("formFields", {})
    custom_label = (theme.get("customLabel") or "").strip()
    parts = []
    for k in ["name", "phone", "attend", "count", "company", "diet"]:
        if fields.get(k):
            parts.append(FORM_FIELDS[k])
    if fields.get("custom"):
        # 自定义字段支持起名（如「微信号」），没填名字就显示「自定义内容」
        parts.append('<input placeholder="%s" name="custom">' % _esc(custom_label or "自定义内容"))
    if not parts:
        parts = [FORM_FIELDS["name"], FORM_FIELDS["phone"]]
    submit_text = theme.get("submitText") or "提交"
    return (
        '<form id="rsvp" novalidate>' + "".join(parts) +
        '<button class="cta" type="submit">%s</button></form>'
        '<div class="ok" id="ok">✅ 已收到，感谢您的参与！</div>' % _esc(submit_text)
    )


# ---------------------------------------------------------------- HTML 模板
TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>__TITLE__</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{min-height:100%}
body{font-family:"PingFang SC","Microsoft YaHei","Noto Sans SC",sans-serif;__PAGE_BG__}
/* 背景三层全部挂在 .page 内（absolute + 负 z-index），严格限制在手机框内且垫在内容下方 */
#bgfx{position:absolute;inset:0;width:100%;height:100%;z-index:-3;pointer-events:none}
#scrim{position:absolute;inset:0;z-index:-1;pointer-events:none;__SCRIM__}
.page{position:relative;z-index:2;min-height:100vh;max-width:520px;margin:0 auto;display:flex;flex-direction:column;
  padding:0;overflow:hidden;box-shadow:0 0 80px rgba(0,0,0,.35)}
.zone{padding:26px 22px;display:flex;flex-direction:column;align-items:center;text-align:center}
.head{background:__HEAD_BG__;color:__HEAD_TEXT__;padding-top:44px;padding-bottom:28px}
.kicker{font-size:13px;letter-spacing:6px;opacity:.85;margin-bottom:10px}
h1{font-size:34px;font-weight:800;letter-spacing:2px;line-height:1.2;text-shadow:0 2px 18px rgba(0,0,0,.35)}
h1 .accent{color:var(--accent2)}
.sub{margin-top:10px;font-size:15px;opacity:.9;line-height:1.6}
.rule{width:56px;height:2px;background:var(--accent);margin:16px auto;border-radius:2px}
.mid{background:__BODY_BG__;color:__BODY_TEXT__;flex:1;padding-top:26px;padding-bottom:30px}
.meta{font-size:15px;line-height:2;opacity:.95;margin-bottom:6px}
.meta .k{opacity:.75;margin-right:6px}
.content{font-size:14px;line-height:1.9;opacity:.9;margin:8px 0 4px;white-space:pre-wrap}
.cd{display:flex;gap:8px;justify-content:center;margin:14px 0 4px}
.cd .cell{background:var(--accent);color:__ON_ACCENT__;border-radius:10px;padding:8px 10px;min-width:52px}
.cd .cell b{font-size:22px;font-weight:800;display:block;line-height:1}
.cd .cell span{font-size:11px;opacity:.9}
form{margin-top:18px;width:100%;display:flex;flex-direction:column;gap:10px;text-align:left}
input{width:100%;padding:13px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.22);
  background:rgba(0,0,0,.18);color:inherit;font-size:15px;outline:none}
body.light input{background:rgba(0,0,0,.06)}
input::placeholder{color:currentColor;opacity:.5}
/* 单选/复选选项：胶囊分格 + 自定义圆点（全局 input 样式不适用于 radio/checkbox） */
.row{display:flex;gap:8px;flex-wrap:wrap;font-size:14px}
.opts{display:flex;flex-direction:column;gap:8px;margin:10px 0}
.opt{flex:1;display:flex;align-items:center;justify-content:center;gap:8px;
  padding:12px 10px;border-radius:12px;border:1px solid rgba(255,255,255,.25);
  background:rgba(0,0,0,.18);cursor:pointer;white-space:nowrap;color:inherit;font-size:14px;
  transition:border-color .15s,background .15s;-webkit-tap-highlight-color:transparent}
.opts .opt{flex:none;justify-content:flex-start}
.opt:hover{border-color:var(--accent)}
.opt input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;margin:0;padding:0}
.opt i{width:16px;height:16px;border-radius:50%;border:2px solid rgba(255,255,255,.45);
  flex-shrink:0;display:inline-block;position:relative;transition:border-color .15s,background .15s}
.opt.checkbox i{border-radius:5px}
.opt input:checked+i{border-color:var(--accent);background:var(--accent)}
.opt input:checked+i::after{content:"";position:absolute;left:4px;top:1px;width:4px;height:8px;
  border:solid __ON_ACCENT__;border-width:0 2px 2px 0;transform:rotate(45deg)}
.opt.checkbox input:checked+i::after{left:4px;top:0;height:9px}
.opt.on{border-color:var(--accent);background:rgba(255,255,255,.10)}
body.light .opt{border-color:rgba(0,0,0,.20);background:rgba(0,0,0,.04)}
body.light .opt.on{background:rgba(0,0,0,.07)}
body.light .opt i{border-color:rgba(0,0,0,.35)}
.cta{width:100%;padding:15px;border:none;border-radius:30px;cursor:pointer;font-size:17px;font-weight:800;
  color:__ON_ACCENT__;background:linear-gradient(90deg,var(--accent),var(--accent2));
  box-shadow:0 8px 24px rgba(0,0,0,.28);transition:transform .12s}
.cta:active{transform:scale(.97)}
.ok{display:none;margin-top:14px;padding:14px;border-radius:12px;background:rgba(255,255,255,.12);
  border:1px solid rgba(255,255,255,.25);font-size:15px}
.actions{display:flex;gap:10px;margin-top:14px;width:100%}
.btn{flex:1;min-height:48px;padding:12px 32px;border-radius:30px;border:1.5px solid var(--accent);
  background:transparent;color:var(--accent2);font-size:15px;font-weight:700;cursor:pointer;
  display:inline-flex;align-items:center;justify-content:center;gap:8px;
  transition:transform .12s,background .2s,color .2s,border-color .2s}
.btn:active{transform:scale(.93)}
.btn.liked{background:linear-gradient(90deg,var(--accent),var(--accent2));color:__ON_ACCENT__;
  border-color:transparent;animation:likepop .35s ease}
@keyframes likepop{0%{transform:scale(1)}40%{transform:scale(1.12)}100%{transform:scale(1)}}
.likecount{font-size:13px;opacity:.85;margin-top:8px}
.cmt{margin-top:16px;width:100%;text-align:left}
.cmt h3{font-size:14px;opacity:.8;margin-bottom:8px}
.cmt .list{max-height:150px;overflow:auto;margin-bottom:8px}
.cmt .item{font-size:13px;padding:8px 10px;border-radius:10px;background:rgba(255,255,255,.10);margin-bottom:6px}
.cmt .item b{color:var(--accent2);margin-right:6px}
.cmt .box{display:flex;gap:8px}
.cmt .box input{flex:1}
.cmt .box button{padding:0 26px;min-height:48px;font-size:15px;border:none;border-radius:12px;background:var(--accent);color:__ON_ACCENT__;font-weight:700;cursor:pointer;flex-shrink:0}
.foot{background:__FOOT_BG__;color:__FOOT_TEXT__;padding:22px;gap:14px}
.qr img{width:92px;height:92px;border-radius:10px;display:block}
.qr p{font-size:12px;opacity:.85;margin-top:6px}
.share{border:1px solid currentColor;background:none;color:inherit;padding:11px 26px;border-radius:30px;font-size:14px;cursor:pointer}
.note{font-size:12px;opacity:.7;line-height:1.6}
.music{position:fixed;top:14px;right:14px;z-index:5;width:42px;height:42px;border-radius:50%;
  border:1px solid var(--accent);background:rgba(0,0,0,.35);color:var(--accent2);font-size:18px;cursor:pointer}
.music.on{animation:spin 4s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
/* ===== 动效 ===== */
/* 入场：每个区块逐项上浮浮现 */
.zone>*{animation:fadeUp .75s cubic-bezier(.22,1,.36,1) both}
.zone>*:nth-child(1){animation-delay:.05s}
.zone>*:nth-child(2){animation-delay:.13s}
.zone>*:nth-child(3){animation-delay:.21s}
.zone>*:nth-child(4){animation-delay:.29s}
.zone>*:nth-child(5){animation-delay:.37s}
.zone>*:nth-child(6){animation-delay:.45s}
.zone>*:nth-child(7){animation-delay:.53s}
.zone>*:nth-child(n+8){animation-delay:.6s}
/* 背景：Ken Burns 缓慢放大平移（图片背景时启用） */
#bgPhoto{position:absolute;inset:-4%;z-index:-2;pointer-events:none;background-position:center;background-size:cover;background-repeat:no-repeat}
#bgPhoto video{width:100%;height:100%;object-fit:cover;display:block}
#bgPhoto.on{animation:kb 26s ease-in-out infinite alternate}
@keyframes kb{0%{transform:scale(1) translate(0,0)}50%{transform:scale(1.06) translate(1.4%,-1.4%)}100%{transform:scale(1.02) translate(-1.2%,1%)}}
/* 按钮：玻璃流光周期扫过 */
.cta{position:relative;overflow:hidden}
.cta::after{content:"";position:absolute;top:-30%;bottom:-30%;left:-75%;width:46%;pointer-events:none;
  background:linear-gradient(105deg,rgba(255,255,255,0),rgba(255,255,255,.5) 50%,rgba(255,255,255,0));
  transform:skewX(-18deg);animation:shine 3.8s cubic-bezier(.45,0,.25,1) infinite}
@keyframes shine{0%{left:-75%}55%,100%{left:135%}}
/* 倒计时数字格：轻轻浮动 */
.cd .cell{animation:cellFloat 2.6s ease-in-out infinite alternate}
.cd .cell:nth-child(2){animation-delay:.25s}
.cd .cell:nth-child(3){animation-delay:.5s}
.cd .cell:nth-child(4){animation-delay:.75s}
@keyframes cellFloat{to{transform:translateY(-4px)}}
/* 系统开了「减弱动态效果」时全部关闭 */
@media (prefers-reduced-motion:reduce){#bgPhoto.on,.zone>*,.cta::after,.cd .cell{animation:none!important}}
</style>
<style>
:root{--accent:__ACCENT__;--accent2:__ACCENT2__;--on:__ON_ACCENT__}
</style>
<style>__MODULE_CSS__</style>
</head>
<body class="__BODY_CLASS__">
__MUSIC__
<div class="page">
<canvas id="bgfx" __CANVAS_ATTRS__></canvas>
<div id="bgPhoto" __BGP__>__BG_MEDIA__</div>
<div id="scrim"></div>
  <header class="zone head">
    <div class="kicker">__KICKER__</div>
    <h1>__TITLE__</h1>
    <div class="rule"></div>
    __SUBTITLE_BLOCK__
  </header>
  <main class="zone mid">
    __DATE_BLOCK__
    __LOCATION_BLOCK__
    __CONTENT_BLOCK__
    __COUNTDOWN_BLOCK__
    __FORM_BLOCK__
    __LIKE_BLOCK__
    __COMMENT_BLOCK__
    __MODULES_BLOCK__
  </main>
  <footer class="zone foot">
    __QR_BLOCK__
    __SHARE_BLOCK__
    __FOOTNOTE_BLOCK__
  </footer>
</div>
<script>
window.H5_POST="__PID__";
function track(type,payload){try{fetch("/api/track?post=__PID__",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.assign({type:type},payload||{}))}).catch(function(){});}catch(e){}}
window.addEventListener("load",function(){track("view");});
</script>
<script>
__ENGINE__
</script>
<script>
__INIT_ENGINE__
(function(){
  var rf=document.getElementById("rsvp");
  if(rf){rf.addEventListener("submit",function(e){e.preventDefault();
    if(!rf.checkValidity()){rf.reportValidity();return;}
    var data={};var fd=new FormData(rf);fd.forEach(function(v,k){data[k]=v;});
    track("submit",{name:data.name||"",fields:data});
    rf.hidden=true;document.getElementById("ok").style.display="block";});}
  // 选项胶囊选中态高亮（自定义圆点由 CSS :checked+i 处理，label 底色靠这里）
  document.querySelectorAll(".row,.opts").forEach(function(box){
    var sync=function(){box.querySelectorAll(".opt").forEach(function(l){
      var inp=l.querySelector("input");l.classList.toggle("on",!!(inp&&inp.checked));});};
    box.addEventListener("change",sync);sync();});
  var like=document.getElementById("likeBtn");
  if(like){like.addEventListener("click",function(){track("like");like.classList.add("liked");like.textContent="❤ 已点赞";});}
  var cf=document.getElementById("cmtForm");
  if(cf){cf.addEventListener("submit",function(e){e.preventDefault();
    var n=document.getElementById("cmtName").value.trim();
    var c=document.getElementById("cmtText").value.trim();
    if(!c){return;}
    track("comment",{name:n||"访客",content:c});
    var list=document.getElementById("cmtList");
    var it=document.createElement("div");it.className="item";
    it.innerHTML="<b>"+(n||"访客")+"</b>"+c.replace(/[<>&]/g,function(m){return{"<":"&lt;",">":"&gt;","&":"&amp;"}[m];});
    list.insertBefore(it,list.firstChild);
    document.getElementById("cmtText").value="";});}
  var sh=document.getElementById("shareBtn");
  if(sh){sh.addEventListener("click",function(){
    if(navigator.share){navigator.share({title:document.title,url:location.href}).catch(function(){});}
    else{try{var t=document.createElement("textarea");t.value=location.href;document.body.appendChild(t);t.select();document.execCommand("copy");document.body.removeChild(t);sh.textContent="链接已复制 ✓";}catch(e){sh.textContent=location.href;}}});}
  var mb=document.getElementById("musicBtn"),bgm=document.getElementById("bgm"),mon=false;
  if(mb){mb.addEventListener("click",function(){mon=!mon;mb.classList.toggle("on",mon);
    if(bgm&&bgm.src){mon?bgm.play():bgm.pause();}});}
  __COUNTDOWN_INIT__
  __MODULES_INIT__
})();
</script>
</body>
</html>
"""


def _css_color(v, default):
    v = (v or "").strip()
    return v if v else default


def _urlq(s):
    return _quote(str(s or ""), safe="")


# ================================================================ 功能组件
MODULE_CSS = """
.mod{margin-top:18px;width:100%;text-align:left}
.modt{font-size:15px;margin:0 0 10px;opacity:.92;font-weight:700}
.video video{width:100%;border-radius:12px;background:#000;display:block}
.map .mapaddr{font-size:14px;margin-bottom:10px;opacity:.95}
.map .mapframe{width:100%;height:240px;border:0;border-radius:14px;display:block;margin-bottom:10px;background:#e8ecef}
.map .mapgo{display:inline-block;text-decoration:none;text-align:center;width:auto;padding:12px 24px}
.opts{display:flex;flex-direction:column;gap:8px;margin-bottom:12px}
.opts .opt{display:flex;align-items:center;gap:9px;font-size:14px;padding:11px 13px;
  border:1px solid rgba(255,255,255,.2);border-radius:11px;background:rgba(0,0,0,.12);cursor:pointer}
body.light .opts .opt{border-color:rgba(0,0,0,.15);background:rgba(0,0,0,.04)}
.lottery .prize{min-height:60px;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;
  border:1px dashed var(--accent);border-radius:12px;margin-bottom:12px;padding:12px;background:rgba(0,0,0,.15)}
.hint2{font-size:13px;opacity:.85;margin-top:8px}
#rpLayer{position:fixed;inset:0;pointer-events:none;z-index:6;overflow:hidden}
.rpk{position:absolute;top:-46px;font-size:32px;pointer-events:auto;cursor:pointer;animation:rpfall linear forwards;user-select:none;filter:drop-shadow(0 4px 8px rgba(0,0,0,.35))}
.rpgot{position:fixed;z-index:9;pointer-events:none;font-weight:800;font-size:20px;color:#ffd86b;
  text-shadow:0 2px 8px rgba(0,0,0,.5);animation:rppop 1s ease-out forwards}
@keyframes rppop{0%{transform:translateY(0) scale(.6);opacity:0}20%{transform:translateY(-10px) scale(1.15);opacity:1}100%{transform:translateY(-64px) scale(1);opacity:0}}
.rpmsg{position:fixed;left:50%;bottom:18%;transform:translateX(-50%);z-index:9;pointer-events:none;
  background:rgba(0,0,0,.72);color:#ffe9c7;font-size:14px;padding:8px 16px;border-radius:20px;
  animation:rppop 1.4s ease-out forwards;white-space:nowrap}
#rpCap{position:fixed;inset:0;z-index:20;background:rgba(0,0,0,.6);display:none;align-items:center;justify-content:center}
.rpcapbox{background:#1c2330;border:1px solid #2c3648;border-radius:16px;padding:20px;width:250px;text-align:center}
.rpcapbox .rpcapt{font-size:15px;font-weight:700;color:#ffe9c7;margin-bottom:12px}
#rpCapSvg{display:flex;justify-content:center;margin-bottom:10px}
#rpCapSvg svg{border-radius:8px}
#rpCapInp{width:100%;box-sizing:border-box;padding:9px 12px;border-radius:10px;border:1px solid #2c3648;
  background:#12171f;color:#fff;font-size:16px;text-align:center;letter-spacing:4px;margin-bottom:12px}
.rprow{display:flex;gap:10px;justify-content:center}
@keyframes rpfall{to{transform:translateY(112vh) rotate(40deg)}}
.signin{display:flex;align-items:center;gap:14px}
.signin .cta{width:auto;padding:13px 28px}
.signin .signstate{font-size:13px;opacity:.9}
#danmakuLayer{position:fixed;left:0;right:0;top:0;height:62%;pointer-events:none;z-index:7;overflow:hidden}
.dm{position:absolute;left:100%;white-space:nowrap;font-size:16px;font-weight:700;color:#fff;
  text-shadow:0 1px 5px rgba(0,0,0,.7);animation:dmmove linear forwards}
@keyframes dmmove{to{transform:translateX(calc(-100vw - 110%))}}
.dmbar{position:fixed;left:0;right:0;bottom:0;z-index:8;display:flex;gap:8px;padding:10px 12px;
  background:rgba(0,0,0,.5);backdrop-filter:blur(6px)}
.dmbar input{flex:1;border-radius:20px;border:1px solid rgba(255,255,255,.28);background:rgba(0,0,0,.35);color:#fff;padding:9px 14px;font-size:14px}
.dmbar input::placeholder{color:rgba(255,255,255,.6)}
.dmbar button{border:none;border-radius:20px;background:var(--accent);color:var(--on);font-weight:700;padding:0 24px;min-height:42px;font-size:15px;cursor:pointer;flex-shrink:0}
.coupons .cplist{display:flex;flex-direction:column;gap:10px}
.cp{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 15px;border-radius:12px;
  background:linear-gradient(120deg,var(--accent),var(--accent2));color:var(--on);box-shadow:0 6px 18px rgba(0,0,0,.22)}
.cp .cpinfo{display:flex;flex-direction:column}
.cp .cpinfo b{font-size:20px;font-weight:800}
.cp .cpinfo span{font-size:13px;opacity:.95}
.cp .cpget{border:none;border-radius:20px;background:rgba(255,255,255,.9);color:#222;font-weight:700;padding:8px 16px;cursor:pointer;white-space:nowrap}
.cp .cpget:disabled{opacity:.7;cursor:default}
"""


def build_modules(theme):
    """根据 theme.modules 生成功能组件 HTML 与初始化 JS。"""
    m = theme.get("modules", {}) or {}
    blocks = []
    inits = []

    # 视频（url = 网络链接；src = 本地文件 base64 内联，优先用 src）
    v = m.get("video", {})
    if v.get("enabled") and (v.get("url") or v.get("src")):
        vsrc = v.get("src") or v.get("url")
        poster = (' poster="%s"' % _esc(v.get("posterSrc") or v.get("poster") or "")) if (v.get("posterSrc") or v.get("poster")) else ""
        # autoplay 必须配 muted（浏览器策略），否则手机/电脑都会拒绝自动播放；保留 controls 可手动开声音。
        # 另加 JS 兜底：个别手机浏览器不吃 muted 属性，页面加载后强制静音并调 play()。
        blocks.append('<div class="mod video"><video controls autoplay muted loop playsinline preload="auto"%s src="%s"></video></div>'
                      % (poster, _esc(vsrc)))
        inits.append("(function(){var vs=document.querySelectorAll('video');"
                     "for(var i=0;i<vs.length;i++){(function(v){"
                     "v.muted=true;v.playsInline=true;v.loop=true;"
                     "var go=function(){var p=v.play();if(p&&p.catch)p.catch(function(){});};"
                     "if(v.readyState>=2){go();}else{v.addEventListener('loadeddata',go);"
                     "setTimeout(function(){if(v.paused){go();}},1200);}"
                     "})(vs[i]);}})();")

    # 地图 / 导航：有坐标就内嵌真地图（OSM iframe，免 key），下方导航按钮；
    # 地址解析失败（无网络等）自动降级为纯文字+按钮
    mp = m.get("map", {})
    if mp.get("enabled") and mp.get("address"):
        addr = mp.get("address", "")
        link = mp.get("link") or ("https://uri.amap.com/search?keyword=" + _urlq(addr))
        nav_btn = ('<a class="cta mapgo" href="%s" target="_blank" rel="noopener">🧭 导航去这里</a>'
                   % _esc(link))
        coords = _geocode(addr)
        if coords:
            lat, lon = coords
            bbox = "%.5f,%.5f,%.5f,%.5f" % (lon - 0.012, lat - 0.007, lon + 0.012, lat + 0.007)
            src = ("https://www.openstreetmap.org/export/embed.html?bbox=%s&layer=mapnik&marker=%.5f,%.5f"
                   % (bbox, lat, lon))
            blocks.append('<div class="mod map">'
                          '<iframe class="mapframe" src="%s" loading="lazy" title="地图"></iframe>'
                          '<div class="mapaddr">📍 %s</div>%s</div>'
                          % (_esc(src), _esc(addr), nav_btn))
        else:
            blocks.append('<div class="mod map"><div class="mapaddr">📍 %s</div>%s</div>'
                          % (_esc(addr), nav_btn))

    # 投票
    vt = m.get("vote", {})
    if vt.get("enabled") and vt.get("options"):
        q = vt.get("question") or "投个票吧"
        typ = "checkbox" if vt.get("multiple") else "radio"
        opts = "".join('<label class="opt%s"><input type="%s" name="vote" value="%s"><i></i>%s</label>'
                       % (" checkbox" if typ == "checkbox" else "", typ, _esc(o), _esc(o))
                       for o in vt["options"])
        blocks.append('<div class="mod vote"><h3 class="modt">🗳 %s</h3><div class="opts" id="voteOpts">%s</div>'
                      '<button class="cta" id="voteBtn">投票</button><div class="ok" id="voteOk"></div></div>'
                      % (_esc(q), opts))
        inits.append("(function(){var cfg=%s;var box=document.getElementById('voteOpts'),btn=document.getElementById('voteBtn'),ok=document.getElementById('voteOk');"
                     "btn.addEventListener('click',function(){var sel=[];box.querySelectorAll('input:checked').forEach(function(i){sel.push(i.value);});"
                     "if(!sel.length){alert('请先选择');return;}track('vote',{question:cfg.question||'',options:sel});"
                     "box.querySelectorAll('input').forEach(function(i){i.disabled=true;});btn.style.display='none';"
                     "ok.style.display='block';ok.textContent='✅ 已投票：'+sel.join('、');});})();"
                     % json.dumps(vt, ensure_ascii=False))

    # 抽奖
    lt = m.get("lottery", {})
    if lt.get("enabled") and lt.get("prizes"):
        title = lt.get("title") or "幸运抽奖"
        blocks.append('<div class="mod lottery"><h3 class="modt">🎁 %s</h3>'
                      '<div class="prize" id="prizeBox">点击下方开始</div>'
                      '<button class="cta" id="lotteryBtn">开始抽奖</button></div>' % _esc(title))
        inits.append("(function(){var cfg=%s;var btn=document.getElementById('lotteryBtn'),box=document.getElementById('prizeBox');"
                     "var prizes=cfg.prizes||[];var done=false;"
                     "btn.addEventListener('click',function(){if(done)return;done=true;btn.disabled=true;"
                     "var n=0;var iv=setInterval(function(){box.textContent=prizes[(Math.random()*prizes.length)|0]||'…';"
                     "if(++n>20){clearInterval(iv);var p=prizes[(Math.random()*prizes.length)|0]||'谢谢参与';"
                     "box.textContent='🎉 '+p;track('lottery',{prize:p});}},60);});})();"
                     % json.dumps(lt, ensure_ascii=False))

    # 红包雨（服务端开奖：限量 + 限人次 + 图形验证码防刷）
    rp = m.get("redpacket", {})
    if rp.get("enabled"):
        blocks.append('<div class="mod"><button class="cta" id="rpBtn">🧧 抢红包</button>'
                      '<div class="hint2">已抢到 <b id="rpN">0</b> 个 · 全场剩余 <b id="rpLeft">-</b> 个</div></div><div id="rpLayer"></div>')
        inits.append("(function(){var btn=document.getElementById('rpBtn'),layer=document.getElementById('rpLayer'),"
                     "nEl=document.getElementById('rpN'),lEl=document.getElementById('rpLeft'),got=0,busy=false;"
                     "var NEED_CAPTCHA=%s,capTok=null,capAns='',capPending=null;"
                     % ("true" if rp.get("captcha") else "false")
                     + "var dev=localStorage.getItem('h5dev');"
                     "if(!dev){dev='d'+Date.now().toString(36)+Math.random().toString(36).slice(2,10);"
                     "localStorage.setItem('h5dev',dev);}"
                     "function pop(x,y,txt){var e=document.createElement('div');e.className='rpgot';e.textContent=txt;"
                     "e.style.left=(x-14)+'px';e.style.top=y+'px';document.body.appendChild(e);"
                     "setTimeout(function(){e.remove();},1000);}"
                     "function msg(t){var e=document.createElement('div');e.className='rpmsg';e.textContent=t;"
                     "document.body.appendChild(e);setTimeout(function(){e.remove();},1400);}"
                     "var m=document.createElement('div');m.id='rpCap';"
                     "m.innerHTML='<div class=\"rpcapbox\"><div class=\"rpcapt\">验证后领取红包</div><div id=\"rpCapSvg\"></div>"
                     "<input id=\"rpCapInp\" maxlength=\"4\" placeholder=\"输入图中字符\"><div class=\"rprow\">"
                     "<button id=\"rpCapOk\" class=\"cta\">确定</button><button id=\"rpCapRe\" class=\"btn\">换一张</button></div></div>';"
                     "document.body.appendChild(m);"
                     "function capLoad(){fetch('/api/rp/captcha').then(function(r){return r.json();}).then(function(d){"
                     "capTok=d.token;capAns='';document.getElementById('rpCapSvg').innerHTML=d.svg;"
                     "document.getElementById('rpCapInp').value='';});}"
                     "function capOpen(){document.getElementById('rpCap').style.display='flex';capLoad();}"
                     "function capClose(){document.getElementById('rpCap').style.display='none';}"
                     "document.getElementById('rpCapRe').onclick=capLoad;"
                     "document.getElementById('rpCapOk').onclick=function(){"
                     "capAns=document.getElementById('rpCapInp').value.trim();if(!capAns)return;"
                     "capClose();var cb=capPending;capPending=null;if(cb)cb();};"
                     "function ensureCap(cb){if(!NEED_CAPTCHA||capTok)return cb();capPending=cb;capOpen();}"
                     "function grab(p,x,y){fetch('/api/rp/grab',{method:'POST',"
                     "headers:{'Content-Type':'application/json'},"
                     "body:JSON.stringify({post:window.H5_POST,dev:dev,"
                     "captchaToken:NEED_CAPTCHA?capTok:'',captchaAnswer:NEED_CAPTCHA?capAns:''})})"
                     ".then(function(r){return r.json();})"
                     ".then(function(d){if(d.ok){got++;nEl.textContent=got;if(d.left!=null)lEl.textContent=d.left;"
                     "pop(x,y,'+¥'+d.amount.toFixed(2));p.remove();}"
                     "else if(d.reason==='limit'){msg('每人限领，下次再来~');p.remove();}"
                     "else if(d.reason==='empty'){msg('红包已被抢完');p.remove();}"
                     "else if(d.reason==='fast'){msg('手速太快，歇2秒~');p.remove();}"
                     "else if(d.reason==='captcha'){capTok=null;msg('验证码错误，请重试');"
                     "ensureCap(function(){grab(p,x,y);});}"
                     "else{p.remove();}})"
                     ".catch(function(){p.remove();});}"
                     "btn.addEventListener('click',function(){if(busy)return;busy=true;btn.disabled=true;"
                     "for(var i=0;i<12;i++){(function(i){setTimeout(function(){var p=document.createElement('div');"
                     "p.className='rpk';p.textContent='🧧';"
                     "p.style.left=(8+Math.random()*80)+'%%';"
                     "p.style.animationDuration=(2.4+Math.random()*1.6)+'s';"
                     "p.addEventListener('click',function(){if(p.dataset.done)return;p.dataset.done='1';"
                     "var r=p.getBoundingClientRect();ensureCap(function(){grab(p,r.left,r.top);});});"
                     "layer.appendChild(p);setTimeout(function(){if(p.parentNode)p.remove();},4400);},i*140);})(i);}"
                     "setTimeout(function(){busy=false;btn.disabled=false;},4200);});})();")

    # 签到
    si = m.get("signin", {})
    if si.get("enabled"):
        blocks.append('<div class="mod signin"><button class="cta" id="signBtn">📅 每日签到</button>'
                      '<span class="signstate" id="signState"></span></div>')
        inits.append("(function(){var btn=document.getElementById('signBtn'),st=document.getElementById('signState');"
                     "var KEY='h5sign_'+window.H5_POST;var d=new Date();var day=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();"
                     "var nk=KEY+'_n';if(localStorage.getItem(KEY)===day){btn.disabled=true;btn.textContent='已签到 ✓';"
                     "st.textContent='今天已签到';}"
                     "btn.addEventListener('click',function(){if(localStorage.getItem(KEY)===day)return;"
                     "var n=parseInt(localStorage.getItem(nk)||'0',10)+1;localStorage.setItem(KEY,day);localStorage.setItem(nk,String(n));"
                     "btn.disabled=true;btn.textContent='已签到 ✓';st.textContent='签到成功，已连续 '+n+' 天';track('signin',{days:n});});})();")

    # 弹幕
    dm = m.get("danmaku", {})
    if dm.get("enabled"):
        blocks.append('<div id="danmakuLayer"></div>'
                      '<div class="dmbar"><input id="dmText" placeholder="发条弹幕…" maxlength="40">'
                      '<button id="dmSend">发送</button></div>')
        inits.append("(function(){var layer=document.getElementById('danmakuLayer'),inp=document.getElementById('dmText'),send=document.getElementById('dmSend');"
                     "function fire(text){var d=document.createElement('div');d.className='dm';d.textContent=text;"
                     "d.style.top=(6+Math.random()*40)+'%%';d.style.animationDuration=(5+Math.random()*3)+'s';layer.appendChild(d);"
                     "setTimeout(function(){if(d.parentNode)d.remove();},8600);}"
                     "function go(){var t=inp.value.trim();if(!t)return;fire(t);track('comment',{name:'弹幕',content:t,danmaku:true});inp.value='';}"
                     "send.addEventListener('click',go);inp.addEventListener('keydown',function(e){if(e.key==='Enter')go();});"
                     "['欢迎来到现场～','弹幕刷起来 666','这个海报真好看'].forEach(function(t,i){setTimeout(function(){fire(t);},700+i*900);});})();")

    # 优惠券
    cp = m.get("coupon", {})
    if cp.get("enabled") and cp.get("items"):
        title = cp.get("title") or "领券福利"
        cards = "".join(
            '<div class="cp"><div class="cpinfo"><b>%s</b><span>%s</span></div>'
            '<button class="cpget" data-code="%s">领取</button></div>'
            % (_esc(it.get("amount", "")), _esc(it.get("name", "")), _esc(it.get("code", "")))
            for it in cp["items"])
        blocks.append('<div class="mod coupons"><h3 class="modt">🎫 %s</h3><div class="cplist">%s</div></div>'
                      % (_esc(title), cards))
        inits.append("(function(){document.querySelectorAll('.cpget').forEach(function(b){"
                     "b.addEventListener('click',function(){if(b.disabled)return;b.disabled=true;b.textContent='已领取';"
                     "var nm=b.parentNode.querySelector('span').textContent;"
                     "track('coupon',{code:b.getAttribute('data-code'),name:nm});});});})();")

    return "".join(blocks), "\n".join(inits)


def build_poster(theme):
    cat = theme.get("category", "invitation")
    d = CATEGORY_DEFAULTS.get(cat) or CATEGORY_DEFAULTS.get("wedding") or CATEGORY_DEFAULTS.get("meeting")
    bg = theme.get("bg", {})

    # ---- 背景 ----
    bgtype = bg.get("type", "gradient")
    colors = bg.get("colors") or d["gradient"]
    angle = bg.get("angle", d.get("angle", 135))
    image = bg.get("image") or ""
    body_class = ""
    bgp = 'style="display:none"'
    bg_media = ""
    if bgtype == "video" and (bg.get("videoSrc") or "").startswith("data:"):
        # 动态视频背景：全屏静音循环；同时把静态图作 poster/兜底，视频未播时仍有场景
        body_bg = "background:#10141b;"
        _img = bg.get("image") or ""
        if _img.startswith("data:"):
            bgp = 'class="on" style="background-image:url(\'%s\')"' % _img
            bg_media = '<video src="%s" autoplay muted loop playsinline poster="%s"></video>' % (bg["videoSrc"], _img)
        else:
            bgp = 'class="on"'
            bg_media = '<video src="%s" autoplay muted loop playsinline></video>' % bg["videoSrc"]
    elif bgtype in ("image", "image+particles") and image.startswith("data:"):
        # 背景图放到独立层 #bgPhoto（Ken Burns 动画），body 只留深色兜底
        body_bg = "background:#10141b;"
        bgp = 'class="on" style="background-image:url(\'%s\')"' % image
    elif bgtype == "gradient":
        stops = ", ".join(colors)
        body_bg = "background:linear-gradient(%ddeg, %s);" % (angle, stops)
    else:
        body_bg = "background:linear-gradient(%ddeg, #14181f, #1f2430);" % angle

    # 顶部/中部/底部色（可空 → 用分类默认），并判断明暗决定 body class
    zones = theme.get("zones", {})
    head = zones.get("head", {})
    body_z = zones.get("body", {})
    foot = zones.get("foot", {})
    head_bg = _css_color(head.get("bg"), d["head"][0])
    head_text = _css_color(head.get("text"), d["head"][1])
    body_bg_z = _css_color(body_z.get("bg"), d["body"][0])
    body_text = _css_color(body_z.get("text"), d["body"][1])
    foot_bg = _css_color(foot.get("bg"), d["foot"][0])
    foot_text = _css_color(foot.get("text"), d["foot"][1])
    # 若中部文字色是深色，标记 light 供 input 反色
    r, g, b = _hex_to_rgb(body_text)
    if (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5:
        body_class = "light"

    accent = _css_color(theme.get("accent"), d["accent"])
    accent2 = _css_color(theme.get("accent2"), d["accent2"])
    on_accent = _auto_text(accent)

    # ---- 粒子 ----
    particles = bg.get("particles", {})
    mode = particles.get("mode", "none")
    canvas_attrs = ""
    init_engine = ""
    if bgtype in ("particles", "image+particles") and mode in PARTICLE_PRESETS:
        pcolors = ",".join(particles.get("colors") or d["pcolors"])
        pspeed = particles.get("speed", 1.0)
        inter = "1" if particles.get("interactive", True) else "0"
        canvas_attrs = 'data-particles="%s" data-colors="%s" data-speed="%s" data-interactive="%s"' % (mode, pcolors, pspeed, inter)
        init_engine = "if(window.H5Particles&&window.H5Particles.autoInit){window.H5Particles.autoInit();}"
    scrim = "background:linear-gradient(180deg, rgba(0,0,0,.10), rgba(0,0,0,.28));" if (bgtype in ("image", "image+particles", "video")) else "display:none;"

    # ---- 文本块 ----
    subtitle = theme.get("subtitle") or ""
    subtitle_block = ('<p class="sub">%s</p>' % _esc(subtitle)) if subtitle else ""
    date = theme.get("date") or ""
    date_block = ('<div class="meta"><span class="k">📅</span>%s</div>' % _esc(date)) if date else ""
    location = theme.get("location") or ""
    location_block = ('<div class="meta"><span class="k">📍</span>%s</div>' % _esc(location)) if location else ""
    content = theme.get("content") or ""
    content_block = ('<div class="content">%s</div>' % _esc(content)) if content else ""

    # ---- 倒计时 ----
    cd = theme.get("countdown", {})
    countdown_block = ""
    countdown_init = ""
    if cd.get("enabled") and cd.get("target"):
        countdown_block = '<div class="cd" id="cd"><div class="cell"><b id="cdd">0</b><span>天</span></div><div class="cell"><b id="cdh">0</b><span>时</span></div><div class="cell"><b id="cdm">0</b><span>分</span></div><div class="cell"><b id="cds">0</b><span>秒</span></div></div>'
        countdown_init = """
  var tgt=new Date("__CDTGT__").getTime();
  function tick(){var diff=tgt-Date.now();if(diff<0)diff=0;
    var d=Math.floor(diff/86400000),h=Math.floor(diff/3600000)%24,m=Math.floor(diff/60000)%60,s=Math.floor(diff/1000)%60;
    document.getElementById("cdd").textContent=d;document.getElementById("cdh").textContent=h;
    document.getElementById("cdm").textContent=m;document.getElementById("cds").textContent=s;}
  tick();setInterval(tick,1000);
""".replace("__CDTGT__", _esc(cd.get("target")))

    # ---- 功能块 ----
    feats = theme.get("features", [])
    form_block = build_form(theme) if "form" in feats else ""
    like_block = ('<div style="width:100%%;text-align:center"><button class="btn" id="likeBtn">♡ 点赞</button>'
                  '<div class="likecount">已有 <span id="likeN">0</span> 人点赞</div></div>') if "like" in feats else ""
    comment_block = ""
    if "comment" in feats:
        comment_block = (
            '<div class="cmt"><h3>留言 · 说说心里话</h3><div class="list" id="cmtList"></div>'
            '<form class="box" id="cmtForm"><input id="cmtName" placeholder="称呼（选填）" style="max-width:110px">'
            '<input id="cmtText" placeholder="写下留言…"><button type="submit">发送</button></form></div>'
        )
    qr_block = ""
    if "qr" in feats and theme.get("qrTarget"):
        b64 = _qr_base64(theme["qrTarget"])
        if b64:
            qr_block = '<div class="qr"><img src="%s" alt="扫码"><p>扫码了解更多</p></div>' % b64
    share_block = ('<button class="share" id="shareBtn">分享给好友</button>') if "share" in feats else ""
    footnote = theme.get("footerNote") or ""
    footnote_block = ('<p class="note">%s</p>' % _esc(footnote)) if footnote else ""
    music_block = ""
    # musicSrc = 本地 mp3 base64 内联（优先），musicUrl = 网络链接
    if "music" in feats and (theme.get("musicUrl") or theme.get("musicSrc")):
        msrc = theme.get("musicSrc") or theme.get("musicUrl")
        music_block = '<button class="music" id="musicBtn" aria-label="音乐">♪</button><audio id="bgm" loop src="%s"></audio>' % _esc(msrc)

    post_id = theme.get("postId") or "demo"

    modules_html, modules_init = build_modules(theme)
    module_css = MODULE_CSS

    html = TEMPLATE
    for ph, val in [
        ("__TITLE__", _esc(theme.get("title") or "动态海报")),
        ("__KICKER__", _esc(theme.get("kicker") or d["kicker"])),
        ("__SUBTITLE_BLOCK__", subtitle_block),
        ("__DATE_BLOCK__", date_block),
        ("__LOCATION_BLOCK__", location_block),
        ("__CONTENT_BLOCK__", content_block),
        ("__COUNTDOWN_BLOCK__", countdown_block),
        ("__COUNTDOWN_INIT__", countdown_init),
        ("__FORM_BLOCK__", form_block),
        ("__LIKE_BLOCK__", like_block),
        ("__COMMENT_BLOCK__", comment_block),
        ("__QR_BLOCK__", qr_block),
        ("__SHARE_BLOCK__", share_block),
        ("__FOOTNOTE_BLOCK__", footnote_block),
        ("__MUSIC__", music_block),
        ("__ENGINE__", _read_engine()),
        ("__INIT_ENGINE__", init_engine),
        ("__CANVAS_ATTRS__", canvas_attrs),
        ("__BGP__", bgp),
        ("__BG_MEDIA__", bg_media),
        ("__PAGE_BG__", body_bg),
        ("__BODY_CLASS__", body_class),
        ("__SCRIM__", scrim),
        ("__HEAD_BG__", head_bg),
        ("__HEAD_TEXT__", head_text),
        ("__BODY_BG__", body_bg_z),
        ("__BODY_TEXT__", body_text),
        ("__FOOT_BG__", foot_bg),
        ("__FOOT_TEXT__", foot_text),
        ("__ACCENT__", accent),
        ("__ACCENT2__", accent2),
        ("__ON_ACCENT__", on_accent),
        ("__PID__", post_id),
        ("__MODULE_CSS__", module_css),
        ("__MODULES_BLOCK__", modules_html),
        ("__MODULES_INIT__", modules_init),
    ]:
        html = html.replace(ph, str(val))

    return html


def _read_engine():
    try:
        with io.open(ENGINE_PATH, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""
