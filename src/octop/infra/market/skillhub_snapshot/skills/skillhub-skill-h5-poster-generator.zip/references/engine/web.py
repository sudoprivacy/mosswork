# -*- coding: utf-8 -*-
"""本地 Web 服务：托管管理 UI、海报页 /p/<id>、埋点 /api/track、生成/发布/数据 API。

安全模型（修复版）：
- 管理台与管理类 API 仅限本机回环地址访问（127.0.0.1 / ::1 / localhost）。
- 若通过隧道把服务映射到公网，管理台与管理类 API 一律 403，公网只放行
  海报页 /p/<id> 与访客互动埋点 /api/track、/api/rp/*（红包抽奖属访客功能）。
- 启动时生成一次性本地令牌并打印到控制台与 data/local_token.txt，可选
  通过 query 参数 ?token= 访问管理台（防同机其他用户/进程越权，不影响访客）。
"""
import os
import json
import time
import hmac
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote

from . import db
from . import generator
from . import paths
from .tunnel import Tunnel, load_cfg, save_cfg, mask_cfg

WEBROOT = os.path.join(paths.base_dir(), "webroot")
ASSETS = os.path.join(paths.base_dir(), "assets")

# 过期提示页：顾客点开已过期链接时看到，避免干巴巴的 404
EXPIRED_HTML = """<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>内容已过期</title><style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
font-family:"PingFang SC","Microsoft YaHei",sans-serif;background:#14161c;color:#e8eaf0;text-align:center;padding:24px}
.box{max-width:420px}
h1{font-size:20px;margin:0 0 10px}p{font-size:14px;opacity:.7;line-height:1.8;margin:0}
</style></head><body><div class="box"><h1>📭 该内容已过期</h1>
<p>这份海报已超过作者设置的有效期并被自动清理。<br>如需查看请联系发布者重新生成。</p>
</div></body></html>"""

# 管理台拒绝页：公网访客访问管理台/管理类 API 时看到
FORBIDDEN_HTML = """<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>无权访问</title><style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
font-family:"PingFang SC","Microsoft YaHei",sans-serif;background:#14161c;color:#e8eaf0;text-align:center;padding:24px}
.box{max-width:440px}h1{font-size:20px;margin:0 0 10px}p{font-size:14px;opacity:.7;line-height:1.8;margin:0}
</style></head><body><div class="box"><h1>🔒 管理台不对外开放</h1>
<p>管理后台、海报数据与系统配置仅限作者在本机使用。<br>公网访客只能访问已发布的海报页面本身。</p>
</div></body></html>"""

_tunnel = None
_port = 0

# ── 本地管理台令牌（每次启动随机生成） ──
LOCAL_TOKEN = None


def _gen_token():
    return secrets.token_urlsafe(18)


def _is_loopback(host):
    if not host:
        return False
    # 客户端地址形如 "127.0.0.1:54321" 或 "::1:54321"
    host = host.split("%")[0]  # IPv6 zone id
    h = host.rsplit(":", 1)[0]
    return h in ("127.0.0.1", "::1", "localhost")


def _public_base():
    """优先隧道公网地址，其次本机。"""
    if _tunnel and _tunnel.status().get("public_url"):
        return _tunnel.public_url
    return "http://127.0.0.1:%d" % _port


# 公网（隧道）下仅放行的访客路径前缀/精确路径
def _is_public_path(path):
    if path == "/api/track":
        return True
    if path.startswith("/p/"):
        return True
    if path == "/api/rp/captcha" or path.startswith("/api/rp/grab"):
        return True
    return False


class Handler(BaseHTTPRequestHandler):
    server_version = "H5Poster/1.0.2"

    def log_message(self, fmt, *args):
        pass  # 安静

    # ---------- 工具 ----------
    def _send(self, code, body=b"", ctype="text/html; charset=utf-8", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8")

    def _read_json(self):
        try:
            n = int(self.headers.get("Content-Length", 0) or 0)
            raw = self.rfile.read(n) if n > 0 else b""
            return json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            return {}

    def _client_loopback(self):
        return _is_loopback(self.client_address[0] if self.client_address else "")

    def _token_ok(self, q):
        """管理台可选令牌校验：若请求带 token 参数且正确则放行，否则按回环地址放行。"""
        tok = (q.get("token") or [""])[0]
        if tok and LOCAL_TOKEN and hmac.compare_digest(tok, LOCAL_TOKEN):
            return True
        return self._client_loopback()

    def _static(self, path):
        full = os.path.normpath(os.path.join(WEBROOT, path))
        if not full.startswith(WEBROOT):
            return self._send(403, "forbidden")
        if not os.path.isfile(full):
            return self._send(404, "not found")
        ctype = "text/plain"
        if full.endswith(".html"):
            ctype = "text/html; charset=utf-8"
        elif full.endswith(".js"):
            ctype = "application/javascript"
        elif full.endswith(".css"):
            ctype = "text/css"
        elif full.endswith(".jpg") or full.endswith(".jpeg"):
            ctype = "image/jpeg"
        elif full.endswith(".png"):
            ctype = "image/png"
        elif full.endswith(".mp4"):
            ctype = "video/mp4"
        elif full.endswith(".svg"):
            ctype = "image/svg+xml"
        elif full.endswith(".ico"):
            ctype = "image/x-icon"
        with open(full, "rb") as f:
            self._send(200, f.read(), ctype)

    # ---------- 路由 ----------
    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        # 公网（隧道）下仅放行访客路径；其余一律拒绝管理台
        if not self._client_loopback():
            if not _is_public_path(path):
                return self._send(403, FORBIDDEN_HTML)
        # 海报页
        if path.startswith("/p/"):
            pid = path[3:]
            p = db.get_poster(pid)
            if not p:
                return self._send(404, EXPIRED_HTML)
            return self._send(200, p["html"])
        # 管理台静态与管理类 API：仅本机或持令牌
        if not self._token_ok(q):
            return self._send(403, FORBIDDEN_HTML)
        if path == "/" or path == "/index.html":
            return self._static("manage.html")
        if path.startswith("/assets/"):
            # /assets/manage.js → webroot/assets/manage.js
            return self._static(os.path.join("assets", path[len("/assets/"):]))
        if path == "/api/status":
            t = _tunnel.status() if _tunnel else {}
            return self._json({"port": _port, "public_base": _public_base(),
                               "tunnel": t})
        if path == "/api/meta":
            return self._json(generator.meta())
        if path == "/api/qr":
            text = (q.get("text") or [""])[0]
            png = generator.qr_png(text or " ")
            if not png:
                return self._send(500, "二维码生成失败（缺少 qrcode 库）")
            return self._send(200, png, "image/png", {"Cache-Control": "no-store"})
        if path == "/api/mch":
            cfg = db.get_setting("mch", None) or {}
            masked = dict(cfg)
            for k in ("v3Key", "privateKey"):
                v = masked.get(k) or ""
                if v:
                    masked[k] = v[:6] + "…（已保存）"
            return self._json({"ok": True, "mch": masked,
                               "enabled": bool(cfg.get("mchid") and cfg.get("v3Key"))})
        if path == "/api/rp/captcha":
            token, code = db.captcha_create()
            return self._json({"ok": True, "token": token, "svg": db.captcha_svg(code)})
        if path == "/api/posts":
            return self._json({"posts": db.list_posters()})
        if path == "/api/tunnel/config":
            return self._json({"ok": True, "config": mask_cfg(load_cfg())})
        if path.startswith("/api/posts/") and path.endswith("/export"):
            pid = path.split("/")[3]
            p = db.get_poster(pid)
            if not p:
                return self._send(404, "海报不存在或已删除")
            title = (p.get("title") or "").strip() or ("海报-" + pid)
            safe = "".join(c for c in title if c not in '\\/:*?"<>|').strip() or pid
            fname = quote((safe + ".html").encode("utf-8"))
            return self._send(200, p["html"], "text/html; charset=utf-8", {
                "Content-Disposition": "attachment; filename*=UTF-8''" + fname,
            })
        if path.startswith("/api/posts/") and path.endswith("/data"):
            pid = path.split("/")[3]
            return self._json(db.post_stats(pid))
        return self._send(404, "not found")

    def do_POST(self):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        # 公网（隧道）下仅放行访客路径
        if not self._client_loopback():
            if not _is_public_path(path):
                return self._json({"ok": False, "error": "forbidden"}, 403)
        # 管理类操作：仅本机或持令牌
        if not self._token_ok(q):
            return self._json({"ok": False, "error": "forbidden"}, 403)
        if path == "/api/generate":
            theme = self._read_json()
            pid = db.new_post_id()
            theme["postId"] = pid
            html = generator.build_poster(theme)
            ttl = theme.get("ttlDays")
            try:
                ttl = int(ttl) if ttl else 0
            except (TypeError, ValueError):
                ttl = 0
            db.create_poster(pid, theme.get("title", ""), theme.get("kicker", ""),
                             theme.get("category", ""), html, theme, ttl_days=ttl)
            return self._json({"ok": True, "id": pid, "ttl_days": ttl,
                               "expire_at": int(time.time()) + ttl * 86400 if ttl else 0,
                               "local": "http://127.0.0.1:%d/p/%s" % (_port, pid)})
        if path == "/api/publish":
            if not _tunnel:
                return self._json({"ok": False, "error": "tunnel 未初始化"})
            url = _tunnel.start()
            if url:
                st = _tunnel.status()
                return self._json({"ok": True, "public_url": url,
                                   "mode": st.get("mode", "quick"),
                                   "probe": st.get("probe", False),
                                   "probe_detail": st.get("probe_detail", ""),
                                   "probe_code": st.get("probe_code", ""),
                                   "probe_hint": st.get("probe_hint", "")})
            return self._json({"ok": False, "error": _tunnel.status().get("error", "启动失败"),
                               "logs": _tunnel.logs()})
        if path == "/api/posts/purge":
            n = db.purge_expired()
            return self._json({"ok": True, "purged": n})
        if path == "/api/tunnel/config":
            data = self._read_json()
            cfg = save_cfg({
                "mode": data.get("mode", "quick"),
                "tunnel": data.get("tunnel", ""),
                "hostname": data.get("hostname", ""),
                "credentials": data.get("credentials", ""),
            })
            if _tunnel:
                _tunnel.stop()
            return self._json({"ok": True, "config": mask_cfg(cfg)})
        if path == "/api/tunnel/stop":
            if _tunnel:
                _tunnel.stop()
            return self._json({"ok": True})
        if path == "/api/track":
            data = self._read_json()
            pid = q.get("post", [""])[0] or data.get("post", "")
            itype = data.get("type", "")
            payload = {k: v for k, v in data.items() if k not in ("type", "post")}
            if pid and itype:
                db.add_interaction(pid, itype, payload)
            return self._json({"ok": True})
        if path == "/api/rp/grab":
            data = self._read_json()
            pid = data.get("post", "")
            dev = (data.get("dev") or "")[:64]
            if not pid:
                return self._json({"ok": False, "reason": "no-post"})
            res = db.grab_redpacket(pid, dev,
                                    captcha_token=data.get("captchaToken", ""),
                                    captcha_answer=data.get("captchaAnswer", ""))
            return self._json(res)
        if path == "/api/rp/reset":
            data = self._read_json()
            pid = data.get("post", "")
            if pid:
                db.reset_redpacket_pool(pid)
            return self._json({"ok": True})
        if path.startswith("/api/posts/") and path.endswith("/read"):
            pid = path.split("/")[3]
            db.mark_notifications_read(pid)
            return self._json({"ok": True})
        if path == "/api/posts/delete":
            data = self._read_json()
            db.delete_poster(data.get("id", ""))
            return self._json({"ok": True})
        if path == "/api/mch/save":
            data = self._read_json()
            mch = data.get("mch") or {}
            cfg = {
                "mchid": (mch.get("mchid") or "").strip(),
                "scene": (mch.get("scene") or "").strip(),
                "v3Key": (mch.get("v3Key") or "").strip(),
                "serialNo": (mch.get("serialNo") or "").strip(),
                "privateKey": (mch.get("privateKey") or "").strip(),
            }
            db.set_setting("mch", cfg)
            return self._json({"ok": True})
        if path == "/api/mch/clear":
            db.set_setting("mch", {})
            return self._json({"ok": True})
        return self._json({"ok": False, "error": "not found"}, 404)

    def do_DELETE(self):
        self.do_POST()


def make_server(port=0):
    global _tunnel, _port, LOCAL_TOKEN
    _port = port
    LOCAL_TOKEN = _gen_token()
    _tunnel = Tunnel(port)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    return httpd


def _bind_any(start_port, tries=20):
    """从 start_port 起找第一个可用端口（避免重复启动时端口占用直接崩）。"""
    last = None
    for p in range(start_port, start_port + tries):
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", p), Handler)
            httpd.daemon_threads = True
            return httpd, p
        except OSError as e:
            last = e
    raise last or OSError("no free port in range")


def _purge_loop():
    """每小时巡检一次，清理到期海报（默认长效运行时也不会堆积）。"""
    while True:
        time.sleep(3600)
        try:
            db.purge_expired()
        except Exception:
            pass


def run(port=8765, open_browser=True):
    global _port, _tunnel, LOCAL_TOKEN
    # 启动时先清一次过期海报
    try:
        db.purge_expired()
    except Exception:
        pass
    threading.Thread(target=_purge_loop, daemon=True).start()
    httpd, actual = _bind_any(port)
    _port = actual
    LOCAL_TOKEN = _gen_token()
    _tunnel = Tunnel(actual)
    url = "http://127.0.0.1:%d" % actual
    # 把令牌写到 data/local_token.txt，便于其他脚本读取
    try:
        tok_path = os.path.join(paths.data_dir(), "local_token.txt")
        with open(tok_path, "w", encoding="utf-8") as f:
            f.write(LOCAL_TOKEN)
    except Exception:
        pass
    if open_browser:
        import webbrowser
        threading.Thread(
            target=lambda: (__import__("time").sleep(0.6),
                            webbrowser.open(url + "?token=" + LOCAL_TOKEN)),
            daemon=True).start()
    lines = ["H5 海报生成器（桌面版）已启动：%s" % url,
             "管理台访问令牌：%s（已写入 data/local_token.txt，其他人访问需附加 ?token= 令牌）" % LOCAL_TOKEN,
             "数据保存在：%s" % db.DB_PATH]
    if actual != port:
        lines.insert(0, "提示：端口 %d 被占用，已自动改用 %d" % (port, actual))
    for ln in lines:
        print(ln)
    # 打包为无控制台 exe 时用户看不到 print，写一份日志兜底
    try:
        from . import paths
        with open(os.path.join(paths.log_dir(), "last-run.log"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.shutdown()
