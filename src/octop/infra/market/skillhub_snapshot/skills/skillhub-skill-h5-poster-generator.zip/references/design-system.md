# H5 海报 · 设计系统参考

生成海报前或不确定时查阅。本文件是技能的「素材字典」，所有视觉与功能都源于此。

## 一、分类（49 个，按场景分组）

**邀请函 / 会展**：`expo` 展会邀请函 · `meeting` 商务会议邀请 · `opening` 开业邀请函 ·
`anniversary` 周年庆邀请 · `summit` 峰会论坛邀请 · `franchise` 招商加盟邀请 ·
`annual` 年会邀请函 · `nonprofit` 公益活动邀请 · `parent` 家长会邀请 ·
`housewarming` 乔迁喜宴 · `reunion` 同学会/校友会

**婚礼 / 生活**：`wedding` 婚礼邀请函 · `birthday` 生日会邀请 · `baby100` 百日宴邀请 ·
`greeting` 祝福贺卡 · `album` 相册(毕业/旅行/宝宝) · `daily` 日签/语录

**企业 / 品牌**：`company` 公司简介/企业宣传 · `brochure` 企业宣传册 · `brandlaunch` 品牌发布 ·
`productlaunch` 新品发布 · `microsite` 微官网

**营销 / 电商**：`promo` 产品促销 · `seckill` 秒杀/大促 · `ecom` 电商带货 · `retail` 商超/零售

**招聘 / 教育**：`recruit` 企业招聘 · `campus` 校园招聘 · `resume` 个人简历/名片 ·
`enroll` 招生简章 · `course` 课程培训报名 · `camp` 冬夏令营招募

**金融 / 医疗**：`finance` 理财宣传 · `report` 业绩喜报/数据报告 · `survey` 调研问卷 ·
`health` 健康科普 · `medical` 医学会议/义诊

**行业专题**：`realestate` 地产/楼盘 · `auto` 汽车 · `food` 餐饮/美食 · `beauty` 美容/美妆 ·
`travel` 旅游/文旅 · `digital` 数码/家电 · `pet` 宠物 · `inkcn` 国风/中式/文旅

**互动 / 游戏**：`vote` 投票评选 · `contest` 比赛/大赛 · `lotterycat` 抽奖活动 · `game` 互动游戏

> 选用 `category` 决定默认配色与版式；用户没明确说时，按描述最贴近的选，拿不准用 `wedding`/`meeting`。

## 二、配色家族（10 个）

| 家族 key | 主色 | 气质 | 适合分类 |
|---|---|---|---|
| `business-blue` | #2f6bff | 专业冷静 | 会议/会展/招聘/金融 |
| `red-gold` | #e63946 | 喜庆红金 | 开业/周年/年会/抽奖 |
| `gold-lux` | #d4af37 | 奢华金 | 品牌/地产/钟表 |
| `romance-pink` | #ff5e8a | 浪漫粉 | 婚礼/生日/宠物/祝福 |
| `tech-dark` | #22d3ee | 科技冷光 | 数码/汽车/互动游戏 |
| `fresh-green` | #16a34a | 清新自然 | 课程/公益/健康/旅游 |
| `orange-energy` | #ff6b35 | 活力橙 | 促销/电商/餐饮/大赛 |
| `purple-dream` | #a855f7 | 梦幻紫 | 品牌发布/美妆 |
| `ink-cn` | #b08968 | 东方水墨 | 国风/文旅 |
| `minimal-light` | #334155 | 极简浅色 | 简历/微官网/相册/日签 |

> 不指定 `--accent` 时自动用分类默认家族；指定则覆盖。浅色家族（minimal-light）正文为深字。

## 三、功能模块（features 参数）

逗号传入 `--features`，按需勾选，不堆砌：

- `form` 报名回执表单（姓名/手机/出席/人数等，前端校验）
- `like` 点赞计数
- `comment` 留言祝福墙
- `qr` 二维码（需配 `--qr-target` 链接，真实可扫）
- `share` 分享给好友按钮
- `music` 背景音乐（需配 `--music` 链接/路径）
- `countdown` 倒计时（需配 `--countdown-target` 时间，如 `2026-12-20 18:00`）
- `map` 地图内嵌 + 导航按钮（填地址即可，免 key）

## 四、动态背景（AI 实时生成，无内置素材）

本技能**不打包任何图片/视频**。背景由 AI 在对话中按用户场景生成：
- 静图 → ImageGen（竖版 750×1334）
- 动态 → VideoGen（同场景短视频，循环播放）

提示词见 `references/scenes.md`（13 个场景 × ImageGen/VideoGen 各一版）。

**铁律**：生成的图/视频画面中**绝对不能出现文字、标志、数字、水印、字幕**。
违反则重生成。

## 五、产物形态

`scripts/generate.py` 输出**单文件、自包含 HTML**：
- 粒子/动效、背景图/视频均 base64 内联，**零外链、离线可跑**
- 双击即看，可发微信/邮件/网盘，任何人都能打开
- 移动优先（520px 手机框居中），桌面端呈手机卡片
- 尊重 `prefers-reduced-motion`（动效自动降级）
