/* H5 海报生成器 · 桌面版 前端逻辑 */
(function () {
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var currentPostId = null;
  var imgDataURL = "";
  var bgVideoDataURL = "";   // 动态背景视频（内置素材的会动版本）
  var curBgType = "gradient";
  var publicBase = "http://127.0.0.1:" + (location.port || "8765");
  var dataTimer = null;
  var lastData = null;

  // 分类默认配色：从 /api/meta 拉取（单一来源，避免与 server 不一致）
  var META_DEFAULTS = {};
  var META_CATS = [];
  var META_COPY = {};        // 文案素材库（分类 key → 文案数组）
  var appliedBgFile = "";    // 当前套用的内置背景文件名

  function loadMeta() {
    fetch("/api/meta").then(function (r) { return r.json(); }).then(function (m) {
      META_CATS = m.categories; META_DEFAULTS = m.defaults; META_COPY = m.copy || {};
      var sel = $("#category"); sel.innerHTML = "";
      var groups = {};
      m.categories.forEach(function (c) { (groups[c.group] = groups[c.group] || []).push(c); });
      Object.keys(groups).forEach(function (g) {
        var og = document.createElement("optgroup"); og.label = g;
        groups[g].forEach(function (c) {
          var o = document.createElement("option"); o.value = c.key; o.textContent = c.label;
          if (c.key === "wedding") o.selected = true;
          og.appendChild(o);
        });
        sel.appendChild(og);
      });
      applyCategory(sel.value || "wedding");
    }).catch(function () {});
  }

  function applyCategory(cat) {
    var d = META_DEFAULTS[cat] || META_DEFAULTS["wedding"] || {};
    if (!d.accent) return;
    $("#accent").value = d.accent; $("#accent2").value = d.accent2;
    $("#gc1").value = d.gradient[0]; $("#gc2").value = d.gradient[1]; $("#gc3").value = (d.gradient[2] || d.gradient[1]);
    $("#angle").value = d.angle; $("#angV").textContent = d.angle;
    $("#headC").value = d.headC; $("#headA").value = d.headA; $("#headT").value = d.headT;
    $("#bodyC").value = d.bodyC; $("#bodyA").value = d.bodyA; $("#bodyT").value = d.bodyT;
    $("#footC").value = d.footC; $("#footA").value = d.footA; $("#footT").value = d.footT;
    $("#pmode").value = d.pmode; $("#pc1").value = d.pc1; $("#pc2").value = d.pc2;
    $("#pspeed").value = d.pspeed; $("#spdV").textContent = d.pspeed;
    var kk = (META_CATS.filter(function (c) { return c.key === cat; })[0] || {}).kicker;
    if (kk) $("#kicker").value = kk;
    renderCopyChips(cat);
    renderPhotoGrid(cat);
  }

  function hexRgb(h) {
    h = (h || "").replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    if (isNaN(n)) return [255, 255, 255];
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgba(hex, a) { var c = hexRgb(hex); return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + (a / 100) + ")"; }

  // ---- 分类默认 ----
  $("#category").addEventListener("change", function () { applyCategory(this.value); });

  // ---- 背景类型切换 ----
  function setBgType(t) {
    curBgType = t;
    $$("#bgType button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === t); });
    $("#bgGradient").style.display = (t === "gradient" || t === "image+particles") ? "grid" : "none";
    $("#bgImage").style.display = (t === "image" || t === "image+particles") ? "block" : "none";
    $("#bgParticles").style.display = (t === "particles" || t === "image+particles") ? "block" : "none";
  }
  $$("#bgType button").forEach(function (b) { b.addEventListener("click", function () { setBgType(b.dataset.v); }); });
  $("#angle").addEventListener("input", function () { $("#angV").textContent = this.value; });
  $("#pspeed").addEventListener("input", function () { $("#spdV").textContent = this.value; });

  // ---- 功能组件：勾选后显示对应配置 ----
  var MOD_CFG = { mVideo: "cfgVideo", mMap: "cfgMap", mVote: "cfgVote", mLottery: "cfgLottery", mCoupon: "cfgCoupon", mRedpacket: "cfgRedpacket" };
  Object.keys(MOD_CFG).forEach(function (id) {
    $("#" + id).addEventListener("change", function () { $("#" + MOD_CFG[id]).style.display = this.checked ? "block" : "none"; });
  });
  // 勾选「自定义」字段后，出现命名框（给字段起名，如「微信号」）
  $("#ffCustom").addEventListener("change", function () { $("#customLabelWrap").style.display = this.checked ? "block" : "none"; });
  function lines(t) { return String(t || "").split(/\n/).map(function (s) { return s.trim(); }).filter(Boolean); }
  function couponLines(t) {
    return lines(t).map(function (l) { var p = l.split("|"); return { name: (p[0] || "").trim(), amount: (p[1] || "").trim(), code: (p[2] || "").trim() }; })
      .filter(function (c) { return c.name || c.code; });
  }

  // ---- 本地文件读取（图片/视频/音乐 → base64 内联进单个海报 HTML） ----
  var videoDataURL = "", posterDataURL = "", musicDataURL = "";
  function readMedia(input, cb, limitMB, label) {
    var f = input.files && input.files[0];
    if (!f) return;
    var mb = f.size / 1048576;
    if (mb > limitMB) {
      alert(label + "有 " + mb.toFixed(1) + " MB，内嵌后海报页面会明显变大，手机打开可能变慢。\n建议压缩到 " + limitMB + " MB 以内（仍可继续使用）。");
    }
    var r = new FileReader();
    r.onload = function () { cb(r.result); };
    r.readAsDataURL(f);
  }
  $("#imgFile").addEventListener("change", function () { readMedia(this, function (d) { imgDataURL = d; bgVideoDataURL = ""; appliedBgFile = ""; $$("#photoGrid .bg-thumb").forEach(function (t) { t.classList.remove("on"); }); }, 3, "背景图片"); });
  $("#videoFile").addEventListener("change", function () { readMedia(this, function (d) { videoDataURL = d; }, 8, "视频"); });
  $("#posterFile").addEventListener("change", function () { readMedia(this, function (d) { posterDataURL = d; }, 2, "封面图"); });
  $("#musicFile").addEventListener("change", function () { readMedia(this, function (d) { musicDataURL = d; }, 3, "音乐"); });

  // ---- 媒体来源切换：链接 / 本地文件 ----
  function setSrcType(segId, urlWrap, fileWrap, t) {
    $$("#" + segId + " button").forEach(function (b) { b.classList.toggle("on", b.dataset.v === t); });
    $("#" + urlWrap).style.display = t === "file" ? "none" : "block";
    $("#" + fileWrap).style.display = t === "file" ? "block" : "none";
  }
  $$("#videoSrcType button").forEach(function (b) { b.addEventListener("click", function () { setSrcType("videoSrcType", "videoUrlWrap", "videoFileWrap", b.dataset.v); }); });
  $$("#musicSrcType button").forEach(function (b) { b.addEventListener("click", function () { setSrcType("musicSrcType", "musicUrlWrap", "musicFileWrap", b.dataset.v); }); });

  // ---- 文案素材：按类别渲染 chips，点击一键套用 ----
  function renderCopyChips(cat) {
    var box = $("#copyChips");
    box.innerHTML = "";
    var list = META_COPY[cat] || [];
    if (!list.length) {
      box.innerHTML = '<div class="copy-empty">这个类别暂无内置文案，直接在上方填写即可。</div>';
      return;
    }
    list.forEach(function (item) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "copy-chip";
      b.innerHTML = '<span class="dot"></span>' + esc(item.name || "套用");
      b.addEventListener("click", function () {
        applyCopy(item);
        $$("#copyChips .copy-chip").forEach(function (x) { x.classList.toggle("on", x === b); });
      });
      box.appendChild(b);
    });
  }
  function applyCopy(c) {
    $("#kicker").value = c.kicker || "";
    $("#title").value = c.title || "";
    $("#subtitle").value = c.subtitle || "";
    $("#date").value = c.date || "";
    $("#location").value = c.location || "";
    $("#content").value = c.content || "";
    $("#footerNote").value = c.footerNote || "";
  }

  // ---- 内置背景素材：按类别家族匹配，点击即用（保留粒子则切 图片+粒子） ----
  // 真实场景图片素材：file → 中文标签 + 适用的分类 key；vid = 对应的动态视频（图生视频）
  // 技能开放版：不内置素材，背景由 AI 在对话中实时生成（见 references/scenes.md）
  var PHOTOS = [];
  function renderPhotoGrid(cat) {
    var box = $("#photoGrid");
    box.innerHTML = "";
    if (PHOTOS.length === 0) {
      box.innerHTML = '<div style="padding:14px 16px;background:rgba(124,140,255,.08);border:1px dashed rgba(124,140,255,.4);border-radius:10px;font-size:13px;color:var(--text-sub);line-height:1.7">本技能背景由 <b>AI 实时生成</b>。<br>在对话里描述场景（如"婚礼花艺""商务会议"），AI 会自动生成动态背景并填入，无需在此选素材。</div>';
      return;
    }
    var items = PHOTOS.map(function (p) {
      return { p: p, fit: p.cats.indexOf(cat) >= 0 };
    }).sort(function (a, b) { return (b.fit ? 1 : 0) - (a.fit ? 1 : 0); });
    items.forEach(function (it) {
      var t = document.createElement("button");
      t.type = "button";
      t.className = "bg-thumb" + (it.p.file === appliedBgFile ? " on" : "");
      t.dataset.file = it.p.file;
      t.title = it.p.label;
      t.innerHTML = '<img src="/assets/bg/' + it.p.file + '" alt="' + it.p.label + '" loading="lazy">' +
        '<span class="cap"><span>' + it.p.label + (it.p.vid ? " ▶" : "") + "</span>" + (it.fit ? '<span class="fit">适配当前</span>' : "") + "</span>";
      t.addEventListener("click", function () { applyBgAsset(it.p.file); });
      box.appendChild(t);
    });
  }
  function applyBgAsset(file) {
    // 有动态视频版的素材（▶ 标记）直接套用会动的背景，其余套用静态图
    var item = null;
    PHOTOS.forEach(function (p) { if (p.file === file) item = p; });
    var src = (item && item.vid) ? item.vid : file;
    var isVideo = !!(item && item.vid);
    fetch("/assets/bg/" + src).then(function (r) { return r.blob(); }).then(function (b) {
      var r = new FileReader();
      r.onload = function () {
        if (isVideo) { bgVideoDataURL = r.result; imgDataURL = ""; }
        else { imgDataURL = r.result; bgVideoDataURL = ""; }
        appliedBgFile = file;
        setBgType(isVideo ? "video" : (curBgType === "particles" ? "image+particles" : "image"));
        $$("#photoGrid .bg-thumb").forEach(function (t) { t.classList.toggle("on", t.dataset.file === file); });
      };
      r.readAsDataURL(b);
    }).catch(function () { alert("背景素材加载失败，请检查程序文件是否完整"); });
  }

  // ---- Tab 切换 ----
  function showTab(name) {
    $$("nav button").forEach(function (b) { b.classList.toggle("active", b.dataset.tab === name); });
    $$(".tab").forEach(function (s) { s.classList.toggle("active", s.id === "tab-" + name); });
    if (name === "pub") loadPosts();
    if (name === "set") loadMch();
    if (name === "data") { loadDataPosts(); startDataPoll(); } else { stopDataPoll(); }
  }
  $$("nav button").forEach(function (b) { b.addEventListener("click", function () { showTab(b.dataset.tab); }); });
  $("#btnGoPub").addEventListener("click", function () { showTab("pub"); });

  // ---- 生成 ----
  function collectTheme() {
    var cat = $("#category").value;
    var bgType = curBgType;
    var colors = [$("#gc1").value, $("#gc2").value, $("#gc3").value].filter(function (c) { return c && c !== "#000000" || c === "#000000"; });
    var bg = { type: bgType, colors: colors, angle: +$("#angle").value, image: imgDataURL, videoSrc: bgVideoDataURL };
    if (bgType === "particles" || bgType === "image+particles") {
      bg.particles = {
        mode: $("#pmode").value,
        colors: [$("#pc1").value, $("#pc2").value].filter(Boolean),
        speed: +$("#pspeed").value,
        interactive: $("#pinter").checked
      };
    }
    var zones = {
      head: { bg: rgba($("#headC").value, +$("#headA").value), text: $("#headT").value },
      body: { bg: rgba($("#bodyC").value, +$("#bodyA").value), text: $("#bodyT").value },
      foot: { bg: rgba($("#footC").value, +$("#footA").value), text: $("#footT").value }
    };
    var features = [];
    if ($("#fCountdown").checked) features.push("countdown");
    if ($("#fForm").checked) features.push("form");
    if ($("#fLike").checked) features.push("like");
    if ($("#fComment").checked) features.push("comment");
    if ($("#fShare").checked) features.push("share");
    var qr = $("#qrTarget").value.trim();
    if ($("#fQr").checked && qr) features.push("qr");
    var mu = $("#musicUrl").value.trim();
    if ($("#fMusic").checked && (mu || musicDataURL)) features.push("music");
    var formFields = {
      name: $("#ffName").checked, phone: $("#ffPhone").checked, attend: $("#ffAttend").checked,
      count: $("#ffCount").checked, company: $("#ffCompany").checked, diet: $("#ffDiet").checked, custom: $("#ffCustom").checked
    };
    return {
      category: cat, kicker: $("#kicker").value, title: $("#title").value, subtitle: $("#subtitle").value,
      date: $("#date").value, location: $("#location").value, content: $("#content").value,
      bg: bg, accent: $("#accent").value, accent2: $("#accent2").value, zones: zones,
      countdown: { enabled: $("#fCountdown").checked, target: $("#cdTarget").value },
      features: features, formFields: formFields, customLabel: $("#customLabel").value.trim(), submitText: $("#submitText").value,
      qrTarget: qr, musicUrl: mu, musicSrc: musicDataURL, footerNote: $("#footerNote").value,
      modules: (function () {
        var modules = {};
        if ($("#mVideo").checked) modules.video = { enabled: true, url: $("#videoUrl").value.trim(), src: videoDataURL, poster: $("#videoPoster").value.trim(), posterSrc: posterDataURL };
        if ($("#mMap").checked) modules.map = { enabled: true, address: $("#mapAddress").value.trim(), link: $("#mapLink").value.trim() };
        if ($("#mVote").checked) modules.vote = { enabled: true, question: $("#voteQ").value.trim(), options: lines($("#voteOpts").value), multiple: $("#voteMulti").checked };
        if ($("#mLottery").checked) modules.lottery = { enabled: true, title: $("#lotteryTitle").value.trim(), prizes: lines($("#lotteryPrizes").value) };
        if ($("#mRedpacket").checked) modules.redpacket = {
          enabled: true,
          pool: parseFloat($("#rpPool").value) || 100,
          count: parseInt($("#rpCount").value, 10) || 20,
          perUser: parseInt($("#rpPerUser").value, 10),
          captcha: $("#rpCaptcha").checked
        };
        if ($("#mSignin").checked) modules.signin = { enabled: true };
        if ($("#mDanmaku").checked) modules.danmaku = { enabled: true };
        if ($("#mCoupon").checked) modules.coupon = { enabled: true, title: $("#couponTitle").value.trim(), items: couponLines($("#couponItems").value) };
        return modules;
      })()
    };
  }

  $("#btnGen").addEventListener("click", function () {
    var theme = collectTheme();
    // 有效期：到期自动清理（0 = 永久）
    theme.ttlDays = parseInt($("#ttlSel").value, 10) || 0;
    fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(theme) })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res.ok) { alert("生成失败"); return; }
        currentPostId = res.id;
        var out = $("#genOut");
        out.style.display = "block";
        out.innerHTML = '✅ 已生成！本地预览：<a href="' + res.local + '" target="_blank">' + res.local + "</a><br>" +
          '<span class="hint">点「② 去发布」生成给顾客的公网链接。</span>';
        $("#btnPreview").disabled = false;
        $("#btnGoPub").disabled = false;
      })
      .catch(function () { alert("网络错误"); });
  });

  $("#btnPreview").addEventListener("click", function () {
    if (currentPostId) window.open("/p/" + currentPostId, "_blank");
  });

  // ---- 发布 ----
  function refreshStatus() {
    fetch("/api/status").then(function (r) { return r.json(); }).then(function (s) {
      publicBase = s.public_base || publicBase;
      var st = $("#tunnelState");
      if (s.tunnel && s.tunnel.running) {
        st.textContent = s.tunnel.mode === "named" ? "固定域名 · 通道运行中" : "临时通道运行中";
        $("#btnStopTunnel").style.display = "inline-block";
      } else if (s.tunnel && s.tunnel.error) {
        st.textContent = "⚠️ " + s.tunnel.error;
        $("#btnStopTunnel").style.display = "none";
      } else {
        st.textContent = "未发布";
        $("#btnStopTunnel").style.display = "none";
      }
    }).catch(function () {});
  }
  $("#btnPublish").addEventListener("click", function () {
    $("#pubErr").style.display = "none";
    $("#btnPublish").disabled = true; $("#btnPublish").textContent = "正在建立通道并校验…";
    fetch("/api/publish", { method: "POST" }).then(function (r) { return r.json(); }).then(function (res) {
      $("#btnPublish").disabled = false; $("#btnPublish").textContent = "🌐 一键发布";
      if (res.ok) {
        var link = res.public_url + "/p/" + currentPostId;
        $("#pubOut").style.display = "block";
        $("#pubUrl").textContent = res.public_url;
        $("#pubLink").textContent = link;
        $("#btnOpenLink").href = link;
        // 导出独立 HTML：自包含，上传任意空间即永久有效
        $("#btnExportHtml").href = "/api/posts/" + currentPostId + "/export";
        // 自检结果提示（DNS 负缓存会让本机暂时打不开，浏览器侧刷新即可）
        var ph = $("#probeHint");
        if (res.probe === false) {
          ph.style.display = "block";
          var tip = res.probe_hint ||
            "多半是本机/浏览器的 DNS 还缓存着“域名不存在”的旧记录：<b>等 1 分钟再刷新，或重开浏览器</b>即可；" +
            "也可以到 chrome://net-internals/#dns 点 Clear host cache。";
          ph.innerHTML = "⚠️ 通道已建立，但本机自检暂未通过（" + esc(res.probe_detail || "未知") + "）。" + esc(tip);
        } else {
          ph.style.display = "none";
        }
        // 海报链接二维码：服务端 /api/qr 渲染 PNG，可直接下载
        var qrSrc = "/api/qr?text=" + encodeURIComponent(link);
        $("#pubQr").src = qrSrc;
        $("#btnQrDownload").href = qrSrc;
        $("#btnCopyLink").onclick = function () { copy(link); this.textContent = "已复制 ✓"; };
        $("#btnStopTunnel").style.display = "inline-block";
        publicBase = res.public_url;
      } else {
        var e = $("#pubErr"); e.style.display = "block";
        var logs = (res.logs || []).slice(-2).join(" ｜ ");
        e.innerHTML = "发布失败：" + (res.error || "未知错误") +
          (logs ? "<br><span class='hint'>" + esc(logs) + "</span>" : "") +
          "<br><span class='hint'>可重试一次；仍失败请把上面这段信息发给作者。</span>";
      }
    }).catch(function () { $("#btnPublish").disabled = false; });
  });
  $("#btnStopTunnel").addEventListener("click", function () {
    fetch("/api/tunnel/stop", { method: "POST" }).then(refreshStatus);
  });

  // ---- 固定域名（named tunnel，可选）----
  function loadDomainCfg() {
    fetch("/api/tunnel/config").then(function (r) { return r.json(); }).then(function (res) {
      var c = res.config || {};
      $("#cfHostname").value = c.hostname || "";
      $("#cfTunnel").value = c.tunnel || "";
      $("#cfCred").value = "";
      $("#cfCred").placeholder = c.has_credentials
        ? ("凭证已保存（" + (c.credentials || "") + "），如需更换请重新粘贴整段 JSON")
        : '{"AccountTag":"...","TunnelID":"...","TunnelName":"...","TunnelSecret":"..."}';
      $("#domainState").textContent = (c.mode === "named" && c.hostname)
        ? "当前：固定域名 " + c.hostname
        : "当前：临时通道（每次换新地址）";
    }).catch(function () {});
  }
  $("#btnToggleDomain").addEventListener("click", function () {
    var p = $("#domainPanel");
    var open = p.style.display !== "none";
    p.style.display = open ? "none" : "block";
    this.textContent = open ? "⚙️ 展开配置" : "⚙️ 收起配置";
    if (!open) loadDomainCfg();
  });
  function postDomainCfg(payload) {
    fetch("/api/tunnel/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        var m = $("#domainMsg"); m.style.display = "block";
        if (!res.ok) { m.innerHTML = "保存失败：" + esc(res.error || "未知错误"); return; }
        var c = res.config || {};
        m.innerHTML = (c.mode === "named" && c.hostname)
          ? "✅ 已启用固定域名 <b>" + esc(c.hostname) + "</b>。回到上面点「一键发布」即按固定域名生效。"
          : "✅ 已恢复为临时通道。";
        loadDomainCfg();
      }).catch(function () {
        var m = $("#domainMsg"); m.style.display = "block"; m.innerHTML = "网络错误，请重试。";
      });
  }
  $("#btnSaveDomain").addEventListener("click", function () {
    var host = $("#cfHostname").value.trim();
    var tun = $("#cfTunnel").value.trim();
    var cred = $("#cfCred").value.trim();
    var m = $("#domainMsg");
    if (!host || !tun) { m.style.display = "block"; m.innerHTML = "请先填写固定域名和隧道名称。"; return; }
    if (!cred) { m.style.display = "block"; m.innerHTML = "请粘贴隧道凭证 JSON（整段内容）。"; return; }
    postDomainCfg({ mode: "named", hostname: host, tunnel: tun, credentials: cred });
  });
  $("#btnClearDomain").addEventListener("click", function () {
    postDomainCfg({ mode: "quick", hostname: "", tunnel: "", credentials: "" });
  });
  loadDomainCfg();
  function copy(t) { var ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); } catch (e) {} document.body.removeChild(ta); }

  // ---- 海报列表 ----
  function loadPosts() {
    fetch("/api/posts").then(function (r) { return r.json(); }).then(function (res) {
      var box = $("#postList");
      $("#postCount").textContent = res.posts.length;
      if (!res.posts.length) { box.innerHTML = '<div class="empty">还没有生成海报。</div>'; return; }
      box.innerHTML = "";
      res.posts.forEach(function (p) {
        var div = document.createElement("div");
        div.className = "li";
        var link = publicBase + "/p/" + p.id;
        div.innerHTML = '<div><b>' + esc(p.title || p.kicker || "未命名") + '</b>' +
          '<div class="hint">ID ' + p.id + ' · ' + fmtTime(p.created_at) + ' · ' + ttlText(p.expire_at) + '</div></div>' +
          '<div class="row" style="margin-left:auto">' +
          '<button class="btn ghost" data-act="prev">预览</button>' +
          '<button class="btn ghost" data-act="copy">复制链接</button>' +
          '<button class="btn danger" data-act="del">删除</button></div>';
        div.querySelector('[data-act=prev]').onclick = function () { window.open("/p/" + p.id, "_blank"); };
        div.querySelector('[data-act=copy]').onclick = function () { copy(link); this.textContent = "已复制"; };
        div.querySelector('[data-act=del]').onclick = function () {
          if (!confirm("删除该海报及其全部数据？")) return;
          fetch("/api/posts/delete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: p.id }) }).then(loadPosts);
        };
        box.appendChild(div);
      });
    });
  }

  $("#btnPurge").addEventListener("click", function () {
    var h = $("#purgeHint");
    h.textContent = "清理中…";
    fetch("/api/posts/purge", { method: "POST" }).then(function (r) { return r.json(); }).then(function (res) {
      h.textContent = res.ok ? ("已清理 " + (res.purged || 0) + " 张过期海报") : "清理失败";
      loadPosts();
    }).catch(function () { h.textContent = "清理失败"; });
  });

  // ---- 数据看板 ----
  function loadDataPosts() {
    fetch("/api/posts").then(function (r) { return r.json(); }).then(function (res) {
      var sel = $("#dataPost");
      var keep = sel.value;
      sel.innerHTML = '<option value="">选择海报…</option>';
      res.posts.forEach(function (p) {
        var o = document.createElement("option");
        o.value = p.id; o.textContent = (p.title || p.kicker || "未命名") + "（" + p.id + "）";
        sel.appendChild(o);
      });
      if (keep) sel.value = keep;
      else if (currentPostId) sel.value = currentPostId;
      if (sel.value) loadData();
    });
  }
  $("#dataPost").addEventListener("change", loadData);
  $("#btnMarkRead").addEventListener("click", function () {
    var id = $("#dataPost").value; if (!id) return;
    fetch("/api/posts/" + id + "/read", { method: "POST" }).then(loadData);
  });
  $("#btnRpReset").addEventListener("click", function () {
    var id = $("#dataPost").value; if (!id) return;
    if (!confirm("重置后红包池重新生成，此前的领取记录会清空，确定？")) return;
    fetch("/api/rp/reset", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ post: id }) }).then(loadData);
  });

  function loadData() {
    var id = $("#dataPost").value; if (!id) return;
    fetch("/api/posts/" + id + "/data").then(function (r) { return r.json(); }).then(function (d) {
      lastData = d;
      $("#sView").textContent = d.counts.view;
      $("#sLike").textContent = d.counts.like;
      $("#sCmt").textContent = d.counts.comment;
      $("#sSub").textContent = d.counts.submit;
      var unread = d.notifications.filter(function (n) { return !n.is_read; }).length;
      var badge = $("#unread");
      if (unread > 0) { badge.style.display = "inline-block"; badge.textContent = unread; } else { badge.style.display = "none"; }
      // 通知
      var nl = $("#notifList");
      nl.innerHTML = d.notifications.length ? "" : '<div class="empty">暂无互动</div>';
      d.notifications.forEach(function (n) {
        var div = document.createElement("div"); div.className = "li";
        div.innerHTML = (n.is_read ? "" : "🔵 ") + "<span>" + esc(n.text) + '</span><span class="t">' + fmtTime(n.created_at) + "</span>";
        nl.appendChild(div);
      });
      // 留言
      var cl = $("#cmtList");
      cl.innerHTML = d.comments.length ? "" : '<div class="empty">暂无留言</div>';
      d.comments.forEach(function (c) {
        var div = document.createElement("div"); div.className = "li";
        div.innerHTML = "<b>" + esc(c.payload.name || "访客") + "</b><span>" + esc(c.payload.content || "") + '</span><span class="t">' + fmtTime(c.created_at) + "</span>";
        cl.appendChild(div);
      });
      // 提交
      var sl = $("#subList");
      sl.innerHTML = d.submits.length ? "" : '<div class="empty">暂无提交</div>';
      d.submits.forEach(function (s) {
        var f = s.payload.fields || {};
        var txt = Object.keys(f).map(function (k) { return k + ":" + f[k]; }).join(" · ");
        var div = document.createElement("div"); div.className = "li";
        div.innerHTML = "<span>" + esc(txt) + '</span><span class="t">' + fmtTime(s.created_at) + "</span>";
        sl.appendChild(div);
      });
      // 红包
      var rp = d.redpacket || {};
      $("#rpPanel").style.display = rp.enabled ? "block" : "none";
      if (rp.enabled) {
        $("#rpGot").textContent = rp.claimedAmount.toFixed(2);
        $("#rpGotN").textContent = rp.claimedCount;
        $("#rpLeft").textContent = rp.leftCount;
        $("#rpPer").textContent = rp.perUser > 0 ? rp.perUser : "不限";
        var rl = $("#rpList");
        rl.innerHTML = rp.records.length ? "" : '<div class="empty">暂无人领取</div>';
        rp.records.forEach(function (r) {
          var div = document.createElement("div"); div.className = "li";
          div.innerHTML = "<b style='color:#ffd86b'>¥" + r.amount.toFixed(2) + "</b><span>设备 " + esc(r.dev) + '</span><span class="t">' + fmtTime(r.time) + "</span>";
          rl.appendChild(div);
        });
      }
    });
  }
  function startDataPoll() { stopDataPoll(); dataTimer = setInterval(loadData, 4000); }
  function stopDataPoll() { if (dataTimer) { clearInterval(dataTimer); dataTimer = null; } }

  // ---- 导出 CSV ----
  $("#btnExport").addEventListener("click", function () {
    if (!lastData) { alert("先选择海报"); return; }
    var rows = [["类型", "称呼/访客", "内容/字段", "时间"]];
    lastData.submits.forEach(function (s) {
      var f = s.payload.fields || {};
      rows.push(["表单提交", s.payload.name || "", JSON.stringify(f), fmtTime(s.created_at)]);
    });
    lastData.comments.forEach(function (c) { rows.push(["留言", c.payload.name || "", c.payload.content || "", fmtTime(c.created_at)]); });
    (lastData.redpacket && lastData.redpacket.records || []).forEach(function (r) {
      rows.push(["红包领取", "设备" + (r.dev || ""), "¥" + Number(r.amount).toFixed(2), fmtTime(r.time)]);
    });
    var csv = "\uFEFF" + rows.map(function (r) { return r.map(function (x) { return '"' + String(x).replace(/"/g, '""') + '"'; }).join(","); }).join("\n");
    var blob = new Blob([csv], { type: "text/csv" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "poster-data-" + ($("#dataPost").value || "") + ".csv"; a.click();
  });

  // ---- 工具 ----
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (m) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]; }); }
  function fmtTime(t) { if (!t) return ""; var d = new Date(t * 1000); function p(n) { return (n < 10 ? "0" : "") + n; } return p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes()); }
  function ttlText(exp) {
    if (!exp) return "永久保留";
    var left = exp * 1000 - Date.now();
    if (left <= 0) return "已过期";
    var d = Math.floor(left / 86400000), h = Math.floor((left % 86400000) / 3600000);
    if (d >= 1) return "还剩 " + d + " 天";
    if (h >= 1) return "还剩 " + h + " 小时";
    return "还剩 " + Math.max(1, Math.floor(left / 60000)) + " 分钟";
  }

  // ---- 商户配置（预留位：终端用户自己的商户，与开发者无关） ----
  function mchState(txt, ok) {
    var el = $("#mchState");
    el.textContent = txt;
    el.style.color = ok ? "#7ee2a8" : "#ff9aa2";
  }
  function loadMch() {
    fetch("/api/mch").then(function (r) { return r.json(); }).then(function (d) {
      var m = d.mch || {};
      $("#mchMchid").value = m.mchid || "";
      $("#mchScene").value = m.scene || "";
      $("#mchSerialNo").value = m.serialNo || "";
      // 密钥已保存时显示掩码，不回填原文（避免明文外泄屏幕）
      $("#mchV3Key").value = m.v3Key || "";
      $("#mchV3Key").placeholder = m.v3Key ? "已保存（不显示，输入新值可覆盖）" : "商户平台 → 账户中心 → API安全 中设置";
      $("#mchPrivateKey").value = m.privateKey || "";
      $("#mchPrivateKey").placeholder = m.privateKey ? "已保存（不显示，粘贴新内容可覆盖）" : "-----BEGIN PRIVATE KEY-----";
      mchState(d.enabled ? "已启用：红包金额将从你自己的商户账户转出" : "未配置：当前为虚拟红包（后台名单 + 自行兑现）", d.enabled);
    }).catch(function () { mchState("读取失败", false); });
  }
  $("#btnSaveMch").addEventListener("click", function () {
    var mch = {
      mchid: $("#mchMchid").value, scene: $("#mchScene").value,
      v3Key: $("#mchV3Key").value, serialNo: $("#mchSerialNo").value,
      privateKey: $("#mchPrivateKey").value
    };
    fetch("/api/mch/save", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mch: mch }) }).then(function (r) { return r.json(); }).then(function () {
      mchState("已保存到本机（data/settings.json）", true);
      loadMch();
    }).catch(function () { mchState("保存失败", false); });
  });
  $("#btnClearMch").addEventListener("click", function () {
    if (!confirm("确定清除商户配置？清除后红包恢复为虚拟模式。")) return;
    fetch("/api/mch/clear", { method: "POST", headers: { "Content-Type": "application/json" },
      body: "{}" }).then(function (r) { return r.json(); }).then(function () {
      mchState("已清除，当前为虚拟红包", true);
      loadMch();
    }).catch(function () { mchState("清除失败", false); });
  });

  // ---- 主题皮肤 ----
  var THEME_KEY = "h5poster-theme";
  function applyTheme(t) {
    document.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
    $$("#themeGrid .theme").forEach(function (b) { b.classList.toggle("on", b.dataset.t === t); });
  }
  $$("#themeGrid .theme").forEach(function (b) { b.addEventListener("click", function () { applyTheme(b.dataset.t); }); });

  // 初始化
  loadMeta();
  setBgType("gradient");
  refreshStatus();
  setInterval(refreshStatus, 8000);
  try { applyTheme(localStorage.getItem(THEME_KEY) || "stripe"); } catch (e) { applyTheme("stripe"); }
})();
