# -*- coding: utf-8 -*-
"""统一路径解析：兼容「源码运行」与「PyInstaller 打包（frozen）」两种模式。

- 源码运行：静态资源 = 工程根目录（本文件的上级目录）
- 打包运行：静态资源 = sys._MEIPASS（PyInstaller 解压目录）
            可写数据 = exe 同级目录下的 data/（保证重启、升级不丢数据；
            exe 所在盘只读时自动回退到 %LOCALAPPDATA%\\H5PosterData）
"""
import os
import sys


def is_frozen():
    return bool(getattr(sys, "frozen", False))


def _project_root():
    if is_frozen():
        return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _writable_root():
    if is_frozen():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def base_dir():
    """静态资源根目录：webroot/、assets/、bin/ 都在它下面。"""
    return _project_root()


def data_dir():
    """可写数据目录：数据库、日志。默认在程序目录/data/，只读时回退用户目录。"""
    d = os.path.join(_writable_root(), "data")
    try:
        os.makedirs(d, exist_ok=True)
        probe = os.path.join(d, ".writable")
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)
    except OSError:
        fallback = os.path.join(
            os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"),
            "H5PosterData",
        )
        d = fallback
        os.makedirs(d, exist_ok=True)
    return d


def log_dir():
    d = os.path.join(data_dir(), "logs")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d
