# -*- coding: utf-8 -*-
"""本地 SQLite 数据层：海报、互动记录、通知。"""
import os
import json
import time
import sqlite3
import threading

from . import paths

DATA_DIR = paths.data_dir()
DB_PATH = os.path.join(DATA_DIR, "h5poster.db")

_lock = threading.RLock()
_conn = None


def _connect():
    global _conn
    if _conn is None:
        os.makedirs(DATA_DIR, exist_ok=True)
        _conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _init_schema(_conn)
    return _conn


def _init_schema(c):
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS posters (
            id TEXT PRIMARY KEY,
            title TEXT,
            kicker TEXT,
            category TEXT,
            html TEXT,
            theme TEXT,
            created_at INTEGER,
            expire_at INTEGER          -- 到期时间戳（毫秒）；NULL/0 = 永久
        );
        CREATE TABLE IF NOT EXISTS interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id TEXT,
            type TEXT,              -- view / like / comment / submit
            payload TEXT,           -- JSON
            created_at INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_inter_post ON interactions(post_id, type);
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id TEXT,
            text TEXT,
            is_read INTEGER DEFAULT 0,
            created_at INTEGER
        );
        CREATE TABLE IF NOT EXISTS redpackets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            post_id TEXT,
            code TEXT,               -- 领取凭证（防重码）
            amount REAL,             -- 金额（元）
            dev TEXT,                -- 领取设备标识
            claimed_at INTEGER       -- NULL=未领
        );
        CREATE INDEX IF NOT EXISTS idx_rp_post ON redpackets(post_id, claimed_at);
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at INTEGER
        );
        """
    )
    # 旧库升级：CREATE TABLE IF NOT EXISTS 不会补列，这里手动补齐后再建索引
    try:
        cols = {r["name"] for r in c.execute("PRAGMA table_info(posters)")}
        if "expire_at" not in cols:
            c.execute("ALTER TABLE posters ADD COLUMN expire_at INTEGER")
        c.execute("CREATE INDEX IF NOT EXISTS idx_post_expire ON posters(expire_at)")
    except Exception:
        pass
    c.commit()


def new_post_id():
    import uuid
    return uuid.uuid4().hex[:12]


def create_poster(post_id, title, kicker, category, html, theme, ttl_days=None):
    """ttl_days：有效天数（1/3/7/30…）；None 或 0 = 永久。"""
    now = int(time.time())
    expire = now + int(ttl_days) * 86400 if ttl_days else 0
    with _lock:
        c = _connect()
        try:
            c.execute(
                "INSERT INTO posters(id,title,kicker,category,html,theme,created_at,expire_at)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (post_id, title, kicker, category, html,
                 json.dumps(theme, ensure_ascii=False), now, expire),
            )
        except sqlite3.OperationalError:
            # 极端情况下列还没补上，退回老字段写一次
            c.execute(
                "INSERT INTO posters(id,title,kicker,category,html,theme,created_at) VALUES(?,?,?,?,?,?,?)",
                (post_id, title, kicker, category, html, json.dumps(theme, ensure_ascii=False), now),
            )
        c.commit()


def get_poster(post_id):
    with _lock:
        c = _connect()
        row = c.execute("SELECT * FROM posters WHERE id=?", (post_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        exp = d.get("expire_at") or 0
        if exp and exp <= int(time.time()):
            return None  # 已过期：对外等同不存在
        return d


def list_posters():
    """只返回未过期的海报；顺带把已过期的清掉（惰性清理）。"""
    purge_expired()
    with _lock:
        c = _connect()
        rows = c.execute(
            "SELECT id,title,kicker,category,created_at,expire_at FROM posters"
            " WHERE expire_at IS NULL OR expire_at=0 OR expire_at>? ORDER BY created_at DESC",
            (int(time.time()),),
        ).fetchall()
        return [dict(r) for r in rows]


def purge_expired():
    """物理删除所有已过期海报及其关联数据，返回删除条数。"""
    now = int(time.time())
    with _lock:
        c = _connect()
        rows = c.execute(
            "SELECT id FROM posters WHERE expire_at IS NOT NULL AND expire_at>0 AND expire_at<=?",
            (now,),
        ).fetchall()
        ids = [r["id"] for r in rows]
        for pid in ids:
            c.execute("DELETE FROM posters WHERE id=?", (pid,))
            c.execute("DELETE FROM interactions WHERE post_id=?", (pid,))
            c.execute("DELETE FROM notifications WHERE post_id=?", (pid,))
            c.execute("DELETE FROM redpackets WHERE post_id=?", (pid,))
        if ids:
            c.commit()
        return len(ids)


def delete_poster(post_id):
    with _lock:
        c = _connect()
        c.execute("DELETE FROM posters WHERE id=?", (post_id,))
        c.execute("DELETE FROM interactions WHERE post_id=?", (post_id,))
        c.execute("DELETE FROM notifications WHERE post_id=?", (post_id,))
        c.execute("DELETE FROM redpackets WHERE post_id=?", (post_id,))
        c.commit()


# ================= 红包（服务端开奖） =================

# 内存验证码存储（不落库）：token -> {"code","exp"}
_CAPTCHAS = {}
_CAPTCHA_TTL = 600  # 10 分钟


def captcha_create():
    """生成 4 位验证码（去掉易混淆字符），返回 (token, code)。"""
    import random
    import uuid
    chars = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
    code = "".join(random.choice(chars) for _ in range(4))
    token = uuid.uuid4().hex
    now = time.time()
    for t in [k for k, v in _CAPTCHAS.items() if v["exp"] < now]:
        _CAPTCHAS.pop(t, None)
    _CAPTCHAS[token] = {"code": code, "exp": now + _CAPTCHA_TTL}
    return token, code


def captcha_verify(token, answer):
    e = _CAPTCHAS.get(token or "")
    if not e or e["exp"] < time.time():
        return False
    return str(answer or "").strip().upper() == e["code"].upper()


def captcha_svg(code):
    """纯字符串 SVG 验证码图（零依赖，浏览器直接渲染）。"""
    import random
    W, H = 120, 44
    bg = ("#f6f3ec", "#eef4fb", "#fdf0f0", "#f0faf3")[random.randint(0, 3)]
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">' % (W, H, W, H),
             '<rect width="%d" height="%d" fill="%s"/>' % (W, H, bg)]
    colors = ["#e63946", "#1d3557", "#2a9d8f", "#e76f51", "#6a4c93", "#0077b6"]
    for i, ch in enumerate(code):
        x = 14 + i * 26 + random.uniform(-4, 4)
        y = 30 + random.uniform(-5, 5)
        parts.append('<text x="%.1f" y="%.1f" font-size="26" font-family="Georgia,serif" font-weight="bold" '
                     'fill="%s" transform="rotate(%.1f %.1f %.1f)">%s</text>'
                     % (x, y, colors[random.randint(0, len(colors) - 1)],
                        random.uniform(-28, 28), x, y, ch))
    for _ in range(3):
        x1, y1 = random.uniform(0, W), random.uniform(0, H)
        parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="%s" stroke-width="1.2" opacity="0.5"/>'
                     % (x1, y1, x1 + random.uniform(-30, 30), y1 + random.uniform(-16, 16),
                        colors[random.randint(0, len(colors) - 1)]))
    for _ in range(24):
        parts.append('<circle cx="%.1f" cy="%.1f" r="1.1" fill="#999" opacity="0.45"/>'
                     % (random.uniform(0, W), random.uniform(0, H)))
    parts.append("</svg>")
    return "".join(parts)

def _split_amounts(total, count):
    """二倍均值法切分总金额为 count 份，最后一份兜底（经典微信红包算法）。"""
    import random
    total = round(float(total), 2)
    count = int(count)
    if count <= 0:
        return []
    if total < count * 0.01:
        total = round(count * 0.01, 2)
    amounts = []
    remaining = total
    left = count
    for _ in range(count - 1):
        max_v = max(0.01, remaining / left * 2)
        v = round(random.uniform(0.01, max_v), 2)
        v = max(0.01, min(v, round(remaining - 0.01 * (left - 1), 2)))
        amounts.append(v)
        remaining = round(remaining - v, 2)
        left -= 1
    amounts.append(round(remaining, 2))
    return amounts


def ensure_redpacket_pool(post_id):
    """按海报 theme 里的 redpacket 配置懒初始化红包池；返回配置 dict 或 None。"""
    with _lock:
        c = _connect()
        row = c.execute("SELECT theme FROM posters WHERE id=?", (post_id,)).fetchone()
        if not row:
            return None
        try:
            theme = json.loads(row["theme"] or "{}")
        except Exception:
            return None
        cfg = (theme.get("modules") or {}).get("redpacket") or {}
        if not cfg.get("enabled"):
            return None
        n = c.execute("SELECT COUNT(*) n FROM redpackets WHERE post_id=?", (post_id,)).fetchone()["n"]
        if n > 0:
            return cfg
        count = max(1, int(cfg.get("count", 20) or 20))
        pool = float(cfg.get("pool", 100) or 100)
        amounts = _split_amounts(pool, count)
        import random
        random.shuffle(amounts)  # 打乱顺序，先点先得与金额无关
        import uuid
        for a in amounts:
            c.execute(
                "INSERT INTO redpackets(post_id,code,amount,dev,claimed_at) VALUES(?,?,?,?,NULL)",
                (post_id, uuid.uuid4().hex[:10], a, ""),
            )
        c.commit()
        return cfg


def grab_redpacket(post_id, dev="", per_user=None, captcha_token="", captcha_answer=""):
    """服务端开奖：限量 + 限人次 +（可选）图形验证码。返回 {ok, amount, left} 或 {ok:False, reason}。"""
    with _lock:
        c = _connect()
        cfg = ensure_redpacket_pool(post_id)
        if not cfg:
            return {"ok": False, "reason": "disabled"}
        # 验证码校验（防脚本刷）
        if cfg.get("captcha") and not captcha_verify(captcha_token, captcha_answer):
            return {"ok": False, "reason": "captcha"}
        if per_user is None:
            per_user = cfg.get("perUser", 1)
            per_user = 1 if per_user is None else int(per_user)
        if dev and per_user > 0:
            n = c.execute(
                "SELECT COUNT(*) n FROM redpackets WHERE post_id=? AND dev=?", (post_id, dev)
            ).fetchone()["n"]
            if n >= per_user:
                return {"ok": False, "reason": "limit"}
        # 同一设备 2 秒内只能抢一次（防连点）
        if dev:
            last = c.execute(
                "SELECT MAX(claimed_at) t FROM redpackets WHERE post_id=? AND dev=?", (post_id, dev)
            ).fetchone()["t"]
            if last and time.time() - last < 2:
                return {"ok": False, "reason": "fast"}
        row = c.execute(
            "SELECT id, code, amount FROM redpackets WHERE post_id=? AND claimed_at IS NULL ORDER BY id LIMIT 1",
            (post_id,),
        ).fetchone()
        if not row:
            return {"ok": False, "reason": "empty"}
        c.execute(
            "UPDATE redpackets SET dev=?, claimed_at=? WHERE id=?",
            (dev or "", int(time.time()), row["id"]),
        )
        c.commit()
        # 记录互动 + 通知（服务端权威记录，前端改不了）
        add_interaction(post_id, "redpacket", {"amount": row["amount"], "code": row["code"],
                                               "dev": (dev or "")[:8]})
        left = c.execute(
            "SELECT COUNT(*) n FROM redpackets WHERE post_id=? AND claimed_at IS NULL", (post_id,)
        ).fetchone()["n"]
        return {"ok": True, "amount": row["amount"], "code": row["code"], "left": left}


def reset_redpacket_pool(post_id):
    """重置红包池（活动再开一轮）。"""
    with _lock:
        c = _connect()
        c.execute("DELETE FROM redpackets WHERE post_id=?", (post_id,))
        c.commit()
        ensure_redpacket_pool(post_id)


def redpacket_stats(post_id):
    with _lock:
        c = _connect()
        cfg = ensure_redpacket_pool(post_id) or {}
        rows = c.execute(
            "SELECT code, amount, dev, claimed_at FROM redpackets WHERE post_id=? ORDER BY id",
            (post_id,),
        ).fetchall()
        claimed = [r for r in rows if r["claimed_at"]]
        return {
            "enabled": bool(cfg.get("enabled")),
            "pool": float(cfg.get("pool", 0) or 0),
            "count": int(cfg.get("count", 0) or 0),
            "perUser": int(cfg.get("perUser", 1) or 1),
            "claimedCount": len(claimed),
            "claimedAmount": round(sum(r["amount"] for r in claimed), 2),
            "leftCount": len(rows) - len(claimed),
            "records": [
                {"amount": r["amount"], "dev": (r["dev"] or "")[:8], "time": r["claimed_at"]}
                for r in reversed(claimed)
            ],
        }


def add_interaction(post_id, itype, payload):
    with _lock:
        c = _connect()
        c.execute(
            "INSERT INTO interactions(post_id,type,payload,created_at) VALUES(?,?,?,?)",
            (post_id, itype, json.dumps(payload or {}, ensure_ascii=False), int(time.time())),
        )
        # 生成一条通知
        text = _notify_text(itype, payload)
        c.execute(
            "INSERT INTO notifications(post_id,text,is_read,created_at) VALUES(?,?,0,?)",
            (post_id, text, int(time.time())),
        )
        c.commit()


def _notify_text(itype, payload):
    p = payload or {}
    if itype == "view":
        return "有新浏览"
    if itype == "like":
        return "有人点赞了 ❤"
    if itype == "comment":
        name = p.get("name") or "访客"
        content = (p.get("content") or "")[:30]
        if p.get("danmaku"):
            return "弹幕：%s" % content
        return "%s 留言：%s" % (name, content)
    if itype == "submit":
        name = p.get("name") or "访客"
        return "%s 提交了表单" % name
    if itype == "vote":
        return "有人投票：%s" % ("、".join(p.get("options") or [])[:30])
    if itype == "lottery":
        return "有人抽奖，结果：%s" % (p.get("prize") or "")
    if itype == "signin":
        return "有人签到（连续 %s 天）" % p.get("days", 1)
    if itype == "coupon":
        return "有人领取优惠券：%s" % (p.get("name") or p.get("code") or "")
    if itype == "redpacket":
        return "有人抢到红包 ¥%s" % (p.get("amount") if p.get("amount") is not None else p.get("got", 0))
    return "新互动：%s" % itype


def post_stats(post_id):
    """返回某海报的计数 + 明细 + 通知。"""
    with _lock:
        c = _connect()
        counts = {"view": 0, "like": 0, "comment": 0, "submit": 0,
                  "vote": 0, "lottery": 0, "signin": 0, "coupon": 0, "redpacket": 0}
        for r in c.execute(
            "SELECT type, COUNT(*) n FROM interactions WHERE post_id=? GROUP BY type", (post_id,)
        ).fetchall():
            counts[r["type"]] = r["n"]
        comments = [
            dict(r) for r in c.execute(
                "SELECT payload, created_at FROM interactions WHERE post_id=? AND type='comment' ORDER BY id DESC LIMIT 200",
                (post_id,),
            ).fetchall()
        ]
        submits = [
            dict(r) for r in c.execute(
                "SELECT payload, created_at FROM interactions WHERE post_id=? AND type='submit' ORDER BY id DESC LIMIT 200",
                (post_id,),
            ).fetchall()
        ]
        likes = [
            dict(r) for r in c.execute(
                "SELECT created_at FROM interactions WHERE post_id=? AND type='like' ORDER BY id DESC LIMIT 200",
                (post_id,),
            ).fetchall()
        ]
        notifs = [
            dict(r) for r in c.execute(
                "SELECT id,text,is_read,created_at FROM notifications WHERE post_id=? ORDER BY id DESC LIMIT 200",
                (post_id,),
            ).fetchall()
        ]
        for r in comments + submits:
            try:
                r["payload"] = json.loads(r["payload"])
            except Exception:
                r["payload"] = {}
        return {
            "counts": counts,
            "comments": comments,
            "submits": submits,
            "likes": likes,
            "notifications": notifs,
            "redpacket": redpacket_stats(post_id),
        }


def mark_notifications_read(post_id):
    with _lock:
        c = _connect()
        c.execute("UPDATE notifications SET is_read=1 WHERE post_id=?", (post_id,))
        c.commit()


def unread_count():
    with _lock:
        c = _connect()
        r = c.execute("SELECT COUNT(*) n FROM notifications WHERE is_read=0").fetchone()
        return r["n"] if r else 0


# ================= 设置（商户配置等键值对） ================

def get_setting(key, default=None):
    with _lock:
        c = _connect()
        r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if not r:
            return default
        try:
            return json.loads(r["value"])
        except Exception:
            return default


def set_setting(key, value):
    with _lock:
        c = _connect()
        c.execute(
            "INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key, json.dumps(value, ensure_ascii=False), int(time.time())),
        )
        c.commit()
