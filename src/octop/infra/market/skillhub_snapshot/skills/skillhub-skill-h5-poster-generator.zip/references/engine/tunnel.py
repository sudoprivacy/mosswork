# -*- coding: utf-8 -*-
"""隧道发布：支持两种模式。

1) quick（默认）：cloudflared quick tunnel，免费免配置，但链接每次随机、
   软件一关即失效。
2) named（可选）：用你自己的 Cloudflare 域名 + 固定隧道，链接固定不变、
   只要电脑开着就一直有效（关掉软件仍失效，除非隧道由系统服务托管）。

另含两处健壮性处理：
- 拿到公网地址后自动 `ipconfig /flushdns`：Windows 会把“隧道建立前”的
  NXDOMAIN 负缓存住，导致浏览器 ERR_NAME_NOT_RESOLVED（2026-10 实测）。
- 发布后自检：程序自己请求一次公网地址，确认真的通了再告诉用户。
"""
import os
import json
import re
import shutil
import subprocess
import threading
import time
import urllib.request

from . import paths

BIN_DIR = os.path.join(paths.base_dir(), "bin")
DATA_DIR = paths.data_dir()
CFG_PATH = os.path.join(DATA_DIR, "tunnel.json")
CF_DIR = os.path.join(DATA_DIR, "cloudflared")

DEFAULT_CFG = {"mode": "quick", "tunnel": "", "hostname": "", "credentials": ""}

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) H5Poster/1.0 "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")


def find_cloudflared():
    # 1) 项目自带 bin 目录
    for name in ("cloudflared", "cloudflared.exe"):
        p = os.path.join(BIN_DIR, name)
        if os.path.isfile(p):
            return p
    # 2) 系统 PATH
    for name in ("cloudflared", "cloudflared.exe"):
        p = shutil.which(name)
        if p:
            return p
    # 3) 常见安装位置
    for p in (
        "/usr/local/bin/cloudflared", "/usr/bin/cloudflared",
        "/opt/homebrew/bin/cloudflared",
        os.path.expanduser("~/.cloudflare-warp/cloudflared"),
    ):
        if os.path.isfile(p):
            return p
    return None


# ───────────────────────── 配置读写 ─────────────────────────
def load_cfg():
    try:
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        return dict(DEFAULT_CFG)
    out = dict(DEFAULT_CFG)
    for k in DEFAULT_CFG:
        out[k] = cfg.get(k, "") or ""
    return out


def save_cfg(cfg):
    data = dict(DEFAULT_CFG)
    for k in DEFAULT_CFG:
        data[k] = (cfg.get(k, "") or "").strip()
    if data["mode"] not in ("quick", "named"):
        data["mode"] = "quick"
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return data


def mask_cfg(cfg):
    """对外返回时脱敏：凭证只给头尾，不把密钥发给浏览器。"""
    c = cfg.get("credentials", "") or ""
    masked = ""
    if c:
        masked = c[:8] + "…（已保存 " + str(len(c)) + " 字符）"
    return {
        "mode": cfg.get("mode", "quick"),
        "tunnel": cfg.get("tunnel", ""),
        "hostname": cfg.get("hostname", ""),
        "credentials": masked,
        "has_credentials": bool(c),
    }


def _write_named_files(cfg, local_port):
    """把凭证与 config.yml 落到 data/cloudflared/，返回 config.yml 路径。"""
    os.makedirs(CF_DIR, exist_ok=True)
    try:
        cred_obj = json.loads(cfg["credentials"])
        tid = cred_obj.get("TunnelID") or cfg["tunnel"] or "tunnel"
    except Exception:
        tid = cfg["tunnel"] or "tunnel"
    cred_path = os.path.join(CF_DIR, str(tid) + ".json")
    with open(cred_path, "w", encoding="utf-8") as f:
        f.write(cfg["credentials"])
    # 注意：YAML 里路径含反斜杠需正斜杠，避免转义问题
    cp = cred_path.replace("\\", "/")
    origin = "http://127.0.0.1:%d" % local_port
    host = (cfg.get("hostname") or "").strip()
    lines = [
        "url: %s" % origin,
        "tunnel: %s" % (cfg.get("tunnel") or tid),
        'credentials-file: "%s"' % cp,
        "ingress:",
    ]
    if host:
        lines += ["  - hostname: %s" % host, "    service: %s" % origin]
    lines += ["  - service: http_status:404"]
    yml = os.path.join(CF_DIR, "config.yml")
    with open(yml, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return yml


def flush_dns():
    """清掉 Windows DNS 负缓存（隧道建立前的 NXDOMAIN 会被缓存住）。"""
    if os.name != "nt":
        return False
    try:
        subprocess.run(["ipconfig", "/flushdns"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=10,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return True
    except Exception:
        return False


def probe_url(url, timeout=8):
    """自检公网地址是否真的可达。返回 (ok, detail)。

    必须显式绕过系统代理：urllib 会读 http_proxy 环境变量，本机若开了代理，
    访问 trycloudflare 会被代理挡成 502，自检结果就是假阴性。
    """
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with opener.open(req, timeout=timeout) as r:
            return True, "HTTP %s" % r.status
    except Exception as e:
        return False, str(e)


def wait_reachable(url, tries=7, interval=4, timeout=8):
    """隧道刚建好时 DNS 还没同步开，反复刷新 DNS 并重试，直到真的能访问。"""
    detail = ""
    for i in range(tries):
        ok, detail = probe_url(url, timeout=timeout)
        if ok:
            return True, detail
        if i < tries - 1:
            flush_dns()
            time.sleep(interval)
    return False, detail


def diagnose_dns(url):
    """自检失败时定位是谁的问题：本机/本地 DNS 慢，还是隧道没就绪。

    返回 (代码, 说明)。代码：
      dns_lag  —— 公共 DNS 已能解析，本地 DNS 还没同步（用户需改 DNS 或稍等）
      not_ready—— 公共 DNS 也解析不了，隧道尚未生效
      unknown  —— 无法判定
    """
    host = url.split("//")[-1].split("/")[0]
    # 系统 DNS（经本机 DNS 缓存）
    sys_ok = False
    try:
        import socket
        socket.setdefaulttimeout(6)
        socket.gethostbyname(host)
        sys_ok = True
    except Exception:
        sys_ok = False
    # 公共 DNS 对照
    pub_ip = ""
    for dns in ("223.5.5.5", "119.29.29.29", "114.114.114.114"):
        ip = _nslookup(host, dns)
        if ip:
            pub_ip = ip
            break
    if pub_ip and not sys_ok:
        return "dns_lag", ("公共 DNS（%s）已能解析到 %s，但你电脑的 DNS 还没同步。"
                           "建议把 DNS 改成 223.5.5.5，或等 1~2 分钟再打开。" % (dns, pub_ip))
    if not pub_ip:
        return "not_ready", "公共 DNS 也解析不到该地址，通道可能还没生效，稍等半分钟再点一次发布。"
    return "unknown", "地址已能解析但访问未成功，请刷新页面或重开浏览器。"


def _nslookup(host, dns_server, timeout=6):
    """用指定 DNS 服务器查询，返回首个 A 记录 IP。"""
    try:
        out = subprocess.run(["nslookup", host, dns_server],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             timeout=timeout, universal_newlines=True,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        return ""
    txt = out.stdout or ""
    # 取最后一个「Addresses:」块里的第一个 IPv4
    ips = re.findall(r"(?:\d{1,3}\.){3}\d{1,3}", txt)
    # 排除掉 DNS 服务器自身那一行
    for ip in ips:
        if ip not in (dns_server, "127.0.0.1") and not ip.startswith("192.168."):
            return ip
    return ""


class Tunnel:
    def __init__(self, local_port):
        self.local_port = local_port
        self.proc = None
        self.public_url = None
        self._log = []
        self._lock = threading.Lock()
        self._err = ""
        self._mode = "quick"

    # ───────────────────────── 对外 ─────────────────────────
    def start(self):
        """启动隧道，返回公网 URL；失败返回 None。"""
        with self._lock:
            if self.proc and self.proc.poll() is None and self.public_url:
                return self.public_url
            cfg = load_cfg()
            use_named = (cfg.get("mode") == "named" and cfg.get("credentials")
                         and cfg.get("tunnel"))
            self._mode = "named" if use_named else "quick"
            if use_named:
                url = self._start_named(cfg)
            else:
                url = self._start_quick()
            if not url:
                return None
            self.public_url = url
            # 隧道刚建好时，本机 DNS 常缓存着「域名还不存在」的负缓存，
            # 直接把链接给用户就会显示 ERR_NAME_NOT_RESOLVED。
            # 这里反复清 DNS 并重试，尽量保证用户拿到手就能打开。
            flush_dns()
            ok, detail = wait_reachable(url, tries=5, interval=3)
            self._probe_ok = ok
            self._probe_detail = detail
            if not ok:
                self._log.append("[自检] 暂时无法访问：%s" % detail)
                try:
                    self._probe_code, self._probe_hint = diagnose_dns(url)
                except Exception:
                    self._probe_code, self._probe_hint = "unknown", ""
            else:
                self._probe_code, self._probe_hint = "ok", ""
            return url

    def _drain(self):
        try:
            for line in iter(self.proc.stdout.readline, ""):
                self._log.append(line.rstrip())
                self._log = self._log[-80:]
        except Exception:
            pass
        # 进程退出 → 公网地址立即作废，避免前端继续展示已失效链接
        self._log.append("[通道] 进程已退出，公网地址失效")

    # ───────────────────────── quick ─────────────────────────
    def _start_quick(self):
        exe = find_cloudflared()
        if not exe:
            self._err = "未找到 cloudflared（请把可执行文件放到 bin/ 或加入 PATH）"
            return None
        try:
            # CREATE_NO_WINDOW：不弹出黑色控制台窗口（遮挡管理页且吓人）
            # --protocol http2：强制走 TCP/443，国内网络下 QUIC(UDP) 长连接易被 QoS 掐断导致 1033
            self.proc = subprocess.Popen(
                [exe, "tunnel", "--url", "http://127.0.0.1:%d" % self.local_port,
                 "--no-autoupdate", "--protocol", "http2"],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, universal_newlines=True, bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as e:
            self._err = "启动失败：%s" % e
            return None
        url = None
        deadline = time.time() + 25
        for line in iter(self.proc.stdout.readline, ""):
            self._log.append(line.rstrip())
            self._log = self._log[-80:]
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
            if m:
                url = m.group(0)
                break
            if time.time() > deadline:
                break
        if url:
            threading.Thread(target=self._drain, daemon=True).start()
        else:
            tail = " ｜ ".join(self._log[-3:])[:300]
            if self.proc and self.proc.poll() is not None:
                self._err = "cloudflared 已退出（code %s）%s" % (self.proc.returncode, tail)
            else:
                self._err = "25 秒内未拿到公网地址 %s" % (tail or "（无日志输出）")
        return url

    # ───────────────────────── named ─────────────────────────
    def _start_named(self, cfg):
        exe = find_cloudflared()
        if not exe:
            self._err = "未找到 cloudflared（请把可执行文件放到 bin/ 或加入 PATH）"
            return None
        try:
            yml = _write_named_files(cfg, self.local_port)
        except Exception as e:
            self._err = "写入固定域名配置失败：%s" % e
            return None
        try:
            self.proc = subprocess.Popen(
                [exe, "--no-autoupdate", "--protocol", "http2",
                 "--config", yml, "tunnel", "run", cfg.get("tunnel") or ""],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, universal_newlines=True, bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as e:
            self._err = "启动固定域名通道失败：%s" % e
            return None
        # 等到隧道连接注册成功；同时顺手抓一下日志里出现的地址
        url = None
        host = (cfg.get("hostname") or "").strip()
        deadline = time.time() + 25
        for line in iter(self.proc.stdout.readline, ""):
            self._log.append(line.rstrip())
            self._log = self._log[-80:]
            low = line.lower()
            if "registered tunnel connection" in low or "registered" in low and "connection" in low:
                break
            if time.time() > deadline:
                break
        if self.proc.poll() is not None:
            tail = " ｜ ".join(self._log[-3:])[:300]
            self._err = "cloudflared 已退出（code %s）%s" % (self.proc.returncode, tail)
            return None
        url = "https://%s" % host if host else None
        if not url:
            self._err = "固定域名未填写（hostname 为空）"
            return None
        threading.Thread(target=self._drain, daemon=True).start()
        return url

    # ───────────────────────── 生命周期 ─────────────────────────
    def stop(self):
        with self._lock:
            if self.proc and self.proc.poll() is None:
                try:
                    self.proc.terminate()
                except Exception:
                    pass
            self.proc = None
            self.public_url = None

    def status(self):
        alive = bool(self.proc and self.proc.poll() is None)
        running = alive and bool(self.public_url)
        return {
            "running": running,
            # 进程已死就不再返回旧链接，避免前端展示失效地址
            "public_url": self.public_url if running else None,
            "mode": self._mode,
            "probe": bool(getattr(self, "_probe_ok", False)),
            "probe_detail": getattr(self, "_probe_detail", ""),
            "probe_code": getattr(self, "_probe_code", ""),
            "probe_hint": getattr(self, "_probe_hint", ""),
            "error": self._err,
            "bin": find_cloudflared(),
        }

    def logs(self):
        return list(self._log[-40:])
