# -*- coding: utf-8 -*-
"""文案素材库：每个海报分类的现成文案，用户一键套用后可再随意改。
字段与表单一一对应：kicker=标题上方小字 / title=主标题 / subtitle=副标题 /
date=时间 / location=地点 / content=正文(\\n 换行) / footerNote=底部备注。
写法要求：说人话、有场景感、不堆形容词。"""

COPY_BANK = {
    "wedding": [
        {"name": "温馨版", "kicker": "婚礼请柬", "title": "我们结婚啦", "subtitle": "诚挚邀请你见证我们的幸福时刻",
         "date": "12 月 20 日 18:00", "location": "杭州 · 西湖国宾馆",
         "content": "从校服到婚纱，谢谢你一路在场。\n这一天，因为有你才完整。", "footerNote": "期待与你相见"},
        {"name": "正式版", "kicker": "INVITATION", "title": "诚邀莅临", "subtitle": "陈先生 ❤ 李小姐 婚礼典礼",
         "date": "2026 年 12 月 20 日 18:00", "location": "星河会议中心 · 一楼宴会厅",
         "content": "谨定于公历二〇二六年十二月二十日举行婚礼，恭请阁下携家人光临，共饮此杯。", "footerNote": "敬备喜宴 · 恭候佳音"},
    ],
    "annual": [
        {"name": "温情版", "kicker": "年会邀请", "title": "又是一年，谢谢你", "subtitle": "2026 年度盛会 · 诚邀你到场",
         "date": "1 月 18 日 18:30", "location": "万达嘉华酒店 · 三层宴会厅",
         "content": "这一年辛苦了。\n来吃顿饭、领份年礼、抽个大奖，咱们不见不散。", "footerNote": "全体同仁 敬邀"},
        {"name": "正式版", "kicker": "ANNUAL GALA", "title": "2026 年度盛典", "subtitle": "聚势 · 同行 · 赢未来",
         "date": "2026 年 1 月 18 日 18:30", "location": "国际会议中心 · 主会场",
         "content": "谨邀您出席公司年度盛典，与全体同仁共叙情谊、共话来年。", "footerNote": "凭此邀请函入场"},
    ],
    "opening": [
        {"name": "喜庆版", "kicker": "开业大吉", "title": "我们开业啦", "subtitle": "新店启幕 · 惠顾满堂",
         "date": "10 月 28 日 09:08", "location": "中山路 128 号（旗舰店）",
         "content": "筹备了三百天，终于在今天见面。\n开业前三天全场八折，到店就有伴手礼。", "footerNote": "欢迎街坊邻里来坐坐"},
        {"name": "正式版", "kicker": "GRAND OPENING", "title": "诚邀共启新程", "subtitle": "××品牌旗舰店开业典礼",
         "date": "2026 年 10 月 28 日 09:08", "location": "中山路 128 号 · 旗舰店",
         "content": "诚邀您出席开业典礼，见证新店启幕，同享开业礼遇。", "footerNote": "凭邀请函享开业礼遇"},
    ],
    "birthday": [
        {"name": "活泼版", "kicker": "生日派对", "title": "来我家过生日呀", "subtitle": "甜甜的蛋糕已经备好",
         "date": "11 月 8 日 15:00", "location": "望江路小区 3 栋 502",
         "content": "蛋糕、气球、游戏机都准备好了，\n就差你了。记得带礼物（不是）。", "footerNote": "来不了也要说生日快乐呀"},
        {"name": "正式版", "kicker": "BIRTHDAY PARTY", "title": "生日会邀请", "subtitle": "小王子周岁宴",
         "date": "2026 年 11 月 8 日 15:00", "location": "云端酒店 · 亲子厅",
         "content": "诚邀您携家人出席宝宝的周岁生日会，共享甜蜜时光。", "footerNote": "静候佳音"},
    ],
    "promo": [
        {"name": "紧迫版", "kicker": "限时优惠", "title": "全年最低，就这几天", "subtitle": "秋冬新品 5 折起",
         "date": "10 月 20 日 - 10 月 26 日", "location": "线上商城 · 同步开抢",
         "content": "错过等一年。\n满 299 减 50，前 100 名再送定制礼盒。", "footerNote": "库存有限，售完即止"},
        {"name": "温和版", "kicker": "会员专享", "title": "给你留了一份专属优惠", "subtitle": "老客回馈 · 全场 8 折",
         "date": "10 月 20 日 - 11 月 11 日", "location": "全国门店 & 小程序商城",
         "content": "谢谢你一直都在。\n这张专属券，请收好。", "footerNote": "最终解释权归本店所有"},
    ],
    "seckill": [
        {"name": "狂欢版", "kicker": "限时秒杀", "title": "10 点开抢，手慢无", "subtitle": "整点秒杀 · 低至 9.9",
         "date": "10 月 20 日 10:00", "location": "直播间 & 小程序",
         "content": "每天 4 个整点，每场 30 件。\n定好闹钟，拼手速的时候到了。", "footerNote": "秒杀商品不支持退换"},
        {"name": "正式版", "kicker": "FLASH SALE", "title": "年度大促 全场狂欢", "subtitle": "跨店满减 · 上不封顶",
         "date": "10 月 20 日 20:00 - 10 月 21 日 24:00", "location": "官方商城",
         "content": "年度最低价，错过再等一年。", "footerNote": "优惠可与店铺券叠加"},
    ],
    "recruit": [
        {"name": "真诚版", "kicker": "诚聘英才", "title": "我们在找一起做事的人", "subtitle": "不画饼，薪资写死在那",
         "date": "长期有效", "location": "深圳南山 · 科技园",
         "content": "团队 30 人，方向明确，老板不烦人。\n五险一金、双休、下午茶，一个都不少。", "footerNote": "简历砸过来：hr@example.com"},
        {"name": "正式版", "kicker": "JOIN US", "title": "2027 届校园招聘正式启动", "subtitle": "技术 / 产品 / 运营 三大方向",
         "date": "2026 年 10 月 - 12 月", "location": "全国 6 所高校 · 巡回宣讲",
         "content": "加入我们，与优秀的同伴一起做有挑战的事。", "footerNote": "网申通道已开启"},
    ],
    "course": [
        {"name": "实用版", "kicker": "课程报名", "title": "这门课，学完就能用", "subtitle": "零基础入门 · 12 节课",
         "date": "11 月 2 日开课", "location": "线上直播 + 回放",
         "content": "不讲大道理，只教能上手的东西。\n作业有人批，问题不过夜。", "footerNote": "早鸟价截止 10 月 31 日"},
        {"name": "正式版", "kicker": "培训招生", "title": "项目管理实战训练营", "subtitle": "系统提升 · 案例驱动",
         "date": "2026 年 11 月 2 日 - 12 月 28 日", "location": "市中心教室 & 线上同步",
         "content": "系统讲授项目管理方法论，配套真实案例演练。", "footerNote": "限额 40 人，报满即止"},
    ],
    "travel": [
        {"name": "诗意版", "kicker": "诗和远方", "title": "去有风的地方", "subtitle": "滇西北 7 日慢游",
         "date": "11 月 15 日出发", "location": "大理集合 · 丽江解散",
         "content": "洱海骑行、雪山日落、古城夜话。\n不赶路，只感受。", "footerNote": "小团出行，每团不超 12 人"},
        {"name": "正式版", "kicker": "旅行邀约", "title": "××景区金秋推介会", "subtitle": "全域旅游 · 优惠政策发布",
         "date": "2026 年 11 月 15 日", "location": "景区游客中心",
         "content": "诚邀您共赏金秋盛景，现场发布年度优惠政策。", "footerNote": "凭邀请函享门票半价"},
    ],
    "food": [
        {"name": "烟火版", "kicker": "美食地图", "title": "这家店，值得你专程去", "subtitle": "本帮菜 · 三十年老手艺",
         "date": "每日 11:00 - 21:00", "location": "老街 56 号（近地铁口）",
         "content": "招牌红烧肉，每天限量 30 份。\n饭点常排队，建议提前到。", "footerNote": "订座电话：0571-XXXXXXXX"},
        {"name": "正式版", "kicker": "品鉴邀请", "title": "××餐厅品鉴晚宴", "subtitle": "主厨定制 · 八道式",
         "date": "2026 年 11 月 8 日 19:00", "location": "××餐厅 · 二层包场",
         "content": "诚邀您出席主厨定制晚宴，共品时令风味。", "footerNote": "凭邀请函入场"},
    ],
    "expo": [
        {"name": "通用版", "kicker": "展会邀请", "title": "这场展会，别错过", "subtitle": "2026 智能制造博览会",
         "date": "11 月 12 日 - 15 日", "location": "国际博览中心 A1-A4 馆",
         "content": "300+ 展商、50 场论坛。\n凭本函到场，免登记直接入场。", "footerNote": "展位号：A1-108"},
    ],
    "meeting": [
        {"name": "通用版", "kicker": "会议邀请", "title": "诚邀出席年度战略会", "subtitle": "聚焦增长 · 共话未来",
         "date": "2026 年 12 月 5 日 09:00", "location": "××大厦 28 层会议室",
         "content": "全天闭门研讨，含午宴。\n请提前预留时间。", "footerNote": "请于 11 月 30 日前回复出席"},
    ],
    "anniversary": [
        {"name": "通用版", "kicker": "周年同庆", "title": "十年了，谢谢你还在", "subtitle": "××品牌十周年庆典",
         "date": "12 月 12 日 18:00", "location": "滨江大饭店 · 宴会厅",
         "content": "十年风雨，一路有你们。\n当晚全场大奖，只为老朋友们准备。", "footerNote": "老客户专属席位"},
    ],
    "summit": [
        {"name": "通用版", "kicker": "峰会邀请", "title": "行业大咖都来了", "subtitle": "2026 数字营销峰会",
         "date": "11 月 28 日 09:00-17:30", "location": "国际会议中心 · 主会场",
         "content": "20 位实战派嘉宾，一下午的干货。\n早鸟票剩最后 50 张。", "footerNote": "凭报名二维码签到"},
    ],
    "franchise": [
        {"name": "通用版", "kicker": "招商加盟", "title": "找个靠谱的品牌一起干", "subtitle": "××品牌 2027 招商季",
         "date": "11 月 20 日 14:00", "location": "总部招商中心",
         "content": "不说暴富神话，只算实在账。\n首店扶持政策现场公布。", "footerNote": "席位有限，需提前报名"},
    ],
    "nonprofit": [
        {"name": "通用版", "kicker": "公益同行", "title": "一起做件小事", "subtitle": "山区儿童暖冬计划",
         "date": "12 月 1 日 - 12 月 20 日", "location": "线上 + 线下联动",
         "content": "一件冬衣、一本书，都是暖的。\n捐赠去向全程公示。", "footerNote": "感谢每一份善意"},
    ],
    "parent": [
        {"name": "通用版", "kicker": "家长会通知", "title": "明天下午，教室里见", "subtitle": "××班期中家长会",
         "date": "11 月 14 日 15:30", "location": "实验中学 3 楼 302",
         "content": "聊聊孩子这半年的进步和小问题。\n大概一小时，不拖堂。", "footerNote": "请提前 10 分钟签到"},
    ],
    "housewarming": [
        {"name": "通用版", "kicker": "乔迁之喜", "title": "新家落成，来暖房", "subtitle": "乔迁宴 · 家常便饭",
         "date": "11 月 22 日 11:30", "location": "翡翠湾 12 栋 1601",
         "content": "房子不大，酒管够。\n带上嘴和胃口来就行。", "footerNote": "地铁 2 号线直达"},
    ],
    "reunion": [
        {"name": "通用版", "kicker": "同学会", "title": "十五年，聚一次", "subtitle": "2006 级同学会",
         "date": "12 月 20 日 18:00", "location": "老校区南门 · 川菜馆",
         "content": "还是那家店，还是那拨人。\nAA 制，不许装老板。", "footerNote": "来不了的自觉发红包"},
    ],
    "baby100": [
        {"name": "通用版", "kicker": "百日宴", "title": "小公主百日啦", "subtitle": "宝宝百日宴 · 敬备喜宴",
         "date": "11 月 30 日 12:00", "location": "××酒店 · 二楼宴会厅",
         "content": "宝宝会笑会翻身了，\n带来给你看看。", "footerNote": "拒绝攀比，礼轻人意重"},
    ],
    "greeting": [
        {"name": "通用版", "kicker": "祝福", "title": "中秋快乐", "subtitle": "月圆人团圆",
         "date": "农历八月十五", "location": "",
         "content": "月光所照，皆是故乡。\n愿你抬头见月，低头有家。", "footerNote": "遥祝安康"},
    ],
    "album": [
        {"name": "通用版", "kicker": "时光相册", "title": "我们的这四年", "subtitle": "2022 - 2026 · 毕业纪念",
         "date": "2026 年 6 月", "location": "",
         "content": "军训、晚自习、宿舍夜聊……\n都在这里了。\n翻到底，有彩蛋。", "footerNote": "常联系，别客气"},
    ],
    "daily": [
        {"name": "通用版", "kicker": "今日语录", "title": "慢慢来，比较快", "subtitle": "10 月 18 日 · 宜微笑",
         "date": "每天 08:00", "location": "",
         "content": "你只管努力，剩下的交给时间。\n早安。", "footerNote": "扫码关注每日更新"},
    ],
    "company": [
        {"name": "通用版", "kicker": "关于我们", "title": "把复杂的事做简单", "subtitle": "××科技 · 成立于 2016",
         "date": "", "location": "深圳 · 北京 · 上海",
         "content": "我们是一家做××的公司，\n服务过 500+ 客户。\n不吹牛，案例说话。", "footerNote": "官网：www.example.com"},
    ],
    "brochure": [
        {"name": "通用版", "kicker": "企业宣传", "title": "十年磨一剑", "subtitle": "××集团品牌手册",
         "date": "", "location": "",
         "content": "从 3 人团队到 300 人，\n我们只做一件事：把产品做好。", "footerNote": "扫码查看完整版手册"},
    ],
    "brandlaunch": [
        {"name": "通用版", "kicker": "品牌发布", "title": "新名字，老朋友", "subtitle": "××品牌 2.0 焕新发布",
         "date": "11 月 6 日 14:00", "location": "798 艺术区 · 发布厅",
         "content": "换了张更年轻的皮，\n内核还是那个认真做产品的我们。", "footerNote": "现场有首发体验"},
    ],
    "productlaunch": [
        {"name": "通用版", "kicker": "新品发布", "title": "这一次，更进一步", "subtitle": "×× Pro 系列全球首发",
         "date": "11 月 11 日 19:30", "location": "线上发布会",
         "content": "等了 400 天。\n更快、更轻、更耐用。\n今晚 8 点，直播间见。", "footerNote": "首发用户享 3 年质保"},
    ],
    "microsite": [
        {"name": "通用版", "kicker": "官方网站", "title": "欢迎来看看", "subtitle": "××品牌官方网站",
         "date": "", "location": "",
         "content": "产品、案例、联系方式，\n一页看全。\n有合作意向，随时留言。", "footerNote": "本页为官方唯一入口"},
    ],
    "ecom": [
        {"name": "通用版", "kicker": "好物推荐", "title": "这 5 件，秋天必备", "subtitle": "编辑部亲测 · 闭眼入",
         "date": "10 月 18 日 - 10 月 25 日", "location": "视频号小店",
         "content": "都是从自家仓库发的货，\n不好用你回来骂我。", "footerNote": "7 天无理由退换"},
    ],
    "retail": [
        {"name": "通用版", "kicker": "超级购物节", "title": "周末来逛就对了", "subtitle": "全场满 100 减 20",
         "date": "10 月 24 日 - 10 月 25 日", "location": "××超市 全门店",
         "content": "生鲜、日用品、换季新装都参加。\n会员再叠 95 折。", "footerNote": "部分特价商品除外"},
    ],
    "campus": [
        {"name": "通用版", "kicker": "校招启动", "title": "第一份工作，值得挑好的", "subtitle": "2027 届校招 · 6 城巡回",
         "date": "10 月 25 日起", "location": "××大学 宣讲厅",
         "content": "导师一对一带，\n不打卡内卷，只看成长。", "footerNote": "现场投递，当天初面"},
    ],
    "resume": [
        {"name": "通用版", "kicker": "个人简介", "title": "你好，我是小林", "subtitle": "产品经理 · 5 年经验",
         "date": "", "location": "现居上海",
         "content": "做过 3 款百万级用户产品，\n擅长把模糊需求变清晰。\n正在寻找新机会。", "footerNote": "微信：linlinlin"},
    ],
    "enroll": [
        {"name": "通用版", "kicker": "招生啦", "title": "给孩子一个不一样的学期", "subtitle": "××学校 2027 春季招生",
         "date": "12 月 1 日 - 1 月 15 日", "location": "本校招生办",
         "content": "小班制、双班主任、每天两节户外课。\n欢迎预约参观。", "footerNote": "学位有限，先到先得"},
    ],
    "camp": [
        {"name": "通用版", "kicker": "营地招募", "title": "这个冬天，去雪地里撒欢", "subtitle": "6 天 5 夜 · 滑雪冬令营",
         "date": "2027 年 1 月 25 日 - 1 月 30 日", "location": "崇礼滑雪场",
         "content": "滑雪课、篝火晚会、自制火锅。\n手机统一保管，玩就玩痛快。", "footerNote": "适合 8-14 岁"},
    ],
    "finance": [
        {"name": "通用版", "kicker": "理财课堂", "title": "钱放着，不如让它上班", "subtitle": "零基础理财 12 讲",
         "date": "11 月 1 日起每周三", "location": "线上直播",
         "content": "不荐股、不承诺收益，\n只讲能听懂的逻辑。", "footerNote": "投资有风险，入市需谨慎"},
    ],
    "report": [
        {"name": "通用版", "kicker": "业绩报告", "title": "提前 45 天完成全年目标", "subtitle": "2026 前三季度经营报告",
         "date": "2026 年 10 月", "location": "",
         "content": "营收同比增长 63%，\n新签客户 217 家。\n感谢每一位并肩的伙伴。", "footerNote": "详细报告见附件"},
    ],
    "survey": [
        {"name": "通用版", "kicker": "有奖调研", "title": "3 分钟，帮我们个忙", "subtitle": "用户体验改进调研",
         "date": "10 月 18 日 - 10 月 31 日", "location": "线上问卷",
         "content": "填完抽 50 元购物卡，\n中奖率 100%。", "footerNote": "信息严格保密"},
    ],
    "health": [
        {"name": "通用版", "kicker": "健康科普", "title": "久坐的人，做这 3 个动作", "subtitle": "颈腰放松指南",
         "date": "每天 21:00", "location": "",
         "content": "不用器械，在家就能做。\n坚持两周，身体会感谢你。", "footerNote": "仅供参考，不构成医疗建议"},
    ],
    "medical": [
        {"name": "通用版", "kicker": "学术会议", "title": "干货满满的学术周末", "subtitle": "第七届××学术年会",
         "date": "11 月 21 日 - 22 日", "location": "××医院学术报告厅",
         "content": "30 个专题报告，继续教育学分 6 分。\n欢迎同行参会。", "footerNote": "免注册费，需提前报名"},
    ],
    "realestate": [
        {"name": "通用版", "kicker": "臻品楼盘", "title": "把家安在公园里", "subtitle": "××府 · 实景现房",
         "date": "10 月 20 日开盘", "location": "城东新区 · 湖畔路",
         "content": "地铁口 300 米，学区已定。\n现房销售，即买即住。", "footerNote": "认筹享 2 万抵 5 万"},
    ],
    "auto": [
        {"name": "通用版", "kicker": "新车到店", "title": "这台车，有点东西", "subtitle": "×× 2027 款 · 实车到店",
         "date": "10 月 25 日起", "location": "××4S 店",
         "content": "试驾有礼，订车抽盲盒。\n本周六下午茶已备好。", "footerNote": "预约试驾请留言"},
    ],
    "beauty": [
        {"name": "通用版", "kicker": "焕新之旅", "title": "换季了，脸也该换了", "subtitle": "秋季护肤限定套餐",
         "date": "10 月 18 日 - 11 月 18 日", "location": "××美容 · 全门店",
         "content": "到店免费肌肤检测，\n套餐直降 30%。", "footerNote": "每人限购一套"},
    ],
    "digital": [
        {"name": "通用版", "kicker": "数码新品", "title": "以旧换新，正当时", "subtitle": "家电补贴 10% + 旧机抵扣",
         "date": "10 月 20 日 - 11 月 11 日", "location": "线下门店 & 京东/天猫",
         "content": "旧机先估价，满意再换新。\n补贴名额每日刷新。", "footerNote": "每人每类限享一次"},
    ],
    "pet": [
        {"name": "通用版", "kicker": "毛孩子之家", "title": "带毛孩子来赴宴", "subtitle": "××宠物店周年趴",
         "date": "11 月 2 日 14:00", "location": "××宠物生活馆",
         "content": "免费体检、零食自助、萌宠合影。\n请系好牵引绳。", "footerNote": "欢迎晒图 @ 我们"},
    ],
    "inkcn": [
        {"name": "通用版", "kicker": "东方美学", "title": "一盏茶，见山水", "subtitle": "××茶文化雅集",
         "date": "11 月 9 日 14:00", "location": "古镇 · 听雨茶舍",
         "content": "茶艺、古琴、香道，\n半日清闲。\n着装无要求，心来就好。", "footerNote": "席位 20 个，报名从速"},
    ],
    "vote": [
        {"name": "通用版", "kicker": "投票评选", "title": "你的一票，很重要", "subtitle": "2026 年度优秀员工评选",
         "date": "10 月 20 日 - 10 月 27 日", "location": "线上投票",
         "content": "每个账号每天可投 1 票。\n结果 10 月 28 日公示。", "footerNote": "严禁刷票，违者取消资格"},
    ],
    "contest": [
        {"name": "通用版", "kicker": "大赛报名", "title": "舞台搭好了，该你上了", "subtitle": "第六届青年歌手大赛",
         "date": "11 月 1 日 - 11 月 30 日", "location": "市文化馆",
         "content": "不设门槛，敢唱就行。\n冠军奖金 10000 元。", "footerNote": "报名截止 10 月 30 日"},
    ],
    "lotterycat": [
        {"name": "通用版", "kicker": "幸运抽奖", "title": "手气这东西，玄得很", "subtitle": "下单即抽 · 100% 中奖",
         "date": "10 月 18 日 - 10 月 31 日", "location": "小程序活动页",
         "content": "一等奖最新手机，\n最差也有优惠券。\n每天 3 次机会。", "footerNote": "奖品于活动结束后 7 日内发放"},
    ],
    "game": [
        {"name": "通用版", "kicker": "玩个游戏", "title": "来局轻松的", "subtitle": "答题闯关 · 赢限量周边",
         "date": "长期开放", "location": "线上 H5",
         "content": "5 道题，2 分钟，\n满分直接兑奖。", "footerNote": "每个账号限领一次"},
    ],
}
