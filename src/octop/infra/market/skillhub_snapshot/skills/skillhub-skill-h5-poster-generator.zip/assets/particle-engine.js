/* =====================================================================
 * H5 Poster Particle Engine — 零依赖、可内联、模式丰富
 * 用法 1（自动）：<canvas data-particles="flow" data-colors="#fff,#0af"></canvas>
 * 用法 2（手动）：H5Particles.createParticles(canvasEl, {preset:'fireworks'})
 *
 * 背景模式（mode）：
 *   flow 粒子流 / constellation 连线 / snow 飘雪 / burst 爆发 / spark 火花
 *   starfield 星空 / fireworks 烟花 / petals 花瓣 / bubbles 气泡
 *   bokeh 光斑 / nebula 星云 / rain 雨丝 / matrix 代码雨
 *
 * 特性：DPR 适配、resize 自适应、prefers-reduced-motion 降级、
 *       指针交互（flow/constellation 排斥；点击任意模式触发星爆）、
 *       拖尾（fireworks）、闪烁（starfield）、自旋（petals）。
 * ===================================================================== */
(function (global) {
  'use strict';

  function rand(min, max) { return Math.random() * (max - min) + min; }

  // 颜色 → rgba() 字符串（支持 #rrggbb 与已带透明度的 rgba）
  function rgba(c, a) {
    if (typeof c === 'string' && c.charAt(0) === '#') {
      var h = c.slice(1);
      if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
      var n = parseInt(h, 16);
      return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
    }
    return c;
  }

  var PRESETS = {
    flow:         { mode: 'flow',         shape: 'dot',  count: 90,  colors: ['#ffffff', '#9fd3ff', '#5ea8ff'], speed: 0.6,  size: [1, 3],    dir: [1, 0.12] },
    constellation:{ mode: 'constellation',shape: 'dot',  count: 70,  colors: ['#ffffff', '#7fd1ff'],           speed: 0.25, size: [1, 2.2],  link: true, linkDist: 130, linkColor: 'rgba(255,255,255,0.18)' },
    snow:         { mode: 'snow',         shape: 'dot',  count: 80,  colors: ['#ffffff', '#e8f4ff'],           speed: 0.5,  size: [1.5, 4],  drift: 0.6 },
    burst:        { mode: 'burst',        shape: 'dot',  count: 120, colors: ['#ffd86b', '#ff7eb3', '#7afcff'],speed: 1.4,  size: [1.5, 3.5],gravity: 0.012 },
    spark:        { mode: 'spark',        shape: 'dot',  count: 70,  colors: ['#ffb347', '#ff5e62', '#ffd86b'],speed: 1.1,  size: [1, 2.6],   gravity: -0.02 },
    starfield:    { mode: 'starfield',    shape: 'star', count: 160, colors: ['#ffffff', '#cfe8ff', '#fff3c4'], speed: 0.12, size: [0.5, 2.2], twinkle: true },
    fireworks:    { mode: 'fireworks',    shape: 'dot',  count: 150, colors: ['#ffd86b', '#ff7eb3', '#7afcff', '#9bff9b', '#ff9a9e'], speed: 2.2, size: [1.4, 3], gravity: 0.028, trail: true },
    petals:       { mode: 'petals',       shape: 'petal',count: 34,  colors: ['#ffd1e8', '#ffb3d9', '#ffc9c9', '#ffeede'], speed: 0.7, size: [6, 12], drift: 1.1, sway: 0.02 },
    bubbles:      { mode: 'bubbles',      shape: 'bubble',count: 28,  colors: ['#bfefff', '#d9f7ff', '#ffffff'], speed: 0.55, size: [4, 14], rise: true },
    bokeh:        { mode: 'bokeh',        shape: 'bokeh',count: 16,  colors: ['#ff9a9e', '#fad0c4', '#a18cd1', '#84fab0'], speed: 0.16, size: [30, 90] },
    nebula:       { mode: 'nebula',       shape: 'bokeh',count: 9,   colors: ['#5ea8ff', '#a18cd1', '#ff7eb3', '#18ffb2'], speed: 0.1, size: [90, 220] },
    rain:         { mode: 'rain',         shape: 'streak',count: 140, colors: ['rgba(174,194,224,0.55)', 'rgba(200,220,255,0.45)'], speed: 3, size: [1, 1.6], streak: 16 },
    matrix:       { mode: 'matrix',       shape: 'char', count: 0,   colors: ['#39ff14', '#7dffb0'], speed: 1.0, size: [13, 17], chars: 'アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789ABCDEFｱｲｳｴｵ' }
  };

  function createParticles(canvas, userCfg) {
    if (!canvas || !canvas.getContext) return null;
    var ctx = canvas.getContext('2d');
    var cfg = Object.assign({}, PRESETS.flow, userCfg || {});
    if (typeof cfg.preset === 'string' && PRESETS[cfg.preset]) {
      cfg = Object.assign({}, PRESETS[cfg.preset], userCfg);
      delete cfg.preset;
    }
    // matrix 用列数而非粒子数
    if (cfg.mode === 'matrix') cfg.cols = cfg.cols || Math.max(8, Math.ceil((canvas.clientWidth || global.innerWidth || 375) / 16));

    var dpr = Math.min(global.devicePixelRatio || 1, 2);
    var W = 0, H = 0, pointer = null, pdown = null;

    function resize() {
      var rect = canvas.getBoundingClientRect();
      W = rect.width || canvas.clientWidth || global.innerWidth;
      H = rect.height || canvas.clientHeight || global.innerHeight;
      canvas.width = Math.max(1, Math.floor(W * dpr));
      canvas.height = Math.max(1, Math.floor(H * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();

    var colors = cfg.colors || ['#ffffff'];
    var N = (cfg.mode === 'matrix')
      ? (cfg.cols || 20)
      : Math.max(8, Math.min(cfg.count || 80, Math.floor((W * H) / 8500)));
    var parts = [];

    function mkChar() { return cfg.chars ? cfg.chars[(Math.random() * cfg.chars.length) | 0] : '0'; }

    function make() {
      var p = {
        x: rand(0, W), y: rand(0, H),
        r: rand(cfg.size ? cfg.size[0] : 1, cfg.size ? cfg.size[1] : 3),
        c: colors[(Math.random() * colors.length) | 0],
        vx: 0, vy: 0, life: 1, maxLife: rand(0.6, 1),
        px: 0, py: 0, baseA: 1, rot: rand(0, Math.PI * 2), vr: rand(-0.02, 0.02),
        ch: mkChar(), tw: 1
      };
      switch (cfg.mode) {
        case 'flow': p.vx = cfg.speed * (cfg.dir ? cfg.dir[0] : 1) * rand(0.5, 1.4); p.vy = cfg.speed * (cfg.dir ? cfg.dir[1] : 0.1) * rand(-1, 1); break;
        case 'constellation': p.vx = rand(-1, 1) * cfg.speed; p.vy = rand(-1, 1) * cfg.speed; break;
        case 'snow': p.vx = rand(-1, 1) * (cfg.drift || 0.6); p.vy = cfg.speed * rand(0.5, 1.2); break;
        case 'burst': { var a = rand(0, Math.PI * 2), s = cfg.speed * rand(0.4, 1); p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s; p.maxLife = rand(0.5, 1); } break;
        case 'spark': p.x = rand(0, W); p.y = H + rand(0, H * 0.3); p.vx = rand(-0.4, 0.4); p.vy = -cfg.speed * rand(0.6, 1.4); p.maxLife = rand(0.7, 1.4); break;
        case 'starfield': p.vx = rand(-1, 1) * cfg.speed; p.vy = rand(-1, 1) * cfg.speed; p.twBase = rand(0.4, 1); break;
        case 'fireworks': launchFirework(p); break;
        case 'petals': p.vx = rand(-1, 1) * (cfg.drift || 1); p.vy = cfg.speed * rand(0.6, 1.1); break;
        case 'bubbles': p.x = rand(0, W); p.y = H + rand(0, H * 0.3); p.vx = rand(-0.3, 0.3); p.vy = -cfg.speed * rand(0.5, 1.2); p.baseA = rand(0.4, 0.8); break;
        case 'bokeh':
        case 'nebula': p.x = rand(0, W); p.y = rand(0, H); p.vx = rand(-1, 1) * cfg.speed; p.vy = rand(-1, 1) * cfg.speed; p.baseA = rand(0.35, 0.7); break;
        case 'rain': p.x = rand(0, W); p.y = rand(-H, H); p.vx = 0; p.vy = cfg.speed * rand(0.7, 1.3); p.streak = cfg.streak || 16; p.baseA = rand(0.3, 0.7); break;
        case 'matrix': p.x = (parts.length) * ((W) / N) + 8; p.y = rand(-H, 0); p.vy = cfg.speed * rand(0.7, 1.5); p.ch = mkChar(); p.baseA = 1; break;
        default: p.vx = rand(-1, 1) * cfg.speed; p.vy = rand(-1, 1) * cfg.speed;
      }
      p.px = p.x; p.py = p.y;
      return p;
    }

    function launchFirework(p) {
      var bx = rand(W * 0.15, W * 0.85), by = rand(H * 0.12, H * 0.5);
      var n = 1; // 单个粒子，靠 re-launch 持续
      p.x = bx; p.y = by; p.px = bx; p.py = by;
      var a = rand(0, Math.PI * 2), s = cfg.speed * rand(0.4, 1.1);
      p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s;
      p.maxLife = rand(0.5, 1.1); p.life = 1;
    }

    function seed() {
      parts.length = 0;
      for (var i = 0; i < N; i++) parts.push(make());
    }
    seed();

    var raf = 0, last = 0;
    var reduce = global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function onMove(e) { var t = e.touches ? e.touches[0] : e; pointer = { x: t.clientX, y: t.clientY }; }
    function onLeave() { pointer = null; }
    function onDown(e) { var t = e.touches ? e.touches[0] : e; pdown = { x: t.clientX, y: t.clientY }; setTimeout(function () { pdown = null; }, 60); }
    if (cfg.interactive) {
      global.addEventListener('pointermove', onMove, { passive: true });
      global.addEventListener('pointerleave', onLeave, { passive: true });
      global.addEventListener('pointerdown', onDown, { passive: true });
    }

    function drawShape(p) {
      switch (p.shape) {
        case 'star':
          ctx.globalAlpha = p.baseA * (p.tw || 1);
          ctx.fillStyle = p.c;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
          break;
        case 'petal':
          ctx.globalAlpha = p.baseA; ctx.fillStyle = p.c;
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot || 0);
          ctx.beginPath(); ctx.ellipse(0, 0, p.r, p.r * 0.5, 0, 0, Math.PI * 2); ctx.fill();
          ctx.restore();
          break;
        case 'bubble':
          ctx.globalAlpha = p.baseA * 0.55; ctx.strokeStyle = p.c; ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.stroke();
          ctx.globalAlpha = p.baseA * 0.35; ctx.fillStyle = p.c;
          ctx.beginPath(); ctx.arc(p.x - p.r * 0.3, p.y - p.r * 0.3, p.r * 0.3, 0, Math.PI * 2); ctx.fill();
          break;
        case 'bokeh': {
          var g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r);
          g.addColorStop(0, rgba(p.c, 0.5)); g.addColorStop(0.6, rgba(p.c, 0.18)); g.addColorStop(1, rgba(p.c, 0));
          ctx.globalAlpha = 1; ctx.fillStyle = g;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
          break;
        }
        case 'streak':
          ctx.globalAlpha = p.baseA; ctx.strokeStyle = p.c; ctx.lineWidth = p.r;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * (p.streak || 14), p.y - p.vy * (p.streak || 14)); ctx.stroke();
          break;
        case 'char':
          ctx.globalAlpha = p.baseA; ctx.fillStyle = p.c;
          ctx.font = (p.r * 1.1) + 'px monospace'; ctx.textBaseline = 'top';
          ctx.fillText(p.ch, p.x, p.y);
          break;
        default:
          ctx.globalAlpha = p.baseA; ctx.fillStyle = p.c;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
      }
    }

    function frame(t) {
      var dt = last ? Math.min(40, t - last) : 16; last = t;
      ctx.clearRect(0, 0, W, H);

      for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        p.px = p.x; p.py = p.y;

        // 指针交互：flow/constellation 排斥；点击触发局部星爆反馈
        if (cfg.interactive && pointer) {
          var dx = p.x - pointer.x, dy = p.y - pointer.y, d2 = dx * dx + dy * dy;
          if ((cfg.mode === 'flow' || cfg.mode === 'constellation') && d2 < 14000 && d2 > 1) {
            var f = (14000 - d2) / 14000 * 0.7; p.x += (dx / Math.sqrt(d2)) * f; p.y += (dy / Math.sqrt(d2)) * f;
          }
        }

        p.x += p.vx * (dt / 16);
        p.y += p.vy * (dt / 16);
        if (cfg.gravity) p.vy += cfg.gravity * (dt / 16);
        if (p.rot !== undefined && p.vr) p.rot += p.vr * (dt / 16);

        // 闪烁（starfield）
        if (cfg.twinkle && p.twBase !== undefined) p.tw = p.twBase * (0.55 + 0.45 * Math.sin((t / 600) + i));

        // 生命周期衰减
        if (cfg.mode === 'spark' || cfg.mode === 'burst') p.life -= 0.01 * (dt / 16) / p.maxLife;
        if (cfg.mode === 'fireworks') {
          p.life -= 0.012 * (dt / 16) / p.maxLife;
          if (p.life <= 0) launchFirework(p);
        }

        // 边界回收
        if (cfg.mode === 'flow') {
          if (p.x - p.r > W) { p.x = -p.r; p.y = rand(0, H); }
          if (p.y < -p.r) p.y = H + p.r; if (p.y > H + p.r) p.y = -p.r;
        } else if (cfg.mode === 'snow') {
          if (p.y - p.r > H) { p.y = -p.r; p.x = rand(0, W); }
          if (p.x < -p.r) p.x = W + p.r; if (p.x > W + p.r) p.x = -p.r;
        } else if (cfg.mode === 'petals') {
          p.x += Math.sin((t / 700) + i) * (cfg.sway || 0.02) * 4;
          if (p.y - p.r > H) { p.y = -p.r; p.x = rand(0, W); }
          if (p.x < -p.r) p.x = W + p.r; if (p.x > W + p.r) p.x = -p.r;
        } else if (cfg.mode === 'spark') {
          if (p.y < -p.r || p.life <= 0) { var s2 = make(); s2.y = H + rand(0, H * 0.3); s2.vy = -cfg.speed * rand(0.6, 1.4); s2.life = 1; parts[i] = s2; }
        } else if (cfg.mode === 'burst') {
          if (p.life <= 0) { var b = make(); var a2 = rand(0, Math.PI * 2), s3 = cfg.speed * rand(0.4, 1); b.x = W / 2; b.y = H / 2; b.vx = Math.cos(a2) * s3; b.vy = Math.sin(a2) * s3; b.life = 1; parts[i] = b; }
        } else if (cfg.mode === 'bubbles') {
          if (p.y + p.r < -2 || p.life <= 0) { var bb = make(); bb.y = H + rand(0, H * 0.3); bb.vy = -cfg.speed * rand(0.5, 1.2); parts[i] = bb; }
        } else if (cfg.mode === 'rain') {
          if (p.y - p.streak > H) { p.y = rand(-H, 0); p.x = rand(0, W); }
        } else if (cfg.mode === 'matrix') {
          if (p.y > H) { p.y = rand(-H, 0); p.ch = mkChar(); }
          if (Math.random() < 0.04) p.ch = mkChar();
        } else if (cfg.mode === 'bokeh' || cfg.mode === 'nebula') {
          if (p.x < -p.r) p.x = W + p.r; if (p.x > W + p.r) p.x = -p.r;
          if (p.y < -p.r) p.y = H + p.r; if (p.y > H + p.r) p.y = -p.r;
        } else {
          if (p.x < -p.r) p.x = W + p.r; if (p.x > W + p.r) p.x = -p.r;
          if (p.y < -p.r) p.y = H + p.r; if (p.y > H + p.r) p.y = -p.r;
        }

        // 拖尾（fireworks）
        if (cfg.trail && (cfg.mode === 'fireworks' || cfg.mode === 'burst')) {
          ctx.globalAlpha = p.baseA * Math.max(0, p.life) * 0.5;
          ctx.strokeStyle = p.c; ctx.lineWidth = p.r * 0.8;
          ctx.beginPath(); ctx.moveTo(p.px, p.py); ctx.lineTo(p.x, p.y); ctx.stroke();
        }

        var a = (cfg.mode === 'spark' || cfg.mode === 'burst' || cfg.mode === 'fireworks') ? Math.max(0, p.life) : 1;
        p.baseA = p.baseA || 1;
        drawShape({ x: p.x, y: p.y, r: p.r, c: p.c, shape: p.shape, baseA: a, rot: p.rot, tw: p.tw, ch: p.ch, streak: p.streak });
      }

      // 连线（constellation）
      if (cfg.link) {
        var ld = cfg.linkDist || 130;
        for (var m = 0; m < parts.length; m++) {
          for (var n = m + 1; n < parts.length; n++) {
            var a1 = parts[m], b1 = parts[n];
            var ddx = a1.x - b1.x, ddy = a1.y - b1.y, d = Math.sqrt(ddx * ddx + ddy * ddy);
            if (d < ld) {
              ctx.globalAlpha = (1 - d / ld) * 0.5;
              ctx.strokeStyle = cfg.linkColor || 'rgba(255,255,255,0.18)';
              ctx.lineWidth = 1;
              ctx.beginPath(); ctx.moveTo(a1.x, a1.y); ctx.lineTo(b1.x, b1.y); ctx.stroke();
            }
          }
        }
        ctx.globalAlpha = 1;
      }

      // 点击星爆反馈（任意模式）
      if (pdown) {
        ctx.globalAlpha = 0.9; ctx.fillStyle = '#fff';
        for (var k = 0; k < 8; k++) {
          var ang = (k / 8) * Math.PI * 2, rr = (Date.now() % 400) / 400 * 18;
          ctx.beginPath(); ctx.arc(pdown.x + Math.cos(ang) * rr, pdown.y + Math.sin(ang) * rr, 1.6, 0, Math.PI * 2); ctx.fill();
        }
        ctx.globalAlpha = 1;
      }

      raf = global.requestAnimationFrame(frame);
    }

    if (reduce) {
      for (var k2 = 0; k2 < parts.length; k2++) {
        var pp = parts[k2];
        ctx.globalAlpha = 0.6; ctx.fillStyle = pp.c;
        ctx.beginPath(); ctx.arc(pp.x, pp.y, pp.r, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    } else {
      raf = global.requestAnimationFrame(frame);
    }

    global.addEventListener('resize', resize);
    var stop = function () {
      global.cancelAnimationFrame(raf);
      global.removeEventListener('resize', resize);
      if (cfg.interactive) { global.removeEventListener('pointermove', onMove); global.removeEventListener('pointerleave', onLeave); global.removeEventListener('pointerdown', onDown); }
    };
    return { stop: stop, reseed: seed, setColors: function (cs) { colors = cs; seed(); } };
  }

  function autoInit() {
    var els = document.querySelectorAll('canvas[data-particles]');
    Array.prototype.forEach.call(els, function (cv) {
      var preset = cv.getAttribute('data-particles');
      var colors = cv.getAttribute('data-colors');
      var speed = parseFloat(cv.getAttribute('data-speed'));
      var cfg = { preset: preset };
      if (colors) cfg.colors = colors.split(',');
      if (!isNaN(speed)) cfg.speed = speed;
      if (cv.getAttribute('data-interactive') === '1') cfg.interactive = true;
      createParticles(cv, cfg);
    });
  }

  var API = { createParticles: createParticles, presets: PRESETS, autoInit: autoInit };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  global.H5Particles = API;
  if (typeof document !== 'undefined') {
    if (document.readyState !== 'loading') autoInit();
    else document.addEventListener('DOMContentLoaded', autoInit);
  }
})(typeof window !== 'undefined' ? window : this);
