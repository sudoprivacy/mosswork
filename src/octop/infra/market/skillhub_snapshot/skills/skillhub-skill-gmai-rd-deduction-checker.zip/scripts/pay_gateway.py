#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GMAI-SkillPay批量运营大师 —— SkillPay 支付服务接入客户端（X402 / 微信 Agent Pay）

本文件是本技能「支付服务」的可运行实现，直连云端支付网关，完成三段真实链路：

    probe     首次请求 → 网关返回 HTTP 402 + WeixinPay-Required(支付码) + X-Out-Trade-No(订单号)
    pay       把 WeixinPay-Required 作为 paymentCode 交给 Agent 的 weixinpay_pay 工具向用户申请授权
    complete  用户支付后，用完全相同的请求体 + Header X-Out-Trade-No 重试 → 网关查单确认 → HTTP 200 放行

本脚本只做编排，不接触任何支付密钥，也不自行发起微信支付。

用法：
    python scripts/pay_gateway.py health
    python scripts/pay_gateway.py probe    --payload '{"topic":"示例需求"}'
    python scripts/pay_gateway.py complete --out-trade-no <X-Out-Trade-No> --payload '{"topic":"示例需求"}'
    python scripts/pay_gateway.py status   --out-trade-no <X-Out-Trade-No>

环境变量（不填则用下面的生产默认值）：
    SKILLPAY_GATEWAY   网关地址
    SKILLPAY_API_KEY   网关调用密钥
    SKILLPAY_SLUG      技能 slug
"""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request

# 强制直连：支付链路不走系统代理（代理环境会导致网关请求挂起）
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))

GATEWAY = os.environ.get("SKILLPAY_GATEWAY", "https://viralclip-313815-12-1485772243.sh.run.tcloudbase.com").rstrip("/")
API_KEY = os.environ.get("SKILLPAY_API_KEY", "viralclip-public-demo-key")
SLUG = os.environ.get("SKILLPAY_SLUG", "gmai-rd-deduction-checker")
PRICE_FEN = 4990
STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".skillpay_state.json")

PAY_HEADERS = ("weixinpay-required", "x-out-trade-no", "payment-needed")


def call(method, path, body=None, extra=None):
    headers = {"Accept": "application/json", "X-API-Key": API_KEY}
    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    if extra:
        headers.update(extra)
    req = urllib.request.Request(GATEWAY + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status, dict(resp.headers), resp.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read().decode("utf-8", "ignore")
    except Exception as e:  # 网络不可达等
        return -1, {}, json.dumps({"error": str(e)}, ensure_ascii=False)


def pick(headers):
    return {k: v for k, v in headers.items() if k.lower() in PAY_HEADERS}


def save_state(d):
    try:
        with open(STATE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def cmd_health(_a):
    st, hd, tx = call("GET", "/healthz")
    print("[GET /healthz] ->", st, tx)
    return 0 if st == 200 else 1


def cmd_probe(a):
    body = {"skill_slug": SLUG, "client_ref": "skillpay-client",
            "payload": json.loads(a.payload) if a.payload else {}}
    st, hd, tx = call("POST", "/api/v1/gateway/orders", body)
    info = pick(hd)
    out_trade_no = info.get("X-Out-Trade-No") or info.get("x-out-trade-no", "")
    if st == 402:
        print("[POST /api/v1/gateway/orders] -> 402 需要支付")
        print("  WeixinPay-Required:", info.get("WeixinPay-Required", ""))
        print("  X-Out-Trade-No   :", out_trade_no)
        print("  账单:", tx)
        save_state({"skill_slug": SLUG, "out_trade_no": out_trade_no,
                    "payload": body["payload"], "price_fen": PRICE_FEN})
        print("\n下一步：把上面的 WeixinPay-Required 作为 paymentCode 交给 weixinpay_pay，"
              "用户支付后执行：")
        print("  python scripts/pay_gateway.py complete --out-trade-no %s --payload '%s'"
              % (out_trade_no, json.dumps(body["payload"], ensure_ascii=False)))
        return 2
    if st == 200:
        print("[POST /api/v1/gateway/orders] -> 200 已支付/已放行，可直接履约")
        print(tx)
        return 0
    print("[POST /api/v1/gateway/orders] ->", st, tx)
    return 1


def cmd_complete(a):
    payload = json.loads(a.payload) if a.payload else {}
    if not payload and os.path.isfile(STATE):
        try:
            payload = json.load(open(STATE, encoding="utf-8")).get("payload", {})
        except Exception:
            payload = {}
    body = {"skill_slug": SLUG, "payload": payload}
    st, hd, tx = call("POST", "/api/v1/gateway/orders", body,
                      {"X-Out-Trade-No": a.out_trade_no})
    print("[POST /api/v1/gateway/orders  (X-Out-Trade-No: %s)] -> %s" % (a.out_trade_no, st))
    print(" ", tx[:500])
    if st == 200:
        print("\n支付已确认，订单履约放行。可用以下结果继续本技能的正式交付流程：")
        return 0
    print("\n支付尚未完成（或订单已过期）。同一订单重试不会重复扣费；"
          "若返回订单过期，请重新执行 probe 下单。")
    return 2


def cmd_status(a):
    st, hd, tx = call("GET", "/api/v1/gateway/orders/" + a.out_trade_no)
    print("[GET /api/v1/gateway/orders/%s] -> %s" % (a.out_trade_no, st))
    print(" ", tx[:500])
    return 0 if st == 200 else 1


def main():
    p = argparse.ArgumentParser(description="SkillPay 支付服务客户端（X402）")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("health", help="网关健康检查").set_defaults(fn=cmd_health)
    sp = sub.add_parser("probe", help="首次请求，取 402 账单")
    sp.add_argument("--payload", default="", help="业务参数 JSON 字符串")
    sp.set_defaults(fn=cmd_probe)
    sc = sub.add_parser("complete", help="支付后带订单号重试查单放行")
    sc.add_argument("--out-trade-no", required=True)
    sc.add_argument("--payload", default="")
    sc.set_defaults(fn=cmd_complete)
    ss = sub.add_parser("status", help="免费查单")
    ss.add_argument("--out-trade-no", required=True)
    ss.set_defaults(fn=cmd_status)
    a = p.parse_args()
    if not getattr(a, "fn", None):
        p.print_help()
        return 1
    print("技能: %s   单价: ¥%.2f/次   网关: %s" % (SLUG, PRICE_FEN / 100.0, GATEWAY))
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
