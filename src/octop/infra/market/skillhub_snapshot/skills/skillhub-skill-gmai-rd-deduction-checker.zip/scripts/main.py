# -*- coding: utf-8 -*-
"""研发加计扣除核查（gmai-rd-deduction-checker）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
建议输入信息：研发项目清单；研发费用明细账；辅助账样例
"""
import json, os, sys, time

SLUG = "gmai-rd-deduction-checker"
TITLE = "研发加计扣除核查"
PRICE_FEN = 4990

# 检查项（标题, 关键词, 落地建议）—— 逐项对本技能领域定制
CHECKS = [
 [
  "项目立项",
  [
   "立项",
   "研发项目",
   "RD"
  ],
  "核对研发项目立项资料完整性"
 ],
 [
  "费用归集",
  [
   "归集",
   "人员人工",
   "直接投入"
  ],
  "检查五项费用归集口径"
 ],
 [
  "辅助账",
  [
   "辅助账",
   "台账"
  ],
  "核验研发支出辅助账设置"
 ],
 [
  "负面清单",
  [
   "负面清单",
   "烟草",
   "住宿"
  ],
  "排查负面清单行业适用性"
 ],
 [
  "留存备查",
  [
   "备查",
   "资料"
  ],
  "输出留存备查资料清单"
 ]
]

DELIVERABLES = ["加计扣除合规核查表", "费用归集口径说明", "备查资料清单"]


def load_input(argv):
    path = argv[1] if len(argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f), path


def analyze(data):
    text = json.dumps(data, ensure_ascii=False)
    fields = [v for v in data.values() if str(v).strip()]
    rich = len(fields) >= 2 or sum(len(str(v)) for v in fields) >= 28
    rows = []
    full = 0
    for item, kws, advice in CHECKS:
        if any(k in text for k in kws):
            rows.append((item, 2, advice))
            full += 1
        elif rich:
            rows.append((item, 1, advice))
        else:
            rows.append((item, 0, advice))
    return rows, full, rich


def build_report(data, rows, full, rich, src):
    L = []
    L.append("# %s 分析报告" % TITLE)
    L.append("")
    L.append("- 技能：%s（`%s`）" % (TITLE, SLUG))
    L.append("- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0))
    L.append("- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    L.append("- 输入来源：%s" % os.path.basename(src))
    L.append("")
    L.append("## 输入概览")
    L.append("")
    for k, v in data.items():
        v = str(v)
        L.append("- **%s**：%s" % (k, v[:160] + ("…" if len(v) > 160 else "")))
    L.append("")
    L.append("## 逐项分析")
    L.append("")
    for i, (item, lv, advice) in enumerate(rows, 1):
        if lv == 2:
            L.append("%d. **%s**：输入中已包含直接相关信息，落地路径——%s" % (i, item, advice))
        elif lv == 1:
            L.append("%d. **%s**：现有材料可支撑基础分析（该项的直接关键词材料偏薄，结论深度依补充材料而定）；路径——%s" % (i, item, advice))
        else:
            L.append("%d. **%s**：输入信息暂缺，需补充材料后才能给出可靠结论；建议：%s" % (i, item, advice))
    partial = sum(1 for r in rows if r[1] == 1)
    score = int(round(100.0 * (full + 0.5 * partial) / len(CHECKS)))
    L.append("")
    L.append("## 综合评估")
    L.append("")
    L.append("- 信息充分度：**%d/100**（直接命中 %d 项 / 材料可支撑 %d 项 / 共 %d 项）" % (score, full, full + partial, len(CHECKS)))
    if score >= 80:
        L.append("- 判定：输入充分，可按上述落地路径直接执行。")
    elif score >= 50:
        L.append("- 判定：输入基本可用，优先补齐薄弱项信息后执行效果更佳。")
    else:
        L.append("- 判定：输入偏薄，请按「待补充信息」整理材料后重新分析。")
    L.append("")
    L.append("## 待补充信息")
    L.append("")
    missed = [r[0] for r in rows if r[1] == 0]
    weak = [r[0] for r in rows if r[1] == 1]
    if missed or weak:
        for m in missed:
            L.append("- 「%s」相关的原始材料或说明（必需）" % m)
        for m in weak:
            L.append("- 「%s」相关的补充材料（建议，可提升结论深度）" % m)
    else:
        L.append("- 无：输入已覆盖全部检查项。")
    L.append("")
    L.append("## 交付物")
    L.append("")
    for d in DELIVERABLES:
        L.append("- %s" % d)
    L.append("")
    L.append("> 本报告由 `%s` 基于规则分析生成，供决策参考，不构成任何绝对保证。" % SLUG)
    return "\n".join(L) + "\n"


def main():
    data, src = load_input(sys.argv)
    rows, full, rich = analyze(data)
    md = build_report(data, rows, full, rich, src)
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "report_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
