# -*- coding: utf-8 -*-
"""
gen_report.py — export-metric-analysis 报表渲染入口（HTML 脚本化生成）

用法:
    python gen_report.py <data.json> <output.html> [--template <template.html>]

行为:
    1. 读取 data.json, 做 schema 校验与业务话术校验
    2. 注入渲染引擎模板(默认与本脚本同目录的 report_template.html)的 __REPORT_DATA__
    3. 写出成品 HTML, 校验无残留占位符

data.json 结构 (速查):
{
  "title": "报表标题(必填)",
  "subtitle": "工具栏副标题(可选)",
  "period": "统计周期, 如 2026年1月–9月(必填)",
  "time_axis": "时间口径, 如 按申报日期(必填)",
  "scope": "统计范围胶囊, 如 全公司 / 中基人和(必填)",
  "data_note": "页顶数据说明 banner, 业务语言(可选)",
  "kpis": [ {"label","value","unit","note","tone":default|warn|ok,"yoy","yoy_dir":up|down} x1..4 ],
  "sections": [
    {"type":"line","title","hint","chart_title","unit","this":[数值...],
     "last":[数值...]|null,"fc_from":预测起点下标|省略,"labels":[...],"start_month":1},
    {"type":"donut","title","chart_title","unit","data":[["名称",数值],...],
     "rows":[["列1","列2"],[...]]|省略(自动算占比表)},
    {"type":"hbar","title","chart_title","unit","cur":[["名称",数值],...],
     "last":[["名称",数值],...]|null},
    {"type":"table","title","columns":[...],"rows":[[...]],"行单元格支持 {"text","badge":hi|mid|lo|no|yes}"},
    {"type":"eval","conclusion","evidence","advice"}
  ],
  "foot": "页脚统计范围, 业务语言(必填)"
}
"""
import json
import os
import re
import sys

# 铁律 12: 客户报表禁止出现的技术词(大小写不敏感)
BANNED_TERMS = [
    'appliedFilters', 'UNSUPPORTED_SHAPE', 'truncated', 'overlapGroup',
    'overlap=true', 'additive', 'NO_MATCH', 'REJECTED', 'AUTH_INCOMPLETE',
    'withTotal', 'mergeOthers', 'metricId', 'metric_id', 'dim_value',
    'dataBusinessTerms', 'dataMetricCatalog', 'dataDimensionValues',
    'dataMetricQuery', 'mcp-gateway', 'MCP', '语义层', '注册表', '注册态',
    '上线路径', '场景代号', 'S1', 'S8',
]

SECTION_TYPES = ('line', 'donut', 'hbar', 'table', 'eval')


def fail(msg):
    print('ERROR: ' + msg)
    sys.exit(1)


def walk_strings(obj, path='$'):
    """递归产出 (路径, 字符串值)"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk_strings(v, path + '.' + str(k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk_strings(v, path + '[%d]' % i)
    elif isinstance(obj, str):
        yield path, obj


def check_banned_strings(data):
    """禁止词校验: 报出的位置方便定位"""
    hits = []
    for path, s in walk_strings(data):
        for t in BANNED_TERMS:
            if t.lower() in s.lower():
                hits.append('%s 含技术词 "%s" (客户报表禁止, 见铁律 12): %s' % (path, t, s[:60]))
    if hits:
        fail('话术校验未通过:\n  - ' + '\n  - '.join(hits))


def check_inject(data):
    for path, s in walk_strings(data):
        if '</script' in s.lower() or '<!--' in s:
            fail('%s 含非法标签片段, 会破坏页面结构: %s' % (path, s[:60]))


def num_list(v, path):
    if not isinstance(v, list) or len(v) == 0:
        fail('%s 必须是非空数值数组' % path)
    for x in v:
        if not isinstance(x, (int, float)) or x != x:
            fail('%s 含非数值/NaN: %r' % (path, x))


def pair_list(v, path):
    if not isinstance(v, list) or len(v) == 0:
        fail('%s 必须是非空 [["名称",数值],...] 数组' % path)
    for it in v:
        if (not isinstance(it, list) or len(it) < 2
                or not isinstance(it[0], str) or not it[0]
                or not isinstance(it[1], (int, float))):
            fail('%s 的项必须是 ["名称",数值], 收到: %r' % (path, it))


def validate(data):
    if not isinstance(data, dict):
        fail('data.json 顶层必须是对象')
    for k in ('title', 'period', 'time_axis', 'scope', 'kpis', 'sections', 'foot'):
        if k not in data:
            fail('缺少必填字段: %s' % k)
    for k in ('title', 'period', 'time_axis', 'scope'):
        if not isinstance(data[k], str) or not data[k].strip():
            fail('字段 %s 必须是非空字符串' % k)
    foot = data['foot']
    foot_lines = foot if isinstance(foot, list) else [foot]
    if (not isinstance(foot, (str, list)) or not foot_lines
            or not all(isinstance(x, str) and x.strip() for x in foot_lines)):
        fail('foot 必须是非空字符串或多行字符串数组(逐行业务语言, 见 §8 页脚模板)')
    # 抬头范围校验(2026-11-11 用户规范): foot 必含抬头范围行, 且只正向列出包含哪些抬头
    foot_text = '\n'.join(foot_lines)
    if '抬头' not in foot_text:
        fail('foot 必须含「抬头范围」独立行(正向列出本次包含的抬头, 见 §8), 当前 foot 未出现抬头关键词')
    scope_lines = [x for x in foot_lines if '抬头范围' in x] or [x for x in foot_lines if '抬头' in x]
    check_text = '\n'.join(scope_lines) + '\n' + str(data.get('scope') or '')
    for bad in ('公司口径', '不含中基天时', '含中基天时', '全部抬头口径'):
        if bad in check_text:
            fail('抬头范围标注只正向列出本次包含哪些抬头, 不得写「%s」等口径标签或排除式表述(见 §8); 页脚抬头范围行与顶部 scope 均须一致' % bad)

    kpis = data['kpis']
    if not isinstance(kpis, list) or not (1 <= len(kpis) <= 4):
        fail('kpis 必须是 1-4 张卡')
    for i, k in enumerate(kpis):
        p = '$.kpis[%d]' % i
        if not isinstance(k, dict) or not k.get('label'):
            fail('%s.label 必填' % p)
        if 'value' not in k or not isinstance(k['value'], (str, int, float)):
            fail('%s.value 必填(字符串或数值)' % p)
        if k.get('tone') not in (None, 'default', 'warn', 'ok'):
            fail('%s.tone 只能是 default/warn/ok' % p)
        if k.get('yoy_dir') not in (None, 'up', 'down'):
            fail('%s.yoy_dir 只能是 up(涨红)/down(跌绿)' % p)

    secs = data['sections']
    if not isinstance(secs, list) or not secs:
        fail('sections 必须是非空数组')
    has_eval = False
    for i, s in enumerate(secs):
        p = '$.sections[%d]' % i
        if not isinstance(s, dict) or s.get('type') not in SECTION_TYPES:
            fail('%s.type 必须是 %s 之一' % (p, '/'.join(SECTION_TYPES)))
        t = s['type']
        if t != 'eval' and not s.get('title'):
            fail('%s.title 必填(eval 段自带标题, 可省略)' % p)
        if t == 'line':
            num_list(s.get('this'), p + '.this')
            if s.get('last') is not None:
                num_list(s['last'], p + '.last')
                if len(s['last']) != len(s['this']):
                    fail('%s.last 与 this 等长(同比按位对比)' % p)
            f = s.get('fc_from')
            if f is not None and (not isinstance(f, int) or not (1 <= f < len(s['this']))):
                fail('%s.fc_from 须为 1..len(this)-1 的整数(预测起点下标)' % p)
        elif t == 'donut':
            pair_list(s.get('data'), p + '.data')
        elif t == 'hbar':
            pair_list(s.get('cur'), p + '.cur')
            if s.get('last') is not None:
                pair_list(s['last'], p + '.last')
                if len(s['last']) != len(s['cur']):
                    fail('%s.last 与 cur 等长(同比按位对比)' % p)
        elif t == 'table':
            cols = s.get('columns')
            if not isinstance(cols, list) or not cols:
                fail('%s.columns 必填' % p)
            rows = s.get('rows')
            if not isinstance(rows, list) or not rows:
                fail('%s.rows 必填' % p)
            for r in rows:
                if not isinstance(r, list) or len(r) != len(cols):
                    fail('%s.rows 行列数须与 columns 一致: %r' % (p, r))
                for c in r:
                    ok = isinstance(c, str) or c is None or (
                        isinstance(c, dict) and isinstance(c.get('text'), str)
                        and c.get('badge') in ('hi', 'mid', 'lo', 'no', 'yes'))
                    if not ok:
                        fail('%s.rows 单元格须为字符串或 {"text","badge"}: %r' % (p, c))
        else:  # eval
            has_eval = True
            for k in ('conclusion', 'evidence', 'advice'):
                if not isinstance(s.get(k), str) or not s[k].strip():
                    fail('%s.%s 必填(150-250 字业务语言)' % (p, k))
    if not has_eval:
        fail('sections 必须包含一个 type=eval 的数据评价段(结论/依据/建议)')

    check_inject(data)
    check_banned_strings(data)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    opts = {sys.argv[i][2:]: sys.argv[i + 1] for i in range(1, len(sys.argv)) if sys.argv[i].startswith('--')}
    if len(args) < 2:
        print(__doc__)
        fail('参数不足: python gen_report.py <data.json> <output.html>')
    src, out = args[0], args[1]
    # 文件名中文校验(2026-11-06 用户规范): 报表文件名用中文业务描述, 便于用户理解
    base = os.path.basename(out)
    if len(re.findall(r'[\u4e00-\u9fff]', base)) < 2:
        fail('输出文件名须为中文业务描述(如「各部门危险品出口_2026上半年.html」), 当前是: %s —— 请改中文名重跑' % base)
    tpl = opts.get('template', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'report_template.html'))

    if not os.path.isfile(src):
        fail('找不到 data.json: ' + src)
    if not os.path.isfile(tpl):
        fail('找不到渲染模板: ' + tpl)
    try:
        data = json.load(open(src, encoding='utf-8'))
    except json.JSONDecodeError as e:
        fail('data.json 不是合法 JSON: %s' % e)

    validate(data)

    tpl_text = open(tpl, encoding='utf-8').read()
    if '__REPORT_DATA__' not in tpl_text:
        fail('模板缺少 __REPORT_DATA__ 占位符(模板是否被改坏?)')
    html = tpl_text.replace('__REPORT_DATA__', json.dumps(data, ensure_ascii=False))

    leftovers = re.findall(r'__[A-Z_]+__', html)
    if leftovers:
        fail('渲染后仍残留占位符: %s' % sorted(set(leftovers)))

    with open(out, 'w', encoding='utf-8') as f:
        f.write(html)
    print('OK  已生成: %s (%d KB, KPI %d 张, 段落 %d 个)' % (
        os.path.abspath(out), len(html) // 1024, len(data['kpis']), len(data['sections'])))


if __name__ == '__main__':
    main()
