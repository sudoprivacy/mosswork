# 8+2 业务场景与取数映射

> 来源：《指标体系-按场景拆分设计.html》（场景拆分设计 v2.7）。
> **读取时机（性能）**：本文件是**详细编排层**。两类情况**必读**：① **报表档**（整体情况 / 趋势 / 走势 / 同比环比 / 结构 / 占比 / 排名 / 对比 / 归因 / 风险 / 政策影响）→ 按步骤 0 取场景配方卡的预置指标组合，**即使速查表已覆盖也要读**（`SKILL.md` 铁律 11）；② 速查表未覆盖、多场景组合、需要详细护栏 / 能力边界话术。**仅单点查数（文字档）不必打开本文件**，直接走速查表。
> **配方卡是内部编排信息（2026-11-04 用户指令）**：「必读护栏」「能力边界话术」「组织重叠 / 不可相加 / 重叠分类」等只用于组参数与自检，**不得整段抄进回答或报表**（例如不要写「『北美洲国家』属重叠分类组织口径，不与一带一路、欧盟、RCEP 相加或交叉剔除」）。真要告知能力边界时，改用 `output_design.md` §10 的业务话术；只有用户主动要求跨组织相加，才提示一句「这几个组织成员有重叠，不宜直接相加」。见 `SKILL.md` 铁律 12 与 `output_design.md` §1.2。
> **本文件是 Skill 的「场景编排层」**：步骤 0 用它识别场景并取出每场景「配方卡」的默认值（预置指标组合 / 默认维度与时间轴 / 必读护栏 / 输出形态 / 能力边界话术），驱动步骤 2 / 4 / 5 的参数与输出选择。
> **配方卡不是权威源**：`metricId` / `dimensionId` / 过滤值一律以 `dataMetricCatalog` 与 `dataDimensionValues` 实时返回为准；目录没有的指标不得凭配方卡硬传，须按 `metric_catalog.md` 决策树换替代（见 `SKILL.md` 铁律 7）。
> **内部代号不外露**：S1–S8 仅用于本文件内部路由，面向客户的报表与文案中禁止出现。

## 配方卡怎么读（五项字段的落地位置）

| 字段 | 读到后怎么用 |
|---|---|
| 预置指标组合 | 步骤 2 逐个去 `dataMetricCatalog` 确认 `metricId`，目录没有就换替代 |
| 默认维度 / 时间轴 | 步骤 4 组 `dimensions` / `timeAxis` / `grain` 默认值 |
| 必读护栏 | 步骤 2 / 4 前自检，避免 `REJECTED` 与口径错 |
| 输出形态 | 步骤 5 直接采用（KPI 数 / 主图 / 段落） |
| 能力边界话术 | 命中语义层做不到的部分时如实告知，不得编造 |

---

## 0. 场景总览（内部路由用）

| 场景 | 分析模式 | 输出结构 | 指标层次 | 典型消费角色 |
|---|---|---|---|---|
| S1 经营总览与预测 | 汇总 + 时序 | KPI(货值/单量/客户数) · 月度趋势(含预测) · 部门占比 · AI 评价 | 原子 + 时间派生 + 预测外推 | 高层（主）、部门经理 |
| S2 市场国别分析 | 结构切分 | KPI(覆盖国家/第一大占比/一带一路/欧盟) · 国别 TOP 排名 · 占比结构 · AI 评价 | 国别货值切片、占比、TOP N、覆盖国家数 | 高层、部门经理 |
| S3 组织部门分析 | 结构切分 | KPI(总额/增量/最大部门/负增长) · 部门对比 · 增量贡献度 · AI 评价 | 部门货值切片、占比、增量贡献度、部门单量 | 高层、部门经理 |
| S4 客户经营分析 | 客群 | KPI(活跃/CR5/新客户/流失) · 委托方 TOP5 · 新老分层 · 流失清单 · AI 评价 | 派生 + 复合（集中度、流失、合作网络） | 部门经理（主）、高层 |
| S5 产品结构分析 | 切分 + 时序 | KPI(项数/TOP1占比/低退税率/危险品) · 商品结构 · 品类 TOP · AI 评价 | 品类分布 + 明细级原子 + 品类时序 | 运营 |
| S6 退税与结算监控 | 状态监控 | KPI(完成率/待退/周期/超期) · 状态分布 · 退税率结构 · 超期清单 · AI 评价 | 状态派生 + 复合 + 时效 | 财务（主）、高层 |
| S7 风险预警与归因 | 风险识别 | KPI(在途/集中度/危险品/下滑) · 危险品命中 · 预警清单 · AI 归因链 · AI 评价 | 复合业务判断型 | 风控（主）、高层 |
| S8 政策影响评估 | 外部交叉 | KPI(低退税敞口/危化品类/美线/委托方) · 退税率暴露 · 关税命中清单 · AI 评价 | 外部清单 × 存量盘点（事件驱动） | 风控 |
| 横切支撑 · 明细下钻 | 行级检索 | 过滤器 · 行级明细表 · 申报要素模板 · 小结 · AI 评价 | 任何场景的第四层出口 | 全部角色 |
| 横切支撑 · 数据质量运营 | 质量度量 | 后台保障，无客户报表 | 指标可信度背书 | 数据 / IT |

**典型角色只用真实存在的**：高层、部门经理、运营、风控、财务；不得编造角色。

---

## 1. S1 经营总览与预测

**定义**：公司与部门两级对象、任意时间粒度（年/月/日）与任意区间的出口规模汇总，含同环比与预测——"出口了多少、涨了还是跌了、接下来会怎样"。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `export_usd_amt`（USD）+ `export_ticket_cnt`（票）成对调用；活跃委托方数 → 目录无独立指标，用 `export_usd_amt` + `dimensions:["consignor"]` 后数分组数（标注去重口径）；**同比必取**（铁律 15）：完整月 `compare:"yoy"`，当前月未完按日同期对齐两次查询 |
| 默认维度 / 时间轴 | 趋势 `dimensions:["ym"]`；结构 `["dept"]` 或 `["title"]` + `withTotal:true`；日粒度 `grain:"day"` + `startDay/endDay`；轴 `declaration` |
| 必读护栏 | `additive=true` 可跨期求和；`compare:"yoy"` 基准可能全 null，不得编造同比；月度序列默认按 `metric_value` 降序，画图前按 `dim_value` 升序重排；均值类 `additive=false` 不可跨分组相加 |
| 输出形态 | 单点查数 → 1–2 张 KPI 卡 + 一句结论；经营总览 → 3–4 KPI + `lineChart` 月度趋势 + `donut` 结构占比 + AI 评价 |
| 能力边界话术 | 语义层无预测指标、无独立活跃客户数指标；四季度预测只能基于历史序列参考外推，须显著标注"预测值 / 非注册指标 / 仅供参考" |

**问法示例**：
- "看一下今年截至 9 月公司整体出口情况"
- "三季度出口额多少？跟去年同期比怎么样？"
- "我们部门上个月出了多少票货？"
- "今年累计出口额和去年全年比还差多少？"
- "10 月 5 号到 8 号这几天公司出口了多少？"
- "预测一下四季度出口额能到多少"

**上线态取数组合**：
- 规模三度量：`export_usd_amt`（USD）+ `export_ticket_cnt`（票）各调一次；活跃委托方数可用 `client_avg_export_amt` 的分母概念但**语义层无独立委托方数指标**，如需说明"家数"须用 `consignor` 下钻后数分组数（注意 `additive=false` 语义与去重口径）。
- 月度趋势：`dimensions:["ym"]` + `startYm/endYm`；同比用 `compare:"yoy"`，环比用 `compare:"mom"`。
- 部门占比：`export_dept_rank` 或通用指标 + `dimensions:["dept"]` + `withTotal:true`。
- 日粒度：`grain:"day"` + `startDay/endDay`。

**能力边界**：语义层**没有预测指标**。用户要"预测四季度"时，只能基于已取到的历史序列 + YTD 同比做**参考外推**，必须在报表中显著标注"预测值 / 非注册指标 / 仅供参考"，不得当作实测数。

---

## 2. S2 市场国别分析

**定义**：出口货值在国家维度的分布、排名与覆盖度——"卖到哪些国家、各占多少、市场分散还是集中"。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `export_usd_amt` + `dimensions:["destination_country"]`（**默认，运抵国**）；`export_country_topn` 目录只登记 `dimensions:["country"]`，是**贸易国口径**，仅明确"签约国/交易对手"时用；组织口径 `export_usd_amt_by_org` / `export_ticket_cnt_by_org` |
| 默认维度 / 时间轴 | 国别默认 `destination_country`（运抵国，数据质量更高），仅"交易对手/签约国"用 `country`；大洲 `continent`；组织 `org`；通用指标轴 `declaration` |
| 必读护栏 | `org` 是 `overlapGroup=true` 重叠分类，**各行之和 ≠ 总量**，禁 `withTotal`/`mergeOthers`、禁据此算占比；单国占比用「过滤取分子 + 全量取分母」；`truncated=true` 时分组数不可信；高基数维取值必带 `search`；`export_country_topn` / `export_usd_amt_by_org` 的 `timeAxes=null`，**传 `timeAxis` 会被拒**，只有用通用指标 `export_usd_amt` 时才指定轴；**组织成员构成以平台字典为准，严禁用常识补正**（`金砖四国` 实测 4 国：巴西 / 中国 / 俄罗斯联邦 / 印度，**无南非**）；问「某组织里出口到哪几个国家」用 `dimensions:["destination_country"]` + `filters:[{dim:"org",op:"eq",values:["金砖四国"]}]`，**只列返回行，不补不删** |
| 输出形态 | KPI（覆盖/第一大占比/一带一路/欧盟）+ `hbar` 国别 TOP N + `donut` 占比 + 明细表 + AI 评价 |
| 能力边界话术 | 语义层无"覆盖国家数"独立指标，可用 `destination_country` 分组数近似并标注口径（`truncated` 时不可信） |

**问法示例**：目的国 TOP10 排名 / 美国市场占比 / 一带一路国家占出口总额多少 / 今年出口覆盖了多少个国家 / 欧盟成员国里哪个国家出口最多 / 按大洲看今年出口主要落在哪个洲。

**上线态取数组合**：
- 国别 TOP N：`export_usd_amt` + `dimensions:["destination_country"]` + `topN` + `order:"desc"` + `withTotal:true` + `mergeOthers:true`（**默认，运抵国**）；`export_country_topn` 只登记 `dimensions:["country"]`，走的是贸易国口径，仅在明确"签约国"时替换使用。
- **默认用运抵国 `destination_country`**；只有明确"交易对手/签约国"语义才用 `country`。
- 单个国家占比：先 `dataDimensionValues(destination_country, search:"美国")` 拿到 `USA`，再用 `filters:[{dim:"destination_country",op:"eq",values:["USA"]}]` 取分子 + 不带该过滤取分母。
- 组织口径：`export_usd_amt_by_org` / `export_ticket_cnt_by_org`，或 `filters:[{dim:"org",op:"eq",values:["一带一路国家"]}]`。
  注意：**`org` 是重叠分类**：`overlapGroup=true`，各行之和 ≠ 总量，不得求总或算占比；`withTotal`/`mergeOthers` 会被拒。
- 大洲：`dimensions:["continent"]`。

**能力边界**：语义层无"覆盖国家数"独立指标，可用 `dimensions:["destination_country"]` 的分组数近似并标注口径（注意 `truncated` 时分组数不可信）。

---

## 3. S3 组织部门分析

**定义**：出口规模在部门 / 公司抬头两级的横向分布、占比对比与增量贡献拆分——"谁大、谁占比高、增长是谁带来的"。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `export_dept_rank` + `dimensions:["dept"]`；抬头对比 `export_usd_amt` + `dimensions:["title"]`；部门单量 `export_ticket_cnt` + `dimensions:["dept"]` |
| 默认维度 / 时间轴 | 部门 `dept`（统一权限轴，默认）、抬头 `title`；增量 `dimensions:["dept","ym"]` 或 `compare:"yoy"`；轴 `declaration` |
| 必读护栏 | `dept` ≠ `business_department`（报关单原值），用户说"部门"默认 `dept` 且报表标注；未匹配部门归 `UNASSIGNED`（海关数据已收到但未与内部数据匹配，**不是脏数据**）须单列，不得剔除、不得强行算同环比；增量贡献本地算 `(部门本期−部门同期) ÷ (全公司本期−全公司同期)`，可为负、各部门守恒 100%；`export_dept_rank` 的 `timeAxes=null`，**勿传 `timeAxis`**，增量时序改用通用指标 `export_usd_amt` + `dimensions:["dept","ym"]` 或 `compare:"yoy"` |
| 输出形态 | KPI + `hbar` 部门对比 + 增量贡献表（双区间对比条）+ AI 评价 |
| 能力边界话术 | 增量贡献度为本地计算、非注册指标；`title` 实测 6 个抬头（含 09 中基天时），值域以 `dataDimensionValues` 为准 |

**问法示例**：各部门出口额对比 / 综合二部占比 / 今年出口增长主要靠哪个部门 / 把几个综合部排个名 / 两个事业部谁规模大 / 哪个部门对今年出口增量贡献最大。

**上线态取数组合**：
- 部门排行：`export_dept_rank` + `dimensions:["dept"]` + `withTotal:true`。
- 抬头对比：`dimensions:["title"]` + `withTotal:true`（实测 6 个抬头，含 09 中基天时）。
- 增量贡献度：**本地计算** —— 取本期与去年同期各部门货值，`(部门本期 − 部门去年同期) ÷ (全公司本期 − 全公司去年同期)`；可为负、不取绝对值、各部门合计守恒 100%。可用 `compare:"yoy"` 直接拿 `diff`。
- 部门单量：`export_ticket_cnt` + `dimensions:["dept"]`。

**注意**：`dept`（统一部门，权限轴，未匹配归 `UNASSIGNED`）与 `business_department`（报关单原值）**是不同轴**，用户说"部门"默认指 `dept`，报表须标注。

---

## 4. S4 客户经营分析

**定义**：委托方全生命周期：合作金额与画像、新老客户分层、流失识别、集中度，以及工厂 × 委托方的合作网络。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `export_usd_amt` + `dimensions:["consignor"]` + `withTotal:true`；`client_avg_export_amt`（`additive=false`）；集中度 CR5 / CR10 本地基于 `share_pct` 算 |
| 默认维度 / 时间轴 | `consignor`；期内新准入 `filters:[{dim:"principal_client_approval_date",op:"between",values:[...]}]`；流失取两期集合差集；轴 `declaration` |
| 必读护栏 | `consignor` 是 `sensitive` 维，**只返回代码/简称不返回注册全称**，报表须用代码标识并说明；去重客户数 `additive=false` 不可跨期/跨维相加；`principal_client_approval_date` 只作过滤不做度量时间轴 |
| 输出形态 | KPI（活跃/CR5/新客/流失）+ `hbar` 委托方 TOP5 + 集中度标注 + 新老分层 / 流失清单 + AI 评价 |
| 能力边界话术 | 语义层无"生产厂家 × 委托方合作网络"现成指标（生产销售单位不纳入查询维度），须说明不可按厂家名称拆分；流失判定为本地两期比对 |

**问法示例**：客户合作情况分析 / 委托方 TOP10 与前五大占比 / 哪些客户流失了按去年体量排 / 今年新准入的委托方及贡献 / 次新客户（合作一年内）出口额 / 某工厂当前合作的委托方。

**上线态取数组合**：
- 委托方 TOP N：`export_usd_amt` + `dimensions:["consignor"]` + `topN` + `withTotal:true`；CR5/CR10 由本地基于 `share_pct` 计算。
- 期内新准入：`filters:[{dim:"principal_client_approval_date", op:"between", values:["2026-01-01","2026-09-30"]}]`（该维 `ops` 含 `between`）。
- 流失客户：**本地两期比对** —— 取去年有单、今年无单的 `consignor` 集合差集，按去年货值降序。语义层不直接提供流失判定。

**能力边界**：
- `consignor` 是**敏感维**，只返回 `principal_client_code` / 简称，**不返回注册全称**；报表须用代码标识并说明。
- 语义层无"生产厂家 × 委托方合作网络"的现成指标（生产销售单位不纳入查询维度），遇到此类问法须说明不可按厂家名称拆分。
- 去重客户数不可跨期/跨维相加。

---

## 5. S5 产品结构分析

**定义**：产品维度的分布、趋势与增减突变——商品数字资产战略在指标层的落点，全部基于明细表。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | **一律明细面**：`export_item_usd_amt` + `dimensions:["product_category"]`；`export_item_line_cnt`；`avg_items_per_declaration`（`additive=false`） |
| 默认维度 / 时间轴 | `product_category` / `product_sub_category`（交叉 `[product_category, product_sub_category]`）；HS 前缀 `hs_code_4` / `hs_code_6`；时序 `dimensions:["product_category","ym"]`；轴 `declaration` |
| 必读护栏 | `export_item_usd_amt`（明细面）与 `export_usd_amt`（主面）是**两个粒度**，之和互相对平、**相加无意义**（实测两口径 `grand_total` 同为 1,692,973,955 USD）；`hs_code_4` 与 `product_category` 是两套归集体系不可互推核对，且二者**只在 `source=item` 指标的 filters 白名单里**，主表指标传它们会 `REJECTED`；`export_item_declared_qty` 跨 `item_declared_unit` 相加无意义；`hs_code` 高基数取值必带 `search`；`topN:10` 时 `truncated=true`（共 35 类目），不可称全集 |
| 输出形态 | KPI（项数/TOP1 占比）+ `hbar` 品类 TOP + `donut` 占比 + `lineChart` 品类时序 + AI 评价 |
| 能力边界话术 | 语义层无退税率指标（目录无 `tax_refund_rate` 度量），"零退税 / 低退税率商品"暂不支持 |

**问法示例**：产品类别分布哪个大类最多 / 机电类近 6 个月趋势 / 纺织制品占比 / HS 84 开头今年出口多少 / 五金工具大类下有哪些小类 / 哪个品类单票货值最高。

**上线态取数组合**（一律用**明细面**指标）：
- 品类 TOP：`export_item_usd_amt` + `dimensions:["product_category"]`（或小类 `product_sub_category`） + `topN` + `withTotal:true`。
- 二级类目交叉：`dimensions:["product_category","product_sub_category"]`。
- HS 前缀：`dataDimensionValues(hs_code, search:"8517")` 后 `filters:[{dim:"hs_code_4",op:"eq",values:["8517"]}]`；或用 `hs_code_6`（国际通行）。
- 品类时序：`dimensions:["product_category","ym"]` + `startYm/endYm`。
- 商品行数：`export_item_line_cnt`；票均商品行数：`avg_items_per_declaration`。

**注意**：
- `hs_code_4` 与 `product_category` 是**两套归集体系**，不可互推互相核对。
- `export_item_usd_amt`（明细面）与 `export_usd_amt`（主面）是两个**粒度**，之和互相对平，**两者相加没有意义**。
- `export_item_declared_qty` 跨 `item_declared_unit` 相加无意义，先按单位过滤或分组。

---

## 6. S6 退税与结算监控

**定义**：退税进度、积压、完成率与异常退税委托方识别；结算状态与资金占用——状态字段的时序监控。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `refund_actual_amt`（CNY）；`avg_refund_cycle_days` **必须成对读** `refund_cycle_coverage`；状态分布 `export_usd_amt` / `export_ticket_cnt` + `dimensions:["rebate_status"]` 或 `["settlement_status"]` |
| 默认维度 / 时间轴 | `timeAxis:"rebate_writeback"`（默认，看到账）；看归属期传 `"rebate_period"`（**仅 ym，不开放 day**）；`rebate_status` / `settlement_status` 分组；未结算 `filters` eq `UNSETTLED`；另取全量作分母算占比 |
| 必读护栏 | 退税金额类内建 `requiredFilters: rebate_status=DECLARED`，**勿重复传**；`avg_refund_cycle_days` 覆盖率仅约 10.8%，必须与 `refund_cycle_coverage` 同读并披露；CNY 不可与 USD 相加；`additive=false` 均值不可跨期相加 |
| 输出形态 | KPI（完成率/待退/周期含覆盖率/超期）+ `donut` 状态分布 + 周期说明 + AI 评价 |
| 能力边界话术 | 「超期未回填清单」「逐单申报要素」属行级明细，语义层只返聚合，须说明改用报表系统；无退税率指标 |

**问法示例**：本季度退税完成率 / 待退税积压 / 退税异常委托方 / 8 月所属期申报退税的单子平均多久回款 / 还有多少货值没结算及占比 / 零退税商品 / 申报很久还没回填的单子。

**上线态取数组合**：
- 实际退税金额：`refund_actual_amt`（CNY），默认轴 `rebate_writeback`（看"这段时间到账多少"）；看归属期传 `timeAxis:"rebate_period"`。内建 `requiredFilters: rebate_status=DECLARED`，勿重复传。
- 退税周期：`avg_refund_cycle_days` **必须同时读 `refund_cycle_coverage`**（有效样本仅约 10.8%），否则均值会把覆盖率问题藏起来。
- 状态分布：`export_usd_amt` / `export_ticket_cnt` + `dimensions:["rebate_status"]` 或 `["settlement_status"]`；完成率由本地基于分组值计算。
- 未结算：`filters:[{dim:"settlement_status",op:"eq",values:["UNSETTLED"]}]`，占比另取全量分母。

**能力边界**：
- 「超期未回填清单」「逐单申报要素」属于**行级明细**，语义层只返回聚合数据，**不支持逐单明细**；须说明改用报表系统。
- 退税率结构：语义层无退税率指标（目录无 `tax_refund_rate` 度量），如实告知暂不支持。

---

## 7. S7 风险预警与归因

**定义**：内部数据异常的检测、预警与归因：三类危险品监控、查验率、大客户集中度、客户产品结构突变、部门经营异常——输出 AI 归因链与行动建议。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `export_inspection_rate`（`additive=false`）；危险品明细面 `export_item_usd_amt` / `export_item_line_cnt` + `filters:[{dim:"is_dangerous",op:"eq",values:["1"]}]`；集中度 `export_usd_amt` + `dimensions:["consignor"]` + `withTotal:true`；下滑 `compare:"yoy"` |
| 默认维度 / 时间轴 | `is_dangerous` / `is_hazardous_chemical`；`consignor`；`destination_country` + `compare:"yoy"` 筛 `diff_pct<0`；`dimensions:["dept","ym"]`；轴 `declaration` |
| 必读护栏 | 查验率 `additive=false`，分组后大量 0 与空组，**不可把各组率相加**；危险品按明细行数 / 明细金额统计，**不是票数**；`is_hazardous_chemical` 是 `is_dangerous` 子集，不可混用或相加；归因链是 AI 基于下钻结果的分析结论、非语义层指标，须写明依据、不得编造因果 |
| 输出形态 | 命中清单 + 阈值标注 + 预警表 + `hbar` + **AI 归因段** + AI 评价 |
| 能力边界话术 | 归因结论为 AI 分析、不是注册指标；语义层不提供风险评级，阈值（如 CR5 60%、下滑幅度）为业务假设须标注 |

**问法示例**：哪些国家同比下滑幅度多大 / 大客户占比过高有没有风险 / 综合二部九月出口是不是有风险帮我归因 / 客户产品结构突变 / 危险品出口异常涉及哪些客户 / 排查高风险客户给建议。

**上线态取数组合**：
- 查验率：`export_inspection_rate`（`additive=false`，实测整体 0.30% 小比率，分组后大量 0 与空组）。
- 危险品：明细面 `export_item_usd_amt` / `export_item_line_cnt` + `filters:[{dim:"is_dangerous",op:"eq",values:["1"]}]` 或按 `is_dangerous` 分组；`is_hazardous_chemical` 是子集，不可混用。
- 集中度：`dimensions:["consignor"]` + `withTotal:true` 后本地算 CR5 / CR10（阈值默认 60%）。
- 同比下滑：`dimensions:["destination_country"]` + `compare:"yoy"`，筛 `diff_pct < 0`。
- 部门异常：`dimensions:["dept","ym"]` + `compare:"yoy"`/`"mom"`。

**注意**：归因链是 **AI 基于多维下钻结果的分析结论**，不是语义层返回的指标；须写明依据是哪些下钻数据，不得编造因果。

---

## 8. S8 政策影响评估

**定义**：外部政策事件（加征关税、制裁清单、出口禁令、税率调整）出台后，对系统存量的影响盘点与业务暴露度评估——事件驱动、临时入参、不注册固定指标。

**配方卡（步骤 0 读取 · 默认参数，须经目录实时确认）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | 事件驱动、**无固定指标**，且**按过滤维选面**：主面维（`destination_country` / `consignor`）→ `export_usd_amt` / `export_ticket_cnt`；明细面维（`hs_code_4` / `hs_code_6` / `product_category`）→ **必须改用** `export_item_usd_amt` / `export_item_line_cnt` |
| 默认维度 / 时间轴 | 过滤维 `destination_country`（如 `USA`）、`hs_code_4`（如 `8517` / `8471`）、`product_category`；主面指标轴 `declaration`；税负测算税率由用户提供、本地算影响金额区间 |
| 必读护栏 | **过滤维要认面**：`hs_code_4` / `hs_code_6` / `product_category` / `product_sub_category` / `is_dangerous` 只在 `source=item` 指标（明细面）的 filters 白名单里，用主表 `export_usd_amt` / `export_ticket_cnt` 硬传会 `REJECTED`；外部清单（关税税率 / 制裁名单 / 管制清单）**语义层不维护**，须用户提供或明确标注为假设，**不编造政策内容**；过滤值一律先经 `dataDimensionValues` 取真实值（多值自动写成 IN）；`truncated` 时命中分布不可称全集 |
| 输出形态 | 暴露扫描 KPI + `hbar` 命中分布 + 命中清单 + 影响测算 + AI 评价 |
| 能力边界话术 | 外部清单与税率非语义层数据；逐单命中明细请改用报表系统（四工具只返聚合） |

**问法示例**：美国最新加征关税影响多大 / 出口管制清单命中了哪些货 / 受制裁国家还有多少出口 / 欧盟新规影响哪些品类 / 把受影响的单子明细拉出来。

**上线态取数组合**：把外部清单**翻译成过滤条件**做暴露扫描：
- 涉美国：`filters:[{dim:"destination_country",op:"eq",values:["USA"]}]`
- 涉某 HS 段：`filters:[{dim:"hs_code_4",op:"eq",values:["8517","8471"]}]`（**须用明细面指标 `export_item_usd_amt` / `export_item_line_cnt`**，主表指标不认该维）
- 涉某品类：`filters:[{dim:"product_category",op:"eq",values:[...]}]`（同上，须用明细面指标）
- 涉制裁国家：`filters:[{dim:"destination_country",op:"eq",values:[...]}]`
再按 `dimensions` 出受影响货值 / 票数 / 委托方 / 品类分布；税负测算的税率参数由用户提供，本地计算影响金额区间。

**能力边界**：外部清单（关税税率、制裁名单、管制清单）**语义层不维护**，须由用户提供或明确标注为假设；不编造政策内容。

---

## 9. 横切支撑域

### 9.1 明细下钻

**问法**："客户C 本月的领单明细拉一下""美国禁令命中的那些单子明细给我""综合二部 9 月每一票报的什么品名"

**配方卡（步骤 0 读取 · 默认参数）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | 任意指标的**最细粒度分组**；`declaration_no` / `declaration_no_item` eq 过滤后的聚合值 |
| 默认维度 / 时间轴 | `declaration_no`（主面）/ `declaration_no_item`（明细面）/ `consignor` / `hs_code` 最细分组；单据号值大小写敏感须精确 |
| 必读护栏 | **四工具只返聚合 / 维度统计，不支持逐单、逐行明细导出**；不得用分组结果冒充明细、不得编造行级数据 |
| 输出形态 | 无客户报表；可提供"按单据号 eq 过滤后的聚合值 / 最细粒度分组"作为替代 |
| 能力边界话术 | 「语义层仅支持汇总统计，逐单明细请改用报表系统」 |

> 注意：**cbnb-mcp-gateway 四个工具全部只返回聚合 / 维度统计，不支持逐单、逐行明细导出。** 遇到此类问法必须明确告知"语义层仅支持汇总统计，逐单明细请改用报表系统"，**不得用分组结果冒充明细**，也不得编造行级数据。可提供的替代：按 `declaration_no` / `declaration_no_item` 等单据号维做 eq 过滤后的聚合值、按 `consignor` / `hs_code` 等维度的最细粒度分组。

### 9.2 数据质量运营

**配方卡（步骤 0 读取 · 默认参数）**

| 配方项 | 默认值 |
|---|---|
| 预置指标组合 | `export_usd_amt_coverage` 与 `export_ticket_cnt` 比对得金额覆盖率；`export_inspection_rate` |
| 默认维度 / 时间轴 | 轴 `declaration` |
| 必读护栏 | 未解析金额的票不得当作 0 金额解读；引用 `export_usd_amt` 时若覆盖率不足须在页脚标注 |
| 输出形态 | 后台保障，无客户报表 |
| 能力边界话术 | 仅作指标可信度背书，不单独出客户报表 |

> 后台保障，无客户报表：金额覆盖率用 `export_usd_amt_coverage` 与 `export_ticket_cnt` 比对；引用 `export_usd_amt` 时若覆盖率不足须在页脚标注。

---

## 10. 场景配方索引（步骤 0 用）

> 每个场景的完整配方卡见上文对应小节。本表供步骤 0 快速定位主场景与核心默认值；「输出形态 / 主图」列可直接落到步骤 5。

| 场景 / 倾向 | 配方卡 | 主指标组合 | 主护栏 | 输出形态 | 主图 |
|---|---|---|---|---|---|
| S1 单点查数 | §1 | `export_usd_amt` + `export_ticket_cnt` | 同比基准可能缺失 | 1–2 KPI + 一句结论 | 无 |
| S1 经营总览 | §1 | 同上 + `dimensions:["ym"]` | 月度序列默认降序须重排 | 3–4 KPI + 趋势 + 占比 + AI 评价 | `lineChart` + `donut` |
| S2 市场国别 | §2 | `export_usd_amt` + `destination_country` | `org` 重叠分类禁求和 | TOP N 条形 + 占比 + 明细表 | `hbar` + `donut` |
| S3 部门对比 | §3 | `export_dept_rank` + `["dept"]` | `dept` ≠ `business_department` | KPI + 部门对比 + AI 评价 | `hbar` + `donut` |
| S3 增量贡献 | §3 | 双期部门货值 + 本地计算 | 可为负、守恒 100% | 双区间对比条 + 增量贡献表 | `hbar` |
| S4 客户经营 | §4 | `export_usd_amt` + `["consignor"]` | 敏感维只返代码 | KPI + 委托方 TOP5 + 集中度标注 | `hbar` |
| S5 产品结构 | §5 | `export_item_usd_amt` + `product_category` | 明细面与主面两粒度不相加 | 品类 TOP 条形 + 占比 + 时序 | `hbar` + `lineChart` |
| S6 退税结算 | §6 | `refund_actual_amt` / 状态分布 | 周期须同读覆盖率 ~10.8% | KPI + 状态分布 + 周期（含覆盖率） | `donut` |
| S7 风险归因 | §7 | 查验率 / 危险品明细 / 集中度 | 归因链是 AI 结论非指标 | 命中清单 + 阈值 + 预警表 + AI 归因段 | `hbar` |
| S8 政策影响 | §8 | 无固定指标 + 外部清单 `filters` | 外部清单不编造 | 暴露扫描 KPI + 命中明细 + 影响测算 | `hbar` |
| 横切 · 明细下钻 | §9.1 | 最细粒度分组 / 单据号 eq | 不支持逐单明细 | 无客户报表，改报表系统 | 无 |
| 横切 · 数据质量 | §9.2 | `export_usd_amt_coverage` | 覆盖率不足页脚标注 | 后台保障，无客户报表 | 无 |

> **回归验证记录（2026-11-03 · 场景驱动编排升级）**：用 `dataMetricCatalog({})` 全量目录核对配方卡全部 `metricId` / `dimensionId` / `timeAxis`，均在上线条目内；并实跑三组参数全部 `success:true`——S2 `export_usd_amt_by_org` + `dimensions:["org"]`（回 `overlapGroup:true`，19 个组织，不带 `withTotal` 未被拒）、S5 `export_item_usd_amt` + `["product_category"]` + `withTotal:true`（`grand_total=1,692,973,955 USD`，与主表票级对平）、S6 `refund_actual_amt` + `timeAxis:"rebate_writeback"`（回 `appliedFilters:["rebate_status=DECLARED（指标口径内建）"]`）。核对中发现并已修正三处白名单级冲突：① `export_country_topn` 只登记 `country`（贸易国），默认运抵国须用 `export_usd_amt` + `destination_country`；② 排行 / 组织类指标 `timeAxes=null`，传 `timeAxis` 会被拒；③ HS / 品类维只在明细面指标 filters 白名单，主表指标硬传会 `REJECTED`。

> **红线**：以上 S1–S8 代号仅本文件与内部路由使用。客户报表、AI 评价、话术中一律用中性业务措辞（"国别结构分析""部门对比"等），不得出现"命中场景 S2""见 S8""metric_drill"等字样；跨维度引导用"可继续向我提问"。
