# 四工具工作流手册

> 数据源唯一入口：连接器 `cbnb-mcp-gateway`。四个工具全部为**元数据或聚合查询**，不返回逐单明细。
> 目录自带 `usage` 字段给出的正确顺序：**术语 → 目录 → 维度值 → 查询**。
>
> **完整工具 ID**：`mcp__cbnb-mcp-gateway__dataBusinessTerms` / `mcp__cbnb-mcp-gateway__dataMetricCatalog` / `mcp__cbnb-mcp-gateway__dataDimensionValues` / `mcp__cbnb-mcp-gateway__dataMetricQuery`。实际调用须用完整 ID，本文件正文用简写（`dataBusinessTerms` 等）。
> **数据源**：用户需在连接器管理页启用「中基惠通MCP Connector」（**"MCP" 前无空格**；`mcpServer` = `cbnb-mcp-gateway`）后，本 Skill 才能取到真实业务数据；工具前缀统一为 `mcp__cbnb-mcp-gateway__`。未启用时的处理见下节；无交互的自动化环境按「运行环境分流 ③」走演示模式，不发起连接请求。

### 连接器未启用时的自动处理（2026-11-12 用户规范 · 仅 cbnb 版）

**适用范围**：仅限存在可交互用户、且连接打通能力可用的会话；无交互的自动化环境按 §8 走演示模式，本节三步一律不执行。

**触发信号**：`mcp__cbnb-mcp-gateway__*` 四个工具在本会话检索不到；或调用返回未连接 / 需授权 / 授权过期 / 缺少凭证等等价信号。**此时不按 §5 普通失败语义处理，也不先甩「请到设置里手动启用」之类指引**——先由 Skill 替用户把连接打通；自动打通失败（`failed` / `skipped` / 无响应 / 授权未达成）或打通能力本身不可用时，按第 4 步给「手动连接引导」。

**四步（内部动作，按顺序）**：
1. `list_installed_plugins()` **不传参列全部**，按 `mcpServer:"cbnb-mcp-gateway"` 找到该连接器，看 `bound` / `enabled` / `status`。若确实要按名精确查，`connectorName` 必须写**无空格**的「中基惠通MCP Connector」——平台实测多一个空格会直接报 `No installed connector named ...`。
2. **仅 `bound:false`** → `search_plugins({type:"connector", userIntent:"中基惠通MCP Connector", keywords:["中基惠通"]})` 查真实候选 → `suggest_plugin_install({type:"connector", pluginId1:<结果 id>, contextLabel:"中基惠通出口数据"})` 出一张卡片；用户安装后进入第 3 步。**`bound:true` 一律跳过本步，直接进第 3 步发连接卡片**；认证失效可先 `reconnect_plugin({pluginName:<list_installed_plugins 返回的 pluginName>})`。

> **「搜不到」的正确解释**：`search_plugins` **只返回当前账号未绑定的连接器**（平台设计）。已绑定 / 曾连接 / 已装未连的账号，无论用业务问法、中文全称还是英文 `cbnb`，都不会返回它；实测三种写法返回的都是金融、法律等无关候选。**这不是关键词问题，不要换词反复搜、也不要据此判定连接器不存在。** `userIntent` 用精确展示名 + 单个 `keywords`，只为在 `bound:false` 时提高命中率。

> 另一类「搜不到」是 `mcp__cbnb-mcp-gateway__*` 四工具在会话里检索不到（工具未注册），与中文名无关；按第 3 步用 `servers:["cbnb-mcp-gateway"]` 发连接卡片即可，卡片自带平台权威服务名称，不需要 Skill 自己拼名字。
3. `workbuddy_request_mcp_connection({servers:["cbnb-mcp-gateway"], capability:"中基惠通出口数据查询"})`，等待用户完成授权：`connected` → **立即重试原查询**并继续原本的输出档；**`failed` / `skipped` / 无响应 / 无法完成授权 → 不重复请求、不阻塞、不只回一句「无法取数」：有真实用户转第 4 步「手动连接引导」；无交互自动化环境才立即转 §8 演示模式**。

4. **手动连接引导（自动打通失败 · 有真实用户）**：用 `output_design.md` §10.1c 话术引导用户自行完成——聊天窗口左下角「+」连接器市场（或连接器管理页）→ 搜索「中基惠通MCP Connector」（**"MCP" 前无空格**）→ 启用并完成授权。用户回来说已完成 → 重探四工具：可用即重试原问句并按原输出档续跑；仍不可用再走一次第 3 步（仅一次），之后如实说明当前状态并再给一次手动引导，不编数、不无限循环、不转演示模式。

**边界**：`servers` 只列 `cbnb-mcp-gateway`、不列会话里其他服务器、不 invent 服务名；`suggest_plugin_install` 每轮最多一次；**`search_plugins` 无结果时先看 `bound`，不靠改名称或加关键词重试**；连接卡片本身已说明状态，**调用前不要用散文复述连接状态**；授权未达成时：有真实用户转第 4 步「手动连接引导」（不卡在等待上），无交互自动化环境才转 §8 演示模式；全程不把工具名、失败码、连接状态写进客户回答（铁律 12）。授权必须由用户点确认，Skill 只负责查找、发起、等待与续跑。

## 0. 依赖顺序（不可颠倒；按快照可跳步）

```
dataBusinessTerms  ── 语义理解（条件触发：仅黑话 / 歧义时调）
        ↓
dataMetricCatalog  ── 拿到 metricId / dimensionId（条件触发：仅快照未覆盖或报错时调，必带 category）
        ↓
dataDimensionValues ── 拿到 filters 的真实 value（条件触发：仅模糊 / 高基数 / 需精确代码时调）
        ↓
dataMetricQuery    ── 取聚合数据（必做，目标 1 次）
```

- **顺序不可颠倒**，但前三步都是**条件触发**：`references/business_terms.md` 与 `references/metric_catalog.md` 是服务端实测快照，默认信任；绝大多数问句直接从 `SKILL.md` 速查表取参数、只调 `dataMetricQuery` 一次。
- 目录调用必须带 `category`（如 `amount` / `volume` / `rank`）窄查；**禁止 `dataMetricCatalog({})` 全量返回**（实测约 65KB，是最大单次开销）。
- 步骤 3 只在「过滤值是用户口语、高基数维、需要精确代码」时必做；已登记精确枚举（20 组织、状态值、incoterm、抬头代码、alpha-3 国家码）可直接填，不猜测也不重复取。
- 一次用户问题尽量**一次 `dataMetricQuery` 拿全**：能用 `withTotal` / `topN` / 多维一次返回的，就别拆成总量→分组→同比三次往返；确需多次时控制在 3 次工具调用以内。
- 聚合计算（占比、增量贡献）在本地基于返回行算，不额外调工具。

---

## 1. dataBusinessTerms — 术语解析

**入参**：无（`{}`）。**返回**：业务术语知识库 Markdown 全文（仅元数据，不取业务数据）。

调用时机（条件触发）：仅遇到 `business_terms.md` 未收录的口语黑话、口径出现歧义、或怀疑服务端知识库已更新时才调。常规问句直接走 `SKILL.md` 速查表，不必调用本工具。未收录某词不代表业务数据不存在。

精炼快照见 `business_terms.md`（2026-11-03 实测）；**默认信任快照，不每次调用**——这是性能预算要求，不是跳过语义理解。

---

## 2. dataMetricCatalog — 指标与维度定义

**入参**：`category`（可选，英文 key 如 `amount`/`volume`/`rank`/`weight`/`quality`，或中文标签如 `金额`/`票量`；留空返回全部）。

**返回结构**：

| 字段 | 含义 |
|---|---|
| `metrics[]` | 指标清单：`metricId` / `name` / `description` / `category` / `unit` / `measureId` / `timeGrains` / `dimensions`（可下钻）/ `filters`（可过滤）/ `comparable` / `caveat` / `additive` / `nonAdditiveCaveat` / `requiredFilters` / `source`(main\|item) / `grain` / `timeAxes` / `defaultTimeAxis` |
| `dimensions[]` | 全量维度：`dimensionId` / `name` / `description` / `synonyms` / `ops` / `sensitive` / `source` / `viaJoin` / `overlap` |
| `measures[]` | 度量定义：`measureId` / `unit` / `additive` / 口径护栏说明 |
| `timeAxes[]` | 4 条时间轴与各自 `timeGrains` |
| `categories` | 分类 key → 中文标签 |
| `supportedTimeGrains` | `["ym","day"]` |
| `usage` | 官方调用顺序说明 |

**关键判断**：

- `metrics[].dimensions` = 允许下钻的维；`metrics[].filters` = 允许过滤的维。**传了不在白名单内的维 → `REJECTED` 或 `UNSUPPORTED_SHAPE`**。
- `dimensions[].viaJoin` 非空（如 `org` 的 `bridge`）= **关联维**，靠桥表取数，取值是全局字典、不经权限收窄；`overlap=true` 表示重叠分类。
- `additive=false` 的指标（均值/比率/去重计数）不可跨期跨维相加。
- `requiredFilters` 是指标内建口径条件（退税类内建 `rebate_status=DECLARED`），**不要自己再传一遍**，也不要把空值当 0 解读。

速查表见 `metric_catalog.md`。

---

## 3. dataDimensionValues — 维度真实取值

**入参**：

| 参数 | 必填 | 说明 |
|---|---|---|
| `dimensionId` | ✅ | 来自目录 `dimensions[]` |
| `search` | — | 子串模糊匹配（不区分大小写）；高基数维度**必用**，如国家名片段、HS 前缀 |
| `startYm` / `endYm` | — | 探测区间 `yyyyMM`；**关联维（桥表）无效** |
| `limit` | — | 默认 100，有硬上限 |

**返回**：`{dimensionId, dimensionName, values:[{value, name, cnt}], returned, truncated, candidateDimensions}`

- `value` 是填 `filterVal` / `filters[].values` 的**键**，`name` 是展示名，`cnt` 只是热门排序依据（普通维度=出现行数；**关联维=成员数，是组织成员构成的权威依据**），**不是业务指标**。实测 `org` + `search:"金砖"` 返回 `cnt:4`，即平台字典「金砖四国」成员数为 4，**不得按现实常识补南非**。
- `search` 除命中分组列/展示名列外，还命中注册表登记的匹配列（如国家英文名），故英文反查也可定位。
- `truncated=true` = 只回了前 limit 个热门值，**不能当全集**、不能据此判断"该维只有这些取值"；缩小 `search` 重查。
- 普通维度自动注入行级权限：决策层看全量、管理层只看本部门取值；无权限上下文 → `AUTH_INCOMPLETE`，绝不放全量。
- 关联维（`viaJoin` 非空）取值来自维表/桥表本身，是全局字典、不经权限收窄（权限只约束事实行）。
- `UNSUPPORTED_SHAPE` = 该维在视图侧无对应列或不支持当前粒度。

**实测样例（2026-01 ~ 2026-09）**：

```json
// ① 普通维 title（公司抬头）——注意出现术语表未收录的 09
{"dimensionId":"title","values":[
 {"value":"05","name":"中基惠通","cnt":53775},
 {"value":"02","name":"中基人和","cnt":8534},
 {"value":"04","name":"宁波和念","cnt":4250},
 {"value":"09","name":"中基天时","cnt":1956},
 {"value":"07","name":"惠通跨境","cnt":1331},
 {"value":"08","name":"宁波初念","cnt":28}],"truncated":false}

// ② 关联维 org（重叠分类）——值是精确中文枚举，cnt 是成员国数
{"dimensionId":"org","values":[
 {"value":"一带一路国家","name":"一带一路国家","cnt":155},
 {"value":"欧洲","name":"欧洲","cnt":46},
 {"value":"欧盟国家","name":"欧盟国家","cnt":27},
 {"value":"RCEP","name":"RCEP","cnt":15}, ... ],"truncated":false}

// ③ 高基数维 destination_country + search
{"dimensionId":"destination_country","search":"美国",
 "values":[{"value":"USA","name":"美国","cnt":26434}],"truncated":false}
```

> **教训**：术语知识库列了 5 个抬头（02/04/05/07/08），实际值域是 6 个（多 09 中基天时）。**值域一律以本工具为准，术语表只用于理解语义。**

---

## 4. dataMetricQuery — 执行查询

**入参**：见 `SKILL.md` 步骤 4 参数表。补充要点：

- `startYm`/`endYm`（`yyyyMM`）与 `startDay`/`endDay`（`yyyyMMdd`）**不得混传**；`grain=day` 恒走视图且单次跨度有上限。**同比同期对齐**（当前月未完）用 `grain=day`：`startDay=YYYYMM01`/`endDay=YYYYMMDD` 取本期，`(YYYY-1)MM01`/`(YYYY-1)MMDD` 取去年基期，`compare` 不支持 day 故须两次查询后本地算（见 §4 D、SKILL.md 铁律 15）。
- `timeAxis` 传指标未登记的轴会**被拒**，不是默默换回默认轴；退税类指标默认轴就是退税轴。
- `filters` 每项 `{dim, op, values}`，`op` 缺省 `eq`；`between` 仅对目录 `ops` 含 between 的时间维开放；多值自动写成 IN。与 `filterDim/filterVal` 同维重复时 `filters` 优先。
- `compare` 仅 `grain=ym`；`mergeOthers`/`withTotal` 对关联维分组会 `UNSUPPORTED_SHAPE`。

**返回体字段**：

| 字段 | 含义 |
|---|---|
| `metricId` / `metricName` / `unit` | 指标标识与单位 |
| `comboCd` / `sourceLayer` / `source` | 路由层级（DWS 快路径 / DWD 受控聚合视图兜底）、数据面（main / item） |
| `timeAxis` / `periodStart` / `periodEnd` | 本次实际时间轴与区间 |
| `overlapGroup` | 分组是否为重叠分类 |
| `additive` | 指标是否可加 |
| `rows[]` | 单维下钻含 `dim_value`/`dim_name`/`metric_value`；多维下钻含 `dim_<维度>`/`dim_<维度>_name` |
| `rows[]`（withTotal） | 附 `total_group_cnt` / `grand_total` / `share_pct` |
| `rows[]`（compare） | 附 `base_value` / `diff` / `diff_pct` |
| `truncated` | 是否达到行数上限 |
| `appliedFilters` | **本次实际生效的过滤**（含指标内建口径条件与被口径覆盖而丢弃的传入条件） |
| `capability` | 失败时给出的可用清单 |

**实测样例**：

```json
// export_usd_amt 按 title 下钻，2026-01~09，withTotal
{"metricId":"export_usd_amt","unit":"USD","comboCd":"DWD","source":"main",
 "timeAxis":"declaration","overlapGroup":false,"additive":true,
 "periodStart":202601,"periodEnd":202609,
 "rows":[
  {"dim_value":"05","dim_name":"中基惠通","metric_value":1373762190.00,"share_pct":81.14,"total_group_cnt":6,"grand_total":1692973955.00},
  {"dim_value":"02","dim_name":"中基人和","metric_value":190104385.00,"share_pct":11.23,...},
  ... 共 6 行 ],
 "truncated":false,"grandTotal":1692973955.00,"appliedFilters":[],"capability":null}
```

---

## 5. 失败语义（必读，含三步处理策略）

| 标记 | 含义 | 正确动作 | 错误动作 |
|---|---|---|---|
| `NO_MATCH` | 查询合法但无数据行（**非值为 0**） | 调整时间窗（区间是否太早 / 太晚）、放宽或去掉过滤；如实告知「该条件无数据」 | 当成 0 汇报；改参数格式反复试 |
| `REJECTED` | 参数非法：维度 / 度量不在白名单、时间格式错、轴未登记 | 按 `message` 修正参数；对照目录核对 `metricId` / `dimensionId` | 原样重试 |
| `UNSUPPORTED_SHAPE` | 覆盖不了该形状：未登记维度组合、不支持的粒度、双桥同分组、`org` 分组叠加 `withTotal` / `mergeOthers` | 按 `message` / `capability` 给出的**可用清单**换维度或粒度 | 重试同样的问题 |
| `AUTH_INCOMPLETE` | 缺用户权限上下文（账号未配置业务数据查看范围） | **引导用户完成授权**；说明系统此时**绝不返回全量数据**；按「权限不足直答」直接给业务化说明 | 认为查询失败；伪造数据；反复调接口后制作演示报表 |
| 有过滤但 `metric_value: null` | 过滤值传错（如抬头传中文名而非代码）——**静默不报错** | 回 `dataDimensionValues` 核对真实取值重试 | 不得当作「无数据」回答用户 |
| `truncated=true` | 达行数上限 | 收窄区间 / 加过滤，或 `topN` 调大（上限 **500**）后重查 | 拿它求和、算占比、称全集 |
| `overlapGroup=true` | 重叠分类（如 `org`） | 各行只单看，占比用「按该维过滤取分子 + 全量作分母」 | 各行相加求总；`withTotal` / `mergeOthers` |
| `additive=false` | 指标不可加 | 重查目标区间不带分组 | 跨期 / 跨维相加 |

> **权限不足单独处理，不进入三步自愈（最高优先）**：`AUTH_INCOMPLETE` / 账号无业务数据查看范围属权限问题，重复调接口拿不到数、输出也没有意义。判定后**立即停止**——不换参重试、不换替代维度、不生成演示报表、不调用渲染脚本、不联想制造数字；直接按 `SKILL.md`「权限不足直答」给一段中文业务化说明（哪些数字给不出 + 为什么 + 系统此时绝不返回全量数据），需要时用一句业务措辞提示先开通查看范围。话术模板见 `output_design.md` §10.1。

> **自愈重试与预算（铁律 8 的唯一例外）**：自愈重试**必须换参数**（禁止原样重发），最多 **2 次**；同一问句含自愈的总调用**不超 4 次**。仍失败才进第三步「引导补充」，且引导**只留给缺用户信息的情况**——能内部修的不引导。用户补充后把新条件并入原问句继续完成查询与输出。**`AUTH_INCOMPLETE` 不走自愈、不占重试预算，一次判定即直答。**

---

## 6. 常见问法 → 四步调用模板（按场景配方索引）

以下模板均先经过步骤 0（场景识别 + 读 `scenes.md` 配方卡）、步骤 1（术语）与步骤 2（目录）。模板是配方卡默认值的**参数级落地**；调用前仍须以 `dataMetricCatalog` 白名单与 `dataDimensionValues` 真实值域为准，冲突时以工具返回为准（`SKILL.md` 铁律 7）。区间示例用 2026-01~09，即 `startYm=202601, endYm=202609`。

**模板 ↔ 场景配方卡对照**（步骤 0 命中场景后，按此表找参数模板）

| 模板 | 对应场景配方卡 | 典型用途 |
|---|---|---|
| A 单点查数（总量） | S1 §1 | 全公司规模、单点问数 |
| B 月度趋势 | S1 §1 | 经营总览时序、预测底稿 |
| C 部门 / 国别 TOP N + 占比 | S3 §3 / S2 §2 | 部门对比、国别排名 |
| D 同比 / 环比 | S1 §1 / S3 §3 / S7 §7 | 增量、下滑、异常 |
| E 按抬头 / 组织 / 国家过滤 | S3 §3 / S2 §2 / S8 §8 | 抬头对比、暴露过滤 |
| F 组织占比（重叠分类） | S2 §2 | 一带一路 / RCEP 占比 |
| G 退税类（注意时间轴） | S6 §6 | 退税到账、周期、结算状态 |
| H 明细面（HS / 品类 / 货源地） | S5 §5 / S7 §7 / S8 §8 | 产品结构、危险品、HS 命中 |
| I 多值过滤 | S8 §8 / 通用 | 多国 / 多 HS 段 / 多运输方式 |

> 配方卡「必读护栏」优先于模板默认参数：例如 S2 的 `org` 重叠分类不得套用 C 的 `withTotal`/`mergeOthers`，须改走 F；S6 的退税内建 `requiredFilters` 不得重复传；S5 的明细面指标不得与主面指标相加。

### A. 单点查数（总量）

```
dataMetricQuery {metricId:"export_usd_amt", startYm:202601, endYm:202609}
→ dimensions 留空 = 全公司总量
```
配套票数：`metricId:"export_ticket_cnt"` 再调一次。问"出口量"默认**双值输出**（票数 + USD）。

### B. 月度趋势

```
dataMetricQuery {metricId:"export_usd_amt", dimensions:["ym"], startYm:202601, endYm:202609}
→ 返回逐月序列；compare:"yoy" 可同时回传 base_value/diff/diff_pct
```

> ⚠️ **实测坑（2026-11-03）**：时间序列默认按 `metric_value` **降序**返回（9 月 232.8M 排第一，不是按月份升序）。**画趋势图前必须按 `dim_value`（yyyyMM）升序重排**，否则折线图月份错乱。

### C. 部门 / 国别 TOP N + 占比

```
dataMetricQuery {metricId:"export_dept_rank", dimensions:["dept"], startYm:202601, endYm:202609,
                 topN:10, order:"desc", withTotal:true, mergeOthers:true}
或  {metricId:"export_usd_amt", dimensions:["destination_country"], withTotal:true, topN:10}
```
国别默认**运抵国** `destination_country`；用 `country`（贸易国）须有明确"交易对手/签约国"语义。

### D. 同比 / 环比

```
// ① 完整月区间：一次查询出同比
dataMetricQuery {metricId:"export_usd_amt", dimensions:["ym"], startYm:202601, endYm:202609,
                 compare:"yoy"}     // 环比用 compare:"mom"，仅 grain=ym

// ② 当前月未完（同期对齐，如当前 2026-11-11）：两次查询 + 本地机械算同比
dataMetricQuery {metricId:"export_usd_amt", grain:"day", startDay:20261101, endDay:20261111, timeAxis:"declaration"}  // 本期
dataMetricQuery {metricId:"export_usd_amt", grain:"day", startDay:20251101, endDay:20251111, timeAxis:"declaration"}  // 去年基期：同月同日起止
// 同比 = (本期 metric_value - 基期 metric_value) / 基期 metric_value
```

> **同期对齐是硬约束（2026-11-11 用户规范，SKILL.md 铁律 15）**：结束于未完整的当前月时，去年基期必须截取到**相同月、相同日起止**，不得用去年整月、不得按天数比例折算。实测 2026-11-11：今年 11.1–11.11 = **76,710,159 USD**、去年同日区间 = **59,600,485 USD** → 同比 **+28.71%**；若误用去年整月 **168,419,276 USD** 会算成 **−54.45%**，结论完全反向。
> ⚠️ **基准缺失兜底**：`compare:"yoy"` 可能返回 `base_value:null / diff:null / diff_pct:null`（去年同期基准不可用）。此时**不得直接放弃**，改走 ② 的按日两次查询取去年同日区间；两次都无数据才在报表如实说明「去年同期数据暂不可比，本次不计算同比」。**不得编造同比数字**，也不要改用别的指标硬凑。

### E. 按抬头 / 组织 / 国家过滤（必须先走步骤 3）

```
① dataDimensionValues {dimensionId:"title", startYm:202601, endYm:202609} → value 是代码 "02"/"05"
② dataDimensionValues {dimensionId:"org"} → value 是中文枚举 "一带一路国家"/"RCEP"
③ dataDimensionValues {dimensionId:"destination_country", search:"美国"} → value "USA"

dataMetricQuery {metricId:"export_usd_amt", startYm:202601, endYm:202609,
                 filters:[{dim:"title", op:"eq", values:["02"]}]}
```

### F. 组织占比（重叠分类，特殊处理）

```
分子：dataMetricQuery {metricId:"export_usd_amt", filters:[{dim:"org",op:"eq",values:["RCEP"]}], ...}
分母：dataMetricQuery {metricId:"export_usd_amt", ... 不带 org 过滤}
或按 org 分组用 export_usd_amt_by_org / export_ticket_cnt_by_org，
但注意 overlapGroup=true，禁止 withTotal/mergeOthers、禁止把各行相加当分母。
票数与金额需两个指标各调一次，由调用端按 dim_value 合并。
```

### G. 退税类（注意时间轴）

```
dataMetricQuery {metricId:"refund_actual_amt", startYm:202601, endYm:202609,
                 timeAxis:"rebate_writeback"}   // 默认轴，看"这段时间到账多少退税"
                 timeAxis:"rebate_period"       // 看"归属于哪一期申报"
读 avg_refund_cycle_days 必须同时读 refund_cycle_coverage（覆盖率仅约 10.8%）。
本类指标内建 requiredFilters: rebate_status=DECLARED，勿重复传。
```

### H. 明细面（HS / 品类 / 境内货源地）

```
dataDimensionValues {dimensionId:"hs_code", search:"8517"}
dataMetricQuery {metricId:"export_item_usd_amt", dimensions:["product_category"],
                 startYm:202601, endYm:202609, topN:10, withTotal:true}
⚠ 明细指标与主表指标不是两个口径而是两个粒度，两者相加没有意义。
⚠ export_item_declared_qty 跨 item_declared_unit 相加无意义，先按单位过滤或分组。
```

### I. 多值过滤（如海运 + 空运）

```
dataDimensionValues {dimensionId:"transport_mode", search:"运输"}  // 拿真实原值，勿猜代码
dataMetricQuery {metricId:"export_usd_amt", filters:[{dim:"transport_mode", op:"eq",
                 values:["水路运输","航空运输"]}], ...}
```

---

## 7. 口径叠加与说明

- 业务如需限定「监管方式白名单」或出口标志，用 `filters` 传 `trade_mode`（**分组/过滤键是中文名称列**，先经 `dataDimensionValues` 取值）；目录里没有独立的进出口标志维，不要臆造参数。
- **字典即事实，禁止常识补正（2026-11-03 用户指令，`SKILL.md` 铁律 9）**：组织枚举名、成员构成、状态值、维度取值一律以平台返回为准，**不得用现实常识补充 / 删减 / 替换，也不得自行推断"应该用什么维度或过滤"**。实测 `dataDimensionValues(org, search:"金砖")` → `cnt:4`；`export_usd_amt` + `dimensions:["destination_country"]` + `filters:[{dim:"org",op:"eq",values:["金砖四国"]}]`（2026H1）返回 **巴西 / 中国 / 俄罗斯联邦 / 印度** 4 行、合计 82,677,569 USD，**无南非**。不得按 BRICS 常识补南非，也不得删 `CHN`。组织口径**原样用 `dim:"org"` 过滤**，不得自行拆成国家代码 IN 列表；成员明细只呈现返回行，不解释"为什么没有某国"。若结果与常识不符，如实呈现并标注"按平台字典口径"，不调整取数重答。
- **过滤维要认面（回归验证 2026-11-03）**：`hs_code` / `hs_code_4` / `hs_code_6` / `product_category` / `product_sub_category` / `domestic_source_region` / `is_dangerous` / `is_hazardous_chemical` 只在 `source=item` 指标（`export_item_usd_amt` / `export_item_line_cnt` / `export_item_declared_qty` 等）的 `filters` 白名单里；用主表 `export_usd_amt` / `export_ticket_cnt` 传这些维会 `REJECTED`。S8 涉 HS 段 / 品类的暴露扫描须改用明细面指标。另 `export_dept_rank` / `export_country_topn` / `export_usd_amt_by_org` / `export_ticket_cnt_by_org` 的 `timeAxes=null` 且 `defaultTimeAxis=null`，**勿传 `timeAxis`**；`export_country_topn` 只登记 `dimensions:["country"]`（贸易国），默认运抵国口径请用 `export_usd_amt` + `dimensions:["destination_country"]`。
- **不自行假设默认过滤**：以 `dataMetricQuery` 回传的 `appliedFilters` 为口径说明依据；指标内建的 `requiredFilters` 会体现在其中。
- 时间轴不同 = 不同批票：同一个 `yyyyMM` 区间打在 `declaration` / `import_export` / `rebate_writeback` / `rebate_period` 上圈出的是四批不同的票，报表须写明本次用的是哪一轴。
- 报表页脚用**业务语言**写明统计区间、时间口径（按申报日期 / 按进出口日期 / 按退税所属期）、统计范围、金额与票数口径、粒度（按报关单 / 按商品明细）、前 N 项说明；**不写连接器名、字段名、失败码、"语义层"、是否截断**（见 `output_design.md` §8、`SKILL.md` 铁律 12）。技术字段与失败码只在本手册内部使用。

---

## 8. 无交互环境的演示模式

> **边界**：有真实用户但无数据权限走「权限不足直答」，不走本档；本档仅限无交互自动化评测环境。

**触发**：数据四工具不可用，且连接打通能力（`workbuddy_request_mcp_connection` / `list_installed_plugins` / `search_plugins` / `suggest_plugin_install` / `reconnect_plugin`）也不可用，或不存在可确认授权的真实用户——常见于自动化评测、离线预览。判定不产生额外工具调用，只看本会话已可用的能力。

**与 §5 的区别**：这不是查询失败，不需要自愈重试，也不进入三步处理；直接分流到演示模式。

**执行**：
1. 按 `SKILL.md`「问句类型 → 输出档」照常判定档位。
2. 文字档：中文说明「当前尚未连接业务数据源，暂时无法给出真实出口数字」+ 本应覆盖的统计范围与口径 + 可继续看的方向；不给编造数字。
3. 报表档：`python assets/gen_report.py assets/demo_report_data.json 出口业务分析演示报表.html` → `present_files`，并说明「以下为演示报表，页面数字为示例值，不是业务统计结果」。演示数据已内置页顶说明、页脚「数据性质」与结论前缀标注。
4. 渲染 / 交付能力也不可用 → 纯中文结构化文字档（结论 → 拆解 → 统计范围 → 延伸引导），不依赖外部工具、不报错、不输出失败码。

**红线**：不得把示例数字写成真实业务结论；不得只回一句「查询失败 / 无法使用」；不得外显工具名、连接状态、失败码、档位判定（铁律 12）；第一句仍是中文业务句（铁律 14）。演示模式只改变数字来源，口径护栏、抬头范围正向列举、同期对齐、业务化页脚与中文结论先行全部不变。

## 9. 性能预算（2026-11-03 优化）

| 项 | 预算 | 说明 |
|---|---|---|
| 工具调用 | **1–3 次 / 问句** | 默认 1 次 `dataMetricQuery`；升级到完整链路才逐步增加 |
| `dataBusinessTerms` | 0 次（默认） | 仅未收录黑话 / 口径歧义时调 |
| `dataMetricCatalog` | 0 次（默认） | 仅快照未覆盖 / `REJECTED` 时调，且必带 `category`；禁止 `{}` 全量（约 65KB） |
| `dataDimensionValues` | 0–1 次 | 仅模糊中文名 / 高基数维 / 需精确代码时调 |
| references 读取 | 0–3 份 | 单点查数不读；**报表档读 `scenes.md`（取配方卡）+ `output_design.md`**；**模板不读**（报表由 `assets/gen_report.py` 渲染，模板是脚本内部资产）；复杂场景才额外查护栏 |
| HTML 生成 | 按需（**非单点查数必生成**） | 仅单点查数直接文字回答、不写文件；整体 / 趋势 / 对比 / 结构 / 排名类必须生成 HTML 报表并 `present_files`，不受性能预算限制（`SKILL.md` 铁律 11） |

**标杆案例**：「一带一路 2026 年上半年出口额」→ 1 次 `dataMetricQuery({metricId:"export_usd_amt", startYm:202601, endYm:202606, filters:[{dim:"org",op:"eq",values:["一带一路国家"]}]})` 即出数（实测 499,515,463 USD，`appliedFilters:["org=一带一路国家"]`），与 `export_usd_amt_by_org` + `["org"]` 分组里同名行逐值一致。组织值「一带一路国家」来自实测快照（`business_terms.md` §4.3），不是猜测。

**稳定性**：同问句必须走同一路径。差异只应来自「是否需要图表」和「是否命中未覆盖问法」，不应来自模型临时决定多读几份文档或多调几次元数据工具。

---

## 10. 主体限定词解析与 appliedFilters 回验（2026-11-03 用户反馈）

**问题**：「2026 年第一季度人和出口多少？」——「人和」是抬头简称（`dataBusinessTerms` 语义库有解释），但回答输出了**全公司**数据。根因是快路径只锁 `metricId` / `dimensions`，没有强制把问句里的主体限定词翻成 `filters`，直接套用了「出口总额」行。

**实测对照（2026Q1 = 202601–202603，`declaration` 轴）**：

| 调用 | `filters` | `metric_value` | `appliedFilters` | 判定 |
|---|---|---|---|---|
| ① 误答 | 留空 | **472,627,272 USD** | `[]` | **全公司** Q1，不是人和 |
| ② 正确 | `[{dim:"title",op:"eq",values:["02"]}]` | **54,988,539 USD** | `["title=02"]` | 人和（02 中基人和）Q1 |
| ③ 传中文名 | `[{dim:"title",op:"eq",values:["中基人和"]}]` | **`null`** | `["title=中基人和"]` | **静默空值**，不报错 |

`dataDimensionValues({dimensionId:"title", startYm:202601, endYm:202603})` 实测返回 `value:"02", name:"中基人和"` —— **`value` 是代码，`name` 才是中文名**；`filters` 必须填 `value`。③ 说明传错值**不会**得到 `REJECTED` / `NO_MATCH`，而是 `metric_value: null`，极易被误判为"无数据"。

**落地规则（`SKILL.md` 铁律 10）**：
1. 问句里的抬头简称 / 全称、部门、委托方、国别、组织、品类、HS、状态一律解析成 `filters`；只有确实没有主体限定词才允许留空。
2. 口语简称先翻成维度真实取值；抬头用**代码**（`人和→02`、`和念→04`、`惠通→05`、`跨境→07`、`初念→08`、`天时→09`）。
3. **「我们 / 公司 / 集团」**（不点名抬头）→ 六抬头白名单 **02/04/05/07/08/13**（2026-11-06 业务确认，**不含 09 天时**）：`filters:[{dim:"title",op:"eq",values:["02","04","05","07","08","13"]}]`，先取 `dataDimensionValues(title)` 值域做**交集**——不在值域的代码（13 心念国际当前未接入）跳过不传，接入后自动纳入；抬头对比或明确说「全部抬头」才用值域全量（含 09）并注明。
4. **出数后核对 `appliedFilters`**：问句有主体却回 `[]` → 过滤未生效，这个数是全公司的，**不得当作该主体答案**，须重查；有过滤但 `metric_value:null` → 多半过滤值传错，回值域工具核对后重查。
5. 回答里**只正向列出本次包含哪些抬头**，统一用「以上统计包含抬头：A（代码）、B（代码）…」（单抬头列 1 个、多抬头逐一列全），不写「公司口径（不含中基天时）」等标签或排除式表述；**`appliedFilters` 核对是内部动作，核对过程、字段名与「已确认生效」之类话术一律不写进回答**（`SKILL.md` 铁律 12、`output_design.md` §1.2）。

**与输出档的关系（`SKILL.md` 铁律 11）**：本题「Q1 人和出口多少」是**单点查数** → 文字档（54,988,539 USD + 拆解 + 统计范围 + 延伸引导，全业务措辞）；若用户改问「人和今年整体出口情况怎么样 / 趋势如何」→ 命中整体 / 趋势，**必须生成 HTML 报表**，不得因性能预算压成纯文字。报表档按步骤 0 读 `scenes.md` 配方卡定指标组合。**档位判定、护栏推理与交付动作均为内部自检，不写进回答**（铁律 12）；报表附文只给业务结论，不描述主题、模板、预览与导出。
