# 指标目录速查

> **权威源 = `dataMetricCatalog` 实时返回**（冲突时以工具为准）。本文件是 2026-11-03 抓取的精炼快照，**默认信任、无需每次调用工具**；仅当快照未覆盖、返回 `REJECTED` / `UNSUPPORTED_SHAPE` 或怀疑目录已更新时，才带 `category` 窄查复核（禁止 `{}` 全量）。
> **命名冲突提醒**：场景设计 HTML《指标体系-按场景拆分设计.html》里的 `metric_id` 是**设计态**命名（如 `export_declaration_cnt`、`item_usd_amt`），与上线态目录不同。取数一律用本文件的 `metricId`。

## 1. 指标速查（26 个）

| metricId | 名称 | 单位 | 分类 | 可加 | 时间粒度 | 默认轴 | 关键口径 /  caveat |
|---|---|---|---|---|---|---|---|
| `export_usd_amt` | 出口美元金额 | USD | 金额 | ✅ | ym/day | declaration | **主金额口径**；全量主面维度可下钻；按组织分组改用 `export_usd_amt_by_org` |
| `export_ticket_cnt` | 出口票数 | 票 | 数量 | ✅ | ym/day | declaration | 每票一行，可加；主表面等值于去重票数 |
| `export_usd_yoy` | 出口金额同比基数 | USD | 金额 | ✅ | ym | — | 同比由 `compare=yoy` 对上年同区间求比，不要自己算 |
| `export_ticket_yoy` | 出口票数同比基数 | 票 | 数量 | ✅ | ym | — | 同上 |
| `export_amt_share` | 出口金额占比基数 | USD | 占比/环比 | ✅ | ym | — | 占比 = 组值 / 同口径总值；用 `withTotal=true` 直接回传 `share_pct`/`grand_total` |
| `export_amt_mom` | 出口金额环比基数 | USD | 占比/环比 | ✅ | ym | — | 环比由 `compare=mom`（仅 grain=ym） |
| `export_dept_rank` | 部门出口排行 | USD | 排行 | ✅ | ym/day | — | `dimensions:["dept"]` + 降序 + `topN` |
| `export_country_topn` | 国家出口 TOP-N | USD | 排行 | ✅ | ym | — | `dimensions:["country"]`；占比/其他合并靠 `withTotal`/`mergeOthers` |
| `export_gross_weight` | 出口毛重 | KG | 重量 | ✅ | ym/day | declaration | 可跨维求和 |
| `export_net_weight` | 出口净重 | KG | 重量 | ✅ | ym/day | declaration | 可跨维求和 |
| `export_deal_amt` | 出口成交币种金额 | 成交币种 | 金额 | ✅ | ym/day | declaration | ⚠ **不可与美元金额相加或混算**；跨币种对比用 `export_usd_amt` 并按 `declared_currency` 分组/过滤 |
| `export_package_qty` | 出口包装件数 | 件 | 数量 | ✅ | ym/day | declaration | 主表 `package_qty`，实测全表非空无负值 |
| `export_usd_amt_coverage` | 金额非空票数（数据质量） | 票 | 数据质量 | ✅ | ym/day | — | 与 `export_ticket_cnt` 比较得**金额覆盖率**；未解析金额的票不得当作 0 金额解读 |
| `export_ticket_cnt_by_org` | 各组织出口票数 | 票 | 数量 | ✅ | ym | — | 按 `org` 下钻；**overlapGroup=true**，`withTotal`/`mergeOthers` 被拒；票数按单据去重 |
| `export_usd_amt_by_org` | 各组织出口美元金额 | USD | 金额 | ✅ | ym | — | 同上；默认按运抵国关联；**各行之和 ≠ 总量** |
| `refund_actual_amt` | 实际退税金额 | CNY | 金额 | ✅ | ym/day | **rebate_writeback** | 内建 `rebate_status=DECLARED`；看归属期传 `timeAxis=rebate_period`；**不可与美元相加** |
| `avg_refund_cycle_days` | 平均退税回填周期 | 天 | 周期 | ❌ | ym | **rebate_period** | ⚠ **必须与 `refund_cycle_coverage` 同读**（有效样本仅约 10.8%）；不可跨期相加 |
| `refund_cycle_coverage` | 退税周期覆盖票数 | 票 | 数据质量 | ✅ | ym | rebate_period | 上者的分母，用于披露覆盖率，不是业务量 |
| `export_inspection_rate` | 出口查验率 | % | 数据质量 | ❌ | ym/day | — | `avg(inspected_flag)`，实测整体 0.30%（小比率）；分组后大量 0 与空组，**不可把各组的率相加** |
| `avg_declaration_amt` | 单票平均出口金额 | USD/票 | 均值/比率 | ❌ | ym/day | — | 分母为去重票数；**不可跨分组相加**；占比/排行用 `export_amt_share`，同比用 `compare=yoy` |
| `client_avg_export_amt` | 客户均出口金额 | USD/个 | 均值/比率 | ❌ | ym/day | — | 分母 `count(distinct principal_client_code)` 不可跨期/跨维相加；整体均值请重查不带分组 |
| `export_item_usd_amt` | 出口商品项美元金额 | USD | 金额 | ✅ | ym/day | declaration | **明细面**；与 `export_usd_amt` 是两个**粒度**不是两个口径，相加无意义；需要 HS/类目/货源地才用它 |
| `export_item_line_cnt` | 出口商品项行数 | 行 | 数量 | ✅ | ym/day | declaration | 是「商品行数」不是票数；一票多行，与 `export_ticket_cnt` 从不相等 |
| `export_item_declared_qty` | 出口商品申报数量 | 申报数量 | 数量 | ✅ | ym/day | declaration | ⚠ 单位随 `item_declared_unit` 变，**跨单位相加无意义**；先按单位过滤或分组 |
| `avg_items_per_declaration` | 票均商品行数 | 行/票 | 均值/比率 | ❌ | ym/day | declaration | 率不可加；配合 `export_item_line_cnt` 与 `export_ticket_cnt` 一起读更稳 |
| `avg_item_unit_price` | 商品行均价 | 成交币种 | 均值/比率 | ❌ | ym/day | declaration | ⚠ 必须先把 `item_currency` 过滤到单一币种（或按它分组）；是「行价的平均」非「总额÷总量」 |

**分类 key**：`amount` 金额 / `volume` 数量 / `weight` 重量 / `share` 占比·环比 / `rank` 排行 / `quality` 数据质量 / `cycle` 周期 / `ratio` 均值·比率。

---

## 2. 维度清单（按用途分组）

### 时间维（分组 / 序列）
| dimensionId | 名称 | 说明 |
|---|---|---|
| `year` / `quarter` / `ym` | 年份 / 季度 / 月份 | 放进 `dimensions` 出年/季/月序列，配 `startYm`/`endYm` |
| `day` | 申报日 | `grain=day` 时用，配 `startDay`/`endDay`；**同比同期对齐取去年同日区间基期也用它**（`compare` 仅 ym，故须两次查询） |

### 主体维
| dimensionId | 名称 | 关键说明 |
|---|---|---|
| `dept` | 统一部门 | **行级权限轴**，由 `business_department_code` 关联维表产出，未匹配归 `UNASSIGNED`；与单据自带部门不同轴。synonyms：部门/业务部门/出口部门 |
| `business_department` | 单据业务部门 | 报关单原值（实测 21 个 code 与名称 1:1），与权限轴 `dept` **不等价** |
| `consignor` | 委托方（客户） | `sensitive=true`：键用 `principal_client_code`，**只返回代码/简称不返回注册全称**；代码缺失归 `UNKNOWN`；去重计数用 `distinct_client_cnt`。synonyms：委托方/客户/发货客户 |
| `overseas_consignee` | 境外收货人 | `sensitive=true`；**高基数文本列、未做名称归一**，同名异体写法会被数成多个 |
| `title` | 公司抬头 | 键用 `company_entity_code`（**禁止用名称关联**），展示名 `short_name`；工商全称只作搜索匹配列。synonyms：抬头/公司抬头/签约主体 |

### 地理维
| dimensionId | 名称 | 关键说明 |
|---|---|---|
| `country` | 贸易国家/地区 | 贸易国；英文名只作搜索入口（matchColumns），不另开英文名维。synonyms：贸易国/贸易伙伴/国家 |
| `destination_country` | 运抵国家/地区 | **出口国别统计默认口径**（数据质量更高）；`org` 桥维默认按本列关联。synonyms：运抵国/目的国 |
| `continent` | 运抵国大洲 | 视图列 `destination_country_continent`（实际列名带前缀）。synonyms：大洲/洲/洲区 |
| `exit_port` | 离境口岸 | 实测 257 个 code。synonyms：离境口岸/出境口岸/口岸 |
| `destination_port` | 指运港 | 实测 838 值；**源列名为 code 但存中文名**（字段命名错位）。synonyms：指运港/目的港 |
| `domestic_source_region` | 境内货源地 | 明细面；与离境口岸是不同实体（货源地=哪里生产，口岸=哪里出境）。synonyms：货源地/产地 |

### 贸易属性维
| dimensionId | 名称 | 关键说明 |
|---|---|---|
| `trade_mode` | 监管方式（贸易方式） | ⚠ **分组/过滤键是中文名称列，不是代码列**（代码列约 36% 为 NULL）；代码列只开给值域搜索（按 "0110"/"9710" 能回中文名称行）。synonyms：监管方式/贸易方式/9710/跨境B2B |
| `tax_exemption_type` | 征免性质 | 实测 8 个取值，含「跨境B2B」；空值 11 行 |
| `transport_mode` | 运输方式 | 实测 14 值；⚠ 混有「保税港区/监管仓库/物流园区」等非运输方式取值（约 1.3 万行），且「其它运输/其他方式运输」并存；**多值查询用原值，不要猜代码** |
| `incoterm` | 成交方式 | 实测仅 `FOB`/`C&F`/`CIF`/`EXW` 四值。synonyms：成交方式/FOB/CIF/C&F/EXW |
| `declared_currency` | 申报币种 | 实测 9 值；与 `deal_amt` 原币金额配对使用 |
| `package_type` | 包装种类 | 实测 30 值，含「其他包装/其它/其他」同义写法；件数用 `package_qty` |
| `item_currency` | 商品项币制 | 明细面 ISO 4217；**与主表 `declared_currency` 是两个列**（头币制不约束行币制） |
| `item_declared_unit` | 商品项申报单位 | 明细面；`export_item_declared_qty` 跨单位相加无意义，用本维过滤或分组 |

### 状态维
| dimensionId | 名称 | 实测取值 |
|---|---|---|
| `settlement_status` | 结汇状态 | `SETTLED` / `UNSETTLED` / `PENDING_CONFIRM` / `PROVISIONAL` / `RETURNED` |
| `rebate_status` | 退税申报状态 | `DECLARED`(469,286) / `NOT_DECLARED`(34,704) / `PENDING_DECLARATION`(4,715)；退税金额类度量口径靠指标 `requiredFilters` 内建 |

### 商品明细维（仅 `source=item` 指标可用）
| dimensionId | 名称 | 关键说明 |
|---|---|---|
| `hs_code` | HS 编码（10 位） | **高基数，值域工具必须带 `search`**；商品名称只作搜索入口，不单独成维（同名可挂多税号） |
| `hs_code_4` | HS 章（前 4 位） | 与 `product_category` 是**两套归集体系**，不可互推互相核对 |
| `hs_code_6` | HS 六位（国际通行） | 产品「商品大类」按前缀归集依赖此列 |
| `product_category` / `product_sub_category` | 商品一级 / 二级类目 | 源 `t_hgsh_code4` 归集结果，非 HS 前缀；小类只在大类内有层级意义，交叉用 `[product_category, product_sub_category]` |
| `is_dangerous` | 危险品标记 | 0/1；明细行级 ⇒ 按它分组统计单位是**商品行数/明细金额，不是票数** |
| `is_hazardous_chemical` | 危化品标记 | 0/1；与 `is_dangerous` 是包含而非等价（危化品是危险品子集），不可混用或相加 |

### 单据号 / 日期过滤维（只做过滤，不进分组）
| dimensionId | 名称 | 关键说明 |
|---|---|---|
| `declaration_no` | 报关单号（主面） | 每票一行、全表唯一；值大小写敏感，须原样精确值 |
| `declaration_no_item` | 报关单号（明细面） | 与主面 `declaration_no` 同一物理列的面级别名；eq 定位该票全部商品行 |
| `internal_invoice_no` / `export_invoice_no` | 内部发票号 / 外销发票号 | 与报关单实测 1:1，eq 即定位单票；值须精确 |
| `contract_no` | 外销合同号 | ⚠ **1:N**（一个合同号最多覆盖 221 票），过滤得到的是一批票的合计，不是单票 |
| `rebate_declaration_period` | 退税申报所属期 | 原文 `YYYY-MM`；**本维只做过滤**，按月分组用 `rp_ym` 复合键；空值在源表为 NULL |
| `declaration_date` / `import_export_date` / `rebate_writeback_date` | 申报 / 进出口 / 退税申领回填日期 | 区间过滤，`ops` 含 `between`；分组请用时间维 + `grain` |
| `principal_client_approval_date` | 委托方审批日期 | 只作过滤维、不做度量时间轴 |

### 关联维（viaJoin=bridge，重叠分类）
| dimensionId | 名称 | 关键说明 |
|---|---|---|
| `org` | 组织（国家分组） | **`overlap=true`**：一国可属多个组织，按它分组各行之和 ≠ 总量；取值是全局字典、不经权限收窄；`startYm/endYm` 对它无效；占比改用「按 org 过滤取分子 + 不带 org 过滤的全量作分母」 |

---

## 3. 时间轴（4 条，`timeAxis` 参数）

| axisId | 名称 | 粒度 | 语义 |
|---|---|---|---|
| `declaration` | 申报日期 | ym/day | **默认轴**，也是 DWS 预聚合唯一折叠过的轴；存量口径与对平基线以此为准 |
| `import_export` | 进出口日期 | ym/day | 实际放行/离境日期；与申报日一般差数日。「货什么时候出去」用它 |
| `rebate_writeback` | 退税申领回填日期 | ym/day | 「这段时间实际办结/到账多少退税」；未回填行本列 NULL，按它圈窗只看已回填那批票 |
| `rebate_period` | 退税申报所属期 | **仅 ym** | 「这批所属期的申报退得多快/多少」；所属期本身月粒度、**不开放 day**（带 `grain=day` 会被拒）；空所属期行被排除 |

> 同一 `yyyyMM` 区间打在不同轴上圈出的是**四批不同的票**，报表必须标注本次用的是哪一轴。

---

## 4. 度量要点（护栏）

- `usd_amt`（USD）：唯一可跨币种相加的金额度量；**NULL 不置 0**，金额覆盖率用 `usd_amt_covered_cnt` 标注。
- `ticket_cnt`（票）：DWD 每票一行恒 1，跨任意维度求和不会重复计数。
- `distinct_ticket_cnt`（单据去重票数）：**关联维（桥表）分组下的唯一正确票数口径**；`sum(ticket_cnt)` 在组织分组会按成员多重度重复放大（单国最多属 5 个组织）。
- `distinct_client_cnt` / `distinct_consignee_cnt` / `distinct_trade_country_cnt`：去重计数，**不可跨期/跨维相加**（同一客户两个月各一行相加会把 1 数成 2）；需要跨期总数必须重查目标区间。
- `actual_refund_amt`（CNY）：仅 `rebate_status=DECLARED` 行有值，其他为 NULL，不要自行把空值当 0。
- `item_usd_amt`（明细 USD）：与 `usd_amt` 是包含关系（明细之和对平主表值），**两者相加没有意义**。
- `item_declared_qty`：`item_declared_unit` 变则跨单位相加无意义。
- `refund_cycle_days_avg`：负值已置 NULL 不进分母，覆盖率约 10.8%；**禁止用 GREATEST(0,…) 钳零**（会把均值抹成 1.26 天假结论）。
- `inspected_rate`：0/1 列均值即查验票数/总票数，分组后大量 0 与空组，不可按可加度量相加。
- `item_unit_price_avg`：成交币种的行价算术平均，跨币种无意义、大小批量行同权。

---

## 5. 选指标决策树

```
要金额 → 主表默认 export_usd_amt（USD，可比）
        └ 要按 HS/品类/货源地拆 → export_item_usd_amt（明细面）
要票数 → export_ticket_cnt
        └ 按组织(org)分组 → export_ticket_cnt_by_org（金额配套 export_usd_amt_by_org）
要占比/排名 → export_amt_share / export_dept_rank / export_country_topn（或通用指标 + withTotal/topN）
要同比/环比 → 完整月用通用指标 + compare=yoy/mom；当前月未完按日同期对齐，两次真实查询后本地机械算同比（见 tool_workflow §4 D / SKILL.md 铁律 15）
要退税 → refund_actual_amt（金额，CNY）/ avg_refund_cycle_days + refund_cycle_coverage（周期，成对读）
要数据质量 → export_usd_amt_coverage / export_inspection_rate
要重量件数 → export_gross_weight / export_net_weight / export_package_qty
要客户均值 → client_avg_export_amt（注意 additive=false）
```
