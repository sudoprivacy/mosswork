# -*- coding: utf-8 -*-
"""违约概率模型评估器（gmai-pd-lgd-model-ee13）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：模型合规性核查表（样本代表性、违约定义一致性）；区分度与校准度评估（AUC、KS、二项检验）；回溯测试结论与模型改进建议
建议输入（专业字段）：测算对象
"""
import json, os, re, sys, time

SLUG = "gmai-pd-lgd-model-ee13"
TITLE = "违约概率模型评估器"
PRICE_FEN = 1990
CATEGORY = "金融风控与反洗钱"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['测算对象', True, ['对象', '项目', '测算事项'], '明确测算的业务对象与边界'], ['期间', False, ['会计期间', '年度', '月份'], '决定口径与同期比较基准'], ['收入/规模', False, ['营业收入', '收入', '规模', '营业额'], '费率类项目的计算基数'], ['适用税率', False, ['税率', '征收率', '费率'], '用于税负与费率测算'], ['成本项', False, ['成本构成', '费用项'], '分项成本的原始数据']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'items': [['人工审核成本', 0.006, '按风险敞口比例估算的审核人力投入'], ['欺诈损失（现状）', 0.018, '按历史欺诈率估算的资金损失'], ['缓释措施投入', 0.004, '规则引擎、名单库与监控投入'], ['客户体验成本', 0.002, '误拦截带来的流失与补偿'], ['合规与报告成本', 0.001, '可疑交易报告与合规人力']], 'assumptions': ['敞口与损失率按历史区间估算，实际以账面与系统数据为准', '未考虑一次性整改与外部审计费用', '规则上线前须经独立验证与回溯测试']}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['《企业会计准则》收入确认与成本配比原则', '增值税一般计税与简易计税的适用情形（按纳税人类型判定）', '成本费用列支的真实性与相关性要求（税前扣除凭证）', '毛利率与净利率口径：均按不含税收入计算', '敏感性分析惯例：对收入与成本各做 ±10% 情景测算']
# 自检项（输入完备度）
CHECKS = [['违约概率模型评估·业务与风险盘点', ['违约概率模型评估', '按违约概率'], '先明确业务类型、风险敞口与数据可得性'], ['违约概率模型评估·指标与规则设计', ['按违约概率', '验证与回溯测试'], '按真实计量口径设计指标、规则与阈值并说明假设'], ['违约概率模型评估·模型与验证', ['验证与回溯测试', '违约概率模型评估器'], '核对样本代表性、区分度指标与回溯测试结果'], ['违约概率模型评估·合规红线', ['违约概率模型评估器', '违约概率模型评估'], '识别协助掩饰资金来源等违规情形，命中即终止'], ['违约概率模型评估·管理动作交付', ['违约概率模型评估', '按违约概率'], '输出监测、上报与整改的管理动作清单']]
# 交付物构成
DELIVERABLES = ['模型合规性核查表（样本代表性、违约定义一致性）', '区分度与校准度评估（AUC、KS、二项检验）', '回溯测试结论与模型改进建议']
FOOTER = "本报告不构成投资或合规结论；不协助规避监管；模型上线前须独立验证。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """财税/成本测算交付物：口径假设 → 分项测算 → 关键指标 → 敏感性 → 合规凭据 → 风险提示"""
    P = ctx["spec"]["params"]; L = []
    obj = ctx["fv"]("测算对象") or ctx["spec"]["title"]
    period = ctx["fv"]("期间")
    rev = ctx["nm"]("收入/规模")
    taxrate = ctx["nm"]("适用税率")
    items = P.get("items") or []          # [[项目, 取值(数), 口径说明], ...]
    assumptions = P.get("assumptions") or []

    total = 0.0
    has_num = False
    for x in items:
        v = ctx["nm"](x[0])
        if v is None:
            v = x[1]
        if isinstance(v, (int, float)):
            total += float(v)
            has_num = True

    L.append(("一、测算口径与假设", [
        "- 测算对象：%s" % brief(obj, 50),
        "- 测算期间：%s" % (brief(period, 30) or "（未提供，默认按单个完整年度口径）"),
        "- 计量口径：人民币元，不含/含税口径需在下列分项中逐项标注；金额保留两位小数。",
        "- 收入/规模基数：%s" % (fmt(rev) if rev is not None else "（未提供，无法给出金额级结论，以下按费率口径列示）"),
        "",
        "**口径假设**（如有出入，请修正输入后重跑，结果随输入变化）：",
        "",
    ] + ["- %s" % a for a in assumptions[:8]]))

    rows = ["| 序号 | 项目 | 取值/费率 | 金额（元） | 计算过程 |", "|---|---|---|---|---|"]
    for i, x in enumerate(items, 1):
        v = ctx["nm"](x[0])
        if v is None:
            v = x[1]
        amt = ""
        if rev is not None and isinstance(v, (int, float)) and abs(v) < 1.0 and v != 0:
            amt = "{:,.2f}".format(rev * float(v))
            proc = "%s × %s" % (fmt(rev), ("{:.2%}".format(float(v))))
        elif isinstance(v, (int, float)):
            amt = "{:,.2f}".format(float(v))
            proc = "按输入值直接计入"
        else:
            amt = "待补充"
            proc = "需提供取值"
        rows.append("| %d | %s | %s | %s | %s |" % (i, x[0], (fmt(v) if isinstance(v, (int, float)) else str(v)), amt, proc))
    if not items:
        rows.append("| 1 | 待补充测算项 | — | — | 依业务模型补充成本/收入项 |")
    rows.append("| — | **合计** | — | %s | 各分项加总 |" % ("{:,.2f}".format(total) if has_num else "待补充"))
    L.append(("二、分项测算表", rows))

    ind = ["| 指标 | 数值 | 计算口径 |", "|---|---|---|"]
    if rev and total:
        gross = rev - total
        ind.append("| 毛利/净收益 | {:,.2f} 元 | 收入 − 合计成本 |".format(gross))
        ind.append("| 利润率 | {:.2%} | 毛利 ÷ 收入 |".format(gross / rev))
    else:
        ind.append("| 利润率 | 待补充 | 需同时提供收入与成本 |")
    if rev and taxrate is not None:
        ind.append("| 税负测算 | {:,.2f} 元 | 收入 × 适用税率 {:.2%} |".format(rev * taxrate, taxrate))
    ind.append("| 成本收入比 | %s | 合计成本 ÷ 收入 |" % ("{:.2%}".format(total / rev) if (rev and total) else "待补充"))
    L.append(("三、关键指标", ind))

    sens = ["| 情景 | 收入变动 | 成本变动 | 利润（元） | 利润率 | 说明 |", "|---|---|---|---|---|---|"]
    if rev and total:
        for name, dr, dc in (("基准", 0, 0), ("收入 −10%", -0.10, 0), ("成本 +10%", 0, 0.10), ("双向不利", -0.10, 0.10)):
            r2 = rev * (1 + dr); c2 = total * (1 + dc)
            g2 = r2 - c2
            sens.append("| %s | %+d%% | %+d%% | %s | %s | 利润对收入更敏感时优先保收入 |" % (
                name, round(dr * 100), round(dc * 100), "{:,.2f}".format(g2), "{:.2%}".format(g2 / r2 if r2 else 0)))
    else:
        sens.append("| 基准 | — | — | 待补充 | — | 补齐收入与成本后自动生成 |")
    L.append(("四、敏感性分析", sens))

    L.append(("五、合规要点与凭证", [
        "| 要点 | 要求 | 凭证 |", "|---|---|---|",
        "| 计税/核算依据 | 按适用税率与征收口径计算，注明依据文件与生效时间 | 政策文件、纳税申报表 |",
        "| 成本列支 | 与收入配比、凭证齐全、真实性可追溯 | 发票、合同、付款凭证 |",
        "| 凭证留存 | 按备查要求保存完整链条 | 台账与原始件 |",
        "| 差异说明 | 与申报或审计口径不一致的，逐项说明原因 | 差异调节表 |",
    ]))

    L.append(("六、风险提示", [
        "- 本测算基于所提供的输入与假设，输入变化将直接改变结论；正式申报前应以账面数据复核。",
        "- 涉及税率适用、优惠资格与跨境税务的判定，须以现行有效文件与主管口径为准。",
        "- 不得用于虚构业务、拆分收入或伪造凭证等违规目的；如输入中出现此类诉求，本技能不予处理。",
        "- 本测算为作业参考，**不构成税务意见或投资建议**；重大安排请由持证税务师、会计师或投资顾问复核后执行。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
