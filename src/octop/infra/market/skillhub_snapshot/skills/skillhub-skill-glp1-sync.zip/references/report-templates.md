# Report Templates

## User Weekly Report

Use a warm, nonjudgmental tone. Do not over-focus on weight loss speed.

Sections:

1. One-sentence summary.
2. Weight trend.
3. Body signals and adverse reactions.
4. Food and nutrition observations.
5. Exercise/body state.
6. Sleep, mood, and life scenes.
7. Real medication-use record.
8. Next week's 1-3 small goals.
9. Questions worth asking a doctor/pharmacist.

Example summary:

"这一周你不是'做得不够'，而是在适应药物带来的食欲和身体变化。比起某一天的体重，更值得看的是哪些信号开始变得可观察。"

## Weekly Report Data

- week_number
- period_start / period_end
- weight_record_days
- week_start_weight
- week_end_weight
- weekly_change_kg
- baseline_to_now_change_kg
- baseline_to_now_change_percent
- main_symptoms
- symptom_days_count
- max_gi_symptom_level
- protein_quality_summary
- hydration_summary
- exercise_days
- strength_training_days
- sleep_stress_summary
- usage_deviation_events
- risk_events

## Doctor/Pharmacist Summary

Use objective, concise language. Avoid emotional judgment. State that AI did not provide diagnosis, prescription, or dose-adjustment advice.

Sections:

1. Basic information: height, baseline/current weight, BMI if available, comorbidities, other medications.
2. Medication information: brand/generic, start date, injection day, prescribed plan text, actual usage pattern.
3. Weight trend: period, records, current change, plateau/fluctuation.
4. Symptoms/adverse reactions: type, frequency, severity, duration, impact on food/water/life.
5. Real usage deviations: missed/delayed/self-increase/self-decrease/stopped/switched, reason, symptom context.
6. Food, exercise, sleep, stress observations.
7. User questions: 3-5 prioritized questions.
8. Boundary note.

Boundary note:

"本摘要由用户自述记录自动整理，仅用于辅助医生/药师了解近期情况。AI 未提供诊断、处方或具体剂量调整建议。请以医生/药师判断为准。"

## Risk Event Summary

Use for yellow/orange/red events.

Fields:

- event_type
- medication_brand
- event_date_time
- main_symptom_or_action
- severity
- duration
- impact_food_water
- impact_daily_life
- red_flags_checked
- risk_level
- suggested_action_summary

For red events, prioritize urgent-care guidance over normal reporting.
