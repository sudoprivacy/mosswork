# Data Schema

Use these fields when extracting records, designing forms, or producing backend payloads.

## Profile Fields

P0:

- user_id
- nickname
- has_prescription
- consent_privacy
- consent_health_record
- medication_brand: 诺和盈 | 穆峰达 | 信尔美 | 先维盈 | 其他
- medication_generic: 司美格鲁肽 | 替尔泊肽 | 玛仕度肽 | 埃诺格鲁肽 | 其他
- start_date
- current_week
- injection_day
- prescribed_plan_text
- actual_usage_pattern
- height_cm
- baseline_weight_kg
- baseline_bmi
- weight_related_comorbidities
- diabetes_status
- current_other_meds
- preferred_checkin_time

P1:

- baseline_waist_cm
- target_weight_kg
- medication_source
- follow_up_date
- pregnancy_lactation_plan
- gallbladder_history
- pancreatitis_history
- tone_preference
- recording_style

## Daily Check-In Fields

P0:

- record_date
- weight_kg
- appetite_level: 0-5
- gi_symptom_level: 0-5
- main_symptoms: nausea, vomiting, reflux, constipation, diarrhea, bloating, abdominal_pain, dizziness, fatigue
- meals_summary
- mood_energy: 0-5
- free_note

P1:

- protein_quality
- hydration
- vegetable_fiber
- meal_pattern: skipped_meal, small_frequent_meals, eating_out, social_meal, alcohol, late_night
- exercise_type
- exercise_duration_min
- strength_training_done
- steps
- sleep_quality
- stress_level
- social_scenario

## Event Records

### Usage Deviation Event

- event_type: missed | delayed | early | self_increase | self_decrease | stopped | switched | uncertain
- event_date
- medication_brand
- prescribed_plan_snapshot
- actual_action_text
- reason
- symptom_context
- red_flags_checked
- risk_level
- professional_contact_needed
- doctor_question_generated

### Symptom Event

- symptom_type
- severity: mild | moderate | severe | unknown
- duration_hours
- impact_level
- hydration_or_food_intake
- red_flags_checked
- risk_level
- follow_up_time

## Live Turn Payload

```json
{
  "visible_reply": "",
  "scene": "",
  "risk_level": "green",
  "fields_to_record": {},
  "red_flags_checked": [],
  "needs_follow_up": false,
  "follow_up_time": null,
  "doctor_question_candidate": [],
  "boundary_notes": []
}
```

## Minimal Data Philosophy

Ask the fewest fields needed for the scene. One daily check-in should normally ask one question and at most 2-3 follow-ups. Allow "skip" and "light record" modes.
