#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPT一键生成 · 主引擎（gen_pptx.py）
==================================
spec 驱动，一键产出可编辑 .pptx：12 种版式 + 6 种原生图表 + 7 种矢量图示 + 5 套主题 + 进入动画。

用法：
  python3 gen_pptx.py spec.json -o deck.pptx
  python3 gen_pptx.py --demo -o demo.pptx          # 全能力演示（12 版式全跑一遍）
  python3 gen_pptx.py spec.json --theme finance    # 覆盖 spec 里的主题

spec 格式（JSON）：
  {"theme": "business", "title": "季度经营汇报", "slides": [ {...页...}, ... ]}

报错原则：每条错误都指明「第几页、什么版式、哪个字段、该怎么改」，不出无头技术报错。
"""
import json
import os
import sys

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt, Emu

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_assets          # noqa: E402
import animations          # noqa: E402

# ───────── 合规词库（与 sensitive-words.md 同源，check/verify 共用） ─────────
DICT_CANDIDATES = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "sensitive-words.md"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "references", "sensitive-words.md"),
]

def load_dict():
    """加载完整词库（「词||等级||改法」）。找不到返回 (None, [])——绝不静默放行。"""
    for p in DICT_CANDIDATES:
        if os.path.exists(p):
            rules = []
            for line in open(p, encoding="utf-8"):
                line = line.strip()
                if not line or line.startswith("#") or line.startswith(">"):
                    continue
                parts = line.split("||")
                if len(parts) >= 2 and parts[1].strip() in ("HARD", "SOFT"):
                    rules.append((parts[0].strip(), parts[1].strip(),
                                  parts[2].strip() if len(parts) > 2 else ""))
            return os.path.normpath(p), rules
    return None, []

def collect_texts(prs):
    """收集整片所有文本（含图表标题区之外的 shape 文本），返回 [(页码, 文本)]。"""
    out = []
    for i, sld in enumerate(prs.slides, 1):
        for sh in sld.shapes:
            if sh.has_text_frame:
                t = sh.text_frame.text.strip()
                if t:
                    out.append((i, t))
    return out

# ───────────────────────── 主题（与 templates.md 一致） ─────────────────────────
GOLD = "F2CB57"                                 # 家族统一强调金
INK, SUB, PAPER = "1A1A1A", "555555", "F4F6F8"

THEMES = {
    "business": {"name": "商务蓝", "primary": "0E5A8A",
                 "palette": ["0E5A8A", GOLD, "2E86C1", "E67E22", "16A085", "C0392B"]},
    "tech":     {"name": "科技紫", "primary": "3B2A77",
                 "palette": ["3B2A77", "7C5CFF", "00C2D1", "FF6FB5", "2D98DA", "F8B500"]},
    "finance":  {"name": "财经绿", "primary": "0B5E3B",
                 "palette": ["0B5E3B", GOLD, "1E8449", "C7A317", "117A65", "B9770E"]},
    "mono":     {"name": "极简黑", "primary": "111111",
                 "palette": ["111111", GOLD, "444444", "888888", "2C3E50", "E74C3C"]},
    "edu":      {"name": "教育橙", "primary": "C2681B",
                 "palette": ["C2681B", GOLD, "E67E22", "16A085", "2E86C1", "8E44AD"]},
}

LAYOUTS = ["cover", "toc", "section", "content", "two_column", "image_text",
           "chart", "diagram", "timeline", "quote", "stat", "closing"]
CHART_TYPES = {"column": XL_CHART_TYPE.COLUMN_CLUSTERED, "bar": XL_CHART_TYPE.BAR_CLUSTERED,
               "line": XL_CHART_TYPE.LINE_MARKERS, "pie": XL_CHART_TYPE.PIE,
               "doughnut": XL_CHART_TYPE.DOUGHNUT, "area": XL_CHART_TYPE.AREA}
DIAGRAM_TYPES = ["flow", "org", "swot", "pyramid", "venn", "cycle", "funnel"]

FONT_NAME = "微软雅黑"
PAGE_W, PAGE_H = Inches(13.333), Inches(7.5)
MARGIN = 0.9                                     # 统一边距 in
GOLD_BAR_H = 0.12
FOOTER_H = 0.42


class SpecError(Exception):
    """带修复指引的规格错误：消息即答案。"""


def _need(slide, field, example, idx):
    if not slide.get(field):
        raise SpecError(
            "第 %d 页（%s 版式）缺字段「%s」。\n"
            "  改法：加上 \"%s\": %s\n"
            "  示例：%s" % (idx, slide.get("layout", "?"), field, field,
                            json.dumps(example, ensure_ascii=False),
                            json.dumps({**slide, field: example}, ensure_ascii=False)[:160]))


def _rgb(h):
    return RGBColor.from_string(h.lstrip("#").upper())


def _set_run(run, text, size, color, bold=False, italic=False):
    run.text = text
    f = run.font
    f.size = Pt(size)
    f.bold = bold
    f.italic = italic
    f.color.rgb = _rgb(color)
    f.name = FONT_NAME
    rPr = run._r.get_or_add_rPr()                # 东亚字体
    ea = rPr.find(qn("a:ea"))
    if ea is None:
        ea = rPr.makeelement(qn("a:ea"), {})
        rPr.append(ea)
    ea.set("typeface", FONT_NAME)


def _text(slide, x, y, w, h, lines, anchor=MSO_ANCHOR.TOP):
    """lines: [(text, size, color, bold, align, space_after_pt), ...] 或单段。"""
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    if isinstance(lines, tuple):
        lines = [lines]
    first = True
    for text, size, color, bold, align, after in lines:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        first = False
        p.alignment = align
        p.space_after = Pt(after)
        _set_run(p.add_run(), text, size, color, bold)
    return box


def _rect(slide, x, y, w, h, fill=None, line=None, line_w=None, shape=MSO_SHAPE.RECTANGLE,
          shadow=False):
    sp = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill is None:
        sp.fill.background()
    else:
        sp.fill.solid()
        sp.fill.fore_color.rgb = _rgb(fill)
    if line is None:
        sp.line.fill.background()
    else:
        sp.line.color.rgb = _rgb(line)
        sp.line.width = Pt(line_w or 1)
    sp.shadow.inherit = False
    sp.text_frame.word_wrap = True
    return sp


def _shape_text(sp, text, size, color="FFFFFF", bold=True):
    tf = sp.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf.margin_left = tf.margin_right = Pt(4)
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    _set_run(p.add_run(), text, size, color, bold)


# ───────────────────────── 页面公共骨架 ─────────────────────────
def _chrome(slide, theme, page_no, total, deck_title):
    """页眉金条 + 页脚色带（封面/结尾/章节/金句不加）。"""
    _rect(slide, 0, 0, 13.333, GOLD_BAR_H, fill=GOLD)
    _rect(slide, 0, 7.5 - FOOTER_H, 13.333, FOOTER_H, fill=PAPER)
    _text(slide, MARGIN - 0.3, 7.5 - FOOTER_H + 0.03, 6, 0.35,
          ((deck_title or "", 10, SUB, False, PP_ALIGN.LEFT, 0)))
    _text(slide, 12.0, 7.5 - FOOTER_H + 0.03, 1.0, 0.35,
          ("%d / %d" % (page_no, total), 10, SUB, False, PP_ALIGN.RIGHT, 0))
    _rect(slide, 0, 7.5 - FOOTER_H, 13.333, 0.03, fill=theme["primary"])


def _title_block(slide, theme, title, subtitle=None):
    _text(slide, MARGIN - 0.3, 0.55, 11.5, 0.8,
          ((title, 32, INK, True, PP_ALIGN.LEFT, 2)))
    _rect(slide, MARGIN - 0.3, 1.28, 1.6, 0.06, fill=GOLD)
    if subtitle:
        _text(slide, MARGIN - 0.3, 1.42, 11.5, 0.4,
              ((subtitle, 14, SUB, False, PP_ALIGN.LEFT, 0)))


# ───────────────────────── 十二版式 ─────────────────────────
def ly_cover(prs, slide, theme, idx, total, deck_title):
    bg = gen_assets.make_cover_bg(theme)
    prs.slides[-1].shapes.add_picture(bg, 0, 0, PAGE_W, PAGE_H)
    s = prs.slides[-1]
    out = []
    kicker = slide.get("kicker", "")
    if kicker:
        out.append(_text(s, 1.2, 1.7, 11, 0.5, ((kicker, 16, GOLD, False, PP_ALIGN.LEFT, 0))))
    _need(slide, "title", "页面主标题", idx)
    out.append(_text(s, 1.2, 2.5, 11, 1.6,
                     ((slide["title"], 46, "F6F3EC", True, PP_ALIGN.LEFT, 4))))
    if slide.get("subtitle"):
        out.append(_text(s, 1.2, 4.3, 11, 0.7,
                         ((slide["subtitle"], 20, "D8D4CC", False, PP_ALIGN.LEFT, 0))))
    if slide.get("author"):
        out.append(_text(s, 1.2, 5.6, 11, 0.5,
                         ((slide["author"], 15, "B8B2A6", False, PP_ALIGN.LEFT, 0))))
    return out


def ly_toc(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _title_block(s, theme, slide.get("title", "目录"))
    _need(slide, "items", ["第一章 …", "第二章 …"], idx)
    items = slide["items"]
    out = []
    col_x = [MARGIN, 7.1]
    per = (len(items) + 1) // 2
    for i, it in enumerate(items):
        col = 0 if i < per else 1
        row = i if col == 0 else i - per
        y = 2.3 + row * 0.85
        _text(s, col_x[col], y, 0.9, 0.6, ("%02d" % (i + 1), 26, GOLD, True, PP_ALIGN.LEFT, 0))
        out.append(_text(s, col_x[col] + 0.8, y + 0.06, 4.8, 0.6,
                         ((str(it), 20, INK, False, PP_ALIGN.LEFT, 0))))
    return out


def ly_section(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _rect(s, 0, 0, 13.333, 7.5, fill=theme["primary"])
    _need(slide, "name", "章节名", idx)
    num = str(slide.get("number", idx))
    out = [_text(s, 1.0, 1.6, 4.5, 2.6, (num, 120, GOLD, True, PP_ALIGN.LEFT, 0))]
    out.append(_text(s, 1.0, 4.4, 11, 1.0, ((slide["name"], 40, "F6F3EC", True, PP_ALIGN.LEFT, 0))))
    if slide.get("subtitle"):
        out.append(_text(s, 1.0, 5.5, 11, 0.6,
                         ((slide["subtitle"], 16, "D8D4CC", False, PP_ALIGN.LEFT, 0))))
    return out


def ly_content(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "本页标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle"))
    _need(slide, "bullets", ["要点一", ["二级要点", 1]], idx)
    out = []
    y = 2.25
    for b in slide["bullets"]:
        lvl, txt = (b[1], b[0]) if isinstance(b, list) else (0, str(b))
        if lvl == 0:
            _rect(s, MARGIN - 0.32, y + 0.12, 0.14, 0.14, fill=GOLD, shape=MSO_SHAPE.OVAL)
            out.append(_text(s, MARGIN, y, 11.3, 0.9,
                             ((txt, 20, INK, False, PP_ALIGN.LEFT, 10))))
            y += 0.62 + (0.34 if len(txt) > 38 else 0)
        else:
            out.append(_text(s, MARGIN + 0.55, y, 10.7, 0.7,
                             (("· " + txt, 16, SUB, False, PP_ALIGN.LEFT, 6))))
            y += 0.45 + (0.26 if len(txt) > 46 else 0)
        if y > 6.7:
            break
    return out


def ly_two_column(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "本页标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle"))
    for key in ("left", "right"):
        if key not in slide:
            raise SpecError(
                "第 %d 页（two_column 版式）缺「%s」栏。\n"
                "  改法：\"%s\": {\"title\": \"栏标题\", \"bullets\": [\"要点…\"]}" % (idx, key, key))
    out = []
    for i, key in enumerate(("left", "right")):
        col = slide[key]
        x = MARGIN - 0.3 + i * 6.0
        _rect(s, x, 2.25, 5.6, 4.4, fill=PAPER)
        _rect(s, x, 2.25, 5.6, 0.14, fill=theme["palette"][2 + i])
        out.append(_text(s, x + 0.35, 2.6, 4.9, 0.6,
                         ((str(col.get("title", "")), 22, INK, True, PP_ALIGN.LEFT, 0))))
        yy = 3.4
        for b in col.get("bullets", []):
            _rect(s, x + 0.35, yy + 0.09, 0.1, 0.1, fill=GOLD, shape=MSO_SHAPE.OVAL)
            out.append(_text(s, x + 0.6, yy - 0.04, 4.7, 0.7,
                             ((str(b), 16, INK, False, PP_ALIGN.LEFT, 4))))
            yy += 0.52
    return out


def ly_image_text(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "本页标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle"))
    img = slide.get("image")
    out = []
    ix, iy, iw, ih = MARGIN - 0.3, 2.25, 5.4, 4.3
    if img and os.path.exists(str(img)):
        try:
            s.shapes.add_picture(str(img), Inches(ix), Inches(iy), Inches(iw), Inches(ih))
        except Exception as e:
            raise SpecError("第 %d 页图片打不开：%s\n  改法：确认文件是完整 PNG/JPG，或换路径。"
                            "想先出片可把该页 image 字段改成文字描述（会自动用图标占位）。" % (idx, e))
    else:
        if img and os.path.isabs(str(img)) and not os.path.exists(str(img)):
            print("⚠ 第 %d 页找不到图片 %s，已用图标占位（版式不乱，交付说明里会列替换清单）"
                  % (idx, img))
        desc = str(img) if img and not os.path.isabs(str(img)) else slide["title"][:2]
        ph = gen_assets.make_icon(theme, desc[:2])
        s.shapes.add_picture(ph, Inches(ix), Inches(iy), Inches(iw), Inches(ih))
        if img:
            out.append(_text(s, ix, iy + ih + 0.05, iw, 0.35,
                             (("AI 配图占位：" + str(img)[:60], 10, SUB, False, PP_ALIGN.LEFT, 0))))
    _need(slide, "bullets", ["要点一"], idx)
    yy = 2.45
    for b in slide["bullets"]:
        _rect(s, 6.5, yy + 0.1, 0.12, 0.12, fill=GOLD, shape=MSO_SHAPE.OVAL)
        out.append(_text(s, 6.75, yy - 0.05, 6.0, 0.8,
                         ((str(b), 18, INK, False, PP_ALIGN.LEFT, 6))))
        yy += 0.72
    return out


def ly_chart(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "图表标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle",
                 "示例数据，正式使用前替换" if slide.get("example") else None))
    _need(slide, "categories", ["Q1", "Q2", "Q3"], idx)
    _need(slide, "series", [{"name": "系列名", "values": [1, 2, 3]}], idx)
    ct = slide.get("chart_type", "column")
    if ct not in CHART_TYPES:
        raise SpecError(
            "第 %d 页（chart 版式）chart_type「%s」不支持。\n"
            "  可选：%s\n"
            "  组合图/散点等复杂图 → 用 matplotlib 出 PNG 走 image_text 版式。"
            % (idx, ct, "、".join(CHART_TYPES)))
    cats = slide["categories"]
    for si, se in enumerate(slide["series"]):
        if "values" not in se:
            raise SpecError("第 %d 页 series[%d] 缺「values」。\n  示例：{\"name\": \"2025\", \"values\": [120, 158, 210]}"
                            % (idx, si))
        if len(se["values"]) != len(cats):
            raise SpecError(
                "第 %d 页 series[%d] 的 values 有 %d 个数，但 categories 有 %d 个，对不上。\n"
                "  改法：让每个系列 values 个数 = categories 个数。" % (idx, si, len(se["values"]), len(cats)))
    cd = CategoryChartData()
    cd.categories = [str(c) for c in cats]
    for se in slide["series"]:
        cd.add_series(str(se.get("name", "系列")), se["values"])
    gf = s.shapes.add_chart(CHART_TYPES[ct], Inches(MARGIN - 0.3), Inches(2.1),
                            Inches(11.9), Inches(4.6), cd)
    chart = gf.chart
    chart.has_title = False
    pal = theme["palette"]
    plot = chart.plots[0]
    if ct in ("pie", "doughnut"):
        plot.has_data_labels = True
        dl = plot.data_labels
        dl.show_percentage = True
        dl.show_value = False
        dl.font.size = Pt(12)
        ser = chart.series[0]
        for pi in range(len(cats)):
            pt = ser.points[pi]
            pt.format.fill.solid()
            pt.format.fill.fore_color.rgb = _rgb(pal[pi % len(pal)])
    else:
        try:
            plot.gap_width = 90
        except Exception:
            pass
        for i, ser in enumerate(chart.series):
            ser.format.fill.solid()
            ser.format.fill.fore_color.rgb = _rgb(pal[i % len(pal)])
            ser.format.line.color.rgb = _rgb(pal[i % len(pal)])
        if slide.get("data_labels", len(slide["series"]) == 1):
            plot.has_data_labels = True
            plot.data_labels.font.size = Pt(11)
    if len(slide["series"]) > 1:
        chart.has_legend = True
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(12)
    else:
        chart.has_legend = False
    for name in ("category_axis", "value_axis"):
        try:
            ax = getattr(chart, name)
            if ax is not None:
                ax.tick_labels.font.size = Pt(12)
        except Exception:                     # 饼/环无坐标轴
            pass
    return []


def ly_diagram(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "图示标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle"))
    dt = slide.get("diagram_type", "")
    if dt not in DIAGRAM_TYPES:
        raise SpecError(
            "第 %d 页（diagram 版式）diagram_type「%s」不支持。\n  可选：%s\n"
            "  各型数据格式见 SKILL.md diagrams.md 一节。" % (idx, dt, "、".join(DIAGRAM_TYPES)))
    data = slide.get("data")
    if not isinstance(data, dict):
        raise SpecError(
            "第 %d 页（%s 图示）缺「data」。\n  示例：%s"
            % (idx, dt, json.dumps({"steps": ["第一步", "第二步", "第三步"]}, ensure_ascii=False)))
    pal = theme["palette"]
    out = []
    if dt == "flow":
        _need_data(slide, data, "steps", ["第一步", "第二步", "第三步"], idx, dt)
        steps = [str(x) for x in data["steps"]][:6]
        n = len(steps)
        w, gap = 1.9, 0.35
        x0 = (13.333 - n * w - (n - 1) * gap) / 2
        for i, t in enumerate(steps):
            x = x0 + i * (w + gap)
            sp = _rect(s, x, 3.6, w, 1.3, fill=pal[i % len(pal)],
                       shape=MSO_SHAPE.ROUNDED_RECTANGLE)
            _shape_text(sp, t, 15)
            out.append(sp)
            if i < n - 1:
                ar = _rect(s, x + w + 0.03, 4.05, gap - 0.06, 0.4, fill=GOLD,
                           shape=MSO_SHAPE.RIGHT_ARROW)
                ar.line.fill.background()
    elif dt == "org":
        _need_data(slide, data, "root", {"name": "负责人"}, idx, dt)
        kids = data.get("children", [])
        if len(kids) > 5:
            print("⚠ 第 %d 页 org 子节点 %d 个（建议 ≤5），已自动排两行" % (idx, len(kids)))
        root = data["root"]
        sp = _rect(s, 5.42, 2.35, 2.5, 1.0, fill=pal[0], shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        _shape_text(sp, str(root.get("name", "")) + ("\n" + root.get("sub", "") if root.get("sub") else ""), 15)
        out.append(sp)
        n = max(len(kids), 1)
        cw = min(2.1, 11.0 / n - 0.3)
        total_w = n * cw + (n - 1) * 0.3
        x0 = (13.333 - total_w) / 2
        for i, k in enumerate(kids):
            x = x0 + i * (cw + 0.3)
            conn = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(6.67),
                                          Inches(3.35), Inches(x + cw / 2), Inches(4.6))
            conn.line.color.rgb = _rgb("9AA0A6")
            conn.line.width = Pt(1.5)
            csp = _rect(s, x, 4.6, cw, 1.1, fill=pal[(i + 1) % len(pal)],
                        shape=MSO_SHAPE.ROUNDED_RECTANGLE)
            _shape_text(csp, str(k.get("name", "")) + ("\n" + k.get("sub", "") if k.get("sub") else ""), 13)
            out.append(csp)
    elif dt == "swot":
        _need_data(slide, data, "items", {"S": "优势", "W": "劣势", "O": "机会", "T": "挑战"}, idx, dt)
        items = data["items"]
        cells = [("S", "S · 优势", 0), ("W", "W · 劣势", 1), ("O", "O · 机会", 2), ("T", "T · 挑战", 3)]
        for key, label, i in cells:
            x = MARGIN - 0.3 + (i % 2) * 5.95
            y = 2.15 + (i // 2) * 2.25
            card = _rect(s, x, y, 5.75, 2.1, fill=PAPER)
            _rect(s, x, y, 0.12, 2.1, fill=pal[i])
            _text(s, x + 0.3, y + 0.12, 5.2, 0.45, ((label, 16, pal[i], True, PP_ALIGN.LEFT, 0)))
            _text(s, x + 0.3, y + 0.62, 5.2, 1.4,
                  (str(items.get(key, "")), 14, INK, False, PP_ALIGN.LEFT, 0))
            out.append(card)
    elif dt == "pyramid":
        _need_data(slide, data, "levels", ["顶层", "中层", "底层"], idx, dt)
        levels = [str(x) for x in data["levels"]][:5]
        n = len(levels)
        base_w = 7.6
        y = 2.3
        for i, t in enumerate(levels):
            frac_top = i / n
            frac_bot = (i + 1) / n
            w_top = base_w * frac_top
            w_bot = base_w * frac_bot
            h = 4.0 / n
            sp = s.shapes.add_shape(MSO_SHAPE.ISOCELES_TRIANGLE,
                                    Inches(6.667 - w_bot / 2), Inches(y), Inches(w_bot), Inches(h + 0.02))
            sp.adjustments[0] = max(0.0, (w_bot - w_top) / 2 / w_bot) if w_bot else 0
            sp.fill.solid()
            sp.fill.fore_color.rgb = _rgb(pal[i % len(pal)])
            sp.line.color.rgb = _rgb("FFFFFF")
            sp.line.width = Pt(1.5)
            sp.shadow.inherit = False
            sp.text_frame.word_wrap = True
            if i >= 0:
                _shape_text(sp, t, min(15, 9 + n - i))
            out.append(sp)
            _text(s, 10.6, y + h / 2 - 0.2, 2.4, 0.5, ((t, 13, SUB, False, PP_ALIGN.LEFT, 0)))
            y += h
    elif dt == "venn":
        labels = [str(x) for x in data.get("labels", [])][:3]
        if not labels:
            raise SpecError("第 %d 页（venn 图示）data 缺「labels」（2-3 个）。\n  示例：{\"labels\": [\"内容\", \"流量\"]}" % idx)
        colors = [pal[i % len(pal)] for i in range(len(labels))]
        pos = {2: [(4.6, 2.5), (6.6, 2.5)], 3: [(4.4, 2.4), (7.4, 2.4), (5.9, 4.4)]}[len(labels)]
        for (x, y), c, t in zip(pos, colors, labels):
            sp = _rect(s, x, y, 2.6, 2.6, fill=c, shape=MSO_SHAPE.OVAL)
            sp.fill.fore_color.rgb = _rgb(c)
            _shape_text(sp, t, 14)
            out.append(sp)
    elif dt == "cycle":
        _need_data(slide, data, "steps", ["内容", "流量", "转化"], idx, dt)
        steps = [str(x) for x in data["steps"]][:6]
        n = len(steps)
        cx, cy = 6.667, 4.35
        import math as _m
        for i, t in enumerate(steps):
            ang = -_m.pi / 2 + i * 2 * _m.pi / n
            x = cx + 3.6 * _m.cos(ang) - 1.0
            y = cy + 1.75 * _m.sin(ang) - 0.5
            sp = _rect(s, x, y, 2.0, 1.0, fill=pal[i % len(pal)], shape=MSO_SHAPE.ROUNDED_RECTANGLE)
            _shape_text(sp, t, 14)
            out.append(sp)
        core = _rect(s, cx - 1.1, cy - 0.55, 2.2, 1.1, fill=GOLD, shape=MSO_SHAPE.OVAL)
        _shape_text(core, str(data.get("core", "循环")), 15, color=INK)
        out.append(core)
    elif dt == "funnel":
        _need_data(slide, data, "steps", ["曝光", "点击", "咨询", "成交"], idx, dt)
        steps = [str(x) for x in data["steps"]][:5]
        n = len(steps)
        w0 = 8.6
        y = 2.2
        for i, t in enumerate(steps):
            w = w0 * (1 - i * 0.72 / max(n - 1, 1))
            sp = s.shapes.add_shape(MSO_SHAPE.TRAPEZOID, Inches(6.667 - w / 2), Inches(y),
                                    Inches(w), Inches(0.95))
            sp.rotation = 180
            sp.adjustments[0] = 0.22
            sp.fill.solid()
            sp.fill.fore_color.rgb = _rgb(pal[i % len(pal)])
            sp.line.fill.background()
            sp.shadow.inherit = False
            sp.text_frame.word_wrap = True
            _shape_text(sp, t, 14)
            out.append(sp)
            y += 1.06
    return out


def _need_data(slide, data, key, example, idx, dt):
    if key not in data:
        raise SpecError(
            "第 %d 页（%s 图示）data 缺「%s」。\n  示例：%s"
            % (idx, dt, key, json.dumps({key: example}, ensure_ascii=False)))


def ly_timeline(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "时间轴标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle"))
    _need(slide, "events", [{"date": "2026-01", "text": "启动"}], idx)
    events = slide["events"][:7]
    n = len(events)
    x0, x1 = MARGIN, 12.4
    y = 4.2
    _rect(s, x0, y - 0.02, x1 - x0, 0.05, fill="C9CDC2")
    out = []
    for i, ev in enumerate(events):
        x = x0 + i * (x1 - x0) / max(n - 1, 1)
        _rect(s, x - 0.09, y - 0.09, 0.2, 0.2, fill=GOLD, shape=MSO_SHAPE.OVAL)
        up = i % 2 == 0
        date_y = y - 0.75 if up else y + 0.25
        text_y = y - 1.75 if up else y + 0.62
        tx = max(0.10, min(x - 0.85, 13.23 - 1.9))     # 文本框夹在版心内，防末节点越界
        tx2 = max(0.10, min(x - 0.95, 13.23 - 2.1))
        out.append(_text(s, tx, date_y, 1.9, 0.4,
                         ((str(ev.get("date", "")), 13, theme["primary"], True, PP_ALIGN.CENTER, 0))))
        out.append(_text(s, tx2, text_y, 2.1, 1.0,
                         ((str(ev.get("text", "")), 12, INK, False, PP_ALIGN.CENTER, 0))))
    return out


def ly_quote(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _rect(s, 0, 0, 13.333, 7.5, fill=theme["primary"])
    _need(slide, "quote", "在这页放一句打动人的话", idx)
    out = [_text(s, 1.0, 1.2, 2.0, 1.6, (("“", 96, GOLD, True, PP_ALIGN.LEFT, 0)))]
    out.append(_text(s, 1.6, 2.7, 10.2, 2.2,
                     ((slide["quote"], 34, "F6F3EC", True, PP_ALIGN.LEFT, 0))))
    if slide.get("attribution"):
        out.append(_text(s, 1.6, 5.3, 10, 0.5,
                         ((slide["attribution"], 16, "D8D4CC", False, PP_ALIGN.LEFT, 0))))
    return out


def ly_stat(prs, slide, theme, idx, total, deck_title):
    s = prs.slides[-1]
    _chrome(s, theme, idx, total, deck_title)
    _need(slide, "title", "数据页标题", idx)
    _title_block(s, theme, slide["title"], slide.get("subtitle"))
    _need(slide, "stats", [{"num": "87%", "label": "指标说明"}], idx)
    stats = slide["stats"][:4]
    n = len(stats)
    gap = 0.35
    w = (11.53 - (n - 1) * gap) / n
    out = []
    for i, st in enumerate(stats):
        x = MARGIN - 0.3 + i * (w + gap)
        if "num" not in st:
            raise SpecError("第 %d 页 stats[%d] 缺「num」。\n  示例：{\"num\": \"87%\", \"label\": \"完成率\"}" % (idx, i))
        _rect(s, x, 2.5, w, 3.2, fill=PAPER)
        _rect(s, x, 2.5, w, 0.14, fill=theme["palette"][i % len(theme["palette"])])
        out.append(_text(s, x + 0.2, 3.1, w - 0.4, 1.4,
                         ((str(st["num"]), 54, INK, True, PP_ALIGN.CENTER, 0))))
        out.append(_text(s, x + 0.2, 4.7, w - 0.4, 0.9,
                         ((str(st.get("label", "")), 17, SUB, False, PP_ALIGN.CENTER, 0))))
    return out


def ly_closing(prs, slide, theme, idx, total, deck_title):
    bg = gen_assets.make_cover_bg(theme)
    prs.slides[-1].shapes.add_picture(bg, 0, 0, PAGE_W, PAGE_H)
    s = prs.slides[-1]
    out = [_text(s, 1.2, 2.6, 11, 1.5,
                 ((slide.get("title", "谢谢观看"), 52, "F6F3EC", True, PP_ALIGN.LEFT, 0)))]
    if slide.get("subtitle"):
        out.append(_text(s, 1.2, 4.4, 11, 0.7,
                         ((slide["subtitle"], 20, "D8D4CC", False, PP_ALIGN.LEFT, 0))))
    return out


BUILDERS = {"cover": ly_cover, "toc": ly_toc, "section": ly_section, "content": ly_content,
            "two_column": ly_two_column, "image_text": ly_image_text, "chart": ly_chart,
            "diagram": ly_diagram, "timeline": ly_timeline, "quote": ly_quote,
            "stat": ly_stat, "closing": ly_closing}
NO_CHROME = {"cover", "section", "quote", "closing"}



# ───────────────────────── 硬核三件套：scan / check / verify / selftest ─────────────────────────
def scan_deck(pptx_path):
    """对成片内全部文本跑完整词库。返回 (hard_n, soft_n, dict_path, n_rules)。"""
    dpath, rules = load_dict()
    if dpath is None:
        return 0, 0, None, 0
    prs = Presentation(pptx_path)
    hard = soft = 0
    for _page, text in collect_texts(prs):
        for w, lvl, _fix in rules:
            if w in text:
                if lvl == "HARD":
                    hard += 1
                else:
                    soft += 1
    return hard, soft, dpath, len(rules)


def check_spec(spec, theme_override=None):
    """只校验不生成：逐页验证版式与必填字段，返回问题清单（空 = 通过）。"""
    errs = []
    theme_key = theme_override or spec.get("theme", "business")
    if theme_key not in THEMES:
        errs.append("主题「%s」不存在（可选：%s）" % (theme_key, "、".join(THEMES)))
    slides_spec = spec.get("slides")
    if not slides_spec or not isinstance(slides_spec, list):
        return ['spec 缺「slides」列表。示例：{"theme":"business","slides":[{"layout":"cover",'
                '"title":"…"}]}'] + errs
    for i, sl in enumerate(slides_spec, 1):
        try:
            if not isinstance(sl, dict) or "layout" not in sl:
                raise SpecError("缺「layout」字段（可选：%s）" % "、".join(LAYOUTS))
            if sl["layout"] not in BUILDERS:
                raise SpecError("layout「%s」不存在（可选：%s）" % (sl["layout"], "、".join(LAYOUTS)))
            ly = sl["layout"]
            req = {"cover": ["title"], "toc": ["items"], "section": ["name"],
                   "content": ["title", "bullets"], "two_column": ["title", "left", "right"],
                   "image_text": ["title", "bullets"], "chart": ["title", "categories", "series"],
                   "diagram": ["title", "diagram_type", "data"], "timeline": ["title", "events"],
                   "quote": ["quote"], "stat": ["title", "stats"], "closing": ["title"]}[ly]
            for f in req:
                if not sl.get(f):
                    raise SpecError("缺必填字段「%s」" % f)
            if ly == "chart":
                ct = sl.get("chart_type", "column")
                if ct not in CHART_TYPES:
                    raise SpecError("chart_type「%s」不支持（可选：%s）" % (ct, "、".join(CHART_TYPES)))
                for si, se in enumerate(sl["series"]):
                    if len(se.get("values", [])) != len(sl["categories"]):
                        raise SpecError("series[%d] values 个数与 categories 不一致" % si)
            if ly == "diagram" and sl["diagram_type"] not in DIAGRAM_TYPES:
                raise SpecError("diagram_type「%s」不支持（可选：%s）"
                                % (sl["diagram_type"], "、".join(DIAGRAM_TYPES)))
        except SpecError as e:
            errs.append("第 %d 页（%s）：%s" % (i, sl.get("layout", "?") if isinstance(sl, dict) else "?", e))
    return errs


def verify_deck(pptx_path):
    """成片质检报告：结构完整性 + 边界越界 + 逐条机检（含页码与改法）。返回退出码。"""
    if not os.path.exists(pptx_path):
        print("✗ 找不到文件：%s" % pptx_path)
        return 2
    prs = Presentation(pptx_path)
    W, H = prs.slide_width, prs.slide_height
    n_shapes = n_chart = n_pic = n_anim = 0
    oob = []                                   # 越界（容忍 0.05in）
    tol = Emu(int(0.05 * 914400))
    for i, sld in enumerate(prs.slides, 1):
        for sh in sld.shapes:
            n_shapes += 1
            try:
                if sh.has_chart:
                    n_chart += 1
            except Exception:
                pass
            if sh.shape_type == 13:
                n_pic += 1
            try:
                if sh.left is not None and (sh.left < -tol or sh.top < -tol
                                            or sh.left + sh.width > W + tol
                                            or sh.top + sh.height > H + tol):
                    oob.append((i, sh.shape_type, round(sh.left / 914400, 2),
                                round(sh.top / 914400, 2)))
            except Exception:
                pass
        t = sld.element.find("{%s}timing" % "http://schemas.openxmlformats.org/presentationml/2006/main")
        if t is not None:
            n_anim += len(t.findall(".//{%s}animEffect" % "http://schemas.openxmlformats.org/presentationml/2006/main"))
    texts = collect_texts(prs)
    dpath, rules = load_dict()
    hits = []
    if rules:
        for page, text in texts:
            for w, lvl, fix in rules:
                if w in text:
                    hits.append((page, lvl, w, fix))
    hard = [h for h in hits if h[1] == "HARD"]
    soft = [h for h in hits if h[1] == "SOFT"]
    print("═" * 56)
    print("成片质检报告：%s" % pptx_path)
    print("═" * 56)
    n_notes = sum(1 for sld in prs.slides
                  if sld.has_notes_slide and sld.notes_slide.notes_text_frame.text.strip())
    print("结构：%d 页｜%d 个形状｜原生图表 %d｜图片 %d｜动画效果 %d｜讲者备注 %d 页"
          % (len(prs.slides._sldIdLst), n_shapes, n_chart, n_pic, n_anim, n_notes))
    if oob:
        print("⚠ 越界元素 %d 处（页码, 类型, x, y）：%s" % (len(oob), oob[:5]))
    else:
        print("边界检查：全部元素在版心内 ✓")
    if dpath is None:
        print("⚠ 词库缺失（references/sensitive-words.md），文本机检未执行")
    else:
        print("文本机检：词库 %d 条｜文本块 %d 个" % (len(rules), len(texts)))
        if hard:
            print("✗ HARD 命中 %d 处（必须改完再交付）：" % len(hard))
            for page, _l, w, fix in hard:
                print("  第 %d 页「%s」→ 改法：%s" % (page, w, fix or "换中性描述"))
        else:
            print("HARD 命中 0 ✓")
        if soft:
            print("△ SOFT %d 处：%s" % (len(soft), "、".join("第%d页「%s」" % (p, w) for p, _l, w, _f in soft[:6])))
    print("─" * 56)
    if hard or (dpath is None):
        print("结论：✗ 未过检（HARD %d）——改完重跑 gen_pptx.py verify 确认" % len(hard))
        return 1
    print("结论：✓ 质检通过，可交付（越界 %d / HARD 0 / SOFT %d）" % (len(oob), len(soft)))
    return 0


def selftest():
    """全矩阵回归：5 主题 × demo 全版式 + 4 例异常注入。全 PASS 退出 0。"""
    import tempfile
    results = []
    for tk in THEMES:
        try:
            out = os.path.join(tempfile.mkdtemp(prefix="pptselftest_"), tk + ".pptx")
            build({"theme": tk, "title": "回归-" + tk, "slides": _demo_spec()["slides"]}, out)
            chk = Presentation(out)
            ok = len(chk.slides) == len(_demo_spec()["slides"])
            results.append(("主题 %s × 12 版式" % tk, ok, "14 页重开一致" if ok else "页数不符"))
        except Exception as e:                # noqa: BLE001
            results.append(("主题 %s × 12 版式" % tk, False, str(e)[:60]))
    cases = [
        ("坏 layout → 应报 SpecError", {"slides": [{"layout": "nope", "title": "t"}]}),
        ("缺必填字段 → 应报 SpecError", {"slides": [{"layout": "content", "title": "t"}]}),
        ("values 不匹配 → 应报 SpecError",
         {"slides": [{"layout": "chart", "title": "t", "categories": ["A", "B"],
                      "series": [{"name": "s", "values": [1]}]}]}),
        ("坏主题 → 应报 SpecError", {"theme": "nope", "slides": [{"layout": "toc", "items": ["a"]}]}),
    ]
    for name, bad in cases:
        try:
            errs = check_spec(bad)
            results.append((name, bool(errs), errs[0][:60] if errs else "竟然没报错"))
        except Exception as e:                # noqa: BLE001
            results.append((name, True, "抛错即过：%s" % str(e)[:40]))
    print("═" * 56)
    print("selftest 全矩阵回归（5 主题 × 14 页 demo + 4 例异常注入）")
    print("═" * 56)
    fails = 0
    for name, ok, note in results:
        print("  %s %s ｜ %s" % ("PASS" if ok else "FAIL", name, note))
        fails += 0 if ok else 1
    print("─" * 56)
    print("结果：%d/%d PASS" % (len(results) - fails, len(results)))
    return 1 if fails else 0

# ───────────────────────── 主流程 ─────────────────────────
def build(spec, out_path, theme_override=None):
    theme_key = theme_override or spec.get("theme", "business")
    if theme_key not in THEMES:
        raise SpecError("主题「%s」不存在。可选：%s（也可 --theme business 覆盖）"
                        % (theme_key, "、".join(THEMES)))
    theme = THEMES[theme_key]
    slides_spec = spec.get("slides")
    if not slides_spec or not isinstance(slides_spec, list):
        raise SpecError('spec 缺「slides」列表。\n  示例：{"theme": "business", "slides": '
                        '[{"layout": "cover", "title": "汇报"}, {"layout": "content", '
                        '"title": "要点", "bullets": ["第一点"]}]}')
    for i, sl in enumerate(slides_spec, 1):
        if not isinstance(sl, dict) or "layout" not in sl:
            raise SpecError("第 %d 页缺「layout」字段。\n  可选版式：%s\n"
                            "  示例：{\"layout\": \"content\", \"title\": \"…\", \"bullets\": [\"…\"]}"
                            % (i, "、".join(LAYOUTS)))
        if sl["layout"] not in BUILDERS:
            raise SpecError(
                "第 %d 页 layout「%s」不存在。\n  可选：%s\n"
                "  是不是想写别的？对照可选项改一个字即可。" % (i, sl["layout"], "、".join(LAYOUTS)))
    deck_title = spec.get("title", "")
    prs = Presentation()
    prs.slide_width, prs.slide_height = PAGE_W, PAGE_H
    blank = prs.slide_layouts[6]
    total = len(slides_spec)
    anim_count = 0
    for i, sl in enumerate(slides_spec, 1):
        prs.slides.add_slide(blank)
        targets = BUILDERS[sl["layout"]](prs, sl, theme, i, total, deck_title)
        s = prs.slides[-1]
        if sl.get("anim") and targets:
            anim_count += animations.apply(s, targets, sl["anim"])
        elif sl.get("anim"):
            # 无内容形状的页：标题类页不加动画（克制原则）
            pass
        if sl.get("notes"):
            s.notes_slide.notes_text_frame.text = str(sl["notes"])  # 讲者备注
    # 收尾页补页码之外的校验
    prs.save(out_path)
    # 自检：重新打开数页数 + 统计动画页
    chk = Presentation(out_path)
    n_slides = len(chk.slides)
    size_kb = os.path.getsize(out_path) / 1024
    return {"slides": len(slides_spec), "reopened": n_slides,
            "anim_shapes": anim_count, "kb": size_kb,
            "theme": theme["name"], "out": out_path}


def _demo_spec():
    return {
        "theme": "business",
        "title": "季度经营汇报（演示样片）",
        "slides": [
            {"layout": "cover", "kicker": "内部汇报 · 示例数据",
             "title": "季度经营汇报", "subtitle": "从数据到下一步",
             "author": "汇报人：待填", "anim": {"type": "fade", "order": "batch"},
             "notes": "开场 1 分钟：先讲结论，再讲数据，最后讲下一步。"},
            {"layout": "toc", "title": "目录",
             "items": ["本季回顾", "关键数据", "打法复盘", "下季计划"]},
            {"layout": "section", "number": "01", "name": "本季回顾"},
            {"layout": "content", "title": "三件最重要的事",
             "bullets": ["新渠道跑通，贡献 23% 的新增（示例数据）", ["细分：转化率环比提升 4 个点", 1],
                          "老客复购计划落地，复购率 31%", "团队扩编 3 人，分工重排"],
             "anim": {"type": "fly_in", "order": "seq", "dur": 500, "delay": 300}},
            {"layout": "two_column", "title": "两种打法对比",
             "left": {"title": "渠道 A", "bullets": ["成本低", "周期长"]},
             "right": {"title": "渠道 B", "bullets": ["起量快", "单价高"]}},
            {"layout": "chart", "title": "季度营收（示例数据）", "chart_type": "column",
             "categories": ["Q1", "Q2", "Q3", "Q4"],
             "series": [{"name": "去年", "values": [120, 158, 210, 268]},
                         {"name": "今年", "values": [180, 240, 305, 410]}],
             "data_labels": True, "anim": {"type": "wipe", "order": "batch"},
             "notes": "数据页停 30 秒，让观众先看完数字再开口。"},
            {"layout": "chart", "title": "新增构成（示例数据）", "chart_type": "doughnut",
             "categories": ["自然流量", "付费投放", "转介绍"],
             "series": [{"name": "占比", "values": [52, 31, 17]}]},
            {"layout": "diagram", "title": "增长飞轮", "diagram_type": "cycle",
             "data": {"core": "增长", "steps": ["内容", "流量", "转化", "复购", "裂变"]}},
            {"layout": "diagram", "title": "SWOT（示例）", "diagram_type": "swot",
             "data": {"items": {"S": "供应链响应快", "W": "品牌认知弱",
                                 "O": "下沉市场空白", "T": "头部压价"}}},
            {"layout": "timeline", "title": "下季里程碑（示例）",
             "events": [{"date": "7月", "text": "新渠道放量"}, {"date": "8月", "text": "产品 2.0"},
                         {"date": "9月", "text": "渠道分销"}, {"date": "10月", "text": "年度复盘"}]},
            {"layout": "stat", "title": "关键指标（示例数据）",
             "stats": [{"num": "312%", "label": "同比增长"}, {"num": "31%", "label": "复购率"},
                        {"num": "23%", "label": "新增占比"}, {"num": "4pt", "label": "转化提升"}]},
            {"layout": "image_text", "title": "案例：单渠道打样",
             "image": "增长", "bullets": ["两周内跑通最小闭环（示例）", "成本回收周期 11 天"]},
            {"layout": "quote", "quote": "先跑通一条最小链路，再谈放大。", "attribution": "—— 本季复盘"},
            {"layout": "closing", "title": "谢谢，等你的问题",
             "subtitle": "数据口径与明细见附录"},
        ],
    }


def main():
    import argparse
    ap = argparse.ArgumentParser(description="PPT一键生成主引擎：spec → 可编辑 .pptx")
    ap.add_argument("spec", nargs="?", help="spec.json 路径；用 --demo 则忽略")
    ap.add_argument("-o", "--out", default="deck.pptx", help="输出路径（默认 deck.pptx）")
    ap.add_argument("--theme", default=None, help="覆盖主题：%s" % "、".join(THEMES))
    ap.add_argument("--demo", action="store_true", help="生成全能力演示样片（12 版式+图表+图示+动画）")
    ap.add_argument("--no-scan", action="store_true", help="跳过成片文本机检（默认开）")
    ap.add_argument("--check", action="store_true", help="只校验 spec 不生成（CI/发布前用）")
    ap.add_argument("--selftest", action="store_true", help="全矩阵回归：5 主题×12 版式 + 4 例异常注入")
    ap.add_argument("--verify", metavar="PPTX", default=None, help="对已生成 .pptx 出质检报告")
    a = ap.parse_args()
    try:
        if a.selftest:
            sys.exit(selftest())
        if a.verify:
            sys.exit(verify_deck(a.verify))
        if a.demo:
            spec = _demo_spec()
        else:
            if not a.spec:
                ap.error("给 spec.json 路径，或用 --demo 出演示样片")
            if not os.path.exists(a.spec):
                near = [f for f in os.listdir(".") if f.endswith(".json")]
                raise SpecError(
                    "找不到 spec 文件：%s\n  当前目录下的 json：%s\n"
                    "  改法：确认路径，或用 --demo 先看样片。" % (a.spec, "、".join(near) or "无"))
            try:
                spec = json.load(open(a.spec, encoding="utf-8"))
            except json.JSONDecodeError as e:
                raise SpecError("spec.json 不是合法 JSON（%s）。\n  改法：第 %d 行附近检查引号/逗号。"
                                % (e.msg, getattr(e, "lineno", 0)))
        if a.check:
            if a.demo:
                spec = _demo_spec()
            errs = check_spec(spec, a.theme)
            if errs:
                print("✗ spec 校验未过（%d 处）：" % len(errs))
                for e in errs:
                    print("  - %s" % e)
                sys.exit(1)
            print("✓ spec 校验通过：%d 页、主题 %s，可直接生成。"
                  % (len(spec.get("slides", [])), a.theme or spec.get("theme", "business")))
            sys.exit(0)
        info = build(spec, a.out, a.theme)
        print("═" * 56)
        print("成片完成：%s" % info["out"])
        print("═" * 56)
        print("  页数：%d（重新打开校验 %d 页一致）｜主题：%s｜大小 %.0fKB"
              % (info["slides"], info["reopened"], info["theme"], info["kb"]))
        print("  动画形状：%d 个（PowerPoint/WPS 放映模式播放）" % info["anim_shapes"])
        # 交付即机检：对成片内全部文本跑完整词库（默认开，--no-scan 关）
        if not a.no_scan:
            hard_n, soft_n, dpath, nr = scan_deck(a.out)
            if dpath is None:
                print("  ⚠ 词库缺失，未做成片机检——请补回 references/sensitive-words.md")
            elif hard_n:
                print("  ⚠ 成片文本机检（%d 条词库）：命中 %d 处 HARD——跑 "
                      "python3 gen_pptx.py verify %s 看逐条位置与改法" % (nr, hard_n, a.out))
            else:
                print("  成片文本机检（%d 条词库）：HARD 0（SOFT %d）✓" % (nr, soft_n))
        print("  质检：python3 gen_pptx.py verify %s ｜ 回归：python3 gen_pptx.py --selftest"
              % a.out)
    except SpecError as e:
        print("✗ 规格有误，按提示改完重跑即可：\n%s" % e)
        sys.exit(1)
    except Exception as e:                    # noqa: BLE001 —— 兜住一切技术报错
        print("✗ 生成中断：%s.%s" % (type(e).__name__, e))
        print("  常见原因：① 某页字段取值越界（values 与 categories 数量不一致等）")
        print("           ② 输出路径被占用（换 -o 路径）")
        print("  排查法：python3 gen_pptx.py --demo -o demo.pptx 先验证环境，")
        print("          再对比你的 spec 找差异页。")
        sys.exit(1)


if __name__ == "__main__":
    main()
