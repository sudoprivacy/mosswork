#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPT一键生成 · 动画注入引擎（animations.py）
==========================================
向 python-pptx 生成的幻灯片注入 PowerPoint 原生进入动画（<p:timing> 时序树），
PowerPoint / WPS 放映模式可播放。非 GIF、非切页转场。

支持：
  type:  fade（淡入，默认稳妥） / fly_in（自底部飞入） / wipe（自底部擦除，适合图表揭示）
  order: seq（逐条依次自动进入） / batch（整批同时进入）
  dur:   单个动画时长 ms（默认 600）
  delay: 逐条间隔 ms（默认 350，仅 seq 生效）

设计原则：
- 注入失败只警告不中断——宁可少动画，绝不产出打不开的文件；
- 调用方（gen_pptx.py）负责挑选目标形状，全屏背景图不参与动画。
"""
import itertools

from lxml import etree

P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
NSMAP = 'xmlns:p="%s" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"' % P_NS

# presetID/presetSubtype 按 PowerPoint 预设库：10=淡入 2=飞入(自底=4) 22=擦除(自底=4)
_PRESETS = {
    "fade":   (10, 0, "fade"),
    "fly_in": (2, 4, "slide(fromBottom)"),
    "wipe":   (22, 4, "wipe(up)"),
}


def supported():
    return list(_PRESETS)


def _effect_par(ids, spid, kind, dur, delay, first):
    pid, psub, filt = _PRESETS[kind]
    cid, sid, aid = next(ids), next(ids), next(ids)
    node_type = "withEffect" if first else "afterEffect"
    return (
        '<p:par><p:cTn id="%d" presetID="%d" presetClass="entr" presetSubtype="%d"'
        ' fill="hold" grpId="0" nodeType="%s">'
        '<p:stCondLst><p:cond delay="%d"/></p:stCondLst>'
        "<p:childTnLst>"
        '<p:set><p:cBhvr><p:cTn id="%d" dur="1" fill="hold">'
        "<p:stCondLst><p:cond delay=\"0\"/></p:stCondLst></p:cTn>"
        '<p:tgtEl><p:spTgt spid="%d"/></p:tgtEl>'
        "<p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst>"
        '</p:cBhvr><p:to><p:strVal val="visible"/></p:to></p:set>'
        '<p:animEffect transition="in" filter="%s"><p:cBhvr>'
        '<p:cTn id="%d" dur="%d"/>'
        '<p:tgtEl><p:spTgt spid="%d"/></p:tgtEl></p:cBhvr></p:animEffect>'
        "</p:childTnLst></p:cTn></p:par>"
        % (cid, pid, psub, node_type, delay, sid, spid, filt, aid, dur, spid)
    )


def build_timing_xml(shape_ids, kind="fade", order="seq", dur=600, delay=350):
    """构造整页 <p:timing> XML。shape_ids 为参与动画的形状 id 列表。"""
    if kind not in _PRESETS:
        raise ValueError(
            "不认识的动画类型：%s（可选：%s）" % (kind, "、".join(_PRESETS)))
    if not shape_ids:
        return None
    ids = itertools.count(3)
    effects = []
    for i, spid in enumerate(shape_ids):
        d = 0 if (order == "batch" or i == 0) else delay
        effects.append(_effect_par(ids, spid, kind, dur, d, i == 0))
    gid1, gid2 = next(ids), next(ids)
    return (
        "<p:timing %s><p:tnLst><p:par>"
        '<p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot">'
        "<p:childTnLst>"
        '<p:seq concurrent="1" nextAc="seek">'
        '<p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'
        '<p:par><p:cTn id="%d" fill="hold">'
        '<p:stCondLst><p:cond delay="indefinite"/>'
        '<p:cond evt="onBegin" delay="0"><p:tn val="2"/></p:cond></p:stCondLst>'
        "<p:childTnLst>"
        '<p:par><p:cTn id="%d" fill="hold">'
        '<p:stCondLst><p:cond delay="0"/></p:stCondLst>'
        "<p:childTnLst>%s</p:childTnLst>"
        "</p:cTn></p:par>"
        "</p:childTnLst></p:cTn></p:par>"
        "</p:childTnLst></p:cTn>"
        '<p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl>'
        "</p:cond></p:prevCondLst>"
        '<p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl>'
        "</p:cond></p:nextCondLst>"
        "</p:seq></p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>"
        % (NSMAP, gid1, gid2, "".join(effects))
    )


def apply(slide, shapes, anim):
    """向一页幻灯片注入动画。shapes 为可动画形状列表；失败仅警告不抛异常。"""
    if not anim:
        return 0
    kind = anim.get("type", "fade")
    order = anim.get("order", "seq")
    dur = int(anim.get("dur", 600))
    delay = int(anim.get("delay", 350))
    if kind not in _PRESETS:
        print("⚠ 动画类型「%s」不支持（可选：%s），本页跳过动画"
              % (kind, "、".join(_PRESETS)))
        return 0
    if order not in ("seq", "batch"):
        print("⚠ order 应为 seq/batch，收到「%s」，按 seq 处理" % order)
        order = "seq"
    spids = [sh.shape_id for sh in shapes]
    try:
        xml = build_timing_xml(spids, kind, order, dur, delay)
        if xml is None:
            return 0
        el = etree.fromstring(xml)
        sld = slide.element
        old = sld.find("{%s}timing" % P_NS)
        if old is not None:
            sld.remove(old)
        sld.append(el)
        return len(spids)
    except Exception as e:                    # noqa: BLE001 —— 动画失败不拖垮整片
        print("⚠ 本页动画注入失败（已跳过，不影响成片）：%s" % e)
        return 0
