#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PPT一键生成 · 视觉资产引擎（gen_assets.py）
==========================================
PIL 真实出图，三类资产：
  make_cover_bg(theme)  封面/结尾背景：深色渐变 + 金描边双框 + 金上扬折线 + 三白点
  make_icon(theme, label) 品类图标：主色圆底 + 金圈 + 白字
  make_badge(text, color) 圆角徽章

中文字体自动探测（Noto CJK / 思源 / 文泉驿），找不到时给出可操作的修复指引。
所有函数返回 PNG 文件路径（临时目录），生成即用，无需用户管理文件。
"""
import glob
import math
import os
import tempfile

from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ───────── 字体探测（找不到给统一报错，不带假路径裸奔） ─────────
_FONT_ROOTS = ["/usr/share/fonts", "/usr/local/share/fonts",
               os.path.expanduser("~/.fonts"), os.path.expanduser("~/.local/share/fonts")]

def find_cjk_font(bold=False):
    pats = ["*NotoSansCJK*Bol*.tt*", "*NotoSansSC*Bol*.tt*", "*SourceHanSans*Bol*.tt*",
            "*wqy*micro*.tt*"] if bold else \
           ["*NotoSansCJK*Reg*.tt*", "*NotoSansSC*Reg*.tt*", "*SourceHanSans*Reg*.tt*",
            "*NotoSansCJK*.tt*", "*wqy*micro*.tt*"]
    for root in _FONT_ROOTS:
        for pat in pats:
            hits = glob.glob(os.path.join(root, "**", pat), recursive=True)
            if hits:
                return sorted(hits)[0]
    return None

def _font(size, bold=False):
    path = find_cjk_font(bold)
    if path:
        return ImageFont.truetype(path, size)
    # 无中文字体：回退 PIL 默认并提示（不中断，但出图中文会缺字）
    print("⚠ 未找到中文字体，图形内中文可能显示不全。修复：sudo apt install fonts-noto-cjk")
    return ImageFont.load_default()

def _hex2rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def _mix(c1, c2, t):
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))

# ───────── 封面/结尾背景 ─────────
def make_cover_bg(theme, out=None, W=1920, H=1080):
    """深色渐变底（主题主色压暗）+ 金描边双框 + 金上扬折线箭头 + 底部三白点。"""
    primary = _hex2rgb(theme["primary"])
    accent = _hex2rgb(theme.get("accent", "#F2CB57"))
    top = _mix(primary, (0, 0, 0), 0.72)     # 顶部更深
    bot = _mix(primary, (0, 0, 0), 0.45)     # 底部略提
    img = Image.new("RGB", (W, H), top)
    d = ImageDraw.Draw(img)
    for y in range(H):                        # 垂直渐变
        d.line([(0, y), (W, y)], fill=_mix(top, bot, y / H))
    # 轻噪点提升质感
    import random
    rnd = random.Random(42)
    for _ in range(900):
        x, y = rnd.randrange(W), rnd.randrange(H)
        d.point((x, y), fill=_mix(top, bot, rnd.random()))
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    d = ImageDraw.Draw(img)
    m1, m2 = 14, 6 + 14                       # 双框：贴边 14px + 内缩 20px
    d.rectangle([m1, m1, W - m1 - 1, H - m1 - 1], outline=accent, width=4)
    d.rectangle([m2, m2, W - m2 - 1, H - m2 - 1], outline=_mix(accent, top, 0.55), width=2)
    # 金上扬折线 + 箭头（右中区域，低饱和不抢主标）
    pts = [(int(W * 0.58), int(H * 0.80)), (int(W * 0.70), int(H * 0.66)),
           (int(W * 0.78), int(H * 0.72)), (int(W * 0.88), int(H * 0.52))]
    line_c = _mix(accent, top, 0.25)
    for i in range(len(pts) - 1):
        d.line([pts[i], pts[i + 1]], fill=line_c, width=6)
    ax, ay = pts[-1]
    d.polygon([(ax - 4, ay - 30), (ax + 24, ay - 22), (ax + 2, ay - 2)], fill=line_c)
    # 底部三白点
    for i in range(3):
        cx = int(W * 0.5) + (i - 1) * 34
        d.ellipse([cx - 5, H - 74 - 5, cx + 5, H - 74 + 5], fill=(240, 240, 238))
    out = out or os.path.join(tempfile.mkdtemp(prefix="pptassets_"), "cover_bg.png")
    img.save(out, "PNG")
    return out

# ───────── 品类图标 ─────────
def make_icon(theme, label, out=None, S=512):
    """圆形图标：主色底 + 金圈 + 白字（label 1-4 字自动缩放）。"""
    primary = _hex2rgb(theme["primary"])
    accent = _hex2rgb(theme.get("accent", "#F2CB57"))
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = 18
    d.ellipse([pad, pad, S - pad, S - pad], fill=primary + (255,))
    d.ellipse([pad + 14, pad + 14, S - pad - 14, S - pad - 14],
              outline=accent + (255,), width=10)
    label = (label or "图")[:4]
    size = int(S * 0.42) if len(label) == 1 else int(S * 0.30)
    f = _font(size, bold=True)
    tw = d.textlength(label, font=f)
    while tw > S * 0.62 and size > 20:        # 防溢出
        size -= 6
        f = _font(size, bold=True)
        tw = d.textlength(label, font=f)
    bbox = d.textbbox((0, 0), label, font=f)
    th = bbox[3] - bbox[1]
    d.text(((S - tw) / 2, (S - th) / 2 - bbox[1]), label, font=f, fill=(246, 243, 236, 255))
    out = out or os.path.join(tempfile.mkdtemp(prefix="pptassets_"), "icon.png")
    img.save(out, "PNG")
    return out

# ───────── 徽章 ─────────
def make_badge(text, color, out=None, W=420, H=120):
    c = _hex2rgb(color)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([6, 6, W - 6, H - 6], radius=H // 3, fill=c + (235,))
    f = _font(52, bold=True)
    text = (text or "")[:8]
    tw = d.textlength(text, font=f)
    while tw > W * 0.8 and len(text) > 2:
        text = text[:-1]
        tw = d.textlength(text + "…", font=f)
    if d.textlength(text, font=f) > W * 0.8:
        text = text[:-1] + "…"
        tw = d.textlength(text, font=f)
    bbox = d.textbbox((0, 0), text, font=f)
    d.text(((W - tw) / 2, (H - (bbox[3] - bbox[1])) / 2 - bbox[1]), text,
           font=f, fill=(255, 255, 255, 255))
    out = out or os.path.join(tempfile.mkdtemp(prefix="pptassets_"), "badge.png")
    img.save(out, "PNG")
    return out

if __name__ == "__main__":
    t = {"primary": "#0E5A8A", "accent": "#F2CB57"}
    print("cover :", make_cover_bg(t))
    print("icon  :", make_icon(t, "增长"))
    print("badge :", make_badge("示例数据", "#0E5A8A"))
