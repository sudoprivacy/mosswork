# S Square 认知引擎 · Skill 打包脚本
# 用法: powershell -ExecutionPolicy Bypass -File scripts/pack.ps1

$ErrorActionPreference = "Stop"
$SkillRoot = Split-Path -Parent $PSScriptRoot
$DistDir = Join-Path $SkillRoot "dist"
$Version = "1.1.0"
$ZipName = "s-square-cognitive-engine-v$Version.zip"
$ZipPath = Join-Path $DistDir $ZipName

$Include = @(
    "SKILL.md",
    "manifest.json",
    "assets",
    "examples",
    "references",
    "scripts"
)

if (-not (Test-Path (Join-Path $SkillRoot "SKILL.md"))) {
    Write-Error "SKILL.md not found in $SkillRoot"
}

New-Item -ItemType Directory -Force -Path $DistDir | Out-Null

$Stage = Join-Path $env:TEMP "s-square-skill-pack-$([guid]::NewGuid().ToString('N'))"
New-Item -ItemType Directory -Force -Path $Stage | Out-Null

foreach ($item in $Include) {
    $src = Join-Path $SkillRoot $item
    if (Test-Path $src) {
        Copy-Item -Path $src -Destination (Join-Path $Stage $item) -Recurse -Force
    }
}

if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
Compress-Archive -Path (Join-Path $Stage "*") -DestinationPath $ZipPath -Force
Remove-Item $Stage -Recurse -Force

$sizeMb = [math]::Round((Get-Item $ZipPath).Length / 1MB, 2)
Write-Host "OK: $ZipPath ($sizeMb MB)"

if ($sizeMb -gt 10) {
    Write-Warning "Package exceeds 10MB store limit"
    exit 1
}
