# Coze Bot 逐步配置指南 · 第二步（v1.1）

**预计耗时**：单 Agent MVP 约 45–90 分钟 · 工作流完整版 3–4 小时  
**前置文件**：`dist/s-square-cognitive-engine-v1.1.0.zip`  
**平台**：[扣子 Coze](https://www.coze.cn)（国内）/ [coze.com](https://www.coze.com)（海外）

---

## 路线选择

| 路线 | 适合 | 难度 | 本指南章节 |
|------|------|------|------------|
| **A · 单 Agent MVP** | 快速上架验证 | ⭐⭐ | §1–§5、§8、§9 |
| **B · 工作流 + 数据库** | 持久化 streak/回访 | ⭐⭐⭐⭐ | 全文 |

**建议**：先走 **路线 A** 上架，验证留存后再升级路线 B。

---

## §0 · 准备清单

- [ ] 已解压或保留 zip：`dist/s-square-cognitive-engine-v1.1.0.zip`
- [ ] Coze 账号（建议企业/个人实名，便于上架）
- [ ] 模型：豆包 / GPT-4o-mini 等（分类建议 temperature≤0.3）
- [ ] 封面图：`assets/skill_icon.png`
- [ ] 测试用手机号或 Coze 调试窗口

---

## §1 · 上传 Skill 知识包（Coze）

### 1.1 解压 zip

解压到本地，确认根目录有 `SKILL.md` 和 `manifest.json`。

### 1.2 扣子「技能 / 知识库」入口（二选一）

**方式 1 · 作为 Bot 知识库（推荐 MVP）**

1. 登录 Coze → 左侧 **「知识库」**
2. 点击 **「创建知识库」**
3. 名称：`S Square 认知引擎 v1.1`
4. 上传以下文件（可多选）：

| 优先级 | 文件 |
|--------|------|
| 必传 | `SKILL.md` |
| 必传 | `references/error-classification-prompt.md` |
| 必传 | `references/bot-conversation-flow.md` |
| 推荐 | `references/interventions-seed-library.md` |
| 推荐 | `examples/sample-daily-log.md` |
| 可选 | `references/scientific-foundation-v1.1.md` |

5. 分段策略：**按 Markdown 标题分段**
6. 保存 → 等待索引完成（绿色「可用」）

**方式 2 · 扣子编程 Skill 包（若你的账号有「技能商店/编程」入口）**

1. 进入 **扣子编程** 或 **Skill 开发**
2. **导入技能包** → 选择 `s-square-cognitive-engine-v1.1.0.zip`
3. 确认 `manifest.json` 被识别，根文件为 `SKILL.md`

> 不同 Coze 版本菜单名可能为「插件」「技能」「Bot SDK」——核心是把 `SKILL.md` 注入 Agent 可读知识。

---

## §2 · 创建 Bot（路线 A · 单 Agent）

### 2.1 新建 Bot

1. Coze 首页 → **「创建 Bot」**
2. 名称：**S Square 认知教练**
3. 模式：选择 **「单 Agent（LLM 模式）」**（勿选工作流，MVP 更快）
4. 图标：上传 `assets/skill_icon.png`
5. 简介（复制）：

```
PEG 预测误差增益 · 觉醒三问 · if-then 实施意图 · pre-mortem · 校准曲线 · 元认知教练。不替你做决策，帮你看清预测模型哪里该重算。
```

### 2.2 绑定知识库

1. 进入 Bot → **「知识库」** 或 **「技能」** 面板
2. **添加** 上一步创建的 `S Square 认知引擎 v1.1`
3. 召回策略：**自动召回** 或 **按需召回**（建议自动，阈值 0.5）

### 2.3 人设与回复逻辑（System Prompt）

进入 **「人设与回复逻辑」** → **「系统提示词」**，粘贴以下内容（可微调）：

```text
你是「S Square 认知教练」v1.1——用户的元认知教练，不是心理咨询师。

## 铁律
1. 不替用户决策；只评估预测模型与校准缺口
2. 觉醒三问必须逐条提问，禁止一次抛出三问
3. 「重来」必须格式化为 if-then：当[情境]发生时，我将[行为]
4. 禁止空洞安慰（「别担心」「你已经很棒了」）
5. 检测到自伤倾向 → 停止挑战，提供 400-161-9995
6. 过程 praise，禁止身份标签（「你是 XX 型人」）

## 工作流优先级
- 新用户：Onboarding（欢迎→角色 A-E→skill_level→首条日志）
- 主菜单关键词：开始/菜单/1日志/2仪表盘/3挑战/4复盘/预测/回访
- 日志完成后：按 error-classification-prompt 规则输出分类 + PEG
- 仪表盘：校准曲线 + 挑战-技能平衡 + 五维（文字版）
- 微挑战前：COM-B 两问（时间窗口、社交能量）

## PEG 公式
PEG = |outcome_deviation - prior_score| × category_weight × hypercorrection(1.3 if prior≥8) × digestion(0.5 if-then / 0.6 adjusted / 1.0)

## 角色基准 peg_baseline
创业者22 / 产品20 / 技术18 / 市场21 / 其他19

## 知识库
详细话术与分支见 bot-conversation-flow.md；分类细则见 error-classification-prompt.md；微挑战见 interventions-seed-library.md。

## 开场
新对话先说隐私声明，再问角色或展示主菜单。
```

### 2.4 模型参数

| 参数 | 建议值 |
|------|--------|
| 模型 | 豆包 Pro / GPT-4o |
| 温度 | **0.3**（日志引导可 0.5，分类时 mentally 要求精确） |
| 最大回复 | 2048 tokens |
| 携带上下文轮数 | 20+ |

### 2.5 开场白（Prologue）

```text
欢迎来到 S Square 认知教练。

我不替你决策，但会帮你看清：你的预测模型，此刻健康吗？

🔒 原始日志只保存在本会话，我只处理结构化标签。

回复「开始」 onboarding，或「菜单」查看功能。
```

### 2.6 预置问题（Suggested Questions）

在 **「开场白 / 预置问题」** 添加：

```
1. 开始今日觉醒三问
2. 查看认知仪表盘
3. 写一张预测卡（pre-mortem）
4. 今日微挑战
```

---

## §3 · 创建「误差分类」插件（可选但推荐）

单 Agent 可直接在人设里分类；独立插件更稳定。

### 3.1 新建插件

1. 左侧 **「插件」** → **「创建插件」**
2. 名称：`ssquare_error_classify`
3. 类型：**基于已有服务** 或 **Prompt 插件**（视 Coze 版本）

### 3.2 Prompt 插件配置

- **System**：复制 `references/error-classification-prompt.md` 中 `## 1. System Prompt` 整段
- **User 模板**：复制同文件 `## 3. User Prompt 模板`
- **输出**：JSON 模式（若支持 JSON Schema，粘贴 Schema 段）

### 3.3 绑定到 Bot

1. Bot 编辑页 → **「插件」** → 添加 `ssquare_error_classify`
2. 在人设中补充：

```text
当用户完成觉醒三问后，调用 ssquare_error_classify 插件，将返回 JSON 解析为用户可见摘要，不要直接输出 raw JSON。
```

---

## §4 · 变量与记忆（路线 A 简化版）

Coze **「变量」** 或 **「数据库」**（若可用）：

### 4.1 Bot 变量（最少集）

| 变量名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| `role_type` | string | "" | 创业者/产品/… |
| `peg_baseline` | number | 19 | |
| `skill_level` | number | 5 | |
| `streak_days` | number | 0 | |
| `onboarding_done` | boolean | false | |
| `current_step` | string | "menu" | 状态机 |
| `events_json` | string | "[]" | 事件摘要 JSON |

### 4.2 在人设中说明变量用法

```text
每完成一条日志，将 events_json 追加一条摘要，streak_days+1。
onboarding_done=false 时任何输入先走 Onboarding。
current_step 取值：menu | log_t1 | log_t2 | log_t3 | log_t4 | predict | ...
```

> **路线 A 限制**：无真实 DB 时，变量在长时间对话后可能丢失——MVP 可接受；路线 B 用数据库解决。

---

## §5 · 调试（路线 A 必做 7 条）

Bot 编辑页右侧 **「预览与调试」**：

| # | 发送 | 期望 |
|---|------|------|
| 1 | `开始` | 欢迎 + 隐私 + 角色选择 |
| 2 | `A` | 创业者 + 问 skill_level |
| 3 | `5` | 进入意外问 |
| 4 | 完整走完三问+if-then | 分类 + PEG，非一次性三问 |
| 5 | `仪表盘` | 校准+flow 文字版 |
| 6 | `预测` | 预测卡 5 字段引导 |
| 7 | `今天心情不太好` | 追问 clarification，不强行分类 |

**不通过**：回到人设，强调「逐问引导」；或提高知识库召回。

---

## §6 · 路线 B · 工作流 + 数据库（进阶）

### 6.1 创建数据库表

Bot → **「数据库」** → 创建表 `user_events`：

| 字段 | 类型 |
|------|------|
| user_id | string |
| event_date | string |
| error_category | string |
| prior_score | number |
| outcome_deviation | number |
| peg_delta | number |
| implementation_intention | string |
| emotion_words | string |

表 `user_profile`：`user_id, role_type, peg_baseline, skill_level, streak_days, onboarding_done`

### 6.2 切换到工作流模式

1. Bot 设置 → 模式改为 **「工作流」**
2. 新建工作流 `main_router`

**节点拓扑**：

```text
[开始] → [意图识别 LLM]
           ├─ onboarding → [子流程 onboarding]
           ├─ tab1_log → [子流程 log_state_machine]
           ├─ tab2_dashboard → [代码/LLM 聚合 events]
           ├─ tab3_challenge → [COM-B 问 → 查 interventions 知识库]
           └─ default → [主菜单输出]
```

### 6.3 日志子流程 `log_state_machine`

用 **「选择器」** 或 **变量 current_step** 驱动：

```
log_t1 → 输出意外问 → 等待输入 → 存 surprise
log_t2 → 预期 + prior
log_t3 → if-then
log_t4 → 情绪三词 + deviation
→ [插件 classify] → [写数据库] → [输出反馈]
```

### 6.4 定时任务（7 天回访 / 周日复盘）

1. **「触发器」** → 定时 / Cron
2. 周日 20:00 → 向活跃用户数推送「本周复盘」
3. 7 天回访：需 **数据库查询** `event_date + 7天` → 推送模板（路线 B）

> MVP 可跳过定时器，用户手动发「回访」。

---

## §7 · 微挑战库导入

1. 知识库新建 **`interventions`**，上传 `interventions-seed-library.md`
2. 或数据库表 `interventions`：字段 `trigger_condition, content, priority`
3. Bot 推送挑战时 Prompt：

```text
根据用户 COM-B 答案（时间/社交能量）和 weekly_metrics，
从 interventions 知识库匹配 1 条，排除用户 7 天内已完成内容。
```

---

## §8 · 发布到扣子商店

### 8.1 发布 Bot

1. Bot 编辑页右上角 **「发布」**
2. 选择渠道：**扣子 Bot 商店** / 豆包 / 微信（按需）
3. 填写：

| 字段 | 内容 |
|------|------|
| 名称 | S Square 认知教练 |
| 分类 | 效率工具 / 教育 / 生活方式 |
| 标签 | 元认知、日记、复盘、pre-mortem |
| 封面 | skill_icon.png |
| 详情 | 见 publish-checklist.md |

### 8.2 精选案例（粘贴到商品页）

使用 `examples/sample-daily-log.md` 中 **用户可见反馈** 段落。

### 8.3 审核

- 强调 **非心理咨询**（COPYRIGHT.md）
- 危机资源 400-161-9995 已在人设中
- 审核周期通常 1–5 个工作日

---

## §9 · 上传 SkillHub

### 9.1 CLI 方式

```bash
cd c:\Users\admin\.cursor\skills\s-square-cognitive-engine
npx clawhub publish .
```

按提示选择 namespace、visibility（PUBLIC）。

### 9.2 Web 方式

1. 打开 SkillHub `/dashboard/publish`
2. 上传 `dist/s-square-cognitive-engine-v1.1.0.zip`
3. 填写与 Coze 相同的名称/简介/封面
4. 等待 `PENDING_REVIEW`

### 9.3 SkillHub 与 Coze 关系

| 项 | SkillHub | Coze Bot |
|----|----------|----------|
| 产物 | Skill 包（给 Agent 读） | 可对话 Bot |
| 用户 | Cursor/Claw 生态 | 扣子/豆包用户 |
| 建议 | 两个都上，互相引流 |

---

## §10 · 常见问题

**Q：Bot 一次问完三问怎么办？**  
A：人设置顶加粗「禁止合并三问」；温度降到 0.2；加预置 workflow 示例。

**Q：PEG 数字和 Cursor 不一致？**  
A：检查 if-then 消化因子 0.5 是否生效；category_weight 是否一致。

**Q：知识库召回不到 interventions？**  
A：单独建 interventions 知识库；提问时显式「从微挑战库选一条」。

**Q：没有「数据库」菜单？**  
A：账号/版本限制，继续用路线 A + 变量；或接 **飞书多维表格** 插件。

**Q：zip 上传 Coze 没反应？**  
A：Coze 商店要的是 **Bot 发布**，不是 zip；zip 用于 SkillHub 或知识库单文件上传。

---

## §11 · 完成检查清单

```
路线 A MVP
- [ ] 知识库已索引 SKILL.md + error-classification-prompt
- [ ] Bot 人设已粘贴 §2.3
- [ ] 开场白 + 4 条预置问题
- [ ] §5 七条调试通过
- [ ] 扣子商店已提交审核

路线 B（可选）
- [ ] 数据库表 user_events / user_profile
- [ ] 工作流 log_state_machine
- [ ] 定时复盘/回访

SkillHub
- [ ] zip 已上传或 clawhub publish 成功
```

---

## 相关文档

- 对话话术全集：`bot-conversation-flow.md`
- 分类 Prompt：`error-classification-prompt.md`
- 上架字段：`publish-checklist.md`
- 版权免责声明：`COPYRIGHT.md`

---

*Coze 配置指南 v1.1 · S Square Lab · 2026-07-21*
