# S Square 认知引擎 · 技术开发需求文档（PRD）

**文档版本**：v1.1（科学修订版）  
**文档类型**：Product Requirements Document  
**产品名称**：S Square 认知引擎 · 元 Skill 自我成长系统  
**最后更新**：2026-07-21

### 修订日志

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.1 | 2026-07-21 | PEG 主度量 · 校准曲线 · 挑战-技能平衡 · if-then · 第四问双环 · 7天AR回访 · 预测卡 · 间隔检索 · COM-B · CV替代BV · PHQ-2筛查 |
| v1.0 | 2026-07-21 | 初版 |

详见 [scientific-foundation-v1.1.md](scientific-foundation-v1.1.md)

---

## 1. 文档概述

### 1.1 目的

本文档为 S Square 认知引擎的产品与技术团队提供统一的需求基准，涵盖产品定位、系统架构、数据模型、功能规格、分阶段路线图、非功能需求及商业化策略，可直接用于：

- 项目立项与资源评估
- 后端 / 前端 / 算法工程师开发排期
- QA 测试用例编写
- 运营冷启动执行

### 1.2 产品一句话定位

构建「技能的操作系统」——通过量化认知熵，持续进化元认知，实现人类大脑的贝叶斯推理工程化。

### 1.3 核心定位

| 维度 | 说明 |
|------|------|
| 本质 | **元 Skill 引擎**（技能生成器），非单一技能 App |
| 功能 | 「感知-认知-行动-监控」增强回路，将元认知能力转化为可量化、可干预、可迭代的系统工程 |
| 终局 | 成为未来社会的**认知基础设施**，为个人/团队/生态提供统一的「认知熵度量衡」 |

### 1.4 目标用户

- Primary：知识工作者（创业者、产品经理、工程师、市场人员）
- Secondary：追求元认知训练的终身学习者
- Tertiary（Phase 3）：企业团队管理者

### 1.5 成功指标（North Star Metrics）

| 指标 | MVP 目标（90 天） | 说明 |
|------|-------------------|------|
| D7 留存 | ≥ 35% | 验证习惯养成 |
| 周活跃记录率 | ≥ 4 天/周 | 核心行为 |
| 微挑战完成率 | ≥ 45% | 干预有效性 |
| 30 天图谱生成率 | ≥ 15% 注册用户 | 长期价值验证 |
| 付费转化率 | ≥ 5%（免费试用后） | 商业验证 |

---

## 2. 底层科学理论（设计约束 · v1.1）

所有功能设计**必须**严格遵循以下八条第一性原理（详见 scientific-foundation-v1.1.md）：

| # | 理论 | 系统映射 |
|---|------|----------|
| ① | 预测加工（Clark/Hohwy） | 预测卡 + 觉醒三问 + 误差分类 |
| ② | 元认知校准（Lichtenstein/Fischhoff） | 校准曲线 + Calibration Gap |
| ③ | 心流/挑战-技能平衡（Csikszentmihalyi） | 仪表盘主视觉 flow_index |
| ④ | 双环学习（Argyris & Schön） | 第四问 + 季度重置 |
| ⑤ | 实施意图（Gollwitzer） | if-then 格式化 |
| ⑥ | Desirable difficulties（Bjork） | 微挑战 + 间隔误差检索 |
| ⑦ | 情绪粒度（Barrett/Kashdan） | 三词情绪命名 |
| ⑧ | COM-B 行为改变（Michie/MRC） | 挑战推送前诊断 |

**设计哲学（非硬约束）**：认知负荷三分法 · 神经可塑性组块化 · 自由能原理（内部参考，不对用户表述）

### 2.1 核心量化基石：PEG（预测误差增益）

- **品牌别名**：认知熵 CE（用户可见，向后兼容 `entropy_delta` 字段）
- **科学名称**：Prediction Error Gain (PEG)
- **公式**：

```
PEG = |outcome_deviation − prior_score|
      × category_weight
      × hypercorrection_bonus    # prior≥8 → 1.3
      × digestion_factor         # if-then→0.5; adjustment→0.6; else→1.0
```

- **校准缺口**：`CG = AVG(prior_score) − AVG(10 − outcome_deviation)`
- **挑战-技能平衡**：`flow_index = challenge_level − skill_level`（主仪表盘区间判断，替代倒 U 熵曲线）

---

## 3. 系统架构

### 3.1 四层神经网络模型

```text
┌─────────────────────────────────────────────────────────────┐
│             第四层：元认知监控层（Meta-Cognition）           │
│     功能：观察者模式 + 认知熵仪表盘 + 季度重置日             │
│     神经靶点：前额叶极区（BA10）+ 默认模式网络（DMN）        │
│                     ↑ 反馈调节信号 ↓                        │
├─────────────────────────────────────────────────────────────┤
│             第三层：行动闭环层（Action Loop）                │
│     功能：最小单元执行 → 误差捕获 → 策略调整                 │
│     神经靶点：基底节（组块化）+ 小脑（自动化）               │
│                     ↑ 提供数据输入 ↓                        │
├─────────────────────────────────────────────────────────────┤
│             第二层：认知加工层（Cognitive Processing）        │
│     功能：知识分层存储 + 三句话强制提炼（费曼技巧）           │
│     神经靶点：海马体（长时编码）+ 前额叶（工作记忆）          │
│                     ↑ 建立预测模型 ↓                        │
├─────────────────────────────────────────────────────────────┤
│             第一层：感知校准层（Perception Calibration）      │
│     功能：达克效应破局 + 认知审计 + 确认偏误对抗             │
│     神经靶点：前扣带回（ACC，冲突检测）+ 前脑岛（内感受）     │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 技术架构（推荐）

```text
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  Client      │     │  API Gateway │     │  Core API    │
│  Web/H5/小程序│────▶│  Auth/Rate   │────▶│  FastAPI/    │
│  Bot (Coze)  │     │  Limit       │     │  Node.js     │
└──────────────┘     └──────────────┘     └──────┬───────┘
                                                  │
                    ┌─────────────────────────────┼─────────────────────────────┐
                    ▼                             ▼                             ▼
            ┌──────────────┐              ┌──────────────┐              ┌──────────────┐
            │ PostgreSQL   │              │ LLM Service  │              │ Rule Engine  │
            │ + RLS        │              │ GPT-4o-mini  │              │ Interventions│
            └──────────────┘              └──────────────┘              └──────────────┘
                    │
                    ▼
            ┌──────────────┐
            │ Redis Cache  │
            │ (sessions)   │
            └──────────────┘
```

### 3.3 数据流

1. **采集**：用户提交觉醒三问 → 本地加密存储原始文本
2. **脱敏**：客户端/Edge 提取结构化字段 → 上传云端
3. **分类**：LLM API 误差预分类 → 写入 events
4. **计算**：定时任务聚合 CE 五维指标
5. **干预**：规则引擎匹配 interventions → 推送微挑战
6. **反馈**：用户响应 → 更新 AR/BV 等指标

---

## 4. 核心量化指标（v1.1）

| 指标 | 代号 | 定义 | 健康范围 | 触发干预 |
|------|------|------|----------|----------|
| 高置信失误率 | ER | prior≥7 且 deviation≥6 的事件 / 总记录 | 15%~25% | <10% 增难；>35% 降维 |
| 真实调整率 | AR | **7天回访**确认执行 if-then 次数 / 标记调整总数 | >60% | <50% 主动失败专项 |
| 深度困惑 | PTR | 今日 ≥10min 无法用旧模型解释（二元）或 ESM 1-5 | 4~5天/周 | 过少→新领域；过多→整合 |
| 情绪粒度 | NA | 3 个不同情绪词描述今日 | 持续改善 | 3天失败→内感受练习 |
| 认知变异度 | CV | 尝试非默认决策路径的天数/周 | ≥4天/周 | 3天为0→认知挑战 |

**v1.0 废弃**：BV（行为变异度）· PTR 分钟自报 · AR 纯自报

### 4.1 PEG 与 Flow 聚合（服务端）

```python
def calc_peg(prior, outcome, category, has_if_then, adjusted):
    weights = {"未知未知":1.2,"逻辑谬误":1.0,"信息缺失":0.9,"惯性假设":0.8,"情绪干扰":0.7}
    raw = abs(outcome - prior) * weights[category]
    hyper = 1.3 if prior >= 8 else 1.0
    digest = 0.5 if has_if_then else (0.6 if adjusted else 1.0)
    return round(raw * hyper * digest, 2)

# 区间（flow_index = challenge_level - skill_level）
# flow_index < -2  → rigid
# -2 ≤ flow_index ≤ 2 → peak
# flow_index > 2   → anxiety
```

---

## 5. 数据模型

**数据库**：PostgreSQL 14+  
**安全**：Row Level Security (RLS) 按 user_id 隔离

### 5.1 用户表 `users`

| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| user_id | UUID | PK | 主键 |
| role_type | VARCHAR(20) | NOT NULL | 创业者/产品/技术/市场/其他 |
| entropy_baseline | DECIMAL(5,2) | NOT NULL DEFAULT 19.0 | PEG 基准线（别名 peg_baseline） |
| skill_level | INT | CHECK 1-10 DEFAULT 5 | 挑战-技能平衡自评 |
| challenge_level | INT | CHECK 1-10 DEFAULT 5 | 每周更新 |
| member_since | TIMESTAMP | NOT NULL DEFAULT NOW() | 注册时间 |
| subscription_tier | VARCHAR(20) | NOT NULL DEFAULT 'free' | free/pro/enterprise |
| streak_days | INT | DEFAULT 0 | 连续打卡天数 |
| last_log_date | DATE | NULL | 最近记录日期 |
| created_at | TIMESTAMP | NOT NULL DEFAULT NOW() | |
| updated_at | TIMESTAMP | NOT NULL DEFAULT NOW() | |

**索引**：`idx_users_subscription` ON (subscription_tier)

### 5.2 事件日志表 `events`（核心资产）

> **隐私设计**：用户输入的原始文本（含隐私内容）默认仅存储在本地设备；云端只接收经脱敏处理后的分类标签与数值。

| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| event_id | UUID | PK | 主键 |
| user_id | UUID | FK → users | 外键 |
| event_date | DATE | NOT NULL | 事件发生日期 |
| error_category | VARCHAR(20) | NOT NULL | 信息缺失/逻辑谬误/情绪干扰/惯性假设/未知未知 |
| prior_score | INT | CHECK 1-10 | 用户自评预期准确率 |
| outcome_deviation | INT | CHECK 1-10 | 自评结果偏差度 |
| adjustment_made | BOOLEAN | NOT NULL DEFAULT false | 是否调整后续策略 |
| emotional_tag | VARCHAR(10) | NOT NULL | 平静/焦虑/兴奋/困惑/沮丧 |
| entropy_delta | DECIMAL(5,2) | NOT NULL | PEG 值（向后兼容字段名） |
| peg_delta | DECIMAL(5,2) | NULL | v1.1 显式字段，= entropy_delta |
| prediction_level | VARCHAR(5) | NULL | L1/L2/L3/L4 |
| implementation_intention | TEXT | NULL | if-then 实施意图 |
| falsifier | TEXT | NULL | 可证伪条件 |
| emotion_words | JSONB | NULL | 三词情绪命名 ["词1","词2","词3"] |
| hypercorrection | BOOLEAN | DEFAULT false | prior≥8 且 deviation≥6 |
| local_ref_id | VARCHAR(64) | NULL | 本地原文引用 ID（非原文） |
| created_at | TIMESTAMP | NOT NULL DEFAULT NOW() | |

**索引**：
- `idx_events_user_date` ON (user_id, event_date DESC)
- `idx_events_category` ON (user_id, error_category)

### 5.3 每周复盘表 `weekly_reviews`

| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| review_id | UUID | PK | 主键 |
| user_id | UUID | FK → users | 外键 |
| week_start_date | DATE | NOT NULL | 周起始日（周一） |
| entropy_avg | DECIMAL(5,2) | NOT NULL | 周平均熵值 |
| error_distribution | JSONB | NOT NULL | 五类误差占比 |
| focus_dimension | VARCHAR(20) | NOT NULL | 下周训练维度 |
| cognitive_milestone | TEXT | NOT NULL | 本周最重要认知修正 |
| metrics_snapshot | JSONB | NULL | ER/AR/PTR/NA/BV 快照 |
| created_at | TIMESTAMP | NOT NULL DEFAULT NOW() | |

**唯一约束**：UNIQUE (user_id, week_start_date)

### 5.4 系统干预策略库 `interventions`

| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| task_id | UUID | PK | 主键 |
| trigger_condition | VARCHAR(50) | NOT NULL | 如 `error_rate < 10%` |
| intervention_type | VARCHAR(20) | NOT NULL | 微挑战/季度重置/暂停提醒 |
| content | TEXT | NOT NULL | 干预指令内容 |
| priority | INT | DEFAULT 0 | 匹配优先级 |
| is_active | BOOLEAN | DEFAULT true | |
| created_at | TIMESTAMP | NOT NULL DEFAULT NOW() | |

**索引**：`idx_interventions_trigger` ON (trigger_condition, is_active)

### 5.5 微挑战响应表 `intervention_responses`（扩展）

| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| response_id | UUID | PK | |
| user_id | UUID | FK | |
| task_id | UUID | FK → interventions | |
| response | VARCHAR(10) | NOT NULL | completed/skipped |
| responded_at | TIMESTAMP | NOT NULL DEFAULT NOW() | |

### 5.6 预测卡表 `predictions`（v1.1）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| prediction_id | UUID | PK |
| user_id | UUID | FK |
| event_date | DATE | 预测目标日期 |
| event_desc | TEXT | 事件描述 |
| prediction | TEXT | 预测内容 |
| confidence | INT | 1-10 |
| falsifier | TEXT | 证伪条件 |
| premortem | TEXT | pre-mortem 答案 |
| outcome_matched | BOOLEAN | NULL 直至事后配对 |
| linked_event_id | UUID | FK → events |

### 5.7 调整回访表 `adjustment_followups`（v1.1）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| followup_id | UUID | PK |
| event_id | UUID | FK → events |
| scheduled_date | DATE | 标记后第 7 天 |
| actual_executed | INT | 0 / 1-2 / 3+ |
| verified_at | TIMESTAMP | |

### 5.8 间隔检索表 `error_reviews`（v1.1）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| review_id | UUID | PK |
| event_id | UUID | FK |
| review_type | VARCHAR(10) | day3 / day7 / day30 |
| user_recall | TEXT | 用户复述 |
| chunk_mastered | BOOLEAN | day30 组块化标记 |

### 5.9 心智筛查表 `mental_screenings`（v1.1）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| screening_id | UUID | PK |
| user_id | UUID | FK |
| phq2_score | INT | 0-6 |
| gad2_score | INT | 0-6 |
| screened_at | TIMESTAMP | |

### 5.10 ER 图（简）

```text
users 1───N events
users 1───N predictions
users 1───N weekly_reviews
users 1───N intervention_responses
users 1───N mental_screenings
events 1───N adjustment_followups
events 1───N error_reviews
interventions 1───N intervention_responses
predictions N───1 events (linked_event_id)
```

---

## 6. API 规格（REST）

**Base URL**：`/api/v1`  
**Auth**：JWT Bearer Token / 微信 OAuth 2.0

### 6.1 用户与 Onboarding

| Method | Path | 说明 |
|--------|------|------|
| POST | `/auth/register` | 注册 + role_type |
| POST | `/auth/login` | 登录 |
| GET | `/users/me` | 当前用户信息 |
| PATCH | `/users/me/baseline` | 重新校准基线（季度重置） |

**POST `/auth/register` Request**：

```json
{
  "role_type": "产品",
  "oauth_provider": "wechat",
  "oauth_token": "..."
}
```

**Response 201**：

```json
{
  "user_id": "uuid",
  "entropy_baseline": 20.0,
  "subscription_tier": "free",
  "trial_expires_at": "2026-07-28T00:00:00Z"
}
```

### 6.2 事件日志

| Method | Path | 说明 |
|--------|------|------|
| POST | `/events` | 创建认知日志 |
| GET | `/events` | 列表（分页，按日期倒序） |
| GET | `/events/stats` | 聚合统计（误差分布、CE 趋势） |

**POST `/events` Request**：

```json
{
  "event_date": "2026-07-21",
  "surprise": "会议结论与预期相反",
  "expectation": "客户会接受方案 A",
  "retry": "下次先确认决策链",
  "implementation_intention": "当客户口头确认时，我将追问否决权并邮件确认",
  "prior_score": 7,
  "outcome_deviation": 4,
  "adjustment_made": true,
  "emotional_tag": "困惑",
  "emotion_words": ["困惑", "挫败", "警觉"],
  "falsifier": "若客户主动提竞品，说明我预测框架错了"
}
```

**Response 201**（含 LLM 分类结果）：

```json
{
  "event_id": "uuid",
  "error_category": "逻辑谬误",
  "prediction_level": "L2",
  "peg_delta": 2.1,
  "entropy_delta": 2.1,
  "hypercorrection": false,
  "instant_feedback": "逻辑谬误型误差。if-then 已记录，7天后回访执行。"
}
```

### 6.2b 预测卡（v1.1）

| Method | Path | 说明 |
|--------|------|------|
| POST | `/predictions` | 创建预测卡 + pre-mortem |
| PATCH | `/predictions/{id}/link` | 事后配对 events |

### 6.2c 回访与间隔检索（v1.1）

| Method | Path | 说明 |
|--------|------|------|
| GET | `/followups/pending` | 待完成 7 天 AR 回访 |
| POST | `/followups/{id}` | 提交 actual_executed |
| GET | `/error-reviews/pending` | Day 3/7/30 待检索 |
| POST | `/error-reviews/{id}` | 提交复述 |

### 6.3 认知仪表盘

| Method | Path | 说明 |
|--------|------|------|
| GET | `/dashboard` | 校准曲线 + flow + 五维 + 误差分布 |
| GET | `/dashboard/calibration` | prior vs accuracy 散点 |
| GET | `/dashboard/flow-balance` | challenge-skill 数据 |

**GET `/dashboard` Response**：

```json
{
  "calibration_gap": 1.2,
  "flow_index": 0.5,
  "zone": "peak",
  "weekly_peg_avg": 18.5,
  "metrics": {
    "ER": 0.21,
    "AR": 0.68,
    "PTR": 0.80,
    "NA": 0.75,
    "CV": 0.71
  },
  "error_distribution": {
    "信息缺失": 0.15,
    "逻辑谬误": 0.35,
    "情绪干扰": 0.20,
    "惯性假设": 0.20,
    "未知未知": 0.10
  },
  "alerts": []
}
```

### 6.4 微挑战

| Method | Path | 说明 |
|--------|------|------|
| GET | `/interventions/today` | 获取今日推送 |
| POST | `/interventions/{task_id}/respond` | 完成/跳过 |

### 6.5 每周复盘

| Method | Path | 说明 |
|--------|------|------|
| GET | `/reviews/current` | 本周复盘（自动生成草稿） |
| POST | `/reviews` | 提交复盘 |
| GET | `/reviews/{review_id}` | 历史复盘 |

### 6.6 30 天进化图谱

| Method | Path | 说明 |
|--------|------|------|
| GET | `/evolution/30day` | 生成进化图谱数据（需 streak ≥ 30） |

**Response**：

```json
{
  "day1_distribution": { "...": 0.4 },
  "day30_distribution": { "...": 0.2 },
  "narrative": "你开始更常做 pre-mortem，真实 AR 从 42% 升至 68%",
  "sample_size": 28,
  "confidence_label": "初步趋势",
  "hypercorrections_broken": 5,
  "share_image_url": "https://..."
}
```

### 6.7 错误码

| Code | HTTP | 说明 |
|------|------|------|
| CE_SAFETY_LOCK | 423 | 心智安全锁激活 |
| TRIAL_EXPIRED | 402 | 试用期结束 |
| STREAK_INSUFFICIENT | 400 | 未满足 30 天条件 |
| RATE_LIMITED | 429 | 超出调用限制 |

---

## 7. LLM 集成规格

### 7.1 误差分类 Pipeline

```
Input: 结构化觉醒三问 JSON
Model: GPT-4o-mini（或等价）
Temperature: 0.2
Output: JSON Schema 严格模式
Fallback: 规则引擎关键词匹配
Latency SLA: P95 < 3s
```

### 7.2 System Prompt 结构

1. 角色定义：S Square 误差分类引擎
2. 五类标签定义 + 边界案例
3. 输出 JSON Schema
4. 禁止：心理咨询、诊断、法律建议
5. 低置信度时返回 `needs_clarification`

### 7.3 PEG 计算（服务端 · v1.1）

```python
CATEGORY_WEIGHT = {
    "未知未知": 1.2, "逻辑谬误": 1.0, "信息缺失": 0.9,
    "惯性假设": 0.8, "情绪干扰": 0.7,
}

def calc_peg(prior, outcome, category, has_if_then, adjusted):
    raw = abs(outcome - prior) * CATEGORY_WEIGHT[category]
    hyper = 1.3 if prior >= 8 else 1.0
    if has_if_then:
        digest = 0.5
    elif adjusted:
        digest = 0.6
    else:
        digest = 1.0
    peg = round(raw * hyper * digest, 2)
    return peg, peg  # (peg_delta, entropy_delta alias)
```

### 7.4 LLM 分类 κ 校准（v1.1）

- 每 100 条人工标注 → Cohen's κ
- κ < 0.6 → 回退规则引擎 + Prompt 迭代
- 目标 κ ≥ 0.65

---

## 8. MVP V1.1 功能定义

### 8.1 四大 Tab + 扩展工作流

| Tab/流 | 名称 | 核心交互 | 产出 |
|--------|------|----------|------|
| 1 | 今日认知日志 | 三问 + if-then + 情绪三词 | events |
| 2 | 认知仪表盘 | **校准曲线** + **挑战-技能平衡** + 五维 | dashboard |
| 3 | 今日微挑战 | COM-B 诊断 → 完成/跳过+原因 | responses |
| 4 | 每周复盘 | 里程碑 + **第四问双环** | weekly_reviews |
| + | 预测卡 | pre-mortem + falsifier | predictions |
| + | 间隔检索 | Day 3/7/30 推送 | error_reviews |
| + | AR 回访 | Day 7 执行验证 | adjustment_followups |

### 8.2 爆点功能：30 天认知进化图谱

| 项 | 规格 |
|----|------|
| 触发 | 连续打卡满 30 天 |
| 输出 | Day 1 vs Day 30 误差分布对比图 |
| 叙事 | LLM 生成进化文案（模板 + 个性化） |
| 传播 | 「分享我的进化图谱」按钮 → 生成分享图 |

### 8.3 MVP 不做清单

| 功能 | 原因 |
|------|------|
| 社交/好友/排行榜 | 避免焦虑偏移，聚焦个人修炼 |
| 富文本编辑器 | 纯文本足够 |
| 用户自定义挑战 | 前期由系统保证科学性 |

---

## 9. 非功能需求

### 9.1 性能

| 项 | 要求 |
|----|------|
| API P95 延迟 | < 500ms（不含 LLM） |
| LLM 分类 P95 | < 3s |
| 仪表盘加载 | < 2s |
| 并发 | MVP 支持 1000 DAU |

### 9.2 安全与隐私

| 项 | 要求 |
|----|------|
| 原始文本 | 默认仅存本地（IndexedDB/SQLite） |
| 云端数据 | 仅分类标签 + 数值 + 元数据 |
| 传输 | TLS 1.3 |
| 存储 | AES-256 静态加密 |
| 合规 | 发布《S Square 认知隐私保护白皮书》 |
| RLS | PostgreSQL 行级安全，user_id 隔离 |

### 9.3 心智安全锁（v1.1）

| 条件 | 系统行为 |
|------|----------|
| flow_index > +4 且 PEG 均值 > 30 连续 2 周 | 整合模式；锁定增难 |
| flow_index < −4 且 ER < 5% 连续 2 周 | 整合模式；锁定制造失败 |
| PHQ-2 ≥ 3 或 GAD-2 ≥ 3（每月） | 暂停挑战 + 专业资源 |
| 自伤倾向检测 | 停止挑战；危机资源 400-161-9995 |

### 9.4 可观测性

- API 调用量、错误率、LLM 延迟监控
- 用户留存漏斗（D1/D7/D30）
- 内部开发者看板（Phase 1 交付物）

---

## 10. 分阶段路线图

### Phase 1：基建闭环期（4-6 周）

| # | 工作 | 技术要点 | 交付物 |
|---|------|----------|--------|
| 1 | PostgreSQL + API | 建表 + RLS | 数据库就绪 |
| 2 | 今日认知日志录入端 | Web/H5 + 语音转文字 SDK | 数据采集入口 |
| 3 | LLM 误差分类 | Prompt + Pipeline | 自动分类 |
| 4 | 初始基线校准 | role_type 常模 | Onboarding 闭环 |
| 5 | 开发者监控看板 | API 量/错误/留存 | 运维后台 |

### Phase 2：产品成形期（8-10 周）

| # | 模块 | 关键组件 |
|---|------|----------|
| 1 | Tab 1 今日日志 | 文本框 + Emoji |
| 2 | Tab 2 仪表盘 | 校准散点图 + 挑战-技能平衡 + 雷达图 |
| 3 | Tab 3 微挑战 | 规则引擎 + interventions |
| 4 | Tab 4 每周复盘 | 推送通知 + 时间线 UI |
| 5 | 商业化 | 微信登录 + 支付（free/pro 隔离） |

### Phase 3：生态扩展期（12-16 周+）

| # | 项目 | 内容 |
|---|------|------|
| 1 | 数据飞轮 | 匿名聚合 role_type 基准线 |
| 2 | Open API | 误差捕捉 + CE 计算接口 + 沙盒 |
| 3 | Skill Store | 第三方垂直领域认知包 |
| 4 | Enterprise | 团队看板 + 组织盲区聚合 + 权限 |

---

## 11. 商业化

### 11.1 原生 Skill 上架策略

将「认知日志 + 自动分类 + 周报」封装为轻应用，优先上架 AI Bot 商店。

| 优先级 | 渠道 | 形态 |
|--------|------|------|
| 🔥 最高 | GPT Store / Coze / 豆包 | 对话式认知教练 Bot |
| 🔥 高 | Notion 模板 / 飞书应用目录 | 模板 + 自动化 |
| 中 | Product Hunt / 即刻 / 少数派 | 首发帖 + 种子用户 |
| 低 | 微信小程序 / App Store | 后期原生轻应用 |

### 11.2 定价

| 版本 | 价格 | 功能 | 战略目的 |
|------|------|------|----------|
| 免费体验 | ¥0（7 天） | 全功能试用，7 天后锁定 | 降低决策门槛 |
| 原生 Skill 标准版 | ¥19.9/月 或 ¥99/年 | 无限记录 + 周报 + 熵值 + 30 天图谱 | 验证付费意愿 |
| 完整 S Square 引擎 | ¥199/月 | 含微挑战 + 仪表盘 + 季度重置 | 高价值转化 |

---

## 12. 测试计划

### 12.1 单元测试

- entropy_delta 计算边界值
- 五维指标聚合逻辑
- 规则引擎 trigger 匹配

### 12.2 集成测试

- 完整日志提交 → 分类 → 仪表盘更新链路
- 微挑战触发 → 响应 → BV 更新
- 30 天 streak → 图谱生成

### 12.3 E2E 测试

- Onboarding → 7 天使用 → 周报 → 付费转化漏斗
- 心智安全锁触发场景

### 12.4 LLM 评测

- 五类误差分类准确率 ≥ 85%（人工标注 200 条测试集）
- 低置信度召回率 ≥ 90%

---

## 13. 风险与护城河

### 13.1 风险

| 风险 | 缓解 |
|------|------|
| 用户将产品当作心理治疗 | 明确定位 + 危机资源 + 免责声明 |
| LLM 分类不稳定 | JSON Schema + 规则 fallback |
| 隐私信任不足 | 白皮书 + 本地优先架构 |
| 竞品模仿 UI | 深耕 Prompt + 策略库 + 常模数据 |

### 13.2 护城河

- 误差分类 Prompt（数千次迭代）
- interventions 策略库（500+ 条 + 触发规则）
- 校准常模数据库 + 真实 AR 行为验证数据

---

## 14. 冷启动（2 周行动清单）

| 周次 | 任务 | 具体动作 | 产出 |
|------|------|----------|------|
| 第 1 周 | Bot 开发与内容 | Coze/GPT 对话流；分类 Prompt；50~100 条微挑战；30 天图谱模板 | Bot 链接 + 内容库 |
| 第 2 周 | 上架与冷启动 | 上架商店；即刻/知识星球/朋友圈招募；种子微信群 | 用户反馈 + 首批数据 |

---

## 15. 附录

### 15.1 误差分类枚举

```
信息缺失 | 逻辑谬误 | 情绪干扰 | 惯性假设 | 未知未知
```

### 15.2 情绪标签枚举

```
平静 | 焦虑 | 兴奋 | 困惑 | 沮丧
```

### 15.3 role_type 常模初始值

| role_type | entropy_baseline |
|-----------|------------------|
| 创业者 | 22.0 |
| 产品 | 20.0 |
| 技术 | 18.0 |
| 市场 | 21.0 |
| 其他 | 19.0 |

### 15.4 相关文档

- Agent Skill 操作手册：`../SKILL.md`
- 科学理论地基 v1.1：`scientific-foundation-v1.1.md`
- 认知隐私保护白皮书（待发布）

---

*S Square 认知引擎 PRD v1.1 · 2026-07-21*
