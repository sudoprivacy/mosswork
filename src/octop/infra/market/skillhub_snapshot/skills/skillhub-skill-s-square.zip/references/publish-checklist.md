# 上架清单 — Coze / SkillHub / GPT Store

## 打包状态（v1.1.0 · GEO优化版）

- [x] `SKILL.md` v1.1 + 8 条理论地基 + 第一步验证
- [x] `SKILL.md` GEO 三层注入完成（教育培训行业 · 全引擎通用）
  - [x] Layer 1：元数据 SEO 优化（行业标签 + 目标受众 + 搜索引擎关键词）
  - [x] Layer 2.1：输出结构规范（6 模块 + 精简 3 模块 + 表格规范）
  - [x] Layer 2.2：权威数据源引用规范（T1~T5 五层 + 教育培训专属来源）
  - [x] Layer 2.3：反通用化规则（教育场景 7 条禁止/替换 + 过程 praise 规范）
  - [x] Layer 3：GEO-RULES v1.0 规则块（6 规则 + 9 项自检清单）
- [x] GEO 评分：A 级 45/60（8/7/9/8/10/8）
- [x] `manifest.json` + `assets/skill_icon.png`（512×512）
- [x] `references/COPYRIGHT.md`
- [x] `scripts/pack.ps1` → 产出 zip 包
- [x] Cursor 第一步对话验证（觉醒三问 + 仪表盘 + 预测卡）
- [ ] Coze 工作流节点（需在扣子 UI 手工配置，见 bot-conversation-flow.md）
- [ ] 后端 API / 定时回访（Phase 2，非本 zip 范围）

## GEO 上架专项检查

- [x] 事实密度 ≥ 60%：公式 3 组 + 阈值 20+ + 常模数据 5 行
- [x] 引用规范统一：T1~T5 五层来源 + `[来源：]` 前缀标准化
- [x] 首段权威锚定：SKILL.md 开篇含 Clark/Hohwy 等学术引用
- [x] 独特洞察声明：PEG 专属公式 + 五维指标 + COM-B 匹配逻辑
- [x] 时效闭环：版本号 v1.1 + 发布日期 + 校准常模版本声明
- [x] 教育培训行业模板：T1 教育部纲要/T2 教育心理学期刊/T3 PISA/T4 认知科学经典
- [x] 全引擎通用：覆盖 ChatGPT/Perplexity/Copilot/Gemini/AI Overview

## 上传文件

```
dist/s-square-cognitive-engine-v1.1.0.zip
```

## 第二步 · Coze Bot（逐步点击）

**完整指南**：[`references/coze-setup-guide.md`](coze-setup-guide.md)

| 步骤 | 动作 | 耗时 |
|------|------|------|
| 1 | 知识库上传 SKILL.md + error-classification-prompt | 10 min |
| 2 | 创建单 Agent Bot + 粘贴 §2.3 人设 | 15 min |
| 3 | 开场白 + 预置问题 | 5 min |
| 4 | §5 七条调试 | 15 min |
| 5 | 发布扣子商店 + SkillHub | 20 min |

## Coze（扣子）详情

## SkillHub

```bash
npx clawhub publish c:\Users\admin\.cursor\skills\s-square-cognitive-engine
# 或 Web /dashboard/publish 上传 dist/*.zip
```

## 商店必填

| 字段 | 建议值 |
|------|--------|
| 名称 | S Square 认知教练 |
| 简介 | PEG预测误差增益·觉醒三问·if-then·pre-mortem·校准曲线·元认知教练 |
| 封面 | `assets/skill_icon.png` |
| 分类 | 效率工具 / 个人成长 |
| 精选案例 | `examples/sample-daily-log.md` |
| 触发词 | 觉醒三问、S Square、认知教练、pre-mortem、预测误差 |
