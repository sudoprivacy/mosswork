# 科学理论地基 · v1.1 修订说明

**文档用途**：解释 v1.1 每项设计的实证来源、v1.0 弃用项理由、对外表述边界  
**读者**：产品、研发、内容审核、对外宣讲

---

## 1. v1.0 → v1.1 变更摘要

| v1.0 | v1.1 | 理由 |
|------|------|------|
| 认知熵 CE 为主度量 | **PEG** 为主，CE 为品牌别名 | CE 公式接近信息增益，非标准 cognitive entropy |
| 倒 U 型 CE 曲线 | **挑战-技能平衡**（心流） | Yerkes-Dodson 描述唤醒度，非信息熵；心流有更强操作化 |
| 随机共振 | 移除对外表述 | 物理现象，不宜等同于学习区 |
| 达克效应 | **校准缺口 Calibration Gap** | DK 效应 meta 分析显示部分为回归假象 |
| 自由能原理（硬约束） | 降为设计哲学 | FEP 消费级落地易流于隐喻 |
| BV 行为变异度 | **CV 认知变异度** | BV 缺乏直接实证；社交型挑战对部分人有害 |
| PTR 困惑分钟占比 | 二元/ESM | 分钟级自报效度极低 |
| AR 自报 adjustment | **7 天 AR 回访** | 自报 AR 有 social desirability bias |
| 觉醒三问 | 三问 + **if-then** + **第四问双环** | Gollwitzer 实施意图；Argyris 双环学习 |
| 仅事后复盘 | + **预测卡/pre-mortem** | 预测加工要求事前预测才有清晰误差 |
| 30 天图谱 | + 置信提示 + 真实 AR + 过程 praise | 叙事谬误风险（Taleb）；McAdams 叙事身份 |
| 规则引擎推挑战 | **COM-B 前置诊断** | MRC 行为改变框架 |

---

## 2. 八条核心理论 · 文献锚点

### ① 预测加工（Predictive Processing）

- **代表**：Clark (2015) *Surfing Uncertainty*; Hohwy (2013) *The Predictive Mind*
- **核心**：大脑持续生成预测，学习来自预测误差信号
- **产品映射**：预测卡（事前）+ 觉醒三问（事后）+ 误差五分类

### ② 元认知校准（Metacognitive Calibration）

- **代表**：Lichtenstein, Fischhoff & Phillips (1977); Koriat (1997)
- **核心**：人们系统性地高估/低估自己判断准确率；可训练改善
- **产品映射**：prior_score vs outcome_deviation → 校准曲线 + CG 指数
- **替代 DK**：用可测量校准缺口，而非「能力越低越盲目」叙事

### ③ 挑战-技能平衡 / 心流（Flow）

- **代表**：Csikszentmihalyi (1990) *Flow*
- **核心**：当挑战略高于技能时，进入专注与最优学习
- **产品映射**：flow_index = challenge − skill；仪表盘主视觉

### ④ 双环学习（Double-Loop Learning）

- **代表**：Argyris & Schön (1978) *Organizational Learning*
- **核心**：单环改行动；双环改 governing variables / 深层假设
- **产品映射**：第四问「哪条深信的假设被证伪了」；季度重置

### ⑤ 实施意图（Implementation Intentions）

- **代表**：Gollwitzer (1999); meta-analysis Gollwitzer & Sheeran (2006) — 中等效应量 d≈0.65
- **核心**：「当 X 时我将 Y」格式显著提升目标执行
- **产品映射**：「重来」强制 if-then 格式化

### ⑥ Desirable Difficulties

- **代表**：Bjork (1994); Roediger & Butler testing effect
- **核心**：间隔、检索、变式等「困难」增强长期 retention
- **产品映射**：Day 3/7/30 间隔误差检索；微挑战

### ⑦ 情绪粒度（Emotion Granularity）

- **代表**：Barrett (2017) *How Emotions Are Made*; Kashdan et al. (2015)
- **核心**：更精细区分情绪 → 更好调节与心理健康
- **产品映射**：NA 从 1-10 改为「三词情绪命名」

### ⑧ COM-B 行为改变模型

- **代表**：Michie, van Stralen & West (2011); UK MRC Framework
- **核心**：Behavior = Capability × Opportunity × Motivation
- **产品映射**：微挑战推送前时间/社交/动机诊断

---

## 3. 辅助设计哲学（非 PRD 硬约束）

| 理论 | 用途 |
|------|------|
| 认知负荷理论（Sweller/Cowan） | 知识三分法 |
| 神经可塑性 / 髓鞘化 | 间隔检索 → 组块化叙事 |
| Hypercorrection（Metcalfe & Kornell） | prior≥8 失误加权 1.3× |
| Pre-mortem（Klein 2007） | 预测卡工作流 |
| Tetlock 超级预测者 | falsifier 字段；Enterprise 参考类预测 |
| 确认偏误去偏（Larrick/SPARQ） | consider-the-opposite 微挑战 |

**自由能原理（Friston）**：保留为团队内部「主动推理」直觉，不写入用户可见文案或 API 契约。

---

## 4. 误差五分类 · 与经典框架对照

| S Square 分类 | 近似对照 |
|---------------|----------|
| 信息缺失 | 信息论不确定性；规划谬误（缺参考类） |
| 逻辑谬误 | 认知扭曲（Beck）；System 2 失误 |
| 情绪干扰 | 热认知（hot cognition）；内感受干扰 |
| 惯性假设 | 确认偏误；功能固着 |
| 未知未知 | Knight 不可计算不确定性；Black Swan 维度 |

**预测层级 L1-L4**：对齐预测加工 hierarchy of prediction errors。

---

## 5. 指标效度说明

| 指标 | 效度策略 |
|------|----------|
| ER | 限定高置信子集，避免分母不可数 |
| AR | 7 天行为回访，非自报 |
| PTR | 二元或 ESM，放弃分钟自报 |
| NA | 三词命名任务，可 NLP 检测重复词 |
| CV | 自报决策路径变化，社交行为改为可选模块 |

**效度验证路线图**：
- Phase 1：内部一致性 + 用户 face validity
- Phase 2：与 Brier score 相关性
- Phase 3：90 天 outcome（self-reported goal achievement）关联 AR

---

## 6. LLM 分类质量

- 每 100 条人工标注 → Cohen's κ
- κ < 0.6 → 回退规则引擎 + Prompt 迭代
- 目标：κ ≥ 0.65，准确率 ≥ 85%

---

## 7. 伦理与临床边界

- **非医疗产品**：PHQ-2/GAD-2 仅筛查，非诊断
- **跳过不惩罚**：保护 burnout 用户自主性（SDT）
- **危机资源**：400-161-9995 + 建议专业咨询

---

## 8. 对外话术指南

**可以说**：
- 「基于预测加工与元认知校准研究设计」
- 「帮助你看清预测与结果的校准缺口」
- 「挑战-技能平衡下的峰值学习区」

**避免说**：
- 「科学证明的认知熵倒 U 曲线」
- 「达克效应破局」
- 「自由能原理工程化实现」
- 「你是 XX 型思考者」（身份标签）

---

*v1.1 · S Square Lab · 2026-07-21*
