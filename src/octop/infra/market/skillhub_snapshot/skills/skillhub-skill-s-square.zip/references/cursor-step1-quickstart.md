# Cursor 第一步 · 对话验证快速指南

**目标**：在 Cursor 中跑通「Onboarding → 觉醒三问 → if-then → 误差分类 → 反馈」，无需数据库。

**Skill 路径**：`c:\Users\admin\.cursor\skills\s-square-cognitive-engine\`

---

## 1. 启用 Skill

### 方式 A：自动触发（推荐）

在 Cursor Agent 对话中说：

```
开始 S Square 第一步验证
```

或：

```
今日觉醒三问
```

Agent 应加载 `s-square-cognitive-engine` skill 并按 `SKILL.md` 执行。

### 方式 B：手动引用

```
@s-square-cognitive-engine 开始第一步验证
```

### 方式 C：打开 Skill 目录

在 Cursor 中打开文件夹：

```
c:\Users\admin\.cursor\skills\s-square-cognitive-engine
```

确保 `SKILL.md` 被 Agent 读取。

---

## 2. 验证流程（约 5 分钟）

| 步骤 | 用户动作 | 期望 Agent 行为 |
|------|----------|-----------------|
| 1 | 说「开始」 | 欢迎 + 隐私说明 |
| 2 | 选角色 A-E | 写入 role_type + peg_baseline |
| 3 | 自评 skill_level 1-10 | 解释挑战-技能平衡 |
| 4 | 回答「意外」 | 只问下一问，不合并 |
| 5 | 回答「预期」+ prior 分数 | 继续 |
| 6 | 回答「重来」+ if-then | 强制 if-then 格式 |
| 7 | 三词情绪 + deviation 分数 | 可选 falsifier |
| 8 | — | 输出 YAML/JSON 分类 + PEG + instant_feedback |
| 9 | 说「仪表盘」 | 文字版校准 + flow + 五维 |

完整期望输出见 [step1-validation-checklist.md](../examples/step1-validation-checklist.md)

---

## 3. 会话状态（无 DB 时）

Agent 在对话中维护以下变量（用户可复制到笔记备查）：

```yaml
session:
  role_type: 产品
  peg_baseline: 20.0
  skill_level: 6
  challenge_level: 6
  streak_days: 1
  events:
    - date: 2026-07-21
      error_category: 逻辑谬误
      peg_delta: 0.59
      hypercorrection: true
```

---

## 4. 通过标准

- [ ] 三问逐条引导，未合并提问
- [ ] 「重来」被格式化为 if-then
- [ ] 输出含 error_category + prediction_level + peg_delta
- [ ] instant_feedback ≤ 60 字、无空洞安慰
- [ ] 未替用户做决策
- [ ] 模糊输入触发 clarification 追问

---

## 5. 常见问题

**Q：Skill 没触发？**  
A：描述中加入「觉醒三问」「S Square」「认知教练」等 trigger 词。

**Q：没有 7 天回访？**  
A：第一步仅验证单次日志；回访需用户 Day 7 回来或进入第二步 Coze Bot。

**Q：和 sample-daily-log 不一致？**  
A：PEG 因 if-then 消化因子 0.5 会低于 v1.0 示例，属正常。

---

## 6. 下一步

验证通过后 → [publish-checklist.md](publish-checklist.md) 第二步：Coze Bot MVP
