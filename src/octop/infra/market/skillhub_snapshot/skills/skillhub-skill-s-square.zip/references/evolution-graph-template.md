# 30 天认知进化图谱 · 生成模板（v1.1）

**v1.1 变更**：样本量置信提示 · 真实 AR 趋势 · 高置信打破次数 · 过程 praise · 禁止身份标签

---

## 1. 数据输入

```json
{
  "user_id": "uuid",
  "day1_date": "2026-06-21",
  "day30_date": "2026-07-21",
  "day1_distribution": {
    "信息缺失": 0.20,
    "逻辑谬误": 0.15,
    "情绪干扰": 0.35,
    "惯性假设": 0.20,
    "未知未知": 0.10
  },
  "day30_distribution": {
    "信息缺失": 0.12,
    "逻辑谬误": 0.28,
    "情绪干扰": 0.18,
    "惯性假设": 0.25,
    "未知未知": 0.17
  },
  "day1_entropy_avg": 24.5,
  "day30_entropy_avg": 19.2,
  "total_events": 28,
  "verified_ar_rate": 0.68,
  "verified_ar_day1": 0.42,
  "hypercorrections_broken": 5,
  "confidence_label": "初步趋势",
  "role_type": "产品"
}
```

---

## 2. 进化叙事生成规则

```python
HIERARCHY = ["情绪干扰", "惯性假设", "信息缺失", "逻辑谬误", "未知未知"]

def generate_narrative(d1: dict, d30: dict) -> str:
    # 下降最多 = 开始摆脱
    decline = min(d1.keys(), key=lambda k: d30[k] - d1[k])
    decline_delta = d1[decline] - d30[decline]

    # 上升最多 = 更多审视（需层级更高）
    rise = max(d1.keys(), key=lambda k: d30[k] - d1[k])
    rise_delta = d30[rise] - d1[rise]

    part_a = f"从『{LABEL_MAP[decline]}』" if decline_delta > 0.05 else ""
    part_b = f"进化为『{LABEL_MAP[rise]}』" if rise_delta > 0.05 else "保持稳定觉察"

    if part_a:
        return f"你{part_a}进化为{part_b.replace('进化为', '')}"
    return f"你的认知模型在 30 天内{part_b}"

def confidence_label(n: int) -> str:
    if n >= 20: return "较可靠"
    if n >= 10: return "初步趋势"
    return "样本不足，仅供参考"

def generate_narrative_v11(d1, d30, ar_d1, ar_d30, premortem_count) -> str:
    parts = []
    if ar_d30 > ar_d1 + 0.1:
        parts.append(f"真实执行率从 {ar_d1:.0%} 升至 {ar_d30:.0%}")
    if premortem_count >= 3:
        parts.append(f"你完成了 {premortem_count} 次 pre-mortem")
    if parts:
        return "；".join(parts) + "——这是可验证的行为改变。"
    return generate_narrative(d1, d30)

LABEL_MAP = {
    "情绪干扰": "被情绪牵着走",
    "惯性假设": "依赖惯性假设",
    "信息缺失": "忽视关键信息",
    "逻辑谬误": "开始审视逻辑",
    "未知未知": "拓展认知边界",
}
```

---

## 3. 文案模板

### 标准版

```markdown
# 🧠 30 天认知进化图谱

**{user_display_name}** · {role_type} · {day1_date} → {day30_date}

---

## 误差分布 evolution

| 类型 | Day 1 | Day 30 | Δ |
|------|-------|--------|---|
| 信息缺失 | {d1_信息}% | {d30_信息}% | {delta} |
| 逻辑谬误 | {d1_逻辑}% | {d30_逻辑}% | {delta} |
| 情绪干扰 | {d1_情绪}% | {d30_情绪}% | {delta} |
| 惯性假设 | {d1_惯性}% | {d30_惯性}% | {delta} |
| 未知未知 | {d1_未知}% | {d30_未知}% | {delta} |

## 认知熵
Day 1 均值：**{d1_ce}** → Day 30 均值：**{d30_ce}**

## 进化叙事
「{narrative}」

⚠️ **置信提示**：基于 {total_events} 条记录 · {confidence_label}
（样本 < 10 时不生成身份型结论）

---
📊 共记录 {total_events} 条认知日志
🔥 S Square 认知引擎 · 认知基础设施
```

### 分享图文字层（1080×1920 竖版）

```
[顶部] S Square · 30 DAY EVOLUTION

[左栏标题] DAY 1          [右栏标题] DAY 30
[左栏饼图]                  [右栏饼图]

[中部大字] {narrative}

[底部] 连续打卡 30 天 · {date}
       扫码开启你的认知进化 →
```

---

## 4. 叙事示例库

| 变化模式 | 叙事 |
|----------|------|
| 情绪↓ + 逻辑↑ + AR↑ | 「真实 AR 从 42%→68%，你开始更常做 pre-mortem」 |
| 高置信打破 ≥5 | 「你本周打破了 5 个高置信假设——hypercorrection 正在发生」 |
| 惯性↓ + 未知↑ | 「你从『依赖惯性假设』进化为『拓展认知边界』」 |
| 信息↓ + 逻辑↑ | 「你从『忽视关键信息』进化为『开始审视逻辑』」 |
| 全面均衡 | 「你的认知模型在 30 天内保持稳定觉察，误差类型分布更均匀」 |
| 情绪仍高 | 「你仍在与情绪干扰共处，但调整率已提升 {AR}%——这是消化中的信号」 |

---

## 5. 禁止用语

- ❌ 「你已经成功了」
- ❌ 「打败了 XX% 的用户」
- ❌ 「你是 XX 型思考者」（身份标签）
- ❌ 样本 < 10 时生成确定性进化结论

---

## 6. Phase 2 分享图 API

```
GET /api/v1/evolution/30day/share-image
→ Returns: PNG URL (1080×1920)
→ 模板引擎: Figma / HTML-to-image / Canvas
```

---

*进化图谱模板 v1.0*
