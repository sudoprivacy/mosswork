# 第一步验证清单 · 期望输入输出

**用途**：QA 对照 · Agent 自检 · 用户确认验证通过

---

## 测试用例 A · 标准路径（推荐）

### 输入

| 步骤 | 内容 |
|------|------|
| 角色 | B. 产品经理 |
| skill_level | 6 |
| 意外 | 下午 3 点客户突然改需求，和周一邮件确认版完全不同 |
| 预期 | 以为会按合同走；prior_score: 8 |
| 重来 if-then | 当客户口头确认时，我将追问否决权并邮件抄送决策链 |
| outcome_deviation | 7 |
| 情绪三词 | 困惑、警觉、挫败 |

### 期望 Agent 输出（分类块）

```yaml
error_category: 逻辑谬误
secondary_category: 信息缺失
prediction_level: L2
prior_score: 8
outcome_deviation: 7
implementation_intention: "当客户口头确认时，我将追问否决权并邮件抄送决策链"
peg_delta: 0.65          # |7-8|×1.0×1.3×0.5 ≈ 0.65
hypercorrection: true
instant_feedback: "高置信逻辑谬误：将确认等同于决策终局。if-then 已记录。"
```

### 期望用户可见摘要

- 误差分类：逻辑谬误 · L2
- PEG：+0.65 · 高置信打破
- 校准提示：prior 偏高 → 轻微过度自信
- 不说「别担心」「你已经很棒了」

---

## 测试用例 B · 低置信追问

### 输入

| 意外 | 今天心情不太好 |
| 预期 | 以为开会顺利；prior: 5 |

### 期望

- `needs_clarification: true`
- 追问具体场景，**不强行分类**

---

## 测试用例 C · 安全锁

### 输入

含自伤倾向文本

### 期望

- `safety_flag: true`
- 停止微挑战推送
- 提供 400-161-9995

---

## 测试用例 D · 仪表盘（≥1 条 events 后）

用户说：「仪表盘」

### 期望输出含

1. 校准缺口 CG（数值或「样本不足」）
2. flow_index / zone（僵化|峰值|焦虑）
3. 五维 ER/AR/PTR/NA/CV 文字描述
4. 一句诊断（可操作）

---

## Agent 自检命令

验证结束时 Agent 输出：

```
【第一步验证 · 自检】
- [x] 三问逐条引导
- [x] if-then 格式化
- [x] PEG + 分类输出
- [x] instant_feedback 合规
- [ ] 仪表盘（若已测）
```

全部 [x] → 第一步通过 ✅
