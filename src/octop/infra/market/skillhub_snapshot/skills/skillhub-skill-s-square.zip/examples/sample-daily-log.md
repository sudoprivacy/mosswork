# 完整交互示例 · 今日认知日志（v1.1）

**场景**：产品经理，周三下午客户改需求  
**用途**：Coze 测试用例 / 上架精选案例 / Agent 输出参考

---

## 用户输入

| 字段 | 用户回答 |
|------|----------|
| 意外 | 下午 3 点客户突然说方案 A 不做了，要换成竞品同款功能，和周一书面确认的版本完全不同 |
| 预期 | 以为客户会按合同走，周一已经邮件确认过。自评 8 分 |
| 重来 if-then | **当**客户口头确认需求时，**我将**追问最终否决权并邮件抄送决策链 |
| 情绪三词 | 困惑、警觉、挫败 |
| falsifier | 若客户主动提竞品对比，说明我只理解了表面需求 |
| outcome_deviation | 7 |

---

## 分类结果（JSON）

```json
{
  "error_category": "逻辑谬误",
  "secondary_category": "信息缺失",
  "prediction_level": "L2",
  "prior_score": 8,
  "outcome_deviation": 7,
  "adjustment_made": true,
  "peg_delta": 0.59,
  "entropy_delta": 0.59,
  "hypercorrection": true,
  "confidence": 0.88,
  "instant_feedback": "高置信逻辑谬误：将邮件确认等同于决策终局。if-then 已记录，7天后回访。",
  "safety_flag": false
}
```

> PEG 计算：|7−8|×1.0×1.3×0.5 = 0.65（if-then 消化因子 0.5）

---

## 用户可见反馈

```markdown
✅ 日志已记录 · 2026-07-21

📊 **误差分类**：逻辑谬误 · L2（副类：信息缺失）
📈 **PEG**：+0.59 · 🔥 高置信打破
💬 高置信逻辑谬误：将邮件确认等同于决策终局。if-then 已记录，7天后回访。

📐 **校准缺口提示**：你近期 prior 均值偏高 1.2 分 → 轻微过度自信

---
🔥 连续打卡 12 天 · flow_index +0.5（峰值区 ✓）

⏰ 2026-07-28 将回访你的 if-then 执行情况
```

---

## 7 天后 AR 回访示例

```
上次：「当客户口头确认时，我将追问否决权并邮件抄送决策链」
过去 7 天执行了几次？
用户：B. 1-2 次
→ 真实 AR 更新 · 过程 praise：「你开始把复盘转化为具体触发行为了」
```

---

*示例 v1.1 · 见 error-classification-prompt.md · scientific-foundation-v1.1.md*
