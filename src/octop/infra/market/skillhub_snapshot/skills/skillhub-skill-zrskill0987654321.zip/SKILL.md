---
name: skillhub-skill-zrskill0987654321
description: "当用户询问 SAP 日常操作、FICO/MM/SD/PP/QM 后勤模块问题、配置排查、事务码查询、实施步骤、月末结账或常见 SAP 报错处理时，应使用此技能。适用于 SAP 业务顾问、关键用户或运维人员处理采购到付款、销售到收款、生产计划、库存管理、财务会计、管理会计、质量管理等场景。"
---

# SAP 日常运维实施助手

## 概述

此技能基于工作站中的 SAP 学习资料（FICO 财务笔记、MM 定价条件全解析、SAP 后勤模块实施攻略、SAP-QM 质量管理模块详解、SAP 完全配置方案系列——FICO/PP/SD 后台配置详解）以及通用 SAP 运维经验，帮助用户处理日常 SAP 操作、模块问题排查、配置指导和实施支持。

## 使用场景

此技能应在以下场景触发：

- 用户咨询 SAP 事务码或操作路径。
- 用户遇到 SAP 报错，需要排查原因和解决方案。
- 用户需要配置指导（如定价条件、科目确定、审批策略等）。
- 用户询问月末结账、清账、对账、外币评估等流程。
- 用户需要 MM/SD/PP/FICO/QM 集成问题的分析。
- 用户希望了解某个业务流程的完整操作步骤。
- 用户需要编写 SAP 操作手册或培训材料。

## 使用说明

处理 SAP 问题时，按以下步骤进行：

1. **确认问题范围**：判断问题属于 FI、CO、MM、SD、PP、WM、QM、PM 哪个模块，还是跨模块集成问题。
2. **加载参考资料**：根据需要读取对应的参考文件：
   - `references/fico-reference.md`：FI/CO 财务模块知识与事务码。
   - `references/fico-config-reference.md`：FICO 完整后台配置方案（公司代码、科目表、凭证、税务、AM 资产、CO 成本控制）。
   - `references/mm-pricing-reference.md`：MM 采购定价条件配置与运维。
   - `references/sap-logistics-operations.md`：MM/SD/PP 后勤模块操作与集成。
   - `references/pp-config-reference.md`：PP 完整后台配置方案（物料主数据、BOM、工艺路线、工作中心、MRP、计划策略、生产订单）。
   - `references/sd-config-reference.md`：SD 完整后台配置方案（组织架构、销售凭证、交货、开票、定价、客户、信贷管理）。
   - `references/qm-operations-reference.md`：QM 质量管理模块前台操作详解。
   - `references/qm-configuration-reference.md`：QM 质量管理模块后台配置详解。
   - `references/troubleshooting-guide.md`：通用排查方法与常见错误处理。
3. **信息收集**：向用户询问必要的上下文，如公司代码、工厂、采购/销售组织、单据号、错误消息号、期间状态等。
4. **分层排查**：按权限/期间 → 主数据 → 配置 → 业务数据一致性 → 程序/系统的顺序排查。
5. **给出方案**：提供清晰的操作步骤、事务码、检查点和可能的解决方案。
6. **必要时升级**：若判断需要 ABAP 开发、Basis 支持或跨模块顾问协作，明确告知用户。

## 模块速查

### FI/CO（财务会计 / 管理会计）

- 会计科目创建：FS00 / FSP0 / FSS0
- 凭证录入：F-02 / FB50
- 凭证修改/显示：FB02 / FB03
- 凭证冲销：FB08 / F.80
- 预制凭证：FB50 预制 / FBV0 过账
- 清账：F-03 / F.13 / F-44 / F-32
- 总账报表：F.01 / F.08 / FAGLB03 / FAGLL03
- 成本中心：KS03 / KSV5 / KSU5
- 内部订单：KO88 / CO88
- 资产折旧：AFAB

### MM（物料管理）

- 物料主数据：MM01 / MM02 / MM03
- 供应商：XK01 / XK02 / XK03
- 采购申请：ME51N / ME52N / ME53N
- 采购订单：ME21N / ME22N / ME23N
- 收货：MIGO / MBST
- 发票校验：MIRO / MR8M
- 预留：MB21 / MB25
- 物料凭证：MB51
- 库存总览：MMBE

### SD（销售与分销）

- 客户：XD01 / XD02 / XD03
- 销售订单：VA01 / VA02 / VA03
- 交货：VL01N / VL02N / VL03N / VL09
- 发票：VF01 / VF02 / VF03 / VF11
- 收款：F-28 / F-32
- 定价条件：VK11 / VK12 / VK13

### PP（生产计划）

- BOM：CS01 / CS02 / CS03
- 工艺路线：CA01 / CA02 / CA03
- 生产订单：CO01 / CO02 / CO03
- 报工：CO11N / CO15 / CO13
- MRP：MD02 / MD03 / MDBT
- 生产订单信息系统：COOIS

### QM（质量管理）

- 主检验特性：QS21 / QS24 / QS25 / QS26 / QS27 / QS28
- 目录管理：QS41 / QS49 / QS51 / QS59
- 检验方法：QS31 / QS33 / QS34 / QS36 / QS37 / QS38
- 抽样过程：QDV1 / QDV2 / QDV3 / QDV6 / QDV7
- 检验计划：QP01 / QP02 / QP03 / QSR6
- 质量信息记录：QI01 / QI02 / QI03
- 检验批与结果记录：QA32 / QA33
- 质量通知：QM01 / QM02 / QM03 / QM11 / QM19
- 标准报表：QA33 / QC55 / MCXB / MCVA / MCOA / MCXV / QGA2

## 月末结账清单

1. 打开会计期间（OB52）和物料期间（MMPV）。
2. 检查并处理未清项：FBL1N / FBL5N / ME2N / VA05。
3. 运行外币评估（FAGL_FC_VAL）。
4. 运行自动清账（F.13）。
5. 运行折旧（AFAB）。
6. 运行成本中心分配/分摊（KSV5 / KSU5）。
7. 运行生产订单结算（CO88 / KO88）。
8. 运行物料分类账（CKMLCP）。
9. 出具报表：F.01 / F.08 / S_ALR_87013611。
10. 关闭期间（OB52 / MMPV）。

## 重要注意事项

- 任何生产环境配置变更，应先在开发/测试环境验证，并通过传输请求（SE10 / STMS）传输到生产环境。
- 月末结账期间应尽量避免配置变更，防止影响结账进程。
- 对于系统自动生成的凭证（如 MIRO、VF01、MIGO），冲销时应通过原始业务单据冲销，而非直接用 FB08。
- 涉及敏感财务数据或权限变更时，需按企业内控流程审批。

## 参考资料

- `references/fico-reference.md`：FICO 财务模块详细知识。
- `references/fico-config-reference.md`：FICO 完整后台配置方案（FI 财务会计 + AM 固定资产 + CO 管理会计，326 页原文提炼）。
- `references/mm-pricing-reference.md`：MM 采购定价条件详细配置。
- `references/sap-logistics-operations.md`：MM/SD/PP 后勤模块操作与集成。
- `references/pp-config-reference.md`：PP 完整后台配置方案（物料主数据、分类系统、BOM、工艺路线、工作中心、MRP、计划策略、生产订单，240 页原文提炼）。
- `references/sd-config-reference.md`：SD 完整后台配置方案（组织架构、销售凭证、交货、开票、定价、客户、信贷，568 页原文提炼）。
- `references/qm-operations-reference.md`：QM 质量管理模块前台操作详解（主检验特性、目录、检验方法、抽样过程、检验计划、质量信息记录、检验批、结果记录、使用决策、缺陷记录、质量通知、标准报表）。
- `references/qm-configuration-reference.md`：QM 质量管理模块后台配置详解（基本设置、质量计划、质量检验、质量通知单配置路径）。
- `references/troubleshooting-guide.md`：通用排查方法与常见错误。
- 原始资料：`E:\AI测试文件\SAP资料\` 目录下的 SAP 学习文档。
