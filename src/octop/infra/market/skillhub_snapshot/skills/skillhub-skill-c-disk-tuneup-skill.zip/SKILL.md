---
name: skillhub-skill-c-disk-tuneup-skill
description: "在别的电脑上直接执行的「WorkBuddy 数据迁移 + C 盘清理 + 跨盘归类归并」合并操作手册。机器无关、参数化脚本、junction 重定向法。含自动关闭占用进程、VerifyComplete 精确校验、/E 递归铁律；脚本开箱一键跑(含 -DryRun 零风险预演)。默认不迁浏览器(避免副盘 HDD 卡顿)。当用户要给新机器迁 WorkBuddy、C 盘瘦身、把散落各盘的同类文件归并到同一盘、或套用已验证的\"数据迁移+清理\"成功模式时触发。合并自 workbuddy-data-migration 与 c-disk-cleanup。"
---

# C 盘瘦身与 WorkBuddy 迁移（合并操作手册 · 机器无关）

本手册把两件事合并成一套可直接在**别的电脑**上执行的流程：
- **A 部分：WorkBuddy / CodeBuddy 数据**从 C 迁到副盘（junction 重定向）。
- **B 部分：C 盘用户数据**（个人目录 + AppData 大块头）经 junction 迁到副盘瘦身。

> ⚠️ **默认不迁浏览器数据**。原因：早期在 ice_l 机器上把 AppData（含浏览器）迁到副盘 HDD 后，浏览器随机读小文件变慢、冷启动卡顿。若你的副盘也是 SSD，可把 B 部分脚本里的 `$browserPatterns` 清空来迁移浏览器；若副盘是 HDD，保持不迁。

---

## 〇、通用铁律（任何脚本都必须遵守）

1. **UTF-8 BOM 必须**：Windows PowerShell 5.1 读无 BOM 的 UTF-8 脚本会用 GBK 误读中文 → 解析失败静默无输出。生成/保存 `.ps1` 后务必加 BOM：
   `[System.IO.File]::WriteAllText($p,$c,[System.Text.UTF8Encoding]::new($true))`
2. **robocopy 绝不用 `/COPYALL`**：AppData 大量文件带特殊 ACL，`/COPYALL` 会因 ACL 拷贝失败把整批文件跳过 → junction 建好但副盘是空壳（早年踩过 35/36 全空的坑）。一律 `/COPY:DAT /DCOPY:T`。**且必须显式 `/E`**：本机（360 迁移 + 过滤驱动）会抑制 robocopy 默认递归，漏写 `/E` 会让子目录整层不被拷贝 → 删源即丢数据（曾误删 SteamLibrary 11GB、MV视频 拷出 0 文件）。
3. **校验不能省（VerifyComplete 最强）**：只看"建了 junction"会漏掉空拷贝。必须比对副盘目标 vs 源：**文件数完全一致 + 总大小偏差 ≤ 0.5%**（源用 `Get-ChildItem -Recurse`）。过滤驱动漏递归会令文件数骤降，精确匹配能在删源前 100% 拦住。仅用"体积 ≥ 99%"不够稳。
4. **删前确认 + 保留 `.orig-backup` 可逆层**：任何永久删除都要输入 `YES`；junction 迁移时先把原目录改名 `.orig-backup` 保留，确认应用正常数天后再删。
5. **锁文件处理（脚本自动关进程优先）**：`cleanup-c-disk-generic.ps1` 在迁移前会**自动关闭微信/WPS/Steam/浏览器/钉钉等"数据被迁"的常驻程序**（safe-list + 优雅关闭，绝不碰杀毒/系统进程），绝大多数锁已被释放，无需手动关。仍报占用 = 被杀毒/系统核心独占 → 这些在 deny-list 不会被杀，需：重启后重跑（幂等）→ 停服务/杀 safe-list 进程 + `takeown`/`icacls` 夺权 → 安全模式 `rd /s /q` 兜底。**不要依赖 `MoveFileEx` 重启删除**（需 `SeManageVolumePrivilege`，本机常不可靠）。
6. **safe-delete 守卫**：agent 工具对个人目录的 `Remove-Item` 会被拦下/送回收站。删除类操作写成脚本，让用户在**独立 PowerShell（Win+R → powershell）**手动跑。
7. **副盘必须是固定磁盘**：junction 指向固定盘，副盘拔掉应用起不来。

---

## 一、A 部分：WorkBuddy 数据迁移（C → 副盘）

### 1.1 为什么是 junction 而不是改路径
WorkBuddy 用户数据目录写死在 `USERPROFILE` 下，没有环境变量可改路径；且 `WorkBuddy/projects` 子目录名**编码了绝对路径**，真挪路径会让历史映射失效。Junction 让数据实体在副盘、C 原路径名不变（变"指针"），零配置、应用无感知、可逆。

### 1.2 迁移映射（通用变量）
把 `$TargetRoot` 换成实际副盘路径（如 `G:\WorkBuddyData`）：

| 源 (C) | 目标 (副盘) |
|---|---|
| `$env:USERPROFILE\.workbuddy` | `$TargetRoot\.workbuddy` |
| `$env:USERPROFILE\WorkBuddy` | `$TargetRoot\WorkBuddy` |
| `$env:LOCALAPPDATA\@genieworkbuddy-desktop-updater` | `$TargetRoot\AppDataLocal\@genieworkbuddy-desktop-updater` |
| `$env:LOCALAPPDATA\WorkBuddy` | `$TargetRoot\AppDataLocal\WorkBuddy` |
| `$env:LOCALAPPDATA\CodeBuddyExtension` | `$TargetRoot\AppDataLocal\CodeBuddyExtension` |

### 1.3 执行（脚本在 `scripts/move-workbuddy-to-X.ps1`）
前置：完全关闭 WorkBuddy（托盘退出 + 任务管理器确认无 `WorkBuddy.exe`/`genieworkbuddy`/`CodeBuddy*`）。
```
powershell -ExecutionPolicy Bypass -File "X:\scripts\move-workbuddy-to-X.ps1"
```
脚本行为：前置检查（副盘类型 + 进程）→ 预生成 `rollback-workbuddy-move.ps1` → 逐目录 `robocopy /COPY:DAT` + 改名 `.orig-backup` + `mklink /J` + 3 次重试 + 自动验证体积。异常时跑回滚脚本一键还原。

### 1.4 验证与收尾
启动 WorkBuddy 确认正常 → 观察 1~2 天 → 再手动删 `.orig-backup` 释放 C 盘（用 B 部分的 `delete-backups-generic.ps1` 或单独确认）。

---

## 二、B 部分：C 盘用户数据清理（junction 迁移，默认不迁浏览器）

### 2.1 标准流程
1. **扫描**：列出 3 个 root（`$HOME`、`$HOME\AppData\Local`、`$HOME\AppData\Roaming`）下各目录大小，挑大块头。
2. 对每个目标目录：
   a. `dst = $DataRoot\<Home|Local|Roaming>\<name>`（Local/Roaming 分开，避免同名冲突，如 `Tencent`）。
   b. `robocopy <src> <dst> /E /COPY:DAT /DCOPY:T /R:1 /W:1 /XJ /MT:8`。
   c. **校验（VerifyComplete）**：文件数完全一致 + 总大小偏差 ≤ 0.5%，否则中止（过滤驱动漏递归会令文件数骤降，精确匹配 100% 拦住）。
   d. 改名 `.<name>.orig-backup` + `mklink /J <src> <dst>`。
3. **不迁**：`Microsoft`、`Packages`（系统/UWP 绑定，硬搬会让内置应用失效）；浏览器（默认按 `$browserPatterns` 跳过）。

### 2.2 执行（脚本在 `scripts/cleanup-c-disk-generic.ps1`）
先编辑脚本顶部 `$DataRoot`（副盘路径）与 `$targetNames`（要迁的目录清单），然后：
```
powershell -ExecutionPolicy Bypass -File "X:\scripts\cleanup-c-disk-generic.ps1"
```
脚本自带幂等、单项 try/catch、3 次重试、**自动关闭占用进程**（微信/Steam/浏览器等，无需手动关）、**VerifyComplete 精确校验**（文件数+大小）、自动跳过已 junction 项。

### 2.3 验证（脚本在 `scripts/verify-cleanup-generic.ps1`，只读）
```
powershell -ExecutionPolicy Bypass -File "X:\scripts\verify-cleanup-generic.ps1"
```
确认所有 junction 指向副盘且可访问，并给出可释放的 `.orig-backup` 空间。

### 2.4 收尾删除备份（脚本在 `scripts/delete-backups-generic.ps1`，危险）
确认应用全部正常后：
```
powershell -ExecutionPolicy Bypass -File "X:\scripts\delete-backups-generic.ps1"
```
输入 `YES` 才删，删完自动清空受影响盘回收站（避 360 等安全软件拦截进回收站导致空间不释放）。

### 2.5 跨盘归类归并（migrate-category.ps1）
除了给 C 盘瘦身，有时需要把**已散落在 D/E/G 上的同类大目录**物理归并到同一块盘（重新归类，便于集中备份/管理）。脚本 `scripts/migrate-category.ps1` 处理这类"源→目标"整目录迁移，与 B 部分同源同铁律。**无需改代码**，三种用法：

- **交互式（推荐，运行时中文提示输入源与目标根，第三方最省心）**：
  `powershell -ExecutionPolicy Bypass -File "X:\scripts\migrate-category.ps1"`
- **参数式·多源归并**（Dst 作目标根，自动按源目录名归并到 `Dst\leaf`）：
  `powershell -ExecutionPolicy Bypass -File "X:\scripts\migrate-category.ps1" -Src "D:\MV视频","D:\图片" -Dst "G:"`
- **参数式·单源精确目标**：
  `powershell -ExecutionPolicy Bypass -File "X:\scripts\migrate-category.ps1" -Src "D:\MV视频" -Dst "G:\MyVideos"`
- 任意用法后追加 **`-DryRun`** 先做零风险预演（只复制+校验，不删源不建 junction），确认无误再去掉 `-DryRun` 正式跑。

特性：自动关闭锁文件常驻程序（媒体/办公/压缩查看器，deny-list 保护系统/杀毒/WorkBuddy）、`/E` 递归、VerifyComplete 精确校验、junction 可逆、汇总后**一次 `YES`** 放行所有删源+建 junction。

---

## 三、在别的电脑上执行的端到端清单

1. 选固定磁盘作目标（WorkBuddy 用 `$TargetRoot` 如 `G:\WorkBuddyData`；C 盘清理用 `$DataRoot` 如 `G:\AppDataData`）。
2. **WorkBuddy 迁移**：完全关闭 WB → 编辑 `move-workbuddy-to-X.ps1` 的 `$TargetRoot` → 跑 → 看自动验证全 OK → 启动 WB 确认。
3. **C 盘清理**：脚本会**自动关闭**微信/Steam/浏览器等占用进程（无需手动关；仅杀毒核心锁定时才需重启）→ 编辑 `cleanup-c-disk-generic.ps1` 的 `$DataRoot`/`$targetNames` → 跑（自动迁移+校验）→ 跑 `verify-cleanup-generic.ps1` 复核。
4. **观察 1~2 天**应用正常后，再跑 `delete-backups-generic.ps1`（输入 YES）释放 C 盘。
5. 遇"拒绝访问/文件被占用"：关软件 → 重启重跑（幂等）→ 仍锁则停服务/夺权 → 安全模式 `rd /s /q` 兜底。
6. （可选）**跨盘归类归并**：若要把散落在 D/E/G 上的同类大目录归并到同一盘，用 `migrate-category.ps1`：直接交互式运行（中文提示输入源与目标），或 `-Src`/`-Dst` 参数式，**无需改代码**；先 `-DryRun` 零风险确认，再正式跑（自动关进程 + VerifyComplete + 一次 YES 闸）。

---

## 四、坑位速查（已踩过，必看）

| 现象 | 根因 | 对策 |
|---|---|---|
| 脚本静默无输出 | 无 BOM 的 UTF-8 被 GBK 误读 | 加 UTF-8 BOM |
| junction 建好但副盘空 | `/COPYALL` ACL 拷贝跳过 | 改 `/COPY:DAT /DCOPY:T` + 体积校验 |
| 删完空间没少 | 安全软件把删除拦进回收站 | 删后 `Clear-RecycleBin` |
| 常驻程序开着删 | 一边删一边写，收益被吃 | 先关程序/重启再跑 |
| 重启删除不生效 | `MoveFileEx` 需特殊权限/文件被独占 | 不依赖，改安全模式 `rd /s /q` |
| 浏览器卡顿 | 数据在 HDD 副盘随机读慢 | 默认不迁浏览器；或副盘用 SSD |
| robocopy 拷出空目录/0 文件 | 本机过滤驱动抑制默认递归(漏写 /E) | 必须显式 `/E` + VerifyComplete 精确校验兜底 |

## 五、互补技能
- `disk-cache-cleanup`：另一种思路——直接删缓存/临时释放空间（非 junction），适合"缓存占空间、可丢弃"。
- `workbuddy-data-migration` / `c-disk-cleanup`：本手册拆分前的两份专项技能，可作深入参考。
