﻿# migrate-category.ps1
# 跨盘归类归并(物理迁移)通用脚本 —— 自动关进程 + 一键 + 参数化/交互式.
# 把"源目录"递归复制到"目标目录", 校验通过后(文件数+大小一致)删除源并在原路径建 junction.
# 自动关闭可能锁住文件的常驻程序(媒体/办公/压缩查看器等), 无需手动一个一个关.
# 安全: 绝不关 explorer / WorkBuddy / 杀毒 / 系统进程; 关前打印清单并暂停等你按 Enter(可 Ctrl+C 取消).
#
# 用法(在 WorkBuddy 之外的独立 PowerShell 管理员运行):
#   1) 交互式(推荐, 无需改代码):
#        powershell -ExecutionPolicy Bypass -File "X:\scripts\migrate-category.ps1"
#   2) 参数式 —— 多源,Dst 作为目标根, 自动按源目录名归并:
#        powershell -ExecutionPolicy Bypass -File "X:\scripts\migrate-category.ps1" -Src "D:\MV视频","D:\图片" -Dst "G:"
#   3) 参数式 —— 单源精确指定目标:
#        powershell -ExecutionPolicy Bypass -File "X:\scripts\migrate-category.ps1" -Src "D:\MV视频" -Dst "G:\MyVideos"
#   4) 只复制+校验, 不删源不建 junction(先跑确认)：
#        在上面任意命令后追加 -DryRun
[CmdletBinding()]
param(
    [string[]]$Src,
    [string]$Dst,
    [switch]$DryRun
)

$ErrorActionPreference = 'Continue'

# 默认目标根: 仅在未用 -Dst 时才生效(交互模式或不指定 Dst 的参数模式). 改成你自己的副盘即可.
$defaultTargetRoot = 'G:'

# ===== 自动关进程配置 =====
# 常见会锁住媒体/文档/压缩包的常驻程序(迁移前优雅关闭以释放文件锁). 不在 neverKill 里的才会被关.
$mediaOfficeProcs = @(
    'PotPlayerMini64','PotPlayer','vlc','mpv','mpc-hc64','mpc-hc','storm','iqiyi',
    'QQLive','tencentvideo','Youku','youkup',
    'WINWORD','EXCEL','POWERPNT','outlook',
    'wps','wpscloudsvr','et','wpp','wpspdf',
    '7zFM','7z','Bandizip','bz','winrar','WinRAR',
    'honeyview','Honeyview','acdsee','ACDSee','pictureview'
)
# 额外进程(按目录语义映射). 可增删.
$safeKillMap = @{
    'MV视频'     = @('PotPlayerMini64','PotPlayer','vlc','mpv','mpc-hc64','storm','iqiyi','QQLive');
    '石料山文件' = @('wps','wpscloudsvr','et','wpp','WINWORD','EXCEL','POWERPNT')
}
# 永不关闭的关键/系统/杀毒进程(误杀会崩系统或失防护)
$neverKill = @(
    'explbuddy','WorkBuddy','CodeBuddy','genieworkbuddy',
    '360safe','360tray','360sd','HipsDaemon','Huorong','mfevtps','MsMpEng','WinDefend','SecurityHealthService',
    'lsass','csrss','winlogon','services','svchost','System','Registry','smss','wininit','dllhost',
    'conhost','RuntimeBroker','dwm','fontdrvhost','taskhostw','sihost','ctfmon','audiodg','spoolsv',
    'SearchIndex  er','ShellExperienceHost','SearchUI','powershell','cmd'
)

function Get-NamesToKill($plan){
    $set = @{}
    foreach($p in $plan){
        $name = Split-Path $p.src -Leaf
        if($safeKillMap.ContainsKey($name)){ foreach($x in $safeKillMap[$name]){ $set[$x]=$true } }
    }
    # 同时把常见媒体/办公进程里实际运行的也纳入(它们可能锁住任意媒体/文档)
    foreach($x in $mediaOfficeProcs){ $set[$x]=$true }
    $out=@()
    foreach($k in $set.Keys){ if($k -notin $neverKill){ $out += $k } }
    return $out
}

function Close-SafeProcesses($names){
    $killed=@()
    foreach($nm in $names){
        if($nm -in $neverKill){ continue }
        $procs = @(Get-Process -Name $nm -ErrorAction SilentlyContinue)
        if($procs.Count -eq 0){ continue }
        Write-Host "  关闭进程: $nm (x$($procs.Count))" -ForegroundColor Yellow
        foreach($p in $procs){ try { $null = $p.CloseMainWindow() } catch {} }
        Start-Sleep -Seconds 3
        if(@(Get-Process -Name $nm -ErrorAction SilentlyContinue).Count -gt 0){
            try { Stop-Process -Name $nm -Force -ErrorAction SilentlyContinue } catch {}
            Start-Sleep -Seconds 2
        }
        if(@(Get-Process -Name $nm -ErrorAction SilentlyContinue).Count -eq 0){ $killed += $nm; Write-Host "    已终止: $nm" -ForegroundColor Green }
        else { Write-Host "    仍运行(系统/服务保护, 将跳过其数据目录): $nm" -ForegroundColor Red }
    }
    return $killed
}

# 校验: 文件数必须完全一致, 总大小偏差 <= 0.5%. 本机过滤驱动会抑制 robocopy 默认递归(必须 /E), 缺失子目录会令文件数骤降 -> 此处拦截, 杜绝误删.
function VerifyComplete($s, $d){
    $sf = @(Get-ChildItem -LiteralPath $s -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object{ -not ($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) })
    $df = @(Get-ChildItem -LiteralPath $d -Recurse -Force -File -ErrorAction SilentlyContinue)
    $sc=$sf.Count; $dc=$df.Count
    $ss=if($sc-eq0){0}else{($sf|Measure-Object -Property Length -Sum).Sum}
    $ds=if($dc-eq0){0}else{($df|Measure-Object -Property Length -Sum).Sum}
    $ratio = if($ds -eq 0){1}else{[Math]::Abs($ss-$ds)/$ds}
    if($sc -eq $dc -and $ratio -le 0.005){ return $true }
    Write-Host ("    !! 校验不一致: 源 文件数=$sc 大小=$ss / 目标 文件数=$dc 大小=$ds -> 中止(防漏拷/误删)") -ForegroundColor Red
    return $false
}

function Get-DriveLetter($path){ return $path.Substring(0,1) }

# ===== 构建迁移计划: 支持参数或交互式, 不再硬编码目录 =====
$plan = @()
if($Src -and $Src.Count){
    $valid = @()
    foreach($s in $Src){
        if(Test-Path -LiteralPath $s -PathType Container){ $valid += $s }
        else { Write-Host "[跳过] 源不存在或不是目录: $s" -ForegroundColor Red }
    }
    if($valid.Count -eq 0){ Write-Host "没有可用的源目录, 退出." -ForegroundColor Red; exit }
    if($Dst){
        $dstRoot = $Dst.TrimEnd('\')
        # 单源 + Dst 是已存在的真实目录 -> 当作精确目标; 多源 -> Dst 作为目标根, 按源目录名归并到 Dst\leaf
        if($valid.Count -eq 1 -and (Test-Path -LiteralPath $Dst -PathType Container -ErrorAction SilentlyContinue)){
            $plan += @{ src = $valid[0]; dst = $dstRoot }
        } else {
            foreach($s in $valid){ $plan += @{ src = $s; dst = (Join-Path $dstRoot (Split-Path $s -Leaf)) } }
        }
    } else {
        Write-Host "[提示] 未指定 -Dst, 使用默认目标根: $defaultTargetRoot" -ForegroundColor Yellow
        foreach($s in $valid){ $plan += @{ src = $s; dst = (Join-Path $defaultTargetRoot (Split-Path $s -Leaf)) } }
    }
} else {
    Write-Host "=== 交互式归类归并 (无需改代码) ===" -ForegroundColor Cyan
    $srcInput = Read-Host "请输入要迁移的源目录(多个用逗号或分号分隔, 例如 D:\MV视频,D:\图片)"
    $srcList = @($srcInput -split '[;,，]' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    $rootInput = Read-Host "请输入目标根目录(例如 G: 或 G:\Backup)"
    $rootInput = $rootInput.TrimEnd('\')
    foreach($s in $srcList){
        if(-not (Test-Path -LiteralPath $s -PathType Container)){ Write-Host "[跳过] 源不存在或不是目录: $s" -ForegroundColor Red; continue }
        $plan += @{ src = $s; dst = (Join-Path $rootInput (Split-Path $s -Leaf)) }
    }
}

if($plan.Count -eq 0){ Write-Host "没有可迁移的项, 退出." -ForegroundColor Yellow; exit }

Write-Host "`n========== 本次迁移计划 ==========" -ForegroundColor Cyan
foreach($p in $plan){ Write-Host "  $($p.src)  ->  $($p.dst)" -ForegroundColor White }
Write-Host "===================================" -ForegroundColor Cyan

# ===== 自动关闭占用进程(一键核心) =====
$toKill = Get-NamesToKill $plan
if($toKill.Count -gt 0){
    Write-Host "`n[自动关进程] 即将关闭以下程序以释放文件锁(未保存内容可能丢失):" -ForegroundColor Yellow
    Write-Host "  $($toKill -join ', ')" -ForegroundColor White
    Write-Host "  按 Enter 继续(自动关闭并迁移), 或 Ctrl+C 取消:" -ForegroundColor Cyan
    Read-Host | Out-Null
    $killed = Close-SafeProcesses $toKill
    Write-Host ("[自动关进程] 已终止: $($killed -join ', ')") -ForegroundColor Green
} else {
    Write-Host "[自动关进程] 无需关闭的常驻程序." -ForegroundColor DarkGray
}

$approved = @(); $failed = @()
foreach($p in $plan){
    $src=$p.src; $dst=$p.dst; $junc=$src
    if(-not (Test-Path -LiteralPath $src)){ Write-Host "`n[跳过] 源不存在: $src" -ForegroundColor DarkGray; continue }
    $it = Get-Item -LiteralPath $src -Force -ErrorAction SilentlyContinue
    if($it -and ($it.Attributes -band [System.IO.FileAttributes]::ReparsePoint)){ Write-Host "`n[跳过] 已是 junction: $src" -ForegroundColor DarkGray; continue }
    Write-Host "`n=== 复制: $src -> $dst ===" -ForegroundColor Cyan
    if(-not (Test-Path $dst)){ New-Item -ItemType Directory -Path $dst -Force | Out-Null }
    # 必须 /E: 本机(360 过滤驱动)抑制 robocopy 默认递归, 缺 /E 漏拷子目录 -> 删源即丢数据
    robocopy "$src" "$dst" /E /COPY:DAT /DCOPY:T /R:1 /W:1 /XJ /MT:8 /NFL /NDL | Out-Null

    if(-not (VerifyComplete $src $dst)){ Write-Host "  [FAIL] 校验未过, 不删源: $src" -ForegroundColor Red; $failed += $src; continue }
    Write-Host "  校验通过." -ForegroundColor Green
    $approved += $p
}

Write-Host "`n========== 复制+校验完成 ==========" -ForegroundColor Green
Write-Host "通过(待删源+建junction): $($approved.Count)   失败/跳过: $($failed.Count)" -ForegroundColor White
if($approved.Count){
    foreach($p in $approved){ Write-Host "  - $($p.src)  ->  $($p.dst)" -ForegroundColor White }
}
if($failed.Count){
    foreach($f in $failed){ Write-Host "  [FAIL] $f" -ForegroundColor Red }
}

if($DryRun){
    Write-Host "`n[DryRun] 未删除任何源, 未建 junction. 确认无误后去掉 -DryRun 重跑以完成迁移." -ForegroundColor Yellow
    exit
}

if($approved.Count -eq 0){
    Write-Host "`n无通过校验的项, 未做任何删除." -ForegroundColor Yellow
    exit
}

Write-Host "`n即将对以上 $($approved.Count) 项执行: 删除源目录 + 在原路径建 junction 指向目标."
Write-Host "Type YES to proceed (其他任意输入中止):"
$c = Read-Host "Confirm"
if($c -ne 'YES'){ Write-Host "已中止, 未删除任何文件."; exit }

foreach($p in $approved){
    $src=$p.src; $dst=$p.dst; $junc=$src
    $drv = Get-DriveLetter $src
    Remove-Item -LiteralPath $src -Recurse -Force -Confirm:$false
    cmd /c mklink /J "$junc" "$dst" | Out-Null
    Clear-RecycleBin -DriveLetter $drv -Force -ErrorAction SilentlyContinue
    Write-Host "  DONE: $src -> junction -> $dst" -ForegroundColor Green
}
Write-Host "`n=== ALL DONE: 归类归并完成, 原路径均为 junction ===" -ForegroundColor Green
