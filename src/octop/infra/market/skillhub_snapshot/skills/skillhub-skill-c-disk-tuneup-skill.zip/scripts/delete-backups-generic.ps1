﻿# delete-backups-generic.ps1
# 在确认 C 盘清理/迁移成功、应用正常后, 永久删除 *.orig-backup 释放 C 盘空间.
# 危险: 不可逆. 必须输入 YES. 删完清空受影响盘回收站(避安全软件拦截进回收站).
# 用法: powershell -ExecutionPolicy Bypass -File "X:\scripts\delete-backups-generic.ps1"
$ErrorActionPreference='Continue'
$roots = @($env:USERPROFILE, $env:LOCALAPPDATA, $env:APPDATA)
$items = @()
foreach($r in $roots){ $items += Get-ChildItem -Path $r -Directory -Filter '*.orig-backup' -Force -ErrorAction SilentlyContinue }
if($items.Count -eq 0){ Write-Host "未发现 .orig-backup, 无需删除."; exit }
$total=0
Write-Host "=== 将删除以下 .orig-backup (C 盘备份, 不可逆) ===" -ForegroundColor Yellow
foreach($it in $items){ $sz=(Get-ChildItem $it.FullName -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; if($null -eq $sz){$sz=0}; $total+=$sz; Write-Host ("  {0,-50} {1,10:N1} MB" -f $it.FullName, ($sz/1MB)) }
Write-Host ("合计约 {0:N2} GB" -f ($total/1GB))
Write-Host "Type YES to DELETE these now. Anything else aborts."
$confirm = Read-Host "Confirm"
if($confirm -ne 'YES'){ Write-Host "Aborted."; exit }
$drives=@{}
foreach($it in $items){
    try { Remove-Item $it.FullName -Recurse -Force -Confirm:$false -ErrorAction Stop; $drives[(Split-Path -Qualifier $it.FullName)]=$true; Write-Host ("  DELETED {0}" -f $it.FullName) -ForegroundColor Green }
    catch { Write-Host ("  FAIL {0}: {1}" -f $it.FullName, $_.Exception.Message) -ForegroundColor Red }
}
foreach($d in $drives.Keys){ $L=$d.TrimEnd(':'); Clear-RecycleBin -DriveLetter $L -Force -ErrorAction SilentlyContinue; Write-Host ("  已清空 {0}: 回收站" -f $L) }
Write-Host "=== DONE ==="
