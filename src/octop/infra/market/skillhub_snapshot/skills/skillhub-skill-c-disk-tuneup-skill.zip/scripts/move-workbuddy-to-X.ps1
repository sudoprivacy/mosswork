﻿# move-workbuddy-to-X.ps1  (幂等 + 重试 + 单项错误不中断 + 自动回滚)
# 把 WorkBuddy / CodeBuddy 用户数据从 C 盘迁到副盘(固定磁盘), 用 junction 重定向, 应用无感知且可逆.
# 用法: 先完全关闭 WorkBuddy(托盘退出+任务管理器确认无 WorkBuddy.exe/genieworkbuddy/CodeBuddy*);
#       在 WorkBuddy 之外的独立 PowerShell 运行:
#         powershell -ExecutionPolicy Bypass -File "X:\scripts\move-workbuddy-to-X.ps1"
$ErrorActionPreference = 'Stop'
$TargetRoot = 'X:\WorkBuddyData'   # <-- 改成目标机实际副盘路径(固定磁盘)

# 校验: 文件数必须完全一致, 总大小偏差 <= 0.5%. 本机过滤驱动会抑制 robocopy 默认递归(必须 /E), 缺失子目录会令文件数骤降 -> 此处拦截, 杜绝误删.
function VerifyComplete($s, $d){
    $sf = @(Get-ChildItem -LiteralPath $s -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object{ -not ($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) })
    $df = @(Get-ChildItem -LiteralPath $d -Recurse -Force -File -ErrorAction SilentlyContinue)
    $sc=$sf.Count; $dc=$df.Count
    $ss=if($sc-eq0){0}else{($sf|Measure-Object -Property Length -Sum).Sum}
    $ds=if($dc-eq0){0}else{($df|Measure-Object -Property Length -Sum).Sum}
    $ratio = if($ds -eq 0){1}else{[Math]::Abs($ss-$ds)/$ds}
    if($sc -eq $dc -and $ratio -le 0.005){ return $true }
    Write-Host ("    !! 校验不一致: 源 文件数=$sc 大小=$ss / 目标 文件数=$dc 大小=$ds -> 中止(防漏拷/误删)") -ForegroundColor Red
    return $false
}

try {
    $gType = (Get-Volume -DriveLetter ($TargetRoot[0]) -ErrorAction SilentlyContinue).DriveType
    if ($gType -and $gType -ne 'Fixed') {
        $ans = Read-Host "WARNING: 目标盘 $($TargetRoot[0]): 非固定磁盘, 断开后 WorkBuddy 将无法启动. 仍继续? (Y/N)"
        if ($ans -notmatch '^[Yy]') { exit 0 }
    }
} catch {}
$wb = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'WorkBuddy|CodeBuddy|genieworkbuddy' }
if ($wb) {
    $ans = Read-Host "WARNING: WorkBuddy 仍在运行, 迁移可能失败. 请先完全关闭后重跑, 或输入 Y 强制(不推荐). (Y/N)"
    if ($ans -notmatch '^[Yy]') { exit 0 }
}

$maps = @(
    @{ Src = "$env:USERPROFILE\.workbuddy";                       Dst = "$TargetRoot\.workbuddy" },
    @{ Src = "$env:USERPROFILE\WorkBuddy";                        Dst = "$TargetRoot\WorkBuddy" },
    @{ Src = "$env:LOCALAPPDATA\@genieworkbuddy-desktop-updater"; Dst = "$TargetRoot\AppDataLocal\@genieworkbuddy-desktop-updater" },
    @{ Src = "$env:LOCALAPPDATA\WorkBuddy";                       Dst = "$TargetRoot\AppDataLocal\WorkBuddy" },
    @{ Src = "$env:LOCALAPPDATA\CodeBuddyExtension";              Dst = "$TargetRoot\AppDataLocal\CodeBuddyExtension" }
)

# 预生成回滚脚本
$rb = @('# rollback-workbuddy-move.ps1 (自动生成)', '# 异常时: 删 junction 并恢复原文件夹', '$ErrorActionPreference = "Stop"')
foreach ($m in $maps) {
    $s = $m.Src; $b = "$($m.Src).orig-backup"
    $rb += ""; $rb += "# 还原: $s"
    $rb += "if (Test-Path '$s') { cmd /c rmdir '$s' }"
    $rb += "if (Test-Path '$b') { Rename-Item '$b' '$s' -Force }"
}
if (-not (Test-Path $TargetRoot)) { New-Item -ItemType Directory -Path $TargetRoot -Force | Out-Null }
$rb | Out-File -FilePath "$TargetRoot\rollback-workbuddy-move.ps1" -Encoding utf8

$ans = Read-Host "`n确认迁移以上 $($maps.Count) 个目录到 $TargetRoot ? (Y/N)"
if ($ans -notmatch '^[Yy]') { exit 0 }

$failures = @()
foreach ($m in $maps) {
    $Src = $m.Src; $Dst = $m.Dst; $backup = "$($m.Src).orig-backup"
    Write-Host "`n=== 处理: $Src ===" -ForegroundColor Cyan
    if (-not (Test-Path $Src)) { Write-Host "  源不存在, 跳过。" -ForegroundColor Yellow; continue }
    $item = Get-Item $Src -Force
    if ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { Write-Host "  已是 junction, 跳过(已完成)。" -ForegroundColor Green; continue }
    try {
        if (Test-Path $Dst) {
            Write-Host "  目标已存在(部分残留), 刷新: $Dst" -ForegroundColor Yellow
            robocopy "$Src" "$Dst" /E /COPY:DAT /DCOPY:T /R:1 /W:1 /XJ /MT:8 /NFL /NDL | Out-Null
        } else {
            Write-Host "  复制 $Src -> $Dst ..." -ForegroundColor White
            robocopy "$Src" "$Dst" /E /COPY:DAT /DCOPY:T /R:1 /W:1 /XJ /MT:8 /NFL /NDL | Out-Null
            $rc = $LASTEXITCODE
            if ($rc -ge 8) { throw "robocopy 失败 (退出码 $rc)" }
            Write-Host "  复制完成 (退出码 $rc, <8 即成功)。" -ForegroundColor Green
        }
        if (-not (VerifyComplete $Src $Dst)) { throw "校验失败(子目录可能未被复制), 中止以免误删源" }
        $ok = $false
        for ($i = 1; $i -le 3; $i++) {
            try {
                if (Test-Path $backup) { Remove-Item $backup -Recurse -Force -ErrorAction Stop }
                Rename-Item $Src $backup -Force -ErrorAction Stop
                & cmd /c mklink /J "$Src" "$Dst" | Out-Null
                if (Test-Path $Src) { $ok = $true; break }
            } catch {
                Write-Host "  尝试 $i 失败: $($_.Exception.Message)" -ForegroundColor Yellow
                Start-Sleep -Seconds 3
            }
        }
        if (-not $ok) { throw "改名或建 junction 失败(请确认 WorkBuddy 已完全关闭)" }
        Write-Host "  已建 junction: $Src -> $Dst" -ForegroundColor Green
    } catch {
        Write-Host "  [FAIL] $Src : $($_.Exception.Message)" -ForegroundColor Red
        $failures += $Src
    }
}

function Get-JunctionTarget($path){ $o=fsutil reparsepoint query "$path" 2>$null; if($o -match 'Print Name:\s*(.+)'){return $matches[1].Trim()}; return $null }
function Get-SizeMB($path){ try{ $s=(Get-ChildItem $path -Recurse -Force -ErrorAction SilentlyContinue | Where-Object{-not($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint)} | Measure-Object -Property Length -Sum).Sum; return [math]::Round($s/1MB,1)}catch{return $null} }
Write-Host "`n---------- 自动验证 ----------" -ForegroundColor Cyan
$allOk=$true
foreach ($m in $maps) {
    $Src=$m.Src; $Dst=$m.Dst; $it=Get-Item $Src -Force -ErrorAction SilentlyContinue
    $isJ=$it -and ($it.Attributes -band [System.IO.FileAttributes]::ReparsePoint)
    if ($isJ) {
        $t=Get-JunctionTarget $Src; $ok=$t -and (Test-Path $t) -and ($t -like "$($TargetRoot[0]):\*")
        if ($ok){ $s=Get-SizeMB $Dst; $suf=if($s){"  (${s} MB)"}else{""}; Write-Host "  [OK]   $Src -> $t$suf" -ForegroundColor Green }
        else { Write-Host "  [FAIL] $Src junction 异常: 目标='$t'" -ForegroundColor Red; $allOk=$false }
    } else { Write-Host "  [FAIL] $Src 不是 junction" -ForegroundColor Red; $allOk=$false }
}
Write-Host "`n=========================================" -ForegroundColor Green
if ($allOk){ Write-Host "迁移完成且验证通过! 所有目录已重定向到 $TargetRoot。" -ForegroundColor Green }
else { Write-Host "部分未完成, 关闭 WorkBuddy 后重跑(幂等, 自动补齐)。失败项: $($failures -join ', ')" -ForegroundColor Yellow }
Write-Host "下一步: 1)启动 WorkBuddy 确认正常 2)确认后删 .orig-backup 释放 C 盘 3)异常跑 $TargetRoot\rollback-workbuddy-move.ps1" -ForegroundColor White
Write-Host "=========================================" -ForegroundColor Green
