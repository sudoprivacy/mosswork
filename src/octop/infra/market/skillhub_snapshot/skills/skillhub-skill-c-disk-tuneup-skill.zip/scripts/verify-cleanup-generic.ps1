﻿# verify-cleanup-generic.ps1 (只读, 不改任何文件)
# 复核 C 盘用户数据 junction 迁移结果: 是否 junction、指向副盘、体积是否合理, 并统计可释放的 .orig-backup.
$DataRoot='X:\AppDataData'   # <-- 与清理脚本一致
$roots = @($env:USERPROFILE, $env:LOCALAPPDATA, $env:APPDATA)
function Get-JunctionTarget($p){ try{ $o=cmd /c "fsutil reparsepoint query `"$p`"" 2>$null; if($o -match 'Print Name:\s*(.+)'){return $matches[1].Trim()} }catch{}; return $null }
function Get-SizeMB($p){ try{ $s=(Get-ChildItem $p -Recurse -Force -ErrorAction SilentlyContinue | Where-Object{-not($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint)} | Measure-Object -Property Length -Sum).Sum; return [math]::Round($s/1MB,1)}catch{return $null} }
$allOk=$true; $reclaimMB=0
Write-Host "`n========== C 盘清理迁移状态验证 ==========`n" -ForegroundColor Cyan
foreach($r in $roots){
    Get-ChildItem -Path $r -Directory -Force -ErrorAction SilentlyContinue | Where-Object { $_.Attributes -band [System.IO.FileAttributes]::ReparsePoint } | ForEach-Object {
        $src=$_.FullName; $t=Get-JunctionTarget $src
        $ok = $t -and (Test-Path $t) -and ($t -like "$($DataRoot[0]):\*")
        if($ok){ $s=Get-SizeMB $t; Write-Host ("  [OK]   {0} -> {1} ({2} MB)" -f $src,$t,$s) -ForegroundColor Green }
        else { Write-Host ("  [FAIL] {0} junction 异常: {1}" -f $src,$t) -ForegroundColor Red; $allOk=$false }
        $backup="$($src).orig-backup"
        if(Test-Path $backup){ $bMB=Get-SizeMB $backup; if($null -ne $bMB){$reclaimMB+=$bMB; Write-Host ("        备份: {0} ({1} MB)" -f $backup,$bMB) -ForegroundColor Gray} }
    }
}
Write-Host "`n============================================" -ForegroundColor Cyan
if($allOk){ Write-Host "结论: 所有 junction 指向副盘且可访问。" -ForegroundColor Green } else { Write-Host "结论: 存在异常 junction, 需修复。" -ForegroundColor Yellow }
if($reclaimMB -gt 0){ Write-Host ("可释放 C 盘备份空间: 约 {0} MB" -f $reclaimMB) -ForegroundColor White }
Write-Host "============================================" -ForegroundColor Cyan
