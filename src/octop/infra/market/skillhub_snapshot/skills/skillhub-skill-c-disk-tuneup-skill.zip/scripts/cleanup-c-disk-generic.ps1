﻿# cleanup-c-disk-generic.ps1
# 把 C 盘用户数据(个人目录 + AppData 大块头)经 junction 迁到副盘, 释放 C 盘空间.
# 【一键 + 自动关进程】: 运行本脚本会自动关闭"数据被迁"的常驻程序(微信/Steam/浏览器等)以释放文件锁, 无需手动关.
# 默认【不迁浏览器数据】(避免副盘若是 HDD 时浏览器卡顿). 如需迁移浏览器, 把 $browserPatterns 清空即可(会自动关浏览器).
# 安全: 绝不会关闭 explorer / WorkBuddy / 杀毒软件(360/火绒/Defender) 等系统关键进程; 若被这类进程锁定则跳过并提示.
# 用法: 在 WorkBuddy 之外的独立 PowerShell 运行:
#       powershell -ExecutionPolicy Bypass -File "X:\scripts\cleanup-c-disk-generic.ps1"
$ErrorActionPreference = 'Continue'
$DataRoot = 'X:\AppDataData'   # <-- 改成目标机副盘实际路径(固定磁盘)
if (-not (Test-Path $DataRoot)) { New-Item -ItemType Directory -Path $DataRoot -Force | Out-Null }

# 要迁移的目录名(相对各 root). 自行增删. 默认排除浏览器与系统绑定目录.
$targetNames = @(
    'WeChat','Tencent','360se','360chrome','360huabao',
    'Steam','SteamLibrary','EpicGamesLauncher',
    'TencentDocs','WPS','Kingsoft','wpscloud',
    'BaiduNetdisk','Thunder','Xunlei','qihoo',
    'DingTalk','Lark','Feishu','WXWork',
    'NVIDIA','nv','Adobe','AdobeCache',
    'Code','VisualStudio','JetBrains','AndroidStudio',
    'Spotify','NeteaseCloudMusic','QQMusic',
    'Downloads','Documents','Music','Videos','Pictures','Saved Games','3D Objects'
)
# 浏览器名模式(命中则跳过, 除非把此数组清空). 避免副盘 HDD 导致浏览器卡顿.
$browserPatterns = @('Google','360*','Quark','Chrome','Edge','Firefox','Opera','Brave','MicrosoftEdge')
# 是否迁移浏览器(清空 $browserPatterns 时为 $true, 此时自动关浏览器进程)
$migrateBrowsers = ($browserPatterns.Count -eq 0)

# ===== 自动关进程配置 =====
# 数据被迁的常驻程序 -> 进程名(迁移前自动关闭以释放锁). 仅关"数据被迁"的程序, 不关系统关键进程.
$safeKillMap = @{
    'WeChat'            = @('WeChat','WeChatAppEx','WeChatPlayer','WeChatWeb');
    'Tencent'           = @('QQ','TXPlatform','QQMusic');
    'QQMusic'           = @('QQMusic','QQMusicService');
    'WPS'               = @('wps','wpscloudsvr','et','wpp','wpspdf');
    'Kingsoft'          = @('wps','wpscloudsvr');
    'TencentDocs'       = @('wps','TXPlatform');
    'Steam'             = @('steam','steamwebhelper');
    'SteamLibrary'      = @('steam','steamwebhelper');
    'EpicGamesLauncher' = @('EpicGamesLauncher','EOSWebHelper');
    'BaiduNetdisk'      = @('BaiduNetdisk','baidunetdisk','BaiduNetdiskHost');
    'Thunder'           = @('Thunder','xllive','XLServicePlatform','ThunderPlatform');
    'Xunlei'            = @('Thunder','xllive');
    'DingTalk'          = @('DingTalk');
    'Lark'              = @('Feishu','Lark');
    'Feishu'            = @('Feishu','Lark');
    'WXWork'            = @('WXWork');
    'Spotify'           = @('Spotify');
    'NeteaseCloudMusic' = @('cloudmusic');
    'Adobe'             = @('AdobeIPC','CreativeCloud');
    'AdobeCache'        = @('AdobeIPC');
    'NVIDIA'            = @('nvcontainer','NVIDIA Web Helper');
    'nv'                = @('nvcontainer');
    'Wallpaper'         = @('wallpaper32','wallpaperservice','wallpaperservice32_c');
    'Code'              = @('Code');
    'VisualStudio'      = @('devenv');
    'JetBrains'         = @('idea64','pycharm64','clion64','WebStorm');
    'AndroidStudio'     = @('studio64')
}
$browserKill = @('chrome','msedge','firefox','opera','brave','360chrome','Quark','360se','MicrosoftEdge')
# 永不关闭的关键/系统/杀毒进程(误杀会崩系统或失防护)
$neverKill = @(
    'explorer','WorkBuddy','CodeBuddy','genieworkbuddy',
    '360safe','360tray','360sd','HipsDaemon','Huorong','mfevtps','MsMpEng','WinDefend','SecurityHealthService',
    'lsass','csrss','winlogon','services','svchost','System','Registry','smss','wininit','dllhost',
    'conhost','RuntimeBroker','dwm','fontdrvhost','taskhostw','sihost','ctfmon','audiodg','spoolsv',
    'SearchIndexer','ShellExperienceHost','SearchUI','powershell','cmd'
)

function Get-ProcessNamesToKill($names){
    $set = @{}
    foreach($n in $names){ if($safeKillMap.ContainsKey($n)){ foreach($p in $safeKillMap[$n]){ $set[$p]=$true } } }
    if($migrateBrowsers){ foreach($p in $browserKill){ $set[$p]=$true } }
    $out=@()
    foreach($k in $set.Keys){ if($k -notin $neverKill){ $out += $k } }
    return $out
}
function Close-SafeProcesses($names){
    $killed=@()
    foreach($nm in $names){
        if($nm -in $neverKill){ continue }
        $procs = @(Get-Process -Name $nm -ErrorAction SilentlyContinue)
        if($procs.Count -eq 0){ continue }
        Write-Host "  关闭进程: $nm (x$($procs.Count))" -ForegroundColor Yellow
        foreach($p in $procs){ try { $null = $p.CloseMainWindow() } catch {} }
        Start-Sleep -Seconds 3
        if(@(Get-Process -Name $nm -ErrorAction SilentlyContinue).Count -gt 0){
            try { Stop-Process -Name $nm -Force -ErrorAction SilentlyContinue } catch {}
            Start-Sleep -Seconds 2
        }
        if(@(Get-Process -Name $nm -ErrorAction SilentlyContinue).Count -eq 0){ $killed += $nm; Write-Host "    已终止: $nm" -ForegroundColor Green }
        else { Write-Host "    仍运行(系统/服务保护, 将跳过其数据目录): $nm" -ForegroundColor Red }
    }
    return $killed
}
# 校验: 文件数必须完全一致, 总大小偏差 <= 0.5%. 本机过滤驱动会抑制 robocopy 默认递归(必须 /E), 缺失子目录会令文件数骤降 -> 此处拦截, 杜绝误删.
function VerifyComplete($s, $d){
    $sf = @(Get-ChildItem -LiteralPath $s -Recurse -Force -File -ErrorAction SilentlyContinue | Where-Object{ -not ($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) })
    $df = @(Get-ChildItem -LiteralPath $d -Recurse -Force -File -ErrorAction SilentlyContinue)
    $sc=$sf.Count; $dc=$df.Count
    $ss=if($sc-eq0){0}else{($sf|Measure-Object -Property Length -Sum).Sum}
    $ds=if($dc-eq0){0}else{($df|Measure-Object -Property Length -Sum).Sum}
    $ratio = if($ds -eq 0){1}else{[Math]::Abs($ss-$ds)/$ds}
    if($sc -eq $dc -and $ratio -le 0.005){ return $true }
    Write-Host ("    !! 校验不一致: 源 文件数=$sc 大小=$ss / 目标 文件数=$dc 大小=$ds -> 中止(防漏拷/误删)") -ForegroundColor Red
    return $false
}

$roots = @(
    @{ Tag='Home';    Path=$env:USERPROFILE },
    @{ Tag='Local';   Path=$env:LOCALAPPDATA },
    @{ Tag='Roaming'; Path=$env:APPDATA }
)
function Match-Pattern($name, $pats){ foreach($p in $pats){ if($name -like $p){ return $true } }; return $false }

Write-Host "C 盘清理(用户数据 junction 迁移). 目标根: $DataRoot" -ForegroundColor Cyan
Write-Host "排除浏览器: $($browserPatterns -join ', ')" -ForegroundColor Yellow

# === 自动关闭占用进程(一键核心) ===
$toKill = Get-ProcessNamesToKill $targetNames
if($toKill.Count -gt 0){
    Write-Host "`n[自动关进程] 即将关闭以下程序以释放文件锁(未保存内容可能丢失):" -ForegroundColor Yellow
    Write-Host "  $($toKill -join ', ')" -ForegroundColor White
    Write-Host "  按 Enter 继续(自动关闭并迁移), 或 Ctrl+C 取消:" -ForegroundColor Cyan
    Read-Host | Out-Null
    $killed = Close-SafeProcesses $toKill
    Write-Host ("[自动关进程] 已终止: $($killed -join ', ')") -ForegroundColor Green
} else {
    Write-Host "[自动关进程] 无需关闭的常驻程序." -ForegroundColor DarkGray
}

$processed=0; $skipped=0; $failed=@()
foreach ($r in $roots) {
    foreach ($name in $targetNames) {
        if (Match-Pattern $name $browserPatterns) { continue }
        if ($name -in @('Microsoft','Packages')) { continue }   # 系统绑定, 不迁
        $src = Join-Path $r.Path $name
        if (-not (Test-Path -LiteralPath $src)) { continue }
        $it = Get-Item -LiteralPath $src -Force -ErrorAction SilentlyContinue
        if ($it -and ($it.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) { Write-Host "  跳过(已是junction): $src" -ForegroundColor DarkGray; $skipped++; continue }
        $dst = Join-Path $DataRoot $r.Tag $name
        Write-Host "`n=== 处理: $src ===" -ForegroundColor Cyan
        try {
            if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst -Force | Out-Null }
            # 必须 /E: 本机(360 过滤驱动)会抑制 robocopy 默认递归, 缺 /E 会漏拷子目录 -> 删源即丢数据
            robocopy "$src" "$dst" /E /COPY:DAT /DCOPY:T /R:1 /W:1 /XJ /MT:8 /NFL /NDL | Out-Null
            if (-not (VerifyComplete $src $dst)) { throw "校验失败(子目录可能未被复制)" }
            $ok=$false
            for($i=1;$i-le3;$i++){
                try {
                    $backup = "$src.orig-backup"
                    if (Test-Path $backup) { Remove-Item $backup -Recurse -Force -ErrorAction Stop }
                    Rename-Item $src $backup -Force -ErrorAction Stop
                    & cmd /c mklink /J "$src" "$dst" | Out-Null
                    if (Test-Path $src) { $ok=$true; break }
                } catch { Write-Host "  尝试 $i 失败: $($_.Exception.Message)" -ForegroundColor Yellow; Start-Sleep -Seconds 2 }
            }
            if(-not $ok){ throw "改名/建junction失败(若被系统/杀毒进程锁定, 请重启后重跑)" }
            Write-Host "  已建 junction: $src -> $dst" -ForegroundColor Green; $processed++
        } catch {
            Write-Host "  [FAIL] $src : $($_.Exception.Message)" -ForegroundColor Red; $failed += $src
        }
    }
}
Write-Host "`n========== 完成 ==========" -ForegroundColor Green
Write-Host "已处理: $processed  跳过(junction/不存在): $skipped  失败: $($failed.Count)" -ForegroundColor White
if($failed.Count){ Write-Host "失败项(多为被系统/杀毒进程锁定): 重启后重跑本脚本(幂等补齐): $($failed -join ', ')" -ForegroundColor Yellow }
Write-Host "下一步: 确认应用正常 -> 跑 verify-cleanup-generic.ps1 -> 确认后跑 delete-backups-generic.ps1(输入YES释放C盘)" -ForegroundColor White
