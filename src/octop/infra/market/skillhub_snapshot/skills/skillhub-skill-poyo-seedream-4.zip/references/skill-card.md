## Description: <br>
Helps agents prepare and submit PoYo Seedream 4 image generation and editing requests, including payloads, curl commands, async polling, callbacks, and server-side safety guidance. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[coolhackboy](https://clawhub.ai/user/coolhackboy) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and engineers use this skill to build PoYo Seedream 4 text-to-image, reference-guided generation, and image-editing workflows with server-side API keys, request payloads, polling, and callback handling. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: POYO_API_KEY can be exposed if copied into browser code, logs, screenshots, public repositories, or chat output. <br>
Mitigation: Store POYO_API_KEY only in server-side environment variables or a backend secret manager, and redact authorization headers from outputs. <br>
Risk: Private prompts, source image URLs, generated output URLs, callback URLs, or task IDs may reveal sensitive workflow data. <br>
Mitigation: Review payloads before submission and avoid sending private prompts or image URLs unless the user is comfortable sharing them with PoYo. <br>
Risk: Live API submission can incur external processing and send user content to PoYo. <br>
Mitigation: Submit requests only after explicit user confirmation and only from a trusted server-side environment. <br>


## Reference(s): <br>
- [PoYo Seedream 4 API Reference](references/api.md) <br>
- [PoYo Seedream 4 model page](https://poyo.ai/models/seedream-4) <br>
- [PoYo Seedream 4 API docs](https://docs.poyo.ai/api-manual/image-series/seedream-4) <br>
- [PoYo Seedream 4 OpenAPI JSON](https://docs.poyo.ai/api-manual/image-series/seedream-4.json) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown with JSON payloads and shell command examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May include PoYo request payloads, status polling steps, callback guidance, and returned task IDs when a request is submitted.] <br>

## Skill Version(s): <br>
1.0.1 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
