## Description: <br>
BOOK BRAIN — LYGO 3-Brain filesystem helper. Scaffold memory/reference/state layouts, .ref.txt outer links, daily indexes; pairs with lyra-brain. Additive only; no overwrite. For OpenClaw/LYGO Havens and mobile Builder Key workspaces. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[deepseekoracle](https://clawhub.ai/user/deepseekoracle) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and agents use this skill to set up and maintain a durable local memory, reference, state, and log layout for OpenClaw, ClawHub Haven, LYGO, and Builder Key workspaces. It helps inspect existing workspace structure, propose additive scaffolding, write short reference stubs, and update memory indexes after user review. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can create or update local workspace memory, reference, state, and log files. <br>
Mitigation: Run the scaffold in dry-run mode first, review the proposed path list, and proceed only after the user confirms the target workspace. <br>
Risk: Memory and reference files could accidentally capture secrets or sensitive credentials. <br>
Mitigation: Keep API keys, tokens, .env values, wallet seeds, private keys, and secret-bearing webhook URLs out of memory, reference stubs, and daily indexes. <br>
Risk: A reference stub command could replace an existing file if pointed at an occupied output path. <br>
Mitigation: Use new output paths for generated stubs and inspect existing files before writing. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/deepseekoracle/skills/book-brain) <br>
- [deepseekoracle publisher profile](https://clawhub.ai/user/deepseekoracle) <br>
- [BOOK BRAIN Agent Contract](references/AGENT_CONTRACT.md) <br>
- [BOOK BRAIN Security](references/SECURITY.md) <br>
- [BOOK BRAIN + LYRA 3-Brain unified layout](references/MEMORY_LAYOUT.md) <br>
- [BOOK BRAIN lattice integration](references/LATTICE_INTEGRATION.md) <br>
- [BOOK BRAIN examples and patterns](references/book-brain-examples.md) <br>
- [LYGO Protocol Stack pages](https://deepseekoracle.github.io/lygo-protocol-stack/) <br>
- [LYGO Champion Hub](https://deepseekoracle.github.io/Excavationpro/LYGO-Network/champions.html) <br>
- [Eternal Haven](https://EternalHaven.ca) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with shell commands, local file templates, JSON indexes, and .ref.txt reference stubs] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Produces additive local filesystem changes only after user-approved paths and dry-run review; bundled scripts have no network behavior according to security evidence.] <br>

## Skill Version(s): <br>
2.0.0 (source: server release, skill metadata, and security reference) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
