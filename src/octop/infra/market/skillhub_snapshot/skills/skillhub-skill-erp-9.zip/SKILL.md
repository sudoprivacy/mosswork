---
name: skillhub-skill-erp-9
description: "# Skill: ERP 菜单功能 · 仓库商品信息"
---

# Skill: ERP 菜单功能 · 仓库商品信息

## 触发场景

当用户用自然语言询问以下类型的问题时，应加载本技能并执行对应的 ERP 查询/操作：

- **典型示例**："查看配货仓库中的商品信息"
- **口语变体**：同义表达（如"库存"→"存量"/"余量"、入库→"进货"/"收货"、出库→"出货"/"发货"、收款→"回款"/"进账"等）
- **菜单匹配**：输入"菜单"/"功能菜单"/"帮助"/"?" 时展示全部功能列表

## 功能定位

> 列出各仓库中的商品、数量与库存金额。

## 路由映射

调用后端服务 `ReplenishmentAssistant.handle()` 时传入：
```python
params = {"action": "warehouse_products", "entities": {...}}
```

- **action**: `"warehouse_products"`
- **entities**: 按以下实体槽位填充（由后端 NLPEngine.parse() 自动完成，本技能仅告知需要抽取的实体）

## 实体抽取

需要在 NLP 意图中提取以下实体槽位（由 _extract_entities 自动解析，LLM 路径下由模型直接输出 JSON）：
  - `warehouse`
  - `keyword`

## 返回格式

返回的 `dict` 包含至少以下字段：
- `reply`: 格式化的回复文本（含 Markdown 表格/列表）
- `action`: 当前执行的动作名称（用于路由追踪）

回复中会自动追加「📊 智能分析与建议」段（含分析结论 + 可行动建议），由 `_make_analysis()` 统一处理。

## 注意事项

1. 所有查询接口支持 `time_range`（默认最近 30 天）和 `top_n`（默认 10 条）参数
2. 时间范围口语解析：本月/上月/本周/上周/今年/最近N天/前N天
3. 当 `.env` 中 `AI_API_KEY` 为有效值时，回复自动走 LLM 增强分析；否则降级为规则引擎兜底
4. 写操作类（开单/审批/申请）只生成草稿+预览，不直接写入 ERP 数据库 `yszt` 账套
5. 数据来源：H3ERP SQL Server 账套 `yszt`

## 依赖

启动后端服务后才能使用：
```bash
# 方式一：双击 start.bat
D:\辉煌\start.bat

# 方式二：手动启动
D:\辉煌\workbuddy_erp_sales\.venv\Scripts\python.exe run_server.py
```

## 相关文件

- `procurement_scenarios/replenishment_assistant.py` — 主 handler（路由 + 查询 + 格式化）
- `ai_dialog_layer/nlp_engine.py` — 自然语言解析（LLM 优先 / 规则兜底）
- `erp_core/h3erp/service.py` — H3ERP 真实数据查询（真实库路径）
- `erp_core/procurement/service.py` — 演示数据路径（`H3ERP_ENABLED=false` 时）
