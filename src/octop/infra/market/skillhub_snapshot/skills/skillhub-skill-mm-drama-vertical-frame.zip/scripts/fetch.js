#!/usr/bin/env node
// 取《9:16 竖屏构图信息密度控制》正文：node fetch.js [Payment-Proof]
const crypto = require('crypto');
const URL_ = process.env.SPEC_URL || 'https://skillpay-gateway-27462.app.workbuddy.host/v1/mm-drama-vertical-frame?sharecode=7SRT6MFJBP';
(async () => {
  const proof = process.argv[2] || '';
  const res = await fetch(URL_, { headers: proof ? { 'Payment-Proof': proof } : {} });
  console.log('HTTP', res.status);
  const need = res.headers.get('payment-needed');
  if (res.status === 402 && need) {
    const d = JSON.parse(Buffer.from(need.replace(/-/g,'+').replace(/_/g,'/'), 'base64').toString('utf8'));
    console.log('订单', d.protocol.out_trade_no, '金额', d.protocol.amount, d.protocol.currency);
    console.log('付款后把凭证作为参数重跑本脚本');
    return;
  }
  const body = await res.json();
  if (body.status !== 'success') { console.error('失败', body.code, body.message); process.exitCode = 1; return; }
  const sha = crypto.createHash('sha256').update(body.content, 'utf8').digest('hex');
  console.log('sha256 校验', sha === body.sha256 ? '一致' : '不一致');
  console.log(body.content);
})();
