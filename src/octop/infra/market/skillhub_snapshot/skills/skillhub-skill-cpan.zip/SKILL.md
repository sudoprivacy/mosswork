---
name: skillhub-skill-cpan
description: "# C 盘安全垃圾清理"
---

# C 盘安全垃圾清理

## 原则（安全第一）

1. **先扫描，后清理** —— `scan.ps1` 只读，绝不删除。
2. **默认预览** —— `clean.ps1` 不加 `-Execute` 只列将要删除的内容与可释放空间。
3. **显式确认** —— 真正删除必须传 `-Execute`，执行前再次提示“不可撤销”。
4. **只删白名单** —— 仅清理 `references/safe_locations.md` 中的安全垃圾位置；任何目标落入受保护目录立即中止。
5. **锁文件容错** —— 被程序占用的文件静默跳过，不中断。
6. **大目录只建议** —— AppData 下的大目录（微信/QQ/Chrome 用户数据等）仅列出，提示迁移到 D 盘，不自动删。

## 触发场景

- “C盘红了/满了，帮我清一下”
- “清理C盘垃圾文件”
- “释放点磁盘空间”
- 用户只想删临时/缓存垃圾，不想迁移个人数据

## 工作流

### 第 1 步：扫描（必做，只读）
运行 `scripts/scan.ps1`，得到每个安全垃圾位置的可释放空间、文件数，以及清理后预计可用百分比。
也可加 `-Json` 获取结构化数据，或 `-TopBigFolders 0` 跳过“大目录迁移建议”。

```powershell
powershell -ExecutionPolicy Bypass -File "<skill>/scripts/scan.ps1"
```

### 第 2 步：向用户汇报，等待确认
展示报告，明确：可清理合计、清理后预计可用空间、以及“受保护目录绝不触碰”的保证。
**在用户明确同意前，不进入第 3 步。**

### 第 3 步：预览待删（默认行为）
```powershell
powershell -ExecutionPolicy Bypass -File "<skill>/scripts/clean.ps1"
```
不加参数即预览模式，只列出将删除项与合计空间，不做任何改动。

### 第 4 步：执行清理（需显式 -Execute）
仅当用户确认后执行：
```powershell
powershell -ExecutionPolicy Bypass -File "<skill>/scripts/clean.ps1" -Execute
```
可按类别清理，例如只清临时文件与回收站：
```powershell
powershell -ExecutionPolicy Bypass -File "<skill>/scripts/clean.ps1" -Execute -Categories SystemTemp,UserTemp,RecycleBin
```
可用类别：SystemTemp, UserTemp, WinUpdate, Prefetch, ThumbCache, WER, INetCache, RecycleBin, BrowserCache。

## 安全位置（详见 references）

- ✅ 白名单：`C:\Windows\Temp`、用户 Temp、更新下载缓存、Prefetch、缩略图缓存、WER、INetCache、当前用户回收站、Chrome/Edge 缓存。
- ⛔ 黑名单（绝不触碰）：桌面 / 文档 / 下载 / 图片 / 视频 / 音乐，以及任何非白名单的个人目录。

## 话术风格

直白、给结论、强调安全：
- ✅ “扫描完，安全垃圾合计 8.6 GB，清理后 C 盘可用从 12% 升到 23%。桌面/文档/下载我不会碰。”
- ✅ “下面是预览，确认后我加 -Execute 真正清理；锁住的文件会自动跳过。”
- ❌ 不夸大、不承诺“瞬间提速”、不删用户数据。
