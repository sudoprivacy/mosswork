﻿<#
.SYNOPSIS
    C 盘安全垃圾扫描（只读，绝不删除）。
.DESCRIPTION
    扫描 Windows / 用户临时文件、系统更新缓存、回收站、浏览器缓存、缩略图缓存、
    错误报告等“安全可清理”位置，统计可释放空间，并额外列出占用大的 AppData 目录
    （仅作迁移建议，不删除）。所有受保护目录（桌面/下载/文档/图片/视频/音乐等）一律跳过。
.PARAMETER Json
    以 JSON 输出结果，便于程序解析。
.PARAMETER TopBigFolders
    额外列出占用最大的 Local/Roaming 应用目录数量（默认 8，0 表示跳过）。
#>
[CmdletBinding()]
param(
    [switch]$Json,
    [int]$TopBigFolders = 8
)

$ErrorActionPreference = 'SilentlyContinue'

# ---------- 工具函数 ----------
function Format-Size {
    param([double]$Bytes)
    if ($Bytes -ge 1TB) { return '{0:N2} TB' -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return '{0:N2} GB' -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return '{0:N2} MB' -f ($Bytes / 1MB) }
    if ($Bytes -ge 1KB) { return '{0:N2} KB' -f ($Bytes / 1KB) }
    return '{0} B' -f $Bytes
}

function Measure-Dir {
    param([string]$Path, [string]$Label, [string]$Category)
    if (-not (Test-Path -LiteralPath $Path)) {
        return [PSCustomObject]@{ Path = $Path; Label = $Label; Category = $Category; Exists = $false; Size = 0; Files = 0 }
    }
    $items = Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue
    $sum = 0; $count = 0
    foreach ($it in $items) {
        if (-not $it.PSIsContainer) {
            try { $sum += $it.Length; $count++ } catch {}
        }
    }
    return [PSCustomObject]@{ Path = $Path; Label = $Label; Category = $Category; Exists = $true; Size = $sum; Files = $count }
}

# ---------- 受保护目录（绝不扫描/删除）----------
# 仅用于说明与兜底校验，扫描列表本身不会包含这些路径。
$ProtectedDirs = @(
    [Environment]::GetFolderPath('Desktop'),
    [Environment]::GetFolderPath('MyDocuments'),
    [Environment]::GetFolderPath('MyMusic'),
    [Environment]::GetFolderPath('MyPictures'),
    [Environment]::GetFolderPath('MyVideos'),
    (Join-Path $env:USERPROFILE 'Downloads')
)

# ---------- 安全垃圾位置白名单 ----------
$sid = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
$JunkSpecs = @(
    @{ Path = 'C:\Windows\Temp';                            Label = 'Windows 临时文件';     Category = 'SystemTemp' },
    @{ Path = $env:TEMP;                                   Label = '用户临时文件 (TEMP)';  Category = 'UserTemp' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Temp');        Label = 'LocalAppData 临时文件'; Category = 'UserTemp' },
    @{ Path = 'C:\Windows\SoftwareDistribution\Download';  Label = 'Windows 更新下载缓存';  Category = 'WinUpdate' },
    @{ Path = 'C:\Windows\Prefetch';                       Label = '预读取缓存 (Prefetch)'; Category = 'Prefetch' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'); Label = '缩略图缓存'; Category = 'ThumbCache' },
    @{ Path = 'C:\ProgramData\Microsoft\Windows\WER';       Label = 'Windows 错误报告';      Category = 'WER' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\INetCache'); Label = 'IE/Edge 临时网络文件'; Category = 'INetCache' },
    @{ Path = "C:\`$Recycle.Bin\$sid";                     Label = '回收站 (当前用户)';     Category = 'RecycleBin' },
    # 浏览器缓存
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Cache'); Label = 'Chrome 缓存'; Category = 'BrowserCache' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Cache'); Label = 'Edge 缓存';  Category = 'BrowserCache' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Code Cache'); Label = 'Chrome 代码缓存'; Category = 'BrowserCache' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Code Cache'); Label = 'Edge 代码缓存'; Category = 'BrowserCache' }
)

# 去重：同一物理路径（如 TEMP 与 LocalAppData\Temp 常指向同一目录）只计一次
$seenPaths = @{}
$uniqueSpecs = @()
foreach ($s in $JunkSpecs) {
    try { $rp = [System.IO.Path]::GetFullPath($s.Path) } catch { $rp = $s.Path }
    if ($seenPaths.ContainsKey($rp)) { continue }
    $seenPaths[$rp] = $true
    $uniqueSpecs += $s
}
$JunkSpecs = $uniqueSpecs

$results = foreach ($s in $JunkSpecs) {
    Measure-Dir -Path $s.Path -Label $s.Label -Category $s.Category
}

$totalRecoverable = ($results | Where-Object { $_.Exists } | Measure-Object -Property Size -Sum).Sum

# ---------- 大目录（迁移建议，不删除）----------
$bigFolders = @()
if ($TopBigFolders -gt 0) {
    $roots = @($env:LOCALAPPDATA, $env:APPDATA)
    $cands = foreach ($r in $roots) {
        Get-ChildItem -LiteralPath $r -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
            $sz = (Get-ChildItem -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum
            [PSCustomObject]@{ Name = $_.Name; Path = $_.FullName; Size = $sz }
        }
    }
    $bigFolders = $cands | Sort-Object Size -Descending | Select-Object -First $TopBigFolders
}

# ---------- 磁盘信息 ----------
$drive = Get-PSDrive -Name C -ErrorAction SilentlyContinue
$freeBytes = if ($drive) { $drive.Free } else { 0 }
$usedBytes = if ($drive) { $drive.Used } else { 0 }
$totalBytes = $freeBytes + $usedBytes
$freePctBefore = if ($totalBytes -gt 0) { [math]::Round($freeBytes / $totalBytes * 100, 1) } else { 0 }
$freePctAfter = if ($totalBytes -gt 0) { [math]::Round(($freeBytes + $totalRecoverable) / $totalBytes * 100, 1) } else { 0 }

# ---------- 输出 ----------
if ($Json) {
    $out = [PSCustomObject]@{
        JunkLocations   = $results
        TotalRecoverableBytes = [int64]$totalRecoverable
        TotalRecoverableHuman = Format-Size $totalRecoverable
        BigFolders      = $bigFolders
        Disk = [PSCustomObject]@{
            FreeBytesBefore = [int64]$freeBytes
            FreeHumanBefore = Format-Size $freeBytes
            FreePctBefore   = $freePctBefore
            FreePctAfter    = $freePctAfter
            TotalHuman      = Format-Size $totalBytes
        }
        ProtectedDirs   = $ProtectedDirs
    }
    $out | ConvertTo-Json -Depth 4
} else {
    Write-Host ''
    Write-Host '========== C 盘安全垃圾扫描报告（只读，未做任何删除）=========='
    Write-Host ''
    Write-Host ('磁盘 C:  总容量 {0}  |  当前可用 {1} ({2}%)' -f (Format-Size $totalBytes), (Format-Size $freeBytes), $freePctBefore)
    Write-Host ''
    Write-Host ('{0,-28} {1,14} {2,10}  路径' -f '项目', '可释放', '文件数')
    Write-Host ('-' * 100)
    foreach ($r in $results) {
        if ($r.Exists -and $r.Size -gt 0) {
            Write-Host ('{0,-26} {1,14} {2,10}  {3}' -f $r.Label, (Format-Size $r.Size), $r.Files, $r.Path)
        }
    }
    Write-Host ('-' * 100)
    Write-Host ('可清理合计: {0}' -f (Format-Size $totalRecoverable))
    Write-Host ('清理后预计可用: {0} ({1}%)' -f (Format-Size ($freeBytes + $totalRecoverable)), $freePctAfter)
    Write-Host ''
    if ($TopBigFolders -gt 0 -and $bigFolders.Count -gt 0) {
        Write-Host '----- 占用较大的应用目录（仅建议迁移到 D 盘，本工具不自动删除）-----'
        foreach ($b in $bigFolders) {
            if ($b.Size -gt 0) { Write-Host ('  {0,-22} {1,12}  {2}' -f $b.Name, (Format-Size $b.Size), $b.Path) }
        }
        Write-Host ''
    }
    Write-Host '受保护目录（绝不触碰）: ' + ($ProtectedDirs -join '; ')
    Write-Host ''
    Write-Host '下一步: 运行 clean.ps1 查看将删除内容（默认仅预览）；加 -Confirm 才真正清理。'
    Write-Host ''
}
