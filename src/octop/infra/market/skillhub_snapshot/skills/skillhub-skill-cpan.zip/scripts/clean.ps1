﻿<#
.SYNOPSIS
    C 盘安全垃圾清理（默认仅预览，需 -Execute 才真正删除）。
.DESCRIPTION
    仅清理 scan.ps1 中“安全垃圾白名单”内的内容：临时文件、更新缓存、回收站、
    浏览器缓存、缩略图缓存、错误报告等。绝不触碰受保护目录。
    默认 WhatIf/预览模式：只列出将要删除的内容与可释放空间，不做任何改动。
    必须显式传入 -Execute 才会真正删除（且会再次二次确认）。
.PARAMETER Execute
    真正执行删除。省略则仅预览。
.PARAMETER Categories
    仅清理指定类别（如 SystemTemp, UserTemp, WinUpdate, RecycleBin, BrowserCache, Prefetch, ThumbCache, WER, INetCache）。
.PARAMETER Json
    JSON 输出。
#>
[CmdletBinding()]
param(
    [switch]$Execute,
    [string[]]$Categories,
    [switch]$Json
)

$ErrorActionPreference = 'SilentlyContinue'

function Format-Size {
    param([double]$Bytes)
    if ($Bytes -ge 1TB) { return '{0:N2} TB' -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return '{0:N2} GB' -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return '{0:N2} MB' -f ($Bytes / 1MB) }
    if ($Bytes -ge 1KB) { return '{0:N2} KB' -f ($Bytes / 1KB) }
    return '{0} B' -f $Bytes
}

$ProtectedDirs = @(
    [Environment]::GetFolderPath('Desktop'),
    [Environment]::GetFolderPath('MyDocuments'),
    [Environment]::GetFolderPath('MyMusic'),
    [Environment]::GetFolderPath('MyPictures'),
    [Environment]::GetFolderPath('MyVideos'),
    (Join-Path $env:USERPROFILE 'Downloads')
)

$sid = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
$JunkSpecs = @(
    @{ Path = 'C:\Windows\Temp';                            Label = 'Windows 临时文件';     Category = 'SystemTemp' },
    @{ Path = $env:TEMP;                                   Label = '用户临时文件 (TEMP)';  Category = 'UserTemp' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Temp');        Label = 'LocalAppData 临时文件'; Category = 'UserTemp' },
    @{ Path = 'C:\Windows\SoftwareDistribution\Download';  Label = 'Windows 更新下载缓存';  Category = 'WinUpdate' },
    @{ Path = 'C:\Windows\Prefetch';                       Label = '预读取缓存 (Prefetch)'; Category = 'Prefetch' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'); Label = '缩略图缓存'; Category = 'ThumbCache' },
    @{ Path = 'C:\ProgramData\Microsoft\Windows\WER';       Label = 'Windows 错误报告';      Category = 'WER' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\INetCache'); Label = 'IE/Edge 临时网络文件'; Category = 'INetCache' },
    @{ Path = "C:\`$Recycle.Bin\$sid";                     Label = '回收站 (当前用户)';     Category = 'RecycleBin' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Cache'); Label = 'Chrome 缓存'; Category = 'BrowserCache' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Cache'); Label = 'Edge 缓存';  Category = 'BrowserCache' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Default\Code Cache'); Label = 'Chrome 代码缓存'; Category = 'BrowserCache' },
    @{ Path = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data\Default\Code Cache'); Label = 'Edge 代码缓存'; Category = 'BrowserCache' }
)

# 去重：同一物理路径只计一次（如 TEMP 与 LocalAppData\Temp）
$seenPaths = @{}
$uniqueSpecs = @()
foreach ($s in $JunkSpecs) {
    try { $rp = [System.IO.Path]::GetFullPath($s.Path) } catch { $rp = $s.Path }
    if ($seenPaths.ContainsKey($rp)) { continue }
    $seenPaths[$rp] = $true
    $uniqueSpecs += $s
}
$JunkSpecs = $uniqueSpecs

# 类别筛选
if ($Categories -and $Categories.Count -gt 0) {
    $JunkSpecs = $JunkSpecs | Where-Object { $Categories -contains $_.Category }
}

# 安全兜底：任何目标路径若落入受保护目录，立即中止
foreach ($s in $JunkSpecs) {
    foreach ($p in $ProtectedDirs) {
        if ($s.Path -like "$p*" -or $p -like "$($s.Path)*") {
            Write-Error "安全拦截：目标路径 $($s.Path) 落入受保护目录 $p，已中止。"
            exit 3
        }
    }
}

# 统计预览
$preview = foreach ($s in $JunkSpecs) {
    if (-not (Test-Path -LiteralPath $s.Path)) { continue }
    $items = Get-ChildItem -LiteralPath $s.Path -Recurse -Force -ErrorAction SilentlyContinue
    $sum = 0; $cnt = 0
    foreach ($it in $items) { if (-not $it.PSIsContainer) { try { $sum += $it.Length; $cnt++ } catch {} } }
    [PSCustomObject]@{ Label = $s.Label; Category = $s.Category; Path = $s.Path; Size = $sum; Files = $cnt }
}
$totalSize = ($preview | Measure-Object -Property Size -Sum).Sum

if (-not $Execute) {
    if ($Json) {
        [PSCustomObject]@{ Mode = 'Preview'; TotalBytes = [int64]$totalSize; TotalHuman = (Format-Size $totalSize); Items = $preview } | ConvertTo-Json -Depth 4
    } else {
        Write-Host ''
        Write-Host '========== 预览模式：以下内容将被清理（未做任何删除）=========='
        Write-Host ''
        Write-Host ('{0,-26} {1,14} {2,10}  路径' -f '项目', '可释放', '文件数')
        Write-Host ('-' * 100)
        foreach ($r in $preview) { if ($r.Size -gt 0) { Write-Host ('{0,-26} {1,14} {2,10}  {3}' -f $r.Label, (Format-Size $r.Size), $r.Files, $r.Path) } }
        Write-Host ('-' * 100)
        Write-Host ('合计可释放: {0}' -f (Format-Size $totalSize))
        Write-Host ''
        Write-Host '⚠️ 这是预览，没有删除任何文件。确认无误后加 -Execute 参数执行真正清理。'
        Write-Host ''
    }
    exit 0
}

# 真正执行
Write-Host ''
Write-Host '⚠️ 即将真正删除上述文件，此操作不可撤销（仅限安全垃圾白名单）。'
$freed = 0
foreach ($s in $JunkSpecs) {
    if (-not (Test-Path -LiteralPath $s.Path)) { continue }
    try {
        if ($s.Category -eq 'RecycleBin') {
            Clear-RecycleBin -DriveLetter C -Force -ErrorAction SilentlyContinue
            Write-Host ('已清空回收站: {0}' -f $s.Label)
            continue
        }
        Get-ChildItem -LiteralPath $s.Path -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                if ($_.PSIsContainer) {
                    # 长路径用 cmd rmdir 更稳
                    cmd /c ("rmdir /s /q `"{0}`"" -f $_.FullName) 2>$null
                } else {
                    Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
        Write-Host ('已清理: {0}  ({1})' -f $s.Label, $s.Path)
    } catch {
        Write-Host ('清理失败(已跳过): {0} - {1}' -f $s.Label, $_.Exception.Message)
    }
}
Write-Host ''
Write-Host ('预计释放空间: {0}' -f (Format-Size $totalSize))
Write-Host '清理完成。建议重启一次以确保被锁文件在下次释放。'
Write-Host ''
