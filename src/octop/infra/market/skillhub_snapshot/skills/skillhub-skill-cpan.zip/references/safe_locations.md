# C 盘清理 · 安全位置清单

本技能只处理“可安全删除的垃圾”，绝不动用户数据。以下为白名单与黑名单。

## ✅ 安全垃圾白名单（可清理）

| 类别 | 路径 | 说明 |
|------|------|------|
| SystemTemp | `C:\Windows\Temp` | Windows 系统临时文件 |
| UserTemp | `$env:TEMP`、`$env:LOCALAPPDATA\Temp` | 当前用户临时文件 |
| WinUpdate | `C:\Windows\SoftwareDistribution\Download` | Windows 更新下载缓存（删除不影响已装更新） |
| Prefetch | `C:\Windows\Prefetch` | 预读取缓存，系统会自动重建 |
| ThumbCache | `$env:LOCALAPPDATA\Microsoft\Windows\Explorer` | 缩略图缓存（thumbcache_*.db） |
| WER | `C:\ProgramData\Microsoft\Windows\WER` | Windows 错误报告dump |
| INetCache | `$env:LOCALAPPDATA\Microsoft\Windows\INetCache` | IE/Edge 临时网络文件 |
| RecycleBin | `C:\$Recycle.Bin\<当前用户SID>` | 仅当前用户回收站 |
| BrowserCache | Chrome/Edge 的 `User Data\Default\Cache` 与 `Code Cache` | 浏览器缓存，登录态不丢 |

## ⛔ 受保护黑名单（绝不触碰，扫描/清理均跳过）

- 桌面 `Desktop`
- 文档 `Documents`
- 下载 `Downloads`
- 图片 `Pictures`、视频 `Videos`、音乐 `Music`
- 用户个人文件根目录 `C:\Users\<用户名>` 下的非白名单目录
- 任何 AppData 子目录（如微信/QQ数据、WPS文档缓存）——仅作“迁移建议”展示，不删除

## 设计原则

1. **先扫描，后清理**：`scan.ps1` 只读，给出报告；`clean.ps1` 默认仅预览。
2. **显式确认**：`clean.ps1` 必须加 `-Execute` 才真删；删除前再次提示不可撤销。
3. **只删白名单**：任何目标路径若落入受保护目录，脚本立即中止（exit 3）。
4. **锁文件容错**：被占用的文件静默跳过，不报错中断。
5. **大目录仅建议**：AppData 下的大目录（如微信、Chrome 用户数据）只列出，提示“迁移到 D 盘”，不自动删——迁移请用 robocopy + mklink 方案。
