#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阶段 2-1：新增 scripts/data_resolver.py——数据文件四级搜索公共模块。"""
import os, sys

SCRIPT_NAME = "data_resolver"
SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_ERR_MSG = ("数据文件未找到：%s——已按四级搜索（主包 assets/data → 主包 law-pack/assets/data → "
            "$CDIW_LAW_PACK_DIR → 主包父目录/cdiw-law-pack），全级未命中。"
            "请确认法条数据包挂载状态或恢复主包数据文件。")


def resolve_data(relpath):
    """按四级顺序解析数据文件绝对路径，首个命中即用（V2.5.1 数据归位重构）。

    ① <主包>/assets/data/<relpath>            未迁移文件＋向后兼容
    ② <主包>/law-pack/assets/data/<relpath>   V2.5.1 起默认形态（法条包内嵌）
    ③ $CDIW_LAW_PACK_DIR/assets/data/<relpath>
    ④ <主包父目录>/cdiw-law-pack/assets/data/<relpath>
    未命中返回 (None, None)；调用方以结构化错误处理，禁止裸抛。
    """
    cands = []
    cands.append(("main:<主包>/assets/data", os.path.join(SKILL_ROOT, "assets", "data", relpath)))
    cands.append(("embedded:<主包>/law-pack/assets/data", os.path.join(
        SKILL_ROOT, "law-pack", "assets", "data", relpath)))
    env = os.environ.get("CDIW_LAW_PACK_DIR")
    if env:
        cands.append(("env:CDIW_LAW_PACK_DIR", os.path.join(env, "assets", "data", relpath)))
    cands.append(("sibling:cdiw-law-pack", os.path.join(
        os.path.dirname(SKILL_ROOT), "cdiw-law-pack", "assets", "data", relpath)))
    for level, path in cands:
        if os.path.isfile(path):
            return path, level
    return None, None


def load_json_data(relpath):
    """resolve_data＋JSON 解析；失败时打印结构化信封并退出码 2（与主包脚本错误约定一致）。"""
    path, level = resolve_data(relpath)
    if path is None:
        print(json_envelope("error", "ERR_DATA_NOT_FOUND", _ERR_MSG % relpath, {"relpath": relpath}))
        sys.exit(2)
    try:
        import json
        return json.load(open(path, encoding="utf-8")), path, level
    except (OSError, ValueError) as exc:
        print(json_envelope("error", "ERR_IO", "数据文件读取失败:%s（%s）" % (path, exc), None))
        sys.exit(2)


def json_envelope(status, code, message, data):
    import json
    return json.dumps({"status": status, "error_code": code, "message": message, "data": data},
                      ensure_ascii=False, indent=2)


if __name__ == "__main__":
    rel = sys.argv[1] if len(sys.argv) > 1 else ""
    if not rel:
        print(json_envelope("error", "MISSING_PARAM", "用法：python3 data_resolver.py <相对路径，如 crime_index.json>", None))
        sys.exit(1)
    path, level = resolve_data(rel)
    if path:
        print(json_envelope("ok", None, "命中", {"relpath": rel, "level": level, "path": path}))
        sys.exit(0)
    print(json_envelope("error", "ERR_DATA_NOT_FOUND", _ERR_MSG % rel, {"relpath": rel}))
    sys.exit(2)
