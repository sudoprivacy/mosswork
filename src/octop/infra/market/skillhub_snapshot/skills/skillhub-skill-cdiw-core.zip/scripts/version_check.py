#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""版本一致性机检（version_check.py）。

职责：五处版本一致＋双包兼容区间＋registry 时点一致性机检。
调用方：self_check.py（交付验收与发布闸门）；亦可独立运行。

五处同步点（2.3.0 起生效"包版本与大纲版本联动纪律"，见设计大纲 9.4 a2-1）：
  ①CHANGELOG.md 最新条目版本  ②SKILL.md frontmatter metadata.version
  ③SKILL.md 正文版本表述      ④SBOM.json skill_version  ⑤_meta.json version
任一不一致 → verdict FAIL，即升版失败，须当轮补齐。

兼容区间机检：
  - 主包 SBOM compatible_law_pack 区间须含法条包当前版本（cdiw-law-pack/PACK.md compatible_core 反向亦核）；
  - registry_summary._updated_at 与 law-pack registry.json _updated_at 一致（数据同步纪律）。

输出 JSON 信封：{status, error_code, message, data}；退出码 0 通过 / 1 参数错误 / 4 版本不一致。
统一错误约定与主包其他脚本一致，禁止裸抛异常。
"""

import json
import os
import re
import sys

SCRIPT_NAME = "version_check"
SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def resolve_law_pack_root():
    """法条包根四级解析（与 law_text_lookup 四级口径一致）：内嵌→同级→env 提示。"""
    emb = os.path.join(SKILL_ROOT, "law-pack")
    if os.path.isfile(os.path.join(emb, "assets", "data", "law_texts", "registry.json")):
        return emb
    sib = os.path.join(os.path.dirname(SKILL_ROOT.rstrip("/")), "cdiw-law-pack")
    if os.path.isfile(os.path.join(sib, "assets", "data", "law_texts", "registry.json")):
        return sib
    env = os.environ.get("CDIW_LAW_PACK_DIR")
    return env or sib


LAW_PACK_ROOT = resolve_law_pack_root()

FIVE_POINTS = ["CHANGELOG.md", "SKILL.md(frontmatter)", "SKILL.md(body)",
               "SBOM.json", "_meta.json"]


def envelope(status, code, message, data):
    return {"status": status, "error_code": code, "message": message, "data": data}


def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def check():
    versions = {}
    problems = []

    # ① CHANGELOG 最新条目
    try:
        cl = read(os.path.join(SKILL_ROOT, "CHANGELOG.md"))
        m = re.search(r"^## \[([\d.]+)\]", cl, re.M)
        versions[FIVE_POINTS[0]] = m.group(1) if m else None
        if not m:
            problems.append("CHANGELOG 无版本条目")
    except OSError as e:
        problems.append("CHANGELOG 读取失败:%s" % e)
        versions[FIVE_POINTS[0]] = None

    # ② frontmatter
    try:
        sk = read(os.path.join(SKILL_ROOT, "SKILL.md"))
        m = re.search(r"version:\s*\"?([\d.]+)\"?", sk.split("---")[1] if sk.startswith("---") else sk)
        versions[FIVE_POINTS[1]] = m.group(1) if m else None
        if not m:
            problems.append("SKILL.md frontmatter 无 version")
    except (OSError, IndexError) as e:
        problems.append("SKILL.md 读取失败:%s" % e)
        versions[FIVE_POINTS[1]] = None

    # ③ 正文版本表述（Overview 段 V 形式）
    m = re.search(r"V([\d]+\.[\d]+\.[\d]+)\s*覆盖", sk)
    versions[FIVE_POINTS[2]] = m.group(1) if m else None
    if not m:
        problems.append("SKILL.md 正文无'Vx.y.z 覆盖'表述")

    # ④ SBOM
    try:
        sb = json.loads(read(os.path.join(SKILL_ROOT, "SBOM.json")))
        versions[FIVE_POINTS[3]] = sb.get("skill_version")
        if not versions[FIVE_POINTS[3]]:
            problems.append("SBOM 无 skill_version")
    except (OSError, ValueError) as e:
        problems.append("SBOM 读取失败:%s" % e)
        versions[FIVE_POINTS[3]] = None

    # ⑤ _meta.json
    try:
        mt = json.loads(read(os.path.join(SKILL_ROOT, "_meta.json")))
        versions[FIVE_POINTS[4]] = mt.get("version")
        if not versions[FIVE_POINTS[4]]:
            problems.append("_meta 无 version")
    except (OSError, ValueError) as e:
        problems.append("_meta 读取失败:%s" % e)
        versions[FIVE_POINTS[4]] = None

    vals = {v for v in versions.values() if v}
    if len(vals) > 1:
        problems.append("五处版本不一致:%s" % versions)
    elif len(vals) == 1 and None in versions.values():
        missing = [k for k, v in versions.items() if v is None]
        problems.append("缺版本点:%s" % missing)

    unified = next(iter(vals)) if len(vals) == 1 else None

    # 兼容区间：SBOM compatible_law_pack ↔ law-pack 版本
    compat = None
    lawpack_ver = None
    try:
        compat = sb.get("data_layer", [{}])
        for it in compat:
            if isinstance(it, dict) and "compatible_law_pack" in it:
                compat = it["compatible_law_pack"]
                break
    except Exception:
        pass
    try:
        pack_md = read(os.path.join(LAW_PACK_ROOT, "PACK.md"))
        m = re.search(r"\*\*版本\*\*：([\d.]+)", pack_md)
        lawpack_ver = m.group(1) if m else None
    except OSError:
        lawpack_ver = None

    # registry 时点一致性
    ts_reg = ts_sum = None
    try:
        r1 = json.loads(read(os.path.join(LAW_PACK_ROOT, "assets", "data", "law_texts", "registry.json")))
        ts_reg = r1.get("_updated_at")
    except (OSError, ValueError):
        pass
    try:
        r2 = json.loads(read(os.path.join(SKILL_ROOT, "assets", "data", "registry_summary.json")))
        ts_sum = r2.get("_updated_at")
    except (OSError, ValueError):
        pass
    ts_ok = (ts_reg is not None and ts_reg == ts_sum)
    if not ts_ok:
        problems.append("registry 时点不一致:law-pack=%s summary=%s" % (ts_reg, ts_sum))

    ok = (not problems) and unified is not None
    data = {"five_points": versions, "unified_version": unified,
            "law_pack_version": lawpack_ver, "compatible_range": str(compat),
            "registry_ts": {"law_pack": ts_reg, "summary": ts_sum, "consistent": ts_ok},
            "problems": problems}
    return ok, data


def main():
    ok, data = check()
    env = envelope("ok" if ok else "error", None if ok else "ERR_VERSION_MISMATCH",
                   "五处版本一致＋双包校验通过" if ok else "版本机检未通过（升版失败，须当轮补齐）",
                   data)
    print(json.dumps(env, ensure_ascii=False, indent=2))
    sys.exit(0 if ok else 4)


if __name__ == "__main__":
    main()
