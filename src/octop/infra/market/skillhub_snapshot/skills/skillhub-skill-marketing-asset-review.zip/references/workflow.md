# Marketing asset review

The checklist is free, and it is shown before any file is read. Judge claim clarity, whether the product is recognizable, whether the words can be read, and whether the crop matches the destination.

Upload each local file first. One `beatra.images.understand` per still after `image_to_text`. One `beatra.videos.understand` per clip after `video_to_text`. The note quotes what those calls returned. It does not invent ad-account results, store sales, or a legal clearance.

A category read, only when asked, is one execute of `social.douyin.video.search` or `social.xiaohongshu.note.search`. Say it is public posts, not the account's own results.

The repair is a later card. `beatra.images.edit` takes the still as `images[0]` and changes only the line the note named. `beatra.videos.edit` takes the clip and changes only the instruction the note named. Do not generate a fresh file from text.

## Worked note

A square main image of a kettle whose claim that it does not leak when laid on its side is cut off by the crop. The note says the claim is unreadable and the product is recognizable. One edit moves that exact claim into the clear band and leaves the kettle.
