---
name: skillhub-skill-marketing-asset-review
description: "把已经做好的海报、主图或短片做成营销素材审核：逐条写出哪里不能发、哪里要改。营销素材审核先给出检查单，再看你交来的文件，并可以重做一张替换静帧或一条替换短片。这里的营销素材指海报、封面和主图。适合发布前的这一遍。"
---

# 营销素材审核

## 你会拿到

- 一份检查单，写明要判什么，在读任何文件之前。
- 对你确认的文件的逐条意见：哪里不该发，以及要改什么。
- 一张修好的静帧或一条修好的短片，从你交来的那份文件改出来，只改你点名的那一件。

## 怎么跑

- 检查单，然后意见。默认。读文件是第一步付费。
- 修一件。只在意见存在之后，并且只修你点名的那一件。修理从那份文件开始。
- 带一次品类读取。你想拿意见和这个品类正在展示的样子对照时，查一次抖音或小红书上的公开帖子。这不是你的广告账户。

发布之前，海报、封面、主图或短片已经存在，你要意见，并且点名的话还要一份修好的文件，就从这里开始。

## 范围和相邻路线

这条路线用来判断已经存在的海报、封面、主图和短片。从空白想法做第一张海报走视觉创作。一套商品上架图走商品素材。

## 输入和默认

硬性输入是这份文件，或者没有文件时对这件物料的一段白话说明。缺了只问这个。判断卖点是否清楚、商品是否认得出来、图上的字是否读得清、裁切是否符合它要发的地方。不要编造广告账户结果、店铺销量或法律结论。`model` 保持 `auto`。

## 黄金路径

1. 写出检查单并展示。这段文字不收费。
2. 这次包含品类读取时，一张查询卡和一次 `beatra.social.execute`。允许的键是 `social.douyin.video.search` 和 `social.xiaohongshu.note.search`。复制 `schema_hash`，它来自 `beatra.social.tools.get`。
3. 已确认的静帧，用 `beatra.assets.upload` 上传每个本地文件，调用 `beatra.models.list`，载荷 `{"capability": "image_to_text"}`，出示理解卡，并提交一次 `beatra.images.understand`。
4. 已确认的短片，上传它，调用 `beatra.models.list`，载荷 `{"capability": "video_to_text"}`，另出一张卡，并提交一次 `beatra.videos.understand`。
5. 根据这些调用返回的内容写意见。这段文字不收费。
6. 修一张静帧时，调用 `beatra.models.list`，载荷 `{"capability": "image_edit"}`，在这份文件上提交一次 `beatra.images.edit`。修一条短片时，调用 `beatra.models.list`，载荷 `{"capability": "video_edit"}`，在这份文件上提交一次 `beatra.videos.edit`。不要用从文字重新生成的新文件替换它们。
7. 用 `beatra.tasks.get` 轮询，交付意见、修好的文件和 `billing.net_charged_credits`。

## 需要确认的决定

规划和写出来的文字不收费，也不算批准。

每次付费调用之前，出示当前的制作卡并等待：

1. 做什么：用用户的话说出将要做出的东西，并说明这次是生成还是查询。
2. 积分：刚刚从模型卡或 `beatra.social.tools.get` 读到的现价。不要沿用记得的数字。
3. 次数：每个槽位一次付费调用。理解一份文件是一张卡。修理它是后面的一张卡。每个槽位有自己的 `client_request_id`。查询的下一页是另一次调用。
4. 标识：每次调用一个新的不透明 `client_request_id`。提示词、文件、模型或控制项一变，就换一个新标识。
5. 停在这里：已经写出的文字仍然可用。
6. 余额不足：原样转达官方消息和其中的充值地址。用户说已经充值之前不要重试。

查询和生成是两张卡。意见不批准修理。所有远程 Beatra 工具只通过随包 `scripts/mcp_client.py` 调用。工具名是命令参数，JSON 参数走标准输入。不要配置、调用或使用宿主 Beatra Connector。不要使用 REST/OpenAPI 降级。

创建响应丢失时，只用逐字节相同的载荷和同一个 `client_request_id` 重试。任务标识丢失时，先调用 `beatra.tasks.list`，再调用 `beatra.tasks.get`，对照冻结的请求之后才做相同重试。只有用户要求取消时才调用 `beatra.tasks.cancel`，然后用 `beatra.tasks.get` 确认该任务。

用户问还剩多少积分时，调用 `beatra.wallet.get`。用户问扣了什么时，调用 `beatra.wallet.ledger`。

## 按任务阅读

检查单和一份写成的意见，读场景工作流（references/workflow.md）。
任务卡住、响应丢失、价格看起来不对，或修理离开了原文件，读出错时怎么处理（references/faq.md）。
连接还没就绪时，读安装与认证（references/installation-and-auth.md）。
首次注册，读安装注册（references/installation-registration.md）。
调用在任务出现之前失败时，读随包 MCP Client 连接诊断（references/mcp-connection.md）。
任务在排队、运行或找不到时，读任务与结果（references/tasks-and-results.md）。
扣费、退款或丢失的响应需要共用规则时，读计费、错误与恢复（references/billing-errors-and-recovery.md）。
用户要停止并移除连接时，读卸载与断开（references/uninstall-and-disconnect.md）。

## 更新与安全

本 Skill 会自动更新。内置客户端每天最多一次从 Beatra 官网读取本渠道的版本信息
（中国大陆网络走 www.beatra.cn 与 cdn.beatra.cn）。有新版本时，它下载官方发布包，
逐个文件校验 SHA-256，再替换本 Skill 自己的文件；你放进这个目录的其他文件不会被
改动。替换过程中断时，下次运行会自动恢复到替换前的状态。除此之外，它不下载或执行
任何其他代码，只通过 HTTPS 与 Beatra 官方服务通信；你选择上传的文件只会传到
Beatra 为这次上传签发的一次性地址。

关闭自动更新：`python3 scripts/mcp_client.py update --auto off`。关闭后，客户端每天
最多提示一次在你安装它的商店里更新的命令。详见更新与安全（references/updates-and-security.md）。
