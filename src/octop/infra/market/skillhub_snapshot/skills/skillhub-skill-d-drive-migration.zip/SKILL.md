---
name: skillhub-skill-d-drive-migration
description: "用 robocopy + junction 把写死在 C 盘用户目录下的程序数据目录（WorkBuddy、Chrome/Edge 用户数据、开发工具缓存与配置等）整体迁移到 D 盘，程序零感知、配置零修改。适用于 C 盘空间告急、需要 relocate 数据目录但程序无官方路径配置项的场景。"
---

# D 盘迁移：robocopy + junction 四步法

## 触发场景
- 用户说"C 盘红了""磁盘空间不够""把 XX 数据挪到 D 盘""迁移 .workbuddy / 浏览器数据 / 开发工具缓存"。
- 目标程序**没有官方路径配置项**，启动时硬读某个固定目录（如 `%USERPROFILE%\.workbuddy`）。
- 需要先确认目标目录**不是 reparse point**（已是联接/符号链接就不能再套），用 `fsutil reparsepoint query "<路径>"` 或 `dir /aL` 确认。

## 核心思路：四步走，把停机时间压到最短
不要直接退出程序再复制（海量小文件要跑几十分钟）。正确顺序：

```
① 在线预复制   → 程序还在跑，先把 99% 数据搬过去（活跃日志这类"追不平"的文件不用等）
② 退出程序     → 唯一停机点，tasklist 确认进程退干净
③ 离线增量收尾 → 同一命令再跑一遍，只补变化的少量文件，几十秒
④ 改名 + 建联接 → 原目录改名留备份，原位置建 junction 指到 D 盘，秒级完成
```

**为什么用 junction（目录联接）而不是符号链接/快捷方式：**
| 方案 | 适用 | 权限 | 结论 |
|---|---|---|---|
| 快捷方式 .lnk | 文件/目录 | 无 | ✗ 程序不认，Explorer 专用 |
| 符号链接 mklink /D | 文件/目录 | 需管理员/开发者模式 | △ 能用但门槛高 |
| **目录联接 mklink /J** | **仅目录** | **普通用户** | **✓ 最佳** |

junction 让 `C:\Users\xxx\.workbuddy` 物理上仍是那个路径、实际指向 D 盘，程序读写全程无感知。

## 完整命令（在 Git Bash 执行）
> 关键：robocopy **必须在 Bash 里跑**。PowerShell 受限环境会静默失败（空退出码、目标 0 文件、不报错）。路径要写 Windows 风格并加 `MSYS_NO_PATHCONV=1`，否则 `/c/Users` 会被拼成 `d:\c\Users` 报"系统找不到指定的路径"。

**步骤 1 · 在线预复制（/MT:32 提速约 4 倍）**
```bash
MSYS_NO_PATHCONV=1 robocopy \
  "C:\Users\Administrator\.workbuddy" \
  "D:\workbuddyfiles\.workbuddy" \
  /E /COPYALL /R:2 /W:2 /MT:32 /NFL /NDL
```
- `/E` 含空子目录；`/COPYALL` 复制数据+属性+时间戳+NTFS ACL+所有者+审计；`/R:2 /W:2` 失败重试 2 次间隔 2 秒；`/MT:32` 32 线程并行（海量小文件提速关键）；`/NFL /NDL` 不输出文件/目录列表，减日志 IO。
- 实测：`.workbuddy\workspace\sessions` 8.7 万个几百字节小文件，单线程 21 分钟没跑完 → /MT:32 五分钟完成 200MB，约 4 倍。瓶颈是文件创建与元数据开销，不是带宽。

**步骤 2 · 完全退出程序**
```bash
tasklist | grep -iE "WorkBuddy|sandbox|editor_sdk"
```
确认 `WorkBuddy.exe`(多实例)、`sandbox-center.exe`、`sandbox-cli.exe`、`editor_sdk.exe` 全部退干净。

**步骤 3 · 离线增量收尾**（同步骤 1 命令再跑一遍，几十秒）

**步骤 4 · 改名 + 建 junction**
```bash
mv "C:/Users/Administrator/.workbuddy" "C:/Users/Administrator/.workbuddy.pre-migration.bak"
cmd //c mklink /J "C:\Users\Administrator\.workbuddy" "D:\workbuddyfiles\.workbuddy"
```
> `mklink` 是 cmd 内部命令，Git Bash 里用 `cmd //c`（双斜杠是 MSYS 转义）；PowerShell 里用 `cmd /c`。

## 六个踩坑点
1. **批处理脚本写全英文提示**：离线 .bat 若用中文，Windows 控制台代码页会乱码，报错没法看。
2. **Git Bash 里 robocopy 两边路径写 Windows 风格 + `MSYS_NO_PATHCONV=1`**：否则路径被错误转换。
3. **PowerShell 跑 robocopy 会静默失败**：跨盘复制目录一律放 Bash。
4. **验证 junction 看目标盘有没有新文件，别看进程路径**：任务管理器永远显示 C 盘原路径，不代表失败；正确验证是看 D 盘目标目录有无新写入（日志、修改时间变化）。
5. **备份目录先别删**：程序完全正常（跑任务、重启几次）后再删 `C:/Users/Administrator/.workbuddy.pre-migration.bak`。
6. **准备好回滚脚本**：删 junction（不带 -r）+ 备份改回原名，秒级回滚：
   ```bash
   rm "C:/Users/Administrator/.workbuddy"
   mv "C:/Users/Administrator/.workbuddy.pre-migration.bak" "C:/Users/Administrator/.workbuddy"
   ```

## 可复用范围
任何"运行中程序的数据目录迁移"都套用四步法：在线预复制 → 退出程序 → 离线增量 → 改名+junction。同理可迁 Chrome/Edge 用户数据、各类开发工具缓存与配置、任何写死在 C 盘用户目录下的数据。
