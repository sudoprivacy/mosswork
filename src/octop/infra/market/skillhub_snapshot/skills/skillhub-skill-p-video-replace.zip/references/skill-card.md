## Description: <br>
Use when someone wants to swap a person, outfit, or product inside existing footage while keeping the camera move and audio. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[pruna-ai](https://clawhub.ai/user/pruna-ai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and creative production teams use this skill to prepare Pruna P-API video replacement jobs that swap characters, clothing, objects, or products in existing footage while preserving motion, timing, camera movement, scene structure, and audio. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: Source videos and reference images are uploaded to Pruna for processing. <br>
Mitigation: Use only media you are permitted to send to a third-party API, and avoid sensitive or private footage unless the user has approved that processing. <br>
Risk: Identity replacement can be used for impersonation, misleading edits, public-figure misuse, or sensitive personal content. <br>
Mitigation: Require explicit permission for identifiable people and decline uses that are deceptive, non-consensual, or otherwise violate the provider's policy. <br>
Risk: PRUNA_API_KEY is required for paid API calls. <br>
Mitigation: Keep the key in environment variables, never commit or print it, and stop before making requests when the key is missing. <br>
Risk: Safety-checker bypasses may increase policy and misuse risk. <br>
Mitigation: Leave safety checks enabled unless the user understands and accepts the provider policy and risk. <br>


## Reference(s): <br>
- [Pruna p-video-replace model docs](https://docs.api.pruna.ai/guides/models/p-video-replace) <br>
- [Pruna P-API shared reference](references/pruna-api.md) <br>
- [API credentials](references/api-credentials.md) <br>
- [p-video-replace quality checklist](references/p-video-replace-quality-checklist.md) <br>
- [Generation diversity](references/generation-diversity.md) <br>
- [Product and wardrobe variations](https://runware.ai/docs/models/prunaai-p-video-replace/guides/product-and-wardrobe-variations) <br>
- [Recasting scenes](https://runware.ai/docs/models/prunaai-p-video-replace/guides/recasting-iconic-film-scenes) <br>


## Skill Output: <br>
**Output Type(s):** [Guidance, Markdown, Shell commands, Configuration, API calls] <br>
**Output Format:** [Markdown guidance with prompts, checklists, JSON request examples, and curl commands] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May produce Pruna prediction requests, uploaded media references, polling commands, and output review guidance.] <br>

## Skill Version(s): <br>
1.0.6 (source: server release metadata and skill metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
