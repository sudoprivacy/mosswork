#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
word_counter.py — 统计目录内 .txt 文件的词频，输出 CSV 报告（单文件产物）。

用法：
    python scripts/word_counter.py --input INPUT_DIR
    python scripts/word_counter.py --input INPUT_DIR --out output --top 10

确定性任务：输入相同则输出相同。单文件产物 report.csv，
提交采用“临时文件自检 + os.replace 原子替换”，manifest 最后写入。
"""

import argparse
import hashlib
import json
import sys
from pathlib import Path

SCRIPT_VERSION = "1.1.0"
MANIFEST_NAME = ".manifest.json"
INCOMPLETE_MARKER = ".INCOMPLETE"

E_MISSING_INPUT = "E_MISSING_INPUT"
E_BAD_INPUT = "E_BAD_INPUT"
E_ENV = "E_ENV"
E_IO = "E_IO"
E_VERIFY = "E_VERIFY"


def progress(msg):
    print(f"[进度] {msg}", flush=True)


def fail_out(code, msg):
    print(f"错误代码: {code}", flush=True)
    print(f"RESULT: FAIL: {msg}", flush=True)
    return 1


def pass_out(msg):
    print(f"RESULT: PASS: {msg}", flush=True)
    return 0


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def input_signature(input_path: Path) -> str:
    h = hashlib.sha256()
    if input_path.is_dir():
        files = sorted(p for p in input_path.rglob("*") if p.is_file())
        for p in files:
            rel = p.relative_to(input_path).as_posix()
            h.update(rel.encode("utf-8"))
            h.update(b"\0")
            h.update(p.read_bytes())
            h.update(b"\0")
    else:
        h.update(input_path.read_bytes())
    return h.hexdigest()


def environment_precheck():
    if sys.version_info < (3, 8):
        return f"需要 Python 3.8+，当前为 {sys.version.split()[0]}"
    return None


def compute_outputs(input_path: Path, top: int):
    """主算法：str.split 分词。返回 (csv_text, 输入文件数)。"""
    files = sorted(input_path.rglob("*.txt")) if input_path.is_dir() else [input_path]
    if not files:
        raise ValueError("输入中没有 .txt 文件")
    counts = {}
    for p in files:
        for word in p.read_text(encoding="utf-8").split():
            counts[word] = counts.get(word, 0) + 1
    rows = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:top]
    lines = ["word,count"] + [f"{w},{c}" for w, c in rows]
    return "\n".join(lines) + "\n", len(files)


def run(input_arg: str, out_arg: str, top: int, overwrite: bool) -> int:
    progress("[1/5] 环境预检")
    missing = environment_precheck()
    if missing:
        return fail_out(E_ENV, f"环境不满足，交付状态为阻塞: {missing}")

    input_path = Path(input_arg)
    if not input_path.exists():
        return fail_out(E_MISSING_INPUT, f"输入路径不存在: {input_path}")

    out_dir = Path(out_arg)
    manifest_path = out_dir / MANIFEST_NAME
    report_path = out_dir / "report.csv"

    if (out_dir / INCOMPLETE_MARKER).exists():
        progress("检测到上次提交未完成标记，整体重新计算")
        overwrite = True

    progress("[2/5] 计算输入与实现签名")
    try:
        sig = input_signature(input_path)
    except OSError as exc:
        return fail_out(E_BAD_INPUT, f"无法读取输入: {exc}")
    impl_sig = sha256_bytes(Path(__file__).read_bytes())

    if not overwrite and manifest_path.exists():
        try:
            old = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            old = {}
        if (old.get("input_signature") == sig
                and old.get("params") == {"input": str(input_path), "out": out_arg, "top": top}
                and old.get("implementation_signature") == impl_sig
                and report_path.is_file()):
            return pass_out(f"输入、参数、实现签名均一致，跳过计算，产物位于: {out_dir.as_posix()}")
        progress("已有产物与本次输入/参数/实现不一致，重新计算（契约内授权更新生成物）")

    progress("[3/5] 执行词频统计")
    try:
        csv_text, n_files = compute_outputs(input_path, top)
    except ValueError as exc:
        return fail_out(E_BAD_INPUT, str(exc))
    except OSError as exc:
        return fail_out(E_IO, f"读取输入失败: {exc}")

    progress("[4/5] 暂存自检并原子提交单文件产物")
    out_dir.mkdir(parents=True, exist_ok=True)
    marker = out_dir / INCOMPLETE_MARKER
    marker.write_text('{"pending": ["report.csv"]}', encoding="utf-8")
    tmp = out_dir / "report.csv.tmp"
    backup = out_dir / "report.csv.bak"
    try:
        tmp.write_text(csv_text, encoding="utf-8", newline="\n")
        # 暂存自检：非空、表头正确
        staged = tmp.read_text(encoding="utf-8").splitlines()
        if not staged or staged[0] != "word,count":
            return fail_out(E_VERIFY, "临时产物自检未通过：表头不是 word,count")
        if report_path.exists():
            report_path.replace(backup)
        tmp.replace(report_path)
        record = {
            "script_version": SCRIPT_VERSION,
            "implementation_signature": impl_sig,
            "input_signature": sig,
            "params": {"input": str(input_path), "out": out_arg, "top": top},
            "outputs": ["report.csv"],
        }
        manifest_tmp = out_dir / ".manifest.json.tmp"
        manifest_tmp.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n")
        manifest_tmp.replace(manifest_path)
        marker.unlink()
        if backup.exists():
            backup.unlink()
    except OSError as exc:
        if backup.exists() and not report_path.exists():
            try:
                backup.replace(report_path)
                marker.unlink()
                return fail_out(E_IO, f"提交失败，已回滚: {exc}")
            except OSError:
                pass
        return fail_out(
            E_IO, f"提交失败，回滚不完整: {exc}；.INCOMPLETE 已保留，重新运行将整体重算")

    progress("[5/5] 提交完成；任务成功仍以 verify_output.py 对同一次输入的验证为准")
    return pass_out(f"已统计 {n_files} 个文件，产物位于: {out_dir.as_posix()}")


def main():
    parser = argparse.ArgumentParser(
        prog="word_counter.py",
        description="统计目录内 .txt 文件的词频，输出 CSV 报告")
    parser.add_argument("--input", default="input", help="输入目录，默认: input")
    parser.add_argument("--out", default="output", help="输出目录，默认: output")
    parser.add_argument("--top", type=int, default=10, help="保留前 N 个高频词，默认: 10")
    parser.add_argument("--overwrite", action="store_true",
                        help="强制忽略仍然有效的缓存重新计算")
    args = parser.parse_args()
    sys.exit(run(args.input, args.out, args.top, args.overwrite))


if __name__ == "__main__":
    sys.exit(main())
