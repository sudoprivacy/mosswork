#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# invoke.py — Shell 字符串宿主下的参数透传封装（可信基建脚本，随子技能原样复制）
"""
invoke.py — 不拼 Shell 引号的命令调用封装

适用场景：
    宿主的执行工具只接受一条 Shell 字符串命令，无法直接传 argv 数组。
    此时不允许模型手工给路径加引号（空格、引号、Shell 元字符、Unicode
    都可能拼错），改为：
      1. 把真正要执行的命令 argv 数组写进一个 JSON 文件（UTF-8）；
      2. 运行：python scripts/invoke.py <spec.json>
    本脚本用 subprocess 的 argv 数组方式执行（shell=False），
    参数不经过 Shell 解释。

spec.json 格式：
    {
      "argv": ["python", "scripts/word_counter.py",
               "--input", "C:/my dir/a b.txt",
               "--out", "output"],
      "cwd": "."            // 可选，工作目录
    }

任意用户文本仍应通过输入文件传递，不要放进 argv；本封装解决的是
路径等参数的透传问题。

终态协议：
    被调命令退出码 0 且最后一个非空行为 RESULT: PASS → 本脚本同样退出 0；
    否则退出码非 0，最后一个非空行为 RESULT: FAIL，并回传被调命令的
    真实退出码与最后一行，供调用方按故障表处理。
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path


def fail(msg, code=1):
    print(f"RESULT: FAIL: {msg}", flush=True)
    return code


def main():
    parser = argparse.ArgumentParser(
        prog="invoke.py",
        description="读取 JSON 中的 argv 数组，以 shell=False 方式执行，避免手工拼引号")
    parser.add_argument("spec", help="JSON 规格文件路径，内含 argv 数组与可选 cwd")
    args = parser.parse_args()

    spec_path = Path(args.spec)
    if not spec_path.is_file():
        return fail(f"规格文件不存在: {spec_path}")
    try:
        spec = json.loads(spec_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        return fail(f"规格文件无法解析: {exc}")

    argv = spec.get("argv")
    if not isinstance(argv, list) or not argv or not all(isinstance(a, str) for a in argv):
        return fail("规格文件中的 argv 必须是非空字符串数组")
    cwd = spec.get("cwd", ".")

    try:
        proc = subprocess.run(
            argv, cwd=cwd, shell=False,
            capture_output=True, text=True, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return fail(f"命令不存在（环境阻塞）: {argv[0]}")
    except OSError as exc:
        return fail(f"无法启动命令: {exc}")

    # 原样转发被调命令的全部输出，再做终态行核对
    if proc.stdout:
        sys.stdout.write(proc.stdout)
        if not proc.stdout.endswith("\n"):
            sys.stdout.write("\n")
    if proc.stderr:
        sys.stderr.write(proc.stderr)

    last_lines = [ln for ln in (proc.stdout or "").splitlines() if ln.strip()]
    last = last_lines[-1] if last_lines else ""

    if proc.returncode == 0 and last.startswith("RESULT: PASS"):
        print(f"[进度] invoke.py：退出码与终态行一致（{last[:60]}）")
        print("RESULT: PASS: 被调命令协议成功")
        return 0
    if proc.returncode != 0 and last.startswith("RESULT: FAIL"):
        print(f"RESULT: FAIL: 被调命令失败（退出码 {proc.returncode}），按其错误代码行处理")
        return proc.returncode if proc.returncode > 0 else 1
    # 退出码与终态行不一致或缺失：协议异常
    print(f"RESULT: FAIL: 输出协议异常（退出码 {proc.returncode}，最后非空行不是约定终态），停止")
    return 1


if __name__ == "__main__":
    sys.exit(main())
