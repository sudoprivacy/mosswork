#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# validate_skill.py 规范版本戳: VALIDATOR_SPEC_VERSION = "1.9.0"
"""
validate_skill.py — Skill 质量自动验证器（开发期结构检查，弱模型友好）

用法：
    python scripts/validate_skill.py                 # 项目模式：验证当前目录
    python scripts/validate_skill.py <技能目录>      # 项目模式：验证指定目录
    python scripts/validate_skill.py --review-mode <技能目录>
    # 评审模式：只做平台兼容性检查，不把“未采用本项目 Python 骨架”判为违规
    python scripts/validate_skill.py -h              # 查看帮助
    python scripts/validate_skill.py --version       # 查看验证器规则版本
    python scripts/validate_skill.py --self-hash     # 本文件 SHA256（可信副本自检）
    python scripts/validate_skill.py --hash-file <文件>  # 只读计算任意文件 SHA256，不执行该文件

职责边界（三类检查不要混用）：
    1. 开发期结构检查（本脚本）：SKILL.md 是否规范、脚本语法是否成立；
    2. 运行期环境预检：由主脚本在任何业务副作用之前自行完成；
    3. 运行期产物验证：由各技能的 scripts/verify_output.py 完成。
本脚本不检查依赖是否安装、外部命令是否可用、输出目录是否可写。
评审外来目录时本脚本只读其文件：语法检查使用 ast.parse 读源码，
不生成 __pycache__/.pyc，不向被评审目录写入任何内容。

终态输出协议（validate / 主脚本 / verify_output 三者一致）：
    进度行以 [进度] 开头，不得含终态标志；
    成功：退出码 0，最后一个非空行为 RESULT: PASS；
    失败：退出码 1，最后一个非空行为 RESULT: FAIL；
    其他任何组合都是输出协议异常，调用方必须停止，不得继续后续步骤。

检查等级：
    FAIL = 可机械判定的硬性违规，必须修复；
    WARN = 启发式提示，可能误报，不证明行为正确或错误，
           行为正确性以功能测试矩阵的真实运行为准；
    INFO = 评审模式下被跳过的本项目约定，不计结论。

退出码：无 FAIL 为 0，有 FAIL 为 1。WARN/INFO 不改变退出码。
"""

import argparse
import ast
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

VALIDATOR_SPEC_VERSION = "1.9.0"  # 改动检查规则时升版本；副本用 SHA256 比对防漂移

# 可信基建脚本：随母本/模板原样复制，不接受技能自身的参数计数等约束
INFRASTRUCTURE_SCRIPTS = {"validate_skill.py", "verify_output.py", "invoke.py",
                          "safe_copy.py"}

SCRIPT_SUFFIXES = (".py", ".js", ".sh")
BODY_LINE_LIMIT = 300    # 正文非空行上限：本项目弱模型可靠性约定，超过为 FAIL（项目模式）
DESC_CHAR_LIMIT = 1024   # description 字符上限（平台规范），超过为 FAIL
PARAM_COUNT_LIMIT = 5    # 主入口脚本参数提示阈值：AST 启发式，超过为 WARN

# ---- 占位符语法（唯一定义，SKILL.md 规范表与本实现必须一致）----
# 创建期占位符 A：中文尖括号，如 <技能名称>；交付前必须全部消失。
CREATION_PLACEHOLDER_CN = r"<[一-龥][^>\n]{0,39}>"
# 创建期占位符 B：小写 kebab/snake 形态且必须含 - 或 _，如 <skill-name>、<skill_name>。
# 纯小写单词（<input>、<div>）不在此列，避免误伤 HTML 标签与泛型。
CREATION_PLACEHOLDER_ASCII = r"<[a-z][a-z0-9]*[-_][a-z0-9\-_]*>"
# 运行期参数：全大写蛇形，如 <INPUT_PATH>；允许保留，但必须在参数映射表登记。
RUNTIME_PARAM = r"<[A-Z][A-Z0-9_]{1,39}>"
# 内置目录变量：由目录契约统一登记，豁免参数映射检查。
# <SKILL_NAME> 为创建流程变量（A1 确定的目录名），同源登记。
BUILTIN_TOKENS = {
    "<TARGET_ROOT>", "<CREATOR_ROOT>", "<WORK_ROOT>", "<SKILL_NAME>",
    "<SANDBOX_ROOT>", "<DELIVERY_ROOT>",
    "<TARGET_FILE>"}
# 叙述区可疑标记（仅 WARN）
NARRATIVE_MARKERS = [r"【[^】\n]{1,20}】", r"\bTODO\b", r"\bFIXME\b", r"\bXXX\b"]

# name 平台完整定义：非空、小写字母数字、连字符不得在首尾、不得连续，≤64 字符
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
# 本项目额外保留词（非平台规则）：避免暗示官方归属
# 完全等于保留词：skill 单独成名没有区分度
RESERVED_EXACT = {"skill", "anthropic", "claude", "openai", "chatgpt"}
# 官方归属问题检查 description 与 frontmatter 声明，不按 name 产品名一刀切
# （openai-api-client、claude-config-review 等合理名称不误伤）
OFFICIAL_BRANDS = {"anthropic", "claude", "openai", "chatgpt"}


class Checker:
    def __init__(self):
        self.results = []

    def ok(self, msg):
        self.results.append(("PASS", msg))

    def fail(self, msg):
        self.results.append(("FAIL", msg))

    def warn(self, msg):
        self.results.append(("WARN", msg))

    def info(self, msg):
        self.results.append(("INFO", msg))

    def summary(self):
        n_pass = sum(1 for s, _ in self.results if s == "PASS")
        n_warn = sum(1 for s, _ in self.results if s == "WARN")
        n_fail = sum(1 for s, _ in self.results if s == "FAIL")
        print("\n===== 验证结果汇总 =====")
        for status, msg in self.results:
            print(f"[{status}] {msg}")
        print(f"\nPASS={n_pass}  WARN={n_warn}  FAIL={n_fail}")
        if n_fail:
            print("修复全部 FAIL 后重新运行本脚本；WARN 为启发式提示，请逐条人工过目。")
            print("RESULT: FAIL")
        else:
            print("RESULT: PASS")
        return 0 if n_fail == 0 else 1


def strip_html_comments(text):
    """移除 HTML 注释，注释中的文件引用不作为检查依据。"""
    return re.sub(r"<!--.*?-->", "", text, flags=re.DOTALL)


def parse_frontmatter(text):
    """解析 frontmatter，返回 (name, description, version_info, body)。"""
    version_info = {"present": False, "has_key": False, "is_string": False, "value": ""}
    fm_re = re.match(r"^---\s*\n(.*?)\n---\s*\n?", text, re.DOTALL)
    if not fm_re:
        return None, "", version_info, text
    fm = fm_re.group(1)
    body = text[fm_re.end():]

    name = None
    m = re.search(r"^name:\s*(.+?)\s*$", fm, re.MULTILINE)
    if m:
        name = m.group(1).strip().strip("\"'")

    description = ""
    lines = fm.splitlines()
    for i, line in enumerate(lines):
        if not line.startswith("description:"):
            continue
        rest = line.split(":", 1)[1].strip()
        rest = re.sub(r"^[>|][+-]?\s*", "", rest)
        buf = [rest] if rest else []
        for follow in lines[i + 1:]:
            if re.match(r"^\S", follow):
                break
            buf.append(follow.strip())
        description = " ".join(p for p in buf if p)
        break

    meta_m = re.search(r"(?ms)^metadata:\s*\n((?:[ \t]+.*(?:\n|$))*)", fm)
    if meta_m:
        version_info["present"] = True
        block = meta_m.group(1)
        vm = re.search(r"(?m)^\s+version:\s*(.*?)\s*$", block)
        if vm:
            version_info["has_key"] = True
            raw_val = vm.group(1).strip()
            quoted = re.fullmatch(r"[\"']([0-9][0-9A-Za-z.\-]*)[\"']", raw_val)
            if quoted:
                version_info["is_string"] = True
                version_info["value"] = quoted.group(1)
            else:
                version_info["value"] = raw_val

    return name, description, version_info, body


def find_backslash_paths(text):
    """查找 Windows 风格反斜杠路径（启发式 WARN），限定字符集避免正则误报。"""
    hits = re.findall(
        r"[A-Za-z]:\\(?![sSwWdDbBnrtvf0'\"\\/])"
        r"[A-Za-z0-9_.\-]+(?:\\[A-Za-z0-9_.\-]+)+",
        text)
    hits += re.findall(
        r"(?<![\w.\\/])[A-Za-z0-9_\-]+\\[A-Za-z0-9_\-][A-Za-z0-9_.\\\-]*\.[A-Za-z0-9]{1,8}",
        text)
    return sorted(set(h.rstrip("\\") for h in hits))


def find_narrative_markers(prose):
    """叙述区的【】、TODO 等可疑标记，WARN。"""
    hits = []
    for pat in NARRATIVE_MARKERS:
        hits.extend(re.findall(pat, prose))
    return sorted(set(hits))[:5]


def check_creator_markers(raw_text, checker):
    """MODULE 标记与“说明：”创建者注释必须在交付前消失，FAIL。

    检查未剥离注释的原文：这两类内容是创建过程资产，不允许随技能交付，
    即使它们以 HTML 注释形态存在。
    """
    module_hits = re.findall(r"<!--\s*MODULE:[^>]*-->", raw_text)
    if module_hits:
        checker.fail(
            "残留 MODULE 模块边界标记（不需要的模块应整块删除，含两行标记）: "
            + ", ".join(module_hits[:5]))
    note_hits = re.findall(r"<!--[^>]*说明[：:][^>]*-->", raw_text, re.DOTALL)
    if note_hits:
        checker.fail(
            "创建者说明未删除（“说明：”内容只服务创建过程，交付前必须清除），共 "
            + f"{len(note_hits)} 处")
    leaked_notes = [
        ln.strip() for ln in strip_html_comments(raw_text).splitlines()
        if re.match(r"^\s*说明[：:]", ln)]
    if leaked_notes:
        checker.fail(
            "创建者说明写成了正文（应只存在于注释并在交付前删除）: "
            + "; ".join(leaked_notes[:3]))


def check_indirect_reference(body, checker):
    """启发式 WARN：只写“以某文件为准”而无明确加载动作，运行者无法执行。

    命中“以……为准”且同一句中没有“读取/查看/打开”等加载动词时提示。
    可能误报（文件路径含“为准”等），故只 WARN。
    """
    for ln in body.splitlines():
        if re.search(
                r"以\s*[《\"']?[^。；\n]{0,40}"
                r"(?:references/|[\w.\-]+\.md|模板|契约文件)"
                r"[^。；\n]{0,30}为准", ln) \
                and not re.search(r"先?读取|先?查看|先?打开|加载", ln):
            checker.warn(
                "发现间接引用但未写明加载动作（应改为“先读取某文件，再做什么”）: "
                + ln.strip()[:60])
            return


def check_semantic_rubric(body, checker):
    """语义判断型技能必须内联评分量表并规定复核（启发式 WARN）。

    判定信号（启发式，可能误报，故只 WARN）：
    正文声明为语义判断型，或命中写作/审阅/摘要等语义任务关键词，
    但未出现量表（评分/量表/合格线）或未规定复核。
    """
    declared = "语义" in body
    accept_rubric = re.search(r"验收方式[：:][^\n]*量表", body)
    keyword_hit = re.search(
        r"写作|审阅|评审|研究|设计|撰写|总结|摘要|提炼|润色", body)
    if not (declared or accept_rubric or keyword_hit):
        return  # 非语义型，本检查静默不输出
    has_hard = "硬性条件" in body
    has_rubric = ("量表" in body or "评分" in body) and "合格线" in body
    has_review = "复核级别" in body or "复核" in body
    if has_hard and has_rubric and has_review:
        checker.ok("语义步骤已具备硬性条件、内联量表与复核级别")
    else:
        missing = []
        if not has_hard:
            missing.append("硬性条件（不可抵消项）")
        if not has_rubric:
            missing.append("内联评分量表（含合格线）")
        if not has_review:
            missing.append("复核级别约定")
        checker.warn(
            "疑似含语义步骤但缺少：" + "、".join(missing) +
            "；机械检查通过不代表内容合格")


def check_skill_type(body, checker):
    """本项目创建的技能应按两个维度声明分类（启发式 WARN）。"""
    has_exec = "执行方式" in body and re.search(
        r"纯文本指导|工具调用|脚本|混合", body)
    has_accept = "验收方式" in body and re.search(
        r"机械检查|清单核对|量表评分|外部复核", body)
    if has_exec and has_accept:
        checker.ok("已按执行方式与验收方式两个维度声明分类")
    else:
        missing = []
        if not has_exec:
            missing.append("执行方式")
        if not has_accept:
            missing.append("验收方式")
        checker.warn("未完整声明分类两个维度，缺少：" + "、".join(missing))


def check_placeholders(body, checker, project_mode):
    """两类变量分别检查（语法定义见模块顶部常量，SKILL.md 规范表同源）。

    创建期占位符（中文尖括号 / 小写 kebab-snake 尖括号）：交付前必须消失。
    运行期参数（全大写尖括号）：允许出现在命令代码块中，但必须登记。
    纯小写单词尖括号（HTML、泛型）不在检查范围。
    """
    code_blocks = re.findall(r"```[A-Za-z0-9]*\n(.*?)```", body, re.DOTALL)
    code_text = "\n".join(code_blocks)
    prose = re.sub(r"```.*?```", "", body, flags=re.DOTALL)
    prose = re.sub(r"`[^`\n]+`", "", prose)

    def creation_hits(t):
        return sorted(set(re.findall(CREATION_PLACEHOLDER_CN, t)
                          + re.findall(CREATION_PLACEHOLDER_ASCII, t)))

    if project_mode:
        creation_in_prose = creation_hits(prose)
        if creation_in_prose:
            checker.fail(
                "正文叙述区残留创建期占位符（交付前必须全部替换）: "
                + ", ".join(creation_in_prose[:5]))
        else:
            checker.ok("正文叙述区无创建期占位符残留")

        creation_in_code = creation_hits(code_text)
        if creation_in_code:
            checker.fail(
                "命令代码块中残留创建期占位符（运行期参数须改用大写形态并在参数映射表登记）: "
                + ", ".join(creation_in_code[:5]))

        mapping_section = ""
        tm = re.search(
            r"^\|[^\n]*参数[^\n]*\|\s*\n\|[ :\-|]+\|\s*\n"
            r"(?:\|[^\n]*\|\s*\n)*",
            body, re.MULTILINE)
        if tm:
            mapping_section = tm.group(0)
            required_cols = ["参数", "来源", "类型", "必填", "默认值", "传递方式"]
            missing_cols = [c for c in required_cols if c not in mapping_section]
            if missing_cols:
                checker.warn(
                    "参数映射表缺少列（应为六列：参数/来源/类型/必填/默认值/传递方式）: "
                    + ", ".join(missing_cols))
        else:
            sm = re.search(
                r"^#{2,4}\s*参数映射[^\n]*\n(.*?)(?=\n#{2,4}\s|\Z)",
                body, re.MULTILINE | re.DOTALL)
            if sm:
                mapping_section = sm.group(1)

        unregistered = []
        for block in code_blocks:
            for tok in sorted(set(re.findall(RUNTIME_PARAM, block))):
                if tok in BUILTIN_TOKENS:
                    continue
                if tok not in mapping_section:
                    unregistered.append(tok)
        if unregistered:
            checker.fail(
                "命令中的运行期参数未在“参数映射”章节登记来源/类型/默认值/传递方式: "
                + ", ".join(sorted(set(unregistered))[:5]))
        else:
            checker.ok("命令中的运行期参数均已在参数映射表登记（或不存在）")

        markers = find_narrative_markers(prose)
        if markers:
            checker.warn(f"叙述区存在待定标记: {', '.join(markers)}")
    else:
        checker.info("评审模式：跳过创建期占位符与参数映射表等本项目约定检查")


def check_magic_numbers(code, source_label, checker):
    """启发式：赋值三位及以上数字且行内无注释，疑似魔法常量。WARN。"""
    for line in code.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            continue
        if re.search(r"=\s*\d{3,}\b", stripped) and "#" not in stripped:
            checker.warn(f"{source_label} 疑似魔法数字无注释: {stripped[:80]}")
            return


def check_script_params(path: Path, checker):
    """用 AST 启发式检查主入口脚本的 argparse 参数数量/位置参数/默认值。

    全部结论只给 WARN：AST 统计在封装、循环、子解析器等写法下可能误报，
    参数数量是否真正合格以真实运行测试为准，本检查不阻断交付。
    """
    source = path.read_text(encoding="utf-8-sig", errors="replace")
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return

    bool_actions = {"store_true", "store_false", "store_const", "count", "version", "help"}
    calls = [n for n in ast.walk(tree)
             if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Attribute)
             and n.func.attr == "add_argument"]

    total = len(calls)
    for node in calls:
        flags = [a.value for a in node.args
                 if isinstance(a, ast.Constant) and isinstance(a.value, str)]
        kwargs = {kw.arg: kw.value for kw in node.keywords if kw.arg}

        positional = [f for f in flags if not f.startswith("-")]
        nargs = kwargs.get("nargs")
        nargs_val = nargs.value if isinstance(nargs, ast.Constant) else None
        for pos in positional:
            if nargs_val not in ("?", "*"):
                checker.warn(
                    f"{path.name} 含必填位置参数 '{pos}'；建议改为带默认值的 --flag 参数")

        optional = [f for f in flags if f.startswith("-")]
        action = kwargs.get("action")
        action_val = action.value if isinstance(action, ast.Constant) else None
        if optional and "default" not in kwargs and action_val not in bool_actions:
            required = kwargs.get("required")
            if not (isinstance(required, ast.Constant) and required.value is True):
                checker.warn(
                    f"{path.name} 参数 {optional[0]} 未显式给出 default（启发式："
                    "argparse 隐式默认值为 None，不代表默认值可用）")

    if total > PARAM_COUNT_LIMIT:
        checker.warn(
            f"{path.name} AST 识别到 {total} 个 add_argument（> {PARAM_COUNT_LIMIT}）；"
            "启发式可能误报（封装/子解析器），请人工确认弱模型能否拼对命令")


def check_result_protocol(path: Path, checker):
    """启发式：脚本源码应同时包含 RESULT: PASS / RESULT: FAIL 两个终态分支。

    这只是文本提示，不证明运行时真的遵守协议；协议以功能测试矩阵的
    真实运行（退出码 + 最后一个非空行）为准。
    """
    source = path.read_text(encoding="utf-8-sig", errors="replace")
    if "RESULT: PASS" not in source:
        checker.warn(f"{path.name} 源码未出现 RESULT: PASS 终态（启发式，需运行测试确认）")
    if "RESULT: FAIL" not in source:
        checker.warn(f"{path.name} 源码未出现 RESULT: FAIL 终态（启发式，需运行测试确认）")


def check(skill_dir: Path, checker: Checker, project_mode: bool = True):
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        checker.fail("SKILL.md 不存在")
        return
    raw_text = skill_md.read_text(encoding="utf-8-sig", errors="replace")
    text = strip_html_comments(raw_text)
    checker.ok("SKILL.md 存在")

    mode_label = "项目模式（本项目全类型技能规范）" if project_mode \
        else "评审模式（仅平台兼容性检查，本项目约定不判违规）"
    print(f"[进度] 检查模式: {mode_label}")

    # ---------- A. 平台兼容性检查（两种模式都执行） ----------
    name, desc, ver, body = parse_frontmatter(raw_text)
    if not text.lstrip().startswith("---"):
        checker.fail("缺少 YAML frontmatter（文件必须以 --- 开头并包含 name/description）")
    else:
        checker.ok("YAML frontmatter 存在")

    if name:
        if "<" in name or ">" in name:
            checker.fail(f"name 仍是模板占位符: {name}；必须替换为真实技能名")
        elif not NAME_RE.fullmatch(name) or len(name) > 64:
            checker.fail(
                f"name 非法: {name}（平台要求：1-64 字符，小写字母/数字/连字符，"
                "连字符不得在首尾或连续出现）")
        elif project_mode and name in RESERVED_EXACT:
            checker.fail(
                f"name 完全等于本项目保留词: {name}；避免无区分度或暗示官方归属"
                "（本项目额外限制，非平台规则）")
        else:
            checker.ok(f"name 合法: {name}")
        if project_mode and (skill_dir.resolve().name != name):
            checker.warn(
                f"目录名 '{skill_dir.name}' 与 name '{name}' 不一致（本项目约定，建议同名）")
    else:
        checker.fail("frontmatter 缺少 name 字段")

    # 官方归属问题检查 description 与 frontmatter 声明（不按 name 产品名一刀切，
    # openai-api-client、claude-config-review 等合理名称不误伤）
    if project_mode and desc and any(brand in desc.lower() for brand in OFFICIAL_BRANDS):
        if re.search(r"官方|official|由\s*Anthropic|by\s*Anthropic", desc, re.IGNORECASE):
            checker.warn("description 存在官方归属暗示；请改为独立声明的第三方技能")
        else:
            checker.ok("description 含产品词但无官方归属暗示")

    if desc:
        if desc.startswith("<") or "<一句" in desc:
            checker.fail("description 仍是模板占位符；必须替换为真实描述")
        elif len(desc) > DESC_CHAR_LIMIT:
            checker.fail(f"description 过长（{len(desc)} 字符，上限 {DESC_CHAR_LIMIT}）")
        else:
            checker.ok("description 存在且长度合规")
        if project_mode:
            triggers = ["when", "use", "if", "用户", "触发", "不要用于", "不用于", "不触发"]
            if any(t in desc.lower() for t in triggers):
                checker.ok("description 包含触发场景或负面排除线索")
            else:
                checker.warn("description 缺少触发场景词（use/when/用户/不用于），可能影响触发率")
    elif text.lstrip().startswith("---"):
        checker.fail("frontmatter 缺少 description 字段")

    if ver["is_string"]:
        checker.ok(f"版本号已声明: {ver['value']}")
    elif project_mode:
        if ver["present"] and not ver["has_key"]:
            checker.warn("frontmatter 已含 metadata 块但缺少 version 键；建议补 metadata: version")
        elif ver["present"] and ver["has_key"]:
            checker.warn(
                f"metadata.version 不是字符串（当前写法: {ver['value']}）；"
                '请加引号，如 version: "0.1.0"，避免被 YAML 解析为数字')
        else:
            checker.warn("frontmatter 未声明 metadata.version（建议字段，缺失不阻断）")

    code_blocks = re.findall(r"```[A-Za-z0-9]*\n(.*?)```", body, re.DOTALL)

    # ---------- B. 本项目约定（仅项目模式） ----------
    if project_mode:
        nonempty_body = [ln for ln in body.splitlines() if ln.strip()]
        if len(nonempty_body) > BODY_LINE_LIMIT:
            checker.fail(
                f"正文非空行 {len(nonempty_body)} > {BODY_LINE_LIMIT}"
                "（frontmatter 与空行不计）。300 行是工程预算而非硬门槛："
                "优先模块化下沉细节；确属必要定义无法移走时，在交付报告中申请例外并说明理由")
        else:
            checker.ok(f"正文非空行 {len(nonempty_body)}（≤{BODY_LINE_LIMIT}，frontmatter/空行不计）")

        check_placeholders(body, checker, project_mode=True)
        check_creator_markers(raw_text, checker)
        check_indirect_reference(body, checker)
        check_skill_type(body, checker)
        check_semantic_rubric(body, checker)

        backslash_in_doc = find_backslash_paths(prose=body) if False else find_backslash_paths(body)
        if backslash_in_doc:
            checker.warn("文档中发现反斜杠路径，请改用正斜杠: "
                         + ", ".join(backslash_in_doc[:3]))
        else:
            checker.ok("SKILL.md 未发现反斜杠硬编码路径")

        magic_in_doc = False
        for block in code_blocks:
            for line in block.splitlines():
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                if re.search(r"\b\d{3,}\b", stripped) and "#" not in stripped:
                    checker.warn(f"文档代码块疑似魔法数字无注释: {stripped[:80]}")
                    magic_in_doc = True
                    break
            if magic_in_doc:
                break
        if not magic_in_doc:
            checker.ok("文档代码块中未发现明显魔法数字")
    else:
        check_placeholders(body, checker, project_mode=False)
        checker.info("评审模式：跳过正文行数、占位符、魔法数字等本项目约定检查")

    # ---------- C. 脚本可运行性 ----------
    scripts_dir = skill_dir / "scripts"
    script_files = []
    if scripts_dir.exists():
        script_files = sorted(
            p for p in scripts_dir.iterdir()
            if p.is_file() and p.suffix.lower() in SCRIPT_SUFFIXES)
    elif project_mode:
        checker.ok("无 scripts/ 目录（指导型/语义型等纯文档技能合法形态）")

    PY_CALL = re.compile(
        r"python(?:3)?(?:\.exe)?\s+(?:[<\w.\-]+/)*scripts/([A-Za-z0-9_.\-]+\.py)")
    command_text = "\n".join(code_blocks)
    commanded = set(PY_CALL.findall(command_text))
    entry_names = commanded - INFRASTRUCTURE_SCRIPTS
    py_scripts = []
    for sf in script_files:
        rel = sf.name
        if sf.suffix == ".py":
            # 只读语法检查：ast.parse 读源码，不生成 __pycache__/.pyc，不写目标目录
            source = sf.read_text(encoding="utf-8-sig", errors="replace")
            try:
                ast.parse(source, filename=str(sf))
                checker.ok(f"语法检查通过（ast.parse 只读，不写缓存）: {rel}")
                py_scripts.append(sf)
            except SyntaxError as exc:
                checker.fail(f"Python 语法错误: {rel}: 行 {exc.lineno}: {exc.msg}")
        elif sf.suffix == ".js":
            try:
                proc = subprocess.run(
                    ["node", "--check", str(sf)],
                    capture_output=True, text=True, timeout=30)
                code, err = proc.returncode, proc.stderr
            except FileNotFoundError:
                code, err = -1, "node 不可用"
            if code == 0:
                checker.ok(f"node --check 通过: {rel}")
            elif code == -1:
                checker.warn(f"JS 语法检查未执行（{err}）: {rel}；不判语法不合格")
            else:
                checker.fail(f"JS 语法错误: {rel}: {err[:200]}")
        else:
            checker.warn(f"无法自动检查语法: {rel}（非 .py/.js），请人工确认")

    if not entry_names and py_scripts:
        entry_names = {p.name for p in py_scripts if p.name not in INFRASTRUCTURE_SCRIPTS}

    if project_mode:
        for sf in py_scripts:
            if sf.name in INFRASTRUCTURE_SCRIPTS:
                continue  # 可信基建脚本豁免参数计数、终态文本、魔法数字等项目启发式
            if sf.name in entry_names:
                check_script_params(sf, checker)
            check_result_protocol(sf, checker)
            check_magic_numbers(
                sf.read_text(encoding="utf-8-sig", errors="replace"), sf.name, checker)

        if script_files:
            backslash_in_scripts = set()
            for sf in script_files:
                backslash_in_scripts.update(
                    find_backslash_paths(sf.read_text(encoding="utf-8-sig", errors="replace")))
            if backslash_in_scripts:
                sample = ", ".join(sorted(backslash_in_scripts)[:3])
                checker.warn(f"脚本中发现反斜杠路径，请改用正斜杠: {sample}")
    else:
        checker.info("评审模式：跳过参数计数、终态文本、魔法数字等本项目启发式检查")

    # 引用文件存在性：两种模式都检查（引用缺失在任何平台都是实际问题）
    missing_scripts = [m for m in sorted(commanded)
                       if not (scripts_dir / m).exists()]
    if missing_scripts:
        checker.fail(f"SKILL.md 命令引用了不存在的脚本: {', '.join(missing_scripts)}")
    else:
        checker.ok("SKILL.md 命令引用的脚本均存在")

    mentioned_refs = set(re.findall(r"(?<![\w./-])references/([A-Za-z0-9_.\-/]+)", text))
    missing_refs = [r for r in sorted(mentioned_refs)
                    if not (skill_dir / "references" / r).exists()]
    if missing_refs:
        checker.fail(f"SKILL.md 引用了不存在的 references 文件: {', '.join(missing_refs)}")
    else:
        checker.ok("SKILL.md 引用的 references 文件均存在")


def main():
    parser = argparse.ArgumentParser(
        prog="validate_skill.py",
        description="Skill 结构质量验证器：检查 SKILL.md 规范与脚本可运行性（开发期）。")
    parser.add_argument(
        "skill_dir", nargs="?", default=".",
        help="待验证的技能目录（含 SKILL.md）；默认为当前目录")
    parser.add_argument(
        "--review-mode", action="store_true",
        help="评审模式：仅平台兼容性检查；本项目 Python 骨架相关约定只提示不判违规")
    parser.add_argument(
        "--version", action="version",
        version=f"validate_skill.py spec {VALIDATOR_SPEC_VERSION}")
    parser.add_argument(
        "--self-hash", action="store_true",
        help="输出本验证器文件的 SHA256，用于可信副本自检")
    parser.add_argument(
        "--hash-file", metavar="FILE", default=None,
        help="只读计算任意文件的 SHA256（不执行该文件）；用于在不运行不可信脚本的"
             "前提下记录其哈希")
    args = parser.parse_args()

    if args.self_hash:
        own = Path(__file__).read_bytes()
        print(f"validate_skill.py spec {VALIDATOR_SPEC_VERSION}")
        print(f"sha256:{hashlib.sha256(own).hexdigest()}")
        sys.exit(0)

    if args.hash_file is not None:
        p = Path(args.hash_file)
        if not p.is_file():
            print(f"ERROR: 文件不存在: {p}")
            sys.exit(1)
        print(f"file: {p.as_posix()}")
        print(f"sha256:{hashlib.sha256(p.read_bytes()).hexdigest()}")
        sys.exit(0)

    skill_dir = Path(args.skill_dir).resolve()
    if not skill_dir.is_dir():
        print(f"ERROR: 目录不存在: {skill_dir}")
        sys.exit(1)
    print(f"验证器版本: {VALIDATOR_SPEC_VERSION}")
    print(f"验证目录: {skill_dir}")
    checker = Checker()
    check(skill_dir, checker, project_mode=not args.review_mode)
    sys.exit(checker.summary())


if __name__ == "__main__":
    main()
