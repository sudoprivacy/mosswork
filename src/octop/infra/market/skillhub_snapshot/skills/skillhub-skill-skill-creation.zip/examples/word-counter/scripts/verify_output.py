#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_output.py — word-counter 本次产物验证器（运行期）。

独立基准：主脚本用 str.split() 分词；本验证器用正则 [A-Za-z0-9']+
重新统计（不同实现），并对最小样例使用任务契约中的手工基准。
验证必须绑定本次实际 --input/--top/--out，不信任 manifest 自报信息。
"""

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

MANIFEST_NAME = ".manifest.json"
INCOMPLETE_MARKER = ".INCOMPLETE"
INFRASTRUCTURE_SCRIPTS = {"validate_skill.py", "verify_output.py", "invoke.py"}


def detail_bad(msg):
    print(f"[问题] {msg}")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def input_signature(input_path: Path) -> str:
    h = hashlib.sha256()
    if input_path.is_dir():
        for p in sorted(p for p in input_path.rglob("*") if p.is_file()):
            rel = p.relative_to(input_path).as_posix()
            h.update(rel.encode("utf-8"))
            h.update(b"\0")
            h.update(p.read_bytes())
            h.update(b"\0")
    else:
        h.update(input_path.read_bytes())
    return h.hexdigest()


def independent_expectation(input_path: Path, top: int) -> str:
    """用与主脚本不同的实现（正则分词）计算预期 CSV 文本。"""
    files = sorted(input_path.rglob("*.txt")) if input_path.is_dir() else [input_path]
    counts = {}
    for p in files:
        for word in re.findall(r"[A-Za-z0-9']+", p.read_text(encoding="utf-8")):
            counts[word] = counts.get(word, 0) + 1
    rows = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:top]
    return "\n".join(["word,count"] + [f"{w},{c}" for w, c in rows]) + "\n"


def run(input_arg: str, out_arg: str, top: int) -> int:
    failures = []
    input_path = Path(input_arg)
    out = Path(out_arg)
    scripts_dir = Path(__file__).resolve().parent

    if not input_path.exists():
        detail_bad(f"本次输入路径不存在: {input_path}")
        print("RESULT: FAIL: 本次输入缺失，拒绝依据旧产物判定成功")
        return 1
    if not out.exists():
        detail_bad(f"产物目录不存在: {out}")
        print("RESULT: FAIL: 产物目录不存在，本次任务未完成")
        return 1

    if (out / INCOMPLETE_MARKER).exists():
        failures.append("存在 .INCOMPLETE 标记：上次提交未完成，必须整体重算")
    leftovers = [p.name for p in out.rglob("*")
                 if p.is_file() and (p.name.endswith(".tmp") or p.name.endswith(".bak"))]
    if leftovers:
        failures.append("存在临时/备份残留: " + ", ".join(leftovers[:5]))

    manifest = None
    try:
        manifest = json.loads((out / MANIFEST_NAME).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        failures.append(f"manifest 缺失或不可解析: {exc}")

    actual_sig = input_signature(input_path)
    mains = [p for p in scripts_dir.glob("*.py") if p.name not in INFRASTRUCTURE_SCRIPTS]
    main_script = mains[0] if len(mains) == 1 else None
    actual_impl = sha256_bytes(main_script.read_bytes()) if main_script else None

    if manifest is not None:
        if manifest.get("input_signature") != actual_sig:
            failures.append("输入签名不一致：产物不是本次输入的结果")
        expected_params = {"input": str(input_path), "out": out_arg, "top": top}
        if manifest.get("params") != expected_params:
            failures.append(
                f"参数不一致：manifest={manifest.get('params')}，本次={expected_params}")
        if actual_impl is not None and manifest.get("implementation_signature") != actual_impl:
            failures.append("实现签名不一致：产物由不同版本主脚本生成")

    report = out / "report.csv"
    if not report.is_file():
        failures.append("业务产物 report.csv 缺失")
    elif report.stat().st_size == 0:
        failures.append("report.csv 为空文件")

    business = [p for p in out.rglob("*")
                if p.is_file() and p.name not in (MANIFEST_NAME, INCOMPLETE_MARKER)
                and not p.name.endswith((".tmp", ".bak"))]
    declared = set((manifest or {}).get("outputs", []))
    actual_rel = {p.relative_to(out).as_posix() for p in business}
    ghosts = actual_rel - declared
    missing = declared - actual_rel
    if ghosts:
        failures.append("清单外幽灵产物: " + ", ".join(sorted(ghosts)))
    if missing:
        failures.append("清单声明但缺失: " + ", ".join(sorted(missing)))

    # 独立内容断言（不同分词实现的逐字比对）
    if report.is_file() and manifest is not None and not ghosts and not missing:
        expected = independent_expectation(input_path, top)
        actual = report.read_text(encoding="utf-8")
        if actual != expected:
            failures.append(
                "report.csv 与独立基准（正则分词重算）逐字不一致；"
                "可能统计了错误输入或内容错误")

    if failures:
        for f in failures:
            detail_bad(f)
        print("RESULT: FAIL: 产物未通过本次输入绑定验证，本次任务不得宣布完成")
        return 1

    print(f"RESULT: PASS: 产物与本次输入/参数/实现绑定，且与独立基准逐字一致，"
          f"业务产物 {len(business)} 个")
    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="verify_output.py",
        description="验证 word-counter 本次输入对应的产物")
    parser.add_argument("--input", required=True, help="本次运行实际使用的输入路径")
    parser.add_argument("--out", default="output", help="本次运行实际使用的输出目录")
    parser.add_argument("--top", type=int, default=10, help="本次运行实际使用的 top 参数")
    args = parser.parse_args()
    sys.exit(run(args.input, args.out, args.top))


if __name__ == "__main__":
    sys.exit(main())
