#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
word-counter 功能测试矩阵（持久保留，可复跑）。

运行方式（在 examples/word-counter 目录）：
    python -m unittest tests.functional.test_functional -v

覆盖与契约条款的映射：
  T1  正常输入：产物与独立基准逐字一致，终态协议成立（契约·正确性判据）
  T2  边界：单文件输入（契约·输入）
  T3  非法输入：空目录 → E_BAD_INPUT，退出非 0，无新产物（契约·缺失输入）
  T4  格式正确但内容错误的产物被 verify 拒绝（verify 独立断言）
  T5a 产物来自错误输入 → verify 拒绝（绑定本次输入）
  T5b 产物对应错误参数（top 不同）→ verify 拒绝（绑定本次参数）
  T5c 产物与 manifest 一起被修改 → verify 拒绝（不信任 manifest 自报）
  T6  主脚本失败后遗留上次成功产物，本次不得宣布成功（任务完成定义）
  T7a 输入变化 → 自动重算（契约内授权，幂等失效）
  T7b 参数变化 → 自动重算
  T8  二次运行输入未变 → 跳过，结果一致（幂等）
  T9  提交中断 → .INCOMPLETE/manifest 不一致被 verify 拒绝；再跑恢复
  T10 含空格/引号/Shell 元字符/Unicode 的路径经 argv 数组透传成功
每个用例只在临时目录写产物，不污染技能目录。
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[2]
MAIN = SKILL_DIR / "scripts" / "word_counter.py"
VERIFY = SKILL_DIR / "scripts" / "verify_output.py"

EXPECTED_BASIC = "word,count\ncat,2\ndog,1\n"


def run(argv, cwd):
    proc = subprocess.run(
        argv, cwd=str(cwd), capture_output=True, text=True,
        encoding="utf-8", errors="replace")
    lines = [ln for ln in proc.stdout.splitlines() if ln.strip()]
    return proc.returncode, lines[-1] if lines else "", proc.stdout


class FunctionalMatrix(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="wc_ft_"))
        self.work = self.tmp / "work"
        self.work.mkdir()
        self.inputs = self.tmp / "inputs"
        self.inputs.mkdir()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def write_input(self, name, content, d=None):
        d = d or self.inputs
        p = d / name
        p.write_text(content, encoding="utf-8")
        return p

    def main_run(self, inp, *extra):
        return run([sys.executable, str(MAIN), "--input", str(inp),
                    "--out", "output", *extra], self.work)

    def verify_run(self, inp, *extra):
        return run([sys.executable, str(VERIFY), "--input", str(inp),
                    "--out", "output", *extra], self.work)

    def out_file(self):
        return self.work / "output" / "report.csv"

    def test_t1_normal_matches_independent_baseline(self):
        self.write_input("a.txt", "cat cat dog")
        code, last, _ = self.main_run(self.inputs)
        self.assertEqual(code, 0)
        self.assertEqual(last, "RESULT: PASS: 已统计 1 个文件，产物位于: output")
        self.assertEqual(self.out_file().read_text(encoding="utf-8"), EXPECTED_BASIC)
        code, last, _ = self.verify_run(self.inputs)
        self.assertEqual(code, 0, "verify 应与独立基准逐字一致")
        self.assertTrue(last.startswith("RESULT: PASS"))

    def test_t2_single_file_input(self):
        f = self.write_input("one.txt", "bee bee bee")
        code, last, _ = self.main_run(f)
        self.assertEqual((code, last.startswith("RESULT: PASS")), (0, True))
        self.assertEqual(self.out_file().read_text(encoding="utf-8"),
                         "word,count\nbee,3\n")
        code, _, _ = self.verify_run(f)
        self.assertEqual(code, 0)

    def test_t3_empty_dir_is_bad_input_no_output(self):
        code, last, out = self.main_run(self.inputs)
        self.assertNotEqual(code, 0)
        self.assertIn("E_BAD_INPUT", out)
        self.assertTrue(last.startswith("RESULT: FAIL"))
        self.assertFalse(self.out_file().exists(), "非法输入不得产生业务产物")

    def test_t4_wrong_content_rejected(self):
        self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        # 格式合法但内容错误
        self.out_file().write_text("word,count\ncat,99\ndog,1\n", encoding="utf-8")
        code, last, out = self.verify_run(self.inputs)
        self.assertNotEqual(code, 0)
        self.assertTrue(last.startswith("RESULT: FAIL"))
        self.assertIn("逐字不一致", out)

    def test_t5a_product_from_wrong_input_rejected(self):
        self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        other = self.tmp / "other"
        other.mkdir()
        (other / "b.txt").write_text("totally different words here", encoding="utf-8")
        code, _, out = self.verify_run(other)
        self.assertNotEqual(code, 0)
        self.assertIn("输入签名不一致", out)

    def test_t5b_product_with_wrong_params_rejected(self):
        self.write_input("a.txt", "cat cat dog bird fish")
        self.assertEqual(self.main_run(self.inputs, "--top", "2")[0], 0)
        code, _, out = self.verify_run(self.inputs, "--top", "3")
        self.assertNotEqual(code, 0)
        self.assertIn("参数不一致", out)

    def test_t5c_manifest_tampered_together_rejected(self):
        self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        # 同时改产物和 manifest 中的自报签名
        manifest = self.work / "output" / ".manifest.json"
        rec = json.loads(manifest.read_text(encoding="utf-8"))
        rec["input_signature"] = "0" * 64
        manifest.write_text(json.dumps(rec), encoding="utf-8")
        code, _, out = self.verify_run(self.inputs)
        self.assertNotEqual(code, 0)
        self.assertIn("输入签名不一致", out)

    def test_t6_stale_product_after_failure_not_success(self):
        self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        # 本次输入缺失，主脚本失败；旧产物仍在
        missing = self.tmp / "gone"
        code, _, out = self.main_run(missing)
        self.assertNotEqual(code, 0)
        self.assertIn("E_MISSING_INPUT", out)
        code, last, out = self.verify_run(missing)
        self.assertNotEqual(code, 0, "不得凭旧产物宣布本次成功")
        self.assertTrue(last.startswith("RESULT: FAIL"))

    def test_t7a_input_change_triggers_recompute(self):
        f = self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        f.write_text("cat cat cat", encoding="utf-8")
        code, _, out = self.main_run(self.inputs)
        self.assertEqual(code, 0)
        self.assertIn("重新计算", out)
        self.assertEqual(self.out_file().read_text(encoding="utf-8"),
                         "word,count\ncat,3\n")
        self.assertEqual(self.verify_run(self.inputs)[0], 0)

    def test_t7b_param_change_triggers_recompute(self):
        self.write_input("a.txt", "cat cat dog bird")
        self.assertEqual(self.main_run(self.inputs, "--top", "1")[0], 0)
        self.assertEqual(self.out_file().read_text(encoding="utf-8"),
                         "word,count\ncat,2\n")
        code, _, out = self.main_run(self.inputs, "--top", "2")
        self.assertEqual(code, 0)
        self.assertIn("重新计算", out)
        # cat=2；bird 与 dog 同频为 1，按字母升序 bird 在前
        self.assertEqual(self.out_file().read_text(encoding="utf-8"),
                         "word,count\ncat,2\nbird,1\n")

    def test_t8_second_run_skips_and_identical(self):
        self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        first = self.out_file().read_bytes()
        code, _, out = self.main_run(self.inputs)
        self.assertEqual(code, 0)
        self.assertIn("跳过计算", out)
        self.assertEqual(self.out_file().read_bytes(), first)

    def test_t9_interrupted_commit_detected_and_recovered(self):
        self.write_input("a.txt", "cat cat dog")
        self.assertEqual(self.main_run(self.inputs)[0], 0)
        # 注入中断状态：保留 INCOMPLETE 标记并删除产物，模拟替换中途失败
        outdir = self.work / "output"
        (outdir / ".INCOMPLETE").write_text('{"pending": ["report.csv"]}', encoding="utf-8")
        self.out_file().unlink()
        code, _, out = self.verify_run(self.inputs)
        self.assertNotEqual(code, 0, "中断状态必须可检测并被拒绝")
        self.assertIn("INCOMPLETE", out)
        # 再跑一次：检测标记 → 整体重算 → 恢复
        code, _, out = self.main_run(self.inputs)
        self.assertEqual(code, 0)
        self.assertIn("整体重新计算", out)
        self.assertEqual(self.out_file().read_text(encoding="utf-8"), EXPECTED_BASIC)
        self.assertFalse((outdir / ".INCOMPLETE").exists())
        self.assertEqual(self.verify_run(self.inputs)[0], 0)

    def test_t10_paths_with_spaces_quotes_metachars_unicode(self):
        weird = self.tmp / "dir with spaces" / "a'b&$;中😀"
        weird.mkdir(parents=True)
        (weird / "x.txt").write_text("cat cat dog", encoding="utf-8")
        # argv 数组透传：路径中的空格/引号/Shell 元字符/Unicode 不经过 Shell
        code, last, _ = self.main_run(weird)
        self.assertEqual(code, 0, last)
        self.assertTrue(last.startswith("RESULT: PASS"))
        self.assertEqual(self.out_file().read_text(encoding="utf-8"), EXPECTED_BASIC)
        self.assertEqual(self.verify_run(weird)[0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
