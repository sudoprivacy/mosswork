# skill-creation

通用**技能创建元技能**：指导智能体（包括能力较弱的模型）编写、改进或评审
**任意类型**的智能体技能——纯文本指导型、语义判断型、工具调用型、
脚本自动化型（Python 或其他运行时）及混合型。

核心特点：

- **两个维度分类**：执行方式与验收方式逐步骤标注，不用一把尺子套所有技能。
- **任务契约先行**：输入、输出、正确性判据、副作用、运行环境在实现前固化。
- **按需组合的验收机制**：机械检查、清单核对、量表评分、工具四项验收、
  独立复核、分层测试协议，通过固定插槽组合，不自由拼接章节。
- **人机决策门 G1/G2/G3**：需求歧义、多方案选择、未验证项交付均有明确规则。
- **唯一交付状态判定**：已验证 / 未验证草稿 / 阻塞 / 失败，顺序固定，
  验收不通过不得声称完成。

## 仓库结构

```text
SKILL.md                         元技能正文（技能入口）
templates/                       模板（通用骨架 + Python 参考实现 + 交付报告）
  skill_template.md              全类型 SKILL.md 通用模板
  python_template.md             Python 脚本模块参考实现
  main_script_template.py        主脚本骨架（预检、终态、可恢复提交）
  verify_output_template.py      产物验证器骨架
  delivery_report_template.md    技能包交付报告模板
references/                      契约与协议（自有表述）
  automation-contract.md         语言无关自动化契约
  layout-and-variables.md        目录变量、副本布局与文件产物提交规则
  validation-protocol.md         分层测试协议与弱模型测试指标
  human-gates.md                 人机交互决策门契约（G1/G2/G3）
  runtime-for-weak-agents.md     弱模型可运行性设计笔记
  practices-notes.md             外部经验提炼与出处
scripts/                         母技能基础设施工具
  validate_skill.py              结构质量验证器（规则版本见文件内常量）
  invoke.py                      Shell 字符串宿主的参数透传封装
  safe_copy.py                   安全复制工具
examples/
  word-counter/                  脚本型完整示例（含 13 个可复跑功能测试）
  text-summary/                  语义步骤型完整示例
tests/
  test_validator.py              验证器回归测试（不复制进子技能）
```

## 快速使用

将本目录作为技能安装到支持 Agent Skill 的宿主中（目录名建议改为
`skill-creation`），然后直接提出需求，例如：

- “帮我编写一个把会议纪要整理成行动项的技能”
- “评审一下这个技能仓库是否达到可发布状态”
- “改进这个已有技能，补上中断恢复能力”

元技能会引导完成契约固化、模板组合、实现、分层验收与交付报告。

## 自行验证（开发期）

```powershell
# 验证器回归测试
python -m unittest tests.test_validator

# 结构验证（母技能与示例）
python scripts/validate_skill.py .
python scripts/validate_skill.py examples/word-counter
python scripts/validate_skill.py examples/text-summary

# 示例功能矩阵
Push-Location examples/word-counter
python -m unittest tests.functional.test_functional
Pop-Location
```

## 版本

- 技能版本：**0.3.0**（见 `SKILL.md` frontmatter）
- 验证器规则版本：见 `scripts/validate_skill.py` 内
  `VALIDATOR_SPEC_VERSION` 常量

## 许可

见 [LICENSE](LICENSE)。
