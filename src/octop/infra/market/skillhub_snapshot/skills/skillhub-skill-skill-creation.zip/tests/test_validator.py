#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_skill.py 回归测试（母技能基建，不复制进子技能）。

运行方式（在 CREATOR_ROOT）：
    python -m unittest tests.test_validator -v
"""

import hashlib
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = ROOT / "scripts" / "validate_skill.py"

FRONTMATTER = (
    "---\n"
    "name: test-skill\n"
    "description: >-\n"
    "  A test skill. Use when 用户要求测试。不用于其他场景。\n"
    'metadata:\n  version: "0.1.0"\n'
    "---\n"
)

MAIN_SCRIPT = '''\
import argparse
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="input")
    p.add_argument("--out", default="output")
    a = p.parse_args()
    print("RESULT: PASS: ok")
if __name__ == "__main__":
    main()
'''

VERIFY_SCRIPT = '''\
import argparse
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    a = p.parse_args()
    print("RESULT: PASS: verified")
if __name__ == "__main__":
    main()
'''


class ValidatorCase(unittest.TestCase):
    def make_skill(self, skill_md, scripts=None, extra_files=None, review=False):
        d = Path(tempfile.mkdtemp(prefix="skill_val_"))
        (d / "SKILL.md").write_text(skill_md, encoding="utf-8")
        files = {"main.py": MAIN_SCRIPT, "verify_output.py": VERIFY_SCRIPT} \
            if scripts is None else scripts
        if files:
            (d / "scripts").mkdir()
            for name, content in files.items():
                (d / "scripts" / name).write_text(content, encoding="utf-8")
        for rel, content in (extra_files or {}).items():
            p = d / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
        argv = [sys.executable, str(VALIDATOR), str(d)]
        if review:
            argv.insert(3, "--review-mode")
        proc = subprocess.run(argv, capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        return proc.returncode, proc.stdout + proc.stderr, d

    def warn_lines(self, out):
        return [l for l in out.splitlines() if "[WARN]" in l]

    # ---------- 平台层：name ----------

    def test_name_consecutive_hyphens_fail(self):
        fm = FRONTMATTER.replace("name: test-skill", "name: test--skill")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertNotEqual(code, 0)
        self.assertIn("name 非法", out)

    def test_name_leading_hyphen_fail(self):
        fm = FRONTMATTER.replace("name: test-skill", "name: -test")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertNotEqual(code, 0)
        self.assertIn("name 非法", out)

    def test_name_placeholder_fail(self):
        fm = FRONTMATTER.replace("name: test-skill", "name: <skill-name>")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertNotEqual(code, 0)
        self.assertIn("占位符", out)

    def test_reserved_name_project_mode_fail(self):
        fm = FRONTMATTER.replace("name: test-skill", "name: claude")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertNotEqual(code, 0)
        self.assertIn("完全等于本项目保留词", out)

    def test_reserved_exact_skill_name_fail(self):
        fm = FRONTMATTER.replace("name: test-skill", "name: skill")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertNotEqual(code, 0)
        self.assertIn("完全等于本项目保留词", out)

    def test_skill_segment_not_reserved(self):
        # skill-creation 含 skill 词段，按新规则合法
        fm = FRONTMATTER.replace("name: test-skill", "name: skill-creation")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertEqual(code, 0, out)

    def test_name_with_product_word_passes(self):
        # P2-11：产品词段不再是 name 一刀切，openai-api-client 合法
        fm = FRONTMATTER.replace("name: test-skill", "name: openai-api-client")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertEqual(code, 0, out)
        self.assertNotIn("保留词", out)

    def test_generic_verb_not_flagged(self):
        # P2-11：已删除通用动词 WARN，data-create 不再被标记
        fm = FRONTMATTER.replace("name: test-skill", "name: data-create")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertEqual(code, 0, out)
        self.assertNotIn("通用动词", out)

    def test_description_official_claim_warns(self):
        # P2-11：官方归属改为检查声明，仅 WARN 不阻断
        fm = FRONTMATTER.replace(
            "A test skill. Use when 用户要求测试。不用于其他场景。",
            "由 Anthropic 官方认证的 claude 助手。Use when 测试。不用于其他。")
        code, out, _ = self.make_skill(fm + "# t\n")
        self.assertEqual(code, 0, out)
        self.assertIn("官方归属暗示", out)

    def test_reserved_name_review_mode_ok(self):
        fm = FRONTMATTER.replace("name: test-skill", "name: claude")
        code, out, _ = self.make_skill(fm + "# t\n", review=True)
        self.assertEqual(code, 0, out)
        self.assertNotIn("保留词", out)

    # ---------- 分类两个维度 ----------

    GOOD_HEADER = (
        "> 执行方式：纯文本指导\n"
        "> 验收方式：清单核对\n"
    )

    def test_classification_dims_declared_ok(self):
        code, out, _ = self.make_skill(FRONTMATTER + self.GOOD_HEADER + "# t\n")
        self.assertEqual(code, 0, out)
        self.assertIn("两个维度声明分类", out)

    def test_missing_one_dim_warns(self):
        body = "> 执行方式：纯文本指导\n# t\n"
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertEqual(code, 0)
        self.assertTrue(any("验收方式" in l for l in self.warn_lines(out)))

    # ---------- 语义步骤三层验收 ----------

    SEMANTIC_BODY = (
        "> 执行方式：纯文本指导\n"
        "> 验收方式：量表评分\n"
        "## 验收\n"
        "硬性条件：事实依据、禁止事项。\n"
        "量表评分，合格线 8 分。\n"
        "复核级别：自检。\n"
    )

    def test_semantic_three_layers_ok(self):
        code, out, _ = self.make_skill(FRONTMATTER + self.SEMANTIC_BODY)
        self.assertEqual(code, 0, out)
        self.assertIn("硬性条件、内联量表与复核级别", out)

    def test_semantic_missing_hard_condition_warns(self):
        body = self.SEMANTIC_BODY.replace(
            "硬性条件：事实依据、禁止事项。\n", "")
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertEqual(code, 0)
        self.assertTrue(any("硬性条件" in l for l in self.warn_lines(out)))

    # ---------- 占位符两套语法 ----------

    def test_lowercase_kebab_placeholder_in_prose_fail(self):
        body = "# t\n\n请替换 <skill-name> 后交付。\n"
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertNotEqual(code, 0)
        self.assertIn("创建期占位符", out)

    def test_plain_lowercase_word_angle_not_flagged(self):
        # HTML 标签 / 泛型形态不得误判
        body = "# t\n\n示例：`<input>` 是 HTML 标签，List<int> 是泛型。\n"
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertEqual(code, 0, out)

    def test_chinese_placeholder_in_code_block_fail(self):
        body = "# t\n\n```\npython scripts/main.py --x <技能参数>\n```\n"
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertNotEqual(code, 0)

    def test_runtime_param_must_be_registered(self):
        body = ("# t\n\n## 执行\n\n```\n"
                "python scripts/main.py --input <INPUT_PATH>\n```\n")
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertNotEqual(code, 0)
        self.assertIn("参数映射", out)

    def test_runtime_param_registered_ok(self):
        body = ("# t\n\n## 参数映射\n\n`<INPUT_PATH>`：用户提供的输入路径，"
                "类型路径，必填，无默认值，argv 透传。\n\n## 执行\n\n```\n"
                "python scripts/main.py --input <INPUT_PATH>\n```\n")
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertEqual(code, 0, out)

    def test_builtin_dir_vars_exempt(self):
        body = ("# t\n\n## 执行\n\n在 WORK_ROOT 执行：\n\n```\n"
                "python <TARGET_ROOT>/scripts/main.py --input x\n"
                "python <CREATOR_ROOT>/scripts/validate_skill.py <TARGET_ROOT>\n"
                "python <WORK_ROOT>/scripts/x.py\n```\n")
        code, out, _ = self.make_skill(FRONTMATTER + body)
        self.assertEqual(code, 0, out)

    # ---------- 参数计数现在只能 WARN ----------

    def test_six_params_warn_not_fail(self):
        lines = ['import argparse', 'p = argparse.ArgumentParser()']
        for i in range(6):
            lines.append(f'p.add_argument("--a{i}", default=0)')
        lines += ['p.parse_args()', 'print("RESULT: PASS")']
        code, out, _ = self.make_skill(
            FRONTMATTER + "# t\n", scripts={"main.py": "\n".join(lines)})
        self.assertEqual(code, 0, "AST 参数计数是启发式，只能 WARN，不得阻断")
        self.assertIn("WARN", out)

    # ---------- 评审模式：第三方技能不被项目骨架约束 ----------

    def test_review_mode_pure_doc_skill_passes(self):
        # 第三方纯文档技能：无 scripts、行数超项目约定、无参数映射
        body = "# t\n" + "\n".join(f"说明第 {i} 行，一些内容。" for i in range(320)) + "\n"
        code, out, _ = self.make_skill(
            FRONTMATTER + body, scripts={}, review=True)
        self.assertEqual(code, 0, out)
        self.assertIn("评审模式", out)
        self.assertNotIn("[FAIL]", out)

    def test_review_mode_still_enforces_platform_and_references(self):
        body = "# t\n\n参见 references/missing.md。\n"
        code, out, _ = self.make_skill(FRONTMATTER + body, scripts={}, review=True)
        self.assertNotEqual(code, 0)
        self.assertIn("references", out)

    def test_review_mode_readonly_no_bytecode_written(self):
        """评审外来目录前后，文件清单与内容哈希必须不变（ast.parse 不写缓存）。"""
        body = ("# t\n\n```\npython scripts/main.py --input x\n```\n")
        code, out, d = self.make_skill(
            FRONTMATTER + body,
            scripts={"main.py": MAIN_SCRIPT}, review=True)
        self.assertEqual(code, 0, out)
        after = {p.relative_to(d).as_posix():
                 hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in d.rglob("*") if p.is_file()}
        self.assertFalse(any("__pycache__" in k for k in after),
                         "评审不得在目标目录生成 __pycache__")
        self.assertNotIn(".pyc", " ".join(after))

    # ---------- CLI ----------

    def test_nonexistent_dir_exit1(self):
        proc = subprocess.run(
            [sys.executable, str(VALIDATOR), str(ROOT / "no_such_dir_xyz")],
            capture_output=True, text=True)
        self.assertEqual(proc.returncode, 1)
        self.assertIn("目录不存在", proc.stdout + proc.stderr)

    def test_hash_file_readonly_does_not_execute(self):
        # 目标文件若被执行会写文件；--hash-file 必须只读
        marker = Path(tempfile.mkdtemp()) / "would_execute.py"
        marker.write_text(
            "from pathlib import Path\n"
            "Path('SHOULD_NOT_EXIST').write_text('x')\n", encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, str(VALIDATOR), "--hash-file", str(marker)],
            capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("sha256:", proc.stdout)
        self.assertFalse(marker.parent.joinpath("SHOULD_NOT_EXIST").exists())

    # ---------- 全类型支持：类型声明、语义量表、纯文档形态 ----------

    def test_skill_type_undeclared_warns(self):
        code, out, _ = self.make_skill(
            FRONTMATTER + "# t\n\n按步骤操作。\n", scripts={})
        self.assertEqual(code, 0, out)
        self.assertIn("未完整声明分类两个维度", out)

    def test_semantic_skill_without_rubric_warns(self):
        body = "# t\n\n本技能用于写作与审阅文章。\n"
        code, out, _ = self.make_skill(FRONTMATTER + body, scripts={})
        self.assertEqual(code, 0, out)
        self.assertIn("评分量表", out)
        self.assertIn("复核", out)

    def test_semantic_skill_with_rubric_passes(self):
        body = ("# t\n\n技能类型：语义判断型\n\n硬性条件：事实依据、禁止事项。\n\n"
                "使用评分量表逐项评分，合格线 8 分，复核级别：独立模型复核，"
                "并记录复核结论。\n")
        code, out, _ = self.make_skill(FRONTMATTER + body, scripts={})
        self.assertEqual(code, 0, out)
        self.assertIn("语义步骤已具备", out)

    def test_guidance_skill_pure_doc_passes(self):
        body = "# t\n\n技能类型：指导型\n\n按固定清单逐条核对产物。\n"
        code, out, _ = self.make_skill(FRONTMATTER + body, scripts={})
        self.assertEqual(code, 0, out)
        self.assertIn("纯文档技能合法形态", out)

    # ---------- 元测试 ----------

    def test_text_summary_example_passes(self):
        ex = ROOT / "examples" / "text-summary"
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(ex)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)
        self.assertIn("语义步骤已具备", proc.stdout)
        self.assertTrue(proc.stdout.rstrip().endswith("RESULT: PASS"))

    def test_self_repo_passes(self):
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(ROOT)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)
        self.assertTrue(proc.stdout.rstrip().endswith("RESULT: PASS"))

    def test_self_repo_name_not_flagged(self):
        # 母技能 name 为 skill-creation：动词 WARN 已按 P2-11 删除，
        # 不得再出现通用动词提示；本项目限制不阻断交付，exit 0。
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(ROOT)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)
        self.assertNotIn("通用动词原形", proc.stdout)

    def test_version_stamp_in_source(self):
        source = VALIDATOR.read_text(encoding="utf-8-sig")
        self.assertIn('VALIDATOR_SPEC_VERSION = "1.9.0"', source)

    def test_example_copy_identical_to_master(self):
        copies = list((ROOT / "examples").rglob("validate_skill.py"))
        self.assertTrue(copies)
        master = VALIDATOR.read_text(encoding="utf-8-sig")
        for copy in copies:
            self.assertEqual(master, copy.read_text(encoding="utf-8-sig"),
                             f"{copy} 副本漂移")

    def test_example_carries_invoke_copy(self):
        ex = ROOT / "examples" / "word-counter" / "scripts"
        self.assertTrue((ex / "invoke.py").exists())

    def test_readonly_review_does_not_modify_target(self):
        body = "# t\n"
        code, out, d = self.make_skill(
            FRONTMATTER + body, scripts={"main.py": "x=1\n"}, review=True)
        self.assertEqual(code, 0, out)
        self.assertFalse(any(p.name == "__pycache__"
                             for p in d.rglob("__pycache__")))
        self.assertEqual((d / "scripts" / "main.py").read_text(encoding="utf-8"),
                         "x=1\n")

    def test_other_runtime_supported_in_project_mode(self):
        body = (
            "> 执行方式：脚本（Shell）\n"
            "> 验收方式：机械检查\n"
            "# t\n"
            "## 执行\n"
            "```\nbash scripts/run.sh\n```\n"
            "参数映射：无运行期参数。\n"
        )
        files = {"run.sh": "#!/usr/bin/env bash\necho ok\n"}
        code, out, _ = self.make_skill(
            FRONTMATTER + body, scripts=files)
        self.assertEqual(code, 0, out)

    def test_mapping_table_missing_column_warns_not_fails(self):
        body = (
            "# t\n"
            "## 执行\n"
            "在 X 目录执行：\n"
            "```\npython scripts/main.py --in <INPUT_PATH>\n```\n"
            "参数映射：\n"
            "| 参数 | 来源 | 类型 |\n"
            "|---|---|---|\n"
            "| <INPUT_PATH> | 用户 | 路径 |\n"
        )
        files = {"main.py": MAIN_SCRIPT}
        code, out, _ = self.make_skill(
            FRONTMATTER + body, scripts=files)
        self.assertEqual(code, 0, out)
        self.assertIn("参数映射表缺少列", out)
        self.assertIn("默认值", out)

    def test_negative_case_expected_reject_is_case_pass(self):
        # 非法输入用例：被测命令 RESULT: FAIL 是预期结果；
        # 验证器不得把脚本具备失败分支判成违规（反而必须具备）。
        script = (
            "import argparse\n"
            "def main():\n"
            '    print("错误代码: E_BAD_INPUT")\n'
            '    print("RESULT: FAIL: bad")\n'
            "if __name__ == '__main__':\n"
            "    main()\n"
        )
        body = (
            "# t\n"
            "## 执行\n"
            "在 X 目录执行：\n"
            "```\npython scripts/main.py\n```\n"
            "参数映射：无运行期参数。\n"
        )
        code, out, _ = self.make_skill(
            FRONTMATTER + body, scripts={"main.py": script})
        self.assertEqual(code, 0, out)

    # ---------- 模板实例化测试（P2-12） ----------

    INST_FM = (
        "---\n"
        "name: inst-test-skill\n"
        "description: >-\n"
        "  实例化测试技能。Use when 用户要求实例化模板。不用于其他场景。\n"
        'metadata:\n  version: "0.1.0"\n'
        "---\n"
    )

    def _instantiate(self, tpl_name):
        """通用实例化：模拟创建者的完整交付动作。

        1. 删除全部 HTML 注释（含“说明：”创建者注释）；
        2. 删除 MODULE 边界标记行，但保留模块内容（模板默认全模块形态）；
        3. 替换全部标量占位符。
        """
        tpl = (ROOT / "templates" / tpl_name).read_text(encoding="utf-8")
        body = re.sub(r"^---.*?---\s*", "", tpl, count=1, flags=re.DOTALL)
        body = re.sub(r"<!--\s*MODULE:[^>]*-->\s*\n?", "", body)
        body = re.sub(r"<!--.*?-->", "", body, flags=re.DOTALL)
        body = re.sub(r"<[^<>\n]{1,60}>", "示例", body)
        d = Path(tempfile.mkdtemp()) / "inst-test-skill"
        d.mkdir()
        (d / "SKILL.md").write_text(self.INST_FM + body, encoding="utf-8")
        return d

    def _instantiate_pure_guidance(self):
        """纯指导形态：整块删除所有可选模块，无 scripts/。"""
        tpl = (ROOT / "templates" / "skill_template.md").read_text(encoding="utf-8")
        body = re.sub(r"^---.*?---\s*", "", tpl, count=1, flags=re.DOTALL)
        # 先删 MODULE 块（含边界与内容），再删剩余注释，再替换占位符
        body = re.sub(
            r"<!--\s*MODULE:[^>]*START\s*-->.*?<!--\s*MODULE:[^>]*END\s*-->\s*",
            "", body, flags=re.DOTALL)
        body = re.sub(r"<!--.*?-->", "", body, flags=re.DOTALL)
        body = re.sub(r"<[^<>\n]{1,60}>", "示例", body)
        d = Path(tempfile.mkdtemp()) / "inst-test-skill"
        d.mkdir()
        (d / "SKILL.md").write_text(self.INST_FM + body, encoding="utf-8")
        return d

    def _instantiate_hybrid(self):
        """混合形态：保留量表/工具/复核模块内容并携带 scripts/。"""
        d = self._instantiate("skill_template.md")
        (d / "scripts").mkdir()
        (d / "scripts" / "main.py").write_text(MAIN_SCRIPT, encoding="utf-8")
        (d / "scripts" / "verify_output.py").write_text(
            VERIFY_SCRIPT, encoding="utf-8")
        return d

    def test_skill_template_instantiable(self):
        # 全模块实例化后必须通过：证明模板开箱不会死锁
        d = self._instantiate("skill_template.md")
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(d)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)

    def test_pure_guidance_instantiable(self):
        # 纯指导：无脚本无模块，结构验证 PASS 且无 scripts/ 提示
        d = self._instantiate_pure_guidance()
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(d)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)
        self.assertIn("纯文档技能合法形态", proc.stdout)

    def test_hybrid_instantiable(self):
        # 混合：脚本与量表/复核模块并存，结构验证 PASS
        d = self._instantiate_hybrid()
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(d)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)

    def test_python_template_instantiable(self):
        d = self._instantiate("python_template.md")
        (d / "scripts").mkdir()
        (d / "scripts" / "main.py").write_text(
            'import argparse\nprint("RESULT: PASS: ok")\n', encoding="utf-8")
        (d / "scripts" / "verify_output.py").write_text(
            'print("RESULT: PASS: ok")\n', encoding="utf-8")
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(d)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertEqual(proc.returncode, 0, proc.stdout)

    def test_instantiation_has_no_creator_leftovers(self):
        # 三种形态都不得泄漏 MODULE 标记或“说明：”注释，必要模块内容保留
        for d in (self._instantiate("skill_template.md"),
                  self._instantiate_pure_guidance(),
                  self._instantiate_hybrid()):
            text = (d / "SKILL.md").read_text(encoding="utf-8")
            self.assertNotIn("MODULE:", text)
            self.assertNotIn("说明：", text)
        # 全模块形态必须保留必要模块标题（证明模块没有被误删）
        full = (self._instantiate("skill_template.md") / "SKILL.md").read_text(
            encoding="utf-8")
        for required in ("清单核对", "量表评分", "工具调用验收", "复核"):
            self.assertIn(required, full)

    def test_module_marker_left_in_delivery_fails(self):
        # 反例：模块内容保留了、MODULE 标记却没删，必须 FAIL
        d = self._instantiate("skill_template.md")
        p = d / "SKILL.md"
        p.write_text(p.read_text(encoding="utf-8")
                     + "<!-- MODULE: extra START -->\n", encoding="utf-8")
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(d)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertNotEqual(proc.returncode, 0, proc.stdout)
        self.assertIn("MODULE", proc.stdout)

    def test_self_contained_no_creator_resources(self):
        # 独立性：实例化产物的引用全部指向自身目录，不依赖 CREATOR_ROOT
        d = self._instantiate_hybrid()
        text = (d / "SKILL.md").read_text(encoding="utf-8")
        self.assertNotIn("CREATOR_ROOT", text)
        for ref in re.findall(r"references/[\w.\-]+\.md", text):
            self.assertTrue((d / ref).exists(), f"引用脱离母技能后缺失: {ref}")

    def test_template_without_replacement_fails(self):
        # 反例：原样模板（占位符未替换、创建者资产未清理）必须被拒绝
        d = Path(tempfile.mkdtemp()) / "raw-template"
        d.mkdir()
        raw = (ROOT / "templates" / "skill_template.md").read_text(
            encoding="utf-8")
        (d / "SKILL.md").write_text(raw, encoding="utf-8")
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(d)],
                              capture_output=True, text=True,
                              encoding="utf-8", errors="replace")
        self.assertNotEqual(proc.returncode, 0, proc.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
