#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# safe_copy.py — 可信安全复制工具（评审/改进外来技能时使用）
"""
safe_copy.py — 安全复制技能目录（只读源、只写目标，不执行源目录任何代码）

为什么需要它：
    shutil.copytree 默认会跟随符号链接，可能把 TARGET_ROOT 之外的
    凭证、密钥或敏感文件复制进工作副本；普通 copytree 也不防链接环、
    设备文件和超大目录树。本工具把这些判断固定下来，创建者不需要
    自己实现。

安全规则（任一不满足即拒绝整个复制，RESULT: FAIL 退出 1）：
    1. 只复制普通文件和普通目录；符号链接、目录联接(junction)、
       设备文件、FIFO、套接字一律拒绝，并报告其路径；
    2. 对每个路径做真实路径解析（resolve），解析结果必须仍位于
       源根目录之内；指向源外的条目直接拒绝，不静默跳过；
    3. 限制目录树条目数与总大小，超限拒绝（默认 5000 条 / 50 MB），
       可用 --max-files / --max-bytes 调整；
    4. 复制完成后逐字节核对 SHA256；
    5. 目标目录必须不存在或为空，绝不覆盖已有内容。

本工具本身是可信母本的一部分，随 skill-creation 分发，不复制进子技能。

用法：
    python scripts/safe_copy.py <源目录> <目标目录>
    python scripts/safe_copy.py <源目录> <目标目录> --max-bytes 104857600

终态协议：成功退出 0 且最后一个非空行为 RESULT: PASS；
          失败退出 1 且最后一个非空行为 RESULT: FAIL。
"""

import argparse
import hashlib
import os
import sys
from pathlib import Path

DEFAULT_MAX_FILES = 5000
DEFAULT_MAX_BYTES = 50 * 1024 * 1024
READ_CHUNK = 1024 * 1024


def fail(msg):
    print(f"RESULT: FAIL: {msg}", flush=True)
    return 1


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        while True:
            chunk = fh.read(READ_CHUNK)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def run(src_root: Path, dst_root: Path, max_files: int, max_bytes: int) -> int:
    src_real = src_root.resolve()
    if not src_real.is_dir():
        return fail(f"源目录不存在或不是目录: {src_root}")
    if dst_root.exists() and any(dst_root.iterdir()):
        return fail(f"目标目录已存在且非空，拒绝覆盖: {dst_root}")

    dst_root.mkdir(parents=True, exist_ok=True)
    count = 0
    total = 0
    copied = []

    for root, dirs, files in os.walk(src_real, followlinks=False):
        root_p = Path(root)
        # 目录本身的安全性
        if root_p != src_real:
            real_root = root_p.resolve()
            try:
                real_root.relative_to(src_real)
            except ValueError:
                return fail(
                    f"发现指向源目录之外的链接目录，已停止: {root_p} -> {real_root}")
            if root_p.is_symlink():
                return fail(f"发现符号链接目录，已停止: {root_p}")

        for name in sorted(dirs + files):
            p = root_p / name
            count += 1
            if count > max_files:
                return fail(f"目录条目超过上限 {max_files}，拒绝复制（可显式调大 --max-files）")

            if p.is_symlink():
                return fail(f"发现符号链接，已停止（不解引用，避免带出源外文件）: {p}")

            try:
                st = p.stat()  # follow_symlinks=True；前面已排除链接
            except OSError as exc:
                return fail(f"无法读取条目状态: {p}: {exc}")

            import stat as stat_mod
            mode = st.st_mode
            if not (stat_mod.S_ISDIR(mode) or stat_mod.S_ISREG(mode)):
                return fail(f"发现非常规文件（设备/FIFO/套接字），已停止: {p}")

            real_p = p.resolve()
            try:
                real_p.relative_to(src_real)
            except ValueError:
                return fail(f"条目解析后位于源目录之外，已停止: {p} -> {real_p}")

            if stat_mod.S_ISREG(mode):
                total += st.st_size
                if total > max_bytes:
                    return fail(f"总大小超过上限 {max_bytes} 字节，拒绝复制（可显式调大 --max-bytes）")
                rel = p.relative_to(src_real)
                out = dst_root / rel
                out.parent.mkdir(parents=True, exist_ok=True)
                data = p.read_bytes()
                out.write_bytes(data)
                copied.append((rel, hashlib.sha256(data).hexdigest()))

    # 逐字节复核
    for rel, digest in copied:
        actual = sha256_file(dst_root / rel)
        if actual != digest:
            return fail(f"复制后校验不一致: {rel}")

    print(f"[进度] 已复制 {len(copied)} 个普通文件，共 {total} 字节，全部 SHA256 复核一致")
    print(f"RESULT: PASS: 安全复制完成: {src_real} -> {dst_root.resolve()}", flush=True)
    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="safe_copy.py",
        description="安全复制技能目录：拒绝链接、特殊文件、源外路径和超大目录树")
    parser.add_argument("src", help="源目录（被评审技能）")
    parser.add_argument("dst", help="目标目录（受控工作副本位置，须不存在或为空）")
    parser.add_argument("--max-files", type=int, default=DEFAULT_MAX_FILES)
    parser.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES)
    args = parser.parse_args()
    sys.exit(run(Path(args.src), Path(args.dst), args.max_files, args.max_bytes))


if __name__ == "__main__":
    sys.exit(main())
