#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
<skill_name>.py — <技能一句话功能>

弱模型友好的单入口主脚本骨架。使用方法：
1. 全局替换 <中文尖括号> 与 <小写-kebab 形态> 创建期占位符；
   本文件交付前不得残留创建期占位符；
2. 在“任务实现区”填写 compute_outputs() 与独立校验逻辑；
3. 不要删除 progress / fail_out / result 函数与终态输出协议。

终态输出协议（与 SKILL.md、verify_output.py 完全一致）：
  - 进度行只允许 [进度] 前缀，绝不在进度行出现 RESULT/PASS/FAIL 字样；
  - 成功：退出码 0，最后一个非空行为 RESULT: PASS；
  - 失败：退出码 1，最后一个非空行为 RESULT: FAIL，其前一行给出错误代码；
  - 其他组合都是输出协议异常，调用方必须停止。

设计约束：
  - 参数建议不超过 5 个（工程建议，非硬性正确性要求；不为减参数合并
    语义或隐藏权限），全部带默认值；必填输入缺失时以 E_MISSING_INPUT 失败；
  - 任何业务副作用（写产物、联网）之前先做环境预检；
  - 幂等跳过条件（四者全部满足）：现有产物通过验证、输入内容哈希一致、
    参数一致、实现签名（本文件内容哈希）一致；任一不满足即重算；
  - 多文件提交不承诺跨文件瞬时原子性（平台无事务文件系统前提），
    承诺“失败可检测、可恢复”：暂存目录逐个自检 → 备份后逐个替换 →
    失败尝试回滚；回滚也失败时留下 .INCOMPLETE 标记并以 E_IO 失败，
    下次运行检测到标记或 manifest 不一致即整体重算；
  - manifest 最后写入；verify_output.py 绑定本次实际输入/参数/实现重算，
    不信任产物或 manifest 的自报信息；
  - 不联网、不写输出目录之外的路径、不删除、不外发。

用法：
    python scripts/<skill_name>.py --input INPUT_DIR
    python scripts/<skill_name>.py --input INPUT_DIR --out output --overwrite
"""

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

SCRIPT_VERSION = "1.0.0"
INCOMPLETE_MARKER = ".INCOMPLETE"
MANIFEST_NAME = ".manifest.json"

# 错误代码表：SKILL.md 故障表按代码处理，运行者不需要根据错误文字猜测。
# 注意：操作结果（命令失败）与交付状态（失败/阻塞）是两件事，
# E_ENV 表示环境缺失，交付状态映射为“阻塞”，不是“失败”。
E_MISSING_INPUT = "E_MISSING_INPUT"    # 必填输入缺失或不是合法路径
E_BAD_INPUT = "E_BAD_INPUT"            # 输入内容不合法（空目录、格式错误等）
E_ENV = "E_ENV"                        # 环境预检失败（Python 版本、写权限等）→ 交付状态：阻塞
E_IO = "E_IO"                          # 读写失败（磁盘、权限、占用）
E_VERIFY = "E_VERIFY"                  # 临时产物自检失败
E_TRANSIENT = "E_TRANSIENT"            # 锁文件/占用类临时错误，仅确认无副作用或具备幂等、去重机制时可原样重跑一次


def progress(msg):
    print(f"[进度] {msg}", flush=True)


def fail_out(code, msg):
    """失败出口：先错误代码行，最后一个非空行必须是 RESULT: FAIL，退出码 1。"""
    print(f"错误代码: {code}", flush=True)
    print(f"RESULT: FAIL: {msg}", flush=True)
    return 1


def pass_out(msg):
    print(f"RESULT: PASS: {msg}", flush=True)
    return 0


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_signature(path: Path) -> dict:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return {"path": path.name, "sha256": h.hexdigest(), "size": path.stat().st_size}


def input_signature(input_path: Path) -> str:
    """目录输入：按相对路径排序后逐文件哈希（文件输入：单文件哈希）。

    只基于内容，不使用大小或修改时间，避免输入内容不变却误判失效。
    """
    h = hashlib.sha256()
    if input_path.is_dir():
        files = sorted(p for p in input_path.rglob("*") if p.is_file())
        for p in files:
            rel = p.relative_to(input_path).as_posix()
            h.update(rel.encode("utf-8"))
            h.update(b"\0")
            h.update(p.read_bytes())
            h.update(b"\0")
    elif input_path.is_file():
        h.update(input_path.read_bytes())
    else:
        raise FileNotFoundError(str(input_path))
    return h.hexdigest()


def environment_precheck() -> str | None:
    """业务副作用之前的环境预检。返回非 None 字符串表示缺项（交付状态：阻塞）。"""
    if sys.version_info < (3, 8):
        return f"需要 Python 3.8+，当前为 {sys.version.split()[0]}"
    # <在此补充本技能的依赖/外部命令检查，例如 import xxx；不通过时返回说明文字>
    return None


def compute_outputs(input_path: Path, limit: int) -> list[tuple[str, str]]:
    """任务实现区：返回 [(相对输出文件名, 文本内容), ...]。

    必须为纯函数：相同输入与参数必须产出相同内容；不在这里做任何写盘动作。
    """
    raise NotImplementedError("请在 compute_outputs 中填写真实任务逻辑")


def stage_and_commit(out_dir: Path, outputs: list[tuple[str, str]], record: dict,
                     manifest_path: Path) -> int | None:
    """暂存—自检—备份—替换—写 manifest 的可恢复提交。

    不保证多文件瞬时原子（那需要事务文件系统等平台前提），
    保证任何中断都可检测、可恢复：
      - verify_output.py 看到 .INCOMPLETE 标记或 manifest 与产物不一致即 FAIL；
      - 本脚本下次运行检测到上述状态会整体重算。
    返回 None 表示成功；返回 int 退出码表示失败。
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    staging = out_dir / f".staging-{os.getpid()}"
    if staging.exists():
        for p in sorted(staging.rglob("*"), reverse=True):
            p.unlink() if p.is_file() else p.rmdir()
        staging.rmdir()
    staging.mkdir(parents=True)

    # 1) 全部写入暂存目录
    staged = []
    try:
        for name, content in outputs:
            tmp = staging / name
            tmp.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(content, encoding="utf-8", newline="\n")
            staged.append(tmp)

        # 2) 暂存产物逐个自检（在正式目录之外验证，失败不污染正式目录）
        for tmp in staged:
            reason = self_verify_one(tmp)
            if reason:
                return fail_out(E_VERIFY, f"临时产物自检未通过: {tmp.name}: {reason}")

        # 3) 标记未完成状态；备份旧文件；逐个替换
        marker = out_dir / INCOMPLETE_MARKER
        marker.write_text(
            json.dumps({"pending": [n for n, _ in outputs]}, ensure_ascii=False),
            encoding="utf-8")
        backups: list[tuple[Path, Path | None]] = []
        committed: list[Path] = []
        try:
            for name, _content in outputs:
                target = out_dir / name
                backup = None
                if target.exists():
                    backup = target.with_suffix(target.suffix + ".bak")
                    target.replace(backup)
                    backups.append((target, backup))
                else:
                    backups.append((target, None))
                (staging / name).replace(target)
                committed.append(target)
        except OSError as exc:
            # 4) 替换失败：尝试回滚已提交文件
            rollback_failed = []
            for target, backup in reversed(backups):
                try:
                    if backup is not None and backup.exists():
                        if target.exists():
                            target.unlink()
                        backup.replace(target)
                except OSError:
                    rollback_failed.append(str(target))
            if rollback_failed:
                return fail_out(
                    E_IO,
                    f"提交失败且回滚不完整: {exc}；受影响文件: {', '.join(rollback_failed)}；"
                    f"{INCOMPLETE_MARKER} 已保留，重新运行本脚本将整体重算")
            return fail_out(E_IO, f"提交失败，已回滚: {exc}；重新运行即可恢复")

        # 5) 全部替换成功后，manifest 最后写入并清除标记
        manifest_tmp = manifest_path.with_suffix(".json.tmp")
        manifest_tmp.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n")
        manifest_tmp.replace(manifest_path)
        marker.unlink()

        # 清理暂存目录与旧备份
        for _t, backup in backups:
            if backup is not None and backup.exists():
                backup.unlink()
        for p in sorted(staging.rglob("*"), reverse=True):
            p.unlink() if p.is_file() else p.rmdir()
        staging.rmdir()
        return None
    finally:
        if staging.exists():
            for p in sorted(staging.rglob("*"), reverse=True):
                try:
                    p.unlink() if p.is_file() else p.rmdir()
                except OSError:
                    pass
            try:
                staging.rmdir()
            except OSError:
                pass


def self_verify_one(staged_file: Path) -> str | None:
    """对单个暂存产物做基本自检；返回 None 表示通过，字符串表示原因。

    任务专属的严格检查写在 verify_output.py（运行期、绑定本次输入）。
    """
    if staged_file.stat().st_size == 0:
        return "文件为空"
    return None


def run(input_arg: str, out: str, limit: int, overwrite: bool) -> int:
    progress("[1/5] 环境预检（业务副作用之前）")
    missing = environment_precheck()
    if missing:
        return fail_out(E_ENV, f"环境不满足，交付状态为阻塞: {missing}")

    input_path = Path(input_arg)
    if not input_path.exists():
        return fail_out(E_MISSING_INPUT, f"输入路径不存在: {input_path}")

    out_dir = Path(out)
    manifest_path = out_dir / MANIFEST_NAME

    # 上次中断或不一致状态：不尝试修补，整体重算（可恢复策略）
    if (out_dir / INCOMPLETE_MARKER).exists():
        progress("检测到上次提交未完成标记，整体重新计算")
        overwrite = True

    progress("[2/5] 计算输入与实现签名")
    try:
        sig = input_signature(input_path)
    except OSError as exc:
        return fail_out(E_BAD_INPUT, f"无法读取输入: {exc}")
    impl_sig = sha256_bytes(Path(__file__).read_bytes())

    if not overwrite and manifest_path.exists():
        try:
            old = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            old = {}
        if (old.get("input_signature") == sig
                and old.get("params") == {"input": str(input_path), "out": out, "limit": limit}
                and old.get("implementation_signature") == impl_sig):
            declared = old.get("outputs", [])
            if declared and all((out_dir / rel).is_file() for rel in declared) \
                    and not (out_dir / INCOMPLETE_MARKER).exists():
                return pass_out(
                    f"输入、参数、实现签名均一致，跳过计算，产物位于: {out_dir.as_posix()}")
        progress("已有产物与本次输入/参数/实现不一致，重新计算（契约内授权更新生成物）")

    progress("[3/5] 执行任务计算")
    try:
        outputs = compute_outputs(input_path, limit)
    except NotImplementedError:
        return fail_out(E_VERIFY, "compute_outputs 任务逻辑尚未填写（模板骨架不可直接运行）")
    except ValueError as exc:
        return fail_out(E_BAD_INPUT, str(exc))
    except OSError as exc:
        return fail_out(E_IO, f"读取输入失败: {exc}")

    if not outputs:
        return fail_out(E_BAD_INPUT, "计算结果为空；按任务契约这属于非法输入")

    progress(f"[4/5] 暂存并提交 {len(outputs)} 个产物（失败可检测、可恢复）")
    record = {
        "script_version": SCRIPT_VERSION,
        "implementation_signature": impl_sig,
        "input_signature": sig,
        "params": {"input": str(input_path), "out": out, "limit": limit},
        "outputs": [name for name, _ in outputs],
    }
    commit_result = stage_and_commit(out_dir, outputs, record, manifest_path)
    if commit_result is not None:
        return commit_result

    progress("[5/5] 提交完成；任务是否成功仍以 verify_output.py 对同一次输入的验证结果为准")
    return pass_out(f"处理完成，产物位于: {out_dir.as_posix()}（共 {len(outputs)} 个文件）")


def main():
    parser = argparse.ArgumentParser(
        prog="<skill_name>.py",
        description="<技能一句话功能>")
    parser.add_argument(
        "--input", default="input",
        help="输入路径，默认: input；路径不存在时脚本以 E_MISSING_INPUT 失败")
    parser.add_argument("--out", default="output", help="输出目录，默认: output")
    parser.add_argument("--limit", type=int, default=100,
                        help="最多处理多少项，默认: 100（防止误操作跑全量）")
    parser.add_argument("--overwrite", action="store_true",
                        help="强制忽略仍然有效的缓存重新计算；默认关闭")
    args = parser.parse_args()
    sys.exit(run(args.input, args.out, args.limit, args.overwrite))


if __name__ == "__main__":
    sys.exit(main())
