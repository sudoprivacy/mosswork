#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_output.py — 任务产物验证器（运行期使用）

职责：验证“本次输入、本次参数对应的本次产物”是否合格。
不做技能结构检查（那是 validate_skill.py），不做环境预检（主脚本负责）。

与本次运行的绑定契约（关键）：
  本脚本必须拿到本次实际的输入路径与有效参数，重新独立计算输入签名，
  并与产物目录中 .manifest.json 记录比对。产物自身合法、甚至与 manifest
  自洽都不够——manifest 可能与产物一起被修改，或产物来自另一次输入。
  只有下列全部成立才允许 RESULT: PASS：
    1. 主脚本本次以退出码 0、RESULT: PASS 结束（调用方保证调用时机）；
    2. 传入的 --input/--limit/--out 就是本次运行实际使用的值；
    3. manifest 中的输入签名、参数、实现签名分别与本次实际值一致；
    4. 无 .INCOMPLETE 标记、无 .tmp/.bak 残留、无清单外幽灵产物；
    5. 技能专属内容断言通过（独立基准，见技能专属检查区）。

终态输出协议：
  - 明细行使用 [通过]/[问题] 前缀；进度行使用 [进度]；
  - 成功：退出码 0，最后一个非空行为 RESULT: PASS；
  - 失败：退出码 1，最后一个非空行为 RESULT: FAIL。

用法（参数与主脚本同名同义，调用方原样透传，禁止自行推算路径）：
    python scripts/verify_output.py --input INPUT_DIR --out output
    python scripts/verify_output.py --input INPUT_DIR --out output --limit 100
    python scripts/verify_output.py -h
"""

import argparse
import hashlib
import json
import sys
from pathlib import Path

MANIFEST_NAME = ".manifest.json"
INCOMPLETE_MARKER = ".INCOMPLETE"
INFRASTRUCTURE_SCRIPTS = {"validate_skill.py", "verify_output.py", "invoke.py",
                          "safe_copy.py"}


def detail_ok(msg):
    print(f"[通过] {msg}")


def detail_bad(msg):
    print(f"[问题] {msg}")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def input_signature(input_path: Path) -> str:
    """与主脚本同一规范的输入内容签名（只基于内容，排序确定）。

    这里重新独立计算，不读取主脚本内存中的任何值，以防绑定失效。
    """
    h = hashlib.sha256()
    if input_path.is_dir():
        files = sorted(p for p in input_path.rglob("*") if p.is_file())
        for p in files:
            rel = p.relative_to(input_path).as_posix()
            h.update(rel.encode("utf-8"))
            h.update(b"\0")
            h.update(p.read_bytes())
            h.update(b"\0")
    elif input_path.is_file():
        h.update(input_path.read_bytes())
    else:
        raise FileNotFoundError(str(input_path))
    return h.hexdigest()


def find_main_script(scripts_dir: Path) -> Path | None:
    candidates = [p for p in scripts_dir.glob("*.py")
                  if p.name not in INFRASTRUCTURE_SCRIPTS]
    return candidates[0] if len(candidates) == 1 else None


def independent_expectation(input_path: Path, limit: int):
    """技能专属检查区：用独立基准计算预期，禁止照抄主脚本算法。

    例如主脚本用 str.split 统计词频，这里应使用另一套实现（如正则），
    或直接使用任务契约中写明的手工基准数据。
    返回任意可比较对象，交给 compare_outputs 使用。
    """
    raise NotImplementedError("请按任务契约填写独立预期计算")


def compare_outputs(expected, business_files, out_dir: Path) -> list[str]:
    """技能专属检查区：把独立预期与本次产物逐字比对。

    返回差异说明列表；空列表表示内容一致。
    “格式正确但内容错误”的产物必须在这里产生一条差异，例如：
        实际行 = (out_dir / "report.csv").read_text(encoding="utf-8").splitlines()
        if 实际行 != expected:
            return [f"report.csv 与独立预期逐字不一致"]
    """
    raise NotImplementedError("请按任务契约填写产物与独立预期的逐字比对")


def run(input_arg: str, out_arg: str, limit: int) -> int:
    failures = []
    input_path = Path(input_arg)
    out = Path(out_arg)
    scripts_dir = Path(__file__).resolve().parent

    if not input_path.exists():
        detail_bad(f"本次输入路径不存在，无法绑定验收: {input_path}")
        print("RESULT: FAIL: 本次输入缺失，拒绝依据旧产物判定成功")
        return 1
    if not out.exists():
        detail_bad(f"产物目录不存在: {out}")
        print("RESULT: FAIL: 产物目录不存在，本次任务未完成")
        return 1

    # ---- 1. 未完成标记与临时/备份残留 ----
    if (out / INCOMPLETE_MARKER).exists():
        failures.append(f"存在 {INCOMPLETE_MARKER} 标记：上次提交未完成，必须整体重算")
    leftovers = [p.name for p in out.rglob("*")
                 if p.is_file() and (p.name.endswith(".tmp") or p.name.endswith(".bak"))]
    if leftovers:
        failures.append("存在临时/备份残留: " + ", ".join(sorted(leftovers)[:5]))

    # ---- 2. manifest 必须存在并可解析 ----
    manifest_path = out / MANIFEST_NAME
    manifest = None
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        detail_ok("manifest 存在且可解析")
    except (OSError, json.JSONDecodeError) as exc:
        failures.append(f"manifest 缺失或不可解析: {exc}")

    # ---- 3. 绑定本次实际输入、参数、实现 ----
    actual_sig = input_signature(input_path)
    main_script = find_main_script(scripts_dir)
    actual_impl = sha256_bytes(main_script.read_bytes()) if main_script else None

    if manifest is not None:
        if manifest.get("input_signature") != actual_sig:
            failures.append(
                "输入签名不一致：产物不是本次输入的结果"
                f"（manifest={str(manifest.get('input_signature'))[:12]}...，"
                f"本次输入={actual_sig[:12]}...）")
        expected_params = {"input": str(input_path), "out": out_arg, "limit": limit}
        if manifest.get("params") != expected_params:
            failures.append(
                f"参数不一致：manifest 记录 {manifest.get('params')}，"
                f"本次运行 {expected_params}")
        if actual_impl is not None and manifest.get("implementation_signature") != actual_impl:
            failures.append("实现签名不一致：产物由不同版本的主脚本生成，必须重算")

    # ---- 4. 清单产物与幽灵产物 ----
    business = sorted(
        p for p in out.rglob("*")
        if p.is_file()
        and p.name != MANIFEST_NAME
        and p.name != INCOMPLETE_MARKER
        and not p.name.endswith(".tmp")
        and not p.name.endswith(".bak"))
    if not business:
        failures.append("没有任何业务产物文件")

    declared = set((manifest or {}).get("outputs", []))
    actual_rel = {p.relative_to(out).as_posix() for p in business}
    ghosts = actual_rel - declared
    missing = declared - actual_rel
    if ghosts:
        failures.append("存在 manifest 清单外的幽灵产物: " + ", ".join(sorted(ghosts)[:5]))
    if missing:
        failures.append("manifest 声明但缺失的产物: " + ", ".join(sorted(missing)[:5]))

    for p in business:
        try:
            size = p.stat().st_size
        except OSError as exc:
            failures.append(f"产物无法读取: {p.name}: {exc}")
            continue
        if size == 0:
            failures.append(f"产物为空文件: {p.relative_to(out).as_posix()}")

    # ---- 5. 技能专属内容断言（独立基准，格式正确但内容错误必须在此拒绝）----
    if manifest is not None and not ghosts and not missing:
        try:
            expected = independent_expectation(input_path, limit)
            failures.extend(compare_outputs(expected, business, out))
        except NotImplementedError:
            failures.append(
                "verify_output.py 未实现独立内容断言（independent_expectation/"
                "compare_outputs）；结构合法不等于内容正确")

    for p in business:
        if p.is_file() and p.stat().st_size > 0:
            detail_ok(f"产物存在且非空: {p.relative_to(out).as_posix()}（{p.stat().st_size} 字节）")

    if failures:
        for f in failures:
            detail_bad(f)
        print("RESULT: FAIL: 产物未通过本次输入绑定验证，本次任务不得宣布完成")
        return 1

    print(f"RESULT: PASS: 产物与本次输入/参数/实现绑定且内容验证通过，"
          f"共 {len(business)} 个业务产物文件")
    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="verify_output.py",
        description="验证本次输入与参数对应的任务产物（运行期）")
    parser.add_argument("--input", required=True,
                        help="本次运行实际使用的输入路径（必填，用于与产物绑定核对）")
    parser.add_argument("--out", default="output",
                        help="本次运行实际使用的输出目录，默认: output")
    parser.add_argument("--limit", type=int, default=100,
                        help="本次运行实际使用的业务参数，默认: 100")
    args = parser.parse_args()
    sys.exit(run(args.input, args.out, args.limit))


if __name__ == "__main__":
    sys.exit(main())
