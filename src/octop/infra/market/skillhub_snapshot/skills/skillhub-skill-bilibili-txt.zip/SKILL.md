---
name: skillhub-skill-bilibili-txt
description: "提取B站（bilibili.com）视频的完整文字稿。当用户需要提取、获取、下载B站视频的文字稿、字幕、转录内容、语音转文字时使用此skill。支持从视频URL提取音频并使用Whisper进行中文语音识别，生成带时间戳的结构化文字稿。触发词包括\"提取B站\"\"B站文字稿\"\"bilibili转录\"\"视频转文字\"等。"
---

# Bilibili Transcript - B站视频文字稿提取

## Overview

从B站视频URL提取完整语音文字稿。通过 yt-dlp 下载音频，再用 OpenAI Whisper 进行中文语音识别，生成带时间戳的结构化 Markdown 文字稿文件。

## Prerequisites

确保以下工具已安装（如未安装则先执行安装）：

1. **yt-dlp** - B站视频/音频下载工具
   ```bash
   pip3 install yt-dlp
   ```

2. **openai-whisper** - 语音识别模型
   ```bash
   pip3 install openai-whisper
   ```

## Workflow

### Step 1: 下载B站视频音频

使用 yt-dlp 下载视频的音频轨（mp3格式）：

```bash
yt-dlp -f "bestaudio" --extract-audio --audio-format mp3 -o "<output_dir>/bilibili_audio.%(ext)s" "<B站视频URL>"
```

**注意事项：**
- B站高画质格式需大会员Cookie，但音频轨一般可直接下载
- 如果遇到SSL证书问题，Python中需设置 `ssl._create_default_https_context = ssl._create_unverified_context`
- B站URL格式示例：`https://www.bilibili.com/video/BV1RiASzXEEy`

### Step 2: 检查是否有CC字幕（可选优先路径）

部分B站视频提供UP主上传的CC字幕，如果有则可直接提取，无需语音识别：

```bash
yt-dlp --list-subs "<B站视频URL>"
```

- 如果显示 `zh-Hans` / `zh` 等非弹幕字幕，直接下载字幕文件：
  ```bash
  yt-dlp --write-subs --sub-lang zh-Hans --skip-download -o "<output_dir>/bilibili_subtitle" "<B站视频URL>"
  ```
- `danmaku` 是弹幕（观众评论），不是视频内容稿，不能替代语音转录
- CC字幕需要登录Cookie才能获取，未登录时可能无法获取

### Step 3: 语音识别转录

使用 `scripts/transcribe.py` 脚本进行转录：

```bash
python3 <skill_dir>/scripts/transcribe.py --input <audio_file> --output <output_file> [--model-size <size>]
```

**参数说明：**
- `--input`: 输入音频文件路径（必需）
- `--output`: 输出文字稿文件路径（必需）
- `--model-size`: Whisper模型大小，默认 `medium`（可选：tiny/base/small/medium/large）
  - `medium`：中文识别效果较好，模型约1.5GB
  - `large`：效果最佳但速度慢，模型约3GB
  - `small`：速度快但中文准确度稍低

**Whisper模型选择指南：**
| 模型 | 大小 | 中文效果 | 速度 | 适用场景 |
|------|------|----------|------|----------|
| tiny | 39M | 差 | 最快 | 快速预览 |
| base | 74M | 一般 | 很快 | 短视频 |
| small | 244M | 较好 | 快 | 一般视频 |
| medium | 1.5G | 好 | 中等 | 推荐（默认）|
| large | 3G | 最佳 | 慢 | 长视频/专业需求 |

### Step 4: 获取视频元信息

使用 WebFetch 获取视频的标题、UP主、播放量等元信息：

```
WebFetch url="https://www.bilibili.com/video/<BV号>" prompt="提取视频标题、作者、播放量、发布时间、简介"
```

### Step 5: 整理输出文字稿

将转录结果整理为结构化的文字稿文件（.txt后缀，微信兼容），格式如下：

```markdown
# {视频标题}

**UP主**: {作者} | **播放量**: {播放量} | **发布时间**: {发布时间}
**视频链接**: {原始URL}

---

## 完整文字稿

[00:00] 转录内容...
[00:15] 转录内容...
...

---

## 要点总结

| 方法/要点 | 核心思路 | 具体操作 |
|-----------|---------|---------|
| ... | ... | ... |

**金句**: 提取的金句内容
```

**输出规范：**
- 文件保存为 `.txt` 后缀（微信移动端兼容）
- 按视频内容逻辑分节，添加章节标题
- 提取核心要点，整理为表格
- 提取金句/关键结论
- 时间戳格式：`[MM:SS]`

### Step 6: 清理临时文件

删除下载的音频文件和弹幕xml文件：

```bash
rm -f "<output_dir>/bilibili_audio.mp3" "<output_dir>/bilibili_subtitle.danmaku.xml"
```

## Common Issues

### SSL证书错误
**现象**: Whisper下载模型时出现 `SSL: CERTIFICATE_VERIFY_FAILED`
**解决**: 脚本中已内置 `ssl._create_default_https_context = ssl._create_unverified_context` 绕过

### B站字幕需登录
**现象**: `Subtitles are only available when logged in`
**解决**: 使用 `--cookies-from-browser chrome` 参数传入浏览器Cookie，或直接走语音识别路线

### 高画质无法下载
**现象**: `Format(s) 4K, 1080P... are missing; you have to become a premium member`
**解决**: 音频轨不受此限制，可正常下载；如需视频画面则需Cookie

### FP16不支持
**现象**: `FP16 is not supported on CPU; using FP32 instead`
**解决**: 这是警告而非错误，CPU上自动降级为FP32，不影响结果

## Resources

### scripts/
- `transcribe.py` - Whisper语音识别转录脚本，支持参数化模型选择，输出带时间戳的文字稿
