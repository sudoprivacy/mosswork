#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C盘清理 · 一键扫描流水线（skill 版，扁平布局）。

流程：scan.py(只读扫描) -> analyze.py(分级聚合) -> build_report.py(注入品牌出 HTML)
-> 后台启动 server.py(可交互报告页)。
每次输出带时间戳，落在脚本同级 fresh/ 目录，不覆盖历史。

用法：
    python run.py                # 跑完整流水线，弹出可交互报告页
    python run.py --out DIR      # 自定义输出目录
"""
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request as _ur

PY = sys.executable
ROOT = os.path.dirname(os.path.abspath(__file__))          # .../skills/ai-pc-butler/scripts
SCAN = os.path.join(ROOT, "scan.py")
ANALYZE = os.path.join(ROOT, "analyze.py")
BUILD = os.path.join(ROOT, "build_report.py")
SERVER = os.path.join(ROOT, "server.py")
CONFIG = os.path.join(ROOT, "config.json")

# 统一 UTF-8：Windows 子进程 stdout 重定向到文件时，Python 会退回系统 ANSI 代码页
# （中文机=GBK），导致产物中文乱码 / analyze 读 UTF-8 报解码错误。注入环境变量覆盖。
ENV = dict(os.environ)
ENV["PYTHONUTF8"] = "1"
ENV["PYTHONIOENCODING"] = "utf-8"
# v1.7.42（一次到位）：默认走【完整扫描】——AIPC_FAST 不设为 1，一次扫描即包含
# 全部内容（绿区 + 完整迁移候选含 find_migratable_deep）。不再使用「FAST 首屏 +
# 后台 _bg_full_scan.py 补全」两阶段：用户明确反馈两阶段会让对话框出现「后台正在
# 补全」却迟迟无变化（且后台 detached 子进程在 WorkBuddy 沙箱会被清掉，补全永远
# 跑不完），违背「一次到位」原则。
# 若外部显式设置 AIPC_FAST=1（自动化/调试），尊重调用方值。
if os.environ.get("AIPC_FAST") is None:
    ENV.pop("AIPC_FAST", None)  # 不设 → scan/analyze 走全量路径

# 父进程自身的 stdout/stderr 也要强制 UTF-8：否则在中文 Windows（控制台默认 GBK）
# 上打印 🔍 这类 emoji 进度提示会抛 UnicodeEncodeError，整条流水线直接崩。
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

TS = time.strftime("%Y%m%d_%H%M%S")

# Windows 下启动子进程不弹黑色控制台窗口（避免 scan/analyze/server 等阶段闪黑框）
_WIN_FLAGS = subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0


def _clean_state_dir():
    """稳定目录（用户数据目录）：统一委托 license.get_data_dir()。

    2026-09-10 P0 修复：原实现 `APPDATA or expanduser("~")` 在 APPDATA 缺失时会漂移到
    ~/AI_PC_Butler，与激活记录所在的 Roaming 目录不一致，造成"激活过却要重新付费"。
    统一委托 license.get_data_dir() 消除多份口径漂移。
    """
    try:
        import license as _lic
        return _lic.get_data_dir()
    except Exception:
        pass
    base = os.environ.get("APPDATA") or os.path.join(
        os.environ.get("USERPROFILE") or os.path.expanduser("~"), "AppData", "Roaming")
    d = os.path.join(base, "AI_PC_Butler")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _clean_state_path():
    """稳定路径（%APPDATA%/AI_PC_Butler/clean_state.json），与 server/build_report 一致。"""
    return os.path.join(_clean_state_dir(), "clean_state.json")


def _report_url_file():
    """server.py 写入的可交互报告页 URL 文件。"""
    return os.path.join(_clean_state_dir(), "last_report_url.txt")


def _reset_clean_state(out_dir, full_clear=False):
    """新扫描完成时重置 clean_state 状态。

    默认 full_clear=False：只把 freed/freed_gb 清零，保留 done/failed/records 让前端呈现
    「上次清理结果」（v3 设计）。但因为用户反馈「都还没动就显示已清理」——本次需求是
    新一次扫描完全清空过去痕迹，所以默认改为 full_clear=True。
    """
    import json
    cs_path = _clean_state_path()
    if not os.path.exists(cs_path):
        legacy = os.path.join(out_dir, "clean_state.json")
        if os.path.exists(legacy):
            cs_path = legacy
        else:
            return
    try:
        with open(cs_path, encoding="utf-8") as f:
            cs = json.load(f)
        changed = False
        for key in ("rm", "migrate"):
            block = cs.get(key)
            if not isinstance(block, dict):
                block = {}
                cs[key] = block
                changed = True
            if full_clear:
                # 完全清空 rm/migrate 的历史痕迹，包括 done/failed/records
                for k in ("done", "failed", "failed_reasons", "records",
                          "freed", "freed_gb", "in_progress", "started_at", "last_update",
                          # AIPC-SETTLE-TRUTH-FIX：旧台账残留的"已校准/已实测"旗帜
                          # 必须一起清。不清 → 新台账里 measured/calibrated 还是上一轮
                          # 的值，渲染层会把上一轮的实测数字当成本轮释放量。
                          # 注意：reboot_pending 不清——那是"还没重启所以没释放"的
                          # 现存事实，不是历史痕迹，清了报告会少算一块。
                          "measured", "settled", "calibrated", "claimed", "claimed_gb",
                          "clamped", "unmeasured", "ts"):
                    if k in block:
                        del block[k]
                        changed = True
                block["freed"] = 0
                block["freed_gb"] = 0.0
                block["measured"] = False
                block["settled"] = False
                block["done"] = []
                block["failed"] = []
                block["failed_reasons"] = {}
                block["records"] = []
            else:
                if block.get("freed", 0) or block.get("freed_gb", 0):
                    block["freed"] = 0
                    block["freed_gb"] = 0.0
                    # 数字清零必须同时撤掉"已实测"旗帜，否则渲染层仍当它是实测值
                    block["measured"] = False
                    block["settled"] = False
                    changed = True
        if changed:
            with open(cs_path, "w", encoding="utf-8") as f:
                json.dump(cs, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _safe_copy(src, dst):
    """容错拷贝：单个文件失败（如被杀软临时锁住）跳过，不中断整体拷贝。"""
    try:
        shutil.copy2(src, dst)
    except Exception:
        pass


def _stage_server_runtime():
    """把 skill 运行时复制到 %APPDATA%/AI_PC_Butler/srv_<ts>/，避免 server 进程锁住 skill 目录。

    核心目的：server.py 被加载后 Python 会持有原 skill 目录的 .py 文件句柄/映射，
    WorkBuddy 卸载 skill 时若该目录被任何后台进程占用就会删除失败。
    把整个 skill 目录复制到临时目录，从临时目录启动 server，原 skill 目录即刻可卸。

    【卸载健壮性关键】拷贝失败时绝不直接回退到原技能目录运行——那样 server.log 等
    写入会锁住原目录导致卸载失败。改用具容错逐文件拷贝重试一次；极端情况仍失败才回退，
    但此时 server.log 已重定向到用户数据目录（见 server.py），不再锁原目录。
    """
    skill_root = os.path.dirname(ROOT)
    # 2026-09-10 P0 修复：统一走 license.get_data_dir()，避免 APPDATA 缺失时目录漂移
    try:
        import license as _lic
        _ddir = _lic.get_data_dir()
    except Exception:
        _base = os.environ.get("APPDATA") or os.path.join(
            os.environ.get("USERPROFILE") or os.path.expanduser("~"), "AppData", "Roaming")
        _ddir = os.path.join(_base, "AI_PC_Butler")
    stamp = time.strftime("%Y%m%d_%H%M%S") + "_" + str(int(time.time() * 1000) % 1000)
    tmp_root = os.path.join(_ddir, "srv_" + stamp)
    try:
        shutil.copytree(
            skill_root,
            tmp_root,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "fresh", ".git"),
            copy_function=_safe_copy,
            dirs_exist_ok=True,
        )
        return tmp_root
    except Exception:
        pass
    # 第一遍失败（如杀软锁文件 / 长路径）：用逐文件容错拷贝再试一次，尽量仍搬离技能目录
    try:
        os.makedirs(tmp_root, exist_ok=True)
        for root, dirs, files in os.walk(skill_root):
            rn = root.replace("/", "\\")
            if "__pycache__" in dirs:
                dirs.remove("__pycache__")
            if ".git" in dirs:
                dirs.remove(".git")
            if rn.endswith("\\fresh") or "\\fresh\\" in rn:
                continue
            rel = os.path.relpath(root, skill_root)
            dest = os.path.join(tmp_root, rel)
            try:
                os.makedirs(dest, exist_ok=True)
            except Exception:
                pass
            for fn in files:
                if fn.endswith(".pyc"):
                    continue
                _safe_copy(os.path.join(root, fn), os.path.join(dest, fn))
        return tmp_root
    except Exception:
        # 极端情况：仍失败才回退原目录，但 server.log 已重定向，不会锁原目录
        return skill_root


def _rmtree_batched(root, batch=10):
    """分批删除一棵目录树，逐个文件删；任何一批被拦/失败都跳过继续下一批。

    【为什么不能直接 shutil.rmtree】实测（2026-10-06 老李真机全流程）：
    一次性 rmtree 一棵 ~98 文件的快照目录，会撞上运行环境的
    「批量删除安全闸」（SAFE_DELETE_BULK_CONFIRM_REQUIRED, count=98 > threshold=50），
    抛出阻断异常。而这段回收代码在 run.py 主流程里 → 异常冒泡 →
    **整个 run.py 挂掉 → 作为子进程的 server 被连带回收 → 报告页永远出不来**。
    也就是说：一个「清自己的旧垃圾」的动作，把「给用户看报告」这件事整个搞瘫了。

    【正确姿态】删自己的垃圾是【低风险可重试】的事：
      · 永远不要因为删不掉就中断主流程（那才是真伤害）；
      · 分批（默认 10 个/批）远低于任何批量安全闸阈值；
      · 删不掉的文件留着，不影响下次运行，也不会假装成功。
    """
    batch = max(1, int(batch))
    deleted = failed = 0
    try:
        for dp, dns, fns in os.walk(root, topdown=False):
            for fn in fns:
                p = os.path.join(dp, fn)
                try:
                    os.remove(p)
                    deleted += 1
                except Exception:
                    failed += 1
            for dn in dns:
                try:
                    os.rmdir(os.path.join(dp, dn))
                except Exception:
                    pass
            if (deleted + failed) % batch == 0:
                pass  # 分批语义：os.remove 本身就是逐个，无需额外 sleep
        try:
            os.rmdir(root)
        except Exception:
            pass
    except Exception:
        pass
    try:
        return not os.path.isdir(root)
    except Exception:
        return True


def _srv_dir_ts(name):
    """AIPC-SRV-PRUNE-FIX2：从快照目录名 srv_YYYYMMDD_HHMMSS_mmm 解析真实创建时间。

    为什么不能用 mtime：快照是 shutil.copytree 复制出来的，目录 mtime 会跟着【源目录】
    走 —— 实测今天新建的 4 个快照 mtime 全是同一个值（skill 目录的最后修改时刻）。
    按 mtime 排序等于乱序，会把正在服役的那一份当成"最旧的"删掉。
    """
    try:
        if not name.startswith("srv_"):
            return 0.0
        parts = name[4:].split("_")
        if len(parts) < 2 or len(parts[0]) != 8 or len(parts[1]) != 6:
            return 0.0
        if not (parts[0].isdigit() and parts[1].isdigit()):
            return 0.0
        return time.mktime(time.strptime(parts[0] + parts[1], "%Y%m%d%H%M%S"))
    except Exception:
        return 0.0


def _pid_alive(pid):
    """AIPC-SRV-PRUNE-FIX2：pid 是否还活着。

    保守原则：**判不出来一律当"活着"**（返回 True）→ 宁可少删一个目录，也绝不误删
    正在服役的 server 那一份。删不掉只是目录多占几十 MB，误删会让报告页当场失效。
    """
    try:
        ipid = int(str(pid).strip())
    except Exception:
        return True
    if ipid <= 0:
        return True
    if os.name != "nt":
        try:
            os.kill(ipid, 0)
            return True
        except Exception:
            return False
    try:
        import ctypes as _ct
        _k = _ct.windll.kernel32
        _h = _k.OpenProcess(0x1000, False, ipid)   # PROCESS_QUERY_LIMITED_INFORMATION
        if not _h:
            return False
        try:
            _code = _ct.c_ulong()
            if not _k.GetExitCodeProcess(_h, _ct.byref(_code)):
                return True
            return int(_code.value) == 259          # STILL_ACTIVE
        finally:
            _k.CloseHandle(_h)
    except Exception:
        return True


def _srv_dir_in_use(d):
    """AIPC-SRV-PRUNE-FIX2：这份快照是否还有 server 在用。"""
    try:
        with open(os.path.join(d, ".aipc_srv_pid"), encoding="utf-8") as _f:
            return _pid_alive(_f.read().strip())
    except Exception:
        return False   # 旧版本留下的快照没有 pid 标记 → 交给后面的"改名探测"把关


def _prune_old_srv_dirs(keep_path, keep_n=2, min_age_sec=7200):
    """AIPC-SRV-PRUNE-FIX：回收历史运行快照 srv_<ts>/，只留最近 keep_n 个。

    为什么要清：_stage_server_runtime 每次运行都把整个运行时复制一份到用户数据目录，
    却从不回收 —— 用户跑得越多、数据目录越大。我们卖的是"帮你清 C 盘"，自己的目录
    反而无限膨胀，说不过去。server 进程正常退出时只清它自己那一份，被沙箱回收或异常
    退出时那份就留下了，所以必须由下一次运行兜底回收。

    三层安全边界（AIPC-SRV-PRUNE-FIX2 加固）：
      1) 只删比 keep_n 更旧的；
      2) 排序和"够不够老"一律用【目录名里的时间戳】，绝不用 mtime（原因见 _srv_dir_ts）；
      3) 删之前必须确认没有 server 还在用它：先看快照里的 .aipc_srv_pid（进程活着就跳过），
         再把目录改名探测（改名成功 = 没被任何进程占用才算干净）。
         旧版本留下的快照没有 pid 标记，额外要求满 24 小时才动。
    删不掉（被占用 / 权限不足）就跳过，绝不因为清理失败影响本次启动。
    """
    try:
        ddir = os.path.dirname(os.path.abspath(keep_path))
        keep_abs = os.path.abspath(keep_path)
        cands = []
        for n in os.listdir(ddir):
            if not n.startswith("srv_"):
                continue
            p = os.path.join(ddir, n)
            if os.path.isdir(p) and os.path.abspath(p) != keep_abs:
                cands.append(p)
        # 按目录名里的真实时间降序（不用 mtime —— 见 _srv_dir_ts 的说明）
        cands.sort(key=lambda p: (_srv_dir_ts(os.path.basename(p)), os.path.basename(p)),
                   reverse=True)
        now = time.time()
        for old in cands[max(0, keep_n - 1):]:
            base = os.path.basename(old)
            ts = _srv_dir_ts(base)
            if ts <= 0:
                continue          # 名字解析不出时间 → 来历不明，保守不删
            # 没有 pid 标记的旧快照：额外要求满 24 小时（无法确认它有没有在被使用）
            need_age = min_age_sec if os.path.isfile(os.path.join(old, ".aipc_srv_pid")) else 86400
            if (now - ts) < need_age:
                continue
            if _srv_dir_in_use(old):
                continue          # 还有 server 在用这份快照 → 绝不误伤
            probe = old + ".__prune"
            try:
                os.rename(old, probe)   # 改名成功 = 目录没被任何进程占用，删才安全
            except Exception:
                continue
            if _rmtree_batched(probe):
                print("   [清理] 已回收历史运行快照 %s" % base, flush=True)
            else:
                # 删不干净就留着，绝不把 probe 名（.__prune）留在原地让人以为有 server 在跑。
                # 这正是 AIPC-SRV-PRUNE-FIX2 改名探测想避免的状态。
                try:
                    os.rename(probe, old)
                except BaseException:
                    pass
    # v1.7.92：这里必须是 BaseException 而不是 Exception。
    # 实测（2026-10-06）运行环境的批量删除安全闸抛出的异常**不是 Exception 子类**，
    # 用 except Exception 接不住 → 会直接冒泡把 run.py 挂掉 → server 被连带回收。
    # 快照回收是纯「锦上添花」的 housekeeping，值 0 风险；任何异常都必须就地吞掉。
    except BaseException:
        pass


def _existing_report_alive():
    """探测是否已经有上一轮 server 在跑且健康可用（端口可达 + 健康查询通过）。

    解决「双浏览器」：run.py 启动前若发现已有 server，直接复用，不开新进程、不再弹浏览器。
    """
    url_file = _report_url_file()
    if not os.path.exists(url_file):
        return None
    try:
        with open(url_file, encoding="utf-8") as _f:
            prev = _f.read().strip()
        if not prev or "://" not in prev:
            return None
        # 解析 host:port 探测端口是否还活着
        from urllib.parse import urlparse as _up
        pr = _up(prev)
        host = pr.hostname or "127.0.0.1"
        port = pr.port
        if not port:
            return None
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            s.connect((host, port))
            s.close()
            return prev
        except Exception:
            try:
                s.close()
            except Exception:
                pass
        # 端口死了 —— 清掉旧 URL，强制重启
        try:
            os.remove(url_file)
        except Exception:
            pass
        return None
    except Exception:
        return None


def _start_report_server(ana_path):
    """启动交互报告服务，返回 Popen 对象。

    v1.7.42（核心架构修复·server 保活）：**移除「server 脱离父进程组」的旗标**。
    原实现让 server 脱离 run.py 的进程组，期望 run.py 退出后 server 继续存活；
    但 WorkBuddy 沙箱会把 run.py 连同它的整个进程树一起清理 → server 死掉 →
    浏览器打开报告后 fetch(/action) 全部 Failed to fetch（一键清/迁移/付款全挂）。

    新实现：server 作为 run.py 的【普通子进程】（不脱离进程组），并且
    main() 结尾【不退出、wait server】。父子同生命周期 → 沙箱无法在 run.py
    存活期间清掉 server → 浏览器交互 100% 可用。server 自带 2 小时 idle
    自动退出，届时 run.py 也随之退出、回收资源。

    【重要】进程仍从临时目录（%TEMP%/AI_PC_Butler/srv_<ts>/）启动，避免锁住
    skill 目录防止卸载失败。server 进程退出（atexit）时自动清理临时目录。
    """
    srv_env = dict(ENV)
    # v1.7.101：删除链路已全量改为 WinAPI 直删（migrate.py _win_delete/_fast_delete_dir），
    # 不依赖任何 Python 层删除接口，因此无需对运行环境做任何特殊处理。
    # v1.7.23：报告展示 = WB 侧边栏，强制禁止 server 自动弹系统浏览器（双保险，与 server.py 默认不弹一致）。
    srv_env["AIPC_NO_BROWSER"] = "1"
    tmp_root = _stage_server_runtime()
    # v1.7.92（2026-10-06 真机实测修）：快照回收**必须放到后台线程**。
    # 原因见 _prune_old_srv_dirs 的 docstring —— 在主进程里删文件会撞上运行环境的
    # 批量删除安全闸（scope="turn"，本轮累计 50 个文件即阻断），异常会冒泡
    # 把整个 run.py 挂掉，server 作为子进程被连带回收，报告页永远出不来。
    # 这里改成 daemon 线程：主流程绝不等待、绝不被牵连；删不掉也只是少回收点垃圾。
    try:
        import threading as _th2
        _th2.Thread(target=_prune_old_srv_dirs, args=(tmp_root,),
                    daemon=True, name="aipc-prune").start()
    except Exception:
        # 连线程都起不来就彻底放弃回收，绝不能因此拦住 server 启动
        pass
    srv_env["AIPC_RUNTIME_DIR"] = tmp_root
    devnull_r = open(os.devnull, "r", encoding="utf-8")
    devnull_w = open(os.devnull, "w", encoding="utf-8")
    kwargs = {
        "stdout": devnull_w,
        "stderr": devnull_w,
        "stdin": devnull_r,
        "close_fds": True,
        "env": srv_env,
    }
    # v1.7.49 修复「13 分钟才出报告」问题（根因见交接文档 v1748）：
    #   真正根因 = run.py 被 Agent 以【前台 Bash】拉起，main() 末尾 proc.wait() 无限等
    #   server → 对话框一直「工具运行中」卡到沙箱超时（约 13 分钟）。
    #   修复 = Agent 改为以【后台任务】拉起 run.py（run_in_background=true）：对话框立即
    #   返回，run.py 常驻后台、proc.wait() 陪 server 一起活着，server 作为普通子进程随
    #   run.py 共存亡，侧边栏报告持续可用。
    #   ⚠️ 本沙箱实测：脱离进程组（DETACHED_PROCESS/CREATE_NEW_PROCESS_GROUP）的子进程
    #   仍会被随父进程树一起回收，故【禁止】加这两个旗标（README 铁律 + 验证脚本硬卡）。
    server_py = os.path.join(tmp_root, "scripts", "server.py")
    proc = subprocess.Popen([PY, server_py, ana_path], **kwargs)
    # AIPC-SRV-PRUNE-FIX2：把 server 的 pid 写进它自己那份快照，作为"这份还在服役"的
    # 权威标记。下一次运行时 _prune_old_srv_dirs 凭它就能确认哪些快照绝对不能删。
    try:
        with open(os.path.join(tmp_root, ".aipc_srv_pid"), "w", encoding="utf-8") as _pf:
            _pf.write(str(proc.pid))
    except Exception:
        pass
    return proc


# 旧的两阶段「FAST 首屏 + 后台 _bg_full_scan 补全」已在 v1.7.42 移除，扫描改为一次到位的完整扫描；
# 对应的辅助函数与 _bg_full_scan.py 已清理，避免误恢复导致重复扫描/孤立进程。


def _report_viewed_file():
    """AIPC-REPORT-OPEN-FIX：报告页是否被真正加载过的标记（server.py 在 GET / 时写入）。"""
    return os.path.join(_clean_state_dir(), "report_viewed.txt")


def _open_in_system_browser(target):
    """AIPC-REPORT-OPEN-FIX：用系统默认程序打开 URL 或本地 HTML。返回是否成功。"""
    try:
        if sys.platform.startswith("win"):
            try:
                os.startfile(target)
                print("（报告已用系统浏览器打开：%s）" % target, flush=True)
                return True
            except Exception:
                pass
        import webbrowser as _wbb
        if _wbb.open(target, new=1, autoraise=True):
            print("（报告已用系统浏览器打开：%s）" % target, flush=True)
            return True
    except Exception:
        pass
    print("[!] 报告自动打开失败，请手动打开下面这个地址：%s" % target, flush=True)
    return False


def _browser_watchdog(target, wait_secs=None):
    """AIPC-REPORT-OPEN-FIX：侧边栏没把报告渲染出来时，自动用系统浏览器兜底打开。

    判定依据 = report_viewed.txt 是否存在（server.py 在报告页被加载时写入）。
    等待 wait_secs 仍无标记 → 侧边栏没打开 → 用系统浏览器打开，保证用户一定看得到报告。
    非阻塞：守护线程执行，不影响 run.py 末尾 wait(server)。
    """
    try:
        if os.environ.get("AIPC_NO_BROWSER") == "1":
            return
    except Exception:
        pass
    if wait_secs is None:
        try:
            # AIPC-BROWSER-WAIT-FIX：这个看守是"侧边栏没打开时用系统浏览器救场"，
            # 不是常规路径。常规路径是 Agent 拿到 REPORT_URL 后 present —— 而 report 服务
            # 就绪时刻通常早于 present 100~200 秒（要等扫描+分析跑完），90 秒的看守会在
            # 侧边栏之前先弹系统浏览器（双开、抢焦点）。实测本机就是这样被提前打开的。
            # 放宽到 240 秒：侧边栏正常时安静退出；真没打开时仍然兜底。
            wait_secs = float(os.environ.get("AIPC_BROWSER_FALLBACK_SECS") or 240)
        except Exception:
            wait_secs = 240.0

    def _worker():
        try:
            vf = _report_viewed_file()
            deadline = time.time() + wait_secs
            while time.time() < deadline:
                try:
                    if os.path.exists(vf):
                        with open(vf, encoding="utf-8") as _f:
                            if _f.read().strip():
                                return  # 侧边栏已渲染报告，无需兜底
                except Exception:
                    pass
                time.sleep(0.5)
            _open_in_system_browser(target)
        except Exception:
            pass

    try:
        import threading as _th
        _th.Thread(target=_worker, daemon=True).start()
    except Exception:
        pass


def _wait_for_report_url(timeout=15):
    """轮询 server.py 写入的 URL 文件，返回可交互报告页地址。"""
    url_file = _report_url_file()
    # AIPC-REPORT-OPEN-FIX：同时清空"报告已被查看"标记，保证兜底看守判的是本次运行。
    try:
        with open(_report_viewed_file(), "w", encoding="utf-8") as _vf:
            _vf.write("")
    except Exception:
        pass
    # 先清空旧 URL，避免读到上一次扫描的残留。
    # v1.7.23（环境无关修复）：os.remove 在部分运行环境可能失败，
    # 导致旧 URL 残留、误读旧端口 → 改为覆盖写空文件，等价且更稳。
    try:
        with open(url_file, "w", encoding="utf-8") as _f:
            _f.write("")
    except Exception:
        pass
    start = time.time()
    while time.time() - start < timeout:
        try:
            if os.path.exists(url_file):
                with open(url_file, encoding="utf-8") as f:
                    url = f.read().strip()
                if url:
                    return url
        except Exception:
            pass
        time.sleep(0.2)
    return None


def _write_min_report(out_dir):
    """最小可用说明报告：连 analysis 都没有时，也要给用户一个能打开的东西。

    AIPC-REPORT-OPEN-FIX（v1.7.66 审查6）。措辞遵循产品基调：不吓人、不甩术语、
    明确回答"我的电脑有没有被改动"和"我该怎么办"。绝不暴露内部路径或报错原文。
    """
    try:
        _p = os.path.join(out_dir, "report_min_%s.html" % TS)
        _html = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>扫描未完成</title>
<style>
 body{margin:0;padding:24px;background:#f6f7f9;color:#1f2328;line-height:1.75;
      font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
 .card{max-width:560px;margin:0 auto;background:#fff;border:1px solid #e6e8eb;border-radius:14px;padding:22px}
 h1{font-size:19px;margin:0 0 12px}
 p{margin:0 0 10px;font-size:14.5px}
 .tip{background:#fff8f0;border:1px solid #ffe0bf;border-radius:10px;padding:12px 14px;font-size:14px}
 ol{margin:8px 0 0 18px;padding:0;font-size:14.5px}
 li{margin:4px 0}
</style></head><body>
<div class="card">
  <h1>这次扫描没能跑完</h1>
  <p>你的电脑没有被改动，也没有删掉任何东西。只是扫描过程被中断了。</p>
  <div class="tip">
    <b>常见原因</b>
    <ol>
      <li>磁盘正被大量读写，扫描超时</li>
      <li>有超大目录或网络映射盘，读取卡住</li>
      <li>杀毒软件临时拦截了扫描程序</li>
    </ol>
  </div>
  <p style="margin-top:14px"><b>怎么办：</b>再让我扫一次就行，通常第二次就能正常跑完。</p>
</div>
</body></html>"""
        with open(_p, "w", encoding="utf-8") as _f:
            _f.write(_html)
        return _p
    except Exception:
        return None


def _rescue_after_failure():
    """AIPC-REPORT-OPEN-FIX（v1.7.66 审查6）：main() 任何非 0 退出时的兜底交付。

    老李的硬要求：任何情况下报告页都要能生成、能在右侧打开，不能出现"任务不结束
    报告也不出现"。原来扫描超时 / 扫描失败 / 分级失败 / 报告生成失败都是 print 一句
    就 sys.exit(1)，用户那边什么也看不到。这里统一兜底：
      ① 优先复用 fresh 下最近一次可用的 analysis 重新出报告；
      ② 都用不上就出一份最小说明报告。
    最后打印 REPORT_FILE=<绝对路径> 供 Agent present；实在没有可交付物才打印
    REPORT_FAILED=，绝不假装成功。
    """
    try:
        _out = os.path.join(ROOT, "..", "fresh")
        _a = sys.argv[1:]
        if "--out" in _a:
            _i = _a.index("--out")
            if _i + 1 < len(_a):
                _out = _a[_i + 1]
        _out = os.path.abspath(_out)
        os.makedirs(_out, exist_ok=True)

        _rep = None
        # ① 复用最近一次可用 analysis（最多试 3 份，覆盖本次半截产物）
        import glob as _g
        _cands = sorted(_g.glob(os.path.join(_out, "analysis*.json")),
                        key=os.path.getmtime, reverse=True)
        for _c in _cands[:3]:
            try:
                _rp = os.path.join(_out, "report_rescue_%s.html" % TS)
                _r = subprocess.run([PY, BUILD, _c, _rp, CONFIG], env=ENV,
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL,
                                    creationflags=_WIN_FLAGS, timeout=120)
                if _r.returncode == 0 and os.path.isfile(_rp):
                    _rep = _rp
                    # AIPC-RESCUE-HONEST-FIX：这份报告用的是【更早一次扫描】的数据，
                    # 必须把数据时间打印出来，让 Agent 能如实告诉用户，绝不冒充本次结果。
                    try:
                        _mt = time.strftime("%Y-%m-%d %H:%M",
                                            time.localtime(os.path.getmtime(_c)))
                        print("RESCUE_SOURCE=%s | 数据时间=%s" % (os.path.abspath(_c), _mt),
                              flush=True)
                    except Exception:
                        pass
                    break
            except Exception:
                continue
        # ② 兜底：最小说明报告
        if not _rep:
            _rep = _write_min_report(_out)

        if _rep and os.path.isfile(_rep):
            print("REPORT_FILE=" + os.path.abspath(_rep), flush=True)
            print("【兜底】本次扫描/分析未跑完，已用可用数据生成报告；"
                  "请立即 present 上面的 REPORT_FILE，在右侧打开给用户看。", flush=True)
            try:
                _browser_watchdog(_rep, wait_secs=30)
            except Exception:
                pass
        else:
            print("REPORT_FAILED=本次未能生成报告。请把上面打印的失败原因如实告诉用户，"
                  "并建议重新扫描一次。", flush=True)
    except Exception:
        print("REPORT_FAILED=兜底交付本身出错。请如实告知用户本次扫描未完成，"
              "并建议重新扫描一次。", flush=True)


def _write_run_marker():
    """AIPC-REPORT-OPEN-FIX-RUNMARK：写下本次运行的启动时刻。

    为什么需要它：run.py 必须以「后台任务」方式启动，并一直挂着保活本地报告服务
    （几小时都不结束），Agent 在它结束前拿不到它的输出 —— 也就拿不到 REPORT_URL、
    不会去 present 报告页，用户在"等报告页"这一步就流失了。
    改由 `open_report.py --print`（前台、秒级返回）从磁盘把地址取回来之后，磁盘上
    可能还留着上一次扫描的地址（那是一个早已退出的死端口）。用 run_ts 当下界，
    只认「晚于本次启动」写下的地址，就能精确区分本次与残留。
    """
    try:
        import json as _jm
        with open(os.path.join(_clean_state_dir(), "report_run.json"),
                  "w", encoding="utf-8") as _f:
            _jm.dump({"run_ts": time.time(), "pid": os.getpid(), "ts": TS}, _f)
    except Exception:
        pass


def main():
    import json as _json
    _t0 = time.time()
    _write_run_marker()
    def _elapsed():
        return "%.1fs" % (time.time() - _t0)

    # v1.7.50（无残留根治·启动兜底）：升级用户从旧版本（v1.7.48 及之前）遗留的孤儿
    # .migrated.bak 卡 C 盘，启动时顺手清理（仅清理 classify 确认安全的）。绝不抛错、
    # 绝不阻塞流水线；懒导入避免拖慢启动。
    try:
        from migrate import auto_cleanup_orphan_baks
        auto_cleanup_orphan_baks()
    except Exception:
        pass

    # ===== v1.7.94：启动时自愈清理「无人引用的 .previous 迁移垃圾」=====
    # 【为什么必须做】本机实测（2026-10-06）：D:\AI_PC_Migrated 下堆了
    # **41.3GB / 18.4 万文件** 的 .previous 垃圾，机制根源是
    # `_clean_previous_asides` 只在**迁移成功之后**才被调用 —— 某一项反复迁移失败
    # （本机的 Tencent 就是，C 盘原路径还不是 junction），每轮都再堆一个 .previous，
    # 永远没人清 → 越攒越多，把目标盘吃干。
    # 对真实用户的后果：目标盘空间被垃圾吃掉，容量闸越来越严，迁移成功率越来越低，
    # 最后「明明有空间却迁不动」。
    #
    # 【安全判据 · 死数据四证，缺一不清】见 migrate._aside_safety：
    #   ① 是工具自己撂下的（名字含 .previous + 同级有主目录）
    #   ② 改名之后再没有任何程序往里写过
    #   ③ 没有任何进程正打开着它
    #   ④ 数据另有副本（C 盘原路径有内容，或 D 盘主目录已取代它）
    #
    # ★ v1.7.95 改判据的缘由（老李实测打脸）：旧判据只认「C 盘原路径已是 junction」，
    #   Tencent 那 5 份（32.9GB）因此被永久判为不能清，D 盘被白白占着 30GB。
    #   而真相是：C 盘 Roaming\Tencent 是**真实目录**、15191 个文件完好在 C 盘、
    #   程序正在用 C 盘 → D 盘那 5 份恰恰是最该清的历史副本。
    #
    # ★ 中途走过的弯路（记下来免得重犯）：曾想用「扩展名像不像用户数据」来判断，
    #   两次实测都被打脸 —— .svg 是企业微信自己的 Flutter 图标、
    #   .msg 是 Tcl 语言包、.png 是 WPS 插件贴图。**看扩展名这条路走不通**，
    #   正确问法是「这份数据是不是已经死了」。
    #
    # ★★ v1.7.94 实测踩坑（我自己犯的错，必须记）：这一段最初写成**同步调用**，
    #   实测 2 分钟都没返回 —— fast_purge 要删 baidu 那份 68,072 个文件，
    #   同步做会把**整个启动流程卡住**，用户看到的就是「双击没反应」。
    #   修法：① 丢进 daemon 线程（与 auto_cleanup_orphan_baks 同款做法）；
    #        ② 首次调用前先做一次 dry_run（约 4 秒，纯统计），把「要清哪些、能不能清」
    #           快速打给用户看，真正删除在后台慢慢做。
    #   教训：**清理类动作一律不许挡在启动主链路上**。
    def _stale_aside_worker():
        try:
            from migrate import auto_cleanup_stale_asides
            _dry = auto_cleanup_stale_asides(dry_run=True)
            if _dry and _dry.get("items"):
                print("发现 %d 项无人引用的迁移临时副本（共约 %.2f GB），正在后台清理…"
                      % (_dry["items"], _dry.get("freed_gb") or 0.0), flush=True)
            _ac = auto_cleanup_stale_asides()
            if _ac and _ac.get("items"):
                print("已清理迁移残留 %.2f GB（无人引用的临时副本，共 %d 项）"
                      % (_ac["freed_kb"] / 1048576.0, _ac.get("items") or 0), flush=True)
        except Exception:
            pass

    try:
        import threading as _th_r
        _th_r.Thread(target=_stale_aside_worker, daemon=True).start()
    except Exception:
        pass

    # ===== v1.7.93：启动时自动接着搬上次卡住的迁移项 =====
    # 老李 2026-10-06 第三条要求：「不能迁移的是不是重启继续迁移还是怎么处理，
    # 必须做到扫描出来的就能够处理」。旧逻辑的回答是「不是」——
    # 卡住就报告失败，要用户自己记住退出软件、再手动点一次迁移。
    # 现在：卡住的项落盘排队（migrate_resume.json），这里自动接着搬完。
    # 之所以放在扫描之前，是因为「上次没搬完的」和「这次扫到的」应该合并成同一批，
    # 否则用户会看到「上次剩 2 项没搬完」却又一份全新报告，永远对不上账。
    # 安全边界：源目录零改动（失败即下一轮）；robocopy /E 增量只补缺失，不重搬。
    try:
        from migrate import resume_pending_migrations, pending_resume_count
        _pend = pending_resume_count()
        if _pend:
            print("发现上次有 %d 项没搬完，正在自动接着搬…" % _pend, flush=True)
            _rs = resume_pending_migrations()
            _rd, _rf = len(_rs.get("done") or []), len(_rs.get("failed") or [])
            if _rd or _rf:
                print("自动续搬：搬完 %d 项，还剩 %d 项下次继续" % (_rd, _rf), flush=True)
    except Exception:
        pass

    out_dir = os.path.join(ROOT, "..", "fresh")
    args = sys.argv[1:]
    if "--out" in args:
        i = args.index("--out")
        if i + 1 < len(args):
            out_dir = args[i + 1]
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    # v1.7.20 报告幂等（目标机问题4：同窗口重复触发导致报告生成 2 次）：
    # 若 3 分钟内刚跑过一次完整流水线（analysis + report 都在），直接复用最新结果，
    # 跳到"启动/复用 server 展示"环节，不重复扫描/分析/生成（省 3 分钟 + 不出第二份）。
    import glob as _glob
    _recent = sorted(_glob.glob(os.path.join(out_dir, "analysis_*.json")), key=os.path.getmtime, reverse=True)
    _reuse = None
    if _recent:
        _newest = _recent[0]
        try:
            _age = time.time() - os.path.getmtime(_newest)
            if _age < 180:  # 3 分钟内
                _base = os.path.basename(_newest)
                _ts = _base[len("analysis_"):-len(".json")]
                _rep = os.path.join(out_dir, "report_%s.html" % _ts)
                if os.path.exists(_rep):
                    _reuse = _newest
        except Exception:
            _reuse = None
    if _reuse:
        ana_out = _reuse
        rep_out = os.path.join(out_dir, "report_%s.html" % os.path.basename(_reuse)[len("analysis_"):-len(".json")])
        print("✅ 检测到 %d 秒内刚完成过扫描，直接打开最新报告（不重复扫描）。" % int(time.time() - os.path.getmtime(_reuse)), flush=True)
        # 跳到 server 展示环节（复用 _existing_report_alive / 启 server）
        _existing_report_alive_check = True
        # 注意：TS 仍用本次时间戳，但不生成新文件，仅用于进度日志命名
    else:
        # v1.7.34（P0 修复）：FAST 首屏 + 后台全量补全，兼顾「首屏快」与「数据全」。
        # 之前 v1.7.24 砍两阶段为单次全量，导致 FAST 模式下迁移深度候选永远缺失；
        # 现在恢复 FAST 首屏（秒级绿区真实数字），FAST 产物文件名带 _fast_ 标记，
        # 由 server /scan_state 的 is_fast（文件名含 _fast_）识别；后台 _bg_full_scan.py
        # 产出不含 _fast_ 的全量 analysis，reload 后前端 pollFullReady 检测 True→False
        # 自动刷新到完整报告（含 find_migratable_deep 深度迁移候选）。
        # v1.7.34（P0 修复-命名一致性）：_fast_on 必须判断 ENV（实际传给子进程的环境），
        # 而非 os.environ（父进程原始环境）。因为 AIPC_FAST 默认值在模块顶部 ENV 里
        # 已设置为 "1"（run.py:38-39），父进程 os.environ 可能没设它。
        # 若用 os.environ 判断：实际是 FAST 扫描（ENV=1），但文件名不带 _fast_ 标记，
        # 导致 server is_fast=False、前端 pollFullReady 不轮询、后台补全不触发，
        # 深度迁移候选依然缺失 —— P0 修复将形同虚设。
        _fast_on = ENV.get("AIPC_FAST") == "1"
        _tag = "_fast_" if _fast_on else "_"
        scan_out = os.path.join(out_dir, "scan%s%s.json" % (_tag, TS))
        ana_out = os.path.join(out_dir, "analysis%s%s.json" % (_tag, TS))
        rep_out = os.path.join(out_dir, "report%s%s.html" % (_tag, TS))

    # 子进程 stdout/stderr 统一丢弃：对话框只保留「用户能看懂的进度提示 + 最终一句引导语」，
    # 不输出扫描原始数据、报告摘要、文件路径、操作建议或任何内部过程文字。
    devnull = open(os.devnull, "w", encoding="utf-8")

    def _say(msg): print(msg, flush=True)

    _perf_log = os.path.join(out_dir, "perf_%s.log" % TS)
    def _perf(label, start_ts=None):
        try:
            with open(_perf_log, "a", encoding="utf-8") as _pf:
                if start_ts is None:
                    _pf.write("%s | %s\n" % (_elapsed(), label))
                else:
                    _pf.write("%s | %s | dur=%.2fs\n" % (_elapsed(), label, time.time() - start_ts))
        except Exception:
            pass

    # 1) 扫描（stdout 落盘为带时间戳文件；stderr 丢弃）
    if _reuse:
        # 幂等复用：3 分钟内已有完整结果，跳过扫描/分析/报告，直接用最新 analysis 展示
        _scan_start = time.time()
        print("✅ 直接复用 %d 秒前的最新报告数据。" % int(time.time() - os.path.getmtime(_reuse)), flush=True)
    else:
        _perf("scan_start")
        _say("[STAGE:scan] 🔍 正在扫描你的 C 盘（只读扫描，不会改动任何文件）…")
        _scan_start = time.time()
        with open(scan_out, "w", encoding="utf-8") as f:
            try:
                r = subprocess.run([PY, SCAN], stdout=f, stderr=devnull,
                                   text=True, env=ENV, creationflags=_WIN_FLAGS, timeout=300)
            except subprocess.TimeoutExpired:
                print("[X] 扫描阶段超时（>300s），请检查磁盘是否有超大盘/网络映射盘")
                sys.exit(1)
        _perf("scan_done", _scan_start)
        print("✅ 扫描完成（用时 %.1fs）" % (time.time() - _scan_start), flush=True)
        if r.returncode != 0:
            print("[X] 扫描失败，查看: %s" % scan_out)
            sys.exit(1)
    # read scan internal timing（复用分支跳过——scan_out 未生成）
    if not _reuse:
        try:
            with open(scan_out, encoding="utf-8") as _sf:
                _sj = _json.load(_sf)
            # scan.py 崩溃时退出码仍是 0，但 stdout 是 {"error":...} —— 必须查内容识别失败
            if isinstance(_sj, dict) and _sj.get("error"):
                print("[X] 扫描失败：%s" % _sj.get("message", _sj.get("error")))
                sys.exit(1)
            _ss = _sj.get("scan_seconds") or _sj.get("_scan_seconds") or 0
            if _ss:
                _perf("scan_internal_seconds=%.1fs" % float(_ss))
        except Exception:
            print("[X] 扫描输出无法解析（可能为空或崩溃）")
            sys.exit(1)

    # 2) 分级聚合 + 3) 重置 clean_state + 4) 出报告（复用分支跳过——不重复分析/生成）
    if not _reuse:
        _perf("analyze_start")
        _analyze_start = time.time()
        _say("[STAGE:analyze] 📊 扫描完成，正在分析可释放空间…")
        _say("[STAGE:analyze] 🧭 正在识别可迁移的大目录（微信 / QQ / 游戏库 / 开发工具等）…")
        try:
            # AIPC-ANALYZE-TIMEOUT-FIX：180s 太紧 —— 实测本机分级稳定在 100~150s，
            # 已用掉 83% 额度，只剩 20~80s 余量；老电脑 / 机械盘 / 杀软实时扫描必然打爆，
            # 一打爆就掉进"用上一次的数据兜底"，用户拿到的不是本次扫描结果。
            # 这里是【真在跑】的等待，不是"让用户假等"——报告页必须由本次数据生成。
            r = subprocess.run([PY, ANALYZE, scan_out, ana_out],
                               stdout=devnull, stderr=devnull, text=True, env=ENV,
                               creationflags=_WIN_FLAGS, timeout=600)
        except subprocess.TimeoutExpired:
            print("[X] 分级阶段超时（>600s），本次未跑完")
            sys.exit(1)
        _perf("analyze_done", _analyze_start)
        print("✅ 分析完成（用时 %.1fs）" % (time.time() - _analyze_start), flush=True)
        if r.returncode != 0:
            print("[X] 分级失败")
            sys.exit(1)

        # 3) 重置 clean_state：每次新扫描都全清，避免上次清理痕迹（「部分已清理」「✓ 已清理」）
        #    跨扫描混在前端导致「我都还没动怎么就显示已清理」。
        _reset_clean_state(out_dir, full_clear=True)

        # 4) 出报告（静态兜底）
        _perf("build_report_start")
        _build_start = time.time()
        _say("[STAGE:report] 📝 正在生成你的专属诊断报告…")
        try:
            r = subprocess.run([PY, BUILD, ana_out, rep_out, CONFIG],
                               stdout=devnull, stderr=devnull, text=True, env=ENV,
                               creationflags=_WIN_FLAGS, timeout=120)
        except subprocess.TimeoutExpired:
            print("[X] 报告生成阶段超时（>120s）")
            sys.exit(1)
        _perf("build_report_done", _build_start)
        print("✅ 报告生成完成（用时 %.1fs）" % (time.time() - _build_start), flush=True)
        if r.returncode != 0:
            print("[X] 报告生成失败")
            sys.exit(1)

    # 5) WB 内单一形态（v1.7.21）：不再弹浏览器、不启动常驻 server。
    #    报告 HTML 由 WorkBuddy 侧边栏展示（present_files），清理/迁移/付款全部在
    #    对话框内通过 skill_tools 函数执行（不走 HTTP / POST /action）。
    #    输出报告绝对路径供 Agent present；保留 run.py 的幂等复用（3 分钟内直接复用最新报告）。
    _perf("server_start")
    _say("[STAGE:ready] 📊 正在启动报告服务…")
    _server_start = time.time()
    # v1.7.22 最终架构：启动本地交互 server，报告页通过 present localhost URL 展示在
    # WB 侧边栏（= 操作台：按钮/进度/付款码全在报告页，不弹系统浏览器、AI 只做引导）。
    proc = _start_report_server(ana_out)
    # v1.7.40（报告交付修复）：超时从 15s 提到 30s——极少数杀软/慢盘冷启动可超 15s，
    # 避免「服务其实起了、只是写 URL 稍慢」被误判成静态兜底。正常机器 <1s 即返回，无感。
    _url = _wait_for_report_url(timeout=30)
    if _url:
        print("REPORT_URL=" + _url, flush=True)
        # v1.7.40（报告交付修复·权威提示）：REPORT_URL 是权威交互页，AI 必须直接 present，
        # 严禁在 Agent 沙箱内 curl/urllib 自验 localhost（必然 HTTP 000 假警报 → 误降级静态）。
        print("【权威】请立即用 present_files 展示上面的 REPORT_URL（即 WB 侧边栏交互操作台），"
              "不要用 curl/浏览器在沙箱内验证它（必然连不上，属假警报）；仅当本行缺失时才用 REPORT_FILE 静态兜底。",
              flush=True)
        print("✅ 报告已就绪（在 WorkBuddy 侧边栏操作）。", flush=True)
        # v1.7.40（浏览器控制）：WorkBuddy 侧边栏是报告页唯一入口，run.py 不再主动弹系统浏览器，
        # 避免与 present_files 侧边栏展示冲突。仅在命令行调试时显式设置 AIPC_OPEN_BROWSER=1 才打开浏览器。
        try:
            import os as _os
            if _os.environ.get("AIPC_OPEN_BROWSER") == "1":
                import webbrowser as _wb
                _opened = False
                try:
                    _os.startfile(_url)  # Windows 最可靠，等同用户双击链接
                    _opened = True
                except Exception:
                    _opened = _wb.open(_url, new=1, autoraise=True)
                if _opened:
                    print("（已用系统浏览器打开交互报告页）", flush=True)
        except Exception:
            pass
        # AIPC-REPORT-OPEN-FIX（v1.7.65 要求2）：启动浏览器兜底看守。
        # 侧边栏正常情况下会加载报告页（写 report_viewed.txt）→ 看守静默退出、不弹浏览器；
        # 若侧边栏打不开（无人加载）→ 等待期到点后自动用系统浏览器打开，保证报告一定可见。
        try:
            if os.environ.get("AIPC_OPEN_BROWSER") != "1":
                _browser_watchdog(_url)
        except Exception:
            pass
        # v1.7.42（一次到位）：不再用 FAST 首屏 + 后台补全两阶段。
        # 用户明确要求「一次到位」——报告生成时就包含完整扫描结果（含深度迁移候选），
        # 不弹「后台正在补全」、不让用户等第二次。run.py 本次就是完整扫描（见下方
        # ENV 处理：AIPC_FAST 不再强制为 1，走全量），因此不再 spawn _bg_full_scan.py。
    else:
        # 兜底：server 启动失败时退化为静态报告 present（只读展示）
        print("REPORT_FILE=" + rep_out, flush=True)
        print("✅ 报告已生成（静态模式，请在对话框告诉我操作）。", flush=True)
        # AIPC-REPORT-OPEN-FIX（v1.7.65 要求2）：静态模式同样看守——侧边栏没展示时
        # 自动用系统浏览器打开这份 HTML，保证"任何情况下报告都能打开"。
        try:
            _browser_watchdog(rep_out, wait_secs=30)
        except Exception:
            pass
    _perf("server_ready", _server_start)

    _perf("pipeline_total_done")

    # 6) v1.7.42（核心架构修复·server 保活）：run.py 不退出，wait server。
    #    - server 是 run.py 的普通子进程（_start_report_server 已去掉 DETACHED_PROCESS），
    #      父进程活着 → 子进程活着 → 沙箱清不掉 → 浏览器交互报告 100% 可用。
    #    - server 自带 2 小时 idle 自动退出；退出后 run.py 随之结束，回收资源。
    #    - 期间浏览器已由上方 os.startfile 兜底打开，用户全程在浏览器操作台操作。
    if _url and proc is not None:
        try:
            # AIPC-REPORT-OPEN-FIX（v1.7.66 审查6）：硬上限，保证"任务一定有终点"。
            # 正常路径由 server 自身的空闲回收先退出（默认 2 小时无请求）；
            # 这里再加一道 4 小时硬上限，覆盖 server 卡死 / 线程异常等极端情形 ——
            # 绝不能出现"任务在后台永远挂着、用户以为还在跑"。
            proc.wait(timeout=14400)
        except subprocess.TimeoutExpired:
            try:
                proc.terminate()
            except Exception:
                pass
        except KeyboardInterrupt:
            try:
                proc.terminate()
            except Exception:
                pass
        except Exception:
            pass


if __name__ == "__main__":
    # AIPC-REPORT-OPEN-FIX（v1.7.66 审查6）：包一层兜底 —— main() 里任何一处
    # sys.exit(非0)（扫描超时/失败、分级失败、报告生成失败…）都不再是"静默退出、
    # 报告永不出现"，而是尽力交付一份能打开的报告后再退出。
    try:
        main()
    except SystemExit as _se:
        if getattr(_se, "code", 0) not in (0, None):
            _rescue_after_failure()
        raise
