# 精确清理 C盘清理 迁移残留的回收站条目。
# 只删 recycle_pending.json 里记录的 $R/$I（即本程序迁移产生的临时备份），
# 绝不碰用户回收站里其他的（用户自己删除的）文件。删不掉的（被锁）留在清单，
# 下次登录再重试，直至彻底清空。
#
# 删除走 .NET 原生 API（与 migrate.py 的 WinAPI 同源，杀软/安全软件不拦、无系统对话框），
# 比 PowerShell Remove-Item 更稳、行为更可预期。
$p = Join-Path $env:LOCALAPPDATA 'AI_PC_Butler\recycle_pending.json'
if (-not (Test-Path $p)) { exit 0 }
try { $raw = Get-Content $p -Raw | ConvertFrom-Json } catch { exit 0 }

# ConvertFrom-Json 在管道里把 JSON 数组作为【单个对象】输出，需手动扁平化，
# 否则 $it 会变成“数组的数组”，无法正确逐个删。
$flat = @()
if ($raw -is [System.Array]) {
    foreach ($e in $raw) {
        if ($e -is [System.Array]) { $flat += $e } else { $flat += $e }
    }
} else { $flat += $raw }

$fail = @()
foreach ($it in $flat) {
    try {
        if ([System.IO.Directory]::Exists($it)) {
            [System.IO.Directory]::Delete($it, $true)
        } elseif ([System.IO.File]::Exists($it)) {
            [System.IO.File]::Delete($it)
        }
    } catch { }
    # 复核：仍在 = 真没删掉（被锁），留待下次登录重试；已不在 = 成功，不计入 fail。
    if ((Test-Path $it)) { $fail += $it }
}
try {
    if ($fail.Count -gt 0) {
        $fail | ConvertTo-Json -Compress | Set-Content $p -Force
    } else {
        try { [System.IO.File]::Delete($p) } catch { }
    }
} catch { }
exit 0
