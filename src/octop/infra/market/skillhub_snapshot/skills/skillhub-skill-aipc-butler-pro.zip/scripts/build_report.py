#!/usr/bin/env python3
# 🔥 项目基因：改本流水线前必读 ai-pc-butler/.workbuddy/memory/MEMORY.md（六条铁律+踩坑档案）
"""Inject an analysis JSON into the HTML template -> a standalone report.

Usage:
    build_report.py <analysis.json> [output.html] [config.json] [explanations.json]

The analysis JSON is produced by Claude after interpreting scan.py output.
config.json (optional) carries brand / fingerprint / version
for the anti-theft 锁1+锁2 (see 交付架构-防抄袭方案.md). Missing => DEMO defaults.
Schema (all sections optional except system):

{
  "generated_at": "2026-05-28 12:00:00",
  "scan_seconds": 42.1,
  "system": {os, build, arch, user, home, filesystem,
             disk_total, disk_used, disk_free, purgeable},
  "top5": [{rank, tier(green|yellow|red), size, type, name, path, note}],
  "green":  [{name, path, size_estimate, kill_processes:[], trash_paths:[...], commands:[{label,cmd}]}],
  "yellow": [{name, path, size, content_profile, why_manual, disposal, risk, trash_paths:[...]?, open_note?}],
  "red":    [{name, path, size, why_keep, indirect_release, auto_reclaim, app_paths:[...]?}],
  "denied": ["/path/one", ...],
  "summary": {overview, tier_stats:{green,yellow,red}, priority:[...], long_term:[...]}
}
"""
import json
import os
import sys
import time  # AIPC-JUNCSCAN-CACHE-FIX：缓存 TTL 判定用

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)  # 允许 import 同目录 license.py
TEMPLATE = os.path.join(HERE, "..", "assets", "report_template.html")


# 锁1+锁2 默认值：未提供 config 时打印 DEMO 占位，避免裸奔
DEFAULTS = {
    "app_name": "C盘清理 · 腾讯 WorkBuddy 驱动",
    "fingerprint": "DEMO-未授权",
    "version": "v1.7.36-DEMO",
}


def load_config(path):
    cfg = dict(DEFAULTS)
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    return cfg


def _set_llm_explain(item, m):
    fid = (item.get("llm_facts") or {}).get("id")
    if fid and fid in m and m[fid]:
        item["llm_explain"] = m[fid]


def apply_explanations(data, expl_map):
    """把 Agent 生成的 LLM 人话说明（{id: text}）回写到黄区项。

    缺失 id / 解析为空 / expl_map 为空都安全跳过，保留规则说明兜底——绝不报错。
    覆盖黄区顶层子项与其智能钻取出的子项（都是用户会展开决策的点）。
    """
    if not expl_map:
        return
    for cat in (data.get("yellow") or []):
        for child in (cat.get("top_children") or []):
            _set_llm_explain(child, expl_map)
            sc = child.get("smart_scan") or {}
            for sub in (sc.get("unknown_children") or []):
                _set_llm_explain(sub, expl_map)


def _kb_to_h(kb):
    """与 analyze.kb_to_h 完全一致的展示格式，供过滤后重算 reclaim_h 复用。"""
    if kb >= 1024 * 1024:
        return "%.1f GB" % (kb / 1024 / 1024)
    if kb >= 1024:
        return "%.1f MB" % (kb / 1024)
    return "%.0f KB" % kb


def _filter_migrated(data):
    """生成报告时剔除「已迁移(junction)」的幽灵迁移项，与 server.py 渲染层双保险。

    仅判定 NTFS reparse point（数据实际已在 D:，逻辑路径仍挂 C: 下），不跟随链接。
    复用 migrate._under_junction，导入失败则安全降级为不过滤（绝不阻塞报告生成）。
    同时重算 migration 区块 reclaim_kb / reclaim_h，避免「列表少了但顶部数字没少」。
    """
    try:
        from migrate import _under_junction
    except Exception:
        return data

    mb = data.get("migration") or {}
    if not isinstance(mb, dict):
        return data

    plan = mb.get("plan") or []
    if plan:
        kept = [p for p in plan if not _under_junction(p.get("src") or "")]
        if len(kept) != len(plan):
            mb["plan"] = kept
            kb = sum(float(p.get("size_kb", 0) or 0) for p in kept)
            mb["reclaim_kb"] = kb
            mb["reclaim_h"] = _kb_to_h(kb)

    cands = mb.get("candidates") or []
    if cands:
        mb["candidates"] = [c for c in cands
                            if not _under_junction(c.get("path") or c.get("src") or "")]
    return data


def _measured_reboot_kb():
    """上一次真实清理中「需重启才释放」的实测残留（KB）。<!-- AIPC-RELEASE-RANGE-TRUTH-FIX -->

    数据源 = 本机清理台账 clean_state.json 的 rm.reboot_pending.bytes ——
    这是清理时逐文件登记下来的「文件被占用、已安排重启删除」的真实字节数。
    没有台账 / 台账里没这一项（= 还从没清理过）→ 返回 (0.0, False)，
    调用方据此走「不虚构数字」分支。绝不在这里造一个比例去估。
    """
    try:
        import json
        with open(_clean_state_path(), encoding="utf-8") as _f:
            cs = json.load(_f)
        rb = ((cs.get("rm") or {}).get("reboot_pending") or {})
        b = float(rb.get("bytes") or 0)
        if b > 0:
            return (b / 1024.0, True)
    except Exception:
        pass
    return 0.0, False


def _inject_release_range(data):
    """v1.7.8: release range self-consistent with "2-step reclaim X GB".

    floor = green*(1-12%) + reclaim_kb  (conservative min, immediately free-able)
    ceil  = green + total_reclaim_kb      (= page proReclaim, max possible)
    gap   = ceil - floor                  (needs reboot / free D space / disable AV)

    Uses section-level aggregates (reclaim_kb / total_reclaim_kb) instead of
    per-plan-item classify_lock to avoid size_kb sum != reclaim_kb mismatch.
    """
    green = data.get("green") or []
    green_kb = sum(float(g.get("kb", 0) or 0) for g in green)
    mb = data.get("migration") or {}
    plan = mb.get("plan") or []
    # AIPC-RELEASE-RANGE-TRUTH-FIX：保底值的扣减**只用实测**。
    # 上一版写死 12% 估出「需重启后才能释放」的量，并在报告里写成「约 X GB」——
    # 那个数是编的，不是量出来的。现在：
    #   ① 台账里有实测残留（上次真实清理登记的重启删除量）→ 用实测值；
    #   ② 没有实测（新用户第一次扫描，绝大多数情况）→ 扣减 0，且报告里不再出现
    #      任何「需重启释放 X GB」的具体数字。
    # 保底/上限区间本身保留（它表达「保守—乐观」的范围），只是不再虚构分量。
    green_reboot_est, _rr_measured = _measured_reboot_kb()

    # v1.7.8: use section-level aggregates for self-consistency with proReclaim
    reclaim_kb = float(mb.get("reclaim_kb") or 0)
    total_reclaim_kb = float(mb.get("total_reclaim_kb") or reclaim_kb)
    floor_kb = (green_kb - green_reboot_est) + reclaim_kb
    ceil_kb = green_kb + total_reclaim_kb
    gap_kb = ceil_kb - floor_kb
    gap_items = []
    if green_reboot_est > 0:
        gap_items.append(
            "上次清理时被程序占用的缓存（约 %.1f GB，实测）需重启后才释放"
            % (green_reboot_est / 1048576))
    if total_reclaim_kb > reclaim_kb and (total_reclaim_kb - reclaim_kb) > 104857:
        dg = (total_reclaim_kb - reclaim_kb) / 1048576
        gap_items.append(
            "部分迁移因目标盘空间不足暂缓（约 %.1f GB，请先释放 D 盘空间）" % dg)
    for p in plan:
        # v1.7.36（审查修复）：数据源字段是 "type"（migrate.classify_lock 返回
        # 'av_kernel'），此前误用 "block_type" 导致杀软内核锁拦截提示永不生效。
        # 兼容两种字段名，避免未来字段变化再踩坑。
        if p.get("type") == "av_kernel" or p.get("block_type") == "av_kernel":
            nm = p.get("display_name") or p.get("name") or ""
            if nm and nm not in gap_items:
                gap_items.append(nm)
    data["release_range"] = {
        "floor_kb": floor_kb,
        "ceil_kb": ceil_kb,
        "gap_kb": gap_kb,
        "gap_items": gap_items,
        "floor_h": _kb_to_h(floor_kb),
        "ceil_h": _kb_to_h(ceil_kb),
        "gap_h": _kb_to_h(gap_kb),
        "includes_reboot_cleanable": green_kb > 0,
        }
    return data


def _scan_migrated_junctions():
    """A：当 clean_state 缺失时，扫描用户目录下所有指向『AI_PC_Migrated』的 junction，
    构造『已迁移项』records（数据以真实磁盘为准，不凭印象造假）。只扫描、不递归进目标盘。

    ⚠️ 健壮性（v1.7.14 修复 20 分钟卡死根因）：本函数仅用于报告页『已迁移记录』展示，
    属非必需增强，绝不允许阻塞出报告。旧实现无任何时间预算，真机大用户目录 / 慢 D 盘 /
    OneDrive 云文件（文件按需占位会触发云拉取，每次 lstat/readlink 都走网络）下可卡 20 分钟+。
    现加硬时间预算（_DEADLINE_SEC）+ 逐目录 entry 上限 + 跳过云同步目录 + 体积估算仅下钻 2 层，
    超预算立即返回已收集结果（可能为空），保证出报告始终在数秒内完成。
    """
    import time as _time
    recs = []
    _DEADLINE_SEC = 8.0           # 整体硬预算：8 秒，超出立即返回
    _PER_WALK_ENTRIES = 20000     # 单根 walk entry 上限，防单目录爆炸
    _SIZE_WALK_DEPTH = 2          # 体积估算只下钻 2 层（粗估足够，避免遍历整个目标盘）
    _deadline = _time.time() + _DEADLINE_SEC
    # 云同步 / 已知超慢目录：跳过，避免网络挂载点 stall（OneDrive 文件按需占位会触发云拉取）
    _SKIP_DIRS = {"onedrive", "dropbox", "google drive", "googledrive",
                  "iclouddrive", "nextcloud", "坚果云", "jianguoyun"}
    try:
        import os as _os
        HOME = _os.path.expanduser("~")
        base_depth = HOME.count(_os.sep)
        for root, dirs, files in _os.walk(HOME):
            if _time.time() > _deadline:
                break
            if root.count(_os.sep) - base_depth > 6:
                dirs[:] = []
                continue
            # 原地剪枝超慢云目录，os.walk 不再下钻（避免网络 stall）
            for d in list(dirs):
                if d.lower() in _SKIP_DIRS:
                    dirs.remove(d)
            _entries = 0
            for d in list(dirs):
                if _time.time() > _deadline:
                    break
                dp = _os.path.join(root, d)
                try:
                    st = _os.lstat(dp)
                    if not (getattr(st, "st_file_attributes", 0) & 0x400):
                        continue
                    target = _os.readlink(dp)
                    if "AI_PC_Migrated" not in target:
                        dirs.remove(d)  # 非产品迁移 junction，不递归
                        continue
                    # 推断真实体积：仅粗估（下钻 _SIZE_WALK_DEPTH 层 + entry 上限），不遍历整个目标盘
                    kb = 0
                    try:
                        _sd = target.count(_os.sep)
                        for _dp, _dn, _fn in _os.walk(target):
                            _entries += 1
                            if _entries > _PER_WALK_ENTRIES:
                                break
                            if _dp.count(_os.sep) - _sd > _SIZE_WALK_DEPTH:
                                _dn[:] = []
                                continue
                            for _f in _fn:
                                try:
                                    kb += _os.path.getsize(_os.path.join(_dp, _f))
                                except Exception:
                                    pass
                    except Exception:
                        pass
                    kb = kb / 1024.0
                    ts = 0
                    try:
                        ts = int(_os.path.getmtime(dp))
                    except Exception:
                        pass
                    recs.append({
                        "src": dp, "dst": target, "kb": kb,
                        "ok": True, "ts": ts, "auto_inferred": True,
                    })
                    dirs.remove(d)  # 已记录，不递归进 D 盘目标
                except Exception:
                    continue
            if _time.time() > _deadline:
                break
    except Exception:
        pass
    return recs


# ── AIPC-JUNCSCAN-CACHE-FIX ───────────────────────────────────────────────
# 病根（2026-09-16 实测，非推断）：_scan_migrated_junctions 每次都要从用户目录
# 递归整棵树找 junction。真机剖面：os.walk 18750 次、lstat 20260 次、readlink 1426 次，
# 8 秒预算【跑满】，扫出的却是空数组 —— 于是每次打开报告页都白等 8 秒。
# 而它只在 clean_state 里没有迁移记录时才被调用，也就是绝大多数没迁过的用户，
# 每次打开报告页都要白等这 8 秒。同一状态下扫一次就够，缓存掉。
# 失效锚 = clean_state.json 的 mtime(ns)：迁移动作必然改写它 → 锚变 → 自动重扫，
# 因此「刚迁完」的用户看到的永远是最新事实，功能一点不打折。
_JUNCSCAN_TTL_SEC = 6 * 3600


def _juncscan_cache_path():
    """扫描结果缓存文件路径 —— 与 clean_state.json 同在一个用户数据目录。"""
    try:
        return os.path.join(os.path.dirname(_clean_state_path()), "junc_scan_cache.json")
    except Exception:
        return ""


def _juncscan_anchor():
    """失效锚 = clean_state.json 的 mtime(ns)；文件不存在记 0。

    为什么用它当锚：迁移动作一定会写 clean_state.json（记录已迁项），锚随之改变，
    缓存立刻失效去重扫 —— 保证「刚迁完」的用户看到的永远是最新事实。
    """
    try:
        return int(os.stat(_clean_state_path()).st_mtime_ns)
    except Exception:
        return 0


def _juncscan_cached(anchor):
    """读缓存。命中返回 records 列表（可能是空列表 —— 空结果也必须缓存，
    那才是省掉 8 秒等待的关键）；未命中/已过期/锚变了返回 None（调用方去真扫）。"""
    p = _juncscan_cache_path()
    if not p or not os.path.isfile(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            o = json.load(f) or {}
        if int(o.get("anchor", -1)) != int(anchor):
            return None                      # clean_state 变过（刚迁移过）→ 必须重扫
        if time.time() - float(o.get("ts", 0) or 0) > _JUNCSCAN_TTL_SEC:
            return None                      # 过期兜底（用户可能手工建过 junction）
        recs = o.get("recs")
        return recs if isinstance(recs, list) else None
    except Exception:
        return None


def _juncscan_store(anchor, recs):
    """写缓存。先写临时文件再 os.replace 原子替换，避免读到半截文件。
    纯优化：任何失败都不影响出报告，绝不阻塞主流程。"""
    p = _juncscan_cache_path()
    if not p:
        return
    try:
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "anchor": int(anchor), "recs": recs},
                      f, ensure_ascii=False)
        os.replace(tmp, p)
    except Exception:
        pass


def _clean_state_path():
    """迁移/清理状态稳定路径（与 license.json 同处一个用户数据目录），
    优先于 analysis 同目录的旧路径，保证记录跨扫描持久存在。

    2026-09-10 P0 修复：统一委托 license.get_data_dir()，避免 APPDATA 缺失时
    数据目录漂移，造成"激活过却要重新付费 / 迁移记录丢失"。
    """
    try:
        import license as _lic
        d = _lic.get_data_dir()
    except Exception:
        base = os.environ.get("APPDATA") or os.path.join(
            os.environ.get("USERPROFILE") or os.path.expanduser("~"), "AppData", "Roaming")
        d = os.path.join(base, "AI_PC_Butler")
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            pass
    return os.path.join(d, "clean_state.json")


def _clean_state_legacy_path(src):
    return os.path.join(os.path.dirname(os.path.abspath(src)), "clean_state.json")


def _last_resort_license():
    """AIPC-LIC-HWM：与 license 模块解耦的最后一层授权兜底（只读）。

    license 模块不可用（导入失败/异常）时，直接在各候选用户目录里找
    license_hwm.json / license.json，取 tier 最高的一份（要求 tier>=1）。
    目的只有一个：不让"读不到"直接等价于"没付费"。找不到返回 None。
    """
    home = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    cands = []
    for _b in (os.environ.get("APPDATA"),
               os.path.join(home, "AppData", "Roaming"),
               os.environ.get("LOCALAPPDATA"),
               home):
        if _b:
            _p2 = os.path.join(_b, "AI_PC_Butler")
            if _p2 not in cands:
                cands.append(_p2)
    best = None
    for _d in cands:
        for _n in ("license_hwm.json", "license.json"):
            _p = os.path.join(_d, _n)
            if not os.path.isfile(_p):
                continue
            try:
                with open(_p, "r", encoding="utf-8") as _f:
                    _o = json.load(_f)
                if not isinstance(_o, dict):
                    continue
                _t = int(_o.get("tier", 0) or 0)
            except Exception:
                continue
            if _t < 1:
                continue
            if best is None or _t > int(best.get("tier", 0) or 0):
                best = {"tier": _t, "active": True, "exp": 0,
                        "version": _o.get("version", ""), "hwid": _o.get("hwid", "")}
    return best


def _is_admin():
    """检测当前进程是否以管理员权限运行（与 server.py 保持一致）。

    v1.7.32 修复：静态报告此前写死 __IS_ADMIN_VALUE__="false"，导致无论用户是否
    管理员都显示「🔐 需要管理员权限」提示，误导用户。现改为运行时实时检测。"""
    try:
        if sys.platform.startswith("win"):
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        return os.geteuid() == 0
    except Exception:
        return False


def _release_cap_gb(src=None):
    """AIPC-FREED-DEDUP-FIX（渲染期兜底）：本次释放量的物理上限（GB）。

    = 这块盘已用空间。释放量在物理上不可能比它更多。真机出现过 120GB 的盘
    显示「本次释放 258.7GB」，必须有一道在数字进入用户视野前拦住。
    取「实测已用 / 扫描时已用 / 盘总容量」三者的最小值（保守，绝不放行超限值）。
    拿不到 → 返回 0，调用方跳过夹取（宁可不夹，也不制造新错误）。
    """
    _cands = []
    try:
        _di = (json.load(open(src, encoding="utf-8")).get("disk_info") or {}) if src else {}
        for _k in ("used_gb", "total_gb"):
            _v = float(_di.get(_k) or 0)
            if _v > 0:
                _cands.append(_v)
    except Exception:
        pass
    try:
        import shutil as _sh3
        _cands.append(_sh3.disk_usage("C:").used / 1073741824.0)
    except Exception:
        pass
    return min(_cands) if _cands else 0.0


def _clamp_release_json(_s, src=None):
    """把 clean_state JSON 里的释放量夹到物理上限以内后返回（已转义 </）。"""
    try:
        if not _s:
            return _s
        _cap = _release_cap_gb(src)
        if _cap <= 0:
            return _s
        _o = json.loads(_s)
        if not isinstance(_o, dict):
            return _s
        _hit = []
        for _k in ("rm", "migrate"):
            _b = _o.get(_k)
            if not isinstance(_b, dict):
                continue
            # AIPC-SETTLE-TRUTH-FIX（第 4 道）：没有磁盘实测就【不许】把任何数字
            # 渲染成"已释放"。旧台账里可能残留标称估算（真机 258.73GB 就是这么
            # 进到用户眼前的）。无实测 → 归零 + 打 unmeasured，前端据此说明未测到。
            # AIPC-SETTLE-TRUTH-FIX（收紧）：只有**显式** measured=true 才算实测。
            # 曾经用「calibrated 且 freed_gb>0」当兼容判据 —— 那是错的：真机
            # clean_state.json 里 calibrated=true 与 freed_gb=258.73 同时存在过
            # （run.py 重置只删 freed 不删 calibrated，孤儿旗帜留了下来），
            # 判据一命中就去走"夹到上限"，把假的 258.73 夹成假的 102.50 放行。
            # 判据一放宽 = 假数据就有第二条活路，所以这里只认显式实测。
            _meas = (_b.get("measured") is True)
            if not _meas:
                if float(_b.get("freed_gb") or 0) > 0:
                    _hit.append("%s 无实测->0（原 %.2f）" % (_k, float(_b.get("freed_gb") or 0)))
                    _b["freed_gb"] = 0.0
                    _b["freed"] = 0
                    _b["unmeasured"] = True
                # 标"未实测"必须同时把 measured 落成 False：前端/报告页统一按
                # measured 判断是否显示数字，只给 unmeasured 会让页面停在旧数字上。
                _b["measured"] = False
                continue
            try:
                _g = float(_b.get("freed_gb") or 0)
            except Exception:
                _g = 0.0
            if _g > _cap:
                _hit.append("%s %.2f->%.2f" % (_k, _g, _cap))
                _b["freed_gb"] = round(_cap, 2)
                _b["clamped"] = True
                try:
                    _b["freed"] = int(_cap * 1073741824)
                except Exception:
                    pass
        if _hit:
            sys.stderr.write("[build_report] render clamp release: cap=%.2f GB, %s\n"
                             % (_cap, "; ".join(_hit)))
        return json.dumps(_o, ensure_ascii=False).replace("</", "<\\/")
    except Exception:
        return _s


def _build_clean_state_blob(src, raw_plan):
    """构造注入报告的 clean_state 数据（JSON 字符串，已转义 </）。

    修复「每次扫描迁移记录为空」的根因三：
    - 优先读取稳定路径的 clean_state.json（server 交互产生，含迁移时间/细节/状态）。
    - 回退读取 src 同目录（旧路径）的 clean_state.json。
    - 若都缺失或 migrate.records 为空，则从磁盘 junction 自动推断「已迁移项」注入，
      保证 static 报告也能展示（数据以真实磁盘 junction 为准，不凭印象造假）。
    """
    cs = {}
    cs_path = _clean_state_path()
    if not os.path.exists(cs_path):
        legacy = _clean_state_legacy_path(src)
        if os.path.exists(legacy):
            cs_path = legacy
    if os.path.exists(cs_path):
        try:
            with open(cs_path, encoding="utf-8") as f:
                cs = json.load(f) or {}
        except Exception:
            cs = {}
    recs = (((cs.get("migrate") or {}).get("records")) or []) if isinstance(cs, dict) else []
    if not recs:
        try:
            inferred = []
            # 优先从分析 plan 里捕获已 junction 的项（若扫描仍纳入）；否则扫描真实磁盘 junction
            try:
                from migrate import _under_junction
                for p in (raw_plan or []):
                    s = p.get("src") or ""
                    if s and _under_junction(s):
                        inferred.append({
                            "src": s,
                            "dst": p.get("dst") or "",
                            "kb": float(p.get("size_kb", 0) or 0),
                            "ok": True,
                            "ts": 0,
                            "auto_inferred": True,
                        })
            except Exception:
                pass
            if not inferred:
                # AIPC-JUNCSCAN-CACHE-FIX：同一状态下只真扫一次 ——
                # 缓存命中（含"上次扫出来是空"）直接复用，不再每次打开报告页白等 8 秒。
                _anchor = _juncscan_anchor()
                _hit = _juncscan_cached(_anchor)
                if _hit is None:
                    _hit = _scan_migrated_junctions()
                    _juncscan_store(_anchor, _hit)
                inferred = _hit
            if inferred:
                cs.setdefault("migrate", {})["records"] = inferred
        except Exception:
            pass
    # D：对「已安排重启」的迁移项，若磁盘上 src 已是 junction（说明重启已完成），
    # 动态标记为已完成（仅注入副本，不写回 clean_state.json）。
    try:
        from migrate import _under_junction
        _mg = cs.get("migrate") or {}
        for _r in (_mg.get("records") or []):
            if _r.get("reboot_commit") and not _r.get("reboot_done") and _r.get("src"):
                if _under_junction(_r.get("src")):
                    _r["reboot_done"] = True
    except Exception:
        pass
    return json.dumps(cs, ensure_ascii=False).replace("</", "<\\/")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    src = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.expanduser(
        "~/Desktop/storage-report.html")
    cfg = load_config(sys.argv[3] if len(sys.argv) > 3 else None)

    with open(src, "r", encoding="utf-8") as f:
        data = json.load(f)

    # v1.7.32：黄区整体删除（产品形态）。报告页只渲染「一键清 + 迁移」两区，
    # 不再向报告注入黄区判定数据（scan 不再产出黄区）。server.py/license.py 的回收站删除能力
    # 保持不变（红区红线），仅报告渲染层不再展示黄区。
    data["yellow"] = []

    # 人话说明机制：可选第 4 参数 explanations.json（{id: 说明}），由 Agent 用当前模型生成。
    # 缺失或解析失败都安全跳过，保留规则说明兜底——不阻塞、不报错（见 SKILL.md 第 2.5 步）。
    expl_map = {}
    if len(sys.argv) > 4 and os.path.exists(sys.argv[4]):
        try:
            with open(sys.argv[4], "r", encoding="utf-8") as _ef:
                expl_map = json.load(_ef) or {}
        except Exception:
            expl_map = {}
    apply_explanations(data, expl_map)

    # 保存过滤前的迁移 plan（含已 junction 的幽灵项），供下方选项 A 注入「已迁移记录」使用。
    # _filter_migrated 会把 junction 项从 plan 移除，故须在此之前留存原始 plan。
    raw_plan = list(((data.get("migration") or {}).get("plan") or []))

    # ── 选项 B：剔除已迁移(junction)幽灵项，与 server.py 渲染层双保险（见 _filter_migrated）──
    data = _filter_migrated(data)

    # ── 释放区间：按真实锁探测算保底/上限/差距，注入 release_range（产品哲学转向）──
    data = _inject_release_range(data)

    # ── 选项 A：迁移卡片明细「整树 X（含可清理缓存 Y · 净用户数据 Z）」──
    # 纯展示层增强：复用已存在的 green + migration 数据计算，不动算账逻辑、不动绿区。
    # 语义：迁移整棵树里可能含有"同时也被绿区判定为绝对安全缓存"的子目录（如 CEF 缓存）。
    # 把这部分体积从整树里拆出说明，让"缓存在绿区、整树在迁移"的重叠透明化，用户不再困惑。
    def _norm(p):
        return os.path.normpath(p).lower().rstrip("\\")
    _green_items = []  # [(该绿项所有路径列表, kb)]
    for _it in (data.get("green") or []):
        _kb = _it.get("kb") or 0
        _paths = list(_it.get("trash_paths") or [])
        if _it.get("path"):
            _paths.append(_it["path"])
        _green_items.append(([_norm(p) for p in _paths if p], _kb))
    # v1.7.36（审查修复）：data.get("migration", {}) 在键存在但值为 null 时返回 None，
    # None.get 会 AttributeError。改为 (data.get("migration") or {})，与文件内其他处
    # 的 or {} 兜底风格一致。
    for _p in ((data.get("migration") or {}).get("plan") or []):
        _src = _p.get("src")
        _sc = 0
        if _src:
            _ns = _norm(_src)
            for _gpaths, _gkb in _green_items:
                if any(gp == _ns or gp.startswith(_ns + "\\") for gp in _gpaths):
                    _sc += _gkb
        _p["safe_cache_kb"] = _sc

    with open(TEMPLATE, "r", encoding="utf-8") as f:
        tpl = f.read()

    blob = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    # 静态报告不带删除能力（DELETE=null），删除按钮只在 server.py 服务时出现
    # 注入前转义 </ 防止路径/名称中的 </script> 闭合脚本标签造成 XSS（P0-3）
    # 许可状态：静态报告也展示“已授权/未授权”徽章（授权经由 server.py 服务完成）
    # 环境变量 AIPC_FORCE_UNACTIVATED=1 用于生成「未授权用户视角」预览报告，覆盖本机真实 license。
    if os.environ.get("AIPC_FORCE_UNACTIVATED") in ("1", "true", "yes"):
        lic = {"tier": 0, "active": False, "exp": 0, "version": "", "hwid": ""}
    else:
        lic = {}
        try:
            import license as _lic
            _l = _lic.read_license()
            lic = {"tier": _l.get("tier", 0),
                   "active": bool(_l.get("active", False)),
                   "exp": _l.get("exp", 0),
                   "version": _l.get("version", ""),
                   "hwid": _lic.get_hwid()}
            # AIPC-LIC-HWM：读到未授权时，再用服务端确认过的水位复核一次，
            # 避免"文件读不到 / 路径漂移"直接把付费用户渲染成付款墙。
            if int(lic.get("tier", 0) or 0) < 1:
                try:
                    _l2 = _lic._hwm_restore()
                except Exception:
                    _l2 = None
                if isinstance(_l2, dict) and int(_l2.get("tier", 0) or 0) >= 1:
                    lic = {"tier": int(_l2.get("tier", 0)),
                           "active": True,
                           "exp": 0,
                           "version": _l2.get("version", ""),
                           "hwid": _l2.get("hwid", "")}
        except Exception:
            # AIPC-LIC-HWM：license 模块整体不可用时，独立兜底扫一遍授权文件，
            # 绝不因为"读不到"就把已付费用户判成未授权。
            _fk = _last_resort_license()
            lic = _fk if _fk else {"tier": 0, "active": False, "exp": 0,
                                   "version": "", "hwid": ""}
    lic_blob = json.dumps(lic, ensure_ascii=False).replace("</", "<\\/")
    # 静态报告默认值：服务端（server.py）会覆盖这些占位符，但只读流水线必须兜底，
    # 否则模板里裸引用 __PRODUCTS_DATA__ 等变量会抛 ReferenceError，导致整页白屏。
    # 静态报告也必须注入渠道（否则模板里 window.__CHANNEL__ = __CHANNEL_VAL__
    # 裸标识符抛 ReferenceError 导致整页白屏）。与服务端 server.py 保持一致，数据源均为 config.json。
    # 注意：左侧变量名 window.__CHANNEL__ 必须保留，仅替换右侧占位符 __CHANNEL_VAL__。
    _channel = cfg.get("channel", "")
    _sc_blob = json.dumps(_channel, ensure_ascii=False).replace("</", "<\\/")
    # 方案价从 config 真实注入（模板有兜底，但注入真实值更准，且改价后静态报告同步）
    products_blob = json.dumps(cfg.get("plans", {}), ensure_ascii=False).replace("</", "<\\/")
    # ── 选项 A：注入真实迁移记录（优先 clean_state.json，缺失则从磁盘 junction 自动推断）──
    # 修复「每次扫描迁移记录为空」：不再写死空对象，保证静态报告也能展示已迁移项。
    clean_state_blob = _clamp_release_json(_build_clean_state_blob(src, raw_plan), src)
    # 迁移/清理状态持久路径（模板用 JS 引用，必须合法字符串；空字符串会生成 `= ;` 语法错误）
    cs_path = _clean_state_path()
    cs_path_blob = json.dumps(cs_path, ensure_ascii=False).replace("</", "<\\/")
    html = (tpl
            .replace("__INJECT_DATA__", blob)
            .replace("__DELETE_CFG__", "null")
            .replace("__LICENSE_CFG__", lic_blob)
            .replace("__PRODUCTS_DATA__", products_blob)
            .replace("__CLEAN_STATE_DATA__", clean_state_blob)
            .replace("__AIPC_CLEAN_STATE_PATH__", cs_path_blob)
            .replace("__IS_ADMIN_VALUE__", "true" if _is_admin() else "false")
            .replace("__CHANNEL_VAL__", _sc_blob))
    # 锁1+锁2：注入应用名 / 指纹 / 版本（随报告一起沉淀，利于应用名露出与传播）
    html = (html
            .replace("__BRAND__", cfg["app_name"])
            .replace("__FP__", cfg["fingerprint"])
            .replace("__VER__", cfg["version"]))

    # 健壮输出：先确保父目录存在；若目标路径不可用（如桌面被 OneDrive 重定向 /
    # 企业环境限制 / 路径异常），自动回退到脚本所在目录，保证报告总能生成、不中断链路。
    out = os.path.abspath(out)
    try:
        parent = os.path.dirname(out)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            f.write(html)
    except OSError:
        out = os.path.join(HERE, os.path.basename(out) or "C盘清理-报告.html")
        with open(out, "w", encoding="utf-8") as f:
            f.write(html)
    print(f"报告已生成: {out}")
    print(f"打开: open '{out}'")


if __name__ == "__main__":
    main()
