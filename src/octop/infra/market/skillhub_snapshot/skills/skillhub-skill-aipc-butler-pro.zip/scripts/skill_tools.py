#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""skill_tools.py — WB 对话框内执行的函数层（v1.7.21）。

把原来 server.py 里走 HTTP 的 action 逻辑抽成可直接调用的函数，供 WorkBuddy Agent
在对话框内执行（不再依赖浏览器报告页 / POST /action）。复用同一套引擎：
  - 清理：migrate.fast_purge（rename→批量删→残留重启删）
  - 迁移：migrate.do_migrate（复制-校验-切换 junction）
  - 支付：skillhub_adapter.create_order / x402_order_status + license 激活
  - 授权：license.mode_allowed / activate

用法（SKILL.md 工作流中 Agent 调用）：
  from skill_tools import create_order, check_paid, activate_code, clean_green, migrate_items, get_report_summary
"""
import os
import sys
import json
import time
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import license as license_mod
import skillhub_adapter as shub
import migrate as migrate_mod

# 产品表（价格/档位）—— 与 server.py 同源
def _products():
    try:
        with open(os.path.join(HERE, "config.json"), encoding="utf-8") as f:
            return (json.load(f) or {}).get("plans", {}) or {}
    except Exception:
        return {}


def _buyout_pids():
    """返回「基础版 / 高级版」的计划键，按 tier 从 config.json 派生。

    AIPC-SKU-DERIVE-FIX（v1.7.76）：原先这里把两个档位键名写死在代码里，但三壳的键
    前缀并不相同（有的壳带品牌前缀、有的无前缀），当时只是靠打包时的全局替换碰巧对上。
    一旦改名就会静默少下单（不报错、无日志）。现改为按 tier 从 config.json 派生，三壳通用。
    只取一次性买断档（排除 upgrade=true 的升级包）。
    """
    out = []
    for tier in (1, 2):
        for pid, cfg in (_products() or {}).items():
            if not isinstance(cfg, dict) or cfg.get("upgrade"):
                continue
            try:
                if int(cfg.get("tier", 0) or 0) == tier:
                    out.append(pid)
                    break
            except Exception:
                continue
    return out


def get_license():
    """返回当前本机授权状态 {tier, active, version, exp, hwid}。"""
    return license_mod.read_license()


# ---------------------------------------------------------------------------
# 支付链路（WB 内：Agent 下单 → weixinpay 插件/二维码 → Agent 查单解锁）
# ---------------------------------------------------------------------------
def create_order(product_id):
    """创建支付订单（X402 主通道）。

    返回 dict：
      ok=True  → {"mode":"x402","order_id":...,"payment_code":...,"code_url":...,"amount":...}
                  payment_code 交给 weixinpay_pay 插件拉起支付；code_url 可生成二维码兜底。
      ok=False → {"error": ...}（支付服务不可达等）
    """
    prod = _products().get(product_id)
    if not prod:
        return {"ok": False, "error": "无效的产品：" + product_id}
    # AIPC-HWID-REAL-FIX（v1.7.76）：原先恒传 "*"，让服务端「首次下单必须带
    # hwid/user_id，否则 400 IDENTITY_REQUIRED」的身份闸门形同不存在（非空恒过）。
    # 改传真 hwid；取不到时退回 "*" —— 宁可让身份闸门形同虚设，也绝不能让用户
    # 「付不了钱」（收入通道的可用性优先于标识完整）。绑机时机不变：仍在
    # /v1/activate 首次激活时完成，与本次下单参数无关。
    _real_hwid = ""
    try:
        _real_hwid = (license_mod.get_hwid() or "").strip()
    except Exception:
        _real_hwid = ""
    if not _real_hwid:
        _real_hwid = "*"
    oid = __import__("uuid").uuid4().hex
    order = {
        "order_id": oid,
        "product_id": product_id,
        "fee_cents": int(prod.get("fee_cents", 0)),
        "device_bound": bool(prod.get("device_bound", True)),
        "status": "pending",
        "created": int(time.time()),
        "license_code": "",
        "hwid": _real_hwid,     # 供订单归属判定（报告页复用未支付订单时用）
    }
    # 持久化订单（供 check_paid 查询；与 server 同路径，双保障）
    _save_order(order)
    try:
        res = shub.create_order(prod, _real_hwid, "http://127.0.0.1", oid,
                                product_id=product_id, cloud_order=False)
    except Exception as e:
        return {"ok": False, "error": "下单失败：" + str(e)}
    order["mode"] = res.get("mode", "simulate")
    order["out_trade_no"] = res.get("out_trade_no", "")
    order["payment_code"] = res.get("payment_code") or res.get("pay_url") or ""
    order["code_url"] = res.get("code_url") or ""
    _save_order(order)
    return {
        "ok": True,
        "mode": order["mode"],
        "order_id": oid,
        "payment_code": order["payment_code"],
        "code_url": order["code_url"],
        "out_trade_no": order["out_trade_no"],
        "amount": res.get("amount"),
        "fee_cents": order["fee_cents"],
        "product_name": prod.get("name", ""),
    }


def _orders_path():
    return os.path.join(license_mod.get_data_dir(), "orders.json")


# ===== 订单文件并发安全（AIPC-ORDER-LOCK-FIX，v1.7.76）=====
# 病根：orders.json 有**两个写入方** —— 对话框侧（本文件，Agent 调 skill_tools）
# 与报告页 server 进程；两边都是「全量读出 → 改一个 key → 全量写回」，后写者会把
# 先写者的改动整段覆盖（lost update）。后果：用户付了钱，本地订单却被覆盖回
# pending，报告页一直等、还可能再付一次 = 真金白银事故。
# 治法：与 server.py 用**同一把锁文件 <orders.json>.lock、同一段锁区间**，读改写
# 全程互斥；拿不到文件锁时不抛错也不阻断（退化为进程内锁 + 原子替换）。
# 只改一边等于没锁 —— 两处必须成对维护。
_ORDER_LOCK = threading.RLock()
_ORDER_FLOCK_DEPTH = [0]


def _orders_flock():
    """读改写 orders.json 时全程持有的跨进程互斥锁（上下文管理器）。

    与 server.py 的同名函数锁同一路径、同一区间；只改一边等于没锁。
    """
    import contextlib

    @contextlib.contextmanager
    def _cm():
        if _ORDER_FLOCK_DEPTH[0] > 0:      # 同进程重入：不再锁一次
            _ORDER_FLOCK_DEPTH[0] += 1
            try:
                yield
            finally:
                _ORDER_FLOCK_DEPTH[0] -= 1
            return
        lock_path = _orders_path() + ".lock"
        f = None
        try:
            try:
                os.makedirs(os.path.dirname(lock_path) or ".", exist_ok=True)
            except Exception:
                pass
            f = open(lock_path, "a+b")
            try:
                if os.name == "nt":
                    # AIPC-LOCK-SPIN-FIX（v1.7.76）：原先用 msvcrt.LK_LOCK —— 它的重试
                    # 粒度是**整秒**（失败等 1 秒、共 10 次）→ 双方高频写同一文件时
                    # 每次要等 0.5~1 秒，200 次写就从 3 秒变 20 秒；更糟的是等满 10 次
                    # 仍拿不到就抛错，退化无锁 → 那一次写入直接丢（实测 400 条丢 1 条，
                    # 日志 `[Errno 36] Resource deadlock avoided`）。
                    # 改用 LK_NBLCK 非阻塞 + 5ms 粒度自旋（总上限 10 秒）：拿锁快、
                    # 不因"等太久"而静默退化。
                    import msvcrt
                    _deadline = time.time() + 10.0
                    while True:
                        try:
                            f.seek(0)
                            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                            break
                        except Exception:
                            if time.time() >= _deadline:
                                raise
                            time.sleep(0.005)
                else:
                    import fcntl
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            except Exception as _le:
                # 锁拿不到时退化为「进程内锁 + 原子替换」：支付可用性优先。
                # 但必须留下痕迹 —— 静默退化等于没人知道锁已经失效了。
                try:
                    sys.stderr.write(
                        "[order-lock] 文件锁获取失败（已退化为进程内锁）：%s\n" % _le)
                except Exception:
                    pass
            _ORDER_FLOCK_DEPTH[0] = 1
            yield
        finally:
            _ORDER_FLOCK_DEPTH[0] = 0
            if f is not None:
                try:
                    if os.name == "nt":
                        import msvcrt
                        f.seek(0)
                        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except Exception:
                    pass
                try:
                    f.close()
                except Exception:
                    pass
    return _cm()


# v1.7.21 预下单缓存：报告一出就预生成两个档位的订单，用户点解锁秒级出示付款码。
# 缓存 {product_id: order_result}，订单未支付不产生费用（X402 仅创建支付单）。
# v1.7.76 实情说明：预下单能力**目前未接入主链路**（preorder_all 全仓无调用方，
# 报告生成流程不会调它）。保留本段是为了不改变既有对外函数签名；get_pay_qr 仍会
# 用它作为"秒级出码"的缓存层（首次实时下单后写入缓存）。
_PREORDER_CACHE = {}
_PREORDER_TS = {}

# v1.7.64（安全合规）：自动预下单开关。默认开启（提升解锁出码速度），
# 但必须由前端隐私开关显式控制。关闭后仅在用户主动点解锁时实时下单，
# 不在报告生成时静默预创建订单。
_AUTO_PREORDER_ENABLED = [True]

def set_auto_preorder_enabled(enabled):
    """由前端隐私开关调用：是否允许报告生成时自动预下单。"""
    _AUTO_PREORDER_ENABLED[0] = bool(enabled)


def preorder_all():
    """预下单基础版 + 高级版（报告生成后立即调用，用户点解锁时秒级出码）。

    返回 {product_id: result}；失败项标记 ok=False（用户点它时再实时补单）。
    v1.7.64：若用户关闭自动预下单，则跳过（订单仍可在用户点解锁时实时创建）。
    """
    global _PREORDER_CACHE, _PREORDER_TS
    if not _AUTO_PREORDER_ENABLED[0]:
        return _PREORDER_CACHE
    for pid in _buyout_pids():   # v1.7.76：按 tier 派生，不再写死 SKU 键（三壳通用）
        # 缓存 10 分钟内复用，避免重复下单堆积订单
        if pid in _PREORDER_CACHE and time.time() - _PREORDER_TS.get(pid, 0) < 600:
            continue
        try:
            r = create_order(pid)
            _PREORDER_CACHE[pid] = r
            _PREORDER_TS[pid] = time.time()
        except Exception as e:
            _PREORDER_CACHE[pid] = {"ok": False, "error": str(e)}
            _PREORDER_TS[pid] = time.time()
    return _PREORDER_CACHE


def get_pay_qr(product_id):
    """秒级取付款码：优先用预下单缓存；无缓存/过期才实时下单。

    返回 {ok, order_id, payment_code, code_url, amount, fee_cents, product_name, error}
    """
    if product_id in _PREORDER_CACHE and time.time() - _PREORDER_TS.get(product_id, 0) < 600:
        r = _PREORDER_CACHE[product_id]
        if r.get("ok"):
            return r
    # 实时补单（预下单失败或过期）
    r = create_order(product_id)
    if r.get("ok"):
        _PREORDER_CACHE[product_id] = r
        _PREORDER_TS[product_id] = time.time()
    return r


def _save_order(order):
    """持久化单个订单（跨进程互斥 + 原子替换）。

    AIPC-ORDER-LOCK-FIX（v1.7.76）：原先「全量读 → 改一个 key → 全量写」且直接
    覆盖写目标文件，会 ① 覆盖报告页进程同时写入的其它订单（lost update）；
    ② 写到一半崩溃留下半个 JSON（订单全丢）。现在全程在锁内读改写，并用
    「临时文件 + os.replace」原子替换（与 server.py._save_orders 同一套写法）。

    本函数是 skill_tools 侧**唯一**的订单写入口，改这里即覆盖本文件全部写点。
    """
    if not order or not order.get("order_id"):
        return
    try:
        path = _orders_path()
        d = os.path.dirname(path) or "."
        os.makedirs(d, exist_ok=True)
        import tempfile
        with _ORDER_LOCK:
            with _orders_flock():
                orders = {}
                if os.path.exists(path):
                    with open(path, encoding="utf-8") as f:
                        orders = json.load(f) or {}
                orders[order["order_id"]] = order
                # AIPC-ORDER-ATOMIC-COST（v1.7.76）：改用固定 tmp 名而非
                # tempfile.mkstemp 随机名 —— 不再每次写都新建文件。实测 200 次写
                # 从 9.94s 降到 <1s。这里全程持锁，不存在第二个写者，固定名安全；
                # 上次崩溃残留的 tmp 会被直接覆盖。仍走 os.replace 原子替换。
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(orders, f, ensure_ascii=False)
                # AIPC-REPLACE-RETRY（v1.7.76）：Windows 的 MoveFileEx 遇到「目标文件
                # 正被打开」会报 WinError 5（实测 400 次写丢 1 条）。读方已改持锁读，
                # 这里再短自旋兜底，覆盖杀软扫描／用户手动打开文件等外部占用。
                _rep_err = None
                for _ in range(40):          # 最多 40 × 25ms = 1 秒
                    try:
                        os.replace(tmp, path)
                        _rep_err = None
                        break
                    except OSError as _re:
                        _rep_err = _re
                        time.sleep(0.025)
                if _rep_err is not None:
                    raise _rep_err
    except Exception as _se:
        # AIPC-ORDER-SAVE-TRACE（v1.7.76）：原先这里是静默 pass —— 订单写失败
        # （权限/杀软拦截/磁盘满）时订单凭空消失且无人知晓，是「丢单查不出原因」的根源。
        try:
            sys.stderr.write("[order-save] 订单写盘失败：%s\n" % _se)
        except Exception:
            pass


def _read_orders():
    """读订单（跨进程互斥读）。

    AIPC-ORDER-READ-LOCK（v1.7.76）：与 server.py._load_orders 同理 —— 裸读会
    ① 让写方的 os.replace 报 WinError 5（Windows 独占语义）而丢一次写入；
    ② 在替换瞬间读到「文件不存在」→ 返回 {} → 后续写回从空档重来（丢全部订单）。
    """
    try:
        path = _orders_path()
    except Exception:
        return {}
    with _ORDER_LOCK:
        with _orders_flock():
            try:
                if not os.path.exists(path):
                    return {}
                with open(path, encoding="utf-8") as f:
                    return json.load(f) or {}
            except Exception:
                return {}


def check_paid(order_id):
    """查单：订单是否已支付并解锁。

    返回 dict：{paid, status, tier, active, license_code, error}
    - 已支付 → paid=True，且已自动激活（active=True）
    - 未支付 → paid=False, status=pending
    """
    # AIPC-ORDER-READ-LOCK（v1.7.76）：原先是裸读，会影响写方的原子替换（见 _read_orders）。
    orders = _read_orders()
    order = orders.get(order_id, {})
    if not order:
        return {"paid": False, "status": "not_found", "error": "未找到订单"}
    if order.get("status") == "paid":
        # AIPC-PAY-RECOVER-FIX：不能无条件回 active=True —— 必须读本机真实授权状态。
        # 旧实现曾出现「订单已 paid、但本机激活失败」时仍报 active=True，
        # Agent 据此告诉用户「已解锁」，用户回报告页发现功能还是锁着 = 谎报。
        _lic = license_mod.read_license()
        if _lic.get("active") and int(_lic.get("tier", 0) or 0) >= 1:
            return {"paid": True, "status": "paid", "active": True,
                    "tier": int(_lic.get("tier", 0) or 0),
                    "license_code": order.get("license_code", "")}
        _code = order.get("license_code", "")
        if not _code:
            return {"paid": True, "status": "paid_no_code", "active": False,
                    "error": "订单已支付，但服务端未返回授权码"}
        _ar, _ = license_mod.activate_online(_code, version=license_mod.LOCAL_VERSION)
        if _ar.get("ok"):
            _lic2 = license_mod.read_license()
            return {"paid": True, "status": "paid", "active": True,
                    "tier": int(_lic2.get("tier", 0) or 0), "license_code": _code}
        return {"paid": True, "status": "paid_but_activate_fail", "active": False,
                "license_code": _code,
                "error": _ar.get("error") or "本机激活失败，请重试或联系客服"}
    # X402 模式：带 out_trade_no 重试 /invoke 查单（商户侧确认支付 → 返回授权码）
    out_trade_no = order.get("out_trade_no", "")
    mode = order.get("mode", "")
    try:
        if mode == "x402" and out_trade_no:
            st = shub.x402_order_status(out_trade_no)
            if st.get("status") == "paid" and st.get("code"):
                act_res, _ = license_mod.activate_online(st["code"], version=license_mod.LOCAL_VERSION)
                if act_res.get("ok"):
                    order["status"] = "paid"
                    order["license_code"] = st["code"]
                    order["paid_at"] = int(time.time())
                    _save_order(order)
                    return {"paid": True, "status": "paid", "active": True,
                            "license_code": st["code"]}
                return {"paid": False, "status": "paid_but_activate_fail",
                        "error": act_res.get("error") or "授权失败"}
            if st.get("status") == "error":
                return {"paid": False, "status": "error", "error": st.get("error")}
    except Exception as e:
        return {"paid": False, "status": "error", "error": "查单失败：" + str(e)}
    return {"paid": False, "status": "pending"}


def pending_orders():
    """列出「钱可能已经付了、但本机还没解锁」的订单 —— 救单用（AIPC-PAY-RECOVER-FIX）。

    返回 [{order_id, product_id, fee_cents, status, mode, out_trade_no, created}]，按创建时间倒序。
    包含 status=="error" 的订单：「已付款却被误标 error」正是要救的对象。
    """
    # AIPC-ORDER-READ-LOCK（v1.7.76）：原先裸读，同样会影响写方的原子替换。
    orders = _read_orders()
    rows = []
    for oid, o in (orders or {}).items():
        if not isinstance(o, dict):
            continue
        if o.get("status") == "paid" and license_mod.read_license().get("active"):
            continue
        if not o.get("out_trade_no"):
            continue
        rows.append({
            "order_id": oid,
            "product_id": o.get("product_id", ""),
            "fee_cents": int(o.get("fee_cents", 0) or 0),
            "status": o.get("status", ""),
            "mode": o.get("mode", ""),
            "out_trade_no": o.get("out_trade_no", ""),
            "created": int(o.get("created", 0) or 0),
        })
    rows.sort(key=lambda r: r["created"], reverse=True)
    return rows


def rescue_orders():
    """救单：把所有「未解锁」订单逐一拿去服务端确认，查到已付就当场激活。

    两处必用（AIPC-PAY-RECOVER-FIX）：
      ① 用户说「我付了钱但没解锁 / 没收到码 / 页面说确认失败」→ **先跑这个**。
      ② **每次要下单之前也先跑这个** —— 用户在报告页可能已经付款成功、只是没解锁，
         不先查就下单会让用户付第二遍钱（重复付款是事故，不是小事）。

    返回 {checked, rescued:[{order_id,product_id,tier}], still_pending, failed:[...]}
    """
    res = {"checked": 0, "rescued": [], "still_pending": 0, "failed": []}
    for row in pending_orders():
        res["checked"] += 1
        try:
            r = check_paid(row["order_id"])
        except Exception as e:
            res["failed"].append({"order_id": row["order_id"], "error": str(e)})
            continue
        if r.get("paid") and r.get("active"):
            res["rescued"].append({"order_id": row["order_id"],
                                   "product_id": row["product_id"],
                                   "tier": int(r.get("tier", 0) or 0)})
        elif r.get("status") in ("pending", "not_found", "paid_no_code"):
            res["still_pending"] += 1
        elif r.get("paid") and not r.get("active"):
            # 已付款但激活失败：单独报出来，别混进 pending
            res["failed"].append({"order_id": row["order_id"],
                                  "error": r.get("error") or "已付款但激活失败"})
        else:
            res["failed"].append({"order_id": row["order_id"],
                                  "error": r.get("error") or r.get("status", "")})
    return res


def activate_code(code):
    """激活码激活（在线台账一码一机）。"""
    code = (code or "").strip()
    if not code:
        return {"ok": False, "error": "请输入激活码"}
    res = license_mod.activate(code, version=license_mod.LOCAL_VERSION)
    return {"ok": bool(res.get("ok")), "tier": res.get("tier", 0),
            "error": res.get("error") or ("" if res.get("ok") else "激活失败")}


# ---------------------------------------------------------------------------
# 清理 / 迁移（WB 内执行，复用引擎）
# ---------------------------------------------------------------------------
def _tier_gate(min_tier, action_name):
    """付费闸门：未达到档位 → 返回需解锁的拒绝结果；达标 → 返回 None 表示放行。

    规则（与 tier_capabilities 一致）：清理需基础版(≥1)，迁移需高级版(≥2)。
    用 current_tier()（含云端复核，只降不升）取权威等级。
    """
    tier = license_mod.current_tier()
    cap = tier_capabilities(tier)
    if cap.get("clean") or cap.get("migrate"):
        if tier >= min_tier:
            return None
    need = "高级版" if min_tier >= 2 else "基础版"
    return {
        "ok": False,
        "paid": False,
        "gate": "locked",
        "need": need,
        "error": "该功能需解锁 %s 才能使用，未解锁无法执行%s。" % (need, action_name),
        "hint": "请在右侧报告页点「解锁」完成支付，或在对话框粘贴激活码解锁。",
        "tier": tier,
    }


def clean_green(paths, on_progress=None):
    """一键清：并行 fast_purge 删除绿区缓存路径。

    paths: 报告 green[].trash_paths 展开后的路径列表
    返回 {ok, done:[], failed:[{path, reason}], reboot_pending: n}
    """
    # 付费闸门：清理需基础版及以上。未付费一律拒绝，杜绝对话框绕过付费。
    gate = _tier_gate(1, "清理")
    if gate:
        return gate
    from concurrent.futures import ThreadPoolExecutor, as_completed
    done, failed = [], []
    reboot_pending = 0

    def _one(p):
        try:
            residual = migrate_mod.fast_purge(p, on_progress=on_progress)
            return p, residual
        except Exception as e:
            return p, ("ERR:" + str(e))

    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(_one, p) for p in paths]
        for fu in as_completed(futs):
            p, res = fu.result()
            if isinstance(res, list):
                done.append(p)
                if res:
                    reboot_pending += 1  # 有残留 = 已安排重启删
            else:
                failed.append({"path": p, "reason": str(res)})
    return {"ok": len(failed) == 0, "done": done, "failed": failed,
            "reboot_pending": reboot_pending}


def migrate_items(plan, on_progress=None):
    """执行迁移计划（复制-校验-切换 junction）。"""
    # 付费闸门：迁移需高级版。未付费一律拒绝，杜绝对话框绕过付费。
    gate = _tier_gate(2, "迁移")
    if gate:
        return gate
    try:
        mres = migrate_mod.do_migrate(plan, dry_run=False, on_progress=on_progress,
                                      max_workers=None)
    except Exception as e:
        return {"ok": False, "done": [], "failed": [{"msg": str(e)}], "error": str(e)}
    return {"ok": True, "done": mres.get("done", []), "failed": mres.get("failed", [])}


# ---------------------------------------------------------------------------
# 报告摘要（供 Agent 对话框展示，不读完整 HTML）
# ---------------------------------------------------------------------------
def get_report_summary(analysis_path):
    """从 analysis.json 提取对话框展示用的摘要。

    绿区/迁移量**与报告页同源**（solution.green_reclaim_kb / migration.total_reclaim_kb），
    保证对话框与报告页数字完全一致（不重复自算，避免 7.2 vs 6.8 这种不一致）。
    """
    try:
        with open(analysis_path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return {"error": "读取报告失败：" + str(e)}
    sol = d.get("solution") or {}
    green_kb = float(sol.get("green_reclaim_kb") or 0)
    mig = d.get("migration") or {}
    mig_kb = float(mig.get("total_reclaim_kb") or 0)
    return {
        "green_gb": round(green_kb / 1024 / 1024, 1),
        "mig_gb": round(mig_kb / 1024 / 1024, 1),
        "green_count": len(d.get("green", [])),
        "mig_count": len(mig.get("candidates") or []),
        "scan_seconds": d.get("scan_seconds") or 0,
        "generated_at": d.get("generated_at") or "",
    }


# ---------------------------------------------------------------------------
# 交互能力扩展（v1.7.21 用户点点点原则）：自动解锁 / 迁移部分选择 / 档位能力
# ---------------------------------------------------------------------------
def poll_paid(order_id, timeout=60, interval=2.0):
    """自动轮询订单是否已支付并解锁（用户付款后无需说「已付款」）。

    付款 → 服务端 /invoke 查单确认 → 自动激活 → 返回 {paid, tier, active, error}。
    timeout 秒内持续轮询（默认 60s），超时返回 pending 供 Agent 引导。
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = check_paid(order_id)
        if r.get("paid"):
            return r
        if r.get("status") == "error":
            return r
        time.sleep(interval)
    return {"paid": False, "status": "pending", "error": "等待支付超时"}


def detect_activation_code(text):
    """从用户消息中识别激活码（WX-XXXX-XXXX 格式，字母数字-）。

    用户直接粘贴激活码即可解锁，无需先点任何按钮（丝滑原则）。
    返回激活码或 None。
    """
    import re
    m = re.search(r"\bWX-[A-Z0-9]{4}-[A-Z0-9]{4}\b", (text or "").upper())
    return m.group(0) if m else None


def tier_capabilities(tier):
    """按档位返回能力描述（用于解锁按钮文案与权限判断）。"""
    if tier >= 2:
        return {"tier": 2, "name": "高级版", "clean": True, "migrate": True, "trash": True}
    if tier >= 1:
        return {"tier": 1, "name": "基础版", "clean": True, "migrate": False, "trash": False}
    return {"tier": 0, "name": "免费版", "clean": False, "migrate": False, "trash": False}


def unlock_buttons(analysis_path):
    """生成报告后的解锁按钮文案（不放价格，放能力——让报告先打动用户）。

    返回 dict：
      {basic: "解锁基础版 · 可一键清理约 X GB",
       pro:   "解锁高级版 · 可清理 + 迁移约 Y GB",
       free:  "先看看报告 / 输入激活码"}
    """
    s = get_report_summary(analysis_path)
    green_gb = s.get("green_gb", 0)
    total_gb = round((s.get("green_gb", 0) + s.get("mig_gb", 0)), 1)
    return {
        "basic": "解锁基础版 · 可一键清理约 %s GB" % green_gb,
        "pro": "解锁高级版 · 可清理 + 迁移约 %s GB" % total_gb,
        "activate": "输入激活码",
    }


def get_migration_options(analysis_path):
    """返回迁移候选列表（含大小/目标盘容量，供用户部分选择）。

    返回 {options:[{id,name,size_gb,src,dst,capacity_exceeded}], target_drive, target_free_gb, total_gb}
    - capacity_exceeded=True 表示该候选已超出目标盘剩余空间（用户需挑选一部分）
    """
    try:
        with open(analysis_path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return {"error": "读取报告失败：" + str(e)}
    mig = d.get("migration") or {}
    plan = mig.get("plan") or []
    target_drive = mig.get("target_drive") or ""
    target_free_gb = float(mig.get("target_free_gb") or 0)
    options = []
    for i, p in enumerate(plan, 1):
        options.append({
            "id": i,
            "name": p.get("name") or p.get("display_name") or os.path.basename(p.get("src", "")),
            "size_gb": round(float(p.get("size_kb", 0) or 0) / 1024 / 1024, 1),
            "src": p.get("src", ""),
            "dst": p.get("dst", ""),
            "mode": p.get("mode", "junction"),
            "capacity_exceeded": bool(p.get("capacity_exceeded")),
        })
    total_gb = round(sum(o["size_gb"] for o in options), 1)
    return {"options": options, "target_drive": target_drive,
            "target_free_gb": target_free_gb, "total_gb": total_gb,
            "has_capacity_issue": any(o["capacity_exceeded"] for o in options)}


def plan_selected_migration(analysis_path, selected_ids):
    """按用户勾选的迁移项生成执行计划。

    selected_ids: 用户选择的 id 列表（来自 get_migration_options 的 options[].id）
    返回 do_migrate 可执行的 plan（含 src/dst/size_kb/mode）。
    """
    try:
        with open(analysis_path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:
        return {"error": "读取报告失败：" + str(e)}
    plan = (d.get("migration") or {}).get("plan") or []
    chosen = []
    for p in plan:
        # 按顺序给每个 plan 项一个稳定 id（与 get_migration_options 一致）
        pass
    opts = get_migration_options(analysis_path).get("options", [])
    id_to_plan = {o["id"]: p for o, p in zip(opts, plan)}
    selected = [id_to_plan[i] for i in selected_ids if i in id_to_plan]
    if not selected:
        return {"error": "未选择任何迁移项"}
    return {"ok": True, "plan": selected, "count": len(selected),
            "total_gb": round(sum(float(p.get("size_kb", 0) or 0) for p in selected) / 1024 / 1024, 1)}


if __name__ == "__main__":
    # 自检
    lic = get_license()
    print("license:", json.dumps(lic, ensure_ascii=False)[:120])
