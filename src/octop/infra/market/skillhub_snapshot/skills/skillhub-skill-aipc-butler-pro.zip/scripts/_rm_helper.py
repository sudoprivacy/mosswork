#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Restart Manager 精准释放 + 旧开机任务清理，子进程隔离版。

为什么独立成子进程？
  migrate.py 主迁移进程在调用 rstrtmgr.dll / kernel32.MoveFileExW 时，这些 C 层
  调用一旦出意外（结构体不匹配、驱动态崩溃）会产生 segfault —— 而 Python 的
  try/except 抓不住 segfault，会直接杀死整个迁移进程，导致用户目录卡在半迁移状态。
  把这类 Windows 内部调用单独放一个子进程里：即使它崩溃，也只是子进程死掉，
  主进程通过 returncode 感知后安全走兜底（诚实失败 / 补齐指引），绝不连累主迁移。

用法（由 migrate.py 以 subprocess 调用）：
  python _rm_helper.py release <src>      -> 输出 JSON {"lockers": [...]} 或 {"lockers": null}
子进程自身任何异常都返回合法 JSON、exit 0，绝不让父进程看到崩溃。

v1.7.82（过审改造·科恩实验室）：本模块已彻底移除「注册开机/登录自启任务」的一切能力
（v1.7.81 及之前的 _reboot_commit_script 生成器与 do_reboot 注册通道已删除）。
迁移收尾不再依赖任何计划任务：源目录在重启前完全不动，用户重启电脑后重新打开
本工具，启动兜底（migrate.auto_cleanup_orphan_baks）会自动补齐零头并完成切换。
本模块仅保留 delete_reboot_task 用于清理旧版本遗留在用户电脑上的任务（撤销行为）。
"""
import sys
import os
import json
import subprocess
import ctypes
from ctypes import wintypes as wt

# 创建子进程时不弹黑框（Windows）；schtasks /delete 等控制台命令静默执行。
try:
    CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW
except AttributeError:
    CREATE_NO_WINDOW = 0x08000000


def do_release(src):
    """Restart Manager：枚举并强制关闭握持 src 的进程（不限白名单），返回占用者名单。
    非提权 / 失败 返回 {"lockers": null}。任何异常都返回合法 JSON，不抛。"""
    try:
        class _FT(ctypes.Structure):
            _fields_ = [("dwLowDateTime", wt.DWORD), ("dwHighDateTime", wt.DWORD)]

        class _UP(ctypes.Structure):
            _fields_ = [("dwProcessId", wt.DWORD), ("ProcessStartTime", _FT)]

        class _PI(ctypes.Structure):
            _pack_ = 4
            _fields_ = [
                ("Process", _UP),
                ("strAppName", wt.WCHAR * 256),
                ("strServiceShortName", wt.WCHAR * 64),
                ("ApplicationType", ctypes.c_int),
                ("AppStatus", ctypes.c_int),
                ("TSSessionId", wt.DWORD),
                ("bRestartable", ctypes.c_bool),
            ]

        rst = ctypes.windll.rstrtmgr
        rst.RmStartSession.argtypes = [ctypes.POINTER(wt.DWORD), ctypes.c_int, ctypes.c_wchar_p]
        rst.RmStartSession.restype = wt.DWORD
        rst.RmRegisterResources.argtypes = [wt.DWORD, wt.UINT, ctypes.POINTER(ctypes.c_wchar_p),
                                            wt.UINT, ctypes.POINTER(_UP), wt.UINT, ctypes.POINTER(ctypes.c_wchar_p)]
        rst.RmRegisterResources.restype = wt.DWORD
        rst.RmGetList.argtypes = [wt.DWORD, ctypes.POINTER(wt.DWORD), ctypes.POINTER(wt.DWORD),
                                  ctypes.POINTER(_PI), ctypes.POINTER(wt.DWORD)]
        rst.RmGetList.restype = wt.DWORD
        rst.RmShutdown.argtypes = [wt.DWORD, wt.ULONG, ctypes.c_void_p]
        rst.RmShutdown.restype = wt.DWORD
        rst.RmRestart.argtypes = [wt.DWORD, wt.DWORD, ctypes.c_void_p]
        rst.RmRestart.restype = wt.DWORD
        rst.RmEndSession.argtypes = [wt.DWORD]
        rst.RmEndSession.restype = wt.DWORD

        sess = wt.DWORD(0)
        # 注意：strSessionKey 是【输出】缓冲区，RmStartSession 会写入最多
        # CCH_RM_SESSION_KEY+1 = 22 个 WCHAR；缓冲区太小会堆溢出→崩溃。
        # 必须用固定大小的空缓冲区，绝不能按初始字符串长度建。
        key = ctypes.create_unicode_buffer(22)
        if rst.RmStartSession(ctypes.byref(sess), 0, key) != 0:
            return json.dumps({"lockers": None})
        try:
            files = (ctypes.c_wchar_p * 1)(src)
            if rst.RmRegisterResources(sess.value, 1, files, 0, None, 0, None) != 0:
                return json.dumps({"lockers": None})
            needed = wt.DWORD(0)
            info = wt.DWORD(0)
            reboot = wt.DWORD(0)
            rst.RmGetList(sess.value, ctypes.byref(needed), ctypes.byref(info), None, ctypes.byref(reboot))
            lockers = []
            if needed.value > 0:
                arr = (_PI * needed.value)()
                info = wt.DWORD(needed.value)
                rst.RmGetList(sess.value, ctypes.byref(needed), ctypes.byref(info), arr, ctypes.byref(reboot))
                for i in range(info.value):
                    nm = arr[i].strAppName or ("pid:%d" % arr[i].Process.dwProcessId)
                    lockers.append(nm.strip())
                # 强制关闭握持本资源的进程（仅这些进程），释放文件/目录句柄
                rst.RmShutdown(sess.value, 0x1, None)
                _t = __import__("time")
                _t.sleep(1.5)
                try:
                    rst.RmRestart(sess.value, 0, None)
                except Exception:
                    pass
            return json.dumps({"lockers": lockers})
        finally:
            rst.RmEndSession(sess.value)
    except Exception as e:
        return json.dumps({"lockers": None, "error": str(e)})


# v1.7.82（过审改造）：原 do_reboot（注册 schtasks 开机任务 + MoveFileEx 开机改名）已整体删除。
# 迁移收尾改为「重启电脑 → 重新打开本工具 → 启动兜底自动补齐」，不再注册任何开机/登录任务。


def delete_reboot_task(tn):
    """清理旧版本（v1.7.81 及之前）遗留在用户电脑上的开机任务，并删除落盘脚本。

    v1.7.82 起本工具绝不再创建任何任务；本函数只做【撤销/清理】——
    对不存在的任务名执行 /delete 无副作用，用于升级用户的环境净化。"""
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        script = os.path.join(here, "_reboot_commit_" + tn + ".py")
        subprocess.run(
            ["schtasks", "/delete", "/tn", tn, "/f"],
            capture_output=True, text=True, encoding="utf-8", errors="ignore",
            timeout=20, creationflags=CREATE_NO_WINDOW,
        )
        try:
            if os.path.exists(script):
                os.remove(script)
        except Exception:
            pass
        return True
    except Exception:
        return False


if __name__ == "__main__":
    try:
        mode = sys.argv[1] if len(sys.argv) > 1 else ""
        if mode == "release" and len(sys.argv) >= 3:
            sys.stdout.write(do_release(sys.argv[2]))
        else:
            sys.stdout.write(json.dumps({"ok": False, "error": "bad args"}))
    except Exception as e:
        sys.stdout.write(json.dumps({"ok": False, "error": str(e)}))
