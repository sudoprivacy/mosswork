# -*- coding: utf-8 -*-
"""实测查锁：枚举系统句柄，找出「握有迁移源目录下文件句柄」的进程，返回可安全结束的进程名。

为什么需要它：
  迁移改名(os.rename)失败(winerror=32/5)通常是某个进程握着源目录内文件的句柄。
  但「谁在握」无法靠进程名猜测穷举——输入法(搜狗 sgtool)、云盘、备份、编辑器、杀软、
  索引服务都可能锁。本模块用 Windows 原生句柄枚举(NtQuerySystemInformation)实测找出真凶，
  返回进程名，交给上层按名结束(可覆盖复活)。这是「不靠猜、立足现实」的查锁方案。

性能/安全：
  全系统句柄约 15 万，逐句柄查名约 15~30s（一次性，不在改名紧循环内）。
  用线程池 + 每句柄 50ms 超时，跳过会挂死的句柄类型(ALPC/桌面等)，绝不卡死主流程。
  绝对不返回系统关键进程名(system/lsass/svchost/explorer 等)，避免误杀。
失败(权限/API 异常)返回空列表，上层可安全降级到原有白名单逻辑。
"""
import os
import ctypes
import ctypes.wintypes as wt
import subprocess
import concurrent.futures
import threading

# v1.7.34（黑框修复）：lockfinder 被迁移锁对抗 L3 全盘句柄枚举调用，tasklist 是控制台
# 程序，capture_output=True 只接管 stdio、不抑制控制台窗口本身。补 CREATE_NO_WINDOW
# 避免迁移过程中闪现黑色控制台窗口。
try:
    CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW
except AttributeError:
    CREATE_NO_WINDOW = 0x08000000

# 绝对不可结束的系统/桌面关键进程（误杀会崩系统或丢任务栏）
CRITICAL_NAMES = {
    "system", "smss.exe", "csrss.exe", "wininit.exe", "services.exe", "lsass.exe",
    "svchost.exe", "explorer.exe", "dwm.exe", "winlogon.exe", "spoolsv.exe",
    "fontdrvhost.exe", "lsaiso.exe", "memcompress.exe", "securityhealthservice.exe",
    "sihost.exe", "taskhostw.exe", "shellhost.exe", "startmenuexperiencehost.exe",
    "searchui.exe", "cortana.exe", "lockscreen.exe", "conhost.exe", "taskmgr.exe",
    "runtimebroker.exe", "dllhost.exe", "searchindexer.exe", "audiodg.exe",
    "wudfhost.exe", "dashost.exe", "wbengine.exe",
}


def _normalize_tail(path):
    p = path.lower().replace("/", "\\")
    i = p.find("\\")
    return p[i:] if i >= 0 else p


def _list_procs():
    out = subprocess.run(["tasklist", "/FO", "CSV"], capture_output=True,
                         text=True, encoding="utf-8", errors="ignore",
                         creationflags=CREATE_NO_WINDOW).stdout
    procs = {}
    for line in out.splitlines()[1:]:
        parts = [x.strip('"') for x in line.split('","')]
        if len(parts) >= 2:
            try:
                procs[int(parts[1])] = parts[0].lower()
            except Exception:
                pass
    return procs


def find_locking_process_names(src, skip_critical=True):
    """返回握有 src 目录下文件句柄的进程名列表（去重，已剔除系统关键进程）。"""
    try:
        ntdll = ctypes.windll.ntdll
        kernel32 = ctypes.windll.kernel32
        ntdll.NtDuplicateObject.argtypes = [wt.HANDLE, wt.HANDLE, wt.HANDLE,
                                            ctypes.POINTER(wt.HANDLE), wt.DWORD, wt.DWORD, wt.DWORD]
        ntdll.NtDuplicateObject.restype = wt.DWORD
        ntdll.NtQueryObject.argtypes = [wt.HANDLE, wt.DWORD, ctypes.c_void_p, wt.DWORD, ctypes.POINTER(wt.DWORD)]
        ntdll.NtQueryObject.restype = wt.DWORD
        kernel32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
        kernel32.OpenProcess.restype = wt.HANDLE
        kernel32.CloseHandle.argtypes = [wt.HANDLE]
        kernel32.CloseHandle.restype = wt.BOOL

        src_tail = _normalize_tail(src)

        # NtQuerySystemInformation(SystemHandleInformation=16)
        bufsize = 8 * 1024 * 1024
        while True:
            buf = ctypes.create_string_buffer(bufsize)
            retlen = wt.DWORD(0)
            hr = ntdll.NtQuerySystemInformation(16, buf, bufsize, ctypes.byref(retlen))
            if hr == 0:
                break
            if (hr & 0xffffffff) == 0xC0000004:
                bufsize *= 2
                continue
            return []

        count = ctypes.cast(buf, ctypes.POINTER(wt.DWORD))[0]
        base = ctypes.addressof(buf) + 8
        entry_size = 16

        class ENTRY(ctypes.Structure):
            _fields_ = [("pid", ctypes.c_ushort), ("bt", ctypes.c_ushort),
                        ("type", ctypes.c_ubyte), ("attr", ctypes.c_ubyte),
                        ("hv", ctypes.c_ushort), ("obj", ctypes.c_void_p),
                        ("granted", ctypes.c_ulong)]

        procs = _list_procs()
        open_cache = {}
        cache_lock = threading.Lock()
        found_pids = set()
        found_lock = threading.Lock()

        def get_proc(pid):
            with cache_lock:
                if pid in open_cache:
                    return open_cache[pid]
                h = kernel32.OpenProcess(0x40, False, pid)
                open_cache[pid] = h
                return h

        def query_name(dup):
            nbuf = ctypes.create_string_buffer(0x1000)
            nr = wt.DWORD(0)
            res = {}

            def run():
                try:
                    res["r"] = ntdll.NtQueryObject(dup, 1, nbuf, 0x1000, ctypes.byref(nr))
                except Exception:
                    res["r"] = -1

            t = threading.Thread(target=run, daemon=True)
            t.start()
            t.join(0.05)
            if t.is_alive():
                return None
            if res.get("r", 1) != 0:
                return None
            slen = ctypes.cast(nbuf, ctypes.POINTER(wt.USHORT))[0]
            if slen <= 0:
                return None
            raw = nbuf.raw
            for off in (8, 12, 16, 4):
                try:
                    s = raw[off:off + slen].decode("utf-16-le", errors="ignore")
                except Exception:
                    continue
                if s:
                    return s
            return None

        def work(i):
            e = ENTRY.from_address(base + i * entry_size)
            pid = e.pid
            hv = e.hv
            if pid == 0 or pid == 4:
                return
            hproc = get_proc(pid)
            if not hproc:
                return
            dup = wt.HANDLE(0)
            if ntdll.NtDuplicateObject(hproc, hv, kernel32.GetCurrentProcess(),
                                       ctypes.byref(dup), 0, 0, 2) != 0:
                return
            try:
                name = query_name(dup)
            finally:
                kernel32.CloseHandle(dup)
            if name and src_tail in name.lower():
                with found_lock:
                    found_pids.add(pid)

        with concurrent.futures.ThreadPoolExecutor(max_workers=48) as ex:
            list(ex.map(work, range(count)))

        for k, h in open_cache.items():
            if h:
                kernel32.CloseHandle(h)

        names = set()
        for pid in found_pids:
            nm = procs.get(pid)
            if not nm:
                continue
            if skip_critical and nm in CRITICAL_NAMES:
                continue
            names.add(nm)
        return sorted(names)
    except Exception:
        return []
