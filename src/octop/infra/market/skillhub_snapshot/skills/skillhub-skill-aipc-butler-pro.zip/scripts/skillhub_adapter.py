#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""【SkillHub 商户支付适配层】

职责：把"创建订单 / 校验回调"与具体支付平台解耦。
  - 未开启真实模式 → SIMULATE：返回本地模拟支付页，便于本地跑通"价格↔订单↔授权码"。
  - 开启真实模式（SKILLHUB_REAL=1 + 微信三件套就位）→ 走**微信 Native 直连 + 本地轮询**（HANDOFF §6.2 选项 A）：
      微信 Native 下单 → 返回 code_url（前端展示二维码）→ server 定时用"查询订单"API 出站轮询
      → 返回 PAID 即 _fulfill_order 直写本机 license 解锁（零填码）。
      无需公网服务器、无需 pay_notify_url（出站调用 127.0.0.1 即可通）。

⚠️ 敏感凭证（商户证书私钥 / APIv3 key / Token）一律从本机安全文件读取（默认
   ~/.workbuddy/ai-pc-butler/skillhub_secrets.json），绝不进 skill 包/前端/config.json。
   生产环境应改用密钥管理服务。

真实链路所需（本地轮询支付）：
  - WECHAT_APPID            : 微信商户绑定的 appid（wx...）
  - WECHAT_APIV3_KEY        : 扫码支付 APIv3 密钥
  - wechat_merchant_key_pem : 商户 API 证书私钥（apiclient_key.pem，请求签名用）
  - wechat_merchant_serial  : 商户证书序列号（或给 wechat_merchant_cert_pem 自动推导）
  以上任一缺失，真实模式会在调用处抛出清晰报错，不静默失败。
  - SkillHub X402 通道（计划B）：本地 skill 调商户统一履约接口（x402_invoke_endpoint，取代裸 IP
    自建授权/支付服务器）走微信 Agent Pay X402 402→支付→200 履约闭环，消除安全扫描命中；
    SkillHub 预下单签名（x402_preorder_sign / build_payment_required）供商户后端调用。
    未配置履约端点则回退原链路（零影响）。
  - 后期可选：PAY_NOTIFY_URL（微信回调推送模式，需公网服务器）。
"""
import base64
import hashlib
import json
import os
import time
import uuid
import ssl
import urllib.parse

# PROD 包按安全规则排除 signing.py（仅云端授权/开发者本地真实支付才需要）。
# 改为可选导入：缺省置 None，SIMULATE 模式与云端授权不受影响；
# 仅当启用真实扫码支付（SKILLHUB_REAL=1）时才会用到，届时会在使用处明确报错。
try:
    import signing as signing_mod
except ImportError:
    signing_mod = None

HERE = os.path.dirname(os.path.abspath(__file__))

# 安全密钥文件（在 skill 包之外，本机后端读取）
_DEFAULT_SECRETS = os.path.join(
    os.path.expanduser("~"), ".workbuddy", "ai-pc-butler", "skillhub_secrets.json"
)


def load_secrets():
    """读取商户密钥。返回 dict；缺失则返回 {}（不影响 SIMULATE 模式）。"""
    path = os.environ.get("SKILLHUB_SECRETS", _DEFAULT_SECRETS)
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


SECRETS = load_secrets()

# 云端授权/支付服务地址与证书（来自 license.py，避免重复维护）。
# 失败则置空，cloud_order_enabled() 自动返回 False，云端下单不会误开启。
try:
    from license import AUTH_URL as _AUTH_URL, AUTH_CA_PEM as _AUTH_CA_PEM
except Exception:
    _AUTH_URL = ""
    _AUTH_CA_PEM = ""


# 真实模式：显式开关 + 密钥文件就位才启用；否则 SIMULATE（保持本地链路可用）
_SIM_FLAG = os.environ.get("SKILLHUB_REAL", "").lower() in ("1", "true")
SIMULATE = (not _SIM_FLAG) or (not SECRETS)


def is_simulate():
    # ⚠️ 安全闸门依赖此函数：默认态（生产/交付）SIMULATE=True → 返回 True，
    # 使 /pay_simulate 端点 403（禁用免费解锁的模拟收银台）。绝不可改其真值，
    # 否则会开放任何人免费解锁。其命名易误导：SIMULATE=True 并不代表「走模拟支付」，
    # 生产真实支付由 X402 通道承担（见 x402_enabled / payment_capability）。
    return SIMULATE


def payment_capability():
    """当前生效的支付通道——全局唯一事实来源，取代散落的 SIMULATE 判断。

    返回：
      - "x402"    : SkillHub X402 通道（线上 /invoke，默认生产真实支付，客户端不持密钥）
      - "cloud"   : 云端代下单（config.cloud_pay 开启）
      - "native"  : 本地微信 Native 直连（SKILLHUB_REAL=1 + 密钥就位）
      - "simulate": 本地模拟收银台（仅 AIPC_DEV_SIMULATE=1 的开发态）
      - "none"    : 无任何真实通道（仅配置预览态）
    """
    if x402_enabled():
        return "x402"
    if cloud_order_enabled():
        return "cloud"
    if not SIMULATE:
        creds, missing = _wechat_creds()
        if not missing:
            return "native"
    return "simulate" if SIMULATE else "none"


def is_real_configured():
    """支付版是否具备真实支付能力（任一真实通道可用即视为已配置）。

    修复旧实现：旧版在 SIMULATE=True 时直接返回 False，但生产真实支付由 X402
    承担（与 SIMULATE 解耦），导致默认生产态被误报「未配置」。现统一委托
    payment_capability() 判定，x402/cloud/native 任一可用即 True。
    """
    return payment_capability() in ("x402", "cloud", "native")


# ---------------------------------------------------------------------------
# 云端下单路由（报告页支付：客户端不再持任何商户私钥）
# ---------------------------------------------------------------------------
def cloud_order_enabled(force=None):
    """是否走云端代下单。

    驱动优先级：显式 force 参数 > 环境变量 AIPC_USE_CLOUD_ORDER(1/true) > 关闭。
    仅当云端地址(_AUTH_URL)已配置才视为可用；空值直接 False。
    生产包：server.py 依据 config.cloud_pay 显式传入 force=True。
    """
    if force is not None:
        return bool(force) and bool(_AUTH_URL)
    flag = os.environ.get("AIPC_USE_CLOUD_ORDER", "").lower() in ("1", "true")
    return flag and bool(_AUTH_URL)


def _auth_ssl_context():
    """系统默认证书校验 + 追加内嵌授权服务 CA 证书（证书固定 cert pinning，仅追加，不覆盖系统根），连接经 TLS 校验，仅信任我们自己的授权/支付服务器。"""
    ctx = ssl.create_default_context()
    if _AUTH_CA_PEM:
        ctx.load_verify_locations(cadata=_AUTH_CA_PEM)
    return ctx


def _post_auth(url_path, obj):
    """POST JSON 到云端授权/支付服务，返回 (http_status, parsed_dict)。

    用 _auth_ssl_context() 校验云端身份（防中间人）；连接失败抛 RuntimeError。
    """
    import urllib.request
    import urllib.error
    body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    url = _AUTH_URL.rstrip("/") + url_path
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "ai-pc-butler/1.7")
    try:
        with urllib.request.urlopen(req, timeout=20, context=_auth_ssl_context()) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        try:
            return e.code, json.loads(detail)
        except Exception:
            return e.code, {"ok": False, "error": detail[:300]}
    except urllib.error.URLError as e:
        raise RuntimeError("云端连接失败：" + str(getattr(e, "reason", e)))


def cloud_create_order(product_id, hwid):
    """云端代下单：返回 (ok, code_url, out_trade_no, price_cents)。

    金额由服务端 PRODUCT_PRICES 权威定价，客户端只传 product_id，防篡改 tier/价格。
    """
    st, data = _post_auth("/v1/create_order", {"product_id": product_id, "hwid": hwid})
    if data.get("ok") and data.get("code_url"):
        return True, data.get("code_url"), data.get("out_trade_no"), data.get("price_cents")
    raise RuntimeError("云端下单失败(%s)：%s" % (st, data.get("error", "未知错误")))


def cloud_order_status(out_trade_no, fulfill_token=""):
    """云端查单 + 自动履约：返回 {status, code, tier, trade_state, error}。

    status: paid（已付且已签码，含 code/tier）/ pending / error / not_found。
    已支付时云端已在服务端完成签码（do_order_status 内部走 do_fulfill），
    客户端据此本地授权即可，无需再调 /v1/fulfill。
    """
    st, data = _post_auth("/v1/order_status",
                          {"out_trade_no": out_trade_no, "fulfill_token": fulfill_token})
    if not isinstance(data, dict):
        data = {"status": "error", "error": "云端返回格式异常(%s)" % st}
    data.setdefault("status", "error")
    return data


# ---------------------------------------------------------------------------
# X402 AI 预下单签名（SKILLHUB-SHA256-RSA2048，5 行签名串，SHA256withRSA）
# ---------------------------------------------------------------------------
def _b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def x402_preorder_sign(payment_required_obj):
    """对 payment_required (L2 JSON) 做 X402 AI 预下单签名，返回完整 L1 请求体 dict。

    **签名串（5 行，每行以 \\n 结尾，最后一行也保留换行）—— 严格按 SkillHub 官方规范**：
        POST
        <预下单接口 path，取自 x402_endpoint() 的 URL path>
        <timestamp>
        <nonce_str>
        <payment_required_base64>

    用 SkillHub 开发者私钥（PKCS#8）做 SHA256withRSA（PKCS#1 v1.5），标准 base64（非 url-safe）。
    ⚠️ 注意顺序：timestamp 在前、nonce_str 在后（与旧占位实现相反）；payment_required
    字段即下方 Base64(L2) 字符串，签名串里用的也是同一个字符串。
    """
    if SIMULATE or not SECRETS:
        raise RuntimeError("真实模式未启用，无法做 X402 签名")
    developer_id = SECRETS["skillhub_mch_id"]
    pub_key_id = SECRETS["pub_key_id"]
    priv_pem = SECRETS["private_key_pem"]

    payment_required_b64 = base64.b64encode(
        json.dumps(payment_required_obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).decode("ascii")
    nonce_str = uuid.uuid4().hex
    timestamp = str(int(time.time()))  # 文档示例为字符串（Unix 秒）
    path = urllib.parse.urlparse(x402_endpoint()).path or "/palmpayminiapp/clawagentpay/preorder"
    sign_str = (
        "POST\n"
        f"{path}\n"
        f"{timestamp}\n"
        f"{nonce_str}\n"
        f"{payment_required_b64}\n"
    )
    if signing_mod is None:
        raise RuntimeError(
            "真实支付签名需要 signing 模块，但当前环境未提供（PROD 包已按安全规则排除 signing.py）。"
            "请改用 SIMULATE 模式或云端授权码，或在开发者本地环境中保留 signing.py 后再启用真实支付。"
        )
    signature = signing_mod.raw_sign(priv_pem, sign_str.encode("utf-8"))
    return {
        "signature_type": "SKILLHUB-SHA256-RSA2048",
        "developer_platform": "SKILLHUB",
        "developer_id": developer_id,
        "pub_key_id": pub_key_id,
        "nonce_str": nonce_str,
        "timestamp": timestamp,
        "signature": signature,
        "payment_required": payment_required_b64,
    }


# ---------------------------------------------------------------------------
# 计划B：SkillHub X402 通道（取代自建裸 IP 授权/支付服务器，消除安全扫描命中）
# ---------------------------------------------------------------------------
# ⚠️ 端点 / 回执机制由 SkillHub 开发者后台（Pay Skill / SkillPay 接入）提供。
#    老李拿到端点 URL + 回执方式后，仅需配置 SKILLHUB_X402_ENDPOINT（及回执模式），
#    本通道即自动优先于"云端代下单/微信 Native/模拟"，无需改其它代码。
#    未配置端点时 x402_enabled()=False，create_order 原样回退，零影响。
SKILLHUB_X402_ENDPOINT_DEFAULT = "https://payapp.weixin.qq.com/palmpayminiapp/clawagentpay/preorder"


def x402_endpoint():
    """SkillHub X402（微信 Agent Pay）预下单端点。

    配置优先级：环境变量 SKILLHUB_X402_ENDPOINT > secrets.skillhub_x402_endpoint > 内置官方默认。
    内置默认即 SkillHub 官方文档给出的预下单路径（base 域名以 SkillHub 后台为准，可 env 覆盖）。
    """
    return (os.environ.get("SKILLHUB_X402_ENDPOINT")
            or SECRETS.get("skillhub_x402_endpoint", "") or SKILLHUB_X402_ENDPOINT_DEFAULT).strip()


def x402_opt_in():
    """X402 通道开关。v1.7.7 起默认开启（商户后端 47.82.100.165:443 已上线并验证通过）。
    设 AIPC_USE_X402=0/false/off/no 可强制退回旧支付；X402 临时故障时也会自动回退云端支付，不丢单。"""
    v = os.environ.get("AIPC_USE_X402", "1").lower()
    if v in ("0", "false", "off", "no", "disabled"):
        return False
    return True


def x402_token():
    """X402 通道鉴权 Bearer Token（复用开发者入驻令牌 skillhub_token；若 SkillHub 另发临时 token 以环境变量覆盖）。"""
    return (os.environ.get("SKILLHUB_X402_TOKEN")
            or SECRETS.get("skillhub_token", "") or "").strip()


def x402_receipt_mode():
    """回执/履约机制：poll（轮询订单状态，默认，最稳）/ callback（SkillHub 回调本服务）/ sync（同步返回授权+履约）。

    ⚠️ 待老李从 SkillHub 确认实际回执方式后校准；默认 poll 与现有云端查单一致。
    """
    return (os.environ.get("SKILLHUB_X402_RECEIPT_MODE")
            or SECRETS.get("skillhub_x402_receipt_mode", "poll") or "poll").strip()


def x402_enabled(force=None):
    """是否走 SkillHub X402 通道（本地 skill 视角）。需显式 opt-in（AIPC_USE_X402=1）
    且商户履约端点（x402_invoke_endpoint）已配置才 True。

    默认关闭：即使 SkillHub 预下单端点已内置默认，本地 skill 也只在配置了自有商户履约
    域名后才启用 X402，防止割接前误开、或裸调 SkillHub 预下单而无履约端点收口。
    """
    if force is not None:
        return bool(force) and x402_opt_in() and bool(x402_invoke_endpoint())
    return x402_opt_in() and bool(x402_invoke_endpoint())


def build_payment_required(skill_id, skill_version, product_id, code_url, ttl_sec=900):
    """构造 X402 L2 业务 JSON（Base64 后作为 L1.payment_required）。

    严格按 SkillHub 官方商户 Demo（mch-demo）字段：
      skill_info: { skill_id, skill_version }
      pay_type:   "SKILL_PAY"
      pay_mode:   "AUTH_AND_PAY"
      pay_items:  [{ product_id, pay_data: { type:"code_url", value: code_url } }]
      expires_at: Unix 秒级时间戳（字符串）

    ⚠️ 关键（官方 Demo 实锤）：金额/商品名**不在** L2 里！
       金额与商品说明由商户在微信 Native 下单时确定（见 auth_server.do_invoke_x402），
       L2 仅把 Native 下单返回的 code_url 包进 pay_data，供微信/Agent 拉起支付。
       code_url 来自微信 Native 下单响应，调用方须先完成 Native 下单再构造本 L2。
    """
    return {
        "skill_info": {"skill_id": skill_id, "skill_version": skill_version},
        "pay_type": "SKILL_PAY",
        "pay_mode": "AUTH_AND_PAY",
        "pay_items": [
            {
                "product_id": product_id or "",
                "pay_data": {"type": "code_url", "value": code_url or ""},
            }
        ],
        "expires_at": str(int(time.time()) + int(ttl_sec)),
    }


def merchant_ai_preorder(payment_required_obj):
    """商户后端专用：对 L2 做 X402 签名并调 SkillHub 预下单，返回 payment_code。

    不经过 SIMULATE 门控（商户侧永远走真实链路）；密钥取自本机 secrets。
    依赖：secrets 含 skillhub_mch_id / pub_key_id / private_key_pem。
    本地 skill 视角（Agent）请勿调用——它只调商户 /invoke；本函数供 auth_server 复用。
    """
    if signing_mod is None:
        raise RuntimeError("真实支付签名需要 signing 模块（商户后端请保留 signing.py）。")
    developer_id = SECRETS.get("skillhub_mch_id")
    pub_key_id = SECRETS.get("pub_key_id")
    priv_pem = SECRETS.get("private_key_pem")
    if not (developer_id and pub_key_id and priv_pem):
        raise RuntimeError("SkillHub 开发者密钥缺失（skillhub_mch_id/pub_key_id/private_key_pem）")
    pr_b64 = base64.b64encode(
        json.dumps(payment_required_obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ).decode("ascii")
    nonce_str = uuid.uuid4().hex
    timestamp = str(int(time.time()))
    path = urllib.parse.urlparse(x402_endpoint()).path or "/palmpayminiapp/clawagentpay/preorder"
    sign_str = "POST\n%s\n%s\n%s\n%s\n" % (path, timestamp, nonce_str, pr_b64)
    signature = signing_mod.raw_sign(priv_pem, sign_str.encode("utf-8"))
    l1 = {
        "signature_type": "SKILLHUB-SHA256-RSA2048",
        "developer_platform": "SKILLHUB",
        "developer_id": developer_id,
        "pub_key_id": pub_key_id,
        "nonce_str": nonce_str,
        "timestamp": timestamp,
        "signature": signature,
        "payment_required": pr_b64,
    }
    data = _x402_preorder(x402_endpoint(), x402_token(), l1)
    code = data.get("payment_code") or data.get("pay_url") or data.get("code_url")
    if not code:
        raise RuntimeError("SkillHub 预下单未返回 payment_code：" + json.dumps(data, ensure_ascii=False)[:200])
    return code


def _x402_preorder(endpoint, token, signed_body):
    """SkillHub X402 预下单：POST signed_body 到 endpoint，解析支付触发信息。

    signed_body: x402_preorder_sign() 产出的完整签名请求体 dict。
    Authorization: Bearer <token>。返回解析后的 dict（宽松解析，兼容多种字段命名）：
      payment_code / pay_url / code_url：支付触发信息（前端展示，用户授权）
      out_trade_no / order_id：后续查单/履约单号
    失败时抛 RuntimeError（由调用方捕获并回退，不丢单）。
    """
    import urllib.request
    import urllib.error
    body = json.dumps(signed_body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(endpoint, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("Authorization", "Bearer " + (token or ""))
    req.add_header("User-Agent", "ai-pc-butler/1.7")
    try:
        with urllib.request.urlopen(req, timeout=20, context=_auth_ssl_context()) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        raise RuntimeError("X402 预下单失败(%s)：%s" % (e.code, detail[:300]))
    except urllib.error.URLError as e:
        raise RuntimeError("X402 连接失败：" + str(getattr(e, "reason", e)))
    if not isinstance(data, dict):
        raise RuntimeError("X402 返回格式异常")
    return data


def _parse_x402_fulfilled(data, order_id):
    """解析商户 /invoke 200 履约响应 → 统一 {status, code, tier, ...}。

    content 字段即履约凭证（授权码/权益）；已支付时本地据此解锁 tier。
    """
    if not isinstance(data, dict):
        return {"status": "error", "error": "X402 履约返回格式异常"}
    code = data.get("content") or data.get("code_value") or data.get("activation")
    return {
        "status": "paid",
        "code": code,
        # AIPC-TIER-DEFAULT-FIX（v1.7.76）：原先兜底值写 2（Pro），方向错 ——
        # 服务端 200 履约响应本身**不带 tier 字段**（auth_server.do_invoke_x402 返回的是
        # content / transaction_id / already_fulfilled），所以这里恒等于 2。
        # 档位永远应由「授权码里写死的 tier」决定，不该由客户端兜底值决定；
        # 兜底只应取最小权限（0），避免任何误用把用户"升级"到更高档。
        "tier": data.get("tier") or 0,
        # AIPC-INSTANT-UNLOCK（v1.7.79）：把「签发时绑定的机器」和「服务端签名」一起带出来。
        # 有了这两个字段，本机就能离线自证"这张码是真的、等级是 N、且属于本机"，
        # 于是"付款成功 → 解锁"不再依赖任何一次网络往返（网络抖动 / 限流 / 服务重启
        # 都卡不住付费用户）。字段缺失时保持空串，走原有的云端激活兜底，行为不变。
        "bound_hwid": data.get("bound_hwid") or data.get("hwid") or "",
        "signature": data.get("signature") or data.get("sig") or "",
        "trade_state": "SUCCESS",
        "transaction_id": data.get("transaction_id"),
        "already_fulfilled": data.get("already_fulfilled", False),
        "out_trade_no": data.get("out_trade_no") or order_id,
        "raw": data,
    }


def x402_invoke_endpoint():
    """商户侧统一履约接口（取代裸 IP 自建授权/支付服务器）。

    配置优先级：环境变量 SKILLHUB_X402_INVOKE_ENDPOINT > secrets.skillhub_x402_invoke_endpoint
    > 内置默认 https://47.82.100.165/invoke（443 与授权服务共用，skill 包已内嵌 CA 做证书固定 cert pinning）。
    未配置且默认也不可达时，create_order 回退原链路，零影响。
    """
    return (os.environ.get("SKILLHUB_X402_INVOKE_ENDPOINT")
            or SECRETS.get("skillhub_x402_invoke_endpoint", "")
            or "https://47.82.100.165/invoke").strip()


def create_x402_order(product, hwid, base_url, order_id, product_id=None):
    """SkillHub X402 下单（本地 skill 视角 = Agent）：调用商户 /invoke → 解析 402 → 返回支付触发信息。

    文档流程（统一接口）：POST /invoke（无 X-Out-Trade-No 头）→ 商户后端做微信 Native 下单
    + SkillHub AI 预下单 → 返回 HTTP 402 + WeixinPay-Required(payment_code) + X-Out-Trade-No
    + amount。本地 skill 据此向用户展示支付码（二维码），用户扫码支付后由前端轮询
    x402_order_status 取履约（重试 /invoke 带 X-Out-Trade-No → 200 + content）。

    返回 dict：{"mode": "x402", "payment_code":..., "out_trade_no":..., "amount":..., "currency":...}
    """
    pid = product_id or (product or {}).get("product_id") or (product or {}).get("id") or ""
    if not pid:
        raise RuntimeError("X402 下单缺 product_id")
    ep = x402_invoke_endpoint()
    if not ep:
        raise RuntimeError("X402 商户履约端点未配置（SKILLHUB_X402_INVOKE_ENDPOINT）")
    import urllib.request
    import urllib.error
    body = json.dumps({"query": "unlock_pro:" + pid, "hwid": hwid or ""}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(ep, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "ai-pc-butler/1.7")
    try:
        # v1.7.20：超时 20s→8s（目标机实测：服务不可达时用户等 10s 才见错误，体验差；
        # 8s 足够正常下单，不可达时更快失败）。配合 create_order 失败明确报错，不回退 simulate。
        with urllib.request.urlopen(req, timeout=8, context=_auth_ssl_context()) as r:
            # 极少数情况直接 200（已履约，幂等返回）
            return _parse_x402_fulfilled(json.loads(r.read().decode("utf-8")), order_id)
    except urllib.error.HTTPError as e:
        if e.code != 402:
            detail = e.read().decode("utf-8", "ignore")
            raise RuntimeError("X402 商户接口错误(%s)：%s" % (e.code, detail[:300]))
        # 正常 402：从响应头 + 响应体提取支付码与订单号
        pay_code = (e.headers.get("WeixinPay-Required")
                    or e.headers.get("weixinpay-required"))
        try:
            body_data = json.loads(e.read().decode("utf-8"))
        except Exception:
            body_data = {}
        if not pay_code:
            pay_code = (body_data.get("WeixinPay", {}) or {}).get("WeixinPay-Required")
        out_trade_no = (e.headers.get("X-Out-Trade-No")
                        or e.headers.get("x-out-trade-no")
                        or body_data.get("out_trade_no") or order_id)
        return {
            "mode": "x402",
            "payment_code": pay_code,
            "pay_url": pay_code,
            "out_trade_no": out_trade_no,
            "order_id": order_id,
            "amount": body_data.get("amount"),
            "currency": body_data.get("currency", "CNY"),
            "code_url": body_data.get("code_url"),  # 商户额外返回，供降级扫码（若 weixinpay 插件不可用）
            "receipt_mode": "invoke_402",
            "raw": body_data,
        }


def x402_order_status(out_trade_no, fulfill_token=""):
    """X402 履约查询（支付后重试商户 /invoke 并带 X-Out-Trade-No 头 → 200 + content）。

    文档流程：POST /invoke + Header X-Out-Trade-No → 商户后端查单(微信) → 返回 200
    + content(履约凭证/授权码) + transaction_id + already_fulfilled。
    返回 {status, code, tier, trade_state, error}：已支付时 code=content，本地据此解锁。
    """
    ep = x402_invoke_endpoint()
    if not ep:
        raise RuntimeError("X402 商户履约端点未配置（SKILLHUB_X402_INVOKE_ENDPOINT）")
    import urllib.request
    import urllib.error
    body = json.dumps({"query": "unlock_pro"}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(ep, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("X-Out-Trade-No", out_trade_no or "")
    req.add_header("User-Agent", "ai-pc-butler/1.7")
    try:
        with urllib.request.urlopen(req, timeout=8, context=_auth_ssl_context()) as r:
            return _parse_x402_fulfilled(json.loads(r.read().decode("utf-8")), out_trade_no)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        if e.code == 402:
            return {"status": "pending", "trade_state": "NOTPAY", "error": "订单尚未支付"}
        return {"status": "error", "error": "X402 履约查询失败(%s)：%s" % (e.code, detail[:200])}
    except urllib.error.URLError as e:
        # v1.7.23（生产修复）：网络超时/连接失败 ≠ 订单错误——返回 pending + network_error，
        # server 据此保持 pending 让前端继续轮询重试，杜绝「已付款却被确认失败」
        # （本机实测：23:03 查单一次 timed out，升级订单被误标 error）。
        return {"status": "pending", "network_error": True,
                "error": "X402 连接失败：" + str(getattr(e, "reason", e))}


# ---------------------------------------------------------------------------
# 创建订单
# ---------------------------------------------------------------------------
def create_order(product, hwid, base_url, order_id, product_id=None, cloud_order=None):
    """创建支付订单，返回 dict：

      SIMULATE: {"mode": "simulate", "pay_url": <本地模拟收银台>, "order_id": ...}
      REAL    : {"mode": "real", "code_url": <微信二维码>, "out_trade_no": ..., "order_id": ...}

    cloud_order: 显式开关（通常由 server 依据 config.cloud_pay 传入），仅作云端代下单的兜底通道。
      X402 主通道与之解耦、独立常开（x402_opt_in 默认 True + x402_invoke_endpoint 默认指向线上
      /invoke），确保即便 cloud_pay=false 也能出真实微信码，不会退化成"配置预览"。
    product_id : 产品键（std_buyout/pro_buyout/std_pro_upgrade），云端据此权威定价。
    order_id: 由 server 生成的订单号（轮询以此为准）。
    base_url: 报告页服务地址，如 http://127.0.0.1:4210
    product : dict，含 tier / fee_cents / name 等（来自 config.json plans）。
    hwid    : 下单身份标识，原样透传给商户端 /invoke（服务端据此做「首次下单必须带
              hwid/user_id，否则 400 IDENTITY_REQUIRED」的身份闸门校验）。
              注意：**下单这一步不绑机** —— 绑机只发生在 /v1/activate 首次激活时。
              v1.7.76 更正：此处原先写「绑机在 _fulfill_order 内按 order.device_bound
              判定」，与代码不符 —— _fulfill_order 里没有这段逻辑；device_bound 是
              config.json 里的方案表字段，本地代码把它抄进订单对象后**无人读取**。
    """
    # ===== 主通道：SkillHub X402（线上 /invoke 已验证出真实微信码，客户端不持任何密钥）=====
    # 与 cloud_order 开关解耦，x402_enabled() 独立判断（opt-in 默认开 + 端点默认指向线上），
    # 确保无论 cloud_pay 取值都能出真实微信码，不退化成"配置预览"。
    if x402_enabled():
        try:
            return create_x402_order(product, hwid, base_url, order_id, product_id=product_id)
        except Exception as _e:
            import sys
            # v1.7.20（目标机实测）：X402 失败**不再静默回退 simulate**——simulate 在生产环境
            # 是死路（/pay_simulate 403「模拟收银台已禁用」），用户看到的是开发态文案且无法支付。
            # 改为：若有云端兜底则试云端；否则**抛明确错误**，前端展示「支付服务连接失败」。
            # v1.7.76 更正：此处原先写「同时保留"网络抖动自动重试一次"的韧性」，
            # 与代码不符 —— 实际**没有重试**：X402 失败即转云端兜底，或直接抛错。
            sys.stderr.write("[x402] 预下单失败：%s\n" % _e)
            if cloud_order_enabled(force=cloud_order):
                pass  # 走到下方云端分支
            else:
                raise RuntimeError("支付服务连接失败（网络不可达或服务暂不可用），请检查网络后重试：%s" % (_e,))

    # ===== 兜底：云端代下单（仅当 cloud_order 开启且 X402 不可用时；当前线上未部署 /v1/create_order 会 404）=====
    if cloud_order_enabled(force=cloud_order):
        pid = product_id or (product or {}).get("product_id") or (product or {}).get("id") or ""
        if not pid:
            raise RuntimeError("云端下单缺 product_id（产品字典未含 product_id 字段）")
        try:
            ok, code_url, out_trade_no, _price = cloud_create_order(pid, hwid)
            return {"mode": "real", "code_url": code_url, "out_trade_no": out_trade_no, "order_id": order_id}
        except Exception as _cloud_e:
            import sys
            # v1.7.20：cloud 失败不再回退 simulate（生产死路），抛明确错误
            sys.stderr.write("[cloud] 云端下单失败：%s\n" % _cloud_e)
            raise RuntimeError("支付服务连接失败（云端下单不可用），请检查网络后重试：%s" % (_cloud_e,))

    if SIMULATE:
        pay_url = base_url.rstrip("/") + "/pay_simulate?order_id=" + order_id
        return {"mode": "simulate", "pay_url": pay_url, "order_id": order_id}

    # ===== 真实模式：微信 Native 直连 + 本地轮询（开发机本地密钥）=====
    # 不需要公网服务器、不需要 pay_notify_url：server 用"查询订单"API 出站轮询即可。
    creds, missing = _wechat_creds()
    if missing:
        raise RuntimeError(
            "真实下单缺配置（无法发起微信 Native 支付）：" + ", ".join(missing)
            + "。需老李从微信商户平台补全（HANDOFF §6.2）。"
        )
    serial = _wechat_serial(creds)
    if not serial:
        raise RuntimeError(
            "无法取得微信商户证书序列号：请补全 wechat_merchant_serial，"
            "或提供 wechat_merchant_cert_pem 自动推导。"
        )
    # out_trade_no 须符合微信 6-32 位规则；order_id 本身已是唯一 UUID，无需前缀。
    out_trade_no = order_id
    wx_body = {
        "appid": creds["appid"],
        "mchid": creds["mch_id"],
        "description": product.get("name", "C盘清理升级"),
        "out_trade_no": out_trade_no,
        "notify_url": base_url.rstrip("/") + "/pay_callback",
        "amount": {"total": int(product["fee_cents"]), "currency": "CNY"},
    }
    # 微信 Native 下单（WECHATPAY2-SHA256-RSA2048 签名 + 商户证书私钥），返回 code_url
    code_url = _wechat_native_order(wx_body, creds, serial)
    return {"mode": "real", "code_url": code_url, "out_trade_no": out_trade_no, "order_id": order_id}


# ---------------------------------------------------------------------------
# 微信商户凭证 & v3 API 请求签名（本地轮询支付核心）
# ---------------------------------------------------------------------------
def _wechat_creds():
    """读取微信商户凭证；返回 (creds_dict, missing_list)。

    本地轮询支付（HANDOFF §6.2 选项 A）只需：
      - wechat_appid            : 微信商户绑定的 appid（wx...）
      - wechat_apiv3_key        : APIv3 密钥（保留，回调验签才会用到）
      - wechat_mchid            : 微信商户号（secrets 已有）
      - wechat_merchant_key_pem : 商户 API 证书私钥（apiclient_key.pem），请求签名用
      - wechat_merchant_serial  : 商户证书序列号（缺省从 wechat_merchant_cert_pem 推导）
    平台证书仅回调验签需要，本地轮询不依赖；pay_notify_url / X402 为后期可选。
    """
    creds = {
        "appid": os.environ.get("WECHAT_APPID") or SECRETS.get("wechat_appid"),
        "apiv3": os.environ.get("WECHAT_APIV3_KEY") or SECRETS.get("wechat_apiv3_key"),
        "mch_id": SECRETS.get("wechat_mchid"),
        "key_pem": os.environ.get("WECHAT_MERCHANT_KEY") or SECRETS.get("wechat_merchant_key_pem"),
        "serial": os.environ.get("WECHAT_MERCHANT_SERIAL") or SECRETS.get("wechat_merchant_serial"),
        "cert_pem": os.environ.get("WECHAT_MERCHANT_CERT") or SECRETS.get("wechat_merchant_cert_pem"),
    }
    missing = []
    if not creds["appid"]:
        missing.append("wechat_appid")
    if not creds["apiv3"]:
        missing.append("wechat_apiv3_key")
    if not creds["mch_id"]:
        missing.append("wechat_mchid")
    if not creds["key_pem"]:
        missing.append("wechat_merchant_key_pem")
    if not creds["serial"] and not creds["cert_pem"]:
        missing.append("wechat_merchant_serial(或 wechat_merchant_cert_pem)")
    return creds, missing


def _wechat_serial(creds):
    """优先用显式 serial；否则从商户证书 PEM 推导序列号（hex 大写，去冒号）。"""
    if creds.get("serial"):
        return creds["serial"].replace(":", "").upper()
    cert_pem = creds.get("cert_pem")
    if not cert_pem:
        return None
    from cryptography import x509
    cert = x509.load_pem_x509_certificate(cert_pem.encode("utf-8"))
    return format(cert.serial_number, "X")


def _wechat_sign(method, url_path, body_str, creds, serial):
    """生成微信 v3 请求签名，返回 Authorization 头字符串。
    method: GET/POST（大写）；url_path: 含 query 的完整 path（不含域名）；
    body_str: 请求体原文（GET 为空串）。
    """
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives import hashes
    timestamp = str(int(time.time()))
    nonce = uuid.uuid4().hex
    message = "%s\n%s\n%s\n%s\n%s\n" % (method, url_path, timestamp, nonce, body_str)
    key = serialization.load_pem_private_key(creds["key_pem"].encode("utf-8"), password=None)
    signature = key.sign(message.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())
    sig_b64 = base64.b64encode(signature).decode("ascii")
    return ('WECHATPAY2-SHA256-RSA2048 mchid="%s",nonce_str="%s",signature="%s",'
            'timestamp="%s",serial_no="%s"') % (
        creds["mch_id"], nonce, sig_b64, timestamp, serial)


def _wechat_post(url_path, body_obj, creds, serial):
    import urllib.request
    body = json.dumps(body_obj, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.mch.weixin.qq.com" + url_path, data=body, method="POST")
    req.add_header("Authorization", _wechat_sign("POST", url_path, body.decode("utf-8"), creds, serial))
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "ai-pc-butler/1.7")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        raise RuntimeError("微信 Native 下单失败(%s)：%s" % (e.code, detail[:300]))


def _wechat_get(url_path, creds, serial):
    import urllib.request
    req = urllib.request.Request("https://api.mch.weixin.qq.com" + url_path, method="GET")
    req.add_header("Authorization", _wechat_sign("GET", url_path, "", creds, serial))
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "ai-pc-butler/1.7")
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        raise RuntimeError("微信订单查询失败(%s)：%s" % (e.code, detail[:300]))


def _wechat_native_order(wx_body, creds, serial):
    """微信 Native 下单，返回 code_url（前端展示微信二维码）。"""
    data = _wechat_post("/v3/pay/transactions/native", wx_body, creds, serial)
    code_url = data.get("code_url")
    if not code_url:
        raise RuntimeError("微信未返回 code_url：" + json.dumps(data, ensure_ascii=False)[:200])
    return code_url


# （X402 预下单真实实现见上方 _x402_preorder()，计划B 已落地；配置端点后自动启用，未配置则回退原链路。）


# ---------------------------------------------------------------------------
# 校验回调 / 查询订单
# ---------------------------------------------------------------------------
def verify_callback(payload, signature):
    """校验扫码支付成功回调（含金额比对）。模拟模式直接 True。

    真实实现（待补）：用微信平台证书验签回调报文 → 按 out_trade_no 查本地订单
    → 比对回调金额与订单金额 → 返回 paid 与否（幂等）。需 WECHAT_APIV3_KEY + 平台证书。
    """
    if SIMULATE:
        return True
    raise NotImplementedError(
        "微信回调验签未实现：需 WECHAT_APIV3_KEY + 微信平台证书解密/验签，并比对 out_trade_no 金额。"
    )


def query_order(out_trade_no, creds=None, serial=None):
    """按 out_trade_no 向微信查询交易状态（本地轮询确认支付）。

    返回 dict: {"state": <trade_state>, "paid": bool, "raw": <response>}
    trade_state 明文返回（SUCCESS / NOTPAY / CLOSED / ...），无需 APIv3 解密。
    SIMULATE 模式返回 None（由本地 /simulate_paid 直接置 paid）。
    """
    if SIMULATE:
        return None
    if creds is None or serial is None:
        creds, missing = _wechat_creds()
        if missing:
            raise RuntimeError("微信查询缺配置：" + ", ".join(missing))
        serial = _wechat_serial(creds)
    data = _wechat_get("/v3/pay/transactions/out-trade-no/" + out_trade_no + "?mchid=" + creds["mch_id"], creds, serial)
    state = data.get("trade_state", "")
    return {"state": state, "paid": state == "SUCCESS", "raw": data}
