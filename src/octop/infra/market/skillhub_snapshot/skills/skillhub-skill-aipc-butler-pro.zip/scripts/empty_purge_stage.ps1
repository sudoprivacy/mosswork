# Clean fast_purge staging dirs so "deleted" always means real space freed on C.
# fast_purge renames a tree here (same-volume, instant) and a bg daemon thread
# physically deletes it. If that daemon dies (server exit / tool close / timeout),
# files stay here forever on C. Real leftover seen on user machine: 44.75MB / 4 items.
# v1.7.100 fixes:
#   1) the old script only cleaned TEMP paths, but the real staging dir since
#      v1.7.85 is C:\aipc_purge (fallback C:\ProgramData\aipc_purge) - so cleaning
#      only relocated files instead of freeing them.
#   2) deletion goes through System.IO.File.Delete / Directory.Delete (real NT
#      delete) instead of Remove-Item, so a safe-delete layer cannot redirect it
#      into the Recycle Bin - a trashed file still occupies C:. This matches
#      migrate._win_delete / _fast_delete_dir semantics.
# Safety: only dirs ending in aipc_purge; delete child items one by one and keep
# the staging dir itself (avoids racing with a concurrent fast_purge rename).
# Idempotent, hidden, silent on failure (retried next run).
$ErrorActionPreference = 'SilentlyContinue'

function Remove-TreeReally([string]$full) {
    try {
        if ([System.IO.Directory]::Exists($full)) {
            [System.IO.Directory]::Delete($full, $true)
            return $true
        }
        if ([System.IO.File]::Exists($full)) {
            [System.IO.File]::SetAttributes($full, [System.IO.FileAttributes]::Normal)
            [System.IO.File]::Delete($full)
            return $true
        }
    } catch {
    }
    return $false
}

$stageDirs = New-Object System.Collections.ArrayList
$null = $stageDirs.Add('C:\aipc_purge')
$null = $stageDirs.Add('C:\ProgramData\aipc_purge')
$null = $stageDirs.Add((Join-Path ([System.IO.Path]::GetTempPath()) 'aipc_purge'))
$localAppData = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::LocalApplicationData)
if ($localAppData) {
    $null = $stageDirs.Add((Join-Path $localAppData 'Temp\aipc_purge'))
}

foreach ($stage in $stageDirs) {
    if (-not $stage) { continue }
    if ($stage -notmatch '(?i)aipc_purge$') { continue }
    if (-not [System.IO.Directory]::Exists($stage)) { continue }
    $kids = @(Get-ChildItem -LiteralPath $stage -Force -ErrorAction SilentlyContinue)
    foreach ($k in $kids) {
        $null = Remove-TreeReally $k.FullName
    }
}
