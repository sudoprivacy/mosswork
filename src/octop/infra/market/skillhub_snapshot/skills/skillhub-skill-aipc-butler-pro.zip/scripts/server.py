#!/usr/bin/env python3
"""Serve the storage report with a guarded one-click delete API (macOS + Windows).

Starts on 127.0.0.1 + a random port + a random per-session token, serves the
interactive report, and exposes POST /action to move green-tier paths to Trash
or delete them outright. Stop with Ctrl+C.

Usage:
    server.py <analysis.json>

SAFETY MODEL — read before changing:
- Allowlist: only paths listed in this report's green items `trash_paths` are
  accepted. Every request path is realpath-resolved and must be in the allowlist
  AND under $HOME. Anything else is rejected. This is the core guard — the
  endpoint cannot be used to delete arbitrary files.
- Bound to 127.0.0.1 only; every POST requires the session token; Host header
  must be 127.0.0.1 (blocks DNS-rebinding from a malicious page).
- Two modes: "trash" (Finder -> Trash, reversible) and "rm" (immediate,
  irreversible). The browser confirms each action before sending.
"""
import base64
import atexit
import json
import os
import secrets
import shutil
import subprocess
import sys
import time
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from concurrent.futures import ThreadPoolExecutor, as_completed

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)  # 允许 import 同目录的 license.py
TEMPLATE = os.path.join(HERE, "..", "assets", "report_template.html")
HOME = os.path.realpath(os.path.expanduser("~"))
TOKEN = secrets.token_urlsafe(24)

# 本地许可门控：纯本地验签，零网络。server.py 的 rm/trash/open 都受 tier 约束。
import license as license_mod
import migrate as migrate_mod
from migrate import classify_lock as _classify_block_type  # 探测函数收口到 migrate.py 共用
# 释放区间『保底/上限/差距』计算统一收口到 build_report._inject_release_range（单一真理源，消除三处重复口径漂移）
from build_report import _inject_release_range
# signing 仅在开发/内测打包里存在（PROD 包按安全规则排除 signing.py），
# 故改为可选导入，缺省置 None——server.py 运行时不依赖它，避免 PROD 用户一启动即崩。
try:
    import signing as signing_mod
except ImportError:
    signing_mod = None
import skillhub_adapter as shub
import uuid

# 授权/履约服务使用 HTTPS；出站请求由 skillhub_adapter._auth_ssl_context()
# 与 license._do_post_activate 注入内嵌的授权服务 CA 证书（证书固定 cert pinning，仅追加，不覆盖系统根），
# 确保所有 HTTPS 请求经 TLS 校验、「付款→解锁」链路不中断。
try:
    import ssl as _ssl  # noqa: F401
except Exception:
    pass

DATA = {}
TPL = ""
RM_ALLOW = set()
TRASH_ALLOW = set()
OPEN_ALLOW = set()
MIGRATE_ALLOW = set()
CLEAN_STATE_PATH = ""  # 清理/迁移状态持久化文件（与 analysis.json 同目录）
ORDERS_PATH = ""       # 支付订单持久化（%APPDATA%/AI_PC_Butler/orders.json）
PRODUCTS = {}          # 方案表（从 config.json 加载）：plan_id -> {tier,fee_cents,...}
CFG = {}               # 应用配置（从 config.json 加载）
BASE_URL = ""          # 报告服务地址，在 main() 中按实际端口动态生成
# 日志写到用户数据目录（%APPDATA%/AI_PC_Butler），【绝不写回技能目录】。
# 若 server 从原技能目录拉起（run.py 临时副本拷贝失败回退场景），日志文件句柄会锁住
# 技能目录，导致 WorkBuddy 卸载技能时 "文件正在使用" 失败。重定向后彻底消除该锁。
try:
    _DATA_DIR = license_mod.get_data_dir()
except Exception:
    _app = os.environ.get("APPDATA") or os.path.join(
        os.environ.get("USERPROFILE") or os.path.expanduser("~"), "AppData", "Roaming")
    _DATA_DIR = os.path.join(_app, "AI_PC_Butler")
try:
    os.makedirs(_DATA_DIR, exist_ok=True)
except Exception:
    pass
LOG_FILE = os.path.join(_DATA_DIR, "server.log")
# 无请求空闲超时：server 启动后若 N 秒没有任何 HTTP 请求，自动退出。
# AIPC-REPORT-OPEN-FIX（v1.7.66 审查6）：原实现默认 0 = 永不退出，导致 run.py 末尾的
# proc.wait() 永远等不到 server 结束 —— 用户视角就是「任务在后台一直跑、永远不结束」。
# 现改为默认 7200 秒（2 小时）无任何请求即回收，理由：
#   · 有请求（看报告 / 一键清 / 迁移 / 付款）就刷新计时 → 绝不打断用户正在做的事；
#   · 2 小时无任何操作基本可判定用户已离开，此时回收安全，且任务终于有终点；
#   · 原注释担心「清理+迁移+决策超过 30 分钟就自杀会误伤」——2 小时窗口已远大于该场景；
#     如确需长期挂起，可显式设 AIPC_IDLE_TIMEOUT 调大；设 0 则恢复"永不自杀"。
INACTIVITY_TIMEOUT = int(os.environ.get("AIPC_IDLE_TIMEOUT", "7200"))
LAST_REQUEST_TIME = time.time()
SERVER_INSTANCE = None
# AIPC-DEADPLAN-PURGE：原 _GREEN_TRASH_ITEMS / _MIG_SRC_KB 两个全局，以及依赖它们的
# _planned_freed_kb()「用计划大小估算已释放」，已整套删除 —— 那是 fast_purge 时代
# 的遗留，全仓零调用点，留着只会让人误判「估算值还在当释放量用」。
# 现在释放量只有两个事实源，且职责分离：
#   · 标称估算：action 处理函数内的局部 _green_attr（[(norm_trash_paths_set, kb)]）
#   · 磁盘实测：_calibrate_freed / _calibrate_migrate_freed 写出的 freed / freed_gb
# 报告页「本次释放」只取实测（见 AIPC-SETTLE-TRUTH-FIX）。


def _norm_path(p):
    if not p:
        return ""
    return os.path.normpath(p).lower().replace("/", "\\")


# 创建子进程时不显示黑色控制台窗口（Windows）。用于清理/迁移命令（cmd/robocopy/
# takeown/icacls/schtasks/taskkill 等），避免用户看到一堆黑框而恐慌/退款。
try:
    CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW
except AttributeError:
    CREATE_NO_WINDOW = 0x08000000

# 后台 purge 线程等待上限（秒）：等暂存区 rd 真正释放磁盘后再测「真实释放量」。
# 老值 120s 让前端「进度满但弹窗不出现」等 1~5 分钟被用户骂死。改为 8s：实测
# rename 已把 inode 移走，rd 只是清理 staging，后台继续；前端的 freed_gb 取
# 此刻 disk_free 的差额，数字偏差很小但弹窗立刻出现，体验丝滑。
PURGE_WAIT_S = 8

# 后台线程登记（回收站清空等），供 handler 等待其完成以准确测量释放量。
_BG_THREADS = []

def _disk_free_bytes(drive):
    """返回某盘当前可用字节数（磁盘实测），用于核算『真实释放量』。

    是多少就是多少：清理/迁移前后各测一次，差值即用户真实拿回的空间，
    彻底规避旧逻辑用扫描时计划 kb 估算导致的「清了 10GB 显示 2GB」类偏差。
    """
    try:
        import shutil
        d = drive if drive else "C:"
        return shutil.disk_usage(d).free
    except Exception:
        # AIPC-FREED-DEDUP-FIX：读不到必须返回 None，绝不返回 0。
        # 返回 0 会被下游当成"这块盘一点空间都没了"→ 报告页算出「C 盘已用 100% /
        # 仅剩 0 GB / 清理后还有 120 GB」这种自相矛盾的画面（真机实测发生过）。
        # None = 不知道；调用方据此跳过校准，而不是拿 0 当真值去算。
        return None


def _log(fmt, *a):
    try:
        msg = fmt % a if a else fmt
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


def _mig_warn_text(ev):
    """v1.7.85：把迁移告警翻成人话（小白能懂），并明确给出「现在该怎么办」。

    老李 2026-10-04 实测 4h48m 零进展时，页面上唯一的信息是一个冻结的 93.4%，
    既没说卡在哪、也没说停了多久、更没说还能不能等 —— 用户只能干等。
    这里保证每条告警都包含三件事：①现在什么状态 ②已经停滞多久 ③你该做什么。
    """
    ev = ev or {}
    if ev.get("kind") == "stall":
        _idle = int(ev.get("idle_sec") or 0)
        _cur = float(ev.get("progress_mb") or 0)
        _tot = float(ev.get("total_mb") or 0)
        if _idle < 60:
            return ("复制速度暂时降下来了（%d 秒没新增数据），正在继续。"
                    "如果超过 2 分钟还停在这里，我会自动中止并保留已搬好的部分，"
                    "你的数据一个都不会丢。" % _idle)
        return ("这一项已经 %d 秒没有任何进展了（停在 %.0f / %.0f MB）。"
                "多半是有软件正在占用里面的文件。"
                "我会在 2 分钟内自动中止，把已经搬好的部分保留下来，"
                "不会硬撑着一直卡 —— 你的数据不会丢。"
                "想现在就让它继续：先退出微信/QQ/浏览器/网盘等软件，再点一次迁移即可。" % (_idle, _cur, _tot))
    return str(ev.get("msg") or "")

# 应用名/指纹/版本/渠道（与 build_report.py 一致）——server 服务的交互报告也要
# 替换这些占位，否则页面会残留 __BRAND__ / __VER__ 等字面量。
QR_IMAGE = os.path.join(HERE, "..", "assets", "qr_wechat.png")
_BRAND_DEFAULTS = {
    "app_name": "C盘清理 · 腾讯 WorkBuddy 驱动",
    "fingerprint": "DEMO-未授权",
    "version": "v0.0-DEMO",
}


def _qr_data_uri():
    """支付码转 base64 data URI，嵌入单文件报告，无需外部依赖。"""
    try:
        with open(QR_IMAGE, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        return "data:image/png;base64," + b64
    except Exception:
        return ("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAAL"
                "AAAAAABAAEAAAIBRAA7")


def _qr_for_text(text, box=6, border=2):
    """把任意字符串（如扫码支付 code_url）渲染成 SVG data URI，供前端展示支付码。

    不依赖 PIL：直接用 vendored 的 qrcode 包生成布尔矩阵，再手动画成 SVG。
    扫码 Native 支付的 code_url 以 weixin:// 开头，长度通常在 120~180 字符，
    ERROR_CORRECT_M + 自动版本即可稳定容纳。
    """
    try:
        import qrcode
        qr = qrcode.QRCode(version=None,
                           error_correction=qrcode.constants.ERROR_CORRECT_M,
                           box_size=box, border=border)
        qr.add_data(text)
        qr.make(fit=True)
        modules = qr.modules
        n = len(modules)
        size = n * box + border * 2 * box
        # 用 <rect> 逐模块绘制，模块尺寸 box，无间隙
        rects = []
        y = border * box
        for row in modules:
            x = border * box
            for cell in row:
                if cell:
                    rects.append('<rect x="%d" y="%d" width="%d" height="%d"/>' % (x, y, box, box))
                x += box
            y += box
        svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">'
            '<rect width="%d" height="%d" fill="#ffffff"/>%s</svg>'
        ) % (size, size, size, size, size, size, "".join(rects))
        return "data:image/svg+xml;base64," + base64.b64encode(svg.encode("utf-8")).decode("ascii")
    except Exception:
        return None


def _load_app_config():
    cfg = dict(_BRAND_DEFAULTS)
    cp = os.path.join(HERE, "config.json")
    if os.path.exists(cp):
        try:
            with open(cp, "r", encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    return cfg


# ===== 订单：价格↔授权码映射 =====
def _load_orders():
    """读订单（跨进程互斥读）。

    AIPC-ORDER-READ-LOCK（v1.7.76）：原先这里是**裸读**，与写方的 os.replace
    并发时有两个后果 ——
      ① Windows 的 MoveFileEx 遇到「目标文件正被打开」会报 WinError 5 拒绝访问，
         写方那一次写入直接丢失（实测 400 次写丢 1 条，且旧版是静默吞掉、
         表现为「莫名丢订单」）；
      ② 替换的瞬间目标文件可能短暂不存在，裸读会 except 成 {}，后续写回就等于
         从空档重来（丢掉**全部**订单，不只丢一条）。
    所以读也必须与写共用同一把锁。重入由 _ORDER_LOCK(RLock) + _orders_flock 的
    深度短路处理，不会自锁。
    """
    if not ORDERS_PATH:
        return {}
    with _ORDER_LOCK:
        with _orders_flock():
            try:
                with open(ORDERS_PATH, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}


def _save_orders(orders):
    if not ORDERS_PATH:
        return
    import tempfile
    try:
        d = os.path.dirname(ORDERS_PATH) or "."
        fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(orders, f, ensure_ascii=False)
        # AIPC-REPLACE-RETRY（v1.7.76）：Windows 的 MoveFileEx 在目标文件正被
        # **任何进程打开**时会报 WinError 5 拒绝访问。读方已改为持锁读（见
        # _load_orders），这里再加一层短自旋兜底 —— 其他程序（杀软扫描、用户用
        # 记事本打开）占用时也能自愈，而不是把这次订单写入丢掉。
        _rep_err = None
        for _ in range(40):              # 最多 40 × 25ms = 1 秒
            try:
                os.replace(tmp, ORDERS_PATH)   # 同盘原子替换，避免写一半崩溃损坏文件
                _rep_err = None
                break
            except OSError as _re:
                _rep_err = _re
                time.sleep(0.025)
        if _rep_err is not None:
            raise _rep_err
    except Exception as _e:
        # AIPC-ORDER-SAVE-TRACE（v1.7.76）：原先静默 pass —— 订单写失败时
        # 用户付了钱本地却没有订单，且日志里一个字都没有，事后无从排查。
        _log("orders.json 写盘失败：%s", _e)


# ===== 订单文件并发安全（AIPC-ORDER-LOCK-FIX，v1.7.76）=====
# 病根：orders.json 有**两个写入方** —— 报告页进程（本文件）与对话框侧 skill_tools。
# 两边都是「全量读出 → 改一个 key → 全量写回」；本文件内还被多线程并发调用
# （前端 2 秒轮询 /order_status 与用户点解锁打 /create_order 同时发生，
# 本服务用的是 ThreadingHTTPServer）。后写者会把先写者的改动整段覆盖
# （lost update）→ 用户付了钱，本地订单却被覆盖回 pending，页面一直等、
# 还可能再付一次 = 真金白银事故。
# 注意：_save_orders 的「临时文件 + os.replace」只防「写一半崩溃」，**挡不住丢更新**。
# 治法两道：
#   ① 进程内：所有订单写操作串行化在 _ORDER_LOCK 下。
#   ② 跨进程：读改写全程持 <orders.json>.lock（Windows=msvcrt / 其它=fcntl），
#      与 skill_tools.py 用**同一把锁文件、同一段锁区间**。
_ORDER_LOCK = threading.RLock()
_ORDER_FLOCK_DEPTH = [0]   # 本进程持锁深度：Windows 区间锁重复锁同一区间会自锁


def _orders_flock():
    """读改写 orders.json 时全程持有的跨进程互斥锁（上下文管理器）。

    拿不到文件锁时**不抛错也不阻断**（退化为进程内锁 + 原子替换）—— 支付流程的
    可用性优先，绝不能因为锁文件有问题就让用户付不了钱。
    """
    import contextlib

    @contextlib.contextmanager
    def _cm():
        if not ORDERS_PATH:
            yield
            return
        if _ORDER_FLOCK_DEPTH[0] > 0:      # 同进程重入：不再锁一次
            _ORDER_FLOCK_DEPTH[0] += 1
            try:
                yield
            finally:
                _ORDER_FLOCK_DEPTH[0] -= 1
            return
        lock_path = ORDERS_PATH + ".lock"
        f = None
        try:
            try:
                os.makedirs(os.path.dirname(lock_path) or ".", exist_ok=True)
            except Exception:
                pass
            f = open(lock_path, "a+b")
            try:
                if os.name == "nt":
                    # AIPC-LOCK-SPIN-FIX（v1.7.76）：原先用 msvcrt.LK_LOCK —— 它的重试
                    # 粒度是**整秒**（失败等 1 秒、共 10 次）→ 双方高频写同一文件时
                    # 每次要等 0.5~1 秒，200 次写就从 3 秒变 20 秒；更糟的是等满 10 次
                    # 仍拿不到就抛错，退化无锁 → 那一次写入直接丢（实测 400 条丢 1 条，
                    # 日志 `[Errno 36] Resource deadlock avoided`）。
                    # 改用 LK_NBLCK 非阻塞 + 5ms 粒度自旋（总上限 10 秒）：拿锁快、
                    # 不因"等太久"而静默退化。
                    import msvcrt
                    _deadline = time.time() + 10.0
                    while True:
                        try:
                            f.seek(0)
                            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                            break
                        except Exception:
                            if time.time() >= _deadline:
                                raise
                            time.sleep(0.005)
                else:
                    import fcntl
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            except Exception as _le:
                # 锁拿不到时退化为「进程内锁 + 原子替换」：支付可用性优先。
                # 但必须留下痕迹 —— 静默退化等于没人知道锁已经失效了。
                try:
                    sys.stderr.write(
                        "[order-lock] 文件锁获取失败（已退化为进程内锁）：%s\n" % _le)
                except Exception:
                    pass
            _ORDER_FLOCK_DEPTH[0] = 1
            yield
        finally:
            _ORDER_FLOCK_DEPTH[0] = 0
            if f is not None:
                try:
                    if os.name == "nt":
                        import msvcrt
                        f.seek(0)
                        msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except Exception:
                    pass
                try:
                    f.close()
                except Exception:
                    pass
    return _cm()


def _patch_order(order_id, **fields):
    """原子更新单个订单的部分字段（读改写全程互斥，杜绝跨进程丢更新）。

    返回更新后的订单 dict；订单不存在时返回 {}（且**不写入**占位空对象）。
    """
    if not ORDERS_PATH or not order_id:
        return {}
    with _ORDER_LOCK:
        with _orders_flock():
            orders = _load_orders()
            o = orders.get(order_id)
            if not isinstance(o, dict):
                return {}
            o.update(fields)
            orders[order_id] = o
            _save_orders(orders)
            return o


def _insert_order(order):
    """原子新增一个订单（与 _patch_order 同一把锁，防止新建时覆盖他人改动）。"""
    if not ORDERS_PATH or not order or not order.get("order_id"):
        return {}
    with _ORDER_LOCK:
        with _orders_flock():
            orders = _load_orders()
            orders[order["order_id"]] = order
            _save_orders(orders)
            return order


def _order_hwid():
    """本机 hwid（下单身份标识）。取不到时返回空串，由调用方决定兜底。"""
    try:
        return (license_mod.get_hwid() or "").strip()
    except Exception:
        return ""


def _find_reusable_order(product_id, ttl_sec=600):
    """找一张「可复用」的未支付订单：同产品 + 同 hwid + 未支付 + 未过期 + 有付款码。

    AIPC-ORDER-REUSE-FIX（v1.7.76）：原先 /create_order 无条件新建订单 → 用户连点
    「解锁」就堆一堆订单，并撞上服务端下单限流（10 次/分/IP）→ 429「操作过于频繁」，
    用户以为坏了。现在命中既存未支付订单就直接复用，秒级出码、零服务端请求。

    只复用**带真实付款码**的订单（mode 为 x402 / real）：pending_config 类订单根本
    还没有码，复用只会让用户看到空码，比新建更糟。
    复用窗口取 600 秒（< 付款码刷新触发 840s，留足余量），且以「码签发时刻
    code_created」为基准（见下方 age 判定），避免死码被无限复用。
    """
    if not ORDERS_PATH:
        return None
    hwid = _order_hwid()
    now = time.time()
    best = None
    with _ORDER_LOCK:
        for _o in (_load_orders() or {}).values():
            if not isinstance(_o, dict):
                continue
            if _o.get("product_id") != product_id:
                continue
            if (_o.get("status") or "pending") != "pending":
                continue
            if _o.get("mode") not in ("x402", "real"):
                continue
            if not _o.get("out_trade_no"):
                continue
            if not (_o.get("payment_code") or _o.get("code_url")):
                continue                      # 没码可复用
            # v1.7.97 P1：以「码签发时刻 code_created」为基准，而非被 _patch_order 刷新的
            # created —— 否则复用会把 created 永远刷成「现在」，死码被无限复用。
            _code_ts = float(_o.get("code_created") or _o.get("created") or 0)
            if now - _code_ts >= ttl_sec:
                continue                      # 付款码已超安全窗口，强制重新下单拿活码
            if hwid and _o.get("hwid") and _o.get("hwid") != hwid:
                continue                      # 他人订单（防御性判定）
            if best is None or float(_o.get("created") or 0) > float(best.get("created") or 0):
                best = _o
    return best


def _host_ok(host_header):
    """付款类接口只接受「本机回环」来源（AIPC-PAY-RECOVER-FIX）。

    背景：旧实现写死「Host 首段必须等于 127.0.0.1」→ 用户若用
    `http://localhost:4210/?token=...` 打开报告页，所有付款/订单接口一律 403，
    而页面只会告诉用户「下单网络错」——看起来像服务器坏了，实际是本地自锁。
    回环的三种合法写法都要放行：127.0.0.1 / localhost / ::1 / [::1]，均含带端口形式。
    全 server.py 共 20 处 Host 校验统一走本函数（原先只放行 127.0.0.1 字面量，
    用 `localhost:PORT` 打开报告页时，付款、激活、执行清理会全部自锁）。
    """
    raw = (host_header or "").strip().lower()
    if raw.startswith("["):              # [::1]:4210
        host = raw.split("]")[0] + "]"
    elif ":" in raw:
        host = raw.split(":")[0]
    else:
        host = raw
    return host in ("127.0.0.1", "localhost", "::1", "[::1]")


def _fulfill_order(order_id, paid_amount_cents=None):
    """支付成功后，向远程台账申请签发短码并尝试自动绑定本机（一机一码）。

    安全点：
      - 只信订单存的 product_id + fee_cents，不重新读前端（防伪造 tier）。
      - 若回调带回 paid_amount_cents，必须与订单金额一致（防篡改金额换高 tier）。
      - 幂等：已 paid 的订单不重复签发。
      - 短码由服务端台账生成并入库，skill 端不持私钥；自动授权失败时把短码
        显示给用户，让用户手动在报告页输入授权。
    返回 (ok, error)。
    """
    orders = _load_orders()
    order = orders.get(order_id)
    if not order:
        return False, "订单不存在"
    if order.get("status") == "paid":
        return True, ""  # 幂等
    if paid_amount_cents is not None and int(paid_amount_cents) != int(order.get("fee_cents", 0)):
        return False, "支付金额与订单不符"
    prod = PRODUCTS.get(order.get("product_id", ""))
    if not prod:
        return False, "产品配置缺失"

    # 履约端点收敛：客户端只持权限极小的 fulfill_token（无任意签码能力），
    # 服务端自己查扫码确认支付成功、按真实金额签短码落库。
    # AIPC-ADMIN-FALLBACK-DEADEND-FIX（v1.7.76）：删掉「未设 AIPC_FULFILL_TOKEN
    # 时回退 AIPC_AUTH_ADMIN」。这是一条死路 —— 服务端 /v1/fulfill 校验的是
    # **服务端自己的** AIPC_FULFILL_TOKEN，与客户端 admin 令牌本就不相等，回退
    # 必然 401；而且 admin 是最高权限令牌，本不该出现在客户端进程里。
    fulfill_token = (os.environ.get("AIPC_FULFILL_TOKEN") or "").strip()
    if not fulfill_token:
        return False, "未配置 AIPC_FULFILL_TOKEN，无法完成自动发卡"

    local_hwid = license_mod.get_hwid()
    auth_url = license_mod.AUTH_URL.rstrip("/")
    try:
        from urllib.request import urlopen, Request
        from urllib.error import HTTPError
        body = json.dumps({
            "out_trade_no": order_id,
            "hwid": local_hwid,
            "fulfill_token": fulfill_token,
        }, ensure_ascii=False).encode("utf-8")
        req = Request(auth_url + "/v1/fulfill", data=body,
                      headers={"Content-Type": "application/json"}, method="POST")
        with urlopen(req, timeout=15) as r:
            sign_resp = json.loads(r.read().decode("utf-8"))
    except HTTPError as e:
        try:
            sign_resp = json.loads(e.read().decode("utf-8"))
        except Exception:
            sign_resp = {"ok": False, "error": "远程履约服务返回 %d" % e.code}
    except Exception as e:
        return False, "远程履约失败：" + str(e)

    if not sign_resp.get("ok"):
        return False, sign_resp.get("error") or "远程履约失败"
    code = (sign_resp.get("code") or "").strip()
    if not code:
        return False, "远程履约未返回授权码"

    # AIPC-FULFILL-ATOMIC-FIX（v1.7.76）：原先这里是无锁的「全量读 → 改 → 全量写」，
    # 而读快照在本函数开头就取好了 —— 中间隔着一次 urlopen(timeout=15) 网络请求，
    # 「读到写完」的窗口最长 15 秒。期间别人新增的订单会被这次写回**整段抹掉**，
    # 别人改过的状态（含「已支付」）会被打回旧值 → 用户付了钱又被判未付、反复付款。
    # 改为原子补丁：锁内重读文件，只落这一张订单的这三个字段。
    order = _patch_order(order_id, status="paid", license_code=code,
                         paid_at=int(time.time()))
    if not order:
        return False, "订单在履约期间已不存在，未能标记为已支付"

    # 支付直解锁：本机就在运行，把刚签的短码直接绑定到本机 hwid。
    # AIPC-INSTANT-UNLOCK-FIX（v1.7.79）：优先本机验签解锁（零网络）—— /v1/fulfill 若
    # 带回 signature/bound_hwid 就地离线解开，不再赌一次网络往返。
    try:
        act_res = _instant_unlock(code, sign_resp,
                                  {"product_id": order.get("product_id", "")})
        if not act_res.get("ok"):
            _log("fulfill: 支付自动授权未成功：%s", act_res.get("error"))
            # 订单仍算 paid，前端会把短码展示给用户手动授权
        else:
            _register_license_async(code)
    except Exception as e:
        _log("fulfill: 支付自动授权异常：%s", e)
    return True, ""


# ---------------------------------------------------------------------------
# AIPC-INSTANT-UNLOCK-FIX（v1.7.79）：付款成功 → 解锁，不允许有第二种结果
#
# 【病根】旧链路把"解锁"押在一次 /v1/activate 网络往返上。云端 429（限流）、网络
#   抖动、服务重启……任何一次失败都会把订单打成 paid_unactivated —— 用户看到的就是
#   "钱付了、功能没开"。这是真金白银的体验事故，且完全由我们自己造成。
#
# 【治法】把"解锁"拆成两件互不阻塞的事：
#   ① 本机解锁（唯一必须成功的一步）：付款已确认时，码 / 签名 / 绑定机器 都已经在手，
#      本机用内嵌公钥离线验签就能自证"这码是真的、等级是 N、且属于本机" → 立刻写
#      许可、立刻解锁。零网络 → 零失败。
#   ② 云端登记（可选、幂等、后台）：只是让云端台账记下"这台机器激活了"。失败只记
#      日志，绝不影响用户已获得的权限；指数退避重试，网络恢复自动补上。
# 只有两种情况才算真失败，且都不是本机故障：签名验不过（假码）、码绑定了别的机器。
# ---------------------------------------------------------------------------
_unlock_reg_lock = threading.Lock()
_unlock_reg_done = set()


def _tier_candidates(order):
    """本地配置里这张订单产品对应的档位，作为验签候选（只用于定位签名对应的真实档位）。"""
    out = []
    try:
        _t = (PRODUCTS.get((order or {}).get("product_id", "")) or {}).get("tier")
        if _t:
            out.append(int(_t))
    except Exception:
        pass
    return out


def _instant_unlock(code, st, order):
    """先用本机验签解锁（零网络），拿不到签名才退回云端激活一次。

    返回 license_mod 风格的结果 dict，含 ok / tier / error / local。
    """
    st = st or {}
    try:
        res = license_mod.unlock_local(
            code,
            tier=st.get("tier"),
            signature=st.get("signature"),
            bound_hwid=st.get("bound_hwid"),
            tier_candidates=_tier_candidates(order),
        )
    except Exception as e:
        _log("instant_unlock 异常，退回云端激活：%s", e)
        res = {"ok": False, "error": "本地解锁异常"}
    if res.get("ok"):
        return res
    # 只有"没拿到签名"才值得再打一次网络。签名无效 / 绑定他机 是结论，重试没有意义
    # （也不该把一个假码或别人机器的码硬解到本机）。
    _e = res.get("error") or ""
    if "签名无效" in _e or "其他电脑" in _e:
        return res
    try:
        res2, _neterr = license_mod.activate_online(code, version=license_mod.LOCAL_VERSION)
        return res2
    except Exception as e:
        _log("instant_unlock 云端激活异常：%s", e)
        return res


def _register_license_async(code):
    """云端登记（幂等、后台、指数退避）。失败只记日志，绝不影响用户已获得的权限。"""
    code = (code or "").strip()
    if not code:
        return
    with _unlock_reg_lock:
        if code in _unlock_reg_done:
            return
        _unlock_reg_done.add(code)

    def _worker():
        delays = [0, 10, 30, 60, 300]
        for i, d in enumerate(delays):
            if d:
                time.sleep(d)
            try:
                res, neterr = license_mod.activate_online(
                    code, version=license_mod.LOCAL_VERSION)
                if res.get("ok"):
                    _log("云端登记成功：%s（第 %d 次）", code[:8], i + 1)
                    return
                _e = str(res.get("error") or "")
                # 限流 / 网络类：等一等再来；其它（已作废等）死磕没有意义
                if not (neterr or "频繁" in _e or "连接" in _e):
                    _log("云端登记未成功（不再重试）：%s -> %s", code[:8], _e)
                    return
            except Exception as e:
                _log("云端登记异常（将重试）：%s -> %s", code[:8], e)
        _log("云端登记重试耗尽，仅本地已解锁：%s", code[:8])

    try:
        threading.Thread(target=_worker, name="lic-register", daemon=True).start()
    except Exception as e:
        _log("云端登记线程启动失败：%s", e)


def _simulate_pay_html(order_id, name, price):
    return ("<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>模拟支付 - C盘清理</title>"
            "<style>body{font-family:system-ui,-apple-system,'Microsoft YaHei',sans-serif;background:#0f1115;color:#e8e8ee;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}"
            ".card{background:#181b22;border:1px solid #2a2f3a;border-radius:18px;padding:32px 36px;max-width:380px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.4)}"
            "h2{margin:0 0 8px}.sub{color:#9aa3b2;font-size:13px;margin-bottom:20px}"
            ".amt{font-size:34px;font-weight:800;margin:14px 0}"
            "button{width:100%%;padding:12px;border:0;border-radius:12px;background:linear-gradient(135deg,#6d5efc,#9b6dff);color:#fff;font-size:15px;font-weight:700;cursor:pointer}"
            ".note{margin-top:14px;font-size:11px;color:#6b7280}</style></head>"
            "<body><div class='card'><h2>%s</h2><div class='sub'>本地模拟收银台（SkillHub 真实接入后即为扫码支付）</div>"
            "<div class='amt'>¥ %.2f</div>"
            "<button onclick=\"pay()\">我已支付</button>"
            "<div class='note'>仅本地联调用；真实环境由系统回调自动签发授权码</div></div>"
            "<script>function pay(){fetch('/simulate_paid',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({order_id:'%s',token:'%s'})}).then(r=>r.json()).then(d=>{if(d.ok){location.href='/?order_id=%s';}else{alert('支付失败：'+(d.error||''));}}).catch(e=>alert('请求失败'));}</script>"
            "</body></html>") % (name, price, order_id, TOKEN, order_id)


def _apply_app_name(html):
    """把应用名/指纹/版本占位替换成真实值（server 服务模式也要做，
    否则交互报告会显示 __BRAND__ 等字面量）。应用名文案做 </ 转义（P0-3 防护）。"""
    c = _load_app_config()
    esc = lambda s: str(s).replace("</", "<\\/")
    return (html
            .replace("__BRAND__", esc(c["app_name"]))
            .replace("__FP__", esc(c["fingerprint"]))
            .replace("__VER__", esc(c["version"])))




def expand(p):
    return os.path.realpath(os.path.expanduser(p))


def expand_nojunction(p):
    # 词法规范化：展开 ~ 与 . / ..，但【不】跟随 junction/符号链接。
    # 迁移后源路径会变成 junction（指向目标盘），若用 realpath 会解析到目标盘
    # 路径，导致服务端护栏误判“不在白名单/越界”而拒绝（实则数据安全）。
    # 迁移护栏只需按逻辑路径比对，故用 abspath + normcase（Windows 小写归一）。
    return os.path.normcase(os.path.abspath(os.path.expanduser(p)))


def _compute_rm_freed(done, green_attr, residual_map):
    """按绿区条目聚合真实释放量（KB），纯函数便于单测。

    done: 前端逐条发来的 trash_paths（原始路径）
    green_attr: [(set_of_norm_trash_paths, kb)]，扫描时构建的绿区条目
    residual_map: {orig_request_path: [residual_file_paths]}，migrate 返回

    命中与残留 key 都做归一化（normcase+abspath），确保同源路径能正确匹配。
    选了某条目中几个子路径就按占比归因其 kb，再减该条目真实残留文件体积。
    """
    freed_kb = 0.0
    _done_norm = set()
    for _p in done:
        try:
            _rp = expand(_p)
        except Exception:
            _rp = _p
        _done_norm.add(os.path.normcase(os.path.abspath(_rp)))
    _resid_map = {}
    for _k, _v in residual_map.items():
        _resid_map[os.path.normcase(os.path.abspath(_k))] = _v
    for _tps, _kb in green_attr:
        if not _tps:
            continue
        _hit = [_tp for _tp in _tps if _tp in _done_norm]
        if not _hit:
            continue
        _attr = _kb * (len(_hit) / len(_tps))
        _resid_kb = 0.0
        for _tp in _hit:
            for _rf in (_resid_map.get(_tp) or []):
                try:
                    _resid_kb += os.path.getsize(_rf) / 1024.0
                except Exception:
                    pass
        freed_kb += max(0.0, _attr - _resid_kb)
    return freed_kb





def load(src):
    with open(src, encoding="utf-8") as f:
        data = json.load(f)
    with open(TEMPLATE, encoding="utf-8") as f:
        tpl = f.read()
    # 三套白名单，权限从严到宽：
    #   rm    = 仅绿灯 trash_paths（可直接删的纯缓存）
    #   trash = 绿灯 + 橙灯 trash_paths（橙灯只准移废纸篓，不准直接删）
    #   open  = trash 全集 + 橙灯 path + 红灯 app_paths（仅"在文件管理器打开"，非破坏性）
    rm_allow, trash_allow, open_allow = set(), set(), set()
    for it in data.get("green", []):
        for p in (it.get("trash_paths") or []):
            rp = expand(p)
            rm_allow.add(rp); trash_allow.add(rp); open_allow.add(rp)
    for it in data.get("yellow", []):
        for p in (it.get("trash_paths") or []):
            rp = expand(p)
            trash_allow.add(rp); open_allow.add(rp)
        if it.get("path"):
            rp = expand(it["path"])
            if os.path.exists(rp):
                open_allow.add(rp)
        # v7/v8: 钻取出的单文件路径 — 打开看 / 移废纸篓 允许；不直接删（最小特权，P1-1）
        # 黄区"需用户判断"，即便已看到文件名大小，也不开放不可逆 rm，避免前端/Payload 异常误删
        for child in (it.get("top_children") or []):
            rp = expand(child.get("path", ""))
            if rp and os.path.exists(rp):
                open_allow.add(rp)
                trash_allow.add(rp)
        # v7/v8：smart_scan 钻取的孙项（unknown_children / safe_children）
        # 报告页会给这些孙项渲染「打开看 / 删除」按钮，必须把路径加进白名单，
        # 否则 server 会拒绝 → 假按钮（R3 修复）。keep_children 前端不渲染，不加。
        scan = it.get("smart_scan") or {}
        for _key in ("unknown_children", "safe_children"):
            for _gc in (scan.get(_key) or []):
                _rp = expand(_gc.get("path", ""))
                if _rp and os.path.exists(_rp):
                    open_allow.add(_rp)
                    trash_allow.add(_rp)
    # 红灯只允许"打开"（应用本体在 /Applications，删除让用户在访达里自己卸）
    for it in data.get("red", []):
        for p in (it.get("app_paths") or []):
            rp = expand(p)
            if os.path.exists(rp):
                open_allow.add(rp)
    # 迁移白名单：仅 analysis.json 里建议迁移的程序数据目录（Pro 才可用）
    # 用 expand_nojunction：迁移后源路径是 junction，realpath 会解析到目标盘，
    # 导致白名单比对失败。逻辑路径与请求端一致即可正确匹配。
    for p in (data.get("migration", {}).get("plan") or []):
        rp = expand_nojunction(p.get("src", ""))
        if rp:
            MIGRATE_ALLOW.add(rp)
    # 回收站：独立的「深度清理」项（非绿区），用户二次确认后单独执行
    _rb = data.get("recycle_bin")
    if _rb and _rb.get("marker"):
        rm_allow.add(_rb["marker"]); trash_allow.add(_rb["marker"]); open_allow.add(_rb["marker"])

    return data, tpl, rm_allow, trash_allow, open_allow


def move_to_trash(path):
    if sys.platform == "darwin":
        _trash_macos(path)
    elif sys.platform.startswith("win"):
        _trash_windows(path)
    else:
        raise OSError("移到废纸篓仅支持 macOS / Windows")


def _trash_macos(path):
    # osascript Finder delete -> macOS Trash, recoverable. First run may prompt
    # for Finder automation permission. Fall back to ~/.Trash move if it fails.
    script = 'tell application "Finder" to delete (POSIX file %s as alias)' % json.dumps(path)
    r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    if r.returncode != 0:
        dest = os.path.join(HOME, ".Trash",
                            os.path.basename(path.rstrip("/")) + "." + time.strftime("%H%M%S"))
        shutil.move(path, dest)


def _trash_windows(path):
    # Send to Recycle Bin via SHFileOperationW with FOF_ALLOWUNDO (stdlib ctypes).
    # Verified on this Windows build (2026-07-19, test_trash.py): the original file
    # is removed and routed to $Recycle.Bin (recoverable), no exception raised.
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", wintypes.HWND),
            ("wFunc", wintypes.UINT),
            ("pFrom", wintypes.LPCWSTR),
            ("pTo", wintypes.LPCWSTR),
            ("fFlags", ctypes.c_uint16),
            ("fAnyOperationsAborted", wintypes.BOOL),
            ("hNameMappings", ctypes.c_void_p),
            ("lpszProgressTitle", wintypes.LPCWSTR),
        ]

    FO_DELETE = 3
    FOF_ALLOWUNDO = 0x0040
    FOF_NOCONFIRMATION = 0x0010
    FOF_SILENT = 0x0004
    FOF_NOERRORUI = 0x0400  # 抑制 Windows 错误对话框（"找不到项目"等系统弹窗）
    op = SHFILEOPSTRUCTW()
    op.wFunc = FO_DELETE
    op.pFrom = os.path.abspath(path) + "\x00\x00"  # double-null terminated list
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI
    # 某些 Windows 环境（尤其无桌面交互的会话）即使已成功移入回收站，
    # SHFileOperationW 也会返回非 0（如 fAnyOperationsAborted 误报 / 0x4C7 等），
    # 导致「目录其实已删除」却被误判为失败、前端弹「删除失败」。
    # 改用「源文件是否已从原位置移除」作为成功判据，最稳妥。
    # 重试：大目录在实时查杀（360 等）逐文件扫描时，偶发单文件被占用导致整次
    # 操作以非 0 中断、源仍在原位。给 0.4s 让占用/查杀释放后重试，至多 3 次，
    # 既覆盖瞬时锁又不过度拖延 UI（每次失败仍即时回包）。
    last_rc = 0
    for _attempt in range(3):
        rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        if not os.path.exists(path):
            return
        last_rc = rc
        if rc == 0:
            return
        if _attempt < 2:
            time.sleep(0.4)
    if last_rc != 0:
        raise OSError("SHFileOperation failed (code %d, aborted=%s)" % (last_rc, bool(op.fAnyOperationsAborted)))


# 回收站特殊操作：不走普通文件删除，直接调用 Windows API 清空 C 盘回收站。
# 这是 100% 安全的操作——清空的是用户已经删除、躺在回收站里的文件。
_EMPTY_RECYCLE_BIN_MARKER = "__EMPTY_RECYCLE_BIN__"

def empty_recycle_bin(drive=None):
    """清空指定驱动器（默认 C:）的回收站。

    v1.7.34（弹窗根因修复）：原实现直接调 SHEmptyRecycleBinW，被 explorer.exe
    监视弹出「找不到项目」系统对话框（用户图片证据：$R7H3E6C / $ROB5ZON 等 0 字节
    文件在 C:\\$Recycle.Bin\\S-1-5-21-... 找不到）。这是与 migrate.py 的 _do_empty
    并行的清空入口，用户点「一键清理」勾选回收站时**同时**触发，导致弹窗仍出现。

    现改为委托 migrate.recycle_bin_fast_purge(empty_full_bin=True) —— 与 _do_empty
    **统一为一条 WinAPI 路径**（纯 DeleteFileW / RemoveDirectoryW），彻底根除
    资源管理器监视失败弹窗，同时保留「整盘清空回收站」的语义与速度。
    """
    if not sys.platform.startswith("win"):
        raise OSError("清空回收站仅支持 Windows")
    import migrate as _mig_mod
    _drive = (drive or os.environ.get("SystemDrive", "C:") + "\\").rstrip("\\/") + "\\"
    # 传一个 dummy path 让 recycle_bin_fast_purge 推导出目标盘符，
    # 走统一的 _do_empty（WinAPI 直清 $R*/$I*，零弹窗）。
    _dummy = os.path.join(_drive, "_aipc_empty_")
    _ok, _failed = _mig_mod.recycle_bin_fast_purge([_dummy], empty_full_bin=True)
    # 线程已 spawn（_do_empty 后台跑），立即返回不阻塞弹窗；
    # 校准线程 wait_bg_empty 等线程 join 释放。
    return True

def _disk_free_by_drive(paths):
    """记录涉及各盘的剩余空间(字节)，用于真实核算『实际释放量』。"""
    drives = {}
    for p in paths:
        try:
            # 用逻辑路径取盘符：迁移源的 junction 经 realpath 会指到目标盘，
            # 导致“实际释放量”按错盘核算。逻辑路径 C: 才正确。
            rp = expand_nojunction(p)
            d = os.path.splitdrive(rp)[0]
            if not d:
                d = os.path.splitdrive(HOME)[0] or "C:"
            if d not in drives:
                drives[d] = shutil.disk_usage(d + os.sep).free
        except Exception:
            pass
    return drives


def _classify_skips(skipped):
    """把跳过的文件按错误分类成一句话原因（只读探测，不真删）。
    若进程已是管理员，errno 5/13 通常不再是“缺权限”，而是系统保护或被独占占用，
    所以不再提示“以管理员重开”，避免误导用户。
    v1.7.20：限量探测前 20 个即可判断分类，避免杀软下对大量残留逐个 os.open 拖慢。"""
    locked = denied = other = 0
    for fp in (skipped or [])[:20]:
        try:
            fd = os.open(fp, os.O_RDWR)
            os.close(fd)
            other += 1  # 现在能写，可能已释放
        except OSError as e:
            if e.errno in (5, 13):
                denied += 1   # 权限不足 / 系统保护 / 独占占用
            elif e.errno in (32,):
                locked += 1   # 被其他程序占用
            else:
                other += 1
    admin = is_admin()
    if denied and not locked:
        if admin:
            return "部分文件被系统保护或程序独占（关闭相关程序后重清即可）"
        return "需管理员权限（请以管理员身份重开 WorkBuddy 再清）"
    if locked and not denied:
        return "部分文件被程序占用（关闭迅雷/微信/360 等后重清即可）"
    if locked and denied:
        if admin:
            return "部分文件被程序占用或系统保护（关闭相关程序后重清即可）"
        return "部分被程序占用、部分需管理员（关闭相关程序 + 以管理员重开再清）"
    return "部分文件暂无法删除（关闭相关程序 + 以管理员重开再清）"


def _schedule_reboot_deletes(files):
    """一键清删不掉的文件 → 登记『下次重启自动删除』（仅文件、仅安全路径）。

    ===== v1.7.86 修一个「骗用户」的缺陷 =====
    旧实现自己复制了一份登记逻辑，且**只返回成功数**、失败原因被 `except: continue`
    吞掉。于是非管理员态下 MoveFileExW 全部失败，n=0，而上层照样对用户说
    「已安排重启后自动清理」—— 用户重启后发现文件原封不动躺在 C 盘。
    这与「报告说清得了、实际清不掉」是同一类欺骗。

    现在：改为复用 migrate.py 的 _reboot_register_count（单一真理源，不再两份实现），
    并把 (成功数, 失败原因) 一起返回，让上层能如实告知。
    """
    try:
        return migrate_mod._reboot_register_count(files)
    except Exception:
        return (0, "登记失败：系统异常")


def hard_delete(path, on_progress=None, size_kb=0):
    """极速删除（委托 migrate.fast_purge）：整目录瞬时改名搬至暂存区（同卷 rename
    = 一次元数据操作，360 只扫一次，毫秒级），随后后台线程 rd 真正清掉暂存区——
    请求 / UI 线程立即返回，彻底消除「清理无响应」根因
    （原 rd /s /q 在数万子目录上 40s+ 卡死；del+rd 也受 360 逐文件扫描拖累）。

    size_kb（v1.7.24）：条目扫描体积，>=200MB 时 fast_purge 异步删暂存区（提交秒级、
    弹窗不被拖）；小目录同步返回真实残留（弹窗展示未清理项）。
    """
    return migrate_mod.fast_purge(path, on_progress, size_kb=size_kb)


def open_in_file_manager(path):
    # 非破坏性：在访达 / 资源管理器里打开该位置，方便用户自己审查删除
    if not os.path.exists(path):
        raise OSError("该文件/目录已不存在，可能刚被清理或移动过")
    target = path if os.path.isdir(path) else os.path.dirname(path)
    target = os.path.normpath(os.path.abspath(target))
    if sys.platform == "darwin":
        # .app 是 bundle，对它用 open 会"启动应用"而非显示；必须用 open -R 在访达里选中。
        if target.rstrip("/").endswith(".app"):
            r = subprocess.run(["open", "-R", target], capture_output=True, text=True, timeout=10)
            if r.returncode != 0:
                raise OSError((r.stderr or "open -R 失败").strip())
            return
        # 普通文件夹：先试直接打开看内容；沙盒容器（如微信）open 会报 -10814，
        # 退回 open -R 在父目录里选中它。两者都失败才算错。
        r = subprocess.run(["open", target], capture_output=True, text=True, timeout=10)
        if r.returncode != 0:
            r2 = subprocess.run(["open", "-R", target], capture_output=True, text=True, timeout=10)
            if r2.returncode != 0:
                raise OSError((r.stderr or r2.stderr or "open 失败").strip())
    elif sys.platform.startswith("win"):
        # Windows：os.startfile 比 explorer 命令更可靠（自动处理空格、长路径、隐藏目录）。
        # 对目录用 'explore' 动词打开文件夹；对文件用 /select 高亮选中。
        import os as _os
        norm_path = _os.path.normpath(_os.path.abspath(path))
        try:
            if _os.path.isdir(norm_path):
                _os.startfile(norm_path, 'explore')
            else:
                # /select 能直接定位并高亮文件，比打开父目录更符合"打开看"预期
                # v1.7.34（黑框修复）：explorer 虽为 GUI 程序，但补 CREATE_NO_WINDOW
                # 更严谨（对 GUI 无副作用，且覆盖极端回退场景）
                subprocess.Popen(["explorer", "/select,", norm_path], creationflags=CREATE_NO_WINDOW)
        except Exception:
            # 兜底：仍尝试 explorer（旧路径兼容）
            subprocess.Popen(["explorer", target], creationflags=CREATE_NO_WINDOW)
    else:
        raise OSError("打开文件夹仅支持 macOS / Windows")


def _plain_error(e):
    """把系统底层异常翻译成用户能看懂的大白话，不暴露技术细节。"""
    msg = str(e)
    # Windows 权限不足（文件被占用 / 需管理员）
    if "[WinError 5]" in msg or "拒绝访问" in msg or "Permission denied" in msg:
        return ("这个文件正被程序占用或权限不够，暂时跳过它。" +
                "不影响清理效果——下次程序关闭后再清即可自动删掉。")
    # 文件已不存在（并发删除竞态）
    if "[WinError 2]" in msg or "No such file" in msg:
        return "这个文件已经不存在了（可能刚被其他程序清理过），跳过即可。"
    # 文件正在使用中
    if "being used" in msg.lower() or "used by another process" in msg.lower():
        return ("文件正被其他程序打开，暂时无法删除。" +
                "关闭相关程序后重试即可，缓存会自动重建。")
    # 通用兜底：不暴露技术细节
    return "清理时遇到问题，已安全跳过此项。这不影响其他文件的清理结果。"


def is_admin():
    """判断当前进程是否以管理员身份运行（迁移建 junction 必须）。"""
    try:
        if sys.platform.startswith("win"):
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        return os.getuid() == 0
    except Exception:
        return False


def _get_running_procs():
    """通过 tasklist 拿到当前所有运行中的进程名（小写去扩展名）。仅 Windows。
    超时 8s 兜底，避免 tasklist 抽风卡住整个预检。
    """
    procs = set()
    if not sys.platform.startswith("win"):
        return procs
    try:
        out = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=8,
            creationflags=CREATE_NO_WINDOW,
        )
        for line in (out.stdout or "").splitlines():
            parts = line.split('","')
            if not parts:
                continue
            name = parts[0].strip('"').lower()
            if name.endswith(".exe"):
                name = name[:-4]
            if name:
                procs.add(name)
    except Exception:
        pass
    return procs


def _is_file_locked(path):
    """真实文件锁探测：用 Windows CreateFile 以「不共享」方式试探打开。
    成功=没被别的程序独占；返回 ERROR_SHARING_VIOLATION(32)=正被占用。
    非 Windows 或异常一律返回 False（放行，由迁移的零丢失机制兜底）。
    """
    if not sys.platform.startswith("win"):
        return False
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        k32.CreateFileW.restype = ctypes.c_void_p
        k32.CreateFileW.argtypes = [
            ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32,
            ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p,
        ]
        k32.GetLastError.restype = ctypes.c_uint32
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        INVALID = 0xFFFFFFFFFFFFFFFF  # INVALID_HANDLE_VALUE（64位全1）
        h = k32.CreateFileW(
            ctypes.c_wchar_p(path),
            0x80000000,   # GENERIC_READ：请求读权限以触发与占用者的冲突
            0,            # dwShareMode=0，请求独占（不共享）
            None,
            3,            # OPEN_EXISTING
            0,            # 普通文件不需要 BACKUP_SEMANTICS
            None,
        )
        hv = int(h) & INVALID
        if hv == INVALID:
            if k32.GetLastError() == 32:   # 32 = ERROR_SHARING_VIOLATION
                return True
            return False
        k32.CloseHandle(h)
        return False
    except Exception:
        return False


def _path_occupied_real(path, max_probe=300):
    """方案B核心：真实文件锁探测，不再只看进程名。

    对目录内（含下一层、不跟随 junction）的代表性文件逐个试探，
    任一被程序独占即视为占用。命中才拦，没命中放行——
    避免 WPS 仅挂托盘就把整个 Kingsoft 目录误判为占用。
    """
    if not path or not os.path.isdir(path):
        return False
    count = 0
    try:
        for entry in os.scandir(path):
            if count >= max_probe:
                break
            try:
                full = entry.path
            except Exception:
                continue
            if entry.is_file():
                if _is_file_locked(full):
                    return True
                count += 1
            elif entry.is_dir(follow_symlinks=False):
                try:
                    for sub in os.scandir(full):
                        if count >= max_probe:
                            break
                        if sub.is_file(follow_symlinks=False):
                            if _is_file_locked(sub.path):
                                return True
                            count += 1
                except Exception:
                    pass
    except Exception:
        pass
    return False


# 路径关键词 → (中文名, 关联进程列表)
# 用于迁移预检：路径里出现这些关键词 + 对应进程正在跑 → 那一项迁移会失败
PATH_PROCESS_MAP = [
    (("tencent", "wechat", "weixin"), "微信", ["weixin", "wechat", "wechatappex", "wechatutility"]),
    (("tencent", "qq\\"), "QQ/TIM", ["qq", "tim", "qqprotect", "qqbrowser", "qqmusic"]),
    (("thunder", "xunlei", "xldl"), "迅雷", ["thunder", "xlserviceplatform", "xldownloader"]),
    (("wps", "kingsoft"), "WPS", ["wps", "wpp", "et", "wpscenter", "wpscloudsvr", "kpservice"]),
    (("microsoft office", "office", "word", "excel", "powerpnt"), "Microsoft Office", ["winword", "excel", "powerpnt", "outlook", "onenote", "ms-teams", "teams"]),
    (("adobe", "photoshop", "illustrator", "acrobat", "acrord"), "Adobe", ["photoshop", "illustrator", "acrobat", "acrord32", "acrocef", "creative cloud"]),
    (("steam",), "Steam", ["steam", "steamservice", "steamwebhelper"]),
    (("epic games", "epicgames"), "Epic", ["epicgameslauncher"]),
    (("origin",), "Origin", ["origin", "originclientservice"]),
    (("battle.net",), "战网", ["battle.net", "blizzardupdateagent"]),
    (("nvidia",), "NVIDIA", ["nvdisplay.container", "nvtray", "nvidia web helper"]),
    (("360safe", "360safe"), "360", ["360safe", "360tray", "zhudongfangyu"]),
    (("baidunetdisk", "baidu"), "百度网盘", ["baidunetdisk"]),
    (("dingtalk", "钉钉"), "钉钉", ["dingtalk", "dingtalklauncher"]),
    (("wxwork", "企业微信"), "企业微信", ["wxwork", "wxworkwebdev"]),
    (("feishu", "lark", "larkshell"), "飞书/Lark", ["feishu", "lark", "larkshell"]),
    (("wemeet", "腾讯会议", "txmeet"), "腾讯会议", ["wemeet", "txmeet", "wemeetapp"]),
    (("zoom",), "Zoom", ["zoom"]),
    (("netease", "cloudmusic"), "网易云音乐", ["cloudmusic", "netease"]),
    (("qqmusic",), "QQ音乐", ["qqmusic"]),
    (("kugou", "酷狗"), "酷狗", ["kugou", "kugoumusic"]),
    (("kuwo", "酷我"), "酷我", ["kuwo", "kuwomusic"]),
    (("sogou", "搜狗"), "搜狗", ["sogoucloud", "sogouimebroker"]),
    (("vscode", "visual studio code"), "VS Code", ["code", "code - insiders"]),
    (("jetbrains", "idea", "webstorm", "pycharm"), "JetBrains", ["idea64", "webstorm64", "pycharm64", "rider64"]),
    (("jianying", "剪映"), "剪映", ["jianyingpro", "jianying"]),
    (("xmind",), "XMind", ["xmind"]),
    (("youdao", "有道"), "有道", ["youdao", "youdaodict"]),
    (("quark", "夸克"), "夸克", ["quark", "quarkbrowser"]),
    (("ucbrowser", "uc浏览器"), "UC浏览器", ["ucbrowser"]),
    (("opera", "欧朋"), "Opera", ["opera"]),
    (("firefox", "火狐"), "Firefox", ["firefox"]),
    # ---- 浏览器（用户数据目录是常见迁移目标，且常驻锁 User Data）----
    (("chrome", "chromium", "google\\\\chrome"), "Chrome", ["chrome", "chrome.exe"]),
    (("edge", "msedge", "microsoft\\\\edge"), "Edge", ["msedge", "edge"]),
    # ---- AI / 即时通讯 / 国民软件（迁移目标全集，必须能强杀释放锁）----
    (("kimi", "kimi-desktop"), "Kimi", ["kimi", "kimi-desktop"]),
    (("telegram",), "Telegram", ["telegram", "telegramdesktop"]),
    (("discord",), "Discord", ["discord", "discordptb", "discordcanary"]),
    (("spotify",), "Spotify", ["spotify"]),
    (("yuanbao", "元宝"), "腾讯元宝", ["yuanbao"]),
    (("doubao", "豆包"), "豆包", ["doubao"]),
    (("tongyi", "通义", "qianwen"), "通义千问", ["tongyi"]),
    (("alipay", "支付宝"), "支付宝", ["alipay"]),
    (("whatsapp",), "WhatsApp", ["whatsapp"]),
    (("skype",), "Skype", ["skype"]),
    (("slack",), "Slack", ["slack"]),
]

# 厂商「伞形目录」：迁移某厂商伞形目录（如 Roaming\Tencent）时，其下所有同厂商应用
# 都可能锁文件。迁移整树要求所有应用释放锁，故只要任一同厂商应用在跑，就整组视为需关闭
# （不再依赖浅层锁探测，避免「WXWork 在深层目录持锁、顶层探测不到」导致漏杀、迁移失败）。
# key = 路径关键词（命中即视为该厂商伞）；value = [(组中文名, [进程名...]), ...]，涵盖该厂商旗下全部软件。
UMBRELLA_MAP = {
    "tencent": [
        ("微信", ["weixin", "wechat", "wechatappex", "wechatutility"]),
        ("QQ/TIM", ["qq", "tim", "qqprotect", "qqbrowser", "qqmusic"]),
        ("企业微信", ["wxwork", "wxworkwebdev"]),
        ("腾讯元宝", ["yuanbao"]),
        ("腾讯会议", ["wemeet", "txmeet", "wemeetapp"]),
    ],
}


def _umbrella_groups_for(path):
    """给定路径，返回命中的伞形目录下的全部 (组中文名, 进程列表)。无命中返回 []。"""
    np_ = (path or "").lower().replace("/", "\\")
    groups = []
    for umb_kw, grps in UMBRELLA_MAP.items():
        if umb_kw in np_:
            groups.extend(grps)
    return groups




def preflight_migrate(paths):
    """迁移预检（方案B：真实文件锁探测 + 运行进程风险提示）。

    返回 {is_admin: bool, blocks: [...], warnings: [...]}
    - blocks：目录当前真实被锁的项（硬拦），type 分两类：
        'av_kernel' = 杀软内核驱动拦截改名（必须重启完成迁移）；
        'process'   = 普通进程/用户态占用（可强杀后迁移）。
    - warnings：关联进程正在跑、但当前未真锁文件的项（软提示，不拦）。

    关键（老李要求）：对每一个迁移路径都做『改名探测』，无论是否检测到用户进程。
    这样即使微信已关、仅杀软内核在锁目录，也能第一时间报 av_kernel，避免用户
    花时间迁移最后失败。winerror=5=内核拦截，winerror=32=进程占用。"""
    norm_paths = []
    for p in (paths or []):
        if not p:
            continue
        try:
            norm_paths.append(os.path.normpath(os.path.realpath(expand(p))))
        except Exception:
            pass
    blocks = []
    warnings = []
    procs = _get_running_procs()
    # 1) 已知应用进程匹配：友好命名 + 强杀建议（真锁才硬拦）
    for keywords, name, proc_list in PATH_PROCESS_MAP:
        hit_path = None
        for np_ in norm_paths:
            if any(kw in np_.lower() for kw in keywords):
                hit_path = np_
                break
        if not hit_path:
            continue
        hit_proc = [p for p in proc_list if p in procs]
        if not hit_proc:
            continue
        # 关联进程在跑：再分真实锁 / 仅运行
        if _path_occupied_real(hit_path):
            _bt = _classify_block_type(hit_path)
            if _bt != "free":
                blocks.append({
                    "path": hit_path,
                    "name": name,
                    "processes": hit_proc,
                    "type": _bt,
                })
        else:
            warnings.append({
                "path": hit_path,
                "name": name,
                "processes": hit_proc,
            })
    # 2) 伞形目录：同厂商应用整组视为需关闭（强杀释放锁），真锁才硬拦
    for np_ in norm_paths:
        for gname, gprocs in _umbrella_groups_for(np_):
            # 已被 per-row 覆盖的（微信/QQ 本身带 tencent 关键词）跳过，避免重复
            if any(b.get("path") == np_ and b.get("name") == gname for b in blocks):
                continue
            rg = [p for p in gprocs if p in procs]
            if not rg:
                continue
            if _path_occupied_real(np_):
                _bt = _classify_block_type(np_)
                if _bt != "free":
                    blocks.append({"path": np_, "name": gname, "processes": rg, "type": _bt})
            else:
                warnings.append({"path": np_, "name": gname, "processes": rg})

    # 3) 兜底：对每个尚未判锁的路径做改名探测，捕获『无用户进程、仅杀软内核锁』。
    #    这是『第一时间检测、避免花时间才失败』的核心兜底。
    for np_ in norm_paths:
        if any(b.get("path") == np_ for b in blocks):
            continue
        _bt = _classify_block_type(np_)
        if _bt == "av_kernel":
            blocks.append({"path": np_, "name": "杀毒软件占用", "processes": [], "type": "av_kernel"})
        elif _bt == "process":
            blocks.append({"path": np_, "name": "文件夹被占用", "processes": [], "type": "process"})

    # 去重（同一 path 可能多次命中）
    _seen, _dedup = set(), []
    for b in blocks:
        _k = (b.get("path"), b.get("name"))
        if _k in _seen:
            continue
        _seen.add(_k)
        _dedup.append(b)
    blocks = _dedup

    return {
        "is_admin": is_admin(),
        "blocks": blocks,
        "warnings": warnings,
    }


# 仅允许杀死 PATH_PROCESS_MAP 登记的进程（白名单），绝不接受任意进程名
_KILL_WHITELIST = set()
for _kw, _nm, _pl in PATH_PROCESS_MAP:
    _KILL_WHITELIST.update(_pl)


def _kill_whitelisted_procs(proc_names):
    """白名单制杀进程：只杀 PATH_PROCESS_MAP 登记的进程，防止误杀系统/用户进程。

    增强（根治「微信托盘退出但后台进程仍占用、单杀子进程被父进程重启、看门狗自动复活」的死循环）：
    1. 把请求的进程名扩展到「同一软件」的全部白名单进程（如杀 wechatappex 同时杀
       weixin/wechat/wechatutility），避免只杀子进程被父进程 weixin 立即重启。
    2. 使用 taskkill /F /T /IM <name>.exe 终止整个进程树（含子进程）。
    3. 父进程优先杀（weixin 先于 wechatappex），杀父即连带杀全部子进程。
    4. 单次失败自动重试最多 3 次，每次间隔 2 秒（防看门狗 1~2 秒内重启）。
    5. 组级最终复检：逐个杀完后统一等 3 秒，对仍存活的进程再补一轮精准 PID 杀。

    返回 {killed:[...], failed:[...], skipped:[...], retried:[...]}：
    - killed：成功终止，或本就不在运行（视为已关闭）
    - failed：多次尝试仍无法终止
    - skipped：不在白名单，被拒绝（安全兜底，绝不杀未知进程）
    - retried：需要重试才杀掉的进程
    """
    import time
    killed, failed, skipped, retried = [], [], [], []
    if not sys.platform.startswith("win"):
        return {"killed": killed, "failed": failed, "skipped": skipped, "retried": retried,
                "note": "仅 Windows 支持终止进程"}
    # 进程名 -> 同组全部白名单进程（用于按组整杀，防止父进程重启子进程）
    group_map = {}
    for _pat, _label, procs in PATH_PROCESS_MAP:
        for p in procs:
            group_map.setdefault(p, set()).update(procs)
    # 展开请求：每个请求名扩展为同组全部进程，去重
    expanded = set()
    for name in (proc_names or []):
        nm = (name or "").strip().lower()
        if not nm:
            continue
        if nm not in _KILL_WHITELIST:
            skipped.append(nm)
            continue
        expanded.update(group_map.get(nm, {nm}))

    # 已知「父进程/主进程」优先杀（杀父即连带 /T 杀全部子进程，避免子进程被父进程立刻重启）
    # 常见主进程：weixin(微信)、wxwork(企业微信)、qq、chrome、msedge 等
    _PARENT_FIRST = {
        "weixin", "wxwork", "qq", "tim", "chrome", "msedge",
        "wps", "dingtalk", "feishu", "lark", "wemeet",
        "thunder", "discord", "telegram", "spotify",
    }

    def _kill_order(nm):
        """排序键：父进程优先（0），其余按字母序（1）。"""
        return (0 if nm in _PARENT_FIRST else 1, nm)

    # 逐个进程：整树强杀 + 重试 + 复检（父进程优先）
    ordered = sorted(expanded, key=_kill_order)
    for nm in ordered:
        attempts = 0
        alive = True
        while alive and attempts < 3:
            attempts += 1
            try:
                out = subprocess.run(
                    ["taskkill", "/F", "/T", "/IM", nm + ".exe"],
                    capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=12,
                    creationflags=CREATE_NO_WINDOW,
                )
                rc = out.returncode
            except Exception:
                rc = 1
            # 退出码 0=成功；128/未找到=进程已退出（视为已关闭）
            if rc == 0 or rc == 128 or "not found" in (out.stderr or out.stdout or "").lower():
                alive = False
                killed.append(nm)
            else:
                # 还没死：等 2 秒让系统回收 + 防看门狗重启（旧值 0.6s 太短）
                time.sleep(2)
                if nm not in _get_running_procs():
                    alive = False
                    killed.append(nm)
        if alive:
            failed.append(nm)
            if attempts > 1:
                retried.append(nm)

    # 组级最终复检：逐个杀完后统一等 3 秒，用精准 PID 补杀仍存活的进程
    # （解决「每个单独看都杀了、但看门狗在间隙重启」的极端情况）
    still_alive_names = set(expanded) - set(killed) - set(skipped)
    if still_alive_names:
        time.sleep(3)
        running = _get_running_procs()
        for nm in list(still_alive_names):
            if nm not in running:
                # 此轮等待后已死，归入 killed
                killed.append(nm)
                if nm in failed:
                    failed.remove(nm)
                continue
            # 仍活着：尝试按精准 PID 杀（比 /IM 更可靠，不受同名新进程干扰）
            try:
                pids_out = subprocess.run(
                    ["tasklist", "/FI", "IMAGENAME eq %s.exe" % nm, "/FO", "CSV", "/NH"],
                    capture_output=True, text=True, encoding="utf-8", errors="ignore", timeout=8,
                    creationflags=CREATE_NO_WINDOW,
                )
                import re
                pids = re.findall(r'"(\d+)"', pids_out.stdout or "")
                for pid in pids[:5]:  # 最多杀 5 个同名 PID
                    subprocess.run(
                        ["taskkill", "/F", "/T", "/PID", pid],
                        capture_output=True, timeout=5,
                        creationflags=CREATE_NO_WINDOW,
                    )
                time.sleep(2)
                if nm not in _get_running_procs():
                    killed.append(nm)
                    if nm in failed:
                        failed.remove(nm)
                    retried.append(nm)
            except Exception:
                pass  # 最终兜底失败也不抛异常

    return {"killed": killed, "failed": failed, "skipped": skipped, "retried": retried}


def release_locks_for(src):
    """给定迁移源目录，杀掉其所属软件组（白名单内）的全部进程，释放文件锁。

    用于迁移「复制-校验-切换」阶段遇到被锁文件时自动重试：只需传入 src 路径，
    即按 PATH_PROCESS_MAP 关键词匹配出所属软件（如 Roaming\\Tencent → 微信组 + QQ组），
    整组强杀（含 /T 进程树 + 重试），从而把"复制中途被锁"转化为"自动释放后补复制"，
    彻底消除「花了时间最后还失败」的体验。

    安全：仅杀 PATH_PROCESS_MAP 登记的进程；白名单外的进程（含系统进程）绝不碰。
    """
    if not sys.platform.startswith("win"):
        return {"killed": [], "failed": [], "skipped": [], "note": "仅 Windows 支持"}
    np_ = (src or "").lower().replace("/", "\\")
    names = set()
    for keywords, _name, proc_list in PATH_PROCESS_MAP:
        if any(kw in np_ for kw in keywords):
            names.update(proc_list)
    # 伞形目录补齐：迁移整树时，同厂商旗下所有软件（含路径关键词匹配不到的企业微信等）
    # 都可能锁文件，一并强杀，彻底消除「复制中途被某同厂商进程锁住」的失败。
    np_ = (src or "").lower().replace("/", "\\")
    for gname, gprocs in _umbrella_groups_for(np_):
        names.update(gprocs)
    if not names:
        return {"killed": [], "failed": [], "skipped": [], "note": "未匹配到软件组"}
    return _kill_whitelisted_procs(sorted(names))


def _quick_kill_for(src):
    """快速杀整组白名单进程（taskkill /F /T /IM 父进程优先，不等待复检）。

    专为「改名紧循环」设计：release_locks_for 含 2s×3 等待 + 组级复检，全程 9s+，
    而微信看门狗 1-2s 就复活——等它返回时进程又活了。_quick_kill_for 只发 taskkill
    命令、不等待，让调用方在杀完瞬间立即改名，赶在看门狗复活前完成本次迁移。
    复制阶段遇锁也用它（配合 robocopy /R:5 /W:2 重试扛瞬时锁）。
    安全：仅杀 PATH_PROCESS_MAP 白名单 + 伞形组，系统/未知进程绝不碰。

    【2026-07-25 热修复】用户核心通讯软件（微信/QQ/企业微信）绝不自动强杀，
    避免迁移时把用户正在用的微信/QQ 关掉。这类目录迁不了时明确提示用户手动关闭。
    """
    if not sys.platform.startswith("win"):
        return {"killed": [], "failed": [], "skipped": [], "note": "仅 Windows"}
    np_ = (src or "").lower().replace("/", "\\")
    # 核心通讯软件：不自动杀
    _PROTECTED_APPS = {"微信", "QQ/TIM", "企业微信"}
    names = set()
    for keywords, _name, proc_list in PATH_PROCESS_MAP:
        if _name in _PROTECTED_APPS:
            continue
        if any(kw in np_ for kw in keywords):
            names.update(proc_list)
    for _gname, gprocs in _umbrella_groups_for(np_):
        if _gname in _PROTECTED_APPS:
            continue
        names.update(gprocs)
    if not names:
        return {"killed": [], "failed": [], "skipped": [], "note": "未匹配到可自动关闭的软件组"}
    _PARENT_FIRST = {"chrome", "msedge", "wps", "dingtalk", "feishu", "lark",
                     "wemeet", "thunder", "discord", "telegram", "spotify"}
    killed = []
    # 父进程优先，/T 整树强杀，一次性发命令不等待（让调用方紧接改名）
    for nm in sorted(names, key=lambda n: (0 if n in _PARENT_FIRST else 1, n)):
        try:
            subprocess.run(["taskkill", "/F", "/T", "/IM", nm + ".exe"],
                           capture_output=True, timeout=2,
                           creationflags=CREATE_NO_WINDOW)
            killed.append(nm)
        except Exception:
            pass
    return {"killed": killed, "failed": [], "skipped": [], "note": "quick"}


def _clean_state_dir():
    """迁移/清理状态稳定目录：与 license.json 同处一个用户数据目录，
    不随每次扫描生成的带时间戳 analysis 文件迁移，保证迁移记录跨扫描持久存在。

    AIPC-DATADIR-FIX-SRVCSD (2026-09-10 P0)：统一委托 license_mod.get_data_dir()，
    避免 APPDATA 缺失时状态目录漂移，导致"激活记录读不到 / 迁移记录丢失"。
    """
    try:
        return license_mod.get_data_dir()
    except Exception:
        pass
    base = os.environ.get("APPDATA") or os.path.join(
        os.environ.get("USERPROFILE") or os.path.expanduser("~"), "AppData", "Roaming")
    d = os.path.join(base, "AI_PC_Butler")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _clean_state_path():
    return os.path.join(_clean_state_dir(), "clean_state.json")


def _clean_state_legacy_path():
    if not sys.argv or len(sys.argv) < 2:
        return None
    return os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), "clean_state.json")


def _clamp_release_json(_s):
    """AIPC-FREED-DEDUP-FIX（渲染期兜底）：把释放量夹到物理上限以内。

    上游任何算法错误只要漏到这一步，用户看到的就是自相矛盾的报告页 —— 真机
    出现过「120GB 的盘显示本次释放 258.7GB」（按路径重复累加所致，8.0GB×33），
    连带把双环打成「清理前 100%／仅剩 0GB／清理后还有 120GB」。
    释放量在物理上不可能超过「这块盘的已用空间」→ 以此为上限单点夹住。
    历史脏数据（已落盘在 clean_state.json 里的 258.73）同样被拦住。
    拿不到上限时原样返回 —— 宁可不夹，也绝不制造新错误。
    """
    try:
        if not _s:
            return _s
        _cands = []
        try:
            _di = (DATA.get("disk_info") or {})
            for _k in ("used_gb", "total_gb"):
                _v = float(_di.get(_k) or 0)
                if _v > 0:
                    _cands.append(_v)
        except Exception:
            pass
        try:
            import shutil as _sh3
            _cands.append(_sh3.disk_usage("C:").used / 1073741824.0)
        except Exception:
            pass
        _cap = min(_cands) if _cands else 0.0
        if _cap <= 0:
            return _s
        _o = json.loads(_s)
        if not isinstance(_o, dict):
            return _s
        _hit = []
        for _k in ("rm", "migrate"):
            _b = _o.get(_k)
            if not isinstance(_b, dict):
                continue
            # AIPC-SETTLE-TRUTH-FIX（第 4 道）：没有磁盘实测就【不许】把任何数字
            # 渲染成"已释放"。旧台账里可能残留标称估算（真机 258.73GB 就是这么
            # 进到用户眼前的）。无实测 → 归零 + 打 unmeasured，前端据此说明未测到。
            # AIPC-SETTLE-TRUTH-FIX（收紧）：只有**显式** measured=true 才算实测。
            # 曾经用「calibrated 且 freed_gb>0」当兼容判据 —— 那是错的：真机
            # clean_state.json 里 calibrated=true 与 freed_gb=258.73 同时存在过
            # 。孤儿旗帜的真实来源有两处，现在都已堵掉：
            # ① 校准线程落盘时把 calibrated 硬写成 True，与实测成功与否无关
            #    （自 AIPC-FREED-PEAK-FIX 起改为镜像 _measured_ok）；
            # ② run.py 重置时只删 freed 不删 calibrated（已改为连测量旗帜一起清）。
            # 判据一命中就去走"夹到上限"，把假的 258.73 夹成假的 102.50 放行。
            # 判据一放宽 = 假数据就有第二条活路，所以这里只认显式实测。
            _meas = (_b.get("measured") is True)
            if not _meas:
                if float(_b.get("freed_gb") or 0) > 0:
                    _hit.append("%s 无实测->0（原 %.2f）" % (_k, float(_b.get("freed_gb") or 0)))
                    _b["freed_gb"] = 0.0
                    _b["freed"] = 0
                    _b["unmeasured"] = True
                # 标"未实测"必须同时把 measured 落成 False：前端/报告页统一按
                # measured 判断是否显示数字，只给 unmeasured 会让页面停在旧数字上。
                _b["measured"] = False
                # v1.7.83（老李实测「0.0GB 清理已安排」修复）：
                # 归零之后【不能就这么显示 0.0】——老李 2026-10-04 实操看到
                # 「一键清 10.6GB → 弹窗 0.0GB」，直接判定"skill 没起作用"。
                # 实测根因：校准线程（wait_purge 300s + 4 次采样）期间进程被杀
                # （工具被关/被停），settle 从未执行 → freed=0/settled=False →
                # 上面这道防线照章归零 → 用户看到 0.0。
                #
                # 修法：拿「本次真实提交删除的字节数」当兜底显示值。
                # 它不是磁盘实测，但绝不会是 0 —— 因为确实有那么多条路径被成功提交了
                # （done 非空）。落盘字段 planned_gb，前端据此显示
                # 「已清理 X GB（后台还在继续，数字可能再涨）」。
                # 诚实性不受损：明确标注是「已提交」口径，不是「已实测释放」口径。
                _pg = _b.get("planned_gb")
                if _pg is None:
                    _pg = _b.get("est_gb")
                if _pg is None:
                    # v1.7.83：claimed_gb 就是本次「已提交删除」的量（_save_clean_state
                    # 在 done 那一刻就落好了，比 submitted_gb 更早更可靠）。
                    _pg = _b.get("claimed_gb")
                try:
                    _pg = float(_pg or 0)
                except Exception:
                    _pg = 0.0
                if _pg > 0:
                    _b["submitted_gb"] = round(_pg, 2)
                    _b["unmeasured"] = True      # 仍是未实测，前端必须如实标注
                continue
            try:
                _g = float(_b.get("freed_gb") or 0)
            except Exception:
                _g = 0.0
            if _g > _cap:
                _hit.append("%s %.2f->%.2f" % (_k, _g, _cap))
                _b["freed_gb"] = round(_cap, 2)
                _b["clamped"] = True
                try:
                    _b["freed"] = int(_cap * 1073741824)
                except Exception:
                    pass
        if _hit:
            _log("render clamp release: cap=%.2f GB, %s", _cap, "; ".join(_hit))
        return json.dumps(_o, ensure_ascii=False).replace("</", "<\\/")
    except Exception:
        return _s


_AIPC_HEAL_ONCE = {"done": False}


def _aipc_heal_stale_progress(path):
    """v1.7.98 P0 自愈：清掉磁盘上陈旧的 in_progress。

    ★ 2026-10-09 实测修正：本函数必须**每进程只执行一次**。原实现挂在
    _load_clean_state_raw 里每次读取都跑 —— 前端兜底轮询每 1.5s 读一次，
    结果把【正在运行的清理】的 in_progress 活标记当"陈旧"误杀（启动后 3 秒即被清，
    日志铁证 10:13:39 clean start → 10:13:42 heal），前端从此永远读到"没在跑、0 完成"，
    页面表现为一键清永远卡 0/47。
    判据（非猜测）：进程启动后的**首次**读取时，上个进程的清理/迁移绝无可能还在跑
    → 磁盘残留必是陈旧。只清 in_progress，不动 done/failed/freed 等真实结果。
    """
    if _AIPC_HEAL_ONCE["done"]:
        return
    _AIPC_HEAL_ONCE["done"] = True
    try:
        if not path or not os.path.exists(path):
            return
        st = json.load(open(path, encoding="utf-8"))
        if not isinstance(st, dict):
            return
        dirty = False
        for m in ("rm", "migrate", "trash", "open"):
            sub = st.get(m)
            if isinstance(sub, dict) and sub.get("in_progress"):
                sub["in_progress"] = False
                sub["stale_cleared"] = True
                dirty = True
        if dirty:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(st, f, ensure_ascii=False)
            _log("heal: cleared stale in_progress")
    except Exception:
        pass


def _load_clean_state_raw():
    """读取清理/迁移状态原始 JSON 字符串。
    优先稳定路径(app-data)，回退旧路径(analysis 同目录)，再回退空对象。
    修复：之前状态文件写在 analysis 同目录，新扫描生成新 analysis 文件后读不到，
    用户看到的「迁移记录没了」根因之一。"""
    p = _clean_state_path()
    # v1.7.99：自愈陈旧 in_progress 已移到 server 启动时跑一次（见 main），
    # 这里不再每次读都跑 —— 否则会把本次正在进行的清理活标记当陈旧误杀，
    # 前端永远读到"没在跑、0完成"，表现为一键清卡 0/47。
    if os.path.exists(p):
        try:
            return open(p, encoding="utf-8").read()
        except Exception:
            pass
    lp = _clean_state_legacy_path()
    if lp and os.path.exists(lp):
        try:
            return open(lp, encoding="utf-8").read()
        except Exception:
            pass
    return "{}"


# AIPC-SETTLE-TRUTH-FIX：clean_state.json 的读写锁。
# 根因：清理校准线程（rm）与迁移校准线程（migrate）各自对同一个文件做【读-改-写】
# 且完全没有锁 —— 后写者会用自己读到的旧快照覆盖前写者的结果（lost update），
# 真机台账里因此出现过「已落盘 0.03GB 的实测值被抹回 0」这种自相矛盾的记录。
# 所有落盘（_save_clean_state / 两处校准 / 进度标记）统一走本锁。
_STATE_LOCK = threading.Lock()

# AIPC-FREED-PEAK-FIX：全程可用空间采样线程的停止令牌（见 do_action 入口）。
# 0 = 没有任何采样线程需要停。结账时写入【本请求自己的令牌】，线程只认自己的令牌。
# 为什么不用全局布尔：连点两次清理时（真机发生过，台账里留下过 8.3+8.3=16.6GB），
# 第一次结账会把第二次的采样线程一起掐掉 -> 第二次又退回"只采末尾余量"的老毛病。
_FREE_SAMPLE = {"stop": 0}


def _save_clean_state(mode, done, failed, failed_reasons, freed, freed_gb, details=None,
                      reset_measured=False):
    """把本次清理/迁移结果落盘，刷新页面后也能回到清理后状态。

    mode 为 migrate 时，details 是每条迁移记录的完整列表（含 src/dst/kb/ok/msg），
    用于在「迁移记录」里显示迁了什么、迁到哪、是否成功。
    """
    if not CLEAN_STATE_PATH:
        return
    try:
        state = {}
        if os.path.exists(CLEAN_STATE_PATH):
            try:
                state = json.load(open(CLEAN_STATE_PATH, encoding="utf-8"))
            except Exception:
                state = {}
        prev = state.get(mode, {}) or {}
        # 合并历史，避免后续调用（含探针等非实际迁移请求）把已完成的迁移记录清空
        prev_done = set(prev.get("done") or [])
        prev_failed = set(prev.get("failed") or [])
        prev_reasons = dict(prev.get("failed_reasons") or {})
        prev_records = list(prev.get("records") or [])
        # v1.7.33「补齐剩余」必须能翻身：本次结果对同一路径要**覆盖**历史，不能被旧状态挡住。
        # 旧实现 done/failed 只做并集、records 见 src 即丢弃新条目 → 一旦某项失败过，
        # 补齐成功后报告仍显示「没搬完」，用户会认为工具没用。
        cur_done = set(done or [])
        cur_failed = set(failed or [])
        merged_done = sorted((prev_done | cur_done) - cur_failed)
        merged_failed = sorted((prev_failed | cur_failed) - cur_done)
        merged_reasons = dict(prev_reasons)
        merged_reasons.update(failed_reasons or {})
        for _s in cur_done:  # 这次搬成了，历史失败原因清掉
            merged_reasons.pop(_s, None)
        # records 合并：本次涉及的 src 用最新记录覆盖，其余保留历史
        new_records = details or []
        _new_srcs = {r.get("src") for r in new_records}
        merged_records = [r for r in prev_records if r.get("src") not in _new_srcs] + list(new_records)
        # AIPC-SETTLE-TRUTH-FIX（释放量口径分离）：
        # 本函数的 freed 参数是【标称估算】—— 扫描时算出的「这些条目一共多大」，
        # 不是磁盘上真的少了多少。旧实现把它写进 freed/freed_gb 落盘，于是
        # 【估算】与【磁盘实测】两个不同口径共用同一字段，必然打架：
        #   ① 连点两次「一键清」→ 8.3 + 8.3 = 16.6GB「已释放」（估算累加，凭空翻倍）；
        #   ② 报告页把估算直接当「本次释放」展示，用户拿资源管理器一核就是假的。
        # 现在：估算只进 claimed/claimed_gb（同一字段取最大值，绝不累加）；
        # freed/freed_gb 的唯一写入者是磁盘实测（_calibrate_freed /
        # _calibrate_migrate_freed）。
        # reset_measured=True（主清理/迁移动作）：本次必然会有实测结账 → 先把上一轮
        # 的实测值清零并 measured=False，宁可页面先显示「正在核对」，也不把上次的
        # 数字冒充这一次。
        # reset_measured=False（探针、重启补齐登记等不产生实测的落盘）：必须保留已有
        # 实测值，否则会把用户上一次真实释放的数字抹成 0。
        _prev_claimed = float(prev.get("claimed") or 0)
        _claimed = max(_prev_claimed, float(max(0, freed)))
        if reset_measured:
            _freed_v, _measured_v, _settled_v = 0, False, False
        else:
            _freed_v = int(prev.get("freed") or 0)
            _measured_v = bool(prev.get("measured"))
            _settled_v = bool(prev.get("settled"))
        state[mode] = {
            "done": merged_done,
            "failed": merged_failed,
            "failed_reasons": merged_reasons,
            "claimed": int(_claimed),
            "claimed_gb": round(_claimed / 1073741824.0, 2),
            "freed": _freed_v,
            "freed_gb": round(_freed_v / 1073741824.0, 2),
            "measured": _measured_v,
            "settled": _settled_v,
            "ts": time.time(),
            "records": merged_records,
            "in_progress": False,
        }
        # 上一轮登记的「需重启才释放」是既成事实，跨轮保留
        # （build_report._measured_reboot_kb 依赖它给出保守下界，清了会让报告少算一块）
        if isinstance(prev.get("reboot_pending"), dict):
            state[mode]["reboot_pending"] = prev["reboot_pending"]
        # AIPC-SETTLE-TRUTH-FIX：calibrated 是旧版（<=v1.7.74）的"已标定"旗帜。
        # 它会与实测值脱钩、被 run.py 的重置残留下来，是一个纯粹会撒谎的孤儿字段
        # （真机就是 calibrated=true 配 freed_gb=0 这个矛盾组合）。
        # 现在让它**只镜像 measured**：有实测才为真，绝不独立保留。
        state[mode]["calibrated"] = bool(_measured_v)
        # v1.7.37（审查修复·P0 防迁移记录丢失）：原子写——先写临时文件再 os.replace，
        # 避免进程中途被杀/断电导致 json 半写损坏 → 下次读 json.load 失败、记录"消失"。
        # 写入失败不再静默：留痕到日志，便于排查「迁移记录没了」。
        try:
            _tmp = CLEAN_STATE_PATH + ".tmp"
            with open(_tmp, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False)
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
            try:
                os.replace(_tmp, CLEAN_STATE_PATH)
            except Exception:
                os.rename(_tmp, CLEAN_STATE_PATH)
        except Exception as _w:
            _log("save_clean_state write failed: %s", _w)
    except Exception as _e:
        _log("save_clean_state failed: %s", _e)


def _set_clean_state_progress(mode, in_progress):
    """标记某操作是否进行中。用户在清理/迁移时刷新页面，可据此恢复或提示继续。"""
    if not CLEAN_STATE_PATH:
        return
    try:
        state = {}
        if os.path.exists(CLEAN_STATE_PATH):
            try:
                state = json.load(open(CLEAN_STATE_PATH, encoding="utf-8"))
            except Exception:
                state = {}
        cur = state.get(mode, {}) or {}
        cur["in_progress"] = bool(in_progress)
        state[mode] = cur
        with open(CLEAN_STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except Exception:
        pass


def _scan_bak_residuals():
    """E：扫描用户目录下所有 *.migrated.bak 冗余副本目录，校验完整性，返回可安全删除的列表。

    这些 .bak 是迁移过程中的「改名残留」——数据已在 D 盘（junction 目标），bak 只是冗余副本。
    仅当 bak 内每个文件在 dst（junction 目标）都有同名且大小一致的副本时，才标记 safe_to_delete，
    否则保留（数据不完整，宁留勿丢）。绝不删除用户真实文件，只删确认冗余的迁移残留。
    """
    results = []
    if not sys.platform.startswith("win"):
        return results
    HOME = os.path.expanduser("~")
    seen_real = set()  # 按 realpath 去重，避免同一物理目录被多条 junction 路径重复枚举
    try:
        base_depth = HOME.count(os.sep)
        for root, dirs, files in os.walk(HOME):
            # 限制扫描深度（用户目录通常 3-5 层），过深则剪枝，避免全盘卡顿
            if root.count(os.sep) - base_depth > 6:
                dirs[:] = []
                continue
            # 不 descend 进 reparse 点（junction）：Windows 的 AppData\Application Data、
            # Local Settings 等是指向自身的遗留 junction，descend 会陷入死循环并重复枚举同一目录。
            # 仅剪枝 junction；.migrated.bak 是 junction 的「兄弟目录」，不会被误剪。
            pruned = []
            for d in dirs:
                dp = os.path.join(root, d)
                try:
                    if os.lstat(dp).st_file_attributes & 0x400:
                        continue  # 是 junction/reparse 点，剪枝
                except Exception:
                    pass
                pruned.append(d)
            dirs[:] = pruned
            bak_dirs = [d for d in dirs if d.endswith(".migrated.bak")]
            for bd in bak_dirs:
                bak_path = os.path.join(root, bd)
                # 去重：同一物理目录可能被多条 junction 路径命中，按 realpath 合并只保留一份
                try:
                    rk = os.path.realpath(bak_path)
                except Exception:
                    rk = bak_path
                if rk in seen_real:
                    continue
                seen_real.add(rk)
                # v1.7.45：复用 migrate.classify_bak_residual 做基础判定（src 状态 + dst 可达），
                # server 这里再补文件级 missing 比对（精确但慢，仅 server 清理时跑）。
                src = bak_path[:-len(".migrated.bak")]
                dst = ""
                src_is_junction = False
                try:
                    st = os.lstat(src)
                    src_is_junction = bool(getattr(st, "st_file_attributes", 0) & 0x400) or os.path.islink(src)
                    if src_is_junction:
                        dst = os.readlink(src)
                except Exception:
                    dst = ""
                total_files, missing, size_kb = 0, 0, 0
                try:
                    for dp, dn, fn in os.walk(bak_path):
                        for fl in fn:
                            sf = os.path.join(dp, fl)
                            total_files += 1
                            try:
                                size_kb += os.path.getsize(sf)
                            except Exception:
                                pass
                            rel = os.path.relpath(sf, bak_path)
                            tf = os.path.join(dst, rel) if dst else ""
                            if not (tf and os.path.exists(tf) and os.path.getsize(tf) == os.path.getsize(sf)):
                                missing += 1
                except Exception:
                    missing = total_files or 1
                # v1.7.45：诊断原因分级（why 字段），前端确认/结果弹窗直接展示，
                # 避免「扫描说有残留 → 点清理 → 没可清理的残留」这种摸不着头脑的体验。
                # 常见 4 类：junction_broken / dst_missing / dst_mismatch / dst_unreadable
                why = ""
                safe = False
                if not dst:
                    if not src_is_junction:
                        # src 已不是 junction —— 典型孤儿场景（D 盘副本可能还在但工具无法验证对应关系）
                        why = "junction_broken"
                    else:
                        # junction 在但 readlink 失败（极少）——按不可删处理
                        why = "dst_unreadable"
                elif not os.path.exists(dst):
                    why = "dst_missing"
                elif missing > 0:
                    why = "dst_mismatch"
                else:
                    safe = True
                results.append({
                    "bak": bak_path,
                    "src": src,
                    "dst": dst,
                    "size_kb": round(size_kb / 1024, 1),
                    "total_files": total_files,
                    "missing": missing,
                    "safe_to_delete": safe,
                    "why": why,
                })
    except Exception:
        pass
    return results


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        _log(fmt % a)

    def handle_one_request(self):
        global LAST_REQUEST_TIME
        LAST_REQUEST_TIME = time.time()
        super().handle_one_request()

    def _send(self, code, body, ctype="application/json"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_HEAD(self):
        """AIPC-HEAD-PROBE-FIX：有些预览面板 / 探活客户端在展示前先发 HEAD 探活。

        BaseHTTPRequestHandler 默认不实现 HEAD，会回 501 Unsupported method ——
        客户端可能据此判定"这个地址是坏的"，于是明明服务好好的、报告页却不展示。
        实测本机侧边栏就发过 `HEAD /?token=...` 并拿到 501。这里统一回 200（不带正文），
        彻底消灭"服务活着、探测方却认为它坏了"这条假失败路径。
        """
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", "0")
            self.end_headers()
        except Exception:
            pass

    def do_GET(self):
        global DATA, TPL, RM_ALLOW, TRASH_ALLOW, OPEN_ALLOW, ANALYSIS_PATH
        # v1.7.19：URL 带 token（/?token=xxx）供 run.py 复用分支鉴权，首页匹配须剥离 query
        from urllib.parse import urlparse as _up0
        _path0 = _up0(self.path).path or "/"
        # AIPC-REPORT-OPEN-FIX：报告页"报到"端点（由页面内 JS 主动调用）。
        # 刻意【不】在 GET / 时写标记：任何探活 / 端口探测 / 可达性检查都会 GET /，
        # 那会把"没人真的看到报告"误判成"侧边栏已打开"，使浏览器兜底永不触发 ——
        # 恰好掐掉"侧边栏打不开就用浏览器打开"这条救命路径。
        # 改由页面渲染成功后 fetch 报到：只有真正渲染出来的页面才会报到，判定准确。
        if _path0 in ("/viewed", "/__viewed"):
            try:
                with open(os.path.join(_DATA_DIR, "report_viewed.txt"), "w",
                          encoding="utf-8") as _vf:
                    _vf.write(str(int(time.time())))
            except Exception:
                pass
            self._send(200, '{"ok":true}')
            return
        if _path0 in ("/", "/index.html"):
            # 迁移计划按当前磁盘过滤已迁成 junction 的项，并重算合计：
            # 避免「已迁走却仍列在可迁移里」+ 合计含 analyze 多算的幽灵值。
            # 每次请求都做，开销可忽略（plan 仅数项），无论用户何时迁的刷新页面都不再冒出。
            _inject = DATA
            _mig = DATA.get("migration") or {}
            _plan = _mig.get("plan") or []
            _cands = _mig.get("candidates") or []
            # 按当前磁盘真实状态过滤已迁成 junction 的项（plan 用 src，candidates 用 path），
            # 避免「已迁走却仍列在可迁移里」；合计按过滤后真实 size_kb 重算，杜绝 analyze 幽灵值。
            _keep_plan = [p for p in _plan if not migrate_mod._under_junction(p.get("src", ""))]
            _keep_cands = [c for c in _cands if not migrate_mod._under_junction(c.get("path", ""))]
            if len(_keep_plan) != len(_plan) or len(_keep_cands) != len(_cands):
                _inject = dict(DATA)
                _inject["migration"] = dict(_mig)
                _inject["migration"]["plan"] = _keep_plan
                _inject["migration"]["candidates"] = _keep_cands
                _tk = sum(float(p.get("size_kb", 0) or 0) for p in _keep_plan)
                _inject["migration"]["reclaim_kb"] = _tk
                _inject["migration"]["reclaim_h"] = migrate_mod._kb_h(_tk)
            # 重算 Pro 合计：保证 solution.pro_reclaim_h 与页面(green+迁移)完全自洽，
            # 杜绝 devtools 里看到 21.5 而页面显示 16.6 的幽灵差异，重建用户数字信任。
            _sol = DATA.get("solution") or {}
            try:
                _green_gb = float(str(_sol.get("green_reclaim_h") or "").replace(" GB", "").strip() or 0)
            except Exception:
                _green_gb = 0.0
            _mig_block = (_inject.get("migration") or {})
            try:
                _mig_gb = float(str(_mig_block.get("reclaim_h") or "").replace(" GB", "").strip() or 0)
            except Exception:
                _mig_gb = 0.0
            _pro_gb = round(_green_gb + _mig_gb, 1)
            if _inject is DATA:
                _inject = dict(DATA)
            _inject["solution"] = dict(_sol)
            _inject["solution"]["pro_reclaim_h"] = ("%.1f GB" % _pro_gb)
            # 释放区间：保底/上限/差距。实现收口在 build_report._inject_release_range；
            # 保底扣减只用实测残留（见 AIPC-RELEASE-RANGE-TRUTH-FIX）。
            _inject = _inject_release_range(_inject)
            # P0-3：注入前转义 </ 防止路径/名称中的 </script> 闭合脚本标签造成 XSS（可盗 token 删文件）
            blob = json.dumps(_inject, ensure_ascii=False).replace("</", "<\\/")
            cfg = json.dumps({"token": TOKEN, "endpoint": "/action"}).replace("</", "<\\/")
            # 许可状态：当前 tier + 是否授权（前端据此决定显示“一键清”还是“授权”锁）
            lic = license_mod.read_license()
            lic_blob = json.dumps({
                "tier": lic.get("tier", 0),
                "active": bool(lic.get("active", False)),
                "exp": lic.get("exp", 0),
                "version": lic.get("version", ""),
                "hwid": license_mod.get_hwid(),
            }, ensure_ascii=False).replace("</", "<\\/")
            # 清理/迁移状态持久化：刷新后回到清理后状态。
            # P2-3 修复（2026-08-01 审查）：复用 build_report._build_clean_state_blob ——
            # 新扫描全清 clean_state 后，「已迁移」记录由真实磁盘 junction 自动推断兜底
            # （含 reboot_done 标记），用户重新扫描不会误以为迁移记录丢了。
            try:
                from build_report import _build_clean_state_blob as _bcsb
                _raw_plan = list(((DATA.get("migration") or {}).get("plan")) or [])
                clean_state = _bcsb(ANALYSIS_PATH, _raw_plan)
            except Exception:
                clean_state = _load_clean_state_raw()
                try:
                    from migrate import _under_junction
                    _cs_obj = json.loads(clean_state)
                    for _r in (((_cs_obj.get("migrate") or {}).get("records")) or []):
                        if _r.get("reboot_commit") and not _r.get("reboot_done") and _r.get("src"):
                            if _under_junction(_r.get("src")):
                                _r["reboot_done"] = True
                    clean_state = json.dumps(_cs_obj, ensure_ascii=False)
                except Exception:
                    pass
            c = _load_app_config()
            html = (TPL
                    .replace("__INJECT_DATA__", blob)
                    .replace("__DELETE_CFG__", cfg)
                    .replace("__LICENSE_CFG__", lic_blob)
                    .replace("__CLEAN_STATE_DATA__", _clamp_release_json(clean_state))
                    .replace("__AIPC_CLEAN_STATE_PATH__", json.dumps(CLEAN_STATE_PATH or "").replace("</", "<\\/"))
                    .replace("__IS_ADMIN_VALUE__", "true" if is_admin() else "false")
                    .replace("__PRODUCTS_DATA__", json.dumps(PRODUCTS, ensure_ascii=False).replace("</", "<\\/"))
                    .replace("__CHANNEL_VAL__", json.dumps(c.get("channel", ""), ensure_ascii=False).replace("</", "<\\/")))
            html = _apply_app_name(html)
            self._send(200, html, "text/html; charset=utf-8")
        elif self.path.startswith("/ping"):  # AIPC-PING-MATCH-FIX
            # 连通性探针：报告页加载时探测服务是否存活（R4 修复）
            self._send(200, json.dumps({"ok": True, "ping": True}))
        elif _path0 == "/av_state":
            # v1.7.101 审核整改：本工具不探测、不更改任何安全软件状态。
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            self._send(200, json.dumps({"ok": True, "admin": False,
                                        "defender_present": False,
                                        "defender_rt_on": None, "third_party": []},
                                       ensure_ascii=False))
            return
        elif self.path.startswith("/clean_state"):
            # v1.7.29（P0-1 修复）：弹窗期间前端轮询校准值——done 后 SSE 连接关闭，
            # 后台校准线程的 freed 事件送不到前端；前端改轮询本端点，拿到磁盘实测
            # freed_gb 后更新弹窗数字（数字最终诚实，无需刷新页面）。
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            from urllib.parse import urlparse as _up1, parse_qs as _pqs1
            _q1 = _pqs1(_up1(self.path).query)
            if (_q1.get("token") or [""])[0] != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            self._send(200, _clamp_release_json(_load_clean_state_raw()))
        elif self.path.startswith("/healthz"):
            # 健康 + 数据新鲜度探针（v1.7.19 修复 P1-A）：返回当前加载的 analysis
            # 时间戳，供 run.py 复用分支判断「旧 server 是否还显示旧数据」。
            # 只有 127.0.0.1 本机可调；token 校验与其它端点一致（防其它进程探测）。
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            if (q.get("token") or [""])[0] != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            try:
                _mt = os.path.getmtime(ANALYSIS_PATH)
            except Exception:
                _mt = 0
            self._send(200, json.dumps({
                "ok": True,
                "analysis": ANALYSIS_PATH,
                "mtime": _mt,
            }))
        elif self.path.startswith("/scan_state"):
            # v1.7.23 分批扫描：报告页轮询本端点，判断「全量报告是否已 reload 就绪」。
            # is_fast=True 表示当前服务的是快扫首屏数据；后台补全 reload 后变为 False，
            # 前端检测到变化即自动刷新页面（数字只增不减，无需用户操作）。
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            if (q.get("token") or [""])[0] != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            try:
                _mt = os.path.getmtime(ANALYSIS_PATH)
            except Exception:
                _mt = 0
            _is_fast = "_fast_" in (os.path.basename(ANALYSIS_PATH) or "")
            self._send(200, json.dumps({
                "ok": True,
                "analysis": ANALYSIS_PATH,
                "is_fast": _is_fast,
                "mtime": _mt,
            }))
        # ---- 其他盘深度扫描：列出非 C 本地盘（只读，无需授权）----
        elif self.path.startswith("/other_drives"):
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            if (q.get("token") or [""])[0] != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            try:
                import importlib
                so = importlib.import_module("scan_other")
                drives = so.list_other_drives()
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": "列举其他盘失败：" + str(e)}, ensure_ascii=False))
                return
            self._send(200, json.dumps({"ok": True, "drives": drives}, ensure_ascii=False))
            return
        elif self.path.startswith("/reload"):
            # 数据重载（v1.7.19 修复 P1-A）：run.py 复用旧 server 时，若发现其 analysis
            # 落后于本次新扫描，调用本端点把新 analysis 重载进内存（DATA/白名单/模板）。
            # 效果：二次触发「扫描电脑」在 server 存活窗口内也能看到最新报告，无需启新进程。
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            if (q.get("token") or [""])[0] != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            ana = (q.get("analysis") or [""])[0]
            if not ana or not os.path.exists(ana):
                self._send(400, json.dumps({"ok": False, "error": "analysis 路径无效"}))
                return
            # 重载前先确保旧 analysis 目录里的 junction 过滤语义仍适用：
            # load() 会重建白名单（含迁移 junction 剔除），全局替换即可。
            try:
                _new_data, _new_tpl, _new_rm, _new_trash, _new_open = load(ana)
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": "analysis 加载失败：" + str(e)}))
                return
            DATA, TPL, RM_ALLOW, TRASH_ALLOW, OPEN_ALLOW, ANALYSIS_PATH = (
                _new_data, _new_tpl, _new_rm, _new_trash, _new_open, os.path.abspath(ana))
            _log("reload analysis: %s", ANALYSIS_PATH)
            self._send(200, json.dumps({"ok": True, "analysis": ANALYSIS_PATH}))
        elif self.path.startswith("/order_status"):
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            if (q.get("token") or [""])[0] != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            oid = (q.get("order_id") or [""])[0]
            order = _load_orders().get(oid, {})
            status = order.get("status", "not_found")
            # v1.7.10: 冷静期 15s（原为 120s，过长会掩盖真实未付/查单失败，用户付完款卡死）。
            # 扫码支付 1~5s 即到账，15s 足够覆盖扫码+到账延迟；超期仍查单失败才标 error。
            _order_ts = order.get("created") or 0
            _grace = (_order_ts > 0 and (time.time() - _order_ts) < 15)
            # AIPC-PAY-RECOVER-FIX（v1.7.71）：error 订单也必须能重查。
            # 病根：页面「我已付款，立即刷新」按钮调的就是本接口，但旧代码只对 status=="pending"
            # 查单 → 订单一旦被误标 error，按钮点了永远无效、用户付了钱永远拿不到码（真金白银事故）。
            # 治法：把 error 视作「待重查」，查到已付就自愈解锁（服务端 already_fulfilled 幂等，重查安全）。
            # 节流：error 订单每 8s 最多查一次服务端（前端 2s 轮询，不节流会打爆服务端）。
            if status == "error":
                _now_rc = time.time()
                if _now_rc - float(order.get("recheck_at") or 0) >= 8:
                    # AIPC-ORDER-LOCK-FIX（v1.7.76）：改单字段走原子补丁，不再
                    # 「全量读 → 改 → 全量写」（后者会覆盖并发方刚写入的结果）。
                    _x_rc = _patch_order(oid, recheck_at=_now_rc) or order
                    order = _x_rc
                    # 降级为「待查」，让下面的查询块真正跑起来；查不到会再标回 error
                    status = "pending"
                    _log("order_status 重查 error 订单：%s", oid)
            # 支付确认：已下单且拿到扫码 out_trade_no 时，查单确认支付 → 解锁。
            # AIPC-PAID-UNACTIVATED-FIX-B：已付款但本机未解锁的订单，也要继续走下面的
            # 查询块 —— 每查一次会重试一次本机激活（服务端履约幂等，重查安全），一旦成功
            # 立刻自愈成 paid。节流 10 秒，避免 2 秒一查打爆服务端与 /v1/activate 限流。
            if status == "paid_unactivated":
                _now_ua = time.time()
                if _now_ua - float(order.get("unact_recheck_at") or 0) >= 10:
                    # AIPC-ORDER-LOCK-FIX（v1.7.76）：同上，原子补丁。
                    _x_ua = _patch_order(oid, unact_recheck_at=_now_ua) or order
                    order = _x_ua
                    status = "pending"      # 降级为待查，让查询块真正跑起来（含重试激活）
            if status == "pending" and order.get("out_trade_no"):
                # 按订单自身通道查单（不再用全局开关重算），修复「下单走 X402、查单走云端」单号错配
                mode = order.get("mode")
                use_cloud = shub.cloud_order_enabled(force=CFG.get("cloud_pay"))
                if mode == "x402":
                    # X402 通道：重试商户 /invoke（带 X-Out-Trade-No）触发查单+履约，
                    # 拿到授权码即本地授权（支付发生在商户侧，本地不持微信凭证）。
                    try:
                        st = shub.x402_order_status(order["out_trade_no"])
                        if st.get("status") == "paid" and st.get("code"):
                            # AIPC-INSTANT-UNLOCK-FIX（v1.7.79）：先本机验签解锁（零网络、
                            # 零失败）；云端登记转后台重试，失败只记日志 —— 不允许再出现
                            # "钱到了、机没解开"。
                            act_res = _instant_unlock(st["code"], st, order)
                            if act_res.get("ok"):
                                # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁。
                                o = _patch_order(oid, status="paid",
                                                 license_code=st["code"],
                                                 paid_at=int(time.time())) or order
                                order = o
                                status = "paid"
                                # 权限已经到手（本机已解锁）；登记只是让云端台账同步，
                                # 放后台跑，绝不阻塞、绝不回滚用户已获得的权限。
                                _register_license_async(st["code"])
                            else:
                                # AIPC-INSTANT-UNLOCK-FIX 之后，只有两种情况才会走到这里，
                                # 且都是【真拒绝】、不是本机故障：签名验不过（假码）、
                                # 或这张码绑定了别的电脑。此时挂 pending 只会让用户以为
                                # "还在等支付"而再付一次（真金白银事故），故如实标记
                                # paid_unactivated，前端据此提示"回对话框说一句就帮你解开、
                                # 不用再付"，并保留重试。
                                # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁。
                                o = _patch_order(
                                    oid, status="paid_unactivated",
                                    license_code=st["code"],
                                    paid_at=order.get("paid_at") or int(time.time()),
                                    unact_reason=str(act_res.get("error") or "")[:200],
                                    unact_at=int(time.time())) or order
                                order = o
                                status = "paid_unactivated"
                                _log("order_status 已付款但本机未解锁：%s -> %s",
                                     oid, o["unact_reason"])
                        elif st.get("status") == "error":
                            _log("order_status x402 query error: %s", st.get("error"))
                            # v1.7.23（生产修复）：network_error（网络超时/抖动）≠ 订单错误——
                            # 保持 pending 让前端继续轮询重试，绝不误标 error（用户已付款却
                            # 报「确认失败」= 支付事故）。仅明确业务错误（订单不存在等）才标 error。
                            if not _grace and not st.get("network_error"):
                                # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁。
                                o = _patch_order(
                                    oid, status="error",
                                    error=st.get("error", "支付确认失败")) or order
                                order = o; status = "error"
                        elif st.get("status") == "pending" and st.get("network_error"):
                            # 网络抖动：静默保持 pending，前端自动继续轮询（不打扰用户）
                            _log("order_status x402 network retry: %s", st.get("error", ""))
                    except Exception as e:
                        _log("order_status x402 query error: %s", e)
                elif mode == "real":
                    # 真实模式：优先云端查单（无公网 notify_url，本机出站轮询确认支付→解锁）
                    if use_cloud:
                        try:
                            # AIPC-ADMIN-FALLBACK-DEADEND-FIX（v1.7.76）：同 _fulfill_order，
                            # 不再回退 admin 令牌（服务端不认，且客户端不该持有）。
                            ftoken = (os.environ.get("AIPC_FULFILL_TOKEN") or "").strip()
                            st = shub.cloud_order_status(order["out_trade_no"], ftoken)
                            if st.get("status") == "paid" and st.get("code"):
                                # AIPC-INSTANT-UNLOCK-FIX（v1.7.79）：同上 —— 本机验签
                                # 先解锁，云端登记转后台。
                                act_res = _instant_unlock(st["code"], st, order)
                                if act_res.get("ok"):
                                    # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁。
                                    o = _patch_order(oid, status="paid",
                                                     license_code=st["code"],
                                                     paid_at=int(time.time())) or order
                                    order = o
                                    status = "paid"
                                    _register_license_async(st["code"])
                                else:
                                    _log("order_status cloud 授权失败（真拒绝）：%s",
                                         act_res.get("error"))
                            elif st.get("status") == "error":
                                _log("order_status cloud query error: %s", st.get("error"))
                                if not _grace:
                                    # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁。
                                    o = _patch_order(
                                        oid, status="error",
                                        error=st.get("error", "支付确认失败")) or order
                                    order = o; status = "error"
                        except Exception as e:
                            _log("order_status cloud query error: %s", e)
                    elif not shub.is_simulate():
                        # 本地真实扫码 Native 直连：查「查询订单」API 出站轮询
                        try:
                            qr = shub.query_order(order["out_trade_no"])
                            if qr and qr.get("paid"):
                                _fulfill_order(oid, paid_amount_cents=order.get("fee_cents"))
                                order = _load_orders().get(oid, {})
                                status = order.get("status", "paid")
                        except Exception as e:
                            _log("order_status query error: %s", e)
                # 其它模式（simulate 等）保持 pending，由前端轮询处理
            lic = license_mod.read_license()
            self._send(200, json.dumps({
                "order_id": oid,
                "status": status,
                # AIPC-PAID-UNACTIVATED-FIX-C：paid = 钱已确认到账；activated = 本机授权
                # 真的写进去了。二者必须分开返回，前端才不会把"钱到了、机没解开"说成"已解锁"。
                "paid": status in ("paid", "paid_unactivated"),
                "activated": status == "paid",
                "product_id": order.get("product_id", ""),
                "fee_cents": order.get("fee_cents", 0),
                "license_code": order.get("license_code", ""),
                "tier": lic.get("tier", 0),
                "active": bool(lic.get("active", False)),
            }, ensure_ascii=False), "application/json; charset=utf-8")
        elif self.path.startswith("/pay_simulate"):
            # 安全闸门：模拟支付仅限显式开发模式（AIPC_DEV_SIMULATE=1）。
            # 交付/生产默认 is_simulate()=True 且无该 flag → 直接 403，杜绝任何人免费解锁。
            if shub.is_simulate() and not os.environ.get("AIPC_DEV_SIMULATE"):
                self._send(403, "模拟收银台已禁用（生产环境请使用真实支付或授权码）", "text/plain; charset=utf-8")
                return
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            oid = (q.get("order_id") or [""])[0]
            order = _load_orders().get(oid, {})
            prod = PRODUCTS.get(order.get("product_id", ""), {})
            name = prod.get("name", "产品")
            price = (order.get("fee_cents", 0) / 100.0)
            self._send(200, _simulate_pay_html(oid, name, price), "text/html; charset=utf-8")
        elif self.path.startswith("/open_report"):
            # 安全返回迁移后重生成的「最新报告」HTML：仅允许 ANALYSIS_PATH 同目录下
            # 固定文件名 report_latest.html，杜绝路径穿越；同源 localhost 新标签打开。
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            fname = (q.get("f") or [""])[0]
            if fname and fname == os.path.basename(fname) and fname == "report_latest.html":
                fpath = os.path.join(os.path.dirname(os.path.abspath(ANALYSIS_PATH)), fname)
                if os.path.exists(fpath):
                    try:
                        with open(fpath, encoding="utf-8") as _fh:
                            self._send(200, _fh.read(), "text/html; charset=utf-8")
                        return
                    except Exception:
                        pass
            self._send(404, "not found", "text/plain")
        elif self.path.startswith("/preflight"):
            # 迁移预检：管理员 + 锁文件的程序（一次性列全，避免用户等了几分钟才失败）
            from urllib.parse import urlparse, parse_qs
            paths = []
            try:
                q = parse_qs(urlparse(self.path).query)
                if "paths" in q:
                    paths = json.loads(q["paths"][0])
            except Exception:
                paths = []
            try:
                _log("preflight start: %d paths", len(paths))
                if not paths:
                    # 前端必须传选择的路径；空列表直接拒绝，避免 fallback 到全部导致误判
                    _log("preflight rejected: empty paths")
                    self._send(400, json.dumps({"is_admin": is_admin(), "blocks": [], "error": "未选择迁移路径"},
                                               ensure_ascii=False), "application/json; charset=utf-8")
                    return
                res = preflight_migrate(paths)
                _log("preflight ok: admin=%s blocks=%d", res.get("is_admin"), len(res.get("blocks", [])))
                self._send(200, json.dumps(res, ensure_ascii=False),
                           "application/json; charset=utf-8")
            except Exception as e:
                _log("preflight error: %s", e)
                self._send(500, json.dumps({"is_admin": is_admin(), "blocks": [], "error": str(e)},
                                           ensure_ascii=False), "application/json; charset=utf-8")
        else:
            self._send(404, "not found", "text/plain")

    def do_POST(self):
        from urllib.parse import urlparse, parse_qs
        # ---- 创建支付订单（价格↔授权码映射的唯一入口） ----
        if self.path == "/create_order":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            pid = (req.get("product_id") or "").strip()
            if pid not in PRODUCTS:
                self._send(400, json.dumps({"ok": False, "error": "无效的产品"}))
                return
            prod = PRODUCTS[pid]
            # 价格严格取自后端产品表，绝不信任前端传入金额（防篡改 tier/价格）
            # AIPC-ORDER-REUSE-FIX（v1.7.76）：先看有没有「可复用的未支付订单」，
            # 有就直接把上次的付款码原样返回（秒级出码、零服务端请求）。
            _reuse = _find_reusable_order(pid)
            if _reuse:
                oid = _reuse["order_id"]
                # 刷新 created：/order_status 的 15 秒宽限期按它算，应从「本次用户
                # 发起支付」算起，而不是从订单首次创建算起 —— 否则复用一张旧单会在
                # 查单结果还没反映时就被标成 error。
                _reuse = _patch_order(oid, created=int(time.time())) or _reuse
                _log("复用未支付订单：%s product=%s mode=%s",
                     oid, pid, _reuse.get("mode"))
                _rr = {
                    "ok": True, "order_id": oid,
                    "mode": _reuse.get("mode", ""),
                    "fee_cents": _reuse.get("fee_cents", 0),
                    "product_id": pid, "product_name": prod.get("name", ""),
                    "reused": True,
                }
                if _reuse.get("out_trade_no"):
                    _rr["out_trade_no"] = _reuse["out_trade_no"]
                if _reuse.get("payment_code"):
                    _rr["payment_code"] = _reuse["payment_code"]
                if _reuse.get("code_url"):
                    _rr["code_url"] = _reuse["code_url"]
                    _rr["qr_data_uri"] = _qr_for_text(_reuse["code_url"])
                self._send(200, json.dumps(_rr, ensure_ascii=False))
                return
            oid = uuid.uuid4().hex
            order = {
                "order_id": oid,
                "product_id": pid,
                "fee_cents": int(prod.get("fee_cents", 0)),
                "device_bound": bool(prod.get("device_bound", True)),
                "status": "pending",
                "created": int(time.time()),
                "license_code": "",
                "hwid": _order_hwid(),      # 供 _find_reusable_order 判定归属
            }
            # AIPC-ORDER-LOCK-FIX（v1.7.76）：新建也走加锁写，避免与并发的查单
            # 「读 → 改 → 写」交错时把这张新订单整段覆盖掉（丢单 = 用户付了钱页面不认）。
            _insert_order(order)
            # 云端下单路由：生产包默认开启（config.cloud_pay）。开启时客户端不持
            # 商户私钥也能出真实支付码 → 跳过「配置预览」闸门，直接走云端代下单。
            use_cloud = shub.cloud_order_enabled(force=CFG.get("cloud_pay"))
            # 未走云端、且真实扫码凭证未就绪 → 返回「配置预览」态
            # （便于上架审核看到支付意图；真凭证到位后自动转真支付）。
            if not use_cloud and not shub.x402_enabled() and (CFG.get("channel") or "") != "wechat" and not shub.is_real_configured():
                self._send(200, json.dumps({
                    "ok": True,
                    "mode": "pending_config",
                    "notice": CFG.get(
                    "pay_notice",
                    "支付通道开通中，配置完成后即可在报告页直接扫码解锁。"),
                    "fee_cents": order["fee_cents"],
                    "product_name": prod.get("name", ""),
                }, ensure_ascii=False))
                return
            try:
                # AIPC-HWID-REAL-FIX（v1.7.76）：原先恒传 "*"，让服务端「首次下单
                # 必须带 hwid/user_id，否则 400 IDENTITY_REQUIRED」的身份闸门形同
                # 不存在（非空恒过）。改传真 hwid，服务端可按机器归集订单。
                # 取不到 hwid 时退回 "*" —— 宁可让身份闸门形同虚设，也绝不能让用户
                # 「付不了钱」（收入通道的可用性优先于标识完整）。绑机时机不变：
                # 仍在 /v1/activate 首次激活时完成，与本次下单参数无关。
                _real_hwid = ""
                try:
                    _real_hwid = (license_mod.get_hwid() or "").strip()
                except Exception as _e:
                    _log("取本机 hwid 失败：%s", _e)
                if not _real_hwid:
                    _real_hwid = "*"
                res = shub.create_order(prod, _real_hwid, BASE_URL, oid,
                                        product_id=pid, cloud_order=use_cloud)
            except (NotImplementedError, RuntimeError) as e:
                self._send(501, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
                return
            order["mode"] = res.get("mode", "simulate")
            order["out_trade_no"] = res.get("out_trade_no", "")
            # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁（只写这两个字段）。
            _patch_order(oid, mode=order["mode"], out_trade_no=order["out_trade_no"])
            # AIPC-PRICE-GUARD-FIX（v1.7.76）：服务端 402 会带权威金额 amount。
            # 注意单位差异：服务端给的是**元**的字符串（auth_server 用 "%.2f" 格式化
            # PRODUCT_PRICES/100.0，得到如 "19.90"），本地 fee_cents 是**分**。
            # 客户端此前把 amount 取回却不消费 —— 页面价格只来自本地 config.json，
            # 一旦本地价格被改或与服务端漂移，用户看到的价与实收价不一致却毫无提示。
            # 此处比对：不一致只**记日志 + 在响应里标记**，**绝不阻断支付**
            # （金额以服务端为准，阻断只会让用户付不了钱 = 更严重的事故）。
            _price_mismatch = False
            _srv_amt = res.get("amount")
            if _srv_amt is not None:
                try:
                    _srv_cents = int(round(float(_srv_amt) * 100))
                    if _srv_cents != int(order["fee_cents"]):
                        _price_mismatch = True
                        _log("价格不一致：product=%s 本地=%s分 服务端=%s分（以服务端为准，不阻断支付）",
                             pid, order["fee_cents"], _srv_cents)
                except Exception:
                    pass
            resp = {
                "ok": True, "order_id": oid, "mode": order["mode"],
                "fee_cents": order["fee_cents"], "product_id": pid,
                "product_name": prod.get("name", ""),
                "price_mismatch": _price_mismatch,
            }
            if order["mode"] == "real":
                resp["code_url"] = res.get("code_url", "")
                resp["out_trade_no"] = order["out_trade_no"]
                resp["qr_data_uri"] = _qr_for_text(res.get("code_url", ""))
            elif order["mode"] == "x402":
                # X402：商户 /invoke 返回的 payment_code 交给 weixinpay 插件；
                # 同时返回 code_url 供降级扫码（插件不可用时），前端复用现有支付码展示。
                # v1.7.23（生产审计修复）：把 code_url/payment_code 一并持久化进订单记录，
                # 便于支付后排查「扫码码 ↔ 订单」对应关系（此前只回响应、不落库，查单
                # 对不上时无从追溯用户实际扫的是哪一单）。
                order["code_url"] = res.get("code_url", "")
                order["payment_code"] = res.get("payment_code", "")
                # AIPC-ORDER-LOCK-FIX（v1.7.76）：原子补丁（只写这两个字段）。
                _patch_order(oid, code_url=order["code_url"],
                             payment_code=order["payment_code"],
                             code_created=order.get("created") or int(time.time()))
                resp["payment_code"] = res.get("payment_code")
                resp["code_url"] = res.get("code_url")
                resp["out_trade_no"] = order["out_trade_no"]
                if res.get("code_url"):
                    resp["qr_data_uri"] = _qr_for_text(res.get("code_url", ""))
            else:
                resp["pay_url"] = res.get("pay_url", "")
            self._send(200, json.dumps(resp, ensure_ascii=False))
            return
        # ---- 其他盘深度扫描（SSE 流式，只读，不删不搬，无需授权）----
        elif self.path == "/scan_other_disk":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            import re as _re
            drive = (req.get("drive") or "").strip()
            if not _re.match(r'^[A-Za-z]:[\\/]?$', drive):
                self._send(400, json.dumps({"ok": False, "error": "仅支持整盘扫描，如 D:"}, ensure_ascii=False))
                return
            drive = os.path.normpath(drive)
            _sys = (os.environ.get("SystemDrive", "C:") or "C:")[:1].upper()
            if drive[:1].upper() == _sys:
                self._send(400, json.dumps({"ok": False, "error": "其他盘扫描不支持 C 盘（C 盘请使用主扫描）"}, ensure_ascii=False))
                return
            # 进入 SSE 流模式
            try:
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "close")
                self.send_header("X-Accel-Buffering", "no")
                self.end_headers()
                self.wfile.flush()
                self.close_connection = True
            except Exception:
                self._send(500, json.dumps({"ok": False, "error": "SSE 头发送失败"}, ensure_ascii=False))
                return
            _sse_lock = threading.Lock()
            # ★ 2026-10-09 P0：客户端（webview）不读流时 wfile.write 会永久阻塞并握死锁，
            #   冻结整个任务。设 2 秒写超时；写不动即置失联标记，后续事件全部丢弃，
            #   引擎照常执行，结果由状态接口兜底带回。绝不让 socket 卡死引擎。
            try:
                self.connection.settimeout(2.0)
            except Exception:
                pass
            _sse_gone = [False]
            def _sse(ev):
                if _sse_gone[0]:
                    return
                with _sse_lock:
                    if _sse_gone[0]:
                        return
                    try:
                        self.wfile.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                    except Exception:
                        _sse_gone[0] = True
            try:
                import importlib
                so = importlib.import_module("scan_other")
            except Exception as e:
                _sse({"type": "done", "ok": False, "error": "扫描模块加载失败：" + str(e)})
                try:
                    self.wfile.flush()
                except Exception:
                    pass
                return
            def _on_item(item, cur, total):
                _sse({"type": "item", "path": item["path"], "name": item["name"],
                      "size_kb": item["size_kb"], "size_h": item["size_h"],
                      "kind": item["kind"],
                      "current": cur, "total": total})
            def _on_done(res):
                _sse({"type": "done", "ok": res.get("ok", True), "drive": res.get("drive"),
                      "folders": res.get("folders", []), "large_files": res.get("large_files", []),
                      "total_gb": res.get("total_gb", 0), "disk_used_gb": res.get("disk_used_gb", 0),
                      "scanned_dirs": res.get("scanned_dirs", 0),
                      "error_count": res.get("error_count", 0), "error": res.get("error")})
                try:
                    self.wfile.flush()
                except Exception:
                    pass
            _sse({"type": "start", "drive": drive, "total": 0})
            try:
                so.scan_drive(drive, on_item=_on_item, on_done=_on_done, min_file_kb=51200)
            except Exception as e:
                _sse({"type": "done", "ok": False, "error": "扫描异常：" + str(e)})
                try:
                    self.wfile.flush()
                except Exception:
                    pass
            return
        # ---- 其他盘扫描结果：在资源管理器打开路径（只读打开，不修改任何文件）----
        elif self.path == "/open_path":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            path = (req.get("path") or "").strip()
            if not path or not os.path.exists(path):
                self._send(400, json.dumps({"ok": False, "error": "路径不存在或无效"}, ensure_ascii=False))
                return
            try:
                norm = os.path.abspath(path)
                subprocess.Popen(["explorer", "/select,", norm], creationflags=CREATE_NO_WINDOW)
                self._send(200, json.dumps({"ok": True}))
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": "打开失败：" + str(e)}, ensure_ascii=False))
            return
        # ---- 模拟支付成功（仅本地联调；上线由 SkillHub webhook 触发） ----
        if self.path == "/simulate_paid":
            # 安全闸门：默认 403，仅在 SkillHub 模拟模式且显式开启开发调试时才允许；真实模式绝对禁止。
            if not (shub.is_simulate() and os.environ.get("AIPC_DEV_SIMULATE") == "1"):
                self._send(403, json.dumps({"ok": False, "error": "模拟支付已禁用（生产环境请使用真实支付或授权码）"}, ensure_ascii=False))
                return
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            # 与同文件其他端点一致：校验会话 token（开发模式 AIPC_DEV_SIMULATE=1 下豁免，兼容内置模拟页）
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            oid = (req.get("order_id") or "").strip()
            ok, err = _fulfill_order(oid, paid_amount_cents=None)
            self._send(200, json.dumps({"ok": ok, "error": err or ""}, ensure_ascii=False))
            return
        # ---- SkillHub 支付成功回调（webhook；真实模式验签+幂等） ----
        if self.path == "/pay_callback":
            n = int(self.headers.get("Content-Length", 0))
            try:
                raw = self.rfile.read(n) or b"{}"
                req = json.loads(raw)
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            sig = self.headers.get("X-SkillHub-Signature") or req.get("signature") or ""
            if not shub.is_simulate():
                if not os.environ.get("AIPC_ENABLE_CALLBACK"):
                    # 当前走本地轮询模式（选项A），回调验签未启用；启用 webhook 前返回
                    # 明确的 501 而非让 verify_callback 抛 NotImplementedError 导致 500。
                    self._send(501, json.dumps({"ok": False, "error": "回调验签尚未启用，当前使用本地轮询模式"}, ensure_ascii=False))
                    return
                if not shub.verify_callback(req, sig):
                    self._send(403, json.dumps({"ok": False, "error": "签名校验失败"}))
                    return
            oid = (req.get("order_id") or "").strip()
            paid_cents = req.get("paid_amount_cents")
            ok, err = _fulfill_order(oid, paid_amount_cents=paid_cents)
            self._send(200, json.dumps({"ok": ok, "error": err or ""}, ensure_ascii=False))
            return
        # ---- 授权端点：优先走在线授权台账（一码一机），未配置在线则本地验签 ----
        if self.path == "/activate":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            # 授权也走 token 防护（防止恶意页冒充提交；本页带着 token）
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            code = (req.get("code") or "").strip()
            res = license_mod.activate(code, version=license_mod.LOCAL_VERSION)
            self._send(200, json.dumps({
                "ok": res.get("ok", False),
                "tier": res.get("tier", 0),
                "saved": res.get("saved", False),
                "error": res.get("error", ""),
            }, ensure_ascii=False))
            return

        # ---- v1.7.64（安全合规）：隐私偏好设置 ----
        # 前端隐私面板的两个开关（设备指纹上报 / 自动预下单）调用此端点落盘并即时生效。
        if self.path == "/set_privacy":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            send_hwid = bool(req.get("send_hwid", True))
            auto_preorder = bool(req.get("auto_preorder", True))
            try:
                license_mod.set_hwid_send_enabled(send_hwid)
            except Exception:
                pass
            try:
                import skill_tools as _st
                _st.set_auto_preorder_enabled(auto_preorder)
            except Exception:
                pass
            # 同时持久化到本地隐私配置，重启后保持用户选择。
            try:
                _privacy = {"send_hwid": send_hwid, "auto_preorder": auto_preorder}
                _pp = os.path.join(license_mod.get_data_dir(), "privacy.json")
                os.makedirs(os.path.dirname(_pp), exist_ok=True)
                with open(_pp, "w", encoding="utf-8") as f:
                    json.dump(_privacy, f, ensure_ascii=False)
            except Exception:
                pass
            self._send(200, json.dumps({"ok": True, "send_hwid": send_hwid,
                                        "auto_preorder": auto_preorder}, ensure_ascii=False))
            return

        # ---- v1.7.98 P0：进度标记复位端点 ----
        # 前端「上次操作被刷新了」弹窗点「取消」时调用，把该 mode 的 in_progress 落盘为 false。
        if self.path == "/set_progress":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            _mode = str(req.get("mode") or "").strip()
            if _mode not in ("rm", "migrate", "trash", "open"):
                self._send(400, json.dumps({"ok": False, "error": "mode 不合法"}))
                return
            try:
                _set_clean_state_progress(_mode, bool(req.get("in_progress", False)))
                self._send(200, json.dumps({"ok": True, "mode": _mode,
                                            "in_progress": bool(req.get("in_progress", False))},
                                           ensure_ascii=False))
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
            return

        # ---- 杀进程端点（白名单制，仅用于迁移前释放后台占用） ----
        if self.path == "/kill_processes":
            # DNS-rebinding guard: 只接受回环来源（127.0.0.1 / localhost / ::1）AIPC-PAY-RECOVER-FIX
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            # procs 必须是白名单内进程名，后端二次校验，前端传什么都杀不了未知进程
            res = _kill_whitelisted_procs(req.get("procs") or [])
            self._send(200, json.dumps({"ok": True, **res}, ensure_ascii=False))
            return

        # ---- 重启电脑（迁移被杀软内核锁时，用户确认后由系统开机早期完成迁移） ----
        if self.path == "/restart_computer":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            if not is_admin():
                self._send(200, json.dumps({"ok": False, "need_admin": True}, ensure_ascii=False))
                return
            try:
                # 立即重启；前端已二次确认。/f 强制关闭挂起程序，避免重启被未保存窗口卡住。
                subprocess.Popen(["shutdown", "/r", "/t", "0", "/f"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 shell=False, creationflags=CREATE_NO_WINDOW)
                self._send(200, json.dumps({"ok": True}, ensure_ascii=False))
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
            return

        # ---- 可选重启迁移（结果页「安排重启释放」按钮：点击后才复制+安排 reboot_commit，不预先写系统待办） ----
        if self.path == "/schedule_reboot_migrate":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            # v1.7.64（安全合规）：调用 Restart Manager 等敏感系统 API 必须经用户于前端
            # 明确勾选「已知悉并同意」后，前端才携带 consent_system=true 调用。
            # 未携带或为非真值，一律拒绝，绝不静默执行。（v1.7.82 起已无开机任务可安排，
            # 本同意开关仅门控 Restart Manager 强制释放占用。）
            if not req.get("consent_system"):
                self._send(200, json.dumps({
                    "ok": False,
                    "need_consent": True,
                    "error": "未获得用户明确同意，拒绝执行迁移",
                }, ensure_ascii=False))
                return
            # 将用户同意状态同步给 migrate 模块（双重保险：模块级开关 + 此处请求级校验）。
            try:
                migrate_mod.set_system_tasks_allowed(True)
            except Exception:
                pass
            if not is_admin():
                self._send(200, json.dumps({"ok": False, "need_admin": True}, ensure_ascii=False))
                return
            paths = req.get("paths") or []
            plan = DATA.get("migration", {}).get("plan") or []
            _want = set(expand_nojunction(x) for x in paths)
            _td = req.get("target_drive")
            _orig_td = (DATA.get("migration", {}).get("target_drive") or "")
            if _td and _td.lower().rstrip("\\") != _orig_td.lower().rstrip("\\"):
                items = []
                for pp in plan:
                    if expand_nojunction(pp.get("src", "")) in _want:
                        _n = dict(pp)
                        _n["dst"] = migrate_mod.compute_dst(pp["src"], pp.get("mode", "junction"), _td)
                        items.append(_n)
            else:
                items = [pp for pp in plan if expand_nojunction(pp.get("src", "")) in _want]
            if not items:
                self._send(200, json.dumps({"ok": False, "error": "未匹配到迁移项"}, ensure_ascii=False))
                return
            try:
                _mw = getattr(migrate_mod, "MIGRATE_MAX_WORKERS", 3)
                mres = migrate_mod.do_migrate(items, dry_run=False, max_workers=_mw,
                                              release_locks=_quick_kill_for)
                # D：安排重启迁移后，立即把带 reboot_commit 标记的 records 落盘，
                # 让报告在重启前就能明确展示「已安排重启迁移 X 项」，根治「微信突然没了」的恐慌。
                try:
                    _save_clean_state("migrate",
                                      [r.get("src") for r in mres.get("done", [])],
                                      [r.get("src") for r in mres.get("failed", [])],
                                      {}, 0, 0.0,
                                      mres.get("done", []) + mres.get("failed", []))
                except Exception:
                    pass
                self._send(200, json.dumps({
                    "ok": True,
                    "reboot_commit": any((r.get("reboot_commit") for r in
                                          mres.get("done", []) + mres.get("failed", []))),
                    "done": [r.get("src") for r in mres.get("done", [])],
                    "failed": [r.get("src") for r in mres.get("failed", [])],
                }, ensure_ascii=False))
            except Exception as e:
                self._send(500, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
            return

        # ---- v1.7.82：清理旧版本（v1.7.81 及之前）遗留的开机迁移任务/落盘脚本 + 关闭 Restart Manager 授权 ----
        # v1.7.82 起本工具绝不再创建任何任务，本端点只做【清理】：删除旧版本落盘的
        # _reboot_commit_*.py 脚本并撤销对应任务（对不存在的任务 /delete 无副作用），
        # 升级用户的环境由此彻底告别本工具的开机/登录任务。
        if self.path == "/cancel_reboot_tasks":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                req = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            # 撤销同意开关（防止后续静默调度）。
            try:
                migrate_mod.set_system_tasks_allowed(False)
            except Exception:
                pass
            removed = 0
            failed = []
            try:
                # 扫描 scripts 目录下所有已落盘的 _reboot_commit_*.py，逐一撤销对应任务并删脚本。
                import glob as _glob
                _here = os.path.dirname(os.path.abspath(__file__))
                for _sc in _glob.glob(os.path.join(_here, "_reboot_commit_*.py")):
                    _tn = "AIPC_Commit_" + os.path.basename(_sc)[len("_reboot_commit_"):-3]
                    try:
                        if getattr(migrate_mod, "delete_reboot_task", None):
                            migrate_mod.delete_reboot_task(_tn)
                        else:
                            subprocess.run(["schtasks", "/delete", "/tn", _tn, "/f"],
                                           capture_output=True, text=True, encoding="utf-8",
                                           errors="ignore", timeout=20,
                                           creationflags=CREATE_NO_WINDOW)
                        removed += 1
                    except Exception as _e:
                        failed.append(str(_e))
            except Exception as _e:
                self._send(500, json.dumps({"ok": False, "error": str(_e)}, ensure_ascii=False))
                return
            self._send(200, json.dumps({
                "ok": True,
                "removed": removed,
                "failed": failed,
            }, ensure_ascii=False))
            return

        # ---- E：清理迁移残留（.migrated.bak 冗余副本，仅删确认完整的）----
        if self.path == "/clean_bak_residuals":
            if not _host_ok(self.headers.get("Host")):
                self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
                return
            n = int(self.headers.get("Content-Length", 0))
            try:
                # v1.7.85：/action 的 clean_resid 会把已解析的 req 预置进来（见上），
                # 此时 rfile 已被读空，再读只会拿到 b""。所以优先用预置的。
                req = getattr(self, "_pre_parsed_req", None)
                if req is None:
                    req = json.loads(self.rfile.read(n) or b"{}")
                else:
                    self._pre_parsed_req = None
            except Exception:
                self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
                return
            if req.get("token") != TOKEN:
                self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
                return
            # v1.7.85（老李 2026-10-04 实测「未知操作」bug 第二道坎）：
            # 原来这里有 `if not is_admin(): return need_admin` 硬拦截，是错的。
            # 下面真正干活的 recycle_bin_fast_purge 全程只用 MoveFileExW（同卷 rename，
            # 元数据操作）+ SHEmptyRecycleBinW，两者都只要求「对用户自己 profile 目录有删除
            # 权限」—— 而 .migrated.bak 恰恰全在 C:\Users\<用户>\AppData\Local\ 下，
            # 用户天然有完全控制权。实测非管理员也能 0.7 秒删掉一个残留。
            # 真正需要管理员的只有 MoveFileExW(DELAY_UNTIL_REBOOT)（要写 HKLM 注册表），
            # 那是在 _schedule_reboot_delete_batch 里，与本端点无关。
            # 老李这台机器就不是管理员 —— 这个拦截等于把「零丢失迁移的最后一步」直接堵死。
            mode = req.get("mode", "scan")
            residuals = _scan_bak_residuals()
            if mode != "execute":
                self._send(200, json.dumps({"ok": True, "mode": "scan", "items": residuals}, ensure_ascii=False))
                return
            # execute：v1.7.48（一键删除 · 回收站秒级物理释放）——不再按 safe_to_delete 过滤。
            # 产品铁律（老李拍板）：用户是小白，工具必须替用户做选择、点击就删。
            # 所有 *.migrated.bak 残留（无论 junction 是否完好）一律删除。
            #
            # v1.7.46/47 教训（用户明确要求「1.5GB 20 秒内解决」）：
            #   - v1.7.46：串行 fast_purge，9 个大目录串起来几分钟 → 卡死
            #   - v1.7.47：并发 fast_purge，但 fast_purge 对大目录（≥200MB）是「改名到暂存区 +
            #               后台线程逐文件 DeleteFileW」，物理释放要等后台慢慢删，1.5GB 仍可能
            #               超过 20 秒。
            #   - v1.7.48：改用 recycle_bin_fast_purge（黄金组合）——MoveFileExW 把目录整体
            #               rename 进回收站（0.003s/个，元数据操作，杀软/沙箱都不拦），物理释放
            #               由回收站清空批量完成（官方 API 比逐文件 DeleteFileW 快 10-30 倍，
            #               3 万小文件 + 1.5GB 实测 12.7s）。empty_full_bin=False 只删自己搬进
            #               的 $R 条目，不碰用户回收站。rename 秒级返回 → 端到端 20 秒内。
            _total = len(residuals)
            # 进入 SSE 流模式（与 /action 一致）
            try:
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "close")
                self.send_header("X-Accel-Buffering", "no")
                self.end_headers()
                self.wfile.flush()
                self.close_connection = True
            except Exception:
                self._send(500, json.dumps({"ok": False, "error": "SSE headers 发送失败"}, ensure_ascii=False))
                return

            _sse_lock = threading.Lock()
            # ★ 2026-10-09 P0：客户端（webview）不读流时 wfile.write 会永久阻塞并握死锁，
            #   冻结整个任务。设 2 秒写超时；写不动即置失联标记，后续事件全部丢弃，
            #   引擎照常执行，结果由状态接口兜底带回。绝不让 socket 卡死引擎。
            try:
                self.connection.settimeout(2.0)
            except Exception:
                pass
            _sse_gone = [False]
            def _sse(ev):
                if _sse_gone[0]:
                    return
                with _sse_lock:
                    if _sse_gone[0]:
                        return
                    try:
                        self.wfile.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                    except Exception:
                        _sse_gone[0] = True

            # 起步事件：告诉前端总数 + 名义进度 0%
            _sse({"type": "start", "mode": "clean_resid", "total": _total})

            # ① 批量回收站删除（黄金组合：rename 秒级 + $I + 后台精确清 $R）
            # recycle_bin_fast_purge(paths, empty_full_bin=False)：
            #   - 对每个残留目录整体 MoveFileExW rename 进 $Recycle.Bin\<SID>\$R<rand>（0.003s）
            #   - 写标准 $I<rand> 元数据（0.9ms）→ 回收站可正确识别
            #   - 返回 (ok_count, failed_paths)
            #   - 物理释放（清 $R）由该函数内部后台线程做；rename 秒级返回，不阻塞 SSE
            all_bak = [it.get("bak", "") for it in residuals if it.get("bak")]
            _ok_n, _fail_paths = 0, []

            # v1.7.49（P0 修复·硬超时）：recycle_bin_fast_purge 对「broken junction / 被锁目录」
            # 会掉进单线程逐文件回退，数万文件可耗时数分钟；且一旦抛异常旧逻辑还触发 5×0.5s
            # 重试的慢回退。这里用后台线程 + 60s 硬超时兜底，绝不允许对话框卡 10 分钟。
            _purge_res = {}
            _purge_ev = threading.Event()
            def _purge_worker():
                try:
                    _purge_res["ok"], _purge_res["fail"] = migrate_mod.recycle_bin_fast_purge(
                        all_bak, empty_full_bin=False)
                except Exception as _e:
                    _purge_res["exc"] = str(_e)
                finally:
                    _purge_ev.set()
            _pw = threading.Thread(target=_purge_worker, daemon=True)
            _pw.start()
            _purge_ev.wait(timeout=60)

            if not _purge_ev.is_set():
                # 60s 仍未返回：物理删除由其内部 _bg_precise 后台线程继续，不阻塞用户。
                _sse({"type": "warn", "mode": "clean_resid",
                      "msg": "清理量较大，正在后台加速处理，请稍后刷新查看结果"})
                _sse({
                    "type": "done", "ok": True, "mode": "execute",
                    "deleted": [], "failed": [], "all_deleted": 0, "all_failed": 0,
                    "timeout": True, "method": "recycle_bin_async",
                })
                try:
                    self.wfile.flush()
                except Exception:
                    pass
                return

            if "exc" in _purge_res:
                # 极端降级（并行、限时、最多 2 次重试）：每个残留整体 fast_purge，物理释放
                # 交给内部后台线程；不再用 5×0.5s 串行重试（旧逻辑 10 分钟卡死的元凶之一）。
                _fallback_reason = _purge_res.get("exc")
                deleted, failed = [], []
                _done_count = [0]
                def _do_delete(bak):
                    last_err = ""
                    for _ in range(2):
                        try:
                            migrate_mod.fast_purge(bak)
                            return bak, None
                        except Exception as ex2:
                            last_err = str(ex2)
                    return bak, last_err or "未知错误"
                _cw = min(16, max(8, (os.cpu_count() or 4) * 2))
                with concurrent.futures.ThreadPoolExecutor(max_workers=_cw) as _ex:
                    _futs = {_ex.submit(_do_delete, it.get("bak", "")): it for it in residuals}
                    for _fu in concurrent.futures.as_completed(_futs):
                        bak, err = _fu.result()
                        _done_count[0] += 1
                        if err:
                            failed.append({"bak": bak, "error": err})
                        else:
                            deleted.append(bak)
                        _sse({"type": "item", "path": bak,
                              "status": "fail" if err else "done",
                              "reason": err, "current": _done_count[0], "total": _total})
                _sse({
                    "type": "done", "ok": True, "mode": "execute",
                    "deleted": deleted, "failed": failed,
                    "all_deleted": len(deleted), "all_failed": len(failed),
                    "fallback": True, "fallback_reason": _fallback_reason,
                })
                try:
                    self.wfile.flush()
                except Exception:
                    pass
                return

            # ② 回收站路径成功（黄金组合主路径）：rename 全部秒级返回
            _ok_set = set(all_bak) - set(_purge_res.get("fail", []))
            deleted = [b for b in all_bak if b in _ok_set]
            failed = [{"bak": b, "error": "回收站删除失败"} for b in _purge_res.get("fail", [])]
            _done_count = len(deleted) + len(failed)
            # 逐个推 item（rename 已完成，进度快速到位）
            for i, b in enumerate(deleted):
                _sse({"type": "item", "path": b, "status": "done",
                      "current": i + 1, "total": _total})
            for b in failed:
                _sse({"type": "item", "path": b.get("bak"), "status": "fail",
                      "reason": b.get("error"), "current": _total, "total": _total})

            # 全部完成：推 done 事件并关闭
            _sse({
                "type": "done", "ok": True, "mode": "execute",
                "deleted": deleted, "failed": failed,
                "all_deleted": len(deleted), "all_failed": len(failed),
                "method": "recycle_bin",
            })
            try:
                self.wfile.flush()
            except Exception:
                pass
            return

        # ---- 清理端点 ----
        if self.path != "/action":
            self._send(404, json.dumps({"ok": False, "error": "not found"}))
            return
        # DNS-rebinding guard: 只接受回环来源（127.0.0.1 / localhost / ::1）AIPC-PAY-RECOVER-FIX
        if not _host_ok(self.headers.get("Host")):
            self._send(403, json.dumps({"ok": False, "error": "host 不被允许"}))
            return
        n = int(self.headers.get("Content-Length", 0))
        try:
            req = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            self._send(400, json.dumps({"ok": False, "error": "请求格式错误"}))
            return
        if req.get("token") != TOKEN:
            self._send(403, json.dumps({"ok": False, "error": "token 校验失败"}))
            return
        mode = req.get("mode")
        # ===== v1.7.85（老李 2026-10-04 实测「清理迁移残留 → 未知操作」根因修复）=====
        # 症状：点「清理迁移残留」→ 弹「未知操作」→ 点确定后进度条又显示"正在清理残留"。
        # 根因：前端 v1.7.47 改成复用 postAction（POST /action, mode="clean_resid"），
        #       但后端 clean_resid 的真实现一直只挂在**另一个端点** /clean_bak_residuals 上，
        #       /action 的 mode 白名单里压根没有 clean_resid → 走到 400「未知操作」。
        #       也就是说这个按钮从 v1.7.47 起就没通过，老李是第一个真点到的人。
        # 修法（零逻辑复制）：识别 clean_resid → 把已解析的 req 转成 /clean_bak_residuals
        #       的 execute 形态重新走一遍，复用同一份删除实现。
        #       刻意【不】把 recycle_bin_fast_purge 复制到 /action 分支：
        #       两份删除代码将来必然漂移（v1.7.46→48 已经漂了一轮）。
        # ===== v1.7.95（老李实测「D 盘 33.5GB 迁移垃圾永远清不掉」）=====
        # 报告页必须能显示「目标盘上还压着 X GB 历史副本」，并且给个按钮真能清掉。
        # 判据在 migrate._aside_safety（死数据四证），这里是它的用户可见落点。
        if mode == "clean_aside":
            try:
                from migrate import auto_cleanup_stale_asides as _clean_aside
            except Exception:
                self._send(500, json.dumps({"ok": False, "error": "清理模块加载失败"},
                                           ensure_ascii=False))
                return
            try:
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "close")
                self.send_header("X-Accel-Buffering", "no")
                self.end_headers()
                self.wfile.flush()
                self.close_connection = True
            except Exception:
                self._send(500, json.dumps({"ok": False, "error": "SSE headers 发送失败"},
                                           ensure_ascii=False))
                return
            _sse_lock = threading.Lock()
            # ★ 2026-10-09 P0：同上 —— 写超时 + 失联弃写，绝不让 socket 卡死引擎。
            try:
                self.connection.settimeout(2.0)
            except Exception:
                pass
            _sse_gone = [False]

            def _sse_a(ev):
                if _sse_gone[0]:
                    return
                with _sse_lock:
                    if _sse_gone[0]:
                        return
                    try:
                        self.wfile.write(("data: " + json.dumps(ev, ensure_ascii=False)
                                          + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                    except Exception:
                        _sse_gone[0] = True

            # _ASIDE_SSE_HEARTBEAT_V1796
            # ★ v1.7.96：心跳线程。清理在真实数据上要跑几十分钟，
            #   中间一条消息都不发 = 用户以为卡死了（2026-10-07 报告页实操实测）。
            #   这里每 10 秒发一次【磁盘上真实测到的】已释放量，不是假进度。
            _hb_stop = {"v": False}

            def _hb_sampler(_drive, _base_free):
                _t0 = _time.time()
                _peak = 0.0
                while not _hb_stop["v"]:
                    try:
                        _now = _disk_free_bytes(_drive)
                        if _now is not None and _base_free is not None:
                            _gb = (_now - _base_free) / float(1 << 30)
                            if _gb > _peak:
                                _peak = _gb
                        _sse_a({"type": "progress", "mode": "clean_aside",
                                "elapsed": int(_time.time() - _t0),
                                "freed_gb": round(_peak, 2)})
                    except Exception:
                        pass
                    for _i in range(100):        # 10 秒，可被打断
                        if _hb_stop["v"]:
                            break
                        _time.sleep(0.1)

            try:
                _dry = _clean_aside(dry_run=True)
                _sse_a({"type": "start", "mode": "clean_aside",
                        "total": int(_dry.get("items") or 0),
                        "total_gb": round(float(_dry.get("freed_gb") or 0.0), 2)})
                # 目标盘取第一份垃圾所在盘，用来实测释放量
                _hb_drive = ""
                try:
                    for _z in (_dry.get("details") or []):
                        _pp = _z.get("path") or ""
                        if _pp:
                            _hb_drive = os.path.splitdrive(_pp)[0]
                            break
                except Exception:
                    _hb_drive = ""
                _hb_base = _disk_free_bytes(_hb_drive) if _hb_drive else None
                _hb_th = None
                if _hb_drive:
                    _hb_th = threading.Thread(target=_hb_sampler,
                                              args=(_hb_drive, _hb_base),
                                              daemon=True)
                    _hb_th.start()
                try:
                    _res = _clean_aside()
                finally:
                    _hb_stop["v"] = True
                _d = (_res.get("details") or [])
                # ★ 拿不到单飞锁 = 上一轮还在跑。这不是失败，要如实说「已经在清了」。
                if _res.get("busy"):
                    _sse_a({"type": "done", "mode": "clean_aside", "ok": True,
                            "busy": True, "deleted": [], "failed": [],
                            "freed_gb": 0.0,
                            "error": _res.get("error") or "上一轮清理还在进行中"})
                else:
                    _sse_a({"type": "done", "mode": "clean_aside", "ok": True,
                            "deleted": [x for x in _d if x.get("action") == "cleaned"],
                            "failed": [x for x in _d if x.get("action") != "cleaned"],
                            "freed_gb": float(_res.get("freed_gb") or 0.0)})
                _sse_a({"type": "end", "mode": "clean_aside"})
            except Exception as _ce:
                _hb_stop["v"] = True
                _sse_a({"type": "done", "mode": "clean_aside", "ok": False,
                        "error": repr(_ce)[:200], "deleted": [], "failed": []})
            return
        if mode == "clean_resid":
            req = dict(req)
            req["mode"] = "execute"
            self._pre_parsed_req = req          # 让 /clean_bak_residuals 分支复用已解析的 body
            self.path = "/clean_bak_residuals"
            return self.do_POST()
        allow = {"rm": RM_ALLOW, "trash": TRASH_ALLOW, "open": OPEN_ALLOW,
                  "migrate": MIGRATE_ALLOW}.get(mode)
        if allow is None:
            self._send(400, json.dumps({"ok": False, "error": "未知操作"}))
            return
        # ===== 等级门控：未达 minTier 直接拒绝（核心权限验证） =====
        allowed, cur_tier, why = license_mod.mode_allowed(mode)
        if not allowed:
            # need_tier 由 feature 映射回等级，便于前端弹授权引导
            feat = license_mod.MODE_FEATURE.get(mode)
            need = license_mod.FEATURE_MIN_TIER.get(feat, 1)
            self._send(403, json.dumps({
                "ok": False, "locked": True, "need_tier": need,
                "error": why or "需要授权码",
            }, ensure_ascii=False))
            return
        paths = req.get("paths") or []
        if not paths:  # P2-7：空路径列表防护，避免下方 NameError
            self._send(400, json.dumps({"ok": False, "error": "空路径列表"}))
            return

        # 真实释放量基线：在任一删除/迁移发生前，测一次目标盘可用空间。
        # 目标盘取首个路径所在盘符（清理/迁移的 src 均在该盘）。
        _free_drive = os.path.splitdrive(paths[0])[0] or "C:"
        _free_before = _disk_free_bytes(_free_drive)
        _real_done_srcs = []  # 迁移成功项 src（用于报告刷新）
        # AIPC-FREED-PEAK-FIX：从「删除动作发生之前」就每 5 秒记一次目标盘可用空间，
        # 一直记到校准结账，最后取整条轨迹的【峰值】增量作为实测释放量。
        # 为什么必须这样：物理删除是单调释放，但同一段时间里浏览器/微信/系统更新也在
        # 往这块盘里写。旧实现只在「等物理删完」之后才开始采样（4 次 x 15 秒），采到的
        # 是【已被并发写入抵消之后的余量】—— 真机把「删掉约 3.4GB」测成 27MB
        # （落盘 0.03GB，用户眼前就是"清了跟没清一样"）。峰值才代表删除真正腾出来过多少。
        _free_trace = []
        # AIPC-FREED-PEAK-FIX（并发安全）：停止信号用【本请求独有】令牌，不用全局布尔。
        # 连点两次清理时，全局布尔会让第一次结账掐掉第二次的采样线程。
        _free_rid = id(_free_trace)
        try:
            if _free_before is not None:
                _free_trace.append(int(_free_before))

                def _free_sampler():
                    _t_0 = time.time()
                    while (time.time() - _t_0) < 1800.0:
                        if _FREE_SAMPLE.get("stop") == _free_rid:
                            return
                        try:
                            _v = _disk_free_bytes(_free_drive)
                            if _v is not None:
                                _free_trace.append(int(_v))
                        except Exception:
                            pass
                        time.sleep(5.0)

                _th_s = threading.Thread(target=_free_sampler, daemon=True)
                _th_s.start()
        except Exception:
            pass

        # 清理项的扫描体积映射：用于「秒级返回真实释放量」，不再等后台 rd 完成。
        # 修复（v1.7.8）：原实现只把绿区条目 path(=trash_paths[0]) 当 key，而前端逐条发
        # 的是所有 trash_paths 子路径 → 除 paths[0] 外命中率 0，释放量系统性失准
        # （勾选子集被低估、只勾 paths[0] 被高估）。改为按「绿区条目 × 其全部 trash_paths」
        # 聚合：选了条目中几个子路径就按占比归因其 kb，再减去真实残留体积。
        _item_size_kb = {}
        _green_attr = []  # [(set_of_norm_trash_paths, kb)]
        # AIPC-FREED-DEDUP-FIX：路径 → 条目序号 反查表。
        # 为什么必须有：同一个条目的体积被复制给了它每一条 trash_path（下面 for 循环），
        # 而累加时必须【按条目去重】——否则「8.0GB 的条目有 33 条路径」会被数成 264GB。
        _item_idx_of = {}
        _residual_map = {}
        if mode == "rm":
            for _g in (DATA.get("green") or []):
                _kb = float(_g.get("kb", 0) or 0)
                _tps = [os.path.normcase(os.path.abspath(x)) for x in (_g.get("trash_paths") or [])]
                if not _tps and _g.get("path"):
                    _tps = [os.path.normcase(os.path.abspath(_g["path"]))]
                if _tps:
                    _green_attr.append((set(_tps), _kb))
                    for _tp in _tps:
                        _item_size_kb[_tp] = _kb  # 兼容旧逻辑（单路径条目同值）

        # 标记进行中，刷新页面后可恢复或提示继续
        _set_clean_state_progress(mode, True)

        # ===== SSE 流式进度：边删边回报，前端实时渲染进度条 =====
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        # 关键修复：每条 /action 是一次性的 SSE 事件流，发完 done 后必须关闭连接，
        # 否则 BaseHTTPRequestHandler 在 keep-alive 下会等待下一个请求、永不 EOF，
        # 导致前端 fetch 的 Promise 永不 resolve → 按钮转圈/无响应/卡死。
        self.send_header("Connection", "close")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.wfile.flush()
        self.close_connection = True  # 强制 handler 返回后即关闭连接

        _sse_lock = threading.Lock()  # 并行清理时多线程并发写 SSE，必须加锁防乱序/损坏
        # ★ 2026-10-09 P0：侧边栏 webview 不读 SSE 流 → socket 发送缓冲填满 →
        #   wfile.write 永久阻塞且握着 _sse_lock，12 个并行删除线程全部排队冻死
        #   （实测零CPU/零完成/零日志，一键清永远 0/47；系统浏览器有人读流所以从不复现）。
        #   修法：连接设 2 秒写超时；写不动 = 客户端不读，置 _sse_gone 丢弃后续事件，
        #   引擎照常跑完，真实结果落 clean_state，由前端兜底轮询带回。绝不让 socket 卡死引擎。
        try:
            self.connection.settimeout(2.0)
        except Exception:
            pass
        _sse_gone = [False]
        def sse(event):
            if _sse_gone[0]:
                return
            with _sse_lock:
                if _sse_gone[0]:
                    return
                try:
                    self.wfile.write(("data: " + json.dumps(event, ensure_ascii=False) + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                except Exception:
                    _sse_gone[0] = True

        total = len(paths)
        done = []
        failed = []
        failed_reasons = {}
        last_error = ""
        need_admin = False
        mig_records = []  # migrate 模式下汇总每条迁移记录的 src/dst/kb/ok/msg
        migrate_items = []  # 方案B：先收集所有通过护栏的迁移项，循环后一次性并行执行
        clean_items = []    # 一键清：先收集所有通过护栏的清理项，循环后一次性并行删除（提速核心）
        deferred = []  # 产品哲学转向：av_kernel（杀软内核锁）项自动跳过，结果页「可选重启释放」
        reboot_registered_total = 0  # Q1：累计一键清删不掉、已登记重启自动删的文件数
        reboot_pending_count = 0     # v1.7.21：本次清理中「已安排重启后自动清理」的文件代表数

        sse({"type": "start", "mode": mode, "total": total})

        # 【codex 副本 v1.7.29-candidate 修正】迁移管理员判定下移到逐项：
        # 管理员仅「建 junction」必需；mode=move 的大文件迁移是纯「复制-校验-删源」，
        # 非管理员照常执行（目标用户多为电脑小白、常非管理员，之前整批拦截把 move 也挡住）。
        # junction 项仍逐条提示需要管理员，不静默回滚。

        for idx, p in enumerate(paths, 1):
            # 回收站标记：放在 expand 之前判定——expand 用 realpath 会把标记解析成带 cwd 的
            # 绝对路径（如 C:\...\scripts\__EMPTY_RECYCLE_BIN__），导致字面比对永远失败。
            # 故此处用原始请求 p 直接比对，命中即跳过白名单/越界检查，直接调 Windows API 清空。
            if p == _EMPTY_RECYCLE_BIN_MARKER:
                # 清空回收站在 360 实时防护下可能耗时（逐文件扫描），改为后台线程执行，
                # 请求立即返回，彻底杜绝「清理无响应」。用户已二次确认，故乐观标记完成。
                def _do_empty_rb():
                    try:
                        empty_recycle_bin()
                    except Exception as e:
                        _log("empty_recycle_bin bg error: %s", e)
                _rb_thread = threading.Thread(target=_do_empty_rb, daemon=True)
                _rb_thread.start()
                _BG_THREADS.append(_rb_thread)
                done.append(p)
                sse({"type": "item", "path": p, "status": "done"})
                continue
            # 迁移模式用 expand_nojunction（不跟随 junction），避免已迁文件夹被
            # realpath 解析到目标盘而误判越界；rm/trash/open 仍用安全 realpath。
            rp = expand_nojunction(p) if mode == "migrate" else expand(p)
            if mode != "migrate":
                # 迁移改为循环后统一并行执行；此处不逐条发 progress（避免提前显示完成）
                sse({"type": "progress", "current": idx, "total": total, "path": p, "status": "deleting"})
            if rp not in allow:
                failed.append(p)
                failed_reasons[p] = "不在清理白名单"
                sse({"type": "item", "path": p, "status": "skip", "reason": failed_reasons[p]})
                continue

            # 二级护栏：只允许用户目录 / 应用安装目录 / 系统缓存目录。
            # rm/trash 不再仅限制 HOME，否则 analyze.py 标绿的 Windows Temp/Prefetch
            # 等系统缓存会被误拦截，导致"系统目录不在清理范围"。
            if sys.platform == "darwin":
                roots = (HOME, "/Applications")
            else:
                _roots = [
                    HOME,
                    os.environ.get("ProgramFiles", ""),
                    os.environ.get("ProgramFiles(x86)", ""),
                    os.environ.get("ProgramData", ""),
                    os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "Temp"),
                    os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "Prefetch"),
                ]
                roots = tuple(r for r in _roots if r)

            def _is_safe_system_cache(p):
                plo = p.lower().replace("/", "\\")
                # 原有快捷判定兜底（路径片段级）
                if (
                    "\\temp\\" in plo or plo.endswith("\\temp")
                    or "\\prefetch\\" in plo or plo.endswith("\\prefetch")
                    or "\\softwaredistribution\\download" in plo
                    or "\\windows\\logs" in plo
                    or "\\inetcache\\" in plo
                ):
                    return True
                # 与 analyze 标绿同源（v1.7.17 修复）：analyze 用 path_rules.SYSTEM_CACHE_MARKS
                # 判定系统级安全缓存（含 NativeImages / DeliveryOptimization / Search 索引 /
                # thumbcache / WER 等），server 若只用上方 5 类片段会把这些已标绿路径误判为
                # 「越界」而拒绝清理 → 绿区显示可清、实际点一键清报错。这里复用同一套白名单，
                # 保证「标绿 = 可清」。classify_path=='safe' 同理（ITSKHD\Update 等非系统但
                # 段名命中缓存的路径，analyze 已按四道关标绿，server 必须放行）。
                try:
                    import path_rules as _pr
                    if _pr.is_system_cache(p):
                        return True
                    _safety, _ = _pr.classify_path(p)
                    if _safety == "safe":
                        return True
                except Exception:
                    pass
                return False

            in_roots = any(rp.lower() == base.lower() or rp.lower().startswith(base.lower() + os.sep) for base in roots)
            if not in_roots and not _is_safe_system_cache(rp):
                failed.append(p)
                failed_reasons[p] = "越界（不在用户目录内）"
                sse({"type": "item", "path": p, "status": "skip", "reason": failed_reasons[p]})
                continue
            # --- 错误大白话翻译 ---
            try:
                if mode == "open":
                    open_in_file_manager(rp)
                elif not os.path.exists(rp):
                    pass  # already gone, treat as success
                elif mode == "trash":
                    move_to_trash(rp)
                elif mode == "migrate":
                    plan = DATA.get("migration", {}).get("plan") or []
                    items = [pp for pp in plan if expand_nojunction(pp.get("src", "")) == rp]
                    if not items:
                        failed.append(p)
                        failed_reasons[p] = "未匹配到迁移项"
                        sse({"type": "item", "path": p, "status": "fail", "reason": failed_reasons[p]})
                        continue
                    # 用户在前端选了非默认目标盘 → 用所选盘重算 dst（避免迁到旧盘路径）
                    _td = req.get("target_drive") or DATA.get("migration", {}).get("target_drive")
                    _orig_td = (DATA.get("migration", {}).get("target_drive") or "")
                    _recompute = bool(_td) and _td.lower().rstrip("\\") != _orig_td.lower().rstrip("\\")
                    # v1.7.33（老李拍板：能迁多少迁多少 + 如实记账）：
                    # 旧实现把 av_kernel（杀软内核锁）项【只塞进内存 deferred，不入 migrate_items、
                    # 不入 failed、不落盘】——结果就是这一项在报告里凭空消失，用户以为全成功。
                    # 现在统一送进 migrate_items：migrate.py 开头会零开销识别内核锁并即时返回
                    # 「本次没动它 + 重启后可搬」的诚实结果，照常进 failed 与记录，落盘可查。
                    for _it in items:
                        _src = _it.get("src", "")
                        if _recompute:
                            _it = dict(_it)
                            _it["dst"] = migrate_mod.compute_dst(_src, _it.get("mode", "junction"), _td)
                        if _it.get("mode") == "move":
                            # 物理搬家：不建 junction，改名锁探测不适用；直接做（锁了执行时优雅失败）
                            migrate_items.extend([_it])
                            continue
                        # junction 项：非管理员逐条明确告知（v1.7.29-candidate，见上方注释）
                        if not is_admin():
                            need_admin = True
                            failed.append(_src)
                            failed_reasons[_src] = "需要管理员权限：请右键 WorkBuddy 选择「以管理员身份运行」后重试"
                            sse({"type": "item", "path": _src, "status": "fail", "reason": failed_reasons[_src]})
                            continue
                        migrate_items.extend([_it])
                    continue
                else:
                    # rm 清理：先收集，循环后【并行删除】（提速核心）。
                    # 删除逻辑/锁探测/重启删除兜底完全不变，只是把「串行逐个删」改「线程池并行删」。
                    clean_items.append((p, rp))
                    continue
                done.append(p)
                sse({"type": "item", "path": p, "status": "done"})
            except Exception as e:
                failed.append(p)
                failed_reasons[p] = _plain_error(e)
                last_error = _plain_error(e)
                sse({"type": "item", "path": p, "status": "fail", "reason": failed_reasons[p]})
                continue
        # ===== 一键清【并行】执行：把循环里串行收集的清理项，用线程池并行删除 =====
        # 提速核心：N 个目录同时删，总时间≈最慢目录时间（不再累加）。
        # 删除逻辑/锁探测/重启删除兜底与串行版完全一致（hard_delete → fast_purge → robocopy）。
        # SSE 已加锁（_sse_lock），多线程并发写安全；done/failed/_residual_map 在主线程
        # as_completed 循环里串行更新，无并发问题。
        # v1.7.36（审查修复·P0）：_golden_planned_kb 必须在 if clean_items 块【外】初始化。
        # 若放在 if clean_items 内，当用户只勾选「清空回收站」而未勾选任何缓存目录
        # （clean_items 为空）时，整个 if clean_items 块被跳过、_golden_planned_kb 永不
        # 赋值，下方 mode=="rm" 分支读取会 UnboundLocalError 崩溃。
        _golden_planned_kb = 0
        _rm_planned_kb = 0.0  # v1.7.54 根因修复：即时标称释放量累计（done 即出，不阻塞后台物理删除）
        # AIPC-FREED-DEDUP-FIX：按条目去重核算所需的两个容器（见下方核算逻辑）
        _done_rps = set()        # 已处理成功的规范路径
        _resid_by_item = {}      # 条目序号 -> 该条目累计真实残留 KB
        if clean_items:
            # ===== v1.7.25 黄金组合：用户勾选「清空回收站」时，缓存目录走批量快删通道 =====
            # 原理（本机实测 2026-08-03）：MoveFileExW rename 缓存目录进回收站 = 0.003s
            # （元数据操作，杀软/沙箱不拦）+ 写标准 $I 元数据（0.9ms）+
            # SHEmptyRecycleBinW 清空回收站（杀软放行的官方批量通道：大文件秒清 11.7GB 实测、
            # 小文件 2-3ms/个，真实机器比 DeleteFileW 被杀软逐文件扫快 10-30 倍）。
            # 触发条件 = 本次清理含回收站标记（用户勾选「清空回收站」默认开）→ 行为自洽：
            # 缓存目录进回收站 + 用户回收站一起清，都符合"清空回收站"的用户预期。
            # 未勾选回收站 → 不进此分支（保护用户回收站），走现有后台逐文件删。
            _wants_recycle = any(x == _EMPTY_RECYCLE_BIN_MARKER for x in paths)
            # v1.7.26：黄金组合计划释放量（rename 全部成功 = 提交的量；done 即时 freed 用
            # 它兜底，避免 SHEmpty 异步后台释放导致弹窗短暂显示低值，校准线程后覆盖实测）
            if _wants_recycle and clean_items:
                # v1.7.27 修复：必须按「条目」去重聚合——_item_size_kb 把条目的全部
                # trash_paths 都映射到整条 kb（如 Temp 12.2GB 有 11 个 trash_paths，
                # 每个都记 12.2GB），若对每个 trash_path 累加会把同一条目重复计入
                # （实测 freed_gb=136.4 假值：12.2×11≈134）。正确口径 = 条目只要
                # 有任一 trash_path 命中即计一次条目 kb。
                _done_norm = {os.path.normcase(os.path.abspath(rp)) for _, rp in clean_items}
                for _tps, _kb in _green_attr:
                    if _tps & _done_norm:
                        _golden_planned_kb += _kb
            if False:  # P0 修复（2026-08-13）：禁用「黄金组合」进回收站分支。
                # 根因：recycle_bin_fast_purge 会把一键清缓存 rename 进回收站 $R，
                # 后台删 daemon 线程被重启中断 → 文件永久留在回收站（老李实测回收站 13GB）。
                # 这违反「一键清彻底删除、不进回收站」铁律。缓存改走下方 hard_delete
                # （fast_purge → aipc_purge 暂存区物理删，不进回收站；重启兜底见修复 1）。
                # v1.7.26（外部团队方案 v2.0 融合）：无论是否勾选回收站，缓存目录都走黄金组合
                #   · 勾选回收站（_wants_recycle=True）→ SHEmptyRecycleBinW 全清（快，行为自洽：
                #     缓存进回收站 + 用户回收站一起清，符合"清空回收站"预期）
                #   · 未勾选（False）→ 精确删除：只后台删自己搬进的 $R，**不碰用户回收站**
                #     （rename 秒级感知 + 后台释放，用户回收站安全）
                _cache_paths = [rp for _, rp in clean_items]
                _okc, _failc = migrate_mod.recycle_bin_fast_purge(
                    _cache_paths, empty_full_bin=_wants_recycle)
                _failset = set(_failc or [])
                _log("golden combo: recycle-bin purge ok=%d fail=%d empty_full=%s",
                     _okc, len(_failset), _wants_recycle)
                for _p, _rp in clean_items:
                    if _rp not in _failset:
                        done.append(_p)
                        sse({"type": "item", "path": _p, "status": "done"})
                # 失败项回退：保留在 clean_items，走下方现有并行 hard_delete（后台逐文件删）
                clean_items = [(p, rp) for p, rp in clean_items if rp in _failset]
            if clean_items:
                try:
                    _cw = max(1, int(CFG.get("clean_parallel") or os.environ.get("AIPC_CLEAN_PARALLEL", "12")))
                except Exception:
                    _cw = 4
            _cn = len(clean_items)
            _clean_done_n = [0]
            _log("parallel clean start: %d items, workers=%d" % (_cn, _cw))

            def _clean_one(p, rp):
                last_ts = [0.0]
                def _sub(dn, tot, skipped_n):
                    now = time.time()
                    if now - last_ts[0] < 0.4 and dn != tot:
                        return
                    last_ts[0] = now
                    sse({"type": "sub_progress", "path": p,
                         "deleted": dn, "total": tot, "skipped": skipped_n,
                         "pct": (round(dn * 100 / tot, 1) if tot else 0)})
                try:
                    # v1.7.24：传条目扫描体积，大目录异步提交（弹窗不被后台删除拖住）
                    _kb = _item_size_kb.get(os.path.normcase(os.path.abspath(rp)), 0)
                    skipped = hard_delete(rp, on_progress=_sub, size_kb=_kb)
                    return (p, rp, skipped or [], "")
                except Exception as e:
                    return (p, rp, None, _plain_error(e))

            # v1.7.97 P0：绝不用 with ThreadPoolExecutor（shutdown(wait=True) 会 join 每个
            # worker，一个死锁就永远出不来）。显式创建 + as_completed 带超时 + shutdown 不等待。
            _ex = ThreadPoolExecutor(max_workers=_cw)
            _futs = [_ex.submit(_clean_one, p, rp) for p, rp in clean_items]
            _fut_item = dict(zip(_futs, clean_items))
            _CLEAN_DEADLINE = max(120, int(os.environ.get("AIPC_CLEAN_DEADLINE", "900")))
            try:
                for _fu in as_completed(_futs, timeout=_CLEAN_DEADLINE):
                    p, rp, skipped, err = _fu.result()
                    _clean_done_n[0] += 1
                    sse({"type": "progress", "current": _clean_done_n[0], "total": _cn,
                         "path": p, "status": "deleting"})
                    if err:
                        failed.append(p)
                        failed_reasons[p] = err
                        last_error = err
                        sse({"type": "item", "path": p, "status": "fail", "reason": err})
                        continue
                    _residual_map[p] = skipped
                    # AIPC-FREED-DEDUP-FIX：本处【不再】取条目体积也不累加 ——
                    # 条目体积的核算已统一挪到末尾「按条目一次性核算」（见 freed_kb 处）。
                    # 这里只负责算这条路径的【真实残留】体积。
                    _resid_kb = 0.0
                    if skipped:
                        for _f in skipped:
                            try:
                                _resid_kb += os.path.getsize(_f) / 1024.0
                            except Exception:
                                pass
                    # AIPC-FREED-DEDUP-FIX：这里【不再】逐路径累加条目体积 ——
                    # 那会把同一个条目的体积按它的路径条数重复计数（真机：8.0GB × 33 = 264GB，
                    # 报告页就显示成「本次释放 258.7GB」，而整块 C 盘才 120GB）。
                    # 改为只登记「这条路径确实处理成功」+ 它的真实残留，最后按条目一次性核算。
                    _done_rps.add(os.path.normcase(os.path.abspath(rp)))
                    _idx_done = _item_idx_of.get(os.path.normcase(os.path.abspath(rp)))
                    if _idx_done is not None and _resid_kb > 0:
                        _resid_by_item[_idx_done] = _resid_by_item.get(_idx_done, 0.0) + _resid_kb

                    if skipped:
                        # v1.7.23（生产审计修复）：残留处理三态如实呈现——
                        #   reg>0  = 已登记重启删（重启后自动释放，明示生效）
                        #   reg==0 = 登记失败（多为非管理员：MoveFileExW 写 HKLM 注册表
                        #            需管理员权限）→ 不再承诺「重启自动删」，如实提示
                        #            需管理员身份，杜绝「显示已安排、重启后却不删」的
                        #            承诺断裂（虚假营销红线）。
                        reg, reg_why = _schedule_reboot_deletes(skipped)
                        reboot_registered_total += reg
                        reason = _classify_skips(skipped)
                        if reg > 0:
                            reason += "（已安排重启后自动清理，重启电脑即生效，本次 %d 个文件）" % reg
                        else:
                            # v1.7.86：如实说清「为什么没登记成功」，并给出可执行的下一步。
                            # 旧文案只说「需管理员权限」，在管理员态下也可能是别的原因
                            # （路径被占/权限不足），笼统说等于让用户猜。
                            reason += "（没能安排自动清理：%s）" % (reg_why or "登记没成功")
                            if "管理员" in (reg_why or ""):
                                need_admin = True
                        done.append(p)
                        # v1.7.86：只有**真登记成功**才标 reboot_pending。
                        # 旧代码无论成功失败都 reboot_pending += len(skipped)，
                        # 于是没登记成功也会在报告里显示「已安排重启后清理 N 项」= 骗用户。
                        if reg > 0:
                            reboot_pending_count += len(skipped)
                        sse({"type": "item", "path": p, "status": "done",
                             "reason": reason, "reboot_pending": reg > 0})
                    else:
                        done.append(p)
                        sse({"type": "item", "path": p, "status": "done"})
            except TimeoutError:
                # 真卡死（某 worker 死锁/坏道）：未完成的项如实标失败，绝不谎报完成。
                _unfin = [f for f in _futs if not f.done()]
                for _fu in _unfin:
                    _up, _urp = _fut_item.get(_fu, (None, None))
                    if _up:
                        failed.append(_up)
                        failed_reasons[_up] = "清理超时未完成（疑似文件被占用或磁盘异常），请稍后重试"
                        last_error = failed_reasons[_up]
                        sse({"type": "item", "path": _up, "status": "fail",
                             "reason": failed_reasons[_up]})
                _log("parallel clean TIMEOUT after %ds, %d items unfinished",
                     _CLEAN_DEADLINE, len(_unfin))
            finally:
                _ex.shutdown(wait=False, cancel_futures=True)

        # ===== 方案B：迁移项【同步】执行 + 真实进度/结果流式回报 =====
        # 关键修正（老李要求）：不再「乐观标记完成 + 后台线程静默搬运」。
        # 改为在请求线程内同步执行 do_migrate，并用 on_progress 把真实进度/每条结果
        # 实时推回前端；完成后用【真实结果】核算释放量。效果：
        #   · 被锁定的项在复制前即由 do_migrate 内 classify_lock 探测并跳过，
        #     绝不会「迁了半天最后全失败」；
        #   · 前端看到真实完成情况，失败项在结果弹窗逐条列出，不再「假完成」。
        if mode == "migrate" and migrate_items:
            # v1.7.9: dedup migration paths — keep only top-level dirs, skip sub-dirs
            # that are already covered by a parent. Prevents robocopy from scanning
            # the same tree multiple times.
            if len(migrate_items) > 1:
                _sorted = sorted(migrate_items, key=lambda it: len(it.get("src", "")))
                _deduped = []
                for it in _sorted:
                    _s = os.path.normcase(os.path.abspath(it.get("src", "")))
                    if not any(_s.startswith(os.path.normcase(os.path.abspath(kept.get("src", ""))) + os.sep)
                               for kept in _deduped):
                        _deduped.append(it)
                if len(_deduped) < len(migrate_items):
                    _log("migrate dedup: %d -> %d items" % (len(migrate_items), len(_deduped)))
                migrate_items = _deduped

            _mw = getattr(migrate_mod, "MIGRATE_MAX_WORKERS", 3)

            def _on_progress(cur, total, src, speed_mb=None, eta_sec=None):
                try:
                    if src:
                        # 单项内子进度：file/MB 计数（仅做内部细化，不影响全局）
                        sse({"type": "sub_progress", "path": src,
                             "deleted": int(cur), "total": int(total),
                             "pct": round(min(99.5, (cur * 100.0 / total) if total else 0.0), 1),
                             "unit": "MB"})
                    else:
                        # 全局进度：用真实 cur/total（MB/MB），让前端算出真实百分比。
                        # 关键修复：原代码传 1/1 让前端渲染成 100%，造成「满了却弹窗不来」的假完成感；
                        # 现在传真实进度，前端 `pct = current/total*100` 自然不会先到 100%。
                        # v1.7.88：附带 speed_mb / eta_sec —— 老李实测「速度非常之慢，
                        # 用户等不急」；只显示已搬多少，用户无法判断是在推进还是卡死，
                        # 补上「按当前速度还要多久」才能让等待变得可预期。
                        sse({"type": "progress",
                             "current": float(cur or 0),
                             "total": float(total or 1),
                             "speed_mb": float(speed_mb or 0),
                             "eta_sec": int(eta_sec or 0),
                             "path": "", "status": "migrating"})
                except Exception:
                    pass

            # v1.7.85：停滞告警直推前端（老李 2026-10-04 实测「迁移卡 4h48m、
            # 页面进度条冻结在 93.4%、日志一行不写」）。
            # 此前 do_migrate 没有任何「我卡住了」的出口，ticker 只管推数字不管报警，
            # 于是真实搬运量停摆时页面毫无察觉 —— 用户只能干等到天荒地老。
            # 现在停滞超 30 秒就推 warn 事件，页面明写「卡在第几步 / 停了多少秒」。
            def _on_warn(ev):
                try:
                    if (ev or {}).get("kind") == "stall":
                        _log("migrate STALL: idle=%ss progress=%.1f/%.1f MB pending=%s",
                             ev.get("idle_sec"), ev.get("progress_mb", 0),
                             ev.get("total_mb", 0), ev.get("pending"))
                    sse({"type": "warn", "mode": "migrate",
                         "kind": (ev or {}).get("kind", "info"),
                         "msg": _mig_warn_text(ev),
                         "idle_sec": (ev or {}).get("idle_sec", 0),
                         "progress_mb": (ev or {}).get("progress_mb", 0),
                         "total_mb": (ev or {}).get("total_mb", 0)})
                except Exception:
                    pass

            try:
                mres = migrate_mod.do_migrate(
                    migrate_items, dry_run=False,
                    on_progress=_on_progress, on_warn=_on_warn,
                    max_workers=_mw, release_locks=_quick_kill_for)
            except Exception as e:
                mres = {"done": [], "failed": [], "total_kb": 0.0}
                _log("migrate sync error: %s", e)

            _real_done, _real_failed = mres.get("done", []), mres.get("failed", [])
            # v1.7.33 如实记账：每一条结果（含没搬动的）都进 mig_records 并落盘，
            # 带上 status/done_gb/pending_gb/resume，报告据此诚实展示「已迁 X · 剩 Y」+ 补齐入口。
            # 铁律：绝不再出现「某项凭空消失、failed=[] 假成功」。
            def _rec(_r, _ok):
                _name = ""
                try:
                    _name = os.path.basename(os.path.normpath(_r.get("src") or "")) or (_r.get("src") or "")
                except Exception:
                    _name = _r.get("src") or ""
                return {
                    "src": _r.get("src"), "dst": _r.get("dst"),
                    "name": _name,
                    "kb": float(_r.get("kb", 0) or 0),
                    "ok": bool(_ok), "msg": _r.get("msg", "" if _ok else "没能搬动"),
                    "status": _r.get("status") or ("done" if _ok else "failed"),
                    "done_gb": float(_r.get("done_gb", 0) or 0),
                    "pending_gb": float(_r.get("pending_gb", 0) or 0),
                    "resume": _r.get("resume", ""),
                    "cleanup_warning": _r.get("cleanup_warning", False),
                    "reboot_commit": _r.get("reboot_commit", False),
                    "committed_gb": _r.get("committed_gb", 0),
                }
            for _r in _real_done:
                _s = _r.get("src")
                if _s and _s not in done:
                    done.append(_s)
                mig_records.append(_rec(_r, True))
            for _r in _real_failed:
                _s = _r.get("src")
                if _s and _s not in failed:
                    failed.append(_s)
                    failed_reasons[_s] = _r.get("msg", "没能搬动")
                mig_records.append(_rec(_r, False))
            # deferred：从真实结果派生（需重启才能搬完的项），不再是「跳过且不记账」的黑洞
            for _mr in mig_records:
                if _mr.get("resume") == "reboot" and float(_mr.get("pending_gb") or 0) > 0.001:
                    deferred.append({
                        "src": _mr.get("src"), "name": _mr.get("name") or _mr.get("src"),
                        "size_kb": float(_mr.get("pending_gb") or 0) * 1024 * 1024,
                        "status": _mr.get("status"),
                    })
            # 记录迁移成功项 src（报告刷新用）；真实释放量统一在下方用磁盘实测核算。
            _real_done_srcs = [_r.get("src") for _r in _real_done if _r.get("ok")]
        # ===== 真实释放量：双轨制（v1.7.24 P0 修复） =====
        # 此前磁盘实测依赖 wait_purge(90s)：Temp 等系统共享目录清空需数分钟（本机实测
        # 6.7GB/数千文件 90s 删不完）→ free_after 测早 → freed 严重低估（实测 0.09GB vs
        # 实际 17.2GB）→ 弹窗数字离谱。改为：
        #   ① 弹窗即时：标称核算（条目标称 - 真实残留），sse done 立即出（不卡用户）
        #   ② 后台校准：wait_purge(300) 后磁盘实测 → 更新 clean_state + sse freed 事件，
        #      前端弹窗数字更新为最终真实值，页面刷新亦显示真值（数字最终诚实）。
        if mode == "rm":
            # v1.7.54 根因修复（速度+诚实双轨，杜绝打地鼠）：
            # done 即时 freed = 已提交删除缓存条目的「扫描体积 − 真实残留体积」合计。
            #   · 速度：rename 到 aipc_purge 暂存区（同卷、非回收站）即时返回，done/弹窗秒出，
            #     绝不 join 等后台物理删除（否则 10-30G 物理删 1-6 分钟会顶满 SLA、慢盘更超时）——
            #     这正是上轮「解决回收站却拖慢速度」的陷阱，已避开。
            #   · 诚实：标称体积与扫描报告一致（偏差≤10% SLA）；残留已在 _clean_one 内登记重启删、
            #     此处精确扣除，不虚报。
            #   · 可靠性：物理删除在后台 daemon 线程完成；若 WB 关闭/重启打断，
            #     v1.7.82 起不再依赖任何计划任务：立即就地清扫暂存区（migrate._run_purge_stage_cleanup），
            #     且工具每次启动时 auto_cleanup_orphan_baks 也会再清扫一遍，不会像回收站那样卡成永久孤儿。
            #   · 校准：下方 _calibrate_freed 后台线程等物理删完用磁盘实测覆盖为最终真值。
            # AIPC-FREED-DEDUP-FIX：按【条目】核算标称释放量 ——
            # ① 一个条目无论有几条 trash_paths，它的体积只计一次；
            # ② 只有整项所有路径都处理成功才计入（与报告页承诺的 greenReclaim = Σ green.kb
            #    同一口径，部分失败就不计入，绝不虚报）；
            # ③ 再减去该条目处理过程中的真实残留体积。
            # 这样「一键清 8.3GB」就只会是 8.3GB 级别，永远不会变成 264GB。
            # 注：回收站项（__EMPTY_RECYCLE_BIN__）不走本循环，与原逻辑口径保持一致。
            _rm_planned_kb = 0.0
            for _gi, (_gset, _gkb) in enumerate(_green_attr):
                if _gset and _gset.issubset(_done_rps):
                    _rm_planned_kb += max(0.0, _gkb - _resid_by_item.get(_gi, 0.0))
            freed_kb = max(0.0, _rm_planned_kb)
            freed = int(freed_kb * 1024)
            freed_gb = round(freed_kb / 1024 / 1024, 2)
            # v1.7.85（老李「报告说清得了、实际清不掉」根因③·最后一道闸）：
            # 标称 = 条目 kb − 该条目真实残留。若某条路径被登记了「重启删」，
            # 它的文件此刻还在磁盘上，空间尚未释放 —— 必须从「已清理」里剔出去，
            # 转入「待重启」。宁可显示小数字，也绝不让承诺量大于真值。
            # 口径：已清理 = 条目 kb − 真实残留 − 本次登记重启删的量。
            try:
                _rp_bytes = 0
                try:
                    with migrate_mod._PURGE_RESIDUAL_LOCK:
                        _rp_bytes = migrate_mod._PURGE_RESIDUAL.get("bytes", 0) or 0
                except Exception:
                    _rp_bytes = 0
                if _rp_bytes > 0 and freed_kb > 0:
                    _after = max(0.0, freed_kb - (_rp_bytes / 1024.0))
                    if _after < freed_kb:
                        _log("v1.7.85 真值闸：标称 %.2f GB 减去待重启 %.2f GB → 实际已清理 %.2f GB"
                             % (freed_kb / 1048576.0, _rp_bytes / 1048576.0, _after / 1048576.0))
                        freed_kb = _after
                        freed = int(freed_kb * 1024)
                        freed_gb = round(freed_kb / 1024 / 1024, 2)
            except Exception:
                pass
            # AIPC-FREED-DEDUP-FIX 保险丝：物理上不可能释放出比这块盘【已用空间】更多的空间。
            # 上游任何算法错误都不许再传到用户眼前（真机出现过 120GB 的盘显示「释放 258.7GB」）。
            try:
                import shutil as _sh
                _cap = _sh.disk_usage(_free_drive).used
                if _cap and freed > _cap:
                    _log("freed 超上限被夹：%d -> %d（%s 已用 %.2f GB）",
                         freed, _cap, _free_drive, _cap / 1073741824.0)
                    freed = int(_cap)
                    freed_gb = round(_cap / 1073741824.0, 2)
            except Exception:
                pass
            # 后台校准线程（不阻塞 done/弹窗）
            def _calibrate_freed():
                try:
                    migrate_mod.wait_purge(timeout=300)
                    # v1.7.27：SHEmpty 后台线程（黄金组合物理释放）也要等——否则大回收站
                    # 实测过早，freed 低估（20GB SHEmpty ~8 分钟 > wait_purge 窗口）
                    migrate_mod.wait_bg_empty(timeout=420)
                except Exception:
                    pass
                # AIPC-FREED-DEDUP-FIX：任一侧读不到（None）就不校准 ——
                # 宁可不给数字，也绝不拿 0 当真实值算出一个错数字给用户。
                # AIPC-FREED-DEDUP-FIX（第 2 道）：多次采样取最大增量。
                # 单次采样不可信：真机实测一次 8.3GB 的清理被「校准」成 0.03GB。
                # 成因：fast_purge 把目录 rename 到【同盘】暂存区（同盘改名不释放
                # 空间），真正释放发生在后台删除时；单次采样撞上「还没落盘」或
                # 「系统同时写入抵消」就会得到一个远低于真实的极小值。
                # 物理删除是单调的（空间只会越删越多）→ 多次采样取最大值最接近真值。
                # AIPC-SETTLE-TRUTH-FIX（实测唯一权威）
                # 旧实现在 _real <= 0 时直接 return —— 于是【标称估算值继续留在
                # clean_state.json 和页面上】，这就是「报告页显示释放 258.7GB、
                # 磁盘实际只少了 0.03GB」能活到用户眼前的唯一通道。
                # 现在无论实测是否拿到，都必须结账（settle）一次：
                #   拿到正值 → freed = 实测（唯一权威），measured=True
                #   没拿到/为 0 → freed = 0，measured=False，页面明说「未测到」，
                #                  绝不把估算值顶上来充数。
                _real = 0
                for _ti in range(4):
                    _fa = _disk_free_bytes(_free_drive)
                    if _fa is None or _free_before is None:
                        break
                    _real = max(_real, int(_fa - _free_before))
                    if _ti < 3:
                        time.sleep(15.0)
                # AIPC-FREED-PEAK-FIX：再并上「清理全程轨迹」的峰值增量（采样线程见动作
                # 入口）。旧实现只在物理删完之后采 4 次样，采到的是被并发写入抵消后的
                # 余量；轨迹覆盖删除真正发生的整个时间窗，峰值才代表我们腾出来过多少。
                try:
                    _peak = max(_free_trace) if _free_trace else None
                    if _peak is not None and _free_before is not None:
                        _real = max(_real, int(_peak - _free_before))
                except Exception:
                    pass
                # AIPC-FREED-PEAK-FIX（并发安全）：只停本请求自己那条采样线程。
                try:
                    _FREE_SAMPLE["stop"] = _free_rid
                except Exception:
                    pass
                # AIPC-FREED-ATTRIBUTION-FIX：只有【本次真的删掉了东西】才有资格谈释放量。
                # 实测取的是整盘可用空间差值，它不区分是谁腾出来的 —— 别的程序、甚至上一次
                # 点击造成的释放都会被算进本次功劳。活体实测复现过：一次「不在清理白名单」
                # 被拒、什么都没删的请求，照样落盘「实测释放 160MB」。
                # done 非空 ⇔ 至少一项真的处理成功（含回收站项）-> 否则一律 0，不许认领。
                if not done:
                    _log("clean settle skip: 本次没有任何一项成功处理，"
                         "不认领整盘实测差值 %d（%.2f GB）", _real, _real / 1073741824.0)
                    _real = 0
                _measured_ok = _real > 0
                _log("clean settle: 实测释放 %d (%.2f GB) | 标称估算 %.2f GB | 实测可信=%s",
                     _real, _real / 1073741824.0, freed / 1073741824.0,
                     "是" if _measured_ok else "否")
                try:
                    # v1.7.24：异步清空项的真实残留（未清理 X 项 + 已安排重启删）
                    _rc = _rb2 = 0
                    try:
                        with migrate_mod._PURGE_RESIDUAL_LOCK:
                            _rc = migrate_mod._PURGE_RESIDUAL["count"]
                            _rb2 = migrate_mod._PURGE_RESIDUAL["bytes"]
                    except Exception:
                        pass
                    # 校准 = 覆盖磁盘实测真值（不走 _save_clean_state 的落盘逻辑，
                    # 避免估算值参与合并）。整段读-改-写持锁，消灭并发 lost update。
                    with _STATE_LOCK:
                        _cs = {}
                        if os.path.exists(CLEAN_STATE_PATH):
                            try:
                                _cs = json.load(open(CLEAN_STATE_PATH, encoding="utf-8"))
                            except Exception:
                                _cs = {}
                        _rm = _cs.get("rm") or {}
                        _rm["freed"] = int(_real)
                        _rm["freed_gb"] = round(_real / 1073741824.0, 2)
                        _rm["measured"] = bool(_measured_ok)
                        _rm["settled"] = True
                        _rm["ts"] = time.time()
                        # v1.7.83：同时落盘「本次提交量」。实测拿不到时（如校准期间进程被杀），
                        # 读档侧会用它兜底显示，避免页面停在刺眼的 0.0GB。
                        # 落 submitted_gb 而非复用 freed_gb：两个口径必须可区分——
                        # submitted=「已提交删除的量」，measured=「磁盘实测腾出的量」。
                        try:
                            _rm["submitted_gb"] = round(freed / 1073741824.0, 2)
                        except Exception:
                            pass
                        # AIPC-FREED-PEAK-FIX：calibrated 从「硬写 True」改为镜像实测结果。
                        # 旧写法与实测是否成功无关 —— 真机因此留下 calibrated=true 配
                        # freed_gb=0 的矛盾组合（一个纯粹会撒谎的孤儿旗帜）。
                        _rm["calibrated"] = bool(_measured_ok)
                        if _rc:
                            _rm["reboot_pending"] = {"count": _rc, "bytes": _rb2}
                        _cs["rm"] = _rm
                        with open(CLEAN_STATE_PATH, "w", encoding="utf-8") as _f:
                            json.dump(_cs, _f, ensure_ascii=False)
                except Exception as _e:
                    _log("clean settle write failed: %s", _e)
                try:
                    sse({"type": "freed", "freed": int(_real),
                         "freed_gb": round(_real / 1073741824.0, 2),
                         "measured": bool(_measured_ok)})
                except Exception:
                    pass
            try:
                import threading as _th
                _th.Thread(target=_calibrate_freed, daemon=True).start()
            except Exception:
                pass
        else:
            # 迁移：即时标称（成功项 kb 合计，秒级弹窗）+ 后台校准（等 .bak 后台删完 → 磁盘实测）
            # v1.7.24：删源已改后台异步（junction 先建、软件可用），同步等磁盘实测 = 13GB 等 9.5 分钟。
            _mig_ok_kb = sum(float(_r.get("kb", 0) or 0) for _r in _real_done if _r.get("ok"))
            freed = int(_mig_ok_kb * 1024)
            freed_gb = round(_mig_ok_kb / 1024 / 1024, 2)

            def _calibrate_migrate_freed():
                try:
                    migrate_mod.wait_purge(timeout=300)
                except Exception:
                    pass
                # AIPC-FREED-DEDUP-FIX：任一侧读不到（None）就不校准。
                # AIPC-FREED-DEDUP-FIX（第 2 道）：多次采样取最大增量（同 rm 侧，
                # 见 clean 校准处注释：单次采样会因「还没落盘」拿到极小值）。
                # AIPC-SETTLE-TRUTH-FIX（同 rm 侧）：实测拿不到也照样结账，
                # 让页面显示「未测到」而不是留着一个标称估算值冒充实际释放量。
                _real = 0
                for _ti in range(4):
                    _fa = _disk_free_bytes(_free_drive)
                    if _fa is None or _free_before is None:
                        break
                    _real = max(_real, int(_fa - _free_before))
                    if _ti < 3:
                        time.sleep(15.0)
                # AIPC-FREED-PEAK-FIX：再并上「清理全程轨迹」的峰值增量（采样线程见动作
                # 入口）。旧实现只在物理删完之后采 4 次样，采到的是被并发写入抵消后的
                # 余量；轨迹覆盖删除真正发生的整个时间窗，峰值才代表我们腾出来过多少。
                try:
                    _peak = max(_free_trace) if _free_trace else None
                    if _peak is not None and _free_before is not None:
                        _real = max(_real, int(_peak - _free_before))
                except Exception:
                    pass
                # AIPC-FREED-PEAK-FIX（并发安全）：只停本请求自己那条采样线程。
                try:
                    _FREE_SAMPLE["stop"] = _free_rid
                except Exception:
                    pass
                # AIPC-FREED-ATTRIBUTION-FIX：只有【本次真的删掉了东西】才有资格谈释放量。
                # 实测取的是整盘可用空间差值，它不区分是谁腾出来的 —— 别的程序、甚至上一次
                # 点击造成的释放都会被算进本次功劳。活体实测复现过：一次「不在清理白名单」
                # 被拒、什么都没删的请求，照样落盘「实测释放 160MB」。
                # done 非空 ⇔ 至少一项真的处理成功（含回收站项）-> 否则一律 0，不许认领。
                if not done:
                    _log("migrate settle skip: 本次没有任何一项成功处理，"
                         "不认领整盘实测差值 %d（%.2f GB）", _real, _real / 1073741824.0)
                    _real = 0
                _measured_ok = _real > 0
                _log("migrate settle: 实测释放 %d (%.2f GB) | 标称估算 %.2f GB | 实测可信=%s",
                     _real, _real / 1073741824.0, freed / 1073741824.0,
                     "是" if _measured_ok else "否")
                try:
                    with _STATE_LOCK:
                        _cs = {}
                        if os.path.exists(CLEAN_STATE_PATH):
                            try:
                                _cs = json.load(open(CLEAN_STATE_PATH, encoding="utf-8"))
                            except Exception:
                                _cs = {}
                        _mg = _cs.get("migrate") or {}
                        _mg["freed"] = int(_real)
                        _mg["freed_gb"] = round(_real / 1073741824.0, 2)
                        _mg["measured"] = bool(_measured_ok)
                        _mg["settled"] = True
                        _mg["ts"] = time.time()
                        # AIPC-FREED-PEAK-FIX：同 rm 侧，calibrated 只镜像实测结果。
                        _mg["calibrated"] = bool(_measured_ok)
                        _cs["migrate"] = _mg
                        with open(CLEAN_STATE_PATH, "w", encoding="utf-8") as _f:
                            json.dump(_cs, _f, ensure_ascii=False)
                except Exception as _e:
                    _log("migrate settle write failed: %s", _e)
                try:
                    sse({"type": "freed", "freed": int(_real),
                         "freed_gb": round(_real / 1073741824.0, 2),
                         "measured": bool(_measured_ok)})
                except Exception:
                    pass
            try:
                import threading as _th
                _th.Thread(target=_calibrate_migrate_freed, daemon=True).start()
            except Exception:
                pass
        # 迁移：用磁盘实测值刷新报告（展示已迁移项），失败/缺网络静默忽略
        # 用 _async=True 让 build_report.py 在后台跑，sse done 不被它阻塞
        # —— 用户抱怨「进度满但弹窗不出现」就是这个 rebuild 卡住 5+ 分钟引起的
        if _real_done_srcs:
            try:
                _refresh_after_migrate(_real_done_srcs, freed_gb, _async=True)
            except Exception as e:
                _log("refresh_after_migrate error: %s", e)
        # 持久化清理状态（刷新不回退）。
        # AIPC-SETTLE-TRUTH-FIX：本处是主清理/迁移动作，下方必定起校准线程做磁盘实测
        # 结账 → 显式 reset_measured=True，先把上一轮的实测值清零，避免页面上把
        # 「上一次释放了多少」当成这一次的。
        _save_clean_state(mode, done, failed, failed_reasons, freed, freed_gb, mig_records,
                          reset_measured=True)
        # ===== v1.7.98 P0：本轮已收尾，把 in_progress 复位 =====
        # 病根：_set_clean_state_progress 全代码只有开头那 1 处调用、只传 True，
        # 从来没有任何地方传 False → 一旦置真就永远卡在真。前端见 in_progress 为真
        # 每次刷新都弹「上次操作中页面被刷新了」，弹窗挡住操作台
        # → 老李真机表现「一键清执行不下去 / 点迁移又弹这个」。
        try:
            _set_clean_state_progress(mode, False)
        except Exception:
            pass
        # 迁移报告由后台线程在 do_migrate 完成后重生成（见 _bg_migrate），此处不再同步等待
        report_file = None
        # v1.7.33：bg_cleaning 判定从「存在任意≥200MB条目」改为「异步总量>500MB」。
        # 避免清理 3GB（其中仅 1 个 250MB 目录走异步）时也弹"后台还需1-3分钟"的误导提示。
        # 500MB 以内的异步删除通常在 30 秒内完成，用户感知为"秒级完成"，不应显示后台提示。
        _async_kb_threshold = 500 * 1024  # 500MB
        # AIPC-FREED-DEDUP-FIX：原式 sum(_item_size_kb.values()) 是【按路径】求和 ——
        # 同一条目的体积被它的 N 条 trash_paths 各计一次（真机 8GB×33=264GB），
        # 后果：只清了 200MB 也会误弹「后台还需 1-3 分钟」。
        # 改为【按条目】去重，且只统计本轮真删掉的条目（整项所有路径都成功），
        # 与 freed 的核算口径完全一致，从根上消灭"按路径重复计数"这一类问题。
        _total_async_kb = sum(
            _kb for _gset, _kb in _green_attr
            if _kb >= 200 * 1024 and _gset and _gset.issubset(_done_rps))
        _bg_cleaning = bool(mode == "rm" and _total_async_kb >= _async_kb_threshold)
        # AIPC-SETTLE-TRUTH-FIX：done 事件**不再**把标称估算当"已释放"下发。
        # freed/freed_gb 一律 0 + measured=False，真实数字只由 settle（磁盘实测）
        # 事件下发；标称估算另走 claimed_gb，前端只能把它显示为「预计」。
        sse({"type": "done", "ok": True, "need_admin": need_admin, "is_admin": is_admin(), "done": done,
             "failed": failed, "failed_reasons": failed_reasons,
             "freed": 0, "freed_gb": 0.0, "measured": False,
             "claimed_gb": freed_gb, "records": mig_records,
             "deferred": deferred, "report_file": report_file,
             "reboot_registered": reboot_registered_total, "bg_cleaning": _bg_cleaning})


def _refresh_after_migrate(done_paths, freed_gb, _async=False):
    """迁移成功后：重新生成一份与磁盘一致的静态报告。

    不改动全局 DATA（do_GET 已实时按 junction 过滤，页面始终自洽）；仅产出新报告文件。
    异步模式（_async=True）：在后台线程跑 build_report，前端立刻拿到 SSE done 不再等。
    """
    if not done_paths:
        return None

    def _do():
        try:
            import copy, subprocess
            # 重建临时文件放到用户数据目录，不写回技能目录（避免卸载时目录被占用）
            adir = _DATA_DIR
            migrated = set(expand_nojunction(d) for d in done_paths)
            updated = copy.deepcopy(DATA)
            mb = updated.get("migration") or {}
            plan = mb.get("plan") or []
            kept_plan = [p for p in plan if expand_nojunction(p.get("src", "")) not in migrated]
            kept_cands = [c for c in (mb.get("candidates") or [])
                          if expand_nojunction(c.get("path", "") or c.get("src", "")) not in migrated]
            mb["plan"] = kept_plan
            mb["candidates"] = kept_cands
            if kept_plan != plan:
                kb = sum(float(p.get("size_kb", 0) or 0) for p in kept_plan)
                mb["reclaim_kb"] = kb
                mb["reclaim_h"] = migrate_mod._kb_h(kb)
            ana_tmp = os.path.join(adir, "analysis_migrated.json")
            rep_out = os.path.join(adir, "report_latest.html")
            with open(ana_tmp, "w", encoding="utf-8") as f:
                json.dump(updated, f, ensure_ascii=False)
            cfg = os.path.join(HERE, "config.json")
            build = os.path.join(HERE, "build_report.py")
            env = dict(os.environ)
            env["PYTHONUTF8"] = "1"
            env["PYTHONIOENCODING"] = "utf-8"
            r = subprocess.run([sys.executable, build, ana_tmp, rep_out, cfg],
                               text=True, env=env, capture_output=True,
                               creationflags=CREATE_NO_WINDOW)
            if r.returncode != 0:
                _log("migrated report build failed: %s", (r.stderr or "")[-300:])
                return None
            _log("migrated report rebuilt -> %s", rep_out)
            return "report_latest.html"
        except Exception as e:
            _log("refresh_after_migrate error: %s", e)
            return None

    if _async:
        import threading as _th
        _t = _th.Thread(target=_do, daemon=True)
        _t.start()
        return None
    return _do()


def _maybe_open_browser(url):
    """打开报告页；带去重锁，避免重复启动 server.py 时开出多个互动报告页。

    同一会话（30s 内）若已开过浏览器，本次跳过，保证「只跳出一个报告页」。
    Windows 优先用 os.startfile，比 webbrowser.open 更容易把浏览器窗口推到前台。
    """
    import json as _json
    try:
        ddir = license_mod.get_data_dir()
        os.makedirs(ddir, exist_ok=True)
        lock = os.path.join(ddir, "aipc_browser_open.lock")
        now = time.time()
        if os.path.exists(lock):
            try:
                d = _json.load(open(lock, encoding="utf-8"))
                if (now - (d.get("ts") or 0)) < 30:  # 30s 内已开过，跳过重复打开
                    return
            except Exception:
                pass
        with open(lock, "w", encoding="utf-8") as f:
            _json.dump({"ts": now}, f)
    except Exception:
        pass
    opened = False
    if sys.platform.startswith("win"):
        try:
            # os.startfile 走 Windows shell，等价于用户双击链接，通常能把浏览器推到眼前
            os.startfile(url)
            opened = True
        except Exception:
            pass
    if not opened:
        try:
            # new=1 尝试开新窗口，autoraise=True 尝试置顶
            webbrowser.open(url, new=1, autoraise=True)
            opened = True
        except Exception:
            pass
    if not opened:
        print("（无法自动打开浏览器，请手动复制上面的地址打开）")


def _cleanup_runtime_dir():
    """server 退出（idle/异常）时清理 run.py 准备的临时目录，避免积累垃圾。

    仅当 AIPC_RUNTIME_DIR 存在且位于临时目录/AI_PC_Butler 时才删（不误删开发目录）。
    """
    try:
        tmp = os.environ.get("AIPC_RUNTIME_DIR")
        if not tmp:
            return
        n = os.path.normpath(tmp).lower()
        if not any(s in n for s in ("\\temp\\", "\\tmp\\", "\\ai_pc_butler\\")):
            return
        if os.path.isdir(tmp):
            shutil.rmtree(tmp, ignore_errors=True)
    except Exception:
        pass


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    # v1.7.33：全局抑制 Windows 系统错误对话框（"找不到项目"/"删除出错"等）。
    # 整个 server 进程生命周期内生效，防止清理/迁移过程中弹出任何系统级弹窗。
    if sys.platform.startswith("win"):
        try:
            import ctypes
            SEM_FAILCRITICALERRORS = 0x0001
            ctypes.windll.kernel32.SetErrorMode(SEM_FAILCRITICALERRORS)
        except Exception:
            pass
    atexit.register(_cleanup_runtime_dir)
    global DATA, TPL, RM_ALLOW, TRASH_ALLOW, OPEN_ALLOW, CLEAN_STATE_PATH, ORDERS_PATH, BASE_URL, ANALYSIS_PATH
    DATA, TPL, RM_ALLOW, TRASH_ALLOW, OPEN_ALLOW = load(sys.argv[1])
    ANALYSIS_PATH = os.path.abspath(sys.argv[1])
    # 清理/迁移状态持久化文件：稳定路径（%APPDATA%/AI_PC_Butler），不随带时间戳的
    # analysis 文件迁移，保证迁移记录跨扫描持久存在（修复「迁移记录没了」）。
    CLEAN_STATE_PATH = _clean_state_path()
    # v1.7.99：自愈「陈旧 in_progress」仅在本进程启动时空跑一次（覆盖上一进程异常退出/
    # 断连/被强杀残留）。本次清理进行中的 in_progress 由 _set_clean_state_progress 自行
    # 管理，绝不在读取时误杀，避免前端永远显示 0/47。
    try:
        _aipc_heal_stale_progress(CLEAN_STATE_PATH)
    except Exception:
        pass
    ORDERS_PATH = os.path.join(license_mod.get_data_dir(), "orders.json")
    # v1.7.64（安全合规）：启动时加载用户隐私偏好（设备指纹上报 / 自动预下单），
    # 还原上次选择，避免每次启动回落默认值。
    try:
        _pp = os.path.join(license_mod.get_data_dir(), "privacy.json")
        if os.path.isfile(_pp):
            with open(_pp, "r", encoding="utf-8") as f:
                _pv = json.load(f) or {}
            license_mod.set_hwid_send_enabled(bool(_pv.get("send_hwid", True)))
            import skill_tools as _st
            _st.set_auto_preorder_enabled(bool(_pv.get("auto_preorder", True)))
    except Exception:
        pass
    # 产品表（买断）从 config.json 加载；支付价格的唯一权威来源
    CFG.clear()
    CFG.update(_load_app_config())
    PRODUCTS.clear()
    PRODUCTS.update(CFG.get("plans", {}) or {})
    port = int(os.environ.get("AIPC_PORT", "0") or "0")
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    global SERVER_INSTANCE
    SERVER_INSTANCE = srv
    port = srv.server_address[1]
    url = "http://127.0.0.1:%d/?token=%s" % (port, TOKEN)
    BASE_URL = "http://127.0.0.1:%d" % port
    # 写入稳定文件，run.py 读取后确认服务已就绪（含 token，供 run.py 探活/重载鉴权）。
    try:
        with open(os.path.join(_clean_state_dir(), "last_report_url.txt"), "w", encoding="utf-8") as _f:
            _f.write(url)
    except Exception:
        pass
    # 机器可识别标记（调试用；run.py 不再把它输出到聊天）。
    print("AIPC_REPORT_URL=" + url)
    lic = license_mod.read_license()
    tier = lic.get("tier", 0)
    tier_label = {0: "免费扫描版", 1: "基础版", 2: "高级版"}.get(tier, "未知")
    print("报告服务已启动：" + url)
    print("当前许可：%s（tier=%d）" % (tier_label, tier))
    if tier < 1:
        print("⚠️ 未授权：清理按钮已锁定，报告页输入授权码即可解锁。")
    print("绿灯可删 %d 项 | 橙灯可移废纸篓/打开文件夹 %d 项 | 页面上点" % (len(RM_ALLOW), len(TRASH_ALLOW) - len(RM_ALLOW)))
    print("用完按 Ctrl+C 停止服务（服务关掉后按钮即失效）")
    # v1.7.23：报告页 = WB 侧边栏操作台，【默认永不弹系统浏览器】。
    # 仅当显式设置 AIPC_OPEN_BROWSER=1（开发调试）才尝试自动打开。
    if os.environ.get("AIPC_OPEN_BROWSER") == "1":
        try:
            _maybe_open_browser(url)
        except Exception:
            print("（无法自动打开浏览器，请手动复制上面的地址打开）")
    # 启动空闲监控线程：长时间无请求则自动关闭，避免僵尸服务。
    # AIPC-NO-SCARE-UI-FIX：报告页一旦被真正打开过，空闲窗口不得低于 1800 秒。
    # 事故复盘：本机日志出现"报告页打开 99 秒后服务自行关闭"（idle timeout (90s)）——
    # 服务一死，页面上的清理/迁移就全废。用户还在看报告，就不该被回收。
    _idle_window = INACTIVITY_TIMEOUT
    if _idle_window > 0 and os.path.exists(os.path.join(_DATA_DIR, "report_viewed.txt")):
        _idle_window = max(_idle_window, 1800)
    if _idle_window > 0:
        def _idle_monitor():
            while True:
                time.sleep(10)
                if time.time() - LAST_REQUEST_TIME > _idle_window:
                    try:
                        _log("idle timeout (%ds), shutting down server", _idle_window)
                        srv.shutdown()
                    except Exception:
                        pass
                    break
        threading.Thread(target=_idle_monitor, daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止服务。")


if __name__ == "__main__":
    main()
