# 调弦法大全

## 标准调弦与校音

- 标准调弦（EADGBE，6→1 弦）：E2-A2-D3-G3-B3-E4。
- 校音基准：A4 = 440Hz（5 弦空弦 = A2 110Hz）。相对校音：5 弦 5 品 = 4 弦空弦；4 弦 5 品 = 3 弦空弦；3 弦 4 品 = 2 弦空弦（G 弦例外）；2 弦 5 品 = 1 弦空弦。

## 常用特殊调弦

| 调弦名 | 6→1 弦 | 用途 / 代表 |
|--------|--------|------------|
| Drop D | DADGBE | 民谣指弹、金属强力和弦（单指 6-5-4 弦横按即五和弦） |
| DADGAD | DADGAD | 凯尔特/指弹（Lawrence Juber、押尾部分曲） |
| Open G | DGDGBD | 滑棒蓝调（Keith Richards、Robert Johnson 风） |
| Open D | DADF#AD | 滑棒、指弹（《Nothing Else Matters》前奏亦可标准调） |
| Open E | EBEG#BE | 滑棒（Duane Allman）——张力大，建议降半音用 Open D+变调夹 |
| 半音降 | EbAbDbGbBbEb | 90 年代摇滚/grunge（Guns N' Roses、Nirvana） |
| 全音降 | DGCFAD | 重金属、deep blues |
| Open C | CGCGCE | 现代指弹（Andy McKee《Drifting》） |
| NST（罗伯特·弗里普） | CGDAEG | 设计时较少用，列出备查 |

## 使用要点

1. **换调弦后先重新校音再弹**，且新调弦张力变化会使其他弦跑音，需循环微调 2-3 遍。
2. Drop D 快速设置法：6 弦拨响同时按 5 品调至与 5 弦空弦同度（八度关系由泛音校准：12 品泛音=7 品实音）。
3. 滑棒演奏（Open G/D）：琴枕抬高（ nut riser）、弦距略升、用玻璃/金属滑棒压弦不按品。
4. 电吉他降调超过全音建议换粗一档琴弦（如 010→011/012）避免打品。
5. 爵士箱头传统：拨弦全音+ 变调夹或直接半音降（Eb）获得温暖音色。
