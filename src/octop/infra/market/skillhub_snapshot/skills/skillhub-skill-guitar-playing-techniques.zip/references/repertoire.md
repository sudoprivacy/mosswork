# 练习曲目库（按风格分级，含爵士标准曲）

选曲原则：大众经典 + 技巧针对性 + 难度递进。每曲标注调性、核心技巧、练习要点。

## 一、民谣/流行（木吉他）

| 曲目 | 调 | 难度 | 核心技巧 |
|------|----|------|---------|
| 《Knockin' on Heaven's Door》Bob Dylan | G | ★ | 四个开放和弦转换 |
| 《Wish You Were Here》Pink Floyd | G(录音 Em) | ★★ | 分解+和弦旋律 |
| 《Blackbird》The Beatles | G | ★★★ | Travis picking、半音低音线 |
| 《Dust in the Wind》Kansas | C | ★★★ | 恒定指型琶音 |
| 《Tears in Heaven》Eric Clapton | A | ★★★★ | 指弹+击勾弦+低音保持 |
| 《Fighter / 温柔》中文弹唱入门 | C/G | ★ | 扫弦节奏型入门 |
| 《Fashion》/ 押尾《Fight》 | — | ★★★★★ | 打板、AM/PM 技巧、特殊调弦 |

## 二、布鲁斯/摇滚（电吉他）

| 曲目 | 调 | 难度 | 核心技巧 |
|------|----|------|---------|
| 《Smoke on the Water》Deep Purple | G | ★ | 双音 riff |
| 《Sunshine of Your Love》Cream | D | ★★ | riff+蓝调推弦 |
| 《Wonderful Tonight》Eric Clapton | G | ★★ | 旋律独奏、揉弦 |
| 《Sultans of Swing》Dire Straits | Dm→ | ★★★★ | fingerpicking、音色动态 |
| 《Texas Flood》Stevie Ray Vaughan | Eb | ★★★★ | 德州蓝调 shuffle、强推弦 |
| 《Sweet Child O' Mine》GN'R | Db(半音降) | ★★★ | 16 分 riff、点弦 |
| 《Little Wing》Jimi Hendrix | Eb | ★★★★★ | 和弦+旋律双线、Hendrix 和弦 (7#9) |

## 三、Funk / R&B

- 《Superstition》Stevie Wonder（Eb，十六分单音 riff）★★
- 《I Want You Back》Jackson 5（十六分闷音律动）★★
- 《Chameleon》Herbie Hancock（单音 funk riff + 半音贝斯线）★★

## 四、爵士标准曲（吉他版，入门→进阶）

### 入门级（先攻这三首）

1. **《Autumn Leaves》**（e 小调/G 大调）
   - ii-V-I 大调与小调全覆盖，guide tone 练习首选。
   - 和声骨架：Cm7-F7-B♭maj7-E♭maj7(或 Am7b5-D7-Gm)。
2. **《All of Me》**（C 大调）
   - 三明治进行 I-vi-ii-V、下行半音低音 (C-E7-A7-Dm... )。
3. **《Blue Bossa》** Kenny Dorham（Cm→Db 大调）
   - 小调 ii-V-i 与平行大调切换，16 小节短小，即兴入门最佳。

### 中级

4. **《Summertime》**Gershwin（Am，小调布鲁斯感）
   - 旋律律动、闷音 comping。
5. **《Take the "A" Train》**Billy Strayhorn（C）
   - 转位低音线、ii-V 短句。
6. **《There Will Never Be Another You》**（Eb）
7. **《Misty》**Erroll Garner（Eb）——标准 ballad，rubato 旋律+solo。

### 进阶

8. **《Stella by Starlight》**（Bb）——复杂和声、半减七运用。
9. **《All the Things You Are》**Jerome Kern（Ab→多调性）——转调马拉松。
10. **《Giant Steps》**John Coltrane（B）——Coltrane changes，终极挑战。

### 吉他大师参考版本（聆听清单）

- Joe Pass《Virtuoso》系列（独奏编曲）
- Wes Montgomery《Full House》（拇指拨弦+octave 线）
- Jim Hall/Bill Evans《Undercurrent》
- Pat Metheny《Bright Size Life》
- Django Reinhardt《Minor Swing》（吉普赛爵士，和声小调+rest stroke）

## 五、练习方法

1. **三遍法**：一遍旋律（原位）、一遍 comping、一遍即兴。
2. 爵士曲目先背和声功能谱（罗马数字）再移调至 Bb、Eb、F 三个常用调。
3. 使用 iReal Pro / YouTube backing track 伴奏练习即兴。
4. 聆听参考版本并扒 2-4 小节乐句，分析其节奏放置（负空间 swing）。
