# -*- coding: utf-8 -*-
r"""
draw_science_figs.py —— K12 科学命题 skill 的「初中理科随题图绘制助手」（可选，需 matplotlib）。

定位：本文件是 draw_geometry.py 的**初中理科专项扩展**，专门补齐物理/化学/生物三科
      出卷最高频的"随题图"：光路图、力的图示、实验装置图、图像曲线、制取装置、
      微观示意、溶解度曲线、细胞/器官结构、生理曲线、遗传图解、探究装置、食物链等。
      所有图均**代码精确绘制**（角度、刻度、连接、标注严谨），绝不依赖 AI 文生图
      （避免角度失真、读数乱码）。

依赖：pip install matplotlib
中文：自动加载系统黑体（simhei.ttf），标签不乱码。
风格：与 draw_geometry.py 一致（黑色 #1a1a1a 线稿、红色 #c00/#e11 强调、浅灰虚线辅助）。

常用函数速查：
  —— 物理 ——
  light_plane_mirror(path, ...)          平面镜成像光路（物体/虚像/入射·反射光线/法线）
  light_lens(path, kind='u>2f'|'f<u<2f'|'u<f', ...)  凸透镜成像光路（三条特殊光线）
  light_refraction(path, ...)            光的折射（筷子弯折/池水变浅，空气↔水）
  light_pinhole(path, ...)               小孔成像（光沿直线传播，蜡烛→倒立实像）
  force_diagram(path, preset='horizontal'|'incline'|'in_water'|'free_fall'|'balanced'|'lift', ...)
                                        力的示意图（重力/支持力/摩擦力/浮力/拉力箭头）
  ramp_car(path, s=1.2, ...)             斜面小车测平均速度装置图
  balance_cylinder(path, mass=..., vol=..., ...)  天平读数(甲)+量筒读数(乙) 测密度图
  boiling_apparatus(path, ...)           水沸腾实验装置（酒精灯+石棉网+烧杯+温度计）
  optical_bench(path, ...)               凸透镜成像光具座（蜡烛-透镜-光屏+刻度尺）
  phase_curve(path, kind='melt'|'boil'|'freeze', ...)  物态变化温度-时间图像（带熔点/沸点平台）
  motion_graph(path, kind='st'|'vt', ...)  运动学 s-t / v-t 图像
  —— 化学 ——
  gas_setup(path, gas='O2'|'CO2', ...)   气体制取+收集装置（O2 固固加热 / CO2 固液不加热）
  filter_setup(path, ...)                过滤操作装置（一贴二低三靠）
  cylinders(path, ...)                   量筒读数（视线与凹液面最低处相平）
  atom_structure(path, protons=..., neutrons=..., ...)  原子结构示意（核+电子层）
  electrolysis_water(path, ...)          电解水微观（水分子→H2:O2=2:1）
  ionic_nacl(path, ...)                  氯化钠形成（Na/Cl → Na⁺/Cl⁻ → 离子化合物）
  solubility_curve(path, ...)            溶解度曲线（多物质+交叉点+指定点）
  —— 生物 ——
  cell_structure(path, kind='animal'|'plant', ...)  动植物细胞模式图（结构标注）
  eye_structure(path, ...)               眼球结构模式图（角膜/晶状体/视网膜等）
  digestive_system(path, ...)            消化系统组成（消化道+消化腺）
  photosynthesis_curve(path, kind='light'|'co2'|'temp', ...)  光合速率曲线（饱和/最适）
  enzyme_curve(path, kind='ph'|'temp', ...)  酶活性曲线（最适+失活）
  punnett(path, p1='Aa', p2='Aa', ...)   遗传图解（Punnett 方格 + 子代比例）
  germination(path, ...)                 种子萌发条件三装置（水/空气/温度）
  food_chain(path, chains=..., ...)       食物链/食物网（节点+箭头）
"""
import os
import math
import warnings
import matplotlib
matplotlib.use("Agg")
warnings.filterwarnings("ignore", message="findfont:")   # SimHei 无 bold 字重，抑制无害告警
import logging as _logging
_logging.getLogger("matplotlib.font_manager").setLevel(_logging.ERROR)
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Polygon, Wedge, Circle, Ellipse, Rectangle

# ---- 中文支持：自动找系统黑体 ----
_FONT = None
for _cand in (r"C:/Windows/Fonts/simhei.ttf",
              r"C:/Windows/Fonts/msyh.ttc",
              r"/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"):
    if os.path.exists(_cand):
        _FONT = _cand
        break
if _FONT:
    from matplotlib import font_manager
    font_manager.fontManager.addfont(_FONT)
    plt.rcParams["font.family"] = font_manager.FontProperties(fname=_FONT).get_name()
plt.rcParams["axes.unicode_minus"] = False

# 配色（与 draw_geometry.py 一致）
INK = "#1a1a1a"
RED = "#c00"
REDB = "#e11"
GRAY = "#999"
LBLUE = "#dbeafe"
LYEL = "#fde68a"
LGREEN = "#cfe8c8"
LGRAY = "#e5e7eb"


# ---------------------------------------------------------------------------
# 基础图元（与 draw_geometry 同风格）
# ---------------------------------------------------------------------------
def _new_fig(figsize=(4.6, 3.4)):
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.set_aspect("equal")
    ax.axis("off")
    return fig, ax


def save(fig, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def label(ax, p, text, dx=0.18, dy=0.12, size=13, color=INK):
    ax.text(p[0] + dx, p[1] + dy, text, fontsize=size, color=color,
            ha="center", va="center")


def _arrow(ax, start, vec, color=INK, lw=1.8, head=0.22, label=None, lbl_dx=0.14, lbl_dy=0.12):
    """从 start 画带箭头的力/光线矢量（vec 为位移）。可选末尾标签。"""
    tip = (start[0] + vec[0], start[1] + vec[1])
    ax.annotate("", xy=tip, xytext=start,
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw,
                                mutation_scale=14))
    if label:
        ax.text(tip[0] + lbl_dx, tip[1] + lbl_dy, label, fontsize=12,
                color=color, ha="center", va="center")
    return tip


def _dashed_line(ax, p1, p2, color=GRAY, lw=1.0):
    ax.plot([p1[0], p2[0]], [p1[1], p2[1]], ls="--", color=color, lw=lw)


# ===========================================================================
# 物理：光路图
# ===========================================================================
def light_plane_mirror(path, kind="S", figsize=(5.2, 3.6)):
    """平面镜成像光路：竖直平面镜（镜面画斜线影线），左侧物体 S（箭头），
    右侧虚像 S'（对称、虚线），一条从 S 顶端经镜面 P 点反射到眼 E 的光线 + 法线，
    并标出入射角=反射角。kind 仅占位（默认单物成像）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.6, 3.6); ax.set_ylim(-2.2, 2.4)
    # 镜面（x=0）
    ax.plot([0, 0], [-2.0, 2.0], color=INK, lw=2.2)
    for y in (-1.8, -1.2, -0.6, 0.0, 0.6, 1.2, 1.8):
        ax.plot([0, 0.28], [y, y + 0.28], color=INK, lw=0.8)   # 镜面影线
    ax.text(-0.45, 2.15, "平面镜", fontsize=11)
    # 物体 S：箭头，底端 (-2.4, -1.4) 顶端 (-2.4, 0.6)
    S = (-2.4, 0.6); Sb = (-2.4, -1.4)
    ax.plot([Sb[0], S[0]], [Sb[1], S[1]], color=INK, lw=1.8)
    ax.plot([S[0]-0.18, S[0]], [S[1]-0.32, S[1]], color=INK, lw=1.8)
    ax.plot([S[0]+0.18, S[0]], [S[1]-0.32, S[1]], color=INK, lw=1.8)
    ax.text(-2.7, -0.4, "S\n物体", fontsize=11, va="center")
    # 虚像 S'（对称 x=2.4，虚线箭头）
    Sp = (2.4, 0.6); Spb = (2.4, -1.4)
    ax.plot([Spb[0], Sp[0]], [Spb[1], Sp[1]], ls="--", color=RED, lw=1.8)
    ax.plot([Sp[0]-0.18, Sp[0]], [Sp[1]-0.32, Sp[1]], ls="--", color=RED, lw=1.8)
    ax.plot([Sp[0]+0.18, Sp[0]], [Sp[1]-0.32, Sp[1]], ls="--", color=RED, lw=1.8)
    ax.text(2.75, -0.4, "S′\n虚像", fontsize=11, color=RED, va="center")
    # 反射点 P 在镜面
    P = (0.0, 0.2)
    E = (2.0, 1.5)                      # 眼
    # 入射光线 S->P，反射光线 P->E
    ax.plot([S[0], P[0]], [S[1], P[1]], color=INK, lw=1.8)
    ax.plot([P[0], E[0]], [P[1], E[1]], color=INK, lw=1.8)
    ax.plot([E[0]], [E[1]], "o", color=INK, ms=4)
    ax.text(E[0]+0.12, E[1]-0.05, "眼", fontsize=11)
    # 法线（过 P 水平）
    _dashed_line(ax, (-1.2, P[1]), (1.4, P[1]))
    ax.text(-1.3, P[1]+0.05, "法线", fontsize=10, color=GRAY)
    ax.text(P[0]-0.12, P[1]-0.28, "P", fontsize=11)
    # 入射角/反射角弧
    ax.add_patch(Arc((0, P[1]), 0.7, 0.7, angle=0, theta1=0, theta2=73, color=RED, lw=1.0))
    ax.add_patch(Arc((0, P[1]), 0.7, 0.7, angle=0, theta1=180, theta2=253, color=RED, lw=1.0))
    return save(fig, path)


def light_lens(path, kind="u>2f", f=2.0, ho=1.3, figsize=(6.4, 4.2)):
    """凸透镜成像光路（三条特殊光线中的两条）：
       kind='u>2f'  物体在 2F 外 → 倒立缩小实像（F 与 2F 之间）
       kind='f<u<2f' 物体在 F 与 2F 之间 → 倒立放大实像（2F 外）
       kind='u<f'    物体在 F 内 → 正立放大虚像（同侧，虚线）
       画出光轴、透镜(中央箭头符号)、焦点 F/2F、物体箭头、两束光线、像箭头。"""
    u = {"u>2f": 4.6, "f<u<2f": 3.2, "u<f": 1.3}[kind]
    fig, ax = _new_fig(figsize)
    xmax = 7.2 if kind != "u<f" else 5.2
    ax.set_xlim(-u-1.4, xmax); ax.set_ylim(-3.4, 3.4)
    # 光轴
    _dashed_line(ax, (-u-1.2, 0), (xmax, 0), color=GRAY, lw=0.9)
    # 透镜（中央竖直，两端向外箭头表示会聚）
    ax.plot([0, 0], [-2.2, 2.2], color=INK, lw=2.0)
    ax.plot([0, -0.32], [2.2, 2.5], color=INK, lw=1.6)
    ax.plot([0, 0.32], [2.2, 2.5], color=INK, lw=1.6)
    ax.plot([0, -0.32], [-2.2, -2.5], color=INK, lw=1.6)
    ax.plot([0, 0.32], [-2.2, -2.5], color=INK, lw=1.6)
    ax.text(0.18, 2.62, "透镜", fontsize=10)
    # 焦点 / 二倍焦距
    for fx, t in ((f, "F"), (2*f, "2F"), (-f, "F"), (-2*f, "2F")):
        ax.plot([fx], [0], "o", color=INK, ms=3)
        ax.text(fx, -0.32, t, fontsize=10, ha="center")
    # 物体箭头（在 x=-u）
    Ob = (-u, 0); Ot = (-u, ho)
    ax.plot([Ob[0], Ot[0]], [Ob[1], Ot[1]], color=INK, lw=1.8)
    ax.plot([Ot[0]-0.16, Ot[0]], [Ot[1]-0.28, Ot[1]], color=INK, lw=1.6)
    ax.plot([Ot[0]+0.16, Ot[0]], [Ot[1]-0.28, Ot[1]], color=INK, lw=1.6)
    ax.text(Ob[0]-0.12, -0.55, "物体", fontsize=10, ha="center")
    # 透镜成像公式
    v = f * u / (u - f)
    hi = -ho * v / u
    # 两束光线到透镜
    # 光线1：物顶平行光轴 → 过透镜后过右焦点 F(f,0)
    ax.plot([Ot[0], 0], [Ot[1], Ot[1]], color=INK, lw=1.6)           # 到透镜
    # 光线2：物顶过光心 → 直线
    ax.plot([Ot[0], 0], [Ot[1], 0], color=INK, lw=1.6)               # 到透镜中心
    if u > f:   # 实像
        # 折射后的光线延伸到像点 (v, hi)
        ax.plot([0, v], [Ot[1], hi], color=REDB, lw=1.6)
        ax.plot([0, v], [0, hi], color=REDB, lw=1.6)
        # 虚线延长到轴/像
        Ib = (v, 0); It = (v, hi)
        ax.plot([Ib[0], It[0]], [Ib[1], It[1]], color=RED, lw=1.8)
        ax.plot([It[0]-0.16, It[0]], [It[1]+0.28*(1 if hi<0 else -1), It[1]], color=RED, lw=1.6)
        ax.plot([It[0]+0.16, It[0]], [It[1]+0.28*(1 if hi<0 else -1), It[1]], color=RED, lw=1.6)
        ax.text(v+0.12, -0.55, "实像", fontsize=10, color=RED, ha="center")
    else:       # 虚像（同侧，虚线）
        # 折射光线向右发散（沿过 F 的方向）
        ax.plot([0, 2.6], [Ot[1], Ot[1] + (Ot[1])*(2.6)/f], color=REDB, lw=1.6)
        ax.plot([0, 2.6], [0, -Ot[1]*2.6/f], color=REDB, lw=1.6)
        # 反向延长（虚线）到右像点 (v, hi)
        ax.plot([0, v], [Ot[1], hi], ls="--", color=RED, lw=1.4)
        ax.plot([0, v], [0, hi], ls="--", color=RED, lw=1.4)
        Ib = (v, 0); It = (v, hi)
        ax.plot([Ib[0], It[0]], [Ib[1], It[1]], ls="--", color=RED, lw=1.8)
        ax.text(v-0.15, -0.55, "虚像", fontsize=10, color=RED, ha="center")
    return save(fig, path)


def light_refraction(path, figsize=(5.4, 4.0)):
    """光的折射（筷子斜插入水，水下段向法线偏折，看上去弯折）：
       上半为空气、下半为水（浅蓝），水面画分界面，一条筷子穿过，法线虚线，
       并画"看起来的直线"虚线（由水面交点指向眼，高于实际）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.2, 3.2); ax.set_ylim(-3.4, 2.2)
    # 水面（y=0）
    ax.plot([-3.0, 3.0], [0, 0], color=INK, lw=1.6)
    ax.add_patch(plt.Rectangle((-3.0, -3.2), 6.0, 3.2, facecolor=LBLUE,
                               edgecolor="none", zorder=0))
    ax.text(2.4, -0.3, "水", fontsize=12, color="#3b6ea5")
    ax.text(2.4, 0.3, "空气", fontsize=12)
    # 法线
    _dashed_line(ax, (0, -2.6), (0, 1.8), color=GRAY)
    ax.text(0.12, 1.9, "法线", fontsize=10, color=GRAY)
    # 实际筷子：水上一小段直插，水面处折向法线
    ax.plot([-0.6, 0.0], [1.6, 0.0], color=INK, lw=3.0)             # 水上段
    ax.plot([0.0, 0.55], [0.0, -2.6], color=INK, lw=3.0)            # 水下段（向法线偏折）
    # 看起来的虚线（由交点 0,0 指向眼所在的上方直线，比实际高）
    ax.plot([-0.6, 0.0], [1.6, 0.0], color=INK, lw=3.0)
    ax.plot([0.0, 0.95], [0.0, 1.55], ls="--", color=RED, lw=2.0)   # 虚像方向
    # 眼
    ax.plot([0.95], [1.55], "o", color=INK, ms=4)
    ax.text(1.1, 1.55, "眼", fontsize=11)
    ax.text(-1.7, -1.4, "筷子在水面处\n弯折", fontsize=11, color=RED)
    return save(fig, path)


def light_pinhole(path, figsize=(6.6, 3.6)):
    """小孔成像（光沿直线传播）：左侧蜡烛，中间带小孔的不透明板，右侧光屏上倒立实像。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.6, 3.6); ax.set_ylim(-2.2, 2.2)
    # 蜡烛（左）
    ax.add_patch(Rectangle((-3.4, -0.5), 0.4, 1.4, fill=False, ec=INK, lw=1.4))
    ax.add_patch(Wedge((-3.2, 1.0), 0.32, 0, 360, facecolor=RED, edgecolor=INK, lw=1.0))
    ax.text(-3.2, -0.9, "蜡烛", fontsize=11, ha="center")
    # 小孔板（中）
    ax.add_patch(Rectangle((-0.5, -2.0), 1.0, 4.0, facecolor="#f3f4f6",
                           edgecolor=INK, lw=1.4, zorder=2))
    ax.plot([-0.05, 0.05], [-0.05, 0.05], color=INK, lw=2.0, zorder=3)  # 小孔
    ax.text(0, 2.2, "小孔", fontsize=11, ha="center")
    # 光屏（右）
    ax.add_patch(Rectangle((2.6, -2.0), 0.18, 4.0, fill=False, ec=INK, lw=1.6))
    ax.text(3.2, 2.2, "光屏", fontsize=11, ha="center")
    # 光线：烛顶 (-3.2,1.0) → 小孔 (0,0) → 屏底 (2.7,-1.0)；烛底 (-3.2,-0.3) → 小孔 → 屏顶 (2.7,0.7)
    ax.plot([-3.2, 0, 2.7], [1.0, 0, -1.0], color=RED, lw=1.2)
    ax.plot([-3.2, 0, 2.7], [-0.3, 0, 0.7], color=REDB, lw=1.2)
    # 倒立实像（屏上）
    ax.plot([2.78, 2.78], [-1.0, 0.7], color=INK, lw=2.4)
    ax.text(2.95, -0.15, "倒立\n实像", fontsize=10)
    return save(fig, path)


# ===========================================================================
# 物理：力的图示
# ===========================================================================
def force_diagram(path, preset="horizontal", figsize=(5.0, 3.6)):
    """力的示意图（物体受力分析）常用预设：
       'horizontal' 水平面上的物体：重力 G↓ + 支持力 F_N↑（二力平衡）
       'incline'    斜面上的物体：重力 G↓ + 支持力 F_N⊥斜面 + 摩擦力 f∥斜面向上
       'in_water'   水中的物体：重力 G↓ + 浮力 F_浮↑
       'free_fall'  自由下落：仅重力 G↓
       'balanced'   二力平衡（水平拉力 F 与摩擦力 f 等大反向）
       'lift'       竖直向上提：重力 G↓ + 拉力 F↑（起重机吊物）
       力一律从物体重心画出，箭头长短表示力的大小（重力最长）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-2.8, 2.8); ax.set_ylim(-2.6, 2.6)
    L = 1.2                       # 力的基准长度
    nlabel = r"$F_N$"

    def ground(y, x0=-2.2, x1=2.2, n=9):
        ax.plot([x0, x1], [y, y], color=INK, lw=2.0)
        for k in range(n):
            x = x0 + (x1 - x0) * (k + 0.5) / n
            ax.plot([x, x - 0.16], [y, y - 0.22], color=INK, lw=0.9)

    if preset in ("horizontal", "balanced"):
        ax.add_patch(Rectangle((-0.7, -0.7), 1.4, 1.4, fill=False, ec=INK, lw=2.0))
        ax.text(0.36, 0.36, "物块", fontsize=9.5, ha="center", va="center")
        ground(-0.72)
        _arrow(ax, (0, 0), (0, -L * 1.15), label="G", lbl_dx=0.24, lbl_dy=-0.1)
        _arrow(ax, (0, 0), (0, L), label=nlabel)
        if preset == "balanced":
            _arrow(ax, (0, 0), (-L, 0), label="F", lbl_dx=-0.02, lbl_dy=0.24)
            _arrow(ax, (0, 0), (L, 0), color=REDB, label="f", lbl_dx=0.02, lbl_dy=0.24)

    elif preset == "incline":
        ang = math.radians(30)
        ca, sa = math.cos(ang), math.sin(ang)
        A, B, C = (0.0, 0.0), (0.0, -1.5), (2.6, -1.5)     # 斜面（左竖直、下水平）
        for p1, p2 in ((A, B), (B, C), (C, A)):
            ax.plot([p1[0], p2[0]], [p1[1], p2[1]], color=INK, lw=2.0)
        t = 0.46
        u = (ca, -sa)                                      # 沿斜面向下
        nv = (sa, ca)                                      # 垂直斜面向外
        hu, hn = 0.34, 0.26
        ps = (t * 2.6, -t * 1.5)                           # 斜面上的接触点
        c = (ps[0] + nv[0] * hn, ps[1] + nv[1] * hn)        # 物块中心（底面贴斜面）
        corners = [(c[0] + su * hu * u[0] + sn * hn * nv[0],
                    c[1] + su * hu * u[1] + sn * hn * nv[1])
                   for su, sn in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        ax.add_patch(Polygon(corners, closed=True, facecolor="white", ec=INK, lw=2.0, zorder=5))
        ax.text(c[0] - nv[0] * 0.72, c[1] - nv[1] * 0.72, "物块",
                fontsize=9.5, ha="center", va="center")
        _arrow(ax, c, (0, -1.35), label="G", lbl_dx=0.24, lbl_dy=-0.1)
        _arrow(ax, c, (nv[0] * 1.0, nv[1] * 1.0), label=nlabel)
        _arrow(ax, c, (-u[0] * 0.95, -u[1] * 0.95), color=REDB, label="f")
        # 底角 30°（在右下顶点处画小圆弧并标注，避开力的箭头）
        ax.add_patch(Arc(C, 0.62, 0.62, theta1=150, theta2=180, ec=RED, lw=1.2))
        ax.text(2.06, -1.37, "30°", fontsize=10, color=RED, ha="left", va="center")

    elif preset == "in_water":
        ax.add_patch(plt.Rectangle((-2.4, -2.3), 4.8, 3.95, facecolor=LBLUE,
                                   edgecolor="none", zorder=0))
        ax.plot([-2.4, 2.4], [1.65, 1.65], color="#7aa7d0", lw=1.4, zorder=1)
        ax.text(2.3, 1.82, "水面", fontsize=9.5, ha="right", color="#3f6f9f")
        ax.add_patch(Circle((0, 0), 0.75, fill=False, ec=INK, lw=2.0, zorder=3))
        ax.text(0.33, 0.3, "石块", fontsize=9.5, ha="center", va="center", zorder=4)
        _arrow(ax, (0, 0), (0, -1.35), label="G")
        _arrow(ax, (0, 0), (0, 1.05), color=REDB, label="F浮")

    elif preset == "free_fall":
        ax.add_patch(Circle((0, 0), 0.62, fill=False, ec=INK, lw=2.0))
        ax.text(0.3, 0.26, "小球", fontsize=9.5, ha="center", va="center")
        _arrow(ax, (0, 0), (0, -1.45), label="G", lbl_dx=0.24, lbl_dy=-0.1)
        ax.text(0, 1.0, "自由下落（只受重力）", fontsize=10.5, ha="center")

    elif preset == "lift":
        ax.add_patch(Rectangle((-0.7, -0.6), 1.4, 1.2, fill=False, ec=INK, lw=2.0))
        ax.text(0.36, 0.32, "重物", fontsize=9.5, ha="center", va="center")
        ax.plot([0, 0], [0.6, 1.9], color=INK, lw=1.4)
        ax.plot([-0.35, 0.35], [1.9, 1.9], color=INK, lw=1.6)
        _arrow(ax, (0, 0), (0, -1.45), label="G", lbl_dx=0.24, lbl_dy=-0.1)
        _arrow(ax, (0, 0), (0, 1.1), color=RED, label="F", lbl_dx=0.2, lbl_dy=0.06)
    return save(fig, path)


# ===========================================================================
# 物理：实验装置图
# ===========================================================================
def ramp_car(path, s=1.2, figsize=(6.2, 3.6)):
    """斜面小车测平均速度实验装置：斜面（带刻度）、小车、底端金属挡板、s 距离标注。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.5, 6.6); ax.set_ylim(-0.5, 3.2)
    # 斜面（从 (0.4,2.4) 到 (5.6,0.4)）
    ax.plot([0.4, 5.6], [2.4, 0.4], color=INK, lw=2.4)
    # 支撑腿
    ax.plot([0.4, 0.4], [2.4, 0.0], color=INK, lw=1.4)
    ax.plot([5.6, 5.6], [0.4, 0.0], color=INK, lw=1.4)
    # 刻度（沿斜面）
    for k in range(1, 6):
        x = 0.4 + (5.6-0.4)*k/6; y = 2.4 + (0.4-2.4)*k/6
        ax.plot([x, x+0.12], [y, y-0.18], color=GRAY, lw=0.8)
    # 小车（在斜面上，用矩形近似，沿斜面方向）
    cx, cy = 3.0, 1.55
    ax.add_patch(Rectangle((cx-0.55, cy-0.28), 1.1, 0.56, fill=False, ec=INK, lw=2.0))
    ax.plot([cx-0.4, cx+0.4], [cy-0.28, cy-0.28], color=INK, lw=1.4)  # 车轮轴
    ax.plot([cx-0.4], [cy-0.28], "o", color=INK, ms=5)
    ax.plot([cx+0.4], [cy-0.28], "o", color=INK, ms=5)
    # 金属挡板（底端）
    ax.plot([5.6, 5.6], [0.4, 1.2], color=RED, lw=2.4)
    # s 距离标注（沿斜面上方）
    ax.annotate("", xy=(5.4, 2.5), xytext=(2.6, 2.5),
                arrowprops=dict(arrowstyle="<->", color=RED, lw=1.2))
    ax.text(4.0, 2.7, "s=%g m" % s, fontsize=12, color=RED, ha="center")
    ax.text(0.4, 2.7, "斜面", fontsize=11)
    return save(fig, path)


def balance_cylinder(path, mass=None, volume=None, figsize=(7.6, 3.4)):
    """测密度：甲=天平读数（砝码+游码），乙=量筒读数。
       mass 为总质量(g)，volume 为量筒读数(mL)；不传则画"无读数"的示例模板。"""
    m = mass if mass is not None else 82.4
    v = volume if volume is not None else 40.0
    fig, axes = plt.subplots(1, 2, figsize=figsize, dpi=200)
    # ---- 甲：托盘天平 ----
    ax = axes[0]; ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-2.6, 2.6); ax.set_ylim(-1.0, 2.4)
    # 底座
    ax.plot([-1.8, 1.8], [-0.9, -0.9], color=INK, lw=2.0)
    ax.plot([0, 0], [-0.9, -0.2], color=INK, lw=2.0)              # 立柱
    ax.plot([0, -1.4], [-0.2, 0.2], color=INK, lw=1.6)            # 左臂
    ax.plot([0, 1.4], [-0.2, 0.2], color=INK, lw=1.6)             # 右臂
    ax.plot([0, 0], [-0.2, 0.45], color=INK, lw=1.6)              # 中柱顶
    # 左盘（物体）
    ax.add_patch(Rectangle((-1.9, 0.0), 1.0, 0.18, fill=False, ec=INK, lw=1.6))
    ax.text(-1.4, 0.3, "物体", fontsize=10, ha="center")
    # 右盘（砝码）
    ax.add_patch(Rectangle((0.9, 0.0), 1.0, 0.18, fill=False, ec=INK, lw=1.6))
    # 砝码块（按质量取几个示例块）
    ax.add_patch(Rectangle((1.0, 0.18), 0.35, 0.32, fill=False, ec=INK, lw=1.2))
    ax.add_patch(Rectangle((1.4, 0.18), 0.28, 0.28, fill=False, ec=INK, lw=1.2))
    ax.text(1.3, 0.7, "砝码", fontsize=9, ha="center")
    # 游码（标尺）
    ax.plot([-1.9, 1.9], [-0.55, -0.55], color=INK, lw=1.2)
    for k in range(6):
        ax.plot([-1.4+k*0.6, -1.4+k*0.6], [-0.55, -0.62], color=INK, lw=0.8)
    slide = (m % 10) / 10.0 * 1.8 - 0.9 if mass is not None else 0.0
    ax.add_patch(Rectangle((slide-0.08, -0.52), 0.16, 0.2, facecolor=RED, ec=INK, lw=0.8))
    ax.text(0, -0.95, "甲：天平", fontsize=11, ha="center")
    if mass is not None:
        ax.text(0, 1.9, "%g g" % m, fontsize=12, color=RED, ha="center")
    # ---- 乙：量筒 ----
    ax = axes[1]; ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-1.6, 1.8); ax.set_ylim(-0.6, 3.4)
    # 量筒（梯形筒身）
    ax.plot([-0.7, -0.5], [0.0, 3.0], color=INK, lw=2.0)
    ax.plot([0.7, 0.5], [0.0, 3.0], color=INK, lw=2.0)
    ax.plot([-0.7, 0.7], [0.0, 0.0], color=INK, lw=2.0)
    # 刻度
    for k in range(0, 61, 10):
        yy = 0.2 + (3.0-0.2)*k/60
        ax.plot([-0.7, -0.5], [yy, yy+0.0], color=INK, lw=1.0) if False else None
        ax.plot([-0.7, -0.55], [yy, yy], color=INK, lw=0.9)
        ax.text(-1.4, yy, "%d" % (k//2*20), fontsize=8, ha="right", va="center")
    # 液体（浅蓝）到读数
    yv = 0.2 + (3.0-0.2)*(v/100.0) if volume is not None else 1.6
    ax.add_patch(plt.Rectangle((-0.58, 0.0), 1.0, yv, facecolor=LBLUE, edgecolor="none", zorder=0))
    ax.plot([-0.62, 0.62], [yv, yv], color=RED, lw=1.6)          # 凹液面
    # 视线（平视）
    ax.annotate("", xy=(-1.3, yv), xytext=(1.3, yv),
                arrowprops=dict(arrowstyle="<->", color=GRAY, lw=0.8))
    ax.text(0, 3.2, "乙：量筒", fontsize=11, ha="center")
    if volume is not None:
        ax.text(1.2, yv+0.1, "%g mL" % v, fontsize=11, color=RED, ha="left")
    fig.tight_layout()
    return save(fig, path)


def boiling_apparatus(path, figsize=(4.8, 5.4)):
    """水沸腾实验装置：铁架台 + 石棉网 + 烧杯（含水）+ 温度计 + 酒精灯。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.2, 3.2); ax.set_ylim(-0.5, 6.2)
    # 铁架台
    ax.plot([-2.6, -2.6], [0.0, 5.6], color=INK, lw=2.2)          # 立杆
    ax.plot([-2.9, -2.3], [0.0, 0.0], color=INK, lw=2.2)          # 底座
    # 铁夹 + 横臂夹烧杯
    ax.plot([-2.6, -0.9], [4.0, 4.0], color=INK, lw=1.6)
    ax.plot([-0.9, -0.9], [3.6, 4.4], color=INK, lw=1.6)
    # 烧杯（矩形+圆底近似）
    ax.add_patch(Rectangle((-1.6, 1.2), 3.2, 2.4, fill=False, ec=INK, lw=2.0))
    ax.add_patch(plt.Rectangle((-1.55, 1.25), 3.1, 1.5, facecolor=LBLUE,
                               edgecolor="none", zorder=0))        # 水
    ax.plot([-1.6, 1.6], [2.75, 2.75], color=INK, lw=1.2)         # 液面
    ax.text(1.9, 2.0, "水", fontsize=11, color="#3b6ea5")
    # 温度计（插入水中）
    ax.plot([1.0, 1.0], [2.7, 5.2], color=INK, lw=2.0)
    ax.add_patch(Circle((1.0, 1.9), 0.22, fill=False, ec=INK, lw=1.4))  # 玻璃泡
    ax.text(1.3, 5.0, "温度计", fontsize=10)
    # 石棉网
    ax.plot([-2.0, 2.0], [1.1, 1.1], color=INK, lw=1.6)
    # 酒精灯（下）
    ax.add_patch(Rectangle((-0.7, 0.0), 1.4, 0.7, fill=False, ec=INK, lw=1.8))
    ax.plot([-0.2, 0.2], [0.7, 1.0], color=INK, lw=1.4)           # 灯颈
    # 火焰
    ax.add_patch(Wedge((0, 1.0), 0.5, 0, 180, facecolor=RED,
                       edgecolor="none", zorder=0))
    ax.add_patch(Wedge((0, 1.0), 0.24, 0, 180, facecolor=LYEL,
                       edgecolor="none", zorder=1))
    ax.text(0, -0.3, "酒精灯", fontsize=11, ha="center")
    return save(fig, path)


def optical_bench(path, figsize=(7.6, 3.4)):
    """凸透镜成像光具座：蜡烛（左）- 凸透镜（中）- 光屏（右），下方刻度尺。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.5, 8.2); ax.set_ylim(-1.6, 2.2)
    # 导轨
    ax.plot([-0.2, 8.0], [-1.2, -1.2], color=INK, lw=2.0)
    for k in range(0, 9):
        ax.plot([k*1.0, k*1.0], [-1.2, -1.35], color=INK, lw=0.8)
        ax.text(k*1.0, -1.5, "%d" % (0 if k==0 else k*10), fontsize=8, ha="center")
    # 蜡烛（左 x=1.0）
    ax.add_patch(Rectangle((0.9, -0.6), 0.2, 1.0, fill=False, ec=INK, lw=1.4))
    ax.add_patch(Wedge((1.0, 0.4), 0.18, 0, 360, facecolor=RED, edgecolor=INK, lw=1.0))
    ax.text(1.0, -0.85, "蜡烛", fontsize=10, ha="center")
    # 凸透镜（中 x=4.0）
    ax.plot([4.0, 4.0], [-0.9, 0.9], color=INK, lw=2.0)
    ax.plot([4.0, 3.75], [0.9, 1.1], color=INK, lw=1.4)
    ax.plot([4.0, 4.25], [0.9, 1.1], color=INK, lw=1.4)
    ax.plot([4.0, 3.75], [-0.9, -1.1], color=INK, lw=1.4)
    ax.plot([4.0, 4.25], [-0.9, -1.1], color=INK, lw=1.4)
    ax.text(4.35, 1.12, "凸透镜", fontsize=10, ha="left", va="center")
    # 光屏（右 x=6.8）
    ax.add_patch(Rectangle((6.7, -0.9), 0.12, 1.8, fill=False, ec=INK, lw=1.6))
    ax.text(6.95, 1.12, "光屏", fontsize=10, ha="left", va="center")
    # 辅助线（光轴）
    _dashed_line(ax, (0, 0), (7.4, 0), color=GRAY)
    return save(fig, path)


def phase_curve(path, kind="melt", Tm=0.0, figsize=(5.6, 3.8)):
    """物态变化温度-时间图像：
       kind='melt'  晶体熔化（升温→熔点平台→升温）
       kind='boil'  液体沸腾（升温→沸点平台→升温）
       kind='freeze' 液体凝固（降温→凝固点平台→降温）
       标注熔点/沸点、固/液/固液共存（或液/固/固液共存）阶段。"""
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.axhline(0, color="#ccc", lw=0.8); ax.axvline(0, color="#ccc", lw=0.8)
    ax.set_xlabel("时间 / min", fontsize=11); ax.set_ylabel("温度 / ℃", fontsize=11)
    if kind in ("melt", "boil"):
        T0, Tf, t1, t2 = (kind == "melt" and (-8, 12, 4, 9)) or (70, 110, 5, 10)
        xs = [0, t1, t1, t2, t2, 14]
        ys = [T0, T0, Tm, Tm, Tf, Tf]
        ax.plot(xs, ys, color=INK, lw=1.8)
        ax.plot([t1, t1], [T0-2, Tm+0.5], color=RED, ls="--", lw=0.9)
        ax.plot([t2, t2], [Tm-0.5, Tf+2], color=RED, ls="--", lw=0.9)
        ax.text(t1, Tm+1.5, "%g℃" % Tm, fontsize=11, color=RED, ha="center")
        ax.text((t1+t2)/2, Tm-1.6, "固液共存" if kind=="melt" else "沸腾中",
                fontsize=10, color=RED, ha="center")
        if kind == "melt":
            ax.text(2, (T0+Tm)/2, "固态", fontsize=10, ha="center")
            ax.text(12, (Tm+Tf)/2, "液态", fontsize=10, ha="center")
        else:
            ax.text(2.5, (T0+Tm)/2, "升温", fontsize=10, ha="center")
            ax.text(12, (Tm+Tf)/2, "气态", fontsize=10, ha="center")
        ax.set_title("晶体熔化图像" if kind=="melt" else "水沸腾图像", fontsize=12)
    else:  # freeze
        T0, Tf, t1, t2 = 60, 30, 4, 9
        xs = [0, t1, t1, t2, t2, 14]
        ys = [T0, T0, Tm, Tm, Tf, Tf]
        ax.plot(xs, ys, color=INK, lw=1.8)
        ax.text(t1, Tm+1.5, "%g℃" % Tm, fontsize=11, color=RED, ha="center")
        ax.text((t1+t2)/2, Tm-1.6, "固液共存", fontsize=10, color=RED, ha="center")
        ax.set_title("液体凝固图像", fontsize=12)
    ax.set_xlim(-0.5, 14.5); ax.set_ylim(min(T0, Tf, Tm)-12, max(T0, Tf, Tm)+12)
    ax.set_aspect("auto"); ax.axis("off")
    return save(fig, path)


def motion_graph(path, kind="st", figsize=(5.2, 3.6)):
    """运动学图像：kind='st' 路程-时间（匀速为过原点直线），kind='vt' 速度-时间（匀速为水平线）。"""
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.axhline(0, color="#ccc", lw=0.8); ax.axvline(0, color="#ccc", lw=0.8)
    if kind == "st":
        ax.plot([0, 10], [0, 50], color=INK, lw=1.8)
        ax.set_xlabel("时间 t / s", fontsize=11); ax.set_ylabel("路程 s / m", fontsize=11)
        ax.text(5, 28, "匀速直线运动", fontsize=11, color=RED)
    else:
        ax.plot([0, 10], [6, 6], color=INK, lw=1.8)
        ax.set_xlabel("时间 t / s", fontsize=11); ax.set_ylabel("速度 v / (m·s⁻¹)", fontsize=11)
        ax.text(5, 7.4, "匀速直线运动", fontsize=11, color=RED)
    ax.set_xlim(-0.5, 10.5); ax.set_ylim(-2, max(8 if kind=="vt" else 56, 12))
    ax.set_aspect("auto"); ax.axis("off")
    return save(fig, path)


def electroscope(path, charged=True, spread=1.0, figsize=(4.4, 5.6)):
    """验电器（电学高频随题图）：金属球 + 金属杆 + 绝缘垫 + 金属箔 + 外壳。

    charged=True  箔片张开（同种电荷相斥），spread 为张开系数（1.0 标准，0 闭合）；
    charged=False 箔片自然下垂（不带电）。
    """
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-2.6, 2.6); ax.set_ylim(-0.4, 6.6)

    # 外壳（玻璃/金属筒）
    ax.add_patch(Rectangle((-1.35, 0.35), 2.7, 4.15, fill=False, ec=INK, lw=1.6))
    ax.text(1.48, 2.55, "外壳", fontsize=10, ha="left", va="center")

    # 绝缘垫（顶部封口）
    ax.add_patch(Rectangle((-1.35, 4.3), 2.7, 0.35, facecolor=LGRAY, edgecolor=INK, lw=1.2))
    ax.text(-1.48, 4.45, "绝缘垫", fontsize=10, ha="right", va="center")

    # 金属球
    ax.add_patch(Circle((0, 5.35), 0.5, facecolor="#dcdcdc", edgecolor=INK, lw=1.6))
    ax.text(0.62, 5.62, "金属球", fontsize=11, ha="left", va="center")

    # 金属杆
    ax.plot([0, 0], [4.85, 2.35], color=INK, lw=3.2, solid_capstyle="butt")
    ax.text(-1.48, 3.45, "金属杆", fontsize=10, ha="right", va="center")

    # 金属箔（两片，绕顶端小铰点张开）
    ang = math.radians(20 * spread) if charged else math.radians(2)
    L = 1.35
    for s in (-1, 1):
        tip = (s * L * math.sin(ang), 2.3 - L * math.cos(ang))
        poly = [(0, 2.35), tip,
                (tip[0] - s * 0.055, tip[1] - 0.02),
                (s * 0.055, 2.35)]
        ax.add_patch(Polygon(poly, closed=True, facecolor=LGRAY, edgecolor=INK, lw=1.2))
    ax.text(-1.48, 1.15, "金属箔", fontsize=10, ha="right", va="center")
    if charged:
        ax.text(0, 0.78, "同种电荷相斥，箔片张开", fontsize=9, color=RED,
                ha="center", va="center")

    ax.text(0, 6.35, "验电器" + ("" if charged else "（不带电）"), fontsize=12,
            fontweight="bold", ha="center")
    return save(fig, path)


# ===========================================================================
# 化学：制取 / 操作 / 微观 / 曲线
# ===========================================================================
def gas_setup(path, gas="O2", figsize=(7.6, 4.8)):
    """气体制取+收集装置：
       gas='O2'  固固加热（大试管+高锰酸钾/氯酸钾，酒精灯，导管，水槽+集气瓶排水法）
       gas='CO2' 固液不加热（锥形瓶+长颈漏斗+石灰石，导管，集气瓶向上排空气法）
       各部件中文标注；防泄题：不写药品名称文字，仅示意装置与接口。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.5, 8.4); ax.set_ylim(-0.5, 6.4)
    if gas == "O2":
        # 铁架台 + 试管（略向下倾斜）
        ax.plot([1.0, 1.0], [1.2, 5.4], color=INK, lw=2.0)        # 立杆
        ax.plot([0.7, 1.3], [1.2, 1.2], color=INK, lw=2.0)
        ax.plot([1.0, 1.0], [3.4, 3.4], color=INK, lw=1.4)        # 铁夹横
        # 大试管（略斜）
        ax.plot([0.5, 2.4], [3.6, 4.5], color=INK, lw=2.2)        # 上壁
        ax.plot([0.5, 2.4], [3.0, 3.9], color=INK, lw=2.2)        # 下壁
        ax.add_patch(plt.Rectangle((-0.1, 2.5), 0.6, 0.5, fill=False, ec=INK, lw=1.2))  # 管口塞+导管
        ax.plot([0.2, 0.2], [2.5, 1.0], color=INK, lw=1.4)        # 导管弯下
        ax.plot([0.2, 1.3], [1.0, 1.0], color=INK, lw=1.4)
        ax.text(1.4, 4.2, "试管", fontsize=10)
        # 酒精灯
        ax.add_patch(Rectangle((0.6, 0.0), 1.2, 0.6, fill=False, ec=INK, lw=1.8))
        ax.plot([1.0, 1.0], [0.6, 0.85], color=INK, lw=1.2)
        ax.add_patch(Wedge((1.2, 0.85), 0.4, 0, 180, facecolor=RED, edgecolor="none", zorder=0))
        ax.text(1.2, -0.25, "酒精灯", fontsize=10, ha="center")
        # 水槽 + 集气瓶（排水法）
        ax.add_patch(Rectangle((5.6, 0.3), 2.4, 1.6, fill=False, ec=INK, lw=2.0))
        ax.add_patch(plt.Rectangle((5.65, 0.35), 2.3, 1.5, facecolor=LBLUE, edgecolor="none", zorder=0))
        ax.text(6.8, 0.05, "水槽", fontsize=10, ha="center")
        # 集气瓶（倒置排水）
        ax.add_patch(Rectangle((6.0, 2.0), 1.4, 2.2, fill=False, ec=INK, lw=2.0))
        ax.add_patch(plt.Rectangle((6.05, 2.05), 1.3, 1.6, facecolor="#eaf2fb", edgecolor="none", zorder=0))
        ax.plot([1.3, 6.0], [1.0, 3.0], color=INK, lw=1.4)        # 导管入瓶
        ax.text(6.7, 4.4, "集气瓶", fontsize=10, ha="center")
    else:  # CO2
        # 锥形瓶
        ax.add_patch(Polygon([(3.0, 1.2), (4.8, 1.2), (4.5, 4.2), (3.3, 4.2)],
                            fill=False, ec=INK, lw=2.0))
        ax.add_patch(plt.Rectangle((3.1, 1.3), 1.6, 1.4, facecolor=LGRAY, edgecolor="none", zorder=0))
        ax.text(3.9, 0.9, "锥形瓶", fontsize=10, ha="center")
        # 长颈漏斗（伸入液面下）
        ax.plot([3.9, 3.9], [5.4, 2.4], color=INK, lw=2.0)
        ax.plot([3.6, 4.2], [5.4, 5.4], color=INK, lw=2.0)
        ax.text(4.5, 5.6, "长颈漏斗", fontsize=9)
        # 双孔塞 + 导管
        ax.add_patch(Rectangle((3.2, 4.2), 1.4, 0.3, fill=False, ec=INK, lw=1.2))
        ax.plot([4.1, 4.1], [4.5, 5.0], color=INK, lw=1.4)        # 漏斗颈
        ax.plot([4.6, 4.6], [4.5, 5.0], color=INK, lw=1.4)
        ax.plot([4.6, 7.0], [4.5, 4.5], color=INK, lw=1.4)
        ax.plot([7.0, 7.0], [4.5, 3.0], color=INK, lw=1.4)
        ax.text(3.9, 4.8, "双孔塞", fontsize=9)
        # 集气瓶（向上排空气，瓶口向上，导管伸到底）
        ax.add_patch(Rectangle((6.4, 1.0), 1.6, 3.4, fill=False, ec=INK, lw=2.0))
        ax.plot([7.0, 7.0], [3.0, 1.4], color=INK, lw=1.4)        # 导管伸到底
        ax.text(7.2, 4.6, "集气瓶\n(向上排空气)", fontsize=9, ha="center")
    ax.text(0.3, 6.1, "气体制取与收集装置" if gas=="O2" else "二氧化碳制取装置",
            fontsize=11, fontweight="bold")
    return save(fig, path)


def filter_setup(path, figsize=(5.2, 5.2)):
    """过滤操作装置（一贴二低三靠）：漏斗+滤纸+烧杯+玻璃棒引流。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-2.8, 2.8); ax.set_ylim(-0.5, 6.2)
    # 铁架台
    ax.plot([-2.4, -2.4], [0.0, 5.6], color=INK, lw=2.0)
    ax.plot([-2.7, -2.1], [0.0, 0.0], color=INK, lw=2.0)
    ax.plot([-2.4, -0.4], [3.6, 3.6], color=INK, lw=1.6)          # 横臂
    # 漏斗（倒三角）
    ax.plot([-1.4, 1.4], [3.0, 3.0], color=INK, lw=2.0)
    ax.plot([-1.4, 0.0], [3.0, 1.2], color=INK, lw=2.0)
    ax.plot([1.4, 0.0], [3.0, 1.2], color=INK, lw=2.0)
    ax.plot([0.0, 0.0], [1.2, 0.2], color=INK, lw=1.8)            # 漏斗颈
    # 滤纸（内层虚线示意）
    ax.plot([-1.1, 1.1], [3.0, 3.0], ls="--", color=GRAY, lw=1.0)
    ax.plot([-1.1, 0.0], [3.0, 1.35], ls="--", color=GRAY, lw=1.0)
    ax.plot([1.1, 0.0], [3.0, 1.35], ls="--", color=GRAY, lw=1.0)
    ax.text(0.4, 3.4, "漏斗+滤纸", fontsize=10)
    # 烧杯（承接滤液）
    ax.add_patch(Rectangle((-1.2, 0.0), 2.4, 1.8, fill=False, ec=INK, lw=2.0))
    ax.add_patch(plt.Rectangle((-1.15, 0.05), 2.3, 0.9, facecolor=LBLUE, edgecolor="none", zorder=0))
    ax.text(0, -0.25, "烧杯", fontsize=10, ha="center")
    # 玻璃棒（引流，靠三层滤纸）
    ax.plot([1.3, -0.4], [5.0, 1.5], color=INK, lw=1.6)
    ax.text(1.7, 5.0, "玻璃棒引流", fontsize=9)
    return save(fig, path)


def cylinders(path, value=42.0, figsize=(3.6, 5.2)):
    """量筒读数示意：视线与凹液面最低处相平（正确），并画一条俯视/仰视错误视线对比。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-2.2, 2.2); ax.set_ylim(-0.5, 6.0)
    # 量筒
    ax.plot([-0.9, -0.6], [0.0, 5.4], color=INK, lw=2.0)
    ax.plot([0.9, 0.6], [0.0, 5.4], color=INK, lw=2.0)
    ax.plot([-0.9, 0.9], [0.0, 0.0], color=INK, lw=2.0)
    # 刻度
    for k in range(0, 51, 10):
        yy = 0.3 + (5.1-0.3)*k/50
        ax.plot([-0.9, -0.6], [yy, yy], color=INK, lw=0.9)
        ax.text(-1.6, yy, "%d" % (k*2), fontsize=8, ha="right", va="center")
    # 正确读数凹液面
    yv = 0.3 + (5.1-0.3)*(value/100.0)
    ax.add_patch(plt.Rectangle((-0.75, 0.0), 1.4, yv, facecolor=LBLUE, edgecolor="none", zorder=0))
    ax.plot([-0.95, 0.95], [yv, yv], color=RED, lw=1.8)
    # 正确视线（平视，虚线延长到眼）
    ax.plot([-2.0, 0.0], [yv, yv], ls="--", color=RED, lw=1.2)
    ax.plot([0.0], [yv+0.4], "o", color=INK, ms=4)
    ax.text(0.2, yv+0.35, "视线与凹液面\n最低处相平", fontsize=9, color=RED)
    ax.text(0, 5.8, "%g mL" % value, fontsize=11, color=RED, ha="center")
    return save(fig, path)


def atom_structure(path, protons=8, neutrons=8, electrons=(2, 6), figsize=(4.8, 4.8)):
    """原子结构示意：中央原子核（质子+中子），外层电子层（按 electrons 每层数量）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.2, 3.2); ax.set_ylim(-3.2, 3.2)
    # 原子核
    ax.add_patch(Circle((0, 0), 0.6, facecolor="#cfe0f0", ec=INK, lw=1.6))
    # 核内质子(红)+中子(灰)
    np_ = protons; nn_ = neutrons
    tot = np_ + nn_
    for i in range(tot):
        ang = 2*math.pi*i/tot
        col = RED if i < np_ else GRAY
        ax.plot([0.3*math.cos(ang)], [0.3*math.sin(ang)], "o", color=col, ms=7)
    ax.text(0, 0, "+%d" % np_, fontsize=10, ha="center", va="center")
    # 电子层
    shells = list(electrons)
    r0 = 1.1
    for si, cnt in enumerate(shells):
        r = r0 + si*0.85
        ax.add_patch(Circle((0, 0), r, fill=False, ec=GRAY, lw=1.0, ls="--"))
        for j in range(cnt):
            ang = 2*math.pi*j/max(cnt,1) + si*0.5
            ax.plot([r*math.cos(ang)], [r*math.sin(ang)], "o", color=INK, ms=6)
    ax.text(0, -2.9, "质子 %d  中子 %d" % (protons, neutrons), fontsize=10, ha="center")
    ax.text(0, 2.95, "核外电子 %s（分层）" % str(electrons), fontsize=10, ha="center")
    return save(fig, path)


def electrolysis_water(path, figsize=(6.6, 3.6)):
    """电解水微观示意：水分子 H₂O 在通电条件下分解为 H₂ 与 O₂（体积比 2:1）。
       左侧若干 H₂O 分子（1 红 O + 2 灰/白 H），右侧生成 2 个 H₂ 分子 + 1 个 O₂ 分子。
       防泄题：仅示意微粒组成与比例，不标电极产物文字（由学生判断）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.5, 3.6); ax.set_ylim(-1.9, 1.9)
    rO, rH = 0.26, 0.15           # 氧、氢原子半径（H 与 O 轻微交叠，示意化学键）
    # 左侧：3 个 H2O（1 个 O + 2 个 H，夹角约 105°）
    for cx in (-3.05, -2.05, -1.05):
        for sgn in (-1, 1):
            ax.add_patch(Circle((cx + sgn * 0.30, 0.22), rH,
                                facecolor="white", ec=INK, lw=1.0, zorder=2))
        ax.add_patch(Circle((cx, 0), rO, facecolor=RED, ec=INK, lw=1.2, zorder=3))
    ax.text(-2.05, -1.55, r"通电前：3 个 $\mathrm{H_2O}$ 分子", fontsize=10, ha="center")

    # 通电箭头
    ax.annotate("", xy=(0.0, 0), xytext=(-0.62, 0),
                arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.4))
    ax.text(-0.3, -0.32, "通电", fontsize=9.5, ha="center", va="top")

    # 右侧：2 个 H2（白）+ 1 个 O2（红）
    for cx in (0.95, 1.75):
        ax.add_patch(Circle((cx - 0.16, 0), 0.17, facecolor="white", ec=INK, lw=1.1))
        ax.add_patch(Circle((cx + 0.16, 0), 0.17, facecolor="white", ec=INK, lw=1.1))
    ax.add_patch(Circle((2.95, 0.19), 0.23, facecolor=RED, ec=INK, lw=1.1))
    ax.add_patch(Circle((2.95, -0.19), 0.23, facecolor=RED, ec=INK, lw=1.1))
    ax.text(1.35, -1.55, r"通电后：2 个 $\mathrm{H_2}$ 分子 + 1 个 $\mathrm{O_2}$ 分子",
            fontsize=10, ha="center")
    ax.text(1.35, 1.35, r"$\mathrm{H_2}$        $\mathrm{H_2}$", fontsize=11, ha="center")
    ax.text(2.95, 1.15, r"$\mathrm{O_2}$", fontsize=11, ha="center")
    ax.text(-3.4, 1.35, r"体积比 $V(\mathrm{H_2}):V(\mathrm{O_2})=2:1$",
            fontsize=9.5, ha="left", color=RED)
    return save(fig, path)


def ionic_nacl(path, figsize=(6.8, 3.8)):
    """氯化钠（离子化合物）形成示意：Na 原子失电子→Na⁺，Cl 原子得电子→Cl⁻，
       异号电荷相互吸引形成离子化合物（晶格片段）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.6, 3.6); ax.set_ylim(-1.9, 1.9)
    # 左侧钠原子（核 + 3 层电子示意）
    ax.add_patch(Circle((-3.0, 0), 0.5, facecolor="#cfe0f0", ec=INK, lw=1.4))
    ax.add_patch(Circle((-3.0, 0), 0.28, fill=False, ec=GRAY, ls="--", lw=0.9))
    ax.plot([-3.0+0.28*math.cos(0.5)], [0.28*math.sin(0.5)], "o", color=INK, ms=4)
    ax.text(-3.0, -1.5, "Na 原子", fontsize=10, ha="center")
    # 失去的电子（飞向 Cl）
    ax.annotate("", xy=(-0.6, 0.2), xytext=(-2.4, 0.5),
                arrowprops=dict(arrowstyle="-|>", color=RED, lw=1.2))
    ax.plot([-1.2], [0.55], "o", color=RED, ms=5)
    # 右侧氯原子
    ax.add_patch(Circle((3.0, 0), 0.5, facecolor="#e7d6f0", ec=INK, lw=1.4))
    ax.text(3.0, -1.5, "Cl 原子", fontsize=10, ha="center")
    ax.text(0, 1.4, "Na 失去 1 个电子 → Na⁺    Cl 得到 1 个电子 → Cl⁻",
            fontsize=10, ha="center")
    # 下方晶格片段（Na+ Cl- 交替）
    ax.text(0, -1.0, "离子化合物（NaCl）", fontsize=10, ha="center", color=RED)
    for i, (cx, cy, t) in enumerate([(-1.2, -0.6, "Na⁺"), (0.0, -0.6, "Cl⁻"),
                                     (1.2, -0.6, "Na⁺"), (-0.6, 0.4, "Cl⁻"),
                                     (0.6, 0.4, "Na⁺")]):
        col = "#cfe0f0" if "Na" in t else "#e7d6f0"
        ax.add_patch(Rectangle((cx-0.22, cy-0.22), 0.44, 0.44, facecolor=col, ec=INK, lw=1.0))
        ax.text(cx, cy, t, fontsize=8, ha="center", va="center")
    return save(fig, path)


def solubility_curve(path, figsize=(5.8, 4.0)):
    """溶解度曲线题图：三条物质 A（陡升）、B（缓升）、C（略降），标注交点 P 与指定点 Q。
       坐标：横=温度/℃，纵=溶解度/g。供"比较溶解度/析出/配制"类题使用。"""
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.axhline(0, color="#ccc", lw=0.8); ax.axvline(0, color="#ccc", lw=0.8)
    # 三条曲线
    xs = list(range(0, 101, 10))
    # A：陡升
    yA = [20 + 2.2*x for x in xs]
    # B：缓升
    yB = [35 + 0.5*x for x in xs]
    # C：略降
    yC = [45 - 0.15*x for x in xs]
    ax.plot(xs, yA, color=INK, lw=1.8, label="A")
    ax.plot(xs, yB, color=RED, lw=1.8, label="B")
    ax.plot(xs, yC, color="#2a7", lw=1.8, label="C")
    ax.text(95, yA[-1]-6, "A", fontsize=11)
    ax.text(95, yB[-1]+2, "B", fontsize=11)
    ax.text(95, yC[-1]-8, "C", fontsize=11)
    # 交点 P（A、B 相交 ~ t=9）
    pt = 9; pA = 20+2.2*pt; pB = 35+0.5*pt
    ax.plot([pt], [pA], "o", color=INK, ms=5)
    ax.annotate("P", (pt, pA), textcoords="offset points", xytext=(6, 4), fontsize=10)
    # 指定点 Q
    qt, qy = 60, 35+0.5*60
    ax.plot([qt], [qy], "o", color=RED, ms=5)
    ax.annotate("Q", (qt, qy), textcoords="offset points", xytext=(6, 4), fontsize=10, color=RED)
    ax.set_xlabel("温度 / ℃", fontsize=11); ax.set_ylabel("溶解度 / g", fontsize=11)
    ax.set_xlim(-3, 103); ax.set_ylim(0, max(yA)+10)
    ax.set_aspect("auto"); ax.axis("off")
    return save(fig, path)


# ===========================================================================
# 生物：结构 / 曲线 / 遗传 / 探究 / 食物链
# ===========================================================================
def cell_structure(path, kind="plant", figsize=(5.0, 4.2)):
    """细胞模式图：kind='animal' 动物细胞（细胞膜/细胞核/细胞质/线粒体）；
       kind='plant' 植物细胞（加细胞壁/叶绿体/液泡）。结构中文标注。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.0, 3.0); ax.set_ylim(-2.6, 2.6)
    if kind == "plant":
        ax.add_patch(Rectangle((-2.2, -2.0), 4.4, 4.0, fill=False, ec=INK, lw=2.2))   # 细胞壁
        ax.add_patch(Rectangle((-2.0, -1.8), 4.0, 3.6, fill=False, ec=INK, lw=1.0))   # 细胞膜
        # 液泡（大）
        ax.add_patch(Circle((0.3, 0.2), 1.1, facecolor=LGREEN, ec=INK, lw=1.2))
        label(ax, (0.3, 0.2), "液泡", 0, 0, size=10)
        # 细胞核
        ax.add_patch(Circle((-1.1, -0.6), 0.55, facecolor="#f3e8c8", ec=INK, lw=1.4))
        label(ax, (-1.1, -0.6), "细胞核", -0.1, 0.0, size=9)
        # 叶绿体（绿椭圆）
        ax.add_patch(Ellipse((-1.2, 1.1), 0.9, 0.4, facecolor=LGREEN, ec=INK, lw=1.2))
        label(ax, (-1.2, 1.1), "叶绿体", 0, 0, size=9)
        # 线粒体
        ax.add_patch(Ellipse((1.4, -1.1), 0.7, 0.32, facecolor="#f6c6c6", ec=INK, lw=1.0))
        label(ax, (1.4, -1.1), "线粒体", 0, 0, size=9)
        ax.text(0, 2.4, "植物细胞模式图", fontsize=11, ha="center", fontweight="bold")
    else:
        ax.add_patch(Circle((0, 0), 2.0, fill=False, ec=INK, lw=2.2))                  # 细胞膜
        ax.add_patch(Circle((-0.4, 0.3), 0.6, facecolor="#f3e8c8", ec=INK, lw=1.4))   # 细胞核
        label(ax, (-0.4, 0.3), "细胞核", -0.05, 0.0, size=9)
        ax.add_patch(Ellipse((1.0, -0.7), 0.8, 0.36, facecolor="#f6c6c6", ec=INK, lw=1.0))
        label(ax, (1.0, -0.7), "线粒体", 0, 0, size=9)
        ax.text(0, 2.35, "动物细胞模式图", fontsize=11, ha="center", fontweight="bold")
    return save(fig, path)


def eye_structure(path, figsize=(5.2, 3.8)):
    """眼球结构模式图（水平切面）：角膜/晶状体/玻璃体/视网膜/虹膜/瞳孔，标注光线入眼路径。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-3.2, 3.2); ax.set_ylim(-2.2, 2.2)
    # 眼球外轮廓（略扁圆）
    ax.add_patch(Ellipse((0, 0), 5.6, 3.6, fill=False, ec=INK, lw=2.2))
    # 角膜（前方凸起）
    ax.plot([-2.8, -2.4], [0.9, 1.5], color=INK, lw=2.0)
    ax.plot([-2.8, -2.4], [-0.9, -1.5], color=INK, lw=2.0)
    # 晶状体（双凸，前方）
    ax.add_patch(Ellipse((-1.9, 0), 0.5, 1.3, facecolor="#dbeafe", ec=INK, lw=1.6))
    label(ax, (-1.9, 0), "晶状体", -0.05, 0, size=9)
    # 虹膜/瞳孔
    ax.plot([-2.4, -2.4], [0.55, -0.55], color=INK, lw=1.4)
    # 玻璃体
    ax.text(0.6, -1.2, "玻璃体", fontsize=9)
    # 视网膜（后方内壁）
    ax.plot([2.6, 2.2], [0.9, 1.4], color=RED, lw=3.0)
    ax.plot([2.6, 2.2], [-0.9, -1.4], color=RED, lw=3.0)
    label(ax, (2.6, 0), "视网膜", 0.05, 0, size=9, color=RED)
    # 入眼光线
    ax.plot([-3.0, -1.9], [0.6, 0.2], color=RED, lw=1.2)
    ax.plot([-1.9, 2.4], [0.2, 0.0], color=RED, lw=1.2)
    ax.text(-2.9, 1.0, "光线", fontsize=9, color=RED)
    ax.text(0, 2.1, "眼球结构模式图", fontsize=11, ha="center", fontweight="bold")
    return save(fig, path)


def digestive_system(path, figsize=(7.8, 3.6)):
    """消化系统组成：消化道（口腔→食道→胃→小肠→大肠→肛门）+ 消化腺（唾液腺/肝/胰）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.5, 8.4); ax.set_ylim(-1.4, 2.2)
    # 口腔
    ax.add_patch(Rectangle((0.2, 0.6), 0.9, 0.7, fill=False, ec=INK, lw=1.6))
    ax.text(0.65, 1.5, "口腔", fontsize=10, ha="center")
    # 食道
    ax.plot([1.1, 1.4], [0.6, -0.6], color=INK, lw=2.0)
    # 胃（袋状）
    ax.add_patch(Ellipse((2.1, -0.4), 1.1, 0.9, fill=False, ec=INK, lw=1.8))
    ax.text(2.1, -0.4, "胃", fontsize=10, ha="center", va="center")
    # 小肠（蜿蜒）
    xs = [2.7, 3.2, 3.0, 3.6, 3.3, 3.9, 3.6]; ys = [-0.6, -0.2, -0.9, -0.4, -1.0, -0.5, -1.0]
    ax.plot(xs, ys, color=INK, lw=2.0)
    ax.text(3.3, 0.4, "小肠", fontsize=10, ha="center")
    # 大肠
    ax.plot([3.9, 5.6], [-1.0, -0.6], color=INK, lw=2.2)
    ax.plot([5.6, 5.6], [-0.6, 0.6], color=INK, lw=2.2)
    ax.plot([5.6, 6.4], [0.6, 0.4], color=INK, lw=2.0)            # 肛门
    ax.text(5.6, -1.3, "大肠", fontsize=10, ha="center")
    ax.text(6.5, 0.9, "肛门", fontsize=9, ha="center")
    # 消化腺：唾液腺(口上)、肝(胃下)、胰(胃右)
    ax.add_patch(Circle((0.65, 2.0), 0.3, fill=False, ec=INK, lw=1.2))
    ax.text(0.65, 2.4, "唾液腺", fontsize=9, ha="center")
    ax.add_patch(Circle((2.1, -1.6), 0.35, fill=False, ec=INK, lw=1.2))
    ax.text(2.1, -2.1, "肝", fontsize=9, ha="center")
    ax.add_patch(Circle((3.0, -1.6), 0.3, fill=False, ec=INK, lw=1.2))
    ax.text(3.0, -2.1, "胰", fontsize=9, ha="center")
    ax.text(4.0, 2.0, "消化系统组成", fontsize=11, ha="center", fontweight="bold")
    return save(fig, path)


def photosynthesis_curve(path, kind="light", figsize=(5.6, 3.8)):
    """光合速率曲线：kind='light' 光照强度（先升后饱和）；kind='co2' CO₂浓度（先升后平台）；
       kind='temp' 温度（钟形，最适约 25~30℃）。标注拐点/最适点。"""
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.axhline(0, color="#ccc", lw=0.8); ax.axvline(0, color="#ccc", lw=0.8)
    x = list(range(0, 101))
    if kind == "light":
        y = [min(0.9*(1-math.exp(-0.05*i)), 0.9) for i in x]
        ax.set_xlabel("光照强度", fontsize=11); lbl="光合作用强度"
    elif kind == "co2":
        y = [min(0.9*(1-math.exp(-0.06*i)), 0.9) for i in x]
        ax.set_xlabel(r"$\mathrm{CO_2}$ 浓度", fontsize=11); lbl="光合作用强度"
    else:
        # 钟形：最适 28℃
        y = [0.95*math.exp(-((i-28)**2)/(2*12**2)) for i in x]
        ax.set_xlabel("温度 / ℃", fontsize=11); lbl="光合作用强度"
    ax.plot(x, y, color=INK, lw=1.8)
    if kind == "temp":
        ax.plot([28], [0.95], "o", color=RED, ms=5)
        ax.annotate("最适", (28, 0.95), textcoords="offset points", xytext=(6, 4), fontsize=10, color=RED)
    else:
        ax.annotate("饱和点", (80, 0.9), textcoords="offset points", xytext=(0, 6), fontsize=10, color=RED)
    ax.set_ylabel(lbl, fontsize=11)
    ax.set_xlim(-3, 103); ax.set_ylim(0, 1.1)
    ax.set_aspect("auto"); ax.axis("off")
    return save(fig, path)


def enzyme_curve(path, kind="temp", figsize=(5.6, 3.8)):
    """酶活性曲线：kind='temp' 温度（钟形，最适约 37℃，高温失活归零）；
       kind='ph' pH（钟形，胃蛋白酶最适≈2、唾液淀粉酶≈7，极端失活）。标注最适与失活区。"""
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.axhline(0, color="#ccc", lw=0.8); ax.axvline(0, color="#ccc", lw=0.8)
    x = list(range(0, 101))
    if kind == "temp":
        y = [ (0.95*math.exp(-((i-37)**2)/(2*10**2))) if i <= 60 else 0.0 for i in x]
        ax.set_xlabel("温度 / ℃", fontsize=11); xbest = 37
    else:
        # pH：以胃蛋白酶为例，最适≈2（这里取 2）；同时示意唾液淀粉酶≈7 的另一种（不画，仅标注）
        y = [ (0.95*math.exp(-((i-2)**2)/(2*1.6**2))) if 0 < i < 8 else 0.0 for i in x]
        ax.set_xlabel("pH", fontsize=11); xbest = 2
    ax.plot(x, y, color=INK, lw=1.8)
    ax.plot([xbest], [0.95], "o", color=RED, ms=5)
    ax.annotate("最适", (xbest, 0.95), textcoords="offset points", xytext=(6, 4), fontsize=10, color=RED)
    ax.annotate("失活", (95 if kind=='temp' else 95, 0.0), textcoords="offset points",
                xytext=(-10, 6), fontsize=10, color=RED)
    ax.set_ylabel("酶活性", fontsize=11)
    ax.set_xlim(-3, 103); ax.set_ylim(0, 1.1)
    ax.set_aspect("auto"); ax.axis("off")
    return save(fig, path)


def punnett(path, p1="Aa", p2="Aa", figsize=(5.2, 4.2)):
    """遗传图解（Punnett 方格）：亲代 p1 × p2（如 Aa × Aa），展示配子与子代基因型、
       表型比例。显性性状以 A 表示。返回生成路径。"""
    import itertools
    def gametes(geno):
        # 仅处理单基因杂合/纯合（形如 Aa / AA / aa）
        g = sorted(set(geno))
        return [a for a in g for _ in (1,)] if len(set(geno)) == 1 else list(geno)
    g1 = list(p1); g2 = list(p2)
    # 生成配子（每对等位基因拆成两配子）
    def split_gametes(geno):
        # 假定形如 "Aa"（两等位）
        return [geno[0], geno[1]]
    pg1 = split_gametes(p1); pg2 = split_gametes(p2)
    # 子代
    cells = {}
    for a in pg1:
        for b in pg2:
            key = "".join(sorted([a, b]))
            cells[key] = cells.get(key, 0) + 1
    total = sum(cells.values())
    # 表型（显性 A 存在即显性）
    pheno = {}
    for k, c in cells.items():
        dom = "显性" if "A" in k else "隐性"
        pheno[dom] = pheno.get(dom, 0) + c
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.5, 4.6); ax.set_ylim(-0.5, 4.6)
    # 网格 2x2（含配子行/列）
    xs = [1, 2, 3]; ys = [3, 2, 1]
    # 外框
    ax.add_patch(Rectangle((1, 1), 2, 2, fill=False, ec=INK, lw=2.0))
    ax.plot([2, 2], [1, 3], color=INK, lw=1.2); ax.plot([1, 3], [2, 2], color=INK, lw=1.2)
    # 配子标签
    for i, g in enumerate(pg1):
        ax.text(1.5 + 0.0, 3.4 - i*1.0, g, fontsize=13, ha="center")
    for j, g in enumerate(pg2):
        ax.text(0.6 + j*1.0, 2.5, g, fontsize=13, ha="center")
    # 子代格子
    order = [(pg1[0], pg2[0]), (pg1[0], pg2[1]), (pg1[1], pg2[0]), (pg1[1], pg2[1])]
    for idx, (a, b) in enumerate(order):
        cx = 1.5 + (idx % 2)*1.0; cy = 2.5 - (idx // 2)*1.0
        key = "".join(sorted([a, b]))
        ax.text(cx, cy, key, fontsize=13, ha="center", va="center")
    ax.text(2.0, 4.1, "亲代  %s × %s" % (p1, p2), fontsize=11, ha="center", fontweight="bold")
    # 比例
    gp = " : ".join("%s(%d)" % (k, v) for k, v in sorted(cells.items()))
    pp = " : ".join("%s(%d)" % (k, v) for k, v in sorted(pheno.items()))
    ax.text(2.0, 0.2, "基因型  %s\n表型  %s" % (gp, pp), fontsize=9.5, ha="center", va="center")
    return save(fig, path)


def germination(path, figsize=(7.4, 3.6)):
    """种子萌发条件探究三装置：(1) 适量水+空气+适宜温度（萌发）；(2) 无水；
       (3) 完全浸没（无空气）或低温。用三套容器示意，标注 (1)(2)(3)。防泄题：不标结论。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.5, 7.6); ax.set_ylim(-0.5, 3.4)
    setups = [
        ("适量水", LBLUE, True, "①"),
        ("无水", "#f3f4f6", False, "②"),
        ("完全浸没(无空气)", LBLUE, True, "③"),
    ]
    for i, (lab, col, has_water, tag) in enumerate(setups):
        cx = i * 2.5
        # 容器
        ax.add_patch(Rectangle((cx, 0.3), 1.4, 1.8, fill=False, ec=INK, lw=1.8))
        if has_water and "浸没" not in lab:
            ax.add_patch(plt.Rectangle((cx+0.05, 0.35), 1.3, 0.5, facecolor=col, edgecolor="none", zorder=0))
        elif "浸没" in lab:
            ax.add_patch(plt.Rectangle((cx+0.05, 0.35), 1.3, 1.5, facecolor=col, edgecolor="none", zorder=0))
            ax.add_patch(plt.Rectangle((cx+0.05, 1.8), 1.3, 0.1, facecolor=LYEL, edgecolor="none", zorder=1))  # 油层
        # 种子
        ax.add_patch(Ellipse((cx+0.7, 0.6), 0.3, 0.18, fill=False, ec=INK, lw=1.2))
        ax.text(cx+0.7, 0.3, tag, fontsize=13, ha="center", color=RED)
        ax.text(cx+0.7, 2.4, lab, fontsize=9.5, ha="center")
    ax.text(3.8, 3.1, "种子萌发条件探究装置", fontsize=11, ha="center", fontweight="bold")
    return save(fig, path)


def food_chain(path, chains=None, figsize=(7.0, 3.4)):
    """食物链/食物网：nodes 为层级（生产者→初级消费者→次级消费者...），用箭头连接。
       chains 形如 [["草","兔","狐"],["草","鼠","蛇","鹰"]]，自动布局成网。"""
    chains = chains or [["草", "虫", "蛙", "蛇"], ["草", "鼠", "蛇"]]
    # 收集所有节点与各层
    layers = {}
    for ch in chains:
        for depth, node in enumerate(ch):
            layers.setdefault(depth, set()).add(node)
    depths = sorted(layers)
    pos = {}
    for d, nodes in zip(depths, [sorted(layers[x]) for x in depths]):
        n = len(nodes)
        for k, node in enumerate(nodes):
            x = d * 2.2
            y = (k - (n-1)/2.0) * 1.4
            pos[node] = (x, y)
    fig, ax = _new_fig(figsize)
    allx = [p[0] for p in pos.values()]; ally = [p[1] for p in pos.values()]
    ax.set_xlim(min(allx)-1.2, max(allx)+1.2)
    ax.set_ylim(min(ally)-1.2, max(ally)+1.2)
    # 箭头（沿节点连线方向，从圆周到圆周，避免线尾在圆内形成"假箭头"）
    R = 0.5
    for ch in chains:
        for a, b in zip(ch, ch[1:]):
            pa, pb = pos[a], pos[b]
            dx, dy = pb[0] - pa[0], pb[1] - pa[1]
            L = math.hypot(dx, dy) or 1.0
            ux, uy = dx / L, dy / L
            ax.annotate("", xy=(pb[0] - ux * R, pb[1] - uy * R),
                        xytext=(pa[0] + ux * R, pa[1] + uy * R),
                        arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.4,
                                        shrinkA=0, shrinkB=0))
    # 节点
    for node, (x, y) in pos.items():
        ax.add_patch(Circle((x, y), 0.45, facecolor="#eaf2fb", ec=INK, lw=1.4))
        ax.text(x, y, node, fontsize=10, ha="center", va="center")
    ax.text(0, max(ally)+0.9, "食物链（网）", fontsize=11, ha="center", fontweight="bold")
    return save(fig, path)


# ---------------------------------------------------------------------------
# 命令行示例（生成全部 demo 图到指定目录）
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    os.makedirs(out, exist_ok=True)
    d = os.path.join(out, "science_figs_demo")
    os.makedirs(d, exist_ok=True)
    fns = [
        light_plane_mirror, light_lens, light_refraction, light_pinhole,
        lambda p: force_diagram(p, "horizontal"),
        lambda p: force_diagram(p, "incline"),
        lambda p: force_diagram(p, "in_water"),
        lambda p: force_diagram(p, "balanced"),
        lambda p: force_diagram(p, "lift"),
        lambda p: force_diagram(p, "free_fall"),
        ramp_car, lambda p: balance_cylinder(p, 82.4, 40.0), boiling_apparatus,
        optical_bench, lambda p: phase_curve(p, "melt"),
        lambda p: phase_curve(p, "boil"), lambda p: phase_curve(p, "freeze"),
        lambda p: motion_graph(p, "st"), lambda p: motion_graph(p, "vt"),
        lambda p: electroscope(p, True), lambda p: electroscope(p, False),
        lambda p: gas_setup(p, "O2"), lambda p: gas_setup(p, "CO2"), filter_setup,
        lambda p: cylinders(p, 42.0), lambda p: atom_structure(p, 8, 8, (2, 6)),
        electrolysis_water, ionic_nacl, solubility_curve,
        lambda p: cell_structure(p, "plant"), lambda p: cell_structure(p, "animal"),
        eye_structure, digestive_system,
        lambda p: photosynthesis_curve(p, "light"),
        lambda p: photosynthesis_curve(p, "temp"),
        lambda p: enzyme_curve(p, "temp"), lambda p: enzyme_curve(p, "ph"),
        lambda p: punnett(p, "Aa", "Aa"), germination,
        lambda p: food_chain(p, [["草", "兔", "狐"], ["草", "鼠", "蛇", "鹰"]]),
    ]
    for i, fn in enumerate(fns, 1):
        p = os.path.join(d, "fig_%02d.png" % i)
        try:
            fn(p)
            print("OK", p)
        except Exception as e:
            print("FAIL", p, e)
