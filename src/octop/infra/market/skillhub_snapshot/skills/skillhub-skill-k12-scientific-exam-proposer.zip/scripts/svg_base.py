# -*- coding: utf-8 -*-
"""
教学用图生成助手 · SVG 基础构件（A 类精确示意图）
=================================================
用于程序化生成「白底黑线、中文标注、可编辑」的精确示意图。
所有中文标注用系统字体渲染（SVG 由浏览器 / WPS / Inkscape 按 font-family 取本地字体），
绝不交给生图模型。老师拿到 .svg 后可直接改字、改颜色、改线宽。

设计约定（遵循 SKILL.md 做法要求）：
    - 默认白底（#ffffff）、黑线（#000000）
    - 主线粗（2~3）、辅助线虚、标注细（1~1.5）
    - 中文字体默认宋体（SimSun），兼顾印刷与试卷

用法：
    from svg_base import doc, text, line, arrow, rect, circle, save
    body = text(100, 50, "叶绿体") + arrow(50, 200, 150, 120)
    save("examples/test.svg", doc(400, 300, body))
"""

# ----------------------------------------------------------------------
# 箭头 / 标记定义（defs）。黑色实心箭头最常用，另备红色箭头用于强调方向。
# ----------------------------------------------------------------------
_DEFS = """
  <defs>
    <marker id="arrow" markerWidth="12" markerHeight="12" refX="8" refY="3.5"
            orient="auto" markerUnits="strokeWidth">
      <path d="M0,0 L9,3.5 L0,7 Z" fill="#000000"/>
    </marker>
    <marker id="arrow-red" markerWidth="12" markerHeight="12" refX="8" refY="3.5"
            orient="auto" markerUnits="strokeWidth">
      <path d="M0,0 L9,3.5 L0,7 Z" fill="#d62728"/>
    </marker>
    <marker id="arrow-white" markerWidth="12" markerHeight="12" refX="8" refY="3.5"
            orient="auto" markerUnits="strokeWidth">
      <path d="M0,0 L9,3.5 L0,7 Z" fill="#ffffff"/>
    </marker>
  </defs>
"""

# 常用中文字体回退链：宋体优先（印刷/试卷通用），无则黑体，再退回衬线。
CN_FONT = "SimSun, STSong, SimHei, 'Microsoft YaHei', serif"


def escape(s):
    """转义 SVG 文本中的特殊字符，避免破坏 XML。"""
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def doc(width, height, body, bg="#ffffff", font_family=CN_FONT):
    """组装完整 SVG 文档。body 为各构件字符串拼接。"""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">\n'
        f'  <rect width="100%" height="100%" fill="{bg}"/>\n'
        f'{_DEFS}\n'
        f'  <g font-family="{font_family}">\n{body}\n  </g>\n'
        '</svg>'
    )


def text(x, y, s, size=16, color="#000000", anchor="middle",
         weight="normal", italic=False):
    """文字标注。anchor: start|middle|end。"""
    style = ""
    if weight != "normal" or italic:
        style = f' font-style="italic"' if italic else ""
        if weight != "normal":
            style += f' font-weight="{weight}"'
    return (f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" '
            f'text-anchor="{anchor}"{style}>{escape(s)}</text>')


def line(x1, y1, x2, y2, stroke="#000000", width=2, dash=None):
    """直线。dash 如 "6,4" 表示虚线（辅助线）。"""
    da = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="{stroke}" stroke-width="{width}"{da}/>')


def arrow(x1, y1, x2, y2, stroke="#000000", width=2, color=None):
    """带箭头直线。color 指定 'red' 用红色箭头，'white' 用白色。"""
    marker = "url(#arrow)"
    if color == "red":
        marker = "url(#arrow-red)"
    elif color == "white":
        marker = "url(#arrow-white)"
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="{stroke}" stroke-width="{width}" marker-end="{marker}"/>')


def rect(x, y, w, h, stroke="#000000", width=2, fill="none", rx=0, dash=None):
    rx_attr = f' rx="{rx}"' if rx else ""
    da = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" '
            f'stroke="{stroke}" stroke-width="{width}"{rx_attr}{da}/>')


def circle(cx, cy, r, stroke="#000000", width=2, fill="none"):
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}" '
            f'stroke="{stroke}" stroke-width="{width}"/>')


def ellipse(cx, cy, rx, ry, stroke="#000000", width=2, fill="none"):
    return (f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{fill}" '
            f'stroke="{stroke}" stroke-width="{width}"/>')


def polyline(points, stroke="#000000", width=2, fill="none", dash=None, closed=False):
    pts = " ".join(f"{x},{y}" for x, y in points)
    tag = "polygon" if closed else "polyline"
    da = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<{tag} points="{pts}" fill="{fill}" stroke="{stroke}" '
            f'stroke-width="{width}"{da}/>')


def polygon(points, stroke="#000000", width=2, fill="none"):
    return polyline(points, stroke, width, fill, closed=True)


def arc(cx, cy, r, a0, a1, stroke="#000000", width=2, dash=None):
    """圆弧路径。a0/a1 为角度（度），0°在右侧，逆时针为正。"""
    import math
    x0 = cx + r * math.cos(math.radians(a0))
    y0 = cy - r * math.sin(math.radians(a0))
    x1 = cx + r * math.cos(math.radians(a1))
    y1 = cy - r * math.sin(math.radians(a1))
    large = 1 if abs(a1 - a0) > 180 else 0
    sweep = 1 if a1 > a0 else 0
    da = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<path d="M{x0:.2f},{y0:.2f} A{r},{r} 0 {large},{sweep} '
            f'{x1:.2f},{y1:.2f}" fill="none" stroke="{stroke}" '
            f'stroke-width="{width}"{da}/>')


def angle_mark(x, y, r, a0, a1, stroke="#000000", width=1.5):
    """在 (x,y) 处画一段角度弧标记。"""
    return arc(x, y, r, a0, a1, stroke=stroke, width=width)


def leader(x1, y1, x2, y2, stroke="#000000", width=1, blank=False):
    """指引线：从图元指向空白标注处。blank=True 时末端留短横线供填写。"""
    s = line(x1, y1, x2, y2, stroke=stroke, width=width)
    if blank:
        s += line(x2, y2 - 8, x2 + 40, y2 - 8, stroke=stroke, width=width)
    return s


def save(path, svg):
    """写盘。自动创建父目录。"""
    import os
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(svg)
    return path


if __name__ == "__main__":
    # 最小自测：生成一个含中英文标注与箭头的示例
    body = (
        text(200, 40, "示例图（白底黑线·可编辑）", size=20, weight="bold")
        + rect(60, 80, 120, 80, rx=8)
        + text(120, 125, "框 A")
        + circle(320, 120, 45)
        + text(320, 125, "圆 B")
        + arrow(180, 120, 275, 120, width=2.5)
        + text(228, 105, "方向→", size=12)
        + line(60, 220, 360, 220, dash="6,4", width=1.5)
        + text(210, 240, "虚线=辅助线", size=12, color="#555555")
    )
    save("examples/_svgbase_demo.svg", doc(400, 280, body))
    print("已生成 examples/_svgbase_demo.svg")
