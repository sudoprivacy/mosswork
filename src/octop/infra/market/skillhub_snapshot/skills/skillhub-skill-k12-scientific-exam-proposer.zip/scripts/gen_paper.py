#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
gen_paper.py —— K12 科学命题 skill 的试卷生成器（零依赖，仅用标准库）。

功能：
  1. 把一份结构化的试卷 spec（JSON）渲染为可打印的 Word .docx。
  2. 题干/选项中的数理化公式用 LaTeX 子集书写（以 $...$ 包裹），
     自动转换为 Word 原生公式编辑器格式（OMML），双击即可在 Word 内编辑。
  3. 支持版式参数：A4 / A3，竖排(portrait) / 横排(landscape)，分栏 1/2/3 栏。
     默认 A4 竖排、不分栏（与 skill 约定一致）。
  4. 主观题（简答/论述/解答）按题型自动留"答题线"空间（可逐题覆盖）；
     语文"作文"渲染标准方格（作文纸），且作文段强制整页宽（即便正文分栏也独占整宽）。

用法：
  python gen_paper.py spec.json output.docx
  python gen_paper.py spec.json            # 输出到 spec 同目录
  echo '<json>' | python gen_paper.py - out.docx

spec 结构（详见 skill 内 assets/sample_spec.json）：
{
  "title": "试卷标题",
  "meta":  "学校______  班级______  姓名______  学号______   时长：90 分钟   满分：100 分",
  "notice": "注意事项：...（可多行，用 \\n 分隔）",
  "layout": {"page":"A4", "orient":"portrait", "columns":1, "col_space":425},
  "sections": [
     {"title":"一、选择题（每小题 3 分，共 18 分）",
      "type":"single",                       # single 选择 / fill 填空 / short 简答 / solve 解答 / essay 论述 / composition 作文
      "items":[
        {"stem":"解方程 $x^2-5x+6=0$，其根为（  ）",
         "options":["A. $x=2$ 或 $x=3$","B. $x=-2$ 或 $x=-3$","C. $x=1$ 或 $x=6$","D. $x=-1$ 或 $x=-6$"],
         "answer":"A"},
        ...
      ]},
     {"title":"三、解答题（共 40 分）", "type":"solve",   # 自动每题留 6 行答题线
      "items":[{"stem":"解方程 $(x+3)^2=4$。", "answer":"$x=-1$ 或 $x=-5$"}]},
     {"title":"七、作文（50 分）", "type":"composition",  # 强制整页宽 + 方格
      "items":[{"prompt":"题目：________  以《那一刻，我长大了》为题，写一篇不少于 600 字的文章。",
                "grid_rows":30}]},            # grid_rows=30 → 600 字方格
     {"title":"参考答案（教师专用）", "answer_key":true,
      "items":[{"stem":"1. A   2. C   3. B ...", "options":[]}]}
  ]
}
插图支持（几何图/树状图/情境图/实验装置图/光路图/曲线图等）：
  - 任意 item 可加 "image":"路径.png"（绝对或相对 spec 所在目录的路径），
    生成时自动居中嵌入试卷（题后图前标准卷式），passage 正文块同样支持挂图。
    可选 "image_width":8.0 指定**总显示宽度**（厘米，默认 8.0，按原图比例换算高度）。
  - **多图并排**：image 可写成字符串列表，如
    "image":["fig/甲.png","fig/乙.png"]，渲染为甲/乙并排（总宽按 image_width 均分），
    适合"如图甲、乙"类题；可加 "image_caption":"图甲：××  图乙：××" 作题图说明。
  - **图—题绑定自检**（初中理科防事故）：stem 含"如图/图甲/装置图/光路图"等关键词
    但该项无 image，或 image 路径找不到——生成时向 stderr 告警；spec 加
    "strict_figures":true 则直接报错退出（CI/批量出卷时强烈建议开启）。
  - 图片由出卷方自备：可用本 skill 附带的 draw_geometry.py / draw_science_figs.py
    （需 matplotlib）精确绘制，也可用绘图软件/扫描件/AI 生成。
    gen_paper.py 仅用标准库嵌入，零额外依赖；每张图分配唯一 docPr 编号，多图不冲突。
  - 例（单图）：{"stem":"如图，求 OC 的长。", "image":"fig/chord.png", "image_width":7.5}
  - 例（多图+说明）：{"stem":"如图甲、乙，回答问题。",
            "image":["fig/甲.png","fig/乙.png"], "image_width":14.0,
            "image_caption":"图甲：××装置   图乙：××现象"}

阅读正文与排版增强：
  - section 加 "number_start":N → 该大题从 N 开始编号（默认 1），实现整卷连续题号
    （如选择 1-10、填空 11-18、解答 19-24）；题干一律不手写题号，避免双编号。
  - item 加 "passage": true → 阅读正文块：不自动编号、两端对齐、独立成段，
    段后自动补空段，与后续题目明确换行分隔（阅读理解的正文部分用）；
  - section 加 "options_inline": true/false → 选择题选项横向排列（默认 single 题型横排，省纸）；
    选项过长（合计超 64 字符）或含换行时自动回退竖排；
  - 题干段前距已加大（约 6pt），题与题之间分隔清晰。
答题空间规则：
  - type=single/fill/composition 默认 0 行；type=short 默认 4 行；solve 默认 6 行；essay 默认 8 行。
  - 可用 section 级 "answer_lines":N 覆盖整段，或 question 级 "space":N 覆盖单题。
  - 作文用 grid_rows（默认 20 行=400 字；25→500字，30→600字，40→800字）。

公式语法（LaTeX 子集，足够覆盖中小学数理化）：
  $x^2$ 上标   $a_1$ 下标   $\frac{a}{b}$ 分数   $\sqrt{x}$ 根号
  $\pm$ $\times$ $\div$ $\cdot$ $\leq$ $\geq$ $\neq$ $\approx$ $\equiv$
  $\in$ $\forall$ $\exists$ $\sum$ $\prod$ $\infty$ $\angle$ $\perp$ $\parallel$ $\triangle$
  $\alpha \beta \gamma \Delta \theta \pi \lambda \mu \rho \sigma \phi \omega$ 等希腊字母
  $\sin \cos \tan \log \ln \lim$ 函数（自动正体）
  $\text{速度}$ 中文/正体文本   $\{ \}$ 分组   $( )$ 括号（直接作普通符号）
"""
import sys, json, zipfile, os, re, struct

_CTRL = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f]')  # 非法 XML 控制字符

# ---------------------------------------------------------------------------
# 1. LaTeX 子集 -> OMML 转换器
# ---------------------------------------------------------------------------
GREEK = {
    'alpha':'α','beta':'β','gamma':'γ','delta':'δ','epsilon':'ε','varepsilon':'ε',
    'zeta':'ζ','eta':'η','theta':'θ','vartheta':'ϑ','iota':'ι','kappa':'κ',
    'lambda':'λ','mu':'μ','nu':'ν','xi':'ξ','omicron':'ο','pi':'π',
    'rho':'ρ','sigma':'σ','varsigma':'ς','tau':'τ','upsilon':'υ','phi':'φ',
    'varphi':'φ','chi':'χ','psi':'ψ','omega':'ω',
    'Gamma':'Γ','Delta':'Δ','Theta':'Θ','Lambda':'Λ','Xi':'Ξ','Pi':'Π',
    'Sigma':'Σ','Phi':'Φ','Psi':'Ψ','Omega':'Ω',
    'nabla':'∇','partial':'∂','infty':'∞',
}
SYMBOL = {
    'pm':'±','mp':'∓','times':'×','div':'÷','cdot':'·','ast':'∗','star':'☆','circ':'∘',
    'leq':'≤','le':'≤','geq':'≥','ge':'≥','ne':'≠','neq':'≠','approx':'≈','equiv':'≡',
    'sim':'∼','simeq':'≃','propto':'∝','cong':'≅',
    'in':'∈','notin':'∉','ni':'∋','subset':'⊂','supset':'⊃','subseteq':'⊆','supseteq':'⊇',
    'cup':'∪','cap':'∩','emptyset':'∅','forall':'∀','exists':'∃','nexists':'∄',
    'angle':'∠','perp':'⊥','parallel':'∥','triangle':'△','square':'□','deg':'°',
    'rightarrow':'→','leftarrow':'←','Rightarrow':'⇒','Leftarrow':'⇐',
    'leftrightarrow':'↔','Leftrightarrow':'⇔','to':'→','mapsto':'↦','uparrow':'↑',
    'sum':'∑','prod':'∏','int':'∫','oint':'∮','lim':'lim','log':'log','ln':'ln',
}
FUNCS = {'sin','cos','tan','cot','sec','csc','log','ln','lg','lim','exp','det','gcd','mod'}
SPACE_CMDS = {'!',',',';',':','quad','qquad',' ','\\',';'}

def esc(s):
    s = _CTRL.sub('', s)  # 清洗非法 XML 控制字符（如换页符），避免生成的 docx 损坏
    return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def omml_text(ch, sty=None):
    if sty:
        return '<m:r><m:rPr><m:sty m:val="%s"/></m:rPr><m:t xml:space="preserve">%s</m:t></m:r>' % (sty, esc(ch))
    return '<m:r><m:t xml:space="preserve">%s</m:t></m:r>' % esc(ch)

def omml_func(name):
    return '<m:r><m:rPr><m:sty m:val="f"/></m:rPr><m:t xml:space="preserve">%s</m:t></m:r>' % esc(name)

def run_for_token(buf):
    if buf.isdigit():
        return omml_text(buf, 'p')          # 数字正体
    if buf in FUNCS:
        return omml_func(buf)               # 函数名正体
    return omml_text(buf)                    # 字母默认数学斜体

def tokenize(s):
    toks = []
    i = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c == '\\':
            j = i + 1
            if j < n and not s[j].isalpha():
                toks.append(('CMD', s[j])); i = j + 1; continue
            j = i + 1
            while j < n and s[j].isalpha():
                j += 1
            toks.append(('CMD', s[i+1:j])); i = j; continue
        if c == '{':
            toks.append(('BRACE','{')); i += 1; continue
        if c == '}':
            toks.append(('BRACE','}')); i += 1; continue
        if c == '^':
            toks.append(('SUP',None)); i += 1; continue
        if c == '_':
            toks.append(('SUB',None)); i += 1; continue
        toks.append(('CHAR', c)); i += 1
    return toks

def apply_supsub(toks, pos, base):
    while pos[0] < len(toks) and toks[pos[0]][0] in ('SUP','SUB'):
        kind = toks[pos[0]][0]; pos[0] += 1
        exp = parse_group(toks, pos)          # 返回内容字符串
        if kind == 'SUP':
            base = ['<m:sSup><m:e>',''.join(base),'</m:e><m:sup>',exp,'</m:sup></m:sSup>']
        else:
            base = ['<m:sSub><m:e>',''.join(base),'</m:e><m:sub>',exp,'</m:sub></m:sSub>']
    return base

def parse_group(toks, pos):
    """读取 { ... } 分组内容，返回 OMML 内容字符串；若下一个不是 { 则取单个符号。"""
    if pos[0] < len(toks) and toks[pos[0]][0] == 'BRACE' and toks[pos[0]][1] == '{':
        pos[0] += 1
        inner = parse_expr(toks, pos, '}')
        if pos[0] < len(toks) and toks[pos[0]][0] == 'BRACE' and toks[pos[0]][1] == '}':
            pos[0] += 1
        return ''.join(inner)
    # 无花括号：取单个 atom
    if pos[0] < len(toks):
        saved = pos[0]
        a = parse_expr(toks, pos, None)
        # 仅取第一个 atom（parse_expr 可能吃掉多个，这里只想要一个）
        pos[0] = saved
        t = toks[pos[0]]
        if t[0] == 'CHAR':
            pos[0] += 1
            return run_for_token(t[1]) if t[1].isalnum() else omml_text(t[1])
        if t[0] == 'CMD':
            pos[0] += 1
            name = t[1]
            if name in SYMBOL: return omml_text(SYMBOL[name])
            if name in GREEK: return omml_text(GREEK[name])
            if name in FUNCS: return omml_func(name)
            return omml_text('\\'+name)
    return ''

def parse_text_group(toks, pos):
    """\\text{...} 取原始文本。"""
    if pos[0] < len(toks) and toks[pos[0]][0] == 'BRACE' and toks[pos[0]][1] == '{':
        pos[0] += 1
        buf = ''
        while pos[0] < len(toks):
            t = toks[pos[0]]
            if t[0] == 'BRACE' and t[1] == '}':
                pos[0] += 1; break
            if t[0] == 'CHAR':
                buf += t[1]
            elif t[0] == 'CMD':
                buf += '\\'+t[1]
            pos[0] += 1
        return buf
    return ''

def parse_expr(toks, pos, stop):
    out = []
    while pos[0] < len(toks):
        t = toks[pos[0]]
        if t[0] == 'BRACE' and t[1] == '}':
            if stop == '}':
                return out
            pos[0] += 1; continue
        if t[0] == 'BRACE' and t[1] == '{':
            pos[0] += 1
            inner = parse_expr(toks, pos, '}')
            if pos[0] < len(toks) and toks[pos[0]][0] == 'BRACE' and toks[pos[0]][1] == '}':
                pos[0] += 1
            atom = apply_supsub(toks, pos, inner)
            out.extend(atom); continue
        if t[0] in ('SUP','SUB'):
            pos[0] += 1; continue
        if t[0] == 'CHAR':
            ch = t[1]; pos[0] += 1
            if ch.isalnum():
                buf = ch
                while pos[0] < len(toks) and toks[pos[0]][0] == 'CHAR' and toks[pos[0]][1].isalnum():
                    buf += toks[pos[0]][1]; pos[0] += 1
                atom = [run_for_token(buf)]
            else:
                atom = [omml_text(ch)]
            atom = apply_supsub(toks, pos, atom)
            out.extend(atom); continue
        if t[0] == 'CMD':
            name = t[1]; pos[0] += 1
            if name in ('left','right'):
                if pos[0] < len(toks) and toks[pos[0]][0] == 'CHAR':
                    ch = toks[pos[0]][1]; pos[0] += 1
                    atom = apply_supsub(toks, pos, [omml_text(ch)])
                    out.extend(atom)
                continue
            if name in SPACE_CMDS:
                continue
            if name == 'frac':
                num = parse_group(toks, pos); den = parse_group(toks, pos)
                atom = ['<m:f><m:fPr/>','<m:num>',num,'</m:num>','<m:den>',den,'</m:den>','</m:f>']
                atom = apply_supsub(toks, pos, atom); out.extend(atom); continue
            if name in ('sqrt','surd'):
                rad = parse_group(toks, pos)
                atom = ['<m:rad><m:radPr/>','<m:e>',rad,'</m:e>','</m:rad>']
                atom = apply_supsub(toks, pos, atom); out.extend(atom); continue
            if name in ('text','mbox','mathrm'):
                txt = parse_text_group(toks, pos)
                atom = apply_supsub(toks, pos, [omml_text(txt,'p')]); out.extend(atom); continue
            if name in SYMBOL:
                atom = apply_supsub(toks, pos, [omml_text(SYMBOL[name])]); out.extend(atom); continue
            if name in GREEK:
                atom = apply_supsub(toks, pos, [omml_text(GREEK[name])]); out.extend(atom); continue
            if name in FUNCS:
                atom = apply_supsub(toks, pos, [omml_func(name)]); out.extend(atom); continue
            # 未知命令：原样文本
            atom = apply_supsub(toks, pos, [omml_text('\\'+name)]); out.extend(atom); continue
    return out

def content_to_omml(s):
    try:
        toks = tokenize(s)
        pos = [0]
        return ''.join(parse_expr(toks, pos, None))
    except Exception:
        return omml_text(s)

def latex_to_omml(s):
    return '<m:oMath>' + content_to_omml(s) + '</m:oMath>'

def inline_children(text):
    """把一段文本按 $...$ 切成 Word 段落子元素（普通 run 与 oMath 交错）。
    段内的 \n 转为 Word 软换行（w:br），使表格文本/分行选项等可按原文换行显示。"""
    if text is None:
        return ''
    out = []
    parts = text.split('$')
    for i, seg in enumerate(parts):
        if seg == '':
            continue
        if i % 2 == 1:
            out.append(latex_to_omml(seg))
        else:
            runs = []
            for j, line in enumerate(esc(seg).split('\n')):
                if j > 0:
                    runs.append('<w:r><w:br/></w:r>')
                runs.append('<w:r><w:t xml:space="preserve">%s</w:t></w:r>' % line)
            out.append(''.join(runs))
    return ''.join(out)

# ---------------------------------------------------------------------------
# 2. 答题线 / 作文方格 辅助
# ---------------------------------------------------------------------------
def ruled_lines(n):
    """生成 n 行浅灰答题线（段落下边框）。"""
    if not n or n <= 0:
        return ''
    out = []
    for _ in range(int(n)):
        out.append(
            '<w:p><w:pPr>'
            '<w:pBdr><w:bottom w:val="single" w:sz="4" w:space="2" w:color="999999"/></w:pBdr>'
            '<w:spacing w:before="0" w:after="60" w:line="276" w:lineRule="auto"/>'
            '</w:pPr><w:r><w:t xml:space="preserve"> </w:t></w:r></w:p>')
    return ''.join(out)

def composition_grid(grid_w, rows, per_row=None):
    """生成作文方格（按用户样图"标准稿纸式"）：每行 per_row 个正方形
    细黑边框格，行与行之间留一条空白隔行（约 0.45 格高）。
    表格宽度=所在栏宽（分栏时随栏走：先排满左栏、再排右栏，
    由 Word 分栏流式排版自然完成）。"""
    rows = int(rows) if rows else 20
    if not per_row:
        per_row = max(8, min(24, grid_w // 460))   # 每格约0.8cm见方
    per_row = max(1, int(per_row))
    cell_w = grid_w // per_row
    gap_h = int(cell_w * 0.45)
    grid_cols = ''.join('<w:gridCol w:w="%d"/>' % cell_w for _ in range(per_row))
    cell_borders = ('<w:tcBorders>'
                    '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                    '<w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                    '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                    '<w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>'
                    '</w:tcBorders>')
    tblpr = ('<w:tblPr>'
             '<w:tblW w:w="%d" w:type="dxa"/>' % grid_w
             + '<w:tblBorders>'
               '<w:top w:val="none" w:sz="0" w:space="0"/>'
               '<w:left w:val="none" w:sz="0" w:space="0"/>'
               '<w:bottom w:val="none" w:sz="0" w:space="0"/>'
               '<w:right w:val="none" w:sz="0" w:space="0"/>'
               '<w:insideH w:val="none" w:sz="0" w:space="0"/>'
               '<w:insideV w:val="none" w:sz="0" w:space="0"/>'
               '</w:tblBorders>'
             + '<w:tblCellMar>'
               '<w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/>'
               '<w:bottom w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/>'
               '</w:tblCellMar>'
               '<w:tblLayout w:type="fixed"/>'
               '</w:tblPr>')
    tbl = ['<w:tbl>', tblpr, '<w:tblGrid>%s</w:tblGrid>' % grid_cols]
    empty_p = ('<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" '
               'w:lineRule="auto"/></w:pPr><w:r><w:t/></w:r></w:p>')
    for i in range(rows):
        # 一行方格（单格自带四边框）
        cells = ''.join(
            '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s</w:tcPr>%s</w:tc>'
            % (cell_w, cell_borders, empty_p) for _c in range(per_row))
        tbl.append('<w:tr><w:trPr><w:trHeight w:val="%d" w:hRule="exact"/></w:trPr>%s</w:tr>'
                   % (cell_w, cells))
        # 行间空白隔行（无边框，最后一行后不加）
        if i < rows - 1:
            spacer = ''.join(
                '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/></w:tcPr>%s</w:tc>'
                % (cell_w, empty_p) for _c in range(per_row))
            tbl.append('<w:tr><w:trPr><w:trHeight w:val="%d" w:hRule="exact"/></w:trPr>%s</w:tr>'
                       % (gap_h, spacer))
    tbl.append('</w:tbl>')
    return ''.join(tbl)

def section_break_para(cols, pgsz, marg, col_space):
    """连续分节符：把当前栏数切到 cols（用于作文段强制单栏）。
    必须携带与全文一致的页面尺寸/页边距，否则该段会回退为默认 A4。"""
    return ('<w:p><w:pPr><w:sectPr><w:type w:val="continuous"/>%s%s'
            '<w:cols w:num="%d" w:space="%d"/></w:sectPr></w:pPr></w:p>'
            % (pgsz, marg, cols, col_space))

# ---------------------------------------------------------------------------
# 2.5 插图支持（纯标准库嵌入 PNG/JPEG，零额外依赖）
# ---------------------------------------------------------------------------
EMU_PER_CM = 360000

def image_dimensions(path):
    """读取图片原始像素尺寸（支持 PNG / JPEG），用于按比例换算显示高度。"""
    try:
        with open(path, 'rb') as f:
            sig = f.read(8)
        if sig == b'\x89PNG\r\n\x1a\n':
            with open(path, 'rb') as f:
                f.seek(16)
                w, h = struct.unpack('>II', f.read(8))
            return w, h
        if sig[:2] == b'\xff\xd8':
            with open(path, 'rb') as f:
                data = f.read()
            i, n = 2, len(data)
            while i < n:
                if data[i] != 0xFF:
                    i += 1; continue
                marker = data[i+1]
                if marker in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB):
                    h = int.from_bytes(data[i+5:i+7], 'big')
                    w = int.from_bytes(data[i+7:i+9], 'big')
                    return w, h
                if marker in (0xD8,0xD9) or 0xD0 <= marker <= 0xD7:
                    i += 2; continue
                seg = int.from_bytes(data[i+2:i+4], 'big')
                i += 2 + seg
    except Exception:
        pass
    return 0, 0

def make_inline_drawing(rid, cx, cy, name, docid=1):
    """生成 Word 内嵌图片的 drawing XML（inline，可随分栏流式排版）。
    docid 为每张图递增的唯一编号（避免多图时 wp:docPr id 重复导致 Word 告警）。"""
    return (
        '<w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
        '<wp:extent cx="%d" cy="%d"/>'
        '<wp:effectExtent l="0" t="0" r="0" b="0"/>'
        '<wp:docPr id="%d" name="%s"/>'
        '<wp:cNvGraphicFramePr><a:graphicFrameLocks '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        'noChangeAspect="1"/></wp:cNvGraphicFramePr>'
        '<a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        '<pic:nvPicPr><pic:cNvPr id="%d" name="%s"/><pic:cNvPicPr/></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
        '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing>'
    ) % (cx, cy, docid, esc(name), docid, esc(name), rid, cx, cy)

def image_para(imgs, width_cm=8.0, caption=None):
    """生成居中插图段落。

    imgs      : 单张图的信息 dict，或若干张图的信息 dict 列表（多图并排，如甲/乙/丙）。
    width_cm  : 插图在试卷上的**总显示宽度**（厘米）；多图时按张数均分。
    caption   : 题图说明（如 "图1" / "图甲：××装置"），可选，居中置于图下方。
    """
    if isinstance(imgs, dict):
        imgs = [imgs]
        total_cm = width_cm
    else:
        total_cm = width_cm
    n = max(1, len(imgs))
    per = total_cm / n
    runs = []
    for i, info in enumerate(imgs):
        w, h = info.get('w', 0), info.get('h', 0)
        cx = int(per * EMU_PER_CM)
        cy = int(cx * h / w) if w else cx
        runs.append(make_inline_drawing(info['rid'], cx, cy, info['media'], info.get('docid', 1)))
        if i < n - 1:
            runs.append('<w:r><w:t xml:space="preserve">  </w:t></w:r>')  # 图间微隙
    p = para(''.join(runs), jc='center', sp_before=40, sp_after=(40 if caption else 80))
    if caption:
        p += para(inline_children(caption), jc='center', size=18, sp_before=0, sp_after=80)
    return p


# 题干中出现这些词但该项无 image（或 image 路径不存在），即"有题无图"事故高风险。
FIGURE_KEYWORDS = ('如图', '下图', '上图', '图甲', '图乙', '图丙', '图1', '图2', '图3',
                   '图中', '示意图', '装置图', '光路图', '电路图', '结构图', '曲线图')


def figure_selfcheck(spec, spec_dir='.'):
    """初中理科出卷必备：逐题核对"如图"类题干是否挂了图。
    返回 (warnings, errors)：warnings 提示缺失/找不到图；errors 为 strict_figures=True 时的致命项。"""
    warnings, errors = [], []
    n = 0
    for si, sec in enumerate(spec.get('sections', []), 1):
        if sec.get('answer_key'):
            continue
        for it in sec.get('items', []):
            stem = it.get('stem', '')
            n += 1
            if it.get('passage'):
                continue
            img = it.get('image')
            imgs = [img] if isinstance(img, str) else (img or [])
            has_field = bool(imgs)
            # 路径存在性校验（相对路径按 spec 目录解析）
            missing = []
            for im in imgs:
                p = im if os.path.isabs(im) or os.path.exists(im) else os.path.join(spec_dir, im)
                if not os.path.exists(p):
                    missing.append(im)
            # 情形一：写了 image 但文件找不到（多为出图/shebang 路径问题）
            if missing:
                msg = '第%d大题 第%d题：图片找不到 %s' % (si, n, missing)
                warnings.append(msg)
                errors.append(msg)
            # 情形二：题干说"如图"却压根没写 image 字段
            if not has_field and any(k in stem for k in FIGURE_KEYWORDS):
                msg = ('第%d大题 第%d题：题干含"如图/图×/装置图"等但无 image 字段'
                       '（有题无图风险）' % (si, n))
                warnings.append(msg)
                errors.append(msg)
    return warnings, errors

# ---------------------------------------------------------------------------
# 3. docx 部件构建
# ---------------------------------------------------------------------------
PAGE = {
    ('A4','portrait'):   (11906, 16838, None),
    ('A4','landscape'):  (16838, 11906, 'landscape'),
    ('A3','portrait'):   (16838, 23811, None),
    ('A3','landscape'):  (23811, 16838, 'landscape'),
}
MARGIN = 1300   # 页边距（twips，约 2.3cm）—— 为作文方格预留整宽
TYPE_DEFAULT_LINES = {'single':0, 'fill':0, 'short':4, 'solve':6, 'essay':8, 'composition':0}

def para(children_xml, style=None, jc=None, size=None, bold=False,
         ind_left=None, ind_hang=None, sp_before=60, sp_after=60, col_break=False):
    ppr = []
    if style:
        ppr.append('<w:pStyle w:val="%s"/>' % style)
    if jc:
        ppr.append('<w:jc w:val="%s"/>' % jc)
    if col_break:
        ppr.append('<w:br w:type="column"/>')
    rpr = []
    if size:
        rpr.append('<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (size, size))
    if bold:
        rpr.append('<w:b/><w:bCs/>')
    if rpr:
        ppr.append('<w:rPr>%s</w:rPr>' % ''.join(rpr))
    ppr.append('<w:spacing w:before="%d" w:after="%d" w:line="276" w:lineRule="auto"/>' % (sp_before, sp_after))
    if ind_left is not None or ind_hang is not None:
        attrs = ''
        if ind_left is not None:
            attrs += ' w:left="%d"' % ind_left
        if ind_hang is not None:
            attrs += ' w:hanging="%d"' % ind_hang
        ppr.append('<w:ind%s/>' % attrs)
    ppr_xml = '<w:pPr>%s</w:pPr>' % ''.join(ppr) if ppr else ''
    return '<w:p>%s%s</w:p>' % (ppr_xml, children_xml)

def build_document(spec, img_reg=None):
    img_reg = img_reg or {}
    layout = spec.get('layout', {}) or {}
    page = layout.get('page', 'A4')
    # 版式规范：A4 = 竖排一栏（默认）；A3 = 横排两栏（正规试卷大版式）。
    # 用户显式指定 orient/columns 时以用户为准。
    default_orient = 'landscape' if page == 'A3' else 'portrait'
    default_cols = 2 if page == 'A3' else 1
    orient = layout.get('orient', default_orient)
    columns = int(layout.get('columns', default_cols))
    col_space = int(layout.get('col_space', 425))
    pw, ph, orient_attr = PAGE.get((page, orient), PAGE[('A4','portrait')])
    usable_w = pw - 2 * MARGIN
    marg = ('<w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" '
            'w:header="720" w:footer="720" w:gutter="0"/>'
            % (MARGIN, MARGIN, MARGIN, MARGIN))
    orient_xml = ' w:orient="%s"' % orient_attr if orient_attr else ''
    pgsz = '<w:pgSz w:w="%d" w:h="%d"%s/>' % (pw, ph, orient_xml)

    # ---- 卷头：标题 / 元信息 / 注意事项 ----
    header = []
    title = spec.get('title', '未命名试卷')
    header.append(para(inline_children(title), jc='center', size=32, bold=True, sp_before=0, sp_after=120))
    meta = spec.get('meta')
    if meta:
        header.append(para(inline_children(meta), jc='left', size=21, sp_before=0, sp_after=80))
    notice = spec.get('notice')
    if notice:
        for line in notice.split('\n'):
            if line.strip():
                header.append(para(inline_children(line), size=21, sp_before=0, sp_after=20))

    # ---- 各题组渲染 ----
    def render_section(sec):
        out = []
        sec_title = sec.get('title', '')
        stype = sec.get('type', '')
        is_key = sec.get('answer_key', False)
        full_width = bool(sec.get('full_width', False))
        # 题组标题
        cb = sec.get('break_before', False) and columns > 1
        out.append(para(inline_children(sec_title),
                        jc='left', size=24, bold=True,
                        sp_before=160, sp_after=80, col_break=cb))
        if is_key:
            for it in sec.get('items', []):
                stem = it.get('stem', '')
                out.append(para(inline_children(stem), size=21, sp_before=0, sp_after=40))
            return ''.join(out), full_width
        # 作文方格：随栏排版（分栏时先排满左栏再排右栏），格宽=栏宽
        if stype == 'composition':
            grid_w = usable_w if columns == 1 else (usable_w - (columns - 1) * col_space) // columns
            per_row = max(8, min(24, grid_w // 460))   # 每格约0.8cm见方
            for it in sec.get('items', []):
                prompt = it.get('prompt', '')
                # 格数按作文字数自动配置：总格数 ≥ 要求字数
                words = int(it.get('words', 0))
                rows = it.get('grid_rows')
                rows = int(rows) if rows else max(1, -(-(words or 600) // per_row))
                if prompt:
                    out.append(para(inline_children(prompt), size=22, sp_before=80, sp_after=60, ind_hang=420))
                out.append(composition_grid(grid_w, rows, per_row))
                out.append(para(inline_children(''), sp_before=120, sp_after=0))
            return ''.join(out), full_width
        # 普通题型
        default_lines = TYPE_DEFAULT_LINES.get(stype, 0)
        sec_lines = sec.get('answer_lines', None)
        n = sec.get('number_start', 1) - 1   # 支持整卷连续题号（默认从 1 起）
        for it in sec.get('items', []):
            stem = it.get('stem', '')
            # 阅读正文块：item 加 "passage": true 时不编号、两端对齐、独立成段，
            # 段后补空段，与后续题目明确换行分隔（用于阅读理解的正文部分）
            if it.get('passage'):
                out.append(para(inline_children(stem), size=21, sp_before=60, sp_after=40, jc='both'))
                _pimg = it.get('image')
                _plist = [_pimg] if isinstance(_pimg, str) else list(_pimg or [])
                _pin = [img_reg[i] for i in _plist if i in img_reg]
                if _pin:
                    out.append(image_para(_pin, it.get('image_width', 8.0), it.get('image_caption')))
                out.append(para(inline_children(''), sp_before=0, sp_after=80))
                continue
            n += 1
            opts = it.get('options') or []
            img = it.get('image')
            if isinstance(img, str):
                img_list = [img] if img in img_reg else []
            else:
                img_list = [i for i in (img or []) if i in img_reg]
            if img_list:
                imgs_info = [img_reg[i] for i in img_list]
                cap = it.get('image_caption')
                if '\n' in stem:
                    # 多行题干挂图：图插在首行之后（引导句 -> 图 -> 小问，题后图前标准卷式）
                    head, rest = stem.split('\n', 1)
                    out.append(para(inline_children('%d. %s' % (n, head)), size=22,
                                    sp_before=120, sp_after=40, ind_hang=420))
                    out.append(image_para(imgs_info, it.get('image_width', 8.0), cap))
                    out.append(para(inline_children(rest), size=22, sp_before=40,
                                    sp_after=40, ind_hang=420))
                else:
                    out.append(para(inline_children('%d. %s' % (n, stem)), size=22,
                                    sp_before=120, sp_after=40, ind_hang=420))
                    out.append(image_para(imgs_info, it.get('image_width', 8.0), cap))
            else:
                out.append(para(inline_children('%d. %s' % (n, stem)), size=22,
                                sp_before=120, sp_after=40, ind_hang=420))
            if opts:
                # 选择题选项排版：单行横排（省纸）→ 放不下分两行（AB/CD）→ 竖排兜底；
                # 选项一律不缩进（ind_left 取消）
                inline_opts = sec.get('options_inline', stype == 'single')
                has_nl = any('\n' in o for o in opts)
                total = sum(len(o) for o in opts)
                if inline_opts and not has_nl and total <= 64:
                    out.append(para(inline_children('\u3000\u3000'.join(opts)), size=22,
                                    sp_before=0, sp_after=40))
                elif inline_opts and not has_nl and len(opts) >= 3:
                    # 本行放不下：选项分两行（4 选项即 AB / CD），按前后均分；
                    # 若单行仍超 64 字符则回退每行一个
                    half = (len(opts) + 1) // 2
                    row1 = '\u3000\u3000'.join(opts[:half])
                    row2 = '\u3000\u3000'.join(opts[half:])
                    if len(row1) <= 64:
                        out.append(para(inline_children(row1), size=22,
                                        sp_before=0, sp_after=30))
                        if row2:
                            out.append(para(inline_children(row2), size=22,
                                            sp_before=0, sp_after=40))
                    else:
                        for opt in opts:
                            out.append(para(inline_children(opt), size=22,
                                            sp_before=0, sp_after=30))
                else:
                    for opt in opts:
                        out.append(para(inline_children(opt), size=22, sp_before=0, sp_after=30))
            # 答题空间：question.space > section.answer_lines > 题型默认
            lines = it.get('space', None)
            if lines is None:
                lines = sec_lines if sec_lines is not None else default_lines
            if lines and int(lines) > 0:
                out.append(ruled_lines(int(lines)))
        return ''.join(out), full_width

    # 组装"内容块"：(栏数, xml)。卷头与正文默认栏数一致；作文随栏排版。
    blocks = [(columns, ''.join(header))]
    for sec in spec.get('sections', []):
        xml, fw = render_section(sec)
        blk_cols = 1 if fw else columns
        blocks.append((blk_cols, xml))

    # 栏数变化时插入"连续分节符"，作文段即便在分栏试卷中也独占整宽
    result = []
    for i, (cols, xml) in enumerate(blocks):
        if i > 0 and cols != blocks[i-1][0]:
            result.append(section_break_para(blocks[i-1][0], pgsz, marg, col_space))
        result.append(xml)
    terminal_cols = blocks[-1][0]

    cols_xml = '<w:cols w:num="%d" w:space="%d"/>' % (terminal_cols, col_space)
    sectpr = ('<w:sectPr>%s%s%s</w:sectPr>' % (pgsz, marg, cols_xml))

    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
            'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
            '<w:body>%s%s</w:body></w:document>' % (''.join(result), sectpr))

def build_styles():
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:docDefaults><w:rPrDefault><w:rPr>'
            '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="宋体" w:cs="Times New Roman"/>'
            '<w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:rPrDefault>'
            '<w:pPrDefault><w:pPr><w:spacing w:after="60" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault>'
            '</w:docDefaults>'
            '<w:style w:type="paragraph" w:default="1" w:styleId="Normal">'
            '<w:name w:val="Normal"/></w:style>'
            '</w:styles>')

def build_settings():
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:zoom w:percent="100"/>'
            '<w:defaultTabStop w:val="420"/>'
            '<w:characterSpacingControl w:val="doNotCompress"/>'
            '</w:settings>')

def build_content_types(img_reg=None):
    img_defaults = ''
    if img_reg:
        ctype = {'png':'image/png', 'jpeg':'image/jpeg', 'gif':'image/gif', 'bmp':'image/bmp'}
        for ext in set(i['ext'] for i in img_reg.values()):
            if ext in ctype:
                img_defaults += '<Default Extension="%s" ContentType="%s"/>' % (ext, ctype[ext])
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '%s'
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
            '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
            '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            '</Types>' % img_defaults)

def build_rels():
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
            '</Relationships>')

def build_doc_rels(img_reg=None):
    img_rels = ''
    if img_reg:
        for info in img_reg.values():
            img_rels += ('<Relationship Id="%s" '
                'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
                'Target="media/%s"/>' % (info['rid'], info['media']))
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>'
            '%s'
            '</Relationships>' % img_rels)

def build_core(title):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            '<dc:title>%s</dc:title><dc:creator>K12科学命题skill</dc:creator>'
            '</cp:coreProperties>' % esc(title))

def build_app():
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
            '<Application>Microsoft Office Word</Application></Properties>')

def generate(spec, out_path, spec_path='-'):
    spec_dir = (os.path.dirname(os.path.abspath(spec_path))
                if spec_path not in ('-', '') else os.getcwd())
    # —— 图—题绑定自检（初中理科出卷必备，防"有题无图"事故）——
    warns, errs = figure_selfcheck(spec, spec_dir)
    if warns:
        for w in warns:
            sys.stderr.write('[图件提示] %s\n' % w)
    if spec.get('strict_figures') and errs:
        raise SystemExit('[致命] strict_figures=True，存在"有题无图"或图片缺失：\n' + '\n'.join(errs))
    # 预扫描插图：为每幅图片分配 rId / media 名 / 原始尺寸（嵌入用）
    # image 可为字符串（单图）或字符串列表（多图并排），路径相对 spec 目录解析
    img_reg = {}
    rid = 100; docid = 1; mc = 1
    def reg_one(p):
        nonlocal rid, docid, mc
        if p in img_reg:
            return
        ap = p if (os.path.isabs(p) or os.path.exists(p)) else os.path.join(spec_dir, p)
        if not os.path.exists(ap):
            return
        w, h = image_dimensions(ap)
        ext = os.path.splitext(ap)[1].lower().lstrip('.') or 'png'
        if ext not in ('png', 'jpeg', 'jpg', 'gif', 'bmp'):
            ext = 'png'
        media_ext = 'jpeg' if ext == 'jpg' else ext
        img_reg[p] = {'rid': 'rId%d' % rid,
                      'media': 'image%d.%s' % (mc, media_ext),
                      'w': w, 'h': h, 'ext': media_ext, 'docid': docid,
                      'path': ap}
        rid += 1; docid += 1; mc += 1
    for sec in spec.get('sections', []):
        for it in sec.get('items', []):
            img = it.get('image')
            if not img:
                continue
            if isinstance(img, str):
                reg_one(img)
            else:
                for im in img:
                    reg_one(im)
    document = build_document(spec, img_reg)
    parts = {
        '[Content_Types].xml': build_content_types(img_reg),
        '_rels/.rels': build_rels(),
        'word/document.xml': document,
        'word/_rels/document.xml.rels': build_doc_rels(img_reg),
        'word/styles.xml': build_styles(),
        'word/settings.xml': build_settings(),
        'docProps/core.xml': build_core(spec.get('title', '试卷')),
        'docProps/app.xml': build_app(),
    }
    # 嵌入图片二进制
    for img, info in img_reg.items():
        with open(info['path'], 'rb') as f:
            parts['word/media/' + info['media']] = f.read()
    with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in parts.items():
            z.writestr(name, data)
    return out_path

# ---------------------------------------------------------------------------
# 4. 入口
# ---------------------------------------------------------------------------
def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)
    spec_path = args[0]
    if spec_path == '-':
        spec = json.load(sys.stdin)
    else:
        with open(spec_path, 'r', encoding='utf-8') as f:
            spec = json.load(f)
    if len(args) >= 2 and args[1] != '-':
        out_path = args[1]
    else:
        base = os.path.splitext(os.path.basename(spec_path if spec_path != '-' else 'paper'))[0]
        out_path = base + '.docx'
    generate(spec, out_path, spec_path)
    print('OK -> %s' % out_path)

if __name__ == '__main__':
    main()
