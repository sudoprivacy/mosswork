# -*- coding: utf-8 -*-
r"""
draw_geometry.py —— K12 科学命题 skill 的「插图绘制助手」（可选，需 matplotlib）。

用途：出卷时由 AI 按题意精确绘制试卷插图（几何图、树状图、对称图形等），
      输出 PNG，再交给 gen_paper.py 通过 item 的 image 字段嵌入 docx。
说明：本文件不是 gen_paper.py 的运行时依赖（gen_paper.py 仅用标准库嵌入图片）；
      它只是"怎么把图画出来"的现成工具箱，便于各学段复用、保证图形严谨。

依赖：pip install matplotlib   （已在隔离 venv 预装）
中文：自动加载系统黑体（simhei.ttf），"正/反"等中文标签不乱码。

常用函数：
  circle_chord(R, half, path, ...)        圆 + 弦 + 垂径（垂径定理）
  coin_tree(path, ...)                     两枚硬币树状图
  shapes_panel(path, items, ...)           对称/几何图形对比面板（A/B/C/D）
  triangle_with_marks(...)                 带直角/角度标记的三角形
  parabola(path, ...)                      二次函数抛物线（顶点/开口）
  circuit_series(path, points=...)         串联电路图（开关/灯泡/电流表/测量点）
  circuit_parallel(path, meters=...)       并联电路图（干路与支路电流表位置可配）
  circuit_real(path)                       实物连接图（画电路图题用）
  circuit_panel_identify(path)             四格电路辨识面板（短路/断路/通路）
  ammeter_dial(path, value, rng)           电流表双量程表盘（读数题用）
  rust_tubes(path, ...)                    铁钉锈蚀条件三试管（干燥空气/只有水/水+空气）
  acid_tubes(path, ...)                    Mg/Zn/Fe/Cu 与相同稀盐酸四试管（无气泡防泄题）
  blast_furnace(path, ...)                 高炉炼铁剖面示意图（无文字标注，供指认）
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Polygon, Wedge

# ---- 中文支持：自动找系统黑体 ----
_FONT = None
for _cand in (r"C:/Windows/Fonts/simhei.ttf",
              r"C:/Windows/Fonts/msyh.ttc",
              r"/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"):
    if os.path.exists(_cand):
        _FONT = _cand; break
if _FONT:
    from matplotlib import font_manager
    font_manager.fontManager.addfont(_FONT)
    plt.rcParams["font.family"] = font_manager.FontProperties(fname=_FONT).get_name()
plt.rcParams["axes.unicode_minus"] = False


# ---------------------------------------------------------------------------
# 基础图元
# ---------------------------------------------------------------------------
def _new_fig(figsize=(4.2, 3.2)):
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.set_aspect("equal")
    ax.axis("off")
    return fig, ax


def save(fig, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def right_angle(ax, p, d1, d2, size=0.35, color="#1a1a1a", lw=1.0):
    """在 p 处画直角标记：d1、d2 为两条边的另一端点。"""
    v1 = (d1[0]-p[0], d1[1]-p[1]); v2 = (d2[0]-p[0], d2[1]-p[1])
    L1 = (v1[0]**2 + v1[1]**2) ** 0.5 or 1
    L2 = (v2[0]**2 + v2[1]**2) ** 0.5 or 1
    u1 = (v1[0]/L1, v1[1]/L1); u2 = (v2[0]/L2, v2[1]/L2)
    p1 = (p[0]+u1[0]*size, p[1]+u1[1]*size)
    p2 = (p[0]+u1[0]*size+u2[0]*size, p[1]+u1[1]*size+u2[1]*size)
    p3 = (p[0]+u2[0]*size, p[1]+u2[1]*size)
    ax.plot([p1[0], p2[0], p3[0]], [p1[1], p2[1], p3[1]], color=color, lw=lw)


def label(ax, p, text, dx=0.18, dy=0.12, size=13, color="#1a1a1a"):
    ax.text(p[0]+dx, p[1]+dy, text, fontsize=size, color=color,
            ha="center", va="center")


def equal_mark(ax, p1, p2, gap=0.18, color="#1a1a1a"):
    """在 p1-p2 中点画两条短斜线，表示相等（如弦中点）。"""
    mx, my = (p1[0]+p2[0])/2, (p1[1]+p2[1])/2
    ax.plot([mx-gap, mx+gap], [my+gap, my-gap], color=color, lw=1.0)
    ax.plot([mx-gap, mx+gap], [my+gap*1.8, my-gap*0.2], color=color, lw=1.0)


# ---------------------------------------------------------------------------
# 1. 垂径定理：圆 + 弦 + 垂径
# ---------------------------------------------------------------------------
def circle_chord(R, half, path, labels=True, title=None, figsize=(4.6, 3.4)):
    """圆心 O(0,0)，弦 AB 水平，半弦长=half；OC ⟂ AB 于 C（C 为 AB 中点）。
       y_c = sqrt(R^2 - half^2)。满足 half < R。"""
    import math
    yc = math.sqrt(max(R*R - half*half, 0))
    A = (-half, yc); B = (half, yc); O = (0, 0); C = (0, yc)
    fig, ax = _new_fig(figsize)
    ax.add_patch(plt.Circle(O, R, fill=False, lw=1.6, color="#1a1a1a"))
    ax.plot([A[0], B[0]], [A[1], B[1]], color="#1a1a1a", lw=1.6)      # 弦 AB
    ax.plot([O[0], C[0]], [O[1], C[1]], color="#1a1a1a", lw=1.6)      # 垂径 OC
    ax.plot([O[0], A[0]], [O[1], A[1]], ls="--", color="#999", lw=1)  # 半径 OA
    ax.plot([O[0], B[0]], [O[1], B[1]], ls="--", color="#999", lw=1)  # 半径 OB
    right_angle(ax, C, (C[0], C[1]-1), B)                              # ∠OCB=90°
    equal_mark(ax, A, B)                                               # C 为中点
    if labels:
        label(ax, O, "O", -0.45, -0.45, size=13)
        label(ax, A, "A", -0.45, 0.12)
        label(ax, B, "B", 0.42, 0.12)
        label(ax, C, "C", 0.18, 0.16)
    if title:
        ax.set_title(title, fontsize=13)
    ax.set_xlim(-R-1, R+1); ax.set_ylim(-R-1, R+1)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 2. 两枚硬币树状图
# ---------------------------------------------------------------------------
def coin_tree(path, figsize=(5.4, 3.2), filled=True):
    """甲、乙各掷一枚硬币一次的树状图。
       filled=True  → 画满分支与 4 种结果（用于讲解/答案）；
       filled=False → 空白模板（节点留空/下划线），供学生答题填写。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(0, 10); ax.set_ylim(0, 6)
    # 根
    ax.plot(1, 3, "o", color="#1a1a1a")
    ax.text(0.7, 3.25, "开始", fontsize=12)
    # 第一层
    ax.annotate("", xy=(3, 4), xytext=(1, 3),
                arrowprops=dict(arrowstyle="-", color="#1a1a1a", lw=1.2))
    ax.annotate("", xy=(3, 2), xytext=(1, 3),
                arrowprops=dict(arrowstyle="-", color="#1a1a1a", lw=1.2))
    # 第二层
    for y0 in (4, 2):
        ax.annotate("", xy=(6, y0+0.6), xytext=(3, y0),
                    arrowprops=dict(arrowstyle="-", color="#1a1a1a", lw=1.2))
        ax.annotate("", xy=(6, y0-0.6), xytext=(3, y0),
                    arrowprops=dict(arrowstyle="-", color="#1a1a1a", lw=1.2))
    if filled:
        ax.text(2.0, 4.15, "甲正", fontsize=12); ax.text(2.0, 1.85, "甲反", fontsize=12)
        for y0 in (4, 2):
            ax.text(4.6, y0+0.75, "乙正", fontsize=12)
            ax.text(4.6, y0-0.75, "乙反", fontsize=12)
        results = [("正,正"), ("正,反"), ("反,正"), ("反,反")]
        ys = [4.6, 3.4, 2.6, 1.4]
        for y, r in zip(ys, results):
            ax.annotate("", xy=(9, y), xytext=(6, y),
                        arrowprops=dict(arrowstyle="-", color="#1a1a1a", lw=1.2))
            ax.text(7.4, y+0.18, "乙", fontsize=11, color="#888")
            ax.text(9.1, y, "(%s)" % r, fontsize=12)
    else:
        # 空白模板：分支端点与末端留空
        for y0 in (4, 2):
            ax.text(2.0, y0, "____", fontsize=12, ha="center", va="center", color="#555")
            ax.text(4.6, y0+0.6, "____", fontsize=12, ha="center", va="center", color="#555")
            ax.text(4.6, y0-0.6, "____", fontsize=12, ha="center", va="center", color="#555")
        ys = [4.6, 3.4, 2.6, 1.4]
        for y in ys:
            ax.annotate("", xy=(9, y), xytext=(6, y),
                        arrowprops=dict(arrowstyle="-", color="#1a1a1a", lw=1.2))
            ax.text(9.1, y, "（____,____）", fontsize=11, color="#555")
    ax.text(5.0, 5.4, "甲、乙各掷一枚硬币", fontsize=12, ha="center")
    return save(fig, path)


# ---------------------------------------------------------------------------
# 3. 对称图形对比面板（A/B/C/D）
# ---------------------------------------------------------------------------
def shapes_panel(path, items, cols=2, figsize=(6.0, 4.2)):
    """items: [(字母, 名称, draw_callable(ax))] —— 在子图里画该图形。"""
    n = len(items); rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=figsize, dpi=200)
    if n == 1:
        axes = [axes]
    else:
        axes = axes.flatten()
    for ax, (letter, name, draw) in zip(axes, items):
        ax.set_aspect("equal"); ax.axis("off")
        ax.set_xlim(-1.3, 1.3); ax.set_ylim(-1.3, 1.3)
        draw(ax)
        ax.text(-1.15, 1.05, "%s. %s" % (letter, name), fontsize=12, fontweight="bold")
    for ax in axes[n:]:
        ax.axis("off")
    fig.tight_layout()
    return save(fig, path)


def _draw_parallelogram(ax):
    ax.add_patch(Polygon([(-1, -0.6), (0.6, -0.6), (1, 0.6), (-0.6, 0.6)],
                         fill=False, lw=1.6, color="#1a1a1a"))


def _draw_iso_triangle(ax):
    ax.add_patch(Polygon([(0, 1), (-1, -0.7), (1, -0.7)],
                         fill=False, lw=1.6, color="#1a1a1a"))
    ax.plot([0, 0], [1, -0.7], ls="--", color="#999", lw=1)  # 对称轴


def _draw_rectangle(ax):
    ax.add_patch(plt.Rectangle((-1, -0.7), 2, 1.4, fill=False, lw=1.6, color="#1a1a1a"))


def _draw_equilateral(ax):
    import math
    h = math.sqrt(3) / 2 * 1.8
    ax.add_patch(Polygon([(0, h/2), (-0.9, -h/2), (0.9, -h/2)],
                         fill=False, lw=1.6, color="#1a1a1a"))


def shapes_symmetry(path):
    """默认四图形：平行四边形/等腰三角形/矩形/正三角形（对应选择题辨识）。"""
    items = [
        ("A", "平行四边形", _draw_parallelogram),
        ("B", "等腰三角形", _draw_iso_triangle),
        ("C", "矩形", _draw_rectangle),
        ("D", "正三角形", _draw_equilateral),
    ]
    return shapes_panel(path, items)


# ---------------------------------------------------------------------------
# 4. 抛物线（二次函数顶点/开口/过点/最值）
# ---------------------------------------------------------------------------
def parabola(path, a=1.0, h=0.0, k=0.0, xmin=None, xmax=None,
             points=None, show_axis=True, vertex_label=True, figsize=(4.6, 3.4)):
    """y = a(x-h)^2 + k。可标对称轴、顶点，及若干已知点（points）。
       x/y 尺度独立（抛物线题横纵比例常不同），故不用等比例。"""
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.axhline(0, color="#ccc", lw=0.8)   # x 轴
    ax.axvline(0, color="#ccc", lw=0.8)   # y 轴
    if xmin is None or xmax is None:
        xmin, xmax = h - 2.2, h + 2.2
    xs = [xmin + (xmax - xmin) * i / 240 for i in range(241)]
    ys = [a * (x - h) ** 2 + k for x in xs]
    ax.plot(xs, ys, color="#1a1a1a", lw=1.8)
    ylo = min(min(ys), k, *[py for _, py in (points or [])])
    yhi = max(max(ys), k, *[py for _, py in (points or [])])
    pad = (yhi - ylo) * 0.08 or 1.0
    ax.set_xlim(xmin - 0.4, xmax + 0.4)
    ax.set_ylim(ylo - pad, yhi + pad)
    if show_axis:  # 对称轴 x=h
        ax.plot([h, h], [ylo - pad, yhi + pad], color="#e11", ls="--", lw=1.0)
        ax.text(h, ylo - pad * 0.75, "x=%g" % h, fontsize=10, color="#c00",
                ha="center", va="top")
    ax.plot(h, k, "o", color="#1a1a1a", ms=4)   # 顶点
    if vertex_label:
        ax.text(h, k, "(%g, %g)" % (h, k), fontsize=11, ha="center", va="bottom")
    if points:      # 已知点
        for px, py in points:
            ax.plot(px, py, "o", color="#e11", ms=5)
            ax.text(px, py, "(%g, %g)" % (px, py), fontsize=10, color="#c00",
                    ha="right", va="top")
    ax.set_aspect("auto")
    ax.axis("off")
    return save(fig, path)


# ---------------------------------------------------------------------------
# 5. 扇形弧长
# ---------------------------------------------------------------------------
def sector(path, radius=4, angle_deg=90, figsize=(3.6, 3.6)):
    """扇形：半径 radius、圆心角 angle_deg；标圆心角、半径与弧长 l。"""
    import math
    fig, ax = _new_fig(figsize)
    ax.add_patch(plt.Circle((0, 0), radius, fill=False, lw=1.2, color="#bbb"))
    ax.add_patch(Wedge((0, 0), radius, 0, angle_deg, facecolor="#dfe6ef",
                       edgecolor="#1a1a1a", lw=1.5))
    ax.plot([0, radius], [0, 0], color="#1a1a1a", lw=1.5)  # 半径1
    ax.plot([0, radius * math.cos(math.radians(angle_deg))],
            [0, radius * math.sin(math.radians(angle_deg))], color="#1a1a1a", lw=1.5)  # 半径2
    ax.add_patch(Arc((0, 0), 2.6, 2.6, angle=0, theta1=0, theta2=angle_deg,
                     color="#c00", lw=1.0))
    ax.text(1.7, 0.55, "%d°" % angle_deg, fontsize=13, color="#c00")
    ax.text(radius / 2 * 0.85, -0.4, "r=%d" % radius, fontsize=11)
    amx = radius * math.cos(math.radians(angle_deg / 2))
    amy = radius * math.sin(math.radians(angle_deg / 2))
    ax.text(amx * 0.82, amy * 0.82, "l", fontsize=14, color="#1a1a1a")
    label(ax, (0, 0), "O", -0.35, -0.35)
    ax.set_xlim(-1, radius + 1); ax.set_ylim(-1, radius + 1)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 6. 点与圆的位置关系
# ---------------------------------------------------------------------------
def point_circle(path, radius=5, d=3, figsize=(3.6, 3.6)):
    """圆半径 radius，点 P 距圆心 d（d<radius 画圆内，= 上，> 外由调用方选 d）。"""
    import math
    fig, ax = _new_fig(figsize)
    ax.add_patch(plt.Circle((0, 0), radius, fill=False, lw=1.6, color="#1a1a1a"))
    ang = math.radians(40)
    P = (d * math.cos(ang), d * math.sin(ang))
    ax.plot([0, P[0]], [0, P[1]], color="#1a1a1a", lw=1.4)
    ax.plot(*P, "o", color="#e11", ms=5)
    label(ax, (0, 0), "O", -0.45, -0.45)
    label(ax, P, "P", 0.3, 0.28)
    ax.text(P[0] / 2 + 0.05, P[1] / 2 - 0.5, "OP=%d" % d, fontsize=11)
    ax.set_xlim(-radius - 1, radius + 1); ax.set_ylim(-radius - 1, radius + 1)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 7. 旋转
# ---------------------------------------------------------------------------
def rotation(path, length=2.5, angle_deg=90, figsize=(3.8, 3.4)):
    """线段 AB 绕点 A 逆时针旋转 angle_deg 得到 AB'，标出旋转角。"""
    import math
    fig, ax = _new_fig(figsize)
    A = (0, 0); B = (length, 0)
    ang = math.radians(angle_deg)
    Bp = (length * math.cos(ang), length * math.sin(ang))
    ax.plot([A[0], B[0]], [A[1], B[1]], color="#1a1a1a", lw=1.6)   # AB
    ax.plot([A[0], Bp[0]], [A[1], Bp[1]], color="#c00", lw=1.6)    # AB'
    ax.add_patch(Arc(A, 1.8, 1.8, angle=0, theta1=0, theta2=angle_deg,
                     color="#c00", lw=1.0))
    ax.text(1.2, 0.5, "%d°" % angle_deg, fontsize=12, color="#c00")
    for p in (A, B, Bp):
        ax.plot(*p, "o", color="#1a1a1a", ms=4)
    label(ax, A, "A", -0.4, -0.4); label(ax, B, "B", 0.28, -0.32)
    label(ax, Bp, "B'", 0.2, 0.28)
    ax.set_xlim(-0.9, length + 1.0); ax.set_ylim(-0.9, length + 1.0)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 8. 直角三角形（直角+指定锐角）
# ---------------------------------------------------------------------------def right_triangle(path, angleA=30, base=3.0, figsize=(3.8, 3.0)):
    """直角三角形：∠C=90°，∠A=angleA。AC=base，BC=base·tan(angleA)。"""
    import math
    fig, ax = _new_fig(figsize)
    A = (-base, 0); C = (0, 0); B = (0, base * math.tan(math.radians(angleA)))
    ax.add_patch(Polygon([A, B, C], fill=False, lw=1.6, color="#1a1a1a"))
    right_angle(ax, C, A, B, size=0.3)
    ax.add_patch(Arc(A, 1.2, 1.2, angle=0, theta1=0, theta2=angleA,
                     color="#c00", lw=1.0))
    label(ax, A, "A", -0.4, -0.4); label(ax, C, "C", 0.32, -0.38)
    label(ax, B, "B", 0.22, 0.28)
    ax.text(-base + 0.75, 0.42, "%d°" % angleA, fontsize=12, color="#c00")
    ax.set_xlim(-base - 0.9, 1.2); ax.set_ylim(-0.9, B[1] + 0.6)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 9. 线段图（分数应用题"单位1"图示）
# ---------------------------------------------------------------------------
def segment_bar(path, parts, total_label=None, remainder_label="？", figsize=(6.0, 1.9)):
    """分数应用题线段图：一条线段表示单位"1"，按给定分数分段涂色，
       剩余部分标"?". parts: [(num, den, label), ...]（如 [(1,4,'第一天'),(1,3,'第二天')]）。
       给的是题干信息，答案由学生计算。"""
    import math
    denoms = [d for _, d, _ in parts]
    lcd = denoms[0]
    for d in denoms[1:]:
        lcd = lcd * d // math.gcd(lcd, d)
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.set_xlim(-0.3, lcd + 0.3); ax.set_ylim(0, 3.2); ax.axis("off")
    bar_y, bar_h = 1.7, 0.6
    x = 0
    for num, den, lab in parts:
        w = num * (lcd // den)
        ax.add_patch(plt.Rectangle((x, bar_y), w, bar_h, facecolor="#cfe0f0",
                                   edgecolor="#1a1a1a", lw=1.2))
        ax.text(x + w / 2, bar_y + bar_h / 2, "%s\n%d/%d" % (lab, num, den),
                ha="center", va="center", fontsize=9.5)
        x += w
    rem = lcd - x
    if rem > 0:
        ax.add_patch(plt.Rectangle((x, bar_y), rem, bar_h, facecolor="#f6e3c4",
                                   edgecolor="#1a1a1a", lw=1.2))
        ax.text(x + rem / 2, bar_y + bar_h / 2, remainder_label,
                ha="center", va="center", fontsize=11)
    ax.annotate("", xy=(0, bar_y - 0.08), xytext=(lcd, bar_y - 0.08),
                arrowprops=dict(arrowstyle="<->", color="#555", lw=1))
    if total_label:
        ax.text(lcd / 2, bar_y - 0.45, total_label, ha="center", fontsize=10, color="#555")
    return save(fig, path)


# ---------------------------------------------------------------------------
# 10. 分数乘法面积模型（a/b × c/d）
# ---------------------------------------------------------------------------
def fraction_rect(path, a=(1, 2), b=(3, 4), figsize=(3.4, 3.0)):
    """长方形面积模型表示 a/b × c/d：纵向 a/b、横向 c/d，双重阴影=积。"""
    an, ad = a; bn, bd = b
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    ax.set_xlim(-0.05, 1.28); ax.set_ylim(-0.12, 1.05)
    ax.axis("off"); ax.set_aspect("equal")
    aw = an / ad; bh = bn / bd
    ax.add_patch(plt.Rectangle((0, 0), aw, 1, facecolor="#bcd4ea", edgecolor="none"))   # 纵向 a/b
    ax.add_patch(plt.Rectangle((0, 1 - bh), 1, bh, facecolor="#cfe8c8", edgecolor="none"))  # 横向 c/d
    ax.add_patch(plt.Rectangle((0, 1 - bh), aw, bh, facecolor="#93b4d6", edgecolor="none"))  # 交集=积
    for i in range(1, ad):
        ax.plot([i / ad, i / ad], [0, 1], color="#1a1a1a", lw=0.6)
    for j in range(1, bd):
        ax.plot([0, 1], [1 - j / bd, 1 - j / bd], color="#1a1a1a", lw=0.6)
    ax.add_patch(plt.Rectangle((0, 0), 1, 1, fill=False, lw=1.6, edgecolor="#1a1a1a"))
    ax.text(aw / 2, -0.06, "%d/%d" % (an, ad), ha="center", va="top", fontsize=11)
    ax.text(1.04, 1 - bh / 2, "%d/%d" % (bn, bd), ha="left", va="center", fontsize=11)
    ax.text(aw / 2, 1 - bh / 2, "%d/%d" % (an * bn, ad * bd), ha="center", va="center", fontsize=10)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 物理电路图（初中：电流和电路 / 串并联 / 电流表）
# ---------------------------------------------------------------------------
def _wire(ax, pts, lw=1.6, color="#1a1a1a"):
    """按折点列画导线。"""
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    ax.plot(xs, ys, color=color, lw=lw, solid_capstyle="round", zorder=1)


def _battery_v(ax, x, y0, y1, cells=1):
    """竖直电池组：最上线为长线（正极），长、短线交替。"""
    import math as _m
    h = y1 - y0; n = cells * 2; step = h / n
    for idx in range(n):
        yy = y1 - idx * step
        half = 0.42 if idx % 2 == 0 else 0.18   # 顶线长（+）
        ax.plot([x - half, x + half], [yy, yy], color="#1a1a1a", lw=2.0, zorder=2)


def _switch_h(ax, cx, cy, closed=False, gap=0.30):
    """水平导线中的开关：两接线柱 + 闸刀（默认断开）。"""
    ax.plot([cx - gap], [cy], marker="o", ms=3.2, color="#1a1a1a", zorder=3)
    ax.plot([cx + gap], [cy], marker="o", ms=3.2, color="#1a1a1a", zorder=3)
    if closed:
        ax.plot([cx - gap, cx + gap], [cy, cy], color="#1a1a1a", lw=1.8, zorder=2)
    else:
        ax.plot([cx - gap, cx + gap * 0.78], [cy, cy + 0.42], color="#1a1a1a", lw=1.8, zorder=2)


def _bulb(ax, cx, cy, r=0.34):
    """小灯泡：圆圈内打叉。"""
    ax.add_patch(plt.Circle((cx, cy), r, fill=False, ec="#1a1a1a", lw=1.6, zorder=2))
    d = r * 0.70
    ax.plot([cx - d, cx + d], [cy - d, cy + d], color="#1a1a1a", lw=1.1, zorder=2)
    ax.plot([cx - d, cx + d], [cy + d, cy - d], color="#1a1a1a", lw=1.1, zorder=2)


def _meter(ax, cx, cy, letter="A", r=0.34):
    """电表：圆圈内字母（A 电流表 / V 电压表）。"""
    ax.add_patch(plt.Circle((cx, cy), r, fill=False, ec="#1a1a1a", lw=1.6, zorder=2))
    ax.text(cx, cy, letter, ha="center", va="center", fontsize=12, color="#1a1a1a", zorder=3)


def circuit_series(path, figsize=(6.6, 2.9), points=None):
    """串联电路图：电池组 + 开关 S + 灯 L1、L2 + 电流表 A。
    points=['A','B','C'] 时在顶线标出三个测量点（探究串联电流规律用）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.8, 10.8); ax.set_ylim(-0.8, 5.3)
    yt = 4.0
    comps = [("S", 1.0, 1.6, "switch"), ("L1", 3.4, 4.2, "bulb"),
             ("L2", 5.4, 6.2, "bulb"), ("A", 7.8, 8.6, "meter")]
    x_prev = 0.0
    for lab, x0, x1, kind in comps:
        _wire(ax, [(x_prev, yt), (x0, yt)]); x_prev = x1
        if kind == "switch":
            _switch_h(ax, (x0 + x1) / 2, yt)
        elif kind == "bulb":
            _bulb(ax, (x0 + x1) / 2, yt)
        else:
            _meter(ax, (x0 + x1) / 2, yt, "A")
        ax.text((x0 + x1) / 2, yt + 0.55, lab, ha="center", fontsize=12)
    _wire(ax, [(x_prev, yt), (10.0, yt)])
    _wire(ax, [(10.0, yt), (10.0, 0.0)])
    _wire(ax, [(10.0, 0.0), (0.0, 0.0)])
    _battery_v(ax, 0.0, 1.2, 2.8, cells=2)
    _wire(ax, [(0.0, 0.0), (0.0, 1.2)]); _wire(ax, [(0.0, 2.8), (0.0, yt)])
    ax.text(0.30, 2.92, "+", fontsize=12); ax.text(0.30, 0.92, "-", fontsize=12)
    if points:
        for lab, xx in zip(points, [2.6, 4.8, 7.0]):
            ax.plot([xx], [yt], marker="o", ms=4.5, color="#1a1a1a", zorder=4)
            ax.text(xx, yt - 0.60, lab, ha="center", fontsize=12)
    return save(fig, path)


def circuit_parallel(path, figsize=(6.6, 3.1), meters=("A",)):
    """并联电路图：干路（开关 S + 电流表）+ 两支路各一只灯泡。
    meters=('A',)          干路一块表（A）；
    meters=('A','B','C')   干路/支路1/支路2 各一块表（探究并联电流规律用）；
    meters=('A1','A2')     干路 A1 + 支路1 A2（计算题用）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-0.8, 10.8); ax.set_ylim(-0.9, 5.3)
    yt, yb = 4.2, 0.6
    x1b, x2b = 5.0, 7.6
    # 干路：开关 + [干路电流表]
    _wire(ax, [(0.0, yt), (1.0, yt)])
    _switch_h(ax, 1.3, yt)
    ax.text(1.3, yt + 0.55, "S", ha="center", fontsize=12)
    x_next = 1.6
    if meters and meters[0]:
        _meter(ax, 2.8, yt, "A" if meters[0] == "A" else meters[0])
        ax.text(2.8, yt + 0.55, meters[0], ha="center", fontsize=12)
        _wire(ax, [(1.6, yt), (2.46, yt)]); _wire(ax, [(3.14, yt), (x1b, yt)])
    else:
        _wire(ax, [(1.6, yt), (x1b, yt)])
    _wire(ax, [(x1b, yt), (x2b, yt)])
    # 支路 1：L1 [+ 支路电流表]
    _bulb(ax, x1b, yt - 1.0)
    ax.text(x1b - 0.60, yt - 1.0, "L1", fontsize=12, va="center", ha="right")
    if len(meters) >= 2 and meters[1]:
        _meter(ax, x1b, yt - 2.0, "A" if meters[1] == "B" else meters[1])
        ax.text(x1b - 0.60, yt - 2.0, meters[1], fontsize=12, va="center", ha="right")
        _wire(ax, [(x1b, yt), (x1b, yt - 1.34)]); _wire(ax, [(x1b, yt - 1.66), (x1b, yt - 2.34)])
        _wire(ax, [(x1b, yt - 2.66), (x1b, yb)])
    else:
        _wire(ax, [(x1b, yt), (x1b, yb)])
    # 支路 2：L2 [+ 支路电流表]
    _bulb(ax, x2b, yt - 1.0)
    ax.text(x2b + 0.60, yt - 1.0, "L2", fontsize=12, va="center")
    if len(meters) >= 3 and meters[2]:
        _meter(ax, x2b, yt - 2.0, "A" if meters[2] == "C" else meters[2])
        ax.text(x2b + 0.60, yt - 2.0, meters[2], fontsize=12, va="center")
        _wire(ax, [(x2b, yt), (x2b, yt - 1.34)]); _wire(ax, [(x2b, yt - 1.66), (x2b, yt - 2.34)])
        _wire(ax, [(x2b, yt - 2.66), (x2b, yb)])
    else:
        _wire(ax, [(x2b, yt), (x2b, yb)])
    # 底边与电池组
    _wire(ax, [(x2b, yb), (0.0, yb)])
    _battery_v(ax, 0.0, yb + 0.3, yt - 0.3, cells=2)
    ax.text(0.30, yt - 0.18, "+", fontsize=12); ax.text(0.30, yb + 0.18, "-", fontsize=12)
    return save(fig, path)


def circuit_real(path, figsize=(6.2, 3.6)):
    """实物连接图：电池组、开关、两只小灯泡串联（供"画电路图"题使用）。"""
    fig, ax = _new_fig(figsize)
    ax.set_xlim(0, 5.6); ax.set_ylim(0, 4.7)
    # 电池组（左下）
    ax.add_patch(plt.Rectangle((0.5, 0.7), 1.5, 0.75, fill=False, ec="#1a1a1a", lw=1.6))
    for xx in (0.85, 1.65):
        ax.plot([xx], [1.45], marker="o", ms=6, mfc="white", mec="#1a1a1a", mew=1.4, zorder=3)
    ax.text(0.85, 1.64, "+", fontsize=11, ha="center")
    ax.text(1.65, 1.64, "-", fontsize=11, ha="center")
    ax.text(1.25, 1.02, "电池组", fontsize=11, ha="center")
    # 开关（左上）
    ax.add_patch(plt.Rectangle((0.7, 3.3), 1.0, 0.42, fill=False, ec="#1a1a1a", lw=1.6))
    for xx in (0.85, 1.45):
        ax.plot([xx], [3.72], marker="o", ms=5, mfc="white", mec="#1a1a1a", zorder=3)
    ax.plot([0.85, 1.24], [3.72, 4.14], color="#1a1a1a", lw=1.8)
    ax.text(1.2, 3.06, "开关", fontsize=11, ha="center")
    # 两只灯泡（右上 L1、右下 L2）
    for cx, cy, lab in ((4.1, 3.7, "L1"), (4.1, 1.1, "L2")):
        ax.add_patch(plt.Circle((cx, cy), 0.36, fill=False, ec="#1a1a1a", lw=1.6, zorder=2))
        d = 0.25
        ax.plot([cx - d, cx + d], [cy - d, cy + d], color="#1a1a1a", lw=1.1)
        ax.plot([cx - d, cx + d], [cy + d, cy - d], color="#1a1a1a", lw=1.1)
        ax.add_patch(plt.Rectangle((cx - 0.16, cy - 0.62), 0.32, 0.26, fill=False, ec="#1a1a1a", lw=1.3))
        ax.text(cx + 0.58, cy, lab, fontsize=12, va="center")
    # 导线：电池+ → 开关 → L1 → L2 → 电池-
    _wire(ax, [(0.85, 1.45), (0.85, 3.72)])
    _wire(ax, [(1.45, 3.72), (1.45, 4.35), (4.1, 4.35), (4.1, 4.06)])
    _wire(ax, [(4.1, 3.34), (4.1, 1.46)])
    _wire(ax, [(4.1, 0.48), (4.1, 0.25), (1.65, 0.25), (1.65, 1.45)])
    return save(fig, path)


def _mini_circuit(ax, case):
    """辨识面板单格：A 电源短路 / B 灯 L2 局部短路 / C 正常通路 / D 断路。"""
    yt, yb = 2.4, 0.5
    _battery_v(ax, 0.3, 0.9, 1.9, cells=1)
    _wire(ax, [(0.3, yb), (0.3, 0.9)]); _wire(ax, [(0.3, 1.9), (0.3, yt)])
    _wire(ax, [(5.0, yt), (5.0, yb)]); _wire(ax, [(5.0, yb), (0.3, yb)])
    if case == "D":                      # 开关与 L1 之间断开
        _wire(ax, [(0.3, yt), (1.55, yt)])
        _wire(ax, [(2.2, yt), (5.0, yt)])
    else:
        _wire(ax, [(0.3, yt), (5.0, yt)])
    _switch_h(ax, 1.2, yt)
    _bulb(ax, 2.6, yt); _bulb(ax, 3.8, yt)
    ax.text(1.2, yt - 0.55, "S", ha="center", fontsize=9)
    ax.text(2.6, yt - 0.55, "L1", ha="center", fontsize=9)
    ax.text(3.8, yt - 0.55, "L2", ha="center", fontsize=9)
    if case == "A":                      # 导线直接并在电源两极
        _wire(ax, [(0.3, yt), (-0.25, yt), (-0.25, yb), (0.3, yb)])
    elif case == "B":                    # 导线并联在 L2 两端
        _wire(ax, [(3.45, yt), (3.45, 2.95), (4.15, 2.95), (4.15, yt)])


def circuit_panel_identify(path, figsize=(7.2, 4.6)):
    """四格电路辨识面板（A/B/C/D）：闭合开关后，只有 C（正常串联通路）两灯都发光。"""
    fig, axes = plt.subplots(2, 2, figsize=figsize, dpi=200)
    for ax, tag in zip(axes.flat, ["A", "B", "C", "D"]):
        ax.set_aspect("equal"); ax.axis("off")
        ax.set_xlim(-0.7, 5.5); ax.set_ylim(-0.2, 3.3)
        ax.text(-0.45, 2.85, tag, fontsize=15, fontweight="bold")
        _mini_circuit(ax, tag)
    return save(fig, path)


def ammeter_dial(path, value=0.32, rng=0.6, figsize=(3.6, 2.7)):
    """电流表表盘（双量程）：上排刻度 0~0.6A、下排 0~3A；指针按 value/rng 比例偏转。"""
    import math
    fig, ax = _new_fig(figsize)
    ax.set_xlim(-1.7, 1.7); ax.set_ylim(-0.85, 1.55)
    for i in range(31):
        tt = i / 30.0
        aa = math.radians(210 - 240 * tt)
        r1 = 0.86 if i % 5 else 0.78
        ax.plot([math.cos(aa) * r1, math.cos(aa) * 0.99],
                [math.sin(aa) * r1, math.sin(aa) * 0.99],
                color="#1a1a1a", lw=1.0 if i % 5 else 1.6)
        if i % 5 == 0:
            ax.text(math.cos(aa) * 1.16, math.sin(aa) * 1.16, "%.1f" % (0.6 * tt),
                    ha="center", va="center", fontsize=9)
            ax.text(math.cos(aa) * 0.62, math.sin(aa) * 0.62, "%g" % (3.0 * tt),
                    ha="center", va="center", fontsize=9)
    aa = math.radians(210 - 240 * (value / rng))
    ax.plot([0, math.cos(aa) * 0.84], [0, math.sin(aa) * 0.84],
            color="#1a1a1a", lw=1.8, zorder=3)
    ax.plot([0], [0], marker="o", ms=4, color="#1a1a1a")
    ax.text(0, -0.44, "A", ha="center", fontsize=12)
    ax.text(0, -0.76, "-    0.6    3", ha="center", fontsize=9)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 13. 化学实验装置图（第八单元 金属和金属材料）
# ---------------------------------------------------------------------------
def _tube_outline(ax, cx, base_y=0.0, h=3.0, r=0.5, lw=1.6, color="#1a1a1a"):
    """试管外轮廓：直筒 + 半圆底。"""
    import math
    ax.plot([cx-r, cx-r], [base_y+r, base_y+h], color=color, lw=lw)
    ax.plot([cx+r, cx+r], [base_y+r, base_y+h], color=color, lw=lw)
    th = [math.pi + i*math.pi/40 for i in range(41)]
    ax.plot([cx + r*math.cos(t) for t in th],
            [base_y + r + r*math.sin(t) for t in th], color=color, lw=lw)


def _tube_liquid(ax, cx, y_bot, y_top, r=0.5, color="#dbeafe"):
    """试管内液体（浅蓝）：矩形 + 半圆底，液面画横线。y_top 为液面高度。"""
    import math
    ax.add_patch(plt.Rectangle((cx-r, y_bot+r), 2*r, max(y_top-y_bot-r, 0),
                               facecolor=color, edgecolor="none", zorder=1))
    th = [math.pi + i*math.pi/40 for i in range(41)]
    xs = [cx + r*math.cos(t) for t in th]
    ys = [y_bot + r + r*math.sin(t) for t in th]
    ax.fill(xs + [cx+r, cx-r], ys + [y_bot+r, y_bot+r],
            color=color, zorder=1)
    ax.plot([cx-r, cx+r], [y_top, y_top], color="#1a1a1a", lw=1.2, zorder=2)


def _nail(ax, cx, cy, w=0.5, metal="#9aa0a6"):
    """铁钉：钉身矩形 + 顶部弯钩。"""
    ax.add_patch(plt.Rectangle((cx-w/2, cy-0.09), w, 0.18,
                               facecolor=metal, edgecolor="#1a1a1a",
                               lw=1.0, zorder=3))
    ax.plot([cx, cx], [cy+0.09, cy+0.34], color="#1a1a1a", lw=1.3, zorder=3)
    ax.plot([cx, cx+0.2], [cy+0.34, cy+0.48], color="#1a1a1a", lw=1.3, zorder=3)


def _stopper(ax, cx, y, w=0.98, h=0.3):
    """试管口橡皮塞。"""
    ax.add_patch(plt.Rectangle((cx-w/2, y), w, h, facecolor="#6b7280",
                               edgecolor="#1a1a1a", lw=1.0, zorder=3))


def rust_tubes(path, figsize=(7.4, 3.4)):
    """铁钉锈蚀条件探究（教材经典实验，人教九下第八单元课题3）：
       试管(1) 干燥空气（底部放干燥剂、管口塞紧）；
       试管(2) 只有水（铁钉浸没在经煮沸并油封的蒸馏水中、管口塞紧）；
       试管(3) 水和空气（铁钉一半浸在水里、管口敞开）。
       防泄题：图只呈现装置条件，生锈结论由学生自行推导。"""
    fig, ax = _new_fig(figsize)
    h, r = 3.0, 0.5
    # (1) 干燥空气
    cx = 0.0
    _tube_outline(ax, cx, 0, h, r)
    for dx in (-0.2, 0.04):                       # 底部干燥剂
        ax.add_patch(plt.Rectangle((cx+dx, 0.12), 0.17, 0.17,
                                   facecolor="#e5e7eb", edgecolor="#1a1a1a",
                                   lw=0.8, zorder=2))
    _nail(ax, cx, 1.75)
    _stopper(ax, cx, h)
    # (2) 只有水（煮沸蒸馏水 + 油层隔绝空气）
    cx = 2.4
    _tube_outline(ax, cx, 0, h, r)
    _tube_liquid(ax, cx, 0.0, 2.5, r)
    ax.add_patch(plt.Rectangle((cx-r, 2.5), 2*r, 0.16, facecolor="#fde68a",
                               edgecolor="#1a1a1a", lw=0.8, zorder=2))   # 油层
    _nail(ax, cx, 1.2)
    _stopper(ax, cx, h)
    # (3) 水 + 空气（铁钉横跨水与空气）
    cx = 4.8
    _tube_outline(ax, cx, 0, h, r)
    _tube_liquid(ax, cx, 0.0, 1.35, r)
    _nail(ax, cx, 1.35)
    for i, c in enumerate((0.0, 2.4, 4.8)):
        ax.text(c, h+0.55, "(%d)" % (i+1), fontsize=14, ha="center", va="center")
    ax.set_xlim(-1.2, 5.8); ax.set_ylim(-0.35, h+1.0)
    return save(fig, path)


def acid_tubes(path, figsize=(7.0, 3.2)):
    """金属活动性顺序探究（人教九下第八单元课题2）：
       四支相同试管中分别放入大小相近的 Mg、Zn、Fe、Cu 片，
       再加入相同浓度、相同体积的稀盐酸（液面等高即等体积）。
       防泄题：不画气泡——气泡多少/快慢即活动性答案，画出来会泄题；
       学生需自行预测现象顺序并解释。"""
    fig, ax = _new_fig(figsize)
    h, r = 2.8, 0.5
    metals = [("Mg", "#c7c9cc"), ("Zn", "#a9adb2"),
              ("Fe", "#7f858c"), ("Cu", "#b5651d")]
    for i, (name, color) in enumerate(metals):
        cx = i*2.2
        _tube_outline(ax, cx, 0, h, r)
        _tube_liquid(ax, cx, 0.0, 1.5, r)                     # 等体积稀盐酸
        ax.add_patch(plt.Rectangle((cx-0.35, 1.15), 0.7, 0.16,
                                   facecolor=color, edgecolor="#1a1a1a",
                                   lw=1.0, zorder=3))         # 大小相近的金属片
        ax.text(cx, h+0.5, "(%d)" % (i+1), fontsize=14,
                ha="center", va="center")
    ax.set_xlim(-1.2, 6.9); ax.set_ylim(-0.3, h+0.9)
    return save(fig, path)


def blast_furnace(path, figsize=(4.8, 5.2)):
    """高炉炼铁剖面示意图（无文字标注版）：
       炉顶三个加料口（向下箭头）、炉身料层斜纹、两侧热风进口、
       炉缸两个出口（铁水口/炉渣口不标注，供学生指认）。
       防泄题：不写任何文字标注，装置识别信息由学生答出。"""
    fig, ax = _new_fig(figsize)
    outline = [(-1.2, 5.2), (-1.55, 4.3), (-3.1, 2.3), (-3.3, 1.9),
               (-2.5, 0.9), (-1.7, 0.25), (0.0, 0.1),
               (1.7, 0.25), (2.5, 0.9), (3.3, 1.9),
               (3.1, 2.3), (1.55, 4.3), (1.2, 5.2)]
    xs = [p[0] for p in outline]; ys = [p[1] for p in outline]
    ax.plot(xs + [xs[0]], ys + [ys[0]], color="#1a1a1a", lw=1.8)
    # 分层虚线：炉喉/炉身、炉身/炉腰、炉腰/炉腹、炉腹/炉缸
    for y, hw in ((4.3, 1.55), (2.3, 3.1), (1.9, 3.3), (0.9, 2.5)):
        ax.plot([-hw, hw], [y, y], ls="--", color="#9ca3af", lw=1.0)
    # 炉身料层斜纹（浅灰，表示固体炉料下降）
    for k in range(5):
        y0 = 2.55 + k*0.35
        hw = 3.05 - (y0-2.3)*0.45
        ax.plot([-hw*0.8, hw*0.8], [y0, y0-0.26], color="#d1d5db", lw=1.2)
    # 炉顶三个加料口（小料斗 + 向下箭头）
    for dx in (-0.8, 0.0, 0.8):
        ax.add_patch(plt.Rectangle((dx-0.17, 5.2), 0.34, 0.55,
                                   facecolor="#e5e7eb", edgecolor="#1a1a1a", lw=1.0))
        ax.annotate("", xy=(dx, 5.05), xytext=(dx, 5.95),
                    arrowprops=dict(arrowstyle="-|>", color="#1a1a1a", lw=1.3))
    # 两侧热风进口
    for sx in (-1, 1):
        ax.add_patch(plt.Circle((sx*3.6, 1.3), 0.17, facecolor="white",
                                edgecolor="#1a1a1a", lw=1.2))
        ax.annotate("", xy=(sx*3.0, 1.3), xytext=(sx*3.95, 1.3),
                    arrowprops=dict(arrowstyle="-|>", color="#1a1a1a", lw=1.3))
    # 炉缸两个出口（左、右各一，不标注名称）
    for sx in (-1, 1):
        ax.add_patch(plt.Rectangle((sx*0.9-0.18, 0.0), 0.36, 0.35,
                                   facecolor="white", edgecolor="#1a1a1a", lw=1.2))
        ax.plot([sx*0.9, sx*0.9], [-0.12, -0.55], color="#1a1a1a", lw=1.6)
    ax.set_xlim(-4.7, 4.7); ax.set_ylim(-0.9, 6.3)
    return save(fig, path)


# ---------------------------------------------------------------------------
# 命令行示例
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    out = sys.argv[2] if len(sys.argv) > 2 else "."
    cmd = sys.argv[1] if len(sys.argv) > 1 else "demo"
    if cmd == "circle":
        print(circle_chord(5, 4, os.path.join(out, "fig_chord.png")))
    elif cmd == "tree":
        print(coin_tree(os.path.join(out, "fig_tree.png")))
    elif cmd == "shapes":
        print(shapes_symmetry(os.path.join(out, "fig_shapes.png")))
    elif cmd == "parabola":
        print(parabola(os.path.join(out, "fig_parabola.png"), a=1, h=0, k=0))
    elif cmd == "sector":
        print(sector(os.path.join(out, "fig_sector.png")))
    elif cmd == "rotation":
        print(rotation(os.path.join(out, "fig_rotation.png")))
    elif cmd == "triangle":
        print(right_triangle(os.path.join(out, "fig_triangle.png")))
    elif cmd == "circuit-series":
        print(circuit_series(os.path.join(out, "fig_series.png"), points=["A", "B", "C"]))
    elif cmd == "circuit-parallel":
        print(circuit_parallel(os.path.join(out, "fig_parallel.png"), meters=("A", "B", "C")))
    elif cmd == "circuit-real":
        print(circuit_real(os.path.join(out, "fig_real.png")))
    elif cmd == "circuit-panel":
        print(circuit_panel_identify(os.path.join(out, "fig_panel.png")))
    elif cmd == "ammeter":
        print(ammeter_dial(os.path.join(out, "fig_ammeter.png")))
    elif cmd == "rust":
        print(rust_tubes(os.path.join(out, "fig_rust_tubes.png")))
    elif cmd == "acid":
        print(acid_tubes(os.path.join(out, "fig_acid_tubes.png")))
    elif cmd == "furnace":
        print(blast_furnace(os.path.join(out, "fig_blast_furnace.png")))
    else:
        d = os.path.join(out, "demo")
        os.makedirs(d, exist_ok=True)
        print(circle_chord(5, 4, os.path.join(d, "fig_chord.png")))
        print(coin_tree(os.path.join(d, "fig_tree.png")))
        print(shapes_symmetry(os.path.join(d, "fig_shapes.png")))
        print(parabola(os.path.join(d, "fig_parabola.png"), a=1, h=0, k=0))
        print(sector(os.path.join(d, "fig_sector.png")))
        print(rotation(os.path.join(d, "fig_rotation.png")))
        print(right_triangle(os.path.join(d, "fig_triangle.png")))
