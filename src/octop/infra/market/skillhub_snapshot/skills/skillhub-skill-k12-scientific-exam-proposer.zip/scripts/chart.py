#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
教学用图生成助手 · 数据图表生成脚本（B 类图）
================================================
支持类型：
    bar      分组/单系列柱状图
    stacked  堆叠柱状图
    line     折线图
    pie      饼图
    scatter  散点图
    radar    雷达图（多维对比）
    box      箱线图（每组一个分布）

输出：
    PNG（默认 300dpi，白底）
    --svg 可同时导出 SVG 矢量源（老师改数据即可重出图）

中文字体：自动探测 SimHei / Microsoft YaHei / SimSun，找不到则退回 DejaVu。

依赖：matplotlib, numpy   （pip install matplotlib numpy）
数据：
    CSV：第一列为类别标签，其余列为各系列数值（首行表头为系列名）
    JSON：{"labels":[...], "series":{系列名:[数值...]}, "series_names":[...]可选}
          box 类型 JSON 特例：{"series":{组名:[若干原始值...]}}，由脚本计算四分位。

用法示例：
    python chart.py --demo
    python chart.py --type bar --data scores.csv --out 各班平均分.png --svg 各班平均分.svg
    python chart.py --type radar --data ability.json --out 能力雷达.png
"""

import argparse
import csv
import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager


# ----------------------------------------------------------------------
# 中文字体
# ----------------------------------------------------------------------
def setup_font():
    candidates = ["SimHei", "Microsoft YaHei", "SimSun",
                  "WenQuanYi Zen Hei", "Heiti SC", "Source Han Sans SC"]
    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((c for c in candidates if c in available), "DejaVu Sans")
    plt.rcParams["font.sans-serif"] = [chosen]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.family"] = "sans-serif"
    return chosen


# ----------------------------------------------------------------------
# 数据读取
# ----------------------------------------------------------------------
def load_data(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".json":
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    # CSV：第一列标签，其余列数值
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r]
    header = rows[0]
    labels = [r[0] for r in rows[1:]]
    names = header[1:] or ["数值"]
    series = {n: [] for n in names}
    for r in rows[1:]:
        for i, n in enumerate(names):
            series[n].append(float(r[i + 1]))
    return {"labels": labels, "series": series, "series_names": names}


def demo_data():
    return {
        "labels": ["一班", "二班", "三班", "四班", "五班"],
        "series": {"语文": [78.5, 82.0, 75.3, 88.1, 80.6],
                   "数学": [81.2, 79.4, 83.0, 85.5, 77.8]},
        "series_names": ["语文", "数学"],
    }


def print_summary(d, ctype):
    print("\n[数据确认] 请老师核对以下数据是否正确：")
    if ctype == "box":
        for name, vals in d["series"].items():
            print(f"  组「{name}」：共 {len(vals)} 个原始值，范围 {min(vals)}~{max(vals)}")
    else:
        labels = d.get("labels", [])
        print(f"  类别（{len(labels)} 个）：{labels}")
        for name, vals in d["series"].items():
            print(f"  系列「{name}」：{vals}")


# ----------------------------------------------------------------------
# 绘图
# ----------------------------------------------------------------------
PALETTE = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
           "#9467bd", "#8c564b", "#e377c2", "#7f7f7f"]


def _style(ax, args):
    if args.title:
        ax.set_title(args.title, fontsize=16, fontweight="bold")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def plot_bar(d, args):
    labels = d["labels"]; series = d["series"]; names = d["series_names"]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi)
    x = np.arange(len(labels))
    n = max(len(names), 1)
    w = 0.8 / n
    for i, name in enumerate(names):
        offset = (i - (n - 1) / 2) * w
        bars = ax.bar(x + offset, series[name], width=w, label=name,
                      color=PALETTE[i % len(PALETTE)])
        if args.show_values:
            ax.bar_label(bars, fmt="%.1f", fontsize=9, padding=2)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=args.xrot,
                       ha="right" if args.xrot else "center")
    if args.ylabel:
        ax.set_ylabel(args.ylabel)
    if args.xlabel:
        ax.set_xlabel(args.xlabel)
    if len(names) > 1:
        ax.legend(frameon=False)
    _style(ax, args)
    return fig, ax


def plot_stacked(d, args):
    labels = d["labels"]; series = d["series"]; names = d["series_names"]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi)
    x = np.arange(len(labels))
    bottom = np.zeros(len(labels))
    for i, name in enumerate(names):
        ax.bar(x, series[name], width=0.6, label=name,
               color=PALETTE[i % len(PALETTE)], bottom=bottom)
        if args.show_values:
            for j, (b, v) in enumerate(zip(bottom, series[name])):
                ax.text(j, b + v / 2, f"{v:.0f}", ha="center", va="center",
                        fontsize=9, color="white")
        bottom = bottom + np.array(series[name])
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=args.xrot,
                       ha="right" if args.xrot else "center")
    if args.ylabel:
        ax.set_ylabel(args.ylabel)
    ax.legend(frameon=False)
    _style(ax, args)
    return fig, ax


def plot_line(d, args):
    labels = d["labels"]; series = d["series"]; names = d["series_names"]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi)
    x = np.arange(len(labels))
    for i, name in enumerate(names):
        ax.plot(x, series[name], marker="o", label=name,
                color=PALETTE[i % len(PALETTE)], linewidth=2)
        if args.show_values:
            for j, v in enumerate(series[name]):
                ax.text(j, v, f"{v:.1f}", fontsize=9,
                        ha="center", va="bottom")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=args.xrot,
                       ha="right" if args.xrot else "center")
    if args.ylabel:
        ax.set_ylabel(args.ylabel)
    if args.xlabel:
        ax.set_xlabel(args.xlabel)
    ax.legend(frameon=False)
    _style(ax, args)
    return fig, ax


def plot_pie(d, args):
    # 饼图：取第一个系列；labels 为扇区
    name = d["series_names"][0]
    vals = d["series"][name]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi)
    wedges, _t, _a = ax.pie(
        vals, labels=d["labels"], autopct="%1.1f%%",
        colors=PALETTE, startangle=90,
        wedgeprops=dict(width=0.6 if args.donut else 1.0, edgecolor="white"))
    ax.set_title((args.title or name), fontsize=16, fontweight="bold")
    ax.axis("equal")
    return fig, ax


def plot_scatter(d, args):
    labels = d["labels"]; series = d["series"]; names = d["series_names"]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi)
    x = np.arange(len(labels))
    for i, name in enumerate(names):
        ax.scatter(x, series[name], label=name, s=60,
                   color=PALETTE[i % len(PALETTE)])
        if args.show_values:
            for j, v in enumerate(series[name]):
                ax.text(j, v, f"{v:.1f}", fontsize=9, ha="center", va="bottom")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=args.xrot,
                       ha="right" if args.xrot else "center")
    if args.ylabel:
        ax.set_ylabel(args.ylabel)
    if args.xlabel:
        ax.set_xlabel(args.xlabel)
    ax.legend(frameon=False)
    _style(ax, args)
    return fig, ax


def plot_radar(d, args):
    labels = d["labels"]; series = d["series"]; names = d["series_names"]
    N = len(labels)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi, subplot_kw=dict(polar=True))
    for i, name in enumerate(names):
        vals = list(series[name]) + [series[name][0]]
        ax.plot(angles, vals, label=name, color=PALETTE[i % len(PALETTE)], linewidth=2)
        ax.fill(angles, vals, color=PALETTE[i % len(PALETTE)], alpha=0.12)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    if args.ylabel:
        ax.set_rlabel_position(0)
    ax.set_title(args.title or "雷达图", fontsize=16, fontweight="bold")
    ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.1), frameon=False)
    return fig, ax


def plot_box(d, args):
    # 每组一个分布
    names = list(d["series"].keys())
    data = [d["series"][k] for k in names]
    fig, ax = plt.subplots(figsize=args.figsize, dpi=args.dpi)
    bp = ax.boxplot(data, labels=names, patch_artist=True,
                    medianprops=dict(color="black"))
    for patch, c in zip(bp["boxes"], PALETTE):
        patch.set_facecolor(c)
        patch.set_alpha(0.5)
    if args.ylabel:
        ax.set_ylabel(args.ylabel)
    _style(ax, args)
    return fig, ax


# ----------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------
DISPATCH = {
    "bar": plot_bar, "stacked": plot_stacked, "line": plot_line,
    "pie": plot_pie, "scatter": plot_scatter, "radar": plot_radar,
    "box": plot_box,
}


def main():
    p = argparse.ArgumentParser(description="教学数据图表生成器（B类图）")
    p.add_argument("--type", default="bar",
                   choices=["bar", "stacked", "line", "pie", "scatter", "radar", "box"])
    p.add_argument("--data", help="CSV 或 JSON 数据文件")
    p.add_argument("--out", default="chart.png", help="输出 PNG 路径")
    p.add_argument("--svg", help="可选：同时导出的 SVG 矢量源路径")
    p.add_argument("--title", default="")
    p.add_argument("--xlabel", default="")
    p.add_argument("--ylabel", default="")
    p.add_argument("--xrot", type=float, default=0, help="X 轴标签旋转角度")
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--figsize", nargs=2, type=float, default=[8, 5])
    p.add_argument("--show-values", action="store_true", help="在图上标数值")
    p.add_argument("--donut", action="store_true", help="饼图镂空")
    p.add_argument("--demo", action="store_true", help="用内置示例数据演示")
    args = p.parse_args()

    font = setup_font()
    print(f"[字体] 使用：{font}")

    if args.demo:
        d = demo_data()
        args.type = "bar"
        args.title = "示例：各班平均分对比"
        args.ylabel = "分"
        args.show_values = True
        if not args.out or args.out == "chart.png":
            args.out = "examples/demo_bar.png"
        if not args.svg:
            args.svg = "examples/demo_bar.svg"
    elif args.data:
        d = load_data(args.data)
    else:
        print("错误：请提供 --data 数据文件，或使用 --demo 演示。", file=sys.stderr)
        sys.exit(1)

    if args.type != "box":
        print_summary(d, args.type)

    func = DISPATCH[args.type]
    fig, ax = func(d, args)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    fig.savefig(args.out, dpi=args.dpi, bbox_inches="tight",
                facecolor="white", edgecolor="none")
    print(f"[输出] PNG（{args.dpi}dpi）：{args.out}")

    if args.svg:
        os.makedirs(os.path.dirname(os.path.abspath(args.svg)) or ".", exist_ok=True)
        fig.savefig(args.svg, format="svg", bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        print(f"[输出] SVG 矢量源：{args.svg}")

    print("[自检提醒] 交付前请确认：文字正常 / 方向正确 / 标签无重叠 / 单位清晰 / 黑白打印可辨。")
    plt.close(fig)


if __name__ == "__main__":
    main()
