# -*- coding: utf-8 -*-
r"""selftest_figures.py —— 自检脚本：验证「随题图内嵌」链路端到端可用。

跑一次即可确认五件事：
  1) matplotlib 与中文字体在本机可用（draw_science_figs 能出图）；
  2) A 类 SVG 构件（svg_base）可用，能生成白底黑线、可编辑的矢量图；
  3) B 类数据图（chart.py）可用，柱状图 + 同款 SVG 源能产出；
  4) gen_paper 能内嵌图片、多图并排、自动题图编号（image_caption）；
  5) 每张图分配唯一 docPr 编号，多图不冲突；「有题无图」自检生效；
     另附黑白可辨性灰度自动扫描（六条自检第⑥条辅助）。

用法：
  python scripts/selftest_figures.py [输出目录]
  # 输出目录缺省为 ./selftest_out；生成 docx + 图 + spec，并打印校验结果

注意（Windows）：若 matplotlib 启动即崩（OpenBLAS 内存分配失败），先设环境变量
  set OPENBLAS_NUM_THREADS=1
  set OMP_NUM_THREADS=1
再运行本脚本。
"""
import os
import re
import sys
import json
import zipfile
import subprocess
import warnings

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import draw_science_figs as sf      # noqa: E402
import gen_paper as gp              # noqa: E402
import svg_base as sb               # noqa: E402  （A 类 SVG 构件，新增）
try:
    from PIL import Image
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

SKILL_DIR = os.path.dirname(os.path.abspath(__file__))


def scan_legibility(fig_dir, names):
    """六条自检·第⑥条（能不能用/黑白可辨）辅助自动扫描：
    把每张 PNG 转灰度，检查是否空白、过暗、灰阶对比度是否过低（黑白打印可能难辨）。
    这是辅助项，最终仍需人工过 assets/self_check.md 六条。"""
    if not HAVE_PIL:
        print("[自检] 未装 Pillow，跳过黑白可辨性自动扫描（请人工过 self_check.md）")
        return
    print("\n[自检·黑白可辨] 灰度扫描每张图的线条量与对比度：")
    for name in names:
        p = os.path.join(fig_dir, name)
        try:
            im = Image.open(p).convert("L")
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                px = list(im.getdata())
        except Exception:
            print("  - %s：读取失败" % name)
            continue
        n = len(px)
        mean = sum(px) / n
        var = sum((v - mean) ** 2 for v in px) / n
        gstd = var ** 0.5
        dark = sum(1 for v in px if v < 110) / n
        notes = []
        if dark < 0.01:
            notes.append("线条过少·疑似空白")
        elif dark > 0.75:
            notes.append("画面过暗")
        if gstd < 18:
            notes.append("灰阶对比度偏低·黑白打印或难辨")
        status = "OK" if not notes else "⚠ " + "/".join(notes)
        print("  - %s：深线条 %.1f%%  灰阶σ=%.0f  → %s" % (name, dark * 100, gstd, status))


def main():
    out_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.getcwd(), "selftest_out")
    fig_dir = os.path.join(out_dir, "fig")
    os.makedirs(fig_dir, exist_ok=True)

    # ---------- 1) 出图：物理 3 张 + 化学 2 张 + 生物 2 张 ----------
    jobs = [
        ("lens.png", lambda p: sf.light_lens(p, kind="u>2f")),
        ("force.png", lambda p: sf.force_diagram(p, preset="incline")),
        ("balance.png", lambda p: sf.balance_cylinder(p, mass=82.4, volume=40.0)),
        ("gas_co2.png", lambda p: sf.gas_setup(p, gas="CO2")),
        ("solubility.png", lambda p: sf.solubility_curve(p)),
        ("cell_plant.png", lambda p: sf.cell_structure(p, kind="plant")),
        ("punnett.png", lambda p: sf.punnett(p, "Aa", "Aa")),
    ]
    made = []
    for name, fn in jobs:
        p = os.path.join(fig_dir, name)
        fn(p)
        if not (os.path.exists(p) and os.path.getsize(p) > 2000):
            raise SystemExit("[FAIL] 出图异常：%s" % p)
        made.append(name)
    print("[1/4] 出图 OK：%d 张 ->" % len(made), fig_dir)

    # ---------- 1.5) 新工具链自检：A 类 SVG（svg_base）+ B 类数据图（chart.py） ----------
    # A 类 SVG 构件可用性：生成一个含中英文标注与箭头的示例
    svg_demo = os.path.join(fig_dir, "svgbase_demo.svg")
    sb.save(svg_demo, sb.doc(400, 280,
        sb.text(200, 40, "示例·白底黑线可编辑", size=20, weight="bold")
        + sb.rect(60, 80, 120, 80, rx=8)
        + sb.text(120, 125, "框 A")
        + sb.circle(320, 120, 45)
        + sb.text(320, 125, "圆 B")
        + sb.arrow(180, 120, 275, 120, width=2.5)
        + sb.text(228, 105, "方向→", size=12)
        + sb.line(60, 220, 360, 220, dash="6,4", width=1.5)
        + sb.text(210, 240, "虚线=辅助线", size=12, color="#555555")))
    print("[1.5] A 类 SVG 构件 OK ->", os.path.basename(svg_demo), os.path.getsize(svg_demo), "B")

    # B 类数据图（chart.py）：用内置示例跑一次 bar + 同源 SVG
    chart_png = os.path.join(fig_dir, "chart_demo.png")
    chart_svg = os.path.join(fig_dir, "chart_demo.svg")
    r = subprocess.run([sys.executable, os.path.join(SKILL_DIR, "chart.py"), "--demo",
                        "--out", chart_png, "--svg", chart_svg],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode == 0 and os.path.exists(chart_png) and os.path.exists(chart_svg):
        print("[1.5] B 类数据图 OK ->", os.path.basename(chart_png), os.path.getsize(chart_png), "B",
              "/", os.path.basename(chart_svg), os.path.getsize(chart_svg), "B")
    else:
        print("[1.5][WARN] chart.py 演示失败：", (r.stderr or "").strip()[-300:])

    # 黑白可辨性自动扫描（六条自检第⑥条辅助）
    scan_legibility(fig_dir, made + ["chart_demo.png"])


    # ---------- 2) 构造带配图的 spec（相对路径，故意留一题"有题无图"） ----------
    rel = lambda n: os.path.join("fig", n)      # 相对 spec 所在目录
    spec = {
        "title": "自检卷：初中理科随题图内嵌验证",
        "meta": "学校__________  班级__________  姓名__________    时长：45 分钟    满分：40 分",
        "layout": {"page": "A3"},           # 只写 A3 → 默认 A3 横排两栏
        "sections": [
            {"title": "一、选择题（每小题 3 分，共 6 分）", "type": "single", "items": [
                # 故意不配图：验证自检告警
                {"stem": "如图，凸透镜成像规律正确的是（  ）",
                 "options": ["A. 实像都正立", "B. 虚像都倒立",
                             "C. u>2f 成倒立缩小实像", "D. 虚像能用光屏承接"], "answer": "C"},
                {"stem": "实验室制取二氧化碳应选用的发生与收集装置是（  ）",
                 "image": rel("gas_co2.png"), "image_width": 7.5,
                 "options": ["A. 图示装置", "B. 电解水装置", "C. 过滤装置", "D. 蒸发装置"],
                 "answer": "A"},
            ]},
            {"title": "二、填空与作图（每空 2 分，共 14 分）", "type": "fill", "items": [
                {"stem": "画出物体沿斜面下滑时的受力示意图（重力、支持力、摩擦力）。",
                 "image": rel("force.png"), "image_width": 6.2},
                {"stem": "用天平与量筒测密度，读数如图所示：\n（1）天平读数______ g；（2）量筒读数______ mL。",
                 "image": rel("balance.png"), "image_width": 9.5,
                 "image_caption": "甲：天平读数   乙：量筒读数"},
                {"stem": "根据溶解度曲线判断：t₁℃ 时甲、乙溶解度的大小关系为______。",
                 "image": rel("solubility.png"), "image_width": 7.0},
            ]},
            {"title": "三、实验探究（共 20 分）", "type": "short", "items": [
                # 多图并排 + 题图编号
                {"stem": "如图甲、乙所示，回答下列问题：\n（1）植物细胞特有的结构有______；"
                         "（2）子代中显性性状所占比例为______。",
                 "image": [rel("cell_plant.png"), rel("punnett.png")], "image_width": 13.0,
                 "image_caption": "图甲：植物细胞结构   图乙：遗传图解"},
            ]},
            {"title": "参考答案（教师专用）", "answer_key": True, "items": [
                {"stem": "一、1.C  2.A\n二、（1）82.4  （2）40  （3）甲 > 乙\n"
                         "三、（1）细胞壁、叶绿体、液泡  （2）3/4"}]},
        ],
    }
    spec_path = os.path.join(out_dir, "selftest_spec.json")
    with open(spec_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)
    print("[2/4] spec 已写出 ->", spec_path)

    # ---------- 3) 生成 docx ----------
    out_docx = os.path.join(out_dir, "selftest_figures.docx")
    gp.generate(spec, out_docx, spec_path)
    print("[3/4] docx 已生成 ->", out_docx)

    # ---------- 4) 校验 ----------
    z = zipfile.ZipFile(out_docx)
    media = [n for n in z.namelist() if n.startswith("word/media/")]
    doc = z.read("word/document.xml").decode("utf-8", "ignore")
    docpr = sorted(set(re.findall(r'wp:docPr id="(\d+)"', doc)), key=int)
    ok = True
    expect = 6   # 本 spec 共 6 张图（含 1 组多图并排的 2 张）
    if len(media) != expect:
        print("[WARN] 内嵌图数量应为 %d，实际 %d" % (expect, len(media))); ok = False
    if doc.count("<w:drawing>") != len(media):
        print("[WARN] drawing 引用数与媒体文件数不一致"); ok = False
    if len(docpr) != len(media):
        print("[WARN] docPr 编号不唯一/缺失：", docpr); ok = False
    if "甲：天平读数" not in doc:
        print("[WARN] 题图编号(image_caption)未渲染"); ok = False
    if z.testzip() is not None:
        print("[FAIL] docx 压缩包损坏"); ok = False
    print("[4/4] 校验：媒体 %d 张 / drawing %d / docPr %s / 题图编号 %s"
          % (len(media), doc.count("<w:drawing>"), docpr,
             "有" if "甲：天平读数" in doc else "无"))
    print("RESULT:", "PASS" if ok else "CHECK NEEDED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
