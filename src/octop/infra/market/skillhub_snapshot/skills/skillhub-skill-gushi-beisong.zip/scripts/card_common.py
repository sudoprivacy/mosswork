"""Shared offline PNG rendering and JSON CLI for the poetry cards."""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import tempfile
import time
from functools import lru_cache

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    raise SystemExit("缺少Pillow。请先运行：python3 -m pip install -r requirements.txt")

W, M = 1200, 64
CW = W - 2 * M
BG = "#F8F7EF"
WHITE = "#FFFFFF"
INK = "#2E2F2F"
MUTED = "#59696B"
TEAL = "#1E9BAE"
DEEP = "#0E5F6B"
YELLOW = "#FBC33A"
ORANGE = "#F05A2A"
RED = "#B83C32"  # semantic highlight for rhyme/differences, not a brand replacement
GREEN = "#397C37"


class ValidationError(ValueError):
    """An actionable error in caller-supplied card data."""


def text_value(value, name, max_length=500, allow_empty=False):
    if not isinstance(value, str):
        raise ValidationError(f"{name}必须是字符串")
    if len(value) > max_length:
        raise ValidationError(f"{name}不能超过{max_length}个字符")
    if not allow_empty and not value.strip():
        raise ValidationError(f"{name}不能为空")
    if any(ord(c) < 32 and c not in "\n\t" for c in value):
        raise ValidationError(f"{name}含有不支持的控制字符")
    return value


def get_text(data, key, max_length=500, required=True, default=""):
    if key not in data:
        if required:
            raise ValidationError(f"缺少{key}")
        return text_value(default, key, max_length, allow_empty=True)
    return text_value(data[key], key, max_length, allow_empty=not required)


def bounded_int(value, name, minimum, maximum):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValidationError(f"{name}必须是整数")
    if not minimum <= value <= maximum:
        raise ValidationError(f"{name}须在{minimum}至{maximum}之间")
    return value


def _font_paths(explicit=None, explicit_bold=None):
    if explicit:
        regular = Path(explicit).expanduser()
        bold = Path(explicit_bold).expanduser() if explicit_bold else regular
    else:
        script_dir = Path(__file__).resolve().parent
        candidates = [script_dir.parent / "assets" / "fonts"]
        candidates += [p / "04-模板与公共素材/公共素材/字体/思源黑体"
                       for p in script_dir.parents]
        regular = bold = None
        for directory in candidates:
            r = directory / "SourceHanSansSC-Regular.ttf"
            b = directory / "SourceHanSansSC-Bold.ttf"
            if r.is_file():
                regular, bold = r, b if b.is_file() else r
                break
        if regular is None:
            system_fonts = [
                "/System/Library/Fonts/PingFang.ttc",
                "/System/Library/Fonts/STHeiti Medium.ttc",
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
                "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
                "C:/Windows/Fonts/msyh.ttc",
            ]
            regular = next((Path(p) for p in system_fonts if Path(p).is_file()), None)
            if regular is None:
                raise ValidationError("找不到中文字体。请用--font指定中文TTF/OTF/TTC，或准备assets/fonts/SourceHanSansSC-Regular.ttf")
            bold = regular
        if explicit_bold:
            bold = Path(explicit_bold).expanduser()
    for path in (regular, bold):
        if not path.is_file():
            raise ValidationError(f"字体文件不存在：{path}")
    return str(regular), str(bold)


@lru_cache(maxsize=32)
def _font_face_index(path, bold=False):
    """Choose the Simplified Chinese face rather than a TTC's default region."""
    with open(path, "rb") as stream:
        header = stream.read(12)
    if header[:4] != b"ttcf":
        return 0
    if len(header) != 12:
        raise ValidationError(f"字体集合头不完整：{path}")
    count = struct.unpack(">I", header[8:12])[0]
    if not 1 <= count <= 256:
        raise ValidationError(f"字体集合的子字体数量不合法：{path}")
    faces = []
    for index in range(count):
        family, style = ImageFont.truetype(path, 16, index=index).getname()
        faces.append((index, family, style))
    simplified = [face for face in faces
                  if re.search(r"(?:^|[\s_-])(?:SC|CN)(?:$|[\s_-])", face[1], re.I)]
    if simplified:
        faces = simplified
    elif any(re.search(r"(?:^|[\s_-])(?:JP|KR|TC|HK)(?:$|[\s_-])", face[1], re.I)
             for face in faces):
        raise ValidationError(
            f"字体集合没有简体中文SC子字体：{path}。请用--font指定简体中文字体。")
    # Collections such as Microsoft YaHei do not use regional suffixes.
    styles = (("bold", "semibold", "demibold", "demi", "heavy", "medium", "regular", "normal", "book")
              if bold else ("regular", "normal", "book", "medium", "light", "semibold", "bold"))

    def rank(face):
        index, family, style = face
        style = re.sub(r"[\s_-]", "", style).lower()
        weight = styles.index(style) if style in styles else len(styles)
        return ("mono" in family.lower(), weight, index)

    return min(faces, key=rank)[0]


class Context:
    """All coordinates are in a fixed 1200px design space; CLI scales at export."""

    def __init__(self, font_path=None, bold_font_path=None):
        self.regular_path, self.bold_path = _font_paths(font_path, bold_font_path)
        try:
            self.regular_index = _font_face_index(self.regular_path)
            self.bold_index = _font_face_index(self.bold_path, True)
            self.font(32)
            self.font(32, True)
        except OSError as exc:
            raise ValidationError(f"无法读取字体：{exc}") from exc

    @lru_cache(maxsize=96)
    def font(self, size, bold=False):
        return ImageFont.truetype(self.bold_path if bold else self.regular_path,
                                  max(1, int(size)),
                                  index=self.bold_index if bold else self.regular_index)

    def font_info(self):
        return {
            label: {"path": path, "index": index,
                    "family": self.font(32, bold).getname()[0],
                    "style": self.font(32, bold).getname()[1]}
            for label, path, index, bold in (
                ("regular", self.regular_path, self.regular_index, False),
                ("bold", self.bold_path, self.bold_index, True))
        }

    def measure(self, text, size, bold=False):
        return float(self.font(size, bold).getlength(str(text)))

    def wrap(self, text, width, size, bold=False):
        if width <= 0:
            raise ValidationError("排版区域宽度必须大于零")
        lines = []
        for paragraph in str(text).replace("\t", "    ").split("\n"):
            current = ""
            for char in paragraph:
                if self.measure(char, size, bold) > width:
                    raise ValidationError("文字字号超过可用排版宽度")
                if current and self.measure(current + char, size, bold) > width:
                    lines.append(current)
                    current = char
                else:
                    current += char
            lines.append(current)
        return lines or [""]

    def text_height(self, text, width, size, bold=False, spacing=10):
        lines = self.wrap(text, width, size, bold)
        ascent, descent = self.font(size, bold).getmetrics()
        return len(lines) * (ascent + descent + spacing) - spacing

    def text(self, draw, xy, text, size=32, fill=INK, bold=False,
             max_width=None, spacing=10):
        lines = self.wrap(text, max_width, size, bold) if max_width else str(text).split("\n")
        f = self.font(size, bold)
        ascent, descent = f.getmetrics()
        line_h = ascent + descent + spacing
        x, y = xy
        for line in lines:
            draw.text((x, y), line, font=f, fill=fill, anchor="lt")
            y += line_h
        return len(lines) * line_h - spacing

    def panel(self, height, fill=WHITE, width=CW):
        height = int(math.ceil(height))
        width = int(math.ceil(width))
        if not 1 <= height <= 16000 or not 1 <= width <= W:
            raise ValidationError("卡片分区尺寸超出范围，请减少单次展示内容")
        im = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((0, 0, width - 1, height - 1), radius=26, fill=fill)
        return im, d


class Card:
    def __init__(self, ctx, title, subtitle="", kicker="", accent=TEAL):
        self.ctx = ctx
        self.blocks = []
        pad = 40
        title = f"《{title}》" if not title.startswith("《") else title
        title_h = ctx.text_height(title, CW - 2 * pad, 56, True)
        subtitle_h = ctx.text_height(subtitle, CW - 2 * pad, 27) if subtitle else 0
        height = pad + (48 if kicker else 0) + title_h + (22 + subtitle_h if subtitle else 0) + pad
        im, d = ctx.panel(height, DEEP)
        d.rounded_rectangle((0, 28, 8, height - 29), radius=4, fill=accent)
        y = pad
        if kicker:
            ctx.text(d, (pad, y), kicker, size=24, fill=YELLOW, bold=True)
            y += 48
        ctx.text(d, (pad, y), title, size=56, fill=WHITE, bold=True, max_width=CW - 2 * pad)
        y += title_h + 22
        if subtitle:
            ctx.text(d, (pad, y), subtitle, size=27, fill="#E4F1EE", max_width=CW - 2 * pad)
        self.add(im, gap=0)

    def add(self, image, gap=24):
        if image.width > CW:
            raise ValidationError("内容宽度超出卡片，请调整排版")
        self.blocks.append((image, int(gap)))

    def add_note(self, text):
        pad = 28
        h = self.ctx.text_height(text, CW - 2 * pad, 26) + 2 * pad
        im, d = self.ctx.panel(h, "#E8F1EC")
        self.ctx.text(d, (pad, pad), text, size=26, fill=DEEP, max_width=CW - 2 * pad)
        self.add(im)

    def finish(self):
        height = 2 * M + 44 + sum(im.height + gap for im, gap in self.blocks)
        if height > 20000:
            raise ValidationError("卡片过长，请拆分输入")
        out = Image.new("RGB", (W, height), BG)
        y = M
        for im, gap in self.blocks:
            y += gap
            x = M + (CW - im.width) // 2
            out.paste(im, (x, y), im if im.mode == "RGBA" else None)
            y += im.height
        d = ImageDraw.Draw(out)
        self.ctx.text(d, (M, height - 50), "古诗学伴", size=22, fill=MUTED)
        return out


def _unique_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValidationError(f"JSON字段重复：{key}")
        obj[key] = value
    return obj


def run_cli(kind, renderer, html_renderer=None):
    formats = "PNG卡片或HTML练习" if html_renderer else "PNG卡片"
    parser = argparse.ArgumentParser(description=f"离线生成{kind}{formats}")
    parser.add_argument("--input", required=True, help="UTF-8 JSON文件；-表示标准输入")
    parser.add_argument("--output", required=True, help="输出.png或.html路径" if html_renderer else "输出.png路径")
    parser.add_argument("--width", type=int, default=W, help="PNG输出宽度600—2400，默认1200；HTML自适应")
    parser.add_argument("--font", help="中文TTF/OTF/TTC路径")
    parser.add_argument("--bold-font", help="粗体字体路径；未提供时使用可用字体")
    args = parser.parse_args()
    temporary = None
    try:
        bounded_int(args.width, "width", 600, 2400)
        if args.input == "-":
            raw = sys.stdin.buffer.read(131073)
        else:
            with Path(args.input).open("rb") as stream:
                raw = stream.read(131073)
        if len(raw) > 131072:
            raise ValidationError("输入JSON不能超过128KB")
        data = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_unique_keys)
        if not isinstance(data, dict):
            raise ValidationError("JSON顶层必须是对象")
        output = Path(args.output).expanduser().resolve()
        suffix = output.suffix.lower()
        if suffix not in ({".png", ".html"} if html_renderer else {".png"}):
            raise ValidationError("output必须使用.png或.html扩展名" if html_renderer else "output必须使用.png扩展名")
        started = time.perf_counter()
        if suffix == ".html":
            html, metadata = html_renderer(data)
            encoded = html.encode("utf-8")
            if len(encoded) > 10 * 1024 * 1024:
                raise ValidationError("HTML不能超过10MB，请减少单次内容")
            dimensions = {"format": "html", "bytes": len(encoded)}
        else:
            ctx = Context(args.font, args.bold_font)
            image, metadata = renderer(data, ctx)
            if args.width != W:
                image = image.resize((args.width, round(image.height * args.width / W)), Image.Resampling.LANCZOS)
            dimensions = {"format": "png", "width": image.width, "height": image.height,
                          "fonts": ctx.font_info()}
        output.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".poem-card-", suffix=suffix, dir=output.parent)
        os.close(fd)
        if suffix == ".html":
            Path(temporary).write_bytes(encoded)
        else:
            image.save(temporary, format="PNG", compress_level=3)
        os.replace(temporary, output)
        temporary = None
        print(json.dumps({"ok": True, "kind": kind, "output": str(output),
                          **dimensions,
                          "render_ms": round((time.perf_counter() - started) * 1000, 1),
                          "details": metadata}, ensure_ascii=False))
    except (ValidationError, OSError, ValueError, TypeError, UnicodeError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
