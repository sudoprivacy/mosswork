#!/usr/bin/env python3
"""Render an evidence-based poem practice result card from explicit records."""

from __future__ import annotations

from datetime import date as Date
import math
from typing import Any

from card_common import (
    Card, Context, ValidationError, bounded_int, get_text, text_value,
    run_cli, CW, WHITE, INK, MUTED, TEAL, DEEP, YELLOW, ORANGE, GREEN,
)


_FIELDS = {
    "title", "date", "next_review", "previous_practice_date",
    "first_attempt", "final_attempt", "achievement", "practice_next",
    "encouragement",
}


def _parse_date(value: Any, name: str) -> Date:
    raw = text_value(value, name, max_length=10)
    try:
        parsed = Date.fromisoformat(raw)
    except ValueError as exc:
        raise ValidationError(f"{name}必须是有效的YYYY-MM-DD日期") from exc
    if parsed.isoformat() != raw:
        raise ValidationError(f"{name}必须使用YYYY-MM-DD格式")
    return parsed


def _attempt(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValidationError(f"{name}必须包含independent、complete和errors")
    if set(value) != {"independent", "complete", "errors"}:
        raise ValidationError(f"{name}只能包含且必须包含independent、complete和errors")
    for field in ("independent", "complete"):
        if not isinstance(value[field], bool):
            raise ValidationError(f"{name}.{field}必须是布尔值")
    return {
        "independent": value["independent"],
        "complete": value["complete"],
        "errors": bounded_int(value["errors"], f"{name}.errors", 0, 1000),
    }


def _passed(attempt: dict[str, Any]) -> bool:
    return attempt["independent"] and attempt["complete"] and attempt["errors"] == 0


def derive_result(data: Any) -> dict[str, Any]:
    """Validate records and derive status; never infer facts from praise or titles.

    Returns normalized inputs plus ``outcome``, ``label``, ``detail``,
    ``interval_days``, ``first_success`` and ``final_success``.
    A positive interval alone does not establish retention: the first attempt
    must have been independent, complete and error free.
    """
    if not isinstance(data, dict):
        raise ValidationError("输入必须是JSON对象")
    unknown = set(data) - _FIELDS
    if unknown:
        raise ValidationError("不支持的字段：" + "、".join(sorted(unknown)))

    title = get_text(data, "title", max_length=60)
    day = _parse_date(data.get("date"), "date")
    next_day = _parse_date(data.get("next_review"), "next_review")
    if next_day <= day:
        raise ValidationError("next_review必须晚于本轮date")

    previous_raw = data.get("previous_practice_date")
    previous = None if previous_raw is None else _parse_date(previous_raw, "previous_practice_date")
    if previous is not None and previous > day:
        raise ValidationError("previous_practice_date不能晚于本轮date")
    interval = None if previous is None else (day - previous).days

    first = _attempt(data.get("first_attempt"), "first_attempt")
    has_final = "final_attempt" in data
    final = _attempt(data["final_attempt"], "final_attempt") if has_final else first
    achievement = get_text(data, "achievement", max_length=200)
    encouragement = get_text(data, "encouragement", max_length=100, required=False, default="")
    practice = data.get("practice_next", [])
    if not isinstance(practice, list) or len(practice) > 4:
        raise ValidationError("practice_next必须是最多4项的文字数组")
    practice = [
        text_value(item, f"practice_next[{i}]", max_length=100)
        for i, item in enumerate(practice)
    ]

    first_success, final_success = _passed(first), _passed(final)
    if not final_success:
        outcome, label = "practice", "继续巩固"
        detail = "本轮还有需要练习的地方"
    elif interval is not None and interval > 0 and first_success:
        outcome, label = "retained", "间隔复习通过"
        detail = f"间隔{interval}天 · 首次独立完成"
    else:
        outcome, label = "learned", "本轮背会"
        if first_success:
            detail = "首次独立完成"
        elif interval is not None and interval > 0:
            detail = "复习纠正后完成"
        else:
            detail = "纠正后完成"

    return {
        "title": title, "date": day.isoformat(),
        "next_review": next_day.isoformat(),
        "previous_practice_date": None if previous is None else previous.isoformat(),
        "first_attempt": first, "final_attempt": final,
        "has_final_attempt": has_final,
        "achievement": achievement, "practice_next": practice,
        "encouragement": encouragement,
        "outcome": outcome, "label": label, "detail": detail,
        "interval_days": interval,
        "first_success": first_success, "final_success": final_success,
    }


def _date_text(value: str, year: bool = True) -> str:
    day = Date.fromisoformat(value)
    prefix = f"{day.year}年" if year else ""
    return f"{prefix}{day.month}月{day.day}日"


def _draw_badge(draw: Any, center: tuple[int, int], outcome: str) -> None:
    x, y = center
    fill = YELLOW if outcome == "practice" else GREEN
    symbol = DEEP if outcome == "practice" else WHITE
    draw.ellipse((x - 62, y - 62, x + 62, y + 62), fill=fill)
    if outcome == "practice":
        draw.arc((x - 31, y - 31, x + 31, y + 31), 35, 310, fill=DEEP, width=9)
        draw.polygon(((x + 24, y - 38), (x + 45, y - 20), (x + 17, y - 14)), fill=DEEP)
    elif outcome == "retained":
        points = []
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = 39 if i % 2 == 0 else 19
            points.append((x + math.cos(angle) * radius, y + math.sin(angle) * radius))
        draw.polygon(points, fill=symbol)
    else:
        draw.line(((x - 30, y), (x - 8, y + 23), (x + 35, y - 26)), fill=symbol, width=12)


def _record_panel(ctx: Context, result: dict[str, Any]):
    records = [("首次默写", result["first_attempt"])]
    if result["has_final_attempt"]:
        records.append(("本轮末次默写", result["final_attempt"]))
    gap, padding = 24, 28
    col_width = (CW - gap * (len(records) - 1)) // len(records)
    height = 230
    panel, draw = ctx.panel(height)
    for i, (heading, attempt) in enumerate(records):
        x = i * (col_width + gap)
        draw.rounded_rectangle((x, 0, x + col_width - 1, height - 1), radius=24,
                               fill="#EEF6F4", outline="#D9E8E4", width=2)
        ctx.text(draw, (x + padding, 23), heading, size=28, bold=True, fill=DEEP)
        lines = [
            "无提示独立作答" if attempt["independent"] else "使用了提示或帮助",
            "已写完整" if attempt["complete"] else "尚未写完整",
            f"记录错误：{attempt['errors']}处",
        ]
        for j, text in enumerate(lines):
            ctx.text(draw, (x + padding, 79 + j * 43), text, size=27,
                     fill=INK if j < 2 else (DEEP if attempt["errors"] == 0 else ORANGE))
    return panel


def _prose_panel(ctx: Context, heading: str, body: str, *, fill: str = WHITE):
    width, padding = CW - 72, 36
    body_height = ctx.text_height(body, width, 34, spacing=12)
    panel, draw = ctx.panel(105 + body_height, fill=fill)
    ctx.text(draw, (padding, 28), heading, size=27, fill=DEEP, bold=True)
    ctx.text(draw, (padding, 80), body, size=34, fill=INK, max_width=width, spacing=12)
    return panel


def render(data: Any, ctx: Context):
    result = derive_result(data)
    card = Card(ctx, result["title"], subtitle=_date_text(result["date"]) + " · 本轮练习",
                kicker="看成果，约复习", accent=TEAL)

    panel, draw = ctx.panel(205, fill="#E6F2EE" if result["final_success"] else "#FFF3CC")
    ctx.text(draw, (40, 36), result["label"], size=55, fill=DEEP, bold=True)
    ctx.text(draw, (42, 122), result["detail"], size=30, fill=INK, max_width=CW - 250)
    _draw_badge(draw, (CW - 109, 103), result["outcome"])
    card.add(panel)
    card.add(_record_panel(ctx, result))
    card.add(_prose_panel(ctx, "这次做到的", result["achievement"]))

    if result["practice_next"]:
        body = "\n".join(f"{index + 1}. {item}" for index, item in enumerate(result["practice_next"]))
        card.add(_prose_panel(ctx, "接下来练什么", body))

    encouragement = result["encouragement"]
    if not encouragement:
        encouragement = (
            "这一步，是你自己完成的。"
            if result["final_success"]
            else "按自己的节奏继续，我们一起把下一步练清楚。"
        )
    card.add(_prose_panel(ctx, "给自己的话", encouragement, fill="#FFF3CC"))

    panel, draw = ctx.panel(233, fill=DEEP)
    ctx.text(draw, (36, 27), "下次，我们在这里继续", size=27, fill=WHITE, bold=True)
    ctx.text(draw, (36, 80), _date_text(result["next_review"]), size=49, fill=YELLOW, bold=True)
    ctx.text(draw, (36, 165), "回到本会话，发送“开始练习”。", size=31, fill=WHITE)
    card.add(panel)

    return card.finish(), {
        "outcome": result["outcome"], "label": result["label"], "detail": result["detail"],
        "interval_days": result["interval_days"],
        "first_success": result["first_success"], "final_success": result["final_success"],
    }


if __name__ == "__main__":
    run_cli("result", render)
