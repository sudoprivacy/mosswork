"""Build three deterministic exercises from already checked poem annotations.

Call ``build_exercises(structure_card.validate(data))``. This module does not
infer rhymes, parallelisms, meaning, or a student's understanding. It only
turns the supplied annotations into questions and explicit answer keys.
"""

from __future__ import annotations

from hashlib import sha256
import unicodedata

from card_common import ValidationError


def _shuffled(items: list[dict], salt: str) -> list[dict]:
    """Return a stable non-identity ordering without mutating input objects."""
    ordered = sorted(items, key=lambda item: sha256(
        (salt + "|" + item["id"]).encode("utf-8")).digest())
    if len(ordered) > 1 and [item["id"] for item in ordered] == [item["id"] for item in items]:
        ordered = ordered[1:] + ordered[:1]
    return [dict(item) for item in ordered]


def _rhyme_question(payload: dict) -> dict:
    lines = payload["lines"]
    rhymes = sorted(payload["rhymes"])
    if len(rhymes) < 2:
        raise ValidationError("互动结构版需要rhymes至少标注两处已核对的韵脚")
    if any(index != len(lines[line - 1]) for line, index in rhymes):
        raise ValidationError("互动结构版的rhymes须指向句末字；请核对字位并去掉句末标点")
    if any(unicodedata.category(line[-1])[0] in {"P", "Z"} for line in lines):
        raise ValidationError("互动结构版的lines请去掉句末标点和空格，以便生成句末字练习")
    options = [{"id": f"r{line}", "text": f"第{line}句：{text[-1]}"}
               for line, text in enumerate(lines, 1)]
    answer = [f"r{line}" for line, _ in rhymes]
    evidence = "、".join(f"第{line}句的“{lines[line - 1][-1]}”" for line, _ in rhymes)
    return {
        "id": "rhyme", "type": "multi", "title": "找一找韵脚",
        "prompt": "哪些句末字是刚才学过的韵脚？选出所有符合的项。",
        "options": _shuffled(options, payload["title"] + "|rhyme"),
        "answer": answer,
        "explanation": f"本诗标出的韵脚是{evidence}。把这些字连起来读一读，再回到原句读。",
    }


def _parallel_question(payload: dict, parallel: dict) -> dict:
    upper, lower = parallel["segments"]
    first_line, second_line = parallel["lines"]
    # Equal text denotes the same selectable value, even if it occurs more
    # than once. Do not grade indistinguishable duplicated choices differently.
    options, option_ids = [], {}
    for index, text in enumerate(lower, 1):
        if text not in option_ids:
            option_id = f"p{index}"
            option_ids[text] = option_id
            options.append({"id": option_id, "text": text})
    rows = []
    for index, text in enumerate(upper, 1):
        label = text if upper.count(text) == 1 else f"{text}（第{first_line}句第{index}个词组）"
        rows.append({"id": f"u{index}", "text": label})
    answer = {f"u{index}": option_ids[text] for index, text in enumerate(lower, 1)}
    evidence = "；".join(f"“{left}”对应“{right}”" for left, right in zip(upper, lower))
    return {
        "id": "parallel", "type": "match", "title": "找一找对应关系",
        "prompt": f"给第{first_line}句的每个词组，选出第{second_line}句中对应的词组。",
        "rows": rows,
        "options": _shuffled(options, payload["title"] + "|parallel"),
        "answer": answer,
        "explanation": f"这两句的对应关系是：{evidence}。对照上下两句再读一次。",
    }


def _groups_question(payload: dict) -> dict:
    groups = payload["groups"]
    if len(groups) < 2:
        raise ValidationError("互动结构版第2题需要至少一组含两个词组的parallels，或至少两组groups")
    labels = [group["label"] for group in groups]
    if any(not label.strip() for label in labels) or len(set(labels)) != len(labels):
        raise ValidationError("互动结构版归组题需要不为空且彼此不同的groups.label")
    options = [{"id": f"g{index}", "text": group["label"]}
               for index, group in enumerate(groups, 1)]
    answer = {f"l{line}": f"g{index}" for index, group in enumerate(groups, 1)
              for line in group["lines"]}
    rows = [{"id": f"l{line}", "text": text}
            for line, text in enumerate(payload["lines"], 1)]
    evidence = "；".join(
        f"第{'、'.join(str(line) for line in group['lines'])}句归入“{group['label']}”"
        for group in groups)
    return {
        "id": "groups", "type": "match", "title": "把诗句分一分",
        "prompt": "按照刚才讲过的分组，把每句诗放回对应的一组。同一组可以放多句。",
        "rows": _shuffled(rows, payload["title"] + "|group-rows"),
        "options": _shuffled(options, payload["title"] + "|groups"),
        "answer": answer,
        "explanation": f"本次讲解的分组是：{evidence}。按组读，再把各组连起来。",
    }


def _sequence_question(payload: dict) -> dict:
    sequence = payload["sequence"]
    if len(sequence) < 2:
        raise ValidationError("互动结构版第3题需要sequence至少两项已核对的内容脉络")
    if len(set(sequence)) != len(sequence):
        raise ValidationError("互动结构版的sequence不能含完全相同的内容，请用可区分的描述")
    options = [{"id": f"s{index}", "text": text}
               for index, text in enumerate(sequence, 1)]
    return {
        "id": "sequence", "type": "order", "title": "把内容串起来",
        "prompt": "按照原诗的先后，把下面的内容排好。",
        "options": _shuffled(options, payload["title"] + "|sequence"),
        "answer": [item["id"] for item in options],
        "explanation": "本次讲解的内容顺序是：" + " → ".join(sequence) + "。沿着这个顺序再读全诗。",
    }


def build_exercises(payload: dict) -> list[dict]:
    """Return exactly three questions; missing evidence is an explicit error.

    Input is the normalized dictionary returned by ``structure_card.validate``.
    Multi/order answers are lists of stable option IDs. Match answers map row
    IDs to option IDs; an option may correctly serve more than one row.
    Explanations and answer keys are feedback data, not pre-answer content.
    """
    if payload["mode"] != "structure":
        raise ValidationError("互动练习只用于mode=structure；其他模式请生成PNG")
    rhyme = _rhyme_question(payload)
    parallel = next((item for item in payload["parallels"]
                     if len(item["segments"][0]) >= 2), None)
    relation = _parallel_question(payload, parallel) if parallel else _groups_question(payload)
    sequence = _sequence_question(payload)
    return [rhyme, relation, sequence]
