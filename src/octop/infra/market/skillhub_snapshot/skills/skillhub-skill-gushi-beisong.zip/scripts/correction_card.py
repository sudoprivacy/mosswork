#!/usr/bin/env python3
"""Render a local, deterministic poetry correction card from checked text.

This module compares characters only. It does not perform OCR, determine why
a child made an error, or infer whether a poem has been independently learned.
"""

from __future__ import annotations

from typing import Any

from card_common import (
    CW, DEEP, GREEN, INK, MUTED, ORANGE, RED, TEAL, WHITE, YELLOW,
    Card, Context, ValidationError, get_text, run_cli, text_value,
)


def align_text(expected: str, actual: str) -> list[dict[str, Any]]:
    """Return a minimum-edit, left-to-right character alignment.

    Each entry contains ``op`` (equal/replace/omit/extra), ``expected`` and
    ``actual`` (a character, or an empty string at an alignment gap), and
    1-based ``expected_index``/``actual_index`` (None for gaps).

    Costs are 1 for replacement, omission, or extra character. Backtracking
    prefers exact matches, then replacement, omission, and extra character.
    Repeated-character ties therefore have deterministic, documented output;
    the alignment is a textual comparison, not a diagnosis of the child's act.
    """
    if not isinstance(expected, str) or not isinstance(actual, str):
        raise TypeError("expected和actual必须是字符串")
    m, n = len(expected), len(actual)
    cost = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        cost[i][0] = i
    for j in range(n + 1):
        cost[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            cost[i][j] = min(
                cost[i - 1][j - 1] + (expected[i - 1] != actual[j - 1]),
                cost[i - 1][j] + 1,
                cost[i][j - 1] + 1,
            )

    aligned: list[dict[str, Any]] = []
    i, j = m, n
    while i or j:
        if i and j and expected[i - 1] == actual[j - 1] and cost[i][j] == cost[i - 1][j - 1]:
            op, before, after, ei, ai = "equal", expected[i - 1], actual[j - 1], i, j
            i, j = i - 1, j - 1
        elif i and j and cost[i][j] == cost[i - 1][j - 1] + 1:
            op, before, after, ei, ai = "replace", expected[i - 1], actual[j - 1], i, j
            i, j = i - 1, j - 1
        elif i and cost[i][j] == cost[i - 1][j] + 1:
            op, before, after, ei, ai = "omit", expected[i - 1], "", i, None
            i -= 1
        else:
            op, before, after, ei, ai = "extra", "", actual[j - 1], None, j
            j -= 1
        aligned.append({
            "op": op, "expected": before, "actual": after,
            "expected_index": ei, "actual_index": ai,
        })
    aligned.reverse()
    return aligned


def _checked_line(value: Any, name: str, allow_empty: bool = False) -> str:
    value = text_value(value, name, max_length=80, allow_empty=allow_empty)
    if any(ord(ch) < 32 or ch in "\u2028\u2029" for ch in value):
        raise ValidationError(f"{name}请填写单行文本，不要包含换行或控制字符")
    return value


def validate(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValidationError("输入必须是JSON对象")
    unknown = set(data) - {"title", "items", "instruction"}
    if unknown:
        raise ValidationError("不支持的字段：" + "、".join(sorted(unknown)))
    title = get_text(data, "title", max_length=50)
    items = data.get("items")
    if not isinstance(items, list) or not 1 <= len(items) <= 8:
        raise ValidationError("items必须是包含1至8项的数组")

    checked = []
    for number, item in enumerate(items, 1):
        prefix = f"items[{number - 1}]"
        if not isinstance(item, dict):
            raise ValidationError(f"{prefix}必须是对象")
        unknown = set(item) - {"label", "expected", "actual", "note"}
        if unknown:
            raise ValidationError(f"{prefix}不支持的字段：" + "、".join(sorted(unknown)))
        if "expected" not in item or "actual" not in item:
            raise ValidationError(f"{prefix}必须同时提供expected和actual；未写出时actual填写空字符串")
        checked.append({
            "label": get_text(item, "label", max_length=40, required=False, default=f"第{number}处"),
            "expected": _checked_line(item["expected"], f"{prefix}.expected"),
            "actual": _checked_line(item["actual"], f"{prefix}.actual", allow_empty=True),
            "note": get_text(item, "note", max_length=160, required=False, default=""),
        })
    return {
        "title": title,
        "items": checked,
        "instruction": get_text(data, "instruction", max_length=240, required=False, default=""),
    }


def _counts(aligned: list[dict[str, Any]]) -> dict[str, int]:
    result = {key: 0 for key in ("equal", "replace", "omit", "extra")}
    for item in aligned:
        result[item["op"]] += 1
    return result


def _chip(ctx: Context, draw: Any, x: int, y: int, label: str, color: str, bg: str) -> int:
    width = int(ctx.measure(label, 24, bold=True)) + 30
    draw.rounded_rectangle((x, y, x + width, y + 42), radius=14, fill=bg)
    ctx.text(draw, (x + 15, y + 7), label, size=24, fill=color, bold=True)
    return width


def _tile(ctx: Context, draw: Any, x: int, y: int, width: int, char: str, changed: bool, correct: bool) -> None:
    if changed:
        fill, stroke, text_color = ("#E8F5F4", TEAL, DEEP) if correct else ("#FFF0EC", RED, RED)
    else:
        fill, stroke, text_color = "#F3F3EE", "#E4E7E0", INK
    draw.rounded_rectangle((x, y, x + width, y + width), radius=12, fill=fill, outline=stroke, width=2 if changed else 1)
    if not char:
        # The em dash is an explicit visual alignment gap, never input text.
        draw.line((x + width * .31, y + width * .51, x + width * .69, y + width * .51), fill=MUTED, width=3)
        return
    size = 44 if width >= 70 else 34
    # Latin or combining input may have unusual bounds: fit actual glyph width.
    while size > 22 and ctx.measure(char, size, bold=changed) > width - 10:
        size -= 1
    glyph_width = ctx.measure(char, size, bold=changed)
    box = ctx.font(size, bold=changed).getbbox(char)
    glyph_height = box[3] - box[1]
    draw.text((x + (width - glyph_width) / 2, y + (width - glyph_height) / 2), char,
              font=ctx.font(size, bold=changed), fill=text_color, anchor="lt")


def _item_panel(ctx: Context, item: dict[str, Any], aligned: list[dict[str, Any]], counts: dict[str, int]):
    pad, label_width = 28, 124
    cell, gap = (72, 8) if len(aligned) <= 10 else (56, 6)
    available = CW - pad * 2 - label_width
    columns = max(1, int((available + gap) // (cell + gap)))
    chunks = [aligned[i:i + columns] for i in range(0, len(aligned), columns)]
    label_height = ctx.text_height(item["label"], CW - pad * 2, 32, bold=True)
    top = pad + label_height + 14
    grid_y = top + 42 + 28
    block_height = 26 + 2 * cell + 18
    grids_height = len(chunks) * block_height + max(0, len(chunks) - 1) * 24
    note = item["note"]
    note_height = ctx.text_height(note, CW - pad * 2 - 28, 27) + 28 if note else 0
    legend_height = ctx.text_height("横线表示对齐空位，并非本次写过的字。", CW - pad * 2, 23) + 16 if counts["omit"] or counts["extra"] else 0
    height = int(grid_y + grids_height + (22 if legend_height else 0) + legend_height + (22 if note else 0) + note_height + pad)
    panel, draw = ctx.panel(height)
    ctx.text(draw, (pad, pad), item["label"], size=32, fill=DEEP, bold=True, max_width=CW - pad * 2)

    x = pad
    if not sum(counts[key] for key in ("replace", "omit", "extra")):
        _chip(ctx, draw, x, int(top), "这一处一致", DEEP, "#E8F5F4")
    else:
        for key, label in (("replace", "换字"), ("omit", "漏字"), ("extra", "多字")):
            if counts[key]:
                x += _chip(ctx, draw, x, int(top), f"{label} {counts[key]}", RED, "#FFF0EC") + 12

    y = int(grid_y)
    tags = {"replace": "换", "omit": "漏", "extra": "多"}
    for chunk in chunks:
        tile_start = pad + label_width + int((available - (len(chunk) * (cell + gap) - gap)) / 2)
        ctx.text(draw, (pad, y + 26 + (cell - 25) / 2), "这次写的", size=25, fill=MUTED, bold=True)
        ctx.text(draw, (pad, y + 26 + cell + 18 + (cell - 25) / 2), "原诗这样写", size=23, fill=DEEP, bold=True)
        for index, atom in enumerate(chunk):
            x = tile_start + index * (cell + gap)
            changed = atom["op"] != "equal"
            if changed:
                tag = tags[atom["op"]]
                tag_width = ctx.measure(tag, 20, bold=True)
                ctx.text(draw, (x + (cell - tag_width) / 2, y), tag, size=20, fill=RED, bold=True)
            _tile(ctx, draw, x, y + 26, cell, atom["actual"], changed, correct=False)
            _tile(ctx, draw, x, y + 26 + cell + 18, cell, atom["expected"], changed, correct=True)
        y += block_height + 24

    y = int(grid_y + grids_height)
    if legend_height:
        y += 22
        ctx.text(draw, (pad, y), "横线表示对齐空位，并非本次写过的字。", size=23, fill=MUTED, max_width=CW - pad * 2)
        y += legend_height
    if note:
        y += 22
        draw.rounded_rectangle((pad, y, CW - pad, y + note_height), radius=16, fill="#FFF6D9")
        ctx.text(draw, (pad + 14, y + 14), note, size=27, fill=INK, max_width=CW - pad * 2 - 28)
    return panel


def render(data: Any, ctx: Context):
    data = validate(data)
    totals = {key: 0 for key in ("equal", "replace", "omit", "extra")}
    comparisons = []
    for item in data["items"]:
        aligned = align_text(item["expected"], item["actual"])
        counts = _counts(aligned)
        comparisons.append((item, aligned, counts))
        for key in totals:
            totals[key] += counts[key]

    differs = bool(totals["replace"] + totals["omit"] + totals["extra"])
    card = Card(ctx, data["title"],
                subtitle="先看清哪里不同，再遮住重写" if differs else "这次核对的内容与原诗一致",
                kicker="自己写，改错再试", accent=ORANGE if differs else TEAL)
    for item, aligned, counts in comparisons:
        card.add(_item_panel(ctx, item, aligned, counts))
    card.add_note(data["instruction"] or (
        "看清差异，遮住这张卡，再独立写一次。" if differs
        else "接下来遮住原文，再独立检查整首诗。"
    ))
    return card.finish(), {
        "items": len(data["items"]),
        "differences": {key: totals[key] for key in ("replace", "omit", "extra")},
        "matching_characters": totals["equal"],
        "has_differences": differs,
    }


if __name__ == "__main__":
    run_cli("correction", render)
