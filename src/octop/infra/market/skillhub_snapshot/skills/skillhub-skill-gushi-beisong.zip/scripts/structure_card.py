#!/usr/bin/env python3
"""Render a checked poem as structure, reading, recall, or limited-hint cards."""

from __future__ import annotations

import unicodedata
import json
from pathlib import Path

from card_common import (
    CW, DEEP, INK, MUTED, RED, TEAL, WHITE,
    Card, ValidationError, bounded_int, get_text, run_cli, text_value,
)


MODES = {"structure", "read", "recall", "hint"}
GROUP_FILLS = ("#E8F5F5", "#FFF5D8", "#EAF1F5", "#F2F3E5")
PAIR_FILLS = ("#DDF0F1", "#FFF0C4", "#E4EAF5", "#F7E8DF")
PAIR_INKS = ("#0E5F6B", "#77520B", "#354D7B", "#8B431E")


def _object(value, name):
    if not isinstance(value, dict):
        raise ValidationError(f"{name}必须是对象")
    return value


def _fields(value, name, allowed):
    value = _object(value, name)
    unknown = set(value) - set(allowed)
    if unknown:
        raise ValidationError(f"{name}含未知字段：" + "、".join(sorted(unknown)))
    return value


def _array(value, name, maximum=8, minimum=0):
    if not isinstance(value, list) or not minimum <= len(value) <= maximum:
        raise ValidationError(f"{name}必须是包含{minimum}至{maximum}项的数组")
    return value


def _indices(value, name, maximum, minimum_items=1):
    items = _array(value, name, maximum=maximum, minimum=minimum_items)
    result = [bounded_int(v, f"{name}[{i}]", 1, maximum) for i, v in enumerate(items)]
    if len(set(result)) != len(result):
        raise ValidationError(f"{name}不能包含重复位置")
    return result


def _single_line(value, name, maximum=40):
    value = text_value(value, name, max_length=maximum)
    if any(c in value for c in "\n\r\t"):
        raise ValidationError(f"{name}不能含换行或制表符")
    return value


def _pinyin_syllable(value, name):
    value = unicodedata.normalize("NFC", text_value(value, name, max_length=16))
    syllable = value[:-1] if value[-1:] in "12345" else value
    latin = ["LATIN" in unicodedata.name(c, "") and c.isalpha() for c in syllable]
    if not any(latin) or not all(is_latin or unicodedata.combining(c)
                                for c, is_latin in zip(syllable, latin)):
        raise ValidationError(f"{name}须为不含空白的单个拼音，可带声调")
    return value


def _pronunciation_targets(raw, name, lines):
    """Bind syllables to literal source text, never to rendered pause marks.

    Numeric-only input remains supported for existing callers. Text targets
    must match exactly; ambiguous targets require an explicit checked index.
    """
    raw = _fields(raw, name, ("line", "text", "index", "pinyin"))
    line = bounded_int(raw.get("line"), f"{name}.line", 1, len(lines))
    verse = lines[line - 1]
    if "text" not in raw:
        index = bounded_int(raw.get("index"), f"{name}.index", 1, len(verse))
        return [(line, index, _pinyin_syllable(raw.get("pinyin"), f"{name}.pinyin"))]

    target = _single_line(raw["text"], f"{name}.text")
    if "index" in raw:
        index = bounded_int(raw["index"], f"{name}.index", 1, len(verse))
        actual = verse[index - 1:index - 1 + len(target)]
        if actual != target:
            raise ValidationError(
                f"{name}字位不匹配：第{line}句第{index}字起是“{actual}”，不是“{target}”；请核对原文和index")
    else:
        matches = [i + 1 for i in range(len(verse)) if verse.startswith(target, i)]
        if not matches:
            raise ValidationError(f"{name}.text“{target}”未出现在第{line}句，请核对原文字形")
        if len(matches) != 1:
            raise ValidationError(f"{name}.text“{target}”在第{line}句出现多次，请提供起始字位index")
        index = matches[0]

    values = raw.get("pinyin")
    if isinstance(values, str) and len(target) == 1:
        values = [values]
    values = _array(values, f"{name}.pinyin（每字一个音节）",
                    minimum=len(target), maximum=len(target))
    return [(line, index + offset, _pinyin_syllable(value, f"{name}.pinyin[{offset}]"))
            for offset, value in enumerate(values)]


def validate(data):
    """Validate all teacher-supplied annotations; never infer rhyme or meaning."""
    _object(data, "输入")
    allowed = {"title", "author", "poem_type", "lines", "groups", "rhymes", "parallels", "sequence",
               "mode", "focus_lines", "annotations", "pauses", "reveals",
               "pronunciations", "pause_style"}
    unknown = set(data) - allowed
    if unknown:
        raise ValidationError("未知字段：" + "、".join(sorted(unknown)))
    title = get_text(data, "title", max_length=64)
    author = get_text(data, "author", max_length=48, required=False)
    poem_type = get_text(data, "poem_type", max_length=24, required=False)
    if any(c in poem_type for c in "\n\r\t\u2028\u2029"):
        raise ValidationError("poem_type须为单行的简短诗体标签")
    poem_type = poem_type.strip()
    mode = get_text(data, "mode", max_length=16, required=False, default="structure")
    if mode not in MODES:
        raise ValidationError("mode须为structure、read、recall或hint")
    raw_lines = _array(data.get("lines"), "lines", maximum=8, minimum=4)
    if len(raw_lines) not in (4, 8):
        raise ValidationError("lines须为4句或8句原诗；每项一整句")
    lines = [_single_line(v, f"lines[{i}]") for i, v in enumerate(raw_lines)]
    count = len(lines)
    pause_style = get_text(data, "pause_style", max_length=8, required=False, default="slash")
    if pause_style not in {"slash", "space"}:
        raise ValidationError("pause_style须为slash或space")
    pronunciations = {}
    for i, raw in enumerate(_array(data.get("pronunciations", []), "pronunciations", maximum=320)):
        for line, index, pinyin in _pronunciation_targets(raw, f"pronunciations[{i}]", lines):
            if (line, index) in pronunciations:
                raise ValidationError("pronunciations不能重复标注同一个位置")
            pronunciations[(line, index)] = pinyin

    groups = []
    raw_groups = data.get("groups")
    if raw_groups is None:
        raw_groups = [{"label": f"第{i // 2 + 1}组", "lines": [i + 1, i + 2]}
                      for i in range(0, count, 2)]
    for i, raw in enumerate(_array(raw_groups, "groups", maximum=8, minimum=1)):
        raw = _fields(raw, f"groups[{i}]", ("label", "lines"))
        indices = _indices(raw.get("lines"), f"groups[{i}].lines", count)
        label = get_text(raw, "label", max_length=80, required=False, default=f"第{i + 1}组")
        groups.append({"label": label, "lines": indices})
    if [line for group in groups for line in group["lines"]] != list(range(1, count + 1)):
        raise ValidationError("groups须按原诗顺序覆盖每句一次，不能漏句、重复或重排原诗")

    rhymes = set()
    for i, raw in enumerate(_array(data.get("rhymes", []), "rhymes", maximum=8)):
        raw = _fields(raw, f"rhymes[{i}]", ("line", "index"))
        line = bounded_int(raw.get("line"), f"rhymes[{i}].line", 1, count)
        index = bounded_int(raw.get("index"), f"rhymes[{i}].index", 1, len(lines[line - 1]))
        if (line, index) in rhymes:
            raise ValidationError("rhymes不能重复标注同一个位置")
        rhymes.add((line, index))

    parallels, parallel_pairs = [], set()
    for i, raw in enumerate(_array(data.get("parallels", []), "parallels", maximum=4)):
        raw = _fields(raw, f"parallels[{i}]", ("label", "lines", "segments"))
        indices = _indices(raw.get("lines"), f"parallels[{i}].lines", count)
        if len(indices) != 2:
            raise ValidationError("每项parallels.lines须指定两句")
        pair = tuple(sorted(indices))
        if pair in parallel_pairs:
            raise ValidationError("parallels不能重复标注同一对诗句")
        parallel_pairs.add(pair)
        rows = _array(raw.get("segments"), f"parallels[{i}].segments", maximum=2, minimum=2)
        segments = []
        for j, row in enumerate(rows):
            row = _array(row, f"parallels[{i}].segments[{j}]", maximum=8, minimum=1)
            row = [_single_line(v, f"parallels[{i}].segments[{j}][{k}]")
                   for k, v in enumerate(row)]
            if "".join(row) != lines[indices[j] - 1]:
                raise ValidationError(f"parallels[{i}]第{j + 1}行分段拼接后须与原句完全一致")
            segments.append(row)
        if len(segments[0]) != len(segments[1]):
            raise ValidationError("对应的两行必须有相同数量的分段")
        parallels.append({"label": get_text(raw, "label", max_length=80,
                                              required=False, default="看看对应的位置"),
                          "lines": indices, "segments": segments})

    sequence = [text_value(v, f"sequence[{i}]", max_length=100)
                for i, v in enumerate(_array(data.get("sequence", []), "sequence", maximum=8))]
    focus = _indices(data.get("focus_lines", [1, 2]), "focus_lines", count)

    annotations = {}
    for i, raw in enumerate(_array(data.get("annotations", []), "annotations", maximum=8)):
        raw = _fields(raw, f"annotations[{i}]", ("line", "text"))
        line = bounded_int(raw.get("line"), f"annotations[{i}].line", 1, count)
        if line in annotations:
            raise ValidationError("annotations每句只能有一项，请合并同一句注释")
        annotations[line] = get_text(raw, "text", max_length=180)
    pauses = {}
    for i, raw in enumerate(_array(data.get("pauses", []), "pauses", maximum=8)):
        raw = _fields(raw, f"pauses[{i}]", ("line", "after"))
        line = bounded_int(raw.get("line"), f"pauses[{i}].line", 1, count)
        if line in pauses:
            raise ValidationError("pauses每句只能有一项")
        pauses[line] = set(_indices(raw.get("after"), f"pauses[{i}].after", len(lines[line - 1]) - 1))
    reveals = {}
    for i, raw in enumerate(_array(data.get("reveals", []), "reveals", maximum=8)):
        raw = _fields(raw, f"reveals[{i}]", ("line", "indices"))
        line = bounded_int(raw.get("line"), f"reveals[{i}].line", 1, count)
        if line in reveals:
            raise ValidationError("reveals每句只能有一项")
        reveals[line] = set(_indices(raw.get("indices"), f"reveals[{i}].indices", len(lines[line - 1])))
    if mode == "hint" and not reveals:
        raise ValidationError("hint模式须通过reveals明确指定至少一个可见字")
    return {"title": title, "author": author, "poem_type": poem_type, "mode": mode, "lines": lines,
            "groups": groups, "rhymes": rhymes, "parallels": parallels,
            "sequence": sequence, "focus_lines": sorted(focus), "annotations": annotations,
            "pauses": pauses, "reveals": reveals,
            "pronunciations": pronunciations, "pause_style": pause_style}


def _row_layout(ctx, text, pauses=()):
    size = 68 if len(text) <= 7 else 52 if len(text) <= 12 else 36
    gap = 22 if len(text) <= 7 else 12 if len(text) <= 12 else 6
    cells = []
    for i, char in enumerate(text, 1):
        width = max(size, ctx.measure(char, size, bold=True))
        cells.append((i, char, width + gap + (22 if i in pauses else 0)))
    rows, row, used = [], [], 0
    maximum = CW - 156
    for item in cells:
        if row and used + item[2] > maximum:
            rows.append((row, used - gap))
            row, used = [], 0
        row.append(item)
        used += item[2]
    if row:
        rows.append((row, used - gap))
    return size, rows, int(size * 1.55)


def _draw_verse(ctx, draw, text, line, y, rhymes=(), pauses=(), reveals=None):
    size, rows, row_height = _row_layout(ctx, text, pauses)
    for row_index, (items, width) in enumerate(rows):
        top = y + row_index * row_height
        x = (CW + 36 - width) / 2
        if row_index == 0:
            draw.rounded_rectangle((26, top + 12, 65, top + 51), radius=12, fill=WHITE)
            ctx.text(draw, (36, top + 16), str(line), size=23, fill=DEEP, bold=True)
        for index, char, advance in items:
            is_visible = reveals is None or index in reveals
            if is_visible:
                marked = (line, index) in rhymes
                ctx.text(draw, (x, top), char, size=size, fill=RED if marked else INK, bold=marked)
                if marked:
                    draw.rounded_rectangle((x + 3, top + size + 10, x + size - 3, top + size + 15),
                                           radius=2, fill=RED)
            else:
                draw.rounded_rectangle((x + 3, top + 5, x + size - 3, top + size + 8),
                                       radius=10, fill="#E7EBE8", outline="#A8B8B5", width=2)
            x += advance
    return len(rows) * row_height


def _reading_layout(ctx, text, line, pronunciations, pauses, pause_style):
    """Reserve independent ruby space and put pause marks between character cells.

    Character indices continue to address the original text. Neither ruby text
    nor rendered slashes are inserted into that text or its rhyme positions.
    """
    size = 68 if len(text) <= 7 else 52 if len(text) <= 12 else 36
    gap = 22 if len(text) <= 7 else 12 if len(text) <= 12 else 6
    ruby_size = max(20, round(size * .38))
    ruby_height = ctx.text_height("gèng", CW, ruby_size) + 8
    pause_width = ctx.measure("/", round(size * .65)) + 16 if pause_style == "slash" else 22
    rows, row, used = [], [], 0
    for index, char in enumerate(text, 1):
        ruby = pronunciations.get((line, index), "")
        cell_width = max(size, ctx.measure(char, size, bold=True),
                         ctx.measure(ruby, ruby_size) + 10 if ruby else 0)
        separator = pause_width if index in pauses else 0
        advance = cell_width + gap + separator
        cell = {"index": index, "char": char, "ruby": ruby, "width": cell_width,
                "advance": advance, "separator": separator}
        if row and used + advance > CW - 156:
            rows.append((row, used - gap))
            row, used = [], 0
        row.append(cell)
        used += advance
    if row:
        rows.append((row, used - gap))
    # All rows in a line use the same baseline, even if only some contain ruby.
    has_ruby = any((line, i) in pronunciations for i in range(1, len(text) + 1))
    ruby_offset = ruby_height if has_ruby else 0
    return size, ruby_size, ruby_offset, rows, int(size * 1.55) + ruby_offset


def _draw_reading_verse(ctx, draw, text, line, y, payload, layout):
    size, ruby_size, ruby_offset, rows, row_height = layout
    for row_index, (cells, width) in enumerate(rows):
        top = y + row_index * row_height
        baseline_top = top + ruby_offset
        x = (CW + 36 - width) / 2
        if row_index == 0:
            draw.rounded_rectangle((26, baseline_top + 12, 65, baseline_top + 51), radius=12, fill=WHITE)
            ctx.text(draw, (36, baseline_top + 16), str(line), size=23, fill=DEEP, bold=True)
        for cell in cells:
            center = x + cell["width"] / 2
            marked = (line, cell["index"]) in payload["rhymes"]
            char_width = ctx.measure(cell["char"], size, bold=marked)
            char_x = center - char_width / 2
            if cell["ruby"]:
                ruby_x = center - ctx.measure(cell["ruby"], ruby_size) / 2
                ctx.text(draw, (ruby_x, top), cell["ruby"], size=ruby_size, fill=DEEP)
            ctx.text(draw, (char_x, baseline_top), cell["char"], size=size,
                     fill=RED if marked else INK, bold=marked)
            if marked:
                draw.rounded_rectangle((char_x + 3, baseline_top + size + 10,
                                        char_x + char_width - 3, baseline_top + size + 15),
                                       radius=2, fill=RED)
            if cell["separator"] and payload["pause_style"] == "slash":
                slash_size = round(size * .65)
                # The slash lives inside reserved inter-cell space, away from ruby.
                slash_x = x + cell["width"] + (cell["advance"] - cell["width"] - ctx.measure("/", slash_size)) / 2
                ctx.text(draw, (slash_x, baseline_top + (size - slash_size) / 2),
                         "/", size=slash_size, fill=MUTED)
            x += cell["advance"]


def _group_panel(ctx, payload, group, number):
    label = group["label"]
    label_height = ctx.text_height(label, CW - 100, 29, bold=True)
    rows_height = sum(len(_row_layout(ctx, payload["lines"][n - 1])[1]) *
                      _row_layout(ctx, payload["lines"][n - 1])[2] for n in group["lines"])
    panel, draw = ctx.panel(int(48 + label_height + 22 + rows_height + 12),
                            fill=GROUP_FILLS[number % len(GROUP_FILLS)])
    draw.rounded_rectangle((24, 26, 32, 26 + label_height), radius=4, fill=TEAL)
    ctx.text(draw, (48, 24), label, size=29, fill=DEEP, bold=True, max_width=CW - 100)
    y = 24 + label_height + 24
    for line in group["lines"]:
        y += _draw_verse(ctx, draw, payload["lines"][line - 1], line, y, payload["rhymes"])
    return panel


def _parallel_panel(ctx, item):
    columns = len(item["segments"][0])
    outer_x, gap = 106, 10
    column_width = (CW - outer_x - 32 - gap * (columns - 1)) / columns
    size = 35 if columns <= 4 else 27
    text_width = column_width - 22
    row_heights = [max(ctx.text_height(s, text_width, size, bold=True) for s in row) + 32
                   for row in item["segments"]]
    heading_height = ctx.text_height(item["label"], CW - 64, 29, bold=True)
    top = 30 + heading_height + 26
    panel, draw = ctx.panel(int(top + sum(row_heights) + 24 + 38))
    ctx.text(draw, (32, 26), item["label"], size=29, fill=DEEP, bold=True, max_width=CW - 64)
    for row, parts in enumerate(item["segments"]):
        h = row_heights[row]
        ctx.text(draw, (30, top + (h - 25) / 2), f"第{item['lines'][row]}句", size=22, fill=MUTED)
        for col, segment in enumerate(parts):
            x = outer_x + col * (column_width + gap)
            draw.rounded_rectangle((x, top, x + column_width, top + h), radius=15,
                                   fill=PAIR_FILLS[col % len(PAIR_FILLS)])
            wrapped = ctx.wrap(segment, text_width, size, bold=True)
            y = top + 16
            for text in wrapped:
                tx = x + (column_width - ctx.measure(text, size, bold=True)) / 2
                ctx.text(draw, (tx, y), text, size=size,
                         fill=PAIR_INKS[col % len(PAIR_INKS)], bold=True)
                y += size + 10
        top += h + 14
    return panel


def _sequence_panel(ctx, sequence):
    title = "内容怎样连起来"
    heights = [max(68, ctx.text_height(s, CW - 176, 30, bold=True) + 28) for s in sequence]
    panel, draw = ctx.panel(int(100 + sum(heights) + 28 * (len(sequence) - 1) + 24), fill="#EDF5F3")
    ctx.text(draw, (32, 26), title, size=29, fill=DEEP, bold=True)
    y = 90
    for i, (label, height) in enumerate(zip(sequence, heights)):
        draw.rounded_rectangle((32, y, CW - 32, y + height), radius=18, fill=WHITE)
        draw.ellipse((50, y + 17, 86, y + 53), fill=TEAL)
        ctx.text(draw, (60, y + 19), str(i + 1), size=22, fill=WHITE, bold=True)
        ctx.text(draw, (108, y + 14), label, size=30, fill=DEEP, bold=True, max_width=CW - 176)
        y += height
        if i < len(sequence) - 1:
            mid = CW / 2
            draw.line((mid, y + 3, mid, y + 18), fill=TEAL, width=4)
            draw.polygon(((mid - 8, y + 15), (mid + 8, y + 15), (mid, y + 23)), fill=TEAL)
        y += 28
    return panel


def render(data, ctx):
    payload = validate(data)
    mode = payload["mode"]
    labels = {"structure": "找联系，串全诗", "read": "读准字，懂诗意",
              "recall": "不看诗，自己背", "hint": "局部提示练习"}
    subtitle = " · ".join(s for s in (payload["author"], payload["poem_type"]) if s) if mode in ("structure", "read") else ""
    card = Card(ctx, payload["title"], subtitle=subtitle, kicker=labels[mode])

    if mode == "recall":
        panel, draw = ctx.panel(310)
        ctx.text(draw, (48, 64), "先不看原文，试着背出整首诗。", size=38, fill=DEEP,
                 bold=True, max_width=CW - 96)
        ctx.text(draw, (48, 170), "需要帮助时，再开口求助。", size=30, fill=MUTED,
                 max_width=CW - 96)
        card.add(panel)
        return card.finish(), {"mode": mode}

    if mode == "hint":
        for line, indices in sorted(payload["reveals"].items()):
            text = payload["lines"][line - 1]
            _, rows, line_height = _row_layout(ctx, text)
            panel, draw = ctx.panel(int(60 + len(rows) * line_height), fill="#FFF5D8")
            _draw_verse(ctx, draw, text, line, 30, reveals=indices)
            card.add(panel)
        card.add_note("这是提示练习。得到帮助后，再不看提示试一次。")
        return card.finish(), {"mode": mode, "hinted_lines": sorted(payload["reveals"])}

    if mode == "read":
        for line in payload["focus_lines"]:
            text = payload["lines"][line - 1]
            pauses = payload["pauses"].get(line, set())
            layout = _reading_layout(ctx, text, line, payload["pronunciations"], pauses, payload["pause_style"])
            _, _, _, rows, line_height = layout
            note = payload["annotations"].get(line, "")
            note_height = ctx.text_height(note, CW - 100, 29) if note else 0
            verse_height = len(rows) * line_height
            panel, draw = ctx.panel(int(60 + verse_height + (32 + note_height if note else 0)),
                                    fill="#E8F5F5")
            _draw_reading_verse(ctx, draw, text, line, 30, payload, layout)
            if note:
                y = 30 + verse_height + 10
                draw.line((48, y, CW - 48, y), fill="#BED9D8", width=2)
                ctx.text(draw, (48, y + 18), note, size=29, fill=DEEP, max_width=CW - 100)
            card.add(panel)
        return card.finish(), {"mode": mode, "focus_lines": payload["focus_lines"]}

    for number, group in enumerate(payload["groups"]):
        card.add(_group_panel(ctx, payload, group, number))
    if payload["rhymes"]:
        card.add_note("红色加粗并带下划线的字：本次标出的韵脚。")
    for item in payload["parallels"]:
        card.add(_parallel_panel(ctx, item))
    if payload["sequence"]:
        card.add(_sequence_panel(ctx, payload["sequence"]))
    return card.finish(), {"mode": mode, "line_count": len(payload["lines"])}


def render_interactive(data):
    """Generate an offline exercise page; no browser-to-chat callback is assumed."""
    from structure_exercises import build_exercises

    payload = validate(data)
    if payload["mode"] != "structure":
        raise ValidationError("HTML互动页仅支持mode=structure；读准、提示和回忆卡请输出.png")
    content = {key: payload[key] for key in (
        "title", "author", "poem_type", "lines", "groups", "parallels", "sequence")}
    content["rhymes"] = [{"line": line, "index": index}
                         for line, index in sorted(payload["rhymes"])]
    content["questions"] = build_exercises(payload)
    # JSON is data, not markup: protect the script element boundary even when
    # teacher-provided strings include HTML or closing-script text.
    serialized = json.dumps(content, ensure_ascii=False).replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
    serialized = serialized.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    template_path = Path(__file__).resolve().parent.parent / "assets/structure-practice.html"
    template = template_path.read_text(encoding="utf-8")
    if template.count("__POEM_DATA__") != 1:
        raise ValidationError("互动模板的数据占位符必须恰好出现一次")
    return template.replace("__POEM_DATA__", serialized), {
        "mode": "structure", "question_count": 3, "page_count": 5,
        "result_handoff": "copy_and_send_in_chat",
    }


if __name__ == "__main__":
    run_cli("structure", render, html_renderer=render_interactive)
