"""Regression checks for the font face actually used to render Chinese cards.

No system font or downloaded font is needed: temporary files contain only a
font header, and Pillow supplies controlled family/style metadata in these
tests. Assertions go through Context.font, including its regular/bold paths.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from card_common import Context, ValidationError


@dataclass(frozen=True)
class FakeFont:
    family: str
    style: str
    index: int
    size: int
    path: str

    def getname(self):
        return self.family, self.style


class FontSelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.faces = {}
        mocked = patch("card_common.ImageFont.truetype", side_effect=self.load_face)
        mocked.start()
        self.addCleanup(mocked.stop)

    def font_file(self, filename, faces, *, collection=True):
        path = Path(self.temp.name) / filename
        if collection:
            # The selector reads the TTC header; Pillow itself is mocked.
            path.write_bytes(struct.pack(">4sII", b"ttcf", 0x00010000, len(faces)))
        else:
            path.write_bytes(b"\x00\x01\x00\x00" + b"\x00" * 8)
        self.faces[str(path)] = faces
        return str(path)

    def load_face(self, font, size=10, index=0, *args, **kwargs):
        path = str(font)
        faces = self.faces[path]
        if not 0 <= index < len(faces):
            raise OSError("invalid font face index")
        family, style = faces[index]
        return FakeFont(family, style, index, size, path)

    def test_noto_sc_is_selected_by_family_at_different_indices(self):
        other_faces = [
            ("Noto Sans CJK JP", "Regular"),
            ("Noto Sans CJK KR", "Regular"),
            ("Noto Sans CJK TC", "Regular"),
            ("Noto Sans CJK HK", "Regular"),
        ]
        for sc_index in (1, 4):
            with self.subTest(sc_index=sc_index):
                faces = list(other_faces)
                faces.insert(sc_index, ("Noto Sans CJK SC", "Regular"))
                path = self.font_file(f"noto-{sc_index}.ttc", faces)
                context = Context(path)
                for bold in (False, True):
                    rendered = context.font(41, bold=bold)
                    self.assertEqual(rendered.getname(), ("Noto Sans CJK SC", "Regular"))
                    self.assertEqual(rendered.index, sc_index)
                    self.assertEqual(rendered.size, 41)

    def test_regular_and_bold_collections_have_independent_sc_positions(self):
        regular = self.font_file("NotoSansCJK-Regular.ttc", [
            ("Noto Sans CJK JP", "Regular"),
            ("Noto Sans CJK SC", "Regular"),
            ("Noto Sans CJK TC", "Regular"),
        ])
        bold = self.font_file("NotoSansCJK-Bold.ttc", [
            ("Noto Sans CJK JP", "Bold"),
            ("Noto Sans CJK KR", "Bold"),
            ("Noto Sans CJK TC", "Bold"),
            ("Noto Sans CJK HK", "Bold"),
            ("Noto Sans CJK SC", "Bold"),
        ])
        context = Context(regular, bold)
        normal_face = context.font(36)
        bold_face = context.font(48, bold=True)
        self.assertEqual((normal_face.path, normal_face.index), (regular, 1))
        self.assertEqual(normal_face.getname(), ("Noto Sans CJK SC", "Regular"))
        self.assertEqual((bold_face.path, bold_face.index), (bold, 4))
        self.assertEqual(bold_face.getname(), ("Noto Sans CJK SC", "Bold"))

    def pingfang_collection(self):
        return self.font_file("PingFang.ttc", [
            ("PingFang TC", "Regular"),
            ("PingFang SC", "Ultralight"),
            ("PingFang HK", "Semibold"),
            ("PingFang SC", "Regular"),
            ("PingFang SC", "Medium"),
            ("PingFang SC", "Semibold"),
        ])

    def assert_pingfang_weights(self, context):
        regular = context.font(39)
        bold = context.font(39, bold=True)
        self.assertEqual((regular.index, regular.getname()),
                         (3, ("PingFang SC", "Regular")))
        self.assertEqual((bold.index, bold.getname()),
                         (5, ("PingFang SC", "Semibold")))

    def test_pingfang_uses_sc_regular_and_semibold_from_one_collection(self):
        self.assert_pingfang_weights(Context(self.pingfang_collection()))

    def test_explicit_same_collection_for_both_paths_still_selects_sc_weights(self):
        path = self.pingfang_collection()
        self.assert_pingfang_weights(Context(path, path))

    def test_collection_with_only_other_cjk_regions_is_rejected(self):
        path = self.font_file("other-cjk.ttc", [
            ("Noto Sans CJK JP", "Regular"),
            ("Noto Sans CJK TC", "Regular"),
            ("Noto Sans CJK HK", "Regular"),
            ("Noto Sans CJK KR", "Regular"),
        ])
        with self.assertRaises(ValidationError):
            Context(path)

    def test_bold_collection_without_sc_is_not_used_with_valid_sc_regular(self):
        regular = self.font_file("regular-sc.ttc", [
            ("Noto Sans CJK JP", "Regular"),
            ("Noto Sans CJK SC", "Regular"),
        ])
        bold = self.font_file("bold-jp-tc.ttc", [
            ("Noto Sans CJK JP", "Bold"),
            ("Noto Sans CJK TC", "Bold"),
        ])
        with self.assertRaises(ValidationError):
            Context(regular, bold)

    def test_standalone_ttf_keeps_default_face_and_explicit_bold_file(self):
        regular = self.font_file("classroom-regular.ttf", [
            ("Classroom Font", "Regular"),
        ], collection=False)
        bold = self.font_file("classroom-bold.ttf", [
            ("Classroom Font", "Bold"),
        ], collection=False)
        context = Context(regular, bold)
        normal_face = context.font(29)
        bold_face = context.font(44, bold=True)
        self.assertEqual((normal_face.path, normal_face.index, normal_face.size),
                         (regular, 0, 29))
        self.assertEqual(normal_face.getname(), ("Classroom Font", "Regular"))
        self.assertEqual((bold_face.path, bold_face.index, bold_face.size),
                         (bold, 0, 44))
        self.assertEqual(bold_face.getname(), ("Classroom Font", "Bold"))


if __name__ == "__main__":
    unittest.main()
