"""Acceptance checks for deterministic question data and offline HTML export.

All student-facing inputs used here are synthetic. Browser interaction is
checked separately; these checks protect answer evidence and export boundaries.
"""

from __future__ import annotations

import copy
from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from card_common import ValidationError
from structure_card import render_interactive, validate
from structure_exercises import build_exercises


def source_data():
    return json.loads((SKILL_ROOT / "examples/structure.json").read_text(encoding="utf-8"))


class ExerciseDataTests(unittest.TestCase):
    def test_exactly_three_evidence_based_questions(self):
        payload = validate(source_data())
        before = copy.deepcopy(payload)
        questions = build_exercises(payload)
        self.assertEqual([q["type"] for q in questions], ["multi", "match", "order"])
        self.assertEqual([q["id"] for q in questions], ["rhyme", "parallel", "sequence"])
        self.assertEqual(questions[0]["answer"], ["r2", "r4"])
        self.assertEqual(payload, before)

    def test_generation_is_deterministic_and_options_are_shuffled(self):
        payload = validate(source_data())
        first = build_exercises(payload)
        self.assertEqual(first, build_exercises(payload))
        original_ids = [
            [f"r{i}" for i in range(1, len(payload["lines"]) + 1)],
            [f"p{i}" for i in range(1, len(payload["parallels"][0]["segments"][1]) + 1)],
            [f"s{i}" for i in range(1, len(payload["sequence"]) + 1)],
        ]
        for question, original in zip(first, original_ids):
            with self.subTest(question=question["id"]):
                actual = [option["id"] for option in question["options"]]
                self.assertCountEqual(actual, original)
                self.assertNotEqual(actual, original)

    def test_every_answer_references_a_visible_option(self):
        for question in build_exercises(validate(source_data())):
            with self.subTest(question=question["id"]):
                option_ids = [item["id"] for item in question["options"]]
                self.assertEqual(len(option_ids), len(set(option_ids)))
                if question["type"] == "match":
                    self.assertEqual(set(question["answer"]), {row["id"] for row in question["rows"]})
                    answer_ids = set(question["answer"].values())
                else:
                    answer_ids = set(question["answer"])
                self.assertLessEqual(answer_ids, set(option_ids))

    def test_no_parallelism_uses_checked_groups(self):
        raw = source_data()
        raw.pop("parallels")
        question = build_exercises(validate(raw))[1]
        self.assertEqual((question["id"], question["type"]), ("groups", "match"))
        option_text = {option["id"]: option["text"] for option in question["options"]}
        for group in raw["groups"]:
            for line in group["lines"]:
                self.assertEqual(option_text[question["answer"][f"l{line}"]], group["label"])
        self.assertCountEqual([row["text"] for row in question["rows"]], raw["lines"])

    def test_repeated_identical_words_share_one_answer_option(self):
        raw = source_data()
        raw["lines"][:2] = ["青山青山", "绿水绿水"]
        raw["rhymes"] = [{"line": 2, "index": 4}, {"line": 4, "index": 5}]
        raw["parallels"] = [{"lines": [1, 2], "segments": [["青山", "青山"], ["绿水", "绿水"]]}]
        question = build_exercises(validate(raw))[1]
        self.assertEqual(len(question["options"]), 1)
        self.assertEqual(question["options"][0]["text"], "绿水")
        self.assertEqual(question["answer"]["u1"], question["answer"]["u2"])
        # The identical upper words remain distinguishable by occurrence.
        self.assertNotEqual(question["rows"][0]["text"], question["rows"][1]["text"])

    def test_missing_or_ambiguous_evidence_is_rejected(self):
        changes = [
            {"rhymes": []},
            {"rhymes": [{"line": 2, "index": 5}]},
            {"rhymes": [{"line": 2, "index": 4}, {"line": 4, "index": 5}]},
            {"sequence": []},
            {"sequence": ["唯一一项"]},
            {"sequence": ["同一内容", "同一内容"]},
            {"parallels": [], "groups": [{"label": "全部", "lines": [1, 2, 3, 4]}]},
            {"parallels": [], "groups": [{"label": "同名", "lines": [1, 2]},
                                           {"label": "同名", "lines": [3, 4]}]},
        ]
        for changed in changes:
            with self.subTest(changed=changed):
                with self.assertRaises(ValidationError):
                    build_exercises(validate(dict(source_data(), **changed)))

    def test_sentence_final_punctuation_is_not_mistaken_for_a_rhyme_word(self):
        raw = source_data()
        raw["lines"][0] += "，"
        with self.assertRaises(ValidationError):
            build_exercises(validate(raw))


class ScriptCollector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []
        self.scripts = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))
        if tag == "script":
            self.current = []

    def handle_data(self, data):
        if self.current is not None:
            self.current.append(data)

    def handle_endtag(self, tag):
        if tag == "script" and self.current is not None:
            self.scripts.append("".join(self.current))
            self.current = None


class InteractiveExportTests(unittest.TestCase):
    def test_teacher_text_cannot_break_out_of_the_json_script_element(self):
        baseline, _ = render_interactive(source_data())
        raw = source_data()
        raw["title"] = "</script><script>UNTRUSTED_SCRIPT</script>"
        raw["author"] = '<img src=x onerror="UNTRUSTED_IMAGE()">&\u2028\u2029'
        html, metadata = render_interactive(raw)
        before, after = ScriptCollector(), ScriptCollector()
        before.feed(baseline)
        after.feed(html)
        self.assertEqual(after.tags, before.tags)
        self.assertEqual(len(after.scripts), len(before.scripts))
        self.assertNotIn(raw["title"], html)
        self.assertNotIn(raw["author"], html)
        decoded = []
        for script in after.scripts:
            try:
                value = json.loads(script)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict) and "questions" in value:
                decoded.append(value)
        self.assertEqual(len(decoded), 1)
        self.assertEqual(decoded[0]["title"], raw["title"])
        self.assertEqual(decoded[0]["author"], raw["author"])
        self.assertEqual(len(decoded[0]["questions"]), 3)
        self.assertEqual(metadata["question_count"], 3)

    def run_cli(self, script, source, output):
        return subprocess.run(
            [sys.executable, str(SKILL_ROOT / "scripts" / script),
             "--input", str(source), "--output", str(output)],
            capture_output=True, text=True,
        )

    def test_cli_writes_a_self_contained_html_with_three_questions(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "nested" / "practice.html"
            completed = self.run_cli("structure_card.py", SKILL_ROOT / "examples/structure.json", target)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            record = json.loads(completed.stdout)
            self.assertTrue(record["ok"])
            self.assertEqual(record["details"]["question_count"], 3)
            self.assertEqual(record["details"]["result_handoff"], "copy_and_send_in_chat")
            self.assertEqual(Path(record["output"]), target.resolve())
            content = target.read_text(encoding="utf-8")
            self.assertIn("<html", content.lower())
            self.assertNotIn("__POEM_DATA__", content)
            self.assertEqual(list(target.parent.glob(".poem-card-*")), [])

    def test_invalid_data_never_replaces_an_existing_html(self):
        bad_values = [
            "{",
            json.dumps(dict(source_data(), sequence=[])),
            json.dumps(dict(source_data(), rhymes=[])),
        ]
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "practice.html"
            source = Path(folder) / "input.json"
            original = b"<!doctype html><p>Previously rendered result</p>"
            for value in bad_values:
                with self.subTest(value=value[:80]):
                    target.write_bytes(original)
                    source.write_text(value, encoding="utf-8")
                    completed = self.run_cli("structure_card.py", source, target)
                    self.assertEqual(completed.returncode, 2, completed.stderr)
                    self.assertFalse(json.loads(completed.stderr)["ok"])
                    self.assertEqual(target.read_bytes(), original)
                    self.assertEqual(list(Path(folder).glob(".poem-card-*")), [])

    def test_html_rejects_non_structure_modes(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "wrong-mode.html"
            source = Path(folder) / "input.json"
            for mode in ("read", "hint", "recall"):
                with self.subTest(mode=mode):
                    raw = dict(source_data(), mode=mode)
                    if mode == "hint":
                        raw["reveals"] = [{"line": 1, "indices": [1]}]
                    source.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
                    completed = self.run_cli("structure_card.py", source, target)
                    self.assertEqual(completed.returncode, 2, completed.stderr)
                    self.assertIn("mode=structure", json.loads(completed.stderr)["error"])
                    self.assertFalse(target.exists())

    def test_png_only_renderers_keep_rejecting_html(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "not-supported.html"
            for script, example in (("correction_card.py", "correction.json"),
                                    ("result_card.py", "result_success.json")):
                with self.subTest(script=script):
                    completed = self.run_cli(script, SKILL_ROOT / "examples" / example, target)
                    self.assertEqual(completed.returncode, 2, completed.stderr)
                    self.assertIn(".png", json.loads(completed.stderr)["error"])
                    self.assertFalse(target.exists())


if __name__ == "__main__":
    unittest.main()
