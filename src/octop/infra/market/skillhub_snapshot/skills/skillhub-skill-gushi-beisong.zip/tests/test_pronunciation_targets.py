"""Literal pronunciation targets prevent valid-but-wrong numeric positions."""
from __future__ import annotations

import copy
from pathlib import Path
import sys
import unittest

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from card_common import ValidationError
from structure_card import render, validate
from test_structure_annotations import RecordingContext


def reading_input(verse="船尾跳鱼拨剌鸣"):
    # Only the target line is displayed. Other rows are synthetic placeholders,
    # so this fixture makes no claims about a complete poem's text or readings.
    return {
        "title": "注音位置测试", "mode": "read",
        "lines": ["测试行甲", "测试行乙", "测试行丙", verse],
        "focus_lines": [4],
    }


class PronunciationTargetTests(unittest.TestCase):
    def test_word_target_locates_literal_characters_without_counting(self):
        data = reading_input()
        data["pronunciations"] = [
            {"line": 4, "text": "拨剌", "pinyin": ["bō", "là"]},
        ]
        original = copy.deepcopy(data)
        self.assertEqual(validate(data)["pronunciations"], {(4, 5): "bō", (4, 6): "là"})
        self.assertEqual(data, original)

    def test_single_character_accepts_one_syllable_string_or_array(self):
        for value in ("bō", ["bō"]):
            with self.subTest(pinyin=value):
                data = reading_input()
                data["pronunciations"] = [{"line": 4, "text": "拨", "pinyin": value}]
                self.assertEqual(validate(data)["pronunciations"], {(4, 5): "bō"})

    def test_word_requires_exactly_one_syllable_per_character(self):
        for value in ("bō là", "bōlà", ["bō"], ["bō", "là", "míng"], [], None):
            with self.subTest(pinyin=value):
                data = reading_input()
                data["pronunciations"] = [{"line": 4, "text": "拨剌", "pinyin": value}]
                with self.assertRaises(ValidationError):
                    validate(data)

    def test_explicit_position_must_match_the_entire_literal_target(self):
        data = reading_input()
        annotation = {"line": 4, "text": "拨剌", "index": 5, "pinyin": ["bō", "là"]}
        data["pronunciations"] = [annotation]
        self.assertEqual(validate(data)["pronunciations"], {(4, 5): "bō", (4, 6): "là"})
        for index in (0, 4, 6, 7, 8, True):
            with self.subTest(index=index):
                data["pronunciations"] = [dict(annotation, index=index)]
                with self.assertRaises(ValidationError):
                    validate(data)

    def test_repeated_target_requires_a_checked_start_position(self):
        for verse, target, index in (("明月明月", "明月", 3), ("人人人", "人人", 2)):
            with self.subTest(verse=verse):
                data = reading_input(verse)
                syllables = ["míng", "yuè"] if target == "明月" else ["rén", "rén"]
                data["pronunciations"] = [{"line": 4, "text": target, "pinyin": syllables}]
                with self.assertRaises(ValidationError):
                    validate(data)
                data["pronunciations"][0]["index"] = index
                self.assertEqual(
                    validate(data)["pronunciations"],
                    {(4, index): syllables[0], (4, index + 1): syllables[1]},
                )

    def test_missing_or_visually_similar_target_is_not_silently_substituted(self):
        for text in ("拨刺", "剌鸣外", "桂树"):
            with self.subTest(text=text):
                data = reading_input()
                data["pronunciations"] = [{"line": 4, "text": text, "pinyin": ["bō"] * len(text)}]
                with self.assertRaises(ValidationError):
                    validate(data)

    def test_overlapping_annotations_are_rejected_across_both_input_forms(self):
        word = {"line": 4, "text": "拨剌", "pinyin": ["bō", "là"]}
        for duplicate in (
            {"line": 4, "text": "剌", "pinyin": "là"},
            {"line": 4, "text": "剌鸣", "pinyin": ["là", "míng"]},
            {"line": 4, "index": 6, "pinyin": "là"},
        ):
            for items in ([word, duplicate], [duplicate, word]):
                with self.subTest(items=items):
                    data = reading_input()
                    data["pronunciations"] = items
                    with self.assertRaises(ValidationError):
                        validate(data)

    def test_legacy_single_syllable_positions_remain_compatible(self):
        data = reading_input()
        data["pronunciations"] = [
            {"line": 4, "index": 5, "pinyin": "bō"},
            {"line": 4, "index": 6, "pinyin": "là"},
        ]
        self.assertEqual(validate(data)["pronunciations"], {(4, 5): "bō", (4, 6): "là"})
        data["pronunciations"][0]["pinyin"] = ["bō"]
        with self.assertRaises(ValidationError):
            validate(data)

    def test_syllables_remain_centered_after_pauses_and_line_wrapping(self):
        # The final case is deliberately synthetic and longer than one row.
        cases = (
            ("更上一层楼", [("更", "gèng"), ("层楼", ["céng", "lóu"])], [2], False),
            ("船尾跳鱼拨剌鸣", [("拨剌", ["bō", "là"])], [2, 4], False),
            ("甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥天地玄黄宇宙洪荒",
             [("甲", "jiǎ"), ("洪荒", ["hóng", "huāng"])], [2, 4], True),
        )
        for verse, targets, pauses, wraps in cases:
            for style in ("slash", "space"):
                with self.subTest(verse=verse, style=style):
                    data = reading_input(verse)
                    data.update(
                        pause_style=style,
                        pauses=[{"line": 4, "after": pauses}],
                        rhymes=[{"line": 4, "index": len(verse)}],
                        pronunciations=[{"line": 4, "text": text, "pinyin": syllables}
                                        for text, syllables in targets],
                    )
                    ctx = RecordingContext()
                    render(data, ctx)
                    character_rows = []
                    for text, value in targets:
                        syllables = [value] if isinstance(value, str) else value
                        for char, syllable in zip(text, syllables):
                            ruby = next(item for item in ctx.drawn if item["text"] == syllable)
                            character = next(item for item in ctx.drawn
                                             if item["text"] == char
                                             and item["draw"] == ruby["draw"]
                                             and item["size"] > ruby["size"])
                            centers = [item["xy"][0] + ctx.measure(item["text"], item["size"], item["bold"]) / 2
                                       for item in (ruby, character)]
                            self.assertAlmostEqual(centers[0], centers[1], delta=1)
                            self.assertLess(ruby["xy"][1], character["xy"][1])
                            character_rows.append(character["xy"][1])
                    if wraps:
                        self.assertGreater(max(character_rows), min(character_rows))
                    else:
                        self.assertEqual(max(character_rows), min(character_rows))


if __name__ == "__main__":
    unittest.main()
