"""Behavioral checks for reading-card annotations and assessment isolation."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import unittest

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

from card_common import Context, ValidationError
from structure_card import render, validate


def poem(mode="read"):
    return {
        "title": "登鹳雀楼", "author": "王之涣", "mode": mode,
        "lines": ["白日依山尽", "黄河入海流", "欲穷千里目", "更上一层楼"],
        "focus_lines": [3, 4],
    }


class RecordingContext(Context):
    def __init__(self):
        super().__init__()
        self.drawn = []

    def text(self, draw, xy, text, size=32, fill="#2E2F2F", bold=False,
             max_width=None, spacing=10):
        self.drawn.append({"draw": id(draw), "xy": xy, "text": text,
                           "size": size, "bold": bold, "fill": fill})
        return super().text(draw, xy, text, size=size, fill=fill, bold=bold,
                            max_width=max_width, spacing=spacing)


class ReadingAnnotationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = Context()

    def pixels(self, data):
        image, _ = render(data, self.ctx)
        return image.size, image.mode, image.tobytes(), image.info

    def test_pronunciation_changes_visible_reading_card(self):
        first = poem()
        first["pronunciations"] = [{"line": 4, "index": 1, "pinyin": "gèng"}]
        second = copy.deepcopy(first)
        second["pronunciations"][0]["pinyin"] = "gēng"
        self.assertNotEqual(self.pixels(first), self.pixels(second))

    def test_offscreen_pronunciation_and_rhyme_do_not_change_reading_card(self):
        base = poem()
        decorated = copy.deepcopy(base)
        decorated["pronunciations"] = [{"line": 1, "index": 1, "pinyin": "bái"}]
        decorated["rhymes"] = [{"line": 2, "index": 5}]
        self.assertEqual(self.pixels(base), self.pixels(decorated))

    def test_pronunciation_is_centered_above_corresponding_character(self):
        data = poem()
        data["pronunciations"] = [{"line": 4, "index": 1, "pinyin": "gèng"}]
        ctx = RecordingContext()
        render(data, ctx)
        pinyin = next(item for item in ctx.drawn if item["text"] == "gèng")
        character = next(item for item in ctx.drawn if item["text"] == "更")
        self.assertEqual(pinyin["draw"], character["draw"])
        self.assertLess(pinyin["size"], character["size"])
        self.assertLess(pinyin["xy"][1], character["xy"][1])
        centers = [item["xy"][0] + ctx.measure(item["text"], item["size"], item["bold"]) / 2
                   for item in (pinyin, character)]
        self.assertAlmostEqual(centers[0], centers[1], delta=1)

    def test_reading_mode_rhyme_changes_pixels(self):
        base = poem()
        highlighted = copy.deepcopy(base)
        highlighted["rhymes"] = [{"line": 4, "index": 5}]
        self.assertNotEqual(self.pixels(base), self.pixels(highlighted))

    def test_slash_is_visual_only_and_keeps_original_character_indices(self):
        data = poem()
        data["pauses"] = [{"line": 4, "after": [2]}]
        data["rhymes"] = [{"line": 4, "index": 5}]
        data["pronunciations"] = [{"line": 4, "index": 1, "pinyin": "gèng"}]
        original_lines = copy.deepcopy(data["lines"])
        rendered = []
        for style in ("slash", "space"):
            with self.subTest(style=style):
                data["pause_style"] = style
                checked = validate(data)
                self.assertEqual(checked["lines"], original_lines)
                self.assertEqual(checked["lines"][3][4], "楼")
                self.assertIn((4, 5), checked["rhymes"])
                rendered.append(self.pixels(data))
                self.assertEqual(data["lines"], original_lines)
        self.assertNotEqual(rendered[0], rendered[1])
        default = copy.deepcopy(data)
        del default["pause_style"]
        self.assertEqual(self.pixels(default), rendered[0])

    def test_poem_type_only_changes_teaching_modes(self):
        for mode in ("read", "structure", "recall", "hint"):
            with self.subTest(mode=mode):
                base = poem(mode)
                if mode == "hint":
                    base["reveals"] = [{"line": 4, "indices": [1]}]
                decorated = copy.deepcopy(base)
                decorated["poem_type"] = "五言绝句"
                if mode in ("read", "structure"):
                    self.assertNotEqual(self.pixels(base), self.pixels(decorated))
                else:
                    self.assertEqual(self.pixels(base), self.pixels(decorated))

    def test_new_annotations_do_not_leak_into_recall_or_hint(self):
        for mode in ("recall", "hint"):
            with self.subTest(mode=mode):
                base = poem(mode)
                if mode == "hint":
                    base["reveals"] = [{"line": 4, "indices": [1]}]
                decorated = copy.deepcopy(base)
                decorated.update(
                    poem_type="五言绝句",
                    pronunciations=[{"line": 4, "index": 5, "pinyin": "lóu"}],
                    pauses=[{"line": 4, "after": [2]}],
                    pause_style="slash",
                    rhymes=[{"line": 4, "index": 5}],
                )
                self.assertEqual(self.pixels(base), self.pixels(decorated))

    def test_pronunciations_and_pauses_do_not_clutter_structure_mode(self):
        base = poem("structure")
        decorated = copy.deepcopy(base)
        decorated.update(
            pronunciations=[{"line": 4, "index": 1, "pinyin": "gèng"}],
            pauses=[{"line": 4, "after": [2]}], pause_style="slash",
        )
        self.assertEqual(self.pixels(base), self.pixels(decorated))

    def test_invalid_annotation_positions_and_values_are_rejected(self):
        good = {"line": 4, "index": 1, "pinyin": "gèng"}
        invalid = [
            {"pronunciations": [dict(good, line=0)]},
            {"pronunciations": [dict(good, line=5)]},
            {"pronunciations": [dict(good, index=0)]},
            {"pronunciations": [dict(good, index=6)]},
            {"pronunciations": [dict(good, index=True)]},
            {"pronunciations": [good, good]},
            {"pronunciations": [dict(good, pinyin="")]},
            {"pronunciations": [dict(good, pinyin=" ")]},
            {"pronunciations": [dict(good, pinyin="gèng\nlóu")]},
            {"pronunciations": [dict(good, pinyin=123)]},
            {"pronunciations": [dict(good, extra="ignored")]},
            {"pause_style": "arrow"},
            {"poem_type": "五言\n绝句"},
        ]
        for changes in invalid:
            with self.subTest(changes=changes):
                data = poem()
                data.update(changes)
                with self.assertRaises(ValidationError):
                    validate(data)

    def test_legacy_examples_render_without_new_fields(self):
        for path in sorted((SKILL_ROOT / "examples").glob("structure*.json")):
            with self.subTest(example=path.name):
                data = json.loads(path.read_text(encoding="utf-8"))
                for field in ("poem_type", "pronunciations", "pause_style"):
                    data.pop(field, None)
                image, details = render(data, self.ctx)
                self.assertEqual(image.width, 1200)
                self.assertGreater(image.height, 0)
                self.assertEqual(details["mode"], data.get("mode", "structure"))


if __name__ == "__main__":
    unittest.main()
