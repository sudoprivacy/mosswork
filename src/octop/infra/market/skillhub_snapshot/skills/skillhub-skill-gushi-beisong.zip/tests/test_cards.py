"""Behavioral acceptance checks for the offline poetry-card scripts.

Run from any working directory with:
    python3 -m unittest discover -s path/to/gushi-beisong/tests -v

Rendering checks require the same Pillow and Chinese font as the CLI.
Examples and records in these tests are synthetic; no student data is used.
"""

from __future__ import annotations

import copy
from io import BytesIO
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SKILL_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = SKILL_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from PIL import Image
from card_common import Context, ValidationError
from correction_card import align_text, render as render_correction
from result_card import derive_result
from structure_card import render as render_structure


def attempt(*, independent=True, complete=True, errors=0):
    return {"independent": independent, "complete": complete, "errors": errors}


def result_input():
    return {
        "title": "登鹳雀楼", "date": "2026-11-06", "next_review": "2026-11-07",
        "first_attempt": attempt(), "achievement": "本次独立默写的四句完整准确。",
    }


class ResultEvidenceTests(unittest.TestCase):
    def test_first_independent_success(self):
        result = derive_result(result_input())
        self.assertEqual(result["outcome"], "learned")
        self.assertEqual(result["detail"], "首次独立完成")
        self.assertTrue(result["first_success"])

    def test_corrected_success_preserves_initial_failure(self):
        data = result_input()
        data["first_attempt"] = attempt(errors=2)
        data["final_attempt"] = attempt()
        result = derive_result(data)
        self.assertEqual(result["outcome"], "learned")
        self.assertEqual(result["detail"], "纠正后完成")
        self.assertFalse(result["first_success"])
        self.assertTrue(result["final_success"])
        self.assertEqual(result["first_attempt"]["errors"], 2)

    def test_delayed_first_success_establishes_observed_interval(self):
        data = result_input()
        data["previous_practice_date"] = "2026-11-03"
        result = derive_result(data)
        self.assertEqual(result["outcome"], "retained")
        self.assertEqual(result["interval_days"], 3)
        self.assertTrue(result["first_success"])

    def test_delayed_relearning_is_not_retention_pass(self):
        data = result_input()
        data["previous_practice_date"] = "2026-11-05"
        data["first_attempt"] = attempt(errors=1)
        data["final_attempt"] = attempt()
        result = derive_result(data)
        self.assertEqual(result["outcome"], "learned")
        self.assertEqual(result["detail"], "复习纠正后完成")
        self.assertFalse(result["first_success"])

    def test_prompted_first_attempt_does_not_establish_retention(self):
        data = result_input()
        data["previous_practice_date"] = "2026-11-05"
        data["first_attempt"] = attempt(independent=False)
        data["final_attempt"] = attempt()
        self.assertEqual(derive_result(data)["outcome"], "learned")

    def test_prompted_incomplete_or_inaccurate_last_attempt_cannot_pass(self):
        for last in [attempt(independent=False), attempt(complete=False), attempt(errors=1)]:
            with self.subTest(last=last):
                data = result_input()
                data["previous_practice_date"] = "2026-11-05"
                data["final_attempt"] = last
                result = derive_result(data)
                self.assertEqual(result["outcome"], "practice")
                self.assertFalse(result["final_success"])

    def test_incomplete_with_no_recorded_errors_does_not_pass(self):
        data = result_input()
        data["first_attempt"] = attempt(complete=False, errors=0)
        self.assertEqual(derive_result(data)["outcome"], "practice")

    def test_same_day_is_not_cross_day_retention(self):
        data = result_input()
        data["previous_practice_date"] = data["date"]
        result = derive_result(data)
        self.assertEqual(result["interval_days"], 0)
        self.assertEqual(result["outcome"], "learned")

    def test_leap_day_interval_and_year_transition(self):
        data = result_input()
        data.update(date="2024-03-01", next_review="2024-03-03", previous_practice_date="2024-02-28")
        self.assertEqual(derive_result(data)["interval_days"], 2)
        data.update(date="2027-01-01", next_review="2027-01-02", previous_practice_date="2026-12-31")
        self.assertEqual(derive_result(data)["interval_days"], 1)

    def test_invalid_or_reversed_dates_are_rejected(self):
        invalid_updates = [
            {"date": "2026-02-29"},
            {"date": "20261106"},
            {"next_review": "2026-11-06"},
            {"next_review": "2026-11-05"},
            {"previous_practice_date": "2026-11-07"},
        ]
        for changes in invalid_updates:
            with self.subTest(changes=changes):
                data = result_input()
                data.update(changes)
                with self.assertRaises(ValidationError):
                    derive_result(data)

    def test_boolean_error_counts_and_untrusted_result_labels_are_rejected(self):
        invalid = [
            {"first_attempt": attempt(errors=True)},
            {"first_attempt": attempt(independent="true")},
            {"first_attempt": attempt(errors=-1)},
            {"status": "间隔复习通过"},
            {"outcome": "retained"},
        ]
        for changes in invalid:
            with self.subTest(changes=changes):
                data = result_input()
                data.update(changes)
                with self.assertRaises(ValidationError):
                    derive_result(data)


class CorrectionAlignmentTests(unittest.TestCase):
    def assert_reconstructs(self, expected, actual):
        aligned = align_text(expected, actual)
        self.assertEqual("".join(cell["expected"] for cell in aligned), expected)
        self.assertEqual("".join(cell["actual"] for cell in aligned), actual)
        self.assertEqual([cell["expected_index"] for cell in aligned if cell["expected_index"] is not None],
                         list(range(1, len(expected) + 1)))
        self.assertEqual([cell["actual_index"] for cell in aligned if cell["actual_index"] is not None],
                         list(range(1, len(actual) + 1)))
        for cell in aligned:
            op = cell["op"]
            if op == "equal":
                self.assertEqual(cell["expected"], cell["actual"])
                self.assertTrue(cell["expected"])
            elif op == "replace":
                self.assertTrue(cell["expected"] and cell["actual"])
                self.assertNotEqual(cell["expected"], cell["actual"])
            elif op == "omit":
                self.assertTrue(cell["expected"])
                self.assertEqual(cell["actual"], "")
                self.assertIsNone(cell["actual_index"])
            elif op == "extra":
                self.assertEqual(cell["expected"], "")
                self.assertTrue(cell["actual"])
                self.assertIsNone(cell["expected_index"])
            else:
                self.fail(f"Unknown alignment operation: {op}")
        return aligned

    def test_distinct_replace_omit_and_extra(self):
        cases = [
            ("停车坐爱枫林晚", "停车坐爱枫林婉", "replace", "晚", "婉"),
            ("停车坐爱枫林晚", "停车坐枫林晚", "omit", "爱", ""),
            ("停车坐爱枫林晚", "停车坐爱红枫林晚", "extra", "", "红"),
        ]
        for expected, actual, op, before, after in cases:
            with self.subTest(actual=actual):
                changed = [cell for cell in self.assert_reconstructs(expected, actual) if cell["op"] != "equal"]
                self.assertEqual(len(changed), 1)
                self.assertEqual((changed[0]["op"], changed[0]["expected"], changed[0]["actual"]),
                                 (op, before, after))

    def test_blank_response_records_omissions(self):
        aligned = self.assert_reconstructs("更上一层楼", "")
        self.assertEqual([cell["op"] for cell in aligned], ["omit"] * 5)

    def test_repeated_characters_preserve_both_sequences(self):
        strings = [""] + ["".join(chars) for n in range(1, 4)
                          for chars in itertools.product("甲乙", repeat=n)]
        for expected, actual in itertools.product(strings, repeat=2):
            with self.subTest(expected=expected, actual=actual):
                first = self.assert_reconstructs(expected, actual)
                self.assertEqual(first, align_text(expected, actual))
                if expected == actual:
                    self.assertTrue(all(cell["op"] == "equal" for cell in first))

    def test_adjacent_swap_needs_two_character_edits(self):
        aligned = self.assert_reconstructs("甲乙丙", "乙甲丙")
        self.assertEqual(sum(cell["op"] != "equal" for cell in aligned), 2)


class RenderingInvariantTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = Context()

    def assert_same_pixels(self, one, two):
        self.assertEqual(one.size, two.size)
        self.assertEqual(one.mode, two.mode)
        self.assertEqual(one.tobytes(), two.tobytes())
        self.assertEqual(one.info, two.info)

    def poem(self, mode):
        return {
            "title": "登鹳雀楼", "author": "王之涣", "mode": mode,
            "lines": ["白日依山尽", "黄河入海流", "欲穷千里目", "更上一层楼"],
        }

    def test_recall_image_does_not_depend_on_hidden_content(self):
        first = self.poem("recall")
        second = {
            "title": first["title"], "mode": "recall", "author": "不应出现的作者",
            "lines": ["甲乙丙丁戊己庚"] * 8,
            "groups": [{"label": "不应出现的结构标签", "lines": list(range(1, 9))}],
            "rhymes": [{"line": 8, "index": 7}],
            "annotations": [{"line": 1, "text": "不应出现的答案注释"}],
            "sequence": ["不应出现的句序说明"],
            "pauses": [{"line": 1, "after": [2, 4]}],
            "reveals": [{"line": 1, "indices": [1, 2]}],
        }
        image_one, info_one = render_structure(first, self.ctx)
        image_two, info_two = render_structure(second, self.ctx)
        self.assert_same_pixels(image_one, image_two)
        self.assertEqual(info_one, info_two)

    def test_recall_still_renders_requested_poem_title(self):
        one, _ = render_structure(self.poem("recall"), self.ctx)
        other = self.poem("recall")
        other["title"] = "静夜思"
        two, _ = render_structure(other, self.ctx)
        self.assertNotEqual(one.tobytes(), two.tobytes())

    def test_hint_does_not_reveal_unauthorized_characters_or_annotations(self):
        first = self.poem("hint")
        first["reveals"] = [{"line": 1, "indices": [1, 2]}]
        second = copy.deepcopy(first)
        second.update(
            author="不应显示",
            lines=["白日甲乙丙", "春风吹又生", "锄禾日当午", "汗滴禾下土"],
            annotations=[{"line": 1, "text": "不应展示的完整答案"}],
            groups=[{"label": "不应展示的语义提示", "lines": [1, 2, 3, 4]}],
            rhymes=[{"line": 1, "index": 3}],
            sequence=["不应出现的提示"],
        )
        image_one, info_one = render_structure(first, self.ctx)
        image_two, info_two = render_structure(second, self.ctx)
        self.assert_same_pixels(image_one, image_two)
        self.assertEqual(info_one, info_two)
        # Control: a permitted character does affect the rendered image.
        second["lines"][0] = "红日甲乙丙"
        changed, _ = render_structure(second, self.ctx)
        self.assertNotEqual(changed.tobytes(), image_one.tobytes())

    def test_hint_requires_an_explicit_visible_position(self):
        with self.assertRaises(ValidationError):
            render_structure(self.poem("hint"), self.ctx)
        data = self.poem("hint")
        data["reveals"] = [{"line": 1, "indices": [6]}]
        with self.assertRaises(ValidationError):
            render_structure(data, self.ctx)

    def test_correction_card_reports_exact_match_without_fabricated_errors(self):
        image, info = render_correction({
            "title": "登鹳雀楼",
            "items": [{"expected": "更上一层楼", "actual": "更上一层楼"}],
        }, self.ctx)
        self.assertFalse(info["has_differences"])
        self.assertEqual(info["differences"], {"replace": 0, "omit": 0, "extra": 0})
        self.assertEqual(info["matching_characters"], 5)
        self.assertGreater(image.height, 0)


class CliOutputSafetyTests(unittest.TestCase):
    def test_bad_json_or_invalid_data_never_overwrites_previous_png(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            output = directory / "existing.png"
            buffer = BytesIO()
            Image.new("RGB", (3, 3), "#1E9BAE").save(buffer, format="PNG")
            prior_bytes = buffer.getvalue()
            output.write_bytes(prior_bytes)
            cases = [
                b'{"title":',
                b'{"title":"first","title":"second"}',
                b'[]',
                json.dumps(dict(result_input(), next_review="2026-11-06")).encode("utf-8"),
                b'\xff\xfe\x80',
            ]
            for payload in cases:
                with self.subTest(payload=payload[:40]):
                    input_file = directory / "input.json"
                    input_file.write_bytes(payload)
                    run = subprocess.run(
                        [sys.executable, str(SCRIPTS / "result_card.py"), "--input", str(input_file),
                         "--output", str(output)],
                        cwd=directory, capture_output=True, text=True, timeout=20,
                    )
                    self.assertEqual(run.returncode, 2, run.stdout + run.stderr)
                    self.assertFalse(json.loads(run.stderr)["ok"])
                    self.assertEqual(output.read_bytes(), prior_bytes)
                    self.assertEqual(list(directory.glob(".poem-card-*")), [])


if __name__ == "__main__":
    unittest.main()
