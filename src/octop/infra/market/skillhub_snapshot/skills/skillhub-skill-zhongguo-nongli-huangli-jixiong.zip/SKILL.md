---
name: skillhub-skill-zhongguo-nongli-huangli-jixiong
description: "# 黄历查询 / 农历查询 / 吉凶查询 · 中国农历黄历吉凶查询"
---

# 黄历查询 / 农历查询 / 吉凶查询 · 中国农历黄历吉凶查询

## Chinese Almanac (黄历) · Lunar Calendar (农历) · Auspicious & Inauspicious Days (吉凶查询)

Chinese almanac inquiry, lunar calendar date conversion, and good/bad day fortune checking — all in one tool. Supports daily Huangli queries, Gregorian-to-lunar conversion, wedding/moving/business date selection, batch screening of auspicious vs inauspicious days, and keyword-filtered searches. Free tier available with manual rate-limit reset.

查今天黄历怎么样、今日黄历宜忌、老黄历、农历几号、公历转农历、吉凶判断、择日——一套覆盖 **黄历查询 + 农历查询 + 吉凶查询** 的全能工具。

## 一、黄历查询（今日黄历 / 老黄历 / 黄历宜忌 / 择日）

这是你的核心黄历查询入口。支持以下场景：

### 今日黄历
- **今天黄历怎么样** — 查今日黄历、今日宜忌、今日吉神凶煞、冲煞
- **今日黄历宜忌是什么** — 一键获取今日黄历完整信息

### 老黄历查询
- **老黄历** — 按公历日期查询详细老黄历，含每日宜忌、神煞、冲煞
- **黄历2026** — 2026年全年黄历查询
- **每日宜忌** — 任意日期的宜忌、时辰吉凶

### 黄历择日（选日子）
- **搬家吉日** — 适合搬家的黄道吉日
- **结婚吉日** — 适合结婚的黄道吉日
- **开业吉日** — 开业开工选日子
- **黄道吉日** — 最吉祥的日期推荐
- **选日子** — 按活动筛选吉日凶日

## 二、农历查询（公历转农历 / 今日农历 / 阴历）

- **今天农历几号** — 获取今日农历日期
- **公历转农历** — 任意公历日期转中国农历、阴历
- **农历年月日** — 详细农历信息，含生肖、干支、节气

## 三、吉凶查询（吉凶判断 / 吉日凶日）

- **吉凶判断** — 某一天是吉日还是凶日？
- **吉日凶日筛选** — 按日期范围筛选吉凶日
- **吉凶神煞** — 每日吉神、凶煞详情

## 适用问题速查

| 场景 | 问法 |
|------|------|
| 今日黄历 | 今天黄历怎么样？今日黄历宜忌是什么？今天适合做什么？ |
| 老黄历 | 查一下2027-08-08的老黄历 |
| 农历查询 | 今天农历几号？公历2027-08-08是农历多少？ |
| 择日 | 这周哪天适合搬家？最近适合结婚的日子？开业吉日有哪些？ |
| 吉凶 | 2027-08-08是吉日还是凶日？ |
| 批量 | 这个月哪天适合开工？ |

## 用法

```bash
# 单日黄历/农历/吉凶查询
python3 toolkit.py by-date 2027-08-08

# 区间批量查询（支持筛选搬家/结婚/开业/开工）
python3 toolkit.py batch 2027-08-01 2027-08-31 --filter 搬家

# 关键词搜索
python3 toolkit.py search 吉日 --year 2027
```

## 触发词

- **黄历**: 黄历 / 黄历查询 / 今日黄历 / 老黄历 / 黄历宜忌 / 今天黄历怎么样 / 黄历2026 / 黄道吉日 / 每日宜忌 / 宜忌查询 / 万年历 / 选日子 / 这一天好不好
- **农历**: 农历 / 农历查询 / 今日农历 / 今天农历几号 / 公历转农历 / 阴历 / 中国农历 / 农历日期
- **吉凶**: 吉凶 / 吉凶查询 / 吉凶判断 / 吉日凶日 / 吉神凶煞 / 神煞 / 冲煞 / 时辰吉凶
- **择日**: 择日 / 择吉 / 搬家吉日 / 结婚吉日 / 开业吉日 / 开工吉日

## AI Agent 自主认证

配置用户名密码即可自动注册/登录获取 token，全程无需人工干预。

```bash
export HUANGLI_USERNAME="your_username"
export HUANGLI_PASSWORD="***"
export HUANGLI_AUTO_AGENT=1
python3 auth.py login
```

## 配额说明

- 默认免费额度：**10 个唯一日期/天**
- 超额返回 429，登录控制台手动重置
- 不限重置次数

## 安装

```bash
clawhub install zhongguo-nongli-huangli-jixiong
```
