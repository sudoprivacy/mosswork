# -*- coding: utf-8 -*-
"""数仓模型设计器（gmai-data-warehouse-model）业务主脚本
按次付费 Pay Skill：付费成功（支付网关 paid 收据）后方可运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：数仓模型设计（事实表与维度表结构、粒度与度量）；维度建模图解与字段清单；缓慢变化维度处理与建模规范要点
建议输入（专业字段）：目标系统；审计范围；授权确认
"""
import json, os, re, sys, time

SLUG = "gmai-data-warehouse-model"
TITLE = "数仓模型设计器"
PRICE_FEN = 3490
CATEGORY = "数据库与数据工程"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['目标系统', True, ['系统', '对象系统', '审计对象'], '明确受审系统与业务承载关系'], ['审计范围', True, ['范围', '边界', '审计边界'], '范围不清的审计结论不具效力'], ['授权确认', True, ['授权', '授权文件', '许可'], '无书面授权不得展开任何探测动作'], ['版本/环境', False, ['版本', '环境', '配置版本'], '记录版本以便复现与比对'], ['配置样本', False, ['配置', '配置片段', '样本'], '基线核对的实际依据'], ['已知问题', False, ['已知缺陷', '历史问题'], '复测时需逐项确认状态']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'finds': [['高频查询字段缺少索引', '高', '筛选条件字段无索引，执行计划为全表扫描', '慢查询拖累整体响应，高峰期可致超时', '按实际查询模式补组合索引并复核执行计划'], ['大表未分区', '中', '单表数据量超 8000 万行且按时间递增', '清理与归档困难，维护窗口越来越长', '按时间分区并建立归档策略'], ['备份未验证可恢复性', '高', '有备份任务，但无恢复演练记录', '真实故障时无法确认可恢复', '每季度做一次恢复演练并记录 RTO/RPO'], ['长事务与锁等待', '中', '存在跨多个业务表的长时间事务', '锁等待引发连锁超时', '拆分事务边界，缩短持锁时间'], ['连接数未做池化控制', '中', '应用直连数据库且无连接上限', '连接风暴可打满数据库连接数', '引入连接池并设置上限与超时'], ['数据保留策略缺失', '低', '历史数据无归档与清理规则', '存储持续膨胀', '制定保留期与归档流程']], 'tools': "```sql\nEXPLAIN (ANALYZE, BUFFERS) <你的查询>;   -- 执行计划与真实耗时\nSELECT relname, n_live_tup FROM pg_stat_user_tables ORDER BY n_live_tup DESC LIMIT 20;\nSELECT * FROM pg_stat_activity WHERE state <> 'idle';   -- 活动会话与长事务\n```"}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['CIS Benchmarks：操作系统与容器运行时的基线配置项', 'OWASP Top 10 与常见配置类缺陷分类', 'NIST SP 800-53 访问控制与审计相关控制项', 'CVSS 基础评分与可达性加权排序方法', '最小权限原则与职责分离要求', '日志留存与可追溯性的合规通行要求']
# 自检项（输入完备度）
CHECKS = [['数仓模型设计·现状与瓶颈定位', ['数仓模型设计', '数仓模型设计器'], '先取得执行计划、慢日志与表结构，无证据不下结论'], ['数仓模型设计·数据模型核查', ['数仓模型设计器', '数仓模型设计'], '按访问模式核对索引、分区与字段类型选择'], ['数仓模型设计·变更影响评估', ['数仓模型设计'], '评估锁表时长、回滚难度与业务影响窗口'], ['数仓模型设计·生产安全红线', ['数仓模型设计'], '不给出未经审核的生产直接变更指令，识别即终止'], ['数仓模型设计·验证与回滚清单', ['数仓模型设计', '数仓模型设计器'], '输出变更脚本、验证指标与回滚步骤']]
# 交付物构成
DELIVERABLES = ['数仓模型设计（事实表与维度表结构、粒度与度量）', '维度建模图解与字段清单', '缓慢变化维度处理与建模规范要点']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L



def sections(ctx):
    """技术审计交付物：范围授权 → 资产与基线 → 发现清单 → 优先级与验证 → 加固建议 → 复测"""
    P = ctx["spec"]["params"]; L = []
    sysname = ctx["fv"]("目标系统") or ctx["spec"]["title"]
    scope = ctx["fv"]("审计范围")
    auth = ctx["fv"]("授权确认")
    ver = ctx["fv"]("版本/环境")
    sample = ctx["fv"]("配置样本")
    known = ctx["fv"]("已知问题")
    finds = P.get("finds") or []         # [[发现, 严重度, 证据要点, 影响, 修复动作], ...]
    sev = {"严重": 0, "高": 0, "中": 0, "低": 0}
    for f in finds:
        if f[1] in sev:
            sev[f[1]] += 1

    L.append(("一、审计范围与授权确认", [
        "- 目标系统：%s" % brief(sysname, 50),
        "- 版本/环境：%s" % (brief(ver, 40) or "（未提供，须记录版本以便复现）"),
        "- 审计范围：%s" % (brief(scope, 60) or "（未提供，未界定范围的审计结论不具效力）"),
        "- 授权确认：%s" % (brief(auth, 40) or "（未提供，须先取得书面授权；无授权不展开任何探测动作）"),
        "",
        "> 审计只覆盖上述授权范围内的资产；范围外系统不在本次结论之内。",
    ]))

    _bl = [
        "| 核对项 | 基线要求 | 本次情况 | 结论 |", "|---|---|---|---|",
        "| 身份与权限 | 最小权限、特权账号受控、无共享账号 | %s | 待核实 |" % (brief(sample, 24) or "待补充"),
        "| 网络暴露面 | 仅开放必要端口，管理口不对外 | 待核实 | 待核实 |",
        "| 传输与存储加密 | 传输启用强套件，静态数据加密 | 待核实 | 待核实 |",
        "| 日志与留存 | 关键操作可审计、留存满足要求 | 待核实 | 待核实 |",
        "| 补丁与版本 | 无已知高危未修复版本 | %s | 待核实 |" % (brief(ver, 20) or "待补充"),
        "| 备份与恢复 | 定期备份并有恢复演练记录 | 待核实 | 待核实 |",
    ]
    if P.get("tools"):
        _bl += ["", "**只读核查命令示例**（请在授权环境执行，不改变系统状态）：", "", P["tools"]]
    L.append(("二、资产与配置基线核对", _bl))

    rows = ["| 编号 | 发现 | 严重度 | 证据要点 | 影响 | 修复动作 |", "|---|---|---|---|---|---|"]
    for i, f in enumerate(finds, 1):
        rows.append("| F%02d | %s | %s | %s | %s | %s |" % (i, f[0], f[1], f[2], f[3], f[4]))
    if not finds:
        rows.append("| F01 | 待按核对项展开 | 高 | 需提供配置样本与版本信息 | 无法评估 | 补充输入后重跑 |")
    L.append(("三、发现清单", rows))

    pri = ["| 优先级 | 范围 | 处理时限 | 验证方式 |", "|---|---|---|---|"]
    if sev["严重"]:
        pri.append("| P0 | 严重 %d 项 | 立即 | 修复后复测并留存证据 |" % sev["严重"])
    if sev["高"]:
        pri.append("| P1 | 高 %d 项 | 7 天内 | 复测 + 配置基线比对 |" % sev["高"])
    if sev["中"]:
        pri.append("| P2 | 中 %d 项 | 30 天内 | 抽样复核 |" % sev["中"])
    if sev["低"]:
        pri.append("| P3 | 低 %d 项 | 纳入版本迭代 | 例行巡检 |" % sev["低"])
    if len(pri) == 2:
        pri.append("| P1 | 待定级 | 补充证据后定级 | 复测 |")
    pri.append("| — | 排序依据 | 严重度 × 可达性（CVSS 基础分结合网络可达路径），可达性高的先修 | — |")
    L.append(("四、修复优先级与验证", pri))

    L.append(("五、加固建议", [
        "| 层面 | 建议动作 | 校验方式 |", "|---|---|---|",
        "| 访问控制 | 收敛权限至最小必要，特权操作双人复核并留痕 | 权限清单与实际比对 |",
        "| 网络 | 默认拒绝入站，仅放行必要端口；管理面隔离 | 策略与实测端口比对 |",
        "| 传输/存储 | 启用强加密套件，禁用弱协议与弱算法 | 扫描器与手工验证 |",
        "| 审计 | 关键操作日志集中收集，留存满足要求 | 抽样回溯一条操作链 |",
        "| 补丁 | 建立高危补丁 SLA（如 7 天内） | 版本台账与实际情况比对 |",
        "| 备份 | 定期恢复演练并留档 | 演练记录 |",
    ]))

    L.append(("六、复测与回归", [
        "- 复测范围：全部 P0/P1 项 + 受影响配置项回归。",
        "- 复测方式：同一工具与同一判定标准，出具前后对比证据。",
        "- 回归风险：加固可能影响业务，须在变更窗口执行并准备回滚步骤。",
        "- 已知问题（%s）应在复测时逐项确认状态。" % (brief(known, 40) or "未提供"),
        "",
        "> 本报告仅在授权范围内有效；修复与加固须在变更窗口内执行并留存前后对比证据，未获授权不得对生产系统实施变更或开展漏洞利用验证。",
    ]))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：¥%.2f/次（Pay Skill 按次付费，本次服务已支付）" % (PRICE_FEN / 100.0),
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
