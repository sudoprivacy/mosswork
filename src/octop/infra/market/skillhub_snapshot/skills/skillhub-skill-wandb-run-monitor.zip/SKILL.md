---
name: skillhub-skill-wandb-run-monitor
description: "使用 W&B Python SDK 和 Public API 从活动运行中流式传输实时训练指标、系统统计信息和梯度。通过 wandb.Api().runs() 查询运行历史记录以检测指标退化，并将摘要发布到 Slack。支持工件版本管理和血缘追踪。"
---

# Weights & Biases 运行监控器

Uses the W&B Python SDK and Public API to stream live training metrics, system stats, and gradients from active runs. Alerts on metric regressions by querying run history via wandb.Api().runs() and posts summaries to Slack. Supports artifact versioning and lineage tracking.

## Prerequisites

Python, Weights & Biases SDK, Slack

## Installation

Basic usage or getting-started notes:
- Monitoring & Usage
- Documentation Index
- Fetch the complete documentation index at: https://docs.wandb.ai/llms.txt

- Source: https://docs.wandb.ai/

## Documentation

- https://docs.wandb.ai/
