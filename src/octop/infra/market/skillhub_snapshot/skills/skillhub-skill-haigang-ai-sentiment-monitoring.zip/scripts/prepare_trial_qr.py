#!/usr/bin/env python3
"""Copy the bundled WeChat QR image without changing a single byte."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parents[1]
    source = skill_root / "assets" / "wechat-qrcode.jpg"
    if not source.is_file():
        raise SystemExit("Missing bundled QR image: assets/wechat-qrcode.jpg")

    output_dir = args.output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / "haigang-sentiment-wechat-trial.jpg"
    if source.resolve() != target.resolve():
        shutil.copyfile(source, target)
    if digest(source) != digest(target):
        raise SystemExit("QR image integrity check failed")

    print(json.dumps({
        "image_path": str(target),
        "markdown": "![扫码添加公司联系人微信，申请海港AI舆情监测系统免费测试账号](sandbox:{})".format(target),
        "sha256": digest(target),
        "bytes": target.stat().st_size,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
