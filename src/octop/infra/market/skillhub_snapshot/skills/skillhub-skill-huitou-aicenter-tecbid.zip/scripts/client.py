#!/usr/bin/env python
"""标书一键生成轻客户端(仅标准库,零第三方依赖)。

命令:
    login [user-key]       设备授权登录(无参自动打开授权页并等待完成);也可手动传入 user-key
    login --start / --poll 两步非阻塞授权:发起(打印授权页地址与确认码后秒回;默认自动打开
                           授权页,--no-open 交给智能体用内嵌浏览器打开)→ 轮询结果,
                           供智能体把授权页地址与确认码即时展示到对话中
    logout                 删除 config.json 退出登录
    status                 检查登录状态(config.json 是否含 user_key)
    bid <tender_file>      上传招标文件发起标书生成;--no-wait 秒回 task_id(智能体推荐)
    result [task_id]       查询生成进度/结果,FIN 时下载投标文件 docx

每次启动先做一次更新检查(同一天仅一次,记录写入 config.json);
接口返回 402(余额不足)时自动签发门户登录地址,引导用户充值;
未登录/身份无效(401)时自动发起设备授权:打开授权页面,用户登录并点击授权后自动取得 user-key。
"""
import argparse
import json
import mimetypes
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from datetime import date
from pathlib import Path

# ===== 常量 =====
BASE_URL = "https://biaoshuai.huitoue.com/api/skill"
PORTAL_URL = "https://aicenter.huitoue.com/"  # 用户门户:授权页所在站点,个人信息页可复制 accessKey(即 user-key)
PRODUCT_ID = 6          # 与服务端 skill_bid_service 的标书产品 id 保持一致
CLIENT_VERSION = "1.0.0"
POLL_INTERVAL = 5       # 轮询间隔(秒)
POLL_TIMEOUT = 1800     # 阻塞式轮询上限(秒,30 分钟);超时后任务仍在服务端继续生成
REQUEST_TIMEOUT = 60
UPLOAD_TIMEOUT = 300

# 设备授权(网关已处理签名,客户端无需额外签名请求头)
AUTH_POLL_INTERVAL = 3      # 授权结果轮询间隔(秒)
AUTH_EXPIRES_DEFAULT = 600  # 授权有效期兜底(秒),服务端未返回 expiresIn 时使用
AUTH_MAX_ROUNDS = 2         # 授权过期/超时后自动重新发起的最多次数

STYLE_LEVELS = ("NONE", "LOW", "MIDDLE", "MANY")
STYLE_LABELS = {"NONE": "无", "LOW": "少量", "MIDDLE": "适量", "MANY": "大量"}

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.json"

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_USAGE = 2
EXIT_NOT_LOGIN = 3
EXIT_NO_BALANCE = 4


# ===== 配置读写 =====

def load_config() -> dict:
    try:
        data = json.loads(CONFIG_PATH.read_text("utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_config(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", "utf-8")


def base_url() -> str:
    url = os.getenv("ZBH_AI_BASE_URL") or load_config().get("base_url") or BASE_URL
    return str(url).rstrip("/")


# ===== HTTP =====

class ApiError(Exception):
    """接口错误,携带 HTTP 状态码与服务端 detail 文案。"""

    def __init__(self, status: int, message: str):
        super().__init__(f"HTTP {status}: {message}")
        self.status = status
        self.message = message


def _request(method: str, url: str, *, headers: dict | None = None,
             data: bytes | None = None, timeout: int = REQUEST_TIMEOUT) -> tuple[int, dict]:
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
            return resp.status, (json.loads(body) if body else {})
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        try:
            payload = json.loads(raw)
        except ValueError:
            payload = None
        if not isinstance(payload, dict):
            payload = {"detail": raw or f"HTTP {e.code}"}
        return e.code, payload
    except urllib.error.URLError as e:
        raise ApiError(0, f"无法连接服务 {url}:{e.reason}") from e


def _ensure_ok(status: int, payload: dict) -> dict:
    if 200 <= status < 300:
        return payload
    detail = payload.get("detail")
    if not isinstance(detail, str):
        detail = json.dumps(detail, ensure_ascii=False) if detail is not None else f"HTTP {status}"
    raise ApiError(status, detail)


def api_get(path: str, *, user_key: str = "", params: dict | None = None,
            timeout: int = REQUEST_TIMEOUT) -> dict:
    url = base_url() + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {"user-key": user_key} if user_key else {}
    return _ensure_ok(*_request("GET", url, headers=headers, timeout=timeout))


def api_post(path: str, payload: dict, *, user_key: str = "",
             timeout: int = REQUEST_TIMEOUT) -> dict:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if user_key:
        headers["user-key"] = user_key
    status, body = _request("POST", base_url() + path, headers=headers, data=data, timeout=timeout)
    return _ensure_ok(status, body)


def api_upload_bid(path: Path, *, page_num: int, is_blind: bool,
                   style_table: str, style_img: str, style_flow: str,
                   custom_catalog: str, user_key: str) -> dict:
    """multipart 上传招标文件与生成参数到 /bid。

    filename 直接使用真实文件名(含中文,按 UTF-8 编码传递),
    另附 filename*(RFC 2231)兜底给严格按标准解析的服务端。
    custom_catalog 为空串表示不提供自定义目录,由服务端按评分点自动生成。
    """
    content = path.read_bytes()
    ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    boundary = uuid.uuid4().hex
    fields = [
        ("page_num", str(page_num)),
        ("is_blind", "true" if is_blind else "false"),
        ("style_table", style_table),
        ("style_img", style_img),
        ("style_flow", style_flow),
        ("custom_catalog", custom_catalog),
    ]
    parts = []
    for name, value in fields:
        parts.append((
            f"--{boundary}\r\n"
            f"Content-Disposition: form-data; name=\"{name}\"\r\n\r\n"
            f"{value}\r\n"
        ).encode("utf-8"))
    parts.append((
        f"--{boundary}\r\n"
        f"Content-Disposition: form-data; name=\"tender_file\"; "
        f"filename=\"{path.name}\"; filename*=UTF-8''{urllib.parse.quote(path.name)}\r\n"
        f"Content-Type: {ctype}\r\n\r\n"
    ).encode("utf-8") + content + f"\r\n--{boundary}--\r\n".encode("utf-8"))
    headers = {"Content-Type": f"multipart/form-data; boundary={boundary}", "user-key": user_key}
    status, payload = _request("POST", base_url() + "/bid",
                               headers=headers, data=b"".join(parts), timeout=UPLOAD_TIMEOUT)
    return _ensure_ok(status, payload)


def portal_url(url: str) -> str:
    """补全门户页面地址:相对路径一律按门户(aicenter)拼接——授权页在门户,不在服务网关。"""
    if re.match(r"^https?://", url, re.I):
        return url
    return PORTAL_URL.rstrip("/") + "/" + url.lstrip("/")


def download_file(url: str, target: Path) -> Path:
    """把文件下载地址落盘;相对路径按服务 base_url 的 host 拼接。"""
    if not re.match(r"^https?://", url, re.I):
        if url.startswith("/"):
            parsed = urllib.parse.urlsplit(base_url())
            url = f"{parsed.scheme}://{parsed.netloc}{url}"
        else:
            url = base_url() + "/" + url
    req = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
        data = resp.read()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return target


# ===== 输出辅助 =====

def warn(msg: str) -> None:
    print(f"[警告] {msg}", file=sys.stderr)


def fail(msg: str, code: int = EXIT_ERROR) -> int:
    print(f"[错误] {msg}", file=sys.stderr)
    return code


def sanitize_name(name: str) -> str:
    """去掉文件名里 Windows 不允许的字符,避免投标文件落盘失败。"""
    return re.sub(r'[<>:"/\\|?*]', "_", name).strip() or "投标文件"


def describe_balance(b: dict) -> str:
    if b.get("unit_type") == "QUANTITY":
        return f"产品「{b.get('name')}」剩余次数:{b.get('remaining_count')}"
    valid = "有效" if b.get("in_range") else "已过期"
    return f"产品「{b.get('name')}」到期:{b.get('expire_at')}({valid})"


def start_device_auth() -> tuple[str, str, str, int]:
    """调用发起设备授权接口,返回 (token, 授权页地址, 确认码, 有效秒数)。

    失败直接以退出码 3 结束(两步式 --start 与阻塞式 login 的失败处理一致)。
    """
    try:
        data = api_post("/auth/device/start", {})
    except ApiError as e:
        sys.exit(fail(f"发起设备授权失败:{e.message}", EXIT_NOT_LOGIN))
    token = str(data.get("token") or "")
    if not token:
        sys.exit(fail("发起设备授权失败:服务端未返回 token", EXIT_NOT_LOGIN))
    # 服务端实际返回 snake_case(authorize_url/expires_in),文档为驼峰,两种都兼容
    authorize_url = portal_url(str(data.get("authorize_url") or data.get("authorizeUrl") or ""))
    code = str(data.get("code", ""))
    expires = int(data.get("expires_in") or data.get("expiresIn") or AUTH_EXPIRES_DEFAULT)
    return token, authorize_url, code, expires


def show_authorize_page(authorize_url: str, code: str, *, auto_open: bool = True) -> None:
    """打印授权页地址与确认码(供智能体即时转述到对话中)。

    auto_open=True 时自动用系统浏览器打开授权页(人工终端场景);
    auto_open=False 不打开,交给智能体用内嵌浏览器展示授权页。
    """
    print("请在打开的页面中登录并进行授权。")
    print(f"授权页面:{authorize_url}")
    print(f"确认码:{code}(请在页面上核对一致后再授权)")
    if auto_open and authorize_url.lower().startswith(("http://", "https://")):
        webbrowser.open(authorize_url)


def save_authorized_key(poll: dict) -> str:
    """授权成功(approved)响应中取凭证(服务端字段 accessKey,兼容蛇形/驼峰)写入 config.json 并打印,返回 key。

    服务端未返回凭证时返回空串,由调用方决定重试或报错。
    """
    user_key = str(poll.get("access_key") or poll.get("accessKey") or "")
    if not user_key:
        return ""
    cfg = load_config()
    cfg["user_key"] = user_key
    save_config(cfg)
    print(f"授权成功,user-key 已保存到 {CONFIG_PATH}")
    if poll.get("phone"):
        print(f"用户手机号:{poll['phone']}")
    return user_key


def device_authorize() -> str:
    """设备授权:发起授权 → 自动打开授权页 → 轮询结果,成功后保存 user-key 并返回。

    未登录或身份无效时调用;授权未完成(过期/超时)直接以退出码 3 结束。
    """
    for round_no in range(1, AUTH_MAX_ROUNDS + 1):
        token, authorize_url, code, expires = start_device_auth()
        show_authorize_page(authorize_url, code)
        print(f"等待授权中(每 {AUTH_POLL_INTERVAL} 秒检测一次,约 {expires // 60} 分钟内有效)…")
        deadline = time.time() + expires
        while time.time() < deadline:
            time.sleep(AUTH_POLL_INTERVAL)
            try:
                poll = api_post("/auth/device/poll", {"token": token})
            except ApiError as e:
                warn(f"轮询授权结果失败:{e.message}")
                continue
            status = str(poll.get("status") or "").lower()
            if status == "approved":
                user_key = save_authorized_key(poll)
                if not user_key:
                    warn("服务端未返回 user-key,将重新发起授权")
                    break
                return user_key
            if status == "expired":
                print("授权请求已过期。")
                break
        else:
            print("等待授权超时。")
        if round_no < AUTH_MAX_ROUNDS:
            print("将重新发起授权…")
    sys.exit(fail("未能完成授权,请重新执行 login", EXIT_NOT_LOGIN))


def require_login() -> str:
    user_key = load_config().get("user_key") or ""
    if not user_key:
        user_key = device_authorize()
    return user_key


def guide_recharge(user_key: str) -> None:
    """余额不足:调 /sso/login(请求体传 user_key,服务端实际约定)签发一次性门户登录地址。"""
    print("账户余额不足,请充值后重试。")
    if not user_key:
        return
    try:
        data = api_post("/sso/login", {"user_key": user_key})
        print("已生成门户自动登录地址(一次性,5 分钟内有效),浏览器打开后即可充值:")
        print(data.get("login_url", ""))
    except ApiError as e:
        warn(f"获取门户登录地址失败,请手动登录门户充值:{e.message}")


# ===== 更新检查 =====

def check_update() -> None:
    """每天最多一次拉取产品最新版本,发现新版本提示下载;记录写入 config.json。"""
    if not PRODUCT_ID:
        return
    cfg = load_config()
    today = date.today().isoformat()
    if cfg.get("last_version_check") == today:
        return
    try:
        data = api_get("/product/latest", params={"product_id": PRODUCT_ID})
    except Exception as e:
        warn(f"更新检查失败(不影响使用):{e}")
        return
    cfg["last_version_check"] = today
    cfg["latest_version"] = data.get("version")
    save_config(cfg)

    local = cfg.get("local_version") or CLIENT_VERSION
    if data.get("version") and data["version"] != local:
        warn(f"发现新版本 {data['version']}(当前 {local}),请及时下载更新(地址 10 分钟内有效):")
        warn(str(data.get("download_url") or ""))


# ===== 命令 =====

def _clear_pending_auth() -> None:
    """清掉 config.json 里的待授权临时记录(授权完成/过期后调用)。"""
    cfg = load_config()
    if "auth_token" in cfg or "auth_expires_at" in cfg:
        cfg.pop("auth_token", None)
        cfg.pop("auth_expires_at", None)
        save_config(cfg)


def cmd_login_start(*, no_open: bool = False) -> int:
    """两步授权第一步:只发起设备授权,打印授权页地址与确认码后立即返回,不阻塞等待。

    轮询凭证 token 只写入 config.json 供 login --poll 使用、从不打印;
    调用方(智能体)应把打印的授权页地址与确认码即时转述到对话中,
    并用内嵌浏览器打开授权页(no_open=True 时不自动弹系统浏览器)。
    """
    token, authorize_url, code, expires = start_device_auth()
    show_authorize_page(authorize_url, code, auto_open=not no_open)
    cfg = load_config()
    cfg["auth_token"] = token
    cfg["auth_expires_at"] = int(time.time()) + expires
    save_config(cfg)
    print(f"约 {expires // 60} 分钟内有效,请稍候执行 login --poll 查询授权结果")
    return EXIT_OK


def poll_device_auth() -> int:
    """两步授权第二步:轮询一次授权结果立即返回。退出码 0=已授权,3=未授权/已过期。"""
    cfg = load_config()
    token = str(cfg.get("auth_token") or "")
    if not token:
        return fail("没有待查询的授权请求,请先执行 login --start", EXIT_NOT_LOGIN)
    if time.time() >= int(cfg.get("auth_expires_at") or 0):
        _clear_pending_auth()
        return fail("授权请求已过期,请重新执行 login --start", EXIT_NOT_LOGIN)
    try:
        poll = api_post("/auth/device/poll", {"token": token})
    except ApiError as e:
        return fail(f"轮询授权结果失败:{e.message}", EXIT_NOT_LOGIN)
    status = str(poll.get("status") or "").lower()
    if status == "expired":
        _clear_pending_auth()
        return fail("授权请求已过期或已被取走,请重新执行 login --start", EXIT_NOT_LOGIN)
    if status == "approved":
        _clear_pending_auth()
        if not save_authorized_key(poll):
            return fail("授权完成但服务端未返回 user-key,请重新执行 login --start", EXIT_NOT_LOGIN)
        return EXIT_OK
    print("尚未授权(pending),请继续执行 login --poll")
    return EXIT_NOT_LOGIN


def cmd_login(args) -> int:
    if args.start:
        return cmd_login_start(no_open=args.no_open)
    if args.poll:
        return poll_device_auth()
    user_key = (args.user_key or "").strip()
    if user_key:
        cfg = load_config()
        cfg["user_key"] = user_key
        save_config(cfg)
        _clear_pending_auth()  # 手动登录后清掉可能残留的待授权记录
    else:
        user_key = device_authorize()  # 无参:自动设备授权,成功后已保存
    try:
        print(f"用户手机号:{api_get('/user', user_key=user_key).get('phone', '')}")
    except ApiError as e:
        warn(f"用户 Key 校验失败:{e.message}")
    if PRODUCT_ID:
        try:
            print(describe_balance(api_get("/balance", user_key=user_key,
                                           params={"product_id": PRODUCT_ID})))
        except ApiError as e:
            warn(f"余额查询失败:{e.message}")
    return EXIT_OK


def cmd_logout(_args) -> int:
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
        print(f"已删除 {CONFIG_PATH},退出登录")
    else:
        print("当前未登录(config.json 不存在)")
    return EXIT_OK


def cmd_status(_args) -> int:
    cfg = load_config()
    user_key = cfg.get("user_key") or ""
    if not user_key:
        print("未登录:config.json 中没有 user_key,请先执行 login 完成授权")
        return EXIT_NOT_LOGIN
    print(f"已登录(user-key: {user_key[:6]}****)")
    try:
        print(f"用户手机号:{api_get('/user', user_key=user_key).get('phone', '')}")
    except ApiError as e:
        if e.status == 401:
            warn("user-key 无效或已失效,请重新执行 login 重新授权")
        else:
            warn(f"用户信息查询失败:{e.message}")
    if PRODUCT_ID:
        try:
            print(describe_balance(api_get("/balance", user_key=user_key,
                                           params={"product_id": PRODUCT_ID})))
        except ApiError as e:
            warn(f"余额查询失败:{e.message}")
    else:
        warn("未配置标书产品 ID(PRODUCT_ID),跳过余额查询")
    return EXIT_OK


def print_overview(p: dict) -> None:
    """解析完成后服务端会附带项目概况与技术分,及时转述给用户。"""
    overview = str(p.get("project_overview") or "").strip()
    if overview:
        print(f"项目概况:{overview}")
    score = p.get("tech_score")
    if score not in (None, ""):
        print(f"技术分:{score}")


def save_bid_file(p: dict, *, out: str | None, source: Path | None) -> None:
    """FIN 时把投标文件 docx 下载落盘;失败只警告,下载地址始终打印。"""
    url = p.get("bid_file_url") or ""
    if not url:
        print("任务已完成,但服务端未返回投标文件下载地址")
        return
    print(f"投标文件下载:{url}")
    if out:
        target = Path(out)
    elif source:
        target = source.parent / f"{sanitize_name(source.stem)}-投标文件.docx"
    else:
        target = Path(f"{p.get('task_id', 'bid')}-投标文件.docx")
    try:
        download_file(url, target)
        print(f"投标文件已保存:{target.resolve()}")
    except Exception as e:
        warn(f"投标文件下载失败,请用上面的地址手动下载:{e}")


STATUS_LABELS = {"RUN": "生成中", "FIN": "已完成", "ERR": "失败"}

STEP_LABELS = {
    "upload": "上传",
    "parse": "解析",
    "outline": "目录",
    "content": "正文",
    "docx": "投标文件",
}


def fmt_progress(p: dict, *, elapsed: int | None = None) -> str:
    """把 get_bid 返回拼成一行人类可读的进度,如:[生成中 42%] 正在撰写正文(已等待 12分05秒)"""
    status = str(p.get("status") or "").upper()
    label = STATUS_LABELS.get(status, status or "未知")
    parts = [f"[{label} {p.get('overall', 0) or 0}%]"]
    msg = str(p.get("message") or "").strip()
    if msg:
        parts.append(msg)
    step = p.get("step")
    if step:
        parts.append(f"(当前:{STEP_LABELS.get(step, step)})")
    if elapsed is not None:
        parts.append(f"已等待 {elapsed // 60}分{elapsed % 60:02d}秒")
    return " ".join(parts)


def wait_bid(task_id: str, *, out: str | None, source: Path | None) -> int:
    """轮询 get_bid 直到 FIN/ERR,打印进度并下载投标文件。"""
    print(f"开始轮询生成进度(每 {POLL_INTERVAL}s 一次,最长 {POLL_TIMEOUT // 60} 分钟)…")
    last_line = ""
    deadline = time.time() + POLL_TIMEOUT
    while True:
        try:
            p = api_get(f"/bid/{task_id}")
        except ApiError as e:
            if e.status == 404:
                return fail(f"任务不存在或已过期:{task_id}")
            return fail(e.message)
        line = fmt_progress(p)
        if line != last_line:
            print(line, flush=True)
            last_line = line
        status = p.get("status")
        if status == "ERR":
            return fail("标书生成失败:" + (p.get("message") or ""))
        if status == "FIN":
            print_overview(p)
            save_bid_file(p, out=out, source=source)
            return EXIT_OK
        if time.time() >= deadline:
            warn(f"等待超时,任务仍在生成中,请稍后执行 result {task_id} 查询")
            return EXIT_ERROR
        time.sleep(POLL_INTERVAL)


def cmd_bid(args) -> int:
    user_key = require_login()
    path = Path(args.file)
    if not path.is_file():
        return fail(f"招标文件不存在:{path}", EXIT_USAGE)
    if not 1 <= args.page_num <= 2000:
        return fail(f"标书页数须在 1-2000 之间,当前:{args.page_num}", EXIT_USAGE)
    custom_catalog = (args.custom_catalog or "").strip()
    print("生成参数:页数 {} | {} | 目录{} | 表格{} | 图片{} | 流程图{}".format(
        args.page_num, "暗标" if args.blind else "明标",
        "自定义" if custom_catalog else "按评分点自动生成",
        STYLE_LABELS[args.style_table], STYLE_LABELS[args.style_img],
        STYLE_LABELS[args.style_flow]))
    print(f"正在上传招标文件:{path.name}({path.stat().st_size / 1024:.0f} KB)")
    data = None
    for attempt in (1, 2):  # 身份无效(401)→ 自动重新授权一次再试
        try:
            data = api_upload_bid(path, page_num=args.page_num, is_blind=args.blind,
                                  style_table=args.style_table, style_img=args.style_img,
                                  style_flow=args.style_flow, custom_catalog=custom_catalog,
                                  user_key=user_key)
            break
        except ApiError as e:
            if e.status == 402:
                guide_recharge(user_key)
                return EXIT_NO_BALANCE
            if e.status == 401 and attempt == 1:
                warn("用户身份无效或已失效,请重新授权。")
                user_key = device_authorize()
                continue
            return fail(e.message)
    task_id = data["task_id"]
    cfg = load_config()
    cfg["last_task_id"] = task_id
    cfg["last_task_time"] = int(time.time())  # 供 result 计算已等待时长
    cfg["last_tender_file"] = str(path.resolve())  # 供 result 缺省把 docx 存到招标文件同目录
    save_config(cfg)
    print(f"标书生成任务已受理,task_id:{task_id}")
    if args.no_wait:
        print(f"稍后执行 result {task_id} 查询进度")
        return EXIT_OK
    return wait_bid(task_id, out=args.out, source=path)


def cmd_result(args) -> int:
    cfg = load_config()
    task_id = args.task_id or cfg.get("last_task_id")
    if not task_id:
        return fail("未指定 task_id,且没有最近一次标书生成记录", EXIT_USAGE)
    try:
        p = api_get(f"/bid/{task_id}")
    except ApiError as e:
        if e.status == 404:
            return fail(f"任务不存在或已过期:{task_id}")
        return fail(e.message)
    # 最近一次 bid 提交的任务顺带打印已等待时长,便于向用户播报进度
    elapsed = None
    source = None
    if task_id == cfg.get("last_task_id"):
        if cfg.get("last_task_time"):
            elapsed = max(0, int(time.time()) - int(cfg["last_task_time"]))
        if cfg.get("last_tender_file"):
            cand = Path(cfg["last_tender_file"])
            source = cand if cand.is_file() else None
    print(f"任务 {task_id}")
    print(fmt_progress(p, elapsed=elapsed))
    status = p.get("status")
    if status == "FIN":
        print_overview(p)
        save_bid_file(p, out=args.out, source=source)
        return EXIT_OK
    if status == "ERR":
        return fail("标书生成失败:" + (p.get("message") or ""))
    print(f"任务进行中,请稍后再次执行 result {task_id}")
    return EXIT_OK


# ===== 入口 =====

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="client.py",
        description="标书一键生成轻客户端(零依赖,纯标准库)",
        epilog="示例:python client.py login && python client.py bid 招标文件.pdf --page-num 100",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("login", help="设备授权登录(无参)、手动保存 user-key,或 --start/--poll 两步非阻塞授权")
    p.add_argument("user_key", nargs="?", default="",
                   help=f"可选:门户 {PORTAL_URL} 个人信息页复制的 user-key,传入则跳过设备授权")
    g = p.add_mutually_exclusive_group()
    g.add_argument("--start", action="store_true",
                   help="两步授权第一步:发起设备授权,打印授权页地址与确认码后立即返回"
                        "(默认自动弹系统浏览器;智能体请加 --no-open 改用内嵌浏览器打开)")
    g.add_argument("--poll", action="store_true",
                   help="两步授权第二步:轮询一次授权结果,退出码 0=已授权(自动保存 user-key),3=未授权/已过期")
    p.add_argument("--no-open", action="store_true",
                   help="与 --start 搭配:不自动弹系统浏览器,由智能体用内嵌浏览器打开授权页")
    p.set_defaults(func=cmd_login)

    p = sub.add_parser("logout", help="删除 config.json 退出登录")
    p.set_defaults(func=cmd_logout)

    p = sub.add_parser("status", help="检查登录状态、用户信息与产品余额")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("bid", help="上传招标文件发起标书生成")
    p.add_argument("file", help="招标文件路径(pdf/doc 等)")
    p.add_argument("--page-num", type=int, required=True, help="标书页数(1-2000)")
    p.add_argument("--blind", action="store_true", help="暗标(缺省为明标)")
    p.add_argument("--style-table", type=str.upper, default="MIDDLE", choices=STYLE_LEVELS,
                   help="表格风格:NONE 无 / LOW 少量 / MIDDLE 适量(缺省)/ MANY 大量")
    p.add_argument("--style-img", type=str.upper, default="MIDDLE", choices=STYLE_LEVELS,
                   help="图片风格:NONE 无 / LOW 少量 / MIDDLE 适量(缺省)/ MANY 大量")
    p.add_argument("--style-flow", type=str.upper, default="MIDDLE", choices=STYLE_LEVELS,
                   help="流程图风格:NONE 无 / LOW 少量 / MIDDLE 适量(缺省)/ MANY 大量")
    p.add_argument("--custom-catalog", help="自定义目录全文(可多行,原样粘贴);不传则按评分点自动生成目录")
    p.add_argument("--no-wait", action="store_true", help="只受理不等待,稍后用 result 查询")
    p.add_argument("--out", help="投标文件 docx 保存路径(默认与招标文件同目录)")
    p.set_defaults(func=cmd_bid)

    p = sub.add_parser("result", help="查询标书生成进度/结果")
    p.add_argument("task_id", nargs="?", help="任务 ID,缺省用最近一次 bid 的")
    p.add_argument("--out", help="完成后把投标文件 docx 下载到该路径")
    p.set_defaults(func=cmd_result)

    _force_utf8_stdio()  # 先统一输出编码,保证 --help/参数报错在管道下也不是乱码
    args = parser.parse_args(argv)
    check_update()
    return args.func(args)


def _force_utf8_stdio() -> None:
    """输出统一 UTF-8,避免 Windows 控制台/管道按 GBK 编出乱码。"""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
