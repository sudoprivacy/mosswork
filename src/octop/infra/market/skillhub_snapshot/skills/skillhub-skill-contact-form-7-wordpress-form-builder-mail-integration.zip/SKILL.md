---
name: skillhub-skill-contact-form-7-wordpress-form-builder-mail-integration
description: "Contact Form 7 是 Rock Lobster Inc. 公司长期运行的 WordPress 表单插件，拥有超过 1000 万次活跃安装，并在 contactform7.com 提供官方文档。此技能适用于需要了解网站表单、邮件模板、验证行为和 shortcode 位置在 Contact Form 7 中实际处理方式的代理。"
---

# Contact Form 7 WordPress 表单构建器和邮件集成

Contact Form 7 是 Rock Lobster Inc. 公司长期运行的 WordPress 表单插件，拥有超过 1000 万次活跃安装，并在 contactform7.com 提供官方文档。此技能适用于需要了解网站表单、邮件模板、验证行为和 shortcode 位置在 Contact Form 7 中实际处理方式的代理。

## 先决条件

WordPress 6.7+, PHP 7.4+

## 安装

使用与您的环境匹配的上游安装或设置路径：
- Make WordPress

基本用法或入门说明：
- 开发
- Support
- 描述

- Source: https://wordpress.org/plugins/contact-form-7/

## 文档

- https://contactform7.com/docs/
