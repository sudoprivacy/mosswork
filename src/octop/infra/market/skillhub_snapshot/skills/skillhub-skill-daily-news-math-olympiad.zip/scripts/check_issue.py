#!/usr/bin/env python3
"""每日奥数题 issue 校验器（零依赖）。

校验一份 issue JSON 是否同时满足：三阶递进、年级能力矩阵、新闻可核验、
图文并茂、讲解清晰、题面不泄露答案、儿童版面安全。

用法:
    python3 check_issue.py --file issue.json [--json]
    python3 check_issue.py --file issue.json --rules ../assets/grade-rules.json --json

退出码:
    0 通过 / 1 存在 error / 2 参数或数据错误
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List

ASSETS = Path(__file__).resolve().parent.parent / "assets"
SCHEME_HTTP = "http" + "://"
SCHEME_HTTPS = "https" + "://"
INTEGER_RE = re.compile(r"\d+")
DECIMAL_RE = re.compile(r"\d+\.\d+")
SVG_SHAPE_RE = re.compile(r"<(rect|circle|path|line|polygon|polyline|ellipse|text)\b")


class Checks:
    def __init__(self) -> None:
        self.items: List[Dict[str, Any]] = []

    def add(self, name: str, ok: bool, hint: str, level: str = "error", detail: str = "") -> None:
        self.items.append({"name": name, "ok": bool(ok), "level": level, "hint": hint, "detail": detail})

    @property
    def ok(self) -> bool:
        return all(i["ok"] for i in self.items if i["level"] == "error")

    def errors(self) -> List[Dict[str, Any]]:
        return [i for i in self.items if i["level"] == "error" and not i["ok"]]

    def warnings(self) -> List[Dict[str, Any]]:
        return [i for i in self.items if i["level"] == "warning" and not i["ok"]]


def _text_of(level: Dict[str, Any]) -> str:
    parts = [
        str(level.get("question", "")),
        str(level.get("title", "")),
        str(level.get("transfer", "")),
    ]
    parts += [str(x) for x in level.get("hints", []) if isinstance(x, str)]
    parts += [str(x) for x in level.get("steps", []) if isinstance(x, str)]
    mistake = level.get("mistake", {})
    if isinstance(mistake, dict):
        parts += [str(mistake.get(k, "")) for k in ("wrong", "right", "why")]
    return "\n".join(parts)


def load_rules(path: Path | None = None) -> Dict[str, Any]:
    p = path or (ASSETS / "grade-rules.json")
    with p.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def validate_issue(issue: Any, rules: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """对 issue 做全量校验，返回结构化结果。"""
    rules = rules or load_rules()
    grades = rules.get("grades", {})
    safety = rules.get("safety", {})
    c = Checks()

    if not isinstance(issue, dict):
        c.add("issue_object", False, "issue 必须是 JSON 对象")
        return _report(c, {})

    # 1. 顶层字段
    required = ["date", "grade", "title", "knowledgePoint", "news", "levels", "parentNote", "cheer"]
    missing = [k for k in required if not issue.get(k)]
    c.add("required_fields", not missing, "补齐字段: " + ", ".join(missing), detail=",".join(missing))

    # 2. 日期
    raw_date = str(issue.get("date", ""))
    try:
        issue_date = datetime.strptime(raw_date, "%Y-%m-%d").date()
        date_ok = True
    except ValueError:
        issue_date = date.today()
        date_ok = False
    c.add("date_format", date_ok, "date 必须是 YYYY-MM-DD")

    # 3. 年级
    grade = str(issue.get("grade", ""))
    grule = grades.get(grade)
    c.add("grade_supported", bool(grule), "grade 需在 grade-rules.json 中，默认 G2", detail=grade)
    grule = grule or grades.get(rules.get("defaultGrade", "G2"), {})
    max_number = int(grule.get("maxNumber", 100))
    max_steps = int(grule.get("maxSteps", 3))
    max_hints = int(grule.get("maxHints", 2))
    forbidden = [str(x) for x in grule.get("forbidden", [])]

    # 4. 新闻取材
    news = issue.get("news") or {}
    stype = str(news.get("sourceType", ""))
    c.add("news_source_type", stype in ("online", "offline"), "sourceType 只能是 online 或 offline")
    if stype == "online":
        news_missing = [k for k in ("sourceName", "sourceHeadline", "sourceDate", "fact") if not news.get(k)]
        c.add("news_online_fields", not news_missing,
              "联网取材必须写 sourceName / sourceHeadline / sourceDate / fact",
              detail=",".join(news_missing))
        try:
            src_date = datetime.strptime(str(news.get("sourceDate", "")), "%Y-%m-%d").date()
            gap = abs((issue_date - src_date).days)
            date_gap_ok = gap <= 3
        except ValueError:
            gap = -1
            date_gap_ok = False
        c.add("news_freshness", date_gap_ok, "新闻日期与出题日期相差不得超过 3 天", detail=f"gap={gap}")
        disclaimer = str(news.get("disclaimer", ""))
        c.add("number_disclaimer", ("练习设定" in disclaimer) or ("不是新闻" in disclaimer),
              "必须声明题目数字是练习设定，不能冒充新闻统计数字")
    elif stype == "offline":
        c.add("offline_reason", bool(news.get("offlineReason")),
              "离线兜底必须写明 offlineReason（为何没用新闻）")
    c.add("news_situation", bool(news.get("situation")), "news.situation 需写明题面情境")

    # 5. 三阶结构
    levels = issue.get("levels")
    is_list = isinstance(levels, list)
    c.add("levels_list", is_list and len(levels) == 3,
          "levels 必须恰好 3 阶（L1 热身 / L2 进阶 / L3 挑战）")
    if not is_list:
        levels = []
    ids_ok = [str(x.get("id", "")) for x in levels if isinstance(x, dict)] == ["L1", "L2", "L3"]
    c.add("level_ids", ids_ok, "levels 的 id 必须依次是 L1 / L2 / L3")
    stars = [x.get("stars") for x in levels if isinstance(x, dict)]
    stars_ok = all(isinstance(s, int) for s in stars) and len(stars) == 3 and stars[0] < stars[1] < stars[2]
    c.add("ladder_stars", stars_ok, "三阶 stars 必须严格递增", detail=str(stars))
    ideas = [str(x.get("newIdea", "")) for x in levels if isinstance(x, dict)]
    c.add("ladder_new_idea", len(ideas) == 3 and all(ideas) and len(set(ideas)) == 3,
          "每阶必须写明不同的 newIdea（新增的思维点）")
    step_counts = [len(x.get("steps", [])) for x in levels if isinstance(x, dict) and isinstance(x.get("steps"), list)]
    c.add("ladder_depth", len(step_counts) == 3 and step_counts[0] <= step_counts[1] <= step_counts[2],
          "讲解步数不得逐阶减少", detail=str(step_counts))

    # 6. 逐阶内容、年级约束、图示、讲解
    child_text = " ".join([
        str(issue.get("title", "")),
        str(news.get("sourceHeadline", "")),
        str(news.get("fact", "")),
        str(news.get("disclaimer", "")),
        str(issue.get("parentNote", "")),
        str(issue.get("cheer", "")),
    ])
    for idx, lv in enumerate(levels):
        if not isinstance(lv, dict):
            continue
        tag = str(lv.get("id", f"L{idx + 1}"))
        needed = ["question", "svg", "answer", "answerUnit", "hints", "steps", "mistake", "transfer"]
        miss = [k for k in needed if k not in lv or lv.get(k) in ("", None, [])]
        c.add(f"{tag}_fields", not miss, f"{tag} 缺字段: " + ", ".join(miss), detail=",".join(miss))

        text = _text_of(lv)
        nums = [int(n) for n in INTEGER_RE.findall(text)]
        too_big = [n for n in nums if n > max_number]
        c.add(f"{tag}_number_range", not too_big,
              f"{tag} 出现超出 {max_number} 的数字，超出本年级能力范围", detail=str(too_big))
        c.add(f"{tag}_no_decimal", not DECIMAL_RE.search(text),
              f"{tag} 不得出现小数形式")
        hits = [w for w in forbidden if w and w in text]
        c.add(f"{tag}_forbidden_concepts", not hits,
              f"{tag} 命中本年级禁用知识点: " + ", ".join(hits), detail=",".join(hits))

        ans = lv.get("answer")
        ans_ok = isinstance(ans, int) and not isinstance(ans, bool) and 0 < ans <= max_number
        c.add(f"{tag}_answer", ans_ok, f"{tag} 答案必须是 1..{max_number} 的整数")
        if isinstance(ans, int):
            leaked = re.search(r"(?<!\d)" + str(ans) + r"(?!\d)", str(lv.get("question", "")))
            c.add(f"{tag}_no_answer_leak", not leaked,
                  f"{tag} 题干里直接出现了答案 {ans}，孩子不用算就知道结果")

        hints = lv.get("hints") if isinstance(lv.get("hints"), list) else []
        c.add(f"{tag}_hints", 1 <= len(hints) <= max_hints,
              f"{tag} 提示需 1..{max_hints} 层，先给方向再给算式")
        steps = lv.get("steps") if isinstance(lv.get("steps"), list) else []
        c.add(f"{tag}_steps", len(steps) >= 2 and len(steps) <= max_steps,
              f"{tag} 讲解需 2..{max_steps} 步，每步写清算式与理由", detail=str(len(steps)))
        mk = lv.get("mistake") if isinstance(lv.get("mistake"), dict) else {}
        c.add(f"{tag}_mistake", all(mk.get(k) for k in ("wrong", "right", "why"))
              and str(mk.get("wrong")) != str(mk.get("right")),
              f"{tag} 易错点需写 错误做法 / 正确做法 / 错因 三段")
        c.add(f"{tag}_transfer", bool(str(lv.get("transfer", "")).strip()),
              f"{tag} 需有一条举一反三的变式题")

        svg = str(lv.get("svg", ""))
        c.add(f"{tag}_svg_present", "<svg" in svg and bool(SVG_SHAPE_RE.search(svg)),
              f"{tag} 必须配内联 SVG 示意图，且含可见图形元素")
        unsafe = [p for p in ("<script", "onload=", SCHEME_HTTP, SCHEME_HTTPS, "<image", "xlink:href") if p in svg]
        c.add(f"{tag}_svg_safe", not unsafe,
              f"{tag} 图示不得含脚本、外链或远程图片: " + ", ".join(unsafe), detail=",".join(unsafe))
        c.add(f"{tag}_svg_label", "aria-label" in svg or "role='img'" in svg or 'role="img"' in svg,
              f"{tag} 图示需带 aria-label 说明它画的是什么", level="warning")
        child_text += " " + text

    banned = [str(w) for w in safety.get("childFacingBannedText", [])]
    banned_hits = [w for w in banned if w and w in child_text]
    c.add("child_facing_text", not banned_hits,
          "面向孩子的成品文字不得出现年级标签或评价性词汇: " + ", ".join(banned_hits),
          detail=",".join(banned_hits))

    summary = {
        "date": raw_date,
        "grade": grade,
        "maxNumber": max_number,
        "newsSourceType": stype,
        "levels": len(levels),
        "answers": [x.get("answer") for x in levels if isinstance(x, dict)],
        "checks": len(c.items),
        "errors": len(c.errors()),
        "warnings": len(c.warnings()),
    }
    return _report(c, summary)


def _report(c: Checks, summary: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ok": c.ok,
        "checks": c.items,
        "errors": c.errors(),
        "warnings": c.warnings(),
        "summary": summary,
    }


def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="校验每日奥数题 issue JSON")
    ap.add_argument("--file", required=True, help="issue JSON 路径")
    ap.add_argument("--rules", help="年级规则 JSON，默认读取 assets/grade-rules.json")
    ap.add_argument("--json", action="store_true", help="输出结构化 JSON")
    args = ap.parse_args(argv)

    path = Path(args.file)
    if not path.is_file():
        print(json.dumps({"error": f"文件不存在: {path}"}, ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        with path.open("r", encoding="utf-8") as fh:
            issue = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"error": f"读取失败: {exc}"}, ensure_ascii=False), file=sys.stderr)
        return 2

    rules = None
    if args.rules:
        try:
            rules = load_rules(Path(args.rules))
        except (OSError, json.JSONDecodeError) as exc:
            print(json.dumps({"error": f"规则读取失败: {exc}"}, ensure_ascii=False), file=sys.stderr)
            return 2
    result = validate_issue(issue, rules)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"校验 {'通过' if result['ok'] else '未通过'}：{result['summary'].get('checks', 0)} 项检查，"
              f"{len(result['errors'])} 个错误，{len(result['warnings'])} 个提醒")
        for item in result["errors"]:
            print(f"  [ERROR] {item['name']}: {item['hint']}")
        for item in result["warnings"]:
            print(f"  [WARN ] {item['name']}: {item['hint']}")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
