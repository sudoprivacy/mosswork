#!/usr/bin/env python3
"""每日新闻奥数题主 CLI（Python 3 标准库，零依赖，脚本本身不联网）。

子命令:
    where                       状态与归档目录
    init                        建立孩子画像（默认 G2）
    next                        取今日出题规格 brief（含去重与新闻检索建议）
    validate                    校验 issue JSON（委托 check_issue.py）
    render                      把 issue 渲染成可打印的单文件 HTML 讲义
    check                       校验 HTML 成品红线
    write                       幂等归档本期并更新进度
    status                      查看进度与下一期建议
    automation                  输出每日调度契约（不创建宿主任务实例）

退出码: 0 成功 / 1 业务失败 / 2 参数或数据错误
"""
from __future__ import annotations

import argparse
import html
import json
import os
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_issue import validate_issue, load_rules  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
TEMPLATE = ASSETS / "worksheet-template.html"
RULES_PATH = ASSETS / "grade-rules.json"
BANK_PATH = ASSETS / "topic-bank.json"
HOME = Path(os.environ.get("DAILY_MATH_HOME", str(Path.home() / ".workbuddy" / "daily-news-math-olympiad")))
STATE_PATH = HOME / "state.json"
ISSUES_DIR = HOME / "issues"
SCHEME_HTTP = "http" + "://"
SCHEME_HTTPS = "https" + "://"
EPOCH = date(2026, 1, 1)


def esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def dump_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def emit(data: Dict[str, Any], as_json: bool, human: str = "") -> None:
    if as_json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    elif human:
        print(human)


def parse_date(text: str) -> date:
    try:
        return datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError("日期必须是 YYYY-MM-DD") from exc


def read_state() -> Dict[str, Any]:
    if not STATE_PATH.is_file():
        return {
            "version": 1,
            "profile": {"grade": "G2", "nickname": "", "avoid": []},
            "history": [],
            "pending": None,
            "createdAt": date.today().isoformat(),
        }
    try:
        return load_json(STATE_PATH)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"状态文件损坏，请先备份再处理: {exc}") from exc


def save_state(state: Dict[str, Any]) -> None:
    dump_json(STATE_PATH, state)


def pick_topic(stamp: str, bank: Dict[str, Any]) -> Dict[str, Any]:
    topics = bank.get("topics", [])
    if not topics:
        return {"id": "generic", "situation": "生活里的小场景", "knowledgePoints": [], "newsKeywords": []}
    d = parse_date(stamp)
    return topics[(d - EPOCH).days % len(topics)]


def brief_for(stamp: str, state: Dict[str, Any], rules: Dict[str, Any], bank: Dict[str, Any],
              topic_override: str = "", knowledge_override: str = "") -> Dict[str, Any]:
    grade = str(state.get("profile", {}).get("grade", "G2"))
    grule = rules.get("grades", {}).get(grade, {})
    fallback = pick_topic(stamp, bank)
    history = state.get("history", [])
    recent = [h.get("knowledgePoint", "") for h in history[-3:] if isinstance(h, dict)]
    return {
        "date": stamp,
        "issueNo": len(history) + 1,
        "grade": grade,
        "gradeRules": grule,
        "topic": topic_override or str(fallback.get("situation", "")),
        "topicId": "custom" if topic_override else fallback.get("id", ""),
        "newsKeywords": [f"{topic_override or fallback.get('situation', '')} 今日新闻 数据"]
                        + [str(x) for x in fallback.get("newsKeywords", [])],
        "newsPolicy": {
            "requireFreshNews": True,
            "maxSourceAgeDays": 3,
            "sourceFields": ["sourceName", "sourceHeadline", "sourceDate", "fact"],
            "blocked": rules.get("safety", {}).get("newsBlocked", []),
            "fallback": "检索不到合适的儿童向新闻时，改用离线情境库并写 offlineReason",
            "numberRule": "题面数字必须声明为练习设定，不得冒充新闻统计数字",
        },
        "recentKnowledgePoints": recent,
        "avoidKnowledgePoints": recent,
        "knowledgePoint": knowledge_override or "由当日新闻情境与年级矩阵共同决定，且不得与近 3 期重复",
        "ladderSpec": [
            {"id": "L1", "label": "热身", "stars": 1, "requirement": grule.get("ladder", ["一步运算"])[0],
             "goal": "人人能上手，一步出答案"},
            {"id": "L2", "label": "进阶", "stars": 2, "requirement": grule.get("ladder", ["", "两步运算"])[1],
             "goal": "在同一情境里多走一步，需要两步算式"},
            {"id": "L3", "label": "挑战", "stars": 3, "requirement": grule.get("ladder", ["", "", "画图思维题"])[2],
             "goal": "必须画图才想得清楚，是本期的思维点"},
        ],
        "sharedSituation": "三阶共用同一新闻情境与同一批角色，只增加条件，不换题面世界观",
        "illustration": grule.get("illustration", "实物图优先"),
        "illustrationRules": "每阶 1 张内联 SVG，一图对应一个数量关系，图形数量与题面数字一致",
        "explanationRules": "每阶 1-2 层提示、2 步以上分步讲解、错误/正确对照、错因、1 道变式题",
        "childFacingBanned": rules.get("safety", {}).get("childFacingBannedText", []),
        "outputContract": {
            "issue": "issue JSON，字段见 references/issue-schema.md",
            "worksheet": "单文件 HTML，A4 打印友好，题面与讲解分页",
            "gate": "先 validate，再 render，再 check，最后 write",
        },
    }


def level_block(lv: Dict[str, Any], index: int) -> str:
    stars = int(lv.get("stars", index + 1))
    star_text = "★" * stars + "☆" * (3 - stars)
    hints = "".join(f"<li>{esc(h)}</li>" for h in lv.get("hints", []))
    svg = str(lv.get("svg", ""))
    hint_id = f"hint-{esc(lv.get('id', index + 1))}"
    return (
        f'<section class="level level-{index + 1}">\n'
        f'  <div class="level-head"><span class="badge">{esc(lv.get("id", ""))}</span>'
        f'<h3>{esc(lv.get("label", ""))} · {esc(lv.get("title", ""))}</h3>'
        f'<span class="stars">{star_text}</span></div>\n'
        f'  <figure class="figure">{svg}</figure>\n'
        f'  <p class="question">{esc(lv.get("question", ""))}</p>\n'
        f'  <div class="answer-space"><span class="label">我的算式和答案：</span><div class="lines"></div></div>\n'
        f'  <input type="checkbox" id="{hint_id}" class="reveal-toggle">\n'
        f'  <label class="hint-label" for="{hint_id}">想不出来？点开分层提示</label>\n'
        f'  <div class="hints-content"><ol>{hints}</ol></div>\n'
        f'</section>\n'
    )


def solution_block(lv: Dict[str, Any]) -> str:
    steps = "".join(f"<li>{esc(s)}</li>" for s in lv.get("steps", []))
    mk = lv.get("mistake", {}) if isinstance(lv.get("mistake"), dict) else {}
    return (
        f'<article class="solution">\n'
        f'  <h3><span class="answer-pill">答案 {esc(lv.get("answer", ""))} {esc(lv.get("answerUnit", ""))}</span>'
        f'{esc(lv.get("id", ""))} · {esc(lv.get("title", ""))}</h3>\n'
        f'  <ol class="steps">{steps}</ol>\n'
        f'  <div class="mistake"><span class="wrong">✗ {esc(mk.get("wrong", ""))}</span>'
        f'<span class="right">✓ {esc(mk.get("right", ""))}</span>'
        f'<p class="why">{esc(mk.get("why", ""))}</p></div>\n'
        f'  <p class="transfer">举一反三：{esc(lv.get("transfer", ""))}</p>\n'
        f'</article>\n'
    )


def render_html(issue: Dict[str, Any]) -> str:
    template = TEMPLATE.read_text(encoding="utf-8")
    d = parse_date(str(issue.get("date", "")))
    news = issue.get("news", {}) if isinstance(issue.get("news"), dict) else {}
    online = news.get("sourceType") == "online"
    source = (f"{news.get('sourceName', '')} · {news.get('sourceDate', '')}") if online else \
             f"离线生活情境（{news.get('offlineReason', '今日无合适新闻')}）"
    headline = news.get("sourceHeadline") or "今天的生活小场景"
    fact = news.get("fact") or "我们用一个熟悉的生活场景来练数学思维。"
    disclaimer = news.get("disclaimer") or "题目里的数字是练习设定，不是新闻里的统计数字。"
    levels = issue.get("levels", [])
    values = {
        "TITLE": esc(issue.get("title", "今日奥数小挑战")),
        "DATE_LABEL": esc(f"{d.year} 年 {d.month} 月 {d.day} 日"),
        "ISSUE_NO": esc(f"第 {int(issue.get('issueNo', 1))} 期"),
        "KNOWLEDGE_POINT": esc(issue.get("knowledgePoint", "")),
        "NEWS_HEADLINE": esc(headline),
        "NEWS_FACT": esc(fact),
        "NEWS_SOURCE": esc(source),
        "DISCLAIMER": esc(disclaimer),
        "LEVELS": "\n".join(level_block(lv, i) for i, lv in enumerate(levels)),
        "SOLUTIONS": "\n".join(solution_block(lv) for lv in levels),
        "PARENT_NOTE": esc(issue.get("parentNote", "")),
        "CHEER": esc(issue.get("cheer", "")),
    }
    for key, value in values.items():
        template = template.replace("{{" + key + "}}", value)
    return template


def check_html(text: str) -> Dict[str, Any]:
    checks: List[Dict[str, Any]] = []

    def add(name: str, ok: bool, hint: str, level: str = "error") -> None:
        checks.append({"name": name, "ok": bool(ok), "level": level, "hint": hint})

    add("placeholder_clean", "{{" not in text, "模板占位符必须全部替换")
    add("inline_svg_count", text.count("<svg") >= 3, "三阶各需一张内联 SVG 示意图")
    add("no_external_link", SCHEME_HTTP not in text and SCHEME_HTTPS not in text,
        "成品不得含任何外链，保证离线可打印")
    add("no_script", "<script" not in text and "onload=" not in text, "成品不得含脚本")
    add("no_runtime_state", all(x not in text for x in ("localStorage", "setInterval", "autoplay")),
        "成品不得含本地存储、定时器或自动播放")
    add("print_ready", all(x in text for x in ("@page", "@media print", "break-inside", "page-break")),
        "需含 A4 打印样式与题面/讲解分页")
    add("answer_space", "answer-space" in text, "每阶需有答题留白")
    add("folded_solution", all(x in text for x in ("reveal-toggle", "hints-content", "solutions", "display: none")),
        "提示与讲解需可折叠，避免孩子直接看到答案")
    add("print_expansion", ".hints-content, .solutions { display: block !important; }" in text,
        "打印时提示与讲解必须自动展开，否则打印成品会缺讲解")
    grade_words = ["年级", "考试", "排名", "差生"]
    grade_hits = [w for w in grade_words if w in text]
    add("child_facing_clean", not grade_hits, "面向孩子的打印成品不得出现年级或评价字样: " + ", ".join(grade_hits))
    add("min_size", len(text.encode("utf-8")) > 3000, "成品过小，可能只渲染了空模板")
    errors = [x for x in checks if x["level"] == "error" and not x["ok"]]
    return {
        "ok": not errors,
        "checks": checks,
        "errors": errors,
        "summary": {"checks": len(checks), "errors": len(errors), "bytes": len(text.encode("utf-8"))},
    }


# ------------------------------------------------------------------ 子命令

def cmd_where(args: argparse.Namespace) -> int:
    emit({"home": str(HOME), "state": str(STATE_PATH), "issues": str(ISSUES_DIR),
          "assets": str(ASSETS)}, args.json, str(HOME))
    return 0


def cmd_init(args: argparse.Namespace) -> int:
    rules = load_rules(RULES_PATH)
    grade = args.grade
    if grade not in rules.get("grades", {}):
        print(json.dumps({"error": f"不支持的年级 {grade}，可用: {', '.join(rules['grades'])}"},
                         ensure_ascii=False), file=sys.stderr)
        return 2
    if STATE_PATH.is_file() and not args.force:
        print(json.dumps({"error": "已存在画像，覆盖请加 --force"}, ensure_ascii=False), file=sys.stderr)
        return 1
    state = read_state()
    state["profile"] = {"grade": grade, "nickname": args.nickname,
                        "avoid": [x.strip() for x in args.avoid.split(",") if x.strip()]}
    if not args.force:
        state["history"] = []
        state["pending"] = None
    save_state(state)
    emit({"ok": True, "profile": state["profile"], "state": str(STATE_PATH)}, args.json,
         f"画像已保存：{grade}（默认值），记录位置 {STATE_PATH}")
    return 0


def cmd_next(args: argparse.Namespace) -> int:
    stamp = args.date or date.today().isoformat()
    try:
        parse_date(stamp)
        state = read_state()
        rules = load_rules(RULES_PATH)
        bank = load_json(BANK_PATH)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    pending = state.get("pending")
    if pending and pending.get("date") == stamp and not args.force:
        print(json.dumps({"error": "今天已经取过出题规格但尚未归档，先完成本期或加 --force 重取"},
                         ensure_ascii=False), file=sys.stderr)
        return 1
    brief = brief_for(stamp, state, rules, bank, args.topic or "", args.knowledge_point or "")
    state["pending"] = {"date": stamp, "topic": brief["topic"], "createdAt": datetime.now().isoformat(timespec="seconds")}
    save_state(state)
    emit({"ok": True, "brief": brief, "pending": state["pending"]}, args.json,
         f"{stamp} 第 {brief['issueNo']} 期：情境「{brief['topic']}」，年级 {brief['grade']}，"
         f"三阶 {brief['ladderSpec'][0]['requirement']} → {brief['ladderSpec'][2]['requirement']}")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.is_file():
        print(json.dumps({"error": f"文件不存在: {path}"}, ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        issue = load_json(path)
        result = validate_issue(issue, load_rules(RULES_PATH))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    emit(result, args.json,
         f"校验 {'通过' if result['ok'] else '未通过'}：{len(result['checks'])} 项，{len(result['errors'])} 个错误")
    if not args.json:
        for item in result["errors"]:
            print(f"  [ERROR] {item['name']}: {item['hint']}")
    return 0 if result["ok"] else 1


def cmd_render(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.is_file():
        print(json.dumps({"error": f"文件不存在: {path}"}, ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        issue = load_json(path)
        gate = validate_issue(issue, load_rules(RULES_PATH))
        if not gate["ok"] and not args.skip_validate:
            emit({"ok": False, "errors": gate["errors"]}, args.json,
                 "issue 校验未通过，先修好再渲染（不要加 --skip-validate 绕过）")
            return 1
        text = render_html(issue)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    out = Path(args.out) if args.out else Path.cwd() / f"{issue.get('date', 'issue')}-worksheet.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    emit({"ok": True, "out": str(out), "bytes": len(text.encode("utf-8")),
          "validated": gate["ok"]}, args.json, f"讲义已生成：{out}")
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    path = Path(args.file)
    if not path.is_file():
        print(json.dumps({"error": f"文件不存在: {path}"}, ensure_ascii=False), file=sys.stderr)
        return 2
    text = path.read_text(encoding="utf-8")
    result = check_html(text)
    emit(result, args.json,
         f"成品红线 {'通过' if result['ok'] else '未通过'}：{result['summary']['checks']} 项")
    if not args.json:
        for item in result["errors"]:
            print(f"  [ERROR] {item['name']}: {item['hint']}")
    return 0 if result["ok"] else 1


def cmd_write(args: argparse.Namespace) -> int:
    issue_path = Path(args.file)
    html_path = Path(args.html) if args.html else None
    if not issue_path.is_file() or (html_path and not html_path.is_file()):
        print(json.dumps({"error": "issue 或 HTML 成品文件不存在"}, ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        issue = load_json(issue_path)
        stamp = str(issue.get("date", ""))
        parse_date(stamp)
        gate = validate_issue(issue, load_rules(RULES_PATH))
        if not gate["ok"]:
            emit({"ok": False, "errors": gate["errors"]}, args.json, "issue 未通过校验，拒绝归档")
            return 1
        if html_path:
            page = html_path.read_text(encoding="utf-8")
            redline = check_html(page)
            if not redline["ok"]:
                emit({"ok": False, "errors": redline["errors"]}, args.json, "HTML 成品红线未通过，拒绝归档")
                return 1
        state = read_state()
        history = [h for h in state.get("history", []) if isinstance(h, dict)]
        record = {
            "date": stamp,
            "topic": (issue.get("news", {}) or {}).get("situation", ""),
            "knowledgePoint": issue.get("knowledgePoint", ""),
            "newsSourceType": (issue.get("news", {}) or {}).get("sourceType", ""),
            "title": issue.get("title", ""),
            "answers": [lv.get("answer") for lv in issue.get("levels", [])],
            "archivedAt": datetime.now().isoformat(timespec="seconds"),
        }
        # 幂等：同日重跑只覆盖自身，不重复计数、不把自身判为跨期重复
        existing = next((i for i, h in enumerate(history) if h.get("date") == stamp), None)
        if existing is None:
            history.append(record)
        else:
            history[existing] = record
        history.sort(key=lambda h: h.get("date", ""))
        state["history"] = history
        if state.get("pending", {}) and (state.get("pending") or {}).get("date") == stamp:
            state["pending"] = None
        save_state(state)
        archived = ""
        if html_path:
            ISSUES_DIR.mkdir(parents=True, exist_ok=True)
            target = ISSUES_DIR / f"{stamp}.html"
            target.write_bytes(html_path.read_bytes())
            archived = str(target)
        # 跨期重复只提醒，不阻断（next 阶段已经给出 avoidKnowledgePoints）
        recent = [h.get("knowledgePoint", "") for h in history[:-1][-3:]]
        duplicate = record["knowledgePoint"] in recent
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    emit({"ok": True, "date": stamp, "total": len(history), "archived": archived,
          "duplicateWarning": duplicate, "idempotent": True}, args.json,
         f"第 {len(history)} 期已归档：{stamp}（同日重跑不会重复计数）")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    try:
        state = read_state()
        rules = load_rules(RULES_PATH)
        bank = load_json(BANK_PATH)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    history = state.get("history", [])
    tomorrow = date.today() + timedelta(days=1)
    next_topic = pick_topic(tomorrow.isoformat(), bank)
    result = {
        "ok": True,
        "profile": state.get("profile", {}),
        "total": len(history),
        "pending": state.get("pending"),
        "recent": history[-5:],
        "recentKnowledgePoints": [h.get("knowledgePoint", "") for h in history[-3:]],
        "nextDate": tomorrow.isoformat(),
        "nextSuggestedTopic": next_topic.get("situation", ""),
        "nextSuggestedKnowledgePoints": next_topic.get("knowledgePoints", []),
        "statePath": str(STATE_PATH),
        "gradeRules": rules.get("grades", {}).get(state.get("profile", {}).get("grade", "G2"), {}),
    }
    emit(result, args.json,
         f"已出 {len(history)} 期；下一期 {tomorrow.isoformat()} 建议情境「{next_topic.get('situation', '')}」")
    return 0


def cmd_automation(args: argparse.Namespace) -> int:
    try:
        hh, mm = [int(x) for x in args.time.split(":")]
        if not (0 <= hh <= 23 and 0 <= mm <= 59):
            raise ValueError
    except ValueError:
        print(json.dumps({"error": "--time 需为 HH:MM（24 小时制）"}, ensure_ascii=False), file=sys.stderr)
        return 2
    contract = {
        "ok": True,
        "rrule": f"FREQ=DAILY;BYHOUR={hh};BYMINUTE={mm}",
        "timezone": "Asia/Shanghai",
        "idempotencyKey": "issue.date",
        "scope": "作业体 + 调度契约；本技能不创建宿主任务实例",
        "promptSteps": [
            "读取当前日期，运行 next --date <今天> --json 取出题规格 brief",
            "按 brief.newsKeywords 做 1-2 次联网检索，只取儿童向、无争议、含生活场景的新闻",
            "命中则记录媒体名、标题、日期与一句话事实；未命中改用离线情境库并写 offlineReason",
            "按 brief.ladderSpec 在同一情境下设计 L1/L2/L3，共用角色，只加条件",
            "为每阶画一张内联 SVG，图形数量与题面数字一致；独立验算三个答案",
            "写 issue JSON，运行 validate，失败按 checks[].hint 改写最多 2 次",
            "运行 render 生成单文件 HTML，再运行 check 校验打印红线",
            "运行 write 幂等归档；同日重跑覆盖自身，不重复计数",
            "交付 HTML 成品链接，并把新闻来源与三阶思维点各用一句话说明",
        ],
        "retryMatrix": {
            "newsSearch": "最多 2 次；仍无结果走离线兜底，不要编造新闻",
            "validate": "最多重写 2 次；不得改年级或放宽 maxNumber 蒙混",
            "render": "模板缺失时报错停止，不用手写 HTML 兜底",
        },
        "guardrails": {
            "oneIssuePerDay": True,
            "noHostTaskCreation": True,
            "noNetworkInScripts": True,
            "maxNumber": "由年级矩阵决定，默认 G2 为 100",
            "childFacing": "成品不出现年级标签、考试排名等评价字样",
            "privacy": "只存昵称/年级/期数与知识点，不存学校、住址、成绩",
        },
        "alertOn": ["validate 连续 2 次失败", "check 红线失败", "同日出现两份不同成品"],
    }
    emit(contract, args.json,
         f"每日 {args.time} 调度契约已生成（技能不会自行创建定时任务）")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="每日新闻奥数题流水线")
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("where", help="查看状态与归档目录")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_where)

    p = sub.add_parser("init", help="建立画像（默认 G2）")
    p.add_argument("--grade", default="G2")
    p.add_argument("--nickname", default="")
    p.add_argument("--avoid", default="")
    p.add_argument("--force", action="store_true", help="覆盖已有画像但保留历史")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("next", help="取今日出题规格")
    p.add_argument("--date", help="YYYY-MM-DD，默认今天")
    p.add_argument("--topic", default="", help="联网检索后确定的新闻情境")
    p.add_argument("--knowledge-point", default="", help="本期思维点")
    p.add_argument("--force", action="store_true", help="同日重取")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_next)

    p = sub.add_parser("validate", help="校验 issue JSON")
    p.add_argument("--file", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("render", help="渲染可打印 HTML 讲义")
    p.add_argument("--file", required=True)
    p.add_argument("--out", help="输出 HTML 路径")
    p.add_argument("--skip-validate", action="store_true", help="仅调试用，正式流程不要加")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_render)

    p = sub.add_parser("check", help="校验 HTML 成品红线")
    p.add_argument("--file", required=True)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("write", help="幂等归档本期")
    p.add_argument("--file", required=True, help="issue JSON")
    p.add_argument("--html", help="已通过 check 的 HTML 成品")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_write)

    p = sub.add_parser("status", help="查看进度")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("automation", help="输出每日调度契约")
    p.add_argument("--time", default="07:00")
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_automation)
    return ap


def main(argv: List[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
