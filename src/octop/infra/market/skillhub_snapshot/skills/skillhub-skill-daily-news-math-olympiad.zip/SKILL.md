---
name: skillhub-skill-daily-news-math-olympiad
description: "每天生成一道取材于当天真实新闻的奥数题讲义：默认二年级（可指定 G1–G6），同一情境下 L1 热身 → L2 进阶 → L3 挑战由浅入深，每阶配内联 SVG 图示、分步讲解、易错点对照与变式题，输出可直接 A4 打印的单文件 HTML。当用户说「今天的奥数题」「每天一个奥数题」「根据新闻出数学题」「给孩子出道思维题」「二年级数学」「图文并茂讲清楚」「由浅入深」，或 daily math olympiad for kids、news-based word problem 时使用。不适合成卷考试、作业批改、竞赛真题解析或系统启蒙规划。"
---

# 每日新闻奥数题 · 三阶递进图文讲义

## Overview

**输入只有两样：孩子年级（默认 G2）和当天的新闻；输出只有一样：一份能直接打印的
图文讲义**——同一情境下三道由浅入深的题，每阶配图、提示、分步讲解与变式题。

动手前必须内化三条原则：

1. **新闻只借情境，不借数字。** 题面来自当天可核验的儿童向新闻（媒体名 + 标题 +
   日期 + 一句话事实），但题目里的数字一律是练习设定，并在成品上明确声明。
   这样既有时事感，又不会把编造的统计数字当成事实，也不会超出低年级的数值范围。
2. **难度靠思维层数爬升，不靠把数字变大。** L1 一步加减 → L2 两步乘加 →
   L3 必须画图才想得清的重叠、倒推或枚举。年级矩阵（`assets/grade-rules.json`）
   规定数字上限与禁用知识点，`check_issue.py` 机器校验，不是建议值。
3. **三阶共用一个世界。** 同一间快递站、同一批角色，只逐阶加条件；
   答案数字不进题干；成品先过 `validate`，再过 HTML 红线 `check`，才允许归档。

### 差异化定位（检索 SkillHub 后的结论）

| 已有技能 | 它做什么 | 本技能补的缺口 |
|:---|:---|:---|
| `math-olympiad-solver`（TRACE 4.7） | 五六年级成卷，A4 PDF 解析卷 + 检测卷 | 低年级**每日一题**、真实新闻情境、三阶递进、零依赖单文件 HTML |
| `kunlun-primary-math`（4.3） | 画图/设元/转化讲经典奥数题型 | 每天自动出题 + 新闻事实核验 + 可打印成品与机器校验 |
| `math-exam`（4.4） | 记住年级与学期按知识点出题 | 同一情境三阶递进、图文讲义、带完整可运行样例 |
| `math`（4.0） | 孩子模式 / 家长模式、分层提示 | 可执行脚本、53 项结构校验、成品红线、幂等归档 |
| `maths-explainer-video`（4.5） | 逐步讲解动画视频 | 静态可打印讲义，不需要视频工程与字体资源 |
| `kids-daily-english-lab`（自家 4.9） | 每日英文短文 + 分数自适应 | 数学侧的日更节奏与「由浅入深」阶梯 |

平台对同类技能的评价反复出现同一句：**文档偏设计说明，缺少可直接体验的功能演示**。
因此本包把重点放在可运行性上：`assets/sample-issue.json` 是一道完整的真实样例，
`scripts/` 下两个零依赖脚本可直接跑通出题 → 校验 → 渲染 → 归档全链路。

本技能不是上述任何一个的替代品：要解析试卷、批改作业、排启蒙课表，请改用对应技能。

### 反模式（出现即返工）

| 反模式 | 后果 |
|:---|:---|
| 把新闻里的大数字搬进低年级题目 | 超出年级数值上限，且把练习数字伪装成统计事实 |
| 三阶各换一个场景 | 递进断裂，孩子每阶都要重新读题 |
| 用「设 x」讲二年级的排队题 | 方程超纲；应画图圈出被数两次的那一箱 |
| 题干里写出答案数字 | 孩子不用算就知道结果 |
| 用一张装饰插画代替数量关系图 | 「图文并茂」变成「有图但没用」 |
| 检索不到新闻就编一条 | 事实不可核验，违反本技能的可信度基线 |
| 绕过 `validate` 或修改 `maxNumber` 让题通过 | 校验失去意义，成品可能超纲 |
| 在打印成品上写年级、考试、排名等字样 | 违背儿童向排版约定 |
| 技能自行创建定时任务 | 越权，容易造成重复出题 |

## 工作流

以下命令均在**本技能根目录**执行。状态与归档默认在
`~/.workbuddy/daily-news-math-olympiad/`，可用环境变量 `DAILY_MATH_HOME` 改位置，
`python3 scripts/daily_math.py where` 可查。脚本本身不联网，检索由宿主 Agent 完成。

### 第 0 步：判断意图，直接路由

| 用户的话 | 动作 |
|:---|:---|
| 「今天的奥数题」「来一道」「每天一个奥数题」 | 第 2 步 → 生成 |
| 「换成三年级 / 四年级」「给 6 岁孩子出题」 | `init --grade G3 --force` 后再走第 2 步 |
| 「学了多少期」「最近都出了什么」 | `status --json` |
| 「每天固定时间自动出」 | `automation --time 07:00 --json` 输出契约，**不自行创建任务** |
| 「记录存在哪」 | `where --json` |

首次使用不阻塞：未建档时脚本按默认 G2 直接工作，不必先问年级。
用户主动说了年级或年龄段，按 `references/grade-rubric.md` 的映射表换算后建档。

### 第 1 步（可选）：建档

```bash
python3 scripts/daily_math.py init --grade G2 --nickname 小恩 --avoid "恐怖,打斗" --json
```

只存昵称、年级与回避主题；不存全名、学校、住址、成绩。
`init` 默认拒绝覆盖已有画像，`--force` 才覆盖（历史保留）。

### 第 2 步：找今天的新闻（宿主 Agent 联网）

先跑一次 `next --json` 拿到 `brief.newsKeywords`，再做 **1–2 次**联网检索，
只取当天或近 3 天、儿童向、有生活场景、含具体事物的报道。
记录媒体名、标题、日期、一句话事实；检索不到或主题不合适时走离线情境库，
并按 `references/news-grounding.md` 写明 `offlineReason`。

判定规则：结果落在安全红线（时政争议、灾难伤亡、事故、暴力、消费诱导、
品牌点名等）内 → 一律不用；与近 3 期情境重复 → 换一条。
**新闻事实与练习数字必须分离**，成品上要写明「题目数字是练习设定」。

### 第 3 步：取今日出题规格

```bash
python3 scripts/daily_math.py next --topic "快递站分拣包裹" --knowledge-point "排队重叠计数" --json
python3 scripts/daily_math.py next --json          # 无合适新闻时用离线兜底情境
```

`brief` 中的 `gradeRules / ladderSpec / avoidKnowledgePoints / illustration /
childFacingBanned` 全部是硬约束。`next` 会登记 pending；
同一天重复运行会退出码 1 并提示先归档，确需重取才加 `--force`。

首次出题前读一次 `references/ladder-design.md`（三阶设计法与题型库）、
`references/issue-schema.md`（字段契约）、`references/illustration-rules.md`（SVG 规范）；
同一次会话内不要重复读。

### 第 4 步：写 issue JSON

按 `assets/sample-issue.json` 的结构写三阶：共用情境、stars 递增、
`newIdea` 互不相同、讲解步数不减少、每阶一张内联 SVG、答案独立验算、
易错点写「错误做法 / 正确做法 / 错因」、每阶一道变式题。

### 第 5 步：机器校验

```bash
python3 scripts/daily_math.py validate --file issue.json --json
```

- `ok: true` → 进入第 6 步。
- 有 `errors[]` → 按 `checks[].hint` 改写后重跑，**最多 2 次**；
  禁止改年级、改 `maxNumber` 或加 `--skip-validate` 蒙混过关。
- 校验覆盖：三阶结构、数值上限、禁用知识点、新闻新鲜度与来源字段、
  答案不泄露、图示安全、讲解五段式、儿童版面安全，共 50 余项。

### 第 6 步：渲染成品并过红线

```bash
python3 scripts/daily_math.py render --file issue.json --out ./今日奥数题.html --json
python3 scripts/daily_math.py check --file ./今日奥数题.html --json
```

成品是**单文件 HTML**：题面页 + 讲解页，A4 打印样式、答题留白、
提示与讲解用折叠区（打印时自动展开）、三张内联 SVG，零外链零脚本。
`check` 校验占位符、外链、脚本、打印展开、打印样式、年级字样等 11 项红线，
不通过就不要交付。

### 第 7 步：幂等归档

```bash
python3 scripts/daily_math.py write --file issue.json --html ./今日奥数题.html --json
```

`write` 会再验一次 issue 与 HTML；同日重跑覆盖自身，不重复计数、不把自身判为跨期重复。
归档副本写到 `issues/<date>.html`。

### 第 8 步：交付

只交付一份 HTML 成品，回复里用两句话说明：新闻来源（媒体名 + 日期）、
本期思维点与三阶分别走了哪一步。不附难度分析、不附备选题目、不附校验日志。
需要打印时用浏览器打开成品直接打印，讲解在第二页。

### 第 9 步（按需）：看进度

```bash
python3 scripts/daily_math.py status --json
```

返回累计期数、最近 5 期、近 3 期知识点、下一期建议情境。只给家长看。

### 每天自动运行

本技能交付「作业体 + 调度契约」，**不自行创建定时任务**。
运行 `automation --time 07:00 --json` 取 rrule、幂等键与九步自包含指令，
由用户或宿主显式配置。详见 `references/automation-setup.md`。

## 硬性约束

| 项 | 值 |
|:---|:---|
| 默认年级 | **G2（二年级）**；可指定 G1–G6，年龄只作参考映射 |
| 数值上限 | G2 = 100；题面与算式中的整数不得超过年级上限 |
| 阶梯 | **恰好 3 阶**，stars 1→2→3，共用情境，newIdea 互不相同 |
| 讲解 | 每阶 1–2 层提示、2–4 步分步讲解、易错点三段、1 道变式题 |
| 图示 | 每阶 1 张内联 SVG，图形数量与题面数字一致，无外链无脚本 |
| 新闻 | 日期与出题日相差 ≤ 3 天；联网取材需四个来源字段；离线需写原因 |
| 数字声明 | 联网取材必须声明「题目数字是练习设定」 |
| 成品 | 零外链单文件 HTML，A4 打印友好，题面与讲解分页，不出现年级字样 |
| 频率 | 一天一期；`next` 有 pending 保护，`write` 有同日覆盖保护 |
| 状态位置 | `~/.workbuddy/daily-news-math-olympiad/`，可用 `DAILY_MATH_HOME` 覆盖 |
| 隐私 | 只存昵称/年级/期数/知识点，不存成绩、答题正误、学校住址 |
| 运行环境 | Python 3 标准库，零第三方依赖；脚本不联网 |
| 退出码 | 0 成功 / 1 业务失败 / 2 参数或数据错误 |

## 资源清单

| 文件 | 什么时候读 |
|:---|:---|
| `references/grade-rubric.md` | 用户指定年龄段、判断某题是否超纲时 |
| `references/news-grounding.md` | 联网取材、事实核验、判断是否该降级时 |
| `references/ladder-design.md` | 首次出题前：三阶设计法、G2 题型库、验算规范 |
| `references/issue-schema.md` | 首次写 issue JSON 前：字段契约与最小示例 |
| `references/illustration-rules.md` | 画 SVG 前：四种图式与检查清单 |
| `references/automation-setup.md` | 配置每日调度时 |
| `assets/sample-issue.json` | 写第一份 issue 时照抄结构的完整真实样例 |
| `assets/worksheet-template.html` | 需要改排版时（渲染器自动读取） |
| `assets/grade-rules.json` | 脚本读取的年级矩阵；改规则后需同步文档 |
| `assets/topic-bank.json` | 脚本读取的 16 条离线情境库 |
| `assets/icon.svg` | 平台图标（发布后需在网页端补设） |

## 脚本索引

| 脚本 | 用途 |
|:---|:---|
| `scripts/daily_math.py` | 主 CLI：`where / init / next / validate / render / check / write / status / automation`，全部支持 `--json` |
| `scripts/check_issue.py` | 独立 issue 校验器，可单独调用；输出结构化 `checks[]` |

## 常见错误

| 现象 | 原因 | 处理 |
|:---|:---|:---|
| `next` 报「今天已经取过出题规格」 | 同日重复触发且 pending 未清 | 先完成 `write`；确需换题加 `--force` |
| `validate` 报 `number_range` | 题面出现超出年级上限的数字 | 换小题目的数据，不要放宽 maxNumber |
| `validate` 报 `forbidden_concepts` | 讲解里出现方程、分数、小数等超纲词 | 改成画图与整数算式讲 |
| `validate` 报 `no_answer_leak` | 题干里直接写了答案数字 | 从题干删掉，答案只留在讲解区 |
| `validate` 报 `news_freshness` | 报道日期离出题日超过 3 天 | 换近 3 天的报道，或走离线兜底 |
| `validate` 报 `svg_safe` | SVG 带了外链命名空间或远程图片 | 去掉 xmlns 与远程引用，属性统一用单引号 |
| `check` 报 `child_facing_clean` | 成品上出现年级或评价字样 | 年级只留在 issue 元数据，不注入 HTML |
| `check` 报 `no_external_link` | 新闻来源把链接写进了成品 | 来源改用媒体名 + 日期文字，链接另在对话里给 |
| 打印出来讲解没展开 | 用 `<details>` 承载讲解时，Chrome 打印会隐藏未展开内容（作者 CSS 覆盖不了 UA slot） | 模板改用纯 CSS 复选框折叠 + `@media print` 强制 `display: block`；`check` 的 `print_expansion` 会拦截回归 |
| 同日 `write` 后总期数还是 1 | 这是幂等保护，属预期行为 | 无需处理；换日期才会新增一期 |
| 联网检索只找到促销与负面新闻 | 主题不合规 | 走离线情境库并写 `offlineReason`，不要硬凑 |
| 用户要「难一点」 | 想加难度 | 在同一档位内换更难的思维点，不改年级 |
