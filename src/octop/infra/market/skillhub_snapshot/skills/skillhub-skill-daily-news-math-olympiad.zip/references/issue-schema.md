# issue JSON 字段契约

`validate`（或 `check_issue.py`）按本文件逐字段校验。字段缺失、类型不符、
数值越界都会给出 `checks[].hint`，按提示改写，**不要改年级或放宽规则绕过**。
完整可运行样例：`assets/sample-issue.json`。

## 顶层字段

| 字段 | 类型 | 必填 | 约束 |
|:---|:---|:---|:---|
| `date` | string | 是 | `YYYY-MM-DD`，与新闻日期相差 ≤ 3 天 |
| `grade` | string | 是 | `G1`–`G6`，默认 `G2`；决定 `maxNumber` 与禁用知识点 |
| `gradeLabel` | string | 否 | 仅供家长/Agent 查看，不注入成品 |
| `issueNo` | int | 否 | 期数，默认由 `next` 给出 |
| `title` | string | 是 | 不超过 16 字，不含年级字样 |
| `knowledgePoint` | string | 是 | 本期主思维点，不得与近 3 期重复 |
| `news` | object | 是 | 见下表 |
| `levels` | array | 是 | **恰好 3 个**，顺序 L1 / L2 / L3 |
| `parentNote` | string | 是 | 给家长的一句话引导话术 |
| `cheer` | string | 是 | 一句鼓励，不评价分数与对错 |

## `news` 对象

| 字段 | online | offline | 说明 |
|:---|:---|:---|:---|
| `sourceType` | `online` | `offline` | 必填 |
| `sourceName` | 必填 | 留空 | 媒体名，不写链接 |
| `sourceHeadline` | 必填 | 建议填场景名 | 报道标题 |
| `sourceDate` | 必填 | 留空 | 报道日期 |
| `fact` | 必填 | 可留空 | 一句话事实，不超过 40 字 |
| `situation` | 必填 | 必填 | 三阶共用的情境 |
| `disclaimer` | 必填 | 建议填 | 必须含「练习设定」或「不是新闻」 |
| `offlineReason` | 留空 | 必填 | 写明为何没用新闻 |

## `levels[]` 对象

| 字段 | 类型 | 约束 |
|:---|:---|:---|
| `id` | string | 依次 `L1` / `L2` / `L3` |
| `label` | string | 热身 / 进阶 / 挑战 |
| `stars` | int | 1 / 2 / 3，严格递增 |
| `title` | string | 不超过 8 字 |
| `newIdea` | string | 本阶新增的思维点，三阶互不相同 |
| `question` | string | 1–2 句；不得出现答案数字；数字 ≤ `maxNumber` |
| `svg` | string | 内联 SVG 片段，含可见图形，无脚本与外链 |
| `answer` | int | 1..`maxNumber` 的整数 |
| `answerUnit` | string | 个 / 箱 / 支 等 |
| `hints` | string[] | 1..`maxHints` 层（G2 为 2），先方向后算式 |
| `steps` | string[] | 2..`maxSteps` 步（G2 为 4），步数不逐阶减少 |
| `mistake` | object | `wrong` / `right` / `why` 三段，前两段不得相同 |
| `transfer` | string | 1 道变式题，不附答案 |

## 最小结构示例

```json
{
  "date": "2026-11-12",
  "grade": "G2",
  "title": "快递站里的小数学",
  "knowledgePoint": "排队重叠计数",
  "news": {
    "sourceType": "online",
    "sourceName": "某日报",
    "sourceHeadline": "快递站迎来派送高峰",
    "sourceDate": "2026-11-11",
    "fact": "报道说这几天末端网点最忙，夜里也要分拣包裹。",
    "situation": "快递站分拣包裹",
    "disclaimer": "题目里的数字是练习设定，不是新闻统计数字。",
    "offlineReason": ""
  },
  "levels": [
    { "id": "L1", "label": "热身", "stars": 1, "title": "数包裹", "newIdea": "把两部分合起来",
      "question": "上午 8 个，下午 6 个，一共几个？", "svg": "<svg ...></svg>",
      "answer": 14, "answerUnit": "个", "hints": ["用加法"], "steps": ["合起来", "8 + 6 = 14"],
      "mistake": {"wrong": "8 - 6 = 2", "right": "8 + 6 = 14", "why": "问一共要合起来"},
      "transfer": "下午换成 9 个呢？" }
  ],
  "parentNote": "先画图再列式。",
  "cheer": "会画图的孩子，最会解题！"
}
```

上面只写了 L1 用于说明结构——真实 issue 必须写满三阶。
`svg` 的写法见 `references/illustration-rules.md`。

## 校验结果怎么读

```bash
python3 scripts/daily_math.py validate --file issue.json --json
```

- `ok: true` → 可以 `render`。
- `errors[]` → 每条含 `name`、`hint`、`detail`；按 `hint` 改内容后重跑，最多 2 次。
- `warnings[]` → 只影响可读性（如 SVG 缺 `aria-label`），建议一并修掉。

`render` 内部会再跑一次 `validate`；`write` 会同时验 issue 与 HTML 红线，
任何一道不过都拒绝归档。
