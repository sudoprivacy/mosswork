# 四六级翻译：中国文化与社会类

四六级翻译多为**中国文化、社会发展、经济、科技**类段落，核心是"意思翻对 + 句子不出错"，不追求辞藻华丽。

## 一、高频主题词块（必背）

| 中文 | 英文 |
| --- | --- |
| 春节 / 中秋节 | the Spring Festival / the Mid-Autumn Festival |
| 农历 | the lunar calendar |
| 传统节日 | traditional festivals |
| 京剧 | Peking Opera |
| 剪纸 / 书法 / 水墨画 | paper-cutting / calligraphy / ink painting |
| 四大发明 | the four great inventions |
| 丝绸之路 | the Silk Road |
| 儒家思想 / 孔子 | Confucianism / Confucius |
| 故宫 / 长城 | the Forbidden City / the Great Wall |
| 改革开放 | reform and opening-up |
| 小康社会 | a moderately prosperous society |
| 人工智能 / 电子商务 | artificial intelligence / e-commerce |
| 高铁 / 共享单车 | high-speed rail / shared bikes |
| 支付宝 / 移动支付 | Alipay / mobile payment |
| 一带一路 | the Belt and Road Initiative |
| 人口普查 | a national census |
| 人口老龄化 | an aging population |
| 碳中和 | carbon neutrality |
| 乡村振兴 | rural revitalization |

## 二、常用句型

- 位于 / 坐落在：**is located in** the north of China.
- 被誉为：**is known as / is honored as** the "______".
- 由…组成：**consists of / is made up of** ...
- 旨在：**is aimed at / is designed to** ...
- 随着…：**With the development of** ______, ...
- 不仅…而且：**not only ... but also** ...
- 据估计：**It is estimated that** ...
- 越来越：**An increasing number of** people ...

## 三、翻译步骤

1. **断句**：中文多流水句，按意群切成 2–4 个英文句，别硬翻成一长句。
2. **补主谓**：中文常省主语，英文每句必须有主语（补 we / it / this / the country）。
3. **定时态**：现状描述用一般现在；讲历史用一般过去；"近年来"用现在完成。
4. **处理无主句/被字句**：用被动（*is built / was considered*）或补 it。
5. **复查**：主谓一致、时态、冠词、拼写。

## 四、典型错例

- 误：*With the develop of economy* → 正：**With the development of the economy**
- 误：*The Great Wall build 2000 years ago* → 正：**was built** over 2,000 years ago
- 误：*Chinese people very like tea* → 正：**Chinese people are very fond of tea** / like tea very much
- 误：*In recent years, China's economy develop fast* → 正：**has developed** rapidly

## 五、练习闭环

给一段中文 → 学生译 → 对照参考译文 → 标红差异（结构/用词）→ 重译一遍。重译比多看三遍更有效。
