# 四六级写作模板与常见错误

## 一、四类常考题型与框架

### 1. 现象解释型（某现象为何出现）
- 首段：Nowadays, ______ has become a hot topic. / It is widely observed that ______.
- 中间：Several factors account for this. To begin with, ______. Furthermore, ______.
- 尾段：From my perspective, ______. / Only by ______ can we ______.

### 2. 观点对比型（A 与 B 孰优）
- 首段：When it comes to ______, opinions vary.
- 中间：Some hold that ______. However, others argue that ______.
- 尾段：As for me, I side with ______ because ______.

### 3. 问题解决型（如何做）
- 首段：______ has brought us both benefits and problems.
- 中间：Measures should be taken. First, ______. Second, ______.
- 尾段：With joint efforts, ______ will be improved.

### 4. 图表/数据型（六级较常见）
- 首段：As is shown in the chart, ______ increased from __ to __.
- 中间：The change reflects ______. / Two reasons lie in ______.
- 尾段：In conclusion, the trend suggests ______.

## 二、万能开头/结尾句（背熟可直接套）

开头：
- It is universally acknowledged that ______.
- With the development of society, ______ has attracted growing attention.

结尾：
- Only when we ______ can we truly ______.
- To sum up, it is high time that we ______.

## 三、高频加分替换（避免小学词汇）

| 普通 | 升级 |
| --- | --- |
| important | crucial / vital / significant |
| many | a wealth of / numerous |
| think | hold / argue / maintain |
| good | beneficial / positive |
| bad | adverse / harmful |
| should | be supposed to / it is advisable to |
| use | employ / utilize |
| help | contribute to / facilitate |

## 四、最常扣分错误（批改时重点查）

1. 主谓不一致：The number of students **is**...（不是 are）
2. 时态混乱：全文统一一般现在/过去，叙述现状用现在。
3. 中式英语：把"随着...的发展"直译成 *With the develop of* → 应为 **With the development of**。
4. 冠词缺失：play **a** role, **an** important part。
5. 连词堆砌：一段里 however / moreover / therefore 全用上，显得刻意，每 2–3 句一个即可。
6. 拼写：definitely 非 definately；separate 非 seperate；necessary 双 n 双 s。
7. 无连接：句句独立，缺 therefore / however / for example 等衔接。

## 五、批改流程（用于作文互改/AI 批改）

1. 通读判结构：是否三段、每段是否单一中心。
2. 逐句查语法：主谓、时态、冠词、单复数。
3. 标中式表达与可升级词汇（给替换建议）。
4. 算字数（四级≥120，六级≥150），不足补例子，超了删废话。
5. 给总分档（按内容/结构/语言各 1/3 权重）与 3 条最该改的点。
