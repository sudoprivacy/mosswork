#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四六级备考计划生成器 (study_plan.py)
根据考试日期、目标级别、每周可用时长，生成一份分阶段（基础->强化->冲刺）周计划，
输出 Markdown。也可结合一次自测分数给出侧重点建议。

用法:
  python study_plan.py --exam-date 2026-12-12 --level 6 --hours 10
  python study_plan.py --exam-date 2026-12-12 --level 4 --hours 8 --score 420

参数:
  --exam-date  YYYY-MM-DD  考试日期（必填）
  --level      4|6         目标级别
  --hours      N           每周可投入小时数（默认 8）
  --score      N           最近一次模拟/真实成绩（可选，用于诊断弱项）
  --start      YYYY-MM-DD  计划起始日（默认今天）
"""
import argparse
import datetime as dt
import sys

MODULES = ["词汇", "听力", "阅读", "写作", "翻译"]


def weeks_between(start, exam):
    d = (exam - start).days
    return max(1, d // 7)


def diagnose(score, level):
    if score is None:
        return None
    # 四六级满分 710，及格线常按 425 计
    if score >= 550:
        return "基础扎实，主攻听力/阅读提速与写作翻译高分表达。"
    if score >= 425:
        return "已过线边缘，重点补弱项（听力抓关键词、阅读定位、写作模板化）。"
    return "尚未达标，先集中突破词汇+听力基础，再练阅读与写译。"


def build_plan(level, weeks, hours, diagnosis):
    # 各阶段占比
    if weeks <= 4:
        phases = [("冲刺(全真模拟)", weeks)]
    elif weeks <= 8:
        phases = [("强化(分项突破)", weeks // 2), ("冲刺(全真模拟)", weeks - weeks // 2)]
    else:
        base = max(2, weeks // 3)
        sprint = max(2, weeks // 4)
        mid = weeks - base - sprint
        phases = [("基础(词汇+语法)", base), ("强化(分项突破)", mid), ("冲刺(全真模拟)", sprint)]

    lines = []
    lines.append(f"# 四六级（CET-{level}）{weeks} 周备考计划")
    lines.append("")
    lines.append(f"- **每周投入**：约 {hours} 小时")
    lines.append(f"- **阶段划分**：" + " → ".join(f"{n}{w}周" for n, w in phases))
    if diagnosis:
        lines.append(f"- **诊断建议**：{diagnosis}")
    lines.append("")
    lines.append("## 每周节奏建议")
    lines.append("")
    lines.append("| 星期 | 模块 | 建议时长 | 任务示例 |")
    lines.append("| --- | --- | --- | --- |")
    per_day = max(1, round(hours / 6))
    schedule = [
        ("词汇", "背+复习核心词，配合 vocab_drill.py 自测"),
        ("听力", "精听 1 篇真题，影子跟读"),
        ("阅读", "限时做 1 套仔细阅读+长篇匹配"),
        ("写作", "背 1 个模板，仿写 1 段"),
        ("翻译", "练 1 段汉译英，对照参考表达"),
        ("模考/复盘", "整套限时或错题复盘"),
    ]
    for d, (m, task) in enumerate(schedule, 1):
        lines.append(f"| 周{d%7 or 7} | {m} | {per_day}h | {task} |")
    lines.append("")
    wk = 1
    for name, w in phases:
        lines.append(f"## 阶段：{name}（第 {wk}–{wk+w-1} 周）")
        lines.append("")
        if name.startswith("基础"):
            lines.append("- 用 `scripts/vocab_drill.py --level %s` 过完核心词 2 遍" % level)
            lines.append("- 每天 30 分钟精听：听写关键词，熟悉语音语调")
            lines.append("- 复习基础语法：时态、从句、非谓语、虚拟语气")
        elif name.startswith("强化"):
            lines.append("- 分项限时训练，记录正确率")
            lines.append("- 听力：抓首尾句、信号词（but/however/in fact）")
            lines.append("- 阅读：先看题再定位，长难句拆分主干")
            lines.append("- 写作：按现象/对比/解决/图表四类模板仿写")
            lines.append("- 翻译：中国文化/社会类高频词与句型积累")
        else:
            lines.append("- 每周 1 套全真模考（严格计时）")
            lines.append("- 错题归类，回归对应分项补漏")
            lines.append("- 作文背诵 3 套万能框架，翻译背 20 个文化词块")
        lines.append("")
        wk += w
    lines.append("> 计划为通用模板，可按自测弱项动态增减各模块比重。")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="四六级备考计划生成器")
    ap.add_argument("--exam-date", required=True)
    ap.add_argument("--level", choices=["4", "6"], default="6")
    ap.add_argument("--hours", type=int, default=8)
    ap.add_argument("--score", type=int, default=None)
    ap.add_argument("--start", default=None)
    args = ap.parse_args()

    try:
        exam = dt.datetime.strptime(args.exam_date, "%Y-%m-%d").date()
        start = dt.datetime.strptime(args.start, "%Y-%m-%d").date() if args.start else dt.date.today()
    except ValueError as e:
        print("日期格式错误，应为 YYYY-MM-DD:", e)
        sys.exit(1)

    weeks = weeks_between(start, exam)
    diag = diagnose(args.score, args.level)
    print(build_plan(args.level, weeks, args.hours, diag))


if __name__ == "__main__":
    main()
