#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四六级资源检索助手 (find_resources.py)
给定主题，输出可信候选站点 URL 与推荐搜索词，供 WorkBuddy 用 WebFetch/WebSearch 拉取真实资料。
本脚本不联网，只做"去哪找 / 搜什么"的确定性映射，避免凭空编造链接。

用法:
  python find_resources.py --topic 真题 --level 6
  python find_resources.py --topic 听力
  python find_resources.py --topic 词汇
  python find_resources.py --topic 写作
  python find_resources.py --topic 翻译
  python find_resources.py --topic 大纲

topic 取值: 真题 | 听力 | 阅读 | 词汇 | 写作 | 翻译 | 大纲 | 经验
"""
import argparse
import datetime as dt

# 候选站点（来自 references/resources.md，均为公开可检索站点）
SITES = {
    "official": [
        ("全国四六级考试官网", "https://cet.neea.edu.cn"),
        ("中国教育考试网", "https://neea.edu.cn"),
    ],
    "practice": [
        ("可可英语(真题听力)", "https://www.kekenet.com"),
        ("沪江英语", "https://www.hjenglish.com"),
        ("新东方在线", "https://www.koolearn.com"),
        ("星火英语", "https://www.sparkenglish.com"),
    ],
    "community": [
        ("知乎(经验帖)", "https://www.zhihu.com"),
        ("B站(技巧视频)", "https://www.bilibili.com"),
    ],
    "dict": [
        ("有道词典", "https://www.youdao.com"),
        ("百词斩", "https://www.baicizhan.com"),
    ],
}

# 主题 -> 用哪些站点分组 + 推荐搜索词模板
TOPICS = {
    "真题": {
        "groups": ["official", "practice", "community"],
        "query": "{year} 年 {month} 月 大学英语{lv}级 真题 及 答案",
    },
    "听力": {
        "groups": ["practice", "community"],
        "query": "大学英语{lv}级 听力 真题 原文 精听",
    },
    "阅读": {
        "groups": ["practice", "community"],
        "query": "大学英语{lv}级 阅读 仔细阅读 长篇匹配 技巧",
    },
    "词汇": {
        "groups": ["dict", "practice"],
        "query": "大学英语{lv}级 核心 高频 词汇 列表",
    },
    "写作": {
        "groups": ["practice", "community"],
        "query": "大学英语{lv}级 作文 模板 现象 对比 解决 图表",
    },
    "翻译": {
        "groups": ["practice", "community"],
        "query": "大学英语{lv}级 翻译 中国文化 社会 模板 词块",
    },
    "大纲": {
        "groups": ["official"],
        "query": "全国大学英语{lv}级 考试 大纲",
    },
    "经验": {
        "groups": ["community"],
        "query": "大学英语{lv}级 备考 经验 计划 高分",
    },
}


def resolve_query(template, level):
    lv = "四" if level == "4" else "六"
    year = dt.date.today().year
    month = "6" if dt.date.today().month > 6 else "12"
    return template.format(lv=lv, year=year, month=month)


def main():
    ap = argparse.ArgumentParser(description="四六级资源检索助手")
    ap.add_argument("--topic", required=True, choices=list(TOPICS.keys()))
    ap.add_argument("--level", choices=["4", "6"], default="6")
    args = ap.parse_args()

    spec = TOPICS[args.topic]
    print(f"# 主题：{args.topic}（CET-{args.level}）\n")
    print("## 推荐搜索词")
    print(f"  {resolve_query(spec['query'], args.level)}\n")
    print("## 候选站点（按可信度排序）")
    for g in spec["groups"]:
        for name, url in SITES[g]:
            print(f"  - [{name}]({url})")
    print("\n下一步：用 WebFetch 打开具体页面抽取正文，或用上面的搜索词跑 WebSearch。")


if __name__ == "__main__":
    main()
