#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四六级听力挖空听写训练 (listening_practice.py)
真正练耳朵：把原文里"口语中常弱读/连读/失爆"的功能词挖空，让你听/读后还原，
直接对应"单词认识但听不出来"的痛点。不依赖音频，专练抓弱读词。
原文段落见 references/listening_transcripts.json（原创 CET 风格；真实真题走 references/resources.md 检索）。

用法:
  python listening_practice.py --mode dictation --level 6        # 六级段落挖空听写
  python listening_practice.py --mode dictation --level 4        # 四级段落挖空听写
  python listening_practice.py --mode mark --level 6             # 标出原文里会被弱读的词（教练讲解用）
  python listening_practice.py --mode vocab --scene campus       # 复习听力场景高频词

说明:
  dictation 模式：功能词（a/an/the/and/but/of/to/in/we/you/is/can/should...）被挖空，
  你按出现顺序填回。这些词在真实语流中最易被连读弱读吞掉，是听力丢分重灾区。
"""
import argparse
import json
import os
import random
import re

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TRANSCRIPTS = os.path.join(SKILL_DIR, "references", "listening_transcripts.json")
VOCAB = os.path.join(SKILL_DIR, "references", "listening_vocab.json")

# 口语中最易被弱读/连读吞掉的功能词（挖空对象）
FUNCTION_WORDS = {
    "a", "an", "the", "and", "or", "but", "so", "because", "if", "when",
    "that", "which", "who", "of", "to", "in", "on", "at", "by", "for",
    "with", "from", "about", "as", "i", "you", "he", "she", "it", "we",
    "they", "me", "him", "her", "us", "them", "my", "your", "his", "their",
    "is", "are", "was", "were", "am", "be", "been", "do", "does", "did",
    "can", "could", "should", "would", "will", "may", "might", "must",
    "has", "have", "had", "not", "no", "this", "these", "those",
}


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def words_of(text):
    return re.findall(r"[A-Za-z']+", text)


def mode_dictation(passages, level):
    items = [p for p in passages if p["level"] == level] or passages
    random.shuffle(items)
    t = items[0]
    toks = words_of(t["text"])
    blanks = [w for w in toks if w.lower() in FUNCTION_WORDS]
    display = " ".join("___" if w.lower() in FUNCTION_WORDS else w for w in toks)
    print(f"\n【{t['level']}级 / {t['type']}】挖空听写：把 ___ 处填回（按顺序，空格分隔）\n")
    print(display + "\n")
    ans = input("你的填空：").strip().split()
    ans_norm = [a.strip().lower() for a in ans]
    blank_norm = [b.lower() for b in blanks]
    right = sum(1 for a, b in zip(ans_norm, blank_norm) if a == b)
    print("\n" + "=" * 40)
    if ans_norm == blank_norm:
        print(f"✅ 全对！{right}/{len(blank_norm)} 个弱读词都抓到了，耳朵过关。")
    else:
        print(f"✅ 抓对 {right}/{len(blank_norm)} 个。漏/错的有：")
        for i, b in enumerate(blank_norm):
            got = ans_norm[i] if i < len(ans_norm) else "(空)"
            mark = "✓" if got == b else f"✗ 你填「{got}」应为「{b}」"
            print(f"  {i+1}. {b}  {mark}")
    print("\n原文：")
    print(t["text"])
    print("\n教练提示：错的多是 a/the/of/to/and/we/you/is/can 这类——它们口语里弱读成 /ə/、/tə/、/ən/，"
          "不弱读就听不出。下一遍听时专盯这些'小词'。")


def mode_mark(passages, level):
    items = [p for p in passages if p["level"] == level] or passages
    t = items[0]
    print(f"\n【{t['level']}级 / {t['type']}】会被弱读/连读吞掉的词已加【】：\n")
    out = " ".join(f"【{w}】" if w.lower() in FUNCTION_WORDS else w for w in words_of(t["text"]))
    print(out)
    print("\n这些词在真实语流中最易被连读弱读，是'听不懂'的主因。先能看着抓出它们，再盲听。")


def mode_vocab(scene):
    data = load(VOCAB)
    groups = data if scene == "all" else {scene: data.get(scene, [])}
    total = right = 0
    for g, ws in groups.items():
        print(f"\n### 场景：{g} ({len(ws)} 词)")
        for w in ws:
            a = input(f"  {w['w']} {w['p']} → 释义：").strip()
            ok = a and a in w["c"]
            print(f"     {'✅' if ok else '❌'} {w['c']}\n")
            total += 1
            right += ok
    print(f"\n场景词正确 {right}/{total}")


def main():
    ap = argparse.ArgumentParser(description="四六级听力挖空听写训练")
    ap.add_argument("--mode", choices=["dictation", "mark", "vocab"], required=True)
    ap.add_argument("--level", choices=["4", "6"], default="6")
    ap.add_argument("--scene", default="all", help="vocab 模式场景: campus/life/academic/attitude/all")
    args = ap.parse_args()

    if args.mode == "vocab":
        mode_vocab(args.scene)
        return
    passages = load(TRANSCRIPTS).get("passages", [])
    if not passages:
        print("无段落数据")
        return
    {"dictation": mode_dictation, "mark": mode_mark}[args.mode](passages, args.level)


if __name__ == "__main__":
    main()
