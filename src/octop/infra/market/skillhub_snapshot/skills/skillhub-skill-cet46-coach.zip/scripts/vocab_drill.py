#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
四六级词汇闯关 (vocab_drill.py)
读取 references/vocab_bank.json，进行交互式词汇自测，自动记录错题并导出复习清单。

用法:
  # 四级，英文->中文，随机 20 词
  python vocab_drill.py --level 4 --mode en2cn --count 20

  # 六级，中文->英文，不限量
  python vocab_drill.py --level 6 --mode cn2en

  # 只复习上次错题
  python vocab_drill.py --level 4 --review

说明:
  --mode en2cn : 给出英文单词，默中文释义
  --mode cn2en : 给出中文释义，默英文单词
  --review     : 读取上次导出的错题清单复习（文件: <level>_wrong.json）
  --out DIR    : 指定错题清单输出目录（默认脚本同目录）
"""
import argparse
import json
import os
import random
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BANK_PATH = os.path.join(SKILL_DIR, "references", "vocab_bank.json")


def load_bank(level):
    with open(BANK_PATH, encoding="utf-8") as f:
        data = json.load(f)
    key = "cet4" if str(level) == "4" else "cet6"
    return data.get(key, [])


def normalize(s):
    return "".join(s.strip().lower().split())


def drill(items, mode, count, out_dir, level):
    if count:
        items = random.sample(items, min(count, len(items)))
    wrong = []
    total = len(items)
    print(f"\n开始自测：共 {total} 词，模式={'英->中' if mode=='en2cn' else '中->英'}\n")
    for i, it in enumerate(items, 1):
        if mode == "en2cn":
            prompt = f"[{i}/{total}] {it['w']}  {it['p']}"
            answer = normalize(it["c"])
            hint = it.get("e", "")
            q = f"{prompt}\n  释义："
        else:
            prompt = f"[{i}/{total}] {it['p']} {it['c']}"
            answer = normalize(it["w"])
            hint = it.get("e", "")
            q = f"{prompt}\n  单词："
        user = normalize(input(q))
        if user == answer:
            print("  ✅ 正确\n")
        else:
            print(f"  ❌ 错误  正确答案：{it['w']} {it['p']} {it['c']}")
            if hint:
                print(f"     例句：{hint}")
            print()
            wrong.append(it)
    # 汇总
    right = total - len(wrong)
    print("=" * 40)
    print(f"完成！正确 {right}/{total}（{100*right//total if total else 0}%），错 {len(wrong)} 词")
    if wrong:
        out_path = os.path.join(out_dir, f"{level}_wrong.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(wrong, f, ensure_ascii=False, indent=2)
        print(f"错题已导出：{out_path}（下次加 --review 复习）")
    else:
        print("全部正确，太强了！")


def review_mode(level, out_dir):
    path = os.path.join(out_dir, f"{level}_wrong.json")
    if not os.path.exists(path):
        print(f"没有找到错题清单：{path}（先跑一次正常自测）")
        return
    with open(path, encoding="utf-8") as f:
        items = json.load(f)
    print(f"复习模式：载入 {len(items)} 个错题\n")
    drill(items, "en2cn", None, out_dir, level)


def main():
    ap = argparse.ArgumentParser(description="四六级词汇闯关")
    ap.add_argument("--level", choices=["4", "6"], default="4")
    ap.add_argument("--mode", choices=["en2cn", "cn2en"], default="en2cn")
    ap.add_argument("--count", type=int, default=None, help="本次自测词数（默认全部）")
    ap.add_argument("--review", action="store_true", help="只复习上次错题")
    ap.add_argument("--out", default=SKILL_DIR, help="错题清单输出目录")
    args = ap.parse_args()

    if args.review:
        review_mode(args.level, args.out)
        return
    items = load_bank(args.level)
    if not items:
        print(f"词库为空或 level={args.level} 不存在")
        sys.exit(1)
    drill(items, args.mode, args.count, args.out, args.level)


if __name__ == "__main__":
    main()
