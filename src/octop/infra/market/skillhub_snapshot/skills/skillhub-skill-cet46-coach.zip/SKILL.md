---
name: skillhub-skill-cet46-coach
description: "中国大学英语四六级（CET-4 / CET-6）备考教练，以听力为主攻方向。当用户备考四六级、练听力/听不懂/精听、练习词汇/阅读/写作/翻译、要求批改作文或汉译英、制定备考计划、刷真题、背核心词、找真题或资料网站、检索备考资源，或说出四六级、过级、刷题、听力技巧、精听、连读弱读、选项预判、同义替换、作文模板、汉译英、资源网站等表述时，使用本技能。提供听力硬技能训练（选项预判/同义替换/干扰项）、场景词、语音规律、诊断与计划、分项模板，以及联网检索真实资料的能力（不内置题库）。"
---

# 四六级教练 (CET-4 / CET-6 Coach)

## 概述

把 WorkBuddy 变成一个能诊断弱项、主攻听力、分项教学、批改作文、按日程出计划、并联网检索真实资料的四六级备考教练。
**本技能以听力为第一主攻方向**：听力占 35% 且最易提分，核心交付是"听不懂→抓不住→选不对"三层破解——语音规律、场景高频词、选项预判、同义替换、干扰项识别、精听五步法。
其余交付：词汇闯关（脚本）、写作模板与批改、汉译英训练、阅读策略、个性化备考计划（脚本）、按需检索真题与资料（WebSearch/WebFetch + 精选站点）。
本技能**不内置题库**，真实材料按需联网获取。所有讲解默认中文，英文例句与术语保留原文。

## 何时使用

- 用户说"帮我备考四六级 / 过级 / 刷分 / 制定复习计划"
- 用户要求：练听力、听不懂怎么办、精听、讲听力技巧、背单词、讲阅读技巧、改作文、练翻译、出模考
- 用户提到：新闻听力、长对话、听力篇章、讲座听力、连读弱读、选项预判、同义替换、选词填空、仔细阅读、汉译英、图表作文
- 用户提供一段作文/译文要求批改评分
- 用户要求"找真题/资料网站/帮我搜四六级资源"

## 核心能力

### 1. 听力主攻（本技能核心）
- 完整方法见 `references/listening.md`：试卷结构、三层痛点（听不懂/抓不住/选不对）、语音规律（连读/弱读/失爆/语调）、精听五步法、按弱项分训练重点。
- **挖空听写（真正练耳朵）**：用 `scripts/listening_practice.py`，把原文里口语常弱读/连读吞掉的功能词（a/the/of/to/and/we/you/is/can/should…）挖空，让学员听/读后还原——直接对应"单词认识但听不出"的痛点：
  - `python scripts/listening_practice.py --mode dictation --level 6`  （六级段落挖空）
  - `python scripts/listening_practice.py --mode dictation --level 4`  （四级段落挖空）
  - `python scripts/listening_practice.py --mode mark --level 6`  （标出原文会被弱读的词，教练讲解用）
  - 段落库见 `references/listening_transcripts.json`（原创 CET 风格；真实历年真题走检索获取）。
- **场景高频词**：`references/listening_vocab.json`（校园/生活/学术/态度四类），用脚本复习：
  `python scripts/listening_practice.py --mode vocab --scene campus`
- 讲听力时强调：发卷扫选项预判、边听边涂卡、抓信号词（but/however/because）与首尾句、没跟上立刻跳下一题；**弱项在"听不懂"的学员，优先刷挖空听写 + 精听五步法**。
- 真实音频去 `references/resources.md` 的站点听；窗口内用挖空/标记训练"抓弱读词"的硬功夫，配合精听见效最快。

### 2. 水平诊断与计划
- 先问清：目标级别（4 还是 6）、考试日期、每周可投入时长、最近成绩（如有）、**听力弱在哪一层**（词汇/语音/抓重点/选不对）。
- 用 `scripts/study_plan.py` 生成分阶段周计划：
  `python scripts/study_plan.py --exam-date YYYY-MM-DD --level 6 --hours 10 [--score 420]`
- 计划按"基础→强化→冲刺"划分，听力弱的用户在"强化"阶段加大精听与硬技能训练比重（见 `references/listening.md` 第六节）。
- 输出 Markdown 计划给用户，并提示可用 `vocab_drill.py` / `listening_practice.py` 配合执行。

### 3. 词汇闯关（脚本驱动）
- 词库在 `references/vocab_bank.json`（CET-4 约 145 词、CET-6 约 121 词核心高频）。
- 运行交互自测，自动导出错题清单供二刷：
  `python scripts/vocab_drill.py --level 4 --mode en2cn --count 20`
  `python scripts/vocab_drill.py --level 6 --mode cn2en`  （中文→英文）
  `python scripts/vocab_drill.py --level 4 --review`  （只复习上次错题）
- 在无终端交互时，也可直接读取 JSON 给用户出"每日 10 词"卡片或抽测。
- 讲词时补充：词性、中文义、例句、常见搭配与近形词辨析。

### 4. 写作教学与批改
- 先让用户说明题型（现象/对比/解决/图表），从 `references/writing.md` 给对应三段框架 + 万能句。
- 讲加分替换词表，避免小学词汇。
- **批改流程**（用户给作文时严格执行）：
  1. 判结构（是否三段、每段单一中心）
  2. 逐句查语法（主谓一致、时态、冠词、单复数）
  3. 标中式英语与可升级词汇，给替换
  4. 算字数（四级≥120，六级≥150）
  5. 给总分档（内容/结构/语言各 1/3）+ 3 条最该改的点
- 输出"原句→问题→修改建议"对照，比笼统评价更有用。

### 5. 汉译英训练
- 主题词块与句型见 `references/translation.md`（文化/社会/经济类高频）。
- 训练闭环：给中文段 → 用户译 → 对照参考 → 标红差异 → 重译。
- 重点纠：断句、补主语、时态、被动、冠词；用第四节错例做反面教材。

### 6. 阅读策略
- 加载 `references/strategy.md`：试卷构成、时间分配、阅读三类题型解法（仔细阅读定位、长篇匹配扫读、选词填空词性排除）。
- 讲题时结合真实真题段落，示范"定位句—主干拆分—选项比对"。

### 7. 检索真实资料（不内置题库）
- 本技能**不捆绑真题/题库**，需要真实材料时联网获取：
  1. 用 `scripts/find_resources.py --topic 真题 --level 6` 拿到候选站点与推荐搜索词。
  2. 用 **WebSearch** 按推荐词检索最新资料（带年份，如 `2025 年 12 月 六级 真题`）。
  3. 用 **WebFetch** 打开具体页面抽取正文（真题文本、听力文稿、词表、模板）。
  4. 给用户的资料**必须附原始链接与获取日期**。
- 站点信任分级与版权红线见 `references/resources.md`：优先官方（cet.neea.edu.cn），练习站仅索引不搬运，不整卷再分发。
- 用户要"刷题"，引导其去站点做题，本技能负责讲解、批改与计划。

## 交付原则

- 听力优先：先定位用户听力弱在哪一层，再给对应训练，不泛泛而谈。
- 先诊断再给料，不盲目堆内容。
- 模板/词块可背，但要求用户"仿写+重译+精听"形成肌肉记忆，而非只看。
- 批改具体、可操作；计划可随自测结果动态调整各模块比重。
- 全程中文讲解，英文术语与例句保持原样。

## 资源

- `scripts/listening_practice.py` — 听力挖空听写训练（dictation/mark 模式 + 场景词）
- `scripts/vocab_drill.py` — 交互式词汇自测，导出错题
- `scripts/study_plan.py` — 按考试日期生成分阶段周计划
- `scripts/find_resources.py` — 主题→候选站点与推荐搜索词（检索入口，不联网）
- `references/listening.md` — 听力主攻：结构、三层痛点、语音规律、精听五步法、训练重点
- `references/listening_vocab.json` — 听力场景高频词（校园/生活/学术/态度）
- `references/listening_transcripts.json` — 原创 CET 风格听力段落（挖空/标记训练用）
- `references/vocab_bank.json` — 四六级核心高频词库
- `references/strategy.md` — 试卷结构、时间管理、阅读策略、分数诊断
- `references/writing.md` — 四类写作框架、万能句、加分替换、常扣分点、批改流程
- `references/translation.md` — 文化/社会类主题词块、句型、翻译步骤、错例
- `references/resources.md` — 可信资源站点分级、检索流程、版权与合规
