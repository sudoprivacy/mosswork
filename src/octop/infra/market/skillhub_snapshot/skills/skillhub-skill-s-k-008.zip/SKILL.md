---
name: skillhub-skill-s-k-008
description: "知识库收藏资料增量汇总与整理。当用户说\"更新知识库整理报告\"、\"整理知识库收藏\"、\"做一次知识库汇总更新\"、或涉及定期整理全部知识库收藏的意图时触发。支持智能关联推荐（每条A类自动推荐Top3相关资料）和成果转化追踪（未处理→已提炼→已转化漏斗）。同步生成交互式HTML报告（标签点击筛选、标题点击复制搜索词在ima中定位、A/B/C等级Tab切换、多维度组合过滤）。不适用于单篇资料阅读、知识库文件移动/重命名等管理操作。"
---

# 知识库收藏汇总整理更新

## 概述

对用户所有知识库中的收藏资料进行增量汇总整理：扫描全部知识库 → 与上次数据对比 → 对新资料分级归类 → 生成更新报告 → 上传到指定知识库。

核心原则：**收藏不是学习。资料只有经过筛选、提炼、关联、输出和复盘，才算真正变成知识。**

## 工作流程

```
扫描知识库 → 对比变更 → 分级归类 → 生成报告 → 上传知识库
```

### Phase 1：扫描知识库

执行扫描脚本，获取所有知识库的最新资料清单：

```bash
python3 scripts/scan_knowledge_bases.py \
    --output scan_result.json
```

扫描完成后，确认输出条数与知识库实际内容是否大致一致。

### Phase 2：对比变更与分级归类

与上次处理结果对比，对新资料自动分级归类：

```bash
python3 scripts/grade_and_classify.py \
    --new scan_result.json \
    --old processed_kb_items_latest.json \
    --output processed_kb_items_latest.json
```

**关键逻辑**：
- 已有资料保留原分级，不重复处理
- 仅对新增资料执行分级归类（规则见 `references/grading_rules.md`）
- 删除的资料从索引中移除，但在报告中记录

**智能升级检查**：对比完成后，人工判断是否需要将部分B类资料提升为A类。关注以下信号：
- 新模型发布后，涉及该模型+提示词方法论的资料应升级为A类
- 标题同时包含"前沿模型关键词+提示词/方法论"的组合

如有升级，修改 `processed_kb_items_latest.json` 中对应条目的 grade、value、output、action 字段。

### Phase 3：生成报告

```bash
python3 scripts/generate_report.py \
    --data processed_kb_items_latest.json \
    --output 知识库收藏汇总整理报告.md

# 如有上次数据（processed_kb_items_prev.json），自动对比变更；首次执行则跳过
```

**首次执行**时无 prev-grade 文件，省略 `--prev-grade` 参数。

执行后自动产出两个文件：
- `知识库收藏汇总整理报告.md` — Markdown 版（适合在ima中阅读）
- `知识库收藏汇总整理报告_交互版.html` — 交互版（浏览器打开，支持点击筛选/搜索定位）

**Markdown 报告结构**：
1. 变更记录（新增/删除/等级变更）
2. 整体数据（知识库概览、分级统计、主题分布、时效性分布）
3. **📈 成果转化漏斗**：全量 & A类 的未处理/已提炼/已转化分布
4. A类资料索引表（含三级标签 + 产出状态 + **时效性标记**）
5. **🔗 A类智能关联推荐**
6. B类资料索引表
7. C类资料索引表
8. **⚠️ 时效性预警**：自动检测标题中的旧年份、停用模型名，分 `outdated`（过时）和 `review`（待复核）两级，逐条列出原因和建议
9. 优先处理建议
10. C类清理进展
11. 附录：全量索引 + 标签分布统计

**三级标签体系**（报告自动生成）：

```
一级（主题域） / 二级（模型/工具） / 三级（资料性质）
```

- **一级标签**（10个主题域）：AI提示词、AI视频、AI图像、AI工具、设计办公、自媒体、商业变现、个人提升、营销品牌、编程开发
- **二级标签**（模型/工具）：根据标题自动匹配 Seedance、Codex、GPT-Image、Gemini、DeepSeek、PPT、YouTube 等
- **三级标签**（资料性质）：模板、教程、指南、工作流、SOP、提示词、案例、评测、推荐等

标签规则维护见 `references/grading_rules.md`。

### Phase 4：上传到知识库

使用 ima-knowledge 技能的上传工具，将报告上传到指定知识库（由环境变量 IMA_INVENTORY_KB_ID 配置）：

```bash
# 上传 Markdown 版
python3 ../ima-knowledge/scripts/upload_file.py \
    --file-path 知识库收藏汇总整理报告.md \
    --knowledge-base-id "${IMA_INVENTORY_KB_ID}" \
    --rename "知识库收藏汇总整理报告_YYYYMMDD.md"

# 上传交互版 HTML
python3 ../ima-knowledge/scripts/upload_file.py \
    --file-path 知识库收藏汇总整理报告_交互版.html \
    --knowledge-base-id "${IMA_INVENTORY_KB_ID}" \
    --rename "知识库收藏汇总整理报告_交互版_YYYYMMDD.html"
```

其中 YYYYMMDD 替换为当天日期。

**上传前确认**：目标知识库 ID 通过环境变量 `IMA_INVENTORY_KB_ID` 配置，上传前可通过 search_knowledge_base 验证该 ID 仍然有效。

### Phase 5：备份数据

为下次增量对比准备数据：

```bash
cp processed_kb_items_latest.json processed_kb_items_prev.json
```

这确保下次执行时能正确检测变更。

## 输出摘要

流程执行完毕后，向用户输出以下摘要：

1. **变更概览**：新增X条、删除X条、等级变更X条
2. **分级分布**：A类/B类/C类数量及占比
3. **新增A类资料**：逐条列出新增的高价值资料
4. **C类清理进展**：当前C类数量、历次清理记录
5. **下一步建议**：优先转化的方向

## 异常处理

| 异常 | 处理方式 |
|------|----------|
| 扫描脚本返回0条 | 检查API凭证是否有效，重试一次 |
| 上次数据文件不存在 | 作为首次扫描处理，全部资料重新分级 |
| 上传失败 | 检查知识库ID是否正确，确认用户仍为创建者 |
| A类比例异常（>30%或<10%） | 在Phase 2手动调整分级，收紧或放宽A类标准 |

## 资源目录

### scripts/
- `scan_knowledge_bases.py` — 扫描全部知识库，输出资料清单 JSON（支持递归遍历子文件夹）
- `grade_and_classify.py` — 对比新旧数据，对新资料分级归类
- `generate_report.py` — 根据分级数据生成 Markdown 报告（含三级标签系统），同步自动调用 generate_interactive_html.py
- `generate_interactive_html.py` — 生成交互式 HTML 报告（标签点击筛选、标题点击复制搜索词、A/B/C Tab切换、多维度组合过滤）

### references/
- `grading_rules.md` — 分级与归类规则详解（含标签体系维护指引）

## 技能链衔接

kb-inventory-update 是知识管理技能链的第一环，为下游技能提供结构化数据：

```
kb-inventory-update（采集+分级）
    ↓ processed_kb_items_latest.json
    ├── kb-auto-digester（消化→卡片+模板）
    │       ↓ knowledge_cards/
    │       ├── kb-linker（自动关联）
    │       └── kb-synthesizer（跨卡合成）
    ├── kb-graph-builder（可视化图谱）
    └── kb-reviewer（复盘+健康检查）
```

执行完本技能后，建议提示用户：
> "资料已整理完毕。回复「消化新增A类」开始制作知识卡片，回复「生成知识图谱」可视化查看，回复「做一次复盘」检查知识库健康度。"

---
## 部署依赖

本技能脚本依赖 `shared/logger.py`（统一日志模块）。部署时需将 `shared/` 目录与技能目录放在**同级**位置：

```
skills/
├── shared/          ← 必须存在（来自 shared.zip）
│   └── logger.py
└── kb-inventory-update/  （或 kb-graph-builder / kb-auto-digester）
```

脚本通过 `sys.path.insert(0, .../../..)` 自动定位，无需额外配置。若缺少该模块，脚本会报 `ModuleNotFoundError: shared.logger`。
