#!/usr/bin/env python3
"""根据分级归类后的数据，生成 Markdown 格式的汇总整理报告。

用法:
    python3 generate_report.py --data DATA_JSON --output REPORT_MD [--prev-grade PREV_JSON]
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime


# ── 关键词提取（复用于关联推荐）──

STOP_WORDS = {
    "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一",
    "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着",
    "没有", "看", "自己", "这", "他", "她", "它", "们", "那", "些",
    "什么", "怎么", "如何", "为什么", "还是", "可以", "这个", "那个",
    "已经", "比较", "非常", "就是", "使用", "通过", "进行", "对于",
    "所以", "还有", "或", "但", "与", "从", "被", "让", "把", "用", "对",
}


def extract_keywords(title):
    clean = re.sub(r'[#＃【】\\[\\]「」\\(\\)（）\\@\\*]', ' ', title)
    clean = re.sub(r'[，。！？、：；～…·,\\.!\\?:\\-]', ' ', clean)
    return [w for w in clean.split() if len(w) >= 2 and w not in STOP_WORDS][:10]


# ── 标签生成系统 ──

THEME_TO_PRIMARY = {
    "AI提示词工程": "AI提示词", "AI视频与创作": "AI视频",
    "AI视觉与图像创作": "AI图像", "AI工具与自动化": "AI工具",
    "内容创作与自媒体运营": "自媒体", "写作表达与公文材料": "设计办公",
    "市场拓展与变现": "商业变现", "个人学习方法": "个人提升",
    "市场营销与品牌": "营销品牌", "编程开发": "编程开发",
}

SECONDARY_KEYWORDS = [
    ("Seedance", "Seedance"), ("即梦", "Seedance"), ("Sora", "Sora"),
    ("GPT-Image", "GPT-Image"), ("Image2", "GPT-Image"),
    ("Nano Banana", "Nano Banana"), ("Codex", "Codex"),
    ("Claude", "Claude"), ("Gemini", "Gemini"), ("DeepSeek", "DeepSeek"),
    ("GPT", "GPT"), ("NotebookLM", "NotebookLM"),
    ("YouTube", "YouTube"), ("PPT", "PPT"), ("Skill", "Skills"),
    ("Agent", "Agent"), ("OpenClaw", "OpenClaw"), ("MCP", "MCP"),
]

TERTIARY_KEYWORDS = [
    ("模板", "模板"), ("SOP", "SOP"), ("手册", "手册"), ("指南", "指南"),
    ("教程", "教程"), ("工作流", "工作流"), ("方法论", "方法论"),
    ("实操", "实操"), ("案例", "案例"), ("评测", "评测"),
    ("全流程", "全流程"), ("对比", "对比"), ("安装", "安装"),
    ("接入", "接入"), ("配置", "配置"), ("提示词", "提示词"),
    ("提词", "提示词"), ("运营", "运营"), ("涨粉", "涨粉"),
    ("变现", "变现"), ("Skill", "Skills"), ("prompt", "提示词"),
    ("推荐", "推荐"), ("盘点", "盘点"), ("合集", "合集"),
    ("玩法", "玩法"), ("实测", "实测"), ("测评", "测评"),
    ("技巧", "技巧"), ("攻略", "攻略"), ("保姆级", "教程"),
    ("保姆", "教程"), ("入门", "入门"), ("新手", "入门"),
    ("用法", "用法"), ("详解", "详解"), ("拆解", "拆解"),
    ("分享", "分享"), ("思路", "思路"), ("经验", "经验"),
]

def generate_tags(item):
    """为单条资料生成三级标签。"""
    title = item.get("title", "")
    theme = item.get("theme", "")

    primary = THEME_TO_PRIMARY.get(theme, "其他")

    secondary = None
    for keyword, tag in SECONDARY_KEYWORDS:
        if keyword in title:
            secondary = tag
            break
    if not secondary:
        secondary = primary

    tertiary = None
    for keyword, tag in TERTIARY_KEYWORDS:
        if keyword in title:
            tertiary = tag
            break
    if not tertiary:
        if any(w in title for w in ["怎么用", "如何做", "教你", "怎么配"]):
            tertiary = "教程"
        elif any(w in title for w in ["好用", "好用"]):
            tertiary = "推荐"
        elif any(w in title for w in ["最新", "上线", "发布"]):
            tertiary = "资讯"
        elif any(w in title for w in ["思路", "思考", "策略"]):
            tertiary = "思路"
        else:
            tertiary = "参考"

    return primary, secondary, tertiary


# ── A类智能关联推荐 ──

def find_related_items(a_item, all_items, top_n=5):
    """为一条 A 类资料找到最相关的资料，基于关键词共现 + 主题 + 工具重叠。"""
    a_title = a_item["title"]
    a_kw = set(extract_keywords(a_title))
    a_theme = a_item.get("theme", "")

    scores = []
    for other in all_items:
        if other["title"] == a_title:
            continue
        o_title = other["title"]
        o_kw = set(extract_keywords(o_title))

        score = 0.0
        # 关键词共现权重
        shared = a_kw & o_kw
        if shared:
            score += len(shared) * 2.0
        # 同主题加分
        if other.get("theme", "") == a_theme:
            score += 1.5
        # 同级优先（A类之间关联更值得看）
        if other.get("grade") == "A":
            score += 1.0
        # 工具/模型关键词特殊加分
        tool_kws = {"Codex", "Seedance", "GPT-Image", "Claude", "Gemini", "DeepSeek",
                     "Skill", "Agent", "MCP", "Obsidian", "NotebookLM", "PPT", "YouTube"}
        tool_overlap = shared & tool_kws
        if tool_overlap:
            score += len(tool_overlap) * 3.0

        if score > 0:
            scores.append((score, other, list(shared)))

    scores.sort(key=lambda x: -x[0])
    return scores[:top_n]


def main():
    args = sys.argv[1:]
    data_path = args[args.index("--data") + 1]
    output_path = args[args.index("--output") + 1]
    prev_path = args[args.index("--prev-grade") + 1] if "--prev-grade" in args else None

    with open(data_path, "r", encoding="utf-8") as f:
        items = json.load(f)
    archived_items = [i for i in items if i.get("output_status") == "已归档"]
    active_items = [i for i in items if i.get("output_status") != "已归档"]

    prev_data = None
    if prev_path:
        try:
            with open(prev_path, "r", encoding="utf-8") as f:
                prev_data = json.load(f)
        except FileNotFoundError:
            pass

    today = datetime.now().strftime("%Y-%m-%d")
    grade_counts = Counter(item["grade"] for item in active_items)
    theme_counts = Counter(item["theme"] for item in active_items)
    kb_counts = Counter(item["kb_name"] for item in items)
    type_counts = Counter(item["media_type"] for item in items)

    # 变更检测
    added_titles = set()
    removed_titles = set()
    upgraded = []
    if prev_data:
        old_lookup = {i["title"].strip(): i for i in prev_data}
        new_titles = {i["title"].strip() for i in items}
        old_titles = set(old_lookup.keys())
        added_titles = new_titles - old_titles
        removed_titles = old_titles - new_titles
        for title in new_titles & old_titles:
            old_g = old_lookup[title].get("grade", "")
            new_item = next(i for i in items if i["title"].strip() == title)
            new_g = new_item.get("grade", "")
            if old_g != new_g:
                upgraded.append((title, old_g, new_g, new_item.get("kb_name", "")))

    r = []
    r.append(f"# 📚 知识库收藏汇总整理报告 — {today} 更新")
    r.append("")
    r.append(f"> 更新时间：{today} | 整理范围：全部知识库 | 资料总数：{len(items)}条")
    r.append(">")
    r.append("> 核心原则：**收藏不是学习。资料只有经过筛选、提炼、关联、输出和复盘，才算真正变成知识。**")
    r.append("")

    # 一、变更记录
    r.append("## 一、变更记录")
    r.append("")
    if added_titles or removed_titles or upgraded:
        r.append(f"| 变更类型 | 数量 | 详情 |")
        r.append(f"|---|---:|---|")
        if added_titles:
            r.append(f"| 🆕 新增 | {len(added_titles)} | 见下方明细 |")
        if removed_titles:
            r.append(f"| 🗑️ 删除 | {len(removed_titles)} | 见下方明细 |")
        if upgraded:
            r.append(f"| ⬆️ 等级变更 | {len(upgraded)} | 见下方明细 |")
        r.append("")

        if added_titles:
            r.append("### 🆕 新增资料")
            r.append("")
            r.append("| 标题 | 类型 | 所属知识库 | 主题 | 等级 | 一句话价值 |")
            r.append("|---|---|---|---|---|---|")
            for t in sorted(added_titles):
                item = next(i for i in items if i["title"].strip() == t)
                title = t.replace("|", "｜")[:50]
                r.append(f"| {title} | {item['media_type']} | {item['kb_name']} | {item['theme']} | {item['grade']} | {item.get('value','')[:25]} |")
            r.append("")

        if removed_titles:
            r.append("### 🗑️ 删除资料")
            r.append("")
            r.append("| 标题 | 原所属知识库 | 原等级 |")
            r.append("|---|---|---|")
            for t in sorted(removed_titles):
                old = next(i for i in prev_data if i["title"].strip() == t)
                title = t.replace("|", "｜")[:60]
                r.append(f"| {title} | {old['kb_name']} | {old.get('grade','')} |")
            r.append("")

        if upgraded:
            r.append("### ⬆️ 等级变更")
            r.append("")
            r.append("| 标题 | 原等级 | 新等级 | 所属知识库 |")
            r.append("|---|---|---|---|")
            for title, old_g, new_g, kb in upgraded:
                t = title.replace("|", "｜")[:60]
                r.append(f"| {t} | {old_g} | {new_g} | {kb} |")
            r.append("")
    else:
        r.append("本次扫描无变更，资料清单与上次完全一致。")
        r.append("")

    # 二、整体数据
    r.append("## 二、当前整体数据")
    r.append("")
    r.append("### 知识库概览")
    r.append("")
    r.append("| 知识库名称 | 资料数 | 类型分布 |")
    r.append("|---|---:|---|")
    for kb_name, count in sorted(kb_counts.items(), key=lambda x: -x[1]):
        kb_items = [i for i in items if i["kb_name"] == kb_name]
        type_dist = Counter(i["media_type"] for i in kb_items)
        type_str = "、".join(f"{t} {c}条" for t, c in sorted(type_dist.items(), key=lambda x: -x[1])[:3])
        r.append(f"| {kb_name} | {count} | {type_str} |")
    r.append("")

    r.append("### A/B/C 分级统计")
    r.append("")
    r.append("| 等级 | 数量 | 占比 | 处理方式 |")
    r.append("|---|---:|---:|---|")
    r.append(f"| **A类**（立即转化） | {grade_counts['A']} | {grade_counts['A']/len(items)*100:.1f}% | 优先提炼知识卡片，转化为成果 |")
    r.append(f"| **B类**（暂存保留） | {grade_counts['B']} | {grade_counts['B']/len(items)*100:.1f}% | 保留索引，有场景时再激活 |")
    r.append(f"| **C类**（建议删除） | {grade_counts['C']} | {grade_counts['C']/len(items)*100:.1f}% | 建议归档删除 |")
    r.append("")

    r.append("### 主题分布")
    r.append("")
    r.append("| 主题 | 总数 | A类 | B类 | C类 |")
    r.append("|---|---:|---:|---:|---:|")
    grade_by_theme = {}
    for item in active_items:
        key = item["theme"]
        if key not in grade_by_theme: grade_by_theme[key] = Counter()
        grade_by_theme[key][item["grade"]] += 1
    for t, c in sorted(theme_counts.items(), key=lambda x: -x[1]):
        gc = grade_by_theme[t]
        r.append(f"| {t} | {c} | {gc.get('A',0)} | {gc.get('B',0)} | {gc.get('C',0)} |")
    r.append("")

    # 转化漏斗
    r.append("### 📈 成果转化漏斗")
    r.append("")
    status_counts = Counter(i.get("output_status", i.get("status", "未处理")) for i in items)
    a_items = [i for i in items if i["grade"] == "A"]
    a_status = Counter(i.get("output_status", i.get("status", "未处理")) for i in a_items)
    pending = status_counts.get("未处理", 0)
    digested = status_counts.get("已提炼", 0)
    converted = status_counts.get("已转化", 0)
    a_pending = a_status.get("未处理", 0)
    a_digested = a_status.get("已提炼", 0)
    a_converted = a_status.get("已转化", 0)
    r.append("```")
    r.append(f"全量 {len(items)}条 (活跃 {len(active_items)})")
    r.append(f"├── 📝 已提炼: {digested}条 ({digested/max(len(active_items),1)*100:.1f}%)")
    r.append(f"├── 🎯 已转化: {converted}条 ({converted/max(len(active_items),1)*100:.1f}%)")
    r.append(f"└── ⏳ 待处理: {pending}条 ({pending/max(len(active_items),1)*100:.1f}%)")
    r.append("")
    r.append(f"A类 {len(a_items)}条 -----------")
    r.append(f"├── 📝 已提炼: {a_digested}条 ({a_digested/len(a_items)*100:.1f}%)" if a_items else "├── (无A类)")
    r.append(f"├── 🎯 已转化: {a_converted}条 ({a_converted/len(a_items)*100:.1f}%)" if a_items else "")
    r.append(f"└── ⏳ 待处理: {a_pending}条 ({a_pending/len(a_items)*100:.1f}%)" if a_items else "")
    r.append("```")
    r.append("")
    r.append("> 💡 使用方式：当你将某条资料提炼为知识卡片后，告诉我「标记 XX 为已提炼」；当你产出具体成果后，告诉我「标记 XX 为已转化」。")
    r.append("")
    # 自动生成消化建议
    if a_pending > 0:
        # 按主题统计待消化A类
        pending_a = [i for i in items if i["grade"] == "A" and i.get("output_status", i.get("status", "")) == "未处理"]
        theme_pending = Counter(i["theme"] for i in pending_a)
        top_themes = theme_pending.most_common(3)
        if top_themes:
            theme_hints = "、".join([f"「{t}」({c}条)" for t, c in top_themes])
            r.append(f"> 🚀 **建议**：剩余 {a_pending} 条A类待消化。回复「**消化新增的A类资料**」批量处理，或指定消化某个主题（如`消化{top_themes[0][0]}`）定向深挖。")
            r.append(f"> 📊 待消化热点主题：{theme_hints}")
    r.append("")

    # 与上次对比的状态变化
    if prev_data:
        prev_status = Counter(i.get("output_status", i.get("status", "未处理")) for i in prev_data)
        prev_converted = prev_status.get("已转化", 0)
        prev_digested = prev_status.get("已提炼", 0)
        if converted > prev_converted or digested > prev_digested:
            r.append(f"**本周期变化**：已提炼 +{digested-prev_digested} | 已转化 +{converted-prev_converted}")
            r.append("")
    r.append("")

    # 三、A类索引
    r.append(f"## 三、A类资料索引表（{grade_counts['A']}条·优先处理）")
    r.append("")
    r.append("| # | 标签 | 标题 | 类型 | 所属知识库 | 产出状态 | 一句话价值 | 可转化成果 | 下一步 |")
    r.append("|---:|---|---|---|---|---|---|---|---|")
    for idx, item in enumerate(a_items, 1):
        title = item["title"].replace("|", "｜")[:45]
        p, s, t = generate_tags(item)
        tag_str = f"{p}/{s}/{t}"
        os = item.get("output_status", item.get("status", "未处理"))
        tl = item.get("timeliness", "current")
        tl_badge = " ⚠️过时" if tl == "outdated" else (" 🔍复核" if tl == "review" else "")
        title_cell = title
        r.append(f"| {idx} | {tag_str} | {title_cell} | {item['media_type']} | {item['kb_name']} | {os}{tl_badge} | {item.get('value','')[:28]} | {item.get('output','')} | {item.get('action','')} |")
    r.append("")

    # 3.5、A类智能关联推荐
    r.append(f"### 🔗 A类资料智能关联推荐")
    r.append("")
    r.append("> 基于关键词共现、主题重叠、工具/模型共享自动计算，帮助发现被遗忘的高价值关联资料。")
    r.append("")
    for idx, item in enumerate(a_items, 1):
        related = find_related_items(item, items, top_n=3)
        if not related:
            continue
        title_short = item["title"].replace("|", "｜")[:50]
        r.append(f"**{idx}. {title_short}**")
        r.append("")
        for j, (score, rel, shared_kw) in enumerate(related):
            rel_title = rel["title"].replace("|", "｜")[:45]
            shared_str = "、".join(shared_kw)[:40] if shared_kw else "同主题"
            r.append(f"    ├── [{rel['grade']}类] {rel_title}（{shared_str}）（{rel['kb_name']}）")
        r.append("")
    r.append("")

    # 四、B类索引
    r.append(f"## 四、B类资料索引表（{grade_counts['B']}条·暂存保留）")
    r.append("")
    r.append("| # | 标签 | 标题 | 类型 | 所属知识库 | 一句话价值 | 下一步 |")
    r.append("|---:|---|---|---|---|---|---|")
    b_items = [i for i in items if i["grade"] == "B"]
    for idx, item in enumerate(b_items, 1):
        title = item["title"].replace("|", "｜")[:40]
        p, s, t = generate_tags(item)
        tag_str = f"{p}/{s}/{t}"
        title_cell = title
        r.append(f"| {idx} | {tag_str} | {title_cell} | {item['media_type']} | {item['kb_name']} | {item.get('value','')[:25]} | {item.get('action','')} |")
    r.append("")

    # 五、C类索引
    r.append(f"## 五、C类资料索引表（{grade_counts['C']}条·建议删除/归档）")
    r.append("")
    r.append("| # | 标题 | 类型 | 所属知识库 | 归入C类原因 |")
    r.append("|---:|---|---|---|---|")
    c_items = [i for i in items if i["grade"] == "C"]
    for idx, item in enumerate(c_items, 1):
        title = item["title"].replace("|", "｜")[:50]
        title_cell = title
        if any(kw in item["title"] for kw in ["杀疯了","疯了"]): reason = "标题含情绪化用词"
        elif "别再" in item["title"]: reason = "标题含否定式引导"
        elif any(kw in item["title"] for kw in ["太强了","神级","300%"]): reason = "标题含夸张用词"
        else: reason = "标题吸引但实质价值待验证"
        r.append(f"| {idx} | {title_cell} | {item['media_type']} | {item['kb_name']} | {reason} |")
    r.append("")

    # 五点五、时效性预警
    r.append(f"## 五.五、⚠️ 时效性预警")
    r.append("")
    outdated_items = [i for i in items if i.get("timeliness") == "outdated"]
    review_items = [i for i in items if i.get("timeliness") == "review"]

    if not outdated_items and not review_items:
        r.append("✅ 未检测到明显过时或需复核的资料。")
    else:
        if outdated_items:
            r.append(f"### 🛑 可能已过时（{len(outdated_items)}条）")
            r.append("")
            r.append("| 标题 | 类型 | 等级 | 原因 | 建议 |")
            r.append("|---|---|---|---|---|")
            for item in outdated_items:
                title = item["title"].replace("|", "｜")[:45]
                note = item.get("timeliness_note", "")[:35]
                suggestion = "建议降为B类并从A类消化队列移除" if item.get("grade") == "A" else "建议归档或删除"
                r.append(f"| {title} | {item['media_type']} | {item['grade']} | {note} | {suggestion} |")
            r.append("")

        if review_items:
            r.append(f"### 🟡 建议复核时效性（{len(review_items)}条）")
            r.append("")
            r.append("| 标题 | 类型 | 等级 | 原因 | 建议 |")
            r.append("|---|---|---|---|---|")
            for item in review_items:
                title = item["title"].replace("|", "｜")[:45]
                note = item.get("timeliness_note", "")[:35]
                r.append(f"| {title} | {item['media_type']} | {item['grade']} | {note} | 建议人肉确认后决定保留或降级 |")
            r.append("")

        r.append("> 💡 时效性检测基于标题中的年份、模型版本号自动判断。`outdated` 条目建议在下一次清理时处理，`review` 条目建议花5分钟快速确认。")
    r.append("")

    # 六、优先处理建议
    r.append("## 六、优先处理建议")
    r.append("")
    r.append("### 🔥 P0：Seedance 2.0 提示词体系")
    r.append("→ **《Seedance 2.0 AI视频创作SOP》**（提示词公式库 + 分镜模板 + 运镜对照表 + 风格预设库）")
    r.append("")
    r.append("### 🔧 P1：AI Skills & Agent 工具链")
    r.append("→ **《AI Skills & Agent 工具速查手册》**（按场景分类，附安装配置SOP）")
    r.append("")
    r.append("### ✍️ P2：提示词工程方法论")
    r.append("→ **《AIGC提示词工程实战手册》**（覆盖图像/视频/文本三大场景）")
    r.append("")
    r.append("### 🎨 P3：AI视觉分镜工作流")
    r.append("→ **《AI视觉分镜与一致性工作流SOP》**")
    r.append("")

    # 七、C类清理进展
    r.append("## 七、C类清理进展")
    r.append("")
    r.append(f"当前C类：{grade_counts['C']}条。建议在ima客户端中手动清理。")
    r.append("")

    # 附录：完整索引
    r.append("---")
    r.append("")
    r.append(f"## 附录：全部{len(items)}条资料完整索引")
    r.append("")
    r.append("| # | 标签 | 标题 | 类型 | 所属知识库 | 等级 | 状态 |")
    r.append("|---:|---|---|---|---|---|---|")
    for idx, item in enumerate(items, 1):
        title = item["title"].replace("|", "｜")[:48]
        p, s, t = generate_tags(item)
        tag_str = f"{p}/{s}/{t}"
        r.append(f"| {idx} | {tag_str} | {title} | {item['media_type']} | {item['kb_name']} | {item['grade']} | {item.get('output_status', item.get('status','未处理'))} |")
    r.append("")

    # 标签分布统计
    r.append("## 附录：标签分布统计")
    r.append("")
    all_tags = [generate_tags(i) for i in items]
    primary_dist = Counter(t[0] for t in all_tags)
    secondary_dist = Counter(t[1] for t in all_tags)
    tertiary_dist = Counter(t[2] for t in all_tags)
    
    r.append("### 一级标签（主题域）")
    r.append("")
    r.append("| 标签 | 数量 | 占比 |")
    r.append("|---|---:|---:|")
    for t, c in primary_dist.most_common():
        r.append(f"| {t} | {c} | {c/len(items)*100:.1f}% |")
    r.append("")
    
    r.append("### 二级标签（模型/工具）TOP15")
    r.append("")
    r.append("| 标签 | 数量 |")
    r.append("|---|---:|")
    for t, c in secondary_dist.most_common(15):
        r.append(f"| {t} | {c} |")
    r.append("")
    
    r.append("### 三级标签（资料性质）")
    r.append("")
    r.append("| 标签 | 数量 |")
    r.append("|---|---:|")
    for t, c in tertiary_dist.most_common():
        r.append(f"| {t} | {c} |")
    r.append("")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(r))

    log.info(f"报告生成完成: {len(r)} 行, {len(items)} 条资料 → {output_path}")

    # 同步生成交互式 HTML 版本
    html_path = output_path.replace(".md", "_交互版.html")
    if output_path == html_path:
        html_path = output_path + "_交互版.html"
    import subprocess
    import os as _os
    script_dir = _os.path.dirname(_os.path.abspath(__file__))
    html_gen = _os.path.join(script_dir, "generate_interactive_html.py")
    cmd = [sys.executable, html_gen, "--data", data_path, "--output", html_path]
    if prev_path:
        cmd.extend(["--prev-grade", prev_path])
    subprocess.run(cmd)
    log.info(f"交互版 HTML 同步生成: {html_path}")


if __name__ == "__main__":
    main()
