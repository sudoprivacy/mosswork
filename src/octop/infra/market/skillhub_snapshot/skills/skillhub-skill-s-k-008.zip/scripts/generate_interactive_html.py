#!/usr/bin/env python3
"""根据分级归类后的数据，生成交互式 HTML 报告。

用法:
    python3 generate_interactive_html.py --data DATA_JSON --output REPORT_HTML [--prev-grade PREV_JSON]


功能:
    - 标签点击筛选（一级/二级/三级标签均可点击过滤）
    - 标题点击复制搜索关键词（用于在ima客户端搜索定位）
    - A/B/C等级Tab切换
    - 主题/知识库/等级多条件组合筛选
    - 实时搜索框
    - 全数据内嵌，单文件无外部依赖
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log

import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime

# ── 关键词提取 ──

STOP_WORDS = {
    "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一",
    "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着",
    "没有", "看", "自己", "这", "他", "她", "它", "们", "那", "些",
    "什么", "怎么", "如何", "为什么", "还是", "可以", "这个", "那个",
    "已经", "比较", "非常", "就是", "使用", "通过", "进行", "对于",
    "所以", "还有", "或", "但", "与", "从", "被", "让", "把", "用", "对",
}

def extract_search_keywords(title):
    """提取3-5个核心搜索关键词。"""
    clean = re.sub(r'[#＃【】\[\]「」\(\)（）\@\*]', ' ', title)
    clean = re.sub(r'[，。！？、：；～…·,\.!\?\-]', ' ', clean)
    words = [w for w in clean.split() if len(w) >= 2 and w not in STOP_WORDS]
    return ' '.join(words[:5])

# ── 标签生成系统 ──

THEME_TO_PRIMARY = {
    "AI提示词工程": "AI提示词", "AI视频与创作": "AI视频",
    "AI视觉与图像创作": "AI图像", "AI工具与自动化": "AI工具",
    "内容创作与自媒体运营": "自媒体", "写作表达与公文材料": "设计办公",
    "市场拓展与变现": "商业变现", "个人学习方法": "个人提升",
    "市场营销与品牌": "营销品牌", "编程开发": "编程开发",
}

SECONDARY_KEYWORDS = [
    ("Seedance", "Seedance"), ("即梦", "Seedance"), ("Sora", "Sora"),
    ("GPT-Image", "GPT-Image"), ("Image2", "GPT-Image"),
    ("Nano Banana", "Nano Banana"), ("Codex", "Codex"),
    ("Claude", "Claude"), ("Gemini", "Gemini"), ("DeepSeek", "DeepSeek"),
    ("GPT", "GPT"), ("NotebookLM", "NotebookLM"),
    ("YouTube", "YouTube"), ("PPT", "PPT"), ("Skill", "Skills"),
    ("Agent", "Agent"), ("OpenClaw", "OpenClaw"), ("MCP", "MCP"),
]

TERTIARY_KEYWORDS = [
    ("模板", "模板"), ("SOP", "SOP"), ("手册", "手册"), ("指南", "指南"),
    ("教程", "教程"), ("工作流", "工作流"), ("方法论", "方法论"),
    ("实操", "实操"), ("案例", "案例"), ("评测", "评测"),
    ("全流程", "全流程"), ("对比", "对比"), ("安装", "安装"),
    ("接入", "接入"), ("配置", "配置"), ("提示词", "提示词"),
    ("提词", "提示词"), ("运营", "运营"), ("涨粉", "涨粉"),
    ("变现", "变现"), ("Skill", "Skills"), ("prompt", "提示词"),
    ("推荐", "推荐"), ("盘点", "盘点"), ("合集", "合集"),
    ("玩法", "玩法"), ("实测", "实测"), ("测评", "测评"),
    ("技巧", "技巧"), ("攻略", "攻略"), ("保姆级", "教程"),
    ("保姆", "教程"), ("入门", "入门"), ("新手", "入门"),
    ("用法", "用法"), ("详解", "详解"), ("拆解", "拆解"),
    ("分享", "分享"), ("思路", "思路"), ("经验", "经验"),
]

def generate_tags(item):
    title = item.get("title", "")
    theme = item.get("theme", "")
    primary = THEME_TO_PRIMARY.get(theme, "其他")
    
    secondary = None
    for keyword, tag in SECONDARY_KEYWORDS:
        if keyword in title:
            secondary = tag
            break
    if not secondary:
        secondary = primary
    
    tertiary = None
    for keyword, tag in TERTIARY_KEYWORDS:
        if keyword in title:
            tertiary = tag
            break
    if not tertiary:
        if any(w in title for w in ["怎么用", "如何做", "教你", "怎么配"]):
            tertiary = "教程"
        elif any(w in title for w in ["好用", "好用"]):
            tertiary = "推荐"
        elif any(w in title for w in ["最新", "上线", "发布"]):
            tertiary = "资讯"
        elif any(w in title for w in ["思路", "思考", "策略"]):
            tertiary = "思路"
        else:
            tertiary = "参考"
    return primary, secondary, tertiary

# ── 关联推荐 ──

def extract_keywords(title):
    clean = re.sub(r'[#＃【】\[\]「」\(\)（）\@\*]', ' ', title)
    clean = re.sub(r'[，。！？、：；～…·,\.!\?\-]', ' ', clean)
    return [w for w in clean.split() if len(w) >= 2 and w not in STOP_WORDS][:10]

def find_related_items(a_item, all_items, top_n=3):
    a_title = a_item["title"]
    a_kw = set(extract_keywords(a_title))
    a_theme = a_item.get("theme", "")
    scores = []
    for other in all_items:
        if other["title"] == a_title:
            continue
        o_title = other["title"]
        o_kw = set(extract_keywords(o_title))
        score = 0.0
        shared = a_kw & o_kw
        if shared: score += len(shared) * 2.0
        if other.get("theme", "") == a_theme: score += 1.5
        if other.get("grade") == "A": score += 1.0
        tool_kws = {"Codex", "Seedance", "GPT-Image", "Claude", "Gemini", "DeepSeek",
                     "Skill", "Agent", "MCP", "Obsidian", "NotebookLM", "PPT", "YouTube"}
        tool_overlap = shared & tool_kws
        if tool_overlap: score += len(tool_overlap) * 3.0
        if score > 0:
            scores.append((score, other, list(shared)))
    scores.sort(key=lambda x: -x[0])
    return scores[:top_n]

# ── HTML 模板 ──

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>知识库收藏汇总整理报告 — {date}</title>
<style>
/* === Taste-Skill v1.2 === */
::-webkit-scrollbar {{ width: 5px; height: 5px; }}
::-webkit-scrollbar-track {{ background: transparent; }}
::-webkit-scrollbar-thumb {{ background: rgba(255,255,255,0.06); border-radius: 10px; }}
::-webkit-scrollbar-thumb:hover {{ background: rgba(255,255,255,0.12); }}
::-webkit-scrollbar-corner {{ background: transparent; }}

* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{
    font-family: "DM Sans","Geist","Microsoft YaHei",-apple-system,sans-serif;
    background: #121214; color: #cdcac5; line-height: 1.58;
    -webkit-font-smoothing: antialiased; font-weight: 400; font-size: 14px;
}}

.header {{
    background: linear-gradient(170deg, #1c1c24 0%, #18181e 35%, #16161c 100%);
    color: #e4e2df; padding: 40px 48px 36px; position: relative; overflow: hidden;
    border-bottom: 1px solid rgba(200,164,92,0.1);
}}
.header::after {{
    content: ''; position: absolute; top: -80px; right: -100px;
    width: 260px; height: 260px; border-radius: 50%;
    background: radial-gradient(circle, rgba(200,164,92,0.05) 0%, transparent 70%);
    pointer-events: none;
}}
.header h1 {{ font-size: 24px; font-weight: 650; margin-bottom: 8px; letter-spacing: -0.4px; color: #ebe8e3; }}
.header h1 span.accent {{ color: #c8a45c; font-weight: 700; }}
.header .subtitle {{ font-size: 13px; color: #8a8882; font-weight: 400; }}
.header .principle {{ margin-top: 12px; font-size: 12.5px; color: #585651; font-style: italic; }}

.stats-bar {{
    display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px;
    padding: 20px 48px; background: #141419;
    border-bottom: 1px solid rgba(255,255,255,0.035);
}}
.stat-card {{
    text-align: center; padding: 14px 14px;
    border-radius: 10px; background: #1a1a20;
    border: 1px solid rgba(255,255,255,0.035); border-top: 3px solid transparent;
    transition: transform 0.22s cubic-bezier(0.2,0,0,1), box-shadow 0.22s;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
}}
.stat-card:hover {{ transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,0.4); }}
.stat-card .num {{ font-size: 28px; font-weight: 700; letter-spacing: -0.6px; line-height: 34px; height: 34px; }}
.stat-card .label {{ font-size: 11px; color: #6e6b65; margin-top: 4px; font-weight: 500; white-space: nowrap; }}
.stat-card.a {{ border-top-color: #5aab8a; }} .stat-card.a .num {{ color: #5aab8a; }}
.stat-card.b {{ border-top-color: #6a9fd8; }} .stat-card.b .num {{ color: #6a9fd8; }}
.stat-card.c {{ border-top-color: #d46a6a; }} .stat-card.c .num {{ color: #d46a6a; }}
.stat-card.digested {{ border-top-color: #f59e0b; }} .stat-card.digested .num {{ color: #f59e0b; }}
.stat-card.converted {{ border-top-color: #22c55e; }} .stat-card.converted .num {{ color: #22c55e; }}
.stat-card.total {{ border-top-color: #c8a45c; }} .stat-card.total .num {{ color: #c8a45c; }}

.main {{ display: flex; min-height: calc(100vh - 204px); }}

.sidebar {{
    width: 268px; min-width: 268px;
    background: linear-gradient(180deg, rgba(22,22,28,0.98) 0%, rgba(20,20,26,0.99) 100%);
    backdrop-filter: blur(20px) saturate(130%);
    -webkit-backdrop-filter: blur(20px) saturate(130%);
    padding: 22px 18px; border-right: 1px solid rgba(255,255,255,0.035);
    overflow-y: auto; max-height: calc(100vh - 204px); position: sticky; top: 0;
}}
.sidebar-section {{ padding: 4px 0 10px; border-bottom: 1px solid rgba(255,255,255,0.03); margin-bottom: 2px; }}
.sidebar-section:last-child {{ border-bottom: none; margin-bottom: 0; }}
.sidebar h3 {{ font-size: 9.5px; color: #585651; margin: 0 0 10px 2px; text-transform: uppercase; letter-spacing: 1.4px; font-weight: 600; }}

.filter-btn {{
    display: inline-block; padding: 5px 11px; margin: 2px 4px 2px 0;
    border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);
    background: rgba(255,255,255,0.02); font-size: 11px; cursor: pointer;
    transition: all 0.18s cubic-bezier(0.2,0,0,1); color: #8a8882; font-weight: 450;
}}
.filter-btn:hover {{ border-color: rgba(200,164,92,0.25); color: #c8a45c; background: rgba(200,164,92,0.05); }}
.filter-btn.active {{ background: rgba(200,164,92,0.13); color: #c8a45c; border-color: rgba(200,164,92,0.35); font-weight: 550; }}
.filter-btn .count {{ font-size: 9.5px; opacity: 0.45; margin-left: 3px; font-weight: 400; }}

.content {{ flex: 1; padding: 26px 34px; overflow-y: auto; scroll-behavior: smooth; }}

.toolbar {{ display: flex; gap: 12px; margin-bottom: 22px; align-items: center; flex-wrap: wrap; }}
.grade-tabs {{ display: flex; gap: 0; border-radius: 9px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); }}
.grade-tab {{
    padding: 8px 18px; background: transparent; border: none; cursor: pointer;
    font-size: 12.5px; font-weight: 480; transition: all 0.2s; color: #6e6b65;
}}
.grade-tab:hover {{ background: rgba(255,255,255,0.025); color: #98968f; }}
.grade-tab.active {{ background: rgba(200,164,92,0.13); color: #c8a45c; font-weight: 580; }}
.search-box {{
    flex: 1; min-width: 200px; padding: 8px 15px;
    border: 1px solid rgba(255,255,255,0.05); border-radius: 9px;
    font-size: 13px; outline: none; background: #1a1a20; color: #cdcac5; font-weight: 400;
}}
.search-box::placeholder {{ color: #4a4945; }}
.search-box:focus {{ border-color: rgba(200,164,92,0.25); box-shadow: 0 0 0 4px rgba(200,164,92,0.05); }}
.filter-summary {{ font-size: 11.5px; color: #585651; margin-left: auto; white-space: nowrap; }}
.clear-btn {{
    padding: 7px 16px; background: rgba(255,255,255,0.02);
    border: 1px solid rgba(255,255,255,0.05); border-radius: 7px;
    cursor: pointer; font-size: 12px; color: #8a8882; transition: all 0.2s; font-weight: 450;
}}
.clear-btn:hover {{ background: rgba(212,106,106,0.08); border-color: rgba(212,106,106,0.22); color: #d46a6a; }}

.table-wrap {{
    overflow-x: auto; background: #1a1a20; border-radius: 10px;
    box-shadow: 0 2px 16px rgba(0,0,0,0.25); border: 1px solid rgba(255,255,255,0.025);
}}
table {{ width: 100%; border-collapse: collapse; font-size: 12.5px; }}
thead {{ position: sticky; top: 0; z-index: 2; }}
th {{
    background: #18181e; padding: 11px 13px; text-align: left; font-weight: 600;
    border-bottom: 2px solid rgba(255,255,255,0.03); font-size: 10.5px; color: #585651;
    white-space: nowrap; cursor: pointer; user-select: none; letter-spacing: 0.4px; text-transform: uppercase;
}}
th:hover {{ color: #c8a45c; }}
td {{
    padding: 9px 13px; border-bottom: 1px solid rgba(255,255,255,0.022);
    vertical-align: middle; font-size: 12.5px; color: #b8b5af; font-weight: 380;
}}
tr:hover td {{ background: rgba(200,164,92,0.025); }}
tr.hidden {{ display: none; }}

.tag-pill {{
    display: inline-block; padding: 3px 9px; margin: 1px 3px 1px 0;
    border-radius: 7px; font-size: 10.5px; cursor: pointer;
    border: 1px solid transparent; transition: all 0.18s cubic-bezier(0.2,0,0,1);
    white-space: nowrap; font-weight: 480;
}}
.tag-pill:hover {{ transform: scale(1.03); box-shadow: 0 2px 10px rgba(0,0,0,0.25); }}
.tag-primary {{ background: rgba(124,58,237,0.13); color: #a78bfa; border-color: rgba(124,58,237,0.18); }}
.tag-secondary {{ background: rgba(37,99,235,0.1); color: #60a5fa; border-color: rgba(37,99,235,0.15); }}
.tag-tertiary {{ background: rgba(22,163,74,0.1); color: #4ade80; border-color: rgba(22,163,74,0.15); }}

.title-link {{
    color: #d4b86a; cursor: pointer; max-width: 350px; display: inline-block;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    transition: color 0.18s; text-decoration: none;
    border-bottom: 1px dashed rgba(200,164,92,0.15); font-weight: 430;
}}
.title-link:hover {{ color: #e0c880; border-bottom-color: rgba(200,164,92,0.5); }}

.grade-badge {{
    display: inline-block; width: 22px; height: 22px; line-height: 23px;
    text-align: center; border-radius: 5px; font-size: 11px; font-weight: 700;
    font-feature-settings: "tnum";
}}
.grade-a {{ background: rgba(22,163,74,0.14); color: #4ade80; }}
.grade-b {{ background: rgba(37,99,235,0.1); color: #60a5fa; }}
.grade-c {{ background: rgba(220,38,38,0.1); color: #f87171; }}

.toast {{
    position: fixed; bottom: 32px; left: 50%; transform: translateX(-50%);
    background: #2a2a34; color: #e4e2df; padding: 13px 26px; border-radius: 10px;
    font-size: 13px; z-index: 9999; opacity: 0; transition: opacity 0.3s;
    pointer-events: none; box-shadow: 0 6px 28px rgba(0,0,0,0.5);
    border: 1px solid rgba(255,255,255,0.05); font-weight: 450;
}}
.toast.show {{ opacity: 1; }}
.toast .cmd {{ color: #c8a45c; font-weight: 600; }}

.related-tip {{
    position: fixed; background: #1e1e26; border-radius: 10px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5); padding: 13px 17px;
    font-size: 12px; z-index: 9998; max-width: 330px; display: none;
    border: 1px solid rgba(255,255,255,0.05);
}}
.related-tip .tip-title {{ font-weight: 600; margin-bottom: 7px; color: #c8a45c; font-size: 12.5px; }}
.related-tip .tip-item {{
    padding: 4px 0; cursor: pointer; color: #98968f;
    border-bottom: 1px dotted rgba(255,255,255,0.03); font-size: 11.5px;
}}
.related-tip .tip-item:hover {{ color: #c8a45c; }}

.empty-state {{ text-align: center; padding: 70px 20px; color: #3d3b38; }}
.empty-state .icon {{ font-size: 48px; margin-bottom: 14px; opacity: 0.5; }}

.funnel {{ display: flex; gap: 8px; margin: 16px 0; align-items: flex-end; }}
.funnel-bar {{
    flex: 1; text-align: center; padding: 11px 8px; border-radius: 7px;
    color: white; font-size: 12px; font-weight: 600;
}}
.funnel-bar.pending {{ background: #3a3835; }}
.funnel-bar.digested {{ background: #6a9fd8; }}
.funnel-bar.converted {{ background: #5aab8a; }}

@media (max-width: 768px) {{
    .main {{ flex-direction: column; }}
    .sidebar {{ width: 100%; min-width: 100%; max-height: none; position: static; border-right: none; border-bottom: 1px solid rgba(255,255,255,0.04); }}
    .content {{ padding: 16px; }}
    .header {{ padding: 22px 24px; }}
    .stats-bar {{ padding: 14px 20px; }}
    .title-link {{ max-width: 200px; }}
}}
</style>
</head>
<body>

<div class="header">
    <h1>📚 知识库收藏<span class="accent">汇总整理报告</span></h1>
    <div class="subtitle">更新时间：{date} &nbsp;|&nbsp; 整理范围：全部知识库 &nbsp;|&nbsp; 资料总数：{total_count}条</div>
    <div class="principle">核心原则：收藏不是学习。资料只有经过筛选、提炼、关联、输出和复盘，才算真正变成知识。</div>
</div>
</div>

<div class="stats-bar">
    <div class="stat-card total">
        <div class="num">{total_count}</div>
        <div class="label">📦 全量收藏</div>
    </div>
    <div class="stat-card a">
        <div class="num">{count_a}</div>
        <div class="label">🟢 A类·立即转化</div>
    </div>
    <div class="stat-card b">
        <div class="num">{count_b}</div>
        <div class="label">🔵 B类·暂存保留</div>
    </div>
    <div class="stat-card c">
        <div class="num">{count_c}</div>
        <div class="label">🔴 C类·建议删除</div>
    </div>
    <div class="stat-card digested">
        <div class="num">{digested_count}</div>
        <div class="label">📝 已提炼</div>
    </div>
    <div class="stat-card converted">
        <div class="num">{converted_count}</div>
        <div class="label">🎯 已转化</div>
    </div>
</div>

<div class="main">
    <div class="sidebar">
        <div class="sidebar-section">
            <h3>🏷️ 一级标签</h3>
            <div id="filter-primary"></div>
        </div>
        <div class="sidebar-section">
            <h3>🔧 二级标签（工具/模型）TOP12</h3>
            <div id="filter-secondary"></div>
        </div>
        <div class="sidebar-section">
            <h3>📋 三级标签（资料性质）</h3>
            <div id="filter-tertiary"></div>
        </div>
        <div class="sidebar-section">
            <h3>📂 知识库</h3>
            <div id="filter-kb"></div>
        </div>
        <div class="sidebar-section">
            <h3>📊 主题</h3>
            <div id="filter-theme"></div>
        </div>
    </div>
    
    <div class="content">
        <div class="toolbar">
            <div class="grade-tabs" id="grade-tabs">
                <button class="grade-tab active" data-grade="all">全部</button>
                <button class="grade-tab" data-grade="A">🟢 A类</button>
                <button class="grade-tab" data-grade="B">🔵 B类</button>
                <button class="grade-tab" data-grade="C">🔴 C类</button>
            </div>
            <input type="text" class="search-box" id="search" placeholder="🔍 搜索标题、标签、知识库...">
            <button class="clear-btn" id="clear-filters">✕ 清除筛选</button>
            <span class="filter-summary" id="result-count"></span>
        </div>
        
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th style="width:40px">#</th>
                        <th style="width:50px">等级</th>
                        <th style="width:140px">标签</th>
                        <th style="min-width:200px">标题</th>
                        <th style="width:70px">类型</th>
                        <th style="width:110px">所属知识库</th>
                        <th style="width:80px">状态</th>
                        <th style="width:180px">一句话价值</th>
                        <th style="width:110px">可转化成果</th>
                    </tr>
                </thead>
                <tbody id="table-body"></tbody>
            </table>
        </div>
        <div class="empty-state hidden" id="empty-state">
            <div class="icon">🔍</div>
            <div>没有匹配的资料，试试调整筛选条件</div>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>
<div class="related-tip" id="related-tip"></div>

<script src="https://cdn.bootcdn.net/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
<script>
// ── Data ──
const ALL_ITEMS = {items_json};
const RELATED_MAP = {related_json};

// ── State ──
let activeGrade = 'all';
let activeFilters = {{
    primary: new Set(), secondary: new Set(), tertiary: new Set(),
    kb: new Set(), theme: new Set()
}};
let searchTerm = '';

// ── Init ──
function init() {{
    buildFilterButtons();
    renderTable();
    bindEvents();
}}

function buildFilterButtons() {{
    // Collect distributions
    const counts = {{
        primary: {{}}, secondary: {{}}, tertiary: {{}}, kb: {{}}, theme: {{}}
    }};
    ALL_ITEMS.forEach(item => {{
        inc(counts.primary, item.p);
        inc(counts.secondary, item.s);
        inc(counts.tertiary, item.t);
        inc(counts.kb, item.kb_name);
        inc(counts.theme, item.theme);
    }});
    
    renderFilterGroup('filter-primary', counts.primary, 'primary');
    renderFilterGroup('filter-secondary', topN(counts.secondary, 12), 'secondary');
    renderFilterGroup('filter-tertiary', counts.tertiary, 'tertiary');
    renderFilterGroup('filter-kb', counts.kb, 'kb');
    renderFilterGroup('filter-theme', counts.theme, 'theme');
}}

function renderFilterGroup(containerId, counts, type) {{
    const container = document.getElementById(containerId);
    const sorted = Object.entries(counts).sort((a,b) => b[1] - a[1]);
    sorted.forEach(([name, count]) => {{
        const btn = document.createElement('span');
        btn.className = 'filter-btn';
        btn.dataset.type = type;
        btn.dataset.value = name;
        btn.innerHTML = `${{name}}<span class="count">${{count}}</span>`;
        btn.addEventListener('click', () => toggleFilter(type, name, btn));
        container.appendChild(btn);
    }});
}}

function toggleFilter(type, value, btn) {{
    if (activeFilters[type].has(value)) {{
        activeFilters[type].delete(value);
        btn.classList.remove('active');
    }} else {{
        activeFilters[type].add(value);
        btn.classList.add('active');
    }}
    renderTable();
}}

function inc(obj, key) {{ if (key) obj[key] = (obj[key] || 0) + 1; }}
function topN(obj, n) {{
    const sorted = Object.entries(obj).sort((a,b) => b[1] - a[1]);
    return Object.fromEntries(sorted.slice(0, n));
}}

// ── Filtering ──
function matchesFilters(item) {{
    // Grade filter
    if (activeGrade !== 'all' && item.grade !== activeGrade) return false;
    
    // Tag filters
    if (activeFilters.primary.size > 0 && !activeFilters.primary.has(item.p)) return false;
    if (activeFilters.secondary.size > 0 && !activeFilters.secondary.has(item.s)) return false;
    if (activeFilters.tertiary.size > 0 && !activeFilters.tertiary.has(item.t)) return false;
    if (activeFilters.kb.size > 0 && !activeFilters.kb.has(item.kb_name)) return false;
    if (activeFilters.theme.size > 0 && !activeFilters.theme.has(item.theme)) return false;
    
    // Search
    if (searchTerm) {{
        const st = searchTerm.toLowerCase();
        const haystack = (item.title + item.p + item.s + item.t + item.kb_name + item.theme + item.value).toLowerCase();
        if (!haystack.includes(st)) return false;
    }}
    return true;
}}

// ── Render table ──
function renderTable() {{
    const filtered = ALL_ITEMS.filter(matchesFilters);
    const tbody = document.getElementById('table-body');
    const empty = document.getElementById('empty-state');
    const countEl = document.getElementById('result-count');
    
    countEl.textContent = `显示 ${{filtered.length}} / ${{ALL_ITEMS.length}} 条`;
    
    if (filtered.length === 0) {{
        tbody.innerHTML = '';
        empty.classList.remove('hidden');
        return;
    }}
    empty.classList.add('hidden');
    
    tbody.innerHTML = filtered.map((item, idx) => {{
        const tlBadge = item.timeliness === 'outdated' ? ' ⚠️过时' : (item.timeliness === 'review' ? ' 🔍复核' : '');
        const statusText = (item.output_status || item.status || '未处理') + tlBadge;
        const gradeCls = 'grade-' + item.grade.toLowerCase();
        const fullTags = item.p + '/' + item.s + '/' + item.t;
        return `
        <tr>
            <td>${{idx + 1}}</td>
            <td><span class="grade-badge ${{gradeCls}}">${{item.grade}}</span></td>
            <td>
                <span class="tag-pill tag-primary" onclick="clickTag('primary','${{esc(item.p)}}')">${{item.p}}</span>
                <span class="tag-pill tag-secondary" onclick="clickTag('secondary','${{esc(item.s)}}')">${{item.s}}</span>
                <span class="tag-pill tag-tertiary" onclick="clickTag('tertiary','${{esc(item.t)}}')">${{item.t}}</span>
            </td>
            <td>
                <span class="title-link" onclick="copySearch(this)" data-keywords="${{esc(item.search_kw)}}" data-idx="${{idx}}" title="点击复制搜索词，在ima中粘贴定位">${{trunc(item.title, 45)}}</span>
                <span style="font-size:10px;color:#aaa;margin-left:4px;" 
                
            </td>
            <td>${{item.media_type}}</td>
            <td>${{item.kb_name}}</td>
            <td>${{statusText}}</td>
            <td style="font-size:12px;color:#666">${{trunc(item.value || '', 28)}}</td>
            <td style="font-size:12px">${{item.output || ''}}</td>
        </tr>`;
    }}).join('');
    
    updateActiveFilterButtons();
}}

function updateActiveFilterButtons() {{
    document.querySelectorAll('.filter-btn').forEach(btn => {{
        const type = btn.dataset.type;
        const value = btn.dataset.value;
        if (activeFilters[type].has(value)) {{
            btn.classList.add('active');
        }} else {{
            btn.classList.remove('active');
        }}
    }});
}}

function clickTag(type, value) {{
    // Find the button and toggle it
    const btn = document.querySelector(`.filter-btn[data-type="${{type}}"][data-value="${{value}}"]`);
    if (btn) {{
        if (activeFilters[type].has(value)) {{
            activeFilters[type].delete(value);
            btn.classList.remove('active');
        }} else {{
            activeFilters[type].add(value);
            btn.classList.add('active');
        }}
        renderTable();
    }}
}}

function esc(s) {{ return (s||'').replace(/'/g, "\\'").replace(/"/g, '&quot;'); }}
function trunc(s, n) {{ return s && s.length > n ? s.slice(0,n) + '...' : (s||''); }}

// ── Copy search keywords ──
function copySearch(el) {{
    const keywords = el.dataset.keywords;
    navigator.clipboard.writeText(keywords).then(() => {{
        showToast(`已复制搜索词：<span class="cmd">${{keywords}}</span><br>在 ima 知识库中 ⌘V / Ctrl+V 搜索定位`);
    }});
}}

function showToast(msg) {{
    const toast = document.getElementById('toast');
    toast.innerHTML = msg;
    toast.classList.add('show');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => toast.classList.remove('show'), 3000);
}}

// ── Events ──
function bindEvents() {{
    // Grade tabs
    document.querySelectorAll('.grade-tab').forEach(tab => {{
        tab.addEventListener('click', () => {{
            document.querySelectorAll('.grade-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            activeGrade = tab.dataset.grade;
            renderTable();
        }});
    }});
    
    // Search
    document.getElementById('search').addEventListener('input', (e) => {{
        searchTerm = e.target.value;
        renderTable();
    }});
    
    // Clear filters
    document.getElementById('clear-filters').addEventListener('click', () => {{
        Object.keys(activeFilters).forEach(k => activeFilters[k] = new Set());
        searchTerm = '';
        document.getElementById('search').value = '';
        activeGrade = 'all';
        document.querySelectorAll('.grade-tab').forEach(t => t.classList.remove('active'));
        document.querySelector('.grade-tab[data-grade="all"]').classList.add('active');
        renderTable();
    }});
    
    // Keyboard shortcut: Ctrl+F focuses search
    document.addEventListener('keydown', (e) => {{
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {{
            e.preventDefault();
            document.getElementById('search').focus();
        }}
    }});
}}

// ── Start ──
init();

// ── GSAP Entrance Animation ──
if (typeof gsap !== 'undefined') {{
    gsap.from('.header', {{ opacity: 0, y: -20, duration: 0.6, ease: 'power2.out' }});
    gsap.from('.stat-card', {{
        opacity: 0, y: 12, duration: 0.4, stagger: 0.08, ease: 'back.out(1.4)',
        delay: 0.15
    }});
    gsap.from('.sidebar', {{ opacity: 0, x: -16, duration: 0.5, ease: 'power2.out', delay: 0.3 }});
    gsap.from('.table-wrap', {{
        opacity: 0, y: 20, duration: 0.5, ease: 'power2.out', delay: 0.4
    }});
    gsap.from('.toolbar', {{ opacity: 0, duration: 0.4, delay: 0.5 }});
}}
</script>
</body>
</html>"""

def main():
    args = sys.argv[1:]
    data_path = args[args.index("--data") + 1]
    output_path = args[args.index("--output") + 1]
    prev_path = args[args.index("--prev-grade") + 1] if "--prev-grade" in args else None

    with open(data_path, "r", encoding="utf-8") as f:
        items = json.load(f)

    prev_data = None
    if prev_path:
        try:
            with open(prev_path, "r", encoding="utf-8") as f:
                prev_data = json.load(f)
        except FileNotFoundError:
            pass

    today = datetime.now().strftime("%Y-%m-%d")
    grade_counts = Counter(item["grade"] for item in items)

    # Build enriched items for frontend
    enriched = []
    for item in items:
        p, s, t = generate_tags(item)
        enriched.append({
            "title": item["title"],
            "grade": item["grade"],
            "p": p, "s": s, "t": t,
            "kb_name": item.get("kb_name", ""),
            "theme": item.get("theme", ""),
            "media_type": item.get("media_type", ""),
            "value": item.get("value", ""),
            "output": item.get("output", ""),
            "output_status": item.get("output_status", item.get("status", "")),
            "timeliness": item.get("timeliness", "current"),
            "search_kw": extract_search_keywords(item["title"]),
        })

    # Build related map for A类 items
    a_items = [i for i in items if i["grade"] == "A"]
    related_map = {}
    for a_item in a_items:
        related = find_related_items(a_item, items, top_n=3)
        if related:
            related_map[a_item["title"]] = [
                {"title": r[1]["title"], "grade": r[1]["grade"], "kb": r[1].get("kb_name", "")}
                for r in related
            ]

    # Count statuses
    status_counts = Counter(i.get("output_status", i.get("status", "未处理")) for i in items)
    digested_count = status_counts.get("已提炼", 0)
    converted_count = status_counts.get("已转化", 0)

    # Render HTML
    html = HTML_TEMPLATE.format(
        date=today,
        total_count=len(items),
        count_a=grade_counts.get("A", 0),
        count_b=grade_counts.get("B", 0),
        count_c=grade_counts.get("C", 0),
        digested_count=digested_count,
        converted_count=converted_count,
        items_json=json.dumps(enriched, ensure_ascii=False),
        related_json=json.dumps(related_map, ensure_ascii=False),
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    log.info(f"交互式 HTML 报告生成完成: {len(enriched)} 条资料 → {output_path}")


if __name__ == "__main__":
    main()
