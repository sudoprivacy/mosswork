#!/usr/bin/env python3
"""扫描所有知识库，输出全量资料清单 JSON。

用法:
    python3 scan_knowledge_bases.py [--output OUTPUT_PATH]


输出:
    JSON 文件，包含所有知识库中每条资料的元信息。
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log

import json
import subprocess
import os
import sys


API_BASE = "https://ima.qq.com/openapi/wiki/v1"
CLIENTID = os.environ.get("IMA_OPENAPI_CLIENTID", "")
APIKEY = os.environ.get("IMA_OPENAPI_APIKEY", "")

MEDIA_TYPE_MAP = {
    1: "PDF", 2: "网页", 3: "Word", 4: "PPT", 5: "Excel",
    6: "公众号文章", 7: "Markdown", 9: "图片", 11: "笔记",
    12: "QA对话", 13: "TXT文本", 14: "Xmind", 15: "录音",
    16: "网页视频", 17: "对话", 18: "视频", 19: "播客", 99: "文件夹",
}

DEFAULT_OUTPUT = "scan_result.json"
PAGE_SIZE = 50
# 动态上限：每页50条，50页=2500条，覆盖知识库增长
MAX_PAGES_PER_KB = 50


def api_call(endpoint, body):
    """调用 ima 开放 API。带重试机制：3次+指数退避+超时120s。"""
    import time as _time
    last_err = None
    for attempt in range(3):
        try:
            result = subprocess.run([
                "curl", "-s", "-X", "POST",
                f"{API_BASE}/{endpoint}",
                "-H", f"ima-openapi-clientid: {CLIENTID}",
                "-H", f"ima-openapi-apikey: {APIKEY}",
                "-H", "Content-Type: application/json",
                "-d", json.dumps(body),
            ], capture_output=True, text=True, timeout=120)
            resp = json.loads(result.stdout)
            if resp.get("code") != 0:
                log.error(f"API error [{endpoint}]: {resp}")
            return resp
        except (subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            last_err = e
            log.warning(f"API call [{endpoint}] attempt {attempt+1}/3 failed: {e}")
            _time.sleep(2 * (attempt + 1))  # 指数退避: 2s, 4s
    log.error(f"API call [{endpoint}] failed after 3 attempts: {last_err}")
    return {"code": -1, "data": {}, "error": str(last_err)}


def get_all_knowledge_bases():
    """获取用户所有知识库列表。"""
    kb_list = []
    cursor = ""
    while True:
        resp = api_call("search_knowledge_base", {
            "query": "", "cursor": cursor, "limit": 20
        })
        data = resp.get("data", {})
        kb_list.extend(data.get("info_list", []))
        if data.get("is_end", True):
            break
        cursor = data.get("next_cursor", "")
    return kb_list


def scan_folder(kb_id, kb_name, folder_id, folder_name, depth=0):
    """递归扫描文件夹，返回其中所有条目。"""
    items = []
    cursor = ""
    page = 0
    while page < MAX_PAGES_PER_KB:
        resp = api_call("get_knowledge_list", {
            "knowledge_base_id": kb_id,
            "folder_id": folder_id,
            "cursor": cursor,
            "limit": PAGE_SIZE,
        })
        data = resp.get("data", {})
        for item in data.get("knowledge_list", []):
            # 如果是文件夹，递归进入
            if item.get("media_type") == 99:
                sub_items = scan_folder(
                    kb_id, kb_name,
                    item["media_id"], item.get("title", ""),
                    depth=depth + 1
                )
                items.extend(sub_items)
                continue
            # 普通资料
            mt = MEDIA_TYPE_MAP.get(item.get("media_type", 0), f"type_{item.get('media_type', 0)}")
            items.append({
                "kb_name": kb_name,
                "kb_id": kb_id,
                "media_id": item.get("media_id", ""),
                "title": item.get("title", ""),
                "media_type": mt,
                "parent_folder_id": item.get("parent_folder_id", ""),
                "folder_name": folder_name,
            })
        if data.get("is_end", True):
            break
        cursor = data.get("next_cursor", "")
        page += 1
    return items


def scan_knowledge_base(kb_id, kb_name):
    """扫描单个知识库（含子文件夹），返回其中所有条目。"""
    items = []
    cursor = ""
    page = 0
    while page < MAX_PAGES_PER_KB:
        resp = api_call("get_knowledge_list", {
            "knowledge_base_id": kb_id,
            "cursor": cursor,
            "limit": PAGE_SIZE,
        })
        data = resp.get("data", {})
        for item in data.get("knowledge_list", []):
            # 如果是文件夹，递归进入
            if item.get("media_type") == 99:
                folder_items = scan_folder(
                    kb_id, kb_name,
                    item["media_id"], item.get("title", "")
                )
                items.extend(folder_items)
                continue
            # 普通资料
            mt = MEDIA_TYPE_MAP.get(item.get("media_type", 0), f"type_{item.get('media_type', 0)}")
            items.append({
                "kb_name": kb_name,
                "kb_id": kb_id,
                "media_id": item.get("media_id", ""),
                "title": item.get("title", ""),
                "media_type": mt,
                "parent_folder_id": item.get("parent_folder_id", ""),
            })
        if data.get("is_end", True):
            break
        cursor = data.get("next_cursor", "")
        page += 1
    return items


def main():
    output_path = sys.argv[sys.argv.index("--output") + 1] if "--output" in sys.argv else DEFAULT_OUTPUT

    log.info("扫描知识库列表...")
    kb_list = get_all_knowledge_bases()
    log.info(f"共发现 {len(kb_list)} 个知识库")

    all_items = []
    for kb in kb_list:
        kb_name = kb["kb_name"]
        kb_id = kb["kb_id"]
        content_count = int(kb.get("content_count", 0))
        log.info(f"  扫描 [{kb_name}] (预期 {content_count} 条)...")
        items = scan_knowledge_base(kb_id, kb_name)
        log.info(f"    实际获取 {len(items)} 条")
        all_items.extend(items)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_items, f, ensure_ascii=False, indent=2)

    log.info(f"\n扫描完成: 共 {len(all_items)} 条资料 → {output_path}")


if __name__ == "__main__":
    main()
