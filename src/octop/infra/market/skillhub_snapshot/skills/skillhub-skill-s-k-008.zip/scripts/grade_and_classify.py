#!/usr/bin/env python3
"""对比新旧扫描数据，对新资料进行分级归类，输出全量处理后 JSON。

用法:
    python3 grade_and_classify.py --new NEW_JSON --old OLD_JSON --output OUTPUT_JSON


分级和归类规则详见 references/grading_rules.md
"""

import sys as _sys, os as _os
_sys.path.insert(0, _os.path.normpath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '../..')))
from shared.logger import log

import json
import sys
from collections import Counter

# ── 主题分类规则 ──

THEME_RULES = {
    "AI视频与创作": "AI视频与创作",
    "YouTube运营": "内容创作与自媒体运营",
    "Skills与工具": "AI工具与自动化",
    "AI绘画与图像": "AI视觉与图像创作",
    "PPT与演示": "写作表达与公文材料",
    "提示词工程": "AI提示词工程",
    "AI大模型": "AI工具与自动化",
    "AI Agnet": "AI工具与自动化",
    "AI Agent": "AI工具与自动化",
    "学习与教育": "个人学习方法",
    "AI办公效率": "AI工具与自动化",
    "AI写作": "AI提示词工程",
    "创业与变现": "市场拓展与变现",
    "编程与开发": "编程与开发",
    "分类整理结果": "个人学习方法",
}

TITLE_KEYWORD_THEME = [
    (["营销", "品牌", "公关", "市场", "策划"], "市场营销与品牌"),
    (["提示词", "Prompt", "prompt", "提示工程"], "AI提示词工程"),
    (["Agent", "agent", "智能体", "MCP", "workflow"], "AI工具与自动化"),
    (["变现", "赚钱", "创业", "商业", "副业", "收入"], "市场拓展与变现"),
    (["PPT", "ppt", "演示", "汇报"], "写作表达与公文材料"),
    (["写作", "公文", "报告", "文案"], "写作表达与公文材料"),
    (["YouTube", "youtube", "自媒体", "涨粉", "运营"], "内容创作与自媒体运营"),
    (["视频", "Seedance", "Kling", "可灵", "Sora", "Runway"], "AI视频与创作"),
    (["绘画", "图像", "Midjourney", "Stable", "Flux", "ComfyUI", "SD"], "AI视觉与图像创作"),
    (["Skill", "skill", "技能", "工具", "插件"], "AI工具与自动化"),
    (["大模型", "GPT", "Claude", "Gemini", "DeepSeek", "LLM"], "AI工具与自动化"),
]


def classify_theme(item):
    """根据标题关键词和知识库名称归类主题。"""
    title = item["title"]
    for keywords, theme in TITLE_KEYWORD_THEME:
        if any(kw in title for kw in keywords):
            return theme
    return THEME_RULES.get(item["kb_name"], "其他")


# ── A/B/C 分级规则 ──

C_KEYWORDS = [
    "震惊", "竟然", "居然", "秘密", "速看", "赶紧", "疯了", "逆天",
    "暴涨", "必看", "免费领", "收藏等于学会", "太强了", "不敢相信",
    "看哭了", "别再", "赶紧收藏", "建议收藏",
]

A_STRICT_KEYWORDS = [
    "模板", "SOP", "指南", "手册", "全流程", "工作流", "方法论",
    "框架", "规范", "完整教程", "实操指南", "V1.0", "V2.0",
]

A_CORE_TOPICS = [
    "Seedance 2.0", "Seedance2.0", "Seedance提示词",
    "Prompt模板", "提示词模板", "AI视频生成全流程",
    "AI Agent", "MCP协议", "Skill",
    # 前沿模型+提示词方法论组合
    "GPT-Image",  # GPT-Image 系列提示词方法论
]

A_TITLE_PATTERNS = [
    # 标题同时包含"模型+提示词"关键词的
    lambda t: any(m in t for m in ["GPT-Image"]) and "提示词" in t,
]


def grade_item(item):
    """对单条资料进行 A/B/C 分级。"""
    title = item["title"]

    # C类：标题党
    if any(kw in title for kw in C_KEYWORDS):
        return "C"

    # A类：系统性/方法论资料
    has_systematic = any(kw in title for kw in A_STRICT_KEYWORDS)
    is_core_topic = any(kw in title for kw in A_CORE_TOPICS)
    matches_pattern = any(pat(title) for pat in A_TITLE_PATTERNS)

    if has_systematic or is_core_topic or matches_pattern:
        return "A"

    return "B"


# ── 价值评估 ──

def assess_value(item):
    grade, title = item["grade"], item["title"]
    if grade == "A":
        if "提示词" in title or "Prompt" in title:
            return "可直接复用的提示词模板/方法论，适合精读并转化为个人提示词库"
        if "Seedance" in title:
            return "Seedance视频创作核心技巧，适合转化为AI视频SOP"
        if "Skill" in title or "Agent" in title:
            return "AI工具/智能体实操指南，适合整合进个人工作流"
        if "模板" in title or "手册" in title:
            return "系统性模板/手册，适合精读后直接应用于工作场景"
        if "全流程" in title or "工作流" in title:
            return "端到端工作流参考，适合转化为个人SOP"
        return "与核心场景高度相关，值得精读并转化为成果"
    if grade == "B":
        if "YouTube" in title or "运营" in title or "涨粉" in title:
            return "自媒体运营参考，有实战案例可借鉴"
        if "AI" in title:
            return "AI领域资讯/技巧，有一定参考价值"
        return "有参考价值，暂无明确使用场景"
    return "标题吸引但实质价值待验证，建议归档或删除"


def suggest_output(item):
    grade, title = item["grade"], item["title"]
    if grade == "A":
        if "提示词" in title or "Prompt" in title: return "提示词模板库"
        if "Seedance" in title or "视频" in title: return "AI视频创作SOP"
        if "Skill" in title or "Agent" in title: return "工具操作SOP"
        if "模板" in title: return "可复用模板"
        if "全流程" in title or "工作流" in title: return "工作流SOP"
        return "知识卡片"
    return "暂存索引" if grade == "B" else "建议删除/归档"


def next_action(item):
    return {"A": "精读→做卡片→转成果", "B": "暂存索引", "C": "删除/归档"}[item["grade"]]


# ── 时效性检测 ──

import re
from datetime import datetime

# 已停用/被取代的旧模型关键词
DEPRECATED_MODELS = [
    (r"GPT-3[^.]", "GPT-3已被GPT-4/GPT-5系列取代"),
    (r"ChatGPT.?3\.5", "GPT-3.5已落后于GPT-4/GPT-5系列"),
    (r"Claude\s*[12](?![0-9])", "Claude 1/2已被Claude 3/4系列取代"),
    (r"Disco\s*Diffusion", "Disco Diffusion已被Stable Diffusion/Flux等替代"),
    (r"DALL-E\s*2", "DALL-E 2已被DALL-E 3/GPT-Image替代"),
    (r"Midjourney\s*v?[1234](?![0-9])", "Midjourney旧版已被V6/V7取代"),
    (r"Stable\s*Diffusion\s*[12](?![0-9])", "SD 1.x/2.x已被SDXL/SD3系列取代"),
    (r"Runway\s*Gen[- ]?[12](?![0-9])", "Runway Gen-1/2已被Gen-3/4取代"),
    (r"ChatGPT\s*4[^.]", "GPT-4已被GPT-4o/GPT-5.5系列取代"),
]

# 教程型资料关键词（时效性衰减快）
TUTORIAL_KEYWORDS = [
    "教程", "指南", "入门", "新手", "安装", "配置", "保姆级",
    "手把手", "实操", "搭建", "部署", "接入", "注册",
]

def detect_timeliness(item):
    """检测资料时效性，返回 (timeliness, note)。"""
    title = item.get("title", "")
    media_type = item.get("media_type", "")
    current_year = datetime.now().year

    # 1. 年份检测（排除"2000万"等数量词）
    year_matches = re.findall(r"(20\d{2})(?=[年版代集期]|\s*教程|\s*更新|\s*发布)", title)
    if not year_matches:
        # fallback: 匹配所有20xx，但排除后面跟"万/亿/人/次"等量词的情况
        all_years = re.findall(r"(20\d{2})(?!\s*[万亿人次数个篇条件])", title) if "20" in title else []
        # 再过滤：去掉1980-2019（明显不是版本号）以及2050+
        year_matches = [y for y in all_years if 2020 <= int(y) <= 2030]
    old_years = [y for y in year_matches if int(y) < current_year - 1]
    if old_years:
        oldest = min(int(y) for y in old_years)
        ago = current_year - oldest
        if ago >= 3:
            return ("outdated", f"标题含{oldest}年（{ago}年前），内容大概率已过时")
        elif ago >= 2:
            return ("review", f"标题含{oldest}年（{ago}年前），建议复核时效性")

    # 2. 旧模型检测
    for pattern, note in DEPRECATED_MODELS:
        if re.search(pattern, title):
            return ("outdated", note)

    # 3. 教程型+旧模型/旧年份的组合
    is_tutorial = any(kw in title for kw in TUTORIAL_KEYWORDS)
    if is_tutorial:
        for pattern, note in DEPRECATED_MODELS[:5]:  # 前5个最明显的
            if re.search(pattern, title):
                return ("outdated", f"教程+{note}，时效性风险极高")

    # 4. 内容类型本身衰变快但没有旧标志 → 提示关注
    CURRENT_SIGNALS = ["最新", "2026", "2025", "2.0", "Pro", "V6", "V7", "GPT-5",
                        "Codex", "Seedance2", "GPT-Image", "NotebookLM", "Gemini 2"]
    has_current_signal = any(s in title for s in CURRENT_SIGNALS)
    if is_tutorial and not has_current_signal:
        return ("review", "教程类资料无明确时效标记，建议确认是否仍适用")

    return ("current", "")


# ── 主流程 ──

def main():
    args = sys.argv[1:]
    new_path = args[args.index("--new") + 1]
    old_path = args[args.index("--old") + 1]
    output_path = args[args.index("--output") + 1]

    with open(new_path, "r", encoding="utf-8") as f:
        new_items = json.load(f)
    with open(old_path, "r", encoding="utf-8") as f:
        old_items = json.load(f)

    # 双键查找表：media_id（精确） + title（回退）
    old_by_media = {}
    old_by_title = {}
    for old in old_items:
        mid = old.get("media_id", "").strip()
        if mid:
            old_by_media[mid] = old
        old_by_title[old["title"].strip()] = old

    processed = []
    rename_count = 0  # 标题修改但 media_id 匹配（保留分级）
    title_match_count = 0  # 仅 title 匹配（回退匹配）

    for idx, item in enumerate(new_items, 1):
        title = item["title"].strip()
        media_id = item.get("media_id", "").strip()
        item["idx"] = idx

        old = None
        match_method = None

        # 优先：media_id 精确匹配
        if media_id and media_id in old_by_media:
            old = old_by_media[media_id]
            match_method = "media_id"
            if old["title"].strip() != title:
                rename_count += 1

        # 回退：title 匹配（历史数据可能无 media_id）
        elif title in old_by_title:
            old = old_by_title[title]
            match_method = "title"
            title_match_count += 1

        if old is not None:
            # 保留已有分级数据，更新元信息
            old["kb_name"] = item.get("kb_name", old.get("kb_name", ""))
            old["kb_id"] = item.get("kb_id", old.get("kb_id", ""))
            old["media_id"] = item.get("media_id", old.get("media_id", ""))
            old["media_type"] = item.get("media_type", old.get("media_type", ""))
            old["idx"] = idx
            # 标题有变化时更新（保留旧标题记录在 note 中）
            if old["title"].strip() != title:
                # 保留旧标题痕迹，方便追溯
                old["_previous_title"] = old.get("_previous_title", old["title"])
                old["title"] = title
            if "output_status" not in old:
                old["output_status"] = old.get("status", "未处理")
            # 保留已确认的时效性：仅当上次标记为 "review" 或未设置时重新检测
            existing_tl = old.get("timeliness", "")
            if existing_tl in ("review", "", None):
                tl, tl_note = detect_timeliness(old)
                old["timeliness"] = tl
                old["timeliness_note"] = tl_note
            processed.append(old)
        else:
            # 真正的新资料：分级归类
            item["theme"] = classify_theme(item)
            item["grade"] = grade_item(item)
            item["value"] = assess_value(item)
            item["output"] = suggest_output(item)
            item["action"] = next_action(item)
            item["status"] = "未处理"
            item["output_status"] = "未处理"
            tl, tl_note = detect_timeliness(item)
            item["timeliness"] = tl
            item["timeliness_note"] = tl_note
            processed.append(item)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(processed, f, ensure_ascii=False, indent=2)

    # 输出统计（用 media_id + title 双键做变更检测）
    new_ids = {i.get("media_id", "").strip(): i for i in new_items if i.get("media_id", "").strip()}
    old_ids = {i.get("media_id", "").strip(): i for i in old_items if i.get("media_id", "").strip()}
    new_titles = {i["title"].strip() for i in new_items}
    old_titles = {i["title"].strip() for i in old_items}

    # 真正新增：media_id 不在旧数据中，且 title 也不在旧数据中
    truly_new_ids = set(new_ids) - set(old_ids)
    truly_new = [
        new_ids[mid] for mid in truly_new_ids
        if new_ids[mid]["title"].strip() not in old_titles
    ]
    # 真正删除：media_id 不在新数据中，且 title 也不在新数据中
    truly_removed_ids = set(old_ids) - set(new_ids)
    truly_removed = [
        old_ids[mid] for mid in truly_removed_ids
        if old_ids[mid]["title"].strip() not in new_titles
    ]

    grade_counts = Counter(item["grade"] for item in processed)
    log.info(f"处理完成: 总计 {len(processed)} 条")
    log.info(f"  A类: {grade_counts['A']} | B类: {grade_counts['B']} | C类: {grade_counts['C']}")
    tl_counts = Counter(i.get("timeliness", "current") for i in processed)
    outdated = tl_counts.get("outdated", 0)
    review = tl_counts.get("review", 0)
    if outdated or review:
        log.warning(f"  ⚠️ 时效性: {outdated}条过时 | {review}条待复核")
    log.info(f"  新增: {len(truly_new)} | 删除: {len(truly_removed)}")
    if rename_count:
        log.info(f"  🔄 标题变更(media_id保留): {rename_count} 条")
    if title_match_count:
        log.warning(f"  ⚠️ title回退匹配: {title_match_count} 条（建议检查 media_id）")
    if truly_new:
        log.info(f"  新增资料:")
        for item in truly_new:
            t = item["title"]
            log.info(f"    [{item['kb_name']}] {t} → {item['grade']}类 ({item.get('theme', '')})")
    if truly_removed:
        log.info(f"  删除资料:")
        for old in truly_removed:
            t = old["title"]
            g = old.get("grade", "?")
            log.info(f"    [{old['kb_name']}] {t[:60]}... (was {g}类)")


if __name__ == "__main__":
    main()
