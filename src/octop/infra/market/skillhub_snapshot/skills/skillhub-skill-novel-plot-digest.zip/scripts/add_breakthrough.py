# -*- coding: utf-8 -*-
"""
add_breakthrough.py —— 向「案件与主线全梳理」文档注入「案件突破口【提炼】」。

用法：
  python3 add_breakthrough.py --in 梳理文档.md --breakthroughs bt.json [--out 输出.md]

bt.json 格式：{ "1": "突破口文本", "14": "..." }  （键为案件编号字符串/整数）

行为：
  - 在每个 `### 案件 N` 下的 `- **经过**：` 行之后，插入 `- **案件突破口【提炼】**：<文本>`。
  - 若该行之后已存在突破口行，跳过（幂等，可重复运行）。
  - 顶部图例后若无说明行，补一行「另：案件突破口【提炼】…」。
  - 写入前自动留 .bt-<时间戳>.bak 备份。
"""
import re, shutil, os, json, argparse
from datetime import datetime


CASE_RE = re.compile(r'^###\s*案件\s*(\d+)')
JING_RE = re.compile(r'^- \*\*经过\*\*：')
TUPO_RE = re.compile(r'^- \*\*案件突破口')
NOTE_TEXT = ("> 另：**案件突破口【提炼】**　各案「经过」中撬动全案的决断性线索，"
             "由梳理者从原文复盘提炼，非独立剧透，仅供复盘锚点。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="梳理文档 md（含 ### 案件 N）")
    ap.add_argument("--breakthroughs", required=True, help="JSON：{案件编号: 突破口文本}")
    ap.add_argument("--out", default=None, help="输出路径（默认覆盖 --in）")
    args = ap.parse_args()

    with open(args.breakthroughs, encoding="utf-8") as f:
        raw = json.load(f)
    bt = {int(k): str(v).strip() for k, v in raw.items()}

    out_path = args.out or args.inp
    if out_path == args.inp:
        bak = args.inp + f".bt-{datetime.now().strftime('%Y%m%d-%H%M%S')}.bak"
        shutil.copy2(args.inp, bak)
        print("backup ->", bak)

    with open(args.inp, encoding="utf-8") as f:
        lines = f.read().split("\n")

    out, cur, inserted = [], None, 0
    for i, ln in enumerate(lines):
        m = CASE_RE.match(ln)
        if m:
            cur = int(m.group(1))
        out.append(ln)
        if JING_RE.match(ln):
            nxt = lines[i + 1] if i + 1 < len(lines) else ""
            if TUPO_RE.match(nxt):
                continue  # 已存在，幂等跳过
            if cur in bt:
                out.append(f"- **案件突破口【提炼】**：{bt[cur]}")
                inserted += 1
            else:
                print(f"[WARN] 案件 {cur} 在 bt.json 中无对应文本，跳过")

    # 顶部说明行（仅一次，插在「标注图例」行之后）
    new_out, added_note = [], False
    for ln in out:
        new_out.append(ln)
        if (not added_note) and ("标注图例" in ln):
            new_out.append(NOTE_TEXT)
            added_note = True

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(new_out) + "\n")

    total = sum(1 for l in new_out if TUPO_RE.match(l))
    print(f"插入 {inserted} 条；文件内总计 {total} 条；顶部说明{'已加' if added_note else '未加'} -> {out_path}")


if __name__ == "__main__":
    main()
