# -*- coding: utf-8 -*-
"""
merge_obsidian_fragments.py —— 把「案件与主线全梳理」文档 + 微信读书碎片，合并成 Obsidian 主笔记，并更新 MOC、归档碎片。

用法：
  python3 merge_obsidian_fragments.py \
      --vault "<读书笔记目录>" \
      --master "书名" \
      --source "<梳理文档.md>" \
      --moc "读书笔记.md" \
      --fragments "碎片1.md 碎片2.md ..." \
      --related "相关笔记A 相关笔记B ..." \
      [--moc-anchor "在某笔记后插入主笔记链接"] \
      [--dry-run]

行为：
  - 主笔记：解码 source（html.unescape）→ 去重 frontmatter/H1 → 拼 frontmatter + MOC 回链 + 单 H1 + 正文 + 划线摘录（按章归并去重）+ 相关笔记段。
  - 划线去重键：^CB-[A-Za-z0-9\-]+（首 - 截断会塌缩同书多条，已修正）。
  - 碎片移入 <vault>/_archive/（可逆，不硬删）。
  - MOC：移除碎片条目、插入单条 [[主笔记]]、顺序重编，保留 ## 段不动。
  - 编辑前留整库时间戳备份 + MOC 时间戳备份。
  - 默认执行；--dry-run 只打印计划不落盘。
"""
import re, shutil, os, html, argparse
from datetime import datetime


HL_RE = re.compile(r'^>\s*📌\s*(.*)$')
TS_RE = re.compile(r'^>\s*⏱\s*(.*?)(\^CB-[A-Za-z0-9\-]+)?\s*$')
CHAP_RE = re.compile(r'^#{2,3}\s*第[一二三四五六七八九十百零\d]+\s*章')
BLOCKREF_RE = re.compile(r'\^CB-[A-Za-z0-9\-]+')

LIST_RE = re.compile(r'^(\d+)\.\[\[(.*)\]\]\s*$')


def strip_frontmatter_and_h1(text):
    lines = text.split("\n")
    # 去掉 YAML frontmatter
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                lines = lines[i + 1:]
                break
    # 去掉所有 H1
    lines = [l for l in lines if not re.match(r'^#\s+\S', l)]
    return "\n".join(lines).strip()


def extract_highlights(frag_path):
    """返回 [(chapter, text, timestamp, blockref), ...]"""
    with open(frag_path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    chapter = "未分章"
    hits = []
    buf_hl = None
    for ln in lines:
        if CHAP_RE.match(ln):
            chapter = ln.lstrip("# ").strip()
            continue
        mh = HL_RE.match(ln)
        if mh:
            buf_hl = (chapter, mh.group(1).strip())
            continue
        if buf_hl is not None:
            mt = TS_RE.match(ln)
            if mt:
                ts = mt.group(1).strip()
                br = mt.group(2) or BLOCKREF_RE.search(ln)
                br = br if isinstance(br, str) else (br.group(0) if br else "")
                hits.append((buf_hl[0], buf_hl[1], ts, br))
                buf_hl = None
            else:
                # 没有时间戳行，仍记录（无 blockref）
                hits.append((buf_hl[0], buf_hl[1], "", ""))
                buf_hl = None
    return hits


def group_highlights(all_hits):
    groups = {}  # chapter -> list of (text, ts, br)
    seen = set()
    order = []
    for ch, text, ts, br in all_hits:
        key = br if br else ("TXT::" + text)
        if key in seen:
            continue
        seen.add(key)
        groups.setdefault(ch, []).append((text, ts, br))
        if ch not in order:
            order.append(ch)
    return groups, order


def build_highlight_section(groups, order):
    if not order:
        return ""
    out = ["", "## 划线摘录（微信读书）",
           f"> 合并自微信读书导入笔记，按章节归并，去重后共 {sum(len(v) for v in groups.values())} 条。"]
    for ch in order:
        out.append(f"### {ch}")
        for text, ts, br in groups[ch]:
            out.append(f"> 📌 {text}")
            if ts or br:
                line = f"> ⏱ {ts}" + (f" {br}" if br else "")
                out.append(line)
        out.append("")
    return "\n".join(out)


def update_moc(moc_path, remove_names, master, anchor):
    with open(moc_path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    first_list = first_tail = None
    for idx, ln in enumerate(lines):
        if first_list is None and LIST_RE.match(ln):
            first_list = idx
        if first_list is not None and first_tail is None and re.match(r'^##\s', ln):
            first_tail = idx
            break
    assert first_list is not None and first_tail is not None, "MOC 区域识别失败"
    head = lines[:first_list]
    body_raw = lines[first_list:first_tail]
    tail = lines[first_tail:]

    entries = []
    for ln in body_raw:
        m = LIST_RE.match(ln)
        if m:
            entries.append((int(m.group(1)), m.group(2).strip()))

    kept = [inner for (_, inner) in entries if inner not in remove_names]
    removed = [inner for (_, inner) in entries if inner in remove_names]

    out_inner = []
    inserted = False
    ins_idx = None
    for i, inner in enumerate(kept):
        out_inner.append(inner)
        if anchor and inner == anchor and not inserted:
            out_inner.append(master)
            inserted = True
            ins_idx = i + 1
    if not inserted:
        # 插入到首个被移除条目原位置，否则尾附
        if removed:
            out_inner.insert(0, master)  # 兜底：放最前（agent 一般传 anchor）
        else:
            out_inner.append(master)

    new_body = [f"{i+1}.[[{inner}]]" for i, inner in enumerate(out_inner)]

    def trim(seq):
        while seq and seq[-1].strip() == "":
            seq.pop()
        while seq and seq[0].strip() == "":
            seq.pop(0)
        return seq
    head = trim(head); tail = trim(tail); new_body = trim(new_body)
    result = head + [""] + new_body + [""] + tail
    return "\n".join(result) + "\n", removed, len(new_body)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vault", required=True)
    ap.add_argument("--master", required=True, help="主笔记文件名（不含 .md）")
    ap.add_argument("--source", required=True)
    ap.add_argument("--moc", default="读书笔记.md")
    ap.add_argument("--fragments", default="", help="空格分隔的碎片文件名")
    ap.add_argument("--related", default="", help="空格分隔的相关笔记名")
    ap.add_argument("--moc-anchor", default="", help="在哪个笔记后插入主笔记链接")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    vault = args.vault
    master_file = os.path.join(vault, args.master + ".md")
    moc_path = os.path.join(vault, args.moc)
    frag_names = args.fragments.split() if args.fragments.strip() else []
    related = args.related.split() if args.related.strip() else []

    # 1) 解码 source
    with open(args.source, encoding="utf-8") as f:
        src = html.unescape(f.read())
    body = strip_frontmatter_and_h1(src)

    # 2) 抽划线
    all_hits = []
    for fn in frag_names:
        fp = os.path.join(vault, fn)
        if os.path.exists(fp):
            all_hits.extend(extract_highlights(fp))
        else:
            print(f"[WARN] 碎片不存在：{fp}")
    groups, order = group_highlights(all_hits)
    hl_section = build_highlight_section(groups, order)
    n_hl = sum(len(v) for v in groups.values())

    # 3) 组装主笔记
    fm = ("---\n"
          "domain: 阅读\n"
          "type: 读书笔记\n"
          f"author: 未知\n"
          "tags:\n  - 摘抄\n  - 网文\n---\n\n"
          f"[[读书笔记|← 读书笔记索引]]\n\n# 《{args.master}》\n\n")
    related_section = ""
    if related:
        related_section = ("\n---\n\n## 相关笔记\n\n"
                           "- 同背景延展阅读：" + "、".join(f"[[{r}]]" for r in related) + "\n"
                           "- 索引回链：[[读书笔记|← 读书笔记索引]]（见文首）\n")
    master_text = fm + body + hl_section + related_section

    # 4) MOC 计划
    remove_names = [os.path.splitext(fn)[0] for fn in frag_names]
    moc_new, removed, new_total = update_moc(moc_path, set(remove_names), args.master, args.moc_anchor)

    # 打印计划
    print("==== 计划 / 结果 ====")
    print(f"主笔记：{master_file}")
    print(f"  正文长度 {len(body)} 字符；划线 {n_hl} 条（来自 {len(frag_names)} 个碎片）")
    print(f"  相关笔记互链：{related}")
    print(f"MOC：移除 {removed}；主笔记将插入；新条目总数 {new_total}")
    print(f"碎片将归档至：{os.path.join(vault, '_archive')}/")
    if args.dry_run:
        print("[DRY-RUN] 未落盘。")
        return

    # 5) 备份
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    shutil.copy2(moc_path, os.path.join(vault, "..", f"读书笔记.moc-{ts}.bak"))
    bak_vault = os.path.join(vault, "..", f"读书笔记.bak-{ts}")
    if not os.path.exists(bak_vault):
        shutil.copytree(vault, bak_vault)
        print(f"整库备份 -> {bak_vault}")

    # 6) 写主笔记
    with open(master_file, "w", encoding="utf-8") as f:
        f.write(master_text + "\n")

    # 7) 归档碎片
    arch = os.path.join(vault, "_archive")
    os.makedirs(arch, exist_ok=True)
    for fn in frag_names:
        fp = os.path.join(vault, fn)
        if os.path.exists(fp):
            shutil.move(fp, os.path.join(arch, fn))
            print(f"归档 -> {os.path.join(arch, fn)}")

    # 8) 写 MOC
    with open(moc_path, "w", encoding="utf-8") as f:
        f.write(moc_new)

    print("完成。主笔记 + MOC 已更新，碎片已归档。")


if __name__ == "__main__":
    main()
