# 基础校验：命名空间、基类、必要 using
import sys, re

REQUIRED_USING = [r"using Kingdee\.BOS;"]
PLUGIN_NAMESPACES = [
    r"using Kingdee\.BOS\.Core\.DynamicForm\.PlugIn;",
    r"using Kingdee\.BOS\.Core\.ConvertPlugIn;",
    r"using Kingdee\.BOS\.WebApi\.ServicesStub;",
]
BASE_CLASSES = ["AbstractFormPlugin", "AbstractOperationServicePlugIn", "AbstractConvertPlugIn", "AbstractWebApiBusinessService"]

def validate(path):
    code = open(path, encoding="utf-8").read()
    issues = []
    for u in REQUIRED_USING:
        if not re.search(u, code):
            issues.append(f"缺少基础命名空间: {u}")
    if not any(re.search(ns, code) for ns in PLUGIN_NAMESPACES):
        issues.append("缺少插件命名空间(需 DynamicForm.PlugIn / ConvertPlugIn / WebApi.ServicesStub 之一)")
    if not any(re.search(r"public class [A-Za-z0-9_{}]+ : " + bc, code) for bc in BASE_CLASSES):
        issues.append("未找到合法的金蝶插件基类继承")
    if issues:
        print("FAIL"); [print(" -", i) for i in issues]; return 1
    print("OK"); return 0

if __name__ == "__main__":
    sys.exit(validate(sys.argv[1]) if len(sys.argv) > 1 else (print("usage: validate_plugin.py <file>") or 2))
