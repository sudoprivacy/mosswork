# 二开常见报错字典

## 插件未注册 / 找不到插件
- 现象：执行时报“未找到插件类型”或功能无反应。
- 原因：DLL 未注册到 BOS、或 app.config 节点缺失、或 IIS 未重启。
- 解决：在 BOS 注册插件并重启 IIS；确认 DLL 已部署到站点 bin 目录。

## 找不到类型/方法 (TypeLoadException)
- 现象：运行时报找不到类或方法。
- 原因：金蝶版本差异导致基类/方法名不同，或引用了不存在的程序集。
- 解决：按用户金蝶版本核对 references/api-reference.md 的基类与方法。

## 事务中不允许查询
- 现象：表单/服务插件中执行查询报此错。
- 原因：在事务上下文里调用了查询。
- 解决：查询放到 OnPreparePropertys/事务外；写库用 DBUtils 且在 BeginOperationTransaction 内。

## 单据已被其他用户锁定
- 现象：保存/审核报锁定。
- 原因：他人并发编辑未退出。
- 解决：联系锁定人保存退出；管理员在【系统管理→会话管理】强制解锁。

## 字段不存在 (FieldNotFound)
- 现象：GetValue/SetValue 报字段不存在。
- 原因：字段标识(FField)拼写错或未在单据上添加。
- 解决：核对元数据字段标识；服务插件需在 OnPreparePropertys 声明加载。
