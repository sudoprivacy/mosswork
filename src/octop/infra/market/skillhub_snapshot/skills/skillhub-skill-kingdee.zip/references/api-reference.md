# 金蝶云星空 BOS 二次开发 API 参考

## 常用命名空间
- Kingdee.BOS — 基础（Context、JSONObject）
- Kingdee.BOS.Core / Kingdee.BOS.Core.DynamicForm.PlugIn — 表单/服务插件
- Kingdee.BOS.Core.ConvertPlugIn — 单据转换插件
- Kingdee.BOS.Orm.DataEntity — DynamicObject 实体
- Kingdee.BOS.App.Data — DBUtils（事务内写库）
- Kingdee.BOS.ServiceHelper — BillServiceHelper、ViewService 等

## 插件基类与关键方法
### 表单插件 AbstractFormPlugin
- OnLoad / AfterBindData — 初始化、设默认值、锁字段
- BarItemClick(BarItemClickEventArgs) — 工具栏按钮，e.BarItemKey
- ButtonClick(ButtonClickEventArgs) — 表单按钮，e.Key
- DataChanged(DataChangedEventArgs) — 值更新，e.Field.Key / e.Row
- BeforeSave / AfterSave — 校验(e.Cancel=true 可拦截)

### 服务插件 AbstractOperationServicePlugIn
- OnPreparePropertys(PreparePropertysEventArgs) — e.FieldKeys.Add("字段") 声明需加载字段
- BeforeExecuteOperationTransaction / BeginOperationTransaction / EndOperationTransaction — 事务内处理，e.DataEntitys

### 取数/写数
- this.Model.GetValue("FField", row) / SetValue("FField", val, row)
- DBUtils.Execute(Context, sql, SqlParam[]) — 仅服务插件事务内使用
- BillServiceHelper.Save(Context, DynamicObject[]) — 服务端保存

## WebAPI 自定义服务（二开接口）
- 基类：Kingdee.BOS.WebApi.ServicesStub.AbstractWebApiBusinessService（需引用 Kingdee.BOS.WebApi.dll）。
- 公开方法即成为 HTTP 端点，调用地址形如：
  `http://<server>/K3Cloud/Kingdee.BOS.WebApi.ServicesStub.<ClassName>,<DllName>.apis/<MethodName>`
- 方法体内通过 `this.Context` 访问已登录上下文；写库同样用 DBUtils。
- ⚠️ 构造函数签名、路由注册方式随金蝶版本不同，请以官方 SDK / 你环境引用的 Kingdee.BOS.WebApi.dll 为准。
- 另一种常见「WebAPI 二开」是从外部系统调用金蝶标准接口（Login/Save/Submit/Audit/View/ExecuteBillQuery/Push），封装在独立客户端，不属于本服务基类范畴。

## BOS 元数据字段规格
- 字段标识（fkey）须以 `F_` 开头，建议 `F_<公司缩写>_<含义>`，如 `F_QT_Remark`。
- 常见 dataType：Text / Int / Decimal(precision) / Bool / Date / BaseData(linkForm 指定关联表单 FormId) / ComboEdit(options 枚举) / MultiLangText。
- bindEntity：表头一般用 `FBillHead`，明细用 `FEntity`（或自定义子单据体标识）。
- 该 JSON 为设计期规格模板（assets/bos-metadata-field-template.json），用于在 BOS 集成开发平台逐字段配置，或作为生成元数据的输入；字段取值以所用金蝶版本的 BOS 为准。

## 注册要点
- 插件（表单/服务/转换/WebApi 服务）：在 BOS 集成开发平台「编辑→批量编辑」注册 DLL；或修改站点 app.config 的 <plugin> 节点；重启 IIS 生效。
- 元数据字段：在 BOS 设计器对单据/基础资料「编辑→批量编辑字段」按规格添加，保存后刷新缓存。
