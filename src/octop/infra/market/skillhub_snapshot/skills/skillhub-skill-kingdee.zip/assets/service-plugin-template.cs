// 金蝶云星空 服务插件模板（继承 AbstractOperationServicePlugIn）
using Kingdee.BOS;
using Kingdee.BOS.Core.DynamicForm.PlugIn;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.Orm.DataEntity;
using Kingdee.BOS.App.Data;

namespace {{Namespace}}.PlugIn.{{Module}}
{
    public class {{ClassName}} : AbstractOperationServicePlugIn
    {
        public override void OnPreparePropertys(PreparePropertysEventArgs e)
        {
            base.OnPreparePropertys(e);
            e.FieldKeys.Add("{{FieldKey}}"); // 声明需加载字段
        }
        public override void BeginOperationTransaction(BeginOperationTransaction e)
        {
            base.BeginOperationTransaction(e);
            foreach (DynamicObject data in e.DataEntitys)
            {
                // ⚠️ 事务内写库必须用 DBUtils
                // DBUtils.Execute(this.Context, sql, new SqlParam[]{ ... });
            }
        }
        public override void EndOperationTransaction(EndOperationTransaction e)
        {
            base.EndOperationTransaction(e);
        }
    }
}
