// 金蝶云星空 表单插件模板（继承 AbstractFormPlugin）
using Kingdee.BOS;
using Kingdee.BOS.Core;
using Kingdee.BOS.Core.DynamicForm.PlugIn;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.Orm.DataEntity;

namespace {{Namespace}}.PlugIn.{{Module}}
{
    public class {{ClassName}} : AbstractFormPlugin
    {
        public override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            // 初始化：锁定字段、设默认值
        }
        public override void BarItemClick(BarItemClickEventArgs e)
        {
            if (e.BarItemKey.Equals("{{BarItemKey}}", System.StringComparison.OrdinalIgnoreCase))
            {
                var val = this.Model.GetValue("{{FieldKey}}", this.Model.GetEntryCurrentRowIndex("{{EntryKey}}"));
            }
            base.BarItemClick(e);
        }
        public override void DataChanged(DataChangedEventArgs e)
        {
            if (e.Field.Key.Equals("{{FieldKey}}", System.StringComparison.OrdinalIgnoreCase))
            {
                // 值更新联动
            }
            base.DataChanged(e);
        }
        public override void BeforeSave(EventArgs e)
        {
            // 校验；e.Cancel = true 可拦截保存
        }
    }
}
