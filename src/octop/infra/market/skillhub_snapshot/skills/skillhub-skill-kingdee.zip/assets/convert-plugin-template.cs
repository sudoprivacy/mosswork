// 金蝶云星空 单据转换插件模板（继承 AbstractConvertPlugIn）
using Kingdee.BOS;
using Kingdee.BOS.Core.ConvertPlugIn;
using Kingdee.BOS.Core.ConvertPlugIn.Args;
using Kingdee.BOS.Orm.DataEntity;

namespace {{Namespace}}.PlugIn.{{Module}}
{
    public class {{ClassName}} : AbstractConvertPlugIn
    {
        public override void OnAfterCreateLink(CreateLinkEventArgs e)
        {
            base.OnAfterCreateLink(e);
            // 下推生成目标单后补充字段映射
        }
    }
}
