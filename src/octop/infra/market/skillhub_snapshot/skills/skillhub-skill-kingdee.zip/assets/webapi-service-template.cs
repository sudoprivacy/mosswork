// 金蝶云星空 自定义 WebAPI 服务模板（继承 AbstractWebApiBusinessService）
// 用途：在 K3 Cloud 站点中暴露一个可被 HTTP 调用的二开接口。
// 调用地址示例：
//   http://<server>/K3Cloud/Kingdee.BOS.WebApi.ServicesStub.{{ClassName}},{{DllName}}.apis/{{MethodName}}
using Kingdee.BOS;
using Kingdee.BOS.WebApi.ServicesStub;

namespace {{Namespace}}.WebApi
{
    public class {{ClassName}} : AbstractWebApiBusinessService
    {
        // ⚠️ 构造函数签名随金蝶版本可能不同，请以官方 SDK / 你环境引用的 Kingdee.BOS.WebApi.dll 为准。
        public {{ClassName}}(IServiceProvider provider) : base(provider) { }

        /// <summary>
        /// 示例方法：返回当前登录组织等信息。
        /// this.Context 已是登录后的上下文；如需鉴权请在此校验。
        /// </summary>
        public string {{MethodName}}()
        {
            var ctx = this.Context;
            // TODO: 业务逻辑，例如调用 BillServiceHelper / DBUtils
            return "ok";
        }
    }
}
