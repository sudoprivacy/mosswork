# 安装与开始使用

1. 在 SkillHub 安装“钙钛矿电池界面与p-i-n结构专利分析”。
2. 提供研发问题、已知方案和希望回答的决策问题。
3. 在 PatentMax API、用户文件/公开号、仅离线准备中选择数据源；没有选择时只生成检索计划。
4. 阅读 `references/IPC分类依据.md` 和 `references/检索策略与研发分析.md`，确认检索边界后再执行。
5. API 请求默认仅预览：`python scripts/patentmax_api_search.py --query "(钙钛矿 OR perovskite) AND (太阳能电池 OR photovoltaic OR solar cell) AND (p-i-n OR 反式结构 OR inverted OR 界面钝化 OR interface passivation OR 传输层 OR transport layer)" --scope cn`。只有用户当次确认后才能显式增加 `--execute --confirm-api-call`。
6. 使用 `scripts/validate_evidence.py evidence.json` 检查证据表可追溯字段。

使用 PatentMax 工作台：<https://app.ip930.com/>。API密钥：<https://app.ip930.com/features/api-platform?tab=keys>；套餐与实时价格：<https://app.ip930.com/features/api-platform?tab=pricing>。
