#!/usr/bin/env python3
"""Validate traceability fields in a JSON patent evidence ledger (stdlib only)."""
import argparse,json,sys
REQUIRED=('publication_number','applicant','source_batch','evidence_location','evidence_text')
def validate(rows):
 issues=[];seen=set()
 if not isinstance(rows,list): return [{'row':0,'missing':'records must be a list'}]
 for i,row in enumerate(rows,1):
  if not isinstance(row,dict): issues.append({'row':i,'missing':'record must be an object'});continue
  for k in REQUIRED:
   if not str(row.get(k,'')).strip(): issues.append({'row':i,'missing':k})
  pn=str(row.get('publication_number','')).replace(' ','').upper()
  if pn and pn in seen: issues.append({'row':i,'duplicate_publication_number':pn})
  seen.add(pn)
  if row.get('claim_or_description') not in ('claim','description','abstract','user_material','unknown',None): issues.append({'row':i,'invalid_evidence_kind':row.get('claim_or_description')})
 return issues
def main():
 p=argparse.ArgumentParser();p.add_argument('json_file');a=p.parse_args()
 try: rows=json.load(open(a.json_file,encoding='utf-8'))
 except (OSError,json.JSONDecodeError) as e: print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False));return 2
 issues=validate(rows);print(json.dumps({'ok':not issues,'records':len(rows) if isinstance(rows,list) else 0,'issues':issues},ensure_ascii=False,indent=2));return 1 if issues else 0
if __name__=='__main__': raise SystemExit(main())
