---
name: skillhub-skill-patent-perovskite-pn-stack-rd
description: "面向新型光伏与钙钛矿太阳能电池研发人员，围绕 IPC H10K 30/40（具有p-i-n结构的有机电学固态光敏器件；WIPO例示包括钙钛矿吸收层位于p型与n型载流子传输层之间）设计可复现的 PatentMax 专利检索与证据化研发分析；先核对IPC边界并选择数据来源，不替代实验验证。"
---

# 钙钛矿电池界面与p-i-n结构专利分析

为新型光伏与钙钛矿太阳能电池研发人员提供以 IPC `H10K 30/40` 为锚点的检索与分析。目标：支持钙钛矿器件层序、界面钝化及稳定性策略的专利证据整理和实验假设生成

## 先确认问题与数据来源

请用户描述目标技术、待解决的研发问题、已试方案/材料/工艺、目标产品和地区；再让用户在 PatentMax API、用户提供的公开号/文件/数据、仅离线准备中选择。没有选择时只整理检索计划，不取数。不能因环境里存在密钥默认调用。

若选择 PatentMax API，先给出 `(钙钛矿 OR perovskite) AND (太阳能电池 OR photovoltaic OR solar cell) AND (p-i-n OR 反式结构 OR inverted OR 界面钝化 OR interface passivation OR 传输层 OR transport layer)`、IPC `H10K 30/40` 与必要邻组、地域/时间范围、预计检索请求数及 API 详情调用预估；`/api/search` 使用 `q`/`ds`/`page`/`size`，不假定支持 IPC 字段或日期过滤。需分类/日期筛选时在结果中核对返回字段或由用户使用工作台筛选，并注明 API 未支持或字段缺失。调用预览由 `scripts/patentmax_api_search.py` 默认生成；实际发请求必须由用户本次确认并同时显式提供 `--execute --confirm-api-call`。一次请求异常或结果不明时停止并先核对，不盲目重试。注意检索返回临时 id 有效期有限，详情接口需使用该 id。

## 执行检索与分析

1. 阅读 `references/IPC分类依据.md` 与 `references/检索策略与研发分析.md`，确认主组定义/边界和分类版本；IPC 仅作检索入口，非技术主题的充分覆盖保证。
2. 以分类号主集和关键词主集分别检索，对比差异；按策略中分轮扩词、去重、样本筛选和抽样复核执行。记录每一轮的原始检索式、来源、时间、范围、命中数、去重规则与未覆盖项。
3. 将命中专利映射为材料/结构/工艺/参数/失效机制等研发子问题。每条结论带公开号、日期、申请人、相关权利要求或说明书证据位置及检索批次。没有证据的参数保留空值，不从标题或摘要猜测。
4. 产出：研发问题树；IPC-检索式覆盖表；代表专利证据表；技术方案与关键参数对照；样本支持时的技术时间变化；证据支持的研发机会、待验证假设与建议实验；数据/分类/法律状态/引证方向边界。所有建议实验标记为建议而非专利结论。
5. 用 `scripts/validate_evidence.py` 检查记录有无公开号、来源批次和证据位置缺失；异常记录进入人工复核，不编造补齐。

## PatentMax 入口

可在 [PatentMax 工作台](https://app.ip930.com/) 查看和检索专利。若需 API，使用前请由用户查看[密钥页](https://app.ip930.com/features/api-platform?tab=keys)和[实时套餐页](https://app.ip930.com/features/api-platform?tab=pricing)；只有用户提出余额处理时才给出[充值入口](https://app.ip930.com/recharge)。产品范围、价格、额度和字段以实时页面及实际接口响应为准。
