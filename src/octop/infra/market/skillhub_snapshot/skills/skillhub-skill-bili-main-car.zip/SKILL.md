---
name: skillhub-skill-bili-main-car
description: "当用户想按 B 站「汽车」分区定位子分区、查找该领域的上榜视频或核对创作者与 BV 号时使用。本包只提供分区结构与榜单元数据，不提供视频口播内容。触发词：汽车、B站分区、rid 223。"
---

# B 站分区 · 汽车

- 一级分区 rid：`223`；网页路由：`/v/car/`
- 采集时间：2026-11-06T16:23:32+08:00
- 状态：本分区在采集时返回 94 条榜单条目，覆盖 7 个现行子分区。

## 现行子分区路由

| 子分区（接口 tname） | 主榜条目 | 二级榜条目 | 文档 tid |
| --- | --- | --- | --- |
| 房车 | 5 | 3 | 248 |
| 摩托车 | 2 | 9 | 240 |
| 改装玩车 | 7 | 6 | 246 |
| 新能源车 | 27 | 10 | 247 |
| 汽车生活 | 41 | 10 | 176 |
| 购车攻略 | 7 | 10 | 227 |
| 赛车 | 5 | 10 | 245 |

## 用法

1. 用户的问题落到某个子分区时，先在下表定位该子分区，再按 BV 号打开原视频核实。
2. 需要别的分区时，转总控 skill `bili-full-map` 查全站路由。
3. 需要视频里的具体讲解、论证或方法时，本包给不了，转 `video-distill` 取字幕或转写。

## 榜单快照（按子分区分组，每区 Top 5）

每个子分区优先使用其独立 7 日榜（内容更均衡）；未取到时退回主分区排行榜。两者均为公开接口的采集时刻快照。

### 房车

数据来源：二级分区 7 日榜，可用 3 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 你看不见我，我家的门窗很社恐 | 码叔数码 | [BV1QbdHYZEik](https://www.bilibili.com/video/BV1QbdHYZEik) | 269.5 万 |
| 自带车库的房车，玩两年赔的就剩零头了，楼顶有高尔夫球场，车尾还有车库 | 957讲二手房车 | [BV1ZPRCYhEar](https://www.bilibili.com/video/BV1ZPRCYhEar) | 36.3 万 |
| 房车里有几张床？能睡几个人？ | 娜娜房车里 | [BV1kyRoYrEnw](https://www.bilibili.com/video/BV1kyRoYrEnw) | 24.8 万 |

### 摩托车

数据来源：二级分区 7 日榜，可用 9 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 丙测评 \| 张雪500RR 大概率又是全网最详尽的测评 | 小丙摩托车评中心 | [BV1eTZUY1Eu8](https://www.bilibili.com/video/BV1eTZUY1Eu8) | 124.1 万 |
| 我们男人不是不愿意洗东西 | 骑不快的H | [BV1vqZ9Y8EqD](https://www.bilibili.com/video/BV1vqZ9Y8EqD) | 230.7 万 |
| 史上最帅的摩托车 | 猪坚强jqsg999 | [BV17cZUYSEBZ](https://www.bilibili.com/video/BV17cZUYSEBZ) | 37.6 万 |
| 高端的猎手往往以猎物出现，男孩子们注意安全#机车 #450sr #搭讪 #vlog日常 | 脉动有点慢 | [BV1RyZZY3Ec3](https://www.bilibili.com/video/BV1RyZZY3Ec3) | 268.5 万 |
| 东京摩托车展2025【英文中字 Part 1】｜本田、雅马哈、川崎、铃木、Bimota｜今年东京摩展油管播放量最高的视频就是它！中国女骑YYDS🔥 | 在东京骑车的Rena | [BV1V5ZDYUEMQ](https://www.bilibili.com/video/BV1V5ZDYUEMQ) | 10.1 万 |

### 改装玩车

数据来源：二级分区 7 日榜，可用 6 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 我把变形金刚开回了家… | JakeToys | [BV1exZmYCEw8](https://www.bilibili.com/video/BV1exZmYCEw8) | 14.6 万 |
| 几千块能开能跑！大学生玩车价格地花板！马自达323 | 老薯的薯 | [BV1WsdpYnE7A](https://www.bilibili.com/video/BV1WsdpYnE7A) | 31.3 万 |
| 10万元的C63跑的快吗？V8 6.2排量都好便宜了！【贴地飞行-穷三代】 | 贴地飞行-三代 | [BV146ZmYPEjo](https://www.bilibili.com/video/BV146ZmYPEjo) | 11.4 万 |
| 2000卢比的丰田霸道是如何进口到巴基斯坦的 | 发光的三极管yoyo | [BV1YwR2Y8EzT](https://www.bilibili.com/video/BV1YwR2Y8EzT) | 36.0 万 |
| 理想mega花五位数升级 | 博哥玩理想 | [BV1UoZ2YYEmX](https://www.bilibili.com/video/BV1UoZ2YYEmX) | 12.3 万 |

### 新能源车

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 中国骄傲！浅谈仰望U7背后的黑科技！ | 所长Wy | [BV1oLdHYqEBa](https://www.bilibili.com/video/BV1oLdHYqEBa) | 164.1 万 |
| 新能源专用轮胎：长续航的代价是什么？ | 小敖不小了 | [BV1a3dpYFEtU](https://www.bilibili.com/video/BV1a3dpYFEtU) | 89.8 万 |
| 吉利银河之新能源最好的设计！ | 安阳红旗渠机场 | [BV15YRkYXESu](https://www.bilibili.com/video/BV15YRkYXESu) | 105.7 万 |
| 小奶龙变成西蒙竟然被布莱德吃了 | 财财蛋 | [BV1quRRYoEs5](https://www.bilibili.com/video/BV1quRRYoEs5) | 157.3 万 |
| 假如评测博主说真话，两小时全程高能 | 先看评测 | [BV11GZ9Y2EzN](https://www.bilibili.com/video/BV11GZ9Y2EzN) | 71.3 万 |

### 汽车生活

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 世界上卖的最好的车，就这？ | 极速拍档 | [BV1ckZDY8EPN](https://www.bilibili.com/video/BV1ckZDY8EPN) | 176.1 万 |
| 购入奕派008大半年，我后悔了吗 | 小敖不小了 | [BV1PPfMYJEiY](https://www.bilibili.com/video/BV1PPfMYJEiY) | 78.0 万 |
| 炸裂！这车也能上路？我坐进了保罗沃克的车里！ | Upspeed盛嘉成 | [BV15AZ2Y6EMH](https://www.bilibili.com/video/BV15AZ2Y6EMH) | 101.4 万 |
| 【重生计划】02价值两万的奥迪修到崩溃！！！ | 易土辉 | [BV1r3Z1YLEM8](https://www.bilibili.com/video/BV1r3Z1YLEM8) | 97.0 万 |
| “这应该是400w以内回头率最高的车了吧！” | 小商的拍车日记 | [BV1XhZmYgEYF](https://www.bilibili.com/video/BV1XhZmYgEYF) | 87.1 万 |

### 购车攻略

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| 【大虾沉浸式试车】20.98—25.98万！汉L DM👉快来快来～带你沉浸式体验！ | 大虾试车真香 | [BV1YKdpYYEAP](https://www.bilibili.com/video/BV1YKdpYYEAP) | 82.6 万 |
| 汉L DM/EV保姆级导购教程 | 懂车兄阿森 | [BV1MgdTY1E3K](https://www.bilibili.com/video/BV1MgdTY1E3K) | 67.7 万 |
| 第一视角 全新大众ID.3提车 好看 好开 行驶品质非常出色的一辆代步电车 价格也实惠 | 宽面车神 | [BV1D7RXYCEFK](https://www.bilibili.com/video/BV1D7RXYCEFK) | 146.9 万 |
| 百万奔驰，一折拿下！奔驰AMG C63 | 有车有肉的肉肉 | [BV1bMR2YxEC9](https://www.bilibili.com/video/BV1bMR2YxEC9) | 18.3 万 |
| 奥迪Q5L，抄底还是陷阱？ | 百车全说 | [BV17YR2YuEN9](https://www.bilibili.com/video/BV17YR2YuEN9) | 13.6 万 |

### 赛车

数据来源：二级分区 7 日榜，可用 10 条，下表展示前 5 条。

| 标题 | UP 主 | BV 号 | 播放 |
| --- | --- | --- | --- |
| “基里安布朗来了都蹬不过他们啊” | 尽墨for车 | [BV19mZ2YzE3Y](https://www.bilibili.com/video/BV19mZ2YzE3Y) | 58.4 万 |
| 【F1日本战报】正赛 \| 毫无波澜 但有大师级的控场 \| 安东内利打破多项记录：下班之后还要去学习，我要努力读完高三 | F1赛事资讯 | [BV1a2RqYBEvn](https://www.bilibili.com/video/BV1a2RqYBEvn) | 25.3 万 |
| 哪辆车能跳过进击的巨人 | 汽车模拟测试 | [BV1veZQY9EVK](https://www.bilibili.com/video/BV1veZQY9EVK) | 19.8 万 |
| 村长F1\|重返天籁之音！V10引擎可能回归F1吗？ | 村长托马斯 | [BV12dZyYxE6P](https://www.bilibili.com/video/BV12dZyYxE6P) | 28.4 万 |
| 铃鹿这一圈☝️无需多言【2025赛季F1日本大奖赛杆位圈车载】 | F1世界锦标赛 | [BV196RdYsE3Z](https://www.bilibili.com/video/BV196RdYsE3Z) | 31.6 万 |

## 名称差异与覆盖说明

- 分区表列出但本次榜单未返回条目：汽车知识科普（不代表分区不存在）。
- 本包以接口 `tname` 为准，不改写、不合并名称。

## 数据边界

1. 公开接口只返回元数据，不含视频口播、字幕或章节大纲。
2. 榜单为采集时刻快照，名次与播放量持续变化，不构成质量评价。
3. 引用任何视频时须给出 BV 号链接与采集日期。
4. 回答时区分「快照中已核实的事实」「现场检索到的网页内容」「模型通用知识」，不得把第三类表述为来自 B 站视频。

## 引用（MLA）

"视频分区一览." *Bilibili API 收集*, https://sessionhu.github.io/bilibili-API-collect/docs/video/video_zone.html. Accessed 6 Nov. 2026.

Bilibili. "排行榜接口 /x/web-interface/ranking/v2, rid=223." https://api.bilibili.com/x/web-interface/ranking/v2?rid=223&type=all. Accessed 6 Nov. 2026.
