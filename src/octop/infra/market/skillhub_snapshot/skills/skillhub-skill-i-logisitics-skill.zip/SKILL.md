---
name: skillhub-skill-i-logisitics-skill
description: "京东国际物流数据查询技能"
---

# joy-logistics-skill — 国际物流 Skills 全集

Complete collection of multi Logistics skills for OpenClaw agents.

## Included Skills

| Skill | Category | Description |
|-------|----------|-------------|
| joy-logistics-trace | logistics-trace-query | 国际物流轨迹明细查询 |
| joy-logistics-indicator | indicators-query | 国际供应链、跨境小包相关指标查询 |

## Documentation

See `README.md` for the complete setup guide (in Chinese).