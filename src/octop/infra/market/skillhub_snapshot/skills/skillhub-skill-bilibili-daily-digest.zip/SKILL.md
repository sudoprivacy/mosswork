---
name: skillhub-skill-bilibili-daily-digest
description: "B站每日摘要。抓取B站热门视频和关键词最新内容，提取字幕转写并生成结构化摘要卡片，站内推送。触发词：B站每日摘要、B站日报、看看B站今天有什么、B站热门汇总、今日B站、B站订阅更新、B站最新视频。"
---

# B站每日摘要（中文版）

按你关心的频道或关键词，每天自动拉取B站最新视频，提取字幕转写，生成结构化摘要卡片，站内推送。

## 依赖技能

本技能依赖以下已安装的 Skill：
- `bilibili-universal` — 抓取热门视频、关键词搜索、UP主更新
- `bilibili-video-summary`（bili-summary）— 视频字幕转写与摘要提取

请先安装这两个技能：
```bash
npx clawhub@latest install bilibili-universal
npx clawhub@latest install bilibili-video-summary
```

## 快速开始

### 模式一：热门视频日报

```text
帮我生成今天的B站热门视频摘要，抓最近24小时的热门视频，每个视频提取字幕并生成要点摘要。
```

### 模式二：关注UP主更新

```text
追踪这些B站UP主的最新视频：
- 老师好我叫何同学
- 影视飓风
- 某位UP主

每天拉取他们最近发布的视频，生成摘要发给我。
```

### 模式三：关键词监控

```text
每天搜索B站关于"AI Agent"的最新视频，提取字幕生成摘要，只展示播放量超过1万的内容。
```

## 执行流程

### 第一步：环境检查

运行环境检查脚本：
```bash
python scripts/check_environment.py
```

- 返回 `ready` → 继续
- 返回 `needs_setup` → 按提示安装缺失依赖
- 返回 `partial` → 继续可用功能，标注降级项

### 第二步：抓取视频列表

根据用户指定的模式，调用 `bilibili-universal` 抓取视频：

**热门排行榜：**
```bash
export SKILL=<bilibili-universal路径>
.venv/bin/python $SKILL/bili-harvest.py hot --limit 10 --since <昨日日期>
```

**关键词搜索：**
```bash
python3 $SKILL/bili-fetch.py search "AI Agent" --order pubdate --pages 2
```

**UP主主页：**
```bash
python3 $SKILL/bili-fetch.py user <mid> --videos 20 --since <昨日日期>
```

### 第三步：字幕转写与摘要

对每个新视频调用 `bili-summary` 提取字幕并生成摘要：
```bash
cd <bilibili-video-summary路径>
python bili-transcript.py "<视频URL>"
cat ./bili-output/transcript.txt
```

### 第四步：生成摘要卡片

为每个视频生成如下格式的摘要卡片：

```markdown
## 今日B站摘要 — <日期>

### 1. <视频标题>
- **UP主**：@<用户名>
- **播放量**：<数字> | **弹幕数**：<数字> | **时长**：<MM:SS>
- **发布时间**：<YYYY-MM-DD>
- **核心要点**：
  - 要点1
  - 要点2
  - 要点3
- **链接**：https://www.bilibili.com/video/<BV号>
```

### 第五步：站内推送

将摘要卡片直接输出到对话中，供用户查看。

## 配置说明

### 视频数量控制

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 热门视频数 | 10条 | 最多展示10条热门 |
| 关键词搜索结果 | 20条 | 最多2页 |
| UP主视频数 | 20条 | 每个UP主最多20条 |
| 最小播放量 | 无限制 | 可过滤低播放量内容 |

### 时间范围

- `--since` 参数使用格式 `YYYY-MM-DD`
- 推荐设为昨天日期，避免重复抓取的边界问题
- 首次运行时不指定，抓取最近7天

## 降级策略

| 功能 | 失败条件 | 降级方式 |
|------|----------|----------|
| 热门视频抓取 | 风控失败（code=-352） | 等10分钟后重试，或用户提供视频列表 |
| 字幕转写 | 无CC字幕且无GPU | 仅使用视频标题+简介生成摘要 |
| 弹幕抓取 | .venv未安装bilibili-api | 跳过弹幕，仅抓取评论 |
| 单视频处理 | API超时 | 跳过该视频，继续处理其他视频 |

## Gotchas

1. **B站搜索接口偶发风控**：`code=-352` 时换 `--order` 参数重试，或等10分钟
2. **UP主空间SPA首次不渲染**：脚本已自动 reload+sleep，无需手动处理
3. **评论接口IP频控**：默认sleep 0.5s，大批量抓取建议轮换IP
4. **字幕优先顺序**：CC字幕 > GPU转写 > 仅标题简介，无字幕时降级为纯文本摘要
5. **BV号与aid转换**：`video` 接口需要aid但用户提供bvid，脚本自动转换

## 输出验收标准

- [ ] 每个视频有标题、UP主、播放量、核心要点
- [ ] 摘要不超过3个要点，简洁明了
- [ ] 链接可点击跳转
- [ ] 无重复视频（按BV号去重）
- [ ] 站内推送格式清晰可读

## 停止条件

- 所有视频处理完成，输出摘要卡片
- 遇到不可恢复的风控错误（连续3次失败），停止并提示用户稍后重试
- 用户要求中止时立即停止
