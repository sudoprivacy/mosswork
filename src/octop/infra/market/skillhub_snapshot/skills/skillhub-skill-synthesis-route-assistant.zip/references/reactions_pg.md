# 反应条件与保护基建议（按官能团）

> 每条给「首选 + 备选 + 兼容性提示」。兼容性指该保护基对酸碱/氧化还原环境的耐受。

## 一、羟基（–OH）保护
| 保护基 | 引入 | 脱除 | 兼容性 |
|---|---|---|---|
| TBDMS / TBS | TBDMSCl, imidazole | TBAF / 稀酸 | 耐碱，**酸敏** |
| TBDPS | TBDPSCl | TBAF | 更稳定，耐弱酸 |
| Ac (乙酰) | Ac2O / Py | 碱水解 (NaOMe/MeOH) | 酸稳定，**碱可脱** |
| Bn (苄基) | BnBr, NaH | H₂/Pd-C（氢解） | 耐酸碱，需氢化脱 |
| MOM / MEM | MOMCl / MEMCl | 酸 (HCl/AcOH) | 酸不稳定 |
| PMB | PMBCl | DDQ（氧化）/ H₂ | 可选择性脱除 |

## 二、氨基（–NH2/–NHR）保护
| 保护基 | 引入 | 脱除 | 兼容性 |
|---|---|---|---|
| Boc | Boc2O, base | TFA / HCl(气) | **酸敏**，碱稳定 |
| Cbz / Z | CbzCl | H₂/Pd-C / HBr | 需氢化脱 |
| Fmoc | Fmoc-Cl | 哌啶（碱） | **碱可脱**，酸稳定 |
| Ts / 磺酰胺 | TsCl | 强还原/强酸 | 很稳定，难脱 |
| SEM | SEM-Cl | TBAF / 酸 | 类似 TBS，更稳 |

## 三、羧酸（–COOH）保护
- 甲酯/乙酯：MeOH/H⁺ 或 SOCl2/MeOH；脱：碱水解（⚠️ 碱敏感酯如 t-Bu 用酸脱）。
- t-Bu 酯：isobutene/H⁺；脱：**酸（TFA）**，碱稳定。
- 苄酯（Bn）：H₂/Pd-C 脱。

## 四、羰基（C=O）保护
- 缩酮/缩醛：二醇 + 酸催化；脱：酸（水溶液）。
- 肟/腙：NH2OH / NH2NH2；脱：水解。

## 五、常用成键反应（含典型条件）
| 反应类型 | 典型条件 | 备注 |
|---|---|---|
| 酰胺缩合 | HATU/DIPEA 或 EDC/HOBt，DMF，RT | 最常用，温和 |
| 酯化 | DCC/DMAP 或 SOCl2/ROH | 注意消旋（手性中心邻位） |
| Suzuki 偶联 | Ar-B(OH)2 + Ar-X, Pd(PPh3)4, base | 卤代芳烃/OTf |
| Buchwald-Hartwig 胺化 | Pd2(dba)3 + 配体, base | C–N 偶联 |
| 还原胺化 | RCHO + R'NH2 + NaBH3CN / NaBH(OAc)3 | 一步成仲胺 |
| 不对称氢化 | [Rh]/[Ru] 手性膦配体, H₂ | 烯烃/酮 |
| SN2 烷基化 | NaH + R–X（或 K2CO3） | 避免叔卤代烃 |
| Grignard 加成 | RMgX, ether, 0℃→RT | ⚠️ 强碱/无水 |
| 氧化（醇→羰基） | Swern / Dess-Martin / PCC | 温和首选 Swern |
| 还原（羰基→醇） | NaBH4（温和）/ LiAlH4（剧烈） | LiAlH4 ⚠️ 遇水剧烈 |

## 六、选择原则
- 先定「哪一步最脆弱」：手性中心旁避免强碱/高温导致消旋。
- 保护基顺序：先引入稳定、后引入易脱；脱保护顺序与之相反（正交保护）。
- 放大优先：能用 NaBH4 不用 DIBAL-H；能用 HATU 不用危险缩合剂；避免柱层析（改用结晶/成盐）。

## 七、消旋风险提醒
- 手性 α-碳的酰胺/酯缩合、酰卤、烯醇化条件易外消旋 → 用 HATU/低温或经手性池。
- 给出路线时标注「此步存在消旋风险，建议用手性 HPLC 监控或改用手性催化」。
