#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
seed_registry.py — 写入种子基线到 data/registry.json
====================================================
仅写入稳定、通用的反应/保护基知识（非任何专有路线），标注"种子基线/待文献复核"。
具体化合物路线(routes)随用户查询经 registry_cli.py add 沉淀成长；首次真实核验后覆盖种子。
运行：python seed_registry.py
"""
import json
import os
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "..", "data", "registry.json")
BASE_DATE = date.today().isoformat()
SRC = "seed-baseline(待文献/专利复核)"


def r(name, **kw):
    d = {"name": name, "last_checked": BASE_DATE, "source": SRC}
    d.update(kw)
    return d


# reactions：稳定的官能团→反应/保护基知识（兼容性、危险类别、首选+备选）
REACTIONS = {
    "醇的硅醚保护(TBDMS/TBS)": r("醇的硅醚保护(TBDMS/TBS)",
        category="保护基-羟基",
        summary="TBSCl/Im 或 TBDMSCl 保护伯/仲醇；TBDMS 对酸更稳定、对碱稍敏感",
        preferred="TBS (Si-O 稳定、氟化脱保护)",
        alternative="TBDPS(更耐酸)/TIPDS(邻二醇)/MOM/Ac(碱敏)",
        compatibility="酸敏(强酸脱)/碱相对稳定；避免强酸条件",
        hazard="低",
        note="脱保护用 TBAF/AcOH-THF；质谱常因 Si 同位素簇识别"),
    "胺的Boc保护": r("胺的Boc保护",
        category="保护基-氨基",
        summary="(Boc)2O/碱 保护伯/仲胺；Boc 对碱稳定、对强酸不稳定",
        preferred="Boc ((Boc)2O, NaOH/Et3N)",
        alternative="Cbz(氢解脱)/Fmoc(碱脱)/Ts(难脱)",
        compatibility="酸敏(4N HCl/dioxane、TFA 脱)；碱稳定",
        hazard="低",
        note="与 TBS 正交：Boc 酸脱、TBS 碱/氟脱"),
    "羧酸酰胺化(缩合)": r("羧酸酰胺化(缩合)",
        category="偶联-羧酸",
        summary="HATU/HBTU/EDC·HCl + HOBt/DIEA 缩合羧酸与胺；或酸化先制酰氯",
        preferred="HATU/HBTU + DIEA (室温, DMF/DCM)",
        alternative="EDC·HCl+HOBt(水相友好)/酰氯(SOCl2, 放热)/DCC(副产DCU难除)",
        compatibility="对水/醇敏感；需无水",
        hazard="中(酰氯放热/腐蚀；HATU 致敏)",
        note="手性中心邻近时防消旋：用 HATU/DIEA 低温"),
    "Suzuki-Miyaura偶联": r("Suzuki-Miyaura偶联",
        category="C-C成键-芳基",
        summary="Pd(PPh3)4 / Pd(dppf)Cl2 + 碱，芳基/烯基硼酸与卤代芳环偶联",
        preferred="Pd(dppf)Cl2, K2CO3, dioxane/H2O, 80°C",
        alternative="Pd(PPh3)4 / Pd(OAc)2+SPhos (位阻大时用)",
        compatibility="对氧/水有一定容忍；需惰性气氛减毒",
        hazard="中(Pd 残留→元素杂质；燃点溶剂)",
        note="卤代物优选 Br/I；Cl 活性低需富电子配体"),
    "Wittig / Still-Gennari烯化": r("Wittig / Still-Gennari烯化",
        category="C-C成键-烯烃",
        summary="磷ylide 与醛酮成烯；Still-Gennari(稳定ylide)得E-烯烃",
        preferred="Still-Gennari (KOtBu, 18-crown-6, THF, -78°C) 得 E",
        alternative="Wittig(普通ylide得Z/E混合)/Horner-Wadsworth-Emmons",
        compatibility="碱敏感基团规避；低温",
        hazard="中(ylide 强碱；NaH 遇水放氢)",
        note="立体化学由ylide稳定性决定"),
    "催化氢化(Pd/C, H2)": r("催化氢化(Pd/C, H2)",
        category="还原-加氢",
        summary="Pd/C 或 PtO2 催化 H2 还原烯/炔/硝基/苄基氢解",
        preferred="Pd/C 10%, H2 1-3 atm, MeOH/EtOAc",
        alternative="Pd(OH)2(苄基氢解更强)/Raney Ni(慎用)/转移氢化(Pd/C+HCOONH4)",
        compatibility="卤代会氢解脱落；含 S/N 中毒催化剂",
        hazard="高(高压H2燃爆；浆态Pd/C易起火→湿态操作)",
        note="⚠️ 安全红线：高压氢化须工程控制；Pd/C 永远保持润湿"),
    "叠氮化物引入/还原": r("叠氮化物引入/还原",
        category="官能团互变-胺",
        summary="NaN3 取代卤代物/甲苯磺酸酯得叠氮，再 Staudinger/Pd-C 还原胺",
        preferred="NaN3 置换(极性非质子溶剂) → Pd/C 还原",
        alternative="Gabriel(邻苯二甲酰亚胺钾)/还原胺化",
        compatibility="与炔/金属叠氮→爆炸风险；避免浓缩干燥叠氮",
        hazard="高(叠氮化物摩擦/热敏感；有机叠氮易爆)",
        note="⚠️ 安全红线：叠氮永远在溶液中、稀浓度操作，禁蒸干"),
}

# routes：仅放一条通用策略基线（具体API路线随查询成长）；不臆造专有路线
ROUTES = {
    "通用逆合成策略基线(待按具体API填充)": r("通用逆合成策略基线(待按具体API填充)",
        category="策略基线",
        summary="先标官能团/立体中心→选 disconnection(优先C-C、邻近官能团、稳定合成子)→FGI/FGA 使逆合成可行→回溯商用起始原料",
        key_disconnections="芳香亲电取代 / 1,3-二羰基 / α,β-不饱和羰基 / 醇→羰基 / 酯酰胺缩合逆 / 杂环环化",
        typical_hazards="高压氢化、叠氮、有机金属强碱、放热酰氯、硝化",
        patent_refs="待按具体API做 FTO(联动 patent-disclosure-skill)",
        note="具体化合物的真实路线请在查询后经 add 沉淀；本条目仅为结构占位"),
}

db = {"meta": {"last_full_refresh": BASE_DATE, "version": 1, "freshness_months": 6},
      "reactions": REACTIONS, "routes": ROUTES}
os.makedirs(os.path.dirname(DB), exist_ok=True)
with open(DB, "w", encoding="utf-8") as f:
    json.dump(db, f, ensure_ascii=False, indent=2)
print("SEED_OK reactions:", len(REACTIONS), "routes:", len(ROUTES), "date:", BASE_DATE)
