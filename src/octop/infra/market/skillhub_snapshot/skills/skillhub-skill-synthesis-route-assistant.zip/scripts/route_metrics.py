#!/usr/bin/env python3
"""route_metrics.py — 合成路线评分（步数/最长线性序列/累计收率/步数经济性/高危计数）。

用法：
  python route_metrics.py '{"steps":[{"name":"步骤1","yield":85,"hazard":false},...],"lls":4}'
  python route_metrics.py route.json
  cat route.json | python route_metrics.py

字段说明：
  steps[].yield : 该步收率（百分数，0-100），缺失视为 100（如“无收率报道”）
  steps[].hazard: 布尔或字符串（高危类别名），非空/True 计为高危步
  lls           : 最长线性序列（可选；缺省按线性=步数）
输出：JSON 摘要 + 人类可读报告。
"""
import sys, json, math

def load(data):
    if isinstance(data, str):
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            with open(data, "r", encoding="utf-8") as f:
                return json.load(f)
    return data

def analyze(d):
    steps = d.get("steps", [])
    n = len(steps)
    yields = []
    hazards = []
    for i, s in enumerate(steps, 1):
        y = s.get("yield", 100)
        try:
            y = float(y)
        except (TypeError, ValueError):
            y = 100.0
        yields.append(y)
        h = s.get("hazard", False)
        if isinstance(h, str):
            if h.strip().lower() in ("", "false", "no", "无"):
                h = False
            else:
                h = True
        if h:
            hazards.append((i, s.get("name", f"步骤{i}"), s.get("hazard") if isinstance(s.get("hazard"), str) else "高危"))
    cum = 1.0
    for y in yields:
        cum *= max(0.0, min(100.0, y)) / 100.0
    cum_pct = cum * 100.0
    lls = d.get("lls") or n
    # 步数经济性：累计收率 / 步数（越高越好，经验参考）
    econ = cum_pct / n if n else 0.0
    return {
        "total_steps": n,
        "longest_linear_sequence": lls,
        "cumulative_yield_pct": round(cum_pct, 2),
        "step_economy_score": round(econ, 2),
        "hazard_steps": len(hazards),
        "hazard_detail": [{"step": i, "name": nm, "type": t} for i, nm, t in hazards],
        "per_step_yield": [round(y, 1) for y in yields],
    }

def report(r):
    lines = []
    lines.append("==== 合成路线评分 ====")
    lines.append(f"总步数            : {r['total_steps']}")
    lines.append(f"最长线性序列(LLS) : {r['longest_linear_sequence']}")
    lines.append(f"累计收率          : {r['cumulative_yield_pct']} %")
    lines.append(f"步数经济性评分    : {r['step_economy_score']} (累计收率/步数)")
    lines.append(f"高危步骤数        : {r['hazard_steps']}")
    if r["hazard_detail"]:
        lines.append("高危明细:")
        for h in r["hazard_detail"]:
            lines.append(f"  - 步骤{h['step']} {h['name']} [{h['type']}]")
    else:
        lines.append("本路线未识别到高危操作（仍建议小试放大前做标准 JSA）。")
    grade = "A" if (r["cumulative_yield_pct"] >= 30 and r["hazard_steps"] == 0) else \
            "B" if r["cumulative_yield_pct"] >= 15 else "C"
    lines.append(f"综合参考等级      : {grade} (A:收率≥30%且无高危; B:收率≥15%; C:其余)")
    return "\n".join(lines)

def main():
    if len(sys.argv) > 1:
        arg = sys.argv[1]
    else:
        arg = sys.stdin.read().strip()
    if not arg:
        print(__doc__)
        sys.exit(1)
    d = load(arg)
    r = analyze(d)
    print(report(r))
    print("\n--- JSON ---")
    print(json.dumps(r, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
