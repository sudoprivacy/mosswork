---
name: skillhub-skill-synthesis-route-assistant
description: "化学合成路线辅助：逆合成拆解（disconnection/合成子/官能团互变）、文献/专利合成路线提取与并排比对、反应条件与保护基选择建议、合成安全风险提示、路线评分（步数/收率/原子经济性）。当用户需要设计或评估一条化合物的合成路线、做逆合成分析、选择保护基或反应条件、从论文或专利中整理并对比多条工艺路线、或审查合成安全性时使用。触发词包括但不限于：合成路线、逆合成、路线设计、disconnection、合成子、官能团互变、FGI、保护基、反应条件、工艺路线、文献路线比对、路线评分、合成安全、工艺安全、收率、原子经济性、药物化学合成、有机合成、中间体、起始原料、API 合成。适用于药物化学、有机合成、API/中间体工艺开发、立项前的合成可行性评估。"
---

# 合成路线辅助 Synthesis Route Assistant

为制剂研发/注册岗（合成基础较弱）提供「查得到、拆得开、比得清、用得安全」的合成推理抓手。本 skill 不替代专业化学家的判断，而是把常见逆合成套路、反应/保护基经验、文献路线整理与安全性检查结构化，降低入门门槛。

## 调用流程（Capability 路由）

1. 先判断用户诉求落在哪个能力（见下「核心能力」），读取对应 `references/*.md`。
2. **涉及反应/保护基知识或具体化合物路线时，先查询本地成长库**：运行 `scripts/registry_cli.py query --name X --type reactions|routes`——
   - 返回 `FRESH` → 直接采用库内条目，标注「📚 本地知识库已核验(YYYY-MM-DD)」；
   - 返回 `STALE` → 提示「该条目已超 6 个月，正在刷新…」，跳到步骤 4；
   - 返回 `NOT_FOUND` → 跳到步骤 4。
3. 涉及路线评分/收率计算时，调用 `scripts/route_metrics.py`。
4. **刷新/新增（自我成长）**：对 STALE/NOT_FOUND 的条目，用文献/专利检索（WebSearch/WebFetch）核实，必要时联动 `regulatory-monitor` 复核 IP/法规最新；再以 `scripts/registry_cli.py add --json '{...}'` 把核验后条目写回 `data/registry.json`，`last_checked` 自动置今天。**知识库因此逐条累积→自我成长**。
5. 输出一律采用统一格式（见「输出规范」），便于沉淀进项目文件夹（如 RD001 / RL009 同类）。

## 核心能力

### 1. 逆合成拆解（retrosynthesis）
目标：把目标分子（TM）逐层拆到可购/可制的起始原料，识别关键键与官能团。
- 步骤：① 标出 TM 的所有官能团与立体中心 → ② 选 disconnection 位点（优先 C–C 键、临近官能团、稳定合成子）→ ③ 给出合成子与其等价试剂（合成子→试剂映射）→ ④ 必要时插入 FGI（官能团互变）或 FGA（官能团添加）使 disconnection 可行 → ⑤ 回溯到商用起始原料并校验每条线「合成子是否能由真实试剂给出」。
- 常用 disconnection 套路（芳香亲电取代、1,3-二羰基、α/β-不饱和羰基、醇→羰基（氧化逆）、胺/酰胺、酯/酰胺（缩合逆）、环化（Dieckmann/内酯/杂环）等）见 `references/retrosynthesis.md`。
- 输出要求：给出 2–3 条候选逆合成线（标注关键 disconnection 与试剂），并说明每条的优劣（步数、立体控制、试剂可得性）。

### 2. 文献/专利路线提取与比对
目标：从论文/专利/Reaxys/SciFinder 摘录多条路线，结构化并排对比。
- 提取字段：路线来源（DOI/专利号/作者年）、步数、最长线性序列（LLS）、各步试剂/条件/收率、关键中间体、是否需柱层析/手性拆分/不对称催化、总收率、所用 hazardous 试剂。
- 对比维度表模板见 `references/literature_extraction.md`。
- 比对结论须给出：哪条更适合放大/哪条更适合实验室、成本与 IP 风险、可否规避某专利（结合专利号）。

### 3. 反应条件与保护基建议
目标：给定底物类型与要转化的官能团，给出常用反应与保护基方案及替代。
- 按官能团分组（羟基/氨基/羧酸/羰基/酰胺/杂环）列常用保护与脱保护条件、常用偶联/烷基化/还原/氧化/环化反应及典型条件，见 `references/reactions_pg.md`。
- 输出须标注「温和/剧烈」「兼容性」（如 TBS 对碱敏感、Boc 对酸敏感），并给 1 个首选 + 1 个备选。

### 4. 合成安全风险提示
目标：在给出任何路线/条件前，主动标注高危操作。
- 高危类别（叠氮/重氮/过氧/高氯酸盐/高压氢化/有机金属强碱/放热酰氯/硝化/氰化/微波高压等）的判定与缓解见 `references/safety.md`。
- 强制：凡路线中出现 `NaN3`、重氮盐、过氧化物、高压 H₂（Pd/C 浆态氢化）、Na/液氨、丁基锂/格氏大规模、硝化、氰化物等，必须单列「⚠️ 安全红线」段落并给替代或工程控制建议。

## 输出规范（统一）
- 逆合成/路线建议用「树状 + 表格」：先一句话总路线，再逐层表（层级 | 结构/名称 | 关键键/disconnection | 试剂 | 说明）。
- 比对用「路线对比表」：来源 | 步数 | LLS | 总收率 | 关键试剂 | 高危点 | IP 备注 | 适用性评分。
- 结尾固定三段：① 推荐路线与理由；② ⚠️ 安全红线（无则写「本路线未识别到高危操作」）；③ 后续建议（如「建议 CNIPA 检索 X 专利确认权项」「建议小试验证 Y 步收率」）。

## 自我成长与自动更新机制（Self-Growth & Auto-Update）——核心特色
本 skill 带一个**会随使用越来越聪明的本地知识库** `data/registry.json`，并联动 `regulatory-monitor` 保持法规/IP 最新：

**知识库结构**（`data/registry.json`）：
```
{
  "meta": {"last_full_refresh": "YYYY-MM-DD", "version": 1, "freshness_months": 6},
  "reactions": { "<名称>": {category, summary, preferred, alternative, compatibility, hazard, note, last_checked, source} },
  "routes":    { "<化合物/领域>": {category, summary, key_disconnections, typical_hazards, patent_refs, last_checked, source} }
}
```
- `reactions`：稳定的官能团→反应/保护基知识（兼容性、危险类别、首选+备选）。种子已写入常见保护基与偶联/还原反应，可逐年沉淀新反应。
- `routes`：用户查询的具体化合物/治疗领域路线，初始仅含一条通用策略基线，**随每次真实查询经 `add` 沉淀成长**。

**每次查询执行流程（必须照做）**：见「调用流程」步骤 2/4。**绝不在未核实的情况下把某专有路线当成既有事实**；凡涉及专利/注册，先 `regulatory-monitor` 复核。

**离线基线** `references/regulatory_baseline.md`：顶部标注「最后刷新 YYYY-MM-DD」，含国内注册分类/起始原料/杂质/元素杂质/Q7/Q11/IP-FTO 基线。**凡涉及工艺合规/专利 FTO，若基线超 6 个月，必须先触发 `regulatory-monitor` 复核再作答**。

**周期性维护**：`scripts/registry_cli.py stale` 列出过期条目 → 结合 `regulatory-monitor` 批量刷新；`stats` 盘点累积量与新鲜度；`list --type X` 查看某类。

## 资源
- `scripts/registry_cli.py`：自我成长引擎（query/add/list/stale/stats，6 个月新鲜度）。纯 Python，无第三方依赖。
- `scripts/seed_registry.py`：写入稳定反应/保护基种子基线；首次运行生成 `data/registry.json`。
- `references/regulatory_baseline.md`：合成相关法规/IP 基线（含刷新日期，联动 regulatory-monitor 更新）。
- `references/retrosynthesis.md`：disconnection 套路、合成子→试剂映射、FGI/FGA、手性控制、worked example。
- `references/reactions_pg.md`：按官能团的反应与保护基速查（含条件、兼容性、备选）。
- `references/safety.md`：高危反应/试剂判定表与缓解措施。
- `references/literature_extraction.md`：路线提取字段、对比表模板、示例。
- `scripts/route_metrics.py`：输入结构化步骤（步数 + 各步收率% + 关键中间体数），输出总步数、最长线性序列、累计收率、步数经济性与风险提示。纯 Python，无第三方依赖。

## 注意
- 不臆造反应：若不确定某试剂/条件，明确标注「待实验验证」并给文献检索建议，不给出看似合理但未经证实的步骤。
- 涉及结构式：优先用 SMILES/IUPAC 名称表述；如需绘图，说明由用户侧 RDKit/ChemDraw 生成。
- 与专利/立项联动：路线若触碰已知化合物专利，提醒先做 FTO（可联动 patent-disclosure-skill / regulatory-monitor）。
- 自我成长纪律：每次给出反应/路线结论后，若条目来自查询且已核实，须通过 `registry_cli.py add` 沉淀进 `data/registry.json`；涉及专利到期/指导原则修订的，以 `regulatory-monitor` 拉取的最新为准，不写死版本号。
