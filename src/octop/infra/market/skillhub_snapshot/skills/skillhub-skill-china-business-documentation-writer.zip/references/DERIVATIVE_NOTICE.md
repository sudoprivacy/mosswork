# 衍生版本说明

- 原项目：[boshi-xixixi/traeskill](https://github.com/boshi-xixixi/traeskill/blob/9cf38e632bdfb9d91a965140ffcbdac8e45659b1/.trae/Skills/.agents/skills/documentation-writer/SKILL.md)
- 原文件：`.trae/Skills/.agents/skills/documentation-writer/SKILL.md`
- 固定提交：`9cf38e632bdfb9d91a965140ffcbdac8e45659b1`
- 许可证：`MIT`，全文见 `LICENSE.md`
- 原发布对象：`documentation-writer`
- 新发布对象：`china-business-documentation-writer`
- 修改内容：重新定义中国业务场景、输入、工作流、交付物、质量门槛、使用边界和语义化 Slug。
- 未删除原许可证义务，也未扩大为无法验证的平台执行能力。
