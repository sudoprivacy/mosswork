#!/usr/bin/env python3
"""Machine contract for MTP 0.2.0 handoffs (T-020-HANDOFF, problem family C).

A handoff is a bounded JSON record. M-Take must validate it before continuing; a
missing / stale / disk-inconsistent handoff fails closed. Historical rounds are
archived under ``ai/handoff/<date>-<round>.md``; ``ai/HANDOFF.md`` keeps only the
current round plus an archive index.

Usage:
    python3 validate_handoff.py <handoff.json> [--head <sha>] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import sys

COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
REVISION_RE = re.compile(r"^[0-9a-f]{64}$")
REQUIRED_FIELDS = {
    "objective",
    "accepted_commit",
    "plan_commit",
    "plan_revision",
    "active_task_id",
    "allowed_paths",
    "pending_registry",
    "reverify_at",
}


class HandoffError(RuntimeError):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def validate_handoff(handoff: object, *, head: str | None = None) -> None:
    if not isinstance(handoff, dict):
        raise HandoffError("handoff-not-object")
    if set(handoff) != REQUIRED_FIELDS:
        raise HandoffError("handoff-fields-invalid")
    for field in ("objective", "active_task_id", "reverify_at"):
        if not isinstance(handoff[field], str) or not handoff[field].strip():
            raise HandoffError(f"handoff-{field}-invalid")
    for field in ("accepted_commit", "plan_commit"):
        if not isinstance(handoff[field], str) or not COMMIT_RE.fullmatch(handoff[field]):
            raise HandoffError(f"handoff-{field}-invalid")
    if not isinstance(handoff["plan_revision"], str) or not REVISION_RE.fullmatch(handoff["plan_revision"]):
        raise HandoffError("handoff-plan-revision-invalid")
    if not isinstance(handoff["allowed_paths"], list) or not all(
        isinstance(p, str) and p.strip() for p in handoff["allowed_paths"]
    ):
        raise HandoffError("handoff-allowed-paths-invalid")
    if not isinstance(handoff["pending_registry"], bool):
        raise HandoffError("handoff-pending-registry-invalid")
    # C-3: a handoff that pins a HEAD must match the disk HEAD, else it is stale.
    if head is not None and handoff["accepted_commit"] != head:
        raise HandoffError("handoff-stale-head")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("handoff")
    parser.add_argument("--head")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    try:
        handoff = json.loads(open(args.handoff, encoding="utf-8").read())
        validate_handoff(handoff, head=args.head)
    except (OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"valid": False, "error": str(exc)}))
        return 1
    except HandoffError as exc:
        print(json.dumps({"valid": False, "error": exc.code}))
        return 1
    print(json.dumps({"valid": True}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
