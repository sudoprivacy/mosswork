trigger: 真实换 Agent、恢复点、阻塞移交或独立审查
budget: 1500
next: 交接后由 m-take 校验；未通过不得继续

# 交接内容与合同

明确交接原因和阻塞，不复制长上下文，只交付恢复当前 Task、AC、TC、验证和下一动作所需的
最小状态。

1. 运行当前 Task 声明的验证，记录命令和真实结果，不把待办写成已完成。
2. 在 `ai/HANDOFF.md` 记录交接原因、`plan_commit`、`plan_revision`、当前 Task/状态、分支和
   HEAD、工作区状态、产物路径、验证、阻塞和唯一下一动作。
3. 只为该真实交接更新 `ai/NEXT.md`；需要跨会话独立审查时，指向固定 artifact HEAD 和审查范围。
4. 长材料、日志和审查证据只引用路径及短摘要，不复制正文。不得声称接收方已经接手或审查已经通过。

若当前 M-Build 已经过失败修复，交接还必须原样保存该次唯一的 Lesson Check、已查询的 Registry
revision（若有）及 `registry pending` 状态。pending 只保留在项目事实中，不写入 Project
Passport；同一 Agent 连续推进仍不得因此创建 HANDOFF。

**交接前必须留下阶段沉淀检查（L-013）**：按 `lessons` / `capability` / `docs` 三类回看本期，
各取 `record` / `none` / `no-new-deposit`，无新增也要留 `no-new-deposit` 结论。判定见 m-build 的
`skills/m-build/scripts/lesson_gate.py phase_knowledge_check`；缺该记录时
`phase_completion_blocked` 为真——不得建立交接。该记录随交接证据一并保留。

恢复点没有接收方时明确写明；交接内容必须足以让接手方检查是否陈旧。

## Handoff Contract

交接带**机器合同**（`ai/handoff/current.json`），m-take 未通过 `scripts/validate_handoff.py` 校验
不得继续。合同字段固定为：`objective`、`accepted_commit`、`plan_commit`、`plan_revision`、
`active_task_id`、`allowed_paths`、`pending_registry`、`reverify_at`。`accepted_commit` 与磁盘
HEAD 不一致即判陈旧（`handoff-stale-head`）。

**归档约定**：`ai/HANDOFF.md` 只保留当前轮 + 归档索引；上一轮交接归档到
`ai/handoff/<date>-<round>.md`，避免只增不减（C-2）。
