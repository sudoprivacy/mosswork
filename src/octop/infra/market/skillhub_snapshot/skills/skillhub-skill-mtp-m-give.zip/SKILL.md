---
name: skillhub-skill-mtp-m-give
description: "monster 的 MTP 0.2.4 交棒入口。真实换 Agent、恢复点、阻塞移交或跨会话审查时用。"
---

# M-Give

```mermaid
flowchart LR
  A["核对"] --> B["写交接"] --> C["路由"]
```

## Version Preflight

写入前读取 `$SKILL_DIR/MTP_VERSION` 和 `ai/mtp.json`。manifest 缺失、profile
不是 `lightweight`、缺少有效 `project_id` / `registry_id` 或版本不匹配时，返回
`m-new` 且零写。只有完整 Bundle `0.2.4` 项目才继续。

仅真实所有权/会话边界才建交接；普通完成、连续推进、子 Agent 返回、常规审查都不是。

## 读哪块

交接内容、合同与归档约定见 `blocks/handoff.md`。

四原则：Think Before Coding / Simplicity First / Surgical Changes / Goal-Driven Execution。

## 硬要求

1. 最小状态 = NEXT 头部 + 按引用走，不复制长上下文。
2. **交接前地图门（D-4）**：跑 `python3 <m-build>/scripts/project_memory.py status --target .`；
   `ready=false`（仍有 `待替换`/缺节）或 `stale=true` 时**拒绝交接**；修复：补地图 →
   `sync-current-state --apply` → 复跑。
3. 不写 `CLAUDE.md` / `ai/lessons.md`。
