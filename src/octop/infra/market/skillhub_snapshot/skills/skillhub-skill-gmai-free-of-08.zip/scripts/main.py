# -*- coding: utf-8 -*-
"""跨部门协作沟通函速查手册（gmai-free-of-08）业务主脚本
免费技能：零费用，安装后可直接运行本脚本交付结果。
用法：python main.py <输入.json>    缺省使用包内 demo_input.json 演示输入
本技能交付：跨部门协作沟通函速查成品文档（可直接复制使用，含替换位说明）；输入完备度自检表（缺项标注 + 补齐建议）；使用与留痕说明（归档口径 / 复用方式 / 更新频率）
建议输入（专业字段）：文书主题；覆盖范围；依据与材料
"""
import json, os, re, sys, time

SLUG = "gmai-free-of-08"
TITLE = "跨部门协作沟通函速查手册"
PRICE_FEN = 0
CATEGORY = "职场办公效率"

# 输入字段规格：[标准字段名, 是否必需, [同义词...], 缺失时的说明]
FIELDS = [['文书主题', True, ['主题', '文书', '事项'], '决定成稿主题与适用场景'], ['覆盖范围', True, ['范围', '边界', '内容范围'], '范围不清会导致成稿口径发散'], ['依据与材料', True, ['依据', '材料', '来源'], '决定结论是否有据可依'], ['格式与版本', False, ['格式', '版本', '模板'], '决定篇幅与归档口径'], ['材料要点', False, ['要点', '素材', '原文'], '决定正文能否直接成稿'], ['待补事项', False, ['待补', '遗留', '缺口'], '标注后可在成稿中留【待补充】']]
# 本领域参数（阈值/档位/因子等，按技能领域固化）
PARAMS = {'finds': [['重复性工作未自动化', '高', '同类数据每周手工整理并跨表复制', '占用大量工时且易出错', '梳理规则后以脚本或工具自动化'], ['信息存放分散无检索规则', '高', '同一资料在多个位置且命名不一致', '查找成本高，版本混乱', '统一命名规范与唯一存放位置'], ['审批链路冗余', '中', '低风险事项仍需三级审批', '流程周期被无谓拉长', '按金额与风险分级授权'], ['权限与共享范围失控', '高', '共享链接为任何人可编辑', '敏感信息外泄风险', '按最小必要设置共享与访问期限'], ['缺少版本与变更记录', '中', '文档更新无版本号与修改说明', '无法追溯变更来源', '启用版本记录并要求变更说明'], ['任务缺少明确负责人与截止', '中', '任务描述无责任人与时限', '事项长期挂起', '任务必须含负责人、截止日与验收标准']], 'tools': '```text\n# 走查清单（无需命令行，按项核对并记录证据）\n1) 抽 10 份常用文档，核对命名与存放位置是否统一\n2) 抽 5 条共享链接，核对权限范围与有效期\n3) 抽 3 个流程实例，记录从发起到完成的实际耗时与审批节点\n4) 统计一周内重复性操作耗时（按人时估算）\n```'}
# 结论依据锚点（真实规则/标准/条款来源）
ANCHORS = ['公文格式国家标准 GB/T 9704 对版头、正文、版记的构成要求', '事务文书通用要素：主体、事项、时间、结论、下一步与承办人', '台账与记录留存通行口径：一事一档、版本号与审批留痕', '表格数据一致性规则：合计与明细可勾稽、单位与时间窗统一', '电子表格处理验收口径：公式重算零错误（recalc）后才算交付']
# 自检项（输入完备度）
CHECKS = [['跨部门协作沟通函速查·输入完备度核查', ['跨部门协作沟通函速查', '面向职场办公高频场景'], '先核对要素（主体/时间/对象/结论）是否齐全，缺项列入自检并说明影响'], ['跨部门协作沟通函速查·结构与要素齐备', ['面向职场办公高频场景', '要素齐全'], '按常用办公文体要素成稿（抬头/正文/落款/附件/时限），前后口径一致'], ['跨部门协作沟通函速查·口径与数据一致', ['要素齐全', '主体/时间/结论/下一步'], '表格字段、单位、时间窗统一，合计与明细可勾稽，金额与数量加千分位'], ['跨部门协作沟通函速查·可执行性复检', ['跨部门协作沟通函速查', '口径前后一致'], '交付前抽检可执行性（谁来办/何时办/怎么算完成）并逐项标注通过或待补'], ['跨部门协作沟通函速查·诚信红线', ['伪造公文', '虚假数据'], '不得伪造公文、虚报数据或冒名签发，命中即终止']]
# 交付物构成
DELIVERABLES = ['跨部门协作沟通函速查成品文档（可直接复制使用，含替换位说明）', '输入完备度自检表（缺项标注 + 补齐建议）', '使用与留痕说明（归档口径 / 复用方式 / 更新频率）']
FOOTER = "本报告为专业作业参考，不构成法定结论或专业意见；关键结论建议由相应持证专业人员复核后使用。"


def _s(v):
    return "" if v is None else str(v).strip()


def fmt(x):
    if x is None:
        return "待补充"
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            x = int(round(x))
        else:
            return ("{:,.2f}".format(x)).rstrip("0").rstrip(".")
    if isinstance(x, int):
        return format(x, ",d")
    return str(x)


def _n(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("，", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    x = float(m.group(0))
    if "%" in s:
        return x / 100.0
    return x


def _pct(x, nd=2):
    return "—" if x is None else ("%." + str(nd) + "f%%") % (x * 100)


def _rpct(x, nd=1):
    return "—" if x is None else ("%." + str(nd) + "f%%") % x


def _money(x, nd=2):
    return "—" if x is None else ("¥{:,.%df}" % nd).format(x)


def brief(s, n=34):
    """取第一个分句并限长，用于表格单元格（短文本原样保留，长文本截断且保证括号闭合）"""
    s = _s(s)
    if not s or len(s) <= n:
        return s
    for sep in ("；", ";", "。", "\n", "，", ",", "、", "/"):
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    if len(s) > n:
        s = s[:n] + "…"
    for op, cl in (("（", "）"), ("(", ")"), ("【", "】"), ("[", "]")):
        if s.count(op) > s.count(cl):
            i = s.find(op)
            if i > 2:
                s = s[:i].rstrip("，,、 ") + "…"
            else:
                s = s.replace(op, "")
    return s


# ---------------- 输入字段解析 ----------------
FIELD_ALIAS = {}
for _f in FIELDS:
    FIELD_ALIAS[_f[0]] = [_f[0]] + list(_f[2])


def _norm(x):
    return re.sub(r"[\s_\-/（）()【】\[\]：:，,。.、|]", "", str(x)).lower()


def make_ctx(data):
    items = [(_norm(k), k, v) for k, v in data.items()]
    miss = []

    def _find(field):
        for c in FIELD_ALIAS.get(field, [field]):
            nc = _norm(c)
            if not nc:
                continue
            for nk, k, v in items:
                if _s(v) and (nc == nk or nc in nk or nk in nc):
                    return v
        return None

    def fv(field, default=None):
        v = _find(field)
        return _s(v) if v is not None else default

    def nm(field):
        v = _find(field)
        return _n(v) if v is not None else None

    def has(field):
        return _find(field) is not None

    spec = {"slug": SLUG, "title": TITLE, "cat": CATEGORY, "params": PARAMS,
            "anchors": ANCHORS, "deliverables": DELIVERABLES}
    return {"data": data, "spec": spec, "fv": fv, "nm": nm, "has": has, "miss": miss}


# ---------------- 交付物正文 ----------------


def missing_block(ctx):
    L = []
    ms = ctx["miss"]
    if ms:
        L.append("以下专业字段本次未提供，相关结论已按行业通行口径给出并标注，补齐后重跑即可得到定量结论：")
        L.append("")
        for name, why in ms:
            L.append("- **%s**：%s" % (name, why))
    else:
        L.append("本次输入已覆盖全部必需专业字段，结论可直接使用。")
    return L


def evidence_block(ctx):
    L = ["本节结论依据的规则/标准/条款来源：", ""]
    for a in ctx["spec"]["anchors"][:8]:
        L.append("- %s" % a)
    return L


# ---------------- doc 范式：通用文书 / 表格 / 清单 ----------------

def _sec_scope(ctx):
    L = ["| 输入项 | 要求 | 本次情况 |", "|---|---|---|"]
    for name, req, al, why in FIELDS:
        v = ctx["fv"](name)
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选",
                                       brief(v, 60) or "待补充"))
    L.append("")
    L.append("> 上表为本次成稿的口径基础。标注「待补充」的项不作臆测，正文中以【待补充】标出。")
    return L


def _sec_frame(ctx):
    L = ["| 段落 | 内容要点 | 产出形态 |", "|---|---|---|"]
    nd = len(DELIVERABLES)
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        if nd == 0:
            d = TITLE
        elif i <= nd:
            d = DELIVERABLES[i - 1]
        else:
            d = "并入「%s」" % DELIVERABLES[0]
        L.append("| 第 %d 段 · %s | %s | %s |" % (i, item, brief(advice, 46), brief(d, 30)))
    return L


def _sec_draft(ctx):
    L = ["以下为按本技能交付段落生成的成稿骨架。每段给出：**本段依据（取自你的输入）→ 撰写要点"
         "（本域专业口径）→ 自查关键词（交付前逐项核对）**；红线段落只标注禁止情形。", ""]
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        L.append("**%d. %s**" % (i, item))
        if "命中即终止" in advice:
            L.append("- 红线：%s" % advice)
            L.append("- 处理：命中不得变通承接，直接终止并说明理由。")
            L.append("")
            continue
        fn = FIELDS[(i - 1) % len(FIELDS)] if FIELDS else ("材料", True, [], "材料缺失")
        v = ctx["fv"](fn[0])
        L.append("- 本段依据：%s → %s" % (fn[0], brief(v, 70) or "【待补充：%s】" % fn[3]))
        L.append("- 撰写要点：%s" % advice)
        L.append("- 自查关键词：%s" % "、".join(kws[:3]))
        L.append("")
    return L


def _sec_basis(ctx):
    L = ["| 段落 | 依据来源（本域锚点） |", "|---|---|"]
    for i, (item, kws, advice) in enumerate(CHECKS, 1):
        a = ANCHORS[(i - 1) % len(ANCHORS)] if ANCHORS else "—"
        L.append("| 第 %d 段 · %s | %s |" % (i, item, a))
    return L


def _sec_deliver(ctx):
    L = []
    for d in DELIVERABLES:
        L.append("- 交付物：%s" % d)
    L.append("")
    L.append("- 留痕口径：保留输入原始材料、本报告与定稿版本号；变更须记说明，便于复现与回滚。")
    L.append("- 复用口径：替换【】内字段即可复用于同类场景；单位、时间窗或口径版本变更时，"
             "须重新核对本报告「四、口径与依据对照」。")
    return L


def _sec_finds(ctx):
    P = ctx["spec"]["params"] or {}
    fs = P.get("finds") or []
    if not fs:
        return []
    L = ["| 问题 | 等级 | 证据要点 | 影响 | 改进动作 |", "|---|---|---|---|---|"]
    for r in fs[:8]:
        L.append("| " + " | ".join(str(x) for x in list(r)[:5]) + " |")
    return L


def sections(ctx):
    """通用文书交付物：口径确认 → 结构骨架 → 成品正文 → 依据对照 → 交付留痕"""
    L = [
        ("一、需求与口径确认", _sec_scope(ctx)),
        ("二、交付结构骨架", _sec_frame(ctx)),
        ("三、成稿骨架与撰写口径", _sec_draft(ctx)),
        ("四、口径与依据对照", _sec_basis(ctx)),
    ]
    f = _sec_finds(ctx)
    if f:
        L.append(("五、本域常见问题与对策", f))
        L.append(("六、交付与留痕", _sec_deliver(ctx)))
    else:
        L.append(("五、交付与留痕", _sec_deliver(ctx)))
    return L


# ---------------- 通用区块 ----------------
def header_block(ctx):
    d = ctx["data"]
    L = ["- 技能：%s（`%s`）" % (TITLE, SLUG),
         "- 领域：%s" % CATEGORY,
         "- 计费：免费（Free Skill · 零费用）",
         "- 生成时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"),
         "- 输入字段数：%d" % len(d)]
    return L


def appendix_block(ctx):
    L = ["## 附录A 输入完备度自检", "", "| 专业字段 | 要求 | 状态 |", "|---|---|---|"]
    req_ok = req_tot = 0
    for name, req, al, why in FIELDS:
        ok = ctx["has"](name)
        if req:
            req_tot += 1
            if ok:
                req_ok += 1
        L.append("| %s | %s | %s |" % (name, "必需" if req else "可选", "已提供" if ok else "待补充"))
    L.append("")
    L.append("- 必需字段完备度：**%d/%d**" % (req_ok, req_tot))
    L.append("")
    L.append("## 附录B 交付要素核对")
    L.append("")
    L.append("| 交付要素 | 落地要点 |")
    L.append("|---|---|")
    for item, kws, advice in CHECKS:
        L.append("| %s | %s |" % (item, advice))
    L.append("")
    L.append("## 附录C 交付物清单")
    L.append("")
    for x in DELIVERABLES:
        L.append("- %s" % x)
    L.append("")
    L.append("## 附录D 待补充信息与依据来源")
    L.append("")
    L += missing_block(ctx)
    L.append("")
    L += evidence_block(ctx)
    return L


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "demo_input.json")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    ctx = make_ctx(data)
    for name, req, al, why in FIELDS:
        if req and not ctx["has"](name):
            ctx["miss"].append((name, why))

    L = ["# %s · 交付报告" % TITLE, ""]
    L += header_block(ctx)
    L.append("")
    for sec_title, body in sections(ctx):
        L.append("## " + sec_title)
        L.append("")
        L += body
        L.append("")
    L += appendix_block(ctx)
    L.append("")
    L.append("> %s" % FOOTER)
    md = "\n".join(L) + "\n"

    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "deliverable_%s.md" % time.strftime("%Y%m%d_%H%M%S"))
    with open(out, "w", encoding="utf-8") as f:
        f.write(md)
    print(md)
    print("[saved] %s" % out)


if __name__ == "__main__":
    main()
