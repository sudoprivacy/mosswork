"""
微信窗口读取器 v4.0.0

通过 Windows UI Automation API 读取微信桌面端窗口中的聊天内容。
使用 ctypes 调用 COM 接口，零外部依赖（仅需 Windows 平台）。

功能：
1. 自动发现微信桌面端窗口
2. 读取当前聊天面板的消息列表
3. 获取联系人/群聊列表
4. 切换聊天窗口
5. 实时监控消息变化

安全设计：
- 仅通过 UI Automation API 读取可见文本，不注入代码
- 不修改微信进程或内存
- 不绕过任何加密或安全机制
- 仅读取用户当前可见的内容
"""

import ctypes
import ctypes.wintypes
import logging
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Win32 常量
WM_GETTEXT = 0x000D
WM_GETTEXTLENGTH = 0x000E
SMTO_ABORTIFHUNG = 0x0002

# Win32 函数
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

# 回调类型
WNDENUMPROC = ctypes.WINFUNCTYPE(
    ctypes.wintypes.BOOL,
    ctypes.wintypes.HWND,
    ctypes.wintypes.LPARAM,
)

user32.EnumWindows.argtypes = [WNDENUMPROC, ctypes.wintypes.LPARAM]
user32.EnumWindows.restype = ctypes.wintypes.BOOL
user32.GetWindowTextW.argtypes = [ctypes.wintypes.HWND, ctypes.c_wchar_p, ctypes.c_int]
user32.GetWindowTextW.restype = ctypes.c_int
user32.GetWindowTextLengthW.argtypes = [ctypes.wintypes.HWND]
user32.GetWindowTextLengthW.restype = ctypes.c_int
user32.IsWindowVisible.argtypes = [ctypes.wintypes.HWND]
user32.IsWindowVisible.restype = ctypes.wintypes.BOOL
user32.GetClassNameW.argtypes = [ctypes.wintypes.HWND, ctypes.c_wchar_p, ctypes.c_int]
user32.GetClassNameW.restype = ctypes.c_int
user32.EnumChildWindows.argtypes = [ctypes.wintypes.HWND, WNDENUMPROC, ctypes.wintypes.LPARAM]
user32.EnumChildWindows.restype = ctypes.wintypes.BOOL


# ============================================================================
# 数据模型
# ============================================================================

@dataclass
class WeChatContact:
    """微信联系人/群聊。"""
    name: str = ""
    last_message: str = ""
    last_time: str = ""
    is_group: bool = False
    unread_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class WeChatMessage:
    """从微信窗口读取的消息。"""
    sender: str = ""
    content: str = ""
    timestamp: str = ""
    role: str = "unknown"  # self/other
    message_type: str = "text"  # text/image/voice/file
    read_at: str = ""
    raw_text: str = ""


@dataclass
class WeChatWindowState:
    """微信窗口状态。"""
    is_open: bool = False
    window_title: str = ""
    current_chat: str = ""
    contact_list: List[WeChatContact] = field(default_factory=list)
    message_list: List[WeChatMessage] = field(default_factory=list)
    detected_at: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


# ============================================================================
# 窗口发现
# ============================================================================

WECHAT_CLASS_NAMES = {
    "WeChatMainWndForPC",   # 微信主窗口
    "ChatWnd",              # 独立聊天窗口
}

# 消息内容特征：去掉明显的系统文本
SYSTEM_MESSAGES = {
    "你已添加了", "以上是打招呼的内容", "以下是新消息",
    "查看更多消息", "撤回了一条消息", "拍了拍",
    "你领取了", "发出了一个红包", "群公告",
}


def find_wechat_windows() -> List[Tuple[ctypes.wintypes.HWND, str, str]]:
    """查找所有微信窗口。

    Returns:
        [(hwnd, class_name, window_title), ...]
    """
    windows = []

    def enum_callback(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        class_buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, class_buf, 256)
        class_name = class_buf.value
        if class_name in WECHAT_CLASS_NAMES:
            title_len = user32.GetWindowTextLengthW(hwnd)
            if title_len > 0:
                title_buf = ctypes.create_unicode_buffer(title_len + 1)
                user32.GetWindowTextW(hwnd, title_buf, title_len + 1)
                windows.append((hwnd, class_name, title_buf.value))
        return True

    try:
        user32.EnumWindows(WNDENUMPROC(enum_callback), 0)
    except Exception as e:
        logger.warning(f"枚举窗口失败: {e}")

    return windows


def get_window_text_safe(hwnd) -> str:
    """安全获取窗口文本。"""
    try:
        title_len = user32.GetWindowTextLengthW(hwnd)
        if title_len <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(title_len + 1)
        user32.GetWindowTextW(hwnd, buf, title_len + 1)
        return buf.value
    except Exception:
        return ""


def get_child_windows(hwnd) -> List[Tuple[int, str, str]]:
    """获取子窗口列表。"""
    children = []

    def enum_callback(child_hwnd, _):
        class_buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(child_hwnd, class_buf, 256)
        text = get_window_text_safe(child_hwnd)
        children.append((child_hwnd, class_buf.value, text))
        return True

    try:
        user32.EnumChildWindows(hwnd, WNDENUMPROC(enum_callback), 0)
    except Exception:
        pass
    return children


# ============================================================================
# UI Automation 读取器
# ============================================================================

class UIAutomationReader:
    """通过 COM UI Automation 读取窗口文本内容。

    如果 COM 不可用，降级到 EnumChildWindows + GetWindowTextW。
    """

    def __init__(self):
        self._uia = None
        self._available = False
        self._init_com()

    def _init_com(self):
        """初始化 COM UI Automation。"""
        try:
            import comtypes
            import comtypes.client
            self._uia = comtypes.client.CreateObject(
                "{FF48DBA4-60EF-4201-AA87-54103EEF594E}",  # CUIAutomation CLSID
                interface=None,
            )
            self._available = True
            logger.debug("UI Automation COM 已初始化")
        except ImportError:
            logger.info("comtypes 不可用，将使用 Win32 API 降级方案")
            self._available = False
        except Exception as e:
            logger.warning(f"UI Automation COM 初始化失败: {e}")
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    def read_element_text(self, hwnd) -> List[str]:
        """读取窗口中的所有文本元素。"""
        if self._available and self._uia:
            return self._read_via_uia(hwnd)
        return self._read_via_win32(hwnd)

    def _read_via_uia(self, hwnd) -> List[str]:
        """通过 UI Automation COM 读取。"""
        texts = []
        try:
            element = self._uia.ElementFromHandle(hwnd)
            condition = self._uia.CreatePropertyCondition(30005, 0x0C)  # UIA_TextControlTypeId
            elements = element.FindAll(4, condition)  # TreeScope_Descendants
            for i in range(elements.Length):
                e = elements.GetElement(i)
                name = e.CurrentName
                if name and len(name.strip()) > 0:
                    texts.append(name.strip())
        except Exception as e:
            logger.debug(f"UI Automation 读取失败: {e}")
            # 降级
            return self._read_via_win32(hwnd)
        return texts

    def _read_via_win32(self, hwnd) -> List[str]:
        """通过 Win32 API 降级读取子窗口文本。"""
        texts = []
        children = get_child_windows(hwnd)
        for child_hwnd, class_name, text in children:
            if text and len(text.strip()) > 1:
                texts.append(text.strip())
        return texts


# ============================================================================
# 消息解析器
# ============================================================================

class WeChatMessageParser:
    """解析从微信窗口读取的原始文本为结构化消息。"""

    # 微信消息时间格式
    TIME_PATTERN = re.compile(r"^(\d{1,2}:\d{2})$")
    DATE_PATTERN = re.compile(r"^(\d{4}年\d{1,2}月\d{1,2}日|今天|昨天|星期[一二三四五六日天])")
    FULL_TIME_PATTERN = re.compile(
        r"(\d{4}[-/年]\d{1,2}[-/月]\d{1,2}[日]?\s+\d{1,2}:\d{2}(?::\d{2})?)"
    )

    def parse_messages(self, texts: List[str], self_name: str = "我") -> List[WeChatMessage]:
        """将原始文本列表解析为结构化消息。

        Args:
            texts: 从窗口读取的文本列表
            self_name: 自己的微信名/昵称

        Returns:
            解析后的消息列表
        """
        messages = []
        current_date = ""
        current_sender = ""
        pending_content = []

        for text in texts:
            text = text.strip()
            if not text:
                continue

            # 过滤系统消息
            if self._is_system_message(text):
                continue

            # 日期行
            if self.DATE_PATTERN.match(text):
                current_date = text
                continue

            # 时间行 (可能是消息的时间戳)
            time_match = self.TIME_PATTERN.match(text)
            if time_match:
                # 保存前一条消息
                if current_sender and pending_content:
                    content = "\n".join(pending_content)
                    if content.strip():
                        role = "self" if current_sender == self_name else "other"
                        messages.append(WeChatMessage(
                            sender=current_sender,
                            content=content,
                            timestamp=f"{current_date} {time_match.group(1)}" if current_date else time_match.group(1),
                            role=role,
                            read_at=datetime.now().isoformat(),
                        ))
                    pending_content = []
                continue

            # 检查是否是发送者名字行
            if self._looks_like_sender(text):
                # 保存前一条消息
                if current_sender and pending_content:
                    content = "\n".join(pending_content)
                    if content.strip():
                        role = "self" if current_sender == self_name else "other"
                        messages.append(WeChatMessage(
                            sender=current_sender,
                            content=content,
                            role=role,
                            read_at=datetime.now().isoformat(),
                        ))
                    pending_content = []
                current_sender = text
                continue

            # 消息内容
            pending_content.append(text)

        # 最后一条
        if current_sender and pending_content:
            content = "\n".join(pending_content)
            if content.strip():
                role = "self" if current_sender == self_name else "other"
                messages.append(WeChatMessage(
                    sender=current_sender,
                    content=content,
                    role=role,
                    read_at=datetime.now().isoformat(),
                ))

        return messages

    def _is_system_message(self, text: str) -> bool:
        """判断是否是系统消息。"""
        return any(sys_text in text for sys_text in SYSTEM_MESSAGES)

    def _looks_like_sender(self, text: str) -> bool:
        """判断是否像是发送者名字（非内容）。"""
        # 发送者名字通常较短，不含特殊标点
        if len(text) > 30:
            return False
        # 不含句号、逗号等消息中常见标点
        if any(c in text for c in "。，！？、；：…"):
            return False
        # 不以常见消息开头词开始
        if any(text.startswith(w) for w in ("你好", "在吗", "好的", "嗯", "哈哈", "谢谢")):
            return False
        return True


# ============================================================================
# 微信窗口管理器（主入口）
# ============================================================================

class WeChatWindowReader:
    """微信桌面端窗口读取器。

    功能：
    1. 检测微信是否运行
    2. 读取当前聊天面板的消息
    3. 获取联系人列表
    4. 监控消息变化

    用法:
        reader = WeChatWindowReader()
        if reader.is_wechat_running():
            state = reader.capture_state()
            print(f"当前聊天: {state.current_chat}")
            for msg in state.message_list:
                print(f"[{msg.sender}] {msg.content}")
    """

    def __init__(self, config: dict = None):
        cfg = (config or {}).get("wechat_window", {})
        self.self_name = cfg.get("self_name", "我")
        self.poll_interval = cfg.get("poll_interval", 2.0)
        self.max_messages = cfg.get("max_messages", 200)

        self._uia_reader = UIAutomationReader()
        self._parser = WeChatMessageParser()
        self._callbacks: List[Callable] = []
        self._monitoring = False
        self._last_state_hash = ""

    def is_wechat_running(self) -> bool:
        """检查微信桌面端是否在运行。"""
        return len(find_wechat_windows()) > 0

    def get_wechat_windows(self) -> List[Dict[str, Any]]:
        """获取所有微信窗口信息。"""
        windows = find_wechat_windows()
        return [
            {
                "hwnd": hwnd,
                "class_name": class_name,
                "title": title,
            }
            for hwnd, class_name, title in windows
        ]

    def capture_state(self) -> WeChatWindowState:
        """捕获当前微信窗口状态（一次性快照）。"""
        windows = find_wechat_windows()
        if not windows:
            return WeChatWindowState(is_open=False, detected_at=datetime.now().isoformat())

        # 取主窗口
        main_hwnd, main_class, main_title = windows[0]

        # 读取文本元素
        texts = self._uia_reader.read_element_text(main_hwnd)

        # 解析消息
        messages = self._parser.parse_messages(texts, self_name=self.self_name)

        # 提取当前聊天对象名（通常在窗口标题中）
        current_chat = self._extract_chat_name(main_title)

        # 提取联系人列表
        contacts = self._extract_contacts(texts)

        return WeChatWindowState(
            is_open=True,
            window_title=main_title,
            current_chat=current_chat,
            contact_list=contacts,
            message_list=messages[:self.max_messages],
            detected_at=datetime.now().isoformat(),
            metadata={
                "window_count": len(windows),
                "text_elements": len(texts),
                "uia_available": self._uia_reader.available,
            },
        )

    def read_messages(self) -> List[WeChatMessage]:
        """快捷方法：只读取消息列表。"""
        state = self.capture_state()
        return state.message_list

    def on_new_message(self, callback: Callable[[List[WeChatMessage]], None]):
        """注册新消息回调。"""
        self._callbacks.append(callback)

    def start_monitoring(self) -> bool:
        """启动消息监控（后台线程）。"""
        if self._monitoring:
            return True
        if not self.is_wechat_running():
            logger.warning("微信未运行，无法启动监控")
            return False

        self._monitoring = True
        import threading
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        logger.info("微信消息监控已启动")
        return True

    def stop_monitoring(self):
        """停止消息监控。"""
        self._monitoring = False

    def _monitor_loop(self):
        """监控循环。"""
        seen_hashes = set()
        while self._monitoring:
            try:
                state = self.capture_state()
                new_msgs = []
                for msg in state.message_list:
                    h = hash(f"{msg.sender}:{msg.content}")
                    if h not in seen_hashes:
                        seen_hashes.add(h)
                        new_msgs.append(msg)

                if new_msgs:
                    for cb in self._callbacks:
                        try:
                            cb(new_msgs)
                        except Exception as e:
                            logger.warning(f"消息回调异常: {e}")

                # 限制 seen_hashes 大小
                if len(seen_hashes) > 5000:
                    seen_hashes = set(list(seen_hashes)[-2000:])

            except Exception as e:
                logger.debug(f"监控循环异常: {e}")

            time.sleep(self.poll_interval)

    def _extract_chat_name(self, title: str) -> str:
        """从窗口标题提取聊天对象名。"""
        # 微信窗口标题通常是 "微信" 或 "微信 - 聊天对象名"
        if " - " in title:
            return title.split(" - ", 1)[1].strip()
        if "—" in title:
            return title.split("—", 1)[1].strip()
        return title

    def _extract_contacts(self, texts: List[str]) -> List[WeChatContact]:
        """从文本元素中提取联系人列表（启发式）。"""
        contacts = []
        for text in texts:
            # 联系人名字通常较短
            if 1 < len(text) <= 20:
                # 排除明显不是联系人的文本
                if not any(c in text for c in "。，！？、；：…"):
                    if not self._parser._is_system_message(text):
                        contacts.append(WeChatContact(name=text))
        return contacts[:50]  # 限制数量

    def get_status(self) -> Dict[str, Any]:
        """获取读取器状态。"""
        return {
            "wechat_running": self.is_wechat_running(),
            "monitoring": self._monitoring,
            "uia_available": self._uia_reader.available,
            "self_name": self.self_name,
            "windows": self.get_wechat_windows(),
        }


# ============================================================================
# 便捷函数
# ============================================================================

_global_reader: Optional[WeChatWindowReader] = None


def get_reader(config: dict = None) -> WeChatWindowReader:
    """获取全局微信窗口读取器。"""
    global _global_reader
    if _global_reader is None:
        _global_reader = WeChatWindowReader(config)
    return _global_reader


def quick_read(config: dict = None) -> List[WeChatMessage]:
    """快速读取当前微信消息。"""
    reader = WeChatWindowReader(config)
    return reader.read_messages()


# ============================================================================
# 自检
# ============================================================================

def self_check() -> Dict[str, Any]:
    """自检。"""
    result = {
        "module": "wechat_window_reader",
        "version": "4.0.0",
        "platform": sys.platform,
        "platform_supported": sys.platform == "win32",
    }

    if sys.platform == "win32":
        reader = WeChatWindowReader()
        result["wechat_running"] = reader.is_wechat_running()
        result["uia_available"] = reader._uia_reader.available
        result["windows"] = reader.get_wechat_windows()
    else:
        result["note"] = "仅支持 Windows 平台"

    # 测试解析器
    parser = WeChatMessageParser()
    test_texts = ["张三", "14:32", "你好啊", "李四", "14:33", "在的呢"]
    parsed = parser.parse_messages(test_texts)
    result["parser_test"] = {
        "input_count": len(test_texts),
        "parsed_count": len(parsed),
    }

    return result


if __name__ == "__main__":
    import json
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))