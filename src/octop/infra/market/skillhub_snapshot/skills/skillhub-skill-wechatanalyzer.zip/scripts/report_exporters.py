#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
报告导出器 v5.0.0 (report_exporters.py)

HTML 报告适合看，但要"贴进周报""拖进表格做二次统计"就得不到的形态。
这里补两条导出：

- Markdown：给飞书/Notion/GitHub 直接粘，人和模型都能读。
- CSV：一行一个指标，给 Excel / BI 做透视。

两者共用 _analyzer_facts()，所以不会出现"HTML 里有、Markdown 里漏了"
这种同一份分析三个口径的问题。零依赖，纯 stdlib。

用法:
    from scripts.report_exporters import write_report
    write_report("markdown", results, meta, "report.md", insights=insights)
"""
import csv
import io
import json
import os
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

if not __package__:  # python scripts/report_exporters.py 直跑时补仓库根目录
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from core.version import __version__ as VERSION
except ImportError:  # pragma: no cover
    VERSION = "5.0.0"

# 事实抽取时优先展示的顺序（未列出的分析器落到通用分支）
_FACT_ORDER = ("mbti", "bigfive", "sentiment", "relationship", "risk",
               "privacy", "group", "topic", "pattern", "scenario", "inference",
               "interpretation")

_RISK_CN = {"high": "高", "medium": "中", "low": "低"}


def _details(results: Dict[str, Any], name: str) -> Dict[str, Any]:
    entry = (results or {}).get(name) or {}
    details = entry.get("details") or {}
    return {} if "error" in details else details


def message_meta(messages) -> Dict[str, Any]:
    """从 Message 列表算出报告头需要的元数据。

    CLI、MCP 工具、快照都要同一份口径，两处各写一遍迟早对不上数。
    """
    messages = list(messages or [])
    self_count = sum(1 for m in messages if m.is_self())
    other_count = sum(1 for m in messages if m.is_other())
    meta: Dict[str, Any] = {
        "total_messages": len(messages),
        "self_messages": self_count,
        "other_messages": other_count,
        "participants": len({m.sender for m in messages if m.sender}),
    }
    timestamps = [m.timestamp for m in messages if getattr(m, "timestamp", None)]
    if len(timestamps) >= 2:
        meta["time_span"] = {"start": min(timestamps).isoformat(),
                             "end": max(timestamps).isoformat()}
    return meta


def _pct(value: Any) -> str:
    try:
        return f"{float(value):.1f}%"
    except (TypeError, ValueError):
        return str(value)


def _analyzer_facts(name: str, result: Dict[str, Any]) -> List[Tuple[str, str]]:
    """把一个分析器结果压成 [(指标, 取值)]，Markdown 与 CSV 共用。"""
    details = result.get("details") or {}
    if "error" in details:
        return [("状态", f"分析失败：{details['error']}")]
    facts: List[Tuple[str, str]] = [
        ("综合得分", f"{result.get('score', 0):.1f}"),
        ("置信度", f"{result.get('confidence', 0):.1f}%"),
    ]

    if name == "mbti":
        facts = [("MBTI 类型", details.get("type", "未知")),
                 ("别名", details.get("name", "")),
                 ("维度描述", details.get("dim_description", "")),
                 ("样本量", str(details.get("sample_size", ""))),
                 ("稳定性", _pct(float(details.get("stability", 0) or 0) * 100)),
                 ("置信度", f"{result.get('confidence', 0):.1f}%")]
        if details.get("insufficient_signal"):
            facts.append(("提示", "信号不足，类型仅供参考"))

    elif name == "bigfive":
        for key, dim in (details.get("dimensions") or {}).items():
            label = (dim or {}).get("label", key)
            facts.append((f"{label}({key})", f"{(dim or {}).get('score', 0):.1f}"))

    elif name == "sentiment":
        facts = [("正面占比", _pct(details.get("positive", 0))),
                 ("负面占比", _pct(details.get("negative", 0))),
                 ("中性占比", _pct(details.get("neutral", 0))),
                 ("趋势", {"up": "上升", "down": "下降", "stable": "平稳"}.get(
                     details.get("trend", "stable"), "平稳"))]
        if details.get("irony_count"):
            facts.append(("反讽条数", str(details["irony_count"])))
        if details.get("turning_points"):
            facts.append(("情感转折点", str(len(details["turning_points"]))))

    elif name == "relationship":
        facts = [("健康度", f"{details.get('health_score', 0):.1f}"),
                 ("等级", details.get("grade_label", "")),
                 ("冷回复比例", _pct(float(details.get("cold_reply_ratio", 0) or 0) * 100))]
        for key, value in (details.get("dimensions") or {}).items():
            facts.append((f"维度 {key}", f"{value:.1f}"))
        for idx, sug in enumerate((details.get("suggestions") or [])[:3], 1):
            facts.append((f"建议{idx}", sug))

    elif name == "risk":
        facts = [("总体等级", _RISK_CN.get(details.get("overall_level", "low"), "低")),
                 ("风险分", f"{details.get('risk_score', 0):.1f}")]
        for rtype, data in (details.get("risks") or {}).items():
            level = _RISK_CN.get((data or {}).get("level", "low"), "低")
            hits = (data or {}).get("keyword_count", 0)
            facts.append((f"风险 {rtype}", f"{level} / 命中 {hits} 次"))

    elif name == "privacy":
        facts = [("泄露等级", _RISK_CN.get(details.get("level", "none"), "无")),
                 ("命中总数", str(details.get("total_hits", 0))),
                 ("涉及消息数", str(details.get("affected_messages", 0))),
                 ("扫描消息数", str(details.get("scanned_messages", 0)))]
        for ptype, count in (details.get("by_type") or {}).items():
            facts.append((f"隐私 {ptype}", str(count)))

    elif name == "group":
        facts = [("是否群聊", "是" if details.get("is_group") else "否"),
                 ("参与人数", str(details.get("member_count", 0))),
                 ("主导度", f"{details.get('dominance', 0):.2f}")]
        for member in (details.get("roster") or [])[:8]:
            facts.append((f"成员 {member.get('sender', '')}",
                          f"{member.get('messages', 0)} 条 / {member.get('share', 0)}%"))
        if details.get("note"):
            facts.append(("口径说明", details["note"]))

    elif name == "topic":
        keywords = details.get("keywords") or []
        facts.append(("主主题", str(details.get("primary_topic", ""))))
        facts.append(("话题集中度", _pct(details.get("concentration", 0))))
        facts.append(("分词方式", str(details.get("tokenizer", ""))))
        facts.append(("关键词", "、".join(
            str(k.get("word", "")) for k in keywords[:10]) or "—"))
        for entry in (details.get("topics") or [])[:5]:
            facts.append((f"主题 {entry.get('name', '')}",
                          f"{entry.get('share', 0)}% / {entry.get('messages', 0)} 条"))
        rising = (details.get("trend") or {}).get("rising") or []
        declining = (details.get("trend") or {}).get("declining") or []
        if rising:
            facts.append(("升温词", "、".join(str(x.get("word", "")) for x in rising[:5])))
        if declining:
            facts.append(("降温词", "、".join(str(x.get("word", "")) for x in declining[:5])))

    elif name == "pattern":
        init = details.get("initiation") or {}
        rs = details.get("reply_speed") or {}
        if init:
            facts.append(("主动发起", f"我 {init.get('self_pct', 0):.0f}% / "
                                      f"TA {init.get('other_pct', 0):.0f}%"))
        if rs:
            facts.append(("平均回复秒数", f"{rs.get('avg_seconds', 0):.0f}"))
            facts.append(("快速回复", str(rs.get("fast_replies", 0))))
            facts.append(("慢速回复", str(rs.get("slow_replies", 0))))
        if details.get("duration_days") is not None:
            facts.append(("聊天跨度(天)", str(details["duration_days"])))

    elif name == "scenario":
        facts.append(("主场景", str(details.get("primary", ""))))
        for item in (details.get("sorted") or [])[:3]:
            facts.append((f"场景 {item.get('scenario', '')}", str(item.get("weight", 0))))

    elif name == "inference":
        facts.append(("整体判断", str(details.get("overall_verdict", ""))))
        traj = details.get("conversation_trajectory") or {}
        if traj:
            facts.append(("对话走向", json.dumps(traj, ensure_ascii=False)[:160]))

    elif name == "interpretation":
        facts.append(("摘要", str(details.get("summary", ""))))
        intents = details.get("intents") or {}
        if isinstance(intents, dict):
            facts.append(("主导意图", str(intents.get("dominant_intent", ""))))
            counts = intents.get("intent_counts") or {}
            for label, count in _top_counts(counts, 5):
                facts.append((f"意图 {label}", str(count)))
        entities = details.get("entities") or {}
        if isinstance(entities, dict) and entities.get("total_count"):
            facts.append(("实体总数", str(entities["total_count"])))
        topics = details.get("topics") or {}
        for label, value in _top_counts(topics, 5):
            facts.append((f"话题 {label}", str(value)))

    else:
        for key, value in list(details.items())[:10]:
            facts.append((key, _stringify(value)))

    return [(k, str(v).replace("\n", " ").strip()) for k, v in facts if str(v).strip()]


def _stringify(value: Any) -> str:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False)[:160]
    return str(value)[:160]


def _top_counts(container: Any, limit: int = 5) -> List[Tuple[str, Any]]:
    """把 {标签: 计数} 或 [{label, count|weight}] 归一成前 N 项。

    各分析器对"列表"这个概念给的是两种形态（interpretation 给 dict，
    scenario 给 list[dict]），这里统一兜住，免得导出器一遇 dict 就
    抛 slice 异常——那会让整份报告直接生成失败。
    """
    if isinstance(container, dict):
        items = sorted(container.items(), key=lambda kv: _as_number(kv[1]), reverse=True)
        pairs = [(str(k), v) for k, v in items]
    elif isinstance(container, (list, tuple)):
        pairs = []
        for entry in container:
            if isinstance(entry, dict):
                label = str(entry.get("label") or entry.get("scenario")
                            or entry.get("name") or entry.get("topic") or "")
                value = entry.get("count", entry.get("weight", entry.get("value", 0)))
                if label:
                    pairs.append((label, value))
            else:
                pairs.append((str(entry), 1))
    else:
        return []
    return [p for p in pairs if p[0]][:limit]


def _as_number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _ordered_names(results: Dict[str, Any]) -> List[str]:
    names = [n for n in _FACT_ORDER if n in (results or {})]
    names += sorted(n for n in (results or {}) if n not in _FACT_ORDER and n != "_meta")
    return names


def _meta_lines(meta: Optional[Dict[str, Any]]) -> List[str]:
    meta = meta or {}
    lines = [f"- 消息总数：{meta.get('total_messages', '未知')}",
             f"- 己方／对方：{meta.get('self_messages', 0)} / {meta.get('other_messages', 0)}"]
    if meta.get("participants") is not None:
        lines.append(f"- 参与人数：{meta['participants']}")
    span = meta.get("time_span") or {}
    if span:
        lines.append(f"- 时间范围：{span.get('start', '')} ~ {span.get('end', '')}")
    return lines


def to_markdown(results: Dict[str, Dict[str, Any]],
                meta: Optional[Dict[str, Any]] = None,
                insights: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    """导出 Markdown 报告。insights 为 attach_insights() 的返回值（可为空）。"""
    from scripts.v2_report_generator import generate_v2_summary
    out: List[str] = [f"# 微信聊天分析报告 v{VERSION}", ""]
    out.append(f"> 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    out.append("")
    try:
        out.append(f"**摘要**：{generate_v2_summary(results)}")
    except Exception:  # noqa: BLE001 - 摘要失败不影响整份报告
        pass
    out.append("")
    out.append("## 数据概览")
    out.extend(_meta_lines(meta))
    out.append("")

    for name in _ordered_names(results):
        facts = _analyzer_facts(name, results[name] or {})
        if not facts:
            continue
        out.append(f"## {name}")
        out.append("")
        out.append("| 指标 | 取值 |")
        out.append("| --- | --- |")
        for label, value in facts:
            out.append(f"| {label.replace('|', '/')} | {value.replace('|', '/')} |")
        out.append("")

    if insights:
        out.append("## AI 洞察")
        out.append("")
        for itype, data in insights.items():
            if not isinstance(data, dict) or data.get("skipped"):
                out.append(f"### {itype}")
                out.append("")
                out.append(f"（未生成：{data.get('reason', '未知原因') if isinstance(data, dict) else data}）")
                out.append("")
                continue
            out.append(f"### {itype}")
            out.append("")
            out.append(data.get("content", "").strip())
            tag = "模板降级" if data.get("is_fallback") else data.get("model", "LLM")
            out.append("")
            out.append(f"<sub>来源：{tag}，耗时 {data.get('latency_ms', 0)} ms</sub>")
            out.append("")

    out.append("---")
    out.append("")
    out.append("本报告由本地规则引擎生成，仅供个人理解参考，不构成心理学、法律或投资建议。")
    return "\n".join(out) + "\n"


def to_csv_text(results: Dict[str, Dict[str, Any]],
                meta: Optional[Dict[str, Any]] = None) -> str:
    """导出 CSV：analyzer, metric, value 三列，可直接透视。"""
    buf = io.StringIO(newline="")
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(["analyzer", "metric", "value"])
    for key, value in _meta_rows(meta):
        writer.writerow(["_meta", key, value])
    for name in _ordered_names(results):
        for label, value in _analyzer_facts(name, results[name] or {}):
            writer.writerow([name, label, value])
    return buf.getvalue()


def _meta_rows(meta: Optional[Dict[str, Any]]) -> List[Tuple[str, str]]:
    meta = meta or {}
    rows = [("total_messages", str(meta.get("total_messages", ""))),
            ("self_messages", str(meta.get("self_messages", ""))),
            ("other_messages", str(meta.get("other_messages", "")))]
    span = meta.get("time_span") or {}
    if span:
        rows.append(("time_start", str(span.get("start", ""))))
        rows.append(("time_end", str(span.get("end", ""))))
    return rows


def write_report(fmt: str,
                 results: Dict[str, Dict[str, Any]],
                 meta: Optional[Dict[str, Any]],
                 output_path: str,
                 insights: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    """按格式落盘并返回路径。UTF-8 with BOM for CSV，方便 Excel 直接双击。"""
    fmt = (fmt or "").lower()
    if fmt in ("markdown", "md"):
        text = to_markdown(results, meta, insights)
        encoding = "utf-8"
    elif fmt == "csv":
        text = to_csv_text(results, meta)
        encoding = "utf-8-sig"
    else:
        raise ValueError(f"不支持的导出格式: {fmt}（可用：markdown / csv）")

    directory = os.path.dirname(os.path.abspath(output_path))
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(output_path, "w", encoding=encoding, newline="") as f:
        f.write(text)
    return output_path


def supported_formats() -> List[str]:
    return ["markdown", "csv"]


if __name__ == "__main__":
    demo_results = {
        "mbti": {"score": 60.0, "confidence": 71.0,
                 "details": {"type": "INFJ", "name": "提倡者", "dim_description": "EI: 内向",
                             "sample_size": 24, "stability": 0.62}},
        "sentiment": {"score": 55.0, "confidence": 60.0,
                      "details": {"positive": 43.1, "negative": 11.1, "neutral": 45.8,
                                  "trend": "up", "turning_points": [{"direction": "up"}]}},
        "privacy": {"score": 20.0, "confidence": 90.0,
                    "details": {"level": "medium", "total_hits": 2, "affected_messages": 2,
                                "scanned_messages": 30, "by_type": {"phone": 1, "email": 1}}},
    }
    demo_meta = {"total_messages": 30, "self_messages": 14, "other_messages": 16}
    print(to_markdown(demo_results, demo_meta))
    print(to_csv_text(demo_results, demo_meta))
