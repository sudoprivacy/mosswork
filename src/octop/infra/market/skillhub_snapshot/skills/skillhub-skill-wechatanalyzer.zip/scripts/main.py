#!/usr/bin/env python3
"""
微信聊天分析助手 - 主入口

完整保留 v1.2.0 CLI 命令（analyze/report/schedule/serve/calendar），
v2.0.0 命令（analyze-v2/predict-v2/graph-stats），
v2.3.0 新增时间感知对话预测与回复时机提示；v2.1.0 新增 demo/doctor/report-v2 + 交互式向导。
v2.5.0 接入友好错误提示（friendly_errors）、predict-v2 --seed 可复现预测、版本号统一。

v2.1.0 新增特性：
- 修复 graph-stats 崩溃（补齐 mirofish/ 本地图谱包）
- 输入文件编码自动检测（utf-8-sig → utf-8 → gb18030）
- 大五人格归一化校准（避免小样本饱和 100%）
- MBTI 稳定性低时给出中文提示
- 分析进度实时反馈
- analyze-v2 支持 --export JSON / --html 单文件报告
- report-v2 从最近一次分析结果生成离线 HTML 报告
- demo 一键体验 / doctor 环境自检
- 无参数启动进入交互式向导
"""

import argparse
import json
import os
import sys
import re
from datetime import datetime
from pathlib import Path

# 禁用 .pyc 生成（避免上传/打包时混入二进制缓存）
sys.dont_write_bytecode = True


# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# v2.5.0：版本号单一来源
from core.version import __version__


def _safe_emoji(text: str) -> str:
    """Replace emoji with plain-text for GBK terminal compatibility."""
    encoding = sys.stdout.encoding or 'utf-8'
    try:
        text.encode(encoding)
        return text
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass
    replacements = {
        '📋': '[规则]', '📊': '[统计]', '🧠': '[MBTI]', '🔬': '[大五]',
        '💬': '[情感]', '⚠️': '[预警]', '🔴': '[高]', '🟡': '[中]',
        '🟢': '[低]', '⚪': '[-]', '💡': '[应对]', '🔮': '[预测]',
        '🎯': '[场景]', '💕': '[恋爱]', '💼': '[工作]', '👥': '[社交]',
        '📌': '[重要]', '📝': '[摘要]', '📅': '[日程]', '✅': '[OK]',
        '📈': '[上升]', '📉': '[下降]', '➡️': '->', '🌟': '*',
        '█': '#', '░': '.', '🤖': '[AI]', '🧪': '[测试]', '📚': '[RAG]',
        '🐟': '[MiroFish]', '🧬': '[图谱]',
    }
    for emoji, alt in replacements.items():
        text = text.replace(emoji, alt)
    return text.encode(encoding, errors='replace').decode(encoding, errors='replace')


# ============== v1.2.0 兼容层 ==============

def load_config():
    """加载配置文件"""
    config_path = Path(__file__).resolve().parent.parent / "config.json"
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def is_llm_configured(config):
    """检查 LLM 是否已配置"""
    llm = config.get('llm', {})
    enabled = llm.get('enabled')
    if enabled is None:
        return bool(llm.get('api_key', '').strip())
    return bool(enabled) and bool(llm.get('api_key', '').strip())


# ============== v1.2.0 命令（保留向后兼容）==============

def cmd_analyze(args):
    """v1.2.0 analyze 命令 - 调用旧 TextAnalyzer"""
    print(_safe_emoji("📋 使用 v1.2.0 分析模式（向后兼容）"))
    print(_safe_emoji("💡 提示：尝试 `analyze-v2` 体验 v2.0.0 新特性（jieba/否定识别/RAG/多智能体）\n"))

    from scripts.text_analyzer import TextAnalyzer
    from scripts.data_manager import DataManager
    from scripts.calendar_manager import CalendarManager
    from scripts.file_importer import MultiFormatImporter

    config = load_config()
    dm = DataManager(config)
    analyzer = TextAnalyzer(config)
    cm = CalendarManager(config)

    messages = _load_messages(args, config, dm)
    if not messages:
        return None

    msg_count = len(messages)
    if msg_count > 500:
        print(f"提示：共 {msg_count} 条消息，数量较多，分析可能需要较长时间。")
    print(f"\n已解析 {msg_count} 条消息，开始分析...")

    use_llm = is_llm_configured(config)

    if use_llm:
        print("[AI增强模式] 检测到LLM API配置，尝试AI增强分析...")
        try:
            from scripts.llm_analyzer import enhance_results
            rule_results = analyzer.analyze(messages)
            results = enhance_results(rule_results, messages, config)
            results['ai_enhanced'] = True
            print("[OK] LLM增强分析完成")
        except Exception as e:
            print(f"[警告] LLM 分析失败（{e}），已切换到本地规则分析")
            results = analyzer.analyze(messages)
            results['ai_enhanced'] = False
    else:
        print("[规则分析模式] LLM未配置，使用本地规则分析")
        results = analyzer.analyze(messages)
        results['ai_enhanced'] = False

    chat_id = dm.save_analysis(results)
    events = cm.extract_events_from_messages(messages, chat_id)
    _display_v1_results(results, events, messages, config)
    return chat_id


def _import_container_text(text: str, platform: str = "auto"):
    """整份导出文件（HTML / CSV / JSON）走多源导入器，返回 v1 格式 dict 列表。

    返回 None 表示"这不是结构化容器，是普通粘贴"，调用方继续用行解析器。
    dm.parse_text_input 只认行式文本：喂 HTML 会把几百行标签当成一条巨型消息，
    分析结果里永远是"1 条消息"，而且没人报错。
    """
    try:
        from scripts.data_source_importer import MultiSourceImporter
    except ImportError:  # pragma: no cover
        return None
    try:
        result = MultiSourceImporter().import_text(text, platform=platform)
    except Exception as e:  # noqa: BLE001 - 导入器坏了不能连累主流程
        print(f"提示：结构化导入失败（{e}），改用逐行解析")
        return None
    if not result.success or not result.messages:
        return None
    detected = str(result.metadata.get("detected_platform") or "")
    # text:* / simple / unknown 都意味着"识别出了行式粘贴"而不是"这是结构化容器"。
    # 特别是 unknown：一句没有冒号的散文若从这里返回，发送者会变成 unknown，
    # self/other 统计就此失真；交给行解析器才能守住"裸行算我说的"这条约定。
    if detected.startswith("text:") or detected in ("simple", "unknown"):
        return None

    legacy = []
    for m in result.messages:
        ts = m.timestamp
        if isinstance(ts, str) and ts:
            from core.utils import parse_timestamp
            ts = parse_timestamp(ts)
        legacy.append({
            "sender": m.sender or "unknown",
            "content": m.content,
            "timestamp": ts.isoformat() if isinstance(ts, datetime) else None,
            "type": "text",
            "msg_type": "text",
        })
    print(_safe_emoji(
        f"📥 结构化导入：{detected or result.source} → {len(legacy)} 条消息"))
    return legacy


def _load_messages(args, config, dm) -> list:
    """从不同来源加载消息（粘贴/文件/导入）"""
    platform = getattr(args, "platform", "auto") or "auto"

    if args.paste:
        print("\n请粘贴聊天记录内容，完成后输入 END（单独一行）后回车：")
        print('(支持从微信直接复制粘贴，只需包含"发送者: 内容"格式)\n')
        print('(也支持整份导出：聊天 HTML 源码 / CSV 表格 / JSON 数组)\n')
        lines = []
        while True:
            try:
                line = input()
            except EOFError:
                break
            if line.strip() == "END":
                break
            lines.append(line)
        text = "\n".join(lines)
        if not text.strip():
            print("错误：未输入任何内容")
            return None
        return _import_container_text(text, platform) or dm.parse_text_input(text)

    elif args.input:
        # v2.1.0：自动检测文件编码（utf-8-sig → utf-8 → gb18030）
        from core.utils import read_text_auto
        try:
            text, used_enc = read_text_auto(args.input)
        except (FileNotFoundError, ValueError) as e:
            print(f"错误：{e}")
            return None
        if used_enc not in ("utf-8", "utf-8-sig"):
            print(f"提示：检测到文件编码为 {used_enc}，已自动转换")
        return _import_container_text(text, platform) or dm.parse_text_input(text)

    elif args.file:
        from scripts.file_importer import MultiFormatImporter
        importer = MultiFormatImporter(config)
        messages = importer.import_file(args.file)
        if not messages:
            print(f"错误：无法解析文件 {args.file}")
            return None
        print(f"已导入 {len(messages)} 条消息")
        return messages

    print("错误：未指定输入（使用 --paste/--input/--file）")
    return None


def _display_v1_results(results, events, messages, config):
    """v1.2.0 结果展示"""
    stats = results.get('stats', {})
    mbti = results.get('mbti', {})
    big_five = results.get('big_five', {})
    sentiment = results.get('sentiment', {})
    prediction = results.get('prediction', {})
    risks = results.get('risks', {})

    print(f"\n{'='*55}")
    print(_safe_emoji("   微信聊天分析报告"))
    print(f"{'='*55}")

    print(f"\n[统计] 聊天统计")
    print(f"  总消息数: {stats.get('total_messages', 0)}")
    print(f"  对方消息: {stats.get('other_messages', 0)}")
    print(f"  你的消息: {stats.get('self_messages', 0)}")

    if mbti and mbti.get('type') and mbti.get('type') != '未知':
        print(f"\n[MBTI] {mbti.get('type')} - {mbti.get('name', '未知')} (置信度 {mbti.get('confidence', 0):.0f}%)")

    if big_five and big_five.get('openness', 0) > 0:
        print(f"\n[大五] 大五人格分析")
        labels = big_five.get('labels', {
            'openness': '开放性', 'conscientiousness': '尽责性',
            'extraversion': '外向性', 'agreeableness': '宜人性', 'neuroticism': '神经质'
        })
        for key in ['openness', 'conscientiousness', 'extraversion', 'agreeableness', 'neuroticism']:
            val = big_five.get(key, 50)
            bar = '#' * int(val / 10) + '.' * (10 - int(val / 10))
            print(f"  {labels[key]}: [{bar}] {val:.0f}%")

    if sentiment:
        trend_map = {'up': '[上升]', 'down': '[下降]', 'stable': '[稳定]'}
        print(f"\n[情感] 趋势: {trend_map.get(sentiment.get('trend', 'stable'), '')}")

    if risks and not risks.get('no_risk_detected'):
        print(f"\n[风险预警]")
        for risk_type, data in risks.items():
            if risk_type == 'no_risk_detected':
                continue
            level = data.get('risk_level', 'low')
            print(f"  [{level.upper()}] {risk_type}: {data.get('description', '')}")

    if prediction and prediction.get('next_message'):
        print(f"\n[预测] 对方可能说:「{prediction.get('next_message', '')}」")

    if events:
        print(f"\n[日程] 发现 {len(events)} 个事件")
        for ev in events[:3]:
            print(f"  - {ev.get('title', '')} ({ev.get('event_date', '')[:10]})")

    print(f"\n{'='*55}")


def cmd_report(args):
    """v1.2.0 报告生成命令"""
    from scripts.report_generator import ReportGenerator
    from scripts.data_manager import DataManager

    config = load_config()
    dm = DataManager(config)

    chat_id = args.chat_id
    if not chat_id:
        results = dm.get_latest_analysis()
        if results:
            chat_id = results.get('chat_id')
        else:
            print("错误：没有找到可用的分析结果，请先运行 analyze 命令")
            return

    results = dm.get_analysis(chat_id)
    if not results:
        print(f"错误：找不到指定的分析结果 {chat_id}")
        return

    generator = ReportGenerator(config)
    output_path = generator.generate(
        results=results,
        report_type=args.report_type,
        period=args.period
    )
    print(f"报告已生成: {output_path}")
    return output_path


def cmd_schedule(args):
    """v1.2.0 定时任务管理"""
    from scripts.scheduler import SchedulerManager

    config = load_config()
    scheduler = SchedulerManager(config)

    if args.list:
        jobs = scheduler.list_jobs()
        if not jobs:
            print("暂无定时任务")
        else:
            print("=== 定时任务列表 ===")
            for job in jobs:
                print(f"  {job['id']}: {job['name']} ({job['period']})")
    elif args.add:
        scheduler.add_job(
            name=args.name,
            period=args.period,
            chat_id=args.chat_id,
            report_type=args.report_type
        )
        print(f"已添加定时任务: {args.name}")
    elif args.remove:
        scheduler.remove_job(args.name)
        print(f"已删除定时任务: {args.name}")
    elif args.enable:
        scheduler.enable_job(args.name)
        print(f"已启用定时任务: {args.name}")
    elif args.disable:
        scheduler.disable_job(args.name)
        print(f"已禁用定时任务: {args.name}")


def cmd_serve(args):
    """v1.2.0 Web 服务启动"""
    config = load_config()
    # v2.5.0：优先用 config.json 的 server.default_port（此前硬编码 5000 忽略配置）
    port = args.port or config.get('server', {}).get('default_port', 5000)

    use_llm = is_llm_configured(config)
    if use_llm:
        print(_safe_emoji("🤖 [AI模式] LLM API 已配置"))

    from scripts.web_server import create_app
    app = create_app(config)
    print(f"启动Web服务: http://localhost:{port}")
    print("按 Ctrl+C 停止")
    debug_mode = config.get('server', {}).get('debug', False)
    app.run(host='0.0.0.0', port=port, debug=debug_mode)


def cmd_calendar(args):
    """v1.2.0 日历事件"""
    from scripts.calendar_manager import CalendarManager

    config = load_config()
    cm = CalendarManager(config)

    if args.upcoming:
        events = cm.get_upcoming_events(args.days)
        print(f"=== 即将到来的 {len(events)} 个事件 ===")
        for event in events:
            imp = event.get('importance', 'medium').upper()
            print(f"  [{imp}] {event['title']} - {event['event_date'][:10]}")
    elif args.list:
        events = cm.get_events(event_type=args.type, importance=args.importance)
        print(f"=== 所有 {len(events)} 个事件 ===")
        for event in events:
            imp = event.get('importance', 'medium').upper()
            print(f"  [{imp}] {event['title']} - {event['event_date'][:10]} ({event.get('event_type', '')})")
    else:
        print("请使用 --list 或 --upcoming")


# ============== v2.0.0 新命令 ==============

def _make_progress_callback():
    """v2.1.0 分析进度回调：[i/N] name ... 完成 (0.12s)"""
    def callback(event, name, index, total, elapsed):
        if event == "start":
            print(f"  [{index}/{total}] {name} ... ", end="", flush=True)
        elif event == "done":
            print(_safe_emoji(f"完成 ({elapsed:.2f}s) ✅"))
        elif event == "skip":
            print(_safe_emoji("跳过（样本不足或校验未通过）"))
        elif event == "error":
            print(_safe_emoji(f"失败 ({elapsed:.2f}s) ⚠️"))
    return callback


def _v2_message_meta(messages) -> dict:
    """消息统计元数据（口径与 MCP 工具、报告导出共用 message_meta）。"""
    from scripts.report_exporters import message_meta
    return message_meta(messages)


def _maybe_attach_insights(results, messages, config, args) -> dict:
    """按需生成 AI 洞察，返回可序列化字典（未启用时为空 dict）。

    本地分析是主路，AI 只是增强，所以这里任何失败都只打印一行提示，
    绝不抛出去把已经跑完的分析废掉。

    默认不触发：--ai 或 config.ai_insight.attach_to_cli=true 才会走这一步，
    因为"本地零依赖分析"是这个包的立身之本，不该在一次普通 analyze-v2 里
    悄悄发出五次外部请求。
    """
    ai_cfg = (config or {}).get("ai_insight", {})
    requested = bool(getattr(args, "ai", False)) or bool(ai_cfg.get("attach_to_cli", False))
    if not requested or not ai_cfg.get("enabled", True):
        if getattr(args, "ai", False) and not ai_cfg.get("enabled", True):
            print("提示：config.ai_insight.enabled=false，--ai 已忽略")
        return {}

    try:
        from analyzers.ai_insight_engine import attach_insights
    except ImportError as e:
        print(f"提示：AI 洞察模块不可用（{e}）")
        return {}

    text = "\n".join(f"{m.sender}: {m.content}" for m in messages if m.has_content() and m.is_text())
    try:
        return attach_insights({k: v.to_dict() for k, v in results.items()},
                               config=config, messages_text=text)
    except Exception as e:  # noqa: BLE001
        print(f"提示：AI 洞察生成失败（{e}），已跳过")
        return {}


def _print_insights(insights: dict) -> None:
    """终端展示 AI 洞察（跳过项只留一行，不刷屏）。"""
    if not insights:
        return
    print(_safe_emoji("\n🔮 [AI 洞察]"))
    for itype, data in insights.items():
        if not isinstance(data, dict):
            continue
        if data.get("skipped"):
            print(f"  · {itype}: 已跳过（{data.get('reason', '')}）")
            continue
        header = "本地模板" if data.get("is_fallback") else data.get("model") or "LLM"
        print(_safe_emoji(f"\n  ▸ {itype}（{header}）"))
        for line in (data.get("content") or "").strip().splitlines():
            print(f"    {line}")
    if any(d.get("is_fallback") for d in insights.values() if isinstance(d, dict)):
        print("  提示: 未配置 API Key，以上为本地模板输出；设置 DEEPSEEK_API_KEY 可获得真正的 AI 洞察")


def cmd_analyze_v2(args):
    """v2 分析命令 - 使用模块化分析器"""
    print(_safe_emoji(f"🤖 [v{__version__}] 模块化分析引擎"))
    print(_safe_emoji("    jieba分词 + 否定识别 + 程度副词 + 反讽检测 + 风险预警\n"))

    from core.message import messages_from_legacy
    from scripts.data_manager import DataManager
    from scripts.calendar_manager import CalendarManager

    config = load_config()
    dm = DataManager(config)
    cm = CalendarManager(config)

    raw_messages = _load_messages(args, config, dm)
    if not raw_messages:
        return None

    return _run_v2_analysis(messages_from_legacy(raw_messages), raw_messages,
                            config, dm, cm, args)


def _save_session_snapshot(results, messages, config, args) -> None:
    """保存跨会话快照；--no-snapshot 或不启用时静默跳过。"""
    if getattr(args, "no_snapshot", False):
        return
    if not (config or {}).get("session_memory", {}).get("enabled", True):
        return
    try:
        from scripts.session_memory import save_snapshot
        snapshot = save_snapshot({k: v.to_dict() for k, v in results.items()},
                                 meta=_v2_message_meta(messages), config=config,
                                 label=getattr(args, "label", "") or "")
        print(_safe_emoji(f"🗂 已保存会话快照 {snapshot['id']}"
                          f"（{len(snapshot['metrics'])} 项指标），"
                          f"可用 session --compare 看趋势"))
    except Exception as e:  # noqa: BLE001 - 快照失败不影响本次分析
        print(f"提示：会话快照未保存（{e}）")


def cmd_session(args):
    """v5.0.0 跨会话快照：--save / --compare [ID] / 默认列出"""
    from scripts.session_memory import cmd_session as _cmd_session_impl
    return _cmd_session_impl(args, load_config())


def _run_v2_analysis(messages, raw_messages, config, dm, cm, args):
    """v2 分析主流程（analyze-v2 与 capture 共用，避免两条路结果不一致）"""
    from analyzers import create_default_registry

    msg_count = len(messages)
    if msg_count > 500:
        print(f"提示：共 {msg_count} 条消息，建议单次分析不超过 500 条。")
    print(f"\n已解析 {msg_count} 条消息，运行 v2 分析器...")

    # 创建分析器注册中心
    registry = create_default_registry(config)
    print(f"已注册 {len(registry.list())} 个分析器: {', '.join(registry.list())}")

    # 运行所有分析器（v2.1.0：带进度反馈）
    results = registry.run_all(messages, progress_callback=_make_progress_callback())

    # 可选：AI 深度洞察（v5.0.0 接线。默认关，--ai 或 config.ai_insight.attach_to_cli 才发请求）
    insights = _maybe_attach_insights(results, messages, config, args)

    # 显示结果
    _display_v2_results(results, messages, cm, raw_messages, dm, config, insights)

    # v5.0.0：跨会话快照（只存指标不存原文，用于"这次比上次怎么样"）
    _save_session_snapshot(results, messages, config, args)

    # 可选：导出 JSON
    if getattr(args, "export", None):
        export_path = args.export
        try:
            payload = {
                "version": __version__,
                "generated_at": datetime.now().isoformat(),
                "meta": _v2_message_meta(messages),
                "results": {k: v.to_dict() for k, v in results.items()},
            }
            if insights:
                payload["insights"] = insights
            with open(export_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            print(_safe_emoji(f"\n✅ 分析结果已导出: {export_path}"))
        except OSError as e:
            print(f"\n错误：导出失败（{e}）")

    # 可选：生成单文件 HTML 报告
    if getattr(args, "html", None):
        try:
            from scripts.v2_report_generator import V2ReportGenerator
            generator = V2ReportGenerator(config)
            out = generator.generate(
                results={k: v.to_dict() for k, v in results.items()},
                meta=_v2_message_meta(messages),
                output_path=args.html,
                insights=insights,
            )
            print(_safe_emoji(f"✅ HTML 报告已生成: {out}"))
        except Exception as e:
            print(f"错误：HTML 报告生成失败（{e}）")

    # 可选：Markdown / CSV 报告（v5.0.0）
    for fmt, path in (("markdown", getattr(args, "markdown", None)),
                      ("csv", getattr(args, "csv", None))):
        if not path:
            continue
        try:
            from scripts.report_exporters import write_report
            write_report(fmt, {k: v.to_dict() for k, v in results.items()},
                         _v2_message_meta(messages), path, insights=insights)
            print(_safe_emoji(f"✅ {fmt.upper()} 报告已生成: {path}"))
        except Exception as e:
            print(f"错误：{fmt} 报告生成失败（{e}）")

    # 可选：构建 MiroFish 图谱
    if config.get("mirofish", {}).get("enabled", False):
        try:
            from mirofish.core_zep_local import ZepLocalGraph
            graph = ZepLocalGraph()
            count = graph.build_from_messages(messages)
            stats = graph.get_stats()
            print(_safe_emoji(f"\n🧬 [MiroFish] 已构建本地图谱：{count} 条记忆 / {stats['entities']} 实体 / {stats['relations']} 关系"))
        except Exception as e:
            print(f"[MiroFish] 图谱构建失败: {e}")

    return results


def _display_v2_results(results: dict, messages, cm, raw_messages, dm, config,
                        insights=None):
    """v2 结果展示（统一格式）"""
    print(f"\n{'='*60}")
    print(_safe_emoji(f"   微信聊天分析报告 v{__version__}"))
    print(f"{'='*60}")

    # MBTI
    if "mbti" in results:
        mbti = results["mbti"].details
        # v2.5.0：分析器失败时 run_all 返回 {"error": ...} 错误桩，
        # 之前直接 mbti['type'] 会 KeyError 崩溃，这里降级展示。
        if "type" in mbti and "name" in mbti:
            print(_safe_emoji(f"\n🧠 [MBTI] {mbti['type']} - {mbti['name']}"))
            print(f"  置信度: {results['mbti'].confidence:.1f}%")
            print(f"  特征: {mbti.get('dim_description', '')}")
            if "stability" in mbti:
                stability_pct = mbti['stability'] * 100
                print(f"  稳定性: {stability_pct:.0f}%")
                # v2.1.0：稳定性低时给出可解释提示
                if stability_pct < 50:
                    print("  提示: 样本较少或特征不明显，结果仅供参考")
        elif "error" in mbti:
            print(_safe_emoji("\n🧠 [MBTI] 分析失败，已跳过"))
            print(f"   原因: {mbti['error']}")

    # 大五
    if "bigfive" in results:
        bf = results["bigfive"].details
        print(_safe_emoji("\n🔬 [大五] OCEAN 人格分析"))
        for item in bf.get("radar_data", []):
            val = item["value"]
            bar = '#' * int(val / 10) + '.' * (10 - int(val / 10))
            print(f"  {item['label']}: [{bar}] {val:.0f}%")

    # 情感
    if "sentiment" in results:
        sent = results["sentiment"].details
        trend_map = {"up": "[上升]", "down": "[下降]", "stable": "[稳定]"}
        print(_safe_emoji(f"\n💬 [情感] 趋势: {trend_map.get(sent.get('trend', 'stable'), '')}"))
        print(f"  正面: {sent.get('positive', 0):.1f}% / 负面: {sent.get('negative', 0):.1f}% / 中性: {sent.get('neutral', 0):.1f}%")
        if sent.get("irony_count", 0) > 0:
            print(f"  [v2.0.0] 检测到 {sent['irony_count']} 条反讽")
        ew = sent.get("emotional_words", {})
        if ew.get("positive"):
            print(f"  正面词: {', '.join(ew['positive'][:5])}")
        if ew.get("negative"):
            print(f"  负面词: {', '.join(ew['negative'][:5])}")
        # v2.9.0：情感转折点
        tps = sent.get("turning_points", [])
        if tps:
            dir_cn = {"up": "好转", "down": "转差"}
            first = tps[0]
            ts = (first.get("timestamp") or "")[:16].replace("T", " ")
            print(f"  [v2.9.0] 检出 {len(tps)} 个情感转折点，首个：{dir_cn.get(first.get('direction', ''), '')}（{ts}）")

    # 风险
    if "risk" in results:
        risk = results["risk"].details
        print(_safe_emoji("\n⚠️ [风险]"))
        if risk.get("overall_level") == "low" and not risk.get("risks"):
            print(_safe_emoji("  ✅ 未检测到明显风险"))
        else:
            for risk_type, data in risk.get("risks", {}).items():
                level = data.get("level", "low")
                fp = "（可能误报）" if data.get("false_positive_likely") else ""
                print(f"  [{level.upper()}] {risk_type} {fp}")
                print(f"    {data.get('description', '')}")
                print(f"    命中 {data.get('keyword_count', 0)} 次: {', '.join(data.get('matched_keywords', [])[:5])}")
                if data.get("response_strategies", {}).get("diplomatic"):
                    print(f"    [建议]: {data['response_strategies']['diplomatic'][0]}")

    # 场景
    if "scenario" in results:
        scen = results["scenario"].details
        scene_map = {"romantic": "[恋爱]", "work": "[工作]", "social": "[社交]", "important": "[重要]"}
        print(_safe_emoji(f"\n🎯 [场景] 主场景: {scene_map.get(scen.get('primary', 'social'), '')}"))
        for item in scen.get("sorted", [])[:3]:
            print(f"    {item['scenario']}: {item['weight']}")

    # 对话模式
    if "pattern" in results:
        pat = results["pattern"].details
        print(_safe_emoji("\n📊 [模式] 对话模式分析"))
        if pat.get("initiation"):
            init = pat["initiation"]
            print(f"  主动发起: 我 {init.get('self_pct', 0):.0f}% / TA {init.get('other_pct', 0):.0f}%")
        if pat.get("reply_speed"):
            rs = pat["reply_speed"]
            print(f"  平均回复: {rs.get('avg_seconds', 0):.0f} 秒")
            print(f"  快速回复 (<1分钟): {rs.get('fast_replies', 0)}")
            print(f"  慢速回复 (>1小时): {rs.get('slow_replies', 0)}")
        if pat.get("duration_days") is not None:
            print(f"  聊天跨度: {pat['duration_days']} 天")

    # v6.0.0：话题地图（关键词 / 主题分布 / 人物关注点 / 冷热）
    if "topic" in results:
        topic = results["topic"].details
        if topic.get("available"):
            print(_safe_emoji("\n🗺️ [话题] 话题地图"))
            kws = topic.get("keywords", [])
            if kws:
                print("  高频词: " + "、".join(
                    f"{k['word']}({k['count']})" for k in kws[:8]))
            topics = topic.get("topics", [])
            if topics:
                print("  主题: " + " / ".join(
                    f"{t['name']} {t['share']:.0f}%" for t in topics[:4]))
            speaker = topic.get("by_speaker", {})
            self_top = (speaker.get("self") or [{}])[0].get("word")
            other_top = (speaker.get("other") or [{}])[0].get("word")
            if self_top and other_top:
                print(f"  我关注: {self_top} / TA 关注: {other_top}")
            trend = topic.get("trend", {})
            if trend.get("rising"):
                print("  升温: " + "、".join(x["word"] for x in trend["rising"][:4]))
            if trend.get("declining"):
                print("  降温: " + "、".join(x["word"] for x in trend["declining"][:4]))
            shifts = topic.get("topic_shifts", [])
            if shifts:
                first = shifts[0]
                print(f"  话题切换 {len(shifts)} 次，最近一次：{first['from']} → {first['to']}")
            if topic.get("tokenizer") == "fallback":
                print(f"  提示: {topic.get('tokenizer_note', '')}")
        elif topic.get("reason"):
            print(_safe_emoji(f"\n🗺️ [话题] {topic['reason']}"))

    # v2.9.0：关系健康度（五维评估 + 建议）
    if "relationship" in results:
        rel = results["relationship"].details
        if "health_score" in rel:
            print(_safe_emoji("\n💞 [关系] 关系健康度"))
            print(f"  综合得分: {rel['health_score']:.0f} / 100（{rel.get('grade_label', '')}）")
            dim_labels = {
                "balance": "互动平衡", "responsiveness": "回应度",
                "emotional_sync": "情感同步", "engagement": "投入度", "depth": "互动深度",
            }
            for key, label in dim_labels.items():
                val = rel.get("dimensions", {}).get(key)
                if val is None:
                    continue
                bar = '#' * int(val / 10) + '.' * (10 - int(val / 10))
                print(f"  {label}: [{bar}] {val:.0f}")
            if rel.get("cold_reply_ratio", 0) > 0:
                print(f"  冷回复比例: {rel['cold_reply_ratio']*100:.0f}%")
            for s in rel.get("suggestions", [])[:2]:
                print(_safe_emoji(f"  💡 {s}"))

    # v5.0.0：群聊多主体
    if "group" in results:
        grp = results["group"].details
        if grp.get("is_group"):
            print(_safe_emoji(f"\n👥 [群聊] {grp.get('member_count', 0)} 位成员"))
        else:
            print(_safe_emoji(f"\n👥 [参与者] {grp.get('member_count', 0)} 位"))
        for m in grp.get("roster", [])[:6]:
            bar = '#' * int(m["share"] / 5) + '.' * max(0, 20 - int(m["share"] / 5))
            print(f"  {m['sender'][:10]:<10} [{bar}] {m['share']:>5.1f}% "
                  f"{m['messages']}条 [{m['tier']}]")
        edges = grp.get("mention_edges", [])
        if edges:
            print("  @提及: " + "、".join(
                f"{e['from']}→{e['to']}({e['count']})" for e in edges[:5]))
        pairs = grp.get("top_pairs", [])
        if pairs:
            print(f"  互动最多: {pairs[0]['pair']}（{pairs[0]['turns']} 次交替）")
        note = grp.get("note", "")
        if note:
            print(_safe_emoji(f"  💡 {note}"))

    # v5.0.0：本地隐私扫描
    if "privacy" in results:
        priv = results["privacy"].details
        hits = priv.get("total_hits", 0)
        if hits:
            print(_safe_emoji(f"\n🔒 [隐私] 检出 {hits} 处可直接定位信息"))
            for ptype, info in sorted(priv.get("by_type", {}).items(),
                                      key=lambda kv: -kv[1]["count"]):
                print(f"  [{info.get('risk_label', '')}] {info['label']} × {info['count']}")
            print("  建议：对外分享报告或让 AI 解读前先脱敏（PrivacyScanner.mask_text）")
        else:
            print(_safe_emoji("\n🔒 [隐私] 未发现可直接定位到个人的信息"))

    # v5.0.0：AI 深度洞察
    _print_insights(insights or {})

    # 日历事件
    try:
        payload = {"v2_results": {k: v.to_dict() for k, v in results.items()}}
        if insights:
            # 存下来，report-v2 才能在不重新调用 LLM 的情况下复现同一份洞察
            payload["insights"] = insights
        chat_id = dm.save_analysis(payload)
        events = cm.extract_events_from_messages(raw_messages, chat_id)
        if events:
            print(_safe_emoji(f"\n📅 [日程] 发现 {len(events)} 个事件"))
            for ev in events[:3]:
                print(f"  - {ev.get('title', '')} ({ev.get('event_date', '')[:10]})")
    except Exception:
        pass

    # v2.1.0：一句话总结（规则生成，放在分隔线内）
    try:
        from scripts.v2_report_generator import generate_v2_summary
        summary = generate_v2_summary({k: v.to_dict() for k, v in results.items()})
        if summary:
            print(f"\n{'='*60}")
            print(_safe_emoji(f"📝 一句话总结: {summary}"))
    except Exception:
        pass

    print(f"\n{'='*60}")


def _history_profile_path(config) -> str:
    """历史感知画像文件路径（规则与 MCP 工具共用，见 default_profile_path）。"""
    from predictors.history_aware_predictor import default_profile_path
    return default_profile_path(config)


def _apply_history_profile(ensemble, config) -> str:
    """给 history_aware 预测器加载上次的画像，返回文件路径（空串=未启用）。"""
    path = _history_profile_path(config)
    if not path:
        return ""
    predictor = ensemble.get_predictor("history_aware")
    if predictor is None:
        return ""
    if predictor.load_profile(path) and getattr(predictor, "merge_history", True):
        print(f"  [历史画像] 已载入 {path}（此前 {predictor.trained_sessions} 次会话）")
    return path


def _save_history_profile(ensemble, path: str) -> None:
    predictor = ensemble.get_predictor("history_aware") if path else None
    if predictor is None or not predictor.is_trained():
        return
    try:
        predictor.save_profile(path)
        print(f"  [历史画像] 已保存到 {path}（累计 {predictor.trained_sessions} 次会话）")
    except OSError as e:
        print(f"  [历史画像] 保存失败（{e}），本次画像不会留存")


def cmd_predict_v2(args):
    """v2 三层融合预测"""
    print(_safe_emoji(f"🔮 [v{__version__}] 多层集成预测器"))
    print(_safe_emoji("    Rule + RAG + MiroFish 三层融合\n"))

    from core.message import messages_from_legacy
    from core.predictor_base import PredictionContext
    from analyzers import create_default_registry
    from predictors import create_default_ensemble
    from scripts.data_manager import DataManager

    config = load_config()
    dm = DataManager(config)

    raw_messages = _load_messages(args, config, dm)
    if not raw_messages:
        return

    messages = messages_from_legacy(raw_messages)

    # 1. 先分析得到 MBTI / BigFive / Sentiment / Scenario
    print("[1/3] 运行分析器...")
    registry = create_default_registry(config)
    analysis_results = registry.run_all(messages, progress_callback=_make_progress_callback())

    mbti_type = analysis_results["mbti"].details.get("type") if "mbti" in analysis_results else None
    big_five = analysis_results["bigfive"].details if "bigfive" in analysis_results else None
    sentiment = analysis_results["sentiment"].details if "sentiment" in analysis_results else None
    scenario = analysis_results["scenario"].details.get("primary", "social") if "scenario" in analysis_results else "social"

    print(f"  MBTI: {mbti_type or '未知'}")
    print(f"  场景: {scenario}")

    # 2. 构建预测上下文
    print("\n[2/3] 构建预测上下文...")
    context = PredictionContext(
        messages=messages,
        mbti=mbti_type,
        big_five=big_five,
        sentiment=sentiment,
        scenario=scenario,
        recent_window=3,
    )

    # 3. 运行集成预测
    print("\n[3/3] 运行三层集成预测...")

    # v2.5.0：--seed 可复现预测（MiroFish 随机选择确定性化）
    seed = getattr(args, "seed", None)
    if seed is not None:
        config.setdefault("mirofish", {})["seed"] = seed
        print(f"  [随机种子] {seed}（预测结果可复现）")

    ensemble = create_default_ensemble(config)
    print(f"  已加载预测器: {', '.join(ensemble.list_predictors())}")

    profile_path = _apply_history_profile(ensemble, config)
    result = ensemble.predict(context)
    _save_history_profile(ensemble, profile_path)

    print(f"\n{'='*60}")
    print(_safe_emoji("   对话预测结果"))
    print(f"{'='*60}")
    print(f"\n[最佳预测] 置信度 {result.top_prediction.confidence*100:.1f}%")
    print(f"  策略: {result.top_prediction.strategy}")
    print(f"  内容: 「{result.top_prediction.text}」")
    if result.top_prediction.rationale:
        print(f"  依据: {result.top_prediction.rationale}")

    if result.alternatives:
        print(f"\n[备选预测] (共 {len(result.alternatives)} 条)")
        for i, alt in enumerate(result.alternatives, 1):
            print(f"  {i}. [{alt.confidence*100:.0f}%] ({alt.strategy}) 「{alt.text}」")

    if result.metadata.get("predictors_used"):
        print(f"\n[使用预测器] {', '.join(result.metadata['predictors_used'])}")
    if result.metadata.get("total_candidates"):
        print(f"[候选总数] {result.metadata['total_candidates']}")

    timing = result.context.get("timing") or result.metadata.get("timing")
    if timing:
        urgency_label = {
            "immediate": "立即回复",
            "soon": "尽快回复",
            "today": "今天内回复",
            "stale": "隔太久，先主动找回联系",
            "unknown": "时间未知",
        }.get(timing.get("urgency", ""), timing.get("urgency", "未知"))
        age = timing.get("last_message_age_minutes")
        age_text = f"，距最后消息约 {age:.0f} 分钟" if age is not None else ""
        print(f"[回复时机] {urgency_label}{age_text}")


def cmd_graph_stats(args):
    """v2 MiroFish 图谱统计"""
    print(_safe_emoji(f"🧬 [v{__version__}] MiroFish 本地图谱统计\n"))

    from mirofish.core_zep_local import ZepLocalGraph
    graph = ZepLocalGraph()
    stats = graph.get_stats()

    print(f"实体数: {stats['entities']}")
    print(f"关系数: {stats['relations']}")
    print(f"记忆数: {stats['memories']}")

    if stats['entities'] > 0:
        graph_data = graph.get_graph()
        print(f"\n[实体 Top 10]")
        # 按出现频率排
        from collections import Counter
        ent_counter = Counter(e['name'] for e in graph_data['entities'])
        for name, count in ent_counter.most_common(10):
            print(f"  {name}: {count}")

        if graph_data['relations']:
            print(f"\n[关系 Top 10]")
            rel_counter = Counter()
            for r in graph_data['relations']:
                rel_counter[r['type']] += 1
            for rel_type, count in rel_counter.most_common(10):
                print(f"  {rel_type}: {count}")


# ============== v2.1.0 新命令 ==============

def cmd_report_v2(args):
    """报告命令 - 用最近一次 analyze-v2 结果生成离线报告（HTML / Markdown / CSV）"""
    fmt = (getattr(args, "format", None) or "html").lower()
    print(_safe_emoji(f"📊 [v5.0.0] 生成 {fmt.upper()} 报告\n"))

    from scripts.data_manager import DataManager

    config = load_config()
    dm = DataManager(config)

    latest = dm.get_latest_analysis()
    if not latest or "v2_results" not in latest:
        print("未找到 v2 分析结果。")
        print(_safe_emoji("💡 请先运行: python scripts/main.py analyze-v2 --input <文件> "
                          "（或 --paste），再执行 report-v2"))
        return None

    results = latest["v2_results"]
    insights = latest.get("insights") or None
    meta = {"total_messages": None, "chat_id": latest.get("chat_id")}

    from scripts.v2_report_generator import V2ReportGenerator
    generator = V2ReportGenerator(config)

    if fmt in ("markdown", "md", "csv"):
        from scripts.report_exporters import write_report
        output_path = getattr(args, "output", None)
        if not output_path:
            # 与 HTML 报告同一个目录口径（core.data_paths），不在技能包里落产物
            output_dir = Path(generator.reports_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            ext = "md" if fmt.startswith("mark") else "csv"
            output_path = str(output_dir / f"v2_report_{datetime.now():%Y%m%d_%H%M%S}.{ext}")
        write_report("markdown" if fmt.startswith("mark") else fmt,
                     results, meta, output_path, insights=insights)
        print(f"✅ {fmt.upper()} 报告已生成: {output_path}")
        return output_path

    output_path = generator.generate(
        results=results,
        meta=meta,
        output_path=getattr(args, "output", None),
        insights=insights,
    )
    print(_safe_emoji(f"✅ HTML 报告已生成: {output_path}"))
    return output_path


def cmd_capture(args):
    """v5.0.0 桌面捕获 → 直接分析。

    之前窗口读取/剪贴板监控只有 MCP 工具能调，CLI 用户必须先抓再自己拼成
    文本喂 analyze-v2，等于没有这条路。
    """
    import sys as _sys
    print(_safe_emoji(f"📸 [v{__version__}] 桌面微信捕获"))

    if _sys.platform != "win32":
        print(f"当前平台 {_sys.platform} 不支持窗口/剪贴板捕获（仅 Windows）。")
        print("请改用: python scripts/main.py analyze-v2 --input <导出的聊天记录>")
        return None

    source = getattr(args, "source", "window") or "window"
    config = load_config()
    raw_messages = None
    chat_name = f"{source} 捕获"

    if source == "clipboard":
        from scripts.clipboard_monitor import ClipboardMonitor
        seconds = int(getattr(args, "seconds", 15) or 15)
        monitor = ClipboardMonitor(config)
        if not monitor.start():
            print("剪贴板监听启动失败（无法创建窗口消息循环）")
            return None
        print(f"监听 {seconds}s：请在微信里选中聊天记录并 Ctrl+C 复制…")
        try:
            import time as _time
            deadline = _time.time() + seconds
            while _time.time() < deadline and not monitor.get_history():
                _time.sleep(0.3)
        finally:
            monitor.stop()
        captured = monitor.get_history(limit=500)
        raw_messages = [{"sender": m.sender or "unknown", "content": m.content,
                         "timestamp": m.timestamp, "type": "text", "msg_type": "text"}
                        for m in captured if m.content]
    else:
        from scripts.wechat_window_reader import WeChatWindowReader
        reader = WeChatWindowReader(config)
        if not reader.is_wechat_running():
            print("未找到微信桌面端窗口。请确认微信已登录并打开，或使用 --source clipboard。")
            return None
        state = reader.capture_state()
        if not getattr(state, "is_open", False):
            print("微信窗口读取失败（可能未开启辅助功能权限）。")
            return None
        print(f"当前会话：{state.current_chat or '未知'}，读到 {len(state.message_list)} 条消息")
        raw_messages = [{"sender": m.sender or "unknown", "content": m.content,
                         "timestamp": m.timestamp or None, "type": m.message_type or "text",
                         "msg_type": m.message_type or "text"}
                        for m in state.message_list if m.content]

    if not raw_messages:
        print("没有捕获到可分析的消息。")
        return None

    from core.message import messages_from_legacy
    from scripts.data_manager import DataManager
    from scripts.calendar_manager import CalendarManager
    dm = DataManager(config)
    cm = CalendarManager(config)
    # 捕获结果落库，之后 report-v2 / session 对比都能拿到这一份
    chat_name = state.current_chat or chat_name
    try:
        dm.save_chat(chat_name, raw_messages, source=f"capture:{source}")
    except Exception as e:  # noqa: BLE001 - 落库失败不该拦住分析
        print(f"提示：捕获记录未入库（{e}）")

    return _run_v2_analysis(messages_from_legacy(raw_messages), raw_messages,
                            config, dm, cm, args)


def cmd_demo(args):
    """v2.1.0 一键演示 - 分析内置示例数据并生成 HTML 报告"""
    print(_safe_emoji(f"🌟 [v{__version__}] 一键演示：使用内置示例聊天记录\n"))

    # v5.0.0 路径修正：tests/ 下从来只有平铺的 fixtures_sample_chat.txt，
    # 没有 fixtures/ 子目录，demo 命令因此每次都报"示例文件不存在"。
    sample_path = (Path(__file__).resolve().parent.parent
                   / "tests" / "fixtures_sample_chat.txt")
    if not sample_path.exists():
        print(f"错误：示例文件不存在: {sample_path}")
        return None

    # 复用 analyze-v2 全流程（终端展示 + 进度反馈）
    demo_args = argparse.Namespace(
        paste=False, input=str(sample_path), file=None,
        export=None, html=None,
    )
    results = cmd_analyze_v2(demo_args)
    if not results:
        return None

    # 生成 HTML 报告到 data/
    from scripts.v2_report_generator import V2ReportGenerator
    from core.message import messages_from_legacy
    from core.utils import read_text_auto
    from scripts.data_manager import DataManager

    config = load_config()
    dm = DataManager(config)
    text, _enc = read_text_auto(sample_path)
    messages = messages_from_legacy(dm.parse_text_input(text))

    generator = V2ReportGenerator(config)
    output_path = generator.generate(
        results={k: v.to_dict() for k, v in results.items()},
        meta=_v2_message_meta(messages),
    )
    print(_safe_emoji(f"\n✅ 演示完成！HTML 报告已生成: {output_path}"))
    print(_safe_emoji("💡 用浏览器打开该文件即可查看完整可视化报告（离线可用）"))
    return output_path


def cmd_doctor(args):
    """v2.1.0 环境自检"""
    import platform

    print(_safe_emoji(f"🧪 [v{__version__}] 环境自检\n"))

    ok_mark = _safe_emoji("✅")
    warn_mark = _safe_emoji("⚠️")
    problems = []   # (问题描述, 修复建议)

    def check(label, ok, note="", fix=""):
        mark = ok_mark if ok else warn_mark
        suffix = f" - {note}" if note else ""
        print(f"  {mark} {label}{suffix}")
        if not ok and fix:
            problems.append((label, fix))

    # 1. Python 版本
    py_ver = platform.python_version()
    py_ok = sys.version_info >= (3, 8)
    check(f"Python 版本: {py_ver}", py_ok,
          "" if py_ok else "需要 >= 3.8",
          "请升级 Python 到 3.8 及以上版本")

    # 2. 必需依赖
    try:
        import jieba  # noqa: F401
        check("jieba（必需，精准分词）", True)
    except ImportError:
        check("jieba（必需，精准分词）", False, "未安装",
              "pip install jieba")

    # 3. v1 功能依赖（可选）
    for mod, pkg in [("flask", "flask"), ("docx", "python-docx"), ("pptx", "python-pptx")]:
        try:
            __import__(mod)
            check(f"{pkg}（v1 功能）", True)
        except ImportError:
            check(f"{pkg}（v1 功能）", False, "未安装，v1 报告/Web 功能不可用",
                  f"pip install {pkg}")

    # 4. RAG 可选依赖
    for mod, pkg in [("sentence_transformers", "sentence-transformers"),
                     ("chromadb", "chromadb")]:
        try:
            __import__(mod)
            check(f"{pkg}（RAG 可选）", True)
        except ImportError:
            check(f"{pkg}（RAG 可选）", False, "未安装，RAG 预测自动降级",
                  f"pip install -r requirements-rag.txt")

    # 5. config.json 可解析
    config_path = Path(__file__).resolve().parent.parent / "config.json"
    try:
        config = load_config()
        check("config.json 可解析", True, f"version={config.get('version', '?')}")
    except Exception as e:
        config = {}
        check("config.json 可解析", False, str(e),
              "检查 config.json 是否为合法 JSON")

    # 6. 运行时数据目录可写（不能探技能包内的 data/，否则自检本身就在包里留产物）
    from core.data_paths import resolve_data_dir
    data_dir = resolve_data_dir()
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        probe = data_dir / ".doctor_write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        check(f"运行时数据目录可写（{data_dir}）", True)
    except OSError as e:
        check(f"运行时数据目录可写（{data_dir}）", False, str(e),
              "检查目录权限，或用 WECHAT_ANALYZER_DATA_DIR 指定一个可写目录")

    # 7. stdout 编码
    out_enc = sys.stdout.encoding or "unknown"
    enc_ok = out_enc.lower() not in ("unknown", "ascii")
    check(f"终端输出编码: {out_enc}", enc_ok,
          "" if enc_ok else "可能出现乱码",
          "Windows 可执行 chcp 65001 切换为 UTF-8 代码页")

    # 8. v5.0.0 能力链路自检：装了几个分析器、AI 上下文能不能构造出来、
    #    解析器认不认常见格式、快照与画像有没有落点。
    #    这几项在 v3/v4 都是"模块在、没人调"，坏了也没人知道，所以现在必须看得见。
    try:
        from analyzers import create_default_registry
        registry = create_default_registry(config)
        names = sorted(registry.list())
        check(f"分析器装载: {len(names)} 个", len(names) >= 12,
              "" if len(names) >= 12 else f"预期 12 个，实际 {len(names)}: {', '.join(names)}",
              "检查 analyzers/ 目录是否完整")
    except Exception as e:
        check("分析器装载", False, str(e)[:80], "查看 analyzers/__init__.py 报错")

    try:
        from scripts.data_source_importer import self_check as ms_self_check
        probe = ms_self_check()
        failed = [r["case"] for r in probe.get("test_results", []) if not r.get("match")]
        check("聊天格式解析（微信/QQ/iMessage/JSON/HTML/CSV）", bool(probe.get("all_passed")),
              "" if not failed else f"{len(failed)} 项失败: " + ", ".join(failed[:5]),
              "粘贴的聊天记录可能解析不出内容，先跑 analyze-v2 看消息数")
    except Exception as e:
        check("聊天格式解析", False, str(e)[:80], "检查 scripts/data_source_importer.py")

    try:
        from analyzers.ai_insight_engine import self_check as ai_self_check
        probe = ai_self_check()
        builders = probe.get("context_builders") or {}
        broken = [k for k, v in builders.items() if not v]
        check(f"AI 洞察上下文构造（{len(builders)} 类）", bool(probe.get("context_build_ok")),
              "" if not broken else f"构造失败: {', '.join(broken)}",
              "分析器结果→提示词这条链断了，洞察会整批跳过")
        if not probe.get("api_key_configured"):
            print("     （未配置 DEEPSEEK_API_KEY：AI 洞察会降级成本地模板汇总，不影响本地分析）")
    except Exception as e:
        check("AI 洞察上下文构造", False, str(e)[:80], "检查 analyzers/ai_insight_engine.py")

    try:
        from scripts.session_memory import self_check as sm_self_check
        probe = sm_self_check()
        check("跨会话快照与对比", bool(probe.get("compare_found")) and probe.get("delta_count", 0) > 0,
              "" if probe.get("compare_found") else str(probe)[:80],
              "快照读写有问题，趋势对比不可用")
    except Exception as e:
        check("跨会话快照与对比", False, str(e)[:80], "检查 scripts/session_memory.py")

    try:
        from predictors.history_aware_predictor import default_profile_path
        path = default_profile_path(config)
        check("历史画像持久化", bool(path), path or "已按配置关闭",
              "" if path else "画像不会跨会话保留（history_aware.persist_profile=false）")
    except Exception as e:
        check("历史画像持久化", False, str(e)[:80], "检查 predictors/history_aware_predictor.py")

    try:
        from scripts.report_exporters import supported_formats
        fmts = supported_formats()
        check(f"报告导出格式: {', '.join(fmts)}", "markdown" in fmts and "csv" in fmts,
              "", "Markdown/CSV 导出不可用")
    except Exception as e:
        check("报告导出格式", False, str(e)[:80], "检查 scripts/report_exporters.py")

    # 汇总
    print(f"\n{'='*50}")
    if not problems:
        print(_safe_emoji("✅ 环境自检全部通过，可以正常使用"))
    else:
        print(_safe_emoji(f"⚠️ 发现 {len(problems)} 个待处理项，修复建议："))
        for i, (label, fix) in enumerate(problems, 1):
            print(f"  {i}. [{label}] {fix}")
    print(f"{'='*50}")
    return len(problems)


def _run_interactive_wizard():
    """v2.1.0 交互式向导（无参数启动时进入）"""
    print(_safe_emoji(f"🌟 欢迎使用微信聊天分析助手 v{__version__}"))
    print("完全本地运行，零数据外传。")
    print(_safe_emoji("💡 提示: 使用 -h 查看全部命令，或运行 demo 一键体验示例数据\n"))

    print("请粘贴聊天记录（每行一条，格式「发送者: 内容」），")
    print("完成后输入 END（单独一行）并回车：\n")

    lines = []
    while True:
        try:
            line = input()
        except (EOFError, KeyboardInterrupt):
            print("\n已取消，再见！")
            return
        if line.strip() == "END":
            break
        lines.append(line)

    text = "\n".join(lines)
    if not text.strip():
        print("未输入任何内容，已退出。")
        print(_safe_emoji("💡 想快速体验？运行: python scripts/main.py demo"))
        return

    # 直接复用 analyze-v2 的分析与展示逻辑
    from core.message import messages_from_legacy
    from analyzers import create_default_registry
    from scripts.data_manager import DataManager
    from scripts.calendar_manager import CalendarManager

    config = load_config()
    dm = DataManager(config)
    cm = CalendarManager(config)

    raw_messages = dm.parse_text_input(text)
    if not raw_messages:
        print("未能从输入中解析出消息，请检查格式（应为「发送者: 内容」）。")
        return

    messages = messages_from_legacy(raw_messages)
    print(f"\n已解析 {len(messages)} 条消息，开始分析...")
    registry = create_default_registry(config)
    results = registry.run_all(messages, progress_callback=_make_progress_callback())
    _display_v2_results(results, messages, cm, raw_messages, dm, config)

    # 询问是否生成 HTML 报告
    try:
        answer = input(_safe_emoji("\n是否生成 HTML 可视化报告？(y/N) ")).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\n已取消报告生成，再见！")
        return
    if answer in ("y", "yes"):
        from scripts.v2_report_generator import V2ReportGenerator
        generator = V2ReportGenerator(config)
        output_path = generator.generate(
            results={k: v.to_dict() for k, v in results.items()},
            meta=_v2_message_meta(messages),
        )
        print(_safe_emoji(f"✅ HTML 报告已生成: {output_path}"))
        print(_safe_emoji("💡 用浏览器打开该文件即可查看（离线可用）"))
    else:
        print("好的，已跳过报告生成。")


def cmd_voice(args):
    """v2.9.0 语音交互命令（SAPI 零依赖降级，说/打字均可）"""
    try:
        from scripts.voice_interface import run_voice_session
    except ImportError:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from voice_interface import run_voice_session
    return run_voice_session()


def cmd_version(args):
    """显示版本信息"""
    print(f"微信聊天分析助手 v{__version__}")
    print(f"\nv{__version__} 新特性:")
    print(_safe_emoji("  🗺 话题地图分析器（TF-IDF 关键词 / 语义主题 / 我 vs 对方关注点 / 冷热变化 / 话题切换）"))
    print(_safe_emoji("  🧩 MCP Server 扩到 31 工具，新增 get_topic_analysis"))
    print(_safe_emoji("  🔌 MCP Server 兼容 mcp 1.x(FastMCP) 与 2.x(MCPServer)"))
    print("\nv5.0.0 新特性:")
    print(_safe_emoji("  🔒 隐私泄露扫描（10 类个人信息 / 银行卡 Luhn 校验 / 一键脱敏 / 送模型前先脱敏）"))
    print(_safe_emoji("  👥 群聊多主体分析（成员占比 / 活跃分层 / 主导度 / 点名关系网 / 双人互动平衡）"))
    print(_safe_emoji("  🗂 session 命令：跨会话快照与趋势对比（--list / --save / --compare）"))
    print(_safe_emoji("  📤 analyze-v2 新增 --markdown / --csv / --platform / --ai / --label"))
    print(_safe_emoji("  🖥 capture 命令：直接从桌面微信读取并分析（Windows）"))
    print(_safe_emoji("  🧩 MCP Server 扩到 30 工具；CLI 共 15 个子命令"))
    print(_safe_emoji("  🐛 修复微信窗口复制格式解析（行首时间戳曾吃掉发送者）与 self/other 口径"))
    print(_safe_emoji("  🧹 运行产物（向量库/模型/报告/截图/快照）不再落进技能包"))
    print("\nv2.9.0 新特性:")
    print(_safe_emoji("  💞 关系健康度分析器（平衡/回应/情感同步/投入/深度五维 + 冷回复惩罚）"))
    print(_safe_emoji("  📈 情感分析增强：滚动趋势 + 转折点检测 + 己方情感占比"))
    print(_safe_emoji("  🎤 语音交互（voice 命令：SAPI 零依赖降级，说/打字均可）"))
    print("\nv2.8.0 新特性:")
    print(_safe_emoji("  🛡 健壮性升级：非法转义修复 / Python 3.15 日期解析兼容 / 裸 except 收紧"))
    print(_safe_emoji("  🧪 全覆盖编译烟囱测试（全部 .py 编译+警告升错误 / 裸 except 防回归 / 版本一致性）"))
    print(_safe_emoji("  🧹 clean.py --check 上传前残留检查（退出码 1=有二进制残留）"))
    print("\nv2.3.0 新特性:")
    print(_safe_emoji("  🔮 时间感知对话预测（消息新鲜度/时间段/周末/连续对话节奏）"))
    print(_safe_emoji("  ⏱ predict-v2 输出回复时机提示（立即/尽快/今天内/隔太久找回联系）"))
    print("\nv2.1.0 新特性:")
    print(_safe_emoji("  🧬 补齐 mirofish/ 本地图谱包（修复 graph-stats 崩溃）"))
    print(_safe_emoji("  📄 输入文件编码自动检测（utf-8-sig / utf-8 / gb18030）"))
    print(_safe_emoji("  📊 大五人格归一化校准（小样本不再轻易饱和 100%）"))
    print(_safe_emoji("  🧠 MBTI 稳定性低时给出中文提示"))
    print(_safe_emoji("  📈 分析进度实时反馈（[i/6] xxx ... 完成）"))
    print(_safe_emoji("  💾 analyze-v2 支持 --export JSON 导出"))
    print(_safe_emoji("  🌐 analyze-v2 --html / report-v2 单文件离线 HTML 报告"))
    print(_safe_emoji("  🌟 demo 一键体验 / doctor 环境自检"))
    print(_safe_emoji("  🧭 无参数启动进入交互式向导"))
    print(_safe_emoji("  📝 终端报告末尾自动生成一句话总结"))
    print(_safe_emoji("  🔮 predict-v2 备选预测按规范化文本去重"))
    print("\nv2.0.0 特性:")
    print(_safe_emoji("  🧠 jieba 精准分词（替代正则分词）"))
    print(_safe_emoji("  💬 否定识别（修复'我不开心'误判）"))
    print(_safe_emoji("  🎭 反讽检测（虽然...但是...）"))
    print(_safe_emoji("  📊 MBTI 新置信度算法（维度差距+样本量）"))
    print(_safe_emoji("  📚 本地 RAG 引擎（sentence-transformers + ChromaDB）"))
    print(_safe_emoji("  🐟 MiroFish 多智能体（8 Agent × N 轮博弈）"))
    print(_safe_emoji("  🔮 三层集成预测（Rule + RAG + MiroFish）"))
    print("\n保留 v1.2.0 兼容命令: analyze, report, schedule, serve, calendar")


def main():
    parser = argparse.ArgumentParser(
        description=f"微信聊天分析助手 v{__version__}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
示例:
  python scripts/main.py                        # 交互式向导（v2.1.0）
  python scripts/main.py demo                   # 一键体验示例数据（v2.1.0）
  python scripts/main.py doctor                 # 环境自检（v2.1.0）
  python scripts/main.py analyze-v2 --paste     # 粘贴分析（带进度反馈）
  python scripts/main.py analyze-v2 --input 1.txt --export result.json
  python scripts/main.py analyze-v2 --input 1.txt --html report.html
  python scripts/main.py report-v2              # 用最近结果生成 HTML 报告
  python scripts/main.py predict-v2 --input 1.txt [--seed 42]  # 三层融合预测
  python scripts/main.py graph-stats            # 查看 MiroFish 图谱
  python scripts/main.py analyze --paste        # v1.2.0 兼容（保留）
  python scripts/main.py version                # 版本信息

首次使用请先运行:
  python scripts/main_setup.py                   # 一键配置
        """
    )
    # v2.5.0：出错时默认显示友好中文提示，--debug 可看完整堆栈。
    # --debug 在子命令前后均可使用（parse_args 前从 argv 中取出）。
    parser.add_argument('--debug', action='store_true',
                        help='出错时显示完整堆栈（默认显示友好提示）')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')

    # ========= v1.2.0 命令（向后兼容）=========
    analyze_parser = subparsers.add_parser('analyze', help='[v1.2.0] 分析聊天记录')
    analyze_parser.add_argument('--paste', action='store_true')
    analyze_parser.add_argument('--input', type=str)
    analyze_parser.add_argument('--file', type=str)
    analyze_parser.set_defaults(func=cmd_analyze)

    report_parser = subparsers.add_parser('report', help='[v1.2.0] 生成报告')
    report_parser.add_argument('--report-type', type=str, default='html',
                              choices=['html', 'pptx', 'word', 'all'])
    report_parser.add_argument('--period', type=str, default='weekly')
    report_parser.add_argument('--chat-id', type=str)
    report_parser.set_defaults(func=cmd_report)

    schedule_parser = subparsers.add_parser('schedule', help='[v1.2.0] 定时任务')
    schedule_parser.add_argument('--list', action='store_true')
    schedule_parser.add_argument('--add', action='store_true')
    schedule_parser.add_argument('--remove', type=str, metavar='NAME')
    schedule_parser.add_argument('--enable', type=str, metavar='NAME')
    schedule_parser.add_argument('--disable', type=str, metavar='NAME')
    schedule_parser.add_argument('--name', type=str)
    schedule_parser.add_argument('--period', type=str)
    schedule_parser.add_argument('--chat-id', type=str)
    schedule_parser.add_argument('--report-type', type=str, default='html')
    schedule_parser.set_defaults(func=cmd_schedule)

    serve_parser = subparsers.add_parser('serve', help='[v1.2.0] 启动Web服务')
    serve_parser.add_argument('--port', type=int)
    serve_parser.set_defaults(func=cmd_serve)

    calendar_parser = subparsers.add_parser('calendar', help='[v1.2.0] 日历事件')
    calendar_parser.add_argument('--list', action='store_true')
    calendar_parser.add_argument('--upcoming', action='store_true')
    calendar_parser.add_argument('--days', type=int, default=7)
    calendar_parser.add_argument('--type', type=str)
    calendar_parser.add_argument('--importance', type=str, choices=['high', 'medium', 'low'])
    calendar_parser.set_defaults(func=cmd_calendar)

    # ========= v2 命令 =========
    analyze_v2_parser = subparsers.add_parser('analyze-v2', help='[v2] 模块化分析（jieba/否定识别/反讽）')
    analyze_v2_parser.add_argument('--paste', action='store_true')
    analyze_v2_parser.add_argument('--input', type=str)
    analyze_v2_parser.add_argument('--file', type=str)
    analyze_v2_parser.add_argument('--platform', type=str, default='auto',
                                   choices=['auto', 'wechat', 'qq', 'imessage', 'simple',
                                            'wechat_html', 'csv', 'tsv', 'json', 'jsonl'],
                                   help='[v5.0.0] 指定输入格式（默认 auto 自动识别）')
    analyze_v2_parser.add_argument('--export', type=str, metavar='PATH.json',
                                  help='[v2.1.0] 导出全部分析结果为 JSON')
    analyze_v2_parser.add_argument('--html', type=str, metavar='PATH.html',
                                  help='[v2.1.0] 生成单文件离线 HTML 报告')
    analyze_v2_parser.add_argument('--markdown', type=str, metavar='PATH.md',
                                  help='[v5.0.0] 生成 Markdown 报告（可贴进飞书/Notion）')
    analyze_v2_parser.add_argument('--csv', type=str, metavar='PATH.csv',
                                  help='[v5.0.0] 生成 CSV 指标表（一行一个指标，给 Excel 透视）')
    analyze_v2_parser.add_argument('--ai', action='store_true',
                                  help='[v5.0.0] 追加 AI 深度洞察（需 API Key；未配置时自动降级为本地模板）')
    analyze_v2_parser.add_argument('--no-snapshot', action='store_true',
                                  help='[v5.0.0] 不保存跨会话快照')
    analyze_v2_parser.add_argument('--label', type=str, default='',
                                  help='[v5.0.0] 给本次快照加备注（用于 session --list）')
    analyze_v2_parser.set_defaults(func=cmd_analyze_v2)

    capture_parser = subparsers.add_parser('capture', help='[v5.0.0] 直接从桌面微信捕获并分析（Windows）')
    capture_parser.add_argument('--source', type=str, default='window',
                                choices=['window', 'clipboard'],
                                help='捕获来源：读微信窗口（默认）或剪贴板监听')
    capture_parser.add_argument('--seconds', type=int, default=15,
                                help='剪贴板模式的监听时长（秒）')
    capture_parser.add_argument('--export', type=str, metavar='PATH.json',
                                help='导出分析结果为 JSON')
    capture_parser.add_argument('--html', type=str, metavar='PATH.html', help='生成 HTML 报告')
    capture_parser.add_argument('--markdown', type=str, metavar='PATH.md', help='生成 Markdown 报告')
    capture_parser.add_argument('--csv', type=str, metavar='PATH.csv', help='生成 CSV 指标表')
    capture_parser.add_argument('--ai', action='store_true', help='追加 AI 深度洞察')
    capture_parser.set_defaults(func=cmd_capture)

    session_parser = subparsers.add_parser('session', help='[v5.0.0] 跨会话快照与趋势对比')
    session_parser.add_argument('--save', dest='action', action='store_const', const='save',
                                help='把最近一次分析存成快照')
    session_parser.add_argument('--compare', dest='action', action='store_const', const='compare',
                                help='与上一次快照对比（可加 ID：--compare 20261015_xxx）')
    session_parser.add_argument('--list', dest='action', action='store_const', const='list',
                                default='list', help='列出历史快照（默认）')
    session_parser.add_argument('--id', type=str, help='配合 --compare 指定快照 ID')
    session_parser.add_argument('--label', type=str, default='', help='快照备注')
    session_parser.add_argument('--limit', type=int, default=20, help='列表条数')
    session_parser.set_defaults(func=cmd_session)

    predict_v2_parser = subparsers.add_parser('predict-v2', help='[v2] 三层融合预测（Rule + RAG + MiroFish）')
    predict_v2_parser.add_argument('--paste', action='store_true')
    predict_v2_parser.add_argument('--input', type=str)
    predict_v2_parser.add_argument('--file', type=str)
    predict_v2_parser.add_argument('--seed', type=int, default=None,
                                   help='[v2.5.0] 随机种子，使 MiroFish 模拟结果可复现')
    predict_v2_parser.set_defaults(func=cmd_predict_v2)

    graph_parser = subparsers.add_parser('graph-stats', help='[v2] MiroFish 图谱统计')
    graph_parser.set_defaults(func=cmd_graph_stats)

    # ========= v2.1.0 新命令 =========
    report_v2_parser = subparsers.add_parser('report-v2', help='[v2.1.0] 用最近一次 analyze-v2 结果生成离线报告')
    report_v2_parser.add_argument('--output', type=str, metavar='PATH',
                                 help='输出路径（默认 data/v2_report_<时间戳>.<ext>）')
    report_v2_parser.add_argument('--format', type=str, default='html',
                                 choices=['html', 'markdown', 'md', 'csv'],
                                 help='[v5.0.0] 报告格式，默认 HTML')
    report_v2_parser.set_defaults(func=cmd_report_v2)

    demo_parser = subparsers.add_parser('demo', help='[v2.1.0] 一键体验：分析内置示例并生成 HTML 报告')
    demo_parser.set_defaults(func=cmd_demo)

    doctor_parser = subparsers.add_parser('doctor', help='[v2.1.0] 环境自检')
    doctor_parser.set_defaults(func=cmd_doctor)

    voice_parser = subparsers.add_parser('voice', help='[v2.9.0] 语音交互（说/打字均可，零依赖自动降级）')
    voice_parser.set_defaults(func=cmd_voice)

    version_parser = subparsers.add_parser('version', help='[v2] 版本信息')
    version_parser.set_defaults(func=cmd_version)

    # v2.1.0：无参数启动进入交互式向导（-h/--help 行为不变）
    if len(sys.argv) == 1:
        _run_interactive_wizard()
        return

    # v2.5.0：--debug 位置无关（子命令前后均可），parse_args 前取出
    debug_flag = False
    if "--debug" in sys.argv:
        sys.argv.remove("--debug")
        debug_flag = True

    args = parser.parse_args()
    args.debug = getattr(args, "debug", False) or debug_flag

    if args.command is None:
        parser.print_help()
        return

    # v2.5.0：全链路友好错误提示（此前 friendly_errors 从未被接入）
    try:
        args.func(args)
    except KeyboardInterrupt:
        print(_safe_emoji("\n⏹ 已取消（Ctrl+C），再见！"))
        sys.exit(130)
    except Exception as e:
        if getattr(args, "debug", False):
            raise
        try:
            from friendly_errors import friendly_error
            print(_safe_emoji("\n" + friendly_error(e)), file=sys.stderr)
        except Exception:
            # 友好提示自身出错时回退到原始堆栈，避免掩盖真实错误
            raise
        sys.exit(1)


if __name__ == '__main__':
    main()
