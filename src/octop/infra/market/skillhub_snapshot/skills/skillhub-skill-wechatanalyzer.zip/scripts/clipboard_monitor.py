"""
剪贴板监控器 v4.0.0

实时监控 Windows 剪贴板，自动捕获从微信桌面端复制的聊天消息。
使用 ctypes 调用 Win32 API，零外部依赖。

功能：
1. 注册剪贴板变化监听（Win32 消息循环）
2. 自动识别微信聊天格式（日期+发送者+内容）
3. 增量去重（同一消息不重复导入）
4. 可配置的监控时长和回调
5. 后台守护线程，不阻塞主进程

隐私设计：
- 仅在用户主动复制时捕获，不读取微信进程内存
- 数据仅存内存，可选持久化到本地 SQLite
- 不上传任何数据到外部服务
"""

import ctypes
import ctypes.wintypes
import logging
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from hashlib import md5
from typing import Any, Callable, Deque, Dict, List, Optional

logger = logging.getLogger(__name__)

# Win32 常量
CF_UNICODETEXT = 13
WM_CLIPBOARDUPDATE = 0x031D
HWND_MESSAGE = -3
GWLP_WNDPROC = -4

# Win32 函数签名
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

# 注册/注销剪贴板监听
user32.AddClipboardFormatListener.argtypes = [ctypes.wintypes.HWND]
user32.AddClipboardFormatListener.restype = ctypes.wintypes.BOOL
user32.RemoveClipboardFormatListener.argtypes = [ctypes.wintypes.HWND]
user32.RemoveClipboardFormatListener.restype = ctypes.wintypes.BOOL

# 窗口消息处理
user32.CreateWindowExW.argtypes = [
    ctypes.wintypes.DWORD, ctypes.wintypes.LPCWSTR, ctypes.wintypes.LPCWSTR,
    ctypes.wintypes.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    ctypes.c_int, ctypes.wintypes.HWND, ctypes.wintypes.HMENU,
    ctypes.wintypes.HINSTANCE, ctypes.wintypes.LPVOID,
]
user32.CreateWindowExW.restype = ctypes.wintypes.HWND

user32.GetMessageW.argtypes = [
    ctypes.POINTER(ctypes.wintypes.MSG), ctypes.wintypes.HWND,
    ctypes.c_uint, ctypes.c_uint,
]
user32.GetMessageW.restype = ctypes.wintypes.BOOL

user32.DefWindowProcW.argtypes = [
    ctypes.wintypes.HWND, ctypes.c_uint,
    ctypes.wintypes.WPARAM, ctypes.wintypes.LPARAM,
]
user32.DefWindowProcW.restype = ctypes.wintypes.LPARAM

kernel32.GetModuleHandleW.argtypes = [ctypes.wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = ctypes.wintypes.HINSTANCE

user32.OpenClipboard.argtypes = [ctypes.wintypes.HWND]
user32.OpenClipboard.restype = ctypes.wintypes.BOOL
user32.CloseClipboard.restype = ctypes.wintypes.BOOL
user32.GetClipboardData.argtypes = [ctypes.wintypes.UINT]
user32.GetClipboardData.restype = ctypes.wintypes.HANDLE
user32.IsClipboardFormatAvailable.argtypes = [ctypes.wintypes.UINT]
user32.IsClipboardFormatAvailable.restype = ctypes.wintypes.BOOL

kernel32.GlobalLock.argtypes = [ctypes.wintypes.HGLOBAL]
kernel32.GlobalLock.restype = ctypes.wintypes.LPVOID
kernel32.GlobalUnlock.argtypes = [ctypes.wintypes.HGLOBAL]
kernel32.GlobalUnlock.restype = ctypes.wintypes.BOOL


# ============================================================================
# 数据模型
# ============================================================================

@dataclass
class ClipboardMessage:
    """从剪贴板捕获的消息。"""
    sender: str = ""
    content: str = ""
    timestamp: Optional[str] = None
    captured_at: str = ""
    raw_text: str = ""
    hash_key: str = ""
    role: str = "unknown"  # self/other/unknown
    metadata: Dict[str, Any] = field(default_factory=dict)


# ============================================================================
# 微信格式识别
# ============================================================================

# 微信桌面复制格式: "2024-01-15 14:32:15 张三\n你好啊\n"
# 或者多条: "2024-01-15 14:32:15 张三\n你好\n2024-01-15 14:33:00 李四\n在的"
WECHAT_TS_PATTERN = re.compile(
    r"(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s+(\S+)"
)

# 企业微信格式类似但可能带 @
WEWORK_TS_PATTERN = re.compile(
    r"(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s+([^@:\n]+)"
)

# 简单格式: "发送者: 内容"
SIMPLE_PATTERN = re.compile(r"^([^\n:：]+)[:：]\s*(.+)$", re.MULTILINE)


def parse_wechat_clipboard(text: str) -> List[ClipboardMessage]:
    """解析微信桌面端复制到剪贴板的聊天文本。

    支持格式:
    1. 微信标准导出: 日期 时间 发送者\\n内容
    2. 微信选中复制: 发送者: 内容（每行一条）
    3. 混合格式
    """
    if not text or len(text.strip()) < 3:
        return []

    lines = text.splitlines()
    messages: List[ClipboardMessage] = []
    current: Optional[ClipboardMessage] = None

    for line in lines:
        line_stripped = line.strip()
        if not line_stripped:
            continue

        # 尝试微信时间戳格式
        ts_match = WECHAT_TS_PATTERN.match(line_stripped)
        if ts_match:
            if current:
                messages.append(current)
            ts_str, sender = ts_match.group(1), ts_match.group(2).strip()
            role = _detect_role(sender)
            current = ClipboardMessage(
                sender=sender,
                content="",
                timestamp=ts_str,
                captured_at=datetime.now().isoformat(),
                raw_text=line,
                role=role,
            )
            continue

        # 尝试简单格式 (发送者: 内容)
        simple_match = SIMPLE_PATTERN.match(line_stripped)
        if simple_match and current is None:
            sender, content = simple_match.group(1).strip(), simple_match.group(2).strip()
            role = _detect_role(sender)
            current = ClipboardMessage(
                sender=sender,
                content=content,
                captured_at=datetime.now().isoformat(),
                raw_text=line,
                role=role,
            )
            continue

        # 续行
        if current:
            if current.content:
                current.content += "\n" + line_stripped
            else:
                current.content = line_stripped
            current.raw_text += "\n" + line
        else:
            # 无主消息
            current = ClipboardMessage(
                content=line_stripped,
                captured_at=datetime.now().isoformat(),
                raw_text=line,
                role="unknown",
            )

    if current:
        messages.append(current)

    # 计算 hash
    for msg in messages:
        msg.hash_key = md5(f"{msg.sender}:{msg.content}".encode("utf-8")).hexdigest()[:16]

    return messages


def _detect_role(sender: str) -> str:
    """根据发送者名字推测角色。"""
    self_names = {"我", "self", "me", "我自己"}
    if sender.lower() in self_names:
        return "self"
    return "other"


# ============================================================================
# 剪贴板监控器
# ============================================================================

class ClipboardMonitor:
    """Windows 剪贴板实时监控器。

    使用 Win32 AddClipboardFormatListener 监听剪贴板变化，
    自动识别并解析微信聊天格式的复制内容。

    用法:
        monitor = ClipboardMonitor()
        monitor.on_message(lambda msgs: print(f"捕获 {len(msgs)} 条消息"))
        monitor.start()  # 非阻塞，启动后台线程
        # ...
        monitor.stop()
    """

    def __init__(self, config: dict = None):
        cfg = (config or {}).get("clipboard_monitor", {})
        self.poll_interval = cfg.get("poll_interval", 0.5)
        self.max_history = cfg.get("max_history", 1000)
        self.dedup_window = cfg.get("dedup_window", 100)
        self.auto_persist = cfg.get("auto_persist", False)
        self.self_names = set(cfg.get("self_names", ["我", "self"]))

        self._history: Deque[ClipboardMessage] = deque(maxlen=self.max_history)
        self._seen_hashes: Deque[str] = deque(maxlen=self.dedup_window)
        self._callbacks: List[Callable] = []
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._last_text = ""
        self._stats = {
            "total_captured": 0,
            "total_duplicates": 0,
            "start_time": None,
            "last_capture_time": None,
        }

    def on_message(self, callback: Callable[[List[ClipboardMessage]], None]):
        """注册消息回调（每批新消息触发一次）。"""
        self._callbacks.append(callback)

    def start(self) -> bool:
        """启动监控（后台线程）。返回是否成功启动。"""
        if self._running:
            return True
        if not self._is_windows():
            logger.warning("剪贴板监控仅支持 Windows 平台")
            return False

        self._running = True
        self._stats["start_time"] = datetime.now().isoformat()
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        logger.info("剪贴板监控已启动")
        return True

    def stop(self):
        """停止监控。"""
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3)
        logger.info("剪贴板监控已停止")

    def is_running(self) -> bool:
        return self._running

    def get_history(self, limit: int = 50) -> List[ClipboardMessage]:
        """获取捕获历史。"""
        items = list(self._history)
        return items[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """获取监控统计。"""
        return {
            **self._stats,
            "is_running": self._running,
            "history_size": len(self._history),
            "seen_hashes": len(self._seen_hashes),
        }

    def clear_history(self):
        """清空历史。"""
        self._history.clear()
        self._seen_hashes.clear()

    # ----------------------------------------------------------------
    # 内部实现
    # ----------------------------------------------------------------

    def _monitor_loop(self):
        """主监控循环（轮询模式，跨平台兼容性更好）。"""
        while self._running:
            try:
                self._poll_clipboard()
            except Exception as e:
                logger.debug(f"剪贴板轮询异常: {e}")
            time.sleep(self.poll_interval)

    def _poll_clipboard(self):
        """轮询剪贴板内容变化。"""
        text = self._read_clipboard_text()
        if text and text != self._last_text:
            self._last_text = text
            self._process_clipboard_text(text)

    def _read_clipboard_text(self) -> Optional[str]:
        """读取剪贴板文本（Win32 API）。"""
        try:
            if not user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
                return None
            if not user32.OpenClipboard(0):
                return None
            try:
                handle = user32.GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return None
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return None
                try:
                    return ctypes.wstring_at(ptr)
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except Exception as e:
            logger.debug(f"读取剪贴板失败: {e}")
            return None

    def _process_clipboard_text(self, text: str):
        """处理剪贴板文本，解析微信格式并去重。"""
        messages = parse_wechat_clipboard(text)
        if not messages:
            return

        # 去重
        new_messages = []
        for msg in messages:
            if msg.hash_key not in self._seen_hashes:
                self._seen_hashes.append(msg.hash_key)
                new_messages.append(msg)
            else:
                self._stats["total_duplicates"] += 1

        if not new_messages:
            return

        # 更新角色（支持自定义 self_names）
        for msg in new_messages:
            if msg.sender in self.self_names:
                msg.role = "self"

        # 记录历史
        for msg in new_messages:
            self._history.append(msg)
        self._stats["total_captured"] += len(new_messages)
        self._stats["last_capture_time"] = datetime.now().isoformat()

        # 回调
        for cb in self._callbacks:
            try:
                cb(new_messages)
            except Exception as e:
                logger.warning(f"回调异常: {e}")

    @staticmethod
    def _is_windows() -> bool:
        import sys
        return sys.platform == "win32"


# ============================================================================
# 便捷函数
# ============================================================================

_global_monitor: Optional[ClipboardMonitor] = None


def get_monitor(config: dict = None) -> ClipboardMonitor:
    """获取全局剪贴板监控器实例。"""
    global _global_monitor
    if _global_monitor is None:
        _global_monitor = ClipboardMonitor(config)
    return _global_monitor


def quick_capture(duration: int = 10, config: dict = None) -> List[ClipboardMessage]:
    """快速捕获剪贴板消息（阻塞 duration 秒）。

    Args:
        duration: 监控时长（秒）
        config: 配置

    Returns:
        捕获到的消息列表
    """
    captured: List[ClipboardMessage] = []

    def collector(msgs):
        captured.extend(msgs)

    monitor = ClipboardMonitor(config)
    monitor.on_message(collector)
    if monitor.start():
        time.sleep(duration)
        monitor.stop()
    return captured


# ============================================================================
# 自检
# ============================================================================

def self_check() -> Dict[str, Any]:
    """自检。"""
    result = {
        "module": "clipboard_monitor",
        "version": "4.0.0",
        "platform_supported": ClipboardMonitor._is_windows(),
    }

    # 测试解析器
    test_texts = [
        "2024-01-15 14:32:15 张三\n你好啊\n2024-01-15 14:33:00 李四\n在的",
        "我: 你好\n对方: 你好啊",
    ]
    for i, text in enumerate(test_texts):
        msgs = parse_wechat_clipboard(text)
        result[f"test_{i}"] = {
            "input_lines": len(text.splitlines()),
            "parsed_count": len(msgs),
            "senders": [m.sender for m in msgs],
        }

    return result


if __name__ == "__main__":
    import json
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))