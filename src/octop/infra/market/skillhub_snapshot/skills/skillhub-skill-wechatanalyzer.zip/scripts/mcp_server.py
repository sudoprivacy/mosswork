#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wechat-analyzer MCP Server v6.0.0
================================

把微信聊天分析能力通过 MCP 协议暴露给 Claude Code / Qoder 客户端。

兼容 mcp 1.x（`mcp.server.fastmcp.FastMCP`）与 2.x（`mcp.server.mcpserver.MCPServer`）；
`get_skill_status()` 里的 `mcp_sdk_generation` 会标明当前跑在哪一代。

支持的能力（按工具分类，共 31 个工具；`get_skill_status` 会实时反查真实名单）：

1. 聊天分析类（规则引擎，全程本地）：
   - analyze_chat           完整分析（MBTI/大五/情感/风险/关系/推演/群聊/隐私/话题）
   - get_mbti_analysis      MBTI 性格分析
   - get_bigfive_analysis   大五人格分析
   - get_sentiment_analysis 情感分析
   - get_risk_analysis      风险检测
   - get_relationship_health 关系健康度五维
   - get_scenario           场景分类（恋爱/工作/社交/重要）
   - get_pattern_analysis   对话模式（谁先发起/回复速度/活跃时段）
   - get_inference_analysis 关系推演（话题趋势/行为预测/风险演化）
   - get_interpretation_analysis 语义解读（意图/实体/主题/立场）
   - get_group_analysis     群聊多主体（成员占比/活跃分层/@网络）
   - get_topic_analysis     话题地图（关键词/主题/人物关注点/冷热/切换）
   - scan_privacy           本地隐私扫描 + 可逆脱敏

2. AI 深度洞察类（需配置 DEEPSEEK_API_KEY，无 Key 时降级为本地模板）：
   - ai_insight_from_chat       一条龙：解析→分析→构造上下文→洞察（推荐）
   - ai_personality_insight     AI 性格解读（手工回填参数）
   - ai_emotion_narrative       AI 情感叙事
   - ai_relationship_advice     AI 关系改善建议
   - ai_risk_interpretation     AI 风险解读
   - ai_prediction_explanation  AI 预测解释

3. 对话预测类：
   - predict_reply            对方可能回复预测（四层融合 + 历史画像）
   - train_reply_predictor    用真实聊天记录训练并落盘个性化画像
   - get_prediction_profile   查看画像积累程度

4. 数据导入类：
   - import_chat_from_text  从文本导入聊天记录（微信/QQ/iMessage/JSON/CSV…）

5. 报告与会话趋势类：
   - export_chat_report     导出 Markdown / CSV / HTML / JSON 文件
   - save_analysis_session  存一次会话快照（只存指标不存原文）
   - list_analysis_sessions 列出历史快照
   - compare_analysis_sessions 两次会话指标变化与显著性

6. 桌面微信捕获类（仅 Windows）：
   - capture_clipboard      剪贴板实时捕获微信消息
   - capture_wechat_window  读取微信桌面端窗口消息
   - get_desktop_status     桌面捕获能力状态

7. 系统类：
   - get_skill_status      技能状态/版本/能力/模块可用性

启动方式（Claude Code mcpServers 配置）：
{
  "mcpServers": {
    "wechat-analyzer": {
      "command": "python",
      "args": ["./mcp_server.py"],
      "env": {
        "DEEPSEEK_API_KEY": "sk-...",
        "PYTHONDONTWRITEBYTECODE": "1"
      }
    }
  }
}
"""
from __future__ import annotations

import sys
import os
import json
import logging
import asyncio
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# 禁止生成 .pyc
sys.dont_write_bytecode = True

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("wechat_analyzer_mcp")

# MCP SDK 导入
# v5.0.0：缺 SDK 时不再 sys.exit(1)。之前 import mcp_server 会直接杀死调用方
# 进程，导致 doctor 自检、单元测试、以及没装 mcp 的机器上连"报告缺什么"都做不到。
# 降级成一个占位 server：工具照常注册（可无 SDK 冒烟），run() 才报错。
#
# v6.0.0：mcp 2.x 把 FastMCP 改名成了 MCPServer（mcp.server.mcpserver），
# 只写下 1.x 的导入会在这类环境里直接启动失败，而 `import mcp` 仍然成功，
# 测试探针也看不出问题。这里两代都试，并把代际上报到 get_skill_status。
MCP_SDK_GENERATION = 0
try:
    from mcp.server.fastmcp import FastMCP  # mcp 1.x
    MCP_SDK_GENERATION = 1
    HAS_MCP = True
except ImportError as _mcp_v1_error:  # noqa: BLE001
    try:
        from mcp.server.mcpserver import MCPServer as FastMCP  # mcp 2.x
        MCP_SDK_GENERATION = 2
        HAS_MCP = True
    except ImportError as _mcp_import_error:  # noqa: BLE001
        HAS_MCP = False
        _MCP_IMPORT_ERROR = (
            f"1.x: {_mcp_v1_error}；2.x: {_mcp_import_error}"
        )

        class _StubFastMCP:
            """MCP SDK 缺失时的占位实现，仅用于让模块可导入、工具可冒烟测试。"""

            def __init__(self, name: str):
                self.name = name
                self.stub_tools: Dict[str, Any] = {}

            def tool(self, **kwargs):  # noqa: D401 - 与 FastMCP 同名的装饰器
                def decorator(fn):
                    self.stub_tools[fn.__name__] = fn
                    return fn
                return decorator

            async def list_tools(self):
                return list(self.stub_tools.values())

            def run(self, transport: str = "stdio"):
                raise RuntimeError(
                    f"MCP SDK 未安装（{_MCP_IMPORT_ERROR}），请运行: pip install mcp"
                )

        FastMCP = _StubFastMCP  # type: ignore[assignment,misc]


def _safe_import(module_path: str, items: list):
    """安全导入模块，缺失时返回 None 占位。"""
    try:
        mod = __import__(module_path, fromlist=items)
        return {item: getattr(mod, item, None) for item in items}
    except Exception as e:
        log.warning(f"导入 {module_path} 失败: {e}")
        return {item: None for item in items}


# 顶层导入
analyzers_init = _safe_import("analyzers", ["create_default_registry"])
ai_insight = _safe_import("analyzers.ai_insight_engine", [
    "get_engine", "generate_insight", "self_check",
    "attach_insights", "INSIGHT_ORDER", "PROMPT_TEMPLATES",
])
# v5.0.0：去掉 "from_dict"——core.message 没有模块级 from_dict（它是 Message
# 的 classmethod），_safe_import 永远取回 None，误导后续代码。
core_message = _safe_import("core.message", ["Message", "MessageType", "SenderRole"])
core_data = _safe_import("core.data_paths", ["resolve_data_dir"])
core_context = _safe_import("core.predictor_base", ["PredictionContext"])
_UTILS = _safe_import("core.utils", ["parse_timestamp", "normalize_for_compare"])
predictors_init = _safe_import("predictors", ["create_default_ensemble"])
history_aware = _safe_import("predictors.history_aware_predictor",
                             ["HistoryAwarePredictor", "default_profile_path"])
file_importer = _safe_import("scripts.file_importer", ["FileImporter"])
multi_source = _safe_import("scripts.data_source_importer", [
    "MultiSourceImporter", "SmartPasteParser", "StructuredChatImporter",
])
privacy_scanner = _safe_import("analyzers.privacy_scanner", [
    "PrivacyScanner", "scan_messages", "mask_text",
])
clipboard_monitor = _safe_import("scripts.clipboard_monitor", [
    "ClipboardMonitor", "get_monitor", "parse_wechat_clipboard",
])
wechat_window = _safe_import("scripts.wechat_window_reader", [
    "WeChatWindowReader", "get_reader",
])
# v5.0.0：会话趋势记忆 + 多格式报告导出。
# 之前的导入清单里写的是 "SessionMemory"，模块里根本没有这个类，
# _safe_import 静默返回 None，工具接线时等于要从零再摸一遍 API。
session_memory = _safe_import("scripts.session_memory", [
    "extract_metrics", "save_snapshot", "list_snapshots",
    "get_snapshot", "compare_sessions", "snapshot_file",
])
report_exporters = _safe_import("scripts.report_exporters", ["write_report"])
v2_report = _safe_import("scripts.v2_report_generator", ["V2ReportGenerator"])

# v5.0.0：版本单一来源，不再硬编码
from core.version import __version__ as VERSION  # noqa: E402

# 2.x 的 MCPServer 支持 version 参数（握手时回报 serverInfo.version），
# 1.x 的 FastMCP 没有这个形参，按代际决定是否传入。
server = FastMCP("wechat-analyzer", **({"version": VERSION} if MCP_SDK_GENERATION == 2 else {}))


def _module_error(name: str) -> str:
    return f"❌ 模块 {name} 未正确加载"


def _load_config() -> Dict[str, Any]:
    """加载 config.json。"""
    for p in ["config.json", str(SCRIPT_DIR / "config.json")]:
        if os.path.isfile(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
    return {}


def _parse_chat_text(text: str, platform: str = "auto") -> List[Any]:
    """把聊天文本解析成 core.Message 列表（只要消息）。"""
    return _parse_chat_text_with_meta(text, platform)[0]


def _parse_chat_text_with_meta(text: str,
                               platform: str = "auto") -> Tuple[List[Any], Dict[str, Any]]:
    """解析聊天文本，返回 (messages, meta)。

    v5.0.0：优先走 MultiSourceImporter（6 平台格式识别 + 时间戳 + 跨行合并）。
    此前这里只有一个只认 `发送者: 内容` 的本地正则，既不解析时间戳也不认
    微信导出格式——v3.0.0 宣称的多源导入其实从未生效。importer 不可用或
    解析为空时，退回最简行格式。meta 里的 detected_platform 是调用方
    （CLI / MCP 工具）判断"到底按哪个平台解析的"唯一依据。
    """
    meta: Dict[str, Any] = {
        "detected_platform": platform or "auto",
        "parser": "simple_lines",
        "with_timestamp": 0,
    }
    if not text or not text.strip():
        return [], meta
    if core_message["Message"] is None:
        return [], meta

    importer_cls = multi_source.get("MultiSourceImporter")
    if importer_cls is not None:
        try:
            importer = importer_cls()
            result = importer.import_text(text, platform=platform)
            if result.success and result.messages:
                messages = importer.to_core_messages(result.messages)
                if messages:
                    meta["detected_platform"] = (result.metadata or {}).get(
                        "detected_platform", meta["detected_platform"])
                    meta["parser"] = "multi_source"
                    meta["with_timestamp"] = sum(
                        1 for m in messages if getattr(m, "timestamp", None) is not None)
                    return messages, meta
        except Exception as e:  # noqa: BLE001 - 解析失败必须回退而不是中断
            log.debug(f"MultiSourceImporter 解析失败，回退最简解析: {e}")

    messages = _parse_simple_lines(text)
    meta["detected_platform"] = "simple" if platform in (None, "auto") else platform
    meta["with_timestamp"] = sum(
        1 for m in messages if getattr(m, "timestamp", None) is not None)
    return messages, meta


def _parse_simple_lines(text: str) -> List[Any]:
    """最简行格式解析（`发送者: 内容`），作为导入器不可用时的兜底。"""
    Message = core_message["Message"]
    MessageType = core_message["MessageType"]
    SenderRole = core_message["SenderRole"]
    parse_ts = _UTILS.get("parse_timestamp")
    if Message is None:
        return []

    messages = []
    lines = text.splitlines()
    pattern = re.compile(
        r"^\s*(?:[\[【]?\s*(?P<time>\d{1,2}:\d{2}(?::\d{2})?)"
        r"|(?P<datetime>\d{4}[-/年]\d{1,2}[-/月]\d{1,2}日?\s*\d{1,2}:\d{2}(?::\d{2})?))?"
        r"\s*[\]】]?\s*(?P<sender>[^:：]{1,40}?)\s*[::]\s*(?P<content>.+)$"
    )

    for line in lines:
        line = line.strip()
        if not line:
            continue
        m = pattern.match(line)
        if m:
            sender = (m.group("sender") or "").strip()
            content = (m.group("content") or "").strip()
            raw_time = m.group("datetime") or m.group("time")
            role = SenderRole.UNKNOWN
            sender_lower = sender.lower()
            if sender_lower in ("self", "我"):
                role = SenderRole.SELF
            elif sender_lower in ("other", "对方", "ta", "他", "她"):
                role = SenderRole.OTHER
            timestamp = parse_ts(raw_time) if (parse_ts and raw_time) else None
            msg = Message(
                sender=sender,
                content=content,
                timestamp=timestamp,
                message_type=MessageType.TEXT,
                raw=line,
                metadata={"role": role.value if hasattr(role, "value") else str(role),
                          "timestamp_raw": raw_time or ""},
            )
            messages.append(msg)
        else:
            # 续行：附加到上一条
            if messages:
                messages[-1].content += "\n" + line
                messages[-1].raw += "\n" + line
    return messages


def _fmt_ts(ts: Any) -> str:
    return ts.strftime("%Y-%m-%d %H:%M:%S") if ts is not None else ""


def _messages_to_payload(messages: List[Any], limit: int = 50) -> List[Dict[str, Any]]:
    return [
        {
            "sender": m.sender,
            "content": m.content[:200],
            "role": (m.metadata or {}).get("role", "unknown"),
            "timestamp": _fmt_ts(getattr(m, "timestamp", None)),
        } for m in messages[:limit]
    ]


def _looks_structured(text: str) -> bool:
    stripped = (text or "").strip()
    return stripped[:1] in ("[", "{")


def _import_structured(chat_text: str, fmt: str) -> Optional[str]:
    """JSON / JSONL 走结构化导入器。

    返回 None 表示"这条路不通"，调用方回退到按行解析——自动识别时用户贴的
    "{...}" 很可能只是单条聊天内容而不是导出文件，不能因此直接报错。
    """
    importer_cls = multi_source.get("MultiSourceImporter")
    if importer_cls is None:
        return None
    try:
        importer = importer_cls()
    except Exception:
        return None

    order = ("json", "jsonl") if fmt == "json" else ("jsonl", "json")
    for kind in order:
        try:
            result = (importer.import_json(chat_text) if kind == "json"
                      else importer.import_jsonl(chat_text))
            if not (result.success and result.messages):
                continue
            messages = importer.to_core_messages(result.messages)
            if not messages:
                continue
        except Exception as e:  # noqa: BLE001
            log.debug(f"结构化导入({kind})失败: {e}")
            continue
        output = {
            "success": True,
            "detected_platform": kind,
            "parser": f"structured_{kind}",
            "message_count": len(messages),
            "with_timestamp": sum(1 for m in messages
                                  if getattr(m, "timestamp", None) is not None),
            "messages": _messages_to_payload(messages),
        }
        return _json(output, 8000)
    return None


# ============================================================================
# 1. 聊天分析类工具
# ============================================================================

async def _analyze_chat_text(chat_text: str,
                             platform: str = "auto") -> Tuple[Optional[Dict[str, Any]],
                                                              List[Any],
                                                              Dict[str, Any],
                                                              str]:
    """解析 + 跑完整分析器，返回 (results, messages, meta, error)。

    results 为 None 时 error 一定有内容。所有"先分析再做点别的"工具都走这里，
    免得每个工具各写一遍解析和 to_dict 化，出错处理方式还各不相同。
    """
    if analyzers_init["create_default_registry"] is None:
        return None, [], {}, _module_error("analyzers")
    messages, meta = _parse_chat_text_with_meta(chat_text, platform)
    if not messages:
        return None, [], {}, "❌ 无法解析聊天内容，请使用格式: '发送者: 内容'（每行一条）"
    try:
        registry = analyzers_init["create_default_registry"](_load_config())
        results = await asyncio.to_thread(registry.run_all, messages)
    except Exception as e:  # noqa: BLE001
        return None, messages, meta, f"❌ 分析异常: {str(e)[:200]}"
    plain = {
        name: (result.to_dict() if hasattr(result, "to_dict") else result)
        for name, result in results.items()
    }
    return plain, messages, meta, ""


def _messages_as_text(messages: List[Any], limit: int = 200) -> str:
    """把消息拼成送 LLM / 存快照用的纯文本（已足够短，避免 prompt 爆长）。"""
    return "\n".join(f"{m.sender}: {m.content}" for m in messages[:limit])


def _json(payload: Dict[str, Any], limit: int = 12000) -> str:
    """序列化并守住体积上限；超限时绝不能返回半截 JSON。

    v6.0.0：原先直接 ``[:limit]`` 把字符串切一半，调用方 json.loads 必炸。
    先试缩进版，超限再退到紧凑版；仍超限就返回合法的"结果过大"信封。
    """
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
    if len(text) <= limit:
        return text
    compact = json.dumps(payload, ensure_ascii=False, default=str)
    if len(compact) <= limit:
        return compact
    return json.dumps({
        "success": False,
        "truncated": True,
        "error": f"结果过大（{len(compact)} 字符），超过 {limit} 字符上限",
    }, ensure_ascii=False)


@server.tool()
async def analyze_chat(chat_text: str = "", export_format: str = "summary",
                       platform: str = "auto") -> str:
    """完整聊天分析：MBTI/大五/情感/风险/关系/推演（一次性返回所有维度）。

    Args:
        chat_text: 聊天记录文本（格式：发送者: 内容）
        export_format: 输出格式 (summary/json)
        platform: 导入平台 (auto/txt/wechat/qq/imessage/json/jsonl)
    """
    results, messages, _meta, error = await _analyze_chat_text(chat_text, platform)
    if error:
        return error
    if export_format == "json":
        return _json(results, 20000)
    return _format_summary(results, messages)


@server.tool()
async def get_mbti_analysis(chat_text: str = "") -> str:
    """MBTI 性格分析（16型 + 置信度 + 维度）。"""
    return await _run_single_analyzer(chat_text, "mbti")


@server.tool()
async def get_bigfive_analysis(chat_text: str = "") -> str:
    """大五人格分析（OCEAN 五维 + 置信度）。"""
    return await _run_single_analyzer(chat_text, "bigfive")


@server.tool()
async def get_sentiment_analysis(chat_text: str = "") -> str:
    """情感分析（整体基调 + 转折点 + 滚动趋势）。"""
    return await _run_single_analyzer(chat_text, "sentiment")


@server.tool()
async def get_risk_analysis(chat_text: str = "") -> str:
    """风险检测（杀猪盘/甩锅/HR/猪队友 + 反讽排除）。"""
    return await _run_single_analyzer(chat_text, "risk")


@server.tool()
async def get_relationship_health(chat_text: str = "") -> str:
    """关系健康度分析（互动平衡/回应度/情感同步/投入度/深度 五维）。"""
    return await _run_single_analyzer(chat_text, "relationship")


@server.tool()
async def get_scenario(chat_text: str = "") -> str:
    """场景分类（恋爱/工作/社交/重要）。"""
    return await _run_single_analyzer(chat_text, "scenario")


@server.tool()
async def get_pattern_analysis(chat_text: str = "") -> str:
    """对话模式分析：谁先发起、回复速度分布、活跃时段、会话跨度天数。"""
    return await _run_single_analyzer(chat_text, "pattern")


@server.tool()
async def get_inference_analysis(chat_text: str = "") -> str:
    """关系推演：话题趋势、对方行为预测、情感轨迹、风险演化、对话走向。"""
    return await _run_single_analyzer(chat_text, "inference")


@server.tool()
async def get_interpretation_analysis(chat_text: str = "") -> str:
    """语义解读：意图、实体、主题、立场四维。"""
    return await _run_single_analyzer(chat_text, "interpretation")


@server.tool()
async def get_group_analysis(chat_text: str = "") -> str:
    """群聊多主体分析：成员占比、活跃度分层、@提及网络、两人子对话。

    一对一场景里关系健康度指标会失真，这个工具负责回答"这是个群，谁在说话"。
    """
    return await _run_single_analyzer(chat_text, "group")


@server.tool()
async def get_topic_analysis(chat_text: str = "") -> str:
    """话题地图：TF-IDF 关键词、语义主题分布、我/对方关注点、冷热变化、话题切换。"""
    return await _run_single_analyzer(chat_text, "topic")


@server.tool()
async def scan_privacy(chat_text: str = "", return_masked: bool = False) -> str:
    """本地隐私扫描：检出聊天记录里的身份证/银行卡/手机号/住址/邮箱/密钥。

    全程离线，不上传任何内容。

    Args:
        chat_text: 聊天记录文本
        return_masked: 是否返回脱敏后的文本（可逆映射只在本地，不外发）
    """
    if privacy_scanner["scan_messages"] is None:
        return _module_error("privacy_scanner")
    try:
        messages = _parse_chat_text(chat_text)
        if not messages:
            return "❌ 无法解析聊天内容"
        config = _load_config()
        report = await asyncio.to_thread(
            privacy_scanner["scan_messages"], messages, config)
        output: Dict[str, Any] = {"success": True, "local_only": True}
        output.update(report)
        if return_masked and privacy_scanner["mask_text"] is not None:
            masked, mapping = await asyncio.to_thread(
                privacy_scanner["mask_text"], _messages_as_text(messages), config)
            output["masked_text"] = masked[:6000]
            output["mapping"] = mapping
        return _json(output, 12000)
    except Exception as e:  # noqa: BLE001
        return f"❌ 隐私扫描异常: {str(e)[:200]}"


async def _run_single_analyzer(chat_text: str, analyzer_name: str) -> str:
    """运行单个分析器。"""
    if analyzers_init["create_default_registry"] is None:
        return _module_error("analyzers")

    try:
        messages = _parse_chat_text(chat_text)
        if not messages:
            return "❌ 无法解析聊天内容"

        config = _load_config()
        registry = analyzers_init["create_default_registry"](config)
        analyzer = registry.get(analyzer_name)
        if analyzer is None:
            available = ", ".join(sorted(registry.list()))
            return f"❌ 分析器 {analyzer_name} 未注册（可用：{available}）"

        # v5.0.0：补上 validate()。之前绕过校验，空消息/非文本消息也会跑完
        # 整个分析，返回一堆以 0.5 填充的假结论。
        if not analyzer.validate(messages):
            return json.dumps({
                "analyzer": analyzer_name,
                "success": False,
                "reason": "输入未通过该分析器的校验（消息过少或没有可用文本）",
                "message_count": len(messages),
            }, ensure_ascii=False, indent=2)

        result = await asyncio.to_thread(analyzer.analyze, messages)
        payload = {
            "analyzer": analyzer_name,
            "success": True,
            "result": result.to_dict() if hasattr(result, "to_dict") else str(result),
        }
        return _json(payload, 12000)
    except Exception as e:
        return f"❌ {analyzer_name} 分析异常: {str(e)[:200]}"


# 摘要优先展示的分析器关键字段（按出现顺序）
_SUMMARY_KEYS = (
    "type", "name", "dimension_scores", "dim_probabilities", "stability",
    "signal_total", "insufficient_signal",
    "positive", "negative", "neutral", "trend", "turning_points",
    "health_score", "grade_label", "dimensions", "suggestions",
    "risks", "risk_count", "level", "scenario", "label", "patterns",
    "summary", "conclusion", "members", "activity", "network",
    "findings", "items", "top_phrases",
    # v5.0.0 群聊
    "is_group", "member_count", "dominance", "tiers", "roster",
    "mention_edges", "top_pairs", "note",
    # v5.0.0 隐私扫描
    "total_hits", "by_type", "breakdown", "affected_messages",
    # v6.0.0 话题地图
    "primary_topic", "concentration", "keywords", "topics", "tokenizer",
)


def _render_detail_value(value: Any, limit: int = 160) -> str:
    """把 details 里的单个字段压成一行可读文本。"""
    if isinstance(value, (int, float, bool)) or value is None:
        return str(value)
    if isinstance(value, str):
        return value if len(value) <= limit else value[:limit] + "…"
    if isinstance(value, dict):
        items = list(value.items())[:8]
        text = ", ".join(f"{k}={_render_detail_value(v, 40)}" for k, v in items)
        return ("{" + text + "}") if len(value) <= 8 else ("{" + text + ", …}")
    if isinstance(value, (list, tuple)):
        items = list(value)[:3]
        rendered = "; ".join(_render_detail_value(v, 60) for v in items)
        if len(value) > 3:
            rendered += f"（共 {len(value)} 项）"
        return rendered
    return str(value)[:limit]


def _format_summary(results: Dict[str, Any], messages: List[Any]) -> str:
    """把 run_all 的结果（已 to_dict 化）格式化为摘要文本。"""
    parts = [
        f"📊 **微信聊天分析报告**（共 {len(messages)} 条消息）",
        "=" * 60,
        "",
    ]
    self_count = sum(1 for m in messages if m.is_self())
    other_count = sum(1 for m in messages if m.is_other())
    senders = {m.sender for m in messages if m.sender}
    parts.append(
        f"己方 {self_count} 条 / 对方 {other_count} 条 / 参与人 {len(senders)} 个"
    )
    if len(senders) > 2 and "group" not in results:
        parts.append("ℹ️ 检测到多人会话（群聊），一对一关系健康度指标仅供参考，"
                     "建议改用 get_group_analysis。")
    parts.append("")

    rendered = 0
    for analyzer_name, result in results.items():
        if analyzer_name == "_meta":
            continue
        if not isinstance(result, dict):
            parts.append(f"⚠️  {analyzer_name}: 结果格式异常（{type(result).__name__}）")
            continue
        details = result.get("details") or {}
        if "error" in details:
            parts.append(f"⚠️  {analyzer_name}: {details['error']}")
            continue

        parts.append(f"### {analyzer_name}")
        parts.append(
            f"- score: {result.get('score', 0)}, "
            f"confidence: {result.get('confidence', 0)}"
        )
        shown = set()
        for key in _SUMMARY_KEYS:
            if key in details and details.get(key) not in (None, "", [], {}):
                parts.append(f"- {key}: {_render_detail_value(details[key])}")
                shown.add(key)
        for key in details:
            if key in shown or key in ("description", "dim_description"):
                continue
            if len(key) <= 18 and not isinstance(details[key], (dict, list)):
                parts.append(f"- {key}: {_render_detail_value(details[key], 80)}")
                if len(parts) > 40:
                    break
        parts.append("")
        rendered += 1

    if rendered == 0:
        parts.append("⚠️ 没有任何分析器产出结果。")

    parts.append("---")
    parts.append("⚠️ 分析仅供参考，不构成专业心理评估或法律意见。")
    return "\n".join(parts)[:12000]


# ============================================================================
# 2. AI 深度洞察类工具
# ============================================================================

@server.tool()
async def ai_personality_insight(
    mbti_type: str = "",
    mbti_confidence: str = "",
    dimension_scores: str = "",
    openness: str = "", conscientiousness: str = "",
    extraversion: str = "", agreeableness: str = "", neuroticism: str = "",
    key_messages: str = "",
) -> str:
    """AI 性格解读（需 DEEPSEEK_API_KEY）。基于 MBTI/大五结果给出深度解读。

    Args:
        mbti_type: MBTI 类型 (INTJ/ENFP 等)
        mbti_confidence: 置信度百分比
        dimension_scores: 维度得分 (I:65, N:80, ...)
        openness/conscientiousness/extraversion/agreeableness/neuroticism: 大五维度
        key_messages: 关键聊天样本
    """
    engine = ai_insight["get_engine"]()
    if engine is None:
        return _module_error("ai_insight_engine")

    context = {
        "mbti_type": mbti_type, "mbti_confidence": mbti_confidence,
        "dimension_scores": dimension_scores,
        "openness": openness, "conscientiousness": conscientiousness,
        "extraversion": extraversion, "agreeableness": agreeableness,
        "neuroticism": neuroticism,
        "key_messages": key_messages,
    }
    try:
        result = await asyncio.to_thread(engine.generate, "personality_insight", context)
        output = {
            "success": result.success,
            "is_fallback": result.is_fallback,
            "model": result.model,
            "tokens_used": result.tokens_used,
        }
        if result.error:
            output["error"] = result.error
        output["insight"] = result.content[:8000]
        return _json(output, 10000)
    except Exception as e:
        return f"❌ AI 性格解读异常: {str(e)}"


@server.tool()
async def ai_emotion_narrative(
    overall_tone: str = "",
    positive_pct: str = "",
    negative_pct: str = "",
    self_positive: str = "",
    self_negative: str = "",
    turning_points: str = "",
    timeline_summary: str = "",
) -> str:
    """AI 情感叙事（需 DEEPSEEK_API_KEY）。把情感变化编织成温暖故事。

    Args:
        overall_tone: 整体基调
        positive_pct/negative_pct: 正负面占比
        self_positive/self_negative: 己方正负面占比
        turning_points: 情感转折点
        timeline_summary: 时间线摘要
    """
    engine = ai_insight["get_engine"]()
    if engine is None:
        return _module_error("ai_insight_engine")

    context = {
        "overall_tone": overall_tone,
        "positive_pct": positive_pct, "negative_pct": negative_pct,
        "self_positive": self_positive, "self_negative": self_negative,
        "turning_points": turning_points or "无明显转折",
        "timeline_summary": timeline_summary,
    }
    try:
        result = await asyncio.to_thread(engine.generate, "emotion_narrative", context)
        output = {
            "success": result.success,
            "is_fallback": result.is_fallback,
            "model": result.model,
        }
        if result.error:
            output["error"] = result.error
        output["narrative"] = result.content[:8000]
        return _json(output, 10000)
    except Exception as e:
        return f"❌ AI 情感叙事异常: {str(e)}"


@server.tool()
async def ai_relationship_advice(
    balance_score: str = "", responsiveness_score: str = "",
    sync_score: str = "", investment_score: str = "", depth_score: str = "",
    balance_desc: str = "", responsiveness_desc: str = "",
    sync_desc: str = "", investment_desc: str = "", depth_desc: str = "",
    overall_rating: str = "",
    relationship_type: str = "",
    key_messages: str = "",
) -> str:
    """AI 关系改善建议（需 DEEPSEEK_API_KEY）。

    Args:
        balance_score/responsiveness_score/sync_score/investment_score/depth_score: 五维分数
        *_desc: 五维描述
        overall_rating: 综合评级
        relationship_type: 关系类型
        key_messages: 关键聊天样本
    """
    engine = ai_insight["get_engine"]()
    if engine is None:
        return _module_error("ai_insight_engine")

    context = {
        "balance_score": balance_score, "responsiveness_score": responsiveness_score,
        "sync_score": sync_score, "investment_score": investment_score,
        "depth_score": depth_score,
        "balance_desc": balance_desc, "responsiveness_desc": responsiveness_desc,
        "sync_desc": sync_desc, "investment_desc": investment_desc,
        "depth_desc": depth_desc,
        "overall_rating": overall_rating, "relationship_type": relationship_type,
        "key_messages": key_messages,
    }
    try:
        result = await asyncio.to_thread(engine.generate, "relationship_advice", context)
        output = {"success": result.success, "is_fallback": result.is_fallback}
        if result.error:
            output["error"] = result.error
        output["advice"] = result.content[:8000]
        return _json(output, 10000)
    except Exception as e:
        return f"❌ AI 关系建议异常: {str(e)}"


@server.tool()
async def ai_risk_interpretation(
    risk_type: str = "",
    risk_level: str = "",
    confidence: str = "",
    evidence: str = "",
    context: str = "",
) -> str:
    """AI 风险解读（需 DEEPSEEK_API_KEY）。

    Args:
        risk_type: 风险类型（杀猪盘/甩锅/HR/猪队友）
        risk_level: 风险等级（低/中/高）
        confidence: 置信度
        evidence: 风险证据
        context: 上下文
    """
    engine = ai_insight["get_engine"]()
    if engine is None:
        return _module_error("ai_insight_engine")

    ctx = {
        "risk_type": risk_type, "risk_level": risk_level,
        "confidence": confidence, "evidence": evidence,
        "context": context or "无额外上下文",
    }
    try:
        result = await asyncio.to_thread(engine.generate, "risk_interpretation", ctx)
        output = {"success": result.success, "is_fallback": result.is_fallback}
        if result.error:
            output["error"] = result.error
        output["interpretation"] = result.content[:8000]
        return _json(output, 10000)
    except Exception as e:
        return f"❌ AI 风险解读异常: {str(e)}"


@server.tool()
async def ai_prediction_explanation(
    other_personality: str = "",
    predicted_reply: str = "",
    confidence: str = "",
    alternative_styles: str = "",
    recent_context: str = "",
) -> str:
    """AI 预测解释（需 DEEPSEEK_API_KEY）。解释为什么对方可能这样回复。

    Args:
        other_personality: 对方性格画像
        predicted_reply: 预测回复
        confidence: 置信度
        alternative_styles: 备选风格
        recent_context: 最近聊天上下文
    """
    engine = ai_insight["get_engine"]()
    if engine is None:
        return _module_error("ai_insight_engine")

    ctx = {
        "other_personality": other_personality,
        "predicted_reply": predicted_reply,
        "confidence": confidence,
        "alternative_styles": alternative_styles or "无备选",
        "recent_context": recent_context,
    }
    try:
        result = await asyncio.to_thread(engine.generate, "prediction_explanation", ctx)
        output = {"success": result.success, "is_fallback": result.is_fallback}
        if result.error:
            output["error"] = result.error
        output["explanation"] = result.content[:8000]
        return _json(output, 10000)
    except Exception as e:
        return f"❌ AI 预测解释异常: {str(e)}"


# ============================================================================
# 2.5 一条龙 AI 洞察（分析器结果 → 提示词上下文 → LLM）
# ============================================================================

async def _prediction_extra(messages: List[Any],
                            config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """跑一次本地集成预测，给 prediction_explanation 补上输入。

    这条洞察的原料不在分析器里，没有预测结果就只能跳过而不是让模型编一段。
    """
    if (predictors_init["create_default_ensemble"] is None
            or core_context["PredictionContext"] is None):
        return None
    try:
        ensemble = predictors_init["create_default_ensemble"](config)
        _load_history_profile(ensemble, config)
        context = core_context["PredictionContext"](
            messages=messages,
            scenario=await _detect_scenario(messages, config),
            metadata={},
        )
        result = await asyncio.to_thread(ensemble.predict, context)
        top = getattr(result, "top_prediction", None)
        if top is None or not getattr(top, "text", ""):
            return None
        alternatives = getattr(result, "alternatives", None) or []
        return {
            "predicted_reply": top.text,
            "confidence": round(float(top.confidence) * 100, 1),
            "alternative_styles": "；".join(
                f"({alt.strategy}) {alt.text}" for alt in alternatives[:3]) or "（无备选）",
            "recent_context": _messages_as_text(messages[-6:]),
        }
    except Exception as e:  # noqa: BLE001 - 预测失败只影响这一条洞察
        log.debug(f"预测补位失败: {type(e).__name__}: {e}")
        return None


@server.tool()
async def ai_insight_from_chat(chat_text: str = "",
                               insight_type: str = "all",
                               platform: str = "auto") -> str:
    """一次调用完成「解析 → 全量分析 → 构造上下文 → AI 洞察」，无需手工回填参数。

    上面五个 ai_* 工具要求调用方自己把 MBTI/大五/情感数值抄进提示词变量里，
    实际没人这么用；这个工具把整条链接管了，分析器结果直接翻译成上下文。

    Args:
        chat_text: 聊天记录文本
        insight_type: all 或单类（personality_insight/emotion_narrative/
                      relationship_advice/risk_interpretation/prediction_explanation）
        platform: 导入平台 (auto/txt/wechat/qq/imessage/json/jsonl)
    """
    if ai_insight["attach_insights"] is None:
        return _module_error("ai_insight_engine")

    config = _load_config()
    if not config.get("ai_insight", {}).get("enabled", True):
        return "❌ config.ai_insight.enabled=false，AI 洞察已关闭"

    templates = ai_insight.get("PROMPT_TEMPLATES") or {}
    order = list(ai_insight.get("INSIGHT_ORDER") or templates.keys())
    wanted = (insight_type or "all").strip()
    if wanted in ("", "all"):
        types = list(order)
    elif wanted in templates:
        types = [wanted]
    else:
        return (f"❌ 未知洞察类型: {wanted}（可选 all 或 {', '.join(order)}）")

    results, messages, _meta, error = await _analyze_chat_text(chat_text, platform)
    if error:
        return error

    extra: Dict[str, Any] = {}
    if "prediction_explanation" in types:
        predicted = await _prediction_extra(messages, config)
        if predicted:
            extra = predicted

    text = "\n".join(f"{m.sender}: {m.content}" for m in messages
                     if m.has_content() and m.is_text())
    try:
        insights = await asyncio.to_thread(
            ai_insight["attach_insights"], results, config, text, None, types, extra)
    except Exception as e:  # noqa: BLE001
        return f"❌ AI 洞察异常: {type(e).__name__}: {str(e)[:200]}"

    generated = {k: v for k, v in insights.items() if not v.get("skipped")}
    return _json({
        "success": bool(generated),
        "engine": (ai_insight["get_engine"]().status()
                   if ai_insight.get("get_engine") else {}),
        "insights": insights,
    }, 16000)


# ============================================================================
# 3. 对话预测类工具
# ============================================================================

def _load_history_profile(ensemble, config: Dict[str, Any]) -> str:
    """给历史感知预测器载入上次画像，返回画像文件路径（空串=未启用）。"""
    path = (history_aware.get("default_profile_path") or (lambda _c: ""))(config)
    predictor = ensemble.get_predictor("history_aware") if path else None
    if predictor is None:
        return ""
    try:
        if predictor.load_profile(path):
            log.debug(f"已载入历史画像 {path}（{predictor.trained_sessions} 次会话）")
    except Exception as e:  # noqa: BLE001 - 画像坏了就当没有，不能阻断预测
        log.warning(f"历史画像载入失败: {type(e).__name__}: {e}")
    return path


def _save_history_profile(ensemble, path: str) -> Optional[Dict[str, Any]]:
    """把本次学到的画像存回文件，返回状态（None=未持久化）。"""
    predictor = ensemble.get_predictor("history_aware") if path else None
    if predictor is None:
        return None
    try:
        if not predictor.is_trained():
            return {"enabled": True, "saved": False,
                    "reason": "本批消息不足以训练（少于 min_history 条己方消息）"}
        predictor.save_profile(path)
        return {"enabled": True, "saved": True, "path": path,
                "trained_sessions": predictor.trained_sessions}
    except Exception as e:  # noqa: BLE001
        log.warning(f"历史画像保存失败: {type(e).__name__}: {e}")
        return {"enabled": True, "saved": False, "reason": str(e)[:120]}


@server.tool()
async def predict_reply(
    chat_text: str = "",
    mbti_self: str = "",
    mbti_other: str = "",
    scenario: str = "",
) -> str:
    """对话预测：基于规则 + RAG + 历史感知 + MiroFish 多层集成，预测对方可能回复。

    Args:
        chat_text: 最近聊天上下文
        mbti_self: 己方 MBTI（可选，提高预测准确性）
        mbti_other: 对方 MBTI（可选）
        scenario: 场景 romantic/work/social/important（留空则自动判断）
    """
    if predictors_init["create_default_ensemble"] is None:
        return _module_error("predictors")
    # ensemble.predict 收的是 PredictionContext dataclass，之前这里传了一个
    # 普通 dict，`context.messages` 立刻 AttributeError，被 except 吞成
    # "❌ 预测异常"——这个工具从上线起就没成功过。
    if core_context["PredictionContext"] is None:
        return _module_error("core.predictor_base")

    try:
        messages = _parse_chat_text(chat_text)
        if not messages:
            return "❌ 无法解析聊天内容"

        config = _load_config()
        ensemble = predictors_init["create_default_ensemble"](config)
        profile_path = _load_history_profile(ensemble, config)

        detected_scenario = scenario or await _detect_scenario(messages, config)
        context = core_context["PredictionContext"](
            messages=messages,
            scenario=detected_scenario,
            metadata={"mbti_self": mbti_self, "mbti_other": mbti_other},
        )
        # mbti_other 才是"对方会怎么回"的主输入；mbti_self 只用于风格校准
        if mbti_other:
            context.mbti = mbti_other

        result = await asyncio.to_thread(ensemble.predict, context)
        output = result.to_dict() if hasattr(result, "to_dict") else {"raw": str(result)}
        output["success"] = True
        profile = _save_history_profile(ensemble, profile_path)
        if profile is not None:
            output["history_profile"] = profile
        return _json(output, 12000)
    except Exception as e:
        return f"❌ 预测异常: {type(e).__name__}: {str(e)[:200]}"


@server.tool()
async def train_reply_predictor(chat_text: str = "") -> str:
    """把粘贴的聊天记录喂给历史感知预测器并落盘画像，越用越像本人说话。

    Args:
        chat_text: 你自己的历史回复所在的聊天记录（己方消息才会被学习）
    """
    if predictors_init["create_default_ensemble"] is None:
        return _module_error("predictors")
    try:
        messages = _parse_chat_text(chat_text)
        if not messages:
            return "❌ 无法解析聊天内容"

        config = _load_config()
        ensemble = predictors_init["create_default_ensemble"](config)
        predictor = ensemble.get_predictor("history_aware")
        if predictor is None:
            return _module_error("history_aware 预测器")

        path = (history_aware.get("default_profile_path") or (lambda _c: ""))(config)
        merged_previous = _load_history_profile(ensemble, config)
        stats = await asyncio.to_thread(predictor.train, messages)
        saved = _save_history_profile(ensemble, path)
        return _json({
            "success": bool(stats.get("trained")),
            "train_stats": stats,
            "profile_file": path,
            "restored_previous": bool(merged_previous),
            "persist": saved,
        }, 8000)
    except Exception as e:  # noqa: BLE001
        return f"❌ 预测器训练异常: {type(e).__name__}: {str(e)[:200]}"


@server.tool()
async def get_prediction_profile() -> str:
    """查看历史感知画像现状（会话数、词短语规模、文件位置），不改动任何数据。"""
    if history_aware["HistoryAwarePredictor"] is None:
        return _module_error("history_aware_predictor")
    try:
        config = _load_config()
        path = (history_aware.get("default_profile_path") or (lambda _c: ""))(config)
        predictor = history_aware["HistoryAwarePredictor"](config)
        loaded = bool(path) and predictor.load_profile(path)
        profile = predictor.export_profile() if loaded else {}
        return _json({
            "success": True,
            "profile_file": path or "",
            "persistence_enabled": bool(path),
            "loaded": loaded,
            "trained_sessions": predictor.trained_sessions,
            "unique_phrases": len(profile.get("phrase_freq") or {}),
            "context_pairs": len(profile.get("context_pairs") or []),
            "style_profile": profile.get("style_profile") or {},
            "hint": ("尚未积累画像：先用 train_reply_predictor 或 predict_reply 跑几次真实对话"
                     if not loaded else "画像已载入，预测会带上你的说话习惯"),
        }, 6000)
    except Exception as e:  # noqa: BLE001
        return f"❌ 画像状态异常: {str(e)[:200]}"



async def _detect_scenario(messages: List[Any], config: Dict[str, Any]) -> str:
    """用 scenario 分析器判断场景；不可用时回退 social。"""
    if analyzers_init["create_default_registry"] is None:
        return "social"
    try:
        registry = analyzers_init["create_default_registry"](config)
        analyzer = registry.get("scenario")
        if analyzer is None:
            return "social"
        result = await asyncio.to_thread(analyzer.analyze, messages)
        details = result.to_dict().get("details", {}) if hasattr(result, "to_dict") else {}
        for key in ("scenario", "type", "label"):
            value = details.get(key)
            if isinstance(value, str) and value:
                return value
        return "social"
    except Exception:  # noqa: BLE001 - 场景判断失败不该阻断预测
        return "social"


# ============================================================================
# 4. 数据导入类工具
# ============================================================================

@server.tool()
async def import_chat_from_text(chat_text: str = "", source_format: str = "auto") -> str:
    """从文本导入聊天记录，自动识别平台格式并解析为 Message 列表。

    Args:
        chat_text: 聊天文本（微信/企微/QQ/iMessage/短信/邮件/最简行格式）
        source_format: 指定平台 (auto/txt/wechat/wework/qq/imessage/email/json/jsonl)
    """
    try:
        fmt = (source_format or "auto").lower()
        if fmt in ("json", "jsonl") or _looks_structured(chat_text):
            result = _import_structured(chat_text, fmt)
            if result is not None:
                return result
            if fmt in ("json", "jsonl"):
                # 用户明确指定了结构化格式，就不能再假装按行解析成功
                return ("❌ 结构化解析失败：JSON/JSONL 需要每条记录是一个对象，"
                        "含 content/text/message 字段（可选 sender/from、timestamp/time）")

        messages, meta = _parse_chat_text_with_meta(chat_text, platform=fmt)
        output = {
            "success": True,
            "source_format": fmt,
            "detected_platform": meta["detected_platform"],
            "parser": meta["parser"],
            "message_count": len(messages),
            "with_timestamp": meta["with_timestamp"],
            "messages": _messages_to_payload(messages),
        }
        return _json(output, 8000)
    except Exception as e:
        return f"❌ 导入异常: {str(e)}"


# ============================================================================
# 4.5 报告导出与会话趋势类工具 (v5.0.0)
# ============================================================================

def _default_export_path(fmt: str, config: Dict[str, Any]) -> str:
    """导出文件默认落在运行时数据目录，绝不写进技能包内。"""
    from core.data_paths import resolve_data_dir
    ext = {"markdown": "md", "md": "md", "csv": "csv", "html": "html", "json": "json"}[fmt]
    stamp = time.strftime("%Y%m%d_%H%M%S")
    return str(resolve_data_dir() / "reports" / f"chat_report_{stamp}.{ext}")


@server.tool()
async def export_chat_report(chat_text: str = "",
                             export_format: str = "markdown",
                             output_path: str = "",
                             platform: str = "auto") -> str:
    """把分析结果导出成 Markdown / CSV / HTML / JSON 文件，返回路径与内容预览。

    Args:
        chat_text: 聊天记录文本
        export_format: markdown / csv / html / json
        output_path: 目标文件（留空则用运行时数据目录下的带时间戳文件名）
        platform: 导入平台 (auto/txt/wechat/qq/imessage/json/jsonl)
    """
    fmt = (export_format or "markdown").strip().lower()
    if fmt not in ("markdown", "md", "csv", "html", "json"):
        return f"❌ 不支持的格式: {fmt}（可用：markdown / csv / html / json）"
    if fmt not in ("html", "json") and report_exporters["write_report"] is None:
        return _module_error("report_exporters")

    results, messages, _meta, error = await _analyze_chat_text(chat_text, platform)
    if error:
        return error

    config = _load_config()
    from scripts.report_exporters import message_meta
    meta = message_meta(messages)
    target = output_path or _default_export_path(fmt, config)

    try:
        if fmt == "html":
            if v2_report["V2ReportGenerator"] is None:
                return _module_error("v2_report_generator")
            generator = v2_report["V2ReportGenerator"](config)
            path = await asyncio.to_thread(
                generator.generate, results, meta, target)
            text = ""
        elif fmt == "json":
            payload = {"version": VERSION, "meta": meta, "results": results}
            path = target
            directory = os.path.dirname(os.path.abspath(path))
            if directory:
                os.makedirs(directory, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(json.dumps(payload, ensure_ascii=False, indent=2, default=str))
            text = json.dumps(payload, ensure_ascii=False, default=str)
            if len(text) > 4000:
                text = text[:4000] + "\n…（预览已截断，完整内容见文件）"
        else:
            path = await asyncio.to_thread(
                report_exporters["write_report"], fmt, results, meta, target)
            with open(path, "r", encoding="utf-8-sig") as f:
                text = f.read()[:4000]
    except Exception as e:  # noqa: BLE001
        return f"❌ 导出失败: {type(e).__name__}: {str(e)[:200]}"

    return _json({
        "success": True,
        "format": fmt,
        "path": path,
        "size_bytes": os.path.getsize(path) if os.path.isfile(path) else 0,
        "content_preview": text,
    }, 6000)


@server.tool()
async def save_analysis_session(chat_text: str = "",
                                label: str = "",
                                platform: str = "auto") -> str:
    """把本次分析的关键指标存成会话快照（只存指标不存聊天原文），供以后看趋势。

    Args:
        chat_text: 聊天记录文本
        label: 备注名（如"吵架后""和好第三天"），对比时靠它认场景
        platform: 导入平台
    """
    if session_memory["save_snapshot"] is None:
        return _module_error("session_memory")
    results, messages, _meta, error = await _analyze_chat_text(chat_text, platform)
    if error:
        return error
    from scripts.report_exporters import message_meta
    config = _load_config()
    try:
        snapshot = await asyncio.to_thread(
            session_memory["save_snapshot"], results, message_meta(messages),
            config, label, "")
    except Exception as e:  # noqa: BLE001
        return f"❌ 快照保存失败: {type(e).__name__}: {str(e)[:200]}"
    return _json({"success": True, "snapshot": snapshot}, 6000)


@server.tool()
async def list_analysis_sessions(limit: int = 20) -> str:
    """列出历史会话快照（时间正序），用于回答"我们聊天的状态一直在变吗"。

    Args:
        limit: 返回条数上限
    """
    if session_memory["list_snapshots"] is None:
        return _module_error("session_memory")
    try:
        rows = session_memory["list_snapshots"](_load_config(), limit=limit)
        brief = [{"id": r.get("id"), "saved_at": r.get("saved_at"),
                  "label": r.get("label", ""), "metrics": r.get("metrics") or {}}
                 for r in rows]
        return _json({"success": True, "count": len(brief), "snapshots": brief,
                      "file": (session_memory.get("snapshot_file") or (lambda _c: ""))(_load_config())},
                     12000)
    except Exception as e:  # noqa: BLE001
        return f"❌ 快照读取失败: {str(e)[:200]}"


@server.tool()
async def compare_analysis_sessions(baseline_id: str = "",
                                   chat_text: str = "",
                                   platform: str = "auto") -> str:
    """对比两次会话的指标变化。默认"最新快照 vs 上一条"，也可以指定基线或用本次分析当现状。

    Args:
        baseline_id: 基线快照 id（留空则取次新一条）
        chat_text: 传了就先分析这段，把它当作"现状"来比
        platform: 导入平台
    """
    if session_memory["compare_sessions"] is None:
        return _module_error("session_memory")
    config = _load_config()
    try:
        current = None
        if chat_text and chat_text.strip():
            results, messages, _meta, error = await _analyze_chat_text(chat_text, platform)
            if error:
                return error
            from scripts.report_exporters import message_meta
            from datetime import datetime
            current = {
                "id": "live",
                "saved_at": datetime.now().isoformat(timespec="seconds"),
                "label": "本次分析",
                "meta": message_meta(messages),
            }
            current["metrics"] = session_memory["extract_metrics"](
                results, current["meta"])
        baseline = None
        if baseline_id:
            baseline = session_memory["get_snapshot"](baseline_id, config)
            if baseline is None:
                return f"❌ 找不到快照 id: {baseline_id}（先用 list_analysis_sessions 查）"
        report = await asyncio.to_thread(
            session_memory["compare_sessions"], current, baseline, config)
        return _json({"success": True, "comparison": report}, 12000)
    except Exception as e:  # noqa: BLE001
        return f"❌ 会话对比失败: {type(e).__name__}: {str(e)[:200]}"


# ============================================================================
# 5. 桌面微信捕获类工具
# ============================================================================

@server.tool()
async def capture_clipboard(duration: int = 10) -> str:
    """剪贴板监控：实时捕获从微信桌面端复制的消息。

    Args:
        duration: 监控时长（秒，默认10，最长60）
    """
    if clipboard_monitor["ClipboardMonitor"] is None:
        return _module_error("clipboard_monitor")

    try:
        duration = min(max(duration, 1), 60)
        monitor = clipboard_monitor["ClipboardMonitor"](_load_config())
        captured = []

        def collector(msgs):
            captured.extend(msgs)

        monitor.on_message(collector)
        started = await asyncio.to_thread(monitor.start)
        if not started:
            return json.dumps({"success": False, "error": "无法启动剪贴板监控（仅支持 Windows）"}, ensure_ascii=False)

        await asyncio.sleep(duration)
        await asyncio.to_thread(monitor.stop)

        output = {
            "success": True,
            "duration_sec": duration,
            "captured_count": len(captured),
            "messages": [
                {
                    "sender": m.sender,
                    "content": m.content[:200],
                    "timestamp": m.timestamp,
                    "role": m.role,
                }
                for m in captured[:100]
            ],
            "stats": monitor.get_stats(),
        }
        return _json(output, 8000)
    except Exception as e:
        return f"❌ 剪贴板监控异常: {str(e)[:200]}"


@server.tool()
async def capture_wechat_window() -> str:
    """读取微信桌面端窗口中的消息（需要微信正在运行）。"""
    if wechat_window["WeChatWindowReader"] is None:
        return _module_error("wechat_window_reader")

    try:
        reader = wechat_window["WeChatWindowReader"](_load_config())
        state = await asyncio.to_thread(reader.capture_state)

        if not state.is_open:
            return json.dumps({
                "success": False,
                "error": "微信桌面端未运行或未找到窗口",
                "hint": "请确保微信桌面端已登录并打开",
            }, ensure_ascii=False)

        output = {
            "success": True,
            "wechat_open": True,
            "window_title": state.window_title,
            "current_chat": state.current_chat,
            "message_count": len(state.message_list),
            "messages": [
                {
                    "sender": m.sender,
                    "content": m.content[:200],
                    "role": m.role,
                    "timestamp": m.timestamp,
                }
                for m in state.message_list[:100]
            ],
            "contact_count": len(state.contact_list),
            "contacts": [c.name for c in state.contact_list[:20]],
            "metadata": state.metadata,
        }
        return _json(output, 8000)
    except Exception as e:
        return f"❌ 微信窗口读取异常: {str(e)[:200]}"


@server.tool()
async def get_desktop_status() -> str:
    """获取桌面微信捕获能力状态（剪贴板监控 + 窗口读取）。"""
    import sys
    output = {
        "version": VERSION,
        "platform": sys.platform,
        "platform_supported": sys.platform == "win32",
    }

    # 剪贴板监控状态
    if clipboard_monitor["ClipboardMonitor"]:
        monitor = clipboard_monitor["get_monitor"](_load_config())
        output["clipboard_monitor"] = {
            "available": True,
            "stats": monitor.get_stats(),
        }
    else:
        output["clipboard_monitor"] = {"available": False}

    # 窗口读取状态
    if wechat_window["WeChatWindowReader"]:
        reader = wechat_window["get_reader"](_load_config())
        output["wechat_window"] = await asyncio.to_thread(reader.get_status)
    else:
        output["wechat_window"] = {"available": False}

    return _json(output, 6000)


# ============================================================================
# 6. 系统类工具
# ============================================================================

@server.tool()
async def get_skill_status() -> str:
    """获取 wechat-analyzer 技能状态（版本/能力/分析器/AI引擎）。"""
    output = {
        "version": VERSION,
        "skill_name": "wechat-analyzer",
        "display_name": "微信聊天分析助手",
        "mcp_sdk_available": HAS_MCP,
        "mcp_sdk_generation": MCP_SDK_GENERATION,
        "mcp_sdk_label": {0: "missing", 1: "1.x/FastMCP", 2: "2.x/MCPServer"}.get(
            MCP_SDK_GENERATION, "unknown"),
        "disclaimer": "⚠️ 分析仅供参考，不构成专业心理评估或法律意见。",
    }
    if not HAS_MCP:
        output["mcp_sdk_error"] = _MCP_IMPORT_ERROR
        output["mcp_sdk_hint"] = "pip install mcp（或 python scripts/main.py doctor 查看环境）"

    # 分析器状态
    if analyzers_init["create_default_registry"]:
        try:
            config = _load_config()
            registry = analyzers_init["create_default_registry"](config)
            # v5.0.0：用公开的 registry.list()，不再戳私有 _analyzers
            output["registered_analyzers"] = sorted(registry.list())
        except Exception as e:
            output["analyzers_error"] = str(e)

    # 预测器状态
    if predictors_init["create_default_ensemble"]:
        try:
            ensemble = predictors_init["create_default_ensemble"](_load_config())
            output["registered_predictors"] = sorted(ensemble.list_predictors())
        except Exception as e:
            output["predictors_error"] = str(e)

    # AI 引擎状态
    if ai_insight["get_engine"]:
        try:
            engine = ai_insight["get_engine"]()
            output["ai_engine"] = engine.status()
        except Exception as e:
            output["ai_engine_error"] = str(e)
    # 分析器结果→提示词这条链能不能真的构造出上下文。v3.0.0 的引擎就是这个
    # 环节缺失而整块空转，status 里必须看得见，而不是等用户问"为什么没有洞察"。
    if ai_insight["self_check"]:
        try:
            check = ai_insight["self_check"]()
            output["ai_insight_context"] = {
                "build_ok": check.get("context_build_ok", False),
                "builders": check.get("context_builders", {}),
            }
        except Exception as e:
            output["ai_insight_context_error"] = str(e)

    # v5.0.0 新接线的模块：任一不可用都会让对应工具直接返回"模块未加载"
    for key, bundle, names in (
        ("session_memory", session_memory, ("save_snapshot", "compare_sessions")),
        ("report_exporters", report_exporters, ("write_report",)),
        ("v2_report", v2_report, ("V2ReportGenerator",)),
        ("history_profile", history_aware, ("default_profile_path",)),
    ):
        output[key] = {
            "available": all(bundle.get(name) is not None for name in names),
            "missing": [n for n in names if bundle.get(n) is None],
        }

    # 多源导入器状态（v3.0.0 起就没人调用，v5.0.0 接线后必须能自检）
    if multi_source.get("MultiSourceImporter"):
        try:
            from scripts.data_source_importer import self_check as ms_self_check
            check = ms_self_check()
            output["multi_source"] = {
                "supported_platforms": check.get("supported_platforms", []),
                "self_check_passed": check.get("all_passed", False),
            }
        except Exception as e:
            output["multi_source_error"] = str(e)
    else:
        output["multi_source"] = {"available": False}

    # 工具列表：v5.0.0 改为从 server 实际注册表反查。
    # 之前是手写的固定名单，加工具时这里必然漏改，上报数字与真实值不符。
    tools = _list_registered_tools()
    output["mcp_tools"] = tools
    output["total_tools"] = len(tools)

    return _json(output, 8000)


def _list_registered_tools() -> List[str]:
    """列出当前注册的 MCP 工具名（同步安全，不依赖事件循环）。"""
    try:
        manager = getattr(server, "_tool_manager", None)
        if manager is not None:
            return sorted(t.name for t in manager.list_tools())
        stub = getattr(server, "stub_tools", None)
        if stub is not None:
            return sorted(stub.keys())
    except Exception as e:  # noqa: BLE001 - status 工具不该因为反射失败而报错
        log.debug(f"列举 MCP 工具失败: {e}")
    return []


# ============================================================================
# 主入口
# ============================================================================

class _StdoutFirewall:
    """把业务代码里的 print() 引流到 stderr，同时把真正的 stdout 完整留给协议。

    mcp.server.stdio 只在建立传输时读一次 sys.stdout.buffer，之后自己持有写句柄，
    所以 .buffer 指向真 stdout、write() 指向 stderr 两个通道互不干扰。
    直接 redirect_stdout(sys.stderr) 会让协议帧写进 stderr，客户端永远读不到回复。
    """

    def __init__(self, real_stdout, sink):
        self._real = real_stdout
        self._sink = sink

    @property
    def buffer(self):  # 协议信道
        return self._real.buffer

    @property
    def encoding(self):
        return getattr(self._sink, "encoding", "utf-8")

    def write(self, data):  # 业务信道
        return self._sink.write(data)

    def flush(self):
        for stream in (self._sink, self._real):
            try:
                stream.flush()
            except Exception:
                pass

    def isatty(self):
        return False

    def fileno(self):
        return self._sink.fileno()


def main():
    """MCP Server 入口 — 走 stdio 协议。"""
    if not HAS_MCP:
        sys.stderr.write(
            f"❌ MCP SDK 不可用：{_MCP_IMPORT_ERROR}\n"
            "   请运行: pip install mcp\n"
        )
        return 1

    log.info(f"wechat-analyzer MCP Server v{VERSION} 启动")

    # 只能在进入事件循环前一刻装上，不能放模块导入期：那时 stdio_server()
    # 还没读 .buffer，任何拿到 sys.stdout 的代码都会被引到 stderr。
    real_stdout = sys.stdout
    sys.stdout = _StdoutFirewall(real_stdout, sys.stderr)
    try:
        server.run(transport="stdio")
    finally:
        sys.stdout = real_stdout
    return 0


if __name__ == "__main__":
    sys.exit(main())
