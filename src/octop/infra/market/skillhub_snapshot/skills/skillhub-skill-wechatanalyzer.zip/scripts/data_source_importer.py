#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多源数据导入器 v3.0.0 (data_source_importer.py)

在 v2.x 的 file_importer.MultiFormatImporter（支持 txt/json/docx/pdf/pptx/xlsx 等）
基础上，新增 4 类多源数据接入能力：

1. **剪贴板智能粘贴**：自动识别微信/企业微信/QQ/iMessage/SMS/邮件 等格式
2. **多源 MCP 桥接**：从外部 MCP数据源（如 cn-financial-scraper 财报说、stock-researcher）
   拉取与"聊天分析"相关的上下文（例如：通过分析公告理解对话背景）
3. **URL 直连**：从公开URL（如公开聊天分享链接）导入聊天内容
4. **结构化 JSON-LD 解析**：处理带元数据的聊天导出格式

设计原则：
1. 完全兼容 v2.x 的 file_importer — 不破坏既有导入路径
2.零依赖核心（urllib），可选 BeautifulSoup/lxml
3.隐私保护：所有处理本地完成，不上传任何数据
4.容错：单个格式解析失败不影响其他源
"""

import csv
import html.parser as html_parser
import io
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ============================================================================
# 1. 智能粘贴格式识别器
# ============================================================================

# 各平台的聊天导出特征
PLATFORM_PATTERNS = {
    "wechat": {
        # 微信导出格式示例:
        # 2024-01-15 14:32:15 张三
        # 你好啊
        "name": "微信",
        "line_pattern": r"^(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s+(.+)$",
        "content_pattern": r"^[^:\n]+$",
    },
    "wework": {
        # 企业微信格式类似微信但可能带"@"标记
        "name": "企业微信",
        "line_pattern": r"^(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s+([^@:\n]+)(@?\S*)\s*$",
    },
    "qq": {
        # QQ 导出格式:
        # 2024-01-15 14:32:15
        # 张三
        # 你好啊
        "name": "QQ",
    },
    "imessage": {
        # iMessage 格式:
        # [2024-01-15 14:32:15] 张三: 你好啊
        "name": "iMessage",
        "line_pattern": r"^\[?(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\]?\s*([^:]+):\s*(.+)$",
    },
    "sms": {
        # 短信格式
        "name": "短信",
    },
    "email": {
        # 邮件格式: From: xxx Date: ... Subject: ... Body: ...
        "name": "邮件",
    },
}


def detect_platform(text: str) -> str:
    """检测聊天文本所属平台。"""
    if not text or len(text) < 5:
        return "unknown"

    # 检查各平台特征
    lines = text.splitlines()[:50]  # 仅看前 50 行

    # 微信特征：日期 + 发送者
    wechat_score = 0
    for line in lines[:10]:
        if re.match(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}", line):
            wechat_score += 1
            # 微信下一行通常是消息内容
            idx = lines.index(line)
            if idx + 1 < len(lines) and lines[idx + 1].strip():
                wechat_score += 0.5

    # iMessage 特征：[日期] 发送者: 内容（日期可带秒可不带秒）
    imessage_score = sum(
        1 for line in lines[:10]
        if re.match(r"^\[\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?\]\s*[^:]+:", line)
    )

    # QQ 特征：连续多行格式
    qq_score = sum(
        1 for line in lines[:30]
        if re.match(r"^\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}", line)
    )

    if imessage_score >= 2:
        return "imessage"
    if wechat_score >= 3:
        return "wechat"
    if qq_score >= 5:
        return "qq"

    # 简化格式："发送者: 内容" (中文冒号或英文冒号)
    simple_pattern = sum(
        1 for line in lines[:20]
        if re.match(r"^[^\n:：]+[:：][^\n]+$", line)
    )
    if simple_pattern >= 2:
        return "simple"

    return "unknown"


# ============================================================================
# 2. 多格式解析器
# ============================================================================

@dataclass
class ParsedMessage:
    """解析后的消息。"""
    sender: str = ""
    content: str = ""
    timestamp: Optional[str] = None
    raw: str = ""
    role: str = "unknown"  # self/other/unknown
    metadata: Dict[str, Any] = field(default_factory=dict)


_OTHER_SENDERS = {"对方", "ta", "他", "她", "theirs"}
_LEADING_TS = re.compile(
    r"^\[?(\d{4}[-/]\d{1,2}[-/]\d{1,2}(?:\s+|日)"
    r"(?:\s*\d{1,2}:\d{2}(?::\d{2})?)?)\]?\s*[::]?\s*"
)


def _role_of(sender: str) -> str:
    """从发送者名字判断角色。各解析器原来各写一份，集合还不一样。

    "我"这一侧直接复用 core 的唯一口径，避免解析器说"这是 self"而分析器
    按 Message.is_self() 判成对方。
    """
    from core.message import is_self_sender
    if is_self_sender(sender):
        return "self"
    name = (sender or "").strip().lower()
    if name in _OTHER_SENDERS:
        return "other"
    return "unknown"


def _split_sender_content(rest: str) -> Tuple[str, str]:
    """把 "张三: 你好" 拆成 ("张三", "你好")；整串没有冒号时视为纯发送者名。

    中英文冒号都要认，但必须取更靠前的那个：内容里也会出现冒号
    （"我: 注意：这个别切"），先找全角就会把 "我: 注意" 当成名字。
    名字段是纯数字说明切到了时间（"14:32:15 张三"），不当名字用。
    """
    positions = [pos for pos in (rest.find("："), rest.find(":")) if pos > 0]
    for idx in sorted(positions):
        sender = rest[:idx].strip()
        if sender and not sender.isdigit() and len(sender) <= 30:
            return sender, rest[idx + 1:].strip()
    return rest, ""


class SmartPasteParser:
    """智能粘贴解析器：自动识别多种聊天格式。"""

    @staticmethod
    def parse(text: str, platform: Optional[str] = None) -> List[ParsedMessage]:
        """根据平台解析聊天文本。

        Args:
            text: 聊天文本
            platform: 指定平台 (wechat/wework/qq/imessage/simple/auto)

        Returns:
            ParsedMessage 列表
        """
        if not text or not text.strip():
            return []

        if platform in (None, "auto"):
            platform = detect_platform(text)

        if platform == "wechat" or platform == "wework":
            return SmartPasteParser._parse_wechat(text)
        elif platform == "imessage":
            return SmartPasteParser._parse_imessage(text)
        elif platform == "qq":
            return SmartPasteParser._parse_qq(text)
        elif platform == "simple":
            return SmartPasteParser._parse_simple(text)
        else:
            # 尝试所有格式，按消息数最多的胜出
            candidates = [
                SmartPasteParser._parse_simple(text),
                SmartPasteParser._parse_imessage(text),
                SmartPasteParser._parse_wechat(text),
            ]
            candidates = [c for c in candidates if c]
            if candidates:
                return max(candidates, key=len)
            return []

    @staticmethod
    def _parse_simple(text: str) -> List[ParsedMessage]:
        """解析 "发送者: 内容" 格式，行首若带时间/日期一并取出而不是当成名字。"""
        messages = []
        # 支持中英文冒号、连续续行
        lines = text.splitlines()
        current = None

        for line in lines:
            line_stripped = line.strip()
            if not line_stripped:
                continue
            timestamp = None
            body = line_stripped
            ts_match = _LEADING_TS.match(line_stripped)
            if ts_match and ts_match.group(1):
                timestamp = ts_match.group(1).strip()
                body = line_stripped[ts_match.end():].strip()
            sender, content = _split_sender_content(body)
            if content:
                if current:
                    messages.append(current)
                current = ParsedMessage(
                    sender=sender, content=content, timestamp=timestamp,
                    raw=line, role=_role_of(sender),
                )
            elif current:
                # 没有冒号也像是"名字:"的续行
                current.content += "\n" + line_stripped
                current.raw += "\n" + line
            else:
                messages.append(ParsedMessage(
                    sender="", content=line_stripped, raw=line, role="unknown"))

        if current:
            messages.append(current)
        return messages

    @staticmethod
    def _parse_imessage(text: str) -> List[ParsedMessage]:
        """解析 iMessage [时间] 发送者: 内容 格式。"""
        messages = []
        pattern = re.compile(
            r"^\[?(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\]?\s*"
            r"([^:]+):\s*(.+)$"
        )
        for line in text.splitlines():
            m = pattern.match(line.strip())
            if m:
                ts, sender, content = m.group(1), m.group(2).strip(), m.group(3).strip()
                messages.append(ParsedMessage(
                    sender=sender, content=content, timestamp=ts, raw=line,
                    role=_role_of(sender),
                ))
        return messages

    @staticmethod
    def _parse_wechat(text: str) -> List[ParsedMessage]:
        """解析微信/企业微信 时间戳+发送者 格式。

        两种粘贴形态都得吃下：
          2024-01-15 14:32:15 张三         2024-01-15 14:32:15 张三: 你好啊
          你好啊                            ← 单行式（聊天窗口选中复制）
        之前只认前者，单行式会被整行塞进 sender、content 留空，
        所有分析器因为"没有文本"静默跳过——用户看到的是"分析出来了但全是空"。
        """
        messages = []
        lines = text.splitlines()
        ts_pattern = re.compile(
            r"^(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s+(.+)$"
        )

        current = None
        for line in lines:
            line_stripped = line.strip()
            if not line_stripped:
                continue
            m = ts_pattern.match(line)
            if m:
                if current:
                    messages.append(current)
                ts, rest = m.group(1), m.group(2).strip()
                sender, inline_content = _split_sender_content(rest)
                current = ParsedMessage(
                    sender=sender, content=inline_content,
                    timestamp=ts, raw=line, role=_role_of(sender),
                )
            else:
                if current:
                    if current.content:
                        current.content += "\n" + line_stripped
                    else:
                        current.content = line_stripped
                    current.raw += "\n" + line
                else:
                    # 没有时间戳的行，作为无主消息
                    messages.append(ParsedMessage(
                        sender="", content=line_stripped, raw=line, role="unknown"
                    ))

        if current:
            messages.append(current)
        return messages

    @staticmethod
    def _parse_qq(text: str) -> List[ParsedMessage]:
        """解析 QQ 格式（时间戳行后接发送者行再接内容）。"""
        messages = []
        lines = text.splitlines()
        ts_pattern = re.compile(
            r"^(\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s*$"
        )

        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue
            ts_match = ts_pattern.match(line)
            if ts_match and i + 2 < len(lines):
                ts = ts_match.group(1)
                sender = lines[i + 1].strip()
                content = lines[i + 2].strip() if i + 2 < len(lines) else ""
                messages.append(ParsedMessage(
                    sender=sender, content=content, timestamp=ts,
                    raw="\n".join(lines[i:i+3]), role=_role_of(sender),
                ))
                i += 3
            else:
                i += 1
        return messages


# ============================================================================
# 3. URL 数据导入器
# ============================================================================

class URLImporter:
    """从公开 URL 导入聊天内容（仅支持无需登录的公开页面）。"""

    SUPPORTED_PATTERNS = [
        # 公开聊天分享页面
        r"https?://(?:www\.)?chat\.example\.com/[\w-]+",
    ]

    def __init__(self, timeout: int = 15, max_size: int = 1024 * 1024):
        self.timeout = timeout
        self.max_size = max_size

    def fetch(self, url: str) -> Optional[str]:
        """从 URL 获取内容（纯文本）。"""
        if not url.startswith(("http://", "https://")):
            return None
        try:
            from urllib.request import Request, urlopen
            req = Request(url, headers={
                "User-Agent": "Mozilla/5.0 (compatible; wechat-analyzer/3.0)",
                "Accept": "text/plain, text/html;q=0.9",
            })
            with urlopen(req, timeout=self.timeout) as resp:
                data = resp.read(self.max_size)
                # 尝试解码
                for enc in ("utf-8", "gb18030", "gbk", "latin-1"):
                    try:
                        return data.decode(enc)
                    except (UnicodeDecodeError, LookupError):
                        continue
                return data.decode("utf-8", errors="replace")
        except Exception as e:
            logger.debug(f"URL fetch failed {url}: {e}")
            return None


# ============================================================================
# 4. JSON-LD / 结构化导入器
# ============================================================================

class StructuredChatImporter:
    """处理带元数据的结构化聊天格式（JSON-LD / Schema.org / 自定义格式）。"""

    @staticmethod
    def parse_jsonl(text: str) -> List[ParsedMessage]:
        """解析 JSONL 格式（每行一个 JSON）。"""
        messages = []
        for i, line in enumerate(text.splitlines()):
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                obj = json.loads(line)
                msg = StructuredChatImporter._from_dict(obj)
                if msg:
                    messages.append(msg)
            except json.JSONDecodeError:
                continue
        return messages

    @staticmethod
    def parse_json_array(text: str) -> List[ParsedMessage]:
        """解析 JSON 数组格式。"""
        try:
            data = json.loads(text)
            if isinstance(data, list):
                return [
                    msg for obj in data
                    if (msg := StructuredChatImporter._from_dict(obj))
                ]
            elif isinstance(data, dict):
                # 尝试常见的字段
                for key in ("messages", "chat", "data", "items"):
                    if key in data and isinstance(data[key], list):
                        return [
                            msg for obj in data[key]
                            if (msg := StructuredChatImporter._from_dict(obj))
                        ]
        except json.JSONDecodeError:
            pass
        return []

    @staticmethod
    def _from_dict(obj: Dict[str, Any]) -> Optional[ParsedMessage]:
        """从 dict 构造 ParsedMessage。"""
        if not isinstance(obj, dict):
            return None

        # 字段名兼容
        sender = obj.get("sender") or obj.get("from") or obj.get("user") or obj.get("name", "")
        content = obj.get("content") or obj.get("text") or obj.get("message") or obj.get("body", "")
        timestamp = obj.get("timestamp") or obj.get("time") or obj.get("date") or obj.get("created_at")

        if not content:
            return None

        role = obj.get("role") or obj.get("sender_role") or "unknown"
        if role not in ("self", "other", "unknown"):
            role = "unknown"

        # 元数据
        metadata = {}
        for k, v in obj.items():
            if k not in ("sender", "from", "user", "name", "content", "text",
                        "message", "body", "timestamp", "time", "date",
                        "created_at", "role", "sender_role"):
                metadata[k] = v

        return ParsedMessage(
            sender=str(sender), content=str(content),
            timestamp=str(timestamp) if timestamp else None,
            raw=json.dumps(obj, ensure_ascii=False)[:500],
            role=role, metadata=metadata,
        )


# ============================================================================
# 4.5 文件形态导入器（v5.0.0 新增）
# ============================================================================

SELF_NAMES = ("我", "self", "me", "Me", "本人")
OTHER_NAMES = ("对方", "TA", "ta", "他", "她")


def role_for_sender(sender: str) -> str:
    """把发送者标识映射成 self/other/unknown（与各平台解析器同一口径）。"""
    s = (sender or "").strip()
    if s in SELF_NAMES:
        return "self"
    if s in OTHER_NAMES:
        return "other"
    return "unknown"


# class/id 里出现这些词，就认为该节点承载对应字段
_HTML_SENDER_TOKENS = ("sender", "nickname", "author", "from", "who", "name", "user")
_HTML_TIME_TOKENS = ("time", "date", "timestamp", "datetime")
_HTML_CONTENT_TOKENS = ("content", "text", "message", "msg", "body", "bubble", "talk")


def _html_token_of(identity: str) -> Optional[str]:
    lowered = (identity or "").lower()
    for tokens, kind in ((_HTML_SENDER_TOKENS, "sender"),
                         (_HTML_TIME_TOKENS, "time"),
                         (_HTML_CONTENT_TOKENS, "content")):
        for tok in tokens:
            if tok in lowered:
                return kind
    return None


class _ChatHtmlCollector(html_parser.HTMLParser):
    """按 class/id 关键词，把导出 HTML 里的 发送者/时间/内容 文本分桶收下。"""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._stack: List[Optional[str]] = []
        self._skip = 0
        self.records: List[Tuple[str, str]] = []

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1
        attr_map = {}
        for key, value in attrs:
            if key and value is not None:
                attr_map.setdefault(key, value)
        kind = _html_token_of(f"{attr_map.get('class', '')} {attr_map.get('id', '')}")
        self._stack.append(kind)

    def handle_startendtag(self, tag, attrs):
        # <br/> 之类自闭合标签不入栈，否则会多弹一次导致栈错位
        return

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self._skip:
            self._skip -= 1
        if self._stack:
            self._stack.pop()

    def handle_data(self, data):
        if self._skip:
            return
        text = (data or "").strip()
        if not text:
            return
        kind = "text"
        for entry in reversed(self._stack):
            if entry:
                kind = entry
                break
        self.records.append((kind, text))


def strip_html(html_text: str) -> str:
    """把 HTML 拍成纯文本行（脚本/样式整块丢弃）。"""

    class _Stripper(html_parser.HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.parts: List[str] = []
            self._skip_depth = 0

        def handle_starttag(self, tag, attrs):
            if tag in ("script", "style"):
                self._skip_depth += 1
            elif tag in ("br", "p", "div", "li", "tr"):
                self.parts.append("\n")

        def handle_endtag(self, tag):
            if tag in ("script", "style") and self._skip_depth:
                self._skip_depth -= 1

        def handle_data(self, data):
            if not self._skip_depth and data.strip():
                self.parts.append(data.strip() + " ")

    stripper = _Stripper()
    stripper.feed(html_text)
    return "\n".join(line.strip() for line in "".join(stripper.parts).splitlines()
                     if line.strip())


class WeChatHtmlImporter:
    """微信聊天记录 HTML 导入。

    各家导出工具（官方 PC 端、WeChatExporter、各种备份小程序）没有统一的
    DOM 约定，所以这里两层兜底：
        1) 结构化层：按 class/id 关键词配对 发送者/时间/内容；
        2) 纯文本层：拍平 HTML 后交给 SmartPasteParser 认行格式。
    第 1 层抓不到 2 条以上就自动降级，不硬撑。
    """

    @staticmethod
    def looks_like_html(text: str) -> bool:
        head = (text or "")[:4000].lstrip().lower()
        return head.startswith("<!doctype html") or head.startswith("<html") \
            or "<body" in head

    @staticmethod
    def _pair_records(records: List[Tuple[str, str]]) -> List[ParsedMessage]:
        messages: List[ParsedMessage] = []
        sender = ""
        timestamp = ""
        buf: List[str] = []

        def flush():
            if not buf:
                return
            content = " ".join(buf).strip()
            if content:
                messages.append(ParsedMessage(
                    sender=sender, content=content, timestamp=timestamp or None,
                    raw=content, role=role_for_sender(sender),
                ))
            buf.clear()

        for kind, text in records:
            if kind == "sender":
                flush()
                sender = text
                timestamp = ""
            elif kind == "time":
                flush()
                timestamp = text
            elif kind == "content":
                if buf and text == buf[-1]:
                    continue  # 同一节点被 class/id 命中两次的重复文本
                buf.append(text)
            elif kind == "text" and (sender or timestamp):
                buf.append(text)
        flush()
        return messages

    @classmethod
    def parse(cls, html_text: str, platform_hint: str = "auto") -> List[ParsedMessage]:
        if not html_text or not html_text.strip():
            return []

        collector = _ChatHtmlCollector()
        try:
            collector.feed(html_text)
        except Exception as e:  # noqa: BLE001 - 畸形 HTML 一律走纯文本兜底
            logger.debug(f"HTML 结构化解析失败，降级纯文本: {e}")
            collector.records = []

        structured = cls._pair_records(collector.records)
        if len(structured) >= 2:
            return structured

        plain = strip_html(html_text)
        return SmartPasteParser.parse(plain, platform=platform_hint)


class DelimitedImporter:
    """CSV / TSV 导入（微信"导出为表格"、各类后台下载的报告都是这个形态）。"""

    @classmethod
    def looks_delimited(cls, text: str) -> bool:
        """保守判断是不是表格文本。

        普通粘贴的聊天里也满是逗号，所以要求：首行至少两列、每行列数一致、
        表头里能认出"发送者 + 内容"两类列。三条全中才当 CSV 处理。
        """
        lines = [ln for ln in (text or "").splitlines() if ln.strip()]
        if len(lines) < 3:
            return False
        delimiter = cls.sniff_dialect(lines[0])
        counts = {ln.count(delimiter) for ln in lines}
        if len(counts) != 1 or counts.pop() < 2:
            return False
        header = [h.strip().lower() for h in lines[0].split(delimiter)]
        kinds = {cls._classify_column(h) for h in header}
        return "sender" in kinds and "content" in kinds

    @staticmethod
    def sniff_dialect(sample: str) -> str:
        first = (sample.splitlines() or [""])[0]
        if "\t" in first:
            return "\t"
        if ";" in first and "," not in first:
            return ";"
        return ","

    @classmethod
    def parse(cls, text: str) -> List[ParsedMessage]:
        if not text or not text.strip():
            return []
        delimiter = cls.sniff_dialect(text)
        reader = csv.reader(io.StringIO(text), delimiter=delimiter)
        try:
            rows = list(reader)
        except Exception as e:
            logger.debug(f"CSV 解析失败: {e}")
            return []
        if len(rows) < 2:
            return []

        header = [(h or "").strip().lower() for h in rows[0]]
        col = {}
        for idx, name in enumerate(header):
            col[idx] = cls._classify_column(name)

        messages: List[ParsedMessage] = []
        for row in rows[1:]:
            if not any((cell or "").strip() for cell in row):
                continue
            rec: Dict[str, str] = {}
            extra: Dict[str, str] = {}
            for idx, cell in enumerate(row):
                kind = col.get(idx, "")
                value = (cell or "").strip()
                if not value:
                    continue
                if kind:
                    rec[kind] = value
                else:
                    extra[header[idx] or f"col{idx}"] = value
            if not rec.get("content"):
                continue
            messages.append(ParsedMessage(
                sender=rec.get("sender", ""),
                content=rec["content"],
                timestamp=rec.get("timestamp") or None,
                raw=" | ".join((cell or "").strip() for cell in row),
                role=rec.get("role") or role_for_sender(rec.get("sender", "")),
                metadata=extra,
            ))
        return messages

    @staticmethod
    def _classify_column(name: str) -> str:
        """表头 → 字段名。中英文都认，因为导出工具的表头语言不固定。"""
        if not name:
            return ""
        if any(k in name for k in ("发送人", "发送者", "昵称", "发言人", "姓名",
                                   "sender", "from", "name", "user", "who")):
            return "sender"
        if any(k in name for k in ("内容", "消息", "正文", "文本", "content",
                                   "message", "text", "body")):
            return "content"
        if any(k in name for k in ("时间", "日期", "timestamp", "time", "date")):
            return "timestamp"
        if "role" in name or "角色" in name:
            return "role"
        return ""


# ============================================================================
# 5. 多源路由器（统一入口）
# ============================================================================

@dataclass
class ImportResult:
    """导入结果。"""
    success: bool = False
    source: str = ""
    messages: List[ParsedMessage] = field(default_factory=list)
    error: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


class MultiSourceImporter:
    """多源数据导入器（统一入口）。

    用法:
        importer = MultiSourceImporter()
        result = importer.import_text(chat_text)
        # 或
        result = importer.import_file("path/to/file.txt")
        # 或
        result = importer.import_url("https://...")
    """

    def __init__(self):
        self.paste_parser = SmartPasteParser()
        self.url_importer = URLImporter()
        self.structured = StructuredChatImporter()

    def import_text(self, text: str, platform: str = "auto") -> ImportResult:
        """从文本导入（自动识别 HTML 导出 / CSV / JSON / 各平台粘贴格式）。"""
        try:
            platform = platform or "auto"
            if platform == "auto":
                if WeChatHtmlImporter.looks_like_html(text):
                    return self.import_html(text)
                if DelimitedImporter.looks_delimited(text):
                    return self.import_delimited(text)
                structured = self._import_jsonish(text)
                if structured is not None:
                    return structured
            elif platform == "wechat_html":
                return self.import_html(text)
            elif platform in ("csv", "tsv"):
                return self.import_delimited(text)
            elif platform in ("json", "jsonl"):
                result = self._import_jsonish(text)
                if result is not None:
                    return result
                # 用户点名是 JSON 却解析不出来时不能悄悄降级成按行解析：
                # 那样会返回一堆莫名其妙的消息，而不是告诉他格式不对。
                return ImportResult(
                    success=False, source=platform,
                    error="JSON/JSONL 解析失败：每条记录需要是含 content/text/message "
                          "字段的对象（可选 sender/from、timestamp/time）",
                )

            detected = detect_platform(text) if platform == "auto" else platform
            messages = self.paste_parser.parse(text, platform=detected)
            return ImportResult(
                success=bool(messages),
                source=f"text:{detected}",
                messages=messages,
                metadata={"detected_platform": detected, "message_count": len(messages)},
            )
        except Exception as e:
            return ImportResult(success=False, source="text", error=str(e)[:200])

    def _import_jsonish(self, text: str) -> Optional[ImportResult]:
        """文本确实是一段 JSON/JSONL 时解析，否则返回 None 让调用方继续按行识别。

        v4.0.0 之前这段逻辑只存在于 mcp_server 里，CLI 与 import_file(".json")
        走不到，同一个包对同一份数据有两种结果。
        """
        stripped = (text or "").lstrip()
        if not stripped or stripped[0] not in "[{":
            return None
        if stripped[0] == "[":
            result = self.import_json(stripped)
            return result if result.success else None
        if "\n{" in stripped:
            result = self.import_jsonl(stripped)
            if result.success:
                return result
        result = self.import_json(stripped)
        return result if result.success else None

    def import_html(self, text: str) -> ImportResult:
        """从微信聊天记录 HTML 导入。"""
        try:
            messages = WeChatHtmlImporter.parse(text)
            return ImportResult(
                success=bool(messages), source="wechat_html", messages=messages,
                metadata={"detected_platform": "wechat_html",
                          "message_count": len(messages)},
            )
        except Exception as e:
            return ImportResult(success=False, source="wechat_html", error=str(e)[:200])

    def import_delimited(self, text: str) -> ImportResult:
        """从 CSV / TSV 导入。"""
        try:
            messages = DelimitedImporter.parse(text)
            return ImportResult(
                success=bool(messages), source="csv", messages=messages,
                metadata={"detected_platform": "csv",
                          "message_count": len(messages)},
            )
        except Exception as e:
            return ImportResult(success=False, source="csv", error=str(e)[:200])

    def import_jsonl(self, text: str) -> ImportResult:
        """从 JSONL 导入。"""
        try:
            messages = self.structured.parse_jsonl(text)
            return ImportResult(
                success=bool(messages), source="jsonl", messages=messages,
                metadata={"message_count": len(messages)},
            )
        except Exception as e:
            return ImportResult(success=False, source="jsonl", error=str(e)[:200])

    def import_json(self, text: str) -> ImportResult:
        """从 JSON 数组/对象导入。"""
        try:
            messages = self.structured.parse_json_array(text)
            return ImportResult(
                success=bool(messages), source="json", messages=messages,
                metadata={"message_count": len(messages)},
            )
        except Exception as e:
            return ImportResult(success=False, source="json", error=str(e)[:200])

    def import_url(self, url: str) -> ImportResult:
        """从 URL 导入。"""
        try:
            content = self.url_importer.fetch(url)
            if not content:
                return ImportResult(success=False, source="url", error="无法获取内容")
            # 自动检测格式
            text_content = content.strip()
            if text_content.startswith("["):
                return self.import_json(text_content)
            elif text_content.startswith("{"):
                # 尝试 JSONL（多行）或 JSON object
                if "\n{" in text_content:
                    return self.import_jsonl(text_content)
                else:
                    return self.import_json(text_content)
            else:
                return self.import_text(content)
        except Exception as e:
            return ImportResult(success=False, source="url", error=str(e)[:200])

    def import_file(self, file_path: str) -> ImportResult:
        """从文件导入（按扩展名分发）。"""
        if not os.path.isfile(file_path):
            return ImportResult(success=False, source="file", error=f"文件不存在: {file_path}")

        ext = os.path.splitext(file_path)[-1].lower()

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            try:
                with open(file_path, "r", encoding="gb18030") as f:
                    content = f.read()
            except Exception as e:
                return ImportResult(success=False, source="file", error=f"编码错误: {e}")
        except Exception as e:
            return ImportResult(success=False, source="file", error=str(e)[:200])

        if ext in (".txt", ".md", ".log"):
            return self.import_text(content)
        elif ext == ".jsonl" or ext == ".ndjson":
            return self.import_jsonl(content)
        elif ext == ".json":
            return self.import_json(content)
        elif ext in (".html", ".htm"):
            # v5.0.0：微信官方/第三方导出常给 HTML，之前落到"默认按文本处理"，
            # 结果整篇标签被当成一条消息，条数永远是 1。
            return self.import_html(content)
        elif ext in (".csv", ".tsv"):
            return self.import_delimited(content)
        else:
            # 默认按文本处理
            return self.import_text(content)

    def to_core_messages(self, parsed: List[ParsedMessage]) -> List[Any]:
        """转换为 core.Message 对象（如果可用）。"""
        try:
            from core.message import Message, MessageType, SenderRole
            from core.utils import parse_timestamp
        except ImportError:
            return []

        role_map = {
            "self": SenderRole.SELF,
            "other": SenderRole.OTHER,
            "unknown": SenderRole.UNKNOWN,
        }
        core_messages = []
        for m in parsed:
            role = role_map.get(m.role, SenderRole.UNKNOWN)
            # v5.0.0：之前这里完全丢弃 ParsedMessage.timestamp，
            # 转成 core.Message 后 timing/relationship 分析拿不到任何时间信息，
            # 滚动趋势与回复延迟全成默认值。
            core_messages.append(Message(
                sender=m.sender or "unknown",
                content=m.content,
                timestamp=parse_timestamp(m.timestamp),
                message_type=MessageType.TEXT,
                raw=m.raw,
                metadata={"role": role.value, "timestamp_raw": m.timestamp, **m.metadata},
            ))
        return core_messages


# ============================================================================
# 6. 自检
# ============================================================================

def self_check() -> Dict[str, Any]:
    """多源导入自检。

    v5.0.0：以前这里把 URLImporter / StructuredChatImporter 一律写成 "OK"，
    一个都没真测——自检报告于是永远全绿，形同虚设。现在每种格式都有
    一条真实输入和期望条数，状态由实际结果推导。
    """
    paste_cases = [
        ("simple", "我: 你好\n对方: 你也好\n我: 吃饭了吗", 3),
        ("simple", "张三: hi\n李四: hello", 2),
        ("imessage", "[2024-01-15 14:32:15] 张三: 你好\n[2024-01-15 14:33:00] 李四: 在吗", 2),
        ("wechat", "2024-01-15 14:32:15 张三\n你好啊\n2024-01-15 14:33:00 我\n在的", 2),
        ("wechat", "2024-01-15 14:32:15 张三: 你好啊\n2024-01-15 14:33:00 我: 在的", 2),
    ]
    results = []
    for platform, text, expected in paste_cases:
        parsed = SmartPasteParser.parse(text, platform=platform)
        results.append({
            "case": f"paste:{platform}",
            "expected_count": expected,
            "actual_count": len(parsed),
            # 条数对但 content 全空=白解析：曾经微信单行式就是这个样子，
            # 分析器因为"没有文本"静默跳过，自检却一片绿。
            "match": len(parsed) == expected and all(p.content.strip() for p in parsed),
        })

    inline = SmartPasteParser.parse("2024-01-15 14:32:15 我: 注意：这个冒号别切",
                                    platform="wechat")
    results.append({
        "case": "paste:wechat:inline_split",
        "expected_count": 1,
        "actual_count": len(inline),
        "match": bool(inline) and inline[0].sender == "我"
        and inline[0].content == "注意：这个冒号别切",
    })

    importer = MultiSourceImporter()

    jsonl = ('{"sender": "张三", "content": "你好", "timestamp": "2024-01-15 14:32:15"}\n'
             '{"sender": "我", "content": "在的"}')
    res = importer.import_jsonl(jsonl)
    results.append({"case": "jsonl", "expected_count": 2,
                    "actual_count": len(res.messages), "match": res.success
                    and len(res.messages) == 2})

    arr = '[{"from": "张三", "text": "你好"}, {"from": "我", "text": "在的"}]'
    res = importer.import_json(arr)
    results.append({"case": "json", "expected_count": 2,
                    "actual_count": len(res.messages), "match": res.success
                    and len(res.messages) == 2})

    html_doc = (
        '<!DOCTYPE html><html><body>'
        '<div class="message"><span class="sender">张三</span>'
        '<span class="time">2024-01-15 14:32:15</span>'
        '<div class="content">你好啊</div></div>'
        '<div class="message"><span class="sender">我</span>'
        '<span class="time">2024-01-15 14:33:00</span>'
        '<div class="content">在的</div></div>'
        '<script>var leak = 1;</script></body></html>'
    )
    res = importer.import_html(html_doc)
    html_ok = (res.success and len(res.messages) == 2
               and not any("leak" in m.content for m in res.messages)
               and all(m.timestamp for m in res.messages))
    results.append({"case": "wechat_html:structural", "expected_count": 2,
                    "actual_count": len(res.messages), "match": html_ok})

    # 结构识别不出来时必须降级成纯文本行，而不是返回 1 条整页标签
    plain_html = ('<html><body><p>2024-01-15 14:32:15 张三</p><p>你好啊</p>'
                  '<p>2024-01-15 14:33:00 我</p><p>在的</p></body></html>')
    res = importer.import_html(plain_html)
    results.append({"case": "wechat_html:fallback", "expected_count": 2,
                    "actual_count": len(res.messages),
                    "match": res.success and len(res.messages) >= 2})

    csv_doc = "发送者,时间,内容\n张三,2024-01-15 14:32:15,你好啊\n我,2024-01-15 14:33:00,在的\n"
    res = importer.import_text(csv_doc)
    results.append({"case": "csv", "expected_count": 2,
                    "actual_count": len(res.messages),
                    "match": res.success and len(res.messages) == 2
                    and (res.metadata or {}).get("detected_platform") == "csv"})

    # 普通粘贴不能被 CSV 判定劫走
    not_csv = importer.import_text("我: 你好，今天不错\n对方: 嗯，好的\n我: 周末见，行吗")
    results.append({"case": "csv:not_hijacked", "expected_count": 3,
                    "actual_count": len(not_csv.messages),
                    "match": len(not_csv.messages) == 3
                    and (not_csv.metadata or {}).get("detected_platform") != "csv"})

    all_passed = all(r["match"] for r in results)
    return {
        "version": f"v{__import__('core.version', fromlist=['__version__']).__version__}",
        "supported_platforms": list(PLATFORM_PATTERNS.keys()) + ["wechat_html", "csv"],
        "modules": {
            "MultiSourceImporter": "OK" if all_passed else "部分失败",
            "SmartPasteParser": "OK" if all(r["match"] for r in results
                                            if r["case"].startswith("paste:")) else "失败",
            "StructuredChatImporter": "OK" if all(r["match"] for r in results
                                                  if r["case"] in ("json", "jsonl")) else "失败",
            "WeChatHtmlImporter": "OK" if all(r["match"] for r in results
                                              if "html" in r["case"]) else "失败",
            "DelimitedImporter": "OK" if all(r["match"] for r in results
                                             if r["case"].startswith("csv")) else "失败",
            "URLImporter": "未自检（需要联网，交由调用方按需触发）",
        },
        "test_results": results,
        "all_passed": all_passed,
    }


if __name__ == "__main__":
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))
