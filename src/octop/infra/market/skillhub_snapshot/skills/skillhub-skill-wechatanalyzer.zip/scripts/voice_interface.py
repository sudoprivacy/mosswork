#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""语音交互模块（v2.9.0 新增）。

零依赖分层设计（逐级降级，任何环境都可用）：
- TTS：pyttsx3（可选）→ Windows SAPI（PowerShell 5.1 System.Speech，系统自带）→ 终端打印
- STT：speech_recognition（可选）→ Windows SAPI 听写识别 → input() 文本输入
- 所有意图均可「说」或「打字」完成；speaker/listener/executor 全部可注入，方便测试。

支持意图（口语化）：
- analyze    「分析 chat.txt / 帮我分析聊天记录」→ v2 模块化分析
- predict    「预测一下 / 他接下来会说什么」→ 三层融合预测
- demo       「演示 / 体验一下」→ 一键示例
- doctor     「检查环境 / 自检」→ 环境自检
- report     「生成报告 / 出个报告」→ 离线 HTML 报告
- calendar   「日历 / 日程」→ 日历事件
- graph      「图谱 / 知识图谱」→ MiroFish 图谱统计
- help / quit

用法：
  python scripts/main.py voice                # 进入语音会话
  python scripts/voice_interface.py           # 直接启动（--demo-file 可指定示例）
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

# PowerShell 5.1（Windows 自带，System.Speech 免安装）
_PS_EXE = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

_FILE_SUFFIXES = (".txt", ".json", ".docx", ".pdf", ".log")

# 裸文件名候选的前导动词/停用词（逐个剔除，直到剩下真正的文件名）
_STRIP_WORDS = sorted(
    ("帮我分析", "请帮我", "帮我", "帮忙", "请", "分析", "预测",
     "看看", "检查", "读一下", "一下", "我的", "我们的", "这个",
     "这份", "那个", "那份", "这个文件", "文件"),
    key=len, reverse=True,
)


# ============================================================
# 1. 文本归一化 + 口语指令解析
# ============================================================

_FULLWIDTH_OFFSET = 0xFEE0  # 全角 → 半角偏移（！～ 区间）


# 常见中英文标点（去标点用；re.escape 构造字符类，避免手写转义陷阱）
_PUNCT_CHARS = (
    "，。！？、；：“”‘’（）《》【】"
    ",.!?;:'()[]{}<>~`@#$%^&*_+=/\\|-"
)
_PUNCT_RE = re.compile("[" + re.escape(_PUNCT_CHARS) + "]")


def normalize_text(text: str) -> str:
    """归一化用户输入：去首尾空白、全角转半角、小写、去常见标点。"""
    if not text:
        return ""
    out = []
    for ch in text.strip():
        code = ord(ch)
        if 0xFF01 <= code <= 0xFF5E:
            ch = chr(code - _FULLWIDTH_OFFSET)
        out.append(ch)
    s = "".join(out).lower()
    # 去常见中英文标点（保留字母/数字/汉字/空格/引号内路径由提取阶段处理）
    s = _PUNCT_RE.sub(" ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def extract_file_path(text: str) -> str | None:
    """从原始文本提取文件路径（保留标点与空格，先于归一化处理）。

    支持：带引号路径、含盘符/目录的路径、以已知后缀结尾的裸文件名。
    """
    if not text:
        return None
    # 1. 引号包裹的路径
    m = re.search(r'["\u201c\u201d\u300c\u300d]([^"\u201c\u201d\u300c\u300d]+)["\u201c\u201d\u300c\u300d]', text)
    if m:
        cand = m.group(1).strip()
        if cand:
            return cand
    # 2. 含目录分隔符或盘符的路径
    m = re.search(r"([A-Za-z]:[\\/][^\s，。！？、]+|\.{0,2}[\\/][^\s，。！？、]+)", text)
    if m:
        return m.group(1)
    # 3. 以已知后缀结尾的裸文件名（允许中文/空格/连字符）
    suffix_alt = "|".join(s.replace(".", r"\.") for s in _FILE_SUFFIXES)
    for m in re.finditer(r"([\w\-.\u4e00-\u9fff ]+?(?:" + suffix_alt + r"))", text):
        cand = m.group(1).strip()
        # 剔除前导动词/停用词（如「帮我分析 chat.txt」→ chat.txt）
        changed = True
        while changed and cand:
            changed = False
            for w in _STRIP_WORDS:
                if cand.startswith(w) and len(cand) > len(w):
                    cand = cand[len(w):].lstrip()
                    changed = True
                    break
        if cand:
            return cand
    return None


QUIT_WORDS = ("退出", "再见", "拜拜", "拜了", "结束会话", "不聊了", "关闭程序")
HELP_WORDS = ("帮助", "怎么用", "你会什么", "有什么功能", "能干什么", "命令列表")
DEMO_WORDS = ("演示", "体验", "示例", "试运行", "跑个例子", "看看效果")
DOCTOR_WORDS = ("自检", "检查环境", "环境检查", "体检", "诊断", "doctor")
PREDICT_WORDS = ("预测", "接下来会说", "下一句", "会怎么回", "怎么接话", "怎么回复")
REPORT_WORDS = ("报告", "导出", "出个文件", "生成文件", "html")
CALENDAR_WORDS = ("日历", "日程", "约会", "提醒事项")
GRAPH_WORDS = ("图谱", "实体", "知识图")
VERSION_WORDS = ("版本", "你是哪个版本", "几版")
ANALYZE_WORDS = ("分析", "看看聊天", "分析聊天", "帮我看看", "心理分析", "性格分析")


@dataclass
class Command:
    """解析后的语音指令。"""
    action: str                  # analyze/predict/demo/doctor/report/calendar/graph/version/help/quit/unknown
    file_path: str | None = None # analyze/predict 的目标文件
    raw: str = ""                # 归一化后的原始文本


def parse_command(text: str) -> Command:
    """把口语/文本输入解析为 Command（纯函数，可测试）。

    意图优先级：退出 > 帮助 > 演示 > 自检 > 预测 > 报告 > 日历 >
    图谱 > 版本 > 分析（含文件路径优先）> 未知。
    """
    raw = normalize_text(text)
    cmd = Command(action="unknown", raw=raw)
    if not raw:
        return cmd
    if any(w in raw for w in QUIT_WORDS):
        cmd.action = "quit"
        return cmd
    if any(w in raw for w in HELP_WORDS):
        cmd.action = "help"
        return cmd
    if any(w in raw for w in DEMO_WORDS):
        cmd.action = "demo"
        return cmd
    if any(w in raw for w in DOCTOR_WORDS):
        cmd.action = "doctor"
        return cmd
    # 文件路径优先于意图关键词判断（「分析 chat.txt」含"分析"也含路径）
    file_path = extract_file_path(text)
    if file_path and any(w in raw for w in ANALYZE_WORDS + PREDICT_WORDS + ("看",)):
        cmd.action = "predict" if any(w in raw for w in PREDICT_WORDS) else "analyze"
        cmd.file_path = file_path
        return cmd
    if any(w in raw for w in PREDICT_WORDS):
        cmd.action = "predict"
        return cmd
    if any(w in raw for w in REPORT_WORDS):
        cmd.action = "report"
        return cmd
    if any(w in raw for w in CALENDAR_WORDS):
        cmd.action = "calendar"
        return cmd
    if any(w in raw for w in GRAPH_WORDS):
        cmd.action = "graph"
        return cmd
    if any(w in raw for w in VERSION_WORDS):
        cmd.action = "version"
        return cmd
    if any(w in raw for w in ANALYZE_WORDS):
        cmd.action = "analyze"
        cmd.file_path = file_path  # 可能为 None（提示用户补充）
        return cmd
    return cmd


# ============================================================
# 2. 语音引擎（TTS / STT，分层降级）
# ============================================================


def _ps_escape(text: str) -> str:
    """转义 PowerShell 单引号字符串。"""
    return text.replace("`", "``").replace("'", "''")


def sapi_speak(text: str) -> None:
    """Windows SAPI 朗读（System.Speech，零依赖；非 Windows/失败抛异常）。"""
    if sys.platform != "win32":
        raise RuntimeError("SAPI 仅支持 Windows")
    script = (
        "Add-Type -AssemblyName System.Speech;"
        f"(New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{_ps_escape(text)}')"
    )
    subprocess.run([_PS_EXE, "-NoProfile", "-Command", script],
                   check=True, timeout=120, capture_output=True)


def sapi_listen(timeout: float = 8.0) -> str:
    """Windows SAPI 听写识别一次（返回识别文本，无结果返回空串）。"""
    if sys.platform != "win32":
        raise RuntimeError("SAPI 仅支持 Windows")
    script = (
        "Add-Type -AssemblyName System.Speech;"
        "$e = New-Object System.Speech.Recognition.SpeechRecognitionEngine;"
        "$e.SetInputToDefaultAudioDevice();"
        "$e.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar));"
        f"$r = $e.Recognize([TimeSpan]::FromSeconds({timeout}));"
        "if ($r) { $r.Text }"
    )
    proc = subprocess.run([_PS_EXE, "-NoProfile", "-Command", script],
                          capture_output=True, text=True, timeout=timeout + 30)
    return (proc.stdout or "").strip()


class Speaker:
    """TTS 扬声器：pyttsx3 → SAPI → 终端打印，逐级降级。

    engine: auto / pyttsx3 / sapi / off（config.json voice.tts 可配）。
    """

    def __init__(self, engine: str = "auto"):
        self.engine = engine
        self.last_used: str | None = None

    def _try_pyttsx3(self, text: str) -> bool:
        try:
            import pyttsx3  # noqa: PLC0415 可选依赖
            eng = pyttsx3.init()
            eng.say(text)
            eng.runAndWait()
            return True
        except Exception:
            return False

    def say(self, text: str) -> None:
        if not text:
            return
        print(f"\U0001F50A {text}")  # 终端始终可见（无音频环境也能用）
        if self.engine == "off":
            self.last_used = "off"
            return
        if self.engine in ("auto", "pyttsx3") and self._try_pyttsx3(text):
            self.last_used = "pyttsx3"
            return
        if self.engine in ("auto", "sapi"):
            try:
                sapi_speak(text)
                self.last_used = "sapi"
                return
            except Exception:
                pass
        self.last_used = "print"


class Listener:
    """STT 监听器：speech_recognition → SAPI → input() 文本，逐级降级。

    engine: auto / sr / sapi / text（config.json voice.stt 可配）。
    """

    def __init__(self, engine: str = "auto", stt_timeout: float = 8.0):
        self.engine = engine
        self.stt_timeout = stt_timeout
        self.last_used: str | None = None

    def _try_sr(self) -> str | None:
        try:
            import speech_recognition as sr  # noqa: PLC0415 可选依赖
            rec = sr.Recognizer()
            with sr.Microphone() as source:
                print("  （正在聆听…）")
                audio = rec.listen(source, timeout=self.stt_timeout)
            return rec.recognize(audio)
        except Exception:
            return None

    def listen(self, prompt: str = "请说指令（或输入文字）") -> str:
        if self.engine in ("auto", "sr"):
            got = self._try_sr()
            if got:
                self.last_used = "sr"
                return got
        if self.engine in ("auto", "sapi") and sys.platform == "win32":
            try:
                print("  （正在聆听…说「退出」结束）")
                got = sapi_listen(self.stt_timeout)
                if got:
                    self.last_used = "sapi"
                    return got
            except Exception:
                pass
        self.last_used = "text"
        try:
            return input(f"{prompt}> ").strip()
        except (EOFError, KeyboardInterrupt):
            return "退出"


# ============================================================
# 3. 动作执行器（意图 → 实际分析，返回口语化摘要）
# ============================================================

HELP_TEXT = (
    "我可以帮你：一说「分析加文件名」分析聊天记录；"
    "二说「预测」推演对方下一句；"
    "三说「演示」跑一遍内置示例；"
    "四说「自检」检查运行环境；"
    "五说「生成报告」导出网页报告；"
    "六说「日历」看提取的日程事件；"
    "七说「图谱」看本地图谱统计；"
    "说「退出」结束会话。"
)


class DefaultExecutor:
    """把语音意图接到 scripts/main.py 的真实流程。"""

    def __init__(self):
        import main as _main  # noqa: PLC0415  scripts/main.py
        self._main = _main

    # ---------- 意图：分析 ----------
    def analyze(self, file_path: str | None) -> str:
        if not file_path:
            return "请告诉我要分析的聊天记录文件名，例如「分析 chat.txt」。"
        path = Path(file_path)
        if not path.is_absolute():
            path = ROOT / path
        if not path.exists():
            return f"找不到文件：{file_path}。请确认路径后重试。"
        args = argparse.Namespace(paste=False, input=str(path), file=None,
                                  export=None, html=None)
        results = self._main.cmd_analyze_v2(args)
        if not results:
            return "分析失败了，可以换「演示」先看看内置示例。"
        return self._summarize_results(results)

    # ---------- 意图：预测 ----------
    def predict(self, file_path: str | None) -> str:
        if not file_path:
            return "预测需要先有聊天记录文件，例如「预测 chat.txt」，或先说「演示」。"
        path = Path(file_path)
        if not path.is_absolute():
            path = ROOT / path
        if not path.exists():
            return f"找不到文件：{file_path}。请确认路径后重试。"
        args = argparse.Namespace(paste=False, input=str(path), file=None, seed=0)
        self._main.cmd_predict_v2(args)
        return "预测已完成，详情在上面的输出里。"

    # ---------- 意图：演示 ----------
    def demo(self) -> str:
        out = self._main.cmd_demo(type("Args", (), {})())
        if out:
            return "演示完成，网页报告已生成，用浏览器打开即可查看。"
        return "演示运行失败，请运行「自检」查看环境问题。"

    # ---------- 意图：自检 ----------
    def doctor(self) -> str:
        problems = self._main.cmd_doctor(None)
        if not problems:
            return "环境自检全部通过，可以正常使用。"
        return f"自检发现 {problems} 个待处理项，修复建议已显示在上方。"

    # ---------- 意图：报告 ----------
    def report(self) -> str:
        args = argparse.Namespace(output=None)
        out = self._main.cmd_report_v2(args)
        if out:
            return f"网页报告已生成：{out}"
        return "还没有可生成报告的最近分析结果，先说「分析」或「演示」。"

    # ---------- 意图：日历 ----------
    def calendar(self) -> str:
        args = argparse.Namespace(list=True, upcoming=False, days=7,
                                  type=None, importance=None)
        self._main.cmd_calendar(args)
        return "日历事件已列在上方。"

    # ---------- 意图：图谱 ----------
    def graph(self) -> str:
        self._main.cmd_graph_stats(None)
        return "图谱统计已显示在上方。"

    # ---------- 意图：版本 ----------
    def version(self) -> str:
        from core.version import __version__  # noqa: PLC0415
        return f"微信聊天分析助手，当前版本 {__version__}。"

    # ---------- 摘要 ----------
    @staticmethod
    def _summarize_results(results: dict) -> str:
        """把 v2 分析结果浓缩为一段口语化摘要。"""
        parts = [f"分析完成，共运行 {len(results)} 个分析器。"]
        mbti = results.get("mbti")
        if mbti is not None and mbti.details.get("type"):
            parts.append(f"对方可能是 {mbti.details['type']} 型，"
                         f"置信度约 {mbti.confidence:.0f}%。")
        sent = results.get("sentiment")
        if sent is not None and "trend" in sent.details:
            trend_cn = {"up": "回暖", "down": "转冷", "stable": "平稳"}
            parts.append(f"情感趋势{trend_cn.get(sent.details['trend'], '平稳')}，"
                         f"正面占比 {sent.details.get('positive', 0):.0f}%。")
        rel = results.get("relationship")
        if rel is not None and "health_score" in rel.details:
            parts.append(f"关系健康度 {rel.details['health_score']:.0f} 分，"
                         f"等级：{rel.details.get('grade_label', '未知')}。")
            sugg = rel.details.get("suggestions") or []
            if sugg:
                parts.append(f"建议：{sugg[0]}")
        risk = results.get("risk")
        if risk is not None:
            risks = risk.details.get("risks") or {}
            if risks:
                parts.append(f"检出 {len(risks)} 项风险信号，请留意上方详情。")
            else:
                parts.append("未检测到明显风险。")
        return " ".join(parts)


# ============================================================
# 4. 会话循环
# ============================================================


class VoiceAssistant:
    """语音会话助手（纯逻辑分发，可注入测试）。"""

    def __init__(self, executor, speaker, listener, max_turns: int = 50):
        self.executor = executor
        self.speaker = speaker
        self.listener = listener
        self.max_turns = max_turns

    def handle_text(self, text: str) -> str | None:
        """处理一句输入，返回回复文本；返回 None 表示会话结束。"""
        cmd = parse_command(text)
        try:
            if cmd.action == "quit":
                return None
            if cmd.action == "help":
                return HELP_TEXT
            if cmd.action == "analyze":
                return self.executor.analyze(cmd.file_path)
            if cmd.action == "predict":
                return self.executor.predict(cmd.file_path)
            if cmd.action == "demo":
                return self.executor.demo()
            if cmd.action == "doctor":
                return self.executor.doctor()
            if cmd.action == "report":
                return self.executor.report()
            if cmd.action == "calendar":
                return self.executor.calendar()
            if cmd.action == "graph":
                return self.executor.graph()
            if cmd.action == "version":
                return self.executor.version()
        except Exception as e:  # noqa: BLE001 - 会话内异常不能中断交互
            return f"执行出错了：{e}。换个说法试试，或说「帮助」。"
        return "没听懂。说「帮助」看看我能做什么。"

    def run(self) -> None:
        self.speaker.say("微信聊天分析助手语音模式已启动，说「帮助」查看指令，说「退出」结束。")
        for _ in range(self.max_turns):
            text = self.listener.listen()
            reply = self.handle_text(text)
            if reply is None:
                self.speaker.say("好的，再见！")
                return
            self.speaker.say(reply)
        self.speaker.say("会话轮次达到上限，已自动结束。")


def _load_voice_config() -> dict:
    """读 config.json 的 voice 节（缺失时用默认值）。"""
    defaults = {"enabled": True, "tts": "auto", "stt": "auto", "stt_timeout": 8.0}
    try:
        import json  # noqa: PLC0415
        cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8")) or {}
        voice = cfg.get("voice") or {}
    except (OSError, ValueError):
        return defaults
    merged = dict(defaults)
    merged.update({k: v for k, v in voice.items() if k in defaults})
    return merged


def run_voice_session(executor=None, speaker=None, listener=None) -> int:
    """语音会话入口（main.py voice 子命令调用）。返回退出码。"""
    cfg = _load_voice_config()
    if not cfg.get("enabled", True):
        print("语音交互已在 config.json 中禁用（voice.enabled = false）。")
        return 1
    if executor is None:
        executor = DefaultExecutor()
    if speaker is None:
        speaker = Speaker(engine=cfg.get("tts", "auto"))
    if listener is None:
        listener = Listener(engine=cfg.get("stt", "auto"),
                            stt_timeout=float(cfg.get("stt_timeout", 8.0)))
    VoiceAssistant(executor, speaker, listener).run()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="微信聊天分析助手 - 语音交互（v2.9.0）")
    parser.add_argument("--tts", choices=["auto", "pyttsx3", "sapi", "off"],
                        help="覆盖 config.json 的 TTS 引擎")
    parser.add_argument("--stt", choices=["auto", "sr", "sapi", "text"],
                        help="覆盖 config.json 的 STT 引擎")
    args = parser.parse_args()
    cfg = _load_voice_config()
    speaker = Speaker(engine=args.tts or cfg.get("tts", "auto"))
    listener = Listener(engine=args.stt or cfg.get("stt", "auto"),
                        stt_timeout=float(cfg.get("stt_timeout", 8.0)))
    if not cfg.get("enabled", True):
        print("语音交互已在 config.json 中禁用（voice.enabled = false）。")
        return 1
    VoiceAssistant(DefaultExecutor(), speaker, listener).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
