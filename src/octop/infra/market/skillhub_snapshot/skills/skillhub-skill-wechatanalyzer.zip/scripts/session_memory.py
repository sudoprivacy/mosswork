#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
跨会话记忆 v5.0.0 (session_memory.py)

一次 analyze-v2 只看得到"这批消息"，但用户真正想知道的是"最近这半年我们
是不是越来越淡了"。这里把每次分析的关键指标存成快照，支持：

- save_snapshot()    追加一条快照（JSONL，按 config.session_memory.max_snapshots 截断）
- list_snapshots()   列出历史快照
- compare_sessions() 两条快照（默认"本次 vs 上一次"）的指标差值 + 中文解读

快照只存指标不存聊天原文：文件小、可分享，也不会把敏感内容二次落地。
存储位置走 core.data_paths（运行时数据目录），不在技能包里留文件。
"""
import json
import os
import sys
import time
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

if not __package__:  # python scripts/session_memory.py 直跑时补仓库根目录
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from core.version import __version__ as VERSION
except ImportError:  # pragma: no cover
    VERSION = "5.0.0"

SCHEMA_VERSION = 1

# 参与对比的指标：(快照字段名, 中文名, 越大越好)
# direction=False 表示"降了才是好事"（比如负面占比、隐私命中）
_TRACKED_METRICS: List[Tuple[str, str, Optional[bool]]] = [
    ("health_score", "关系健康度", True),
    ("balance", "互动平衡", True),
    ("responsiveness", "回应度", True),
    ("emotional_sync", "情感同步", True),
    ("engagement", "投入度", True),
    ("depth", "互动深度", True),
    ("positive", "正面情绪占比", True),
    ("negative", "负面情绪占比", False),
    ("cold_reply_ratio", "冷回复比例", False),
    ("risk_score", "风险分", False),
    ("privacy_hits", "隐私信息命中数", False),
    # 这三个只是"量"，多一条消息不代表关系变好，少几个人也不代表变坏。
    # 标 None → 趋势写成"上升/下降"，不进"改善/转弱"的结论里。
    ("total_messages", "消息总数", None),
    ("avg_length", "平均消息长度", None),
    ("member_count", "参与人数", None),
]

_LABELS = {name: (label, good_up) for name, label, good_up in _TRACKED_METRICS}


def _details(results: Dict[str, Any], name: str) -> Dict[str, Any]:
    entry = (results or {}).get(name) or {}
    if not isinstance(entry, dict):
        return {}
    details = entry.get("details") or {}
    return {} if "error" in details else details


def extract_metrics(results: Dict[str, Any],
                    meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """从分析结果里抽出可跨会话对比的扁平指标（缺项直接不写，比较时按缺失处理）。"""
    metrics: Dict[str, Any] = {}
    meta = meta or {}

    rel = _details(results, "relationship")
    if "health_score" in rel:
        metrics["health_score"] = round(float(rel["health_score"]), 1)
        metrics["grade_label"] = rel.get("grade_label", "")
        for key in ("balance", "responsiveness", "emotional_sync", "engagement", "depth"):
            value = (rel.get("dimensions") or {}).get(key)
            if value is not None:
                metrics[key] = round(float(value), 1)
        if rel.get("cold_reply_ratio") is not None:
            metrics["cold_reply_ratio"] = round(float(rel["cold_reply_ratio"]), 3)

    sent = _details(results, "sentiment")
    for key in ("positive", "negative", "neutral"):
        if key in sent:
            metrics[key] = round(float(sent[key]), 1)

    risk = _details(results, "risk")
    if "risk_score" in risk:
        metrics["risk_score"] = round(float(risk["risk_score"]), 1)
        metrics["risk_level"] = risk.get("overall_level", "low")

    priv = _details(results, "privacy")
    if priv:
        metrics["privacy_hits"] = int(priv.get("total_hits", 0) or 0)
        metrics["privacy_level"] = priv.get("level", "none")

    grp = _details(results, "group")
    if grp:
        metrics["member_count"] = int(grp.get("member_count", 0) or 0)
        metrics["dominance"] = round(float(grp.get("dominance", 0) or 0), 3)

    mbti = _details(results, "mbti")
    if mbti.get("type"):
        metrics["mbti_type"] = mbti["type"]

    pat = _details(results, "pattern")
    length = pat.get("message_length") or {}
    if isinstance(length, dict) and length.get("avg_self") is not None:
        metrics["avg_length"] = round(float(length["avg_self"]), 1)

    if meta.get("total_messages") is not None:
        metrics["total_messages"] = int(meta["total_messages"])
    return metrics


# ---------------------------------------------------------------------------
# 存储
# ---------------------------------------------------------------------------

def snapshot_file(config: Optional[Dict[str, Any]] = None) -> str:
    """快照文件路径：config 给绝对路径就用它，否则落运行时数据目录。"""
    from core.data_paths import resolve_data_dir
    cfg = (config or {}).get("session_memory", {})
    configured = cfg.get("file", "")
    if configured and os.path.isabs(configured):
        return configured
    if configured:
        return str(resolve_data_dir() / configured)
    return str(resolve_data_dir() / "sessions" / "analysis_snapshots.jsonl")


def _read_lines(path: str) -> List[Dict[str, Any]]:
    if not os.path.isfile(path):
        return []
    rows: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue  # 半行写入不该让整份历史读不出来
            if isinstance(row, dict) and row.get("id"):
                rows.append(row)
    return rows


def save_snapshot(results: Dict[str, Any],
                  meta: Optional[Dict[str, Any]] = None,
                  config: Optional[Dict[str, Any]] = None,
                  label: str = "",
                  chat_id: str = "") -> Dict[str, Any]:
    """追加一条快照并按 max_snapshots 截断，返回写入的快照。"""
    cfg = (config or {}).get("session_memory", {})
    if not cfg.get("enabled", True):
        raise RuntimeError("session_memory.enabled=false，未启用跨会话快照")

    path = snapshot_file(config)
    os.makedirs(os.path.dirname(path), exist_ok=True)

    snapshot = {
        "id": time.strftime("%Y%m%d%H%M%S") + "_" + uuid.uuid4().hex[:6],
        "saved_at": datetime.now().isoformat(timespec="seconds"),
        "version": VERSION,
        "label": label,
        "chat_id": chat_id,
        "schema": SCHEMA_VERSION,
        "meta": meta or {},
        "metrics": extract_metrics(results, meta),
    }

    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(snapshot, ensure_ascii=False) + "\n")

    limit = int(cfg.get("max_snapshots", 50) or 50)
    rows = _read_lines(path)
    if len(rows) > limit:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            for row in rows[-limit:]:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        os.replace(tmp, path)

    return snapshot


def list_snapshots(config: Optional[Dict[str, Any]] = None,
                   limit: int = 20) -> List[Dict[str, Any]]:
    """按时间正序返回快照（默认只给最近 limit 条）。"""
    rows = _read_lines(snapshot_file(config))
    return rows[-limit:] if limit > 0 else rows


def get_snapshot(snapshot_id: str,
                 config: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    for row in _read_lines(snapshot_file(config)):
        if row["id"] == snapshot_id:
            return row
    return None


# ---------------------------------------------------------------------------
# 对比
# ---------------------------------------------------------------------------

def _fmt(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.1f}" if abs(value) >= 0.1 or value == 0 else f"{value:.3f}"
    return str(value)


def compare_sessions(current: Optional[Dict[str, Any]] = None,
                     baseline: Optional[Dict[str, Any]] = None,
                     config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """对比两条快照；不传则用"最新一条"和"它前面那条"。

    Returns:
        {found, current_id, baseline_id, deltas:[{metric,label,before,after,delta,
         direction,significance}], notable:[中文短句], summary}
    """
    rows = _read_lines(snapshot_file(config))
    current = current or (rows[-1] if rows else None)
    baseline = baseline or (rows[-2] if len(rows) >= 2 else None)

    if not current:
        return {"found": False, "reason": "还没有任何快照，先跑一次 analyze-v2 并保存"}
    if not baseline:
        return {"found": False, "reason": "只有一条快照，至少需要两次分析才能对比",
                "current_id": current.get("id"),
                "current_saved_at": current.get("saved_at")}

    cur_m = current.get("metrics") or {}
    base_m = baseline.get("metrics") or {}

    deltas: List[Dict[str, Any]] = []
    for name, label, good_up in _TRACKED_METRICS:
        if name not in cur_m or name not in base_m:
            continue
        before, after = base_m[name], cur_m[name]
        try:
            delta = round(float(after) - float(before), 3)
        except (TypeError, ValueError):
            continue
        if delta == 0:
            continue
        pct = round(abs(delta) / abs(before) * 100, 1) if before else None
        evaluative = good_up is not None
        if evaluative:
            trend = "改善" if (delta > 0) == good_up else "转弱"
        else:
            trend = "上升" if delta > 0 else "下降"
        deltas.append({
            "metric": name, "label": label,
            "before": before, "after": after, "delta": delta,
            "direction": "up" if delta > 0 else "down",
            "trend": trend,
            "evaluative": evaluative,
            "change_pct": pct,
            # 1 分以内的波动不足以说明问题，标出来免得用户对着噪声做决定
            "significant": abs(delta) >= 1.0 or (pct is not None and pct >= 10),
        })

    notable = [f"{d['label']} {_fmt(d['before'])}→{_fmt(d['after'])}（{d['trend']}）"
               for d in deltas if d["significant"]]

    for name in ("mbti_type", "grade_label", "risk_level", "privacy_level"):
        if cur_m.get(name) and base_m.get(name) and cur_m[name] != base_m[name]:
            notable.append(f"{_LABELS.get(name, (name, True))[0]} "
                           f"{base_m[name]}→{cur_m[name]}")

    summary = _compare_summary(deltas, notable, current, baseline)
    return {
        "found": True,
        "current_id": current.get("id"),
        "baseline_id": baseline.get("id"),
        "current_saved_at": current.get("saved_at"),
        "baseline_saved_at": baseline.get("saved_at"),
        "gap_days": _gap_days(current, baseline),
        "deltas": deltas,
        "notable": notable,
        "summary": summary,
        "snapshot_count": len(rows),
    }


def _gap_days(current: Dict[str, Any], baseline: Dict[str, Any]) -> Optional[float]:
    try:
        a = datetime.fromisoformat(str(baseline.get("saved_at")))
        b = datetime.fromisoformat(str(current.get("saved_at")))
        return round((b - a).total_seconds() / 86400, 1)
    except (TypeError, ValueError):
        return None


def _compare_summary(deltas: List[Dict[str, Any]], notable: List[str],
                     current: Dict[str, Any], baseline: Dict[str, Any]) -> str:
    gap = _gap_days(current, baseline)
    prefix = f"与{int(gap)}天前那次分析相比，" if gap is not None and gap >= 1 else "与上一次分析相比，"
    if not deltas:
        return prefix + "两次分析没有可比指标（样本格式或分析器开关可能变了）。"
    improved = [d for d in deltas
                if d.get("evaluative", True) and d["trend"] == "改善" and d["significant"]]
    weaker = [d for d in deltas
              if d.get("evaluative", True) and d["trend"] == "转弱" and d["significant"]]
    moved = [d for d in deltas
             if not d.get("evaluative", True) and d["significant"]]
    moved_text = "、".join(f"{d['label']}{d['trend']}" for d in moved[:3])
    if not improved and not weaker:
        if moved:
            return prefix + f"质量类指标基本持平，只有{moved_text}。"
        return prefix + "各项指标基本持平，没有明显变化。"
    parts = []
    if improved:
        parts.append("改善的有 " + "、".join(d["label"] for d in improved[:3]))
    if weaker:
        parts.append("转弱的有 " + "、".join(d["label"] for d in weaker[:3]))
    if moved:
        parts.append(moved_text)
    return prefix + "；".join(parts) + "。"


# ---------------------------------------------------------------------------
# CLI 入口
# ---------------------------------------------------------------------------

def cmd_session(args, config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """`session` 子命令的实现（由 scripts/main.py 调用并传入已加载的 config）。"""
    from scripts.data_manager import DataManager

    config = config or {}
    dm = DataManager(config)
    action = getattr(args, "action", "list") or "list"

    if action == "save":
        latest = dm.get_latest_analysis()
        if not latest or "v2_results" not in latest:
            print("没有可保存的分析结果，请先运行 analyze-v2")
            return {"saved": False}
        snapshot = save_snapshot(latest["v2_results"],
                                 meta={"total_messages": (latest.get("meta") or {}).get(
                                     "total_messages")},
                                 config=config,
                                 label=getattr(args, "label", "") or "",
                                 chat_id=latest.get("chat_id") or "")
        print(f"已保存快照 {snapshot['id']}（{len(snapshot['metrics'])} 项指标）")
        return snapshot

    if action == "compare":
        target = getattr(args, "id", None)
        current = get_snapshot(target, config) if target else None
        if target and not current:
            print(f"未找到快照 {target}")
            return {"found": False}
        result = compare_sessions(current=current, config=config)
        if not result.get("found"):
            print("无法对比：" + result.get("reason", ""))
            return result
        print(f"快照对比：{result['baseline_saved_at']} → {result['current_saved_at']}"
              f"（间隔 {result['gap_days']} 天）")
        for d in result["deltas"]:
            flag = "*" if d["significant"] else " "
            print(f" {flag} {d['label']:<10} {_fmt(d['before']):>8} → {_fmt(d['after']):<8} "
                  f"{d['delta']:+.1f}  {d['trend']}")
        print("结论：" + result["summary"])
        return result

    rows = list_snapshots(config, limit=int(getattr(args, "limit", 20) or 20))
    if not rows:
        print("还没有快照。运行: python scripts/main.py session --save")
        return {"count": 0, "snapshots": []}
    print(f"共 {len(rows)} 条快照（最近 {len(rows)} 条）：")
    for row in rows:
        health = row.get("metrics", {}).get("health_score", "-")
        print(f"  {row['id']}  {row.get('saved_at', '')}  健康度 {health}"
              f"  {row.get('label', '')}")
    return {"count": len(rows), "snapshots": rows}


def self_check() -> Dict[str, Any]:
    """自检：临时目录里存两条快照再比一次，确认整条链是通的。"""
    import tempfile
    tmp = tempfile.mkdtemp(prefix="wa_session_check_")
    try:
        config = {"session_memory": {"file": os.path.join(tmp, "snapshots.jsonl")}}
        base = {"relationship": {"details": {"health_score": 60.0, "grade_label": "良好",
                                            "dimensions": {"balance": 50.0}}},
                "sentiment": {"details": {"positive": 40.0, "negative": 10.0}}}
        cur = {"relationship": {"details": {"health_score": 71.0, "grade_label": "良好",
                                           "dimensions": {"balance": 62.0}}},
               "sentiment": {"details": {"positive": 44.0, "negative": 8.0}}}
        save_snapshot(base, {"total_messages": 30}, config)
        save_snapshot(cur, {"total_messages": 52}, config)
        result = compare_sessions(config=config)
        return {
            "version": VERSION,
            "schema": SCHEMA_VERSION,
            "tracked_metrics": [n for n, _, _ in _TRACKED_METRICS],
            "snapshot_file": snapshot_file(config),
            "compare_found": bool(result.get("found")),
            "delta_count": len(result.get("deltas") or []),
            "summary": result.get("summary", ""),
        }
    finally:
        for name in os.listdir(tmp):
            os.remove(os.path.join(tmp, name))
        os.rmdir(tmp)


if __name__ == "__main__":
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))
