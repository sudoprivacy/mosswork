# 微信聊天分析助手 v6.0.0

**完全本地运行、模块化架构、隐私优先的分析工具**

分析话题地图、MBTI 人格、大五人格、情感趋势、关系健康度、群聊结构、隐私泄露、风险预警，生成可视化报告。
v6.0.0 新增**话题地图分析器**（TF-IDF 关键词 / 语义主题 / 我 vs 对方关注点 / 分段与话题切换 / 冷热变化，无 jieba 时用内置词表降级并明确标注），MCP 新增 `get_topic_analysis`（30 → 31 工具）；同时修复 MCP Server 在 mcp 2.x 下无法启动的兼容问题（自动适配 FastMCP / MCPServer），并让 JSON 超限输出不再产生半截字符串。
v5.0.0 是**正确性治本版**：修复了"从聊天窗口直接复制"的粘贴格式（行首时间戳曾被切成发送者，导致所有分析器认不出谁说的）、统一了 self/other 判定口径（v1 报告里"你的消息"恒为 0，AI 洞察提示词把"我"标成"对方"）、把 RAG 向量库/模型缓存/网页截图/报告目录从技能包内移到运行时数据目录；同时新增**本地隐私扫描**（10 类 PII + 银行卡 Luhn 校验）、**群聊多主体分析**、**跨会话快照趋势**与 **Markdown/CSV 导出**，MCP 工具 18 → 30；
v4.0.0 新增**桌面微信捕获**（剪贴板监控 + 微信窗口 UI Automation 读取）、**历史感知个性化预测**（从你的真实回复学 N-gram/风格/时段）与马尔可夫链、回复时间模式两大推演；
v3.0.0 新增 **AI 深度洞察**（5 类模板，DeepSeek/OpenAI 兼容/Ollama 自动适配）、**多源数据导入**（6 平台智能粘贴 + URL + JSONL）与 **MCP Server**；
v2.9.0 新增**关系健康度分析器**（平衡/回应/情感同步/投入/深度五维 + 冷回复惩罚）、**情感分析增强**（滚动趋势 + 情感转折点 + 己方情感占比）与**语音交互**（说一句话就能分析/预测/出报告，零依赖自动降级）；
v2.5.0 修复 5 个真实 bug（「非常」窗口误判否定 / RAG 角色过滤失效 / msg_type 丢失 / MBTI 显示崩溃 / 无发送者行 self-other 颠倒），接入全链路友好错误提示与 `predict-v2 --seed` 可复现预测；
v2.4.0 修复情感分析在 jieba 下的否定/程度识别 bug，补全 4 个模块测试；
v2.3.0 新增时间感知对话预测与回复时机提示；v2.2.0 新增推演与信息解读；v2.1.0 新增 demo、环境自检、离线 HTML 报告。

## 🆕 v6.0.0 话题地图 + MCP SDK 兼容

- **话题地图分析器**（第 12 个分析器，`analyzers/topic_analyzer.py`）
  - TF-IDF 关键词（词频 × 消息级 IDF，权重 0–100）+ 我/对方/群成员关注点拆分
  - 十个可重叠语义主题桶（工作/家庭/感情/健康/购物/美食/娱乐/学习/财务/出行），命中才输出
  - 按时间间隔（默认 4 小时）切会话段，段间 Jaccard < 0.3 记一次话题切换；前后半段标升温/降温词
  - 有 jieba 走真实词边界；没有 jieba 时按随包内置高频词表最长匹配，置信度扣分并明确提示漏词风险
- **MCP SDK 兼容** — 自动适配 mcp 1.x `FastMCP` 与 2.x `MCPServer`；`get_skill_status` 上报 `mcp_sdk_generation` / `mcp_sdk_label`
- **MCP 31 工具** — 新增 `get_topic_analysis`（12 分析 + 1 隐私 + 6 AI 洞察 + 3 预测画像 + 3 会话记忆 + 1 导出 + 1 导入 + 3 桌面捕获 + 1 系统）
- **输出正确性** — `_json()` 超限先退紧凑格式，仍超限返回合法错误信封，不再把 JSON 切一半

## 🆕 v5.0.0 隐私扫描 + 群聊分析 + 跨会话趋势 + 解析治本

- **隐私扫描器**（第 11 个分析器）— 纯本地正则，零联网
  - 10 类：密钥/口令、身份证号、银行卡号、长数字串、手机号、座机、邮箱、微信号、地址/定位、疑似真实姓名
  - 银行卡走 **Luhn 校验**（订单号不再误报）、命中区间按优先级互斥去重、`mask_privacy_text()` 一键脱敏
  - `privacy_scan.mask_before_llm`（默认开）在把内容发往大模型前先脱敏
- **群聊分析器** — 三人及以上才有意义，二人时会明确标注而不是硬凑指标
  - 成员发言占比/字数/均长 + 活跃度分层 + 主导度 + 点名关系网 + 双人互动平衡度
- **跨会话快照与趋势** — `session --list / --save / --compare`，`analyze-v2` 默认存快照
  - 显著性判定 `|Δ| ≥ 1.0` 或变化率 `≥ 10%`；JSONL 存储，损坏行读取时丢弃
- **多格式导出** — `--markdown`（贴飞书/Notion）、`--csv`（一行一个指标，`utf-8-sig` 给 Excel）、`--export`（全量 JSON）
- **解析与口径修复** — 见上一段的"正确性治本"，另新增 `core.message.is_self_sender()` 作为自我标识的唯一来源
- **MCP 30 工具** — 11 分析 + 6 AI 洞察 + 3 预测画像 + 3 会话记忆 + 1 隐私 + 1 导出 + 1 导入 + 3 桌面捕获 + 1 系统
- **CLI 15 子命令** — 新增 `capture`（捕获桌面微信并直接分析）与 `session`

## 🆕 v2.9.0 分析能力增强 + 语音交互

- 💗 **关系健康度分析器** — 互动平衡 / 回应速度 / 情感同步 / 投入度 / 互动深度五维加权 0-100，冷回复（对方长消息后回「嗯/哦」）额外扣分，输出 excellent/good/fair/warning 等级与中文改善建议（`config.json` 可关闭）
- 📈 **情感趋势深化** — 新增滚动情感平均序列（`rolling_trend`）、情感转折点检测（`turning_points`：变差/好转）、己方情感占比（`self_positive/self_negative`），终端报告展示转折点，全部向后兼容
- 🎤 **语音交互** — `python scripts/main.py voice` 进入会话：「分析 chat.txt / 预测一下 / 跑个演示 / 自检 / 生成报告 / 看日历 / 退出」；TTS 三级降级（pyttsx3 → Windows SAPI 零依赖 → 终端打印），无麦克风自动降级文本输入，分析结果口语化播报

## 🆕 v2.5.0 五大 bug 修复 + 友好错误 + 可复现预测

- 🐛 修复「非常开心」在长消息中「非」按错位索引误判否定（`sentiment_analyzer`）
- 🐛 修复 RAG `sender_filter="other"` 按原始昵称永远匹配不上 → 引入 `sender_role` 角色过滤 + 旧库自动降级
- 🐛 修复 `Message.from_dict` 只认 `message_type` 导致旧数据 image/voice/system 类型丢失
- 🐛 修复 MBTI 分析器失败时 `_display_v2_results` KeyError 中断报告展示
- 🐛 修复无发送者行 self/other 颠倒（注释与代码相反）+ 过滤纯时间戳行/分隔线
- 🛡 `friendly_errors.py` 接入 CLI 主入口：中文「原因+解决」提示，`--debug` 看完整堆栈
- 🎲 `predict-v2 --seed N` 可复现预测（MiroFish seeded 随机源，默认 seed=0 稳定）
- ⚡ 性能：`pseg.cut`→`jieba.cut`、情感词典首字索引、高频词 Counter 排序、二进制中文提取重写
- 🧪 测试 272 通过 / 0 失败 / 0 错误（修复 run_tests 漏跑顶层测试、缺依赖优雅跳过）

## 🆕 v2.4.0 情感分析与测试补全

- 修复「非常开心」被「非」字误判为否定、「我不开心」否定识别失效（jieba 装与不装结果一致）
- 修复立场识别「我反对」被判 neutral（正面词典单字「对」污染）
- 新增 `interpretation` / `data_manager` / `vector_store` / `rag_predictor` 共 75 个测试用例

## 🆕 v2.3.0 时间感知预测

- `core/timing.py`：统一计算消息紧急性、时间段、周末/工作日、连续对话节奏
- `predict-v2` 输出 `[回复时机]`：立即 / 尽快 / 今天内 / 隔太久先主动找回联系
- Rule 与 Ensemble 预测器都使用时间特征调整候选和置信度

---

## 🎉 v2.1.0 新特性

- 🧬 **补齐 `mirofish/` 本地图谱包** — 修复 `graph-stats` 崩溃（sqlite3 + jieba，零新依赖）
- 📄 **文件编码自动检测** — utf-8-sig / utf-8 / gb18030 自动识别，GBK 导出文件不再崩溃
- 📊 **大五人格校准** — 小样本不再轻易饱和 100%，各维度区分度更好
- 📈 **分析进度反馈** — `[i/6] xxx ... 完成 (0.12s)` 实时显示
- 💾 **结果导出** — `analyze-v2 --export result.json`
- 🌐 **单文件离线 HTML 报告** — `analyze-v2 --html report.html` / `report-v2`，零 CDN 零外部资源
- 🌟 **`demo` 一键体验** — 内置示例数据，30 秒跑完全流程
- 🧪 **`doctor` 环境自检** — 依赖/config/目录/编码逐项检查 + 修复建议
- 🧭 **交互式向导** — 无参数启动直接进入粘贴分析（`-h` 不变）
- 📝 **一句话总结** — 终端报告末尾自动生成中文摘要
- 🧠 **MBTI 稳定性提示** — 稳定性低时明确提示"结果仅供参考"
- 🔮 **predict-v2 备选去重** — 按规范化文本合并重复模板

### v2.0.0 基础特性

- 🧠 **jieba 精准分词** — 替代简陋的正则分词
- 💬 **否定识别** — 修复"我不开心"被误判的 bug
- 🎭 **反讽检测** — 识别"虽然...但是..."等句式
- 📊 **新 MBTI 置信度算法** — 维度差距 + 样本量综合评估
- 📚 **本地 RAG 引擎** — sentence-transformers + ChromaDB
- 🐟 **MiroFish 多智能体** — 8 Agent × N 轮模拟 + 投票博弈
- 🔮 **三层集成预测** — Rule + RAG + MiroFish 加权融合
- 🏗️ **模块化架构** — `core/` / `analyzers/` / `predictors/` / `rag/` / `mirofish/`
- 🔒 **隐私优先** — 100% 本地处理，零数据外传
- ♻️ **完全向后兼容 v1.2.0** — 所有旧命令保留

---

## 30秒快速上手

**第一步：安装核心依赖**
```bash
pip install -r requirements.txt
```

**第二步：一键体验（推荐新用户）**
```bash
python scripts/main.py demo      # 分析内置示例 + 生成 HTML 报告
python scripts/main.py doctor    # 环境自检
python scripts/main.py voice     # v2.9 语音交互（说/打字均可，无麦克风自动降级文本输入）
```

**第三步：分析自己的聊天记录**
```bash
python scripts/main.py                              # 交互式向导
python scripts/main.py analyze-v2 --input 聊天记录.txt --html report.html
```

**完成！** 终端报告 + 离线 HTML 报告（浏览器直接打开）。

---

## 命令对照

| 功能 | 推荐命令 | v1.2.0 兼容 |
|------|-------------|-------------|
| **一键体验** | `demo` | (无) |
| **环境自检** | `doctor` | (无) |
| **分析** | `analyze-v2 --paste` | `analyze --paste` |
| **指定输入格式** | `analyze-v2 --input 记录.txt --platform wechat` | (无) |
| **导出 JSON** | `analyze-v2 --export result.json` | (无) |
| **Markdown 报告** | `analyze-v2 --markdown r.md` | (无) |
| **CSV 指标表** | `analyze-v2 --csv r.csv` / `report-v2 --format csv` | (无) |
| **HTML 报告** | `analyze-v2 --html r.html` / `report-v2` | `report --report-type html` |
| **隐私扫描** | `analyze-v2 --paste`（自动含隐私章节）/ MCP `scan_privacy` | (无) |
| **群聊分析** | `analyze-v2 --paste`（≥3 人自动启用） | (无) |
| **跨会话趋势** | `session --list` / `session --compare` | (无) |
| **桌面捕获** | `capture` / `capture --source clipboard --seconds 30` | (无) |
| **AI 洞察** | `analyze-v2 --paste --ai`（需 API Key） | (无) |
| **预测** | `predict-v2 --paste` | (无) |
| **图谱统计** | `graph-stats` | (无) |
| **语音交互** | `voice` | (无) |
| **Web** | (v1.2.0 命令) | `serve --port 5000` |
| **定时任务** | (v1.2.0 命令) | `schedule --list` |
| **日历** | (v1.2.0 命令) | `calendar --list` |

> v1.2.0 的所有命令在当前版本保留并继续工作。

---

## 功能一览

### 分析能力

- **MBTI 推断** — 从聊天风格推断对方 MBTI 16 型人格
  - v2.0.0: 维度差距 + 样本量综合置信度，输出稳定性评分
- **大五人格** — 开放性 / 尽责性 / 外向性 / 宜人性 / 神经质
  - v2.0.0: 归一化 + 雷达图数据 + 补全 neuroticism low 词
- **情感分析** — 追踪情感变化趋势，正面/负面比例
  - v2.0.0: jieba 分词 + 否定识别 + 程度副词 + 反讽检测 + HowNet 词典 + Emoji 映射
- **风险感知** — 标记值得关注的对话模式
  - v2.0.0: 反讽识别 + 否定排除 + 时序突发 + 三级风险
- **关系健康度** — 互动平衡 / 回应度 / 情感同步 / 投入度 / 互动深度五维 + 冷回复惩罚
- **隐私扫描**（v5.0.0）— 10 类个人信息识别 + 银行卡 Luhn 校验 + 一键脱敏 + 送模型前自动遮蔽
- **群聊分析**（v5.0.0）— 成员占比与活跃分层 + 主导度 + 点名关系网 + 双人互动平衡
- **话题地图**（v6.0.0）— TF-IDF 关键词 + 语义主题 + 说话人关注点 + 分段与话题切换 + 冷热变化
- **场景分类** — 恋爱 / 工作 / 社交 / 重要事项
- **对话模式** — 回复速度、主动率、问号/感叹号比例
  - v2.0.0: 修复 v1.2.0 的 reply_speed 丢失 bug
- **推演 + 解读** — 7 大推演（趋势/行为/情感轨迹/风险演化/走向/马尔可夫链/回复时间模式）+ 4 大解读（意图/实体/话题/立场）

### 预测能力

- **Rule 预测** — 16 MBTI × 5 模板 + 场景 + 关键词触发 + 意图链追踪
- **RAG 预测** — 检索 top-K 相似历史对话作为 few-shot
- **MiroFish 预测** — 8 Agent × N 轮模拟 + 多轮辩论 + 加权投票
- **HistoryAware**（v4.0.0）— 从你真实回复中学 N-gram 短语、上下文-回复对、风格、情感映射、时段映射
- **Ensemble** — 四层动态置信度权重融合 + 多样性保障

### 记忆与导出

- **跨会话快照**（v5.0.0）— 保存/列表/对比，显著变化判定，落在运行时数据目录
- **个性化画像**（v5.0.0 接线）— 可持久化、可导出导入、可增量再训练
- v2.1.0：单文件离线 HTML 报告（`analyze-v2 --html` / `report-v2`），内联 SVG 图表，零外部资源
- v5.0.0：Markdown 与 CSV 指标表；HTML / Word (.docx) / PPTX（v1.2.0 保留）

---

## 完整使用指南

### 方式一：交互式向导 / demo（v2.1.0 推荐）

```bash
python scripts/main.py            # 无参数进入向导：粘贴 → 分析 → 可选 HTML 报告
python scripts/main.py demo       # 一键体验内置示例
```

### 方式二：v2 粘贴/文件分析

```bash
python scripts/main.py analyze-v2 --paste
python scripts/main.py analyze-v2 --input 聊天记录.txt    # 自动识别 utf-8/GBK
python scripts/main.py analyze-v2 --input 聊天记录.txt --export result.json --html report.html
```

### 方式三：v2 三层预测

```bash
python scripts/main.py predict-v2 --input 聊天记录.txt
```

输出示例：
```
[最佳预测] 置信度 78.5%
  策略: rule,mirofish
  内容: 「我先确认一下情况」

[备选预测]
  1. [65%] (rag) 「好的，我跟进一下」
  2. [62%] (mirofish) 「收到，我处理一下」
```

### 方式四：v1.2.0 文件导入（保留）

```bash
python scripts/main.py analyze --file 聊天记录.txt
```

支持格式：`.txt` `.json` `.docx` `.pdf` `.jpg` `.mp3`

### 方式五：v1.2.0 Web 服务

```bash
python scripts/main.py serve
# 浏览器打开 http://localhost:5000
```

### 方式六：生成报告

```bash
# v2.1.0：单文件离线 HTML（推荐）
python scripts/main.py analyze-v2 --input 聊天记录.txt --html report.html
python scripts/main.py report-v2                       # 用最近一次 v2 结果生成

# v1.2.0：多格式报告（保留）
python scripts/main.py report --report-type html    # HTML 报告
python scripts/main.py report --report-type word    # Word 报告
python scripts/main.py report --report-type pptx    # PPTX 报告
python scripts/main.py report --report-type all     # 全部格式
```

---

## v2 分析结果示例

### 终端输出

```
  [1/6] mbti ... 完成 (0.01s) ✅
  [2/6] bigfive ... 完成 (0.00s) ✅
  [3/6] sentiment ... 完成 (0.02s) ✅
  [4/6] risk ... 完成 (0.00s) ✅
  [5/6] scenario ... 完成 (0.00s) ✅
  [6/6] pattern ... 完成 (0.00s) ✅

============================================================
   微信聊天分析报告 v2.1.0
============================================================

🧠 [MBTI] ENFP - 竞选者
  置信度: 78.5%
  特征: 外向 | 直觉 | 情感 | 感知
  稳定性: 82%

🔬 [大五] OCEAN 人格分析
  开放性: [#######...] 68%
  尽责性: [#####.....] 52%
  外向性: [#######...] 71%
  宜人性: [#######...] 73%
  神经质: [####......] 42%

💬 [情感] 趋势: [上升]
  正面: 65.5% / 负面: 22.3% / 中性: 12.2%
  [v2.0.0] 检测到 3 条反讽
  正面词: 开心, 喜欢, 期待, 不错, 哈哈
  负面词: 担心, 紧张, 压力

⚠️ [风险]
  [MEDIUM] pig_butcher
    对方可能正在实施诈骗
    命中 2 次: 投资, 充值
    [建议]: 听起来不错，但我得先研究研究

🎯 [场景] 主场景: [工作]
    work: 18
    important: 12
    social: 5

📊 [模式] 对话模式分析
  主动发起: 我 35% / TA 65%
  平均回复: 245 秒
  快速回复 (<1分钟): 23
  慢速回复 (>1小时): 5
  聊天跨度: 15 天

============================================================
```

---

## 目录结构

```
wechat-analyzer/
├── core/                       # 核心抽象层
│   ├── message.py              # 统一 Message 模型 + is_self_sender()（v5 自我标识唯一口径）
│   ├── result.py               # 统一 Result 模型
│   ├── analyzer_base.py        # 分析器基类 + AnalyzerRegistry（run_all 支持进度回调）
│   ├── predictor_base.py       # 预测器基类
│   ├── data_paths.py           # resolve_data_dir()：运行产物的唯一落点
│   ├── timing.py               # 时间感知（回复时机/节奏）
│   ├── version.py              # 版本号单一来源
│   └── utils.py                # 分词/停用词/logger/编码自动检测
│
├── analyzers/                  # 12 个分析器
│   ├── mbti_analyzer.py / bigfive_analyzer.py
│   ├── sentiment_analyzer.py   # 否定识别 + 反讽 + 滚动趋势 + 转折点
│   ├── risk_analyzer.py / scenario_analyzer.py / pattern_analyzer.py
│   ├── inference_analyzer.py   # 7 大推演（含马尔可夫链、回复时间模式）
│   ├── interpretation_analyzer.py  # 4 大解读（意图/实体/话题/立场）
│   ├── relationship_analyzer.py    # 关系健康度五维
│   ├── group_analyzer.py       # v5.0.0 群聊多主体
│   ├── privacy_scanner.py      # v5.0.0 本地隐私泄露扫描（10 类 + Luhn）
│   ├── topic_analyzer.py       # v6.0.0 话题地图（关键词/主题/说话人/切换）
│   ├── ai_insight_engine.py    # v3.0.0 LLM 洞察（5 类模板 + 脱敏 + 缓存）
│   ├── lexicon_topic_fallback.txt  # v6.0.0 无 jieba 时的话题词表
│   └── lexicon_*.txt           # HowNet/否定/程度/Emoji/jieba 词典（平铺，带 lexicon_ 前缀）
│
├── predictors/                 # 4 个预测器 + Ensemble
│   ├── rule_predictor.py / rag_predictor.py / mirofish_predictor.py
│   ├── history_aware_predictor.py  # v4.0.0 从你的真实回复学 N-gram/风格/时段
│   └── ensemble.py             # 四层动态置信度融合
│
├── rag/                        # embedder.py / vector_store.py / retriever.py
│                               #   v5.0.0：缓存与向量库一律落在包外运行时目录
├── mirofish/                   # 本地图谱包（core_zep_local.py：sqlite3 + jieba）
│
├── scripts/                    # CLI 与各功能模块（51 个 .py）
│   ├── main.py                 # CLI 入口（15 个子命令）
│   ├── report_exporters.py     # v5.0.0 Markdown / CSV / 元数据单一口径
│   ├── session_memory.py       # v5.0.0 跨会话快照与趋势对比
│   ├── clipboard_monitor.py / wechat_window_reader.py    # v4.0.0 桌面捕获（Windows）
│   ├── data_source_importer.py # v3.0.0 多源导入（6 平台智能粘贴 / URL / JSONL）
│   ├── v2_report_generator.py  # 单文件离线 HTML
│   ├── data_manager.py         # v5.0.0 修复行首时间戳解析
│   ├── text_analyzer.py / llm_analyzer.py    # v1 通道（v5.0.0 修 self/other 口径）
│   ├── conversation_predictor.py / report_generator.py / file_importer.py
│   ├── calendar_manager.py / scheduler.py / web_server.py / voice_interface.py
│   ├── main_setup.py           # 一键配置向导
│   ├── mirofish_config.py / mirofish_services_*.py / mirofish_utils_*.py
│   │                           # ⚠️ 遗留死代码：见 RUNBOOK「已知问题」
│   └── （`doctor` 自检不是单独文件，由 main.py::cmd_doctor 实现）
│
├── templates/                  # Web 模板
├── references/                 # 方法与词表参考
├── tests/                      # 44 个测试文件（含 fixtures_*.txt 示例数据）
├── mcp_server.py               # MCP Server（31 工具，stdio；兼容 mcp 1.x/2.x）
├── config.json / SKILL.md / README.md / RUNBOOK.md / FAQ.md / CHANGELOG.md
├── requirements.txt / requirements-rag.txt / requirements-web.txt
├── clean.py                    # 上传前清理与残留检查
└── package.py                  # 打包
```

> **没有 `data/` 目录是设计**：所有运行产物（数据库、向量库、模型缓存、报告、截图、快照、画像）
> 落在 `resolve_data_dir()`（默认系统临时目录下的 `wechat-analyzer/`，可用
> `WECHAT_ANALYZER_DATA_DIR` 覆盖）。配置里给的**相对路径不会被拼回技能包内**，只认绝对路径。

---

## 使用限制

使用前请了解以下限制：

- **单次分析建议不超过 500 条消息。** 超出后分析耗时较长。
- **分析结果仅供参考。** 人格推断基于关键词匹配，不是专业心理评估。
- **RAG 首次运行需联网。** 下载 embedding 模型约 50-100MB（1-2 分钟），之后完全离线。
- **RAG 依赖未安装时自动降级。** 预测自动回退到 Rule 层，不影响其他功能。
- **v1.2.0 命令继续可用。** 行为与 v1.2.0 一致，不影响现有用户。

---

## 如何导出微信聊天记录

### 方法一：直接复制文字（最快）

1. 打开电脑端微信，进入聊天对话框
2. 鼠标选中聊天内容（可多选）
3. 按 `Ctrl + C` 复制
4. 在工具中粘贴即可

### 方法二：从微信导出文件

1. 打开电脑端微信聊天窗口
2. 点击右上角 `...` 或 `···` 按钮
3. 选择 `聊天记录` → `聊天文件`
4. 点击 `导出聊天记录`
5. 选择格式 `txt`，保存到本地
6. 使用 `python scripts/main.py analyze-v2 --input 文件路径.txt`

---

## LLM API 配置（可选，v2.0.0 默认禁用）

v2.0.0 默认禁用云端 LLM，**所有分析本地完成**。如需启用 LLM 增强：

```bash
# 1. 复制环境变量模板
cp .env.example .env

# 2. 编辑 .env 填入 API Key
# LLM_API_KEY=sk-...
# LLM_BASE_URL=https://api.deepseek.com
# LLM_MODEL=deepseek-chat

# 3. 修改 config.json
# "llm": { "enabled": true, ... }
```

> v2.0.0 推荐使用本地 RAG 引擎替代云端 LLM（隐私更好、效果更准）。

---

## 数据隐私说明

- **默认零外传**：所有分析在本机跑，不向任何云端服务器发送数据，无需注册账号
- **运行数据不在技能包内**：SQLite 数据库、ChromaDB 向量库、embedding 缓存、MiroFish 图谱、
  HTML/CSV/Markdown 报告、跨会话快照、个性化画像统一落在 `core.data_paths.resolve_data_dir()`
  （默认系统临时目录下的 `wechat-analyzer/`，`WECHAT_ANALYZER_DATA_DIR` 可改）；
  配置里的**相对路径会被归一**，不会被拼回技能包
- **快照只存指标数值**：关系健康度、情感分布、风险分、隐私命中数、群聊人数与主导度等标量，
  **不落聊天正文，也不落参与人昵称**
- **发往 LLM 前先脱敏**（v5.0.0）：`privacy_scan.mask_before_llm` 默认开，替换手机号/身份证/银行卡/邮箱；
  脱敏流程本身出错时发送占位文本而非原文；正文超 4000 字符自动截断
- **LLM 完全可选**（默认关闭）；**MiroFish 默认关闭**；RAG 可 `rag.enabled=false` 关掉
- **本地隐私扫描器**（v5.0.0）：10 类个人信息识别 + 银行卡 Luhn 校验 + 一键脱敏，纯正则、不联网
- 无遥测、无统计、无后台网络请求（唯一例外：RAG 首次下载 embedding 模型）

---

## 常见问题

**Q: v1.2.0 的命令还能用吗？**
A: 完全兼容，所有旧命令保留并继续工作。

**Q: v2.0.0 和 v1.2.0 分析结果不一致？**
A: 正常。v2.0.0 引入 jieba、否定识别等，分析更准确。

**Q: 首次运行很慢？**
A: RAG 首次需下载 embedding 模型（50-100MB），之后秒开。

**Q: 不想用 RAG？**
A: `config.json` 中设 `"rag.enabled": false`。

**Q: 不想用云端 LLM？**
A: v2.0.0 默认禁用。完全不需要 `.env` 文件。

**Q: MiroFish 怎么启用？**
A: `config.json` 中设 `"mirofish.enabled": true`，然后运行 `predict-v2`。

**Q: 如何回滚到 v1.2.0？**
A: v1 的命令与模块仍在（`analyze` / `report` / `serve` / `text_analyzer.py`），
按 v1 命令跑即可；历史快照不随包分发，需要更早的版本请从版本库取。

**Q: Web 仪表盘呢？**
A: `python scripts/main.py serve --port 5000` 起 v1.2.0 的 Flask 界面，功能少于 CLI，
不在当前版本的主路径上。

**Q: 群聊怎么分析？**
A: 导出群聊记录时选"全部消息"，导入后 `group` 分析器在发送者 ≥ 3 时自动启用，
输出成员占比/活跃分层/主导度/点名关系网/双人互动平衡。

**Q: 粘贴进去分析器一个都不跑 / 发送者全是 unknown？**
A: v5.0.0 修好了微信窗口复制格式（行首时间戳）的解析。若仍识别不准，
用 `--platform wechat` 手工指定输入格式，`doctor` 可自检环境。

**Q: 想知道记录里暴露了哪些个人信息？**
A: `analyze-v2` 会自动带「🔒 隐私泄露扫描」章节；单独调用走 MCP 的 `scan_privacy`。
注意它是正则识别，不保证查全。

**Q: 想看两次分析之间的变化？**
A: `python scripts/main.py session --list` / `--compare`，详见 [RUNBOOK.md](RUNBOOK.md)。

**Q: 首次安装依赖太多？**
A: 运行 `python scripts/main_setup.py` 自动完成。

---

## 依赖安装

### 核心（必须）

```bash
pip install -r requirements.txt
```

### RAG 引擎（v2.0.0 推荐）

```bash
pip install -r requirements-rag.txt
```

### 可选增强

```bash
pip install openai-whisper   # 语音转文字
pip install easyocr          # 图片 OCR
```

### Web 仪表盘（v2.1.0 路线图）

```bash
pip install -r requirements-web.txt
cd web/frontend && npm install
```

---

## 版本路线图

已发布：

- ✅ **v1.2.0** — 基础 MBTI/大五/情感/风险分析，LLM 增强（云端）
- ✅ **v2.0.0** — 模块化架构、jieba 分词、本地 RAG、多智能体 MiroFish、隐私优先
- ✅ **v2.1.0 – v2.9.0** — demo/doctor/单文件 HTML 报告、推演与解读、时间感知预测、
  关系健康度五维、语音交互、零警告加固
- ✅ **v3.0.0** — AI 深度洞察（5 类模板真实接通）、多源数据导入、MCP Server 15 工具
- ✅ **v4.0.0** — 桌面微信捕获、历史感知个性化预测、四层融合动态权重、马尔可夫链与回复时间模式
- ✅ **v5.0.0** — 隐私扫描 + 群聊多主体 + 跨会话趋势 + 多格式导出；粘贴解析与 self/other 口径治本；
  运行产物移出技能包；MCP 30 工具 / CLI 15 子命令
- ✅ **v6.0.0** — 话题地图（关键词/语义主题/说话人关注点/分段切换/冷热变化）；
  MCP 新增 `get_topic_analysis`（31 工具）；兼容 mcp 1.x/2.x；JSON 超限不再产生半截输出

候选（未排期，勿当作承诺）：

- ⏳ 微信本地 DB 解密导入（合规与密钥管理未定，风险高于收益）
- ⏳ OCR / ASR 截图与语音消息识别
- ⏳ Web 仪表盘升级（现为 v1.2.0 的 Flask 版）
- ⏳ 清理 `scripts/mirofish_services_*` 死代码（需要 `python-dotenv` + 补 `Config`）

---

版本: v6.0.0
