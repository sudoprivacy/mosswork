# 🚀 RUNBOOK — 微信聊天分析助手 v6.0.0 速查手册

> **一页纸看懂所有用法。** 想用 30 秒上手 → 直接看 [§1 一句话用](#1-一句话用)；想用全部功能 → 看 [§2 完整命令速查](#2-完整命令速查)。

---

## ⚠️ 重要声明（先看这里）

**本工具的分析结果仅供参考，不是专业评估！**

- MBTI / 大五人格推断基于关键词和规则匹配
- **不能用于专业心理评估 / 职业决策 / 感情决策**
- 情感分析 / 风险检测可能误报；**隐私扫描是正则识别，只覆盖格式明确的个人信息，不保证查全**
- 全程在本机计算，**不外传**；运行数据（快照、画像、报告、数据库）落在本机运行时目录，
  默认是系统临时目录，可用 `WECHAT_ANALYZER_DATA_DIR` 改位置。报告文件保密责任在你。

详见 [SKILL.md §3 使用须知](SKILL.md) + [FAQ.md §Q13 MBTI 准吗？](FAQ.md)。

---

## 🆕 v6.0.0 新功能一览

✅ **不用记命令**，直接对加载了本 Skill 的 AI 助手说这些中文：

| 想做的事情 | 这么说就行 |
|---|---|
| **想知道这段聊天反复在聊什么、谁更爱聊什么** | "话题地图" / "聊天高频词" / "谁更爱聊什么" |
| 想知道这段对话接下来会怎么走 | "推演对话走向" / "分析我们关系" |
| 想知道他到底什么意思 | "他是什么意思" / "解读聊天内容" |
| 想看消息里有哪些关键信息 | "提取聊天意图" / "提取关键信息" |
| 想看有没有问题风险 | "这段对话有什么问题" / "看看我们聊了什么" |
| **想知道记录里暴露了哪些个人信息** | "聊天记录有没有暴露隐私" / "帮我脱敏" |
| **想看群里谁主导、谁跟谁说话** | "群聊分析" / "群里谁话最多" |
| **想对比这次和上次有什么变化** | "对比上次分析" / "聊天趋势" |
| **想要一份能贴进飞书/Excel 的结果** | "导出Markdown" / "导出聊天记录表格" |
| **不想复制粘贴，直接从微信读** | "捕获微信消息" / "读取微信窗口" |

> **零基础也可以玩** —— 启动后会进入交互式向导，跟着提示一步步走即可。

---

## 🤔 高级功能是什么？看完这页就懂

> 很多用户被"RAG / MiroFish / jieba"这些术语劝退。**这不是技术黑话**，看完下面类比就懂：

| 术语 | 通俗类比 | 不装会怎样 |
|------|---------|----------|
| **jieba** | 中文分词器。把"我今天很开心"切成"我/今天/很/开心" | 也能用，但分析准确率下降 20-30% |
| **RAG** | AI 记忆库。基于历史 1000 条对话预测下一条 | 只用模板预测，不如 RAG 个性化 |
| **MiroFish** | 8 个虚拟人陪你聊天 | 不用，但装了能模拟多种可能 |
| **本地图谱** | 替代云端数据存储的本地数据库 | 默认就是本地，无需关心 |

**结论**：核心 MBTI/情感/风险分析不需要装任何高级功能，**开箱即用**。

详细对比见 [FAQ.md §Q22-Q25](FAQ.md) 或 [references/INDEX.md](references/INDEX.md)。

---

## 1. 一句话用

### 🎯 三种最快路径（任选一个）

```bash
# 路径 A：30 秒体验（推荐第一次用）
python scripts/main.py demo
# 自动分析内置示例 + 生成 HTML 报告，直接打开就能看

# 路径 B：交互式向导（最简单）
python scripts/main.py
# 无参数启动，跟着提示粘贴聊天记录即可

# 路径 C：完整分析报告（最专业）
python scripts/main.py analyze-v2 --paste --html report.html
# 粘贴聊天 → 自动分析全部维度 → 输出可离线的 HTML 报告
```

**第二步：打开报告**
```bash
# Windows
start report.html
# Mac
open report.html
```

---

## 2. 完整命令速查

### 📊 分析类（6 种）

```bash
# 完整分析：隐私扫描 + 群聊 + 推演 + 解读 + 所有维度
python scripts/main.py analyze-v2 --paste

# 从文件分析（自动识别 utf-8/GBK/UTF-8-sig）
python scripts/main.py analyze-v2 --input 聊天记录.txt

# 自动识别粘贴格式不准时，手工指定（wechat/qq/imessage/csv/json/jsonl…）
python scripts/main.py analyze-v2 --input 聊天记录.txt --platform wechat

# 导出 JSON 结果
python scripts/main.py analyze-v2 --input 聊天.txt --export result.json

# 生成单文件 HTML 报告（离线可开）
python scripts/main.py analyze-v2 --input 聊天.txt --html 我的报告.html

# Markdown / CSV（v5.0.0）：贴飞书 Notion / 丢进 Excel 透视
python scripts/main.py analyze-v2 --paste --markdown 报告.md
python scripts/main.py analyze-v2 --paste --csv 指标.csv

# 只重出报告（基于上次 analyze-v2 结果）
python scripts/main.py report-v2 --format markdown
```

### 🗺 话题地图（v6.0.0）

```bash
# analyze-v2 会自动输出「🗺️ 话题」一段：高频词 / 主题占比 / 我 vs 对方关注点 / 冷热 / 切换
python scripts/main.py analyze-v2 --input 聊天.txt

# MCP 单独调用：get_topic_analysis（参数 chat_text）
# 没装 jieba 时会按内置词表降级，结果里会明确标注并扣置信度
```

### 🔒 隐私与群聊（v5.0.0）

```bash
# 隐私扫描已随 analyze-v2 自动执行，报告里看「🔒 隐私泄露扫描」一段
# 只想单独扫一遍（MCP）：scan_privacy
# 群聊：≥3 个发送者时 group 分析器自动启用，看「👥 群聊结构」
python scripts/main.py analyze-v2 --input 群聊记录.txt
```

### 📈 跨会话趋势（v5.0.0）

```bash
python scripts/main.py session --list                 # 历史快照（默认 20 条）
python scripts/main.py session --save --label 冷战期   # 把最近一次分析存成快照
python scripts/main.py session --compare               # 与上一次比
python scripts/main.py session --compare --id 20261015_1432   # 与指定快照比
```

### 🖥 桌面捕获（Windows）

```bash
python scripts/main.py capture                                  # 读微信窗口，直接分析
python scripts/main.py capture --source clipboard --seconds 30   # 监听剪贴板 30 秒
```

### 🔮 推演类（v2.2.0 新增）

```bash
# 推演包含在 analyze-v2 的输出里，无需单独调用
# 查看报告里「🔮 推演能力」一段即可
```

### 📋 解读类（v2.2.0 新增）

```bash
# 解读同样已包含在 analyze-v2 输出
# 查看报告里「📋 信息解读」一段即可
```

### 🛠 工具类（5 种）

```bash
# 环境自检（出问题时先跑这个）
python scripts/main.py doctor

# 用最近结果生成报告
python scripts/main.py report-v2 --output my.html

# 看图谱统计（多智能体相关）
python scripts/main.py graph-stats

# 查看版本
python scripts/main.py version

# 帮助
python scripts/main.py --help
```

---

## 3. 直接调用 Python 模块

如果你想在 Jupyter / 自己的代码里调用：

```python
import sys
sys.path.insert(0, ".")  # 当前目录

from analyzers import create_default_registry
from core.message import Message
from datetime import datetime, timedelta

# 1. 创建分析器注册中心（含 12 个分析器）
registry = create_default_registry()
print(registry.list())
# ['mbti', 'bigfive', 'sentiment', 'risk', 'scenario', 'pattern', 'inference',
#  'interpretation', 'relationship', 'group', 'privacy', 'topic']

# 2. 构造消息
now = datetime.now()
messages = [
    Message(sender="other", content="你好", timestamp=now - timedelta(days=1)),
    Message(sender="self", content="你好", timestamp=now - timedelta(days=1, hours=1)),
    # ...
]

# 3. 一行运行全部
results = registry.run_all(messages)

# 4. 查看推演结果
print(results["inference"].details["overall_verdict"])
# {'label': '🟡 观察', 'advice': '...'}

# 5. 查看解读摘要
print(results["interpretation"].details["summary"])
# '主要意图：询问；主要讨论主题：工作...'
```

---

## 4. 快速决定表

| 你的情况 | 推荐命令 | 报告类型 |
|---------|---------|---------|
| **第一次用，看个意思** | `python scripts/main.py demo` | HTML（自动生成） |
| **正式分析一段聊天** | `python scripts/main.py analyze-v2 --paste --html 报告.html` | HTML（离线可开） |
| **大批量分析（>10 段聊天）** | `python scripts/main.py analyze-v2 --input 聊天.txt --export result.json` + 批量对比 | JSON |
| **出错了想排查** | `python scripts/main.py doctor` | 终端日志 |
| **想预测对话走向** | 跑 `analyze-v2` 后看报告「🔮 推演」段 | 已包含 |
| **想知道对方在想什么** | 跑 `analyze-v2` 后看报告「📋 解读」段 | 已包含 |
| **集成到自己的代码** | `from analyzers import create_default_registry` | Python dict |

---

## 5. 常见问题（5 大坑）

### 🔴 Q1：跑命令后报 `ModuleNotFoundError: No module named 'xxx'`

**解决**：跑 `python scripts/main.py doctor` 看哪些依赖缺失，然后：
```bash
pip install -r requirements.txt

# RAG 引擎可选：
pip install -r requirements-rag.txt

# Web 仪表盘（v2.1.0 路线图）可选：
pip install -r requirements-web.txt
```

### 🟡 Q2：`jieba` 没用上，结果不准

**症状**：分析结果像没分词一样粗糙。

**原因**：`jieba` 没装。

**解决**：
```bash
pip install jieba
# 然后重启脚本
```

### 🟡 Q3：聊天记录导出格式不识别

**微信导出格式**（默认支持）：
```
张三 13:45:01
你好啊

李四 13:46:22
在的，怎么了
```

**支持的格式变体**：
- `发送者: 内容`（冒号+空格）
- `[时间] 发送者: 内容`（方括号时间）
- JSON 格式（必须是字典列表）

**不识别时怎么办**：
1. 用文本编辑器把聊天记录改成上面的格式
2. 或用 `--input 聊天.txt` 时确认编码（默认 utf-8-sig / utf-8 / gb18030 自动嗅探）

### 🟠 Q4：分析报「MiroFish 默认关闭」

**默认关闭原因**：mirofish 多智能体模拟需要更多算力。

**启用**：编辑 `config.json`，找 `"mirofish_enabled": false` 改成 `true`。

### 🔴 Q5：报告里说「样本较少，结果仅供参考」

**原因**：消息总数 < 50 条，或时间跨度 < 1 天。

**建议**：
- 累积到至少 30 天聊天
- 或增加样本量（导入更多聊天记录）
- 或把这个分析当作"试探性结论"，重要决策再人工核对

---

## 6. 输出报告章节说明

打开 HTML 报告后，你会看到这些章节：

| 章节 | 看什么 |
|------|--------|
| 📋 **总览** | 1 句话总结整体状况 + 健康度评分 |
| 🧬 **MBTI / 大五人格** | 推断的人格类型（仅供参考） |
| 💬 **情感分析** | 整体情感倾向 + 关键转折点 |
| ⚠️ **风险检测** | 是否有对抗/对抗升级信号 |
| 🎬 **场景分类** | 聊天主要是工作/家庭/感情/... |
| 📊 **对话模式** | 主动率、回复速度、活跃时段 |
| 🔮 **推演能力**（v2.2.0 新增） | 5 大子推演：话题/对手/情感/风险/走向 |
| 📋 **信息解读**（v2.2.0 新增） | 4 大解读：意图/实体/主题/立场 |
| 💡 **建议** | 系统自动生成的关系维护建议 |

---

## 7. 一行命令速记（贴桌面）

```bash
# 第一次 → demo
python scripts/main.py demo

# 出问题 → doctor
python scripts/main.py doctor

# 正式分析 → analyze-v2 + HTML
python scripts/main.py analyze-v2 --paste --html report.html && start report.html

# 仅文本/JSON
python scripts/main.py analyze-v2 --input 聊天.txt --export result.json
```

---

## 8. 文档交叉引用

- 📘 [SKILL.md](SKILL.md) — 完整规范和方法论
- 📗 [README.md](README.md) — 项目说明
- 📙 [CHANGELOG.md](CHANGELOG.md) — 历史更新
- 📕 [templates/](templates/) — 报告模板
- 🐟 [scripts/mirofish_README.md](scripts/mirofish_README.md) — 多智能体引擎

---

## 9. 已知问题（不影响主流程，但别踩）

- **`scripts/mirofish_services_*` 目前无法导入** — `scripts/mirofish_config.py` 在模块顶层
  `from dotenv import load_dotenv`，而 `python-dotenv` 没出现在任何 requirements 文件里；
  同时 `scripts/mirofish_services_report_agent.py` 等文件引用的 `Config.UPLOAD_FOLDER` 从未定义。
  结论：**这套服务在当前版本是死代码**，CLI 与 MCP 都不导入它，`mirofish.enabled=true` 也走不到这里。
  要启用需要先补 `pip install python-dotenv` 并给 `Config` 补上 `UPLOAD_FOLDER`；按现状使用不受影响。
- **RAG 首次运行要下模型** — `sentence-transformers` 会下载 50-100MB embedding，离线环境请预先缓存。
  模型缓存与向量库都写在运行时数据目录，不会留在技能包内。
- **桌面捕获只在 Windows 有效** — 非 Windows 平台执行 `capture` 会直接说明原因并改推荐 `analyze-v2 --paste`。

---

*最后更新：v6.0.0（2026-11-07）*
