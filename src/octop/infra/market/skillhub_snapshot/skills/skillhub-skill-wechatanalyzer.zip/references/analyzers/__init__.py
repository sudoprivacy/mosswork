"""
微信聊天分析器 v2.0.0

模块化拆分自 v1.2.0 的 text_analyzer.py，每个分析器独立成模块。
所有分析器继承 core.AnalyzerBase，统一通过 AnalyzerRegistry 调度。

可用分析器：
    - mbti: MBTI 人格推断
    - bigfive: 大五人格
    - sentiment: 情感分析（支持否定识别 + 程度副词 + 滚动趋势）
    - risk: 风险检测（支持反讽识别 + 上下文验证）
    - scenario: 场景分类
    - pattern: 对话模式分析
    - inference: 7 大推演能力（v2.2.0 新增，v4.0.0 加马尔可夫链与回复时间模式）
    - interpretation: 4 大解读能力（v2.2.0 新增）
    - relationship: 关系健康度（v2.9.0 新增）
    - group: 群聊多主体分析（v5.0.0 新增）
    - privacy: 本地隐私泄露扫描（v5.0.0 新增）
    - topic: 话题地图（v6.0.0 新增）
"""

import sys
sys.dont_write_bytecode = True

from core.analyzer_base import AnalyzerBase, AnalyzerRegistry
from core.version import __version__ as _PKG_VERSION
from analyzers.mbti_analyzer import MBTIAnalyzer
from analyzers.bigfive_analyzer import BigFiveAnalyzer
from analyzers.sentiment_analyzer import SentimentAnalyzer
from analyzers.risk_analyzer import RiskAnalyzer
from analyzers.scenario_analyzer import ScenarioAnalyzer
from analyzers.pattern_analyzer import PatternAnalyzer
# v2.2.0 新增
from analyzers.inference_analyzer import InferenceAnalyzer
from analyzers.interpretation_analyzer import InterpretationAnalyzer
# v2.9.0 新增
from analyzers.relationship_analyzer import RelationshipAnalyzer
# v5.0.0 新增
from analyzers.privacy_scanner import PrivacyScanner
from analyzers.group_analyzer import GroupAnalyzer
# v6.0.0 新增
from analyzers.topic_analyzer import TopicAnalyzer


# v5.0.0：版本号一律取自 core.version（此前这里硬编码 2.9.0 长期漂移）
__version__ = _PKG_VERSION


def create_default_registry(config: dict = None) -> AnalyzerRegistry:
    """创建默认的注册中心（包含所有分析器）"""
    registry = AnalyzerRegistry()

    cfg = config or {}
    analysis_cfg = cfg.get("analysis", {})

    if analysis_cfg.get("mbti_enabled", True):
        registry.register(MBTIAnalyzer(config=cfg))
    if analysis_cfg.get("bigfive_enabled", True):
        registry.register(BigFiveAnalyzer(config=cfg))
    if analysis_cfg.get("sentiment_enabled", True):
        registry.register(SentimentAnalyzer(config=cfg))
    if analysis_cfg.get("risk_detection_enabled", True):
        registry.register(RiskAnalyzer(config=cfg))

    # 场景和模式默认开启
    registry.register(ScenarioAnalyzer(config=cfg))
    registry.register(PatternAnalyzer(config=cfg))

    # v2.2.0 新增：推演 + 信息解读（默认开启）
    if analysis_cfg.get("inference_enabled", True):
        registry.register(InferenceAnalyzer(config=cfg))
    if analysis_cfg.get("interpretation_enabled", True):
        registry.register(InterpretationAnalyzer(config=cfg))

    # v2.9.0 新增：关系健康度（默认开启）
    if analysis_cfg.get("relationship_enabled", True):
        registry.register(RelationshipAnalyzer(config=cfg))

    # v5.0.0 新增：群聊多主体 + 本地隐私扫描（默认开启）
    if analysis_cfg.get("group_enabled", True):
        registry.register(GroupAnalyzer(config=cfg))
    if analysis_cfg.get("privacy_scan_enabled", True):
        registry.register(PrivacyScanner(config=cfg))

    # v6.0.0 新增：话题地图（关键词/语义主题/人物关注点/话题切换）
    if analysis_cfg.get("topic_enabled", True):
        registry.register(TopicAnalyzer(config=cfg))

    return registry


__all__ = [
    "AnalyzerBase",
    "AnalyzerRegistry",
    "MBTIAnalyzer",
    "BigFiveAnalyzer",
    "SentimentAnalyzer",
    "RiskAnalyzer",
    "ScenarioAnalyzer",
    "PatternAnalyzer",
    # v2.2.0 新增
    "InferenceAnalyzer",
    "InterpretationAnalyzer",
    # v2.9.0 新增
    "RelationshipAnalyzer",
    # v5.0.0 新增
    "GroupAnalyzer",
    "PrivacyScanner",
    # v6.0.0 新增
    "TopicAnalyzer",
    "create_default_registry",
]
