"""
关系健康度分析器 - v2.9.0 新增

从五个维度量化一段聊天关系的健康程度（全部为启发式估计，仅供参考）：

1. balance        互动平衡度：双方消息量是否接近 1:1（一方独白扣分）
2. responsiveness 回应度：回复速度分布（<1分钟 满分 → >24小时 近零）
3. emotional_sync 情感同步性：双方正负情感走向是否一致
4. engagement     投入度：活跃天密度（日均消息量）
5. depth          互动深度：平均消息长度（嗯/哦 式短消息占比高则浅）

综合分 = 加权和 - 冷回复惩罚（对方长消息后自己回「嗯/哦」的比例）。

等级：excellent(>=75) / good(>=60) / fair(>=40) / warning(<40)
"""

from typing import List, Dict, Any, Optional, Tuple

from core.analyzer_base import AnalyzerBase
from core.message import Message
from core.result import AnalysisResult


# 冷回复：对方发来长消息后，回复这种短词视为敷衍
_COLD_REPLIES = ("嗯", "哦", "噢", "好", "行", "可", "随你", "随便",
                 "嗯嗯", "哦哦", "好的", "知道了", "。", "?", "？")

# 权重（总和 1.0）
_WEIGHTS = {
    "balance": 0.25,
    "responsiveness": 0.20,
    "emotional_sync": 0.20,
    "engagement": 0.20,
    "depth": 0.15,
}

_GRADE_THRESHOLDS = (
    (75.0, "excellent", "优秀"),
    (60.0, "good", "良好"),
    (40.0, "fair", "一般"),
    (0.0, "warning", "需要关注"),
)


class RelationshipAnalyzer(AnalyzerBase):
    """关系健康度分析器（v2.9.0）"""

    name = "relationship"
    version = "2.9.0"
    description = "关系健康度（平衡/回应/情感同步/投入/深度五维评估）"

    def __init__(self, config: dict = None):
        super().__init__(config)
        self.min_messages = 6
        self._sentiment_helper = None  # 延迟初始化的情感评分辅助（词典法）

    def validate(self, messages: List[Message]) -> bool:
        self_count = sum(1 for m in messages if m.is_self() and m.has_content())
        other_count = sum(1 for m in messages if m.is_other() and m.has_content())
        return len(messages) >= self.min_messages and self_count >= 1 and other_count >= 1

    # ---------- 主入口 ----------

    def analyze(self, messages: List[Message], **kwargs) -> AnalysisResult:
        """分析关系健康度。

        kwargs:
            sentiment_detail: 可选，sentiment 分析器 details（含 self_positive 时
                直接复用，避免重复扫描词典）。

        Returns:
            details={
                "dimensions": {balance/responsiveness/emotional_sync/engagement/depth},
                "health_score": 0-100,
                "grade": "excellent"/"good"/"fair"/"warning",
                "grade_label": 中文,
                "cold_reply_ratio": 0-1,
                "suggestions": [...],
            }
        """
        dims: Dict[str, float] = {}
        dims["balance"] = self._calc_balance(messages)
        dims["responsiveness"] = self._calc_responsiveness(messages)
        dims["emotional_sync"] = self._calc_emotional_sync(
            messages, kwargs.get("sentiment_detail"))
        dims["engagement"] = self._calc_engagement(messages)
        dims["depth"] = self._calc_depth(messages)

        cold_ratio = self._calc_cold_reply_ratio(messages)
        penalty = cold_ratio * 20.0  # 最多扣 20 分

        raw = sum(dims[k] * w for k, w in _WEIGHTS.items())
        health = max(0.0, min(100.0, raw - penalty))
        grade, grade_label = self._grade_of(health)

        suggestions = self._build_suggestions(dims, cold_ratio)

        confidence = min(90.0, 30.0 + len(messages) * 0.8)

        return AnalysisResult(
            analyzer_name=self.name,
            score=round(health, 1),
            confidence=round(confidence, 1),
            details={
                "dimensions": {k: round(v, 1) for k, v in dims.items()},
                "weights": dict(_WEIGHTS),
                "health_score": round(health, 1),
                "grade": grade,
                "grade_label": grade_label,
                "cold_reply_ratio": round(cold_ratio, 3),
                "penalty": round(penalty, 1),
                "suggestions": suggestions,
            },
            metadata={"analyzer": "RelationshipAnalyzer", "version": self.version},
        )

    # ---------- 维度计算 ----------

    @staticmethod
    def _calc_balance(messages: List[Message]) -> float:
        """互动平衡度：双方有效消息量比值（1:1 → 100）。

        比值 ≤ 1:5 视为一方独白 → 0 分；1:1 → 满分，中间线性过渡。
        """
        self_count = sum(1 for m in messages if m.is_self() and m.has_content())
        other_count = sum(1 for m in messages if m.is_other() and m.has_content())
        if self_count == 0 or other_count == 0:
            return 0.0
        ratio = min(self_count, other_count) / max(self_count, other_count)
        # ratio 0.2 → 0 分，1.0 → 100 分（低于 1:5 即判为独白）
        score = (ratio - 0.2) / 0.8 * 100.0
        return max(0.0, min(100.0, score))

    @staticmethod
    def _calc_responsiveness(messages: List[Message]) -> float:
        """回应度：跨发送者回复间隔的加权平均（越快越高）。

        分级：<1分钟=1.0 / <10分钟=0.8 / <1小时=0.5 / <24小时=0.2 / 更久=0.05
        无时间戳或无回复样本 → 中性 50。
        """
        scores: List[float] = []
        last_ts = None
        last_sender: Optional[str] = None
        for msg in messages:
            if msg.timestamp is None:
                last_ts, last_sender = None, None
                continue
            if (last_ts is not None and last_sender is not None
                    and msg.sender != last_sender):
                gap = (msg.timestamp - last_ts).total_seconds()
                if gap >= 0:
                    if gap < 60:
                        scores.append(1.0)
                    elif gap < 600:
                        scores.append(0.8)
                    elif gap < 3600:
                        scores.append(0.5)
                    elif gap < 86400:
                        scores.append(0.2)
                    else:
                        scores.append(0.05)
            last_ts = msg.timestamp
            last_sender = msg.sender
        if not scores:
            return 50.0
        return sum(scores) / len(scores) * 100.0

    def _calc_emotional_sync(self, messages: List[Message],
                             sentiment_detail: Optional[Dict[str, Any]]) -> float:
        """情感同步性：时间轴分段，比较双方正面情感占比的一致性。

        优先复用 sentiment 分析器的 details（v2.9.0 起含 self_positive）；
        没有时退化为表情符号轻量统计。样本不足 → 中性 50。
        """
        self_ratio: Optional[float] = None
        other_ratio: Optional[float] = None

        if sentiment_detail:
            self_pos = sentiment_detail.get("self_positive")
            self_neg = sentiment_detail.get("self_negative")
            if isinstance(self_pos, (int, float)) and isinstance(self_neg, (int, float)) \
                    and (self_pos + self_neg) > 0:
                self_ratio = self_pos / (self_pos + self_neg)
            other_pos = sentiment_detail.get("positive", 0.0)
            other_neg = sentiment_detail.get("negative", 0.0)
            if (other_pos + other_neg) > 0:
                other_ratio = other_pos / (other_pos + other_neg)

        if self_ratio is None or other_ratio is None:
            # 回退一：词典评分（复用 SentimentAnalyzer 的语句评分，自包含）
            self_ratio, other_ratio = self._lexicon_sentiment_ratios(messages)
        if self_ratio is None or other_ratio is None:
            # 回退二：表情符号轻量统计（零词典依赖）
            self_ratio, other_ratio = self._emoji_sentiment_ratios(messages)
        if self_ratio is None or other_ratio is None:
            return 50.0

        diff = abs(self_ratio - other_ratio)
        return max(0.0, 100.0 * (1.0 - diff * 2.0))

    def _lexicon_sentiment_ratios(self, messages: List[Message]
                                  ) -> Tuple[Optional[float], Optional[float]]:
        """词典法：复用 SentimentAnalyzer 的单句评分算双方正面占比。

        延迟初始化（仅首次使用时加载词典）；情感词典缺失时返回 (None, None)
        交由表情符号回退层处理。
        """
        try:
            from analyzers.sentiment_analyzer import SentimentAnalyzer  # noqa: PLC0415
        except ImportError:
            return None, None
        if self._sentiment_helper is None:
            helper = SentimentAnalyzer()
            if not helper.sentiment_dict:
                return None, None
            self._sentiment_helper = helper

        def ratio(msgs) -> Optional[float]:
            pos = neg = 0.0
            for m in msgs:
                if not m.has_content():
                    continue
                p, n, _pw, _nw = self._sentiment_helper._analyze_sentence(m.content)
                pos += p
                neg += n
            if pos + neg <= 0:
                return None
            return pos / (pos + neg)

        return (ratio([m for m in messages if m.is_self()]),
                ratio([m for m in messages if m.is_other()]))

    @staticmethod
    def _emoji_sentiment_ratios(messages: List[Message]
                                ) -> Tuple[Optional[float], Optional[float]]:
        """轻量回退：仅统计表情符号的正面占比（无词典依赖）。"""
        pos_emoji = ("😀", "😄", "😁", "😊", "🥰", "❤", "💕", "👍", "😂", "🤣",
                     "😆", "🌹", "🎉", "😍")
        neg_emoji = ("😭", "😢", "😞", "😡", "🙄", "😒", "💔", "😤", "😰")

        def ratio(msgs) -> Optional[float]:
            pos = neg = 0
            for m in msgs:
                text = m.content or ""
                pos += sum(text.count(e) for e in pos_emoji)
                neg += sum(text.count(e) for e in neg_emoji)
            if pos + neg == 0:
                return None
            return pos / (pos + neg)

        return (ratio([m for m in messages if m.is_self()]),
                ratio([m for m in messages if m.is_other()]))

    @staticmethod
    def _calc_engagement(messages: List[Message]) -> float:
        """投入度：日均消息量（>=10 条/天 → 100），无时间戳按总量估计。"""
        total = sum(1 for m in messages if m.has_content())
        timestamps = sorted(m.timestamp for m in messages if m.timestamp)
        if len(timestamps) >= 2:
            span_days = max(1.0, (timestamps[-1] - timestamps[0]).days + 1.0)
            daily = total / span_days
        else:
            # 无时间戳：把总量当作单日强度（封顶）
            daily = float(total)
        return min(100.0, daily * 10.0)

    @staticmethod
    def _calc_depth(messages: List[Message]) -> float:
        """互动深度：平均消息长度（>=25 字 → 100），过短消息占比高则浅。"""
        lengths = [len(m.content) for m in messages if m.has_content()]
        if not lengths:
            return 0.0
        avg_len = sum(lengths) / len(lengths)
        return min(100.0, avg_len * 4.0)

    @staticmethod
    def _calc_cold_reply_ratio(messages: List[Message]) -> float:
        """冷回复比例：上一条是长消息(>20字)而本条是短敷衍词的比例。"""
        cold = 0
        candidates = 0
        prev_long = False
        for msg in messages:
            content = (msg.content or "").strip()
            if not content:
                continue
            if prev_long:
                candidates += 1
                if len(content) <= 4 and content in _COLD_REPLIES or content in _COLD_REPLIES:
                    cold += 1
            prev_long = len(content) > 20
        if candidates == 0:
            return 0.0
        return cold / candidates

    # ---------- 结果汇总 ----------

    @staticmethod
    def _grade_of(health: float) -> Tuple[str, str]:
        for threshold, grade, label in _GRADE_THRESHOLDS:
            if health >= threshold:
                return grade, label
        return "warning", "需要关注"

    @staticmethod
    def _build_suggestions(dims: Dict[str, float], cold_ratio: float) -> List[str]:
        suggestions: List[str] = []
        if dims["balance"] < 50:
            suggestions.append("互动失衡：一方消息明显偏多，可尝试给对方更多回应空间")
        if dims["responsiveness"] < 50:
            suggestions.append("回复偏慢：隔太久容易让对话降温，重要消息尽量当天回复")
        if dims["emotional_sync"] < 50:
            suggestions.append("情感不同步：双方情绪基调差异较大，多关注对方当下感受")
        if dims["engagement"] < 40:
            suggestions.append("联系频率偏低：可以找共同话题增加日常互动")
        if dims["depth"] < 40:
            suggestions.append("对话偏短：多聊具体经历和感受，少用一两个字回应")
        if cold_ratio >= 0.2:
            suggestions.append("冷回复较多：「嗯/哦」式回应容易让对方失落，试着多写一句")
        if not suggestions:
            suggestions.append("关系状态良好，保持当前的互动节奏")
        return suggestions
