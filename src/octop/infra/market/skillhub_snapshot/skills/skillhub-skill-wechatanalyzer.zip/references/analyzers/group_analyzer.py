"""
群聊多主体分析器 v5.0.0

v4.0.0 及之前，`Message.is_other()` 把"所有不是我的发送者"折成一个 other。
一对一聊天里这没问题，群聊里等于把十几个人的话合并成一个人的发言：
    - MBTI / 大五 把三个人的关键词混在一起，输出一个不存在的人格；
    - 关系健康度算出"回复比 1:1 很健康"，其实是 A 在跟 B 吵、C 在潜水；
    - 情感趋势把不同人的情绪当成同一条曲线。

本分析器不试图修复上面那些（那是"按人分组分别跑"的架构改造，另说），
它先把**群聊到底是谁在说话**这件事量化出来，并在检测到群聊时
显式提醒其它结论不可信——这是目前成本最低、也最诚实的一步。

输出：
    - 成员发言占比与活跃度分层
    - @提及网络（谁找谁说话）
    - 两人子对话抽取（把群里的一来一回摘出来，可单独送进分析）
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Tuple

from core.analyzer_base import AnalyzerBase
from core.message import Message
from core.result import AnalysisResult

# @某人：@ 必须处在词起点（行首或标点/空白之后），否则 "lisi@example.com"
# 里的 @ 会被当成一次 @提及，网络图里就多出一条指向域名的假边。
_MENTION_RE = re.compile(
    r"(?:^|(?<=[\s，,。；;：:、！!？?]))@([^\s@，,。；;：:、！!？?]{2,20})")

# 群聊里的系统/噪声行，不该算发言
_SYSTEM_HINTS = ("【图片】", "[图片]", "【动画表情】", "[动画表情]",
                 "你已添加了", "以上是打招呼", "以上是我发送的名片",
                 "撤回了一条消息", "对方正在输入")


class GroupAnalyzer(AnalyzerBase):
    """群聊主体分布分析。"""

    name = "group"
    version = "5.0.0"
    description = "识别群聊并量化成员占比、活跃度分层、@提及网络与两人子对话"

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(config)
        cfg = (config or {}).get("group_chat", {})
        self.enabled = cfg.get("enabled", True)
        # 达到这个参与人数才认定为"群聊"
        self.min_members = cfg.get("min_members", 3)
        # 发言占比高于此值算"活跃"
        self.active_ratio = cfg.get("active_ratio", 0.10)
        self.top_mentions = cfg.get("top_mentions", 10)

    def validate(self, messages: List[Message]) -> bool:
        real = self._real_messages(messages)
        if len(real) < 3:
            return False
        # 一对一也要跑：输出"这是单聊"本身就有信息量，
        # 而且注册中心跳过分析器时报告里什么都不留，用户分不清"没群"还是"没跑"。
        return True

    def analyze(self, messages: List[Message], **kwargs) -> AnalysisResult:
        real = self._real_messages(messages)
        members = self._member_stats(real)
        total_msgs = sum(m["messages"] for m in members.values()) or 1

        roster = []
        for sender, stat in sorted(members.items(), key=lambda kv: -kv[1]["messages"]):
            share = stat["messages"] / total_msgs
            roster.append({
                "sender": sender,
                "messages": stat["messages"],
                "share": round(share * 100, 1),
                "chars": stat["chars"],
                "avg_len": round(stat["chars"] / stat["messages"], 1) if stat["messages"] else 0,
                "tier": self._tier_of(share, stat["messages"]),
                "mentions_out": stat["mentions_out"],
                "mentions_in": 0,  # 下面按边累加
            })
        by_sender = {r["sender"]: r for r in roster}

        edges, mention_pairs = self._mention_network(real, set(members.keys()))
        for frm, to, count in mention_pairs:
            if to in by_sender:
                by_sender[to]["mentions_in"] += count

        pairs = self._dyad_stats(real)
        member_count = len(members)
        is_group = member_count >= self.min_members

        # 集中度：占比最高者有多主导；用 1 - 香农熵/log2(N) 归一
        dominance = self._dominance([r["share"] / 100 for r in roster])

        details = {
            "is_group": is_group,
            "member_count": member_count,
            "message_count": total_msgs,
            "dominance": round(dominance, 3),
            "roster": roster,
            "tiers": self._tier_summary(roster),
            "mention_edges": edges[:self.top_mentions],
            "top_pairs": pairs[:5],
            "note": self._note(is_group, member_count, roster, dominance),
        }

        # 置信度只看样本量：这是纯计数，不涉及推断
        confidence = min(97.0, 55.0 + total_msgs * 0.6)
        # score 用"活跃成员数"占成员数的比例，反映群里到底几个人真在说话
        active = sum(1 for r in roster if r["tier"] in ("主导", "活跃", "常规"))
        score = round(active / member_count * 100, 1) if member_count else 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            score=score,
            confidence=round(confidence, 1),
            details=details,
            metadata={
                "analyzer": "GroupAnalyzer",
                "version": self.version,
                "min_members": self.min_members,
            },
        )

    # ------------------------------------------------------------------
    # 内部
    # ------------------------------------------------------------------

    @staticmethod
    def _real_messages(messages: List[Message]) -> List[Message]:
        out = []
        for m in messages:
            if not m.has_content() or not m.is_text():
                continue
            content = m.content.strip()
            if any(h in content for h in _SYSTEM_HINTS) and len(content) <= 30:
                continue
            out.append(m)
        return out

    @staticmethod
    def _member_stats(real: List[Message]) -> Dict[str, Dict[str, Any]]:
        stats: Dict[str, Dict[str, Any]] = {}
        mention_out: Counter = Counter()
        for m in real:
            sender = (m.sender or "unknown").strip() or "unknown"
            stat = stats.setdefault(sender, {"messages": 0, "chars": 0, "mentions_out": 0})
            stat["messages"] += 1
            stat["chars"] += len(m.content.strip())
            for name in _MENTION_RE.findall(m.content):
                mention_out[(sender, name.strip())] += 1
        for (frm, _to), count in mention_out.items():
            if frm in stats:
                stats[frm]["mentions_out"] += count
        return stats

    def _tier_of(self, share: float, messages: int) -> str:
        if share >= self.active_ratio * 3:
            return "主导"
        if share >= self.active_ratio:
            return "活跃"
        if messages >= 3:
            return "常规"
        return "潜水"

    @staticmethod
    def _tier_summary(roster: List[Dict[str, Any]]) -> Dict[str, int]:
        summary: Dict[str, int] = {"主导": 0, "活跃": 0, "常规": 0, "潜水": 0}
        for r in roster:
            summary[r["tier"]] = summary.get(r["tier"], 0) + 1
        return summary

    def _mention_network(self, real: List[Message],
                         known: set) -> Tuple[List[Dict[str, Any]], List[Tuple[str, str, int]]]:
        counts: Counter = Counter()
        for m in real:
            frm = (m.sender or "unknown").strip() or "unknown"
            for raw in _MENTION_RE.findall(m.content):
                to = raw.strip()
                if to:
                    counts[(frm, to)] += 1
        pairs = sorted(counts.items(), key=lambda kv: -kv[1])
        edges = [
            {"from": frm, "to": to, "count": cnt,
             "resolved": to in known or any(to in k or k in to for k in known)}
            for (frm, to), cnt in pairs[:self.top_mentions]
        ]
        resolved_pairs = [(frm, to, cnt) for (frm, to), cnt in pairs]
        return edges, resolved_pairs

    def _dyad_stats(self, real: List[Message]) -> List[Dict[str, Any]]:
        """相邻消息构成的两人对话强度。

        群里"谁在跟谁说话"没有显式标注，用"上一条 A、紧接着 B 回复"作为
        最弱证据：能抓出一来一回的热度，但不等于 B 真的在回应 A。
        因此只报次数、不下结论。
        """
        adj: Counter = Counter()
        for prev, cur in zip(real, real[1:]):
            a = (prev.sender or "unknown").strip() or "unknown"
            b = (cur.sender or "unknown").strip() or "unknown"
            if a == b:
                continue
            adj[(a, b)] += 1

        combined: Dict[Tuple[str, str], Dict[str, Any]] = {}
        for (a, b), cnt in adj.items():
            key = tuple(sorted((a, b)))
            entry = combined.setdefault(key, {"a": key[0], "b": key[1],
                                              "turns": 0, "a_to_b": 0, "b_to_a": 0})
            entry["turns"] += cnt
            if key[0] == a:
                entry["a_to_b"] += cnt
            else:
                entry["b_to_a"] += cnt

        out = []
        for entry in combined.values():
            total = entry["a_to_b"] + entry["b_to_a"] or 1
            out.append({
                "pair": f"{entry['a']} <-> {entry['b']}",
                "turns": entry["turns"],
                "balance": round(min(entry["a_to_b"], entry["b_to_a"]) / total, 3),
                "a_to_b": entry["a_to_b"],
                "b_to_a": entry["b_to_a"],
            })
        out.sort(key=lambda d: -d["turns"])
        return out

    @staticmethod
    def _dominance(shares: List[float]) -> float:
        """1 - 归一化香农熵：0 = 人人平等，1 = 一个人说完所有话。"""
        shares = [s for s in shares if s > 0]
        if len(shares) <= 1:
            return 0.0
        import math
        entropy = -sum(s * math.log(s, 2) for s in shares)
        return 1.0 - entropy / math.log(len(shares), 2)

    def _note(self, is_group: bool, member_count: int,
              roster: List[Dict[str, Any]], dominance: float) -> str:
        if member_count == 0:
            return "没有可统计的发言。"
        if not is_group:
            top = roster[0]["sender"] if roster else "unknown"
            return (f"{member_count} 位参与者，按一对一处理。"
                    f"主要发言者是「{top}」。")
        tiers = self._tier_summary(roster)
        lurkers = tiers.get("潜水", 0)
        parts = [f"识别为群聊：{member_count} 位成员",
                 f"发言集中度 {dominance:.2f}"]
        if dominance >= 0.6:
            parts.append(f"高度集中在「{roster[0]['sender']}」（{roster[0]['share']}%）")
        if lurkers:
            parts.append(f"{lurkers} 人基本潜水")
        parts.append("注意：MBTI／大五／关系健康度等结论把全部对方消息当同一个人，"
                     "在群聊里不可靠，建议按成员分别分析")
        return "；".join(parts) + "。"


def extract_sub_conversation(messages: List[Message], a: str, b: str) -> List[Message]:
    """从群聊里抽出 A 与 B 之间的两人子对话。

    用于"群里那两个人到底怎么了"——把子集喂给 mbti / relationship 之前，
    至少这两条消息序列只属于两个主体。
    """
    keep = {a, b}
    return [m for m in messages
            if m.has_content() and ((m.sender or "").strip() in keep)]


def group_messages(messages: List[Message]) -> Dict[str, List[Message]]:
    """按发送者分组，供"逐成员分析"使用。"""
    buckets: Dict[str, List[Message]] = defaultdict(list)
    for m in messages:
        if m.has_content() and m.is_text():
            buckets[(m.sender or "unknown").strip() or "unknown"].append(m)
    return dict(buckets)


if __name__ == "__main__":
    import json

    demo = [
        Message(sender="我", content="@张三 那个方案定了吗"),
        Message(sender="张三", content="还没，我今晚看看"),
        Message(sender="李四", content="我这边数据已经跑完了，需要的话发你们"),
        Message(sender="张三", content="@李四 发群里吧，谢谢"),
        Message(sender="王五", content="【图片】"),
        Message(sender="我", content="@张三 辛苦，定个时间我们对一下"),
        Message(sender="赵六", content="收到"),
        Message(sender="张三", content="明天上午十点吧"),
        Message(sender="李四", content="我都可以"),
        Message(sender="我", content="行，那明天见"),
        Message(sender="张三", content="好"),
        Message(sender="王五", content="你们定就行"),
    ]
    print(json.dumps(GroupAnalyzer().analyze(demo).to_dict(), ensure_ascii=False, indent=2))
