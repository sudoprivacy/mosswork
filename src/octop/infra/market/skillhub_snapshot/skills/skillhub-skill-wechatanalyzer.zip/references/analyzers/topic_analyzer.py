"""话题地图分析器 v6.0.0

为什么需要它：
    interpretation 里的"主题"是固定词典命中（工作/家庭/感情…），能回答
    "聊的是哪一类"，但回答不了"这段聊天反复出现的词是什么、谁更爱聊什么、
    话题在哪一段变了"。这里补一张数据驱动的话题地图，全程本地、可复现。

输出四层：
    1. keywords   — TF-IDF 关键词（词频 × 消息级 IDF），带说话人拆分与冷热
    2. topics     — 语义桶（工作/家庭/感情…），可重叠，给关键词一个人话标签
    3. by_speaker — 我 / 对方 / 群成员各自的高频词与共同关注
    4. segments   — 按时间间隔切段，标出话题切换点

分词策略：
    有 jieba 走真实词边界；没有 jieba 时按随包内置的高频词表做最长匹配，
    词表外的未登录专名会漏掉，置信度明确打折并在 summary 里说明。
    不装 jieba 不能等于给出一份看似精确的假词云。
"""

import math
import re
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from core.analyzer_base import AnalyzerBase
from core.message import Message, is_self_sender
from core.result import AnalysisResult
from core.utils import CHINESE_STOPWORDS, HAS_JIEBA, tokenize


# 聊天里高频但不携带话题信息的词；只收"删掉不影响理解"的，不要把名词塞进来。
CHAT_STOPWORDS = {
    "真的", "感觉", "觉得", "知道", "还是", "一直", "然后", "时候", "东西",
    "事情", "可能", "应该", "需要", "大家", "现在", "其实", "有点", "比较",
    "非常", "特别", "就是", "这样", "那样", "一下", "一起", "已经", "因为",
    "所以", "如果", "但是", "可是", "不过", "或者", "而且", "那个", "这个",
    "什么", "怎么", "为什么", "没有", "不是", "可以", "我们", "你们", "他们",
    "她们", "自己", "一个", "这种", "那种", "好像", "似乎", "必须", "千万",
    "稍微", "完全", "确实", "基本", "上次", "这次", "下次", "之前", "之后",
    "最近", "以后", "以前", "目前", "看到", "听到", "想到", "说到", "做到",
    "认为", "希望", "辛苦", "谢谢", "感谢", "抱歉", "对不起", "没事", "好的",
    "行吧", "收到", "晚安", "早安", "晚上", "早上", "中午", "下午", "今天",
    "昨天", "明天", "很多", "看看", "不会", "出来", "起来", "过来", "回来",
    "下来", "下去", "上去", "进去", "出去", "开始", "继续", "结束", "变成",
    "成为", "进行", "出现", "发现", "方面", "情况", "之类", "等等", "以及",
    "这么", "那么", "怎样", "如何", "一定", "一步", "前先", "到时候", "原来",
    "反而", "后来", "然后", "接着", "于是", "因此", "另外", "此外", "同时",
    "终于", "刚刚", "刚才", "最近", "马上", "立刻", "顺便", "其实", "可能",
    "不错", "很好", "好看", "好玩", "厉害", "不见", "好久", "有点", "真的",
    "ok", "okay", "yes", "no", "hi", "hello", "谢谢", "晚安", "早安",
}

# 语义桶：只用于给数据驱动关键词贴标签，命中才输出，没命中不虚构。
TOPIC_HINTS: Dict[str, Tuple[str, ...]] = {
    "工作": ("项目", "会议", "客户", "老板", "加班", "同事", "工作", "任务",
             "需求", "KPI", "汇报", "方案", "上线", "排期", "绩效", "离职"),
    "家庭": ("家人", "爸妈", "父母", "孩子", "宝宝", "老公", "老婆", "婆婆",
             "夫妻", "家里", "亲戚", "回家"),
    "感情": ("喜欢", "爱你", "想你", "分手", "复合", "在一起", "表白", "心动",
             "约会", "恋爱", "对象"),
    "健康": ("生病", "医院", "检查", "吃药", "手术", "发烧", "感冒", "症状",
             "医生", "体检", "熬夜", "失眠", "锻炼"),
    "购物": ("买", "下单", "快递", "包邮", "优惠", "折扣", "淘宝", "京东",
             "拼多多", "退货", "链接"),
    "美食": ("吃", "喝", "餐厅", "外卖", "火锅", "烧烤", "咖啡", "奶茶",
             "做饭", "菜单", "味道"),
    "娱乐": ("游戏", "王者", "吃鸡", "原神", "抖音", "B站", "追剧", "综艺",
             "电影", "演唱会", "直播", "音乐"),
    "学习": ("考试", "作业", "论文", "课程", "老师", "学生", "学校", "毕业",
             "考研", "读书", "复习", "上课"),
    "财务": ("钱", "工资", "转账", "借", "还款", "信用卡", "余额", "存钱",
             "报销", "账单", "理财"),
    "出行": ("旅行", "机票", "高铁", "酒店", "出发", "车站", "机场", "假期",
             "旅游", "打车", "堵车"),
}

_CJK_RUN = re.compile(r"[\u4e00-\u9fff]+")
_ASCII_RUN = re.compile(r"[A-Za-z][A-Za-z0-9+#._-]{1,}")
_HAS_WORD_CHAR = re.compile(r"[A-Za-z0-9\u4e00-\u9fff]")
_PRIVATE_LIKE = re.compile(
    r"(?:1[3-9]\d{9}|[\w.+-]+@[\w-]+\.[A-Za-z]{2,}|https?://|\d{15,19})"
)

_SYSTEM_SENDERS = {"self", "other", "unknown", "system", "我"}

# 无 jieba 时的兜底词表：jieba 高频名词/动词子集（MIT）。
# 只给话题分析用，不改变 core.utils 的全局分词行为。
_FALLBACK_LEXICON_PATH = Path(__file__).resolve().parent / "lexicon_topic_fallback.txt"


@lru_cache(maxsize=1)
def _fallback_lexicon() -> Tuple[frozenset, int]:
    """返回 (词表, 最长词长)。文件缺失时返回空表，退化为重复片段统计。"""
    if not _FALLBACK_LEXICON_PATH.exists():
        return frozenset(), 4
    words = set()
    longest = 2
    with open(_FALLBACK_LEXICON_PATH, "r", encoding="utf-8") as handle:
        for line in handle:
            word = line.strip()
            if not word or word.startswith("#"):
                continue
            words.add(word)
            longest = max(longest, len(word))
    return frozenset(words), longest


class TopicAnalyzer(AnalyzerBase):
    """话题地图：关键词 / 语义主题 / 人物关注点 / 话题切换。"""

    name = "topic"
    version = "6.0.0"
    description = "话题地图（关键词/主题分布/人物偏好/冷热变化）"

    def __init__(self, config: dict = None):
        super().__init__(config)
        cfg = (config or {}).get("topic", {}) or {}
        self.top_n = max(5, int(cfg.get("top_keywords", 20) or 20))
        self.max_clusters = max(1, int(cfg.get("max_clusters", 6) or 6))
        self.session_gap_hours = float(cfg.get("session_gap_hours", 4) or 4)
        self.min_segment_messages = max(2, int(cfg.get("min_segment_messages", 3) or 3))
        self.min_messages = max(3, int(cfg.get("min_messages", 5) or 5))

    # ------------------------------------------------------------------
    # 校验
    # ------------------------------------------------------------------
    def validate(self, messages: List[Message]) -> bool:
        if len(messages) < self.min_messages:
            return False
        total_chars = sum(len(m.content or "") for m in messages)
        return total_chars >= 30

    # ------------------------------------------------------------------
    # 主流程
    # ------------------------------------------------------------------
    def analyze(self, messages: List[Message], **kwargs) -> AnalysisResult:
        texts = [m.content or "" for m in messages]
        excluded = self._excluded_terms(messages)

        per_message: List[Counter] = []
        for text in texts:
            per_message.append(self._terms_in_text(text, excluded))

        tf: Counter = Counter()
        df: Counter = Counter()
        speaker_tf: Dict[str, Counter] = defaultdict(Counter)
        for msg, counts in zip(messages, per_message):
            tf.update(counts)
            df.update(counts.keys())
            bucket = self._speaker_bucket(msg)
            speaker_tf[bucket].update(counts)

        if not tf:
            return AnalysisResult(
                analyzer_name=self.name,
                score=0.0,
                confidence=0.0,
                details={
                    "available": False,
                    "reason": "没有提取到有效话题词（文本过短或全是语气词）",
                    "tokenizer": "jieba" if HAS_JIEBA else "fallback",
                },
                metadata={"status": "empty"},
            )

        ranked = self._rank_terms(tf, df, speaker_tf, len(messages))
        keywords = ranked[: self.top_n]
        segments = self._build_segments(messages, per_message, texts)
        topics = self._build_topics(messages, per_message, keywords)
        clusters = self._build_clusters(per_message, keywords)
        by_speaker = self._build_speaker_view(messages, per_message, speaker_tf)
        trend = self._build_trend(messages, per_message, keywords)
        shifts = self._topic_shifts(segments)

        covered = sum(1 for counts in per_message if counts)
        total_terms = sum(tf.values())
        unique_terms = len(tf)
        top5_tf = sum(item["count"] for item in keywords[:5])
        concentration = round(top5_tf / total_terms * 100, 1) if total_terms else 0.0
        coverage = round(covered / len(messages) * 100, 1) if messages else 0.0
        diversity = round(unique_terms / total_terms, 3) if total_terms else 0.0

        confidence = self._confidence(len(messages), total_terms, coverage)
        summary = self._summary(keywords, topics, by_speaker, trend, shifts)

        return AnalysisResult(
            analyzer_name=self.name,
            score=float(concentration),
            confidence=float(confidence),
            details={
                "available": True,
                "message_count": len(messages),
                "tokenizer": "jieba" if HAS_JIEBA else "fallback",
                "tokenizer_note": (
                    "已安装 jieba，按真实词边界统计"
                    if HAS_JIEBA else
                    "未安装 jieba，按内置高频词表做最长匹配；词表外的未登录专名会漏掉，"
                    "安装 jieba 后结果更细"
                ),
                "total_terms": total_terms,
                "unique_terms": unique_terms,
                "lexical_diversity": diversity,
                "coverage": coverage,
                "concentration": concentration,
                "keywords": keywords,
                "topics": topics,
                "primary_topic": topics[0]["name"] if topics else "综合日常",
                "clusters": clusters,
                "by_speaker": by_speaker,
                "trend": trend,
                "segments": segments,
                "topic_shifts": shifts,
                "summary": summary,
            },
            metadata={
                "status": "ok",
                "config": {
                    "top_keywords": self.top_n,
                    "session_gap_hours": self.session_gap_hours,
                },
            },
        )

    # ------------------------------------------------------------------
    # 词提取与排序
    # ------------------------------------------------------------------
    def _excluded_terms(self, messages: List[Message]) -> Set[str]:
        """发言人名字、系统标识与隐私串不进话题榜。"""
        names: Set[str] = set()
        for msg in messages:
            sender = (msg.sender or "").strip()
            if not sender or sender.lower() in _SYSTEM_SENDERS:
                continue
            if is_self_sender(sender):
                continue
            names.add(sender.lower())
        return names

    def _terms_in_text(self, text: str, excluded: Set[str]) -> Counter:
        if not text:
            return Counter()
        counts: Counter = Counter()
        if HAS_JIEBA:
            for raw in tokenize(text, use_jieba=True):
                word = self._clean_term(raw, excluded)
                if word:
                    counts[word] += 1
            return counts

        # 无 jieba：ASCII 整词 + 词表最长匹配。
        # 词表外的 2 字窗口不做候选——它们绝大多数是跨词碎片（"天项/目终/我觉"），
        # 宁可漏掉未登录专名，也不让话题榜被噪声占满。
        for word in _ASCII_RUN.findall(text):
            clean = self._clean_term(word, excluded)
            if clean:
                counts[clean] += 1
        lexicon, max_len = _fallback_lexicon()
        for run in _CJK_RUN.findall(text):
            i = 0
            while i < len(run) - 1:
                matched = None
                for size in range(min(max_len, len(run) - i), 1, -1):
                    candidate = run[i:i + size]
                    if candidate in lexicon:
                        matched = candidate
                        break
                if matched:
                    clean = self._clean_term(matched, excluded)
                    if clean:
                        counts[clean] += 1
                    i += len(matched)
                else:
                    i += 1
        return counts

    def _clean_term(self, raw: Any, excluded: Set[str]) -> Optional[str]:
        if not isinstance(raw, str):
            return None
        word = raw.strip().lower()
        if len(word) < 2 or len(word) > 12:
            return None
        if not _HAS_WORD_CHAR.search(word):
            return None
        if word in CHINESE_STOPWORDS or word in CHAT_STOPWORDS:
            return None
        if word.isdigit() or _PRIVATE_LIKE.search(word):
            return None
        # 含数字的长串多半是订单号/金额/编号，不当话题词
        if any(ch.isdigit() for ch in word) and len(word) > 6:
            return None
        if word in excluded:
            return None
        return word

    def _rank_terms(self, tf: Counter, df: Counter,
                    speaker_tf: Dict[str, Counter], total_messages: int) -> List[Dict[str, Any]]:
        raw_scores: Dict[str, float] = {}
        for word in tf:
            idf = math.log((1 + total_messages) / (1 + df[word])) + 1.0
            raw_scores[word] = tf[word] * idf

        lexicon: frozenset = frozenset()
        if not HAS_JIEBA:
            lexicon, _ = _fallback_lexicon()
            # 词表外的一次性 2 字窗口基本都是跨词碎片（"天项/目终"），丢掉；
            # 英文缩写与重复出现的未登录词（"日料"）保留。
            for word in list(raw_scores):
                if word in lexicon or _ASCII_RUN.fullmatch(word):
                    continue
                if df[word] < 2:
                    raw_scores.pop(word, None)

        # 无 jieba 时词表外的候选可能与已选词重叠，只裁剪这些未登录候选，
        # 不裁词表内的真词（"项目" 与 "项目组" 可以同时存在）。
        ordered = sorted(
            raw_scores.items(),
            key=lambda kv: (-round(kv[1], 6), -len(kv[0]), kv[0]),
        )
        selected: List[str] = []
        if not HAS_JIEBA:
            for word, _score in ordered:
                if word in lexicon or _ASCII_RUN.fullmatch(word):
                    selected.append(word)
                elif not any(word in kept or kept in word for kept in selected):
                    selected.append(word)
                if len(selected) >= self.top_n * 3:
                    break
        else:
            selected = [word for word, _score in ordered]

        max_score = max((raw_scores[w] for w in selected), default=0.0)
        items: List[Dict[str, Any]] = []
        for word in selected[: self.top_n * 3]:
            count = tf[word]
            items.append({
                "word": word,
                "count": count,
                "df": df[word],
                "weight": round(raw_scores[word] / max_score * 100, 1) if max_score else 0.0,
                "self_count": speaker_tf.get("self", Counter()).get(word, 0),
                "other_count": speaker_tf.get("other", Counter()).get(word, 0),
            })
        # 二次排序：同一批候选里按权重稳定输出
        items.sort(key=lambda item: (-item["weight"], -item["count"], item["word"]))
        return items

    # ------------------------------------------------------------------
    # 语义主题（可重叠）
    # ------------------------------------------------------------------
    def _build_topics(self, messages: List[Message], per_message: List[Counter],
                      keywords: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        keyword_weights = {item["word"]: item["weight"] for item in keywords}
        buckets: List[Dict[str, Any]] = []
        for name, hints in TOPIC_HINTS.items():
            hit_indices = []
            for idx, msg in enumerate(messages):
                text = msg.content or ""
                if any(hint in text for hint in hints):
                    hit_indices.append(idx)
            if not hit_indices:
                continue
            local: Counter = Counter()
            for idx in hit_indices:
                for word, count in per_message[idx].items():
                    if word in keyword_weights:
                        local[word] += count
            top_words = [
                {"word": word, "count": count}
                for word, count in sorted(
                    local.items(), key=lambda kv: (-kv[1], kv[0]))[:3]
            ]
            buckets.append({
                "name": name,
                "messages": len(hit_indices),
                "share": round(len(hit_indices) / len(messages) * 100, 1),
                "top_keywords": top_words,
            })
        buckets.sort(key=lambda b: (-b["messages"], b["name"]))
        return buckets

    # ------------------------------------------------------------------
    # 数据驱动簇（同一条消息里反复一起出现的词）
    # ------------------------------------------------------------------
    def _build_clusters(self, per_message: List[Counter],
                        keywords: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        top_words = [item["word"] for item in keywords[:12]]
        if len(top_words) < 2:
            return []
        index = {word: i for i, word in enumerate(top_words)}
        parent = list(range(len(top_words)))

        def find(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

        cooc: Counter = Counter()
        for counts in per_message:
            present = sorted(index[w] for w in counts if w in index)
            for i, left in enumerate(present):
                for right in present[i + 1:]:
                    cooc[(left, right)] += 1
        for (left, right), times in cooc.items():
            if times >= 1:
                union(left, right)

        groups: Dict[int, List[int]] = defaultdict(list)
        for i in range(len(top_words)):
            groups[find(i)].append(i)

        weight_by_word = {item["word"]: item["weight"] for item in keywords}
        clusters: List[Dict[str, Any]] = []
        for members in groups.values():
            if len(members) < 2:
                continue
            words = [top_words[i] for i in members]
            label = max(words, key=lambda w: (weight_by_word.get(w, 0), w))
            clusters.append({
                "label": label,
                "keywords": sorted(words, key=lambda w: -weight_by_word.get(w, 0)),
                "words": len(words),
            })
        clusters.sort(key=lambda c: (-c["words"], c["label"]))
        return clusters[: self.max_clusters]

    # ------------------------------------------------------------------
    # 人物关注点
    # ------------------------------------------------------------------
    def _speaker_bucket(self, msg: Message) -> str:
        return "self" if msg.is_self() else "other"

    def _build_speaker_view(self, messages: List[Message],
                            per_message: List[Counter],
                            speaker_tf: Dict[str, Counter]) -> Dict[str, Any]:
        def top_for(bucket: str, limit: int = 5) -> List[Dict[str, Any]]:
            counter = speaker_tf.get(bucket, Counter())
            return [
                {"word": word, "count": count}
                for word, count in sorted(
                    counter.items(), key=lambda kv: (-kv[1], kv[0]))[:limit]
            ]

        result: Dict[str, Any] = {
            "self": top_for("self"),
            "other": top_for("other"),
        }
        self_words = {item["word"] for item in result["self"]}
        other_words = {item["word"] for item in result["other"]}
        result["shared"] = sorted(self_words & other_words)
        result["self_only"] = sorted(self_words - other_words)
        result["other_only"] = sorted(other_words - self_words)

        # 群聊：按真实昵称再拆一层（最多 5 人，避免报告被几十人群淹没）
        senders: Counter = Counter()
        per_sender: Dict[str, Counter] = defaultdict(Counter)
        for msg, counts in zip(messages, per_message):
            sender = (msg.sender or "").strip()
            if not sender or sender.lower() in _SYSTEM_SENDERS:
                continue
            if msg.is_self():
                continue
            senders[sender] += 1
            per_sender[sender].update(counts)
        # 群聊：按真实昵称再拆一层（最多 5 人，避免报告被几十人群淹没）。
        # 只有 1 个非 self 发送者时是 1:1 或"我+1人"，"成员拆分"没有信息量。
        result["members"] = [] if len(senders) < 2 else [
            {
                "sender": sender,
                "messages": senders[sender],
                "top_keywords": [
                    {"word": word, "count": count}
                    for word, count in sorted(
                        per_sender[sender].items(), key=lambda kv: (-kv[1], kv[0]))[:3]
                ],
            }
            for sender, _ in senders.most_common(5)
        ]
        return result

    # ------------------------------------------------------------------
    # 冷热变化
    # ------------------------------------------------------------------
    def _build_trend(self, messages: List[Message], per_message: List[Counter],
                     keywords: List[Dict[str, Any]]) -> Dict[str, Any]:
        half = len(messages) // 2
        if half == 0:
            return {"rising": [], "declining": [], "note": "消息太少，无法比较前后半段"}
        early: Counter = Counter()
        late: Counter = Counter()
        for idx, counts in enumerate(per_message):
            (early if idx < half else late).update(counts)

        rising, declining = [], []
        for item in keywords:
            word = item["word"]
            before, after = early[word], late[word]
            if after >= max(2, before + 2) and after >= before * 1.5:
                rising.append({"word": word, "before": before, "after": after})
            elif before >= max(2, after + 2) and before >= after * 1.5:
                declining.append({"word": word, "before": before, "after": after})
        return {
            "rising": rising[:5],
            "declining": declining[:5],
            "note": "按消息顺序对半拆分，不是按自然日",
        }

    # ------------------------------------------------------------------
    # 分段与话题切换
    # ------------------------------------------------------------------
    def _build_segments(self, messages: List[Message], per_message: List[Counter],
                        texts: List[str]) -> List[Dict[str, Any]]:
        ranges = self._segment_ranges(messages)
        segments: List[Dict[str, Any]] = []
        for start, end in ranges:
            local: Counter = Counter()
            for idx in range(start, end):
                local.update(per_message[idx])
            top = [
                {"word": word, "count": count}
                for word, count in sorted(local.items(), key=lambda kv: (-kv[1], kv[0]))[:3]
            ]
            first = messages[start]
            last = messages[end - 1]
            segments.append({
                "start_index": start,
                "end_index": end - 1,
                "messages": end - start,
                "start": first.timestamp.isoformat() if first.timestamp else None,
                "end": last.timestamp.isoformat() if last.timestamp else None,
                "top_keywords": top,
                "primary_topic": self._segment_topic(texts[start:end]),
            })
        return segments[:20]

    def _segment_ranges(self, messages: List[Message]) -> List[Tuple[int, int]]:
        ranges: List[Tuple[int, int]] = []
        start = 0
        gap_seconds = self.session_gap_hours * 3600
        for idx in range(1, len(messages)):
            prev_ts = messages[idx - 1].timestamp
            cur_ts = messages[idx].timestamp
            if prev_ts and cur_ts:
                if (cur_ts - prev_ts).total_seconds() > gap_seconds:
                    if idx - start >= 2:
                        ranges.append((start, idx))
                    start = idx
        if len(messages) - start >= 2:
            ranges.append((start, len(messages)))

        # 没有时间戳（或时间戳稀疏）时按消息数等分，保证仍然能看到话题演进
        if len(ranges) <= 1 and len(messages) >= 3 * self.min_segment_messages:
            chunk = max(self.min_segment_messages, len(messages) // 3)
            ranges = [(i, min(i + chunk, len(messages)))
                      for i in range(0, len(messages), chunk)]
            ranges = [(a, b) for a, b in ranges if b - a >= 2]
        return ranges

    def _segment_topic(self, texts: List[str]) -> str:
        counter: Counter = Counter()
        for name, hints in TOPIC_HINTS.items():
            hits = sum(1 for text in texts if any(h in text for h in hints))
            if hits:
                counter[name] = hits
        return counter.most_common(1)[0][0] if counter else "综合日常"

    def _topic_shifts(self, segments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        shifts: List[Dict[str, Any]] = []
        for prev, cur in zip(segments, segments[1:]):
            before = {item["word"] for item in prev.get("top_keywords", [])}
            after = {item["word"] for item in cur.get("top_keywords", [])}
            if not before or not after:
                continue
            overlap = len(before & after) / len(before | after)
            if overlap < 0.3:
                prev_top = (prev.get("top_keywords") or [{}])[0].get("word", "")
                cur_top = (cur.get("top_keywords") or [{}])[0].get("word", "")
                if not prev_top or not cur_top:
                    continue
                shifts.append({
                    "at": cur.get("start"),
                    "from": prev_top,
                    "to": cur_top,
                    "overlap": round(overlap, 2),
                })
        return shifts[:10]

    # ------------------------------------------------------------------
    # 摘要与置信度
    # ------------------------------------------------------------------
    def _confidence(self, message_count: int, total_terms: int, coverage: float) -> float:
        score = 40.0
        score += min(20.0, message_count * 1.2)
        score += min(15.0, total_terms * 0.15)
        score += coverage * 15.0 / 100.0
        if not HAS_JIEBA:
            score -= 12.0
        return round(max(15.0, min(90.0, score)), 1)

    def _summary(self, keywords: List[Dict[str, Any]],
                 topics: List[Dict[str, Any]],
                 by_speaker: Dict[str, Any],
                 trend: Dict[str, Any],
                 shifts: List[Dict[str, Any]]) -> List[str]:
        lines: List[str] = []
        words = [item["word"] for item in keywords[:5]]
        if words:
            lines.append("高频话题词：" + "、".join(words))
        if topics:
            lines.append(
                f"语义主题以「{topics[0]['name']}」为主"
                f"（{topics[0]['messages']} 条消息，{topics[0]['share']}%）")
        self_top = (by_speaker.get("self") or [{}])[0].get("word")
        other_top = (by_speaker.get("other") or [{}])[0].get("word")
        if self_top and other_top and self_top != other_top:
            lines.append(f"你更常聊「{self_top}」，对方更常聊「{other_top}」")
        if trend.get("rising"):
            lines.append("近期升温：" + "、".join(x["word"] for x in trend["rising"][:3]))
        if trend.get("declining"):
            lines.append("近期降温：" + "、".join(x["word"] for x in trend["declining"][:3]))
        if shifts:
            first = shifts[0]
            lines.append(f"话题切换 {len(shifts)} 次，最近一次从「{first['from']}」转向「{first['to']}」")
        if not HAS_JIEBA:
            lines.append("未安装 jieba，当前按内置词表最长匹配，未登录专名可能漏掉")
        return lines


# LOGGING_AND_COMMENTS_DECISIONS:
# 本模块不写日志：分析器由 AnalyzerRegistry 统一捕获异常并把失败写进
# AnalysisResult.metadata，模块内再打日志会重复且污染 MCP stdout 通道。
# 保留的分段注释只解释"为什么这样切/这样去重"（无 jieba 时的子串去重、
# 话题可重叠、前后半段按消息序而非自然日），不复述代码动作。
