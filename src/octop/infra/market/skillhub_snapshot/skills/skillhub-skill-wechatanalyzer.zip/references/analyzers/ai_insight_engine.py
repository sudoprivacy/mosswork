#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI 深度洞察引擎 v3.0.0 (ai_insight_engine.py)

在 v2.9.0 规则引擎 + LLM 增强的基础上，引入专业化的 AI 洞察模块：

核心能力：
1. AI 性格解读（基于 MBTI/大五结果，给出"为什么是这个人"的深度解读）
2. AI 情感轨迹叙事（把情感转折点编织成故事化的叙述）
3. AI 关系健康度建议（基于五维评分，给出具体可执行的改善建议）
4. AI 风险解读（基于风险类型，给出原因分析+应对策略）
5. AI 聊天预测解释（解释为什么对方可能这样回复）

设计原则：
1. 零依赖核心（urllib 标准库），可选 openai SDK
2. LLM 不可用时降级到模板化输出
3. 提示词模板与响应解析分离
4. 内置隐私保护（敏感内容脱敏后发送）
5. 调用结果缓存
"""

import json
import logging
import os
import re
import hashlib
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger(__name__)


# ============================================================================
# 1. LLM 配置
# ============================================================================

@dataclass
class LLMConfig:
    """LLM 配置。"""
    provider: str = "deepseek"
    base_url: str = "https://api.deepseek.com"
    model: str = "deepseek-chat"
    api_key: str = ""
    temperature: float = 0.5          # 聊天分析需要一定创造性
    max_tokens: int = 2000
    timeout: int = 60


# ============================================================================
# 2. LLM 客户端（OpenAI 兼容协议）
# ============================================================================

class LLMClient:
    """LLM HTTP 客户端（OpenAI Chat Completions 兼容）。"""

    def __init__(self, config: LLMConfig):
        self.config = config

    def chat(self, messages: List[Dict[str, str]],
             temperature: Optional[float] = None,
             max_tokens: Optional[int] = None) -> Dict[str, Any]:
        if not self.config.api_key and self.config.provider != "ollama":
            return {
                "success": False,
                "content": "",
                "error": f"未配置 {self.config.provider} API Key",
            }
        url = f"{self.config.base_url.rstrip('/')}/v1/chat/completions"
        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": max_tokens if max_tokens is not None else self.config.max_tokens,
            "stream": False,
        }
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"

        try:
            req = Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers=headers,
                method="POST",
            )
            with urlopen(req, timeout=self.config.timeout) as resp:
                body = resp.read().decode("utf-8")
                data = json.loads(body)

            if "choices" not in data or not data["choices"]:
                return {"success": False, "content": "", "error": "LLM 响应无 choices"}

            content = data["choices"][0].get("message", {}).get("content", "")
            # 剥离 <think>...</think> 标签（针对 DeepSeek R1 等）
            content = re.sub(r"<think>[\s\S]*?</think>\s*", "", content).strip()
            return {
                "success": True,
                "content": content,
                "usage": data.get("usage", {}),
                "model": data.get("model", self.config.model),
            }
        except HTTPError as e:
            err_body = ""
            try:
                err_body = e.read().decode("utf-8")[:300]
            except Exception:
                pass
            return {"success": False, "content": "", "error": f"HTTP {e.code}: {err_body}"}
        except URLError as e:
            return {"success": False, "content": "", "error": f"网络错误: {str(e)[:200]}"}
        except Exception as e:
            return {"success": False, "content": "", "error": f"调用异常: {str(e)[:200]}"}

    def is_available(self) -> bool:
        if self.config.provider == "ollama":
            return True
        return bool(self.config.api_key)


# ============================================================================
# 3. 配置加载
# ============================================================================

def load_llm_config(config_path: Optional[str] = None) -> LLMConfig:
    """从 config.json 加载 LLM 配置。"""
    config = LLMConfig()
    # 默认值
    config.provider = "deepseek"
    config.base_url = "https://api.deepseek.com"
    config.model = "deepseek-chat"

    # 环境变量优先
    env_provider = os.environ.get("LLM_PROVIDER")
    if env_provider:
        config.provider = env_provider
    env_key = os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("OPENAI_API_KEY") or os.environ.get("LLM_API_KEY")
    if env_key:
        config.api_key = env_key

    # 从 config.json 读取
    if config_path is None:
        candidates = [
            "config.json",
            "../config.json",
            "D:/claude 开发/skill of me/wechat-analyzer/config.json",
        ]
        for p in candidates:
            if os.path.isfile(p):
                config_path = p
                break

    if config_path and os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            llm_block = cfg.get("llm", {})
            if llm_block.get("enabled") and llm_block.get("api_key"):
                config.api_key = llm_block["api_key"]
                if llm_block.get("base_url"):
                    config.base_url = llm_block["base_url"]
                if llm_block.get("model"):
                    config.model = llm_block["model"]
                if isinstance(llm_block.get("temperature"), (int, float)):
                    config.temperature = float(llm_block["temperature"])
                if isinstance(llm_block.get("timeout"), int):
                    config.timeout = llm_block["timeout"]
        except Exception as e:
            logger.warning(f"加载 config.json 失败: {e}")

    # Provider 兜底
    if config.provider == "deepseek" and "deepseek" not in config.base_url:
        config.base_url = "https://api.deepseek.com"
    elif config.provider == "openai" and "openai" not in config.base_url:
        config.base_url = "https://api.openai.com"
    elif config.provider == "ollama":
        config.base_url = config.base_url or "http://localhost:11434"

    return config


# ============================================================================
# 4. 提示词模板（5 大洞察场景）
# ============================================================================

PROMPT_TEMPLATES = {
    "personality_insight": """你是专业的人格分析师。基于以下 MBTI/大五人格测试结果，给出有深度的解读。

【MBTI 结果】
类型：{mbti_type}
置信度：{mbti_confidence}%
维度得分：{dimension_scores}

【大五人格（OCEAN）】
开放性：{openness}%
尽责性：{conscientiousness}%
外向性：{extraversion}%
宜人性：{agreeableness}%
神经质：{neuroticism}%

【关键聊天样本】
{key_messages}

请按以下结构输出（每段 ≤150 字）：
1. **核心人格画像**（用 2-3 句话勾勒这个人的核心特质）
2. **MBTI 解读**（为什么是这个类型？引用聊天证据）
3. **大五亮点**（最突出的 1-2 个维度 + 对日常行为的影响）
4. **潜在盲点**（这个人容易在哪些方面出问题）
5. **沟通建议**（与这类人交流的最佳方式）

注意：分析仅供参考，不构成专业心理学评估。
""",

    "emotion_narrative": """你是情感叙事专家。基于以下情感分析数据，把情绪变化编织成有温度的故事。

【情感统计】
整体基调：{overall_tone}
正面消息占比：{positive_pct}%
负面消息占比：{negative_pct}%
己方正面：{self_positive}%
己方负面：{self_negative}%

【情感转折点】
{turning_points}

【聊天时间线摘要】
{timeline_summary}

请按以下结构输出（每段 ≤150 字）：
1. **情感弧线**（一句话概括这段对话的情感走向）
2. **关键转折**（最重要的1-2个转折点，发生了什么导致情绪变化）
3. **双方状态**（各自当下的情感状态推测）
4. **隐藏信号**（表面看不到但可能存在的情感暗流）
5. **温暖寄语**（给双方的一段温暖的话）

注意：分析仅供参考，保护当事人隐私。
""",

    "relationship_advice": """你是亲密关系咨询师。基于以下关系健康度评估，给出具体可执行的改善建议。

【五维评分】（满分100）
互动平衡：{balance_score}/100（{balance_desc}）
回应度：{responsiveness_score}/100（{responsiveness_desc}）
情感同步：{sync_score}/100（{sync_desc}）
投入度：{investment_score}/100（{investment_desc}）
互动深度：{depth_score}/100（{depth_desc}）

【综合评级】{overall_rating}

【关系类型推测】{relationship_type}

【关键聊天样本】
{key_messages}

请按以下结构输出（每段 ≤150 字）：
1. **核心诊断**（当前关系最突出的1个优势和1个风险）
2. **失衡分析**（哪一维最需要改善 + 为什么）
3. **具体建议**（3-5条可执行的改善动作，按优先级排序）
4. **沟通模式**（什么样的互动模式最有利于这段关系）
5. **预警信号**（需要警惕的关系恶化信号）

注意：仅供学习参考，不构成专业心理咨询。
""",

    "risk_interpretation": """你是风险分析专家。基于以下风险检测结果，给出原因解读和应对策略。

【风险类型】{risk_type}
风险等级：{risk_level}
置信度：{confidence}%

【风险触发证据】
{evidence}

【上下文】
{context}

请按以下结构输出（每段 ≤150 字）：
1. **风险本质**（这个风险类型的典型特征）
2. **证据解读**（为什么这些聊天内容触发了该风险）
3. **可能意图**（对方的潜在动机分析）
4. **应对策略**（3条具体应对话术或行动建议）
5. **后续观察**（需要持续观察的1-2个信号）

注意：分析仅供参考。如遇疑似诈骗等情况，请优先联系警方或专业机构。
""",

    "prediction_explanation": """你是沟通心理学专家。基于以下对话预测结果，解释对方为什么可能这样回复。

【对方性格画像】{other_personality}

【预测回复】
{predicted_reply}

【预测置信度】{confidence}%

【备选风格】{alternative_styles}

【最近聊天上下文】
{recent_context}

请按以下结构输出（每段 ≤150 字）：
1. **心理动因**（对方为什么可能这样回复，1-2个核心动机）
2. **性格线索**（从对方的语言风格看出哪些性格特征）
3. **风险提示**（这个回复可能带来的3种后续走向）
4. **替代选择**（除了预测的回复，还有哪1-2种可能及应对）
5. **实用话术**（如果你想引导对话朝某个方向走，建议的回应）

注意：分析仅供参考，沟通的实际结果受多方因素影响。
""",
}


# ============================================================================
# 5. AI 洞察引擎
# ============================================================================

@dataclass
class InsightResult:
    """AI 洞察结果。"""
    insight_type: str
    success: bool = False
    content: str = ""
    error: str = ""
    model: str = ""
    tokens_used: int = 0
    latency_ms: float = 0.0
    is_fallback: bool = False
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.strftime("%Y-%m-%dT%H:%M:%S")


class AIInsightEngine:
    """AI 洞察引擎主类。"""

    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or load_llm_config()
        self.client = LLMClient(self.config)
        self._cache: Dict[str, InsightResult] = {}
        self._cache_lock = threading.Lock()

    def is_available(self) -> bool:
        return self.client.is_available()

    def status(self) -> Dict[str, Any]:
        return {
            "provider": self.config.provider,
            "model": self.config.model,
            "base_url": self.config.base_url,
            "available": self.is_available(),
            "api_key_configured": bool(self.config.api_key),
        }

    def _cache_key(self, insight_type: str, context: Dict[str, Any]) -> str:
        ctx_str = json.dumps(context, sort_keys=True, ensure_ascii=False)
        return hashlib.md5(f"{insight_type}:{ctx_str}".encode("utf-8")).hexdigest()

    def _format_prompt(self, insight_type: str, context: Dict[str, Any]) -> str:
        template = PROMPT_TEMPLATES.get(insight_type)
        if not template:
            raise ValueError(f"未知洞察类型: {insight_type}")
        try:
            return template.format(**context)
        except KeyError as e:
            missing = e.args[0]
            logger.warning(f"提示词模板缺少字段: {missing}")
            context.setdefault(missing, "N/A")
            return template.format(**context)

    def _sanitize_chat_content(self, messages_text: str, max_len: int = 4000) -> str:
        """对聊天内容做隐私脱敏，限制长度以避免 token 爆炸。"""
        # 截断到 max_len
        if len(messages_text) > max_len:
            messages_text = messages_text[:max_len] + "\n...(已截断)..."
        # 简单脱敏：身份证（先匹配 18 位避免被手机号误判）→ 手机号 → 银行卡
        messages_text = re.sub(r"\d{17}[\dXx]", "[身份证]", messages_text)
        messages_text = re.sub(r"1[3-9]\d{9}", "[手机号]", messages_text)
        messages_text = re.sub(r"\d{16,19}", "[银行卡]", messages_text)
        return messages_text

    def generate(self, insight_type: str, context: Dict[str, Any],
                 use_cache: bool = True) -> InsightResult:
        """生成 AI 洞察。"""
        # 脱敏聊天内容
        for key in list(context.keys()):
            if "chat" in key.lower() or "message" in key.lower():
                if isinstance(context[key], str):
                    context[key] = self._sanitize_chat_content(context[key])

        cache_key = self._cache_key(insight_type, context)
        if use_cache:
            with self._cache_lock:
                if cache_key in self._cache:
                    return self._cache[cache_key]

        # 不可用时降级
        if not self.is_available():
            fallback = self._fallback_template(insight_type, context)
            result = InsightResult(
                insight_type=insight_type,
                success=True,
                content=fallback,
                is_fallback=True,
                error="LLM 不可用，已使用模板化输出",
            )
            if use_cache:
                with self._cache_lock:
                    self._cache[cache_key] = result
            return result

        # 格式化提示词
        try:
            prompt = self._format_prompt(insight_type, context)
        except Exception as e:
            return InsightResult(
                insight_type=insight_type,
                success=False,
                error=f"格式化提示词失败: {e}",
            )

        # 调用 LLM
        start = time.monotonic()
        response = self.client.chat([
            {"role": "system", "content": "你是中国本土的聊天分析专家，输出专业、温暖、有洞察力。结尾必须包含免责说明。"},
            {"role": "user", "content": prompt},
        ])
        latency = (time.monotonic() - start) * 1000

        if not response["success"]:
            fallback = self._fallback_template(insight_type, context)
            result = InsightResult(
                insight_type=insight_type,
                success=True,
                content=fallback,
                is_fallback=True,
                error=f"LLM 调用失败: {response['error']}",
                latency_ms=latency,
            )
        else:
            content = response["content"] + "\n\n---\n⚠️ 免责声明：本洞察由 AI 生成，仅供学习参考，不构成专业心理咨询或法律意见。"
            result = InsightResult(
                insight_type=insight_type,
                success=True,
                content=content,
                model=response.get("model", self.config.model),
                tokens_used=response.get("usage", {}).get("total_tokens", 0),
                latency_ms=latency,
            )

        if use_cache:
            with self._cache_lock:
                self._cache[cache_key] = result
        return result

    def _fallback_template(self, insight_type: str, context: Dict[str, Any]) -> str:
        """LLM 不可用时的模板化输出。"""
        parts = [
            f"📊 **{insight_type.upper()} 洞察报告（规则引擎版）**",
            "=" * 60,
            "",
            "⚠️ AI 深度洞察未启用（请配置 LLM API Key 启用深度解读）",
            "",
            "【关键数据汇总】",
        ]
        for k, v in context.items():
            v_str = str(v)
            if len(v_str) > 200:
                v_str = v_str[:200] + "..."
            parts.append(f"- {k}: {v_str}")
        parts.extend([
            "",
            "📌 说明：当前输出为规则引擎汇总，未含 AI 深度解读。",
            "📌 配置方法：设置环境变量 DEEPSEEK_API_KEY 或在 config.json 中填写 llm.api_key。",
        ])
        return "\n".join(parts)

    def clear_cache(self):
        with self._cache_lock:
            self._cache.clear()


# ============================================================================
# 6. 全局实例
# ============================================================================

_engine: Optional[AIInsightEngine] = None
_engine_lock = threading.Lock()


def get_engine(config_path: Optional[str] = None) -> AIInsightEngine:
    """获取全局引擎（单例）。"""
    global _engine
    with _engine_lock:
        if _engine is None:
            config = load_llm_config(config_path)
            _engine = AIInsightEngine(config)
        return _engine


def reset_engine():
    """重置全局引擎（用于测试）。"""
    global _engine
    with _engine_lock:
        _engine = None


def generate_insight(insight_type: str, context: Dict[str, Any], **kwargs) -> InsightResult:
    """便捷函数。"""
    return get_engine().generate(insight_type, context, **kwargs)


# ============================================================================
# 6.5 分析结果 → 洞察上下文（v5.0.0）
#
# v3.0.0 交付时这一层是缺的：引擎和 5 个模板都写好了，但没人把分析器结果
# 翻译成模板变量，所以 CLI 和 HTML 报告里一个字都看不到，纯死代码。
# ============================================================================

INSIGHT_ORDER = (
    "personality_insight",
    "emotion_narrative",
    "relationship_advice",
    "risk_interpretation",
    "prediction_explanation",
)

# 每个洞察依赖哪个分析器；缺了就整条跳过，
# 而不是把 "N/A" 塞进 prompt 让模型编一段人格分析出来。
_INSIGHT_REQUIREMENTS = {
    "personality_insight": ("mbti",),
    "emotion_narrative": ("sentiment",),
    "relationship_advice": ("relationship",),
    "risk_interpretation": ("risk",),
    "prediction_explanation": (),
}

# 上下文构造返回 None 时的解释。predict 类洞察的输入不在分析器里，
# 光说"证据不足"用户不知道该补什么。
_INSIGHT_SKIP_HINTS = {
    "prediction_explanation": "缺少预测结果，请先跑 predict-v2 或 predict_reply",
}


def _details(results: Dict[str, Any], name: str) -> Optional[Dict[str, Any]]:
    entry = (results or {}).get(name)
    if not isinstance(entry, dict):
        return None
    details = entry.get("details") or {}
    if "error" in details or not details:
        return None
    return details


def _truncate(text: str, limit: int = 1200) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else text[:limit] + "\n…（内容过长已截断）"


def mask_for_llm(messages_text: str, config: Optional[Dict[str, Any]] = None) -> str:
    """送云端之前做可逆 PII 脱敏。

    引擎内部自带的正则只覆盖手机/身份证/银行卡，邮箱、住址、真实姓名、
    API 密钥这类会在隐私扫描器里命中的内容不在其中，所以先用
    PrivacyScanner.mask_text 过一遍，engine.generate 再兜一层。
    """
    if not messages_text:
        return messages_text
    cfg = (config or {}).get("privacy_scan", {})
    if not cfg.get("enabled", True) or not cfg.get("mask_before_llm", True):
        return messages_text
    try:
        from analyzers.privacy_scanner import mask_text
    except ImportError:
        from privacy_scanner import mask_text
    try:
        masked, _mapping = mask_text(messages_text)
        return masked
    except Exception as e:  # noqa: BLE001 - 脱敏失败时宁可不发，也不能裸发原文
        logger.warning(f"LLM 脱敏失败，改为发送占位文本: {e}")
        return "[隐私保护：本次分析未向云端提供聊天原文]"


def build_insight_context(insight_type: str,
                         results: Dict[str, Any],
                         messages_text: str = "",
                         extra: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """把 AnalysisResult.to_dict() 组成的字典翻译成提示词变量。

    Returns:
        上下文 dict；当必需的分析器结果缺失时返回 None（调用方应跳过该洞察）。
    """
    extra = extra or {}
    key_messages = _truncate(extra.get("messages_text", messages_text))

    if insight_type == "personality_insight":
        mbti = _details(results, "mbti")
        if not mbti or mbti.get("type") in (None, "", "未知"):
            return None
        big = _details(results, "bigfive") or {}
        dims = big.get("dimensions") or {}
        context = {
            "mbti_type": mbti.get("type", "未知"),
            "mbti_confidence": round(float((results.get("mbti") or {}).get("confidence", 0)), 1),
            "dimension_scores": json.dumps(mbti.get("dimension_scores") or {}, ensure_ascii=False),
            "key_messages": key_messages or "（未提供样本）",
        }
        for key in ("openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"):
            context[key] = (dims.get(key) or {}).get("score", "未知")
        return context

    if insight_type == "emotion_narrative":
        sent = _details(results, "sentiment")
        if not sent:
            return None
        tone_map = {"up": "整体偏正向", "down": "整体偏负面", "stable": "整体平稳"}
        tps = sent.get("turning_points") or []
        lines = []
        for tp in tps[:5]:
            ts = (tp.get("timestamp") or "时间未知")[:16].replace("T", " ")
            arrow = "转好" if tp.get("direction") == "up" else "转差"
            lines.append(f"- {ts} {arrow}（分值 {tp.get('delta', 0)}）")
        return {
            "overall_tone": tone_map.get(sent.get("trend", "stable"), "整体平稳"),
            "positive_pct": sent.get("positive", 0),
            "negative_pct": sent.get("negative", 0),
            "self_positive": (sent.get("self_positive") if sent.get("self_positive") is not None else 0),
            "self_negative": (sent.get("self_negative") if sent.get("self_negative") is not None else 0),
            "turning_points": "\n".join(lines) or "（未检出明显转折）",
            "timeline_summary": key_messages or "（未提供时间线）",
        }

    if insight_type == "relationship_advice":
        rel = _details(results, "relationship")
        if not rel or "health_score" not in rel:
            return None
        dims = rel.get("dimensions") or {}
        group = _details(results, "group") or {}
        desc_map = {
            "balance": "双方发起与发言是否对等",
            "responsiveness": "回复速度与是否被冷落",
            "emotional_sync": "情绪起伏是否同步",
            "engagement": "投入篇幅与互动密度",
            "depth": "话题是否超越日常寒暄",
        }
        context = {
            "overall_rating": f"{rel.get('health_score', 0)} 分（{rel.get('grade_label', '未知')}）",
            "relationship_type": "多人群聊，一对一指标仅供参考" if group.get("is_group") else "一对一对话",
            "key_messages": key_messages or "（未提供样本）",
        }
        for dim_key, slot in (("balance", "balance"), ("responsiveness", "responsiveness"),
                              ("emotional_sync", "sync"), ("engagement", "investment"),
                              ("depth", "depth")):
            value = dims.get(dim_key)
            context[f"{slot}_score"] = "未知" if value is None else round(float(value), 1)
            context[f"{slot}_desc"] = desc_map.get(dim_key, dim_key)
        return context

    if insight_type == "risk_interpretation":
        risk = _details(results, "risk")
        if not risk:
            return None
        risks = risk.get("risks") or {}
        picked = None
        for level_order in ("high", "medium", "low"):
            for rtype, data in risks.items():
                if (data or {}).get("level") == level_order:
                    picked = (rtype, data)
                    break
            if picked:
                break
        if not picked:
            return None
        rtype, data = picked
        return {
            "risk_type": rtype,
            "risk_level": data.get("level", "low"),
            "confidence": round(float(risk.get("risk_score", 0) or 0), 1),
            "evidence": "、".join(data.get("matched_keywords") or []) or "（无关键词证据）",
            "context": data.get("description") or _truncate(messages_text, 600) or "（未提供上下文）",
        }

    if insight_type == "prediction_explanation":
        if not extra.get("predicted_reply"):
            return None
        return {
            "other_personality": extra.get("other_personality", "未知"),
            "predicted_reply": extra.get("predicted_reply", ""),
            "confidence": extra.get("confidence", 0),
            "alternative_styles": extra.get("alternative_styles", "（无备选）"),
            "recent_context": _truncate(extra.get("recent_context", messages_text), 800) or "（无上下文）",
        }

    return None


def attach_insights(results: Dict[str, Any],
                    config: Optional[Dict[str, Any]] = None,
                    messages_text: str = "",
                    engine: Optional[AIInsightEngine] = None,
                    types: Optional[List[str]] = None,
                    extra: Optional[Dict[str, Any]] = None) -> Dict[str, Dict[str, Any]]:
    """按需生成洞察并返回可序列化的结果字典（供 CLI 打印与 HTML 报告渲染）。

    永不抛异常：AI 是增强项，任何一步失败都不能让本地分析白跑。
    """
    cfg = config or {}
    ai_cfg = cfg.get("ai_insight", {})
    if not ai_cfg.get("enabled", True):
        return {}
    wanted = list(types) if types else list(INSIGHT_ORDER)
    out: Dict[str, Dict[str, Any]] = {}
    active = engine or get_engine()
    masked_text = mask_for_llm(messages_text, cfg)
    for insight_type in wanted:
        if insight_type not in PROMPT_TEMPLATES:
            continue
        if not ai_cfg.get(insight_type, True):
            continue
        missing = [n for n in _INSIGHT_REQUIREMENTS.get(insight_type, ())
                   if _details(results, n) is None]
        if missing:
            out[insight_type] = {"skipped": True,
                                 "reason": f"缺少分析结果：{', '.join(missing)}"}
            continue
        try:
            context = build_insight_context(insight_type, results, masked_text, extra)
        except Exception as e:  # noqa: BLE001
            out[insight_type] = {"skipped": True, "reason": f"上下文构造失败: {e}"}
            continue
        if context is None:
            out[insight_type] = {
                "skipped": True,
                "reason": _INSIGHT_SKIP_HINTS.get(
                    insight_type, "上游分析结果不足，未生成洞察"),
            }
            continue
        try:
            result = active.generate(insight_type, context)
        except Exception as e:  # noqa: BLE001
            out[insight_type] = {"skipped": True, "reason": f"生成失败: {e}"}
            continue
        out[insight_type] = {
            "skipped": False,
            "content": result.content,
            "success": result.success,
            "is_fallback": result.is_fallback,
            "model": result.model,
            "latency_ms": round(result.latency_ms, 1),
            "error": result.error,
        }
    return out


# ============================================================================
# 7. 自检
# ============================================================================

def self_check() -> Dict[str, Any]:
    """AI 洞察引擎自检（v5.0.0：版本号取自 core.version，不再写死；
    并真的跑一次上下文构造，验证分析器结果→提示词这条链是通的）。"""
    try:
        from core.version import __version__ as core_version
    except ImportError:
        core_version = "unknown"
    engine = get_engine()
    status = engine.status()
    probe_results = {
        "mbti": {"confidence": 71.0, "details": {"type": "INFJ", "dimension_scores": {"I": 4, "E": 1}}},
        "bigfive": {"details": {"dimensions": {"openness": {"score": 62.0}}}},
        "sentiment": {"details": {"positive": 40.0, "negative": 10.0, "trend": "up", "turning_points": []}},
        "relationship": {"details": {"health_score": 66.0, "grade_label": "良好", "dimensions": {"balance": 50.0}}},
        "risk": {"details": {"risk_score": 30.0, "risks": {"money": {"level": "medium", "matched_keywords": ["转账"], "description": "涉钱话题"}}}},
    }
    built = {t: build_insight_context(t, probe_results, "你好",
                                      {"predicted_reply": "好的", "confidence": 60}) is not None
             for t in INSIGHT_ORDER}
    return {
        "version": f"v{core_version}",
        "AIInsightEngine": "OK",
        "provider": status["provider"],
        "model": status["model"],
        "api_key_configured": status["api_key_configured"],
        "available": status["available"],
        "prompt_templates": list(PROMPT_TEMPLATES.keys()),
        "template_count": len(PROMPT_TEMPLATES),
        "context_builders": built,
        "context_build_ok": all(built.values()),
        "tip": "设置 DEEPSEEK_API_KEY 启用 AI 深度洞察" if not status["available"] else "AI 洞察引擎已就绪",
    }


if __name__ == "__main__":
    print(json.dumps(self_check(), ensure_ascii=False, indent=2))
