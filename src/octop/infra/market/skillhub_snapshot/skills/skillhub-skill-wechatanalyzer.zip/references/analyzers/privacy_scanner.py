"""
隐私泄露扫描器 v5.0.0

回答一个此前整个技能都没有覆盖的问题：**这段聊天记录里到底有多少能直接
定位到真人的信息**。微信导出/粘贴的对话里出现手机号、身份证号、银行卡号、
家庭住址是常态，而 v4.0.0 会把原文直接送进 AI 洞察模板（哪怕只是本地
脱敏后拼 prompt），也照原样印进 HTML 报告。

设计约束：
    - 纯本地、纯正则，不联网、不调模型。
    - 只报"检出了什么类型、几条、样例长什么样"，样例一律打码。
    - mask_text() 提供可还原的占位符映射，供 AI 洞察在送模型前脱敏、
      拿到结果后再还原。

规则顺序有讲究：身份证必须在银行卡之前、银行卡必须在手机号之前，
否则 18 位身份证会被 11 位连续数字的手机号规则先咬掉一段，
剩下 7 位谁也认不出来。
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from core.analyzer_base import AnalyzerBase
from core.message import Message
from core.result import AnalysisResult

ZH = "\u4e00-\u9fa5"


@dataclass
class Finding:
    """一条命中记录。"""
    ptype: str
    sample: str          # 已打码的样例，绝不存原文
    count: int = 1
    senders: List[str] = field(default_factory=list)


# (类型, 优先级, 风险档, 正则)
# 优先级数字小的先匹配，匹配到的区间会从后续扫描中挖掉。
_PATTERNS: List[Tuple[str, int, str, "re.Pattern[str]"]] = [
    # 显式密钥：先咬，否则里面的数字串会被当成手机号/卡号
    ("api_key", 0, "high", re.compile(
        r"(?i)\b(?:sk|pk|api|key|token|secret|password|passwd)-[A-Za-z0-9_\-]{8,}")),
    ("api_key", 0, "high", re.compile(
        r"(?i)(?:api[_\-]?key|secret[_\-]?key|access[_\-]?token|token|密码)\s*[:：=]\s*"
        r"[A-Za-z0-9_\-\.]{8,}")),
    # 18 位身份证（末位可为 X），含分段书写
    ("id_card", 1, "high", re.compile(
        r"(?<![0-9Xx])\d{6}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:[0-2]\d|3[01])\d{3}[0-9Xx](?![0-9Xx])")),
    # 16-19 位银行卡（允许 4 位分组）
    ("bank_card", 2, "high", re.compile(
        r"(?<!\d)(?:\d[ \-]?){15,18}\d(?!\d)")),
    # 手机号
    ("phone", 3, "medium", re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")),
    # 座机（带区号）
    ("landline", 3, "medium", re.compile(r"(?<!\d)0\d{2,3}[ \-]\d{7,8}(?!\d)")),
    ("email", 4, "medium", re.compile(
        r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")),
    # 显式标注的微信号
    # 显式标注的微信号（"微信号 xxx" 允许无分隔符）
    ("wechat_id", 5, "medium", re.compile(
        r"(?:微信号|微信id|weixinid|wx号)\s*[:：是为]?\s*[A-Za-z][-_A-Za-z0-9]{5,19}")),
    ("wechat_id", 5, "medium", re.compile(
        r"(?i)(?<![A-Za-z])(?:wx|vx|v信|weixin)\s*[:：是为]\s*[A-Za-z][-_A-Za-z0-9]{5,19}")),
    # 住址：显式引导词（必须带冒号/是/为，否则"地址你给我发一下"会误报）
    ("address", 6, "high", re.compile(
        r"(?:住址|地址|家住|收货地址|定位|寄到)\s*[:：是为]\s*[^，,。；;\n]{4,60}")),
    ("address", 6, "high", re.compile(
        rf"[\u4e00-\u9fa5]{{2,8}}(?:省|市|区|县)[\u4e00-\u9fa5A-Za-z0-9]{{2,20}}"
        rf"(?:路|街|道|巷|号|栋|幢|单元|层|室)[\u4e00-\u9fa5A-Za-z0-9\-]{{0,15}}")),
    # 真实姓名候选：只认显式声明。
    # v5.0.0 曾试过 "X老师/X经理" 这类称呼推断，但中文没有词边界，
    # "谢谢张老师" 会被整段当成姓名，既误报又在还原时把正文改花，已删除。
    ("real_name_candidate", 7, "low", re.compile(
        rf"(?:姓名|真实姓名|全名|联系人|收件人|签收人)\s*[:：是为]\s*[{ZH}]{{2,4}}")),
    ("real_name_candidate", 7, "low", re.compile(
        rf"(?:我叫|名字叫|我全名|本人)\s*[:：,，]?\s*[{ZH}]{{2,4}}")),
]

def _luhn_ok(value: str) -> bool:
    """Luhn 校验：银行卡号必过，过不了的长数字只是订单号。"""
    digits = re.sub(r"\D", "", value)
    if not digits:
        return False
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


Ptype_LABELS = {
    "api_key": "密钥/口令",
    "id_card": "身份证号",
    "bank_card": "银行卡号",
    "long_number": "长数字串",
    "phone": "手机号",
    "landline": "座机号",
    "email": "邮箱",
    "wechat_id": "微信号",
    "address": "地址/定位",
    "real_name_candidate": "疑似真实姓名",
}

RISK_LABELS = {"high": "高风险", "medium": "中风险", "low": "低风险"}


class PrivacyScanner(AnalyzerBase):
    """本地隐私泄露扫描。

    用法：
        scanner = PrivacyScanner(config)
        result = scanner.analyze(messages)          # 走注册中心
        report = scanner.scan(messages)             # 直接拿结构化结果
        masked, mapping = scanner.mask_text(raw)    # 送 AI 前脱敏
    """

    name = "privacy"
    version = "5.0.0"
    description = "本地检测聊天记录中的身份证/卡号/手机号/地址等可直接定位信息"

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(config)
        cfg = (config or {}).get("privacy_scan", {})
        self.warn_in_report = cfg.get("warn_in_report", True)
        # 默认关：这是隐私工具，宁可少给信息，也不能因为"忘了配"就把
        # （哪怕打码的）PII 片段复制进报告。要样例请显式 include_samples=true。
        self.include_samples = cfg.get("include_samples", False)
        self.max_samples_per_type = cfg.get("max_samples", 3)

    # ------------------------------------------------------------------
    # 基础 API
    # ------------------------------------------------------------------

    def validate(self, messages: List[Message]) -> bool:
        return any(m.has_content() and m.is_text() for m in messages)

    def scan_text(self, text: str) -> List[Tuple[str, str, int, int]]:
        """返回 [(ptype, 原文命中, start, end)]，同一区间只归入优先级最高的类型。"""
        if not text:
            return []

        hits: List[Tuple[int, int, str, str]] = []
        consumed: List[Tuple[int, int]] = []

        def is_overlapped(start: int, end: int) -> bool:
            return any(start < c_end and c_start < end for c_start, c_end in consumed)

        for ptype, _prio, _risk, pattern in sorted(_PATTERNS, key=lambda x: x[1]):
            for m in pattern.finditer(text):
                start, end = m.span()
                if is_overlapped(start, end):
                    continue
                # 16-19 位数字串的形态太宽，订单号/流水号都会撞进来。
                # 通不过 Luhn 就降级报成"长数字串"，不冒充银行卡号吓用户。
                if ptype == "bank_card" and not _luhn_ok(m.group(0)):
                    ptype = "long_number"
                hits.append((start, end, ptype, m.group(0)))
                consumed.append((start, end))

        return [(ptype, text[start:end], start, end)
                for start, end, ptype, _ in sorted(hits)]
    def scan(self, messages: List[Message]) -> Dict[str, Any]:
        """扫描整段对话，返回结构化报告。"""
        counters: Counter = Counter()
        samples: Dict[str, List[str]] = defaultdict(list)
        senders: Dict[str, set] = defaultdict(set)
        per_message: List[Dict[str, Any]] = []
        total = 0

        for msg in messages:
            if not msg.has_content() or not msg.is_text():
                continue
            msg_types: Counter = Counter()
            for ptype, raw_hit, _s, _e in self.scan_text(msg.content):
                counters[ptype] += 1
                msg_types[ptype] += 1
                senders[ptype].add(msg.sender)
                if self.include_samples and len(samples[ptype]) < self.max_samples_per_type:
                    samples[ptype].append(_obscure(raw_hit))
                total += 1
            if msg_types:
                per_message.append({
                    "sender": msg.sender,
                    "types": dict(msg_types),
                    "excerpt": _obscure(msg.content.strip()[:60]),
                })

        risk_by_type = {p[0]: p[2] for p in _PATTERNS}
        by_type = {}
        score_breakdown = {"high": 0, "medium": 0, "low": 0}
        for ptype, count in counters.items():
            risk = risk_by_type.get(ptype, "low")
            score_breakdown[risk] += count
            by_type[ptype] = {
                "label": Ptype_LABELS.get(ptype, ptype),
                "count": count,
                "risk": risk,
                "risk_label": RISK_LABELS[risk],
                "senders": sorted(senders[ptype])[:5],
                "samples": samples.get(ptype, []),
            }

        # 加权风险分：高危命中一条就值得被看见
        score = min(100.0, score_breakdown["high"] * 30
                    + score_breakdown["medium"] * 12 + score_breakdown["low"] * 4)
        level = "none"
        if score_breakdown["high"]:
            level = "high"
        elif score_breakdown["medium"]:
            level = "medium"
        elif score_breakdown["low"]:
            level = "low"

        return {
            "total_hits": total,
            "level": level,
            "by_type": by_type,
            "breakdown": score_breakdown,
            "score": round(score, 1),
            "affected_messages": per_message[:20],
        }

    def mask_text(self, text: str) -> Tuple[str, Dict[str, str]]:
        """把命中项替换成可还原占位符。

        返回 (脱敏文本, {占位符: 原文})。占位符形如 [手机号1]，
        刻意用中文类型名而不是随机 token：模型若在回复里引用占位符，
        还原后用户看到的仍是可读的类别名。
        """
        if not text:
            return text, {}

        hits = self.scan_text(text)
        if not hits:
            return text, {}

        seq: Counter = Counter()
        mapping: Dict[str, str] = {}
        out: List[str] = []
        cursor = 0
        for ptype, raw_hit, start, end in hits:
            seq[ptype] += 1
            label = Ptype_LABELS.get(ptype, ptype)
            placeholder = f"[{label}{seq[ptype]}]"
            out.append(text[cursor:start])
            out.append(placeholder)
            mapping[placeholder] = raw_hit
            cursor = end
        out.append(text[cursor:])
        return "".join(out), mapping

    def unmask_text(self, text: str, mapping: Dict[str, str]) -> str:
        """还原文本中的占位符（AI 回复落地前调用）。"""
        if not text or not mapping:
            return text
        for placeholder, original in mapping.items():
            text = text.replace(placeholder, original)
        return text

    # ------------------------------------------------------------------
    # 注册中心接口
    # ------------------------------------------------------------------

    def analyze(self, messages: List[Message], **kwargs) -> AnalysisResult:
        report = self.scan(messages)
        total_hits = report["total_hits"]
        # 置信度：扫过的有内容消息越多，"没问题"这个结论才越可信
        scanned = sum(1 for m in messages if m.has_content() and m.is_text())
        confidence = min(95.0, 40.0 + scanned * 1.5) if total_hits == 0 else \
            min(98.0, 70.0 + scanned * 0.8)

        summary = _build_summary(report)
        details = dict(report)
        details["summary"] = summary
        details["scanned_messages"] = scanned

        return AnalysisResult(
            analyzer_name=self.name,
            score=report["score"],
            confidence=round(confidence, 1),
            details=details,
            metadata={
                "analyzer": "PrivacyScanner",
                "version": self.version,
                "local_only": True,
                "warn_in_report": self.warn_in_report,
            },
        )


def _obscure(value: str) -> str:
    """样例打码：保留首尾各 2 个字符，中间固定 4 个星。"""
    cleaned = " ".join(value.split())
    if len(cleaned) <= 4:
        return cleaned[:1] + "*" * max(1, len(cleaned) - 1)
    return f"{cleaned[:2]}****{cleaned[-2:]}"


def _build_summary(report: Dict[str, Any]) -> str:
    if not report["total_hits"]:
        return "未发现可直接定位到个人的敏感信息。"
    parts = []
    for ptype, info in sorted(report["by_type"].items(),
                              key=lambda kv: -kv[1]["count"]):
        parts.append(f"{info['label']}×{info['count']}")
    return f"检出 {report['total_hits']} 处敏感信息（{', '.join(parts)}），" \
        f"整体{RISK_LABELS.get(report['level'], '无')}。"


def scan_messages(messages: List[Message], config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """便捷入口：一次扫描拿结构化报告。"""
    return PrivacyScanner(config).scan(messages)


def mask_text(text: str, config: Optional[Dict[str, Any]] = None) -> Tuple[str, Dict[str, str]]:
    """便捷入口：脱敏单条文本。"""
    return PrivacyScanner(config).mask_text(text)


if __name__ == "__main__":
    import json

    demo = [
        Message(sender="张三", content="我身份证 110101199003074512，你帮我登记一下"),
        Message(sender="我", content="好的，卡号 4111 1111 1111 1111"),
        Message(sender="李四", content="手机号13812345678，微信号 zhangsan_2020"),
        Message(sender="王五", content="住北京市朝阳区建国路88号SOHO现代城A座1201"),
        Message(sender="我", content="api_key: sk-abcd1234efgh5678 记得别外传"),
        Message(sender="张三", content="我叫刘梅，邮箱 liumei@example.com"),
    ]
    scanner = PrivacyScanner()
    print(json.dumps(scanner.scan(demo), ensure_ascii=False, indent=2))
    for m in demo:
        masked, mapping = scanner.mask_text(m.content)
        if mapping:
            print(f"{m.content}\n  -> {masked}\n  {mapping}")
