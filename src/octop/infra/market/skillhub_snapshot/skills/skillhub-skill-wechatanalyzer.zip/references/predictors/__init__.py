"""
预测器集合 v4.0.0

四层融合预测：
    - RulePredictor: 基于 MBTI + 场景 + 关键词 + N-gram 的规则预测
    - RAGPredictor: 基于历史相似对话的检索增强预测
    - MiroFishPredictor: 多智能体博弈模拟预测
    - HistoryAwarePredictor: 从用户真实回复中学习个性化模式

通过 EnsemblePredictor 动态加权融合（v4.0.0 置信度自适应权重）。
"""

import sys
import logging

sys.dont_write_bytecode = True

log = logging.getLogger("wechat_analyzers.predictors")

from core.predictor_base import PredictorBase, PredictionContext
from core.result import PredictionResult, Prediction
from core.version import __version__ as _PKG_VERSION
from predictors.rule_predictor import RulePredictor
from predictors.rag_predictor import RAGPredictor
from predictors.mirofish_predictor import MiroFishPredictor
from predictors.history_aware_predictor import HistoryAwarePredictor
from predictors.ensemble import EnsemblePredictor


# v5.0.0：版本号一律取自 core.version
__version__ = _PKG_VERSION


def _add_when_available(ensemble: "EnsemblePredictor", factory, label: str) -> None:
    """构造并注册一个预测器；不可用时降级跳过，但必须留下日志。

    v4.0.0 这里是 `except Exception: pass`，结果 RAG / 历史感知装不上时
    表面上一切正常，只是预测永远只有规则层那点结果，没有任何线索指向原因。
    """
    try:
        ensemble.add_predictor(factory())
    except Exception as e:
        log.warning(f"{label} 预测器未启用: {type(e).__name__}: {e}")


def create_default_ensemble(config: dict = None) -> EnsemblePredictor:
    """创建默认的集成预测器

    Args:
        config: 配置字典

    Returns:
        EnsemblePredictor
    """
    cfg = config or {}
    predictor_cfg = cfg.get("conversation_predictor", {})

    ensemble = EnsemblePredictor(config=cfg)

    # 规则预测器：始终启用
    if predictor_cfg.get("enabled", True):
        _add_when_available(ensemble, lambda: RulePredictor(config=cfg), "规则")

    # RAG 预测器：如果 RAG 可用
    if cfg.get("rag", {}).get("enabled", True):
        _add_when_available(ensemble, lambda: RAGPredictor(config=cfg), "RAG")

    # MiroFish 预测器：仅在 mirofish.enabled = true
    if cfg.get("mirofish", {}).get("enabled", False):
        _add_when_available(ensemble, lambda: MiroFishPredictor(config=cfg), "MiroFish")

    # 历史感知预测器：v4.0.0 新增，始终尝试添加
    _add_when_available(ensemble, lambda: HistoryAwarePredictor(config=cfg), "历史感知")

    return ensemble


__all__ = [
    "PredictorBase",
    "PredictionContext",
    "PredictionResult",
    "Prediction",
    "RulePredictor",
    "RAGPredictor",
    "MiroFishPredictor",
    "HistoryAwarePredictor",
    "EnsemblePredictor",
    "create_default_ensemble",
]
