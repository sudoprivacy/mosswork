"""版本号单一来源（v2.5.0 新增）。

此前版本号散落在 SKILL.md / config.json / main.py / 报告生成器等
十余处，升级时经常漏改（v2.4.0 时 config.json 仍显示 2.3.0）。
CLI 输出、JSON 导出、HTML 报告统一从这里读取。

用法：
    from core.version import __version__

v5.0.0：`analyzers`、`predictors` 两个包的 __version__ 与 mcp_server 的
VERSION 改为从这里取，不再各自硬编码（此前 analyzers/__init__.py 停在 2.9.0、
mcp_server 停在 4.0.0，`get_skill_status` 报的版本与 SKILL.md 不一致）。
v6.0.0：新增话题地图分析器；MCP Server 兼容 mcp 1.x(FastMCP)/2.x(MCPServer)。
"""

__version__ = "6.0.0"
