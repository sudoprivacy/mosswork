"""
历史感知预测器 v5.0.0

从用户真实回复中学习个性化模式，生成"听起来像你说的"预测回复。

核心思路：
- 传统规则预测器用通用模板（"嗯嗯"、"好的"），千人一面
- 本预测器分析你历史上的真实回复，提取：
  1. 高频回复短语（你最常说的 2-30 字短句）
  2. 回复风格特征（平均长度、标点偏好、emoji习惯）
  3. 上下文-回复对（对方说了X，你通常回Y）
  4. 情感-回复映射（对方情绪好/差时，你的回复差异）
  5. 时段-回复映射（早上/下午/晚上，你的回复风格变化）

技术：
- N-gram 语言模型（bigram/trigram 频率统计）
- 条件频率分布（给定对方消息特征，统计我方回复模式）
- 风格特征向量（长度/标点/emoji/词汇丰富度）
- 滑动窗口权重衰减（近期回复权重更高）

完全本地化，零外部依赖。
"""

import json
import logging
import math
import os
import tempfile
from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from core.predictor_base import PredictorBase, PredictionContext
from core.result import PredictionResult, Prediction
from core.utils import tokenize, normalize_for_compare, HAS_JIEBA

logger = logging.getLogger(__name__)

# v5.0.0：按时间排序时缺时间戳的消息必须落到同类型的最小值。
# 之前 key 用 `m.timestamp if m.timestamp else ""` 混合了 datetime 与 str，
# 只要一个会话里既有带时间戳又有不带时间戳的消息，sorted() 就直接 TypeError；
# 而 MCP 解析出的消息全部没有 timestamp，等于永远走字符串分支、保持原序。
_NO_TIMESTAMP = datetime.min


def _sort_key(msg) -> datetime:
    ts = getattr(msg, "timestamp", None)
    return ts if isinstance(ts, datetime) else _NO_TIMESTAMP


def default_profile_path(config: dict = None) -> str:
    """历史画像文件的统一落点，返回空串表示不持久化。

    CLI 与 MCP 共用这一条规则，免得两边各写一份后路径行为漂移。config 里的
    相对路径（如 profiles/history_aware.json）一律忽略：画像必须落在运行时
    数据目录，不能生成在技能包内。
    """
    cfg = config or {}
    history_cfg = cfg.get("history_aware", {}) or {}
    if history_cfg.get("persist_profile", True) is False:
        return ""
    if cfg.get("session_memory", {}).get("history_aware_persistence") is False:
        return ""
    configured = history_cfg.get("profile_file", "")
    if configured and os.path.isabs(configured):
        return configured
    from core.data_paths import resolve_data_dir
    return str(resolve_data_dir() / "history_profile.json")


class HistoryAwarePredictor(PredictorBase):
    """历史感知预测器（v4.0.0 个性化回复预测）"""

    name = "history_aware"
    version = "5.0.0"
    weight = 0.25  # 在集成中权重 25%
    description = "从用户历史回复中学习个性化模式，生成像用户本人说的回复"

    # 停用短语（太通用、信息量低的回复）
    STOP_PHRASES = {
        "嗯", "嗯嗯", "哦", "好的", "好", "行", "可以", "ok", "OK",
        "知道了", "是的", "对", "不是", "没有", "嗯好",
    }

    def __init__(self, config: dict = None):
        super().__init__(config)
        cfg = (config or {}).get("history_aware", {})
        self.min_history = cfg.get("min_history", 10)
        self.ngram_max = cfg.get("ngram_max", 3)
        self.top_phrases = cfg.get("top_phrases", 50)
        self.decay_factor = cfg.get("decay_factor", 0.95)  # 时间衰减系数
        self.min_phrase_freq = cfg.get("min_phrase_freq", 2)
        # v5.0.0：跨会话累积画像。关掉就退回"每次只学当前这批消息"。
        self.merge_history = cfg.get("merge_history", True)
        self.profile_file = cfg.get("profile_file", "")

        # 学到的模式
        self._phrase_freq: Counter = Counter()  # 短语频率
        self._bigram_freq: Dict[str, Counter] = defaultdict(Counter)  # 上下文→回复
        self._context_reply_pairs: List[Tuple[str, str]] = []  # (对方关键词, 我方回复)
        self._style_profile: Dict[str, Any] = {}  # 风格画像
        self._sentiment_reply_map: Dict[str, List[str]] = defaultdict(list)  # 情绪→回复
        self._time_reply_map: Dict[str, List[str]] = defaultdict(list)  # 时段→回复
        self._self_msgs: List[str] = []  # 我方消息列表
        self._other_msgs: List[str] = []  # 对方消息列表
        self._trained = False
        self._session_trained = False  # 本次这批消息是否已 train 过（载入画像不算）
        self._trained_sessions = 0  # 累计训练过几次会话（画像持久化后才 meaningful）
        self._seed_profile: Optional[Dict[str, Any]] = None  # 上次会话留下的画像
        self._available = True

    def is_available(self) -> bool:
        return self._available

    def train(self, messages: List) -> Dict[str, Any]:
        """从历史消息中学习模式。

        Args:
            messages: Message 对象列表

        Returns:
            训练统计信息
        """
        self_msgs = [m for m in messages if m.is_self() and m.has_content()]
        other_msgs = [m for m in messages if m.is_other() and m.has_content()]

        if len(self_msgs) < self.min_history:
            return {
                "trained": False,
                "reason": f"历史消息不足（{len(self_msgs)} < {self.min_history}）",
            }

        self._self_msgs = [m.content for m in self_msgs]
        self._other_msgs = [m.content for m in other_msgs]

        # 1. 提取高频短语
        self._extract_phrases(self._self_msgs)

        # 2. 学习上下文-回复对
        self._learn_context_reply_pairs(messages)

        # 3. 学习风格画像
        self._learn_style_profile(self_msgs)

        # 4. 学习情感-回复映射
        self._learn_sentiment_reply_map(messages)

        # 5. 学习时段-回复映射
        self._learn_time_reply_map(self_msgs)

        self._trained = True
        self._session_trained = True
        merged = self._merge_seed_profile()
        if not merged:
            # 关掉合并时，历史画像里的会话数并不代表本次模型学过什么，
            # 不能跟着继承过来，否则 trained_sessions 会虚高。
            base = self._trained_sessions if self.merge_history else 0
            self._trained_sessions = max(base, 1)
        stats = {
            "trained": True,
            "self_message_count": len(self_msgs),
            "other_message_count": len(other_msgs),
            "unique_phrases": len(self._phrase_freq),
            "context_reply_pairs": len(self._context_reply_pairs),
            "style_profile": self._style_profile,
            "trained_sessions": self._trained_sessions,
        }
        if merged:
            stats["merged_history"] = merged
        return stats

    def _merge_seed_profile(self) -> Dict[str, int]:
        """把上一次会话持久化下来的画像并进本次结果。

        5 个学习器都是 clear() 后重建的，所以必须在重建之后合并，
        否则"历史感知"每跑一次就忘一次。合并后清掉种子，避免同一进程内
        二次 train() 把历史算两遍。
        """
        seed = self._seed_profile
        if not seed or not self.merge_history:
            return {}
        self._seed_profile = None

        self._phrase_freq.update(Counter({str(k): int(v) for k, v in
                                         (seed.get("phrase_freq") or {}).items()}))
        for ctx, cnt in (seed.get("bigram_freq") or {}).items():
            self._bigram_freq[str(ctx)].update({str(k): int(v) for k, v in (cnt or {}).items()})

        existing = set(self._context_reply_pairs)
        for pair in seed.get("context_pairs") or []:
            if isinstance(pair, (list, tuple)) and len(pair) == 2 and tuple(pair) not in existing:
                self._context_reply_pairs.append(tuple(pair))
                existing.add(tuple(pair))

        for key, replies in (seed.get("sentiment_reply_map") or {}).items():
            self._sentiment_reply_map[str(key)].extend(list(replies or [])[-20:])
        for key, replies in (seed.get("time_reply_map") or {}).items():
            self._time_reply_map[str(key)].extend(list(replies or [])[-20:])

        self._self_msgs.extend(str(m) for m in (seed.get("self_msgs_tail") or []))
        self._trained_sessions = int(seed.get("trained_sessions") or 0) + 1
        if self._style_profile:
            self._style_profile["total_messages"] = (
                int(self._style_profile.get("total_messages", 0))
                + int((seed.get("style_profile") or {}).get("total_messages", 0)))
        return {"sessions_merged": int(seed.get("trained_sessions") or 0)}

    def predict(self, context: PredictionContext) -> PredictionResult:
        """基于历史模式预测回复。"""
        # 自动训练。条件是"本批消息还没学过"，不是"完全没有画像"——
        # 载入历史画像后 _trained 已为 True，若仍按旧条件判断，新会话就永远不会
        # 被 train()，累计次数停在 0，持久化等于白做。
        if not self._session_trained and context.messages:
            self.train(context.messages)

        if not self._trained:
            return self._fallback("untrained", context)

        predictions: List[Prediction] = []

        # 获取对方最后一条消息
        other_msgs = [m for m in context.messages if m.is_other() and m.has_content()]
        last_other = other_msgs[-1] if other_msgs else None
        last_content = last_other.content if last_other else ""

        # 1. 上下文匹配回复（最高优先级）
        ctx_predictions = self._predict_from_context(last_content)
        predictions.extend(ctx_predictions)

        # 2. 高频短语推荐
        phrase_predictions = self._predict_from_phrases(last_content)
        predictions.extend(phrase_predictions)

        # 3. 情感适配回复
        sentiment = (context.sentiment or {}).get("trend", "unknown")
        sentiment_predictions = self._predict_from_sentiment(sentiment)
        predictions.extend(sentiment_predictions)

        # 4. 时段适配回复
        time_predictions = self._predict_from_time()
        predictions.extend(time_predictions)

        # 5. 风格适配生成
        style_predictions = self._predict_from_style(last_content)
        predictions.extend(style_predictions)

        # 排序去重
        predictions = self._dedupe_and_rank(predictions)

        if not predictions:
            return self._fallback("no_predictions", context)

        top = predictions[0]
        alternatives = predictions[1:6]

        return PredictionResult(
            top_prediction=top,
            alternatives=alternatives,
            scenario=context.scenario,
            context={
                "mbti": context.mbti,
                "history_trained": self._trained,
                "phrase_count": len(self._phrase_freq),
                "context_pairs": len(self._context_reply_pairs),
            },
            metadata={
                "predictor": "HistoryAwarePredictor",
                "version": self.version,
                "total_candidates": len(predictions),
                "style_profile": self._style_profile,
            },
        )

    # ----------------------------------------------------------------
    # 训练方法
    # ----------------------------------------------------------------

    def _extract_phrases(self, self_msgs: List[str]):
        """提取高频回复短语。"""
        self._phrase_freq.clear()

        for msg in self_msgs:
            msg = msg.strip()
            if not msg:
                continue
            # 完整短句
            if msg not in self.STOP_PHRASES and len(msg) <= 30:
                self._phrase_freq[msg] += 1

            # N-gram 提取
            tokens = list(msg) if not HAS_JIEBA else tokenize(msg, use_jieba=True)
            for n in range(2, min(self.ngram_max + 1, len(tokens) + 1)):
                for i in range(len(tokens) - n + 1):
                    gram = "".join(tokens[i:i + n])
                    if 2 <= len(gram) <= 15 and gram not in self.STOP_PHRASES:
                        self._phrase_freq[gram] += 1

        # 按频率衰减排序
        for phrase in list(self._phrase_freq.keys()):
            if self._phrase_freq[phrase] < self.min_phrase_freq:
                del self._phrase_freq[phrase]

    def _learn_context_reply_pairs(self, messages: List):
        """学习上下文-回复对（对方消息→我方回复）。"""
        self._context_reply_pairs.clear()

        sorted_msgs = sorted(messages, key=_sort_key)
        prev_other = None

        for msg in sorted_msgs:
            if msg.is_other() and msg.has_content():
                prev_other = msg.content
            elif msg.is_self() and msg.has_content() and prev_other:
                # 提取对方消息的关键特征
                keywords = self._extract_keywords(prev_other)
                if keywords:
                    key = " ".join(keywords[:3])
                    self._context_reply_pairs.append((key, msg.content))
                    for kw in keywords:
                        self._bigram_freq[kw][msg.content] += 1
                prev_other = None

    def _learn_style_profile(self, self_msgs):
        """学习我方回复风格。"""
        if not self_msgs:
            return

        lengths = [len(m.content) for m in self_msgs if m.content]
        questions = sum(1 for m in self_msgs if "？" in m.content or "?" in m.content)
        exclamations = sum(1 for m in self_msgs if "！" in m.content or "!" in m.content)
        emojis = sum(1 for m in self_msgs if any(0x1F300 <= ord(c) <= 0x1FAFF for c in m.content))
        periods = sum(1 for m in self_msgs if m.content.rstrip().endswith(("。", ".", "！", "！")))

        avg_len = sum(lengths) / len(lengths) if lengths else 5
        # 用中位数更稳健
        sorted_lengths = sorted(lengths)
        median_len = sorted_lengths[len(sorted_lengths) // 2] if sorted_lengths else 5

        # 词汇丰富度（Type-Token Ratio）
        all_tokens = []
        for m in self_msgs:
            if m.content:
                all_tokens.extend(tokenize(m.content, use_jieba=True) if HAS_JIEBA else list(m.content))
        ttr = len(set(all_tokens)) / len(all_tokens) if all_tokens else 0.5

        self._style_profile = {
            "avg_length": round(avg_len, 1),
            "median_length": median_len,
            "question_ratio": round(questions / len(self_msgs), 3),
            "exclamation_ratio": round(exclamations / len(self_msgs), 3),
            "emoji_ratio": round(emojis / len(self_msgs), 3),
            "period_ratio": round(periods / len(self_msgs), 3),
            "type_token_ratio": round(ttr, 3),
            "total_messages": len(self_msgs),
            "preferred_length": "short" if median_len <= 8 else ("long" if median_len >= 20 else "medium"),
        }

    def _learn_sentiment_reply_map(self, messages: List):
        """学习情感-回复映射。"""
        self._sentiment_reply_map.clear()

        sorted_msgs = sorted(messages, key=_sort_key)
        for i, msg in enumerate(sorted_msgs):
            if msg.is_self() and msg.has_content():
                # 看前 3 条消息的情感倾向
                recent = sorted_msgs[max(0, i - 3):i]
                sentiment = self._quick_sentiment(recent)
                self._sentiment_reply_map[sentiment].append(msg.content)

    def _learn_time_reply_map(self, self_msgs):
        """学习时段-回复映射。"""
        self._time_reply_map.clear()

        for msg in self_msgs:
            if not (msg.timestamp and msg.content):
                continue
            hour = msg.timestamp.hour if hasattr(msg.timestamp, "hour") else 12
            if hour < 6:
                period = "late_night"
            elif hour < 12:
                period = "morning"
            elif hour < 18:
                period = "afternoon"
            else:
                period = "evening"
            self._time_reply_map[period].append(msg.content)

    # ----------------------------------------------------------------
    # 预测方法
    # ----------------------------------------------------------------

    def _predict_from_context(self, last_content: str) -> List[Prediction]:
        """基于上下文-回复对预测。"""
        if not last_content or not self._bigram_freq:
            return []

        keywords = self._extract_keywords(last_content)
        candidates: Counter = Counter()

        for kw in keywords:
            if kw in self._bigram_freq:
                for reply, count in self._bigram_freq[kw].items():
                    candidates[reply] += count

        predictions = []
        for reply, count in candidates.most_common(5):
            if reply in self.STOP_PHRASES:
                continue
            confidence = min(0.88, 0.55 + math.log(count + 1) * 0.08)
            predictions.append(Prediction(
                text=reply[:50],
                confidence=round(confidence, 3),
                strategy="history_context",
                rationale=f"历史上下文匹配（出现 {count} 次）",
                metadata={"source": "history_context", "frequency": count},
            ))

        return predictions

    def _predict_from_phrases(self, last_content: str) -> List[Prediction]:
        """基于高频短语预测。"""
        if not self._phrase_freq:
            return []

        predictions = []
        # 与当前上下文相关的短语优先
        last_tokens = set(tokenize(last_content, use_jieba=True)) if last_content and HAS_JIEBA else set()

        for phrase, count in self._phrase_freq.most_common(self.top_phrases):
            # 基础置信度
            freq_score = min(0.75, 0.40 + math.log(count + 1) * 0.06)

            # 如果短语与当前上下文有词汇重合，加分
            if last_tokens and HAS_JIEBA:
                phrase_tokens = set(tokenize(phrase, use_jieba=True))
                overlap = len(phrase_tokens & last_tokens)
                if overlap > 0:
                    freq_score = min(0.85, freq_score + overlap * 0.05)

            predictions.append(Prediction(
                text=phrase[:50],
                confidence=round(freq_score, 3),
                strategy="history_phrase",
                rationale=f"高频短语（历史出现 {count} 次）",
                metadata={"source": "history_phrase", "frequency": count},
            ))

        return predictions[:5]

    def _predict_from_sentiment(self, sentiment: str) -> List[Prediction]:
        """基于情感映射预测。"""
        if sentiment not in self._sentiment_reply_map or not self._sentiment_reply_map[sentiment]:
            return []

        replies = self._sentiment_reply_map[sentiment]
        # 取频率最高的
        freq = Counter(replies)
        predictions = []
        for reply, count in freq.most_common(3):
            if reply in self.STOP_PHRASES:
                continue
            confidence = min(0.70, 0.45 + math.log(count + 1) * 0.05)
            predictions.append(Prediction(
                text=reply[:50],
                confidence=round(confidence, 3),
                strategy="history_sentiment",
                rationale=f"情感适配（{sentiment}场景，历史 {count} 次）",
                metadata={"source": "history_sentiment", "sentiment": sentiment, "frequency": count},
            ))

        return predictions

    def _predict_from_time(self) -> List[Prediction]:
        """基于时段映射预测。"""
        now = datetime.now()
        hour = now.hour
        if hour < 6:
            period = "late_night"
        elif hour < 12:
            period = "morning"
        elif hour < 18:
            period = "afternoon"
        else:
            period = "evening"

        if period not in self._time_reply_map or not self._time_reply_map[period]:
            return []

        replies = self._time_reply_map[period]
        freq = Counter(replies)
        predictions = []
        for reply, count in freq.most_common(2):
            if reply in self.STOP_PHRASES:
                continue
            confidence = min(0.60, 0.35 + math.log(count + 1) * 0.04)
            predictions.append(Prediction(
                text=reply[:50],
                confidence=round(confidence, 3),
                strategy="history_time",
                rationale=f"时段适配（{period}，历史 {count} 次）",
                metadata={"source": "history_time", "period": period, "frequency": count},
            ))

        return predictions

    def _predict_from_style(self, last_content: str) -> List[Prediction]:
        """基于风格画像生成风格适配回复。"""
        if not self._style_profile:
            return []

        predictions = []
        style = self._style_profile

        # 根据风格生成回复建议
        if style["question_ratio"] > 0.3:
            predictions.append(Prediction(
                text="你觉得呢？",
                confidence=0.42,
                strategy="history_style",
                rationale=f"风格匹配：你常提问（占比 {style['question_ratio']:.0%}）",
                metadata={"source": "history_style", "feature": "question_habit"},
            ))

        if style["preferred_length"] == "short":
            # 倾向于短回复
            if last_content and "?" not in last_content and "？" not in last_content:
                predictions.append(Prediction(
                    text="嗯嗯",
                    confidence=0.38,
                    strategy="history_style",
                    rationale=f"风格匹配：你倾向短回复（中位长度 {style['median_length']} 字）",
                    metadata={"source": "history_style", "feature": "short_reply"},
                ))

        if style["exclamation_ratio"] > 0.2:
            predictions.append(Prediction(
                text="确实！",
                confidence=0.40,
                strategy="history_style",
                rationale=f"风格匹配：你常用感叹（占比 {style['exclamation_ratio']:.0%}）",
                metadata={"source": "history_style", "feature": "exclamation_habit"},
            ))

        return predictions

    # ----------------------------------------------------------------
    # 工具方法
    # ----------------------------------------------------------------

    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词。"""
        if not text:
            return []
        tokens = tokenize(text, use_jieba=True) if HAS_JIEBA else list(text)
        # 过滤停用词和短字符
        keywords = [t for t in tokens if len(t) >= 2 and t not in self.STOP_PHRASES]
        return keywords[:10]

    def _quick_sentiment(self, messages: List) -> str:
        """快速情感判断（简化版）。"""
        positive = {"好", "开心", "棒", "赞", "感谢", "谢谢", "喜欢", "爱", "哈哈", "太好了"}
        negative = {"累", "烦", "气", "失望", "难过", "累", "糟", "坏", "不好", "讨厌"}

        pos_count = 0
        neg_count = 0
        for msg in messages:
            if msg.content:
                tokens = set(tokenize(msg.content, use_jieba=True)) if HAS_JIEBA else set(msg.content)
                pos_count += len(tokens & positive)
                neg_count += len(tokens & negative)

        if pos_count > neg_count:
            return "positive"
        elif neg_count > pos_count:
            return "negative"
        return "neutral"

    def _dedupe_and_rank(self, predictions: List[Prediction]) -> List[Prediction]:
        """去重排序。"""
        seen = {}
        for pred in predictions:
            key = normalize_for_compare(pred.text)
            if not key or len(key) < 2:
                continue
            if key not in seen or pred.confidence > seen[key].confidence:
                seen[key] = pred

        result = list(seen.values())
        result.sort(key=lambda p: p.confidence, reverse=True)
        return result

    def _fallback(self, reason: str, context: PredictionContext) -> PredictionResult:
        """兜底响应。"""
        return PredictionResult(
            top_prediction=Prediction(text="嗯嗯", confidence=0.3, strategy=reason),
            alternatives=[],
            scenario=context.scenario,
            context={"fallback_reason": reason, "trained": self._trained},
        )

    # ----------------------------------------------------------------
    # 查询接口
    # ----------------------------------------------------------------

    def get_top_phrases(self, n: int = 20) -> List[Tuple[str, int]]:
        """获取最常用的 N 个短语。"""
        return self._phrase_freq.most_common(n)

    def get_style_profile(self) -> Dict[str, Any]:
        """获取风格画像。"""
        return dict(self._style_profile)

    def get_context_pairs(self, keyword: str = "", n: int = 10) -> List[Tuple[str, str]]:
        """获取上下文-回复对。"""
        if keyword:
            return [
                (ctx, reply) for ctx, reply in self._context_reply_pairs
                if keyword in ctx
            ][:n]
        return self._context_reply_pairs[:n]

    def is_trained(self) -> bool:
        return self._trained

    @property
    def trained_sessions(self) -> int:
        """累计学习过多少个会话（画像持久化后才有意义）。"""
        return self._trained_sessions

    # ----------------------------------------------------------------
    # 画像持久化（v5.0.0）
    #
    # 之前每次 predict-v2 进程结束，学到的短语/风格/上下文对就全没了：
    # "历史感知"实际上只感知了本次粘贴的那几十条。落盘后跨会话累积，
    # 用得越多越像本人说话。
    # ----------------------------------------------------------------

    PROFILE_VERSION = 1

    def export_profile(self) -> Dict[str, Any]:
        """导出可 JSON 序列化的画像（截断到 top_* 上限，避免文件无限膨胀）。"""
        cap = max(self.top_phrases * 4, 200)
        return {
            "profile_version": self.PROFILE_VERSION,
            "exported_at": datetime.now().isoformat(),
            "trained": self._trained,
            "phrase_freq": dict(self._phrase_freq.most_common(cap)),
            "bigram_freq": {ctx: dict(cnt.most_common(20))
                            for ctx, cnt in list(self._bigram_freq.items())[:cap]},
            "context_pairs": [list(p) for p in self._context_reply_pairs[:cap]],
            "style_profile": dict(self._style_profile),
            "sentiment_reply_map": {k: v[-20:] for k, v in self._sentiment_reply_map.items()},
            "time_reply_map": {k: v[-20:] for k, v in self._time_reply_map.items()},
            "self_msgs_tail": self._self_msgs[-cap:],
            "trained_sessions": self._trained_sessions,
        }

    def import_profile(self, profile: Dict[str, Any]) -> bool:
        """载入画像。缺字段一律留空，不抛异常——旧版本画像不该让预测器崩。"""
        if not isinstance(profile, dict):
            return False
        self._seed_profile = profile  # train() 之后据此把历史并回来
        try:
            self._phrase_freq = Counter({str(k): int(v) for k, v in
                                         (profile.get("phrase_freq") or {}).items()})
            self._bigram_freq = defaultdict(Counter)
            for ctx, cnt in (profile.get("bigram_freq") or {}).items():
                self._bigram_freq[str(ctx)] = Counter({str(k): int(v)
                                                        for k, v in (cnt or {}).items()})
            self._context_reply_pairs = [tuple(p) for p in (profile.get("context_pairs") or [])
                                         if isinstance(p, (list, tuple)) and len(p) == 2]
            self._style_profile = dict(profile.get("style_profile") or {})
            self._sentiment_reply_map = defaultdict(list)
            for k, v in (profile.get("sentiment_reply_map") or {}).items():
                self._sentiment_reply_map[str(k)] = list(v or [])
            self._time_reply_map = defaultdict(list)
            for k, v in (profile.get("time_reply_map") or {}).items():
                self._time_reply_map[str(k)] = list(v or [])
            self._self_msgs = list(profile.get("self_msgs_tail") or [])
            self._trained_sessions = int(profile.get("trained_sessions") or 0)
            self._trained = bool(profile.get("trained")) and bool(self._self_msgs or self._phrase_freq)
            return self._trained
        except Exception as e:  # noqa: BLE001 - 画像损坏时退回"未训练"，别拖垮整条预测
            logger.warning(f"历史画像载入失败: {type(e).__name__}: {e}")
            return False

    def save_profile(self, path: str) -> str:
        """写画像文件（先写临时文件再替换，避免中断留下半个 JSON）。"""
        payload = self.export_profile()
        directory = os.path.dirname(os.path.abspath(path))
        os.makedirs(directory, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=directory, prefix=".profile_", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False)
            os.replace(tmp, path)
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise
        return path

    def load_profile(self, path: str) -> bool:
        if not path or not os.path.isfile(path):
            return False
        try:
            with open(path, "r", encoding="utf-8") as f:
                profile = json.load(f)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"历史画像读取失败: {type(e).__name__}: {e}")
            return False
        return self.import_profile(profile)