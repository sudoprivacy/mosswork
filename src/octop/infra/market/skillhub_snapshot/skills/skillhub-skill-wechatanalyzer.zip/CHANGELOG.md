# 微信聊天分析助手 - 版本变更日志

## v6.0.0 (2026-11-07) - 话题地图 + MCP SDK 兼容 + 输出正确性

### ✨ 新增：话题地图分析器（第 12 个，`analyzers/topic_analyzer.py`）

- TF-IDF 关键词（词频 × 消息级 IDF），权重归一到 0–100，带 `self_count / other_count`
- 十个可重叠语义主题桶（工作/家庭/感情/健康/购物/美食/娱乐/学习/财务/出行），命中才输出
- 说话人拆分：我 / 对方 / 共同关注 / 各自独有；群聊再按真实昵称拆前 5 人
- 按 `session_gap_hours`（默认 4 小时）切会话段；段间 Jaccard < 0.3 记话题切换；
  前后半段标升温/降温词（按消息顺序，不按自然日）
- 无 jieba 时按随包内置高频词表（`analyzers/lexicon_topic_fallback.txt`）做最长匹配，
  词表外的未登录专名会漏掉，置信度扣分并在 `tokenizer_note` 里明确说明
- `config.json` 新增 `analysis.topic_enabled` 与 `topic` 配置节

### 🔌 修复：mcp 2.x 下 MCP Server 无法启动

- mcp 2.x 把 `mcp.server.fastmcp.FastMCP` 改名为 `mcp.server.mcpserver.MCPServer`，
  旧代码只导入前者，进程导入即失败；现按 1.x / 2.x 双路径探测
- `get_skill_status` 新增 `mcp_sdk_generation` / `mcp_sdk_label`，可直接看到当前跑在哪一代
- MCP 新增 `get_topic_analysis`（30 → 31 工具）；`analyze_chat` 摘要增加 `### topic` 段

### 🐛 修复：JSON 输出超限产生半截字符串

- `mcp_server._json()` 原先直接 `[:limit]`，一旦超限就是非法 JSON，调用方 `json.loads` 必崩
- 现在先试缩进版，超限退紧凑版，仍超限返回合法错误信封（`truncated: true` + 原因）

### 🔗 接线

- CLI `analyze-v2` 新增「🗺️ [话题]」展示段；HTML 报告新增话题地图卡片；
  一句话总结追加「高频话题是「X」」；Markdown / CSV 导出新增 topic 指标
- `doctor` 分析器装载检查 11 → 12

### 🧪 测试

- 新增 `tests/test_v600_topic_analyzer.py`（18 项）：jieba / 无 jieba 双路径、
  关键词/主题/说话人/群成员/分段/切换/冷热/确定性/降级/接线
- `tests/test_mcp_e2e.py` 增加话题工具与 SDK 代数断言，并补 `_json()` 半截输出回归用例
- 文档数字对账闸同步：MCP ≥ 31 工具、`topic` 必须在注册表、`31 工具` 与 `12 个分析器` 必须写进正文
- 全量测试：`py -3.14` **711 passed / 6 skipped**；`py -3.11` **712 passed / 5 skipped**

## v5.0.0 (2026-10-15) - 隐私扫描 + 群聊分析 + 跨会话趋势 + 解析正确性治本

### 🐛 修复：粘贴格式与 self/other 口径（这一版的主线）

- **行首时间戳不再吃掉发送者**（`scripts/data_manager.py`）
  - `2024-01-15 14:32:15 张三: 你好` 之前按冒号切句 → `sender = "2024-01-15 14"`，
    之后所有分析器都认不出是谁说的，内容型分析整体失真
  - 新增 `_INLINE_TIMESTAMP` / `_SENDER_CONTENT` / `_PURE_TIMESTAMP_LINE`：先剥时间戳再认名字，
    名字封顶 30 字（正文里的冒号不当分隔符），纯时间戳行与 `———`/`***` 装饰行丢弃
  - 支持一位小时、多空格、`/` 分隔日期、无秒等微信实际写法；`【…】` 与 `|` 分隔同样处理
- **自我标识统一为单一来源**（新增 `core.message.is_self_sender()`）
  - `scripts/text_analyzer.py`：旧代码只认 `sender == 'self'`，而两条导入通道给的是"我"
    → v1 报告里"你的消息"恒为 0、"对方消息"恒为全部；两处 `initiation_ratio` 同样算反
  - `scripts/llm_analyzer.py`：同一判定错误导致**发给大模型的逐句话把"我"标成"对方"**
  - `scripts/data_source_importer.py`：删掉自己那份 `_SELF_SENDERS`，`_role_of()` 改调 core，
    四条导入通道不再各说各话
  - 只做整名匹配：`我的天`、`我们自己` 这类昵称不会被误判成"我"；非字符串/None 不抛异常
- **普通散文不再被当成结构化消息**（`scripts/main.py::_import_container_text`）
  - `detected_platform` 为 `text:*` / `simple` / `unknown` 时一律交回逐行解析，
    否则无冒号的一句散文会变成 `sender="unknown"`，破坏 self/other 统计
  - 顺带修掉"结构化导入：None"的显示问题，改为回落到 `result.source`
- **历史画像会话数不虚高**（`predictors/history_aware_predictor.py`）
  - `merge_history=False` 时不继承旧画像的 `trained_sessions`
  - 种子合并移到 `train()` 清空重建**之后**，否则先合并再清空等于白学

### 🛡️ 修复：运行产物落进技能包

- RAG 向量库（`rag/vector_store.py`）、embedding 缓存（`rag/embedder.py`、
  `predictors/rag_predictor.py`）、Web 截图上传目录（`scripts/web_server.py`）、
  报告目录（`scripts/v2_report_generator.py`）此前默认拼到 `<技能根>/data/…`
- 统一规则：**绝对路径照用，相对路径归一到 `core.data_paths.resolve_data_dir()`**，
  否则 `.db` / `.index` / `.png` 会跟着技能包一起上传被文件类型校验拦下
- 相应地，`tests/test_rag_test_vector_store.py` 里原先**把这个 bug 当成正确行为断言**的用例已改写

### ✨ 新增：本地隐私扫描器（第 11 个分析器，`analyzers/privacy_scanner.py`）

- 10 类：密钥/口令、身份证号、银行卡号、长数字串、手机号、座机、邮箱、微信号、地址/定位、疑似真实姓名
- 银行卡走 **Luhn 校验**，过不了的只标"长数字串"，订单号不再误报成卡号
- 命中区间按优先级互斥去重（显式密钥先咬，否则内部数字会被当成手机号）
- 姓名只认显式声明；"X老师/X经理"式推断因中文无词边界误报严重，实现后删除
- `mask_privacy_text()` 一键脱敏；`privacy_scan.mask_before_llm`（默认开）在发往大模型前先脱敏，
  脱敏本身失败时发送占位文本而不是原文

### ✨ 新增：群聊多主体分析器（`analyzers/group_analyzer.py`）

- 成员发言占比 / 字数 / 均长 + 活跃度分层 + 主导度
- 点名关系网（谁 @ 了谁，含昵称模糊对齐）+ 双人互动平衡度
- 不足 `group_chat.min_members`（默认 3）时明确标注非群聊，不硬凑指标

### ✨ 接线：跨会话快照 + 多格式导出 + 画像训练

- `scripts/session_memory.py` 接入 CLI/MCP：`session --list/--save/--compare`，
  `analyze-v2` 默认存快照（`--no-snapshot` 关闭，`--label` 加备注）
  - 显著变化判定 `|Δ| ≥ 1.0` 或变化率 `≥ 10%`；只存标量指标，不存聊天正文与昵称
  - 消息总数 / 平均长度 / 参与人数是"量"不是"质"，趋势只写**上升/下降**，
    不进"改善/转弱"的结论；仅有量级变化时明确说"质量类指标基本持平"，
    避免"少发了 25 条消息"被读成关系恶化
  - JSONL 存储，损坏行与缺 `id` 的行读取时丢弃；`max_snapshots` 截断
- `scripts/report_exporters.py`：`--markdown` / `--csv`（`utf-8-sig`，Excel 直接双击）/
  `report-v2 --format markdown|csv`；`--platform` 支持手工指定输入格式
- MCP 新增 12 工具（18 → 30）：`scan_privacy`、`get_group_analysis`、`get_pattern_analysis`、
  `get_inference_analysis`、`get_interpretation_analysis`、`ai_insight_from_chat`、
  `list_analysis_sessions`、`save_analysis_session`、`compare_analysis_sessions`、
  `export_chat_report`、`get_prediction_profile`、`train_reply_predictor`
- CLI 新增 `capture` / `session` 两个子命令（共 15 个）；非 Windows 或微信未运行时会说明原因并降级

### 🧪 测试与工程

- 新增 `tests/test_v500_capability_chain.py`（59 项）与 `tests/test_v500_cli_chain.py`（18 项）：
  覆盖导出/快照/画像/脱敏/解析回归与容器导入降级路径
- 新增 `tests/test_v500_doc_facts.py`：文档数字对账闸 —— MCP 工具数、CLI 子命令数、分析器数量
  一律从代码量出来后与 SKILL.md 比对；正文点名的工具名与命令行开关必须存在；
  文档内相对链接必须可解析（这一项当场揪出两处指向不存在文件的链接）
- MCP stdio 子进程端到端用例保留（需 `mcp` 依赖，缺失时跳过）
- 全量测试：`py -3.14` **691 passed / 6 skipped**；`py -3.11` **692 passed / 5 skipped**，
  其中含 29 项 MCP stdio 子进程端到端用例（只在装有 `mcp` 的解释器上跑）

### 📦 文档

- SKILL.md / README.md / FAQ.md / RUNBOOK.md 同步到 v5.0.0：
  能力矩阵补隐私扫描/群聊/跨会话/多格式导出，命令速查补 `capture` 与 `session`
- 修掉三处与代码不符的说明：`TROUBLESHOOTING.md` 死链、`analyze-v2 --format text`（无此开关）、
  `main.py download-models`（无此命令）、`--offline`（无此参数）
- 披露已知问题：`scripts/mirofish_config.py` 顶层依赖 `python-dotenv`（未列入任何 requirements），
  `scripts/mirofish_services_*.py` 引用的 `Config.UPLOAD_FOLDER` 从未定义；当前无任何入口导入，属死代码

## v4.0.0 (2026-09-25) - 桌面微信捕获 + 个性化预测 + 推演增强（三轨升级）

### ✨ 新增：桌面微信实时捕获（`scripts/clipboard_monitor.py` + `scripts/wechat_window_reader.py`）

- **剪贴板实时监控** — Win32 API (AddClipboardFormatListener) 零依赖剪贴板监听
  - 自动识别微信桌面端复制的聊天格式（时间戳+发送者+内容）
  - 增量去重（MD5 hash 去重窗口，默认 100 条）
  - 后台守护线程，不阻塞主进程
  - 可配置轮询间隔、最大历史、self_names
- **微信窗口读取** — UI Automation COM / Win32 API 降级读取
  - 自动发现微信主窗口（WeChatMainWndForPC / ChatWnd）
  - 提取当前聊天面板消息列表
  - 获取联系人/群聊列表
  - 消息结构化解析（日期/时间/发送者/内容自动分离）
  - comtypes 可选依赖（无则降级到 EnumChildWindows）
- **MCP Server 新增 3 工具** — capture_clipboard / capture_wechat_window / get_desktop_status

### ✨ 新增：历史感知个性化预测器（`predictors/history_aware_predictor.py`）

- **N-gram 高频短语** — 从用户真实回复中提取高频短语和 N-gram 模式
- **上下文-回复对** — 学习"对方说了X，你通常回Y"的条件频率分布
- **风格画像** — 平均长度/中位长度/疑问比例/感叹比例/emoji比例/标点比例/词汇丰富度
- **情感-回复映射** — 学习你在正面/负面/中性情绪下的回复差异
- **时段-回复映射** — 学习你在早上/下午/晚上/深夜的回复风格变化
- **置信度算法** — 基于频率对数衰减 + 上下文词汇重合度加权

### ✨ 增强：集成预测器（`predictors/ensemble.py` v4.0.0）

- **动态置信度权重** — 各预测器权重随预测置信度实时调整（置信度越高权重越大）
- **v4.0.0 预测器基础权重** — rule 35% / rag 30% / history_aware 25% / mirofish 10%
- **历史感知预测器加成** — 个性化回复比通用模板多 15% 权重
- **多样性保障** — top-5 中避免过于相似的回复（字符集相似度 > 0.6 过滤）

### ✨ 增强：规则预测器（`predictors/rule_predictor.py` v4.0.0）

- **意图链追踪** — 追踪对话意图变化链（如 question→statement→question），基于历史模式推荐
- **长度自适应回复** — 根据对方消息长度（短/中/长/超长）自动匹配回复长度

### ✨ 增强：推演分析器（`analyzers/inference_analyzer.py` v4.0.0）

- **话题马尔可夫链** — 按滑动窗口提取话题序列，构建转移概率矩阵，预测下一个话题
  - 话题循环检测（同一话题出现 3+ 次）
  - 稳定性评分（话题越频繁跳转越不稳定）
- **回复时间模式** — 分析双方回复延迟模式
  - 对方/我方中位延迟、平均延迟
  - 延迟趋势（越来越快/慢/稳定）
  - 对方高峰回复时段识别
  - 最佳回复窗口建议
  - 健康评分（双方延迟差异+趋势综合评估）

### 📦 依赖更新

- 新增 `scripts/clipboard_monitor.py`（零外部依赖，仅 Win32）
- 新增 `scripts/wechat_window_reader.py`（零外部依赖，comtypes 可选）
- 新增 `predictors/history_aware_predictor.py`（零外部依赖）
- MCP Server 工具数：15 → 18

---

## v3.0.0 (2026-09-21) - AI 深度洞察 + 多源数据导入 + MCP Server（三轨升级）

### ✨ 新增：AI 深度洞察引擎（`analyzers/ai_insight_engine.py`）

- **真正接通 LLM** — 把 `config.json` 中默认禁用的 LLM 真正接进来，提供 5 类专业分析模板：
  - `personality_insight` 性格解读（基于 MBTI/大五）
  - `emotion_narrative` 情感叙事（把转折点编织成故事）
  - `relationship_advice` 关系改善建议（基于五维评分）
  - `risk_interpretation` 风险解读（4 类风险原因+应对）
  - `prediction_explanation` 预测解释（为什么对方可能这样回复）
- **多 Provider 支持** — DeepSeek（默认）/ OpenAI 兼容 / Ollama 本地
- **环境变量优先** — `DEEPSEEK_API_KEY`/`OPENAI_API_KEY`/`LLM_PROVIDER` 自动覆盖 config.json
- **隐私脱敏** — 发送 LLM 前自动屏蔽手机号/身份证/银行卡号；聊天内容超 4000 字符自动截断
- **响应缓存** — MD5 键缓存相同 context 的结果
- **降级机制** — LLM 不可用时自动返回规则引擎模板化输出 + 免责声明

### ✨ 新增：多源数据导入（`scripts/data_source_importer.py`）

- **智能粘贴解析** — 6 平台自动识别（微信/企业微信/QQ/iMessage/短信/邮件）
- **续行支持** — 消息跨多行自动合并到上一条
- **URL 直连** — 从公开 URL 获取聊天内容（urllib 标准库）
- **JSONL 导入** — 每行一个 JSON 对象的高效解析
- **JSON 数组/对象导入** — 支持嵌套结构自动提取消息字段
- **完全本地处理** — 零数据外传，零额外依赖

### ✨ 新增：MCP Server（`mcp_server.py`，15 工具）

- **7 分析工具** — analyze_chat / get_mbti_analysis / get_bigfive_analysis / get_sentiment_analysis / get_risk_analysis / get_relationship_health / get_scenario
- **5 AI 洞察工具** — ai_personality_insight / ai_emotion_narrative / ai_relationship_advice / ai_risk_interpretation / ai_prediction_explanation
- **1 预测工具** — predict_reply（Rule + RAG + MiroFish 三层融合）
- **1 导入工具** — import_chat_from_text
- **1 系统工具** — get_skill_status
- Claude Code / Qoder 可直接 stdio 调用

### 🔧 版本与配置同步

- `core/version.py`：`__version__ = "3.0.0"`
- `config.json`：新增 `ai_insight`、`mcp_server`、`multi_source` 三节配置
- SKILL.md：frontmatter version 升级 + 4 个新 tag + 5 个新 trigger
- README.md / FAQ.md / RUNBOOK.md：版本号统一到 v3.0.0（之前 FAQ/RUNBOOK 仍写 v2.2.0）
- 完整向后兼容：v2.9.0 及之前的所有分析器、命令、API 全部保留

## v2.9.0 (2026-08-22) - 分析能力增强：关系健康度 + 情感趋势深化 + 语音交互

### ✨ 新增：关系健康度分析器（`analyzers/relationship_analyzer.py`）

- **五维评估**：互动平衡度（1:5 以下判为独白 → 0 分）/ 回应度（回复速度分级 <1分钟→>24小时）/ 情感同步性（双方正面情感占比差）/ 投入度（日均消息量）/ 互动深度（平均消息长度），加权求和 0-100。
- **冷回复惩罚**：对方长消息后回「嗯/哦/知道了」的比例 × 20 分封顶扣减。
- **等级**：excellent(≥75) / good(≥60) / fair(≥40) / warning(<40)，附中文改善建议。
- **自包含回退链**：情感同步优先复用 sentiment 分析器 details（含 v2.9 新增 `self_positive`）→ 词典法单句评分 → 表情符号轻量统计 → 中性 50。
- 注册中心默认开启，`config.json` 中 `analysis.relationship_enabled: false` 可关闭。

### ✨ 新增：语音交互（`scripts/voice_interface.py` + `main.py voice` 子命令）

- **零依赖三级降级**：TTS = pyttsx3 → Windows SAPI（PowerShell 5.1 System.Speech）→ 终端打印；STT = speech_recognition → SAPI 听写 → `input()` 文本。
- **口语指令解析**：分析/预测/演示/自检/报告/日历/图谱/版本/帮助/退出，支持文件路径提取（带引号路径、盘符路径、裸文件名 + 前导动词剔除）与中文数字/全角归一化。
- **口语化摘要**：分析结果浓缩为一段话播报（MBTI / 情感趋势 / 关系健康度 / 风险信号）。
- speaker/listener/executor 全部可注入，会话逻辑纯函数化可测。

### 🔬 分析能力优化：情感分析增强（向后兼容新增字段）

- `rolling_trend`：情感净分滚动平均序列（窗口≤5，样本<3 返回空）
- `turning_points`：滚动趋势符号反转点（变差/好转，阈值 ±0.5）
- `self_positive` / `self_negative`：己方情感占比（供关系健康度复用）
- 终端报告新增转折点展示。

### 🧪 测试与工程

- 新增 `tests/test_v290.py`（65 个用例）；版本一致性断言自 v2.9 起由该文件接管。
- 全量 **394 passed, 5 skipped**（329→394，零回归）。
- `config.json` 新增 `voice` 配置节（tts/stt/stt_timeout/enabled）。

---

## v2.8.0 (2026-08-17) - 健壮性升级：零警告 + Python 3.15 兼容 + 裸 except 收紧

### 🐛 修复

- **非法转义序列** — `core/utils.py:216`：分句正则 `r'[…""''…\[\]]+'` 中内容含 `''`，把单引号 raw string 提前截断，后半段隐式拼接成**普通字符串**，`\[` 触发 DeprecationWarning（Python 3.12+ 升级为 SyntaxWarning，未来将成 SyntaxError）。改为三引号 raw string，正则实际值不变。
- **Python 3.15 日期解析行为变更** — `scripts/calendar_manager.py:_parse_date`：`%m-%d` 无年份格式依赖 strptime 默认年份 1900 再 replace，Python 3.14 起产生 DeprecationWarning、3.15 起行为将变更。现改为正则校验月-日后用参考年份显式构造 `datetime`，语义不变（"01-01" + 参考 2026 → 2026-01-01），闰年 02-29 非法时如实返回 None。

### 🛡️ 健壮性

- **7 处裸 except 收紧**（活跃代码，archive_v1 归档不动）：
  - `scripts/text_analyzer.py` ×3（datetime.fromisoformat）→ `except ValueError`
  - `scripts/main_setup.py`（rglob 扫描）→ `except OSError`
  - `scripts/calendar_manager.py`（冗余外层 try 一并移除）
  - `scripts/mirofish/services/simulation_config_generator.py` ×2、`oasis_profile_generator.py` ×1（json.loads 修复链）→ `except json.JSONDecodeError`

### 🧪 测试强化

- 新增 `tests/test_compile_smoke.py`：
  - `test_all_modules_compile_without_warnings` — 自动扫描全部 .py，`compile()` + 警告升级为错误（非法转义无处遁形）
  - `test_no_bare_except_in_active_code` — 裸 except 防回归
  - `test_version_single_source_consistent` — `core/version.py` / config.json / SKILL.md frontmatter 三处版本一致
- 全量 **329 passed**（326→329，新增 3 项烟囱测试），Python 3.11.9 / 3.14 双版本零警告

### 📦 工程

- `clean.py` 新增 `--check` 模式：只检查不删除，退出码 1=有二进制残留（上传前必跑）
- 版本号统一至 2.8.0（core/version.py 单一来源 + config.json + SKILL.md + run_tests.py）
- 补记 CHANGELOG 缺失的 v2.7.0 条目

---

## v2.7.0 (2026-08-13) - 测试优化 + scheduler 建表修复（补记）

- **修 scheduler 缺建表 bug** — `scripts/scheduler.py` 此前 `__init__` 只初始化 APScheduler，从未建 `scheduled_tasks` 表，`add_job`/`list_jobs` 首次调用抛 `no such table`；现新增 `_init_db`
- **补 30 个测试** — `test_calendar_manager.py`（日期解析/事件类型/重要性/完整提取）+ `test_scheduler.py`（建表/增删查）
- 测试 272 → **302 通过**

---

## v2.6.0 (2026-08-13) - 上传被拒修复（.pyc / .db 二进制清理）

### 🚫 修复上传被拒

- **`.pyc` 字节码治本** — 7 个包 `__init__.py` + `scripts/main.py` + `run_tests.py` 顶部加 `sys.dont_write_bytecode = True`；`run_tests.py` 原 `os.environ.setdefault("PYTHONDONTWRITEBYTECODE","1")` 无效（CPython 仅启动时读环境变量），改为直接设 `sys` 标志。
- **`.db` 数据库治本** — 新增 `core/data_paths.py` 统一运行时路径解析，`ZepLocalGraph` / `DataManager` / `CalendarManager` / `SchedulerManager` 默认数据库路径从 `data/mirofish_graph.db`、`data/sessions/chat_history.db` 迁移到系统 tempdir（`%TEMP%/wechat-analyzer/`），支持 `WECHAT_ANALYZER_DATA_DIR` 环境变量覆盖；仅当传入绝对路径时才使用 config 的 `db_path`。
- **`clean.py` 扩展** — 新增 `clean_db()` 清理 `.db/.sqlite/.db-wal/.db-shm`，加 `--keep-db` 参数；docstring 与提示同步更新。

### ⚙️ 工程说明

- 验证：`python run_tests.py` 全量 **272 通过 0 失败 0 错误**，测试后无 `.pyc`/`__pycache__`/`.db` 残留。
- 机制记录：CPython `SourceFileLoader.get_code()` 在「执行模块代码之前」写 pyc，故 `__init__.py` 内 `sys.dont_write_bytecode` 拦不住其自身字节码，只能拦后续 import 的子模块——彻底清零仍需环境变量或 `clean.py` 兜底。

---

## v2.5.0 (2026-08-13) - 五大 bug 修复 + 友好错误全链路 + 性能优化

### 🐛 修复（5 个真实 bug）

- **「非常」窗口索引错位** — `analyzers/sentiment_analyzer.py`：`_is_negated` 判断「非」后是否接「常」时，`re.finditer` 的位置是相对 12 字符窗口（`context`）的，却用 `text[m.end()]` 读原文——情感词距句首 >12 字符时读到不相关字符，「非常开心」被误判否定。
- **RAG 角色过滤永不匹配** — `rag/retriever.py`：`rag_predictor` 传 `sender_filter="other"`，但索引时 metadata 存的是原始 sender 名（如「小王」），`where={"sender": "other"}` 永远匹配不上 → RAG 一直空检索回退。现索引写入 `sender_role` 元数据，`self`/`other` 按角色过滤（其他值仍按原始名精确匹配，向后兼容），旧向量库无该字段时自动去过滤重试。
- **msg_type 键名丢失** — `core/message.py`：旧生产者（file_importer/data_manager）输出 `msg_type` 键，`from_dict` 只读 `message_type`，导致 image/voice/system 消息全部静默降级为 text。现两键均接受，规范键优先。
- **MBTI 失败显示崩溃** — `scripts/main.py`：分析器异常时 `run_all` 返回 `{"error": ...}` 错误桩，`_display_v2_results` 直接 `mbti['type']` 触发 KeyError 中断整个报告展示。现错误桩降级显示「分析失败 + 原因」，同时删除永不可达的 `AnalysisResultStub`。
- **无发送者行 self/other 颠倒** — `scripts/data_manager.py`：注释说「假设没有发送者的是自己的消息」但代码写 `sender='other'`（与注释相反），导致 self/other 统计颠倒、情感/人格分析对象错误；`len(line) < 100` 在正则 `{1,20}` 下不可达一并清理。另新增：纯时间戳行（`2024-01-01 12:30:00`）与分隔线（`----`）不再被误解析为消息。

### ✨ 新增功能

- **友好错误提示全链路接入** — `friendly_errors.py`（此前写了但从未被 CLI 使用）接入 `main()` 全局异常处理：缺依赖/坏文件/权限/编码等输出中文「原因 + 解决」；`--debug` 可看完整堆栈。补充 jinja2/python-docx/python-pptx/openpyxl 缺失模式；修复「JSONDecodeError 命中前一条 'Expecting value' 模式导致缓存损坏条目不可达」的遮蔽问题。
- **`predict-v2 --seed` 可复现预测** — `predictors/mirofish_predictor.py` 用独立 seeded 随机源替代全局 `random.choice`：默认 seed=0 结果稳定，`--seed N` 指定种子，测试/报告不再 flaky。
- **版本号单一来源** — 新增 `core/version.py`，CLI 输出 / JSON 导出 / HTML 报告 / config.json 统一读取；此前十余处版本字符串（config.json 还停在 2.3.0）升级常漏改。

### ⚡ 性能优化

- `core/utils.py`：`pseg.cut`（词性标注，从未消费词性）→ `jieba.cut`，分词快数倍
- `sentiment_analyzer.py`：情感词典首字索引（只扫描首字出现在文本中的词条，替代每消息全词典线性扫描）；正面/负面高频词改用 `Counter` 按频次排序（原 `set()` 输出任意顺序）
- `inference_analyzer.py`：行为信号集合预构建（原在消息 × 行为内层循环反复 `set()` 重建）
- `file_importer.py`：`.doc/.ppt` 二进制兜底的中文提取重写（原只保留 ASCII 字节，中文全丢；现 utf-8/gb18030/utf-16-le 多编码尝试 + 常见字评分）；`.xlsx` 去掉裸单元格重复计数；`except Exception` 吞异常改为具体异常
- `ensemble.py`：删除计算后从未使用的 `recent_text` 死代码；`timing.py` 简化冗余分支

### 🧪 测试与工程

- **测试基建修复**：`run_tests.py` 此前只发现 6 个子目录，`tests/test_friendly_errors.py` 从未被执行——顶层函数式测试现通过 `FunctionTestCase` 纳入；docx/pptx/xlsx 测试缺依赖时优雅跳过（此前 7 个 ERROR）
- 新增 37 个回归测试：情感「非」窗口（长/短消息）、否定窗口、高频词频次、RAG 角色过滤 7 例、Message msg_type 兼容 3 例、main 展示容错 6 例、MiroFish 确定性 3 例、友好错误新模式 6 例、二进制中文提取 5 例、data_manager 垃圾行 2 例
- 全套 **272 个测试通过，0 失败 0 错误**（v2.4.0 时为 227 通过、7 错误）

---

## v2.4.0 (2026-08-05) - 情感分析 jieba 修复 + 测试补全

### 🐛 修复

- **情感分析在 jieba 安装后失效** — `analyzers/sentiment_analyzer.py` 重写为原文扫描（不再依赖分词结果）：
  - 「非常开心」被程度副词「非常」的「非」字误判为否定 → 否定判断改为「非」仅当后不接「常」才算否定
  - 「我不开心」因 jieba 分词过滤停用词删掉否定词「不」导致否定识别失效 → 否定/程度判断改为原文字符窗口，jieba 装与不装结果一致
- **立场识别「我反对」被判 neutral** — `analyzers/interpretation_analyzer.py` 正面词典单字「对」子串命中「反对」里的「对」；移除单字「对」，改配「对的/没错/说得对」
- **词典清理** — 意图「来吧」、主题「爸妈」重复项；NER 金额正则 `[万千百千]` 错字改为 `[万亿千百]`
- **运行时 SQLite 库混入交付物** — `data/chat_history.db` 上传被文件类型校验拦截（".db 不允许"）：统一默认 db 路径到已忽略目录 `data/sessions/`（`config.json` + `data_manager.py` / `calendar_manager.py` / `scheduler.py` / `main_setup.py`），`calendar_manager`/`scheduler` 补 `mkdir(parents=True)`；`gitignore_rules.txt` 补 `data/*.db`；物理移除运行时产物

### 🧪 测试与工程

- 新增 75 个测试用例，覆盖 4 个此前无测试的模块：
  - `interpretation_analyzer`（27）：意图识别 / NER Lite / 主题抽取 / 立场识别
  - `data_manager`（16）：4 种文本格式解析 / 聊天存储读取 / 分析结果存取
  - `vector_store`（11）：metadata 清洗 / CRUD / 缺依赖友好报错（mock chromadb）
  - `rag_predictor`（21）：查询构造 / 候选提取 / 长度匹配 / 重排序去重 / 兜底降级（mock 初始化）
- 全套 **235 个测试通过，0 失败 0 错误**（v2.3.0 时为 160 通过）
- **运行优化**：安装缺失的必需依赖（jieba / flask / flask-cors），`doctor` 不再报必需项缺失，`analyze-v2` 实际跑通 8 个分析器

---

## v2.3.0 (2026-08-01) - 时间感知对话预测 + 及时性提升

### ✨ 新增功能

- **`core/timing.py`**：统一提取聊天时间特征（最后消息距今、紧急度、时间段、周末/工作日、密集对话节奏）
- **Rule 预测器时间适配**：隔太久主动找回联系、即时短回复、夜间关怀、周末轻社交、连续对话延续
- **Ensemble 时间适配**：隔太久找回联系话术加分、即时/尽快场景短回复加分、夜间关怀加分
- **`predict-v2` 输出 `[回复时机]` 提示**：立即回复 / 尽快回复 / 今天内回复 / 隔太久先主动找回联系
- **新增 8 个测试**：时间特征、及时性话术、集成上下文传播

---

## v2.2.0 (2026-07-28) - 多格式导入 + 智能预测强化

### 🐛 修复

- **Word/PPT/Excel 文字导出异常** — `scripts/file_importer.py` 全面重写：
  - 旧版 `.doc` / `.ppt` 缺失解析实现且无任何降级路径，现在补齐 antiword / textract / 二进制可打印片段三层兜底
  - 旧版 `file_importer.py` 直接按 `'.doc'` 后缀走 textract（包未装就直接 `print` 后 `return []`，无任何可读结果）
  - 旧版没有 `.pptx` / `.xlsx` / `.xls` 处理分支，全部兜底为文本或直接 `return []`
  - PDF 仅 pdfplumber 单点依赖；现增加 PyPDF2 / pypdf 双兜底
  - 旧版异常时直接 `print` 后 `return []`，无 metadata 也不区分错误；现在统一返回 system 消息 + `parse_error` metadata
- **Word 解析不完整** — 现在 `.docx` 解析同时输出段落、表格、页眉、页脚、文本框，metadata 标记 `doc_section`
- **Excel 解析不完整** — `.xlsx` 现在逐单元格 + 行汇总双层输出，metadata 含 sheet 名 + 单元格坐标
- **PPT 解析不完整** — `.pptx` 现在按 slide 索引输出所有 text_frame + 表格 + 演讲者备注，metadata 含 `ppt_slide` + `ppt_section`

### ✨ 新增功能

- **多格式统一 chat 输出** — 所有 docx / xlsx / pptx / pdf 解析结果统一为
  `{timestamp, sender, content, msg_type, file_path, metadata}` 格式，
  可直接送入 `analyze-v2` / `predict-v2` 链路
- **Rule 预测器上下文感知** — `predictors/rule_predictor.py` 升级到 v2.2.0：
  - 句末意图识别：question / request / complaint / gratitude / invitation / statement 6 类
  - 风险信号检测 + 自动切换防守话术
  - 暖心/共情/防守 3 套情感话术
  - 30+ 关键词软触发（频次加权）
  - 风格适配：基于最近 5 条我方回复（短/长/疑问/感叹）做风格匹配
- **Ensemble 智能融合** — `predictors/ensemble.py` 升级到 v2.2.0：
  - 上下文匹配加成：与最近对方消息语义匹配的预测获得 +0.05 加权
  - 风险规避：风险场景下减分积极策略
  - 风格一致性：与历史我方风格不一致的预测降权
  - 多策略加成（被多种预测器独立选中 → 提升）
- **RAG 智能版** — `predictors/rag_predictor.py` 升级到 v2.2.0：
  - 智能查询构造：最近 N 条对方消息 + 关键词权重
  - 长度匹配：与最近我方回复长度相当的优先
  - 多样性去重：避免返回几乎相同的回复
  - 双检索：检索 "对方问 + 我方答" 模式
- **可读性优先** — 所有解析器失败时返回 system 类型消息 + 中文友好提示，不再裸抛 stack trace

### 🧪 测试与工程

- 新增 29 个测试用例（`tests/test_scripts/test_file_importer.py` + `tests/test_predictors/test_rule_predictor_v22.py`）
- 覆盖 docx / xlsx / pptx / pdf / txt (utf-8 + gbk) / json / 错误路径 / 上下文意图 / 风险信号 / 情感驱动 / 风格匹配
- 全部 153 个测试通过，0 失败 0 错误（v2.1.0 时为 124 通过）

## v2.1.0 (2026-07-18) - 修复补齐 + 报告与体验增强

### 🐛 修复

- **graph-stats 崩溃修复** — 补齐 README/SKILL.md 已宣传但缺失的 `mirofish/` 顶层包：
  - 新增 `mirofish/__init__.py`、`mirofish/core/__init__.py`、`mirofish/core/zep_local.py`
  - `ZepLocalGraph(db_path=None)` 默认 `data/mirofish_graph.db`，仅用 stdlib sqlite3 + jieba，零新依赖
  - 实体 = 消息发送者 + jieba 高频关键词；关系 = 同一消息内实体共现（mentions / co_occurs）；记忆 = 消息文本摘要（内容哈希去重，重复 build 幂等/增量）
  - 接口：`build_from_messages()` / `get_stats()` / `get_graph()`，兼容 main.py 现有 graph-stats 展示代码
- **输入文件编码自动检测** — `core/utils.py` 新增 `read_text_auto()` / `decode_bytes_auto()`，
  按 utf-8-sig → utf-8 → gb18030 顺序尝试解码；应用于 `scripts/main.py::_load_messages`
  的 `--input` 分支和 `scripts/file_importer.py` 的 txt/md 读取；失败时给出友好中文错误，
  GBK 导出的聊天记录不再 `UnicodeDecodeError` 崩溃
- **大五人格归一化校准** — `analyzers/bigfive_analyzer.py` 改为基于信号量的对数平滑映射
  （以 50 为中点、极性比例偏移、信号越少越收缩、最多 ±35），小样本不再轻易饱和 100%，
  示例数据各维度落在合理分散区间
- **MBTI 可解释性** — `_display_v2_results` 中稳定性 <50% 时追加中文提示
  "样本较少或特征不明显，结果仅供参考"

### ✨ 新增功能

- **分析进度反馈** — `AnalyzerRegistry.run_all` 新增可选 `progress_callback` 参数（向后兼容，
  默认 None）；`analyze-v2` / `predict-v2` 运行时逐个显示 `[i/6] sentiment ... 完成 (0.12s)`
- **`analyze-v2 --export PATH.json`** — 导出全部分析器结果（`AnalysisResult.to_dict()`）
  + 消息统计元数据（总数/双方消息数/时间跨度）为 JSON
- **`analyze-v2 --html PATH.html` + 新命令 `report-v2`** — 新增 `scripts/v2_report_generator.py`，
  生成完全自包含的单文件 HTML 报告（内联 CSS + Python 生成 SVG 雷达图/环形图/条形图，
  零 CDN、零外部资源、离线可开、中文界面）；内容含一句话总结、MBTI 卡片、大五雷达、
  情感环形图 + 正负面高频词、对话模式统计卡片、风险分级配色卡片、场景权重条形图、生成时间戳；
  `report-v2` 从 data_manager 读取最近一次 analyze-v2 结果，输出到 `data/reports/`，
  无 v2 结果时给出明确提示
- **新命令 `demo`** — 一键分析内置示例 `tests/fixtures/sample_chat.txt`，终端展示 +
  在 `data/reports/` 生成 HTML 报告并打印路径
- **新命令 `doctor`** — 环境自检：Python 版本 ≥3.8、jieba（必需）、flask/python-docx/python-pptx
  （v1 功能）、sentence-transformers/chromadb（RAG 可选）、config.json 可解析、data/ 目录可写、
  stdout 编码，逐项 OK/警告并给出修复建议
- **交互式向导** — `python scripts/main.py` 无参数运行时进入向导（`-h/--help` 行为不变）：
  欢迎语 → 粘贴聊天记录（END 结束）→ analyze-v2 → 询问是否生成 HTML 报告（y/N）；
  输入为空时优雅退出
- **v2 终端报告"一句话总结"** — 基于各分析器结果规则生成 1-2 句中文摘要，
  放在 `=` 分隔线内（`scripts/v2_report_generator.py::generate_v2_summary`，终端与 HTML 共用）
- **predict-v2 备选去重** — `predictors/ensemble.py` 融合时按规范化文本
  （去空白/标点/大小写差异）合并，备选列表不再出现重复模板

### 🧪 测试与工程

- 新增单元测试：`tests/test_core/test_utils.py`（编码检测）、
  `tests/test_mirofish/test_zep_local.py`（建库/统计/幂等/增量/兼容）、
  `tests/test_scripts/test_v2_report_generator.py`（HTML 报告 smoke test + 一句话总结）
- `run_tests.py` 新增 "MiroFish 图谱" 与 "脚本/报告" 套件（124 通过 / 0 失败 / 5 跳过，RAG 依赖未装跳过属正常）
- 版本号统一升级为 2.1.0：`config.json`、各 `__init__.py`、`scripts/main.py`
- 完全向后兼容：v1.2.0 / v2.0.0 所有命令行为不变；所有新终端输出走 `_safe_emoji()`

## v2.0.0 (2026-07-09) - 模块化架构 + 本地 AI 增强

### 🎉 重大升级

v2.0.0 是 v1.2.0 之后的全面重构，**完全保留 v1.2.0 兼容性**，新增模块化架构和本地 AI 能力。

### ✨ 新增功能

#### 核心抽象层（`core/`）
- **Message 统一数据模型** — 替代 v1.2.0 的 dict 形式，支持类型安全的 dataclass
- **AnalysisResult / PredictionResult 统一结果** — 所有分析器和预测器输出统一格式
- **AnalyzerBase 抽象基类** — 所有分析器实现统一接口
- **PredictorBase 抽象基类** — 所有预测器实现统一接口
- **AnalyzerRegistry 注册中心** — 统一调度多个分析器

#### 6 个独立分析器（`analyzers/`）
- **MBTIAnalyzer** — 新置信度算法（维度差距 + 样本量）
  - 旧版 `min(90, 50 + total_score * 1)` 几乎不会低于 60%
  - 新版 `50 + min_gap * 30 + size_factor * 20` 范围 20-95
  - 新增稳定性评分（基于前后半段一致性）
- **BigFiveAnalyzer** — 5 维归一化 + 雷达图数据
  - 补全 neuroticism low 词（冷静、镇定、平和、从容）
- **SentimentAnalyzer** — 完全重写，支持：
  - **jieba 精准分词**（如可用）+ 改进的 fallback 分词
  - **HowNet 情感词典**（446 正面 + 441 负面词条，含强度）
  - **否定识别**（修复 v1.2.0 的"我不开心"误判 bug）
  - **程度副词加权**（很/非常/极其/稍微...）
  - **反讽检测**（虽然...但是... / 说是...其实...）
  - **Emoji 情感映射**（约 200 个 emoji）
  - **情感时间线**（按时序输出）
- **RiskAnalyzer** — 完全重写，支持：
  - **反讽识别**（"投资个生日礼物"等无害场景）
  - **否定排除**（"不[风险词]"模式）
  - **时序突发检测**（消息突然变密集 + 风险词 → 升级告警）
  - **三级风险等级**（low / medium / high）
  - **会话级累积**（风险词 ≥3 次才升级 high）
- **ScenarioAnalyzer** — 4 场景分类（romantic/work/social/important）
- **PatternAnalyzer** — 修复 v1.2.0 的 reply_speed 丢失 bug

#### 词典资源（`analyzers/lexicon/`）
- `hownet_positive.txt` — HowNet 正面情感词典（约 446 词条）
- `hownet_negative.txt` — HowNet 负面情感词典（约 441 词条）
- `negation_words.txt` — 否定词表（中文 + 英文 + 短语）
- `degree_words.txt` — 程度副词（含权重 0.5-3.0）
- `emoji_dict.txt` — Emoji 情感映射（约 200 emoji）
- `jieba_dict/user_dict.txt` — jieba 自定义词典（MBTI/网络用语/职场/投资等）

#### 3 个预测器 + 集成器（`predictors/`）
- **RulePredictor** — 16 MBTI × 5 模板 + 4 场景模板 + 12 关键词触发
- **RAGPredictor** — 基于历史相似对话的检索增强预测
- **MiroFishPredictor** — 8 性格 Agent × N 轮模拟 + 加权投票
- **EnsemblePredictor** — 加权融合：相同文本合并 + 多策略加成

#### RAG 引擎（`rag/`）
- **Embedder** — sentence-transformers 封装（支持 bge-small-zh / bge-base-zh / multilingual）
- **VectorStore** — ChromaDB 持久化
- **Retriever** — top-K 检索 + 元数据过滤 + 上下文窗口拼接
- **完全本地化** — 无需云端 LLM，零数据外传

#### MiroFish 本地化（`mirofish/`）
- **ZepLocalGraph** — 本地图谱（NetworkX + SQLite），替代 Zep Cloud
  - 实体识别（人名/事件/情绪）
  - 关系抽取（喜欢/讨厌/关心）
  - 时序关联
- **MiroFishBridge** — 统一入口
- **AgentFactory** — 8 种性格原型（主动/防守/中立/情感/幽默/理性/感性/实用）
- **Deliberation** — 多轮辩论 + 加权投票

#### 单元测试（`tests/`）
- 12 个测试文件，104 个测试用例，5 个跳过（依赖未安装）
- 关键测试：否定识别（修复 v1.2.0 bug）、MBTI 类型验证、风险检测反讽排除、reply_speed 修复等
- `run_tests.py` 一键运行

#### CLI 新命令
- `version` — 显示 v2.0.0 新特性
- `analyze-v2` — 模块化分析（jieba/否定识别/反讽）
- `predict-v2` — 三层融合预测（Rule + RAG + MiroFish）
- `graph-stats` — MiroFish 本地图谱统计

### ♻️ 重构

- **`text_analyzer.py` (588 行) → 6 个独立分析器** — 拆分为 mbti_analyzer / bigfive_analyzer / sentiment_analyzer / risk_analyzer / scenario_analyzer / pattern_analyzer
- **`conversation_predictor.py` (423 行) → 3 个预测器 + ensemble** — 拆分为 rule_predictor / rag_predictor / mirofish_predictor / ensemble
- **`scripts/main.py`** — 改为同时支持 v1.2.0 旧命令（`analyze/report/schedule/serve/calendar`）和 v2.0.0 新命令
- **`config.json`** — 加入 `rag` / `mirofish` / `privacy` 三个新配置块
- **`SKILL.md` / `README.md`** — 更新到 v2.0.0 文档

### 🐛 Bug 修复

| Bug | 修复 |
|---|---|
| `analyze_conversation_pattern` 中 reply_speed 字段计算后丢失 | PatternAnalyzer 正确返回 `reply_speed` 字段 |
| "我不开心" 被误判为 positive | SentimentAnalyzer 实现否定识别（窗口 + 子串 + 字符级 + 文本级 4 重检测）|
| 风险检测"投资理财"被误报 | RiskAnalyzer 加入 innocent_phrases（投资理财、投资个生日礼物等）|
| MBTI 置信度永远不低于 60% | 新算法 `50 + min_gap * 30 + size_factor * 20`，范围 20-95 |
| 大五 neuroticism 缺 low 词 | 补全冷静/镇定/平和/从容等 8 个 low 词 |
| 分词简陋（"我今天很开心"切成单 token） | 引入 jieba + 改进 fallback 分词（单字/2字/3字） |
| v1.2.0 MiroFish 是空壳（未真正调用） | v2.0.0 通过 MiroFishBridge 真正调用本地 Zep + Agent + Deliberation |

### 🔒 隐私升级

- `config.json` 加入 `privacy.telemetry=false`、`external_api=false`
- 所有 v2.0.0 模块完全本地化（除 RAG 首次下载 embedding 模型）
- LLM API 默认禁用
- MiroFish 默认关闭
- README 加入"100% 本地处理，零外部网络请求"声明

### 📦 依赖变化

#### 核心依赖
- 新增：`jieba>=0.42.1`（中文分词）

#### RAG 引擎（`requirements-rag.txt`，可选）
- `sentence-transformers>=2.2.2`（本地 embedding 模型）
- `chromadb>=0.4.22`（本地向量数据库）
- `numpy>=1.24.0`

#### Web 仪表盘（`requirements-web.txt`，v2.1.0 路线图）
- `fastapi>=0.104.0`
- `uvicorn>=0.24.0`

### ⏳ 延后至 v2.1.0

- FastAPI 后端 + Vue3 前端 + ECharts 可视化仪表盘
- WebSocket 实时进度推送
- 完整 ECharts 图表（情感时间线/人格雷达/热词云/关系演变图）

### 📊 测试结果

```
通过: 104
失败: 0
错误: 0
跳过: 5 (sentence-transformers/chromadb 未安装)
```

### 🗂️ 目录结构变化

```
wechat-analyzer/
├── core/                    # 🆕 核心抽象层
├── analyzers/               # 🆕 6 个独立分析器
│   └── lexicon/            # 🆕 词典资源
├── predictors/              # 🆕 3 个预测器 + Ensemble
├── rag/                     # 🆕 RAG 引擎
├── mirofish/                # 🆕 MiroFish 本地化
├── web/                     # 🆕 Web 层（v2.1.0）
├── tests/                   # 🆕 单元测试
├── scripts/                 # ♻️ 旧脚本（向后兼容）
│   └── archive_v1/          # 📦 v1.2.0 完整快照
├── config.json              # ♻️ v2.0.0 配置
├── requirements.txt         # ♻️ v2.0.0 依赖
├── requirements-rag.txt     # 🆕 RAG 独立依赖
├── requirements-web.txt     # ⏳ v2.1.0 Web 依赖
├── SKILL.md                 # ♻️ v2.0.0
├── README.md                # ♻️ v2.0.0
├── CHANGELOG.md             # 🆕 本文件
└── run_tests.py             # 🆕 测试运行脚本
```

### 🔄 迁移指南

#### 用户使用

```bash
# 旧用户（v1.2.0 兼容）
python scripts/main.py analyze --paste    # 完全兼容

# 新用户（v2.0.0 推荐）
python scripts/main.py analyze-v2 --paste # 体验新特性
python scripts/main.py predict-v2 --paste # 三层预测
```

#### 开发者

如需添加新分析器：
```python
from core.analyzer_base import AnalyzerBase
from core.message import Message
from core.result import AnalysisResult

class MyAnalyzer(AnalyzerBase):
    name = "my_analyzer"
    def validate(self, messages): ...
    def analyze(self, messages, **kwargs) -> AnalysisResult: ...
```

---

## v1.2.0 (2026-05-26) - 基础版本

- MBTI / 大五 / 情感 / 风险 / 日历 基础分析
- LLM API 增强（可选）
- MiroFish 群体智能引擎（高级功能）
- HTML / Word / PPTX 报告生成
- Flask Web 服务
- APScheduler 定时任务

### 已知 Bug（已在 v2.0.0 修复）

- `analyze_conversation_pattern` 中 reply_speed 字段计算后丢失
- "我不开心" 被误判为 positive
- MBTI 置信度永远不低于 60%
- 风险检测"投资理财"等无辜场景被误报
- v1.2.0 MiroFish 是空壳（未真正调用引擎）
- 分词简陋
