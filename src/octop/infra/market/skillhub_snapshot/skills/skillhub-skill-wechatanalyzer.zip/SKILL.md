---
name: skillhub-skill-wechatanalyzer
description: ">"
---

# 微信聊天分析助手 v6.0.0

**话题地图 + 隐私扫描 + 群聊分析 + 跨会话趋势 + 桌面捕获 + 个性化预测的本地工具**

> ## ⚠️ 分析结果仅供参考，**不是专业评估**
>
> MBTI / 大五 / 情感 / 风险 / 关系健康度 / 群聊 / 推演都是**启发式估计**，准确率有限。
> 隐私扫描是**正则识别**，不能保证查全；AI 洞察是基于统计规则的辅助解读，不能用于专业心理评估、职业/感情决策、临床诊断。详见 [FAQ.md](FAQ.md)。

## 🆕 v6.0.0 话题地图 + MCP SDK 兼容

**当前口径**：分析器注册表共 12 个分析器；MCP Server 31 工具（12 分析 + 1 隐私 +
6 AI 洞察 + 3 预测画像 + 3 会话记忆 + 1 导出 + 1 导入 + 3 桌面捕获 + 1 系统）；
CLI 仍为 15 个子命令。

### 新增分析器：话题地图（第 12 个，`analyzers/topic_analyzer.py`）

回答"这段聊天反复在聊什么、谁更爱聊什么、话题在哪一段变了"：

- **关键词** — TF-IDF（词频 × 消息级 IDF），权重归一到 0–100，带 `self_count / other_count`
- **语义主题** — 工作/家庭/感情/健康/购物/美食/娱乐/学习/财务/出行十个可重叠桶，命中才输出
- **人物关注点** — 我 / 对方 / 共同关注 / 各自独有；群聊再按真实昵称拆前 5 人
- **分段与切换** — 按 `session_gap_hours`（默认 4 小时）切会话段，段间 Jaccard < 0.3 记一次话题切换
- **冷热变化** — 按消息顺序对半拆，标出升温/降温词（不是按自然日）
- **分词降级** — 有 jieba 走真实词边界；没有 jieba 时用随包内置高频词表做最长匹配，
  置信度扣分并在正文说明"词表外的未登录专名会漏掉"，不产出假精确词云

配置见 `config.json` 的 `analysis.topic_enabled` 与 `topic` 节（`top_keywords / max_clusters /
session_gap_hours / min_segment_messages / min_messages`）。

### MCP SDK 兼容（mcp 1.x / 2.x）

- 1.x 走 `mcp.server.fastmcp.FastMCP`，2.x 走 `mcp.server.mcpserver.MCPServer`，自动探测
- `get_skill_status` 新增 `mcp_sdk_generation` / `mcp_sdk_label`，兼容问题不用再靠猜
- 新增 `get_topic_analysis` 工具；MCP Server 共 31 工具

### 输出正确性

- `_json()` 超限不再直接切片：先试缩进版，再退紧凑版，仍超限返回合法错误信封，
  调用方 `json.loads` 不会因为半截字符串崩掉

## 🆕 v5.0.0 隐私扫描 + 群聊分析 + 跨会话趋势 + 解析治本

### 正确性修复（这一版的主线）

- **"从聊天窗口直接复制"不再毁掉发送者** — `scripts/data_manager.py`
  - `2024-01-15 14:32:15 张三: 你好` 曾按冒号切句，发送者变成 `2024-01-15 14`
  - 现在先剥行首时间戳再认名字；纯时间戳分隔行、`———`/`***` 装饰行会被丢弃
  - 名字封顶 30 字，正文里的冒号（`他说：你好`）不会被当成名字分隔符
- **self/other 判定统一口径** — 新增 `core.message.is_self_sender()` 为唯一来源
  - 旧 v1 只认 `sender == 'self'`，而两条导入通道给的是"我" → 报告里"你的消息"恒为 0
  - `scripts/llm_analyzer.py` 同样判错，**发给大模型的逐句话把"我"标成了"对方"**
  - `scripts/data_source_importer.py` 删掉自己那份集合，改调用 core，四条通道不再各说各话
  - 只做整名匹配：`我的天`、`我们自己` 这类昵称不会被当成"我"
- **普通散文不再被当成结构化消息** — `_import_container_text` 把 `text:* / simple / unknown` 一律交回逐行解析，守住"裸行算我说的"这条约定
- **产物不落技能包** — RAG 向量库、embedding 缓存、网页截图上传目录、报告目录全部改为**只尊重绝对路径，相对路径归一到运行时数据目录**（`core.data_paths.resolve_data_dir()`）
  - 这四处的默认值都指向 `<技能根>/data/…`，一旦真的跑起来，`.db`/`.index`/`.png` 会被上传通道按二进制文件拦下
- **历史画像会话数不再虚高** — `predictors/history_aware_predictor.py`：关掉 `merge_history` 时不继承旧画像的 `trained_sessions`；种子合并改在 `train()` 重建之后进行

### 新增能力

- **隐私扫描器**（第 11 个分析器，`analyzers/privacy_scanner.py`）— 完全本地正则识别
  - 10 类标签：密钥/口令、身份证号、银行卡号、长数字串、手机号、座机、邮箱、微信号、地址/定位、疑似真实姓名
  - 银行卡走 **Luhn 校验**，订单号/快递号不再误报；命中区间按优先级互斥去重
  - 姓名只认显式声明（`我叫…`/`联系人：…`），试过"X老师/X经理"推断但因中文无词边界误报严重，已删除
  - `mask_privacy_text()` 一键脱敏；`config.privacy_scan.mask_before_llm=true` 时**发往大模型前自动脱敏**
- **群聊分析器**（`analyzers/group_analyzer.py`）— 三人及以上才有意义
  - 成员发言占比/字数/均长 + 活跃度分层 + 主导度 + 点名关系网 + 双人互动平衡度
  - 非群聊时明确标注，不硬凑指标
- **跨会话快照与趋势**（`scripts/session_memory.py` 接入 CLI/MCP）
  - `analyze-v2` 默认存快照，`session --list / --save / --compare` 看变化
  - 显著性判定：`|Δ| ≥ 1.0` 或 `变化率 ≥ 10%`；只写 JSON 行，损坏行与缺 `id` 的行读取时丢弃
  - 快照文件落在运行时数据目录，`session_memory.max_snapshots` 控制保留条数
- **多格式导出**（`scripts/report_exporters.py`）
  - `--markdown` 贴飞书/Notion，`--csv` 一行一个指标给 Excel 透视，`--export` 全量 JSON
  - CSV 用 `utf-8-sig`（Excel 直接双击不乱码），Markdown 不带 BOM
- **CLI 接线** — 新增 `capture`（窗口/剪贴板捕获后直接分析）与 `session` 两个子命令，共 15 个子命令；`analyze-v2` 新增 `--platform / --markdown / --csv / --ai / --label / --no-snapshot`
- **MCP Server 30 工具** — 11 分析 + 6 AI 洞察 + 3 预测画像 + 3 会话记忆 + 1 隐私 + 1 导出 + 1 导入 + 3 桌面捕获 + 1 系统
  - 新增 12 个：`scan_privacy`、`get_group_analysis`、`get_pattern_analysis`、`get_inference_analysis`、`get_interpretation_analysis`、`ai_insight_from_chat`、`list_analysis_sessions`、`save_analysis_session`、`compare_analysis_sessions`、`export_chat_report`、`get_prediction_profile`、`train_reply_predictor`

## 🆕 v4.0.0 桌面微信捕获 + 个性化预测 + 推演增强

- **桌面捕获**（`scripts/clipboard_monitor.py` / `scripts/wechat_window_reader.py`）— Win32 剪贴板实时监控 + UI Automation 窗口读取，自动识别微信格式、增量去重、后台守护线程；MCP 新增 `capture_clipboard` / `capture_wechat_window` / `get_desktop_status`
- **个性化预测**（`predictors/history_aware_predictor.py`）— 从用户真实回复中学习：N-gram 高频短语 + 上下文-回复对 + 风格画像 + 情感-回复映射 + 时段映射
- **融合与推演** — `ensemble.py` 动态置信度权重 + 多样性保障；`rule_predictor.py` 意图链追踪 + 长度自适应回复；`inference_analyzer.py` 新增话题马尔可夫链（转移概率 + 循环检测）与回复时间模式（延迟分析 + 最佳回复窗口）
- **MCP Server 18 工具**

## 🆕 v3.0.0 AI 深度洞察 + 多源数据导入 + MCP Server

- **AI 洞察引擎**（`analyzers/ai_insight_engine.py`）— 把 `config.json` 中默认禁用的 LLM 真正接进来
  - 5 类分析模板：性格解读（personality_insight）/ 情感叙事（emotion_narrative）/ 关系建议（relationship_advice）/ 风险解读（risk_interpretation）/ 预测解释（prediction_explanation）
  - DeepSeek / OpenAI 兼容 / Ollama 自动适配；环境变量 `DEEPSEEK_API_KEY` 优先级最高
  - 隐私脱敏：发送前自动屏蔽手机号/身份证号/银行卡号；聊天内容超 4000 字符自动截断
  - 响应缓存（md5 键）+ 模板化降级 + 免责声明自动追加
- **多源数据导入**（`scripts/data_source_importer.py`）— 智能粘贴 + URL + JSONL
  - 6 平台自动识别：微信 / 企业微信 / QQ / iMessage / 短信 / 邮件
  - 续行支持（消息跨多行自动合并）+ JSONL 每行解析 + JSON 数组导入
  - 完全本地处理，零数据外传
- **MCP Server**（`mcp_server.py`）— 15 工具 stdio 协议
  - 7 分析工具：analyze_chat / get_mbti / bigfive / sentiment / risk / relationship_health / scenario
  - 5 AI 洞察工具：ai_personality_insight / emotion_narrative / relationship_advice / risk_interpretation / prediction_explanation
  - 1 预测工具：predict_reply（Rule + RAG + MiroFish 三层融合）
  - 1 导入工具：import_chat_from_text + 1 系统工具：get_skill_status
- **CLI 接线** — `main.py analyze-v2` 输出新增 AI 洞察章节（需配置 LLM Key）

## 🆕 v2.9.0 分析能力升级 + 语音交互

- **关系健康度分析器**（新第 9 个分析器）— 互动平衡 / 回应度 / 情感同步 / 投入度 / 互动深度五维评分 + 冷回复惩罚 → 0-100 健康分与优秀/良好/一般/需关注四级，附针对性建议；情感同步优先复用 sentiment 己方占比，回退词典评分 → 表情符号统计 → 中性 50（零词典环境仍可用）
- **情感分析增强** — 新增 `rolling_trend` 滚动趋势（窗口≤5 净分移动平均）+ `turning_points` 情感转折点检测（好转/转差与时间点）+ `self_positive/self_negative` 己方情感占比（旧字段全部兼容）
- **语音交互**（`python scripts/main.py voice`）— 七大口语指令（分析文件/预测/演示/自检/报告/日历/图谱）；TTS 三级降级 pyttsx3 → Windows SAPI（PowerShell 5.1 System.Speech，零依赖）→ 终端打印；STT 三级降级 speech_recognition → SAPI 听写 → 打字；无麦克风环境自动降级文本输入；speaker/listener/executor 全部可注入测试；`config.json` 新增 `voice` 配置节（`voice.enabled=false` 可关）
- **CLI 接线** — `main.py` 新增 `voice` 子命令；报告展示新增关系健康度与情感转折点两个段落；`version` 命令同步新特性

## 🆕 v2.8.0 健壮性升级 + 零警告

- **消除非法转义** — `core/utils.py` 正则因引号截断产生隐式字符串拼接，`\[` 成非法转义（DeprecationWarning，3.12+ 将变 SyntaxError），改三引号 raw string
- **Python 3.15 兼容** — `calendar_manager._parse_date` 无年份日期（"08-20"）显式补参考年份，不再依赖 strptime 默认年份（3.15 起行为变更）
- **7 处裸 except 收紧** — 按场景改为 ValueError / OSError / json.JSONDecodeError，不再吞 KeyboardInterrupt
- **全覆盖编译烟囱测试** — 自动扫描全部 .py（编译+警告升错误）+ 裸 except 防回归 + 版本一致性校验
- 测试 329 过 / Python 3.11 与 3.14 双版本零警告

## 能力矩阵

| 能力 | 说明 | 入口 |
|---|---|---|
| **MBTI / 大五人格** | 关键词规则推断 + 维度差距置信度 + 稳定性评分 | `analyze-v2` |
| **情感分析** | jieba 分词 + 否定识别 + 反讽检测 + Emoji 映射 + 滚动趋势/转折点（v2.9） | `analyze-v2` |
| **风险检测** | 4 类风险 + 反讽排除 + 时序突发 + 三级分级 | `analyze-v2` |
| **关系健康度** | 平衡/回应/情感同步/投入/深度五维 + 冷回复惩罚（v2.9 新增） | `analyze-v2` |
| **群聊多主体**（v5） | 发言占比/活跃分层/主导度/点名关系网/双人平衡 | `analyze-v2` |
| **隐私扫描**（v5） | 10 类 PII + 银行卡 Luhn 校验 + 区间去重 + 一键脱敏 | `analyze-v2` / `scan_privacy` |
| **话题地图**（v6） | TF-IDF 关键词 + 语义主题 + 我/对方关注点 + 冷热变化 + 话题切换 | `analyze-v2` / `get_topic_analysis` |
| **对话预测** | Rule + RAG + MiroFish + HistoryAware 四层融合，动态权重 | `predict-v2` |
| **个性化画像**（v5 接线） | 从真实回复学 N-gram/风格/时段，可持久化与再训练 | `train_reply_predictor` |
| **时间感知** | 距最后消息时间/周末/密集节奏调整回复时机 | `predict-v2` |
| **推演 + 解读** | 7 大推演（含马尔可夫链 + 回复时间模式）+ 4 大解读 | `analyze-v2` |
| **跨会话趋势**（v5） | 快照保存/列表/对比 + 显著变化判定 | `session` |
| **多格式导出**（v5） | Markdown / CSV 指标表 / 全量 JSON / 单文件 HTML | `--markdown --csv --export --html` |
| **桌面捕获** | 剪贴板实时监控 + 微信窗口 UI Automation 读取 | `capture` |
| **AI 深度洞察** | 5 类模板，DeepSeek/OpenAI/Ollama，默认关闭 | `--ai` |
| **日历事件** | 从聊天提取约会/截止/提醒/生日/付款/出行 | `calendar` |
| **定时任务** | 每日/周/月/季/年自动生成报告 | `schedule` |
| **报告生成** | 单文件离线 HTML（内联 SVG 图表） | `--html` |
| **文件导入** | txt/json/docx/pdf，编码自动检测 | `--input` |

## 使用说明

### 分析与导出

```bash
python scripts/main.py analyze-v2 --paste                          # 粘贴分析（自动识别格式）
python scripts/main.py analyze-v2 --input 聊天记录.txt               # 文件分析（自动识别编码）
python scripts/main.py analyze-v2 --input 记录.txt --platform wechat # 自动识别不准时手工指定
python scripts/main.py analyze-v2 --paste --markdown r.md          # Markdown 报告
python scripts/main.py analyze-v2 --paste --csv r.csv              # CSV 指标表（Excel 双击不乱码）
python scripts/main.py analyze-v2 --paste --html r.html            # 单文件离线 HTML
python scripts/main.py analyze-v2 --paste --ai --label 和TA         # 追加 AI 洞察 + 存快照备注
python scripts/main.py analyze-v2 --paste --no-snapshot            # 本次不进快照
```

### 跨会话趋势（v5.0.0）

```bash
python scripts/main.py session --list                # 历史快照（默认列 20 条）
python scripts/main.py session --save --label 第一阶段
python scripts/main.py session --compare             # 与上一次比
python scripts/main.py session --compare --id 20261015_1432  # 与指定快照比
```

### 桌面捕获与预测

```bash
python scripts/main.py capture                       # 读微信窗口并直接分析（Windows）
python scripts/main.py capture --source clipboard --seconds 30   # 监听剪贴板 30 秒
python scripts/main.py predict-v2 --paste            # 四层融合对话预测
python scripts/main.py graph-stats                   # MiroFish 本地图谱统计
python scripts/main.py report-v2 --format csv        # 用最近一次结果重出报告
```

### 其他命令

```bash
python scripts/main.py demo                    # 一键体验内置示例
python scripts/main.py doctor                  # 环境自检（依赖/config/编码）
python scripts/main.py voice                   # 语音交互（v2.9，说/打字均可）
python scripts/main.py calendar --list         # 日历事件
python scripts/main.py schedule --list         # 定时任务
python scripts/main.py version                 # 查看版本
```

### v1.2.0 命令（向后兼容）

`analyze` / `report` / `schedule` / `serve` / `calendar` 全部保留，行为不变。

## 隐私与配置

- **100% 本地计算**，零外部网络请求（首次下载 embedding 模型除外）
- **运行时数据**（数据库、向量库、模型缓存、报告、截图、快照、画像）默认存系统 tempdir，`WECHAT_ANALYZER_DATA_DIR` 环境变量可覆盖；配置里的**相对路径不会落回技能包**，只有绝对路径被采纳
- **发往大模型前先脱敏**：`privacy_scan.mask_before_llm=true`（默认开）会把手机号/身份证/银行卡/邮箱替换成占位符
- **可选能力**：RAG（`rag.enabled=false` 关闭）/ MiroFish（`mirofish.enabled=true` 启用）/ LLM（默认禁用，隐私优先）/ 群聊（`group.enabled`）/ 隐私扫描（`privacy_scan.enabled`）/ 会话记忆（`session_memory.enabled`）
- **上传前** `python clean.py --check` 检查残留（退出码 1=有残留），`python clean.py` 一键清理

## 常见问题

**Q: 粘贴进来全是"unknown"发送者 / 分析器一个都不跑？** A: v5.0.0 修复了行首时间戳被切成发送者的问题，直接用 `analyze-v2 --paste` 粘贴微信窗口的复制内容即可；自动识别不准时用 `--platform wechat` 指定。

**Q: 隐私扫描说没风险就安全吗？** A: 不一定。它是**正则识别**，只覆盖格式明确的 10 类信息，认不出"我家住XX小区3栋"以外的隐式表述；查全率有限，重要场景仍需人工过一遍。

**Q: 群聊分析两个人能用吗？** A: 能跑但没意义，`is_group` 会是 false 并给出说明；`group_chat.min_members` 默认 3。

**Q: 话题地图的词为什么有的没认出来 / 没装 jieba 准不准？** A: 有 jieba 时按真实词边界统计；没有 jieba 时按随包内置高频词表做最长匹配，词表外的未登录专名会漏掉，置信度也会打折，正文会明确标注。想要更细的结果请 `pip install jieba`。

**Q: GBK 编码读取报错？** A: v2.1.0 起自动识别 utf-8-sig / utf-8 / gb18030，直接传入即可。

**Q: 大五人格全是 100%？** A: 已修复归一化，小样本收缩到 50 附近，信号充分时落在 15~85 区间。

**Q: 首次运行很慢？** A: RAG 首次需下载 embedding 模型（50-100MB），之后秒开。

**Q: 环境出问题怎么排查？** A: `python scripts/main.py doctor` 逐项检查并给修复建议。

**Q: v2 和 v1.2.0 结果不一致？** A: 正常，v2 引入 jieba 分词、否定识别等，更准确。

**Q: `ModuleNotFoundError: No module named 'dotenv'`？** A: 只有直接导入 `scripts/mirofish_services_*.py` 时才会碰到（`scripts/mirofish_config.py` 顶层依赖 `python-dotenv`，未列入任何 requirements，且 `Config.UPLOAD_FOLDER` 从未定义）。这套服务在当前版本**没有任何入口引用**（CLI/MCP 都不导入），需要自行补依赖后才能启用，详见 [RUNBOOK.md](RUNBOOK.md) 的"已知问题"。

## 依赖安装

```bash
pip install -r requirements.txt          # 核心（必须：jieba/Flask/docx/pptx）
pip install -r requirements-rag.txt      # RAG（可选：sentence-transformers/chromadb）
python scripts/main_setup.py             # 一键配置
```

## 版本历史

- **v6.0.0** 话题地图 + MCP SDK 兼容：`topic_analyzer`（TF-IDF 关键词 / 语义主题 / 说话人关注点 / 分段切换 / 冷热变化 / 无 jieba 词表降级）+ MCP 新增 `get_topic_analysis`（30→31 工具）+ 兼容 mcp 1.x/2.x + JSON 超限不再产生半截输出
- **v5.0.0** 隐私扫描 + 群聊分析 + 跨会话趋势 + 解析治本：`privacy_scanner`（10 类 PII / Luhn 校验 / 一键脱敏）+ `group_analyzer`（占比 / 分层 / 点名网 / 双人平衡）+ session_memory 与 report_exporters 接入 CLI/MCP + 行首时间戳粘贴格式修复 + `is_self_sender` 统一 self/other 口径 + 运行产物移出技能包 + MCP 18→30 工具
- **v4.0.0** 桌面微信捕获 + 历史感知个性化预测 + 马尔可夫/时间模式推演：clipboard_monitor + wechat_window_reader + history_aware_predictor + ensemble 动态权重（MCP 15→18 工具）
- **v3.0.0** AI 深度洞察 + 多源数据导入 + MCP Server：ai_insight_engine（5 类模板/DeepSeek 真实接通）+ data_source_importer（智能粘贴/URL/JSONL）+ mcp_server（15 工具）
- **v2.9.0** 分析能力升级 + 语音交互：关系健康度五维分析器 + 情感滚动趋势/转折点 + SAPI 零依赖语音会话
- **v2.8.0** 零警告：非法转义修复 + Python 3.15 日期兼容 + 裸 except 收紧 + 编译烟囱测试
- **v2.7.0** scheduler 建表修复 + 日历/调度测试补全
- **v2.6.0** 上传修复（.pyc/.db 二进制治本，`core/data_paths.py` 统一路径）
- **v2.5.0** 五 bug 修复 + 友好错误全链路 + 版本号单一来源
- **v2.4.0** jieba 情感修复 + 测试补全
- **v2.3.0** 时间感知对话预测
- **v2.2.0** 推演 + 信息解读（10 大子能力）
- **v2.1.0** 本地图谱 + 编码检测 + 单文件 HTML 报告

> 完整功能说明见 [README.md](README.md) | 新手速查见 [RUNBOOK.md](RUNBOOK.md) | 更多问答与故障排查见 [FAQ.md](FAQ.md) | 变更记录见 [CHANGELOG.md](CHANGELOG.md)
