#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v6.0.0 话题地图测试

覆盖三条线：
    1. 有 jieba / 无 jieba 两条分词路径都要产出可用关键词，不能因为环境
       缺 jieba 就退化成一份假词云。
    2. 说话人拆分、群成员拆分、分段与话题切换必须真的按 Message 计算，
       而不是把所有人折成 other。
    3. 接线层（HTML 卡片 / 一句话总结 / Markdown-CSV 导出）不能再把 topic
       当成未知分析器丢掉。
"""

import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest import mock

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.dont_write_bytecode = True

from analyzers import create_default_registry
from analyzers import topic_analyzer as topic_module
from analyzers.topic_analyzer import (
    CHAT_STOPWORDS, TOPIC_HINTS, TopicAnalyzer, _fallback_lexicon,
)
from core.message import Message, MessageType


def _msgs(pairs, gap_at=None, gap_hours=6):
    """[(sender, content)] → Message 列表；gap_at 处插入时间断层。"""
    base = datetime(2026, 3, 1, 9, 0, 0)
    moment = base
    messages = []
    for idx, (sender, content) in enumerate(pairs):
        if gap_at is not None and idx == gap_at:
            moment += timedelta(hours=gap_hours)
        messages.append(Message(
            sender=sender, content=content, timestamp=moment,
            message_type=MessageType.TEXT, raw=f"{sender}: {content}",
        ))
        moment += timedelta(minutes=1)
    return messages


WORK_CHAT = [
    ("我", "项目会议定在周一，客户需求还要再确认"),
    ("对方", "好的，我把方案和排期发你，需求我来跟进"),
    ("我", "加班到九点，客户又改需求了"),
    ("对方", "别太累，项目上线前先保重身体"),
    ("我", "咖啡续命，会议室再约一次"),
    ("对方", "我订了咖啡，会议前对一下项目方案"),
    ("我", "客户说周末要看到排期"),
    ("对方", "那我们把方案再压缩一下"),
    ("我", "项目上线时间不能改"),
    ("对方", "明白，我今晚把客户需求整理完"),
]


class TestTopicAnalyzer(unittest.TestCase):

    def setUp(self):
        self.analyzer = TopicAnalyzer({"topic": {"top_keywords": 20}})

    def _analyze(self, pairs=None, **kwargs):
        return self.analyzer.analyze(_msgs(pairs or WORK_CHAT, **kwargs))

    # ------------------------------------------------------------------
    # 基础产出
    # ------------------------------------------------------------------
    def test_validate_needs_enough_text(self):
        self.assertFalse(self.analyzer.validate(_msgs([("我", "在吗"), ("对方", "嗯")])))
        self.assertTrue(self.analyzer.validate(_msgs(WORK_CHAT)))

    def test_available_and_ranked_keywords(self):
        details = self._analyze().details
        self.assertTrue(details["available"])
        self.assertEqual(details["message_count"], len(WORK_CHAT))
        keywords = details["keywords"]
        self.assertTrue(keywords)
        weights = [item["weight"] for item in keywords]
        self.assertEqual(weights, sorted(weights, reverse=True))
        self.assertLessEqual(max(weights), 100.0)
        self.assertGreater(min(weights), 0.0)
        for item in keywords:
            self.assertGreaterEqual(len(item["word"]), 2)
            self.assertGreater(item["count"], 0)
            self.assertGreaterEqual(item["df"], 1)

    def test_meaningful_work_terms_survive(self):
        words = [item["word"] for item in self._analyze().details["keywords"]]
        hits = {"项目", "需求", "客户", "会议", "方案"} & set(words)
        self.assertGreaterEqual(len(hits), 3, f"工作词被清光：{words[:15]}")

    def test_stopwords_and_sender_names_excluded(self):
        details = self._analyze().details
        words = {item["word"] for item in details["keywords"]}
        self.assertFalse(words & CHAT_STOPWORDS, words & CHAT_STOPWORDS)

        # 发言人昵称恰好是普通词时，不能把它当成话题
        pairs = [("咖啡", "今天喝咖啡") for _ in range(6)]
        result = TopicAnalyzer().analyze(_msgs(pairs))
        self.assertNotIn("咖啡", {w["word"] for w in result.details.get("keywords", [])})

    def test_private_strings_and_numbers_excluded(self):
        pairs = [
            ("我", f"项目会议需求 {i} 身份证 110101199003074512 手机 13812345678")
            for i in range(7)
        ]
        words = [item["word"] for item in TopicAnalyzer().analyze(_msgs(pairs)).details["keywords"]]
        for word in words:
            self.assertFalse(any(ch.isdigit() for ch in word), word)
            self.assertNotIn("@", word)

    # ------------------------------------------------------------------
    # 主题 / 人物 / 群聊
    # ------------------------------------------------------------------
    def test_topics_are_labelled_and_share_computed(self):
        details = self._analyze().details
        topics = details["topics"]
        self.assertTrue(topics)
        self.assertIn(details["primary_topic"], TOPIC_HINTS)
        self.assertEqual(details["primary_topic"], topics[0]["name"])
        for entry in topics:
            self.assertIn(entry["name"], TOPIC_HINTS)
            self.assertGreater(entry["messages"], 0)
            self.assertGreater(entry["share"], 0)
            self.assertLessEqual(entry["share"], 100)
            for word in entry["top_keywords"]:
                self.assertGreater(word["count"], 0)

    def test_speaker_split_is_not_all_merged(self):
        by_speaker = self._analyze().details["by_speaker"]
        self.assertTrue(by_speaker["self"])
        self.assertTrue(by_speaker["other"])
        self_true = {item["word"] for item in by_speaker["self"]}
        other = {item["word"] for item in by_speaker["other"]}
        self.assertEqual(set(by_speaker["shared"]), self_true & other)
        self.assertEqual(set(by_speaker["self_only"]), self_true - other)
        self.assertEqual(set(by_speaker["other_only"]), other - self_true)
        # 1:1 不硬拆"成员"，否则 "对方" 会被当成群成员列出来
        self.assertEqual(by_speaker["members"], [])

    def test_group_members_use_real_nicknames(self):
        pairs = [
            ("我", "项目会议定在周一"),
            ("张三", "客户需求我来跟进，方案下午发"),
            ("李四", "火锅店我订好了，电影票也买了"),
            ("王五", "论文还没写完，考试周太忙"),
            ("张三", "客户那边我再催一下方案"),
            ("李四", "电影改到晚上八点"),
            ("王五", "考试复习资料发群里了"),
            ("我", "会议室我来订"),
        ]
        members = TopicAnalyzer().analyze(_msgs(pairs)).details["by_speaker"]["members"]
        self.assertEqual({m["sender"] for m in members}, {"张三", "李四", "王五"})
        for member in members:
            self.assertGreaterEqual(member["messages"], 1)
            self.assertTrue(member["top_keywords"])
            self.assertLessEqual(len(member["top_keywords"]), 3)

    # ------------------------------------------------------------------
    # 分段 / 冷热 / 确定性
    # ------------------------------------------------------------------
    def test_timestamp_gap_splits_segments(self):
        details = self._analyze(gap_at=5, gap_hours=6).details
        segments = details["segments"]
        self.assertGreaterEqual(len(segments), 2)
        self.assertEqual(segments[0]["start_index"], 0)
        self.assertEqual(segments[-1]["end_index"], len(WORK_CHAT) - 1)
        for seg in segments:
            self.assertGreaterEqual(seg["messages"], 2)
            self.assertTrue(seg["start"] and seg["end"])

    def test_topic_shift_detected_on_disjoint_keywords(self):
        shifts = self.analyzer._topic_shifts([
            {"start": "a", "top_keywords": [{"word": "项目", "count": 3}]},
            {"start": "b", "top_keywords": [{"word": "火锅", "count": 3}]},
        ])
        self.assertEqual(len(shifts), 1)
        self.assertEqual(shifts[0]["from"], "项目")
        self.assertEqual(shifts[0]["to"], "火锅")
        self.assertLess(shifts[0]["overlap"], 0.3)

    def test_trend_compares_message_halves(self):
        pairs = [("我", "论文考试复习")] * 5 + [("对方", "火锅电影旅行")] * 5
        trend = TopicAnalyzer().analyze(_msgs(pairs)).details["trend"]
        self.assertIn("火锅", {x["word"] for x in trend["rising"]})
        self.assertIn("论文", {x["word"] for x in trend["declining"]})
        self.assertTrue(trend["note"])

    def test_repeated_runs_are_deterministic(self):
        first = self._analyze().details
        second = self._analyze().details
        self.assertEqual(first["keywords"], second["keywords"])
        self.assertEqual(first["topics"], second["topics"])
        self.assertEqual(first["segments"], second["segments"])
        self.assertEqual(first["topic_shifts"], second["topic_shifts"])

    # ------------------------------------------------------------------
    # 降级与无内容
    # ------------------------------------------------------------------
    def test_fallback_lexicon_is_bundled(self):
        lexicon, longest = _fallback_lexicon()
        self.assertGreater(len(lexicon), 5000)
        self.assertGreaterEqual(longest, 2)
        self.assertIn("项目", lexicon)
        self.assertIn("需求", lexicon)

    def test_no_jieba_path_still_produces_real_words(self):
        with mock.patch.object(topic_module, "HAS_JIEBA", False):
            details = self.analyzer.analyze(_msgs(WORK_CHAT)).details
        self.assertTrue(details["available"])
        self.assertEqual(details["tokenizer"], "fallback")
        self.assertIn("jieba", details["tokenizer_note"])
        words = [item["word"] for item in details["keywords"]]
        self.assertTrue(words)
        self.assertEqual(words, [w for w in words if len(w) >= 2])
        self.assertIn("项目", words)
        lexicon, _ = _fallback_lexicon()
        for item in details["keywords"]:
            if item["word"] in lexicon or item["word"].isascii():
                continue
            self.assertGreaterEqual(
                item["df"], 2,
                f"词表外候选只出现一次却进了榜：{item['word']}")

    def test_all_stopwords_is_unavailable(self):
        pairs = [("我", "好的 收到 谢谢 晚安 早安") for _ in range(6)]
        details = TopicAnalyzer().analyze(_msgs(pairs)).details
        self.assertFalse(details["available"])
        self.assertIn("reason", details)

    # ------------------------------------------------------------------
    # 注册与接线
    # ------------------------------------------------------------------
    def test_registered_by_default(self):
        self.assertIn("topic", create_default_registry().list())
        disabled = create_default_registry({"analysis": {"topic_enabled": False}})
        self.assertNotIn("topic", disabled.list())

    def test_report_card_and_summary_use_topic(self):
        from scripts.v2_report_generator import (
            _render_topic_card, generate_v2_summary,
        )
        details = self._analyze().details
        card = _render_topic_card(details)
        self.assertIn("话题地图", card)
        self.assertIn("高频话题词", card)
        self.assertIn("关注点", card)
        self.assertEqual(_render_topic_card({"available": False}), "")

        summary = generate_v2_summary({"topic": self._analyze().to_dict()})
        self.assertIn("高频话题是", summary)

    def test_exporter_has_topic_facts(self):
        from scripts.report_exporters import _analyzer_facts
        result = self._analyze()
        facts = _analyzer_facts("topic", result.to_dict())
        labels = [label for label, _value in facts]
        self.assertIn("主主题", labels)
        self.assertIn("话题集中度", labels)
        self.assertIn("分词方式", labels)
        self.assertIn("关键词", labels)
        values = dict(facts)
        self.assertTrue(values["主主题"])
        self.assertTrue(values["关键词"])


# LOGGING_AND_COMMENTS_DECISIONS:
# 测试文件不写日志：断言失败信息本身就是诊断输出，再打日志只会淹没 pytest 的
# 定位信息。注释只保留"为什么必须测这条"（缺 jieba 不能出假词云、群成员不能
# 折成 other、接线层不能丢 topic），不复述断言动作。
if __name__ == "__main__":
    unittest.main()
