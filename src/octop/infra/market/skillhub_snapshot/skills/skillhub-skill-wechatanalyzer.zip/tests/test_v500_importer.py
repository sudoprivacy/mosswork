# -*- coding: utf-8 -*-
"""
v5.0.0 导入通道测试 (test_v500_importer.py)

覆盖新增的两条导入路径：
- WeChatHtmlImporter  聊天记录 HTML 导出（结构化层 + 纯文本兜底）
- DelimitedImporter   CSV / TSV 表格导出
以及 MultiSourceImporter 的路由、import_file 的扩展名分发、
to_core_messages 的时间戳透传。

完全 stdlib，无网络、无外部依赖。
"""
import datetime
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))


STRUCTURED_HTML = """<!DOCTYPE html>
<html><body>
<div class="chat">
  <div class="message-row">
    <span class="sender">我</span>
    <span class="time">2024-03-01 09:12:00</span>
    <div class="content">周末有空吗</div>
  </div>
  <div class="message-row">
    <span class="nickname">小李</span>
    <span class="time">2024-03-01 09:15:30</span>
    <div class="content">有啊，去哪</div>
  </div>
</div>
</body></html>"""

# 只有一条带 content 节点：结构化层凑不够 2 条，必须降级到纯文本层
FALLBACK_HTML = """<html><body>
<p>2024-03-01 09:12 我</p>
<p>周末有空吗</p>
<p>2024-03-01 09:15 小李</p>
<p>有啊，去哪</p>
</body></html>"""

CSV_TEXT = """发送者,时间,内容,设备
我,2024-03-01 09:12:00,周末有空吗,iPhone
小李,2024-03-01 09:15:30,有啊，去哪,Android
我,2024-03-01 09:16:00,爬山怎么样,iPhone"""


class TestHtmlDetection(unittest.TestCase):

    def test_detects_doctype_and_html(self):
        from data_source_importer import WeChatHtmlImporter
        self.assertTrue(WeChatHtmlImporter.looks_like_html(STRUCTURED_HTML))
        self.assertTrue(WeChatHtmlImporter.looks_like_html("<html><body>x</body></html>"))
        self.assertTrue(WeChatHtmlImporter.looks_like_html("  <!DOCTYPE HTML>..."))

    def test_plain_paste_is_not_html(self):
        from data_source_importer import WeChatHtmlImporter
        self.assertFalse(WeChatHtmlImporter.looks_like_html("我: 你好\n对方: 在吗"))
        self.assertFalse(WeChatHtmlImporter.looks_like_html(""))
        self.assertFalse(WeChatHtmlImporter.looks_like_html(None))

    def test_leading_body_tag_still_counts(self):
        """有些导出工具不写 <html>，只从 <body> 开始。"""
        from data_source_importer import WeChatHtmlImporter
        self.assertTrue(WeChatHtmlImporter.looks_like_html("<body><div class='content'>x</div></body>"))


class TestHtmlStructuralParse(unittest.TestCase):

    def test_parses_sender_time_content(self):
        from data_source_importer import WeChatHtmlImporter
        msgs = WeChatHtmlImporter.parse(STRUCTURED_HTML)
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0].sender, "我")
        self.assertEqual(msgs[0].content, "周末有空吗")
        self.assertEqual(msgs[0].timestamp, "2024-03-01 09:12:00")
        self.assertEqual(msgs[1].sender, "小李")

    def test_role_mapping_from_sender(self):
        from data_source_importer import WeChatHtmlImporter
        msgs = WeChatHtmlImporter.parse(STRUCTURED_HTML)
        self.assertEqual(msgs[0].role, "self")
        self.assertEqual(msgs[1].role, "unknown")

    def test_script_style_never_leaks_into_content(self):
        """导出页里的 JS/CSS 如果被当成消息，报告里会出现一堆代码。"""
        from data_source_importer import WeChatHtmlImporter
        html = STRUCTURED_HTML.replace(
            "</body>",
            "<script>var trackingToken = 'UA-0000-1';</script>"
            "<style>.bubble{color:red}</style></body>")
        msgs = WeChatHtmlImporter.parse(html)
        joined = " ".join(m.content for m in msgs)
        self.assertNotIn("trackingToken", joined)
        self.assertNotIn("color:red", joined)

    def test_falls_back_to_plaintext_when_structural_thin(self):
        from data_source_importer import WeChatHtmlImporter
        msgs = WeChatHtmlImporter.parse(FALLBACK_HTML)
        self.assertGreaterEqual(len(msgs), 2)
        self.assertTrue(any("周末有空吗" in m.content for m in msgs))

    def test_empty_input(self):
        from data_source_importer import WeChatHtmlImporter
        self.assertEqual(WeChatHtmlImporter.parse(""), [])
        self.assertEqual(WeChatHtmlImporter.parse("   "), [])


class TestStripHtml(unittest.TestCase):

    def test_drops_tags_keeps_text(self):
        from data_source_importer import strip_html
        out = strip_html("<div><p>你好</p><p>在吗</p></div>")
        self.assertIn("你好", out)
        self.assertIn("在吗", out)
        self.assertNotIn("<p>", out)

    def test_drops_script_block(self):
        from data_source_importer import strip_html
        out = strip_html("<p>hi</p><script>alert(1)</script>")
        self.assertNotIn("alert", out)

    def test_decodes_entities(self):
        from data_source_importer import strip_html
        self.assertIn("&", strip_html("<p>a &amp; b</p>"))


class TestDelimitedDetection(unittest.TestCase):

    def test_real_csv_is_detected(self):
        from data_source_importer import DelimitedImporter
        self.assertTrue(DelimitedImporter.looks_delimited(CSV_TEXT))

    def test_ordinary_paste_with_commas_is_not_csv(self):
        """聊天正文里全是逗号，误判会把整段对话解析成表格。"""
        from data_source_importer import DelimitedImporter
        text = ("我: 今天好累，晚上，一起吃点东西吧，你看行不行\n"
                "对方: 好呀，那我们去，那家新开的店，人应该不多\n"
                "我: 行，六点，老地方见，别迟到啊")
        self.assertFalse(DelimitedImporter.looks_delimited(text))

    def test_header_without_both_columns_is_not_csv(self):
        from data_source_importer import DelimitedImporter
        text = "a,b,c\n1,2,3\n4,5,6"
        self.assertFalse(DelimitedImporter.looks_delimited(text))

    def test_two_rows_is_not_enough(self):
        from data_source_importer import DelimitedImporter
        self.assertFalse(DelimitedImporter.looks_delimited("sender,content\nme,hi"))


class TestDelimitedParse(unittest.TestCase):

    def test_maps_columns_and_extra_metadata(self):
        from data_source_importer import DelimitedImporter
        msgs = DelimitedImporter.parse(CSV_TEXT)
        self.assertEqual(len(msgs), 3)
        self.assertEqual(msgs[0].sender, "我")
        self.assertEqual(msgs[0].content, "周末有空吗")
        self.assertEqual(msgs[0].timestamp, "2024-03-01 09:12:00")
        self.assertEqual(msgs[0].metadata.get("设备"), "iPhone")

    def test_quoted_comma_survives(self):
        from data_source_importer import DelimitedImporter
        text = 'sender,content\nme,"你好，世界"'
        msgs = DelimitedImporter.parse(text)
        self.assertEqual(len(msgs), 1)
        self.assertEqual(msgs[0].content, "你好，世界")

    def test_tsv_dialect(self):
        from data_source_importer import DelimitedImporter
        self.assertEqual(DelimitedImporter.sniff_dialect("a\tb\tc"), "\t")
        self.assertEqual(DelimitedImporter.sniff_dialect("a;b;c"), ";")
        self.assertEqual(DelimitedImporter.sniff_dialect("a,b,c"), ",")
        msgs = DelimitedImporter.parse("sender\tcontent\nme\thi\nyou\tyo")
        self.assertEqual([m.content for m in msgs], ["hi", "yo"])

    def test_blank_and_contentless_rows_skipped(self):
        from data_source_importer import DelimitedImporter
        text = "sender,content\nme,hi\n,\nyou,\nher,ok"
        msgs = DelimitedImporter.parse(text)
        self.assertEqual([m.content for m in msgs], ["hi", "ok"])

    def test_chinese_and_english_headers(self):
        """各家导出工具的表头语言不固定，中英文都要认出来。"""
        from data_source_importer import DelimitedImporter
        for header in ("发送者,消息内容", "From,Body", "昵称,正文"):
            msgs = DelimitedImporter.parse(f"{header}\n张三,你好")
            self.assertEqual(len(msgs), 1, header)
            self.assertEqual(msgs[0].sender, "张三", header)
            self.assertEqual(msgs[0].content, "你好", header)

    def test_empty_input(self):
        from data_source_importer import DelimitedImporter
        self.assertEqual(DelimitedImporter.parse(""), [])
        self.assertEqual(DelimitedImporter.parse("only,header\n"), [])


class TestMultiSourceRouting(unittest.TestCase):

    def test_auto_routes_html(self):
        from data_source_importer import MultiSourceImporter
        result = MultiSourceImporter().import_text(STRUCTURED_HTML)
        self.assertTrue(result.success)
        self.assertEqual(result.source, "wechat_html")
        self.assertEqual(result.metadata["detected_platform"], "wechat_html")
        self.assertEqual(len(result.messages), 2)

    def test_auto_routes_csv(self):
        from data_source_importer import MultiSourceImporter
        result = MultiSourceImporter().import_text(CSV_TEXT)
        self.assertTrue(result.success)
        self.assertEqual(result.source, "csv")
        self.assertEqual(len(result.messages), 3)

    def test_auto_still_handles_plain_paste(self):
        from data_source_importer import MultiSourceImporter
        result = MultiSourceImporter().import_text("我: 你好\n对方: 在吗")
        self.assertTrue(result.success)
        self.assertTrue(result.source.startswith("text:"))
        self.assertEqual(result.metadata["detected_platform"], "simple")
        self.assertEqual(len(result.messages), 2)

    def test_explicit_platform_overrides_detection(self):
        from data_source_importer import MultiSourceImporter
        result = MultiSourceImporter().import_text(STRUCTURED_HTML, platform="simple")
        self.assertTrue(result.source.startswith("text:"))

    def test_import_file_dispatches_by_extension(self):
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        tmp = tempfile.mkdtemp(prefix="wa_v5_importer_")
        try:
            html_path = os.path.join(tmp, "chat.html")
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(STRUCTURED_HTML)
            res = importer.import_file(html_path)
            self.assertEqual(res.source, "wechat_html")
            self.assertEqual(len(res.messages), 2)

            csv_path = os.path.join(tmp, "chat.csv")
            with open(csv_path, "w", encoding="utf-8") as f:
                f.write(CSV_TEXT)
            res = importer.import_file(csv_path)
            self.assertEqual(res.source, "csv")
            self.assertEqual(len(res.messages), 3)

            txt_path = os.path.join(tmp, "chat.txt")
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write("我: 你好\n对方: 在吗")
            res = importer.import_file(txt_path)
            self.assertTrue(res.source.startswith("text:"))
        finally:
            for name in os.listdir(tmp):
                os.remove(os.path.join(tmp, name))
            os.rmdir(tmp)

    def test_import_file_missing_returns_error(self):
        from data_source_importer import MultiSourceImporter
        result = MultiSourceImporter().import_file("Z:/nope/not-here.html")
        self.assertFalse(result.success)
        self.assertIn("文件不存在", result.error)


class TestCoreMessageConversion(unittest.TestCase):

    def test_timestamp_becomes_real_datetime(self):
        """v5.0.0 之前 to_core_messages 丢掉 timestamp，回复延迟/趋势分析全拿默认值。"""
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        result = importer.import_text(CSV_TEXT)
        core_msgs = importer.to_core_messages(result.messages)
        self.assertTrue(core_msgs)
        self.assertIsInstance(core_msgs[0].timestamp, datetime.datetime)
        self.assertEqual(core_msgs[0].timestamp.year, 2024)

    def test_missing_timestamp_stays_none(self):
        """解析不出时间就留 None，不能塞 now()——那会让所有消息"刚刚发出"。"""
        from data_source_importer import MultiSourceImporter, ParsedMessage
        importer = MultiSourceImporter()
        core_msgs = importer.to_core_messages([ParsedMessage(sender="我", content="hi")])
        self.assertIsNone(core_msgs[0].timestamp)

    def test_role_and_raw_metadata(self):
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        result = importer.import_text("我: 你好\n小李: 在吗")
        core_msgs = importer.to_core_messages(result.messages)
        self.assertTrue(core_msgs[0].is_self())


if __name__ == "__main__":
    unittest.main()
