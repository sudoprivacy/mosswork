"""文档数字对账闸：SKILL.md 里的能力数字必须能从代码量出来。

v3/v4 连着两版把 MCP 工具数写陈旧（文档停在 15/18，代码早就不止），数字一旦
和代码分家，之后每次升级都会继续错下去。这里把几个能机械核对的数字钉住：
改了代码没改文档、或文档吹了没有的能力，都会红。
"""

import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DOCS = ["SKILL.md", "README.md", "FAQ.md", "RUNBOOK.md"]

# 文档正文里点名的"非 MCP 工具"反引号词，工具存在性检查要跳过
_NON_TOOL_TOKENS = {
    "personality_insight", "emotion_narrative", "relationship_advice",
    "risk_interpretation", "prediction_explanation", "mask_privacy_text",
    "is_self_sender", "resolve_data_dir", "mask_before_llm", "max_snapshots",
    "min_members", "trained_sessions", "history_aware", "privacy_scan",
    "session_memory", "group_chat", "group_analyzer", "privacy_scanner",
    "data_source_importer", "clipboard_monitor", "wechat_window_reader",
    "history_aware_predictor", "report_exporters", "ai_insight_engine",
    "data_manager", "llm_analyzer", "text_analyzer", "mcp_server",
}

_TOOL_PREFIXES = ("get_", "ai_", "capture_", "analyze_", "predict_",
                  "import_", "export_", "scan_", "list_", "save_",
                  "compare_", "train_")


def _skill_md() -> str:
    return (ROOT / "SKILL.md").read_text(encoding="utf-8")


def _current_body() -> str:
    """只留下"当前口径"的段落。

    `## 🆕 v3/v4/...` 各版本小节和「版本历史」里的 15/18 工具是历史事实，
    拿现在的数字去要求它们会把文档改成谎话；但它们不能反过来当现状用。
    """
    from core.version import __version__
    text = _skill_md().split("---", 2)[2]
    kept, skipping = [], False
    for line in text.split("\n"):
        head = re.match(r"^##\s+🆕\s+v([\d.]+)", line)
        if head or line.startswith("## 版本历史"):
            skipping = bool(head and head.group(1) != __version__) or \
                       line.startswith("## 版本历史")
        if not skipping:
            kept.append(line)
    return "\n".join(kept)


def _mcp_tools() -> set:
    src = (ROOT / "mcp_server.py").read_text(encoding="utf-8")
    return set(re.findall(r"@server\.tool\(\)\n(?:async )?def (\w+)", src))


def _cli_commands() -> set:
    src = (ROOT / "scripts" / "main.py").read_text(encoding="utf-8")
    return set(re.findall(r"subparsers\.add_parser\(['\"]([\w-]+)['\"]", src))


def _analyzer_names() -> set:
    from analyzers import create_default_registry
    return set(create_default_registry().list())


class TestFactsFromCode(unittest.TestCase):

    def test_mcp_tool_count_is_documented(self):
        n = len(_mcp_tools())
        self.assertGreaterEqual(n, 31, "MCP 工具数量不应回退")
        self.assertIn(f"MCP Server {n} 工具", _current_body(),
                      f"SKILL.md 未提到当前 MCP 工具数 {n}")

    def test_cli_subcommand_count_is_documented(self):
        cmds = _cli_commands()
        for required in ("analyze-v2", "capture", "session", "voice", "doctor"):
            self.assertIn(required, cmds, f"CLI 缺少 {required} 子命令")
        self.assertIn(f"{len(cmds)} 个子命令", _current_body(),
                      f"SKILL.md 未提到当前 CLI 子命令数 {len(cmds)}")

    def test_analyzer_count_is_documented(self):
        names = _analyzer_names()
        self.assertIn("group", names)
        self.assertIn("privacy", names)
        self.assertIn("topic", names)
        n = len(names)
        self.assertIn(f"{n} 个分析器", _current_body(),
                      f"SKILL.md 未提到当前分析器数 {n}")

    def test_documented_tool_names_exist(self):
        """正文点名的 MCP 工具必须真的注册了，防止写出没实现的名字。"""
        tools = _mcp_tools()
        for token in set(re.findall(r"`([a-z][a-z0-9_]{5,})`", _current_body())):
            if token in _NON_TOOL_TOKENS or not token.startswith(_TOOL_PREFIXES):
                continue
            self.assertIn(token, tools, f"SKILL.md 提到 MCP 工具 {token}，代码里没有")

    def test_documented_cli_flags_exist(self):
        src = (ROOT / "scripts" / "main.py").read_text(encoding="utf-8")
        for flag in set(re.findall(r"`(--[a-z][a-z-]+)`", _current_body())):
            self.assertIn(f"'{flag}'", src, f"SKILL.md 提到 {flag}，CLI 没有这个参数")


class TestDocHygiene(unittest.TestCase):

    def test_local_links_resolve(self):
        for name in DOCS:
            text = (ROOT / name).read_text(encoding="utf-8")
            for target in re.findall(r"\[[^\]]*\]\(([^)\s]+)\)", text):
                if target.startswith(("http://", "https://", "mailto:", "#")):
                    continue
                rel = target.split("#")[0]
                if rel:
                    self.assertTrue((ROOT / rel).exists(),
                                    f"{name} 链接指向不存在的 {rel}")

    def test_no_stale_tool_count_in_current_body(self):
        body = _current_body()
        for stale in ("15 工具 stdio", "MCP Server 18 工具", "MCP Server 18工具",
                      "三层融合预测", "7 分析工具"):
            self.assertNotIn(stale, body, f"正文残留陈旧口径：{stale}")

    def test_version_matches_core(self):
        from core.version import __version__
        m = re.search(r"^version:\s*([\d.]+)", _skill_md(), re.M)
        self.assertIsNotNone(m, "SKILL.md 缺 version 字段")
        self.assertEqual(m.group(1), __version__)

    def test_disclaimer_present(self):
        """心理/人格类结论必须带免责声明，这是本技能的硬约束。"""
        self.assertIn("不是专业评估", _skill_md())

    def test_known_issue_disclosed(self):
        """mirofish_services 的 dotenv 依赖缺口要写在文档里，别让用户自己踩。"""
        self.assertTrue(any("dotenv" in (ROOT / d).read_text(encoding="utf-8")
                            for d in DOCS),
                        "mirofish_services 依赖问题未在文档披露")


if __name__ == "__main__":
    unittest.main()
