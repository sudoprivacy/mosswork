#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v4.0.0 测试套件 — 新模块 + 增强回归测试

覆盖：
1. clipboard_monitor — 剪贴板解析器
2. wechat_window_reader — 消息解析器
3. history_aware_predictor — 个性化预测器
4. inference_analyzer — 马尔可夫链 + 时间模式
5. ensemble — 动态权重 + 多样性保障
6. rule_predictor — 意图链 + 长度自适应
"""

import sys
import os
import json
import re
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from collections import Counter

# 确保项目根目录在 sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.dont_write_bytecode = True


# ============================================================================
# 1. 剪贴板解析器测试
# ============================================================================

class TestClipboardParser(unittest.TestCase):
    """测试 clipboard_monitor.parse_wechat_clipboard"""

    def test_parse_wechat_timestamp_format(self):
        from scripts.clipboard_monitor import parse_wechat_clipboard
        text = "2024-01-15 14:32:15 张三\n你好啊\n2024-01-15 14:33:00 李四\n在的"
        msgs = parse_wechat_clipboard(text)
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0].sender, "张三")
        self.assertEqual(msgs[0].content, "你好啊")
        self.assertEqual(msgs[0].timestamp, "2024-01-15 14:32:15")
        self.assertEqual(msgs[1].sender, "李四")
        self.assertEqual(msgs[1].content, "在的")

    def test_parse_simple_format(self):
        from scripts.clipboard_monitor import parse_wechat_clipboard
        text = "我: 你好\n对方: 你也好"
        msgs = parse_wechat_clipboard(text)
        self.assertGreaterEqual(len(msgs), 1)
        # 第一条应该是 "我"
        self.assertEqual(msgs[0].sender, "我")
        self.assertEqual(msgs[0].role, "self")

    def test_parse_multiline_content(self):
        from scripts.clipboard_monitor import parse_wechat_clipboard
        text = "2024-01-15 14:32:15 张三\n第一行\n第二行\n第三行"
        msgs = parse_wechat_clipboard(text)
        self.assertEqual(len(msgs), 1)
        self.assertIn("第一行", msgs[0].content)
        self.assertIn("第二行", msgs[0].content)

    def test_parse_empty(self):
        from scripts.clipboard_monitor import parse_wechat_clipboard
        self.assertEqual(parse_wechat_clipboard(""), [])
        self.assertEqual(parse_wechat_clipboard(None), [])
        self.assertEqual(parse_wechat_clipboard("x"), [])

    def test_hash_key_generation(self):
        from scripts.clipboard_monitor import parse_wechat_clipboard
        text = "我: 测试消息"
        msgs = parse_wechat_clipboard(text)
        self.assertEqual(len(msgs), 1)
        self.assertTrue(len(msgs[0].hash_key) > 0)

    def test_self_check(self):
        from scripts.clipboard_monitor import self_check
        result = self_check()
        self.assertIn("module", result)
        self.assertEqual(result["module"], "clipboard_monitor")


class TestClipboardMonitor(unittest.TestCase):
    """测试 ClipboardMonitor 实例。"""

    def test_init(self):
        from scripts.clipboard_monitor import ClipboardMonitor
        monitor = ClipboardMonitor()
        self.assertFalse(monitor.is_running())
        self.assertEqual(len(monitor.get_history()), 0)

    def test_callback_registration(self):
        from scripts.clipboard_monitor import ClipboardMonitor
        monitor = ClipboardMonitor()
        called = []
        monitor.on_message(lambda msgs: called.extend(msgs))
        self.assertEqual(len(monitor._callbacks), 1)

    def test_stats(self):
        from scripts.clipboard_monitor import ClipboardMonitor
        monitor = ClipboardMonitor()
        stats = monitor.get_stats()
        self.assertIn("total_captured", stats)
        self.assertIn("is_running", stats)


# ============================================================================
# 2. 微信窗口读取器测试
# ============================================================================

class TestWeChatMessageParser(unittest.TestCase):
    """测试 wechat_window_reader.WeChatMessageParser"""

    def test_parse_simple_messages(self):
        from scripts.wechat_window_reader import WeChatMessageParser
        parser = WeChatMessageParser()
        texts = ["张三", "14:32", "你好啊", "李四", "14:33", "在的呢"]
        msgs = parser.parse_messages(texts, self_name="李四")
        self.assertGreaterEqual(len(msgs), 1)

    def test_filter_system_messages(self):
        from scripts.wechat_window_reader import WeChatMessageParser
        parser = WeChatMessageParser()
        texts = ["你已添加了张三", "张三", "14:32", "你好"]
        msgs = parser.parse_messages(texts)
        # 系统消息应该被过滤
        for msg in msgs:
            self.assertNotIn("你已添加了", msg.content)

    def test_date_line_handling(self):
        from scripts.wechat_window_reader import WeChatMessageParser
        parser = WeChatMessageParser()
        texts = ["今天", "张三", "14:32", "你好"]
        msgs = parser.parse_messages(texts)
        # 应该能解析出消息
        self.assertGreaterEqual(len(msgs), 0)

    def test_empty_input(self):
        from scripts.wechat_window_reader import WeChatMessageParser
        parser = WeChatMessageParser()
        self.assertEqual(parser.parse_messages([]), [])
        self.assertEqual(parser.parse_messages(["", "  "]), [])


class TestWeChatWindowReader(unittest.TestCase):
    """测试 WeChatWindowReader 实例。"""

    def test_init(self):
        from scripts.wechat_window_reader import WeChatWindowReader
        reader = WeChatWindowReader()
        self.assertFalse(reader._monitoring)

    def test_status(self):
        from scripts.wechat_window_reader import WeChatWindowReader
        reader = WeChatWindowReader()
        status = reader.get_status()
        self.assertIn("wechat_running", status)
        self.assertIn("uia_available", status)

    def test_self_check(self):
        from scripts.wechat_window_reader import self_check
        result = self_check()
        self.assertIn("module", result)
        self.assertEqual(result["module"], "wechat_window_reader")


# ============================================================================
# 3. 历史感知预测器测试
# ============================================================================

class TestHistoryAwarePredictor(unittest.TestCase):
    """测试 HistoryAwarePredictor。"""

    def _make_messages(self, pairs):
        """构造消息列表。pairs = [(is_self, content), ...]"""
        from core.message import Message, MessageType, SenderRole
        msgs = []
        base_time = datetime(2024, 1, 15, 14, 0, 0)
        for i, (is_self, content) in enumerate(pairs):
            msgs.append(Message(
                sender="我" if is_self else "对方",
                content=content,
                message_type=MessageType.TEXT,
                timestamp=base_time + timedelta(minutes=i),
                metadata={"role": "self" if is_self else "other"},
            ))
        return msgs

    def test_train_with_enough_messages(self):
        from predictors.history_aware_predictor import HistoryAwarePredictor
        predictor = HistoryAwarePredictor()
        pairs = [
            (False, "在吗"), (True, "在的"), (False, "吃饭了吗"), (True, "还没呢"),
            (False, "一起吃"), (True, "好的"), (False, "去哪吃"), (True, "你定吧"),
            (False, "火锅"), (True, "好啊"), (False, "走起"), (True, "出发"),
            (False, "到了吗"), (True, "快了"), (False, "等你"), (True, "马上"),
            (False, "今天忙吗"), (True, "还行"), (False, "一起吃"), (True, "好的"),
            (False, "去哪"), (True, "你定吧"), (False, "火锅"), (True, "好啊"),
        ]
        msgs = self._make_messages(pairs)
        result = predictor.train(msgs)
        self.assertTrue(result["trained"], f"Expected trained=True, got: {result}")
        self.assertGreater(result["self_message_count"], 0)
        self.assertGreater(result["unique_phrases"], 0)

    def test_train_insufficient_messages(self):
        from predictors.history_aware_predictor import HistoryAwarePredictor
        predictor = HistoryAwarePredictor()
        msgs = self._make_messages([(False, "hi"), (True, "hello")])
        result = predictor.train(msgs)
        self.assertFalse(result["trained"])

    def test_predict_after_training(self):
        from predictors.history_aware_predictor import HistoryAwarePredictor
        from core.predictor_base import PredictionContext
        predictor = HistoryAwarePredictor()
        pairs = [
            (False, "今天忙吗"), (True, "还行"), (False, "一起吃饭"), (True, "好的"),
            (False, "去哪"), (True, "你定吧"), (False, "火锅"), (True, "好啊"),
            (False, "走起"), (True, "出发"), (False, "到了吗"), (True, "快了"),
            (False, "等你"), (True, "马上"), (False, "吃什么"), (True, "随便"),
            (False, "走吧"), (True, "好"), (False, "来了吗"), (True, "到了"),
        ]
        msgs = self._make_messages(pairs)
        predictor.train(msgs)

        context = PredictionContext(messages=msgs, scenario="social")
        result = predictor.predict(context)
        self.assertIsNotNone(result.top_prediction)
        self.assertTrue(len(result.top_prediction.text) > 0)

    def test_style_profile(self):
        from predictors.history_aware_predictor import HistoryAwarePredictor
        predictor = HistoryAwarePredictor()
        pairs = [
            (False, "q1"), (True, "a1!"), (False, "q2"), (True, "a2?"),
            (False, "q3"), (True, "a3!"), (False, "q4"), (True, "a4"),
            (False, "q5"), (True, "a5!"), (False, "q6"), (True, "a6"),
            (False, "q7"), (True, "a7?"), (False, "q8"), (True, "a8"),
            (False, "q9"), (True, "a9"), (False, "q10"), (True, "a10"),
        ]
        msgs = self._make_messages(pairs)
        predictor.train(msgs)
        profile = predictor.get_style_profile()
        self.assertIn("avg_length", profile)
        self.assertIn("question_ratio", profile)
        self.assertIn("exclamation_ratio", profile)

    def test_get_top_phrases(self):
        from predictors.history_aware_predictor import HistoryAwarePredictor
        predictor = HistoryAwarePredictor()
        pairs = [(False, f"问{i}") for i in range(15)] + [(True, "好的")] * 5 + [(True, "收到")] * 5
        msgs = self._make_messages(pairs)
        predictor.train(msgs)
        phrases = predictor.get_top_phrases(5)
        self.assertIsInstance(phrases, list)


# ============================================================================
# 4. 推演分析器增强测试
# ============================================================================

class TestInferenceAnalyzerV4(unittest.TestCase):
    """测试 inference_analyzer v4.0.0 新增能力。"""

    def _make_messages(self, n=20):
        from core.message import Message, MessageType
        msgs = []
        base_time = datetime(2024, 1, 15, 10, 0, 0)
        topics = ["工作", "吃饭", "工作", "休息", "工作", "吃饭", "工作", "运动",
                  "工作", "吃饭", "休息", "工作", "运动", "吃饭", "工作", "休息",
                  "工作", "运动", "吃饭", "工作"]
        for i in range(n):
            is_self = i % 2 == 0
            topic = topics[i % len(topics)]
            msgs.append(Message(
                sender="我" if is_self else "对方",
                content=f"今天{topic}很忙" if is_self else f"关于{topic}的事",
                message_type=MessageType.TEXT,
                timestamp=base_time + timedelta(minutes=i * 5),
                metadata={"role": "self" if is_self else "other"},
            ))
        return msgs

    def test_markov_topics(self):
        from analyzers.inference_analyzer import InferenceAnalyzer
        analyzer = InferenceAnalyzer()
        msgs = self._make_messages(20)
        result = analyzer._infer_markov_topics(msgs)
        self.assertTrue(result.get("available", False))
        self.assertIn("topic_sequence", result)
        self.assertIn("stability_score", result)

    def test_reply_timing(self):
        from analyzers.inference_analyzer import InferenceAnalyzer
        analyzer = InferenceAnalyzer()
        msgs = self._make_messages(20)
        result = analyzer._infer_reply_timing(msgs)
        self.assertTrue(result.get("available", False))
        self.assertIn("self_delay_median_sec", result)
        self.assertIn("other_delay_median_sec", result)
        self.assertIn("health_score", result)

    def test_full_analyze_v4(self):
        from analyzers.inference_analyzer import InferenceAnalyzer
        analyzer = InferenceAnalyzer()
        msgs = self._make_messages(20)
        result = analyzer.analyze(msgs)
        self.assertIn("markov_topics", result.details)
        self.assertIn("reply_timing", result.details)


# ============================================================================
# 5. 集成预测器增强测试
# ============================================================================

class TestEnsembleV4(unittest.TestCase):
    """测试 ensemble v4.0.0 动态权重 + 多样性保障。"""

    def test_diversity_enforcement(self):
        from predictors.ensemble import EnsemblePredictor
        from core.result import Prediction
        predictions = [
            Prediction(text="好的", confidence=0.8, strategy="rule"),
            Prediction(text="好的好的", confidence=0.7, strategy="rag"),
            Prediction(text="嗯嗯", confidence=0.6, strategy="rule"),
            Prediction(text="收到", confidence=0.5, strategy="rag"),
            Prediction(text="好的呢", confidence=0.45, strategy="history"),
        ]
        result = EnsemblePredictor._enforce_diversity(predictions, max_similar=0.6)
        # "好的" 和 "好的好的" 应该只保留一个
        self.assertLessEqual(len(result), 5)

    def test_normalize_text(self):
        from predictors.ensemble import EnsemblePredictor
        norm = EnsemblePredictor._normalize_text("你好！ 世界？")
        self.assertNotIn("！", norm)
        self.assertNotIn("？", norm)
        self.assertNotIn(" ", norm)

    def test_version(self):
        from predictors.ensemble import EnsemblePredictor
        # v5.0.0 改了融合算法（准确率倍率生效 + 连续置信度权重 + 空候选兜底）
        self.assertEqual(EnsemblePredictor.version, "5.0.0")

    def test_predictor_base_weights(self):
        from predictors.ensemble import EnsemblePredictor
        weights = EnsemblePredictor.PREDICTOR_BASE_WEIGHTS
        self.assertIn("rule", weights)
        self.assertIn("rag", weights)
        self.assertIn("history_aware", weights)
        self.assertAlmostEqual(sum(weights.values()), 1.0, places=1)


# ============================================================================
# 6. 规则预测器增强测试
# ============================================================================

class TestRulePredictorV4(unittest.TestCase):
    """测试 rule_predictor v4.0.0 意图链 + 长度自适应。"""

    def test_version(self):
        from predictors.rule_predictor import RulePredictor
        self.assertEqual(RulePredictor.version, "4.0.0")

    def test_intent_chains(self):
        from predictors.rule_predictor import RulePredictor
        self.assertIn(("question", "statement"), RulePredictor.INTENT_CHAINS)
        self.assertIn(("request", "statement"), RulePredictor.INTENT_CHAINS)

    def test_length_response_map(self):
        from predictors.rule_predictor import RulePredictor
        self.assertEqual(len(RulePredictor.LENGTH_RESPONSE_MAP), 4)
        for (lo, hi), templates in RulePredictor.LENGTH_RESPONSE_MAP.items():
            self.assertLess(lo, hi)
            self.assertGreater(len(templates), 0)


# ============================================================================
# 7. 版本一致性测试
# ============================================================================

class TestVersionConsistency(unittest.TestCase):
    """确保各处版本号一致。

    v5.0.0 重写：之前这里把 "4.0.0" 硬编码了 4 处，每次升级都要改测试，
    而真正会漂移的 analyzers/__init__.py、mcp_server.py 反倒没人检查
    （结果 analyzers 长期停在 2.9.0）。改成以 core.version 为基准反查所有
    对外版本出口，升级时只需改 core/version.py + config.json + SKILL.md。
    """

    def test_core_version(self):
        from core.version import __version__
        self.assertRegex(__version__, r"^\d+\.\d+\.\d+$")

    def test_config_version(self):
        from core.version import __version__
        config_path = PROJECT_ROOT / "config.json"
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        self.assertEqual(config["version"], __version__)

    def test_predictors_version(self):
        from core.version import __version__
        from predictors import __version__ as predictors_version
        self.assertEqual(predictors_version, __version__)

    def test_analyzers_version(self):
        """v5.0.0 新增：analyzers 此前硬编码 2.9.0 长期漂移。"""
        from core.version import __version__
        from analyzers import __version__ as analyzers_version
        self.assertEqual(analyzers_version, __version__)

    def test_mcp_server_version(self):
        """v5.0.0 新增：MCP get_skill_status 上报的版本必须与包一致。

        用子进程读而不是 import——mcp_server 在缺 SDK 时会走降级分支。
        """
        from core.version import __version__
        text = (PROJECT_ROOT / "mcp_server.py").read_text(encoding="utf-8")
        found = re.findall(r'^VERSION\s*=\s*["\']([\d.]+)["\']', text, re.MULTILINE)
        if found:
            self.assertEqual(found[0], __version__,
                             "mcp_server.py 不应硬编码版本，应从 core.version 取")
        else:
            self.assertIn("core.version", text,
                          "mcp_server.py 既无 VERSION 字面量也未引用 core.version")

    def test_skill_version(self):
        from core.version import __version__
        skill_path = PROJECT_ROOT / "SKILL.md"
        with open(skill_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip().startswith("version:"):
                    self.assertIn(__version__, line)
                    return
        self.fail("version not found in SKILL.md")

    def test_no_stale_literal_versions_in_package_init(self):
        """包 __init__ 里不允许出现与 core.version 不一致的 __version__ 字面量。"""
        from core.version import __version__
        offenders = []
        for rel in ("analyzers/__init__.py", "predictors/__init__.py", "core/__init__.py"):
            path = PROJECT_ROOT / rel
            if not path.exists():
                continue
            text = path.read_text(encoding="utf-8")
            for value in re.findall(r'__version__\s*=\s*"([\d.]+)"', text):
                if value != __version__:
                    offenders.append(f"{rel}: {value}")
        self.assertFalse(offenders, f"存在硬编码版本字面量: {offenders}")


# ============================================================================
# 8. 编译冒烟测试（确保新模块无语法错误）
# ============================================================================

class TestCompileSmoke(unittest.TestCase):
    """确保所有新模块可以正常导入。"""

    def test_import_clipboard_monitor(self):
        import scripts.clipboard_monitor
        self.assertTrue(hasattr(scripts.clipboard_monitor, "ClipboardMonitor"))
        self.assertTrue(hasattr(scripts.clipboard_monitor, "parse_wechat_clipboard"))

    def test_import_wechat_window_reader(self):
        import scripts.wechat_window_reader
        self.assertTrue(hasattr(scripts.wechat_window_reader, "WeChatWindowReader"))
        self.assertTrue(hasattr(scripts.wechat_window_reader, "WeChatMessageParser"))

    def test_import_history_aware_predictor(self):
        import predictors.history_aware_predictor
        self.assertTrue(hasattr(predictors.history_aware_predictor, "HistoryAwarePredictor"))

    def test_import_ensemble_v4(self):
        import predictors.ensemble
        self.assertTrue(hasattr(predictors.ensemble, "EnsemblePredictor"))

    def test_import_predictors_init(self):
        import predictors
        self.assertTrue(hasattr(predictors, "HistoryAwarePredictor"))
        self.assertTrue(hasattr(predictors, "create_default_ensemble"))


# ============================================================================
# Main
# ============================================================================

if __name__ == "__main__":
    unittest.main(verbosity=2)