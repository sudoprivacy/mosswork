#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""test_mcp_e2e.py — MCP Server 子进程端到端测试（v5.0.0 新增）

为什么必须用子进程：
    进程内直接调 handle_request() 只能证明函数逻辑对，证明不了协议帧真的
    写进了 stdout、证明不了 stdio 信道没被业务模块的 print() 污染、也证明不了
    mcp SDK 的 FastMCP 装饰器把工具正确注册上了。v4.0.0 的 analyze_chat 与
    predict_reply 就是靠"看起来能跑"混过去的——实际一个只输出表头、
    一个每次必返回"❌ 预测异常"。

运行：
    py -3.11 -m pytest tests/test_mcp_e2e.py -v     # 装有 mcp SDK 的解释器
    没装 mcp 时整个文件自动 skip，不会把主测试套件拖红。
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SERVER = PROJECT_ROOT / "mcp_server.py"
PROTOCOL_VERSION = "2024-11-05"

# 需要 10 条以上"对方"消息 mbti / bigfive 才会通过 validate()，
# 样本太短会让这两个分析器被静默跳过，测试就看不出摘要里少了段落。
SAMPLE_CHAT = "\n".join([
    "我: 今天项目终于上线了，忙到飞起",
    "对方: 辛苦了，晚上一起吃饭庆祝一下？我请客",
    "我: 好啊，去哪吃",
    "对方: 上次那家日料，我订位，我觉得他们的寿司很新鲜",
    "我: 行，那我六点到",
    "对方: 好，到时候门口见。对了这周加班多吗，别太累着自己",
    "我: 收到",
    "对方: 把你那份文档也带上，我想再看看里面的细节，应该还有很多可以改进的地方",
    "对方: 最近团队氛围怎么样，大家沟通还顺畅吗",
    "我: 还行，就是需求老是变",
    "对方: 变化其实也正常，重要的是我们把每一步都记录下来，这样以后复盘会轻松很多",
    "对方: 周末如果有空，我们可以一起去爬山，放松一下心情，顺便聊聊下半年的计划",
    "我: 可以啊，我看看时间安排",
    "对方: 好的，你决定就行。我觉得我们做事前先想清楚目标，比埋头赶进度有效多了",
    "对方: 上次你提的那个方案我认真想了想，确实比我原来的思路更稳妥，风险也小",
    "我: 那就好，我还担心你觉得太保守",
    "对方: 不会，我反而更喜欢把风险先摆出来再讨论，这样大家心里都有底",
])


_MCP_PROBE = (
    "try:\n"
    "    from mcp.server.fastmcp import FastMCP\n"
    "except ImportError:\n"
    "    from mcp.server.mcpserver import MCPServer\n"
)


def _find_python_with_mcp():
    """找一个能提供可用 MCP server API 的解释器；找不到返回 None。

    v6.0.0：不能只探 `import mcp`——mcp 2.x 里包能导，但 FastMCP 已改名，
    旧探针会把一个服务端根本起不来的解释器当成"可用"，29 个用例全变 ERROR。
    """
    candidates = [sys.executable]
    if os.name == "nt" and shutil.which("py"):
        for ver in ("3.13", "3.12", "3.11", "3.10"):
            candidates.append(["py", f"-{ver}"])
    for cand in candidates:
        argv = cand if isinstance(cand, list) else [cand]
        try:
            r = subprocess.run(argv + ["-c", _MCP_PROBE],
                               capture_output=True, timeout=60)
            if r.returncode == 0:
                return argv
        except Exception:
            continue
    return None


_PY = _find_python_with_mcp()
requires_mcp_sdk = pytest.mark.skipif(_PY is None, reason="没有可导入 mcp SDK 的 Python 解释器")


def _inside(path, root):
    """服务端返回的路径是否落在允许的临时数据目录下（大小写/短名都要认）。"""
    return os.path.realpath(str(path)).startswith(os.path.realpath(root))


class McpClient:
    """最小 MCP stdio 客户端：换行分隔的 JSON-RPC。"""

    def __init__(self, python_argv):
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        # 测试产物一律落到包外目录，源码树保持干净
        env["WECHAT_ANALYZER_DATA_DIR"] = tempfile.mkdtemp(prefix="wa_mcp_e2e_")
        # 断言"产物没落进源码树"时要能认出哪个目录是合法的
        self.data_dir = env["WECHAT_ANALYZER_DATA_DIR"]
        env.pop("DEEPSEEK_API_KEY", None)
        env.pop("OPENAI_API_KEY", None)
        self.proc = subprocess.Popen(
            python_argv + [str(SERVER)],
            cwd=str(PROJECT_ROOT),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", env=env, bufsize=1,
        )
        self._id = 0
        self._stderr_lines = []
        self._drain = threading.Thread(target=self._read_stderr, daemon=True)
        self._drain.start()

    def _read_stderr(self):
        for line in self.proc.stderr:
            self._stderr_lines.append(line.rstrip())

    def send(self, payload):
        self.proc.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()

    def request(self, method, params=None, timeout=90):
        self._id += 1
        msg_id = self._id
        payload = {"jsonrpc": "2.0", "id": msg_id, "method": method, "params": params or {}}
        self.send(payload)
        deadline = time.time() + timeout
        while time.time() < deadline:
            line = self.proc.stdout.readline()
            if not line:
                raise RuntimeError(
                    "服务端 stdout 关闭（进程退出？）\nstderr:\n"
                    + "\n".join(self._stderr_lines[-30:])
                )
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError as e:
                raise AssertionError(
                    f"stdout 出现非 JSON 帧，协议已被污染: {line[:200]!r} ({e})"
                )
            if msg.get("id") == msg_id:
                if "error" in msg:
                    raise AssertionError(f"{method} 返回错误: {msg['error']}")
                return msg["result"]
        raise TimeoutError(f"{method} 超时 {timeout}s")

    def notify(self, method, params=None):
        self.send({"jsonrpc": "2.0", "method": method, "params": params or {}})

    def initialize(self):
        result = self.request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "wa-e2e-test", "version": "1.0"},
        })
        self.notify("notifications/initialized")
        return result

    def list_tools(self):
        return [t["name"] for t in self.request("tools/list").get("tools", [])]

    def call_tool(self, name, arguments=None, timeout=90):
        result = self.request("tools/call", {"name": name, "arguments": arguments or {}},
                              timeout=timeout)
        if result.get("isError"):
            text = self._extract_text(result)
            raise AssertionError(f"工具 {name} 返回 isError：{text[:400]}")
        return self._extract_text(result)

    @staticmethod
    def _extract_text(result):
        content = result.get("content") or []
        parts = [c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"]
        structured = result.get("structuredContent")
        if structured is not None and not parts:
            return json.dumps(structured, ensure_ascii=False)
        return "\n".join(parts)

    def close(self):
        try:
            self.proc.stdin.close()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=10)
        except Exception:
            self.proc.kill()

    @property
    def stderr_text(self):
        return "\n".join(self._stderr_lines)


@pytest.fixture(scope="module")
def client():
    if _PY is None:
        pytest.skip("没有可导入 mcp SDK 的 Python 解释器")
    c = McpClient(_PY)
    try:
        c.initialize()
    except Exception:
        c.close()
        raise
    yield c
    c.close()


# ============================================================================
# 协议层
# ============================================================================

@requires_mcp_sdk
def test_server_starts_without_stdout_pollution(client):
    """握手成功即说明 stdout 只有 JSON-RPC 帧。"""
    assert client.list_tools(), "工具列表为空说明注册失败"


@requires_mcp_sdk
def test_declares_expected_tools(client):
    tools = set(client.list_tools())
    expected = {
        "analyze_chat", "get_mbti_analysis", "get_bigfive_analysis",
        "get_sentiment_analysis", "get_risk_analysis", "get_relationship_health",
        "get_scenario", "ai_personality_insight", "ai_emotion_narrative",
        "ai_relationship_advice", "ai_risk_interpretation",
        "ai_prediction_explanation", "predict_reply", "import_chat_from_text",
        "capture_clipboard", "capture_wechat_window", "get_desktop_status",
        "get_skill_status",
        # v5.0.0 新增
        "get_pattern_analysis", "get_inference_analysis",
        "get_interpretation_analysis", "get_group_analysis", "scan_privacy",
        "ai_insight_from_chat", "train_reply_predictor", "get_prediction_profile",
        "export_chat_report", "save_analysis_session", "list_analysis_sessions",
        "compare_analysis_sessions",
        # v6.0.0 新增
        "get_topic_analysis",
    }
    missing = expected - tools
    assert not missing, f"MCP 工具缺失: {sorted(missing)}"


# ============================================================================
# 分析类：v4.0.0 的 analyze_chat 只会输出表头，这里必须断言到真内容
# ============================================================================

@requires_mcp_sdk
def test_analyze_chat_summary_has_real_content(client):
    out = client.call_tool("analyze_chat", {"chat_text": SAMPLE_CHAT,
                                            "export_format": "summary"})
    assert "❌" not in out, out[:400]
    assert "### mbti" in out, f"摘要缺少分析器段落：{out[:600]}"
    assert "### sentiment" in out
    assert "### relationship" in out
    assert "### topic" in out
    assert "仅供参考" in out


@requires_mcp_sdk
def test_analyze_chat_json_is_parseable(client):
    out = client.call_tool("analyze_chat", {"chat_text": SAMPLE_CHAT,
                                            "export_format": "json"})
    assert "❌" not in out, out[:400]
    data = json.loads(out)
    assert isinstance(data, dict) and "mbti" in data
    # 必须是 to_dict() 之后的结构，而不是 "AnalysisResult(...)" 的 repr
    assert isinstance(data["mbti"], dict), data["mbti"]
    assert "details" in data["mbti"]


def test_json_helper_never_returns_half_json():
    """体积上限不能靠裸切片：半截 JSON 会让所有下游 json.loads 崩掉。"""
    sys.path.insert(0, str(PROJECT_ROOT))
    try:
        import mcp_server
    finally:
        sys.path.pop(0)
    out = mcp_server._json({"blob": "x" * 50000}, 1000)
    data = json.loads(out)
    assert data["truncated"] is True
    assert "上限" in data["error"]


@requires_mcp_sdk
@pytest.mark.parametrize("tool", [
    "get_mbti_analysis", "get_bigfive_analysis", "get_sentiment_analysis",
    "get_risk_analysis", "get_relationship_health", "get_scenario",
])
def test_single_analyzer_tools_return_success_json(client, tool):
    out = client.call_tool(tool, {"chat_text": SAMPLE_CHAT})
    assert not out.startswith("❌"), f"{tool}: {out[:300]}"
    data = json.loads(out)
    assert data.get("success") is True, f"{tool}: {out[:300]}"
    assert isinstance(data.get("result"), dict)
    assert data["result"].get("analyzer_name")


@requires_mcp_sdk
def test_rejects_unparseable_input(client):
    out = client.call_tool("analyze_chat", {"chat_text": ""})
    assert "❌" in out


# ============================================================================
# 预测类：v4.0.0 的 predict_reply 必抛 AttributeError
# ============================================================================

@requires_mcp_sdk
def test_predict_reply_returns_predictions(client):
    out = client.call_tool("predict_reply", {"chat_text": SAMPLE_CHAT,
                                             "mbti_other": "ENFP"}, timeout=120)
    assert not out.startswith("❌"), f"predict_reply 失败: {out[:400]}"
    data = json.loads(out)
    assert data.get("success") is True, out[:400]
    top = data.get("top_prediction") or {}
    assert top.get("text"), f"没有 top_prediction：{out[:400]}"
    assert "metadata" in data
    # 至少要有一个真实预测器参与（fallback 不算）
    used = data["metadata"].get("predictors_used") or []
    assert used, f"没有任何预测器产出候选：{out[:500]}"


@requires_mcp_sdk
def test_predict_reply_reports_effective_weights(client):
    out = client.call_tool("predict_reply", {"chat_text": SAMPLE_CHAT}, timeout=120)
    data = json.loads(out)
    meta = data.get("metadata", {})
    assert "weights_applied" in meta, "集成预测器没有上报实际生效权重"
    assert "failed_predictors" in meta, "集成预测器没有上报失败的预测器"


# ============================================================================
# 导入类
# ============================================================================

@requires_mcp_sdk
def test_import_chat_from_text_detects_platform(client):
    out = client.call_tool("import_chat_from_text", {"chat_text": SAMPLE_CHAT})
    data = json.loads(out)
    assert data["success"] is True
    assert data["message_count"] >= 6, out[:400]
    roles = {m["role"] for m in data["messages"]}
    assert "self" in roles and "other" in roles, f"角色识别失败：{roles}"


@requires_mcp_sdk
def test_import_chat_wechat_export_format_with_timestamps(client):
    """微信导出格式（时间戳 + 昵称）必须解析出时间，否则时序分析全废。"""
    text = (
        "2024-03-01 09:12:33 张伟\n早上好，昨天的报表发了吗\n"
        "2024-03-01 09:15:02 我\n刚发你邮箱了\n"
        "2024-03-01 09:16:40 张伟\n收到，谢谢\n"
    )
    out = client.call_tool("import_chat_from_text", {"chat_text": text})
    data = json.loads(out)
    assert data["message_count"] == 3, out[:400]
    assert data.get("detected_platform") == "wechat", out[:400]
    assert any(m.get("timestamp") for m in data["messages"]), "时间戳全部丢失"


@requires_mcp_sdk
def test_import_chat_inline_timestamp_colon_format(client):
    """聊天窗口直接复制的"时间 昵称: 内容"单行式，必须切出内容与角色。

    曾经整行被当成 sender、content 为空，所有分析器因为"没有文本"静默跳过，
    用户看到的是一份标题齐全、正文全空的报告。
    """
    text = (
        "2026-03-01 09:12 张伟: 早上好，昨天的报表发了吗\n"
        "2026-03-01 09:15 我: 刚发你邮箱了\n"
        "2026-03-01 09:16 张伟: 收到，谢谢。注意：数字别改\n"
    )
    out = client.call_tool("import_chat_from_text", {"chat_text": text})
    data = json.loads(out)
    assert data["message_count"] == 3, out[:400]
    senders = {m["sender"] for m in data["messages"]}
    assert senders == {"张伟", "我"}, f"发送者切错：{senders}"
    assert all(m["content"] for m in data["messages"]), "内容为空"
    roles = {m["role"] for m in data["messages"]}
    assert "self" in roles, f"角色识别失败：{roles}"
    last = data["messages"][-1]["content"]
    assert last.startswith("收到"), f"内容被冒号切坏：{last}"


@requires_mcp_sdk
def test_analyze_chat_inline_timestamp_format_has_content(client):
    """同一种粘贴格式走 analyze_chat 时，分析器必须真的跑出结果。"""
    text = "\n".join(
        f"2026-03-0{ i % 9 + 1} 09:{i:02d} {'张伟' if i % 2 else '我'}: "
        f"这句话有点长，够分析器用的了{i}"
        for i in range(14)
    )
    out = client.call_tool("analyze_chat", {"chat_text": text})
    assert "❌" not in out, out[:300]
    assert "###" in out, f"没有任何分析段落：{out[:400]}"
    assert "共 14 条消息" in out


# ============================================================================
# 桌面捕获类（非 Windows / 无微信时必须优雅降级而不是崩）
# ============================================================================

@requires_mcp_sdk
def test_get_desktop_status_returns_json(client):
    out = client.call_tool("get_desktop_status", {})
    data = json.loads(out)
    assert "platform" in data and "clipboard_monitor" in data


@requires_mcp_sdk
def test_capture_tools_degrade_gracefully(client):
    """没有微信窗口时必须是可读的失败说明，不能是异常堆栈或崩溃。"""
    for tool in ("capture_wechat_window",):
        out = client.call_tool(tool, {}, timeout=60)
        assert out, f"{tool} 返回空"
        assert "Traceback" not in out
        if out.startswith("❌"):
            pytest.fail(f"{tool} 抛异常: {out[:300]}")


@requires_mcp_sdk
def test_clipboard_capture_short_window(client):
    out = client.call_tool("capture_clipboard", {"duration": 1}, timeout=60)
    data = json.loads(out)
    assert "success" in data, out[:300]


# ============================================================================
# 系统类
# ============================================================================

@requires_mcp_sdk
def test_skill_status_reports_consistent_version(client):
    out = client.call_tool("get_skill_status", {})
    data = json.loads(out)
    sys.path.insert(0, str(PROJECT_ROOT))
    try:
        from core.version import __version__
    finally:
        sys.path.pop(0)
    assert data["version"] == __version__, \
        f"MCP 上报 {data['version']} != core.version {__version__}"
    # v6.0.0：必须能说明自己跑在哪一代 SDK 上，否则兼容问题无处可查
    assert data["mcp_sdk_generation"] in (1, 2), data.get("mcp_sdk_generation")
    assert data["mcp_sdk_label"] in ("1.x/FastMCP", "2.x/MCPServer")
    # 工具清单必须来自真实注册表
    assert data["total_tools"] == len(data["mcp_tools"])
    assert data["total_tools"] >= 31
    assert "mbti" in data["registered_analyzers"]
    assert "rule" in data["registered_predictors"]
    # v5.0.0 接线的模块必须在状态里可见——接不上时不能只等用户投诉
    for key in ("session_memory", "report_exporters", "v2_report", "history_profile"):
        assert data[key]["available"] is True, f"{key} 未加载: {data[key]}"
    assert data["ai_insight_context"]["build_ok"] is True, data.get("ai_insight_context")


@requires_mcp_sdk
def test_new_single_analyzer_tools(client):
    for tool in ("get_pattern_analysis", "get_inference_analysis",
                 "get_interpretation_analysis", "get_group_analysis",
                 "get_topic_analysis"):
        out = client.call_tool(tool, {"chat_text": SAMPLE_CHAT})
        assert not out.startswith("❌"), f"{tool}: {out[:300]}"
        data = json.loads(out)
        assert data.get("success") is True, f"{tool}: {out[:300]}"
        assert isinstance(data.get("result"), dict)


@requires_mcp_sdk
def test_topic_tool_returns_keywords_and_speakers(client):
    """话题工具不能只返回空壳：关键词、人物拆分、分词方式都要有。"""
    out = client.call_tool("get_topic_analysis", {"chat_text": SAMPLE_CHAT})
    details = json.loads(out)["result"]["details"]
    assert details["available"] is True, out[:400]
    assert details["keywords"], out[:400]
    assert details["by_speaker"]["self"] or details["by_speaker"]["other"]
    assert details["tokenizer"] in ("jieba", "fallback")
    assert details["tokenizer_note"]


@requires_mcp_sdk
def test_scan_privacy_masks_before_returning(client):
    """隐私扫描必须报出命中项；开启脱敏时原文不能再出现。"""
    text = SAMPLE_CHAT + "\n我: 我身份证 110101199003074512，手机 13812345678 你存一下"
    out = client.call_tool("scan_privacy", {"chat_text": text})
    data = json.loads(out)
    assert data["success"] is True and data["local_only"] is True
    assert data["total_hits"] >= 2, out[:400]
    assert "id_card" in data["by_type"] and "phone" in data["by_type"]

    masked = json.loads(client.call_tool("scan_privacy",
                                         {"chat_text": text, "return_masked": True}))
    assert "110101199003074512" not in masked["masked_text"]
    assert "13812345678" not in masked["masked_text"]
    assert masked["mapping"], "可逆映射丢了就无法还原"


@requires_mcp_sdk
def test_ai_insight_from_chat_chains_analyzers(client):
    """一条龙洞察：分析器结果必须自动变成提示词上下文，不要求调用方手抄参数。"""
    out = client.call_tool("ai_insight_from_chat",
                           {"chat_text": SAMPLE_CHAT, "insight_type": "emotion_narrative"})
    data = json.loads(out)
    assert data["success"] is True, out[:400]
    insight = data["insights"]["emotion_narrative"]
    assert insight["skipped"] is False, insight
    # 无 Key 时走本地模板，也必须给出可用的正文
    assert "正面" in insight["content"] or "positive" in insight["content"], insight["content"][:200]


@requires_mcp_sdk
def test_ai_insight_from_chat_rejects_unknown_type(client):
    out = client.call_tool("ai_insight_from_chat",
                           {"chat_text": SAMPLE_CHAT, "insight_type": "塔罗牌"})
    assert out.startswith("❌"), out[:200]


@requires_mcp_sdk
def test_export_chat_report_writes_outside_source_tree(client):
    """导出必须落在 WECHAT_ANALYZER_DATA_DIR 下，技能包里不能多文件。"""
    for fmt in ("markdown", "csv", "html", "json"):
        out = client.call_tool("export_chat_report",
                               {"chat_text": SAMPLE_CHAT, "export_format": fmt})
        data = json.loads(out)
        assert data["success"] is True, f"{fmt}: {out[:300]}"
        assert _inside(data["path"], client.data_dir), f"{fmt} 导出到了包内: {data['path']}"
        assert os.path.isfile(data["path"]) and data["size_bytes"] > 0
    assert client.call_tool("export_chat_report", {"export_format": "exe"}).startswith("❌")


@requires_mcp_sdk
def test_session_snapshot_roundtrip_and_compare(client):
    """快照存两条再对比，趋势链路必须在 MCP 侧真的可用。"""
    first = json.loads(client.call_tool("save_analysis_session",
                                        {"chat_text": SAMPLE_CHAT, "label": "第一次"}))
    assert first["success"] is True, str(first)[:300]
    assert first["snapshot"]["label"] == "第一次"
    assert first["snapshot"]["metrics"], "快照里没有指标"

    client.call_tool("save_analysis_session", {"chat_text": SAMPLE_CHAT, "label": "第二次"})
    listed = json.loads(client.call_tool("list_analysis_sessions", {"limit": 10}))
    assert listed["count"] >= 2, str(listed)[:300]
    assert _inside(listed["file"], client.data_dir), listed["file"]

    compared = json.loads(client.call_tool("compare_analysis_sessions", {}))
    assert compared["comparison"]["found"] is True, str(compared)[:400]
    assert "summary" in compared["comparison"]

    missing = client.call_tool("compare_analysis_sessions", {"baseline_id": "不存在"})
    assert missing.startswith("❌"), missing[:200]


@requires_mcp_sdk
def test_prediction_profile_persists_across_calls(client):
    """训练→查状态：画像文件必须真的落在数据目录，且能被读回来。"""
    trained = json.loads(client.call_tool("train_reply_predictor",
                                          {"chat_text": SAMPLE_CHAT}))
    assert _inside(trained["profile_file"], client.data_dir), trained
    status = json.loads(client.call_tool("get_prediction_profile", {}))
    assert status["success"] is True
    assert status["persistence_enabled"] is True
    if trained["success"]:
        assert status["loaded"] is True, str(status)[:300]
        assert status["trained_sessions"] >= 1


@requires_mcp_sdk
def test_ai_tools_fallback_without_api_key(client):
    """没有 API Key 时必须走降级模板，不能报错也不能悄悄联网。"""
    out = client.call_tool("ai_personality_insight", {"mbti_type": "INTJ"})
    data = json.loads(out)
    assert "insight" in data, out[:400]
