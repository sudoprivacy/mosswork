# -*- coding: utf-8 -*-
"""
v5.0.0 能力链单元测试 (test_v500_capability_chain.py)

v5 把几条"模块存在但没人接"的链路接通了。MCP 端到端测试只覆盖工具返回值，
这一份盯的是链路本身的规则，出错时能直接定位到模块而不是一个笼统的 ❌：

- report_exporters.message_meta   报告头口径（CLI / MCP / 快照共用）
- session_memory                  跨会话快照的写入、读取、对比
- default_profile_path            历史画像落点（绝不进技能包）
- HistoryAwarePredictor 画像       导出→载入→跨会话合并
- mask_for_llm / build_insight_context / attach_insights   AI 洞察的前置条件
- _split_sender_content / _parse_simple   粘贴格式的切分回归

无网络、无外部依赖；LLM 一律用假引擎，绝不真调用。
"""
import json
import os
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "scripts"))

# 防止任何测试因为环境里有 key 就真去调云端
os.environ.pop("DEEPSEEK_API_KEY", None)
os.environ.pop("OPENAI_API_KEY", None)

from core.message import Message                                    # noqa: E402
from scripts.report_exporters import (message_meta, supported_formats,   # noqa: E402
                                      to_csv_text, to_markdown, write_report)
from scripts import session_memory                                  # noqa: E402
from analyzers.ai_insight_engine import (InsightResult,             # noqa: E402
                                        attach_insights, build_insight_context,
                                        mask_for_llm)
from predictors.history_aware_predictor import (HistoryAwarePredictor,  # noqa: E402
                                                default_profile_path)
from scripts.data_source_importer import SmartPasteParser, _split_sender_content  # noqa: E402


CHAT = [
    Message(sender="我", content="周末有空吗", timestamp=datetime(2024, 3, 1, 9, 12)),
    Message(sender="小李", content="有啊，去哪", timestamp=datetime(2024, 3, 1, 9, 15)),
    Message(sender="我", content="看电影吧", timestamp=datetime(2024, 3, 1, 9, 16)),
    Message(sender="unknown", content="系统提示：对方撤回了一条消息"),
]

RESULTS = {
    "relationship": {"score": 72.0, "confidence": 80.0, "details": {
        "health_score": 72.0, "grade_label": "良好", "cold_reply_ratio": 0.1,
        "dimensions": {"balance": 70.0, "responsiveness": 65.0}}},
    "sentiment": {"score": 60.0, "confidence": 70.0, "details": {
        "positive": 45.0, "negative": 10.0, "neutral": 45.0, "trend": "up"}},
    "privacy": {"score": 30.0, "confidence": 90.0, "details": {
        "total_hits": 2, "level": "medium"}},
    "mbti": {"score": 61.0, "confidence": 71.0,
             "details": {"type": "INFJ", "name": "提倡者"}},
}


class TempDataDirCase(unittest.TestCase):
    """把运行时数据目录指到包外临时目录，测试产物绝不落源码树。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        previous = os.environ.get("WECHAT_ANALYZER_DATA_DIR")
        os.environ["WECHAT_ANALYZER_DATA_DIR"] = self.tmp.name
        self.addCleanup(lambda: (os.environ.pop("WECHAT_ANALYZER_DATA_DIR", None)
                                 if previous is None
                                 else os.environ.__setitem__("WECHAT_ANALYZER_DATA_DIR", previous)))
        self.data_dir = Path(self.tmp.name)

    def assert_outside_package(self, path):
        resolved = Path(path).resolve()
        self.assertNotIn(REPO_ROOT, resolved.parents, f"产物写进了技能包: {path}")


# ---------------------------------------------------------------------------
# 1. 报告元数据口径
# ---------------------------------------------------------------------------

class TestMessageMeta(unittest.TestCase):

    def test_counts_self_other_and_participants(self):
        meta = message_meta(CHAT)
        self.assertEqual(meta["total_messages"], 4)
        self.assertEqual(meta["self_messages"], 2)
        # unknown 既不是 self 也不是 other，不能混进"对方"里虚增互动
        self.assertEqual(meta["other_messages"], 1)
        self.assertEqual(meta["participants"], 3)

    def test_time_span_needs_two_timestamps(self):
        self.assertIn("time_span", message_meta(CHAT))
        self.assertNotIn("time_span", message_meta(CHAT[:1]))
        self.assertNotIn("time_span", message_meta([]))

    def test_empty_input_is_safe(self):
        self.assertEqual(message_meta([])["total_messages"], 0)
        self.assertEqual(message_meta(None)["participants"], 0)

    def test_time_span_span_is_start_end_sorted(self):
        span = message_meta(CHAT)["time_span"]
        self.assertEqual(span["start"], "2024-03-01T09:12:00")
        self.assertEqual(span["end"], "2024-03-01T09:16:00")


class TestReportExport(TempDataDirCase):

    def test_markdown_renders_analyzer_facts(self):
        text = to_markdown(RESULTS, message_meta(CHAT))
        self.assertIn("INFJ", text)
        self.assertIn("良好", text)
        self.assertIn("参与人数", text)

    def test_csv_is_pivotable_three_column(self):
        text = to_csv_text(RESULTS, message_meta(CHAT))
        lines = text.strip().splitlines()
        self.assertEqual(lines[0], "analyzer,metric,value")
        self.assertTrue(any(line.startswith("_meta,total_messages,4") for line in lines), lines)
        self.assertTrue(any(line.startswith("relationship,健康度,72.0") for line in lines), lines)
        self.assertTrue(any(line.startswith("mbti,MBTI 类型,INFJ") for line in lines), lines)

    def test_write_report_csv_has_bom_for_excel(self):
        out = str(self.data_dir / "r.csv")
        write_report("csv", RESULTS, message_meta(CHAT), out)
        with open(out, "rb") as f:
            self.assertTrue(f.read(3) == b"\xef\xbb\xbf")
        self.assert_outside_package(out)

    def test_write_report_markdown_is_utf8_without_bom(self):
        out = str(self.data_dir / "r.md")
        write_report("markdown", RESULTS, message_meta(CHAT), out)
        with open(out, "rb") as f:
            self.assertFalse(f.read(3) == b"\xef\xbb\xbf")

    def test_unsupported_format_raises(self):
        """exe / html 这类不能导，别让调用方以为真的生成了可执行文件。"""
        with self.assertRaises(ValueError):
            write_report("exe", RESULTS, {}, str(self.data_dir / "bad"))
        self.assertEqual(supported_formats(), ["markdown", "csv"])
        self.assertNotIn("exe", supported_formats())

    def test_failed_analyzer_degrades_instead_of_crashing(self):
        broken = {"mbti": {"score": 0, "confidence": 0,
                           "details": {"error": "样本不足"}}}
        text = to_markdown(broken, message_meta(CHAT))
        self.assertIn("分析失败", text)


# ---------------------------------------------------------------------------
# 2. 跨会话快照
# ---------------------------------------------------------------------------

class TestSessionMemory(TempDataDirCase):

    def config(self, **session_cfg):
        return {"session_memory": dict(session_cfg)}

    def test_extract_metrics_flattens_only_present_analyzers(self):
        m = session_memory.extract_metrics(RESULTS, message_meta(CHAT))
        self.assertEqual(m["health_score"], 72.0)
        self.assertEqual(m["grade_label"], "良好")
        self.assertEqual(m["privacy_hits"], 2)
        self.assertEqual(m["mbti_type"], "INFJ")
        self.assertEqual(m["total_messages"], 4)
        # 没跑 risk / group，就不该凭空造出 0 分
        self.assertNotIn("risk_score", m)
        self.assertNotIn("member_count", m)

    def test_extract_metrics_ignores_errored_analyzer(self):
        m = session_memory.extract_metrics(
            {"relationship": {"details": {"error": "崩了"}}}, {})
        self.assertNotIn("health_score", m)

    def test_snapshot_roundtrip(self):
        first = session_memory.save_snapshot(RESULTS, message_meta(CHAT),
                                             self.config(), label="第一次")
        second = session_memory.save_snapshot(RESULTS, message_meta(CHAT),
                                              self.config(), label="第二次")
        rows = session_memory.list_snapshots(self.config())
        self.assertEqual([r["id"] for r in rows], [first["id"], second["id"]])
        self.assertEqual(session_memory.get_snapshot(first["id"], self.config())["label"], "第一次")
        self.assertIsNone(session_memory.get_snapshot("不存在的id", self.config()))
        self.assert_outside_package(session_memory.snapshot_file(self.config()))

    def test_compare_detects_direction_and_significance(self):
        low = {"relationship": {"score": 50, "confidence": 70, "details": {
            "health_score": 50.0, "grade_label": "一般"}}}
        high = {"relationship": {"score": 80, "confidence": 70, "details": {
            "health_score": 65.0, "grade_label": "良好"}}}
        a = session_memory.save_snapshot(low, {}, self.config())
        b = session_memory.save_snapshot(high, {}, self.config())
        out = session_memory.compare_sessions(config=self.config())
        self.assertTrue(out["found"])
        self.assertEqual(out["current_id"], b["id"])
        self.assertEqual(out["baseline_id"], a["id"])
        delta = [d for d in out["deltas"] if d["metric"] == "health_score"][0]
        self.assertEqual(delta["direction"], "up")
        self.assertEqual(delta["trend"], "改善")
        self.assertTrue(delta["significant"])
        self.assertTrue(any("关系健康度" in n for n in out["notable"]))

    def test_small_wobble_is_flagged_not_significant(self):
        """0.4 分的抖动不该被当成趋势，否则用户会对着噪声做决定。"""
        base = {"relationship": {"details": {"health_score": 70.0}}}
        cur = {"relationship": {"details": {"health_score": 70.4}}}
        session_memory.save_snapshot(base, {}, self.config())
        session_memory.save_snapshot(cur, {}, self.config())
        out = session_memory.compare_sessions(config=self.config())
        delta = [d for d in out["deltas"] if d["metric"] == "health_score"][0]
        self.assertFalse(delta["significant"])

    def test_dropping_bad_metrics_is_not_significant_for_lower_is_better(self):
        base = {"sentiment": {"details": {"negative": 30.0}}}
        cur = {"sentiment": {"details": {"negative": 12.0}}}
        session_memory.save_snapshot(base, {}, self.config())
        session_memory.save_snapshot(cur, {}, self.config())
        delta = [d for d in session_memory.compare_sessions(
            config=self.config())["deltas"] if d["metric"] == "negative"][0]
        self.assertEqual(delta["direction"], "down")
        self.assertEqual(delta["trend"], "改善")

    def test_volume_metrics_are_not_scored_good_or_bad(self):
        """消息变多不等于关系变好，量类指标只报升降。"""
        session_memory.save_snapshot({}, {"total_messages": 10}, self.config())
        session_memory.save_snapshot({}, {"total_messages": 40}, self.config())
        delta = [d for d in session_memory.compare_sessions(
            config=self.config())["deltas"] if d["metric"] == "total_messages"][0]
        self.assertFalse(delta["evaluative"])
        self.assertEqual(delta["trend"], "上升")
        self.assertNotIn("改善的有", session_memory.compare_sessions(
            config=self.config())["summary"])

    def test_only_volume_change_says_quality_is_flat(self):
        session_memory.save_snapshot({}, {"total_messages": 30}, self.config())
        session_memory.save_snapshot({}, {"total_messages": 5}, self.config())
        summary = session_memory.compare_sessions(config=self.config())["summary"]
        self.assertIn("质量类指标基本持平", summary)
        self.assertIn("消息总数下降", summary)

    def test_single_snapshot_reports_reason(self):
        session_memory.save_snapshot(RESULTS, {}, self.config())
        out = session_memory.compare_sessions(config=self.config())
        self.assertFalse(out["found"])
        self.assertIn("至少需要两次", out["reason"])

    def test_corrupt_and_id_less_lines_are_skipped(self):
        """半行写入没有 id 的记录都要被跳过，不能拖垮整份历史。"""
        good = [session_memory.save_snapshot(RESULTS, {}, self.config()),
                session_memory.save_snapshot(RESULTS, {}, self.config())]
        path = session_memory.snapshot_file(self.config())
        with open(path, "w", encoding="utf-8") as f:
            f.write(good[0]["id"] + "\n")                       # 不是 JSON 对象
            f.write("{这不是完整的一行\n")                        # 半行写入
            f.write(json.dumps({"saved_at": "2024-01-01T00:00:00"}) + "\n")  # 缺 id
            for row in good:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        rows = session_memory.list_snapshots(self.config())
        self.assertEqual([r["id"] for r in rows], [good[0]["id"], good[1]["id"]])

    def test_max_snapshots_truncates_oldest(self):
        cfg = self.config(max_snapshots=3)
        for _ in range(6):
            session_memory.save_snapshot(RESULTS, {}, cfg)
        rows = session_memory.list_snapshots(cfg, limit=0)
        self.assertEqual(len(rows), 3)

    def test_disabled_flag_raises_explicitly(self):
        with self.assertRaises(RuntimeError):
            session_memory.save_snapshot(RESULTS, {}, self.config(enabled=False))


# ---------------------------------------------------------------------------
# 3. 历史画像落点与持久化
# ---------------------------------------------------------------------------

class TestDefaultProfilePath(TempDataDirCase):

    def test_relative_config_path_is_ignored(self):
        """config 写 profiles/history_aware.json 时绝不能生成在技能包内。"""
        path = default_profile_path({"history_aware": {
            "profile_file": "profiles/history_aware.json"}})
        self.assertEqual(Path(path).name, "history_profile.json")
        self.assert_outside_package(path)

    def test_absolute_config_path_is_respected(self):
        target = str(self.data_dir / "custom" / "profile.json")
        self.assertEqual(default_profile_path(
            {"history_aware": {"profile_file": target}}), target)

    def test_persistence_switches_return_empty(self):
        self.assertEqual(default_profile_path({"history_aware": {"persist_profile": False}}), "")
        self.assertEqual(default_profile_path(
            {"session_memory": {"history_aware_persistence": False}}), "")

    def test_default_is_inside_runtime_data_dir(self):
        self.assertEqual(Path(default_profile_path()),
                         self.data_dir / "history_profile.json")

    def test_config_json_profile_path_is_not_in_package(self):
        """仓库自带 config 的默认值必须过同一条规则——它是真实入口。"""
        cfg = json.loads((REPO_ROOT / "config.json").read_text(encoding="utf-8"))
        path = default_profile_path(cfg)
        if path:
            self.assert_outside_package(path)


class TestHistoryProfileMerge(unittest.TestCase):

    def messages(self, replies):
        msgs = []
        for i, reply in enumerate(replies):
            msgs.append(Message(sender="小李", content=f"在忙吗{i}",
                                timestamp=datetime(2024, 3, 1, 9, i)))
            msgs.append(Message(sender="我", content=reply,
                                timestamp=datetime(2024, 3, 1, 9, i + 30)))
        return msgs

    def test_export_then_import_survives_json(self):
        p = HistoryAwarePredictor({"history_aware": {"min_history": 2}})
        p.train(self.messages(["好的收到啦", "好的收到啦", "明天再说吧"]))
        payload = json.loads(json.dumps(p.export_profile(), ensure_ascii=False))
        self.assertEqual(payload["profile_version"], p.PROFILE_VERSION)

        q = HistoryAwarePredictor()
        self.assertTrue(q.import_profile(payload))
        self.assertEqual(dict(q._phrase_freq), dict(p._phrase_freq))
        self.assertEqual(q.trained_sessions, p.trained_sessions)

    def test_seed_merges_after_rebuild_not_before(self):
        """5 个学习器 train() 时 clear() 重建，种子必须在重建后并入才不丢。"""
        first = HistoryAwarePredictor({"history_aware": {"min_history": 2}})
        first.train(self.messages(["今天累死了", "今天累死了", "早点休息"]))

        seed = first.export_profile()
        second = HistoryAwarePredictor({"history_aware": {"min_history": 2}})
        second.import_profile(seed)
        stats = second.train(self.messages(["明天要去跑步", "明天要去跑步", "一起啊"]))

        self.assertTrue(stats["trained"])
        # 历史会话计数从 1 累到 2，说明画像真的并进来了
        self.assertEqual(second.trained_sessions, 2)
        self.assertIn("merged_history", stats)
        # 上一个会话学到的短语必须还在
        self.assertGreater(second._phrase_freq.get("今天累死了", 0), 0)

    def test_double_train_in_one_process_does_not_double_count(self):
        """同一进程 train 两次，历史只能并进来一次，否则会话数会越算越虚。"""
        p = HistoryAwarePredictor({"history_aware": {"min_history": 2}})
        p.import_profile({"profile_version": p.PROFILE_VERSION, "trained": True,
                          "trained_sessions": 3, "phrase_freq": {"收到": 2},
                          "self_msgs_tail": ["收到"]})
        p.train(self.messages(["好的好的", "好的好的", "嗯行"]))
        self.assertEqual(p.trained_sessions, 4)
        p.train(self.messages(["改天了", "改天了", "下次约"]))
        self.assertEqual(p.trained_sessions, 4)
        self.assertIsNone(p._seed_profile)

    def test_merge_history_off_keeps_session_only(self):
        p = HistoryAwarePredictor({"history_aware": {"min_history": 2,
                                                     "merge_history": False}})
        p.import_profile({"trained_sessions": 9, "phrase_freq": {"历史短语": 5},
                          "self_msgs_tail": ["历史短语"]})
        p.train(self.messages(["先这样", "先这样", "回头聊"]))
        self.assertEqual(p.trained_sessions, 1)
        self.assertEqual(p._phrase_freq.get("历史短语", 0), 0)

    def test_save_and_load_profile_roundtrip(self):
        p = HistoryAwarePredictor({"history_aware": {"min_history": 2}})
        p.train(self.messages(["可以的呀", "可以的呀", "没问题"]))
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "history_profile.json")
            self.assertEqual(p.save_profile(path), path)
            # 原子写：不能留下半个 .tmp
            self.assertEqual([f for f in os.listdir(tmp) if f.endswith(".tmp")], [])
            q = HistoryAwarePredictor()
            self.assertTrue(q.load_profile(path))
            self.assertEqual(dict(q._phrase_freq), dict(p._phrase_freq))

    def test_load_missing_or_corrupt_file_returns_false(self):
        p = HistoryAwarePredictor()
        self.assertFalse(p.load_profile(""))
        self.assertFalse(p.load_profile(str(Path(tempfile.gettempdir()) / "没有这个文件.json")))
        with tempfile.TemporaryDirectory() as tmp:
            bad = str(Path(tmp) / "bad.json")
            with open(bad, "w", encoding="utf-8") as f:
                f.write("{\"phrase_freq\": [坏")
            self.assertFalse(HistoryAwarePredictor().load_profile(bad))

    def test_import_profile_tolerates_garbage(self):
        """画像坏了、字段类型不对、来自旧版本，都不能让预测器崩。"""
        for junk in (None, [], "字符串", 42, {"phrase_freq": "不是字典"},
                     {"bigram_freq": {"a": None}}, {"context_pairs": ["x", [1, 2, 3]]},
                     {"trained_sessions": "很多"}):
            p = HistoryAwarePredictor()
            # 关键契约：任何畸形输入都只会被拒绝，不会抛异常拖垮整条预测链
            self.assertIsInstance(p.import_profile(junk), bool)


# ---------------------------------------------------------------------------
# 4. AI 洞察前置条件
# ---------------------------------------------------------------------------

class FakeEngine:
    """假引擎：记录收到的上下文，绝不联网。"""

    def __init__(self, content="洞察内容"):
        self.calls = []
        self.content = content

    def generate(self, insight_type, context, **kwargs):
        self.calls.append((insight_type, context))
        return InsightResult(insight_type=insight_type, success=True,
                             content=self.content, model="fake", is_fallback=False)


class TestInsightContext(unittest.TestCase):

    def test_missing_evidence_returns_none(self):
        for insight_type in ("personality_insight", "emotion_narrative",
                             "relationship_advice", "risk_interpretation",
                             "prediction_explanation"):
            self.assertIsNone(build_insight_context(insight_type, {}, ""),
                              f"{insight_type} 在零证据时必须返回 None")

    def test_prediction_explanation_needs_predicted_reply(self):
        self.assertIsNone(build_insight_context("prediction_explanation", RESULTS, "原文"))
        ctx = build_insight_context("prediction_explanation", RESULTS, "原文",
                                   {"predicted_reply": "好呀", "confidence": 62})
        self.assertEqual(ctx["predicted_reply"], "好呀")

    def test_personality_needs_real_type(self):
        for bad in ({"mbti": {"details": {"type": "未知"}}},
                    {"mbti": {"details": {"error": "样本不足"}}},
                    {}):
            self.assertIsNone(build_insight_context("personality_insight", bad, ""))

    def test_group_chat_relabels_relationship_context(self):
        results = dict(RESULTS, group={"details": {"is_group": True, "member_count": 4}})
        ctx = build_insight_context("relationship_advice", results, "原文")
        self.assertIn("群聊", ctx["relationship_type"])

    def test_unknown_dimension_degrades_to_placeholder(self):
        ctx = build_insight_context("relationship_advice", RESULTS, "")
        self.assertEqual(ctx["depth_score"], "未知")
        self.assertTrue(ctx["depth_desc"])


class TestMaskForLlm(unittest.TestCase):

    def test_pii_is_masked_before_cloud(self):
        masked = mask_for_llm("我的手机 13800138000，邮箱 a@b.com")
        self.assertNotIn("13800138000", masked)
        self.assertNotIn("a@b.com", masked)

    def test_opt_out_flags_return_raw(self):
        text = "手机 13800138000"
        for cfg in ({"privacy_scan": {"enabled": False}},
                    {"privacy_scan": {"mask_before_llm": False}}):
            self.assertEqual(mask_for_llm(text, cfg), text)

    def test_empty_text_passthrough(self):
        self.assertEqual(mask_for_llm(""), "")

    def test_mask_failure_sends_placeholder_not_raw(self):
        """脱敏本身报错时宁可不发原文，也不能裸发。"""
        import analyzers.privacy_scanner as ps
        previous = ps.mask_text
        ps.mask_text = lambda t: (_ for _ in ()).throw(RuntimeError("脱敏炸了"))
        try:
            out = mask_for_llm("手机 13800138000")
        finally:
            ps.mask_text = previous
        self.assertNotIn("13800138000", out)
        self.assertIn("隐私保护", out)


class TestAttachInsights(unittest.TestCase):

    def test_disabled_config_returns_empty(self):
        self.assertEqual(attach_insights(RESULTS, {"ai_insight": {"enabled": False}},
                                         "原文", FakeEngine()), {})

    def test_skip_reason_is_actionable(self):
        """缺预测结果时要告诉用户跑什么命令，不能只说"结果不足"。"""
        engine = FakeEngine()
        out = attach_insights(RESULTS, {}, "原文", engine, types=["prediction_explanation"])
        entry = out["prediction_explanation"]
        self.assertTrue(entry["skipped"])
        self.assertIn("predict", entry["reason"])
        self.assertEqual(engine.calls, [])

    def test_per_type_config_switch_is_respected(self):
        engine = FakeEngine()
        out = attach_insights(RESULTS, {"ai_insight": {"personality_insight": False}},
                              "原文", engine, types=["personality_insight", "emotion_narrative"])
        self.assertNotIn("personality_insight", out)
        self.assertIn("emotion_narrative", out)

    def test_missing_upstream_analyzer_is_reported_as_missing(self):
        out = attach_insights({}, {}, "原文", FakeEngine(), types=["emotion_narrative"])
        self.assertTrue(out["emotion_narrative"]["skipped"])
        self.assertIn("缺少分析结果", out["emotion_narrative"]["reason"])

    def test_happy_path_serializes_engine_result(self):
        engine = FakeEngine("这是一段洞察")
        out = attach_insights(RESULTS, {}, "原文", engine, types=["emotion_narrative"])
        entry = out["emotion_narrative"]
        self.assertFalse(entry["skipped"])
        self.assertEqual(entry["content"], "这是一段洞察")
        self.assertTrue(entry["success"])
        self.assertIn("model", entry)

    def test_generate_exception_does_not_break_local_analysis(self):
        class Boom:
            def generate(self, *a, **k):
                raise RuntimeError("云端挂了")

        out = attach_insights(RESULTS, {}, "原文", Boom(), types=["emotion_narrative"])
        self.assertTrue(out["emotion_narrative"]["skipped"])
        self.assertIn("生成失败", out["emotion_narrative"]["reason"])

    def test_text_is_masked_before_reaching_engine(self):
        engine = FakeEngine()
        attach_insights({"sentiment": {"details": {"positive": 1.0}}}, {},
                        "我的手机 13800138000", engine, types=["emotion_narrative"])
        _type, ctx = engine.calls[0]
        joined = json.dumps(ctx, ensure_ascii=False)
        self.assertNotIn("13800138000", joined)


# ---------------------------------------------------------------------------
# 5. 粘贴格式切分回归
# ---------------------------------------------------------------------------

class TestPasteSplitting(unittest.TestCase):

    def test_earliest_colon_wins(self):
        """内容里带全角冒号时不能切成两半——这是曾经的线上事故。"""
        sender, content = _split_sender_content("我: 注意：这个冒号别切")
        self.assertEqual(sender, "我")
        self.assertEqual(content, "注意：这个冒号别切")

    def test_full_width_colon_still_works(self):
        self.assertEqual(_split_sender_content("小李：周末有空吗"), ("小李", "周末有空吗"))

    def test_no_colon_keeps_whole_line_as_sender(self):
        sender, content = _split_sender_content("随手粘贴的一行")
        self.assertEqual(content, "")
        self.assertEqual(sender, "随手粘贴的一行")

    def test_leading_digit_is_not_a_name(self):
        """时间戳被切成"名字"时必须放弃这次切分。"""
        sender, content = _split_sender_content("2024: 后面是时间不是内容")
        self.assertEqual(sender, "2024: 后面是时间不是内容")
        self.assertEqual(content, "")

    def test_overlong_sender_is_rejected(self):
        long = "很" * 40
        self.assertEqual(_split_sender_content(f"{long}: 内容")[1], "")

    def test_inline_timestamp_wechat_line_has_content(self):
        """v5 修掉的 P0：时间 名字: 内容 单行格式解析后 content 为空，
        导致所有依赖内容的分析器静默跳过。"""
        parsed = SmartPasteParser.parse(
            "2026-10-01 09:12 小雨: 在吗\n2026-10-01 09:13 我: 在的", platform="wechat")
        self.assertEqual(len(parsed), 2)
        self.assertTrue(all(p.content.strip() for p in parsed), [p.raw for p in parsed])
        self.assertEqual(parsed[0].sender, "小雨")
        self.assertEqual(parsed[1].sender, "我")

    def test_simple_parser_strips_leading_timestamp(self):
        """行首时间不能被当成发送者名字，否则分析器全认不出"我"。"""
        parsed = SmartPasteParser.parse("2024-01-15 14:32 张三：你好啊", platform="simple")
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0].sender, "张三")
        self.assertEqual(parsed[0].content, "你好啊")
        self.assertEqual(parsed[0].timestamp, "2024-01-15 14:32")

    def test_simple_parser_attaches_continuation_lines(self):
        parsed = SmartPasteParser.parse(
            "2024-01-15 14:32 张三：你好啊\n一句没有名字的补充", platform="simple")
        self.assertEqual(len(parsed), 1)
        self.assertIn("你好啊", parsed[0].content)
        self.assertIn("一句没有名字的补充", parsed[0].content)

    def test_simple_parser_keeps_leading_orphan(self):
        parsed = SmartPasteParser.parse("开头就一句没名字的话\n我: 在的", platform="simple")
        self.assertTrue(any(p.role == "unknown" for p in parsed), [p.raw for p in parsed])
        self.assertTrue(any(p.sender == "我" and p.content == "在的" for p in parsed))

    def test_role_detection_matches_core_message(self):
        parsed = SmartPasteParser.parse("我: 在的\n对方: 好的", platform="simple")
        roles = {p.sender: p.role for p in parsed}
        self.assertEqual(roles.get("我"), "self")
        self.assertEqual(roles.get("对方"), "other")

    def test_self_check_covers_inline_paste(self):
        from scripts.data_source_importer import self_check
        report = self_check()
        self.assertTrue(report["all_passed"], json.dumps(
            [r for r in report["test_results"] if not r["match"]], ensure_ascii=False))
        cases = {r["case"] for r in report["test_results"]}
        self.assertTrue(any("inline" in c for c in cases), cases)


if __name__ == "__main__":
    unittest.main(verbosity=2)
