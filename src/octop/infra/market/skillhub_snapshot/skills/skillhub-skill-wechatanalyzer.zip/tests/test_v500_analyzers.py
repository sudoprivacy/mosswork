#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v5.0.0 新增分析器测试 — PrivacyScanner + GroupAnalyzer

覆盖两条主线：
    1. 规则顺序不能错（身份证 vs 银行卡 vs 手机号）——错了会漏报，
       而漏报比误报危险得多，因为用户看到"未发现"就放心转发了。
    2. 群聊识别不能把邮箱里的 @ 当成提及——假边会污染整个网络图。
"""

import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.dont_write_bytecode = True

import unittest

from analyzers.privacy_scanner import (
    PrivacyScanner, mask_text, scan_messages, _luhn_ok,
)
from analyzers.group_analyzer import (
    GroupAnalyzer, extract_sub_conversation, group_messages,
)
from core.message import Message, MessageType


def _msgs(pairs):
    """[(sender, content)] → Message 列表（带递增时间戳）。"""
    base = datetime(2026, 3, 1, 9, 0, 0)
    return [
        Message(sender=s, content=c, timestamp=base.replace(minute=i),
                message_type=MessageType.TEXT, raw=f"{s}: {c}",
                metadata={"role": "self" if s == "我" else "other"})
        for i, (s, c) in enumerate(pairs)
    ]


# ============================================================================
# 隐私扫描
# ============================================================================

class TestPrivacyScanner(unittest.TestCase):

    def setUp(self):
        self.scanner = PrivacyScanner()

    def _types(self, text):
        return [ptype for ptype, _hit, _s, _e in self.scanner.scan_text(text)]

    def test_id_card_beats_phone(self):
        """18 位身份证必须整体识别成 id_card，不能被手机号规则咬碎。"""
        hits = self.scanner.scan_text("我身份证 110101199003074512 帮我登记")
        self.assertEqual([h[0] for h in hits], ["id_card"])
        self.assertEqual(hits[0][1], "110101199003074512")

    def test_phone_detected(self):
        self.assertEqual(self._types("手机号13812345678"), ["phone"])

    def test_valid_card_is_bank_card(self):
        self.assertEqual(self._types("卡 4111 1111 1111 1111"), ["bank_card"])

    def test_order_number_downgraded(self):
        """过不了 Luhn 的长数字不该冒充银行卡号。"""
        self.assertFalse(_luhn_ok("1234567890123456789"))
        self.assertEqual(self._types("订单号 1234567890123456789"), ["long_number"])

    def test_luhn_accepts_known_test_pan(self):
        self.assertTrue(_luhn_ok("4111111111111111"))

    def test_email_and_wechat_id(self):
        types = self._types("微信号 zhangsan_2020 邮箱 liu@example.com")
        self.assertIn("wechat_id", types)
        self.assertIn("email", types)

    def test_api_key(self):
        self.assertEqual(self._types("api_key: sk-abcd1234efgh5678"), ["api_key"])

    def test_address_needs_separator(self):
        """"地址你给我发一下" 不是地址，不该报高风险。"""
        self.assertEqual(self._types("地址你给我发一下"), [])
        self.assertIn("address", self._types("住址：北京市朝阳区建国路88号"))

    def test_landline(self):
        self.assertEqual(self._types("座机 010-88886666 转 302"), ["landline"])

    def test_no_false_positive_on_plain_chat(self):
        for text in ["收到，谢谢！", "我们 12 个人，预算 3000 左右",
                     "定 6 点 30 分集合", "2024-01-15 14:32:15 张三: 你好"]:
            self.assertEqual(self._types(text), [], f"误报: {text}")

    def test_honorific_is_not_name(self):
        """中文没有词边界，"谢谢张老师" 里的称呼不能当姓名。"""
        self.assertEqual(self._types("谢谢张老师，改天聚聚"), [])

    def test_explicit_name_is_candidate(self):
        self.assertEqual(self._types("我叫刘梅"), ["real_name_candidate"])

    def test_mask_unmask_roundtrip(self):
        raw = "我手机 13812345678，微信 zhangsan_2020"
        masked, mapping = self.scanner.mask_text(raw)
        self.assertNotIn("13812345678", masked)
        self.assertIn("[手机号1]", masked)
        self.assertEqual(self.scanner.unmask_text(masked, mapping), raw)

    def test_mask_no_hit_returns_unchanged(self):
        masked, mapping = self.scanner.mask_text("今晚七点老地方")
        self.assertEqual(masked, "今晚七点老地方")
        self.assertEqual(mapping, {})

    def test_scan_level(self):
        report = self.scanner.scan(_msgs([
            ("我", "我身份证 110101199003074512"),
            ("张三", "好的，我记下了"),
        ]))
        self.assertEqual(report["level"], "high")
        self.assertGreaterEqual(report["total_hits"], 1)
        self.assertEqual(report["by_type"]["id_card"]["risk"], "high")

    def test_scan_clean_level_none(self):
        report = self.scanner.scan(_msgs([("我", "明天见"), ("张三", "好")]))
        self.assertEqual(report["level"], "none")
        self.assertEqual(report["total_hits"], 0)

    def test_analyze_result_shape(self):
        result = self.scanner.analyze(_msgs([("我", "手机 13812345678")])).to_dict()
        self.assertEqual(result["analyzer_name"], "privacy")
        self.assertIn("summary", result["details"])
        self.assertIn("scanned_messages", result["details"])
        self.assertTrue(result["details"]["summary"])

    def test_validate_requires_text_content(self):
        self.assertFalse(self.scanner.validate([]))
        self.assertFalse(self.scanner.validate(
            [Message(sender="我", content="   ", message_type=MessageType.IMAGE)]))
        self.assertTrue(self.scanner.validate(_msgs([("我", "你好")])))

    def test_samples_are_obscured(self):
        """即使打开 samples，也不能出现完整原文。"""
        scanner = PrivacyScanner({"privacy_scan": {"include_samples": True}})
        report = scanner.scan(_msgs([("我", "手机 13812345678")]))
        samples = report["by_type"]["phone"]["samples"]
        self.assertTrue(samples)
        for s in samples:
            self.assertNotIn("13812345678", s)
            self.assertIn("*", s)

    def test_default_config_hides_samples(self):
        """默认 include_samples=false：不把（哪怕打码的）PII 片段再复制进报告。"""
        report = PrivacyScanner({"privacy_scan": {}}).scan(_msgs([("我", "手机 13812345678")]))
        self.assertEqual(report["by_type"]["phone"]["samples"], [])

    def test_module_level_helpers(self):
        report = scan_messages(_msgs([("我", "手机 13812345678")]))
        self.assertEqual(report["total_hits"], 1)
        masked, mapping = mask_text("手机 13812345678")
        self.assertTrue(mapping and "13812345678" not in masked)

    def test_scanner_is_local_only(self):
        """隐私扫描不许引入任何网络栈。"""
        source = (PROJECT_ROOT / "analyzers" / "privacy_scanner.py").read_text(encoding="utf-8")
        for banned in ("import requests", "import socket", "urllib", "httpx", "openai"):
            self.assertNotIn(banned, source, f"隐私扫描器不应出现 {banned}")


# ============================================================================
# 群聊分析
# ============================================================================

GROUP = _msgs([
    ("我", "@张三 方案定了吗"),
    ("张三", "还没，我今晚看看"),
    ("李四", "我这边数据跑完了"),
    ("张三", "@李四 发群里吧"),
    ("王五", "【图片】"),
    ("我", "@张三 定个时间"),
    ("赵六", "收到"),
    ("张三", "明天上午十点"),
    ("李四", "我都可以"),
    ("我", "行，明天见"),
])


class TestGroupAnalyzer(unittest.TestCase):

    def setUp(self):
        self.analyzer = GroupAnalyzer()
        self.details = self.analyzer.analyze(GROUP).to_dict()["details"]

    def test_detected_as_group(self):
        self.assertTrue(self.details["is_group"])
        # 王五只发了"【图片】"，被当系统噪声过滤 → 4 位真实成员
        self.assertEqual(self.details["member_count"], 4)

    def test_roster_shares_sum_to_100(self):
        total = sum(r["share"] for r in self.details["roster"])
        self.assertAlmostEqual(total, 100.0, delta=0.5)

    def test_roster_sorted_desc(self):
        shares = [r["share"] for r in self.details["roster"]]
        self.assertEqual(shares, sorted(shares, reverse=True))

    def test_system_message_excluded(self):
        """"【图片】" 不该算作一次发言。"""
        self.assertNotIn("王五", [r["sender"] for r in self.details["roster"]])

    def test_mention_edges(self):
        edges = {(e["from"], e["to"]): e["count"] for e in self.details["mention_edges"]}
        self.assertEqual(edges[("我", "张三")], 2)
        self.assertEqual(edges[("张三", "李四")], 1)

    def test_email_at_is_not_mention(self):
        """邮箱里的 @ 必须被忽略，否则网络图出现指向域名的假边。"""
        msgs = _msgs([("李四", "邮箱 lisi@example.com 收到了"), ("我", "好的")])
        details = GroupAnalyzer().analyze(msgs).to_dict()["details"]
        for edge in details["mention_edges"]:
            self.assertNotIn("example.com", edge["to"])

    def test_single_chat_not_group(self):
        msgs = _msgs([("我", "在吗"), ("对方", "在的"), ("我", "吃饭吗")])
        details = GroupAnalyzer().analyze(msgs).to_dict()["details"]
        self.assertFalse(details["is_group"])
        self.assertIn("一对一", details["note"])

    def test_dominance(self):
        even = GroupAnalyzer._dominance([0.5, 0.5])
        lopsided = GroupAnalyzer._dominance([0.9, 0.1])
        self.assertLess(even, lopsided)
        self.assertAlmostEqual(lopsided, 0.531, delta=0.01)

    def test_top_pairs_and_balance(self):
        pairs = self.details["top_pairs"]
        self.assertTrue(pairs)
        for p in pairs:
            self.assertIn(" <-> ", p["pair"])
            self.assertLessEqual(p["balance"], 1.0)

    def test_tiers_summary_counts_members(self):
        tiers = self.details["tiers"]
        self.assertEqual(sum(tiers.values()), self.details["member_count"])

    def test_note_warns_about_other_analyzers(self):
        self.assertIn("不可靠", self.details["note"])

    def test_extract_sub_conversation(self):
        sub = extract_sub_conversation(GROUP, "我", "张三")
        self.assertTrue(sub)
        self.assertEqual({m.sender for m in sub}, {"我", "张三"})

    def test_group_messages(self):
        buckets = group_messages(GROUP)
        self.assertEqual(sum(len(v) for v in buckets.values()), len(GROUP))
        self.assertIn("李四", buckets)

    def test_registered_in_default_registry(self):
        from analyzers import create_default_registry
        registry = create_default_registry({})
        self.assertIn("group", registry.list())
        self.assertIn("privacy", registry.list())

    def test_can_be_disabled_by_config(self):
        from analyzers import create_default_registry
        registry = create_default_registry(
            {"analysis": {"group_enabled": False, "privacy_scan_enabled": False}})
        self.assertNotIn("group", registry.list())
        self.assertNotIn("privacy", registry.list())

    def test_empty_and_degenerate_input(self):
        details = GroupAnalyzer().analyze([Message(sender="我", content="嗯")]).to_dict()["details"]
        self.assertEqual(details["member_count"], 1)
        self.assertFalse(details["is_group"])
        self.assertEqual(details["top_pairs"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
