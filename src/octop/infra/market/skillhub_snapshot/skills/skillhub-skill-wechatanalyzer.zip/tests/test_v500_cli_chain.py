# -*- coding: utf-8 -*-
"""
v5.0.0 CLI 接线测试 (test_v500_cli_chain.py)

CLI 是 v5 里最容易"接了但没通"的一层：模块单测过、MCP 也过，但命令行用户
拿到的还是旧行为。这里盯三条 CLI 专属链路：

- DataManager._parse_line      粘贴兜底解析器（v1 analyze 的唯一入口）
- _import_container_text       整份导出文件走多源导入器，普通粘贴必须让路
- cmd_capture                  桌面捕获的平台与前置条件守卫

无网络、不碰真实微信窗口、产物不落源码树。
"""
import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "scripts"))

os.environ.pop("DEEPSEEK_API_KEY", None)
os.environ.pop("OPENAI_API_KEY", None)

from scripts.data_manager import DataManager                        # noqa: E402
from scripts.main import _import_container_text, cmd_capture        # noqa: E402

STRUCTURED_HTML = """<html><body>
<div class="message-row">
  <span class="sender">我</span><span class="time">2024-03-01 09:12:00</span>
  <div class="content">周末有空吗</div>
</div>
<div class="message-row">
  <span class="nickname">小李</span><span class="time">2024-03-01 09:15:30</span>
  <div class="content">有啊，去哪</div>
</div>
</body></html>"""

CSV_TEXT = ("sender,time,content\n"
            "我,2024-03-01 09:12:00,周末有空吗\n"
            "小李,2024-03-01 09:15:30,有啊，去哪\n")

JSON_TEXT = json.dumps([
    {"sender": "我", "time": "2024-03-01 09:12:00", "content": "周末有空吗"},
    {"sender": "小李", "content": "有啊，去哪"},
], ensure_ascii=False)

PLAIN_PASTE = "2024-01-15 14:32:15 张三: 你好啊\n2024-01-15 14:33:00 我: 在的"


# ---------------------------------------------------------------------------
# 1. 粘贴兜底解析器
# ---------------------------------------------------------------------------

class TestDataManagerLineParser(unittest.TestCase):
    """_parse_line 不需要 DB，用 __new__ 绕过 __init__ 建表副作用。"""

    def setUp(self):
        self.dm = object.__new__(DataManager)

    def parse(self, line):
        return self.dm._parse_line(line)

    def test_inline_timestamp_is_not_chewed_into_sender(self):
        """v5 修掉的第二个 P0：微信复制出来的单行时间戳会被切成
        sender="2024-01-15 14"，v1 analyze 路径拿不到发言人。"""
        for line, ts in (("2024-01-15 14:32:15 张三: 你好啊", "2024-01-15 14:32:15"),
                         ("2024-01-15 14:32 张三: 你好啊", "2024-01-15 14:32"),
                         ("2024/6/1 9:05 小李：在吗", "2024/6/1 9:05")):
            got = self.parse(line)
            self.assertEqual(got["sender"], ("张三" if "张三" in line else "小李"), line)
            self.assertEqual(got["timestamp"], ts, line)
            self.assertTrue(got["content"], line)

    def test_bare_timestamp_line_is_dropped(self):
        """分隔行不能变成一条消息——秒可省的那种也要认出。"""
        for line in ("2024-01-01 12:30:00", "2024-01-01 12:30", "2024-01-01  12:30:00"):
            self.assertIsNone(self.parse(line), line)

    def test_separator_lines_dropped(self):
        for line in ("-----", "=====", "*****", "———"):
            self.assertIsNone(self.parse(line), line)

    def test_bracketed_and_pipe_formats_still_work(self):
        self.assertEqual(self.parse("[2024-01-01 12:30:00] 张三: 早")["sender"], "张三")
        self.assertEqual(self.parse("2024-01-01 12:30:00 | 张三 | 早")["content"], "早")

    def test_content_colon_does_not_eat_the_name(self):
        got = self.parse("我: 注意：这个冒号别切")
        self.assertEqual(got["sender"], "我")
        self.assertEqual(got["content"], "注意：这个冒号别切")

    def test_bare_line_treated_as_self_message(self):
        """按设计约定无发送者的裸行算"我"说的，之前写成 other 统计全颠倒。"""
        got = self.parse("裸内容没有冒号")
        self.assertEqual(got["sender"], "self")
        self.assertEqual(got["content"], "裸内容没有冒号")

    def test_long_message_not_truncated_at_100(self):
        """微信一条长消息能到几百字，早期正则在第 100 字硬切并丢掉余下内容。"""
        long = "我" * 300
        self.assertEqual(self.parse(long)["content"], long)

    def test_parse_text_input_mixes_good_and_junk_lines(self):
        msgs = self.dm.parse_text_input(
            "2024-01-15 14:32:15 张三: 你好啊\n----\n我: 在的\n")
        self.assertEqual(len(msgs), 2)
        self.assertEqual([m["sender"] for m in msgs], ["张三", "我"])


# ---------------------------------------------------------------------------
# 2. 整份导出的容器识别
# ---------------------------------------------------------------------------

class TestContainerImport(unittest.TestCase):

    def import_(self, text, platform="auto"):
        buf = io.StringIO()
        with redirect_stdout(buf):
            out = _import_container_text(text, platform)
        return out, buf.getvalue()

    def test_html_container_routes_to_importer(self):
        out, log = self.import_(STRUCTURED_HTML)
        self.assertEqual(len(out), 2)
        self.assertEqual(out[0]["content"], "周末有空吗")
        self.assertIn("wechat_html", log)

    def test_csv_container_carries_timestamp(self):
        out, log = self.import_(CSV_TEXT)
        self.assertEqual(len(out), 2)
        self.assertEqual(out[0]["timestamp"], "2024-03-01T09:12:00")
        self.assertIn("csv", log)

    def test_json_container_reports_source_not_none(self):
        out, log = self.import_(JSON_TEXT)
        self.assertEqual(len(out), 2)
        self.assertNotIn("None", log)
        self.assertIn("json", log)

    def test_plain_paste_yields_to_line_parser(self):
        """返回 None 是契约：粘贴文本必须交回 dm.parse_text_input，
        否则逐行格式会被结构化导入器误吞。"""
        out, log = self.import_(PLAIN_PASTE)
        self.assertIsNone(out)
        self.assertEqual(log, "")

    def test_empty_and_garbage_yield_none(self):
        for text in ("", "  \n ", "不是聊天记录的一段散文"):
            self.assertIsNone(self.import_(text)[0], repr(text))

    def test_importer_exception_does_not_break_cli(self):
        """导入器崩了只能提示并降级，不能让 analyze 整条命令挂掉。"""
        import scripts.data_source_importer as dsi

        def boom(self, t, platform="auto"):
            raise RuntimeError("导入器炸了")

        original = dsi.MultiSourceImporter.import_text
        dsi.MultiSourceImporter.import_text = boom
        try:
            out, log = self.import_(PLAIN_PASTE)
        finally:
            dsi.MultiSourceImporter.import_text = original
        self.assertIsNone(out)
        self.assertIn("改用逐行解析", log)

    def test_missing_fields_default_to_unknown_sender(self):
        text = json.dumps([{"content": "没有发送者"}], ensure_ascii=False)
        out, _ = self.import_(text)
        self.assertEqual(out[0]["sender"], "unknown")
        self.assertIsNone(out[0]["timestamp"])

    def test_explicit_platform_hint_is_honoured(self):
        out, _ = self.import_(CSV_TEXT, platform="csv")
        self.assertEqual(len(out), 2)
        # 点名 JSON 却给了粘贴文本：必须让路，不能硬解出一堆假消息
        self.assertIsNone(self.import_(PLAIN_PASTE, platform="json")[0])


# ---------------------------------------------------------------------------
# 3. 桌面捕获守卫
# ---------------------------------------------------------------------------

class _Args:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class TestCaptureGuards(unittest.TestCase):
    """cmd_capture 的真实抓屏路径不在测试里跑，只验证它拒绝得干净。"""

    def test_non_windows_platform_declines_with_alternative(self):
        original = sys.platform
        buf = io.StringIO()
        try:
            sys.platform = "darwin"
            with redirect_stdout(buf):
                out = cmd_capture(_Args(source="window"))
        finally:
            sys.platform = original
        self.assertIsNone(out)
        text = buf.getvalue()
        self.assertIn("仅 Windows", text)
        # 拒绝的同时必须给出可用的替代命令
        self.assertIn("analyze-v2", text)

    def test_wechat_not_running_declines_before_touching_window(self):
        import scripts.wechat_window_reader as wr
        called = []
        original = wr.WeChatWindowReader.is_wechat_running
        original_state = wr.WeChatWindowReader.capture_state
        wr.WeChatWindowReader.is_wechat_running = lambda self: False
        wr.WeChatWindowReader.capture_state = lambda self: called.append(1)
        try:
            buf = io.StringIO()
            with redirect_stdout(buf):
                out = cmd_capture(_Args(source="window"))
        finally:
            wr.WeChatWindowReader.is_wechat_running = original
            wr.WeChatWindowReader.capture_state = original_state
        if sys.platform == "win32":
            self.assertIsNone(out)
            self.assertIn("未找到微信桌面端窗口", buf.getvalue())
            self.assertEqual(called, [], "微信没开时不该去读窗口")


# ---------------------------------------------------------------------------
# 4. v1 统计口径（dict 通道）
# ---------------------------------------------------------------------------

class TestV1StatsWiring(unittest.TestCase):
    """v1 走的是 dict 消息，sender 是"我"而不是 'self'。
    旧代码按 'self' 精确比对，导致"你的消息"永远是 0、给对方贴"对方"标签，
    连送进大模型的对话都是反的。"""

    LEGACY = [
        {"sender": "我", "content": "在的", "timestamp": "2024-03-01T09:12:00"},
        {"sender": "小李", "content": "周末有空吗", "timestamp": "2024-03-01T09:15:00"},
        {"sender": "self", "content": "有空", "timestamp": "2024-03-01T09:16:00"},
    ]

    def test_stats_count_both_self_labels(self):
        from scripts.text_analyzer import TextAnalyzer
        analyzer = TextAnalyzer.__new__(TextAnalyzer)
        stats = analyzer._analyze_stats(self.LEGACY)
        self.assertEqual(stats["total_messages"], 3)
        self.assertEqual(stats["self_messages"], 2)
        self.assertEqual(stats["other_messages"], 1)

    def test_llm_transcript_labels_are_not_inverted(self):
        from scripts.llm_analyzer import LLMAnalyzer
        analyzer = LLMAnalyzer.__new__(LLMAnalyzer)
        text = analyzer._format_chat(self.LEGACY)
        self.assertIn("我：在的", text)
        self.assertIn("对方：周末有空吗", text)
        self.assertIn("我：有空", text)
        self.assertNotIn("对方：在的", text)

    def test_missing_sender_does_not_crash(self):
        from scripts.text_analyzer import TextAnalyzer
        analyzer = TextAnalyzer.__new__(TextAnalyzer)
        stats = analyzer._analyze_stats([{"content": "没有发送者"}, {"sender": None}])
        self.assertEqual(stats["self_messages"], 0)
        self.assertEqual(stats["total_messages"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
