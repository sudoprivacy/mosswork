# -*- coding: utf-8 -*-
"""
v3.0.0 AI 洞察引擎测试 (test_v300_ai_insight.py)

覆盖：
- LLMConfig 数据类
- LLMClient HTTP 调用（mock）
- AIInsightEngine 缓存/降级/正常路径
- 5 类洞察模板
- 配置加载（环境变量 + config.json）
- 隐私脱敏功能

不依赖真实 LLM API（通过 mock 或 fallback 路径测试）。
"""
import json
import os
import sys
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestLLMConfig(unittest.TestCase):
    """测试 LLMConfig 数据类。"""

    def test_default_values(self):
        from analyzers.ai_insight_engine import LLMConfig
        config = LLMConfig()
        self.assertEqual(config.provider, "deepseek")
        self.assertIn("deepseek", config.base_url)
        self.assertEqual(config.temperature, 0.5)
        self.assertEqual(config.max_tokens, 2000)

    def test_custom_values(self):
        from analyzers.ai_insight_engine import LLMConfig
        config = LLMConfig(
            provider="openai",
            base_url="https://api.openai.com",
            model="gpt-4",
            api_key="sk-test",
            temperature=0.7,
            max_tokens=4000,
        )
        self.assertEqual(config.provider, "openai")
        self.assertEqual(config.model, "gpt-4")


class TestConfigLoading(unittest.TestCase):
    """测试配置加载。"""

    def test_env_var_overrides(self):
        from analyzers.ai_insight_engine import load_llm_config
        env = {k: v for k, v in os.environ.items()
               if k not in ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "LLM_API_KEY", "LLM_PROVIDER")}
        env["DEEPSEEK_API_KEY"] = "env-key-123"
        with patch.dict(os.environ, env, clear=True):
            config = load_llm_config(config_path="/nonexistent.json")
            self.assertEqual(config.api_key, "env-key-123")

    def test_default_when_no_config(self):
        from analyzers.ai_insight_engine import load_llm_config
        config = load_llm_config(config_path="/nonexistent/path.json")
        self.assertEqual(config.provider, "deepseek")
        self.assertIn("deepseek", config.base_url)

    def test_openai_provider_url_fallback(self):
        from analyzers.ai_insight_engine import load_llm_config
        env = {k: v for k, v in os.environ.items()
               if k not in ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "LLM_API_KEY", "LLM_PROVIDER")}
        env["OPENAI_API_KEY"] = "sk-test"
        env["LLM_PROVIDER"] = "openai"
        with patch.dict(os.environ, env, clear=True):
            config = load_llm_config(config_path="/nonexistent.json")
            self.assertEqual(config.provider, "openai")
            self.assertIn("openai.com", config.base_url)


class TestPromptTemplates(unittest.TestCase):
    """测试提示词模板。"""

    def test_all_templates_defined(self):
        from analyzers.ai_insight_engine import PROMPT_TEMPLATES
        expected = ["personality_insight", "emotion_narrative",
                    "relationship_advice", "risk_interpretation",
                    "prediction_explanation"]
        for name in expected:
            self.assertIn(name, PROMPT_TEMPLATES)

    def test_personality_template(self):
        from analyzers.ai_insight_engine import PROMPT_TEMPLATES
        template = PROMPT_TEMPLATES["personality_insight"]
        self.assertIn("MBTI", template)
        self.assertIn("mbti_type", template)

    def test_relationship_template(self):
        from analyzers.ai_insight_engine import PROMPT_TEMPLATES
        template = PROMPT_TEMPLATES["relationship_advice"]
        self.assertIn("balance_score", template)
        self.assertIn("relationship_type", template)

    def test_risk_template(self):
        from analyzers.ai_insight_engine import PROMPT_TEMPLATES
        template = PROMPT_TEMPLATES["risk_interpretation"]
        self.assertIn("risk_type", template)
        self.assertIn("confidence", template)


class TestLLMClient(unittest.TestCase):
    """测试 LLM 客户端 HTTP 调用。"""

    def test_unavailable_without_api_key(self):
        from analyzers.ai_insight_engine import LLMClient, LLMConfig
        config = LLMConfig(provider="deepseek", api_key="")
        client = LLMClient(config)
        self.assertFalse(client.is_available())
        result = client.chat([{"role": "user", "content": "hi"}])
        self.assertFalse(result["success"])

    def test_chat_success(self):
        from analyzers.ai_insight_engine import LLMClient, LLMConfig
        config = LLMConfig(provider="deepseek", api_key="sk-test")
        client = LLMClient(config)

        mock_response = MagicMock()
        mock_response.read = MagicMock(return_value=json.dumps({
            "choices": [{"message": {"content": "AI 洞察"}}],
            "model": "deepseek-chat",
            "usage": {"total_tokens": 150},
        }).encode("utf-8"))
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        # ai_insight_engine 直接 import 了 urlopen
        with patch("analyzers.ai_insight_engine.urlopen", return_value=mock_response):
            result = client.chat([{"role": "user", "content": "分析"}])
            self.assertTrue(result["success"])
            self.assertEqual(result["content"], "AI 洞察")

    def test_chat_strips_think_tag(self):
        """应剥离 <think>...</think> 标签。"""
        from analyzers.ai_insight_engine import LLMClient, LLMConfig
        config = LLMConfig(provider="deepseek", api_key="sk-test")
        client = LLMClient(config)

        mock_response = MagicMock()
        mock_response.read = MagicMock(return_value=json.dumps({
            "choices": [{"message": {"content": "<think>reasoning</think>\n实际回答"}}],
            "model": "deepseek-r1",
        }).encode("utf-8"))
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("analyzers.ai_insight_engine.urlopen", return_value=mock_response):
            result = client.chat([{"role": "user", "content": "x"}])
            self.assertTrue(result["success"])
            self.assertNotIn("<think>", result["content"])
            self.assertIn("实际回答", result["content"])

    def test_chat_http_error(self):
        from analyzers.ai_insight_engine import LLMClient, LLMConfig
        from urllib.error import HTTPError
        config = LLMConfig(provider="deepseek", api_key="sk-test")
        client = LLMClient(config)

        err = HTTPError(url="http://x", code=401, msg="Unauthorized", hdrs={}, fp=None)
        with patch("analyzers.ai_insight_engine.urlopen", side_effect=err):
            result = client.chat([{"role": "user", "content": "x"}])
            self.assertFalse(result["success"])
            self.assertIn("401", result["error"])

    def test_chat_network_error(self):
        from analyzers.ai_insight_engine import LLMClient, LLMConfig
        from urllib.error import URLError
        config = LLMConfig(provider="deepseek", api_key="sk-test")
        client = LLMClient(config)

        with patch("analyzers.ai_insight_engine.urlopen",
                   side_effect=URLError("connection refused")):
            result = client.chat([{"role": "user", "content": "x"}])
            self.assertFalse(result["success"])
            self.assertIn("网络", result["error"])


class TestPrivacySanitization(unittest.TestCase):
    """测试隐私脱敏功能。"""

    def test_sanitize_phone(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key=""))
        text = "我的手机是13812345678"
        sanitized = engine._sanitize_chat_content(text)
        self.assertNotIn("13812345678", sanitized)
        self.assertIn("[手机号]", sanitized)

    def test_sanitize_id_card(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key=""))
        text = "身份证号110101199003078888"
        sanitized = engine._sanitize_chat_content(text)
        self.assertIn("[身份证]", sanitized)

    def test_sanitize_bank_card(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key=""))
        text = "卡号6225888812345678"
        sanitized = engine._sanitize_chat_content(text)
        self.assertIn("[银行卡]", sanitized)

    def test_sanitize_truncation(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key=""))
        text = "a" * 5000
        sanitized = engine._sanitize_chat_content(text, max_len=1000)
        self.assertLess(len(sanitized), 1500)  # 包含截断标记
        self.assertIn("已截断", sanitized)


class TestEngineFallback(unittest.TestCase):
    """测试 LLM 不可用时的降级路径。"""

    def test_unavailable_uses_fallback(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key=""))
        result = engine.generate("personality_insight", {
            "mbti_type": "INTJ",
            "mbti_confidence": "78",
            "dimension_scores": "I:65, N:80",
            "openness": "70", "conscientiousness": "85",
            "extraversion": "30", "agreeableness": "55", "neuroticism": "40",
            "key_messages": "test",
        }, use_cache=False)
        self.assertTrue(result.success)
        self.assertTrue(result.is_fallback)
        self.assertIn("规则引擎", result.content)


class TestEngineSuccess(unittest.TestCase):
    """测试 LLM 可用时的成功路径。"""

    def test_successful_generation(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key="sk-test"))
        self.assertTrue(engine.is_available())

        mock_response = MagicMock()
        mock_response.read = MagicMock(return_value=json.dumps({
            "choices": [{"message": {"content": "AI 性格解读内容"}}],
            "model": "deepseek-chat",
            "usage": {"total_tokens": 200},
        }).encode("utf-8"))
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        with patch("analyzers.ai_insight_engine.urlopen", return_value=mock_response):
            result = engine.generate("personality_insight", {
                "mbti_type": "INTJ", "mbti_confidence": "78",
                "dimension_scores": "I:65",
                "openness": "70", "conscientiousness": "85",
                "extraversion": "30", "agreeableness": "55", "neuroticism": "40",
                "key_messages": "test",
            }, use_cache=False)
            self.assertTrue(result.success)
            self.assertFalse(result.is_fallback)
            self.assertEqual(result.tokens_used, 200)
            self.assertIn("AI 性格解读内容", result.content)
            # 免责声明应自动追加
            self.assertIn("免责", result.content)


class TestCache(unittest.TestCase):
    """测试缓存机制。"""

    def test_cache_hit(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key="sk-test"))

        mock_response = MagicMock()
        mock_response.read = MagicMock(return_value=json.dumps({
            "choices": [{"message": {"content": "cached"}}],
        }).encode("utf-8"))
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        ctx = {"mbti_type": "ENFP", "mbti_confidence": "80",
               "dimension_scores": "E:60",
               "openness": "70", "conscientiousness": "85",
               "extraversion": "30", "agreeableness": "55", "neuroticism": "40",
               "key_messages": "x"}

        with patch("analyzers.ai_insight_engine.urlopen", return_value=mock_response) as m:
            r1 = engine.generate("personality_insight", ctx, use_cache=True)
            r2 = engine.generate("personality_insight", ctx, use_cache=True)
            self.assertEqual(m.call_count, 1)
            self.assertEqual(r1.content, r2.content)

    def test_clear_cache(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key=""))
        engine.generate("emotion_narrative", {"overall_tone": "neutral"}, use_cache=True)
        self.assertGreater(len(engine._cache), 0)
        engine.clear_cache()
        self.assertEqual(len(engine._cache), 0)


class TestUnknownType(unittest.TestCase):
    """测试未知洞察类型。"""

    def test_unknown_returns_failure(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(api_key="sk-test"))
        result = engine.generate("nonexistent_insight", {}, use_cache=False)
        self.assertFalse(result.success)
        self.assertIn("提示词", result.error)


class TestSelfCheck(unittest.TestCase):
    """测试自检函数。"""

    def test_self_check(self):
        from analyzers.ai_insight_engine import self_check
        result = self_check()
        # 版本号只验格式：写死 "v3.0" 让每次升级都得来改这里，
        # 而自检本来就该跟着 core.version 走。
        self.assertRegex(result["version"], r"^v\d+\.\d+(\.\d+)?$")
        self.assertEqual(result["template_count"], 5)
        self.assertIn("personality_insight", result["prompt_templates"])
        self.assertTrue(result["context_build_ok"])


class TestEngineStatus(unittest.TestCase):
    """测试引擎状态。"""

    def test_status_fields(self):
        from analyzers.ai_insight_engine import AIInsightEngine, LLMConfig
        engine = AIInsightEngine(LLMConfig(provider="deepseek", api_key="sk-test"))
        status = engine.status()
        self.assertIn("provider", status)
        self.assertIn("model", status)
        self.assertIn("available", status)
        self.assertIn("api_key_configured", status)
        self.assertTrue(status["api_key_configured"])
        self.assertTrue(status["available"])


if __name__ == "__main__":
    unittest.main()
