"""tests/test_v290.py — v2.9.0 新增能力测试

覆盖：
1. RelationshipAnalyzer：五维评分 / 冷回复惩罚 / 等级边界 / 建议生成 / 注册接线
2. SentimentAnalyzer v2.9 字段：rolling_trend / turning_points / self_* / 向后兼容
3. voice_interface：归一化 / 文件路径提取 / 口语指令解析
4. VoiceAssistant 会话（注入假执行器/扬声器/脚本监听器）
5. Speaker / Listener 降级链
6. 版本一致性（v2.9 由本文件接管断言）
"""

import json
import re
import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from core.message import Message
from analyzers.relationship_analyzer import RelationshipAnalyzer
from analyzers.sentiment_analyzer import SentimentAnalyzer
import voice_interface as vi


def _mk(sender, content, ts=None):
    return Message(sender=sender, content=content, timestamp=ts)


def _balanced_msgs(n=10, base=None):
    """双方交替、内容均衡的消息（含时间戳）。"""
    base = base or datetime(2026, 8, 1, 10, 0, 0)
    msgs = []
    for i in range(n):
        sender = "self" if i % 2 == 0 else "other"
        msgs.append(_mk(sender, f"今天天气真不错啊第{i}条", base + timedelta(seconds=30 * i)))
    return msgs


# ============================================================
# 1. 关系健康度分析器
# ============================================================

class TestRelationshipAnalyzer(unittest.TestCase):

    def setUp(self):
        self.analyzer = RelationshipAnalyzer()

    def test_validate_requires_both_sides(self):
        one_side = [_mk("self", f"消息{i}号内容够长") for i in range(10)]
        self.assertFalse(self.analyzer.validate(one_side))
        self.assertTrue(self.analyzer.validate(_balanced_msgs()))

    def test_validate_requires_min_messages(self):
        msgs = [_mk("self", "你好"), _mk("other", "你好")]
        self.assertFalse(self.analyzer.validate(msgs))

    def test_balance_symmetric_is_high(self):
        result = self.analyzer.analyze(_balanced_msgs(20))
        self.assertGreaterEqual(result.details["dimensions"]["balance"], 95)

    def test_balance_one_sided_is_zero(self):
        base = datetime(2026, 8, 1, 10, 0, 0)
        msgs = [_mk("self", f"我自己说了一大段话内容很长很长第{i}条",
                    base + timedelta(seconds=30 * i)) for i in range(8)]
        msgs.append(_mk("other", "哦"))
        self.assertEqual(self.analyzer._calc_balance(msgs), 0.0)

    def test_responsiveness_fast_replies_high(self):
        result = self.analyzer.analyze(_balanced_msgs(20))
        # 30 秒间隔全是 <1 分钟 → 100
        self.assertGreaterEqual(result.details["dimensions"]["responsiveness"], 99)

    def test_responsiveness_slow_replies_low(self):
        base = datetime(2026, 8, 1, 10, 0, 0)
        msgs = []
        for i in range(8):
            sender = "self" if i % 2 == 0 else "other"
            msgs.append(_mk(sender, f"隔了很久才回复的消息内容第{i}条",
                            base + timedelta(hours=48 * (i + 1))))
        score = self.analyzer._calc_responsiveness(msgs)
        self.assertLess(score, 10)

    def test_responsiveness_no_timestamp_neutral(self):
        msgs = [_mk("self" if i % 2 == 0 else "other", f"没有时间戳的消息第{i}条")
                for i in range(8)]
        self.assertEqual(self.analyzer._calc_responsiveness(msgs), 50.0)

    def test_emotional_sync_same_positive_high(self):
        detail = {"positive": 60.0, "negative": 40.0,
                  "self_positive": 60.0, "self_negative": 40.0}
        msgs = _balanced_msgs()
        score = self.analyzer._calc_emotional_sync(msgs, detail)
        self.assertGreaterEqual(score, 95)

    def test_emotional_sync_opposite_low(self):
        detail = {"positive": 90.0, "negative": 10.0,
                  "self_positive": 10.0, "self_negative": 90.0}
        score = self.analyzer._calc_emotional_sync(_balanced_msgs(), detail)
        self.assertLess(score, 5)

    def test_emotional_sync_no_signal_neutral(self):
        msgs = [_mk("self" if i % 2 == 0 else "other", f"完全中性的文字内容第{i}条")
                for i in range(8)]
        # 无 sentiment_detail、无情感词、无表情 → 50
        self.assertEqual(self.analyzer._calc_emotional_sync(msgs, None), 50.0)

    def test_cold_reply_penalty_lowers_health(self):
        base = datetime(2026, 8, 1, 10, 0, 0)
        msgs = []
        for i in range(6):
            # 对方发长消息，自己回「嗯」→ 冷回复
            msgs.append(_mk("other", "我写了一段很长很长的话想跟你好好聊聊这件事",
                            base + timedelta(minutes=10 * i)))
            msgs.append(_mk("self", "嗯", base + timedelta(minutes=10 * i + 1)))
        ratio = self.analyzer._calc_cold_reply_ratio(msgs)
        self.assertGreater(ratio, 0.5)
        result = self.analyzer.analyze(msgs)
        self.assertGreater(result.details["penalty"], 5)
        self.assertTrue(any("冷回复" in s for s in result.details["suggestions"]))

    def test_health_grade_excellent(self):
        result = self.analyzer.analyze(_balanced_msgs(40))
        self.assertGreaterEqual(result.details["health_score"], 75)
        self.assertEqual(result.details["grade"], "excellent")

    def test_details_structure(self):
        result = self.analyzer.analyze(_balanced_msgs())
        details = result.details
        for key in ("dimensions", "weights", "health_score", "grade",
                    "grade_label", "cold_reply_ratio", "penalty", "suggestions"):
            self.assertIn(key, details)
        self.assertEqual(set(details["dimensions"]),
                         {"balance", "responsiveness", "emotional_sync",
                          "engagement", "depth"})
        self.assertAlmostEqual(sum(details["weights"].values()), 1.0, places=6)
        self.assertTrue(0 <= details["health_score"] <= 100)

    def test_registry_includes_relationship(self):
        from analyzers import create_default_registry
        registry = create_default_registry({})
        self.assertIn("relationship", registry.list())

    def test_registry_disabled_by_config(self):
        from analyzers import create_default_registry
        registry = create_default_registry({"analysis": {"relationship_enabled": False}})
        self.assertNotIn("relationship", registry.list())

    def test_suggestion_when_all_good(self):
        result = self.analyzer.analyze(_balanced_msgs(40))
        self.assertTrue(result.details["suggestions"])


# ============================================================
# 2. 情感分析 v2.9 增强字段
# ============================================================

class TestSentimentV29(unittest.TestCase):

    def setUp(self):
        self.analyzer = SentimentAnalyzer()

    def _ts_msgs(self, contents):
        base = datetime(2026, 8, 1, 10, 0, 0)
        return [_mk("other", c, base + timedelta(minutes=i))
                for i, c in enumerate(contents)]

    def test_new_fields_present(self):
        result = self.analyzer.analyze(self._ts_msgs(["很开心"] * 5))
        for key in ("rolling_trend", "turning_points", "self_positive", "self_negative"):
            self.assertIn(key, result.details)

    def test_legacy_fields_unchanged(self):
        result = self.analyzer.analyze(self._ts_msgs(["很开心"] * 5))
        for key in ("positive", "negative", "neutral", "trend", "timeline",
                    "emotional_words", "irony_count"):
            self.assertIn(key, result.details)

    def test_rolling_trend_length(self):
        msgs = self._ts_msgs(["开心"] * 8)
        result = self.analyzer.analyze(msgs)
        timeline = result.details["timeline"]
        rolling = result.details["rolling_trend"]
        if len(timeline) >= 3:
            win = min(5, len(timeline))
            self.assertEqual(len(rolling), len(timeline) - win + 1)

    def test_rolling_trend_empty_when_few_messages(self):
        result = self.analyzer.analyze(self._ts_msgs(["开心", "难过"]))
        self.assertEqual(result.details["rolling_trend"], [])

    def test_turning_point_detected_down(self):
        # 前 6 条正面 → 后 6 条负面，滚动序列应由正翻负
        contents = ["今天真开心太棒了"] * 6 + ["我很难过太崩溃了"] * 6
        result = self.analyzer.analyze(self._ts_msgs(contents))
        tps = result.details["turning_points"]
        self.assertTrue(any(tp["direction"] == "down" for tp in tps),
                        f"未检出转差转折点: {tps}")

    def test_turning_point_detected_up(self):
        contents = ["我很难过太崩溃了"] * 6 + ["今天真开心太棒了"] * 6
        result = self.analyzer.analyze(self._ts_msgs(contents))
        tps = result.details["turning_points"]
        self.assertTrue(any(tp["direction"] == "up" for tp in tps),
                        f"未检出好转转折点: {tps}")

    def test_self_sentiment_computed(self):
        base = datetime(2026, 8, 1, 10, 0, 0)
        msgs = [_mk("self", "我好开心啊", base + timedelta(minutes=i)) for i in range(4)]
        msgs += [_mk("other", "嗯", base + timedelta(minutes=4 + i)) for i in range(4)]
        result = self.analyzer.analyze(msgs)
        self.assertGreater(result.details["self_positive"], 50)
        self.assertLess(result.details["self_negative"], 50)

    def test_empty_result_has_new_fields(self):
        # 无任何情感信号 → 空结果分支也应包含新字段
        msgs = [_mk("other", f"普通消息第{i}条") for i in range(4)]
        result = self.analyzer.analyze(msgs)
        self.assertIn("rolling_trend", result.details)
        self.assertIn("self_positive", result.details)


# ============================================================
# 3. 语音指令解析
# ============================================================

class TestVoiceParsing(unittest.TestCase):

    def test_normalize_fullwidth_and_punct(self):
        self.assertEqual(vi.normalize_text("分析一下，ＣＨＡＴ．txt！"),
                         "分析一下 chat.txt".replace(".txt", " txt"))

    def test_normalize_empty(self):
        self.assertEqual(vi.normalize_text(""), "")
        self.assertEqual(vi.normalize_text("   "), "")

    def test_extract_file_plain_name(self):
        self.assertEqual(vi.extract_file_path("帮我分析 chat.txt"), "chat.txt")

    def test_extract_file_chinese_name(self):
        self.assertEqual(vi.extract_file_path("分析 聊天记录.txt 看看"), "聊天记录.txt")

    def test_extract_file_quoted_path(self):
        path = vi.extract_file_path('分析 "D:\\temp\\my chat.txt"')
        self.assertEqual(path, "D:\\temp\\my chat.txt")

    def test_extract_file_directory_path(self):
        self.assertEqual(vi.extract_file_path("分析 D:\\data\\a.txt"), "D:\\data\\a.txt")

    def test_extract_file_none_when_absent(self):
        self.assertIsNone(vi.extract_file_path("帮我分析一下我们的关系"))

    def test_parse_quit(self):
        self.assertEqual(vi.parse_command("再见吧").action, "quit")
        # 优先级：含「扫描」类词但含退出词 → quit
        self.assertEqual(vi.parse_command("帮我分析完就退出").action, "quit")

    def test_parse_help(self):
        self.assertEqual(vi.parse_command("你会什么").action, "help")

    def test_parse_demo(self):
        self.assertEqual(vi.parse_command("跑个演示看看").action, "demo")

    def test_parse_doctor(self):
        self.assertEqual(vi.parse_command("帮我自检一下环境").action, "doctor")

    def test_parse_predict(self):
        self.assertEqual(vi.parse_command("预测一下他接下来会说什么").action, "predict")

    def test_parse_report(self):
        self.assertEqual(vi.parse_command("生成报告").action, "report")

    def test_parse_calendar(self):
        self.assertEqual(vi.parse_command("看看日历").action, "calendar")

    def test_parse_graph(self):
        self.assertEqual(vi.parse_command("看看图谱").action, "graph")

    def test_parse_version(self):
        self.assertEqual(vi.parse_command("你是哪个版本").action, "version")

    def test_parse_analyze_with_file(self):
        cmd = vi.parse_command("分析 chat.txt")
        self.assertEqual(cmd.action, "analyze")
        self.assertEqual(cmd.file_path, "chat.txt")

    def test_parse_predict_with_file(self):
        cmd = vi.parse_command("预测一下 chat.txt 里的下一句")
        self.assertEqual(cmd.action, "predict")
        self.assertEqual(cmd.file_path, "chat.txt")

    def test_parse_analyze_without_file(self):
        cmd = vi.parse_command("帮我分析一下聊天记录")
        self.assertEqual(cmd.action, "analyze")
        self.assertIsNone(cmd.file_path)

    def test_parse_unknown(self):
        self.assertEqual(vi.parse_command("今天股市怎么样啊兄弟").action, "unknown")


# ============================================================
# 4. VoiceAssistant 会话（可注入）
# ============================================================

class _FakeExecutor:
    def __init__(self, fail=None):
        self.calls = []
        self.fail = fail

    def analyze(self, file_path):
        self.calls.append(("analyze", file_path))
        if self.fail == "analyze":
            raise RuntimeError("boom")
        return f"分析了 {file_path}"

    def predict(self, file_path):
        self.calls.append(("predict", file_path))
        return "预测完成"

    def demo(self):
        self.calls.append(("demo",))
        return "演示完成"

    def doctor(self):
        self.calls.append(("doctor",))
        return "自检通过"

    def report(self):
        self.calls.append(("report",))
        return "报告已生成"

    def calendar(self):
        self.calls.append(("calendar",))
        return "日历如下"

    def graph(self):
        self.calls.append(("graph",))
        return "图谱统计"

    def version(self):
        self.calls.append(("version",))
        return "版本 2.9.0"


class _FakeSpeaker:
    def __init__(self):
        self.said = []

    def say(self, text):
        self.said.append(text)


class _ScriptedReader:
    """按脚本顺序返回输入的假监听器。"""

    def __init__(self, lines):
        self.lines = list(lines)
        self.last_used = None

    def listen(self, prompt=""):
        return self.lines.pop(0)


class TestVoiceAssistant(unittest.TestCase):

    def _assistant(self, executor, lines):
        return vi.VoiceAssistant(executor, _FakeSpeaker(), _ScriptedReader(lines))

    def test_session_quit(self):
        ex = _FakeExecutor()
        assistant = self._assistant(ex, ["你好", "退出"])
        assistant.run()
        self.assertEqual(ex.calls, [])

    def test_session_dispatch(self):
        ex = _FakeExecutor()
        assistant = self._assistant(ex, ["演示", "生成报告", "退出"])
        assistant.run()
        self.assertEqual(ex.calls, [("demo",), ("report",)])

    def test_session_analyze_with_file(self):
        ex = _FakeExecutor()
        assistant = self._assistant(ex, ["分析 chat.txt", "退出"])
        assistant.run()
        self.assertEqual(ex.calls, [("analyze", "chat.txt")])

    def test_handle_text_unknown(self):
        assistant = self._assistant(_FakeExecutor(), [])
        reply = assistant.handle_text("今天股市怎么样啊兄弟")
        self.assertIn("没听懂", reply)

    def test_handle_text_quit_returns_none(self):
        assistant = self._assistant(_FakeExecutor(), [])
        self.assertIsNone(assistant.handle_text("再见"))

    def test_help_text(self):
        assistant = self._assistant(_FakeExecutor(), [])
        reply = assistant.handle_text("帮助")
        self.assertIn("分析", reply)
        self.assertIn("退出", reply)

    def test_executor_exception_friendly(self):
        ex = _FakeExecutor(fail="analyze")
        assistant = self._assistant(ex, [])
        reply = assistant.handle_text("分析 chat.txt")
        self.assertIn("出错", reply)

    def test_max_turns_stops(self):
        ex = _FakeExecutor()
        assistant = vi.VoiceAssistant(ex, _FakeSpeaker(),
                                      _ScriptedReader(["演示"] * 10), max_turns=3)
        assistant.run()
        self.assertEqual(len(ex.calls), 3)


# ============================================================
# 5. Speaker / Listener 降级链
# ============================================================

class TestSpeakerFallback(unittest.TestCase):

    def test_off_engine_print_only(self, ):
        speaker = vi.Speaker(engine="off")
        speaker.say("测试")
        self.assertEqual(speaker.last_used, "off")

    def test_pyttsx3_preferred(self, monkeypatch=None):
        import pytest
        speaker = vi.Speaker(engine="auto")
        pytest.MonkeyPatch().setattr(speaker, "_try_pyttsx3", lambda text: True)
        speaker.say("测试")
        self.assertEqual(speaker.last_used, "pyttsx3")

    def test_sapi_fallback(self):
        import pytest
        speaker = vi.Speaker(engine="auto")
        mp = pytest.MonkeyPatch()
        mp.setattr(speaker, "_try_pyttsx3", lambda text: False)
        mp.setattr(vi, "sapi_speak", lambda text: None)
        speaker.say("测试")
        self.assertEqual(speaker.last_used, "sapi")
        mp.undo()

    def test_print_final_fallback(self):
        import pytest
        speaker = vi.Speaker(engine="auto")
        mp = pytest.MonkeyPatch()
        mp.setattr(speaker, "_try_pyttsx3", lambda text: False)

        def _raise(text):
            raise RuntimeError("no sapi")
        mp.setattr(vi, "sapi_speak", _raise)
        speaker.say("测试")
        self.assertEqual(speaker.last_used, "print")
        mp.undo()


class TestListenerFallback(unittest.TestCase):

    def test_text_fallback(self):
        import pytest
        listener = vi.Listener(engine="auto")
        mp = pytest.MonkeyPatch()
        mp.setattr(listener, "_try_sr", lambda: None)

        def _raise(timeout=8.0):
            raise RuntimeError("no sapi")
        mp.setattr(vi, "sapi_listen", _raise)
        mp.setattr("builtins.input", lambda prompt="": "演示")
        got = listener.listen()
        self.assertEqual(got, "演示")
        self.assertEqual(listener.last_used, "text")
        mp.undo()

    def test_text_engine_direct(self):
        import pytest
        listener = vi.Listener(engine="text")
        mp = pytest.MonkeyPatch()
        mp.setattr("builtins.input", lambda prompt="": "退出")
        self.assertEqual(listener.listen(), "退出")
        mp.undo()

    def test_eof_returns_quit(self):
        import pytest
        listener = vi.Listener(engine="text")
        mp = pytest.MonkeyPatch()

        def _eof(prompt=""):
            raise EOFError
        mp.setattr("builtins.input", _eof)
        self.assertEqual(listener.listen(), "退出")
        mp.undo()


# ============================================================
# 6. 版本一致性（v2.9 接管）
# ============================================================

class TestVersionConsistency(unittest.TestCase):
    """版本一致性。

    这里不再钉死具体版本号（v4.0.0 那次升级就是被这类硬编码断言拖住的：
    每次升版本都要来改一遍，漏改就红）。具体模块间的版本对账由
    test_v400_upgrade.py::TestVersionConsistency 负责，它从
    core.version 反推，升版本时不需要动。
    """

    def test_core_version_is_semver(self):
        from core.version import __version__
        self.assertRegex(__version__, r"^\d+\.\d+\.\d+$",
                        f"版本号应为 X.Y.Z，实际 {__version__}")

    def test_config_json_consistent(self):
        from core.version import __version__
        cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"], __version__)

    def test_skill_md_frontmatter_consistent(self):
        from core.version import __version__
        fm = (ROOT / "SKILL.md").read_text(encoding="utf-8").split("---")[1]
        m = re.search(r"^version:\s*([\d.]+)", fm, re.MULTILINE)
        self.assertTrue(m and m.group(1) == __version__)

    def test_voice_config_section_exists(self):
        cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
        self.assertIn("voice", cfg)
        self.assertIn("tts", cfg["voice"])
        self.assertIn("stt", cfg["voice"])

    def test_voice_interface_module_exists(self):
        self.assertTrue((ROOT / "scripts" / "voice_interface.py").exists())

    def test_relationship_analyzer_module_exists(self):
        self.assertTrue((ROOT / "analyzers" / "relationship_analyzer.py").exists())


if __name__ == "__main__":
    unittest.main()
