"""rag.embedder 单元测试（依赖检查 + 模型缓存落点）"""

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rag.embedder import Embedder

REPO_ROOT = Path(__file__).resolve().parent.parent


class TestModelCacheLocation(unittest.TestCase):
    """模型有 50-100MB 且全是二进制，落进技能包会让上传直接被文件类型校验拦掉。"""

    def _with_data_dir(self, tmpdir):
        previous = os.environ.get("WECHAT_ANALYZER_DATA_DIR")
        os.environ["WECHAT_ANALYZER_DATA_DIR"] = tmpdir
        self.addCleanup(lambda: (os.environ.pop("WECHAT_ANALYZER_DATA_DIR", None)
                                 if previous is None
                                 else os.environ.__setitem__(
                                     "WECHAT_ANALYZER_DATA_DIR", previous)))

    def test_default_cache_dir_is_runtime_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            self._with_data_dir(tmpdir)
            self.assertEqual(Path(Embedder().cache_dir), Path(tmpdir) / "models")

    def test_relative_cache_dir_is_pulled_out_of_package(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            self._with_data_dir(tmpdir)
            e = Embedder(cache_dir="data/models")
            self.assertEqual(Path(e.cache_dir), Path(tmpdir) / "models")
            self.assertNotIn(REPO_ROOT, Path(e.cache_dir).resolve().parents)

    def test_absolute_cache_dir_is_respected(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            absolute = str(Path(tmpdir) / "my_models")
            self.assertEqual(Embedder(cache_dir=absolute).cache_dir, absolute)


def _check_sentence_transformers():
    """检查 sentence-transformers 是否可用"""
    try:
        import sentence_transformers  # noqa
        return True
    except ImportError:
        return False


_HAS_ST = _check_sentence_transformers()


@unittest.skipUnless(_HAS_ST, "sentence-transformers not installed")
class TestEmbedder(unittest.TestCase):
    """Embedder 测试（如果 sentence-transformers 可用）"""

    def test_create(self):
        """创建 Embedder（不实际加载）"""
        e = Embedder()
        self.assertIsNotNone(e)
        self.assertEqual(e.device, "cpu")

    def test_recommended_models(self):
        """检查推荐模型列表"""
        self.assertIn("bge-small-zh", Embedder.RECOMMENDED_MODELS)
        self.assertIn("bge-base-zh", Embedder.RECOMMENDED_MODELS)

    @unittest.skipUnless(_HAS_ST, "sentence-transformers not installed")
    def test_embed_single(self):
        """测试单条 embedding（如依赖可用）"""
        try:
            e = Embedder()
            if not e.is_available():
                self.skipTest("Model not available")
            emb = e.embed("测试文本")
            self.assertEqual(len(emb), 1)
            self.assertGreater(len(emb[0]), 0)
        except Exception as e:
            self.skipTest(f"Embedding failed: {e}")


if __name__ == "__main__":
    unittest.main()
