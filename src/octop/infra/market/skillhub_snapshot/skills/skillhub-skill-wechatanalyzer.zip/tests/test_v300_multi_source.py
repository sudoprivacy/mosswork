# -*- coding: utf-8 -*-
"""
v3.0.0 多源数据导入器测试 (test_v300_multi_source.py)

覆盖：
- detect_platform 平台自动识别
- SmartPasteParser 各格式解析（wechat/qq/imessage/simple）
- URLImporter URL 抓取
- StructuredChatImporter JSONL/JSON 解析
- MultiSourceImporter 统一入口
- 隐私脱敏功能

完全 stdlib 测试，无外部依赖。
"""
import json
import os
import sys
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))


class TestPlatformDetection(unittest.TestCase):
    """测试平台自动识别。"""

    def test_detect_wechat(self):
        from data_source_importer import detect_platform
        text = """2024-01-15 14:32:15 张三
你好啊
2024-01-15 14:33:00 李四
在吗？"""
        self.assertEqual(detect_platform(text), "wechat")

    def test_detect_imessage(self):
        from data_source_importer import detect_platform
        text = """[2024-01-15 14:32:15] 张三: 你好
[2024-01-15 14:33:00] 李四: 在吗？"""
        self.assertEqual(detect_platform(text), "imessage")

    def test_detect_simple(self):
        from data_source_importer import detect_platform
        text = "张三: 你好\n李四: 在吗\n王五: 周末一起吃饭"
        self.assertEqual(detect_platform(text), "simple")

    def test_detect_unknown_short(self):
        from data_source_importer import detect_platform
        self.assertEqual(detect_platform(""), "unknown")
        self.assertEqual(detect_platform("hi"), "unknown")


class TestSmartPasteParser(unittest.TestCase):
    """测试智能粘贴解析器。"""

    def test_parse_simple_chinese_colon(self):
        from data_source_importer import SmartPasteParser
        text = "我: 你好\n对方: 我也好\n我: 吃饭了吗？"
        msgs = SmartPasteParser.parse(text, platform="simple")
        self.assertEqual(len(msgs), 3)
        self.assertEqual(msgs[0].sender, "我")
        self.assertEqual(msgs[0].role, "self")
        self.assertEqual(msgs[1].sender, "对方")
        self.assertEqual(msgs[1].role, "other")
        self.assertEqual(msgs[2].content, "吃饭了吗？")

    def test_parse_simple_english_colon(self):
        from data_source_importer import SmartPasteParser
        text = "Alice: hello\nBob: hi"
        msgs = SmartPasteParser.parse(text, platform="simple")
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0].sender, "Alice")

    def test_parse_simple_continuation(self):
        from data_source_importer import SmartPasteParser
        text = "我: 这是第一段\n第二段延续内容\n对方: 我也是\n继续说"
        msgs = SmartPasteParser.parse(text, platform="simple")
        self.assertEqual(len(msgs), 2)
        self.assertIn("第一段", msgs[0].content)
        self.assertIn("延续", msgs[0].content)
        self.assertIn("继续说", msgs[1].content)

    def test_parse_imessage(self):
        from data_source_importer import SmartPasteParser
        text = """[2024-01-15 14:32:15] 张三: 你好
[2024-01-15 14:33:00] 李四: 在吗？"""
        msgs = SmartPasteParser.parse(text, platform="imessage")
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0].timestamp, "2024-01-15 14:32:15")
        self.assertEqual(msgs[0].sender, "张三")

    def test_parse_wechat(self):
        from data_source_importer import SmartPasteParser
        text = """2024-01-15 14:32:15 张三
你好啊
2024-01-15 14:33:00 李四
在吗？"""
        msgs = SmartPasteParser.parse(text, platform="wechat")
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0].sender, "张三")
        self.assertEqual(msgs[0].timestamp, "2024-01-15 14:32:15")
        self.assertEqual(msgs[0].content, "你好啊")

    def test_parse_qq(self):
        from data_source_importer import SmartPasteParser
        text = """2024-01-15 14:32:15
张三
你好啊
2024-01-15 14:33:00
李四
在吗？"""
        msgs = SmartPasteParser.parse(text, platform="qq")
        self.assertEqual(len(msgs), 2)
        self.assertEqual(msgs[0].sender, "张三")
        self.assertEqual(msgs[0].content, "你好啊")

    def test_parse_empty(self):
        from data_source_importer import SmartPasteParser
        self.assertEqual(SmartPasteParser.parse(""), [])
        self.assertEqual(SmartPasteParser.parse("   \n  \n"), [])

    def test_unknown_task_fallback(self):
        """未知平台时尝试多种格式，取消息数最多的。"""
        from data_source_importer import SmartPasteParser
        text = "张三: 你好\n李四: 我好\n王五: 真的吗"
        msgs = SmartPasteParser.parse(text, platform="unknown_format")
        self.assertGreaterEqual(len(msgs), 1)


class TestStructuredImport(unittest.TestCase):
    """测试结构化导入。"""

    def test_parse_jsonl(self):
        from data_source_importer import StructuredChatImporter
        text = """{"sender":"我","content":"你好","timestamp":"2024-01-15"}
{"sender":"对方","content":"我好","timestamp":"2024-01-15"}
{"sender":"我","content":"吃饭了吗"}"""
        msgs = StructuredChatImporter.parse_jsonl(text)
        self.assertEqual(len(msgs), 3)
        self.assertEqual(msgs[0].sender, "我")
        self.assertEqual(msgs[1].role, "unknown")  # role 默认 unknown

    def test_parse_jsonl_with_role(self):
        from data_source_importer import StructuredChatImporter
        text = """{"sender":"Alice","content":"hi","role":"other"}
{"sender":"Me","content":"hello","role":"self"}"""
        msgs = StructuredChatImporter.parse_jsonl(text)
        self.assertEqual(msgs[0].role, "other")
        self.assertEqual(msgs[1].role, "self")

    def test_parse_jsonl_skips_invalid(self):
        from data_source_importer import StructuredChatImporter
        text = """{"sender":"我","content":"你好"}
not json line
{"sender":"对方","content":"hi"}"""
        msgs = StructuredChatImporter.parse_jsonl(text)
        self.assertEqual(len(msgs), 2)

    def test_parse_json_array(self):
        from data_source_importer import StructuredChatImporter
        text = '[{"sender":"我","content":"hello"},{"sender":"TA","content":"hi"}]'
        msgs = StructuredChatImporter.parse_json_array(text)
        self.assertEqual(len(msgs), 2)

    def test_parse_json_object_with_messages_key(self):
        from data_source_importer import StructuredChatImporter
        text = '{"messages":[{"sender":"A","content":"hi"},{"sender":"B","content":"ho"}]}'
        msgs = StructuredChatImporter.parse_json_array(text)
        self.assertEqual(len(msgs), 2)

    def test_parse_invalid_json(self):
        from data_source_importer import StructuredChatImporter
        self.assertEqual(StructuredChatImporter.parse_json_array("not json"), [])

    def test_dict_with_field_aliases(self):
        """支持 sender/from/user/name 和 content/text/message/body 别名。"""
        from data_source_importer import StructuredChatImporter
        text = '{"messages":[{"from":"Alice","text":"hi","time":"2024-01-15"}]}'
        msgs = StructuredChatImporter.parse_json_array(text)
        self.assertEqual(msgs[0].sender, "Alice")
        self.assertEqual(msgs[0].content, "hi")
        self.assertEqual(msgs[0].timestamp, "2024-01-15")


class TestURLImporter(unittest.TestCase):
    """测试 URL 导入器。"""

    def test_unsupported_scheme(self):
        from data_source_importer import URLImporter
        importer = URLImporter()
        self.assertIsNone(importer.fetch("ftp://example.com"))
        self.assertIsNone(importer.fetch("file:///etc/passwd"))

    @patch("urllib.request.urlopen")
    def test_fetch_success(self, mock_urlopen):
        from data_source_importer import URLImporter
        mock_resp = MagicMock()
        mock_resp.read = MagicMock(return_value=b"hello world")
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        importer = URLImporter()
        result = importer.fetch("https://example.com/chat.txt")
        self.assertEqual(result, "hello world")

    @patch("urllib.request.urlopen")
    def test_fetch_gbk_content(self, mock_urlopen):
        from data_source_importer import URLImporter
        mock_resp = MagicMock()
        mock_resp.read = MagicMock(return_value="你好世界".encode("gb18030"))
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        importer = URLImporter()
        result = importer.fetch("https://example.com/cn.txt")
        self.assertIn("你好", result)

    @patch("urllib.request.urlopen")
    def test_fetch_error_returns_none(self, mock_urlopen):
        from data_source_importer import URLImporter
        mock_urlopen.side_effect = Exception("network error")
        importer = URLImporter()
        self.assertIsNone(importer.fetch("https://example.com"))


class TestMultiSourceImporter(unittest.TestCase):
    """测试多源导入器统一入口。"""

    def test_import_text(self):
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        text = "我: 你好\n对方: 我也好"
        result = importer.import_text(text)
        self.assertTrue(result.success)
        self.assertEqual(len(result.messages), 2)
        self.assertEqual(result.source, "text:simple")

    def test_import_jsonl(self):
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        text = '{"sender":"我","content":"hi"}\n{"sender":"TA","content":"hello"}'
        result = importer.import_jsonl(text)
        self.assertTrue(result.success)
        self.assertEqual(len(result.messages), 2)

    def test_import_json_array(self):
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        text = '[{"sender":"A","content":"hi"}]'
        result = importer.import_json(text)
        self.assertTrue(result.success)

    def test_import_file_txt(self, tmp_path=None):
        """用临时文件测试 import_file。"""
        import tempfile
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write("我: 你好\n对方: 我也好")
            tmp = f.name
        try:
            result = importer.import_file(tmp)
            self.assertTrue(result.success)
            self.assertEqual(len(result.messages), 2)
        finally:
            os.unlink(tmp)

    def test_import_file_not_found(self):
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        result = importer.import_file("/nonexistent/path.txt")
        self.assertFalse(result.success)
        self.assertIn("不存在", result.error)

    def test_to_core_messages_without_core(self):
        """core 模块不可用时返回空列表。"""
        from data_source_importer import MultiSourceImporter
        importer = MultiSourceImporter()
        result = importer.import_text("我: 你好\n对方: 我也好")
        # 在 conftest 屏蔽 core 模块时
        with patch.dict(sys.modules, {"core.message": None}):
            core_msgs = importer.to_core_messages(result.messages)
        self.assertEqual(core_msgs, [])


class TestSelfCheck(unittest.TestCase):
    """测试自检函数。"""

    def test_self_check(self):
        from data_source_importer import self_check
        result = self_check()
        # 版本号只校验格式，不做字面量断言：以前写死 "v3.0"，每次升级都要来改这里，
        # 而升级本身恰恰是最容易漏改这行的时候。
        self.assertRegex(result["version"], r"^v\d+\.\d+(\.\d+)?$")
        self.assertIn("wechat", result["supported_platforms"])
        self.assertIn("imessage", result["supported_platforms"])
        self.assertTrue(result["all_passed"])

    def test_self_check_covers_new_formats(self):
        """v5.0.0 加的 HTML/CSV 通道必须在自检里有位置，否则坏掉没人知道。"""
        from data_source_importer import self_check
        result = self_check()
        for platform in ("wechat_html", "csv"):
            self.assertIn(platform, result["supported_platforms"])
        cases = {c["case"] for c in result["test_results"]}
        self.assertTrue({"wechat_html:structural", "csv"} <= cases)


if __name__ == "__main__":
    unittest.main()
