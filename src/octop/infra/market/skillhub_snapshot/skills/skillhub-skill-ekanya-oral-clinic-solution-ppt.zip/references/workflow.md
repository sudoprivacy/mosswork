# Workflow

## 1. Intake and Confirmation

Parse the user's materials into:

- Institution basics: name, city, type, store count, departments, team configuration.
- Business objective: new-customer growth, conversion, revisit, closing, management, add-on purchase, competitor replacement, owner presentation.
- Known operating data: metric names, periods, values, source files, and owner.
- Current problems: customer-stated pain points and sales observations.
- Current system status: existing software, competitor product, purchased e看牙 products.
- Deck use: first visit, solution meeting, add-on purchase, competitor replacement, management meeting.
- Case permission: whether approved customer cases can be used externally.

Ask only the highest-impact missing questions first:

1. PPT audience and sales stage.
2. Metric period and data source.
3. Conversion funnel data: 到诊, 咨询, 初诊, 成交, 复诊.
4. Current product and competitor system status.
5. Priority product focus among e看牙智能版, 智能工牌, e看牙机器人.
6. Whether approved cases may be used.

If the user answers, use the answers. If the user wants immediate output or leaves gaps, generate the PPT from verified known facts only.

## 2. Evidence Retrieval

Build an internal evidence log before drafting.

| Evidence type | Extracted content | Source/input | Confidence | Client-visible use |
|---|---|---|---|---|
| Customer fact | Background, data, goal, pain point | User input or uploaded file | High/medium/low | Yes if verified |
| Metric definition | Formula, scope, interpretation | P0 metric standard | High | Yes, without citation |
| Product capability | Feature, scenario, boundary | P1 product material | High | Yes |
| Implementation path | Action, process, role, cadence | P2 solution material | High/medium | Yes |
| Case | Institution, problem, action, result | P3 approved case | High | Yes, concise bottom note |
| Unusable item | Unsourced or conflicting content | Unknown/conflict | Low | No |

For any operating metric, retrieve P0 first. If another source conflicts with P0, use P0 and record the conflict outside the visible deck.

## 3. Diagnosis

Use this logic:

`known fact -> metric or phenomenon judgment -> business impact -> controllable problem -> source`

For conversion-rate topics, inspect:

- Lead or appointment input.
- Arrival and consultation.
- Initial diagnosis conversion.
- Treatment plan acceptance or deal closing.
- Revisit and re-treatment.
- Staff follow-up behavior and manager review.

Avoid generic statements such as `管理能力不足` unless the source directly supports them. Prefer concrete and controllable language such as `复诊跟进动作缺少闭环记录`.

## 4. Solution Mapping

For each verified problem, map:

| Customer problem | Evidence | Product/solution | Mechanism | Operating action | Process metric | Management checkpoint | Source |
|---|---|---|---|---|---|---|---|

Rules:

- Use the smallest sufficient product set.
- Link 智能工牌 to conversion-rate and staff behavior management only when supported.
- Link e看牙机器人 to automated patient communication and follow-up only when supported.
- Link e看牙智能版 to data, process, and operating management scenarios only when supported.
- Process metrics must come from P0 or approved solution materials. Do not invent metrics.

## 5. PPT Outline

Create an internal outline:

| Page | Client-facing title | Page purpose | Visible content | Case use | Source note |
|---:|---|---|---|---|---|

Required deck structure:

1. Cover.
2. Communication logic.
3. Institution current state and business goals.
4. Current-state problem diagnosis.
5. Conversion-rate diagnosis when relevant.
6. Overall digitalization solution blueprint.
7. Scenario-by-scenario solution paths.
8. Implementation plan.
9. Process metrics and management review mechanism.
10. Value summary and next-step cooperation logic.
11. Closing page.

Use 12-18 slides for a normal deck. Expand to 18-30 slides for complex organizations or multiple verified problems.

## 6. PPT Generation

Visible slide bodies must contain only client-ready solution content:

- No source filenames.
- No evidence citations.
- No missing-input lists.
- No internal sales suggestions.
- No `待补充` or `资料不足` wording.
- No standalone large case pages unless the user explicitly asks for a case-heavy deck.

Speaker notes or evidence log should contain:

- Source files or user inputs behind each page.
- Missing inputs and conservative assumptions.
- Conflicts and the higher-priority source used.

For actual PPTX output:

1. Convert the final outline into a JSON deck spec compatible with `scripts/build_oral_solution_ppt.py`.
2. Keep slide `title`, `subtitle`, `bullets`, `blocks`, and `case_note` concise.
3. Put source material in `notes`.
4. Run the script and deliver both `.pptx` and `.evidence.md`.
5. If the deck looks crowded, split the crowded slide in the JSON spec and rerun.

## 7. QA Review

Before delivery, check:

- Every visible claim has source support.
- P0 was used for metric口径 when available.
- Conversion-rate analysis appears when 智能工牌 or funnel data is relevant.
- Products stay within allowed scope.
- Cases are approved, concise, and embedded in scenario pages.
- Visible pages contain no internal suggestions, requirements, missing-input lists, or evidence citations.
- No slide is overloaded.
- Product names, metric names, and terminology are consistent.

