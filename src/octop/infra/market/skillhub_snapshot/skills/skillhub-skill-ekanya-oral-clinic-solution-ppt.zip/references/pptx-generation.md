# PPTX Generation

Use `scripts/build_oral_solution_ppt.py` when the user asks for an actual `.pptx` file.

Runtime dependency: Python with `python-pptx`. If unavailable, install from `scripts/requirements.txt` in an isolated environment.

## Command

```bash
python3 scripts/build_oral_solution_ppt.py assets/sample_deck_spec.json -o output/oral-clinic-solution.pptx
```

The script also creates `output/oral-clinic-solution.evidence.md`.

## Deck Spec

```json
{
  "theme": {
    "accent": "1677FF",
    "accent_2": "00A870"
  },
  "slides": [
    {
      "type": "cover",
      "title": "某口腔机构数智化经营提升方案",
      "subtitle": "围绕转化率、复诊经营与过程管理形成可落地闭环",
      "date": "2026-05-26",
      "notes": ["来源：销售输入。"]
    },
    {
      "type": "content",
      "title": "转化率漏斗决定新增价值能否沉淀为业绩",
      "subtitle": "只放客户可见结论，不放证据文件名。",
      "bullets": [
        "到诊、咨询、初诊、成交与复诊环节需要统一口径后再判断。",
        "智能工牌相关场景重点呈现沟通过程、跟进闭环和管理复盘。",
        "过程指标用于管理动作，不写成确定性增长承诺。"
      ],
      "case_note": "案例：某机构围绕初诊转化采用智能工牌，复盘沟通过程并提升转化质量。",
      "notes": ["来源：P0 指标标准、P1 智能工牌能力文件、P3 审核案例。"]
    }
  ]
}
```

Supported slide types:

- `cover`
- `section`
- `content`
- `scenario`
- `summary`
- `closing`

Use `blocks` for two or three concise cards. Use `bullets` for direct points. Use `case_note` only for one short approved case sentence.

## Layout Protection

Before running the script:

- Keep one main conclusion per slide.
- Use no more than five bullets per slide.
- Use no more than three blocks per slide.
- Keep `case_note` short enough for a bottom row.
- Put long evidence, conflicts, and missing-input notes in `notes`.

The script applies:

- 16:9 canvas.
- Fixed safe margins.
- Conservative Chinese fonts.
- Automatic continuation pages for long bullet lists or too many blocks.
- Companion evidence log generation.

## Required Sequence

1. Build the internal evidence log.
2. Create the slide outline.
3. Convert the outline to `deck_spec.json`.
4. Run `build_oral_solution_ppt.py`.
5. Inspect the generated PPTX for crowding or overflow.
6. Split crowded pages and rerun.
7. Deliver the `.pptx` and `.evidence.md`.

## Visual QA Checklist

- No visible slide contains source filenames, evidence citations, or `待补充`.
- No text extends beyond the safe slide area.
- Titles fit on one or two lines.
- No slide has more than three content groups.
- Scenario pages have at most one bottom-row case note.
- Dense content has been split.
- Evidence log contains source notes for each page.

