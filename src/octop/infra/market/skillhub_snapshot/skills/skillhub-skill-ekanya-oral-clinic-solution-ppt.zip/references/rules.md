# Rules

## Source Priority

Use this order when retrieving and resolving conflicts.

| Level | Source type | Use | Conflict rule |
|---|---|---|---|
| P0 | 门诊经营指标口径统一标准（v1.0） | Metric definitions, formulas, interpretation, conversion口径 | Highest priority for all metrics |
| P1 | Official product capabilities, applicable scenarios, and product boundaries | Decide whether e看牙智能版, 智能工牌, or e看牙机器人 can be recommended | Never exceed P1 capability boundaries |
| P2 | Approved solution paths, implementation methods, operating playbooks, management actions | Build landing path, process metrics, management checkpoints | Must not contradict P0 or P1 |
| P3 | Approved customer cases and external-use permissions | Add concise scenario case notes | Use only complete approved cases |
| P4 | PPT template, brand rules, terminology rules | Visual and wording consistency | Cannot override business facts |
| P5 | Training notes, meeting notes, auxiliary materials | Context only | Discard when conflicting with higher priority sources |

## Evidence Boundary

- Use only customer input and approved source content.
- Do not invent product features, service capabilities, business data, customer cases, customer quotes, growth percentages, formulas, thresholds, benchmark ranges, or effect promises.
- Do not attribute business growth to a product unless the source explicitly supports that attribution.
- If evidence is incomplete, narrow or remove the visible claim. Put the limitation in the evidence log or handoff note, not on the client-facing slide.
- Avoid absolute promise language such as `一定能够`, `必然提升`, `保证达成`, `立刻见效`, `行业领先`, unless that exact claim is approved and sourced.

## Product Scope

Allowed products:

- e看牙智能版
- 智能工牌
- e看牙机器人

Recommendation rules:

- Recommend a product only when a verified customer problem matches a verified product capability or scenario.
- Explain the product's mechanism, required operating actions, process metrics, and management checkpoints.
- Do not make a product replace internal management. Product capability, staff execution, and manager review must remain separate.
- If sales wants to push a product but evidence does not prove fit, do not state a causal fit on visible slides. Either omit it or keep it as an internal exploration note.

## Conversion-Rate Emphasis

智能工牌 is strategically important for conversion-rate management. Whenever supported by customer data or approved source evidence, explicitly assess:

- 初诊转化率
- 复诊转化率
- 到诊转化率
- 咨询转化率
- 成交转化率
- Follow-up process metrics such as response timeliness, follow-up completion, communication quality, handoff completeness, and manager review cadence

Use P0 wording for metric definitions. If P0 does not define the metric, use the customer's wording conservatively and record the口径 gap outside the visible deck.

## Client-Facing Slide Rules

- Use conclusion-style titles.
- One page should focus on one core conclusion.
- Do not show evidence citations, source filenames, missing-input lists, internal sales suggestions, or internal requirements on visible slides.
- Do not place `待补充`, `资料不足`, `建议补充`, `来源`, `证据`, or similar caveat wording in visible slide bodies.
- Split pages when a slide contains more than three core conclusions, two or more different problems, multiple products with separate roles, or too much product/action/metric/management content.

## Customer Case Rules

- Do not create a large standalone customer-case chapter by default.
- Place at most one approved case as a bottom-row sentence in the relevant scenario slide.
- Visible format: `案例：{机构名称}，围绕{问题}采用{产品/动作}，实现{经证实的增长/改善}。`
- If no approved matching case exists, omit the case from visible slides and record that in the evidence log.

