# Templates

## Sales Intake Template

```markdown
## 机构基本信息
- 机构名称：
- 所在城市：
- 机构类型：
- 门店数量：
- 主要科室/业务：
- 团队配置：

## 本次PPT用途
- 使用场景：
- 面向对象：
- 销售阶段：
- 希望重点推动的产品：

## 经营目标与问题
- 客户经营目标：
- 客户明确反馈的问题：
- 销售观察到的问题：
- 当前系统/竞品情况：

## 已知经营数据
- 数据周期：
- 数据来源：
- 新客/线索：
- 到诊：
- 咨询：
- 初诊转化：
- 成交转化：
- 复诊转化：
- 复购/再治疗：
- 其他指标：

## 案例与边界
- 是否允许使用已审核客户案例：
- 不希望出现的表述：
- 品牌/版式要求：
```

## Confirmation Questions Template

```markdown
在生成正式PPT前，建议先确认以下信息。若暂时无法补充，我会先基于现有资料输出一版客户可用的初步方案。

1. 本次PPT主要面向谁汇报，处于什么销售阶段？
2. 经营数据的统计周期和来源是什么？
3. 是否有到诊、咨询、初诊、成交、复诊等转化漏斗数据？
4. 当前机构正在使用哪些系统或竞品？
5. 本次重点推动 e看牙智能版、智能工牌、e看牙机器人中的哪几项？
6. 是否允许使用已审核客户案例？
```

## Evidence Log Template

| Slide | Claim/data/case | Source | Priority | Visible use | Note |
|---:|---|---|---|---|---|

## Diagnosis Schema

| Known fact | Metric/phenomenon judgment | Business impact | Controllable problem | Source |
|---|---|---|---|---|

## Solution Mapping Schema

| Problem | Product/path | Mechanism | Landing action | Process metric | Management checkpoint | Embedded case | Source |
|---|---|---|---|---|---|---|---|

## PPT Structure Template

| Slide | Visible title style | Required visible content | Notes/evidence content |
|---:|---|---|---|
| 1 | `{机构名称}数智化经营提升方案` | Institution name, theme, date | Input source |
| 2 | `本次方案围绕经营目标、关键问题与落地路径展开` | Communication logic | Outline evidence |
| 3 | `机构当前目标聚焦在{目标}` | Background and goals | Customer input |
| 4 | `当前经营提升的关键在于{核心问题}` | Diagnosis summary | Diagnosis evidence |
| 5 | `转化率漏斗决定新增价值能否沉淀为业绩` | Conversion diagnosis when relevant | P0 and customer data |
| 6 | `以数据、过程和触达形成整体经营闭环` | Overall blueprint | Product source notes |
| 7+ | `{问题}需要通过{路径}形成闭环` | Product capability, action, metric, management point, concise bottom case if available | Capability and case sources |
| N-3 | `实施推进以阶段目标和复盘节奏保障落地` | Phase plan, roles, milestones | Implementation source notes |
| N-2 | `核心过程指标用于持续验证经营改善` | Process metrics and review rhythm | Metric source notes |
| N-1 | `本方案帮助机构把{目标}转化为可管理动作` | Value summary | Evidence summary |
| N | `携手推进口腔机构数智化经营升级` | Closing | None |

## Embedded Case Template

Visible bottom-row text:

```markdown
案例：{机构名称}，围绕{问题}采用{产品/动作}，实现{经证实结果}。
```

Notes:

```markdown
Case source: {source file/input}; approved for external use: {yes/no}; evidence summary: {summary}.
```

## Deck JSON Template

Use this shape with `scripts/build_oral_solution_ppt.py`.

```json
{
  "slides": [
    {
      "type": "cover",
      "title": "某口腔机构数智化经营提升方案",
      "subtitle": "围绕转化率、复诊经营与过程管理形成可落地闭环",
      "date": "2026-05-26",
      "notes": ["来源：销售输入。"]
    },
    {
      "type": "content",
      "title": "转化率漏斗决定新增价值能否沉淀为业绩",
      "subtitle": "客户可见的一句话背景，不放来源文件名。",
      "bullets": [
        "到诊、咨询、初诊、成交与复诊环节需要统一口径后再判断。",
        "智能工牌相关场景重点呈现沟通过程、跟进闭环和管理复盘。",
        "过程指标用于管理动作，不写成确定性增长承诺。"
      ],
      "case_note": "案例：某机构围绕初诊转化采用智能工牌，复盘沟通过程并提升转化质量。",
      "notes": ["来源：P0 指标标准、P1 智能工牌能力文件、P3 审核案例。"]
    }
  ]
}
```

