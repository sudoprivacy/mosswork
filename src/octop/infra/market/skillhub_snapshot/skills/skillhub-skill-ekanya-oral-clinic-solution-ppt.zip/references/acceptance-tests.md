# Acceptance Tests

## Test Case 1: Complete Information

Input includes institution background, business goals, full conversion funnel data, P0 metric standard, P1 product evidence, P2 implementation path, and a matching approved case.

Expected:

- Generate a complete 12-18 slide PPT.
- Include conversion-rate diagnosis and 智能工牌 mechanism when supported.
- Embed one concise case in the relevant scenario page.
- Put evidence sources in speaker notes or evidence log, not visible slides.

## Test Case 2: Incomplete Customer Data

Input lacks several metrics and current system details.

Expected:

- Ask concise confirmation questions first.
- If user proceeds, generate a preliminary client-safe deck.
- Do not invent missing metrics.
- Do not show `待补充` or `资料不足` on visible slides.
- Record missing items in non-client-facing handoff notes.

## Test Case 3: Metric Conflict

One source defines a conversion metric differently from P0.

Expected:

- Use P0 as the metric definition.
- Record the conflict in evidence log.
- Do not expose the conflict on client-facing pages unless the user explicitly asks for a technical appendix.

## Test Case 4: No Matching Case

Approved case library has no case matching the customer's problem.

Expected:

- Omit case note from visible scenario slide.
- Do not create a standalone case page.
- Record `no suitable approved case found` in the evidence log or handoff note.

## Test Case 5: Forced Product Recommendation

Sales input asks to recommend a product, but P1 sources do not prove that the product solves the stated problem.

Expected:

- Do not make the product-problem causal claim.
- Recommend only evidence-supported product paths.
- If useful, mention the product only in internal notes as an exploration topic.

## Test Case 6: Smart Badge Conversion Focus

Input includes 智能工牌 and conversion funnel or follow-up behavior data.

Expected:

- Include conversion-rate diagnosis if supported by P0 and customer data.
- Cover 初诊转化率 and 复诊转化率 when data exists.
- Treat process metrics as management observation points, not guaranteed outcomes.

## Hallucination Checks

Fail the output if it contains:

- A product outside the allowed scope.
- An unsourced product feature.
- An unsourced customer case.
- A fabricated growth percentage or operating metric.
- A guarantee or absolute result promise.
- Visible slide text that says evidence is missing or asks the client to supplement internal data.
- Evidence citations or source filenames in visible slide bodies.

## Acceptance Criteria

The skill passes when:

- The PPT is directly usable for a client conversation.
- When a PPTX file is requested, the skill generates a `.pptx` and a companion evidence log.
- Every visible claim has a source or customer input.
- Conversion-rate topics are handled when relevant.
- Cases are concise and embedded, not oversized.
- Missing information is handled outside the visible deck.
- Evidence traceability is preserved in notes or evidence log.
- Text stays inside safe page areas, and crowded slides are split before delivery.

