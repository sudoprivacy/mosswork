#!/usr/bin/env python3
"""
Build a client-facing oral clinic digitalization solution PPTX from JSON.

Visible slides intentionally exclude evidence citations and missing-input notes.
Each slide's source notes are written to a companion .evidence.md file.
"""

from __future__ import annotations

import argparse
import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_AUTO_SIZE, MSO_ANCHOR, PP_ALIGN
from pptx.util import Cm, Pt


SLIDE_W = Cm(33.867)
SLIDE_H = Cm(19.05)
SAFE_X = Cm(1.05)
SAFE_W = SLIDE_W - Cm(2.1)

THEME = {
    "font": "Microsoft YaHei",
    "bg": "F8FAFC",
    "text": "172033",
    "muted": "5F6B7A",
    "accent": "1B76FF",
    "accent_2": "12A474",
    "soft": "EEF5FF",
    "case_bg": "F5FBF2",
    "line": "D9E2EC",
}

MAX_BULLETS = 5
MAX_BLOCKS = 3
MAX_CASE_CHARS = 62


def rgb(hex_value: str) -> RGBColor:
    value = hex_value.strip().lstrip("#")
    return RGBColor(int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def clean(value: Any) -> str:
    return re.sub(r"\s+", " ", "" if value is None else str(value)).strip()


def truncate(value: Any, limit: int) -> str:
    text = clean(value)
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip("，。；; ") + "…"


def chunks(items: List[Any], size: int) -> Iterable[List[Any]]:
    for idx in range(0, len(items), size):
        yield items[idx : idx + size]


def normalize_slides(raw_slides: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    slides: List[Dict[str, Any]] = []
    for raw in raw_slides:
        slide = deepcopy(raw)
        blocks = slide.get("blocks") or []
        bullets = slide.get("bullets") or []

        if len(blocks) > MAX_BLOCKS:
            for idx, group in enumerate(chunks(blocks, MAX_BLOCKS), start=1):
                next_slide = deepcopy(slide)
                next_slide["blocks"] = group
                next_slide["bullets"] = []
                if idx > 1:
                    next_slide["title"] = f"{clean(slide.get('title'))}（续）"
                    next_slide["case_note"] = ""
                slides.append(next_slide)
            continue

        if len(bullets) > MAX_BULLETS:
            for idx, group in enumerate(chunks(bullets, MAX_BULLETS), start=1):
                next_slide = deepcopy(slide)
                next_slide["bullets"] = group
                if idx > 1:
                    next_slide["title"] = f"{clean(slide.get('title'))}（续）"
                    next_slide["case_note"] = ""
                slides.append(next_slide)
            continue

        slides.append(slide)
    return slides


def add_bg(slide, theme: Dict[str, str]) -> None:
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, SLIDE_W, SLIDE_H)
    shape.fill.solid()
    shape.fill.fore_color.rgb = rgb(theme["bg"])
    shape.line.fill.background()


def add_text(
    slide,
    x,
    y,
    w,
    h,
    text: Any,
    size: float,
    theme: Dict[str, str],
    color: str = "text",
    bold: bool = False,
    align=PP_ALIGN.LEFT,
    valign=MSO_ANCHOR.TOP,
):
    box = slide.shapes.add_textbox(x, y, w, h)
    frame = box.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    frame.vertical_anchor = valign
    frame.margin_left = Cm(0.08)
    frame.margin_right = Cm(0.08)
    frame.margin_top = Cm(0.04)
    frame.margin_bottom = Cm(0.04)
    paragraph = frame.paragraphs[0]
    paragraph.text = clean(text)
    paragraph.alignment = align
    paragraph.font.name = theme["font"]
    paragraph.font.size = Pt(size)
    paragraph.font.bold = bold
    paragraph.font.color.rgb = rgb(theme[color])
    return box


def add_header(slide, title: str, theme: Dict[str, str], page: int) -> None:
    add_text(slide, SAFE_X, Cm(0.55), Cm(27.0), Cm(1.05), title, 22, theme, bold=True)
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, SAFE_X, Cm(1.72), SAFE_W, Cm(0.035))
    line.fill.solid()
    line.fill.fore_color.rgb = rgb(theme["line"])
    line.line.fill.background()
    add_text(slide, SLIDE_W - Cm(2.2), Cm(0.65), Cm(1.2), Cm(0.45), page, 8, theme, "muted", align=PP_ALIGN.RIGHT)


def add_footer(slide, theme: Dict[str, str]) -> None:
    add_text(slide, SAFE_X, SLIDE_H - Cm(0.68), SAFE_W, Cm(0.28), "e看牙口腔数智化解决方案", 7.5, theme, "muted")


def add_bullets(slide, bullets: List[str], x, y, w, h, theme: Dict[str, str]) -> None:
    box = slide.shapes.add_textbox(x, y, w, h)
    frame = box.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    frame.margin_left = Cm(0.16)
    frame.margin_right = Cm(0.12)
    frame.margin_top = Cm(0.08)
    frame.margin_bottom = Cm(0.08)
    size = 14.5 if sum(len(clean(x)) for x in bullets) < 300 else 12.5
    for idx, bullet in enumerate(bullets):
        paragraph = frame.paragraphs[0] if idx == 0 else frame.add_paragraph()
        paragraph.text = clean(bullet)
        paragraph.level = 0
        paragraph.space_after = Pt(8)
        paragraph.font.name = theme["font"]
        paragraph.font.size = Pt(size)
        paragraph.font.color.rgb = rgb(theme["text"])


def add_card(slide, x, y, w, h, heading: str, body: str, theme: Dict[str, str], accent: bool = False) -> None:
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    card.fill.solid()
    card.fill.fore_color.rgb = rgb(theme["soft"] if accent else "FFFFFF")
    card.line.color.rgb = rgb(theme["line"])
    add_text(slide, x + Cm(0.32), y + Cm(0.25), w - Cm(0.64), Cm(0.5), heading, 13, theme, bold=True)
    size = 11.2 if len(clean(body)) < 120 else 9.8
    add_text(slide, x + Cm(0.32), y + Cm(0.92), w - Cm(0.64), h - Cm(1.1), body, size, theme, "muted")


def render_cover(prs, data: Dict[str, Any], theme: Dict[str, str]) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, theme)
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Cm(0.9), SLIDE_H)
    bar.fill.solid()
    bar.fill.fore_color.rgb = rgb(theme["accent"])
    bar.line.fill.background()
    add_text(slide, Cm(2.0), Cm(4.7), Cm(25.5), Cm(1.35), data.get("title", "口腔机构数智化经营提升方案"), 30, theme, bold=True)
    add_text(slide, Cm(2.04), Cm(6.35), Cm(24.5), Cm(0.8), data.get("subtitle", ""), 15, theme, "muted")
    add_text(slide, Cm(2.04), Cm(14.95), Cm(14), Cm(0.5), data.get("date", ""), 10.5, theme, "muted")


def render_section(prs, data: Dict[str, Any], theme: Dict[str, str], page: int) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, theme)
    marker = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, SAFE_X, Cm(5.2), Cm(0.18), Cm(3.2))
    marker.fill.solid()
    marker.fill.fore_color.rgb = rgb(theme["accent"])
    marker.line.fill.background()
    add_text(slide, Cm(1.75), Cm(5.0), Cm(26), Cm(1.1), data.get("title", ""), 25, theme, bold=True)
    add_text(slide, Cm(1.78), Cm(6.5), Cm(23), Cm(1.0), data.get("subtitle", ""), 13, theme, "muted")
    add_footer(slide, theme)


def render_content(prs, data: Dict[str, Any], theme: Dict[str, str], page: int) -> None:
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, theme)
    add_header(slide, data.get("title", ""), theme, page)
    add_footer(slide, theme)
    y = Cm(2.12)
    subtitle = clean(data.get("subtitle"))
    if subtitle:
        add_text(slide, SAFE_X, y, SAFE_W, Cm(0.58), subtitle, 11.2, theme, "muted")
        y = Cm(2.88)

    case_note = truncate(data.get("case_note"), MAX_CASE_CHARS)
    bottom = Cm(1.35) if case_note else Cm(0.15)
    content_h = SLIDE_H - y - Cm(1.0) - bottom

    blocks = data.get("blocks") or []
    bullets = data.get("bullets") or []
    if blocks:
        gap = Cm(0.38)
        card_w = (SAFE_W - gap * (len(blocks) - 1)) / len(blocks)
        for idx, block in enumerate(blocks):
            body = block.get("body") or "；".join(block.get("bullets", []))
            add_card(slide, SAFE_X + (card_w + gap) * idx, y, card_w, content_h, block.get("heading", ""), body, theme, idx == 0)
    elif bullets:
        add_bullets(slide, bullets, SAFE_X + Cm(0.18), y, SAFE_W - Cm(0.36), content_h, theme)
    else:
        add_text(slide, SAFE_X + Cm(0.18), y, SAFE_W - Cm(0.36), content_h, data.get("body", ""), 14, theme)

    if case_note:
        case = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, SAFE_X, SLIDE_H - Cm(1.82), SAFE_W, Cm(0.85))
        case.fill.solid()
        case.fill.fore_color.rgb = rgb(theme["case_bg"])
        case.line.color.rgb = rgb(theme["line"])
        add_text(slide, SAFE_X + Cm(0.32), SLIDE_H - Cm(1.62), SAFE_W - Cm(0.64), Cm(0.43), case_note, 9.5, theme, "muted")


def write_evidence(path: Path, slides: List[Dict[str, Any]]) -> None:
    rows = ["# Evidence Log", "", "| Slide | Title | Notes |", "|---:|---|---|"]
    for idx, slide in enumerate(slides, start=1):
        notes = slide.get("notes") or []
        if isinstance(notes, str):
            notes = [notes]
        note_text = "<br>".join(clean(note).replace("|", "/") for note in notes if clean(note))
        rows.append(f"| {idx} | {clean(slide.get('title'))} | {note_text} |")
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def build(spec: Dict[str, Any], output: Path) -> Tuple[Path, Path]:
    theme = {**THEME, **(spec.get("theme") or {})}
    slides = normalize_slides(spec.get("slides") or [])
    if not slides:
        raise ValueError("spec.slides must contain at least one slide")

    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    for idx, slide_data in enumerate(slides, start=1):
        slide_type = slide_data.get("type", "content")
        if slide_type == "cover" or idx == 1:
            render_cover(prs, slide_data, theme)
        elif slide_type == "section":
            render_section(prs, slide_data, theme, idx)
        else:
            render_content(prs, slide_data, theme, idx)

    output.parent.mkdir(parents=True, exist_ok=True)
    prs.save(output)
    evidence = output.with_suffix(".evidence.md")
    write_evidence(evidence, slides)
    return output, evidence


def main() -> None:
    parser = argparse.ArgumentParser(description="Build an oral clinic solution PPTX from JSON.")
    parser.add_argument("spec", help="Path to JSON deck spec.")
    parser.add_argument("-o", "--output", default="oral-clinic-digital-solution.pptx", help="Output PPTX path.")
    args = parser.parse_args()

    spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
    pptx, evidence = build(spec, Path(args.output))
    print(f"PPTX: {pptx}")
    print(f"Evidence log: {evidence}")


if __name__ == "__main__":
    main()
