#!/usr/bin/env python3
"""native_art — the drawn surfaces of the NATIVE visual languages (ink, poster, cutpaper, drafting,
starlit, broadsheet, journal, tally, chalkboard):
native, editable shapes, deterministic for a seed, and ON THE PAGE by construction.

Two rules every function keeps, both found on the 2026-10-05 look-dev deck, which LibreOffice rendered and
PowerPoint did not open cleanly:
  · nothing is drawn past the slide edge. PowerPoint's editing view shows geometry beyond the slide, so a
    bleed is computed up to the edge (clip_to_page, band) — never left for the renderer to clip;
  · every angle written is in range. A negative outerShdw `dir` made PowerPoint repair the file (angle()).

    import native_art as na
    na.ink_ridges(s, color="1D1C1A", layers=na.INK_LAYERS["land"], keep_clear=[(9.6, 0.7, 1.2, 4.9)])
"""
from __future__ import annotations

import math
import random
import tempfile
from pathlib import Path

from lxml import etree
from pptx.oxml.ns import qn

import deckkit as dk
import ornaments as orn


def _cached_ok(path):
    """A cached picture that exists AND decodes — a build killed mid-write (or two builds at once) left a truncated file
    under a stable name that every later build reused (final review, 2026-10-09)."""
    try:
        from PIL import Image
        if not Path(path).exists():
            return False
        with Image.open(path) as im:
            im.load()
        return True
    except Exception:
        return False


def _atomic_save(im, path, **kw):
    """Save through a temporary name and an atomic rename, so no reader ever sees half a picture."""
    import os
    path = Path(path)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=path.suffix)
    os.close(fd)
    try:
        im.save(tmp, **kw)
        os.replace(tmp, str(path))
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)

A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
U = 100000

# ridge layers, far to near: (crest base / H, peak height / H, top alpha, depth / H)
INK_LAYERS = {
    "land": ((0.57, 0.25, 0.34, 0.32), (0.67, 0.20, 0.46, 0.30), (0.77, 0.15, 0.62, 0.25), (0.89, 0.09, 0.80, 0.21)),
    "port": ((0.66, 0.12, 0.34, 0.20), (0.73, 0.10, 0.46, 0.18), (0.81, 0.08, 0.62, 0.15), (0.90, 0.05, 0.80, 0.11)),
    "faint": ((0.86, 0.10, 0.18, 0.16), (0.93, 0.06, 0.30, 0.10)),
}


def page_size(slide):
    pres = slide.part.package.presentation_part.presentation
    return pres.slide_width / 914400.0, pres.slide_height / 914400.0


def hexstr(c):
    if isinstance(c, str):
        return c.lstrip("#").upper()
    return "{:02X}{:02X}{:02X}".format(*c)


def _pct(v):
    return int(round(min(max(float(v), 0.0), 1.0) * 100000))


def angle(deg):
    """An OOXML angle (60000ths of a degree), always in 0..21599999 — PowerPoint repairs a negative one."""
    return int(round((float(deg) % 360.0) * 60000)) % 21600000


def clip_to_page(pts, W, H):
    """Sutherland-Hodgman: the polygon `pts` (inches) cut to the page rectangle [0, W] x [0, H]."""
    def clip(poly, inside, cross):
        out = []
        for i, cur in enumerate(poly):
            prev = poly[i - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(cross(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(cross(prev, cur))
        return out

    def at_x(xv):
        return lambda a, b: (xv, a[1] + (b[1] - a[1]) * (xv - a[0]) / (b[0] - a[0]))

    def at_y(yv):
        return lambda a, b: (a[0] + (b[0] - a[0]) * (yv - a[1]) / (b[1] - a[1]), yv)

    pts = [tuple(p) for p in pts]
    for inside, cross in ((lambda p: p[0] >= 0.0, at_x(0.0)), (lambda p: p[0] <= W, at_x(W)),
                          (lambda p: p[1] >= 0.0, at_y(0.0)), (lambda p: p[1] <= H, at_y(H))):
        if not pts:
            break
        pts = clip(pts, inside, cross)
    return pts


def _custom(slide, x, y, w, h, path_xml, *, fill=None, alpha=None, line=None, line_w=1.0):
    return orn._shape(slide, x, y, w, h, path_xml, fill=fill, alpha=alpha, line=line, line_w=line_w)


def poly(slide, pts, *, fill=None, alpha=None, line=None, line_w=0.75):
    """A straight-edged polygon, clipped to the page; None when nothing of it is on the page."""
    W, H = page_size(slide)
    pts = clip_to_page(pts, W, H)
    if len(pts) < 3:
        return None
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    x0, y0 = min(xs), min(ys)
    w, h = max(max(xs) - x0, 0.01), max(max(ys) - y0, 0.01)
    u = [((px - x0) / w * U, (py - y0) / h * U) for px, py in pts]
    path = '<a:path w="{u}" h="{u}"{f}>{d}</a:path>'.format(u=U, d=orn._ring(u),
                                                            f="" if fill is not None else ' fill="none"')
    return _custom(slide, x0, y0, w, h, path, fill=None if fill is None else hexstr(fill), alpha=alpha,
                   line=line, line_w=line_w)


def multipoly(slide, polys, fill, *, alpha=None):
    """Many closed straight-edged polygons as ONE editable shape (a stripe colour, a stamp's perforations, a barcode's
    bars) — a hundred shapes would be a hundred objects to select. None when there is nothing to draw. Not clipped:
    keep the polygons on the page (or declare the shape's bleed)."""
    polys = [p for p in polys if len(p) >= 3]
    if not polys:
        return None
    xs = [x for p in polys for x, _y in p]
    ys = [y for p in polys for _x, y in p]
    x0, y0 = min(xs), min(ys)
    w, h = max(max(xs) - x0, 0.01), max(max(ys) - y0, 0.01)
    d = "".join(orn._ring([((x - x0) / w * U, (y - y0) / h * U) for x, y in p]) for p in polys)
    return _custom(slide, x0, y0, w, h, '<a:path w="{u}" h="{u}">{d}</a:path>'.format(u=U, d=d), fill=hexstr(fill),
                   alpha=alpha)


def band(slide, top_pts, bottom_y, *, fill, alpha=None):
    """A band whose top edge is a smooth curve through `top_pts` and whose foot is flat — x clamped to the page,
    the foot to the page bottom, so a bleed reaches the edge and stops there."""
    W, H = page_size(slide)
    pts = [(min(max(px, 0.0), W), py) for px, py in top_pts]
    bottom_y = min(bottom_y, H)
    x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
    y0 = max(0.0, min(min(p[1] for p in pts), bottom_y - 0.02))
    w, h = max(x1 - x0, 0.01), max(bottom_y - y0, 0.01)
    u = [((px - x0) / w * U, (max(py, y0) - y0) / h * U) for px, py in pts]
    d = "<a:moveTo>{}</a:moveTo>{}<a:lnTo>{}</a:lnTo><a:lnTo>{}</a:lnTo><a:close/>".format(
        orn._pt(*u[0]), orn._smooth(u), orn._pt(U, U), orn._pt(0, U))
    return _custom(slide, x0, y0, w, h, '<a:path w="{u}" h="{u}">{d}</a:path>'.format(u=U, d=d),
                   fill=hexstr(fill), alpha=alpha)


def fade(shape, color, top, mid=None, stop=55):
    """Swap a solid fill for a vertical transparency gradient: `top` alpha at the crest, mist at the foot."""
    sp = shape._element.spPr
    sf = sp.find(qn("a:solidFill"))
    if sf is None:
        raise ValueError("fade(): the shape has no solid fill to fade")
    mid = top * 0.35 if mid is None else mid
    g = etree.fromstring(
        '<a:gradFill xmlns:a="{a}" rotWithShape="1"><a:gsLst>'
        '<a:gs pos="0"><a:srgbClr val="{c}"><a:alpha val="{t}"/></a:srgbClr></a:gs>'
        '<a:gs pos="{p}"><a:srgbClr val="{c}"><a:alpha val="{m}"/></a:srgbClr></a:gs>'
        '<a:gs pos="100000"><a:srgbClr val="{c}"><a:alpha val="0"/></a:srgbClr></a:gs></a:gsLst>'
        '<a:lin ang="5400000" scaled="0"/></a:gradFill>'.format(
            a=A_NS, c=hexstr(color), t=_pct(top), m=_pct(mid), p=int(min(max(stop, 1), 99)) * 1000))
    sf.addprevious(g)
    sp.remove(sf)
    return shape


def soft_shadow(shape, *, blur=0.10, dist=0.04, alpha=0.25, color="2A1E10", direction=90.0):
    """A soft paper shadow (a real outerShdw), its angle normalised into range, placed in schema order."""
    sp = shape._element.spPr
    for e in sp.findall(qn("a:effectLst")):
        sp.remove(e)
    eff = etree.fromstring(
        '<a:effectLst xmlns:a="{a}"><a:outerShdw blurRad="{b}" dist="{d}" dir="{r}" algn="t" rotWithShape="0">'
        '<a:srgbClr val="{c}"><a:alpha val="{al}"/></a:srgbClr></a:outerShdw></a:effectLst>'.format(
            a=A_NS, b=int(abs(blur) * 914400), d=int(abs(dist) * 914400), r=angle(direction), c=hexstr(color),
            al=_pct(alpha)))
    ln = sp.find(qn("a:ln"))
    if ln is not None:
        ln.addnext(eff)
    else:
        sp.append(eff)
    return shape


def disc(slide, cx, cy, d, fill, *, shadow=False):
    b = dk.box(slide, cx - d / 2.0, cy - d / 2.0, d, d, fill=hexstr(fill))
    b._element.spPr.find(qn("a:prstGeom")).set("prst", "ellipse")
    return soft_shadow(b, blur=0.12, dist=0.05, alpha=0.24) if shadow else b


def seg(slide, x0, y0, x1, y1, color, *, w=0.75, dash=False, alpha=None):
    W, H = page_size(slide)
    cl = lambda v, hi: min(max(v, 0.0), hi)            # noqa: E731
    c = dk._connector(slide, cl(x0, W), cl(y0, H), cl(x1, W), cl(y1, H), dk._as_rgb(hexstr(color)), w=w, dash=dash)
    if alpha is not None:
        clr = c._element.spPr.find(qn("a:ln")).find(qn("a:solidFill"))[0]
        clr.append(clr.makeelement(qn("a:alpha"), {"val": str(_pct(alpha))}))
    return c


def no_autofit(tb):
    """A measured box keeps its size: PowerPoint re-runs spAutoFit on vertical text differently from LibreOffice."""
    bp = tb.text_frame._txBody.find(qn("a:bodyPr"))
    for e in list(bp):
        if e.tag in (qn("a:spAutoFit"), qn("a:normAutofit"), qn("a:noAutofit")):
            bp.remove(e)
    bp.insert(0, bp.makeelement(qn("a:noAutofit"), {}))
    return tb


def vertical(tb):
    """CJK set upright, top to bottom, columns right to left."""
    tb.text_frame._txBody.find(qn("a:bodyPr")).set("vert", "eaVert")
    return no_autofit(tb)


def _bg(slide, fill_xml):
    """Set the slide background. A picture the OLD background held is dropped with it, unless the new one uses the
    same relationship: a starlit page is painted at new_slide and again once its words are known, and the first sky
    would otherwise ride along as an orphan picture."""
    import re as _re
    csld = slide._element.find(qn("p:cSld"))
    keep = set(_re.findall(r'r:embed="([^"]+)"', fill_xml))
    stale = set()
    for old in csld.findall(qn("p:bg")):
        stale |= {b.get(qn("r:embed")) for b in old.iter(qn("a:blip"))} - keep - {None}
        csld.remove(old)
    csld.insert(0, etree.fromstring('<p:bg xmlns:p="{p}" xmlns:a="{a}" xmlns:r="{r}"><p:bgPr>{f}<a:effectLst/>'
                                    '</p:bgPr></p:bg>'.format(p=P_NS, a=A_NS, r=R_NS, f=fill_xml)))
    for rid in stale:
        if not slide._element.xpath('.//*[@r:embed="{}"]'.format(rid)):
            slide.part.drop_rel(rid)


def solid_background(slide, color):
    _bg(slide, '<a:solidFill><a:srgbClr val="{}"/></a:solidFill>'.format(hexstr(color)))


def grid_background(slide, *, base, ink, step=0.25, major=4, dpi=150):
    """A drafting grid as the slide background — one picture per canvas and colour, cached, never a shape."""
    from PIL import Image, ImageDraw
    W, H = page_size(slide)
    path = Path(tempfile.gettempdir()) / "slide-maker-native-art" / "grid_{}_{}_{:.3f}x{:.3f}.png".format(
        hexstr(base), hexstr(ink), W, H)
    if not _cached_ok(path):
        path.parent.mkdir(parents=True, exist_ok=True)
        pw, ph = int(W * dpi), int(H * dpi)
        b = tuple(int(hexstr(base)[i:i + 2], 16) for i in (0, 2, 4))
        k = tuple(int(hexstr(ink)[i:i + 2], 16) for i in (0, 2, 4))
        mix = lambda a: tuple(int(b[i] * (1 - a) + k[i] * a) for i in range(3))  # noqa: E731
        im = Image.new("RGB", (pw, ph), b)
        dr = ImageDraw.Draw(im)
        px = dpi * step
        for i in range(int(pw / px) + 1):
            dr.line([(int(i * px), 0), (int(i * px), ph)], fill=mix(0.13 if i % major == 0 else 0.055), width=1)
        for j in range(int(ph / px) + 1):
            dr.line([(0, int(j * px)), (pw, int(j * px))], fill=mix(0.13 if j % major == 0 else 0.055), width=1)
        _atomic_save(im, path)
    _part, rid = slide.part.get_or_add_image_part(str(path))
    _bg(slide, '<a:blipFill dpi="0" rotWithShape="1"><a:blip r:embed="{}"/><a:srcRect/><a:stretch><a:fillRect/>'
               '</a:stretch></a:blipFill>'.format(rid))
    return str(path)


SHOULDER = 1.6      # how steeply (in/in) a ridge falls away beside kept-clear text: a hillside, not a cut


def ridge_points(W, H, layer, i, seed, peak_span, keep_clear):
    """The crest of ridge layer `i` as 41 (x, y) points. Over a keep_clear rect the crest sits below the rect's
    foot; beside it the crest is held down by a SHOULDER that relaxes with distance — measured 2026-10-05, a flat
    clamp left a vertical cut in the ridge at the rect's edge."""
    bf, af, _top_alpha, _df = layer
    rnd = random.Random(seed * 31 + i)
    base, amp = bf * H, af * H
    lo, hi = peak_span[0] * W, peak_span[1] * W
    centers = [(rnd.uniform(lo, hi), rnd.uniform(0.45, 1.0) * amp, rnd.uniform(0.06, 0.16) * W) for _ in range(4)]
    pts = []
    for j in range(41):
        x = W * j / 40.0
        hgt = 0.12 * amp * (1 + math.sin(x / W * 12.0 + seed + i)) / 2.0
        for cx, a, sp in centers:
            hgt = max(hgt, a * math.exp(-((x - cx) / sp) ** 2 * 2.2) * (1 + 0.08 * math.sin(x * 9 + seed)))
        y = base - hgt
        for kx, ky, kw, kh in keep_clear:
            d = max(kx - 0.25 - x, 0.0, x - (kx + kw + 0.25))      # how far outside the kept span
            y = max(y, ky + kh + 0.15 - SHOULDER * d)
        pts.append((x, y))
    return pts


def ink_ridges(slide, *, color, layers, seed=0, peak_span=(0.0, 0.62), keep_clear=()):
    """Ink-wash ridges, far to near, each fading from its crest into mist. Peaks rise only inside `peak_span`
    (fractions of W); over every `keep_clear` rect the crest stays below the rect's foot — text never sits on
    the wash. Declared decorative: the language's ground, like paper grain."""
    W, H = page_size(slide)
    out = []
    for i, layer in enumerate(layers):
        bf, _af, top_alpha, df = layer
        pts = ridge_points(W, H, layer, i, seed, peak_span, keep_clear)
        sh = band(slide, pts, bf * H + df * H, fill=color)
        fade(sh, color, top_alpha)
        dk.decorative(sh, "an ink-wash ridge: the language's ground, like paper grain")
        out.append(sh)
    return out


def seal(slide, x, y, size, chars, *, fill, ink, face):
    """A carved seal carrying ONE or TWO characters of the caller's own text (never invented)."""
    chars = (chars or "").strip()
    if not 1 <= len(chars) <= 2:
        raise ValueError("seal(): one or two characters from the caller's own text, got {!r}".format(chars))
    rnd = random.Random(sum(map(ord, chars)))
    j = lambda: rnd.uniform(-0.035, 0.035) * size     # noqa: E731 — a carved stone's edge is never straight
    pts = [(x + j(), y + j()), (x + size / 2, y + j() * 0.6), (x + size + j(), y + j()),
           (x + size + j(), y + size / 2), (x + size + j(), y + size + j()), (x + size / 2, y + size + j() * 0.6),
           (x + j(), y + size + j()), (x + j() * 0.6, y + size / 2)]
    body = poly(slide, pts, fill=fill, alpha=0.94)
    pt = size * 72 * (0.40 if len(chars) == 2 else 0.60)
    tb = dk.text(slide, x, y, size, size, [[(chars, pt, dk._as_rgb(hexstr(ink)), True, False, face, face)]],
                 align=dk.PP_ALIGN.CENTER, anchor=dk.MSO_ANCHOR.MIDDLE, space_after=0)
    (vertical if len(chars) == 2 else no_autofit)(tb)
    dk.overlap_intent(tb, "the seal's characters are carved into the seal")
    return [body, tb]


def enso(slide, cx, cy, R, width, *, color, seed=3, gap=38.0, start=110.0, alpha=0.9):
    """An open ensō brush circle: thick where the brush lands, dry and thin where it lifts."""
    rnd = random.Random(seed)
    n, sweep = 120, 360.0 - gap
    outer, inner = [], []
    for i in range(n + 1):
        t = i / float(n)
        a = math.radians(start + sweep * t)
        wob = 0.012 * R * math.sin(t * 23 + seed) + 0.01 * R * (rnd.random() - 0.5)
        w = width * (0.25 + 0.75 * math.sin(math.pi * min(1.0, t * 1.15)) ** 0.6) * (1 - 0.55 * t ** 3)
        outer.append((cx + (R + wob) * math.cos(a), cy + (R + wob) * math.sin(a)))
        inner.append((cx + (R + wob - w) * math.cos(a), cy + (R + wob - w) * math.sin(a)))
    sh = poly(slide, outer + inner[::-1], fill=color, alpha=alpha)
    dk.decorative(sh, "an ensō brush circle around the figure; ornament")
    return sh


def hill_points(W, base, amp, seed, waves):
    ph = random.Random(seed).uniform(0.0, 6.28)
    return [(W * i / 16.0, base - amp * (0.55 + 0.45 * math.sin(ph + waves * 6.28318 * i / 16.0))) for i in range(17)]


def paper_hill(slide, pts, bottom_y, *, fill, shadow=True):
    sh = band(slide, pts, bottom_y, fill=fill)
    if shadow:
        soft_shadow(sh, blur=0.14, dist=0.05, alpha=0.22, direction=270.0)
    dk.decorative(sh, "a cut-paper hill: the language's ground")
    # a diorama IS layered paper: hills over hills, over the sun, tucking the cards — the delivery lint's OVERLAP read
    # every cutpaper cover, quote and closing as a collision the author could not clear (audits, 2026-10-09)
    dk.overlap_intent(sh, "cut-paper hills layer over each other, the sun and the cards: the diorama is the overlap")
    return sh


def paper_card(slide, x, y, w, h, *, fill="FFFFFF", r=0.22, rotation=0.0):
    c = dk.box(slide, x, y, w, h, fill=hexstr(fill), round=True, r=r)
    if rotation:
        c.rotation = float(rotation)
    dk.overlap_intent(c, "a paper card tucked among the paper hills, or stacked on its twin: layered by design")
    return soft_shadow(c, blur=0.16, dist=0.06, alpha=0.24)


def cloud(slide, cx, cy, w, *, fill="FFFFFF"):
    pts = []
    for i in range(14):
        a = 6.28318 * i / 14
        r = 1 + 0.18 * math.sin(a * 3) + 0.08 * math.sin(a * 5)
        pts.append((cx + math.cos(a) * w / 2 * r, cy + math.sin(a) * w / 5.5 * r))
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    x0, y0, ww, hh = min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)
    u = [((px - x0) / ww * U, (py - y0) / hh * U) for px, py in pts]
    d = "<a:moveTo>{}</a:moveTo>{}<a:close/>".format(orn._pt(*u[0]), orn._smooth(u, closed=True))
    sh = _custom(slide, x0, y0, ww, hh, '<a:path w="{u}" h="{u}">{d}</a:path>'.format(u=U, d=d), fill=hexstr(fill))
    soft_shadow(sh, blur=0.08, dist=0.04, alpha=0.18)
    dk.decorative(sh, "a paper cloud: the cut-paper ground")
    dk.overlap_intent(sh, "a paper cloud drifts over the hills and the sun: part of the layered diorama")
    return sh


def paper_sun(slide, cx, cy, diameters, colors):
    out = []
    for d, col in zip(diameters, colors):
        sh = disc(slide, cx, cy, d, col, shadow=True)
        dk.decorative(sh, "a layered paper sun")
        dk.overlap_intent(sh, "a layered paper sun: its discs stack and the hills pass in front of it")
        out.append(sh)
    return out


def drawing_sheet(slide, *, ink, mute, accent, number, project, face):
    """A drawing sheet's furniture: double border, zone marks, and a title block holding only the sheet number
    and the caller's own project words. Returns (content rect, title-block rect)."""
    W, H = page_size(slide)
    s = min(W, H) / 7.5
    m1, m2 = 0.32 * s, 0.42 * s
    rgb = lambda c: dk._as_rgb(hexstr(c))              # noqa: E731
    dk.box(slide, m1, m1, W - 2 * m1, H - 2 * m1, line=rgb(ink), line_w=1.0)
    dk.box(slide, m2, m2, W - 2 * m2, H - 2 * m2, line=rgb(ink), line_w=0.5)
    zpt = max(8.0, 8.0 * s)
    nx, ny = max(2, int(round(W / 2.2))), max(2, int(round(H / 1.9)))
    for i in range(nx):
        dk.text(slide, m2 + (W - 2 * m2) * (i + 0.5) / nx - 0.15, 0.03 * s, 0.3, m1 - 0.04 * s,
                [[(str(i + 1), zpt, rgb(mute), False, False, face)]], align=dk.PP_ALIGN.CENTER,
                anchor=dk.MSO_ANCHOR.MIDDLE, space_after=0)
    for j in range(min(ny, 8)):
        dk.text(slide, 0.02 * s, m2 + (H - 2 * m2) * (j + 0.5) / ny - 0.12, m1 - 0.04 * s, 0.24,
                [[("ABCDEFGH"[j], zpt, rgb(mute), False, False, face)]], align=dk.PP_ALIGN.CENTER,
                anchor=dk.MSO_ANCHOR.MIDDLE, space_after=0)
    bw, bh = min(3.9 * s, W * 0.36), 0.9 * s
    bx, by = W - m2 - 0.12 * s - bw, H - m2 - 0.12 * s - bh
    dk.box(slide, bx, by, bw, bh, line=rgb(ink), line_w=0.75)
    split = bx + bw * 0.66
    seg(slide, split, by, split, by + bh, ink, w=0.5)
    lab = max(8.0, 8.0 * s)
    if project:
        title_block_project(slide, (bx, by, bw, bh), project, ink=ink, mute=mute, face=face)
    dk.text(slide, split + 0.08 * s, by + 0.06 * s, bx + bw - split - 0.14 * s, bh - 0.12 * s,
            [[("SHEET", lab, rgb(mute), False, False, face)],
             [("{:02d}".format(number), max(14.0, 16.0 * s), rgb(accent), True, False, face)]], space_after=0)
    return (0.9 * s, 0.78 * s, W - 1.8 * s, H - 1.56 * s), (bx, by, bw, bh)


def title_block_project(slide, block, project, *, ink, mute, face):
    """The caller's project words in a drawing sheet's title block (left field), measured: 10pt shrinking to 7pt.
    Returns False and draws NOTHING when they do not fit even then — the caller decides (refuse the caller's own
    project=, or leave a remembered title out: the sheet number alone)."""
    W, H = page_size(slide)
    s = min(W, H) / 7.5
    bx, by, bw, bh = block
    split = bx + bw * 0.66
    fw, fh = split - bx - 0.14 * s, bh - 0.12 * s
    rgb = lambda c: dk._as_rgb(hexstr(c))              # noqa: E731
    lab = max(8.0, 8.0 * s)
    lab_h = dk.measure_text([("PROJECT", False)], fw, lab, font=face, line_h_factor=dk._LINT_LINE_H)   # lint's model
    sz = max(9.0, 10.0 * s)
    while True:
        need = lab_h + dk.measure_text([(str(project), True)], fw, sz, font=face, line_h_factor=dk._LINT_LINE_H)
        if need <= fh or sz <= 7.0:
            break
        sz = max(7.0, sz - 0.5)
    if need > fh + 1e-6:
        return False
    dk.text(slide, bx + 0.08 * s, by + 0.06 * s, fw, fh,
            [[("PROJECT", lab, rgb(mute), False, False, face)],
             [(str(project), sz, rgb(ink), True, False, face, face)]], space_after=0)
    return True


def _iso(cx, cy, a, b):
    return (cx + (a - b) * 0.866, cy + (a + b) * 0.5)


def iso_stack(slide, cx, cy, size, gap, n, *, ink, accent=None, accent_layer=None, thick=0.18):
    """`n` isometric layers (one per point of the page — never a generic diagram), top layer first; the layer at
    `accent_layer` is filled with `accent`. Returns each layer's top rhombus corners (top, right, bottom, left)."""
    tops = []
    for k_ in range(n):
        y = cy + k_ * gap
        p = [_iso(cx, y, 0, 0), _iso(cx, y, size, 0), _iso(cx, y, size, size), _iso(cx, y, 0, size)]
        if accent is not None and accent_layer == k_:
            poly(slide, p, fill=accent, alpha=0.9)
        poly(slide, p, line=dk._as_rgb(hexstr(ink)), line_w=1.0)
        poly(slide, [p[3], p[2], (p[2][0], p[2][1] + thick), (p[3][0], p[3][1] + thick)], line=dk._as_rgb(hexstr(ink)), line_w=1.0)
        poly(slide, [p[2], p[1], (p[1][0], p[1][1] + thick), (p[2][0], p[2][1] + thick)], line=dk._as_rgb(hexstr(ink)), line_w=1.0)
        tops.append(p)
    if n > 1:
        for corner in (0, 1, 3):
            x, y = tops[0][corner]
            seg(slide, x, y, x, tops[-1][corner][1], ink, w=0.5, dash=True, alpha=0.7)
    return tops


def dimension_line(slide, x, y0, y1, *, ink):
    out = [seg(slide, x, y0, x, y1, ink, w=0.6)]
    for y in (y0, y1):
        out.append(seg(slide, x - 0.09, y + 0.09, x + 0.09, y - 0.09, ink, w=0.9))
        out.append(seg(slide, x - 0.16, y, x + 0.16, y, ink, w=0.4))
    return out


def balloon(slide, x, y, d, label, *, ink, accent, face, fill):
    b = dk.box(slide, x, y, d, d, fill=hexstr(fill), line=dk._as_rgb(hexstr(ink)), line_w=0.9)
    b._element.spPr.find(qn("a:prstGeom")).set("prst", "ellipse")
    tb = dk.text(slide, x, y, d, d, [[(str(label), max(10.0, d * 72 * 0.40), dk._as_rgb(hexstr(accent)), True, False, face)]],
                 align=dk.PP_ALIGN.CENTER, anchor=dk.MSO_ANCHOR.MIDDLE, space_after=0)
    no_autofit(tb)
    dk.overlap_intent(tb, "a numbered balloon: the number sits inside its circle")
    return [b, tb]


def strokes(slide, segs, color, *, w=0.6, dash=False, alpha=None):
    """Straight pen strokes [((x0, y0), (x1, y1)), ...] (inches) drawn as ONE outline-only shape — a drawing's whole line
    work is a single object, not a hundred connectors. None when there is nothing to draw."""
    segs = [((float(a[0]), float(a[1])), (float(b[0]), float(b[1]))) for a, b in segs]
    if not segs:
        return None
    xs = [p[0] for sg in segs for p in sg]
    ys = [p[1] for sg in segs for p in sg]
    x0, y0 = min(xs), min(ys)
    bw, bh = max(max(xs) - x0, 0.01), max(max(ys) - y0, 0.01)
    u = lambda p: ((p[0] - x0) / bw * U, (p[1] - y0) / bh * U)               # noqa: E731
    d = "".join("<a:moveTo>{}</a:moveTo><a:lnTo>{}</a:lnTo>".format(orn._pt(*u(a)), orn._pt(*u(b))) for a, b in segs)
    sh = _custom(slide, x0, y0, bw, bh, '<a:path w="{u}" h="{u}" fill="none">{d}</a:path>'.format(u=U, d=d),
                 line=dk._as_rgb(hexstr(color)), line_w=w)
    ln = sh._element.spPr.find(qn("a:ln"))
    if alpha is not None:
        clr = ln.find(qn("a:solidFill"))[0]
        clr.append(clr.makeelement(qn("a:alpha"), {"val": str(_pct(alpha))}))
    if dash:
        ln.append(ln.makeelement(qn("a:prstDash"), {"val": "dash"}))
    return sh


def _circle_pts(cx, cy, r, n=40):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n + 1)]


def _dim_h(x0, x1, y, t=0.07):
    """A horizontal dimension line from x0 to x1 at y: its extension stubs are drawn by the caller; slash ends."""
    return [((x0, y), (x1, y))] + [((x - t, y + t), (x + t, y - t)) for x in (x0, x1)]


def _dim_v(x, y0, y1, t=0.07):
    return [((x, y0), (x, y1))] + [((x - t, y + t), (x + t, y - t)) for y in (y0, y1)]


def _fit(segs_solid, segs_dash, x, y, w, h):
    """Scale and centre a drawing (two stroke lists in local units) into the rect (x, y, w, h)."""
    pts = [p for sg in segs_solid + segs_dash for p in sg]
    x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
    y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
    f = min(w / max(x1 - x0, 1e-6), h / max(y1 - y0, 1e-6))
    ox, oy = x + (w - (x1 - x0) * f) / 2.0 - x0 * f, y + (h - (y1 - y0) * f) / 2.0 - y0 * f
    mv = lambda sg: [((ox + a[0] * f, oy + a[1] * f), (ox + b[0] * f, oy + b[1] * f)) for a, b in sg]   # noqa: E731
    return mv(segs_solid), mv(segs_dash), f


def ghost_iso(slide, x, y, w, h, *, ink, alpha=0.30):
    """A faint isometric box in (x, y, w, h): visible edges solid, hidden ones dashed, a height and a length dimension
    with slash ends, a dashed centre line. Drawing furniture — no words, no numbers. Returns the shapes."""
    L, c = 1.0, 0.75                                   # edge, height (local units: scaled to fit below)
    T = lambda a, b, z=0.0: (_iso(0, 0, a, b)[0], _iso(0, 0, a, b)[1] + z)   # noqa: E731
    top = [T(0, 0), T(L, 0), T(L, L), T(0, L)]
    bot = [(p[0], p[1] + c) for p in top]
    solid = [(top[i], top[(i + 1) % 4]) for i in range(4)]
    solid += [(top[3], bot[3]), (top[2], bot[2]), (top[1], bot[1]), (bot[3], bot[2]), (bot[2], bot[1])]
    dash = [(top[0], bot[0]), (bot[0], bot[3]), (bot[0], bot[1])]
    xr = top[1][0] + 0.30                              # height dimension, right of the box
    solid += _dim_v(xr, top[1][1], bot[1][1])
    solid += [((top[1][0] + 0.06, top[1][1]), (xr + 0.1, top[1][1])), ((bot[1][0] + 0.06, bot[1][1]), (xr + 0.1, bot[1][1]))]
    e, n = (0.866, 0.5), (-0.5, 0.866)                 # length dimension under the front-left edge, offset outward
    p, q = (bot[3][0] + n[0] * 0.30, bot[3][1] + n[1] * 0.30), (bot[2][0] + n[0] * 0.30, bot[2][1] + n[1] * 0.30)
    solid += [(p, q)]
    for m in (p, q):
        solid.append(((m[0] - 0.05, m[1] - 0.07), (m[0] + 0.05, m[1] + 0.07)))
    solid += [(bot[3], (p[0] + n[0] * 0.08, p[1] + n[1] * 0.08)), (bot[2], (q[0] + n[0] * 0.08, q[1] + n[1] * 0.08))]
    dash += [((top[0][0], top[0][1] - 0.18), (top[0][0], bot[2][1] + 0.18))]
    s_, d_, _f = _fit(solid, dash, x, y, w, h)
    out = [strokes(slide, s_, ink, w=0.8, alpha=alpha), strokes(slide, d_, ink, w=0.7, dash=True, alpha=alpha)]
    return [o for o in out if o is not None]


def ghost_detail(slide, x, y, w, h, *, ink, alpha=0.30):
    """A faint section detail in (x, y, w, h): a plate with a bored hole and a smaller ring, dashed centre lines, a leader
    with a shelf, a length and a height dimension. No words, no numbers. Returns the shapes."""
    a, b = 1.5, 1.0
    cx, cy = a / 2.0, b / 2.0
    solid = [((0, 0), (a, 0)), ((a, 0), (a, b)), ((a, b), (0, b)), ((0, b), (0, 0))]
    for r in (0.30, 0.17):
        pts = _circle_pts(cx, cy, r)
        solid += [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    dash = [((cx - 0.55, cy), (cx + 0.55, cy)), ((cx, cy - 0.45), (cx, cy + 0.45))]
    ang = math.radians(-40)
    lx, ly = cx + 0.30 * math.cos(ang), cy + 0.30 * math.sin(ang)
    solid += [((lx, ly), (a + 0.25, -0.22)), ((a + 0.25, -0.22), (a + 0.62, -0.22))]
    solid += _dim_h(0, a, b + 0.30) + [((0, b + 0.04), (0, b + 0.38)), ((a, b + 0.04), (a, b + 0.38))]
    solid += _dim_v(-0.30, 0, b) + [((-0.04, 0), (-0.38, 0)), ((-0.04, b), (-0.38, b))]
    s_, d_, _f = _fit(solid, dash, x, y, w, h)
    out = [strokes(slide, s_, ink, w=0.8, alpha=alpha), strokes(slide, d_, ink, w=0.7, dash=True, alpha=alpha)]
    return [o for o in out if o is not None]


def clipped_block(slide, x, y, w, h, deg, *, fill):
    """A rotated colour block drawn as its polygon cut to the page (a rotated rectangle would hang off it)."""
    cx, cy, a = x + w / 2.0, y + h / 2.0, math.radians(deg)
    corners = [(cx + dx * math.cos(a) - dy * math.sin(a), cy + dx * math.sin(a) + dy * math.cos(a))
               for dx, dy in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2))]
    sh = poly(slide, corners, fill=fill)
    if sh is not None:
        dk.decorative(sh, "a poster colour block: the language's ground")
    return sh


# ═══════════════════ P4: starlit · broadsheet · journal · tally · chalkboard ═══════════════════
def _rgb3(h):
    h = hexstr(h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def starfield_png(slide, *, base, ink, glow, seed=0, keep_clear=(), density=1.0, dpi=200):
    """A night sky as the slide BACKGROUND: small stars and six four-point sparkles, deterministic for `seed`, none
    within 0.12in of a `keep_clear` rect (inches). One picture, cached by its inputs, never ~150 shapes: the deck's
    size and every lint pass grow with the shape count. Returns the PNG's path."""
    import hashlib
    from PIL import Image, ImageDraw
    W, H = page_size(slide)
    sig = repr((hexstr(base), hexstr(ink), hexstr(glow), seed, round(W, 3), round(H, 3),
                [tuple(round(float(v), 2) for v in r) for r in keep_clear], round(float(density), 3), dpi))
    path = Path(tempfile.gettempdir()) / "slide-maker-native-art" / "sky_{}.png".format(
        hashlib.sha1(sig.encode("utf-8")).hexdigest()[:16])
    if not _cached_ok(path):
        path.parent.mkdir(parents=True, exist_ok=True)
        rnd = random.Random(seed)
        b, kc, gc = _rgb3(base), _rgb3(ink), _rgb3(glow)
        mix = lambda c, a: tuple(int(round(b[i] * (1 - a) + c[i] * a)) for i in range(3))   # noqa: E731
        im = Image.new("RGB", (int(W * dpi), int(H * dpi)), b)
        dr = ImageDraw.Draw(im)

        def clear(x, y, m=0.0):
            return not any(kx - 0.12 - m <= x <= kx + kw + 0.12 + m and ky - 0.12 - m <= y <= ky + kh + 0.12 + m
                           for kx, ky, kw, kh in keep_clear)
        for _ in range(int(140 * float(density) * (W * H) / (13.333 * 7.5))):
            x, y = rnd.uniform(0.05, W - 0.05), rnd.uniform(0.05, H - 0.05)      # every draw consumed: the sky
            d = rnd.choice((0.018, 0.022, 0.026, 0.03, 0.04)) if rnd.random() < 0.85 else rnd.uniform(0.05, 0.07)
            c = mix(kc if rnd.random() < 0.8 else gc, rnd.uniform(0.35, 0.95))   # is the same whatever is kept clear
            if clear(x, y):
                r = d * dpi / 2.0
                dr.ellipse([x * dpi - r, y * dpi - r, x * dpi + r, y * dpi + r], fill=c)
        lw = max(1, int(round(dpi / 120.0)))
        for _ in range(6):
            x, y, L = rnd.uniform(0.3, W - 0.3), rnd.uniform(0.3, H * 0.6), rnd.uniform(0.12, 0.2)
            if clear(x, y, L):
                c = mix(gc, 0.8)
                dr.line([((x - L) * dpi, y * dpi), ((x + L) * dpi, y * dpi)], fill=c, width=lw)
                dr.line([(x * dpi, (y - L) * dpi), (x * dpi, (y + L) * dpi)], fill=c, width=lw)
                r = 0.03 * dpi
                dr.ellipse([x * dpi - r, y * dpi - r, x * dpi + r, y * dpi + r], fill=mix(gc, 0.9))
        _atomic_save(im, path, optimize=True)
    _part, rid = slide.part.get_or_add_image_part(str(path))
    _bg(slide, '<a:blipFill dpi="0" rotWithShape="1"><a:blip r:embed="{}"/><a:srcRect/><a:stretch><a:fillRect/>'
               '</a:stretch></a:blipFill>'.format(rid))
    return str(path)


def _radial(shape, color, alpha):
    """Swap a solid fill for a radial fade: `alpha` at the centre, clear by 68% of the path. path="circle" puts the
    100% stop at the bounding box's CORNER, not the disc's edge — a fade ending at 100% left a rim at ~71%
    (look-dev render, 2026-10-08)."""
    sp = shape._element.spPr
    sf = sp.find(qn("a:solidFill"))
    sf.addprevious(etree.fromstring(
        '<a:gradFill xmlns:a="{a}" rotWithShape="1"><a:gsLst>'
        '<a:gs pos="0"><a:srgbClr val="{c}"><a:alpha val="{a0}"/></a:srgbClr></a:gs>'
        '<a:gs pos="34000"><a:srgbClr val="{c}"><a:alpha val="{a1}"/></a:srgbClr></a:gs>'
        '<a:gs pos="68000"><a:srgbClr val="{c}"><a:alpha val="0"/></a:srgbClr></a:gs>'
        '<a:gs pos="100000"><a:srgbClr val="{c}"><a:alpha val="0"/></a:srgbClr></a:gs></a:gsLst>'
        '<a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path></a:gradFill>'.format(
            a=A_NS, c=hexstr(color), a0=_pct(alpha), a1=_pct(alpha * 0.45))))
    sp.remove(sf)
    return shape


def radial_glow(slide, cx, cy, d, color, *, alpha=0.42):
    """A soft glow behind a figure or a star, shrunk until it is whole on the page."""
    W, H = page_size(slide)
    d = max(0.05, min(d, 2 * cx, 2 * (W - cx), 2 * cy, 2 * (H - cy)))
    sh = _radial(disc(slide, cx, cy, d, color), color, alpha)
    dk.decorative(sh, "a soft glow behind a figure; the words beside it carry the meaning")
    return sh


def horizon_glow(slide, top, color, deep, *, alpha=0.45):
    """A warm horizon at the foot of the page: clear at `top`, `alpha` of `deep` at the page's bottom edge."""
    W, H = page_size(slide)
    top = min(max(float(top), 0.0), H - 0.05)
    b = dk.box(slide, 0, top, W, H - top, fill=hexstr(color))
    sp = b._element.spPr
    sf = sp.find(qn("a:solidFill"))
    sf.addprevious(etree.fromstring(
        '<a:gradFill xmlns:a="{a}" rotWithShape="1"><a:gsLst>'
        '<a:gs pos="0"><a:srgbClr val="{c}"><a:alpha val="0"/></a:srgbClr></a:gs>'
        '<a:gs pos="100000"><a:srgbClr val="{d}"><a:alpha val="{al}"/></a:srgbClr></a:gs></a:gsLst>'
        '<a:lin ang="5400000" scaled="0"/></a:gradFill>'.format(a=A_NS, c=hexstr(color), d=hexstr(deep), al=_pct(alpha))))
    sp.remove(sf)
    dk.decorative(b, "the warm horizon at the foot of a night page")
    return b


def crescent(slide, cx, cy, d, color, ground):
    """A crescent moon: a disc of `color` cut by a disc of the ground, offset up and right — moved so both discs are
    whole on the page."""
    W, H = page_size(slide)
    cx = min(max(cx, 0.5 * d + 0.05), W - 0.71 * d - 0.05)
    cy = min(max(cy, 0.60 * d + 0.05), H - 0.5 * d - 0.05)
    a = disc(slide, cx, cy, d, color)
    b = disc(slide, cx + 0.24 * d, cy - 0.13 * d, 0.94 * d, ground)
    for sh in (a, b):
        dk.decorative(sh, "the crescent moon of the night sky; nothing reads from it")
        dk.overlap_intent(sh, "the crescent is one disc cut by another: they overlap by construction")
    return a, b


def ring(slide, cx, cy, d, color, *, w=1.0):
    """A thin circle outline (a round window's rim)."""
    b = dk.box(slide, cx - d / 2.0, cy - d / 2.0, d, d, fill=None, line=dk._as_rgb(hexstr(color)), line_w=w)
    b._element.spPr.find(qn("a:prstGeom")).set("prst", "ellipse")
    dk.decorative(b, "the rim of a round picture window")
    return b


def polyline(slide, pts, color, *, w=1.0, alpha=None):
    """An OPEN polyline as one editable shape, every point clamped onto the page."""
    W, H = page_size(slide)
    pts = [(min(max(float(x), 0.0), W), min(max(float(y), 0.0), H)) for x, y in pts]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    x0, y0 = min(xs), min(ys)
    bw, bh = max(max(xs) - x0, 0.01), max(max(ys) - y0, 0.01)
    u = [((px - x0) / bw * U, (py - y0) / bh * U) for px, py in pts]
    d = "<a:moveTo>{}</a:moveTo>".format(orn._pt(*u[0])) + "".join("<a:lnTo>{}</a:lnTo>".format(orn._pt(*q)) for q in u[1:])
    sh = _custom(slide, x0, y0, bw, bh, '<a:path w="{u}" h="{u}" fill="none">{d}</a:path>'.format(u=U, d=d),
                 line=hexstr(color), line_w=w)
    if alpha is not None:
        clr = sh._element.spPr.find(qn("a:ln")).find(qn("a:solidFill"))[0]
        clr.append(clr.makeelement(qn("a:alpha"), {"val": str(_pct(alpha))}))
    return sh


def chalk_path(slide, pts, color, *, w=2.2, seed=0, passes=2):
    """A chalk stroke: `passes` jittered copies of the polyline, the second thinner and fainter (chalk dragged twice)."""
    rnd = random.Random(seed)
    out = []
    for k in range(passes):
        j = [(x + rnd.uniform(-0.012, 0.012), y + rnd.uniform(-0.012, 0.012)) for x, y in pts]
        sh = polyline(slide, j, color, w=w * (1.0 if k == 0 else 0.6), alpha=0.85 if k == 0 else 0.45)
        dk.decorative(sh, "a chalk stroke; the words it frames carry the meaning")
        out.append(sh)
    return out


def chalk_box(slide, x, y, w, h, color, *, seed=0):
    rnd = random.Random(seed)
    o = lambda: rnd.uniform(-0.04, 0.04)   # noqa: E731
    pts = [(x + o(), y + o()), (x + w + o(), y + o()), (x + w + o(), y + h + o()), (x + o(), y + h + o()), (x + 0.05, y + o())]
    return chalk_path(slide, pts, color, w=2.0, seed=seed)


def chalk_ellipse(slide, cx, cy, rx, ry, color, *, seed=0, turns=1.08):
    """A hand-drawn ring: enough points for its size that no facet shows (60 read as a polygon on a large ring), the
    wobble eased along the stroke rather than jumping point to point, and a short overshoot where the chalk lifts."""
    rnd = random.Random(seed)
    n = max(60, int(2 * math.pi * max(rx, ry) * 24))
    k1, k2, ph1, ph2 = rnd.uniform(0.012, 0.025), rnd.uniform(0.008, 0.015), rnd.uniform(0, 6.3), rnd.uniform(0, 6.3)
    pts = []
    for t in range(n + 1):
        a = 2 * math.pi * turns * t / n - 2.2
        wob = 1 + k1 * math.sin(3 * a + ph1) + k2 * math.sin(7 * a + ph2)
        pts.append((cx + rx * wob * math.cos(a), cy + ry * wob * math.sin(a)))
    return chalk_path(slide, pts, color, w=2.4, seed=seed)


def chalk_underline(slide, x, y, w, color, *, seed=0):
    a = chalk_path(slide, [(x + w * t / 10.0, y + 0.03 * math.sin(t * 1.7 + seed)) for t in range(11)], color, w=2.6, seed=seed)
    b = chalk_path(slide, [(x + 0.1 + (w - 0.2) * t / 10.0, y + 0.11 + 0.03 * math.sin(t * 1.3 + seed)) for t in range(11)],
                   color, w=1.8, seed=seed + 1)
    return a + b


def chalk_arrow(slide, x0, y0, x1, y1, color, *, seed=0):
    ang = math.atan2(y1 - y0, x1 - x0)
    L = 0.16
    head = [(x1 + L * math.cos(ang + 2.6), y1 + L * math.sin(ang + 2.6)), (x1, y1),
            (x1 + L * math.cos(ang - 2.6), y1 + L * math.sin(ang - 2.6))]
    return chalk_path(slide, [(x0, y0), (x1, y1)], color, w=2.2, seed=seed) + \
        chalk_path(slide, head, color, w=2.2, seed=seed + 1, passes=1)


def board_frame(slide, wood, chalk):
    """A blackboard's wooden frame drawn INSIDE the page, and a stick of chalk on the ledge. Returns the inner rect."""
    W, H = page_size(slide)
    t = 0.14 * min(W, H) / 7.5
    for x, y, w, h in ((0, 0, W, t), (0, H - t, W, t), (0, t, t, H - 2 * t), (W - t, t, t, H - 2 * t)):   # bars meet, never overlap
        dk.decorative(dk.box(slide, x, y, w, h, fill=hexstr(wood)), "the blackboard's wooden frame")
    stick = dk.box(slide, 0.32 * W, H - t - 0.06, 1.2 * min(W, H) / 7.5, 0.06, fill=hexstr(chalk))
    dk.decorative(stick, "a stick of chalk on the board's ledge")
    return (t, t, W - 2 * t, H - 2 * t)


def chip_width(text, size, face, *, bold=True, ea_face=None):
    """The width (in) of a one-line pill holding `text` at `size`, plus the pill's padding: the wider of the lints'
    reading (every CJK character an em, the rest in `face` — 0.62 em a character when the face is not installed here)
    and LibreOffice's (display_type.line_width: each script in its own face — `ea_face` for CJK, an em a character
    without one — and the autospace at every change between CJK and Latin, which "GPT-5 模型" has and a pill that never
    wraps has no room for). Measured in the face the weight renders in: a .ttc family's bold, not its face 0."""
    import display_type as _dt
    w = _dt.em_width(text, size, face, bold)
    if dk._has_cjk(text):
        w = max(w, _dt.line_width(text, size, face, ea_face, bold))
    return w + 1.2 * size / 72.0


def chip(slide, x, y, text, *, size, fill, ink, face, ea_face=None, bold=True, roomy=False):
    """A pill label: rounded, one line that never wraps, as wide as its measured words. Returns (x, y, w, h).
    `roomy=True` (a visual language's card-sized pill) gives a pill taller than 0.35in half an em above and below."""
    # every pill is 1.9em tall unless its caller asks for room (ordinary decks unchanged at every size — a 14pt chip
    # grew 0.37 -> 0.41in when the room was decided by size alone, final review 2026-10-16); a roomy one big enough to
    # read as a card gets half an em above and below its line — a CJK line is set taller, so its pill is too
    w, h = chip_width(text, size, face, bold=bold, ea_face=ea_face), size / 72.0 * 1.9
    if roomy and h > 0.35:
        h = size / 72.0 * (2.4 if dk._has_cjk(text) else 2.1)
    dk.box(slide, x, y, w, h, fill=hexstr(fill), round=True, r=h / 2.0)
    run = (text, size, dk._as_rgb(hexstr(ink)), bold, False, face) + ((ea_face,) if ea_face else ())
    tb = dk.text(slide, x, y, w, h, [[run]], align=dk.PP_ALIGN.CENTER, anchor=dk.MSO_ANCHOR.MIDDLE)
    tb.text_frame.word_wrap = False
    dk.overlap_intent(tb, "the label sits on its own pill")
    return (x, y, w, h)


def share_bar(slide, x, y, w, frac, *, track, fill, h=0.16):
    """A rounded share bar: the whole track, and `frac` (clamped to 0..1) of it filled from the left. Returns
    (track, filled) — filled is None at 0 — so a caller that prints both numbers can declare the track decorative."""
    frac = min(max(float(frac), 0.0), 1.0)
    trk = dk.box(slide, x, y, w, h, fill=hexstr(track), round=True, r=h / 2.0)
    filled = None
    if frac > 0:
        filled = dk.box(slide, x, y, max(h, w * frac), h, fill=hexstr(fill), round=True, r=h / 2.0)
    return trk, filled


# ═══════════════════ P5: wayfinding (metro map + signage) and interface (app UI) ═══════════════════
def route(slide, pts, color, *, w=0.16, casing=None):
    """A transit route through `pts` [(x, y), …] — horizontal, vertical or 45° legs — as round-capped strokes `w` in
    wide. Clipped to the page by seg(); a cap may overhang the edge, which beyond_page() does not count (it reads
    the connector's box). `casing` (a colour) first draws the same path 0.06in wider in it — a light line (yellow on
    the enamel ground, 1.67:1) reads on its dark casing, as on a printed metro map."""
    if casing:
        route(slide, pts, casing, w=w + 0.06)
    out = []
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        c = seg(slide, x0, y0, x1, y1, color, w=w * 72.0)
        c._element.spPr.find(qn("a:ln")).set("cap", "rnd")
        out.append(c)
    return out


def station(slide, cx, cy, d, *, ring, fill="FFFFFF", w=2.25):
    """A station: a white disc with a dark ring, centred on (cx, cy)."""
    return dk.disc(slide, cx - d / 2.0, cy - d / 2.0, d, fill=hexstr(fill), line=dk._as_rgb(hexstr(ring)), line_w=w)


def interchange(slide, cx, cy, w, h, *, ring, fill="FFFFFF", lw=3.0):
    """An interchange: a white rounded rectangle with a heavy dark ring, centred on (cx, cy)."""
    return dk.box(slide, cx - w / 2.0, cy - h / 2.0, w, h, fill=hexstr(fill), line=dk._as_rgb(hexstr(ring)),
                  line_w=lw, round=True, r=min(w, h) / 2.0)


def roundel(slide, cx, cy, d, text, *, fill, ink, size, face, ea_face=None, w=None):
    """A line roundel: a filled disc with one short unwrapped label — or, given `w` wider than `d`, a pill that wide
    (a longer code, as transit signs set "M10" or 一号线). Centred on (cx, cy). Returns (x, y, w, d)."""
    w = max(d, w or d)
    x, y = cx - w / 2.0, cy - d / 2.0
    if w > d:
        dk.box(slide, x, y, w, d, fill=hexstr(fill), round=True, r=d / 2.0)
    else:
        dk.disc(slide, x, y, d, fill=hexstr(fill))
    run = (text, size, dk._as_rgb(hexstr(ink)), True, False, face) + ((ea_face,) if ea_face else ())
    tb = dk.text(slide, x, y, w, d, [[run]], align=dk.PP_ALIGN.CENTER, anchor=dk.MSO_ANCHOR.MIDDLE, space_after=0)
    tb.text_frame.word_wrap = False
    dk.overlap_intent(tb, "the label sits on its own roundel")
    return (x, y, w, d)


def sign_panel(slide, x, y, w, h, *, fill, keyline="FFFFFF", r=0.12):
    """An enamel sign: a rounded panel with a white keyline inset by 0.07in. Returns the rect inside the keyline."""
    dk.box(slide, x, y, w, h, fill=hexstr(fill), round=True, r=r)
    k = dk.box(slide, x + 0.07, y + 0.07, w - 0.14, h - 0.14, fill=None, line=dk._as_rgb(hexstr(keyline)), line_w=1.5,
               round=True, r=max(0.02, r - 0.04))
    dk.decorative(k, "the sign's keyline")
    return (x + 0.07, y + 0.07, w - 0.14, h - 0.14)


def ui_window(slide, x, y, w, h, *, fill, line, drop, r=0.22, bar=None):
    """An app window: a flat drop offset under a rounded panel with a hairline, and an optional top bar separated by
    a hairline. Returns the content rect (below the bar)."""
    d = dk.box(slide, x + 0.04, y + 0.08, w, h, fill=hexstr(drop), round=True, r=r)
    dk.decorative(d, "the window's drop edge")
    dk.box(slide, x, y, w, h, fill=hexstr(fill), line=dk._as_rgb(hexstr(line)), line_w=0.75, round=True, r=r)
    if bar:
        hl = dk.box(slide, x, y + bar, w, 0.012, fill=hexstr(line))
        dk.decorative(hl, "the top bar's hairline")
        return (x, y + bar, w, h - bar)
    return (x, y, w, h)


def ui_toggle(slide, x, y, on, *, on_fill, off_line, knob="FFFFFF", w=0.62, h=0.34):
    """A switch: an on track filled with the primary, an off track outlined; the knob at the matching end."""
    if on:
        dk.box(slide, x, y, w, h, fill=hexstr(on_fill), round=True, r=h / 2.0)
    else:
        dk.box(slide, x, y, w, h, fill=None, line=dk._as_rgb(hexstr(off_line)), line_w=1.25, round=True, r=h / 2.0)
    d = h - 0.08
    dk.disc(slide, x + (w - d - 0.04 if on else 0.04), y + 0.04, d,
            fill=hexstr(knob if on else off_line))


def ui_button_width(text, size, face):
    """A button as wide as its words plus 1.6 em of padding (chip_width carries 1.2 em; a button breathes more)."""
    return chip_width(text, size, face) + 0.4 * size / 72.0 + 0.3


def ui_button(slide, x, y, text, *, size, fill, ink, face, ea_face=None, line=None, h=None):
    """A pill button, one line that never wraps, its width measured. Returns (x, y, w, h)."""
    w = ui_button_width(text, size, face)
    h = h or size / 72.0 * 2.6
    dk.box(slide, x, y, w, h, fill=hexstr(fill) if fill else None, line=dk._as_rgb(hexstr(line)) if line else None,
           line_w=1.0, round=True, r=h / 2.0)
    run = (text, size, dk._as_rgb(hexstr(ink)), True, False, face) + ((ea_face,) if ea_face else ())
    tb = dk.text(slide, x, y, w, h, [[run]], align=dk.PP_ALIGN.CENTER, anchor=dk.MSO_ANCHOR.MIDDLE, space_after=0)
    tb.text_frame.word_wrap = False
    dk.overlap_intent(tb, "the label sits on its own button")
    return (x, y, w, h)


def ui_cursor(slide, x, y, *, fill, edge, size=0.34):
    """A pointer arrow resting at (x, y) — its tip — drawn as a tilted triangle with a light edge."""
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.util import Inches, Pt
    sh = slide.shapes.add_shape(MSO_SHAPE.ISOSCELES_TRIANGLE, Inches(x), Inches(y), Inches(size * 0.76), Inches(size))
    sh.rotation = 332.0
    sh.fill.solid()
    sh.fill.fore_color.rgb = dk._as_rgb(hexstr(fill))
    sh.line.color.rgb = dk._as_rgb(hexstr(edge))
    sh.line.width = Pt(1.5)
    dk.adopt(sh)
    dk.decorative(sh, "a pointer resting on the primary button")
    dk.overlap_intent(sh, "the pointer's tip rests on the button it points at")   # its tilted box crossed the button
    return sh


def ui_device(slide, x, y, w, h, kind, *, frame, screen, edge=None):
    """A device frame around a picture: "browser" (a window with a slim bar and three dots) or "phone" (a rounded
    bezel, with a hairline in `edge` when given). Returns the screen rect the picture goes in."""
    if kind == "browser":
        dk.box(slide, x, y, w, h, fill=hexstr(frame), line=dk._as_rgb(hexstr(screen)), line_w=0.75, round=True, r=0.14)
        bar = min(0.36, 0.09 * h)
        for i in range(3):
            dot = dk.disc(slide, x + 0.16 + i * 0.16, y + bar / 2.0 - 0.045, 0.09, fill=hexstr(screen))
            dk.decorative(dot, "browser window chrome")
        return (x + 0.06, y + bar, w - 0.12, h - bar - 0.06)
    if kind == "phone":
        dk.box(slide, x, y, w, h, fill=hexstr(frame), round=True, r=min(w, h) * 0.16,
               **({"line": dk._as_rgb(hexstr(edge)), "line_w": 0.75} if edge else {}))
        m = max(0.06, 0.045 * w)
        return (x + m, y + m * 1.6, w - 2 * m, h - m * 3.2)
    raise ValueError("ui_device(): kind must be 'browser' or 'phone', got {!r}".format(kind))


def ui_bubble(slide, x, y, w, h, *, fill, line, r=0.32, tail=True):
    """A chat bubble: a rounded panel with a real TAIL — a triangle on its left edge, just below the corner, pointing
    out toward the avatar. The body and the tail share one outline colour `line`: the tail's two outer edges are an
    open stroke and its base is a fill-only patch over the body's outline, so the outline runs unbroken into it.
    (The old tail was a square patch on the corner in the faint hairline colour, 1.3:1 against the card.)
    Returns its rect."""
    dk.box(slide, x, y, w, h, fill=hexstr(fill), line=dk._as_rgb(hexstr(line)), line_w=0.75, round=True, r=r)
    if tail:
        ln = 0.95 * r                                         # how far the tail reaches, and how long its base is
        y0 = y + r                                            # the base starts where the left edge turns straight
        pts = [(x, y0), (x - ln, y0 + 0.6 * ln), (x, y0 + ln)]
        patch = poly(slide, [(x + 0.012, y0 + 0.004), (x - ln, y0 + 0.6 * ln), (x + 0.012, y0 + ln - 0.004)], fill=fill)
        dk.decorative(patch, "the bubble's tail, filled like the bubble")
        edge = polyline(slide, pts, line, w=0.75)
        dk.decorative(edge, "the bubble's tail outline")
    return (x, y, w, h)
