#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书一键生成 · 半自动发布脚本（Playwright）
==========================================
工作模式：在你本人登录态下，把"发布四件套"(标题/正文/标签/封面)自动填入创作者中心
并点击「存草稿」。**不自动点发布**，留人工确认阀，把封号风险降到最低。

⚠️ 重要合规与风控提示：
  - 仅用于你本人账号、你自己创作并合规的内容。
  - 高频操作可能触发平台风控，建议单篇人工复核后再发。
  - Cookie 仅保存在你本地文件，不上传任何地方。
  - 小红书页面 DOM 会变化，如填表失效，按页面实际选择器微调下方 SELECTORS。

用法：
  # 首次：手动登录并保存 Cookie（会打开浏览器，登录后自动存）
  python3 publish_bot.py --login

  # 提交草稿（需先 --login 过）
  python3 publish_bot.py --draft 发布四件套.json

JSON 格式（见 report-template.md）：
  {"title":"标题","body":"正文\\n换行","tags":["#大词","#中词"],"cover":"/path/封面.png"}
"""
import json
import os
import sys

# playwright 只有真实提交时才必需；dry-run 不依赖它
HAS_PW = False
try:
    from playwright.sync_api import sync_playwright
    HAS_PW = True
except ImportError:
    pass


def ensure_pw():
    if HAS_PW:
        return
    print("❌ 缺 playwright 库，没法真正提交草稿（dry-run 不受影响）。")
    print("   👉 安装两条命令（都要跑）：")
    print("      pip install playwright")
    print("      playwright install chromium")
    sys.exit(2)

COOKIE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "xhs_cookies.json")
CREATOR_URL = "https://creator.xiaohongshu.com/publish/publish"
# 选择器可能随页面改版变化，按需微调
SELECTORS = {
    "title": 'input[placeholder*="标题"], .title-input, #post-title',
    "body": 'textarea[placeholder*="正文"], .content-input, #post-content',
    "tag_add": 'button:has-text("添加标签"), .tag-add',
    "cover_upload": 'input[type="file"]',
    "draft_btn": 'button:has-text("存草稿")',
}


def load_payload(path):
    """读物料 JSON：不存在/不是 JSON/缺字段，都给中文提示。"""
    if not os.path.exists(path):
        hit = [f for f in os.listdir(".") if f.endswith(".json") and "cookie" not in f.lower()]
        print(f"❌ 找不到物料文件：{path}")
        if hit:
            print(f"   👉 你是不是想用这个：{hit[0]}")
        else:
            print("   👉 先让技能生成「发布四件套 JSON」，再传路径进来。")
        sys.exit(1)
    try:
        payload = json.load(open(path, encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        print(f"❌ 物料文件不是合法 JSON（{e.__class__.__name__}）。")
        print("   👉 重新让技能生成物料包；自己手写的话，别用中文引号，键和值都用英文双引号。")
        sys.exit(1)
    if not payload.get("title") or not payload.get("body"):
        print("❌ 物料里缺 title 或 body 字段。")
        print('   👉 最简格式：{"title":"标题","body":"正文","tags":["#标签"],"cover":"封面.png"}')
        sys.exit(1)
    return payload


def save_cookies(p, path):
    """登录并存 Cookie。只开一个浏览器。"""
    browser = p.chromium.launch(headless=False)
    ctx = browser.new_context()
    page = ctx.new_page()
    page.goto(CREATOR_URL)
    print("➡️ 请在打开的浏览器里登录你的小红书创作者中心账号。")
    input("   登录完成后回到这里按回车继续：")
    ctx.storage_state(path=path)
    browser.close()
    print(f"✅ Cookie 已保存到 {path}（只在你本地，不会上传）")
    print("   👉 下一步：python3 publish_bot.py --draft 你的物料.json")


def dry_run(payload):
    """不开浏览器，在沙箱/无登录态下也能跑通：校验物料 + 打印草稿箱预览。"""
    print("🔍 —— 草稿箱预览（dry-run，未真实提交）——")
    title = payload.get("title", "")
    body = payload.get("body", "")
    tags = payload.get("tags", [])
    cover = payload.get("cover", "")

    print(f"\n【标题】{title}")
    tl = len(title)
    print(f"  字数 {tl} · {'✅ ≤13 字，合适' if tl <= 13 else '⚠️ 超过 13 字，建议压短'}")

    print(f"\n【正文】首 200 字预览：")
    print(body[:200] + ("…" if len(body) > 200 else ""))
    print(f"  总字数 {len(body)}")

    print(f"\n【标签】")
    for t in tags:
        print(f"  - {t}")
    if len(tags) == 0:
        print("  ⚠️ 没标签，至少补 1 个大词")
    elif len(tags) > 5:
        print("  ⚠️ 标签偏多，3–5 个足够")

    print(f"\n【封面】")
    if cover:
        if os.path.exists(cover):
            print(f"  ✅ 已就绪：{cover}")
        else:
            print(f"  ⚠️ 文件不存在：{cover}（gen_cover.py 出一张）")
    else:
        print("  ⚠️ 没指定封面路径（可省，但建议配）")

    print("\n✅ 物料链路校验通过。真实提交两步（需你本机登录态）：")
    print("   1) python3 publish_bot.py --login        # 首次手动登录存 Cookie")
    print("   2) python3 publish_bot.py --draft 你的物料.json   # 填表并点存草稿")
    return True


def submit_draft(p, payload, path):
    if not os.path.exists(path):
        print("❌ 还没登录过（找不到 Cookie 文件）。")
        print("   👉 先运行一次：python3 publish_bot.py --login")
        return False
    browser = p.chromium.launch(headless=False)
    ctx = browser.new_context(storage_state=path)
    page = ctx.new_page()
    try:
        page.goto(CREATOR_URL, timeout=30000)
        page.wait_for_load_state("networkidle", timeout=20000)
    except Exception:
        browser.close()
        print("❌ 创作者中心页面打不开或加载超时。")
        print("   👉 检查网络；如果页面改版了，手动发一遍，并把报错告诉技能。")
        return False

    # 登录态是否还有效：页面跳回登录页说明 Cookie 过期
    if "login" in page.url.lower():
        browser.close()
        print("❌ 登录态过期了（页面跳回了登录页）。")
        print("   👉 重新登录一次：python3 publish_bot.py --login")
        return False

    try:
        # 填标题
        page.fill(SELECTORS["title"], payload["title"], timeout=10000)
        # 填正文（换行用实际换行）
        page.fill(SELECTORS["body"], payload["body"], timeout=10000)
        # 添加话题标签
        for tag in payload.get("tags", []):
            page.click(SELECTORS["tag_add"], timeout=8000)
            page.keyboard.type(tag)
            page.keyboard.press("Enter")
        # 上传封面
        if payload.get("cover"):
            if os.path.exists(payload["cover"]):
                page.set_input_files(SELECTORS["cover_upload"], payload["cover"])
            else:
                print(f"⚠️  封面文件不存在：{payload['cover']}，先跳过上传。")
                print("   👉 重新跑 gen_cover.py 出一张，或手动在页面里传。")
        page.wait_for_timeout(1500)
        # 存草稿（不点发布）
        page.click(SELECTORS["draft_btn"], timeout=10000)
        page.wait_for_timeout(2000)
    except Exception as e:
        browser.close()
        print(f"❌ 页面填表失败（{e.__class__.__name__}）。")
        print("   👉 十有八九是页面改版，选择器对不上了。两个办法：")
        print("      1. 手动发布：复制标题 → 复制正文 → 复制标签 → 传封面，30 秒贴完；")
        print("      2. 把报错贴给技能，按新版页面调 SELECTORS。")
        return False
    browser.close()
    print("✅ 已提交到草稿箱。请在 App/网页端确认无误后再点发布。")
    print("   👉 记得核对：标题 13 字内、标签 3 个、封面清晰。")
    return True


DEMO_PAYLOAD = {
    "title": "租房收纳：300块搞定全屋",
    "body": (
        "搬过四次家，才摸清收纳的关键不是买盒子，是先把东西按「用得多／用得少」分两堆。\n\n"
        "① 每周都用的，放伸手就够得着的高度；\n"
        "② 一年用一次的，塞到床底或柜顶，别占黄金位；\n"
        "③ 三年没动的，直接处理掉，别给它找房子。\n\n"
        "我这次只花了 300 块：真空压缩袋 45、抽屉分隔盒 39、床底收纳箱 128、"
        "剩下的买了标签机。搬家三次的经验，一次说清。"
    ),
    "tags": ["租房收纳", "小户型收纳", "收纳好物", "搬家"],
    "cover": "",
}



def main():
    import argparse
    ap = argparse.ArgumentParser(description="小红书半自动发布（只存草稿，不自动发布）")
    ap.add_argument("--login", action="store_true", help="手动登录并保存 Cookie")
    ap.add_argument("--draft", help="提交草稿的 JSON 物料路径")
    ap.add_argument("--dry-run", help="只校验物料并打印草稿箱预览，不真实提交（沙箱/无账号可用）")
    ap.add_argument("--demo", action="store_true",
                    help="用内置示例物料跑一遍校验（不联网、不开浏览器、不需登录）")
    a = ap.parse_args()

    # 纯校验分支放在前面：不进入 playwright 上下文，装没装浏览器都能跑
    if a.demo:
        dry_run(DEMO_PAYLOAD)
        sys.exit(0)

    if a.dry_run:
        dry_run(load_payload(a.dry_run))
        sys.exit(0)

    if not a.login and not a.draft and not a.dry_run:
        print("用法：")
        print("  python3 publish_bot.py --login            # 第一次先登录存 Cookie")
        print("  python3 publish_bot.py --draft 物料.json   # 提交草稿（真实）")
        print("  python3 publish_bot.py --dry-run 物料.json # 只预览，不提交（沙箱可用）")
        sys.exit(0)

    with sync_playwright() as p:
        if a.login:
            save_cookies(p, COOKIE_FILE)
        else:
            payload = load_payload(a.draft)
            ok = submit_draft(p, payload, COOKIE_FILE)
            sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
