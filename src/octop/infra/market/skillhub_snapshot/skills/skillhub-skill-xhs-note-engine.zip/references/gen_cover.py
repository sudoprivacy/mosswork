#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书封面生成器：输入文案，按家族 VI 生成竖版(3:4)封面，也支持 1:1 / 16:9。
用法：
  python3 gen_cover.py "主标题" "副标题/标签" 输出.png "署名" 3:4 主色HEX
例：
  python3 gen_cover.py "工资3招多留30%" "刚工作必看" 封面.png "出品人｜村长老谢" 3:4 C2185B
"""
import os
import sys
import argparse
from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    '/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc',
    '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
]


def die(why, nxt):
    print(f"❌ {why}\n   👉 {nxt}")
    sys.exit(1)


def load_font(size, bold=True):
    """逐个候选字体尝试；ttc 的 index 在不同发行版不一样，逐个试。"""
    for path in FONT_CANDIDATES:
        if not os.path.exists(path):
            continue
        for idx in (2, 1, 0):
            try:
                return ImageFont.truetype(path, size, index=idx)
            except Exception:
                continue
    print("⚠️  没找到中文字体，标题可能显示为方块。安装：sudo apt install fonts-noto-cjk")
    return ImageFont.load_default()


def hex2rgb(h):
    h = h.lstrip('#')
    if len(h) not in (3, 6) or any(c not in '0123456789abcdefABCDEF' for c in h):
        die(f"颜色值「{h}」看不懂（要 6 位 HEX，如 C2185B）。",
            "用默认的玫红 C2185B：把这个参数去掉就行。")
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def wrap(text, draw, font, max_w):
    """按像素宽换行；空段落跳过，不产生空行。"""
    lines = []
    for para in text.split('\n'):
        para = para.strip()
        if not para:
            continue
        line = ''
        for ch in para:
            t = line + ch
            if draw.textlength(t, font=font) <= max_w:
                line = t
            else:
                lines.append(line)
                line = ch
        if line:
            lines.append(line)
    return lines


def make(title, subtitle, out, sign, ratio, color):
    sizes = {'3:4': (1080, 1440), '1:1': (1080, 1080), '16:9': (1920, 1080)}
    if ratio not in sizes:
        die(f"比例只支持 {'/'.join(sizes)}，收到的是「{ratio}」。",
            "把比例参数改成 3:4（小红书封面最常用）。")
    if not title.strip():
        die("主标题是空的。", "第一个参数传标题文字，比如 \"工资3招多留30%\"。")
    W, H = sizes[ratio]
    main = hex2rgb(color)
    gold = (0xF2, 0xCB, 0x57)
    white = (255, 255, 255)
    grey = (0xD8, 0xD8, 0xD8)

    out_dir = os.path.dirname(os.path.abspath(out))
    if not os.path.isdir(out_dir):
        die(f"输出目录不存在：{out_dir}", "先建目录，或把输出路径改到已有文件夹。")

    img = Image.new('RGB', (W, H), main)
    d = ImageDraw.Draw(img)
    # 顶部金色细条装饰
    d.rectangle([0, 0, W, 14], fill=gold)
    # 底部细条
    d.rectangle([0, H - 14, W, H], fill=gold)

    max_w = int(W * 0.82)
    # 标题：自动字号 + 换行（最多 3 行，超了缩小并提示）
    tf = load_font(100)
    lines = wrap(title, d, tf, max_w)
    if len(lines) > 3:
        tf = load_font(76)
        lines = wrap(title, d, tf, max_w)
    if len(lines) > 3:
        lines = lines[:3]
        print("⚠️  主标题太长，只保留前 3 行。")
        print("   👉 主标压到 14 字内更醒目，长句挪到副标题参数。")
    lh = tf.size + 26
    total = lh * len(lines)
    y = int(H * 0.36) - total // 2
    for ln in lines:
        d.text((W // 2, y), ln, font=tf, fill=white, anchor='mm')
        y += lh

    # 副标题（金色）
    if subtitle:
        sf = load_font(42)
        sl = wrap(subtitle, d, sf, max_w)[:2]
        sy = y + 36
        for ln in sl:
            d.text((W // 2, sy), ln, font=sf, fill=gold, anchor='mm')
            sy += sf.size + 16

    # 署名（底部居中）
    if sign:
        gf = load_font(32)
        d.text((W // 2, H - 78), sign, font=gf, fill=grey, anchor='mm')

    img.save(out)
    print(f'✅ 封面已保存 {out} ({W}x{H})')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description='小红书封面生成器（3:4 默认）')
    p.add_argument('--demo', action='store_true', help='生成示例封面（无需参数）')
    p.add_argument('title', nargs='?', default=None, help='主标题（建议 ≤14 字）')
    p.add_argument('subtitle', nargs='?', default='', help='副标题/标签（可省）')
    p.add_argument('out', nargs='?', default=None, help='输出 PNG 路径')
    p.add_argument('sign', nargs='?', default='', help='底部署名（可省）')
    p.add_argument('ratio', nargs='?', default='3:4', help='比例 3:4 / 1:1 / 16:9')
    p.add_argument('color', nargs='?', default='C2185B', help='主色 HEX，如 C2185B')
    a = p.parse_args()
    if a.demo or not a.title:
        a.title = a.title or '月薪5千，我存下了第一个10万'
        a.subtitle = a.subtitle or '存钱｜打工人实测'
        a.out = a.out or 'cover-demo.png'
        print('未给参数，生成示例封面（正式使用：gen_cover.py "标题" "副标题" 输出.png）')
    make(a.title, a.subtitle, a.out, a.sign, a.ratio, a.color)
