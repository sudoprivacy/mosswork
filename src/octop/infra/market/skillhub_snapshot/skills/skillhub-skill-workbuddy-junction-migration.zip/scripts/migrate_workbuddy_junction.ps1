<#
.SYNOPSIS
  Migrate a large, in-use application data directory to another drive via Windows junction.
.DESCRIPTION
  Robocopy full copy (with /XJ anti-loop) -> verify -> rename source as backup -> create
  junction (mklink /J) -> bidirectional verify. All original paths stay transparent.
  English messages + parameterized paths to avoid .ps1 encoding corruption with non-ASCII paths.
.PARAMETER SourceDir
  Source directory to migrate, e.g. "C:\Users\foo\.workbuddy"
.PARAMETER TargetDir
  Destination directory (must not exist or be empty), e.g. "F:\WorkBuddy\.workbuddy"
.PARAMETER BackupSuffix
  Suffix for the renamed source backup. Default "_old".
.PARAMETER Force
  Skip the "is source locked?" interactive check. Use only after confirming the owning app is closed.
.EXAMPLE
  .\migrate_workbuddy_junction.ps1 -SourceDir "C:\Users\foo\.workbuddy" -TargetDir "F:\WorkBuddy\.workbuddy"
.NOTES
  Prerequisite: the application using SourceDir MUST be fully exited before running,
  otherwise the rename step will fail with Access Denied. This script does NOT kill processes.
  Junction (mklink /J) does not require admin privileges and works across volumes.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)] [string]$SourceDir,
    [Parameter(Mandatory=$true)] [string]$TargetDir,
    [string]$BackupSuffix = "_old",
    [switch]$Force
)

$ErrorActionPreference = "Stop"
function Write-Step($msg) { Write-Host "[STEP] $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "[OK]   $msg" -ForegroundColor Green }
function Write-Warn2($msg){ Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }

# ---------- Step 0: Recon ----------
Write-Step "Step 0: Recon"
if (-not (Test-Path $SourceDir)) { Write-Err "Source not found: $SourceDir"; exit 1 }
$srcItem = Get-Item $SourceDir -Force
if ($srcItem.LinkType) { Write-Err "Source is already a link ($($srcItem.LinkType)) -> $($srcItem.Target). Aborting to avoid recursion."; exit 1 }
$srcSize = (Get-ChildItem $SourceDir -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Ok ("Source size: {0:N2} GB" -f ($srcSize/1GB))
$targetParent = Split-Path $TargetDir -Parent
$targetDrive = (Split-Path $TargetDir -Qualifier)
$free = (Get-PSDrive $targetDrive.TrimEnd(':')).Free
Write-Ok ("Target drive {0} free: {1:N2} GB" -f $targetDrive, ($free/1GB))
if ($free -lt $srcSize * 1.1) { Write-Err "Not enough free space on target. Need >= 110% of source."; exit 1 }
if (Test-Path $TargetDir) {
    $existing = Get-ChildItem $TargetDir -Force -ErrorAction SilentlyContinue
    if ($existing) { Write-Err "Target exists and is not empty: $TargetDir. Pick a clean path or clear it first."; exit 1 } else { Write-Warn2 "Target exists but empty, will reuse." }
} else { New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null }

# ---------- Step 1: Robocopy ----------
Write-Step "Step 1: Robocopy full copy (/XJ anti-loop)"
$log = Join-Path $SourceDir "robocopy-migration.log"
robocopy $SourceDir $TargetDir /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XJ /NFL /NDL /NP /LOG:"$log" | Out-Null
$rc = $LASTEXITCODE
if ($rc -ge 8) { Write-Err "Robocopy exit $rc (errors). Check log: $log"; exit 1 }
Write-Ok "Robocopy done, exit $rc (0-7 = success)"

# ---------- Step 2: Verify copy ----------
Write-Step "Step 2: Verify copy integrity"
$dstSize = (Get-ChildItem $TargetDir -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
$srcCnt  = (Get-ChildItem $SourceDir -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
$dstCnt  = (Get-ChildItem $TargetDir -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object).Count
Write-Ok ("Source: {0} files / {1:N2} GB | Target: {2} files / {3:N2} GB" -f $srcCnt, ($srcSize/1GB), $dstCnt, ($dstSize/1GB))
# Nested self-copy check
$nestedA = Join-Path $TargetDir (Split-Path $TargetDir -Leaf)
if (Test-Path $nestedA) { Write-Err "Nested self-copy detected: $nestedA. Robocopy ran AFTER a junction was created. Aborting."; exit 1 }
Write-Ok "No nested self-copy"

# ---------- Step 3: Rename source as backup ----------
Write-Step "Step 3: Rename source as backup (app MUST be closed)"
if (-not $Force) {
    Write-Warn2 "Confirm the application using '$SourceDir' is FULLY exited (window + tray)."
    $a = Read-Host "Type 'yes' to proceed renaming source -> ${SourceDir}${BackupSuffix}"
    if ($a -ne 'yes') { Write-Warn2 "Aborted by user. Backup/rename skipped."; exit 2 }
}
$backupDir = "$SourceDir$BackupSuffix"
if (Test-Path $backupDir) { Write-Warn2 "Backup already exists, removing old backup first."; Remove-Item $backupDir -Recurse -Force }
try {
    Rename-Item $SourceDir -NewName (Split-Path $backupDir -Leaf)
    Write-Ok "Source renamed to $backupDir"
} catch {
    Write-Err "Rename failed (likely app still holds the dir): $($_.Exception.Message)"
    Write-Warn2 "Fully exit the application and re-run with -Force, or reboot and retry."
    exit 3
}

# ---------- Step 4: Create junction ----------
Write-Step "Step 4: Create junction (mklink /J, no admin needed)"
try {
    $j = New-Item -ItemType Junction -Path $SourceDir -Target $TargetDir
    Write-Ok "Junction created: $($j.FullName) -> $($j.Target)"
} catch {
    Write-Err "Junction creation failed: $($_.Exception.Message)"
    Write-Warn2 "ROLLBACK: renaming backup back to source."
    Rename-Item $backupDir -NewName (Split-Path $SourceDir -Leaf)
    exit 4
}

# ---------- Step 5: Bidirectional verify ----------
Write-Step "Step 5: Bidirectional verify"
$link = Get-Item $SourceDir -Force
if ($link.LinkType -ne "Junction") { Write-Err "Link type mismatch: $($link.LinkType)"; exit 5 }
Write-Ok "LinkType=$($link.LinkType) Target=$($link.Target)"
$sample = @("SOUL.md","IDENTITY.md","MEMORY.md","settings.json")
foreach ($f in $sample) {
    $p1 = Join-Path $SourceDir $f; $p2 = Join-Path $TargetDir $f
    if ((Test-Path $p1) -and (Test-Path $p2)) {
        $s1 = (Get-Item $p1 -Force).Length; $s2 = (Get-Item $p2 -Force).Length
        if ($s1 -eq $s2) { Write-Ok "$f : $($s1)B == $($s2)B" } else { Write-Warn2 "$f size mismatch $s1 vs $s2" }
    }
}
Write-Host ""
Write-Ok "Migration complete. Original path now transparent -> $TargetDir"
Write-Host "Backup retained at: $backupDir"
Write-Host "Observe 1-2 days, then (after closing the app) run:"
Write-Host "  Remove-Item `"$backupDir`" -Recurse -Force"
