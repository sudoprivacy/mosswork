# Junction 迁移故障排查

记录迁移过程中真实遇到的陷阱与处理，按发生频率排序。

## 1. 源目录被运行中应用占用 → Rename-Item Access Denied
**现象**：第 3 步改名时报 `拒绝访问` / `Access Denied`。
**根因**：源目录正被应用进程持有句柄（WorkBuddy 主进程 + 托盘 + 子进程）。
**处理**：
1. 完全退出应用：关闭主窗口 + 右键托盘图标退出 + 任务管理器确认无残留进程
2. 仍失败则重启系统后再跑改名步骤（robocopy 复制结果已落盘，无需重做）
3. 实在无法停应用：放弃在线迁移，安排停机窗口

**真实案例**：WorkBuddy 数据目录迁移时，应用运行中改名失败，用户退出应用后一键脚本顺利完成。所以脚本设计为"复制可在线做，改名+建联接必须停应用"。

## 2. robocopy 不加 /XJ → 复制源里的 junction 造成循环
**现象**：复制卡住、无限递归、目标出现重复嵌套结构。
**根因**：源目录里含 junction/symlink（如某些缓存目录用链接组织），不加 `/XJ` 会跟随链接递归复制。
**处理**：robocopy 命令**必加 `/XJ`**，跳过所有 junction/symlink。

## 3. junction 建后再跑 robocopy → src 解析到 dst 自复制
**现象**：目标下出现 `dst\.workbuddy\.workbuddy` 嵌套子目录。
**根因**：junction 创建后，源路径 `C:\Users\foo\.workbuddy` 解析到 `F:\...\workbuddy`，此时再跑 `robocopy 源 目标` 等于 `robocopy 目标 目标`，robocopy 会在目标下再建一个同名子目录复制自身。
**处理**：
- **顺序铁律**：robocopy 全量复制必须在 junction 创建**之前**完成
- 验证阶段必查嵌套：`Test-Path "$TargetDir\$(Split-Path $TargetDir -Leaf)"`
- 若已发生嵌套：删除 junction → 删除嵌套子目录 → 从备份重新复制

## 4. 目标路径已存在非空目录 → 旧数据混入
**现象**：目标盘根目录已有其他内容（如工作区目录、知识库），直接 junction 会把迁移数据与旧数据混在同一层。
**根因**：把 `C:\...\.workbuddy` 直接指向 `F:\WorkBuddy`（根目录），而该根目录已有工作区/知识库子目录。
**处理**：用**子目录方案**——目标设为 `F:\WorkBuddy\.workbuddy`（迁移数据作为子目录，与现有内容平级共存），根目录保持干净。脚本会检测目标非空即拒绝。

## 5. PowerShell 工具禁用 cmd.exe
**现象**：在 WorkBuddy 的 PowerShell 工具里跑 `cmd /c mklink /J ...` 被安全策略拦截。
**处理**：改用原生 PowerShell：`New-Item -ItemType Junction -Path <link> -Target <target>`。效果等价，不需 cmd。

## 6. 含中文路径的 .ps1 脚本编码乱码
**现象**：脚本里的中文消息或硬编码中文路径变成乱码，文件名错乱。
**根因**：PowerShell 5.1 默认按系统 ANSI(GBK) 读无 BOM 的 .ps1，UTF-8 无 BOM 中文会乱码。
**处理**：
- 脚本内消息全用英文
- 路径通过**参数**传入（命令行参数按系统编码传递，字符串本身不乱码）
- 不在脚本里硬编码非 ASCII 路径
- 即：脚本文件本身放纯 ASCII 路径下，内容纯 ASCII，路径靠参数

## 7. 冒烟测试要点（迁移后必做）
| 测试项 | 命令 | 通过标准 |
|---|---|---|
| 联接类型 | `Get-Item <原路径>` | `LinkType: Junction` |
| 双向读关键文件 | 经原路径 + 经目标路径读 | 大小一致 |
| skills/配置/脚本目录 | `Get-ChildItem` | 可列出 |
| 运行时二进制 | 执行一次（如 python.exe -V） | 正常返回版本 |
| 自动化任务库 | 查 automation 列表 | 任务可读、状态 ACTIVE |
| 端到端代表性脚本 | 实发一封 smtp 邮件 | 发送成功 |

当前 WorkBuddy 会话本身就是最强冒烟证据：身份文件（SOUL.md/USER.md/IDENTITY.md）经原路径注入并成功加载，即说明 junction 对文件系统层透明。

## 8. 回滚
junction 异常时，零损失回滚：
1. `Remove-Item <原路径>`（删 junction 本身，不影响目标数据）
2. `Rename-Item "<原路径>_old" <原名>`（备份改回原名）
3. 数据回到迁移前状态
