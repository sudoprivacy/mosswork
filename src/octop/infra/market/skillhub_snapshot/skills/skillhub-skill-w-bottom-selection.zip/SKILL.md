---
name: skillhub-skill-w-bottom-selection
description: "双底(W底)形态选股工具。基于知乎《股票K线之双底形态》规则扫描 A 股,识别 W 底反转,输出「个股名 + 形态成立概率 + K 线图(副图 KDJ)」。触发词:双底 / W底 / W底选股 / 双底形态 / 底部反转 / KDJ双底 / 找双底股票。"
---

# 双底(W底)形态选股

按知乎 W 底文章规则扫 A 股日 K,给出**启发式置信度 0~100**,为候选生成 K 线图(蜡烛+MA+颈线/左右底标记 + 成交量副图 + **KDJ(9,3,3) 副图**)。

> ⚠️ "发生概率"是启发式评分,**非统计概率**。仅供研究,不构成投资建议。

## 激活
关键词:双底、W底、W底选股、双底形态、底部反转、KDJ双底、找双底。或用户给某股问"是不是双底"。

## 运行
`<PY>` = `C:\Users\Lenovo\.workbuddy\binaries\python\envs\default\Scripts\python.exe`(已装 pandas/numpy/matplotlib/mplfinance)。

```bash
# 全 A 扫描
<PY> scripts/scan.py --universe a-share --max 5300 --workers 12 --top 20 --out ./wbottom_out

# 指定代码 / 文件
<PY> scripts/scan.py --codes 600519,000001,300750 --top 10 --out ./out
<PY> scripts/scan.py --codes @watchlist.txt --out ./out

# 单只诊断
import sys;sys.path.insert(0,"scripts");import wbottom_core as wb
res,df=wb.analyze("600519",limit=320);wb.plot_chart(df,res,"600519","贵州茅台","c.png")
```

参数:`--universe a-share`(沪+深+创+科,4 节点按 100/页翻页取全量;`hs_a` 已被 Sina 映射为北交所,不用)| `--max N` | `--min-prob 60`(阈值) | `--top N` | `--workers`(默认 10,建议 8~16) | `--resume` | `--no-cache` | `--codes`。

## 输出 (`--out`)
- `report.md`:候选表(排名/名称/代码/置信度/当前价/分类/颈线)+ 形态要点。
- `report.html`:内嵌 K 线图的画廊。
- `chart_<代码>.png`:主图蜡烛+MA5/10/20+颈线(红虚线)+左底(橙▲)/右底(绿▲);副图成交量;副图 **KDJ(9,3,3)** 含 20/80 参考线。

呈现:先给排名表,再逐个 `chart_*.png` 卡片展示。

## 检测规则
先过 **3 项结构性硬性门控**(下跌末端 / 颈线突破前高 / 颈线清晰),再**细评分 ≥60** 才判 `found`。其余条件(两底相近、KDJ���跌、量能递增、临近颈线、站上60日线)为加权评分项。两底价差 >7% 在主循环直接淘汰。评分权重(满分100):两底相近10+颈线突破15+左底KDJ超跌15+量能递增15+突破颈线15+均线系统10+形成期≥1月5+右底强度5+颈线清晰5。标签:`强势W底·突破确认`(≥72且已突破+站上60线)/ `弱势W底·底背离`(右底<左底)/ `W底雏形·关注突破`(≥58)/ `形态不完整`。

## 数据源(免 key)
K 线 **5 源回退**:Sina `CN_MarketData.getKLineData` → 东财 `push2his` → 网易 `quotes.money.163.com/service/chddata.html` → 腾讯 `web.ifzq.gtimg.cn/appstuff/app/fqkline/get` → 百度 `finance.pae.baidu.com/selfselect/getstockquotation`。股票池:Sina `Market_Center.getHQNodeData` 四节点 `sh_a/sz_a/cyb/kcb`,100/页翻页(全 A ≈ 57 次请求),落 `universe_cache.json`。

⚠️ 限流:批量 50+ 易触发 456/502/403/断连,需停 15~60 分钟冷却;**别用 `except:pass` 吞错**(会误判为检测器问题)。

## 性能(已内置)
- 多线程并发(`--workers`)
- K 线磁盘缓存(`kline_cache/*.csv`)
- 数据源熔断(3 连败即本次停用)
- 断点续扫(`--resume`,跳过已分析)

正常网络 ~40~100 只/秒,全 A 约 2~3 分钟;命中缓存更快。

## 形态解读(作答参考)
三买点:①回踩前低(站上5日线+底部K线组合)→看至颈线;②**放量突破颈线**买入(最小理论涨幅=颈线-底);③突破后回踩颈线有支撑。止损:跌破颈线/突破2日内跌回须止损。KDJ:D<20超卖、金叉为左底信号;K>90/D>80超买。MACD 底背离=弱势不追。量能全程递增,否则易成矩形整理。

调参:`wbottom_core.py` 顶部 `DEFAULT_CFG`(`min_gap/max_gap` 两底间隔、`max_price_band` 两底价差、`min_prob` 阈值、`kdj` 默认 9,3,3、`max_recent` 右底最大距今天数)。