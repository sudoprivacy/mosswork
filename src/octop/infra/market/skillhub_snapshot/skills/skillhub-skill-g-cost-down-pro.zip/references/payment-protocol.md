# 支付宝付费改造协议对照表（PAYSKILL Protocol Mapping）

> 本技能已按支付宝官方 AI 按量付费（Machine Pay / A2M，基于 HTTP 402 Payment Required）完成付费改造。本文档说明平台检查项与本技能服务端实现的对应关系。

## 检查项对照

| 平台检查项 | 本技能实现 | 位置 |
|---|---|---|
| 402 账单下发 | 未付款请求付费资源时，服务端返回 HTTP 402 Payment Required + `Payment-Needed` 响应头（base64url 账单 JSON：out_trade_no / amount=2.99 / currency=CNY / resource_id / pay_before / seller_signature(RSA2) / seller_unique_id + method 层 seller_name / seller_id / seller_app_id / goods_name / service_id） | 服务端 `server.js` → `createPaymentRequiredResponse()` |
| 携带凭证重试 | 买家支付成功后，Agent 携带 `Payment-Proof` 头重试原资源请求；凭证结构 `{protocol:{payment_proof, trade_no}, method:{client_session}}`（base64url） | SKILL.md Step 3 · complete |
| 验付调用 | 服务端调用支付宝官方验付接口 `alipay.aipay.agent.payment.verify`，校验 active=true、金额一致、out_trade_no/resource_id 匹配、trade_no 未重复履约；不通过再次返回 402 | 服务端 `verifyPaymentAndDeliverResource()` |
| 履约确认 | 资源返回后服务端异步调用 `alipay.aipay.agent.fulfillment.confirm` 上报履约回执 | 服务端 `sendFulfillmentConfirm()` |
| 订单持久化与幂等 | 订单持久化存储（orders.json，含订单状态机 PENDING_PAYMENT → PAID → PENDING_CONFIRM → FULFILLED）；同一 Payment-Proof / trade_no 仅履约一次，重复请求返回缓存（`already_fulfilled: true`），不重复扣费、不重复交付 | 服务端 `orderRepository`（createPending / findByOutTradeNo / prepareFulfillment / markFulfilled） |

## 支付依赖

- 服务端：Node.js + `alipay-sdk`（网关验付、履约回执、RSA2 签名）
- 买方侧：支付宝官方 `alipay-payment-skill` / `alipay-bot` CLI（402-buyer-pay、402-query-payment-status、402-buyer-fulfillment-ack）

## 调用流程

```
Agent 请求付费资源（无 Payment-Proof）
  → 服务端 402 + Payment-Needed 账单
  → Agent 保存账单，alipay-bot 402-buyer-pay 拉起支付宝收银
  → 用户扫码/免密支付
  → Agent 查单（402-query-payment-status，success=true）
  → Agent 携带 Payment-Proof 重试资源请求
  → 服务端 alipay.aipay.agent.payment.verify 验付
  → 幂等履约（订单持久化，already_fulfilled 防重复）
  → 返回资源（Payment-Validation 头 + content 完整内容包）
  → 服务端 alipay.aipay.agent.fulfillment.confirm 履约确认
```

## 安全红线

- 应用私钥只存服务端（config.json / 环境变量），不写入技能包与日志
- 生产环境 service_id 使用 API_ 开头真实值（api_mock_service_id 仅沙箱）
- 不向用户暴露二维码原文、签名、密钥；支付链接由支付宝 CLI 原样透传
