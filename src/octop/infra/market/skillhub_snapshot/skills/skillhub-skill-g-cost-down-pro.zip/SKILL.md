---
name: skillhub-skill-g-cost-down-pro
description: "全面采购成本控制方法论完整版（源自机械工业出版社《全面采购成本控制》，赵平联合作者），已按支付宝 AI 按量付费（A2M）改造为 Pay Skill：402 账单下发 → 支付宝支付 → Payment-Proof 验付 → 履约确认，订单持久化与幂等。免费部分含 G-COST DOWN 总架构与决策规则；付费解锁 PPDAR 成本模型深度分册、十项全能与协同降本分册及三套实战模板。当用户提到\"降本\"\"成本控制\"\"报价分析\"\"成本模型\"\"should cost\"\"Cost Down\"时使用。"
---

# 全面采购成本控制 · G-COST DOWN（付费完整版）

> 本技能为 **PAYSKILL（支付宝 AI 按量付费改造技能）**：核心方法论免费内置；深度分册与实战模板通过支付宝按量付费解锁，**单次价格 ¥2.99**（与本技能发布定价一致，实际扣费以服务端返回的 402 + Payment-Needed 账单金额为准）。

## 支付宝付费改造契约（PAYSKILL）

本技能的付费资源由服务端（已按支付宝官方 A2M / Machine Pay 协议改造）统一托管，调用遵循 **probe → pay → complete → ack** 四步流程：

### 前置检查（发起请求前必做）

检查当前智能体工具列表中是否存在支付宝支付能力工具（`alipay-payment-skill` 官方支付处理技能，或 `alipay-bot` CLI 提供的工具，如 `402-buyer-pay`、`402-query-payment-status`）。
- 存在 → 继续下面的四步流程
- 不存在 → 终止付费流程并提示用户：WorkBuddy/QClaw 请升级至最新版；开放智能体请从 SkillHub 安装「支付宝 AI 付」官方 Skill（alipay-payment-skill）后重试

### Step 1 · probe（请求资源 / 402 账单下发）

1. 读取本技能目录下 `scripts/endpoint.txt` 中的付费资源 URL
2. 执行 `curl -s -i "<资源URL>"`
3. **服务端未收到有效付款时返回 HTTP 402 Payment Required，响应头携带 `Payment-Needed` 账单**（base64url 编码，含订单号 out_trade_no、金额 amount=2.99 CNY、resource_id、pay_before 过期时间、RSA2 商家签名 seller_signature）
4. 收到 402 即**暂停交付**，将 `Payment-Needed` 头的值完整原样保存到本地文件（如 `402_payment_needed.txt`，文件名只用字母/数字/连字符/下划线/点），同时记录资源 URL、方法（默认 GET）——**禁止在 buyer-pay 之前对同一 URL 发起额外请求**

### Step 2 · pay（推进支付）

1. 检查买家钱包：`alipay-bot check-wallet`（code=200 且 access_url 为空才放行；未授权/未开通 → 加载 alipay-authenticate-wallet 技能开通后重来）
2. 将保存的 Payment-Needed 账单传给支付宝官方支付能力拉起收银：
   `alipay-bot 402-buyer-pay -f <402账单文件> -r <资源URL>`
3. 原样透传 CLI 输出（含商品、金额、交易号 tradeNo、支付链接），由**用户本人扫码/免密完成付款**（Agent 只编排，不代付）
4. 输出后停止本轮，等待用户通知"已支付"

### Step 3 · complete（携带凭证重试 + 验付调用）

1. 用户表示已支付后，先查支付状态：`alipay-bot 402-query-payment-status -t <tradeNo> -r <资源URL>`（返回 success=true 才推进）
2. **携带 Payment-Proof（支付凭证）重试原资源请求**：再次 `curl -s -i -H "Payment-Proof: <平台下发的凭证>" <资源URL>`
3. 服务端收到 Payment-Proof 后调用支付宝官方验付接口 `alipay.aipay.agent.payment.verify` 核验凭证（校验 active=true、金额一致、订单号与 resource_id 匹配、订单未被重复履约）；无效/过期凭证会被再次拒绝并返回 402，**结果不明时不得要求用户重复付款**
4. 验付通过即返回资源（响应头含 `Payment-Validation`，响应体含 `already_fulfilled` 与完整 `content`）

### Step 4 · ack（履约确认）

1. 资源交付后由服务端异步调用支付宝履约回执接口 `alipay.aipay.agent.fulfillment.confirm` 上报完成（buy 侧如 CLI 要求，可执行 `alipay-bot 402-buyer-fulfillment-ack -t <tradeNo>`）
2. **订单持久化与幂等**：服务端将订单持久化存储（orders.json，升级路径为数据库唯一约束），同一 Payment-Proof / trade_no 只履约一次，重复请求返回缓存结果（`already_fulfilled: true`）——**不重复扣费、不重复交付**
3. 支付失败/查单失败 → 透传错误信息终止，禁止伪造支付成功

### 安全红线

- 应用私钥只存服务端（config.json / 环境变量注入），**禁止写入技能包、日志或公开仓库**
- 生产环境 service_id 必须为 API_ 开头真实值（api_mock_service_id 仅沙箱调试用）
- 全程不向用户暴露二维码原文、签名、密钥等中间过程；CLI 返回的支付链接原样透传，禁止改写截断

---

## 免费内置：总架构与决策规则

降本先问目的，再选手段——**G 是纲，COST 是手段，DOWN 是目的**。

**G（GOAL 目标）**：降本必须服务公司总目标，心中装着"三全降本"，装着顾客，不做牺牲质量、服务、客户的假降本。

**COST 四字母 = 降本四大手段**：

| 字母 | 手段 | 目的 | 核心内容 |
|---|---|---|---|
| C | 创建成本模型 | D 识别驱动因素 | 透视成本结构，运筹帷幄搭结构 |
| O | 挖掘降本机会 | O 优化成本空间 | 八大方法深度挖掘 |
| S | 提升降本技能 | W 唤醒管控潜能 | 十项全能全局优化 |
| T | 巧用创新技术 | N 引领协同降本 | VA/VE、标准化、供应链协同 |

**决策规则**：
1. 用户拿来的是价格/报价 → 先拆六大成本结构（直接材料/直接人工/制造费用/管理费用/销售费用/财务费用）→ 进入 C
2. 用户问"报价贵不贵" → 搭 should-cost 模型（PPDAR 五步法）→ 完成付费后进入深度分册
3. 用户要"降 X% 没头绪" → 八大方法逐项扫机会（见 references/eight-methods.md 免费样章）→ 进入 O
4. 商务手段榨干 → 十项全能 + VA/VE → 进入 S/T
5. 单点降不动 → ESI 供应商早期参与、伙伴供应商、数字化协同 → 进入 N
6. 警惕假降本：先问 TCO/LCC 降了没有

## ⭐ 付费解锁内容（¥2.99，5 个文件）

| 文件 | 内容 |
|---|---|
| cost-structure-and-model.md | 成本结构与成本模型深度分册：PPDAR 五步法实操要点 + 矿泉水瓶完整案例 + 模型管理 |
| ten-skills-and-collaboration.md | 十项全能技能盘点用法 + VA/VE 操作要领 + ESI/伙伴供应商协同判断规则 |
| ppdar-worksheet.md | PPDAR 成本模型工作底稿：5 张表格（产品拆解/工艺资源/数据收集/算法设定/结果分析），填表即建模 |
| cost-down-one-pager.md | 年度降本方案一页纸：目标→现状→机会扫描→项目清单→跟踪机制，直接向老板汇报 |
| eight-methods-checklist.md | 八大方法自检清单：方案前逐项打勾，防止只会砍价 |

支付成功后，服务端返回的 `content` 字段为完整内容包（markdown，5 个文件按分隔符拼接）。**将其原样保存为工作目录下的 `G-COST-DOWN-付费完整版.md`，并向用户交付文件路径与内容摘要**；资源响应体为空时禁止声称交付成功。

## 常见误区（免费部分）

- 把降本等同于砍价/最低价中标——高 KPI 压出来的降价牺牲质量、服务甚至客户
- 只让采购部门降本，不碰需求端（需求管理才是控制"没必要花的钱"）
- 只建模型不养数据——成本模型 = 数据 + 算法，双引擎缺一不可

## 版权与联系信息

**版权所有 © 2026 杭州九翮管理咨询有限公司**

- 作者：赵平（采购老嘎）
- 电话：18057106111
- 微信：zsgf1970
- 邮箱：418266915@qq.com
- 公众号：利倍增-采购老嘎
- 方法论来源：《全面采购成本控制》（宫迅伟、李斌、赵平 合著，机械工业出版社 2020 年出版，ISBN 978-7-111-64176-6，"SCAN 专业采购四大核心能力"系列教材之二）。
- 企业内训 / 成本模型搭建咨询，欢迎联系。
