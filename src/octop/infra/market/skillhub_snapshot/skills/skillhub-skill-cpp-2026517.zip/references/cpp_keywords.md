# C++ 关键字详解参考

按类别整理的C++关键字用法大全，用于代码分析时快速查阅。

---

## 一、基础类型与修饰符

### 数据类型关键字

| 关键字 | 含义 | 常见用法 |
|--------|------|----------|
| `int` | 整数类型 | `int age = 25;` |
| `float` | 单精度浮点数 | `float pi = 3.14f;` |
| `double` | 双精度浮点数 | `double e = 2.71828;` |
| `char` | 字符类型 | `char grade = 'A';` |
| `bool` | 布尔类型 | `bool isActive = true;` |
| `void` | 空类型 | `void function();` |

### 类型修饰符

| 关键字 | 作用 | 示例 |
|--------|------|------|
| `signed` | 有符号（默认） | `signed int x = -5;` |
| `unsigned` | 无符号（只能表示非负数） | `unsigned int x = 100;` |
| `short` | 短整型（通常16位） | `short int x;` |
| `long` | 长整型（通常32/64位） | `long long x;` |
| `const` | 常量（不可修改） | `const int MAX = 100;` |
| `constexpr` | 编译时常量 | `constexpr int SIZE = 10;` |

### 类型修饰符详解

#### `const` 关键字

```cpp
const int MAX_SIZE = 100;      // 编译时常量
const double PI = 3.14159;

void print(const std::string& s) {  // 参数常量：防止修改
    // s = "new";  // 错误！不能修改
    std::cout << s << std::endl;
}

class Widget {
public:
    int getValue() const { return value; }  // 常量成员函数
private:
    int value;
};
```

#### `constexpr` 关键字（C++11）

```cpp
constexpr int factorial(int n) {  // 编译时计算
    return n <= 1 ? 1 : n * factorial(n - 1);
}

int arr[factorial(5)];  // 合法！数组大小在编译时确定
```

---

## 二、控制流语句

### 条件判断

#### `if` / `else`

```cpp
if (condition) {
    // 条件为真时执行
} else if (another_condition) {
    // 另一个条件为真时执行
} else {
    // 所有条件都不满足时执行
}

// 三元运算符简写
int max = (a > b) ? a : b;
```

#### `switch`

```cpp
switch (value) {
    case 1:
        // value == 1 时执行
        break;        // 重要！不加break会继续执行后续case
    case 2:
    case 3:          // 多个case可以合并
        // value == 2 或 3 时执行
        break;
    default:
        // 所有case都不匹配时执行
        break;
}
```

### 循环结构

#### `for`

```cpp
// 传统for循环
for (int i = 0; i < 10; i++) {
    std::cout << i << std::endl;
}

// 范围for循环（C++11）
std::vector<int> nums = {1, 2, 3, 4, 5};
for (int n : nums) {
    std::cout << n << " ";
}
```

#### `while` / `do-while`

```cpp
while (condition) {
    // 条件为真时循环，先判断后执行
}

// 先执行后判断，至少执行一次
do {
    std::cout << "至少执行一次" << std::endl;
} while (condition);
```

#### 循环控制

```cpp
for (int i = 0; i < 100; i++) {
    if (i == 50) {
        break;    // 跳出整个循环
    }
    if (i % 2 == 0) {
        continue;  // 跳过本次循环，继续下一次
    }
    std::cout << i << std::endl;
}
```

---

## 三、函数与参数

### 函数定义与调用

```cpp
// 基本函数
return_type function_name(parameters) {
    // 函数体
}

// 声明与定义分离
void greet();                    // 声明
void greet() {                   // 定义
    std::cout << "Hello!" << std::endl;
}
```

### 参数传递方式

| 传递方式 | 语法 | 效果 |
|----------|------|------|
| 值传递 | `void f(int x)` | 复制一份，实参不变 |
| 指针传递 | `void f(int* p)` | 可以修改实参，需判空 |
| 引用传递 | `void f(int& r)` | 直接操作实参，效率高 |
| const引用 | `void f(const int& r)` | 只读不修改，效率高 |

```cpp
void byValue(int x) { x = 100; }           // 不影响实参
void byPointer(int* p) { *p = 100; }       // 可以修改实参
void byReference(int& r) { r = 100; }       // 直接修改实参
void byConstRef(const std::string& s) {}   // 高效只读

int main() {
    int a = 10;
    byValue(a);      // a 仍是 10
    byPointer(&a);   // a 变为 100
    byReference(a);  // a 变为 100
}
```

### 特殊函数关键字

#### `inline`

```cpp
// 内联函数：建议编译器在调用处展开代码
inline int add(int a, int b) {
    return a + b;
}

// 适用于短小、频繁调用的函数
// 注意：inline只是建议，编译器可能忽略
```

#### `static`（函数内）

```cpp
void counter() {
    static int count = 0;  // 只初始化一次，值保持
    count++;
    std::cout << count << std::endl;
}

int main() {
    counter();  // 输出 1
    counter();  // 输出 2
    counter();  // 输出 3
}
```

#### `extern`

```cpp
// extern.cpp
int global_var = 42;

// main.cpp
extern int global_var;  // 声明外部变量
std::cout << global_var << std::endl;  // 输出 42
```

---

## 四、面向对象关键字

### 类与对象

#### `class` vs `struct`

```cpp
// class：默认private
class Circle {
    double radius;  // 私有成员
public:
    double getArea() { return 3.14159 * radius * radius; }
};

// struct：默认public
struct Point {
    double x;  // 公有成员
    double y;
};
```

#### 访问控制

| 关键字 | 访问权限 | 用途 |
|--------|----------|------|
| `public` | 任意代码可访问 | 接口函数 |
| `protected` | 本类和派生类可访问 | 基类受保护成员 |
| `private` | 仅本类可访问 | 实现细节 |

### 构造函数与析构函数

```cpp
class Widget {
private:
    int* data;
    int size;

public:
    // 默认构造函数
    Widget() : data(nullptr), size(0) {}

    // 参数构造函数
    Widget(int s) : size(s), data(new int[s]) {}

    // 拷贝构造函数
    Widget(const Widget& other) : size(other.size), data(new int[other.size]) {
        std::copy(other.data, other.data + size, data);
    }

    // 移动构造函数（C++11）
    Widget(Widget&& other) noexcept : data(other.data), size(other.size) {
        other.data = nullptr;
        other.size = 0;
    }

    // 析构函数
    ~Widget() {
        delete[] data;
    }
};
```

### 运算符重载

```cpp
class Vector {
public:
    int x, y;

    Vector(int x, int y) : x(x), y(y) {}

    // 重载 +
    Vector operator+(const Vector& other) const {
        return Vector(x + other.x, y + other.y);
    }

    // 重载 <<
    friend std::ostream& operator<<(std::ostream& os, const Vector& v) {
        return os << "(" << v.x << ", " << v.y << ")";
    }
};
```

### 继承

```cpp
// 基类
class Animal {
protected:
    std::string name;
public:
    Animal(const std::string& n) : name(n) {}
    virtual void speak() { std::cout << "..." << std::endl; }
    virtual ~Animal() {}  // 虚析构函数
};

// 派生类
class Dog : public Animal {
public:
    Dog(const std::string& n) : Animal(n) {}

    // 重写基类函数
    void speak() override { std::cout << "汪汪！" << std::endl; }
};

// 多态调用
Animal* animal = new Dog("旺财");
animal->speak();  // 输出"汪汪！"
delete animal;
```

### `virtual` 与 `override`

| 关键字 | 作用 |
|--------|------|
| `virtual` | 声明虚函数，支持运行时多态 |
| `override`（C++11） | 明确表示重写基类函数，编译器检查 |
| `final`（C++11） | 禁止继续重写或继承 |

```cpp
class Base {
public:
    virtual void foo() {}
    virtual void bar() {}
};

class Derived : public Base {
public:
    void foo() override {}  // 正确重写
    void baz() override {} // 错误！基类没有baz()
};
```

### `static`（类中）

```cpp
class Counter {
private:
    static int count;  // 静态成员：所有对象共享
public:
    Counter() { count++; }

    static int getCount() {  // 静态成员函数
        return count;
    }
};

int Counter::count = 0;  // 必须类外定义并初始化

Counter a, b, c;
Counter::getCount();  // 返回 3
```

---

## 五、模板与泛型

### 函数模板

```cpp
// T为模板参数，由编译器根据实参推断
template <typename T>
T max(T a, T b) {
    return (a > b) ? a : b;
}

// 显式指定模板参数
int a = max<int>(1, 2);
double b = max(1.5, 2.5);  // 编译器推断为double
```

### 类模板

```cpp
template <typename T>
class Stack {
private:
    std::vector<T> data;
public:
    void push(const T& item) { data.push_back(item); }
    T pop() {
        T top = data.back();
        data.pop_back();
        return top;
    }
};

Stack<int> intStack;      // 整数栈
Stack<std::string> strStack;  // 字符串栈
```

### 模板特化

```cpp
// 全特化
template <>
class Widget<std::string> {
    // 针对string的专门实现
};

// 偏特化
template <typename T>
class Widget<T*> {  // 针对指针类型的偏特化
    // 针对指针的专门实现
};
```

---

## 六、内存管理

### `new` 与 `delete`

```cpp
// 动态分配
int* p = new int;          // 分配一个int
int* arr = new int[10];    // 分配int数组

// 动态分配并初始化（C++11）
int* p = new int(42);                  // *p = 42
int* arr = new int[5]{1, 2, 3, 4, 5};  // 列表初始化

// 释放
delete p;      // 释放单个对象
delete[] arr;  // 释放数组（必须配对）
```

### 智能指针（C++11）

| 类型 | 用途 | 特点 |
|------|------|------|
| `std::unique_ptr` | 独占所有权 | 不可拷贝，作用域结束时自动释放 |
| `std::shared_ptr` | 共享所有权 | 引用计数，最后一个销毁时释放 |
| `std::weak_ptr` | 弱引用 | 不增加引用计数，避免循环引用 |

```cpp
#include <memory>

// unique_ptr：独占所有权的最佳选择
std::unique_ptr<int> p1 = std::make_unique<int>(42);
// std::unique_ptr<int> p2 = p1;  // 错误！不能拷贝
std::unique_ptr<int> p3 = std::move(p1);  // 可以转移所有权

// shared_ptr：共享所有权
std::shared_ptr<int> s1 = std::make_shared<int>(42);
std::shared_ptr<int> s2 = s1;  // 引用计数+1

// weak_ptr：打破循环引用
std::weak_ptr<int> w = s1;
if (auto p = w.lock()) {  // 检查对象是否还存在
    // 使用p
}
```

### `malloc` / `free`（不推荐）

```cpp
// C风格的内存分配，不推荐在C++中使用
int* p = (int*)malloc(sizeof(int));
free(p);

// 与new/delete混用会导致未定义行为！
```

---

## 七、异常处理

### `try` / `catch` / `throw`

```cpp
#include <stdexcept>

// 抛出异常
double divide(double a, double b) {
    if (b == 0) {
        throw std::invalid_argument("除数不能为零");
    }
    return a / b;
}

// 捕获异常
try {
    double result = divide(10, 0);
} catch (const std::invalid_argument& e) {
    std::cerr << "错误：" << e.what() << std::endl;
} catch (const std::exception& e) {
    std::cerr << "未知错误：" << e.what() << std::endl;
} catch (...) {
    std::cerr << "未知异常！" << std::endl;
}
```

### noexcept（C++11）

```cpp
// 声明函数不会抛出异常
void doSomething() noexcept {
    // 如果这里抛出异常，会调用std::terminate()
}

// noexcept运算符
template <typename T>
void moveIfNoexcept(T& dest, T& src) noexcept(std::is_nothrow_move_constructible<T>::value) {
    dest = std::move(src);
}
```

---

## 八、C++11/14/17/20 新特性关键字

### `auto`（C++11）

```cpp
// 自动类型推断
auto i = 42;           // int
auto d = 3.14;         // double
auto s = "hello";      // const char*

// 简化长类型名
std::map<std::string, std::vector<int>>::iterator it = m.begin();
// 变为
auto it = m.begin();
```

### `decltype`（C++11）

```cpp
int x = 5;
decltype(x) y = 10;  // y的类型是int

// 用于泛型编程
template <typename T, typename U>
auto add(T t, U u) -> decltype(t + u) {
    return t + u;
}
```

### `nullptr`（C++11）

```cpp
// 代替NULL，解决NULL可能被定义为0的问题
int* p = nullptr;
void* v = nullptr;
bool b = nullptr;  // false
```

### `default` 与 `delete`（C++11）

```cpp
class Widget {
public:
    // 要求编译器生成默认构造函数
    Widget() = default;

    // 禁止拷贝
    Widget(const Widget&) = delete;
    Widget& operator=(const Widget&) = delete;
};
```

### `using` 别名声明（C++11）

```cpp
// 代替typedef
using Int = int;
using FuncPtr = int(*)(int, int);

// 模板别名（typedef做不到）
template <typename T>
using Vec = std::vector<T>;
Vec<int> v;  // std::vector<int>
```

### `final` 与 `override`（C++11）

```cpp
class Base {
    virtual void foo() {}
    virtual void bar() {}
    void baz() {}
};

class Derived : public Base {
    void foo() override {}  // 正确重写
    void bar() final {}     // 禁止继续重写
    void baz() override {}  // 错误！baz不是虚函数
};

class FinalClass final {};  // 禁止继承
```

### `[[nodiscard]]`（C++17）

```cpp
// 提示编译器警告未使用的返回值
[[nodiscard]] int* allocate() {
    return new int[100];
}

void test() {
    allocate();  // 编译器可能警告
}
```

### `[[maybe_unused]]`（C++17）

```cpp
void process(int x, [[maybe_unused]] int y) {
    // y可能不使用，编译器不警告
}
```

### `co_await`（C++20）

```cpp
#include <coroutine>

// 协程支持（需要编译器支持）
task<int> async_operation() {
    co_await std::suspend_always{};
    co_return 42;
}
```

---

## 九、其他重要关键字

### `typedef`

```cpp
// 为类型创建别名（已被using取代）
typedef unsigned int uint;
typedef void (*Callback)(int, int);
```

### `using`

```cpp
// 类型别名
using String = std::string;

// 命名空间别名
namespace fs = std::filesystem;

// 函数指针类型
using Comparator = bool(*)(int, int);
```

### `namespace`

```cpp
namespace MyLib {
    void foo();
    class Bar {};
}

// 使用
MyLib::foo();
using namespace MyLib;  // 引入整个命名空间（慎用）
```

### `typeid` 与 `type_info`

```cpp
#include <typeinfo>

Base* p = new Derived();
if (typeid(*p) == typeid(Derived)) {
    // p实际指向Derived对象
}
```

### `explicit`

```cpp
class Fraction {
public:
    explicit Fraction(int num, int denom = 1) : numerator(num), denominator(denom) {}
};

// 禁止隐式转换
Fraction f1(5);    // 合法
// Fraction f2 = 5;  // 错误！explicit禁止隐式转换
```

### `friend`

```cpp
class Node {
    friend class Tree;  // Tree可以访问Node的private成员
    friend void display(const Node& n);  // 函数可以访问private成员
private:
    int value;
};
```

### `register`（C++17废弃）

```cpp
// 建议将变量存储在寄存器中，现代编译器会自动优化
// C++17已废弃，不应使用
```

---

## 十、预处理指令（#开头，不算关键字但常用）

| 指令 | 用途 |
|------|------|
| `#include` | 包含头文件 |
| `#define` | 定义宏 |
| `#if/#endif` | 条件编译 |
| `#ifdef` | 宏是否定义 |
| `#pragma` | 编译器特定指令 |

```cpp
// 防止头文件重复包含
#pragma once
// 或
#ifndef HEADER_H
#define HEADER_H
// ...
#endif

// 条件编译
#ifdef DEBUG
    std::cout << "调试信息" << std::endl;
#else
    std::cout << "发布版本" << std::endl;
#endif
```
