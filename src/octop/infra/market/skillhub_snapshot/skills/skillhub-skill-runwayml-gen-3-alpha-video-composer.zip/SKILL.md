---
name: skillhub-skill-runwayml-gen-3-alpha-video-composer
description: "使用 RunwayML Gen-3 Alpha API 生成 AI 视频片段，支持文本到视频和图像到视频模式。通过 FFmpeg 管理生成任务、轮询和输出拼接。"
---

# RunwayML Gen-3 Alpha 视频合成器

Composes AI-generated video clips using the RunwayML Gen-3 Alpha API with text-to-video and image-to-video modes. Manages generation tasks, polling, and output stitching via FFmpeg.

## Installation

No source-backed install or usage instructions could be extracted automatically. Review the upstream project before running this skill in a sensitive workflow.

- Source: https://github.com/1991513ccie-png/skills
