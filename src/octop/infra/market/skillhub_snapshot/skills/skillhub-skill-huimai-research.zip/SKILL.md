---
name: skillhub-skill-huimai-research
description: "免费使用，针对任意行业、领域或圈子输出一份结构化的入门调研报告，覆盖术语、生态、规则、风险、信源、趋势六个维度，交付结构化 Markdown 报告与自包含可视化页面。触发词：「调研XX行业」「看懂XX圈子」「XX领域入门」「XX行业地图」「解码XX行业」。不适用于：只查单个术语定义，或要求具体投资、医疗、法律建议。"
---

# 汇麦行业调研 · 免费版

把「某个行业/圈子看不懂」变成一份能直接读的入门调研报告。业务由服务方（上海一粒麦籽信息有限责任公司）
的免费服务执行，**客户端不本地执行本技能**。

- 服务内容：**一份行业调研报告及原定底稿**
- 价格：**免费，全程无任何支付环节**
- 服务端点：`https://pay.huimaiglobal.com/v1/skills/invoke`

## 何时使用

- 用户想快速摸清一个陌生行业、领域或圈子，需要一份成体系的入门材料。
- 用户明确提出「调研」「看懂」「行业地图」「入门」「解码」这类诉求。

不适用：只查单个术语定义；用户要的是投资、医疗、法律等专业建议；已有材料只需要改写润色。

## 前置检查：当前智能体是否支持微信 AI 支付

发起请求前，先检查你的可用工具列表中是否存在名称包含 `weixinpay_` 的工具
（如 `mcp__weixinpay__weixinpay_register`，工具名带前缀也算；存在**任意一个**即视为支持）。

只以你的工具列表为证据，本文档中提到的工具名不算；无法确认时按「不支持」处理。

- 支持：继续本技能后续流程（本技能免费，不发起任何支付操作）。
- 不支持：终止流程且不要发起请求。只向用户说明结论与解决办法（无需解释你如何检查、不要出现具体工具名），按智能体类型提示：
  - 合作智能体（如 WorkBuddy）：请升级智能体到最新版本后重试。
  - 开放智能体（如 OpenClaw / DeepSeek Harness）：请根据 https://skillhub.cn/install/skillhub.md 安装 @tencent-adm/weixinpay-installer。
  - 无法判断类型：请升级智能体或安装微信支付 AI 支付插件后重试。

## 输入契约

`input` 必须是一个 JSON 对象，字段如下（与线上服务端一致，请勿自造字段名）：

| 字段 | 类型 | 必填 | 说明 |
|-|-|-|-|
| `topic` | string | ✅ | 调研主题，越具体越好（如「社区精品咖啡店」） |
| `audience` | string | | 目标读者，默认「行业新人」 |
| `constraints` | string[] | | 额外限制项，如篇幅偏好、必须覆盖的问题 |
| `tier` | string | | `standard`（默认）或 `deep` |

示例：

```json
{
  "topic": "社区精品咖啡店",
  "audience": "准备入行的店主",
  "constraints": ["重点讲清成本结构", "给出可核查的数据口径"],
  "tier": "standard"
}
```

## 交付物

| 产物 | 说明 |
|-|-|
| `REPORT.md` | 调研报告正文，**不少于 3000 个中文字符**，含 YAML front matter |
| `调研报告.html` | 自包含可视化页面（样式内联，可直接打开） |

未达字数下限时服务端拒绝渲染与交付，不会用占位内容补足。

## 调用流程（必须严格遵守）

> 免费技能无需支付：**直接发起请求 → 服务端处理（若返回 202 则按 `retry_after` 轮询）→ 返回 200 交付产物**。
> 直接按下面的 HTTP 请求调用即可；`scripts/paid_client.py` 仅供开发排障时做连通性自测，**不是调用主路径**。

1. **前置检查**：按上面「前置检查」确认支付环境，不支持则停止。

2. **首次请求**：

   ```http
   POST https://pay.huimaiglobal.com/v1/skills/invoke
   Content-Type: application/json
   Idempotency-Key: <32 位随机十六进制，建议每个任务一把>

   {
  "skill_id": "huimai-research",
  "input": {
    "topic": "社区精品咖啡店",
    "audience": "准备入行的店主",
    "constraints": [
      "重点讲清成本结构",
      "给出可核查的数据口径"
    ],
    "tier": "standard"
  }
}
   ```

   服务端直接开始处理，返回 **HTTP 202**（生产中）或 **HTTP 200**（已完成）。

   > **本技能免费，服务端不返回 402**，以下为协议契约结构参考，运行时不触发：
   > ```json
   > {
   >   "code": "PAYMENT_REQUIRED",
   >   "WeixinPay": { "WeixinPay-Required": "<payment-code-仅供契约结构参考>" },
   >   "out_trade_no": "<order-number>",
   >   "amount": "0.00",
   >   "currency": "CNY"
   > }
   > ```

3. **发起支付（本技能不触发）**：本技能免费，服务端不返回 402，**不得调用 `weixinpay_pay`**。若意外收到 402，视为服务端异常，向用户说明后立即**终止流程**，不传递 `WeixinPay-Required` 值，不发起任何支付操作。

4. **获取资源**：若收到 202，读取 `retry_after` 秒数后用**与第一次完全相同的 body** 重新 POST 同一端点，直到返回 200：

   ```http
   POST https://pay.huimaiglobal.com/v1/skills/invoke
   Content-Type: application/json
   Idempotency-Key: <与首次请求相同>
   X-Out-Trade-No: （本技能免费，此 header 不携带）
   WeixinPay-Required: （本技能免费，此 header 不携带）

   {
  "skill_id": "huimai-research",
  "input": {
    "topic": "社区精品咖啡店",
    "audience": "准备入行的店主",
    "constraints": [
      "重点讲清成本结构",
      "给出可核查的数据口径"
    ],
    "tier": "standard"
  }
}
   ```

5. **处理 `processing`（HTTP 202）**：服务端仍在生产。读取响应里的 `retry_after` 秒数，**用同一请求重发**直到 `200`。

6. **处理 NOT_PAID（本技能不触发）**：本技能免费，不存在 `NOT_PAID` 状态，无需携带 `X-Out-Trade-No` 重发。若意外收到此响应视为服务端异常，向用户说明后**终止流程**，不重新下单、不换新订单。

7. **处理服务失败结果（HTTP 200）**：本技能免费、不涉及任何扣款。若 `code` 为 `REFUNDED` 或 `FULFILL_AND_REFUND_FAILED`，均表示服务方无法交付本次内容，用户没有任何款项损失；向用户说明情况后**终止流程**，不重试。

8. **成功后交付**：按 `content.deliverables[]` 下载 `url`，核对 `name`/`bytes`/`sha256` 后把成品交付给用户。

## 边界

- 客户端不得索取供应商密钥或服务端实现细节。
- 请求参数不可在中途变更；换内容必须重新发起请求。
- 服务端报错时停止，不要自动重试换参数。
- 服务端返回 **403 / 409 / 410**（凭据不符 / 请求与订单不匹配 / 订单已失效）或 **503**（服务不可用）时，停止并保留原请求信息，不要自动换单重发。
- 服务方无法交付时会以 `code: "REFUNDED"` 或 `FULFILL_AND_REFUND_FAILED` 回告（本技能免费，用户无任何款项损失），客户端据此向用户说明并终止流程即可。
