#!/usr/bin/env python3
"""端点连通性自测脚本（仅开发排障用，不参与实际业务流程）。

本技能为免费技能（amount_fen=0），服务端不返回 402，无支付环节；
结构上保留 402 分支仅为与 SkillPay 协议契约对齐，运行时不会触发。
调用主路径是 SKILL.md 里给出的直接 HTTP POST；本脚本只做两件事：
验证端点可达、验证响应的字段形状是否符合契约。

用法：
    python3 scripts/paid_client.py --input input.json --state .state/task-001.json
重试同一任务时沿用同一个 --state 文件与同一份 input（body 必须保持不变）。
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import uuid

ENDPOINT = "https://pay.huimaiglobal.com/v1/skills/invoke"
SKILL_ID = "huimai-research"
AMOUNT_FEN = 0


class ProtocolError(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ProtocolError("拒绝重定向：请核对服务地址")


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def check_url(url, mock=False):
    parsed = urllib.parse.urlparse(url)
    if parsed.username or parsed.password or parsed.fragment or not parsed.hostname:
        raise ProtocolError("服务地址无效")
    local = parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "::1")
    if parsed.scheme != "https" and not (mock and local):
        raise ProtocolError("生产请求必须使用 HTTPS；模拟测试仅允许回环 HTTP")


def exchange(state, mock=False):
    check_url(state["url"], mock)
    headers = {"Content-Type": "application/json", "Idempotency-Key": state["request_id"]}
    request = urllib.request.Request(state["url"], data=state["body"].encode(), headers=headers, method="POST")
    try:
        response = urllib.request.build_opener(NoRedirect).open(request, timeout=30)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        raw = response.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024:
            raise ProtocolError("响应过大；业务产物应通过独立文件交付")
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError):
            raise ProtocolError("服务端未返回 JSON") from None
        if not isinstance(data, dict):
            raise ProtocolError("响应必须是 JSON 对象")
        return response.status, dict(response.headers), data


def advance(config, payload, state_path, mock=False):
    url = config.get("endpoint", "")
    check_url(url, mock)
    body = json.dumps({"skill_id": config["skill_id"], "input": payload},
                      ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(body.encode()).hexdigest()
    state_path = Path(state_path)
    state_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = Path(str(state_path) + ".lock")
    try:
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        raise ProtocolError("该会话正在执行；若进程异常退出，核对原订单后再清理锁") from None
    os.close(fd)
    try:
        if state_path.exists():
            state = json.loads(state_path.read_text())
            if state["digest"] != digest or state["url"] != url or state["amount_fen"] != config["amount_fen"]:
                raise ProtocolError("请求、地址或价格已变更；禁止复用旧订单")
            if state.get("status") in ("complete", "failed"):
                return state["result"]
        else:
            state = {"request_id": uuid.uuid4().hex, "url": url, "body": body, "digest": digest,
                     "amount_fen": config["amount_fen"], "status": "created"}
            save(state_path, state)
        status, headers, data = exchange(state, mock)
        headers = {k.lower(): v for k, v in headers.items()}
        # 免费技能不走 402 路径；保留分支仅为与 SkillPay 协议契约结构对齐，运行时不触发
        if status == 402:
            # 本技能免费（amount_fen=0），服务端不应返回 402；意外收到视为服务端异常
            raise ProtocolError("免费技能收到意外的 402 响应；终止流程，不发起任何支付操作")
        if status == 202:
            # 首次收到 202 时从响应体读取 order（免费技能不走 402，此处首次建立 order 绑定）
            order = data.get("out_trade_no") or state.get("order")
            if not isinstance(order, str) or not order:
                raise ProtocolError("202 响应缺少 out_trade_no")
            retry_after = data.get("retry_after")
            if type(retry_after) is not int or retry_after <= 0:
                retry_after = 20
            retry_after = min(retry_after, 300)
            state.update(order=order, status="processing")
            save(state_path, state)
            return {"status": "processing", "out_trade_no": order, "retry_after": retry_after,
                    "next": "服务端正在生产：等待 %d 秒后原样重跑本命令，直到返回 200。" % retry_after}
        if status != 200:
            raise ProtocolError("服务返回 HTTP %s；保留会话并核对原任务，不自动重新发起" % status)
        # 200：从响应体或已有 state 读取 order
        order = data.get("out_trade_no") or state.get("order")
        if not isinstance(order, str) or not order:
            raise ProtocolError("成功响应缺少 out_trade_no")
        if state.get("order") and state["order"] != order:
            raise ProtocolError("成功响应的 out_trade_no 与已记录的任务不一致")
        if data.get("code") in ("REFUNDED", "FULFILL_AND_REFUND_FAILED"):
            state.update(order=order, status="failed", result=data)
            save(state_path, state)
            return data
        if data.get("code") != "SUCCESS" or not data.get("content"):
            raise ProtocolError("成功响应缺少成功状态或业务产物")
        state.update(order=order, status="complete", result=data)
        save(state_path, state)
        return data
    finally:
        lock.unlink()


def main():
    parser = argparse.ArgumentParser(description="端点连通性自测；调用主路径见 SKILL.md")
    parser.add_argument("--input", required=True, help="业务输入 JSON；远端不可读取本机路径")
    parser.add_argument("--state", required=True, help="每个任务一个私有状态文件；重试沿用")
    parser.add_argument("--endpoint", default=ENDPOINT)
    parser.add_argument("--amount-fen", type=int, default=AMOUNT_FEN)
    parser.add_argument("--mock", action="store_true", help="仅用于本地回环模拟")
    args = parser.parse_args()
    config = {"endpoint": args.endpoint, "skill_id": SKILL_ID, "amount_fen": args.amount_fen}
    try:
        payload = json.loads(Path(args.input).read_text())
        if not isinstance(payload, dict):
            raise ProtocolError("业务输入必须是 JSON 对象")
        print(json.dumps(advance(config, payload, args.state, args.mock), ensure_ascii=False, indent=2))
    except (ProtocolError, OSError, ValueError) as exc:
        raise SystemExit(str(exc))


if __name__ == "__main__":
    main()
