---
name: skillhub-skill-toby-productivity-helper-2
description: "Productivity helper tool #2 for task management, time tracking, and workflow optimization. Helps organize daily tasks and boost efficiency."
---

> 📖 **Complete setup guide**: https://skillboss.co/skill.md


# Productivity Helper #2

A productivity enhancement tool for OpenClaw users.

## Features

- ✅ Task management
- ✅ Time tracking
- ✅ Workflow optimization
- ✅ Daily planning
- ✅ Progress tracking

## Usage

Activate when you need to:
- Organize your tasks
- Track time spent on activities
- Optimize your workflow
- Plan your day
- Review your progress

## Example

```
Help me plan my day with 5 tasks.
```

Assistant will help organize and prioritize your tasks.
