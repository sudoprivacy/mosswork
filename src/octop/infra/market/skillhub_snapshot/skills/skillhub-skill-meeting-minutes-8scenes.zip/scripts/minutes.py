# -*- coding: utf-8 -*-
"""分场景会议纪要生成器 —— 8 类会议，各自产出真正不同的交付物。

核心判断：只有"交付物不同"的场景才值得单独做。若两个场景产出的东西一样，
那只是参数差异，不该拆成两个技能。

用法：
  python minutes.py --list
  python minutes.py --scenario client_visit --data spec.json --out 客户拜访纪要.docx
"""
import argparse
import json
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from report_kit import Report
except ImportError as e:
    raise SystemExit("[依赖缺失] %s\n修复命令：\n"
                     '  "C:/Users/ghszb/.workbuddy/binaries/python/envs/default/Scripts/python.exe"'
                     " -m pip install python-docx" % e)

SCENARIOS = {
    "client_visit": ("客户拜访 / 商务洽谈", "跟进邮件 + 承诺追踪表"),
    "escalate":     ("向上汇报", "一页纸（结论先行）+ 请示事项"),
    "brainstorm":   ("头脑风暴 / 创意会", "点子清单 + 收敛矩阵 + 归属人"),
    "decision":     ("决策评审会", "决策记录 ADR（含反对意见与复盘时点）"),
    "weekly":       ("项目周会 / 例会", "待办清单 + 上期承诺五态回顾"),
    "retro":        ("复盘会", "复盘报告（做对/做错/下次怎么做）"),
    "interview":    ("需求调研 / 用户访谈", "需求池 + 用户原话引述"),
    "cross_team":   ("跨部门协调会", "RACI 责任矩阵 + 依赖项清单"),
}


def _base(d):
    return Report(
        title=d.get("title") or "%s 会议纪要" % SCENARIOS.get(d.get("scenario"), ("", ""))[0],
        subtitle=d.get("subtitle"),
        confidential=d.get("confidential", "内部资料"),
        footer=d.get("footer", ""),
        cover=bool(d.get("cover", False)),
    )


def _meta(r, d):
    rows = [["会议时间", d.get("time", "")], ["会议地点", d.get("place", "")],
            ["参会人员", d.get("attendees", "")], ["记录人", d.get("recorder", "")]]
    rows = [[k, v] for k, v in rows if v]
    if rows:
        r.table(["项目", "内容"], rows, widths=[3.6, 11.6], first_col_bold=True)


# ------------------------------------------------------------ 1. 客户拜访
def build_client_visit(r, d):
    r.summary(d.get("summary") or ["一句话：这次会谈拿到的最小承诺是什么"])
    _meta(r, d)
    r.h1("一、对方参会人与角色")
    r.table(["姓名", "职务", "角色", "关注点 / 雷区"],
            [list(x) for x in (d.get("people") or [])], widths=[2.6, 3.4, 3.0, 6.2])
    r.h1("二、客户现状与真实诉求")
    r.bullets(d.get("needs") or [])
    r.h1("三、我方承诺（离会议室即生效）")
    r.actions([list(x) for x in (d.get("commitments") or [])])
    r.h1("四、客户承诺（需对方兑现的）")
    r.actions([list(x) for x in (d.get("client_commitments") or [])])
    r.h1("五、跟进邮件（可直接发送）")
    r.para(d.get("followup_mail") or "（待生成）", size=10.5)
    if d.get("next_step"):
        r.callout("下一步", d["next_step"])
    return r


# ------------------------------------------------------------ 2. 向上汇报
def build_escalate(r, d):
    r.summary(d.get("summary") or ["结论 / 现状 / 请求决策"])
    _meta(r, d)
    r.h1("一、结论先行")
    r.para(d.get("conclusion") or "")
    r.h1("二、依据（不超过 3 条）")
    r.numbered(d.get("evidence") or [])
    r.h1("三、需要您决策的事项")
    r.table(["事项", "建议方案", "备选方案", "不决策的后果"],
            [list(x) for x in (d.get("decisions") or [])], widths=[3.4, 4.2, 4.2, 3.4])
    r.h1("四、资源请求")
    r.bullets(d.get("resources") or [])
    if d.get("deadline"):
        r.callout("时限", "请于 %s 前答复，否则将影响 %s。" % (d["deadline"], d.get("impact", "后续节点")))
    return r


# ------------------------------------------------------------ 3. 头脑风暴
def build_brainstorm(r, d):
    r.summary(d.get("summary") or ["本次产出 N 个点子，收敛出 M 个进入验证"])
    _meta(r, d)
    r.h1("一、点子清单（不评判，先穷尽）")
    r.table(["#", "点子", "提出人"], [[i, x[0] if isinstance(x, (list, tuple)) else x,
                                      x[1] if isinstance(x, (list, tuple)) and len(x) > 1 else ""]
                                     for i, x in enumerate(d.get("ideas") or [], 1)],
            widths=[1.2, 11.0, 3.0])
    r.h1("二、收敛矩阵（影响力 × 可行性）")
    r.table(["点子", "影响力", "可行性", "结论"],
            [list(x) for x in (d.get("matrix") or [])], widths=[6.4, 2.6, 2.6, 3.6])
    r.h1("三、进入验证的举措")
    r.actions([list(x) for x in (d.get("actions") or [])])
    r.h1("四、暂缓与淘汰（写明理由，避免反复讨论）")
    r.table(["点子", "结论", "理由"], [list(x) for x in (d.get("parked") or [])],
            widths=[5.4, 2.6, 7.2])
    return r


# ------------------------------------------------------------ 4. 决策评审会
def build_decision(r, d):
    r.summary(d.get("summary") or ["决策内容 / 关键依据 / 复盘时点"])
    _meta(r, d)
    r.h1("一、决策事项")
    r.para(d.get("topic") or "")
    r.h1("二、备选方案与评估")
    r.table(["方案", "优势", "劣势", "成本", "结论"],
            [list(x) for x in (d.get("options") or [])], widths=[3.0, 3.4, 3.4, 2.4, 3.0])
    r.h1("三、最终决策")
    r.para(d.get("decision") or "")
    r.h1("四、决策依据")
    r.numbered(d.get("rationale") or [])
    r.h1("五、反对意见（必须记录，否则复盘无从谈起）")
    r.bullets(d.get("dissent") or ["（无）"])
    r.h1("六、执行与复盘")
    r.actions([list(x) for x in (d.get("actions") or [])])
    if d.get("review_date"):
        r.callout("复盘时点", "%s 复盘本决策；若届时结果未达预期，触发重新评估。" % d["review_date"])
    return r


# -------------------------------------------------------------- 5. 项目周会
def build_weekly(r, d):
    r.summary(d.get("summary") or ["上期承诺完成情况 / 本期风险 / 下期承诺"])
    _meta(r, d)
    r.h1("一、上期承诺回顾（五态：完成/进行中/受阻/延期/取消）")
    r.table(["承诺事项", "责任人", "上期状态", "本期状态"],
            [list(x) for x in (d.get("last_commitments") or [])],
            widths=[6.4, 2.6, 2.8, 3.4])
    r.h1("二、本期进展")
    r.bullets(d.get("progress") or [])
    r.h1("三、风险与阻塞（需升级的标红）")
    r.table(["风险 / 阻塞", "影响", "需要的支持", "是否升级"],
            [list(x) for x in (d.get("risks") or [])], widths=[5.0, 3.0, 4.0, 3.2])
    r.h1("四、下期承诺")
    r.actions([list(x) for x in (d.get("next_commitments") or [])])
    return r


# ---------------------------------------------------------------- 6. 复盘会
def build_retro(r, d):
    r.summary(d.get("summary") or ["做对了什么 / 做错了什么 / 下次怎么改"])
    _meta(r, d)
    r.h1("一、目标与结果对照")
    r.table(["目标", "实际结果", "偏差"], [list(x) for x in (d.get("goals") or [])],
            widths=[6.0, 5.0, 4.2])
    r.h1("二、做对了（继续保持）")
    r.bullets(d.get("keep") or [])
    r.h1("三、做错了（停止做）")
    r.bullets(d.get("stop") or [])
    r.h1("四、根因分析（连问五个为什么）")
    r.numbered(d.get("root_cause") or [])
    r.h1("五、下次怎么做（必须可执行）")
    r.actions([list(x) for x in (d.get("actions") or [])])
    return r


# ------------------------------------------------------- 7. 需求调研 / 访谈
def build_interview(r, d):
    r.summary(d.get("summary") or ["受访对象 / 核心发现 / 需求条目数"])
    _meta(r, d)
    r.h1("一、受访对象画像")
    r.table(["项目", "内容"], [list(x) for x in (d.get("profile") or [])],
            widths=[3.6, 11.6], first_col_bold=True)
    r.h1("二、用户原话（一字不改，加引号）")
    for q in (d.get("quotes") or []):
        r.para("“%s”" % q, size=10.5, indent=0.6)
    r.h1("三、需求池")
    r.table(["需求", "频次", "强度", "归类", "优先级"],
            [list(x) for x in (d.get("needs") or [])], widths=[5.4, 2.0, 2.0, 3.0, 2.8])
    r.h1("四、意外发现")
    r.bullets(d.get("surprises") or [])
    return r


# ------------------------------------------------------------ 8. 跨部门协调
def build_cross_team(r, d):
    r.summary(d.get("summary") or ["目标 / 责任划分 / 关键依赖项"])
    _meta(r, d)
    r.h1("一、共同目标")
    r.para(d.get("goal") or "")
    r.h1("二、RACI 责任矩阵")
    r.table(["事项", "负责 R", "批准 A", "咨询 C", "知会 I"],
            [list(x) for x in (d.get("raci") or [])], widths=[6.0, 2.6, 2.6, 2.0, 2.0])
    r.h1("三、依赖项与接口")
    r.table(["依赖项", "依赖方", "交付时点", "延误影响"],
            [list(x) for x in (d.get("dependencies") or [])], widths=[4.6, 3.0, 3.2, 4.4])
    r.h1("四、争议与决议")
    r.bullets(d.get("resolutions") or [])
    r.h1("五、行动项")
    r.actions([list(x) for x in (d.get("actions") or [])])
    return r


BUILDERS = {
    "client_visit": build_client_visit, "escalate": build_escalate,
    "brainstorm": build_brainstorm, "decision": build_decision,
    "weekly": build_weekly, "retro": build_retro,
    "interview": build_interview, "cross_team": build_cross_team,
}


def main():
    ap = argparse.ArgumentParser(description="分场景会议纪要生成器")
    ap.add_argument("--scenario", help="会议场景")
    ap.add_argument("--data", help="JSON 文件路径或 JSON 字符串")
    ap.add_argument("--out", help="输出 docx 路径")
    ap.add_argument("--list", action="store_true", help="列出全部场景")
    a = ap.parse_args()

    if a.list:
        print("可用场景 %d 类：\n" % len(SCENARIOS))
        for k, (name, deliverable) in SCENARIOS.items():
            print("  %-14s %-16s → %s" % (k, name, deliverable))
        return

    if not a.data or not a.scenario:
        ap.error("需要 --scenario 与 --data")
    if a.scenario not in BUILDERS:
        raise SystemExit("[错误] 未知场景 %r。可用：%s" % (a.scenario, "、".join(BUILDERS)))

    raw = open(a.data, encoding="utf-8").read() if os.path.isfile(a.data) else a.data
    try:
        d = json.loads(raw)
    except Exception as e:
        raise SystemExit("[错误] JSON 解析失败：%s" % e)
    d["scenario"] = a.scenario

    r = _base(d)
    BUILDERS[a.scenario](r, d)
    if d.get("sign"):
        r.sign(d["sign"])
    out = a.out or ("%s_%s.docx" % (a.scenario, datetime.now().strftime("%Y%m%d")))
    print("[生成] %s" % r.save(out))


if __name__ == "__main__":
    main()
