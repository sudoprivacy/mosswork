# -*- coding: utf-8 -*-
"""录音转写稿质检引擎 —— 出交付物之前，先把原文洗干净。

检查四类问题：
  1. 错别字 / 易混词（同音、近形、商务场景高频误用）
  2. 专业术语（疑似误用 + 未登记术语待确认）
  3. 口语冗余（填充词、重复、指代不明）
  4. 数字与单位（ASR 常见数字错、单位不统一、日期格式混乱）

用法：
  python textqc.py --transcript raw.txt                    # 输出质检报告（Markdown）
  python textqc.py --transcript raw.txt --json             # 输出 JSON
  python textqc.py --transcript raw.txt --clean clean.txt  # 同时输出清洗稿
"""
import argparse
import json
import os
import re
import sys

# ---------------------------------------------------------------- 1. 易错词表
# 格式：(错误写法, 正确写法, 说明)
TYPO = [
    ("帐户", "账户", "「账」用于金钱往来"),
    ("帐号", "账号", "「账」用于金钱往来"),
    ("登陆", "登录", "登录=进入系统；登陆=军队上岸"),
    ("签定", "签订", "合同用「签订」或「签署」"),
    ("定金", "订金", "⚠法律含义不同：定金有担保性质，可适用定金罚则；订金无"),
    ("权力", "权利", "权利=依法享有的利益；权力=支配力量"),
    ("反应", "反映", "反映情况；化学反应"),
    ("考查", "考察", "考察=实地观察调查；考查=用标准检查衡量"),
    ("启用", "起用", "启用=开始使用物；起用=重新任用/提拔人"),
    ("制定", "制订", "制定=定出并确定（法规/政策）；制订=创制拟定（草案）"),
    ("截止", "截至", "截至=到…为止（后接时间点）；截止=到期停止"),
    ("牟利", "毛利", "毛利=营业收入减成本；牟利=谋取私利"),
    ("营销额", "营业额", "营销是动作，营收是金额"),
    ("营利", "盈利", "营利=谋求利润（非贬义）；盈利=获得利润"),
    ("赢利", "盈利", "统一用「盈利」"),
    ("渡过", "度过", "度过时间；渡过大河/难关"),
    ("不止", "不只", "不只=不但；不止=不停/超出"),
    ("启示", "启事", "启事=公开声明（寻物/招聘）；启示=启发"),
    ("委屈求全", "委曲求全", "成语固定写法"),
    ("人情事故", "人情世故", "成语固定写法"),
    ("一如继往", "一如既往", "成语固定写法"),
    ("迫不急待", "迫不及待", "成语固定写法"),
    ("谈笑风声", "谈笑风生", "成语固定写法"),
    ("走头无路", "走投无路", "成语固定写法"),
    ("再接再励", "再接再厉", "成语固定写法"),
    ("默守成规", "墨守成规", "成语固定写法"),
    ("好高鹜远", "好高骛远", "成语固定写法"),
    ("趋之若骛", "趋之若鹜", "成语固定写法"),
    ("不落巢臼", "不落窠臼", "成语固定写法"),
    ("按步就班", "按部就班", "成语固定写法"),
    ("不径而走", "不胫而走", "成语固定写法"),
    ("甘败下风", "甘拜下风", "成语固定写法"),
    ("自抱自弃", "自暴自弃", "成语固定写法"),
    ("一愁莫展", "一筹莫展", "成语固定写法"),
    ("穿流不息", "川流不息", "成语固定写法"),
    ("一股作气", "一鼓作气", "成语固定写法"),
    ("悬梁刺骨", "悬梁刺股", "成语固定写法"),
    ("食不裹腹", "食不果腹", "成语固定写法"),
    ("迫在眉捷", "迫在眉睫", "成语固定写法"),
    ("世外桃园", "世外桃源", "成语固定写法"),
    ("鼎立相助", "鼎力相助", "成语固定写法"),
    ("松驰", "松弛", "「弛」从弓"),
    ("精萃", "精粹", "「粹」从米"),
    ("幅射", "辐射", "「辐」从车"),
    ("气慨", "气概", "「概」从木"),
    ("粗旷", "粗犷", "「犷」从犬"),
    ("凑和", "凑合", "「合」"),
    ("既使", "即使", "「即」"),
    ("即然", "既然", "「既」"),
    ("峻工", "竣工", "「竣」从立"),
    ("打腊", "打蜡", "「蜡」从虫"),
    ("了望", "瞭望", "「瞭」从目"),
    ("杀戳", "杀戮", "「戮」从戈"),
    ("痉孪", "痉挛", "「挛」从手"),
    ("罗唆", "啰嗦", "「啰」从口"),
    ("沉缅", "沉湎", "「湎」从水"),
    ("修茸", "修葺", "「葺」从艸"),
    ("亲睐", "青睐", "「睐」从目"),
    ("发韧", "发轫", "「轫」从车"),
    ("欣尝", "欣赏", "「赏」"),
    ("追朔", "追溯", "「溯」从水"),
    ("迁徒", "迁徙", "「徙」从彳"),
    ("渲泄", "宣泄", "「宣」"),
    ("寒喧", "寒暄", "「暄」从日"),
    ("弦律", "旋律", "「旋」"),
    ("膺品", "赝品", "「赝」从贝"),
    ("脏款", "赃款", "「赃」从贝"),
    ("醮水", "蘸水", "「蘸」从艸"),
    ("蜇伏", "蛰伏", "「蛰」从虫"),
    ("装祯", "装帧", "「帧」从巾"),
    ("坐阵", "坐镇", "「镇」从金"),
]

# ------------------------------------------------------- 2. 咨询/商业术语表
TERMS = {
    "毛利": "营业收入 − 营业成本",
    "净利": "扣除全部成本费用税费后的利润",
    "毛利率": "毛利 / 营业收入",
    "EBITDA": "息税折旧摊销前利润",
    "ROI": "投资回报率",
    "IRR": "内部收益率",
    "NPV": "净现值",
    "回本周期": "投资额 / 年净现金流",
    "现金流": "企业实际收到的现金与流出的现金",
    "BCG矩阵": "波士顿矩阵，按市场增长率与相对份额划分业务",
    "波特五力": "供应商/买方/潜在进入者/替代品/现有竞争者",
    "SWOT": "优势/劣势/机会/威胁",
    "MECE": "相互独立、完全穷尽",
    "RACI": "负责R/批准A/咨询C/知会I",
    "SKU": "最小库存单位",
    "客单价": "平均每位客户的消费金额",
    "复购率": "再次购买的客户占比",
    "转化率": "完成目标动作的人数 / 触达人数",
    "获客成本": "CAC，获取一个客户的总成本",
    "客户生命周期价值": "LTV",
    "市盈率": "P/E，股价 / 每股收益",
    "市占率": "市场份额",
    "同比": "与去年同期相比",
    "环比": "与上一周期相比",
    "库存周转天数": "平均库存 / 日均销货成本",
    "应收账款周转天数": "DSO",
    "法定代表人": "⚠代表企业行使职权的负责人，不等同于「法人」（法人是组织不是人）",
    "尽调": "尽职调查",
    "对赌": "估值调整机制",
    "VIE": "可变利益实体",
    "OKR": "目标与关键成果",
    "KPI": "关键绩效指标",
    "SOP": "标准作业流程",
}

# 法律/金融强提示词：出现即需人工复核
RISK_TERMS = ["法人", "定金", "订金", "对赌", "担保", "无限连带", "竞业限制", "对赌协议"]

# ---------------------------------------------------------- 3. 口语填充词
FILLERS = ["那个", "这个", "就是说", "然后", "嗯", "啊", "对吧", "是吧", "反正",
           "基本上", "其实", "好像", "就是", "怎么说呢", "你懂我意思", "换言之",
           "总而言之", "某种程度上", "我个人觉得", "怎么说", "对对对", "行行行"]

# 指代不明
VAGUE = ["这个事", "那件事", "这个东西", "那边", "那个人", "他们那个", "这块的",
         "一些问题", "相关的", "等等之类的", "各种"]


def check_typo(text):
    out = []
    for wrong, right, note in TYPO:
        n = text.count(wrong)
        if n:
            for m in re.finditer(re.escape(wrong), text):
                s = max(0, m.start() - 12)
                out.append({"type": "错别字", "severity": "高",
                            "found": wrong, "suggest": right, "note": note,
                            "context": text[s:m.end() + 12].replace("\n", " ")})
    return out


def check_terms(text):
    out = []
    for t, meaning in TERMS.items():
        if t in text:
            out.append({"type": "术语", "severity": "提示", "found": t,
                        "suggest": "确认用法", "note": meaning, "context": ""})
    for t in RISK_TERMS:
        if t in text:
            out.append({"type": "术语", "severity": "高", "found": t,
                        "suggest": "人工复核", "note": "法律/金融敏感词，含义易被误用，需与对方确认后写入",
                        "context": ""})
    return out


def check_verbal(text):
    out = []
    for w in FILLERS:
        n = text.count(w)
        if n >= 3:
            out.append({"type": "口语冗余", "severity": "低", "found": w,
                        "suggest": "成稿时删除", "note": "出现 %d 次，口语填充词，正式纪要中应删除" % n,
                        "context": ""})
    for w in VAGUE:
        n = text.count(w)
        if n >= 2:
            out.append({"type": "口语冗余", "severity": "中", "found": w,
                        "suggest": "替换为具体指代", "note": "出现 %d 次，指代不明，纪要中必须写清具体对象" % n,
                        "context": ""})
    return out


def check_numbers(text):
    out = []
    # 中文数字与阿拉伯数字混用
    cn_num = re.findall(r"[一二三四五六七八九十百千万亿]+(?:元|万|亿|个|人|天|月|年|%)", text)
    ar_num = re.findall(r"\d+(?:\.\d+)?(?:元|万|亿|个|人|天|月|年|%)", text)
    if cn_num and ar_num:
        out.append({"type": "数字规范", "severity": "中", "found": "中阿混用",
                    "suggest": "统一用阿拉伯数字",
                    "note": "中文数字：%s；阿拉伯数字：%s" % ("、".join(cn_num[:5]), "、".join(ar_num[:5])),
                    "context": ""})
    # 单位不统一（万/亿混用）
    if "万" in text and "亿" in text:
        out.append({"type": "数字规范", "severity": "低", "found": "万/亿混用",
                    "suggest": "统一单位", "note": "同一份纪要建议统一到「万」或「亿」，避免换算出错",
                    "context": ""})
    # 疑似 ASR 数字错误：口语化的大数
    for m in re.finditer(r"(\d+)\s*(万|亿|千|百)", text):
        v, u = int(m.group(1)), m.group(2)
        if u == "万" and v > 100000:
            out.append({"type": "数字规范", "severity": "高", "found": m.group(0),
                        "suggest": "复核原文", "note": "数值异常大，疑似转写错误或多写了位数", "context": ""})
    # 日期格式
    for m in re.finditer(r"\d{1,2}\s*月\s*\d{1,2}\s*[号日]", text):
        pass
    if re.search(r"\d{4}年", text) and re.search(r"\d{1,2}/\d{1,2}", text):
        out.append({"type": "数字规范", "severity": "低", "found": "日期格式不统一",
                    "suggest": "统一为 YYYY-MM-DD", "note": "存在「年月日」与「斜杠」两种写法",
                    "context": ""})
    return out


def clean_text(text, issues):
    """按高严重度的错别字做保守自动修正，口语填充词不自动删（避免误伤）。"""
    out = text
    for i in issues:
        if i["type"] == "错别字" and i["severity"] == "高":
            out = out.replace(i["found"], i["suggest"])
    return out


def run(text):
    issues = []
    issues += check_typo(text)
    issues += check_terms(text)
    issues += check_verbal(text)
    issues += check_numbers(text)
    order = {"高": 0, "中": 1, "低": 2, "提示": 3}
    issues.sort(key=lambda x: (order.get(x["severity"], 9), x["type"]))
    return issues


def to_markdown(issues, text):
    L = ["# 转写稿质检报告", ""]
    L.append("- 原文长度：%d 字" % len(text))
    L.append("- 发现问题：**%d** 项" % len(issues))
    hi = [i for i in issues if i["severity"] == "高"]
    if hi:
        L.append("")
        L.append("> ⚠ **%d 项高危问题必须处理**：%s"
                 % (len(hi), "、".join(sorted({i["found"] for i in hi})[:10])))
    L.append("")
    L.append("| 严重度 | 类型 | 发现 | 建议 | 说明 |")
    L.append("|---|---|---|---|---|")
    for i in issues:
        L.append("| %s | %s | `%s` | %s | %s |"
                 % (i["severity"], i["type"], i["found"], i["suggest"],
                    i["note"].replace("|", "/")))
    L.append("")
    L.append("## 使用建议")
    L.append("")
    L.append("1. **高**：直接影响结论正确性，必须逐条与参会人确认后再写入纪要。")
    L.append("2. **中**：影响专业性，成稿前应修正。")
    L.append("3. **低/提示**：格式与冗余问题，成稿时清理即可。")
    L.append("4. 质检只做**提示**，最终以参会人确认的口径为准——不要替用户做实质性改写。")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="录音转写稿质检")
    ap.add_argument("--transcript", required=True, help="转写稿 txt 路径")
    ap.add_argument("--clean", help="输出清洗后文本的路径")
    ap.add_argument("--report", help="质检报告输出路径（默认打印到屏幕）")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    a = ap.parse_args()

    if not os.path.isfile(a.transcript):
        raise SystemExit("[错误] 文件不存在：%s" % a.transcript)
    text = open(a.transcript, encoding="utf-8").read()
    issues = run(text)

    if a.json:
        payload = json.dumps({"length": len(text), "issues": issues},
                             ensure_ascii=False, indent=1)
        if a.report:
            open(a.report, "w", encoding="utf-8").write(payload)
            print("[生成] %s" % os.path.abspath(a.report))
        else:
            print(payload)
    else:
        md = to_markdown(issues, text)
        if a.report:
            open(a.report, "w", encoding="utf-8").write(md)
            print("[生成] %s" % os.path.abspath(a.report))
        else:
            print(md)

    if a.clean:
        open(a.clean, "w", encoding="utf-8").write(clean_text(text, issues))
        print("[生成] %s" % os.path.abspath(a.clean))


if __name__ == "__main__":
    main()
