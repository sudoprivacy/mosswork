# -*- coding: utf-8 -*-
"""承诺 / 行动项跟踪台账 —— 让纪要里的承诺不再是"写完即忘"。

设计要点：
  * 台账是一个 JSON 文件，跨会议累积，可反复追加与更新
  * 六态流转：未开始 → 进行中 → 已完成 / 受阻 / 延期 / 已取消
  * 自动判逾期：有截止日 + 未闭环 + 已过期 → 标「逾期」
  * 输出 Markdown（屏幕/文件）与 docx（归档/发人）

用法：
  python tracker.py --add spec.json --ledger ledger.json   # 追加本次会议的承诺
  python tracker.py --set A003 --status 已完成 --note "已交付" --ledger ledger.json
  python tracker.py --report --ledger ledger.json --docx 跟踪表.docx
  python tracker.py --report --ledger ledger.json --only-open
"""
import argparse
import json
import os
import sys
from datetime import datetime, date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from report_kit import Report
except ImportError as e:
    raise SystemExit("[依赖缺失] %s\n修复命令：\n"
                     '  "C:/Users/ghszb/.workbuddy/binaries/python/envs/default/Scripts/python.exe"'
                     " -m pip install python-docx" % e)

STATUS = ["未开始", "进行中", "已完成", "受阻", "延期", "已取消"]
CLOSED = ("已完成", "已取消")
TODAY = date.today().isoformat()


# ------------------------------------------------------------------ 台账读写
def load(path):
    if not path or not os.path.isfile(path):
        return {"version": 1, "meetings": [], "items": []}
    try:
        d = json.loads(open(path, encoding="utf-8").read())
    except Exception as e:
        raise SystemExit("[错误] 台账解析失败 %s：%s" % (path, e))
    d.setdefault("meetings", [])
    d.setdefault("items", [])
    return d


def save(path, d):
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    open(path, "w", encoding="utf-8").write(
        json.dumps(d, ensure_ascii=False, indent=1))
    return os.path.abspath(path)


def next_id(prefix, used):
    n = 1
    while "%s%03d" % (prefix, n) in used:
        n += 1
    return "%s%03d" % (prefix, n)


def is_overdue(it):
    if it.get("status") in CLOSED:
        return False
    due = (it.get("due") or "").strip()
    if not due:
        return False
    try:
        return datetime.strptime(due, "%Y-%m-%d").date() < date.today()
    except ValueError:
        return False


def days_left(it):
    due = (it.get("due") or "").strip()
    if not due:
        return ""
    try:
        return (datetime.strptime(due, "%Y-%m-%d").date() - date.today()).days
    except ValueError:
        return ""


# -------------------------------------------------------------------- 动作
def cmd_add(d, spec):
    """spec: {meeting, date, scenario, items:[[事项,责任人,截止], ...] 或 [dict]}"""
    used_m = {m["id"] for m in d["meetings"]}
    mid = next_id("M", used_m)
    d["meetings"].append({
        "id": mid,
        "name": spec.get("meeting") or spec.get("title") or "未命名会议",
        "date": spec.get("date") or TODAY,
        "scenario": spec.get("scenario") or "",
    })
    used_a = {i["id"] for i in d["items"]}
    added, skipped = 0, 0
    for x in spec.get("items") or []:
        if isinstance(x, dict):
            action = x.get("action") or x.get("事项") or ""
            owner = x.get("owner") or x.get("责任人") or ""
            due = x.get("due") or x.get("截止") or ""
            note = x.get("note") or x.get("备注") or ""
        elif isinstance(x, (list, tuple)):
            action, owner, due = (list(x) + ["", "", ""])[:3]
            note = x[3] if len(x) > 3 else ""
        else:
            action, owner, due, note = str(x), "", "", ""
        action = (action or "").strip()
        if not action:
            continue
        dup = [i for i in d["items"]
               if i["action"] == action and i["owner"] == (owner or "")]
        if dup:
            skipped += 1
            continue
        aid = next_id("A", used_a)
        used_a.add(aid)
        d["items"].append({"id": aid, "meeting": mid, "action": action,
                           "owner": owner or "", "due": due or "",
                           "status": "未开始", "updated": TODAY, "note": note})
        added += 1
    return mid, added, skipped


def cmd_set(d, ids, status=None, note=None, due=None):
    hit = []
    for it in d["items"]:
        if it["id"] in ids:
            if status:
                it["status"] = status
            if due:
                it["due"] = due
            if note is not None:
                it["note"] = note
            it["updated"] = TODAY
            hit.append(it["id"])
    return hit


# -------------------------------------------------------------------- 输出
def stats(d):
    s = {k: 0 for k in STATUS}
    for it in d["items"]:
        s[it.get("status", "未开始")] = s.get(it.get("status", "未开始"), 0) + 1
    total = len(d["items"])
    done = s.get("已完成", 0)
    overdue = [i for i in d["items"] if is_overdue(i)]
    s["总计"] = total
    s["完成率"] = ("%.0f%%" % (done * 100.0 / total)) if total else "—"
    s["逾期"] = len(overdue)
    return s, overdue


def to_markdown(d, only_open=False):
    items = d["items"]
    if only_open:
        items = [i for i in items if i.get("status") not in CLOSED]
    mname = {m["id"]: "%s（%s）" % (m["name"], m.get("date", ""))
             for m in d["meetings"]}
    s, overdue = stats(d)
    L = ["# 承诺与行动项跟踪表", "",
         "- 更新时点：%s" % datetime.now().strftime("%Y-%m-%d %H:%M"),
         "- 会议数：%d ｜ 事项总数：%d ｜ 已完成：%d ｜ 完成率：%s ｜ **逾期：%d**"
         % (len(d["meetings"]), s["总计"], s.get("已完成", 0),
            s["完成率"], s["逾期"]),
         ""]
    if overdue:
        L.append("> ⚠ **逾期未闭环 %d 项**：%s"
                 % (len(overdue),
                    "、".join("%s %s" % (i["id"], i["action"][:18]) for i in overdue[:8])))
        L.append("")
    L.append("| ID | 来源会议 | 事项 | 责任人 | 截止 | 状态 | 更新 | 备注 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for i in items:
        dl = days_left(i)
        due = i.get("due") or "—"
        if is_overdue(i):
            due = "%s ⚠逾期%d天" % (due, abs(dl))
        elif dl != "" and i.get("status") not in CLOSED and 0 <= dl <= 3:
            due = "%s（剩%d天）" % (due, dl)
        L.append("| %s | %s | %s | %s | %s | %s | %s | %s |"
                 % (i["id"], mname.get(i.get("meeting"), i.get("meeting", "")),
                    i["action"].replace("|", "/"), i.get("owner") or "—",
                    due, i.get("status", "未开始"), i.get("updated", ""),
                    (i.get("note") or "—").replace("|", "/")))
    L.append("")
    L.append("## 状态说明")
    L.append("")
    L.append("`未开始` → `进行中` → 闭环于 `已完成`；异常走 `受阻`（卡住需支援）/ `延期`（改期需新截止日）/ `已取消`。")
    L.append("")
    L.append("**铁律**：改状态为「延期」必须同时给新截止日，否则等于把承诺悄悄作废。")
    return "\n".join(L)


def to_docx(d, out, title=None, only_open=False):
    items = d["items"]
    if only_open:
        items = [i for i in items if i.get("status") not in CLOSED]
    mname = {m["id"]: m["name"] for m in d["meetings"]}
    s, overdue = stats(d)

    r = Report(title=title or "承诺与行动项跟踪表",
               subtitle="更新时点 %s" % datetime.now().strftime("%Y-%m-%d %H:%M"),
               confidential="内部资料", cover=False)
    r.summary([
        "事项总数 %d ｜ 已完成 %d ｜ 进行中 %d ｜ 受阻 %d ｜ 延期 %d"
        % (s["总计"], s.get("已完成", 0), s.get("进行中", 0),
           s.get("受阻", 0), s.get("延期", 0)),
        "完成率 %s ｜ 逾期未闭环 %d 项" % (s["完成率"], s["逾期"]),
    ])
    if overdue:
        r.callout("逾期预警",
                  "以下事项已过截止日仍未闭环：%s。请责任人在下次会议前更新状态或申请延期。"
                  % "；".join("%s（%s，%s）" % (i["action"], i.get("owner") or "未指派",
                                          i.get("due")) for i in overdue[:10]))
    r.h1("一、跟踪明细")
    rows = []
    for i in items:
        dl = days_left(i)
        due = i.get("due") or "—"
        if is_overdue(i):
            due = "%s（逾期%d天）" % (due, abs(dl))
        rows.append([i["id"], mname.get(i.get("meeting"), ""), i["action"],
                     i.get("owner") or "—", due, i.get("status", "未开始"),
                     (i.get("note") or "—")])
    r.table(["ID", "来源会议", "事项", "责任人", "截止", "状态", "备注"],
            rows, widths=[1.4, 3.0, 5.2, 2.0, 2.6, 1.8, 3.2])
    r.h1("二、状态分布")
    r.table(["状态", "数量"],
            [[k, s.get(k, 0)] for k in STATUS] + [["总计", s["总计"]],
                                                  ["逾期", s["逾期"]]],
            widths=[6.0, 3.0])
    r.h1("三、使用规则")
    r.bullets([
        "每次会议结束后 24 小时内，把会议纪要里的承诺与行动项追加进本台账。",
        "下次会议开场第一件事：过一遍上期未闭环事项，逐条更新状态。",
        "状态改为「延期」必须同时写入新的截止日期，否则视为承诺作废并需重新决策。",
        "连续两次会议仍为「受阻」的事项，必须升级——要么换人，要么换资源，要么砍掉。",
        "台账只记录事实与状态，不替责任人解释原因；原因写在备注栏。",
    ])
    return r.save(out)


# -------------------------------------------------------------------- CLI
def main():
    ap = argparse.ArgumentParser(description="承诺 / 行动项跟踪台账")
    ap.add_argument("--ledger", default="commitments.json", help="台账 JSON 路径")
    ap.add_argument("--add", help="追加：spec.json 路径或 JSON 字符串")
    ap.add_argument("--set", help="更新：事项 ID，多个用逗号分隔")
    ap.add_argument("--status", help="配合 --set 的状态")
    ap.add_argument("--note", help="配合 --set 的备注")
    ap.add_argument("--due", help="配合 --set 的新截止日 YYYY-MM-DD")
    ap.add_argument("--report", action="store_true", help="输出跟踪表")
    ap.add_argument("--out", help="Markdown 输出路径")
    ap.add_argument("--docx", help="docx 输出路径")
    ap.add_argument("--only-open", action="store_true", help="只看未闭环")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    a = ap.parse_args()

    d = load(a.ledger)

    if a.add:
        raw = open(a.add, encoding="utf-8").read() if os.path.isfile(a.add) else a.add
        try:
            spec = json.loads(raw)
        except Exception as e:
            raise SystemExit("[错误] JSON 解析失败：%s" % e)
        mid, added, skipped = cmd_add(d, spec)
        save(a.ledger, d)
        print("[追加] 会议 %s：新增 %d 项，跳过重复 %d 项 → %s"
              % (mid, added, skipped, os.path.abspath(a.ledger)))

    if a.set:
        ids = [x.strip() for x in a.set.split(",") if x.strip()]
        if a.status and a.status not in STATUS:
            raise SystemExit("[错误] 状态必须是：%s" % "、".join(STATUS))
        hit = cmd_set(d, ids, a.status, a.note, a.due)
        miss = [i for i in ids if i not in hit]
        save(a.ledger, d)
        print("[更新] 命中 %d 项：%s" % (len(hit), "、".join(hit) or "无"))
        if miss:
            print("[警告] 未找到 ID：%s" % "、".join(miss))
        if a.status == "延期" and not a.due:
            print("[警告] 延期未给新截止日 —— 按铁律应同时写入 --due")

    if a.report:
        if a.json:
            print(json.dumps(d, ensure_ascii=False, indent=1))
        md = to_markdown(d, a.only_open)
        if a.out:
            open(a.out, "w", encoding="utf-8").write(md)
            print("[生成] %s" % os.path.abspath(a.out))
        else:
            print(md)
        if a.docx:
            print("[生成] %s" % to_docx(d, a.docx, only_open=a.only_open))

    if not (a.add or a.set or a.report):
        ap.print_help()


if __name__ == "__main__":
    main()
