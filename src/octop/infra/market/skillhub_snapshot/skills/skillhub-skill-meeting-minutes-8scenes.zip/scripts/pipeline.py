# -*- coding: utf-8 -*-
"""会议纪要一键流水线：录音转写稿 → 质检 → 分场景纪要 docx → 承诺跟踪表。

这是本技能的**默认入口**。单独调 minutes.py 只出纪要，调本脚本出完整交付包。

  python pipeline.py --template client_visit                 # 打印数据骨架
  python pipeline.py --transcript raw.txt \
                     --scenario client_visit --data spec.json \
                     --out-dir ./交付包

产出（在 --out-dir 下）：
  01_转写稿质检报告.md     高/中/低问题清单，高危必须人工确认
  02_清洗稿.txt            自动修正高危错别字后的文本（不删口语、不改写）
  03_会议纪要.docx         按场景定制的正式文档
  04_承诺跟踪表.md         跨会议累积的承诺台账（Markdown）
  05_承诺跟踪表.docx       同内容 docx 版，可直接发人

铁律：
  1. 质检只**提示**不代改实质内容；高危项必须与人确认后由人工决定是否采信。
  2. 承诺不入台账，等于没承诺。流水线默认自动把 spec 里的行动项写进台账。
"""
import argparse
import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DOCX_HINT = ("[依赖缺失] %s\n修复命令：\n"
             '  "C:/Users/ghszb/.workbuddy/binaries/python/envs/default/Scripts/python.exe"'
             " -m pip install python-docx")
try:
    import minutes
    import textqc
    import tracker
except ImportError as e:          # 依赖缺失要给可执行命令，不给裸 traceback
    raise SystemExit(DOCX_HINT % e)

# ------------------------------------------------------------------ 数据骨架
SKELETON = {
    "client_visit": {
        "title": "XX 客户拜访纪要",
        "time": "2026-09-03 14:00-15:30", "place": "", "attendees": "",
        "recorder": "",
        "summary": ["一句话：这次会谈拿到的最小承诺是什么"],
        "people": [["姓名", "职务", "角色", "关注点/雷区"]],
        "needs": ["客户现状与真实诉求"],
        "commitments": [["我方承诺事项", "责任人", "2026-09-10"]],
        "client_commitments": [["客户承诺事项", "对方责任人", "2026-09-10"]],
        "followup_mail": "（可直接发送的跟进邮件正文）",
        "next_step": "下一步动作",
    },
    "escalate": {
        "title": "XX 事项向上汇报",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["结论 / 现状 / 请求决策"],
        "conclusion": "第一段就把结论写完",
        "evidence": ["依据一", "依据二", "依据三"],
        "decisions": [["需决策事项", "建议方案", "备选方案", "不决策的后果"]],
        "resources": ["需要的资源"],
        "deadline": "2026-09-10", "impact": "后续节点",
    },
    "brainstorm": {
        "title": "XX 主题头脑风暴",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["本次产出 N 个点子，收敛出 M 个进入验证"],
        "ideas": [["点子", "提出人"]],
        "matrix": [["点子", "影响力", "可行性", "结论"]],
        "actions": [["举措", "责任人", "2026-09-10"]],
        "parked": [["点子", "暂缓/淘汰", "理由"]],
    },
    "decision": {
        "title": "XX 决策评审记录",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["决策内容 / 关键依据 / 复盘时点"],
        "topic": "本次要决策的事项",
        "options": [["方案", "优势", "劣势", "成本", "结论"]],
        "decision": "最终决策", "rationale": ["依据一", "依据二"],
        "dissent": ["反对意见（必须记录）"],
        "actions": [["行动项", "责任人", "2026-09-10"]],
        "review_date": "2026-12-03",
    },
    "weekly": {
        "title": "XX 项目周会",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["上期承诺完成情况 / 本期风险 / 下期承诺"],
        "last_commitments": [["承诺事项", "责任人", "上期状态", "本期状态"]],
        "progress": ["本期进展"],
        "risks": [["风险/阻塞", "影响", "需要的支持", "是否升级"]],
        "next_commitments": [["下期承诺", "责任人", "2026-09-10"]],
    },
    "retro": {
        "title": "XX 项目复盘",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["做对了什么 / 做错了什么 / 下次怎么改"],
        "goals": [["目标", "实际结果", "偏差"]],
        "keep": ["继续保持"], "stop": ["停止做"],
        "root_cause": ["为什么1→答案", "为什么2→答案", "为什么3→答案",
                    "为什么4→答案", "为什么5→根因"],
        "actions": [["改进行动", "责任人", "2026-09-10"]],
    },
    "interview": {
        "title": "XX 用户访谈纪要",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["受访对象 / 核心发现 / 需求条目数"],
        "profile": [["项目", "内容"]],
        "quotes": ["用户原话，一字不改"],
        "needs": [["需求", "频次", "强度", "归类", "优先级"]],
        "surprises": ["意外发现"],
    },
    "cross_team": {
        "title": "XX 跨部门协调会",
        "time": "", "attendees": "", "recorder": "",
        "summary": ["目标 / 责任划分 / 关键依赖项"],
        "goal": "共同目标",
        "raci": [["事项", "R", "A", "C", "I"]],
        "dependencies": [["依赖项", "依赖方", "交付时点", "延误影响"]],
        "resolutions": ["争议与决议"],
        "actions": [["行动项", "责任人", "2026-09-10"]],
    },
}

# 场景 → 台账字段映射（哪些字段算"承诺/行动项"，要进跟踪表）
ACTION_FIELDS = {
    "client_visit": ["commitments", "client_commitments"],
    "escalate": [],
    "brainstorm": ["actions"],
    "decision": ["actions"],
    "weekly": ["next_commitments"],
    "retro": ["actions"],
    "interview": [],
    "cross_team": ["actions"],
}


def _read_json_arg(s):
    """读 spec：支持文件路径或 JSON 字符串。

    解析失败一律以 `[错误]` 前缀输出并退出，不抛裸 traceback——
    调用方看到的是可执行的修复建议，不是栈信息。
    """
    if os.path.isfile(s):
        raw = open(s, encoding="utf-8").read()
        src = "文件 %s" % os.path.abspath(s)
    elif s.strip().endswith(".json"):
        print("[错误] 数据文件不存在：%s" % os.path.abspath(s))
        print("       用绝对路径，或先跑 `--template <场景> > spec.json` 生成骨架再填。")
        sys.exit(2)
    else:
        raw, src = s, "内联 JSON 字符串"
    try:
        return json.loads(raw)
    except Exception as e:
        print("[错误] JSON 解析失败（%s）：%s" % (src, e))
        print("       常见原因：尾逗号、中文引号（“ ”）、用了单引号、注释未删。")
        print("       修复：跑 `--template <场景> > spec.json` 重新生成骨架，照格式填。")
        sys.exit(2)


def _attach_qc(r, qc):
    """把质检提示插到「核心结论」之后——放附录没人看。"""
    orig = r.summary
    done = {"v": False}

    def _s(lines, title="核心结论"):
        orig(lines, title)
        if done["v"]:
            return
        done["v"] = True
        high = [i for i in qc["issues"] if i["severity"] == "高"]
        r.h2("转写稿质检提示（发出前请确认）")
        r.para("原文 %d 字，质检发现 %d 项问题，其中高危 %d 项。"
               % (qc["length"], len(qc["issues"]), len(high)), size=10.5)
        if high:
            r.table(["高危项", "建议", "说明"],
                    [[i["found"], i["suggest"], i["note"]] for i in high[:12]],
                    widths=[3.0, 2.6, 9.6])
            r.callout("必须人工确认",
                      "以上高危项多涉及法律/金融含义或疑似转写错误（如「定金/订金」「法人」、"
                      "异常大的数字）。质检只做提示，不代改——请与参会人核对口径后再定稿。")
        else:
            r.para("无高危问题，中低危项已在《转写稿质检报告》中列出。", size=10.5)
    r.summary = _s


def main():
    ap = argparse.ArgumentParser(description="会议纪要一键流水线")
    ap.add_argument("--scenario", help="会议场景，--list 查看全部")
    ap.add_argument("--transcript", help="录音转写稿 txt 路径")
    ap.add_argument("--data", help="场景数据 spec.json 路径或 JSON 字符串")
    ap.add_argument("--out-dir", default=".", help="交付包输出目录")
    ap.add_argument("--ledger", help="承诺台账路径（默认 输出目录/commitments.json）")
    ap.add_argument("--template", help="打印某场景的数据骨架")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--no-tracker", action="store_true", help="不写入台账")
    a = ap.parse_args()

    if a.list:
        print("可用场景 %d 类：\n" % len(minutes.SCENARIOS))
        for k, (name, deliv) in minutes.SCENARIOS.items():
            print("  %-14s %-16s → %s" % (k, name, deliv))
        return

    if a.template:
        if a.template not in SKELETON:
            raise SystemExit("[错误] 未知场景 %r。可用：%s"
                             % (a.template, "、".join(SKELETON)))
        print(json.dumps(SKELETON[a.template], ensure_ascii=False, indent=1))
        return

    if not a.scenario or not a.data:
        ap.error("需要 --scenario 与 --data（或先用 --template 生成骨架）")
    if a.scenario not in minutes.BUILDERS:
        raise SystemExit("[错误] 未知场景 %r。可用：%s"
                         % (a.scenario, "、".join(minutes.BUILDERS)))

    out_dir = a.out_dir
    os.makedirs(out_dir, exist_ok=True)
    d = _read_json_arg(a.data)
    d["scenario"] = a.scenario
    steps = []

    # ---- 步骤 1：转写稿质检（有转写稿才跑）
    qc_path = clean_path = None
    if a.transcript:
        if not os.path.isfile(a.transcript):
            raise SystemExit("[错误] 转写稿不存在：%s" % a.transcript)
        raw = open(a.transcript, encoding="utf-8").read()
        issues = textqc.run(raw)
        qc = {"length": len(raw), "issues": issues}
        qc_path = os.path.join(out_dir, "01_转写稿质检报告.md")
        open(qc_path, "w", encoding="utf-8").write(textqc.to_markdown(issues, raw))
        clean_path = os.path.join(out_dir, "02_清洗稿.txt")
        open(clean_path, "w", encoding="utf-8").write(textqc.clean_text(raw, issues))
        high = [i for i in issues if i["severity"] == "高"]
        steps.append(("① 转写稿质检", "OK",
                      "%d 字 / %d 项问题 / 高危 %d 项"
                      % (len(raw), len(issues), len(high))))
    else:
        qc = None
        steps.append(("① 转写稿质检", "跳过", "未提供 --transcript"))

    # ---- 步骤 2：分场景纪要 docx
    r = minutes._base(d)
    if qc:
        _attach_qc(r, qc)
    try:
        minutes.BUILDERS[a.scenario](r, d)
    except ValueError as e:
        print("[错误] 数据字段与场景 '%s' 不匹配：%s" % (a.scenario, e))
        print("       每个场景的字段结构不同，别拿一份 spec 套全部场景。")
        print("       修复：跑 `--template %s > spec.json` 重新生成该场景骨架，照格式填。" % a.scenario)
        sys.exit(2)
    if d.get("sign"):
        r.sign(d["sign"])
    docx_path = os.path.join(
        out_dir, "03_%s_%s.docx"
        % (d.get("title") or minutes.SCENARIOS[a.scenario][0],
           datetime.now().strftime("%Y%m%d")))
    docx_path = r.save(docx_path)
    steps.append(("② 分场景纪要", "OK", os.path.basename(docx_path)))

    # ---- 步骤 3：承诺入台账
    md_path = tk_path = None
    if a.no_tracker:
        steps.append(("③ 承诺跟踪表", "跳过", "已指定 --no-tracker"))
    else:
        fields = ACTION_FIELDS.get(a.scenario, [])
        items = []
        for f in fields:
            for x in (d.get(f) or []):
                if isinstance(x, (list, tuple)) and len(x) >= 2:
                    items.append([x[0], x[1], x[2] if len(x) > 2 else ""])
                elif isinstance(x, dict):
                    items.append([x.get("action", ""), x.get("owner", ""),
                                  x.get("due", "")])
        ledger = a.ledger or os.path.join(out_dir, "commitments.json")
        led = tracker.load(ledger)
        if items:
            mid, added, skipped = tracker.cmd_add(led, {
                "meeting": d.get("title") or minutes.SCENARIOS[a.scenario][0],
                "date": (d.get("time") or "")[:10] or datetime.now().strftime("%Y-%m-%d"),
                "scenario": a.scenario,
                "items": items,
            })
            tracker.save(ledger, led)
            steps.append(("③ 承诺入台账", "OK",
                          "%s：新增 %d 项，去重跳过 %d 项" % (mid, added, skipped)))
        else:
            steps.append(("③ 承诺入台账", "OK",
                          "本场景无行动项字段（%s），台账未变动" % (fields or "无")))
        md_path = os.path.join(out_dir, "04_承诺跟踪表.md")
        open(md_path, "w", encoding="utf-8").write(tracker.to_markdown(led))
        tk_path = os.path.join(out_dir, "05_承诺跟踪表.docx")
        tracker.to_docx(led, tk_path)

    # ---- 汇总
    print("\n" + "=" * 62)
    print("会议纪要交付包 · %s" % minutes.SCENARIOS[a.scenario][0])
    print("=" * 62)
    for name, ok, note in steps:
        print("  [%s] %-12s %s" % (ok, name, note))
    print("-" * 62)
    for p in (qc_path, clean_path, docx_path, md_path, tk_path):
        if p:
            print("  → %s" % os.path.abspath(p))
    if qc and any(i["severity"] == "高" for i in qc["issues"]):
        hi = sorted({i["found"] for i in qc["issues"] if i["severity"] == "高"})
        print("-" * 62)
        print("  ⚠ 高危项 %d 类必须人工确认：%s" % (len(hi), "、".join(hi)))
        print("    质检只提示不代改，请与参会人核对口径后再定稿。")
    print("=" * 62 + "\n")


if __name__ == "__main__":
    main()
