# -*- coding: utf-8 -*-
"""中文商业报告 docx 生成器（基于 python-docx）。

把"方法论结论"落成能直接发出去的正式文档：封面、结论摘要框、分级标题、
三线表、评分卡、行动清单、页眉页脚页码、落款。

用法：
    from report_kit import Report
    r = Report(title="出海准备度体检报告", subtitle="XX 有限公司",
               confidential="内部资料", footer="博维管理咨询")
    r.summary(["建议推迟出海 6 个月", "最大短板：海外渠道为零"])
    r.h1("一、总体结论")
    r.para("...")
    r.bullets(["...", "..."])
    r.score_card([("市场吸引力", 72, "中"), ("组织准备度", 45, "弱")])
    r.table(["维度", "现状", "建议"], [["渠道", "0 家", "先找 2 家试单"]])
    r.callout("风险提示", "汇率敞口未对冲。")
    r.actions([("补齐海外渠道", "海外负责人", "2026-12-31")])
    r.sign("博维管理咨询", "2026-09-03")
    r.save("出海体检报告.docx")
"""
import os
from datetime import datetime

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

FONT_CN = "微软雅黑"
FONT_BODY = "等线"
NAVY = RGBColor(0x1B, 0x3A, 0x5C)
INK = RGBColor(0x1F, 0x27, 0x33)
SUB = RGBColor(0x5F, 0x5E, 0x5A)
AMBER = RGBColor(0x8A, 0x5A, 0x0B)
RED = RGBColor(0xA3, 0x2D, 0x2D)
GREEN = RGBColor(0x0F, 0x6E, 0x56)

H_FILL = "1B3A5C"
S_FILL = "F4F1EA"
C_FILL = "FAEEDA"
W_FILL = "F1EFE8"


def _shade(cell, hex_fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tcPr.append(shd)


def _borders(cell, spec):
    """spec: {'top':(sz,color), 'bottom':(sz,color), 'left':None, 'right':None}"""
    tcPr = cell._tc.get_or_add_tcPr()
    el = tcPr.find(qn("w:tcBorders"))
    if el is None:
        el = OxmlElement("w:tcBorders")
        tcPr.append(el)
    for edge in ("top", "left", "bottom", "right"):
        old = el.find(qn("w:" + edge))
        if old is not None:
            el.remove(old)
        v = spec.get(edge)
        if v:
            sz, color = v
            e = OxmlElement("w:" + edge)
            e.set(qn("w:val"), "single")
            e.set(qn("w:sz"), str(sz))
            e.set(qn("w:space"), "0")
            e.set(qn("w:color"), color)
            el.append(e)


def _font(run, size=11, bold=False, color=INK, name=FONT_BODY):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    return run


def _para(doc, text="", size=11, bold=False, color=INK, name=FONT_BODY,
          align=None, before=0, after=6, indent=0, spacing=1.45):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = spacing
    if indent:
        pf.left_indent = Cm(indent)
    if align:
        p.alignment = align
    if text:
        _font(p.add_run(text), size=size, bold=bold, color=color, name=name)
    return p


class Report:
    def __init__(self, title="商业分析报告", subtitle=None, confidential=None,
                 footer=None, header=None, cover=True):
        self.doc = Document()
        self.footer = footer
        self.header = header
        sec = self.doc.sections[0]
        sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
        sec.top_margin = sec.bottom_margin = Cm(2.5)
        sec.left_margin = sec.right_margin = Cm(2.6)
        st = self.doc.styles["Normal"]
        st.font.name = FONT_BODY
        st.font.size = Pt(11)
        st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT_BODY)

        if cover:
            self._cover(title, subtitle, confidential)
        self._build_header_footer()

    # ---------------------------------------------------------------- 封面
    def _cover(self, title, subtitle, confidential):
        d = self.doc
        for _ in range(5):
            _para(d, "", after=0)
        _para(d, title, size=26, bold=True, color=NAVY, name=FONT_CN,
              align=WD_ALIGN_PARAGRAPH.CENTER, after=10)
        if subtitle:
            _para(d, subtitle, size=14, color=SUB, name=FONT_CN,
                  align=WD_ALIGN_PARAGRAPH.CENTER, after=6)
        _para(d, datetime.now().strftime("%Y 年 %m 月 %d 日"), size=11, color=SUB,
              align=WD_ALIGN_PARAGRAPH.CENTER, after=0)
        if confidential:
            _para(d, "", after=0)
            _para(d, "（%s）" % confidential, size=10.5, color=RED,
                  align=WD_ALIGN_PARAGRAPH.CENTER, after=0)
        d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    # ------------------------------------------------------- 页眉页脚页码
    def _build_header_footer(self):
        sec = self.doc.sections[0]
        if self.header:
            hp = sec.header.paragraphs[0]
            hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            _font(hp.add_run(self.header), size=9, color=SUB)
        fp = sec.footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if self.footer:
            _font(fp.add_run(self.footer + "    "), size=9, color=SUB)
        _font(fp.add_run("第 "), size=9, color=SUB)
        self._page_field(fp)
        _font(fp.add_run(" 页"), size=9, color=SUB)

    def _page_field(self, para):
        r = para.add_run()
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), "PAGE")
        run_el = OxmlElement("w:r")
        rpr = OxmlElement("w:rPr")
        szel = OxmlElement("w:sz"); szel.set(qn("w:val"), "18")
        rpr.append(szel)
        run_el.append(rpr)
        fld.append(run_el)
        r._r.addnext(fld)

    # ---------------------------------------------------------------- 组件
    def summary(self, lines, title="核心结论"):
        """结论摘要框：一眼看到底牌。"""
        d = self.doc
        _para(d, title, size=13, bold=True, color=NAVY, name=FONT_CN, before=6, after=6)
        t = d.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        c = t.cell(0, 0)
        _shade(c, S_FILL)
        _borders(c, {"top": (6, H_FILL), "bottom": (6, H_FILL)})
        c.text = ""
        first = True
        for ln in lines:
            p = c.paragraphs[0] if first else c.add_paragraph()
            first = False
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.line_spacing = 1.4
            _font(p.add_run("▪ "), size=11, bold=True, color=NAVY)
            _font(p.add_run(ln), size=11, color=INK)
        _para(d, "", after=2)

    def h1(self, text):
        _para(self.doc, text, size=15, bold=True, color=NAVY, name=FONT_CN,
              before=14, after=8)

    def h2(self, text):
        _para(self.doc, text, size=12.5, bold=True, color=INK, name=FONT_CN,
              before=10, after=5)

    def para(self, text, size=11, indent=0, bold=False, color=INK):
        return _para(self.doc, text, size=size, bold=bold, color=color, indent=indent)

    def bullets(self, items, size=11):
        for it in items:
            p = _para(self.doc, "", size=size, after=3)
            p.paragraph_format.left_indent = Cm(0.6)
            _font(p.add_run("· "), size=size, color=NAVY, bold=True)
            _font(p.add_run(it), size=size, color=INK)

    def numbered(self, items, size=11):
        for i, it in enumerate(items, 1):
            p = _para(self.doc, "", size=size, after=3)
            p.paragraph_format.left_indent = Cm(0.6)
            _font(p.add_run("%d. " % i), size=size, color=NAVY, bold=True)
            _font(p.add_run(it), size=size, color=INK)

    def table(self, headers, rows, widths=None, first_col_bold=True):
        d = self.doc
        t = d.add_table(rows=1, cols=len(headers))
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for i, h in enumerate(headers):
            c = t.rows[0].cells[i]
            _shade(c, H_FILL)
            c.text = ""
            p = c.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _font(p.add_run(str(h)), size=10.5, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF),
                  name=FONT_CN)
        for ri, row in enumerate(rows):
            row = list(row)
            if len(row) != len(headers):
                raise ValueError(
                    "表格第 %d 行有 %d 列，但表头要求 %d 列（%s）"
                    % (ri + 1, len(row), len(headers),
                       "、".join(str(h) for h in headers)))
            cells = t.add_row().cells
            for i, v in enumerate(row):
                cells[i].text = ""
                p = cells[i].paragraphs[0]
                p.paragraph_format.space_after = Pt(2)
                _font(p.add_run(str(v)), size=10.5,
                      bold=(i == 0 and first_col_bold), color=INK)
            if ri % 2 == 1:
                for c in cells:
                    _shade(c, W_FILL)
        if widths:
            for r in t.rows:
                for i, w in enumerate(widths):
                    if i < len(r.cells):
                        r.cells[i].width = Cm(w)
        _para(d, "", after=2)
        return t

    def score_card(self, rows, headers=("评估维度", "得分", "判定")):
        """评分卡：维度 / 得分 / 判定，得分按区间自动着色。"""
        d = self.doc
        t = d.add_table(rows=1, cols=3)
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for i, h in enumerate(headers):
            c = t.rows[0].cells[i]
            _shade(c, H_FILL)
            c.text = ""
            p = c.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _font(p.add_run(h), size=10.5, bold=True,
                  color=RGBColor(0xFF, 0xFF, 0xFF), name=FONT_CN)
        for name, score, verdict in rows:
            cells = t.add_row().cells
            cells[0].text = ""
            _font(cells[0].paragraphs[0].add_run(str(name)), size=10.5, bold=True, color=INK)
            cells[1].text = ""
            p = cells[1].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            try:
                sv = float(score)
                col = GREEN if sv >= 75 else (AMBER if sv >= 55 else RED)
            except (TypeError, ValueError):
                col = INK
            _font(p.add_run(str(score)), size=11, bold=True, color=col)
            cells[2].text = ""
            p2 = cells[2].paragraphs[0]
            p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _font(p2.add_run(str(verdict)), size=10.5, color=INK)
        _para(d, "", after=2)
        return t

    def callout(self, title, text, fill=C_FILL):
        d = self.doc
        t = d.add_table(rows=1, cols=1)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        c = t.cell(0, 0)
        _shade(c, fill)
        _borders(c, {"top": (6, H_FILL), "bottom": (6, H_FILL)})
        c.text = ""
        p = c.paragraphs[0]
        p.paragraph_format.space_after = Pt(3)
        _font(p.add_run(title + "："), size=10.5, bold=True, color=AMBER, name=FONT_CN)
        _font(p.add_run(text), size=10.5, color=INK)
        _para(d, "", after=2)

    def actions(self, rows, headers=("行动项", "责任人", "截止日期")):
        return self.table(list(headers), [list(r) for r in rows], widths=[9.0, 3.4, 3.4])

    def sign(self, org=None, date=None):
        d = self.doc
        _para(d, "", after=18)
        for line in [org or "", date or datetime.now().strftime("%Y 年 %m 月 %d 日")]:
            if line:
                _para(d, line, size=11, color=SUB, align=WD_ALIGN_PARAGRAPH.RIGHT, after=2)

    def page_break(self):
        self.doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    def save(self, path):
        d = os.path.dirname(os.path.abspath(path))
        if d and not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        self.doc.save(path)
        return os.path.abspath(path)
