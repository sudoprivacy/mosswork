## Description: <br>
Produces Chinese A-share stock diagnosis reports using a top-down macro, industry, and single-stock analysis flow with investment star ratings and operating suggestions. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[stevenge791](https://clawhub.ai/user/stevenge791) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External users and analysts use this skill to generate structured A-share stock diagnosis reports covering fundamentals, technicals, fund flows, news, macro context, and industry context. The output supports review and decision preparation, not personalized financial advice. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can produce buy, sell, or hold-style investment suggestions that may be incorrect, incomplete, or unsuitable for a specific user. <br>
Mitigation: Treat the output as non-professional financial guidance and independently verify market data, assumptions, and recommendations before acting. <br>
Risk: The skill may activate on broad stock or investment questions and answer in Chinese, which can make scope or intent unclear. <br>
Mitigation: Confirm the target stock, market context, and intended analysis scope before relying on the generated report. <br>


## Reference(s): <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, guidance] <br>
**Output Format:** [Markdown report with tables, scores, ratings, and narrative analysis] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Chinese-language financial analysis output; relies on available market, news, and related skill outputs.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
