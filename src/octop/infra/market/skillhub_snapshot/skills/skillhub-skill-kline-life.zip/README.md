# 人生 K 线卡点视频 skill

这是一个可直接放入 Codex skills 目录的 skill。它把人物、角色或主题的真实经历整理为 63 根 K 线，按内置配乐卡点，输出约 140 秒的 1080×1920 竖屏 MP4。正式入口是项目根目录的 `SKILL.md`；`skills/kline-life-video.md` 仅保留给旧版 PI-Desktop 插件兼容使用。

## 安装

将整个目录复制为 Codex skill 目录中的 `kline-life-video`：

```powershell
Copy-Item -Recurse -Force C:\Users\admin\Desktop\kline-life-skill $env:CODEX_HOME\skills\kline-life-video
```

如果未设置 `CODEX_HOME`，可复制到 `~/.codex/skills/kline-life-video`。安装后可在请求中直接使用 `$kline-life-video`，也可以让 Codex 根据描述自动调用。

## 目录结构

| 路径 | 作用 |
|---|---|
| `SKILL.md` | Codex skill 标准入口与工作流 |
| `agents/openai.yaml` | Codex UI 名称、描述和默认提示语 |
| `references/story-spec.md` | 63 个槽位、字段和特效规范 |
| `engine/kline.mjs` | `doctor`、`new`、`check`、`preview`、`render` 命令入口 |
| `engine/render.mjs` | 逐帧绘制 K 线并调用 ffmpeg 合成视频 |
| `engine/music.mjs` | 节拍网格、63 个乐句槽位和涨幅规则 |
| `engine/env.mjs` | 渲染依赖、字体和外部工具检查 |
| `templates/story.template.mjs` | 故事模板 |
| `examples/mayun.story.mjs` | 完整示例 |
| `assets/bgm.m4a` | 内置配乐 |

## 环境要求

- Node.js 18 及以上。
- `ffmpeg` 和 `ffprobe` 已加入 PATH。
- 首次运行会自动安装 `@napi-rs/canvas@1.1.0`，默认目录为 `%LOCALAPPDATA%\kline-life-video\runtime`，可用 `KLINE_RUNTIME_DIR` 覆盖。
- 中文字体优先使用 Noto Serif SC / Noto Sans SC；没有时会回退到系统字体。

## 命令

把 `K` 设置为 skill 目录：

```powershell
$K = 'C:\Users\admin\.codex\skills\kline-life-video'
node "$K\engine\kline.mjs" doctor
node "$K\engine\kline.mjs" new .\张三-kline --name 张三
node "$K\engine\kline.mjs" check .\张三-kline\story.mjs
node "$K\engine\kline.mjs" preview .\张三-kline\story.mjs
node "$K\engine\kline.mjs" render .\张三-kline\story.mjs
```

| 命令 | 参数 | 作用 |
|---|---|---|
| `doctor` | 无 | 检查环境并准备渲染依赖 |
| `new <目录>` | `--name 名字`、`--force` | 生成 `story.mjs` 模板 |
| `check <story>` | 无 | 校验 63 根 K 线、涨幅规则和文字长度 |
| `preview <story>` | `--at 秒,秒`、`--dir 目录` | 导出关键帧和 `preview/sheet.png` |
| `render <story>` | `--out 路径`、`--from 秒`、`--to 秒`、`--force` | 渲染成片 |

推荐顺序：`doctor` → `new` → 编辑 `story.mjs` → `check` → `preview` → `render`。

## 注意

事件应来自可核实的公开资料；人生指数只用于视觉叙事。内置配乐来自用户提供的示例视频，公开发布前请确认音乐版权，或在发布平台替换为合规曲库版本。
