/**
 * 人生K线卡点视频 — PI-Desktop 插件入口。
 *
 * 本插件只提供技能（skills/kline-life-video.md），渲染引擎位于 engine/，
 * 由 Agent 通过 node 命令调用，入口无需在启动时做任何事。
 */

async function onLoad() {}

async function onUnload() {}

module.exports = { onLoad, onUnload };
