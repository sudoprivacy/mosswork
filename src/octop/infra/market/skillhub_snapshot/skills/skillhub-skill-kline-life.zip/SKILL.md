---
name: skillhub-skill-kline-life
description: "Create a vertical “life K-line” short video from a person, character, company, brand, city, or other theme by researching dated events, writing a 63-candle story, validating it, previewing key frames, and rendering an MP4 with the bundled beat-synced music. Use when the user asks to visualize a life or development arc as candlesticks or a beat-matched K-line video."
---

# 人生 K 线卡点视频

这个 skill 使用项目内置的配乐、故事模板和 Node.js 渲染引擎，把一个人物或主题的真实经历制作成约 140 秒的 1080×1920 竖屏 MP4。人生指数是视觉叙事用的虚构指标，事件和日期仍需来自可核实的公开资料。

## 何时使用

用户只给出人物、角色或主题，并要求制作“人生 K 线”“经历涨跌”“配合 BGM 卡点”或类似短视频时使用。主题可以是人物、公司、品牌、城市或虚构角色；同名人物或主题含义不明确时再询问用户。

## 工作流程

把包含本文件的目录记为 `$K`。在 Windows PowerShell 中按以下顺序执行：

```powershell
node "$K\engine\kline.mjs" doctor
node "$K\engine\kline.mjs" new ".\<名字>-kline" --name <名字>
node "$K\engine\kline.mjs" check ".\<名字>-kline\story.mjs"
node "$K\engine\kline.mjs" preview ".\<名字>-kline\story.mjs"
node "$K\engine\kline.mjs" render ".\<名字>-kline\story.mjs"
```

1. 先运行 `doctor`。它会检查 Node.js、ffmpeg、ffprobe、字体和内置配乐，并在首次使用时把 `@napi-rs/canvas@1.1.0` 安装到用户运行时目录。
2. 调研至少 60 个带日期的真实事件和可核实数字。为每个事件保留来源，负面事件只写公开报道过的事实并使用中性措辞；日期不确定时只写年份。
3. 阅读 `examples/mayun.story.mjs`，然后用 `new` 生成故事模板。只编辑生成的 `story.mjs`，不要手写拍位。
4. 运行 `check`，修复所有错误并尽量消除文字过长提示。再运行 `preview`，检查 `preview/sheet.png` 中的文字、特效位置和走势。
5. 运行 `render` 生成成片。交付前用 `ffprobe` 检查时长约 140 秒、分辨率为 1080×1920，并抽帧确认画面；向用户说明成片路径、关键事件、事实来源和“人生指数”为虚构。

## 固定故事约束

- 故事必须正好有 63 根 K 线，一个乐句对应一个事件；`b` 和 `boom` 由引擎分配，故事文件不要填写。
- 第 25–40 根属于大涨音乐，每根涨幅至少 `+30%`；其余段落单根涨幅最多 `+15%`。第 9 根是唯一允许在高潮外大涨的超跌反弹。
- 第 47 根是全片最高点，第 48 根是风暴前夜，第 49 根是最大打击；若主题没有真实崩盘，用最大的挫折、争议或新挑战表达低潮。
- 每根事件使用 `{ date, pct|c, ev, fx?, mark?, ph? }`。标题 `t` 最多 10 字，描述 `d` 最多 28 字，`badge` 1–2 字，`cap` 最多 5 字；特效文字也遵守模板中的长度限制。
- `person` 至少填写 `name`、`logo`、`code`、`birth`、`watermark`、`intro`、`endingNote`；第 1 根必须指定 `ph`。阶段键不超过 3 字，身份不超过 7 字。

## 项目资源

- `engine/kline.mjs`：`doctor`、`new`、`check`、`preview`、`render` 命令入口。
- `engine/render.mjs`：逐帧绘制 K 线、特效并调用 ffmpeg 合成视频。
- `engine/music.mjs`：配乐节拍、63 个槽位和涨幅规则。
- `templates/story.template.mjs`：可直接生成的故事模板。
- `examples/mayun.story.mjs`：完整故事示例，适合参考事件密度和文字长度。
- `assets/bgm.m4a`：内置配乐。公开发布前确认音乐版权，或在发布平台替换为同一首歌曲的合规版本。

详细槽位、字段和特效说明见 [references/story-spec.md](references/story-spec.md)。
