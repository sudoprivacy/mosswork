// 内置配乐与乐句槽位表
// 配乐：assets/bgm.m4a（约 140 秒，112.80 BPM，每小节 4 拍），含第 24-39 小节的“大涨音乐”（高潮音乐）。
// 节奏规则：一个乐句（一小节）对应一个事件、一根K线；无鼓蓄力段每 2 拍一根。
// 涨幅规则：大涨只出现在“大涨音乐”段（该段每根都必须大涨），其余段落单根涨幅不超过 RULES.calmMaxPct；
//           第一段高潮重拍上的“超跌反弹”是唯一例外。
// 故事文件只需按顺序写 63 根K线，拍位与爆发拍由本表自动分配。
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

// 配乐与节拍网格（对配乐做节拍检测后线性拟合得到）
export const MUSIC = {
  // 配乐文件
  file: path.resolve(HERE, '..', 'assets', 'bgm.m4a'),
  // 第 0 拍所在秒数
  beat0: 0.3848,
  // 每拍秒数
  beatSec: 0.53192,
  // 片头结束、第一根K线出现的拍位
  introEndBeat: 8,
  // 片尾全景开始的拍位
  endingBeat: 252,
  // 结尾音频淡出秒数
  fadeOut: 1.5,
};

// 配乐段落（单位：拍）：gain 为节拍脉冲强度；rise 为“大涨音乐”段（红色氛围光 + 上升粒子，且每根K线必须大涨）；
// climaxHit 表示该段第一拍是鼓点进入的重拍，允许出现一次大涨（超跌反弹）
export const SECTIONS = [
  { from: 0, to: 8, key: 'title', name: '片头', gain: 0 },
  { from: 8, to: 20, key: 'intro', name: '前奏', gain: 0.55 },
  { from: 20, to: 32, key: 'build', name: '无鼓蓄力', gain: 0 },
  { from: 32, to: 96, key: 'drop1', name: '第一段高潮', gain: 1, climaxHit: true },
  { from: 96, to: 160, key: 'rise', name: '大涨音乐', gain: 1.25, rise: true },
  { from: 160, to: 188, key: 'calm', name: '平稳段', gain: 0.55 },
  { from: 188, to: 192, key: 'silence', name: '留白', gain: 0 },
  { from: 192, to: 252, key: 'crash', name: '暴跌重鼓', gain: 1 },
  { from: 252, to: 9999, key: 'ending', name: '片尾', gain: 0 },
];

// 涨幅规则阈值（单位：%）
export const RULES = {
  // 大涨音乐段内每根K线的最低涨幅
  riseMinPct: 30,
  // 其余段落单根K线的最高涨幅
  calmMaxPct: 15,
};

// 紧张度渐强区间（单位：拍）：画面缓慢推近、四周压暗，peak 为区间末尾的强度
export const TENSION = [
  { from: 20, to: 32, peak: 1 },
  { from: 180, to: 188, peak: 0.8 },
];

// 63 个乐句槽位：b 出现拍；boom 出现后第几拍爆发（不填为在乐句内逐步生长）；role 写作提示；fx 推荐特效
function buildSlots() {
  const s = [];
  const add = (sec, b, extra = {}) => s.push({ sec, b, ...extra });
  // 前奏 3 根：起点与童年，小幅波动；第一根开盘价固定 100
  [8, 12, 16].forEach((b, i) => add('intro', b, { role: i === 0 ? '起点：出生/成立（开盘 100）' : '早年经历，小幅波动' }));
  // 无鼓蓄力 5 根（每 2 拍一根）：连续受挫，一路跌到谷底
  [20, 22, 24, 26, 28].forEach((b) => add('build', b, { role: '低谷：连续受挫、下跌' }));
  // 转折：第 30 拍亮出，第 32 拍（第一段高潮重拍）爆发
  add('rebound', 30, { boom: 2, role: '转折：超跌反弹（全片第一次大涨）', fx: 'rebound' });
  // 第一段高潮 15 根：小涨小跌慢慢积累（最后一根为 2 拍过渡）
  for (let b = 36; b <= 88; b += 4) add('drop1', b, { role: '积累：小涨小跌，慢慢走高' });
  add('drop1', 92, { role: '过渡：大涨前夜（可不写事件）' });
  // 大涨音乐 16 根：第 3 拍亮出，下一小节重拍暴涨
  const riseFx = { 1: 'title', 3: 'flashUp:主力进场', 9: 'glow', 12: 'flashUp:主升浪', 15: 'glow', 16: 'title' };
  for (let i = 1, b = 94; b <= 154; b += 4, i++) {
    add('rise', b, { boom: 2, role: i === 16 ? '主升浪顶点：巅峰头衔' : '主升浪：每根大涨', fx: riseFx[i] });
  }
  // 平稳段 7 根：高位震荡，最后一根为人生巅峰
  for (let b = 160; b <= 184; b += 4) add('calm', b, { role: b === 184 ? '人生巅峰（全片最高点）' : '高位小幅震荡' });
  // 留白 1 根：音乐骤停，风暴前夜
  add('silence', 188, { role: '风暴前夜：预警事件', fx: 'spot' });
  // 暴跌重鼓 15 根：重拍上砸下，后段可小幅修复
  for (let i = 1, b = 192; b <= 248; b += 4, i++) {
    add('crash', b, { boom: 0, role: i === 1 ? '崩盘：最大打击' : '暴跌与余波，后段可小幅修复', fx: i === 1 ? 'flashDown:闪崩' : undefined });
  }
  return s;
}

export const SLOTS = buildSlots();
