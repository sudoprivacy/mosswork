// 人生K线卡点视频渲染器（@napi-rs/canvas 逐帧绘制 → ffmpeg 合成内置配乐）
// 一般通过 kline.mjs 调用，也可直接运行：
//   node render.mjs check   <story.mjs>                              校验故事并打印节奏表（有违规时退出码为 1）
//   node render.mjs preview <story.mjs> [--at 5,51.9] [--dir 目录]   导出关键时刻预览帧与拼图 sheet.png
//   node render.mjs render  <story.mjs> [--out 成片.mp4] [--from 秒 --to 秒] [--force]  渲染成片
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { once } from 'node:events';
import { pathToFileURL } from 'node:url';
import { MUSIC, SECTIONS, TENSION, RULES, SLOTS } from './music.mjs';
import { loadCanvas, resolveFonts, probeDuration } from './env.mjs';

// ===================== 命令行与故事文件 =====================
const argv = process.argv.slice(2);
const CMD = argv[0];
const opt = (name) => {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : undefined;
};
if (!['check', 'preview', 'render'].includes(CMD) || !argv[1] || argv[1].startsWith('--')) {
  console.error('用法：node render.mjs <check|preview|render> <story.mjs> [选项]');
  process.exit(2);
}
const STORY_PATH = path.resolve(argv[1]);
if (!fs.existsSync(STORY_PATH)) {
  console.error(`找不到故事文件：${STORY_PATH}`);
  process.exit(2);
}
const STORY = (await import(pathToFileURL(STORY_PATH).href)).default;
if (!STORY || !STORY.person || !Array.isArray(STORY.phases) || !Array.isArray(STORY.candles)) {
  console.error('故事文件格式错误：需要 export default { person, phases, candles }');
  process.exit(2);
}
const PERSON = STORY.person;
const PHASES = STORY.phases;
// 出生年月（主题类可写成立年月），用于计算年龄
const [BIRTH_Y, BIRTH_M] = String(PERSON.birth ?? '').split('.').map(Number);
const STORY_DIR = path.dirname(STORY_PATH);
const { createCanvas, GlobalFonts } = loadCanvas();

// ===================== 可调参数 =====================
const CONFIG = {
  // 内置配乐文件，视频总时长以配乐时长为准
  music: MUSIC.file,
  // 默认成片输出路径：故事文件同目录
  out: path.join(STORY_DIR, `${PERSON.name || '主角'}人生K线.mp4`),
  // 预览帧默认输出目录
  previewDir: path.join(STORY_DIR, 'preview'),
  // 画面尺寸与帧率（竖屏 1080x1920、30fps）
  width: 1080,
  height: 1920,
  fps: 30,
  // 节拍网格与片头/片尾拍位（见 music.mjs）
  beat0: MUSIC.beat0,
  beatSec: MUSIC.beatSec,
  introEndBeat: MUSIC.introEndBeat,
  endingBeat: MUSIC.endingBeat,
  // 镜头纵向跟随的平滑时间常数（秒），越小跟得越紧
  cameraTau: 0.11,
  // x264 编码参数：crf 越小越清晰，preset 越慢压缩率越高
  crf: 18,
  preset: 'medium',
  // 随机种子：决定影线长度、价格跳动等细节，固定后每次渲染结果一致
  seed: 20260910,
};

// 特效类型及其大字最多字数（0 表示无大字）
const FX_TEXT_MAX = { rebound: 5, flashUp: 5, flashDown: 5, title: 5, stamp: 3, spot: 0, glow: 0 };

// 配色：红涨绿跌
const COLOR = {
  bg: '#090c12',
  panel: '#0c1017',
  up: '#ff3b3b',
  down: '#19d3a2',
  text: '#f2f4f8',
  dim: '#8a93a6',
  dimmer: '#5d6679',
  blue: '#5b7bd5',
  blueLight: '#8fb0ff',
  ma5: '#f2b84b',
  ma20: '#8ea2c8',
  logo: '#ff6a00',
  year: '#b9c8ea',
};

// 版式坐标（像素）
const L = {
  plotL: 40, plotR: 900, plotT: 470, plotB: 1068, // K线绘图区
  axisX: 915, // 右侧价格刻度起点
  spacing: 64, bodyW: 40, // K线间距与实体宽度
  firstX: 300, anchorX: 772, // 首根K线位置、当前K线最终锚点
  bandT: 1076, bandB: 1108, bandR: 805, // 底部阶段条
};

// 各类特效触发的镜头抖动幅度（像素）
const SHAKE = { rebound: 18, flashUp: 18, flashDown: 26, stamp: 16, glow: 8, title: 6 };

// ===================== 基础工具 =====================
const W = CONFIG.width;
// 视频总时长以配乐为准
const DURATION = probeDuration(CONFIG.music);
const H = CONFIG.height;
const FPS = CONFIG.fps;
const bt = (b) => CONFIG.beat0 + b * CONFIG.beatSec;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, u) => a + (b - a) * u;
const smooth = (u) => u * u * (3 - 2 * u);
const easeOut = (u) => 1 - Math.pow(1 - clamp(u, 0, 1), 3);
const easeOutBack = (u) => {
  const x = clamp(u, 0, 1) - 1;
  return 1 + 2.70158 * x * x * x + 1.70158 * x * x;
};
const ramp = (t, t0, dur) => clamp((t - t0) / dur, 0, 1);
const fmt = (v, d) => v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });

function mulberry32(seed) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function rgba(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

// 注册字体：每个别名可能对应多个文件（如雅黑常规 + 粗体）
const FONTS = resolveFonts();
for (const [alias, { files }] of Object.entries(FONTS)) {
  for (const file of files) GlobalFonts.registerFromPath(file, alias);
}
const FONTS_OK = FONTS.KSans.files.length > 0 && FONTS.KSerif.files.length > 0;
const F = {
  serif: (s, w = 900) => `${w} ${s}px KSerif`,
  sans: (s, w = 400) => `${w} ${s}px KSans`,
  mono: (s) => `700 ${s}px KMono`,
  din: (s) => `700 ${s}px KDin`,
};

// 日期 "1999.2" → { y: 1999, m: 2 }；没有月份按年底计算
function parseDate(s) {
  const [y, m] = s.split('.').map(Number);
  return { y, m: m || 12 };
}
function ageOf(date) {
  if (!BIRTH_Y) return null;
  const { y, m } = parseDate(date);
  return y - BIRTH_Y - (BIRTH_M && m < BIRTH_M ? 1 : 0);
}
// 按显示宽度计字数：中文与全角字符算 1，数字/英文/半角符号约算半个
function textLen(s) {
  let n = 0;
  for (const ch of String(s ?? '')) n += ch.codePointAt(0) >= 0x2e80 ? 1 : 0.55;
  return n;
}

// ===================== 数据模型 =====================
// 生长型K线的走势关键点（进度 0~1 → 价格）：在一个乐句内逐步走完
function pathKeys(cd) {
  const { o, c, h, l, up } = cd;
  const ext = up ? h : l; // 顺势极值
  const back = up ? l : h; // 反向试探
  if (cd.big) {
    // 大事件：重拍上迅速拉开，冲过极值后回落到收盘
    return [[0, o], [0.05, back], [0.16, lerp(o, c, 0.72)], [0.38, ext], [0.62, lerp(c, ext, 0.3)], [1, c]];
  }
  // 普通K线：先反向试探，乐句中段冲到极值，再收于收盘价
  return [[0, o], [0.16, back], [0.55, ext], [1, c]];
}

// 不含跳动的基础价格：生长型按关键点走；爆发型在爆发拍前停在开盘价，
// 爆发拍上 0.12 秒冲到极值，再用 0.55 秒回落到收盘价
function basePrice(cd, t) {
  if (cd.boomT === undefined) return pathAt(cd.keys, clamp((t - cd.t0) / (cd.t1 - cd.t0), 0, 1));
  if (t < cd.boomT) return cd.o;
  const ext = cd.up ? cd.h : cd.l;
  const tau = t - cd.boomT;
  if (tau < 0.12) return lerp(cd.o, ext, easeOut(tau / 0.12));
  return lerp(ext, cd.c, smooth(clamp((tau - 0.12) / 0.55, 0, 1)));
}

// 逐帧采样价格：基础走势 + 每秒 8 次的随机跳动（出现时与收盘前收敛为 0，保证开盘、收盘价准确），
// 同时记录到当前帧为止的最高/最低价
function sampleCandle(cd, rng) {
  const f0 = Math.ceil(cd.t0 * FPS - 1e-6);
  const n = Math.max(1, Math.ceil(cd.t1 * FPS - 1e-6) - f0);
  const ticks = Array.from({ length: Math.ceil((cd.t1 - cd.t0) * 8) + 2 }, () => rng() * 2 - 1);
  const amp = Math.max(Math.abs(cd.c - cd.o) * 0.06, Math.max(cd.o, cd.c) * 0.0035);
  const px = new Float64Array(n);
  const hi = new Float64Array(n);
  const lo = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const t = (f0 + i) / FPS;
    const x = Math.max(0, (t - cd.t0) * 8);
    const k = Math.floor(x);
    const noise = lerp(ticks[k], ticks[k + 1], x - k);
    // 爆发前价格完全静止在开盘价（显示 +0.00%），与示例一致
    const calm = cd.boomT !== undefined && t < cd.boomT ? 0 : 1;
    const env = clamp((t - cd.t0) / 0.15, 0, 1) * clamp((cd.t1 - t) / 0.3, 0, 1) * calm;
    px[i] = i === n - 1 ? cd.c : basePrice(cd, t) + noise * amp * env;
    hi[i] = Math.max(i ? hi[i - 1] : cd.o, px[i]);
    lo[i] = Math.min(i ? lo[i - 1] : cd.o, px[i]);
  }
  Object.assign(cd, { f0, px, hi, lo });
  // 收盘后的影线以实际走过的最高/最低价为准
  cd.h = hi[n - 1];
  cd.l = lo[n - 1];
}

function buildCandles() {
  const rng = mulberry32(CONFIG.seed);
  const phaseKeys = new Set(PHASES.map((p) => p.key));
  const list = [];
  let prev = 100;
  let phase = null;
  CANDLES.forEach((src, i) => {
    const nextB = i + 1 < CANDLES.length ? CANDLES[i + 1].b : CONFIG.endingBeat;
    if (nextB <= src.b) throw new Error(`第 ${i} 根K线拍位未递增：${src.b} → ${nextB}`);
    if (src.ph) {
      if (!phaseKeys.has(src.ph)) throw new Error(`未知人生阶段：${src.ph}`);
      phase = src.ph;
    }
    const o = src.o ?? prev;
    const c = src.c;
    const body = Math.abs(c - o);
    const top = Math.max(o, c);
    const bot = Math.min(o, c);
    const h = src.h ?? top + body * (0.08 + rng() * 0.3) + top * (0.004 + rng() * 0.008);
    const l = src.l ?? bot - body * (0.08 + rng() * 0.28) - bot * (0.004 + rng() * 0.008);
    const cd = {
      ...src, idx: i, o, c, h, l, phase,
      t0: bt(src.b), t1: bt(nextB),
      up: c >= o,
      big: body / bot > 0.25 || Boolean(src.fx),
    };
    // boom：K线出现后第几拍爆发；fxT0：整屏特效触发时刻
    if (src.boom !== undefined) cd.boomT = bt(src.b + src.boom);
    cd.fxT0 = cd.boomT ?? cd.t0;
    cd.keys = pathKeys(cd);
    sampleCandle(cd, rng);
    list.push(cd);
    prev = c;
  });
  return list;
}

// ===================== 故事 → K线（按配乐槽位表分配拍位） =====================
// 故事中每根K线可写 c（收盘价）或 pct（相对上一根收盘价的涨跌幅 %）；b/boom 由 SLOTS 自动分配
function normalizeStory() {
  const errors = [];
  const list = STORY.candles;
  if (list.length !== SLOTS.length) errors.push(`K线数量必须为 ${SLOTS.length} 根（当前 ${list.length} 根），与配乐乐句一一对应`);
  const out = [];
  let prev = list[0]?.o ?? 100;
  for (let i = 0; i < Math.min(list.length, SLOTS.length); i++) {
    const src = list[i] || {};
    let c = src.c;
    if (c === undefined && typeof src.pct === 'number') c = Math.round(prev * (1 + src.pct / 100) * 100) / 100;
    if (!(c > 0)) {
      errors.push(`第 ${i + 1} 根缺少有效的 c（收盘价）或 pct（涨跌幅）`);
      c = prev;
    }
    out.push({ ...src, c, b: SLOTS[i].b, boom: SLOTS[i].boom, sec: SLOTS[i].sec });
    prev = c;
  }
  return { candles: out, errors };
}

// 结构性错误（缺字段、阶段不存在、日期格式、特效类型等）：存在时直接退出
function structuralErrors() {
  const errs = [];
  for (const k of ['name', 'logo', 'code', 'birth', 'watermark', 'intro', 'endingNote']) {
    if (!PERSON[k]) errs.push(`person.${k} 未填写`);
  }
  if (!PHASES.length) errs.push('phases 不能为空');
  const keys = new Set(PHASES.map((p) => p.key));
  if (!STORY.candles[0]?.ph) errs.push('第 1 根K线必须指定 ph（人生阶段）');
  STORY.candles.forEach((c, i) => {
    const n = `第 ${i + 1} 根`;
    if (!/^\d{4}(\.\d{1,2}){0,2}$/.test(String(c.date ?? ''))) errs.push(`${n} date 格式应为 YYYY、YYYY.M 或 YYYY.M.D`);
    if (c.ph && !keys.has(c.ph)) errs.push(`${n} ph「${c.ph}」不在 phases 中`);
    if (c.b !== undefined || c.boom !== undefined) errs.push(`${n} 不要写 b/boom，拍位由配乐槽位表自动分配`);
    if (c.fx) {
      if (!(c.fx.type in FX_TEXT_MAX)) errs.push(`${n} fx.type「${c.fx.type}」无效（可选：${Object.keys(FX_TEXT_MAX).join('/')}）`);
      else if (FX_TEXT_MAX[c.fx.type] > 0 && (!c.fx.text || !c.fx.sub)) errs.push(`${n} ${c.fx.type} 特效需要 text 和 sub`);
    }
  });
  if (JSON.stringify(STORY).includes('TODO')) errs.push('故事文件中仍有 TODO 占位内容');
  return errs;
}

const NORM = normalizeStory();
const FATAL = [...NORM.errors, ...structuralErrors()];
if (FATAL.length) {
  console.error('故事文件有以下问题，请修正后重试：');
  FATAL.forEach((e) => console.error(`  - ${e}`));
  process.exit(1);
}
const CANDLES = NORM.candles;
const C = buildCandles();
// 片尾全景标注：取故事中带 mark 的K线
const ENDING_MARKS = C.filter((c) => c.mark).map((c) => ({ b: c.b, label: c.mark }));
// 起止年份与曲线下方的年份刻度（起点、转折、主升浪起止、巅峰、终点）
const YEAR_FROM = parseDate(C[0].date).y;
const YEAR_TO = parseDate(C[C.length - 1].date).y;
const TICK_YEARS = [...new Set([0, 8, 24, 39, 46, C.length - 1].map((i) => parseDate(C[i].date).y))].sort((a, b) => a - b);
const EV = C.filter((c) => c.ev);
const BADGES = C.filter((c) => c.ev && c.ev.badge);
// 整屏特效在爆发拍触发（没有爆发拍的K线在出现时触发）
// 整屏特效在爆发拍触发（没有爆发拍的K线在出现时触发）；持续拍数默认 4 拍（一个乐句）
const FXS = C.filter((c) => c.fx).map((c) => ({ ...c.fx, idx: c.idx, t0: c.fxT0, dur: (c.fx.beats ?? 4) * CONFIG.beatSec }));
const PHASE_BY_KEY = new Map(PHASES.map((p) => [p.key, p]));
// 每个阶段覆盖的K线下标区间
const PHASE_SPAN = new Map();
C.forEach((c, i) => {
  const s = PHASE_SPAN.get(c.phase);
  if (s) s[1] = i;
  else PHASE_SPAN.set(c.phase, [i, i]);
});
// 前缀统计：历史最高、事件数、图章数
const MAX_H = [];
const EV_COUNT = [];
const BADGE_COUNT = [];
C.forEach((c, i) => {
  MAX_H[i] = Math.max(i ? MAX_H[i - 1] : -Infinity, c.h);
  EV_COUNT[i] = (i ? EV_COUNT[i - 1] : 0) + (c.ev ? 1 : 0);
  BADGE_COUNT[i] = (i ? BADGE_COUNT[i - 1] : 0) + (c.ev && c.ev.badge ? 1 : 0);
});

function pathAt(keys, p) {
  if (p <= 0) return keys[0][1];
  for (let k = 1; k < keys.length; k++) {
    if (p <= keys[k][0]) {
      const [p0, v0] = keys[k - 1];
      const [p1, v1] = keys[k];
      return lerp(v0, v1, smooth((p - p0) / (p1 - p0)));
    }
  }
  return keys[keys.length - 1][1];
}

// 当前K线在时刻 t 的实时状态：直接取逐帧采样，影线随实际走势延伸
function liveCandle(cd, t) {
  const i = clamp(Math.round(t * FPS) - cd.f0, 0, cd.px.length - 1);
  return { o: cd.o, c: cd.px[i], h: cd.hi[i], l: cd.lo[i] };
}

function indexAt(t) {
  let k = -1;
  for (let i = 0; i < C.length && C[i].t0 <= t; i++) k = i;
  return k;
}

function maAt(j, n, k, livePrice) {
  let s = 0;
  let cnt = 0;
  for (let i = Math.max(0, j - n + 1); i <= j; i++) {
    s += i === k ? livePrice : C[i].c;
    cnt++;
  }
  return s / cnt;
}

// 横向镜头：新K线出现后 0.24 秒内滑入
function camAt(t, k) {
  return k - 1 + easeOut((t - C[k].t0) / 0.24);
}
function xOf(j, cam) {
  const scroll = Math.max(0, cam * L.spacing - (L.anchorX - L.firstX));
  return L.firstX + j * L.spacing - scroll;
}

// 最近一个仍需显示标注的事件K线（事件后两根K线内）
function calloutIdx(k) {
  const n = EV_COUNT[k];
  if (!n) return -1;
  const e = EV[n - 1].idx;
  return k - e <= 1 ? e : -1;
}

// ===================== 镜头纵向跟随（按帧顺序累积） =====================
const cam = { lo: 0, hi: 1, ready: false };

function targetRange(t, k, camX) {
  let lo = Infinity;
  let hi = -Infinity;
  for (let j = Math.max(0, k - 16); j <= k; j++) {
    const x = xOf(j, camX);
    if (x < L.plotL - L.spacing || x > L.plotR) continue;
    const c = j === k ? liveCandle(C[j], t) : C[j];
    lo = Math.min(lo, c.l);
    hi = Math.max(hi, c.h);
  }
  // 横盘时限制最小振幅，避免小K线被过度放大
  const minSpan = hi * 0.06;
  if (hi - lo < minSpan) {
    const mid = (hi + lo) / 2;
    lo = mid - minSpan / 2;
    hi = mid + minSpan / 2;
  }
  const span = hi - lo;
  // 给事件标注留出空间：上涨事件在上方，下跌事件在下方
  const e = calloutIdx(k);
  const down = e >= 0 && !C[e].up;
  return down ? [lo - span * 0.28, hi + span * 0.2] : [lo - span * 0.14, hi + span * 0.3];
}

function stepCamera(t, dt) {
  const k = indexAt(t);
  if (k < 0) return;
  const [lo, hi] = targetRange(t, k, camAt(t, k));
  if (!cam.ready) {
    Object.assign(cam, { lo, hi, ready: true });
    return;
  }
  const a = 1 - Math.exp(-dt / CONFIG.cameraTau);
  cam.lo += (lo - cam.lo) * a;
  cam.hi += (hi - cam.hi) * a;
}

// 节拍脉冲：按配乐段落的强度每拍闪一下，无鼓段为 0
function sectionGain(bi) {
  const s = SECTIONS.find((x) => bi >= x.from && bi < x.to);
  return s ? s.gain : 0;
}
function beatPulse(t) {
  const b = (t - CONFIG.beat0) / CONFIG.beatSec;
  const bi = Math.floor(b);
  const gain = sectionGain(bi);
  return gain ? gain * Math.exp(-((b - bi) * CONFIG.beatSec) / 0.13) : 0;
}

// 紧张度 0~1：在 TENSION 区间内逐拍升高，区间结束（重拍到来）时归零
function tensionAt(t) {
  const b = (t - CONFIG.beat0) / CONFIG.beatSec;
  const r = TENSION.find((x) => b >= x.from && b < x.to);
  return r ? smooth((b - r.from) / (r.to - r.from)) * r.peak : 0;
}

// “大涨音乐”段的强度 0~1：段首 0.35 秒淡入，段尾 0.6 秒淡出
function riseAt(t) {
  let v = 0;
  for (const s of SECTIONS) {
    if (s.rise) v = Math.max(v, ramp(t, bt(s.from) - 0.05, 0.35) * (1 - ramp(t, bt(s.to) - 0.5, 0.6)));
  }
  return v;
}

// 上升粒子：位置与速度由固定种子生成，保证每次渲染一致
const PARTICLES = (() => {
  const rng = mulberry32(CONFIG.seed + 7);
  return Array.from({ length: 46 }, () => ({
    x: L.plotL + rng() * (L.plotR - L.plotL),
    speed: 70 + rng() * 150,
    size: 1.6 + rng() * 2.6,
    phase: rng() * 1000,
    gold: rng() < 0.35,
  }));
})();

function drawRise(ctx, t, amt, pulse) {
  // 图区底部的红色氛围光，随节拍呼吸
  const h = 420;
  const g = ctx.createLinearGradient(0, L.plotB, 0, L.plotB - h);
  g.addColorStop(0, `rgba(255,40,40,${(0.16 + 0.1 * pulse) * amt})`);
  g.addColorStop(1, 'rgba(255,40,40,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, L.plotB - h, W, h);
  // 自下而上飘升的光点
  const span = L.plotB - L.plotT;
  ctx.save();
  for (const p of PARTICLES) {
    const y = L.plotB - ((p.phase + t * p.speed) % span);
    const fade = Math.min(1, (L.plotB - y) / 120) * Math.min(1, (y - L.plotT) / 160);
    ctx.globalAlpha = 0.55 * amt * fade;
    ctx.fillStyle = p.gold ? '#ffc35a' : '#ff5a4a';
    ctx.beginPath();
    ctx.arc(p.x + Math.sin(t * 1.3 + p.phase) * 8, y, p.size * (1 + 0.4 * pulse), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function shakeAt(t) {
  let amp = 0;
  for (const fx of FXS) {
    const a = t - fx.t0;
    if (a >= 0 && a < 0.7) amp += (SHAKE[fx.type] || 0) * Math.exp(-a / 0.12);
  }
  if (amp < 0.4) return [0, 0];
  const n = t * 61;
  return [amp * Math.sin(n * 1.7) * Math.cos(n * 0.37), amp * 0.8 * Math.cos(n * 1.31)];
}

// ===================== 绘制工具 =====================
function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function triangle(ctx, cx, cy, size, up, color) {
  ctx.beginPath();
  if (up) {
    ctx.moveTo(cx, cy - size);
    ctx.lineTo(cx + size, cy + size * 0.8);
    ctx.lineTo(cx - size, cy + size * 0.8);
  } else {
    ctx.moveTo(cx, cy + size);
    ctx.lineTo(cx + size, cy - size * 0.8);
    ctx.lineTo(cx - size, cy - size * 0.8);
  }
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

// 带字距的文字
function spacedText(ctx, str, x, y, spacing, align) {
  const chars = [...str];
  const widths = chars.map((ch) => ctx.measureText(ch).width);
  const total = widths.reduce((a, b) => a + b, 0) + spacing * (chars.length - 1);
  let cx = align === 'center' ? x - total / 2 : x;
  ctx.textAlign = 'left';
  chars.forEach((ch, i) => {
    ctx.fillText(ch, cx, y);
    cx += widths[i] + spacing;
  });
  return total;
}

// 多色文字片段居中：segs = [[文字, 颜色, 发光半径, 字体], ...]，未指定字体时沿用当前字体
function richCenter(ctx, segs, cx, y) {
  const base = ctx.font;
  const ws = segs.map(([s, , , font]) => {
    ctx.font = font || base;
    return ctx.measureText(s).width;
  });
  let x = cx - ws.reduce((a, b) => a + b, 0) / 2;
  ctx.textAlign = 'left';
  segs.forEach(([s, color, glow, font], i) => {
    ctx.save();
    ctx.font = font || base;
    if (glow) {
      ctx.shadowColor = color;
      ctx.shadowBlur = glow;
    }
    ctx.fillStyle = color;
    ctx.fillText(s, x, y);
    ctx.restore();
    x += ws[i];
  });
  ctx.font = base;
}

function pill(ctx, text, x, cy, fontStr, align) {
  ctx.font = fontStr;
  const w = ctx.measureText(text).width + 32;
  const left = align === 'center' ? x - w / 2 : x - w;
  rr(ctx, left, cy - 24, w, 48, 6);
  ctx.fillStyle = '#19202b';
  ctx.fill();
  ctx.fillStyle = '#d5dae4';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, left + 16, cy + 1);
  ctx.textBaseline = 'alphabetic';
}

function dashedLine(ctx, x0, y, x1, color, width, dash) {
  ctx.save();
  ctx.setLineDash(dash);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(x0, y);
  ctx.lineTo(x1, y);
  ctx.stroke();
  ctx.restore();
}

function niceStep(range, n) {
  const raw = range / n;
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / p;
  return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
}

function drawBg(ctx) {
  ctx.fillStyle = COLOR.bg;
  ctx.fillRect(0, 0, W, H);
  const g = ctx.createRadialGradient(540, 760, 80, 540, 900, 1250);
  g.addColorStop(0, 'rgba(46,66,120,0.12)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

// ===================== 顶部行情区 =====================
function drawHeader(ctx, t, k, live, pulse) {
  const cd = C[k];
  const ph = PHASE_BY_KEY.get(cd.phase);
  const prevClose = k > 0 ? C[k - 1].c : cd.o;
  const price = live.c;
  const chg = price - prevClose;
  const up = chg >= 0;
  const col = up ? COLOR.up : COLOR.down;

  // 标志与姓名
  rr(ctx, 100, 203, 62, 62, 4);
  ctx.fillStyle = PERSON.logoColor || COLOR.logo;
  ctx.fill();
  ctx.font = F.serif(42);
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(PERSON.logo, 131, 236);
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = 'left';
  ctx.font = F.serif(40);
  ctx.fillStyle = COLOR.text;
  ctx.fillText(PERSON.name, 180, 238);
  ctx.font = F.sans(20);
  ctx.fillStyle = COLOR.dim;
  ctx.fillText(`${PERSON.code} · ${ph.identity}`, 180, 268);

  // 年份、年龄与阶段
  const year = String(parseDate(cd.date).y);
  ctx.font = F.din(84);
  ctx.fillStyle = COLOR.year;
  ctx.fillText(year, 100, 346);
  const yw = ctx.measureText(year).width;
  ctx.font = F.serif(34);
  ctx.fillStyle = COLOR.text;
  const age = ageOf(cd.date);
  ctx.fillText(age === null ? ph.key : `${age} ${PERSON.ageSuffix || '岁'} · ${ph.key}`, 100 + yw + 22, 314);
  ctx.font = F.sans(21);
  ctx.fillStyle = COLOR.dim;
  ctx.fillText(`${ph.identity} ${PERSON.name}`, 100 + yw + 22, 347);

  // 实时价格（带发光背板，随节拍脉冲）
  const txt = fmt(price, 2);
  ctx.font = F.mono(78);
  const tw = ctx.measureText(txt).width;
  ctx.fillStyle = rgba(col, 0.1 + 0.08 * pulse);
  rr(ctx, 980 - tw - 14, 270, tw + 28, 82, 4);
  ctx.fill();
  ctx.save();
  ctx.shadowColor = rgba(col, 0.85);
  ctx.shadowBlur = 16 + 18 * pulse;
  ctx.fillStyle = col;
  ctx.textAlign = 'right';
  ctx.fillText(txt, 980, 336);
  ctx.restore();

  // 涨跌幅
  ctx.font = F.mono(24);
  ctx.fillStyle = col;
  ctx.textAlign = 'right';
  const absTxt = `${up ? '+' : '-'}${fmt(Math.abs(chg), 1)}`;
  const pctTxt = `${up ? '+' : '-'}${Math.abs((chg / prevClose) * 100).toFixed(2)}%`;
  ctx.fillText(absTxt, 980, 380);
  const aw = ctx.measureText(absTxt).width;
  ctx.fillText(pctTxt, 980 - aw - 34, 380);
  const pw = ctx.measureText(pctTxt).width;
  triangle(ctx, 980 - aw - 34 - pw - 20, 372, 9, up, col);

  // 历史最高 / 较发行价
  ctx.textAlign = 'left';
  let x = 100;
  const hiTxt = fmt(Math.max(k ? MAX_H[k - 1] : 0, live.h), 0);
  const vs = (price / 100 - 1) * 100;
  const vsTxt = `${vs >= 0 ? '+' : ''}${fmt(vs, 0)}%`;
  for (const [label, val, color] of [['历史最高', hiTxt, COLOR.text], ['较发行价', vsTxt, vs >= 0 ? COLOR.up : COLOR.down]]) {
    ctx.font = F.sans(21);
    ctx.fillStyle = COLOR.dim;
    ctx.fillText(label, x, 397);
    x += ctx.measureText(label).width + 12;
    ctx.font = F.mono(21);
    ctx.fillStyle = color;
    ctx.fillText(val, x, 397);
    x += ctx.measureText(val).width + 44;
  }

  // 分隔线与整体进度
  ctx.fillStyle = '#18202d';
  ctx.fillRect(0, 409, W, 2);
  const prog = clamp((t - C[0].t0) / (bt(CONFIG.endingBeat) - C[0].t0), 0, 1);
  ctx.fillStyle = COLOR.blue;
  ctx.fillRect(0, 408, W * prog, 4);
}

// ===================== K线图区 =====================
function drawChart(ctx, t, k, live, camX, pulse) {
  const { lo, hi } = cam;
  const yOf = (v) => L.plotB - ((v - lo) / (hi - lo)) * (L.plotB - L.plotT);
  const first = Math.max(0, k - 16);
  const xc = xOf(k, camX);

  // 标题行：指数名称、均线数值、红涨绿跌
  ctx.textAlign = 'left';
  ctx.font = F.sans(22, 700);
  ctx.fillStyle = '#e6e9ef';
  const indexTitle = `${PERSON.indexName || '人生指数'} · 年K`;
  ctx.fillText(indexTitle, 100, 452);
  let x = 100 + ctx.measureText(indexTitle).width + 26;
  ctx.font = F.mono(19);
  for (const [n, color] of [[5, COLOR.ma5], [20, COLOR.ma20]]) {
    const s = `MA${n} ${fmt(maAt(k, n, k, live.c), 1)}`;
    ctx.fillStyle = color;
    ctx.fillText(s, x, 452);
    x += ctx.measureText(s).width + 26;
  }
  ctx.font = F.sans(20);
  ctx.fillStyle = '#6b7385';
  ctx.textAlign = 'right';
  ctx.fillText('红涨 绿跌', 980, 452);

  // 背景水印
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 414, W, 730);
  ctx.clip();
  ctx.font = F.serif(640);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(255,255,255,0.028)';
  ctx.fillText(PERSON.watermark, 470, 800);
  ctx.restore();

  // “大涨音乐”段：底部红色氛围光 + 上升粒子
  const rise = riseAt(t);
  if (rise > 0) drawRise(ctx, t, rise, pulse);

  // 网格与刻度
  const step = niceStep(hi - lo, 4);
  const ticks = [];
  // 用整数倍生成刻度，避免浮点累加误差；+0 把 -0 规整为 0
  for (let n = Math.ceil(lo / step); n * step <= hi; n++) ticks.push(n * step + 0);
  ctx.fillStyle = '#131924';
  for (const v of ticks) ctx.fillRect(L.plotL, Math.round(yOf(v)), L.plotR - L.plotL, 1);

  ctx.save();
  ctx.beginPath();
  ctx.rect(0, L.plotT - 12, L.plotR, L.plotB - L.plotT + 12);
  ctx.clip();

  // 当前K线高亮列
  ctx.fillStyle = `rgba(255,255,255,${0.035 + 0.035 * pulse})`;
  ctx.fillRect(xc - 32, L.plotT - 12, 64, L.plotB - L.plotT + 12);

  // 发行价虚线
  if (lo < 100 && hi > 100) {
    const y = yOf(100);
    dashedLine(ctx, L.plotL, y, L.plotR, 'rgba(91,123,213,0.75)', 2, [8, 7]);
    ctx.font = F.sans(20, 700);
    const lw = ctx.measureText('发行价 100.00').width;
    ctx.fillStyle = 'rgba(9,12,18,0.78)';
    ctx.fillRect(54, y - 32, lw + 12, 28);
    ctx.fillStyle = '#6f8fe0';
    ctx.textAlign = 'left';
    ctx.fillText('发行价 100.00', 60, y - 11);
  }

  // 均线
  for (const [n, color, width] of [[20, rgba(COLOR.ma20, 0.8), 2.2], [5, COLOR.ma5, 2.6]]) {
    ctx.beginPath();
    for (let j = first; j <= k; j++) {
      const px = xOf(j, camX);
      const py = yOf(maAt(j, n, k, live.c));
      if (j === first) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  // K线
  for (let j = first; j <= k; j++) {
    const px = xOf(j, camX);
    if (px < L.plotL - L.spacing || px > L.plotR + L.spacing) continue;
    const c = j === k ? live : C[j];
    const up = c.c >= c.o;
    const col = up ? COLOR.up : COLOR.down;
    const pop = j === k ? easeOutBack(ramp(t, C[j].t0, 0.16)) : 1;
    const bw = L.bodyW * (0.55 + 0.45 * pop);
    const yo = yOf(c.o);
    const yc = yOf(c.c);
    const top = Math.min(yo, yc);
    const hgt = Math.max(4, Math.abs(yc - yo));
    ctx.save();
    if (j === k) {
      ctx.shadowColor = rgba(col, 0.8);
      ctx.shadowBlur = 8 + 18 * pulse;
    }
    ctx.strokeStyle = col;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(px, yOf(c.h));
    ctx.lineTo(px, top);
    ctx.moveTo(px, top + hgt);
    ctx.lineTo(px, yOf(c.l));
    ctx.stroke();
    if (up) {
      ctx.fillStyle = 'rgba(255,59,59,0.22)';
      ctx.fillRect(px - bw / 2, top, bw, hgt);
      ctx.strokeRect(px - bw / 2 + 1.5, top + 1.5, bw - 3, hgt - 3);
    } else {
      ctx.fillStyle = col;
      ctx.fillRect(px - bw / 2, top, bw, hgt);
    }
    ctx.restore();
  }
  ctx.restore();

  // 右侧刻度
  ctx.font = F.mono(20);
  ctx.fillStyle = '#6b7385';
  ctx.textAlign = 'left';
  const dec = step >= 1 ? 0 : step >= 0.1 ? 1 : 2;
  for (const v of ticks) {
    const y = yOf(v);
    if (y > L.plotT + 8 && y < L.plotB - 2) ctx.fillText(fmt(v, dec), L.axisX, y + 7);
  }

  // 现价虚线与价格标签
  const liveCol = live.c >= live.o ? COLOR.up : COLOR.down;
  const yp = clamp(yOf(live.c), L.plotT + 14, L.plotB - 14);
  dashedLine(ctx, xc + 26, yp, L.plotR + 4, rgba(liveCol, 0.75), 2, [5, 5]);
  ctx.font = F.mono(20);
  const tag = fmt(live.c, 1);
  const tagW = ctx.measureText(tag).width + 16;
  ctx.fillStyle = liveCol;
  ctx.fillRect(906, yp - 15, tagW, 30);
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'left';
  ctx.fillText(tag, 914, yp + 7);

  drawPhaseBand(ctx, k, camX);
  drawCallout(ctx, t, k, live, camX, yOf);
  drawBadges(ctx, t, k);
}

// 底部阶段条：只画到当前K线为止
function drawPhaseBand(ctx, k, camX) {
  const curKey = C[k].phase;
  for (const [key, [i0, i1]] of PHASE_SPAN) {
    if (i0 > k) continue;
    const xa = xOf(i0, camX) - L.spacing / 2 + 2;
    const xb = xOf(Math.min(i1, k), camX) + L.spacing / 2 - 2;
    const a = Math.max(L.plotL, xa);
    const b = Math.min(L.bandR, xb);
    if (b - a < 4) continue;
    const cur = key === curKey;
    ctx.fillStyle = cur ? '#2b3d63' : '#141a26';
    ctx.fillRect(a, L.bandT, b - a, L.bandB - L.bandT);
    if (b - a > 46) {
      ctx.font = F.sans(20, 700);
      ctx.fillStyle = cur ? '#ffffff' : '#6b7385';
      ctx.textAlign = 'center';
      ctx.fillText(key, (a + b) / 2, L.bandB - 9);
    }
    if (xa >= L.plotL - 1 && xa < L.bandR - 40) {
      ctx.font = F.mono(17);
      ctx.fillStyle = '#4d5566';
      ctx.textAlign = 'left';
      ctx.fillText(String(parseDate(C[i0].date).y), xa + 6, 1132);
    }
  }
}

// 左上角事件图章：最多 4 个，新图章弹出、旧图章左移
function drawBadges(ctx, t, k) {
  const n = BADGE_COUNT[k];
  if (!n) return;
  const list = BADGES.slice(Math.max(0, n - 5), n);
  const newest = list[list.length - 1];
  const u = easeOut((t - newest.t0) / 0.28);
  const shifting = n > 4;
  list.forEach((b, i) => {
    const r = list.length - 1 - i; // 0 为最新
    let slot = shifting ? 3 - r + (r > 0 ? 1 - u : 0) : n - 1 - r;
    let alpha = 1;
    if (r === 0) alpha = u;
    if (shifting && r === 4) alpha = 1 - u;
    if (r > 4 || alpha <= 0.01) return;
    const x = 108 + slot * 84;
    const y = 478;
    const col = b.up ? COLOR.up : COLOR.down;
    const s = r === 0 ? easeOutBack((t - b.t0) / 0.28) : 1;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(x + 31, y + 31);
    ctx.scale(s, s);
    ctx.fillStyle = rgba(col, 0.16);
    ctx.fillRect(-31, -31, 62, 62);
    ctx.strokeStyle = col;
    ctx.lineWidth = 2.5;
    ctx.strokeRect(-30, -30, 60, 60);
    ctx.strokeStyle = rgba(col, 0.45);
    ctx.lineWidth = 1;
    ctx.strokeRect(-25, -25, 50, 50);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = b.ev.badge.length > 1 ? F.sans(26, 900) : F.serif(36);
    ctx.fillText(b.ev.badge, 0, 2);
    ctx.textBaseline = 'alphabetic';
    ctx.font = F.sans(15);
    ctx.fillStyle = '#8a93a6';
    ctx.fillText(b.ev.cap, 0, 56);
    ctx.restore();
  });
}

// 事件标注框：上涨在K线上方、下跌在K线下方，箭头指向K线
function drawCallout(ctx, t, k, live, camX, yOf) {
  const e = calloutIdx(k);
  if (e < 0) return;
  const ec = C[e];
  const c = e === k ? live : ec;
  let alpha = easeOut((t - ec.t0) / 0.2);
  if (k > e) alpha *= 1 - ramp(t, C[e + 1].t0 + 0.35, 0.3);
  // 整屏大字特效期间先让位（特效在爆发拍触发），特效收尾后再出现
  const fx = ec.fx;
  if (fx && ['rebound', 'flashUp', 'flashDown', 'stamp'].includes(fx.type)) {
    const fxEnd = ec.fxT0 + (fx.beats ?? 4) * CONFIG.beatSec * 0.86;
    alpha *= 1 - ramp(t, ec.fxT0 - 0.06, 0.08) * (1 - ramp(t, fxEnd, 0.2));
  }
  if (alpha <= 0.01) return;
  const col = ec.up ? COLOR.up : COLOR.down;
  const x = xOf(e, camX);
  const tag = ec.ev.tag;
  ctx.font = F.sans(30, 700);
  const tw = ctx.measureText(ec.ev.t).width;
  ctx.font = F.mono(18);
  const dw = ctx.measureText(ec.date).width;
  ctx.font = F.sans(18, 700);
  const tagW = tag ? ctx.measureText(tag).width + 18 : 0;
  const bh = 64;
  const bw = 18 + (tag ? tagW + 12 : 0) + tw + 14 + dw + 18;
  const by = ec.up
    ? clamp(yOf(c.h) - 26 - bh, L.plotT + 6, L.plotB - bh - 6)
    : clamp(yOf(c.l) + 26, L.plotT + 6, L.plotB - bh - 6);
  let bx = clamp(Math.min(x + 90, L.plotR - 8) - bw, L.plotL + 8, L.plotR - 8 - bw);
  // 与左上角图章区域重叠时向右让开
  const nb = Math.min(4, BADGE_COUNT[k]);
  if (nb && by < 572) bx = clamp(Math.max(bx, 108 + nb * 84 - 10), L.plotL + 8, L.plotR - 8 - bw);
  const slide = (1 - easeOut((t - ec.t0) / 0.2)) * 14;

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(0, ec.up ? -slide : slide);
  // 主力进场 / 上市：整条发光横线
  if (fx && fx.type === 'glow') {
    // 爆发前横线暗着，爆发拍上点亮后缓慢回落
    const since = t - ec.fxT0;
    const g = since < 0 ? 0.35 : 0.55 + 0.45 * Math.exp(-since / 0.5);
    ctx.save();
    ctx.shadowColor = col;
    ctx.shadowBlur = 22 * g;
    ctx.fillStyle = rgba(col, 0.9 * g);
    ctx.fillRect(L.plotL, by + bh - 2, L.plotR - L.plotL, 3);
    ctx.restore();
  }
  ctx.fillStyle = 'rgba(13,17,25,0.94)';
  ctx.fillRect(bx, by, bw, bh);
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.lineWidth = 1;
  ctx.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
  ctx.fillStyle = col;
  ctx.fillRect(bx, by + bh - 3, bw, 3);
  // 指向K线的小三角
  const ax = clamp(x, bx + 14, bx + bw - 14);
  if (ec.up) triangle(ctx, ax, by + bh + 7, 7, false, col);
  else triangle(ctx, ax, by - 7, 7, true, col);
  let tx = bx + 18;
  if (tag) {
    ctx.fillStyle = col;
    ctx.fillRect(tx, by + 15, tagW, 32);
    ctx.font = F.sans(18, 700);
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.fillText(tag, tx + 9, by + 38);
    tx += tagW + 12;
  }
  ctx.font = F.sans(30, 700);
  ctx.fillStyle = COLOR.text;
  ctx.textAlign = 'left';
  ctx.fillText(ec.ev.t, tx, by + 43);
  ctx.font = F.mono(18);
  ctx.fillStyle = col;
  ctx.fillText(ec.date, tx + tw + 14, by + 42);
  ctx.restore();
}

// ===================== 底部身份与大事记 =====================
function drawBottom(ctx, t, k) {
  const cd = C[k];
  const ph = PHASE_BY_KEY.get(cd.phase);
  const [p0, p1] = PHASE_SPAN.get(cd.phase);

  ctx.fillStyle = COLOR.panel;
  ctx.fillRect(80, 1158, 920, 640);
  ctx.fillStyle = COLOR.blue;
  ctx.fillRect(92, 1150, 30, 3);
  ctx.fillRect(958, 1150, 30, 3);

  ctx.textAlign = 'left';
  ctx.font = F.sans(21);
  ctx.fillStyle = COLOR.dim;
  ctx.fillText('当前身份', 120, 1208);
  // 身份切换：淡入并轻微右滑
  const u = easeOut((t - C[p0].t0) / 0.32);
  ctx.save();
  ctx.globalAlpha = u;
  ctx.font = F.serif(58);
  ctx.fillStyle = COLOR.text;
  const ix = 120 + (1 - u) * 24;
  ctx.fillText(ph.identity, ix, 1274);
  const iw = ctx.measureText(ph.identity).width;
  ctx.font = F.sans(26);
  ctx.fillStyle = '#6b7385';
  ctx.fillText(PERSON.name, ix + iw + 22, 1270);
  ctx.restore();
  pill(ctx, '内容仅作科普，不构成投资建议', 980, 1252, F.sans(23, 700), 'right');

  // 阶段内进度
  const prog = clamp((t - C[p0].t0) / (C[p1].t1 - C[p0].t0), 0, 1);
  ctx.fillStyle = '#1a2130';
  ctx.fillRect(120, 1302, 840, 3);
  ctx.fillStyle = COLOR.blue;
  ctx.fillRect(120, 1301, 840 * prog, 5);

  ctx.font = F.sans(22, 700);
  ctx.fillStyle = COLOR.blueLight;
  ctx.fillText('大事记', 120, 1352);

  const n = EV_COUNT[k];
  if (!n) return;
  const latest = EV[n - 1];
  const a = easeOut((t - latest.t0) / 0.32);
  // 历史事件行：从上一位置滑到新位置
  const rowY = (r) => (r === 0 ? 1418 : 1512 + (r - 1) * 58);
  const fades = [1, 0.95, 0.62, 0.36, 0];
  for (let r = 4; r >= 1; r--) {
    const e = EV[n - 1 - r];
    if (!e) continue;
    const y = lerp(rowY(r - 1), rowY(r), a);
    const alpha = lerp(fades[r - 1], fades[r], a);
    if (alpha <= 0.01) continue;
    const col = e.up ? COLOR.up : COLOR.down;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.font = F.mono(19);
    ctx.fillStyle = rgba(col, 0.6);
    ctx.fillText(e.date, 124, y);
    ctx.font = F.sans(28, 700);
    ctx.fillStyle = '#a7afbf';
    ctx.fillText(e.ev.t, 296, y + 2);
    ctx.restore();
  }
  // 当前事件高亮行
  const col = latest.up ? COLOR.up : COLOR.down;
  ctx.save();
  ctx.globalAlpha = a;
  ctx.fillStyle = '#121824';
  ctx.fillRect(96, 1366, 889, 110);
  ctx.fillStyle = col;
  ctx.fillRect(96, 1366, 5, 110);
  const sx = (1 - a) * 30;
  ctx.font = F.mono(20);
  ctx.fillStyle = col;
  ctx.fillText(latest.date, 120 + sx, 1402);
  ctx.font = F.sans(32, 900);
  ctx.fillStyle = COLOR.text;
  ctx.fillText(latest.ev.t, 292 + sx, 1410);
  ctx.font = F.sans(23);
  ctx.fillStyle = COLOR.dim;
  ctx.fillText(latest.ev.d, 292 + sx, 1454);
  ctx.restore();
}

// ===================== 整屏特效 =====================
function fxFlash(ctx, a, u, fx, color, size) {
  // 图区染色闪屏
  const flash = 0.6 * Math.exp(-a / 0.22) + 0.16 * (1 - u);
  const g = ctx.createRadialGradient(540, 760, 60, 540, 760, 720);
  g.addColorStop(0, rgba(color, flash));
  g.addColorStop(1, rgba(color, flash * 0.35));
  ctx.fillStyle = g;
  ctx.fillRect(0, 412, W, 736);
  // 大字：缩放冲击 + 红青错位
  const alpha = u < 0.8 ? 1 : 1 - (u - 0.8) / 0.2;
  const s = 1 + 0.42 * Math.exp(-a / 0.07);
  const dx = 18 * Math.exp(-a / 0.1);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(540, 712);
  ctx.scale(s, s);
  ctx.font = F.serif(size);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(0,255,240,0.5)';
  ctx.fillText(fx.text, dx, 0);
  ctx.fillStyle = 'rgba(255,0,90,0.5)';
  ctx.fillText(fx.text, -dx, 0);
  const grad = ctx.createLinearGradient(0, -size / 2, 0, size / 2);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.55, color);
  grad.addColorStop(1, color);
  ctx.shadowColor = color;
  ctx.shadowBlur = 40;
  ctx.fillStyle = grad;
  ctx.fillText(fx.text, 0, 0);
  ctx.shadowBlur = 0;
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgba(255,255,255,0.5)';
  ctx.strokeText(fx.text, 0, 0);
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = alpha * easeOut(a / 0.25);
  ctx.font = F.sans(30, 700);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0,0,0,0.85)';
  ctx.shadowBlur = 12;
  ctx.fillText(fx.sub, 540, 846);
  ctx.restore();
}

function fxTitle(ctx, a, u, fx) {
  const appear = easeOut(a / 0.22);
  const alpha = appear * (u < 0.8 ? 1 : 1 - (u - 0.8) / 0.2);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.textAlign = 'left';
  ctx.font = F.serif(150);
  ctx.shadowColor = 'rgba(255,255,255,0.35)';
  ctx.shadowBlur = 26;
  ctx.fillStyle = '#f5f7fb';
  ctx.fillText(fx.text, 84 - (1 - appear) * 40, 800);
  ctx.shadowColor = 'rgba(0,0,0,0.9)';
  ctx.shadowBlur = 10;
  ctx.font = F.sans(28, 700);
  ctx.fillStyle = '#dfe4ee';
  ctx.fillText(fx.sub, 92, 856);
  ctx.restore();
}

function fxStamp(ctx, a, u, fx) {
  const color = fx.color === 'red' ? COLOR.up : '#eef0f4';
  const s = a < 0.16 ? lerp(2.6, 1, easeOut(a / 0.16)) : 1 + 0.035 * Math.exp(-(a - 0.16) / 0.12) * Math.sin((a - 0.16) * 55);
  const alpha = clamp(a / 0.08, 0, 1) * (u < 0.85 ? 1 : 1 - (u - 0.85) / 0.15);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(540, 730);
  ctx.rotate(-0.16);
  ctx.scale(s, s);
  ctx.font = F.serif(128);
  const bw = ctx.measureText(fx.text).width + 96;
  const bh = 184;
  rr(ctx, -bw / 2, -bh / 2, bw, bh, 12);
  ctx.fillStyle = 'rgba(10,12,16,0.84)';
  ctx.fill();
  ctx.lineWidth = 9;
  ctx.strokeStyle = color;
  ctx.stroke();
  rr(ctx, -bw / 2 + 14, -bh / 2 + 14, bw - 28, bh - 28, 6);
  ctx.lineWidth = 2.5;
  ctx.stroke();
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(fx.text, 0, 8);
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = alpha * easeOut((a - 0.12) / 0.25);
  ctx.font = F.sans(30, 700);
  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffffff';
  ctx.shadowColor = 'rgba(0,0,0,0.9)';
  ctx.shadowBlur = 12;
  ctx.fillText(fx.sub, 540, 898);
  ctx.restore();
}

// 暴风雨前的宁静：四周压暗 + 每拍一次心跳暗角
function fxSpot(ctx, t, a, u, x, y) {
  const fade = easeOut(a / 0.4) * (u < 0.92 ? 1 : 1 - (u - 0.92) / 0.08);
  const g = ctx.createRadialGradient(x, y, 80, x, y, 640);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, `rgba(0,0,0,${0.58 * fade})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  const b = Math.floor((t - CONFIG.beat0) / CONFIG.beatSec);
  const hb = Math.exp(-(t - bt(b)) / 0.16) * 0.32 * fade;
  const v = ctx.createRadialGradient(540, 960, 360, 540, 960, 1150);
  v.addColorStop(0, 'rgba(255,30,30,0)');
  v.addColorStop(1, `rgba(255,30,30,${hb})`);
  ctx.fillStyle = v;
  ctx.fillRect(0, 0, W, H);
}

function drawFx(ctx, t, k, live, camX) {
  for (const fx of FXS) {
    const a = t - fx.t0;
    if (a < 0 || a > fx.dur) continue;
    const u = a / fx.dur;
    if (fx.type === 'rebound' || fx.type === 'flashUp') fxFlash(ctx, a, u, fx, COLOR.up, fx.text.length > 3 ? 160 : 190);
    else if (fx.type === 'flashDown') fxFlash(ctx, a, u, fx, COLOR.down, 200);
    else if (fx.type === 'title') fxTitle(ctx, a, u, fx);
    else if (fx.type === 'stamp') fxStamp(ctx, a, u, fx);
    else if (fx.type === 'spot') {
      const yOf = (v) => L.plotB - ((v - cam.lo) / (cam.hi - cam.lo)) * (L.plotB - L.plotT);
      fxSpot(ctx, t, a, u, xOf(k, camX), clamp(yOf(live.c), L.plotT, L.plotB));
    } else if (fx.type === 'glow') {
      // 主力进场 / 上市：图区短促红闪
      const peak = fx.flash ? 0.5 : 0.3;
      ctx.fillStyle = rgba(COLOR.up, peak * Math.exp(-a / 0.18));
      ctx.fillRect(0, 412, W, 736);
    }
  }
}

// ===================== 片头 =====================
function lifeCurvePoints(x0, x1, y0, y1) {
  const logs = C.map((c) => Math.log10(c.c));
  const lo = Math.min(...logs) - 0.12;
  const hi = Math.max(...logs) + 0.08;
  return C.map((c, i) => ({
    x: lerp(x0, x1, i / (C.length - 1)),
    y: lerp(y1, y0, (logs[i] - lo) / (hi - lo)),
    up: i === 0 || c.c >= C[i - 1].c,
  }));
}

// 按进度绘制人生曲线（colored=true 时红绿分段，否则白色发光线）
function drawCurve(ctx, pts, prog, baseY, colored) {
  const upto = prog * (pts.length - 1);
  const last = Math.floor(upto);
  const path = pts.slice(0, last + 1);
  if (last + 1 < pts.length && upto > last) {
    const f = upto - last;
    const p0 = pts[last];
    const p1 = pts[last + 1];
    path.push({ x: lerp(p0.x, p1.x, f), y: lerp(p0.y, p1.y, f), up: p1.up });
  }
  const end = path[path.length - 1];
  if (path.length >= 2) {
    const g = ctx.createLinearGradient(0, Math.min(...pts.map((p) => p.y)), 0, baseY);
    g.addColorStop(0, 'rgba(255,255,255,0.17)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.beginPath();
    ctx.moveTo(path[0].x, baseY);
    for (const p of path) ctx.lineTo(p.x, p.y);
    ctx.lineTo(end.x, baseY);
    ctx.closePath();
    ctx.fillStyle = g;
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    if (colored) {
      for (let i = 1; i < path.length; i++) {
        ctx.beginPath();
        ctx.moveTo(path[i - 1].x, path[i - 1].y);
        ctx.lineTo(path[i].x, path[i].y);
        ctx.strokeStyle = path[i].up ? COLOR.up : COLOR.down;
        ctx.stroke();
      }
    } else {
      ctx.save();
      ctx.shadowColor = 'rgba(255,255,255,0.7)';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.moveTo(path[0].x, path[0].y);
      for (const p of path) ctx.lineTo(p.x, p.y);
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();
      ctx.restore();
    }
  }
  ctx.save();
  ctx.shadowColor = '#ffffff';
  ctx.shadowBlur = 18;
  ctx.beginPath();
  ctx.arc(end.x, end.y, 6, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.restore();
}

// 年份刻度：取每个年份第一次出现的K线位置；与上一个刻度太近（< 64px）的跳过，最后一个年份始终保留
function yearTicks(pts, years) {
  const all = years.map((yr) => {
    const i = C.findIndex((c) => parseDate(c.date).y >= yr);
    return { yr, x: pts[Math.max(0, i)].x };
  });
  const out = [];
  all.forEach((tk, i) => {
    const last = i === all.length - 1;
    if (out.length && tk.x - out[out.length - 1].x < 64) {
      if (!last) return;
      out.pop();
    }
    out.push(tk);
  });
  return out;
}

function drawIntro(ctx, t) {
  const B = bt;
  const out = 1 - ramp(t, B(CONFIG.introEndBeat) - 0.24, 0.24);
  ctx.save();
  ctx.globalAlpha = out;
  ctx.textAlign = 'center';

  // 小标题与两侧短线
  let a = easeOut(ramp(t, 0, 0.35));
  ctx.globalAlpha = out * a;
  ctx.font = F.sans(30, 700);
  ctx.fillStyle = COLOR.blueLight;
  ctx.fillText(PERSON.intro, 540, 240);
  const iw = ctx.measureText(PERSON.intro).width;
  ctx.fillRect(540 - iw / 2 - 74, 229, 52, 2);
  ctx.fillRect(540 + iw / 2 + 22, 229, 52, 2);

  // 如果把 XXX 的经历
  a = easeOut(ramp(t, B(1) - 0.06, 0.3));
  ctx.globalAlpha = out * a;
  ctx.font = F.serif(68);
  richCenter(ctx, [['如果把', '#ffffff'], [PERSON.name, COLOR.up, 18], ['的经历', '#ffffff']], 540, 372 + (1 - a) * 24);

  // 画成K线（重拍冲击）
  a = ramp(t, B(2) - 0.04, 0.18);
  if (a > 0) {
    ctx.save();
    ctx.globalAlpha = out * clamp(a * 2, 0, 1);
    ctx.translate(540, 580);
    const s = lerp(1.55, 1, easeOut(a));
    ctx.scale(s, s);
    ctx.font = F.serif(178);
    richCenter(ctx, [['画成', '#ffffff'], ['K线', COLOR.up, 42]], 0, 0);
    ctx.restore();
  }

  // 会是什么样？
  a = easeOut(ramp(t, B(3) - 0.06, 0.3));
  ctx.globalAlpha = out * a;
  ctx.font = F.serif(70);
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.fillText('会是什么样？', 540, 720 + (1 - a) * 24);

  // 副标题
  a = easeOut(ramp(t, B(4) - 0.1, 0.4));
  ctx.globalAlpha = out * a;
  ctx.font = F.sans(26, 700);
  ctx.fillStyle = '#6f8fd8';
  spacedText(ctx, `${PERSON.name} · 人生K线 · ${YEAR_FROM}—${YEAR_TO}`, 540, 900, 6, 'center');

  // 人生曲线预览
  const pts = lifeCurvePoints(150, 930, 980, 1500);
  const prog = smooth(clamp((t - B(4)) / (B(7.4) - B(4)), 0, 1));
  ctx.globalAlpha = out * clamp((t - B(4)) / 0.2, 0, 1);
  if (prog > 0) drawCurve(ctx, pts, prog, 1500, false);
  ctx.font = F.mono(20);
  ctx.fillStyle = '#5d6679';
  ctx.textAlign = 'center';
  for (const { yr, x } of yearTicks(pts, TICK_YEARS)) ctx.fillText(String(yr), x, 1546);

  // 免责声明
  a = easeOut(ramp(t, B(5), 0.4));
  ctx.globalAlpha = out * a;
  pill(ctx, '内容仅作科普，不构成投资建议', 540, 1640, F.sans(23, 700), 'center');
  ctx.restore();
}

// ===================== 片尾全景 =====================
function drawEnding(ctx, t) {
  const a = t - bt(CONFIG.endingBeat);
  const box = { x0: 130, x1: 960, y0: 560, y1: 1390 };
  const pts = lifeCurvePoints(box.x0, box.x1, box.y0, box.y1);
  const logs = C.map((c) => Math.log10(c.c));
  const lo = Math.min(...logs) - 0.12;
  const hi = Math.max(...logs) + 0.08;
  const yOfLog = (v) => lerp(box.y1, box.y0, (v - lo) / (hi - lo));
  const fadeIn = easeOut(a / 0.35);

  ctx.save();
  ctx.globalAlpha = fadeIn;
  ctx.textAlign = 'center';
  ctx.font = F.serif(78);
  ctx.fillStyle = COLOR.text;
  ctx.fillText('人生K线 · 全景', 540, 340);
  ctx.font = F.sans(24);
  ctx.fillStyle = COLOR.dim;
  ctx.fillText(`${YEAR_FROM} — ${YEAR_TO} · ${PERSON.code} · ${PERSON.name} · 对数坐标`, 540, 402);

  // 对数网格
  ctx.font = F.mono(17);
  for (const v of [100, 1000, 10000, 100000]) {
    const y = yOfLog(Math.log10(v));
    ctx.fillStyle = '#131924';
    ctx.fillRect(box.x0, Math.round(y), box.x1 - box.x0, 1);
    ctx.fillStyle = '#4d5566';
    ctx.textAlign = 'right';
    ctx.fillText(fmt(v, 0), box.x0 - 10, y + 6);
  }
  dashedLine(ctx, box.x0, yOfLog(2), box.x1, 'rgba(91,123,213,0.6)', 2, [8, 7]);

  // 片尾时长随配乐剩余时间自适应：曲线约在前 45% 时间内画完
  const drawDur = Math.min(2.7, (DURATION - bt(CONFIG.endingBeat)) * 0.45);
  const prog = smooth(clamp((a - 0.15) / drawDur, 0, 1));
  drawCurve(ctx, pts, prog, box.y1, true);

  ctx.font = F.mono(20);
  ctx.fillStyle = '#5d6679';
  ctx.textAlign = 'center';
  for (const { yr, x } of yearTicks(pts, TICK_YEARS)) ctx.fillText(String(yr), x, 1436);

  // 关键节点标注：曲线画到时淡入
  ctx.font = F.sans(22, 700);
  for (const m of ENDING_MARKS) {
    const i = C.findIndex((c) => c.b === m.b);
    if (i < 0) throw new Error(`片尾标注找不到第 ${m.b} 拍的K线`);
    const ma = clamp((prog * (C.length - 1) - i) / 3, 0, 1);
    if (ma <= 0) continue;
    const p = pts[i];
    const below = i > 0 && i < C.length - 1 && C[i].c < C[i - 1].c && C[i].c < C[i + 1].c;
    const ly = below ? p.y + 44 : p.y - 26;
    ctx.save();
    ctx.globalAlpha = fadeIn * ma;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.textAlign = clamp(p.x, 200, 880) === p.x ? 'center' : p.x < 200 ? 'left' : 'right';
    ctx.fillStyle = '#dfe4ee';
    ctx.shadowColor = 'rgba(0,0,0,0.9)';
    ctx.shadowBlur = 8;
    ctx.fillText(m.label, p.x, ly);
    ctx.restore();
  }

  // 结论
  const ca = easeOut((a - drawDur * 0.8) / 0.4);
  if (ca > 0) {
    ctx.globalAlpha = fadeIn * ca;
    const last = C[C.length - 1].c;
    ctx.font = F.mono(42);
    ctx.textAlign = 'center';
    richCenter(ctx, [['发行价 ', '#cfd5e1', 0, F.sans(36, 700)], ['100.00  →  ', '#cfd5e1', 0, F.mono(42)], [fmt(last, 2), COLOR.up, 16, F.mono(42)]], 540, 1540);
    ctx.font = F.sans(27, 700);
    ctx.fillStyle = '#dfe4ee';
    ctx.textAlign = 'center';
    ctx.fillText(PERSON.endingNote, 540, 1604);
    pill(ctx, '内容仅作科普，不构成投资建议', 540, 1680, F.sans(23, 700), 'center');
  }
  ctx.restore();
}

// ===================== 帧合成 =====================
function drawMain(ctx, t) {
  const k = indexAt(t);
  const live = liveCandle(C[k], t);
  const camX = camAt(t, k);
  const pulse = beatPulse(t);
  drawHeader(ctx, t, k, live, pulse);
  drawChart(ctx, t, k, live, camX, pulse);
  drawBottom(ctx, t, k);
  drawFx(ctx, t, k, live, camX);
}

function drawFrame(ctx, t) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  drawBg(ctx);
  const tMain = bt(CONFIG.introEndBeat);
  const tEnd = bt(CONFIG.endingBeat);
  if (t < tMain) {
    drawIntro(ctx, t);
    return;
  }
  if (t < tEnd) {
    const [sx, sy] = shakeAt(t);
    const tension = tensionAt(t);
    // 蓄力段镜头缓慢推近，重拍到来时瞬间弹回
    const z = 1 + 0.035 * tension;
    ctx.save();
    ctx.translate(540 + sx, 760 + sy);
    ctx.scale(z, z);
    ctx.translate(-540, -760);
    drawMain(ctx, t);
    ctx.restore();
    if (tension > 0) {
      const g = ctx.createRadialGradient(540, 820, 260, 540, 820, 1150);
      g.addColorStop(0, 'rgba(0,0,0,0)');
      g.addColorStop(1, `rgba(0,0,0,${0.55 * tension})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    // 进出场：以背景色遮罩做淡入淡出
    const veil = Math.max(1 - easeOut(ramp(t, tMain, 0.3)), ramp(t, tEnd - 0.28, 0.28));
    if (veil > 0) {
      ctx.fillStyle = rgba(COLOR.bg, veil);
      ctx.fillRect(0, 0, W, H);
    }
    return;
  }
  drawEnding(ctx, t);
  // 视频最后 0.6 秒淡出
  const fadeOut = ramp(t, DURATION - 0.6, 0.6);
  if (fadeOut > 0) {
    ctx.fillStyle = rgba(COLOR.bg, fadeOut);
    ctx.fillRect(0, 0, W, H);
  }
}

// ===================== 输出 =====================
async function renderVideo(fromSec, toSec, outPath) {
  const total = Math.round(DURATION * FPS);
  const f0 = clamp(Math.floor(fromSec * FPS), 0, total);
  const f1 = clamp(Math.ceil(toSec * FPS), f0, total);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  const args = [
    '-y', '-hide_banner', '-loglevel', 'error',
    '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${W}x${H}`, '-r', String(FPS), '-i', 'pipe:0',
    '-ss', (f0 / FPS).toFixed(3), '-i', CONFIG.music,
    '-map', '0:v', '-map', '1:a:0',
    // 结尾音频淡出（时间相对于本次输出起点）
    '-af', `afade=t=out:st=${Math.max(0, DURATION - MUSIC.fadeOut - f0 / FPS).toFixed(3)}:d=${MUSIC.fadeOut}`,
    '-c:v', 'libx264', '-preset', CONFIG.preset, '-crf', String(CONFIG.crf), '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', outPath,
  ];
  const ff = spawn('ffmpeg', args, { stdio: ['pipe', 'inherit', 'inherit'] });
  const closed = once(ff, 'close');
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  const start = Date.now();
  for (let f = 0; f < f1; f++) {
    const t = f / FPS;
    stepCamera(t, 1 / FPS);
    if (f < f0) continue;
    drawFrame(ctx, t);
    const img = ctx.getImageData(0, 0, W, H);
    if (!ff.stdin.write(Buffer.from(img.data.buffer, img.data.byteOffset, img.data.byteLength))) await once(ff.stdin, 'drain');
    if ((f - f0) % 300 === 0) {
      const done = f - f0 + 1;
      const speed = done / ((Date.now() - start) / 1000);
      console.log(`帧 ${done}/${f1 - f0}  ${speed.toFixed(1)} fps`);
    }
  }
  ff.stdin.end();
  const [code] = await closed;
  if (code !== 0) throw new Error(`ffmpeg 退出码 ${code}`);
  console.log(`完成：${outPath}（${((f1 - f0) / FPS).toFixed(2)} 秒，用时 ${((Date.now() - start) / 1000).toFixed(0)} 秒）`);
}

// 预览默认时刻（序号为第几根K线）：片头、超跌反弹、第一段高潮、大涨音乐（标题/等待/爆发/特效/顶点）、巅峰、留白、崩盘、暴跌段、片尾
function defaultPreviewTimes() {
  const at = (no, dt) => (C[no - 1].boomT ?? C[no - 1].t0) + dt;
  return [
    bt(4) + 0.6, at(9, 0.3), at(20, 1.0), at(25, 0.35), C[30].t0 + 0.4, at(31, 0.25), at(36, 0.35),
    at(40, 0.4), at(47, 1.2), at(48, 1.0), at(49, 0.3), at(56, 0.4), at(60, 0.4), bt(CONFIG.endingBeat) + 3.6,
  ].filter((t) => t < DURATION - 0.05);
}

// 导出预览帧，并用 ffmpeg 拼成一张 sheet.png（每行 7 张）
function renderPreview(times, dir) {
  fs.mkdirSync(dir, { recursive: true });
  for (const f of fs.readdirSync(dir)) if (/^(frame_\d+\.png|sheet\.png)$/.test(f)) fs.rmSync(path.join(dir, f));
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  const sorted = [...times].sort((x, y) => x - y);
  let f = 0;
  sorted.forEach((ts, n) => {
    const target = Math.round(ts * FPS);
    for (; f <= target; f++) stepCamera(f / FPS, 1 / FPS);
    drawFrame(ctx, target / FPS);
    const file = path.join(dir, `frame_${String(n).padStart(3, '0')}.png`);
    fs.writeFileSync(file, canvas.toBuffer('image/png'));
    console.log(`${String(n).padStart(2)}  ${ts.toFixed(2).padStart(6)}s  ${file}`);
  });
  const cols = Math.min(7, sorted.length);
  const sheet = path.join(dir, 'sheet.png');
  const r = spawnSync('ffmpeg', ['-v', 'error', '-y', '-i', path.join(dir, 'frame_%03d.png'),
    '-vf', `scale=360:640,tile=${cols}x${Math.ceil(sorted.length / cols)}`, '-frames:v', '1', sheet], { encoding: 'utf8' });
  if (r.status === 0) console.log(`拼图：${sheet}`);
  else console.warn(`拼图生成失败：${r.stderr}`);
}

// ===================== 校验 =====================
// 涨幅规则：大涨音乐段内每根K线必须大涨；其余段落不出现大涨（climaxHit 段第一拍的超跌反弹除外）
function ruleCheck(c) {
  const pct = (c.c / c.o - 1) * 100;
  const hitBeat = c.b + (c.boom ?? 0);
  const sec = SECTIONS.find((s) => hitBeat >= s.from && hitBeat < s.to);
  let issue = '';
  if (sec.rise && pct < RULES.riseMinPct) issue = `大涨音乐段内涨幅不足 ${RULES.riseMinPct}%`;
  else if (!sec.rise && !(sec.climaxHit && hitBeat === sec.from) && pct > RULES.calmMaxPct) {
    issue = `非大涨音乐段涨幅超过 ${RULES.calmMaxPct}%`;
  }
  return { pct, sec, issue };
}

// 文案长度、空事件、日期顺序等软性提示（不阻断渲染）
function softWarnings() {
  const w = [];
  const lim = (v, n, what) => {
    if (v !== undefined && textLen(v) > n) w.push(`${what}「${v}」超过 ${n} 字，可能显示不下`);
  };
  lim(PERSON.name, 6, 'person.name');
  lim(PERSON.intro, 12, 'person.intro');
  lim(PERSON.endingNote, 30, 'person.endingNote');
  if ([...String(PERSON.logo)].length !== 1) w.push('person.logo 应为 1 个字');
  if ([...String(PERSON.watermark)].length !== 1) w.push('person.watermark 应为 1 个字');
  PHASES.forEach((p) => {
    lim(p.key, 3, '阶段名');
    lim(p.identity, 7, '身份');
  });
  let lastY = 0;
  C.forEach((c, i) => {
    const n = `第 ${i + 1} 根`;
    if (c.ev) {
      lim(c.ev.t, 10, `${n} 事件标题`);
      lim(c.ev.d, 28, `${n} 事件描述`);
      lim(c.ev.tag, 4, `${n} 标签`);
      lim(c.ev.cap, 5, `${n} 图章说明`);
      if (c.ev.badge && [...c.ev.badge].length > 2) w.push(`${n} badge 应为 1-2 个字`);
      if (c.ev.badge && !c.ev.cap) w.push(`${n} 有 badge 时需要 cap`);
    } else if (i !== 23) {
      w.push(`${n} 没有事件（ev），建议每个乐句都配一个事件`);
    }
    if (c.fx) {
      if (FX_TEXT_MAX[c.fx.type]) lim(c.fx.text, FX_TEXT_MAX[c.fx.type], `${n} 特效大字`);
      lim(c.fx.sub, 26, `${n} 特效副标题`);
      if (c.fx.type === 'flashUp' && c.sec !== 'rise') w.push(`${n} flashUp 建议只用在大涨音乐段`);
      if (c.fx.type === 'flashDown' && c.sec !== 'crash') w.push(`${n} flashDown 建议只用在暴跌段`);
    }
    const y = parseDate(c.date).y;
    if (y < lastY) w.push(`${n} 日期 ${c.date} 早于前面的K线`);
    lastY = Math.max(lastY, y);
  });
  return w;
}

const SEC_NAME = { intro: '前奏', build: '无鼓蓄力', rebound: '超跌反弹', drop1: '第一段高潮', rise: '大涨音乐', calm: '平稳段', silence: '留白', crash: '暴跌重鼓' };

// 打印节奏表与校验结果，返回错误数
function printCheck() {
  let bad = 0;
  console.log('序号  拍位      时间    段落        日期        收盘价      涨跌     事件 [特效]');
  for (const c of C) {
    const { pct, issue } = ruleCheck(c);
    if (issue) bad++;
    const fxTxt = c.fx ? ` [${c.fx.type}${c.fx.text ? ':' + c.fx.text : ''}]` : '';
    const beats = `${c.b}-${C[c.idx + 1] ? C[c.idx + 1].b : CONFIG.endingBeat}`;
    const boom = c.boomT !== undefined && c.boom > 0 ? ` 爆发@${c.b + c.boom}拍` : '';
    const pctTxt = `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%`;
    console.log(`${String(c.idx + 1).padStart(2)}  拍${beats.padStart(7)}  ${c.t0.toFixed(2).padStart(6)}s  ${SEC_NAME[c.sec].padEnd(5, '　')}  ${c.date.padEnd(10)} ${fmt(c.c, 2).padStart(11)} ${pctTxt.padStart(8)}  ${c.ev ? c.ev.t : '（无事件）'}${boom}${fxTxt}${issue ? `  <<违规：${issue}` : ''}`);
  }
  const warns = softWarnings();
  if (warns.length) {
    console.log(`\n提示（${warns.length} 条，不阻断渲染）：`);
    warns.forEach((s) => console.log(`  - ${s}`));
  }
  console.log(bad
    ? `\n涨幅规则未通过：${bad} 根K线违规（大涨音乐段每根须 ≥ +${RULES.riseMinPct}%，其余段落单根 ≤ +${RULES.calmMaxPct}%，超跌反弹除外）`
    : `\n检查通过：${C.length} 根K线与配乐乐句一一对应，大涨只出现在大涨音乐段。`);
  return bad;
}

// ===================== 入口 =====================
if (CMD === 'check') {
  process.exit(printCheck() ? 1 : 0);
}
const ruleBad = C.filter((c) => ruleCheck(c).issue);
if (ruleBad.length && !argv.includes('--force')) {
  ruleBad.forEach((c) => console.error(`[涨幅规则] 第 ${c.idx + 1} 根 ${c.date} ${c.ev ? c.ev.t : ''}：${ruleCheck(c).issue}`));
  console.error('涨幅规则未通过，请先运行 check 修正（确需强制渲染可加 --force）');
  process.exit(1);
}
if (!FONTS_OK) console.warn('警告：缺少可用的中文字体，文字可能显示为方框（运行 kline.mjs doctor 查看）');
if (CMD === 'preview') {
  const times = opt('--at') ? opt('--at').split(',').map(Number) : defaultPreviewTimes();
  renderPreview(times, opt('--dir') ? path.resolve(opt('--dir')) : CONFIG.previewDir);
} else {
  const from = Number(opt('--from') || 0);
  const to = Number(opt('--to') || Infinity);
  await renderVideo(from, to, opt('--out') ? path.resolve(opt('--out')) : CONFIG.out);
}
