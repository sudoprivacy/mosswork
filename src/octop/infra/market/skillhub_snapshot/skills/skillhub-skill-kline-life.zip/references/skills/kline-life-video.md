---
name: 人生K线卡点视频
description: PI-Desktop 兼容入口；Codex skill 的正式入口是项目根目录的 SKILL.md。
---

# 兼容入口

本文件保留给旧版 PI-Desktop 插件使用。Codex 应加载项目根目录的 [SKILL.md](../SKILL.md)，详细字段说明见 [references/story-spec.md](../references/story-spec.md)。
