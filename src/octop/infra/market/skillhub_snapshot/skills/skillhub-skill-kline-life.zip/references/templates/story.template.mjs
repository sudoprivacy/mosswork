// 人生K线故事模板：由 kline.mjs new 生成，按注释把所有 TODO 替换为真实内容后运行 check
// 规则（引擎会校验）：
//   1. 必须正好 63 根K线，按顺序对应配乐的 63 个乐句；不要写 b/boom，拍位由引擎自动分配。
//   2. 只有“大涨音乐”（第 25-40 根）大涨，每根 ≥ +30%；其余每根 ≤ +15%；第 9 根“超跌反弹”例外。
//   3. 事件必须真实可查；在世人物的负面事件只写公开报道过的事实，措辞中性；日期不确定时只写年份。
// 字段：
//   person.name 姓名或主题名（≤6字）  logo 左上角方块单字  code 类股票代码「出生年.四字母代号」
//   person.birth 出生年月 'YYYY.M'（主题类写成立年月）  watermark 背景水印单字  intro 片头小标题（≤12字）
//   person.endingNote 片尾结论一句话（≤30字）
//   可选：ageSuffix 年龄后缀（默认“岁”，公司等主题可写“年”）  indexName 指数名（默认“人生指数”）  logoColor 方块颜色
//   phases：人生阶段 { key: 阶段名 ≤3字（显示在阶段条与表头）, identity: 当前身份 ≤7字 }
//   candles 每根：
//     date  'YYYY' / 'YYYY.M' / 'YYYY.M.D'，按时间先后
//     pct   相对上一根收盘价的涨跌幅（%）；也可直接写 c（收盘价）；第 1 根写 o: 100
//     ph    从这根开始进入的阶段（第 1 根必填）
//     ev    事件：t 标题 ≤10字；d 描述 ≤28字；tag 标注标签 ≤4字（利空/利好/上市/主力进场/叫停…，可省）；
//           badge 图章字 1-2 字；cap 图章说明 ≤5字
//     fx    整屏特效（可省）：rebound/flashUp/flashDown/title 需 text ≤5字 + sub ≤26字；
//           stamp 需 text ≤3字 + sub + color: 'red'|'white'；spot、glow 只需 { type, beats: 4 }（glow 可加 flash: true）
//     mark  片尾全景图上的标注（全片挑 5-6 个关键节点），如 '1999 湖畔创业'
export default {
  person: {
    name: 'TODO姓名',
    logo: 'T',
    code: 'TODO',
    birth: '2000.1',
    watermark: 'T',
    intro: 'TODO一句话头衔',
    endingNote: 'TODO片尾结论（最新状态/数据）',
  },
  phases: [
    { key: 'TODO', identity: 'TODO身份' },
  ],
  candles: [
    // ---------- 前奏（第 1-3 根，每小节一个事件）：起点与早年，小幅波动 ----------
    { date: '2000.1', ph: 'TODO', o: 100, pct: 0,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 1 根 · 起点：出生/成立（开盘 100）
    { date: '2000', pct: 6,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 2 根 · 早年经历，小幅波动
    { date: '2000', pct: 5,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 3 根 · 早年经历，小幅波动
    // ---------- 无鼓蓄力（第 4-8 根，每 2 拍一根）：连续受挫，一路跌到谷底 ----------
    { date: '2000', pct: -12,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 4 根 · 低谷：连续受挫、下跌
    { date: '2000', pct: -8,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 5 根 · 低谷：连续受挫、下跌
    { date: '2000', pct: -9,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 6 根 · 低谷：连续受挫、下跌
    { date: '2000', pct: -7,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 7 根 · 低谷：连续受挫、下跌
    { date: '2000', pct: -6,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 8 根 · 低谷：连续受挫、下跌
    // ---------- 转折（第 9 根）：第 30 拍亮出，第一段高潮重拍爆发——超跌反弹（唯一允许的非高潮段大涨） ----------
    { date: '2000', pct: 60,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'rebound', text: '超跌反弹', sub: 'TODO年份 · 转折事件一句话' } }, // 第 9 根 · 转折：超跌反弹（全片第一次大涨）
    // ---------- 第一段高潮（第 10-24 根）：积累期，小涨小跌慢慢走高，单根 ≤ +15% ----------
    { date: '2000', pct: 4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 10 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 5,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 11 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: -6,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 12 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 13 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 5,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 14 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 3,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 15 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: -5,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 16 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 6,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 17 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 8,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 18 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: -4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 19 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 5,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 20 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 21 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: -3,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 22 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 23 根 · 积累：小涨小跌，慢慢走高
    { date: '2000', pct: 1 }, // 第 24 根 · 过渡：大涨前夜（可不写事件）
    // ---------- 大涨音乐（第 25-40 根）：黄金时代，每小节一个里程碑；第 3 拍亮出、下一小节重拍暴涨，每根 ≥ +30% ----------
    { date: '2000', pct: 60,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'title', text: 'TODO大字', sub: 'TODO年份 · 一句话说明' } }, // 第 25 根 · 主升浪：每根大涨
    { date: '2000', pct: 45,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 26 根 · 主升浪：每根大涨
    { date: '2000', pct: 80,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'flashUp', text: '主力进场', sub: 'TODO年份 · 关键资本/贵人入场' } }, // 第 27 根 · 主升浪：每根大涨
    { date: '2000', pct: 40,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 28 根 · 主升浪：每根大涨
    { date: '2000', pct: 42,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 29 根 · 主升浪：每根大涨
    { date: '2000', pct: 70,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 30 根 · 主升浪：每根大涨
    { date: '2000', pct: 45,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 31 根 · 主升浪：每根大涨
    { date: '2000', pct: 60,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 32 根 · 主升浪：每根大涨
    { date: '2000', pct: 90,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'glow', beats: 4, flash: true } }, // 第 33 根 · 主升浪：每根大涨
    { date: '2000', pct: 38,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 34 根 · 主升浪：每根大涨
    { date: '2000', pct: 42,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 35 根 · 主升浪：每根大涨
    { date: '2000', pct: 75,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'flashUp', text: '主升浪', sub: 'TODO年份 · 爆发式增长的数据' } }, // 第 36 根 · 主升浪：每根大涨
    { date: '2000', pct: 40,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 37 根 · 主升浪：每根大涨
    { date: '2000', pct: 38,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 38 根 · 主升浪：每根大涨
    { date: '2000', pct: 62,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'glow', beats: 4, flash: true } }, // 第 39 根 · 主升浪：每根大涨
    { date: '2000', pct: 35,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'title', text: 'TODO大字', sub: 'TODO年份 · 一句话说明' } }, // 第 40 根 · 主升浪顶点：巅峰头衔
    // ---------- 平稳段（第 41-47 根）：高位小幅震荡，第 47 根为人生巅峰（全片最高点），单根 ≤ +15% ----------
    { date: '2000', pct: -12,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 41 根 · 高位小幅震荡
    { date: '2000', pct: 9,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 42 根 · 高位小幅震荡
    { date: '2000', pct: 8,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 43 根 · 高位小幅震荡
    { date: '2000', pct: 4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 44 根 · 高位小幅震荡
    { date: '2000', pct: 7,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 45 根 · 高位小幅震荡
    { date: '2000', pct: -2,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 46 根 · 高位小幅震荡
    { date: '2000', pct: 9,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 47 根 · 人生巅峰（全片最高点）
    // ---------- 留白（第 48 根）：音乐骤停，风暴前夜的预警事件 ----------
    { date: '2000', pct: -6,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'spot', beats: 4 } }, // 第 48 根 · 风暴前夜：预警事件
    // ---------- 暴跌重鼓（第 49-63 根）：重拍上砸下的打击与余波，后段可小幅修复，单根 ≤ +15% ----------
    { date: '2000', pct: -34,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' },
      fx: { type: 'flashDown', text: '闪崩', sub: 'TODO年份 · 最大打击一句话' } }, // 第 49 根 · 崩盘：最大打击
    { date: '2000', pct: -14,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 50 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -12,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 51 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -10,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 52 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -18,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 53 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -13,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 54 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -4,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 55 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: 14,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 56 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: 8,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 57 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -10,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 58 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: 7,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 59 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: 14,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 60 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: 12,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 61 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -14,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 62 根 · 暴跌与余波，后段可小幅修复
    { date: '2000', pct: -6,
      ev: { t: 'TODO事件标题', d: 'TODO一句话描述（带具体数字/细节）', badge: 'T', cap: 'TODO' } }, // 第 63 根 · 暴跌与余波，后段可小幅修复
  ],
};
