// 人生K线卡点视频 · 命令行入口
// 用法（K 为插件目录）：
//   node K/engine/kline.mjs doctor                         检查 node/ffmpeg/字体/配乐，首次运行自动安装渲染依赖
//   node K/engine/kline.mjs new <目录> [--name 名字]         在目录中生成 story.mjs 模板
//   node K/engine/kline.mjs check <story.mjs>                校验故事：63 个乐句、涨幅规则、文案长度，打印节奏表
//   node K/engine/kline.mjs preview <story.mjs> [--at 秒,秒] [--dir 目录]   导出关键帧与拼图 preview/sheet.png
//   node K/engine/kline.mjs render <story.mjs> [--out 成片.mp4] [--force]   渲染 1080x1920 竖屏成片（约 140 秒）
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { MUSIC, SLOTS } from './music.mjs';
import { ensureCanvas, resolveFonts, toolVersion, probeDuration, CANVAS_VERSION } from './env.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const argv = process.argv.slice(2);
const cmd = argv[0];
const opt = (name) => {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : undefined;
};

function usage() {
  console.log(`人生K线卡点视频引擎（插件目录：${ROOT}）
  doctor                                   检查环境（首次运行自动安装 @napi-rs/canvas）
  new <目录> [--name 名字] [--force]        生成 story.mjs 模板
  check <story.mjs>                        校验故事并打印节奏表
  preview <story.mjs> [--at 秒,秒] [--dir 目录]   导出预览帧与拼图 sheet.png
  render <story.mjs> [--out 成片.mp4] [--force]   渲染成片
参考示例：${path.join(ROOT, 'examples', 'mayun.story.mjs')}`);
}

function doctor() {
  let ok = true;
  const line = (good, label, detail) => {
    console.log(`${good ? '✔' : '✘'} ${label}${detail ? `：${detail}` : ''}`);
    if (!good) ok = false;
  };
  const major = Number(process.versions.node.split('.')[0]);
  line(major >= 18, 'Node.js', `v${process.versions.node}${major >= 18 ? '' : '（需要 18 及以上）'}`);
  const ffmpeg = toolVersion('ffmpeg');
  const ffprobe = toolVersion('ffprobe');
  line(Boolean(ffmpeg), 'ffmpeg', ffmpeg || '未找到，请安装 ffmpeg 并加入 PATH');
  line(Boolean(ffprobe), 'ffprobe', ffprobe || '未找到，请安装 ffmpeg 并加入 PATH');
  if (fs.existsSync(MUSIC.file) && ffprobe) {
    line(true, '内置配乐', `${MUSIC.file}（${probeDuration(MUSIC.file).toFixed(2)} 秒，${SLOTS.length} 个乐句槽位）`);
  } else {
    line(false, '内置配乐', `缺少 ${MUSIC.file}`);
  }
  try {
    const r = ensureCanvas();
    line(true, `渲染依赖 @napi-rs/canvas@${CANVAS_VERSION}`, `${r.installed ? '已自动安装到' : '已就绪'} ${r.dir}`);
  } catch (e) {
    line(false, '渲染依赖 @napi-rs/canvas', e.message);
  }
  const fonts = resolveFonts();
  const names = { KSerif: '衬线粗体（标题）', KSans: '无衬线（正文）', KMono: '等宽数字', KDin: '年份数字' };
  for (const [alias, info] of Object.entries(fonts)) {
    const files = info.files.map((f) => path.basename(f)).join(' + ');
    if (!info.files.length) line(alias === 'KMono' || alias === 'KDin', names[alias], '未找到可用字体');
    else console.log(`${info.ideal ? '✔' : '△'} ${names[alias]}：${files}${info.ideal ? '' : '（回退字体；安装 Noto Serif SC / Noto Sans SC 效果最佳）'}`);
  }
  console.log(ok ? '\n环境就绪，可以开始制作。' : '\n环境未就绪，请按上面的 ✘ 项处理后重试。');
  return ok;
}

function createStory() {
  const dir = argv[1];
  if (!dir || dir.startsWith('--')) {
    console.error('用法：kline.mjs new <目录> [--name 名字]');
    return 2;
  }
  const target = path.resolve(dir, 'story.mjs');
  if (fs.existsSync(target) && !argv.includes('--force')) {
    console.error(`已存在 ${target}（如需覆盖请加 --force）`);
    return 1;
  }
  fs.mkdirSync(path.dirname(target), { recursive: true });
  let text = fs.readFileSync(path.join(ROOT, 'templates', 'story.template.mjs'), 'utf8');
  const name = opt('--name');
  if (name) text = text.replace("name: 'TODO姓名'", `name: '${name.replace(/'/g, "\\'")}'`);
  fs.writeFileSync(target, text, 'utf8');
  console.log(`已生成：${target}\n下一步：按模板注释填写 63 根K线（参考 ${path.join(ROOT, 'examples', 'mayun.story.mjs')}），然后运行 check。`);
  return 0;
}

// check / preview / render 交给 render.mjs 在子进程中执行
function runEngine() {
  if (!argv[1] || argv[1].startsWith('--')) {
    console.error(`用法：kline.mjs ${cmd} <story.mjs> [选项]`);
    return 2;
  }
  ensureCanvas();
  const r = spawnSync(process.execPath, [path.join(HERE, 'render.mjs'), ...argv], { stdio: 'inherit' });
  return r.status ?? 1;
}

let code = 0;
try {
  if (cmd === 'doctor') code = doctor() ? 0 : 1;
  else if (cmd === 'new') code = createStory();
  else if (['check', 'preview', 'render'].includes(cmd)) code = runEngine();
  else usage();
} catch (e) {
  console.error(e.message);
  code = 1;
}
process.exit(code);
