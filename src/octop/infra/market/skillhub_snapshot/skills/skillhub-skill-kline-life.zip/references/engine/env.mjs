// 运行环境：渲染依赖（@napi-rs/canvas）自动安装、字体查找、外部工具检查
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// 渲染依赖版本（已验证可用的版本）
export const CANVAS_VERSION = '1.1.0';

// 依赖安装目录：可用环境变量 KLINE_RUNTIME_DIR 覆盖；默认放在用户目录，避免写入插件安装目录
export function runtimeDir() {
  return process.env.KLINE_RUNTIME_DIR || path.join(process.env.LOCALAPPDATA || os.homedir(), 'kline-life-video', 'runtime');
}

function canvasInstalled(dir) {
  return fs.existsSync(path.join(dir, 'node_modules', '@napi-rs', 'canvas', 'package.json'));
}

// 首次使用时自动安装 @napi-rs/canvas（需要联网访问 npm）
export function ensureCanvas() {
  const dir = runtimeDir();
  if (canvasInstalled(dir)) return { dir, installed: false };
  fs.mkdirSync(dir, { recursive: true });
  const pkg = path.join(dir, 'package.json');
  if (!fs.existsSync(pkg)) {
    fs.writeFileSync(pkg, JSON.stringify({ name: 'kline-life-video-runtime', private: true, version: '1.0.0' }, null, 2));
  }
  console.log(`首次使用：正在安装渲染依赖 @napi-rs/canvas@${CANVAS_VERSION} 到 ${dir} ...`);
  const r = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm',
    ['install', `@napi-rs/canvas@${CANVAS_VERSION}`, '--no-audit', '--no-fund'],
    { cwd: dir, stdio: 'inherit', shell: true });
  if (r.status !== 0 || !canvasInstalled(dir)) {
    throw new Error(`安装 @napi-rs/canvas 失败，请检查网络与 npm 后重试（目录：${dir}）`);
  }
  return { dir, installed: true };
}

export function loadCanvas() {
  const { dir } = ensureCanvas();
  return createRequire(path.join(dir, 'package.json'))('@napi-rs/canvas');
}

// 字体候选（按优先级）：Noto 可变字体效果最好；未安装时回退到系统自带字体
const FONT_DIRS = [
  'C:/Windows/Fonts',
  path.join(process.env.LOCALAPPDATA || '', 'Microsoft', 'Windows', 'Fonts'),
  '/System/Library/Fonts', '/Library/Fonts', path.join(os.homedir(), 'Library', 'Fonts'),
  '/usr/share/fonts', '/usr/local/share/fonts', path.join(os.homedir(), '.fonts'),
];
const FONT_CANDIDATES = {
  // 衬线粗体：大标题、身份、特效大字
  KSerif: [['NotoSerifSC-VF.ttf'], ['SourceHanSerifSC-VF.ttf'], ['NotoSerifCJK-Bold.ttc'], ['Songti.ttc'], ['msyhbd.ttc']],
  // 无衬线（需要常规与粗体两种字重）：正文、标注、大事记
  KSans: [['NotoSansSC-VF.ttf'], ['SourceHanSansSC-VF.ttf'], ['msyh.ttc', 'msyhbd.ttc'], ['PingFang.ttc'], ['NotoSansCJK-Regular.ttc', 'NotoSansCJK-Bold.ttc']],
  // 等宽粗体：价格与日期数字
  KMono: [['consolab.ttf'], ['Menlo.ttc'], ['courbd.ttf'], ['DejaVuSansMono-Bold.ttf']],
  // 年份大数字
  KDin: [['DINNextLTPro-Bold.ttf'], ['bahnschrift.ttf'], ['arialbd.ttf'], ['Arial Bold.ttf'], ['DejaVuSans-Bold.ttf']],
};

function findFont(file) {
  for (const dir of FONT_DIRS) {
    if (!dir) continue;
    const p = path.join(dir, file);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// 返回 { 别名: { files: [路径...], ideal: 是否为首选字体 } }
export function resolveFonts() {
  const out = {};
  for (const [alias, groups] of Object.entries(FONT_CANDIDATES)) {
    for (let i = 0; i < groups.length; i++) {
      const files = groups[i].map(findFont);
      if (files.every(Boolean)) {
        out[alias] = { files, ideal: i === 0 };
        break;
      }
    }
    if (!out[alias]) out[alias] = { files: [], ideal: false };
  }
  return out;
}

export function toolVersion(cmd) {
  const r = spawnSync(cmd, ['-version'], { encoding: 'utf8' });
  if (r.error || r.status !== 0) return null;
  return (r.stdout.split(/\r?\n/)[0] || '').trim();
}

export function probeDuration(file) {
  const r = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', file], { encoding: 'utf8' });
  const d = parseFloat(r.stdout);
  if (!(d > 0)) throw new Error(`无法读取音频时长：${file}\n${r.stderr || ''}`);
  return d;
}
