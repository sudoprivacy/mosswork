## Description: <br>
C Disk Cleanup helps Windows users inspect C: drive space, review plain-language cleanup options, and move or clean selected safe items only after explicit user confirmation. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[jiamiaolou-art](https://clawhub.ai/user/jiamiaolou-art) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
External Windows users and support agents use this skill to diagnose C: drive storage pressure, explain cleanup candidates, and run consent-gated local cleanup workflows that preserve recovery paths. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can scan C: and guide file movement, so a user could approve actions that affect local files or applications. <br>
Mitigation: Require explicit confirmation before any move or cleanup action, review each proposed path and rollback location, and keep backups before approving file movement. <br>
Risk: Advanced cleanup options such as Program Files compression, CompactOS, DISM, or arbitrary folder moves may have system or rollback implications. <br>
Mitigation: Avoid approving advanced system cleanup unless the user understands the rollback path, has backups, and can verify the result after each small batch. <br>
Risk: Chat data, application program directories, locked files, or damaged subdirectories can be disrupted by manual movement. <br>
Mitigation: Use official application migration tools for chat data, do not move application program directories, close relevant processes before movement, and skip locked or damaged subdirectories while reporting them. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/jiamiaolou-art/skills/c-disk-cleanup) <br>
- [Workflow reference](references/workflow.md) <br>
- [Troubleshooting reference](references/troubleshooting.md) <br>
- [Glossary reference](references/glossary.md) <br>
- [Habit sample](references/habit.sample.json) <br>


## Skill Output: <br>
**Output Type(s):** [text, markdown, shell commands, configuration, guidance] <br>
**Output Format:** [Markdown guidance with PowerShell commands, cleanup reports, and JSON preference examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Windows-only local workflow; cleanup actions require explicit confirmation and may produce backup-location guidance.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
