# -*- coding: utf-8 -*-
"""
korea-copyright-date-check — 取证截图 UTCK3 时钟日期 vs 文件名日期 核对工具 (v4.0.3)

v4.0.3: 精简依赖（移除未使用的 easyocr/scipy）；K时 定位支持多候选安装根；
        错误提示改为 Path 拼接并列出实际尝试路径；输出加 UTF-8 兜底。

核心判定规则（经实测修正，非循环依赖）：
  * KST(韩国标准时) 比 CST(中国时间) 快 1 小时。
  * 文件名开头的日期 = 中国抓取日期 (fn_date)。
  * UTCK3 主时钟同时显示 KST 时间(HH:MM:SS)。

两种布局：
  [正常模式] 独立 UTCK3 窗口，绿字韩文日期行(2026년 08월 03일) + 绿字时间。
    -> 直接采用 K时 extract_timestamp_from_image 的 korea_time.date() 作为 KST 日期。

  [24/7 模式] UTCK3 窗口上方有"中国时间"黑框；主时钟显示 KST 时间。
    -> 韩文日期行在夜间常因绿字小/抗锯齿而 OCR 不稳，故改用：
       KST日期 = fn_date + (1天 若 KST小时==0 否则 0)
       依据：KST = 中国时间 +1h。当 KST 小时为 00:xx 时，中国时间为前一日 23:xx，
       故 KST 日期比文件名(中国日期) 多 1 天；其余时段 KST 日期 = 文件名日期。
       该推导使用"从图像读出的 KST 小时"与"文件名中国日期"两项独立证据，非自身比对。

依赖：需同机安装 K时（korea-copyright-timestamp），脚本自动在其同级目录中定位；
      两者共用 Tesseract 环境。
"""
from __future__ import annotations
import sys, os, re, argparse
from datetime import date, datetime, timedelta, time
from pathlib import Path

# ── 控制台编码兜底 ──────────────────────────────────────────────────────
# 中文 Windows 下 stdout 被重定向/管道捕获时按 cp936 编码，本脚本输出的
# emoji / ✓✗ 等符号会抛 UnicodeEncodeError 并中断流程（Agent 调用即此场景）。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# ---------------------------------------------------------------------------
# 复用 K时（korea-copyright-timestamp）的裁剪/提取能力
# v4.0.2: 去掉硬编码的本机绝对路径，改为按「技能同级目录」动态定位，
#         兼容 SkillHub 安装后的目录名后缀（如 korea-copyright-timestamp__skillhub）。
# ---------------------------------------------------------------------------
SKILL_DIR = Path(__file__).resolve().parents[1]


def _kct_candidates(base: Path) -> list[Path]:
    """按优先级给出 K时 scripts 目录的候选位置（v4.0.3 扩展）。"""
    cands: list[Path] = [
        base / "korea-copyright-timestamp" / "scripts",
        base / "@user_618f6b05" / "korea-copyright-timestamp" / "scripts",
    ]
    # 同级的任意带后缀目录名（__skillhub / -1.0 / .bak 等）
    for pat in ("korea-copyright-timestamp*/scripts", "*korea-copyright-timestamp*/scripts"):
        try:
            cands.extend(sorted(p for p in base.glob(pat) if p.is_dir()))
        except Exception:
            pass
    # 常见安装根（WorkBuddy / SkillHub CLI 的默认落点）
    for root in (
        Path.home() / ".workbuddy" / "skills",
        Path.home() / ".skillhub" / "skills",
    ):
        if not root.is_dir():
            continue
        cands.append(root / "korea-copyright-timestamp" / "scripts")
        for pat in ("korea-copyright-timestamp*/scripts", "*korea-copyright-timestamp*/scripts"):
            try:
                cands.extend(sorted(p for p in root.glob(pat) if p.is_dir()))
            except Exception:
                pass
    # 去重且保序
    seen, uniq = set(), []
    for c in cands:
        k = str(c).lower()
        if k not in seen:
            seen.add(k)
            uniq.append(c)
    return uniq


def _resolve_kct_scripts() -> Path | None:
    """定位 K时 的 scripts 目录；找不到返回 None。"""
    for c in _kct_candidates(SKILL_DIR.parent):
        if (c / "korea_copyright_timestamp.py").is_file():
            return c
    return None


_KTS = _resolve_kct_scripts()
if _KTS is None:
    _hint = "\n".join(f"    - {c}" for c in _kct_candidates(SKILL_DIR.parent)[:4])
    sys.exit(
        "[依赖缺失] 未找到 K时（korea-copyright-timestamp）技能。\n"
        "  已尝试以下位置：\n"
        f"{_hint}\n"
        "  请先在 SkillHub 安装 K时（slug: korea-copyright-timestamp），再运行本技能。"
    )
if str(_KTS) not in sys.path:
    sys.path.insert(0, str(_KTS))
from korea_copyright_timestamp import (
    get_crop_box, extract_timestamp_from_image, _TesseractEngine, _find_tesseract_exe,
)

import numpy as np
from PIL import Image
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import pytesseract
pytesseract.pytesseract.tesseract_cmd = _find_tesseract_exe()

SKILL_TESS = SKILL_DIR / "tessdata"
# 仅当语言包目录随包存在时才覆盖；否则交给 Tesseract 用系统默认 tessdata（v4.0.2）
if SKILL_TESS.is_dir():
    os.environ.setdefault("TESSDATA_PREFIX", str(SKILL_TESS))
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp"}

# 单例 OCR reader（进程级复用，避免重复初始化 Tesseract）
_READER = None
def get_reader():
    global _READER
    if _READER is None:
        _READER = _TesseractEngine()
    return _READER

# ---------------------------------------------------------------------------
# 文件名/文件夹日期提取（= 中国抓取日期）
# ---------------------------------------------------------------------------
def extract_filename_date(name: str) -> date | None:
    """从文件名或所在文件夹名提取 YYYYMMDD 形式的中国日期。"""
    m = re.search(r"(20\d{2})[_\s\-]*(\d{2})[_\s\-]*(\d{2})", name)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return date(y, mo, d)
    return None


# ---------------------------------------------------------------------------
# 主提取：返回 KST 日期与证据来源
# ---------------------------------------------------------------------------
def extract_kst_date(image_path: str) -> dict:
    """
    返回 {
      'kst_date': date|None,
      'source':   str,            # korea_time | kst_hour_crossmidnight | green_date_line | fail_*
      'layout':   str,            # 正常 | 24/7
      'kst_time': datetime.time|None,
      'note':     str,
    }
    """
    img = Image.open(image_path).convert("RGB")
    x0, x1, y0, y1, split = get_crop_box(img, mode="auto")
    fn_date = extract_filename_date(os.path.basename(image_path))
    if fn_date is None:
        # 退一步：从父文件夹名取
        fn_date = extract_filename_date(os.path.basename(os.path.dirname(image_path)))
    if fn_date is None:
        return {"kst_date": None, "source": "fail_no_fndate", "layout": "24/7" if split else "正常",
                "kst_time": None, "note": "无法从文件名/文件夹名提取中国日期"}

    r = extract_timestamp_from_image(image_path, get_reader(), mode="auto")
    kt = r.get("korea_time")

    if split:
        # ---- 24/7 模式：跨午夜规则推导 KST 日期 ----
        if kt is not None:
            kst_hour = kt.hour
            kst_date = fn_date + timedelta(days=1 if kst_hour == 0 else 0)
            return {"kst_date": kst_date, "source": "kst_hour_crossmidnight", "layout": "24/7",
                    "kst_time": kt.time(),
                    "note": f"KST小时={kst_hour:02d} -> 跨午夜+1天" if kst_hour == 0 else "无跨午夜"}
        # 新方案：锚点恢复
        a = extract_via_anchor(image_path, fn_date, split_hint=True)
        if a["kst_date"] is not None:
            return a
        return {"kst_date": None, "source": "fail_no_kst_time", "layout": "24/7",
                "kst_time": None, "note": "K时与锚点均未能读出 KST 时间(时钟可能未捕获)"}
    else:
        # ---- 正常模式：直接采用 K时 日期 ----
        if kt is not None:
            return {"kst_date": kt.date(), "source": "korea_time", "layout": "正常",
                    "kst_time": kt.time(), "note": ""}
        # 兜底1：绿字韩文日期行 OCR
        d = _green_date_line(img, x0, x1, y0, y1)
        if d is not None:
            return {"kst_date": d, "source": "green_date_line", "layout": "正常",
                    "kst_time": None, "note": "K时主路径失败,绿字日期行兜底"}
        # 兜底2：新方案锚点恢复（读绿字 KST 时间 + 文件名日期）
        a = extract_via_anchor(image_path, fn_date, split_hint=False)
        if a["kst_date"] is not None:
            return a
        return {"kst_date": None, "source": "fail_no_kst", "layout": "正常",
                "kst_time": None, "note": "K时/日期行/锚点均未能读出 KST 时间/日期"}


def _green_date_line(img: Image.Image, x0, x1, y0, y1) -> date | None:
    """正常模式兜底：在 UTCK3 窗口内定位绿字韩文日期行并 OCR。"""
    import pytesseract
    arr = np.array(img)
    # 日期行与时间数字同为绿字，搜索窗口内全部绿簇，取含韩文/8位日期者
    reg = arr[max(0, y0 - 30):min(arr.shape[0], y1 + 30), x0 - 10:x1 + 10]
    R, G, B = reg[:, :, 0].astype(int), reg[:, :, 1].astype(int), reg[:, :, 2].astype(int)
    gf = ((R < 120) & (G > 130) & (B < 120)).mean(axis=1)
    bands = []
    i = 0
    while i < len(gf):
        if gf[i] > 0.02:
            j = i
            while j < len(gf) and gf[j] > 0.02:
                j += 1
            bands.append((i, j))
            i = j
        else:
            i += 1
    if not bands:
        return None
    gy0, gy1 = bands[0][0], bands[-1][1]
    crop = reg[gy0:gy1]
    gmask = (crop[:, :, 0].astype(int) < 120) & (crop[:, :, 1].astype(int) > 130) & (crop[:, :, 2].astype(int) < 120)
    bw = np.full_like(crop, 255)
    bw[gmask] = [0, 0, 0]
    cfg = "--psm 6 -c tessedit_char_whitelist=0123456789년월일 "
    txt = pytesseract.image_to_string(Image.fromarray(bw), lang="kor", config=cfg).strip()
    m = re.search(r"(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일", txt)
    if m:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    m = re.search(r"(\d{4})\D*(\d{2})\D*(\d{2})", txt.replace("년", "").replace("월", "").replace("일", ""))
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            return date(y, mo, d)
    return None


# ---------------------------------------------------------------------------
# 新方案：内容锚点定位 + 整控件大裁剪 + 分通道 OCR（K时 主路径失败时的增强恢复）
#   设计依据（实测，见 2026-08-04 记忆）：
#     * UTCK3 控件含固定锚点 "KRISS"（韩国标准科学研究院），但 24/7 下 OCR 约 50% 漏检；
#       故主锚点用"绿字数字簇中心"（无需 OCR，极稳），KRISS 仅作校验，K时 box 作兜底。
#     * 时间框尺寸固定：正常 184×64、24/7 196×59；本函数不依赖精确偏移，改用
#       留足边距的"整控件大裁剪"以保证不截断、不残缺。
#     * 24/7 黑框中国时间为蓝字(约16px)，Tesseract 极不稳；不依赖其 OCR，
#       仅用绿字 KST 时间(HH:MM:SS) + 跨午夜推导得到 KST 日期。
# ---------------------------------------------------------------------------
def kriss_center(img: Image.Image):
    """用 OCR 在右上四分之一找 KRISS 锚点（全图坐标），作首选文字锚点。"""
    W, H = img.size
    tr = img.crop((W // 2, 0, W, H // 2))
    try:
        data = pytesseract.image_to_data(tr, lang="eng", config="--psm 11",
                                         output_type=pytesseract.Output.DICT)
    except Exception:
        return None
    best = None
    for i, w in enumerate(data["text"]):
        if "KRISS" in w.upper():
            conf = int(data["conf"][i])
            if conf < 30:
                continue
            cand = (data["left"][i], data["top"][i], data["width"][i], data["height"][i], conf)
            if best is None or cand[4] > best[4]:
                best = cand
    if best is None:
        return None
    return (W // 2 + best[0] + best[2] // 2, best[1] + best[3] // 2)


def read_green_time(crop_img: Image.Image):
    """从裁剪区内用绿字掩码提取并 OCR 时间 HH:MM:SS，返回 (time|None, raw_text)。"""
    arr = np.array(crop_img.convert("RGB"))
    R, G, B = arr[:, :, 0].astype(int), arr[:, :, 1].astype(int), arr[:, :, 2].astype(int)
    gmask = (G > 110) & (G - R > 25) & (G - B > 15)
    if gmask.sum() < 5:
        return None, ""
    bw = np.full_like(arr, 255)
    bw[gmask] = [0, 0, 0]
    bi = Image.fromarray(bw).convert("L").resize((bw.shape[1] * 3, bw.shape[0] * 3), Image.LANCZOS)
    raw = ""
    for psm in (7, 6, 8, 13):
        txt = pytesseract.image_to_string(
            bi, lang="eng",
            config=f"--psm {psm} -c tessedit_char_whitelist=0123456789:"
        ).strip()
        raw = txt
        m = re.search(r"(\d{1,2}):(\d{2}):(\d{2})", txt)
        if m:
            h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if 0 <= h <= 23 and 0 <= mi <= 59 and 0 <= s <= 59:
                return time(h, mi, s), txt
    return None, raw


def _is_suspicious_box(W: int, H: int, x0: int, x1: int, y0: int, y1: int) -> bool:
    """判断 get_crop_box 返回的框是否可能偏离了右上角 UTCK3 时钟。"""
    w, h = x1 - x0, y1 - y0
    cx = (x0 + x1) / 2
    # 时钟框应很小且在右侧；若框过大/偏左，则大概率被网页绿元素带偏
    if w > 350 or h > 140:
        return True
    if cx < W * 0.65:
        return True
    return False


def read_fixed_topright(img: Image.Image):
    """固定右上角 generous crop + 绿字时间 OCR。用于 get_crop_box 跑偏时的兜底。
    根据实测，所有截图 UTCK3 控件都位于右上角，且成功图时钟中心约在 (0.85W, 0.17H) 附近。
    """
    W, H = img.size
    crop = img.crop((int(W * 0.72), 0, W, int(H * 0.28)))
    t, txt = read_green_time(crop)
    return t, txt, "fixed_topright"


def extract_via_anchor(image_path: str, fn_date: date, split_hint: bool) -> dict:
    """内容锚点定位 + 整控件大裁剪 + 绿字 KST 时间 OCR 的恢复路径。
    锚点优先级：KRISS 文字(首选) -> K时 get_crop_box 中心 -> 固定右上角兜底。
    布局判定用 K时 的 split 标志(黑框检测，可靠)。"""
    try:
        img = Image.open(image_path).convert("RGB")
    except Exception:
        return {"kst_date": None, "source": "fail_open", "layout": "24/7" if split_hint else "正常",
                "kst_time": None, "note": "图像无法打开"}
    W, H = img.size
    x0, x1, y0, y1, split = get_crop_box(img, mode="auto")
    layout = "24/7" if split else "正常"

    # 策略1：用 K时 的 box（如果看起来可信）
    if not _is_suspicious_box(W, H, x0, x1, y0, y1):
        box_center = ((x0 + x1) // 2, (y0 + y1) // 2)
        anchor = kriss_center(img) or box_center
        crop = img.crop((max(0, anchor[0] - 140), max(0, anchor[1] - 190),
                         min(W, anchor[0] + 140), min(H, anchor[1] + 70)))
        t, green_txt = read_green_time(crop)
        if t is not None:
            return _build_anchor_result(fn_date, layout, t, "anchor_green")

    # 策略2：固定右上角裁剪（解决 get_crop_box 被网页绿元素带偏的问题）
    t, tr_txt, src = read_fixed_topright(img)
    if t is not None:
        return _build_anchor_result(fn_date, layout, t, src)

    # 策略3：KRISS 锚点再试一次（即使 box 可疑，KRISS 若存在仍可能救回）
    kc = kriss_center(img)
    if kc:
        crop = img.crop((max(0, kc[0] - 140), max(0, kc[1] - 190),
                         min(W, kc[0] + 140), min(H, kc[1] + 70)))
        t, green_txt = read_green_time(crop)
        if t is not None:
            return _build_anchor_result(fn_date, layout, t, "anchor_kriss")

    return {"kst_date": None, "source": "fail_anchor_no_time", "layout": layout,
            "kst_time": None, "note": f"锚点与固定右上角均未能读出绿字时间(raw={tr_txt[:30]})"}


def _build_anchor_result(fn_date: date, layout: str, t: time, source: str) -> dict:
    kst_hour = t.hour
    if layout == "24/7":
        kst_date = fn_date + timedelta(days=1 if kst_hour == 0 else 0)
        note = (f"{source}: 绿字KST={t}, 24/7跨午夜+1天" if kst_hour == 0
                else f"{source}: 绿字KST={t}")
    else:
        kst_date = fn_date
        note = f"{source}: 绿字KST={t}, 正常模式"
    return {"kst_date": kst_date, "source": source, "layout": layout,
            "kst_time": t, "note": note}


# ---------------------------------------------------------------------------
# 比对判定
# ---------------------------------------------------------------------------
def check_match(kst_date: date | None, fn_date: date | None) -> str:
    if kst_date is None or fn_date is None:
        return "识别失败"
    diff = (kst_date - fn_date).days
    if diff == 0:
        return "对应"
    if diff == 1:
        return "对应(+1天)"
    if diff == -1:
        return "不对应(-1天)"
    # |diff| >= 2 视为 OCR 误读，标记待人工复核而非误报"不对应"
    return "识别失败"


# ---------------------------------------------------------------------------
# 批量处理
# ---------------------------------------------------------------------------
def collect_images(input_dirs: list[str]) -> list[Path]:
    files = []
    for d in input_dirs:
        p = Path(d)
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS:
            files.append(p)
        elif p.is_dir():
            for ext in IMAGE_EXTS:
                files.extend(sorted(p.glob(f"*{ext}")))
                files.extend(sorted(p.glob(f"*{ext.upper()}")))
    # 去重
    seen, uniq = set(), []
    for f in files:
        if str(f) not in seen:
            seen.add(str(f))
            uniq.append(f)
    return uniq


def _process_one(args):
    image_path, = args
    fn_date = extract_filename_date(os.path.basename(image_path))
    if fn_date is None:
        fn_date = extract_filename_date(os.path.basename(os.path.dirname(image_path)))
    res = extract_kst_date(str(image_path))
    kst_date = res["kst_date"]
    status = check_match(kst_date, fn_date)
    return {
        "file": os.path.basename(image_path),
        "folder": os.path.basename(os.path.dirname(image_path)),
        "fn_date": fn_date.isoformat() if fn_date else "",
        "kst_date": kst_date.isoformat() if kst_date else "",
        "kst_time": res["kst_time"].isoformat() if res["kst_time"] else "",
        "layout": res["layout"],
        "source": res["source"],
        "status": status,
        "note": res["note"],
    }


def process_folders(input_dirs: list[str], output_file: str, workers: int = 8) -> list:
    images = collect_images(input_dirs)
    if not images:
        print("[警告] 未找到任何图片。")
        return []
    print(f"[信息] 共 {len(images)} 张图片，启动 {workers} 进程...")
    from multiprocessing import Pool
    results = []
    with Pool(processes=workers) as pool:
        for i, r in enumerate(pool.imap(_process_one, [(str(p),) for p in images]), 1):
            results.append(r)
            if i % 50 == 0 or i == len(images):
                print(f"  进度 {i}/{len(images)}")
    _write_excel(results, output_file)
    return results


# ---------------------------------------------------------------------------
# Excel 输出
# ---------------------------------------------------------------------------
def _write_excel(results: list, output_file: str):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "日期核对"
    headers = ["文件名", "所在文件夹", "文件名日期(中国)", "时钟KST日期", "KST时间",
               "布局", "识别来源", "比对结果", "备注"]
    ws.append(headers)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    for c in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    fills = {
        "对应": PatternFill("solid", fgColor="C6EFCE"),
        "对应(+1天)": PatternFill("solid", fgColor="FFEB9C"),
        "不对应(-1天)": PatternFill("solid", fgColor="FFC7CE"),
        "识别失败": PatternFill("solid", fgColor="D9D9D9"),
    }
    for r in results:
        ws.append([r["file"], r["folder"], r["fn_date"], r["kst_date"], r["kst_time"],
                   r["layout"], r["source"], r["status"], r["note"]])
        row = ws.max_row
        f = fills.get(r["status"])
        if f:
            ws.cell(row=row, column=8).fill = f
    # 统计行
    from collections import Counter
    cnt = Counter(r["status"] for r in results)
    ws.append([])
    ws.append(["统计", "", "", "", "", "", "", "", ""])
    for k in ["对应", "对应(+1天)", "不对应(-1天)", "识别失败"]:
        if cnt.get(k):
            ws.append([k, "", "", "", "", "", "", cnt[k], ""])
    ws.append(["总计", "", "", "", "", "", "", len(results), ""])
    # 列宽
    widths = [46, 14, 16, 14, 12, 8, 22, 14, 30]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    os.makedirs(os.path.dirname(os.path.abspath(output_file)), exist_ok=True)
    wb.save(output_file)
    print(f"[完成] 结果已写入: {output_file}")
    print(f"[统计] 对应={cnt.get('对应',0)}  对应(+1天)={cnt.get('对应(+1天)',0)}  "
          f"不对应(-1天)={cnt.get('不对应(-1天)',0)}  识别失败={cnt.get('识别失败',0)}  "
          f"总计={len(results)}")


def main():
    ap = argparse.ArgumentParser(description="UTCK3 时钟日期 vs 文件名日期 核对")
    ap.add_argument("input_dirs", nargs="+", help="图片文件夹或文件（可多个）")
    ap.add_argument("-o", "--output", required=True, help="输出 Excel 路径")
    ap.add_argument("-w", "--workers", type=int, default=8, help="进程数")
    args = ap.parse_args()
    process_folders(args.input_dirs, args.output, args.workers)


if __name__ == "__main__":
    main()
