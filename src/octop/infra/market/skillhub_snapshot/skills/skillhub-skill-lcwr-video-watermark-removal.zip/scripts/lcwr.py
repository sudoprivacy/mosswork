#!/usr/bin/env python3
"""高质量视频去水印LCWR · 命令行工具（晴沐智坊 出品，供智能体自动化调用）。

子命令：
  check-key              检查 API Key 是否已配置（环境变量 QM_KEY 或 skill 目录 .env）
  save-key <key>         把用户贴回的 API Key 写入 skill 目录 .env（键名 QM_KEY）
  list                   获取公开能力列表
  detail <slug>          获取能力详情与调用方式
  upload                 上传本地视频，返回公网链接
  roi                    用 OpenCV 弹窗框选水印区域，输出坐标 JSON（可选依赖）
  invoke                 调用能力（自动处理异步任务轮询）
  task <request_id>      查询异步任务结果

鉴权：Authorization: Bearer <QM_KEY>
计费口径：1 积分 = 人民币 1 分钱（0.01 元）。
所有输出为 JSON（便于智能体解析）；缺失 Key 时退出码为 2，并输出 need_key=true。
除 roi 需要可选的 opencv-python 与桌面 GUI 外，其余命令仅依赖 Python 标准库。
"""

import argparse
import base64
import json
import mimetypes
import os
import stat
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

DEFAULT_BASE_URL = "https://www.licorxj.online"
KEY_PAGE = "https://www.licorxj.online/capability-hub"
KEY_GUIDE = (f"请打开 {KEY_PAGE} 注册并登录，在「API Key 管理」创建并复制 API Key（cbk_ 开头），"
             "然后把 Key 贴回给智能体，由智能体执行 save-key 保存到 .env")
POINTS_NOTE = "计费口径：1 积分 = 人民币 1 分钱（0.01 元）"
ENV_KEY_NAME = "QM_KEY"

SKILL_NAME = "高质量视频去水印LCWR"
PUBLISHER = "晴沐智坊"
WATERMARK_SLUG = "video-watermark-removal"

SKILL_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = SKILL_DIR / ".env"
FALLBACK_ENV_FILE = SKILL_DIR.parent / ".env"

EXIT_OK = 0
EXIT_ERROR = 1
EXIT_NEED_KEY = 2
EXIT_AUTH_FAILED = 3
EXIT_INSUFFICIENT_POINTS = 4


# ────────────────────────────────────────────
# Key 读取与保存
# ────────────────────────────────────────────

def _parse_env_file(path: Path) -> dict:
    data = {}
    if not path.exists():
        return data
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        data[k.strip()] = v.strip().strip('"').strip("'")
    return data


def resolve_key(cli_key: str = None):
    """按优先级取 Key：命令行 > 环境变量 QM_KEY > skill/.env > 上级 .env"""
    if cli_key:
        return cli_key, "--key"
    env_val = os.environ.get(ENV_KEY_NAME)
    if env_val:
        return env_val, f"env:{ENV_KEY_NAME}"
    for path in (ENV_FILE, FALLBACK_ENV_FILE):
        val = _parse_env_file(path).get(ENV_KEY_NAME)
        if val:
            return val, str(path)
    return None, None


def mask(key: str) -> str:
    if not key:
        return None
    return key[:8] + "..." + key[-4:] if len(key) > 12 else "***"


def save_key(key: str, env_path: Path = ENV_FILE) -> Path:
    lines = []
    if env_path.exists():
        lines = [
            l for l in env_path.read_text(encoding="utf-8").splitlines()
            if not l.strip().startswith(f"{ENV_KEY_NAME}=")
        ]
    lines.append(f"{ENV_KEY_NAME}={key}")
    lines.append(f"QM_HUB_BASE_URL={os.environ.get('QM_HUB_BASE_URL') or DEFAULT_BASE_URL}")
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        os.chmod(env_path, stat.S_IRUSR | stat.S_IWUSR)  # 600
    except OSError:
        pass
    return env_path


# ────────────────────────────────────────────
# HTTP
# ────────────────────────────────────────────

def request_json(method: str, url: str, api_key: str = None, body: dict = None, timeout: int = 60):
    data = None
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "ignore")
        try:
            payload = json.loads(raw)
        except ValueError:
            payload = {"code": e.code, "msg": raw or e.reason}
        if e.code in (401, 403):
            print(json.dumps({
                "ok": False,
                "error": "auth_failed",
                "message": f"API Key 无效、已禁用或已过期。{KEY_GUIDE}",
                "key_page": KEY_PAGE,
                "key_guide": KEY_GUIDE,
                "detail": payload,
            }, ensure_ascii=False, indent=2))
            sys.exit(EXIT_AUTH_FAILED)
        if e.code == 402:
            print(json.dumps({
                "ok": False,
                "error": "insufficient_points",
                "message": f"积分不足，请先到门户充值后重试。{POINTS_NOTE}",
                "key_page": KEY_PAGE,
                "detail": payload,
            }, ensure_ascii=False, indent=2))
            sys.exit(EXIT_INSUFFICIENT_POINTS)
        print(json.dumps({"ok": False, "error": f"http_{e.code}", "detail": payload},
                         ensure_ascii=False, indent=2))
        sys.exit(EXIT_ERROR)
    except urllib.error.URLError as e:
        print(json.dumps({"ok": False, "error": "network_error", "message": str(e.reason)},
                         ensure_ascii=False, indent=2))
        sys.exit(EXIT_ERROR)


def unwrap(payload: dict):
    """统一响应 {code,msg,data} 解包；非 0 视为失败。"""
    if isinstance(payload, dict) and "code" in payload and "data" in payload:
        if payload.get("code") != 0:
            print(json.dumps({"ok": False, "error": payload.get("msg"), "code": payload.get("code")},
                             ensure_ascii=False, indent=2))
            sys.exit(EXIT_ERROR)
        return payload.get("data")
    return payload


def emit(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def get_base_url(args) -> str:
    return (getattr(args, "base_url", None)
            or os.environ.get("QM_HUB_BASE_URL")
            or _parse_env_file(ENV_FILE).get("QM_HUB_BASE_URL")
            or DEFAULT_BASE_URL).rstrip("/")


def require_key(args):
    key, source = resolve_key(getattr(args, "key", None))
    if not key:
        emit({
            "ok": False,
            "need_key": True,
            "has_key": False,
            "message": f"未检测到 {ENV_KEY_NAME}。{KEY_GUIDE}",
            "key_page": KEY_PAGE,
            "key_guide": KEY_GUIDE,
            "save_command": f"python3 {Path(__file__).as_posix()} save-key <用户贴回的Key>",
            "env_var": ENV_KEY_NAME,
            "env_file": str(ENV_FILE),
        })
        sys.exit(EXIT_NEED_KEY)
    return key, source


# ────────────────────────────────────────────
# 子命令
# ────────────────────────────────────────────

# ────────────────────────────────────────────
# 余额检查与充值提醒
# ────────────────────────────────────────────

LOW_BALANCE_THRESHOLD = 10
RECHARGE_URL = KEY_PAGE


def fetch_me(base, key):
    """远程校验 Key 并取余额；失败不中断流程，返回 (data, error)。"""
    req = urllib.request.Request(
        f"{base}/api/capability/me",
        headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return None, f"http_{e.code}"
    except (urllib.error.URLError, ValueError, OSError) as e:
        return None, str(e)
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, dict):
        return None, "bad_response"
    return data, None


def _balance_hint(points):
    """余额低于阈值时返回统一提醒字段；否则返回空 dict。"""
    try:
        points = int(points)
    except (TypeError, ValueError):
        return {}
    if points >= LOW_BALANCE_THRESHOLD:
        return {}
    return {
        "low_balance": True,
        "total_points": points,
        "recharge_url": RECHARGE_URL,
        "message": (f"当前积分 {points}，不足 {LOW_BALANCE_THRESHOLD} 积分，请提醒用户及时充值；"
                    f"用户可自行前往购买地址：{RECHARGE_URL}"),
    }


def cmd_check_key(args):
    key, source = resolve_key(args.key)
    if not key:
        emit({
            "ok": False,
            "need_key": True,
            "has_key": False,
            "message": f"环境变量 {ENV_KEY_NAME} 与 {ENV_FILE} 中均未找到 API Key。",
            "key_page": KEY_PAGE,
            "key_guide": KEY_GUIDE,
            "instruction": KEY_GUIDE,
            "env_file": str(ENV_FILE),
        })
        return EXIT_NEED_KEY

    base = get_base_url(args)
    info = {"ok": True, "has_key": True, "source": source,
            "key_masked": mask(key), "base_url": base}
    me, err = fetch_me(base, key)
    if me is None:
        if err in ("http_401", "http_403"):
            info.update({
                "ok": False,
                "key_valid": False,
                "balance_error": err,
                "message": f"API Key 无效、已禁用或已过期。{KEY_GUIDE}",
                "key_page": KEY_PAGE,
            })
            emit(info)
            return EXIT_AUTH_FAILED
        info.update({
            "key_valid": None,
            "balance_error": err,
            "message": "Key 已配置，但远程校验/余额查询失败（网络或服务异常），可稍后重试",
        })
        emit(info)
        return EXIT_OK

    points = me.get("total_points")
    info.update({
        "key_valid": True,
        "user_id": me.get("user_id"),
        "username": me.get("username"),
        "total_points": points,
        "low_balance": bool(me.get("low_balance")),
        "low_balance_threshold": me.get("low_balance_threshold", LOW_BALANCE_THRESHOLD),
        "recharge_url": RECHARGE_URL,
    })
    if info["low_balance"]:
        info["message"] = (f"当前积分 {points}，不足 {info['low_balance_threshold']} 积分，"
                           f"请提醒用户及时充值；用户可自行前往购买地址：{RECHARGE_URL}")
    emit(info)
    return EXIT_OK


# ────────────────────────────────────────────
# 环境自检（初次运行 / 换机 / 排障）
# ────────────────────────────────────────────

def _check_python():
    v = sys.version_info
    ok = v >= (3, 8)
    return {"name": "python", "required": True, "ok": ok,
            "detail": f"{v.major}.{v.minor}.{v.micro}",
            "guide": None if ok else "需要 Python 3.8+，请升级：https://www.python.org/downloads/"}


def _check_network(base):
    try:
        with urllib.request.urlopen(f"{base}/api/capability/capabilities", timeout=8) as resp:
            ok = 200 <= resp.status < 300
    except Exception as exc:  # noqa: BLE001
        return {"name": "network", "required": True, "ok": False,
                "detail": f"{base} 不可达：{exc}",
                "guide": "检查网络连通性，或用 --base-url 指定正确服务地址"}
    return {"name": "network", "required": True, "ok": ok,
            "detail": f"{base} 可达" if ok else f"{base} 返回异常",
            "guide": None if ok else "检查服务状态或 --base-url 配置"}


def _check_api_key(base, args):
    key, source = resolve_key(getattr(args, "key", None))
    if not key:
        return {"name": "api_key", "required": True, "ok": False,
                "detail": "未配置 API Key", "guide": KEY_GUIDE}, None
    me, err = fetch_me(base, key)
    if me is None:
        if err in ("http_401", "http_403"):
            return {"name": "api_key", "required": True, "ok": False,
                    "detail": "Key 无效、已禁用或已过期", "guide": KEY_GUIDE}, None
        return {"name": "api_key", "required": True, "ok": True,
                "detail": f"已配置（来源 {source}），余额查询失败：{err}",
                "key_masked": mask(key), "balance_error": err}, None
    points = me.get("total_points")
    return {"name": "api_key", "required": True, "ok": True,
            "detail": f"已配置（来源 {source}），余额 {points} 积分",
            "key_masked": mask(key), "total_points": points,
            "low_balance": bool(me.get("low_balance")),
            "recharge_url": RECHARGE_URL}, me


def _check_cv2():
    try:
        import cv2  # noqa: F401
        version = getattr(cv2, "__version__", "unknown")
        return {"name": "opencv", "required": False, "ok": True,
                "detail": f"opencv-python {version}", "guide": None}
    except Exception:  # noqa: BLE001
        return {"name": "opencv", "required": False, "ok": False,
                "detail": "未安装（仅影响 roi 弹窗框选，可改用 --coords）",
                "guide": "pip install opencv-python"}


def _check_gui():
    if os.name == "nt" or sys.platform == "darwin":
        return {"name": "gui", "required": False, "ok": True,
                "detail": "桌面系统", "guide": None}
    has_display = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    return {"name": "gui", "required": False, "ok": has_display,
            "detail": "检测到图形界面" if has_display else "无图形界面（roi 弹窗不可用）",
            "guide": None if has_display else "在有桌面的机器运行，或用 --coords x1,y1,x2,y2"}


def cmd_doctor(args):
    base = get_base_url(args)
    key_check, me = _check_api_key(base, args)
    checks = [_check_python(), key_check, _check_network(base), _check_cv2(), _check_gui()]
    missing = [c["name"] for c in checks if c["required"] and not c["ok"]]
    out = {
        "ok": not missing,
        "ready": not missing,
        "skill": SKILL_NAME,
        "publisher": PUBLISHER,
        "base_url": base,
        "checks": checks,
        "missing_required": missing,
        "guides": [c["guide"] for c in checks if c.get("guide")],
        "install_guide": "https://www.licorxj.online/capability-hub",
    }
    if me and me.get("low_balance"):
        out.update(_balance_hint(me.get("total_points")))
    emit(out)
    return EXIT_OK if not missing else EXIT_ERROR


def cmd_save_key(args):
    key = args.key.strip().strip('"').strip("'")
    if not key:
        emit({"ok": False, "error": "empty_key", "message": "Key 不能为空"})
        return EXIT_ERROR
    path = save_key(key)
    emit({"ok": True, "saved": True, "env_file": str(path),
          "key_masked": mask(key),
          "warning": None if key.startswith("cbk_") else "该 Key 不以 cbk_ 开头，请确认复制完整",
          "message": "已保存用户贴回的 Key，后续调用将自动读取"})
    return EXIT_OK


def cmd_list(args):
    base = get_base_url(args)
    data = unwrap(request_json("GET", f"{base}/api/capability/capabilities"))
    items = data if isinstance(data, list) else data.get("items", [])
    if args.full:
        emit({"ok": True, "count": len(items), "capabilities": items})
        return EXIT_OK
    slim = [{
        "id": c.get("id"),
        "name": c.get("name"),
        "slug": c.get("slug"),
        "category": c.get("category"),
        "summary": c.get("summary"),
        "input_type": c.get("input_type"),
        "points_per_call": c.get("points_per_call"),
        "billing": c.get("billing"),
    } for c in items]
    emit({"ok": True, "count": len(slim), "capabilities": slim})
    return EXIT_OK


def cmd_detail(args):
    base = get_base_url(args)
    data = unwrap(request_json("GET", f"{base}/api/capability/capabilities/{urllib.parse.quote(args.slug)}"))
    cap = data if isinstance(data, dict) else {}
    base_url = base
    out = {
        "ok": True,
        "capability": cap,
        "how_to_call": {
            "method": "POST",
            "url": f"{base_url}/api/capability/invoke",
            "headers": {"Authorization": "Bearer $QM_KEY", "Content-Type": "application/json"},
            "body": {
                "slug": cap.get("slug"),
                "input_url": "<文件 URL，与 input_base64 二选一>",
                "input_base64": "<文件 base64，可选>",
                "params": cap.get("params_schema") or {},
                "duration_seconds": "<视频秒数，视频类能力建议传入以便预校验积分>",
            },
            "cli": f"python3 {Path(__file__).as_posix()} invoke --slug {cap.get('slug')} --input-url <URL> --wait",
        },
    }
    emit(out)
    return EXIT_OK


# ────────────────────────────────────────────
# 视频上传（取得公网链接）
# ────────────────────────────────────────────

def cmd_upload(args):
    key, _ = require_key(args)
    base = get_base_url(args)
    path = Path(args.file).expanduser()
    if not path.is_file():
        emit({"ok": False, "error": "file_not_found", "path": str(path)})
        return EXIT_ERROR
    size = path.stat().st_size
    if size <= 0:
        emit({"ok": False, "error": "empty_file", "path": str(path)})
        return EXIT_ERROR
    content_type = (args.content_type or mimetypes.guess_type(path.name)[0]
                    or "application/octet-stream")

    ticket = unwrap(request_json(
        "POST", f"{base}/api/capability/upload-ticket", api_key=key,
        body={"filename": path.name, "content_type": content_type, "size": size}))
    if not isinstance(ticket, dict) or not ticket.get("upload_url"):
        emit({"ok": False, "error": "bad_ticket", "message": "服务端未返回有效的上传信息"})
        return EXIT_ERROR

    headers = {"Content-Type": content_type}
    headers.update(ticket.get("headers") or {})
    req = urllib.request.Request(
        ticket["upload_url"], data=path.read_bytes(), headers=headers,
        method=ticket.get("method") or "PUT")
    try:
        with urllib.request.urlopen(req, timeout=args.timeout) as resp:
            resp.read()
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "ignore")
        emit({"ok": False, "error": "upload_failed", "http_status": e.code,
              "message": "视频上传失败，请检查文件是否可读、格式与大小是否符合要求", 
              "detail": raw[:1000]})
        return EXIT_ERROR
    except urllib.error.URLError as e:
        emit({"ok": False, "error": "network_error", "message": str(e.reason)})
        return EXIT_ERROR

    done = unwrap(request_json(
        "POST", f"{base}/api/capability/upload-complete", api_key=key,
        body={"key": ticket["key"]}))
    public_url = (done or {}).get("public_url") or ticket.get("public_url")
    emit({"ok": True, "public_url": public_url, "key": ticket.get("key"),
          "size": size, "content_type": content_type,
          "note": "该链接可直接作为 invoke 的 --input-url"})
    return EXIT_OK


# ────────────────────────────────────────────
# 水印区域框选（OpenCV 弹窗，可选依赖）
# ────────────────────────────────────────────

def _parse_coords(text):
    try:
        parts = [int(v.strip()) for v in text.split(",")]
    except (ValueError, AttributeError):
        return None
    if len(parts) != 4:
        return None
    x1, y1, x2, y2 = parts
    if x2 <= x1 or y2 <= y1:
        return None
    return {"x1": x1, "y1": y1, "x2": x2, "y2": y2}


def _emit_box(box, video_size=None):
    emit({"ok": True, "box": box, "params": dict(box),
          "params_json": json.dumps(box, ensure_ascii=False),
          "video_size": video_size,
          "invoke_hint": "把 params_json 原样作为 invoke 的 --params 值"})


def cmd_roi(args):
    if args.coords:
        box = _parse_coords(args.coords)
        if not box:
            emit({"ok": False, "error": "bad_coords",
                  "message": "--coords 需为 x1,y1,x2,y2 四个整数像素坐标，且 x2>x1、y2>y1"})
            return EXIT_ERROR
        _emit_box(box)
        return EXIT_OK

    source = Path(args.file).expanduser() if args.file else None
    temp_path = None
    if args.url:
        try:
            with urllib.request.urlopen(args.url, timeout=args.download_timeout) as resp:
                data = resp.read()
        except (urllib.error.HTTPError, urllib.error.URLError) as e:
            emit({"ok": False, "error": "download_failed", "message": str(e)})
            return EXIT_ERROR
        suffix = Path(urllib.parse.urlparse(args.url).path).suffix or ".mp4"
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
            f.write(data)
            temp_path = Path(f.name)
        source = temp_path
    if source is None or not source.is_file():
        emit({"ok": False, "error": "file_not_found",
              "message": "框选需要本地视频（--file）或可下载的视频 URL（--url）"})
        return EXIT_ERROR

    try:
        import cv2
    except ImportError:
        emit({"ok": False, "error": "opencv_missing",
              "message": "框选需要 opencv-python：pip install opencv-python",
              "hint": "无桌面环境时可用 --coords x1,y1,x2,y2 直接给出像素坐标"})
        return EXIT_ERROR

    try:
        cap = cv2.VideoCapture(str(source))
        if not cap.isOpened():
            emit({"ok": False, "error": "video_open_failed", "path": str(source)})
            return EXIT_ERROR
        if args.frame_time and args.frame_time > 0:
            cap.set(cv2.CAP_PROP_POS_MSEC, args.frame_time * 1000.0)
        ok, frame = cap.read()
        cap.release()
        if not ok or frame is None:
            emit({"ok": False, "error": "frame_read_failed",
                  "message": "无法读取指定时间点的画面，试试更小的 --frame-time"})
            return EXIT_ERROR
        height, width = frame.shape[:2]
        scale = min(1.0, float(args.max_width) / float(width)) if width > 0 else 1.0
        preview = cv2.resize(frame, None, fx=scale, fy=scale) if scale < 1.0 else frame
        try:
            rect = cv2.selectROI(
                "Select watermark ROI - drag then press Enter (c to cancel)",
                preview, fromCenter=False, showCrosshair=True)
            cv2.destroyAllWindows()
        except Exception as exc:  # noqa: BLE001 - headless 环境下 HighGUI 会抛错
            emit({"ok": False, "error": "headless",
                  "message": f"无法打开 OpenCV 图形窗口：{exc}",
                  "hint": "请在有桌面的机器上运行；或改用 --coords x1,y1,x2,y2"})
            return EXIT_ERROR
        x, y, w, h = [int(v) for v in rect]
        if w <= 0 or h <= 0:
            emit({"ok": False, "error": "cancelled", "message": "未框选有效区域或已取消"})
            return EXIT_ERROR
        box = {
            "x1": int(round(x / scale)), "y1": int(round(y / scale)),
            "x2": int(round((x + w) / scale)), "y2": int(round((y + h) / scale)),
        }
        _emit_box(box, {"width": width, "height": height, "frame_time": args.frame_time})
        return EXIT_OK
    finally:
        if temp_path:
            try:
                temp_path.unlink()
            except OSError:
                pass


def _build_payload(args):
    payload = {"slug": args.slug}
    if args.input_file and args.slug == WATERMARK_SLUG:
        emit({"ok": False, "error": "watermark_needs_url",
              "message": "视频水印擦除只接受公网链接；先用 upload 子命令上传本地视频取得 public_url",
              "hint": f"python3 {Path(__file__).as_posix()} upload --file <视频>"})
        sys.exit(EXIT_ERROR)
    if args.input_url:
        payload["input_url"] = args.input_url
    elif args.input_file:
        p = Path(args.input_file)
        if not p.exists():
            emit({"ok": False, "error": "file_not_found", "path": str(p)})
            sys.exit(EXIT_ERROR)
        payload["input_base64"] = base64.b64encode(p.read_bytes()).decode("utf-8")
    elif args.input_base64:
        payload["input_base64"] = args.input_base64
    if args.params:
        try:
            payload["params"] = json.loads(args.params)
        except ValueError:
            emit({"ok": False, "error": "bad_params", "message": "--params 需为合法 JSON"})
            sys.exit(EXIT_ERROR)
    for kv in args.param or []:
        if "=" not in kv:
            emit({"ok": False, "error": "bad_param", "message": f"--param 需形如 key=value，收到：{kv}"})
            sys.exit(EXIT_ERROR)
        k, v = kv.split("=", 1)
        try:
            value = json.loads(v)
        except (ValueError, TypeError):
            value = v
        payload.setdefault("params", {})[k] = value
    if getattr(args, "coords", None):
        box = _parse_coords(args.coords)
        if not box:
            emit({"ok": False, "error": "bad_coords",
                  "message": "--coords 需为 x1,y1,x2,y2 四个整数像素坐标，且 x2>x1、y2>y1"})
            sys.exit(EXIT_ERROR)
        payload.setdefault("params", {}).update(box)
    if args.duration_seconds is not None:
        payload["duration_seconds"] = args.duration_seconds
    if args.output_format:
        payload["output_format"] = args.output_format
    return payload


def cmd_invoke(args):
    key, _ = require_key(args)
    base = get_base_url(args)
    payload = _build_payload(args)
    result = unwrap(request_json("POST", f"{base}/api/capability/invoke", api_key=key, body=payload,
                                 timeout=args.timeout))

    if result.get("status") == "processing" and args.wait:
        request_id = result.get("request_id")
        deadline = time.time() + args.wait_timeout
        while time.time() < deadline:
            time.sleep(args.poll_interval)
            task = unwrap(request_json("GET", f"{base}/api/capability/tasks/{request_id}", api_key=key))
            result = task
            if task.get("status") != "processing":
                break
        if result.get("status") == "processing":
            emit({"ok": False, "error": "timeout", "message": "任务仍在处理中，请稍后用 task 命令查询结果",
                  "result": result})
            return EXIT_ERROR

    ok = result.get("status") == "success"
    out = {"ok": ok, "result": result}
    out.update(_balance_hint(result.get("remaining_points")))
    emit(out)
    return EXIT_OK if ok else EXIT_ERROR


def cmd_task(args):
    key, _ = require_key(args)
    base = get_base_url(args)
    result = unwrap(request_json("GET", f"{base}/api/capability/tasks/{args.request_id}", api_key=key))
    ok = result.get("status") == "success"
    out = {"ok": ok, "result": result}
    out.update(_balance_hint(result.get("remaining_points")))
    emit(out)
    return EXIT_OK if ok else EXIT_ERROR


def build_parser():
    p = argparse.ArgumentParser(
        description=f"{SKILL_NAME} CLI（{PUBLISHER} 出品；初次使用建议先运行 doctor 自检）")
    p.add_argument("--base-url", default=None, help=f"服务地址，默认 {DEFAULT_BASE_URL}")
    p.add_argument("--key", default=None, help="临时指定 API Key（优先于环境变量与 .env）")
    sub = p.add_subparsers(dest="command", required=True)

    sdr = sub.add_parser("doctor", help="环境自检与安装指导（初次使用先跑这个）")
    sdr.set_defaults(func=cmd_doctor)

    sc = sub.add_parser("check-key", help="检查 API Key 是否已配置（并查询余额）")
    sc.set_defaults(func=cmd_check_key)

    ss = sub.add_parser("save-key", help="保存 API Key 到 .env")
    ss.add_argument("key", help="能力 Hub API Key（cbk_ 开头）")
    ss.set_defaults(func=cmd_save_key)

    sl = sub.add_parser("list", help="获取能力列表")
    sl.add_argument("--full", action="store_true", help="输出完整字段（含示例与参数结构）")
    sl.set_defaults(func=cmd_list)

    sd = sub.add_parser("detail", help="获取能力详情与调用方式")
    sd.add_argument("slug", nargs="?", default=WATERMARK_SLUG,
                     help="能力 slug，默认 video-watermark-removal（LCWR 高质量视频去水印）")
    sd.set_defaults(func=cmd_detail)

    su = sub.add_parser("upload", help="上传本地视频，返回公网链接")
    su.add_argument("--file", required=True, help="本地视频文件")
    su.add_argument("--content-type", default=None, help="覆盖 Content-Type")
    su.add_argument("--timeout", type=int, default=600, help="PUT 超时秒数，默认 600")
    su.set_defaults(func=cmd_upload)

    sr = sub.add_parser("roi", help="用 OpenCV 弹窗框选水印区域，输出坐标 JSON")
    sr.add_argument("--file", help="本地视频文件")
    sr.add_argument("--url", help="视频 URL（下载后框选）")
    sr.add_argument("--frame-time", type=float, default=0.0, help="取第几秒的画面，默认首帧")
    sr.add_argument("--max-width", type=int, default=1280, help="预览最大宽度，默认 1280")
    sr.add_argument("--download-timeout", type=int, default=120, help="下载 URL 的超时秒数")
    sr.add_argument("--coords", help="跳过弹窗，直接给出 x1,y1,x2,y2")
    sr.set_defaults(func=cmd_roi)

    si = sub.add_parser("invoke", help="调用能力")
    si.add_argument("--slug", default=WATERMARK_SLUG,
                      help="能力 slug，默认 video-watermark-removal（LCWR 高质量视频去水印）")
    si.add_argument("--input-url", help="输入文件 URL")
    si.add_argument("--input-file", help="本地文件路径（自动转 base64；水印能力禁用）")
    si.add_argument("--input-base64", help="输入文件 base64")
    si.add_argument("--params", help="附加参数 JSON 字符串")
    si.add_argument("--param", action="append", help="附加参数，形如 key=value，可重复")
    si.add_argument("--coords", help="水印区域坐标 x1,y1,x2,y2（像素），自动写入 params")
    si.add_argument("--duration-seconds", type=float, help="视频时长（秒），视频类能力用于积分预校验")
    si.add_argument("--output-format", help="期望输出格式")
    si.add_argument("--wait", action="store_true", help="异步能力自动轮询至终态")
    si.add_argument("--poll-interval", type=int, default=15, help="轮询间隔秒数，默认 15")
    si.add_argument("--wait-timeout", type=int, default=900, help="最长等待秒数，默认 900")
    si.add_argument("--timeout", type=int, default=120, help="单次请求超时秒数，默认 120")
    si.set_defaults(func=cmd_invoke)

    st = sub.add_parser("task", help="查询异步任务结果")
    st.add_argument("request_id", type=int, help="调用返回的 request_id")
    st.set_defaults(func=cmd_task)

    return p


def main():
    if sys.version_info < (3, 8):
        print(json.dumps({
            "ok": False,
            "error": "python_too_old",
            "message": f"需要 Python 3.8+，当前 {sys.version.split()[0]}",
            "guide": "请升级 Python 后重试：https://www.python.org/downloads/",
        }, ensure_ascii=False))
        return EXIT_ERROR
    args = build_parser().parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
