# 高质量视频去水印LCWR · 接口参考

> 出品方：晴沐智坊 · 从「晴沐AI创作辅助能力套装」提取的去水印链路专用文档。
> 基础地址：`https://www.licorxj.online`（可用 `--base-url` / `QM_HUB_BASE_URL` 覆盖）
> 鉴权：`Authorization: Bearer cbk_xxx`（能力 Hub 专用 Key）
> 统一响应：`{"code": 0, "msg": "success", "data": ...}`；业务失败 `code != 0`（HTTP 状态码仍为 200，需判断 `code`）。

**计费口径：1 积分 = 人民币 1 分钱（0.01 元）**；本能力按秒计费，1.3 积分/秒，不足 10 秒按 10 秒。以 `detail` 实时返回的 `billing` 为准。

---

## 1. 能力详情（公开）

`GET /api/capability/capabilities/video-watermark-removal`

按 slug 查询，返回 `params_schema`、`example_request` / `example_response`、`points_per_call`、`billing` 等字段。
调用前用它确认输入方式与实时价格；`input_type` 应为仅 `url`。

> 排障时可用 `GET /api/capability/capabilities` 拉全量列表，确认水印能力 `status=enabled`、`is_public=true`。

## 2. 调用能力（需鉴权）

`POST /api/capability/invoke`

请求体：

```json
{
  "slug": "video-watermark-removal",
  "input_url": "https://example.com/a.mp4",
  "input_base64": null,
  "params": {"x1": 100, "y1": 100, "x2": 400, "y2": 300, "mode": "normal"},
  "duration_seconds": 120
}
```

- **`input_url` 优先且必须**：该能力 handler 只读取 `input_url`，不读 `input_base64`；上游按 `video_link` 主动拉取，因此必须是可匿名 GET 的公网链接。本地视频需先通过上传接口取得公网链接（见第 4 节）。
- `duration_seconds`：建议传入视频时长，用于提交前积分预校验。
- `params` 字段（全部可选，后端原值透传给上游）：

| 字段 | 说明 |
|---|---|
| `x1` / `y1` | 水印矩形左上角像素坐标（number，默认 0） |
| `x2` / `y2` | 水印矩形右下角像素坐标（number，默认 0） |
| `mode` | `normal`（默认）/ `protect`（保护模式） |

省略坐标或全 0 = **全屏去除**；传非零矩形 = **精确标注区域**。坐标不做任何换算或校验，取自原视频帧的像素坐标系。可用 CLI `roi` 子命令通过 OpenCV 弹窗框选得到 `params_json`，直接作为 `invoke --params` 的值；无 GUI 时用 `--coords x1,y1,x2,y2`。

返回（`CapabilityInvokeResponse`）：

| 字段 | 说明 |
|---|---|
| `status` | `success` / `processing` / `failed` / `error` / `insufficient_points` |
| `result_url` | 结果文件地址（成功后必须交给用户） |
| `points_charged` / `remaining_points` | 本次扣减与剩余积分 |
| `message` | 说明或错误信息 |
| `error_code` | 失败错误码（400 / 402 / 429 / 500） |
| `request_id` | 调用日志 ID，用于轮询任务 |
| `task_id` / `external_status` | 异步任务的上游 ID 与状态（`processing` 时） |
| `duration_seconds` / `billing_seconds` / `fee` | 异步任务的时长与计费信息 |

计费：异步能力提交时不扣费，任务成功结算时按上游视频时长计费（不足 10 秒按 10 秒，1.3 积分/秒）；生成 / 处理失败不扣费。

## 3. 查询异步任务（需鉴权）

`GET /api/capability/tasks/{request_id}`

- 已终态：`status` 为 `success` / `failed` / `error`，直接返回缓存结果。
- 仍为 `processing`：懒查询上游，返回 `processing`，需继续轮询。
- 不存在或不属于当前用户：`{"code":404,"msg":"任务不存在"}`。

登录态（JWT）另有一个等价端点 `GET /api/capability/my/tasks/{request_id}`，智能体场景用 Key 版即可。

CLI 封装：`invoke --wait` 自动轮询；或 `task <request_id>` 单次查询。

## 4. 视频上传接口（需 `cbk_` Key）

### 申请上传

`POST /api/capability/upload-ticket`

```json
{
  "filename": "a.mp4",
  "content_type": "video/mp4",
  "size": 10485760
}
```

- 支持 `.mp4/.mov/.m4v/.webm/.mkv/.avi`，上限 512MB。
- 返回 `data`：`{key, method:"PUT", upload_url, headers, public_url, expires_in}`。

### 上传与确认

1. 客户端 `PUT upload_url`，请求头必须带 `headers` 中的 `Content-Type`，body 为文件原始字节。
2. `POST /api/capability/upload-complete`，请求体 `{"key": "<上一步返回的 key>"}`；服务端确认后返回 `data.public_url`。
3. 把 `public_url` 作为 `POST /api/capability/invoke` 的 `input_url`。

CLI 一步封装：`python3 scripts/lcwr.py upload --file ./a.mp4`，输出 `public_url`。

> `public_url` 是公网可访问链接，任何拿到链接的人都能访问，注意视频隐私；上传端点与能力调用共用同一个 `cbk_` Key。

上传得到的 `public_url` 短期有效：请及时调用去水印并保存 `result_url`（结果链接不受影响），过期后需重新 `upload`。

## 5. Key 身份与余额（需鉴权）

`GET /api/capability/me`

鉴权：`Authorization: Bearer cbk_xxx`。供 Skill 在调用前校验 Key 并判断是否需要提醒充值。

返回 `data`：

| 字段 | 说明 |
|---|---|
| `user_id` / `username` | 账号信息 |
| `total_points` | 当前积分余额（1 积分 = 人民币 1 分钱） |
| `low_balance` | 余额是否低于阈值（当前阈值 10 积分） |
| `low_balance_threshold` | 阈值，默认 10 |
| `recharge_url` | 购买地址 https://www.licorxj.online/capability-hub |
| `key_id` / `key_name` | 本次使用的 Key |

CLI：`check-key` 会调用该端点，输出 `total_points` 与 `low_balance`；`low_balance=true` 时附带充值提醒与购买地址。`invoke` / `task` 返回的 `remaining_points` 低于阈值时也会附带同样的提醒字段。

## 6. Key 的创建入口

https://www.licorxj.online/capability-hub ：注册并登录 → 页面内「API Key 管理」创建（明文仅显示一次，格式为 `cbk_` 前缀），然后把 Key 贴回给智能体，由智能体用 `save-key` 保存到 `.env`（权限 600）。

自动化场景也可用 `POST /api/capability/keys/issue` 以用户名+密码换取 Key（`data.raw_key` 明文仅此一次，服务端只存哈希）。同一账号启用密钥上限 10 个；密码连续错误 10 次锁定 10 分钟。

## 7. 端点与鉴权速查

| 端点 | 方法 | 鉴权 | 链路环节 |
|---|---|---|---|
| `/api/capability/capabilities` | GET | 公开 | 能力在线检查 |
| `/api/capability/capabilities/{slug}` | GET | 公开 | 参数与价格确认 |
| `/api/capability/upload-ticket` | POST | `cbk_` Key | 上传视频（申请） |
| `/api/capability/upload-complete` | POST | `cbk_` Key | 上传视频（确认） |
| `/api/capability/invoke` | POST | `cbk_` Key | 发起去水印 |
| `/api/capability/tasks/{request_id}` | GET | `cbk_` Key | 轮询异步结果 |
| `/api/capability/me` | GET | `cbk_` Key | Key 校验与余额 |

需浏览器登录态 JWT 的端点（`/api/capability/logs`、`/api/capability/summary`、Key 管理 CRUD）智能体不直接使用。
