# 高质量视频去水印LCWR · 安装指南

> 出品方：**晴沐智坊** · 从「晴沐AI创作辅助能力套装」独立出来的去水印专用 Skill。采用专门训练的 AI 模型重绘式去除，无痕保持画面一致性与背景；全屏去除技术可自动检测水印与字幕，无需框选，对硬字幕、移动字幕、AI 水印、移动水印效果出色。
> 保留完整链路：环境自检 → Key 校验与余额 → 上传本地视频 → 框选水印区域 → 异步调用与轮询 → 结果交付。

## 1. 安装

解压后目录结构：

```
lcwr-video-watermark-removal/
├── SKILL.md              # Skill 定义（智能体读取的入口）
├── INSTALL.md            # 本文件
├── .env.example          # API Key 配置模板
├── scripts/lcwr.py       # 命令行工具（纯标准库，Python 3.8+）
└── references/api.md     # 去水印链路接口参考
```

| 级别 | 路径 | 适用场景 |
|---|---|---|
| 用户级（推荐） | `~/.workbuddy/skills/lcwr-video-watermark-removal` | WorkBuddy 所有项目都能用 |
| 兼容路径 | `~/.codebuddy/skills/lcwr-video-watermark-removal` | CodeBuddy / 其它支持 Skill 的 Agent |
| 项目级 | `<项目根目录>/.workbuddy/skills/lcwr-video-watermark-removal` | 只在本项目生效 |

Linux / macOS：

```bash
mkdir -p ~/.workbuddy/skills
cp -r lcwr-video-watermark-removal ~/.workbuddy/skills/
```

Windows PowerShell：

```powershell
New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.workbuddy\skills"
Copy-Item -Recurse -Force lcwr-video-watermark-removal "$env:USERPROFILE\.workbuddy\skills\"
```

安装后新建一次会话，智能体即可自动发现；也可直接在对话里点名「用 高质量视频去水印LCWR 去掉这个视频的水印」。

## 2. 配置 API Key（调用前必做）

本 Skill 与「晴沐AI创作辅助能力套装」共用同一套能力 Hub Key（`cbk_` 开头），**已配置过套装的用户无需重新申请**：

- 已装套装：把 `~/.workbuddy/skills/qingmu-skill-hub/.env` 复制到本 Skill 目录即可；
- 或设置系统环境变量 `QM_KEY=cbk_xxxxx`（优先级高于 `.env`）；
- 首次使用：打开 https://www.licorxj.online/capability-hub 注册登录 →「API Key 管理」创建（明文仅显示一次）→ 把 Key 贴回给智能体，由它执行 `save-key` 保存。

```bash
cd ~/.workbuddy/skills/lcwr-video-watermark-removal
python3 scripts/lcwr.py doctor          # 环境自检
python3 scripts/lcwr.py check-key       # 校验 Key 并查询余额
python3 scripts/lcwr.py save-key 'cbk_你的Key'
```

`doctor` 输出 `ready:true` 即关键依赖齐全；`opencv` / `gui` 为可选项，缺失只影响弹窗框选，可用 `--coords` 代替。

## 3. 试用

```bash
cd ~/.workbuddy/skills/lcwr-video-watermark-removal

python3 scripts/lcwr.py detail                                   # 查看水印能力参数与实时价格
python3 scripts/lcwr.py upload --file ./a.mp4                    # 上传本地视频，返回公网链接
python3 scripts/lcwr.py roi --file ./a.mp4 --frame-time 3        # 精确框选（可选）
python3 scripts/lcwr.py invoke --input-url '<public_url>' --duration-seconds 120 --wait
```

全屏去除不加坐标即可；精确区域用 `--coords x1,y1,x2,y2` 或 `--params '{"x1":100,"y1":100,"x2":400,"y2":300}'`。
成功后把返回的 `result.result_url` 交给用户。

## 4. 计费与限制

- **1 积分 = 人民币 1 分钱（0.01 元）**；去水印按秒计费，1.3 积分/秒，不足 10 秒按 10 秒；失败不扣费。以 `detail` 实时返回为准。
- 视频上限 512MB，支持 mp4/mov/m4v/webm/mkv/avi。
- `public_url` 是公网可访问链接，注意视频隐私；源视频链接短期有效，请及时完成处理并保存结果链接。
- 余额低于 10 积分时 `check-key` 会提示充值：https://www.licorxj.online/capability-hub

## 5. 常见问题

| 现象 | 处理 |
|---|---|
| `need_key=true` | 见第 2 节配置 Key；或直接设置环境变量 `QM_KEY` |
| `auth_failed` | Key 无效/过期，到门户重新创建并 `save-key` 覆盖 |
| `insufficient_points` | 到门户充值后重试 |
| `opencv_missing` / `headless` | 安装 `opencv-python` 或换有桌面的机器；也可直接用 `--coords` |
| `watermark_needs_url` | 水印能力只吃公网 URL，先用 `upload --file` 拿 `public_url` |
| `upload_failed` | 检查文件是否可读、格式与大小是否符合要求，稍后重试 `upload` |
| `error=timeout` | 稍后 `task <request_id>` 查询，**不要重复提交以免重复扣费** |

## 6. 卸载

```bash
rm -rf ~/.workbuddy/skills/lcwr-video-watermark-removal
```
