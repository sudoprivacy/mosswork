---
name: skillhub-skill-lcwr-video-watermark-removal
description: "高质量视频去水印LCWR（晴沐智坊出品）。采用专门训练的 AI 模型进行重绘式去除，能完美保持画面一致性与背景，做到无痕擦除；创新性的全屏去除技术可自动检测并擦除水印与字幕，对不想框选区域以及智能体调用场景具有很好的使用体验；对视频上的硬字幕、移动字幕、AI 水印、移动水印拥有很好的效果。支持整帧全屏去除与精确框选水印区域两种模式、保护模式，自动等待任务完成并交付结果链接。当用户提到去水印、视频水印擦除、去掉字幕、全屏去除、框选水印区域、精确标注水印位置、LCWR、晴沐去水印、水印保护模式时使用本 skill。调用前会检查 API Key，缺失时引导用户到 https://www.licorxj.online/capability-hub 注册登录获取并保存。"
---

# 高质量视频去水印LCWR

> 出品方：**晴沐智坊** · 从「晴沐AI创作辅助能力套装」中独立出来的去水印专用 Skill。
> 技术标识（目录名与 `name`）为 `lcwr-video-watermark-removal`；底层能力 slug 仍为 `video-watermark-removal`。

## 用途

采用**专门训练的 AI 模型做重绘式去除**，能完美保持画面一致性与背景，做到无痕擦除；创新性的**全屏去除技术**可自动检测并擦除水印与字幕，用户无需框选区域，在智能体调用场景下也有很好的使用体验。对视频上的**硬字幕、移动字幕、AI 水印、移动水印**拥有很好的效果。

完整链路：

1. 自检环境 / 检查并保存 API Key / 查询余额
2. 确认视频来源（公网 URL 或本地文件）与处理方式（全屏 / 精确区域）
3. 上传本地视频，取得处理服务可访问的公网链接 `public_url`
4. 可选：打开视频画面框选水印矩形，得到像素坐标
5. 发起去水印调用，自动轮询异步任务直到终态
6. 把 `result.result_url` 交给用户

## 计费口径

**1 积分 = 人民币 1 分钱（0.01 元）**。本能力**按秒计费**：1.3 积分/秒（不足 10 秒按 10 秒），异步任务提交时不扣费，成功结算时按上游视频时长扣费，处理失败不扣费。实际价格以 `detail` 实时返回的 `billing` 为准，不要凭文档写死价格。

## 环境要求

- Python 3.8+（除框选功能外仅依赖标准库）
- 一个能力 Hub API Key（`cbk_` 开头），获取地址 https://www.licorxj.online/capability-hub
- 精确框选（可选）：`pip install opencv-python` + 有图形桌面的运行环境；无 GUI 时改用 `--coords` 手动给坐标

## 工作流

### 第 0 步：环境自检（初次运行 / 换机 / 排障时先做）

```bash
python3 scripts/lcwr.py doctor
```

输出 `ready`、逐项 `checks`、`missing_required` 与 `guides`：

- `ready=false`：按 `missing_required` 与 `guides` 逐条处理（缺 Key → 注册获取；网络不通 → 检查网络或 `--base-url`；Python 过旧 → 升级到 3.8+）。
- `opencv` / `gui` 是**可选**项：失败只影响 `roi` 弹窗框选，可用 `--coords x1,y1,x2,y2` 代替，不阻断去水印。
- `low_balance=true`：按第 1 步的余额提醒处理。

> 推荐顺序：`doctor`（自检）→ `check-key`（Key 与余额）→ `detail`（参数与价格）→ 输入准备 → `invoke`（调用）。

### 第 1 步：检查 API Key（必做，在调用之前）

```bash
python3 scripts/lcwr.py check-key
```

判定规则（脚本已实现，按此优先级）：
1. 命令行 `--key`
2. 系统环境变量 `QM_KEY`
3. 本 skill 目录 `.env`
4. 上级目录 `.env`

- 退出码 `0`：已配置，继续下一步。
- 退出码 `2`：未配置（`need_key=true`）。此时**必须停止调用**，向用户输出：
  > 需要能力 Hub API Key。请打开 https://www.licorxj.online/capability-hub 注册并登录，在「API Key 管理」创建并复制 API Key（`cbk_` 开头），然后把 Key 贴回给我，我会用 `save-key` 自动保存到 skill 的 `.env`，下次直接调用。

**余额提醒**：`check-key` 会远程校验 Key 并返回 `total_points`、`low_balance`（阈值 10 积分）。

- `low_balance=true`：**必须提醒用户充值** → https://www.licorxj.online/capability-hub 购买。
- `key_valid=false`（`balance_error` 为 `http_401` / `http_403`）：Key 无效或已过期，引导用户重新创建并贴回保存。
- `balance_error` 为其它值：网络或服务异常，Key 本地已配置，可继续尝试调用，稍后重试余额查询。

### 第 2 步：保存用户贴回的 Key

```bash
python3 scripts/lcwr.py save-key 'cbk_xxxxx'
```

脚本写入 `.env` 并设为 600 权限。保存后重新执行 `check-key` 确认，再继续。
若用户此前已安装「晴沐AI创作辅助能力套装」并配置过 `.env`，可直接复制该 `.env` 到本 skill 目录，或设置环境变量 `QM_KEY`（同一套 Key 通用）。

### 第 3 步：确认能力参数与价格（推荐）

```bash
python3 scripts/lcwr.py detail                     # 默认查 video-watermark-removal
python3 scripts/lcwr.py detail video-watermark-removal
```

返回 `params_schema`、服务端维护的示例与 `how_to_call`。调用前确认：输入方式（**只接受公网 `input_url`**）、必需参数、计费方式（`billing.mode = per_second`）。

### 第 4 步：向用户确认两件事（必做）

1. **水印处理方式**：
   - **A. 全屏去除**：不标记位置，整帧自动识别擦除
   - **B. 精确标注水印区域**：打开视频画面，用鼠标框选水印所在矩形
2. **视频来源**：本地文件路径，还是已有的公网 URL

> `video-watermark-removal` 的后端 handler **只读取 `input_url`**（不读 `input_base64`），因此需要先取得公网可访问的视频链接。**禁止**对水印能力用 `--input-file`（脚本会拦截并返回 `watermark_needs_url`）。

### 第 5 步：准备工作 —— 上传本地视频（仅当用户给的是本地文件）

```bash
python3 scripts/lcwr.py upload --file ./a.mp4
```

执行后返回 `public_url`（公网可访问的视频链接），直接作为下一步 `--input-url` 的值。
支持 mp4/mov/m4v/webm/mkv/avi，上限 512MB。已有公网 URL 时跳过此步。

### 第 6 步（可选）：精确标注水印区域

```bash
python3 scripts/lcwr.py roi --file ./a.mp4 --frame-time 3
```

拖拽框选 → 按 Enter 确认（按 c 取消）。返回 `params_json`，例如 `{"x1": 100, "y1": 100, "x2": 400, "y2": 300}`。坐标为**原视频像素坐标**，预览缩放已自动换算回去，`video_size` 给出原视频宽高。
若用户只有 URL：`roi --url '<url>' --frame-time 3` 会下载后框选。
无桌面环境或未装 cv2 时，`roi` 返回 `opencv_missing` / `headless`。此时**不要强行框选**，请让用户直接给出 `x1,y1,x2,y2`，用 `roi --coords 100,100,400,300` 生成 `params_json` 后继续。

### 第 7 步：调用去水印

**分支 A：全屏去除**（不带任何坐标，后端默认 `x1=y1=x2=y2=0`）

```bash
python3 scripts/lcwr.py invoke --input-url '<public_url>' --duration-seconds 120 --wait
```

可追加 `--param mode=protect` 启用保护模式。

**分支 B：精确标注区域**（两种写法等价）

```bash
python3 scripts/lcwr.py invoke --input-url '<public_url>' \
    --params '{"x1": 100, "y1": 100, "x2": 400, "y2": 300, "mode": "normal"}' \
    --duration-seconds 120 --wait

python3 scripts/lcwr.py invoke --input-url '<public_url>' --coords 100,100,400,300 --wait
```

- `--wait`：异步任务（`status=processing`）自动轮询至终态，默认每 15 秒一次、最多 15 分钟（`--poll-interval` / `--wait-timeout` 可调）。
- 未加 `--wait` 而返回 `processing` 时，用返回的 `request_id` 查询：
  ```bash
  python3 scripts/lcwr.py task <request_id>
  ```
- 成功时 `result.result_url` 即结果文件地址，**必须把该链接交给用户**。

> 坐标是可选的 number 字段，后端原值透传给上游；省略或全 0 = 全屏。`mode` 仅 `normal` / `protect`，与区域无关。

## 命令速查

| 命令 | 作用 |
|---|---|
| `doctor` | 环境自检（Python / Key / 网络 / opencv / GUI / 余额） |
| `check-key` | 检查 Key 并查询余额、充值提醒 |
| `save-key <key>` | 保存 Key 到 `.env`（600 权限） |
| `detail [slug]` | 查看能力参数结构与实时价格，默认水印能力 |
| `upload --file <视频>` | 上传本地视频，返回公网链接 `public_url` |
| `roi --file/--url` | 弹窗框选水印区域；`--coords` 手动给坐标 |
| `invoke` | 发起去水印，`--wait` 自动轮询 |
| `task <request_id>` | 查询异步任务结果 |
| `list` / `list --full` | 能力列表（排障时可确认水印能力是否在线） |

所有命令输出 JSON，直接解析即可，不要凭猜测构造请求体。

## 错误处理

| 退出码 / 输出 | 含义 | 处理 |
|---|---|---|
| `need_key=true` | 未配置 API Key | 引导用户到 https://www.licorxj.online/capability-hub 注册登录并创建 Key，贴回后 `save-key` 保存 |
| `error=auth_failed` | Key 无效 / 已禁用 / 过期 | 让用户重新创建 Key，贴回后 `save-key` 覆盖 |
| `error=insufficient_points` / `status=insufficient_points` | 积分不足 | 提示到门户充值后重试（1 积分 = 人民币 1 分钱） |
| `status=error` | 处理失败 | 输出 `message`；检查参数与视频格式后重试 |
| `error=timeout` | 异步任务超时未完成 | 稍后 `task <request_id>` 查询，**不重复提交以免重复扣费** |
| `error=watermark_needs_url` | 误用 `--input-file` | 先用 `upload --file` 拿 `public_url`，再用 `--input-url` |
| `error=upload_failed` | 视频上传失败 | 检查文件是否可读、格式与大小是否符合要求，稍后重试 `upload` |
| `error=opencv_missing` / `headless` | 缺 `opencv-python` 或无图形桌面 | 安装依赖或换有桌面的机器；也可让用户直接给坐标并用 `--coords` |
| `error=bad_coords` | 坐标格式错误 | 需 `x1,y1,x2,y2` 四个整数像素坐标，且 `x2>x1`、`y2>y1` |
| `error=network_error` / `http_*` | 网络或服务异常 | 检查网络或 `--base-url`，稍后重试 |

## 约定与注意

- 服务地址默认 `https://www.licorxj.online`；可用 `--base-url` 或 `.env` 中 `QM_HUB_BASE_URL` 覆盖。
- `detail` / `list` 是公开接口；`invoke` / `task` / `upload` 必须带 Key。
- 响应统一为 `{"code":0,"msg":"success","data":...}`，脚本已自动解包 `data`；`code != 0` 视为失败。
- 密钥只保存在本地 `.env`，绝不写入日志、提交到仓库或回显明文（`check-key` 仅显示掩码）。
- **隐私**：上传得到的 `public_url` 是公网可访问直链，任何拿到链接的人都能访问，务必提醒用户注意视频隐私；上传与去水印调用共用同一个 `cbk_` Key。
- **源视频链接有有效期**：上传得到的源视频链接为短期有效，请及时完成去水印并把 `result.result_url` 交给用户；结果链接不受影响。若之后还要复用同一视频，需重新 `upload`。
- `--param k=v` 会自动把数字/布尔/JSON 字面量转型，坐标也可直接用 `--coords`。
- 计费换算：**1 积分 = 人民币 1 分钱（0.01 元）**。
- 更完整的端点说明见 `@references/api.md`，安装与 Key 配置见 `@INSTALL.md`。
