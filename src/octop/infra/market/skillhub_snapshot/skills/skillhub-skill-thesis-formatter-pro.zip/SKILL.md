---
name: skillhub-skill-thesis-formatter-pro
description: "一键规范毕业论文/学位论文格式并生成送审稿。Use whenever the user mentions 论文格式、毕业论文、学位论文、格式规范、论文排版、封面/目录/页眉页脚、参考文献、GB/T 7714、图表编号、盲审、查重、Word论文、thesis、dissertation、paper format — even if they don't explicitly say \"skill\"。"
---

# 论文格式一键规范 (thesis-formatter)

把任意 Word 初稿自动修正为符合学校《毕业论文撰写规范》的终稿，产出**规范 Word + 送审 PDF + 格式体检报告**，并支持前后对比预览。

## 何时触发

- 用户提到“论文格式”“毕业论文”“学位论文”“格式不对”“排版”“封面/目录/页眉”“参考文献”“GB/T 7714”“图表编号”“盲审”“查重”
- 用户上传了 `*.docx / *.doc / *.pdf` 论文初稿
- 用户需要“帮我改论文格式”“按学校模板排一下”“导出盲审版”
- 用户询问“论文格式怎么才算规范”“参考文献怎么排”

> 即使用户只说“论文老师说格式不行”“帮我看看这论文哪里不规范”，也应触发本技能。

## 输入与识别

按优先级尝试：

1. **Word 文档** — `*.docx`（优先）/ `*.doc`（先转 docx）
2. **PDF 论文** — 需先转结构化再回写 docx
3. **自然语言/截图** — 规范条目口述或模板截图，先确认校级规范
4. **已有项目数据** — `D:\daima\lunwengeshi` 中的模板配置与 `templates/` 样式

若用户未指定学校模板，默认使用**本科毕业论文通用规范**，并追问：学校/学院是否有专用模板（页边距、字体、参考文献样式是否特殊）。

## 核心能力

### 1. 封面与元数据

- 校验字段：校名、论文题目、学院、专业、学号、姓名、指导教师、完成日期
- 修正：题目二号黑体居中，其余三号仿宋；下划线对齐；日期为中文大写或 `YYYY年MM月`

### 2. 目录自动生成

- 基于 `标题 1/2/3` 样式重建 TOC 域（`w:fldChar`），含点线与页码对齐
- 清理手打目录，保留原有章节结构

### 3. 标题分级与编号

- 三级结构：`1 / 1.1 / 1.1.1`，分别对应黑体三号/四号/小四，段前段后间距按规范
- 应用 `w:numPr` 多级列表，移除手打数字

### 4. 正文与页面

- 中文宋体小四 / 英文 Times New Roman 12pt，1.5 倍行距，首行缩进 2 字符，两端对齐
- A4，上 2.54cm 下 2.54cm 左 3.18cm 右 3.18cm；页眉含校名与题目，页脚分节：摘要罗马数字 `Ⅰ, Ⅱ`，正文阿拉伯数字 `1, 2`

### 5. 图表编号

- 按章编号：`图1-1 / 图2-1`、`表1-1 / 表2-1`，题注五号宋体居中，图在下表在上
- 扫描 `w:drawing / w:tbl`，重编号并更新正文交叉引用

### 6. 参考文献 GB/T 7714

- 著录顺序按正文引用顺序，`[1] [2] ...` 上标
- 校验必填：作者、题名、期刊/出版社、年、卷(期)、页码；缺项标为待补
- 示例：`[1] 张三. 深度学习研究[J]. 计算机学报, 2023, 46(5): 1021-1035.`

### 7. 盲审与导出

- 盲审版：移除封面学号/姓名/导师，页眉去个人信息，保留题目与编号
- 导出：`thesis-formatted.docx`（保留修订）、`thesis-final.pdf`（嵌入字体 + 书签）、`format-report.pdf`（12 项体检明细）

## 工作流

按序执行，跳过不适用步骤：

1. **读取文档** — 用 `documents:docx` 解析 `*.docx` 为结构化模型（段落/样式/编号/图/表/引用）
2. **体检** — 按 12 项清单逐项检查，产出 `[{id, title, status: ok|error|pend, detail}]`，计算合规率
3. **修正** — 对 `error/pend` 项应用自动修正（样式/编号/分节/TOC/引用），每项可单独回滚
4. **预览** — 生成修正前后对比视图（`visualize` 技能，fragment 写入会话可视化目录，不写入项目源码）
5. **导出** — 写回 `docx`（`documents:docx`）、转 `pdf`（`pdf` 技能，嵌入字体与书签）、生成体检报告
6. **交付** — 返回：① 对比预览 ② 三个下载文件 ③ 体检报告摘要

## 12 项体检清单

| # | 项 | 判定 |
|---|----|------|
| 1 | 封面信息完整性 | 字段齐全且字体字号正确 |
| 2 | 中英文摘要与关键词 | 摘要 300-500字，关键词 3-5个分号分隔 |
| 3 | 目录自动生成 | TOC 域且点线页码对齐 |
| 4 | 标题分级与编号 | 多级列表自动编号 |
| 5 | 正文字体与行距 | 宋体小四 + 1.5倍行距 + 首行缩进 |
| 6 | 页眉/页脚与页码 | 分节且罗马/阿拉伯分段 |
| 7 | 页边距与纸张 | A4 指定边距 |
| 8 | 图题与表题编号 | 按章编号且题注居中 |
| 9 | 参考文献 GB/T 7714 | 顺序与著录完整 |
| 10 | 脚注与附录 | 每页重编号 |
| 11 | 盲审信息脱敏 | 无个人信息 |
| 12 | PDF 嵌入字体与书签 | 字体嵌入且书签对应目录 |

## 输出规范

- **规范 Word**：`thesis-formatted.docx`，UTF-8，保留修订痕迹，样式基于模板 `Normal` + `Heading 1-3`
- **送审 PDF**：`thesis-final.pdf`，嵌入全部字体，书签层级 = 目录层级
- **体检报告**：`format-report.pdf` 或 JSON：
  ```json
  {
    "template": "本科毕业论文",
    "score": 58,
    "total": 12,
    "passed": 7,
    "items": [{"id": "heading", "title": "标题分级与编号", "status": "error", "detail": "二级标题未编号"}],
    "outputs": ["thesis-formatted.docx", "thesis-final.pdf"]
  }
  ```

## 示例

### 示例 1 — Word 初稿一键规范

用户上传 `thesis-draft.docx`，提示“老师说格式全不对”。

处理：
- 体检：5 项 error（摘要/目录/标题/字体/图表）、2 项 pend（页码/参考文献），合规率 42%
- 修正：重建 TOC、多级列表、统一字体行距、图重编号为 图1-1、参考文献按引用重排
- 产出：对比预览 + `thesis-formatted.docx` + `format-report.pdf`

### 示例 2 — 仅做体检不改

用户：“先帮我看看哪里不合规，不急着改”。

处理：仅执行体检，返回 12 项清单与合规率，不写回文档。

### 示例 3 — 导出盲审版

用户：“要一个盲审版 PDF”。

处理：在已修正文档上移除个人信息域，导出 `thesis-final.pdf`（盲审）。

## 与 lunwengeshi 项目集成

- 模板配置：`src/main/resources/templates` 下按 `本科/硕士/期刊` 分模板，`application.properties` 加 `thesis.template=本科` 与 `thesis.blind=false`
- 后端：`com.lunwengeshi.service.FormatService`（体检+修正）、`ExportService`（docx/pdf/report）
- Controller：`POST /api/thesis/upload`（上传）、`GET /api/thesis/check`（体检）、`POST /api/thesis/fix`（修正）、`GET /api/thesis/export/{type}`（docx/pdf/report）
- 依赖：`documents:docx` 负责 docx 读写，`pdf` 负责 PDF 导出与字体嵌入；`pom.xml` 现有 `spring-boot-starter-thymeleaf` 用于预览页

## 边界与注意事项

- 不做内容改写与查重，仅做格式；如用户要求“降重/改写”，先提示风险再执行
- 旧版 `.doc` 必须先转 `.docx` 再处理
- 参考文献缺项不编造，仅标“需补：年份/卷期/页码”
- 盲审脱敏前需用户确认，避免误删致谢中的必要信息
- SkillHub 审核关注“可视化对比 + 可交付”，提交时附 Demo 截图与一份示例报告

## 参考资源

- 可视化 Demo：`C:\Users\Administrator\.zcode\v2\visualizations\91760e993a2b331ba485e0097e7aeee34e32c91db7952dae2140eab62dad5876\thesis-formatter-demo.html`
- 国家标准 GB/T 7714-2015（信息与文献 参考文献著录规则）— 仅需期刊/学位论文/图书三类
