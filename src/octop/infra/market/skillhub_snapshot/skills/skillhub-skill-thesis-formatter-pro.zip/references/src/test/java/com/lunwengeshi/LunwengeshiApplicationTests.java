package com.lunwengeshi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LunwengeshiApplicationTests {

    @Test
    void contextLoads() {
    }

}
