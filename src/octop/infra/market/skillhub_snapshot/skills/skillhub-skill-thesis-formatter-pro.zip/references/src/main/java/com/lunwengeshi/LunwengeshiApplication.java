package com.lunwengeshi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LunwengeshiApplication {

    public static void main(String[] args) {
        SpringApplication.run(LunwengeshiApplication.class, args);
    }

}
