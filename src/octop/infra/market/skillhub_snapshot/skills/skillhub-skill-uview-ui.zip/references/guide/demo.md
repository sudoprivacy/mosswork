---
name: "demo"
description: "示例指南 -- uView UI uni-app Vue2 组件/工具。Invoke when user needs 示例指南 in uni-app Vue 2.x project."
url: "https://www.uviewui.com/guide/demo.html"
---

---

## [#](#演示) 演示

uView 会将各个版本的演示在此展示，目前演示的版本有 H5，安卓，微信小程序，其他版本的演示将会陆续添加。

### [#](#使用方法) 使用方法

-   H5 版本可以用微信或者手机浏览器扫描二维码即可
-   微信小程序只能通过微信扫码查看
-   安卓版本只能在安卓使用，可以用安卓浏览器或者 QQ 扫码进行安装(**微信中不能扫码安装**)，安装过程中您可能需要勾选相应的提示，允许安装来自非应用市场的 APP，或者您需要在`设置`中打开 [允许安装来自未知来源的应用 (opens new window)](https://www.pc841.com/shoujijiqiao/45848.html)

### [#](#说明) 说明

文档中也有相应的演示示例，但它是通过`iframe`嵌入到网页的，所以可能会造成某些 uni-appAPI 在网页上(浏览器 F12 手机调试模式无问题)无法使用，造成组件有 BUG 的错觉。

**注意：** 建议您只在浏览文档时使用文档右侧的演示功能，电脑示例由于分辨率和 uni-app 用`rpx`单位的问题，显示可能会不够细致，请通过微信扫码小程序体验最佳的效果。

### [#](#扫码) 扫码

![](https://www.uviewui.com/common/weixin_mini_qrcode.png)

微信小程序

只能微信扫码

![](https://uviewui.com/resources/1546181654815455.png)

H5

微信或浏览器扫码

![](https://uviewui.com/resources/168415644515.png)

安卓

浏览器扫码安装(微信扫码无效)

[HBuilder X 代码提示](https://www.uviewui.com/guide/codeHint.html) →


