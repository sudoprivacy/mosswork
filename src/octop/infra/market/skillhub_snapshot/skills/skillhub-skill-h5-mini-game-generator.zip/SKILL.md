---
name: skillhub-skill-h5-mini-game-generator
description: "H5包体标准小游戏生成器 - 根据H5小游戏包体规范生成符合标准的轻量级HTML5游戏代码。关键词：H5游戏、小游戏、贪吃蛇、俄罗斯方块、打砖块、2048、扫雷、井字棋、飞机大战、射击、塔防、跑酷、横版格斗、消消乐、Canvas游戏、对象池、粒子系统、游戏AI、行为树、波次生成、包体优化、4MB主包"
---

# H5 Mini Game Generator

> **Goal**: 根据用户需求生成符合 **H5 包体标准小游戏** 规范的完整 HTML5 游戏代码。核心约束：主包 ≤ 4MB、整包 ≤ 30MB、69 种文件白名单、FPS 50-60。

> `<skill-directory>` 指本 Skill 所在目录，不是用户项目目录。

---

## When to Use

当用户要求**创建/生成/开发一个 H5 小游戏**时触发，包括但不限于：

- 用户提到 **H5 游戏 / HTML5 游戏 / Canvas 游戏 / 网页游戏 / 小游戏**
- 用户提到具体游戏类型：**贪吃蛇 / 俄罗斯方块 / 打砖块 / 2048 / 扫雷 / 井字棋 / 飞机大战 / 射击 / 塔防 / 跑酷 / 横版格斗 / 消消乐** 等
- 用户提到复杂游戏机制：**对象池 / 粒子特效 / 敌人AI / 波次系统 / 状态机 / 寻路 / 连招 / Boss战** 等
- 用户提到 **包体标准 / 4MB 限制 / 包体优化 / 轻量游戏**
- 用户要求生成一个"简单的小游戏"或"休闲游戏"

## When NOT to Use

以下场景**不触发**此 Skill：

- 用户要开发 **React/Vue/Angular Web 应用**（非游戏）
- 用户要用 **Cocos Creator / Laya / Egret / Unity** 等大型引擎开发
- 用户要开发 **Node.js 后端服务 / API**
- 用户要求 **桌面端 / 移动端原生 App**
- 用户只是要一个**动画 / 交互演示页面**（非游戏玩法）

---

## Core Principles

1. **包体红线**：主包 ≤ 4MB（4,194,304 字节），整包 ≤ 30MB（31,457,280 字节）。生成后**必须**运行 `validate.sh` 验证
2. **纯 H5 技术栈**：HTML5 + Canvas/WebGL + 原生 JavaScript（ES6+），**不依赖大型引擎框架**（Cocos/Laya/Phaser 等）
3. **标准目录结构**：遵循下文的目录规范，文件各归其位
4. **性能达标**：FPS 稳定 50-60，Draw Call ≤ 100/帧，首屏渲染 ≤ 1.5s
5. **资源精简**：纹理用 PNG-8/WebP，音频用短 MP3/AAC，字体用子集化或系统字体
6. **文件白名单**：只用 69 种允许的文件类型（详见 `references/file-whitelist.md`）
7. **先读模板再生成**：生成前读取 `references/templates/<game-type>/README.md` 获取架构指导
8. **生成后必验证**：运行 `validate.sh` 检查合规性，有违规立即修复

---

## Generation Workflow

```
用户提出游戏需求
    │
    ▼
1. 识别游戏类型，匹配模板（见「Game Type Mapping」表）
    │  ── 有匹配模板 → 读取 references/templates/<type>/README.md
    │  ── 无匹配模板 → 读取最接近的原型模板 + references/coding-guidelines.md
    │
    ▼
2. 按需读取参考文档
    │  ── references/package-spec.md（包体规范）
    │  ── references/coding-guidelines.md（编码规范）
    │  ── references/modules/ai-behaviors.md（AI与敌人行为，复杂游戏需要时）
    │  ── references/modules/particles-and-pooling.md（粒子与对象池，射击/动作类需要时）
    │  ── references/modules/audio-and-haptics.md（音效与振动反馈，需要时）
    │
    ▼
3. 生成标准目录结构（见下文）
    │
    ▼
4. 生成配置文件
    │  ── game.json（游戏元数据）
    │  ── config.js（可调参数）
    │  ── index.html（入口页面）
    │
    ▼
5. 实现核心引擎 js/core/
    │  ── GameLoop（游戏循环 + requestAnimationFrame）
    │  ── InputHandler（触摸/键盘/鼠标输入抽象）
    │  ── Renderer（Canvas 渲染封装）
    │
    ▼
6. 实现场景 js/scenes/
    │  ── MenuScene（开始菜单）
    │  ── GameScene（主游戏逻辑）
    │  ── GameOverScene（结算页面）
    │
    ▼
7. 实现实体 js/entities/（游戏对象）
    │
    ▼
8. 运行验证脚本
    │  bash <skill-directory>/scripts/validate.sh <项目目录>
    │
    ├─ 全部 PASS → 向用户报告结果
    └─ 有 FAIL → 修复后重新验证，直到全部通过
```

---

## Standard Directory Structure

生成的游戏项目写入 `/workspace/<game-name>/`，结构如下：

```
<game-name>/
├── index.html              # H5 入口页面，加载 game.js
├── game.js                 # 程序入口，初始化游戏
├── game.json               # 游戏全局配置（元数据、屏幕方向、网络超时等）
├── config.js               # 游戏参数配置（难度、速度、颜色等可调项）
├── styles/
│   └── main.css            # 基础样式（全屏、禁止滚动、触屏优化）
├── js/
│   ├── core/
│   │   ├── GameLoop.js     # 游戏循环（requestAnimationFrame + delta time）
│   │   ├── InputHandler.js # 输入处理（touch/mouse/keyboard 统一抽象）
│   │   └── Renderer.js     # Canvas 渲染封装（绘制、状态批处理）
│   ├── scenes/
│   │   ├── Scene.js        # 场景基类
│   │   ├── MenuScene.js    # 开始菜单场景
│   │   ├── GameScene.js    # 主游戏场景
│   │   └── GameOverScene.js# 结算场景
│   ├── entities/
│   │   └── ...             # 游戏实体（根据游戏类型而定）
│   └── utils/
│       ├── EventEmitter.js # 事件系统
│       └── AssetLoader.js  # 资源加载器
├── assets/
│   ├── images/             # 图片资源（PNG-8/WebP）
│   └── audio/              # 音频资源（短 MP3/AAC）
└── subpackages/            # 分包目录（超过 4MB 时使用）
    └── ...
```

**目录说明**：

| 路径 | 必须 | 说明 |
|------|------|------|
| `index.html` | ✅ | H5 入口，包含 `<canvas>` 元素并加载 `game.js` |
| `game.js` | ✅ | 程序入口，创建 Canvas、初始化游戏循环和场景管理器 |
| `game.json` | ✅ | 全局配置 |
| `config.js` | ✅ | 可调参数集中管理 |
| `js/core/` | ✅ | 核心引擎，游戏循环和输入渲染 |
| `js/scenes/` | ✅ | 场景管理 |
| `js/entities/` | ✅ | 游戏实体 |
| `js/utils/` | 推荐 | 工具函数 |
| `assets/` | 可选 | 静态资源（无资源时可不创建） |
| `styles/` | 推荐 | 样式文件 |
| `subpackages/` | 可选 | 超过 4MB 时拆分分包 |

---

## Game Type Mapping

根据用户关键词匹配模板：

| 用户关键词 | 模板路径 | 原型分类 |
|-----------|---------|---------|
| 贪吃蛇 / snake | `templates/snake/` | 街机 |
| 俄罗斯方块 / tetris / 方块 | `templates/tetris/` | 街机 |
| 打砖块 / breakout / 弹球 | `templates/breakout/` | 街机 |
| 2048 / 数字滑块 | `templates/2048/` | 益智 |
| 扫雷 / minesweeper | `templates/minesweeper/` | 益智 |
| 井字棋 / tic-tac-toe / 三连棋 | `templates/tictactoe/` | 棋盘 |
| 飞机大战 / 射击 / shooter / 弹幕 | `templates/shooter/` | 射击 |
| 塔防 / tower-defense / td | `templates/tower-defense/` | 策略 |
| 跑酷 / parkour / runner / 横版跑 | `templates/runner/` | 动作 |
| 横版格斗 / fighting / 格斗对战 | `templates/fighting/` | 格斗 |
| 消消乐 / 三消 / match-3 | 无专属模板，参考 `2048` | 益智 |
| 其他类型 | 读取 `coding-guidelines.md` 按通用规范生成 | — |

> **复杂游戏模板**：shooter / tower-defense / runner / fighting 四种模板包含更深层次的架构设计（对象池、状态机、寻路、连招等），生成前还应按需加载 `references/modules/` 下的通用能力模块文档。

---

## game.json Schema

```json
{
  "name": "游戏名称",
  "version": "1.0.0",
  "description": "游戏描述",
  "deviceOrientation": "portrait",
  "showStatusBar": false,
  "networkTimeout": {
    "request": 60000,
    "connectSocket": 60000
  },
  "subpackages": []
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `name` | String | ✅ | 游戏名称 |
| `version` | String | ✅ | 版本号（语义化） |
| `deviceOrientation` | String | ✅ | `portrait` / `landscape` |
| `showStatusBar` | Boolean | — | 是否显示状态栏，默认 false |
| `networkTimeout` | Object | — | 网络超时配置（ms） |
| `subpackages` | Array | — | 分包配置 |

---

## config.js Pattern

所有可调参数集中在 `config.js`，使用全局对象模式：

```javascript
// config.js
const CONFIG = {
  // 游戏基础
  gameName: 'Snake',
  version: '1.0.0',

  // 画面
  canvas: {
    width: 750,
    height: 1334,
    designRatio: 750 / 1334,
  },

  // 游戏逻辑参数
  gameplay: {
    gridSize: 25,        // 网格大小
    initialSpeed: 150,   // 初始速度(ms/步)
    speedIncrement: 5,   // 加速幅度
    maxSpeed: 60,        // 最快速度
  },

  // 颜色
  colors: {
    background: '#1a1a2e',
    snake: '#0f0',
    food: '#f00',
    grid: '#16213e',
  },

  // 音效
  audio: {
    eat: 'assets/audio/eat.mp3',
    gameOver: 'assets/audio/gameover.mp3',
  },
};

// 导出（兼容浏览器环境）
if (typeof module !== 'undefined') module.exports = CONFIG;
```

---

## Performance Guidelines

> 完整规范见 `references/coding-guidelines.md`，以下为关键要点：

| 维度 | 要求 | 实现要点 |
|------|------|---------|
| **游戏循环** | 60 FPS | `requestAnimationFrame` + delta time capping（≤33ms） |
| **渲染** | Draw Call ≤100 | 批量绘制、减少 `save()/restore()`、离屏 Canvas |
| **内存** | 无 GC 抖动 | 对象池复用、数组复用、避免循环内创建对象 |
| **资源加载** | 首屏 ≤1.5s | 预加载关键资源、延迟加载非首屏资源 |
| **输入** | 响应 ≤16ms | 事件委托、统一 touch/mouse/keyboard |

---

## Package Optimization Strategies

当包体接近或超过 4MB 时的优化优先级：

```
1. 资源压缩（最高优先）
   ├── 图片：PNG → WebP / PNG-8，使用 TinyPNG / pngquant
   ├── 音频：长 BGM → 低码率 AAC，短音效 → 压缩 MP3
   └── 字体：子集化（fontmin）或用位图字体/系统字体

2. 代码精简
   ├── 移除未使用代码（tree shaking）
   ├── 压缩混淆（ terser / uglify）
   └── 避免引入大型库（lodash 完整版 → 按需引入）

3. 分包加载
   ├── 首屏不需要的内容拆入 subpackages/
   ├── 按关卡/功能模块拆分
   └── 使用分包加载 API

4. 远程 CDN（超过 30MB 时）
   ├── 大图/动画/音效放 CDN
   ├── 按需下载 + 本地缓存
   └── 使用 ZIP 打包减少传输体积
```

---

## Validation

**生成代码后必须运行验证脚本**：

```bash
bash <skill-directory>/scripts/validate.sh <项目目录>
```

脚本会检查：

| 检查项 | 判定标准 |
|--------|---------|
| 目录结构 | `index.html`、`game.js`、`game.json`、`config.js` 必须存在 |
| 主包大小 | ≤ 4,194,304 字节（4MB） |
| 整包大小 | ≤ 31,457,280 字节（30MB） |
| 文件类型 | 所有文件扩展名在 69 种白名单内 |
| game.json | 文件存在且为有效 JSON |

**输出格式**：彩色 PASS/WARN/FAIL 报告 + 体积明细 + 违规列表

**退出码**：0 = 全部通过，1 = 存在违规

> 如果验证失败，**必须修复后重新验证**，直到全部通过才能交付给用户。

---

## Important Rules

1. **生成后必须运行 `validate.sh`** — 不可跳过，不可凭感觉判断包体大小
2. **主包不超过 4MB** — 超限时必须拆分包或压缩资源
3. **只用白名单文件类型** — 不允许 `.scss`、`.ts`（需编译为 `.js`）、`.md` 等非白名单文件出现在最终包中
4. **遵循标准目录结构** — 不要随意变更文件位置
5. **生成前必须读模板** — 即使是熟悉的游戏类型也要读取对应模板参考
6. **纯原生实现** — 不引入 Cocos/Laya/Phaser/PixiJS 等引擎，用原生 Canvas API
7. **代码可运行** — 生成的代码必须能在浏览器中直接打开 `index.html` 运行
8. **移动端适配** — 支持 touch 事件，适配竖屏/横屏，禁止页面滚动

---

## Knowledge Map

按需加载以下文档：

| 文档 | 内容 | 何时加载 |
|------|------|---------|
| `references/package-spec.md` | 完整包体规范（限制、白名单、结构） | 需要了解详细规范时 |
| `references/coding-guidelines.md` | 编码规范（游戏循环、渲染、内存等） | 实现核心引擎前 |
| `references/file-whitelist.md` | 69 种允许文件类型完整列表 | 确认文件类型是否合规时 |
| `references/templates/<type>/README.md` | 游戏模板参考 | 生成对应类型游戏前 |
| `references/modules/ai-behaviors.md` | 游戏AI与敌人行为（FSM、行为树、追踪、波次） | 生成需要敌人AI的游戏时 |
| `references/modules/particles-and-pooling.md` | 粒子/特效与对象池（通用池、粒子系统、空间分区） | 生成射击/动作类游戏时 |
| `references/modules/audio-and-haptics.md` | 音效与振动反馈（Web Audio、混播、振动API） | 需要音效和触觉反馈时 |
