#!/usr/bin/env bash
# =============================================================================
# H5 Mini Game - Package Validator
# 验证生成的 H5 小游戏项目是否符合包体标准
#
# Usage: bash validate.sh <project-dir>
# Exit:  0 = 全部通过, 1 = 存在违规
# =============================================================================

set -euo pipefail

# ---- 颜色定义 ----
if [[ -t 1 ]]; then
  RED='\033[0;31m'
  GREEN='\033[0;32m'
  YELLOW='\033[0;33m'
  BLUE='\033[0;34m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  NC='\033[0m'
else
  RED='' GREEN='' YELLOW='' BLUE='' CYAN='' BOLD='' NC=''
fi

# ---- 常量 ----
MAIN_PKG_LIMIT=4194304        # 4MB
TOTAL_PKG_LIMIT=31457280      # 30MB
MB=1048576

# ---- 文件类型白名单 ----
# 基于微信小游戏 69 种 + H5 必需类型（html, css, webp）
WHITELIST=(
  png jpg jpeg gif svg webp js json cer obj dae fbx mtl stl 3ds mp3 pvr wav
  plist ttf fnt gz ccz m4a mp4 bmp atlas swf ani part proto bin sk
  mipmaps txt zip tt map ogg silk dbbin dbmv etc lmat lm ls lh lani
  lav lsani ltc aac astc br csv cur dat dds glb gltf ico ktx lmani
  lml pkm prefab scene skel wasm xml html css
)

# 构建快速查找的关联数组
declare -A WHITELIST_MAP
for ext in "${WHITELIST[@]}"; do
  WHITELIST_MAP["$ext"]=1
done

# ---- 参数检查 ----
if [[ $# -lt 1 ]]; then
  echo -e "${RED}错误: 缺少项目目录参数${NC}"
  echo -e "用法: bash validate.sh <project-dir>"
  exit 1
fi

PROJECT_DIR="$1"

if [[ ! -d "$PROJECT_DIR" ]]; then
  echo -e "${RED}错误: 项目目录不存在: $PROJECT_DIR${NC}"
  exit 1
fi

# 转为绝对路径
PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd)"

# ---- 结果统计 ----
PASS_COUNT=0
WARN_COUNT=0
FAIL_COUNT=0
VIOLATIONS=()

print_pass() {
  echo -e "  ${GREEN}✓ PASS${NC}  $1"
  PASS_COUNT=$((PASS_COUNT + 1))
}

print_warn() {
  echo -e "  ${YELLOW}⚠ WARN${NC}  $1"
  WARN_COUNT=$((WARN_COUNT + 1))
}

print_fail() {
  echo -e "  ${RED}✗ FAIL${NC}  $1"
  FAIL_COUNT=$((FAIL_COUNT + 1))
  VIOLATIONS+=("$1")
}

# ---- 检测 stat 参数格式（Linux vs macOS）----
get_file_size() {
  local file="$1"
  if stat --version &>/dev/null; then
    # GNU stat (Linux)
    stat -c%s "$file" 2>/dev/null || echo 0
  else
    # BSD stat (macOS)
    stat -f%z "$file" 2>/dev/null || echo 0
  fi
}

# =============================================================================
# 开始验证
# =============================================================================

echo ""
echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${CYAN}  H5 小游戏包体标准验证${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "  项目路径: ${BLUE}$PROJECT_DIR${NC}"
echo ""

# ---- 检查 1: 目录结构 ----
echo -e "${BOLD}[1/5] 目录结构检查${NC}"

REQUIRED_FILES=("index.html" "game.js" "game.json" "config.js")
for f in "${REQUIRED_FILES[@]}"; do
  if [[ -f "$PROJECT_DIR/$f" ]]; then
    print_pass "存在 $f"
  else
    print_fail "缺少必需文件: $f"
  fi
done

echo ""

# ---- 检查 2: 主包大小 ----
echo -e "${BOLD}[2/5] 主包大小检查 (≤ 4MB)${NC}"

MAIN_SIZE=0
TOTAL_SIZE=0

# 遍历所有文件，区分主包和分包
while IFS= read -r -d '' file; do
  size=$(get_file_size "$file")
  TOTAL_SIZE=$((TOTAL_SIZE + size))

  # 判断是否在 subpackages/ 目录下
  rel_path="${file#$PROJECT_DIR/}"
  if [[ "$rel_path" == subpackages/* ]]; then
    # 分包文件，不计入主包
    :
  else
    MAIN_SIZE=$((MAIN_SIZE + size))
  fi
done < <(find "$PROJECT_DIR" -type f -not -path '*/.*' -print0)

MAIN_SIZE_MB=$(awk "BEGIN {printf \"%.2f\", $MAIN_SIZE / $MB}")
if [[ $MAIN_SIZE -le $MAIN_PKG_LIMIT ]]; then
  print_pass "主包大小: ${MAIN_SIZE_MB}MB (≤ 4.00MB)"
else
  print_fail "主包大小: ${MAIN_SIZE_MB}MB (超过 4.00MB 限制)"
fi

echo ""

# ---- 检查 3: 整包大小 ----
echo -e "${BOLD}[3/5] 整包大小检查 (≤ 30MB)${NC}"

TOTAL_SIZE_MB=$(awk "BEGIN {printf \"%.2f\", $TOTAL_SIZE / $MB}")
if [[ $TOTAL_SIZE -le $TOTAL_PKG_LIMIT ]]; then
  print_pass "整包大小: ${TOTAL_SIZE_MB}MB (≤ 30.00MB)"
else
  print_fail "整包大小: ${TOTAL_SIZE_MB}MB (超过 30.00MB 限制)"
fi

echo ""

# ---- 检查 4: 文件类型白名单 ----
echo -e "${BOLD}[4/5] 文件类型白名单检查${NC}"

declare -A FOUND_TYPES
NON_WHITELISTED=()

while IFS= read -r -d '' file; do
  # 提取扩展名（转小写）
  filename="$(basename "$file")"
  ext="${filename##*.}"

  # 无扩展名的文件跳过
  if [[ "$filename" == "$ext" ]]; then
    continue
  fi

  ext_lower=$(echo "$ext" | tr '[:upper:]' '[:lower:]')
  FOUND_TYPES["$ext_lower"]=1

  # 检查是否在白名单
  if [[ -z "${WHITELIST_MAP[$ext_lower]:-}" ]]; then
    NON_WHITELISTED+=("$ext_lower")
  fi
done < <(find "$PROJECT_DIR" -type f -not -path '*/.*' -print0)

if [[ ${#NON_WHITELISTED[@]} -eq 0 ]]; then
  print_pass "所有文件类型均在白名单内"
else
  # 去重
  unique_non_whitelisted=($(printf '%s\n' "${NON_WHITELISTED[@]}" | sort -u))
  print_fail "发现非白名单文件类型: ${unique_non_whitelisted[*]}"
fi

echo ""

# ---- 检查 5: game.json 有效性 ----
echo -e "${BOLD}[5/5] game.json 配置检查${NC}"

GAME_JSON="$PROJECT_DIR/game.json"
if [[ ! -f "$GAME_JSON" ]]; then
  print_fail "game.json 不存在"
else
  # 检查是否为有效 JSON
  if command -v jq &>/dev/null; then
    # 使用 jq 验证 JSON
    if jq empty "$GAME_JSON" 2>/dev/null; then
      print_pass "game.json 是有效 JSON"

      # 检查必需字段
      name=$(jq -r '.name // empty' "$GAME_JSON" 2>/dev/null)
      version=$(jq -r '.version // empty' "$GAME_JSON" 2>/dev/null)
      orientation=$(jq -r '.deviceOrientation // empty' "$GAME_JSON" 2>/dev/null)

      if [[ -n "$name" ]]; then
        print_pass "game.json 包含 name: $name"
      else
        print_warn "game.json 缺少 name 字段"
      fi

      if [[ -n "$version" ]]; then
        print_pass "game.json 包含 version: $version"
      else
        print_warn "game.json 缺少 version 字段"
      fi

      if [[ -n "$orientation" ]]; then
        print_pass "game.json 包含 deviceOrientation: $orientation"
      else
        print_warn "game.json 缺少 deviceOrientation 字段"
      fi
    else
      print_fail "game.json JSON 格式错误"
    fi
  else
    # 无 jq 时使用 python3 验证
    if python3 -c "import json,sys; json.load(open('$GAME_JSON'))" 2>/dev/null; then
      print_pass "game.json 是有效 JSON"
    else
      print_fail "game.json JSON 格式错误"
    fi
  fi
fi

echo ""

# =============================================================================
# 汇总报告
# =============================================================================

echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}  验证汇总${NC}"
echo -e "${BOLD}${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""

echo -e "  ${GREEN}通过: $PASS_COUNT${NC}  ${YELLOW}警告: $WARN_COUNT${NC}  ${RED}失败: $FAIL_COUNT${NC}"
echo ""
echo -e "  ${BOLD}体积明细:${NC}"
echo -e "    主包: ${BLUE}${MAIN_SIZE_MB}MB${NC} / 4.00MB $(awk "BEGIN{print ($MAIN_SIZE <= $MAIN_PKG_LIMIT) ? \"✓\" : \"✗\"}")"
echo -e "    整包: ${BLUE}${TOTAL_SIZE_MB}MB${NC} / 30.00MB $(awk "BEGIN{print ($TOTAL_SIZE <= $TOTAL_PKG_LIMIT) ? \"✓\" : \"✗\"}")"
echo ""

if [[ ${#FOUND_TYPES[@]} -gt 0 ]]; then
  echo -e "  ${BOLD}检测到的文件类型 (${#FOUND_TYPES[@]} 种):${NC}"
  sorted_types=($(printf '%s\n' "${!FOUND_TYPES[@]}" | sort))
  echo -e "    ${sorted_types[*]}"
  echo ""
fi

if [[ $FAIL_COUNT -gt 0 ]]; then
  echo -e "  ${BOLD}${RED}违规项:${NC}"
  for v in "${VIOLATIONS[@]}"; do
    echo -e "    ${RED}• $v${NC}"
  done
  echo ""
  echo -e "  ${RED}${BOLD}验证未通过，请修复上述问题后重新验证。${NC}"
  exit 1
else
  if [[ $WARN_COUNT -gt 0 ]]; then
    echo -e "  ${YELLOW}${BOLD}验证通过（有警告项，建议优化）。${NC}"
  else
    echo -e "  ${GREEN}${BOLD}验证全部通过，项目符合 H5 包体标准。${NC}"
  fi
  exit 0
fi
