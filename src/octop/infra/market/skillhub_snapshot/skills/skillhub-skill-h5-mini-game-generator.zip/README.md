# h5-mini-game-generator

> H5 包体标准小游戏代码生成器 — 根据腾讯 H5 小游戏包体规范，自动生成符合标准的轻量级 HTML5 游戏代码。

## 简介

这是一个 CodeBuddy Skill，帮助 AI 自动生成符合 **H5 包体标准小游戏** 规范的完整 HTML5 游戏代码。核心约束：主包 ≤ 4MB、整包 ≤ 30MB、72 种文件白名单、FPS 50-60。

支持从简单到复杂的 10 种游戏类型，包括贪吃蛇、俄罗斯方块、打砖块、2048、扫雷、井字棋、飞机大战、塔防、跑酷、横版格斗。

## 支持的游戏类型

| 类型 | 复杂度 | 特色算法 |
|------|--------|---------|
| 🐍 贪吃蛇 | ★☆☆☆☆ | 网格移动、食物生成 |
| 🧱 俄罗斯方块 | ★★☆☆☆ | SRS旋转、消行检测 |
| 🏓 打砖块 | ★★☆☆☆ | 球物理、AABB碰撞 |
| 🔢 2048 | ★★☆☆☆ | 滑动合并算法 |
| 💣 扫雷 | ★★☆☆☆ | 洪泛填充 |
| ⭕ 井字棋 | ★☆☆☆☆ | Minimax AI |
| ✈️ 飞机大战 | ★★★★☆ | 对象池、波次生成、弹幕模式 |
| 🏰 塔防 | ★★★★☆ | 路径插值、塔升级、经济系统 |
| 🏃 跑酷 | ★★★☆☆ | 可变高度跳跃、无限滚动 |
| 🥊 横版格斗 | ★★★★★ | FSM状态机、帧数据招式、连招系统 |

## 特色功能

- **自动包体验证**：内置 `validate.sh` 脚本，5 大检查项确保合规
- **3 个通用模块**：AI行为、粒子/对象池、音效/振动反馈，可跨游戏复用
- **纯原生技术栈**：HTML5 + Canvas + 原生 JS，零引擎依赖
- **移动端适配**：触屏操作、自适应屏幕、禁止滚动

## 安装

```bash
# 下载并解压到 CodeBuddy skills 目录
# macOS/Linux: ~/.codebuddy/skills/h5-mini-game-generator/
# Windows: %USERPROFILE%\.codebuddy\skills\h5-mini-game-generator\

# 解压后重启 CodeBuddy，Skill 自动加载
```

## 使用

在 CodeBuddy 对话中输入：

> "帮我生成一个飞机大战 H5 小游戏"

Skill 会自动触发，生成完整项目代码并运行包体验证。

## 目录结构

```
h5-mini-game-generator/
├── SKILL.md                      # 核心定义
├── scripts/validate.sh           # 包体验证脚本
├── references/
│   ├── package-spec.md           # 包体标准规范
│   ├── coding-guidelines.md      # 编码规范
│   ├── file-whitelist.md         # 文件类型白名单
│   ├── modules/                  # 通用能力模块
│   │   ├── ai-behaviors.md
│   │   ├── particles-and-pooling.md
│   │   └── audio-and-haptics.md
│   └── templates/                # 10 种游戏模板
│       ├── snake/README.md
│       ├── tetris/README.md
│       ├── breakout/README.md
│       ├── 2048/README.md
│       ├── minesweeper/README.md
│       ├── tictactoe/README.md
│       ├── shooter/README.md
│       ├── tower-defense/README.md
│       ├── runner/README.md
│       └── fighting/README.md
```

## 版本

v2.0.0 — 新增 4 种复杂游戏（飞机大战/塔防/跑酷/横版格斗）+ 3 个通用能力模块

## 许可

MIT
