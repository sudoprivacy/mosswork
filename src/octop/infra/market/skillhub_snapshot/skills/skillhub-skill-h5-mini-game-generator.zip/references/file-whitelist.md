# H5 小游戏文件类型白名单

共 **72 种**允许的文件类型（微信小游戏 69 种 + H5 必需的 html/css/webp）。

## 图片

| 扩展名 | 说明 |
|--------|------|
| `png` | PNG 图片（无损，推荐） |
| `jpg` | JPEG 图片 |
| `jpeg` | JPEG 图片 |
| `gif` | GIF 动图 |
| `svg` | SVG 矢量图 |
| `bmp` | 位图 |
| `ico` | 图标文件 |
| `pvr` | PVR 纹理（移动端压缩纹理） |
| `astc` | ASTC 纹理（自适应可伸缩纹理压缩） |
| `ktx` | KTX 纹理（Khronos 纹理容器） |
| `pkm` | PKM 纹理（ETC 压缩纹理） |
| `dds` | DDS 纹理（DirectDraw Surface） |
| `webp` | WebP 图片（高压缩比，推荐） |

## 音频

| 扩展名 | 说明 |
|--------|------|
| `mp3` | MP3 音频（推荐，兼容性好） |
| `wav` | WAV 音频（无损，短音效推荐） |
| `ogg` | OGG 音频 |
| `aac` | AAC 音频（高压缩比，BGM 推荐） |
| `m4a` | M4A 音频 |
| `silk` | Silk 音频 |

## 视频

| 扩展名 | 说明 |
|--------|------|
| `mp4` | MP4 视频 |

## 代码与配置

| 扩展名 | 说明 |
|--------|------|
| `js` | JavaScript 代码 |
| `json` | JSON 配置 |
| `html` | HTML 页面（H5 入口） |
| `css` | CSS 样式表 |
| `wasm` | WebAssembly 二进制 |
| `xml` | XML 配置 |
| `csv` | CSV 数据 |
| `txt` | 纯文本 |
| `proto` | Protocol Buffers 定义 |
| `plist` | plist 配置 |

## 字体

| 扩展名 | 说明 |
|--------|------|
| `ttf` | TrueType 字体 |
| `fnt` | 位图字体 |
| `tt` | — |

## 3D / 模型

| 扩展名 | 说明 |
|--------|------|
| `obj` | Wavefront OBJ 模型 |
| `dae` | COLLADA 模型 |
| `fbx` | FBX 模型 |
| `mtl` | 材质文件 |
| `stl` | STL 模型 |
| `3ds` | 3ds Max 模型 |
| `glb` | glTF 二进制模型 |
| `gltf` | glTF 模型 |

## 引擎专用资源

| 扩展名 | 说明 |
|--------|------|
| `atlas` | 精灵图集 |
| `prefab` | 预制体 |
| `scene` | 场景文件 |
| `skel` | 骨骼数据 |
| `sk` | 骨骼 |
| `mipmaps` | Mipmap 数据 |
| `bin` | 二进制数据 |
| `dat` | 数据文件 |
| `dbbin` | DragonBones 二进制 |
| `dbmv` | DragonBones 动画 |
| `etc` | — |
| `lmat` | LayaAir 材质 |
| `lm` | LayaAir 模型 |
| `ls` | LayaAir 场景 |
| `lh` | LayaAir 预制体 |
| `lani` | LayaAir 动画 |
| `lav` | LayaAir 动画 |
| `lsani` | LayaAir 场景动画 |
| `ltc` | LayaAir 纹理压缩 |
| `lmani` | LayaAir 动画 |
| `lml` | LayaAir 材质库 |
| `ani` | 动画文件 |
| `part` | 粒子文件 |
| `swf` | SWF 动画 |

## 压缩包

| 扩展名 | 说明 |
|--------|------|
| `zip` | ZIP 压缩包 |
| `gz` | Gzip 压缩 |
| `ccz` | Cocos 压缩 |
| `br` | Brotli 压缩 |

## 其他

| 扩展名 | 说明 |
|--------|------|
| `cer` | 证书文件 |
| `cur` | 光标文件 |
| `map` | 地图数据 |
| `atlas` | 图集 |
| `mipmaps` | Mipmap |

---

## 注意事项

1. **`.js` 和 `game.json`** 会被编译，上传后无法直接通过路径访问
2. **不在白名单的文件**在开发阶段可访问，但上传时会报错
3. **需编译的类型**（`.ts`、`.scss`、`.less`、`.coffee` 等）必须先编译为白名单类型
4. **开发阶段文件**（`.md`、`.DS_Store`、`.gitignore` 等）不应出现在最终包中

## 快速校验

```bash
# 使用 validate.sh 自动校验
bash <skill-directory>/scripts/validate.sh <project-dir>
```
