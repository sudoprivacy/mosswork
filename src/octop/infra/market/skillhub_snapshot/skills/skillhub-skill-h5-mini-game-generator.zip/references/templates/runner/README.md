# 跑酷/横版动作类 (Runner) — 模板参考

## 游戏概述

角色自动向前跑，玩家控制跳跃和滑铲躲避障碍物。地图无限滚动，速度逐渐加快，有金币收集和距离计分。核心挑战是可变高度跳跃物理和障碍物生成的可过性保证。

> **复杂度**：★★★☆☆ — 需要可变高度跳跃、无限滚动、障碍物生成器、加速度系统。
>
> **相关模块**：生成前应读取 `references/modules/particles-and-pooling.md`（障碍物池+尘土粒子）、`references/modules/ai-behaviors.md`（障碍物生成决策）、`references/modules/audio-and-haptics.md`（跳跃/碰撞音效+振动）。

---

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Runner` | `js/entities/Runner.js` | 角色状态机（running/jumping/sliding/hurt）、物理参数 |
| `Obstacle` | `js/entities/Obstacle.js` | 障碍物类型（低/高/宽）、位置、碰撞箱 |
| `Coin` | `js/entities/Coin.js` | 金币位置、收集检测、旋转动画 |
| `Ground` | `js/entities/Ground.js` | 地面滚动 |
| `ObstacleSpawner` | `js/utils/ObstacleSpawner.js` | 障碍物生成（间距+可过性保证） |
| `Camera` | `js/core/Camera.js` | 横向滚动 + 屏幕震动 |

### Runner 实体骨架

```javascript
class Runner {
  constructor(config) {
    this.x = 150;
    this.y = 0;            // y=0 为地面
    this.vy = 0;
    this.gravity = config.gravity || 2000;
    this.jumpForce = config.jumpForce || -700;
    this.jumpHoldForce = config.jumpHoldForce || -200;
    this.maxJumpTime = config.maxJumpTime || 300;
    this.state = 'running';  // running | jumping | sliding | hurt
    this.stateTimer = 0;
    this.jumpTime = 0;
    this.jumpHeld = false;
    this.slideDuration = config.slideDuration || 500;
    this.slideTimer = 0;
    this.hurtTimer = 0;
    this.invincibleTimer = 0;
    this.width = 40;
    this.height = 50;
    this.animFrame = 0;
  }

  jump() {
    if (this.state === 'running') {
      this.vy = this.jumpForce;
      this.state = 'jumping';
      this.jumpTime = 0;
      return true;
    }
    return false;
  }

  // 按住跳跃键时给予额外上升力（可变高度跳跃）
  holdJump(dt) {
    if (this.state === 'jumping' && this.vy < 0 && this.jumpTime < this.maxJumpTime) {
      this.vy += this.jumpHoldForce * dt / 1000;
      this.jumpTime += dt;
    }
  }

  slide() {
    if (this.state === 'running') {
      this.state = 'sliding';
      this.slideTimer = this.slideDuration;
      return true;
    }
    // 空中滑铲 = 快速下落
    if (this.state === 'jumping' && this.vy < 0) {
      this.vy = Math.abs(this.jumpForce); // 向下弹
    }
    return false;
  }

  update(dt) {
    this.stateTimer += dt;
    this.animFrame += dt;

    switch (this.state) {
      case 'jumping':
        if (this.jumpHeld) this.holdJump(dt);
        this.vy += this.gravity * dt / 1000;
        this.y += this.vy * dt / 1000;
        if (this.y >= 0) {
          this.y = 0; this.vy = 0;
          this.state = 'running';
        }
        break;
      case 'sliding':
        this.slideTimer -= dt;
        if (this.slideTimer <= 0) this.state = 'running';
        break;
      case 'hurt':
        this.hurtTimer -= dt;
        if (this.hurtTimer <= 0) this.state = 'running';
        break;
    }

    if (this.invincibleTimer > 0) this.invincibleTimer -= dt;
  }

  takeDamage() {
    if (this.invincibleTimer > 0) return false;
    this.state = 'hurt';
    this.hurtTimer = 500;
    this.invincibleTimer = 1000;
    return true;
  }

  // 碰撞箱随状态变化
  getHitbox() {
    if (this.state === 'sliding') {
      return { x: this.x - 20, y: this.y - 10, w: 50, h: 20 }; // 矮（可穿过高障碍）
    }
    return { x: this.x - 15, y: this.y - this.height, w: 30, h: this.height };
  }

  isInvincible() { return this.invincibleTimer > 0; }
}
```

### Obstacle 实体骨架

```javascript
class Obstacle {
  constructor(type, x) {
    const cfg = OBSTACLE_TYPES[type];
    this.type = type;
    this.x = x;
    this.y = cfg.y;          // 相对于地面的 y 偏移
    this.width = cfg.width;
    this.height = cfg.height;
    this.color = cfg.color;
    this.requiredAction = cfg.requiredAction;  // 'jump' | 'slide' | 'jump_slide'
    this.active = true;
    this.passed = false;
  }

  scroll(dx) { this.x -= dx; }
  getHitbox() {
    return { x: this.x, y: this.y, w: this.width, h: this.height };
  }
}

// 障碍物类型设计
const OBSTACLE_TYPES = {
  // 低障碍：需要跳跃
  rock:    { y: -30, width: 30, height: 30, color: '#888', requiredAction: 'jump' },
  crate:   { y: -40, width: 40, height: 40, color: '#a52', requiredAction: 'jump' },
  // 高障碍：需要滑铲
  barrier: { y: -80, width: 40, height: 30, color: '#f44', requiredAction: 'slide' },
  banner:  { y: -90, width: 60, height: 25, color: '#a0f', requiredAction: 'slide' },
  // 宽障碍：可跳可滑
  wall:    { y: -60, width: 80, height: 60, color: '#444', requiredAction: 'jump_slide' },
};
```

### ObstacleSpawner 实体骨架

```javascript
class ObstacleSpawner {
  constructor() {
    this.nextSpawnX = 800;
    this.minGap = 250;
    this.maxGap = 500;
    this.lastObstacleType = null;
  }

  update(world, obstacles, dt, canvasW) {
    // 当世界滚动距离+屏幕宽度达到 nextSpawnX 时生成
    if (world.scrollDistance + canvasW >= this.nextSpawnX) {
      const type = this._pickObstacle(world);
      const x = this.nextSpawnX + canvasW - world.scrollDistance;
      obstacles.push(new Obstacle(type, x));

      // 间距随速度缩短（但保证可通过）
      const speedFactor = 1 - Math.min(world.speed / 800, 0.3);
      this.nextSpawnX += (this.minGap + Math.random() * (this.maxGap - this.minGap)) * speedFactor;
    }
  }

  _pickObstacle(world) {
    const types = Object.keys(OBSTACLE_TYPES);
    let type;
    do {
      type = types[Math.floor(Math.random() * types.length)];
    } while (this._isInvalidSequence(type));
    this.lastObstacleType = type;
    return type;
  }

  // 保证障碍物组合可通过：不连续生成两个紧挨的高障碍
  _isInvalidSequence(type) {
    if (!this.lastObstacleType) return false;
    // 两个需要滑铲的障碍连续生成且间距太短时不可通过
    const lastAction = OBSTACLE_TYPES[this.lastObstacleType].requiredAction;
    const currAction = OBSTACLE_TYPES[type].requiredAction;
    return lastAction === 'slide' && currAction === 'slide' &&
           (this.nextSpawnX - this.lastSpawnX) < 350;
  }
}
```

### Coin 实体骨架

```javascript
class Coin {
  constructor(x, y) {
    this.x = x; this.y = y;
    this.radius = 12;
    this.active = true;
    this.rotation = 0;
  }
  scroll(dx) { this.x -= dx; }
  update(dt) { this.rotation += dt * 0.005; }
  getHitbox() {
    return { x: this.x - this.radius, y: this.y - this.radius, w: this.radius*2, h: this.radius*2 };
  }
}
```

### 滚动世界

```javascript
class ScrollingWorld {
  constructor(baseSpeed) {
    this.baseSpeed = baseSpeed;
    this.speed = baseSpeed;
    this.maxSpeed = baseSpeed * 2.5;
    this.acceleration = 20;  // px/s^2
    this.scrollDistance = 0;
    this.elapsed = 0;
  }

  update(dt) {
    this.elapsed += dt;
    // 速度随时间递增（带上限）
    this.speed = Math.min(this.maxSpeed, this.baseSpeed + this.elapsed * this.acceleration / 1000);
    const scroll = this.speed * dt / 1000;
    this.scrollDistance += scroll;
    return scroll;  // 返回本帧滚动距离
  }
}
```

---

## 核心算法

### 1. 可变高度跳跃

短按 = 低跳，长按 = 高跳。实现见 `Runner.holdJump(dt)`。

```
跳跃曲线：
  短按(100ms)：低跳，越过低障碍
  长按(300ms)：高跳，越过宽障碍
  松开后不可再续跳
```

### 2. 无限滚动

所有障碍物和金币的 `x` 每帧减去滚动距离。超出屏幕左侧的对象回收。

```javascript
// GameScene.update
const scroll = world.update(dt);
for (const ob of obstacles) ob.scroll(scroll);
for (const coin of coins) coin.scroll(scroll);

// 回收超出屏幕的对象
for (let i = obstacles.length - 1; i >= 0; i--) {
  if (obstacles[i].x < -100) obstacles.splice(i, 1);
}
for (let i = coins.length - 1; i >= 0; i--) {
  if (coins[i].x < -50) coins.splice(i, 1);
}
```

### 3. 碰撞检测（状态感知）

```javascript
function checkCollisions(runner, obstacles, coins) {
  const runnerHB = runner.getHitbox();

  // 障碍物碰撞
  if (!runner.isInvincible()) {
    for (const ob of obstacles) {
      if (!ob.active || ob.passed) continue;
      if (rectIntersect(runnerHB, ob.getHitbox())) {
        if (runner.takeDamage()) {
          // 受伤处理：扣血/结束游戏
          onHit();
        }
      }
      // 标记已通过（用于计分）
      if (!ob.passed && ob.x + ob.width < runner.x) {
        ob.passed = true;
        score += 10;
      }
    }
  }

  // 金币收集
  for (const coin of coins) {
    if (!coin.active) continue;
    if (rectIntersect(runnerHB, coin.getHitbox())) {
      coin.active = false;
      coinsCollected++;
      score += 5;
    }
  }
}
```

### 4. 加速度递增

速度随时间线性增长，有上限：

```javascript
// world.update 中
this.speed = Math.min(this.maxSpeed, this.baseSpeed + this.elapsed * this.acceleration / 1000);
```

### 5. 视差背景

多层背景以不同速度滚动，产生深度感：

```javascript
const PARALLAX_LAYERS = [
  { speed: 0.1, color: '#1a1a3e', draw: drawSky },     // 远景天空
  { speed: 0.3, color: '#2a2a4e', draw: drawMountains }, // 中景山脉
  { speed: 0.6, color: '#3a3a5e', draw: drawTrees },     // 近景树木
  { speed: 1.0, color: '#4a4a6e', draw: drawGround },    // 地面
];

function renderParallax(ctx, layers, scrollDistance, canvasW, canvasH) {
  for (const layer of layers) {
    const offset = (scrollDistance * layer.speed) % canvasW;
    // 绘制两层交替实现无缝滚动
    layer.draw(ctx, -offset, canvasW, canvasH);
    layer.draw(ctx, -offset + canvasW, canvasW, canvasH);
  }
}
```

---

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 标题、开始按钮、最高分 |
| GameScene | 滚动世界 + 角色 + 障碍物 + 金币 |
| GameOverScene | 距离/金币/得分、重新开始 |

---

## config.js 参数建议

```javascript
const CONFIG = {
  gameName: 'Runner',
  version: '1.0.0',
  canvas: { width: 750, height: 400, designRatio: 750 / 400 }, // 横屏
  runner: {
    gravity: 2000,
    jumpForce: -700,
    jumpHoldForce: -200,
    maxJumpTime: 300,
    slideDuration: 500,
    invincibleDuration: 1000,
  },
  world: {
    baseSpeed: 300,
    maxSpeed: 750,
    acceleration: 20,
  },
  obstacles: OBSTACLE_TYPES,
  coins: { value: 5, spawnRate: 0.3 },
  scoring: { distancePerPoint: 10, coinValue: 5 },
  colors: {
    sky: '#1a1a3e',
    mountain: '#2a2a4e',
    tree: '#3a3a5e',
    ground: '#4a4a6e',
    runner: '#0f0',
    obstacle: '#f44',
    coin: '#ff0',
  },
  audio: {
    bgm: 'assets/audio/bgm.mp3',
    jump: 'assets/audio/sfx_jump.mp3',
    slide: 'assets/audio/sfx_slide.mp3',
    coin: 'assets/audio/sfx_coin.mp3',
    hurt: 'assets/audio/sfx_hurt.mp3',
  },
};
```

---

## 输入映射

| 操作 | 效果 |
|------|------|
| 点击/空格 | 跳跃（按住可变高度） |
| 下滑/↓/S | 滑铲 |
| 上滑/↑/W | 跳跃（替代点击） |

---

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 角色奔跑动画帧 | 可用矩形+微弹跳代替 | 可选 |
| 角色跳跃帧 | 可用矩形+旋转代替 | 可选 |
| 角色滑铲帧 | 可用压扁矩形代替 | 可选 |
| 障碍物图片 | 可用几何图形+颜色 | 可选 |
| 金币图片 | 可用黄色圆形代替 | 可选 |
| 背景图片 | 可用渐变色带代替 | 可选 |
| 跳跃音效 | `sfx_jump.mp3` | 推荐 |
| 滑铲音效 | `sfx_slide.mp3` | 推荐 |
| 金币音效 | `sfx_coin.mp3` | 推荐 |
| 碰撞音效 | `sfx_hurt.mp3` | 推荐 |
| BGM | `bgm.mp3` | 推荐 |

---

## 预估包体

- 纯 Canvas 绘制：**< 50KB**
- 含动画帧和音效：**< 300KB**
- 远低于 4MB 限制

---

## 渲染要点

```javascript
render(ctx) {
  // 1. 视差背景（多层）
  renderParallax(ctx, PARALLAX_LAYERS, world.scrollDistance, canvasW, canvasH);

  // 2. 地面线
  ctx.strokeStyle = CONFIG.colors.ground;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, groundY);
  ctx.lineTo(canvasW, groundY);
  ctx.stroke();

  // 3. 障碍物
  for (const ob of obstacles) {
    ctx.fillStyle = ob.color;
    ctx.fillRect(ob.x, groundY + ob.y, ob.width, ob.height);
  }

  // 4. 金币（旋转效果）
  for (const coin of coins) {
    if (!coin.active) continue;
    const scaleX = Math.abs(Math.cos(coin.rotation));
    ctx.fillStyle = CONFIG.colors.coin;
    ctx.beginPath();
    ctx.ellipse(coin.x, groundY + coin.y, coin.radius * scaleX, coin.radius, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // 5. 角色（状态感知绘制）
  const hb = runner.getHitbox();
  ctx.fillStyle = runner.isInvincible() && Math.floor(performance.now()/100) % 2 === 0
    ? 'rgba(0,255,0,0.5)' : CONFIG.colors.runner;
  if (runner.state === 'sliding') {
    ctx.fillRect(hb.x, groundY + hb.y, hb.w, hb.h);  // 压扁
  } else if (runner.state === 'jumping') {
    ctx.save();
    ctx.translate(hb.x + hb.w/2, groundY + hb.y + hb.h/2);
    ctx.rotate(Math.PI / 8);  // 轻微前倾
    ctx.fillRect(-hb.w/2, -hb.h/2, hb.w, hb.h);
    ctx.restore();
  } else {
    // 奔跑：微弹跳
    const bounce = Math.sin(runner.animFrame * 0.02) * 2;
    ctx.fillRect(hb.x, groundY + hb.y + bounce, hb.w, hb.h);
  }

  // 6. HUD
  ctx.fillStyle = '#fff';
  ctx.font = '20px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(`距离: ${Math.floor(world.scrollDistance / 10)}m`, 10, 30);
  ctx.fillText(`金币: ${coinsCollected}`, 200, 30);
  ctx.textAlign = 'right';
  ctx.fillText(`速度: ${Math.floor(world.speed)}`, canvasW - 10, 30);
}
```

---

## 包体优化指引

| 优化方向 | 具体做法 | 效果 |
|---------|---------|------|
| 程序化角色 | 奔跑=矩形微弹跳、跳跃=矩形旋转、滑铲=矩形压扁 | 零角色图片资源 |
| 渐变背景 | 多层渐变色带代替背景图 | 零背景资源 |
| 几何障碍 | 障碍物=矩形+颜色+尺寸区分类型 | 零障碍图片 |
| 程序化金币 | 金币=椭圆+旋转缩放模拟 3D | 零金币图片 |
| 音效压缩 | SFX 压缩为低码率 MP3 | 每个音效 < 30KB |
| BGM 分包 | BGM 放分包或 CDN | 主包减至 < 60KB |
