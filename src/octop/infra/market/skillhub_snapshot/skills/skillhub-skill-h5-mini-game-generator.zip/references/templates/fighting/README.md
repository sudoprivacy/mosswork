# 横版格斗类 (Fighting) — 模板参考

## 游戏概述

双角色对战格斗，有血条、能量条、招式系统。玩家控制一个角色，AI 控制对手。包含连招系统、格挡、击倒、起身等格斗游戏核心机制。核心挑战是帧数据驱动的招式系统和连招输入缓存。

> **复杂度**：★★★★★ — 需要状态机、帧数据招式系统、连招缓存、AI 对手、击退/浮空物理。
>
> **相关模块**：生成前应读取 `references/modules/ai-behaviors.md`（AI 对手 FSM+决策框架）、`references/modules/particles-and-pooling.md`（命中特效+拖尾）、`references/modules/audio-and-haptics.md`（出招/命中音效+振动）。

---

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Fighter` | `js/entities/Fighter.js` | 角色基类：状态机、属性、招式帧数据 |
| `PlayerFighter` | `js/entities/PlayerFighter.js` | 玩家输入处理、连招输入缓存 |
| `AIFighter` | `js/entities/AIFighter.js` | AI 决策（FSM + 反应延迟） |
| `Hitbox` | `js/entities/Hitbox.js` | 攻击判定盒（伤害、击退、持续帧） |
| `ComboSystem` | `js/utils/ComboSystem.js` | 连招输入缓存、取消窗口、连段表 |
| `FightStage` | `js/scenes/FightStage.js` | 对战场景管理（回合制、计时器） |

### Fighter 实体骨架

```javascript
class Fighter {
  constructor(config) {
    this.name = config.name;
    this.x = config.startX;
    this.y = 0;           // y=0 为地面
    this.vx = 0; this.vy = 0;
    this.facing = config.facing || 1;  // 1=右, -1=左
    this.hp = config.maxHp;
    this.maxHp = config.maxHp;
    this.energy = 0;
    this.maxEnergy = 100;
    this.speed = config.speed || 300;
    this.jumpForce = config.jumpForce || -600;
    this.gravity = config.gravity || 1500;
    this.width = 40;
    this.height = 70;

    // 状态机
    this.state = 'idle';
    this.stateTimer = 0;
    this.hitStun = 0;     // 受击硬直

    // 招式
    this.currentMove = null;
    this.moveFrame = 0;
    this.hitThisMove = false;  // 防止一招多段命中

    // 无敌帧
    this.invincibleTimer = 0;
  }

  changeState(newState) {
    this.state = newState;
    this.stateTimer = 0;
    if (newState !== 'attack') {
      this.currentMove = null;
      this.moveFrame = 0;
    }
  }

  update(dt, opponent) {
    this.stateTimer += dt;
    if (this.invincibleTimer > 0) this.invincibleTimer -= dt;

    // 自动面朝对手
    if (this.state === 'idle' || this.state === 'walk') {
      this.facing = opponent.x > this.x ? 1 : -1;
    }

    // 状态更新
    switch (this.state) {
      case 'idle':      this._updateIdle(dt); break;
      case 'walk':      this._updateWalk(dt); break;
      case 'jump':      this._updateJump(dt); break;
      case 'attack':    this._updateAttack(dt, opponent); break;
      case 'hurt':      this._updateHurt(dt); break;
      case 'block':     this._updateBlock(dt); break;
      case 'knockdown': this._updateKnockdown(dt); break;
      case 'getup':     this._updateGetup(dt); break;
    }

    // 通用物理
    this.vy += this.gravity * dt / 1000;
    this.y += this.vy * dt / 1000;
    if (this.y >= 0) {
      this.y = 0; this.vy = 0;
      if (this.state === 'jump') this.changeState('idle');
    }
    this.x += this.vx * dt / 1000;
    this.vx *= 0.85;  // 摩擦减速
    this.x = clamp(this.x, 40, canvasW - 40);
  }

  _updateIdle(dt) {
    // 能量缓慢恢复
    this.energy = Math.min(this.maxEnergy, this.energy + dt * 0.005);
  }

  _updateWalk(dt) {
    // 由子类设置 vx
  }

  _updateJump(dt) {
    // 空中微调
  }

  _updateAttack(dt, opponent) {
    this.moveFrame += dt;
    const move = MOVES[this.currentMove];
    if (!move) { this.changeState('idle'); return; }

    const activeStart = move.startup;
    const activeEnd = move.startup + move.active;

    // 在 active 帧期间检测命中
    if (this.moveFrame >= activeStart && this.moveFrame < activeEnd && !this.hitThisMove) {
      const hb = this._getWorldHitbox(move.hitbox);
      const opponentHB = opponent.getHurtbox();
      if (rectIntersect(hb, opponentHB)) {
        opponent.takeHit(move, this);
        this.hitThisMove = true;
        this.energy = Math.min(this.maxEnergy, this.energy + move.energyGain);
      }
    }

    // 收招完毕
    if (this.moveFrame >= move.startup + move.active + move.recovery) {
      this.currentMove = null;
      this.changeState('idle');
    }
  }

  _updateHurt(dt) {
    if (this.stateTimer >= this.hitStun) this.changeState('idle');
  }

  _updateBlock(dt) {
    // 格挡中无法移动
  }

  _updateKnockdown(dt) {
    // 倒地后经过一段时间起身
    if (this.stateTimer >= 800) this.changeState('getup');
  }

  _updateGetup(dt) {
    if (this.stateTimer >= 300) this.changeState('idle');
  }

  // 攻击
  startMove(moveName) {
    const move = MOVES[moveName];
    if (!move) return false;
    // 能量检查
    if (move.energyCost && this.energy < move.energyCost) return false;
    if (move.energyCost) this.energy -= move.energyCost;
    this.currentMove = moveName;
    this.moveFrame = 0;
    this.hitThisMove = false;
    this.changeState('attack');
    return true;
  }

  // 受击
  takeHit(move, attacker) {
    if (this.state === 'block') {
      // 格挡减伤
      this.hp -= Math.ceil(move.damage * 0.2);
      this.vx = move.knockback * 0.3 * -this.facing;
      this.energy = Math.min(this.maxEnergy, this.energy + 2);
      return;
    }
    if (this.invincibleTimer > 0) return;

    this.hp -= move.damage;
    this.energy = Math.min(this.maxEnergy, this.energy + move.damage * 0.3);

    // 击退
    const dir = attacker.x > this.x ? -1 : 1;
    this.vx = move.knockback * dir;

    if (move.launch) {
      // 浮空
      this.vy = -400;
      this.changeState('hurt');
      this.hitStun = 500;
    } else if (move.knockback >= 10) {
      this.changeState('knockdown');
    } else {
      this.changeState('hurt');
      this.hitStun = move.startup + move.active + move.recovery;
    }

    if (this.hp <= 0) {
      this.hp = 0;
      this.changeState('knockdown');
    }
  }

  // 获取攻击判定盒（世界坐标）
  _getWorldHitbox(hb) {
    return {
      x: this.facing > 0 ? this.x + hb.x : this.x - hb.x - hb.w,
      y: this.y + hb.y,
      w: hb.w, h: hb.h,
    };
  }

  // 获取受击判定盒（身体范围）
  getHurtbox() {
    return { x: this.x - this.width/2, y: this.y - this.height, w: this.width, h: this.height };
  }

  canAct() {
    return ['idle', 'walk'].includes(this.state);
  }
}
```

### 招式帧数据系统

```javascript
// 每个招式有 startup（起手）-> active（判定）-> recovery（收招）三阶段
const MOVES = {
  lightPunch: {
    startup: 80,    // 起手帧(ms)
    active: 80,     // 判定持续(ms)
    recovery: 200,  // 收招帧(ms)
    damage: 8,
    knockback: 3,
    energyGain: 5,
    hitbox: { x: 30, y: -50, w: 35, h: 20 },
    cancelInto: ['lightKick', 'heavyPunch'],  // 可取消的招式
  },
  lightKick: {
    startup: 100, active: 80, recovery: 250,
    damage: 10, knockback: 5, energyGain: 5,
    hitbox: { x: 25, y: -30, w: 45, h: 25 },
    cancelInto: ['heavyPunch', 'uppercut'],
  },
  heavyPunch: {
    startup: 200, active: 100, recovery: 400,
    damage: 20, knockback: 8, energyGain: 10,
    hitbox: { x: 30, y: -55, w: 45, h: 30 },
    cancelInto: [],
  },
  uppercut: {
    startup: 150, active: 150, recovery: 500,
    damage: 15, knockback: 12, launch: true,  // 浮空
    energyGain: 15, energyCost: 30,           // 消耗能量
    hitbox: { x: 20, y: -70, w: 40, h: 60 },
    cancelInto: [],
  },
};
```

### ComboSystem 实体骨架

```javascript
class ComboSystem {
  constructor() {
    this.inputBuffer = [];   // { input, timestamp }
    this.bufferWindow = 200; // 输入缓存窗口(ms)
  }

  addInput(input) {
    const now = performance.now();
    this.inputBuffer.push({ input, time: now });
    // 清除过期输入
    this.inputBuffer = this.inputBuffer.filter(i => now - i.time < this.bufferWindow);
  }

  // 在当前招式的可取消窗口期间检查输入
  checkCancel(fighter) {
    if (!fighter.currentMove) return null;
    const move = MOVES[fighter.currentMove];
    // 在 active 帧期间可以取消
    const inCancelWindow = fighter.moveFrame >= move.startup &&
                           fighter.moveFrame < move.startup + move.active;
    if (!inCancelWindow) return null;

    for (let i = 0; i < this.inputBuffer.length; i++) {
      if (move.cancelInto.includes(this.inputBuffer[i].input)) {
        const nextMove = this.inputBuffer[i].input;
        this.inputBuffer.splice(0, i + 1);  // 消费已用输入
        return nextMove;
      }
    }
    return null;
  }

  clear() { this.inputBuffer = []; }
}
```

### AIFighter 实体骨架

```javascript
class AIFighter extends Fighter {
  constructor(config) {
    super(config);
    this.aiState = 'idle';   // idle | approach | attack | retreat | block
    this.reactionDelay = config.reactionDelay || 300;
    this.lastDecisionTime = 0;
    this.difficulty = config.difficulty || 'normal';
  }

  updateAI(opponent, dt) {
    const dist = Math.abs(this.x - opponent.x);
    const now = performance.now();

    // 反应延迟
    if (now - this.lastDecisionTime < this.reactionDelay) {
      this._executeAIState(opponent, dist, dt);
      return;
    }
    this.lastDecisionTime = now;

    // 决策树
    if (opponent.state === 'attack' && dist < 100) {
      // 对手攻击且在近距 -> 格挡
      this.aiState = 'block';
    } else if (this.hp < this.maxHp * 0.25 && Math.random() < 0.3) {
      // 低血量 -> 后撤
      this.aiState = 'retreat';
    } else if (dist > 120) {
      // 远距 -> 接近
      this.aiState = 'approach';
    } else if (dist <= 120 && this.energy >= 30 && Math.random() < 0.3) {
      // 有能量 -> 必杀技
      this.aiState = 'special';
    } else if (dist <= 100) {
      // 近距 -> 攻击
      this.aiState = 'attack';
    } else {
      this.aiState = 'approach';
    }

    this._executeAIState(opponent, dist, dt);
  }

  _executeAIState(opponent, dist, dt) {
    const dir = opponent.x > this.x ? 1 : -1;
    switch (this.aiState) {
      case 'approach':
        if (this.canAct()) {
          this.vx = dir * this.speed;
          this.changeState('walk');
        }
        break;
      case 'retreat':
        if (this.canAct()) {
          this.vx = -dir * this.speed * 0.7;
          this.changeState('walk');
        }
        break;
      case 'attack':
        if (this.canAct()) {
          // 随机选择轻攻击
          const moves = ['lightPunch', 'lightKick'];
          if (this.energy >= 30) moves.push('heavyPunch');
          this.startMove(moves[Math.floor(Math.random() * moves.length)]);
        }
        break;
      case 'special':
        if (this.canAct() && this.energy >= 30) {
          this.startMove('uppercut');
        }
        break;
      case 'block':
        if (this.canAct()) this.changeState('block');
        break;
    }
  }
}
```

### PlayerFighter 实体骨架

```javascript
class PlayerFighter extends Fighter {
  constructor(config) {
    super(config);
    this.comboSystem = new ComboSystem();
  }

  handleInput(input) {
    // 移动
    if (this.canAct()) {
      if (input.left) {
        this.vx = -this.speed;
        this.changeState('walk');
      } else if (input.right) {
        this.vx = this.speed;
        this.changeState('walk');
      } else if (this.state === 'walk') {
        this.vx = 0;
        this.changeState('idle');
      }
    }

    // 跳跃
    if (input.jumpPressed && this.canAct()) {
      this.vy = this.jumpForce;
      this.changeState('jump');
    }

    // 格挡
    if (input.block && this.canAct()) {
      this.changeState('block');
    } else if (this.state === 'block' && !input.block) {
      this.changeState('idle');
    }

    // 攻击
    if (input.lightAttackPressed && this.canAct()) {
      this.comboSystem.addInput('lightPunch');
      this.startMove('lightPunch');
    }
    if (input.heavyAttackPressed && this.canAct()) {
      this.comboSystem.addInput('heavyPunch');
      this.startMove('heavyPunch');
    }
    if (input.specialPressed && this.canAct() && this.energy >= 30) {
      this.comboSystem.addInput('uppercut');
      this.startMove('uppercut');
    }

    // 连招取消检测
    if (this.state === 'attack') {
      const nextMove = this.comboSystem.checkCancel(this);
      if (nextMove) {
        this.startMove(nextMove);
      }
    }
  }
}
```

---

## 核心算法

### 1. 状态机（FSM）

```
┌──────┐  移动  ┌──────┐  跳跃  ┌──────┐
│ idle │ ←───→ │ walk │ ────→ │ jump │
└──┬───┘       └──────┘       └──┬───┘
   │                              │
   │ 攻击     ┌────────┐          │
   ├───────→ │ attack │          │
   │          └────────┘          │
   │ 格挡     ┌───────┐           │
   ├───────→ │ block │           │
   │          └───────┘           │
   │ 受击     ┌──────┐            │
   ├───────→ │ hurt │ ←──────────┘
   │          └──────┘
   │ 击倒     ┌──────────┐  ┌────────┐
   └───────→ │knockdown │→ │ getup  │→ idle
              └──────────┘  └────────┘
```

### 2. 帧数据驱动的招式系统

每个招式分三阶段：

| 阶段 | 时长 | 行为 |
|------|------|------|
| **startup** | 80-200ms | 起手动画，无判定 |
| **active** | 80-150ms | 攻击判定有效，可命中对手 |
| **recovery** | 200-500ms | 收招硬直，无法行动 |

> **取消窗口**：在 active 帧期间，如果玩家输入了 `cancelInto` 列表中的招式，立即取消当前招式转入新招式——这就是连招的核心机制。

### 3. 连招输入缓存

玩家在当前招式执行期间按下的攻击键被缓存（200ms 窗口），在取消窗口期间检查是否匹配连段表。

```
输入序列：轻拳 → 轻踢 → 重拳
     ↓        ↓        ↓
  lightPunch(80ms startup) → active 帧检查到 lightKick 在 cancelInto 中
  → 立即取消 → lightKick → active 帧检查到 heavyPunch
  → 立即取消 → heavyPunch → 无 cancelInto，收招
```

### 4. AI 决策

基于距离和对手状态的简单决策树（见 `AIFighter.updateAI`）。难度通过反应延迟和决策概率控制。

### 5. 击退与浮空

| 击退值 | 效果 | 招式示例 |
|--------|------|---------|
| 1-5 | 轻微后退 | 轻拳/轻踢 |
| 6-10 | 明显后退 | 重拳 |
| 10+ | 击倒 | 上勾拳 |
| launch=true | 浮空（可追击） | 升龙拳 |

---

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 角色选择、难度选择 |
| FightStage | 对战场景（双方角色 + HUD） |
| RoundOverScene | 回合结算（谁赢了本回合） |
| GameOverScene | 最终结果、重新开始 |

### FightStage 回合管理

```javascript
class FightStage {
  constructor() {
    this.player = new PlayerFighter({ name: 'P1', maxHp: 100, startX: 200, facing: 1 });
    this.ai = new AIFighter({ name: 'CPU', maxHp: 100, startX: 550, facing: -1, difficulty: 'normal' });
    this.roundsToWin = 2;
    this.playerWins = 0;
    this.aiWins = 0;
    this.currentRound = 1;
    this.roundTimer = 60000;  // 60秒
    this.roundActive = false;
  }

  startRound() {
    this.player.hp = this.player.maxHp;
    this.ai.hp = this.ai.maxHp;
    this.player.x = 200; this.ai.x = 550;
    this.player.changeState('idle'); this.ai.changeState('idle');
    this.roundTimer = 60000;
    this.roundActive = true;
  }

  update(dt, input) {
    if (!this.roundActive) return;
    this.roundTimer -= dt;

    this.player.handleInput(input);
    this.player.update(dt, this.ai);

    this.ai.updateAI(this.player, dt);
    this.ai.update(dt, this.player);

    // 回合结束判定
    if (this.player.hp <= 0) { this.aiWins++; this._endRound(); }
    else if (this.ai.hp <= 0) { this.playerWins++; this._endRound(); }
    else if (this.roundTimer <= 0) {
      // 超时：血量高者胜
      if (this.player.hp > this.ai.hp) this.playerWins++;
      else if (this.ai.hp > this.player.hp) this.aiWins++;
      this._endRound();
    }
  }

  _endRound() {
    this.roundActive = false;
    if (this.playerWins >= this.roundsToWin || this.aiWins >= this.roundsToWin) {
      sceneManager.switch('gameover');
    } else {
      this.currentRound++;
      setTimeout(() => this.startRound(), 2000);
    }
  }
}
```

---

## config.js 参数建议

```javascript
const CONFIG = {
  gameName: 'Fighting',
  version: '1.0.0',
  canvas: { width: 800, height: 450, designRatio: 800 / 450 }, // 横屏
  fighters: {
    player: { name: 'Player', maxHp: 100, speed: 300, jumpForce: -600, gravity: 1500, startX: 200, facing: 1 },
    ai:     { name: 'CPU',    maxHp: 100, speed: 280, jumpForce: -600, gravity: 1500, startX: 550, facing: -1 },
  },
  moves: MOVES,  // 见上方定义
  ai: {
    difficulty: 'normal',  // easy | normal | hard | nightmare
    reactionDelay: 300,
    blockChance: 0.4,
    attackChance: 0.6,
  },
  stage: { groundY: 0, leftBound: 40, rightBound: 760 },
  rounds: { toWin: 2, timeLimit: 60000 },
  colors: {
    background: '#1a1a2e',
    ground: '#16213e',
    player: '#0f0',
    ai: '#f44',
    healthBar: '#0f0',
    healthBarLow: '#f00',
    energyBar: '#0ff',
  },
  audio: {
    bgm: 'assets/audio/bgm_fight.mp3',
    lightHit: 'assets/audio/sfx_light_hit.mp3',
    heavyHit: 'assets/audio/sfx_heavy_hit.mp3',
    block: 'assets/audio/sfx_block.mp3',
    knockdown: 'assets/audio/sfx_knockdown.mp3',
    ko: 'assets/audio/sfx_ko.mp3',
  },
};
```

---

## 输入映射

| 操作 | 效果 |
|------|------|
| ← / A | 向左移动 |
| → / D | 向右移动 |
| ↑ / W | 跳跃 |
| ↓ / S | 蹲下/格挡（按住） |
| J / 轻击 | 轻攻击（可连招） |
| K / 重击 | 重攻击 |
| L / 特殊 | 特殊技（消耗能量） |

---

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 角色精灵帧 | 各状态动画（idle/walk/attack/hurt/knockdown） | 可选 |
| 打击特效 | 可用放射状线条+粒子代替 | 可选 |
| 命中音效 | `sfx_light_hit.mp3` / `sfx_heavy_hit.mp3` | 推荐 |
| 格挡音效 | `sfx_block.mp3` | 推荐 |
| 击倒音效 | `sfx_knockdown.mp3` | 推荐 |
| KO 音效 | `sfx_ko.mp3` | 推荐 |
| 对战 BGM | `bgm_fight.mp3` | 推荐 |

---

## 预估包体

- 纯 Canvas 绘制：**< 60KB**
- 含精灵帧和音效：**< 400KB**
- 远低于 4MB 限制

---

## 渲染要点

```javascript
render(ctx) {
  // 1. 背景
  ctx.fillStyle = CONFIG.colors.background;
  ctx.fillRect(0, 0, canvasW, canvasH);
  // 地面
  ctx.fillStyle = CONFIG.colors.ground;
  ctx.fillRect(0, canvasH - 80, canvasW, 80);

  // 2. 角色（根据状态绘制）
  drawFighter(ctx, player, CONFIG.colors.player);
  drawFighter(ctx, ai, CONFIG.colors.ai);

  // 3. 命中特效（粒子）
  particlePool.renderAll(ctx);

  // 4. HUD
  // 玩家血条（左）
  drawHealthBar(ctx, 20, 20, 300, 20, player.hp, player.maxHp, true);
  drawEnergyBar(ctx, 20, 45, 200, 8, player.energy, player.maxEnergy);
  // AI 血条（右）
  drawHealthBar(ctx, canvasW - 320, 20, 300, 20, ai.hp, ai.maxHp, false);
  drawEnergyBar(ctx, canvasW - 220, 45, 200, 8, ai.energy, ai.maxEnergy);
  // 回合数
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(`R${currentRound}`, canvasW/2, 35);
  // 计时器
  ctx.fillText(Math.ceil(roundTimer / 1000), canvasW/2, 70);
  // 回合胜场
  ctx.font = '16px Arial';
  ctx.fillText('●'.repeat(playerWins), 30, 75);
  ctx.fillText('●'.repeat(aiWins), canvasW - 50, 75);
}

function drawFighter(ctx, fighter, color) {
  const hb = fighter.getHurtbox();
  ctx.save();

  // 闪烁（无敌帧）
  if (fighter.invincibleTimer > 0 && Math.floor(performance.now()/80) % 2 === 0) {
    ctx.globalAlpha = 0.5;
  }

  ctx.fillStyle = color;
  // 根据状态变形
  switch (fighter.state) {
    case 'idle':
      // 站立矩形（微浮动）
      const idle = Math.sin(performance.now() * 0.003) * 2;
      ctx.fillRect(hb.x, hb.y + idle, hb.w, hb.h);
      break;
    case 'walk':
      ctx.fillRect(hb.x, hb.y, hb.w, hb.h);
      // 移动方向指示
      ctx.fillRect(hb.x + hb.w/2 * fighter.facing, hb.y + hb.h/2, 10, 5);
      break;
    case 'attack':
      // 攻击时身体前倾
      const move = MOVES[fighter.currentMove];
      if (move) {
        const attackHB = fighter._getWorldHitbox(move.hitbox);
        ctx.fillRect(hb.x, hb.y, hb.w, hb.h);
        // 攻击判定盒（调试可见或绘制为拳头延伸）
        ctx.globalAlpha *= 0.7;
        ctx.fillRect(attackHB.x, attackHB.y, attackHB.w, attackHB.h);
      }
      break;
    case 'hurt':
      // 后仰
      ctx.save();
      ctx.translate(hb.x + hb.w/2, hb.y + hb.h/2);
      ctx.rotate(fighter.facing * 0.2);
      ctx.fillRect(-hb.w/2, -hb.h/2, hb.w, hb.h);
      ctx.restore();
      break;
    case 'knockdown':
      // 倒地（旋转 90 度）
      ctx.save();
      ctx.translate(hb.x + hb.w/2, hb.y + hb.h);
      ctx.rotate(fighter.facing * Math.PI / 2);
      ctx.fillRect(-hb.w/2, -hb.h, hb.w, hb.h);
      ctx.restore();
      break;
    case 'block':
      // 格挡（缩小+蓝色边框）
      ctx.fillRect(hb.x + 5, hb.y + 5, hb.w - 10, hb.h - 10);
      ctx.strokeStyle = '#0ff';
      ctx.lineWidth = 2;
      ctx.strokeRect(hb.x + 5, hb.y + 5, hb.w - 10, hb.h - 10);
      break;
    default:
      ctx.fillRect(hb.x, hb.y, hb.w, hb.h);
  }

  // 面朝方向指示（眼睛）
  ctx.fillStyle = '#fff';
  const eyeX = fighter.facing > 0 ? hb.x + hb.w * 0.7 : hb.x + hb.w * 0.3;
  ctx.fillRect(eyeX - 2, hb.y + 10, 4, 4);

  ctx.restore();
}
```

---

## 包体优化指引

| 优化方向 | 具体做法 | 效果 |
|---------|---------|------|
| 状态化角色 | idle=微浮动矩形、attack=前伸、hurt=后仰、knockdown=旋转90° | 零角色图片资源 |
| 程序化特效 | 打击特效=放射线+粒子，代替图片 | 零特效资源 |
| 几何场景 | 背景=纯色+地面矩形 | 零场景资源 |
| 音效压缩 | SFX 压缩为低码率 MP3 | 每个音效 < 30KB |
| BGM 分包 | BGM 放分包或 CDN | 主包减至 < 80KB |
