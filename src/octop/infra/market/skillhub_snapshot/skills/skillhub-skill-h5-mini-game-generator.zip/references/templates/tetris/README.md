# 俄罗斯方块 (Tetris) — 模板参考

## 游戏概述

经典俄罗斯方块：7 种方块下落，旋转、左右移动、加速下落，消除满行得分。

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Tetromino` | `js/entities/Tetromino.js` | 方块定义、旋转、位置 |
| `Board` | `js/entities/Board.js` | 棋盘网格、消行检测、锁定 |
| `NextPiece` | `js/entities/NextPiece.js` | 下一个方块预览 |

### Tetromino 实体骨架

```javascript
// 7 种方块定义（SRS 标准）
const SHAPES = {
  I: [[1,1,1,1]],
  O: [[1,1],[1,1]],
  T: [[0,1,0],[1,1,1]],
  S: [[0,1,1],[1,1,0]],
  Z: [[1,1,0],[0,1,1]],
  J: [[1,0,0],[1,1,1]],
  L: [[0,0,1],[1,1,1]],
};

const COLORS = {
  I: '#00f0f0', O: '#f0f000', T: '#a000f0',
  S: '#00f000', Z: '#f00000', J: '#0000f0', L: '#f0a000',
};

class Tetromino {
  constructor(type) {
    this.type = type;
    this.shape = SHAPES[type].map(row => [...row]);
    this.color = COLORS[type];
    this.x = Math.floor((10 - this.shape[0].length) / 2);
    this.y = 0;
  }

  // 矩阵旋转（顺时针）
  rotate() {
    const rows = this.shape.length;
    const cols = this.shape[0].length;
    const rotated = [];
    for (let c = 0; c < cols; c++) {
      rotated[c] = [];
      for (let r = rows - 1; r >= 0; r--) {
        rotated[c].push(this.shape[r][c]);
      }
    }
    return rotated;
  }

  getCells(dx = 0, dy = 0, shape = this.shape) {
    const cells = [];
    for (let r = 0; r < shape.length; r++) {
      for (let c = 0; c < shape[r].length; c++) {
        if (shape[r][c]) {
          cells.push({ x: this.x + c + dx, y: this.y + r + dy });
        }
      }
    }
    return cells;
  }
}
```

### Board 实体骨架

```javascript
class Board {
  constructor(cols, rows) {
    this.cols = cols;
    this.rows = rows;
    this.grid = Array.from({ length: rows }, () => Array(cols).fill(null));
  }

  isValid(piece, dx = 0, dy = 0, shape = piece.shape) {
    return piece.getCells(dx, dy, shape).every(cell =>
      cell.x >= 0 && cell.x < this.cols &&
      cell.y >= 0 && cell.y < this.rows &&
      !this.grid[cell.y][cell.x]
    );
  }

  lock(piece) {
    for (const cell of piece.getCells()) {
      if (cell.y >= 0) this.grid[cell.y][cell.x] = piece.color;
    }
  }

  clearLines() {
    let cleared = 0;
    for (let r = this.rows - 1; r >= 0; r--) {
      if (this.grid[r].every(cell => cell !== null)) {
        this.grid.splice(r, 1);
        this.grid.unshift(Array(this.cols).fill(null));
        cleared++;
        r++; // 重新检查该行
      }
    }
    return cleared;
  }
}
```

## 核心算法

### SRS 旋转（带踢墙）

```javascript
tryRotate(board) {
  const rotated = this.rotate();
  // 尝试踢墙偏移
  const kicks = [0, -1, 1, -2, 2];
  for (const kick of kicks) {
    if (board.isValid(this, kick, 0, rotated)) {
      this.x += kick;
      this.shape = rotated;
      return true;
    }
  }
  return false;
}
```

### 下落与锁定

```javascript
// GameScene.update
update(dt) {
  this.fallTimer += dt;
  const speed = this.softDrop ? 50 : this.config.fallSpeed;

  if (this.fallTimer >= speed) {
    this.fallTimer = 0;
    if (board.isValid(currentPiece, 0, 1)) {
      currentPiece.y++;
    } else {
      // 锁定并检查消行
      board.lock(currentPiece);
      const cleared = board.clearLines();
      this.score += SCORE_TABLE[cleared] || 0;

      // 生成新方块
      currentPiece = nextPiece;
      nextPiece = new Tetromino(randomType());

      // 游戏结束检测
      if (!board.isValid(currentPiece)) {
        this.sceneManager.switch('gameover');
      }
    }
  }
}
```

### Lock Delay（锁定延迟）

方块触底后给玩家短暂时间继续移动：

```javascript
if (!board.isValid(currentPiece, 0, 1)) {
  this.lockDelay += dt;
  if (this.lockDelay >= 500) {  // 500ms 延迟
    // 执行锁定
  }
} else {
  this.lockDelay = 0;
}
```

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 标题、开始按钮、操作说明 |
| GameScene | 棋盘、当前方块、下一个方块预览、分数 |
| GameOverScene | 最终分数、重新开始 |

## config.js 参数建议

```javascript
const CONFIG = {
  gameplay: {
    cols: 10,
    rows: 20,
    cellSize: 28,
    fallSpeed: 800,     // 初始下落间隔(ms)
    speedDecrement: 50, // 每升一级减少
    minFallSpeed: 100,
    lockDelay: 500,     // 锁定延迟(ms)
    softDropSpeed: 50,  // 软降速度
    linesPerLevel: 10,  // 升级所需行数
  },
  scoring: {
    0: 0, 1: 100, 2: 300, 3: 500, 4: 800,  // 消行得分
  },
};
```

## 输入映射

| 操作 | 效果 |
|------|------|
| ← / A | 左移 |
| → / D | 右移 |
| ↑ / W | 旋转 |
| ↓ / S | 软降（加速下落） |
| 空格 | 硬降（直接落底） |
| 左滑 | 左移 |
| 右滑 | 右移 |
| 点击 | 旋转 |
| 下滑 | 软降 |

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 方块图片 | 可用纯色填充 + 边框代替 | 可选 |
| 消行音效 | `clear.mp3` | 推荐 |
| 锁定音效 | `lock.mp3` | 可选 |
| 旋转音效 | `rotate.mp3` | 可选 |

## 预估包体

- 纯 Canvas 绘制：**< 40KB**
- 含音效：**< 150KB**

## 渲染要点

```javascript
render(ctx) {
  // 绘制棋盘背景
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, boardW, boardH);

  // 绘制已锁定方块
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (board.grid[r][c]) {
        drawBlock(ctx, c, r, board.grid[r][c]);
      }
    }
  }

  // 绘制当前方块的投影（ghost piece）
  const ghostY = calculateGhostY(currentPiece, board);
  drawPiece(ctx, currentPiece, ghostY, true);  // 半透明

  // 绘制当前方块
  drawPiece(ctx, currentPiece, currentPiece.y, false);

  // 侧边栏：下一个方块、分数、等级
}

function drawBlock(ctx, col, row, color) {
  const x = col * cellSize;
  const y = row * cellSize;
  ctx.fillStyle = color;
  ctx.fillRect(x + 1, y + 1, cellSize - 2, cellSize - 2);
  // 高光效果
  ctx.fillStyle = 'rgba(255,255,255,0.2)';
  ctx.fillRect(x + 1, y + 1, cellSize - 2, 3);
}
```
