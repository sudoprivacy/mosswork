# 贪吃蛇 (Snake) — 模板参考

## 游戏概述

经典贪吃蛇游戏：控制蛇移动吃食物，蛇身变长，撞墙或自身则游戏结束。

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Snake` | `js/entities/Snake.js` | 蛇身（段数组）、移动、生长、碰撞检测 |
| `Food` | `js/entities/Food.js` | 食物位置、随机生成 |
| `Grid` | `js/core/Grid.js`（可选） | 网格坐标系统 |

### Snake 实体骨架

```javascript
class Snake {
  constructor(config) {
    this.segments = [{ x: 10, y: 10 }];  // 初始位置
    this.direction = { x: 1, y: 0 };       // 初始方向（右）
    this.nextDirection = { x: 1, y: 0 };
    this.growing = 0;
    this.config = config;
  }

  setDirection(dx, dy) {
    // 禁止 180 度反转
    if (this.direction.x === -dx && this.direction.y === -dy) return;
    this.nextDirection = { x: dx, y: dy };
  }

  move() {
    this.direction = this.nextDirection;
    const head = this.segments[0];
    const newHead = {
      x: head.x + this.direction.x,
      y: head.y + this.direction.y,
    };
    this.segments.unshift(newHead);

    if (this.growing > 0) {
      this.growing--;
    } else {
      this.segments.pop();
    }
  }

  grow() { this.growing += 1; }

  checkSelfCollision() {
    const head = this.segments[0];
    return this.segments.slice(1).some(s => s.x === head.x && s.y === head.y);
  }

  checkWallCollision(cols, rows) {
    const head = this.segments[0];
    return head.x < 0 || head.x >= cols || head.y < 0 || head.y >= rows;
  }
}
```

## 场景结构

```
MenuScene → GameScene → GameOverScene
```

| 场景 | 功能 |
|------|------|
| MenuScene | 显示标题、"开始游戏"按钮、最高分 |
| GameScene | 游戏主循环、渲染蛇和食物、处理输入 |
| GameOverScene | 显示得分、"重新开始"按钮 |

## 核心算法

### 网格移动

蛇在固定网格上移动，每次移动一格：

```javascript
// GameScene.update
update(dt) {
  this.moveTimer += dt;
  if (this.moveTimer >= this.config.speed) {
    this.moveTimer = 0;
    this.snake.move();

    // 碰撞检测
    if (this.snake.checkWallCollision(cols, rows) ||
        this.snake.checkSelfCollision()) {
      this.sceneManager.switch('gameover');
      return;
    }

    // 吃食物
    if (head.x === food.x && head.y === food.y) {
      this.snake.grow();
      this.food.respawn(this.snake.segments);
      this.score += 10;
    }
  }
}
```

### 食物随机生成（避开蛇身）

```javascript
respawn(snakeSegments) {
  const occupied = new Set(snakeSegments.map(s => `${s.x},${s.y}`));
  let pos;
  do {
    pos = {
      x: Math.floor(Math.random() * cols),
      y: Math.floor(Math.random() * rows),
    };
  } while (occupied.has(`${pos.x},${pos.y}`));
  this.x = pos.x;
  this.y = pos.y;
}
```

## config.js 参数建议

```javascript
const CONFIG = {
  gameplay: {
    cols: 20,           // 网格列数
    rows: 30,           // 网格行数
    cellSize: 25,       // 每格像素
    initialSpeed: 150,  // 初始移动间隔(ms)
    speedIncrement: 5,  // 每吃一个食物加速
    minSpeed: 60,       // 最快速度
  },
  colors: {
    background: '#1a1a2e',
    grid: '#16213e',
    snake: '#0f0',
    snakeHead: '#0f0',
    food: '#f00',
  },
};
```

## 输入映射

| 操作 | 效果 |
|------|------|
| ↑ / W | 向上 |
| ↓ / S | 向下 |
| ← / A | 向左 |
| → / D | 向右 |
| 滑动 | 触屏方向（判断滑动方向） |

### 触屏滑动方向检测

```javascript
let touchStart = null;
inputHandler.on('down', (pos) => { touchStart = pos; });
inputHandler.on('up', (pos) => {
  if (!touchStart) return;
  const dx = pos.x - touchStart.x;
  const dy = pos.y - touchStart.y;
  if (Math.abs(dx) > Math.abs(dy)) {
    snake.setDirection(dx > 0 ? 1 : -1, 0);
  } else {
    snake.setDirection(0, dy > 0 ? 1 : -1);
  }
  touchStart = null;
});
```

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 蛇身图片 | 可用纯色填充代替 | 可选 |
| 食物图片 | 可用纯色圆形代替 | 可选 |
| 吃食物音效 | `eat.mp3`，<1s | 推荐 |
| 游戏结束音效 | `gameover.mp3`，<2s | 推荐 |

## 预估包体

- 无图片资源（纯 Canvas 绘制）：**< 30KB**
- 含少量音效：**< 100KB**
- 远低于 4MB 限制

## 渲染要点

```javascript
render(ctx) {
  // 清屏
  ctx.fillStyle = CONFIG.colors.background;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 绘制网格（可选）
  ctx.strokeStyle = CONFIG.colors.grid;
  for (let i = 0; i <= cols; i++) { /* 画线 */ }

  // 绘制食物
  ctx.fillStyle = CONFIG.colors.food;
  ctx.beginPath();
  ctx.arc(food.x * cellSize + cellSize/2, food.y * cellSize + cellSize/2,
          cellSize/2 - 2, 0, Math.PI * 2);
  ctx.fill();

  // 绘制蛇（批量同色）
  ctx.fillStyle = CONFIG.colors.snake;
  for (const seg of snake.segments) {
    ctx.fillRect(seg.x * cellSize + 1, seg.y * cellSize + 1,
                 cellSize - 2, cellSize - 2);
  }
}
```
