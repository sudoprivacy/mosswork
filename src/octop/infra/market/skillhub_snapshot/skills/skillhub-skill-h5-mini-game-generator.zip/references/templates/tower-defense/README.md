# 塔防/策略类 (Tower Defense) — 模板参考

## 游戏概述

玩家在地图上放置防御塔，敌人沿固定路径前进，塔自动攻击范围内的敌人。包含经济系统（击杀获得金币）、塔升级系统、敌人波次递增。核心挑战是路径插值和塔目标选择策略。

> **复杂度**：★★★★☆ — 需要路径插值、塔目标选择、经济系统、波次生成器。
>
> **相关模块**：生成前应读取 `references/modules/ai-behaviors.md`（波次生成器）、`references/modules/particles-and-pooling.md`（弹道对象池+空间网格）、`references/modules/audio-and-haptics.md`（音效+振动）。

---

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Tower` | `js/entities/Tower.js` | 塔类型、位置、等级、攻击范围、伤害、射速、目标选择 |
| `Enemy` | `js/entities/Enemy.js` | 位置、HP、速度、路径进度、类型（普通/快速/装甲/Boss） |
| `Projectile` | `js/entities/Projectile.js` | 弹道（直线/追踪）、伤害、目标引用 |
| `Path` | `js/core/Path.js` | 路径节点数组、分段线性插值 |
| `TileMap` | `js/core/TileMap.js` | 网格地图、可放置区域标记 |
| `WaveManager` | `js/utils/WaveManager.js` | 波次配置、敌人生成间隔、难度递增 |
| `Economy` | `js/utils/Economy.js` | 金币管理、消费、收入 |

### Path 实体骨架

```javascript
// js/core/Path.js
class Path {
  constructor(nodes) {
    this.nodes = nodes;
    this.segments = this._calcSegments();
    this.totalLength = this.segments.reduce((s, seg) => s + seg.len, 0);
  }

  _calcSegments() {
    const segs = [];
    let accumulated = 0;
    for (let i = 0; i < this.nodes.length - 1; i++) {
      const dx = this.nodes[i+1].x - this.nodes[i].x;
      const dy = this.nodes[i+1].y - this.nodes[i].y;
      const len = Math.hypot(dx, dy);
      segs.push({ start: this.nodes[i], end: this.nodes[i+1], len, accumulated });
      accumulated += len;
    }
    return segs;
  }

  // progress: 0(起点) ~ 1(终点)
  getPositionAt(progress) {
    const dist = Math.max(0, Math.min(1, progress)) * this.totalLength;
    for (const seg of this.segments) {
      if (dist <= seg.accumulated + seg.len) {
        const t = (dist - seg.accumulated) / seg.len;
        return {
          x: seg.start.x + (seg.end.x - seg.start.x) * t,
          y: seg.start.y + (seg.end.y - seg.start.y) * t,
        };
      }
    }
    return { ...this.nodes[this.nodes.length - 1] };
  }

  getDirectionAt(progress) {
    const dist = progress * this.totalLength;
    for (const seg of this.segments) {
      if (dist <= seg.accumulated + seg.len) {
        const dx = seg.end.x - seg.start.x;
        const dy = seg.end.y - seg.start.y;
        const len = Math.hypot(dx, dy);
        return { x: dx / len, y: dy / len };
      }
    }
    return { x: 0, y: 0 };
  }
}
```

### Enemy 实体骨架

```javascript
class Enemy {
  constructor(type, path) {
    const cfg = ENEMY_TYPES[type];
    this.type = type;
    this.path = path;
    this.pathProgress = 0;       // 0~1 沿路径进度
    this.hp = cfg.hp;
    this.maxHp = cfg.hp;
    this.speed = cfg.speed;      // 路径进度速率
    this.reward = cfg.reward;
    this.size = cfg.size;
    this.color = cfg.color;
    this.slowEffect = 0;         // 减速计时器
    this.slowFactor = 1;
    this.active = true;
    this.reachedEnd = false;
    const pos = path.getPositionAt(0);
    this.x = pos.x; this.y = pos.y;
  }

  update(dt) {
    // 减速效果
    if (this.slowEffect > 0) {
      this.slowEffect -= dt;
      this.slowFactor = 0.5;
    } else {
      this.slowFactor = 1;
    }

    // 沿路径前进
    this.pathProgress += this.speed * this.slowFactor * dt / 1000;
    if (this.pathProgress >= 1) {
      this.reachedEnd = true;
      this.active = false;
      return;
    }

    const pos = this.path.getPositionAt(this.pathProgress);
    this.x = pos.x;
    this.y = pos.y;
  }

  takeDamage(dmg) {
    this.hp -= dmg;
    if (this.hp <= 0) this.active = false;
  }

  applySlow(duration) {
    this.slowEffect = Math.max(this.slowEffect, duration);
  }

  getHitbox() {
    return { x: this.x - this.size/2, y: this.y - this.size/2, w: this.size, h: this.size };
  }
}

const ENEMY_TYPES = {
  normal:  { hp: 30,  speed: 0.0003, reward: 10,  size: 24, color: '#f44' },
  fast:    { hp: 15,  speed: 0.0006, reward: 15,  size: 20, color: '#ff0' },
  armored: { hp: 80,  speed: 0.0002, reward: 25,  size: 28, color: '#88f' },
  boss:    { hp: 500, speed: 0.00015, reward: 200, size: 48, color: '#a0f' },
};
```

### Tower 实体骨架

```javascript
class Tower {
  constructor(type, x, y) {
    const cfg = TOWER_TYPES[type];
    this.type = type;
    this.x = x; this.y = y;
    this.level = 1;
    this.range = cfg.range;
    this.damage = cfg.damage;
    this.fireRate = cfg.fireRate;
    this.fireCooldown = 0;
    this.target = null;
    this.targetingStrategy = cfg.targeting || 'first';
    this.color = cfg.color;
    this.size = 30;
    this.splash = cfg.splash || 0;
    this.slow = cfg.slow || 0;
    this.totalCost = cfg.cost;
  }

  update(dt, enemies, projectiles) {
    this.fireCooldown -= dt;

    // 检查当前目标是否仍有效
    if (this.target) {
      if (!this.target.active || this._distanceTo(this.target) > this.range) {
        this.target = null;
      }
    }

    // 选择新目标
    if (!this.target) {
      this.target = this._selectTarget(enemies);
    }

    // 射击
    if (this.target && this.fireCooldown <= 0) {
      this._fire(projectiles);
      this.fireCooldown = this.fireRate;
    }
  }

  _selectTarget(enemies) {
    let best = null;
    let bestScore = -Infinity;
    for (const e of enemies) {
      if (!e.active) continue;
      const dist = this._distanceTo(e);
      if (dist > this.range) continue;
      let score;
      switch (this.targetingStrategy) {
        case 'first':  score = e.pathProgress; break;       // 最前方
        case 'last':   score = -e.pathProgress; break;      // 最后方
        case 'strong': score = e.hp; break;                 // 最高血量
        case 'weak':   score = -e.hp; break;                // 最低血量
        default:       score = e.pathProgress;
      }
      if (score > bestScore) { bestScore = score; best = e; }
    }
    return best;
  }

  _distanceTo(enemy) {
    return Math.hypot(enemy.x - this.x, enemy.y - this.y);
  }

  _fire(projectiles) {
    projectiles.push(new Projectile(this.x, this.y, this.target, {
      damage: this.damage, speed: 400,
      splash: this.splash, slow: this.slow,
    }));
  }

  upgrade() {
    const upgradeCfg = TOWER_TYPES[this.type].upgrades[this.level - 1];
    if (!upgradeCfg) return false;
    this.level++;
    this.range = upgradeCfg.range;
    this.damage = upgradeCfg.damage;
    this.fireRate = upgradeCfg.fireRate;
    this.totalCost += upgradeCfg.cost;
    return true;
  }

  getUpgradeCost() {
    const cfg = TOWER_TYPES[this.type].upgrades[this.level - 1];
    return cfg ? cfg.cost : null;
  }

  getSellValue() { return Math.floor(this.totalCost * 0.7); }
}

const TOWER_TYPES = {
  arrow: {
    cost: 50, range: 100, damage: 10, fireRate: 500,
    color: '#0f0', targeting: 'first',
    upgrades: [
      { cost: 75,  range: 120, damage: 18, fireRate: 450 },
      { cost: 150, range: 140, damage: 30, fireRate: 350 },
      { cost: 300, range: 160, damage: 55, fireRate: 250 },
    ],
  },
  cannon: {
    cost: 100, range: 80, damage: 30, fireRate: 1000,
    color: '#f80', targeting: 'strong', splash: 40,
    upgrades: [
      { cost: 120, range: 90,  damage: 50, fireRate: 900 },
      { cost: 200, range: 100, damage: 80, fireRate: 800 },
    ],
  },
  frost: {
    cost: 80, range: 90, damage: 5, fireRate: 600,
    color: '#0ff', targeting: 'first', slow: 1500,
    upgrades: [
      { cost: 100, range: 100, damage: 8,  fireRate: 550 },
      { cost: 180, range: 120, damage: 15, fireRate: 450 },
    ],
  },
};
```

### Projectile 实体骨架

```javascript
class Projectile {
  constructor(x, y, target, config) {
    this.x = x; this.y = y;
    this.target = target;
    this.damage = config.damage;
    this.speed = config.speed;
    this.splash = config.splash || 0;
    this.slow = config.slow || 0;
    this.active = true;
  }

  update(dt, enemies) {
    if (!this.target || !this.target.active) {
      this.active = false;
      return;
    }
    const dx = this.target.x - this.x;
    const dy = this.target.y - this.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 8) {
      // 命中
      this._hit(enemies);
      this.active = false;
      return;
    }
    this.x += (dx / dist) * this.speed * dt / 1000;
    this.y += (dy / dist) * this.speed * dt / 1000;
  }

  _hit(enemies) {
    if (this.splash > 0) {
      // 范围伤害
      for (const e of enemies) {
        if (!e.active) continue;
        const d = Math.hypot(e.x - this.target.x, e.y - this.target.y);
        if (d <= this.splash) e.takeDamage(this.damage);
      }
    } else {
      this.target.takeDamage(this.damage);
    }
    if (this.slow > 0) this.target.applySlow(this.slow);
  }
}
```

### Economy 实体骨架

```javascript
class Economy {
  constructor(startGold) {
    this.gold = startGold;
  }
  canAfford(cost) { return this.gold >= cost; }
  spend(cost) { this.gold -= cost; }
  reward(amount) { this.gold += amount; }
}
```

---

## 核心算法

### 1. 路径插值移动

见上方 `Path` 类实现。敌人通过 `pathProgress`（0~1）沿路径移动，`getPositionAt(progress)` 返回插值坐标。

### 2. A* 寻路（可选，用于可变路径塔防）

```javascript
// 简化版 A*（网格寻路）
function findPath(grid, start, end) {
  const open = [{ ...start, g: 0, h: heuristic(start, end), parent: null }];
  const closed = new Set();
  const key = (n) => `${n.x},${n.y}`;

  while (open.length > 0) {
    open.sort((a, b) => (a.g + a.h) - (b.g + b.h));
    const current = open.shift();
    if (current.x === end.x && current.y === end.y) {
      return reconstructPath(current);
    }
    closed.add(key(current));
    for (const neighbor of getNeighbors(grid, current)) {
      if (closed.has(key(neighbor))) continue;
      const g = current.g + 1;
      const existing = open.find(n => n.x === neighbor.x && n.y === neighbor.y);
      if (!existing || g < existing.g) {
        if (existing) {
          existing.g = g; existing.parent = current;
        } else {
          open.push({ ...neighbor, g, h: heuristic(neighbor, end), parent: current });
        }
      }
    }
  }
  return null;
}

function heuristic(a, b) { return Math.abs(a.x - b.x) + Math.abs(a.y - b.y); }
function getNeighbors(grid, node) {
  const dirs = [[0,1],[0,-1],[1,0],[-1,0]];
  const result = [];
  for (const [dx, dy] of dirs) {
    const nx = node.x + dx, ny = node.y + dy;
    if (grid[ny] && grid[ny][nx] === 0) result.push({ x: nx, y: ny });
  }
  return result;
}
```

> **何时用 A***：固定路径塔防用 `Path` 即可；允许玩家改变地形/塔阻挡路径时需用 A*。

### 3. 塔目标选择策略

| 策略 | 选择对象 | 适用场景 |
|------|---------|---------|
| `first` | 路径进度最高（最前方） | 默认，优先击杀快到终点的敌人 |
| `last` | 路径进度最低（最后方） | 在入口集火 |
| `strong` | 血量最高 | 对付 Boss/装甲敌人 |
| `weak` | 血量最低 | 补刀残血敌人 |

### 4. 塔升级系统

见 `TOWER_TYPES` 配置。每次升级提升 range/damage/fireRate，消耗金币递增。最多 3-4 级。

### 5. 经济系统

```javascript
// 击杀敌人时
enemy.onDeath = () => {
  economy.reward(enemy.reward);
  // 击杀特效 + 音效
};

// 敌人到达终点时
enemy.onReachEnd = () => {
  playerLives--;
  if (playerLives <= 0) sceneManager.switch('gameover');
};

// 放置塔时
function placeTower(type, x, y) {
  const cost = TOWER_TYPES[type].cost;
  if (!economy.canAfford(cost)) return false;
  economy.spend(cost);
  towers.push(new Tower(type, x, y));
  return true;
}

// 升级塔
function upgradeTower(tower) {
  const cost = tower.getUpgradeCost();
  if (!cost || !economy.canAfford(cost)) return false;
  economy.spend(cost);
  tower.upgrade();
  return true;
}

// 出售塔
function sellTower(tower) {
  economy.reward(tower.getSellValue());
  towers.splice(towers.indexOf(tower), 1);
}
```

---

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 标题、开始按钮 |
| GameScene | 地图 + 塔放置 UI + 波次进度条 + 金币显示 |
| GameOverScene | 胜利/失败、波数、重新开始 |

GameScene 额外 UI 状态：
- **空闲**：无选中，点击空地弹出塔选择菜单
- **放置预览**：跟随鼠标显示塔范围圈
- **选中塔**：显示升级/出售按钮 + 范围圈

---

## config.js 参数建议

```javascript
const CONFIG = {
  gameName: 'TowerDefense',
  version: '1.0.0',
  canvas: { width: 750, height: 1334, designRatio: 750 / 1334 },
  map: {
    gridCols: 15, gridRows: 20, cellSize: 44,
    // 路径节点（网格坐标转像素）
    pathNodes: [
      { x: -1, y: 2 }, { x: 7, y: 2 }, { x: 7, y: 8 },
      { x: 3, y: 8 }, { x: 3, y: 14 }, { x: 12, y: 14 },
      { x: 12, y: 6 }, { x: 16, y: 6 },
    ],
  },
  towers: TOWER_TYPES,  // 见上方定义
  enemies: ENEMY_TYPES, // 见上方定义
  economy: { startGold: 200, startLives: 20 },
  waves: [
    { enemies: [{ type: 'normal', count: 10, interval: 1000 }] },
    { enemies: [{ type: 'normal', count: 15, interval: 800 }] },
    { enemies: [{ type: 'fast', count: 10, interval: 500 }] },
    { enemies: [{ type: 'normal', count: 15, interval: 600 }, { type: 'armored', count: 3, interval: 2000 }] },
    { enemies: [{ type: 'boss', count: 1 }] },
  ],
  colors: {
    background: '#1a1a2e',
    grid: '#16213e',
    path: '#e94560',
    placeable: '#0f3460',
    ui: '#16213e',
    text: '#fff',
  },
  audio: {
    bgm: 'assets/audio/bgm.mp3',
    shoot: 'assets/audio/sfx_shoot.mp3',
    place: 'assets/audio/sfx_place.mp3',
    upgrade: 'assets/audio/sfx_upgrade.mp3',
    enemyDeath: 'assets/audio/sfx_death.mp3',
    lifeLost: 'assets/audio/sfx_life.mp3',
  },
};
```

---

## 输入映射

| 操作 | 效果 |
|------|------|
| 点击空地 | 弹出塔选择菜单 |
| 选择塔类型 | 进入放置预览（跟随手指） |
| 确认放置 | 消耗金币放置塔 |
| 点击已有塔 | 显示升级/出售菜单 |
| 点击升级 | 消耗金币升级塔 |
| 点击出售 | 回收 70% 金币 |

---

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 塔精灵 | 可用几何图形+颜色区分类型 | 可选 |
| 敌人精灵 | 可用圆形/方形+颜色区分类型 | 可选 |
| 地图背景 | 可用程序化网格绘制 | 可选 |
| 射击音效 | `sfx_shoot.mp3` | 推荐 |
| 建塔音效 | `sfx_place.mp3` | 推荐 |
| 升级音效 | `sfx_upgrade.mp3` | 推荐 |
| 敌人死亡 | `sfx_death.mp3` | 推荐 |
| BGM | `bgm.mp3` | 推荐 |

---

## 预估包体

- 纯 Canvas 绘制：**< 60KB**
- 含精灵图和音效：**< 400KB**
- 远低于 4MB 限制

---

## 渲染要点

```javascript
render(ctx) {
  // 1. 地图背景（离屏 Canvas 预渲染）
  ctx.fillStyle = CONFIG.colors.background;
  ctx.fillRect(0, 0, canvasW, canvasH);
  drawGrid(ctx);

  // 2. 路径（粗线条）
  ctx.strokeStyle = CONFIG.colors.path;
  ctx.lineWidth = 30;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(path.nodes[0].x, path.nodes[0].y);
  for (let i = 1; i < path.nodes.length; i++) ctx.lineTo(path.nodes[i].x, path.nodes[i].y);
  ctx.stroke();

  // 3. 可放置区域（半透明）
  ctx.fillStyle = CONFIG.colors.placeable + '40';
  for (const cell of placeableCells) ctx.fillRect(cell.x, cell.y, cellSize, cellSize);

  // 4. 塔
  for (const tower of towers) {
    ctx.fillStyle = tower.color;
    ctx.fillRect(tower.x - 15, tower.y - 15, 30, 30);
    // 等级标记
    ctx.fillStyle = '#fff';
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(tower.level, tower.x, tower.y + 5);
  }

  // 5. 选中塔的范围圈
  if (selectedTower) {
    ctx.strokeStyle = selectedTower.color + '80';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(selectedTower.x, selectedTower.y, selectedTower.range, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 6. 敌人
  for (const e of enemies) {
    if (!e.active) continue;
    ctx.fillStyle = e.color;
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.size/2, 0, Math.PI * 2);
    ctx.fill();
    // 血条
    const barW = e.size; const barH = 4;
    ctx.fillStyle = '#333';
    ctx.fillRect(e.x - barW/2, e.y - e.size/2 - 8, barW, barH);
    ctx.fillStyle = '#0f0';
    ctx.fillRect(e.x - barW/2, e.y - e.size/2 - 8, barW * (e.hp / e.maxHp), barH);
  }

  // 7. 弹道
  for (const p of projectiles) {
    if (!p.active) continue;
    ctx.fillStyle = '#ff0';
    ctx.fillRect(p.x - 3, p.y - 3, 6, 6);
  }

  // 8. HUD
  ctx.fillStyle = CONFIG.colors.ui;
  ctx.fillRect(0, 0, canvasW, 50);
  ctx.fillStyle = '#fff';
  ctx.font = '20px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(`💰 ${economy.gold}`, 10, 32);
  ctx.fillText(`❤️ ${playerLives}`, 150, 32);
  ctx.fillText(`波次 ${currentWave}/${totalWaves}`, 280, 32);
}
```

---

## 包体优化指引

| 优化方向 | 具体做法 | 效果 |
|---------|---------|------|
| 程序化地图 | 网格+路径用 Canvas 绘制代替图片 | 省去地图资源 |
| 几何角色 | 塔=矩形+等级数字，敌人=圆形+颜色 | 零图片资源 |
| 数据驱动波次 | 波次配置用 JSON（可放分包按需加载） | 主包更小 |
| 音效压缩 | SFX 压缩为低码率 MP3 | 每个音效 < 50KB |
| BGM 分包 | BGM 放分包或 CDN | 主包减至 < 100KB |
