# H5 包体标准小游戏 — 完整规范

## 1. 包体大小限制

| 限制项 | 上限 | 说明 |
|--------|------|------|
| **主包** | **≤ 4 MB** (4,194,304 字节) | 首次启动必须下载的包，超限无法上传 |
| **整包（主包+所有分包）** | **≤ 30 MB** (31,457,280 字节) | 所有代码包总和 |
| **单个独立分包** | ≤ 4 MB | 可独立于主包运行 |
| **单个普通分包** | 无独立限制 | 受整包 30MB 约束 |

### 1.1 主包构成

主包包含**首次启动必须的文件**：

- `index.html` — 入口页面
- `game.js` — 程序入口
- `game.json` — 全局配置
- `config.js` — 游戏参数
- `js/core/` — 核心引擎
- `js/scenes/` — 首屏场景（菜单 + 游戏场景）
- `js/entities/` — 游戏实体
- `js/utils/` — 工具函数
- `assets/` — 首屏必需资源
- `styles/` — 样式

### 1.2 分包构成

分包包含**非首屏必需的内容**：

- 额外关卡/场景
- 非首屏资源（大图、动画、音效）
- 可延迟加载的功能模块

---

## 2. 文件类型白名单

共 **69 种**允许的文件类型。完整列表见 [`file-whitelist.md`](./file-whitelist.md)。

**关键规则**：
- `*.js` 和 `game.json` 会被编译，上传后无法直接访问
- 不在白名单内的文件在开发工具中可访问，但**无法上传**
- `.ts` / `.scss` / `.less` 等需编译为白名单类型（`.js` / `.css`）

---

## 3. 技术栈要求

| 维度 | 要求 | 禁止 |
|------|------|------|
| **渲染** | Canvas 2D / WebGL | — |
| **语言** | JavaScript (ES6+) | TypeScript（需编译） |
| **音频** | Web Audio API / HTMLAudioElement | — |
| **输入** | TouchEvent / MouseEvent / KeyboardEvent | — |
| **引擎** | 原生实现，无引擎依赖 | Cocos / Laya / Phaser / PixiJS 等 |
| **框架** | 原生 DOM / Canvas API | React / Vue / Angular |

### 为什么不用引擎？

- **包体控制**：引擎代码本身就占数 MB（Cocos runtime ~1.5MB, Phaser ~1MB），严重挤占 4MB 主包空间
- **加载速度**：无引擎依赖，首屏更快
- **H5 小游戏定位**：轻量休闲游戏，原生 Canvas 完全够用

---

## 4. 性能要求

| 指标 | 目标值 | 说明 |
|------|--------|------|
| **FPS 均值** | 50-60 fps | 低于 30fps 产生明显卡顿 |
| **Draw Call** | ≤ 100 次/帧 | Canvas 绘制调用次数 |
| **首屏时间** | ≤ 1.5s | 用户点击到首屏渲染完成 |
| **内存峰值** | 依机型而定 | 避免内存泄漏，注意对象回收 |
| **可交互时间** | 尽量短 | 核心玩法可交互的时机 |

---

## 5. 标准目录结构

```
<game-name>/
├── index.html              # H5 入口页面
├── game.js                 # 程序入口
├── game.json               # 全局配置
├── config.js               # 游戏参数配置
├── styles/
│   └── main.css            # 基础样式
├── js/
│   ├── core/
│   │   ├── GameLoop.js     # 游戏循环
│   │   ├── InputHandler.js # 输入处理
│   │   └── Renderer.js     # 渲染封装
│   ├── scenes/
│   │   ├── Scene.js        # 场景基类
│   │   ├── MenuScene.js    # 菜单场景
│   │   ├── GameScene.js    # 游戏场景
│   │   └── GameOverScene.js# 结算场景
│   ├── entities/
│   │   └── ...             # 游戏实体
│   └── utils/
│       ├── EventEmitter.js # 事件系统
│       └── AssetLoader.js  # 资源加载器
├── assets/
│   ├── images/             # 图片资源
│   └── audio/              # 音频资源
└── subpackages/            # 分包目录
    └── ...
```

---

## 6. 分包策略

### 6.1 何时使用分包

- 主包超过 4MB 时**必须**拆分
- 非首屏内容（额外关卡、教程、设置页）推荐拆分
- 大资源文件（音效、动画序列帧）推荐拆分

### 6.2 分包原则

```
主包（≤4MB）              分包（≤30MB 总计）
─────────────             ──────────────
入口文件                   额外关卡
首屏场景                   非首屏资源
核心引擎                   可延迟模块
首屏必需资源               大型音效/动画
```

### 6.3 分包加载示例

```javascript
// 按需加载分包
function loadLevel(levelName) {
  const script = document.createElement('script');
  script.src = `subpackages/${levelName}/level.js`;
  script.onload = () => {
    // 分包加载完成，初始化关卡
    LevelManager.init(levelName);
  };
  document.head.appendChild(script);
}
```

---

## 7. CDN 远程加载

当整包超过 30MB 时，大资源走 CDN：

```javascript
// 远程资源加载
const CDN_BASE = 'https://cdn.example.com/game-assets/';

function loadRemoteImage(name) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = CDN_BASE + name;
  });
}

// 批量预加载
async function preloadAssets(manifest) {
  const images = await Promise.all(
    manifest.images.map(name => loadRemoteImage(name))
  );
  return images;
}
```

### CDN 资源管理原则

| 资源类型 | 存放位置 | 加载时机 |
|---------|---------|---------|
| 首屏必需图片 | 主包 `assets/images/` | 启动时预加载 |
| 关卡背景图 | CDN | 进入关卡时加载 |
| BGM 音乐 | CDN | 场景切换时加载 |
| 短音效 | 主包 `assets/audio/` | 预加载到内存 |
| 动画序列帧 | CDN 或分包 | 按需加载 |

---

## 8. 上线前检查清单

- [ ] 主包 ≤ 4MB
- [ ] 整包 ≤ 30MB
- [ ] 所有文件类型在白名单内
- [ ] game.json 配置正确（名称、版本、屏幕方向）
- [ ] FPS 稳定 50-60
- [ ] 首屏渲染 ≤ 1.5s
- [ ] Touch 事件正常响应
- [ ] 竖屏/横屏适配正确
- [ ] 无内存泄漏（长时间运行不崩溃）
- [ ] `validate.sh` 全部通过
