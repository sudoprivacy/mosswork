# 打砖块 (Breakout) — 模板参考

## 游戏概述

经典打砖块：控制底部挡板反弹球，击碎上方所有砖块，球掉落则失去一条命。

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Paddle` | `js/entities/Paddle.js` | 挡板位置、移动、边界约束 |
| `Ball` | `js/entities/Ball.js` | 球位置、速度、碰撞反弹 |
| `Brick` | `js/entities/Brick.js` | 砖块位置、血量、颜色 |
| `PowerUp` | `js/entities/PowerUp.js` | 道具（可选：多球、加宽挡板等） |

### Paddle 实体骨架

```javascript
class Paddle {
  constructor(config) {
    this.width = config.paddleWidth;
    this.height = 12;
    this.x = (config.canvasWidth - this.width) / 2;
    this.y = config.canvasHeight - 40;
    this.speed = config.paddleSpeed;
    this.config = config;
  }

  move(direction, dt) {
    this.x += direction * this.speed * dt / 1000;
    // 边界约束
    this.x = Math.max(0, Math.min(this.x, this.config.canvasWidth - this.width));
  }

  // 根据球击中挡板的位置改变反弹角度
  getReflectAngle(ballX) {
    const hitPos = (ballX - this.x) / this.width;  // 0~1
    const angle = (hitPos - 0.5) * Math.PI * 0.6;  // -54°~+54°
    return angle;
  }
}
```

### Ball 实体骨架

```javascript
class Ball {
  constructor(config) {
    this.radius = 8;
    this.x = config.canvasWidth / 2;
    this.y = config.canvasHeight / 2;
    this.speed = config.ballSpeed;
    this.vx = this.speed * 0.707;  // 45度
    this.vy = -this.speed * 0.707;
    this.attached = true;  // 开局吸附在挡板上
  }

  update(dt) {
    if (this.attached) return;
    this.x += this.vx * dt / 1000;
    this.y += this.vy * dt / 1000;
  }

  // 墙壁碰撞
  checkWallCollision(width, height) {
    if (this.x - this.radius < 0) {
      this.x = this.radius;
      this.vx = Math.abs(this.vx);
    }
    if (this.x + this.radius > width) {
      this.x = width - this.radius;
      this.vx = -Math.abs(this.vx);
    }
    if (this.y - this.radius < 0) {
      this.y = this.radius;
      this.vy = Math.abs(this.vy);
    }
  }

  // 挡板碰撞
  checkPaddleCollision(paddle) {
    if (this.vy > 0 &&  // 只在下落时检测
        this.y + this.radius >= paddle.y &&
        this.y + this.radius <= paddle.y + paddle.height &&
        this.x >= paddle.x &&
        this.x <= paddle.x + paddle.width) {
      const angle = paddle.getReflectAngle(this.x);
      this.vx = this.speed * Math.sin(angle);
      this.vy = -this.speed * Math.cos(angle);
      this.y = paddle.y - this.radius;
      return true;
    }
    return false;
  }

  // 砖块碰撞（AABB vs Circle）
  checkBrickCollision(brick) {
    const closestX = Math.max(brick.x, Math.min(this.x, brick.x + brick.width));
    const closestY = Math.max(brick.y, Math.min(this.y, brick.y + brick.height));
    const dx = this.x - closestX;
    const dy = this.y - closestY;
    if (dx * dx + dy * dy < this.radius * this.radius) {
      // 判断从哪个方向碰撞，决定反弹方向
      if (Math.abs(dx) > Math.abs(dy)) {
        this.vx = -this.vx;
      } else {
        this.vy = -this.vy;
      }
      return true;
    }
    return false;
  }
}
```

### Brick 实体骨架

```javascript
class Brick {
  constructor(x, y, width, height, hp, color) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.hp = hp;
    this.maxHp = hp;
    this.color = color;
    this.alive = true;
  }

  hit() {
    this.hp--;
    if (this.hp <= 0) this.alive = false;
  }
}
```

## 核心算法

### 砖块布局生成

```javascript
function createBricks(config) {
  const bricks = [];
  const rows = config.brickRows;
  const cols = config.brickCols;
  const padding = 4;
  const totalWidth = config.canvasWidth - 40;
  const brickW = (totalWidth - (cols - 1) * padding) / cols;
  const brickH = 20;
  const offsetX = 20;
  const offsetY = 60;

  const colors = ['#f00', '#f80', '#ff0', '#0f0', '#00f'];

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const hp = Math.max(1, Math.floor((rows - r) / 2));
      bricks.push(new Brick(
        offsetX + c * (brickW + padding),
        offsetY + r * (brickH + padding),
        brickW, brickH, hp, colors[r % colors.length]
      ));
    }
  }
  return bricks;
}
```

### 碰撞检测优化

```javascript
// 遍历所有砖块检测碰撞
update(dt) {
  ball.update(dt);
  ball.checkWallCollision(width, height);

  if (ball.checkPaddleCollision(paddle)) {
    playSound('paddle');
  }

  for (const brick of bricks) {
    if (!brick.alive) continue;
    if (ball.checkBrickCollision(brick)) {
      brick.hit();
      this.score += 10;
      playSound('brick');
      break;  // 一帧只碰一个砖块（避免穿墙）
    }
  }

  // 球掉落
  if (ball.y - ball.radius > height) {
    this.lives--;
    if (this.lives <= 0) {
      this.sceneManager.switch('gameover');
    } else {
      ball.reset();
    }
  }

  // 胜利检测
  if (bricks.every(b => !b.alive)) {
    this.sceneManager.switch('gameover');  // 或下一关
  }
}
```

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 标题、开始按钮 |
| GameScene | 挡板、球、砖块、分数、生命 |
| GameOverScene | 胜利/失败、最终分数、重新开始 |

## config.js 参数建议

```javascript
const CONFIG = {
  canvas: { width: 750, height: 1334 },
  gameplay: {
    paddleWidth: 120,
    paddleSpeed: 500,   // px/s
    ballSpeed: 350,     // px/s
    ballRadius: 8,
    brickRows: 6,
    brickCols: 8,
    initialLives: 3,
  },
  colors: {
    background: '#0a0a23',
    paddle: '#0ff',
    ball: '#fff',
    bricks: ['#f00', '#f80', '#ff0', '#0f0', '#00f', '#a0f'],
  },
};
```

## 输入映射

| 操作 | 效果 |
|------|------|
| ← / A | 挡板左移 |
| → / D | 挡板右移 |
| 鼠标移动 | 挡板跟随鼠标 X |
| 触摸移动 | 挡板跟随触摸 X |
| 空格 / 点击 | 发射球（脱离挡板） |

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 砖块图片 | 可用纯色矩形代替 | 可选 |
| 挡板图片 | 可用纯色圆角矩形代替 | 可选 |
| 球图片 | 可用纯色圆形代替 | 可选 |
| 反弹音效 | `bounce.mp3` | 推荐 |
| 破砖音效 | `break.mp3` | 推荐 |
| 失败音效 | `lose.mp3` | 可选 |

## 预估包体

- 纯 Canvas 绘制：**< 35KB**
- 含音效：**< 120KB**

## 渲染要点

```javascript
render(ctx) {
  // 背景
  ctx.fillStyle = CONFIG.colors.background;
  ctx.fillRect(0, 0, width, height);

  // 砖块（按颜色批量绘制）
  const colorGroups = {};
  for (const brick of bricks) {
    if (!brick.alive) continue;
    const c = brick.color;
    if (!colorGroups[c]) colorGroups[c] = [];
    colorGroups[c].push(brick);
  }
  for (const [color, group] of Object.entries(colorGroups)) {
    ctx.fillStyle = color;
    for (const b of group) {
      ctx.fillRect(b.x, b.y, b.width, b.height);
    }
  }

  // 挡板（圆角矩形）
  ctx.fillStyle = CONFIG.colors.paddle;
  roundRect(ctx, paddle.x, paddle.y, paddle.width, paddle.height, 6);
  ctx.fill();

  // 球
  ctx.fillStyle = CONFIG.colors.ball;
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fill();
}
```
