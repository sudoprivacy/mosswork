# 2048 — 模板参考

## 游戏概述

经典 2048：在 4x4 网格上滑动数字方块，相同数字合并，目标是合成 2048。

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Board` | `js/entities/Board.js` | 4x4 网格、滑动合并逻辑、生成新方块 |
| `Tile` | `js/entities/Tile.js` | 单个方块（值、位置、动画状态） |

### Board 实体骨架

```javascript
class Board {
  constructor(size = 4) {
    this.size = size;
    this.grid = Array.from({ length: size }, () => Array(size).fill(null));
    this.score = 0;
    this.won = false;
    this.over = false;
    this.spawnTile();
    this.spawnTile();
  }

  spawnTile() {
    const empty = [];
    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        if (!this.grid[r][c]) empty.push({ r, c });
      }
    }
    if (empty.length === 0) return false;
    const { r, c } = empty[Math.floor(Math.random() * empty.length)];
    this.grid[r][c] = {
      value: Math.random() < 0.9 ? 2 : 4,
      r, c,
      isNew: true,
    };
    return true;
  }

  // 核心滑动+合并算法
  move(direction) {
    let moved = false;
    const vectors = {
      up:    { r: -1, c: 0 },
      down:  { r: 1, c: 0 },
      left:  { r: 0, c: -1 },
      right: { r: 0, c: 1 },
    };
    const vec = vectors[direction];

    // 遍历顺序：沿移动方向从远到近
    const rowOrder = vec.r > 0 ? [3,2,1,0] : [0,1,2,3];
    const colOrder = vec.c > 0 ? [3,2,1,0] : [0,1,2,3];

    // 重置合并标记
    for (let r = 0; r < this.size; r++)
      for (let c = 0; c < this.size; c++)
        if (this.grid[r][c]) this.grid[r][c].merged = false;

    for (const r of rowOrder) {
      for (const c of colOrder) {
        const tile = this.grid[r][c];
        if (!tile) continue;

        // 找到最远可移动位置
        let nr = r, nc = c;
        while (true) {
          const tr = nr + vec.r;
          const tc = nc + vec.c;
          if (tr < 0 || tr >= this.size || tc < 0 || tc >= this.size) break;
          const target = this.grid[tr][tc];
          if (!target) {
            nr = tr; nc = tc;  // 继续滑
          } else if (target.value === tile.value && !target.merged) {
            // 合并
            this.grid[tr][tc] = { value: tile.value * 2, r: tr, c: tc, merged: true, isNew: false };
            this.grid[r][c] = null;
            this.score += tile.value * 2;
            if (tile.value * 2 === 2048) this.won = true;
            moved = true;
            break;
          } else {
            break;  // 被挡住
          }
        }

        // 未合并但有移动
        if (this.grid[r][c] && (nr !== r || nc !== c)) {
          this.grid[nr][nc] = tile;
          tile.r = nr; tile.c = nc;
          this.grid[r][c] = null;
          moved = true;
        }
      }
    }

    if (moved) {
      this.spawnTile();
      this.checkGameOver();
    }
    return moved;
  }

  checkGameOver() {
    // 有空位则未结束
    for (let r = 0; r < this.size; r++)
      for (let c = 0; c < this.size; c++)
        if (!this.grid[r][c]) return;

    // 检查是否还有可合并的相邻方块
    for (let r = 0; r < this.size; r++) {
      for (let c = 0; c < this.size; c++) {
        const v = this.grid[r][c].value;
        if (r + 1 < this.size && this.grid[r+1][c]?.value === v) return;
        if (c + 1 < this.size && this.grid[r][c+1]?.value === v) return;
      }
    }
    this.over = true;
  }
}
```

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 标题、开始、最高分 |
| GameScene | 4x4 网格、分数、滑动操作 |
| GameOverScene | 最终分数、重新开始 |

## 核心算法

### 滑动方向检测

```javascript
// 触屏滑动
let touchStart = null;
input.on('down', (pos) => { touchStart = pos; });
input.on('up', (pos) => {
  if (!touchStart) return;
  const dx = pos.x - touchStart.x;
  const dy = pos.y - touchStart.y;
  const absDx = Math.abs(dx);
  const absDy = Math.abs(dy);
  const threshold = 30;

  if (Math.max(absDx, absDy) < threshold) return;  // 距离太短忽略

  if (absDx > absDy) {
    board.move(dx > 0 ? 'right' : 'left');
  } else {
    board.move(dy > 0 ? 'down' : 'up');
  }
  touchStart = null;
});

// 键盘
window.addEventListener('keydown', (e) => {
  const map = {
    ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
    w: 'up', s: 'down', a: 'left', d: 'right',
  };
  if (map[e.key]) board.move(map[e.key]);
});
```

### 方块颜色映射

```javascript
const TILE_COLORS = {
  2:    { bg: '#eee4da', fg: '#776e65' },
  4:    { bg: '#ede0c8', fg: '#776e65' },
  8:    { bg: '#f2b179', fg: '#f9f6f2' },
  16:   { bg: '#f59563', fg: '#f9f6f2' },
  32:   { bg: '#f67c5f', fg: '#f9f6f2' },
  64:   { bg: '#f65e3b', fg: '#f9f6f2' },
  128:  { bg: '#edcf72', fg: '#f9f6f2' },
  256:  { bg: '#edcc61', fg: '#f9f6f2' },
  512:  { bg: '#edc850', fg: '#f9f6f2' },
  1024: { bg: '#edc53f', fg: '#f9f6f2' },
  2048: { bg: '#edc22e', fg: '#f9f6f2' },
};
```

## config.js 参数建议

```javascript
const CONFIG = {
  gameplay: {
    gridSize: 4,           // 4x4
    cellSize: 80,          // 每格像素
    cellGap: 12,           // 间距
    spawnValues: [2, 4],   // 生成值
    spawnProb: 0.9,        // 生成 2 的概率
    winValue: 2048,        // 胜利条件
  },
  layout: {
    boardPadding: 16,
    boardBg: '#bbada0',
    cellBg: '#cdc1b4',
    emptyCellBg: 'rgba(238, 228, 218, 0.35)',
  },
  animation: {
    moveDuration: 150,     // 滑动动画时长(ms)
    spawnDuration: 200,    // 出现动画时长(ms)
    mergeDuration: 200,    // 合并动画时长(ms)
  },
};
```

## 输入映射

| 操作 | 效果 |
|------|------|
| ↑ / W | 上滑 |
| ↓ / S | 下滑 |
| ← / A | 左滑 |
| → / D | 右滑 |
| 触屏滑动 | 对应方向 |

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 无 | 纯 Canvas 绘制数字方块 | — |
| 合并音效 | `merge.mp3` | 可选 |

## 预估包体

- 纯 Canvas 绘制：**< 25KB**（最小的游戏之一）
- 含音效：**< 80KB**

## 渲染要点

```javascript
render(ctx) {
  const { gridSize, cellSize, cellGap, boardPadding } = CONFIG.layout;
  const boardSize = gridSize * cellSize + (gridSize + 1) * cellGap;

  // 棋盘背景
  ctx.fillStyle = CONFIG.layout.boardBg;
  roundRect(ctx, 0, 0, boardSize, boardSize, 8);
  ctx.fill();

  // 空格子背景
  ctx.fillStyle = CONFIG.layout.cellBg;
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      const x = boardPadding + c * (cellSize + cellGap);
      const y = boardPadding + r * (cellSize + cellGap);
      roundRect(ctx, x, y, cellSize, cellSize, 6);
      ctx.fill();
    }
  }

  // 方块
  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      const tile = board.grid[r][c];
      if (!tile) continue;
      const colors = TILE_COLORS[tile.value] || TILE_COLORS[2048];
      const x = boardPadding + c * (cellSize + cellGap);
      const y = boardPadding + r * (cellSize + cellGap);

      ctx.fillStyle = colors.bg;
      roundRect(ctx, x, y, cellSize, cellSize, 6);
      ctx.fill();

      // 数字
      ctx.fillStyle = colors.fg;
      ctx.font = `${tile.value > 100 ? 28 : 36}px bold Arial`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(tile.value, x + cellSize / 2, y + cellSize / 2);
    }
  }
}
```

## 动画建议

2048 的体验很依赖滑动动画：

1. **滑动动画**：方块从原位置平滑移动到目标位置（150ms）
2. **合并动画**：合并后方块缩放弹跳（200ms）
3. **生成动画**：新方块从 0 缩放到 1（200ms）

实现方式：给每个 Tile 添加 `displayX/Y` 和 `displayScale`，每帧用 lerp 插值到目标值。
