# 音效与振动反馈模块

> 本模块提供 Web Audio API 封装、多音效混播、BGM 淡入淡出、振动 API 的实现模式，适用于所有需要音频和触觉反馈的游戏类型。

---

## 1. AudioManager 核心封装

### 1.1 设计要点

- **延迟初始化**：浏览器策略要求用户交互后才能创建/恢复 AudioContext
- **音频缓存**：启动时 `fetch + decodeAudioData` 预加载到 `AudioBuffer`
- **分类管理**：BGM 和 SFX 分开管理，独立音量控制

### 1.2 完整实现

```javascript
// js/utils/AudioManager.js
class AudioManager {
  constructor() {
    this.ctx = null;
    this.buffers = {};           // 音频缓存 { src: AudioBuffer }
    this.currentBGM = null;      // { source, gain }
    this.masterGain = null;
    this.categoryVolume = { bgm: 0.5, sfx: 0.8 };
    this.maxConcurrent = { bgm: 1, sfx: 8 };
    this.activeSources = { bgm: [], sfx: [] };
    this.muted = false;
    this.initialized = false;
  }

  // 必须在用户首次交互后调用
  init() {
    if (this.initialized) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 1;
    this.masterGain.connect(this.ctx.destination);
    this.initialized = true;
  }

  // 恢复挂起的 AudioContext（iOS 需要每次交互后 resume）
  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // 预加载音频
  async preload(src) {
    if (this.buffers[src]) return;
    try {
      const response = await fetch(src);
      const arrayBuffer = await response.arrayBuffer();
      this.buffers[src] = await this.ctx.decodeAudioData(arrayBuffer);
    } catch (e) {
      console.warn(`音频加载失败: ${src}`, e);
    }
  }

  // 批量预加载
  async preloadAll(manifest) {
    const all = Object.values(manifest).map(src => this.preload(src));
    await Promise.all(all);
  }
}

// 全局单例
const audioManager = new AudioManager();
```

### 1.3 初始化时机

```javascript
// 首次用户交互时初始化（点击/触摸/按键）
function setupAudioInit() {
  const initOnce = () => {
    audioManager.init();
    audioManager.resume();
    // 预加载所有音频
    audioManager.preloadAll(CONFIG.audio);
    // 移除监听器（只需初始化一次）
    document.removeEventListener('touchstart', initOnce);
    document.removeEventListener('mousedown', initOnce);
    document.removeEventListener('keydown', initOnce);
  };
  document.addEventListener('touchstart', initOnce, { once: true });
  document.addEventListener('mousedown', initOnce, { once: true });
  document.addEventListener('keydown', initOnce, { once: true });
}
```

---

## 2. 音效播放（SFX）

### 2.1 单次播放

```javascript
playSFX(src, options = {}) {
  if (!this.initialized || this.muted) return;
  const buffer = this.buffers[src];
  if (!buffer) return;

  const { volume = 1, category = 'sfx' } = options;

  // 并发数控制
  if (this.activeSources[category].length >= this.maxConcurrent[category]) {
    this._stopOldest(category);
  }

  const source = this.ctx.createBufferSource();
  const gain = this.ctx.createGain();
  gain.gain.value = volume * this.categoryVolume[category];

  source.buffer = buffer;
  source.loop = false;
  source.connect(gain);
  gain.connect(this.masterGain);
  source.start(0);

  // 跟踪活跃源，播放结束后自动清理
  const entry = { source, gain, category };
  this.activeSources[category].push(entry);
  source.onended = () => {
    const idx = this.activeSources[category].indexOf(entry);
    if (idx >= 0) this.activeSources[category].splice(idx, 1);
  };
}
```

### 2.2 并发数控制

| 音效类型 | 最大并发 | 原因 |
|---------|---------|------|
| 射击音效 | 5 | 连续射击时避免叠加爆音 |
| 爆炸音效 | 8 | 多敌机同时爆炸 |
| UI 音效 | 2 | 按钮点击不需要太多 |
| 脚步声 | 3 | 避免连续叠加 |

```javascript
_stopOldest(category) {
  const list = this.activeSources[category];
  if (list.length === 0) return;
  const oldest = list[0];
  try { oldest.source.stop(); } catch (e) {}
  list.shift();
}
```

### 2.3 音效优先级

```javascript
playSFX(src, { volume = 1, priority = 'normal' }) {
  if (priority === 'critical') {
    // 关键音效：强制播放，停止最早的次要音效腾出通道
    if (this.activeSources.sfx.length >= this.maxConcurrent.sfx) {
      this._stopOldest('sfx');
    }
  } else {
    // 次要音效：通道满则丢弃
    if (this.activeSources.sfx.length >= this.maxConcurrent.sfx) return;
  }
  // ... 播放逻辑
}
```

---

## 3. BGM 管理

### 3.1 播放与淡入

```javascript
playBGM(src, fadeDuration = 1000) {
  if (!this.initialized) return;
  const buffer = this.buffers[src];
  if (!buffer) return;

  // 淡出当前 BGM
  if (this.currentBGM) {
    this._fadeOut(this.currentBGM, fadeDuration, () => {
      try { this.currentBGM?.source.stop(); } catch(e) {}
    });
  }

  // 淡入新 BGM
  const source = this.ctx.createBufferSource();
  const gain = this.ctx.createGain();
  const now = this.ctx.currentTime;

  gain.gain.setValueAtTime(0, now);
  gain.gain.linearRampToValueAtTime(
    this.categoryVolume.bgm, now + fadeDuration / 1000
  );

  source.buffer = buffer;
  source.loop = true;
  source.connect(gain);
  gain.connect(this.masterGain);
  source.start(0);

  this.currentBGM = { source, gain, src };
}
```

### 3.2 淡出与停止

```javascript
_fadeOut(bgm, duration, callback) {
  if (!bgm) return;
  const now = this.ctx.currentTime;
  bgm.gain.gain.cancelScheduledValues(now);
  bgm.gain.gain.setValueAtTime(bgm.gain.gain.value, now);
  bgm.gain.gain.linearRampToValueAtTime(0, now + duration / 1000);
  setTimeout(callback, duration);
}

stopBGM(fadeDuration = 500) {
  if (!this.currentBGM) return;
  this._fadeOut(this.currentBGM, fadeDuration, () => {
    try { this.currentBGM?.source.stop(); } catch(e) {}
    this.currentBGM = null;
  });
}
```

### 3.3 场景 BGM 切换

```javascript
// 场景管理器切换时自动切换 BGM
const SCENE_BGM = {
  menu: 'assets/audio/bgm_menu.mp3',
  game: 'assets/audio/bgm_battle.mp3',
  gameover: 'assets/audio/bgm_gameover.mp3',
};

// 场景切换时
sceneManager.onSwitch = (sceneName) => {
  const bgm = SCENE_BGM[sceneName];
  if (bgm) audioManager.playBGM(bgm, 800);
};
```

---

## 4. 振动反馈

### 4.1 HapticsManager 封装

```javascript
// js/utils/HapticsManager.js
class HapticsManager {
  constructor() {
    this.enabled = true;
    this.supported = 'vibrate' in navigator;
    // 从 localStorage 读取用户偏好
    this.enabled = localStorage.getItem('haptics_enabled') !== 'false';
  }

  vibrate(pattern) {
    if (!this.supported || !this.enabled) return;
    navigator.vibrate(pattern);
  }

  // 预设振动模式
  light()    { this.vibrate(10); }                    // 轻触/子弹命中
  medium()   { this.vibrate(30); }                    // 击中/碰撞
  heavy()    { this.vibrate([50, 30, 50]); }          // 爆炸/重击
  hurt()     { this.vibrate([30, 20, 30, 20, 30]); }  // 受伤
  death()    { this.vibrate([100, 50, 100, 50, 200]); } // 死亡
  success()  { this.vibrate([10, 50, 10, 50, 10]); }  // 胜利
  coin()     { this.vibrate(5); }                     // 收集金币

  toggle() {
    this.enabled = !this.enabled;
    localStorage.setItem('haptics_enabled', String(this.enabled));
  }
}

const haptics = new HapticsManager();
```

### 4.2 振动模式预设表

| 事件 | 模式 | 时长 | 说明 |
|------|------|------|------|
| 轻击/子弹命中 | `10` | 10ms | 短促 |
| 收集金币 | `5` | 5ms | 极短 |
| 重击/碰撞 | `30` | 30ms | 明显 |
| 爆炸 | `[50, 30, 50]` | 130ms | 间歇振动 |
| 受伤 | `[30, 20, 30, 20, 30]` | 130ms | 连续短振 |
| 死亡 | `[100, 50, 100, 50, 200]` | 500ms | 长振动 |
| 胜利 | `[10, 50, 10, 50, 10]` | 130ms | 节奏感 |
| Boss 出场 | `[200, 100, 200]` | 500ms | 沉重 |

### 4.3 兼容性说明

| 平台 | 支持情况 |
|------|---------|
| Android Chrome | ✅ 完全支持 |
| iOS Safari | ⚠️ 不支持 `navigator.vibrate`，需用 AudioContext 生成触觉反馈替代 |
| 微信内置浏览器 | ✅ Android 支持 |

> **iOS 兼容方案**：iOS 不支持振动 API，可省略振动或用低频音效模拟触感。

---

## 5. 音量控制与静音

### 5.1 分类音量

```javascript
class AudioManager {
  // ... 上文代码

  setMasterVolume(volume) {
    if (this.masterGain) {
      this.masterGain.gain.value = this.muted ? 0 : volume;
    }
    this.masterVolume = volume;
  }

  setCategoryVolume(category, volume) {
    this.categoryVolume[category] = volume;
    // 实时更新正在播放的音效
    for (const entry of this.activeSources[category]) {
      entry.gain.gain.value = volume;
    }
    // 更新 BGM
    if (category === 'bgm' && this.currentBGM) {
      this.currentBGM.gain.gain.value = volume;
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    const targetVol = this.muted ? 0 : 1;
    const now = this.ctx.currentTime;
    this.masterGain.gain.linearRampToValueAtTime(targetVol, now + 0.1);
    return this.muted;
  }

  // 持久化设置
  saveSettings() {
    localStorage.setItem('audio_settings', JSON.stringify({
      master: this.masterVolume,
      bgm: this.categoryVolume.bgm,
      sfx: this.categoryVolume.sfx,
      muted: this.muted,
    }));
  }

  loadSettings() {
    const saved = localStorage.getItem('audio_settings');
    if (saved) {
      const s = JSON.parse(saved);
      this.masterVolume = s.master ?? 1;
      this.categoryVolume.bgm = s.bgm ?? 0.5;
      this.categoryVolume.sfx = s.sfx ?? 0.8;
      this.muted = s.muted ?? false;
    }
  }
}
```

### 5.2 音量 UI 推荐方案

在设置场景或暂停菜单中，用 Canvas 绘制滑块：

```javascript
// 画布内音量滑块
function drawVolumeSlider(ctx, x, y, w, h, value, label) {
  // 背景
  ctx.fillStyle = '#333';
  ctx.fillRect(x, y, w, h);
  // 填充
  ctx.fillStyle = '#0f0';
  ctx.fillRect(x, y, w * value, h);
  // 标签
  ctx.fillStyle = '#fff';
  ctx.font = '14px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(label, x, y - 5);
}

// 触摸/点击检测
function handleVolumeTouch(pos, slider) {
  if (pos.x >= slider.x && pos.x <= slider.x + slider.w) {
    const value = (pos.x - slider.x) / slider.w;
    audioManager.setCategoryVolume(slider.category, value);
  }
}
```

---

## 6. 完整使用示例

### 6.1 在 game.js 中初始化

```javascript
// game.js 入口
const audioManager = new AudioManager();
const haptics = new HapticsManager();

// 首次交互时初始化音频
function initAudio() {
  audioManager.init();
  audioManager.loadSettings();
  audioManager.preloadAll(CONFIG.audio).then(() => {
    audioManager.playBGM(CONFIG.audio.bgmMenu, 1000);
  });
}

document.addEventListener('touchstart', initAudio, { once: true });
document.addEventListener('mousedown', initAudio, { once: true });
```

### 6.2 在游戏场景中使用

```javascript
// 射击时
class Player {
  fire() {
    // ... 发射子弹
    audioManager.playSFX(CONFIG.audio.shoot, { volume: 0.3 });
  }
}

// 敌人被击毁时
class Enemy {
  destroy() {
    // 爆炸特效
    createExplosion(particlePool, this.x, this.y, 'small');
    // 音效
    audioManager.playSFX(CONFIG.audio.explosion, { volume: 0.6 });
    // 振动
    haptics.heavy();
  }
}

// 玩家受伤时
class Player {
  takeDamage(amount) {
    this.hp -= amount;
    audioManager.playSFX(CONFIG.audio.hurt, { priority: 'critical' });
    haptics.hurt();
    if (this.hp <= 0) {
      audioManager.playSFX(CONFIG.audio.death);
      haptics.death();
      audioManager.stopBGM(500);
    }
  }
}
```

### 6.3 音频资源配置

```javascript
// config.js 中的音频配置
const CONFIG = {
  audio: {
    // BGM
    bgmMenu:    'assets/audio/bgm_menu.mp3',
    bgmBattle:  'assets/audio/bgm_battle.mp3',
    bgmBoss:    'assets/audio/bgm_boss.mp3',
    bgmGameOver:'assets/audio/bgm_gameover.mp3',
    // SFX
    shoot:      'assets/audio/sfx_shoot.mp3',
    explosion:  'assets/audio/sfx_explosion.mp3',
    hurt:       'assets/audio/sfx_hurt.mp3',
    death:      'assets/audio/sfx_death.mp3',
    powerup:    'assets/audio/sfx_powerup.mp3',
    coin:       'assets/audio/sfx_coin.mp3',
    click:      'assets/audio/sfx_click.mp3',
  },
};
```

---

## 7. 与游戏模板结合总表

| 游戏类型 | SFX 需求 | BGM 需求 | 振动需求 |
|---------|---------|---------|---------|
| shooter | 射击/爆炸/道具/Boss出场 | 战斗 BGM + Boss BGM 切换 | 击中/爆炸/Boss出场 |
| tower-defense | 射击/敌人死亡/建塔/升级/失败 | 轻松背景 BGM | 敌人到达终点/建塔 |
| runner | 跳跃/滑铲/收集金币/碰撞 | 节奏感 BGM | 跳跃/碰撞 |
| fighting | 出拳/命中/格挡/必杀技 | 对战 BGM | 每次命中/格挡/击倒 |

## 8. 性能注意事项

| 注意点 | 建议 |
|--------|------|
| 音频文件大小 | SFX < 50KB/个，BGM < 500KB/个（压缩后） |
| 音频格式 | MP3（兼容性最好）或 AAC（压缩率更高） |
| 预加载时机 | 首屏 SFX 预加载，关卡 BGM 延迟加载 |
| 并发数 | 总活跃音源 ≤ 15，避免爆音和性能问题 |
| AudioContext 数量 | 全局单例，不要创建多个 |
| iOS 兼容 | 每次触摸需 `ctx.resume()`，因 iOS 会挂起 AudioContext |
