# H5 小游戏编码规范

## 1. 游戏循环 (Game Loop)

### 1.1 基本模式

使用 `requestAnimationFrame` 驱动主循环，计算 delta time：

```javascript
// js/core/GameLoop.js
class GameLoop {
  constructor(update, render) {
    this.update = update;   // 更新逻辑
    this.render = render;   // 渲染逻辑
    this.lastTime = 0;
    this.accumulator = 0;
    this.fixedDeltaTime = 1000 / 60;  // 固定 60fps 逻辑步长
    this.maxDelta = 100;              // 最大 delta（防卡顿跳跃）
    this.running = false;
    this.rafId = null;
  }

  start() {
    this.running = true;
    this.lastTime = performance.now();
    this._loop();
  }

  stop() {
    this.running = false;
    if (this.rafId) cancelAnimationFrame(this.rafId);
  }

  _loop = (currentTime = performance.now()) => {
    if (!this.running) return;

    let delta = currentTime - this.lastTime;
    this.lastTime = currentTime;

    // 限制 delta，防止页面切走后回来时大跳跃
    if (delta > this.maxDelta) delta = this.maxDelta;

    // 固定时间步长更新（推荐，物理一致性好）
    this.accumulator += delta;
    while (this.accumulator >= this.fixedDeltaTime) {
      this.update(this.fixedDeltaTime);
      this.accumulator -= this.fixedDeltaTime;
    }

    // 渲染
    this.render(delta);

    this.rafId = requestAnimationFrame(this._loop);
  };
}
```

### 1.2 两种步长策略

| 策略 | 适用场景 | 特点 |
|------|---------|------|
| **固定步长** | 物理敏感游戏（俄罗斯方块、贪吃蛇） | 逻辑一致性好，不受帧率波动影响 |
| **可变步长** | 动作流畅型游戏（跑酷、射击） | 帧率越高越流畅，需要插值 |

### 1.3 Delta Time 注意事项

- **必须 cap delta time**（≤33ms），防止页面切走后回来时逻辑跳跃
- 使用 `performance.now()` 而非 `Date.now()`，精度更高
- 页面不可见时（`visibilitychange`）暂停循环

---

## 2. 渲染优化 (Rendering)

### 2.1 Canvas 状态批处理

```javascript
// ✅ 正确：批量绘制，减少状态切换
ctx.fillStyle = '#ff0000';
for (const rect of redRects) {
  ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
}
ctx.fillStyle = '#00ff00';
for (const rect of greenRects) {
  ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
}

// ❌ 错误：每次绘制都切换颜色
for (const rect of allRects) {
  ctx.fillStyle = rect.color;
  ctx.fillRect(rect.x, rect.y, rect.w, rect.h);
}
```

### 2.2 减少 save/restore

```javascript
// ✅ 只在必要时 save/restore
ctx.save();
ctx.translate(camera.x, camera.y);
// ... 批量绘制所有需要平移的对象
ctx.restore();

// ❌ 每个对象都 save/restore（开销大）
for (const obj of objects) {
  ctx.save();
  ctx.translate(obj.x, obj.y);
  ctx.fillRect(0, 0, 10, 10);
  ctx.restore();
}
```

### 2.3 离屏 Canvas

将不变的内容预渲染到离屏 Canvas，每帧直接 `drawImage`：

```javascript
// 预渲染背景到离屏 Canvas
const bgCanvas = document.createElement('canvas');
bgCanvas.width = 750;
bgCanvas.height = 1334;
const bgCtx = bgCanvas.getContext('2d');
// 绘制复杂背景...
drawBackground(bgCtx);

// 每帧只需一次 drawImage
function render() {
  ctx.drawImage(bgCanvas, 0, 0);  // 1 次 draw call
  // ... 绘制动态对象
}
```

### 2.4 脏矩形渲染

只重绘变化区域（适用于静态背景 + 少量动态对象）：

```javascript
// 记录上一帧和这一帧的脏区域
const dirtyRects = [];

// 只清除和重绘脏区域
for (const rect of dirtyRects) {
  ctx.clearRect(rect.x, rect.y, rect.w, rect.h);
  // 重绘该区域内的对象
}
```

### 2.5 Draw Call 控制

| 操作 | Draw Call |
|------|-----------|
| `fillRect()` | 1 次 |
| `drawImage()` | 1 次 |
| `fillText()` | 1 次 |
| `strokeRect()` | 1 次 |

**目标：≤ 100 次/帧**。策略：
- 同色对象批量绘制
- 精灵图集（sprite sheet）减少纹理切换
- 离屏 Canvas 预渲染静态内容

---

## 3. 输入处理 (Input Handling)

### 3.1 统一输入抽象

```javascript
// js/core/InputHandler.js
class InputHandler {
  constructor(canvas) {
    this.canvas = canvas;
    this.handlers = { down: [], up: [], move: [] };

    // 统一 touch 和 mouse
    canvas.addEventListener('touchstart', this._onTouch, { passive: false });
    canvas.addEventListener('touchmove', this._onTouch, { passive: false });
    canvas.addEventListener('touchend', this._onTouch, { passive: false });
    canvas.addEventListener('mousedown', this._onMouse);
    canvas.addEventListener('mousemove', this._onMouse);
    canvas.addEventListener('mouseup', this._onMouse);

    // 键盘
    window.addEventListener('keydown', this._onKey);
    window.addEventListener('keyup', this._onKey);
  }

  _getPos(e) {
    const rect = this.canvas.getBoundingClientRect();
    const point = e.touches ? e.touches[0] : e;
    return {
      x: (point.clientX - rect.left) * (this.canvas.width / rect.width),
      y: (point.clientY - rect.top) * (this.canvas.height / rect.height),
    };
  }

  _onTouch = (e) => {
    e.preventDefault();  // 阻止默认滚动
    const type = e.type === 'touchstart' ? 'down'
               : e.type === 'touchmove' ? 'move' : 'up';
    const pos = this._getPos(e);
    this.handlers[type].forEach(fn => fn(pos));
  };

  _onMouse = (e) => {
    const type = e.type === 'mousedown' ? 'down'
               : e.type === 'mousemove' ? 'move' : 'up';
    const pos = this._getPos(e);
    this.handlers[type].forEach(fn => fn(pos));
  };

  on(type, fn) { this.handlers[type]?.push(fn); }
}
```

### 3.2 输入响应要求

- **响应延迟 ≤ 16ms**（一帧内处理）
- `touchmove` 事件必须 `e.preventDefault()` 阻止页面滚动
- 使用 `{ passive: false }` 注册 touch 事件以允许 preventDefault
- 坐标需根据 Canvas 缩放比例换算

---

## 4. 内存管理

### 4.1 对象池

频繁创建/销毁的对象（子弹、粒子）使用对象池：

```javascript
// js/utils/ObjectPool.js
class ObjectPool {
  constructor(factory, reset, initialSize = 0) {
    this.factory = factory;
    this.reset = reset;
    this.pool = [];
    for (let i = 0; i < initialSize; i++) {
      this.pool.push(factory());
    }
  }

  acquire() {
    return this.pool.length > 0 ? this.pool.pop() : this.factory();
  }

  release(obj) {
    this.reset(obj);
    this.pool.push(obj);
  }
}

// 使用示例：子弹池
const bulletPool = new ObjectPool(
  () => ({ x: 0, y: 0, vx: 0, vy: 0, active: false }),
  (b) => { b.active = false; b.x = 0; b.y = 0; },
  50  // 预分配 50 个
);
```

### 4.2 避免GC抖动

```javascript
// ❌ 在游戏循环内创建对象 → GC 压力
function update() {
  for (const enemy of enemies) {
    const delta = { x: player.x - enemy.x, y: player.y - enemy.y }; // 每帧创建
    // ...
  }
}

// ✅ 复用临时对象
const _tempDelta = { x: 0, y: 0 };  // 模块级临时变量
function update() {
  for (const enemy of enemies) {
    _tempDelta.x = player.x - enemy.x;
    _tempDelta.y = player.y - enemy.y;
    // ...
  }
}
```

### 4.3 数组复用

```javascript
// 避免在循环中 splice（O(n) 移动）
// 使用标记清除模式
for (let i = entities.length - 1; i >= 0; i--) {
  if (entities[i].dead) {
    entities[i] = entities[entities.length - 1];  // 末尾元素填补
    entities.pop();
  }
}
```

---

## 5. 资源加载

### 5.1 预加载策略

```javascript
// js/utils/AssetLoader.js
class AssetLoader {
  constructor() {
    this.images = {};
    this.audio = {};
  }

  async loadImages(manifest) {
    const promises = Object.entries(manifest).map(([key, src]) => {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => { this.images[key] = img; resolve(); };
        img.onerror = reject;
        img.src = src;
      });
    });
    await Promise.all(promises);
  }

  // 带进度回调
  async loadWithProgress(manifest, onProgress) {
    let loaded = 0;
    const total = Object.keys(manifest).length;
    // ... 每加载完一个调用 onProgress(loaded / total)
  }
}
```

### 5.2 加载策略

| 资源类型 | 加载时机 | 方式 |
|---------|---------|------|
| 首屏图片 | 启动时 | 预加载（阻塞） |
| 首屏音效 | 启动时 | 预加载 |
| 关卡资源 | 进入关卡时 | 按需加载 |
| BGM | 场景切换时 | 按需加载 |
| 非关键资源 | 空闲时 | 延迟加载 |

---

## 6. 场景管理

```javascript
// js/scenes/Scene.js
class Scene {
  enter() {}   // 进入场景
  exit() {}    // 离开场景
  update(dt) {}
  render(ctx) {}
}

// js/scenes/SceneManager.js
class SceneManager {
  constructor() {
    this.current = null;
    this.scenes = {};
  }

  register(name, scene) { this.scenes[name] = scene; }

  switch(name) {
    if (this.current) this.current.exit();
    this.current = this.scenes[name];
    this.current.enter();
  }

  update(dt) { this.current?.update(dt); }
  render(ctx) { this.current?.render(ctx); }
}
```

---

## 7. 代码组织

### 7.1 模块化

使用 ES6 模块或 IIFE 模块模式：

```javascript
// ES6 模块（推荐）
// js/core/GameLoop.js
export class GameLoop { ... }

// game.js
import { GameLoop } from './js/core/GameLoop.js';

// IIFE 模式（兼容性更好）
// js/core/GameLoop.js
(function(global) {
  class GameLoop { ... }
  global.GameLoop = GameLoop;
})(window);
```

### 7.2 文件职责分离

| 文件 | 职责 | 不应包含 |
|------|------|---------|
| `game.js` | 入口、初始化 | 游戏逻辑 |
| `config.js` | 参数配置 | 逻辑代码 |
| `js/core/*.js` | 引擎能力 | 游戏玩法 |
| `js/scenes/*.js` | 场景逻辑 | 渲染细节 |
| `js/entities/*.js` | 实体行为 | 全局状态 |

---

## 8. 音频处理

```javascript
// Web Audio API 播放短音效
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playSound(src) {
  const source = audioCtx.createBufferSource();
  source.buffer = audioBufferCache[src];
  source.connect(audioCtx.destination);
  source.start(0);
}

// 预加载音频
async function preloadAudio(src) {
  const response = await fetch(src);
  const arrayBuffer = await response.arrayBuffer();
  audioBufferCache[src] = await audioCtx.decodeAudioData(arrayBuffer);
}
```

**音频规范**：
- BGM：AAC 格式，低码率（64-96kbps）
- 短音效：MP3 或 WAV，时长 < 3s
- 预加载到内存避免延迟

---

## 9. 体积优化

| 手段 | 效果 | 工具 |
|------|------|------|
| 代码压缩混淆 | -20%~40% | terser, uglify |
| 移除未用代码 | -10%~30% | tree shaking |
| PNG → WebP | -30%~70% | cwebp, sharp |
| PNG 降色 | -50% | pngquant, TinyPNG |
| 音频降码率 | -50%+ | ffmpeg |
| 字体子集化 | -90% | fontmin |
| 精灵图集 | 减少 draw call | TexturePacker |
