# 扫雷 (Minesweeper) — 模板参考

## 游戏概述

经典扫雷：点击格子翻开，数字提示周围地雷数，右键标记可疑格子，翻开所有非雷格子获胜。

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Cell` | `js/entities/Cell.js` | 单格状态（是否雷、是否翻开、是否标记、周围雷数） |
| `Board` | `js/entities/Board.js` | 网格管理、雷布局、翻开扩散、胜负判定 |

### Cell 实体骨架

```javascript
class Cell {
  constructor(row, col) {
    this.row = row;
    this.col = col;
    this.isMine = false;
    this.isRevealed = false;
    this.isFlagged = false;
    this.adjacentMines = 0;
  }
}
```

### Board 实体骨架

```javascript
class Board {
  constructor(rows, cols, mineCount) {
    this.rows = rows;
    this.cols = cols;
    this.mineCount = mineCount;
    this.grid = [];
    this.firstClick = true;
    this.gameOver = false;
    this.won = false;
    this.flagCount = 0;

    for (let r = 0; r < rows; r++) {
      this.grid[r] = [];
      for (let c = 0; c < cols; c++) {
        this.grid[r][c] = new Cell(r, c);
      }
    }
  }

  // 首次点击后才布雷（保证第一次点击不踩雷）
  placeMines(safeR, safeC) {
    const safeZone = new Set();
    // 安全区：首次点击的格子及其周围 8 格
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        safeZone.add(`${safeR + dr},${safeC + dc}`);
      }
    }

    let placed = 0;
    while (placed < this.mineCount) {
      const r = Math.floor(Math.random() * this.rows);
      const c = Math.floor(Math.random() * this.cols);
      if (this.grid[r][c].isMine) continue;
      if (safeZone.has(`${r},${c}`)) continue;
      this.grid[r][c].isMine = true;
      placed++;
    }

    // 计算每个格子周围雷数
    this.calculateAdjacentMines();
  }

  calculateAdjacentMines() {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.grid[r][c].isMine) continue;
        let count = 0;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            const nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < this.rows && nc >= 0 && nc < this.cols) {
              if (this.grid[nr][nc].isMine) count++;
            }
          }
        }
        this.grid[r][c].adjacentMines = count;
      }
    }
  }

  // 翻开格子（含扩散）
  reveal(r, c) {
    if (this.gameOver) return;
    const cell = this.grid[r][c];
    if (cell.isRevealed || cell.isFlagged) return;

    // 首次点击：布雷
    if (this.firstClick) {
      this.placeMines(r, c);
      this.firstClick = false;
    }

    cell.isRevealed = true;

    if (cell.isMine) {
      this.gameOver = true;
      this.revealAllMines();
      return;
    }

    // 数字为 0 时扩散翻开周围格子（Flood Fill）
    if (cell.adjacentMines === 0) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < this.rows && nc >= 0 && nc < this.cols) {
            this.reveal(nr, nc);
          }
        }
      }
    }

    this.checkWin();
  }

  // 标记/取消标记
  toggleFlag(r, c) {
    if (this.gameOver) return;
    const cell = this.grid[r][c];
    if (cell.isRevealed) return;
    cell.isFlagged = !cell.isFlagged;
    this.flagCount += cell.isFlagged ? 1 : -1;
  }

  revealAllMines() {
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        if (this.grid[r][c].isMine) {
          this.grid[r][c].isRevealed = true;
        }
      }
    }
  }

  checkWin() {
    let unrevealedSafe = 0;
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const cell = this.grid[r][c];
        if (!cell.isMine && !cell.isRevealed) unrevealedSafe++;
      }
    }
    if (unrevealedSafe === 0) {
      this.won = true;
      this.gameOver = true;
    }
  }
}
```

## 核心算法

### Flood Fill 翻开

当翻开一个周围无雷的格子（数字为 0）时，递归翻开周围所有格子，直到遇到数字格停止。这是扫雷的核心交互。

### 首次点击安全

保证第一次点击不会踩雷：在首次点击后才布雷，且首次点击位置及周围 8 格不布雷。

### 输入区分

```javascript
// 左键翻开，右键/长按标记
input.on('down', (pos) => {
  touchStartTime = Date.now();
  touchStartPos = pos;
});

input.on('up', (pos) => {
  const duration = Date.now() - touchStartTime;
  const cell = getCellAt(pos);

  if (duration > 500) {
    // 长按 = 标记
    board.toggleFlag(cell.row, cell.col);
  } else {
    // 短按 = 翻开
    board.reveal(cell.row, cell.col);
  }
});

// 鼠标右键
canvas.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  const cell = getCellAt(getMousePos(e));
  board.toggleFlag(cell.row, cell.col);
});
```

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 难度选择（初级/中级/高级） |
| GameScene | 雷区、剩余雷数、计时器 |
| GameOverScene | 胜利/失败、用时、重新开始 |

## config.js 参数建议

```javascript
const CONFIG = {
  difficulties: {
    beginner:     { rows: 9,  cols: 9,  mines: 10 },
    intermediate: { rows: 16, cols: 16, mines: 40 },
    expert:       { rows: 16, cols: 30, mines: 99 },
  },
  display: {
    cellSize: 32,
    cellGap: 1,
  },
  colors: {
    background: '#c0c0c0',
    cellUnrevealed: '#bdbdbd',
    cellRevealed: '#e0e0e0',
    mine: '#f00',
    flag: '#f00',
    numbers: ['', '#0000ff', '#008000', '#ff0000', '#000080',
              '#800000', '#008080', '#000000', '#808080'],
  },
  timing: {
    longPressThreshold: 500,  // 长按阈值(ms)
  },
};
```

## 输入映射

| 操作 | 效果 |
|------|------|
| 左键 / 短按 | 翻开格子 |
| 右键 / 长按 | 标记/取消标记 |

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 地雷图标 | 可用红色圆形代替 | 可选 |
| 旗子图标 | 可用红色三角形代替 | 可选 |
| 爆炸音效 | `explode.mp3` | 推荐 |
| 胜利音效 | `win.mp3` | 可选 |

## 预估包体

- 纯 Canvas 绘制：**< 30KB**
- 含图标和音效：**< 100KB**

## 渲染要点

```javascript
render(ctx) {
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = board.grid[r][c];
      const x = c * (cellSize + gap);
      const y = r * (cellSize + gap);

      if (!cell.isRevealed) {
        // 未翻开
        ctx.fillStyle = CONFIG.colors.cellUnrevealed;
        ctx.fillRect(x, y, cellSize, cellSize);
        // 3D 凸起效果
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fillRect(x, y, cellSize, 2);
        ctx.fillRect(x, y, 2, cellSize);

        if (cell.isFlagged) {
          drawFlag(ctx, x, y, cellSize);
        }
      } else {
        // 已翻开
        ctx.fillStyle = CONFIG.colors.cellRevealed;
        ctx.fillRect(x, y, cellSize, cellSize);

        if (cell.isMine) {
          ctx.fillStyle = CONFIG.colors.mine;
          ctx.beginPath();
          ctx.arc(x + cellSize/2, y + cellSize/2, cellSize/3, 0, Math.PI*2);
          ctx.fill();
        } else if (cell.adjacentMines > 0) {
          ctx.fillStyle = CONFIG.colors.numbers[cell.adjacentMines];
          ctx.font = `bold ${cellSize * 0.6}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(cell.adjacentMines, x + cellSize/2, y + cellSize/2);
        }
      }
    }
  }
}
```
