# 游戏AI与敌人行为模块

> 本模块提供游戏 AI 设计模式与代码骨架，适用于需要敌人行为、波次生成、追踪算法的游戏类型（shooter / tower-defense / runner / fighting）。

---

## 1. 有限状态机（FSM）

### 1.1 设计模式

FSM 是最常见的游戏 AI 架构。每个实体在任意时刻处于一个状态，通过条件触发状态转换。

```
┌──────┐  发现玩家  ┌───────┐  进入射程  ┌────────┐
│ IDLE │ ─────────→ │ CHASE │ ─────────→ │ ATTACK │
└──────┘            └───────┘            └────────┘
   ↑                   ↑                     │
   │  超出范围          │  超出范围            │ 血量低
   │                   │                     ▼
   │              ┌────────┐            ┌───────┐
   └───────────── │  FLEE  │ ←────────── │ DEAD  │
                  └────────┘             └───────┘
```

### 1.2 通用 FSM 实现

```javascript
// js/utils/StateMachine.js
class StateMachine {
  constructor() {
    this.states = {};        // 状态注册表
    this.currentState = null;
    this.currentStateName = '';
  }

  addState(name, state) {
    this.states[name] = state;
    state.machine = this;  // 让状态能访问机器
  }

  transition(toState, context) {
    if (!this.states[toState]) return;
    if (this.currentState) this.currentState.exit(context);
    this.currentStateName = toState;
    this.currentState = this.states[toState];
    this.currentState.enter(context);
  }

  update(dt, context) {
    if (this.currentState) this.currentState.update(dt, context);
  }
}

// 状态基类
class State {
  enter(context) {}   // 进入状态时调用
  update(dt, context) {}  // 每帧更新
  exit(context) {}    // 离开状态时调用
}
```

### 1.3 敌人 FSM 示例

```javascript
// 敌人状态定义
class IdleState extends State {
  update(dt, ctx) {
    const dist = distance(ctx.enemy, ctx.player);
    if (dist < ctx.enemy.detectRange) {
      this.machine.transition('chase', ctx);
    }
  }
}

class ChaseState extends State {
  update(dt, ctx) {
    const dist = distance(ctx.enemy, ctx.player);
    if (dist < ctx.enemy.attackRange) {
      this.machine.transition('attack', ctx);
    } else if (dist > ctx.enemy.detectRange * 1.5) {
      this.machine.transition('idle', ctx);
    }
    // 向玩家移动
    const angle = Math.atan2(ctx.player.y - ctx.enemy.y, ctx.player.x - ctx.enemy.x);
    ctx.enemy.x += Math.cos(angle) * ctx.enemy.speed * dt / 1000;
    ctx.enemy.y += Math.sin(angle) * ctx.enemy.speed * dt / 1000;
  }
}

class AttackState extends State {
  enter(ctx) { ctx.enemy.fireCooldown = 0; }
  update(dt, ctx) {
    const dist = distance(ctx.enemy, ctx.player);
    if (dist > ctx.enemy.attackRange) {
      this.machine.transition('chase', ctx);
      return;
    }
    ctx.enemy.fireCooldown -= dt;
    if (ctx.enemy.fireCooldown <= 0) {
      ctx.enemy.fire(ctx.player);
      ctx.enemy.fireCooldown = ctx.enemy.fireInterval;
    }
  }
}

class FleeState extends State {
  update(dt, ctx) {
    if (ctx.enemy.hp > ctx.enemy.maxHp * 0.3) {
      this.machine.transition('chase', ctx);
      return;
    }
    // 远离玩家
    const angle = Math.atan2(ctx.enemy.y - ctx.player.y, ctx.enemy.x - ctx.player.x);
    ctx.enemy.x += Math.cos(angle) * ctx.enemy.speed * dt / 1000;
    ctx.enemy.y += Math.sin(angle) * ctx.enemy.speed * dt / 1000;
  }
}

// 使用
const enemyFSM = new StateMachine();
enemyFSM.addState('idle', new IdleState());
enemyFSM.addState('chase', new ChaseState());
enemyFSM.addState('attack', new AttackState());
enemyFSM.addState('flee', new FleeState());
enemyFSM.transition('idle', { enemy, player });
```

### 1.4 状态转换条件参考

| 转换 | 条件 | 适用场景 |
|------|------|---------|
| idle → chase | 距离 < detectRange | 所有敌人 |
| chase → attack | 距离 < attackRange | 射击/格斗 |
| chase → idle | 距离 > detectRange × 1.5 | 警戒脱离 |
| any → flee | hp < maxHp × 0.3 | BOSS 狂暴 |
| any → dead | hp ≤ 0 | 所有实体 |
| attack → chase | 距离 > attackRange | 目标逃离 |

---

## 2. 行为树基础

### 2.1 节点类型

| 节点 | 行为 | 返回值 |
|------|------|--------|
| **Sequence** | 依次执行子节点，全部成功才成功 | 任一失败则失败 |
| **Selector** | 依次执行子节点，任一成功即成功 | 全部失败才失败 |
| **Condition** | 判断条件 | SUCCESS / FAILURE |
| **Action** | 执行动作 | SUCCESS / FAILURE / RUNNING |

### 2.2 行为树实现

```javascript
// js/utils/BehaviorTree.js
const { SUCCESS, FAILURE, RUNNING } = { SUCCESS: 1, FAILURE: 0, RUNNING: 2 };

class BTNode { execute(ctx) { return FAILURE; } }

class SequenceNode extends BTNode {
  constructor(children) { super(); this.children = children; }
  execute(ctx) {
    for (const child of this.children) {
      const result = child.execute(ctx);
      if (result !== SUCCESS) return result;
    }
    return SUCCESS;
  }
}

class SelectorNode extends BTNode {
  constructor(children) { super(); this.children = children; }
  execute(ctx) {
    for (const child of this.children) {
      const result = child.execute(ctx);
      if (result !== FAILURE) return result;
    }
    return FAILURE;
  }
}

class ConditionNode extends BTNode {
  constructor(check) { super(); this.check = check; }
  execute(ctx) { return this.check(ctx) ? SUCCESS : FAILURE; }
}

class ActionNode extends BTNode {
  constructor(action) { super(); this.action = action; }
  execute(ctx) { return this.action(ctx); }
}
```

### 2.3 敌人行为树示例

```javascript
// 敌人 AI 行为树
const enemyBT = new SelectorNode([
  // 优先级1：血量低时逃跑
  new SequenceNode([
    new ConditionNode(ctx => ctx.enemy.hp < ctx.enemy.maxHp * 0.2),
    new ActionNode(ctx => { ctx.enemy.flee(ctx.player); return RUNNING; }),
  ]),
  // 优先级2：玩家在攻击范围内则攻击
  new SequenceNode([
    new ConditionNode(ctx => distance(ctx.enemy, ctx.player) < ctx.enemy.attackRange),
    new ActionNode(ctx => { ctx.enemy.attack(ctx.player); return RUNNING; }),
  ]),
  // 优先级3：玩家在检测范围内则追踪
  new SequenceNode([
    new ConditionNode(ctx => distance(ctx.enemy, ctx.player) < ctx.enemy.detectRange),
    new ActionNode(ctx => { ctx.enemy.chase(ctx.player); return RUNNING; }),
  ]),
  // 优先级4：巡逻
  new ActionNode(ctx => { ctx.enemy.patrol(); return RUNNING; }),
]);

// 每帧执行
enemyBT.execute({ enemy, player, world });
```

### 2.4 FSM vs 行为树选择

| 维度 | FSM | 行为树 |
|------|-----|--------|
| 复杂度 | 简单（3-5 状态） | 复杂（多优先级决策） |
| 可读性 | 状态转换图直观 | 树结构层次清晰 |
| 扩展性 | 新状态需改多个转换 | 新增节点插入即可 |
| 适用 | 普通敌人 | BOSS、复杂 AI |
| 推荐 | shooter/tower-defense 普通敌人 | fighting AI 对手、shooter Boss |

---

## 3. 追踪算法

### 3.1 直线追踪

最简单的追踪：直接朝目标移动。

```javascript
function seek(self, target, speed, dt) {
  const dx = target.x - self.x;
  const dy = target.y - self.y;
  const dist = Math.hypot(dx, dy);
  if (dist < 0.1) return;
  self.vx = (dx / dist) * speed;
  self.vy = (dy / dist) * speed;
  self.x += self.vx * dt / 1000;
  self.y += self.vy * dt / 1000;
}
```

**适用**：塔防敌人朝终点、普通敌机直线下落。

### 3.2 预判追踪

计算目标未来位置再追踪（用于追踪弹）。

```javascript
function predictSeek(self, target, bulletSpeed, dt) {
  const dx = target.x - self.x;
  const dy = target.y - self.y;
  const dist = Math.hypot(dx, dy);
  const predictTime = dist / bulletSpeed;  // 预估飞行时间

  // 预测目标未来位置
  const futureX = target.x + (target.vx || 0) * predictTime;
  const futureY = target.y + (target.vy || 0) * predictTime;

  const fdx = futureX - self.x;
  const fdy = futureY - self.y;
  const fdist = Math.hypot(fdx, fdy);
  if (fdist < 0.1) return;

  self.vx = (fdx / fdist) * bulletSpeed;
  self.vy = (fdy / fdist) * bulletSpeed;
}
```

**适用**：射击游戏追踪弹、塔防追踪弹道。

### 3.3 巡逻路径

预设路径点，循环或来回移动。

```javascript
class Patrol {
  constructor(points, mode = 'loop') {
    this.points = points;     // [{x,y}, ...]
    this.mode = mode;         // 'loop' | 'pingpong'
    this.currentIndex = 0;
    this.direction = 1;       // pingpong 方向
  }

  getNext(self, speed, dt) {
    const target = this.points[this.currentIndex];
    const dx = target.x - self.x;
    const dy = target.y - self.y;
    const dist = Math.hypot(dx, dy);

    if (dist < 5) {
      // 到达路径点，切换下一个
      if (this.mode === 'loop') {
        this.currentIndex = (this.currentIndex + 1) % this.points.length;
      } else {
        this.currentIndex += this.direction;
        if (this.currentIndex >= this.points.length - 1 || this.currentIndex <= 0) {
          this.direction *= -1;
        }
      }
      return;
    }

    self.x += (dx / dist) * speed * dt / 1000;
    self.y += (dy / dist) * speed * dt / 1000;
  }
}
```

**适用**：敌人巡逻、Boss 移动模式。

### 3.4 追踪算法选择

| 算法 | 精度 | 计算量 | 适用场景 |
|------|------|--------|---------|
| 直线追踪 | 低 | 极低 | 普通敌人、塔防 |
| 预判追踪 | 高 | 低 | 追踪弹、高级敌人 |
| 巡逻路径 | — | 极低 | 非追踪型移动 |
| A*寻路 | 最高 | 高 | 复杂地形（见 tower-defense 模板） |

---

## 4. 波次生成器

### 4.1 波次配置数据结构

```javascript
const WAVE_CONFIG = [
  {
    waveNumber: 1,
    spawnInterval: 1000,  // 每个敌人生成间隔(ms)
    enemies: [
      { type: 'scout', count: 5 },
    ],
    rewardBonus: 100,
  },
  {
    waveNumber: 2,
    spawnInterval: 800,
    enemies: [
      { type: 'scout', count: 8 },
      { type: 'fighter', count: 2 },
    ],
    rewardBonus: 150,
  },
  {
    waveNumber: 3,
    spawnInterval: 600,
    enemies: [
      { type: 'fighter', count: 5 },
      { type: 'bomber', count: 2 },
      { type: 'boss', count: 1 },
    ],
    rewardBonus: 500,
  },
];
```

### 4.2 波次管理器实现

```javascript
// js/utils/WaveManager.js
class WaveManager {
  constructor(config) {
    this.waves = config;
    this.currentWaveIndex = 0;
    this.spawnQueue = [];     // 待生成的敌人队列
    this.spawnTimer = 0;
    this.waveActive = false;
    this.betweenWaveDelay = 3000;  // 波次间间隔(ms)
    this.idleTimer = 0;
  }

  start() {
    this._prepareWave(0);
  }

  _prepareWave(index) {
    if (index >= this.waves.length) {
      this.onAllWavesComplete?.();
      return;
    }
    const wave = this.waves[index];
    this.spawnQueue = [];
    for (const group of wave.enemies) {
      for (let i = 0; i < group.count; i++) {
        this.spawnQueue.push(group.type);
      }
    }
    this.spawnInterval = wave.spawnInterval;
    this.spawnTimer = 0;
    this.waveActive = true;
    this.currentWaveIndex = index;
    this.onWaveStart?.(wave);
  }

  update(dt, activeEnemies) {
    if (!this.waveActive) {
      // 波次间隔
      this.idleTimer += dt;
      if (this.idleTimer >= this.betweenWaveDelay) {
        this.idleTimer = 0;
        this._prepareWave(this.currentWaveIndex + 1);
      }
      return;
    }

    // 按间隔生成敌人
    if (this.spawnQueue.length > 0) {
      this.spawnTimer += dt;
      if (this.spawnTimer >= this.spawnInterval) {
        this.spawnTimer = 0;
        const type = this.spawnQueue.shift();
        this.onSpawn?.(type);
      }
    }

    // 当前波次完成判定
    if (this.spawnQueue.length === 0 && activeEnemies === 0) {
      this.waveActive = false;
      this.idleTimer = 0;
      this.onWaveComplete?.(this.waves[this.currentWaveIndex]);
    }
  }
}
```

### 4.3 难度递增曲线

```javascript
// 三种难度递增策略
const DIFFICULTY_CURVES = {
  // 线性递增：适合休闲游戏
  linear: (wave, base) => base + wave * 0.15,

  // 指数递增：适合硬核游戏
  exponential: (wave, base) => base * Math.pow(1.2, wave - 1),

  // 阶梯递增：每 5 波大幅提升
  step: (wave, base) => base * (1 + Math.floor((wave - 1) / 5) * 0.5),
};

// 应用：敌人 HP 随波次递增
const baseHp = 100;
const enemyHp = DIFFICULTY_CURVES.exponential(currentWave, baseHp);
```

### 4.4 与游戏模板结合

| 游戏类型 | 波次用途 | 生成方式 |
|---------|---------|---------|
| shooter | 敌机波次，定期出现 Boss | 从屏幕上方/边缘生成 |
| tower-defense | 每波敌人沿路径前进 | 从路径起点生成 |
| runner | 障碍物波次（随距离增加密度） | 从屏幕右侧生成 |
| fighting | 回合制（非波次，但类似结构） | 每回合重置双方状态 |

---

## 5. AI 决策框架

### 5.1 通用决策接口

```javascript
// 所有 AI 决策器实现此接口
class AIDecider {
  decide(self, world) {
    // 返回一个 action 对象
    // { type: 'move', x, y } | { type: 'attack', target } | { type: 'block' } | ...
    throw new Error('Not implemented');
  }
}
```

### 5.2 基于权重的随机决策

```javascript
class WeightedDecider extends AIDecider {
  constructor(actions) {
    super();
    // actions: [{ action, weight }]
    this.actions = actions;
  }

  decide(self, world) {
    const totalWeight = this.actions.reduce((sum, a) => sum + a.weight, 0);
    let r = Math.random() * totalWeight;
    for (const entry of this.actions) {
      r -= entry.weight;
      if (r <= 0) return entry.action;
    }
    return this.actions[0].action;
  }
}

// 使用：AI 在攻击距离内有 60% 概率攻击，30% 格挡，10% 后退
const decider = new WeightedDecider([
  { action: { type: 'attack' }, weight: 60 },
  { action: { type: 'block' },  weight: 30 },
  { action: { type: 'retreat' }, weight: 10 },
]);
```

### 5.3 反应延迟模型

```javascript
class DelayedDecider extends AIDecider {
  constructor(innerDecider, reactionDelay) {
    super();
    this.inner = innerDecider;
    this.reactionDelay = reactionDelay;  // ms
    this.lastDecisionTime = 0;
    this.cachedDecision = null;
  }

  decide(self, world) {
    const now = performance.now();
    if (now - this.lastDecisionTime >= this.reactionDelay) {
      this.cachedDecision = this.inner.decide(self, world);
      this.lastDecisionTime = now;
    }
    return this.cachedDecision;
  }
}
```

### 5.4 难度分级

| 难度 | 反应延迟 | 决策准确率 | 行为复杂度 |
|------|---------|-----------|-----------|
| 简单 | 500ms | 50% | 仅直线追踪 |
| 中等 | 300ms | 75% | 预判追踪 + 偶尔格挡 |
| 困难 | 150ms | 90% | 预判追踪 + 连招 + 主动格挡 |
| 噩梦 | 80ms | 100% | 完美决策 + 行为树 |

```javascript
const DIFFICULTY_PRESETS = {
  easy:   { reactionDelay: 500, accuracy: 0.5, useBehaviorTree: false },
  normal: { reactionDelay: 300, accuracy: 0.75, useBehaviorTree: false },
  hard:   { reactionDelay: 150, accuracy: 0.9, useBehaviorTree: true },
  nightmare: { reactionDelay: 80, accuracy: 1.0, useBehaviorTree: true },
};
```

---

## 6. 与游戏模板结合总表

| 游戏类型 | AI 架构 | 核心行为 | 波次用途 |
|---------|---------|---------|---------|
| shooter | FSM（普通敌人）+ 行为树（Boss） | 追踪、射击、弹幕模式切换 | 敌机波次 + Boss 触发 |
| tower-defense | 无 AI（沿路径）+ FSM（塔目标选择） | 塔自动选择目标 | 敌人波次递增 |
| runner | 无 AI（障碍物静态） | 障碍物生成决策 | 障碍密度随距离递增 |
| fighting | 行为树 + 延迟决策器 | 攻防决策、连招选择 | 回合制 |
