# 井字棋 (Tic-Tac-Toe) — 模板参考

## 游戏概述

经典井字棋：3x3 棋盘，双方轮流落子，先连成三子一线者胜。支持人机对战（AI 对手）。

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Board` | `js/entities/Board.js` | 3x3 棋盘状态、落子、胜负判定 |
| `Player` | `js/entities/Player.js` | 玩家信息（符号、是否AI） |
| `AIPlayer` | `js/entities/AIPlayer.js` | AI 对手逻辑（Minimax 算法） |

### Board 实体骨架

```javascript
class Board {
  constructor() {
    this.size = 3;
    this.cells = Array(9).fill(null);  // null | 'X' | 'O'
    this.currentPlayer = 'X';
    this.winner = null;
    this.winLine = null;  // 获胜的三连位置
    this.gameOver = false;
  }

  place(index) {
    if (this.gameOver || this.cells[index]) return false;
    this.cells[index] = this.currentPlayer;
    this.checkWinner();
    if (!this.gameOver) {
      this.currentPlayer = this.currentPlayer === 'X' ? 'O' : 'X';
    }
    return true;
  }

  // 8 条获胜线
  static WIN_LINES = [
    [0,1,2], [3,4,5], [6,7,8],   // 横
    [0,3,6], [1,4,7], [2,5,8],   // 竖
    [0,4,8], [2,4,6],             // 对角
  ];

  checkWinner() {
    for (const line of Board.WIN_LINES) {
      const [a, b, c] = line;
      if (this.cells[a] &&
          this.cells[a] === this.cells[b] &&
          this.cells[a] === this.cells[c]) {
        this.winner = this.cells[a];
        this.winLine = line;
        this.gameOver = true;
        return;
      }
    }
    // 平局检测
    if (this.cells.every(c => c !== null)) {
      this.gameOver = true;  // winner 保持 null = 平局
    }
  }

  // 获取所有空位（AI 用）
  getAvailableMoves() {
    const moves = [];
    for (let i = 0; i < 9; i++) {
      if (!this.cells[i]) moves.push(i);
    }
    return moves;
  }

  // 克隆（AI 搜索用）
  clone() {
    const b = new Board();
    b.cells = [...this.cells];
    b.currentPlayer = this.currentPlayer;
    b.gameOver = this.gameOver;
    b.winner = this.winner;
    return b;
  }
}
```

### AIPlayer (Minimax) 实体骨架

```javascript
class AIPlayer {
  constructor(symbol, difficulty = 'hard') {
    this.symbol = symbol;           // 'O'
    this.opponent = symbol === 'X' ? 'O' : 'X';
    this.difficulty = difficulty;   // 'easy' | 'medium' | 'hard'
  }

  getMove(board) {
    const moves = board.getAvailableMoves();
    if (moves.length === 0) return -1;

    // 简单模式：随机
    if (this.difficulty === 'easy') {
      return moves[Math.floor(Math.random() * moves.length)];
    }

    // 中等模式：50% 随机 + 50% 最优
    if (this.difficulty === 'medium' && Math.random() < 0.5) {
      return moves[Math.floor(Math.random() * moves.length)];
    }

    // 困难模式：Minimax 完美策略
    return this.minimax(board, this.symbol).index;
  }

  minimax(board, player, depth = 0) {
    // 终局评估
    if (board.gameOver) {
      if (board.winner === this.symbol) return { score: 10 - depth };
      if (board.winner === this.opponent) return { score: depth - 10 };
      return { score: 0 };  // 平局
    }

    const moves = board.getAvailableMoves();
    const scores = [];

    for (const move of moves) {
      const clone = board.clone();
      clone.place(move);
      const result = this.minimax(clone, player === 'X' ? 'O' : 'X', depth + 1);
      scores.push({ index: move, score: result.score });
    }

    // 最大化己方分数，最小化对方分数
    if (player === this.symbol) {
      return scores.reduce((best, s) => s.score > best.score ? s : best);
    } else {
      return scores.reduce((worst, s) => s.score < worst.score ? s : worst);
    }
  }
}
```

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 模式选择（双人/人机）、难度选择 |
| GameScene | 3x3 棋盘、当前玩家指示、落子动画 |
| GameOverScene | 胜负结果、重新开始 |

## 核心算法

### 胜负判定

8 条线检查：3 横 + 3 竖 + 2 对角。

### Minimax 完美 AI

井字棋状态空间小（9! = 362880），可用 Minimax 算法穷举所有可能，实现不可战胜的 AI。

**优化**：Alpha-Beta 剪枝可减少搜索量，但井字棋规模小，基础 Minimax 已足够快。

### 人机对战流程

```javascript
// GameScene
onCellClick(index) {
  if (board.gameOver) return;
  if (board.currentPlayer !== humanPlayer) return;  // 非人类回合
  if (!board.place(index)) return;
  playSound('place');

  if (board.gameOver) {
    setTimeout(() => sceneManager.switch('gameover'), 1000);
    return;
  }

  // AI 回合
  if (aiPlayer && board.currentPlayer === aiPlayer.symbol) {
    setTimeout(() => {
      const aiMove = aiPlayer.getMove(board);
      board.place(aiMove);
      playSound('place');
      if (board.gameOver) {
        setTimeout(() => sceneManager.switch('gameover'), 1000);
      }
    }, 500);  // 延迟模拟思考
  }
}
```

## config.js 参数建议

```javascript
const CONFIG = {
  game: {
    size: 3,
    cellSize: 100,
    cellGap: 8,
    winLineLength: 3,
  },
  players: {
    X: { symbol: 'X', color: '#00bcd4', name: '玩家1' },
    O: { symbol: 'O', color: '#ff5722', name: '玩家2' },
  },
  ai: {
    difficulty: 'hard',  // 'easy' | 'medium' | 'hard'
    thinkDelay: 500,     // AI 思考延迟(ms)
  },
  colors: {
    background: '#1a1a2e',
    board: '#16213e',
    cell: '#0f3460',
    winLine: '#e94560',
  },
};
```

## 输入映射

| 操作 | 效果 |
|------|------|
| 点击格子 | 落子 |
| 触摸格子 | 落子 |

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| X/O 图片 | 可用 Canvas 文字绘制代替 | 可选 |
| 落子音效 | `place.mp3` | 推荐 |
| 胜利音效 | `win.mp3` | 可选 |

## 预估包体

- 纯 Canvas 绘制：**< 20KB**（最简单的游戏之一）
- 含音效：**< 60KB**

## 渲染要点

```javascript
render(ctx) {
  const { cellSize, cellGap } = CONFIG.game;
  const boardSize = 3 * cellSize + 2 * cellGap;

  // 棋盘背景
  ctx.fillStyle = CONFIG.colors.board;
  ctx.fillRect(0, 0, boardSize, boardSize);

  // 格子 + 棋子
  for (let i = 0; i < 9; i++) {
    const r = Math.floor(i / 3);
    const c = i % 3;
    const x = c * (cellSize + cellGap);
    const y = r * (cellSize + cellGap);

    ctx.fillStyle = CONFIG.colors.cell;
    ctx.fillRect(x, y, cellSize, cellSize);

    if (board.cells[i]) {
      const symbol = board.cells[i];
      const color = CONFIG.players[symbol].color;

      ctx.strokeStyle = color;
      ctx.lineWidth = 5;

      if (symbol === 'X') {
        // 画 X
        ctx.beginPath();
        ctx.moveTo(x + 20, y + 20);
        ctx.lineTo(x + cellSize - 20, y + cellSize - 20);
        ctx.moveTo(x + cellSize - 20, y + 20);
        ctx.lineTo(x + 20, y + cellSize - 20);
        ctx.stroke();
      } else {
        // 画 O
        ctx.beginPath();
        ctx.arc(x + cellSize/2, y + cellSize/2, cellSize/2 - 20, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }

  // 获胜连线
  if (board.winLine) {
    const [a, , c] = board.winLine;
    const startPos = getCellCenter(a);
    const endPos = getCellCenter(c);
    ctx.strokeStyle = CONFIG.colors.winLine;
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(startPos.x, startPos.y);
    ctx.lineTo(endPos.x, endPos.y);
    ctx.stroke();
  }
}
```

## 扩展建议

- **五子棋**：将棋盘扩大到 15x15，获胜条件改为 5 连，但 Minimax 需加深度限制 + 启发式评估
- **四子棋**：7x6 棋盘，重力下落，4 连获胜
- **翻转棋（黑白棋）**：8x8 棋盘，夹住对方棋子翻转
