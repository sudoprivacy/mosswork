# 飞机大战/射击类 (Shooter) — 模板参考

## 游戏概述

竖屏卷轴射击游戏。玩家控制战机在屏幕底部移动并自动射击，敌机从顶部出现，击毁敌机得分。包含 Boss 战、道具系统、爆炸特效。核心挑战是子弹管理和碰撞检测性能。

> **复杂度**：★★★★☆ — 需要对象池、波次系统、空间分区碰撞检测、Boss 弹幕模式。
>
> **相关模块**：生成前应读取 `references/modules/particles-and-pooling.md`（对象池+粒子）、`references/modules/ai-behaviors.md`（波次生成器）、`references/modules/audio-and-haptics.md`（音效+振动）。

---

## 实体设计

| 实体 | 文件 | 职责 |
|------|------|------|
| `Player` | `js/entities/Player.js` | 玩家飞机位置、移动、射击间隔、生命、火力等级、无敌帧 |
| `Bullet` | `js/entities/Bullet.js` | 子弹位置、速度、伤害、归属（玩家/敌人）、active 标记 |
| `Enemy` | `js/entities/Enemy.js` | 敌机类型、HP、行为模式（FSM）、掉落概率 |
| `Boss` | `js/entities/Boss.js` | Boss 专属实体，多阶段、弹幕模式切换、血条 |
| `PowerUp` | `js/entities/PowerUp.js` | 道具（火力升级/护盾/炸弹/回血） |
| `ScrollingBackground` | `js/entities/ScrollingBackground.js` | 双图交替滚动背景 |
| `BulletPool` | `js/utils/BulletPool.js` | 子弹对象池（预分配 200+） |
| `EnemySpawner` | `js/utils/EnemySpawner.js` | 波次配置驱动的敌人生成器 |
| `CollisionSystem` | `js/utils/CollisionSystem.js` | AABB + 空间网格碰撞检测 |

### Player 实体骨架

```javascript
class Player {
  constructor(config) {
    this.x = config.canvasWidth / 2;
    this.y = config.canvasHeight - 100;
    this.width = 40; this.height = 50;
    this.speed = 400;
    this.hp = 3;
    this.maxHp = 3;
    this.powerLevel = 1;      // 火力等级 1-3
    this.fireCooldown = 0;
    this.fireInterval = 200;  // 射击间隔(ms)
    this.invincibleTimer = 0; // 无敌帧计时
    this.invincibleDuration = 1500;
    this.config = config;
  }

  update(dt, input) {
    // 移动（拖拽跟随或方向键）
    if (input.targetX !== undefined) {
      const dx = input.targetX - this.x;
      const dy = input.targetY - this.y;
      const dist = Math.hypot(dx, dy);
      if (dist > 2) {
        this.x += (dx / dist) * Math.min(this.speed * dt / 1000, dist);
        this.y += (dy / dist) * Math.min(this.speed * dt / 1000, dist);
      }
    }
    // 边界约束
    this.x = clamp(this.x, this.width/2, this.config.canvasWidth - this.width/2);
    this.y = clamp(this.y, this.height/2, this.config.canvasHeight - this.height/2);

    // 射击
    this.fireCooldown -= dt;
    if (this.fireCooldown <= 0) {
      this.fire();
      this.fireCooldown = this.fireInterval;
    }

    // 无敌帧倒计时
    if (this.invincibleTimer > 0) this.invincibleTimer -= dt;
  }

  fire() {
    // 根据火力等级发射不同弹道
    switch (this.powerLevel) {
      case 1:
        bulletPool.acquire(this.x, this.y - 25, 0, -600, 'player');
        break;
      case 2:
        bulletPool.acquire(this.x - 10, this.y - 20, 0, -600, 'player');
        bulletPool.acquire(this.x + 10, this.y - 20, 0, -600, 'player');
        break;
      case 3:
        bulletPool.acquire(this.x, this.y - 25, 0, -600, 'player');
        bulletPool.acquire(this.x - 15, this.y - 15, -80, -590, 'player');
        bulletPool.acquire(this.x + 15, this.y - 15, 80, -590, 'player');
        break;
    }
  }

  takeDamage() {
    if (this.invincibleTimer > 0) return;
    this.hp--;
    this.invincibleTimer = this.invincibleDuration;
    this.powerLevel = Math.max(1, this.powerLevel - 1);
  }

  getHitbox() {
    return { x: this.x - 15, y: this.y - 15, w: 30, h: 30 }; // 碰撞箱小于视觉
  }

  isInvincible() { return this.invincibleTimer > 0; }
}
```

### Enemy 实体骨架

```javascript
class Enemy {
  constructor(type, x, y) {
    const cfg = ENEMY_TYPES[type];
    this.type = type;
    this.x = x; this.y = y;
    this.hp = cfg.hp;
    this.maxHp = cfg.hp;
    this.speed = cfg.speed;
    this.score = cfg.score;
    this.dropRate = cfg.dropRate;
    this.width = cfg.width; this.height = cfg.height;
    this.fireCooldown = Math.random() * 1000;
    this.fireInterval = cfg.fireInterval || 9999;
    this.active = true;
  }

  update(dt, player) {
    this.y += this.speed * dt / 1000;

    // 敌机射击
    if (this.fireInterval < 9999) {
      this.fireCooldown -= dt;
      if (this.fireCooldown <= 0) {
        this.fireCooldown = this.fireInterval;
        const angle = Math.atan2(player.y - this.y, player.x - this.x);
        bulletPool.acquire(
          this.x, this.y + 20,
          Math.cos(angle) * 300, Math.sin(angle) * 300,
          'enemy'
        );
      }
    }

    // 超出屏幕
    if (this.y > 1400) this.active = false;
  }

  takeDamage(dmg) {
    this.hp -= dmg;
    if (this.hp <= 0) this.active = false;
  }

  getHitbox() {
    return { x: this.x - this.width/2, y: this.y - this.height/2, w: this.width, h: this.height };
  }
}

const ENEMY_TYPES = {
  scout:   { hp: 1,  speed: 200, score: 10,  dropRate: 0.05, width: 30, height: 30 },
  fighter: { hp: 3,  speed: 150, score: 30,  dropRate: 0.15, width: 40, height: 40, fireInterval: 2000 },
  bomber:  { hp: 8,  speed: 80,  score: 80,  dropRate: 0.30, width: 60, height: 60, fireInterval: 1500 },
};
```

### Boss 实体骨架

```javascript
class Boss extends Enemy {
  constructor(x, y) {
    super('boss', x, y);
    this.hp = 200; this.maxHp = 200;
    this.width = 120; this.height = 100;
    this.phase = 1;
    this.phaseThresholds = [0.66, 0.33];  // 血量 66%、33% 时切换阶段
    this.patternTimer = 0;
    this.currentPattern = 'spiral';
    this.patternSwitchInterval = 3000;
    this.entered = false;
    this.targetY = 150;
  }

  update(dt, player) {
    // 入场动画
    if (!this.entered) {
      this.y += 50 * dt / 1000;
      if (this.y >= this.targetY) this.entered = true;
      return;
    }

    // 阶段切换
    const hpRatio = this.hp / this.maxHp;
    if (this.phase === 1 && hpRatio < 0.66) this.phase = 2;
    if (this.phase === 2 && hpRatio < 0.33) this.phase = 3;

    // 左右移动
    this.x += Math.sin(performance.now() / 1000) * 100 * dt / 1000;

    // 弹幕模式切换
    this.patternTimer += dt;
    if (this.patternTimer >= this.patternSwitchInterval) {
      this.patternTimer = 0;
      this.currentPattern = this._pickPattern();
    }

    // 发射弹幕
    this._firePattern(dt, player);
  }

  _pickPattern() {
    const patterns = this.phase === 1
      ? ['spiral', 'fan']
      : this.phase === 2
      ? ['spiral', 'fan', 'tracking']
      : ['spiral', 'fan', 'tracking', 'burst'];
    return patterns[Math.floor(Math.random() * patterns.length)];
  }

  _firePattern(dt, player) {
    this.fireCooldown -= dt;
    if (this.fireCooldown > 0) return;

    switch (this.currentPattern) {
      case 'spral':
        // 螺旋弹幕：每帧旋转角度发射
        const angle = performance.now() / 200;
        for (let i = 0; i < 4; i++) {
          const a = angle + (i * Math.PI / 2);
          bulletPool.acquire(this.x, this.y + 30,
            Math.cos(a) * 200, Math.sin(a) * 200, 'enemy');
        }
        this.fireCooldown = 100;
        break;
      case 'fan':
        // 扇形弹幕
        for (let i = -3; i <= 3; i++) {
          const a = Math.PI / 2 + i * 0.2;
          bulletPool.acquire(this.x, this.y + 30,
            Math.cos(a) * 250, Math.sin(a) * 250, 'enemy');
        }
        this.fireCooldown = 400;
        break;
      case 'tracking':
        // 追踪弹
        const ta = Math.atan2(player.y - this.y, player.x - this.x);
        bulletPool.acquire(this.x, this.y + 30,
          Math.cos(ta) * 300, Math.sin(ta) * 300, 'enemy');
        this.fireCooldown = 200;
        break;
    }
  }
}
```

### BulletPool 实体骨架

```javascript
// 详细实现见 references/modules/particles-and-pooling.md
class BulletPool {
  constructor(size = 200) {
    this.bullets = Array.from({ length: size }, () => ({
      x: 0, y: 0, vx: 0, vy: 0, damage: 1, owner: 'player', active: false,
    }));
  }
  acquire(x, y, vx, vy, owner, damage = 1) {
    const b = this.bullets.find(b => !b.active);
    if (!b) return null;
    Object.assign(b, { x, y, vx, vy, owner, damage, active: true });
    return b;
  }
  release(b) { b.active = false; }
  updateAll(dt, canvasW, canvasH) {
    for (const b of this.bullets) {
      if (!b.active) continue;
      b.x += b.vx * dt / 1000;
      b.y += b.vy * dt / 1000;
      if (b.x < -20 || b.x > canvasW + 20 || b.y < -20 || b.y > canvasH + 20) this.release(b);
    }
  }
  renderAll(ctx) {
    ctx.fillStyle = '#0f0';
    for (const b of this.bullets) if (b.active && b.owner === 'player') ctx.fillRect(b.x-2, b.y-6, 4, 12);
    ctx.fillStyle = '#f44';
    for (const b of this.bullets) if (b.active && b.owner === 'enemy') ctx.fillRect(b.x-3, b.y-3, 6, 6);
  }
}
```

---

## 核心算法

### 1. 碰撞检测（空间网格优化）

```javascript
// 详细实现见 references/modules/particles-and-pooling.md
// 每帧重建网格，将敌人插入，子弹只检测附近网格
function checkCollisions(bullets, enemies, player) {
  const grid = new SpatialGrid(64);
  grid.clear();
  for (const e of enemies) if (e.active) grid.insert(e);

  for (const b of bullets.bullets) {
    if (!b.active) continue;
    const nearby = grid.query(b.x, b.y, 32);
    for (const e of nearby) {
      if (!e.active) continue;
      if (b.owner === 'player' && rectIntersect(b, e.getHitbox())) {
        e.takeDamage(b.damage);
        bullets.release(b);
        if (!e.active) { /* 击毁处理 */ }
        break;
      }
    }
  }

  // 玩家 vs 敌人子弹
  for (const b of bullets.bullets) {
    if (b.active && b.owner === 'enemy' && !player.isInvincible()) {
      if (rectIntersect(b, player.getHitbox())) {
        player.takeDamage();
        bullets.release(b);
      }
    }
  }

  // 玩家 vs 敌机（碰撞）
  const nearbyEnemies = grid.query(player.x, player.y, 64);
  for (const e of nearbyEnemies) {
    if (e.active && !player.isInvincible() && rectIntersect(player.getHitbox(), e.getHitbox())) {
      player.takeDamage();
      e.takeDamage(999);
    }
  }
}
```

### 2. 敌人波次生成

```javascript
// 波次配置
const WAVES = [
  { delay: 1000, enemies: [{ type: 'scout', count: 5, interval: 300 }] },
  { delay: 5000, enemies: [{ type: 'scout', count: 8, interval: 250 }, { type: 'fighter', count: 2, interval: 800 }] },
  { delay: 12000, enemies: [{ type: 'fighter', count: 5, interval: 500 }] },
  { delay: 20000, enemies: [{ type: 'boss', count: 1 }] },
];

// 使用 WaveManager（见 references/modules/ai-behaviors.md）
const spawner = new WaveManager(WAVES);
spawner.onSpawn = (type) => {
  if (type === 'boss') enemies.push(new Boss(canvasW/2, -100));
  else enemies.push(new Enemy(type, Math.random() * canvasW, -50));
};
```

### 3. 卷轴背景

```javascript
class ScrollingBackground {
  constructor(speed, canvasW, canvasH) {
    this.speed = speed;
    this.canvasW = canvasW;
    this.canvasH = canvasH;
    this.y1 = 0;
    this.y2 = -canvasH;
  }
  update(dt) {
    const scroll = this.speed * dt / 1000;
    this.y1 += scroll;
    this.y2 += scroll;
    if (this.y1 >= this.canvasH) this.y1 = this.y2 - this.canvasH;
    if (this.y2 >= this.canvasH) this.y2 = this.y1 - this.canvasH;
  }
  render(ctx) {
    // 纯色渐变背景（无需图片资源）
    const grad = ctx.createLinearGradient(0, 0, 0, this.canvasH);
    grad.addColorStop(0, '#0a0a23');
    grad.addColorStop(1, '#1a1a3e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, this.y1, this.canvasW, this.canvasH);
    ctx.fillRect(0, this.y2, this.canvasW, this.canvasH);

    // 星空效果（随机点）
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    for (let i = 0; i < 50; i++) {
      const x = (i * 137) % this.canvasW;
      const y = (i * 97 + this.y1) % this.canvasH;
      ctx.fillRect(x, y, 2, 2);
    }
  }
}
```

### 4. 道具系统

```javascript
const POWERUP_TYPES = {
  power:  { color: '#0f0', effect: 'upgrade' },   // 火力升级
  shield: { color: '#0ff', effect: 'shield' },    // 护盾
  bomb:   { color: '#f00', effect: 'bomb' },      // 清屏炸弹
  heal:   { color: '#f0f', effect: 'heal' },      // 回血
};

class PowerUp {
  constructor(x, y, type) {
    this.x = x; this.y = y;
    this.type = type;
    this.vy = 100;
    this.active = true;
  }
  update(dt) {
    this.y += this.vy * dt / 1000;
    if (this.y > 1400) this.active = false;
  }
  apply(player) {
    switch (POWERUP_TYPES[this.type].effect) {
      case 'upgrade': player.powerLevel = Math.min(3, player.powerLevel + 1); break;
      case 'shield':  player.invincibleTimer = 3000; break;
      case 'bomb':    enemies.forEach(e => e.active = false); break;
      case 'heal':    player.hp = Math.min(player.maxHp, player.hp + 1); break;
    }
  }
}
```

---

## 场景结构

| 场景 | 功能 |
|------|------|
| MenuScene | 标题、开始按钮、最高分 |
| GameScene | 游戏主循环、波次管理、Boss 触发 |
| GameOverScene | 得分、重新开始 |

---

## config.js 参数建议

```javascript
const CONFIG = {
  gameName: 'Shooter',
  version: '1.0.0',
  canvas: { width: 480, height: 800, designRatio: 480 / 800 },
  gameplay: {
    player: { speed: 400, maxHp: 3, fireInterval: 200, invincibleDuration: 1500 },
    bullet: { poolSize: 200, speed: 600 },
    scrollSpeed: 100,
  },
  enemies: {
    scout:   { hp: 1,  speed: 200, score: 10,  dropRate: 0.05 },
    fighter: { hp: 3,  speed: 150, score: 30,  dropRate: 0.15, fireInterval: 2000 },
    bomber:  { hp: 8,  speed: 80,  score: 80,  dropRate: 0.30, fireInterval: 1500 },
    boss:    { hp: 200, speed: 0,  score: 1000, dropRate: 1.0 },
  },
  waves: [
    { delay: 1000,  enemies: [{ type: 'scout', count: 5, interval: 300 }] },
    { delay: 5000,  enemies: [{ type: 'scout', count: 8, interval: 250 }, { type: 'fighter', count: 2, interval: 800 }] },
    { delay: 12000, enemies: [{ type: 'fighter', count: 5, interval: 500 }] },
    { delay: 20000, enemies: [{ type: 'boss', count: 1 }] },
  ],
  colors: {
    background: '#0a0a23',
    player: '#0f0',
    playerBullet: '#0f0',
    enemyBullet: '#f44',
    boss: '#a0f',
  },
  audio: {
    bgmBattle: 'assets/audio/bgm_battle.mp3',
    bgmBoss: 'assets/audio/bgm_boss.mp3',
    shoot: 'assets/audio/sfx_shoot.mp3',
    explosion: 'assets/audio/sfx_explosion.mp3',
    powerup: 'assets/audio/sfx_powerup.mp3',
    hurt: 'assets/audio/sfx_hurt.mp3',
  },
};
```

---

## 输入映射

| 操作 | 效果 |
|------|------|
| 拖拽 | 飞机跟随手指/鼠标位置 |
| 点击 | 飞机移动到点击位置 |
| ← → A D | 左右移动 |
| ↑ ↓ W S | 上下移动 |
| 空格 | 释放炸弹（清屏） |

---

## 资源清单

| 资源 | 说明 | 可选 |
|------|------|------|
| 玩家飞机精灵 | 可用绿色三角形代替 | 可选 |
| 敌机精灵 | 可用红色矩形/三角形区分类型 | 可选 |
| Boss 精灵 | 可用紫色大矩形代替 | 可选 |
| 爆炸动画帧 | 可用程序化粒子代替 | 可选 |
| 射击音效 | `sfx_shoot.mp3`，<0.5s | 推荐 |
| 爆炸音效 | `sfx_explosion.mp3`，<1s | 推荐 |
| 道具音效 | `sfx_powerup.mp3`，<0.5s | 推荐 |
| 战斗 BGM | `bgm_battle.mp3` | 推荐 |
| Boss BGM | `bgm_boss.mp3` | 可选 |

---

## 预估包体

- 纯 Canvas 绘制（无图片/音效）：**< 80KB**
- 含精灵图和音效：**< 500KB**
- 使用精灵图集可控制在 1MB 内
- 远低于 4MB 限制

---

## 渲染要点

```javascript
render(ctx) {
  // 1. 背景层（最先绘制）
  scrollBg.render(ctx);

  // 2. 敌人子弹（在敌机下方）
  bulletPool.renderEnemyBullets(ctx);

  // 3. 敌机
  for (const e of enemies) {
    if (!e.active) continue;
    ctx.fillStyle = e instanceof Boss ? CONFIG.colors.boss : '#f44';
    ctx.fillRect(e.x - e.width/2, e.y - e.height/2, e.width, e.height);
  }

  // 4. 玩家子弹
  bulletPool.renderPlayerBullets(ctx);

  // 5. 玩家（无敌帧闪烁）
  if (!player.isInvincible() || Math.floor(performance.now() / 100) % 2 === 0) {
    ctx.fillStyle = CONFIG.colors.player;
    // 绘制三角形飞机
    ctx.beginPath();
    ctx.moveTo(player.x, player.y - 25);
    ctx.lineTo(player.x - 20, player.y + 15);
    ctx.lineTo(player.x + 20, player.y + 15);
    ctx.closePath();
    ctx.fill();
  }

  // 6. 道具
  for (const p of powerups) {
    if (!p.active) continue;
    ctx.fillStyle = POWERUP_TYPES[p.type].color;
    ctx.fillRect(p.x - 10, p.y - 10, 20, 20);
  }

  // 7. 粒子/爆炸特效
  particlePool.renderAll(ctx);

  // 8. HUD（最上层）
  ctx.fillStyle = '#fff';
  ctx.font = '20px Arial';
  ctx.textAlign = 'left';
  ctx.fillText(`分数: ${score}`, 10, 30);
  ctx.fillText(`生命: ${'♥'.repeat(player.hp)}`, 10, 55);
  if (boss) drawBossHealthBar(ctx, boss);
}
```

---

## 包体优化指引

| 优化方向 | 具体做法 | 效果 |
|---------|---------|------|
| 精灵图集 | 所有角色帧合并为一张图，用 `drawImage` 裁剪 | 减少文件数+加载时间 |
| 程序化特效 | 爆炸用粒子系统代替序列帧图 | 省去爆炸图片资源 |
| 纯色背景 | 渐变色+星空程序化绘制代替背景图 | 省去背景图资源 |
| 几何角色 | 飞机/敌机用三角形/矩形+颜色区分 | 零图片资源 |
| 音效压缩 | SFX 压缩为低码率 MP3 | 每个音效 < 50KB |
| BGM 分包 | BGM 放分包或 CDN 按需加载 | 主包减至 < 100KB |
